#ifndef _apm_x_
#define _apm_x_

/*
 * asapm is the APM (Advanced Power Management) monitor utility for X Windows
 * Copyright (c) 1998  Albert Dorofeev <Albert@mail.dma.be>
 * For the updates see http://bewoner.dma.be/Albert/linux/
 * 
 * This software is distributed under GPL. For details see LICENSE file.
 */


void initializeWindow(int argc, char** argv,
                        char * display_name,
                        char * mainGeometry,
                        char * statuscolor,
                        char * greencolor,
                        char * yellowcolor,
                        char * redcolor,
                        char * slidercolor,
                        char * sliderbgcolor,
                        int withdrawn,
                        int iconic,
			int embossed);

void CheckX11Events();

void Redraw();

void Cleanup();

#endif

