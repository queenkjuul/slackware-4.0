#ifndef _GETDATE_H_
#define _GETDATE_H_

#include <config.h>
#include "defines.h"

time_t get_date P_((const char *p, const time_t *now));
#endif
