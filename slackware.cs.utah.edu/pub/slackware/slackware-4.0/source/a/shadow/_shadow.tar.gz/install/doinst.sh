if [ ! -r var/log/sulog ]; then
  touch var/log/sulog
  chmod 640 var/log/sulog
fi
( cd bin ; rm -rf sulogin )
( cd bin ; ln -sf /sbin/sulogin sulogin )
( cd usr/include ; rm -rf shadow.h )
( cd usr/include ; ln -sf shadow/shadow.h shadow.h )
if [ -r sbin/adduser ]; then 
  rm -f sbin/adduser
fi
( cd usr/man/man8 ; rm -rf pwunconv.8.gz )
( cd usr/man/man8 ; ln -sf pwconv.8.gz pwunconv.8.gz )
