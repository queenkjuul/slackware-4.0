( cd usr/bin ; rm -rf [ )
( cd usr/bin ; ln -sf  test [ )
