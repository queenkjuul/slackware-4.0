( cd bin ; rm -rf mt )
( cd bin ; ln -sf  mt-GNU mt )
