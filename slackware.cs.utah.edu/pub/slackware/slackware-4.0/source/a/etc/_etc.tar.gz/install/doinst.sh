( chmod 751 root )
if [ ! -r etc/passwd ]; then
 cp etc/npasswd etc/passwd
fi
if [ ! -r etc/passwd.OLD ]; then
 mv etc/npasswd etc/passwd.OLD
else
 rm etc/npasswd
fi
if [ ! -r etc/shadow ]; then
 mv etc/nshadow etc/shadow
else
 rm etc/nshadow
fi
if [ ! -r etc/group ]; then
 mv etc/ngroup etc/group
else
 rm etc/ngroup
fi
if [ ! -r etc/hosts ]; then
 mv etc/hosts-incoming etc/hosts
else
 rm -f etc/hosts-incoming
fi
if [ ! -r etc/networks ]; then
 mv etc/networks-incoming etc/networks
else
 rm -f etc/networks-incoming
fi
if [ ! -r etc/nsswitch.conf ]; then
 mv etc/nsswitch.conf-incoming etc/nsswitch.conf
else
 rm -f etc/nsswitch.conf-incoming
fi
( cd etc ; rm -rf wtmp )
( cd etc ; ln -sf  /var/log/wtmp wtmp )
( cd usr/etc ; rm -rf printcap )
( cd usr/etc ; ln -sf  /etc/printcap printcap )
( cd etc ; rm -rf utmp )
( cd etc ; ln -sf /var/log/utmp utmp )
( cd etc ; rm -rf issue.net )
( cd etc ; ln -sf issue issue.net )
