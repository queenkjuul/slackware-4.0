( cd sbin ; rm -rf rmmod )
( cd sbin ; ln -sf insmod rmmod )
