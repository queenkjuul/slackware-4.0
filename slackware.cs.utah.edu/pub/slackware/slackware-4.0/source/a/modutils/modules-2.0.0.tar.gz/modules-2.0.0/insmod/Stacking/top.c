/* Kernel includes */
#include <linux/module.h>

extern int base(int, char *);

static int level = 1;

int
init_module(void)
{
	base(level, "hello");
	return 0;
}

void
cleanup_module( void)
{
	return;
}
