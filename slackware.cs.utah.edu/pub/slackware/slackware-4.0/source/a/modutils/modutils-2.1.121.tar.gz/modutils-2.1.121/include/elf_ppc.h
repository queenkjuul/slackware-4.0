/* Machine-specific elf macros for the PowerPC.  */
#ident "$Id: elf_ppc.h,v 1.1 1997/09/10 22:13:04 rth Exp $"

#define ELFCLASSM	ELFCLASS32
#define ELFDATAM	ELFDATA2MSB

#define MATCH_MACHINE(x)  (x == EM_PPC)

#define SHT_RELM	SHT_RELA
#define Elf32_RelM	Elf32_Rela
