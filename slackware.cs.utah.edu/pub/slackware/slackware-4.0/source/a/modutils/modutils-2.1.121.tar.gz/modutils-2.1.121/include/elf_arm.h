/* Machine-specific elf macros for ARM.  */
#ident "$Id: elf_arm.h,v 1.1 1998/08/30 20:47:22 philip Exp $"

#define ELFCLASSM	ELFCLASS32
#define ELFDATAM	ELFDATA2LSB

#define MATCH_MACHINE(x)  (x == EM_ARM)

#define SHT_RELM	SHT_REL
#define Elf32_RelM	Elf32_Rel
