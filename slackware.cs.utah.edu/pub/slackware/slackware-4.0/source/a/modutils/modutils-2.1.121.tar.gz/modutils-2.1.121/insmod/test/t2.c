#define MODULE
#include <linux/module.h>

static int printk;
MODULE_PARM(printk, "i");

int init_module(void)
{
  printk=2;
  return 0;
}

void cleanup_module(void)
{
}
