static char *foo = "passed";

void printme()
{
  printk("test %s\n", foo);
}
