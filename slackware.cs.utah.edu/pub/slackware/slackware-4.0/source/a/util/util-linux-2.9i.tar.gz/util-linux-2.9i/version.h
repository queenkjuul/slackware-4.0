#define UTIL_LINUX_VERSION	"2.9i"

const char * const util_linux_version = "util-linux " UTIL_LINUX_VERSION;
