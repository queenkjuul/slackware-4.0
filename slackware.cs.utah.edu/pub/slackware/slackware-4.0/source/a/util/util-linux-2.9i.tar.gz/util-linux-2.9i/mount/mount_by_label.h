char *get_spec_by_uuid(const char *uuid);
char *get_spec_by_volume_label(const char *volumelabel);
