#ifndef __unzver_h   /* prevent multiple inclusions */
#define __unzver_h

#define UNZ_DLL_VERSION "5.4\0"
#define COMPANY_NAME "Info-ZIP\0"

#endif /* __unzver_h */
