#define VERSION	"3.8"
#define DATE	"8 July 97 "
