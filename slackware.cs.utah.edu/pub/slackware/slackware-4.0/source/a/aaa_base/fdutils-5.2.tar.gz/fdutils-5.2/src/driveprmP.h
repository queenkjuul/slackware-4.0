extern FILE *driveprmin;

#define YY_DECL int driveprmlex(int drivenum, struct keyword_l *ids, int size, \
				int *mask, int *found)

YY_DECL;
