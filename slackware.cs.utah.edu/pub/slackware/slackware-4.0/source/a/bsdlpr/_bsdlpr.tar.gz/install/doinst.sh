( cd usr/bin ; rm -rf lpc )
( cd usr/bin ; ln -sf  /usr/sbin/lpc lpc )
rm -f usr/sbin/lpd
mv usr/sbin/bsdlpd usr/sbin/lpd
if [ ! -f etc/printcap ]; then
 mv etc/printcap.new etc/printcap
fi
