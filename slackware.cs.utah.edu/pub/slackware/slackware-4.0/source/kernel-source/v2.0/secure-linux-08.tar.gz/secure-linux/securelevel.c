#include <stdio.h>
#include <sys/sysctl.h>
#include <linux/sysctl.h>

int securelvl_name[] = {
	CTL_KERN,
	KERN_SECURELVL
};

int main()
{
	int level = 1;

	if (sysctl(securelvl_name, 2, NULL, 0, &level, sizeof(level)))
		perror("sysctl");

	return 0;
}
