#include <stdio.h>
#include <string.h>
#include <unistd.h>

void caller(void (*trampoline)()) {
	puts("Attempting to call a trampoline...");

	trampoline();
}

void do_trampoline() {
	void nested() {
		puts("Succeeded.");
	}

	caller(nested);
}

void do_exploit() {
	puts("Attempting to simulate a buffer overflow exploit...");

	__asm__ __volatile__("movl $1f,%%eax;"
		".byte 0x68; popl %%ecx; jmp *%%eax; nop;"
		"pushl %%esp;"
		"ret;"
		"1:"
	: : : "ax", "cx");

	puts("Succeeded.");
}

void help(char *name) {
	printf(
		"Usage: %s OPTION\n"
		"Non-executable user stack area tests\n\n"
		"  -t   call a GCC trampoline\n"
		"  -e   simulate a buffer overflow exploit\n"
		"  -b   simulate an exploit after a trampoline call\n",
		name);
	exit(1);
}

int main(int argc, char **argv) {
	if (argc != 2) help(argv[0]);
	if (argv[1][0] != '-' || strlen(argv[1]) != 2) help(argv[0]);

	switch (argv[1][1]) {
	case 't':
		do_trampoline();
		break;
	case 'b':
		do_trampoline();
	case 'e':
		do_exploit();
		break;
	default:
		help(argv[0]);
	}

	return 0;
}
