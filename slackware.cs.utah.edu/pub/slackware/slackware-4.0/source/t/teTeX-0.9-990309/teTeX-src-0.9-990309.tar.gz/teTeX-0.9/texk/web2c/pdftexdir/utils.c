#include "libpdftex.h"
/*
#include "image.h"
#include <kpathsea/c-vararg.h>
#include <kpathsea/c-proto.h>
*/

char *filename = 0;
char printf_buf[1024];


integer pdfoffset()
{
    return pdfgone + pdfptr;
}

void pdfout(integer c) {
    pdfbuf[pdfptr++] = c;
    if (pdfptr == pdfbufsize)
        pdfflush();
}

void flush_printf_buf()
{
    char *p = printf_buf;
    if (sizeof(pdfbuf) - pdfptr <= 1024)
        pdfflush();
    while (*p)
        pdfbuf[pdfptr++] = *p++;
}

strnumber maketexstring(char *s)
{
    int l;
    if (s == 0 || !*s)
        return getnullstr();
    l = strlen(s);
    CHECK_BUF(poolptr + l, poolsize);
    while (l-- > 0)
        strpool[poolptr++] = *s++;
    return makestring();
}

char *makecstring(integer s)
{
    static char cstrbuf[1024];
    char *p = cstrbuf;
    int i, l = strstart[s + 1] - strstart[s];
    CHECK_BUF(l, 1024);
    for (i = 0; i < l; i++)
        *p++ = strpool[i + strstart[s]];
    *p = 0;
    return cstrbuf;
}

boolean str_eq_cstr(strnumber n, char *s)
{
    int l;
    if (s == 0 || n == 0)
        return false;
    l = strstart[n];
    while (*s && l < strstart[n + 1] && *s == strpool[l])
        l++, s++;
    return !*s && l == strstart[n + 1];
}

size_t xfwrite(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    if (fwrite(ptr, size, nmemb, stream) != nmemb)
        FAIL("fwrite() failed");
    return nmemb;
}

int xfflush(FILE *stream)
{
    if (fflush(stream) != 0)
        FAIL("fflush() failed");
    return 0;
}

int xgetc(FILE *stream)
{
    int c = getc(stream);
    if (c < 0 && c != EOF)
        FAIL("getc() failed");
    return c;
}

int xputc(int c, FILE *stream)
{
    int i = putc(c, stream);
    if (i < 0)
        FAIL("putc() failed");
    return i;
}

void libpdffinish()
{
    fm_free();
    enc_free();
    img_free();
    vf_free();
    epdf_free();
}
