#include "c-auto.h"

/* This string is appended to all the banners and used in --version.  */

char *versionstring = WEB2CVERSION;
