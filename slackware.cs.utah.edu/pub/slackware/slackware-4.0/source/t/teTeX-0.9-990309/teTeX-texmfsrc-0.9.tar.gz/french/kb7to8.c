# include "stdio.h"
# define U(x) ((x)&0377)
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin ={stdin}, *yyout ={stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
  printf("�");
break;
case 2:
  printf("�");
break;
case 3:
  printf("�");
break;
case 4:
  printf("�");
break;
case 5:
  printf("�");
break;
case 6:
  printf("�");
break;
case 7:
  printf("�");
break;
case 8:
  printf("�");
break;
case 9:
  printf("�");
break;
case 10:
  printf("�");
break;
case 11:
  printf("�");
break;
case 12:
  printf("�");
break;
case 13:
  printf("�");
break;
case 14:
  printf("�");
break;
case 15:
  printf("�");
break;
case 16:
  printf("�");
break;
case 17:
  printf("�");
break;
case 18:
  printf("�");
break;
case 19:
  printf("�");
break;
case 20:
  printf("�");
break;
case 21:
  printf("�");
break;
case 22:
  printf("�");
break;
case 23:
  printf("�");
break;
case 24:
  printf("�");
break;
case 25:
  printf("�");
break;
case 26:
  printf("�");
break;
case 27:
  printf("�");
break;
case 28:
  printf("�");
break;
case 29:
  printf("�");
break;
case 30:
  printf("�");
break;
case 31:
  printf("�");
break;
case 32:
  printf("�");
break;
case 33:
  printf("�");
break;
case 34:
  printf("�");
break;
case 35:
  printf("�");
break;
case 36:
  printf("�");
break;
case 37:
  printf("�");
break;
case 38:
  printf("�");
break;
case 39:
  printf("�");
break;
case 40:
  printf("�");
break;
case 41:
  printf("�");
break;
case 42:
  printf("�");
break;
case 43:
  printf("�");
break;
case 44:
  printf("�");
break;
case 45:
  printf("�");
break;
case 46:
  printf("�");
break;
case 47:
  printf("�");
break;
case 48:
  printf("�");
break;
case 49:
  printf("�");
break;
case 50:
  printf("�");
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
#ifndef yywrap
int yywrap () { return 1; }
#endif
int main() { return yylex(); }
int yyvstop[] ={
0,

41,
0,

47,
0,

50,
0,

48,
0,

43,
0,

45,
0,

49,
0,

44,
0,

42,
0,

5,
0,

7,
0,

6,
0,

8,
0,

38,
0,

34,
0,

13,
0,

14,
0,

16,
0,

15,
0,

20,
0,

19,
0,

24,
0,

23,
0,

36,
0,

40,
0,

28,
0,

30,
0,

29,
0,

32,
0,

46,
0,

1,
0,

3,
0,

2,
0,

4,
0,

37,
0,

33,
0,

9,
0,

10,
0,

12,
0,

11,
0,

18,
0,

17,
0,

22,
0,

21,
0,

35,
0,

39,
0,

25,
0,

27,
0,

26,
0,

31,
0,
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } yycrank[] ={
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,3,	60,33,	
61,15,	62,11,	66,54,	68,84,	
64,77,	71,22,	72,32,	0,0,	
0,0,	0,0,	76,43,	81,53,	
0,0,	86,38,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	1,4,	4,13,	1,5,	
1,6,	5,16,	0,0,	0,0,	
7,59,	77,23,	181,14,	59,71,	
60,72,	89,126,	79,104,	0,0,	
0,0,	84,21,	85,109,	88,124,	
0,0,	0,0,	7,60,	7,61,	
0,0,	90,127,	7,62,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	1,7,	8,70,	157,162,	
0,0,	0,0,	3,9,	6,17,	
7,63,	77,44,	7,64,	7,65,	
63,76,	65,80,	79,105,	66,81,	
80,106,	84,42,	85,110,	88,125,	
95,144,	67,83,	7,66,	7,67,	
78,103,	7,68,	7,69,	64,78,	
69,86,	83,108,	96,145,	97,146,	
1,8,	98,147,	60,73,	61,74,	
62,75,	66,82,	68,85,	64,79,	
71,100,	72,101,	73,33,	74,15,	
75,11,	76,102,	81,107,	82,54,	
86,111,	90,33,	99,148,	100,22,	
101,32,	102,43,	103,149,	97,54,	
104,23,	105,44,	106,150,	107,53,	
108,151,	94,138,	109,21,	110,42,	
111,38,	94,139,	112,20,	113,27,	
114,29,	115,31,	1,9,	116,36,	
1,10,	117,37,	118,152,	119,41,	
1,11,	120,48,	1,12,	121,52,	
1,13,	94,140,	122,57,	123,58,	
124,25,	1,14,	125,46,	128,19,	
129,26,	130,28,	131,30,	1,15,	
132,35,	94,141,	133,153,	134,40,	
1,16,	94,142,	135,47,	136,51,	
1,17,	1,18,	137,56,	1,19,	
138,18,	1,20,	1,21,	1,22,	
1,23,	1,24,	1,25,	1,26,	
1,27,	94,143,	139,24,	1,28,	
1,29,	140,34,	141,39,	142,45,	
143,55,	1,30,	145,154,	1,31,	
1,32,	1,33,	1,34,	147,155,	
1,35,	1,36,	1,37,	70,87,	
1,38,	1,39,	149,156,	1,40,	
70,88,	1,41,	1,42,	1,43,	
1,44,	1,45,	1,46,	1,47,	
1,48,	150,157,	151,158,	1,49,	
1,50,	152,50,	153,49,	154,159,	
155,160,	1,51,	156,161,	1,52,	
1,53,	1,54,	1,55,	158,163,	
1,56,	1,57,	70,89,	159,164,	
1,58,	87,112,	160,165,	161,166,	
162,167,	87,113,	163,10,	164,169,	
165,170,	87,114,	166,171,	167,172,	
70,90,	70,91,	168,10,	87,115,	
70,92,	169,173,	171,174,	172,175,	
173,176,	87,116,	174,12,	175,178,	
176,179,	87,117,	177,12,	70,93,	
87,118,	70,94,	70,95,	178,180,	
70,96,	87,119,	180,181,	93,128,	
0,0,	87,120,	0,0,	93,129,	
0,0,	0,0,	0,0,	93,130,	
70,97,	70,98,	0,0,	87,121,	
70,99,	93,131,	0,0,	0,0,	
0,0,	87,122,	0,0,	93,132,	
0,0,	87,123,	0,0,	0,0,	
0,0,	0,0,	93,133,	0,0,	
0,0,	0,0,	0,0,	93,134,	
0,0,	0,0,	0,0,	93,135,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	93,136,	0,0,	0,0,	
0,0,	0,0,	0,0,	93,137,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	163,168,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	174,177,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] ={
0,	0,	0,
yycrank+1,	0,		0,	
yycrank+0,	yysvec+1,	0,	
yycrank+2,	0,		0,	
yycrank+2,	0,		0,	
yycrank+3,	0,		0,	
yycrank+3,	0,		0,	
yycrank+3,	0,		0,	
yycrank+2,	0,		0,	
yycrank+0,	0,		yyvstop+1,
yycrank+0,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+5,
yycrank+0,	0,		yyvstop+7,
yycrank+0,	0,		yyvstop+9,
yycrank+0,	0,		yyvstop+11,
yycrank+0,	0,		yyvstop+13,
yycrank+0,	0,		yyvstop+15,
yycrank+0,	0,		yyvstop+17,
yycrank+0,	0,		yyvstop+19,
yycrank+0,	0,		yyvstop+21,
yycrank+0,	0,		yyvstop+23,
yycrank+0,	0,		yyvstop+25,
yycrank+0,	0,		yyvstop+27,
yycrank+0,	0,		yyvstop+29,
yycrank+0,	0,		yyvstop+31,
yycrank+0,	0,		yyvstop+33,
yycrank+0,	0,		yyvstop+35,
yycrank+0,	0,		yyvstop+37,
yycrank+0,	0,		yyvstop+39,
yycrank+0,	0,		yyvstop+41,
yycrank+0,	0,		yyvstop+43,
yycrank+0,	0,		yyvstop+45,
yycrank+0,	0,		yyvstop+47,
yycrank+0,	0,		yyvstop+49,
yycrank+0,	0,		yyvstop+51,
yycrank+0,	0,		yyvstop+53,
yycrank+0,	0,		yyvstop+55,
yycrank+0,	0,		yyvstop+57,
yycrank+0,	0,		yyvstop+59,
yycrank+0,	0,		yyvstop+61,
yycrank+0,	0,		yyvstop+63,
yycrank+0,	0,		yyvstop+65,
yycrank+0,	0,		yyvstop+67,
yycrank+0,	0,		yyvstop+69,
yycrank+0,	0,		yyvstop+71,
yycrank+0,	0,		yyvstop+73,
yycrank+0,	0,		yyvstop+75,
yycrank+0,	0,		yyvstop+77,
yycrank+0,	0,		yyvstop+79,
yycrank+0,	0,		yyvstop+81,
yycrank+0,	0,		yyvstop+83,
yycrank+0,	0,		yyvstop+85,
yycrank+0,	0,		yyvstop+87,
yycrank+0,	0,		yyvstop+89,
yycrank+0,	0,		yyvstop+91,
yycrank+0,	0,		yyvstop+93,
yycrank+0,	0,		yyvstop+95,
yycrank+0,	0,		yyvstop+97,
yycrank+0,	0,		yyvstop+99,
yycrank+2,	0,		0,	
yycrank+3,	0,		0,	
yycrank+4,	0,		0,	
yycrank+5,	0,		0,	
yycrank+3,	0,		0,	
yycrank+8,	0,		0,	
yycrank+4,	0,		0,	
yycrank+6,	0,		0,	
yycrank+2,	0,		0,	
yycrank+7,	0,		0,	
yycrank+5,	0,		0,	
yycrank+189,	0,		0,	
yycrank+9,	0,		0,	
yycrank+10,	0,		0,	
yycrank+9,	0,		0,	
yycrank+10,	0,		0,	
yycrank+11,	0,		0,	
yycrank+14,	0,		0,	
yycrank+2,	0,		0,	
yycrank+4,	0,		0,	
yycrank+7,	0,		0,	
yycrank+5,	0,		0,	
yycrank+15,	0,		0,	
yycrank+14,	0,		0,	
yycrank+4,	0,		0,	
yycrank+12,	0,		0,	
yycrank+13,	0,		0,	
yycrank+17,	0,		0,	
yycrank+192,	0,		0,	
yycrank+10,	0,		0,	
yycrank+4,	0,		0,	
yycrank+16,	0,		0,	
yycrank+0,	yysvec+74,	0,	
yycrank+0,	yysvec+75,	0,	
yycrank+226,	0,		0,	
yycrank+88,	0,		0,	
yycrank+11,	0,		0,	
yycrank+11,	0,		0,	
yycrank+22,	0,		0,	
yycrank+14,	0,		0,	
yycrank+27,	0,		0,	
yycrank+18,	0,		0,	
yycrank+19,	0,		0,	
yycrank+20,	0,		0,	
yycrank+25,	0,		0,	
yycrank+23,	0,		0,	
yycrank+24,	0,		0,	
yycrank+36,	0,		0,	
yycrank+26,	0,		0,	
yycrank+42,	0,		0,	
yycrank+29,	0,		0,	
yycrank+30,	0,		0,	
yycrank+31,	0,		0,	
yycrank+33,	0,		0,	
yycrank+34,	0,		0,	
yycrank+35,	0,		0,	
yycrank+36,	0,		0,	
yycrank+38,	0,		0,	
yycrank+40,	0,		0,	
yycrank+61,	0,		0,	
yycrank+42,	0,		0,	
yycrank+44,	0,		0,	
yycrank+46,	0,		0,	
yycrank+49,	0,		0,	
yycrank+50,	0,		0,	
yycrank+51,	0,		0,	
yycrank+53,	0,		0,	
yycrank+0,	yysvec+100,	0,	
yycrank+0,	yysvec+101,	0,	
yycrank+54,	0,		0,	
yycrank+55,	0,		0,	
yycrank+56,	0,		0,	
yycrank+57,	0,		0,	
yycrank+59,	0,		0,	
yycrank+81,	0,		0,	
yycrank+62,	0,		0,	
yycrank+65,	0,		0,	
yycrank+66,	0,		0,	
yycrank+69,	0,		0,	
yycrank+71,	0,		0,	
yycrank+81,	0,		0,	
yycrank+84,	0,		0,	
yycrank+85,	0,		0,	
yycrank+86,	0,		0,	
yycrank+87,	0,		0,	
yycrank+0,	yysvec+102,	0,	
yycrank+102,	0,		0,	
yycrank+0,	yysvec+107,	0,	
yycrank+102,	0,		0,	
yycrank+0,	yysvec+111,	0,	
yycrank+112,	0,		0,	
yycrank+136,	0,		0,	
yycrank+138,	0,		0,	
yycrank+116,	0,		0,	
yycrank+117,	0,		0,	
yycrank+122,	0,		0,	
yycrank+134,	0,		0,	
yycrank+141,	0,		0,	
yycrank+3,	0,		0,	
yycrank+136,	0,		0,	
yycrank+141,	0,		0,	
yycrank+158,	0,		0,	
yycrank+156,	0,		0,	
yycrank+143,	0,		0,	
yycrank+230,	0,		0,	
yycrank+158,	0,		0,	
yycrank+149,	0,		0,	
yycrank+162,	0,		0,	
yycrank+157,	0,		0,	
yycrank+145,	0,		0,	
yycrank+170,	0,		0,	
yycrank+0,	yysvec+168,	0,	
yycrank+158,	0,		0,	
yycrank+160,	0,		0,	
yycrank+172,	0,		0,	
yycrank+246,	0,		0,	
yycrank+172,	0,		0,	
yycrank+164,	0,		0,	
yycrank+157,	0,		0,	
yycrank+182,	0,		0,	
yycrank+0,	yysvec+177,	0,	
yycrank+178,	0,		0,	
yycrank+38,	0,		0,	
0,	0,	0};
struct yywork *yytop = yycrank+369;
struct yysvf *yybgin = yysvec+1;
char yymatch[] ={
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] ={
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*	ncform	4.1	83/08/11	*/

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank){		/* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"unsigned char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
