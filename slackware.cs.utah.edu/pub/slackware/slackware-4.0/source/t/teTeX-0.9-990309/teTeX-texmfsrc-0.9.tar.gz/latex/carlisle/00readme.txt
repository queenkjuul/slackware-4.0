
CTAN:macros/latex/contrib/supported/carlisle

This directory contains various packages that are not related to
each other except by the fact that they have the same author.

David Carlisle  david@dcarlisle.demon.co.uk

I shall add new files here from time to time, currently the directory
contains the following.

nopageno.sty
   Turn off all page numbers in standard LaTeX classes, without
   having to worry about \maketitle and friends putting them back.

ltxtable.tex
   This generates and documents the package ltxtable.sty. A merger of
   longtable and tabularx packages from the Standard LaTeX tools
   collection. This produces multipage tables in which the column
   widths are automatically calculated to achieve a specified total
   table width.

blkarray.sty
   Despite being in this `supported' directory this package is less
   supported than the others. I wrote it a long time ago. It is still
   documented using the conventions of LaTeX2.09 (although it appears
   to work with current LaTeX releases). I do not think I am going to
   be able to work on this in the foreseeable future, so have decided to
   let it out in its current state. It is not really a package for
   using in documents in its present state, but if you are interested
   in coding tables of various sorts in TeX, you may be interested to
   experiment with it...


mylatex.ltx
   This file provides a method of making a special format tailored to
   one document, with all the class and packages, and other preamble
   material pre-loaded. This can save quite a lot of time on some
   systems. See the comments in the file.


typehtml.dtx
typehtml.ins
   Typeset HTML (ie World Wide web documents) directly from LaTeX.
   Process the file html.ins to produce the html.sty package file.
   Process the file html.dtx to produce examples, documentation and
   code listings. Currently this package can handle almost all of
   HTML2, and most of the math fragment of the draft HTML3.


plain.sty
   Typeset plain TeX markup in LaTeX documents.
   Within \begin{plain} ... \end{plain} most plain TeX constructs work
   including commands such as \over which might have been disabled by
   other LaTeX packages such as amsmath.

comma.sty
   Adds a new possibility for printing counter values in addition
   to \arabic, \roman, etc.
   \commaform inserts a comma every three digits, as in 12,345.
   It may be easily customised to insert any other TeX command
   (such as a thin space `\,') instead of a comma.

colortbl.dtx
colortbl.ins
   Add colour to LaTeX tables. Requires array and color packages.
   Process colortbl.ins to produce the package file colortbl.sty.
   Process colortbl.dtx to get the documentation (this requires
   longtable hhline and dcolumn from the standard `tools'
   distribution.)

dotlessj.sty
   If you are using a font set without a dotless j (\j and \jmath) then
   this package will fake one. It requires the LaTeX color package.
   It does not require any explicit PostScript support.

textcase.dtx
textcase.ins
   \MakeTextUppercase and \MakeTextLowercase are similar to the standard
   \MakeUppercase and \MakeLowercase, but they do not change the case of
   any sections of mathematics within the argument.
   Improvements from Donald Arseneau mean that \label, \ref and \cite
   also work within the argument of these commands, without the symbolic
   `key name' being incorrectly uppercased.

remreset.sty
   \@removefromreset: a companion to the standard \@addtoreset command
   allows counters to be removed from the reset list of a controlling
   counter. For example, a class file based on book class may say
   \@removefromreset{footnote}{chapter}
   so that footnotes are no longer reset every chapter (the book class
   default).

scalefnt.sty
   \scalefont{2} selects the current font in twice the current size.
   \scalefont{.75} reduces the current font size by three quarters.

fix2col.dtx
fix2col.ins
   Two column fixes.
   a) Fix mark handling so \firstmark is taken from the first column
      if that column has marks at all.
      (A copy of Piet van Oostrum's fixmarks package, more or less.)
   b) Keep two column floats like figure* in sequence with single
      column floats like figure.
      (Modelled on  Ed Sznyter's 2.09 package, fixfloats.)

slashed.sty
   Commands for the `Feynman slashed character' notation.
