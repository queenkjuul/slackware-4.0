Adfathesis


This class modifies the standard report class to meet the requirements
of the Australian Defence Force Academy (a college of the University
of New South Wales) as given in the `University College Handbook'.
This class is ultimately derived from the old suthesis style.

The main changes in this class are firstly to use space and a half
interline spacing, except in footnote, figure and table environments
where normal spacing is used.  Secondly the chapter and section
headings are changed to be less `shouting' than the standard LaTeX
designs.  Thirdly less profligate use was made of vertical spacing.
There is more information in a short document appended to the end of
adfathesis.cls (I have not progressed to using a .dtx).

Since two sided theses are now accepted for my thesis I used the
adfathesis class with the following options:

\documentclass[a4paper,12pt,openright,twoside]{adfathesis}

As supplied adfathesis automatically uses the Harvard package and the
supplied `adfathesis.bst' is designed to work the Harvard package.  If
you wish to use a different bst, such as `plain.bst', this will not be
appropriate.  There is a class option `normalbib' which stops the
automatic use of the Harvard package, and hence allows use of either
the standard LaTeX bibliography style or an alternative package.

Stephen Harker  s-harker@adfa.edu.au
