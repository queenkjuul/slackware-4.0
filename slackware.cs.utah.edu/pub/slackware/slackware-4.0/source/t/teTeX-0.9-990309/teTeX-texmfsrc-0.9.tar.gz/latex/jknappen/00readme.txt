This directory contains packages that I have written for LaTeX. All these
packages are supported in the sense, that you can send bug reports to me.

IMPORTANT NOTICE: All those packages are (c) Copyright J"org Knappen.
They have different licences, please look into the file headers for
them. Any use which is not explicitly allowed by the licence needs my
prior consent.

Short description of the packages:

greekctr      New counterstyles \greek and \Greek
holtpolt      Non-commutative fractions
latin1jk      Special variant of latin1 to be used with the inputenc 
              package which allows verbatim setting of latin1 files
latin2jk      Special variant of latin2 to be used with the inputenc
              package which allows verbatim setting of latin2 files
latin3jk      Latin3 input encoding (esperanto) to be used with the 
              inputenc package
mathbbol      `Mengensymbole' (Blackboard bold, using Alan Jeffrey's 
              bbold fonts)
mathrsfs      Mathematical `Script' letters (as traditionally used in
              physics for Lagrangian, Hamiltonian, path integral 
              measures...)
sans          Interchanges the roles of sans serif and roman fonts 
              throughout the document (\sf produces roman)
semtrans      Support for special latin letters and diacritics used
              in transliteration of semitic languages
smartmn       Intelligent hyphen/minus, which guesses whether to render
              as hyphen or minus
tccompat      A compatibility package for users of the older versions of
              the textcomp package
young         Young tableaus


Please find the file t4enc.def and the fc fonts in directory
tex-archive/fonts/fc


January 1998

J"org Knappen
Barbarossaring 43
D-55118 Mainz
Allemagne
