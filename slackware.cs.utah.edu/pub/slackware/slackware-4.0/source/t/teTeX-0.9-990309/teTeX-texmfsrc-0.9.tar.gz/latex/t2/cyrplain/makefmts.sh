#!/bin/sh

tex -ini -fmt=cyrtex -progname=tex "cyrtex.ini \dump"
tex -ini -fmt=cyramstex -progname=amstex cyramstx.ini
tex -ini -fmt=cyrtexinfo -progname=texinfo cyrtxinf.ini
tex -ini -fmt=cyrblue -progname=tex cyrblue.ini
