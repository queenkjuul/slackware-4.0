#!/bin/sh

initex -fmt=cyrplain -progname=tex "cyrplain.ini \dump"
initex -fmt=cyramstx -progname=amstex cyramstx.ini
initex -fmt=cyrtxinf -progname=texinfo cyrtxinf.ini
initex -fmt=cyrblue -progname=tex cyrblue.ini
