if [ ! -r etc/sudoers ]; then
 mv etc/sudoers.new etc/sudoers
fi
