// dwmain.h

#define GSTEXT_ICON	50
#define GSIMAGE_ICON	51

