#ifndef __TKINFO_H
#define __TKINFO_H

void x_create_info (Dlg_head *h, widget_data parent, WInfo *info);
void x_show_info (WInfo *info, struct my_statfs *s, struct stat *b);

#endif /* __TKINFO_H */
