#ifndef __PANELIZE_H
#define __PANELIZE_H

void add2panelize_cmd (void);
void external_panelize (void);
void load_panelize (void);
void save_panelize (void);
void done_panelize (void);

#endif
