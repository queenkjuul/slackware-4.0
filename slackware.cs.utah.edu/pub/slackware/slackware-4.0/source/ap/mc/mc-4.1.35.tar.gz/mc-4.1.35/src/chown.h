#ifndef __CHOWN_H
#define __CHOWN_H

void chown_cmd (void);
void chown_advanced_cmd (void);

#endif
