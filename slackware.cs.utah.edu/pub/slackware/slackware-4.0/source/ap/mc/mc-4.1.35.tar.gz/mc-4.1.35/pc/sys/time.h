
#ifndef _SYS_TIME_H
#define _SYS_TIME_H

#ifndef _WINSOCKAPI_	  	/* winsock.h defines struct timeval */

struct timeval {
	long tv_sec;
	long tv_usec;
};

#endif 

int gettimeofday (struct timeval*, void *);

#endif
