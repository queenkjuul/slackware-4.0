( cd usr/bin ; rm -rf jove )
( cd usr/bin ; ln -sf  xjove jove )
