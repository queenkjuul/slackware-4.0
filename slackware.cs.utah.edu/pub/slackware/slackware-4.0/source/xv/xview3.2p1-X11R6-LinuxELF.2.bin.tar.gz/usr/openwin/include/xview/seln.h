/*	@(#)seln.h 20.13 93/06/28	*/

#ifndef xview_seln_DEFINED
#define xview_seln_DEFINED

/*
 *	(c) Copyright 1989 Sun Microsystems, Inc. Sun design patents 
 *	pending in the U.S. and foreign countries. See LEGAL NOTICE 
 *	file for terms of the license.
 */

/*
 ***********************************************************************
 *			Include Files
 ***********************************************************************
 */

#include <xview/sel_svc.h>
#include <xview/sel_attrs.h>

#endif /* ~xview_seln_DEFINED */
