#ifndef lint
#ifdef sccs
static char     sccsid[] = "@(#)pw_copy.c 20.13 93/06/28";
#endif
#endif

/*
 *	(c) Copyright 1989 Sun Microsystems, Inc. Sun design patents 
 *	pending in the U.S. and foreign countries. See LEGAL NOTICE 
 *	file for terms of the license.
 */

/*
 * Pw_copy.c: Implement the pw_copy functions of the pixwin.h interface.
 */
