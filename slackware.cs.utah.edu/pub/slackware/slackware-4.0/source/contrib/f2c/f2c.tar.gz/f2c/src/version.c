char F2C_version[] = "19950110";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 19950110\n";
