
/** Support for win'95 keyboard. 
 *
 * If compiled, it can be enabled/disabled in the .rc file.
 *
 * ICEWM assumes the following keyboard mappings:
 *
 * xmodmap - <<EOF
 * ! Left Window key
 * keycode 115 = Meta_L
 * ! Right Window key
 * keycode 116 = Meta_R
 * ! Menu key
 * keycode 117 = Menu
 * EOF
 *
 */
#define SUPPORT_WIN95KBD

#define MAIL_SPOOL "/var/spool/mail/"       /* '/' terminated ! */

/** Use Linux 2.0 Penguin as start button */
#define START_PIXMAP "linux.xpm"
//#define START_PIXMAP "start.xpm"
//#define START_PIXMAP "xfree86os2.xpm"

/** Show title bars at the bottom of the window */
#undef TITLEBAR_BOTTOM

/** No not include configurability of options */
#undef NO_CONFIGURE

/** Do not include configurable menus */
#undef NO_CONFIGURE_MENUS

/** No configurable window options */
#undef NO_WINDOW_OPTIONS

/* experimental: broadcast various gui events (for icesound) */
#undef CONFIG_GUIEVENTS

/* TODO */
#define CONFIG_MAILBOX_STATUS
#define CONFIG_TASKBAR
#define CONFIG_WINLIST
#define CONFIG_WORKSPACES
#define CONFIG_MWMHINTS
#define CONFIG_APPICONS

#define CONFIG_DEFAULT_LOOK lookNice
#define CONFIG_DEFAULT_THEME "nice/default"

#define CONFIG_LOOK_NICE
#define CONFIG_LOOK_WARP3
#define CONFIG_LOOK_WIN95
#define CONFIG_LOOK_WARP4
#define CONFIG_LOOK_MOTIF
