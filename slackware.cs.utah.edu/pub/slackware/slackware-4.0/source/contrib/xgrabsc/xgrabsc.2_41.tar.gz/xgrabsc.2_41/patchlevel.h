#ifndef PATCHLEVEL_H
#define PATCHLEVEL_H
/*========================================================================
*
* Name - patchlevel.h
*
* Version:	1.20
*
* ccsid:	@(#)patchlevel.h	1.20 - 11/07/95 11:31:22
* from: 	ccs/s.patchlevel.h
* date: 	11/07/95 11:31:40
*
* Copyright (C), 1990-95 Bruce Schuchardt
* See cpyright.h for full copyright information.
*  
* Description: patch level for xgrabsc
*
*========================================================================*/

/* XGRABSC_PATCHLEVEL has no bearing on the patch level for individual
 * versions.  Starting with v2.0, version minor numbers indicate the
 * patch level for a particular version.  XGRABSC_PATCHLEVEL indicates
 * the number of released patches/versions since v1.0 was released in
 * 1990.
 */

#define XGRABSC_PATCHLEVEL 13

#define XGRABSC_VERSION "2.41"
#define XGRABSC_FULL_VERSION_INFO "2.4 11/07/95 11:31:40"
#endif
