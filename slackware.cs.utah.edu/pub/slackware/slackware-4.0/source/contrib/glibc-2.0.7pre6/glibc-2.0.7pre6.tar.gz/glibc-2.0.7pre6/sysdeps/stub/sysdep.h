/* This file should contain any system-dependent types and macros
   that will be used by many parts of the library.  It should also
   contain declarations for any functions defined in sysdep.c.  */
