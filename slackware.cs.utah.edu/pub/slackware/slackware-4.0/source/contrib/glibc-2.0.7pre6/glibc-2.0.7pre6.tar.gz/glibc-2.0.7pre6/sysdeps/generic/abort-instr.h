/* We cannot give any generic instruction to crash the program.
   abort() will have to make sure it never returns.  */
