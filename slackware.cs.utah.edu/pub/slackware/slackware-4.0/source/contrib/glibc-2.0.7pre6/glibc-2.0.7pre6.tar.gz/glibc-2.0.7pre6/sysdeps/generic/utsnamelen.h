/* The size of the character arrays used to hold the information
   in a `struct utsname'.  Enlarge this as necessary.  */
#define	_UTSNAME_LENGTH	1024
