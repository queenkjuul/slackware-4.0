/* Make sure NO_WAITPID is not set; sysdeps/unix/pipestream.c defines it. */
#include <sysdeps/posix/pipestream.c>
