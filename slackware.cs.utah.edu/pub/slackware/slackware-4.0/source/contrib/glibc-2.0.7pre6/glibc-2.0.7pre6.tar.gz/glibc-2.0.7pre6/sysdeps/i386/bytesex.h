/* i386 is little-endian.  */

#define __BYTE_ORDER __LITTLE_ENDIAN
