/* An instruction which should crash any program is `hlt'.  */
#define ABORT_INSTRUCTION asm ("hlt")
