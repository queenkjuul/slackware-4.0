/* __profile_frequency is in sysdeps/mach/hurd/profil.c.  This file
is here as a place-holder to prevent the use of sysdeps/generic/prof-freq.c. */
