/* This file should at least define the testandset function as
   appropriate for the machine in question.  */

#error Machine testandset sequence unknown
