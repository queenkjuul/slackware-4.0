#include "mips/xm-mips.h"

#define USG

#if 0
#ifdef __GNUC__
/* The normal irix compiler requires alloca.h or alloca doesn't work.
   However, the IRIX compiler doesn't allow alloca to be stored in
   something like ptr->field = alloca(), so we just use the normal
   C alloca.  */
#include <alloca.h>
#endif
#endif
