/* Configuration for GCC for Motorola m68k running Linux-based GNU systems. */

#include <m68k/xm-m68k.h>
#include <xm-linux.h>
