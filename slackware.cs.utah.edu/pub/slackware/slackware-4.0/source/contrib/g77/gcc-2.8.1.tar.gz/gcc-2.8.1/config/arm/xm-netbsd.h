/* Configuration for GCC for ARM running NetBSD as host.  */

#include <arm/xm-arm.h>

#ifndef SYS_SIGLIST_DECLARED
#define SYS_SIGLIST_DECLARED
#endif
