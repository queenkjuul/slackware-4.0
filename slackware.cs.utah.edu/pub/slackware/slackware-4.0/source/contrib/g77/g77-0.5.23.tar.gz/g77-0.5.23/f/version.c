char *ffe_version_string = "0.5.23";
