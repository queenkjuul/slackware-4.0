#ifndef _H_f_version
#define _H_f_version

extern char *ffe_version_string;

#endif
