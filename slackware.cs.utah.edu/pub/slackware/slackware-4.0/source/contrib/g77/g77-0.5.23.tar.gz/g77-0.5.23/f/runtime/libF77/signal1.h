/* The g77 implementation of libf2c directly includes signal1.h0,
   instead of copying it to signal1.h, since that seems easier to
   cope with at this point.  */

#include "signal1.h0"
