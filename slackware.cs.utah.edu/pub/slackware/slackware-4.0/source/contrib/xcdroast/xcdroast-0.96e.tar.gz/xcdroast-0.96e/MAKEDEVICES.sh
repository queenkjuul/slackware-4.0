#!/bin/sh
# Creates a nice set of devices, that are not usually defined
# on most distributions
# These are absolutely conform to the linux-devices standard.

echo -n "Creating additional device-names: "

mknod /dev/sg0 c 21 0 -m 600 2>/dev/null
mknod /dev/sga c 21 0 -m 600 2>/dev/null

mknod /dev/sg1 c 21 1 -m 600 2>/dev/null
mknod /dev/sgb c 21 1 -m 600 2>/dev/null

mknod /dev/sg2 c 21 2 -m 600 2>/dev/null
mknod /dev/sgc c 21 2 -m 600 2>/dev/null

mknod /dev/sg3 c 21 3 -m 600 2>/dev/null
mknod /dev/sgd c 21 3 -m 600 2>/dev/null

mknod /dev/sg4 c 21 4 -m 600 2>/dev/null
mknod /dev/sge c 21 4 -m 600 2>/dev/null

mknod /dev/sg5 c 21 5 -m 600 2>/dev/null
mknod /dev/sgf c 21 5 -m 600 2>/dev/null

mknod /dev/sg6 c 21 6 -m 600 2>/dev/null
mknod /dev/sgg c 21 6 -m 600 2>/dev/null

mknod /dev/sg7 c 21 7 -m 600 2>/dev/null
mknod /dev/sgh c 21 7 -m 600 2>/dev/null

mknod /dev/sg8 c 21 8 -m 600 2>/dev/null
mknod /dev/sgi c 21 8 -m 600 2>/dev/null

mknod /dev/sg9 c 21 9 -m 600 2>/dev/null
mknod /dev/sgj c 21 9 -m 600 2>/dev/null

mknod /dev/sg10 c 21 10 -m 600 2>/dev/null
mknod /dev/sgk c 21 10 -m 600 2>/dev/null

mknod /dev/sg11 c 21 11 -m 600 2>/dev/null
mknod /dev/sgl c 21 11 -m 600 2>/dev/null

mknod /dev/sg12 c 21 12 -m 600 2>/dev/null
mknod /dev/sgm c 21 12 -m 600 2>/dev/null

mknod /dev/sg13 c 21 13 -m 600 2>/dev/null
mknod /dev/sgn c 21 13 -m 600 2>/dev/null

mknod /dev/sg14 c 21 14 -m 600 2>/dev/null
mknod /dev/sgo c 21 14 -m 600 2>/dev/null

mknod /dev/sg15 c 21 15 -m 600 2>/dev/null
mknod /dev/sgp c 21 15 -m 600 2>/dev/null

mknod /dev/sg16 c 21 16 -m 600 2>/dev/null
mknod /dev/sgq c 21 16 -m 600 2>/dev/null

mknod /dev/sr0 b 11 0 -m 640 2>/dev/null
mknod /dev/sr1 b 11 1 -m 640 2>/dev/null
mknod /dev/sr2 b 11 2 -m 640 2>/dev/null
mknod /dev/sr3 b 11 3 -m 640 2>/dev/null
mknod /dev/sr4 b 11 4 -m 640 2>/dev/null
mknod /dev/sr5 b 11 5 -m 640 2>/dev/null
mknod /dev/sr6 b 11 6 -m 640 2>/dev/null
mknod /dev/sr7 b 11 7 -m 640 2>/dev/null
mknod /dev/sr8 b 11 8 -m 640 2>/dev/null
mknod /dev/sr9 b 11 9 -m 640 2>/dev/null
mknod /dev/sr10 b 11 10 -m 640 2>/dev/null
mknod /dev/sr11 b 11 11 -m 640 2>/dev/null
mknod /dev/sr12 b 11 12 -m 640 2>/dev/null
mknod /dev/sr13 b 11 13 -m 640 2>/dev/null
mknod /dev/sr14 b 11 14 -m 640 2>/dev/null
mknod /dev/sr15 b 11 15 -m 640 2>/dev/null

echo "Done."

