#!/bin/sh
# the next line restarts using tixwish \
exec ../etixwish/etixwish "$0" "$@"

# Standalone loader to run X-CD-Roast without the need of a closed binary.
# Only for development, 1.6.97 T.Niederreiter

# Load other Modules

source ExternalProgs.tcl
source Icons.tcl
source GetHardwareInfo.tcl
source HandleCfgFile.tcl
source HandlePartitions.tcl
source MiscTools.tcl
source Dialog.tcl
source Messages.tcl
source HandleAudio.tcl
source MkMain.tcl
source MkSetup.tcl
source MkCopy.tcl
source MkMaster.tcl
source MkInfo.tcl
source OnLineHelp.tcl
source roastmain.tcl

