/* tty device */
/* linux	"/dev/cua1" */
/* NEWS-OS 4.2  "/dev/tty00" */
/* NEWS-OS 6.X	"/dev/term/00" */
/* EWS4800	"/dev/term/00" */
/* SunOS 4.1.4	"/dev/ttya" */
/* Solaris2.3	"/dev/ttya" */
/* BSD/OS 2.0	"/dev/tty01" */
/* FreeBSD      "/dev/cuaa0" */
/* NEXTSTEP "/dev/ttya" */
/* Windows NT "COM1" */
/* DOS "AUX1" for MLD serial driver */


#if defined(WIN32) || defined(OS2)
#define RSPORT "COM1"
#else
#ifdef DOS
#define RSPORT "AUX1"
#else
#ifdef __linux__
#define RSPORT	"/dev/cua1"
#else
#ifdef __FreeBSD__
#define RSPORT	"/dev/cuaa0"
#else
#define RSPORT	"/dev/tty01"
#endif /* FreeBSD */
#endif /* linux */
#endif /* DOS */
#endif /* WIN32 OS2 */

/* NEXTSTEP and (Old) FreeBSD cannot hold RTS to off
   so you short link cable's RTS and GND */
/* FreeBSD 2.2 Release can hold RTS to off. */
#if defined(NeXT)
#define NO_RTS
#endif 

#define	STX	0x02
#define	ETX	0x03
#define	ENQ	0x05
#define	ACK	0x06
#define	DC2	0x12
#define	NAK	0x15
#define	ETB	0x17


#define DEFAULTBAUD B9600
#define LIGHT 5
#define TOP   4
#define HIGH  3
#define MID   2
#define DEFAULT 1

#define JPEG 0
#define PPM_P 1
#define PPM_T 2
#define RGB_P 3
#define RGB_T 4
#define BMP_P 5
#define BMP_T 6
#define CAM 7

/* for function prototypes */
#ifdef STDC_HEADERS
# define P__(x) x
#else
# define P__(x) ()
#endif

void	Exit P__((int));


#define RETRY   100
#define LOW_BATT 0x3b 
#define SECTOR 0x0600

#define THUMBNAIL_WIDTH 52
#define THUMBNAIL_HEIGHT 36
#define PICTURE_WIDTH 480
#define PICTURE_HEIGHT 240
#define PICTURE_WIDTH_FINE 640
#define PICTURE_HEIGHT_FINE 480

#define THUMBNAIL_MAXSIZ 4*1024
#define	JPEG_MAXSIZ	32*1024
#define	YCC_MAXSIZ	154*1024
#define	JPEG_MAXSIZ_FINE	70*1024
#define	YCC_MAXSIZ_FINE	460*1024

#ifdef BINARYFILEMODE
#define WMODE "wb"
#define RMODE "rb"
#else
#define WMODE "w"
#define RMODE "r"
#endif

