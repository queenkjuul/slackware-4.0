void write_ppm P__((u_char *, FILE *, int, int, int, int, int, int));


