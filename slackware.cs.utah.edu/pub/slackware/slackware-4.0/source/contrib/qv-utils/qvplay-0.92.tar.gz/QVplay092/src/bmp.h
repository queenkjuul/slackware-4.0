void write_bmp P__((u_char *, FILE *, int, int, int, int));


