int	QVputcam P__((int, int, u_char * ));
int	QVputpicture P__((int, int, u_char * ));
