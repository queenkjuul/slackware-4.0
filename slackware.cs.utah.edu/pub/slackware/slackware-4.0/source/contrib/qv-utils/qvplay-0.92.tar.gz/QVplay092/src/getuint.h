u_short get_u_short P__((u_char *));
u_int get_u_int P__((u_char *));
