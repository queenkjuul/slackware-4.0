
/*
 * netatalk/endian.h
 *
 * This file is a dummy replacement for endian.h. NetBSD includes
 * machine/endian.h in sys/types.h, and it was decided that a
 * second include file was not needed. This file is included to
 * make all the source code compile correctly.
 */
