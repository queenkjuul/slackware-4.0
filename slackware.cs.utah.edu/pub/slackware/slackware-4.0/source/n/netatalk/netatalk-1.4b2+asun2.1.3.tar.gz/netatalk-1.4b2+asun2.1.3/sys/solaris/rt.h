int	rt_add( struct sockaddr_at *, struct sockaddr_at *, int );
int	rt_del( struct sockaddr_at *, struct sockaddr_at *, int );
int	rt_gate( struct sockaddr_at *, struct sockaddr_at * );
