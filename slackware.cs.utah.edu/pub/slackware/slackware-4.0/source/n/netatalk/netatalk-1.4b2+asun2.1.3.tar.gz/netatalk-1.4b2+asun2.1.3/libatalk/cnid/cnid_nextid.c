#include <db.h>

#include <atalk/adouble.h>
#include <atalk/cnid.h>

#include "cnid_private.h"

/* return the next id */
cnid_t cnid_nextid(void *CNID)
{
  CNID_private *db;
  cnid_t id;

  if (!(db = CNID)) 
    return 0;

  ad_refresh(&db->rootinfo);
  memcpy(&id, ad_entry(&db->rootinfo, ADEID_DID), sizeof(id));
  return id;
}
