#ifndef _SYS_CDEFS_H
#define _SYS_CDEFS_H 1

#ifdef __STDC__
#define __P(args)    args  
#else
#define __P(args)    ()
#endif

#endif /* sys/cdefs.h */
