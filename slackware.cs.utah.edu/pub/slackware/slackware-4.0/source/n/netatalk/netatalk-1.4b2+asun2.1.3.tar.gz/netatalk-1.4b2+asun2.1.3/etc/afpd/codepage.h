#ifndef CODEPAGE_H
#define CODEPAGE_H 1

/* 
 * header of a codepage --
 * file magic:                   2 bytes
 * file version:                 1 byte
 * size of name:                 1 byte
 * offset to data:               2 bytes
 * size of data:                 2 bytes
 * name:                         strlen(name) bytes (padded)
 * 
 * data for a version 1 codepage --
 * mac code:     1 byte
 * xlate code:   1 byte
 * ...
 */

#define CODEPAGE_FILE_ID 0xCFAF
#define CODEPAGE_FILE_VERSION 0x01
#define CODEPAGE_FILE_HEADER_SIZE 8

#endif
