#ifndef STATUS_H
#define STATUS_H 1

#include <atalk/dsi.h>
#include <atalk/asp.h>
#include "globals.h"

#define PASSWD_NONE     0
#define PASSWD_SET     (1 << 0)
#define PASSWD_NOSAVE  (1 << 1)
#define PASSWD_ALL     (PASSWD_SET | PASSWD_NOSAVE)

extern void status_versions __P((char * /*status*/));
extern void status_uams __P((char * /*status*/, const int /*authbits*/));
extern int status_init __P((void *, ASP, DSI *, const struct afp_options *));

#endif
