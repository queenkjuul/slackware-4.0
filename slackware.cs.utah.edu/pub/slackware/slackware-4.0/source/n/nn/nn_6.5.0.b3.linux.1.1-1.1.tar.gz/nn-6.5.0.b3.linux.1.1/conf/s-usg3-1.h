/*
 *	This version is for System V Release 3.1
 */

#include "s-sys5.h"
