/*
 *	This version is for Hewlett-Packard HP-UX 6.5
 *	Do they really have to screw things up in every release?
 */

#include "s-hpux.h"

#define	SIGNAL_HANDLERS_ARE_VOID	/* */

#define EXTRA_LIB	-lBSD
