/*
 *	This version is for NeXT 2.2
 *	From: lele@itnsg1.cineca.it
 */

#include "s-bsd4-3.h"

#define HAVE_STRCHR			/* */
#define COMPILER_FLAGS -O
#define EXTRA_LIB -lsys_s
#define SIGNAL_HANDLERS_ARE_VOID
