/*
 *	This version is for NeXT 1.0
 *	From: eps@cs.SFSU.EDU (Eric P. Scott)
 */

#define	USE_STRINGS_H

#include "s-bsd4-3.h"

#define HAVE_STRCHR			/* */
#define COMPILER_FLAGS -O -bsd
#define EXTRA_LIB -lsys_s
