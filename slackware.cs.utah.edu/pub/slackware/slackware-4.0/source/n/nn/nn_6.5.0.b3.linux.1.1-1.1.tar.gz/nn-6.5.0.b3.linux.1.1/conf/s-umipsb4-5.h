/*
 *	This is for Mips Risc/os 4.5 or later.
 *	Compile in the bsd43 environment.
 */

#include "s-umipsb.h"

/* 4.5 has vsprintf */
#undef NO_VARARGS

