int daemon(int, int);
