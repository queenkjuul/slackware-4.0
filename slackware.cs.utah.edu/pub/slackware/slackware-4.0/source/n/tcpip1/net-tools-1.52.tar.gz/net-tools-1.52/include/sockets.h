extern int skfd, ipx_sock, ax25_sock, rose_sock, inet_sock, inet6_sock,
 ddp_sock, ec_sock;

extern int sockets_open(int family);
