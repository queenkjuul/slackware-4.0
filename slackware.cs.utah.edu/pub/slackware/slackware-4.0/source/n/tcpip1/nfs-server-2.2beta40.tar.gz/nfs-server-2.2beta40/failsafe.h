/*
 * failsafe.h
 *
 * Fail-safe sessions
 */

#ifndef FAILSAFE_H
#define FAILSAFE_H

extern void	failsafe(int level, int ncopies);

#endif /* FAILSAFE_H */
