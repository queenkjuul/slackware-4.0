/* $Id: patchlevel.h,v 1.38 1999/03/31 06:07:59 paulus Exp $ */
#define	PATCHLEVEL	7

#define VERSION		"2.3"
#define IMPLEMENTATION	""
#define DATE		"31 March 1999"
