#include <stdio.h>

int
fnlockfile(fp)
FILE *fp;
{
	return 1;
}
