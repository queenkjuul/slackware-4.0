/* imports from history.c */
extern char *findfiles(), *gethistory();
extern boolean alreadyseen();
extern statust fakehist(), closehist();
extern void history(), histupdfiles();

#define STARTLOG YES
#define NOLOG NO
