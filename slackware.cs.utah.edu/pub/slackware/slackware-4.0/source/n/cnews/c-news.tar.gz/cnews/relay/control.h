/* imports from control.c */
extern void ctlmsg();
extern char *hackhybrid();

#define CONTROL "control"		/* control message pseudo-ng. */
