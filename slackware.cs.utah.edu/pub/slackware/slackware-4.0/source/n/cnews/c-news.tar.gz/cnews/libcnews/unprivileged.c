/*
 * default unprivileged handler - does nothing
 */

/* ARGSUSED */
void
unprivileged(reason)
char *reason;
{
}
