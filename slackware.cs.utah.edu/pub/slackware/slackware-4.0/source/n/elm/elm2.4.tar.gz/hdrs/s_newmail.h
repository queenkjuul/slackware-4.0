/* s_newmail.h created from s_newmail.us by gencat on Sat Oct  3 18:34:18 EDT 1992 */

#define NewmailSet	0xd
#define NewmailNoSubject	0x1
#define NewmailNoPasswdEntry	0x2
#define NewmailShort	0x3
#define NewmailShortPlur	0x4
#define NewmailIncommingMail	0x5
#define NewmailErrNoPerm	0x6
#define NewmailErrMaxFolders	0x7
#define NewmailInWinPriorityTo	0x8
#define NewmailInWinPriority	0x9
#define NewmailInWinTo	0xa
#define NewmailPriorityMail	0xb
#define NewmailMail	0xc
#define NewmailTo	0xd
#define NewmailFrom	0xe
#define NewmailErrFstat	0xf
#define NewmailErrUsername	0x10
#define NewmailArgsHelp1	0x11
#define NewmailArgsHelp2	0x12
#define NewmailErrExpand	0x13
