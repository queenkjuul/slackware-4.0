/* s_readmsg.h created from s_readmsg.us by gencat on Sat Oct  3 18:34:19 EDT 1992 */

#define ReadmsgSet	0x13
#define ReadmsgUsage	0x1
#define ReadmsgStateFileCorrupt	0x2
#define ReadmsgCannotExpandFolderName	0x3
#define ReadmsgCannotGetIncomingName	0x4
#define ReadmsgFolderEmpty	0x5
#define ReadmsgIDontUnderstand	0x6
#define ReadmsgCannotSeek	0x7
#define ReadmsgCannotFindStart	0x8
#define ReadmsgCannotFindMessage	0x9
#define ReadmsgOutOfMemory	0xa
