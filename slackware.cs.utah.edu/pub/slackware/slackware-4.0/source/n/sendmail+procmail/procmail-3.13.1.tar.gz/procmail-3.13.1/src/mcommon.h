/*$Id: mcommon.h,v 1.1 1994/04/05 15:35:03 berg Exp $*/

void
 qsignal P((const sig,void(*action)(void)));
