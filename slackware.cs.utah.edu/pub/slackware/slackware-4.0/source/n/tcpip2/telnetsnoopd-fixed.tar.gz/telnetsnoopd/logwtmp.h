void logwtmp(const char *_line, const char *name, const char *host);
