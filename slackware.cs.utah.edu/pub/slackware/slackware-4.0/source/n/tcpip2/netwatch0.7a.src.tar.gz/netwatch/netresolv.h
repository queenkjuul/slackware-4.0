/*	Special Struct's for NETWATCH to resolve INET addresses
	into INET Hostnames
*/

struct resolvaddr 
{
	pid_t pid;
	unsigned long inetaddr;
	char *where;
};

struct gotname
{
	char *where;
	char name[80];  /* Watch... LIMIT hardcoded... */
};

