#ifndef __YP_MSG_H__
#define __YP_MSG_H__

extern int debug_flag;

extern void yp_msg(char *, ...);

#endif
