/*
** $Id: yppush.h,v 1.1.1.1 1996/08/11 17:35:13 kukuk Exp $
*/

#ifndef __YPPUSH_H__
#define __YPPUSH_H__

extern int verbose_flag;

extern void yppush_xfrrespprog_1( struct svc_req *rqstp, SVCXPRT *transp);

#endif
