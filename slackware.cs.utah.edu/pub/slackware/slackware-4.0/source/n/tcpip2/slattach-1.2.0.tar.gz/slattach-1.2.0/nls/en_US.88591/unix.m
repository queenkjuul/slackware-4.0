$set 19  #unix

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_unix Original Message:(UNIX Domain)
# UNIX Domain

$ #_unspec Original Message:(UNSPEC)
# UNSPEC
