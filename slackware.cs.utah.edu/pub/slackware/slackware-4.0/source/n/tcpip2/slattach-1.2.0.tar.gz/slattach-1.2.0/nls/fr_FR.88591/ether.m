$set 13  #ether

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_debug1 Original Message:(in_ether(%s): invalid ether address!\n)
# in_ether(%s): Adresse Ethernet incorrecte !\n

$ #_debug2 Original Message:(in_ether(%s): invalid ether address!\n)
# in_ether(%s): Adresse Ethernet incorrecte !\n

$ #_debug3 Original Message:(in_ether(%s): trailing : ignored!\n)
# in_ether(%s): le reste est ignor� !\n

$ #_debug4 Original Message:(in_ether(%s): trailing junk!\n)
# in_ether(%s): le reste est d�truit !\n

$ #_ether Original Message:(10Mbps Ethernet)
# Ethernet � 10Mbps

