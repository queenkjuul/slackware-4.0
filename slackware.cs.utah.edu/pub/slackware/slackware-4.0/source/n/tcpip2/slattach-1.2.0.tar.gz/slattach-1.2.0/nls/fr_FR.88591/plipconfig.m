$set 6  #plipconfig

$ #_usage1 Original Message:(Usage: plipconfig [-a] [-i] [-v] interface\n)
# Syntaxe: plipconfig [-a] [-i] [-v] interface\n

$ #_usage2 Original Message:(                  [nibble NN] [trigger NN]\n)
#                     [nibble NN] [trigger NN]\n

$ #_plip Original Message:(%s\tnibble %lu  trigger %lu\n)
# %s\tdigit %lu  d�clenchement %lu\n
