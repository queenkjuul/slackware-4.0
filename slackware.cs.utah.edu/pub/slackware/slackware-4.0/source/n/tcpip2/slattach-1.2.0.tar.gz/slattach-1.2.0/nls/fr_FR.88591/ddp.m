$set 12  #ddp

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_ddp Original Message:(Appletalk DDP)
# DDP Appletalk 

