/* DateSize.h */

time_t UnLSDate(char *);
time_t UnMDTMDate(char *);
long GetDateSizeFromLSLine(char *, time_t *);
long GetDateAndSize(char *, time_t *);
