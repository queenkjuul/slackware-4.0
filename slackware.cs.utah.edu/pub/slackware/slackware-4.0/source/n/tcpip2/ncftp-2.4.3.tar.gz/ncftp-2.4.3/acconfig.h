#undef MORE

#undef ZCAT

#undef GZCAT

#undef UNAME

#undef LS

#undef HAVE_LIBCURSES
#undef HAVE_LIBNCURSES
#undef HAVE_LIBREADLINE
#undef HAVE_LIBTERMCAP

/* This can be one of kSendPortMode (0), kPassiveMode (1) or
 * kFallBackToSendPortMode (2).
 *
 * Example: #define FTP_DATA_PORT_MODE 2
 */
#undef FTP_DATA_PORT_MODE

#undef CAN_USE_SYS_SELECT_H

#undef HAVE_MAXX
#undef HAVE__MAXX

/* Define if <sys/select.h> exists, and is compatible with <sys/time.h>. */
#undef CAN_USE_SYS_SELECT_H

/* Define to 1 if ANSI function prototypes are usable.  */
#undef PROTOTYPES
