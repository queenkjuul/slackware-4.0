/* Getpass.h */

#ifndef _getpass_h_
#define _getpass_h_

void GetPass(char *promptstr, char *answer, size_t siz);
void Echo(FILE *fp, int on);

#endif	/* _getpass_h_ */

/* eof Getpass.h */
