/* Version.h */

#define kVersion "2.4.3"
#define kVersionDate "March 19, 1998"
#define kAlpha 0
#define kBeta 0
