#ifndef LYMAINLOOP_H
#define LYMAINLOOP_H

#include <HTUtils.h>

extern void LYCloseTracelog NOPARAMS;
extern int mainloop NOPARAMS;

#endif /* LYMAINLOOP_H */
