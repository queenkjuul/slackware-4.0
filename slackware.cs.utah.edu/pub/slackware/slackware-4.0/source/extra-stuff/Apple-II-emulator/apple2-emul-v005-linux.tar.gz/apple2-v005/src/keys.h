/*
 *  Apple II emulator by Alexander Jean-Claude Bottema (C) 1994
 *
 *  $Id: keys.h,v 1.2 1997/02/03 02:36:42 chernabog Exp $
 *
 **/

#define SCODE_L_CTRL	29
#define SCODE_R_CTRL 	97
#define SCODE_L_SHIFT	42
#define SCODE_R_SHIFT	54
#define SCODE_CAPS	58
#define SCODE_J_U	72
#define SCODE_J_D	80
#define SCODE_J_L	75
#define SCODE_J_R	77
#define SCODE_REP	26

#define F1	256
#define F2	257
#define F3	258
#define F4	259
#define F5	260
#define	F6	261
#define F7	262
#define F8	263
#define F9	264
#define F10	265
#define F11	266
#define F12	267
#define RST	268
#define J_U	269
#define J_D	270
#define J_L	271
#define J_R	272
#define JUL	273
#define JUR	274
#define JDL	275
#define JDR	276
#define JB0	277
#define JB1	278
#define JB2	282
#define S_D	279
#define S_I	280
#define J_C	281
#define BOT     283
#define REP	284
