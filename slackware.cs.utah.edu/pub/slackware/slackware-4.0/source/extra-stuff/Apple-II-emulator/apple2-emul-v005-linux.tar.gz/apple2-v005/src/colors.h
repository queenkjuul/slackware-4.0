/*
 *  Apple II emulator by Alexander Jean-Claude Bottema (C) 1994
 *
 *  $Id: colors.h,v 1.3 1997/11/09 06:21:07 chernabog Exp $
 *
 **/

#define COLOR_BLACK		0

#define COLOR_DARK_RED		35
#define COLOR_MEDIUM_RED	36
#define COLOR_LIGHT_RED		37	/* hgr used */

#define COLOR_DARK_GREEN	38
#define COLOR_MEDIUM_GREEN	39
#define COLOR_LIGHT_GREEN	40	/* hgr used */

#define COLOR_DARK_YELLOW	41
#define COLOR_MEDIUM_YELLOW	42
#define COLOR_LIGHT_YELLOW	43

#define COLOR_DARK_BLUE		44
#define COLOR_MEDIUM_BLUE	45
#define COLOR_LIGHT_BLUE	46	/* hgr used */

#define COLOR_DARK_PURPLE	47
#define COLOR_MEDIUM_PURPLE	48
#define COLOR_LIGHT_PURPLE	49	/* hgr used */

#define COLOR_DARK_CYAN		50
#define COLOR_MEDIUM_CYAN	51
#define COLOR_LIGHT_CYAN	52

#define COLOR_DARK_WHITE	53
#define COLOR_MEDIUM_WHITE	54
#define COLOR_LIGHT_WHITE	55

#define COLOR_FLASHING_BLACK	56
#define COLOR_FLASHING_WHITE	57
#define COLOR_FLASHING_UNGREEN	58
#define COLOR_FLASHING_GREEN	59
