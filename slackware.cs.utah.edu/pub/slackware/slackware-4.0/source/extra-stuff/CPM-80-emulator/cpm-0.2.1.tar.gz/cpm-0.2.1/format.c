#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int kb;
    char buff[1024];
    if (argc != 2) {
	fprintf(stderr, "usage: format (kb)\n");
	exit(1);
    }
    kb = atoi(argv[1]);
    memset(buff, 0xe5, 1024);
    if (kb > 0 && kb <= 1504)
	while (kb--)
	    fwrite(buff, 1, 1024, stdout);
    return 0;
}
