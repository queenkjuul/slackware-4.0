typedef struct ToggleType {
	char       *name;
	char       *help;
	int         value;
} ToggleType;
