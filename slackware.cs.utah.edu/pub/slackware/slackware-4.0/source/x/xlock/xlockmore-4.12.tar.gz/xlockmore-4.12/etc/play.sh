#!/bin/sh
cat $1 > /dev/audio
