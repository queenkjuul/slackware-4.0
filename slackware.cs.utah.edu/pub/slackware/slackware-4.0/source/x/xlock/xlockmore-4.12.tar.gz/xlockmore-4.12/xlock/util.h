extern unsigned long seconds(void);

#if ( !HAVE_STRDUP )
extern char *strdup(char *);

#endif
