/* Include prototypes for all files */
/*
 * $Id: protos.h,v 1.7 1998/10/24 10:22:45 mason Exp $
 */
#include "command.extpro"
#include "graphics.extpro"
#include "grkelot.extpro"
#ifdef UTMP_SUPPORT
#include "logging.extpro"
#endif
#include "main.extpro"
#include "menubar.extpro"
#include "misc.extpro"
#ifdef DISPLAY_IS_IP
#include "netdisp.extpro"
#endif
#ifndef NO_RMEMSET
#include "rmemset.extpro"
#endif
#include "screen.extpro"
#include "scrollbar.extpro"
#include "xdefaults.extpro"
#include "xpm.extpro"
