#ifdef XPM_BACKGROUND
# ifdef XPM_INC_X11
#  include <X11/xpm.h>
# else
#  include <xpm.h>
# endif
#endif

typedef struct {
    short           w, h, x, y;
    Pixmap          pixmap;
} bgPixmap_t;

#include "xpm.intpro"		/* PROTOS for internal routines */
