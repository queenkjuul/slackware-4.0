int CORE = 1;
int FUNCTIONS = 1;
int X11 = 1;
int FVWM = 1;
int CONFIG = 1;
int WINLIST = 1;
int MEM = 1;
