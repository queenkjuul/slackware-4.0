/**
 *
 * $Header: /cvsroot/hungry/lesstif/lib/Xm-2.0/RenderTable.c,v 1.1 1998/04/23 22:27:35 u27113 Exp $
 *
 * Copyright (C) 1998 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/

static char rcsid[] = "$Header: /cvsroot/hungry/lesstif/lib/Xm-2.0/RenderTable.c,v 1.1 1998/04/23 22:27:35 u27113 Exp $";

#include <Xm/Xm.h>

XmRenderTable
XmRenderTableAddRenditions(
		XmRenderTable	oldtable,
		XmRendition	*renditions,
		Cardinal	rendition_count,
		XmMergeMode	merge_mode)
{
	return NULL;
}

XmRenderTable
XmRenderTableCopy(
		XmRenderTable	table,
		XmStringTag	*tags,
		int		tag_count)
{
	return NULL;
}

XmRenderTable
XmRenderTableCvtFromProp(
		Widget		widget,
		char		*property,
		unsigned int	length)
{
	return NULL;
}

unsigned int
XmRenderTableCvtToProp(
		Widget		widget,
		XmRenderTable	table,
		char		**prop_return)
{
	return 0;
}

void
XmRenderTableFree(XmRenderTable table)
{
}

XmRendition
XmRenderTableGetRendition(
		XmRenderTable	table,
		XmStringTag	tag)
{
	return NULL;
}

XmRendition *
XmRenderTableGetRenditions(
		XmRenderTable	table,
		XmStringTag	*tags,
		Cardinal	tag_count)
{
	return NULL;
}

int
XmRenderTableGetTags(
		XmRenderTable	table,
		XmStringTag	**tag_list)
{
	return 0;
}

XmRenderTable
XmRenderTableRemoveRenditions(
		XmRenderTable	oldtable,
		XmStringTag	*tags,
		int		tag_count)
{
	return NULL;
}

Boolean
XmeRenderTableGetDefaultFont(
		XmRenderTable	renderTable,
		XFontStruct	**fontStruct)
{
	return False;
}
