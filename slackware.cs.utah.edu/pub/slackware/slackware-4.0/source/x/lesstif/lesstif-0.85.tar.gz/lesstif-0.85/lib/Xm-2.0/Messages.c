/**
 *
 * Copyright (C) 1997 Peter G. Williams, and Others
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/

#include <Xm/XmP.h>
#include <XmI/MessagesI.h>

_XmConst char *XME_WARNING =
    "XmeWarning";

_XmConst char *_XmMsgBaseClass_0000 =
    "No context found for extension";

_XmConst char *_XmMsgBaseClass_0001 =
    "_XmPopWidgetExtData; no extension found with XFindContext";

_XmConst char *_XmMsgBaseClass_0002 =
    "XmFreeWidgetExtData is an unsupported routine";

_XmConst char *_XmMsgBulletinB_0001 =
    "Incorrect dialog style; must be XmDIALOG_MODELESS.";

_XmConst char *_XmMsgCSText_0000 =
    "Invalid margin height; must be greater than or equal to 0.";

_XmConst char *_XmMsgCSText_0001 =
    "Invalid margin width; must be greater than or equal to  0.";

_XmConst char *_XmMsgCSText_0002 =
    "Invalid edit mode.";

_XmConst char *_XmMsgCSText_0003 =
    "xmNtraversalOn must always be true.";

_XmConst char *_XmMsgCSText_0004 =
    "Cannot change XmNscrollHorizontal after initialization";

_XmConst char *_XmMsgCSText_0005 =
    "Cannot change XmNscrollVertical after initialization";

_XmConst char *_XmMsgCSText_0006 =
    "Cannot change XmNscrollTopSide after initialization";

_XmConst char *_XmMsgCSText_0007 =
    "Cannot change XmNscrollLeftSide after initialization";

_XmConst char *_XmMsgCascadeB_0000 =
    "XmCascadeButton[Gadget] must have XmRowColumn parent with \n"
    "XmNrowColumnType XmMENU_PULLDOWN, XmMENU_POPUP, XmMENU_BAR or XmMENU_OPTION.";

_XmConst char *_XmMsgCascadeB_0001 =
    "Only XmRowColumn widgets of type XmMENU_PULLDOWN can be submenus.";

_XmConst char *_XmMsgCascadeB_0002 =
    "XmNmappingDelay must be greater than or equal to 0.";

_XmConst char *_XmMsgCascadeB_0003 =
    "XtGrabPointer failed";

_XmConst char *_XmMsgComboBox_0000 =
    "Applications cannot add children to XmComboBox widgets.";

_XmConst char *_XmMsgComboBox_0001 =
    "XmNcomboBoxType resource cannot be set by XtSetValues.";

_XmConst char *_XmMsgComboBox_0002 =
    "XmFontListGetNextFont failed.";

_XmConst char *_XmMsgComboBox_0003 =
    "XmFontListInitFontContext failed.";

_XmConst char *_XmMsgComboBox_0004 =
    "Internal widget has been destroyed.  Behavior is undefined";

_XmConst char *_XmMsgComboBox_0005 =
    "Internal widget has been unmanaged.  Behavior is undefined";

_XmConst char *_XmMsgComboBox_0006 =
    "XmQUICK_NAVIGATE is only valid for ComboBoxes of XmNcomboBoxType XmDROP_DOWN_LIST";

_XmConst char *_XmMsgComboBox_0007 =
    "Action invoked with the wrong number of parameters.";

_XmConst char *_XmMsgComboBox_0008 =
    "Action routine called from a widget that is not a descendant of ComboBox";

_XmConst char *_XmMsgCommand_0000 =
    "The dialog type must be XmDIALOG_COMMAND.";

_XmConst char *_XmMsgCommand_0001 =
    "Invalid child type; Command widget does not have this child.";

_XmConst char *_XmMsgCommand_0002 =
    "NULL or empty XmString";

_XmConst char *_XmMsgCommand_0003 =
    "NULL or empty XmString passed to XmCommandAppendValue.";

_XmConst char *_XmMsgCommand_0004 =
    "XmNmustMatch is always False for a Command widget.";

_XmConst char *_XmMsgCommand_0005 =
    "XmNhistoryMaxItems must be a positive integer greater than zero.";

_XmConst char *_XmMsgContainer_0000 =
    "Action invoked with the wrong number of parameters.";

_XmConst char *_XmMsgCutPaste_0000 =
    "Must call XmClipboardStartCopy() before XmClipboardCopy()";

_XmConst char *_XmMsgCutPaste_0001 =
    "Must call XmClipboardStartCopy() before XmClipboardEndCopy()";

_XmConst char *_XmMsgCutPaste_0002 =
    "Too many formats in XmClipboardCopy()";

_XmConst char *_XmMsgCutPaste_0003 =
    "ClipboardBadDataType";

_XmConst char *_XmMsgCutPaste_0004 =
    "bad data type";

_XmConst char *_XmMsgCutPaste_0005 =
    "ClipboardCorrupt";

_XmConst char *_XmMsgCutPaste_0006 =
    "internal error - corrupt data structure";

_XmConst char *_XmMsgCutPaste_0007 =
    "ClipboardBadFormat";

_XmConst char *_XmMsgCutPaste_0008 =
    "Error - registered format length must be 8, 16, or 32";

_XmConst char *_XmMsgCutPaste_0009 =
    "Error - registered format name must be nonnull";

_XmConst char *_XmMsgDialogS_0000 =
    "DialogShell widget only supports one RectObj child";

_XmConst char *_XmMsgDisplay_0001 =
    "Creating multiple XmDisplays for the same X display.  Only the\n"
    "first XmDisplay created for a particular X display can be referenced\n"
    "by calls to XmGetXmDisplay";

_XmConst char *_XmMsgDisplay_0002 =
    "Received TOP_LEVEL_LEAVE with no active DragContext";

_XmConst char *_XmMsgDisplay_0003 =
    "Cannot set XmDisplay class to a non-subclass of XmDisplay";

_XmConst char *_XmMsgDragBS_0000 =
    "_MOTIF_DRAG_WINDOW property has been destroyed";

_XmConst char *_XmMsgDragBS_0001 =
    "The protocol version levels do not match.";

_XmConst char *_XmMsgDragBS_0002 =
    "Unable to open display.";

_XmConst char *_XmMsgDragBS_0003 =
    "The atom table is empty.";

_XmConst char *_XmMsgDragBS_0004 =
    "The target table is empty.";

_XmConst char *_XmMsgDragBS_0005 =
    "The target table has an inconsistent property.";

_XmConst char *_XmMsgDragBS_0006 =
    "Invalid target table index.";

_XmConst char *_XmMsgDragC_0001 =
    "GenerateCallback does not expect XmCR_DROP_SITE_ENTER as a reason";

_XmConst char *_XmMsgDragC_0002 =
    "Invalid selection in DropConvertCallback";

_XmConst char *_XmMsgDragC_0003 =
    "The drop selection was lost.";

_XmConst char *_XmMsgDragC_0004 =
    "XGrabPointer failed";

_XmConst char *_XmMsgDragC_0005 =
    "ExternalNotifyHandler: the callback reason is not acceptable";

_XmConst char *_XmMsgDragC_0006 =
    "XmDragStart must be called as a result of a button press or motion event";

_XmConst char *_XmMsgDragICC_0000 =
    "Unknown drag and drop message type";

_XmConst char *_XmMsgDragICC_0001 =
    "The protocol version levels do not match.";

_XmConst char *_XmMsgDragIcon_0000 =
    "No geometry specified for dragIcon pixmap";

_XmConst char *_XmMsgDragIcon_0001 =
    "A dragIcon created with no pixmap";

_XmConst char *_XmMsgDragIcon_0002 =
    "String to Bitmap converter needs Screen argument";

_XmConst char *_XmMsgDragOverS_0000 =
    "Depth mismatch";

_XmConst char *_XmMsgDragOverS_0001 =
    "Unknown icon attachment";

_XmConst char *_XmMsgDragOverS_0002 =
    "Unknown drag state";

_XmConst char *_XmMsgDragOverS_0003 =
    "Unknown XmNblendModel";

_XmConst char *_XmMsgDragUnder_0000 =
    "Unable to get drop site window geometry";

_XmConst char *_XmMsgDragUnder_0001 =
    "Invalid animationPixmapDepth";

_XmConst char *_XmMsgDropSMgrI_0001 =
    "Cannot register a drop site that is a descendent of a simple drop site";

_XmConst char *_XmMsgDropSMgrI_0002 =
    "Cannot create a discontiguous child list for a composite drop site.";

_XmConst char *_XmMsgDropSMgrI_0003 =
    "%s is not a drop site child of %s";

_XmConst char *_XmMsgDropSMgr_0001 =
    "Cannot create drop sites that are children of a simple drop site.";

_XmConst char *_XmMsgDropSMgr_0002 =
    "Receiving motion events without an active drag context";

_XmConst char *_XmMsgDropSMgr_0003 =
    "Receiving operation changed without an active drag context.";

_XmConst char *_XmMsgDropSMgr_0004 =
    "Creating an active drop site with no drop procedure.";

_XmConst char *_XmMsgDropSMgr_0005 =
    "Cannot set rectangles or number of rectangles of composite drop sites.";

_XmConst char *_XmMsgDropSMgr_0006 =
    "Registering a widget as a drop site out of sequence.\n"
    "Ancestors must be registered before any of their \n"
    "descendants are registered.";

_XmConst char *_XmMsgDropSMgr_0007 =
    "Cannot register widget as a drop site more than once.";

_XmConst char *_XmMsgDropSMgr_0008 =
    "Drop site type may only be set at creation time.";

_XmConst char *_XmMsgDropSMgr_0009 =
    "Cannot change rectangles of non-simple drop site.";

_XmConst char *_XmMsgDropSMgr_0010 =
    "Cannot register a shell as a drop site.";

_XmConst char *_XmMsgForm_0000 =
    "Fraction base cannot be zero.";

_XmConst char *_XmMsgForm_0002 =
    "Circular dependency in Form children.";

_XmConst char *_XmMsgForm_0003 =
    "Bailed out of edge synchronization after 10,000 iterations.\n"
    "Check for contradictory constraints on the children of this form.";

_XmConst char *_XmMsgForm_0004 =
    "Attachment widget must have same parent as widget.";

_XmConst char *_XmMsgGadget_0000 =
    "Cannot change XmNlayoutDirection after initialization.";

_XmConst char *_XmMsgGeoUtils_0000 =
    "Failure of geometry request to \"almost\" reply";

_XmConst char *_XmMsgGeoUtils_0001 =
    "Invalid layout of children found";

_XmConst char *_XmMsgGeoUtils_0002 =
    "Invalid order found in XmSelectionBox";

_XmConst char *_XmMsgGetSecRes_0000 =
    "getLabelSecResData: Not enough memory";

_XmConst char *_XmMsgGrabS_0000 =
    "XmPopup requires a subclass of shellWidgetClass.";

_XmConst char *_XmMsgLabel_0003 =
    "Invalid XmNlabelString - must be a compound string";

_XmConst char *_XmMsgLabel_0004 =
    "Invalid XmNacceleratorText - must be a compound string";

_XmConst char *_XmMsgList_0000 =
    "When changed, XmNvisibleItemCount must be at least 1.";

_XmConst char *_XmMsgList_0005 =
    "Cannot change XmNlistSizePolicy after initialization.";

_XmConst char *_XmMsgList_0006 =
    "When changed, XmNitemCount must be nonnegative.";

_XmConst char *_XmMsgList_0007 =
    "Item(s) to be deleted are not present is list.";

_XmConst char *_XmMsgList_0008 =
    "XmNlistSpacing must be nonnegative.";

_XmConst char *_XmMsgList_0009 =
    "Cannot set XmNitems to NULL when XmNitemCount is positive.";

_XmConst char *_XmMsgList_0010 =
    "When changed, XmNselectedItemCount must be nonnegative.";

_XmConst char *_XmMsgList_0011 =
    "Cannot set XmNselectedItems to NULL when XmNselectedItemCount is positive.";

_XmConst char *_XmMsgList_0012 =
    "XmNtopItemPosition must be nonnegative.";

_XmConst char *_XmMsgList_0013 =
    "XmNitems and XmNitemCount mismatch!";

_XmConst char *_XmMsgList_0014 =
    "When changed, XmNselectedPositionCount must be nonnegative.";

_XmConst char *_XmMsgList_0015 =
    "Cannot set XmNselectedPositions to NULL when XmNselectedPositionCount is positive.";

_XmConst char *_XmMsgMainW_0000 =
    "The Menu Bar cannot be changed to NULL.";

_XmConst char *_XmMsgMainW_0001 =
    "The Command Window cannot be changed to NULL.";

_XmConst char *_XmMsgManager_0000 =
    "Widget class %s has invalid CompositeClassExtension record";

_XmConst char *_XmMsgManager_0001 =
    "Cannot change XmNlayoutDirection or XmNstringDirection after initialization.";

_XmConst char *_XmMsgMenuShell_0000 =
    "MenuShell widgets only accept XmRowColumn children.";

_XmConst char *_XmMsgMenuShell_0001 =
    "Attempting to manage a pulldown menu that is not attached \n"
    "to a cascade button.";

_XmConst char *_XmMsgMenuShell_0002 =
    "XmPopup requires a subclass of shellWidgetClass";

_XmConst char *_XmMsgMenuShell_0003 =
    "XmPopdown requires a subclass of shellWidgetClass";

_XmConst char *_XmMsgMenuShell_0004 =
    "XtMenuPopup wants exactly one argument";

_XmConst char *_XmMsgMenuShell_0005 =
    "XtMenuPopup only supports on ButtonPress, KeyPress or EnterNotify events.";

_XmConst char *_XmMsgMenuShell_0006 =
    "Cannot find popup widget \"%s\" in XtMenuPopup";

_XmConst char *_XmMsgMenuShell_0007 =
    "Cannot find popup widget \"%s\" in XtMenuPopdown";

_XmConst char *_XmMsgMenuShell_0008 =
    "XtMenuPopdown called with more than one argument";

_XmConst char *_XmMsgMenuShell_0009 =
    "Cannot change XmNlayoutDirection after initialization.";

_XmConst char *_XmMsgMessageB_0003 =
    "Invalid child type; widget does not have this child";

_XmConst char *_XmMsgMessageB_0004 =
    "Cancel button cannot be changed directly.";

_XmConst char *_XmMsgMotif_0000 =
    "\n"
    "Name: %s\n"
    "Class: %s\n"
    "";

_XmConst char *_XmMsgMotif_0001 =
    "Action invoked with the wrong number of parameters.";

_XmConst char *_XmMsgNavigMap_0000 =
    "_XmNavigate called with invalid direction";

_XmConst char *_XmMsgNotebook_0000 =
    "XmNnotebookChildType resource cannot be set by XtSetValues.";

_XmConst char *_XmMsgPanedW_0000 =
    "Invalid minimum value; must be greater than 0.";

_XmConst char *_XmMsgPanedW_0001 =
    "Invalid maximum value; must be greater than 0.";

_XmConst char *_XmMsgPanedW_0002 =
    "Invalid minimum/maximum value, minimum must be < maximum.";

_XmConst char *_XmMsgPanedW_0003 =
    "Constraints do not allow appropriate sizing.";

_XmConst char *_XmMsgPanedW_0004 =
    "Too few parameters in sash callback.";

_XmConst char *_XmMsgPanedW_0005 =
    "Invalid first parameter in sash callback.";

_XmConst char *_XmMsgPixConv_0000 =
    "Wrong number of parameters for CvtStringToPixmap";

_XmConst char *_XmMsgPrimitive_0000 =
    "Cannot change XmNlayoutDirection after initialization.";

_XmConst char *_XmMsgProtocols_0000 =
    "Widget must be a vendor shell";

_XmConst char *_XmMsgProtocols_0001 =
    "Protocol manager already exists.";

_XmConst char *_XmMsgProtocols_0002 =
    "There are more protocols than widget can handle";

_XmConst char *_XmMsgRegion_0000 =
    "Memory error";

_XmConst char *_XmMsgRepType_0001 =
    "Illegal representation type id";

_XmConst char *_XmMsgRepType_0002 =
    "Illegal value (%d) for rep type XmR%s";

_XmConst char *_XmMsgResConvert_0000 =
    "FetchUnitType: bad widget class";

_XmConst char *_XmMsgResConvert_0001 =
    "Improperly defined default list! exiting...";

_XmConst char *_XmMsgResConvert_0002 =
    "Missing colon in font string \"%s\"; any remaining fonts in list unparsed";

_XmConst char *_XmMsgResConvert_0003 =
    "Invalid delimiter in tag \"%s\"; any remaining fonts in list unparsed";

_XmConst char *_XmMsgResConvert_0004 =
    "Unmatched quotation marks in string \"%s\"; any remaining fonts in list unparsed";

_XmConst char *_XmMsgResConvert_0005 =
    "Unmatched quotation marks in tag \"%s\"; any remaining fonts in list unparsed";

_XmConst char *_XmMsgResConvert_0006 =
    "Null tag found when converting to type %s; any remaining fonts in list unparsed";

_XmConst char *_XmMsgResConvert_0007 =
    "Cannot convert XmString to compound text";

_XmConst char *_XmMsgResConvert_0008 =
    "Insufficient memory for XmbTextListToTextProperty";

_XmConst char *_XmMsgResConvert_0009 =
    "Locale not supported for XmbTextListToTextProperty";

_XmConst char *_XmMsgResConvert_0010 =
    "XmbTextListToTextProperty failed";

_XmConst char *_XmMsgResConvert_0011 =
    "Cannot convert widget name to Widget.";

_XmConst char *_XmMsgResConvert_0012 =
    "Cannot convert compound text to XmString";

_XmConst char *_XmMsgResConvert_0013 =
    "Cannot convert XmString to compound text";

_XmConst char *_XmMsgResConvert_0014 =
    "FetchUnitType called without a widget to reference";

_XmConst char *_XmMsgResConvert_0015 =
    "FetchDisplayArg called without a widget to reference";

_XmConst char *_XmMsgResConvert_0016 =
    "FetchWidgetArg called without a widget to reference";

_XmConst char *_XmMsgRowColText_0024 =
    "XtGrabKeyboard failed";

_XmConst char *_XmMsgRowColumn_0000 =
    "Attempt to set width to zero ignored";

_XmConst char *_XmMsgRowColumn_0001 =
    "Attempt to set height to zero ignored";

_XmConst char *_XmMsgRowColumn_0002 =
    "XmNhelpWidget not used by popup menus: forced to NULL";

_XmConst char *_XmMsgRowColumn_0003 =
    "XmNhelpWidget not used by pulldown menus: forced to NULL";

_XmConst char *_XmMsgRowColumn_0004 =
    "XmNhelpWidget not used by option menus: forced to NULL";

_XmConst char *_XmMsgRowColumn_0005 =
    "XmNhelpWidget not used by work areas: forced to NULL";

_XmConst char *_XmMsgRowColumn_0007 =
    "Widget hierarchy not appropriate for this XmNrowColumnType:\n"
    "defaulting to XmWORK_AREA";

_XmConst char *_XmMsgRowColumn_0008 =
    "Attempt to change XmNrowColumnType after initialization ignored";

_XmConst char *_XmMsgRowColumn_0015 =
    "Attempt to set XmNisHomogenous to FALSE for a RowColumn widget of type XmMENU_BAR ignored";

_XmConst char *_XmMsgRowColumn_0016 =
    "Attempt to change XmNentryClass for a RowColumn widget of type XmMENU_BAR ignored";

_XmConst char *_XmMsgRowColumn_0017 =
    "Attempt to change XmNwhichButton via XtSetValues for a RowColumn widget of type XmMENU_PULLDOWN ignored";

_XmConst char *_XmMsgRowColumn_0018 =
    "Attempt to change XmNmenuPost via XtSetValues for a RowColumn widget of type XmMENU_PULLDOWN ignored";

_XmConst char *_XmMsgRowColumn_0019 =
    "Attempt to set XmNmenuPost to an illegal value ignored";

_XmConst char *_XmMsgRowColumn_0020 =
    "Attempt to change XmNshadowThickness for a RowColumn widget not of type XmMENU_PULLDOWN or XmMENU_POPUP ignored";

_XmConst char *_XmMsgRowColumn_0022 =
    "Attempt to add wrong type child to a menu (that is, XmRowColumn) widget";

_XmConst char *_XmMsgRowColumn_0023 =
    "Attempt to add wrong type child to a homogeneous RowColumn widget";

_XmConst char *_XmMsgRowColumn_0025 =
    "Attempt to change XmNisHomogeneous for a RowColumn widget of type XmMENU_OPTION ignored";

_XmConst char *_XmMsgRowColumn_0026 =
    "Tear off enabled on a shared menupane: allowed but not recommended";

_XmConst char *_XmMsgRowColumn_0027 =
    "Illegal mnemonic character;  Could not convert X KEYSYM to a keycode";

_XmConst char *_XmMsgScaleScrBar_0004 =
    "Incorrect processing direction.";

_XmConst char *_XmMsgScale_0000 =
    "The scale minumum value is greater than or equal to the scale maximum value.";

_XmConst char *_XmMsgScale_0001 =
    "The specified scale value is less than the minimum scale value.";

_XmConst char *_XmMsgScale_0002 =
    "The specified scale value is greater than the maximum scale value.";

_XmConst char *_XmMsgScale_0005 =
    "Invalid highlight thickness.";

_XmConst char *_XmMsgScale_0006 =
    "Invalid XmNscaleMultiple; greater than (max - min)";

_XmConst char *_XmMsgScale_0007 =
    "Invalid XmNscaleMultiple; less than zero";

_XmConst char *_XmMsgScale_0008 =
    "(Maximum - minimum) cannot be greater than INT_MAX / 2;\n"
    "minimum has been set to zero, maximum may have been set to (INT_MAX/2).";

_XmConst char *_XmMsgScale_0009 =
    "XmNshowValue has an incorrect value";

_XmConst char *_XmMsgScreen_0000 =
    "Icon screen mismatch";

_XmConst char *_XmMsgScreen_0001 =
    "Cannot get XmScreen because XmDisplay was not found.";

_XmConst char *_XmMsgScrollBar_0000 =
    "The scrollbar minimum value is greater than or equal to\n"
    "the scrollbar maximum value.";

_XmConst char *_XmMsgScrollBar_0001 =
    "The specified slider size is less than 1";

_XmConst char *_XmMsgScrollBar_0002 =
    "The specified scrollbar value is less than the minimum\n"
    "scrollbar value.";

_XmConst char *_XmMsgScrollBar_0003 =
    "The specified scrollbar value is greater than the maximum\n"
    "scrollbar value minus the scrollbar slider size.";

_XmConst char *_XmMsgScrollBar_0004 =
    "The scrollbar increment is less than 1.";

_XmConst char *_XmMsgScrollBar_0005 =
    "The scrollbar page increment is less than 1.";

_XmConst char *_XmMsgScrollBar_0006 =
    "The scrollbar initial delay is less than 1.";

_XmConst char *_XmMsgScrollBar_0007 =
    "The scrollbar repeat delay is less than 1.";

_XmConst char *_XmMsgScrollBar_0008 =
    "Specified slider size is greater than the scrollbar maximum\n"
    "value minus the scrollbar minimum value.";

_XmConst char *_XmMsgScrollFrameT_0000 =
    "AssocNavigator requires a navigator trait";

_XmConst char *_XmMsgScrollFrameT_0001 =
    "DeAssocNavigator requires a navigator trait";

_XmConst char *_XmMsgScrollVis_0000 =
    "Wrong parameters passed to the XmScrollVisible function.";

_XmConst char *_XmMsgScrolledW_0004 =
    "Cannot change scrolling policy after initialization.";

_XmConst char *_XmMsgScrolledW_0005 =
    "Cannot change visual policy after initialization.";

_XmConst char *_XmMsgScrolledW_0006 =
    "Cannot set AS_NEEDED scrollbar policy with a\n"
    "visual policy of VARIABLE.";

_XmConst char *_XmMsgScrolledW_0007 =
    "Cannot change scrollbar widget in AUTOMATIC mode.";

_XmConst char *_XmMsgScrolledW_0008 =
    "Cannot change clip window";

_XmConst char *_XmMsgScrolledW_0009 =
    "Cannot set visual policy of CONSTANT in APPLICATION_DEFINED mode.";

_XmConst char *_XmMsgSelectioB_0001 =
    "Dialog type cannot be modified.";

_XmConst char *_XmMsgSelectioB_0002 =
    "Invalid child type; widget does not have this child.";

_XmConst char *_XmMsgSpinB_0001 =
    "Invalid value for XmNarrowLayout.";

_XmConst char *_XmMsgSpinB_0002 =
    "XmNminimumValue equals XmNmaximumValue.";

_XmConst char *_XmMsgSpinB_0003 =
    "No items supplied for XmSTRING child.";

_XmConst char *_XmMsgSpinB_0004 =
    "XmNincrementValue cannot be 0. A value of 1 will be used.";

_XmConst char *_XmMsgSpinB_0005 =
    "Spin direction specified by XmNincrementValue\n"
    "has been reversed to match the specified\n"
    "XmNminimumValue and XmNmaximumValue.";

_XmConst char *_XmMsgSpinB_0006 =
    "XmNposition out of range; minimum XmNposition used.";

_XmConst char *_XmMsgSpinB_0007 =
    "XmNposition out of range; maximum XmNposition used.";

_XmConst char *_XmMsgTextFWcs_0000 =
    "Character '%s' not supported in font.  Discarded.";

_XmConst char *_XmMsgTextFWcs_0001 =
    "Cannot use multibyte locale without a fontset.  Value discarded.";

_XmConst char *_XmMsgTextF_0000 =
    "Invalid cursor position; must be greater than or equal to 0.";

_XmConst char *_XmMsgTextF_0001 =
    "Invalid number of columns; must be greater than 0.";

_XmConst char *_XmMsgTextF_0002 =
    "XmFontListInitFontContext failed.";

_XmConst char *_XmMsgTextF_0003 =
    "XmFontListGetNextFont failed.";

_XmConst char *_XmMsgTextF_0004 =
    "Character '%s' not supported in font.  Discarded.";

_XmConst char *_XmMsgTextF_0005 =
    "XmNtraversalOn must always be true.";

_XmConst char *_XmMsgTextF_0006 =
    "Invalid number of columns; must be greater than or equal to 0.";

_XmConst char *_XmMsgTextIn_0000 =
    "Cannot find position while attempting to move to previous line.";

_XmConst char *_XmMsgTextOut_0000 =
    "Invalid rows; must be greater than 0";

_XmConst char *_XmMsgText_0000 =
    "Invalid source; source ignored.";

_XmConst char *_XmMsgText_0002 =
    "Text widget is editable; XmNtraversalOn must be true.";

_XmConst char *_XmMsgTransfer_0000 =
    "Calling SelectionCallbackWrapper when transfers should be finished";

_XmConst char *_XmMsgTransfer_0001 =
    "Cannot lock the clipboard; aborting transfer";

_XmConst char *_XmMsgTransfer_0002 =
    "The format and type of the callback supplied data does not match the data being merged";

_XmConst char *_XmMsgTransfer_0003 =
    "The status in the XmConvertCallbackStruct is not XmCONVERT_MERGE";

_XmConst char *_XmMsgTransfer_0004 =
    "CONVERT_MORE is not yet supported";

_XmConst char *_XmMsgTransfer_0005 =
    "Bad atom value found";

_XmConst char *_XmMsgTransfer_0006 =
    "Warning: Attempt to start a MULTIPLE transfer when one is in progress";

_XmConst char *_XmMsgTransfer_0007 =
    "Warning: Attempt to send a MULTIPLE transfer when one is not in progress";

_XmConst char *_XmMsgVaSimple_0000 =
    "XtVaTypedArg conversion needs nonnull widget handle";

_XmConst char *_XmMsgVaSimple_0001 =
    "Unable to find type of resource for conversion";

_XmConst char *_XmMsgVaSimple_0002 =
    "Type conversion failed";

_XmConst char *_XmMsgVendorE_0000 =
    "String to noop conversion needs no extra arguments";

_XmConst char *_XmMsgVendorE_0005 =
    "FetchUnitType called without a widget to reference";

_XmConst char *_XmMsgVendor_0000 =
    "Invalid value for XmNdeleteResponse";

_XmConst char *_XmMsgVendor_0001 =
    "Invalid value for XmNinputPolicy";

_XmConst char *_XmMsgVendor_0002 =
    "XmNlayoutDirection cannot be changed";

_XmConst char *_XmMsgVendor_0003 =
    "Fatal: \n"
    "_XmGetDefaultDisplay cannot be used prior to VendorS.Initialize, returns NULL";

_XmConst char *_XmMsgVisual_0000 =
    "Invalid color requested from _XmAccessColorData";

_XmConst char *_XmMsgVisual_0001 =
    "Cannot allocate colormap entry for default background";

_XmConst char *_XmMsgVisual_0002 =
    "Cannot parse default background color specification";

_XmConst char *_XmMsgXmIm_0000 =
    "Cannot open input method - using XLookupString";

_XmConst char *_XmMsgXmRenderT_0000 =
    "XmNtag cannot be NULL.  Setting to empty string.";

_XmConst char *_XmMsgXmRenderT_0001 =
    "Display is NULL.  Cannot load font.";

_XmConst char *_XmMsgXmRenderT_0002 =
    "XmNfontType invalid.  Cannot load font.";

_XmConst char *_XmMsgXmRenderT_0003 =
    "Conversion failed.  Cannot load font.";

_XmConst char *_XmMsgXmRenderT_0004 =
    "XmNfontType set to XmAS_IS.  Cannot load font.";

_XmConst char *_XmMsgXmRenderT_0005 =
    "XmNloadModel is XmLOAD_IMMEDIATE but XmNfont and XmNfontName not specified.\n"
    "Cannot load font.";

_XmConst char *_XmMsgXmSelect_0000 =
    "Internal error: no selection property context for display";

_XmConst char *_XmMsgXmSelect_0001 =
    "Selection owner returned type INCR property with format != 32";

_XmConst char *_XmMsgXmSelect_0002 =
    "XtGetSelectionRequest called for widget \"%s\" outside of ConvertSelection proc";

_XmConst char *_XmMsgXmString_0000 =
    "No font found.";

_XmConst char *_XmMsgXmTabList_0000 =
    "Tab value cannot be negative.";

