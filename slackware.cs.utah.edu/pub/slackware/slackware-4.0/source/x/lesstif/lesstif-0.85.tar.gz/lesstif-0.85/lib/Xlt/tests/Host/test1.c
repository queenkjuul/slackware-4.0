#include <Host.h>
#include <Xm/LabelP.h>
#include <Xm/Label.h>
#include <stdio.h>

void debug()
{
}

static void
InputCallback(Widget W, String client_data, XltHostCallbackStruct *call_data)
{
	printf("InputCallback(%s,%s,%i)\n", XtName(W),client_data,call_data->len);
}

static void
BinaryInputCallback(Widget W, String client_data, XltHostCallbackStruct *call_data)
{
	printf("BinaryInputCallback(%s,%s,%i)\n", XtName(W),client_data,call_data->len);
}

static void
AsciiInputCallback(Widget W, String client_data, XltHostCallbackStruct *call_data)
{
	printf("AsciiInputCallback(%s,%s,%s)\n", XtName(W),client_data,call_data->data);
}

static void
Callback(Widget W)
{
	printf("ConnectCallback(%s)\n", XtName(W));
	XltHostSendString(W, "ID?");
}

char *Program = "";
int
main(int argc, char **argv)
{
  Widget toplevel, one;
  Widget Host;
  XtAppContext app;

  XtSetLanguageProc(NULL, NULL, NULL);

  toplevel = XtVaAppInitialize(&app, "Label", NULL, 0, &argc, argv, NULL, NULL);

  one = XtVaCreateManagedWidget("OneLittleOldLabel", xmLabelWidgetClass, toplevel,
				NULL);

  Host = XltCreateHost(toplevel, "Host", NULL, 0);
  XtVaSetValues(Host,
  	NULL);
  XtAddCallback(Host, XltNconnectCallback, (void *)Callback, NULL);
  XtAddCallback(Host, XltNasciiInputCallback, (void *)AsciiInputCallback, NULL);
  XtAddCallback(Host, XltNbinaryInputCallback, (void *)BinaryInputCallback, NULL);
  XtAddCallback(Host, XltNinputCallback, (void *)InputCallback, NULL);
  XtRealizeWidget(toplevel);
  {
  String port;

  	XtVaGetValues(Host,
  		XltNport, &port,
  		NULL);
  	printf("PORT >%s<\n",port);
  }
  XtAppMainLoop(app);

  exit(0);
}
