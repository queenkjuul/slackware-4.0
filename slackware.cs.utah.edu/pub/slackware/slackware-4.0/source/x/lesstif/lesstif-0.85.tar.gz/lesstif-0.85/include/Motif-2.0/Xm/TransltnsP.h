/**
 *
 * $Id: TransltnsP.h,v 1.2 1997/07/03 00:53:42 miers Exp $
 * 
 * Copyright (C) 1995 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/
#ifndef XM_TRANSLTNSP_H
#define XM_TRANSLTNSP_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _XmConst
#define _XmConst
#endif

extern _XmConst char _XmArrowB_defaultTranslations[];
extern _XmConst char _XmBulletinB_defaultTranslations[];
extern _XmConst char _XmCascadeB_menubar_events[];
extern _XmConst char _XmCascadeB_p_events[];
extern _XmConst char _XmClipWindowTranslationTable[];
extern _XmConst char _XmComboBox_defaultTranslations[];
extern _XmConst char _XmComboBox_defaultAccelerators[];
extern _XmConst char _XmComboBox_dropDownComboBoxAccelerators[];
extern _XmConst char _XmComboBox_dropDownListTranslations[];
extern _XmConst char _XmComboBox_textFocusTranslations[];
extern _XmConst char _XmContainer_defaultTranslations[];
extern _XmConst char _XmContainer_traversalTranslations[];
extern _XmConst char _XmCSText_EventBindings1[];
extern _XmConst char _XmCSText_EventBindings2[];
extern _XmConst char _XmCSText_EventBindings3[];
extern _XmConst char _XmDragC_defaultTranslations[];
extern _XmConst char _XmDrawingA_defaultTranslations[];
extern _XmConst char _XmDrawingA_traversalTranslations[];
extern _XmConst char _XmDrawnB_defaultTranslations[];
extern _XmConst char _XmFrame_defaultTranslations[];
extern _XmConst char _XmGrabShell_translations[];
extern _XmConst char _XmLabel_defaultTranslations[];
extern _XmConst char _XmLabel_menuTranslations[];
extern _XmConst char _XmLabel_menu_traversal_events[];
extern _XmConst char _XmList_ListXlations1[];
extern _XmConst char _XmList_ListXlations2[];
extern _XmConst char _XmManager_managerTraversalTranslations[];
extern _XmConst char _XmManager_defaultTranslations[];
extern _XmConst char _XmMenuShell_translations [];
extern _XmConst char _XmNotebook_manager_translations[];
extern _XmConst char _XmNotebook_TabAccelerators[];
extern _XmConst char _XmPrimitive_defaultTranslations[];
extern _XmConst char _XmPushB_defaultTranslations[];
extern _XmConst char _XmPushB_menuTranslations[];
extern _XmConst char _XmRowColumn_menu_traversal_table[];
extern _XmConst char _XmRowColumn_bar_table[];
extern _XmConst char _XmRowColumn_option_table[];
extern _XmConst char _XmRowColumn_menu_table[];
extern _XmConst char _XmSash_defTranslations[];
extern _XmConst char _XmScrollBar_defaultTranslations[];
extern _XmConst char _XmScrolledW_ScrolledWindowXlations[];

/* REMARK: In Motif 2.0 _XmScrolledW_ClipWindowTranslationTable is missing. */

extern _XmConst char _XmScrolledW_ClipWindowTranslationTable[];

/* REMARK: In Motif 2.0 _XmScrolledW_WorkWindowTranslationTable is missing. */

extern _XmConst char _XmScrolledW_WorkWindowTranslationTable[];

extern _XmConst char _XmSelectioB_defaultTextAccelerators[];
extern _XmConst char _XmSpinB_defaultTranslations[];
extern _XmConst char _XmSpinB_defaultAccelerators[];
extern _XmConst char _XmTearOffB_overrideTranslations[];
extern _XmConst char _XmTextF_EventBindings1[];
extern _XmConst char _XmTextF_EventBindings2[]; 
extern _XmConst char _XmTextF_EventBindings3[];
extern _XmConst char _XmTextIn_XmTextEventBindings1[];
extern _XmConst char _XmTextIn_XmTextEventBindings2[];
extern _XmConst char _XmTextIn_XmTextEventBindings3[];
extern _XmConst char _XmTextIn_XmTextEventBindings3[];
extern _XmConst char _XmToggleB_defaultTranslations[];
extern _XmConst char _XmToggleB_menuTranslations[];
extern _XmConst char _XmVirtKeys_fallbackBindingString[];

/* The following keybindings have been provided for backward compatability. */

extern _XmConst char _XmVirtKeys_acornFallbackBindingString[];
extern _XmConst char _XmVirtKeys_apolloFallbackBindingString[];
extern _XmConst char _XmVirtKeys_dgFallbackBindingString[];
extern _XmConst char _XmVirtKeys_decFallbackBindingString[];
extern _XmConst char _XmVirtKeys_dblclkFallbackBindingString[];
extern _XmConst char _XmVirtKeys_hpFallbackBindingString[];
extern _XmConst char _XmVirtKeys_ibmFallbackBindingString[];
extern _XmConst char _XmVirtKeys_ingrFallbackBindingString[];
extern _XmConst char _XmVirtKeys_megatekFallbackBindingString[];
extern _XmConst char _XmVirtKeys_motorolaFallbackBindingString[];
extern _XmConst char _XmVirtKeys_sgiFallbackBindingString[];
extern _XmConst char _XmVirtKeys_siemensWx200FallbackBindingString[];
extern _XmConst char _XmVirtKeys_siemens9733FallbackBindingString[];
extern _XmConst char _XmVirtKeys_sunFallbackBindingString[];
extern _XmConst char _XmVirtKeys_tekFallbackBindingString[];

#ifdef __cplusplus
}
#endif

#endif /* XM_TRANSLTNSP_H */

