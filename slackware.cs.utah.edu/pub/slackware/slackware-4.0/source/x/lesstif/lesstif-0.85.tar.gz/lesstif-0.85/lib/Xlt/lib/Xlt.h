#ifndef _XRWS_H
#define _XRWS_H
/*
	$Id: Xlt.h,v 1.1 1998/06/03 21:55:11 rwscott Exp $
*/

#include <X11/IntrinsicP.h>

#ifdef __cplusplus
extern "C" {
#endif

void XltDisplayFallbackResources(char **Fallback);
void XltDisplayOptions(XrmOptionDescRec *opTable, int num_options);
Boolean XltYesNo(Widget w, String Question);
Boolean XltWorking(Widget w, String Question, int PercentDone);
void XltWaitTillMapped(Widget w);
void XltSetClientIcon(Widget W, char **icon);
Widget XltToolBarAddItem(Widget ToolBar, char *Label, char **PixmapData);
void XltRedirectStdErr(Widget Parent);
void XltSelectDebugLevel(Widget W, int *DebugLevelPtr, XmPushButtonCallbackStruct *reason);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration which encloses file. */
#endif

#endif
