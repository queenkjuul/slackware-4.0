#define cursorm_width 4
#define cursorm_height 4
static unsigned char cursorm_bits[] =
{
  0x0f, 0x0f, 0x0f, 0x0f};
