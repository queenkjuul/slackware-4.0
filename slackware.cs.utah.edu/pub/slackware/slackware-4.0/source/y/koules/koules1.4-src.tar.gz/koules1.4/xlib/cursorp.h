#define cursorp_width 4
#define cursorp_height 4
static unsigned char cursorp_bits[] =
{
  0x09, 0x00, 0x00, 0x09};
