/* This copyright is only for sound servers
   For the copyright of koules sources see README

   Note: sound server was taken from xgalaga by Joe Rumsey, who took it
   from paradise nettrek client. It is covered by the following copyright

   Copyright (C) 1995 S. M. Patel (smpatel@wam.umd.edu)

   Permission to use, copy, modify, and distribute this
   software and its documentation for any purpose and without
   fee is hereby granted, provided that the above copyright
   notice appear in all copies and that both that copyright
   notice and this permission notice appear in supporting
   documentation.  No representations are made about the
   suitability of this software for any purpose.  It is
   provided "as is" without express or implied warranty.

 */
