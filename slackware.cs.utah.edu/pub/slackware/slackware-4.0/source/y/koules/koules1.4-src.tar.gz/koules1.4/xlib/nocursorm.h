#define nocursorm_width 1
#define nocursorm_height 1
static unsigned char nocursorm_bits[] =
{
  0x00};
