// Copyright 1994 Brad Pitzel
//
// Feel free to use/distribute/modify as long as credit for myself 
// and contributors are included.
//

// File   : ObjTools.c[1.1]
// Name   : (null)
// Status : saved
// Changed: Sun Jun 12 23:15:10 1994

#include "ObjTools.h"

FixedPoint Trajectory::VFmaxx = 0;
FixedPoint Trajectory::VFmaxy = 0;

// set the trajectory towards point (Fxp,Fyp)
void Trajectory::towards( FixedPoint Fxp, FixedPoint Fyp, 
				 FixedPoint Fspeed )
	{
	int dx,dy;
	int dist;
	
	dx = FP2INT( Fxp - VFx );
	dy = FP2INT( Fyp - VFy );
	dist = (int)sqrt( dx*dx+dy*dy );

	VFxvel = Fspeed*dx/dist;
	VFyvel = Fspeed*dy/dist;
	}
