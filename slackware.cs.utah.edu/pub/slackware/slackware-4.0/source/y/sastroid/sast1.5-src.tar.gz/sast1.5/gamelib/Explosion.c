// Copyright 1994 Brad Pitzel
//
// Feel free to use/distribute/modify as long as credit/copyrights for myself 
// are included.

// File   : Explosion.c[1.0]
// Name   : gamelib1.0
// Status : proposed
// Changed: Sun Jun 12 22:19:10 1994


#include "Explosion.h"

////////////////////////////////////////////////////////////////////////////
SimpleExpl::SimpleExpl( FixedPoint Fxp, FixedPoint Fyp, int size, int dur,
		        FixedPoint Fxv, FixedPoint Fyv )
		        : Vsize(size), Life(dur)
	{
	if (Vsize > BMAX) Vsize=BMAX;

	register int i;
	
	for(i=0; i<Vsize; i++)
		{
		Vbit[i].setFpos(Fxp,Fyp);
		Vbit[i].randomDir( INT2FP((rand()>>2)&63 + 24)>>4 );
		Vbit[i].addVel( Fxv, Fyv );
		Vbit[i].Vcolor = ((rand()&255)>127) ? 254 : 253;
		}
	}

