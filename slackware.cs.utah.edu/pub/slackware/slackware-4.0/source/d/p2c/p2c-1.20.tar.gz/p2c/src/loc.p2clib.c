
/* Put p2c runtime features local to your system here.
 * In particular, additional initialization may be provided by defining
 * the symbol LOCAL_INIT when you compile p2clib.c.
 */

