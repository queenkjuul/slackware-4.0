/* Linked with objcopy.o to flag that this program is 'objcopy' (not
   'strip'). */

int is_strip = 0;
