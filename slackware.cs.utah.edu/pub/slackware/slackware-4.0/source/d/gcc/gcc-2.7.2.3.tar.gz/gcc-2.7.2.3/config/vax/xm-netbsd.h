#include <vax/xm-vax.h>
#include <xm-netbsd.h>
