#
# LynxOS hints
#
# These hints were submitted by:
#   Greg Seibert
#   seibert@Lynx.COM
#

cc='gcc'
so='none'
usemymalloc='n'
