
static object LI1();
static L3();
static L5();
static object LI1();
static struct { short n,allow_other_keys;object *defaults;
	 KEYTYPE keys[5];} LI1key={5,0,Cstd_key_defaults,{(void *)40,(void *)41,(void *)6,(void *)5,(void *)4}};
#define VMB1 register object *base=vs_top; object Vcs[10];
#define VMS1  register object *sup=vs_top+6;vs_top=sup;
#define VMV1 vs_reserve(6);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top; object  V33 ,V32 ,V31 ,V30 ,V29 ,V27 ,V26 ,V25 ,V21;
#define VMS2  register object *sup=vs_top+6;vs_top=sup;
#define VMV2 vs_reserve(6);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
#define VC3 object  V56 ,V55 ,V54 ,V53 ,V52 ,V51 ,V50 ,V48 ,V46 ,V43;
static object LI4();
#define VMB4 register object *base=vs_top; object  V94 ,V93 ,V90 ,V89 ,V88 ,V82 ,V81 ,V80 ,V74;
#define VMS4  register object *sup=vs_top+6;vs_top=sup;
#define VMV4 vs_reserve(6);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
#define VC5 object  V118 ,V117 ,V116 ,V114 ,V111 ,V106 ,V105 ,V104 ,V103;
static object LI6();
#define VMB6 register object *base=vs_top; object  V130 ,V129 ,V128;
#define VMS6  register object *sup=vs_top+4;vs_top=sup;
#define VMV6 vs_reserve(4);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V139;
#define VMS7 vs_top += 1;
#define VMV7 vs_reserve(1);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static object LI8();
#define VMB8 register object *base=vs_top; object  V146;
#define VMS8 vs_top += 1;
#define VMV8 vs_reserve(1);
#define VMR8(VMT8) vs_top=base ; return(VMT8);
static object LI9();
#define VMB9 register object *base=vs_top; object  V155;
#define VMS9 vs_top += 1;
#define VMV9 vs_reserve(1);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top; object  V172 ,V171 ,V170 ,V167 ,V166 ,V162 ,V161;
#define VMS10 vs_top += 5;
#define VMV10 vs_reserve(5);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
#define VM10 5
#define VM9 1
#define VM8 1
#define VM7 1
#define VM6 4
#define VM5 6
#define VM4 6
#define VM3 7
#define VM2 6
#define VM1 6
static char * VVi[69]={
#define Cdata VV[68]
(char *)(LI1),
(char *)(&LI1key),
(char *)(LI2),
(char *)(L3),
(char *)(LI4),
(char *)(L5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10)
};
#define VV ((object *)VVi)
static object  LnkTLI67() ;
static object  (*LnkLI67)() = LnkTLI67;
static object  LnkTLI66() ;
static object  (*LnkLI66)() = LnkTLI66;
static object  LnkTLI65() ;
static object  (*LnkLI65)() = LnkTLI65;
static object  LnkTLI64() ;
static object  (*LnkLI64)() = LnkTLI64;
static object  LnkTLI63() ;
static object  (*LnkLI63)() = LnkTLI63;
static object  LnkTLI62() ;
static object  (*LnkLI62)() = LnkTLI62;
static object  LnkTLI61() ;
static object  (*LnkLI61)() = LnkTLI61;
static object  LnkTLI60() ;
static object  (*LnkLI60)() = LnkTLI60;
static object  LnkTLI59() ;
static object  (*LnkLI59)() = LnkTLI59;
static  LnkT58() ;
static  (*Lnk58)() = LnkT58;
static object  LnkTLI57() ;
static object  (*LnkLI57)() = LnkTLI57;
static object  LnkTLI56() ;
static object  (*LnkLI56)() = LnkTLI56;
static object  LnkTLI55() ;
static object  (*LnkLI55)() = LnkTLI55;
static object  LnkTLI54() ;
static object  (*LnkLI54)() = LnkTLI54;
static object  LnkTLI53() ;
static object  (*LnkLI53)() = LnkTLI53;
static object  LnkTLI52() ;
static object  (*LnkLI52)() = LnkTLI52;
static object  LnkTLI51() ;
static object  (*LnkLI51)() = LnkTLI51;
static object  LnkTLI50() ;
static object  (*LnkLI50)() = LnkTLI50;
static  LnkT49() ;
static  (*Lnk49)() = LnkT49;
static object  LnkTLI48() ;
static object  (*LnkLI48)() = LnkTLI48;
static object  LnkTLI47() ;
static object  (*LnkLI47)() = LnkTLI47;
static object  LnkTLI46() ;
static object  (*LnkLI46)() = LnkTLI46;
static  LnkT45() ;
static  (*Lnk45)() = LnkT45;
static object  LnkTLI44() ;
static object  (*LnkLI44)() = LnkTLI44;
static object  LnkTLI43() ;
static object  (*LnkLI43)() = LnkTLI43;
static object  LnkTLI42() ;
static object  (*LnkLI42)() = LnkTLI42;
