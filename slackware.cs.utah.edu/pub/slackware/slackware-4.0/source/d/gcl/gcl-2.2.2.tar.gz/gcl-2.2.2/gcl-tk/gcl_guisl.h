
static L1();
static L2();
static char * VVi[2]={
#define Cdata VV[1]
(char *)(L1),
(char *)(L2)
};
#define VV ((object *)VVi)
