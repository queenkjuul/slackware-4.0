/* define the following if you want a type of stream
   which the user can define */

#define USER_DEFINED_STREAMS
  
/* define to enable multiprocessing:  Currently requires
   mat'l not yet in the distribution */

/* #define KCLOVM */

/*  include a couple of constant manipulation routines for maxima */
#define CMAC 

/* When a stack overflow occurs (STACK_OVER)*..GETA will be added to the stack
   to handle debugging */
#define STACK_OVER 3






