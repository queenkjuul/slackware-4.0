
static L1();
static object LI2();
static L3();
static object LI6();
static object LI7();
static L11();
static L12();
static L13();
static L14();
static L15();
static L19();
#define VC1
static object LI2();
#define VMB2 register object *base=vs_top; object  V5; object Vcs[2];
#define VMS2  register object *sup=vs_top+3;vs_top=sup;
#define VMV2 vs_reserve(3);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
#define VC3
static object LI4();
#define VMB4 register object *base=vs_top;
#define VMS4  register object *sup=vs_top+6;vs_top=sup;
#define VMV4 vs_reserve(6);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top;
#define VMS5  register object *sup=vs_top+6;vs_top=sup;
#define VMV5 vs_reserve(6);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V23; object Vcs[2];
#define VMS6  register object *sup=vs_top+3;vs_top=sup;
#define VMV6 vs_reserve(3);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V29; object Vcs[2];
#define VMS7  register object *sup=vs_top+3;vs_top=sup;
#define VMV7 vs_reserve(3);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static object LI8();
#define VMB8 register object *base=vs_top;
#define VMS8  register object *sup=vs_top+5;vs_top=sup;
#define VMV8 vs_reserve(5);
#define VMR8(VMT8) vs_top=base ; return(VMT8);
static object LI9();
#define VMB9 register object *base=vs_top;
#define VMS9  register object *sup=vs_top+4;vs_top=sup;
#define VMV9 vs_reserve(4);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top;
#define VMS10  register object *sup=vs_top+3;vs_top=sup;
#define VMV10 vs_reserve(3);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
#define VC11 object  V43 ,V42 ,V41 ,V40;
#define VC12 object  V50 ,V49 ,V48 ,V47;
#define VC13 object  V56 ,V55 ,V54;
#define VC14 object  V62 ,V61 ,V60;
#define VC15
static object LI16();
#define VMB16 register object *base=vs_top; object  V73 ,V71 ,V70;
#define VMS16  register object *sup=vs_top+4;vs_top=sup;
#define VMV16 vs_reserve(4);
#define VMR16(VMT16) vs_top=base ; return(VMT16);
static object LI17();
#define VMB17 register object *base=vs_top; object  V83 ,V81;
#define VMS17  register object *sup=vs_top+4;vs_top=sup;
#define VMV17 vs_reserve(4);
#define VMR17(VMT17) vs_top=base ; return(VMT17);
static object LI18();
#define VMB18 register object *base=vs_top; object  V99 ,V98 ,V96 ,V95;
#define VMS18  register object *sup=vs_top+4;vs_top=sup;
#define VMV18 vs_reserve(4);
#define VMR18(VMT18) vs_top=base ; return(VMT18);
#define VC19 object  V104 ,V103;
static object LI20();
#define VMB20
#define VMS20
#define VMV20
#define VMR20(VMT20) return(VMT20);
static object LI21();
#define VMB21 register object *base=vs_top;
#define VMS21  register object *sup=vs_top+1;vs_top=sup;
#define VMV21 vs_reserve(1);
#define VMR21(VMT21) vs_top=base ; return(VMT21);
#define VM21 1
#define VM20 0
#define VM19 6
#define VM18 4
#define VM17 4
#define VM16 4
#define VM15 5
#define VM14 7
#define VM13 7
#define VM12 7
#define VM11 7
#define VM10 3
#define VM9 4
#define VM8 5
#define VM7 3
#define VM6 3
#define VM5 6
#define VM4 6
#define VM3 6
#define VM2 3
#define VM1 4
static char * VVi[66]={
#define Cdata VV[65]
(char *)(L1),
(char *)(LI2),
(char *)(L3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10),
(char *)(L11),
(char *)(L12),
(char *)(L13),
(char *)(L14),
(char *)(L15),
(char *)(LI16),
(char *)(LI17),
(char *)(LI18),
(char *)(L19),
(char *)(LI20),
(char *)(LI21)
};
#define VV ((object *)VVi)
static object  LnkTLI64() ;
static object  (*LnkLI64)() = LnkTLI64;
static  LnkT63() ;
static  (*Lnk63)() = LnkT63;
static  LnkT62() ;
static  (*Lnk62)() = LnkT62;
static object  LnkTLI61() ;
static object  (*LnkLI61)() = LnkTLI61;
static  LnkT60() ;
static  (*Lnk60)() = LnkT60;
static object  LnkTLI59() ;
static object  (*LnkLI59)() = LnkTLI59;
static object  LnkTLI58() ;
static object  (*LnkLI58)() = LnkTLI58;
