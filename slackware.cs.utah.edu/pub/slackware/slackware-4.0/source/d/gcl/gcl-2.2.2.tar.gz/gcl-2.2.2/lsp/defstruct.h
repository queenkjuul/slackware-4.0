
static object LI1();
static object LI10();
static L11();
static object LI12();
static L15();
static object LI1();
#define VMB1 register object *base=vs_top; object  V36 ,V35 ,V33 ,V31 ,V30 ,V28 ,V27; object Vcs[12];
#define VMS1  register object *sup=vs_top+4;vs_top=sup;
#define VMV1 vs_reserve(4);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top; object  V85 ,V79 ,V73 ,V64 ,V56;
#define VMS2  register object *sup=vs_top+4;vs_top=sup;
#define VMV2 vs_reserve(4);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top;
#define VMS3  register object *sup=vs_top+1;vs_top=sup;
#define VMV3 vs_reserve(1);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top; object  V114 ,V113 ,V112 ,V111 ,V110 ,V109 ,V106 ,V105;
#define VMS4  register object *sup=vs_top+1;vs_top=sup;
#define VMV4 vs_reserve(1);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top;
#define VMS5  register object *sup=vs_top+2;vs_top=sup;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V150 ,V149 ,V147 ,V146 ,V145 ,V143 ,V142 ,V140;
#define VMS6  register object *sup=vs_top+4;vs_top=sup;
#define VMV6 vs_reserve(4);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V171 ,V170 ,V169 ,V165 ,V164;
#define VMS7  register object *sup=vs_top+2;vs_top=sup;
#define VMV7 vs_reserve(2);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static int LI8();
#define VMB8 register object *base=vs_top;
#define VMS8  register object *sup=vs_top+2;vs_top=sup;
#define VMV8 vs_reserve(2);
#define VMR8(VMT8) vs_top=base ; return(VMT8);
static object LI9();
#define VMB9 register object *base=vs_top; object  V220 ,V219 ,V218 ,V217 ,V216 ,V213 ,V203 ,V201;
#define VMS9  register object *sup=vs_top+3;vs_top=sup;
#define VMV9 vs_reserve(3);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top; object  V263 ,V260 ,V254 ,V253; object Vcs[14];
#define VMS10  register object *sup=vs_top+7;vs_top=sup;
#define VMV10 vs_reserve(7);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
#define VC11 object  V321 ,V320 ,V316 ,V315 ,V314 ,V311 ,V308 ,V307 ,V306 ,V302 ,V301 ,V300 ,V298 ,V297 ,V296 ,V293 ,V292 ,V291 ,V290;
static object LI12();
static object VK12defaults[18]={(void *)-2,(void *)145,(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)145,(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)-2};
static struct { short n,allow_other_keys;object *defaults;
	 KEYTYPE keys[18];} LI12key={18,0,VK12defaults,{(void *)80,(void *)77,(void *)78,(void *)76,(void *)75,(void *)79,(void *)146,(void *)70,(void *)69,(void *)68,(void *)74,(void *)73,(void *)71,(void *)72,(void *)147,(void *)67,(void *)66,(void *)65}};
#define VMB12 register object *base=vs_top; object Vcs[36];
#define VMS12  register object *sup=vs_top+19;vs_top=sup;
#define VMV12 vs_reserve(19);
#define VMR12(VMT12) vs_top=base ; return(VMT12);
static object LI13();
#define VMB13 object  V347;
#define VMS13
#define VMV13
#define VMR13(VMT13) return(VMT13);
static object LI14();
#define VMB14
#define VMS14
#define VMV14
#define VMR14(VMT14) return(VMT14);
#define VC15 object  V365;
static LC20();
#define VC16
static LC19();
#define VC17
static LC18();
#define VC18
static LC17();
#define VC19
static LC16();
#define VC20
static LC20();
static LC19();
static LC18();
static LC17();
static LC16();
#define VM20 3
#define VM19 3
#define VM18 2
#define VM17 2
#define VM16 3
#define VM15 9
#define VM14 0
#define VM13 0
#define VM12 19
#define VM11 18
#define VM10 7
#define VM9 3
#define VM8 2
#define VM7 2
#define VM6 4
#define VM5 2
#define VM4 1
#define VM3 1
#define VM2 4
#define VM1 4
static char * VVi[151]={
#define Cdata VV[150]
(char *)(LI1),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10),
(char *)(L11),
(char *)(LI12),
(char *)(&LI12key),
(char *)(LI13),
(char *)(LI14),
(char *)(L15),
(char *)(&LC19)
};
#define VV ((object *)VVi)
static  LnkT149() ;
static  (*Lnk149)() = LnkT149;
static  LnkT148() ;
static  (*Lnk148)() = LnkT148;
static object  LnkTLI144() ;
static object  (*LnkLI144)() = LnkTLI144;
static object  LnkTLI143() ;
static object  (*LnkLI143)() = LnkTLI143;
static object  LnkTLI142() ;
static object  (*LnkLI142)() = LnkTLI142;
static object  LnkTLI136() ;
static object  (*LnkLI136)() = LnkTLI136;
static object  LnkTLI135() ;
static object  (*LnkLI135)() = LnkTLI135;
static object  LnkTLI134() ;
static object  (*LnkLI134)() = LnkTLI134;
static object  LnkTLI133() ;
static object  (*LnkLI133)() = LnkTLI133;
static  LnkT132() ;
static  (*Lnk132)() = LnkT132;
static object  LnkTLI131() ;
static object  (*LnkLI131)() = LnkTLI131;
static  LnkT127() ;
static  (*Lnk127)() = LnkT127;
static int  LnkTLI126() ;
static int  (*LnkLI126)() = LnkTLI126;
static  LnkT125() ;
static  (*Lnk125)() = LnkT125;
static object  LnkTLI124() ;
static object  (*LnkLI124)() = LnkTLI124;
static  LnkT123() ;
static  (*Lnk123)() = LnkT123;
static  LnkT122() ;
static  (*Lnk122)() = LnkT122;
static  LnkT121() ;
static  (*Lnk121)() = LnkT121;
static object  LnkTLI120() ;
static object  (*LnkLI120)() = LnkTLI120;
static object  LnkTLI119() ;
static object  (*LnkLI119)() = LnkTLI119;
static object  LnkTLI118() ;
static object  (*LnkLI118)() = LnkTLI118;
static object  LnkTLI117() ;
static object  (*LnkLI117)() = LnkTLI117;
static  LnkT115() ;
static  (*Lnk115)() = LnkT115;
static object  LnkTLI113() ;
static object  (*LnkLI113)() = LnkTLI113;
static  LnkT112() ;
static  (*Lnk112)() = LnkT112;
static  LnkT111() ;
static  (*Lnk111)() = LnkT111;
static object  LnkTLI110() ;
static object  (*LnkLI110)() = LnkTLI110;
static  LnkT109() ;
static  (*Lnk109)() = LnkT109;
