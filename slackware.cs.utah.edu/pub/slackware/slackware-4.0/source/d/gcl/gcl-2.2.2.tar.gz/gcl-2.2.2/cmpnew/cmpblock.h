
static object LI1();
static L3();
static L4();
static L8();
static L9();
static object LI1();
static struct { short n,allow_other_keys;object *defaults;
	 KEYTYPE keys[7];} LI1key={7,0,Cstd_key_defaults,{(void *)23,(void *)24,(void *)25,(void *)5,(void *)6,(void *)4,(void *)3}};
#define VMB1 register object *base=vs_top; object Vcs[14];
#define VMS1  register object *sup=vs_top+8;vs_top=sup;
#define VMV1 vs_reserve(8);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top; object  V13;
#define VMS2 vs_top += 3;
#define VMV2 vs_reserve(3);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
#define VC3
#define VC4
static object LI5();
#define VMB5 register object *base=vs_top; object  V26 ,V25 ,V24;
#define VMS5  register object *sup=vs_top+3;vs_top=sup;
#define VMV5 vs_reserve(3);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V40 ,V39 ,V38 ,V37 ,V36 ,V35 ,V34 ,V33 ,V32;
#define VMS6  register object *sup=vs_top+5;vs_top=sup;
#define VMV6 vs_reserve(5);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 object  V54 ,V51 ,V44;
#define VMS7
#define VMV7
#define VMR7(VMT7) return(VMT7);
#define VC8
#define VC9
static object LI10();
#define VMB10 register object *base=vs_top; object  V68 ,V67 ,V66;
#define VMS10 vs_top += 1;
#define VMV10 vs_reserve(1);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
static object LI11();
#define VMB11 register object *base=vs_top; object  V76 ,V75 ,V74;
#define VMS11 vs_top += 1;
#define VMV11 vs_reserve(1);
#define VMR11(VMT11) vs_top=base ; return(VMT11);
#define VM11 1
#define VM10 1
#define VM9 5
#define VM8 6
#define VM7 0
#define VM6 5
#define VM5 3
#define VM4 3
#define VM3 4
#define VM2 3
#define VM1 8
static char * VVi[54]={
#define Cdata VV[53]
(char *)(LI1),
(char *)(&LI1key),
(char *)(LI2),
(char *)(L3),
(char *)(L4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(L8),
(char *)(L9),
(char *)(LI10),
(char *)(LI11)
};
#define VV ((object *)VVi)
static object  LnkTLI52() ;
static object  (*LnkLI52)() = LnkTLI52;
static object  LnkTLI51() ;
static object  (*LnkLI51)() = LnkTLI51;
static object  LnkTLI50() ;
static object  (*LnkLI50)() = LnkTLI50;
static  LnkT49() ;
static  (*Lnk49)() = LnkT49;
static object  LnkTLI48() ;
static object  (*LnkLI48)() = LnkTLI48;
static object  LnkTLI47() ;
static object  (*LnkLI47)() = LnkTLI47;
static object  LnkTLI46() ;
static object  (*LnkLI46)() = LnkTLI46;
static object  LnkTLI43() ;
static object  (*LnkLI43)() = LnkTLI43;
static object  LnkTLI42() ;
static object  (*LnkLI42)() = LnkTLI42;
static object  LnkTLI41() ;
static object  (*LnkLI41)() = LnkTLI41;
static object  LnkTLI40() ;
static object  (*LnkLI40)() = LnkTLI40;
static object  LnkTLI39() ;
static object  (*LnkLI39)() = LnkTLI39;
static object  LnkTLI38() ;
static object  (*LnkLI38)() = LnkTLI38;
static object  LnkTLI37() ;
static object  (*LnkLI37)() = LnkTLI37;
static object  LnkTLI36() ;
static object  (*LnkLI36)() = LnkTLI36;
static object  LnkTLI35() ;
static object  (*LnkLI35)() = LnkTLI35;
static  LnkT34() ;
static  (*Lnk34)() = LnkT34;
static  LnkT33() ;
static  (*Lnk33)() = LnkT33;
static object  LnkTLI32() ;
static object  (*LnkLI32)() = LnkTLI32;
static object  LnkTLI31() ;
static object  (*LnkLI31)() = LnkTLI31;
static object  LnkTLI30() ;
static object  (*LnkLI30)() = LnkTLI30;
static object  LnkTLI29() ;
static object  (*LnkLI29)() = LnkTLI29;
static object  LnkTLI28() ;
static object  (*LnkLI28)() = LnkTLI28;
static object  LnkTLI27() ;
static object  (*LnkLI27)() = LnkTLI27;
static object  LnkTLI26() ;
static object  (*LnkLI26)() = LnkTLI26;
