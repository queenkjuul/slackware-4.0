
/* this is a dummy for emacs unexec.c
i think all the systems we handle which use unexec.c have getpagesize
If you need something better look in the emacs/src/ distribution.
*/

