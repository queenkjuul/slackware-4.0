
static object LI1();
static L23();
static object LI1();
static object VK1defaults[7]={(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)-2,(void *)-1,(void *)62};
static struct { short n,allow_other_keys;object *defaults;
	 KEYTYPE keys[7];} LI1key={7,0,VK1defaults,{(void *)63,(void *)17,(void *)16,(void *)64,(void *)65,(void *)14,(void *)1}};
#define VMB1 register object *base=vs_top; object Vcs[14];
#define VMS1  register object *sup=vs_top+8;vs_top=sup;
#define VMV1 vs_reserve(8);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top; object  V28 ,V27 ,V26 ,V25 ,V20;
#define VMS2  register object *sup=vs_top+1;vs_top=sup;
#define VMV2 vs_reserve(1);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 object  V34 ,V33;
#define VMS3
#define VMV3
#define VMR3(VMT3) return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top; object  V45 ,V44 ,V43;
#define VMS4 vs_top += 1;
#define VMV4 vs_reserve(1);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top; object  V62 ,V60 ,V59 ,V58 ,V55 ,V54;
#define VMS5  register object *sup=vs_top+2;vs_top=sup;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V68 ,V67 ,V66;
#define VMS6  register object *sup=vs_top+1;vs_top=sup;
#define VMV6 vs_reserve(1);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 object  V82;
#define VMS7
#define VMV7
#define VMR7(VMT7) return(VMT7);
static object LI8();
#define VMB8
#define VMS8
#define VMV8
#define VMR8(VMT8) return(VMT8);
static object LI9();
#define VMB9 register object *base=vs_top; object  V99;
#define VMS9 vs_top += 2;
#define VMV9 vs_reserve(2);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top; object  V114 ,V113 ,V112 ,V111 ,V110;
#define VMS10 vs_top += 1;
#define VMV10 vs_reserve(1);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
static object LI11();
#define VMB11 register object *base=vs_top;
#define VMS11  register object *sup=vs_top+1;vs_top=sup;
#define VMV11 vs_reserve(1);
#define VMR11(VMT11) vs_top=base ; return(VMT11);
static object LI12();
#define VMB12 object  V147 ,V146 ,V143 ,V141 ,V139 ,V137 ,V135 ,V133 ,V132 ,V131 ,V130 ,V128 ,V126 ,V125;
#define VMS12
#define VMV12
#define VMR12(VMT12) return(VMT12);
static object LI13();
#define VMB13 register object *base=vs_top; object  V181 ,V179 ,V176 ,V175 ,V174 ,V173 ,V167 ,V165 ,V163 ,V161 ,V159 ,V158 ,V157 ,V156;
#define VMS13  register object *sup=vs_top+4;vs_top=sup;
#define VMV13 vs_reserve(4);
#define VMR13(VMT13) vs_top=base ; return(VMT13);
static object LI14();
#define VMB14 register object *base=vs_top; object  V189;
#define VMS14 vs_top += 1;
#define VMV14 vs_reserve(1);
#define VMR14(VMT14) vs_top=base ; return(VMT14);
static object LI15();
#define VMB15 register object *base=vs_top; object  V199 ,V197 ,V196;
#define VMS15 vs_top += 1;
#define VMV15 vs_reserve(1);
#define VMR15(VMT15) vs_top=base ; return(VMT15);
static object LI16();
#define VMB16 object  V210 ,V208 ,V207;
#define VMS16
#define VMV16
#define VMR16(VMT16) return(VMT16);
static object LI17();
#define VMB17 register object *base=vs_top; object  V225 ,V224 ,V223 ,V222 ,V221;
#define VMS17  register object *sup=vs_top+2;vs_top=sup;
#define VMV17 vs_reserve(2);
#define VMR17(VMT17) vs_top=base ; return(VMT17);
static object LI18();
#define VMB18 register object *base=vs_top; object  V235 ,V232;
#define VMS18 vs_top += 1;
#define VMV18 vs_reserve(1);
#define VMR18(VMT18) vs_top=base ; return(VMT18);
static object LI19();
#define VMB19 register object *base=vs_top; object  V242;
#define VMS19 vs_top += 1;
#define VMV19 vs_reserve(1);
#define VMR19(VMT19) vs_top=base ; return(VMT19);
static object LI20();
#define VMB20 register object *base=vs_top;
#define VMS20  register object *sup=vs_top+4;vs_top=sup;
#define VMV20 vs_reserve(4);
#define VMR20(VMT20) vs_top=base ; return(VMT20);
static object LI21();
#define VMB21 register object *base=vs_top; object  V269 ,V268 ,V267 ,V263 ,V262 ,V261;
#define VMS21  register object *sup=vs_top+5;vs_top=sup;
#define VMV21 vs_reserve(5);
#define VMR21(VMT21) vs_top=base ; return(VMT21);
static object LI22();
#define VMB22 register object *base=vs_top; object  V291 ,V290 ,V289 ,V288 ,V287 ,V286 ,V282 ,V280;
#define VMS22 vs_top += 6;
#define VMV22 vs_reserve(6);
#define VMR22(VMT22) vs_top=base ; return(VMT22);
#define VC23 object  V304 ,V303 ,V302 ,V301 ,V300;
#define VM23 3
#define VM22 6
#define VM21 5
#define VM20 4
#define VM19 1
#define VM18 1
#define VM17 2
#define VM16 0
#define VM15 1
#define VM14 1
#define VM13 4
#define VM12 0
#define VM11 1
#define VM10 1
#define VM9 2
#define VM8 0
#define VM7 0
#define VM6 1
#define VM5 2
#define VM4 1
#define VM3 0
#define VM2 1
#define VM1 8
static char * VVi[116]={
#define Cdata VV[115]
(char *)(LI1),
(char *)(&LI1key),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10),
(char *)(LI11),
(char *)(LI12),
(char *)(LI13),
(char *)(LI14),
(char *)(LI15),
(char *)(LI16),
(char *)(LI17),
(char *)(LI18),
(char *)(LI19),
(char *)(LI20),
(char *)(LI21),
(char *)(LI22),
(char *)(L23)
};
#define VV ((object *)VVi)
static object  LnkTLI69() ;
static object  (*LnkLI69)() = LnkTLI69;
static  LnkT114() ;
static  (*Lnk114)() = LnkT114;
static object  LnkTLI42() ;
static object  (*LnkLI42)() = LnkTLI42;
static object  LnkTLI113() ;
static object  (*LnkLI113)() = LnkTLI113;
static object  LnkTLI112() ;
static object  (*LnkLI112)() = LnkTLI112;
static object  LnkTLI111() ;
static object  (*LnkLI111)() = LnkTLI111;
static  LnkT110() ;
static  (*Lnk110)() = LnkT110;
static object  LnkTLI109() ;
static object  (*LnkLI109)() = LnkTLI109;
static object  LnkTLI108() ;
static object  (*LnkLI108)() = LnkTLI108;
static object  LnkTLI107() ;
static object  (*LnkLI107)() = LnkTLI107;
static object  LnkTLI106() ;
static object  (*LnkLI106)() = LnkTLI106;
static object  LnkTLI104() ;
static object  (*LnkLI104)() = LnkTLI104;
static  LnkT103() ;
static  (*Lnk103)() = LnkT103;
static object  LnkTLI102() ;
static object  (*LnkLI102)() = LnkTLI102;
static object  LnkTLI101() ;
static object  (*LnkLI101)() = LnkTLI101;
static object  LnkTLI100() ;
static object  (*LnkLI100)() = LnkTLI100;
static object  LnkTLI99() ;
static object  (*LnkLI99)() = LnkTLI99;
static object  LnkTLI98() ;
static object  (*LnkLI98)() = LnkTLI98;
static object  LnkTLI97() ;
static object  (*LnkLI97)() = LnkTLI97;
static  LnkT96() ;
static  (*Lnk96)() = LnkT96;
static  LnkT95() ;
static  (*Lnk95)() = LnkT95;
static  LnkT94() ;
static  (*Lnk94)() = LnkT94;
static  LnkT93() ;
static  (*Lnk93)() = LnkT93;
static  LnkT92() ;
static  (*Lnk92)() = LnkT92;
static object  LnkTLI91() ;
static object  (*LnkLI91)() = LnkTLI91;
static  LnkT90() ;
static  (*Lnk90)() = LnkT90;
static  LnkT89() ;
static  (*Lnk89)() = LnkT89;
static  LnkT87() ;
static  (*Lnk87)() = LnkT87;
static object  LnkTLI85() ;
static object  (*LnkLI85)() = LnkTLI85;
static object  LnkTLI84() ;
static object  (*LnkLI84)() = LnkTLI84;
static object  LnkTLI82() ;
static object  (*LnkLI82)() = LnkTLI82;
static object  LnkTLI81() ;
static object  (*LnkLI81)() = LnkTLI81;
static object  LnkTLI80() ;
static object  (*LnkLI80)() = LnkTLI80;
static object  LnkTLI79() ;
static object  (*LnkLI79)() = LnkTLI79;
static  LnkT78() ;
static  (*Lnk78)() = LnkT78;
static object  LnkTLI77() ;
static object  (*LnkLI77)() = LnkTLI77;
static object  LnkTLI76() ;
static object  (*LnkLI76)() = LnkTLI76;
static object  LnkTLI75() ;
static object  (*LnkLI75)() = LnkTLI75;
static object  LnkTLI74() ;
static object  (*LnkLI74)() = LnkTLI74;
static object  LnkTLI73() ;
static object  (*LnkLI73)() = LnkTLI73;
static object  LnkTLI72() ;
static object  (*LnkLI72)() = LnkTLI72;
static object  LnkTLI71() ;
static object  (*LnkLI71)() = LnkTLI71;
static object  LnkTLI70() ;
static object  (*LnkLI70)() = LnkTLI70;
static object  LnkTLI68() ;
static object  (*LnkLI68)() = LnkTLI68;
static object  LnkTLI67() ;
static object  (*LnkLI67)() = LnkTLI67;
static object  LnkTLI66() ;
static object  (*LnkLI66)() = LnkTLI66;
