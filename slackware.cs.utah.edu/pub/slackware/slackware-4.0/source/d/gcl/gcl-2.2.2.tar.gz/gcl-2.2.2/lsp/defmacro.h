
static L1();
static L11();
static L12();
#define VC1 object  V5;
static object LI2();
#define VMB2 register object *base=vs_top; object  V29 ,V28 ,V27 ,V24 ,V23 ,V22 ,V21;
#define VMS2  register object *sup=vs_top+5;vs_top=sup;
#define VMV2 vs_reserve(5);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top; object  V82 ,V81 ,V80 ,V78 ,V77 ,V76 ,V75 ,V70 ,V69 ,V68 ,V56 ,V55 ,V54 ,V50 ,V49 ,V48;
#define VMS3  register object *sup=vs_top+2;vs_top=sup;
#define VMV3 vs_reserve(2);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top; object  V91 ,V88;
#define VMS4  register object *sup=vs_top+0;vs_top=sup;
#define VMV4
#define VMR4(VMT4) return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top;
#define VMS5  register object *sup=vs_top+2;vs_top=sup;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top;
#define VMS6  register object *sup=vs_top+2;vs_top=sup;
#define VMV6 vs_reserve(2);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top;
#define VMS7  register object *sup=vs_top+2;vs_top=sup;
#define VMV7 vs_reserve(2);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static object LI8();
#define VMB8 register object *base=vs_top;
#define VMS8  register object *sup=vs_top+1;vs_top=sup;
#define VMV8 vs_reserve(1);
#define VMR8(VMT8) vs_top=base ; return(VMT8);
static object LI9();
#define VMB9 register object *base=vs_top;
#define VMS9  register object *sup=vs_top+1;vs_top=sup;
#define VMV9 vs_reserve(1);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top;
#define VMS10  register object *sup=vs_top+2;vs_top=sup;
#define VMV10 vs_reserve(2);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
#define VC11
#define VC12
#define VM12 3
#define VM11 5
#define VM10 2
#define VM9 1
#define VM8 1
#define VM7 2
#define VM6 2
#define VM5 2
#define VM4 0
#define VM3 2
#define VM2 5
#define VM1 3
static char * VVi[62]={
#define Cdata VV[61]
(char *)(L1),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10),
(char *)(L11),
(char *)(L12)
};
#define VV ((object *)VVi)
static  LnkT60() ;
static  (*Lnk60)() = LnkT60;
static object  LnkTLI59() ;
static object  (*LnkLI59)() = LnkTLI59;
static object  LnkTLI58() ;
static object  (*LnkLI58)() = LnkTLI58;
static object  LnkTLI57() ;
static object  (*LnkLI57)() = LnkTLI57;
static object  LnkTLI56() ;
static object  (*LnkLI56)() = LnkTLI56;
static object  LnkTLI55() ;
static object  (*LnkLI55)() = LnkTLI55;
static  LnkT54() ;
static  (*Lnk54)() = LnkT54;
static  LnkT53() ;
static  (*Lnk53)() = LnkT53;
