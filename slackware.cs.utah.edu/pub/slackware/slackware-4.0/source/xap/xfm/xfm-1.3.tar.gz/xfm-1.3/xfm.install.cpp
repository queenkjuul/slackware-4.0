XCOMM! /bin/sh

XCOMM-------------------------------------------------------------------------
XCOMM xfm.install
XCOMM
XCOMM (c) Simon Marlow 1994
XCOMM-------------------------------------------------------------------------

if [ -d $HOME/.xfm ]; then
	echo You already have a ~/.xfm directory, would you like it
	echo -n 'replaced with the default configuration? [n] '
	read ANS
	if [ "$ANS" != "y" -a "$ANS" != "Y" ]; then
		echo Aborting.
		exit 1
	fi
	rm -rf $HOME/.xfm
fi

mkdir $HOME/.xfm \
&& cp LIBDIR/dot.xfm/xfm-apps $HOME/.xfm \
&& cp LIBDIR/dot.xfm/xfm-tools $HOME/.xfm \
&& cp LIBDIR/dot.xfm/xfmrc $HOME/.xfm \
&& cp LIBDIR/dot.xfm/xfmdev $HOME/.xfm

if [ $? != 0 ]; then
	echo Installation failed for some reason.  Please consult your
	echo system administrator.
fi

if [ ! -d $HOME/.trash ]; then
	mkdir $HOME/.trash
fi

echo Default configuration files installed.
