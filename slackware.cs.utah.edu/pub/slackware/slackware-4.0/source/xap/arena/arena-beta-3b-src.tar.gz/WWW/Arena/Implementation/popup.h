#ifndef _ARENA_POPUP_H_
#define _ARENA_POPUP_H_

extern void ShowLink(int ,int );

#endif /* _ARENA_POPUP_H_ */    
