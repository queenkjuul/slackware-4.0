/*
 * Simple program to reduce ppm-pictures
 *
 * (c.) 1993 by Ove Kalkan - all rights reserved
 */

#include <stdio.h>

int	main (int argc, char **argv)
{
	int	i;
	char	dummy[1024];

	fgets (dummy,1024,stdin);
	fprintf(stdout,"%s",dummy);
	fgets (dummy,1024,stdin);
	fprintf(stdout,"%s",dummy);
	fgets (dummy,1024,stdin);
	fprintf(stdout,"%s",dummy);
	fgets (dummy,1024,stdin);
	fprintf(stdout,"16\n");

	do {
		unsigned char	s;

		i = fread((void *) &s,1,1,stdin);
		if (i == 1) {
			s /= 16;
			fwrite((void *) &s,1,1,stdout);
		}
	} while (i == 1);
}