/*
 * Copyright 1993 by Ove Kalkan, Cremlingen, Germany
 *
 * Permission to use, copy, modify, distribute and sell this software and it's
 * documentation for any purpose is hereby granted without fee, rpovided that
 * the above copyright notice and this permission appear in supporting
 * documentation, and that the name of Ove Kalkan not to be used in
 * advertising or publicity pertaining to distributiopn of the software without
 * specific, written prior permission. Ove Kalkan makes no representations
 * about the suitability of this software for any purpose. It is provided
 * as is without express or implied warranty.
 *
 * OVE KALKAN DISPLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABLILITY AND FITNESS, IN NO
 * EVENT SHALL OVE KALKAN BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 *
 * $Header: filename,v 1.0 yyyy/mm/dd hh:mm:ss loginname Exp $
 */

#include "global.h"


/*
 * Globale Variablen
 */


/*********************************************************
 * name:	leaveWindow
 * description:	Wird immer dann aufgerufen, wenn ein Fenster
 *		verlassen wurde.Es werden die fuer die Grab
 *		Funktion wichtigen Parameter gesetzt
 * input:	Widget	w	- Fenster das verlassen wurde
 *		XEvent	*e	- der Event
 *		String	*s	- notused
 *		Cardinal *c	- notused
 * output:	none
 * author:	Ove Kalkan
 * date:	16.6.93
 *********************************************************/
XtActionProc		leaveWindow    (Widget w, XLeaveWindowEvent *e, 
					String *s, Cardinal *c)
{
	/*
	 * Wenn es eine Grab-Operation gibt, dann das Highlight loeschen
	 */
	if (GRAB) {
		if (last_g) {
			XDrawRectangle(XtDisplay(dir_area),XtWindow(dir_area),
				       back_gc, last_g->x - 4, last_g->y - 2,
				       32 + XTextWidth (defaults.icon_font,
					last_g->name,strlen(last_g->name)), 20);
			last_y = 16000;
			last_g = NULL;
		}
		else if (folder && last_v < 16000) {
			XDrawRectangle(XtDisplay(folder->window),XtWindow(folder->window),
				       back_gc, 16, last_v*DIR_Y_STEP + 4,
				       folder->max_length + 50 + typelength, 20);
			last_v = 16000;
		}
		else if (last_ws && last_w < 16000) {
			XDrawRectangle(XtDisplay(toplevel),
					XtWindow(last_ws->window),
					back_gc,
					last_ws->wse[last_w]->x - last_ws->wse[last_w]->w/2 - 1,
					last_ws->wse[last_w]->y - 1,
					last_ws->wse[last_w]->w + 1, last_ws->wse[last_w]->h + 1);
			last_ws = NULL;
			last_w = 16000;
		}
	}
	folder = NULL;	/* Zeiger auf derzeitiges Window, wird nur innerhalb
			   von Fenstern gebraucht */
	/*
	 * Muss gemacht werden, da nach einem XGrabButton ein LeaveNotify kommt
	 * und bei einem Grab in einem FolderFenster der Folder sonst verloren
	 * gehen wuerde und man erst aus dem Fenster hinaus und danach wieder
	 * hinein fahren muesste, damit das Fenster reagiert.
	 */
	if (REFRESH) {
		last_fo = selc_fo;
		folder = selc_fo;
		last_v = selc_f;
		REFRESH = FALSE;
	}
}


/*********************************************************
 * name:	enterWindow
 * description:	Wird immer dann aufgerufen, wenn der Mauszeiger
 *		in ein Fenster faehrt.
 * input:	Widget	w	- Fenster das verlassen wurde
 *		XEvent	*e	- der Event
 *		String	*s	- notused
 *		Cardinal *c	- notused
 * output:	none
 * author:	Ove Kalkan
 * date:	16.6.93
 *********************************************************/
XtActionProc		enterWindow    (Widget w, XEnterWindowEvent *e, 
					String *s, Cardinal *c)
{
	if (w != dir_area) {
		Dimension	i = 0;

		while (i < folder_count && i < MAX_FOLDERS && folders[i]->window != w)
			i++;

		if (i < folder_count) {
			folder = folders[i];
		}
	}
}



