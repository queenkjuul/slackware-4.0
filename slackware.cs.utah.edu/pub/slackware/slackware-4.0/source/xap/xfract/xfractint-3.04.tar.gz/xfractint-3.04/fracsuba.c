
#include "port.h"
#include "prototyp.h"

FManOWarfpFractal() {}
FJuliafpFractal() {}
FBarnsley1FPFractal() {}
FBarnsley2FPFractal() {}
FLambdaFPFractal() {}
