import gtk

def hello():
	print 'hello world'

w = gtk.Window()
w.borderWidth(10)
t = gtk.Table(rows=1, columns=2, homogeneous=gtk.TRUE)
b1 = gtk.Button('Hello')
b1.signalConnect('clicked', hello)
b2 = gtk.Button('Quit')
b2.signalConnect('clicked', lambda: gtk.main_quit())
t.attach(b1, 0, 1, 0, 1)
t.attach(b2, 1, 2, 0, 1)
w.add(t)
tip = gtk.Tooltips()
tip.setTips(b2, 'this is a tip')
b1.show()
b2.show()
t.show()
w.show()
gtk.main()
