#!/usr/local/bin/python

import gtk


def main():
	gtk.rc_parse('testgtkrc')

	window = gtk.Window()
	window.setTitle('check buttons')
	window.borderWidth(0)

	box1 = gtk.VBox()
	window.add(box1)
	box1.show()

	box2 = gtk.VBox(spacing=10)
	box2.borderWidth(10)
	box1.packStart(box2)
	box2.show()

	for i in range(3):
		checkbutton = gtk.CheckButton('button%i' % (i,))
		box2.packStart(checkbutton)
		checkbutton.show()

	separator = gtk.HSeparator()
	box1.packStart(separator)
	separator.show()

	box3 = gtk.VBox(spacing=10)
	box3.borderWidth(10)
	box1.packStart(box3)
	box3.show()

	button = gtk.Button(label='close')
	box3.packStart(button)
	button.signalConnect('clicked', gtk.main_quit)
	button.show()

	window.show()
	gtk.main()

main()
