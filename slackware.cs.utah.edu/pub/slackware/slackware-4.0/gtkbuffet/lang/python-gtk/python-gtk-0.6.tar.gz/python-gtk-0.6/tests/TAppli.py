#!/bin/env python
#
# Test the gtk.MenuBar, gtk.Menu and gtk.MenuItem, gtk.List and
# gtk.ListItem, gtk.FileSelection objects
#

import sys
import time
import gtk

class Application:		
	def __init__(self, argv):
		self.w_window=gtk.Window()
		self.w_window.setTitle("Test application")
		self.w_window.borderWidth(10)		
		self.w_vbox=gtk.VBox()
		
		self.init_menu()
		self.init_list()
		self.init_button()
		
		self.w_window.add(self.w_vbox)
		self.w_vbox.show()
		self.w_window.show()		
		
		self.idlecount=0
		gtk.idle_add(self.idle, ())

	def mainloop(self):
		gtk.main()

	def quit(self):
		gtk.main_quit()
				
	def doit(self):
		z=[]
		for x in range(10,20):
			item=gtk.ListItem(label="line %d" % x)
			item.show()
			z.append(item)
		self.w_listbox.appendItems(z)
	

	def init_menu(self):
		self.w_menubar=gtk.MenuBar()
		
		# file menu
		self.w_filemenu=gtk.Menu()
		filemenu=gtk.MenuItem('File')
		filemenu.setSubmenu(self.w_filemenu)
		filemenu.show()
		
		item=gtk.MenuItem('New'); self.w_filemenu.append(item)
		item.signalConnect('activate', self.process_file_new); item.show()
		item=gtk.MenuItem('Open...'); self.w_filemenu.append(item)
		item.signalConnect('activate', self.process_file_open); item.show()
		item=gtk.MenuItem('Save'); self.w_filemenu.append(item)
		item.signalConnect('activate', self.process_file_save); item.show()
		item=gtk.MenuItem('Save As...'); self.w_filemenu.append(item)
		item.signalConnect('activate', self.process_file_save_as); item.show()
		item=gtk.MenuItem('Close'); self.w_filemenu.append(item)
		item.signalConnect('activate', self.process_file_close); item.show()
		item=gtk.MenuItem('Quit'); self.w_filemenu.append(item)
		item.signalConnect('activate', self.quit); item.show()

		# edit menu
		self.w_editmenu=gtk.Menu()
		editmenu=gtk.MenuItem('Edit')
		editmenu.setSubmenu(self.w_editmenu)
		editmenu.show()
		
		item=gtk.MenuItem('Cut'); self.w_editmenu.append(item)
		item.signalConnect('activate', self.process_edit_cut); item.show()
		item=gtk.MenuItem('Copy'); self.w_editmenu.append(item)
		item.signalConnect('activate', self.process_edit_copy); item.show()
		item=gtk.MenuItem('Paste'); self.w_editmenu.append(item)
		item.signalConnect('activate', self.process_edit_paste); item.show()
		
		self.w_menubar.append(filemenu)
		self.w_menubar.append(editmenu)
		self.w_vbox.packStart(self.w_menubar, expand=gtk.FALSE)
		self.w_menubar.show()
		

	def init_list(self):		
		c=gtk.ScrolledWindow()	
		c.setUSize(250,200)
		self.w_listbox=gtk.List()
		self.w_listbox.setSelectMode(gtk.SELECTION_MULTIPLE)
		c.add(self.w_listbox)
		self.w_vbox.packStart(c)
		
		for x in range(0,10):
			item=gtk.ListItem(label="line %d" % x)
			item.show()
			self.w_listbox.add(item)
		self.w_listbox.show()
		c.show()
			
	def init_button(self):
		t = gtk.Table(rows=1, columns=2, homogeneous=gtk.TRUE)
		b1 = gtk.Button('Do it!')
		b1.signalConnect('clicked', self.doit)
		b2 = gtk.Button('Quit')
		b2.signalConnect('clicked', self.quit)
		t.attach(b1, 0, 1, 0, 1, yoptions=0, xpadding=2, ypadding=2)
		t.attach(b2, 1, 2, 0, 1, yoptions=0, xpadding=2, ypadding=2)
		
		self.w_vbox.packEnd(t, expand=gtk.FALSE)
				
		b1.show()
		b2.show()
		t.show()

	def process_file_new(self):
		print "process_file_new"
		
	def process_file_open(self):
		print "process_file_open"
		# how to transform this in modal dialog is myterious...
		fs=gtk.FileSelection()
		fs.show()
		
	def process_file_save(self):
		print "process_file_save"
		
	def process_file_save_as(self):
		print "process_file_save_as"
		# how to transform this in modal dialog is myterious...
		fs=gtk.FileSelection()
		fs.show()
		
	def process_file_close(self):
		print "process_file_close"
		
	def process_edit_cut(self):
		print "process_edit_cut"
		
	def process_edit_copy(self):
		print "process_edit_copy"
		
	def process_edit_paste(self):
		print "process_edit_paste"
		
	
	def idle(self):
		self.idlecount=self.idlecount+1
		if(self.idlecount % 1000 == 0):
			print "Idle:", self.idlecount
			# if measuring time
			##self.quit()
		gtk.idle_add(self.idle, ())
			
if(__name__=="__main__"):
	use_defaults=1
	for arg in sys.argv:
		if(arg=="-d"):
			import pdb
			pdb.set_trace()

		if(arg=="-n"):
			use_defaults=0
			
	start_time = time.time()
	
	if(use_defaults==1):
		gtk.rc_parse("defaults.rc")
	
	app=Application(sys.argv)
	app.mainloop()
	the_time = time.time() - start_time
	print "Application ran %.2f s." % the_time
	
