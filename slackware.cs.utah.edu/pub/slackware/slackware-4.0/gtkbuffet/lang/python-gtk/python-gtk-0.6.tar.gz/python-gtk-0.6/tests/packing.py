import gtk

def make_box(homogeneous, spacing, expand, fill, padding):
	box = gtk.HBox(homogeneous, spacing)
	button = gtk.Button("gtk_box_pack")
	box.packStart(button, expand, fill, padding)
	button.show()

	button = gtk.Button("(box, ")
	box.packStart(button, expand, fill, padding)
	button.show()

	button = gtk.Button("button,")
	box.packStart(button, expand, fill, padding)
	button.show()

	if expand:
		button = gtk.Button("TRUE,")
	else:
		button = gtk.Button("FALSE,")
	box.packStart(button, expand, fill, padding)
	button.show()

	button = gtk.Button("%d" % padding)
	box.packStart(button, expand, fill, padding)
	button.show()

	return box


def main():
	import sys, string

	if len(sys.argv) != 2:
		print "Usage: %s num, where num is 1, 2, or 3\n" % sys.argv[0]
		sys.exit()
	
	which = string.atoi(sys.argv[1])

	window = gtk.Window()
	window.signalConnect("destroy", gtk.main_quit)
	window.borderWidth(10)

	box1 = gtk.VBox(gtk.FALSE, 0)

	if which == 1:
		label = gtk.Label("HBox(FALSE, 0)")
		label.setAlignment(0, 0)
		box1.packStart(label, gtk.FALSE, gtk.FALSE, 0)
		label.show()
	
		box2 = make_box(gtk.FALSE, 0, gtk.FALSE, gtk.FALSE, 0)
		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		box2 = make_box(gtk.FALSE, 0, gtk.TRUE, gtk.FALSE, 0)
		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		box2 = make_box(gtk.FALSE, 0, gtk.TRUE, gtk.TRUE, 0)
		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		separator = gtk.HSeparator()
		box1.packStart(separator, gtk.FALSE, gtk.TRUE, 5)
		separator.show()

		label = gtk.Label("HBox(TRUE, 0)")
		label.setAlignment(0, 0)
		box1.packStart(label, gtk.FALSE, gtk.FALSE, 0)
		label.show()

		box2 = make_box(gtk.TRUE, 0, gtk.TRUE, gtk.FALSE, 0)
		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		box2 = make_box(gtk.TRUE, 0, gtk.TRUE, gtk.TRUE, 0)
		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		separator = gtk.HSeparator()
		box1.packStart(separator, gtk.FALSE, gtk.TRUE, 5)
		separator.show()

	elif which == 2:
		
		label = gtk.Label("HBox(FALSE, 10)")
		label.setAlignment(0, 0)
		box1.packStart(label, gtk.FALSE, gtk.FALSE, 0)
		label.show()
	
		box2 = make_box(gtk.FALSE, 10, gtk.TRUE, gtk.FALSE, 0)
		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		box2 = make_box(gtk.FALSE, 10, gtk.TRUE, gtk.TRUE, 0)
		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		separator = gtk.HSeparator()
		box1.packStart(separator, gtk.FALSE, gtk.TRUE, 5)
		separator.show()

		label = gtk.Label("HBox(FALSE, 0)")
		label.setAlignment(0, 0)
		box1.packStart(label, gtk.FALSE, gtk.FALSE, 0)
		label.show()

		box2 = make_box(gtk.FALSE, 0, gtk.TRUE, gtk.FALSE, 10)
		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		box2 = make_box(gtk.FALSE, 0, gtk.TRUE, gtk.TRUE, 10)
		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		separator = gtk.HSeparator()
		box1.packStart(separator, gtk.FALSE, gtk.TRUE, 5)
		separator.show()

	elif which == 3:
		box2 = make_box(gtk.FALSE, 0, gtk.FALSE, gtk.FALSE, 0)
		label = gtk.Label("end")
		label.setAlignment(0, 0)
		box2.packEnd(label, gtk.FALSE, gtk.FALSE, 0)
		label.show()

		box1.packStart(box2, gtk.FALSE, gtk.FALSE, 0)
		box2.show()

		separator = gtk.HSeparator()
		separator.setUSize(400, 5)
		box1.packStart(separator, gtk.FALSE, gtk.TRUE, 5)
		separator.show()


	quitbox = gtk.HBox(gtk.FALSE, 0)
	button = gtk.Button("Quit")
	button.signalConnect("clicked", window.destroy)
	quitbox.packStart(button, gtk.TRUE, gtk.FALSE, 0)
	box1.packStart(quitbox, gtk.FALSE, gtk.FALSE, 0)

	window.add(box1)
	button.show()
	quitbox.show()
	box1.show()
	window.show()

	gtk.main()


main()
