import gtk

def quit():
	gtk.main_quit()


window = gtk.Window()
window.signalConnect("destroy", quit)
window.borderWidth(10)
frame = gtk.Frame()
pixmap = gtk.Pixmap(frame, open("gtk-logo.xpm"))
window.add(frame)
frame.show()
window.show()
gtk.main()
