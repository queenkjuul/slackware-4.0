#!/usr/local/bin/python

import gtk

def hello_0():
	print 'hello world 0'

def hello_1(i):
	print 'hello world %i' % (i,)

def hello_2(i, j):
	print 'hello world %i %i' % (i, j)

def main():
	w = gtk.Window()
	t = gtk.Table(rows=1, columns=4, homogeneous=gtk.TRUE)
	w.add(t)

	b1 = gtk.Button('Hello 0')
	b1.connect('clicked', hello_0)
	b1.show()

	b2 = gtk.Button('Hello 1')
	b2.connect('clicked', hello_1, 1)
	b2.show()

	b3 = gtk.Button('Hello 2')
	b3.connect('clicked', hello_2, 1, 2)
	b3.show()

	b4 = gtk.Button('Quit')
	b4.connect('clicked', gtk.main_quit)
	b4.show()

	t.attach(b1, 0, 1, 0, 1)
	t.attach(b2, 1, 2, 0, 1)
	t.attach(b3, 2, 3, 0, 1)
	t.attach(b4, 3, 4, 0, 1)

	w.show()
	t.show()
		
	gtk.main()

main()
