import gtk
from gtk_const import *

class Dialog(gtk.Window):
	def __init__(self, title='untitled'):
		gtk.Window.__init__(self, title=title)
		self.vbox = gtk.VBox()
		self.add(self.vbox)

	def show(self):
		self.vbox.show()
		gtk.Window.show(self)



window = Dialog('Dialog')
window.signalConnect('destroy', gtk.main_quit)
window.borderWidth(0)


scrolled_window = gtk.ScrolledWindow()
scrolled_window.borderWidth(10)
scrolled_window.setPolicy(POLICY_AUTOMATIC, POLICY_ALWAYS)
window.vbox.packStart(scrolled_window, TRUE, TRUE, 0)
scrolled_window.show()

table = gtk.Table(10, 10, FALSE)
table.setRowSpacings(0)
table.setColSpacings(0)

scrolled_window.add(table)
table.show()

for i in range(10):
	for j in range(10):
		entry = gtk.Entry()
		table.attach(entry, i, i+1, j, j+1)
		entry.show()

window.show()
gtk.main()
