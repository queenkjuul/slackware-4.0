# based on the tutorial

import gtk

window = gtk.Window(title='Gtk Menu Test')
window.signalConnect('destroy', gtk.main_quit)

menu = gtk.Menu()

root_menu = gtk.MenuItem('Root Menu')
root_menu.show()

for i in range(3):
	menu_item = gtk.MenuItem('Test-undermenu %d' % i)
	menu.append(menu_item)
	menu_item.show()
menu_item = gtk.MenuItem('Quit')
menu.append(menu_item)
menu_item.signalConnect('activate', gtk.main_quit)
menu_item.show()

root_menu.setSubmenu(menu)

menu_bar = gtk.MenuBar()
window.add(menu_bar)
menu_bar.show()

menu_bar.append(root_menu)

window.show()

gtk.main()

