#!/usr/bin/env python

import gtk

w = gtk.Window()
list = gtk.List()

items = []
for i in range(10):
	li = gtk.ListItem('testing %d' % i)
	li.show()
	items.append(li)
list.appendItems(items)

# this is screwed (I think)
list.removeItems(items[4:7])

w.add(list)
list.show()
w.show()
gtk.main()
