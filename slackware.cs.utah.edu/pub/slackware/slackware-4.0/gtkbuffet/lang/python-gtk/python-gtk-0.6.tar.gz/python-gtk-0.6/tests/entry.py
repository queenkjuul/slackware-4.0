import gtk

def hello_entry(theWidget):
        theText = theWidget.getText()
        print 'The final text is: %s' % (theText, )
        gtk.main_quit()

def main():
        w = gtk.Window()
        t = gtk.Table(rows=1, columns=2, homogeneous=gtk.FALSE)
        w.add(t)

        b1 = gtk.Entry()
        b1.setText("hello-all")
        b1.appendText("_post")
        b1.prependText("pre_")
        initialText = b1.getText()
        print 'The initial text is: %s' % (initialText, )
        b1.show()

        b2 = gtk.Button('Quit')
        # here I pass a GTK widget (the b1 gtk.Entry) as argument
        # to the callback, to let the callback determine the text
        # to display, b1.getText(), at runtime
        b2.connect('clicked', hello_entry, b1)
        b2.show()

        t.attach(b1, 0, 1, 0, 1)
        t.attach(b2, 1, 2, 0, 1)

        w.show()
        t.show()

        gtk.main()

main()
 

