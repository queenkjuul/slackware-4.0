import _gtk, regex

r = regex.compile('^GTK_')

names = dir(_gtk)
constants = filter(lambda n: r.match(n) != -1, names)
for c in constants:
	print '%s = %s' % (c[4:], `_gtk.__dict__[c]`)
