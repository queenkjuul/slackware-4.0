import gtk

def quit():
	gtk.main_quit()


window = gtk.Window()
window.signalConnect("destroy", quit)
window.borderWidth(10)
button = gtk.Button("Hello World")
button.signalConnect("clicked", quit)
window.add(button)
button.show()
window.show()
gtk.main()
