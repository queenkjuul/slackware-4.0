#!/usr/local/bin/python

import gtk


def main():
	window = gtk.Window()
	window.setTitle('notebook')
	window.borderWidth(0)

	box1 = gtk.VBox()
	window.add(box1)
	box1.show()

	box2 = gtk.VBox(spacing=10)
	box2.borderWidth(10)
	box1.packStart(box2)
	box2.show()

	notebook = gtk.Notebook()
	notebook.setTabPos(gtk.POS_TOP)
	box2.packStart(notebook)
	notebook.show()

	for i in range(5):
		buffer = 'Page %i' % (i+1,)

		frame = gtk.Frame(buffer)
		frame.borderWidth(10)
		frame.setUSize(200, 150)
		frame.setShadowType(gtk.SHADOW_ETCHED_OUT)
		frame.show()
		
		label = gtk.Label(buffer)
		frame.add(label)
		label.show()

		label =gtk.Label(buffer)
		notebook.appendPage(frame, label)

	separator = gtk.HSeparator()
	box1.packStart(separator)
	separator.show()

	box3 = gtk.VBox(spacing=10)
	box3.borderWidth(10)
	box1.packStart(box3)
	box3.show()

	button = gtk.Button(label='close')
	box3.packStart(button)
	button.signalConnect('clicked', gtk.main_quit)
	button.show()

	window.show()
	gtk.main()

main()
