#!/usr/local/bin/python

import gtk
from gtk_const import *

def main():
	gtk.rc_parse('testgtkrc')

	shadows = [SHADOW_NONE, SHADOW_IN, SHADOW_OUT,
			   SHADOW_ETCHED_IN, SHADOW_ETCHED_OUT]
	names = ['None', 'In', 'Out', 'Etched_In', 'Etched_Out']
	n = len(shadows)

	window = gtk.Window(title='frames')
	window.borderWidth(0)
#	window.setUSize(400, 400)

	table = gtk.Table(rows=n, columns=n, homogeneous=FALSE)
	window.add(table)
	table.show()

	tooltips = gtk.Tooltips()
	tooltips.setDelay(300)
	#tooltips.setColors()

	radiobutton = None

	for i in range (n):
		frame = gtk.Frame(names[i])
		frame.setShadowType(shadows[i])
		table.attach(frame, i, i+1, 0, 1, xpadding=2, ypadding=2)
		frame.show()

		button = gtk.Button('button%i' % (i,))
		table.attach(button, i, i+1, 1, 2, xpadding=2, ypadding=2)
		tooltips.setTips(button, 'This is button%i' % (i,))
		button.show()

		togglebutton = gtk.ToggleButton('toggle%i' % (i,))
		table.attach(togglebutton, i, i+1, 2, 3, xpadding=2, ypadding=2)
		tooltips.setTips(togglebutton, 'This is toggle%i' % (i,))
		togglebutton.show()

		checkbutton = gtk.CheckButton('check%i' % (i,))
		table.attach(checkbutton, i, i+1, 3, 4, xpadding=2, ypadding=2)
		checkbutton.show()

		radiobutton = gtk.RadioButton(radiobutton, 'radio%i' % (i,))
		table.attach(radiobutton, i, i+1, 4, 5, xpadding=2, ypadding=2)
		radiobutton.show()

	window.show()
	gtk.main()

main()
