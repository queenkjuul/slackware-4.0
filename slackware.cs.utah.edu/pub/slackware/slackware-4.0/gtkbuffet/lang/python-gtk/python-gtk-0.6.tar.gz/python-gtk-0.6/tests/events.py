import gtk

def quit():
	gtk.main_quit()

def key_press(event):
	print event


window = gtk.Window()
window.signalConnect("destroy", quit)
window.borderWidth(10)
entry = gtk.Entry()
entry.signalConnect("key_press_event", key_press)
window.add(entry)
entry.show()
window.show()
gtk.main()
