#!/usr/local/bin/python

import gtk

count = 0

def hello():
	global label, count
	count = count + 1
	label.set(" %i" % (count,))

def main():
	global label

	w = gtk.Window()
	w.borderWidth(3)

	hbox = gtk.HBox()
	hbox.setSpacing(5)
	w.add(hbox)
	hbox.show()

	label = gtk.Label(label="0")
	hbox.add(label)
	label.show()

	b1 = gtk.Button('change')
	b1.connect('clicked', hello)
	hbox.add(b1)
	b1.show()

	f = gtk.Frame("Frame")
	hbox.add(f)
	f.show()

	w.show()
	gtk.main()

main()
