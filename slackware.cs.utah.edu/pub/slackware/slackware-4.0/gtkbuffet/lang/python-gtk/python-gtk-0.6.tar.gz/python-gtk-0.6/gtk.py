"""
Some random notes:

	The _gtk is pretty low level.  It does not do any reference
	counting.  This seems to be the simplest solution to me.
	Otherwise, how do reference counts get decremented with things
	are destroyed?  I may change this in the future.  Right now this
	module keeps extra references to things.  It seems to be working
	well so far.

	Should widgets take in a default parameter SHOW, which would be 1
	by default for all widgets except for windows?  This gets into
	another problem.  When __init__ methods are overwritten, keyword
	arguments are a pain, IMO.  Perhaps someone knows of a clean way
	of handling this.
"""

import operator
import _gtk
from gtk_const import *


VERSION = 0.5

_ptrcast = _gtk.ptrcast

# this should be safe, it needs to be run once
_gtk.gtk_init()

main = _gtk.gtk_main
main_quit = _gtk.gtk_main_quit
rc_parse = _gtk.gtk_rc_parse

_timeout_callbacks = {}
def timeout_add(interval, function, *args):
	id = _gtk.gtk_timeout_add(interval, function, args)
	_timeout_callbacks[id] = (function, args)
	return id

def timeout_remove(id):
	if not _timeout_callbacks.has_key(id):
		raise 'Error: invalid callback ID'
	del _timeout_callbacks[id]
	_gtk.gtk_timeout_remove(id)

_idle_callbacks = {}
def idle_add(function, *args):
	id = _gtk.gtk_idle_add(function, args)
	_idle_callbacks[id] = (function, args)
	return id

def idle_remove(id):
	if not _idle_callbacks.has_key(id):
		raise 'Error: invalid callback ID'
	del _idle_callbacks[id]
	_gtk.gtk_idle_remove(id)



# get the Python instance associated with a GtkObject pointer
def _get_instance(gpointer):
	instance = _gtk.gtk_object_get_data(_ptrcast(gpointer, 'GtkObject *'), 'python_instance')
	if instance == NULL:
		instance = None
	return instance
		


class Object:
	"""The base class for Gtk objects.

	Provides basic methods that all Gtk objects respond to.
	"""
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._object = _ptrcast(_pointer, 'GtkObject *')
		# add a reference to this class
		_gtk.gtk_object_set_data(self._object, 'python_instance', self)
		self._callbacks = {}

	def signalConnect(self, name, callback, *args):
		"""Connect a signal to a handler.

		The signal name is specified as a string.  The callback is a
		callable Python object.  Any additional arguments will be
		passed to the callback function.  Returns an integer
		identifying the callback.
		"""
		id = _gtk.gtk_signal_connect(self._object, name, callback, args)
		self._callbacks[id] = (callback, args)
		return id

	def connect(self, name, callback, *args):
		"""Connect a signal to a handler.

		The signal name is specified as a string.  The callback is a
		callable Python object.  Any additional arguments will be
		passed to the callback function.  Returns an ID identifying
		the callback.
		"""
		id = _gtk.gtk_signal_connect(self._object, name, callback, args)
		self._callbacks[id] = (callback, args)
		return id

	def signalDisconnect(self, id):
		"""Disconnect a signal handler using an ID"""
		if not self._callbacks.has_key(id):
			raise 'Error: invalid callback ID'
		del self._callbacks[id]
		_gtk.gtk_signal_disconnect(self._object, id)

	def disconnect(self, id):
		"""Disconnect a signal handler using an ID"""
		self.signalDisconnect(id)

	def destroy(self): 
		"""Causes object to emit the "destroy" signal

		A check is performed to make sure the object is not already
		processing a signal, then emits the destroy signal.
		"""
		_gtk.gtk_object_destroy(self._object)


class Widget(Object):
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._widget = _ptrcast(_pointer, 'GtkWidget *')
		Object.__init__(self, _pointer=_pointer)

	def destroy(self): 
		"""Causes object to emit the "destroy" signal

		A check is performed to make sure the object is not already
		processing a signal, then emits the destroy signal.
		"""
		_gtk.gtk_widget_destroy(self._widget)
	
	def unparent(self): 
		'''void gtk_widget_unparent (GtkWidget *widget)'''
		_gtk.gtk_widget_unparent(self._widget)
	
	def show(self): 
		"""Make a widget visible."""
		_gtk.gtk_widget_show(self._widget)
	
	def hide(self): 
		"""Make a widget invisible"""
		_gtk.gtk_widget_hide(self._widget)
	
	def map(self): 
		'''void gtk_widget_map (GtkWidget *widget)'''
		_gtk.gtk_widget_map(self._widget)
	
	def unmap(self): 
		'''void gtk_widget_unmap (GtkWidget *widget)'''
		_gtk.gtk_widget_unmap(self._widget)
	
	def realize(self): 
		'''void gtk_widget_realize (GtkWidget *widget)'''
		_gtk.gtk_widget_realize(self._widget)
	
	def unrealize(self): 
		'''void gtk_widget_unrealize (GtkWidget *widget)'''
		_gtk.gtk_widget_unrealize(self._widget)
	
##	def queueDraw(self): 
##		'''void gtk_widget_queue_draw (GtkWidget *widget)'''
##		_gtk.gtk_widget_queue_draw(self._widget)
##	
##	def queueResize(self): 
##		'''void gtk_widget_queue_resize (GtkWidget *widget)'''
##		_gtk.gtk_widget_queue_resize(self._widget)
	
	def draw(self, area): 
		'''void gtk_widget_draw (GtkWidget *widget, GdkRectangle *area)'''
		_gtk.gtk_widget_draw(self._widget, area)
	
	def drawFocus(self): 
		'''void gtk_widget_draw_focus (GtkWidget *widget)'''
		_gtk.gtk_widget_draw_focus(self._widget)
	
	def drawDefault(self): 
		'''void gtk_widget_draw_default (GtkWidget *widget)'''
		_gtk.gtk_widget_draw_default(self._widget)
	
	def drawChildren(self): 
		'''void gtk_widget_draw_children (GtkWidget *widget)'''
		_gtk.gtk_widget_draw_children(self._widget)
	
	def sizeRequest(self, requisition): 
		'''void gtk_widget_size_request (GtkWidget *widget, GtkRequisition *requisition)'''
		_gtk.gtk_widget_size_request(self._widget, requisition)
	
	def sizeAllocate(self, allocation): 
		'''void gtk_widget_size_allocate (GtkWidget *widget, GtkAllocation *allocation)'''
		_gtk.gtk_widget_size_allocate(self._widget, allocation)
	
	def installAccelerator(self, table, signal_name, key, guint8, modifiers): 
		'''void gtk_widget_install_accelerator (GtkWidget *widget, GtkAcceleratorTable *table, const gchar *signal_name, gchar key, guint8 modifiers)'''
		_gtk.gtk_widget_install_accelerator(self._widget, table, signal_name, key, guint8, modifiers)
	
	def removeAccelerator(self, table, signal_name): 
		'''void gtk_widget_remove_accelerator (GtkWidget *widget, GtkAcceleratorTable *table, const gchar *signal_name)'''
		_gtk.gtk_widget_remove_accelerator(self._widget, table, signal_name)
	
	# TODO: I think this is important
	def event(self, event): 
		'''gint gtk_widget_event (GtkWidget *widget, GdkEvent *event)'''
		return _gtk.gtk_widget_event(self._widget, event)
	
	def activate(self): 
		'''void gtk_widget_activate (GtkWidget *widget)'''
		_gtk.gtk_widget_activate(self._widget)
	
	def reparent(self, new_parent): 
		'''void gtk_widget_reparent (GtkWidget *widget, GtkWidget *new_parent)'''
		_gtk.gtk_widget_reparent(self._widget, new_parent._widget)
	
	def popup(self, x, y): 
		'''void gtk_widget_popup (GtkWidget *widget, gint x, gint y)'''
		_gtk.gtk_widget_popup(self._widget, x, y)
	
##	def intersect(self, area, intersection): 
##		'''gint gtk_widget_intersect (GtkWidget *widget, GdkRectangle *area, GdkRectangle *intersection)'''
##		return _gtk.gtk_widget_intersect(self._widget, area, intersection)
##	
##	def basic(self): 
##		'''gint gtk_widget_basic (GtkWidget *widget)'''
##		return _gtk.gtk_widget_basic(self._widget)
	
	def grabFocus(self): 
		'''void gtk_widget_grab_focus (GtkWidget *widget)'''
		_gtk.gtk_widget_grab_focus(self._widget)
	
	def grabDefault(self): 
		'''void gtk_widget_grab_default (GtkWidget *widget)'''
		_gtk.gtk_widget_grab_default(self._widget)
	
	def restoreState(self): 
		'''void gtk_widget_restore_state (GtkWidget *widget)'''
		_gtk.gtk_widget_restore_state(self._widget)
	
	def setName(self, name): 
		'''void gtk_widget_set_name (GtkWidget *widget, const gchar *name)'''
		_gtk.gtk_widget_set_name(self._widget, name)
	
	def getName(self): 
		'''gchar* gtk_widget_get_name (GtkWidget *widget)'''
		return _gtk.gtk_widget_get_name(self._widget)
	
	def setState(self, state): 
		'''void gtk_widget_set_state (GtkWidget *widget, GtkStateType state)'''
		_gtk.gtk_widget_set_state(self._widget, state)
	
	def setSensitive(self, sensitive): 
		'''void gtk_widget_set_sensitive (GtkWidget *widget, gint sensitive)'''
		_gtk.gtk_widget_set_sensitive(self._widget, sensitive)
	
	def setParent(self, parent): 
		'''void gtk_widget_set_parent (GtkWidget *widget, GtkWidget *parent)'''
		_gtk.gtk_widget_set_parent(self._widget, parent._widget)
	
	def setStyle(self, style): 
		'''void gtk_widget_set_style (GtkWidget *widget, GtkStyle *style)'''
		_gtk.gtk_widget_set_style(self._widget, style)
	
	def setUPosition(self, x, y): 
		'''void gtk_widget_set_uposition (GtkWidget *widget, gint x, gint y)'''
		_gtk.gtk_widget_set_uposition(self._widget, x, y)
	
	def setUSize(self, width, height): 
		'''void gtk_widget_set_usize (GtkWidget *widget, gint width, gint height)'''
		_gtk.gtk_widget_set_usize(self._widget, width, height)
	
	def setEvents(self, events): 
		'''void gtk_widget_set_events (GtkWidget *widget, gint events)'''
		_gtk.gtk_widget_set_events(self._widget, events)
	
	def setExtensionEvents(self, mode): 
		'''void gtk_widget_set_extension_events (GtkWidget *widget, GdkExtensionMode mode)'''
		_gtk.gtk_widget_set_extension_events(self._widget, mode)
	
	def getToplevel(self): 
		'''GtkWidget* gtk_widget_get_toplevel (GtkWidget *widget)'''
		w = _gtk.gtk_widget_get_toplevel(self._widget)
		return _get_instance(w)
	
	def getAncestor(self, type): 
		'''GtkWidget* gtk_widget_get_ancestor (GtkWidget *widget, gint type)'''
		w = _gtk.gtk_widget_get_ancestor(self._widget, type)
		return _get_instance(w)
	
	def getColormap(self): 
		'''GdkColormap* gtk_widget_get_colormap (GtkWidget *widget)'''
		return _gtk.gtk_widget_get_colormap(self._widget)
	
	def getVisual(self): 
		'''GdkVisual* gtk_widget_get_visual (GtkWidget *widget)'''
		return _gtk.gtk_widget_get_visual(self._widget)
	
	def getStyle(self): 
		'''GtkStyle* gtk_widget_get_style (GtkWidget *widget)'''
		return _gtk.gtk_widget_get_style(self._widget)
	
	def getEvents(self): 
		'''gint gtk_widget_get_events (GtkWidget *widget)'''
		return _gtk.gtk_widget_get_events(self._widget)
	
	def getExtensionEvents(self): 
		'''GdkExtensionMode gtk_widget_get_extension_events (GtkWidget *widget)'''
		return _gtk.gtk_widget_get_extension_events(self._widget)
	
	def getPointer(self, x, y): 
		'''void gtk_widget_get_pointer (GtkWidget *widget, gint *x, gint *y)'''
		_gtk.gtk_widget_get_pointer(self._widget, x, y)
	
	def isAncestor(self, ancestor): 
		'''gint gtk_widget_is_ancestor (GtkWidget *widget, GtkWidget *ancestor)'''
		return _gtk.gtk_widget_is_ancestor(self._widget, ancestor._widget)
	
	def isChild(self, child): 
		'''gint gtk_widget_is_child (GtkWidget *widget, GtkWidget *child)'''
		return _gtk.gtk_widget_is_child(self._widget, child._widget)
	
	def pushColormap(self, cmap): 
		'''void gtk_widget_push_colormap (GdkColormap *cmap)'''
		_gtk.gtk_widget_push_colormap(self._widget, cmap)
	
	def pushVisual(self, visual): 
		'''void gtk_widget_push_visual (GdkVisual *visual)'''
		_gtk.gtk_widget_push_visual(self._widget, visual)
	
	def pushStyle(self): 
		'''void gtk_widget_push_style (GtkStyle *style)'''
		_gtk.gtk_widget_push_style(self._widget)
	
	def popColormap(self): 
		'''void gtk_widget_pop_colormap (void)'''
		_gtk.gtk_widget_pop_colormap(self._widget)
	
	def popVisual(self): 
		'''void gtk_widget_pop_visual (void)'''
		_gtk.gtk_widget_pop_visual(self._widget)
	
	def popStyle(self): 
		'''void gtk_widget_pop_style (void)'''
		_gtk.gtk_widget_pop_style(self._widget)
	
	def setDefaultColormap(self, colormap): 
		'''void gtk_widget_set_default_colormap (GdkColormap *colormap)'''
		_gtk.gtk_widget_set_default_colormap(self._widget, colormap)
	
	def setDefaultVisual(self, visual): 
		'''void gtk_widget_set_default_visual (GdkVisual *visual)'''
		_gtk.gtk_widget_set_default_visual(self._widget, visual)
	
	def setDefaultStyle(self): 
		'''void gtk_widget_set_default_style (GtkStyle *style)'''
		_gtk.gtk_widget_set_default_style(self._widget)
	
	def getDefaultColormap(self): 
		'''GdkColormap* gtk_widget_get_default_colormap (void)'''
		return _gtk.gtk_widget_get_default_colormap(self._widget)
	
	def getDefaultVisual(self): 
		'''GdkVisual* gtk_widget_get_default_visual (void)'''
		return _gtk.gtk_widget_get_default_visual(self._widget)
	
	def getDefaultStyle(self): 
		'''GtkStyle* gtk_widget_get_default_style (void)'''
		return _gtk.gtk_widget_get_default_style(self._widget)
	
	def dndDragSet(self, drag_enable, type_accept_list, numtypes): 
		'''void gtk_widget_dnd_drag_set(GtkWidget *widget, guint8 drag_enable, gchar **type_accept_list, guint numtypes)'''
		_gtk.gtk_widget_dnd_drag_set(self._widget, drag_enable, type_accept_list, numtypes)
	
	def dndDropSet(self, drop_enable, type_accept_list, numtypes, is_destructive_operation): 
		'''void gtk_widget_dnd_drop_set(GtkWidget *widget, guint8 drop_enable, gchar **type_accept_list, guint numtypes, guint8 is_destructive_operation)'''
		_gtk.gtk_widget_dnd_drop_set(self._widget, drop_enable, type_accept_list, numtypes, is_destructive_operation)
	
	def dndDataSet(self, event, data, data_numbytes): 
		'''void gtk_widget_dnd_data_set(GtkWidget *widget, GdkEvent *event, gpointer data, gulong data_numbytes)'''
		_gtk.gtk_widget_dnd_data_set(self._widget, event, data, data_numbytes)


class Container(Widget):
	"""An abstract class for holding other widgets."""
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._container = _ptrcast(_pointer, 'GtkContainer *')
		Widget.__init__(self, _pointer=_pointer)
		self._children = []

	def borderWidth(self, width):
		"""Set the border width around child widgets."""
		_gtk.gtk_container_border_width(self._container, width)

	def add(self, widget):
		"""Add a child widget to the container."""
		_gtk.gtk_container_add(self._container, widget._widget)
		self._children.append(widget)

	def remove(self, widget):
		"""Remove a child widget from the container."""
		_gtk.gtk_container_remove(self._container, widget._widget)
		self._children.remove(widget)

	def disableResize(self):
		"""Disable resizing of container and child widgets."""
		_gtk.gtk_container_disable_resize(self._container)

	def enableResize(self):
		"""Enable resizing of container and child widgets."""
		_gtk.gtk_container_enable_resize(self._container)

	def blockResize(self):
		"""Do not allow the container widget to be resized"""
		_gtk.gtk_container_block_resize(self._container)

	def unblockResize(self):
		"""Allow the container widget to be resized"""
		_gtk.gtk_container_unblock_resize(self._container)

	def needResize(self):
		"""Emit the need resize signal."""
		return _gtk.gtk_container_need_resize(self._container)

	def focus(self):
		"""Emit the focus signal."""
		return _gtk.gtk_container_focus(self._container)



class ProgressBar(Widget):
	def __init__(self, _pointer=None):
		'''GtkWidget* gtk_progress_bar_new (void)'''
		if not _pointer:
			_pointer = _gtk.gtk_progress_bar_new()
		self._progress_bar = _ptrcast(_pointer, 'GtkProgressBar *')
		Widget.__init__(self, _pointer=_pointer)

	def update(self, percentage): 
		'''void gtk_progress_bar_update (GtkProgressBar *pbar, gfloat percentage)'''
		_gtk.gtk_progress_bar_update(self._progress_bar, percentage)


class Button(Container):
	def __init__(self, label=None, _pointer=None):
		if not _pointer:
			if label:
				_pointer = _gtk.gtk_button_new_with_label(label)
			else:
				_pointer = _gtk.gtk_button_new()
		self._button = _ptrcast(_pointer, 'GtkWidget *')
		Container.__init__(self, _pointer=_pointer)

	def buttonPressed(self):
		"""Emit the pressed signal."""
		_gtk.gtk_button_pressed(self._button)

	def buttonReleased(self):
		"""Emit the released signal."""
		_gtk.gtk_button_released(self._button)

	def buttonClicked(self):
		"""Emit the clicked signal."""
		_gtk.gtk_button_clicked(self._button)

	def buttonEnter(self):
		"""Emit the enter signal."""
		_gtk.gtk_button_enter(self._button)

	def buttonLeave(self):
		"""Emit the leave signal."""
		_gtk.gtk_button_leave(self._button)


class ToggleButton(Button):
	def __init__(self, label=None, _pointer=None):
		if not _pointer:
			if label:
				_pointer = _gtk.gtk_toggle_button_new_with_label(label)
			else:
				_pointer = _gtk.gtk_toggle_button_new()
		self._toggle_button = _ptrcast(_pointer, 'GtkToggleButton *')
		Button.__init__(self, _pointer=_pointer)

	def setMode(self, mode):
		_gtk.gtk_toggle_button_set_mode(self._toggle_button, mode)

	def setState(self, state):
		"""Set the state of a toggled button."""
		_gtk.gtk_toggle_button_set_state(self._toggle_button, state)

	def toggled(self):
		"""Emit the toggled signal."""
		_gtk.gtk_toggle_button_toggled(self._toggle_button)


class CheckButton(ToggleButton):
	def __init__(self, label=None, _pointer=None):
		if not _pointer:
			if label:
				_pointer = _gtk.gtk_check_button_new_with_label(label)
			else:
				_pointer = _gtk.gtk_check_button_new()
		self._check_button = _ptrcast(_pointer, 'GtkCheckButton *')
		ToggleButton.__init__(self, _pointer=_pointer)


class RadioButton(CheckButton):
	def __init__(self, group=None, label=None, _pointer=None):
		if not _pointer:
			if group:
				if label:
					_pointer = _gtk.gtk_radio_button_new_with_label_from_widget(label, 
                                                                   group._radiobutton)
				else:
					_pointer = _gtk.gtk_radio_button_new_from_widget(group._radiobutton)
			else:
				if label:
					_pointer = _gtk.gtk_radio_button_new_with_label_from_widget(label)
				else:	
					_pointer = _gtk.gtk_radio_button_new()
		self._radiobutton = _ptrcast(_pointer, 'GtkRadioButton *')
		CheckButton.__init__(self, _pointer=_pointer)


class OptionMenu(Button):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_option_menu_new()
		self._option_menu = _ptrcast(_pointer, 'GtkOptionMenu *')
		Button.__init__(self, _pointer=_pointer)
		self._option_menu_data = None

	def getMenu(self): 
		'''GtkWidget* gtk_option_menu_get_menu (GtkOptionMenu *option_menu)'''
		w = _gtk.gtk_option_menu_get_menu(self._option_menu)
		return _get_instance(w)
	
	def setMenu(self, menu): 
		'''void gtk_option_menu_set_menu (GtkOptionMenu *option_menu, GtkWidget *menu)'''
		_gtk.gtk_option_menu_set_menu(self._option_menu, menu._widget)
		self._option_menus_data = menu
	
	def removeMenu(self): 
		'''void gtk_option_menu_remove_menu (GtkOptionMenu *option_menu)'''
		_gtk.gtk_option_menu_remove_menu(self._option_menu)
		self._option_menu_data = None
	
	def setHistory(self, index): 
		'''void gtk_option_menu_set_history (GtkOptionMenu *option_menu, gint index)'''
		_gtk.gtk_option_menu_set_history(self._option_menu, index)
	

class Box(Container):
	"""An abstract container widget.

	A box provides an abstraction for organizing the position and
	size of widgets. Widgets in a box are layed out horizontally or
	vertically. By using a box widget appropriately, a programmer can
	control how widgets are positioned and how they will be allocated
	space when a window gets resized.
	"""
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._box = _ptrcast(_pointer, 'GtkBox *')
		Container.__init__(self, _pointer=_pointer)

	def packStart(self, child, expand=TRUE, fill=TRUE, padding=0):
		"""Add a child to the front of the box."""
		_gtk.gtk_box_pack_start(self._box, child._widget,
							expand, fill, padding)
		self._children.append(child)

	def packEnd(self, child, expand=TRUE, fill=TRUE, padding=0):
		"""Add a child to the end of the box"""
		_gtk.gtk_box_pack_end(self._box, child._widget,
							expand, fill, padding)
		self._children.append(child)

	def setHomogeneous(self, homogeneous):
		"""Control wether all children are of equal size"""
		_gtk.gtk_box_set_homogeneous(self._box, homogeneous)

	def setSpacing(self, spacing):
		"""Control spacing between children"""
		_gtk.gtk_box_set_spacing(self._box, spacing)


class HBox(Box):
	"""A container widget for packing widgets horizontally.

	"""
	def __init__(self, homogeneous=FALSE, spacing=0, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_hbox_new(homogeneous, spacing)
		self._hbox = _ptrcast(_pointer, 'GtkHBox *')
		Box.__init__(self, _pointer=_pointer)
	

class VBox(Box):
	"""A container widget for packing widgets vertically."""
	def __init__(self, homogeneous=FALSE, spacing=0, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_vbox_new(homogeneous, spacing)
		self._vbox = _ptrcast(_pointer, 'GtkVBox *')
		Box.__init__(self, _pointer=_pointer)


class Table(Container):
	"""A container widget for packing widgets in rows and columns."""
	def __init__(self, rows=1, columns=1, homogeneous=FALSE, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_table_new(rows, columns, homogeneous)
		self._table = _ptrcast(_pointer, 'GtkTable *')
		Container.__init__(self, _pointer=_pointer)

	def attach(self, child, left, right, top, bottom, 
			xoptions=FILL|EXPAND, yoptions=FILL|EXPAND, xpadding=0, ypadding=0):
		"""Attach a child widget to a table."""
		_gtk.gtk_table_attach(self._table, child._widget, left, right, top, bottom,
			xoptions, yoptions, xpadding, ypadding)
		self._children.append(child)

	def setRowSpacing(self, row, spacing):
		"""Set the spacing between two rows."""
		_gtk.gtk_table_set_row_spacing(self._table, row, spacing)

	def setColSpacing(self, column, spacing):
		"""Set the spacing between two columns."""
		_gtk.gtk_table_set_col_spacing(self._table, column, spacing)

	def setRowSpacings(self, spacing):
		"""Set the spacing between all rows."""
		_gtk.gtk_table_set_row_spacings(self._table, spacing)

	def setColSpacings(self, spacing):
		"""Set the spacing between all columns."""
		_gtk.gtk_table_set_col_spacings(self._table, spacing)
		


class Bin(Container):
	"""An abstract container widget."""
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._bin = _ptrcast(_pointer, 'GtkBin *')
		Container.__init__(self, _pointer=_pointer)


class Alignment(Bin):
	"""Allows control over how widgets expand to fill space.

	Most widgets expand to fill all available space.  The alignment
	widget allows the programmer to specify how the widget expands to
	fill its space.
	"""
	def __init__(self, xalign=0.0, yalign=0.0, xscale=0.5, yscale=0.5, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_aligment_new(xalign, yalign, xscale, yscale)
		self._alignment = _ptrcast(_pointer, 'GtkAlignment *')
		Bin.__init__(self, _pointer=_pointer)

	def set(self, xalign=0.0, yalign=0.0, xscale=0.5, yscale=0.5):
		"""The xalign and yalign options specify how to position the
		child widget when it is not allocated all the space
		available to it (because the xscale and/or yscale options
		are less than 1.0). If an alignment value is 0.0 the widget
		is positioned to the left (or top) of its allocated space.
		An alignment value of 1.0 positions the widget to the right
		(or bottom) of its allocated space.  A common usage is to
		specify xalign and yalign to be 0.5 which causes the widget
		to be centered within its allocated area.
		"""
		_gtk.gtk_alignment_set(self._alignment, xalign, yalign, xscale, yscale)
		


class Frame(Bin):
	def __init__(self, label='', _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_frame_new(label)
		self._frame = _ptrcast(_pointer, 'GtkFrame *')
		Bin.__init__(self, _pointer=_pointer)

	def setLabel(self, label):
		_gtk.gtk_frame_set_label(self._frame, label)

	def setLabelAlign(self, xalign, yalign):
		_gtk.gtk_frame_set_align(self._frame, xalign, yalign)

	def setShadowType(self, type):
		_gtk.gtk_frame_set_shadow_type(self._frame, type)


class EventBox(Bin):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_event_box_new()
		self._event_box = _ptrcast(_pointer, 'GtkEventBox *')
		Bin.__init__(self, _pointer=_pointer)


class Item(Bin):
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._item = _ptrcast(_pointer, 'GtkItem *')
		Bin.__init__(self, _pointer=_pointer)

	def select(self):
		"""Emit the select signal."""
		_gtk.gtk_item_select(self._item)

	def deselect(self):
		"""Emit the deselect signal."""
		_gtk.gtk_item_deselect(self._item)

	def toggle(self):
		"""Emit the toggled signal."""
		_gtk.gtk_item_toggle(self._item)


class ListItem(Item):
	def __init__(self, label=None, _pointer=None):
		if not _pointer:
			if label:
				_pointer = _gtk.gtk_list_item_new_with_label(label)
			else:
				_pointer = _gtk.gtk_list_item_new()
		self._list_item = _ptrcast(_pointer, 'GtkListItem *')
		Item.__init__(self, _pointer=_pointer)

	def select(self):
		"""Emit the select signal."""
		_gtk.gtk_list_item_select(self._list_item)

	def deselect(self):
		"""Emit the deselect signal."""
		_gtk.gtk_list_item_deselect(self._list_item)
		

class MenuItem(Item):
	def __init__(self, label=None, _pointer=None):
		if not _pointer:
			if label:
				_pointer = _gtk.gtk_menu_item_new_with_label(label)
			else:
				_pointer = _gtk.gtk_menu_item_new()
		self._menu_item = _ptrcast(_pointer, 'GtkMenuItem *')
		Item.__init__(self, _pointer=_pointer)
		self._submenu_data = None

	def setSubmenu(self, widget):
		self._submenu_data = widget
		_gtk.gtk_menu_item_set_submenu(self._menu_item, widget._widget)

	def setPlacement(self, placement):
		_gtk.gtk_menu_item_set_placement(self._menu_item, placement)

	def acceleratorSize(self):
		_gtk.gtk_menu_item_accelerator_size(self._menu_item)

	def acceleratorText(self, text):
		_gtk.gtk_menu_item_accelerator_text(self._menu_item, text)

	def configure(self, show_toggle_indicator, show_submenu_indicator):
		_gtk.gtk_menu_item_configure(self._menu_item,
				show_toggle_indicator, show_submenu_indicator)

	def select(self):
		_gtk.gtk_menu_item_select(self._menui_tem)

	def deselect(self):
		_gtk.gtk_menu_item_deselect(self._menu_item)

	def activate(self):
		_gtk.gtk_menu_item_activate(self._menu_item)

	def rightJustify(self):
		_gtk.gtk_menu_item_right_justify(self._menu_item)
		

class CheckMenuItem(MenuItem):
	def __init__(self, label=None, _pointer=None):
		if not _pointer:
			if label:
				_pointer = _gtk.gtk_check_menu_item_new_with_label(label)
			else:
				_pointer = _gtk.gtk_check_menu_item_new()
		self._check_menu_item = _ptrcast(_pointer, 'GtkCheckMenuItem *')
		MenuItem.__init__(self, _pointer=_pointer)

	def setState(self, state): 
		'''void gtk_check_menu_item_set_state (GtkCheckMenuItem *check_menu_item, gint state)'''
		_gtk.gtk_check_menu_item_set_state(self._check_menu_item, state)
	
	def toggled(self): 
		'''void gtk_check_menu_item_toggled (GtkCheckMenuItem *check_menu_item)'''
		_gtk.gtk_check_menu_item_toggled(self._check_menu_item)


class MenuShell(Container):
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._menu_shell = _ptrcast(_pointer, 'GtkMenuShell *')
		Container.__init__(self, _pointer=_pointer)
		self._menu_shell_children = []

	def append(self, child):
		self._menu_shell_children.append(child)
		_gtk.gtk_menu_shell_append(self._menu_shell, child._widget)

	def prepend(self, child):
		self._menu_shell_children.append(child)
		_gtk.gtk_menu_shell_prepend(self._menu_shell, child._widget)

	def insert(self, child, position):
		self._menu_shell_children.append(child)
		_gtk.gtk_menu_shell_insert(self._menu_shell, child._widget, position)

	def deactivate(self):
		_gtk.gtk_menu_shell_insert(self._menu_shell)


class Menu(MenuShell):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_menu_new()
		self._menu = _ptrcast(_pointer, 'GtkMenu *')
		MenuShell.__init__(self, _pointer=_pointer)
		self._menu_children = []

	def append(self, child):
		self._menu_children.append(child)
		_gtk.gtk_menu_append(self._menu, child._widget)

	def prepend(self, child):
		self._menu_children.append(child)
		_gtk.gtk_menu_prepend(self._menu, child._widget)

	def insert(self, child, position):
		self._menu_children.append(child)
		_gtk.gtk_menu_insert(self._menu, child._widget, position)

	def popup(self):
		# TODO: this needs a function pointer
		pass
	
	def popdown(self):
		_gtk.gtk_menu_popdown(self._menu)
		
	def getActive(self):
		# TODO: this should return a python class
		pass
	
	def setActive(self, index):
		_gtk.gtk_menu_set_active(self._menu, index)
		
	def setAcceleratorTable(self, table):
		_gtk.gtk_menu_set_accelerator_table(table._accelerator_table)
	


class MenuBar(MenuShell):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_menu_bar_new()
		self._menu_bar = _ptrcast(_pointer, 'GtkMenuBar *')
		MenuShell.__init__(self, _pointer=_pointer)
		self._menu_bar_children = []

	def append(self, child):
		self._menu_bar_children.append(child)
		_gtk.gtk_menu_bar_append(self._menu_bar, child._widget)

	def prepend(self, child):
		self._menu_bar_children.append(child)
		_gtk.gtk_menu_bar_prepend(self._menu_bar, child._widget)

	def insert(self, child, position):
		self._menu_bar_children.append(child)
		_gtk.gtk_menu_bar_insert(self._menu_bar, child._widget, position)



class Window(Bin):
	def __init__(self, type=WINDOW_TOPLEVEL, title=None, 
				wm_name=None, wm_class=None, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_window_new(type)
		self._window = _ptrcast(_pointer, 'GtkWindow *')
		Bin.__init__(self, _pointer=_pointer)
		if title:
			self.setTitle(title)
		if wm_name and wm_class:
			self.setWMClass(wm_name, wm_class)

	def setTitle(self, title):
		_gtk.gtk_window_set_title(self._window, title)

	def setWMClass(self, wm_name, wm_class):
		_gtk.gtk_window_set_wmclass(self._window, wm_name, wm_class)

	def setFocus(self, widget):
		_gtk.gtk_window_set_focus(self._window, widget._widget)



class ScrolledWindow(Container):
	def __init__(self, vadjust=_ptrcast(NULL, 'GtkAdjustment *'), 
				hadjust=_ptrcast(NULL, 'GtkAdjustment *'),
				_pointer=None):
		if not _pointer:
				_pointer = _gtk.gtk_scrolled_window_new(vadjust, hadjust)
				self._vadjust_data = vadjust
				self._hadjust_data = hadjust
		self._scrolled_window = _ptrcast(_pointer, 'GtkScrolledWindow *')
		Container.__init__(self, _pointer=_pointer)

	def getHAdjustment(self):
		return _get_instance(_gtk.gtk_scrolled_window_get_hadjustment(self._scrolled_window))

	def getVAdjustment(self):
		return _get_instance(_gtk.gtk_scrolled_window_get_vadjustment(self._scrolled_window))

	def setPolicy(self, hpolicy=POLICY_AUTOMATIC, vpolicy=POLICY_AUTOMATIC):
		_gtk.gtk_scrolled_window_set_policy(self._scrolled_window,
				hpolicy, vpolicy)



class Dialog(Window):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_dialog_new()
		self._dialog = _ptrcast(_pointer, 'GtkDialog *')
		Window.__init__(self, _pointer=_pointer)


class FileSelection(Window):
	def __init__(self, fileselection=None, title='', _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_file_selection_new(title)
		self._fileselection = _ptrcast(_pointer, 'GtkFileSelection *')
		Window.__init__(self, _pointer=_pointer)
		# give access to internal widgets
		self.cancel_button = Button(_pointer= \
			_gtk._GtkFileSelection_cancel_button_get(self._fileselection))
		self.dir_list = List(_pointer= \
			_gtk._GtkFileSelection_dir_list_get(self._fileselection))
		self.file_list = List(_pointer= \
			_gtk._GtkFileSelection_file_list_get(self._fileselection))
		self.help_button = Button(_pointer= \
			_gtk._GtkFileSelection_help_button_get(self._fileselection))
		self.main_vbox = VBox(_pointer= \
			_gtk._GtkFileSelection_main_vbox_get(self._fileselection))
		self.ok_button = Button(_pointer= \
			_gtk._GtkFileSelection_ok_button_get(self._fileselection))
		self.selection_entry = Entry(_pointer= \
			_gtk._GtkFileSelection_selection_entry_get(self._fileselection))
		#self.selection_text = Text(_pointer= \
		#	_gtk._GtkFileSelection_selection_text_get(self._fileselection))

	def setFilename(self, filename):
		_gtk.gtk_file_selection_set_filename(self._fileselection, filename)

	def getFilename(self):
		return _gtk.gtk_file_selection_get_filename(self._fileselection)


# TODO: change this to understand __getitem__, etc., it is the Python way :)
class List(Container):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_list_new()
		self._list = _ptrcast(_pointer, 'GtkList *')
		Container.__init__(self, _pointer=_pointer)
		self._list_items = []

	def _make_glist(self, items):
		"""Create a Glist from a python list"""
		if not items:
			return 'NULL'
		else:
			list = _gtk.g_list_alloc1(items[0]._list_item)
			for i in items[1:]:
				list = _gtk.g_list_append(list, _ptrcast(i._list_item, 'gpointer'))
			return list

	def insertItems(self, items, position):
		if not items:
			return
		self._list_items = operator.concat(self._list_items, items)
		glist = self._make_glist(items)
		_gtk.gtk_list_insert_items(self._list, glist, position)

	def appendItems(self, items):
		self.insertItems(items, -1) # could be dangerous, using undocumented behavior

	def prependItems(self, items):
		self.insertItems(items, 0) # could be dangerous, using undocumented behavior

	def removeItems(self, items):
		if not items:
			return
		for i in items:
			self._list_items.remove(i)
		glist = self._make_glist(items)
		_gtk.gtk_list_remove_items(self._list, glist)

	def clearItems(self, start, end):
		_gtk.gkt_list_clear_items(self._list, start, end)

	def selectItem(self, item):
		_gtk.gtk_list_select_item(self._list, item)

	def unselectItem(self, item):
		_gtk.gtk_list_unselect_item(self._list, item)

	def selectChild(self, widget):
		_gtk.gtk_list_select_child(self._list, widget._widget)

	def unselectChild(self, widget):
		_gtk.gtk_list_unselect_child(self._list, widget._widget)

	def childPosition(self, widget):
		return _gtk.gtk_list_child_position(self._list, widget._widget)

	def setSelectMode(self, mode):
		_gtk.gtk_list_set_selection_mode(self._list, mode)


class Separator(Widget):
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._separator = _ptrcast(_pointer, 'GtkSeparator *')
		Widget.__init__(self, _pointer=_pointer)

class HSeparator(Separator):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_hseparator_new()
		self._hseparator = _ptrcast(_pointer, 'GtkHSeparator *')
		Separator.__init__(self, _pointer=_pointer)

class VSeparator(Separator):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_vseparator_new()
		self._vseparator = _ptrcast(_pointer, 'GtkVSeparator *')
		Separator.__init__(self, _pointer=_pointer)


class Misc(Widget):
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._misc = _ptrcast(_pointer, 'GtkMisc *')
		Widget.__init__(self, _pointer=_pointer)
	
	def setAlignment(self, xalign, yalign):
		_gtk.gtk_misc_set_alignment(self._misc, xalign, yalign)

	def setPadding(self, xpad, ypad):
		_gtk.gtk_misc_set_padding(self._misc, xpad, ypad)


class Arrow(Misc):
	"""Display an arrow in one of the four directions."""
	def __init__(self, type, shadow=SHADOW_NONE, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_arrow_new(type, shadow)
		self._arrow = _ptrcast(_pointer, 'GtkArrow *')
		Misc.__init__(self, _pointer=_pointer)

	def set(self, type, shadow=SHADOW_NONE):
		"""Set the properties of an arrow."""
		_gtk.gtk_arrow_set(self._arrow, type, shadow)


class Label(Misc):
	def __init__(self, label='', _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_label_new(label)
		self._label = _ptrcast(_pointer, 'GtkLabel *')
		Misc.__init__(self, _pointer=_pointer)

	def set(self, label):
		_gtk.gtk_label_set(self._label, label)

	def setJustify(self, jtype):
		_gtk.gtk_label_set_justify(self._label, jtype)

	def get(self):
		return _gtk.gtk_label_get(self._label)


class Pixmap(Misc):
	def __init__(self, parent, xpm_file, _pointer=None):
		"""Create a pixmap widget.

		Takes a widget to draw inside of and a Python file object to read
		the xpm data from.
		"""
		if not _pointer:
			# TODO: fix this temp file stupidity, pixmap_new should take
			# the data directly
			import tempfile, os
			temp_name = tempfile.mktemp()
			temp = open(temp_name, 'w')
			temp.write(xpm_file.read())
			temp.close()
			_pointer = _gtk.gtk_pixmap_new(parent._widget, temp_name)
			os.unlink(temp_name)
		self._pixmap = _ptrcast(_pointer, 'GtkPixmap *')
		Misc.__init__(self, _pointer=_pointer)

class Entry(Widget):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_entry_new()
		self._entry = _ptrcast(_pointer, 'GtkEntry *')
		Widget.__init__(self, _pointer=_pointer)

	def setText(self, text):
		_gtk.gtk_entry_set_text(self._entry, text)

	def appendText(self, text):
		_gtk.gtk_entry_append_text(self._entry, text)

	def prependText(self, text):
		_gtk.gtk_entry_prepend_text(self._entry, text)

	def setPosition(self, pos):
		_gtk.gtk_entry_set_position(self._entry, pos)

	def getText(self):
		return _gtk.gtk_entry_get_text(self._entry)


class Notebook(Container):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_notebook_new()
		self._notebook = _ptrcast(_pointer, 'GtkNotebook *')
		Container.__init__(self, _pointer=_pointer)
		self._notebook_pages = []

	def appendPage(self, child, tab_label):
		self._notebook_pages.append(child)
		_gtk.gtk_notebook_append_page(self._notebook, child._widget, tab_label._widget)

	def prependPage(self, child, tab_label):
		self._notebook_pages = [child] + self._notebook_pages
		_gtk.gtk_notebook_prepend_page(self._notebook, child._widget, tab_label._widget)

	def insertPage(self, child, tab_label, position):
		self._notebook_pages.insert(position, child)
		_gtk.gtk_notebook_insert_page(self._notebook, child._widget, tab_label._widget, position)

	def removePage(self, page_num):
		# this is a little scary
		del self._notebook_pages[page_num]
		_gtk.gtk_notebook_remove_page(self._notebook, page_num)

	def currentPage(self):
		return _gtk.gtk_notebook_current_page(self._notebook)

	def setPage(self, page_num):
		_gtk.gtk_notebook_set_page(self._notebook, page_num)

	def nextPage(self):
		_gtk.gtk_notebook_next_page(self._notebook)

	def prevPage(self):
		_gtk.gtk_notebook_prev_page(self._notebook)

	def setTabPos(self, pos):
		_gtk.gtk_notebook_set_tab_pos(self._notebook, pos)
		
	def setShowTabs(self, show_tabs):
		_gtk.gtk_notebook_set_tab_pos(self._notebook, show_tabs)

	def setShowBorder(self, show_border):
		_gtk.gtk_notebook_set_show_border(self._notebook, show_border)


class Tooltips:
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_tooltips_new()
		self._tooltips = _ptrcast(_pointer, 'GtkTooltips *')
		
	def destroy(self):
		_gtk.gtk_tooltips_destroy(self._tooltips)

	def ref(self):
		_gtk.gtk_tooltips_ref(self._tooltips)

	def unref(self):
		_gtk.gtk_tooltips_unref(self._tooltips)

	def enable(self):
		_gtk.gtk_tooltips_enable(self._tooltips)

	def disable(self):
		_gtk.gtk_tooltips_disable(self._tooltips)

	def setDelay(self, delay):
		_gtk.gtk_tooltips_set_delay(self._tooltips, delay)

	def setTips(self, widget, text):
		_gtk.gtk_tooltips_set_tips(self._tooltips, widget._widget, text)
		widget._tooltip_data = self # TODO: this doesn't seem nice

	def setColors(self, bg=(0,1,1), fg=(0,0,0)):
		'''The color is specified by percent of (Red, Green, Blue)'''
		if max(bg) > 1.0 or max(fg) > 1.0:
			raise 'Error: invalid color value'
		if min(bg) < 0.0 or min(fg) < 0.0:
			raise 'Error: invalid color value'
		bg = map(lambda x: int(float(x)*65535), bg)
		fg = map(lambda x: int(float(x)*65535), fg)
		_gtk.gtk_tooltips_set_colors(self._tooltips, 
				bg[0], bg[1], bg[2],
				fg[0], fg[1], fg[2])


class ButtonBox(Box):
	def __init__(self, _pointer=None):
		if not _pointer:
			raise 'Error: this class has no init method'
		self._button_box = _ptrcast(_pointer, 'GtkButtonBox *')
		Box.__init__(self, _pointer=_pointer)


class HButtonBox(ButtonBox):
	def __init__(self, _pointer=None):
		if not _pointer:
			_pointer = _gtk.gtk_hbutton_box_new()
		self._hbutton_box = _ptrcast(_pointer, 'GtkHbuttonBox *')
		ButtonBox.__init__(self, _pointer=_pointer)

	def getSpacingDefault(self): 
		'''gint gtk_hbutton_box_get_spacing_default (void)'''
		return _gtk.gtk_hbutton_box_get_spacing_default(self._hbutton_box)
	
	def getLayoutDefault(self): 
		'''gint gtk_hbutton_box_get_layout_default (void)'''
		return _gtk.gtk_hbutton_box_get_layout_default(self._hbutton_box)
	
	def setSpacingDefault(self): 
		'''void gtk_hbutton_box_set_spacing_default (gint spacing)'''
		_gtk.gtk_hbutton_box_set_spacing_default(self._hbutton_box)
	
	def setLayoutDefault(self): 
		'''void gtk_hbutton_box_set_layout_default (gint layout)'''
		_gtk.gtk_hbutton_box_set_layout_default(self._hbutton_box)


