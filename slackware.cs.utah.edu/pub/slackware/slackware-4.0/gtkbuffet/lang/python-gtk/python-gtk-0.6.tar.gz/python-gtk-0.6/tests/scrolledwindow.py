import gtk

class Dialog(gtk.Window):
	def __init__(self, title='untitled'):
		gtk.Window.__init__(self, title=title)
		self.vbox = gtk.VBox()
		self.add(self.vbox)

	def show(self):
		self.vbox.show()
		gtk.Window.show(self)



window = Dialog('Dialog')
window.signalConnect('destroy', gtk.main_quit)
window.borderWidth(0)


scrolled_window = gtk.ScrolledWindow()
scrolled_window.borderWidth(10)
scrolled_window.setPolicy(gtk.POLICY_AUTOMATIC, gtk.POLICY_ALWAYS)
window.vbox.packStart(scrolled_window, gtk.TRUE, gtk.TRUE, 0)
scrolled_window.show()

table = gtk.Table(10, 10, gtk.FALSE)
table.setRowSpacings(10)
table.setColSpacings(10)

scrolled_window.add(table)
table.show()

for i in range(10):
	for j in range(10):
		button = gtk.ToggleButton('Button (%d, %d)' % (i, j))
		table.attach(button, i, i+1, j, j+1)
		button.show()

window.show()
gtk.main()
