import gtk

count = 0
def foo():
	global count

	if count < 10:
		print 'foo', count
		count = count + 1
		return 1

gtk.timeout_add(100, foo)
window = gtk.Window()
window.borderWidth(10)
button = gtk.Button("Quit")
button.signalConnect("clicked", gtk.main_quit)
window.add(button)
button.show()
window.show()
gtk.main()
