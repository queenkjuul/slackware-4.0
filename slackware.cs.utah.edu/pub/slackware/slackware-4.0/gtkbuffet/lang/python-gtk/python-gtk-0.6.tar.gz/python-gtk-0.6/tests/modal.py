import gtk

def quit():
	gtk.main_quit()


w1 = gtk.Window()
w1.signalConnect("destroy", quit)
w1.borderWidth(10)
button = gtk.Button("Hello World")
button.signalConnect("clicked", quit)
w1.add(button)
button.show()
w1.show()

w2 = gtk.Window(title='Hello')
w2.borderWidth(10)
w2.show()
w2.grabFocus()

gtk.main()
