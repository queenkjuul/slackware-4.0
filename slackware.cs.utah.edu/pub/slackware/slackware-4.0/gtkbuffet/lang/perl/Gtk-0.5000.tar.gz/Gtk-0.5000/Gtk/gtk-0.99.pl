# This configuration data is used for versions of Gtk from 0.99 onward

add_defs "gtk-0.99.defs";
add_typemap "gtk-0.99.typemap";

add_xs "GtkSelection.xs";
add_boot "Gtk::Selection";
