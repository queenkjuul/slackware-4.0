
add_defs 'pkg-panel.defs';
add_typemap 'pkg-panel.typemap';

add_headers '<panel-types.h>', '<applet-lib.h>', '<applet-widget.h>';

