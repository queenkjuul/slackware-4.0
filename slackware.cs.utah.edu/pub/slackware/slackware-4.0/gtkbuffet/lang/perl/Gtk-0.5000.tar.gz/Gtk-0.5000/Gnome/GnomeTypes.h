
#ifndef _Gnome_Types_h_
#define _Gnome_Types_h_

typedef GnomeDesktopEntry * Gnome__DesktopEntry;

#endif /*_Gnome_Types_h_*/
