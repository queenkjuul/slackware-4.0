# This configuration data is used only for version Gtk 0.99.x

add_defs 'gtk-0.99-only.defs';

add_xs "GtkAcceleratorTable.xs";
add_boot "Gtk::AcceleratorTable";
