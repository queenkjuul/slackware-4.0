# This configuration data is used for versions of Gtk from 1.3.x onward

add_defs "gtk-1.3.defs";
