# This configuration data is used for versions of Gtk from 1.0.x onward

add_defs "gtk-1.0.defs";
#add_defs "gtk-1.0.typemap";

#add_xs "GtkAcceleratorTable.xs";
#add_boot "Gtk::AcceleratorTable";

