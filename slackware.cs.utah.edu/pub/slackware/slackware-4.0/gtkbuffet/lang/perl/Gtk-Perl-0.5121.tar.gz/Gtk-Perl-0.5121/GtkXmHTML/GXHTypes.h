
#ifndef _PERL_GTK_XM_HTML_TYPES_
#define _PERL_GTK_XM_HTML_TYPES_

typedef int XmHTMLCallbackReason;

#endif
