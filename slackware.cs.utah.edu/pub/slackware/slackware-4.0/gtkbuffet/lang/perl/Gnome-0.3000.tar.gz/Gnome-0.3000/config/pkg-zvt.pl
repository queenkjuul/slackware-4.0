
add_headers (qw( <zvt/zvtterm.h> ));

$libs = "-lzvt $libs";
