

#add_xs qw( Gnome.xs GnomeColorSelector.xs );
add_headers '<panel-types.h>', '<applet-lib.h>', '<applet-widget.h>';
#	
#$pm->{'Gnome.pm'} = '$(INST_LIBDIR)/Gtk/Gnome.pm';
#	
## use gnomeConf.sh...
#$inc = $ENV{GNOME_INCLUDEDIR} . " " . $inc;
$libs = "-lpanel_applet -lORBit -lIIOP -lORBitutil $libs"; #hack hack

