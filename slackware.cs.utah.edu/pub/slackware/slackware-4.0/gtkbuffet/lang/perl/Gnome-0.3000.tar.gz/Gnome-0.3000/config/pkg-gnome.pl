

add_xs qw( Gnome.xs GnomeColorSelector.xs GnomeDialogUtil.xs GnomeDNS.xs GnomeGeometry.xs GnomeICE.xs);
add_headers "<argp.h>", "<libgnome/libgnome.h>", "<libgnomeui/libgnomeui.h>", '"GnomeTypes.h"';
add_boot "Gnome::ColorSelector", "Gnome::DialogUtil", "Gnome::DNS", "Gnome::Geometry", "Gnome::ICE";

	
$pm->{'Gnome.pm'} = '$(INST_LIBDIR)/Gtk/Gnome.pm';
	
# use gnomeConf.sh...
$inc = $ENV{GNOME_INCLUDEDIR} . " " . $inc;
$libs = "$ENV{GNOMEUI_LIBS} -lintl $libs"; #hack hack

