
#ifndef _Gnome_Types_h_
#define _Gnome_Types_h_

typedef GnomeColorSelector * Gnome__ColorSelector;
typedef GnomeDesktopEntry * Gnome__DesktopEntry;

#endif /*_Gnome_Types_h_*/
