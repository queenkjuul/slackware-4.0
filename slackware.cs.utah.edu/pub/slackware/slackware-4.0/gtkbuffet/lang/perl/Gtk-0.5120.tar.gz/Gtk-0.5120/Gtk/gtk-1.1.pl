
#add_typemap "gtk-1.1.typemap";
add_defs "gtk-1.1.defs";

add_xs "GtkAccelGroup.xs", "GtkProgressBar-1.1.xs";
add_boot "Gtk::ProgressBar11";


