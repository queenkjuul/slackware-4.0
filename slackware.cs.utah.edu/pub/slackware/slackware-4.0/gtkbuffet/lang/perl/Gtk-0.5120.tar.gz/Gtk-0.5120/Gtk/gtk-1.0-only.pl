# This configuration data is used only for version Gtk 1.0.x

add_defs "gtk-1.0-only.defs";

add_xs "GtkAcceleratorTable.xs";
add_boot "Gtk::AcceleratorTable";

