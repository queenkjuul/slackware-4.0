/*

  Version for use with SmallEiffel and GTK+ 1.0.4

 */

#include <gtk/gtk.h>
#include "eiffel.h"

/* argv and argc set by SmallEiffel runtime */
extern int se_argc;
extern char**se_argv;

/* Pass command line arguments to the GTK initialization code */
void c_gtk_init_tool_kit () {
  gtk_init (&se_argc, &se_argv);
}

/* Signal callback, just call Eiffel */
void c_signal_callback (GtkObject *w, gpointer data) {
  eiffel_gtk_signal_handler ((void *)data);
}

void c_event_callback (GtkObject *w, GdkEvent *ev,  gpointer data) 
{
  eiffel_gtk_signal_handler ((void *)data);
}

/* Connect an callback to widget/event pair */
gint c_gtk_signal_connect (GtkObject *widget,
						   gchar *name, 
						   void *object) {

  int name_len;
  /* TODO: This code is little hokey. The callback routine is little different */
  /* for signals whose name end with "*_event". For now just look at the */
  /* string. Later maybe I'll come up with a better way of handling this */
  name_len = strlen (name);
  if (name_len > 6)
	{
	  if (strcmp (&name [name_len - 6], "_event") == 0)
		return (gtk_signal_connect (widget, name, 
									GTK_SIGNAL_FUNC(c_event_callback), 
									(gpointer)object));		
	}
  return (gtk_signal_connect (widget, name, 
							  GTK_SIGNAL_FUNC(c_signal_callback),
							  (gpointer)object));

}

/* Create a pixmap widget from an xpm file */
GtkWidget *c_gtk_pixmap_create_from_xpm (GtkWidget *widget, char *fname) 
{
  GdkBitmap *mask;
  GdkPixmap *pixmap;
  
  /* Widget must be realized before we can attach a pixmap to it */
  if (widget->window == NULL)
	gtk_widget_realize (widget);
  pixmap = gdk_pixmap_create_from_xpm (widget->window,
									   &mask, 
									   &widget->style->bg[GTK_STATE_NORMAL],
									   fname);
  return (gtk_pixmap_new (pixmap, mask));
}


/*--------- Widget utility functions ------*/

/* Return a state of a toggle button */
int c_gtk_toggle_button_active (GtkWidget *button) 
{
  return (GTK_TOGGLE_BUTTON(button)->active);
}

/* Set widget flags */
void c_gtk_widget_set_flags (GtkWidget *widget, int flags) 
{
  GTK_WIDGET_SET_FLAGS (widget, flags);
}

char c_gtk_widget_visible (GtkWidget *w) 
{
  if (GTK_WIDGET_VISIBLE(w))
	return (1);
  else
	return (0);
}

int c_gtk_widget_width (GtkWidget *w)
{
  int result = 0;
  if (w != NULL)
	result = w->allocation.width;
  return (result);
}

int c_gtk_widget_height (GtkWidget *w)
{
  int result = 0;
  if (w != NULL)
	result = w->allocation.height;
  return (result);
}

GdkWindow *c_gtk_widget_window (GtkWidget *w) 
{
  return (w->window);
}

c_toolbar_callback (GtkObject *w, gpointer data) {
  eiffel_gtk_toolbar_handler ((void *)data);
}

/* Call back for buttons on a tool bar */
c_gtk_toolbar_append_item (GtkToolbar *toolbar, 
						   const char *text, 
						   const char *tip,
						   const char *private_tip,
						   GtkWidget *icon,
						   void *object)
{
  gtk_toolbar_append_item (toolbar, text, tip, private_tip, icon, 
						   (GtkSignalFunc)c_toolbar_callback,
						   object);
}
