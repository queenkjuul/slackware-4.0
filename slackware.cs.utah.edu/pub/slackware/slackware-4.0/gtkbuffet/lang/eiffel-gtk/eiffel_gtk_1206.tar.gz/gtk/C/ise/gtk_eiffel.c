/**********************************************

  Version:  0.2 - to be used with gtk+-1.0.4
                  and with ISE Eiffel 4.2.
  Date: 3/3/98

**************************************** */

#include <gtk/gtk.h>
#include "eif_eiffel.h"
#include "eif_argv.h"

typedef  struct callback_data {
  EIF_PROC rtn;
  EIF_OBJ obj;
  void *data;
} callback_data_t;


/* Pass command line arguments to the GTK initialization code */
/* In ISE's runtime there are references to these in "argv.h" */
void c_gtk_init_tool_kit () {
  gtk_init (&eif_argc, &eif_argv);
}

/* This function is actually called when the event occurs */
/* an it in turn calls Eiffel.                            */
void c_signal_callback (GtkObject *w, gpointer data) 
{
  callback_data_t *cbd;
  cbd = (callback_data_t *)data;
  /* Call Eiffel */
  /*  printf ("callback= %d object= %d cbd= %d\n", cbd->rtn, (cbd->obj), cbd); */
  (cbd->rtn)(cbd->obj);
}

/* This function is actually called when the event occurs */
/* an it in turn calls Eiffel.                            */
/* This function is called for signals named "*_event".   */
void c_event_callback (GtkObject *w, GdkEvent *ev,  gpointer data) 
{
  callback_data_t *cbd;
  cbd = (callback_data_t *)data;
  /* Call Eiffel */
  /*  printf ("callback= %d object= %d cbd= %d\n", cbd->rtn, (cbd->obj), cbd); */
  (cbd->rtn)(cbd->obj);
}


/* Connect a call back to a widget/event pair */
gint c_gtk_signal_connect (GtkObject *widget, 
						   gchar *name, 
						   EIF_PROC func,
						   EIF_OBJ object,
						   callback_data_t **p)
{
  callback_data_t *cbd;
  int name_len;

  eif_freeze (object);  
  /* TODO: Deallocation of this block needs to be done when the */
  /* widget is GCed.                                            */
  cbd = malloc (sizeof (callback_data_t));
  /* Return the pointer of the allocated block to Eiffel, so it
	 can be deallocated later
  */
  *p = cbd;
  cbd->rtn = func;
  cbd->obj = eif_access (object);
  /*  printf ("connect rtn= %d object= %d cbd= %d\n", cbd->rtn, (cbd->obj), cbd); */

  /* TODO: This code is little hokey. The callback routine is little different */
  /* for signals whose name end with "*_event". For now just look at the */
  /* string. Later maybe I'll come up with a better way of handling this */
  name_len = strlen (name);
  if (name_len > 6)
	{
	  if (strcmp (&name [name_len - 6], "_event") == 0)
		return (gtk_signal_connect (widget, name, 
									GTK_SIGNAL_FUNC(c_event_callback), 
									(gpointer)cbd));		
	}
  return (gtk_signal_connect (widget, name, 
							  GTK_SIGNAL_FUNC(c_signal_callback), 
							  (gpointer)cbd));
}



/* Create a pixmap widget from an xpm file */
GtkWidget *c_gtk_pixmap_create_from_xpm (GtkWidget *widget, char *fname) 
{
  GdkBitmap *mask;
  GdkPixmap *pixmap;
  
  /* Widget must be realized before we can attach a pixmap to it */
  if (widget->window == NULL)
	gtk_widget_realize (widget);
  pixmap = gdk_pixmap_create_from_xpm (widget->window,
									   &mask, 
									   &widget->style->bg[GTK_STATE_NORMAL],
									   fname);
  return (gtk_pixmap_new (pixmap, mask));
}


/*--------- Widget utility functions ------*/

/* Return a state of a toggle button */
int c_gtk_toggle_button_active (GtkWidget *button) 
{
  return (GTK_TOGGLE_BUTTON(button)->active);
}

/* Set widget flags */
void c_gtk_widget_set_flags (GtkWidget *widget, int flags) 
{
  GTK_WIDGET_SET_FLAGS (widget, flags);
}

EIF_BOOLEAN c_gtk_widget_visible (GtkWidget *w) 
{
  if (GTK_WIDGET_VISIBLE(w))
	return (1);
  else
	return (0);
}

EIF_INTEGER c_gtk_widget_width (GtkWidget *w)
{
  EIF_INTEGER result = 0;
  if (w != NULL)
	result = w->allocation.width;
  return (result);
}

EIF_INTEGER c_gtk_widget_height (GtkWidget *w)
{
  EIF_INTEGER result = 0;
  if (w != NULL)
	result = w->allocation.height;
  return (result);
}

GdkWindow *c_gtk_widget_window (GtkWidget *w) 
{
  return (w->window);
}

void c_free_call_back_block (callback_data_t *p) 
{
  if (p != NULL)
	free (p);
}


/* Call back for toolbar buttons */
void c_toolbar_callback (GtkObject *w, gpointer data) 
{
  callback_data_t *cbd;
  cbd = (callback_data_t *)data;
  /* Call Eiffel */
  /*  printf ("callback= %d object= %d cbd= %d\n", cbd->rtn, (cbd->obj), cbd); */
  (cbd->rtn)(cbd->obj);
}



/* Call back for buttons on a tool bar */
c_gtk_toolbar_append_item (GtkToolbar *toolbar, 
						   const char *text, 
						   const char *tip,
						   const char *private_tip,
						   GtkWidget *icon,
						   EIF_PROC func, EIF_OBJ object,
						   callback_data_t **p)
{
  callback_data_t *cbd;

  cbd = malloc (sizeof (callback_data_t));
  *p = cbd;
  eif_freeze (object);
  cbd->rtn = func;
  cbd->obj = eif_access (object);
  gtk_toolbar_append_item (toolbar, text, tip, private_tip, icon, 
						   (GtkSignalFunc)c_toolbar_callback, cbd);
}
						   
/* --------------- Events call backs stuff ---------- */

/* This function is actually called when the event occurs  */
/* an it in turn calls Eiffel.                             */
/* The Eiffel routine takes two arguments - the object and */
/* the pointer to the event data.                          */
void c_real_event_callback (GtkObject *w, GdkEvent *ev,  gpointer data) 
{
  callback_data_t *cbd;
  cbd = (callback_data_t *)data;
  /* Call Eiffel */
  /*  printf ("callback= %d object= %d cbd= %d\n", cbd->rtn, (cbd->obj), cbd); */
  (cbd->rtn)(cbd->obj, ev);
}

/* Connect a call back to a widget/event pair */
gint c_gtk_event_connect (GtkObject *widget, 
						   gchar *name, 
						   EIF_PROC func,
						   EIF_OBJ object,
						   callback_data_t **p)
{
  callback_data_t *cbd;
  int name_len;

  eif_freeze (object);  
  /* TODO: Deallocation of this block needs to be done when the */
  /* widget is GCed.                                            */
  cbd = malloc (sizeof (callback_data_t));
  /* Return the pointer of the allocated block to Eiffel, so it
	 can be deallocated later
  */
  *p = cbd;
  cbd->rtn = func;
  cbd->obj = eif_access (object);
  /*  printf ("connect rtn= %d object= %d cbd= %d\n", cbd->rtn, (cbd->obj), cbd); */

  return (gtk_signal_connect (widget, name, 
							  GTK_SIGNAL_FUNC(c_real_event_callback), 
							  (gpointer)cbd));
}


/* Set widget flags */
void c_gtk_widget_set_flags (GtkWidget *widget, int flags) 
{
  GTK_WIDGET_SET_FLAGS (widget, flags);
}

EIF_BOOLEAN c_gtk_widget_visible (GtkWidget *w) 
{
  if (GTK_WIDGET_VISIBLE(w))
	return (1);
  else
	return (0);
}

EIF_INTEGER c_gtk_widget_width (GtkWidget *w)
{
  EIF_INTEGER result = 0;
  if (w != NULL)
	result = w->allocation.width;
  return (result);
}

EIF_INTEGER c_gtk_widget_height (GtkWidget *w)
{
  EIF_INTEGER result = 0;
  if (w != NULL)
	result = w->allocation.height;
  return (result);
}

GdkWindow *c_gtk_widget_window (GtkWidget *w) 
{
  return (w->window);
}
