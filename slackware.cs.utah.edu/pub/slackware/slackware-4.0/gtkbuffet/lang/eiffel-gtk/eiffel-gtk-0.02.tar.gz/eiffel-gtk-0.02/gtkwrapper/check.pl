#!/usr/bin/perl

use Data::Dumper; 

sub parse_lisp
{
	local($_) = @_;
	my(@result) = ();
	my($node) = \@result;
	my(@parent) = ();
	while ( m/(\()|(\))|("(.*?)")|(;.*?$)|([^\(\)\s]+)/gm) {
		if (defined($1)) {
			my($new) = [];
			push @$node, $new;
			push @parent, $node;
			$node = $new;
		} elsif (defined($2)) {
			$node = pop @parent;
		} elsif (defined($3)) {
			push @$node, $4;
		} elsif (defined($6)) {
			push @$node, $6;
		}
	}
	@result;
}

foreach $node (parse_lisp(join("",<>))) {
	@node = @$node;

	if ( !defined($node[0]) ) {
		next;
	} elsif ($node[0] eq "define-func") {
		my($func) = {returntype => $node[2]};
		my(@args) = ();
		foreach $arg (@{$node[3]}) {
			my (@arg) = @$arg;
			if ($arg->[0] eq "...") {
			    print("We dont DO that sort of thing\n"); 
			    next;
			}
			# Convention: use trailing underscore to prevent 
			# conflict with feature names
			my ($a) = { type => $arg[0], name => $arg[1] } ; 
			push @args, $a;
		}
		$func->{args} = \@args;
		
		if ( exists $func{$node[1]} ) {
			warn "Overriding func `$node[1]'\n";
		}
		$func{$node[1]} = $func;
	}
}

%typemap = ( int => INTEGER, 
	     string => STRING, 
	     bool => BOOLEAN, 
	     float => REAL, 
	     gpointer => POINTER, 
	     uint => INTEGER, 
	   ); 

@long = qw( gtk_scrolled_window, 
	    gtk_aspect_frame, 
	    gtk_button_box, 
	    gtk_check_button,
	    gtk_check_menu_item, 
	    gtk_color_selection_dialog, 
	    gtk_drawing_area, 
	    gtk_event_box, 
	    gtk_file_selection, 
	    gtk_gamma_curve, 
	    gtk_handle_box, 
	    gtk_hbutton_box,
	    gtk_input_dialog, 
	    gtk_list_item, 
	    gtk_menu_bar,
	    gtk_menu_item, 
	    gtk_menu_shell, 
	    gtk_option_menu, 
	    gtk_progress_bar, 
	    gtk_radio_button, 
	    gtk_radio_menu_item,
	    gtk_scrolled_window, 
	    gtk_spin_button, 
	    gtk_toggle_button, 
	    gtk_tree_item, 
	    gtk_vbutton_box); 

# print Dumper(\%func);

foreach $sub (sort keys %func) { 
    next if ($sub =~ /_interp/); 
    feature_write($sub); 
    ext_write($sub); 
}

foreach (@long) { $long{$_}=1; }

sub feature_write { 
    my ($sub) = @_; 
    my ($feature, @names, @args); 

    $feature=feature($sub); 

    print "   $feature "; 
    @args=@{$func{$sub}{args}}; 
    if ($args[0]{type} =~ /^gtk/i) { 
	shift(@args); 
    }
    print arglist($sub, \&typeify, @args); 
    print " is\n      do\n         "; 
    if ($func{$sub}{returntype} ne "none") { 
	print "Result := "; 
    }
    print "ext_"; ($ext=$sub)=~s/gtk_//; 
    print $ext, " ( gtkobject"; 
    @names=names(@args); 
    if (@names) { 
	print ", ",  join(", ",  @names); 
    }
    print " )\n";
    print "      end\n\n"; 
}

sub names { 
    my (@args)=@_; 
    my ($arg, @result); 
    foreach $arg (@args) { 
	if ($arg->{type} =~ /^G[td]k/i)  { 
	    push @result, $arg->{name} . ".gtkobject"; 
	}
	elsif ($arg->{type} =~ /string/i) { 
	    push @result, $arg->{name} . ".to_external"; 
	}
	else { push @result, $arg->{name};  } 
    }
    return @result; 
}
    

sub feature { 
    my $sub=shift; 
    my (@parts, @tail); 
    @parts=split(/_/, $sub); 
    if (@parts < 2) { return $sub; } 
    while ($last=pop(@parts)) { 
	unshift(@tail, $last); 
	if ($long{join("_",@parts)}) { 
	    return join("_",@tail); 
	}
    }
    return (join("_", @tail[2..$#tail])); 
}
    

sub ext_write { 
    my ($sub) = @_; 

    ($ext=$sub) =~ s/^gtk_//; 
    $ext="ext_" . $ext; 
    print "   $ext "; 
    
    print arglist($sub, \&ext_typeify, @{$func{$sub}{args}});  
    print " is\n"; 
    print "      external \"C\"\n"; 
    print "      alias \"$sub\"\n"; 
    print "      end\n\n"; 
}

sub arglist { 
    my ($sub, $typefunc, @args)=@_; 
    my ($flag, $count, $type, @out); 
    foreach $arg (@args) { 
	next unless $arg->{type}; 
	$count++; 
	unless ($flag) { 
	    push(@out, "( "); 
	    $flag=1; 
	}
	$type=$typefunc->($arg->{type}); 
	if (@args > $count and $type eq $typefunc->($args[$count]->{type})) { 
	    push @out, ($arg->{name}, ", "); 
	}
	else {
	    push @out, $arg->{name}, " : ", $type, " ; "; 
	}
    }
    if ($flag) { 
	pop @out;		# remove semicolon
	push @out, " )" ; 
    }
    if ($func{$sub}{returntype} ne "none") { 
	push @out, (" : ", $typefunc->($func{$sub}{returntype}));
    }
    return join("", @out); 
}

sub eiffelize {
    return @_;
}

sub typeify { 
    $type=shift; 
    if (defined $typemap{$type}) { 
	return $typemap{$type};
    }
    if ($type =~ /^G[td]k/) { 
	$type =~ s/([a-z])([A-Z])/\1_\2/g;
	$type =~ tr [a-z] [A-Z]; 
	return $type; 
    }
    return $type; 
}

sub ext_typeify { 
    $type = shift; 
    $type=typeify($type); 
    if ($type =~ /G[DT]K_/) { 
	return "POINTER"; 
    }
    if ($type =~ /STRING/) { 
	return "POINTER"; 
    }
    return $type;
}

