#!/usr/bin/perl

if ($ARGV[0] eq "types") { 
    shift; 
    print "class GTK_TYPE
inherit GTK_ENUM
feature {ANY}
"; 

    while(<>){ 
	if(/^\s*\{\s*\"([A-Za-z]+)\", &([A-Z_]+),/) { 
	    $name=$1; $type=$2; 
	    ($feature=$type)=~tr [A-Z] [a-z]; 
	    print "   $feature : GTK_TYPE is
      do
         !!Result.make_gtk_enum(\"$name\")
      end
";
	}
    }
    print ("end\n"); 
} else {
    print <<EOF;
indexing
   status: "You may be able to redistribute and/or modify this program.% 
          % See the README for details."
   author: "Paul C. Janzen and others"
   header: "\$Header \$"

class GTK_CONSTANTS
   inherit GTK_FLAGS_NONE 
feature {ANY}
EOF
    while(<>){ 
	next if (/^\s*;/); 
	if (/\(define-enum/) { 
	    parse_enum(0); 
	}
	elsif (/\(define-flags/) { 
	    parse_enum(1); 
	}
	elsif (/\(define-boxed/) { 
	    parse_boxed(); 
	}
    }
    print ("end\n"); 
}

sub put_types { 
    foreach $type (@types) { 
	print ("$type\n");
    }
}

sub parse_boxed { 
    split; 
    $type=$_[1]; 
    push (@types, $type); 
}

sub parse_enum { 
    $is_flag=shift; 
    split; 
    $type=$_[1]; 

    ($class=$type)=~s/([a-z])([A-Z])/\1_\2/g;
    $class=~tr [a-z] [A-Z]; 
    ($file=$class)=~tr [A-Z] [a-z]; 
    $file .= ".e"; 
    open (OUT, ">$file") || die; 

    if ($is_flag) { $super="GTK_FLAG" } else { $super = "GTK_ENUM"; } 
    if ($is_flag) { $const="make_gtk_flag" } else { $const = "make_gtk_enum"; }
    if ($class eq "GTK_WIDGET_FLAGS") { 
	$inherit="   GTK_OBJECT_FLAGS redefine fundamental_type end\n"; 
    } else { 
	undef $inherit; 
    }
    print OUT <<EOF;
indexing
   status: "You may be able to redistribute and/or modify this program.% 
          % See the README for details."
   author: "Paul C. Janzen and others"
   header: "\$Header \$"

class $class
inherit $super
$inherit
creation make, 
         make_gtk_constant, 
         $const
EOF
    while (defined ($_=<>) && ! /^\s*$/) { 
	$last=(/\)\)/); 
	s/[\(\)]//g; 
	split; 
	$nick=$_[0]; $feature=$_[1];
	$feature=~tr [A-Z] [a-z];
	print "   $feature : $class is \n      do\n         !!Result.$const(\"$nick\")\n      end\n";
	last if $last; 
    }

print OUT <<EOF;
feature {NONE}
   fundamental_type : STRING is 
      once
        Result := "$type"
      end
end
EOF
}





