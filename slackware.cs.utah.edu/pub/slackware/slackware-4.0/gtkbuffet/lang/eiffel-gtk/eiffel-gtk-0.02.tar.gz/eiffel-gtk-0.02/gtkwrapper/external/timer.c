#include "eiffel-gtk.h"
#include <stdio.h>

extern int gtk_timer_entry(void *, void *); 

/* timeout stuff */ 

static void
timeout_destroy ( gpointer idata ) { 
  struct signal_data *data=idata; 

  if (data) 
    g_free(data);
  else
    fprintf(stderr, "timeout destroy: null data\n");
}

static gint 
timeout_function ( gpointer idata ) { 
  struct signal_data *data=idata; 
   
  if (!data->eiffel_target) {
    g_error("timeout/idle callback with null command");
    return(0);
  }
  
  return ( gtk_timer_entry ( data->eiffel_target, data->eiffel_data ) ); 
}

guint 
ext_timeout_add ( int interval, void *function, void *eiffel_data ) { 

  struct signal_data *timeout_data; 
  timeout_data = (struct signal_data *)g_malloc(sizeof(struct signal_data)); 

  if (!timeout_data)
    return (0); 
  
  timeout_data->eiffel_target = function ;
  timeout_data->eiffel_data = eiffel_data; 
  
  return gtk_timeout_add_full (interval,
			       timeout_function, 
			       NULL,
			       timeout_data, 
			       timeout_destroy);
}

/* Shares callback and destruction functions with the timeout code */ 
guint 
ext_idle_add ( void *function, void *eiffel_data ) { 

  struct signal_data *idle_data; 
  idle_data = (struct signal_data *)g_malloc(sizeof(struct signal_data)); 

  if (!idle_data)
    return (0); 
  
  idle_data->eiffel_target = function ;
  idle_data->eiffel_data = eiffel_data; 
  
  return gtk_idle_add_full (0,
			    timeout_function, 
			    NULL,
			    idle_data, 
			    timeout_destroy);
}
