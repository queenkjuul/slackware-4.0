#include "eiffel-gtk.h"
#include <stdio.h>
#include <stdlib.h>

#ifndef GTK_HAVE_FEATURES_1_1_8
#error Must have at least GTK 1.1.8. 
#endif

static void marshal_func(GtkObject *object, 
		  gpointer        data,
		  guint           nparams,
		  GtkArg         *args,
		  GtkType        *arg_types,
		  GtkType         return_type);

static void destroy_signal_func(gpointer data); 
static void stash_params(struct stashed_data*, int, GtkArg *, GtkType *, GtkType); 

/* return a NULL pointer */
void *ext_null_pointer(void) {
  return NULL;
}

void ext_init(void) {
  gtk_init(&se_argc, &se_argv);
  gtk_signal_set_funcs(marshal_func, destroy_signal_func); 
}

void ext_widget_destroy(GtkObject *gtkobject) {
  gtk_widget_destroy(GTK_WIDGET(gtkobject));
}


/* gtk_eiffel_entry is a cecilized GTK_COMMAND.command_execution */ 
static void jump_to_eiffel(struct signal_data *data, 
			   struct stashed_data *params) {
  if (data->eiffel_target) { 
    gtk_eiffel_entry( data->eiffel_target, data->eiffel_data, params ); 
  }
}

void *ext_create_signal_data(void *command_object, char *eiffel_data) { 
  struct signal_data *data;

  data = (struct signal_data *)g_malloc(sizeof(struct signal_data));
  data->eiffel_target = command_object;
  data->eiffel_data = eiffel_data;

  return data; 
}

int ext_signal_connect(GtkObject *gtkobject, 
		       char *signal_name, 
		       void *command_object ,
		       char *eiffel_data) {

  return gtk_signal_connect(gtkobject, 
			    signal_name, 
			    NULL, 
			    ext_create_signal_data(command_object, eiffel_data)); 
}

/* This function gets called every time there's a callback.  We use it
 * because we don't want to have to deal with all the different
 * callback formats. */

static void marshal_func(GtkObject      *object,
		  gpointer        data,
		  guint           nparams,
		  GtkArg         *args,
		  GtkType        *arg_types,
		  GtkType         return_type) { 

  struct stashed_data parms; 

  stash_params(&parms, nparams, args, arg_types, return_type); 
  jump_to_eiffel(data, &parms); 
}

/* Free the data we allocated in ext_signal_connect. */ 

static void destroy_signal_func(gpointer data){
  g_free(data); 
}

static void stash_params(struct stashed_data *data, 
			 int nparams, 
			 GtkArg *args,
			 GtkType *arg_types, 
			 GtkType return_type) { 
#if 0
  int i; 

  if (nparams > 0) { 
    printf("stashing %d args ( types: ", nparams); 
    for (i=0; i<nparams; i++) { 
      printf("%d ", arg_types[i]); 
    }
    printf(")\n"); 
  }

#endif
  data->nparams=nparams; 
  data->args=args;
  data->arg_types=arg_types; 
  data->return_type=return_type;

  if (return_type == GTK_TYPE_NONE) { 
    data->return_arg=NULL;
  } else {
    data->return_arg=&args[nparams]; 
  }
}

GtkType ext_argument_type(struct stashed_data *data) { 
  return *data->arg_types;
}

GtkType ext_return_value_type(struct stashed_data *data) { 
  return data->return_type; 
}

int ext_num_params(struct stashed_data *data) { 
  return(data->nparams); 
}

void ext_set_return_value_boolean(struct stashed_data *data, int ret) { 
  *GTK_RETLOC_BOOL(*(data->return_arg))=ret;
}

void ext_set_return_value_integer(struct stashed_data *data, int ret) { 
  *GTK_RETLOC_INT(*(data->return_arg))=ret; 
}

void ext_set_return_value_pointer(struct stashed_data *data, void *ret) { 
  *GTK_RETLOC_POINTER(*(data->return_arg))=ret;
}

int ext_shift_param_int(struct stashed_data *data) { 
  int ret; 

  if (data->nparams<=0) { 
    return -1;
  }

  data->nparams--; 

  if (data->arg_types[0] != GTK_TYPE_INT && 
      data->arg_types[0] != GTK_TYPE_UINT) { 
    fprintf(stderr, "Warning: stashed arg not of type integer\n"); 
  }

  ret=GTK_VALUE_INT(data->args[0]); 
  data->args++; 
  data->arg_types++; 
  return ret; 
}

void *ext_shift_param_pointer(struct stashed_data *data) { 
  void *ret; 

  if (data->nparams<=0) { 
    return NULL;
  }

  data->nparams--; 

#if 0
  /* For some reason some events return with type GTK_TYPE_POINTER
   * and others return with the GTK_TYPE_GDK_EVENT */
  if (data->arg_types[0] != GTK_TYPE_POINTER) { 
    fprintf(stderr, "Warning: stashed arg not of type pointer\n"); 
  }
#endif

  ret=GTK_VALUE_POINTER(data->args[0]); 
  data->args++; 
  data->arg_types++; 
  return ret; 
}

float ext_shift_param_float(struct stashed_data *data) { 
  float ret; 

  if (data->nparams<=0) { 
    return 0.0;
  }

  data->nparams--; 

  if (data->arg_types[0] != GTK_TYPE_FLOAT ) { 
    fprintf(stderr, "Warning: stashed arg not of type real\n"); 
  }

  ret=GTK_VALUE_FLOAT(data->args[0]); 
  data->args++; 
  data->arg_types++; 
  return ret; 
}

GtkType ext_object_type ( GtkObject *gtkobject ) { 
  return gtkobject->klass->type; 
}

#ifdef GTK_1_0
int ext_type_builtins(int i) { 
  return gtk_type_builtins[i];
}
#endif

GtkWidget* ext_dialog_vbox(GtkDialog *p) { 
  return p->vbox;
}

GtkWidget* ext_dialog_action_area(GtkDialog *p) { 
  return p->action_area;
}

void ext_widget_set_flags(GtkWidget *widget, int flags) {
  GTK_WIDGET_SET_FLAGS(widget, flags);
}  

void ext_widget_unset_flags(GtkWidget *widget, int flags) { 
  GTK_WIDGET_UNSET_FLAGS(widget, flags); 
}

int ext_widget_visible(GtkWidget *gtkwidget) {
  return GTK_WIDGET_VISIBLE(gtkwidget);
}

GSList *ext_radio_button_get_group(GtkRadioButton *radio_button) {
  return radio_button->group;
}

GtkWidget *ext_fileselection_ok_button(GtkObject *gtkobject) {
  return GTK_FILE_SELECTION(gtkobject)->ok_button;
}

GtkWidget *ext_fileselection_cancel_button(GtkObject *gtkobject) {
  return GTK_FILE_SELECTION(gtkobject)->cancel_button;
}

GtkWidget *ext_fileselection_help_button(GtkObject *gtkobject) {
  return GTK_FILE_SELECTION(gtkobject)->help_button;
}

GtkWidget *ext_fileselection_action_area(GtkObject *gtkobject) { 
  return GTK_FILE_SELECTION(gtkobject)->action_area;
}

GList *ext_list_selection(GtkObject *gtkobject) {
  return GTK_LIST(gtkobject)->selection;
}

guint ext_toggle_button_active(GtkObject *gtkobject) { 
  return (GTK_TOGGLE_BUTTON(gtkobject)->active);
}

#define MAKE_ACCESS_ADJUSTMENT(name) gfloat ext_adjustment_##name (GtkObject *gtkobject) {\
  return (GTK_ADJUSTMENT(gtkobject)->name);\
}

MAKE_ACCESS_ADJUSTMENT(lower)
MAKE_ACCESS_ADJUSTMENT(upper)
MAKE_ACCESS_ADJUSTMENT(value)
MAKE_ACCESS_ADJUSTMENT(step_increment)
MAKE_ACCESS_ADJUSTMENT(page_increment)
MAKE_ACCESS_ADJUSTMENT(page_size)

#define MAKE_EXT_STYLE(name) GdkColor *ext_style_##name (GtkStyle *gtkobject, int state) {\
  return &gtkobject->name[state]; \
}

MAKE_EXT_STYLE(fg)
MAKE_EXT_STYLE(bg)
MAKE_EXT_STYLE(light)
MAKE_EXT_STYLE(dark)
MAKE_EXT_STYLE(mid)
MAKE_EXT_STYLE(text)
MAKE_EXT_STYLE(base)

GdkColor *ext_style_black(GtkStyle *gtkobject) { 
  return &gtkobject->black; 
}

GdkColor *ext_style_white(GtkStyle *gtkobject) { 
  return &gtkobject->white; 
}

#define MAKE_EXT_GC(name) GdkGC *ext_##name (GtkStyle *gtkobject, int state) {\
  return gtkobject->name[state];\
}

MAKE_EXT_GC(fg_gc)
MAKE_EXT_GC(bg_gc)
MAKE_EXT_GC(light_gc)
MAKE_EXT_GC(dark_gc)
MAKE_EXT_GC(mid_gc)
MAKE_EXT_GC(text_gc)
MAKE_EXT_GC(base_gc)

GdkGC *ext_black_gc(GtkStyle *gtkobject) { 
  return gtkobject->black_gc; 
}

GdkGC *ext_white_gc(GtkStyle *gtkobject) { 
  return gtkobject->white_gc; 
}

#define MAKE_ALLOCATION(name) int ext_allocation_##name(GtkAllocation *gtkobject) { \
  return gtkobject->##name; \
}

MAKE_ALLOCATION(x)
MAKE_ALLOCATION(y)
MAKE_ALLOCATION(width)
MAKE_ALLOCATION(height)

GtkAllocation *ext_allocation(GtkWidget *gtkobject) { 
  return &gtkobject->allocation;
}

GdkPoint *ext_point_new(int x, int y, GdkPoint *gdkobject) { 
  gdkobject->x=x;
  gdkobject->y=y;
  return gdkobject;
}    

GtkRequisition *ext_requisition_new(int width, int height, GtkRequisition *gtkobject) { 
  if (sizeof(GtkRequisition) != 4) { 
    fprintf(stderr, "fix GtkRequisition structure in gtk_requisition.e\n"); 
  }
  gtkobject->width=width;
  gtkobject->height=height;
  return gtkobject;
}

#define MAKE_REQUISITION(name) int ext_requisition_##name(GtkRequisition *gtkobject) { \
  return gtkobject->##name; \
}
MAKE_REQUISITION(width)
MAKE_REQUISITION(height)

GdkWindow *ext_gdk_window_from_widget(GtkWidget *gtkobject) { 
  return gtkobject->window;
}

GtkObject *ext_list_item(GList *list, int index) {
  GList *sublist;
  sublist = g_list_nth(list, index);
  return sublist->data;
}

GList *ext_list_append(GList *list, gpointer data) {
  GList *new_list;
  new_list = g_list_append(list, data);
  return new_list;
}

GtkObject *ext_slist_item(GSList *list, int index) {
  GSList *sublist;
  sublist = g_slist_nth(list, index);
  return sublist->data;
}

GSList *ext_slist_append(GSList *list, gpointer data) {
  GSList *new_slist;
  new_slist = g_slist_append(list, data);
  return new_slist;
}

/* We're accepting patches, if you're interested. */ 
void ext_event_button_build (GdkEventButton *p, 
			     GdkEventType *type, 
			     GdkWindow **window,
			     gint8 *send_event,
			     guint32 *time,
			     gdouble *x,
			     gdouble *y,
			     gdouble *pressure, 
			     gdouble *xtilt,
			     gdouble *ytilt,
			     guint *state,
			     guint *button,
			     GdkInputSource *source,
			     guint32 *deviceid,
			     gdouble *x_root, 
			     gdouble *y_root) { 

  *type=p->type; 
  *window=p->window; 
  *send_event=p->send_event;
  *time=p->time;
  *x=p->x;
  *y=p->y;
  *pressure=p->pressure;
  *xtilt=p->xtilt;
  *ytilt=p->ytilt;
  *state=p->state;
  *button=p->button;
  *source=p->source;
  *deviceid=p->deviceid;
  *x_root=p->x_root;
  *y_root=p->y_root;
}

GdkEventType ext_gdk_event_type(GdkEvent *p) { 
  return (p->any.type); 
}

void ext_event_build(GdkEvent *event, 
		     GdkEventType *event_type,
		     GdkWindow **window, 
		     int *send_event) { 

  *event_type=event->any.type; 
  *window=event->any.window; 
  *send_event=event->any.send_event;
}

int ext_event_is_button (GdkEvent *p) { 
  int ret; 
  ret=(p->type == GDK_BUTTON_PRESS);
  return(ret);
}

#define MAKE_COLOR_DIALOG(name) \
GtkWidget *ext_color_selection_dialog_##name(GtkColorSelectionDialog *gtkobject) { \
  return gtkobject->##name; \
}

MAKE_COLOR_DIALOG(colorsel)
MAKE_COLOR_DIALOG(main_vbox)
MAKE_COLOR_DIALOG(ok_button)
MAKE_COLOR_DIALOG(reset_button)
MAKE_COLOR_DIALOG(cancel_button)
MAKE_COLOR_DIALOG(help_button)

#define MAKE_GDK_COLOR(name) \
int ext_color_##name(GdkColor *color) { \
  return color->##name; \
}

MAKE_GDK_COLOR(red)
MAKE_GDK_COLOR(green)
MAKE_GDK_COLOR(blue)

#define MAKE_FONT_DIALOG(name) \
GtkWidget *ext_font_selection_dialog_##name(GtkFontSelectionDialog *gtkobject) { \
  return gtkobject->##name; \
}

MAKE_FONT_DIALOG(fontsel)
MAKE_FONT_DIALOG(main_vbox)
MAKE_FONT_DIALOG(action_area)
MAKE_FONT_DIALOG(ok_button)
MAKE_FONT_DIALOG(apply_button)
MAKE_FONT_DIALOG(cancel_button)

#define MAKE_GAMMA_CURVE(name) \
GtkWidget *ext_gamma_curve_##name(GtkGammaCurve *gtkobject) { \
  return gtkobject->##name; \
}

MAKE_GAMMA_CURVE(table)
MAKE_GAMMA_CURVE(curve)

#define MAKE_GAMMA_CURVE_BUTTON(name, index) \
GtkWidget *ext_gamma_curve_##name(GtkGammaCurve *gtkobject) { \
  return gtkobject->button[index];\
}

MAKE_GAMMA_CURVE_BUTTON(spline, 0)
MAKE_GAMMA_CURVE_BUTTON(linear, 1)
MAKE_GAMMA_CURVE_BUTTON(free, 2)
MAKE_GAMMA_CURVE_BUTTON(gamma, 3)
MAKE_GAMMA_CURVE_BUTTON(reset, 4)

#define MAKE_HANDLE_BOX(name) \
GdkWindow *ext_handle_box_##name(GtkHandleBox *box) { \
  return box->##name;\
}

MAKE_HANDLE_BOX(bin_window)
MAKE_HANDLE_BOX(float_window)

#define MAKE_INPUT_DIALOG(name) \
GtkWidget *ext_input_dialog_##name(GtkInputDialog *dialog) { \
  return dialog->##name;\
}

MAKE_INPUT_DIALOG(axis_list)
MAKE_INPUT_DIALOG(axis_listbox)
MAKE_INPUT_DIALOG(mode_optionmenu)
MAKE_INPUT_DIALOG(close_button)
MAKE_INPUT_DIALOG(save_button)
MAKE_INPUT_DIALOG(keys_list)
MAKE_INPUT_DIALOG(keys_listbox)

int ext_input_dialog_current_device (GtkInputDialog *dialog) { 
  return dialog->current_device; 
}

int ext_flag_find_value ( int type, char *name ) { 
  GtkFlagValue *ret; 
  ret = gtk_type_flags_find_value ( type, name ) ; 
  return ret->value; 
}

int ext_enum_find_value ( int type, char *name ) { 
  GtkEnumValue *ret; 
  ret = gtk_type_enum_find_value ( type, name ); 
  return ret->value;
}

#define MAKE_NOTEBOOK_PAGE(name) \
GtkWidget *ext_notebook_page_##name(GtkNotebookPage *page) { \
  return page->##name;\
}

MAKE_NOTEBOOK_PAGE(child)
MAKE_NOTEBOOK_PAGE(tab_label)
MAKE_NOTEBOOK_PAGE(menu_label)

#define MAKE_NOTEBOOK_PAGE_BOOL(name) \
int ext_notebook_page_##name(GtkNotebookPage *page) { \
  return page->##name; \
}

MAKE_NOTEBOOK_PAGE_BOOL(default_menu)
MAKE_NOTEBOOK_PAGE_BOOL(default_tab)

GList *ext_notebook_children (GtkNotebook *notebook) { 
  return notebook->children;
}

int ext_notebook_tab_pos (GtkNotebook *notebook) { 
  return notebook->tab_pos;
}

GtkNotebookPage *ext_notebook_cur_page ( GtkNotebook *notebook ) { 
  return notebook->cur_page; 
}

int
ext_motion_notify_event ( GtkWidget *widget, GdkEventMotion *event) { 
  return GTK_WIDGET_CLASS(GTK_OBJECT(widget)->klass)->motion_notify_event(widget, (GdkEventMotion*)event); 
}


GdkSegment *
ext_make_segment(int x1, int y1, int x2, int y2, 
			     GdkSegment *segment) 
{ 
  if (sizeof(GdkSegment) != 8)
    fprintf(stderr, "please fix gdk_segment: storage != 64\n"); 
    
  segment->x1=x1;
  segment->y1=y1;
  segment->x2=x2;
  segment->y2=y2;

  return segment; 
}

GtkTargetEntry *
ext_make_target_entry(char *target, int flags, int info, 
				      GtkTargetEntry *storage) 
{
  if (sizeof(GtkTargetEntry) > 12) 
    fprintf(stderr, "please fix gtk_target_entry: storage > 96\n"); 
  
  storage->target=target;
  storage->flags=flags;
  storage->info=info;

  return storage; 
}

/* Grrr.  The GTK+ interface to the dnd routines sucks. */
GtkTargetEntry *
ext_target_entry_to_array(GtkTargetEntry **entry, 
			  int n_entries) { 
  
  int i; 
  GtkTargetEntry *retval;
  retval = (GtkTargetEntry *)(g_malloc(n_entries * sizeof(GtkTargetEntry))); 
  for (i=0; i< n_entries; i++) { 
    memcpy(&retval[i], entry[i], sizeof(GtkTargetEntry)); 
  }
  return(retval); 
}

#define MAKE_DRAG_CONTEXT(type, name) \
type ext_drag_context_##name (GdkDragContext *p) { \
  return p->##name; \
}

MAKE_DRAG_CONTEXT(GdkDragProtocol, protocol)
MAKE_DRAG_CONTEXT(gboolean, is_source)
MAKE_DRAG_CONTEXT(GdkWindow*, source_window)
MAKE_DRAG_CONTEXT(GdkWindow*, dest_window)
MAKE_DRAG_CONTEXT(GdkDragAction, actions)
MAKE_DRAG_CONTEXT(GdkDragAction, suggested_action)
MAKE_DRAG_CONTEXT(GdkDragAction, action)
MAKE_DRAG_CONTEXT(guint32, start_time)


#define MAKE_SELECTION_DATA(type, name) \
type ext_selection_data_##name (GtkSelectionData *p) { \
  return p->##name; \
}

MAKE_SELECTION_DATA(GdkAtom, selection)
MAKE_SELECTION_DATA(GdkAtom, target)
MAKE_SELECTION_DATA(GdkAtom, type)
MAKE_SELECTION_DATA(gint, format)
MAKE_SELECTION_DATA(gint, length)
MAKE_SELECTION_DATA(char*, data)


void
ext_drag_source_set(GtkWidget *widget, 
                   GdkModifierType start_button_mask, 
                   GtkTargetEntry **targets, 
                   gint n_targets, 
                   GdkDragAction actions) { 

  GtkTargetEntry *targets_array; 

  targets_array=ext_target_entry_to_array(targets, n_targets); 

  gtk_drag_source_set(widget, 
                     start_button_mask, 
                     targets_array, 
                     n_targets, 
                     actions); 
  g_free(targets_array); 

}

void
ext_drag_dest_set(GtkWidget *widget, 
                 GtkDestDefaults flags, 
                 GtkTargetEntry **targets, 
                 gint n_targets,
                 GdkDragAction actions) { 
  GtkTargetEntry *targets_array; 

  targets_array=ext_target_entry_to_array(targets, n_targets); 
  
  gtk_drag_dest_set(widget, 
                   flags, 
                   targets_array, 
                   n_targets,
                   actions); 
  g_free(targets_array); 

}

#define VERSION_FUNCTION(type) \
guint ext_version_##type() { \
  return gtk_##type; \
}

VERSION_FUNCTION(major_version) 
VERSION_FUNCTION(minor_version) 
VERSION_FUNCTION(micro_version) 
VERSION_FUNCTION(binary_age) 
VERSION_FUNCTION(interface_age) 

GdkWindow *ext_plug_socket_window(GtkPlug *plug) { 
  return plug->socket_window; 
}

gint ext_plug_same_app(GtkPlug *plug) {
  return plug->same_app;
}
