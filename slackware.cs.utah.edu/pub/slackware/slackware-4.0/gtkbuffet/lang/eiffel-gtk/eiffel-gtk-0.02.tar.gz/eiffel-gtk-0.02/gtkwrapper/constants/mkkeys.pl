#!/usr/bin/perl
while (<>) { 
    if (/#define (GDK[\S]+) +(0x[0-9A-F]+)/i){ 
	$code=$2; 
	($key = $1) =~ s/^GDK_//; 
	print "\"$key\","; printf " %d,\n", hex($code); 
    }
}
