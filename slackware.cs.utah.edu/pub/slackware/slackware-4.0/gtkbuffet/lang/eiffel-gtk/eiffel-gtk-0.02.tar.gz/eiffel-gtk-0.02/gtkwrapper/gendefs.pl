#!/usr/bin/perl

while(<>){ 
    chomp;
    if (/^(typedef )?enum/){
	$valid=1;
	$value=0; 
    }
    next if (/^[\{]/); 
    if (/^\}\s*([a-zA-Z0-9]+)?\s*;/){
	spit($1); 
	$valid=0;
	undef @stuff; 
    }
    next unless $valid; 
    if (/^\s*(G[TD]K_[0-9A-Z_]*)/){
	$const=$1;
#	$const =~ s/GTK_//;
	$const =~ tr/[A-Z]/[a-z]/;
	if (/^(.*)\s*=([^,]*)/){
	    $value=eval($2);
	}
	push (@stuff, [$const, $value]); 
	$value++;
    }
}

sub spit {
    $type=shift; 
    ($file=$type) =~ s/([a-z])([A-Z])/\1_\2/g; 
    ($class=$file) =~ tr/[a-z]/[A-Z]/;
    if ($file) { 
	$file =~ tr/[A-Z]/[a-z]/; 
#	open(FH, ">out/$file.e")||die; 
	print <<EOF; 
class $class
inherit GTK_CONSTANT
creation make_gtk_constant
feature {ANY}
EOF
    }
#    print "$type $class $file\n"; 
    foreach $ref (@stuff) { 
	($const, $value)=@$ref; 
#	$const =~ s/^.*_([a-z0-9]+)$/\1/; 
	print ("   $const : $class is \n      once\n         !!Result.make_gtk_constant($value)\n      end\n");
    }
    print("end\n"); 
}
