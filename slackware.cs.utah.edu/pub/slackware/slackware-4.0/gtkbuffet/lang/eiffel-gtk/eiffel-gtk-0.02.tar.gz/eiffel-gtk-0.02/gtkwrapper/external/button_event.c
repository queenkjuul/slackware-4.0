#include <gdk/gdk.h>

#define DOUBLE_EVENT(name) \
double ext_event_button_##name(GdkEventButton *event) {\
  return event->##name;\
}

DOUBLE_EVENT(x)
DOUBLE_EVENT(y)
DOUBLE_EVENT(pressure)
DOUBLE_EVENT(xtilt)
DOUBLE_EVENT(ytilt)
DOUBLE_EVENT(x_root)
DOUBLE_EVENT(y_root)

#define INT_EVENT(name) \
int ext_event_button_##name(GdkEventButton *event) {\
  return event->##name;\
}

INT_EVENT(time)
INT_EVENT(state)
INT_EVENT(button)
INT_EVENT(source)
INT_EVENT(deviceid)
