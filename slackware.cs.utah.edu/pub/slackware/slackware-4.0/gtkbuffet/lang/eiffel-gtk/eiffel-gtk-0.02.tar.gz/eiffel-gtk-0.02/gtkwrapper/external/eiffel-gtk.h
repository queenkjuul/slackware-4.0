#include <gtk/gtk.h>

struct signal_data {
  void *eiffel_target;
  void *eiffel_data;
};

struct stashed_data { 
  guint nparams;
  GtkArg *args; 
  GtkType *arg_types; 
  GtkType return_type; 
  GtkArg *return_arg; 
}; 

extern int se_argc; 
extern char **se_argv; 
extern void gtk_eiffel_entry(void *, void *, void *); 
