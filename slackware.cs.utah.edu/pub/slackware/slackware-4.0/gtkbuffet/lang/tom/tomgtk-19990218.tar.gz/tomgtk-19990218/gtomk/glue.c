/* gtomk glue code.
   Written by <a href="mailto:tiggr@gerbil.org">Pieter J. Schoenmakers</a>

   Copyright &copy; 1998 Pieter J. Schoenmakers.

   This file is part of GTOMK.	GTOMK is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the GTOMK distribution; see the file COPYING.LIB.

   $Id: glue.c,v 1.13 1998/08/19 09:21:37 yacc Exp $  */

#include "gtomk-r.h"
#include "glue.h"
#include <trt/trt.h>
#include <stdarg.h>
#include <stdio.h>

static void
sig_fatal (int nargs, GtkArg *args, gtomk_glue *cb, char *fmt, ...)
{
  va_list ap;
  int i;

  fprintf (stderr, "TOM/Gtk signal dispatch problem: ");
  va_start (ap, fmt);
  vfprintf (stderr, fmt, ap);
  va_end (ap);
  putc ('\n', stderr);

  fprintf (stderr, "selector: %s (allow_mismatch=%d)\n",
	   cb->sel->name.s, cb->allow_mismatch);
  fprintf (stderr, "signal: #args=%d + %d", nargs, cb->prefix_sender);

  for (i = 0; i < nargs; i++)
    fprintf (stderr, "%s%s", i ? " " : " (", gtk_type_name (args[i].type));
  if (nargs)
    putc (')', stderr);

  fprintf (stderr, " retval=%s\n", gtk_type_name (args[nargs].type));
  abort ();
}

static void dump_gtkarg (FILE *out, int nargs, GtkArg *args) 
{
  int i;
  for (i=0; i<nargs; i++) {
    fprintf(out, "GTKARG[%d].type == %d\n", i, args[i].type);
    fprintf(out, "GTKARG[%d].name == %s\n", i, args[i].name);
  }
}

void
gtomk_signal_relay (GtkObject *object, gtomk_glue *cb,
		    gint nargs, GtkArg *sig_args)
{
  int i, args_size, extra_args = cb->prefix_sender;
  builtin_return_type *result, local_result;
  union apply_args *args;
  selector sel = cb->sel;
  GtkType at;

  if (sel->in->num != nargs + extra_args
      && !(cb->allow_mismatch
	   && sel->in->num <= nargs + extra_args))
    sig_fatal (nargs, sig_args, cb, "#args mismatch");

  args_size = 2 * sizeof (void *) + APPLY_ARGS_REG_SIZE;
  args = alloca (args_size);

  APPLY_ARGS_START (sel);
  args->stack = alloca (APPLY_ARGS_STACK_SIZE (sel));
  APPLY_ARGS_EMIT_REFERENCE (cb->rcv);
  APPLY_ARGS_EMIT_SELECTOR (sel);

  if (extra_args)
    if (sel->in->args[0] == TRT_TE_REFERENCE)
      {
	tom_object sender = TRT_SEND (_PI_, CREF (gtomk_GtkObject),
				      SEL (r_proxy_p_create__o), object, 1);
	APPLY_ARGS_EMIT_REFERENCE (sender);
      }
    else if (sel->in->args[0] == TRT_TE_POINTER)
      APPLY_ARGS_EMIT_POINTER (object);
    else
      sig_fatal (nargs, sig_args, cb,
		 ": first selector arg not object or pointer");

  for (i = extra_args; i < sel->in->num; i++)
    {
      at = sig_args[i - extra_args].type;
      switch (GTK_FUNDAMENTAL_TYPE (at))
	{
	  void *p;
	  int helper_i;
	  char helper_c;
	  
	case GTK_TYPE_BOOL:
	  helper_i = GTK_VALUE_CHAR (sig_args[i-extra_args]);
	  if (sel->in->args[i] != TRT_TE_BOOLEAN)
	    sig_fatal (nargs, sig_args, cb, "expected boolean for sigarg %d",
		       i - extra_args);
	  APPLY_ARGS_EMIT_BYTE (helper_i);
	  break;
	  
	case GTK_TYPE_CHAR:
	  helper_c = GTK_VALUE_CHAR (sig_args[i-extra_args]);
	  if (sel->in->args[i] != TRT_TE_BYTE)
	    sig_fatal (nargs, sig_args, cb, "expected byte for sigarg %d",
		       i - extra_args);
	  APPLY_ARGS_EMIT_BYTE (helper_i);
	  break;

	case GTK_TYPE_INT:
	  /* XXX This is potentially wrong.  TOM doesn't have unsigned
	     integers -> map them to signed integers.
	     Mon Apr 20 00:16:23 MEST 1998 <andreas@ag.or.at>  */
	case GTK_TYPE_UINT:
	  helper_i = GTK_VALUE_INT (sig_args[i-extra_args]);
	  if (sel->in->args[i] != TRT_TE_INT)
	    sig_fatal (nargs, sig_args, cb, "expected int for sigarg %d",
		       i - extra_args);
	  APPLY_ARGS_EMIT_INT (helper_i);
	  break;

	case GTK_TYPE_POINTER:
	  p = GTK_VALUE_POINTER (sig_args[i-extra_args]);
	  if (sel->in->args[i] != TRT_TE_POINTER
	      && sel->in->args[i] != TRT_TE_REFERENCE)
	    sig_fatal (nargs, sig_args, cb, "expected int for sigarg %d",
		       i - extra_args);
	  if (sel->in->args[i] == TRT_TE_REFERENCE)
	    {
	      tom_object pobj = TRT_SEND (_PI_, CREF (gtomk_GtkObject),
					  SEL (r_proxy_p_create__o), p, 1);
	      APPLY_ARGS_EMIT_REFERENCE (pobj);
	    }
	  else 
	    APPLY_ARGS_EMIT_POINTER (p);
	  break;
	  
	case GTK_TYPE_BOXED:
	  p = GTK_VALUE_BOXED (sig_args[i - extra_args]);
	  switch (sel->in->args[i])
	    {
	    case TRT_TE_POINTER:
	      break;

	    bad:
	    default:
	      sig_fatal (nargs, sig_args, cb,
			 "unimplemented arg conversion at sigsarg %d",
			 i - extra_args);
	      break;
	    }

	  APPLY_ARGS_EMIT_REFERENCE (p);
	  break;

	case GTK_TYPE_OBJECT:
	  p = GTK_VALUE_OBJECT (sig_args[i - extra_args]);
	  switch (sel->in->args[i])
	    {
	    case TRT_TE_POINTER:
	      break;
	    case TRT_TE_REFERENCE:
	      p = TRT_SEND (_PI_, CREF (gtomk_GtkObject),
			    SEL (r_proxy_p_create__o), p, 1);
	      break;
	    default:
	      goto bad;
	    }
	  APPLY_ARGS_EMIT_REFERENCE (p);
	  break;

	default:
	  dump_gtkarg (stderr, nargs, sig_args);
	  fflush (stderr);
	  sig_fatal (nargs, sig_args, cb,
		     "unhandled gtk type (%d) at sigarg %d",
		     GTK_FUNDAMENTAL_TYPE (at), i - extra_args);
	  break;
	}
    }

  APPLY_ARGS_COMPLETE ();
  result = APPLY_ARGS_APPLY ((void (*) ()) trt_lookup (cb->rcv, cb->sel),
			     args, APPLY_ARGS_ACTUAL_SIZE (), &local_result);

  if (sel->out->num > 1)
    sig_fatal (nargs, sig_args, cb, "unhandled #out args");

  i = sel->out->num == 1 ? sel->out->args[0] : TRT_TE_VOID;
  at = sig_args[nargs].type;

  switch (i)
    {
    case TRT_TE_VOID:
      if (GTK_FUNDAMENTAL_TYPE (at) != GTK_TYPE_NONE)
	goto bad_retval;
      break;

    case TRT_TE_BOOLEAN:
    case TRT_TE_BYTE:
    case TRT_TE_CHAR:
    case TRT_TE_INT:
      switch (GTK_FUNDAMENTAL_TYPE (at))
	{
	case GTK_TYPE_INVALID:
	case GTK_TYPE_NONE:
	  break;
	case GTK_TYPE_CHAR:
	  *GTK_RETLOC_CHAR (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_BOOL:
	  *GTK_RETLOC_BOOL (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_INT:
	  *GTK_RETLOC_INT (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_UINT:
	  *GTK_RETLOC_UINT (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_ENUM:
	  *GTK_RETLOC_ENUM (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_FLAGS:
	  *GTK_RETLOC_FLAGS (sig_args[nargs]) = result->i.i;
	  break;

	default:
	bad_retval:
	  if (!cb->allow_mismatch)
	    sig_fatal (nargs, sig_args, cb, "unhandled out arg conversion");
	  else switch (GTK_FUNDAMENTAL_TYPE (at))
	    {
	    case GTK_TYPE_INVALID:
	    case GTK_TYPE_NONE:
	      break;
	    case GTK_TYPE_CHAR:
	      *GTK_RETLOC_CHAR (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_BOOL:
	      *GTK_RETLOC_BOOL (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_INT:
	      *GTK_RETLOC_INT (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_UINT:
	      *GTK_RETLOC_UINT (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_ENUM:
	      *GTK_RETLOC_ENUM (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_FLAGS:
	      *GTK_RETLOC_FLAGS (sig_args[nargs]) = 0;
	      break;
	    default:
	      sig_fatal (nargs, sig_args, cb, "unhandled default conversion");
	    }
	}
      break;

    case TRT_TE_LONG:
      sig_fatal (nargs, sig_args, cb, "Gtk doesn't know about 64bit longs :(");
      break;
    case TRT_TE_SELECTOR:
      sig_fatal (nargs, sig_args, cb, "Gtk doesn't know about selectors :(");
      break;
    case TRT_TE_POINTER:
      *GTK_RETLOC_POINTER (sig_args[nargs]) = result->p.p;
      break;
    case TRT_TE_REFERENCE:
      *GTK_RETLOC_OBJECT (sig_args[nargs]) = TRT_SEND((pointer_imp), 
						      result->p.p,
						      SEL (p_gtkObject));
      break;
    case TRT_TE_FLOAT:
      *GTK_RETLOC_FLOAT (sig_args[nargs]) = RETURN_RETRIEVE_FLOAT (result);
      break;
    case TRT_TE_DOUBLE:
      *GTK_RETLOC_DOUBLE (sig_args[nargs]) = RETURN_RETRIEVE_DOUBLE (result);
      break;

    default:
      sig_fatal (nargs, sig_args, cb, "unhandled out arg TOM type");
      break;
    }

  APPLY_ARGS_END ();
}

void
gtomk_idle_fire (gtomk_glue *data)
{
  TRT_SEND (, data->rcv, USEL (tom, v_perform_s___r), data->sel, (void *) 0);
}

void
gtomk_free (void *p)
{
  g_free (p);
}
