/* 
   Written by Andreas Kostyrka <yacc@gerbil.org>

   Copyright (C) 1998 Andreas Kostyrka.

   This file is part of tomgtk. tomgtk is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the tomgtk distribution; see the file COPYING.LIB.

   $Id: tomutil.h,v 1.1 1998/06/16 19:41:46 yacc Exp $
*/

#include <tom/util.h>
#include <assert.h>

static char **tomarray_to_charptrarray (tom_object array, int *len) {
  int alen;
  int i;
  char **retval;
  DECL_USEL (tom, i_length);
  DECL_USEL (tom, r_at_i);

  alen = TRT_SEND ( , array, USEL (tom, i_length));
  retval = malloc (sizeof(char *) * (alen + 1));
  
  assert(retval);		/* This is broken. But better an assert abort
				   then a random core dump. 
				   yacc@gerbil.org 
				   Tue Jun 16 21:10:24 MEST 1998 */
  if (len) *len = alen;

  for (i = 0; i < alen; i++) {
    tom_object element;
    element = TRT_SEND ((reference_imp), array,
			USEL (tom, r_at_i), i);
    retval[i] = c_string_with_tom_string (element);
  }
  retval[i] = (char *) 0;
  return retval;
}

static void free_charptrarray (char **array) {
  char **r = array;
  
  while (*r) {
    free (*r);
    r++;
  }
  free (array);
}
