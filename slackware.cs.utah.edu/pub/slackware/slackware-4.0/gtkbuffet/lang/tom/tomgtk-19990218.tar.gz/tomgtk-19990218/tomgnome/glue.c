/* Tomgnome glue code.
   Written by <a href="mailto:yacc@gerbil.org">Andreas Kostyrka</a>

   Copyright &copy; 1998 Andreas Kostyrka.

   This file is part of tomgnome. tomgnome is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the tomgtk distribution; see the file COPYING.LIB.

   $Id: glue.c,v 1.1 1998/07/08 21:41:09 yacc Exp $
*/

#include "tomgnome-r.h"
#include <libgnomeui/libgnomeui.h>
#include <tom/util.h>
#include <trt/trt.h>
#include <stdarg.h>
#include <stdio.h>

static __inline__ void
mark_if_needed_and_not_nil (struct trt_instance *o)
{
  if (o && TGC_COLOUR (o->asi) == TGC_WHITE)
    trt_make_gray (o);
}

void
i_tomgnome_GnomeUIArray_v_gc_mark_elements (tom_object self, selector cmd)
{
  struct _es_i_tomgnome_GnomeUIArray *this = 
    trt_ext_address (self, _ei_i_tomgnome_GnomeUIArray);
  int i, n;

  for (i = 0, n = this->length; i < n; i++)
    mark_if_needed_and_not_nil (((struct trt_instance **)this->ovalue)[i]);
}

tom_object
  c_tomgnome_GnomeUIArray_r_with_x (tom_object self, selector cmd, ...)
{
  int i, n = cmd->in->num;
  tom_object res;
  tom_object endofinfo;
  va_list ap;
  DECL_USEL (tom, r_new);
  DECL_SEL (v_add_r);

  va_start (ap, cmd);

  res = TRT_SEND ((reference_imp), self, USEL (tom, r_new));
  for (i=0; i<n; i++) {
    if (cmd->in->args[i]==TRT_TE_REFERENCE) {
      TRT_SEND ((void_imp), res, SEL (v_add_r), va_arg (ap, tom_object));
    } else {
      fprintf(stderr,"GnomeUIArray::with called with non object.\n");
    }
  }
  /* with generated Arrays are automatically delimited. */

  endofinfo = TRT_SEND ((reference_imp), CREF(tomgnome_GnomeUIInfoEndOfInfo), USEL (tom, r_new));
  TRT_SEND ((void_imp),
	    res,
	    SEL (v_add_r),
	    endofinfo);

  return res;
}
