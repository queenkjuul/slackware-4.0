/* gtomk glue code.
   Written by <a href="mailto:tiggr@gerbil.org">Pieter J. Schoenmakers</a>

   Copyright &copy; 1998 Pieter J. Schoenmakers.

   This file is part of GTOMK.  GTOMK is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the GTOMK distribution; see the file COPYING.LIB.

   $Id: glue.h,v 1.6 1998/04/09 09:43:10 tiggr Exp $  */

#include <gtk/gtk.h>
#include <tom/util.h>

#define GTK(O)  ((GtkObject *) (O))

DECL_USEL (tom, _pi__byteStringContents);

typedef struct
{
  tom_object rcv;
  selector sel;
  unsigned int prefix_sender: 1;
  unsigned int allow_mismatch: 1;
} gtomk_glue;

void gtomk_signal_relay (GtkObject *object, gtomk_glue *data,
			 gint nargs, GtkArg *args);

void gtomk_idle_fire (gtomk_glue *data);

void gtomk_free (void *);
