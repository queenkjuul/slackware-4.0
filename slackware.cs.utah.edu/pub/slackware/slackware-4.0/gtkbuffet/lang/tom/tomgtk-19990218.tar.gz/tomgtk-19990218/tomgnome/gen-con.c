/* Generate GNOME constants for use in tomgnome.
   Written by Andreas Kostyrka <yacc@gerbil.org>

   Copyright &copy; 1998, 1999 Andreas Kostyrka.

   This file is part of tomgnome.  tomgnome is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the tomgtk distribution; see the file COPYING.LIB.

   $Id: gen-con.c,v 1.8 1999/02/17 23:32:57 tiggr Exp $  */

#include <libgnome/libgnome.h>
#include <libgnomeui/libgnomeui.h>

#define DI(MACRO)  \
  printf ("  const " #MACRO " = %d;\n", MACRO)

int
main (int argc, char **argv)
{
  printf ("implementation class Constants: gdomk.Constants\n{\n");

  /* These are all values from /usr/include/libgnomeui/gnome-uidefs.h.  */
  DI (GNOME_PAD);
  DI (GNOME_PAD_SMALL);
  DI (GNOME_PAD_BIG);
  DI (GNOME_YES);
  DI (GNOME_NO);
  DI (GNOME_OK);
  DI (GNOME_CANCEL);
  DI (GTK_CLOCK_INCREASING);
  DI (GTK_CLOCK_DECREASING);
  DI (GTK_CLOCK_REALTIME);
  DI (GTK_CALENDAR_SHOW_HEADING);
  DI (GTK_CALENDAR_SHOW_DAY_NAMES);
  DI (GTK_CALENDAR_NO_MONTH_CHANGE);
  DI (GNOME_INTERACT_NONE);
  DI (GNOME_INTERACT_ERRORS);
  DI (GNOME_INTERACT_ANY);
  DI (GNOME_DIALOG_ERROR);
  DI (GNOME_DIALOG_NORMAL);
  DI (GNOME_SAVE_GLOBAL);
  DI (GNOME_SAVE_LOCAL);
  DI (GNOME_SAVE_BOTH);
  DI (GNOME_RESTART_IF_RUNNING);
  DI (GNOME_RESTART_ANYWAY);
  DI (GNOME_RESTART_IMMEDIATELY);
  DI (GNOME_RESTART_NEVER);
  DI (GNOME_CLIENT_IDLE);
  DI (GNOME_MDI_NOTEBOOK);
  DI (GNOME_MDI_TOPLEVEL);
  DI (GNOME_MDI_MODAL);

  printf ("}\nend;\nimplementation instance Constants end;\n");

  return 0;
}

