/* TOM/Gtk TOMWidget class, the Gtk view.
   Copyright (C) 1999 Pieter Schoenmakers
   Written by Pieter Schoenmakers <tiggr@gerbil.org>

   This file is part of GTOMK.  GTOMK is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the GTOMK distribution; see the file COPYING.LIB.

   $Id: tomwidget.h,v 1.1 1999/04/25 18:40:34 tiggr Exp $
 */

#ifndef __TOM_WIDGET_H__
#define __TOM_WIDGET_H__

#include <gtk/gtkwidget.h>
#include <tom/util.h>

#define GTK_TYPE_TOMWIDGET			(gtk_tomwidget_get_type ())
#define GTK_TOMWIDGET(obj)			(GTK_CHECK_CAST ((obj), GTK_TYPE_TOMWIDGET, GtkTomwidget))
#define GTK_TOMWIDGET_CLASS(klass)		(GTK_CHECK_CLASS_CAST ((klass), GTK_TYPE_TOMWIDGET, GtkTomwidgetClass))
#define GTK_IS_TOMWIDGET(obj)		(GTK_CHECK_TYPE ((obj), GTK_TYPE_TOMWIDGET))
#define GTK_IS_TOMWIDGET_CLASS(klass)	(GTK_CHECK_CLASS_TYPE ((klass), GTK_TYPE_TOMWIDGET))

typedef struct _GtkTomwidget       GtkTomwidget;
typedef struct _GtkTomwidgetClass  GtkTomwidgetClass;

/* No additional instance variables.  */
struct _GtkTomwidget
{
  GtkWidget widget;
};

/* No additional methods.  */
struct _GtkTomwidgetClass
{
  GtkWidgetClass parent_class;
};

GtkType gtk_tomwidget_get_type (void);
GtkWidget *gtk_tomwidget_new (void);

#endif
