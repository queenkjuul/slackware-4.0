/* gtomk glue code.
   Written by <a href="mailto:tiggr@gerbil.org">Pieter J. Schoenmakers</a>

   Copyright &copy; 1998 Pieter J. Schoenmakers.

   This file is part of GTOMK.  GTOMK is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the GTOMK distribution; see the file COPYING.LIB.

   $Id: glue.h,v 1.7 1999/04/25 18:40:33 tiggr Exp $  */

#include <gtk/gtk.h>
#include <tom/util.h>

#define GTK(O)  ((GtkObject *) (O))

DECL_USEL (tom, _pi__byteStringContents);

typedef struct
{
  tom_object rcv;
  selector sel;
  unsigned int prefix_sender: 1;
  unsigned int allow_mismatch: 1;
} gtomk_glue;

void gtomk_signal_relay (GtkObject *object, gtomk_glue *data,
			 gint nargs, GtkArg *args);

void gtomk_idle_fire (gtomk_glue *data);

void gtomk_free (void *);

void tomwidget_object_set_arg (GtkObject *object, GtkArg *arg, guint arg_id);
void tomwidget_object_get_arg (GtkObject *object, GtkArg *arg, guint arg_id);
void tomwidget_object_shutdown (GtkObject *object);
void tomwidget_object_destroy (GtkObject *object);
void tomwidget_object_finalize (GtkObject *object);

void tomwidget_widget_show (GtkWidget *widget);
void tomwidget_widget_show_all (GtkWidget *widget);
void tomwidget_widget_hide (GtkWidget *widget);
void tomwidget_widget_hide_all (GtkWidget *widget);
void tomwidget_widget_map (GtkWidget *widget);
void tomwidget_widget_unmap (GtkWidget *widget);
void tomwidget_widget_realize (GtkWidget *widget);
void tomwidget_widget_unrealize (GtkWidget *widget);
void tomwidget_widget_draw (GtkWidget *widget,
			    GdkRectangle *area);
void tomwidget_widget_draw_focus (GtkWidget *widget);
void tomwidget_widget_draw_default (GtkWidget *widget);
void tomwidget_widget_size_request (GtkWidget *widget,
				    GtkRequisition *requisition);
void tomwidget_widget_size_allocate (GtkWidget *widget,
				     GtkAllocation *allocation);
void tomwidget_widget_state_changed (GtkWidget *widget,
				     GtkStateType previous_state);
void tomwidget_widget_parent_set (GtkWidget *widget,
				  GtkWidget *previous_parent);
void tomwidget_widget_style_set (GtkWidget *widget,
				 GtkStyle *previous_style);
gint tomwidget_widget_add_accelerator (GtkWidget *widget,
				       guint accel_signal_id,
				       GtkAccelGroup *accel_group,
				       guint accel_key,
				       GdkModifierType accel_mods,
				       GtkAccelFlags accel_flags);
void tomwidget_widget_remove_accelerator (GtkWidget *widget,
					  GtkAccelGroup *accel_group,
					  guint accel_key,
					  GdkModifierType accel_mods);
void tomwidget_widget_grab_focus (GtkWidget *widget);
gint tomwidget_widget_event (GtkWidget *widget,
			     GdkEvent *event);
gint tomwidget_widget_button_press_event (GtkWidget *widget,
					  GdkEventButton *event);
gint tomwidget_widget_button_release_event (GtkWidget *widget,
					    GdkEventButton *event);
gint tomwidget_widget_motion_notify_event (GtkWidget *widget,
				    GdkEventMotion *event);
gint tomwidget_widget_delete_event (GtkWidget *widget,
				    GdkEventAny *event);
gint tomwidget_widget_destroy_event (GtkWidget *widget,
				    GdkEventAny *event);
gint tomwidget_widget_expose_event (GtkWidget *widget,
				    GdkEventExpose *event);
gint tomwidget_widget_key_press_event (GtkWidget *widget,
				    GdkEventKey *event);
gint tomwidget_widget_key_release_event (GtkWidget *widget,
				    GdkEventKey *event);
gint tomwidget_widget_enter_notify_event (GtkWidget *widget,
					  GdkEventCrossing *event);
gint tomwidget_widget_leave_notify_event (GtkWidget *widget,
					  GdkEventCrossing *event);
gint tomwidget_widget_configure_event (GtkWidget *widget,
				       GdkEventConfigure *event);
gint tomwidget_widget_focus_in_event (GtkWidget *widget,
				      GdkEventFocus *event);
gint tomwidget_widget_focus_out_event (GtkWidget *widget,
				       GdkEventFocus *event);
gint tomwidget_widget_map_event (GtkWidget *widget,
				 GdkEventAny *event);
gint tomwidget_widget_unmap_event (GtkWidget *widget,
				   GdkEventAny *event);
gint tomwidget_widget_property_notify_event (GtkWidget *widget,
					     GdkEventProperty *event);
gint tomwidget_widget_selection_clear_event (GtkWidget *widget,
					     GdkEventSelection *event);
gint tomwidget_widget_selection_request_event (GtkWidget *widget,
					       GdkEventSelection *event);
gint tomwidget_widget_selection_notify_event (GtkWidget *widget,
					      GdkEventSelection *event);
gint tomwidget_widget_proximity_in_event (GtkWidget *widget,
					  GdkEventProximity *event);
gint tomwidget_widget_proximity_out_event (GtkWidget *widget,
					   GdkEventProximity *event);
gint tomwidget_widget_visibility_notify_event (GtkWidget *widget,
					       GdkEventVisibility *event);
gint tomwidget_widget_client_event (GtkWidget *widget,
				    GdkEventClient *event);
gint tomwidget_widget_no_expose_event (GtkWidget *widget,
				       GdkEventAny *event);
void tomwidget_widget_selection_get (GtkWidget *widget,
				     GtkSelectionData *selection_data,
				     guint info,
				     guint time);
void tomwidget_widget_selection_received (GtkWidget *widget,
					  GtkSelectionData *selection_data,
					  guint time);
void tomwidget_widget_drag_begin (GtkWidget *widget,
				  GdkDragContext *context);
void tomwidget_widget_drag_end (GtkWidget *widget,
				GdkDragContext *context);
void tomwidget_widget_drag_data_get (GtkWidget *widget,
				     GdkDragContext *context,
				     GtkSelectionData *selection_data,
				     guint info,
				     guint time);
void tomwidget_widget_drag_data_delete (GtkWidget *widget,
					GdkDragContext *context);
void tomwidget_widget_drag_leave (GtkWidget *widget,
				  GdkDragContext *context,
				  guint time);
gboolean tomwidget_widget_drag_motion (GtkWidget *widget,
				       GdkDragContext *context,
				       gint x,
				       gint y,
				       guint time);
gboolean tomwidget_widget_drag_drop (GtkWidget *widget,
				     GdkDragContext *context,
				     gint x,
				     gint y,
				     guint time);
void tomwidget_widget_drag_data_received (GtkWidget *widget,
					  GdkDragContext *context,
					  gint x,
					  gint y,
					  GtkSelectionData *selection_data,
					  guint info,
					  guint time);
void tomwidget_widget_debug_msg (GtkWidget *widget,
				 const gchar *string);
