/* tomgnome glue code.
   Written by <a href="mailto:tiggr@gerbil.org">Pieter J. Schoenmakers</a>

   Copyright &copy; 1999 Pieter J. Schoenmakers.

   This file is part of tomgnome.  tomgnome is distributed under the terms
   of the GNU Library General Public License, a copy of which can be found
   in the tomgnome distribution; see the file COPYING.LIB.

   $Id: glue.h,v 1.4 1999/04/30 20:46:41 tiggr Exp $  */

#include <libgnome/libgnome.h>
#include <libgnomeui/libgnomeui.h>
#include <tom/util.h>

/* If TOMCANVASITEM_CREATED is set, it will be the proxy of the
   GnomeTomCanvasItem being created.  */
extern void *tomcanvasitem_created;

void tomcanvasitem_object_set_arg (GtkObject *object,
				   GtkArg *arg, guint arg_id);
void tomcanvasitem_object_get_arg (GtkObject *object,
				   GtkArg *arg, guint arg_id);
void tomcanvasitem_object_shutdown (GtkObject *object);
void tomcanvasitem_object_destroy (GtkObject *object);
void tomcanvasitem_object_finalize (GtkObject *object);

void tomcanvasitem_canvas_item_update (GnomeCanvasItem *item, double *affine,
				       ArtSVP *clip_path, int flags);
void tomcanvasitem_canvas_item_realize (GnomeCanvasItem *item);
void tomcanvasitem_canvas_item_unrealize (GnomeCanvasItem *item);
void tomcanvasitem_canvas_item_map (GnomeCanvasItem *item);
void tomcanvasitem_canvas_item_unmap (GnomeCanvasItem *item);
ArtUta *tomcanvasitem_canvas_item_coverage (GnomeCanvasItem *item);
void tomcanvasitem_canvas_item_draw (GnomeCanvasItem *item,
				     GdkDrawable *drawable,
				     int x, int y, int width, int height);
void tomcanvasitem_canvas_item_render (GnomeCanvasItem *item,
				       GnomeCanvasBuf *buf);
double tomcanvasitem_canvas_item_point (GnomeCanvasItem *item,
					double x, double y, int cx, int cy,
					GnomeCanvasItem **actual_item);
void tomcanvasitem_canvas_item_translate (GnomeCanvasItem *item,
					  double dx, double dy);
void tomcanvasitem_canvas_item_bounds (GnomeCanvasItem *item, double *x1,
				       double *y1, double *x2, double *y2);
int tomcanvasitem_canvas_item_event (GnomeCanvasItem *item, GdkEvent *event);
