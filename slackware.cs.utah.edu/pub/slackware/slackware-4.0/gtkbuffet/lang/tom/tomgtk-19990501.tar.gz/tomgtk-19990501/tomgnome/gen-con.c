/* Generate GNOME constants for use in tomgnome.
   Written by Andreas Kostyrka <yacc@gerbil.org>

   Copyright &copy; 1998, 1999 Andreas Kostyrka.

   This file is part of tomgnome.  tomgnome is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the tomgtk distribution; see the file COPYING.LIB.

   $Id: gen-con.c,v 1.10 1999/04/30 20:46:39 tiggr Exp $  */

#include <libgnome/libgnome.h>
#include <libgnomeui/libgnomeui.h>

#define DI(MACRO)  \
  printf ("  const " #MACRO " = %d;\n", MACRO)

int
main (int argc, char **argv)
{
  printf ("implementation class Constants: gdomk.Constants\n{\n");

  /* From include/libgnomeui/gnome-canvas.h.  */

  /* Object flags for items */
  DI (GNOME_CANVAS_ITEM_REALIZED);
  DI (GNOME_CANVAS_ITEM_MAPPED);
  DI (GNOME_CANVAS_ITEM_ALWAYS_REDRAW);
  DI (GNOME_CANVAS_ITEM_VISIBLE);
  DI (GNOME_CANVAS_ITEM_NEED_UPDATE);
  DI (GNOME_CANVAS_ITEM_NEED_AFFINE);
  DI (GNOME_CANVAS_ITEM_NEED_CLIP);
  DI (GNOME_CANVAS_ITEM_NEED_VIS);
  DI (GNOME_CANVAS_ITEM_AFFINE_FULL);

  /* Update flags for items */
  DI (GNOME_CANVAS_UPDATE_REQUESTED);
  DI (GNOME_CANVAS_UPDATE_AFFINE);
  DI (GNOME_CANVAS_UPDATE_CLIP);
  DI (GNOME_CANVAS_UPDATE_VISIBILITY);
  DI (GNOME_CANVAS_UPDATE_IS_VISIBLE);

  /* From .../include/libgnomeui/gnome-uidefs.h.  */
  DI (GNOME_PAD);
  DI (GNOME_PAD_SMALL);
  DI (GNOME_PAD_BIG);
  DI (GNOME_YES);
  DI (GNOME_NO);
  DI (GNOME_OK);
  DI (GNOME_CANCEL);
  DI (GTK_CLOCK_INCREASING);
  DI (GTK_CLOCK_DECREASING);
  DI (GTK_CLOCK_REALTIME);
  DI (GTK_CALENDAR_SHOW_HEADING);
  DI (GTK_CALENDAR_SHOW_DAY_NAMES);
  DI (GTK_CALENDAR_NO_MONTH_CHANGE);
  DI (GNOME_INTERACT_NONE);
  DI (GNOME_INTERACT_ERRORS);
  DI (GNOME_INTERACT_ANY);
  DI (GNOME_DIALOG_ERROR);
  DI (GNOME_DIALOG_NORMAL);
  DI (GNOME_SAVE_GLOBAL);
  DI (GNOME_SAVE_LOCAL);
  DI (GNOME_SAVE_BOTH);
  DI (GNOME_RESTART_IF_RUNNING);
  DI (GNOME_RESTART_ANYWAY);
  DI (GNOME_RESTART_IMMEDIATELY);
  DI (GNOME_RESTART_NEVER);
  DI (GNOME_CLIENT_IDLE);
  DI (GNOME_MDI_NOTEBOOK);
  DI (GNOME_MDI_TOPLEVEL);
  DI (GNOME_MDI_MODAL);

  /* gnome-font-picker.h */
  DI (GNOME_FONT_PICKER_MODE_PIXMAP);
  DI (GNOME_FONT_PICKER_MODE_FONT_INFO);
  DI (GNOME_FONT_PICKER_MODE_USER_WIDGET);
  DI (GNOME_FONT_PICKER_MODE_UNKNOWN);

  printf ("}\nend;\nimplementation instance Constants end;\n");

  return 0;
}

