/* gdomk glue code.
   Written by <a href="mailto:tiggr@gerbil.org">Pieter J. Schoenmakers</a>

   Copyright &copy; 1998 Pieter J. Schoenmakers.

   This file is part of GDOMK.  GDOMK is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the GDOMK distribution; see the file COPYING.LIB.

   $Id: glue.h,v 1.1 1998/04/02 14:47:10 tiggr Exp $  */

#include <gdk/gdk.h>
