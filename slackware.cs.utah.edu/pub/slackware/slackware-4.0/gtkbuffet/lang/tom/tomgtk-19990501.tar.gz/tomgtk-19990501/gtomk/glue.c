/* gtomk glue code.
   Written by <a href="mailto:tiggr@gerbil.org">Pieter J. Schoenmakers</a>

   Copyright &copy; 1998 Pieter J. Schoenmakers.

   This file is part of GTOMK.	GTOMK is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the GTOMK distribution; see the file COPYING.LIB.

   $Id: glue.c,v 1.14 1999/04/25 18:40:32 tiggr Exp $  */

#include "gtomk-r.h"
#include "glue.h"
#include <trt/trt.h>
#include <stdarg.h>
#include <stdio.h>

static void
sig_fatal (int nargs, GtkArg *args, gtomk_glue *cb, char *fmt, ...)
{
  va_list ap;
  int i;

  fprintf (stderr, "TOM/Gtk signal dispatch problem: ");
  va_start (ap, fmt);
  vfprintf (stderr, fmt, ap);
  va_end (ap);
  putc ('\n', stderr);

  fprintf (stderr, "selector: %s (allow_mismatch=%d)\n",
	   cb->sel->name.s, cb->allow_mismatch);
  fprintf (stderr, "signal: #args=%d + %d", nargs, cb->prefix_sender);

  for (i = 0; i < nargs; i++)
    fprintf (stderr, "%s%s", i ? " " : " (", gtk_type_name (args[i].type));
  if (nargs)
    putc (')', stderr);

  fprintf (stderr, " retval=%s\n", gtk_type_name (args[nargs].type));
  abort ();
}

static void dump_gtkarg (FILE *out, int nargs, GtkArg *args) 
{
  int i;
  for (i=0; i<nargs; i++) {
    fprintf(out, "GTKARG[%d].type == %d\n", i, args[i].type);
    fprintf(out, "GTKARG[%d].name == %s\n", i, args[i].name);
  }
}

void
gtomk_signal_relay (GtkObject *object, gtomk_glue *cb,
		    gint nargs, GtkArg *sig_args)
{
  int i, args_size, extra_args = cb->prefix_sender;
  builtin_return_type *result, local_result;
  union apply_args *args;
  selector sel = cb->sel;
  GtkType at;

  if (sel->in->num != nargs + extra_args
      && !(cb->allow_mismatch
	   && sel->in->num <= nargs + extra_args))
    sig_fatal (nargs, sig_args, cb, "#args mismatch");

  args_size = 2 * sizeof (void *) + APPLY_ARGS_REG_SIZE;
  args = alloca (args_size);

  APPLY_ARGS_START (sel);
  args->stack = alloca (APPLY_ARGS_STACK_SIZE (sel));
  APPLY_ARGS_EMIT_REFERENCE (cb->rcv);
  APPLY_ARGS_EMIT_SELECTOR (sel);

  if (extra_args)
    if (sel->in->args[0] == TRT_TE_REFERENCE)
      {
	tom_object sender = TRT_SEND (_PI_, CREF (gtomk_GtkObject),
				      SEL (r_proxy_p_create__o), object, 1);
	APPLY_ARGS_EMIT_REFERENCE (sender);
      }
    else if (sel->in->args[0] == TRT_TE_POINTER)
      APPLY_ARGS_EMIT_POINTER (object);
    else
      sig_fatal (nargs, sig_args, cb,
		 ": first selector arg not object or pointer");

  for (i = extra_args; i < sel->in->num; i++)
    {
      at = sig_args[i - extra_args].type;
      switch (GTK_FUNDAMENTAL_TYPE (at))
	{
	  void *p;
	  int helper_i;
	  char helper_c;
	  
	case GTK_TYPE_BOOL:
	  helper_i = GTK_VALUE_CHAR (sig_args[i-extra_args]);
	  if (sel->in->args[i] != TRT_TE_BOOLEAN)
	    sig_fatal (nargs, sig_args, cb, "expected boolean for sigarg %d",
		       i - extra_args);
	  APPLY_ARGS_EMIT_BYTE (helper_i);
	  break;
	  
	case GTK_TYPE_CHAR:
	  helper_c = GTK_VALUE_CHAR (sig_args[i-extra_args]);
	  if (sel->in->args[i] != TRT_TE_BYTE)
	    sig_fatal (nargs, sig_args, cb, "expected byte for sigarg %d",
		       i - extra_args);
	  APPLY_ARGS_EMIT_BYTE (helper_i);
	  break;

	case GTK_TYPE_INT:
	  /* XXX This is potentially wrong.  TOM doesn't have unsigned
	     integers -> map them to signed integers.
	     Mon Apr 20 00:16:23 MEST 1998 <andreas@ag.or.at>  */
	case GTK_TYPE_UINT:
	  helper_i = GTK_VALUE_INT (sig_args[i-extra_args]);
	  if (sel->in->args[i] != TRT_TE_INT)
	    sig_fatal (nargs, sig_args, cb, "expected int for sigarg %d",
		       i - extra_args);
	  APPLY_ARGS_EMIT_INT (helper_i);
	  break;

	case GTK_TYPE_POINTER:
	  p = GTK_VALUE_POINTER (sig_args[i-extra_args]);
	  if (sel->in->args[i] != TRT_TE_POINTER
	      && sel->in->args[i] != TRT_TE_REFERENCE)
	    sig_fatal (nargs, sig_args, cb, "expected int for sigarg %d",
		       i - extra_args);
	  if (sel->in->args[i] == TRT_TE_REFERENCE)
	    {
	      tom_object pobj = TRT_SEND (_PI_, CREF (gtomk_GtkObject),
					  SEL (r_proxy_p_create__o), p, 1);
	      APPLY_ARGS_EMIT_REFERENCE (pobj);
	    }
	  else 
	    APPLY_ARGS_EMIT_POINTER (p);
	  break;
	  
	case GTK_TYPE_BOXED:
	  p = GTK_VALUE_BOXED (sig_args[i - extra_args]);
	  switch (sel->in->args[i])
	    {
	    case TRT_TE_POINTER:
	      break;

	    bad:
	    default:
	      sig_fatal (nargs, sig_args, cb,
			 "unimplemented arg conversion at sigsarg %d",
			 i - extra_args);
	      break;
	    }

	  APPLY_ARGS_EMIT_REFERENCE (p);
	  break;

	case GTK_TYPE_OBJECT:
	  p = GTK_VALUE_OBJECT (sig_args[i - extra_args]);
	  switch (sel->in->args[i])
	    {
	    case TRT_TE_POINTER:
	      break;
	    case TRT_TE_REFERENCE:
	      p = TRT_SEND (_PI_, CREF (gtomk_GtkObject),
			    SEL (r_proxy_p_create__o), p, 1);
	      break;
	    default:
	      goto bad;
	    }
	  APPLY_ARGS_EMIT_REFERENCE (p);
	  break;

	default:
	  dump_gtkarg (stderr, nargs, sig_args);
	  fflush (stderr);
	  sig_fatal (nargs, sig_args, cb,
		     "unhandled gtk type (%d) at sigarg %d",
		     GTK_FUNDAMENTAL_TYPE (at), i - extra_args);
	  break;
	}
    }

  APPLY_ARGS_COMPLETE ();
  result = APPLY_ARGS_APPLY ((void (*) ()) trt_lookup (cb->rcv, cb->sel),
			     args, APPLY_ARGS_ACTUAL_SIZE (), &local_result);

  if (sel->out->num > 1)
    sig_fatal (nargs, sig_args, cb, "unhandled #out args");

  i = sel->out->num == 1 ? sel->out->args[0] : TRT_TE_VOID;
  at = sig_args[nargs].type;

  switch (i)
    {
    case TRT_TE_VOID:
      if (GTK_FUNDAMENTAL_TYPE (at) != GTK_TYPE_NONE)
	goto bad_retval;
      break;

    case TRT_TE_BOOLEAN:
    case TRT_TE_BYTE:
    case TRT_TE_CHAR:
    case TRT_TE_INT:
      switch (GTK_FUNDAMENTAL_TYPE (at))
	{
	case GTK_TYPE_INVALID:
	case GTK_TYPE_NONE:
	  break;
	case GTK_TYPE_CHAR:
	  *GTK_RETLOC_CHAR (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_BOOL:
	  *GTK_RETLOC_BOOL (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_INT:
	  *GTK_RETLOC_INT (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_UINT:
	  *GTK_RETLOC_UINT (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_ENUM:
	  *GTK_RETLOC_ENUM (sig_args[nargs]) = result->i.i;
	  break;
	case GTK_TYPE_FLAGS:
	  *GTK_RETLOC_FLAGS (sig_args[nargs]) = result->i.i;
	  break;

	default:
	bad_retval:
	  if (!cb->allow_mismatch)
	    sig_fatal (nargs, sig_args, cb, "unhandled out arg conversion");
	  else switch (GTK_FUNDAMENTAL_TYPE (at))
	    {
	    case GTK_TYPE_INVALID:
	    case GTK_TYPE_NONE:
	      break;
	    case GTK_TYPE_CHAR:
	      *GTK_RETLOC_CHAR (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_BOOL:
	      *GTK_RETLOC_BOOL (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_INT:
	      *GTK_RETLOC_INT (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_UINT:
	      *GTK_RETLOC_UINT (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_ENUM:
	      *GTK_RETLOC_ENUM (sig_args[nargs]) = 0;
	      break;
	    case GTK_TYPE_FLAGS:
	      *GTK_RETLOC_FLAGS (sig_args[nargs]) = 0;
	      break;
	    default:
	      sig_fatal (nargs, sig_args, cb, "unhandled default conversion");
	    }
	}
      break;

    case TRT_TE_LONG:
      sig_fatal (nargs, sig_args, cb, "Gtk doesn't know about 64bit longs :(");
      break;
    case TRT_TE_SELECTOR:
      sig_fatal (nargs, sig_args, cb, "Gtk doesn't know about selectors :(");  
      break;
    case TRT_TE_POINTER:
      *GTK_RETLOC_POINTER (sig_args[nargs]) = result->p.p;
      break;
    case TRT_TE_REFERENCE:
      *GTK_RETLOC_OBJECT (sig_args[nargs])
	= TRT_SEND((pointer_imp), result->p.p, SEL (p_gtkObject));
      break;
    case TRT_TE_FLOAT:
      *GTK_RETLOC_FLOAT (sig_args[nargs]) = RETURN_RETRIEVE_FLOAT (result);
      break;
    case TRT_TE_DOUBLE:
      *GTK_RETLOC_DOUBLE (sig_args[nargs]) = RETURN_RETRIEVE_DOUBLE (result);
      break;

    default:
      sig_fatal (nargs, sig_args, cb, "unhandled out arg TOM type");
      break;
    }

  APPLY_ARGS_END ();
}

void
gtomk_idle_fire (gtomk_glue *data)
{
  TRT_SEND (, data->rcv, USEL (tom, v_perform_s___r), data->sel, (void *) 0);
}

void
gtomk_free (void *p)
{
  g_free (p);
}

/******************** TOMWidget ********************/

/* Return the pre-existing TOM object corresponding to the Gtk OBJECT.  */
static __inline__ void *
tom_proxy (void *object)
{
  return !object ? 0 : TRT_SEND (_PI_, CREF (gtomk_GtkObject),
				 SEL (r_proxy_p_create__o), object, 0);
}

void
tomwidget_object_set_arg (GtkObject *object,
			  GtkArg    *arg,
			  guint      arg_id)
{
  void *to = tom_proxy (object);
  TRT_SEND (, to, SEL (v_signal_set_arg__pi_), arg, arg_id);
}

void
tomwidget_object_get_arg (GtkObject *object,
			  GtkArg    *arg,
			  guint      arg_id)
{
  void *to = tom_proxy (object);
  TRT_SEND (, to, SEL (v_signal_get_arg__pi_), arg, arg_id);
}

void
tomwidget_object_shutdown (GtkObject *object)
{
  void *to = tom_proxy (object);
  TRT_SEND (, to, SEL (v_signal_shutdown));
}

void
tomwidget_object_destroy (GtkObject *object)
{
  void *to = tom_proxy (object);

  /* XXX Isn't it always too late here?  (Having invoked destroy_proxy.)  */
  if (to)
    TRT_SEND (, to, SEL (v_signal_destroy));
}
  
void
tomwidget_object_finalize (GtkObject *object)
{
  void *to = tom_proxy (object);

  /* XXX Isn't it always too late here?  (Having invoked destroy_proxy.)  */
  if (to)
    TRT_SEND (, to, SEL (v_signal_finalize));
}

void
tomwidget_widget_show (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_show));
}

void
tomwidget_widget_show_all (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_show_all));
}

void
tomwidget_widget_hide (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_hide));
}

void
tomwidget_widget_hide_all (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_hide_all));
}

void
tomwidget_widget_map (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_map));
}

void
tomwidget_widget_unmap (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_unmap));
}

void
tomwidget_widget_realize (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_realize));
}

void
tomwidget_widget_unrealize (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_unrealize));
}

void
tomwidget_widget_draw (GtkWidget *widget,
		       GdkRectangle *area)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_draw__iiii_),
	    (tom_int) area->x, (tom_int) area->y,
	    (tom_int) area->width, (tom_int) area->height);
}

void
tomwidget_widget_draw_focus (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_draw_focus));
}

void
tomwidget_widget_draw_default (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_draw_default));
}

void
tomwidget_widget_size_request (GtkWidget *widget,
			       GtkRequisition *requisition)
{
  void *to = tom_proxy (widget);
  tom_int w, h;

  w = TRT_SEND (_II_, to, SEL (_ii__signal_size_request), &h);
  requisition->width = w;
  requisition->height = h;
}

void
tomwidget_widget_size_allocate (GtkWidget *widget,
				GtkAllocation *allocation)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_size_allocate__iiii_),
	    (tom_int) allocation->x, (tom_int) allocation->y,
	    (tom_int) allocation->width, (tom_int) allocation->height);
}

void
tomwidget_widget_state_changed (GtkWidget *widget,
				GtkStateType previous_state)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_state_changed_i), previous_state);
}

void
tomwidget_widget_parent_set (GtkWidget *widget,
			     GtkWidget *previous_parent)
{
  void *to = tom_proxy (widget);
  void *p = tom_proxy (previous_parent);

  TRT_SEND (, to, SEL (v_signal_parent_set_r), p);
}

void
tomwidget_widget_style_set (GtkWidget *widget,
			    GtkStyle *previous_style)
{
  void *to = tom_proxy (widget);
  void *st = tom_proxy (previous_style);

  TRT_SEND (, to, SEL (v_signal_style_set_r), st);
}

gint
tomwidget_widget_add_accelerator (GtkWidget *widget,
				  guint accel_signal_id,
				  GtkAccelGroup *accel_group,
				  guint accel_key,
				  GdkModifierType accel_mods,
				  GtkAccelFlags accel_flags)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_remove_accelerator (GtkWidget *widget,
				     GtkAccelGroup *accel_group,
				     guint accel_key,
				     GdkModifierType accel_mods)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_grab_focus (GtkWidget *widget)
{
  void *to = tom_proxy (widget);
  TRT_SEND (, to, SEL (v_signal_grab_focus));
}

gint
tomwidget_widget_event (GtkWidget *widget,
			GdkEvent *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_event_p), event);
}

gint
tomwidget_widget_button_press_event (GtkWidget *widget,
				     GdkEventButton *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_button_press_event_p), event);
}

gint
tomwidget_widget_button_release_event (GtkWidget *widget,
				       GdkEventButton *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_button_release_event_p), event);
}

gint
tomwidget_widget_motion_notify_event (GtkWidget *widget,
				      GdkEventMotion *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_motion_notify_event_p), event);
}

gint
tomwidget_widget_delete_event (GtkWidget *widget,
			       GdkEventAny *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_delete_event_p), event);
}

gint
tomwidget_widget_destroy_event (GtkWidget *widget,
				GdkEventAny *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_destroy_event_p), event);
}

gint
tomwidget_widget_expose_event (GtkWidget *widget,
			       GdkEventExpose *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_expose_event_p), event);
}

gint
tomwidget_widget_key_press_event (GtkWidget *widget,
				  GdkEventKey *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_key_press_event_p), event);
}

gint
tomwidget_widget_key_release_event (GtkWidget *widget,
				    GdkEventKey *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_key_release_event_p), event);
}

gint
tomwidget_widget_enter_notify_event (GtkWidget *widget,
				     GdkEventCrossing *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_enter_notify_event_p), event);
}

gint
tomwidget_widget_leave_notify_event (GtkWidget *widget,
				     GdkEventCrossing *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_leave_notify_event_p), event);
}

gint
tomwidget_widget_configure_event (GtkWidget *widget,
				  GdkEventConfigure *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_configure_event_p), event);
}

gint
tomwidget_widget_focus_in_event (GtkWidget *widget,
				 GdkEventFocus *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_focus_in_event_p), event);
}

gint
tomwidget_widget_focus_out_event (GtkWidget *widget,
				  GdkEventFocus *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_focus_out_event_p), event);
}

gint
tomwidget_widget_map_event (GtkWidget *widget,
			    GdkEventAny *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_map_event_p), event);
}

gint
tomwidget_widget_unmap_event (GtkWidget *widget,
			      GdkEventAny *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_unmap_event_p), event);
}

gint
tomwidget_widget_property_notify_event (GtkWidget *widget,
					GdkEventProperty *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_property_notify_event_p), event);
}

gint
tomwidget_widget_selection_clear_event (GtkWidget *widget,
					GdkEventSelection *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_selection_clear_event_p), event);
}

gint
tomwidget_widget_selection_request_event (GtkWidget *widget,
					  GdkEventSelection *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_selection_request_event_p), event);
}

gint
tomwidget_widget_selection_notify_event (GtkWidget *widget,
					 GdkEventSelection *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_selection_notify_event_p), event);
}

gint
tomwidget_widget_proximity_in_event (GtkWidget *widget,
				     GdkEventProximity *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_proximity_in_event_p), event);
}

gint
tomwidget_widget_proximity_out_event (GtkWidget *widget,
				      GdkEventProximity *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_proximity_out_event_p), event);
}

gint
tomwidget_widget_visibility_notify_event (GtkWidget *widget,
					  GdkEventVisibility *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_visibility_notify_event_p), event);
}

gint
tomwidget_widget_client_event (GtkWidget *widget,
			       GdkEventClient *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_client_event_p), event);
}

gint
tomwidget_widget_no_expose_event (GtkWidget *widget,
				  GdkEventAny *event)
{
  void *to = tom_proxy (widget);
  return TRT_SEND (_II_, to, SEL (i_signal_no_expose_event_p), event);
}

void
tomwidget_widget_selection_get (GtkWidget *widget,
				GtkSelectionData *selection_data,
				guint info,
				guint time)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_selection_received (GtkWidget *widget,
				     GtkSelectionData *selection_data,
				     guint time)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_drag_begin (GtkWidget *widget,
			     GdkDragContext *context)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_drag_end (GtkWidget *widget,
			   GdkDragContext *context)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_drag_data_get (GtkWidget *widget,
				GdkDragContext *context,
				GtkSelectionData *selection_data,
				guint info,
				guint time)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_drag_data_delete (GtkWidget *widget,
				   GdkDragContext *context)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_drag_leave (GtkWidget *widget,
			     GdkDragContext *context,
			     guint time)
{
  /* Not yet implemented.  */
  abort ();
}

gboolean
tomwidget_widget_drag_motion (GtkWidget *widget,
			      GdkDragContext *context,
			      gint x,
			      gint y,
			      guint time)
{
  /* Not yet implemented.  */
  abort ();
}

gboolean
tomwidget_widget_drag_drop (GtkWidget *widget,
			    GdkDragContext *context,
			    gint x,
			    gint y,
			    guint time)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_drag_data_received (GtkWidget *widget,
				     GdkDragContext *context,
				     gint x,
				     gint y,
				     GtkSelectionData *selection_data,
				     guint info,
				     guint time)
{
  /* Not yet implemented.  */
  abort ();
}

void
tomwidget_widget_debug_msg (GtkWidget *widget,
			    const gchar *string)
{
  /* Not yet implemented.  */
  abort ();
}

