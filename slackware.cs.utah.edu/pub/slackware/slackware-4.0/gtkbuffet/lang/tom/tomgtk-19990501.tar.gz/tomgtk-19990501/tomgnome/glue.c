/* Tomgnome glue code.
   Written by <a href="mailto:yacc@gerbil.org">Andreas Kostyrka</a>

   Copyright &copy; 1998 Andreas Kostyrka.

   This file is part of tomgnome. tomgnome is distributed under the terms of
   the GNU Library General Public License, a copy of which can be found
   in the tomgtk distribution; see the file COPYING.LIB.

   $Id: glue.c,v 1.4 1999/04/30 20:46:40 tiggr Exp $
*/

#include "tomgnome-r.h"
#include "glue.h"
#include <tom/util.h>
#include <trt/trt.h>
#include <stdarg.h>
#include <stdio.h>

void *tomcanvasitem_creation_class;
void *tomcanvasitem_created;

static __inline__ void
mark_if_needed_and_not_nil (struct trt_instance *o)
{
  if (o && TGC_COLOUR (o->asi) == TGC_WHITE)
    trt_make_gray (o);
}

void
i_tomgnome_GnomeUIArray_v_gc_mark_elements (tom_object self, selector cmd)
{
  struct _es_i_tomgnome_GnomeUIArray *this
    = trt_ext_address (self, _ei_i_tomgnome_GnomeUIArray);
  int i, n;

  for (i = 0, n = this->length; i < n; i++)
    mark_if_needed_and_not_nil (((struct trt_instance **)this->ovalue)[i]);
}

tom_object
  c_tomgnome_GnomeUIArray_r_with_x (tom_object self, selector cmd, ...)
{
  int i, n = cmd->in->num;
  tom_object res;
  tom_object endofinfo;
  va_list ap;
  DECL_USEL (tom, r_new);
  DECL_SEL (v_add_r);

  va_start (ap, cmd);

  res = TRT_SEND ((reference_imp), self, USEL (tom, r_new));
  for (i=0; i<n; i++)
    {
      if (cmd->in->args[i]==TRT_TE_REFERENCE)
	{
	  TRT_SEND (, res, SEL (v_add_r), va_arg (ap, tom_object));
	}
      else
	{
	  fprintf(stderr,"GnomeUIArray::with called with non object.\n");
	}
    }

  endofinfo = TRT_SEND (_PI_, CREF (tomgnome_GnomeUIInfoEndOfInfo),
			USEL (tom, r_new));
  TRT_SEND (, res, SEL (v_add_r), endofinfo);

  return res;
}

/******************** TOMCanvasItem ********************/

/* Return the pre-existing TOM object corresponding to the Gtk OBJECT.
   Properly interact with the TOMCANVASITEM_CREATED.  */
static void *
tom_proxy (void *object)
{
  void *result;

  if (!object)
    result = 0;
  else if (tomcanvasitem_created)
    {
      result = TRT_SEND (_PI_, tomcanvasitem_created, SEL (r_init_p), object);
      tomcanvasitem_created = 0;
    }
  else
    result = TRT_SEND (_PI_, CREF (gtomk_GtkObject),
		       SEL (r_proxy_p_create__o), object, 0);

  return result;
}

void
tomcanvasitem_object_set_arg (GtkObject *object,
			      GtkArg *arg, guint arg_id)
{
  void *to = tom_proxy (object);
  TRT_SEND (, to, SEL (v_signal_set_arg__pi_), arg, arg_id);
}

void
tomcanvasitem_object_get_arg (GtkObject *object,
				   GtkArg *arg, guint arg_id)
{
  void *to = tom_proxy (object);
  TRT_SEND (, to, SEL (v_signal_get_arg__pi_), arg, arg_id);
}

void
tomcanvasitem_object_shutdown (GtkObject *object)
{
  void *to = tom_proxy (object);
  TRT_SEND (, to, SEL (v_signal_shutdown));
}

void
tomcanvasitem_object_destroy (GtkObject *object)
{
  void *to = tom_proxy (object);

  /* XXX Isn't it always too late here?  (Having invoked destroy_proxy.)  */
  if (to)
    TRT_SEND (, to, SEL (v_signal_destroy));
}

void
tomcanvasitem_object_finalize (GtkObject *object)
{
  void *to = tom_proxy (object);

  /* XXX Isn't it always too late here?  (Having invoked destroy_proxy.)  */
  if (to)
    TRT_SEND (, to, SEL (v_signal_finalize));
}

void
tomcanvasitem_canvas_item_update (GnomeCanvasItem *item, double *affine,
				  ArtSVP *clip_path, int flags)
{
  void *to = tom_proxy (item);
  TRT_SEND (, to, SEL (v_signal_item_update__ppi_), affine, clip_path, flags);
}

void
tomcanvasitem_canvas_item_realize (GnomeCanvasItem *item)
{
  void *to = tom_proxy (item);
  TRT_SEND (, to, SEL (v_signal_item_realize));
}

void
tomcanvasitem_canvas_item_unrealize (GnomeCanvasItem *item)
{
  void *to = tom_proxy (item);
  TRT_SEND (, to, SEL (v_signal_item_unrealize));
}

void
tomcanvasitem_canvas_item_map (GnomeCanvasItem *item)
{
  void *to = tom_proxy (item);
  TRT_SEND (, to, SEL (v_signal_item_map));
}

void
tomcanvasitem_canvas_item_unmap (GnomeCanvasItem *item)
{
  void *to = tom_proxy (item);
  TRT_SEND (, to, SEL (v_signal_item_unmap));
}

ArtUta *
tomcanvasitem_canvas_item_coverage (GnomeCanvasItem *item)
{
  void *to = tom_proxy (item);
  return TRT_SEND (_PI_, to, SEL (p_signal_item_coverage));
}

void
tomcanvasitem_canvas_item_draw (GnomeCanvasItem *item, GdkDrawable *drawable,
				int x, int y, int width, int height)
{
  void *to = tom_proxy (item);
  TRT_SEND ((void_imp), to, SEL (v_signal_item_draw__piiii_),
	    drawable, x, y, width, height);
}

void
tomcanvasitem_canvas_item_render (GnomeCanvasItem *item,
				  GnomeCanvasBuf *buf)
{
  void *to = tom_proxy (item);
  TRT_SEND (_PI_, to, SEL (v_signal_item_render_p), buf);
}

double
tomcanvasitem_canvas_item_point (GnomeCanvasItem *item,
				 double x, double y, int cx, int cy,
				 GnomeCanvasItem **actual_item)
{
  void *to = tom_proxy (item);
  return TRT_SEND (_DI_, to, SEL (_dp__signal_item_point__ddii_),
		   x, y, cx, cy, actual_item);
}

void
tomcanvasitem_canvas_item_translate (GnomeCanvasItem *item,
				     double dx, double dy)
{
  void *to = tom_proxy (item);
  return TRT_SEND ((void_imp), to, SEL (v_signal_item_translate__dd_), dx, dy);
}

void
tomcanvasitem_canvas_item_bounds (GnomeCanvasItem *item, double *x1,
				  double *y1, double *x2, double *y2)
{
  /* Not yet implemented.  */
  abort ();
}

int
tomcanvasitem_canvas_item_event (GnomeCanvasItem *item, GdkEvent *event)
{
  void *to = tom_proxy (item);
  return TRT_SEND (_II_, to, SEL (i_signal_item_event_p), event);
}

