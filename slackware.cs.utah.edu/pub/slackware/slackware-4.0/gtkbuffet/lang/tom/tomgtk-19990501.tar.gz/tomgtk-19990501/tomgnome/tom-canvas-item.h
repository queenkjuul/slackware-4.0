/* TOM/Gtk TOMCanvasItem class, the Gtk view.
   Copyright (C) 1999 Pieter Schoenmakers
   Written by Pieter Schoenmakers <tiggr@gerbil.org>

   This file is part of tomgnome.  tomgnome is distributed under the terms
   of the GNU Library General Public License, a copy of which can be found
   in the tomgnome distribution; see the file COPYING.LIB.

   $Id: tom-canvas-item.h,v 1.3 1999/04/30 20:46:45 tiggr Exp $ */

#ifndef __TOM_TOMCANVASITEM_H__
#define __TOM_TOMCANVASITEM_H__

#include <libgnomeui/gnome-canvas.h>
#include <tom/util.h>

#define GNOME_TYPE_TOM_CANVAS_ITEM  \
 (gnome_tomcanvas_item_get_type ())
#define GNOME_TOM_CANVAS_ITEM(obj)  \
 (GNOME_CHECK_CAST ((obj), GNOME_TYPE_TOM_CANVAS_ITEM, GnomeTomCanvasItem))
#define GNOME_TOM_CANVAS_ITEM_CLASS(klass)  \
 (GNOME_CHECK_CLASS_CAST ((klass), GNOME_TYPE_TOM_CANVAS_ITEM,	\
			  GnomeTomCanvasItemClass))
#define GNOME_IS_TOM_CANVAS_ITEM(obj)  \
 (GNOME_CHECK_TYPE ((obj), GNOME_TYPE_TOM_CANVAS_ITEM))
#define GNOME_IS_TOM_CANVAS_ITEM_CLASS(klass)  \
 (GNOME_CHECK_CLASS_TYPE ((klass), GNOME_TYPE_TOM_CANVAS_ITEM))

typedef struct _GnomeTomCanvasItem       GnomeTomCanvasItem;
typedef struct _GnomeTomCanvasItemClass  GnomeTomCanvasItemClass;

/* No additional instance variables.  */
struct _GnomeTomCanvasItem
{
  GnomeCanvasItem canvas_item;
};

/* No additional methods.  */
struct _GnomeTomCanvasItemClass
{
  GnomeCanvasItemClass parent_class;
};

GtkType gnome_tom_canvas_item_get_type (void);
GnomeCanvasItem *gnome_tom_canvas_item_new (GnomeCanvasGroup *parent,
					    void *proxy);

#endif
