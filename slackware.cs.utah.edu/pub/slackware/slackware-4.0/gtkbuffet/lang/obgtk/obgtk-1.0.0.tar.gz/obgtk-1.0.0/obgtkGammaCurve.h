#ifndef OBGTK_GAMMA_CURVE_H
#define OBGTK_GAMMA_CURVE_H 1

#include <obgtk/obgtkVBox.h>
#include <gtk/gtk.h>

@class Gtk_Table;
@class Gtk_Curve;
@class Gtk_Dialog;
@class Gtk_Label;
@class Gtk_Button;

@interface Gtk_GammaCurve : Gtk_VBox
{
@public
  GtkGammaCurve *gtkgammacurve;
  Gtk_Table *table;
  Gtk_Curve *curve;
  Gtk_Button *button[5];
  Gtk_Dialog *gamma_dialog;
  Gtk_Label *gamma_text;
}
- castGtkGammaCurve:(GtkGammaCurve *)castitem;
@end

#endif /* OBGTK_GAMMA_CURVE_H */
