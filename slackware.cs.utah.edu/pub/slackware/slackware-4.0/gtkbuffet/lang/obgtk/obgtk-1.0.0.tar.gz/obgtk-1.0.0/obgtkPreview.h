#ifndef OBGTK_PREVIEW_H
#define OBGTK_PREVIEW_H 1
#include "obgtkWidget.h"
#include <gtk/gtkpreview.h>

@interface Gtk_Preview : Gtk_Widget
{
@public
  GtkPreview *gtkpreview;
}
- initWithPreviewInfo:(GtkPreviewType) type;
- castGtkPreview:(GtkPreview *) castitem;
- size:(gint) width
      :(gint) height;
- put:(GdkWindow *)window
     :(GdkGC *) gc
     :(gint) srcx
     :(gint) srcy
     :(gint) destx
     :(gint) desty
     :(gint) width
     :(gint) height;
- put_row:(guchar *) src
	 :(guchar *) dest
	 :(gint) x
	 :(gint) y
	 :(gint) w;
- draw_row:(guchar *) data
	  :(gint) x
	  :(gint) y
	  :(gint) w;
- set_expand:(gint) expand;
- set_gamma:(double) gamma;
- set_color_cube:(guint) nred_shades
		:(guint) ngreen_shades
		:(guint) nblue_shades
		:(guint) ngray_shades;
- set_install_cmap:(gint) install_cmap;
- set_reserved:(gint) nreserved;
- (GdkVisual *) get_visual;
- (GdkColormap *) get_cmap;
- (GtkPreviewInfo *) get_info;

- uninit;
- reset;
@end

#endif /* OBGTK_PREVIEW_H */
