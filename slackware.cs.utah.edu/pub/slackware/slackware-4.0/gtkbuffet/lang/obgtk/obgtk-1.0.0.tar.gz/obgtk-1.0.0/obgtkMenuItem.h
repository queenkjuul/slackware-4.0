#ifndef OBGTK_MENU_ITEM_H
#define OBGTK_MENU_ITEM_H 1

#include <obgtk/obgtkItem.h>
#include <gtk/gtkmenuitem.h>

@class Gtk_Menu;

@interface Gtk_MenuItem : Gtk_Item
{
@public
  GtkMenuItem *gtkmenuitem;
}
- castGtkMenuItem:(GtkMenuItem *) castitem;
- initWithLabel:(gchar *) label;
- set_submenu:(id) submenu;
- set_placement:(GtkSubmenuPlacement) placement;
- accelerator_size;
- accelerator_text:(gchar *)buffer;
- configure     :(gint)show_toggle_indicator
 indicateSubmenu:(gint)show_submenu_indicator;
- select;
- deselect;
- activate;
- right_justify;
@end

#endif /* OBGTK_MENU_ITEM_H */
