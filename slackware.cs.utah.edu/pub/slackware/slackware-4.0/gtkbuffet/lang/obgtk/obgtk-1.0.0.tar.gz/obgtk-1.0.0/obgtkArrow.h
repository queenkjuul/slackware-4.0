#ifndef OBGTK_ARROW_H
#define OBGTK_ARROW_H 1

#include <obgtk/obgtkMisc.h>
#include <gtk/gtkarrow.h>

@interface Gtk_Arrow : Gtk_Misc
{
@public
  GtkArrow *gtkarrow;
}
- init;
- initWithArrowInfo:(GtkArrowType) arrow_type
	 typeShadow:(GtkShadowType) shadow_type;
- set      :(GtkArrowType) arrow_type
 typeShadow:(GtkShadowType) shadow_type;
@end

#endif /* OBGTK_ARROW_H */
