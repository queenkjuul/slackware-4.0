#ifndef OBGTK_TOOLTIPS_H
#define OBGTK_TOOLTIPS_H 1

#include <objc/Object.h>
#include <obgtk/obgtkWidget.h>
#include <obgtk/obgtkData.h>
#include <gtk/gtk.h>

@interface Gtk_Tooltips : Gtk_Data
{
@public
  GtkTooltips *gtktooltips;
}
- castGtkTooltips:(GtkTooltips *) castitem;
- initWithGtkWidgetLabel:(Gtk_Widget *)widget
		tipsText:(gchar *) tips_text
	     tipsPrivate:(gchar *) tips_private;
- enable;
- disable;
- set_delay:(gint) delay;
- set_tip:(Gtk_Widget *) widget
  tipsText:(gchar *) tips_text
  tipsPrivate:(gchar *) tips_private;
- set_colors:(GdkColor *) background
     colorFg:(GdkColor *) foreground;
@end

#endif /* OBGTK_TOOLTIPS_H */
