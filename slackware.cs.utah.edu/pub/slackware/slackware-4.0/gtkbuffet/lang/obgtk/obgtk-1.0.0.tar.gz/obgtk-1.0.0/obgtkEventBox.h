#ifndef OBGTK_EVENT_BOX_H
#define OBGTK_EVENT_BOX_H 1
#include <obgtk/obgtkBin.h>
#include <gtk/gtkeventbox.h>

@interface Gtk_EventBox : Gtk_Bin
{
@public
  GtkEventBox *gtkeventbox;
}
- castGtkEventBox:(GtkEventBox *) castitem;
@end

#endif /* OBGTK_HANDLE_BOX_H */
