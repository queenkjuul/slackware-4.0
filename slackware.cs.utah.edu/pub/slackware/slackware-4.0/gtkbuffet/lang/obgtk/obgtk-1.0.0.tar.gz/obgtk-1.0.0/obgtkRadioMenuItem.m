#include "obgtkRadioMenuItem.h"

@implementation Gtk_RadioMenuItem
- castGtkRadioMenuItem:(GtkRadioMenuItem *) castitem
{
  gtkradiomenuitem = castitem;
  return [super castGtkCheckMenuItem:GTK_CHECK_MENU_ITEM(castitem)];
}

- init
{
  [self error:"Gtk_RadioMenuItem: attempt to call \"init\" method on a class requiring parameters for initialization. Use \"initWithRadioGroup\" instead."];
  return self;
}

- initWithRadioGroup :(GSList *) group
{
  return [self castGtkRadioMenuItem:GTK_RADIO_MENU_ITEM(gtk_radio_menu_item_new(group))];
}

- initWithRadioGroupLabel:(GSList *) group
		   aLabel:(gchar *) label
{
  return [self castGtkRadioMenuItem:GTK_RADIO_MENU_ITEM(gtk_radio_menu_item_new_with_label(group, label))];
}

- (GSList *) group
{
  return gtk_radio_menu_item_group(gtkradiomenuitem);
}
@end
