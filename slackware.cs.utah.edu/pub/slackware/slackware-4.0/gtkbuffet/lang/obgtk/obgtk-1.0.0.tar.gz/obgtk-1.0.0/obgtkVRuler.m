#include "obgtkVRuler.h"

@implementation Gtk_VRuler
- init
{
  return [super castGtkRuler:GTK_RULER(gtk_vruler_new())];
}
@end
