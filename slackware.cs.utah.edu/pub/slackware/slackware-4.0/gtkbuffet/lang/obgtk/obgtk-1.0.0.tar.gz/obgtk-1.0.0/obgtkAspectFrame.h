#ifndef OBGTK_ASPECT_FRAME_H
#define OBGTK_ASPECT_FRAME_H 1

#include <obgtk/obgtkFrame.h> 
#include <gtk/gtkaspectframe.h>

@interface Gtk_AspectFrame : Gtk_Frame
{
@public
  GtkAspectFrame *gtkaspectframe;
}
- init;
- initWithAspectFrameInfo:(gchar *) label
		   alignX:(gfloat) xalign
		   alignY:(gfloat) yalign
		   aRatio:(gfloat) ratio
		   doObey:(gint) obey_child;
- set  :(gfloat) xalign
 alignY:(gfloat) yalign
 aRatio:(gfloat) ratio
 doObey:(gint) obey_child;
@end

#endif /* OBGTK_ASPECT_FRAME_H */
