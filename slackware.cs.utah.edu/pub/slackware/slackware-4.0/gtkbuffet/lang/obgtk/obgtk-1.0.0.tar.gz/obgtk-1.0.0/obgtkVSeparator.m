#include "obgtkVSeparator.h"

@implementation Gtk_VSeparator
- init
{
  return [super castGtkSeparator:GTK_SEPARATOR(gtk_vseparator_new())];
}
@end
