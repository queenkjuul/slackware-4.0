#ifndef OBGTK_SPIN_BUTTON_H
#define OBGTK_SPIN_BUTTON_H 1

#include <obgtk/obgtkEntry.h>
#include <obgtk/obgtkAdjustment.h>
#include <gtk/gtkspinbutton.h>

@interface Gtk_SpinButton : Gtk_Entry
{
@public
   GtkSpinButton *gtkspinbutton;
}
- castGtkSpinButton:(GtkSpinButton *) castitem;
- initWithSpinInfo:(id) adjustment
		  :(gfloat) climb_rate
		  :(gint) digits;
- set_adjustment:(id) adjustment;
- (id) get_adjustment;
- set_digits:(gint) digits;
- (gfloat) get_value_as_float;
- (gint) get_value_as_int;
- set_value:(gfloat) value;
- set_update_policy:(GtkSpinButtonUpdatePolicy) policy;
- set_numeric:(gint) numeric;
- spin:(guint) direction :(gfloat) step;
- set_wrap:(gint) wrap;
@end
#endif
