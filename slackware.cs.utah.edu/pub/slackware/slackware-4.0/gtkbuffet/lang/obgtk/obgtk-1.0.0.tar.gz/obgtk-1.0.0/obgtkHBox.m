#include "obgtkHBox.h"

@implementation Gtk_HBox
- castGtkHBox:(GtkHBox *)castitem
{
  return [super castGtkBox:GTK_BOX(castitem)];
}

- init
{
  return [self initWithBoxInfo:FALSE setSpacing:5];
}

- initWithBoxInfo:(gint) homogeneous
       setSpacing:(gint) spacing
{
  return [self castGtkHBox:GTK_HBOX(gtk_hbox_new(homogeneous, spacing))];
}
@end
