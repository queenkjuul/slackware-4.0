#ifndef OBGTK_RULER_H
#define OBGTK_RULER_H 1

#include <obgtk/obgtkWidget.h>
#include <gtk/gtkruler.h>

@interface Gtk_Ruler : Gtk_Widget
{
@public
  GtkRuler *gtkruler;
}
- castGtkRuler:(GtkRuler *)castitem;
- set_metric:(GtkMetricType) metric;
- set_range:(gfloat) lower
      Upper:(gfloat) upper
   Position:(gfloat) position
    sizeMax:(gfloat) max_size;
- draw_ticks;
- draw_pos;
@end

#endif /* OBGTK_RULER_H */
