#include "obgtkFileSelection.h"

@implementation Gtk_FileSelection
- init
{
  return [self initWithLabel:"Untitled"];
}

- initWithLabel:(gchar *) title
{
  gtkfileselection = GTK_FILE_SELECTION(gtk_file_selection_new(title));
  return [super castGtkWindow:GTK_WINDOW(gtkfileselection)];
}

- set_filename:(gchar *)filename
{
  gtk_file_selection_set_filename(gtkfileselection, filename);
  return self;
}

- (gchar *) get_filename
{
  return gtk_file_selection_get_filename(gtkfileselection);
}

- show_fileop_buttons
{
  gtk_file_selection_show_fileop_buttons(gtkfileselection);
  return self;
}

- hide_fileop_buttons
{
  gtk_file_selection_hide_fileop_buttons(gtkfileselection);
  return self;
}
@end
