#include "obgtkImage.h"

@implementation Gtk_Image
- init
{
  [self error:"Gtk_Image: attempt to call \"init\" method on a class that requires parameters for initialization. Use \"initWithImageInfo\" instead."];
  return self;
}

- initWithImageInfo:(GdkImage *) val
	    imgMask:(GdkBitmap *) mask
{
  gtkimage = GTK_IMAGE(gtk_image_new(val, mask));
  return [super castGtkMisc:GTK_MISC(gtkimage)];
}

- set   :(GdkImage *) val
 imgMask:(GdkBitmap *) mask
{
  gtk_image_set(gtkimage, val, mask);
  return self;
}

- get   :(GdkImage **) val
 imgMask:(GdkBitmap **) mask
{
  gtk_image_get(gtkimage, val, mask);
  return self;
}
@end
