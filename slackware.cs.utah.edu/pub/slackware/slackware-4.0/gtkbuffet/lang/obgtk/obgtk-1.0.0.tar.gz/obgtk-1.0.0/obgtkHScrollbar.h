#ifndef OBGTK_HSCROLLBAR_H
#define OBGTK_HSCROLLBAR_H 1

#include <obgtk/obgtkScrollbar.h>
#include <obgtk/obgtkAdjustment.h>
#include <gtk/gtkhscrollbar.h>

@interface Gtk_HScrollbar : Gtk_Scrollbar
- initWithGtkAdjustment:(id) gtk_adjustment;
@end

#endif /* OBGTK_HSCROLLBAR_H */
