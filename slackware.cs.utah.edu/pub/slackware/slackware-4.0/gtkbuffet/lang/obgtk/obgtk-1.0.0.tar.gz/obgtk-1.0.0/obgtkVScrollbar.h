#ifndef OBGTK_VSCROLLBAR_H
#define OBGTK_VSCROLLBAR_H 1

#include <obgtk/obgtkScrollbar.h>
#include <obgtk/obgtkAdjustment.h>
#include <gtk/gtkvscrollbar.h>

@interface Gtk_VScrollbar : Gtk_Scrollbar
- initWithGtkAdjustment:(id) adjustment;
@end

#endif /* OBGTK_VSCROLLBAR_H */
