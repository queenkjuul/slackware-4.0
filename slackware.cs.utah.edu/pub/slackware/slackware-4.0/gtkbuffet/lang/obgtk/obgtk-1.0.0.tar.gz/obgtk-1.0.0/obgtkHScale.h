#ifndef OBGTK_HSCALE_H
#define OBGTK_HSCALE_Hx 1

#include <obgtk/obgtkScale.h>
#include <gtk/gtkhscale.h>

@interface Gtk_HScale : Gtk_Scale
- initWithGtkAdjustment:(id) gtk_adjustment;
@end

#endif /* OBGTK_HSCALE_H */
