#ifndef OBGTK_VSEPARATOR_H
#define OBGTK_VSEPARATOR_H 1

#include <obgtk/obgtkSeparator.h>
#include <gtk/gtkvseparator.h>

@interface Gtk_VSeparator : Gtk_Separator
@end

#endif /* OBGTK_VSEPARATOR_H */
