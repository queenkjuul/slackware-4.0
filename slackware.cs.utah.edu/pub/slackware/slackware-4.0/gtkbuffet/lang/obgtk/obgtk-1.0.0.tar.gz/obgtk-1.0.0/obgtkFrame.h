#ifndef OBGTK_FRAME_H
#define OBGTK_FRAME_H 1

#include <obgtk/obgtkBin.h>
#include <gtk/gtkframe.h>

@interface Gtk_Frame : Gtk_Bin
{
@public
  GtkFrame *gtkframe;
}
- initWithLabel:(gchar *) str;
- castGtkFrame:(GtkFrame *)castitem;
- set_label:(gchar *) label;
- set_label_align:(gfloat) xalign
	   alignY:(gfloat) yalign;
- set_shadow_type:(GtkShadowType) type;
@end

#endif /* OBGTK_FRAME_H */
