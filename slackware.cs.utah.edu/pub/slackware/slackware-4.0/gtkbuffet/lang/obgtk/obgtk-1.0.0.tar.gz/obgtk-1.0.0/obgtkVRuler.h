#ifndef OBGTK_VRULER_H
#define OBGTK_VRULER_H 1

#include <obgtk/obgtkRuler.h>
#include <gtk/gtkvruler.h>

@interface Gtk_VRuler : Gtk_Ruler
@end

#endif /* OBGTK_VRULER_H */
