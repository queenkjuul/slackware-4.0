#ifndef OBGTK_VBUTTON_BOX_H
#define OBGTK_VBUTTON_BOX_H 1

#include <obgtk/obgtkButtonBox.h>
#include <gtk/gtkvbbox.h>

@interface Gtk_VButtonBox : Gtk_ButtonBox
{
@public
  GtkVButtonBox *gtkvbuttonbox;
}
- castGtkVButtonBox:(GtkVButtonBox *) castitem;
- (gint) get_spacing_default;
- (GtkButtonBoxStyle) get_layout_default;
- set_spacing_default:(gint) spacing;
- set_layout_default:(GtkButtonBoxStyle) layout;
@end

#endif /* OBGTK_VBUTTON_BOX_H */
