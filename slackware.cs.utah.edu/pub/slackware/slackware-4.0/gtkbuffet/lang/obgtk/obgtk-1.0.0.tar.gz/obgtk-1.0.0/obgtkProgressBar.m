#include "obgtkProgressBar.h"

@implementation Gtk_ProgressBar
- init
{
  gtkprogressbar = GTK_PROGRESS_BAR(gtk_progress_bar_new());
  return [super castGtkWidget:GTK_WIDGET(gtkprogressbar)];
}

- update:(gfloat) percentage
{
  gtk_progress_bar_update(gtkprogressbar, percentage);
  return self;
}
@end
