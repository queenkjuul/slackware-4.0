#ifndef OBGTK_FIXED_H
#define OBGTK_FIXED_H 1

#include <obgtk/obgtkContainer.h>
#include <gtk/gtkfixed.h>

@interface Gtk_Fixed : Gtk_Container
{
@public
  GtkFixed *gtkfixed;
}

- castGtkFixed:(GtkFixed *) castitem;
- put:(Gtk_Widget *) widget
     :(gint16) x
     :(gint16) y;
- move:(Gtk_Widget *) widget
      :(gint16) x
      :(gint16) y;
@end

#endif /* OBGTK_CONTAINER_H */
