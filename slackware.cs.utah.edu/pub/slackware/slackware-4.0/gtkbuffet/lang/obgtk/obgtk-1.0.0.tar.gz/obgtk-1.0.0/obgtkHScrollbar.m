#include "obgtkHScrollbar.h"

@implementation Gtk_HScrollbar
- init
{
  id t = [Gtk_Adjustment new], retval;
  retval = [self initWithGtkAdjustment:t];
  [t free];
  return retval;
}

- initWithGtkAdjustment:(Gtk_Adjustment *) adjustment
{
  return [super castGtkScrollbar:GTK_SCROLLBAR(gtk_hscrollbar_new(adjustment->gtkadjustment))];
}
@end
