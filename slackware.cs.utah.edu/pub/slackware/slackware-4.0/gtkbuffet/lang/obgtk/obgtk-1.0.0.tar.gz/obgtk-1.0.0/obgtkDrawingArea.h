#ifndef OBGTK_DRAWING_AREA_H
#define OBGTK_DRAWING_AREA_H 1

#include <obgtk/obgtkWidget.h>
#include <gtk/gtkdrawingarea.h>

@interface Gtk_DrawingArea : Gtk_Widget
{
@public
  GtkDrawingArea *gtkdrawingarea;
}
- init;
- castGtkDrawingArea:(GtkDrawingArea *) castitem;
- size    :(gint) width
 setHeight:(gint) height;
@end

#endif /* OBGTK_DRAWING_AREA_H */
