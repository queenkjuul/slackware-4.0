#ifndef OBGTK_OPTION_MENU_H
#define OBGTK_OPTION_MENU_H 1

#include <obgtk/obgtkButton.h>
#include <obgtk/obgtkMenu.h>
#include <gtk/gtkoptionmenu.h>

@interface Gtk_OptionMenu : Gtk_Button
{
@public
  GtkOptionMenu *gtkoptionmenu;
}
- castGtkOptionMenu:(GtkOptionMenu *) castitem;
- (id) get_menu;
- set_menu:(id) gtk_menu;
- remove_menu;
- set_history:(gint) index;
@end

#endif /* OBGTK_OPTION_MENU_H */
