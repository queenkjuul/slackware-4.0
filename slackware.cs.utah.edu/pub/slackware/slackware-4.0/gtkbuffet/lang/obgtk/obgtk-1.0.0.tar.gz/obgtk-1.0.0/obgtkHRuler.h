#ifndef OBGTK_HRULER_H
#define OBGTK_HRULER_H 1

#include <obgtk/obgtkRuler.h>
#include <gtk/gtkhruler.h>

@interface Gtk_HRuler : Gtk_Ruler
@end

#endif /* OBGTK_HRULER_H */
