#ifndef OBGTK_EDITABLE_H
#define OBGTK_EDITABLE_H 1

#include <obgtk/obgtkWidget.h>
#include <gtk/gtkeditable.h>

@interface Gtk_Editable : Gtk_Widget
{
@public
   GtkEditable *gtkeditable;
}
- castGtkEditable:(GtkEditable *) castitem;
- select_region:(gint) start :(gint) end;
- insert_text:(const gchar *) new_text
      textLen:(gint) new_text_length
 textPosition:(gint *) position;
- delete_text:(gint) start_pos
	     :(gint) end_pos;
- (gchar *) get_chars:(gint) start_pos
		     :(gint) end_pos;
- cut_clipboard:(guint32) time;
- copy_clipboard:(guint32) time;
- paste_clipboard:(guint32) time;
- claim_selection:(gboolean) claim :(guint32) time;
- delete_selection;
- changed;
@end

#endif
