#ifndef OBGTK_HANDLE_BOX_H
#define OBGTK_HANDLE_BOX_H 1
#include <obgtk/obgtkBin.h>
#include <gtk/gtkhandlebox.h>

@interface Gtk_HandleBox : Gtk_Bin
{
@public
  GtkHandleBox *gtkhandlebox;
}
- castGtkHandleBox:(GtkHandleBox *) castitem;
@end

#endif /* OBGTK_HANDLE_BOX_H */
