#ifndef OBGTK_VIEWPORT_H
#define OBGTK_VIEWPORT_H 1

#include <obgtk/obgtkBin.h>
#include <obgtk/obgtkAdjustment.h>
#include <gtk/gtkviewport.h>

@interface Gtk_Viewport : Gtk_Bin
{
@public
  GtkViewport *gtkviewport;
}
- init;
- initWithAdjustments:(Gtk_Adjustment *) hadjustment
  adjV:(Gtk_Adjustment *) vadjustment;
- (Gtk_Adjustment *)get_hadjustment;
- (Gtk_Adjustment *)get_vadjustment;
- set_hadjustment:(Gtk_Adjustment *) adjustment;
- set_vadjustment:(Gtk_Adjustment *) adjustment;
- set_shadow_type:(GtkShadowType) type;
@end

#endif /* OBGTK_VIEWPORT_H */
