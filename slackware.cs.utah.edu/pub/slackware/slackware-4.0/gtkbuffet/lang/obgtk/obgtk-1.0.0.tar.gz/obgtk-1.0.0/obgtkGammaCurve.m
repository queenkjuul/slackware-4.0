#include "obgtkGammaCurve.h"

@implementation Gtk_GammaCurve
- init
{
  return [self castGtkGammaCurve:GTK_GAMMA_CURVE(gtk_gamma_curve_new())];
}

- castGtkGammaCurve:(GtkGammaCurve *)castitem
{
  int i;
  GtkGammaCurve *g = gtkgammacurve = castitem;

  table = [[Gtk_Table alloc] castGtkTable:GTK_TABLE(g->table)];
  curve = [[Gtk_Curve alloc] castGtkCurve:GTK_CURVE(g->curve)];

  for(i = 0; i < 5; i++) {
    button[i] = [[Gtk_Button alloc] castGtkButton:GTK_BUTTON(g->button[i])];
  }

  gamma_dialog = [[Gtk_Dialog alloc] castGtkDialog:GTK_DIALOG(g->gamma_dialog)];
  gamma_text = [[Gtk_Label alloc] castGtkLabel:GTK_LABEL(g->gamma_text)];

  return [super castGtkVBox:GTK_VBOX(gtkgammacurve)];
}
@end
