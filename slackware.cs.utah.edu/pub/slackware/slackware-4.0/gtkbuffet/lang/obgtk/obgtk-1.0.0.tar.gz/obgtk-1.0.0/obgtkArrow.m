#include "obgtkArrow.h"

@implementation Gtk_Arrow
- init
{
  return [self initWithArrowInfo:GTK_ARROW_RIGHT
	       typeShadow:GTK_SHADOW_OUT];
}

- initWithArrowInfo:(GtkArrowType) arrow_type
	 typeShadow:(GtkShadowType) shadow_type
{
  gtkarrow = GTK_ARROW(gtk_arrow_new(arrow_type, shadow_type));
  [super castGtkMisc:GTK_MISC(gtkarrow)];
  return self;
}

- set      :(GtkArrowType) arrow_type
 typeShadow:(GtkShadowType) shadow_type
{
  gtk_arrow_set(gtkarrow, arrow_type, shadow_type);
  return self;
}

@end
