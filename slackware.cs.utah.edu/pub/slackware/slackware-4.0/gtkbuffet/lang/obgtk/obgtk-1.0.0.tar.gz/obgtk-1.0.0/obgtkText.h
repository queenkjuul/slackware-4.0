#ifndef OBGTK_TEXT_H
#define OBGTK_TEXT_H 1

#include <obgtk/obgtkEditable.h>
#include <obgtk/obgtkAdjustment.h>
#include <gtk/gtktext.h>

@interface Gtk_Text : Gtk_Editable
{
@public
  GtkText *gtktext;
}
- castGtkText:(GtkText *) castitem;
- initWithAdjustments:(id) hadjustment
		 adjV:(id) vadjustment;
- set_editable:(gint) editable;
- set_adjustments:(id) hadjustment
	     adjV:(id) vadjustment;
- set_point:(gint) index;
- (guint) get_point;
- (guint) get_length;
- freeze;
- thaw;
- insert :(GdkFont *) font
    colFg:(GdkColor *) fore
    colBg:(GdkColor *) back
 insChars:(const char *) chars
   insLen:(gint) length;
- (gint) backward_delete:(guint) nchars;
- (gint) forward_delete:(guint) nchars;

- set_word_wrap:(gint) word_wrap;
@end

#endif /* OBGTK_TEXT_H */
