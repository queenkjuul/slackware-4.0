#ifndef OBGTK_BUTTON_BOX_H
#define OBGTK_BUTTON_BOX_H 1

#include <obgtk/obgtkBox.h>
#include <gtk/gtkbbox.h>

@interface Gtk_ButtonBox : Gtk_Box
{
@public
  GtkButtonBox *gtkbuttonbox;
}
- castGtkButtonBox:(GtkButtonBox *) castitem;
- get_child_size_default:(gint *) min_width
			:(gint *) min_height;
- get_child_ipadding_default:(gint *) ipad_x
			    :(gint *) ipad_y;
- set_child_size_default:(gint) min_width
			:(gint) min_height;
- set_child_ipadding_default:(gint) ipad_x
			    :(gint) ipad_y;
- (gint) get_spacing;
- (gint) get_layout;
- get_child_size:(gint *) min_width
	        :(gint *) min_height;
- get_child_ipadding:(gint *) ipad_x
		    :(gint *) ipad_y;
- set_spacing:(gint) spacing;
- set_layout:(gint) layout_style;
- set_child_size:(gint) min_width
		:(gint) min_height;
- set_child_ipadding:(gint) ipad_x
		    :(gint) ipad_y;
@end

#endif /* OBGTK_BOX_H */
