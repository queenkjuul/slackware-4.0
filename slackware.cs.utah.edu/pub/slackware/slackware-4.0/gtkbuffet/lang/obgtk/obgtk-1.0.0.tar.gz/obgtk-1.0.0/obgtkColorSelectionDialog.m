#include "obgtkColorSelectionDialog.h"

@implementation Gtk_ColorSelectionDialog
- init
{
  return [self initWithLabel:"Untitled"];
}

- initWithLabel:(gchar *) title
{
  gtkcolorselectiondialog = GTK_COLOR_SELECTION_DIALOG(gtk_color_selection_dialog_new(title));
  return [super castGtkWindow:GTK_WINDOW(gtkcolorselectiondialog)];
}
@end
