#ifndef OBGTK_HBUTTON_BOX_H
#define OBGTK_HBUTTON_BOX_H 1

#include <obgtk/obgtkButtonBox.h>
#include <gtk/gtkhbbox.h>

@interface Gtk_HButtonBox : Gtk_ButtonBox
{
@public
  GtkHButtonBox *gtkhbuttonbox;
}
- castGtkHButtonBox:(GtkHButtonBox *) castitem;
- (gint) get_spacing_default;
- (GtkButtonBoxStyle) get_layout_default;
- set_spacing_default:(gint) spacing;
- set_layout_default:(GtkButtonBoxStyle) layout;
@end

#endif /* OBGTK_HBUTTON_BOX_H */
