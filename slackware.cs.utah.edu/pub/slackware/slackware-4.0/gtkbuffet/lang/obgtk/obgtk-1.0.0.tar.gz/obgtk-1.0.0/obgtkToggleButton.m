#include "obgtkToggleButton.h"

@implementation Gtk_ToggleButton
- castGtkToggleButton:(GtkToggleButton *)castitem
{
  gtktogglebutton = castitem;
  return [super castGtkButton:GTK_BUTTON(castitem)];
}

- init
{
  gtktogglebutton = GTK_TOGGLE_BUTTON(gtk_toggle_button_new());
  return [super castGtkButton:GTK_BUTTON(gtktogglebutton)];
}

- initWithLabel:(gchar *) label
{
  gtktogglebutton = GTK_TOGGLE_BUTTON(gtk_toggle_button_new_with_label(label));
  return [super castGtkButton:GTK_BUTTON(gtktogglebutton)];
}

- set_mode:(gint) draw_indicator
{
  gtk_toggle_button_set_mode(gtktogglebutton, draw_indicator);
  return self;
}

- set_state:(gint) state
{
  gtk_toggle_button_set_state(gtktogglebutton, state);
  return self;
}

- toggled
{
  gtk_toggle_button_toggled(gtktogglebutton);
  return self;
}
@end
