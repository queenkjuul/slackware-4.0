#ifndef OBGTK_WIDGET_H
#define OBGTK_WIDGET_H 1

#include <obgtk/obgtkObject.h>
#include <gtk/gtkwidget.h>

@class Gtk_AcceleratorTable;

@interface Gtk_Widget : Gtk_Object
{
@public
  GtkWidget *gtkwidget;
}

- castGtkWidget:(GtkWidget *)castitem;
- (Gtk_Widget *)get_parent;
- unparent;
- show;
- hide;
- map;
- unmap;
- realize;
- unrealize;
- draw:(GdkRectangle *) area;
- draw_focus;
- draw_default;
- draw_children;
- size_request:(GtkRequisition *) requisition;
- size_allocate:(GtkAllocation *) allocation;
- install_accelerator:(Gtk_AcceleratorTable *) table
	   signalName:(gchar *)asignal
	       keySym:(gchar)akey
	  modifierSet:(guint8)modifiers;
- (gint)event:(GdkEvent *)event;
- activate;
- reparent:(Gtk_Widget *) new_parent;
- popup: locX:(gint)x
   locY:(gint)y;
- (gint) intersect: area:(GdkRectangle *)anArea
      intersection:(GdkRectangle *)aRectangle;
- (gint) basic;
- grab_focus;
- grab_default;
- set_name:(gchar *)name;
- set_state:(GtkStateType) state;
- set_sensitive:(gint)sensitive;
- set_parent:(Gtk_Widget *) parent;
- set_style:(GtkStyle *) style;
- set_uposition: locX:(gint)x
	   locY:(gint)y;
- set_usize:(gint) awidth
     height:(gint) aheight;
- set_events:(gint) events;
- (Gtk_Widget *) get_toplevel;
- (Gtk_Widget *) get_ancestor:(gint) type;

@end

#endif /* OBGTK_WIDGET_H */
