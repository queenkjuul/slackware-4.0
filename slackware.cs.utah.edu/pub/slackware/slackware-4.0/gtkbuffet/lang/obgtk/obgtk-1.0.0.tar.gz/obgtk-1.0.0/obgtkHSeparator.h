#ifndef OBGTK_HSEPARATOR_H
#define OBGTK_HSEPARATOR_H 1

#include <obgtk/obgtkSeparator.h>
#include <gtk/gtkhseparator.h>

@interface Gtk_HSeparator : Gtk_Separator
@end

#endif /* OBGTK_HSEPARATOR_H */
