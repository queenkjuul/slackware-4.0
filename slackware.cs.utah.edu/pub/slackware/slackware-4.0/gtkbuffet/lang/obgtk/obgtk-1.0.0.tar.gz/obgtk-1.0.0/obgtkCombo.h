#ifndef OBGTK_COMBO_H
#define OBGTK_COMBO_H

#include <obgtk/obgtkHBox.h>
#include <gtk/gtk.h>

@class Gtk_Item;

@interface Gtk_Combo : Gtk_HBox
{
@public
   GtkCombo *gtkcombo;
}
- castGtkCombo:(GtkCombo *) castitem;
- set_value_in_list:(gint) val
	  okIfEmpty:(gint) ok_if_empty;
- set_use_arrows:(gint) val;
- set_use_arrows_always:(gint) val;
- set_case_sensitive:(gint) val;
- set_item_string:(id) item
	itemValue:(const gchar *) item_value;
- set_popdown_strings:(GList *) strings;
@end

#endif /* OBGTK_COMBO_H */

