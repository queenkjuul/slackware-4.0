#undef HAVE_LIBSM
#undef PACKAGE
#undef VERSION
