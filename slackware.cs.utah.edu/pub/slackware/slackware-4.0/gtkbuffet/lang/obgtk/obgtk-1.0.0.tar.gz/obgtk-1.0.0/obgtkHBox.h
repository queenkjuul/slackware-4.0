#ifndef OBGTK_HBOX_H
#define OBGTK_HBOX_H 1

#include <obgtk/obgtkBox.h>
#include <gtk/gtkhbox.h>

@interface Gtk_HBox : Gtk_Box
- castGtkHBox:(GtkHBox *)castitem;
- initWithBoxInfo:(gint) homogeneous
       setSpacing:(gint) spacing;
@end

#endif /* OBGTK_HBOX_H */
