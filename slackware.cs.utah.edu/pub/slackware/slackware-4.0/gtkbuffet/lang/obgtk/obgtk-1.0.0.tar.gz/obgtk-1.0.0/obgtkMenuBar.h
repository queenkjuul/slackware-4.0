#ifndef OBGTK_MENU_BAR_H
#define OBGTK_MENU_BAR_H 1

#include <obgtk/obgtkMenuShell.h>
#include <obgtk/obgtkWidget.h>
#include <gtk/gtkmenubar.h>

@interface Gtk_MenuBar: Gtk_MenuShell
{
@public
  GtkMenuBar *gtkmenubar;
}
- castGtkMenuBar:(GtkMenuBar *) castitem;
@end

#endif /* OBGTK_MENU_BAR_H */
