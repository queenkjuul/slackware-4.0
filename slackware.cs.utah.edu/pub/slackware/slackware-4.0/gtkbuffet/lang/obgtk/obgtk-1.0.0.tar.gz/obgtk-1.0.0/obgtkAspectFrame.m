#include "obgtkAspectFrame.h"

@implementation Gtk_AspectFrame
- init
{
  return [self initWithAspectFrameInfo:"Untitled"
	       alignX:0
	       alignY:0
	       aRatio:1
	       doObey:1];
}

- initWithAspectFrameInfo:(gchar *) label
		   alignX:(gfloat) xalign
		   alignY:(gfloat) yalign
		   aRatio:(gfloat) ratio
		   doObey:(gint) obey_child
{
  gtkaspectframe = GTK_ASPECT_FRAME(gtk_aspect_frame_new(label, xalign,
							 yalign, ratio,
							 obey_child));
  [super castGtkFrame:GTK_FRAME(gtkaspectframe)];
  return self;
}

- set  :(gfloat) xalign
 alignY:(gfloat) yalign
 aRatio:(gfloat) ratio
 doObey:(gint) obey_child
{
  gtk_aspect_frame_set(gtkaspectframe, xalign, yalign, ratio, obey_child);
  return self;
}
@end
