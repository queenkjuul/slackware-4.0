#ifndef OBGTK_COLOR_SELECTION_DIALOG_H
#define OBGTK_COLOR_SELECTION_DIALOG_H 1

#include <obgtk/obgtkWindow.h> 
#include <gtk/gtkcolorsel.h>

@interface Gtk_ColorSelectionDialog : Gtk_Window
{
@public
  GtkColorSelectionDialog *gtkcolorselectiondialog;
}
- initWithLabel:(gchar *) label;
@end

#endif /* OBGTK_COLOR_SELECTION_DIALOG_H */
