#include "obgtkSeparator.h"

@implementation Gtk_Separator
- castGtkSeparator:(GtkSeparator *)castitem
{
  gtkseparator = castitem;
  return [super castGtkWidget:GTK_WIDGET(castitem)];
}
@end
