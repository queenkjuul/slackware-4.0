#ifndef OBGTK_CONTAINER_H
#define OBGTK_CONTAINER_H 1

#include <obgtk/obgtkWidget.h>
#include <gtk/gtkcontainer.h>

@interface Gtk_Container : Gtk_Widget
{
@public
  GtkContainer *gtkcontainer;
}

- castGtkContainer:(GtkContainer *) castitem;
- border_width:(gint) width;
- add:(id) widget;
- remove:(id) widget;
- disable_resize;
- enable_resize;
- block_resize;
- unblock_resize;
- (gint)need_resize;
- foreach    : callbackFunction:(GtkCallback) acallback
callbackData:(gpointer) callback_data;
- foreach_method:(SEL) method; /* this method should take no explicit arguments */
- focus:(GtkDirectionType) direction;
- (GList *) children; /* a GList of GtkWidget *'s, NOT object id's */
- register_toplevel;
- unregister_toplevel;
@end

#endif /* OBGTK_CONTAINER_H */
