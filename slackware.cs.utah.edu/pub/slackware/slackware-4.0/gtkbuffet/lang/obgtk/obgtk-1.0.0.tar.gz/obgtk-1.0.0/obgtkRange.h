#ifndef OBGTK_RANGE_H
#define OBGTK_RANGE_H 1

#include <obgtk/obgtkWidget.h>
#include <obgtk/obgtkAdjustment.h>
#include <gtk/gtkrange.h>

@interface Gtk_Range : Gtk_Widget
{
@public
  GtkRange *gtkrange;
}
- castGtkRange:(GtkRange *) castitem;
- (id)get_adjustment;
- set_update_policy:(GtkUpdateType) policy;
- set_adjustment:(Gtk_Adjustment *) adjustment;
- draw_background;
- draw_trough;
- draw_slider;
- draw_step_forward;
- draw_step_backward;
- slider_update;
- trough_click:(gint) x
	      :(gint) y
	      :(gfloat *) jump_perc;
- default_hslider_update;
- default_vslider_update;
- default_htrough_click:(gint) x
		       :(gint) y
		       :(gfloat *) jump_perc;
- default_vtrough_click:(gint) x
		       :(gint) y
		       :(gfloat *) jump_perc;
- default_hmotion:(gint) xdelta
		 :(gint) ydelta;
- default_vmotion:(gint) xdelta
		 :(gint) ydelta;
@end

#endif /* OBGTK_RANGE_H */
