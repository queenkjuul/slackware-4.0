#include "obgtkHPaned.h"

@implementation Gtk_HPaned
- init
{
  return [self castGtkHPaned:GTK_HPANED(gtk_hpaned_new())];
}

- castGtkHPaned:(GtkHPaned *)castitem
{
  return [super castGtkPaned:GTK_PANED(castitem)];
}
@end
