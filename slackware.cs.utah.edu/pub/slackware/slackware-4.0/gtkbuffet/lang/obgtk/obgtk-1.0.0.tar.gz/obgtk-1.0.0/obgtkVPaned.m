#include "obgtkVPaned.h"

@implementation Gtk_VPaned
- init
{
  return [self castGtkVPaned:GTK_VPANED(gtk_vpaned_new())];
}

- castGtkVPaned:(GtkVPaned *)castitem
{
  return [super castGtkPaned:GTK_PANED(castitem)];
}
@end
