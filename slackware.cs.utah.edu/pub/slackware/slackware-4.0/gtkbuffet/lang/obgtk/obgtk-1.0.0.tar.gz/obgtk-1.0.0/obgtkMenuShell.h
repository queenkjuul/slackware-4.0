#ifndef OBGTK_MENU_SHELL_H
#define OBGTK_MENU_SHELL_H 1

#include <obgtk/obgtkContainer.h>
#include <obgtk/obgtkWidget.h>
#include <obgtk/obgtkMenuItem.h>
#include <gtk/gtkmenushell.h>

@class Gtk_MenuItem;

@interface Gtk_MenuShell : Gtk_Container
{
@public
  GtkMenuShell *gtkmenushell;
}
- castGtkMenuShell:(GtkMenuShell *) castitem;
- appendMenuItem:(id) child;
- prependMenuItem:(id) child;
- insertMenuItem:(id) child
	    aPos:(gint) position;
- deactivate;
@end

#endif /* OBGTK_MENU_SHELL_H */
