#include "obgtkHScale.h"

@implementation Gtk_HScale
- init
{
  id t = [Gtk_Adjustment new], retval;
  retval = [self initWithGtkAdjustment:t];
  [t free];
  return retval;
}

- initWithGtkAdjustment:(Gtk_Adjustment *) adjustment
{
  return [super castGtkScale:GTK_SCALE(gtk_hscale_new(adjustment->gtkadjustment))];
}
@end
