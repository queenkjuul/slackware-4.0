#ifndef OBGTK_VSCALE_H
#define OBGTK_VSCALE_H 1

#include <obgtk/obgtkScale.h>
#include <obgtk/obgtkAdjustment.h>
#include <gtk/gtkvscale.h>

@interface Gtk_VScale : Gtk_Scale
- initWithGtkAdjustment:(id) adjustment;
@end

#endif /* OBGTK_VSCALE_H */
