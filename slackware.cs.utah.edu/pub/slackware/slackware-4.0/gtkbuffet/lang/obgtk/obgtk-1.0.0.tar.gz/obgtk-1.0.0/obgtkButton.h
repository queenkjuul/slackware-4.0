#ifndef OBGTK_BUTTON_H
#define OBGTK_BUTTON_H 1
#include <obgtk/obgtkContainer.h>
#include <gtk/gtkbutton.h>

@interface Gtk_Button : Gtk_Container
{
@public
  GtkButton *gtkbutton;
}
- init;
- castGtkButton:(GtkButton *) castitem;
- initWithLabel:(gchar *) label;
- pressed;
- released;
- clicked;
- enter;
- leave;
@end

#endif /* OBGTK_BUTTON_H */
