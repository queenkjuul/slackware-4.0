#ifndef OBGTK_SCALE_H
#define OBGTK_SCALE_H 1

#include <obgtk/obgtkRange.h>
#include <gtk/gtkscale.h>

@interface Gtk_Scale : Gtk_Range
{
@public
  GtkScale *gtkscale;
}
- castGtkScale:(GtkScale *) castitem;
- set_digits:(gint) digits;
- set_draw_value:(gint) draw_value;
- set_value_pos:(GtkPositionType) pos;
- (gint) value_width;
- draw_value;
@end

#endif /* OBGTK_SCALE_H */
