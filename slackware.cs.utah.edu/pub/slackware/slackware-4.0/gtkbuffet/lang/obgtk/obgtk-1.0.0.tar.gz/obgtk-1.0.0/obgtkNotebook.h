#ifndef OBGTK_NOTEBOOK_H
#define OBGTK_NOTEBOOK_H 1

#include <obgtk/obgtkContainer.h>
#include <obgtk/obgtkWidget.h>
#include <gtk/gtknotebook.h>

@interface Gtk_Notebook : Gtk_Container
{
@public
  GtkNotebook *gtknotebook;
}
- castGtkNotebook:(GtkNotebook *) castitem;
- append_page:(id) child
       tabLabel:(id) tab_label;
- prepend_page:(id) child
	tabLabel:(id) tab_label;
- insert_page:(id) child
       tabLabel:(id) tab_label
      pagePos:(gint) position;
- append_page_menu:(id) child
	  tabLabel:(id) tab_label
	 menuLabel:(id) menu_label;
- prepend_page_menu:(id) child
	   tabLabel:(id) tab_label
	  menuLabel:(id) menu_label;
- insert_page_menu:(id) child
	  tabLabel:(id) tab_label
	 menuLabel:(id) menu_label
	   pagePos:(gint) position;
- remove_page:(gint) page_num;
- (gint) current_page;
- set_page:(gint) page_num;
- next_page;
- prev_page;
- set_tab_pos:(GtkPositionType) pos;
- set_show_tabs:(gint) show_tabs;
- set_show_border:(gint) show_border;
- set_tab_border:(gint) border_width;
- set_scrollable:(gint) scrollable;
- popup_enable;
- popup_disable;
@end

#endif /* OBGTK_NOTEBOOK_H */
