#include "obgtkBin.h"

@implementation Gtk_Bin
- castGtkBin:(GtkBin *) castitem
{
  gtkbin = castitem;
  return [super castGtkContainer:(GtkContainer *) castitem];
}

@end
