#ifndef OBGTK_ENTRY_H
#define OBGTK_ENTRY_H 1

#include <obgtk/obgtkEditable.h>
#include <gtk/gtkentry.h>

@interface Gtk_Entry : Gtk_Editable
{
@public
  GtkEntry *gtkentry;
}
- castGtkEntry:(GtkEntry *) castitem;
- initWithMaxLength:(guint16) max_length;
- set_text:(const gchar *) text;
- append_text:(const gchar *) text;
- prepend_text:(const gchar *) text;
- set_position:(gint) position;
- (gchar *) get_text;
- set_visibility:(BOOL) visible;
- set_editable:(BOOL) editable;
- select_region:(gint) start :(gint) end;
- set_max_length:(guint16) max;
@end

#endif /* OBGTK_ENTRY_H */
