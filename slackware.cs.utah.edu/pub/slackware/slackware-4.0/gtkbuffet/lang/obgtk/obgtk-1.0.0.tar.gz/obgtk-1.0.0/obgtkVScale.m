#include "obgtkVScale.h"

@implementation Gtk_VScale
- init
{
  [self error:"Gtk_VScale: call of \"init\" method in class requiring initialization parameters. Use \"initWithGtkAdjustment\" instead."];
  return self;
}

- initWithGtkAdjustment:(id) adjustment
{
  return [super castGtkScale:GTK_SCALE(gtk_vscale_new(GTK_ADJUSTMENT([adjustment getGtkObject])))];
}
@end
