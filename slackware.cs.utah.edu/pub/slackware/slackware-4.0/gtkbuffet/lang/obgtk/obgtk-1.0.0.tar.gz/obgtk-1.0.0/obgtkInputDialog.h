#ifndef OBGTK_INPUT_DIALOG_H
#define OBGTK_INPUT_DIALOG_H 1
#include <obgtk/obgtkWindow.h>
#include <gtk/gtkwindow.h>
#include <gtk/gtkinputdialog.h>

@interface Gtk_InputDialog : Gtk_Window
{
@public
  GtkInputDialog *gtkinputdialog;
}
- castGtkInputDialog:(GtkInputDialog *) castitem;
@end

#endif /* OBGTK_INPUT_DIALOG_H */
