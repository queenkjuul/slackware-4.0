#include "obgtkCheckButton.h"

@implementation Gtk_CheckButton
- castGtkCheckButton:(GtkCheckButton *)castitem
{
  gtkcheckbutton = castitem;
  return [super castGtkToggleButton:GTK_TOGGLE_BUTTON(gtkcheckbutton)];
}

- init
{
  gtkcheckbutton = GTK_CHECK_BUTTON(gtk_check_button_new());
  return [super castGtkToggleButton:GTK_TOGGLE_BUTTON(gtkcheckbutton)];
}

- initWithLabel:(gchar *) label
{
  gtkcheckbutton = GTK_CHECK_BUTTON(gtk_check_button_new_with_label(label));
  return [super castGtkToggleButton:GTK_TOGGLE_BUTTON(gtkcheckbutton)];
}
@end
