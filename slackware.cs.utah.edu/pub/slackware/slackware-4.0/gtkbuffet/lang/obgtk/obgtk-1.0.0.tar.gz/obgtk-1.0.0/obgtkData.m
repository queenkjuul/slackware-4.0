#include "obgtkData.h"

@implementation Gtk_Data
- castGtkData:(GtkData *)castitem
{
  [super castGtkObject:GTK_OBJECT(castitem)];
  return self;
}
@end
