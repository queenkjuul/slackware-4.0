#include "obgtkVButtonBox.h"

@implementation Gtk_VButtonBox
- init
{
  return [self castGtkVButtonBox:GTK_VBUTTON_BOX(gtk_vbutton_box_new())];
}

- castGtkVButtonBox:(GtkVButtonBox *) castitem
{
  gtkvbuttonbox = castitem;
  return [super castGtkButtonBox:GTK_BUTTON_BOX(castitem)];
}

- (gint) get_spacing_default
{
  return gtk_vbutton_box_get_spacing_default();
}

- (GtkButtonBoxStyle) get_layout_default
{
  return gtk_vbutton_box_get_layout_default();
}

- set_spacing_default:(gint) spacing
{
  gtk_vbutton_box_set_spacing_default(spacing);
  return self;
}

- set_layout_default:(GtkButtonBoxStyle) layout
{
  gtk_vbutton_box_set_layout_default(layout);
  return self;
}
@end
