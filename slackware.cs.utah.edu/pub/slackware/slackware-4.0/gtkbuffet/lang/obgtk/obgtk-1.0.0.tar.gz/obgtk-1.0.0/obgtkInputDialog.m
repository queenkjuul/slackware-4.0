#include "obgtkInputDialog.h"

@implementation Gtk_InputDialog
- init
{
  return [self castGtkInputDialog:GTK_INPUT_DIALOG(gtk_input_dialog_new())];
}

- castGtkInputDialog:(GtkInputDialog *) castitem;
{
  gtkinputdialog = castitem;
  return [super castGtkWindow:GTK_WINDOW(castitem)];
}
@end
