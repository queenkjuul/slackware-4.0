#include "obgtkFrame.h"

@implementation Gtk_Frame
- castGtkFrame:(GtkFrame *)castitem
{
  gtkframe = castitem;
  [super castGtkBin:GTK_BIN(gtkframe)];
  return self;
}

- init
{
  return [self initWithLabel:""];
}

- initWithLabel:(gchar *) str
{
  return [self castGtkFrame:GTK_FRAME(gtk_frame_new(str))];
}

- set_label:(gchar *) label
{
  gtk_frame_set_label(gtkframe, label);
  return self;
}

- set_label_align:(gfloat) xalign
	   alignY:(gfloat) yalign
{
  gtk_frame_set_label_align(gtkframe, xalign, yalign);
  return self;
}

- set_shadow_type:(GtkShadowType) type
{
  gtk_frame_set_shadow_type(gtkframe, type);
  return self;
}
@end
