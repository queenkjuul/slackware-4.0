#ifndef OBGTK_ADJUSTMENT_H
#define OBGTK_ADJUSTMENT_H 1

#include <obgtk/obgtkData.h>
#include <gtk/gtkadjustment.h> 

@interface Gtk_Adjustment : Gtk_Data
{
@public
  GtkAdjustment *gtkadjustment;
}
- castGtkAdjustment:(GtkAdjustment *)castitem;
- initWithAdjustmentInfo:(gfloat) value
	      limitLower:(gfloat) lower
	      limitUpper:(gfloat) upper
	   incrementStep:(gfloat) step_increment
	   incrementPage:(gfloat) page_increment
		sizePage:(gfloat) page_size;
- set_value:(gfloat) value;
@end

#endif /* OBGTK_ADJUSTMENT_H */
