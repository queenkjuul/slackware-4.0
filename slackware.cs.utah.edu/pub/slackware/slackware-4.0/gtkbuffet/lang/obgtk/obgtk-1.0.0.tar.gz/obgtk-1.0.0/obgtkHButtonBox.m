#include "obgtkHButtonBox.h"

@implementation Gtk_HButtonBox
- init
{
  return [self castGtkHButtonBox:GTK_HBUTTON_BOX(gtk_hbutton_box_new())];
}

- castGtkHButtonBox:(GtkHButtonBox *) castitem
{
  gtkhbuttonbox = castitem;
  return [super castGtkButtonBox:GTK_BUTTON_BOX(castitem)];
}

- (gint) get_spacing_default
{
  return gtk_hbutton_box_get_spacing_default();
}

- (GtkButtonBoxStyle) get_layout_default
{
  return gtk_hbutton_box_get_layout_default();
}

- set_spacing_default:(gint) spacing
{
  gtk_hbutton_box_set_spacing_default(spacing);
  return self;
}

- set_layout_default:(GtkButtonBoxStyle) layout
{
  gtk_hbutton_box_set_layout_default(layout);
  return self;
}
@end
