#include "obgtkScrollbar.h"

@implementation Gtk_Scrollbar
- castGtkScrollbar:(GtkScrollbar *) castitem
{
  gtkscrollbar = castitem;
  return [super castGtkRange:GTK_RANGE(castitem)];
}
@end
