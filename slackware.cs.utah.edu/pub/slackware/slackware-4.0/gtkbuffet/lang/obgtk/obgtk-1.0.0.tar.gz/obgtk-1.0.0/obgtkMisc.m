#include "obgtkMisc.h"

@implementation Gtk_Misc
- castGtkMisc:(GtkMisc *) castitem
{
  gtkmisc = castitem;
  [super castGtkWidget:GTK_WIDGET(castitem)];
  return self;
}
- set_alignment:(gfloat) xalign
	 alignY:(gfloat) yalign
{
  gtk_misc_set_alignment(gtkmisc, xalign, yalign);
  return self;
}

- set_padding:(gint) xpad
	 padY:(gint) ypad
{
  gtk_misc_set_padding(gtkmisc, xpad, ypad);
  return self;
}
@end
