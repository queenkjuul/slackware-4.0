#ifndef OBGTK_TREE_ITEM_H
#define OBGTK_TREE_ITEM_H 1

#include <obgtk/obgtkItem.h>
#include <obgtk/obgtkTree.h>
#include <gtk/gtktreeitem.h>

@class Gtk_Tree;
@interface Gtk_TreeItem : Gtk_Item
{
@public
  GtkTreeItem *gtktreeitem;
}
- initWithLabel:(gchar *) label;
- set_subtree:(id) subtree;
- select;
- deselect;
- expand;
- collapse;

- castGtkTreeItem:(GtkTreeItem *) castitem;
- remove_subtree;
@end

#endif /* OBGTK_TREE_ITEM_H */
