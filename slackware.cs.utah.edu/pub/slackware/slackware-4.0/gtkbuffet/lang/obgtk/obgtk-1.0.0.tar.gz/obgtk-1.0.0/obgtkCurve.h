#ifndef OBGTK_CURVE_H
#define OBGTK_CURVE_H 1

#include <obgtk/obgtkDrawingArea.h> 
#include <gtk/gtkcurve.h>

@interface Gtk_Curve : Gtk_DrawingArea
{
@public
  GtkCurve *gtkcurve;
}
- castGtkCurve:(GtkCurve *)castitem;
- reset;
- set_gamma:(gfloat) gamma;
- set_range:(gfloat) min_x
       maxX:(gfloat) max_x
       minY:(gfloat) min_y
       maxY:(gfloat) max_y;
- get_vector:(int) veclen
   getVector:(gfloat *)vector;
- set_vector:(int) veclen
   getVector:(gfloat *)vector;
- set_curve_type:(GtkCurveType)type;
@end

#endif /* OBGTK_CURVE_H */
