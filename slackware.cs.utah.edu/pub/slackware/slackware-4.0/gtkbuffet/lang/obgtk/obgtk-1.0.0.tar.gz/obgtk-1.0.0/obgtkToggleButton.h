#ifndef OBGTK_TOGGLE_BUTTON_H
#define OBGTK_TOGGLE_BUTTON_H 1

#include <obgtk/obgtkButton.h>
#include <gtk/gtktogglebutton.h>

@interface Gtk_ToggleButton : Gtk_Button
{
@public
  GtkToggleButton *gtktogglebutton;
}
- castGtkToggleButton:(GtkToggleButton *)castitem;
- initWithLabel:(gchar *) label;
- set_mode:(gint) draw_indicator;
- set_state:(gint) state;
- toggled;
@end

#endif /* OBGTK_TOGGLE_BUTTON_H */
