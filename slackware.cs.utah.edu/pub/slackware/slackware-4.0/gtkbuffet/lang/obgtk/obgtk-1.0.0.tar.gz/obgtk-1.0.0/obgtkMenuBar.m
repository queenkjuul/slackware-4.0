#include "obgtkMenuBar.h"

@implementation Gtk_MenuBar
- castGtkMenuBar:(GtkMenuBar *) castitem
{
  gtkmenubar = castitem;
  return [super castGtkMenuShell:GTK_MENU_SHELL(gtkmenubar)];  
}

- init
{
  return [self castGtkMenuBar:GTK_MENU_BAR(gtk_menu_bar_new())];
}
@end
