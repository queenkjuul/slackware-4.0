#ifndef OBGTK_ACCELERATOR_TABLE_H
#define OBGTK_ACCELERATOR_TABLE_H 1

#include <objc/Object.h>
#include <gtk/gtkaccelerator.h>

@interface Gtk_AcceleratorTable : Object
{
@public
  GtkAcceleratorTable *gtkacceleratortable;
}
- ref;
- unref;
- install:(id) gtk_object
	 :(const gchar *) signal_name
	 :(guchar) accelerator_key
	 :(guint8) accelerator_mods;
- remove   :(id) gtk_object
 signalName:(const char *) signal_name;
- (gint) check:(const guchar) accelerator_key
	      :(guint8) accelerator_mods;
- set_mod_mask:(guint8) modifier_mask;
@end

#endif /* OBGTK_ACCELERATOR_TABLE_H */
