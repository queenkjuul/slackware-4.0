#ifndef OBGTK_CHECK_MENU_ITEM_H
#define OBGTK_CHECK_MENU_ITEM_H 1

#include <obgtk/obgtkMenuItem.h>
#include <gtk/gtkcheckmenuitem.h>

@interface Gtk_CheckMenuItem : Gtk_MenuItem
{
@public
  GtkCheckMenuItem *gtkcheckmenuitem;
}
- initWithLabel:(gchar *) label;
- init;
- castGtkCheckMenuItem:(GtkCheckMenuItem *)castitem;
- set_state:(gint) state;
- set_show_toggle:(gboolean) always;
- toggled;
@end

#endif /* OBGTK_CHECK_MENU_ITEM_H */
