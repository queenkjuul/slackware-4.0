#ifndef OBGTK_ALIGNMENT_H
#define OBGTK_ALIGNMENT_H 1

#include <obgtk/obgtkBin.h>
#include <gtk/gtkalignment.h>

@interface Gtk_Alignment : Gtk_Bin
{
@public
  GtkAlignment *gtkalignment;
}
- init;
- initWithAlignmentInfo:(gfloat) xalign
		 alignY:(gfloat) yalign
		 scaleX:(gfloat) xscale
		 scaleY:(gfloat) yscale;
- set  :(gfloat) xalign
 alignY:(gfloat) yalign
 scaleX:(gfloat) xscale
 scaleY:(gfloat) yscale;
@end

#endif /* OBGTK_ALIGNMENT_H */
