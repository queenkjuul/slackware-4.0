#ifndef OBGTK_CHECK_BUTTON_H
#define OBGTK_CHECK_BUTTON_H 1

#include <obgtk/obgtkToggleButton.h>
#include <gtk/gtkcheckbutton.h>

@interface Gtk_CheckButton : Gtk_ToggleButton
{
@public
  GtkCheckButton *gtkcheckbutton;
}
- initWithLabel:(gchar *) label;
- castGtkCheckButton:(GtkCheckButton *)castitem;
@end

#endif /* OBGTK_CHECK_BUTTON_H */
