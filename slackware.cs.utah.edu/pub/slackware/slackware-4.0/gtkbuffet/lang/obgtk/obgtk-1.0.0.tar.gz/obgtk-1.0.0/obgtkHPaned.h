#ifndef OBGTK_HPANED_H
#define OBGTK_HPANED_H 1
#include <obgtk/obgtkPaned.h>
#include <gtk/gtkhpaned.h>

@interface Gtk_HPaned : Gtk_Paned
- castGtkHPaned:(GtkHPaned *)castitem;
@end
#endif /* OBGTK_HPANED_H */
