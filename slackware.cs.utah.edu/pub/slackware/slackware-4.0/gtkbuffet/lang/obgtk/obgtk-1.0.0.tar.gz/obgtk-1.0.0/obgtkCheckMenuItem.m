#include "obgtkCheckMenuItem.h"

@implementation Gtk_CheckMenuItem
- init
{
  gtkcheckmenuitem = GTK_CHECK_MENU_ITEM(gtk_check_menu_item_new());
  return [super castGtkMenuItem:GTK_MENU_ITEM(gtkcheckmenuitem)];
}

- initWithLabel:(gchar *) label
{
  gtkcheckmenuitem =
	GTK_CHECK_MENU_ITEM(gtk_check_menu_item_new_with_label(label));
  return [super castGtkMenuItem:GTK_MENU_ITEM(gtkcheckmenuitem)];
}

- castGtkCheckMenuItem:(GtkCheckMenuItem *)castitem
{
  gtkcheckmenuitem = castitem;
  return [super castGtkMenuItem:GTK_MENU_ITEM(castitem)];
}

- set_state:(gint) state
{
  gtk_check_menu_item_set_state(gtkcheckmenuitem, state);
  return self;
}

- set_show_toggle:(gboolean) always
{
  gtk_check_menu_item_set_state(gtkcheckmenuitem, always);
  return self;
}

- toggled
{
  gtk_check_menu_item_toggled(gtkcheckmenuitem);
  return self;
}
@end
