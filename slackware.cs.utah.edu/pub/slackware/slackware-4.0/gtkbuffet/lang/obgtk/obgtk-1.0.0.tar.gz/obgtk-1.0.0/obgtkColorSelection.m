#include "obgtkColorSelection.h"

@implementation Gtk_ColorSelection
- init
{
  gtkcolorselection = GTK_COLOR_SELECTION(gtk_color_selection_new());
  return [super castGtkBox:GTK_BOX(gtkcolorselection)];
}

- set_update_policy:(GtkUpdateType) policy
{
  gtk_color_selection_set_update_policy(gtkcolorselection, policy);
  return self;

}

- set_opacity:(gint) use_opacity
{
  gtk_color_selection_set_opacity(gtkcolorselection, use_opacity);
  return self;
}

- set_color:(gdouble *) color
{
  gtk_color_selection_set_color(gtkcolorselection, color);
  return self;
}

- get_color:(gdouble *) color
{
  gtk_color_selection_get_color(gtkcolorselection, color);
  return self;
}
@end
