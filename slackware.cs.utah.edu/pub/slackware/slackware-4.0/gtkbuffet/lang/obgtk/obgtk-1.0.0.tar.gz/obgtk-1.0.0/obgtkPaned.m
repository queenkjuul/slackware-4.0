#include "obgtkPaned.h"
@implementation Gtk_Paned
- castGtkPaned:(GtkPaned *)castitem
{
  gtkpaned = castitem;
  return [super castGtkContainer:GTK_CONTAINER(castitem)];
}
- add1:(Gtk_Widget *) widget
{
  gtk_paned_add1(gtkpaned, widget->gtkwidget);
  return self;
}

- add2:(Gtk_Widget *) widget
{
  gtk_paned_add2(gtkpaned, widget->gtkwidget);
  return self;
}

- handle_size:(guint16) size
{
  gtk_paned_handle_size(gtkpaned, size);
  return self;
}

- gutter_size:(guint16) size
{
  gtk_paned_gutter_size(gtkpaned, size);
  return self;
}

@end
