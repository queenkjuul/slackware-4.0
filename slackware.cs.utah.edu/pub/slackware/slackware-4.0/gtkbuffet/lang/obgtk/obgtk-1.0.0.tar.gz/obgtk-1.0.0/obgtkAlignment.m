#include "obgtkAlignment.h"

@implementation Gtk_Alignment
- init
{
  return [self initWithAlignmentInfo:0
	       alignY:0
	       scaleX:100
	       scaleY:100];
}
- initWithAlignmentInfo:(gfloat) xalign
		 alignY:(gfloat) yalign
		 scaleX:(gfloat) xscale
		 scaleY:(gfloat) yscale
{
  gtkalignment = GTK_ALIGNMENT(gtk_alignment_new(xalign, yalign,
						 xscale, yscale));
  [super castGtkBin:GTK_BIN(gtkalignment)];
  return self;
}

- set  :(gfloat) xalign
 alignY:(gfloat) yalign
 scaleX:(gfloat) xscale
 scaleY:(gfloat) yscale
{
  gtk_alignment_set(gtkalignment, xalign, yalign, xscale, yscale);
  return self;
}
@end
