#ifndef OBGTK_RADIO_BUTTON_H
#define OBGTK_RADIO_BUTTON_H 1

#include <obgtk/obgtkCheckButton.h>
#include <gtk/gtkradiobutton.h>

@interface Gtk_RadioButton : Gtk_CheckButton
{
@public
  GtkRadioButton *gtkradiobutton;
}
- initWithRadioGroup:(GSList *) group;
- initWithRadioGroupLabel:(GSList *) group
		    label:(const gchar *) label;
- castGtkRadioButton:(GtkRadioButton *) castitem;
- initWithRadioWidget:(id) gtk_radio;
- initWithRadioWidgetLabel:(id) gtk_radio
		     label:(const gchar *) label;
- (GSList *) group;
- set_group:(GSList *) group;
@end

#endif /* OBGTK_RADIO_BUTTON_H */
