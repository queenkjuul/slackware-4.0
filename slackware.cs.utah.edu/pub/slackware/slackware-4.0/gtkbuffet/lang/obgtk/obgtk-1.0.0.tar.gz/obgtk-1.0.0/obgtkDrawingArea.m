#include "obgtkDrawingArea.h"

@implementation Gtk_DrawingArea
- castGtkDrawingArea:(GtkDrawingArea *) castitem
{
  gtkdrawingarea = castitem;
  return [super castGtkWidget:GTK_WIDGET(castitem)];
}

- init
{
  gtkdrawingarea = GTK_DRAWING_AREA(gtk_drawing_area_new());
  return [super castGtkWidget:GTK_WIDGET(gtkdrawingarea)];
}

- size    :(gint) width
 setHeight:(gint) height
{
  gtk_drawing_area_size(gtkdrawingarea, width, height);
  return self;
}
@end
