#include "obgtkLabel.h"

@implementation Gtk_Label
- castGtkLabel:(GtkLabel *) castitem
{
  gtklabel = GTK_LABEL(castitem);
  return [super castGtkMisc:GTK_MISC(castitem)];
}

- init
{
  return [self initWithLabel:""];
}

- initWithLabel:(gchar *) str
{
  return [self castGtkLabel:GTK_LABEL(gtk_label_new(str))];
}

- set:(gchar *) str
{
  gtk_label_set(gtklabel, str);
  return self;
}

- get:(gchar **) str
{
  gtk_label_get(gtklabel, str);
  return self;
}

- set_justify:(GtkJustification) just
{
  gtk_label_set_justify (gtklabel, just);
  return self;
}

@end
