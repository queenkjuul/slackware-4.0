#include "obgtkHRuler.h"

@implementation Gtk_HRuler
- init
{
  return [super castGtkRuler:GTK_RULER(gtk_hruler_new())];
}
@end
