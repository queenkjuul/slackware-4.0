#ifndef OBGTK_TABLE_H
#define OBGTK_TABLE_H 1

#include <obgtk/obgtkContainer.h>
#include <obgtk/obgtkWidget.h>
#include <gtk/gtktable.h>

@interface Gtk_Table : Gtk_Container
{
@public
  GtkTable *gtktable;
}
- init;
- castGtkTable:(GtkTable *) castitem;
- initWithTableInfo:(gint) rows
	    cntCols:(gint) columns
	     isHomo:(gint) homogeneous;
- attach     :(Gtk_Widget *) child
   attachLeft:(gint) left_attach
  attachRight:(gint) right_attach
    attachTop:(gint) top_attach
 attachBottom:(gint) bottom_attach
     optionsX:(gint) xoptions
     optionsY:(gint) yoptions
     paddingX:(gint) xpadding
     paddingY:(gint) ypadding;
- attach_defaults:(Gtk_Widget *) child
       attachLeft:(gint) left_attach
      attachRight:(gint) right_attach
	attachTop:(gint) top_attach
     attachBottom:(gint) bottom_attach;
- set_row_spacing:(gint) row
	  Spacing:(gint) spacing;
- set_col_spacing:(gint) row
	  Spacing:(gint) spacing;
- set_row_spacings:(gint) spacing;
- set_col_spacings:(gint) spacing;
- set_homogeneous:(gint) homogeneous;
@end

#endif /* OBGTK_TABLE_H */
