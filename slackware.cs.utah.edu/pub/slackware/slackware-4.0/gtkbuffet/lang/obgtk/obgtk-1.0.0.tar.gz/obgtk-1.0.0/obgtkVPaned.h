#ifndef OBGTK_VPANED_H
#define OBGTK_VPANED_H 1

#include <obgtk/obgtkPaned.h>
#include <gtk/gtkvpaned.h>

@interface Gtk_VPaned : Gtk_Paned
- castGtkVPaned:(GtkVPaned *)castitem;
@end
#endif /* OBGTK_VPANED_H */
