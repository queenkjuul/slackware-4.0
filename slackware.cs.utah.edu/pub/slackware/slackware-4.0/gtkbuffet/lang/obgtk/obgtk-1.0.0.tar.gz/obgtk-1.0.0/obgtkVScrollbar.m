#include "obgtkVScrollbar.h"

@implementation Gtk_VScrollbar
- init
{
  [self error:"Gtk_VScrollbar: call of \"init\" method in class requiring initialization parameters. Use \"initWithGtkAdjustment\" instead."];
  return self;
}

- initWithGtkAdjustment:(id) adjustment
{
  return [super castGtkScrollbar:GTK_SCROLLBAR(gtk_vscrollbar_new(GTK_ADJUSTMENT([adjustment getGtkObject])))];
}
@end
