#include "obgtkButtonBox.h"

@implementation Gtk_ButtonBox
- castGtkButtonBox:(GtkButtonBox *) castitem
{
	gtkbuttonbox = castitem;
	return [super castGtkBox:GTK_BOX(castitem)];
}

- get_child_size_default:(gint *) min_width
			:(gint *) min_height
{
	gtk_button_box_get_child_size_default(min_width, min_height);
	return self;
}

- get_child_ipadding_default:(gint *) ipad_x
			    :(gint *) ipad_y
{
	gtk_button_box_get_child_ipadding_default(ipad_x, ipad_y);
	return self;
}

- set_child_size_default:(gint) min_width
			:(gint) min_height
{
  gtk_button_box_set_child_size_default(min_width, min_height);
  return self;
}

- set_child_ipadding_default:(gint) ipad_x
			    :(gint) ipad_y
{
  gtk_button_box_set_child_ipadding_default(ipad_x, ipad_y);
  return self;
}

- (gint) get_spacing
{
  return gtk_button_box_get_spacing(gtkbuttonbox);
}

- (gint) get_layout
{
  return gtk_button_box_get_layout(gtkbuttonbox);
}

- get_child_size:(gint *) min_width
	        :(gint *) min_height
{
  gtk_button_box_get_child_size(gtkbuttonbox, min_width, min_height);
  return self;
}

- get_child_ipadding:(gint *) ipad_x
		    :(gint *) ipad_y
{
  gtk_button_box_get_child_ipadding(gtkbuttonbox, ipad_x, ipad_y);
  return self;  
}

- set_spacing:(gint) spacing
{
  gtk_button_box_set_spacing(gtkbuttonbox, spacing);
  return self;
}

- set_layout:(gint) layout_style
{
  gtk_button_box_set_layout(gtkbuttonbox, layout_style);
  return self;
}

- set_child_size:(gint) min_width
		:(gint) min_height
{
  gtk_button_box_set_child_size(gtkbuttonbox, min_width, min_height);
  return self;
}

- set_child_ipadding:(gint) ipad_x
		    :(gint) ipad_y
{
  gtk_button_box_set_child_ipadding(gtkbuttonbox, ipad_x, ipad_y);
  return self;
}
@end
