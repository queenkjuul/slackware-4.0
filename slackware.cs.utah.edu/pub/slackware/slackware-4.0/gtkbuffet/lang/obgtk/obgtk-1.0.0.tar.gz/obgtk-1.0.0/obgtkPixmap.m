#include "obgtkPixmap.h"

@implementation Gtk_Pixmap

- init
{
  [self error:"Gtk_Pixmap: attempt to call \"init\" method on a class requiring parameters for initialization. Use \"initWithImage\" instead."];
  return self;
}

- initWithImage:(GdkPixmap *) pixmap
	    imgMask:(GdkBitmap *) mask
{
  gtkpixmap = GTK_PIXMAP(gtk_pixmap_new(pixmap, mask));
  return [super castGtkMisc:GTK_MISC(gtkpixmap)];
}

- set   :(GdkPixmap *) pixmap
 imgMask:(GdkBitmap *) mask
{
  gtk_pixmap_set(gtkpixmap, pixmap, mask);
  return self;
}

- get   :(GdkPixmap **) pixmap
 imgMask:(GdkBitmap **) mask
{
  gtk_pixmap_get(gtkpixmap, pixmap, mask);
  return self;
}
@end
