#ifndef OBGTK_TOOLBAR_H
#define OBGTK_TOOLBAR_H 1

#include <obgtk/obgtkContainer.h>
#include <obgtk/obgtkPixmap.h>
#include <gtk/gtktoolbar.h>

@interface Gtk_Toolbar : Gtk_Container
{
@public
  GtkToolbar *gtktoolbar;
}

- castGtkToolbar:(GtkToolbar *)castitem;
- initWithToolbarInfo:(GtkOrientation) orientation
		     :(GtkToolbarStyle) style;
- append_item:(const char *) text
	     :(const char *) tooltip_text
	     :(const char *) private_tooltip_text
	     :(id) icon
	     :(GtkSignalFunc) callback
	     :(gpointer) user_data;
- prepend_item:(const char *) text
	      :(const char *) tooltip_text
	      :(const char *) private_tooltip_text
	      :(id) icon
	      :(GtkSignalFunc) callback
	      :(gpointer) user_data;
- insert_item:(const char *) text
	     :(const char *) tooltip_text
	     :(const char *) private_tooltip_text
	     :(id) icon
	     :(GtkSignalFunc) callback
	     :(gpointer) user_data
	     :(gint) position;
- append_space;
- prepend_space;
- insert_space:(gint) position;
- set_orientation:(GtkOrientation) orientation;
- set_style:(GtkToolbarStyle) style;
- set_tooltips:(BOOL) enable;
- set_space_size:(gint) space_size;
@end

#endif /* OBGTK_HBOX_H */
