#include "obgtkFixed.h"

@implementation Gtk_Fixed
- init
{
  return [self castGtkFixed:GTK_FIXED(gtk_fixed_new())];
}

- castGtkFixed:(GtkFixed *) castitem
{
  gtkfixed = castitem;
  return [super castGtkContainer:GTK_CONTAINER(castitem)];
}

- put:(Gtk_Widget *) widget
     :(gint16) x
     :(gint16) y
{
  gtk_fixed_put(gtkfixed, widget->gtkwidget, x, y);
  return self;
}

- move:(Gtk_Widget *) widget
      :(gint16) x
      :(gint16) y
{
  gtk_fixed_move(gtkfixed, widget->gtkwidget, x, y);
  return self;
}
@end
