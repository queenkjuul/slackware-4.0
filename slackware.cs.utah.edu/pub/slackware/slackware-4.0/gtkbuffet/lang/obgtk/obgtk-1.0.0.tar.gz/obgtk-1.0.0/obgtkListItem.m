#include "obgtkListItem.h"

@implementation Gtk_ListItem
- init
{
  return [super castGtkItem:GTK_ITEM(gtk_list_item_new())];
}

- initWithLabel:(gchar *) label
{
  return [super castGtkItem:GTK_ITEM(gtk_list_item_new_with_label(label))];
}

- select
{
  gtk_list_item_select(GTK_LIST_ITEM(gtkitem));
  return self;
}

- deselect
{
  gtk_list_item_deselect(GTK_LIST_ITEM(gtkitem));
  return self;
}
@end
