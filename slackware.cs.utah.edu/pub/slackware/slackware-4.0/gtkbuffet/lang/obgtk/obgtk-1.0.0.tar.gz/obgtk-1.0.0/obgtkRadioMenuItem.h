#ifndef OBGTK_RADIO_MENU_ITEM_H
#define OBGTK_RADIO_MENU_ITEM_H 1

#include <obgtk/obgtkCheckMenuItem.h>
#include <gtk/gtkradiomenuitem.h>

@interface Gtk_RadioMenuItem : Gtk_CheckMenuItem
{
@public
  GtkRadioMenuItem *gtkradiomenuitem;
}
- castGtkRadioMenuItem:(GtkRadioMenuItem *) castitem;
- initWithRadioGroup:(GSList *) group;
- initWithRadioGroupLabel:(GSList *) group
		    label:(const gchar *) label;
- (GSList *) group;
@end

#endif /* OBGTK_RADIO_MENU_ITEM_H */
