#ifndef OBGTK_VBOX_H
#define OBGTK_VBOX_H 1

#include <obgtk/obgtkBox.h>
#include <gtk/gtkvbox.h>

@interface Gtk_VBox : Gtk_Box
- castGtkVBox:(GtkVBox *)castitem;
- initWithBoxInfo:(gint) homogeneous
       setSpacing:(gint) spacing;
@end

#endif /* OBGTK_VBOX_H */
