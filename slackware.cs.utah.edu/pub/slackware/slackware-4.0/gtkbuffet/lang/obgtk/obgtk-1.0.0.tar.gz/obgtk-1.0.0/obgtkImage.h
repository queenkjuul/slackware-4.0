#ifndef OBGTK_IMAGE_H
#define OBGTK_IMAGE_H 1

#include <obgtk/obgtkMisc.h>
#include <gtk/gtkimage.h>

@interface Gtk_Image : Gtk_Misc
{
@public
  GtkImage *gtkimage;
}
- initWithImageInfo:(GdkImage *) val
	    imgMask:(GdkBitmap *) mask;
- set   :(GdkImage *) val
 imgMask:(GdkBitmap *) mask;
- get   :(GdkImage **) val
 imgMask:(GdkBitmap **) mask;
@end

#endif /* OBGTK_IMAGE_H */
