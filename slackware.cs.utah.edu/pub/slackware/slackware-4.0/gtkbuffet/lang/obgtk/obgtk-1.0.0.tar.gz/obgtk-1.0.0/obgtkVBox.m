#include "obgtkVBox.h"

@implementation Gtk_VBox
- castGtkVBox:(GtkVBox *)castitem
{
  return [super castGtkBox:GTK_BOX(castitem)];
}

- init
{
  return [self initWithBoxInfo:FALSE setSpacing:5];
}

- initWithBoxInfo:(gint) homogeneous
 setSpacing:(gint) spacing
{
  return [self castGtkVBox:GTK_VBOX(gtk_vbox_new(homogeneous, spacing))];
}
@end
