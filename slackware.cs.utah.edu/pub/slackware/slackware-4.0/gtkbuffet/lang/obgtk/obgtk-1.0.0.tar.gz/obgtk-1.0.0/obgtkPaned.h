#ifndef OBGTK_PANED_H
#define OBGTK_PANED_H 1
#include <obgtk/obgtkContainer.h>
#include <gtk/gtkpaned.h>
@interface Gtk_Paned : Gtk_Container
{
@public
   GtkPaned *gtkpaned;
}
- castGtkPaned:(GtkPaned *)castitem;
- add1:(Gtk_Widget *) widget;
- add2:(Gtk_Widget *) widget;
- handle_size:(guint16) size;
- gutter_size:(guint16) size;
@end
#endif /* OBGTK_PANED_H */
