#include "obgtkScale.h"

@implementation Gtk_Scale
- castGtkScale:(GtkScale *) castitem
{
  gtkscale = castitem;
  return [super castGtkRange:GTK_RANGE(castitem)];
}

- set_digits:(gint) digits
{
  gtk_scale_set_digits(gtkscale, digits);
  return self;
}

- set_draw_value:(gint) draw_value
{
  gtk_scale_set_draw_value(gtkscale, draw_value);
  return self;
}

- set_value_pos:(GtkPositionType) pos
{
  gtk_scale_set_value_pos(gtkscale, pos);
  return self;
}

- (gint) value_width
{
  return gtk_scale_value_width(gtkscale);
}

- draw_value
{
  gtk_scale_draw_value(gtkscale);
  return self;
}
@end
