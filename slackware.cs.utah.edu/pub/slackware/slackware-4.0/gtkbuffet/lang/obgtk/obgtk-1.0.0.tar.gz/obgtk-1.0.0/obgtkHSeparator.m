#include "obgtkHSeparator.h"

@implementation Gtk_HSeparator
- init
{
  return [super castGtkSeparator:GTK_SEPARATOR(gtk_hseparator_new())];
}
@end
