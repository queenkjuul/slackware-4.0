#ifndef OBGTK_MENU_H
#define OBGTK_MENU_H 1

#include <obgtk/obgtkMenuShell.h>
#include <obgtk/obgtkWidget.h>
#include <obgtk/obgtkAcceleratorTable.h>
#include <obgtk/obgtkMenuItem.h>
#include <gtk/gtkmenu.h>

@class Gtk_MenuItem; /* Needed, for some strange reason, even tho we include the above thing */
@interface Gtk_Menu : Gtk_MenuShell
{
@public
  GtkMenu *gtkmenu;
}
- castGtkMenu:(GtkMenu *) castitem;
- popup     :(id) parent_menu_shell
    menuItem:(id) parent_menu_item
     posFunc:(GtkMenuPositionFunc) func
 posFuncData:(gpointer) data
  posFuncBtn:(gint) button
 posFuncTime:(guint32) activate_time;
- popdown;
- (id) get_active;
- set_active:(gint) index;
- set_accelerator_table:(id) table;
- attach_to_widget:(id) attach_widget
    detachFunction:(GtkMenuDetachFunc) detacher;
- (id) get_attach_widget;
- detach;
@end

#endif /* OBGTK_MENU_H */
