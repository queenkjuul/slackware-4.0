#include "obgtkEventBox.h"

@implementation Gtk_EventBox
- init
{
  return [self castGtkEventBox:GTK_EVENT_BOX(gtk_event_box_new())];
}

- castGtkEventBox:(GtkEventBox *) castitem
{
  gtkeventbox = castitem;
  return [super castGtkBin:GTK_BIN(castitem)];
}
@end
