#ifndef OBGTK_LABEL_H
#define OBGTK_LABEL_H 1

#include <obgtk/obgtkMisc.h>
#include <gtk/gtklabel.h>

@interface Gtk_Label : Gtk_Misc
{
@public
  GtkLabel *gtklabel;
}

- castGtkLabel:(GtkLabel *) castitem;
- initWithLabel:(gchar *) str;
- set:(gchar *) str;
- get:(gchar **) str;
- set_justify:(GtkJustification) just;
@end

#endif /* OBGTK_LABEL_H */
