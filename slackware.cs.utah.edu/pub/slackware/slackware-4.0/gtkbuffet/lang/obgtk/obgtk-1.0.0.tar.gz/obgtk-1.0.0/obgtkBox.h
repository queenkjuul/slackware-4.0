#ifndef OBGTK_BOX_H
#define OBGTK_BOX_H 1

#include <obgtk/obgtkContainer.h>
#include <obgtk/obgtkWidget.h>
#include <gtk/gtkbox.h>

@interface Gtk_Box : Gtk_Container
{
@public
  GtkBox *gtkbox;
}
- castGtkBox:(GtkBox *) castitem;
- pack_start:(Gtk_Widget *) child
    doExpand:(gint) expand
      doFill:(gint) fill
   doPadding:(gint) padding;
- pack_end:(Gtk_Widget *) child
    doExpand:(gint) expand
      doFill:(gint) fill
   doPadding:(gint) padding;
- pack_start_defaults:(Gtk_Widget *) child;
- pack_end_defaults:(Gtk_Widget *) child;
- set_homogeneous:(gint) homogeneous;
- set_spacing:(gint) spacing;
- reorder_child  :(id) child
 newChildPosition:(guint) pos;
- query_child_packing:(id) child
	    getExpand:(gint *) expand
	      getFill:(gint *) fill
	   getPadding:(gint *) padding
	  getPackType:(GtkPackType *) pack_type;
- set_child_packing:(id) child
	  setExpand:(gint) expand
	    setFill:(gint) fill
	 setPadding:(gint) padding
	setPackType:(GtkPackType) pack_type;
@end

#endif /* OBGTK_BOX_H */
