#ifndef OBGTK_STATUSBAR_H
#define OBGTK_STATUSBAR_H 1

#include <obgtk/obgtkHBox.h>
#include <gtk/gtkstatusbar.h>

@interface Gtk_Statusbar : Gtk_HBox
{
@public
  GtkStatusbar *gtkstatusbar;
}
- castGtkStatusbar:(GtkStatusbar *)castitem;
- (guint) get_context_id:(const gchar *) context_description;
- (guint) push:(guint) context_id
	      :(const gchar *) text;
- pop:(guint) context_id;
- remove:(guint) context_id
	:(guint) message_id;

@end

#endif /* OBGTK_HBOX_H */
