#ifndef OBGTK_LIST_ITEM_H
#define OBGTK_LIST_ITEM_H 1

#include <obgtk/obgtkItem.h>
#include <gtk/gtklistitem.h>

@interface Gtk_ListItem : Gtk_Item
- initWithLabel:(gchar *) label;
- select;
- deselect;
@end

#endif /* OBGTK_LIST_ITEM_H */
