#include "obgtkHandleBox.h"

@implementation Gtk_HandleBox
- init
{
  return [self castGtkHandleBox:GTK_HANDLE_BOX(gtk_handle_box_new())];
}

- castGtkHandleBox:(GtkHandleBox *) castitem
{
  gtkhandlebox = castitem;
  return [super castGtkBin:GTK_BIN(castitem)];
}
@end
