#include "obgtkOptionMenu.h"

@implementation Gtk_OptionMenu
- castGtkOptionMenu:(GtkOptionMenu *) castitem
{
  gtkoptionmenu = castitem;
  return [super castGtkButton:GTK_BUTTON(castitem)];
}

- init
{
  return [self castGtkOptionMenu:GTK_OPTION_MENU(gtk_option_menu_new())];
}

- (id) get_menu
{
  return (id)gtk_object_get_data(GTK_OBJECT(gtk_option_menu_get_menu(gtkoptionmenu)), "objc_id");
}

- set_menu:(id) gtk_menu
{
  gtk_option_menu_set_menu(gtkoptionmenu, GTK_WIDGET([gtk_menu getGtkObject]));
  return self;
}

- remove_menu
{
  gtk_option_menu_remove_menu(gtkoptionmenu);
  return self;
}

- set_history:(gint) index
{
  gtk_option_menu_set_history(gtkoptionmenu, index);
  return self;
}
@end
