#ifndef OBGTK_PROGRESS_BAR_H
#define OBGTK_PROGRESS_BAR_H 1

#include <obgtk/obgtkWidget.h>
#include <gtk/gtkprogressbar.h>

@interface Gtk_ProgressBar : Gtk_Widget
{
@public
  GtkProgressBar *gtkprogressbar;
}
- update:(gfloat) percentage;
@end

#endif /* OBGTK_PROGRESS_BAR_H */
