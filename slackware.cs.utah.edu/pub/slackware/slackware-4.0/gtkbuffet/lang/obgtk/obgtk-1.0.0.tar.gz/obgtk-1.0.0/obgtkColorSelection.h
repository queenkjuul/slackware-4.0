#ifndef OBGTK_COLOR_SELECTION_H
#define OBGTK_COLOR_SELECTION_H 1

#include <obgtk/obgtkVBox.h>
#include <gtk/gtkcolorsel.h>

@interface Gtk_ColorSelection : Gtk_VBox
{
@public
  GtkColorSelection *gtkcolorselection;
}
- set_update_policy:(GtkUpdateType) policy;
- set_opacity:(gint) use_opacity;
- set_color:(gdouble *) color;
- get_color:(gdouble *) color;
@end

#endif /* OBGTK_COLOR_SELECTION_H */
