#ifndef OBGTK_FILE_SELECTION_H
#define OBGTK_FILE_SELECTION_H 1

#include <obgtk/obgtkWindow.h>
#include <gtk/gtkfilesel.h>

@interface Gtk_FileSelection : Gtk_Window
{
@public
  GtkFileSelection *gtkfileselection;
}
- initWithLabel:(gchar *) title;
- set_filename:(gchar *)filename;
- (gchar *) get_filename;
- show_fileop_buttons;
- hide_fileop_buttons;
@end

#endif /* OBGTK_FILE_SELECTION_H */
