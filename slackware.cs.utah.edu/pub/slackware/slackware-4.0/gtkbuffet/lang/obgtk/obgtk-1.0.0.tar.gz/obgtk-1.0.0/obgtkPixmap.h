#ifndef OBGTK_PIXMAP_H
#define OBGTK_PIXMAP_H 1

#include <obgtk/obgtkMisc.h>
#include <gtk/gtkpixmap.h>

@interface Gtk_Pixmap : Gtk_Misc
{
@public
  GtkPixmap *gtkpixmap;
}
- initWithImage:(GdkPixmap *) pixmap
	imgMask:(GdkBitmap *) mask;
- set   :(GdkPixmap *) pixmap
 imgMask:(GdkBitmap *) mask;
- get   :(GdkPixmap **) pixmap
 imgMask:(GdkBitmap **) mask;
@end

#endif /* OBGTK_PIXMAP_H */
