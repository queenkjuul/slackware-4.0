#include "obgtkItem.h"

@implementation Gtk_Item
- castGtkItem:(GtkItem *)castitem;
{
  gtkitem = GTK_ITEM(castitem);
  return [super castGtkBin:GTK_BIN(gtkitem)];
}

- select
{
  gtk_item_select(gtkitem);
  return self;
}

- deselect
{
  gtk_item_deselect(gtkitem);
  return self;
}

- toggle
{
  gtk_item_toggle(gtkitem);
  return self;
}
@end
