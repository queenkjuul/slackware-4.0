#ifndef OBGTK_SCROLLED_WINDOW_H
#define OBGTK_SCROLLED_WINDOW_H 1

#include <obgtk/obgtkContainer.h>
#include <obgtk/obgtkAdjustment.h>
#include <gtk/gtkscrolledwindow.h>

@interface Gtk_ScrolledWindow : Gtk_Container
{
@public
  GtkScrolledWindow *gtkscrolledwindow;
}
- castGtkScrolledWindow:(GtkScrolledWindow *) castitem;
- initWithAdjustments:(id) hadjustment
		 adjV:(id) vadjustment;
- (id)get_hadjustment;
- (id)get_vadjustment;
- set_policy:(GtkPolicyType) hscrollbar_policy
    pVScroll:(GtkPolicyType) vscrollbar_policy;
@end

#endif /* OBGTK_SCROLLED_WINDOW_H */
