#include "obgtkButton.h"

@implementation Gtk_Button
- castGtkButton:(GtkButton *) castitem
{
  gtkbutton = castitem;
  return [super castGtkContainer:GTK_CONTAINER(castitem)];
}

- init
{
  return [self castGtkButton:GTK_BUTTON(gtk_button_new())];
}

- initWithLabel:(gchar *) label
{
  return [self castGtkButton:GTK_BUTTON(gtk_button_new_with_label(label))];
}

- pressed
{
  gtk_button_pressed(gtkbutton);
  return self;
}

- released
{
  gtk_button_released(gtkbutton);
}

- clicked
{
  gtk_button_clicked(gtkbutton);
}

- enter
{
  gtk_button_enter(gtkbutton);
}

- leave
{
  gtk_button_leave(gtkbutton);
}
@end
