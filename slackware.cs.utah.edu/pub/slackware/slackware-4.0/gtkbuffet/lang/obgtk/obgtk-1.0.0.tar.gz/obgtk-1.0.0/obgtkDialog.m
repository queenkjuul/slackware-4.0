#include "obgtkDialog.h"
#include "obgtkHBox.h"
#include "obgtkVBox.h"
#include <gtk/gtk.h>

@implementation Gtk_Dialog
- init
{
  return [self castGtkDialog:GTK_DIALOG(gtk_dialog_new())];
}

- castGtkDialog:(GtkDialog *)castitem
{
  gtkdialog = GTK_DIALOG(castitem);
  vbox = [[Gtk_VBox alloc] castGtkVBox:GTK_VBOX(gtkdialog->vbox)];
  action_area = [[Gtk_HBox alloc] castGtkHBox:GTK_HBOX(gtkdialog->action_area)];
  return [super castGtkWindow:GTK_WINDOW(gtkdialog)];  
}
@end
