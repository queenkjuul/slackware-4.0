#ifndef OBGTK_DIALOG_H
#define OBGTK_DIALOG_H 1

#include <obgtk/obgtkWindow.h>
#include <gtk/gtk.h>

@class Gtk_HBox, Gtk_VBox;
@interface Gtk_Dialog : Gtk_Window
{
@public
  GtkDialog *gtkdialog;
  Gtk_VBox *vbox;
  Gtk_HBox *action_area;
}
- castGtkDialog:(GtkDialog *)castitem;
@end

#endif /* OBGTK_DIALOG_H */
