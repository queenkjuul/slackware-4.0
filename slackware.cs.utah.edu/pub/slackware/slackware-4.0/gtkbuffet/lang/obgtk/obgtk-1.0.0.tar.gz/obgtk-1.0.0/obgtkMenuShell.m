#include "obgtkMenuShell.h"

@implementation Gtk_MenuShell
- castGtkMenuShell:(GtkMenuShell *) castitem
{
  gtkmenushell = castitem;
  return [super castGtkContainer:GTK_CONTAINER(castitem)];
}

- appendMenuItem:(Gtk_MenuItem *) child
{
  gtk_menu_shell_append(gtkmenushell, child->gtkwidget);
  return self;
}

- prependMenuItem:(Gtk_MenuItem *) child
{
  gtk_menu_shell_prepend(gtkmenushell, child->gtkwidget);
  return self;
}

- insertMenuItem:(Gtk_MenuItem *) child
	    aPos:(gint) position
{
  gtk_menu_shell_insert(gtkmenushell, child->gtkwidget, position);
  return self;
}

- deactivate
{
  gtk_menu_shell_deactivate(gtkmenushell);
  return self;
}
@end
