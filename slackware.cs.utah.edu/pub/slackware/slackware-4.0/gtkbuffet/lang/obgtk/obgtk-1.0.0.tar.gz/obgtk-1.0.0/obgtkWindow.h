#ifndef OBGTK_WINDOW_H
#define OBGTK_WINDOW_H 1

#include <obgtk/obgtkBin.h>
#include <obgtk/obgtkWidget.h>
#include <obgtk/obgtkAcceleratorTable.h>
#include <gtk/gtkwindow.h>

@interface Gtk_Window : Gtk_Bin
{
@public
  GtkWindow *gtkwindow;
}
- castGtkWindow:(GtkWindow *) castitem;
- init;
- initWithWindowType:(GtkWindowType) wintype;
- set_title:(gchar *) title;
- set_focus:(Gtk_Widget *) focus;
- set_default:(Gtk_Widget *) defaultw;
- set_policy:
  allowShrink:(gint) allow_shrink
allowGrow:(gint) allow_grow
autoShrink:(gint) auto_shrink;
- add_accelerator_table:(Gtk_AcceleratorTable *) table;
- remove_accelerator_table:(Gtk_AcceleratorTable *) table;
- position:(GtkWindowPosition) position;

@end

#endif /* OBGTK_WINDOW_H */
