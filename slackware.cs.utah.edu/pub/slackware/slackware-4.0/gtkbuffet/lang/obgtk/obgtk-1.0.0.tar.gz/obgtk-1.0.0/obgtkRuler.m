#include "obgtkRuler.h"

@implementation Gtk_Ruler
- castGtkRuler:(GtkRuler *)castitem
{
  gtkruler = castitem;
  return [super castGtkWidget:GTK_WIDGET(castitem)];
}

- set_metric:(GtkMetricType) metric
{
  gtk_ruler_set_metric(gtkruler, metric);
  return self;
}

- set_range:(gfloat) lower
      Upper:(gfloat) upper
   Position:(gfloat) position
    sizeMax:(gfloat) max_size
{
  gtk_ruler_set_range(gtkruler, lower, upper, position, max_size);
  return self;
}

- draw_ticks
{
  gtk_ruler_draw_ticks(gtkruler);
  return self;
}

- draw_pos
{
  gtk_ruler_draw_pos(gtkruler);
  return self;
}
@end
