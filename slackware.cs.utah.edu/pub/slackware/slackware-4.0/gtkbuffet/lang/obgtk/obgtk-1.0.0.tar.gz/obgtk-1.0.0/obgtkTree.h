#ifndef OBGTK_TREE_H
#define OBGTK_TREE_H 1

#include <obgtk/obgtkContainer.h>
#include <gtk/gtktree.h>

@interface Gtk_Tree : Gtk_Container
{
@public
  GtkTree *gtktree;
}
- appendTreeItem:(id) child;
- prependTreeItem:(id) child;
- insertTreeItem:(id) child
        childPos:(gint) position;

- castGtkTree:(GtkTree *) castitem;
- remove_items:(GList *) items;
- clear_items:(gint) start :(gint) end;
- select_item:(gint) item;
- unselect_item:(gint) item;
- select_child:(id) gtk_treeitem;
- unselect_child:(id) gtk_treeitem;
- (gint)child_position:(id) gtk_treeitem;
- set_selection_mode:(GtkSelectionMode) mode;
- set_view_mode:(GtkTreeViewMode) mode;
- set_view_lines:(guint) flag;
@end

#endif /* OBGTK_TREE_H */
