#include "obgtkTreeItem.h"

@implementation Gtk_TreeItem
- castGtkTreeItem:(GtkTreeItem *) castitem
{
  gtktreeitem = castitem;
  return [super castGtkItem:GTK_ITEM(castitem)];
}

- remove_subtree
{
  gtk_tree_item_remove_subtree(gtktreeitem);
  return self;
}

- init
{
  return [self castGtkTreeItem:GTK_TREE_ITEM(gtk_tree_item_new())];
}

- initWithLabel:(gchar *) label
{
  return [self castGtkTreeItem:GTK_TREE_ITEM(gtk_tree_item_new_with_label(label))];
}

- set_subtree:(Gtk_Tree *) subtree
{
  gtk_tree_item_set_subtree(gtktreeitem, subtree->gtkwidget);
  return self;
}

- select
{
  gtk_tree_item_select(gtktreeitem);
  return self;
}

- deselect
{
  gtk_tree_item_deselect(gtktreeitem);
  return self;
}

- expand
{
  gtk_tree_item_expand(gtktreeitem);
  return self;
}

- collapse
{
  gtk_tree_item_collapse(gtktreeitem);
  return self;
}
@end
