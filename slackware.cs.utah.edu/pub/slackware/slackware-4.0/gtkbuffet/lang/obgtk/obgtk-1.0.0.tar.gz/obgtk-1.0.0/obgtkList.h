#ifndef OBGTK_LIST_H
#define OBGTK_LIST_H 1

#include <obgtk/obgtkContainer.h>
#include <gtk/gtklist.h>

@interface Gtk_List : Gtk_Container
{
@public
  GtkList *gtklist;
}
/* The GList's here are of GtkWidget's, NOT object id's */
- insert_items:(GList *) items
	  aPos:(gint) position;
- append_items:(GList *) items;
- prepend_items:(GList *) items;
- remove_items:(GList *) items;
- remove_items_no_unref:(GList *) items;
- clear_items:(gint) start
       theEnd:(gint) end;
- select_item:(gint) item;
- unselect_item:(gint) item;
- select_child:(Gtk_Widget *) child;
- unselect_child:(Gtk_Widget *) child;
- set_selection_mode:(GtkSelectionMode) mode;
@end

#endif /* OBGTK_LIST_H */
