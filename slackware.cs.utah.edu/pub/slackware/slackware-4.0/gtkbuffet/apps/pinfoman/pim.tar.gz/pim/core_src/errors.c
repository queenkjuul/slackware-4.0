
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

void 
error(char text[], int type)
{
  extern FILES files;
  FILE *fptr;
  char str[100];
  (void) cf("error");
  fptr = fopen(files.errors_file, "a");
  switch (type)
  {
  case (0):
    (void) strcpy(str, _ERR_BADCALL);
    break;
  case (1):
    (void) strcpy(str, _ERR_UOF);
    break;
  case (2):
    (void) strcpy(str, _ERR_SEEK);
    break;
  case (3):
    (void) strcpy(str, _ERR_URF);
    break;
  case (4):
    (void) strcpy(str, _ERR_UWF);
    break;
  case (5):
    (void) strcpy(str, _ERR_UROF);
    break;
  case (6):
    (void) strcpy(str, _ERR_USB);
    break;
  case (7):
    (void) strcpy(str, _ERR_URT);
    break;
  case (8):
    (void) strcpy(str, _ERR_UWT);
    break;
  case (9):
    (void) strcpy(str, _ERR_UCF);
    break;
  case (10):
    (void) strcpy(str, _ERR_UAF);
    break;
  case (11):
    (void) strcpy(str, _ERR_UAM);
    break;
  }
  (void) strcat(str, text);
  (void) fprintf(fptr, "%s\n", str);
  (void) fclose(fptr);
}
