/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include"../include/xall.h"
int signal_key;

static void 
new_person_update(GtkWidget * widget, gpointer data)
{
  Cf("new_person_update");
  (void) SetupPeopleTable();
}

static void 
new_person_cancel(GtkWidget * widget, gpointer data)
{
  Cf("new_person_cancel");
}

static void 
new_person(GtkWidget * widget, gpointer data)
{
  GtkWidget *editp = NULL;
  Cf("new_person");
  editp = editperson_new();
  if (editp == NULL)
  {
    (void) g_print("editp == NULL\n");
    return;
  }
  
  (void) editperson_type(EDITPERSON(editp), EditTypeNew);
  (void) gtk_signal_connect(GTK_OBJECT(editp), "update",
			    GTK_SIGNAL_FUNC(new_person_update), NULL);
  (void) gtk_signal_connect(GTK_OBJECT(editp), "cancel",
			    GTK_SIGNAL_FUNC(new_person_cancel), NULL);
  (void) editperson_set_person(EDITPERSON(editp), NULL);
  (void) gtk_widget_show(GTK_WIDGET(editp));
  (void) gtk_grab_add(GTK_WIDGET(editp));
}

static void 
Edit_person(GtkWidget * widget, gpointer data)
{
  GtkWidget *editp = NULL;
  PERSON person;
  int *record = NULL;
  extern XPeople *people;
  Cf("Edit_person");
  (void) init_person(&person);
  record = (int *) gtk_clist_get_row_data(GTK_CLIST(people->clist), people->row);
  person.id = *record;
  if (StartPersonEdit(&person) == True)
  {
    editp = editperson_new();
    (void) editperson_type(EDITPERSON(editp), EditTypeEdit);
    (void) gtk_signal_connect(GTK_OBJECT(editp), "update",
			      GTK_SIGNAL_FUNC(new_person_update), NULL);
    (void) gtk_signal_connect(GTK_OBJECT(editp), "cancel",
			      GTK_SIGNAL_FUNC(new_person_cancel), NULL);
    (void) editperson_set_person(EDITPERSON(editp), &person);
    (void) gtk_widget_show(editp);
    (void) gtk_grab_add(editp);
  }
}

static void 
_del_person(GtkWidget * widget, gpointer data)
{
  int *record = NULL;
  extern XPeople *people;
  Cf("Edit_person");
  record = (int *) gtk_clist_get_row_data(GTK_CLIST(people->clist), people->row);
  if (record != NULL)
  {
    DeletePersonRecord(*record);
    (void) SetupPeopleTable();
  }
}


static void 
select_a_person(GtkWidget * widget,
		gint row, gint column,
		GdkEventButton * bevent,
		gpointer data)
{
  extern XPeople *people;
  GtkWidget *editp = NULL;
  char date_str[DATE_SIZE];
  PERSON person;
  int *record = NULL;
  int i = 0;
  Cf("select_a_person");
  people->row = row;
  if ((bevent != NULL) && (widget != NULL))
  {
    switch (bevent->button)
    {
    case 1:
      if (bevent->type == GDK_BUTTON_PRESS)
      {
	record = (int *) gtk_clist_get_row_data(GTK_CLIST(people->clist), row);
	person.id = *record;
	if (ReadNormalPersonRecord(&person) == True)
	{
	  (void) gtk_container_disable_resize(GTK_CONTAINER(people->table));
	  (void) gtk_label_set(GTK_LABEL(people->nick), person.cname);
	  for (i = 0; i < 4; i++)
	  {
	    (void) gtk_entry_set_text(GTK_ENTRY(people->phone[i]),
				      person.phones[i]);
	  }
	  (void) date2str(date_str, person.bd);
	  (void) gtk_label_set(GTK_LABEL(people->bd), date_str);
	  (void) gtk_entry_set_text(GTK_ENTRY(people->email), person.email);
	  (void) gtk_container_enable_resize(GTK_CONTAINER(people->table));
	}
      }
      if (bevent->type == GDK_2BUTTON_PRESS)
      {
	record = (int *) gtk_clist_get_row_data(GTK_CLIST(people->clist), row);
	person.id = *record;
	if (StartPersonEdit(&person) == True)
	{
	  editp = editperson_new();
	  (void) editperson_type(EDITPERSON(editp), EditTypeEdit);
	  (void) gtk_signal_connect(GTK_OBJECT(editp), "update",
				  GTK_SIGNAL_FUNC(new_person_update), NULL);
	  (void) gtk_signal_connect(GTK_OBJECT(editp), "cancel",
				  GTK_SIGNAL_FUNC(new_person_cancel), NULL);
	  (void) editperson_set_person(EDITPERSON(editp), &person);
	  (void) gtk_widget_show(editp);
	  (void) gtk_grab_add(editp);
	}
      }
      break;
    case 3:
      /*
       * Popup a menu to,
       * * Edit a Person
       * * Edit a Notes
       */
      break;
    }
  }
  else
  {
    (void) g_print("The system selected row %d\n", row);
  }
}

static CONTROLS *
_create_people_controls()
{
  CONTROLS *ctrls;
  GtkTooltips *tips = NULL;
  Cf("_create_people_controls");
  tips = gtk_tooltips_new();
  ctrls = New(APP_CONTROLS, 1);
  ctrls->main = gtk_hbox_new(FALSE, 0);
  ctrls->new = gtk_button_new_with_label(NEWSTR);
  (void) gtk_tooltips_set_tip(tips, ctrls->new,
  		"Create a new person", NULL);
  ctrls->del = gtk_button_new_with_label(DELSTR);
  (void) gtk_tooltips_set_tip(tips, ctrls->del,
  		"Remove the currently selected person", NULL);
  ctrls->edit = gtk_button_new_with_label(EDITSTR);
  (void) gtk_tooltips_set_tip(tips, ctrls->edit,
  		"Change the details of the currently selected person", NULL);
  (void) gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->new, TRUE, TRUE, 0);
  (void) gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->edit, TRUE, TRUE, 0);
  (void) gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->del, TRUE, TRUE, 0);
  return ctrls;
}

void 
CreatePeopleTable()
{
  GtkWidget *vbox = NULL;
  GtkWidget *label = NULL;
  GtkTooltips *tips = NULL;
  int i = 0;
  extern XPeople *people;
  char *titles[] =
  {_REC_P2};
  char *labels[] =
  {
    _ADD_P_PHONE1,
    _ADD_P_PHONE2,
    _ADD_P_PHONE3,
    _ADD_P_PHONE4,
    "Other Phone"
  };
  char *strings[] =
  {
    "Currently selected person's home phone number",
    "Currently selected person's fax machine number",
    "Currently selected person's mobile phone number",
    "Currently selected person's work phone number",
    "Currently selected person's other phone number"
  };
  Cf("CreatePeopleTable");
  people = New(XPeople, 1);
  tips = gtk_tooltips_new();
  people->main = gtk_hbox_new(FALSE, 0);
  vbox = gtk_vbox_new(FALSE, 0);
  people->table = gtk_table_new(7, 2, FALSE);
  people->clist = gtk_clist_new_with_titles(1, titles);
  people->ctrls = _create_people_controls();

  (void) gtk_signal_connect(GTK_OBJECT(people->ctrls->new), "clicked",
			    GTK_SIGNAL_FUNC(new_person), NULL);
  (void) gtk_signal_connect(GTK_OBJECT(people->ctrls->edit), "clicked",
			    GTK_SIGNAL_FUNC(Edit_person), NULL);
  (void) gtk_signal_connect(GTK_OBJECT(people->ctrls->del), "clicked",
			    GTK_SIGNAL_FUNC(_del_person), NULL);

  (void) gtk_clist_set_column_width(GTK_CLIST(people->clist), 1, 100);
  (void) gtk_clist_set_selection_mode(GTK_CLIST(people->clist),
				      GTK_SELECTION_BROWSE);
  (void) gtk_clist_set_policy(GTK_CLIST(people->clist),
			      GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  signal_key = (int) gtk_signal_connect(GTK_OBJECT(people->clist),
		      "select_row", GTK_SIGNAL_FUNC(select_a_person), NULL);
  (void) gtk_clist_column_titles_passive(GTK_CLIST(people->clist));
  (void) gtk_box_pack_start(GTK_BOX(people->main), vbox, TRUE, TRUE, 0);
  (void) gtk_box_pack_start(GTK_BOX(vbox), people->clist, TRUE, TRUE, 0);
  (void) gtk_box_pack_start(GTK_BOX(vbox), people->ctrls->main, FALSE, FALSE, 0);

  people->nick = gtk_label_new("");
  (void) gtk_table_attach_defaults(GTK_TABLE(people->table),
				   people->nick, 0, 2, 0, 1);
  (void) gtk_widget_show(people->nick);

  for (i = 0; i < 4; i++)
  {
    people->phone[i] = gtk_entry_new_with_max_length((guint16) 50);
    (void) gtk_entry_set_editable(GTK_ENTRY(people->phone[i]), FALSE);
    (void) gtk_widget_set_usize(GTK_WIDGET(people->phone[i]), 80, 20);
    (void) gtk_table_attach_defaults(GTK_TABLE(people->table),
				     people->phone[i], 1, 2, i + 1, i + 2);
    (void) gtk_tooltips_set_tip(tips, people->phone[i], strings[i], NULL);
    (void) gtk_widget_show(people->phone[i]);

    label = gtk_label_new(labels[i]);
    (void) gtk_table_attach_defaults(GTK_TABLE(people->table),
				     label, 0, 1, i + 1, i + 2);
    /*(void) gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_LEFT);*/
    (void) gtk_misc_set_padding(GTK_MISC(label),3,0);
    (void) gtk_misc_set_alignment(GTK_MISC(label), 0, .5);
    (void) gtk_widget_show(label);
  }

  people->bd = gtk_label_new("");
  (void) gtk_table_attach_defaults(GTK_TABLE(people->table),
				   people->bd, 1, 2, 5, 6);
  
  (void) gtk_misc_set_alignment(GTK_MISC(people->bd), 0, .5);
  (void) gtk_widget_show(people->bd);

  label = gtk_label_new(_ADD_P_B);
  (void) gtk_table_attach_defaults(GTK_TABLE(people->table),
				   label, 0, 1, 5, 6);
  (void) gtk_misc_set_padding(GTK_MISC(label),3,0);
  (void) gtk_misc_set_alignment(GTK_MISC(label), 0, .5);
  (void) gtk_widget_show(label);

  people->email = gtk_entry_new_with_max_length((guint16) 50);
  (void) gtk_entry_set_editable(GTK_ENTRY(people->email), FALSE);
  (void) gtk_table_attach_defaults(GTK_TABLE(people->table),
				   people->email, 0, 2, 6, 7);
  (void) gtk_tooltips_set_tip(tips, people->email,
	"currently selected person's E-Mail address", NULL);
  (void) gtk_widget_show(people->email);

  (void) gtk_box_pack_start(GTK_BOX(people->main), people->table,
			    FALSE, FALSE, 0);
  (void) gtk_widget_show(people->clist);
  (void) gtk_widget_show(people->ctrls->new);
  (void) gtk_widget_show(people->ctrls->del);
  (void) gtk_widget_show(people->ctrls->edit);
  (void) gtk_widget_show(people->ctrls->main);
  (void) gtk_widget_show(vbox);
  (void) gtk_widget_show(people->table);
  (void) gtk_clist_column_titles_hide(GTK_CLIST(people->clist));
}

void 
ShowPeopleTable()
{
  extern XPeople *people;
  Cf("ShowPeopleTable");
  if (people->main != NULL)
  {
    (void) gtk_widget_show(people->main);
  }
}

static void 
free_row(gpointer data)
{
  Cf("free_row");
  if (data == NULL)
  {
    (void) g_warning("%s %s\n", PROG_NAME, "data == NULL");
    return;
  }
  Del(data);
  data = NULL;
}

static void 
_add_row(GtkWidget * clist, int row, int id)
{
  int *id_data = NULL;
  Cf("_add_row");
  id_data = New(int, 1);
  if ((clist != NULL) && (id_data != NULL))
  {
    *id_data = id;
    (void) gtk_clist_set_row_data_full(GTK_CLIST(clist),
		      row, (gpointer) id_data, (GtkDestroyNotify) free_row);
  }
}

void 
SetupPeopleTable()
{
  extern XPeople *people;
  char date_str[DATE_SIZE];
  extern CONFIG settings;
  PERSON *person = NULL;
  int total = 0;
  char **text;
  int i = 0;
  Cf("SetupPeopleTable");
  (void) gtk_clist_clear(GTK_CLIST(people->clist));
  (void) gtk_signal_handler_block(GTK_OBJECT(people->clist), signal_key);
  
  text = New(char *, 1);
  text[0] = New(char, 51);

  person = SortPeople(settings.person_sort_style, SortAscend, &total);
  if (person != NULL)
  {
    for (i = 0; i < total; i++)
    {
      (void) strcpy(text[0], person[i].title);
      (void) _add_row(people->clist, gtk_clist_append(GTK_CLIST(people->clist),
						      text), person[i].id);
    }
    (void) gtk_label_set(GTK_LABEL(people->nick), person[0].cname);
    for (i = 0; i < 4; i++)
    {
      (void) gtk_entry_set_text(GTK_ENTRY(people->phone[i]), person[0].phones[i]);
    }
    (void) date2str(date_str, person[0].bd);
    (void) gtk_label_set(GTK_LABEL(people->bd), date_str);
    (void) gtk_entry_set_text(GTK_ENTRY(people->email), person[0].email);
  }
  Del(text[0]);
  Del(text);
  Del(person);
  (void) gtk_signal_handler_unblock(GTK_OBJECT(people->clist), signal_key);
}
