/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/xall.h"
#include"../include/x/pictures.h"

static void 
clicked(GtkWidget * widget, GtkWidget * data)
{
  (void) gtk_widget_destroy(data);
}

static void 
Destroy(GtkWidget * widget, GtkWidget * data)
{
  (void) gtk_widget_destroy(data);
}

static gint 
Delete(GtkWidget * widget, GtkWidget * data)
{
  return FALSE;
}

static char *
set_string(int line)
{
  char *string = NULL;
  char *tmp;
  tmp = New(char, 300);
  switch(line)
  {
    case 0:
    { 
      (void) sprintf(tmp, "%s v%s, Copyright � %s %s",
                     PROG_NAME, PROG_VER, PROG_YEAR, PROG_AUTHOR);
      break;
    }
    case 1:
    {
      (void) sprintf(tmp, "%s comes with ABSOLUTELY NO WARRANTY", PROG_NAME);
      break;
    }
    case 2:
    {
      (void) sprintf(tmp,
	    "%s is free software, and you are welcome to redistribute it",
		 PROG_NAME);
      break;
    }
    case 3:
    {
      (void) sprintf(tmp, "under certain conditions.  %s",
		 "Read the file COPYRIGHT.GNU for more details.");
      break;
    }
  }
  string = New(char, strlen(tmp) + 1);
  (void) strcpy(string, tmp);
  Del(tmp);
  return string;
}

void 
aboutbox_create()
{
  /*
     this function will create an about box, with this info.
   */
  GtkWidget *window = NULL;
  GtkWidget *box = NULL;
  GtkWidget *text_box = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *button = NULL;
  GtkWidget *picture=NULL;
  GdkPixmap *pixmap=NULL;
  GdkBitmap *mask=NULL;
  GtkStyle *style=NULL;
  GtkWidget *text_label = NULL;
  char *string = NULL;
  char *filename = NULL;
  extern FILES files;
  
  if(files.home_dir != NULL)
  {
    filename = New(char, strlen(files.home_dir) + strlen(PIM_LOGO_XPM) + 1);
    (void) sprintf(filename, "%s%s", files.home_dir, PIM_LOGO_XPM);
  }

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  (void) gtk_window_set_title(GTK_WINDOW(window), "About: PinfoMan");
  (void) gtk_signal_connect_object(GTK_OBJECT(window), "delete_event",
				   (GtkSignalFunc) Delete,
				   GTK_OBJECT(window));
  (void) gtk_signal_connect(GTK_OBJECT(window), "destroy",
			GTK_SIGNAL_FUNC(Destroy),
			GTK_OBJECT(window));
  (void) gtk_widget_realize(window);
  box = gtk_hbox_new(FALSE, 0);
  vbox = gtk_vbox_new(FALSE, 0);
  text_box = gtk_vbox_new(FALSE, 0);

  style = gtk_widget_get_style(window);
  if(filename != NULL)
  {
    pixmap = gdk_pixmap_create_from_xpm(window->window, &mask,
                                        &style->bg[GTK_STATE_NORMAL],
                                        filename);
    Del(filename);
    picture = gtk_pixmap_new(pixmap, mask);
    (void) gtk_box_pack_start(GTK_BOX(box), picture, FALSE, FALSE, 0);
    (void) gtk_widget_show(picture);
  }
  
  string = set_string(0);
  text_label = gtk_label_new(string);
  Del(string);
  (void) gtk_box_pack_start(GTK_BOX(text_box), text_label, TRUE, FALSE, 0);
  (void) gtk_misc_set_alignment(GTK_MISC(text_label), 0, .5);
  (void) gtk_widget_show(text_label);
  
  string = set_string(1);
  text_label = gtk_label_new(string);
  Del(string);
  (void) gtk_box_pack_start(GTK_BOX(text_box), text_label, TRUE, FALSE, 0);
  (void) gtk_misc_set_alignment(GTK_MISC(text_label), 0, .5);
  (void) gtk_widget_show(text_label);
  
  string = set_string(2);
  text_label = gtk_label_new(string);
  Del(string);
  (void) gtk_box_pack_start(GTK_BOX(text_box), text_label, TRUE, FALSE, 0);
  (void) gtk_misc_set_alignment(GTK_MISC(text_label), 0, .5);
  (void) gtk_widget_show(text_label);
  
  string = set_string(3);
  text_label = gtk_label_new(string);
  Del(string);
  (void) gtk_box_pack_start(GTK_BOX(text_box), text_label, TRUE, FALSE, 0);
  (void) gtk_misc_set_alignment(GTK_MISC(text_label), 0, .5);
  (void) gtk_widget_show(text_label);
  
  (void) gtk_box_pack_start(GTK_BOX(box), text_box, TRUE, TRUE, 5);
  (void) gtk_widget_show(box);
  (void) gtk_box_pack_start(GTK_BOX(vbox), box, TRUE, TRUE, 0);

  button = gtk_button_new_with_label("Close");
  (void) gtk_signal_connect(GTK_OBJECT(button),
			    "clicked",
			    GTK_SIGNAL_FUNC(clicked),
			    GTK_OBJECT(window));
  GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);

  (void) gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);
  (void) gtk_widget_show(button);

  (void) gtk_container_add(GTK_CONTAINER(window), vbox);
  (void) gtk_widget_show(text_box);
  (void) gtk_widget_show(vbox);
  (void) gtk_widget_show(window);
  (void) gtk_widget_grab_default(button);
}
