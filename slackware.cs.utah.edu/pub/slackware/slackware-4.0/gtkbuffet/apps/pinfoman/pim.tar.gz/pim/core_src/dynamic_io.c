/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include<unistd.h>
#include"../include/core.h"

static Boolean _get_total_dynamic_records(char fname[], int *num);
static Boolean _read_Dynamic_header_from_index(char fname[], HEADER * head);
static int _write_Dynamic_record_header(char fname[], HEADER * head);
static int _read_Dynamic_record_header(char fname[], HEADER * head);
static MARK _is_Dynamic_record(char fname[], int id);
static int _DeleteDynamicRecord(char fname[], int id);
static Boolean _ReadDynamicRecord(char fname[], RECORD * record);
static Boolean _AppendDynamicRecord(char fname[], RECORD * data);

Boolean 
NextDynamicRecord(char fname[], int *id)
{
  Cf("NextRecord");
  return GetTotalDynamicRecords(fname, id);
}

Boolean 
ReadDynamicRecord(char fname[], RECORD * record)
{
  Boolean stats = False;
  Cf("ReadDynamicRecord");
  if (record->header.id >= 0)
  {
    if (_ReadDynamicRecord(fname, record) == True)
    {
      stats = True;
    }
    else
    {
      /*
         DO ERROR CHECKING HERE
       */
    }
  }
  return stats;
}

static Boolean 
_ReadDynamicRecord(char fname[], RECORD * record)
{
  Boolean result = False;
  FILE *fptr;
  INDEX *index;
  DFI dfi;
  Cf("_ReadDynamicRecord");
  fptr = fopen(fname, "rb");
  if (fptr != NULL)
  {
    DFIRead(dfi, fptr);
    if (DFITest(dfi) == DFITrue)
    {
      index = New(INDEX, DFIGetTotal(dfi));
      if (read_note_index(index) == True)
      {
	(void) fseek(fptr, index[record->header.id], SEEK_SET);
	(void) fread(&record->header, sizeof(HEADER), 1, fptr);
	record->sptr = New(char, record->header.size);
	(void) fread(record->sptr, record->header.size, 1, fptr);
	result = True;
      }
    }
    (void) fclose(fptr);
  }
  return result;
}

/********************************************************
  Massive update to this function needed, do all testing.
  *******************************************************/
static Boolean 
_AppendDynamicRecord(char fname[], RECORD * data)
{
  INDEX *index;
  INDEX position;
  DFI dfi;
  FILE *fptr;
  Cf("_AppendDynamicRecord");
  fptr = fopen(fname, "r+b");
  (void) DFIRead(dfi, fptr);
  index = New(INDEX, DFIGetTotal(dfi));
  (void) read_note_index(index);
  DFIIncrement(dfi);
  (void) fseek(fptr, 0L, SEEK_SET);
  (void) DFIWrite(dfi, fptr);
  (void) fseek(fptr, 0L, SEEK_END);
  position = ftell(fptr);
  (void) freopen(fname, "ab", fptr);
  (void) fwrite(&data->header, sizeof(HEADER), 1, fptr);
  (void) fwrite(data->sptr, data->header.size, 1, fptr);
  index = Realloc(index, INDEX, DFIGetTotal(dfi));
  index[DFIGetTotal(dfi) - 1] = position;
  (void) write_note_index(index, DFIGetTotal(dfi));
  (void) fclose(fptr);
  return True;
}

Boolean 
AppendDynamicRecord(char fname[], RECORD * record)
{
  Boolean stats = False;
  Cf("AppendDynamicRecord");
  if (_AppendDynamicRecord(fname, record) == True)
  {
    stats = True;
  }
  else
  {
    /*
       DO ERROR CHECKING HERE
     */
  }
  return stats;
}

Boolean 
SetupDynamicFile(char fname[])
{
  Boolean status = False;
  FILE *fptr;
  DFI dfi;
  Cf("SetupFile");
  fptr = fopen(fname, "wb");
  if (fptr == NULL)
  {
    status = False;
  }
  else
  {
    DFISet(dfi, 0, 0);
    if (DFIWrite(dfi, fptr) == 1)
    {
      (void) fclose(fptr);
      status = True;
    }
  }
  if (status == True)
  {
    if (!setup_index_file(fname))
    {
      status = True;
    }
    else
    {
      status = False;
    }
  }
  return status;
}

Boolean 
StartDynamicRecordEdit(char fname[], int id)
{
  Cf("StartDynamicRecordEdit");
  if (IsDynamicRecordReadWrite(fname, id) == True)
  {
    if (SetDynamicRecordLocked(fname, id) == True)
    {
      return True;
    }
  }
  return False;
}

Boolean 
EndDynamicRecordEdit(char fname[], int id)
{
  Cf("EndDynamicRecordEdit");
  if (IsDynamicRecordLocked(fname, id) == True)
  {
    if (SetDynamicRecordReadWrite(fname, id) == True)
    {
      return True;
    }
  }
  return False;
}

static Boolean 
_get_total_dynamic_records(char fname[], int *num)
{
  int status = 0;
  DFI dfi;
  FILE *fptr;
  Cf("_get_total_dynamic_records");
  *num = -1;
  fptr = fopen(fname, "rb");
  if (fptr != NULL)
  {
    status = DFIRead(dfi, fptr);
    if (status == 1)
    {
      (void) fclose(fptr);
      *num = DFIGetTotal(dfi);
      return True;
    }
  }
  return False;
}

Boolean 
GetTotalDynamicRecords(char fname[], int *num)
{
  Cf("GetTotalDynamicRecords");
  if (_get_total_dynamic_records(fname, num) == True)
  {
    return True;
  }
  /*
     do error checking
   */
  return False;
}

Boolean 
IsDynamicRecordIDGood(char fname[], int id)
{
  int total;
  Cf("IsDynamicRecordIDGood");
  if (GetTotalDynamicRecords(fname, &total) == True)
  {
    if ((id < total) && (id >= 0))
    {
      return True;
    }
  }
  return False;
}

Boolean 
ReadDynamicRecordHeader(char fname[], HEADER * head)
{
  /*
     this function is here to allow the program to
     change a records marker, the id will be stored
     in the record header before the the function gets
     it.
   */
  int status = 0;
  Cf("ReadDynamicRecordHeader");
  if (IsDynamicRecordIDGood(fname, head->id) == True)
  {
    status = _read_Dynamic_record_header(fname, head);
  }
  if (!status)
  {
    return True;
  }
  /*
     DO ERROR CHECKING HERE
   */
  return False;
}

Boolean 
WriteDynamicRecordHeader(char fname[], HEADER * head)
{
  /*
     This function is here to allow the program to
     change a records marker
   */
  int status = 0;
  Cf("WriteDynamicRecordHeader");
  if (IsDynamicRecordIDGood(fname, head->id) == True)
  {
    status = _write_Dynamic_record_header(fname, head);
  }
  if (!status)
  {
    return True;
  }
  /*
     Do error checking here
   */
  return False;
}

Boolean 
DeleteDynamicRecord(char fname[], int id)
{
  int start;
  int end;
  Cf("DeleteRecord");
  if (IsDynamicRecordIDGood(fname, id) == True)
  {
    if (IsDynamicRecordReadWrite(fname, id) == True)
    {
      if (GetTotalDynamicRecords(fname, &start) == True)
      {
	if (!_DeleteDynamicRecord(fname, id))
	{
	  if (GetTotalDynamicRecords(fname, &end) == True)
	  {
	    if (start - end == 1)
	    {
	      return True;
	    }
	  }
	}
      }
    }
  }
  return False;
}

static int 
_DeleteDynamicRecord(char fname[], int id)
{
  int status = SAFE;
  FILE *fptr;
  INDEX write_pos;
  INDEX size;
  INDEX read_pos;
  RECORD rec;
  Cf("_DeleteRecord");
  fptr = fopen(fname, "r+b");
  (void) get_pos_in_index(fname, id, &write_pos);
  (void) get_pos_in_index(fname, id + 1, &read_pos);
  size = read_pos - write_pos;
  do
  {
    (void) fseek(fptr, read_pos, SEEK_SET);
    (void) fread(&rec.header, sizeof(HEADER), 1, fptr);
    rec.sptr = New(char, rec.header.size);
    (void) fread(rec.sptr, rec.header.size, 1, fptr);
    read_pos = ftell(fptr);
    (void) fseek(fptr, write_pos, SEEK_SET);
    (void) fwrite(&rec.header, sizeof(HEADER), 1, fptr);
    (void) fwrite(rec.sptr, rec.header.size, 1, fptr);
    write_pos = ftell(fptr);
    (void) set_pos_in_index(fname, id, write_pos);
    Del(rec.sptr);
    id++;
  }
  while (!feof(fptr));
  (void) fclose(fptr);
  SHRINK_FILE(fname, size);
  (void) shrink_index_file_size(fname);
  return status;
}

static MARK 
_is_Dynamic_record(char fname[], int id)
{
  HEADER head;
  Cf("_is_Dynamic_record");
  head.marker = Null;
  if (IsDynamicRecordIDGood(fname, id) == True)
  {
    if (ReadDynamicRecordHeader(fname, &head) == True)
    {
      return head.marker;
    }
  }
  return Null;
}

Boolean 
IsDynamicRecordBlank(char fname[], int id)
{
  Cf("IsDynamicRecordBlank");
  if (_is_Dynamic_record(fname, id) == Blank)
  {
    return True;
  }
  return False;
}

Boolean 
IsDynamicRecordReadWrite(char fname[], int id)
{
  Cf("IsDynamicRecordReadWrite");
  if (_is_Dynamic_record(fname, id) == ReadWrite)
  {
    return True;
  }
  return False;
}

Boolean 
IsDynamicRecordLocked(char fname[], int id)
{
  Cf("IsDynamicRecordLocked");
  if (_is_Dynamic_record(fname, id) == Locked)
  {
    return True;
  }
  return False;
}

static int 
_write_Dynamic_record_header(char fname[], HEADER * head)
{
  /*
     just writes a header back to file
   */
  int status = SAFE;
  FILE *fptr;
  Cf("_write_Dynamic_record_header");
  fptr = fopen(fname, "r+b");
  if (fptr != NULL)
  {
    if (fseek(fptr, head->position, SEEK_SET) != -1)
    {
      if (fwrite(head, sizeof(HEADER), 1, fptr) != 1)
      {
	status = UnableToWriteToFile;
      }
    }
    else
    {
      status = UnableToSeekInFile;
    }
  }
  else
  {
    status = UnableToOpenFile;
  }
  return status;
}

static int 
_read_Dynamic_record_header(char fname[], HEADER * head)
{
  /*
     just reads a header from a file
   */
  int status = True;
  FILE *fptr;
  Cf("_read_Dynamic_record_header");
  if (_read_Dynamic_header_from_index(fname, head) == True)
  {
    fptr = fopen(fname, "r+b");
    if (fptr != NULL)
    {
      if (fseek(fptr, head->position, SEEK_SET) != -1)
      {
	if (fread(head, sizeof(HEADER), 1, fptr) != 1)
	{
	  status = UnableToReadFromFile;
	}
      }
      else
      {
	status = UnableToSeekInFile;
      }
    }
    else
    {
      status = UnableToOpenFile;
    }
  }
  return status;
}

static Boolean 
_read_Dynamic_header_from_index(char fname[], HEADER * head)
{
  Cf("_read_Dynamic_header_from_index");
  if (get_pos_in_index(fname, head->id, &head->position) == 1)
  {
    return True;
  }
  return False;
}

Boolean 
SetDynamicRecordBlank(char fname[], int id)
{
  HEADER head;
  Cf("SetDynamicRecordBlank");
  head.id = id;
  if (ReadDynamicRecordHeader(fname, &head) == True)
  {
    if (_Is_Rec_ReadWrite(head))
    {
      _Set_Rec_Blank(head);
      if (WriteDynamicRecordHeader(fname, &head) == True)
      {
	return True;
      }
    }
  }
  return False;
}

Boolean 
SetDynamicRecordReadWrite(char fname[], int id)
{
  HEADER head;
  Cf("SetDynamicRecordReadWrite");
  head.id = id;
  if (ReadDynamicRecordHeader(fname, &head) == True)
  {
    if (!_Is_Rec_ReadWrite(head))
    {
      _Set_Rec_ReadWrite(head);
      if (WriteDynamicRecordHeader(fname, &head) == True)
      {
	return True;
      }
    }
  }
  return False;
}

Boolean 
SetDynamicRecordLocked(char fname[], int id)
{
  Header head;
  Cf("SetDynamicRecordLocked");
  head.id = id;
  if (ReadDynamicRecordHeader(fname, &head) == True)
  {
    if (head.marker == ReadWrite)
    {
      head.marker = Locked;
      if (WriteDynamicRecordHeader(fname, &head) == True)
      {
	return True;
      }
    }
  }
  return False;
}