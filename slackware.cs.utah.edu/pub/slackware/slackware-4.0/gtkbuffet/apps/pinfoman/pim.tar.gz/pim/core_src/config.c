
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

Boolean 
WriteConfig()
{
  extern FILES files;
  FILE *fptr = NULL;
  extern CONFIG settings;

  Cf("WriteConfig");
  fptr = fopen(files.config_file, "wb");
  if (fptr != NULL)
  {
    if (fwrite(&settings, sizeof(CONFIG), 1, fptr) == 1)
    {
      (void) fclose(fptr);
      return True;
    }
  }
  return False;
}

Boolean 
ReadConfig()
{
  extern FILES files;
  FILE *fptr = NULL;
  extern CONFIG settings;

  Cf("ReadConfig");

  (void) init_config();
  fptr = fopen(files.config_file, "rb");
  if (fptr != NULL)
  {
    if (fread(&settings, sizeof(CONFIG), 1, fptr) == 1)
    {
      (void) fclose(fptr);
      return True;
    }
  }
  return False;
}

void 
SetupConfig()
{
  extern CONFIG settings;
  int i = 0;
  (void) strcpy(settings.username, "");
  settings.datestyle = _ENG_DATE;
  if (settings.firstrun)
  {
    settings.firstrun = 0;
    if (SetupNoteRecordFile() == False)
    {
      (void) error(files.note_file, i);
    }

    i = setup_file(files.appointment_file);
    if (i)
    {
      (void) error(files.appointment_file, i);
    }

    i = setup_file(files.todo_file);
    if (i)
    {
      (void) error(files.todo_file, i);
    }

    i = setup_file(files.link_file);
    if (i)
    {
      (void) error(files.link_file, i);
    }

    i = setup_file(files.person_file);
    if (i)
    {
      (void) error(files.person_file, i);
    }

    i = setup_file(files.business_file);
    if (i)
    {
      (void) error(files.business_file, i);
    }

    i = setup_file(files.project_file);
    if (i)
    {
      (void) error(files.project_file, i);
    }
  }
}
