/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

/************************************
 ************************************
 **                                **
 **  English Words for PinfoMan  **
 **                                **
 ************************************
 ************************************/

/*********************************
 *   Main Program Info Strings   *
 *********************************/
#define PROG_TITLE "PinfoMan: Personal Information Manager"

/********************
 *   Record Names   *
 ********************/
#define _REC_P1 "Person"
#define _REC_P2 "People"
#define _REC_B1 "Business"
#define _REC_B2 "Businesses"
#define _REC_A1 "Appointment"
#define _REC_A2 "Appointments"
#define _REC_T1 "Task"
#define _REC_T2 "Tasks"
#define _REC_N1 "Note"
#define _REC_N2 "Notes"
#define _REC_L1 "Link"
#define _REC_L2 "Links"
#define _REC_PRJ1 "Project"
#define _REC_PRJ2 "Projects"

/*****************************
 *  People related strings   *
 *****************************/
#define _ADD_P_ET "Enter the Records Title"
#define _ADD_P_RT "Record Title"
#define _ADD_P_T "Title"
#define _ADD_P_GN "Given Name"
#define _ADD_P_FN "Family Name"
#define _ADD_P_CN "Prefered Name"
#define _ADD_P_B "Birth Date"
#define _ADD_P_G "Gender"
#define _ADD_P_PHONE1 "Home Phone"
#define _ADD_P_PHONE2 "Fax"
#define _ADD_P_PHONE3 "Mobile Phone"
#define _ADD_P_PHONE4 "Work Phone"
#define _ADD_P_PHONE5 "Other Phone"
#define _ADD_P_SA "Street Address"
#define _ADD_P_CS "City / Suburb"
#define _ADD_P_ST "State"
#define _ADD_P_PC "Post Code"
#define _ADD_P_C "Country"
#define _ADD_P_E "E-Mail Address"
#define _ADD_P_W "Personal Web Page"
#define _ADD_P_SP "Partner"
#define _ADD_P_UP "Update"
#define _ADD_P_CA "Cancel"

/*******************
 *   Month Names   *
 *******************/
#define JAN_NAME "January"
#define FEB_NAME "February"
#define MAR_NAME "March"
#define APR_NAME "April"
#define MAY_NAME "May"
#define JUN_NAME "June"
#define JUL_NAME "July"
#define AUG_NAME "August"
#define SEP_NAME "September"
#define OCT_NAME "October"
#define NOV_NAME "November"
#define DEC_NAME "December"

/*****************
 *   Day Names   *
 *****************/
#define SUNDAY_STR "Sunday"
#define SUNDAY_sSTR "Sun"
#define MONDAY_STR "Monday"
#define MONDAY_sSTR "Mon"
#define TUESDAY_STR "Tuesday"
#define TUESDAY_sSTR "Tue"
#define WEDNESDAY_STR "Wednesday"
#define WEDNESDAY_sSTR "Wed"
#define THURSDAY_STR "Thursday"
#define THURSDAY_sSTR "Thu"
#define FRIDAY_STR "Friday"
#define FRIDAY_sSTR "Fri"
#define SATURDAY_STR "Saturday"
#define SATURDAY_sSTR "Sat"

/********************************
 *   Today, New, Edit, Delete   *
 ********************************/
#define TODAYSTR "Today"
#define NEWSTR "Create"
#define DELSTR "Remove"
#define EDITSTR "Change"

#define GENDER_MALE_STR "Male"
#define GENDER_FEMALE_STR "Female"
#define GENDER_UNKNOWN_STR "Unknown"
#define GENDER_MALE_CAP 'M'
#define GENDER_FEMALE_CAP 'F'
#define GENDER_MALE_NOCAP 'm'
#define GENDER_FEMALE_NOCAP 'f'
