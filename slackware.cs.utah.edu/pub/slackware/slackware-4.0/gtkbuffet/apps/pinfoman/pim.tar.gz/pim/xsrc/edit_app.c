
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/xall.h"

enum
{
  _UPDATED,
  _CANCELED,
  EA_LAST_SIGNAL
};

Boolean do_i_close;
Boolean do_i_cancel;

static void editapp_class_init(EditAppClass *);
static void editapp_init(EditApp *);
static void _send_update(EditApp *);
static void _send_cancel(EditApp *);
static void _update_clicked(GtkWidget *, gpointer);
static void _cancel_clicked(GtkWidget *, gpointer);
static void editapp_get_app(EditApp *);

static gint 
Destroy(GtkWidget * widget, GtkWidget * data)
{
  do_i_close = False;
  if(data == NULL) { return True; }
  (void) _cancel_clicked(widget, data);
  return False;
}

static gint
Delete(GtkWidget * widget, GtkWidget * data)
{
  return False;
}

static unsigned int ea_signals[EA_LAST_SIGNAL] =
{0};

guint 
editapp_get_type()
{
  static guint p_type = 0;
  if (!p_type)
  {
    GtkTypeInfo p_info =
    {
      "EditApp",
      sizeof(EditApp),
      sizeof(EditAppClass),
      (GtkClassInitFunc) editapp_class_init,
      (GtkObjectInitFunc) editapp_init,
      (GtkArgSetFunc) NULL,
      (GtkArgGetFunc) NULL
    };
    p_type = gtk_type_unique(gtk_window_get_type(), &p_info);
  }
  return p_type;
}

static void 
editapp_class_init(EditAppClass * class)
{
  GtkObjectClass *object_class;
  object_class = (GtkObjectClass *) class;
  ea_signals[_UPDATED] = gtk_signal_new("update",
					GTK_RUN_FIRST,
					object_class->type,
					GTK_SIGNAL_OFFSET(EditAppClass,
							  update),
					gtk_signal_default_marshaller,
					GTK_TYPE_NONE, 0);
  ea_signals[_CANCELED] = gtk_signal_new("cancel",
					 GTK_RUN_FIRST,
					 object_class->type,
					 GTK_SIGNAL_OFFSET(EditAppClass,
							   cancel),
					 gtk_signal_default_marshaller,
					 GTK_TYPE_NONE, 0);
  (void) gtk_object_class_add_signals(object_class,
				      ea_signals,
				      EA_LAST_SIGNAL);
  class->update = NULL;
  class->cancel = NULL;
}

GtkWidget *
editapp_new()
{
  do_i_close = True;
  do_i_cancel = True;
  return GTK_WIDGET(gtk_type_new(editapp_get_type()));
}

static void 
_send_update(EditApp * ea)
{
  if(ea == NULL) { return; }
  (void) gtk_signal_emit(GTK_OBJECT(ea), ea_signals[_UPDATED]);
}

static void 
_send_cancel(EditApp * ea)
{
  if(ea == NULL) { return; }
  (void) gtk_signal_emit(GTK_OBJECT(ea), ea_signals[_CANCELED]);
}

GtkWidget *type_list=NULL;

static void
_type(GtkWidget * widget, gpointer data)
{
  char *text=NULL;
  text = (char *) data;
  (void) printf("%s\n", text);
  if(!strcmp(text, "Unlinked"))
  {
    (void) linklist_set(LINKLIST(type_list), Unlinked, NULL);
  }
  if(!strcmp(text, "Person Type"))
  {
    (void) linklist_set(LINKLIST(type_list), PersonType, NULL);
  }
  if(!strcmp(text, "Business Type"))
  {
    (void) linklist_set(LINKLIST(type_list), BusinessType, NULL);
  }
  if(!strcmp(text, "Project Type"))
  {
    (void) linklist_set(LINKLIST(type_list), ProjectType, NULL);
  }
}

static GtkWidget*
create_menu()
{
  GtkWidget *menu=NULL;
  GtkWidget *menuitem=NULL;
  GSList *group=NULL;
  int i = 0;
  char *text[] = {"Unlinked", "Person Type", "Business Type", "Project Type"};
  menu = gtk_menu_new();

  for(i=0;i<4;i++)
  {
    menuitem = gtk_radio_menu_item_new_with_label (group, text[i]);
    group = gtk_radio_menu_item_group (GTK_RADIO_MENU_ITEM (menuitem));
    (void) gtk_signal_connect(GTK_OBJECT(menuitem),
			    "activate",
			    GTK_SIGNAL_FUNC(_type),
			    text[i]);
    gtk_menu_append(GTK_MENU(menu), menuitem);
    gtk_widget_show(menuitem);
  }
  return menu;
}

static void 
editapp_init(EditApp * ea)
{
  GtkWidget *table=NULL;
  GtkWidget *title_box=NULL;
  GtkWidget *type_box=NULL;
  GtkWidget *link_box=NULL;
  GtkWidget *optionmenu=NULL;
  
  GtkWidget *box=NULL;
  GtkWidget *controls=NULL;
  GtkWidget *button=NULL;
  GtkWidget *label=NULL;
  
  (void) gtk_signal_connect_object(GTK_OBJECT(ea), "delete_event",
				   (GtkSignalFunc) Delete,
				   GTK_OBJECT(ea));
  (void) gtk_signal_connect(GTK_OBJECT(ea), "destroy",
			GTK_SIGNAL_FUNC(Destroy),
			GTK_OBJECT(ea));

  table = gtk_table_new(4, 4, FALSE);
  
  ea->appointment = New(APPOINTMENT, 1);

  ea->start = XTimeDisplayNew("Start Time");
  (void) gtk_table_attach_defaults(GTK_TABLE(table),
  		XTimeDisplayGetWin(ea->start), 0, 1, 0, 1);
  XTimeDisplayShow(ea->start);
  
  ea->stop = XTimeDisplayNew("Stop Time");
  (void) gtk_table_attach_defaults(GTK_TABLE(table), 
		  XTimeDisplayGetWin(ea->stop), 1, 2, 0, 1);
  XTimeDisplayShow(ea->stop);
  
  box = gtk_vbox_new(FALSE, 0);
  link_box = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new("Link");
  (void) gtk_box_pack_start(GTK_BOX(link_box), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  
  ea->link = linklist_new();
  (void) gtk_box_pack_start(GTK_BOX(link_box), ea->link, TRUE, TRUE, 5);
  type_list = ea->link;
  (void) gtk_widget_show(ea->link);
  (void) gtk_box_pack_start(GTK_BOX(box), link_box, TRUE, TRUE, 5);
  (void) gtk_widget_show(link_box);
  
  link_box = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new("Link Type");
  (void) gtk_box_pack_start(GTK_BOX(link_box), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  
  optionmenu = gtk_option_menu_new();
  (void) gtk_option_menu_set_menu(GTK_OPTION_MENU(optionmenu), create_menu());
  (void) gtk_box_pack_start(GTK_BOX(link_box), optionmenu, TRUE, TRUE, 0);
  (void) gtk_widget_show(optionmenu);
  
  (void) gtk_box_pack_start(GTK_BOX(box), link_box, TRUE, TRUE, 5);
  (void) gtk_widget_show(link_box);
  
  (void) gtk_table_attach_defaults(GTK_TABLE(table), box, 2, 4, 0, 1);
  (void) gtk_widget_show(box);
  

  title_box = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new("Title");
  (void) gtk_box_pack_start(GTK_BOX(title_box), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ea->title = gtk_entry_new_with_max_length((guint16) 60);
  (void) gtk_box_pack_start(GTK_BOX(title_box), ea->title, TRUE, TRUE, 5);
  (void) gtk_widget_show(ea->title);
  (void) gtk_table_attach_defaults(GTK_TABLE(table), title_box, 0, 4, 1, 2);
  (void) gtk_widget_show(title_box);

  
  type_box= gtk_hbox_new(FALSE, 0);
  /* create types */
  (void) gtk_table_attach_defaults(GTK_TABLE(table), type_box, 0, 4, 2, 3);
  (void) gtk_widget_show(type_box);


  controls = gtk_hbox_new(FALSE, 0);

  button = gtk_button_new_with_label("Ok");
  (void) gtk_signal_connect(GTK_OBJECT(button),
			    "clicked",
			    GTK_SIGNAL_FUNC(_update_clicked),
			    EDITAPP(ea));
  (void) gtk_box_pack_start(GTK_BOX(controls), button, TRUE, TRUE, 0);
  (void) gtk_widget_show(button);

  button = gtk_button_new_with_label("Cancel");
  (void) gtk_signal_connect(GTK_OBJECT(button),
			    "clicked",
			    GTK_SIGNAL_FUNC(_cancel_clicked),
			    EDITAPP(ea));
  (void) gtk_box_pack_start(GTK_BOX(controls), button, TRUE, TRUE, 0);
  (void) gtk_widget_show(button);

  (void) gtk_table_attach_defaults(GTK_TABLE(table), controls, 0, 4, 3, 4);
  (void) gtk_widget_show(controls);
  
  (void) gtk_container_add(GTK_CONTAINER(ea), table);
  (void) gtk_widget_show(table);
}

static void 
_update_clicked(GtkWidget * widget, gpointer data)
{  
  GtkWidget *win=NULL;
  EditApp *ea = NULL;
  ea = (EditApp*) data;
  win = (GtkWidget*) data;
  (void) editapp_get_app(ea);
  if(ea->IsNew == False)
  {
    (void) EndAppointmentEdit(ea->appointment);
    WriteLink(&ea->general_link);
  }
  else
  {
    (void) AddAppointment(ea->appointment);
    ea->general_link.left.id = ea->appointment->id;
    AddLink(&ea->general_link);
  }
  Del(ea->appointment);
  (void) gtk_grab_remove(win);
  (void) _send_update(ea);
  do_i_cancel = False;
  do_i_close = False;
  (void) gtk_widget_destroy(win);
}

static void 
_cancel_clicked(GtkWidget * widget, gpointer data)
{
  GtkWidget *win = NULL;
  EditApp * ea = NULL;
  if(data == NULL) { return; }
  win = (GtkWidget *) data;
  ea = (EditApp *) data;
  if(do_i_cancel == True)
  {
    do_i_cancel = False;
    if (ea->IsNew == False)
    {
      (void) CancelAppointmentEdit(ea->appointment);
    }
    Del(ea->appointment);
    (void) _send_cancel(ea);
  }
  if(do_i_close == True)
  {
    do_i_close = False;
    (void) gtk_grab_remove(win);
    (void) gtk_widget_destroy(win);
  }
}

void 
editapp_type(EditApp * ea, EditOption opt)
{
  switch (opt)
  {
  case EditTypeNew:
    (void) gtk_window_set_title(GTK_WINDOW(ea), "PinfoMan: Add an Appointment");
    ea->IsNew = True;
    break;
  case EditTypeEdit:
    (void) gtk_window_set_title(GTK_WINDOW(ea), "PinfoMan: Edit an Appointment");
    ea->IsNew = False;
    break;
  }
}

void 
editapp_set_app(EditApp * ea, APPOINTMENT * a, Link *link)
{
  if(a != NULL)
  {
    *ea->appointment = *a;
    (void) gtk_entry_set_text(GTK_ENTRY(ea->title), ea->appointment->title);
    XTimeDisplaySetTime(ea->start, &ea->appointment->start);
    XTimeDisplaySetTime(ea->stop, &ea->appointment->stop);
    if(link != NULL)
    {
      ea->general_link = *link;
    }
    /*
     * set up the linked list here
     */
  }
}

static void
editapp_get_app(EditApp * ea)
{
  extern APPS *apps;
  TIME *time=NULL;
  char *text=NULL;
/*  Record *rec = NULL;
  rec = linklist_get(ea);
  ea->linked_item = *rec;
  Del(rec);*/
  (void) init_link(&ea->general_link);
  text = gtk_entry_get_text(GTK_ENTRY(ea->title));
  if(text != NULL)
    (void) strcpy(ea->appointment->title, text);
  time = XTimeDisplayGetTime(ea->start);
  ea->appointment->start = *time;
  Del(time);
  time = XTimeDisplayGetTime(ea->stop);
  ea->appointment->stop = *time;
  Del(time);
  ea->general_link.left.id = ea->appointment->id;
  ea->general_link.left.type = AppointmentType;
  ea->general_link.type = Appointment_Unlinked;
  ea->general_link.date = apps->date_marker;
}

void editapp_set_link(EditApp * ea,Link *lnk)
{
}

Link *editapp_get_link(EditApp * ea)
{
  Link *link=NULL;
  return link;
}