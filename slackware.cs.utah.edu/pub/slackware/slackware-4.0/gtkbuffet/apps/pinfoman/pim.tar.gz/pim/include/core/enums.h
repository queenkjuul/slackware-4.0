typedef enum marks
{
  Blank		= 0,
  Locked	= 1,
  ReadWrite	= 2,
  Null		= 3
} MARK, RecordState;

enum
{
  SPById,
  SPByTitle,
  SPByBd,
  SPByPost,
  SPByFamily,
  /* People Sorting options */
  
  SBById,
  SBBYDate,
  SBByName,
  SBByPost,
  /* Business sorting options */
  
  SPRJById,
  SPRJByDate,
  SPRJByTitle,
  /* Project sorting options */
  
  SAById,
  SAByDate,
  SAByTitle,
  SAByType,
  SAByStartTime,
  SAByStopTime,
  /* Appointment sorting options */
  
  STById,
  STByStartDate,
  STByStopDate,
  STByTitle,
  STByType
  /* Todo sorting options */
};

typedef enum
{
  ASCII_IO_TYPE,
  PINFOMAN_TYPE
} IO_TYPE;

typedef enum
{
  False	= 0,
  True	= 1
} Boolean;

typedef enum
{
  ConfigSetupState	= 0,
  ConfigNormalState	= 1
} ConfigStatus;

typedef enum
{
  PersonType		= 0,
  ProjectType		= 1,
  BusinessType		= 2,
  TodoType		= 3,
  AppointmentType	= 4,
  LinkType		= 5,
  NoteType		= 6,
  TransactionType	= 7,
  Unlinked		= 8
} RecordType;

typedef enum
{
  Project_Note,
  Project_Person,
  Project_Business,

  Person_Note,
  Person_Person,
  Person_Business,

  Business_Note,
  Business_Person,
  Business_Business,

  Appointment_Note,
  Appointment_Person,
  Appointment_Business,
  Appointment_Project,
  Appointment_Unlinked,

  Todo_Note,
  Todo_Person,
  Todo_Business,
  Todo_Project,
  Todo_Unlinked,

  Unlinked_Note,
  /* the Unlinked_Note is for diary entries */
  
  DayTitle,
  LTBlank
} TypeOfLink;

typedef enum
{
  Parent_Child	= 0,
    /* for Person_Person */
  Spouse	= 1,
  
  Contact	= 2,
  /* for Business_Person
    or
     for Business_Business */
  SLTBlank	= 3
} SecondaryLinkType;

typedef enum
{
  DFIFalse,
  DFITrue,
  DFINegTot,
  DFINegLiv,
  DFIMoreLiveThanTotal
} DFIResults;

typedef enum
{
  UnableToOpenFile,
  UnableToCloseFile,
  UnableToReOpenFile,
  UnableToReadFromFile,
  UnableToWriteToFile,
  UnableToReadTotalRecords,
  UnableToWriteTotalRecords,
  UnableToSeekInFile,
  UnableToAppendRecord,
  
  UnableToAllocateMemory,
  BadDateStyle,
  BadMonth,
  StringNotADate
} PinfoManErrors;

typedef enum
{
  SortAscend	= 0,
  SortDescend	= 1
} SortOrder;

enum
{
  BOTH,
  RIGHT,
  LEFT
};

typedef enum
{
  Sunday	= 0,
  Monday	= 1,
  Tuesday	= 2,
  Wednesday	= 3,
  Thursday	= 4,
  Friday	= 5,
  Saturday	= 6
} PinfoManWeekDays;

typedef enum
{
  BAD_MONTH	= 0,
  JAN		= 1,
  FEB		= 2,
  MAR		= 3,
  APR		= 4,
  MAY		= 5,
  JUN		= 6,
  JUL		= 7,
  AUG		= 8,
  SEP		= 9,
  OCT		= 10,
  NOV		= 11,
  DEC		= 12
} PinfoManMonths;

typedef enum
{
  TransF_ADollar	= 0,
  TransF_USDollar	= 1,
  TransF_Pound		= 2,
  TransF_Mark		= 3
} TransactionFormat;

typedef enum
{
  Male		= 0,
  Female	= 1,
  Unknown	= 2
} Gender;
