/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

/***************************************************
 * This file contains all link specific file I/O   *
 ***************************************************/

#include"../include/core.h"

/****************************************************
 * Functions for the new links structure begin here *
 ****************************************************/

Boolean 
RemoveLinksTo(Record rec)
{
  extern FILES files;
  /* The Record has already been removed, and now we are to remove, or NULL all
     links to the record, and update all others.  To do this we must
     *Search for all links to the record, that are on the right hand side, then
     remove these altogether.
     *Search for all links to the record, that are on the left hand side, if any
     are links to notes remove note, update links, then remove link.
     *Update all links of record_type > record_id, on both sides
   */
  Boolean return_value = False;
  int i = 0;
  int num_links = 0;
  Link link;

  (void) total_records(files.link_file, &num_links);

  for (i = 0; i < num_links; i++)
  {
    (void) read_record(files.link_file, &link, sizeof(Link), i);
    if (AreLinksSame(link.right, rec))
    {
      link.marker = Blank;
      (void) write_record(files.link_file, &link, sizeof(Link), i);
    }
  }

  for (i = 0; i < num_links; i++)
  {
    (void) read_record(files.link_file, &link, sizeof(Link), i);
    if (AreLinksSame(link.left, rec))
    {
      link.marker = Blank;
      if (link.right.type == NoteType)
      {
	(void) DeleteNote(link.right.id);
      }
      (void) write_record(files.link_file, &link, sizeof(Link), i);
    }
  }
  return return_value;
}

void 
RemoveLeftLinksTo(Record rec)
{
  extern FILES files;
  Link link;
  Boolean loop = True;
  int records = 0;
  int pos = 0;

  TotalLinks(&records);
  if (records > 0)
  {
    while (loop == True)
    {
      link.id = pos;
      ReadLink(&link);
      if (AreLinksSame(link.right, rec))
      {
	(void) remove_record(files.link_file, sizeof(Link), pos);
      }
      else
      {
	pos++;
      }
      TotalLinks(&records);
      if (pos >= records)
      {
	loop = False;
      }
    }
  }
}

Boolean 
DecrementLinks(Record record)
{
  extern FILES files;
  Link link;
  int records;
  Boolean write = False;
  int errors = False;

  if (TotalLinks(&records) == True)
  {
    for (link.id = 0; link.id < records; link.id++)
    {
      if (errors == True)
      {
	write = False;
	if (ReadLink(&link) == True)
	{
	  if ((link.right.type == record.type) && (link.right.id > record.id))
	  {
	    link.right.id--;
	    write = True;
	  }
	  if ((link.left.type == record.type) && (link.left.id > record.id))
	  {
	    link.left.id--;
	    write = True;
	  }
	  if (write == True)
	  {
	    errors = WriteLink(&link);
	  }
	}
      }
    }
  }
  return errors;
}

Boolean 
NextLinkRecord(int *record)
{
  int records;
  int loop;
  Link data;
  Boolean stats = False;

  *record = -1;
  Cf("NextLinkRecord");
  if (TotalLinks(&records) == True)
  {
    if (records > 0)
    {
      for (loop = 0; loop < records; loop++)
      {
	data.id = loop;
	if (ReadLink(&data) == True)
	{
	  if (StatLink(data) == Blank)
	  {
	    *record = loop;
	    loop = records;
	    stats = True;
	  }
	}
      }
    }
  }
  return stats;
}

Boolean 
AddLink(Link * link)
{
  link->marker = ReadWrite;
  Cf("AddLink");
  link->id = -1;
  if (NextLinkRecord(&link->id) == True)
  {
    if (link->id >= 0)
    {
      return WriteLink(link);
    }
  }
  if (link->id < 0)
  {
    if (TotalLinks(&link->id) == True)
      return AppendLink(link);
  }
  return False;
}

void 
AddLinks(Link * link, Record * left, Record * right, int type, int stype)
{
  Cf("AddLinks");
  CopyRecord(link->left, left);
  CopyRecord(link->right, right);
  link->type = type;
  link->stype = stype;
}

void 
SetLinkDate(Link * link, DATE * d)
{
  Cf("SetLinkDate");
  (void) datecpy(&link->date, d);
}

Boolean 
ReadLink(Link * link)
{
  extern FILES files;
  Cf("ReadLink");
  if (ReadRecord(files.link_file, link, sizeof(Link), link->id) == True)
  {
    return True;
  }
  return False;
}

Boolean 
ReadNormalLink(Link * link)
{
  Link tmp;
  extern FILES files;
  Cf("ReadLink");
  if (ReadRecord(files.link_file, &tmp, sizeof(Link), link->id) == True)
  {
    if((tmp.marker != Blank) && (tmp.marker != Locked))
      {
	*link = tmp;
	return True;
      }
  }
  return False;
}

Boolean 
WriteLink(Link * link)
{
  extern FILES files;
  Cf("WriteLink");
  if (WriteRecord(files.link_file, link, sizeof(Link), link->id) == True)
  {
    return True;
  }
  return False;
}

Boolean 
TotalLinks(int *num)
{
  extern FILES files;
  int records = -1;
  Cf("TotalLinks");
  if (!total_records(files.link_file, &records))
  {
    *num = records;
    return True;
  }
  return False;
}

Boolean 
AppendLink(Link * link)
{
  extern FILES files;
  Cf("AppendLink");
  if (!append_record(files.link_file, link, sizeof(Link)))
  {
    return True;
  }
  return False;
}

int 
DoesLinkExist(int type, int *stype, Record * right, Record * left, DATE * d)
{
  Link l;
  Link tmp;
  Link data;
  int total = 0;
  Cf("DoesLinkExist");
  (void) init_link(&l);
  l.type = type;
  if (right != NULL)
  {
    l.right = *right;
    l.has_right = True;
  }
  if (left != NULL)
  {
    l.left = *left;
    l.has_left = True;
  }
  if (stype != NULL)
  {
    l.stype = *stype;
    l.has_stype = True;
  }
  if (d != NULL)
  {
    (void) datecpy(&l.date, d);
    l.has_date = True;
  }

  if (TotalLinks(&total) == True)
  {
    for (tmp.id = 0; tmp.id < total; tmp.id++)
    {
      if (ReadNormalLink(&tmp) == True)
      {
	if ((tmp.type == l.type) && (tmp.stype == l.stype))
	{
	  if ((l.right.id == tmp.right.id) && (l.right.type == tmp.right.type))
	  {
	    if ((l.left.id == tmp.left.id) && (l.left.type == tmp.left.type))
	    {
	      if(!datecmp(&l.date, &tmp.date))
		{
		  return data.id;
		}
	    }
	  }
	}
      }
    }
  }
  return -1;
}

Link *
GetLink(Record rec, int linktype, int itemtype, int *return_value)
{
  Link link;
  Link *links = NULL;
  int num = -1;
  int loop = -1;
  int found = 0;
  Cf("GetLink");
  *return_value = 0;
  if (TotalLinks(&num) == True)
  {
    if (num > 0)
    {
      for (loop = 0; loop < num; loop++)
      {
	link.id = loop;
	if (ReadNormalLink(&link) == True)
	{
	  if (AreLinksSame(rec, link.left))
	  {
	    if ((link.type == linktype) && (link.right.type == itemtype))
	    {
	      found++;
	      links = Realloc(links, Link, found);
	      links[found - 1] = link;
	    }
	  }
	}
      }
    }
  }
  *return_value = found;
  return links;
}

Boolean 
RemoveLink(Link * link)
{
  Link tmp;
  Cf("RemoveLink");
  tmp.id = link->id;
  if (ReadLink(&tmp) == True)
  {
    if (tmp.marker == ReadWrite)
    {
      tmp.marker = Blank;
      if (WriteLink(&tmp) == True)
      {
	return True;
      }
    }
  }
  return False;
}

Boolean 
DeleteLink(int id)
{
  extern FILES files;
  Link tmp;
  Cf("DeleteLink");
  tmp.id = id;
  if (ReadNormalLink(&tmp) == True)
  {
    tmp.marker = Blank;
    if (WriteLink(&tmp) == True)
      {
	return True;
      }
  }
  return False;
}

Link *
GetLink_DayTitle(DATE *date)
{
  Link *link=NULL;
  Link data;
  int number=0;
  Cf("GetLink_DayTitle");
  if(TotalLinks(&number) == True)
    {
      for(data.id=0;data.id<number;data.id++)
	{
	  if(ReadNormalLink(&data) == True)
	    {
	      if((data.has_string == True) && (data.type == DayTitle))
		{
		  if(data.has_date == True)
		    {
		      if(!datecmp(&data.date, date))
		      {
		        link = New(Link, 1);
		        *link = data;
		        return link;
		      }
		    }
		    else
		    {
		      link = New(Link, 1);
                      *link = data;
		      return link;
		    }
		}
	    }
	}
    }
  return link;
}
