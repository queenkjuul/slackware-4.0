
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/all.h"

void 
search_b()
{
  extern FILES files;
  /*
     char search[40];
     int i = 0;
     int j_val = 0;
     int tmp_val = 0;

     printf("Searching database for a business\n");
     printf("Enter the Businessses name : ");
     fgets(search, sizeof(search), stdin);
     for(j_val=0;j_val<strlen(search);j_val++)
     { if(search[j_val] == '\n'){ search[j_val] = '\0';} }
     j_val = 0;
     for(i=0;i<BDATA_SIZE;i++)
     {
     if(strcmp(BDATA[i].bname, search) ==  0)
     { tmp_val = i; j_val++; }
     }
     if(j_val == 1)
     { disp_business(tmp_val); }
     else
     { printf("%d Businesses Matched this Search.\n", j_val); }
   */
}

int 
select_business(int *bus)
{
  extern FILES files;
  int i = 0;
  int recs = 0;
  i = total_records(files.business_file, &recs);
  *bus = -1;			/* Set Invalid record */
  if (recs > 0)
  {
    if (!disp_b_list())
    {
      printf("Please select a business [-1 to abort] : ");
      *bus = getnum();
    }
  }
  return i;
}

int 
disp_b_list()
{
  extern FILES files;
  int i = 0;
  int j, records;
  BUSINESS bdata;
  i = total_records(files.business_file, &records);
  if (!i)
  {
    if (records > 0)
    {
      for (j = 0; j < records; j++)
      {
	i = read_record(files.business_file, &bdata, sizeof(BUSINESS), j);
	if (!i)
	{
	  printf("%d)\t%s\n", j, bdata.bname);
	}
	else
	{
	  error(files.business_file, i);
	}
      }
    }
  }
  else
  {
    error(files.business_file, i);
  }
  return i;
}

int 
visual_report_on_business()
{
  extern FILES files;
  int i = 0;
  int bus = -1;
  i = select_business(&bus);
  if (!i)
  {
    if (bus > 0)
    {
      i = disp_business(bus);
    }
  }
  else
  {
    error(files.business_file, i);
  }
  return i;
}

int 
disp_business(int pos)
{
  extern FILES files;
  int i = 0;
  BUSINESS bdata;
  i = read_record(files.business_file, &bdata, sizeof(BUSINESS), pos);
  if (!i)
  {
    printf("Displaying business details for %s\n", bdata.bname);
    printf("Business Number\t: %s\n", bdata.cnum);
    printf("Address\t\t: %s\n", bdata.address);
    printf("City/Suburb\t: %s\n", bdata.city);
    printf("State\t\t: %s\n", bdata.state);
    printf("Post Code\t: %s\n", bdata.post);
    printf("Country\t\t: %s\n", bdata.country);
    printf("WWW\t\t: %s\n", bdata.www);
    printf("FTP\t\t: %s\n", bdata.ftp);
  }
  else
  {
    error(files.business_file, i);
  }
  return 0;
}
