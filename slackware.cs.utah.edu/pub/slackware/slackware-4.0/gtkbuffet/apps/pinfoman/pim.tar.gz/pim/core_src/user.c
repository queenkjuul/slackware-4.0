/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include<unistd.h>
#include<pwd.h>
#include"../include/core.h"


int 
check_cmdln(int argc, char *argv[])
{
  int msg = 0;
  Cf("check_cmdln");

  for (argc--; argc >= 0; argc--)
  {
    if (!strcmp(argv[argc], "-v") && !msg)
    {
      (void) disp_lisc();
      (void) exit(0);
    }
    if (!strcmp(argv[argc], "--help") && !msg)
    {
      (void) printf("%s External Help Message\n", PROG_NAME);
      (void) exit(0);
    }
    if (!strcmp(argv[argc], "-s") && !msg)
    {
      (void) printf("Entering Setup Mode\n");
      msg = 1;
    }
  }
  return msg;
}

static void 
_set_string(char new[], char add[], char old[])
{
  (void) strcpy(new, add);
  (void) strcat(new, old);
}

void 
setup_locations()
{
  struct passwd *password;
  extern FILES files;
  int size;
  password = getpwuid(getuid());
  size = strlen(password->pw_dir) + strlen("/.") + strlen(PROG_NAME) + 1;
  files.home_dir = New(char, size);
  (void) strcpy(files.home_dir, password->pw_dir);
  (void) strcat(files.home_dir, "/.");
  (void) strcat(files.home_dir, PROG_NAME);

  files.note_file = New(char, size + strlen(NFILE));
  (void) _set_string(files.note_file, files.home_dir, NFILE);

  files.person_file = New(char, size + strlen(PFILE));
  (void) _set_string(files.person_file, files.home_dir, PFILE);

  files.project_file = New(char, size + strlen(PRJFILE));
  (void) _set_string(files.project_file, files.home_dir, PRJFILE);

  files.business_file = New(char, size + strlen(BFILE));
  (void) _set_string(files.business_file, files.home_dir, BFILE);

  files.appointment_file = New(char, size + strlen(AFILE));
  (void) _set_string(files.appointment_file, files.home_dir, AFILE);

  files.todo_file = New(char, size + strlen(TFILE));
  (void) _set_string(files.todo_file, files.home_dir, TFILE);

  files.link_file = New(char, size + strlen(LFILE));
  (void) _set_string(files.link_file, files.home_dir, LFILE);

  files.config_file = New(char, size + strlen(CFILE));
  (void) _set_string(files.config_file, files.home_dir, CFILE);

  files.errors_file = New(char, size + strlen(EFILE));
  (void) _set_string(files.errors_file, files.home_dir, EFILE);

  files.functions_file = New(char, size + strlen(FUNCS_FILE));
  (void) _set_string(files.functions_file, files.home_dir, FUNCS_FILE);

  files.todo_types_file = New(char, size + strlen(TTFILE));
  (void) _set_string(files.todo_types_file, files.home_dir, TTFILE);

  files.appointment_types_file = New(char, size + strlen(ATFILE));
  (void) _set_string(files.appointment_types_file, files.home_dir, ATFILE);
}

void 
free_locations()
{
  extern FILES files;
  Del(files.note_file);
  Del(files.home_dir);
  Del(files.person_file);
  Del(files.project_file);
  Del(files.business_file);
  Del(files.appointment_file);
  Del(files.todo_file);
  Del(files.link_file);
  Del(files.config_file);
  Del(files.errors_file);
  Del(files.functions_file);
  Del(files.todo_types_file);
  Del(files.appointment_types_file);
}

char *
get_host_name()
{
  char *result = NULL;
  char *name = NULL;
  name = New(char, 100);
  if (!gethostname(name, 100))
  {
    result = New(char, strlen(name) + 1);
    Del(name);
    return result;
  }
  Del(name);
  return name;
}

Boolean 
does_dir_exist()
{
  extern FILES files;
  if (!access(files.home_dir, F_OK | W_OK | R_OK))
  {
    return True;
  }
  return False;
}

Boolean 
do_go_into_setup_mode(int argc, char *argv[])
{
  for (argc--; argc >= 0; argc--)
  {
    if (argv[argc][0] == '-')
    {
      if (!strcmp(argv[argc], "-setup"))
      {
	return True;
      }
    }
  }
  return False;
}
