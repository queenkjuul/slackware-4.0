/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/all.h"
#include<ctype.h>

/***************************************************
 *                Project Section                  *
 ***************************************************/
void 
add_project()
{
  PROJECT data;
  char text[DATE_SIZE];
  (void) cf("add_project");
  printf("Adding a project\n");
  printf("Enter the title for the project : ");
  if (getstr(data.title, sizeof(data.title)))
  {
    do
    {
      printf("Enter the start date for the project : ");
      getstr(text, sizeof(text));
    }
    while (str2date(&data.start, text) > 0);
    do
    {
      printf("Enter the end date for the project : ");
      getstr(text, sizeof(text));
    }
    while (str2date(&data.end, text) > 0);
  }
}

void 
edit_project()
{
  (void) cf("edit_project");
  printf("Edit a project\n");
}

void 
rem_project()
{
  (void) cf("rem_project");
  printf("Remove a project\n");
}

/***************************************************
 *                   Notes Section                 *
 ***************************************************/


void 
add_note()
{
  extern FILES files;
  int return_value = 0;
  int note_rec;
  Link link;
  int tmp;
  int general;
  char string[15];
  char *text;
  int mark = 0;

  (void) cf("add_note");

  (void) init_link(&link);

  printf(_INFO_ADD_NOTE);
  /* Ask user the type of link, person, business, app, todo, NULL
     display a list of the item to link to, or if it is a date, set left to NULL
     get the note from the user, then create the link and note.
     Set the description, and the date to the the currently selected one
   */
  printf("\tSo choose what type of link you want!\n");
  printf("\t*************************************\n");
  printf("\t* 0 Link the note to a person       *\n");
  printf("\t* 1 Link the note to a business     *\n");
  printf("\t* 2 Link the note to an appointment *\n");
  printf("\t* 3 Link the note to a todo         *\n");
  printf("\t* 4 Link the note to a project      *\n");
  printf("\t* 5 Link the note to a date         *\n");
  printf("\t*************************************\n");
  tmp = getnum();
  switch (tmp)
  {
      /***************************************
       * - Person
       ***************************************/
  case (0):
    select_person(&general);
    return_value = total_records(files.person_file, &tmp);
    if (!return_value)
    {
      if ((general >= 0) && (general < tmp))
      {
	link.left.id = general;
	link.left.type = PersonType;
	link.type = Person_Note;
	do
	{
	  printf("Enter a date [31/12/1901]: ");
	  getstr(string, sizeof(string));
	}
	while (str2date(&link.date, string) > 0);
	mark = 1;
      }
    }
    else
    {
      error(files.person_file, return_value);
    }
    break;
      /***********************************
       * - Business
       ***********************************/
  case (1):
    select_business(&general);
    return_value = total_records(files.business_file, &tmp);
    if (!return_value)
    {
      if ((general >= 0) && (general < tmp))
      {
	link.left.id = general;
	link.left.type = BusinessType;
	link.type = Business_Note;
	do
	{
	  printf("Enter a date [31/12/1901]: ");
	  getstr(string, sizeof(string));
	}
	while (str2date(&link.date, string) > 0);
	mark = 1;
      }
    }
    else
    {
      error(files.business_file, return_value);
    }
    break;
      /***********************************
       * - Appointment
       ***********************************/
  case (2):
    select_app(&general);
    return_value = total_records(files.appointment_file, &tmp);
    if (!return_value)
    {
      if ((general >= 0) && (general < tmp))
      {
	link.left.id = general;
	link.left.type = AppointmentType;
	link.type = Appointment_Note;
	do
	{
	  printf("Enter a date [31/12/1901]: ");
	  getstr(string, sizeof(string));
	}
	while (str2date(&link.date, string) > 0);
	mark = 1;
      }
    }
    else
    {
      error(files.appointment_file, return_value);
    }
    break;
      /*******************************
       * - Todo
       *******************************/
  case (3):
    select_todo(&general);
    return_value = total_records(files.todo_file, &tmp);
    if (!return_value)
    {
      if ((general >= 0) && (general < tmp))
      {
	link.left.id = general;
	link.left.type = TodoType;
	link.type = Todo_Note;
	do
	{
	  printf("Enter a date [31/12/1901]: ");
	  getstr(string, sizeof(string));
	}
	while (str2date(&link.date, string) > 0);
	mark = 1;
      }
    }
    else
    {
      error(files.todo_file, return_value);
    }
    break;
      /**********************************
       * - Project
       **********************************/
  case (4):
    select_prj(&general);
    return_value = total_records(files.project_file, &tmp);
    if (!return_value)
    {
      if ((general >= 0) && (general < tmp))
      {
	link.left.id = general;
	link.left.type = ProjectType;
	link.type = Project_Note;
	do
	{
	  printf("Enter a date [31/12/1901]: ");
	  getstr(string, sizeof(string));
	}
	while (str2date(&link.date, string) > 0);
	mark = 1;
      }
    }
    else
    {
      error(files.todo_file, return_value);
    }
    break;
      /******************************
       * - Date
       ******************************/
  case (5):
    link.type = Unlinked_Note;
    do
    {
      printf("Enter a date [31/12/1901]: ");
      getstr(string, sizeof(string));
    }
    while (str2date(&link.date, string) > 0);
    mark = 1;
    break;
  default:
    printf("Bad choice\n");
    break;
  }
  /***********************************
    Start creating the note here.
    **********************************/
  if (mark)
  {
    text = (char *) GetNoteFromUser("Enter the note\n: ");
    if (text != NULL)
    {
      if (AddNote(text, &note_rec) == False)
      {
	error(files.note_file, 0);
      }
      else
      {
	link.right.type = NoteType;
	link.right.id = note_rec;
	return_value = append_record(files.link_file, &link, sizeof(Link));
      }
      Del(text);
    }
  }
}

void 
edit_note()
{
  int id;
  char *the_note;
  (void) cf("edit_note");
  /*
     Get the id of the record you want to edit
     get the link that links to the record
   */
  if (StartNoteEdit(id) == True)
  {
    if (DisplayNote(id) == True)
    {
      the_note = (char *) GetNoteFromUser("Enter the new note\n: ");
      if (the_note != NULL)
      {
	if (DeleteNote(id) == True)
	{
	  if (AddNote(the_note, &id) == True)
	  {
	    /*
	       update the link to the new id
	       then write the link
	     */
	  }
	}
	Del(the_note);
      }
    }
    EndNoteEdit(id);
  }
}

void 
rem_note()
{
  (void) cf("rem_note");
  (void) printf("Removing a Note from the database\n");
}


/***************************************************
 *             Appointments Section                *
 ***************************************************/

void 
add_app()
{
  (void) cf("add_app");
  printf("Adding an appointment\n");
}

void 
edit_app()
{
  (void) cf("edit_app");
  printf("Editing an appointment\n");
}

void 
rem_app()
{
  (void) cf("rem_app");
  printf("Removing an appointment\n");
}

/***************************************************
 *                Todos Section                    *
 ***************************************************/

void 
add_todo()
{
  (void) cf("add_todo");
  printf("Add a TODO to the database\n");
  /*
     allow a person / business to be linked

   */
}

void 
edit_todo()
{
  (void) cf("edit_todo");
  printf("Edit a TODO in the database\n");
}

void 
rem_todo()
{
  (void) cf("rem_todo");
  printf("Remove a TODO from the database\n");
}

/***************************************************
 *                People Section                   *
 ***************************************************/

void 
add_person()
{
  int tmp;
  char temp[12];
  PERSON pdata;

  (void) cf("add_person");

  init_person(&pdata);
  do
  {
    printf("%s : ", _ADD_P_ET);
    getstr(pdata.title, sizeof(pdata.title));

    printf("%s : ", _ADD_P_GN);
    getstr(pdata.fname, sizeof(pdata.fname));

    printf("%s : ", _ADD_P_FN);
    getstr(pdata.lname, sizeof(pdata.lname));

    printf("%s : ", _ADD_P_CN);
    getstr(pdata.cname, sizeof(pdata.cname));

    do
    {
      printf("%s : ", _ADD_P_B);
      getstr(temp, sizeof(temp));
    }
    while (str2date(&pdata.bd, temp) > 0);

    printf("%s : ", _ADD_P_G);
    getstr(temp, sizeof(temp));
    pdata.gender = str2Gender(temp);

    printf("%s : ", _ADD_P_PHONE1);
    getstr(pdata.phones[0], sizeof(pdata.phones[0]));

    printf("%s : ", _ADD_P_PHONE2);
    getstr(pdata.phones[1], sizeof(pdata.phones[1]));

    printf("%s : ", _ADD_P_PHONE3);
    getstr(pdata.phones[2], sizeof(pdata.phones[2]));

    printf("%s : ", _ADD_P_PHONE4);
    getstr(pdata.phones[3], sizeof(pdata.phones[3]));

    printf("%s : ", _ADD_P_PHONE5);
    getstr(pdata.phones[4], sizeof(pdata.phones[4]));

    printf("%s : ", _ADD_P_SA);
    getstr(pdata.address, sizeof(pdata.address));

    printf("%s : ", _ADD_P_CS);
    getstr(pdata.city, sizeof(pdata.city));

    printf("%s : ", _ADD_P_ST);
    getstr(pdata.state, sizeof(pdata.state));

    printf("%s : ", _ADD_P_PC);
    getstr(pdata.post, sizeof(pdata.post));

    printf("%s : ", _ADD_P_C);
    getstr(pdata.country, sizeof(pdata.country));

    printf("%s : ", _ADD_P_E);
    getstr(pdata.email, sizeof(pdata.email));
    for (tmp = 0; tmp < strlen(pdata.email); tmp++)
    {
      pdata.email[tmp] = tolower(pdata.email[tmp]);
    }

    printf("%s : ", _ADD_P_W);
    getstr(pdata.www, sizeof(pdata.www));

    printf(_QUEST_CORRECT);
    getstr(temp, 3);
  }
  while ((temp[0] == 'N') || (temp[0] == 'n'));
  if (temp[0] != 'A')
  {
    if (AddPerson(&pdata) == True)
    {
      printf(_INFO_P_ADDED, pdata.title);
    }
    else
    {
      printf(_INFO_P_NADDED, pdata.title);
    }
  }
}

void 
edit_person()
{
  extern FILES files;
  int i = 0;
  int j = 0;
  PERSON pdata;
  char temp[60];
  char *text=NULL;

  (void) cf("edit_person");
  if (TotalPersonRecords(&j) == True)
  {
    select_person(&pdata.id);
    if (StartPersonEdit(&pdata) == True)
    {
      do
      {
	printf("0)\t%s\t\t\t: %s\n", _ADD_P_T, pdata.title);
	printf("1)\t%s\t\t: %s\n", _ADD_P_GN, pdata.fname);
	printf("2)\t%s\t\t: %s\n", _ADD_P_FN, pdata.lname);
	printf("3)\t%s\t\t: %s\n", _ADD_P_CN, pdata.cname);
	text = Gender2str(pdata.gender);
	printf("4)\t%s\t\t\t: %s\n", _ADD_P_G, text);
	Del(text);
	date2str(temp, pdata.bd);
	printf("5)\t%s\t\t: %s\n", _ADD_P_B, temp);
	printf("6)\t%s\t\t: %s\n", _ADD_P_PHONE1, pdata.phones[0]);
	printf("7)\t%s\t\t\t: %s\n", _ADD_P_PHONE2, pdata.phones[1]);
	printf("8)\t%s\t\t: %s\n", _ADD_P_PHONE3, pdata.phones[2]);
	printf("9)\t%s\t\t: %s\n", _ADD_P_PHONE4, pdata.phones[3]);
	printf("10)\t%s\t\t: %s\n", _ADD_P_PHONE5, pdata.phones[4]);
	printf("11)\t%s\t\t: %s\n", _ADD_P_E, pdata.email);
	printf("12)\t%s\t\t: %s\n", _ADD_P_SA, pdata.address);
	printf("13)\t%s\t\t: %s\n", _ADD_P_CS, pdata.city);
	printf("14)\t%s\t\t\t: %s\n", _ADD_P_ST, pdata.state);
	printf("15)\t%s\t\t: %s\n", _ADD_P_PC, pdata.post);
	printf("16)\t%s\t\t\t: %s\n", _ADD_P_C, pdata.country);
	printf("17)\t%s\t: %s\n", _ADD_P_W, pdata.www);
	printf(_QUEST_FIELDCHANGE);
	fgets(temp, sizeof(temp), stdin);
	i = atoi(temp);
	switch (i)
	{
	case (0):
	  printf("%s Title\t: %s\n", _INFO_ORIG, pdata.title);
	  printf("New Title\t: ");
	  getstr(pdata.title, sizeof(pdata.title));
	  break;
	case (1):
	  printf("%s given name\t: %s\n", _INFO_ORIG, pdata.fname);
	  printf("New given name\t: ");
	  getstr(pdata.fname, sizeof(pdata.fname));
	  break;
	case (2):
	  printf("%s family name\t: %s\n", _INFO_ORIG, pdata.lname);
	  printf("New family name\t: ");
	  getstr(pdata.lname, sizeof(pdata.lname));
	  break;
	case (3):
	  printf("%s casual name\t: %s\n", _INFO_ORIG, pdata.cname);
	  printf("New casual name\t: ");
	  getstr(pdata.cname, sizeof(pdata.cname));
	  break;
	case (4):
	  text = Gender2str(pdata.gender);
	  printf("%s gender\t: %s\n", _INFO_ORIG, text);
	  Del(text);
	  printf("New gender\t: ");
	  getstr(temp, sizeof(temp));
	  pdata.gender = str2Gender(temp);
	  break;
	case (5):
	  date2str(temp, pdata.bd);
	  printf("%s birthday\t: %s\n", _INFO_ORIG, temp);
	  do
	  {
	    printf("New birthday\t: ");
	    getstr(temp, sizeof(temp));
	  }
	  while (str2date(&pdata.bd, temp) > 0);
	  break;
	case (6):
	  printf("%s home phone\t: %s\n", _INFO_ORIG, pdata.phones[0]);
	  printf("New home phone\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.phones[0], temp);
	  break;
	case (7):
	  printf("%s fax\t: %s\n", _INFO_ORIG, pdata.phones[1]);
	  printf("New fax\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.phones[1], temp);
	  break;
	case (8):
	  printf("%s mobile phone\t: %s\n", _INFO_ORIG, pdata.phones[2]);
	  printf("New mobile phone\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.phones[2], temp);
	  break;
	case (9):
	  printf("%s work phone\t: %s\n", _INFO_ORIG, pdata.phones[3]);
	  printf("New work phone\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.phones[3], temp);
	  break;
	case (10):
	  printf("%s other phone\t: %s\n", _INFO_ORIG, pdata.phones[4]);
	  printf("New other phone\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.phones[4], temp);
	  break;
	case (11):
	  printf("%s e-mail\t: %s\n", _INFO_ORIG, pdata.email);
	  printf("New e-mail\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.email, temp);
	  break;
	case (12):
	  printf("%s address\t: %s\n", _INFO_ORIG, pdata.address);
	  printf("New address\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.address, temp);
	  break;
	case (13):
	  printf("%s city/suburb\t: %s\n", _INFO_ORIG, pdata.city);
	  printf("New city/suburb\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.city, temp);
	  break;
	case (14):
	  printf("%s state\t: %s\n", _INFO_ORIG, pdata.state);
	  printf("New state\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.state, temp);
	  break;
	case (15):
	  printf("Original post code\t: %s\n", pdata.post);
	  printf("New post code\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.post, temp);
	  break;
	case (16):
	  printf("%s country\t: %s\n", _INFO_ORIG, pdata.country);
	  printf("New country\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.country, temp);
	  break;
	case (17):
	  printf("%s www\t: %s\n", _INFO_ORIG, pdata.www);
	  printf("New www\t: ");
	  getstr(temp, sizeof(temp));
	  strcpy(pdata.www, temp);
	  break;
	}
      }
      while (i != -1);
    }
    EndPersonEdit(&pdata);
  }
}

void 
rem_person()
{
  extern FILES files;
  char string[3];
  int j;
  PERSON pdata;

  (void) cf("rem_person");

  if (TotalPersonRecords(&j) == True)
  {
    printf("Please select a person to remove:\n");
    select_person(&pdata.id);
    if ((GetPersonID(&pdata) >= 0) && (GetPersonID(&pdata) < j))
    {
      ReadPersonRecord(&pdata);
      if (IsPersonReadWrite(&pdata) == True)
      {
	printf("Are you sure you want to remove %s\t? ", pdata.title);
	getstr(string, sizeof(string));
	if ((string[0] == 'y') || (string[0] == 'Y'))
	{
	  if (DeletePersonRecord(pdata.id) == True)
	  {
	    (void) printf("The person has been removed, and all links updated\n");
	  }
	}
      }
      else
      {
	printf("PinfoMan: Record is locked\n");
      }
    }
  }
}

/***************************************************
 *               Business Section                  *
 ***************************************************/

void 
add_business()
{
  extern FILES files;
  char temp[6];
  int i = 0;
  BUSINESS bdata;

  (void) cf("add_business");

  do
  {
    printf("Enter the Businesses Name : ");
    getstr(bdata.bname, sizeof(bdata.bname));

    printf("Enter the businesses registration number : ");
    getstr(bdata.cnum, sizeof(bdata.cnum));

    printf("Businesses Address : ");
    getstr(bdata.address, sizeof(bdata.address));

    printf("City / Suburb : ");
    getstr(bdata.city, sizeof(bdata.city));

    printf("State : ");
    getstr(bdata.state, sizeof(bdata.state));

    printf("Post Code : ");
    getstr(bdata.post, sizeof(bdata.post));

    printf("Country : ");
    getstr(bdata.country, sizeof(bdata.country));

    printf("WWW Site : ");
    getstr(bdata.www, sizeof(bdata.www));

    printf("FTP Site : ");
    getstr(bdata.ftp, sizeof(bdata.ftp));

    printf("Are you sure the above details are correct [Y/N/A] : ");
    getstr(temp, sizeof(temp));
  }
  while ((temp[0] == 'N') || (temp[0] == 'n'));
  if ((temp[0] != 'A') || (temp[0] == 'a'))
  {
    i = append_record(files.business_file, &bdata, sizeof(BUSINESS));
    if (!i)
    {
      printf("%s has been added to the database\n", bdata.bname);
    }
    else
    {
      error(files.business_file, i);
    }
  }
}

void 
edit_business()
{
  extern FILES files;
  int business;
  int i = 0;
  int j = 0;
  BUSINESS bdata;
  int errors;
  char temp[100];

  (void) cf("edit_business");

  total_records(files.business_file, &j);
  if (j > 0)
  {
    select_business(&business);
    errors = read_record(files.business_file, &bdata, sizeof(BUSINESS), business);
    if (!errors)
    {
      do
      {
	printf("0)\tBusiness Name\t: %s\n", bdata.bname);
	printf("1)\tBusiness Number\t: %s\n", bdata.cnum);
	printf("2)\tAddress\t\t: %s\n", bdata.address);
	printf("3)\tCity/Suburb\t: %s\n", bdata.city);
	printf("4)\tState\t\t: %s\n", bdata.state);
	printf("5)\tPost Code\t: %s\n", bdata.post);
	printf("6)\tCountry\t\t: %s\n", bdata.country);
	printf("7)\tWWW\t\t: %s\n", bdata.www);
	printf("8)\tFTP\t\t: %s\n", bdata.ftp);
	printf("Which field would you like to change [-1 to end changes] : ");
	getstr(temp, sizeof(temp));
	i = atoi(temp);
	switch (i)
	{
	case 0:
	  printf("You Picked Fieled %d\n", i);
	  break;
	case 1:
	  printf("You Picked Fieled %d\n", i);
	  break;
	case 2:
	  printf("You Picked Fieled %d\n", i);
	  break;
	case 3:
	  printf("You Picked Fieled %d\n", i);
	  break;
	case 4:
	  printf("You Picked Fieled %d\n", i);
	  break;
	case 5:
	  printf("You Picked Fieled %d\n", i);
	  break;
	case 6:
	  printf("You Picked Fieled %d\n", i);
	  break;
	case 7:
	  printf("You Picked Fieled %d\n", i);
	  break;
	case 8:
	  printf("You Picked Fieled %d\n", i);
	  break;
	}
      }
      while (i != -1);
    }
    else
    {
      error(files.business_file, errors);
    }
  }
}

void 
rem_business()
{
  extern FILES files;
  int test;
  char string[2];
  int j;
  BUSINESS bdata;
  Record rec;

  (void) cf("rem_business");

  total_records(files.business_file, &j);
  if (j > 0)
  {
    printf("Please select a business to remove:\n");
    select_business(&test);
    if ((test >= 0) && (test < j))
    {
      read_record(files.business_file, &bdata, sizeof(BUSINESS), test);
      printf("Are you sure you want to remove \"%s\"? ", bdata.bname);
      getstr(string, sizeof(string));
      if ((string[0] == 'y') || (string[0] == 'Y'))
      {
	remove_record(files.business_file, sizeof(BUSINESS), test);
	rec.id = test;
	rec.type = BusinessType;
	(void) RemoveLinksTo(rec);
	/*
	   Change these last two functions 
	 */
	printf("The business has been removed, and all links updated\n");
      }
    }
  }
}


/******************************************************
 *
 *                    Links Section
 *
 ******************************************************/

void 
add_link(int type, int pos)
{
  extern FILES files;
  int person_link_menu_size = 6;
  char *person_link_menu[] =
  {
    "*******************************",
    "*                             *",
    "*  0 - Link to Another Person *",
    "*  1 - Link to a Note         *",
    "*                             *",
    "*******************************"};

  int business_link_menu_size = 7;
  char *business_link_menu[] =
  {
    "**************************************",
    "*                                    *",
    "* 0 - Link to a Person as a contact  *",
    "* 1 - Link to a Business contact     *",
    "* 2 - Link to a Note                 *",
    "*                                    *",
    "**************************************"};
  /*
     int project_link_menu_size = 7;
     char *project_link_menu[] = {
     "**************************************",
     "*                                    *",
     "* 0 - Add a Person                   *",
     "* 1 - Add a Business                 *",
     "* 2 - Add a Note                     *",
     "*                                    *",
     "**************************************"};
   */
  switch (type)
  {
  case PersonType:
    DisplayMenu(person_link_menu, person_link_menu_size);
    break;
  case BusinessType:
    DisplayMenu(business_link_menu, business_link_menu_size);
    break;
  case ProjectType:
    break;
  case AppointmentType:
    break;
  case TodoType:
    break;
  default:
    printf(_ERR_FNC_AL);
  }
}

void 
rem_link()
{
  extern FILES files;
}
