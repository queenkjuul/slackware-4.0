/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */


#define _Set_Rec_Blank(X) X.marker = Blank
#define _Set_Rec_ReadWrite(X) X.marker = ReadWrite
#define _Set_Rec_Locked(X) X.marker = Locked

#define _Set_Rec_p_Blank(X) X->marker = Blank
#define _Set_Rec_p_ReadWrite(X) X->marker = ReadWrite
#define _Set_Rec_p_Locked(X) X->marker = Locked

#define _Is_Rec_Blank(X) X.marker == Blank
#define _Is_Rec_ReadWrite(X) X.marker == ReadWrite
#define _Is_Rec_Locked(X) X.marker == Locked

#define _Is_Rec_p_Blank(X) X->marker == Blank
#define _Is_Rec_p_ReadWrite(X) X->marker == ReadWrite
#define _Is_Rec_p_Locked(X) X->marker == Locked

#define SHRINK_FILE(F, S) truncate(F, S)

#define InitRecord(X) X.header.marker = ReadWrite; X.header.size = -1; X.header.id = -1
#define InitRecordWithID(X, Y) X.header.marker = ReadWrite; X.header.size = -1; X.header.id = Y
#define InitpRecord(X) X->header.marker = ReadWrite; X->header.size = -1; X->header.id = -1
#define InitpRecordWithID(X, Y) X->header.marker = ReadWrite; X->header.size = -1; X->header.id = Y

/* quick memory stuff */
#define New(Type, Num) (Type *) malloc(sizeof(Type) * (Num))
#define Realloc(Var, Type, Num) (Type *) realloc(Var, sizeof(Type) * (Num))
#define Del(Var) if(Var!=NULL) { (void) free(Var); } Var = NULL

/* Date stuff */
#define IncrementYear(X) X.y++
#define DecrementYear(X) X.y--
#define IncrementpYear(X) X->y++
#define DecrementpYear(X) X->y--
#define IsLeapYear(D) (((!(d->y % 4)) && ((d->y % 100) !=0)) || (!(d->y %400)))?True:False
#define YearToDays(Y) Y * 365L + (Y / 4L) - (Y / 100) + (Y / 400)

#define DFITest(X) _test_dfi(&X)
#define DFIpTest(X) _test_dfi(X)
#define DFISet(X, Y, Z) X.live_records = Z; X.total_records = Y
#define DFIIncrement(X) X.live_records++; X.total_records++
#define DFIDecrementTotal(X) X.total_records--
#define DFIDecrementLive(X) X.live_records--
#define DFIWrite(X, Y) fwrite(&X, sizeof(DFI), 1, Y)
#define DFIRead(X, Y) fread(&X, sizeof(DFI), 1, Y)
#define DFIpWrite(X, Y) fwrite(X, sizeof(DFI), 1, Y)
#define DFIpRead(X, Y) fread(X, sizeof(DFI), 1, Y)
#define DFIGetTotal(X) X.total_records
#define DFIGetLive(X) X.live_records
#define DFIpGetTotal(X) X->total_records
#define DFIpGetLive(X) X->live_records

#define CopyRecord(X, Y) X.id = Y->id; X.type = Y->type
#define StatLink(X) RecordStats(X)
#define StatpLink(X) RecordpStats(X)
#define AreLinksSame(X, Y) (X.type == Y.type) && (X.id == Y.id)


#define RecordStats(X) X.marker
#define RecordpStats(X) X->marker
#define SetRecordStats(X, Y) X.marker = Y
#define SetpRecordStats(X, Y) X->marker = Y

#define Cf(Str)				(void) cf(Str)
#define Cfx(Str, Int)			(void) cfx(Str, Int)

#define SetRecord(Rec, Id, Type)	Rec.id = Id; Rec.type = Type
