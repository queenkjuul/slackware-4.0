/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */
/************************************
 ************************************
 **                                **
 **  Esperanto Words for PinfoMan  **
 **                                **
 ************************************
 ************************************/

/*********************************
 *   Main Program Info Strings   *
 *********************************/
#define PROG_TITLE "PinfoMan: Personal informajxo direktor"

/********************
 *   Record Names   *
 ********************/
#define _REC_P1 "Homo"
#define _REC_P2 "Homoj"
#define _REC_B1 "Firmo"
#define _REC_B2 "Firmoj"
#define _REC_A1 "Rendevuo"
#define _REC_A2 "Rendevuoj"
#define _REC_T1 "Tasko"
#define _REC_T2 "Taskoj"
#define _REC_N1 "Note"
#define _REC_N2 "Notes"
#define _REC_L1 "Link"
#define _REC_L2 "Links"
#define _REC_PRJ1 "Projekto"
#define _REC_PRJ2 "Projektoj"

/*****************************
 *  People related strings   *
 *****************************/
#define _ADD_P_ET "Enter the Records Title"
#define _ADD_P_RT "Record Title"
#define _ADD_P_T "Title"
#define _ADD_P_GN "Given nomo"
#define _ADD_P_FN "Family nomo"
#define _ADD_P_CN "Prefered nomo"
#define _ADD_P_B "Naskigxtago"
#define _ADD_P_G "Gender"
#define _ADD_P_PHONE1 "Hejmo telefon"
#define _ADD_P_PHONE2 "Fax"
#define _ADD_P_PHONE3 "Mobile telefon"
#define _ADD_P_PHONE4 "laborejo telefon"
#define _ADD_P_PHONE5 "Other telefon"
#define _ADD_P_SA "strat adres"
#define _ADD_P_CS "urbo / Suburb"
#define _ADD_P_ST "State"
#define _ADD_P_PC "posxt Code"
#define _ADD_P_C "Country"
#define _ADD_P_E "E-Mail adres"
#define _ADD_P_W "Personal Web Page"
#define _ADD_P_SP "Partner"
#define _ADD_P_UP "Update"
#define _ADD_P_CA "Cancel"

/*******************
 *   Month Names   *
 *******************/
#define JAN_NAME "januaro"
#define FEB_NAME "februaro"
#define MAR_NAME "marto"
#define APR_NAME "aprilo"
#define MAY_NAME "majo"
#define JUN_NAME "junio"
#define JUL_NAME "julio"
#define AUG_NAME "auxgusto"
#define SEP_NAME "sepembro"
#define OCT_NAME "oktobro"
#define NOV_NAME "novembro"
#define DEC_NAME "decembro"

/*****************
 *   Day Names   *
 *****************/
#define SUNDAY_STR "dimancxo"
#define SUNDAY_sSTR "dim"
#define MONDAY_STR "lundo"
#define MONDAY_sSTR "lun"
#define TUESDAY_STR "mardo"
#define TUESDAY_sSTR "mar"
#define WEDNESDAY_STR "merkredo"
#define WEDNESDAY_sSTR "mer"
#define THURSDAY_STR "jxauxdo"
#define THURSDAY_sSTR "jau"
#define FRIDAY_STR "vendredo"
#define FRIDAY_sSTR "ven"
#define SATURDAY_STR "sabato"
#define SATURDAY_sSTR "sab"

/********************************
 *   Today, New, Edit, Delete   *
 ********************************/
#define TODAYSTR "Hodiaux" /* "aktual" */
#define NEWSTR "Krei"
#define DELSTR "Forigi"
#define EDITSTR "ali"

/**********************
 *    Gender stuff    *
 **********************/
#define GENDER_MALE_STR "Male"
#define GENDER_FEMALE_STR "Female"
#define GENDER_UNKNOWN_STR "Unknown"
#define GENDER_MALE_CAP 'M'
#define GENDER_FEMALE_CAP 'F'
#define GENDER_MALE_NOCAP 'm'
#define GENDER_FEMALE_NOCAP 'f'
