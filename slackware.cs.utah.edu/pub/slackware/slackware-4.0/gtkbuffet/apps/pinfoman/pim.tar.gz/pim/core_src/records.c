/*
   PinfoMan: Personal Information Manager
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"
#include<unistd.h>

Boolean 
ReadRecord(char fname[], void *data, int rec_size, int rec)
{
  FILE *fptr = NULL;
  Cf("ReadRecord");
  if ((fptr = fopen(fname, "rb")) != NULL)
  {
    if (fseek(fptr, (rec_size * rec) + sizeof(DFI), SEEK_SET) == 0)
    {
      if (fread(data, rec_size, 1, fptr) == 1)
      {
	if (fclose(fptr) == 0)
	{
	  return True;
	}
      }
    }
  }
  return False;
}

int 
read_record(char fname[], void *data, int rec_size, int rec)
{
  FILE *fptr;
  int return_value = 0;

  Cf("read_record");
  if ((fptr = fopen(fname, "rb")) == NULL)
  {
    return_value = 1;
  }
  else
  {
    if (fseek(fptr, (rec_size * rec) + sizeof(DFI), SEEK_SET) != 0)
    {
      return_value = 2;
    }
    else if (fread(data, rec_size, 1, fptr) != 1)
    {
      return_value = 3;
    }
    else if (fclose(fptr) != 0)
    {
      return_value = 9;
    }
  }
  return return_value;
}


Boolean 
WriteRecord(char fname[], void *data, int rec_size, int rec)
{
  FILE *fptr;
  Boolean test = False;
  Cf("WriteRecord");

  if ((fptr = fopen(fname, "r+b")) != NULL)
  {
    if (fseek(fptr, (rec_size * rec) + sizeof(DFI), SEEK_SET) == 0)
    {
      if (fwrite(data, rec_size, 1, fptr) == 1)
      {
	if (fclose(fptr) == 0)
	{
	  test = True;
	}
      }
    }
  }
  if (test == False)
  {
    (void) perror(PROG_NAME);
  }
  return test;
}

int 
write_record(char fname[], void *data, int rec_size, int rec)
{
  FILE *fptr;
  int return_value = 0;

  (void) cf("write_record");

  if ((fptr = fopen(fname, "r+b")) == NULL)
  {
    return_value = 1;
  }
  else
  {
    if (fseek(fptr, (rec_size * rec) + sizeof(DFI), SEEK_SET) != 0)
    {
      (void) perror("PinfoMan");
      return_value = 2;
    }
    else if (fwrite(data, rec_size, 1, fptr) != 1)
    {
      (void) perror("PinfoMan");
      return_value = 4;
    }
    else if (fclose(fptr) != 0)
    {
      return_value = 9;
    }
  }
  return return_value;
}

int 
append_record(char fname[], void *data, int rec_size)
{
  int return_value = 0;
  DFI rec;
  FILE *fptr;

  (void) cf("append_record");

  if ((fptr = fopen(fname, "ab")) == NULL)
  {
    return_value = 1;
  }
  else
  {
    if (fwrite(data, rec_size, 1, fptr) != 1)
    {
      return_value = 10;
    }
    else
    {
      if ((fptr = freopen(fname, "r+b", fptr)) == NULL)
      {
	return_value = 5;
      }
      else
      {
	if (fseek(fptr, 0L, SEEK_SET) != 0)
	{
	  return_value = 6;
	}
	else if (DFIRead(rec, fptr) != 1)
	{
	  return_value = 7;
	}
	else
	{
	  DFIIncrement(rec);
	  if (fseek(fptr, 0L, SEEK_SET) != 0)
	  {
	    return_value = 6;
	  }
	  else if (DFIWrite(rec, fptr) != 1)
	  {
	    return_value = 8;
	  }
	}
      }
    }
    if (fclose(fptr) != 0)
    {
      return_value = 9;
    }
  }
  return return_value;
}

int 
setup_file(char fname[])
{
  int return_value = 0;
  FILE *fptr;
  DFI rec;

  Cf("setup_file");

  DFISet(rec, 0, 0);
  if ((fptr = fopen(fname, "wb")) == NULL)
  {
    return_value = 1;
  }
  else
  {
    if (DFIWrite(rec, fptr) != 1)
    {
      return_value = 8;
    }
    else if (fclose(fptr) != 0)
    {
      return_value = 9;
    }
  }
  return return_value;
}

int 
total_records(char fname[], int *rec)
{
  int return_value = 0;
  FILE *fptr = NULL;
  DFI data;
  Cf("total_records");

  *rec = 0;
  if ((fptr = fopen(fname, "rb")) == NULL)
  {
    return_value = 1;
  }
  else
  {
    if (DFIRead(data, fptr) != 1)
    {
      return_value = 7;
    }
    if (fclose(fptr) != 0)
    {
      return_value = 9;
    }
    if (return_value == 0)
    {
      *rec = DFIGetTotal(data);
    }
  }
  return return_value;
}

/*
   This function will shrink the database 'fname' down by size 'record_size',
   and in the proccess it will remove record 'record'.
 */
int 
remove_record(char fname[], int record_size, int record)
{
  int return_value = 0;
  FILE *fptr;
  char *tmp_ptr;
  int i;
  DFI rec;
  (void) cf("remove_record");
  if ((fptr = fopen(fname, "r+b")) == NULL)
  {
    return_value = 1;
  }
  else
  {
    if (DFIRead(rec, fptr) != 1)
    {
      return_value = 7;
    }
    else
    {
      DFIDecrementTotal(rec);
      if (fseek(fptr, 0L, SEEK_SET) != 0)
      {
	return_value = 6;
      }
      else if (DFIWrite(rec, fptr) != 1)
      {
	return_value = 8;
      }
      else
      {
	tmp_ptr = New(char, record_size);
	if (tmp_ptr != NULL)
	{
	  for (i = record + 1; i <= DFIGetTotal(rec); i++)
	  {
	    if (fseek(fptr, (record_size * i) +
		      sizeof(DFI), SEEK_SET) != 0)
	    {
	      return_value = 2;
	    }
	    else if (fread(tmp_ptr, record_size, 1, fptr) != 1)
	    {
	      return_value = 3;
	    }
	    else if (fseek(fptr, (record_size * (i - 1)) +
			   sizeof(DFI), SEEK_SET) != 0)
	    {
	      return_value = 2;
	    }
	    else if (fwrite(tmp_ptr, record_size, 1, fptr) != 1)
	    {
	      return_value = 4;
	    }
	  }
	  Del(tmp_ptr);
	  if (SHRINK_FILE(fname, (record_size * DFIGetTotal(rec)) +
			  sizeof(DFI)))
	  {
	    return_value = 12;
	  }
	}
	else
	{
	  return_value = 11;
	}
      }
    }
    if (fclose(fptr) != 0)
    {
      return_value = 9;
    }
  }
  return return_value;
}

int 
read_info(char fname[], DFI * data)
{
  int return_value = 0;
  FILE *fptr;
  cf("read_info");
  if ((fptr = fopen(fname, "rb")) == NULL)
  {
    return_value = 1;
  }
  else
  {
    if (DFIpRead(data, fptr) != 1)
    {
      return_value = 7;
    }
    if (fclose(fptr) != 0)
    {
      return_value = 9;
    }
  }
  return return_value;
}

Boolean 
ReadInfo(char fname[], DFI * data)
{
  FILE *fptr;
  Cf("read_info");
  if ((fptr = fopen(fname, "rb")) != NULL)
  {
    if (DFIpRead(data, fptr) != 1)
    {
      if (fclose(fptr) == 0)
      {
	return True;
      }
    }
  }
  return False;
}

int 
write_info(char fname[], DFI data)
{
  int return_value = 0;
  FILE *fptr;
  (void) cf("write_info");
  if ((fptr = fopen(fname, "r+b")) == NULL)
  {
    return_value = 1;
  }
  else
  {
    if (DFIWrite(data, fptr) != 1)
    {
      return_value = 8;
    }
    if (fclose(fptr) != 0)
    {
      return_value = 9;
    }
  }
  return return_value;
}

Boolean 
WriteInfo(char fname[], DFI * data)
{
  FILE *fptr;
  Cf("WriteInfo");
  if ((fptr = fopen(fname, "r+b")) != NULL)
  {
    if (DFIpWrite(data, fptr) == 1)
    {
      if (fclose(fptr) != 0)
      {
	return True;
      }
    }
  }
  return False;
}

/* shrink total records by one 
   int shrink(char fname[])
   {
   int return_value = 0;
   DFI data;
   DFISet(data, 0, 0);
   return_value = read_info(fname, &data);
   if(!return_value)
   {
   DFIDecrementTotal(data);
   return_value = write_info(fname, data);
   }
   if(return_value == 0)
   {
   (void) cf("shrink");
   }
   return return_value;
   } */

Boolean 
DecrementTotalRecordsForFile(char fname[])
{
  DFI data;
  DFISet(data, 0, 0);
  if (ReadInfo(fname, &data) == True)
  {
    DFIDecrementTotal(data);
    if (WriteInfo(fname, &data) == True)
    {
      return True;
    }
  }
  return False;
}

int 
live_records(char fname[], int *val)
{
  int return_value = 0;
  DFI data;
  DFISet(data, 0, 0);
  (void) cf("live_records");
  return_value = read_info(fname, &data);
  if (!return_value)
  {
    *val = DFIGetLive(data);
  }
  return return_value;
}

Boolean 
TotalLiveRecords(char fname[], int *val)
{
  DFI data;
  DFISet(data, 0, 0);
  Cf("TotalLiveRecords");
  if (ReadInfo(fname, &data) == True)
  {
    *val = DFIGetLive(data);
    return True;
  }
  return False;
}

Boolean 
RemoveRecord(char fname[], int record_size, int record)
{
  Boolean return_value = False;
  Boolean tester = False;
  FILE *fptr = NULL;
  char *tmp_ptr = NULL;
  int i = 0;
  DFI rec;
  Cf("RemoveRecord");
  if ((fptr = fopen(fname, "r+b")) != NULL)
  {
    if (DFIRead(rec, fptr) == 1)
    {
      DFIDecrementTotal(rec);
      if ((fseek(fptr, 0L, SEEK_SET) == 0) && (DFIWrite(rec, fptr) == 1))
      {
	tmp_ptr = New(char, record_size);
	if (tmp_ptr != NULL)
	{
	  for (i = record + 1; i <= DFIGetTotal(rec); i++)
	  {
	    tester = False;
	    if (fseek(fptr, (record_size * i) + sizeof(DFI), SEEK_SET) == 0)
	    {
	      if (fread(tmp_ptr, record_size, 1, fptr) == 1)
	      {
		if (fseek(fptr, (record_size * (i - 1)) + sizeof(DFI), SEEK_SET) == 0)
		{
		  if (fwrite(tmp_ptr, record_size, 1, fptr) == 1)
		  {
		    tester = True;
		  }
		}
	      }
	    }
	  }
	  Del(tmp_ptr);
	  if (!SHRINK_FILE(fname, (record_size * DFIGetTotal(rec)) + sizeof(DFI)))
	  {
	    return_value = True;
	  }
	}
      }
    }
    if ((fclose(fptr) == 0) && (return_value == True))
    {
      return True;
    }
  }
  return False;
}
