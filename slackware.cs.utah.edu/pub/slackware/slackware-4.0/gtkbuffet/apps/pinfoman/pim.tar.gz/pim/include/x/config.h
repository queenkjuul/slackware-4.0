/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

#ifndef __PINFOMANCONFIG_H__
#define __PINFOMANCONFIG_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define PINFOMANCONFIG(obj)          GTK_CHECK_CAST (obj, pinfomanconfig_get_type (), PinfoManConfig)
#define PINFOMANCONFIG_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, pinfomanconfig_get_type (), PinfoManConfigClass)
#define IS_PINFOMANCONFIG(obj)       GTK_CHECK_TYPE (obj, pinfomanconfig_get_type ())


typedef struct _PinfoManConfig       PinfoManConfig;
typedef struct _PinfoManConfigClass  PinfoManConfigClass;

struct _PinfoManConfig
{
  GtkWindow window;
  GtkWidget *text;
  CONFIG settings;
};

struct _PinfoManConfigClass
{
  GtkWindowClass parent_class;
};

guint pinfomanconfig_get_type(void);
GtkWidget *pinfomanconfig_new();

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __PINFOMANCONFIG_H__ */













