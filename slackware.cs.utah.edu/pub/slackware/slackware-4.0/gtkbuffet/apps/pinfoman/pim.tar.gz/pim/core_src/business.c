/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

static int businessnamecmp();
static int businesspostcmp();
int sort_order;

BUSINESS *
SortBusinesses(unsigned type_of_sort, int order, int *number_sorted)
{
  int loop = 0;
  BUSINESS tmp;
  int total_number = -1;
  int number = 0;
  BUSINESS *bus = NULL;

  Cf("SortBusinesses");
  sort_order = order;
  *number_sorted = 0;
  if (TotalBusinessRecords(&total_number) == True)
  {
    switch (type_of_sort)
    {
    case SBById:
      {
	for (loop = 0; loop < total_number; loop++)
	{
	  tmp.id = loop;
	  if (ReadNormalBusinessRecord(&tmp) == True)
	  {
	    number++;
	    bus = Realloc(bus, BUSINESS, number);
	    bus[number - 1] = tmp;
	  }
	}
	*number_sorted = number;
	break;
      }
    case SBByName:
      {
	for (loop = 0; loop < total_number; loop++)
	{
	  tmp.id = loop;
	  if (ReadNormalBusinessRecord(&tmp) == True)
	  {
	    number++;
	    bus = Realloc(bus, BUSINESS, number);
	    bus[number - 1] = tmp;
	  }
	}
	*number_sorted = number;
	(void) qsort(bus, number, sizeof(BUSINESS), businessnamecmp);
	break;
      }
    case SBByPost:
      {
	for (loop = 0; loop < total_number; loop++)
	{
	  tmp.id = loop;
	  if (ReadNormalBusinessRecord(&tmp) == True)
	  {
	    number++;
	    bus = Realloc(bus, BUSINESS, number);
	    bus[number - 1] = tmp;
	  }
	}
	*number_sorted = number;
	(void) qsort(bus, number, sizeof(BUSINESS), businesspostcmp);
	break;
      }
    }
  }
  return bus;
}

static int 
businesspostcmp(BUSINESS * a, BUSINESS * b)
{
  int val = 0;
  Cf("businesspostcmp");
  if (sort_order == SortAscend)
  {
    val = strcmp(a->post, b->post);
    if (!val)
    {
      val = businessnamecmp(a, b);
    }
    return val;
  }
  val = strcmp(b->post, a->post);
  if (!val)
  {
    val = businessnamecmp(b, a);
  }
  return val;
}

static int 
businessnamecmp(BUSINESS * a, BUSINESS * b)
{
  Cf("businessnamecmp");
  if (sort_order == SortAscend)
  {
    return strcmp(a->bname, b->bname);
  }
  return strcmp(b->bname, a->bname);
}

static Boolean 
next_business_record(int *next)
{
  int records;
  BUSINESS data;
  Cf("next_business_record");
  *next = -1;
  if (TotalBusinessRecords(&records) == True)
  {
    if (records > 0)
    {
      for (data.id = 0; data.id < records; data.id++)
      {
	if (ReadBusinessRecord(&data) == True)
	{
	  if (RecordStats(data) == Blank)
	  {
	    *next = data.id;
	    return True;
	  }
	}
      }
    }
  }
  return False;
}

Boolean 
AddBusiness(BUSINESS * b)
{
  Boolean stats = False;
  Cf("AddBusiness");
  if (next_business_record(&b->id) == True)
  {
    stats = WriteBusinessRecord(b);
  }
  else if (TotalBusinessRecords(&b->id) == True)
  {
    stats = AppendBusinessRecord(b);
  }
  return stats;
}

Boolean 
StartBusinessEdit(BUSINESS * b)
{
  Cf("StartBusinessEdit");
  if (ReadNormalBusinessRecord(b) == True)
  {
    b->marker = Locked;
    return WriteBusinessRecord(b);
  }
  return False;
}

Boolean 
CancelBusinessEdit(BUSINESS * b)
{
  Cf("CancelBusinessEdit");
  if (ReadBusinessRecord(b) == True)
  {
    b->marker = ReadWrite;
    if (WriteNormalBusinessRecord(b) == True)
    {
      return True;
    }
  }
  return False;
}

Boolean 
EndBusinessEdit(BUSINESS * b)
{
  Cf("EndBusinessEdit");
  b->marker = ReadWrite;
  return WriteNormalBusinessRecord(b);
}

Boolean 
TotalBusinessRecords(int *num)
{
  extern FILES files;
  int records = -1;
  Cf("TotalBusinessRecords");
  if (!total_records(files.business_file, &records))
  {
    *num = records;
    return True;
  }
  return False;
}

Boolean 
ReadBusinessRecord(BUSINESS * b)
{
  extern FILES files;
  Cf("ReadBusinessRecord");
  if (ReadRecord(files.business_file,
		b, sizeof(BUSINESS),
		b->id) == True)
  {
    return True;
  }
  return False;
}

Boolean 
AppendBusinessRecord(BUSINESS * b)
{
  extern FILES files;
  Cf("AppendBusinessRecord");
  b->marker = ReadWrite;
  if (!append_record(files.business_file, b, sizeof(BUSINESS)))
  {
    return True;
  }
  return False;
}

Boolean 
WriteBusinessRecord(BUSINESS * b)
{
  extern FILES files;
  Cf("WriteBusinessRecord");
  if (WriteRecord(files.business_file,
		b, sizeof(BUSINESS),
		b->id) == True)
  {
    return True;
  }
  return False;
}

Boolean 
WriteNormalBusinessRecord(BUSINESS * b)
{
  extern FILES files;
  Cf("WriteBusinessRecord");
  b->marker = ReadWrite;
  if (WriteBusinessRecord(b) == True)
  {
    return True;
  }
  return False;
}

Boolean 
DeleteBusinessRecord(int id)
{
  extern FILES files;
  BUSINESS b;
  Cf("DeleteBusinessRecord");
  b.id = id;
  if (ReadNormalBusinessRecord(&b) == True)
  {
    b.marker = Blank;
    if (WriteBusinessRecord(&b) == True)
    {
      DecrementTotalRecordsForFile(files.business_file);
      return True;
    }
  }
  return False;
}

Boolean 
ReadNormalBusinessRecord(BUSINESS * b)
{
  BUSINESS bus;
  bus.id = b->id;
  if (ReadBusinessRecord(&bus) == True)
  {
    if (bus.marker != Blank)
    {
      *b = bus;
      return True;
    }
  }
  return False;
}




