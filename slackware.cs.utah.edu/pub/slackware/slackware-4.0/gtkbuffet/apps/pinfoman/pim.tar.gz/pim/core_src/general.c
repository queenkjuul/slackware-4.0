/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

/* General functions that don't go any other place, 
   like, backup, restore, etc..
 */

int 
backup(char current[], char backup[])
{
  int return_value = 0;
  extern FILES files;

  cf("backup");

  /* copy data from 'current' file to 'backup' file. */
  return return_value;
}

int 
restore(char backup[], char dir[])
{
  extern FILES files;
  int return_value = 0;

  cf("restore");

  /* copy data out of backup file, into directory dir. */
  return return_value;
}

void 
disp_lisc()
{

  Cf("disp_lisc");

  printf("%s v%s, Copyright � 1998 %s\n", PROG_NAME, PROG_VER, PROG_AUTHOR);
  printf("%s comes with ABSOLUTELY NO WARRANTY\n", PROG_NAME);
  printf("This is free software, and you are welcome to redistribute it\n");
  printf("under certain conditions.\n");
}

void 
disp_gpl()
{

  Cf("disp_gpl");

  disp_lisc();
  printf("Please read COPYRIGHT.GNU for more details\n");
}

/* Use this function to get all numbers that are needed */
/*
   the 'compact_db' function gets rid of all
   the BLANK records. */
int 
compact_db()
{
  extern FILES files;
  RECORD note;
  PERSON person;
  BUSINESS business;
  PROJECT project;
  TODO todo;
  APPOINTMENT appointment;
  Record rec;
  Link link;
  int errors = 0;
  int loop = 1;
  int record = 0;
  int records = 0;

  cf("compact_db");

  if (NextNoteRecord(&records) == True)
  {
    record = 0;
    while (loop)
    {
      loop = 0;
      if (ReadNoteRecord(&note) == True)
      {
	if (RecordStats(note.header) == Blank)
	{
	  note.header.id = record;
	  DeleteNote(note.header.id);
	  rec.type = NoteType;
	  rec.id = record;
	  (void) DecrementLinks(rec);
	  loop = 1;
	}
	else
	{
	  record++;
	}
      }
    }
  }
  else
  {
    error(files.note_file, errors);
  }

  loop = 1;
  errors = total_records(files.person_file, &records);
  if (!errors)
  {
    record = 0;
    while (loop)
    {
      loop = 0;
      if (!read_record(files.person_file, &person, sizeof(PERSON), record))
      {
	if (IsPersonBlank(&person) == True)
	{
	  remove_record(files.person_file, sizeof(PERSON), record);
	  rec.type = PersonType;
	  rec.id = record;
	  (void) DecrementLinks(rec);
	  loop = 1;
	}
	else
	{
	  record++;
	}
      }
    }
  }
  else
  {
    error(files.person_file, errors);
  }

  loop = 1;
  errors = total_records(files.business_file, &records);
  if (!errors)
  {
    record = 0;
    while (loop)
    {
      loop = 0;
      if (!read_record(files.business_file, &business, sizeof(BUSINESS), record))
      {
	if (RecordStats(business) == Blank)
	{
	  remove_record(files.business_file, sizeof(BUSINESS), record);
	  rec.type = BusinessType;
	  rec.id = record;
	  (void) DecrementLinks(rec);
	  loop = 1;
	}
	else
	{
	  record++;
	}
      }
    }
  }
  else
  {
    error(files.business_file, errors);
  }

  loop = 1;
  errors = total_records(files.todo_file, &records);
  if (!errors)
  {
    record = 0;
    while (loop)
    {
      loop = 0;
      if (!read_record(files.todo_file, &todo, sizeof(TODO), record))
      {
	if (RecordStats(todo) == Blank)
	{
	  remove_record(files.todo_file, sizeof(TODO), record);
	  rec.type = TodoType;
	  rec.id = record;
	  (void) DecrementLinks(rec);
	  loop = 1;
	}
	else
	{
	  record++;
	}
      }
    }
  }
  else
  {
    error(files.todo_file, errors);
  }

  loop = 1;
  errors = total_records(files.appointment_file, &records);
  if (!errors)
  {
    record = 0;
    while (loop)
    {
      loop = 0;
      if (!read_record(files.appointment_file, &appointment, sizeof(APPOINTMENT), record))
      {
	if (RecordStats(appointment) == Blank)
	{
	  remove_record(files.appointment_file, sizeof(APPOINTMENT), record);
	  rec.type = AppointmentType;
	  rec.id = record;
	  (void) DecrementLinks(rec);
	  loop = 1;
	}
	else
	{
	  record++;
	}
      }
    }
  }
  else
  {
    error(files.appointment_file, errors);
  }

  loop = 1;
  errors = total_records(files.project_file, &records);
  if (!errors)
  {
    record = 0;
    while (loop)
    {
      loop = 0;
      if (!read_record(files.project_file, &project, sizeof(PROJECT), record))
      {
	if (RecordStats(project) == Blank)
	{
	  remove_record(files.project_file, sizeof(PROJECT), record);
	  rec.type = ProjectType;
	  rec.id = record;
	  (void) DecrementLinks(rec);
	  loop = 1;
	}
	else
	{
	  record++;
	}
      }
    }
  }
  else
  {
    error(files.project_file, errors);
  }

  loop = 1;
  errors = total_records(files.link_file, &records);
  if (!errors)
  {
    record = 0;
    while (loop)
    {
      loop = 0;
      if (!read_record(files.link_file, &link, sizeof(Link), record))
      {
	if (RecordStats(link) == Blank)
	{
	  remove_record(files.link_file, sizeof(Link), record);
	  loop = 1;
	}
	else
	{
	  record++;
	}
      }
    }
  }
  else
  {
    error(files.link_file, errors);
  }
  return errors;
}


/*
   the 'delete_records' function blanks any record, as well as any loose links it might have
 */
int 
delete_records(int type, int record)
{
  extern FILES files;
  RECORD note;
/*  Link link; */
  BUSINESS business;
  TODO todo;
  PROJECT project;

  cf("delete_records");

  switch (type)
  {
  case NoteType:
    note.header.id = record;
    ReadNoteHeader(&note.header);
    RecordStats(note.header) = Blank;
    WriteNoteHeader(&note.header);
    chklnk(type, record, RIGHT);
    break;
  case PersonType:
    if (DeletePersonRecord(record) == True)
    {
      chklnk(type, record, BOTH);
    }
    break;
  case BusinessType:
    read_record(files.business_file, &business, sizeof(BUSINESS), record);
    RecordStats(business) = Blank;
    write_record(files.business_file, &business, sizeof(BUSINESS), record);
    DecrementTotalRecordsForFile(files.business_file);
    chklnk(type, record, BOTH);
    break;
  case AppointmentType:
    if (DeleteAppointmentRecord(record) == True)
    {
      chklnk(type, record, BOTH);
    }
    break;
  case TodoType:
    read_record(files.todo_file, &todo, sizeof(TODO), record);
    RecordStats(todo) = Blank;
    write_record(files.todo_file, &todo, sizeof(TODO), record);
    DecrementTotalRecordsForFile(files.todo_file);
    chklnk(type, record, BOTH);
    break;
  case ProjectType:
    read_record(files.project_file, &project, sizeof(PROJECT), record);
    RecordStats(project) = Blank;
    write_record(files.project_file, &project, sizeof(PROJECT), record);
    DecrementTotalRecordsForFile(files.project_file);
    chklnk(type, record, LEFT);
    break;
  default:
    printf("Error marking record as BLANK\n");
  }
  return 0;
}

/*
   make sure that if an object is removed from the right hand
   side of a link, the link is marked for nullification
   in other words, the link to the person is kept until
   the database is compacted, so if you recover the person,
   the links are still intact

   what happens to links is determined by what is on the links right side
 */


/*
   the 'chklnk' function is only to be used by the delete_records function
 */
void 
chklnk(int type, int record, int tst)
{
  extern FILES files;
  Link link;
  int loop;
  int records = -1;
  Record rec;
  rec.id = record;
  rec.type = (int) type;
  /*
    replace these if's with a switch
    */
  cf("chklnk");
  
  init_link(&link);

  total_records(files.link_file, &records);
  if (tst == BOTH)
  {
    for (loop = 0; loop < records; loop++)
    {
      read_record(files.link_file, &link, sizeof(Link), loop);
      if (AreLinksSame(link.right, rec))
      {
	RecordStats(link) = Blank;
	write_record(files.link_file, &link, sizeof(Link), loop);
	DecrementTotalRecordsForFile(files.link_file);
      }
      if (AreLinksSame(link.left, rec))
      {
	/* object is on the right of the link, so call this
	   function to clear up unwanted items. */
	if (link.right.type == NoteType)
	{
	  RecordStats(link) = Blank;
	  write_record(files.link_file, &link, sizeof(Link), loop);
	  DecrementTotalRecordsForFile(files.link_file);
	  DeleteNote(link.right.id);
	}
      }
    }
  }
  else if (tst == RIGHT)
  {
    for (loop = 0; loop < records; loop++)
    {
      read_record(files.link_file, &link, sizeof(Link), loop);
      if (AreLinksSame(link.right, rec))
      {
	RecordStats(link) = Blank;
	write_record(files.link_file, &link, sizeof(Link), loop);
	DecrementTotalRecordsForFile(files.link_file);
      }
    }
  }
  else if (tst == LEFT)
  {
    for (loop = 0; loop < records; loop++)
    {
      read_record(files.link_file, &link, sizeof(Link), loop);
      if (AreLinksSame(link.left, rec))
      {
	/* object is on the right of the link, so call this
	   function to clear up unwanted items. */
	if (link.right.type == NoteType)
	{
	  RecordStats(link) = Blank;
	  write_record(files.link_file, &link, sizeof(Link), loop);
	  DecrementTotalRecordsForFile(files.link_file);
	  DeleteNote(link.right.id);
	}
      }
    }
  }
  else
  {
    printf("Error This does not compute\n");
  }
}

void 
EnCrypt(char text[], int size, int key)
{
  for (size -= 1; size >= 0; size--)
  {
    text[size] += size + key;
  }
}

void 
DeCrypt(char text[], int size, int key)
{
  for (size -= 1; size >= 0; size--)
  {
    text[size] -= size + key;
  }
}
