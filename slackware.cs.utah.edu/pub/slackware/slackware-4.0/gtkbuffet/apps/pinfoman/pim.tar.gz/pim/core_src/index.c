/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"
static FILE *_open_index(char fname[], char method[]);
static int _index_dfi(char fname[], DFI * dfi);

int 
shrink_index_file_size(char fname[])
{
  int status = SAFE;
  DFI dfi;
  INDEX *index;
  cf("shrink_index_file_size");
  status = _index_dfi(fname, &dfi);
  index = New(INDEX, DFIGetTotal(dfi));
  status = read_index(fname, index);
  printf("INDEX SIZE - %d -\n", DFIGetTotal(dfi));
  status = write_index(fname, index, DFIGetTotal(dfi) - 1);
  return status;
}

static FILE *
_open_index(char fname[], char method[])
{
  char *nfname = New(char, strlen(fname) + strlen(IFILE));
  FILE *fptr;
  cf("_open_index");
  strcpy(nfname, fname);
  strcat(nfname, IFILE);
  fptr = fopen(nfname, method);
  Del(nfname);
  return fptr;
}

int 
read_index(char fname[], INDEX index[])
{
  int error_status = SAFE;
  FILE *fptr;
  DFI dfi;
  cf("read_index");
  fptr = _open_index(fname, "rb");
  if (fptr != NULL)
  {
    if (DFIRead(dfi, fptr) == 1)
    {
      if (fread(index, sizeof(INDEX), DFIGetTotal(dfi), fptr) != DFIGetTotal(dfi))
      {
	error_status = RNeCRA;
      }
    }
    else
    {
      error_status = RNeCRD;
    }
    fclose(fptr);
  }
  else
  {
    error_status = RNeCOI;
  }
  return error_status;
}

static int 
_index_dfi(char fname[], DFI * dfi)
{
  int status = SAFE;
  FILE *fptr;
  cf("_index_dfi");
  fptr = _open_index(fname, "rb");
  if (fptr != NULL)
  {
    if (DFIpRead(dfi, fptr) != 1)
    {
      status = UnableToReadFromFile;
    }
    fclose(fptr);
  }
  else
  {
    status = UnableToOpenFile;
  }
  return status;
}

int 
write_index(char fname[], INDEX index[], int len)
{
  FILE *fptr;
  int error_status = SAFE;
  DFI dfi;
  cf("write_index");
  fptr = _open_index(fname, "wb");
  error_status = DFISet(dfi, len, 0);
  if (!error_status)
  {
    DFIWrite(dfi, fptr);
    fwrite(index, sizeof(INDEX), len, fptr);
  }
  fclose(fptr);
  return error_status;
}

int 
setup_index_file(char fname[])
{
  FILE *fptr;
  int error_status = SAFE;
  DFI dfi;
  cf("setup_index_file");
  fptr = _open_index(fname, "wb");
  if (fptr != NULL)
  {
    DFISet(dfi, 0, 0);
    DFIWrite(dfi, fptr);
    fclose(fptr);
  }
  return error_status;
}

int 
get_pos_in_index(char fname[], int id, INDEX * pos)
{
  int status = SAFE;
  DFI dfi;
  INDEX *index;
  cf("get_pos_in_index");
  status = _index_dfi(fname, &dfi);
  index = New(INDEX, DFIGetTotal(dfi));
  status = read_index(fname, index);
  *pos = index[id];
  return status;
}

int 
set_pos_in_index(char fname[], int id, INDEX pos)
{
  int status = SAFE;
  DFI dfi;
  INDEX *index;
  cf("set_pos_in_index");
  status = _index_dfi(fname, &dfi);
  index = New(INDEX, DFIGetTotal(dfi));
  status = read_index(fname, index);
  index[id] = pos;
  status = write_index(fname, index, DFIGetTotal(dfi));
  return status;
}
