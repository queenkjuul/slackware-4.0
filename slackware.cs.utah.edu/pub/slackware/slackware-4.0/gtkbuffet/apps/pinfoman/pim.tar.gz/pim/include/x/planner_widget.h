/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

#ifndef __PLANNER_H__
#define __PLANNER_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define NEXTMSTR ">"
#define PREVMSTR "<"
#define NEXTYSTR ">>"
#define PREVYSTR "<<"

#define _TOTAL_DAY_BOXES 42

#define PLANNER(obj)          GTK_CHECK_CAST (obj, planner_get_type (), Planner)
#define PLANNER_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, planner_get_type (), PlannerClass)
#define IS_PLANNER(obj)       GTK_CHECK_TYPE (obj, planner_get_type ())


typedef struct _Planner       Planner;
typedef struct _PlannerClass  PlannerClass;

struct _Planner
{
  GtkVBox vbox;
  DATE date;
  GtkWidget *title;
  /* prev used to reset button to up position */
  GtkWidget *day[_TOTAL_DAY_BOXES];
  GtkWidget *labels[_TOTAL_DAY_BOXES];
  int day_values[_TOTAL_DAY_BOXES];
};

struct _PlannerClass
{
  GtkVBoxClass parent_class;
  void (* planner) (Planner *p);
};

guint planner_get_type(void);
GtkWidget *planner_new();
#define planner_get_date(P) P->date

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __PLANNER_H__ */













