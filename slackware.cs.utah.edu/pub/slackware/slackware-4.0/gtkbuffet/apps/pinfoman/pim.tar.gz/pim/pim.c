/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

#include"include/all.h"

int main(int argc, char *argv[])
{
  char result[50];
  int do_setup=0;
  extern CONFIG settings;
  (void) cf("main");

  do_setup = check_cmdln(argc, argv);
  (void) setup_locations();
  (void) printf("%s\n", PROG_TITLE);
  if(!do_setup)
    {
      (void) ReadConfig();
    }
  (void) setup();
  (void) disp_lisc();
  (void) printf("\n%s %s\n", _INFO_W, settings.username);
  (void) stats();
  do
    {
      (void) prompt(result, sizeof(result));
      (void) doit(result);
    } while (strcmp(result, "quit"));
  if(WriteConfig() == True)
  {
    return 0;
  }
  return 1;
}

void doit(char result[])
{

  (void) cf("doit");

  if(result[0] == 'a') { (void) do_a_funcs(result); }
  else if(result[0] == 'd') { (void) do_d_funcs(result); }
  else if(result[0] == 'e') { (void) do_e_funcs(result); }
  else if(result[0] == 'r') { (void) do_r_funcs(result); }
  else if(result[0] == 'h') { (void) do_h_funcs(result); }
  else { (void) do_other_funcs(result); }
}

int stats()
{
  int i=0;
  int j;
  extern FILES files;

  (void) cf("stats");

  (void) printf(_INFO_MSG001);
  
  i = live_records(files.person_file, &j);
  if(!i)
    {
      if(j)
	{
	  if(j>1)
	    {
	      (void) printf("\t%d %s\n", j, _REC_P2);
	    }
	  else
	    {
	      (void) printf("\t%d %s\n", j, _REC_P1);
	    }
	}
    }
  else
    {
      (void) error(files.person_file, i); 
    }
  
  i = live_records(files.business_file, &j);
  if(!i)
    {
      if(j)
	{
	  if(j>1) 
	    {
	      (void) printf("\t%d %s\n", j, _REC_B2);
	    }
	  else
	    {
	      (void) printf("\t%d %s\n", j, _REC_B1);
	    }
	}
    }
  else
    {
      (void) error(files.business_file, i); 
    }
  
  i = live_records(files.appointment_file, &j);
  if(!i)
    {
      if(j)
	{
	  if(j>1)
	    {
	      (void) printf("\t%d %s\n", j, _REC_A2);
	    }
	  else
	    {
	      (void) printf("\t%d %s\n", j, _REC_A1);
	    }
	}
    }
  else
    {
      (void) error(files.appointment_file, i);
    }
  
  i = live_records(files.todo_file, &j);
  if(!i)
    {
      if(j)
	{
	  if(j>1)
	    {
	      (void) printf("\t%d %s\n", j, _REC_T2);
	    }
	  else 
	    {
	      (void) printf("\t%d %s\n", j, _REC_T1);
	    }
	}
    }
  else
    {
      (void) error(files.todo_file, i);
    }
  
  if(NextNoteRecord(&j) == True)
    {
      if(j)
	{
	  if(j>1)
	    {
	      (void) printf("\t%d %s\n", j, _REC_N2);
	    }
	  else
	    {
	      (void) printf("\t%d %s\n", j, _REC_N1);
	    }
	}
    }
  else
    {
      (void) error(files.note_file, i);
    }
  
  i = live_records(files.link_file, &j);
  if(!i)
    {
      if(j)
	{
	  if(j>1)
	    {
	      (void) printf("\t%d %s\n", j, _REC_L2);
	    }
	  else
	    {
	      (void) printf("\t%d %s\n", j, _REC_L1);
	    }
	}
    }
  else 
    {
      (void) error(files.link_file, i);
    }

  i = live_records(files.project_file, &j);
  if(!i)
    {
      if(j)
	{
	  if(j>1)
	    {
	      (void) printf("\t%d %s\n", j, _REC_PRJ2);
	    }
	  else
	    {
	      (void) printf("\t%d %s\n", j, _REC_PRJ1);
	    }
	}
    }
  else 
    {
      (void) error(files.project_file, i);
    }
  return i;
}

void do_a_funcs(char data[])
{
  /* all functions that begin with the letter 'a' go here */

  (void) cf("do_a_funcs");

  switch (data[1])
    {
    case 'a':
      (void) add_app();
      break;
    case 'b':
      (void) add_business();
      break;
    case 'p':
      if(data[2] == 'r') { (void) add_project(); }
      else { (void) add_person(); }
      break;
    case 'n':
      (void) add_note();
      break;
    case 't':
      (void) add_todo();
      break;
    default:
      (void) help_error(data);
    }
}

void do_d_funcs(char data[])
{
  /* all functions that begin with the letter 'd' go here */

  (void) cf("do_d_funcs");

  switch(data[1])
    {
    case 'a':
      (void) visual_report_on_app();
      break; 
    case 'b': 
      (void) visual_report_on_business();
      break;
    case 'p':
      if(data[2] == 'r') { (void) visual_report_on_project(); } 
      else { (void) visual_report_on_person(); }
      break;
    case 't':
      (void) visual_report_on_todo();
      break;
    default:
      (void) help_error(data);
    }  
}

void do_e_funcs(char data[])
{
  /* all functions that begin with the letter 'e' go here */

  (void) cf("do_e_funcs");

  switch(data[1])
    {
    case 'a':
      (void) edit_app();
      break; 
    case 'b': 
      (void) edit_business();
      break;
    case 'p':
      if(data[2] == 'r') { (void) edit_project(); } 
      else { (void) edit_person(); }
      break;
    case 'n':
      (void) edit_note();
      break;
    case 't':
      (void) edit_todo();
      break;
    default:
      (void) help_error(data);
    }
}

void do_r_funcs(char data[])
{
  /* all functions that begin with the letter 'r' go here */

  (void) cf("do_r_funcs");

  switch(data[1])
    {
    case 'a':
      (void) rem_app(); 
      break;
    case 'b':
      (void) rem_business();
      break;
    case 'p':
      if(data[2] == 'r') { (void) rem_project(); }
      else { (void) rem_person(); }
      break;
    case 'n':
      (void) rem_note();
      break;
    case 't':
      (void) rem_todo();
      break;
    case 'e':
      if(!strcmp(data, "recover")) { recover(); }
      else { (void) help_error(data); }
      break;
    default:
      (void) help_error(data);
    }
}

void do_h_funcs(char data[])
{
  /* all functions that begin with the letter 'h' go here */

  (void) cf("do_h_funcs");

  switch(data[1])
    {
    case 'e':
      if(!strcmp(data, "help"))
	{
	  (void) disp_help(0);
	}
      else if(!strcmp(data, "help ap"))
	{
	  (void) disp_help(1);
	}
      else if(!strcmp(data, "help compact"))
	{
	  (void) disp_help(16);
	}
      else
	{
	  (void) help_error(data);
	}
      break;
    default:
      (void) help_error(data);
    }
}

void do_other_funcs(char data[])
{
  /* all functions that don't go in any other do_funcs go here */

  (void) cf("do_other_funcs");

  if(!strcmp(data, "quit")) { (void) printf(_INFO_Q); }
  else if(!strcmp(data, "stats")) { (void) stats(); }
  else if(!strcmp(data, "lp")) { (void) disp_p_list(); }
  else if(!strcmp(data, "lb")) { (void) disp_b_list(); }
  else if(!strcmp(data, "gpl")) { (void) disp_gpl(); }
  else if(!strcmp(data, "compact")) { (void) compact_db(); }
  else { (void) help_error(data); }
}
