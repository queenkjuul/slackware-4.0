/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

void 
time2str(char stringy[], TIME * t)
{
  (void) sprintf(stringy, "%2d:%2d", t->h, t->m);
}

void 
str2time(TIME * t, char stringy[])
{
  char *p;
  p = strtok(stringy, _DATE_SEPS);
  t->h = atoi(p);
  p = strtok(NULL, _DATE_SEPS);
  t->m = atoi(p);
}

int 
timecmp(TIME * t1, TIME * t2)
{
  int i = 0;
  int m1, m2;
  /* if t1 > t2 return > 0 */
  /* if t1 = t2 return 0 */
  /* if t1 < t2 return < 0 */
  m1 = (t1->h * 60) + t1->m;
  m2 = (t2->h * 60) + t2->m;
  i = m1 - m2;
  return i;
}

Boolean 
chktime(TIME * t)
{
  Boolean val = True;
  if ((t->h > 24) || (t->h < 1))
  {
    val = False;
  }
  if ((t->m < 1) || (t->m > 60))
  {
    val = False;
  }
  return val;
}

Boolean 
next_hour(TIME * t)
{
  if (t->h < 24)
  {
    t->h++;
  }
  else
  {
    return False;
  }
  return True;
}

Boolean 
prev_hour(TIME * t)
{
  if (t->h > 1)
  {
    t->h--;
  }
  else
  {
    return False;
  }
  return True;
}

Boolean 
next_min(TIME * t)
{
  if (t->m < 60)
  {
    t->m++;
  }
  else
  {
    return False;
  }
  return True;
}

Boolean 
prev_min(TIME * t)
{
  if (t->m > 1)
  {
    t->m--;
  }
  else
  {
    return False;
  }
  return True;
}
