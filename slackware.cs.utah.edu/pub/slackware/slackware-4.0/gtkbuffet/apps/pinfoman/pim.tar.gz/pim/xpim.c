/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */
#include"include/xall.h"

void delete_event (GtkWidget *widget, gpointer data)
{    
  (void) gtk_main_quit();
}

static void SetPinfoManDate(DATE d)
{
  extern GtkWidget *day_title;
  DATE *date=NULL;
  Link *day=NULL;
  char str[DATE_SIZE];
  (void) printf("Date Set to %s\n", date2str(str, d));
  day = GetLink_DayTitle(&d);
  date = New(DATE, 1);
  *date = d;
  if(day != NULL)
    {
      (void) gtk_label_set(GTK_LABEL(day_title), day->string);      
      Del(day);
    }
    else
    {
      (void) gtk_label_set(GTK_LABEL(day_title), "");
    }
  (void) gtk_object_set_user_data(GTK_OBJECT(day_title), date);
  (void) SetAppDate(&d);
}

static void planner_set(GtkWidget *widget, gpointer data)
{
  (void) SetPinfoManDate(planner_get_date(PLANNER(widget)));
}

static char *create_rc_file()
{
  extern FILES files;
  char *tptr=NULL;
  tptr = New(char, strlen(files.home_dir) + strlen(RCFILE));
  (void) strcpy(tptr, files.home_dir);
  (void) strcat(tptr, RCFILE);
  return tptr;
}

int main(int argc, char *argv[])
{
  extern TODOS *todos;
  Boolean marker = True;
  extern APPS *apps;
  extern PimNoteBook *book;
  extern GtkWidget *day_title;
  extern XPeople *people;
  char *rcFile=NULL;
  GtkWidget *window=NULL;
  GtkWidget *box=NULL;
  GtkWidget *hbox=NULL;
  GtkWidget *top=NULL;
  GtkWidget *bot=NULL;
  GtkWidget *panes=NULL;
  GtkWidget *menubar=NULL;
  GtkWidget *planner=NULL;
  GtkAcceleratorTable *accel=NULL;
  extern CONFIG settings;
  
  (void) gtk_init(&argc, &argv);

  (void) disp_lisc();
  
  (void) g_print("Setting up file locations\n");
  (void) setup_locations();

  if(ReadConfig() == False)
  {
    marker = False;
    (void) init_config();
    (void) SetupConfig();
    marker = WriteConfig();
  }

  if(marker == True)
    {
      (void) gtk_init(&argc, &argv);
      rcFile = create_rc_file();
      (void) gtk_rc_parse(rcFile);
      Del(rcFile);

      window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
      box = gtk_vbox_new(FALSE, 0);
      hbox = gtk_vbox_new(FALSE, 0);

      top = gtk_hpaned_new();
      bot = gtk_hpaned_new();
      panes = gtk_vpaned_new();
      (void) gtk_paned_handle_size(GTK_PANED(top), 5);
      (void) gtk_paned_handle_size(GTK_PANED(bot), 5);
      (void) gtk_paned_handle_size(GTK_PANED(panes), 5);
      
      (void) gtk_window_set_title(GTK_WINDOW (window), PROG_TITLE);
      (void) gtk_window_set_policy(GTK_WINDOW(window), TRUE, TRUE, TRUE);
      (void) gtk_signal_connect(GTK_OBJECT (window), "delete_event",
				GTK_SIGNAL_FUNC (delete_event), NULL);
      (void) gtk_container_add(GTK_CONTAINER (window), box);

      (void) get_main_menu(&menubar, &accel);
      (void) gtk_window_add_accelerator_table(GTK_WINDOW(window), accel);
      (void) gtk_box_pack_start(GTK_BOX(box), menubar, FALSE, FALSE, 0);

      
      day_title = gtk_label_new("");
      (void) gtk_box_pack_start(GTK_BOX(hbox), day_title, FALSE, TRUE, 0);
      (void) gtk_misc_set_alignment(GTK_MISC(day_title), .5, .5);
      (void) gtk_widget_show(day_title);
      
      (void) gtk_box_pack_start(GTK_BOX(box), panes, TRUE, TRUE, 0);
      (void) gtk_widget_set_usize(panes, 580, 420);
      (void) gtk_paned_add1(GTK_PANED(panes), top);
      (void) gtk_paned_add2(GTK_PANED(panes), bot);
      (void) CreateTodos();
      (void) CreateApps();
      (void) CreatePBPNoteBook();
      planner = planner_new();
      (void) SetPinfoManDate(planner_get_date(PLANNER(planner)));
      (void) gtk_signal_connect(GTK_OBJECT(planner), "planner",
				GTK_SIGNAL_FUNC(planner_set), NULL);
      (void) gtk_paned_add1(GTK_PANED(top), planner);
      (void) gtk_box_pack_start(GTK_BOX(hbox), apps->main, TRUE, TRUE, 0);
      (void) gtk_paned_add2(GTK_PANED(top), hbox);
      (void) gtk_paned_add1(GTK_PANED(bot), todos->main);
      (void) gtk_paned_add2(GTK_PANED(bot), book->main);
      (void) ShowPBPNoteBook();
      (void) gtk_widget_show(planner);
      (void) gtk_widget_show(menubar);
      (void) gtk_widget_show(hbox);
      (void) gtk_widget_show(todos->main);
      (void) gtk_widget_show(apps->main);
      (void) gtk_widget_show(bot);
      (void) gtk_widget_show(top);
      (void) gtk_widget_show(panes);
      (void) gtk_widget_show(box);
      (void) gtk_widget_show(window);
      (void) gtk_main();
      if(WriteConfig() == True)
	{
	  (void) free_locations();
	  return False; /* has an error occured is false */
	}
    }
    (void) free_locations();
  return True; /* has an error occured is true */
}
