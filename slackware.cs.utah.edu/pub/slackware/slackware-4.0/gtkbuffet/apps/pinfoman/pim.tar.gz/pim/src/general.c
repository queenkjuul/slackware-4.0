
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/all.h"

/* General functions that don't go any other place, 
   like, backup, restore, etc..
 */

void 
disp_error(char text[])
{

  cf("disp_error");

  fprintf(stderr, "PinfoMan: %s\n", text);
}

int 
recover()
{
  extern FILES files;
  int errors = 0;
  int choice = -1;
  PERSON p;
  int val;
  cf("recover");

  /*
     give the user some way of choosing which type of
     record they want to recover, then give them a list
     of all the records of that type that are marked as
     BLANK.
     When the user selects one, check that it is still
     marked as BLANK, then change the record to READ_WRITE
     check for linked notes, and do the same to them.
   */
  printf("You have decided to recover some previously removed data\n");
  printf("******************************\n");
  printf("* 0 - Recover a Person       *\n");
  printf("* 1 - Recover a Business     *\n");
  printf("* 2 - Recover a Todo         *\n");
  printf("* 3 - Recover an Appointment *\n");
  printf("* 4 - Recover a Project      *\n");
  printf("******************************\n");
  printf("Which type of data do you want to recover? ");
  choice = getnum();
  switch (choice)
  {
  case 0:
    printf("In the future a menu will be here\n");
    printf("that will allow you to select a person from a list\n");
    printf("But until then press a number : ");
    val = getnum();
    read_record(files.person_file, &p, sizeof(PERSON), val);
    if (p.marker == Blank)
    {
      p.marker = ReadWrite;
      write_record(files.person_file, &p, sizeof(PERSON), val);
    }
    break;
  }
  return errors;
}
