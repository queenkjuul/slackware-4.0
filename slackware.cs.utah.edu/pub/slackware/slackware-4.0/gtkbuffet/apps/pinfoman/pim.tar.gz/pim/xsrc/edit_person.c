/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/xall.h"

enum
{
  _UPDATED,
  _CANCELED,
  EP_LAST_SIGNAL
};

Boolean do_i_close;
Boolean do_i_cancel;

static void editperson_class_init(EditPersonClass *);
static void editperson_init(EditPerson *);
static void _send_update(EditPerson *);
static void _send_cancel(EditPerson *);
static void _update_clicked(GtkWidget *, gpointer);
static void _cancel_clicked(GtkWidget *, gpointer);
static void _notes_menu_clicked(GtkWidget *, gpointer);
static void editperson_get_person(EditPerson *);

static gint 
Destroy(GtkWidget * widget, GtkWidget * data)
{
  do_i_close = False;
  if(data == NULL) { return True; }
  (void) _cancel_clicked(widget, data);
  return False;
}

static gint
Delete(GtkWidget * widget, GtkWidget * data)
{
  return False;
}

static unsigned int ep_signals[EP_LAST_SIGNAL] =
{0};

guint 
editperson_get_type()
{
  static guint p_type = 0;
  if (!p_type)
  {
    GtkTypeInfo p_info =
    {
      "EditPerson",
      sizeof(EditPerson),
      sizeof(EditPersonClass),
      (GtkClassInitFunc) editperson_class_init,
      (GtkObjectInitFunc) editperson_init,
      (GtkArgSetFunc) NULL,
      (GtkArgGetFunc) NULL
    };
    p_type = gtk_type_unique(gtk_window_get_type(), &p_info);
  }
  return p_type;
}

static void 
editperson_class_init(EditPersonClass * class)
{
  GtkObjectClass *object_class;
  
  if(class == NULL) { return; }
  
  object_class = (GtkObjectClass *) class;
  ep_signals[_UPDATED] = gtk_signal_new("update",
					GTK_RUN_FIRST,
					object_class->type,
					GTK_SIGNAL_OFFSET(EditPersonClass,
							  update),
					gtk_signal_default_marshaller,
					GTK_TYPE_NONE, 0);
  ep_signals[_CANCELED] = gtk_signal_new("cancel",
					 GTK_RUN_FIRST,
					 object_class->type,
					 GTK_SIGNAL_OFFSET(EditPersonClass,
							   cancel),
					 gtk_signal_default_marshaller,
					 GTK_TYPE_NONE, 0);
  (void) gtk_object_class_add_signals(object_class,
				      ep_signals,
				      EP_LAST_SIGNAL);
  class->update = NULL;
  class->cancel = NULL;
}

GtkWidget *
editperson_new()
{
  do_i_close = True;
  do_i_cancel = True;
  return GTK_WIDGET(gtk_type_new(editperson_get_type()));
}

static void 
_send_update(EditPerson * ep)
{
  if(ep == NULL) { return; }
  (void) gtk_signal_emit(GTK_OBJECT(ep), ep_signals[_UPDATED]);
}

static void 
_send_cancel(EditPerson * ep)
{
  if(ep == NULL) { return; }
  (void) gtk_signal_emit(GTK_OBJECT(ep), ep_signals[_CANCELED]);
}

static void 
editperson_init(EditPerson * ep)
{
  GtkTooltips *tips = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *box = NULL;
  GtkWidget *hbox = NULL;
  GtkWidget *phones = NULL;
  GtkWidget *display = NULL;
  GtkWidget *details = NULL;
  GtkWidget *controls = NULL;
  GtkWidget *button = NULL;
  GtkWidget *label = NULL;
  GtkWidget *menubar = NULL;
  GtkWidget *menu = NULL;
  GtkWidget *item = NULL;
  GtkWidget *details_frame = NULL;
  GtkWidget *phones_frame = NULL;
  Cf("editperson_init");
  
  if(ep == NULL) { return; }
  
  (void) gtk_signal_connect_object(GTK_OBJECT(ep), "delete_event",
				   (GtkSignalFunc) Delete,
				   GTK_OBJECT(ep));
  (void) gtk_signal_connect(GTK_OBJECT(ep), "destroy",
			GTK_SIGNAL_FUNC(Destroy),
			GTK_OBJECT(ep));
  
  tips = gtk_tooltips_new();

  ep->person = New(PERSON, 1);
  (void) init_person(ep->person);

  vbox = gtk_vbox_new(FALSE, 0);

  menu = gtk_menu_new();
  item = gtk_menu_item_new_with_label("Notes");
  (void) gtk_menu_append(GTK_MENU(menu), item);
  (void) gtk_signal_connect_object(GTK_OBJECT(item), "activate",
				   GTK_SIGNAL_FUNC(_notes_menu_clicked),
				   (gpointer) ep);
  (void) gtk_widget_show(item);

  item = gtk_menu_item_new_with_label("Stuff");
  (void) gtk_menu_item_set_submenu(GTK_MENU_ITEM(item), menu);
  (void) gtk_widget_show(item);

  menubar = gtk_menu_bar_new();
  (void) gtk_menu_bar_append(GTK_MENU_BAR(menubar), item);
  (void) gtk_box_pack_start(GTK_BOX(vbox), menubar, FALSE, TRUE, 0);
  (void) gtk_widget_show(menubar);

  display = gtk_hbox_new(FALSE, 0);
  (void) gtk_box_pack_start(GTK_BOX(vbox), display, TRUE, TRUE, 0);

  details_frame = gtk_frame_new(NULL);
  (void) gtk_container_border_width(GTK_CONTAINER(details_frame), 5);
  (void) gtk_widget_set_usize(details_frame, 500, 220);
  (void) gtk_widget_show(details_frame);

  details = gtk_table_new(7, 2, TRUE);
  box = gtk_vbox_new(FALSE, 0);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_RT);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->title = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->title) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->title, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->title,
  		"Record title for this person", NULL);
  (void) gtk_widget_show(ep->title);
  (void) gtk_box_pack_start(GTK_BOX(box), hbox, FALSE, TRUE, 5);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_FN);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->lname = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->lname) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->lname, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->lname,
        "Family name of person", NULL);
  (void) gtk_widget_show(ep->lname);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 0, 1, 0, 1);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_GN);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->fname = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->fname) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->fname, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->fname,
  	"Given name(s) for this person", NULL);
  (void) gtk_widget_show(ep->fname);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 0, 1, 1, 2);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_CN);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->cname = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->cname) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->cname, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->cname,
  			"The name this person preffers to be called", NULL);
  (void) gtk_widget_show(ep->cname);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 0, 1, 2, 3);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new("Gender");
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->gender = gtk_entry_new_with_max_length((guint16) 15);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->gender, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->gender,
  			"Gender of this person\nMale / Female", NULL);
  (void) gtk_widget_show(ep->gender);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 0, 1, 3, 4);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_B);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->birthdate = gtk_entry_new_with_max_length((guint16) DATE_SIZE);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->birthdate, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->birthdate,
  			"Birthdate for this person\n(09/12/1978)", NULL);
  (void) gtk_widget_show(ep->birthdate);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 0, 1, 4, 5);
  (void) gtk_widget_show(hbox);

  /*****************************************
   *Spouse is a link to another person,    *
   *for this we must use a drop down box,  *
   *that contains a list of all the people.*
   *****************************************/

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_SP);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->spouse = linklist_new();
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->spouse, TRUE, TRUE, 5);
/*  (void) gtk_tooltips_set_tip(tips, ep->spouse,
  			"Select this person's Partner", NULL);*/
  (void) gtk_widget_show(ep->spouse);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 0, 1, 5, 6);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_E);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->email = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->email) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->email, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->email,
  			"E-Mail address for this person", NULL);
  (void) gtk_widget_show(ep->email);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 0, 1, 6, 7);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_SA);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
  (void) gtk_widget_show(label);
  ep->address = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->address) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->address, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->address,
  			"Street address for this person", NULL);
  (void) gtk_widget_show(ep->address);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 1, 2, 0, 1);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new("Address Line 2");
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
  (void) gtk_widget_show(label);
  ep->address2 = gtk_entry_new_with_max_length(
  		(guint16) sizeof(ep->person->address_line2) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->address2, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->address2,
  	"second line of street address address for this person", NULL);
  (void) gtk_widget_show(ep->address2);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 1, 2, 1, 2);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_CS);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
  (void) gtk_widget_show(label);
  ep->city = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->city) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->city, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->city,	
  			"City / Suburb for this person", NULL);
  (void) gtk_widget_show(ep->city);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 1, 2, 2, 3);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_ST);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
  (void) gtk_widget_show(label);
  ep->state = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->state) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->state, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->state,
			"State / Teritory for this person", NULL);
  (void) gtk_widget_show(ep->state);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 1, 2, 3, 4);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_PC);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
  (void) gtk_widget_show(label);
  ep->post = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->post) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->post, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->post,
  			"Post code for this person", NULL);
  (void) gtk_widget_show(ep->post);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 1, 2, 4, 5);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_C);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
  (void) gtk_widget_show(label);
  ep->country = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->country) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->country, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->country,
        "Country for this person", NULL);
  (void) gtk_widget_show(ep->country);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 1, 2, 5, 6);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_W);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
  (void) gtk_widget_show(label);
  ep->www = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->www) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->www, TRUE, TRUE, 5);
  (void) gtk_tooltips_set_tip(tips, ep->www,
  			"World Wide Web address for this person", NULL);
  (void) gtk_widget_show(ep->www);
  (void) gtk_table_attach_defaults(GTK_TABLE(details), hbox, 1, 2, 6, 7);
  (void) gtk_widget_show(hbox);

  phones_frame = gtk_frame_new(NULL);
  (void) gtk_container_border_width(GTK_CONTAINER(phones_frame), 5);
  (void) gtk_widget_show(phones_frame);

  phones = gtk_vbox_new(FALSE, 0);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_PHONE1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->phones[0] = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->phones[0]) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->phones[0], TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, ep->phones[0],
  			"Home phone number for this person", NULL);
  (void) gtk_widget_show(ep->phones[0]);
  (void) gtk_box_pack_start(GTK_BOX(phones), hbox, TRUE, TRUE, 0);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_PHONE2);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->phones[1] = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->phones[1]) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->phones[1], TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, ep->phones[1],
  			"Fax number for this person", NULL);
  (void) gtk_widget_show(ep->phones[1]);
  (void) gtk_box_pack_start(GTK_BOX(phones), hbox, TRUE, TRUE, 0);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_PHONE3);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->phones[2] = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->phones[2]) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->phones[2], TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, ep->phones[2],
  			"Mobile phone number for this person", NULL);
  (void) gtk_widget_show(ep->phones[2]);
  (void) gtk_box_pack_start(GTK_BOX(phones), hbox, TRUE, TRUE, 0);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_PHONE4);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->phones[3] = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->phones[3]) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->phones[3], TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, ep->phones[3],
  			"Work phone number for this person", NULL);
  (void) gtk_widget_show(ep->phones[3]);
  (void) gtk_box_pack_start(GTK_BOX(phones), hbox, TRUE, TRUE, 0);
  (void) gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(_ADD_P_PHONE5);
  (void) gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
  (void) gtk_widget_show(label);
  ep->phones[4] = gtk_entry_new_with_max_length((guint16) sizeof(ep->person->phones[4]) - 1);
  (void) gtk_box_pack_start(GTK_BOX(hbox), ep->phones[4], TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, ep->phones[4],
  			"Other phone number for this person", NULL);
  (void) gtk_widget_show(ep->phones[4]);
  (void) gtk_box_pack_start(GTK_BOX(phones), hbox, TRUE, TRUE, 0);
  (void) gtk_widget_show(hbox);

  (void) gtk_container_add(GTK_CONTAINER(details_frame), details);
  (void) gtk_box_pack_start(GTK_BOX(box), details_frame, TRUE, TRUE, 0);
  (void) gtk_container_add(GTK_CONTAINER(phones_frame), phones);
  (void) gtk_box_pack_start(GTK_BOX(display), box, TRUE, TRUE, 0);
  (void) gtk_box_pack_start(GTK_BOX(display), phones_frame, TRUE, TRUE, 0);
  (void) gtk_widget_show(details);
  (void) gtk_widget_show(phones);
  (void) gtk_widget_show(display);
  (void) gtk_widget_show(box);

  controls = gtk_hbox_new(FALSE, 0);

  button = gtk_button_new_with_label(_ADD_P_UP);
  (void) gtk_signal_connect(GTK_OBJECT(button),
			    "clicked",
			    GTK_SIGNAL_FUNC(_update_clicked),
			    EDITPERSON(ep));
  (void) gtk_box_pack_start(GTK_BOX(controls), button, TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, button,
  	"Add / Update this person", NULL);
  (void) gtk_widget_show(button);

  button = gtk_button_new_with_label(_ADD_P_CA);
  (void) gtk_signal_connect(GTK_OBJECT(button),
			    "clicked",
			    GTK_SIGNAL_FUNC(_cancel_clicked),
			    EDITPERSON(ep));
  (void) gtk_box_pack_start(GTK_BOX(controls), button, TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, button,
  	"Cancel changes to this person", NULL);
  (void) gtk_widget_show(button);

  (void) gtk_box_pack_start(GTK_BOX(vbox), controls, FALSE, TRUE, 0);
  (void) gtk_widget_show(controls);
  (void) gtk_container_add(GTK_CONTAINER(ep), vbox);
  (void) gtk_widget_show(vbox);
  ep->HasSpouse = False;
}

static void 
_update_clicked(GtkWidget * widget, gpointer data)
{
  EditPerson *ep=NULL;
  GtkWidget *win=NULL;
  Link spouse;
  Record right;
  Record left;
  int value = Spouse;
  
  if(data == NULL) { return; }
  ep = (EditPerson *) data;
  win = (GtkWidget *) data;
  (void) editperson_get_person(ep);
  if(ep->IsNew == False)
  {
    (void) EndPersonEdit(ep->person);
  }
  else
  {
    (void) AddPerson(ep->person);
  }
  if (ep->HasSpouse == True)
  {
    left.id = ep->person->id;
    left.type = PersonType;
    right = ep->rec;
    spouse.id = DoesLinkExist(Person_Person, &value, &right, &left, NULL);
    spouse.has_right = True;
    spouse.has_left = True;
    spouse.left = left;
    spouse.right = right;
    spouse.type = Person_Person;
    spouse.stype = Spouse;
    if (spouse.id < 0)
    {
      AddLink(&spouse);
    }
    else
    {
      WriteLink(&spouse);
    }
  }
  else
  {
    /*
       search to see if there is a match to a previous link, then delete it
     */
  }
  Del(ep->person);
  (void) gtk_grab_remove(win);
  (void) _send_update(ep);
  do_i_cancel = False;
  do_i_close = False;
  (void) gtk_widget_destroy(win);
}

static void 
_cancel_clicked(GtkWidget * widget, gpointer data)
{
  GtkWidget *win = NULL;
  EditPerson * ep = NULL;
  if(data == NULL) { return; }
  win = (GtkWidget *) data;
  ep = (EditPerson *) data;
  if(do_i_cancel == True)
  {
    do_i_cancel = False;
    if (ep->IsNew == False)
    {
      (void) CancelPersonEdit(ep->person);
    }
    Del(ep->person);
    (void) _send_cancel(ep);
  }
  if(do_i_close == True)
  {
    do_i_close = False;
    (void) gtk_grab_remove(win);
    (void) gtk_widget_destroy(win);
  }
}

static void 
_notes_menu_clicked(GtkWidget * widget, gpointer data)
{/*
  Record record;
  int num = -1;
  Link *links = NULL;
  GtkWidget *notething = NULL;

  if(data == NULL) { return; }

  record.id = EDITPERSON(data)->person->id;
  record.type = PersonType;
  links = GetLink(record, Person_Note, NoteType, &num);
  if ((num == 1) && (links != NULL))
  {
    notething = EditANote(links);
  }
  else
  {
    Del(links);
    links = New(Link, 1);
    links->type = Person_Note;
    links->left = record;
    links->right.id = -1;
    notething = EditANote(links);
  }
  (void) gtk_grab_add(notething);
  (void) g_print("Notes Menu Clicked\n");*/
}

void 
editperson_type(EditPerson * ep, EditOption opt)
{
  Cf("editperson_type");
  
  if(ep == NULL) { return; }
  
  switch (opt)
  {
  case EditTypeNew:
    (void) gtk_window_set_title(GTK_WINDOW(ep), "PinfoMan: Add a Person");
    ep->IsNew = True;
    break;
  case EditTypeEdit:
    (void) gtk_window_set_title(GTK_WINDOW(ep), "PinfoMan: Edit a Person");
    ep->IsNew = False;
    break;
  }
}

void 
editperson_set_person(EditPerson * ep, PERSON * p)
{
  char text[DATE_SIZE];
  Record this_person;
  Record rec;
  int number = 0;
  int i = 0;
  char *str=NULL;
  Link *spouse = NULL;

  Cf("editperson_set_person");
  if (ep == NULL)
    {
      (void) g_print("ep == NULL\n");
      return;
    }
  if (p != NULL)
    {
      SetRecord(this_person, p->id, PersonType);
      spouse = GetLink(this_person, Person_Person, PersonType, &number);
      if (spouse != NULL && number != 0)
	{
	  for (i = 0; i < number; i++)
	    {
	      if (spouse[i].stype == Spouse)
		{
		  rec = spouse[i].right;
		  ep->HasSpouse = True;
		}
	    }
	}
      Del(spouse);
      *ep->person = *p;
      /*
	Load Person into text fields
	*/
      (void) gtk_entry_set_text(GTK_ENTRY(ep->title), ep->person->title);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->fname), ep->person->fname);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->lname), ep->person->lname);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->cname), ep->person->cname);
      /* Birthdate thing */
      (void) date2str(text, ep->person->bd);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->birthdate), text);

      (void) gtk_entry_set_text(GTK_ENTRY(ep->address), ep->person->address);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->address2), ep->person->address_line2);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->country), ep->person->country);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->city), ep->person->city);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->state), ep->person->state);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->post), ep->person->post);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->email), ep->person->email);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->www), ep->person->www);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->phones[0]), ep->person->phones[0]);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->phones[1]), ep->person->phones[1]);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->phones[2]), ep->person->phones[2]);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->phones[3]), ep->person->phones[3]);
      (void) gtk_entry_set_text(GTK_ENTRY(ep->phones[4]), ep->person->phones[4]);
      str = Gender2str(ep->person->gender);
      if(str != NULL)
	{
	  (void) gtk_entry_set_text(GTK_ENTRY(ep->gender), str);
	  Del(str);
	}
      if (ep->HasSpouse == True)
	{
	  (void) linklist_set(LINKLIST(ep->spouse), PersonType, &rec);
	}
      else
	{
	  (void) linklist_set(LINKLIST(ep->spouse), PersonType, NULL);
	}
      return;
    }
  (void) linklist_set(LINKLIST(ep->spouse), PersonType, NULL);
}

static void 
editperson_get_person(EditPerson * ep)
{
  char *text=NULL;
  /*Record *rec = NULL;*/
  
  if(ep == NULL) { return; }
  
  Cf("editperson_get_person");
/*
  rec = linklist_get(LINKLIST(ep->spouse));
  if (rec != NULL)
  {
    ep->rec = *rec;
    Del(rec);
    ep->HasSpouse = True;
  }
*/
  text = gtk_entry_get_text(GTK_ENTRY(ep->gender));
  if(text != NULL)
    ep->person->gender = str2Gender(text);
  
  text = gtk_entry_get_text(GTK_ENTRY(ep->address2));
  if(text != NULL)
    (void) strcpy(ep->person->address_line2, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->title));
  if(text != NULL)
    (void) strcpy(ep->person->title, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->lname));
  if(text != NULL)
    (void) strcpy(ep->person->lname, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->fname));
  if(text != NULL)
    (void) strcpy(ep->person->fname, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->cname));
  if(text != NULL)
    (void) strcpy(ep->person->cname, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->birthdate));
  if(text != NULL)
    (void) str2date(&ep->person->bd, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->phones[0]));
  if(text != NULL)
    (void) strcpy(ep->person->phones[0], text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->phones[1]));
  if(text != NULL)
    (void) strcpy(ep->person->phones[1], text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->phones[2]));
  if(text != NULL)
    (void) strcpy(ep->person->phones[2], text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->phones[3]));
  if(text != NULL)
    (void) strcpy(ep->person->phones[3], text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->phones[4]));
  if(text != NULL)
    (void) strcpy(ep->person->phones[4], text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->address));
  if(text != NULL)
    (void) strcpy(ep->person->address, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->country));
  if(text != NULL)
    (void) strcpy(ep->person->country, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->city));
  if(text != NULL)
    (void) strcpy(ep->person->city, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->state));
  if(text != NULL)
    (void) strcpy(ep->person->state, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->post));
  if(text != NULL)
    (void) strcpy(ep->person->post, text);

  text = gtk_entry_get_text(GTK_ENTRY(ep->www));
  if(text != NULL)
    (void) strcpy(ep->person->www, text);
  
  text = gtk_entry_get_text(GTK_ENTRY(ep->email));
  if(text != NULL)
    (void) strcpy(ep->person->email, text);
}

