/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/xall.h"

#define _MONTH_LOOP(X) for(X=0;X<_TOTAL_DAY_BOXES;X++)

enum
{
  SET_DATE,
  LAST_SIGNAL
};

static void _ptoday_clicked(GtkWidget * widget, gpointer data);
static void _pnext_month_clicked(GtkWidget * widget, gpointer data);
static void _pprev_month_clicked(GtkWidget * widget, gpointer data);
static void _pnext_year_clicked(GtkWidget * widget, gpointer data);
static void _pprev_year_clicked(GtkWidget * widget, gpointer data);
static void _day_clicked(GtkWidget * widget, gpointer data);
static void setPlannerDate(Planner * p);
static void planner_class_init(PlannerClass * klass);
static void planner_init(Planner * p);
static void planner_date_set(Planner * p);
static void _set_day_labels(Planner * p);

static unsigned int sigs[LAST_SIGNAL] =
{0};

guint 
planner_get_type()
{
  static guint p_type = 0;
  Cf("planner_get_type");
  if (!p_type)
  {
    GtkTypeInfo p_info =
    {
      "Planner",
      sizeof(Planner),
      sizeof(PlannerClass),
      (GtkClassInitFunc) planner_class_init,
      (GtkObjectInitFunc) planner_init,
      (GtkArgSetFunc) NULL,
      (GtkArgGetFunc) NULL
    };
    p_type = gtk_type_unique(gtk_vbox_get_type(), &p_info);
  }
  return p_type;
}

static void 
planner_class_init(PlannerClass * class)
{
  GtkObjectClass *object_class;
  Cf("planner_class_init");
  object_class = (GtkObjectClass *) class;
  sigs[SET_DATE] = gtk_signal_new("planner", GTK_RUN_FIRST,
				  object_class->type,
				  GTK_SIGNAL_OFFSET(PlannerClass,
						    planner),
				  gtk_signal_default_marshaller,
				  GTK_TYPE_NONE, 0);
  (void) gtk_object_class_add_signals(object_class, sigs, LAST_SIGNAL);
  class->planner = NULL;
}

GtkWidget *
planner_new()
{
  Cf("planner_new");
  return GTK_WIDGET(gtk_type_new(planner_get_type()));
}

static void 
planner_date_set(Planner * p)
{
  Cf("planner_date_set");
  if (chkdate(&p->date) == True)
  {
    (void) gtk_signal_emit(GTK_OBJECT(p), sigs[SET_DATE]);
  }
}

static void 
planner_init(Planner * p)
{
  int i = 0, j = 0;
  GtkTooltips *tips = NULL;
  GtkWidget *table = NULL;
  GtkWidget *titles[7];
  GtkWidget *today = NULL;
  GtkWidget *prev_month = NULL;
  GtkWidget *next_month = NULL;
  GtkWidget *prev_year = NULL;
  GtkWidget *next_year = NULL;
  GtkWidget *controls = NULL;
  Cf("planner_init");

  tips = gtk_tooltips_new();
  p->title = gtk_label_new("Month, Year");
  (void) gtk_container_add(GTK_CONTAINER(p), p->title);
  (void) gtk_widget_show(p->title);
  table = gtk_table_new(6, 7, TRUE);
  titles[Sunday] = gtk_label_new(SUNDAY_sSTR);
  titles[Monday] = gtk_label_new(MONDAY_sSTR);
  titles[Tuesday] = gtk_label_new(TUESDAY_sSTR);
  titles[Wednesday] = gtk_label_new(WEDNESDAY_sSTR);
  titles[Thursday] = gtk_label_new(THURSDAY_sSTR);
  titles[Friday] = gtk_label_new(FRIDAY_sSTR);
  titles[Saturday] = gtk_label_new(SATURDAY_sSTR);
  for (i = 0; i < 7; i++)
  {
    (void) gtk_table_attach_defaults(GTK_TABLE(table),
				     titles[i], i, i + 1, 0, 1);
    (void) gtk_widget_show(titles[i]);
  }
  i = 0;
  for (j = 0; j < 7; j++)
  {
    p->day[j] = gtk_toggle_button_new();
    (void) gtk_signal_connect(GTK_OBJECT(p->day[j]), "toggled",
			      GTK_SIGNAL_FUNC(_day_clicked), PLANNER(p));
    (void) gtk_table_attach_defaults(GTK_TABLE(table), p->day[j], i, i + 1, 1, 2);
    (void) gtk_widget_show(p->day[j]);
    p->day_values[j] = j;
    i++;
  }
  i = 0;
  for (j = 7; j < 14; j++)
  {
    p->day[j] = gtk_toggle_button_new();
    (void) gtk_signal_connect(GTK_OBJECT(p->day[j]), "toggled",
			      GTK_SIGNAL_FUNC(_day_clicked), PLANNER(p));
    (void) gtk_table_attach_defaults(GTK_TABLE(table), p->day[j], i, i + 1, 2, 3);
    (void) gtk_widget_show(p->day[j]);
    p->day_values[j] = j;
    i++;
  }
  i = 0;
  for (j = 14; j < 21; j++)
  {
    p->day[j] = gtk_toggle_button_new();
    (void) gtk_signal_connect(GTK_OBJECT(p->day[j]), "toggled",
			      GTK_SIGNAL_FUNC(_day_clicked), PLANNER(p));
    (void) gtk_table_attach_defaults(GTK_TABLE(table), p->day[j], i, i + 1, 3, 4);
    (void) gtk_widget_show(p->day[j]);
    p->day_values[j] = j;
    i++;
  }
  i = 0;
  for (j = 21; j < 28; j++)
  {
    p->day[j] = gtk_toggle_button_new();
    (void) gtk_signal_connect(GTK_OBJECT(p->day[j]), "toggled",
			      GTK_SIGNAL_FUNC(_day_clicked), PLANNER(p));
    (void) gtk_table_attach_defaults(GTK_TABLE(table), p->day[j], i, i + 1, 4, 5);
    (void) gtk_widget_show(p->day[j]);
    p->day_values[j] = j;
    i++;
  }
  i = 0;
  for (j = 28; j < 35; j++)
  {
    p->day[j] = gtk_toggle_button_new();
    (void) gtk_signal_connect(GTK_OBJECT(p->day[j]), "toggled",
			      GTK_SIGNAL_FUNC(_day_clicked), PLANNER(p));
    (void) gtk_table_attach_defaults(GTK_TABLE(table), p->day[j], i, i + 1, 5, 6);
    (void) gtk_widget_show(p->day[j]);
    p->day_values[j] = j;
    i++;
  }
  i = 0;
  for (j = 35; j < _TOTAL_DAY_BOXES; j++)
  {
    p->day[j] = gtk_toggle_button_new();
    (void) gtk_signal_connect(GTK_OBJECT(p->day[j]), "toggled",
			      GTK_SIGNAL_FUNC(_day_clicked), PLANNER(p));
    (void) gtk_table_attach_defaults(GTK_TABLE(table), p->day[j], i, i + 1, 6, 7);
    (void) gtk_widget_show(p->day[j]);
    p->day_values[j] = j;
    i++;
  }
  (void) gtk_container_add(GTK_CONTAINER(p), table);
  (void) gtk_widget_show(table);
  controls = gtk_hbox_new(FALSE, 0);

  prev_year = gtk_button_new_with_label(PREVYSTR);
  (void) gtk_signal_connect(GTK_OBJECT(prev_year), "clicked",
			  GTK_SIGNAL_FUNC(_pprev_year_clicked), PLANNER(p));
  (void) gtk_box_pack_start(GTK_BOX(controls), prev_year, TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, prev_year, "Set the date back one year", NULL);
  (void) gtk_widget_show(prev_year);

  prev_month = gtk_button_new_with_label(PREVMSTR);
  (void) gtk_signal_connect(GTK_OBJECT(prev_month), "clicked",
			 GTK_SIGNAL_FUNC(_pprev_month_clicked), PLANNER(p));
  (void) gtk_box_pack_start(GTK_BOX(controls), prev_month, TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, prev_month, "Set the date back one month", NULL);
  (void) gtk_widget_show(prev_month);

  today = gtk_button_new_with_label(TODAYSTR);
  (void) gtk_signal_connect(GTK_OBJECT(today), "clicked",
			    GTK_SIGNAL_FUNC(_ptoday_clicked), PLANNER(p));
  (void) gtk_box_pack_start(GTK_BOX(controls), today, TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, today, "Set the date to today", NULL);
  (void) gtk_widget_show(today);

  next_month = gtk_button_new_with_label(NEXTMSTR);
  (void) gtk_signal_connect(GTK_OBJECT(next_month), "clicked",
			 GTK_SIGNAL_FUNC(_pnext_month_clicked), PLANNER(p));
  (void) gtk_box_pack_start(GTK_BOX(controls), next_month, TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, next_month, "Set the date forward one month", NULL);
  (void) gtk_widget_show(next_month);

  next_year = gtk_button_new_with_label(NEXTYSTR);
  (void) gtk_signal_connect(GTK_OBJECT(next_year), "clicked",
			  GTK_SIGNAL_FUNC(_pnext_year_clicked), PLANNER(p));
  (void) gtk_box_pack_start(GTK_BOX(controls), next_year, TRUE, TRUE, 0);
  (void) gtk_tooltips_set_tip(tips, next_year, "Set the date forward one year", NULL);
  (void) gtk_widget_show(next_year);
  (void) gtk_container_add(GTK_CONTAINER(p), controls);
  (void) gtk_widget_show(controls);
  _MONTH_LOOP(i)
  {
    p->labels[i] = gtk_label_new(" ");
    (void) gtk_container_add(GTK_CONTAINER(p->day[i]), p->labels[i]);
    (void) gtk_widget_show(p->labels[i]);
  }
  CurrentDate(&p->date);
  (void) setPlannerDate(p);
}

static void 
_ptoday_clicked(GtkWidget * widget, gpointer data)
{
  Cf("_ptoday_clicked");
  (void) CurrentDate(&PLANNER(data)->date);
  (void) setPlannerDate(PLANNER(data));
}

static void 
_pnext_month_clicked(GtkWidget * widget, gpointer data)
{
  Cf("_pnext_month_clicked");
  if (nextmonth(&PLANNER(data)->date) == False)
  {
    PLANNER(data)->date.m = 1;
    IncrementYear(PLANNER(data)->date);
  }
  (void) setPlannerDate(PLANNER(data));
}

static void 
_pprev_month_clicked(GtkWidget * widget, gpointer data)
{
  Cf("_pprev_month_clicked");
  if (prevmonth(&PLANNER(data)->date) == False)
  {
    PLANNER(data)->date.m = 12;
    DecrementYear(PLANNER(data)->date);
  }
  (void) setPlannerDate(PLANNER(data));
}

static void 
_pnext_year_clicked(GtkWidget * widget, gpointer data)
{
  Cf("_pnext_year_clicked");
  IncrementYear(PLANNER(data)->date);
  (void) setPlannerDate(PLANNER(data));
}

static void 
_pprev_year_clicked(GtkWidget * widget, gpointer data)
{
  Cf("_pprev_year_clicked");
  DecrementYear(PLANNER(data)->date);
  (void) setPlannerDate(PLANNER(data));
}

static void 
_day_clicked(GtkWidget * widget, gpointer data)
{
  int i, id = -1;
  Cf("_day_clicked");
  if (GTK_TOGGLE_BUTTON(widget)->active)
  {
    _MONTH_LOOP(i)
    {
      if (widget == PLANNER(data)->day[i])
      {
	id = i;
      }
    }
    PLANNER(data)->date.d = PLANNER(data)->day_values[id];
    (void) setPlannerDate(PLANNER(data));
  }
}

static void 
setPlannerDate(Planner * p)
{
  int i;
  char date_string[MAX_MONTH_YEAR_STRING_SIZE];
  Cf("setPlannerDate");
  (void) _set_day_labels(p);
  (void) sprintf(date_string, "%s, %d", (char *) GetStrMonthFromDate(&p->date), p->date.y);
  _MONTH_LOOP(i)
  {
    if (p->date.d == p->day_values[i])
    {
      (void) gtk_signal_handler_block_by_data(GTK_OBJECT(p->day[i]), p);
      (void) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(p->day[i]), TRUE);
      (void) gtk_signal_handler_unblock_by_data(GTK_OBJECT(p->day[i]), p);
    }
    else
    {
      (void) gtk_signal_handler_block_by_data(GTK_OBJECT(p->day[i]), p);
      (void) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(p->day[i]), FALSE);
      (void) gtk_signal_handler_unblock_by_data(GTK_OBJECT(p->day[i]), p);
    }
  }
  (void) planner_date_set(p);
  (void) gtk_label_set(GTK_LABEL(p->title), date_string);
}

static void 
_set_day_labels(Planner * p)
{
  DATE tmp;
  char date[4];
  int day = 0;
  int i;
  Cf("_set_day_labels");
  tmp = p->date;
  tmp.d = 1;
  (void) SetWeekDayInDate(&tmp);
  _MONTH_LOOP(i)
  {
    if ((i >= tmp.w) && (i <= (tmp.w - 1 + days_this_month(&p->date))))
    {
      day++;
      (void) sprintf(date, "%d", day);
      (void) gtk_label_set(GTK_LABEL(p->labels[i]), date);
      p->day_values[i] = day;
    }
    else
    {
      (void) sprintf(date, " ");
      (void) gtk_label_set(GTK_LABEL(p->labels[i]), date);
      p->day_values[i] = 0;
    }
  }
}
