/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */
extern void add_app_to_list			(APPOINTMENT*, int);
extern void new_app				(GtkWidget*, gpointer);
extern void del_app				(GtkWidget*, gpointer);
extern void EditAppointment			(GtkWidget*, gpointer);
extern void select_a_app			(GtkWidget*, gint, gint,
						GdkEventButton*, gpointer);
extern void CreateApps				(void);
extern void SetAppDate				(DATE*);

extern void new_todo				(GtkWidget*, gpointer);
extern void del_todo				(GtkWidget*, gpointer);
extern void EditTodo				(GtkWidget*, gpointer);
extern void todo_select_item			(GtkWidget*, gpointer);
extern void CreateTodos				(void);

extern void CreatePBPNoteBook			(void);
extern void ShowPBPNoteBook			(void);

extern void CreatePeopleTable			(void);
extern void ShowPeopleTable			(void);
extern void SetupPeopleTable			(void);

extern void CreateBusinessesTable		(void);
extern void ShowBusinessesTable			(void);

extern GtkWidget *EditANote			(Link*);
extern GtkWidget *create_day_title_dialog	(void);
extern void aboutbox_create			(void);

extern Boolean XTimeDisplayShow			(XTimeDisplay *);
extern GtkWidget *XTimeDisplayGetWin		(XTimeDisplay *);
extern Boolean XTimeDisplaySetTime		(XTimeDisplay*, TIME*);
extern TIME * XTimeDisplayGetTime		(XTimeDisplay*);
extern XTimeDisplay * XTimeDisplayNew		(char*);
