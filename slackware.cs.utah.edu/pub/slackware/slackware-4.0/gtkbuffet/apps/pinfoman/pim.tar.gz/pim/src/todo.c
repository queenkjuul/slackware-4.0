
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/all.h"

int 
select_todo(int *todo)
{				/* Call Display list, allow choice, return choice */
  extern FILES files;
  int i = 0;
  int tmp = 0;
  *todo = -1;
  if (!disp_t_list())
  {
    i = total_records(files.todo_file, &tmp);
    if (!i)
    {
      if (tmp > 0)
      {
	printf("Please select a todo [-1 to abort] : ");
	*todo = getnum();
      }
    }
    else
    {
      error(files.todo_file, i);
    }
  }
  return i;
}

int 
disp_t_list()
{
  extern FILES files;
  int i = 0;
  int j, records;
  TODO data;
  i = total_records(files.todo_file, &records);
  if (!i)
  {
    if (records > 0)
    {
      for (j = 0; j < records; j++)
      {
	i = read_record(files.todo_file, &data, sizeof(TODO), j);
	if (!i)
	{
	  printf("%d)\t%s\n", j, data.title);
	}
	else
	{
	  error(files.todo_file, i);
	}
      }
    }
  }
  else
  {
    error(files.todo_file, i);
  }
  return i;
}

int 
visual_report_on_todo()
{				/* get choice, test it, display it */
  extern FILES files;
  int i = 0;
  int todo;
  int tst;
  total_records(files.todo_file, &tst);
  if (tst > 0)
  {
    i = select_todo(&todo);
    if ((todo >= 0) && (todo < tst))
    {
      if (!i)
      {
	i = disp_todo(todo);
      }
      else
      {
	error(files.todo_file, i);
      }
    }
  }
  return i;
}


int 
disp_todo(int pos)
{
  extern FILES files;
  int i = 0;
  TODO data;
  i = read_record(files.todo_file, &data, sizeof(TODO), pos);
  if (!i)
  {
    printf("Displaying details for \"%s\"\n", data.title);
  }
  else
  {
    error(files.todo_file, i);
  }
  return 1;
}
