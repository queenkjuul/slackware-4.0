/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/xall.h"

GtkWidget *text;
Link *linky;

static int 
save_it(GtkWidget * widget, gpointer data)
{
  (void) g_print("Saving a Note\n");
  return FALSE;
}

static int 
add_it(GtkWidget * widget, gpointer data)
{
  int x = 0;
  char *str;
  (void) g_print("Adding a Note\n");
  str = gtk_editable_get_chars(GTK_EDITABLE(text), 0, -1);
  if (AddNote(str, &x) == True)
  {
    (void) g_print("Added Note - %s\n", str);
  }
  Del(str);
  return FALSE;
}

GtkWidget *
EditANote(Link * link)
{
  GtkWidget *window = NULL;
  GtkWidget *table = NULL;
  GtkWidget *vscrollbar = NULL;
  RECORD *note = NULL;
  note = New(RECORD, 1);
  linky = link;
  note->header.id = link->right.id;
  if (ReadNoteRecord(note) == True)
  {
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    (void) gtk_signal_connect_object(GTK_OBJECT(window), "delete_event",
				     (GtkSignalFunc) save_it,
				     GTK_OBJECT(window));
    (void) gtk_widget_set_usize(window, 500, 250);
    (void) gtk_window_set_policy(GTK_WINDOW(window), TRUE, TRUE, TRUE);
    (void) gtk_window_set_title(GTK_WINDOW(window), "PinfoMan: Note System");
    (void) gtk_container_border_width(GTK_CONTAINER(window), 0);

    table = gtk_table_new(2, 2, FALSE);
    (void) gtk_container_add(GTK_CONTAINER(window), table);
    (void) gtk_widget_show(table);

    text = gtk_text_new(NULL, NULL);
    (void) gtk_table_attach_defaults(GTK_TABLE(table), text, 0, 1, 0, 1);
    (void) gtk_widget_realize(text);

    vscrollbar = gtk_vscrollbar_new(GTK_TEXT(text)->vadj);
    (void) gtk_table_attach(GTK_TABLE(table), vscrollbar, 1, 2, 0, 1,
			    GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL,
			    0, 0);
    (void) gtk_widget_show(vscrollbar);

    (void) gtk_text_freeze(GTK_TEXT(text));
    (void) gtk_text_insert(GTK_TEXT(text), NULL, NULL,
			   NULL, note->sptr, note->header.size);
    (void) gtk_text_thaw(GTK_TEXT(text));

    (void) gtk_text_set_editable(GTK_TEXT(text), TRUE);
    (void) gtk_widget_show(text);
    (void) gtk_widget_show(window);
  }
  else if (link->right.id < 0)
  {
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    (void) gtk_signal_connect_object(GTK_OBJECT(window), "delete_event",
				     (GtkSignalFunc) add_it,
				     GTK_OBJECT(window));
    (void) gtk_widget_set_usize(window, 500, 250);
    (void) gtk_window_set_policy(GTK_WINDOW(window), TRUE, TRUE, TRUE);
    (void) gtk_window_set_title(GTK_WINDOW(window), "PinfoMan: Note System");
    (void) gtk_container_border_width(GTK_CONTAINER(window), 0);
    table = gtk_table_new(2, 2, FALSE);
    (void) gtk_container_add(GTK_CONTAINER(window), table);
    (void) gtk_widget_show(table);

    text = gtk_text_new(NULL, NULL);
    (void) gtk_table_attach_defaults(GTK_TABLE(table), text, 0, 1, 0, 1);
    (void) gtk_widget_realize(text);

    vscrollbar = gtk_vscrollbar_new(GTK_TEXT(text)->vadj);
    (void) gtk_table_attach(GTK_TABLE(table), vscrollbar, 1, 2, 0, 1,
			    GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL,
			    0, 0);
    (void) gtk_widget_show(vscrollbar);

    (void) gtk_text_set_editable(GTK_TEXT(text), TRUE);
    (void) gtk_widget_show(text);
    (void) gtk_widget_show(window);
  }
  return window;
}
