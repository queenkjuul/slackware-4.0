
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/xall.h"

static void pinfomanconfig_init(PinfoManConfig *);
static void pinfomanconfig_class_init(PinfoManConfig * class);

static void 
toggle_button_callback(GtkToggleButton * widget, gpointer data)
{
  extern CONFIG settings;
  char *ptr = data;
  settings.datestyle = ptr[0];
}

static void 
change(GtkWidget * widget, GtkWidget * data)
{
  extern CONFIG settings;
  (void) strcpy(settings.username,
	(char *) gtk_entry_get_text(GTK_ENTRY(PINFOMANCONFIG(data)->text)));
  (void) gtk_widget_destroy(data);
}

guint 
pinfomanconfig_get_type()
{
  static guint p_type = 0;
  if (!p_type)
  {
    GtkTypeInfo p_info =
    {
      "PinfoManConfig",
      sizeof(PinfoManConfig),
      sizeof(PinfoManConfigClass),
      (GtkClassInitFunc) pinfomanconfig_class_init,
      (GtkObjectInitFunc) pinfomanconfig_init,
      (GtkArgSetFunc) NULL,
      (GtkArgGetFunc) NULL
    };
    p_type = gtk_type_unique(gtk_window_get_type(), &p_info);
  }
  return p_type;
}

static void 
pinfomanconfig_class_init(PinfoManConfig * class)
{}

GtkWidget *
pinfomanconfig_new()
{
  return GTK_WIDGET(gtk_type_new(pinfomanconfig_get_type()));
}

static void 
pinfomanconfig_init(PinfoManConfig * config)
{
  GtkWidget *table = NULL;
  GtkWidget *button = NULL;
  GtkWidget *button1 = NULL;
  GtkWidget *label = NULL;
  GtkWidget *option1 = NULL;
  GtkWidget *option2 = NULL;
  char *la = NULL;
  char *lb = NULL;
  extern CONFIG settings;
  Cf("pinfomanconfig_init");
  config->settings.datestyle = _ENG_DATE;
  la = New(char, 1);
  la[0] = _ENG_DATE;
  lb = New(char, 1);
  lb[0] = _USA_DATE;

  (void) gtk_window_set_title(GTK_WINDOW(config), "PinfoMan Settings");
  (void) gtk_signal_connect_object(GTK_OBJECT(config), "delete_event",
				   (GtkSignalFunc) gtk_widget_destroy,
				   GTK_OBJECT(config));

  table = gtk_table_new(5, 2, TRUE);
  (void) gtk_container_add(GTK_CONTAINER(config), table);


  label = gtk_label_new("Enter your name");
  (void) gtk_table_attach_defaults(GTK_TABLE(table), label, 0, 1, 0, 1);
  (void) gtk_widget_show(label);

  config->text = gtk_entry_new_with_max_length((guint16) 50);
  (void) gtk_table_attach_defaults(GTK_TABLE(table), config->text, 1, 2, 0, 1);
  (void) gtk_entry_set_text(GTK_ENTRY(config->text), settings.username);
  (void) gtk_widget_show(config->text);

  label = gtk_label_new("Date Style");
  (void) gtk_table_attach_defaults(GTK_TABLE(table), label, 0, 1, 1, 2);
  (void) gtk_widget_show(label);

  option1 = gtk_radio_button_new_with_label(NULL, "dd/mm/yyyy");
  (void) gtk_signal_connect_object(GTK_OBJECT(option1), "toggled",
				   GTK_SIGNAL_FUNC(toggle_button_callback),
				   (gpointer) la);
  (void) gtk_table_attach_defaults(GTK_TABLE(table), option1, 1, 2, 1, 2);
  (void) gtk_widget_show(option1);

  option2 = gtk_radio_button_new_with_label(gtk_radio_button_group(
				  GTK_RADIO_BUTTON(option1)), "mm/dd/yyyy");
  (void) gtk_signal_connect_object(GTK_OBJECT(option2), "toggled",
				   GTK_SIGNAL_FUNC(toggle_button_callback),
				   (gpointer) lb);
  (void) gtk_table_attach_defaults(GTK_TABLE(table), option2, 1, 2, 2, 3);
  (void) gtk_widget_show(option2);
  switch (settings.datestyle)
  {
  case _ENG_DATE:
    (void) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(option1), TRUE);
    break;
  case _USA_DATE:
    (void) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(option2), TRUE);
    break;
  }

  button = gtk_button_new_with_label("Ok");
  (void) gtk_signal_connect(GTK_OBJECT(button), "clicked",
			    (GtkSignalFunc) change, config);
  (void) gtk_table_attach_defaults(GTK_TABLE(table), button, 0, 1, 4, 5);
  GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
  (void) gtk_widget_grab_default(button);
  (void) gtk_widget_show(button);

  button1 = gtk_button_new_with_label("Cancel");
  (void) gtk_signal_connect_object(GTK_OBJECT(button1), "clicked",
				   (GtkSignalFunc) gtk_widget_destroy,
				   GTK_OBJECT(config));
  (void) gtk_table_attach_defaults(GTK_TABLE(table), button1, 1, 2, 4, 5);
  GTK_WIDGET_SET_FLAGS(button1, GTK_CAN_DEFAULT);
  (void) gtk_widget_show(button1);

  (void) gtk_widget_show(table);
}
