
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include"../include/xall.h"

void 
_yes_button_clicked(GtkWidget * widget, gpointer data)
{
  (void) gtk_widget_destroy(data);
}

void 
_no_button_clicked(GtkWidget * widget, gpointer data)
{
  (void) gtk_widget_destroy(data);
}

void 
yes_no_question(char question[])
{
  /*
     display a dialog box, with a title of 'title' and a
     label with 'question' and yes and no buttons.
     yes returns true, no returns false
   */
  GtkWidget *window;
  GtkWidget *label;
  GtkWidget *yes;
  GtkWidget *no;
  GtkWidget *vbox;
  GtkWidget *hbox;
  window = gtk_window_new(GTK_WINDOW_DIALOG);
  gtk_window_set_title(GTK_WINDOW(window), "Question");
  gtk_signal_connect_object(GTK_OBJECT(window), "delete_event",
			    (GtkSignalFunc) gtk_widget_destroy,
			    GTK_OBJECT(window));
  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(window), vbox);
  hbox = gtk_hbox_new(FALSE, 0);
  label = gtk_label_new(question);
  gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  yes = gtk_button_new_with_label("Yes");
  no = gtk_button_new_with_label("No");
  gtk_signal_connect(GTK_OBJECT(yes), "clicked",
		   (GtkSignalFunc) _yes_button_clicked, GTK_OBJECT(window));
  gtk_signal_connect(GTK_OBJECT(no), "clicked",
		     (GtkSignalFunc) _no_button_clicked, GTK_OBJECT(window));
  gtk_box_pack_start(GTK_BOX(hbox), yes, FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX(hbox), no, FALSE, FALSE, 0);
  gtk_widget_show(label);
  gtk_widget_show(no);
  gtk_widget_show(yes);
  gtk_widget_show(hbox);
  gtk_widget_show(vbox);
  gtk_widget_show(window);
}

void 
Init_YesNo()
{
}
