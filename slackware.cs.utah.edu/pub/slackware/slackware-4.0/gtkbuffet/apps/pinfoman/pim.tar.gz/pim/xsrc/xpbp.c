
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include"../include/xall.h"

void 
CreatePBPNoteBook()
{
  extern PimNoteBook *book;
  extern XPeople *people;
  extern XBusinesses *businesses;
  book = g_new(PimNoteBook, 1);
  book->book = gtk_notebook_new();
  book->people = gtk_frame_new(_REC_P2);
  book->businesses = gtk_frame_new(_REC_B2);
  book->project = gtk_frame_new(_REC_PRJ2);
  (void) gtk_frame_set_shadow_type(GTK_FRAME(book->project), GTK_SHADOW_ETCHED_IN);
  (void) gtk_frame_set_shadow_type(GTK_FRAME(book->businesses), GTK_SHADOW_ETCHED_IN);
  (void) gtk_frame_set_shadow_type(GTK_FRAME(book->people), GTK_SHADOW_ETCHED_IN);
  (void) CreatePeopleTable();
  (void) gtk_container_add(GTK_CONTAINER(book->people), people->main);
  (void) ShowPeopleTable();
  (void) SetupPeopleTable();
  (void) CreateBusinessesTable();
  (void) gtk_container_add(GTK_CONTAINER(book->businesses), businesses->main);
  (void) ShowBusinessesTable();
  book->people_label = gtk_label_new(_REC_P2);
  book->businesses_label = gtk_label_new(_REC_B2);
  book->project_label = gtk_label_new(_REC_PRJ2);
  book->main = gtk_vbox_new(FALSE, 0);
  (void) gtk_notebook_popup_enable(GTK_NOTEBOOK(book->book));
  (void) gtk_notebook_set_show_tabs(GTK_NOTEBOOK(book->book), FALSE);
  (void) gtk_notebook_set_show_border(GTK_NOTEBOOK(book->book), FALSE);
  (void) gtk_box_pack_start(GTK_BOX(book->main), book->book, TRUE, TRUE, 0);
  (void) gtk_notebook_append_page(GTK_NOTEBOOK(book->book), book->people, book->people_label);
  (void) gtk_notebook_append_page(GTK_NOTEBOOK(book->book), book->businesses, book->businesses_label);
  (void) gtk_notebook_append_page(GTK_NOTEBOOK(book->book), book->project, book->project_label);
  (void) gtk_widget_show(book->people);
  (void) gtk_widget_show(book->people_label);
  (void) gtk_widget_show(book->businesses);
  (void) gtk_widget_show(book->businesses_label);
  (void) gtk_widget_show(book->project);
  (void) gtk_widget_show(book->project_label);
  (void) gtk_widget_show(book->book);
}

void 
ShowPBPNoteBook()
{
  extern PimNoteBook *book;
  (void) gtk_widget_show(book->main);
}
