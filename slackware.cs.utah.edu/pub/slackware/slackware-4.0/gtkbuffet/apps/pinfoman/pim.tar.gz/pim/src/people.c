/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/all.h"

void 
get_person(int *num)
{

  cf("get_person");

  printf(_SELECT_P_STRING);
  *num = getnum();
}

int 
select_person(int *person)
{				/* Call Display list, allow choice, return choice */
  extern FILES files;
  int i = 0;
  int tmp = 0;
  PERSON pdata;
  int p;
  *person = -1;

  cf("select_person");

  if (!disp_p_list())
  {
    i = total_records(files.person_file, &tmp);
    if (tmp > 0)
    {
      get_person(&p);
      if (p >= tmp)
      {
	printf("Agghh!!  The number is too high.\n");
      }
      else if (p < 0)
      {
	printf("Agghh!!  The number is too low.\n");
      }
      else
      {
	read_record(files.person_file, &pdata, sizeof(PERSON), p);
	if (pdata.marker == Blank)
	{
	  printf("Agghh!! The record you selected does not exist\n");
	}
	else
	{
	  *person = p;
	}
      }
    }
  }
  return i;
}

int 
disp_p_list()
{
  extern FILES files;
  int errors = 0;
  int j, records;
  PERSON pdata;

  cf("disp_p_list");

  errors = total_records(files.person_file, &records);
  if (!errors)
  {
    if (records > 0)
    {
      for (j = 0; j < records; j++)
      {
	errors = read_record(files.person_file, &pdata, sizeof(PERSON), j);
	if (!errors)
	{
	  if (pdata.marker != Blank)
	  {
	    printf("%d)\t%s\n", j, pdata.title);
	  }
	}
	else
	{
	  error(files.person_file, errors);
	}
      }
    }
  }
  else
  {
    error(files.person_file, errors);
  }
  return errors;
}

int 
visual_report_on_person()
{				/* get choice, test it, display it */
  extern FILES files;
  int i = 0;
  int person;
  int tst;

  cf("visual_report_on_person");

  total_records(files.person_file, &tst);
  if (tst > 0)
  {
    i = select_person(&person);
    if ((person >= 0) && (person < tst))
    {
      if (!i)
      {
	i = disp_person(person);
      }
      else
      {
	error(files.person_file, i);
      }
    }
  }
  return i;
}


void 
search_p()
{
  printf("Searching database for a person\n");
}

int 
disp_person(int pos)
{
  extern FILES files;
  int i = 0;
  PERSON pdata;
  char temp[11];
  char *text=NULL;

  Cf("disp_person");

  i = read_record(files.person_file, &pdata, sizeof(PERSON), pos);
  if (!i)
  {
    printf("%s \"%s\"\n", _INFO_DISP_P, pdata.title);
    if (strcmp(pdata.fname, "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_GN, pdata.fname);
    }
    if (strcmp(pdata.lname, "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_FN, pdata.lname);
    }
    if (strcmp(pdata.cname, "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_CN, pdata.cname);
    }
    
    text = Gender2str(pdata.gender);
    (void) printf("%s\t\t\t: %s\n", _ADD_P_G, text);
    Del(text);
    
    date2str(temp, pdata.bd);
    if (strcmp(temp, "  /  /    ") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_B, temp);
    }
    if (strcmp(pdata.phones[0], "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_PHONE1, pdata.phones[0]);
    }
    if (strcmp(pdata.phones[1], "") != 0)
    {
      printf("%s\t\t\t: %s\n", _ADD_P_PHONE2, pdata.phones[1]);
    }
    if (strcmp(pdata.phones[2], "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_PHONE3, pdata.phones[2]);
    }
    if (strcmp(pdata.phones[3], "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_PHONE4, pdata.phones[3]);
    }
    if (strcmp(pdata.phones[4], "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_PHONE5, pdata.phones[4]);
    }
    if (strcmp(pdata.email, "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_E, pdata.email);
    }
    if (strcmp(pdata.address, "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_SA, pdata.address);
    }
    if (strcmp(pdata.city, "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_CS, pdata.city);
    }
    if (strcmp(pdata.state, "") != 0)
    {
      printf("%s\t\t\t: %s\n", _ADD_P_ST, pdata.state);
    }
    if (strcmp(pdata.post, "") != 0)
    {
      printf("%s\t\t: %s\n", _ADD_P_PC, pdata.post);
    }
    if (strcmp(pdata.country, "") != 0)
    {
      printf("%s\t\t\t: %s\n", _ADD_P_C, pdata.country);
    }
    if (strcmp(pdata.www, "") != 0)
    {
      printf("%s\t: %s\n", _ADD_P_W, pdata.www);
    }
  }
  else
  {
    error(files.person_file, i);
  }
  return 0;
}
