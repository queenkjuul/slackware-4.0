/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#define PIM_LOGO_XPM "/pim_logo.xpm"

/*static char *pinfoman_logo[] = {
"72 38 16 1",
". c #000000",
"# c #393939",
"a c #424242",
"b c #4e4e4e",
"c c #737471",
"d c #898c86",
"e c #94948c",
"f c #999996",
"g c #ffff00",
"h c none",
"i c #a5a5a5",
"j c #adadad",
"k c #b9b9b9",
"l c #cacaca",
"m c #d6d6d6",
"n c #ffffff",
"hhhhhhhhhhhhh......hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh",
"hhhhhhhhhhhh........hhhhhhhhhhhhhhhhhdddddeddhhhhhhhhhhhhhhhhhhhhhhhhihh",
"hhhhhhhhhhh..........hhhhhhhhhhhhhhhhhcccdcdddhhhhhhhhhhhhhhhhhhhhhkfcdh",
"hhhhhhhhhhh...........hhhhhhhhhhhhhhhhddcdcddddhhhhhhhhhhhhhhhhhhhkkcbdh",
"hhhhhhhhhhh...........hhhhhhhhhhhhhhhhhdddddfddfhhhhhhhhhhhhhhhhhliebihh",
"hhhhhhhhhhh.nnn.nnn...hhhhhhhhhhhhhhhhhhfedddffeihhhhhhhhhhhhhhhhkcadhhh",
"hhhhhhhhhhh.n.n.n.n...hhhhhhhhhhhhhhhhhhhdeeefeffkhhhhhhhhhhhhhhlkbbkhhh",
"hhhhhhhhhhh.n.....n...hhhhhhhhhhhhhhhhhhhifffififehhhhhhhhhhhhhlkccjhhhh",
"hhhhhhhhhhh...ggg......hhhhhhhhhhhhhhhhhhhfffiijffihhhhhhhhhhhmkiafhhhhh",
"hhhhhhhhhhh..gggggg....hhhhhhhhhhhhhhhhhhhhiiiiijjfhhhhhhhhhhhkdbdhhhhhh",
"hhhhhhhhhhh.g.ggg.g....hhhhhhhhhhhhhhhhhhhhhiijjjjjihhhhhhhhhliachhhhhhh",
"hhhhhhhhhhh..g...gg....hhhhhhhhhhhhhhhhhhhhhjkjjjkkjihhhhhhhllccfhhhhhhh",
"hhhhhhhhhhh...ggggn.....hhhhhhhhhhhhhhhhhhhhhkkkkkkkkkhhhhhhldbkhhhhhhhh",
"hhhhhhhhhh..n...nnnn....hhhhhhhhhhhhhhhhhhhhhkkkkkkkkilhhhhlfbchhhhhhhhh",
"hhhhhhhhhh.nnnnnnnnnn....hhhhhhhhhhhhhhhhhhhhhkkkkklllkkhhliachhhhhhhhhh",
"hhhhhhhhh..nnnnnnnnnn.....hhhhhhhhhhhhhhhhhhhhhkllkllkiclkibdkhhhhhhhhhh",
"hhhhhhhh...nnnnnnnnnn......hhhhhhhhhhhhhhhhhhhhhkkljmmcbkidakhhhhhhhhhhh",
"hhhhhhh....nnnnnnnnnnn.....hhhhhhhhhhhhhhhhhhhhhllkkkcclkc#ihhhhhhhhhhhh",
"hhhhhhh...nnnnnnnnnnnn......hhhhhhhhhhhhhhhhhhhhhljikblkkbahhhhhhhhhhhhh",
"hhhhhhh..nnnnnnnnnnnnnn.....hhhhhhhhhhhhhhhhhhhhhhkicjjjiiehhhhhhhhhhhhh",
"hhhhhh...nnnnnnnnnnnnnn......hhhhhhhhhhhhhhhhhhhhlf#djiieffhhhhhhhhhhhhh",
"hhhhhh...nnnnnnnnnnnnnn......hhhhhhhhhhhhhhhhhhhlkdciiffeeddhhhhhhhhhhhh",
"hhhhh...nnnnnnnnnnnnnnn......hhhhhhhhhhhhhhhhhhljdafjdddddddhhhhhhhhhhhh",
"hhhhh...nnnnnnnnnnnnnnnn.....hhhhhhhhhhhhhhhhhhkfcbhhdddddddchhhhhhhhhhh",
"hhhhh...nnnnnnnnnnnnnnn......hhhhhhhhhhhhhhhhhkdbbhhhhdiddddichhhhhhhhhh",
"hhhh.gg..nnnnnnnnnnnnn.......hhhhhhhhhhhhhhhhhdbcihhhhhciddiiddhhhhhhhhh",
"hhhh.ggg..nnnnnnnnnnn.gg....g.hhhhhhhhhhhhhhhddbfhhhhhhhdididdchhhhhhhhh",
"h...ggggg..nnnnnnnnnn.ggg.ggg.hhhhhhhhhhhhhhfcachhhhhhhhhidiiidchhhhhhhh",
".gggggggg...nnnnnnnnn.ggggggg.hhhhhhhhhhhhhfdbahhhhhhhhhhcdiiddddhhhhhhh",
".ggggggggg...nnnnnnnnn.ggggggg..hhhhhhhhhhfdbcfhhhhhhhhhhhddddddddhhhhhh",
"h.ggggggggg.nnnnnnnn...ggggggggg.hhhhhhhhfcbahhhhhhhhhhhhhhdddedddhhhhhh",
"h.ggggggggg.nnnnnnn....gggggggg.hhhhhhhhhdcachhhhhhhhhhhhhhddddddddhhhhh",
".ggggggggggg...........gggggg..hhhhhhhhhdcachhhhhhhhhhhhhhhhdedfddddhhhh",
"h..ggggggggg...........gggg..hhhhhhhhhhdcbbhhhhhhhhhhhhhhhhhddddddfdfhhh",
"hhhh...gggg...hhhhhhh..ggg.hhhhhhhhhhhfdcbhhhhhhhhhhhhhhhhhhhfdddfdfdihh",
"hhhhhhhh....hhhhhhhhhh....hhhhhhhhhhhfcbbhhhhhhhhhhhhhhhhhhhhhccccccccdh",
"hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhfbchhhhhhhhhhhhhhhhhhhhhhcbbbbbbfh",
"hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"};*/