
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/all.h"


int 
select_prj(int *prj)
{				/* Call Display list, allow choice, return choice */
  extern FILES files;
  int i = 0;
  int tmp = 0;
  *prj = -1;
  if (!disp_prj_list())
  {
    i = total_records(files.project_file, &tmp);
    if (!i)
    {
      if (tmp > 0)
      {
	printf("Please select a project [-1 to abort] : ");
	*prj = getnum();
      }
    }
    else
    {
      error(files.project_file, i);
    }
  }
  return i;
}

int 
disp_prj_list()
{
  extern FILES files;
  int i = 0;
  int j, records;
  PROJECT data;
  i = total_records(files.project_file, &records);
  if (!i)
  {
    if (records > 0)
    {
      for (j = 0; j < records; j++)
      {
	i = read_record(files.project_file, &data, sizeof(PROJECT), j);
	if (!i)
	{
	  printf("%d)\t%s\n", j, data.title);
	}
	else
	{
	  error(AFILE, i);
	}
      }
    }
  }
  else
  {
    error(files.project_file, i);
  }
  return i;
}

int 
visual_report_on_project()
{				/* get choice, test it, display it */
  extern FILES files;
  int i = 0;
  int prj;
  int tst;
  total_records(files.project_file, &tst);
  if (tst > 0)
  {
    i = select_prj(&prj);
    if ((prj >= 0) && (prj < tst))
    {
      if (!i)
      {
	i = disp_prj(prj);
      }
      else
      {
	error(files.project_file, i);
      }
    }
  }
  return i;
}


void 
search_prj()
{
/*  extern FILES files;
   char search[40];
   int i = 0;
   int j_val = 0;
   int tmp_val = 0;
   PROJECT data; */
  printf("Search the database for a project\n");
}

int 
disp_prj(int pos)
{
  extern FILES files;
  int i = 0;
  PROJECT data;
  i = read_record(files.project_file, &data, sizeof(APPOINTMENT), pos);
  if (!i)
  {
    printf("Displaying details for \"%s\"\n", data.title);
    /* DO_ME */
    /*
       Add code to ask the user what parts of the project they want to see
       People & Businesses that have been linked to the project
       Todo's and Appointments that have been linked to the project
       Note's that are linked to the project
     */
  }
  else
  {
    error(files.project_file, i);
  }
  return 0;
}
