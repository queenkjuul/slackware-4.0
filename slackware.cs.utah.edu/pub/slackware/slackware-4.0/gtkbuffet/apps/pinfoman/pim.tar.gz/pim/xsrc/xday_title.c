/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include"../include/xall.h"
DATE current_date;
GtkWidget *text;

static void 
ok(GtkWidget * widget, gpointer data)
{
  Link link;
  extern GtkWidget *day_title;
  char *string=NULL;
  (void) init_link(&link);
  string = gtk_entry_get_text(GTK_ENTRY(text));
  (void) gtk_label_set(GTK_LABEL(day_title), string);
  link.id = DoesLinkExist(DayTitle, NULL, NULL, NULL, &current_date);
  link.type = DayTitle;
  link.date = current_date;
  link.has_date = True;
  (void) strcpy(link.string, string);
  link.has_string = True;
  if(link.id < 0)
    {
      AddLink(&link);
    }
  else
    {
      WriteLink(&link);
    }
  (void) gtk_widget_destroy(GTK_WIDGET(data));
}

static void
clear(GtkWidget * widget, gpointer data)
{
  extern GtkWidget *day_title;
  int id=-1;
  (void) gtk_label_set(GTK_LABEL(day_title), "");
  id = DoesLinkExist(DayTitle, NULL, NULL, NULL, &current_date);
  if(id >= 0)
    {
      DeleteLink(id);
    }
  (void) gtk_widget_destroy(GTK_WIDGET(data));
}

GtkWidget *
create_day_title_dialog()
{
  GtkWidget *button=NULL;
  GtkWidget *hbox=NULL;
  GtkWidget *vbox=NULL;
  GtkWidget *window=NULL;
  extern GtkWidget *day_title;
  DATE *date=NULL;
  char *string=NULL;
  date = (DATE *) gtk_object_get_user_data(GTK_OBJECT(day_title));
  if(date != NULL)
    {
      current_date = *date;
      (void) gtk_label_get(GTK_LABEL(day_title), &string);

      window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
      (void) gtk_window_set_title(GTK_WINDOW (window), "Day Title");
  
      vbox = gtk_vbox_new(FALSE, 0);
      (void) gtk_container_add(GTK_CONTAINER (window), vbox);

      text = gtk_entry_new_with_max_length(50);
      (void) gtk_box_pack_start(GTK_BOX(vbox), text, FALSE, FALSE, 0);
      (void) gtk_entry_set_text(GTK_ENTRY(text), string);
      (void) gtk_widget_show(text);
  
      hbox = gtk_hbox_new(FALSE, 0);
      (void) gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);

      button = gtk_button_new_with_label("Ok");
      (void) gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 0);
      (void) gtk_signal_connect(GTK_OBJECT(button),
				"clicked",
				GTK_SIGNAL_FUNC(ok),
				window);
      (void) gtk_widget_show(button);

      button = gtk_button_new_with_label("Clear");
      (void) gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 0);
      (void) gtk_signal_connect(GTK_OBJECT(button),
				"clicked",
				GTK_SIGNAL_FUNC(clear),
				window);
      (void) gtk_widget_show(button);

      (void) gtk_widget_show(hbox);
      (void) gtk_widget_show(vbox);
    }
  return window;
}

