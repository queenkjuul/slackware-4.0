
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include"../include/xall.h"

int signal_key_thing;

void SetupAppTable();

static void 
_update(GtkWidget * widget, gpointer data)
{
  SetupAppTable();
}

static void 
_cancel(GtkWidget * widget, gpointer data)
{
}

void 
new_app(GtkWidget * widget, gpointer data)
{
  /*new button pressed*/
  extern APPS *apps;
  GtkWidget *editapp;
  editapp = editapp_new();
  (void) editapp_type(EDITAPP(editapp), EditTypeNew);
  (void) editapp_set_app(EDITAPP(editapp), NULL, NULL);
  (void) gtk_signal_connect(GTK_OBJECT(editapp), "update",
			    GTK_SIGNAL_FUNC(_update), NULL);
  (void) gtk_signal_connect(GTK_OBJECT(editapp), "cancel",
			    GTK_SIGNAL_FUNC(_cancel), NULL);
  (void) gtk_widget_show(editapp);
  (void) gtk_grab_add(editapp);
}

void 
del_app(GtkWidget * widget, gpointer data)
{
  /* delete button pressed */
  int *record = NULL;
  extern APPS *apps;
  Cf("Edit_person");
  record = (int *) gtk_clist_get_row_data(GTK_CLIST(apps->clist), apps->row);
  if (record != NULL)
  {
    DeleteAppointmentRecord(*record);
    SetupAppTable();
  }
}

void 
EditAppointment(GtkWidget * widget, gpointer data)
{
  /*edit button pressed*/
  GtkWidget *editapp = NULL;
  Link *link;
  Link lnk;
  int total=0;
  Record rec;
  APPOINTMENT app;
  extern APPS *apps;
  int *record = NULL;
  Cf("EditAppointment");
  record = (int *) gtk_clist_get_row_data(GTK_CLIST(apps->clist), apps->row);
  if(record != NULL)
  {
  app.id = *record;
  if (StartAppointmentEdit(&app) == True)
  {
    editapp = editapp_new();
    (void) editapp_type(EDITAPP(editapp), EditTypeEdit);
    (void) gtk_signal_connect(GTK_OBJECT(editapp), "update",
			      GTK_SIGNAL_FUNC(_update), NULL);
    (void) gtk_signal_connect(GTK_OBJECT(editapp), "cancel",
			      GTK_SIGNAL_FUNC(_cancel), NULL);
    rec.id = app.id;
    rec.type = AppointmentType;
    link = GetLink(rec, Appointment_Unlinked, Unlinked, &total);
    if(total == 1)
    {
      lnk = *link;
      (void) editapp_set_app(EDITAPP(editapp), &app, &lnk);
    }
    else
    {
      printf("agghh!!\n");
      return;
    }
    Del(link);
    (void) gtk_widget_show(editapp);
    (void) gtk_grab_add(editapp);
  }
  }
}

static APP_CONTROLS *
_create_app_controls()
{
  APP_CONTROLS *ctrls;
  ctrls = New(APP_CONTROLS, 1);
  ctrls->main = gtk_hbox_new(FALSE, 0);
  ctrls->new = gtk_button_new_with_label(NEWSTR);
  gtk_signal_connect(GTK_OBJECT(ctrls->new), "clicked",
		     GTK_SIGNAL_FUNC(new_app), NULL);
  ctrls->del = gtk_button_new_with_label(DELSTR);
  gtk_signal_connect(GTK_OBJECT(ctrls->del), "clicked",
		     GTK_SIGNAL_FUNC(del_app), NULL);
  ctrls->edit = gtk_button_new_with_label(EDITSTR);
  gtk_signal_connect(GTK_OBJECT(ctrls->edit), "clicked",
		     GTK_SIGNAL_FUNC(EditAppointment), NULL);
  gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->new, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->edit, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->del, TRUE, TRUE, 0);
  return ctrls;
}

void 
select_a_app(GtkWidget * widget,
             gint row, gint column,
             GdkEventButton * bevent,
             gpointer data)
{
  extern APPS *apps;
  Link *link;
  Link lnk;
  int total=0;
  Record rec;
  GtkWidget *editapp = NULL;
  APPOINTMENT app;
  int *record = NULL;
  Cf("select_a_app");
  apps->row = row;
  if ((bevent != NULL) && (widget != NULL))
  {
    switch (bevent->button)
    {
    case 1:
      if (bevent->type == GDK_2BUTTON_PRESS)
      {
	record = (int *) gtk_clist_get_row_data(GTK_CLIST(apps->clist), row);
	app.id = *record;
	if (StartAppointmentEdit(&app) == True)
	{
	  editapp = editapp_new();
	  (void) editapp_type(EDITAPP(editapp), EditTypeEdit);
	  (void) gtk_signal_connect(GTK_OBJECT(editapp), "update",
				  GTK_SIGNAL_FUNC(_update), NULL);
	  (void) gtk_signal_connect(GTK_OBJECT(editapp), "cancel",
				  GTK_SIGNAL_FUNC(_cancel), NULL);
          rec.id = app.id;
          rec.type = AppointmentType;
          link = GetLink(rec, Appointment_Unlinked, Unlinked, &total);
          if(total == 1)
          {
            lnk = *link;
            (void) editapp_set_app(EDITAPP(editapp), &app, &lnk);
          }
	  (void) gtk_widget_show(editapp);
	  (void) gtk_grab_add(editapp);
	}
      }
      break;
    case 3:
      /*
       * Popup a menu
       */
      break;
    }
  }
  else
  {
    (void) g_print("The system selected row %d\n", row);
  }
}

void 
CreateApps()
{
  extern APPS *apps;
  char *titles[] =
  {"Type", _REC_A1};
  signal_key_thing = -1;
  apps = New(APPS, 1);
  apps->main = gtk_vbox_new(FALSE, 0);
  apps->clist = gtk_clist_new_with_titles(2, titles);
  apps->ctrls = _create_app_controls();
  (void) gtk_clist_set_column_width(GTK_CLIST(apps->clist), 0, 25);
  (void) gtk_clist_set_column_width(GTK_CLIST(apps->clist), 1, 100);
  (void) gtk_clist_set_selection_mode(GTK_CLIST(apps->clist),
                                      GTK_SELECTION_BROWSE);
  (void) gtk_clist_set_policy(GTK_CLIST(apps->clist),
                              GTK_POLICY_AUTOMATIC,
                              GTK_POLICY_AUTOMATIC);
  gtk_box_pack_start(GTK_BOX(apps->main), apps->clist, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(apps->main), apps->ctrls->main, FALSE, FALSE, 0);
  signal_key_thing = (int) gtk_signal_connect(GTK_OBJECT(apps->clist),
                                  "select_row",
                                  (GtkSignalFunc) select_a_app,
                                  NULL);
  gtk_widget_show(apps->clist);
  gtk_widget_show(apps->ctrls->new);
  gtk_widget_show(apps->ctrls->del);
  gtk_widget_show(apps->ctrls->edit);
  gtk_widget_show(apps->ctrls->main);
}

void 
SetAppDate(DATE * d)
{
  extern APPS *apps;
  Cf("SetAppDate");
  if(d != NULL)
  {
    apps->date_marker = *d;
    (void) SetupAppTable();
  }
}

static void 
free_row(gpointer data)
{
  Cf("free_row");
  if (data == NULL)
  {
    (void) g_warning("%s %s\n", PROG_NAME, "data == NULL");
    return;
  }
  Del(data);
  data = NULL;
}

static void 
_add_row(GtkWidget * clist, int row, int id)
{
  int *id_data = NULL;
  Cf("_add_row");
  id_data = New(int, 1);
  if ((clist != NULL) && (id_data != NULL))
  {
    *id_data = id;
    (void) gtk_clist_set_row_data_full(GTK_CLIST(clist),
		      row, (gpointer) id_data, (GtkDestroyNotify) free_row);
  }
}

void 
SetupAppTable()
{
  extern APPS *apps;
  extern CONFIG settings;
  APPOINTMENT *app = NULL;
  int total = 0;
  char **text;
  int i = 0;
  Cf("SetupPeopleTable");
  (void) gtk_clist_clear(GTK_CLIST(apps->clist));
  (void) gtk_signal_handler_block(GTK_OBJECT(apps->clist), signal_key_thing);
  
  text = New(char *, 2);
  text[0] = New(char, 2);
  text[1] = New(char, 61);

  app = ReadAppointmentsForDate(&apps->date_marker, &total);
  if (app != NULL)
  {
    for (i = 0; i < total; i++)
    {
      (void) strcpy(text[1], app[i].title);
      text[0][0] = app[i].type;
      text[0][1] = '\0';
      (void) _add_row(apps->clist, gtk_clist_append(GTK_CLIST(apps->clist),
						      text), app[i].id);
    }
  }
  Del(text[1]);
  Del(text[0]);
  Del(text);
  Del(app);
  (void) gtk_signal_handler_unblock(GTK_OBJECT(apps->clist), signal_key_thing);
}
