







/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/all.h"

int 
select_app(int *app)
{				/* Call Display list, allow choice, return choice */
  extern FILES files;
  int i = 0;
  int tmp = 0;
  *app = -1;
  if (!disp_a_list())
  {
    i = total_records(files.appointment_file, &tmp);
    if (!i)
    {
      if (tmp > 0)
      {
	printf("Please select an appointment [-1 to abort] : ");
	*app = getnum();
      }
    }
    else
    {
      error(files.appointment_file, i);
    }
  }
  return i;
}

int 
disp_a_list()
{
  extern FILES files;
  int i = 0;
  int j, records;
  APPOINTMENT data;
  i = total_records(files.appointment_file, &records);
  if (!i)
  {
    if (records > 0)
    {
      for (j = 0; j < records; j++)
      {
	i = read_record(files.appointment_file, &data, sizeof(APPOINTMENT), j);
	if (!i)
	{
	  printf("%d)\t%s\n", j, data.title);
	}
	else
	{
	  error(files.appointment_file, i);
	}
      }
    }
  }
  else
  {
    error(files.appointment_file, i);
  }
  return i;
}

int 
visual_report_on_app()
{				/* get choice, test it, display it */
  extern FILES files;
  int i = 0;
  int app;
  int tst;
  total_records(files.appointment_file, &tst);
  if (tst > 0)
  {
    i = select_app(&app);
    if ((app >= 0) && (app < tst))
    {
      if (!i)
      {
	i = disp_app(app);
      }
      else
      {
	error(files.appointment_file, i);
      }
    }
  }
  return i;
}


void 
search_a()
{
  printf("Searching database for an appointment\n");
}

int 
disp_app(int pos)
{
  extern FILES files;
  int i = 0;
  APPOINTMENT data;
  i = read_record(files.appointment_file, &data, sizeof(APPOINTMENT), pos);
  if (!i)
  {
    printf("Displaying details for \"%s\"\n", data.title);
    /*      if(strcmp(data.start.h, "") != 0)
       {
       if(strcmp(data.start.m, "") != 0)
       { printf("Start Time\t: %s:%s\n", data.start.h, data.start.m); }
       }
       if(strcmp(data.stop.h, "") != 0)
       {
       if(strcmp(data.stop.m, "") != 0)
       { printf("Stop Time\t: %s:%s\n", data.stop.h, data.stop.m); }
       }
       if(strcmp(data.stop.h, "") != 0)
       {
       if(data.type != '\0')
       {
       printf("Appointment Type\t: %c\n", data.type);
       }
       } */
  }
  else
  {
    error(files.appointment_file, i);
  }
  return 0;
}
