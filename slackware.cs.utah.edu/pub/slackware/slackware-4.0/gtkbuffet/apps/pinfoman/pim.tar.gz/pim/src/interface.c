/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/all.h"

void 
prompt(char result[], int size)
{
  cf("prompt");
  printf("PIM> ");
  getstr(result, size);
}

void 
disp_help(int alt_command)
{
  int loop;
  int help_string_size = 14;
  char *help_string[] =
  {
    "**************************************",
    "**************************************",
    "**                                  **",
    "**       PinfoMan Help Screen       **",
    "**                                  **",
    "**            ap ep rp              **",
    "**            ab eb rb              **",
    "**         aprj eprj rprj           **",
    "**            at et rt              **",
    "**            aa ea ra              **",
    "**  compact  recover   quit  help   **",
    "**                                  **",
    "**************************************",
    "**************************************"
  };
  cf("disp_help");
  switch (alt_command)
  {
  case 0:
    for (loop = 0; loop < help_string_size; loop++)
    {
      printf("%s\n", help_string[loop]);
    }
    break;
  case 1:
    printf("The command 'ap' will add a person to the database\n");
    break;
  case 16:
    printf("The command 'compact' will remove all records that have been marked as BLANK\n");
    printf("You can't 'recover' a record after this has been done\n");
    break;
  default:
    {
      printf("Unimplemented Help Feature\n");
      break;
    }
  }
}

void 
help_error(char command[])
{
  cf("help_error");
  printf("Hmmm!!! I can't seem to find the command \"%s\"\n", command);
}
