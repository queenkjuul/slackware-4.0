/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

Boolean 
ReadNoteHeader(Header * h)
{
  extern FILES files;
  Cf("ReadNoteHeader");
  return ReadDynamicRecordHeader(files.note_file, h);
}

Boolean 
WriteNoteHeader(Header * h)
{
  extern FILES files;
  Cf("WriteNoteHeader");
  return WriteDynamicRecordHeader(files.note_file, h);
}

Boolean 
NextNoteRecord(int *id)
{
  extern FILES files;
  Cf("NextNoteRecord");
  return NextDynamicRecord(files.note_file, id);
}

Boolean 
ReadNoteRecord(Note * data)
{
  extern FILES files;
  Cf("ReadNoteRecord");
  return ReadDynamicRecord(files.note_file, data);
}

Boolean 
AppendNoteRecord(Note * data)
{
  extern FILES files;
  Cf("AppendNoteRecord");
  return AppendDynamicRecord(files.note_file, data);
}

Boolean 
DeleteNoteRecord(int id)
{
  extern FILES files;
  Cf("DeleteNoteRecord");
  return DeleteDynamicRecord(files.note_file, id);
}

Boolean 
SetupNoteRecordFile()
{
  extern FILES files;
  Cf("SetupNoteRecordFile");
  return SetupDynamicFile(files.note_file);
}

Boolean 
StartNoteEdit(int id)
{
  extern FILES files;
  Cf("StartNoteEdit");
  return StartDynamicRecordEdit(files.note_file, id);
}

Boolean 
EndNoteEdit(int id)
{
  extern FILES files;
  Cf("EndNoteEdit");
  return EndDynamicRecordEdit(files.note_file, id);
}

Boolean 
AddNote(char text[], int *id)
{
  Boolean status = False;
  extern FILES files;
  Note data;
  Cf("AddNote");
  data.sptr = text;
  data.header.size = strlen(text) + 1;
  data.header.marker = ReadWrite;
  status = AppendDynamicRecord(files.note_file, &data);
  *id = data.header.id;
  return status;
}

Boolean 
DeleteNote(int id)
{
  extern FILES files;
  Cf("DeleteNote");
  return DeleteDynamicRecord(files.note_file, id);
}
