/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

#define LANG_ENGLISH
/* record status */

#define PROG_NAME "PinfoMan"
#define PROG_AUTHOR "Lawrence Sim"
#define PROG_WWW "http://www.tne.net.au/wanderer/project/"
#define PROG_EMAIL "wanderer@tne.net.au"
#define PROG_VER "0.6.5"
#define PROG_YEAR "1998"

/* Turn Debuging on and off by comenting out this next define 
   #define DEBUG*/
#define DEBUG

/* default program file names */
#define PFILE "/people.data"
#define BFILE "/business.data"
#define TFILE "/todo.data"
#define AFILE "/appointment.data"
#define NFILE "/note.data"
#define NIFILE "/note.index.data"
#define CFILE "/pim.settings"
#define LFILE "/link.data"
#define TTFILE "/todo.types"
#define ATFILE "/appointment.types"
#define EFILE "/errors"
#define PRJFILE "/project.data"
#define FUNCS_FILE "/functions"
#define IFILE ".index"
#define RCFILE "/pimrc"

/* sort orders replace with SortOrder*/
#define ASCEND 1
#define DECEND -1

/* The size of a date string */
#define DATE_SIZE 13


/*
Get rid of these
by using True, False
*/
#define SAFE 0
#define UNSAFE 1

#define _DATE_SEPS "/|:-.+"

#define _ENG_DATE 'a'
#define _USA_DATE 'b'

#define JAN_DAYS 31
#define FEB_DAYS 28 /* except 29 on a leap year */
#define MAR_DAYS 31
#define APR_DAYS 30
#define MAY_DAYS 31
#define JUN_DAYS 30
#define JUL_DAYS 31
#define AUG_DAYS 31
#define SEP_DAYS 30
#define OCT_DAYS 31
#define NOV_DAYS 30
#define DEC_DAYS 31

#define RNeNegTot 100
#define RNeNegTotStr "The notes file states that it has a negative number of records"
#define RNeNegLiv 101
#define RNeNegLivStr "The notes file states that it has a negative number of live records"
#define RNeBadCnt 102
#define RNeBadCntStr "The notes file has a larger number of live than total records"
#define RNeCOI 103
#define RNeCOIStr "Unable to open the note index file"
#define RNeCRD 104
#define RNeCRDStr "Unable to read file info data for notes index file"
#define RNeCRA 105
#define RNeCRAStr "Unable to read entire index from note index file"

/* Error Messages */
#define _ERR_BADCALL "Bad Call to error() for file : "
#define _ERR_UOF "Unable to open file : "
#define _ERR_SEEK "Unable to seek to a record in file : "
#define _ERR_URF "Unable to read a record from file : "
#define _ERR_UWF "Unable to write a record to file : "
#define _ERR_UROF "Unable to reopen file : "
#define _ERR_USB "Unable to seek to begining of file : "
#define _ERR_URT "Unable to read the total number of records from file : "
#define _ERR_UWT "Unable to write the total number of records to file : "
#define _ERR_UCF "Unable to close file : "
#define _ERR_UAF "Unable to append a record to file : "
#define _ERR_UAM "Unable to allocate enough memory for a record from file : "
#define _ERR_SET "Your date style settings have become corrupt"
#define _ERR_BMN "Hmmm!!!  Aparently this is month"
#define _ERR_FNC_D2S "Error in function 'date2str'"
#define _ERR_FNC_S2D "Error in function 'str2date'"
#define _ERR_FNC_DTM "Error in function 'days_this_month'"
#define _ERR_FNC_AL "Error in function 'add_link'"
