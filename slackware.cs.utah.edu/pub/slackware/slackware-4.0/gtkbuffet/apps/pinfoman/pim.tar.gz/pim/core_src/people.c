/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"


static int persontitlecmp();
static int personbdcmp();
static int personfamilycmp();
static int personpostcmp();
int sort_order;

PERSON *
SortPeople(unsigned type_of_sort, int order, int *number_sorted)
{
  int loop = 0;
  PERSON tmp_person;
  int total_number = -1;
  int number = 0;
  PERSON *people = NULL;
  Cf("SortPeople");
  sort_order = order;
  *number_sorted = 0;
  if (TotalPersonRecords(&total_number) == True)
  {
    switch (type_of_sort)
    {
    case SPById:
      {
	for (loop = 0; loop < total_number; loop++)
	{
	  tmp_person.id = loop;
	  if (ReadNormalPersonRecord(&tmp_person) == True)
	  {
	    number++;
	    people = Realloc(people, PERSON, number);
	    people[number - 1] = tmp_person;
	  }
	}
	*number_sorted = number;
	/*
	   people are already in Id order, as
	   that is the order they were read in.
	 */
	break;
      }
    case SPByTitle:
      {
	for (loop = 0; loop < total_number; loop++)
	{
	  tmp_person.id = loop;
	  if (ReadNormalPersonRecord(&tmp_person) == True)
	  {
	    number++;
	    people = Realloc(people, PERSON, number);
	    people[number - 1] = tmp_person;
	  }
	}
	*number_sorted = number;
	(void) qsort(people, number, sizeof(PERSON), persontitlecmp);
	break;
      }
    case SPByBd:
      {
	for (loop = 0; loop < total_number; loop++)
	{
	  tmp_person.id = loop;
	  if (ReadNormalPersonRecord(&tmp_person) == True)
	  {
	    number++;
	    people = Realloc(people, PERSON, number);
	    people[number - 1] = tmp_person;
	  }
	}
	*number_sorted = number;
	(void) qsort(people, number, sizeof(PERSON), personbdcmp);
	break;
      }
    case SPByFamily:
      {
	for (loop = 0; loop < total_number; loop++)
	{
	  tmp_person.id = loop;
	  if (ReadNormalPersonRecord(&tmp_person) == True)
	  {
	    number++;
	    people = Realloc(people, PERSON, number);
	    people[number - 1] = tmp_person;
	  }
	}
	*number_sorted = number;
	(void) qsort(people, number, sizeof(PERSON), personfamilycmp);
	break;
      }
    case SPByPost:
      {
	for (loop = 0; loop < total_number; loop++)
	{
	  tmp_person.id = loop;
	  if (ReadNormalPersonRecord(&tmp_person) == True)
	  {
	    number++;
	    people = Realloc(people, PERSON, number);
	    people[number - 1] = tmp_person;
	  }
	}
	*number_sorted = number;
	(void) qsort(people, number, sizeof(PERSON), personpostcmp);
	break;
      }
    }
  }
  return people;
}

static int 
personfamilycmp(PERSON * p1, PERSON * p2)
{
  int val = 0;
  Cf("personfamilycmp");
  if (sort_order == SortAscend)
  {
    val = strcmp(p1->lname, p2->lname);
    if (!val)
    {
      val = strcmp(p1->fname, p2->fname);
    }
    return val;
  }
  val = strcmp(p2->lname, p1->lname);
  if (!val)
  {
    val = strcmp(p2->fname, p1->fname);
  }
  return val;
}

static int 
personbdcmp(PERSON * p1, PERSON * p2)
{
  Cf("personbdcmp");
  if (sort_order == SortAscend)
  {
    return datecmp(&p2->bd, &p1->bd);
  }
  return datecmp(&p1->bd, &p2->bd);
}

static int 
personpostcmp(PERSON * p1, PERSON * p2)
{
  int val = 0;
  Cf("personpostcmp");
  if (sort_order == SortAscend)
  {
    val = strcmp(p1->post, p2->post);
    if (!val)
    {
      val = persontitlecmp(p1, p2);
    }
    return val;
  }
  val = strcmp(p2->post, p1->post);
  if (!val)
  {
    val = persontitlecmp(p2, p1);
  }
  return val;
}

static int 
persontitlecmp(PERSON * p1, PERSON * p2)
{
  Cf("persontitlecmp");
  if (sort_order == SortAscend)
  {
    return strcmp(p1->title, p2->title);
  }
  return strcmp(p2->title, p1->title);
}

int 
personcmp(PERSON * p1, PERSON * p2)
{
  int i = 0;
  char *ps1;
  char *ps2;
  char theDate[DATE_SIZE];

  Cf("personcmp");

  ps1 = New(char, sizeof(PERSON));
  ps2 = New(char, sizeof(PERSON));

  (void) strcpy(ps1, p1->lname);
  (void) strcpy(ps2, p2->lname);
  (void) strcat(ps1, p1->fname);
  (void) strcat(ps2, p2->fname);
  (void) strcat(ps1, p1->title);
  (void) strcat(ps2, p2->title);

  (void) date2str(theDate, p1->bd);
  (void) strcat(ps1, theDate);
  (void) date2str(theDate, p2->bd);
  (void) strcat(ps2, theDate);

  /* if ps1 > ps2 return > 0 */
  /* if ps1 = ps2 return 0 */
  /* if ps1 < ps2 return < 0 */

  i = strcmp(ps1, ps2);
  Del(ps1);
  Del(ps2);
  return i;
}

Boolean 
chkperson(PERSON * p)
{
  Cf("chkperson");
  if (chkdate(&p->bd) == True)
  {
    return True;
  }
  (void) printf("%s: Bad Birthdate\n", PROG_NAME);
  return True;
}

static Boolean 
next_person_record(int *next)
{
  int records;
  PERSON data;
  Cf("next_person_record");
  *next = -1;
  if (TotalPersonRecords(&records) == True)
  {
    if (records > 0)
    {
      for (data.id = 0; data.id < records; data.id++)
      {
	if (ReadPersonRecord(&data) == True)
	{
	  if (data.marker == Blank)
	  {
	    *next = data.id;
	    return True;
	  }
	}
      }
    }
  }
  return False;
}

Boolean 
AddPerson(PERSON * p)
{
  Boolean stats = False;
  Cf("AddPerson");
  if (next_person_record(&p->id) == True)
  {
    stats = WritePersonRecord(p);
  }
  else if (TotalPersonRecords(&p->id) == True)
  {
    stats = AppendPersonRecord(p);
  }
  return stats;
}

Boolean 
IsPersonReadWrite(PERSON * p)
{
  Cf("IsPersonReadWrite");
  if (p->marker == ReadWrite)
  {
    return True;
  }
  return False;
}

Boolean 
IsPersonLocked(PERSON * p)
{
  Cf("IsPersonLocked");
  if (p->marker == Locked)
  {
    return True;
  }
  return False;
}

Boolean 
IsPersonBlank(PERSON * p)
{
  Cf("IsPersonBlank");
  if (p->marker == Blank)
  {
    return True;
  }
  return False;
}

Boolean 
IsPersonNull(PERSON * p)
{
  Cf("IsPersonNull");
  if (p->marker == Null)
  {
    return True;
  }
  return False;
}

Boolean 
SetPersonBlank(PERSON * p)
{
  Cf("SetPersonBlank");
  if (p->marker != Blank)
  {
    p->marker = Blank;
    return True;
  }
  return False;
}

Boolean 
SetPersonReadWrite(PERSON * p)
{
  Cf("SetPersonReadWrite");
  if (p->marker != ReadWrite)
  {
    p->marker = ReadWrite;
    return True;
  }
  return False;
}

Boolean 
SetPersonLocked(PERSON * p)
{
  Cf("SetPersonLocked");
  if (p->marker != Locked)
  {
    p->marker = Locked;
    return True;
  }
  return False;
}

Boolean 
SetPersonNull(PERSON * p)
{
  Cf("SetPersonNull");
  if (p->marker != Null)
  {
    p->marker = Null;
    return True;
  }
  return False;
}

Boolean 
StartPersonEdit(PERSON * p)
{
  Cf("StartPersonEdit");
  if (ReadNormalPersonRecord(p) == True)
  {
    (void) SetPersonLocked(p);
    return WritePersonRecord(p);
  }
  return False;
}

Boolean 
CancelPersonEdit(PERSON * p)
{
  Cf("CancelPersonEdit");
  if (ReadPersonRecord(p) == True)
  {
    (void) SetPersonReadWrite(p);
    if (WriteNormalPersonRecord(p) == True)
    {
      return True;
    }
  }
  return False;
}

int 
GetPersonID(PERSON * p)
{
  Cf("GetPersonID");
  return p->id;
}

Boolean 
EndPersonEdit(PERSON * p)
{
  Cf("EndPersonEdit");
  (void) SetPersonReadWrite(p);
  return WriteNormalPersonRecord(p);
}

Boolean 
TotalPersonRecords(int *num)
{
  extern FILES files;
  int records = -1;
  Cf("TotalPersonRecords");
  if (!total_records(files.person_file, &records))
  {
    *num = records;
    return True;
  }
  return False;
}

Boolean 
ReadPersonRecord(PERSON * p)
{
  extern FILES files;
  Cf("ReadPersonRecord");
  if (ReadRecord(files.person_file, p, sizeof(PERSON), p->id) == True)
  {
    return True;
  }
  return False;
}

Boolean 
AppendPersonRecord(PERSON * p)
{
  extern FILES files;
  Cf("AppendPersonRecord");
  p->marker = ReadWrite;
  if (!append_record(files.person_file, p, sizeof(PERSON)))
  {
    return True;
  }
  return False;
}

Boolean 
WritePersonRecord(PERSON * p)
{
  extern FILES files;
  Cf("WritePersonRecord");
  if (WriteRecord(files.person_file, p, sizeof(PERSON), p->id) == True)
  {
    return True;
  }
  return False;
}

Boolean 
WriteNormalPersonRecord(PERSON * p)
{
  extern FILES files;
  Cf("WritePersonRecord");
  p->marker = ReadWrite;
  if (WritePersonRecord(p) == True)
  {
    return True;
  }
  return False;
}

Boolean 
DeletePersonRecord(int id)
{
  PERSON p;
  Cf("DeletePersonRecord");
  p.id = id;
  if (ReadNormalPersonRecord(&p) == True)
  {
    SetPersonBlank(&p);
    if (WritePersonRecord(&p) == True)
    {
      return True;
    }
  }
  return False;
}

Boolean 
ReadNormalPersonRecord(PERSON * p)
{
  PERSON person;
  person.id = p->id;
  if (ReadPersonRecord(&person) == True)
  {
    if (person.marker != Blank)
    {
      *p = person;
      return True;
    }
  }
  return False;
}

Gender
str2Gender(char text[])
{
  if(text == NULL)
  { return Unknown; }
  
  if((text[0] == GENDER_MALE_CAP) || (text[0] == GENDER_MALE_NOCAP))
  { return Male; }
  
  if((text[0] == GENDER_FEMALE_CAP) || (text[0] == GENDER_FEMALE_NOCAP))
  { return Female; }
  return Unknown;
}

char *
Gender2str(Gender g)
{
  char *str=NULL;
  switch(g)
  {
    case Male:
      str = New(char, strlen(GENDER_MALE_STR) + 1);
      (void) strcpy(str, GENDER_MALE_STR);
      break;
    case Female:
      str = New(char, strlen(GENDER_FEMALE_STR) + 1);
      (void) strcpy(str, GENDER_FEMALE_STR);
      break;
    case Unknown:
      str = New(char, strlen(GENDER_UNKNOWN_STR) + 1);
      (void) strcpy(str, GENDER_UNKNOWN_STR);
      break;
  }
  return str;
}
