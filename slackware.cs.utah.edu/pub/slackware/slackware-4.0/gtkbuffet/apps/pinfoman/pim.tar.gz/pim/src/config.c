
/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/all.h"
#include<ctype.h>
int 
setup()
{
  extern FILES files;
  int i = 0;
  char temp[5];
  extern CONFIG settings;
  (void) wipe_cf();

  (void) cf("setup");
  if (settings.firstrun)
  {
    settings.firstrun = 0;

    (void) printf(_QUEST_NAME);

    (void) getstr(settings.username, sizeof(settings.username));
    do
    {
      printf(_QUEST_DATESTYLE);
      getstr(temp, sizeof(temp));
      settings.datestyle = tolower(temp[0]);
    }
    while (chkdate_style(temp[0]) == False);

    if (SetupNoteRecordFile() == True)
    {
      printf(_INFO_IF, _REC_N1);
    }
    else
    {
      error(files.note_file, i);
    }

    i = setup_file(files.appointment_file);
    if (!i)
    {
      printf(_INFO_IF, _REC_A1);
    }
    else
    {
      error(files.appointment_file, i);
    }

    i = setup_file(files.todo_file);
    if (!i)
    {
      printf(_INFO_IF, _REC_T1);
    }
    else
    {
      error(files.todo_file, i);
    }

    i = setup_file(files.link_file);
    if (!i)
    {
      printf(_INFO_IF, _REC_L1);
    }
    else
    {
      error(files.link_file, i);
    }

    i = setup_file(files.person_file);
    if (!i)
    {
      printf(_INFO_IF, _REC_P1);
    }
    else
    {
      error(files.person_file, i);
    }

    i = setup_file(files.business_file);
    if (!i)
    {
      printf(_INFO_IF, _REC_B1);
    }
    else
    {
      error(files.business_file, i);
    }

    i = setup_file(files.project_file);
    if (!i)
    {
      printf(_INFO_IF, _REC_PRJ1);
    }
    else
    {
      error(files.project_file, i);
    }
  }
  return i;
}
