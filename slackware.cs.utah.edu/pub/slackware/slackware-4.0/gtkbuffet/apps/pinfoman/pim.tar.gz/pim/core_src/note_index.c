/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

Boolean 
read_note_index(INDEX index[])
{
  extern FILES files;
  Cf("read_note_index");
  if (!read_index(files.note_file, index))
  {
    return True;
  }
  return False;
}

Boolean 
write_note_index(INDEX index[], int len)
{
  extern FILES files;
  Cf("write_note_index");
  if (!write_index(files.note_file, index, len))
  {
    return True;
  }
  return False;
}

int 
_setup_note_index_file()
{
  extern FILES files;
  Cf("_setup_note_index_file");
  return setup_index_file(files.note_file);
}
