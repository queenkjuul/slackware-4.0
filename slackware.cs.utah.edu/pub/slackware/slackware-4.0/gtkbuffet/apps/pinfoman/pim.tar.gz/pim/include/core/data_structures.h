/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

typedef long INDEX;

typedef struct
{
  int id;
  RecordType type:4;
} Record;

typedef struct
{
  int total_records;
  int live_records;
  RecordState marker:2;
} DFI;

typedef struct
{
  unsigned w:3;		/* Week Day */
  unsigned d:5;		/* Day */
  unsigned m:4;		/* Month */
  unsigned y:20;	/* Year */
} DATE;

typedef struct
{
  unsigned h:5;
  unsigned m:6;
} TIME;

typedef struct
{
  char title[52];
  char fname[22];
  char lname[22];
  char cname[32];
  DATE bd;
  char phones[5][22];
  char address[62];
  char address_line2[62];
  char country[32];
  char city[32];
  char state[22];
  char post[12];
  char email[52];
  char www[52];
  int id;		/* record id */
  Boolean has_note:1;	/* True or False */
  RecordState marker:2;
  Gender gender:2;
} PERSON;

typedef struct
{
  char bname[50];
  char cnum[10];
  char address[60];
  char city[30];
  char state[20];
  char post[6];
  char country[20];
  char www[50];
  char ftp[50];
  /* area of business */
  int id;
  RecordState marker:2;
} BUSINESS;

typedef struct
{
  char type;
  char title[60];
  /* Start date comes from the link */
  DATE stop;
  int id;
  RecordState marker:2;
} TODO;

typedef struct
{
  TIME start;
  TIME stop;
  char title[60];
  char type;
  int id;
  RecordState marker:2;
} APPOINTMENT;

typedef struct
{
  unsigned firstrun;
  char username[60];
  char datestyle;
  
  unsigned person_sort_style;
  Record owner;
} CONFIG;

typedef struct
{
  char *person_file;
  char *project_file;
  char *business_file;
  char *appointment_file;
  char *todo_file;
  char *link_file;
  char *note_file;
  char *errors_file;
  char *functions_file;
  char *todo_types_file;
  char *appointment_types_file;
  char *config_file;
  char *home_dir;
} FILES;

typedef struct
{
  char type;
  char data[256];
} TODO_TYPES;

typedef struct
{
  char type;
  char data[256];
} APPOINTMENT_TYPES;

typedef struct
{
  char title[50];
  DATE start;
  DATE end;
  RecordState marker:2;
} PROJECT;

typedef struct
{
 int size;	/* the size of the dynamic record */
 int id;	/* the id of the dynamic record */
 long position;	/* the position of the dynamic record */
 RecordState marker:2;
} Header;

typedef Header HEADER;

typedef struct
{
  Header header;
  char *sptr;
} Note;

typedef Note RECORD;

typedef struct
{
  /*
    A transaction is a new kind of link
    that tracks the flow of money.
  */
  DATE date;
  float amount;
  Record from;
  Record to;
  Boolean has_to:1;
  Boolean has_from:1;
  TransactionFormat format:5;
  RecordState marker:2;
} Transaction;

typedef struct
{
  char string[50]; /* remove this one somehow */
  DATE date;
  int id;
  Record left;
  Record right;
  TypeOfLink type:5;
  SecondaryLinkType stype:3;
  Boolean has_stype:1;
  Boolean has_left:1;
  Boolean has_right:1;
  Boolean has_date:1;
  Boolean has_string:1;
  RecordState marker:2;
} Link;

typedef struct
{
  TransactionFormat format:5;
  float rate; /* amount >< $US */
} ExchangeRate;
