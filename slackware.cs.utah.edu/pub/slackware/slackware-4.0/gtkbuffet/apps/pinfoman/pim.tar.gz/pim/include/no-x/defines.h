/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

#define TRUE 1
#define FALSE 0

/* Selection Strings */
#define _SELECT_P_STRING "Please select a person [-1 to abort] : "
#define _SELECT_B_STRING "Please select a business [-1 to abort] : "
#define _SELECT_PRJ_STRING "Please select a project [-1 to abort] : "
#define _SELECT_A_STRING "Please select an appointment [-1 to abort] : "
#define _SELECT_T_STRING "Please select a todo [-1 to abort] : "
#define _SELECT_N_STRING "Please select a note [-1 to abort] : "
#define _INFO_P_ADDED "%s has been added to the database\n"
#define _INFO_P_NADDED "%s can not been added to the database\n"
#define _INFO_MSG001 "There are currently in the database...\n"
#define _INFO_DISP_P "Displaying personal details for"

/* general questions */
#define _QUEST_NAME "Please enter your name : "
#define _QUEST_CORRECT "Are you sure the details above are correct [Y/N/A] : "
#define _QUEST_DATESTYLE "Date Style\na)\t[dd/mm/yyyy]\nb)\t[mm/dd/yyyy]\t: "
#define _QUEST_FIELDCHANGE "Which field would you like to change [-1 to end changes] : "

/* Information strings */
#define _INFO_ORIG "Original"
#define _INFO_IF "The %s file has been initialised\n"
#define _INFO_W "Welcome"
#define _INFO_Q "Quitting\n"
#define _INFO_ADD_NOTE "Before anything else, a note MUST be attatched to the back end\nof a link, so it can be linked to another item, or a date.\n"