/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

static Boolean 
next_appointment_record(int *next)
{
  int records = 0;
  APPOINTMENT data;
  *next = -1;
  if (TotalAppointmentRecords(&records) == True)
  {
    if (records > 0)
    {
      for (data.id = 0; data.id < records; data.id++)
      {
	if (ReadAppointmentRecord(&data) == True)
	{
	  if (data.marker == Blank)
	  {
	    *next = data.id;
	    return True;
	  }
	}
      }
    }
  }
  return False;
}

Boolean 
AddAppointment(APPOINTMENT * app)
{
  Boolean stats = False;
  if (next_appointment_record(&app->id) == True)
  {
    stats = WriteAppointmentRecord(app);
  }
  else if(TotalAppointmentRecords(&app->id) == True)
  {
    stats = AppendAppointmentRecord(app);
  }
  return stats;
}

Boolean 
StartAppointmentEdit(APPOINTMENT * app)
{
  if (ReadAppointmentRecord(app) == True)
  {
    SetpRecordStats(app, Locked);
    return WriteAppointmentRecord(app);
  }
  return False;
}

Boolean 
CancelAppointmentEdit(APPOINTMENT * app)
{
  if (ReadAppointmentRecord(app) == True)
  {
    SetpRecordStats(app, ReadWrite);
    return WriteAppointmentRecord(app);
  }
  return False;
}

Boolean 
EndAppointmentEdit(APPOINTMENT * app)
{
  SetpRecordStats(app, ReadWrite);
  return WriteAppointmentRecord(app);
}

Boolean 
TotalAppointmentRecords(int *num)
{
  extern FILES files;
  int records = -1;
  if (!total_records(files.appointment_file, &records))
  {
    *num = records;
    return True;
  }
  return False;
}

Boolean 
ReadAppointmentRecord(APPOINTMENT * app)
{
  extern FILES files;
  unsigned size = 0;
  size = sizeof(APPOINTMENT);
  if (ReadRecord(files.appointment_file, app, size, app->id) == True)
  {
    return True;
  }
  return False;
}

Boolean 
ReadNormalAppointmentRecord(APPOINTMENT * app)
{
  extern FILES files;
  APPOINTMENT tmp;
  unsigned size = 0;
  size = sizeof(APPOINTMENT);
  if (ReadRecord(files.appointment_file, &tmp, size, app->id) == True)
  {
    if(tmp.marker == ReadWrite)
    {
      *app = tmp;
      return True;
    }
  }
  return False;
}

Boolean 
AppendAppointmentRecord(APPOINTMENT * app)
{
  extern FILES files;
  app->marker = ReadWrite;
  if (!append_record(files.appointment_file, app, sizeof(APPOINTMENT)))
  {
    return True;
  }
  return False;
}

Boolean 
WriteAppointmentRecord(APPOINTMENT * app)
{
  extern FILES files;
  int size=0;
  size = sizeof(APPOINTMENT);
  if (WriteRecord(files.appointment_file, app, size, app->id) == True)
  {
    return True;
  }
  return False;
}

Boolean 
DeleteAppointmentRecord(int id)
{
  APPOINTMENT app;
  Cf("DeletePersonRecord");
  app.id = id;
  if (ReadNormalAppointmentRecord(&app) == True)
  {
    app.marker = Blank;
    if (WriteAppointmentRecord(&app) == True)
    {
      return True;
    }
  }
  return False;
}

APPOINTMENT *
ReadAppointmentsForDate(DATE * d, int *found)
{
  APPOINTMENT *apps = NULL;
  APPOINTMENT tmp;
  Link link;
  int records = 0;
  int links = 0;

  *found = 0;

  if (TotalAppointmentRecords(&records) == True)
  {
    if (TotalLinks(&links) == True)
    {
      for (link.id = 0; link.id < links; link.id++)
      {
	if (ReadNormalLink(&link) == True)
        {
          if(link.has_left == True)
          {
            if (link.left.type == AppointmentType)
            {
              if(link.has_date == True)
              {
                if (!datecmp(&link.date, d))
                {
                  tmp.id = link.left.id;
                  if (ReadAppointmentRecord(&tmp) == True)
                  {
                    (*found)++;
                    apps = Realloc(apps, APPOINTMENT, *found);
                    apps[*found - 1] = tmp;
                  }
                }
              }
            }
	  }
	}
      }
    }
  }
  return apps;
}
