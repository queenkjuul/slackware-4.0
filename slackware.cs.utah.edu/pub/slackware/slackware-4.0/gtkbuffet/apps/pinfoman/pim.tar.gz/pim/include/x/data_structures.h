/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

typedef struct
{
  GtkWidget *main_window;
  GtkWidget *hours;
  GtkWidget *mins;
} XTimeDisplay;

typedef struct
{
  gint row;
  gint id;
} ROW2ID;

typedef struct
{
  GtkWidget *new;
  GtkWidget *del;
  GtkWidget *edit;
  GtkWidget *main;
} CONTROLS, TODO_CONTROLS, APP_CONTROLS;

typedef struct
{
  GtkWidget *clist;
  GtkWidget *main;
  TODO_CONTROLS *ctrls;
  ROW2ID *links;
} TODOS;

typedef struct
{
  GtkWidget *main;
  GtkWidget *clist;
  CONTROLS *ctrls;
  int num;
  int row;
  int *links;
  DATE date_marker;
} APPS;

typedef struct
{
  GtkWidget *main;
  GtkWidget *book;
  GtkWidget *people;
  GtkWidget *businesses;
  GtkWidget *project;
  GtkWidget *people_label;
  GtkWidget *businesses_label;
  GtkWidget *project_label;
} PimNoteBook;

typedef struct
{
  GtkWidget *main;
  GtkWidget *clist;
  CONTROLS *ctrls;
  GtkWidget *nick;
  GtkWidget *phone[4];
  GtkWidget *bd;
  GtkWidget *email;
  GtkWidget *table;
  int num;
  int row;
  int *links;
} XPeople;

typedef struct
{
  GtkWidget *main;
  GtkWidget *clist;
  CONTROLS *ctrls;
  ROW2ID *links;
} XBusinesses;

typedef enum
{
 EditTypeNew,
 EditTypeEdit
} EditOption;
