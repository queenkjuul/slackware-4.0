/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include"../include/xall.h"

void 
new_todo(GtkWidget * widget, gpointer data)
{
  g_print("Entering a new Todo\n");
}

void 
del_todo(GtkWidget * widget, gpointer data)
{
  g_print("Deleting a Todo\n");
}

void 
EditTodo(GtkWidget * widget, gpointer data)
{
  g_print("Editing a Todo\n");
}

static TODO_CONTROLS *
_create_todo_controls()
{
  TODO_CONTROLS *ctrls;
  ctrls = g_new(TODO_CONTROLS, 1);
  ctrls->main = gtk_hbox_new(FALSE, 0);
  ctrls->new = gtk_button_new_with_label(NEWSTR);
  gtk_signal_connect(GTK_OBJECT(ctrls->new), "clicked",
		     GTK_SIGNAL_FUNC(new_todo), NULL);
  ctrls->del = gtk_button_new_with_label(DELSTR);
  gtk_signal_connect(GTK_OBJECT(ctrls->del), "clicked",
		     GTK_SIGNAL_FUNC(del_todo), NULL);
  ctrls->edit = gtk_button_new_with_label(EDITSTR);
  gtk_signal_connect(GTK_OBJECT(ctrls->edit), "clicked",
		     GTK_SIGNAL_FUNC(EditTodo), NULL);
  gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->new, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->edit, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->del, TRUE, TRUE, 0);
  return ctrls;
}

static void 
_showTodoControls()
{
  extern TODOS *todos;
  gtk_widget_show(todos->ctrls->new);
  gtk_widget_show(todos->ctrls->del);
  gtk_widget_show(todos->ctrls->edit);
  gtk_widget_show(todos->ctrls->main);
}

void 
todo_select_item(GtkWidget * widget, gpointer data)
{
  g_print("Selected a Todo\n");
}

void 
CreateTodos()
{
  extern TODOS *todos;
  char *titles[] =
  {"Type", _REC_T2};

  todos = g_new(TODOS, 1);
  todos->clist = gtk_clist_new_with_titles(2, titles);
  /*
     (void) gtk_clist_set_row_height(GTK_CLIST(todos->clist), 20);
     (void) gtk_clist_set_border(GTK_CLIST(todos->clist), 10);
   */
  gtk_widget_set_usize(todos->clist, 200, 100);
  (void) gtk_signal_connect(GTK_OBJECT(todos->clist), "select_row", (GtkSignalFunc) todo_select_item, NULL);
  (void) gtk_clist_set_column_width(GTK_CLIST(todos->clist), 0, 25);
  (void) gtk_clist_set_selection_mode(GTK_CLIST(todos->clist), GTK_SELECTION_SINGLE);
  (void) gtk_clist_set_policy(GTK_CLIST(todos->clist), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  todos->main = gtk_vbox_new(FALSE, 0);
  todos->ctrls = _create_todo_controls();
  (void) gtk_box_pack_start(GTK_BOX(todos->main), todos->clist, TRUE, TRUE, 0);
  (void) gtk_box_pack_start(GTK_BOX(todos->main), todos->ctrls->main, FALSE, FALSE, 0);
  (void) gtk_widget_show(todos->clist);
  (void) _showTodoControls();
}
