/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

char 
statproject(PROJECT prj)
{
  return prj.marker;
}

int 
next_project_record(int *next)
{
  extern FILES files;
  int errors = 0;
  int records;
  int loop;
  PROJECT data;
  *next = -1;
  errors = total_records(files.project_file, &records);
  if (!errors)
  {
    if (records > 0)
    {
      for (loop = 0; loop < records; loop++)
      {
	errors = read_record(files.project_file, &data, sizeof(PROJECT), loop);
	if (!errors)
	{
	  if (statproject(data) == Blank)
	  {
	    *next = loop;
	    loop = records;
	  }
	}
	else
	{
	  error(files.project_file, errors);
	}
      }
    }
  }
  else
  {
    error(files.project_file, errors);
  }
  return errors;
}
