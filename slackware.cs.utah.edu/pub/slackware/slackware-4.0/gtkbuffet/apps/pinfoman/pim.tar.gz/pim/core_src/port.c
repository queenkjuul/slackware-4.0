/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/core.h"

PERSON *
ImportPeople(char *fname[], int type, int *num)
{
  int i = -1;
  int records = -1;
  PERSON *people = NULL;
  PERSON *pptr = NULL;
  pptr = New(PERSON, 1);
  Cf("ImportPeople");
  switch (type)
  {
  case ASCII_IO_TYPE:
    /*
       import an ascii table.
     */
    break;
  case PINFOMAN_TYPE:
    if (TotalPersonRecords(&records) == True)
    {
      people = New(PERSON, records);
      for (i = 0; i < records; i++)
      {
	people.id = i;
	if (readPersonRecord(&people[i]) == True)
	{
	  *num = i + 1;
	}
      }
      *num = records;
    }
    break;
  }
  return people;
}

void 
ImportNote(char fname[], RECORD * note)
{
  Cf("ImportNote");
}
void 
ExportNote(char fname[], RECORD * note)
{
  Cf("ExportNote");
}
