/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/xall.h"

enum
  {
    YES,
    NO,
    LAST_SIGNAL
  };


static void msgbox_class_init (MsgBoxClass * klass);
static void msgbox_init (Msgbox * msgbox);
static void _yes (GtkWidget * widget, gpointer data);
static void _no (GtkWidget * widget, gpointer data);

static unsigned int msg_sigs[LAST_SIGNAL] =
{0};

guint 
msgbox_get_type ()
{
  static guint p_type = 0;
  if (!p_type)
    {
      GtkTypeInfo p_info =
      {
	"MsgBox",
	sizeof (MsgBox),
	sizeof (MsgBoxClass),
	(GtkClassInitFunc) msgbox_class_init,
	(GtkObjectInitFunc) msgbox_init,
	(GtkArgSetFunc) NULL,
	(GtkArgGetFunc) NULL
      };
      p_type = gtk_type_unique (gtk_window_get_type (), &p_info);
    }
  return p_type;
}

static void 
msgbox_class_init (MsgBoxClass * class)
{
  GtkObjectClass *object_class;
  object_class = (GtkObjectClass *) class;
  msg_sigs[YES] = gtk_signal_new ("yes",
				  GTK_RUN_FIRST,
				  object_class->type,
				  GTK_SIGNAL_OFFSET (MsgBoxClass,
						     yes),
				  gtk_signal_default_marshaller,
				  GTK_TYPE_NONE, 0);
  msg_sigs[NO] = gtk_signal_new ("no",
				 GTK_RUN_FIRST,
				 object_class->type,
				 GTK_SIGNAL_OFFSET (MsgBoxClass,
						    no),
				 gtk_signal_default_marshaller,
				 GTK_TYPE_NONE, 0);
  (void) gtk_object_class_add_signals (object_class,
				       msg_sigs,
				       LAST_SIGNAL);
  class->yes = NULL;
  class->no = NULL;
}

GtkWidget *
msgbox_new ()
{
  return GTK_WIDGET (gtk_type_new (msgbox_get_type ()));
}

static void 
msgbox_init (EditPerson * msg)
{
  GtkWidget *vbox;
  GtkWidget *box;
  GtkWidget *hbox;
  GtkWidget *phones;
  GtkWidget *display;
  GtkWidget *details;
  GtkWidget *controls;
  GtkWidget *button;
  GtkWidget *label;
  GtkWidget *menubar;
  GtkWidget *menu;
  GtkWidget *item;
  GtkWidget *text;
  GtkWidget *details_frame;
  GtkWidget *phones_frame;

  (void) gtk_window_set_title (GTK_WINDOW (ep),
			       "PinfoMan: Question");

  button = gtk_button_new_with_label ("Yes");
  (void) gtk_signal_connect (GTK_OBJECT (button),
			     "clicked",
			     GTK_SIGNAL_FUNC (_yes),
			     EDITPERSON (ep));
  (void) gtk_widget_show (button);

  button = gtk_button_new_with_label ("Cancel");
  (void) gtk_signal_connect (GTK_OBJECT (button),
			     "clicked",
			     GTK_SIGNAL_FUNC (_cancel_clicked),
			     EDITPERSON (ep));
  (void) gtk_box_pack_start (GTK_BOX (controls), button, TRUE, TRUE, 0);
  (void) gtk_widget_show (button);

  (void) gtk_container_add (GTK_CONTAINER (ep), vbox);
  (void) gtk_widget_show (vbox);
}

static void 
_yes (GtkWidget * widget, gpointer data)
{
  (void) gtk_signal_emit (GTK_OBJECT (data), msg_sigs[YES]);
  (void) gtk_widget_destroy (data);
}

static void 
_no (GtkWidget * widget, gpointer data)
{
  (void) gtk_signal_emit (GTK_OBJECT (data), msg_sigs[NO]);
  (void) gtk_widget_destroy (data);
}

GtkWidget *window;
GtkWidget *label;
GtkWidget *yes;
GtkWidget *no;
GtkWidget *vbox;
GtkWidget *hbox;
window = gtk_window_new (GTK_WINDOW_DIALOG);
gtk_window_set_title (GTK_WINDOW (window), "Question");
gtk_signal_connect_object (GTK_OBJECT (window), "delete_event",
			   (GtkSignalFunc) gtk_widget_destroy,
			   GTK_OBJECT (window));
vbox = gtk_vbox_new (FALSE, 0);
gtk_container_add (GTK_CONTAINER (window), vbox);
hbox = gtk_hbox_new (FALSE, 0);
label = gtk_label_new (question);
gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
yes = gtk_button_new_with_label ("Yes");
no = gtk_button_new_with_label ("No");
gtk_signal_connect (GTK_OBJECT (yes), "clicked",
		  (GtkSignalFunc) _yes_button_clicked, GTK_OBJECT (window));
gtk_signal_connect (GTK_OBJECT (no), "clicked",
		    (GtkSignalFunc) _no_button_clicked, GTK_OBJECT (window));
gtk_box_pack_start (GTK_BOX (hbox), yes, FALSE, FALSE, 0);
gtk_box_pack_start (GTK_BOX (hbox), no, FALSE, FALSE, 0);
gtk_widget_show (label);
gtk_widget_show (no);
gtk_widget_show (yes);
gtk_widget_show (hbox);
gtk_widget_show (vbox);
gtk_widget_show (window);
}
