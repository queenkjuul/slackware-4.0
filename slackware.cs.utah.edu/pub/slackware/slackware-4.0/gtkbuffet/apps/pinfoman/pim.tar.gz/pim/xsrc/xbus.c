/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include"../include/xall.h"

static CONTROLS *
_create_businesses_controls()
{
  CONTROLS *ctrls;
  ctrls = New(APP_CONTROLS, 1);
  ctrls->main = gtk_hbox_new(FALSE, 0);
  ctrls->new = gtk_button_new_with_label(NEWSTR);
  /*
     gtk_signal_connect (GTK_OBJECT (ctrls->new), "clicked",
     GTK_SIGNAL_FUNC (new_app), NULL);
   */
  ctrls->del = gtk_button_new_with_label(DELSTR);
  /*
     gtk_signal_connect (GTK_OBJECT (ctrls->del), "clicked",
     GTK_SIGNAL_FUNC (del_app), NULL);
   */
  ctrls->edit = gtk_button_new_with_label(EDITSTR);
  /*
     gtk_signal_connect (GTK_OBJECT (ctrls->edit), "clicked",
     GTK_SIGNAL_FUNC (EditApp), NULL);
   */
  gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->new, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->edit, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(ctrls->main), ctrls->del, TRUE, TRUE, 0);
  return ctrls;
}

void 
CreateBusinessesTable()
{
  extern XBusinesses *businesses;
  char *titles[] =
  {_REC_B2};
  businesses = g_new(XBusinesses, 1);
  businesses->main = gtk_vbox_new(FALSE, 0);
  businesses->clist = gtk_clist_new_with_titles(1, titles);
  businesses->ctrls = _create_businesses_controls();
  (void) gtk_clist_set_column_width(GTK_CLIST(businesses->clist), 1, 100);
  (void) gtk_clist_set_selection_mode(GTK_CLIST(businesses->clist), GTK_SELECTION_BROWSE);
  (void) gtk_clist_set_policy(GTK_CLIST(businesses->clist), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_box_pack_start(GTK_BOX(businesses->main), businesses->clist, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(businesses->main), businesses->ctrls->main, FALSE, FALSE, 0);
  gtk_widget_show(businesses->clist);
  gtk_widget_show(businesses->ctrls->new);
  gtk_widget_show(businesses->ctrls->del);
  gtk_widget_show(businesses->ctrls->edit);
  gtk_widget_show(businesses->ctrls->main);
}

void 
ShowBusinessesTable()
{
  extern XBusinesses *businesses;
  gtk_widget_show(businesses->main);
}
