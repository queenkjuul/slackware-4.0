/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

#ifndef __LINK_H__
#define __LINK_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define LINKLIST(obj)          GTK_CHECK_CAST (obj, linklist_get_type (), LinkList)
#define LINKLIST_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, linklist_get_type (), LinkListClass)
#define IS_LINKLIST(obj)       GTK_CHECK_TYPE (obj, linklist_get_type ())

typedef struct
{
  char string[60];
  Record record;
} LinkItem;

typedef struct _LinkList     	LinkList;
typedef struct _LinkListClass	LinkListClass;

struct _LinkList
{
  GtkCombo combo;
/*  GtkOptionMenu option_menu;*/
  int number_of_records;
  LinkItem *records;
  RecordType type:4;
};

struct _LinkListClass
{
  GtkComboClass parent_class;
};

extern guint linklist_get_type(void);
extern GtkWidget *linklist_new();
extern void linklist_set(LinkList *, RecordType, Record *);
extern Record *linklist_get(LinkList *);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __LINK_H__ */
