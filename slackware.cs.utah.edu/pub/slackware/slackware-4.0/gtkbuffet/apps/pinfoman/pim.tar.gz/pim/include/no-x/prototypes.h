/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

/* pim.c FIXED */
void doit(char result[]);
void do_a_funcs(char data[]);
void do_d_funcs(char data[]);
void do_e_funcs(char data[]);
void do_r_funcs(char data[]);
void do_h_funcs(char data[]);
void do_other_funcs(char data[]);
int stats();

/* aer.c FIXED */
void add_project();
void edit_project();
void rem_project();
void add_note();
void edit_note();
void rem_note();
void add_app();
void edit_app();
void rem_app();
void add_todo();
void edit_todo();
void rem_todo();
void add_person();
void edit_person();
void rem_person();
void add_business();
void edit_business();
void rem_business();

/* appointment.c */
int disp_app(int pos);
int disp_a_list();
int select_app(int *app);
int visual_report_on_app();


/* business.c */
int disp_business(int pos);
int disp_b_list();
int select_business(int *bus);
int visual_report_on_business();


/* config.c */
int setup();

/* general.c */
void disp_error(char text[]);

/* interface.c */
void prompt(char result[], int size);
void disp_help(int alt_command);
void help_error(char command[]);

/* note.c */
int disp_note(int note);

/* people.c */
int disp_person(int pos);
int disp_p_list();
int select_person(int *person);
int visual_report_on_person();
void search_p();

/* project.c */
int disp_prj(int pos);
int disp_prj_list();
int select_prj(int *prj);
int visual_report_on_project();
void search_prj();

/* todo.c */
int disp_todo(int pos);
int disp_t_list();
int select_todo(int *todo);
int visual_report_on_todo();

/* input.c */
int getnum();
int getstr(char data[], int size);
char *GetDynamicStr();
char *GetDynamicStrOfSize(int size);

/* output.c */
void DisplayMenu(char **, int);

extern Boolean DisplayNote(int);
extern char *GetNoteFromUser(char *);
