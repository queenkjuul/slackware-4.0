/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/xall.h"

static void linklist_class_init(LinkListClass * klass);
static void linklist_init(LinkList * list);

guint 
linklist_get_type()
{
  static guint p_type = 0;
  Cf("linklist_get_type");
  if (!p_type)
  {
    GtkTypeInfo p_info =
    {
      "LinkList",
      sizeof(LinkList),
      sizeof(LinkListClass),
      (GtkClassInitFunc) linklist_class_init,
      (GtkObjectInitFunc) linklist_init,
      (GtkArgSetFunc) NULL,
      (GtkArgGetFunc) NULL
    };
    p_type = gtk_type_unique(gtk_combo_get_type(), &p_info);
    /*p_type = gtk_type_unique(gtk_option_menu_get_type(), &p_info);*/
  }
  return p_type;
}

static void 
linklist_class_init(LinkListClass * class)
{
  Cf("linklist_class_init");
}

GtkWidget *
linklist_new()
{
  Cf("linklist_new");
  return GTK_WIDGET(gtk_type_new(linklist_get_type()));
}

static void 
linklist_init(LinkList * list)
{
  Cf("linklist_init");
  if (list == NULL)
  {
    (void) printf("linklist_init - LinkList = NULL\n");
    return;
  }
  list->number_of_records = 0;
  list->records = NULL;
  list->type=Unlinked;
}

void 
linklist_set(LinkList * list, RecordType type, Record * rec)
{
  Record record;
  int i = 0;
  char *text = NULL;
  GList *items = NULL;
  PERSON *person = NULL;
  BUSINESS *business = NULL;
  int total = 0;
  record.type = type;
  list->type = type;
  Cf("linklist_set");
  if (list == NULL)
  {
    (void) printf("LinkList = NULL\n");
    return;
  }
  if (rec == NULL)
  {
    if (list->number_of_records > 0)
    {
      Del(list->records);
      list->number_of_records = 0;
    }
    switch (list->type)
    {
    case PersonType:
      person = SortPeople(SPByTitle, SortAscend, &total);
      if (person != NULL)
      {
	list->number_of_records = total;
	list->records = New(LinkItem, total);
	for (i = 0; i < total; i++)
	{
	  record.id = person[i].id;
	  (void) strcpy(list->records[i].string, person[i].title);
 	  list->records[i].record = record;
	  items = g_list_append(items, list->records[i].string);
	}
	Del(person);
      }
      break;
    case BusinessType:
      business = SortBusinesses(SBByName, SortAscend, &total);
      if (business != NULL)
      {
        list->number_of_records = total;
	list->records = New(LinkItem, total);
	for (i = 0; i < total; i++)
	{
	  record.id = business[i].id;
	  (void) strcpy(list->records[i].string, business[i].bname);
	  items = g_list_append(items, list->records[i].string);
	  list->records[i].record = record;
	}
	Del(business);
      }
      break;
    case AppointmentType:
      /*
        you can't display these here.
      */
      break;
    case TodoType:
      /*
        you can't display these here.
      */
      break;
    case ProjectType:
      /* display a list of the projects. */
      break;
    case Unlinked:
      /*(void) gtk_combo_set_popdown_strings(GTK_COMBO(list), NULL);*/
    default:
      /* do nothing */
    }
    if(items != NULL)
      {
	(void) gtk_combo_set_popdown_strings(GTK_COMBO(list), items);
      }
    else
      {
	(void) gtk_list_clear_items(GTK_LIST(GTK_COMBO(list)->list), 0, -1);
      }
    (void) gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(list)->entry), "");
  }
  else
  {
    if (list->number_of_records > 0)
    {
      Del(list->records);
      list->number_of_records = 0;
    }
    switch (type)
    {
    case PersonType:
      person = SortPeople(SPByTitle, SortAscend, &total);
      if (person != NULL)
      {
	list->number_of_records = total;
	list->records = New(LinkItem, total);
	for (i = 0; i < total; i++)
	{
	  record.id = person[i].id;
	  (void) strcpy(list->records[i].string, person[i].title);
	  items = g_list_append(items, list->records[i].string);
	  list->records[i].record = record;
	  if (person[i].id == rec->id)
          {
	    text = New(char, sizeof(person[i].title));
	    (void) strcpy(text, person[i].title);
	  }
	}
	Del(person);
      }
      break;
    case BusinessType:
      business = SortBusinesses(SBByName, SortAscend, &total);
      if (business != NULL)
      {
        list->number_of_records = total;
	list->records = New(LinkItem, total);
	for (i = 0; i < total; i++)
	{
	  record.id = business[i].id;
	  (void) strcpy(list->records[i].string, business[i].bname);
	  items = g_list_append(items, list->records[i].string);
	  list->records[i].record = record;
	  if(business[i].id == rec->id)
	  {
            text = New(char, sizeof(business[i].bname));
            (void) strcpy(text, business[i].bname);
	  }
	}
	Del(business);
      }
      break;
    case AppointmentType:
      /*
        you can't display these here.
      */
      break;
    case TodoType:
      /*
        you can't display these here.
      */
      break;
    case ProjectType:
      /* display a list of the projects. */
      break;
    default:
      /* do nothing */
    }
    if(items != NULL)
      {
	(void) gtk_combo_set_popdown_strings(GTK_COMBO(list), items);
      }
    else
      {
	(void) gtk_list_clear_items(GTK_LIST(GTK_COMBO(list)->list), 0, -1);
      }
    if(text != NULL)
    {
      (void) gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(list)->entry), text);
      Del(text);
    }
  }
}
/*
GtkWidget *label_thing=NULL;

static void
test_func(GtkWidget *widget, gpointer data)
{
  if(GTK_IS_LABEL(widget))
  {
    label_thing = widget;
  }
}
*/

Record *
linklist_get(LinkList * list)
{
  int i = 0;
  /*
  GtkWidget *menu=NULL;
  GList *list=NULL;
  */
  char *text = NULL;
  Record *rec = NULL;
  Cf("linklist_get");
  /*
  menu = gtk_option_menu_get_menu(GTK_OPTION_MENU(optionmenu));
  list = gtk_container_foreach(menu, test_func(), NULL);
  (void) gtk_label_get(GTK_LABEL(label_thing), &text);
  */
  text = gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(list)->entry));
  if ((text != NULL) && (list->records != NULL))
  {
    for (i = 0; i < list->number_of_records; i++)
    {
      if (!strcmp(text, list->records[i].string))
      {
	rec = New(Record, 1);
	*rec = list->records[i].record;
      }
    }
  }
  Del(list->records);
  list->number_of_records = 0;
  return rec;
}
