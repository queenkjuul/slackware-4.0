extern Boolean	ReadConfig			(void);
extern Boolean	WriteConfig			(void);
extern void	SetupConfig			(void);

extern char	*date2str			(char *, DATE);
extern int	str2date			(DATE *, char *);
extern Boolean	datecpy				(DATE *, DATE *);
extern int	datecmp				(DATE *, DATE *);
extern void	SetWeekDayInDate		(DATE *);
extern int	days_this_month			(DATE *);
extern Boolean	chkdate				(DATE *);
extern Boolean	nextmonth			(DATE *);
extern Boolean	prevmonth			(DATE *);
extern Boolean	nextday				(DATE *);
extern Boolean	prevday				(DATE *);
extern Boolean	chkdate_style			(char);
extern char	*GetStrDayFromDate		(DATE *);
extern char	*GetStrMonthFromDate		(DATE *);
extern void	CurrentDate			(DATE *);

extern void	error				(char *, int);
extern void	chklnk				(int, int, int);
extern int	backup				(char *, char *);
extern int	restore				(char *, char *);
extern void	disp_lisc			(void);
extern void	disp_gpl			(void);
extern int	recover				(void);
extern int	compact_db			(void);
extern int	delete_records			(int, int);

extern int	init_data_file_info		(DFI *);
extern Boolean	init_link			(Link *);
extern void	init_note			(char *);
extern Boolean	init_person			(PERSON *);
extern Boolean	init_business			(BUSINESS *);
extern Boolean	init_date			(DATE *);
extern void	init_config			(void);

/*
extern int	remove_links_to			(int, char);
extern void	remove_left_links_to		(char, int);
extern void	decrement_links			(char, int);
*/
extern Boolean	AddPerson			(PERSON *);
extern Boolean	IsPersonReadWrite		(PERSON *);
extern Boolean	IsPersonLocked			(PERSON *);
extern Boolean	IsPersonBlank			(PERSON *);
extern Boolean	IsPersonNull			(PERSON *);
extern Boolean	SetPersonReadWrite		(PERSON *);
extern Boolean	SetPersonLocked			(PERSON *);
extern Boolean	SetPersonBlank			(PERSON *);
extern Boolean	SetPersonNull			(PERSON *);
extern Boolean	StartPersonEdit			(PERSON *);
extern Boolean	CancelPersonEdit		(PERSON *);
extern Boolean	EndPersonEdit			(PERSON *);
extern Boolean	TotalPersonRecords		(int *);
extern int	GetPersonID			(PERSON *);
extern Boolean	ReadPersonRecord		(PERSON *);
extern Boolean	ReadNormalPersonRecord		(PERSON *);
extern Boolean	AppendPersonRecord		(PERSON *);
extern Boolean	WritePersonRecord		(PERSON *);
extern Boolean	WriteNormalPersonRecord		(PERSON *);
extern Boolean	DeletePersonRecord		(int);
extern Boolean	chkperson			(PERSON *);
extern int	personcmp			(PERSON *, PERSON *);
extern PERSON *	SortPeople			(unsigned, int, int *);
extern Gender	str2Gender			(char *);
extern char *	Gender2str			(Gender);

extern Boolean	AddBusiness     		(BUSINESS *);
extern Boolean	StartBusinessEdit		(BUSINESS *);
extern Boolean	CancelBusinessEdit		(BUSINESS *);
extern Boolean	EndBusinessEdit			(BUSINESS *);
extern Boolean	TotalBusinessRecords		(int *);
extern Boolean	ReadBusinessRecord		(BUSINESS *);
extern Boolean	ReadNormalBusinessRecord	(BUSINESS *);
extern Boolean	AppendBusinessRecord		(BUSINESS *);
extern Boolean	WriteBusinessRecord		(BUSINESS *);
extern Boolean	WriteNormalBusinessRecord	(BUSINESS *);
extern Boolean	DeleteBusinessRecord		(int);
extern BUSINESS *SortBusinesses			(unsigned, int, int *);

extern Boolean	ReadRecord			(char *, void *, int, int);
extern int	read_record			(char *, void *, int, int);
extern Boolean	WriteRecord			(char *, void *, int, int);
extern int	write_record			(char *, void *, int, int);
extern int	append_record			(char *, void *, int);
extern int	setup_file			(char *);
extern int	total_records			(char *, int *);
extern int	remove_record			(char *, int, int);
extern int	live_records			(char *, int *);
extern int	shrink				(char *);
extern Boolean	DecrementTotalRecordsForFile	(char *);
extern int	write_info			(char *, DFI);
extern Boolean	WriteInfo			(char *, DFI *);
extern int	read_info			(char *, DFI *);
extern Boolean	ReadInfo			(char *, DFI *);
extern Boolean	TotalLiveRecords		(char *, int *);


extern int	_setup_note_index_file		(void);
extern int	_write_note_index		(INDEX *, int);
extern int	_read_note_index		(INDEX *);

extern int	check_cmdln			(int, char **);
extern void	setup_locations			(void);
extern void	free_locations			(void);
extern Boolean  do_go_into_setup_mode           (int, char **);
extern Boolean  does_dir_exist                  (void);
extern char *   get_host_name                   (void);

extern DFIResults _test_dfi			(DFI *);

extern Boolean	EndDynamicRecordEdit		(char *, int);
extern Boolean	StartDynamicRecordEdit		(char *, int);
extern Boolean	GetTotalDynamicRecords		(char *, int *);
extern Boolean	IsDynamicRecordIDGood		(char *, int);
extern Boolean	SetDynamicRecordBlank		(char *, int);
extern Boolean	SetDynamicRecordReadWrite	(char *, int);
extern Boolean	SetDynamicRecordLocked		(char *, int);
extern Boolean	AppendDynamicRecord		(char *, RECORD *);
extern Boolean	ReadDynamicRecord		(char *, RECORD *);
extern Boolean	DeleteDynamicRecord		(char *, int);
extern Boolean	ReadDynamicRecordHeader		(char *, Header *);
extern Boolean	WriteDynamicRecordHeader	(char *, Header *);
extern Boolean	IsDynamicRecordBlank		(char *, int);
extern Boolean	IsDynamicRecordReadWrite	(char *, int);
extern Boolean	IsDynamicRecordLocked		(char *, int);
extern Boolean	NextDynamicRecord		(char *, int *);
extern Boolean	SetupDynamicFile		(char *);

extern int	read_index			(char *, INDEX *);
extern int	write_index			(char *, INDEX *, int);
extern int	setup_index_file		(char *);
extern int	get_pos_in_index		(char *, int, INDEX *);
extern int	set_pos_in_index		(char *, int, INDEX);

extern void	cf				(const char *);
extern void	cfx				(const char *, int);
extern void	wipe_cf				(void);

extern Boolean	read_note_index			(INDEX index[]);
extern Boolean	write_note_index		(INDEX index[], int len);
extern int	shrink_index_file_size		(char fname[]);

extern void	EnCrypt				(char *, int, int);
extern void	DeCrypt				(char *, int, int);

extern Boolean	DeleteNote			(int);
extern Boolean	AddNote				(char *, int *);
extern Boolean	EndNoteEdit			(int);
extern Boolean	StartNoteEdit			(int);
extern Boolean	SetupNoteRecordFile		(void);
extern Boolean	DeleteNoteRecord		(int);
extern Boolean	AppendNoteRecord		(Note *);
extern Boolean	ReadNoteRecord			(Note *);
extern Boolean	NextNoteRecord			(int *);
extern Boolean	WriteNoteHeader			(Header *);
extern Boolean	ReadNoteHeader			(Header *);

extern Boolean	NextLinkRecord			(int *);
extern Boolean	DecrementLinks			(Record);
extern void	RemoveLeftLinksTo		(Record);
extern Boolean	RemoveLinksTo			(Record);
extern Boolean	ReadLink			(Link *);
extern Boolean	ReadNormalLink			(Link *);
extern void	SetLinkDate			(Link *, DATE *);
extern Boolean	WriteLink			(Link *);
extern Boolean	TotalLinks			(int *);
extern void	AddLinks			(Link *, Record *,
						Record *, int, int);
extern Boolean	AddLink				(Link *);
extern Boolean	AppendLink			(Link *);
extern Link	*GetLink			(Record, int, int, int *);
extern Boolean	RemoveLink			(Link *);
extern Boolean	DeleteLink			(int);
extern int	DoesLinkExist			(int, int *,
						Record *, Record *, DATE *);
extern Link *   GetLink_DayTitle                (DATE *);

extern Boolean	chktime				(TIME *);
extern int	timecmp				(TIME *, TIME *);
extern void	str2time			(TIME *, char *);
extern void	time2str			(char *, TIME *);
extern Boolean	next_hour			(TIME *);
extern Boolean	prev_hour			(TIME *);
extern Boolean	next_min			(TIME *);
extern Boolean	prev_min			(TIME *);

extern Boolean	AddAppointment			(APPOINTMENT *);
extern Boolean	StartAppointmentEdit		(APPOINTMENT *);
extern Boolean	EndAppointmentEdit		(APPOINTMENT *);
extern Boolean	CancelAppointmentEdit		(APPOINTMENT *);
extern Boolean	TotalAppointmentRecords		(int *);
extern Boolean	ReadAppointmentRecord		(APPOINTMENT *);
extern Boolean	ReadNormalAppointmentRecord	(APPOINTMENT *);
extern Boolean	AppendAppointmentRecord		(APPOINTMENT *);
extern Boolean	WriteAppointmentRecord		(APPOINTMENT *);
extern Boolean	DeleteAppointmentRecord		(int);
extern APPOINTMENT *ReadAppointmentsForDate	(DATE *, int *);
