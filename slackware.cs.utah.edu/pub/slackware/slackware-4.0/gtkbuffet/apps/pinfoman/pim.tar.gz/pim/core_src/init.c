/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */
#include"../include/core.h"

Boolean 
init_link(Link * link)
{
  if (link == NULL)
  {
    return False;
  }
  link->left.id = -1;
  link->left.type = Unlinked;
  link->right.id = -1;
  link->right.type = Unlinked;
  (void) init_date(&link->date);
  link->stype = SLTBlank;
  link->id = -1;
  link->type = LTBlank;
  link->has_left = False;
  link->has_right = False;
  link->has_stype = False;
  link->has_string = False;
  (void) strcpy(link->string, "");
  return True;
}

Boolean 
init_record(RECORD * r)
{
  if (r == NULL)
  {
    return False;
  }
  r->header.marker = ReadWrite;
  r->header.size = -1;
  r->header.id = -1;
  return True;
}

Boolean 
init_person(PERSON * data)
{
  if (data == NULL)
  {
    return False;
  }
  data->marker = ReadWrite;
  data->id = -1;
  data->has_note = False;
  return True;
}

Boolean 
init_business(BUSINESS * data)
{
  if (data == NULL)
  {
    return False;
  }
  data->marker = ReadWrite;
  return True;
}

Boolean 
init_date(DATE * d)
{
  if (d == NULL)
  {
    return False;
  }
  d->y = 0;
  d->m = 0;
  d->d = 0;
  d->w = 0;
  return True;
}

void 
init_config(void)
{
  extern CONFIG settings;
  (void) strcpy(settings.username, "Unknown User");
  settings.datestyle = 'a';
  settings.firstrun = 1;
}
