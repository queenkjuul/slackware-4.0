/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

#ifndef __EDITAPP_H__
#define __EDITAPP_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define EDITAPP(obj)          GTK_CHECK_CAST (obj, editapp_get_type (), EditApp)
#define EDITAPP_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, editapp_get_type (), EditAppClass)
#define IS_EDITAPP(obj)       GTK_CHECK_TYPE (obj, editapp_get_type ())


typedef struct _EditApp     	EditApp;
typedef struct _EditAppClass	EditAppClass;

struct _EditApp
{
  GtkWindow window;
  APPOINTMENT *appointment;
  Link general_link;
  Boolean IsNew;
  
  GtkWidget *title;
  /* title of size 60 */
  
  GtkWidget **type;
  /* array of type radio buttons */
  
  GtkWidget *link;
  Record linked_item;
  XTimeDisplay * start;
  XTimeDisplay * stop;
};

struct _EditAppClass
{
  GtkWindowClass parent_class;
  void (* update) (EditApp *ea);
  void (* cancel) (EditApp *ea);
};

extern guint editapp_get_type(void);
extern GtkWidget *editapp_new();
extern void editapp_type(EditApp *ea, EditOption opt);
extern void editapp_set_app(EditApp *ea, APPOINTMENT *a, Link *link);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __EDITAPP_H__ */
