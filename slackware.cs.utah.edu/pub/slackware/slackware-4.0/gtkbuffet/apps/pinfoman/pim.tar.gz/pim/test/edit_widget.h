/*
  PinfoMan
  Copyright (C) 1998 Lawrence Sim
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  
  E-Mail : lasim@earthling.net
  WWW    : http://www.tne.net.au/wanderer/
  */

#ifndef __EDITPERSON_H__
#define __EDITPERSON_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define EDITPERSON(obj)          GTK_CHECK_CAST (obj, editperson_get_type (), EditPerson)
#define EDITPERSON_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, editperson_get_type (), EditPersonClass)
#define IS_EDITPERSON(obj)       GTK_CHECK_TYPE (obj, editperson_get_type ())


typedef struct _EditPerson     	EditPerson;
typedef struct _EditPersonClass	EditPersonClass;

struct _EditPerson
{
  GtkWindow window;
  PERSON person;
  GtkWidget *title;
  GtkWidget *fname;
  GtkWidget *lname;
  GtkWidget *cname;
  GtkWidget *birthdate;
  GtkWidget *phones[5];
  GtkWidget *address;
  GtkWidget *country;
  GtkWidget *gender;
  GtkWidget *city;
  GtkWidget *state;
  GtkWidget *post;
  GtkWidget *email;
  GtkWidget *www;
};

struct _EditPersonClass
{
  GtkWindowClass parent_class;
  void (* update) (EditPerson *ep);
  void (* cancel) (EditPerson *ep);
};

guint editperson_get_type(void);
GtkWidget *editperson_new();
void editperson_set(PERSON person);
#define editperson_set(E, P) E->person = P
#define editperson_get(P) P->person

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __EDITPERSON_H__ */













