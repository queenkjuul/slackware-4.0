/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/project/
 */

#include"../include/core.h"
#include<ctype.h>
/*
   static long calc_days(DATE *d)
   {
   long days;
   d->y--;
   days = YearToDays(d->y);
   days += (long) days_this_month(d);
   days += (long) d->d;
   return days;
   }

   static void set_day_of_week(DATE *d)
   {
   long days;

   days = calc_days(d);
   (void) printf("Day = %d\n", (int) days);
   days--;
   days %= 7L;
   days++;
   (void) printf("Day = %d\n", (int) days);
   d->w = (int) days;
   }
 */
char *
date2str(char stringy[], DATE d)
{
  extern CONFIG settings;
  int len = 0;
  Cf("date2str");
  if((d.y == 0) && (d.m == 0) && (d.d == 0))
  {
    (void) strcpy(stringy, "");
    return stringy;
  }
  switch (settings.datestyle)
  {
  case _ENG_DATE:
    (void) sprintf(stringy, "%2d/%2d/%4d", d.d, d.m, d.y);
    break;
  case _USA_DATE:
    (void) sprintf(stringy, "%2d/%2d/%4d", d.m, d.d, d.y);
    break;
  default:
    (void) printf("%s\n", _ERR_SET);
    (void) cf(_ERR_FNC_S2D);
  }
  len = strlen(stringy);
  for (len--; len >= 0; len--)
  {
    if (stringy[len] == ' ')
    {
      stringy[len] = '0';
    }
  }
  return stringy;
}

int 
str2date(DATE * d, char stringy[])
{
  char *p;
  int mark = 0;
  extern CONFIG settings;
  (void) cf("str2date");
  init_date(d);
  if (strlen(stringy) >= 10)
  {
    switch (settings.datestyle)
    {
    case _ENG_DATE:
      p = strtok(stringy, _DATE_SEPS);
      d->d = atoi(p);
      p = strtok(NULL, _DATE_SEPS);
      d->m = atoi(p);
      p = strtok(NULL, _DATE_SEPS);
      d->y = atoi(p);
      break;
    case _USA_DATE:
      p = strtok(stringy, _DATE_SEPS);
      d->m = atoi(p);
      p = strtok(NULL, _DATE_SEPS);
      d->d = atoi(p);
      p = strtok(NULL, _DATE_SEPS);
      d->y = atoi(p);
      break;
    default:
      (void) printf("%s\n", _ERR_SET);
      (void) cf(_ERR_FNC_S2D);
    }
  }
  else if (!strlen(stringy))
  {
    mark = -1;
    (void) strcpy(stringy, "");
  }
  else
  {
    mark = 1;
  }
  return mark;
}

Boolean 
datecpy(DATE * a, DATE * b)
{
  if ((a == NULL) || (b == NULL))
  {
    return False;
  }
  a->y = b->y;
  a->m = b->m;
  a->d = b->d;
  a->w = b->w;
  return True;
}

int 
datecmp(DATE * d1, DATE * d2)
{
  int i = 0;
  int y, m, d;

  (void) cf("datecmp");

  /* if d1 > d2 return > 0 */
  /* if d1 = d2 return 0 */
  /* if d1 < d2 return < 0 */
  y = d1->y - d2->y;
  m = d1->m - d2->m;
  d = d1->d - d2->d;
  if (y < 0)
  {
    i = -1;
  }
  else if (y > 0)
  {
    i = 1;
  }
  else if (m < 0)
  {
    i = -1;
  }
  else if (m > 0)
  {
    i = 1;
  }
  else if (d < 0)
  {
    i = -1;
  }
  else if (d > 0)
  {
    i = 1;
  }
  else
  {
    i = 0;
  }
  return i;
}

int 
days_this_month(DATE * d)
{
  int val = -1;

  Cf("days_this_month");

  switch (d->m)
  {
  case JAN:
    val = JAN_DAYS;
    break;
  case FEB:
    if (IsLeapYear(d) == True)
    {
      val = FEB_DAYS + 1;
    }
    else
    {
      val = FEB_DAYS;
    }
    break;
  case MAR:
    val = MAR_DAYS;
    break;
  case APR:
    val = APR_DAYS;
    break;
  case MAY:
    val = MAY_DAYS;
    break;
  case JUN:
    val = JUN_DAYS;
    break;
  case JUL:
    val = JUL_DAYS;
    break;
  case AUG:
    val = AUG_DAYS;
    break;
  case SEP:
    val = SEP_DAYS;
    break;
  case OCT:
    val = OCT_DAYS;
    break;
  case NOV:
    val = NOV_DAYS;
    break;
  case DEC:
    val = DEC_DAYS;
    break;
  default:
    (void) printf("%s: %s %d\n", PROG_NAME, _ERR_BMN, d->m);
    (void) cf(_ERR_FNC_DTM);
  }
  return val;
}

Boolean 
chkdate(DATE * d)
{
  Boolean val = True;
  if ((d->d > days_this_month(d)) || (d->d < 1))
  {
    val = False;
  }
  if ((d->m < 1) || (d->m > 12))
  {
    val = False;
  }
  if (d->y < 0)
  {
    val = False;
  }
  return val;
}

Boolean 
nextmonth(DATE * d)
{
  if (d->m < 12)
  {
    d->m++;
    return True;
  }
  return False;
}

Boolean 
prevmonth(DATE * d)
{
  if (d->m > 1)
  {
    d->m--;
    return True;
  }
  return False;
}

Boolean 
nextday(DATE * d)
{
  if (d->d < days_this_month(d))
  {
    d->d++;
    return True;
  }
  return False;
}

Boolean 
prevday(DATE * d)
{
  if (d->d > 1)
  {
    d->d--;
    return True;
  }
  return False;
}

Boolean 
chkdate_style(char style)
{
  Cf("chkdate_style");
  switch (tolower(style))
  {
  case _ENG_DATE:
  case _USA_DATE:
    break;
  default:
    return False;
  }
  return True;
}

char *
GetStrDayFromDate(DATE * d)
{
  char *str = NULL;
  (void) cf("GetStrDayFromDate");
  switch (d->w)
  {
  case Sunday:
    str = New(char, strlen(SUNDAY_STR));
    (void) strcpy(str, SUNDAY_STR);
    break;
  case Monday:
    str = New(char, strlen(MONDAY_STR));
    (void) strcpy(str, MONDAY_STR);
    break;
  case Tuesday:
    str = New(char, strlen(TUESDAY_STR));
    (void) strcpy(str, TUESDAY_STR);
    break;
  case Wednesday:
    str = New(char, strlen(WEDNESDAY_STR));
    (void) strcpy(str, WEDNESDAY_STR);
    break;
  case Thursday:
    str = New(char, strlen(THURSDAY_STR));
    (void) strcpy(str, THURSDAY_STR);
    break;
  case Friday:
    str = New(char, strlen(FRIDAY_STR));
    (void) strcpy(str, FRIDAY_STR);
    break;
  case Saturday:
    str = New(char, strlen(SATURDAY_STR));
    (void) strcpy(str, SATURDAY_STR);
    break;
  }
  return str;
}

char *
GetStrMonthFromDate(DATE * d)
{
  char *str = NULL;
  (void) cf("GetStrMonthFromDate");
  switch (d->m)
  {
  case JAN:
    str = New(char, strlen(JAN_NAME));
    (void) strcpy(str, JAN_NAME);
    break;
  case FEB:
    str = New(char, strlen(FEB_NAME));
    (void) strcpy(str, FEB_NAME);
    break;
  case MAR:
    str = New(char, strlen(MAR_NAME));
    (void) strcpy(str, MAR_NAME);
    break;
  case APR:
    str = New(char, strlen(APR_NAME));
    (void) strcpy(str, APR_NAME);
    break;
  case MAY:
    str = New(char, strlen(MAY_NAME));
    (void) strcpy(str, MAY_NAME);
    break;
  case JUN:
    str = New(char, strlen(JUN_NAME));
    (void) strcpy(str, JUN_NAME);
    break;
  case JUL:
    str = New(char, strlen(JUL_NAME));
    (void) strcpy(str, JUL_NAME);
    break;
  case AUG:
    str = New(char, strlen(AUG_NAME));
    (void) strcpy(str, AUG_NAME);
    break;
  case SEP:
    str = New(char, strlen(SEP_NAME));
    (void) strcpy(str, SEP_NAME);
    break;
  case OCT:
    str = New(char, strlen(OCT_NAME));
    (void) strcpy(str, OCT_NAME);
    break;
  case NOV:
    str = New(char, strlen(NOV_NAME));
    (void) strcpy(str, NOV_NAME);
    break;
  case DEC:
    str = New(char, strlen(DEC_NAME));
    (void) strcpy(str, DEC_NAME);
    break;
  }
  return str;
}

static void 
_convertTime2Date(DATE * d, struct tm *t)
{
  Cf("_convertTime2Date");
  d->d = t->tm_mday;
  d->m = t->tm_mon + 1;
  d->y = 1900 + t->tm_year;
  d->w = t->tm_wday;
}

static void 
_convertDate2Time(struct tm *t, DATE * d)
{
  Cf("_convertDate2Time");
  t->tm_sec = 0;
  t->tm_min = 0;
  t->tm_hour = 0;
  t->tm_mday = d->d;
  t->tm_mon = d->m - 1;
  t->tm_year = d->y - 1900;
  t->tm_wday = d->w;
  t->tm_isdst = 0;
}

void 
CurrentDate(DATE * d)
{
  time_t t;
  time_t *curr_time = &t;
  struct tm *times;
  (void) cf("CurrentDate");
  t = time(curr_time);
  times = localtime(curr_time);
  (void) _convertTime2Date(d, times);
}

void 
SetWeekDayInDate(DATE * d)
{
  struct tm t;
  struct tm *times = NULL;
  time_t time;
  time_t *ptime = &time;
  Cf("SetWeekDayInDate");
  (void) _convertDate2Time(&t, d);
  time = mktime(&t);
  times = localtime(ptime);
  (void) _convertTime2Date(d, times);
}
