/*
   PinfoMan
   Copyright (C) 1998 Lawrence Sim

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   E-Mail : lasim@earthling.net
   WWW    : http://www.tne.net.au/wanderer/
 */

#include"../include/xall.h"

XTimeDisplay *
XTimeDisplayNew(char title[])
{
  XTimeDisplay *td=NULL;
  GtkWidget *hbox1=NULL;
  GtkWidget *hbox2=NULL;
  GtkWidget *hbox3=NULL;
  GtkAdjustment *adj=NULL;
  GtkWidget *label=NULL;
  if(title != NULL)
  {
    td = New(XTimeDisplay, 1);
    td->main_window = gtk_frame_new(title);
    
    hbox1 = gtk_hbox_new(FALSE, 0);
    (void) gtk_container_add(GTK_CONTAINER(td->main_window), hbox1);

    hbox2 = gtk_hbox_new (FALSE, 0);
    (void) gtk_box_pack_start(GTK_BOX(hbox1), hbox2, TRUE, TRUE, 0);
    adj = (GtkAdjustment *) gtk_adjustment_new(0.0, 0.0, 23.0, 1.0, 1.0, 0.0);
    td->hours = gtk_spin_button_new(adj, 0, 0);
    gtk_spin_button_set_wrap(GTK_SPIN_BUTTON(td->hours), TRUE);
    gtk_box_pack_start(GTK_BOX(hbox2), td->hours, FALSE, TRUE, 0);
    
    label = gtk_label_new(" : ");
    (void) gtk_box_pack_start(GTK_BOX(hbox1), label, FALSE, TRUE, 0);
    
    hbox3 = gtk_hbox_new (FALSE, 0);
    (void) gtk_box_pack_start(GTK_BOX(hbox1), hbox3, TRUE, TRUE, 0);
    adj = (GtkAdjustment *) gtk_adjustment_new(0.0, 0.0, 59.0, 1.0, 15.0, 0.0);
    td->mins = gtk_spin_button_new(adj, 0, 0);
    gtk_spin_button_set_wrap(GTK_SPIN_BUTTON(td->mins), TRUE);
    gtk_box_pack_start(GTK_BOX(hbox3), td->mins, FALSE, TRUE, 0);
  }
  return td;
}

TIME *
XTimeDisplayGetTime(XTimeDisplay *td)
{
  TIME *tm=NULL;
  if(td != NULL)
  {
    tm = New(TIME, 1);
    tm->h = (int) gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(td->hours));
    tm->m = (int) gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(td->mins));
  }
  return tm;
}

Boolean
XTimeDisplaySetTime(XTimeDisplay * td, TIME * st)
{
  float hours, mins;
  if((td != NULL) && (st != NULL))
  {
    hours = st->h;
    mins = st->m;
    (void) gtk_spin_button_set_value(GTK_SPIN_BUTTON(td->hours), hours);
    (void) gtk_spin_button_set_value(GTK_SPIN_BUTTON(td->mins), mins);
    return True;
  }
  return False;
}

GtkWidget *
XTimeDisplayGetWin(XTimeDisplay *td)
{
  return td->main_window;
}

Boolean
XTimeDisplayShow(XTimeDisplay *td)
{
  if(td == NULL) { return False; }
  (void) gtk_widget_show_all(td->main_window);
  return True;
}