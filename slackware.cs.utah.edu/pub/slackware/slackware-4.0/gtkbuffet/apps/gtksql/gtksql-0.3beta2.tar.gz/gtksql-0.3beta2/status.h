#include <gtk/gtk.h>

GtkWidget *status_bar_new(void);
void status_push(gchar *msg);
void status_pop(void);
void status_reset(void);
void status_update(gfloat percentage);
