/* XQF - Quake server browser and launcher
 * Copyright (C) 1998 Roman Pozlevich <roma@botik.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#ifndef __SERVER_H__
#define __SERVER_H__

#include <gtk/gtk.h>

#include "xqf.h"


extern	struct server *server_add (struct host *h, unsigned short port, 
                                                       enum server_type type);
extern	void free_players (struct player **p, int n);
extern	void server_free_info (struct server *s);
extern	void server_unref (struct server *s);
extern	int servers_total (void);
extern	GSList *all_servers (void);
extern	int parse_address (char *str, char **addr, unsigned short *port);
extern	void free_servers (GSList *list);

extern	char *add_server_dialog (enum server_type *type);


#endif /* __SERVER_H__ */
