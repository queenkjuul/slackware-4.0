/* XQF - Quake server browser and launcher
 * Copyright (C) 1998 Roman Pozlevich <roma@botik.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <stdio.h>	/* fprintf, sprintf */
#include <string.h>	/* strchr, strncpy */
#include <stdlib.h>	/* strtol */

#include <gtk/gtk.h>

#include "xqf.h"
#include "game.h"
#include "dns.h"
#include "dialogs.h"
#include "utils.h"
#include "server.h"


struct server_hash {
  int num;
  GSList **nodes;
};

static struct server_hash servers = { 251, NULL };


static int server_hash_func (struct host *h, unsigned short port) {
  unsigned char *ptr;

  if (!h)
    return 0;

  ptr = (char *) &h->ip.s_addr;
  return (ptr[0] + (ptr[1] << 2) + (ptr[2] << 4) + (ptr[3] << 6) + port) % 
                                                                  servers.num;
}


static struct server *server_new (struct host *h, unsigned short port, 
                                                      enum server_type type) {
  struct server *s;

  if (!h || port == 0 || type == UNKNOWN_SERVER)
    return NULL;

  s = g_malloc0 (sizeof (struct server));

  s->host = h;
  h->ref_count++;

  s->port = port;
  s->type = type;
  s->ping = -1;
  s->retries = -1;

  return s;
}


struct server *server_add (struct host *h, unsigned short port, 
                                                      enum server_type type) {
  struct server *s;
  GSList *ptr;
  int node;
  int i;

  if (!h || type == UNKNOWN_SERVER)
    return NULL;

  if (port == 0)
    port = games[type].default_port;

  node = server_hash_func (h, port);

  if (!servers.nodes) {
    servers.nodes = g_malloc (sizeof (GSList *) * servers.num);
    for (i = 0; i < servers.num; i++)
      servers.nodes[i] = NULL;
  }
  else {
    for (ptr = servers.nodes[node]; ptr; ptr = ptr->next) {
      s = (struct server *) ptr->data;
      if (s->host == h && s->port == port)
	return s;
    }
  }

  s = server_new (h, port, type);
  if (s)
    servers.nodes[node] = g_slist_prepend (servers.nodes[node], s);
  return s;
}


void free_players (struct player **p, int n) {
  struct player **ptr = p;

  if (p) {
    while (n-- > 0)
      g_free (*ptr++);
    g_free (p);
  }
}


void server_free_info (struct server *s) {
  if (s->name) {
    g_free (s->name);
    s->name = NULL;
  }
  if (s->map) {
    g_free (s->map);
    s->map  = NULL;
  }
  if (s->info) {
    g_free (s->info);
    s->info = NULL;
    s->game = NULL;
  }
  if (s->players) {
    free_players (s->players, s->curplayers);
    s->players = NULL;
  }

  s->flags = 0;
  s->maxplayers = 0;
  s->curplayers = 0;

  s->filters = 0;
  s->flt_mask = 0;
  s->flt_last = 0;
}


void server_unref (struct server *s) {
  int node;

  if (!s || !servers.nodes)
    return;

  s->ref_count--;

  if (s->ref_count <= 0) {
    node = server_hash_func (s->host, s->port);
    servers.nodes[node] = g_slist_remove (servers.nodes[node], s);

    server_free_info (s);
    host_unref (s->host);

    g_free (s);
  }
}


int servers_total (void) {
  int i;
  int size = 0;

  if (!servers.nodes)
    return 0;

  for (i = 0; i < servers.num; i++) {
    size += g_slist_length (servers.nodes[i]);
  }
  return size;
}


GSList *all_servers (void) {
  GSList *list = NULL;
  GSList *tmp;
  struct server *s;
  int i;

  if (!servers.nodes)
    return NULL;

  for (i = 0; i < servers.num; i++) {
    for (tmp = servers.nodes[i]; tmp; tmp = tmp->next) {
      s = (struct server *) tmp->data;
      list = g_slist_prepend (list, s);
      s->ref_count++;
    }
  }

  return list;
}


int parse_address (char *str, char **addr, unsigned short *port) {
  long tmp;
  char *ptr;

  if(!str || !addr || !port)
    return FALSE;

  ptr = strchr (str, ':');
  if (!ptr) {
    *port = 0;
    *addr = g_strdup (str);
    return TRUE;
  }

  tmp = strtol (ptr + 1, NULL, 10);
  if ((ptr == str) || (tmp <= 0 || tmp > 65535)) {
    *port = 0;
    *addr = NULL;
    return FALSE;
  }
  else {
    *port = tmp;
  }

  *addr = g_malloc (ptr - str + 1);
  strncpy (*addr, str, ptr - str);
  (*addr) [ptr - str] = '\0';
  return TRUE;
}


void free_servers (GSList *list) {
  if (list) {
    g_slist_foreach (list, (GFunc) server_unref, NULL);
    g_slist_free (list);
  }
}


static char *enter_server_result;
static enum server_type *server_type;
static GtkWidget *enter_server_entry;


static void enter_server_activate_callback (GtkWidget *widget, gpointer data) {
  enter_server_result = strdup_strip (gtk_entry_get_text (GTK_ENTRY (widget)));
}


static void select_server_type_callback (GtkWidget *widget, 
					              enum server_type type) {
  *server_type = type;
}


static GtkWidget *create_server_type_menu (void) {
  GtkWidget *menu;
  GtkWidget *menu_item;
  GtkWidget *hbox;
  GtkWidget *pixmap;
  GtkWidget *label;
  int i;
 
  menu = gtk_menu_new ();

  for (i = 0; games[i].type != UNKNOWN_SERVER; i++) {
    menu_item = gtk_menu_item_new ();

    menu_item = gtk_menu_item_new ();
    gtk_menu_append (GTK_MENU (menu), menu_item);

    hbox = gtk_hbox_new (FALSE, 4);
    gtk_container_add (GTK_CONTAINER (menu_item), hbox);

    pixmap = gtk_pixmap_new (games[i].pix->pix, games[i].pix->mask);
    gtk_box_pack_start (GTK_BOX (hbox), pixmap, FALSE, FALSE, 0);
    gtk_widget_show (pixmap);

    label = gtk_label_new (games[i].name);
    gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, FALSE, 0);
    gtk_widget_show (label);

    gtk_widget_show (hbox);

    gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
                 GTK_SIGNAL_FUNC (select_server_type_callback), (gpointer) i);
    gtk_widget_show (menu_item);
  }

  return menu;
}


char *add_server_dialog (enum server_type *type) {
  GtkWidget *window;
  GtkWidget *main_vbox;
  GtkWidget *option_menu;
  GtkWidget *hbox;
  GtkWidget *label;
  GtkWidget *button;
  GtkWidget *hseparator;

  enter_server_result = NULL;
  server_type = type;
  *type = QW_SERVER;

  window = dialog_create_modal_transient_window ("Add Server", TRUE, FALSE);

  main_vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_add (GTK_CONTAINER (window), main_vbox);

  hbox = gtk_hbox_new (FALSE, 8);
  gtk_container_border_width (GTK_CONTAINER (hbox), 16);
  gtk_box_pack_start (GTK_BOX (main_vbox), hbox, FALSE, FALSE, 0);

  /* Server Entry */

  label = gtk_label_new ("Server:");
  gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, FALSE, 0);
  gtk_widget_show (label);

  enter_server_entry = gtk_entry_new_with_max_length (128);
  gtk_widget_set_usize (enter_server_entry, 160, -1);
  gtk_box_pack_start (GTK_BOX (hbox), enter_server_entry, TRUE, TRUE, 0);
  gtk_signal_connect (GTK_OBJECT (enter_server_entry), "activate",
		      GTK_SIGNAL_FUNC (enter_server_activate_callback), NULL);
  gtk_signal_connect_object (GTK_OBJECT (enter_server_entry), "activate",
                   GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (window));
  gtk_widget_grab_focus (enter_server_entry);
  gtk_widget_show (enter_server_entry);

  /* Server Type Option Menu */

  option_menu = gtk_option_menu_new ();
  gtk_box_pack_start (GTK_BOX (hbox), option_menu, FALSE, FALSE, 0);
  gtk_option_menu_set_menu (GTK_OPTION_MENU (option_menu), 
                                                  create_server_type_menu ());
  gtk_option_menu_set_history (GTK_OPTION_MENU (option_menu), *type);
  gtk_widget_show (option_menu);   

  gtk_widget_show (hbox);

  hseparator = gtk_hseparator_new ();
  gtk_box_pack_start (GTK_BOX (main_vbox), hseparator, FALSE, FALSE, 0);
  gtk_widget_show (hseparator);

  /* Buttons */

  hbox = gtk_hbox_new (FALSE, 8);
  gtk_container_border_width (GTK_CONTAINER (hbox), 8);
  gtk_box_pack_start (GTK_BOX (main_vbox), hbox, FALSE, FALSE, 0);

  /* Cancel Button */

  button = gtk_button_new_with_label (" Cancel ");
  gtk_box_pack_end (GTK_BOX (hbox), button, FALSE, FALSE, 0);
  gtk_widget_set_usize (button, 80, -1);
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (window));
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_widget_show (button);

  /* OK Button */

  button = gtk_button_new_with_label (" OK ");
  gtk_box_pack_end (GTK_BOX (hbox), button, FALSE, FALSE, 0);
  gtk_widget_set_usize (button, 80, -1);
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
		             GTK_SIGNAL_FUNC (enter_server_activate_callback),
			     GTK_OBJECT (enter_server_entry));
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (window));
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_widget_grab_default (button);
  gtk_widget_show (button);

  gtk_widget_show (hbox);

  gtk_widget_show (main_vbox);
  gtk_widget_show (window);

  gtk_main ();

  unregister_window (window);

  return enter_server_result;
}

