/* XQF - Quake server browser and launcher
 * Copyright (C) 1998 Roman Pozlevich <roma@botik.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <sys/types.h>
#include <stdio.h>	/* FILE, fprintf, fopen, fclose */
#include <string.h>	/* strlen, strcpy, strcmp, strtok */
#include <stdlib.h>	/* strtol */
#include <unistd.h>	/* stat */
#include <sys/stat.h>	/* stat, chmod */

#include <gtk/gtk.h>

#include "xqf.h"
#include "pref.h"
#include "launch.h"
#include "dialogs.h"
#include "utils.h"
#include "pixmaps.h"
#include "game.h"


static struct player *poqs_parse_player(char *tokens[], int num);
static struct player *qw_parse_player(char *tokens[], int num);
static struct player *q2_parse_player(char *tokens[], int num);

static void quake_parse_server (char *tokens[], int num, struct server *s);

static void qw_analyze_serverinfo (struct server *s);
static void q2_analyze_serverinfo (struct server *s);

static int quake_config_is_valid (struct server *s);

static int write_quake_variables (const struct condef *con);

static void q1_exec (const struct condef *con, int forkit);
static void qw_exec (const struct condef *con, int forkit);

static GList *q1_custom_cfgs (char *dir, char *game);
static GList *qw_custom_cfgs (char *dir, char *game);
static GList *q2_custom_cfgs (char *dir, char *game);


struct game games[] = {
  {
    Q1_SERVER, 
    GAME_CONNECT | GAME_RECORD | GAME_QUAKE_PLAYER_COLORS,
    "Quake",
    Q1_DEFAULT_PORT,
    "QS",
    NULL,
    &q1_pix,

    poqs_parse_player,
    quake_parse_server,
    NULL,
    quake_config_is_valid,
    write_quake_variables,
    q1_exec,
    q1_custom_cfgs
  },
  {
    QW_SERVER,
    GAME_CONNECT | GAME_RECORD | GAME_SPECTATE | GAME_PASSWORD | GAME_RCON | 
                                                     GAME_QUAKE_PLAYER_COLORS,
    "QuakeWorld",
    QW_DEFAULT_PORT,
    "QW",
    "-qws",
    &q_pix,

    qw_parse_player,
    quake_parse_server,
    qw_analyze_serverinfo,
    quake_config_is_valid,
    write_quake_variables,
    qw_exec,
    qw_custom_cfgs
  },
  {
    Q2_SERVER,
    GAME_CONNECT | GAME_RECORD | GAME_SPECTATE | GAME_PASSWORD | GAME_RCON,
    "Quake2",
    Q2_DEFAULT_PORT,
    "Q2",
    "-qws",
    &q2_pix,

    q2_parse_player,
    quake_parse_server,
    q2_analyze_serverinfo,
    quake_config_is_valid,
    write_quake_variables,
    qw_exec,
    q2_custom_cfgs
  },
  {
    H2_SERVER,
    GAME_QUAKE_PLAYER_COLORS,
    "Hexen2",
    H2_DEFAULT_PORT,
    "H2S",
    "-h2s",
    &hex_pix,

    poqs_parse_player,
    quake_parse_server,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
  },
  {
    HW_SERVER,
    GAME_QUAKE_PLAYER_COLORS,
    "HexenWorld",
    HW_DEFAULT_PORT,
    "HWS",
    "-hws",
    &hex_pix,

    qw_parse_player,
    quake_parse_server,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
  },
  {
    UNKNOWN_SERVER,
    0,
    "unknown",
    0,
    NULL,
    NULL,
    NULL,

    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
  }
};


static const char delim[] = " \t\n\r";


static struct player *poqs_parse_player (char *token[], int n) {
  struct player *player = NULL;
  char *ptr;
  long tmp;

  if (n < 7)
    return NULL;

  player = g_malloc0 (sizeof (struct player) + strlen (token[1]) + 1);
  player->time  = strtol (token[4], NULL, 10);
  player->frags = strtosh (token[3]);
  player->ping = -1;

  tmp = strtol (token[5], NULL, 10);
  player->shirt = fix_qw_player_color (tmp);

  tmp = strtol (token[6], NULL, 10);
  player->pants = fix_qw_player_color (tmp);

  ptr = (char *) player + sizeof (struct player);
  player->name = strcpy (ptr, token[1]);

  return player;
}


static struct player *qw_parse_player (char *token[], int n) {
  struct player *player = NULL;
  char *ptr;
  long tmp;

  if (n < 8)
    return NULL;

  player = g_malloc0 (sizeof (struct player) + 
                               strlen (token[1]) + 1 + strlen (token[7]) + 1);
  player->time  = strtol (token[3], NULL, 10);
  player->frags = strtosh (token[2]);
  player->ping  = strtosh (token[6]);

  tmp = strtol (token[4], NULL, 10);
  player->shirt = fix_qw_player_color (tmp);

  tmp = strtol (token[5], NULL, 10);
  player->pants = fix_qw_player_color (tmp);

  ptr = (char *) player + sizeof (struct player);
  player->name = strcpy (ptr, token[1]);
  player->skin = strcpy (ptr + strlen (token[1]) + 1, token[7]);

  return player;
}


static struct player *q2_parse_player (char *token[], int n) {
  struct player *player = NULL;
  char *ptr;

  if (n < 3)
    return NULL;

  player = g_malloc0 (sizeof (struct player) + strlen (token[0]) + 1);
  player->time  = -1;
  player->frags = strtosh (token[1]);
  player->ping  = strtosh (token[2]);

  ptr = (char *) player + sizeof (struct player);
  player->name = strcpy (ptr, token[0]);

  return player;
}


static void quake_parse_server (char *token[], int n, struct server *s) {
  int poqs;
  int offs;

  poqs = (s->type == Q1_SERVER || s->type == H2_SERVER)? TRUE : FALSE;

  if ((poqs && n != 10) || (!poqs && n != 8))
    return;

  if (*(token[2]))		/* if name is not empty */
    s->name = g_strdup (token[2]);

  offs = (poqs)? 5 : 3;

  if (*(token[offs]))            /* if map is not empty */
    s->map  = g_strdup (token[offs]);

  s->maxplayers = strtoush (token[offs + 1]);
  s->curplayers = strtoush (token[offs + 2]);

  s->ping = strtosh (token[offs + 3]);
  if (s->ping > MAX_PING)
    s->ping = MAX_PING;

  s->retries = strtosh (token[offs + 4]);
  if (s->retries > maxretries)
    s->retries = maxretries;
}


static void qw_analyze_serverinfo (struct server *s) {
  char **info_ptr;
  int n;

  for (info_ptr = s->info; info_ptr && *info_ptr; info_ptr += 2) {
    if (strcmp (*info_ptr, "*gamedir") == 0) {
      s->game = info_ptr[1];
    }
    else if (strcmp (*info_ptr, "*cheats") == 0) {
      s->flags |= SERVER_CHEATS;
    }
    else if (strcmp (*info_ptr, "needpass") == 0) {
      n = strtol (info_ptr[1], NULL, 10);
      if ((n & 1) != 0)
	s->flags |= SERVER_PASSWORD;
      if ((n & 2) != 0)
	s->flags |= SERVER_SP_PASSWORD;
    }
  }

  s->flags |= SERVER_SPECTATE;
}


static void q2_analyze_serverinfo (struct server *s) {
  char **info_ptr;
  int n;

  for (info_ptr = s->info; info_ptr && *info_ptr; info_ptr += 2) {
    if (strcmp (*info_ptr, "gamedir") == 0) {
      s->game = info_ptr[1];
    }
    else if (strcmp (*info_ptr, "cheats") == 0 && info_ptr[1][0] != '0') {
      s->flags |= SERVER_CHEATS;
    }
    else if (strcmp (*info_ptr, "protocol") == 0) {
      n = strtol (info_ptr[1], NULL, 10);
      if (n >= 34)
	s->flags |= SERVER_SPECTATE;
    }
    else if (strcmp (*info_ptr, "needpass") == 0) {
      n = strtol (info_ptr[1], NULL, 10);
      if ((n & 1) != 0)
	s->flags |= SERVER_PASSWORD;
      if ((n & 2) != 0)
	s->flags |= SERVER_SP_PASSWORD;
    }
  }
}


static int quake_config_is_valid (struct server *s) {
  struct stat stat_buf;
  char *dir;
  char *cmd;
  char *cfgdir;
  char *path;

  switch (s->type) {

  case Q1_SERVER:
    dir = real_quake_dir;
    cmd = default_q1_cmd;
    cfgdir = "id1";
    break;

  case QW_SERVER:
    dir = real_quake_dir;
    cmd = default_qw_cmd;
    cfgdir = "id1";
    break;

  case Q2_SERVER:
    dir = real_q2_dir;
    cmd = default_q2_cmd;
    cfgdir = "baseq2";
    break;

  default:
    return FALSE;

  }

  if (cmd == NULL || cmd[0] == '\0') {
    dialog_ok (NULL, "%s command line is empty.", games[s->type].name);
    return FALSE;
  }

  if (dir != NULL && dir[0] != '\0') {
    if (stat (dir, &stat_buf) != 0 || !S_ISDIR (stat_buf.st_mode)) {
      dialog_ok (NULL, "\"%s\" is not a directory\n"
	              "Please specify correct %s working directory.", 
                       dir, games[s->type].name);
      return FALSE;
    }
  }

  path = file_in_dir (dir, cfgdir);

  if (stat (path, &stat_buf) || !S_ISDIR (stat_buf.st_mode)) {
    if (!dir || dir[0] == '\0') {
      dialog_ok (NULL, "Please specify correct %s working directory.", 
                                                         games[s->type].name);
    }
    else {
      dialog_ok (NULL,  
                 "Directory \"%s\" doesn\'t contain \"%s\" subdirectory.\n"
                 "Please specify correct %s working directory.", 
                 dir, cfgdir, games[s->type].name);
    }
    g_free (path);
    return FALSE;
  }

  g_free (path);
  return TRUE;
}


static FILE *open_cfg (const char *filename, int secure) {
  FILE *f;

  f = fopen (filename, "w");
  if (f) {
    if (secure)
      chmod (filename, S_IRUSR | S_IWUSR);

    fprintf (f, "//\n// generated by XQF, do not modify\n//\n");
  }
  return f;
}


static int real_password (const char *password) {
  if (!password || (password[0] == '1' && password[1] == '\0'))
    return FALSE;
  return TRUE;
}


static int write_passwords (const char *filename, const struct condef *con) {
  FILE *f;

  f = open_cfg (filename, TRUE);
  if (!f) 
    return FALSE;

  if (con->observe)
    fprintf (f, "spectator \"%s\"\n", con->observe);

  if (con->password)
    fprintf (f, "password \"%s\"\n", con->password);

  if (con->rcon_password)
    fprintf (f, "rcon_password \"%s\"\n", con->rcon_password);

  fclose (f);
  return TRUE;
}


static int write_q1_vars (const char *filename, const struct condef *con) {
  FILE *f;

  f = open_cfg (filename, FALSE);
  if (!f)
    return FALSE;

  if (default_name)
    fprintf (f, "name \"%s\"\n", default_name);

  fprintf (f, "color %d %d\n", default_q1_top_color, default_q1_bottom_color);

  if (default_q1_cfg)
    fprintf (f, "exec \"%s\"\n", default_q1_cfg);

  if (con->custom_cfg)
    fprintf (f, "exec \"%s\"\n", con->custom_cfg);

  fclose (f);
  return TRUE;
}


static int write_qw_vars (const char *filename, const struct condef *con) {
  FILE *f;
  int plat;

  f = open_cfg (filename, FALSE);
  if (!f)
    return FALSE;

  if (default_name)
    fprintf (f, "name \"%s\"\n", default_name);

  if (default_qw_skin)
    fprintf (f, "skin \"%s\"\n", default_qw_skin);

  fprintf (f, "team \"%s\"\n", (default_team)? default_team : "");
  fprintf (f, "topcolor    \"%d\"\n", default_qw_top_color);
  fprintf (f, "bottomcolor \"%d\"\n", default_qw_bottom_color);

  if (default_pushlatency) {
    if (con->s->ping <= 0)
      plat = -50;		/* "min" value */
    else if (con->s->ping >= 2000)
      plat = -1000;		/* "max" value */
    else {
      plat = con->s->ping / 2;
      plat = ((plat+49)/50)*50;	/* beautify it */
    }
    fprintf (f, "pushlatency %d\n", -plat);
  }

  fprintf (f, "rate        \"%d\"\n", default_rate);
  fprintf (f, "cl_nodelta  \"%d\"\n", default_cl_nodelta);
  fprintf (f, "cl_predict_players \"%d\"\n", default_cl_predict);
  fprintf (f, "noaim       \"%d\"\n", default_noaim);
  fprintf (f, "noskins     \"%d\"\n", default_noskins);
  if (default_w_switch >= 0)
    fprintf (f, "setinfo w_switch \"%d\"\n", default_w_switch);
  if (default_b_switch >= 0)
    fprintf (f, "setinfo b_switch \"%d\"\n", default_b_switch);
  fprintf (f, "_windowed_mouse \"%d\"\n", default_windowed_mouse);

  if (default_qw_cfg)
    fprintf (f, "exec \"%s\"\n", default_qw_cfg);

  if (con->custom_cfg)
    fprintf (f, "exec \"%s\"\n", con->custom_cfg);

  fclose (f);
  return TRUE;
}


static int write_q2_vars (const char *filename, const struct condef *con) {
  FILE *f;

  f = open_cfg (filename, FALSE);
  if (!f)
    return FALSE;

  if (default_name)
    fprintf (f, "set name \"%s\"\n", default_name);

  if (default_q2_skin)
    fprintf (f, "set skin \"%s\"\n", default_q2_skin);

  fprintf (f, "set rate        \"%d\"\n", default_rate);
  fprintf (f, "set cl_nodelta  \"%d\"\n", default_cl_nodelta);
  fprintf (f, "set cl_predict  \"%d\"\n", default_cl_predict);
  fprintf (f, "set cl_noskins  \"%d\"\n", default_noskins);
  fprintf (f, "set _windowed_mouse \"%d\"\n", default_windowed_mouse);

  if (default_q2_cfg)
    fprintf (f, "exec \"%s\"\n", default_q2_cfg);

  if (con->custom_cfg)
    fprintf (f, "exec \"%s\"\n", con->custom_cfg);

  fclose (f);
  return TRUE;
}


static int write_quake_variables (const struct condef *con) {
  char *q_dir;
  char *q_conf;
  char *file;

  switch (con->s->type) {

  case Q1_SERVER:
  case QW_SERVER:
    q_dir = real_quake_dir;
    q_conf = "id1/" EXEC_CFG;
    break;

  case Q2_SERVER:
    q_dir = real_q2_dir;
    q_conf = "baseq2/" EXEC_CFG;
    break;

  default:
    return FALSE;

  }

  file = file_in_dir (q_dir, q_conf);

  if ((con->s->type == Q1_SERVER && !write_q1_vars (file, con)) ||
      (con->s->type == QW_SERVER && !write_qw_vars (file, con)) ||
      (con->s->type == Q2_SERVER && !write_q2_vars (file, con))) {
    if (!dialog_yesno (NULL, 1, "Launch", "Cancel", 
             "Cannot write to file \"%s\".\n\nLaunch client anyway?", file)) {
      g_free (file);
      return FALSE;
    }
  }

  g_free (file);
  return TRUE;
}


static void q1_exec (const struct condef *con, int forkit) {
  char *argv[32];
  int argi = 0;
  char buf[16];
  char *cmd;

  cmd = strdup_strip (default_q1_cmd);

  argv[argi++] = strtok (cmd, delim);
  while ((argv[argi] = strtok (NULL, delim)) != NULL)
    argi++;

  if (default_nosound)
    argv[argi++] = "-nosound";

  if (default_nocdaudio)
    argv[argi++] = "-nocdaudio";

  if (con->gamedir) {
    argv[argi++] = "-game";
    argv[argi++] = con->gamedir;
  }

  argv[argi++] = "+exec";
  argv[argi++] = EXEC_CFG;

  if (con->demo) {
    argv[argi++] = "+record";
    argv[argi++] = con->demo;
  }
  
  if (con->server) {
    if (con->s->port != Q1_DEFAULT_PORT) {
      g_snprintf (buf, 16, "%d", con->s->port);
      argv[argi++] = "+port";
      argv[argi++] = buf;
    }
    argv[argi++] = "+connect";
    argv[argi++] = con->server;
  }

  argv[argi] = NULL;

  client_launch_exec (forkit, real_quake_dir, argv, con->s);

  g_free (cmd);
}


static void qw_exec (const struct condef *con, int forkit) {
  char *argv[32];
  int argi = 0;
  char *q_cmd;
  char *q_dir;
  char *q_conf;
  char *q_passwd;
  char *cmd;
  char *file;

  switch (con->s->type) {

  case QW_SERVER:
    q_cmd = default_qw_cmd;
    q_dir = real_quake_dir;
    q_conf = "id1/" EXEC_CFG;
    q_passwd = "id1/" PASSWORD_CFG;
    break;

  case Q2_SERVER:
    q_cmd = default_q2_cmd;
    q_dir = real_q2_dir;
    q_conf = "baseq2/" EXEC_CFG;
    q_passwd = "baseq2/" PASSWORD_CFG;
    break;

  default:
    return;
  }

  cmd = strdup_strip (q_cmd);

  argv[argi++] = strtok (cmd, delim);
  while ((argv[argi] = strtok (NULL, delim)) != NULL)
    argi++;

  switch (con->s->type) {

  case QW_SERVER:
    if (default_nosound)
      argv[argi++] = "-nosound";

    if (default_nocdaudio)
      argv[argi++] = "-nocdaudio";

    if (con->gamedir) {
      argv[argi++] = "-gamedir";
      argv[argi++] = con->gamedir;
    }

    break;

  case Q2_SERVER:
    if (default_nosound) {
      argv[argi++] = "+set";
      argv[argi++] = "s_initsound";
      argv[argi++] = "0";
    }

    argv[argi++] = "+set";
    argv[argi++] = "cd_nocd";
    argv[argi++] = (default_nocdaudio)? "1" : "0";

    if (con->gamedir) {
      argv[argi++] = "+set";
      argv[argi++] = "game";
      argv[argi++] = con->gamedir;
    }

    break;

  default:
    break;

  }

  if (con->password || con->rcon_password || real_password (con->observe)) {
    file = file_in_dir (q_dir, q_passwd);

    if (!write_passwords (file, con)) {
      if (!dialog_yesno (NULL, 1, "Launch", "Cancel", 
             "Cannot write to file \"%s\".\n\nLaunch client anyway?", file)) {
	g_free (file);
	g_free (cmd);
	return;
      }
    }

    g_free (file);

    argv[argi++] = "+exec";
    argv[argi++] = PASSWORD_CFG;
  }
  else {
    if (con->observe) {
	argv[argi++] = "+spectator";
	argv[argi++] = con->observe;
    }
  }

  if (con->s->type == Q2_SERVER || 
                               (con->s->type == QW_SERVER && !con->gamedir)) {
    argv[argi++] = "+exec";
    argv[argi++] = EXEC_CFG;
  }

  if (con->server) {
    if (!con->demo || con->s->type == Q2_SERVER) {
      argv[argi++] = "+connect";
      argv[argi++] = con->server;
    }
    if (con->demo) {
      argv[argi++] = "+record";
      argv[argi++] = con->demo;
      if (con->s->type == QW_SERVER)
	argv[argi++] = con->server;
    }
  }

  argv[argi] = NULL;

  client_launch_exec (forkit, q_dir, argv, con->s);

  g_free (cmd);
}


static char *dir_custom_cfg_filter (const char *dir, const char *str) {
  static const char *cfgext[] = { ".cfg", ".scr", ".rc", NULL };
  const char **ext;
  int len;

  if (!str)
    return NULL;

  len = strlen (str);

  for (ext = cfgext; *ext; ext++) {
    if (len > strlen (*ext) && 
                          strcasecmp (str + len - strlen (*ext), *ext) == 0) {
      return g_strdup (str);
    }
  }

  return NULL;
}


static GList *custom_cfg_filter (GList *list) {
  GList *tmp;
  GList *res = NULL;
  char *str;

  for (tmp = list; tmp; tmp = tmp->next) {
    str = (char *) tmp->data;
    if (strcmp (str, EXEC_CFG) && strcmp (str, PASSWORD_CFG) && 
        strcmp (str, "__qf__.cfg") && strcasecmp (str, "config.cfg") && 
        strcasecmp (str, "server.cfg") && strcasecmp (str, "autoexec.cfg") &&
        strcasecmp (str, "quake.rc")) {
      res = g_list_prepend (res, str);
    }
    else {
      g_free (str);
    }
  }

  g_list_free (list);
  res = g_list_reverse (res);
  return res;
}


static GList *quake_custom_cfgs (const char *path, const char *mod_path) {
  GList *cfgs = NULL;
  GList *mod_cfgs = NULL;

  if (path) {
    cfgs = dir_to_list (path, dir_custom_cfg_filter);

    if (mod_path) {
      mod_cfgs = dir_to_list (mod_path, dir_custom_cfg_filter);
      cfgs = merge_sorted_string_lists (cfgs, mod_cfgs);
    }

    cfgs = custom_cfg_filter (cfgs);
  }

  return cfgs;
}


static GList *q1_custom_cfgs (char *dir, char *game) {
  GList *cfgs;
  char *qdir;
  char *path = NULL;
  char *mod_path = NULL;

  qdir = expand_tilde ((dir)? dir : default_quake_dir, user.home);

  path = file_in_dir (qdir, "id1");
  if (game)
    mod_path = file_in_dir (qdir, game);

  g_free (qdir);

  cfgs = quake_custom_cfgs (path, mod_path);

  g_free (path);
  if (mod_path)
    g_free (mod_path);

  return cfgs;
}


static GList *qw_custom_cfgs (char *dir, char *game) {
  GList *cfgs;
  char *qdir;
  char *path = NULL;
  char *mod_path = NULL;

  qdir = expand_tilde ((dir)? dir : default_quake_dir, user.home);

  path = file_in_dir (qdir, "id1");
  mod_path = file_in_dir (qdir, (game)? game : "qw");

  g_free (qdir);

  cfgs = quake_custom_cfgs (path, mod_path);

  g_free (path);
  if (mod_path)
    g_free (mod_path);

  return cfgs;
}


static GList *q2_custom_cfgs (char *dir, char *game) {
  GList *cfgs;
  char *qdir;
  char *path = NULL;
  char *mod_path = NULL;

  qdir = expand_tilde ((dir)? dir : default_q2_dir, user.home);

  path = file_in_dir (qdir, "baseq2");
  if (game)
    mod_path = file_in_dir (qdir, game);

  g_free (qdir);

  cfgs = quake_custom_cfgs (path, mod_path);

  g_free (path);
  if (mod_path)
    g_free (mod_path);

  return cfgs;
}

