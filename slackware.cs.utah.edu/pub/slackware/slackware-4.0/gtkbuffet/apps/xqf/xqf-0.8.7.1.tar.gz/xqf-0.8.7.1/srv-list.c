/* XQF - Quake server browser and launcher
 * Copyright (C) 1998 Roman Pozlevich <roma@botik.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <sys/types.h>
#include <stdio.h>	/* sprintf */
#include <stdlib.h>	/* qsort */

#include <gtk/gtk.h>

#include "xqf.h"
#include "game.h"
#include "stat.h"
#include "skin.h"
#include "filter.h"
#include "utils.h"
#include "dns.h"
#include "pref.h"
#include "server.h"
#include "psearch.h"
#include "dialogs.h"
#include "pixmaps.h"
#include "srv-info.h"
#include "srv-list.h"


GSList *qw_colors_pixmap_cache = NULL;
GSList *server_pixmap_cache = NULL;


static int last_row_clicked = 0;


static GdkPixmap *create_server_pixmap (GtkWidget *window, struct server *s,
                                                             GSList **cache) {
  GdkPixmap *pixmap;
  struct pixmap *stype;
  GdkGC *white_gc;
  int hb, wb, hs, ws;
  unsigned key;

  if (!s || !window || !buddy_pix[1].pix || !q_pix.pix)
    return NULL;

  key = ((s->flags & PLAYER_GROUP_MASK) << 8) + s->type;

  if (!GTK_WIDGET_REALIZED (window))
    gtk_widget_realize (window);

  if (cache) {
    pixmap = pixmap_cache_lookup (*cache, key);
    if (pixmap)
      return pixmap;
  }

  stype = games[s->type].pix;

  white_gc = window->style->bg_gc[GTK_STATE_PRELIGHT];

  gdk_window_get_size (buddy_pix[1].pix, &wb, &hb);
  gdk_window_get_size (stype->pix, &ws, &hs);

  pixmap = gdk_pixmap_new (window->window, wb + ws, MAX (hs, hb), -1);

  gdk_draw_rectangle (pixmap, white_gc, TRUE, 0, 0, wb + ws, MAX (hs, hb));

  if ((s->flags & PLAYER_GROUP_MASK) != 0) {
    ensure_buddy_pix (window, s->flags & PLAYER_GROUP_MASK);

    gdk_gc_set_clip_origin (white_gc, 0, 0);
    gdk_gc_set_clip_mask (white_gc, 
                                buddy_pix[s->flags & PLAYER_GROUP_MASK].mask);

    gdk_draw_pixmap (pixmap, white_gc, 
             buddy_pix[s->flags & PLAYER_GROUP_MASK].pix, 0, 0, 0, 0, wb, hb);
  }

  gdk_gc_set_clip_origin (white_gc, wb, 0);
  gdk_gc_set_clip_mask (white_gc, stype->mask);

  gdk_draw_pixmap (pixmap, white_gc, stype->pix, 0, 0, wb, 0, ws, hs);

  gdk_gc_set_clip_origin (white_gc, 0, 0);
  gdk_gc_set_clip_mask (white_gc, NULL);

  if (cache)
    pixmap_cache_add (cache, pixmap, key);

  return pixmap;
}


static int server_clist_refresh_row (struct server *s, int row) {
  GdkPixmap *server_pixmap;
  char *text[7];
  char buf1[64], buf2[32], buf3[32], buf4[32];
  int col;
  int frozen;

  text[0] = NULL;

  sprintf (buf1, "%s:%d", 
         (show_hostnames && s->host->name)? s->host->name : s->host->address, 
                                                                     s->port);
  text[1] = buf1;

  if (s->ping >= 0) {
    sprintf (buf2, "%d", (s->ping > MAX_PING)? MAX_PING : s->ping);
    text[2] = buf2;
  }
  else {
    text[2] = "n/a";
  }

  if (s->retries >= 0) {
    if (s->ping == MAX_PING + 1) {
      text[3] = "D";	/* DOWN */
    }
    else if (s->ping == MAX_PING) {
      text[3] = "T";	/* TIMEOUT */
    }
    else {
      sprintf (buf3, "%d", s->retries);
      text[3] = buf3;
    }
  }
  else {
    text[3] = "n/a";
  }

  sprintf (buf4, "%d/%d", s->curplayers, s->maxplayers);
  text[4] = (!s->curplayers)? buf4 : NULL;

  text[5] = (s->map)?  s->map : NULL;
  text[6] = (s->game)? s->game : NULL;

  frozen = GTK_CLIST_FROZEN (GTK_CLIST (server_clist));

  if (row < 0)
    row = gtk_clist_append (GTK_CLIST (server_clist), text);
  else {
    if (!frozen)
      GTK_CLIST_SET_FLAGS (GTK_CLIST (server_clist), CLIST_FROZEN);

    for (col = 1; col < 7; col++) {
      gtk_clist_set_text (GTK_CLIST (server_clist), row, col, text[col]);
    }

    if (!frozen)
      GTK_CLIST_UNSET_FLAGS (GTK_CLIST (server_clist), CLIST_FROZEN);
  }

  if (!frozen)
    GTK_CLIST_SET_FLAGS (GTK_CLIST (server_clist), CLIST_FROZEN);

  gtk_clist_set_shift (GTK_CLIST (server_clist), row, 4, 0, 
                     (s->curplayers)? 0 : pixmap_width (man_red_pix.pix) + 2);
  if (s->curplayers) {
    gtk_clist_set_pixtext (GTK_CLIST (server_clist), row, 4, buf4, 2,
     (s->curplayers == s->maxplayers)? man_red_pix.pix : man_black_pix.pix,
     (s->curplayers == s->maxplayers)? man_red_pix.mask : man_black_pix.mask);
  }

  if (!frozen)
    GTK_CLIST_UNSET_FLAGS (GTK_CLIST (server_clist), CLIST_FROZEN);

  server_pixmap = create_server_pixmap (main_window, s, &server_pixmap_cache);
  gtk_clist_set_pixtext (GTK_CLIST (server_clist), row, 0, 
                             (s->name)? s->name : "", 2, server_pixmap, NULL);
  gdk_pixmap_unref (server_pixmap);

  return row;
}


static void server_clist_select_servers (GSList *servers) {
  struct server *s;
  int row;

  if (!servers || !cur_list)
    return;

  while (servers) {
    s = (struct server *) servers->data;

    row = slist_index (cur_list, s);
    if (row >= 0) {
      gtk_clist_select_row (GTK_CLIST (server_clist), row, 0);
      last_row_clicked = row;
    }

    servers = servers->next;
  }
}


void populate_server_clist (GSList **servers, GSList *selection) {
  GSList *s;

  if (!servers || !*servers) {
    gtk_clist_clear (GTK_CLIST (server_clist));
    pixmap_cache_clear (&server_pixmap_cache, 4);
    return;
  }

  s = *servers = qsort_slist (*servers, qsort_servers);

  /* 
   *  It's basically gtk_clist_clear (GTK_CLIST (server_clist))
   *  without touching vertical offset and scrollbars
   */

  gtk_clist_freeze (GTK_CLIST (server_clist));
  while (GTK_CLIST (server_clist)->rows)
    gtk_clist_remove (GTK_CLIST (server_clist), 0);

  while (s) {
    server_clist_refresh_row ((struct server *) s->data, -1);
    s = s->next;
  }

  if (selection)
    server_clist_select_servers (selection);
  else
    last_row_clicked = 0;

  gtk_clist_thaw (GTK_CLIST (server_clist));

  pixmap_cache_clear (&server_pixmap_cache, 8);
}


void populate_player_clist (struct server *s, int refresh) {
  GdkPixmap *qw_colors_pixmap = NULL;
  char *text[6];
  char buf1[32], buf2[32], buf3[32], buf4[32];
  int i;
  struct player *p;

  if (s->players == NULL) {
    gtk_clist_clear (GTK_CLIST (player_clist));
    return;
  }

  if ((games[s->type].flags & GAME_QUAKE_PLAYER_COLORS) != 0)
    allocate_quake_player_colors (main_window->window);

  text[0] = text[1] = text[2] = text[3] = text[4] = text[5] = NULL;

  gtk_clist_freeze (GTK_CLIST (player_clist));
  if (refresh) {
    while (GTK_CLIST (player_clist)->rows)
      gtk_clist_remove (GTK_CLIST (player_clist), 0);
  }
  else {
    gtk_clist_clear (GTK_CLIST (player_clist));
  }

  qsort (s->players, s->curplayers, sizeof (gpointer), qsort_players);

  for (i = 0; i < s->curplayers; i++) {
    p = s->players[i];

    if (p->name && (p->flags & PLAYER_GROUP_MASK) == 0)
      text[0] = p->name;

    sprintf (buf1, "%d", p->frags);
    text[1] = buf1;

    if (p->skin)
      text[3] = p->skin;

    if (p->ping >= 0) {
      sprintf (buf3, "%d", p->ping);
      text[4] = buf3;
    }

    if (p->time >= 0) {
      sprintf (buf4, "%02d:%02d", p->time / 60 / 60, p->time / 60 % 60);
      text[5] = buf4;
    }

    gtk_clist_append (GTK_CLIST (player_clist), text);

    if ((p->flags & PLAYER_GROUP_MASK) == 0) {
      gtk_clist_set_shift (GTK_CLIST (player_clist), i, 0, 0, 
                                         pixmap_width (buddy_pix[1].pix) + 2);
    }
    else {
      ensure_buddy_pix (main_window, p->flags & PLAYER_GROUP_MASK);
      gtk_clist_set_pixtext (GTK_CLIST (player_clist), i, 0, 
                                (p->name)? p->name : "", 2,
                                buddy_pix[p->flags & PLAYER_GROUP_MASK].pix, 
			        buddy_pix[p->flags & PLAYER_GROUP_MASK].mask);
    }

    if ((games[s->type].flags & GAME_QUAKE_PLAYER_COLORS) != 0) {
      qw_colors_pixmap = qw_colors_pixmap_create (main_window, 
                                 p->shirt, p->pants, &qw_colors_pixmap_cache);

      sprintf (buf2, "%d:%d", p->shirt, p->pants);
      gtk_clist_set_pixtext (GTK_CLIST (player_clist), i, 2, buf2, 2, 
                                                      qw_colors_pixmap, NULL);
      gdk_pixmap_unref (qw_colors_pixmap);
    }
  }

  gtk_clist_thaw (GTK_CLIST (player_clist));

  pixmap_cache_clear (&qw_colors_pixmap_cache, 10);
}


void sync_selection (int refresh) {
  GList *selection;
  GSList *tmp;

  selection = GTK_CLIST (server_clist)->selection;

  if (selection && !selection->next) {
    last_row_clicked = (int) selection->data;
    tmp = g_slist_nth (cur_list, last_row_clicked);
    cur_server = (struct server *) tmp->data;
    populate_player_clist (cur_server, refresh);
    populate_serverinfo_clist (cur_server, refresh);
  }
  else {
    cur_server = NULL;
    gtk_clist_clear (GTK_CLIST (player_clist));
    gtk_clist_clear (GTK_CLIST (serverinfo_clist));
  }

  set_widgets_sensitivity ();
}


int server_clist_refresh_server (struct server *s) {
  int row;

  row = slist_index (cur_list, s);
  if (row >= 0) {
    server_clist_refresh_row (s, row);
    if (s == cur_server) {
      populate_player_clist (cur_server, TRUE);
      populate_serverinfo_clist (cur_server, TRUE);
    }
    return TRUE;
  }
  else {
    apply_filters (cur_filter | FILTER_PLAYER_MASK, s);
    if ((s->filters & cur_filter) == cur_filter) {
      server_clist_refresh_row (s, -1);
      cur_list = g_slist_append (cur_list, s);
      s->ref_count++;
      return TRUE;
    }
  }
  return FALSE;
}


void server_clist_select_row (int row, int state) {
  GList *list = GTK_CLIST (server_clist)->selection;
  int i;
  int low, high;

  if (state & GDK_CONTROL_MASK) {	/* add to selection */
    if (g_list_find (list, (gpointer) row))
      gtk_clist_unselect_row (GTK_CLIST (server_clist), row, 0);
    else
      gtk_clist_select_row (GTK_CLIST (server_clist), row, 0);

    last_row_clicked = row;
  }
  else if (state & GDK_SHIFT_MASK) {	/* extend selection */
    if (row >= last_row_clicked) {
      low = last_row_clicked;
      high = row;
    }
    else {
      low = row;
      high = last_row_clicked;
    }

    while (list) {
      i = (int) list->data;
      list = list->next;
      if (i < low || i > high)
	gtk_clist_unselect_row (GTK_CLIST (server_clist), i, 0);
    }

    list = GTK_CLIST (server_clist)->selection;

    for (i = low; i <= high; i++) {
      if (!g_list_find (list, (gpointer) i))
	gtk_clist_select_row (GTK_CLIST (server_clist), i, 0);
    }
  }
  else {		/* select one server */
    while (list) {
      i = (int) list->data;
      list = list->next;
      if (i != row)
	gtk_clist_unselect_row (GTK_CLIST (server_clist), i, 0);
    }

    if (!GTK_CLIST (server_clist)->selection)
      gtk_clist_select_row (GTK_CLIST (server_clist), row, 0);

    last_row_clicked = row;
  }

  sync_selection (FALSE);
}


void server_clist_clear_selection (void) {
  GList *list = GTK_CLIST (server_clist)->selection;
  int i;

  while (list) {
    i = (int) list->data;
    list = list->next;
    gtk_clist_unselect_row (GTK_CLIST (server_clist), i, 0);
  }

  last_row_clicked = 0;
  sync_selection (FALSE);
}


static int qsort_integers (const void *a, const void *b) {
  int ia = * (int *) a;
  int ib = * (int *) b;
  
  return ia - ib;
}


void server_clist_remove_selected (void) {
  GSList **cursrv;
  GSList *victim;
  GSList *indexes;
  GSList *index;
  int i;

  indexes = list_replicate (GTK_CLIST (server_clist)->selection);

  if (!indexes)
    return;

  indexes = qsort_slist (indexes, qsort_integers);

  cursrv = &cur_list;
  index = indexes;

  for (i = 0; *cursrv && index; i++) {
    if (i == (int) index->data) {
      index = index->next;

      victim = *cursrv;
      *cursrv = (*cursrv)->next;

      server_unref ((struct server *) victim->data);
      g_slist_free_1 (victim);
    }
    else {
      cursrv = &(*cursrv)->next;
    }
  }

  indexes = g_slist_reverse (indexes);

  gtk_clist_freeze (GTK_CLIST (server_clist));

  for (index = indexes; index; index = index->next) {
    gtk_clist_remove (GTK_CLIST (server_clist), (int) index->data);
  }

  g_slist_free (indexes);

  gtk_clist_thaw (GTK_CLIST (server_clist));
  sync_selection (FALSE);
}


void server_clist_select_all (int invert) {
  GSList *cursrv;
  GSList *indexes;
  GSList *index;
  int i;

  if (!cur_list)
    return;

  indexes = list_replicate (GTK_CLIST (server_clist)->selection);
  indexes = qsort_slist (indexes, qsort_integers);

  cursrv = cur_list;
  index = indexes;

  for (i = 0; cursrv; i++) {
    if (!index) {
      gtk_clist_select_row (GTK_CLIST (server_clist), i, 0);
    }
    else {
      if ((int) index->data == i) {
	if (invert)
	  gtk_clist_unselect_row (GTK_CLIST (server_clist), i, 0);
        index = index->next;
      }
      else {
	gtk_clist_select_row (GTK_CLIST (server_clist), i, 0);
      }
    }
    cursrv = cursrv->next;
  }

  g_slist_free (indexes);
  sync_selection (TRUE);
}


GSList *server_clist_selected_servers (void) {
  GList *rows = GTK_CLIST (server_clist)->selection;
  GSList *list = NULL;
  GSList *tmp;
  struct server *s;

  if (!cur_list)
    return NULL;
    
  while (rows) {
    tmp = g_slist_nth (cur_list, (int) rows->data);
    s = (struct server *) tmp->data;
    list = g_slist_prepend (list, s);
    s->ref_count++;
    rows = rows->next;
  }

  return list;
}


void server_clist_selection_visible (void) {
  GList *rows = GTK_CLIST (server_clist)->selection;
  GList *row;
  GtkVisibility vis;
  int min;

  if (!rows)
    return;

  for (row = rows; row; row = row->next) {
    vis = gtk_clist_row_is_visible (GTK_CLIST (server_clist), (int) row->data);
    if (vis == GTK_VISIBILITY_FULL)
      return;
  }

  min = (int) rows->data;
  for (row = rows->next; row; row = row->next) {
    if (min > (int) row->data)
      min = (int) row->data;
  }

  if (rows->next)	/* if (g_list_length (rows) > 1) */
    gtk_clist_moveto (GTK_CLIST (server_clist), min, 0, 0.2, 0.0);
  else 
    gtk_clist_moveto (GTK_CLIST (server_clist), min, 0, 0.5, 0.0);
}


void server_clist_show_hostname (struct host *h) {
  struct server *s;
  GSList *tmp;
  char buf[256];
  int row = 0;

  if (!h->name)
    return;

  for (tmp = cur_list; tmp; tmp = tmp->next) {
    s = (struct server *) tmp->data;
    if (s->host == h) {
      sprintf (buf, "%s:%d", s->host->name, s->port);
      gtk_clist_set_text (GTK_CLIST (server_clist), row, 1, buf);
    }
    row++;
  }
}


void server_clist_show_hostnames (void) {
  struct server *s;
  GSList *tmp;
  char buf[256];
  int row = 0;

  for (tmp = cur_list; tmp; tmp = tmp->next) {
    s = (struct server *) tmp->data;
    if (s->host->name) {
      sprintf (buf, "%s:%d", 
         (show_hostnames && s->host->name)? s->host->name : s->host->address, 
                                                                     s->port);
      gtk_clist_set_text (GTK_CLIST (server_clist), row, 1, buf);
    }
    row++;
  }
}


void find_player (int find_next) {
  GList *selection;
  GtkVisibility vis;
  int old_server;
  int old_player;
  int server;
  int player;

  if (psearch_data_is_empty ())
    return;

  old_server = server = -1;
  old_player = player = -1;

  if (find_next) {
    old_server = server = last_row_clicked;

    selection = GTK_CLIST (player_clist)->selection;
    if (selection) {
      old_player = player = (int) selection->data + 1;
    }
  }

  if (psearch_next_player (&server, &player)) {
    if (old_server != server)
      server_clist_select_row (server, 0);

    gtk_clist_select_row (GTK_CLIST (player_clist), player, 0);

    vis = gtk_clist_row_is_visible (GTK_CLIST (player_clist), player);
    if (vis != GTK_VISIBILITY_FULL) {
      gtk_clist_moveto (GTK_CLIST (player_clist), player, 0, 0.5, 0.0);
    }
  }
  else {
    if (old_server < 0 && old_player < 0) {
      dialog_ok (NULL, "Player not found.");
    }
    else {
      if (dialog_yesno (NULL, 0, "OK", "Cancel",
                   "End of server list reached.  Continue from beginning?")) {
	find_player (FALSE);
      }
    }
  }
}
