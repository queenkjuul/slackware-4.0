/* XQF - Quake server browser and launcher
 * Copyright (C) 1998 Roman Pozlevich <roma@botik.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#ifndef __XQF_H__
#define __XQF_H__

#include <sys/types.h>
#include <netinet/in.h> /* struct in_addr */
#include <arpa/inet.h>	/* struct in_addr */

#include <gtk/gtk.h>


#define XQF_VERSION	"0.8.7.1"

#define RC_DIR		".qf"
#define RC_FILE		"qfrc"
#define SERVERS_FILE	"servers"
#define PLAYERS_FILE	"players"
#define EXEC_CFG	"frontend.cfg"
#define PASSWORD_CFG	"__passwd.cfg"

#define MAX_PING	9999
#define MAX_RETRIES	10

#define	Q1_DEFAULT_PORT		26000
#define	QW_DEFAULT_PORT		27500
#define	Q2_DEFAULT_PORT		27910
#define	H2_DEFAULT_PORT		26900
#define	HW_DEFAULT_PORT		26950
#define	QWM_DEFAULT_PORT	27000
#define	Q2M_DEFAULT_PORT	27900

#define PLAYER_GROUP_MASK	0x07
#define PLAYER_GROUP_RED	0x01
#define PLAYER_GROUP_GREEN	0x02
#define PLAYER_GROUP_BLUE	0x04

#define SERVER_CHEATS		0x08
#define SERVER_PASSWORD		0x10
#define SERVER_SP_PASSWORD	0x20
#define SERVER_SPECTATE		0x40
#define SERVER_REFRESH		0x80

enum launch_mode { 
  LAUNCH_NORMAL,
  LAUNCH_SPECTATE,
  LAUNCH_RECORD
};

enum server_type { 
  Q1_SERVER = 0,
  QW_SERVER,
  Q2_SERVER,
  H2_SERVER,
  HW_SERVER,
  UNKNOWN_SERVER
};

enum psort_mode {
  SORT_PLAYER_NONE = 0,
  SORT_PLAYER_NAME,
  SORT_PLAYER_FRAGS,
  SORT_PLAYER_TIME,
  SORT_PLAYER_COLOR,
  SORT_PLAYER_PING,
  SORT_PLAYER_SKIN
};

enum ssort_mode {
  SORT_SERVER_NONE = 0,
  SORT_SERVER_NAME,
  SORT_SERVER_ADDRESS,
  SORT_SERVER_MAP,
  SORT_SERVER_PLAYERS,
  SORT_SERVER_PING,
  SORT_SERVER_TO,
  SORT_SERVER_GAME
};

enum isort_mode {
  SORT_INFO_NONE = 0,
  SORT_INFO_RULE,
  SORT_INFO_VALUE
};

struct player {
  char	*name;
  int	time;
  short frags;
  short ping;
  unsigned char shirt;
  unsigned char pants;
  unsigned char flags;
  char	*skin;
};

struct host {
  char *address;
  char *name;
  struct in_addr ip;
  int ref_count;
};

struct server {
  enum server_type type;
  struct host *host;
  unsigned short port;

  char	*name;
  char	*map;
  unsigned short maxplayers;
  unsigned short curplayers;
  short	ping;
  short retries;
  struct player **players;
  char 	**info;
  char 	*game;		/* a reference to info item */

  unsigned char flags;	/* flags */

  unsigned char filters;
  unsigned char flt_mask;
  unsigned flt_last;	/* time of the last filtering */

  int 	ref_count;
};

struct master {
  struct host *host;
  unsigned short port;
  char	*name;
  enum server_type type;
  enum server_type protocol;
  GSList *servers;
  GSList *sources;
};

struct clist_coldef {
  char 	*name;
  int	width;
  GtkJustification justify;
  int	sortmode;
  GtkWidget *widget;
};

struct user_info {
  char	*name;
  char	*home;
  char	*rcdir;
};

extern 	GtkWidget *main_window;
extern  GtkWidget *server_clist;
extern  GtkWidget *player_clist;
extern  GtkWidget *serverinfo_clist;

extern	struct clist_coldef server_clist_columns[];
extern  struct clist_coldef player_clist_columns[];
extern  struct clist_coldef serverinfo_clist_columns[];

extern	struct server *cur_server;
extern	GSList *cur_list;

extern 	int psort_column;
extern 	int ssort_column;
extern 	int isort_column;

extern	int show_hostnames;

extern	int window_delete_event_callback (GtkWidget *widget, gpointer data);
extern	void register_window (GtkWidget *window);
extern	void unregister_window (GtkWidget *window);
extern	GtkWidget *top_window (void);

extern	void set_widgets_sensitivity (void);


#endif /* __XQF_H__ */

