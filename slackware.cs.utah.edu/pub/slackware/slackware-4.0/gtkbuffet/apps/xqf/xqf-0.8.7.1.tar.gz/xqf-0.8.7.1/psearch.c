/* XQF - Quake server browser and launcher
 * Copyright (C) 1998 Roman Pozlevich <roma@botik.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <sys/types.h>
#include <regex.h>
#include <string.h>	/* strcmp */
#include <ctype.h>	/* tolower */
#include <stdlib.h>	/* qsort */

#include <gtk/gtk.h>

#include "xqf.h"
#include "dialogs.h"
#include "stat.h"
#include "utils.h"
#include "psearch.h"


#define REGCOMP_FLAGS 	(REG_EXTENDED | REG_NOSUB | REG_ICASE)


static struct psearch_data psearch = { NULL, PSEARCH_MODE_SUBSTR, NULL };

static GList *psearch_history = NULL;

static GtkWidget *psearch_combo;
static GtkWidget *mode_buttons[3];

static int psearch_new_pattern;

static const char *mode_names[3] = { 
  "exact match",
  "substring",
  "regular expression"
};


static void psearch_history_free (void) {
  g_list_foreach (psearch_history, (GFunc) g_free, NULL);
  g_list_free (psearch_history);
  psearch_history = NULL;
}


static char *psearch_history_add (char *str) {
  GList *list;

  if (!str)
    return NULL;

  for (list = psearch_history; list; list = list->next) {
    if (!strcmp (str, (char *) list->data)) {
      g_free (list->data);
      psearch_history = g_list_remove_link (psearch_history, list);
      break;
    }
  }

  while (psearch_history && 
                g_list_length (psearch_history) >= PSEARCH_HISTORY_MAXITEMS) {
    list = g_list_last (psearch_history);
    g_free (list->data);
    psearch_history = g_list_remove_link (psearch_history, list); 
  }
  
  psearch_history = g_list_prepend (psearch_history, g_strdup (str));
  return str;
}


static int psearch_test_player (struct player *p) {
  return
    ((psearch.mode == PSEARCH_MODE_STRING && 
          g_strcasecmp (p->name, psearch.data) == 0) ||
     (psearch.mode == PSEARCH_MODE_SUBSTR && 
          lowcasestrstr (p->name, psearch.data)) ||
     (psearch.mode == PSEARCH_MODE_REGEXP &&
          regexec ((regex_t *) psearch.data, p->name, 0, NULL, 0) == 0));
}


static void psearch_free_pattern_data (void) {
  if (psearch.data) {
    if (psearch.mode == PSEARCH_MODE_REGEXP) {
      regfree ((regex_t *) psearch.data);
    }
    g_free (psearch.data);
    psearch.data = NULL;
  }
}


static void psearch_free_pattern (void) {
  if (psearch.pattern) {
    g_free (psearch.pattern);
    psearch.pattern = NULL;
  }
  psearch_free_pattern_data ();
}


static char *get_regerror (int errcode, regex_t *compiled) {
  size_t length;
  char *buffer;

  length = regerror (errcode, compiled, NULL, 0);
  buffer = g_malloc (length);
  regerror (errcode, compiled, buffer, length);
  return buffer;
}


static int psearch_compile_pattern (void) {
  char *error;
  char *c;
  int res;

  psearch_free_pattern_data ();

  if (psearch.pattern && psearch.pattern[0]) {
    switch (psearch.mode) {

    case PSEARCH_MODE_REGEXP:
      psearch.data = g_malloc (sizeof (regex_t));

      res = regcomp ((regex_t *) psearch.data, psearch.pattern, REGCOMP_FLAGS);
      if (res) {
	error = get_regerror (res, (regex_t *) psearch.data);
	psearch_free_pattern ();

	dialog_ok ("XQF: Error", "Regular Expression Error!\n\n%s\n\n%s.",
                                                      psearch.pattern, error);
	g_free (error);
	return FALSE;
      }
      break;

    case PSEARCH_MODE_STRING:
    case PSEARCH_MODE_SUBSTR:
    default:
      psearch.data = g_strdup (psearch.pattern);

      for (c = (char *) psearch.data; *c; c++) {
	*c = tolower (*c);
      }
      break;

    }

    return TRUE;
  }

  return FALSE;
}


static void psearch_combo_activate_callback (GtkWidget *widget, 
                                                              gpointer data) {
  psearch_free_pattern ();

  if (GTK_TOGGLE_BUTTON (mode_buttons[PSEARCH_MODE_STRING])->active)
    psearch.mode = PSEARCH_MODE_STRING;
  else if (GTK_TOGGLE_BUTTON (mode_buttons[PSEARCH_MODE_SUBSTR])->active)
    psearch.mode = PSEARCH_MODE_SUBSTR;
  else
    psearch.mode = PSEARCH_MODE_REGEXP;

  psearch.pattern = strdup_strip (
           gtk_entry_get_text (GTK_ENTRY (GTK_COMBO (psearch_combo)->entry)));

  if (psearch.pattern && psearch.pattern[0]) {
    psearch_history_add (psearch.pattern);
    psearch_new_pattern = psearch_compile_pattern ();
  }
}


int find_player_dialog (void) {
  GtkWidget *window;
  GtkWidget *main_vbox;
  GtkWidget *hbox;
  GtkWidget *button;
  GtkWidget *label;
  GSList *group;
  int i;

  psearch_new_pattern = FALSE;

  window = dialog_create_modal_transient_window ("Find Player", TRUE, FALSE);

  main_vbox = gtk_vbox_new (FALSE, 8);
  gtk_container_border_width (GTK_CONTAINER (main_vbox), 16);
  gtk_container_add (GTK_CONTAINER (window), main_vbox);

  hbox = gtk_hbox_new (FALSE, 4);
  gtk_box_pack_start (GTK_BOX (main_vbox), hbox, FALSE, FALSE, 0);

  /* Pattern Entry */

  label = gtk_label_new ("Find Player:");
  gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, FALSE, 0);
  gtk_widget_show (label);

  /* ComboBox */

  psearch_combo = gtk_combo_new ();
  gtk_entry_set_max_length (GTK_ENTRY (GTK_COMBO (psearch_combo)->entry), 128);
  gtk_widget_set_usize (GTK_COMBO (psearch_combo)->entry, 160, -1);
  gtk_combo_disable_activate (GTK_COMBO (psearch_combo));
  if (psearch_history) {
    gtk_combo_set_popdown_strings (GTK_COMBO (psearch_combo), 
                                                             psearch_history);
    gtk_entry_set_text (GTK_ENTRY (GTK_COMBO (psearch_combo)->entry), 
                                              (char *) psearch_history->data);
    gtk_entry_select_region (GTK_ENTRY (GTK_COMBO (psearch_combo)->entry), 0, 
                                     strlen ((char *) psearch_history->data));
  }
  gtk_signal_connect (GTK_OBJECT (GTK_COMBO (psearch_combo)->entry), 
         "activate", GTK_SIGNAL_FUNC (psearch_combo_activate_callback), NULL);
  gtk_signal_connect_object (GTK_OBJECT (GTK_COMBO (psearch_combo)->entry), 
       "activate", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (window));
  gtk_box_pack_start (GTK_BOX (hbox), psearch_combo, TRUE, TRUE, 0);
  gtk_widget_grab_focus (GTK_COMBO (psearch_combo)->entry);
  gtk_widget_show (psearch_combo);

  /* OK Button */

  button = gtk_button_new_with_label (" OK ");
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
		            GTK_SIGNAL_FUNC (psearch_combo_activate_callback),
			    GTK_OBJECT (psearch_combo));
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
	           GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (window));
  gtk_box_pack_start (GTK_BOX (hbox), button, FALSE, FALSE, 0);
  gtk_widget_show (button);

  /* Cancel Button */

  button = gtk_button_new_with_label (" Cancel ");
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (window));
  gtk_box_pack_start (GTK_BOX (hbox), button, FALSE, FALSE, 0);
  gtk_widget_show (button);

  gtk_widget_show (hbox);

  /* Mode Buttons */

  hbox = gtk_hbox_new (FALSE, 4);
  gtk_box_pack_start (GTK_BOX (main_vbox), hbox, FALSE, FALSE, 0);

  group = NULL;

  for (i = 0; i < 3; i++) {
    mode_buttons[i] = gtk_radio_button_new_with_label (group, mode_names[i]);
    group = gtk_radio_button_group (GTK_RADIO_BUTTON (mode_buttons[i]));
    gtk_box_pack_start (GTK_BOX (hbox), mode_buttons[i], FALSE, FALSE, 0);
    gtk_widget_show (mode_buttons[i]);
  }

  gtk_toggle_button_set_state (
                        GTK_TOGGLE_BUTTON (mode_buttons[psearch.mode]), TRUE);

  gtk_widget_show (hbox);

  gtk_widget_show (main_vbox);
  gtk_widget_show (window);

  gtk_main ();

  unregister_window (window);

  return psearch_new_pattern;
}


void psearch_free_data (void) {
  if (psearch.pattern) {
    psearch_free_pattern ();
  }
  psearch_history_free ();
}


int psearch_data_is_empty (void) {
  return (psearch.data == NULL);
}


char *psearch_lookup_pattern (void) {
  char *pat;
  int len;

  if (!psearch.pattern || !psearch.pattern[0])
    return NULL;

  len = strlen (psearch.pattern) + 2 + strlen (mode_names[psearch.mode]) + 2;
  pat = g_malloc (len);

  g_snprintf (pat, len, "%s (%s)", psearch.pattern, mode_names[psearch.mode]);

  return pat;
}


int psearch_next_player (int *server, int *player) {
  struct server *s;
  GSList *servers = cur_list;
  int n;

  if (*server > 0) {
    n = *server;

    while (n > 0) {
      if (!servers)
	return FALSE;

      servers = servers->next;
      n--;
    }
  }

  if (*server < 0) *server = 0;
  if (*player < 0) *player = 0;

  while (servers) {
    s = (struct server *) servers->data;

    if (s->curplayers > 1)
      qsort (s->players, s->curplayers, sizeof (gpointer), qsort_players);

    while (*player < s->curplayers) {
      if (psearch_test_player (s->players[*player]))
	return TRUE;
      (*player)++;
    }

    servers = servers->next;
    (*server)++;
    *player = 0;
  }

  return FALSE;
}

