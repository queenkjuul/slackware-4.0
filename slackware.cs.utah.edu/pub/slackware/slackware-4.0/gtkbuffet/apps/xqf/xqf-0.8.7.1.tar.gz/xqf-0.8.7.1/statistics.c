/* XQF - Quake server browser and launcher
 * Copyright (C) 1998 Roman Pozlevich <roma@botik.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <sys/types.h>
#include <string.h>	/* strspn, strcspn, strncasecmp, memset */

#include <gtk/gtk.h>

#include "xqf.h"
#include "game.h"
#include "server.h"
#include "dns.h"
#include "source.h"
#include "dialogs.h"
#include "statistics.h"


#define PERCENTS(A,B)	((B)? (A)/((B)/100.0) : 0)


struct server_stats {
  int	players;
  int 	servers;

  int 	ok;
  int 	down;
  int	timeout;
  int	na;
};

#define	OS_NUM		4
#define CPU_NUM		4

enum OS { OS_WINDOWS = 0, OS_LINUX, OS_SOLARIS, OS_UNKNOWN };
enum CPU { CPU_X86 = 0, CPU_SPARC, CPU_AXP, CPU_UNKNOWN };


static int games_total;

static struct server_stats *srv_stats;

static int *srv_arch;

static int servers_count;
static int players_count;
static int arch_count;


static const char *srv_headers[6] = {
  "Servers", "Up", "T/O", "Down", "Info n/a", "Players"
};

static const char *os_names[OS_NUM] = {
  "Windows", "Linux", "Solaris", "?????"
};

static const char *cpu_names[CPU_NUM] = {
  "Intel x86", "Sparc", "AXP", "?????"
};


static void server_stats_create (void) {

  games_total = 0;

  while (games[games_total].type != UNKNOWN_SERVER)
    games_total++;

  srv_stats = g_malloc0 (sizeof (struct server_stats) * games_total);
  srv_arch = g_malloc0 (sizeof (int) * OS_NUM * CPU_NUM);

  servers_count = 0;
  players_count = 0;
  arch_count = 0;
}


static void server_stats_destroy (void) {
  if (srv_stats) {
    g_free (srv_stats);
    srv_stats = NULL;
  }
  if (srv_arch) {
    g_free (srv_arch);
    srv_arch = NULL;
  }
}

#define	MAX_TOKENS	32
#define	DELIMITERS	" \t\n\r"

static int safe_tokenize (char *str, char *token[]) {
  int num = 0;

  while (str && num < MAX_TOKENS) {
    str += strspn (str, DELIMITERS);

    if (*str == '\0')
      break;

    token[num++] = str;
    str += strcspn (str, DELIMITERS);
  }

  return num;
}


static void collect_statistics (void) {
  GSList *servers;
  GSList *tmp;
  struct server *s;
  char **info;
  char *token[MAX_TOKENS];
  int n;
  enum OS os;
  enum CPU cpu;

  servers = all_servers ();

  if (servers) {
    for (tmp = servers; tmp; tmp = tmp->next) {
      s = (struct server *) tmp->data;
      info = s->info;

      servers_count++;

      srv_stats[s->type].servers++;
      srv_stats[s->type].players += s->curplayers;

      players_count += s->curplayers;

      if (s->ping < MAX_PING) {
	if (s->ping >= 0)
	  srv_stats[s->type].ok++;
	else
	  srv_stats[s->type].na++;
      }
      else {
	if (s->ping == MAX_PING)
	  srv_stats[s->type].timeout++;
	else
	  srv_stats[s->type].down++;
      }

      if (info && s->type == Q2_SERVER) {
	while (info[0]) {
	  if (g_strcasecmp (info[0], "version") == 0) {
	    if (!info[1])
	      break;

	    os  = OS_UNKNOWN;
	    cpu = CPU_UNKNOWN;

	    n = safe_tokenize (info[1], token);
	    if (n >= 2) {
	      if (strncasecmp (token[1], "x86", 3) == 0 ||
                                       strncasecmp (token[1], "i386", 4) == 0)
		cpu = CPU_X86;
	      else if (strncasecmp (token[1], "sparc", 5) == 0)
		cpu = CPU_SPARC;
	      else if (strncasecmp (token[1], "axp", 3) == 0)
		cpu = CPU_AXP;
#ifdef DEBUG
	      else {
		fprintf (stderr, "[%s:%d] Unknown CPU: %s\n", 
                                          s->host->address, s->port, info[1]);
	      }
#endif
	    }

	    if (n >= 6) {
	      if (strncasecmp (token[5], "win", 3) == 0)
		os = OS_WINDOWS;
	      else if (strncasecmp (token[5], "linux", 5) == 0)
		os = OS_LINUX;
	      else if (strncasecmp (token[5], "solaris", 7) == 0)
		os = OS_SOLARIS;
#ifdef DEBUG
	      else {
		fprintf (stderr, "[%s:%d] Unknown OS: %s\n", 
                                          s->host->address, s->port, info[1]);
	      }
#endif
	    }

	    srv_arch[os * CPU_NUM + cpu]++;
	    arch_count++;

	    break;
	  }
	  info += 2;
	}
      }
    }

    free_servers (servers);
  }
}


static void put_label_to_table (GtkWidget *table, const char *str, 
                                            float justify, int col, int row) {
  GtkWidget *label;

  if (str) {
    label = gtk_label_new (str);
    gtk_misc_set_alignment (GTK_MISC (label), justify, 0.5);
    gtk_table_attach_defaults (GTK_TABLE (table), label, 
                                                  col, col + 1, row, row + 1);
    gtk_widget_show (label);
  }
}


static void put_server_stats (GtkWidget *table, int num, int row) {
  char buf1[16], buf2[16], buf3[16], buf4[16], buf5[16], buf6[16];
  const char *strings[6];
  int i;

  strings[0] = buf1;
  strings[1] = buf2;
  strings[2] = buf3;
  strings[3] = buf4;
  strings[4] = buf5;
  strings[5] = buf6;

  g_snprintf (buf1, 16, "%d (%.2f%%)", srv_stats[num].servers, 
                            PERCENTS (srv_stats[num].servers, servers_count));

  g_snprintf (buf2, 16, "%d (%.2f%%)", srv_stats[num].ok,
                        PERCENTS (srv_stats[num].ok, srv_stats[num].servers));

  g_snprintf (buf3, 16, "%d (%.2f%%)", srv_stats[num].timeout,
                   PERCENTS (srv_stats[num].timeout, srv_stats[num].servers));

  g_snprintf (buf4, 16, "%d (%.2f%%)", srv_stats[num].down,
                      PERCENTS (srv_stats[num].down, srv_stats[num].servers));

  g_snprintf (buf5, 16, "%d (%.2f%%)", srv_stats[num].na,
                        PERCENTS (srv_stats[num].na, srv_stats[num].servers));

  g_snprintf (buf6, 16, "%d (%.2f%%)", srv_stats[num].players,
                            PERCENTS (srv_stats[num].players, players_count));

  for (i = 0; i < 6; i++)
    put_label_to_table (table, strings[i], 1.0, i + 1, row);
}


static GtkWidget *server_stats_page (void) {
  GtkWidget *page_vbox;
  GtkWidget *alignment;
  GtkWidget *frame;
  GtkWidget *hbox;
  GtkWidget *table;
  GtkWidget *label;
  GtkWidget *pixmap;
  int i;

  page_vbox = gtk_vbox_new (FALSE, 4);
  gtk_container_border_width (GTK_CONTAINER (page_vbox), 8);

  alignment = gtk_alignment_new (0.5, 0.5, 0.0, 0.0);
  gtk_box_pack_start (GTK_BOX (page_vbox), alignment, TRUE, TRUE, 0);

  frame = gtk_frame_new (NULL);
  gtk_container_add (GTK_CONTAINER (alignment), frame);

  table = gtk_table_new (games_total + 2, 7, FALSE);
  gtk_container_border_width (GTK_CONTAINER (table), 6);
  gtk_container_add (GTK_CONTAINER (frame), table);

  gtk_table_set_row_spacings (GTK_TABLE (table), 4);
  gtk_table_set_col_spacings (GTK_TABLE (table), 8);

  gtk_table_set_col_spacing (GTK_TABLE (table), 0, 20);
  gtk_table_set_col_spacing (GTK_TABLE (table), 1, 20);
  gtk_table_set_col_spacing (GTK_TABLE (table), 5, 20);
  gtk_table_set_row_spacing (GTK_TABLE (table), 0, 12);
  gtk_table_set_row_spacing (GTK_TABLE (table), games_total, 12);

  for (i = 0; i < 6; i++)
    put_label_to_table (table, srv_headers[i], 1.0, i + 1, 0);

  for (i = 0; i < games_total; i++) {
    if (i < games_total) {
      hbox = gtk_hbox_new (FALSE, 4);
      gtk_table_attach_defaults (GTK_TABLE (table), hbox, 0, 1, i + 1, i + 2);

      pixmap = gtk_pixmap_new (games[i].pix->pix, games[i].pix->mask);
      gtk_box_pack_start (GTK_BOX (hbox), pixmap, FALSE, FALSE, 0);
      gtk_widget_show (pixmap);

      label = gtk_label_new (games[i].name);
      gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, FALSE, 0);
      gtk_widget_show (label);

      gtk_widget_show (hbox);
    }

    put_server_stats (table, i, i + 1);

    if (i > 0) {
      srv_stats[0].servers += srv_stats[i].servers;
      srv_stats[0].ok      += srv_stats[i].ok;
      srv_stats[0].timeout += srv_stats[i].timeout;
      srv_stats[0].down    += srv_stats[i].down;
      srv_stats[0].na      += srv_stats[i].na;
      srv_stats[0].players += srv_stats[i].players;
    }
  }

  put_label_to_table (table, "Total", 0.0, 0, games_total + 1);

  put_server_stats (table, 0, games_total + 1);

  gtk_widget_show (table);
  gtk_widget_show (frame);

  gtk_widget_show (alignment);
  gtk_widget_show (page_vbox);

  return page_vbox;
}


static void put_arch_stats (GtkWidget *table, int val, int row, int col) {
  char buf[16];

  g_snprintf (buf, 16, "%d (%.2f%%)", val, PERCENTS (val, arch_count));
  put_label_to_table (table, buf, 1.0, row, col);
}


static GtkWidget *archs_stats_page (void) {
  GtkWidget *page_vbox;
  GtkWidget *alignment;
  GtkWidget *frame;
  GtkWidget *table;
  int i, j;
  int cpu_total;
  char buf[32];

  page_vbox = gtk_vbox_new (FALSE, 4);
  gtk_container_border_width (GTK_CONTAINER (page_vbox), 8);

  alignment = gtk_alignment_new (0.5, 0.5, 0.0, 0.0);
  gtk_box_pack_start (GTK_BOX (page_vbox), alignment, TRUE, TRUE, 0);

  g_snprintf (buf, 32, "%s servers only", games[Q2_SERVER].name);

  frame = gtk_frame_new (buf);
  gtk_container_add (GTK_CONTAINER (alignment), frame);

  table = gtk_table_new (OS_NUM + 2, CPU_NUM + 2, FALSE);
  gtk_container_border_width (GTK_CONTAINER (table), 6);
  gtk_container_add (GTK_CONTAINER (frame), table);
  gtk_table_set_row_spacings (GTK_TABLE (table), 4);
  gtk_table_set_col_spacings (GTK_TABLE (table), 8);

  gtk_table_set_col_spacing (GTK_TABLE (table), 0, 20);
  gtk_table_set_row_spacing (GTK_TABLE (table), 0, 12);
  gtk_table_set_col_spacing (GTK_TABLE (table), OS_NUM, 20);
  gtk_table_set_row_spacing (GTK_TABLE (table), CPU_NUM, 12);

  put_label_to_table (table, "CPU  \\  OS", 0.5, 0, 0);

  for (i = 0; i < OS_NUM; i++) {
    put_label_to_table (table, os_names[i], 1.0, i + 1, 0);
  }
  put_label_to_table (table, "Total", 1.0, OS_NUM + 1, 0);

  for (i = 0; i < CPU_NUM; i++) {
    put_label_to_table (table, cpu_names[i], 0.0, 0, i + 1);
  }
  put_label_to_table (table, "Total", 0.0, 0, CPU_NUM + 1);

  for (j = 0; j < CPU_NUM; j++) {
    cpu_total = 0;
    for (i = 0; i < OS_NUM; i++) {
      put_arch_stats (table, srv_arch[i * CPU_NUM + j], i + 1, j + 1);

      cpu_total += srv_arch[i * CPU_NUM + j];

      if (j > 0)
	srv_arch[i * CPU_NUM + 0] += srv_arch[i * CPU_NUM + j];
    }
    put_arch_stats (table, cpu_total, OS_NUM + 1, j + 1);
  }

  for (i = 0; i < OS_NUM; i++) {
    put_arch_stats (table, srv_arch[i * CPU_NUM + 0], i + 1, CPU_NUM + 1);
  }
  put_arch_stats (table, arch_count, OS_NUM + 1, CPU_NUM + 1);

  gtk_widget_show (table);
  gtk_widget_show (frame);

  gtk_widget_show (alignment);
  gtk_widget_show (page_vbox);

  return page_vbox;
}


void statistics_dialog (void) {
  GtkWidget *window;
  GtkWidget *main_vbox;
  GtkWidget *notebook;
  GtkWidget *page;
  GtkWidget *hbox;
  GtkWidget *label;
  GtkWidget *button;

  server_stats_create ();
  collect_statistics ();

  window = dialog_create_modal_transient_window ("Statistics", TRUE, FALSE);

  main_vbox = gtk_vbox_new (FALSE, 8);
  gtk_container_border_width (GTK_CONTAINER (main_vbox), 8);
  gtk_container_add (GTK_CONTAINER (window), main_vbox);

  label = gtk_label_new ("Statistics");
  gtk_box_pack_start (GTK_BOX (main_vbox), label, FALSE, FALSE, 8);
  gtk_widget_show (label);

  notebook = gtk_notebook_new ();
  gtk_notebook_set_tab_pos (GTK_NOTEBOOK (notebook), GTK_POS_TOP);
  gtk_box_pack_start (GTK_BOX (main_vbox), notebook, FALSE, FALSE, 0);

  page = server_stats_page ();
  label = gtk_label_new (" Servers ");
  gtk_widget_show (label);
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), page, label);

  page = archs_stats_page ();
  label = gtk_label_new (" OS/CPU ");
  gtk_widget_show (label);
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), page, label);

  gtk_notebook_set_page (GTK_NOTEBOOK (notebook), 0);

  gtk_widget_show (notebook);

  /* Close Button */

  hbox = gtk_hbox_new (FALSE, 8);
  gtk_box_pack_start (GTK_BOX (main_vbox), hbox, FALSE, FALSE, 0);

  button = gtk_button_new_with_label ("Close");
  gtk_box_pack_end (GTK_BOX (hbox), button, FALSE, FALSE, 0);
  gtk_widget_set_usize (button, 80, -1);
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (window));
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_widget_grab_default (button);
  gtk_widget_show (button);

  gtk_widget_show (hbox);

  gtk_widget_show (main_vbox);

  gtk_widget_show (window);

  gtk_main ();

  unregister_window (window);

  server_stats_destroy ();
}

