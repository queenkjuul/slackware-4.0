
gchar *label_title_txt = "Title";
gchar *label_artist_txt = "Artist";
gchar *label_album_txt = "Album";
gchar *label_year_txt = "Year";
gchar *label_junle_txt = "Genre";
gchar *label_comment_txt = "Comment";

gchar *window_main_title_txt = "gmp3te";

gchar *button_save_txt = "SAVE";
gchar *button_quit_txt = "Close";

gchar *status_load_txt = "Load success";
gchar *status_loadfail_txt = "Load failed";
gchar *status_save_txt = "Save success";
gchar *status_savefail_txt = "Save failed";
gchar *status_notloaded_txt = "File is not loaded";
gchar *status_context_txt = "Stat";
gchar *status_loadenpty_txt = "Can't find ID3 header";

gchar *status_entry_er = "Entry is too long";

char *usage="\ngmp3te [file.mp3]\n";

gchar *No_Junle = "No Genre";

