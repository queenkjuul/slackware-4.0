
struct _MP3_TAG
{
  char Title[31];
  char Artist[31];
  char Album[31];
  char Year[5];
  char Comment[31];
  unsigned char Junle;
};

typedef struct _MP3_TAG MP3_TAG;

int read_tag ( char *file_name, MP3_TAG *tag );
void sp_cut(char *buff, int l);
void sp_cpy(char *dist, char *buff, int max );
void f_safe_write ( char *buf, int len, FILE *fp );
int Write_ID3 ( char *filename, MP3_TAG *id3_tag );

