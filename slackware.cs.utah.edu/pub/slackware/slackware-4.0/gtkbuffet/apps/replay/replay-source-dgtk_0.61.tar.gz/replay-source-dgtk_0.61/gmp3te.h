GtkWidget *init_junle_menu(void);
void save_mp3(void);
void quit_func(void);

void change_junle (void);

void set_mp3_to_entry(char *filename);
GtkWidget *init_tewin(void);
