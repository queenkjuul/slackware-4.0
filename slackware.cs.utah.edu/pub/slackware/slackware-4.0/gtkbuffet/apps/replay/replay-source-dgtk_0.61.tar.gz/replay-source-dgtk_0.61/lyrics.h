typedef struct _Lyrics LYRICS;

struct _Lyrics
{
  long time;
  char word[255];
  LYRICS *next;
  LYRICS *prev;
};

int fscanline ( FILE *fp );
void clr_lyrics ( LYRICS *lyrics );

int fgetline(char *BUFF, FILE *fp, int line);
LYRICS *ly_getwrdtxt(char *filename);
void update_lyrics ( long time );

