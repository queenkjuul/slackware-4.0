char *sj_to_euc(char *from);
char *euc_to_sj(char *from);
