/* text_style_pallet.m

   Copyright (C) 1998, 1999 Free Software Foundation, Inc.

   Written by:  Masatake YAMATO <masata-y@is.aist-nara.ac.jp>
   
   This file is part of the GNU Yellow Vector Editor

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
   
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 
#include "TextStylePallet.h"
#include "text_style_pallet.h"
#include "GyveGUI.h"
#include "GyveBuffer.h"
#include "GyveWindow.h"
#include "Gyve.h"

#include <gtkDPS/gtkDPSfontpanel.h>

static void text_style_pallet_ok_handler (GtkWidget * widget, GtkDPSFontpanelCore *core);
static void text_style_pallet_font_change_handler (GtkWidget * widget, gpointer data);

GtkWidget *
text_style_pallet_new(TextStylePallet * pallet)
{
	GtkWidget * window;
	GtkWidget * font_panel;
	GtkWidget * font_panel_core;

	/* window */
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window), "Text Style");
	gtk_window_set_policy (GTK_WINDOW (window), TRUE, TRUE, FALSE);
	gtk_container_border_width (GTK_CONTAINER (window), 10);
	gtk_signal_connect(GTK_OBJECT(window), "destroy",
					   GTK_SIGNAL_FUNC(gtk_widget_destroy), NULL);
	gtk_signal_connect(GTK_OBJECT(window), "delete_event",
					   GTK_SIGNAL_FUNC(gtk_widget_hide), NULL);
	gtk_signal_connect(GTK_OBJECT(window), "enter_notify_event",
					   GTK_SIGNAL_FUNC(gui_enter_interactive_mode), NULL);
				
	/* fontpanel widget 
	font_panel = gtk_dps_fontpanel_new("Text Style");
	gtk_container_add (GTK_CONTAINER (window), font_panel);
	*/
	/* core */
	font_panel_core = gtk_dps_fontpanel_core_new();
	gtk_container_add (GTK_CONTAINER (window), font_panel_core);
	gtk_widget_show (font_panel_core);

	/*
	gtk_signal_connect(GTK_OBJECT (GTK_DPS_FONTPANEL (font_panel)->close_button),
					   "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy),NULL);
	gtk_signal_connect(GTK_OBJECT (GTK_DPS_FONTPANEL (font_panel)->ok_button),
					   "clicked", GTK_SIGNAL_FUNC(text_style_pallet_ok_handler), 
					   font_panel_core);
					   */
	gtk_signal_connect(GTK_OBJECT(font_panel_core),
					   "font_changed",
					   GTK_SIGNAL_FUNC (text_style_pallet_font_change_handler), 
					   font_panel_core);
	return window;
}

static void
text_style_pallet_ok_handler (GtkWidget * widget, GtkDPSFontpanelCore *core)
{
	NSPoint p 	    = {100.0, 100.0};
	GyveBuffer * document_buffer = [GyveBuffer currentBuffer];
	GyveWindow * document_window = [GyveWindow currentWindow];
	//GtkDPSFontpanelCore *core = data;
	PSTextAtPoint * t;
	
	char *fontname = (char *)gtk_dps_fontpanel_core_get_fontname(core);
  //char *input = (char *) gtk_dps_fontpanel_core_get_input(GTK_DPS_FONTPANEL_CORE(fp));
	int size = gtk_dps_fontpanel_core_get_fontsize(core);
  
	if (fontname == NULL) {
		fprintf(stderr, "No font name\n");
		return ;
	}
	
	[[TextStylePallet textStylePallet]
		setFontName: [NSString stringWithCString: fontname]];
	[[TextStylePallet textStylePallet]
		setFontSize: size];
	/* 
	   t = [[[PSTextAtPoint alloc]
	   initWithString: [NSString stringWithCString: input]
	   point: &p] autorelease];
	   [document_window redrawLockRetain];
	   [document_window redrawBBox: [document_buffer selectionsLayer] expandBy: 1.0];
	   [document_buffer unSelectAll];
	   [document_buffer putFigObj: t];
	   [document_window redrawFigObj: t];  
	   [document_window redrawLockRelease]; */
}

static void
text_style_pallet_font_change_handler (GtkWidget * widget, gpointer data)
{
	GtkDPSFontpanelCore *core = data;
	char *fontname = (char *) gtk_dps_fontpanel_core_get_fontname(core);
	int size = gtk_dps_fontpanel_core_get_fontsize(core);

	[[TextStylePallet textStylePallet]
		setFontName: [NSString stringWithCString: fontname]];
	[[TextStylePallet textStylePallet]
	  setFontSize: size];
}







