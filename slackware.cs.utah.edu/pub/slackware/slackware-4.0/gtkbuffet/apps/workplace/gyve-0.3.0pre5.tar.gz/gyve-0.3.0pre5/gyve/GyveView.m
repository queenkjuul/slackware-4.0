/* GyveView.m --- The definition for gyve view

   Copyright (C) 1998,1999 Free Software Foundation, Inc.

   Written by:  Masatake YAMATO <masata-y@is.aist-nara.ac.jp>
   
   This file is part of the GNU Yellow Vector Editor

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
   
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 

#include "GyveView.h"
#include "GyveDrawingEngine.h"
#include "geometry.h"
#include "PSPath.h"
#include "PSPaintStyle.h"
#include "init.h"

#include <math.h>
#include <Foundation/NSGeometry.h>
#include <Foundation/NSException.h>
#include <DPS/dpsops.h>
#include <DPS/psops.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>
#include <gdk/gdktypes.h>
#include <gtkDPS/gtkDPS.h>
#include <gtkDPS/gtkDPSarea.h>

static void expose_handler(GtkWidget *, GdkEventExpose *, gpointer);
static void realize_handler(GtkWidget *, gpointer);
static void size_allocate_handler(GtkWidget *, GtkAllocation *, gpointer);

/*
 * Coord translation related functions
 */ 
#include "coord_tr.h"	// generated from coord_tr.psw
#define DGS_BUGGY 1

void
coord_tr_get(struct coord_tr * tr, DPSContext ctxt)
{
  psw_get_transform(ctxt, tr->ctm, tr->invctm,
		    &(tr->x_offset), &(tr->y_offset));
}

void
coord_tr_copy(struct coord_tr * src, struct coord_tr * dist)
{
  int matrix_elt_index;

  dist->updated = src->updated;
  for (matrix_elt_index = 0; matrix_elt_index < 6; matrix_elt_index++)
    {
      dist->ctm[matrix_elt_index] = src->ctm[matrix_elt_index];
      dist->invctm[matrix_elt_index] = src->invctm[matrix_elt_index];
    }
  dist->x_offset = src->x_offset;
  dist->y_offset = src->y_offset;
}

void
coord_tr_x2dps(struct coord_tr * tr,
	    int in_x, int in_y, float * out_x, float * out_y)
{
  in_x -= tr->x_offset;
  in_y -= tr->y_offset;

  *out_x =
    tr->invctm[MATRIX_A] * (float)in_x +
    tr->invctm[MATRIX_C] * (float)in_y +
#ifdef DGS_BUGGY
    0.0;
#else 
    tr->invctm[MATRIX_TX];
#endif /* Def: DGS_BUGGY */

  *out_y =
    tr->invctm[MATRIX_B] * (float)in_x +
    tr->invctm[MATRIX_D] * (float)in_y +
#ifdef DGS_BUGGY
    0.0;
#else 
    tr->invctm[MATRIX_TY];
#endif  /* DGS_BUGGY */
}

void
coord_tr_dps2x(struct coord_tr * tr, 
	       float in_x, float in_y, 
	       int * out_x, int * out_y)
{
  *out_x =
    tr->ctm[MATRIX_A] * in_x +
    tr->ctm[MATRIX_C] * in_y +
#ifdef DGS_BUGGY
    0.0 +
#else 
    tr->ctm[MATRIX_TX] + 
#endif  /* DGS_BUGGY */
    tr->x_offset;
  *out_x = (*out_x < 0)? floor(*out_x): *out_x;	// 0?

  *out_y =
    tr->ctm[MATRIX_B] * in_x +
    tr->ctm[MATRIX_D] * in_y +
#ifdef DGS_BUGGY
    0.0 +
#else 
    tr->ctm[MATRIX_TY] + 
#endif /* Def: DGS_BUGGY */
    tr->y_offset;
  *out_y = (*out_y < 0)? floor(*out_y): *out_y;	// 0?
}

void
coord_tr_dpsRect2xRect(struct coord_tr * tr, 
		       NSRect * in_dps_rect, 
		       NSRect * out_x_rect)
{
  /*      
    a_dps     a_x 
     *---+      *---+
     |DPS|  =>  | X |  
     +---*      +---*
        b_dps     b_x */    
  NSPoint a_dps, b_dps;
  NSPoint a_x_float, b_x_float;
  int a_x[2], b_x[2];
  int x = 0;
  int y = 1;

  if ((tr == NULL) || (in_dps_rect == NULL) ||  (out_x_rect == NULL))
    {
      fprintf(stderr, "Wrong args (coord_tr_dpsRect2xRect)\n");
      return ;
    }
  a_dps.x = in_dps_rect->origin.x;
  a_dps.y = in_dps_rect->origin.y + in_dps_rect->size.height;

  b_dps.x = in_dps_rect->origin.x + in_dps_rect->size.width;
  b_dps.y = in_dps_rect->origin.y;

  coord_tr_dps2x(tr, a_dps.x, a_dps.y, &(a_x[x]), &(a_x[y]));
  coord_tr_dps2x(tr, b_dps.x, b_dps.y, &(b_x[x]), &(b_x[y]));
  
  a_x_float.x = a_x[x];
  a_x_float.y = a_x[y];
  b_x_float.x = b_x[x];
  b_x_float.y = b_x[y];
  
  NSRect_from_points(out_x_rect, &a_x_float, &b_x_float);
}

/*
 * GyveView
 */

NSString * GyveViewWrongGdkEventToTranslate = @"GyveViewWrongGdkEventToTranslate";

@implementation GyveView
// �����
- initWithViewWidth: (int)w_x height: (int)h_x
{
	[super init];
	document_size_x.width = w_x;
	document_size_x.height = h_x;

	widget = (GtkWidget * )gtk_dps_area_new();
	gtk_widget_set_usize(widget, w_x, h_x);
	gtk_widget_set_events(GTK_WIDGET(widget),GDK_EXPOSURE_MASK);
	gtk_signal_connect(GTK_OBJECT(widget), "expose_event",
					   GTK_SIGNAL_FUNC (expose_handler), self);
	gtk_signal_connect(GTK_OBJECT(widget), "size_allocate",
					   GTK_SIGNAL_FUNC (size_allocate_handler), self);
	gtk_signal_connect(GTK_OBJECT(widget), "realize",
					   GTK_SIGNAL_FUNC (realize_handler), self);
	drawing_engine     = nil;
	coord_tr.updated = NO;
	total_redraw_rect = NSZeroRect;
	redraw_lock_depth = 0;
	receiving_expose_events_sequence = NO;

	return self ;
}
// drawing_engine �ν������
- setDrawingEngine: (NSObject<GyveDrawingEngine>*)e
{
	float scale = 1.0;

	if (e && (e != drawing_engine)) {
		if (drawing_engine)	{
			scale = [self absoluteScale];
			[drawing_engine release];
			drawing_engine = nil;
		}
		drawing_engine = [e retain];
    }
	return self ;
}
- (void)dealloc
{
	if (drawing_engine) {
		[drawing_engine release];
		drawing_engine = nil;
	}
	gtk_widget_unref(GTK_WIDGET(widget));
	[super dealloc];
}
// ������򥭥�å���ˤ���
- (void)dpsAreaBegin
{
	/* TODO: recursive entries��ػߤ��뤳��. <- (?_?) */
	if (GTK_WIDGET_REALIZED(widget)) {
		gtk_dps_area_begin(GTK_DPS_AREA (widget));
    }
}
// ������򸵤ˤ�ɤ�
- (void)dpsAreaEnd
{
}
- (void)setAbsoluteScale: (float)scale
{
	NSSize size 	  = [self documentSizeInX];
	float old_scale   = [self absoluteScale];

	size.width /= old_scale;
	size.height /= old_scale;
	gtk_widget_set_usize(widget, size.width * scale + (40 * scale),
						 size.height * scale + (40 * scale));
 
	if (drawing_engine) {
        [drawing_engine setAbsoluteScale: scale];
	}
	coord_tr.updated = NO;
	[self updateCoordTr];
}
- (float)absoluteScale
{
    return [drawing_engine absoluteScale];
}
- (NSObject<GyveDrawingEngine>*)drawingEngine
{
    return drawing_engine;
}
- (void)drawSelf: (NSRect *)rect
{
	// cache �����Ƥ�screen�˥��ԡ�����
	gtk_dps_area_map_area_on_screen(GTK_DPS_AREA(widget));
}
- (void)drawCache: (NSRect *)rect
{
	// cache �����Ƥ�screen�˥��ԡ�����
	gtk_dps_area_map_cache_on_screen(GTK_DPS_AREA(widget));
}

// cache �����޷�����������
- (void)updateCache
{
	// dps area �β�����backup cache �˥��ԡ�����
	if (nil == drawing_engine) {
		return;
	}
	if (NO == coord_tr.updated) {
		[self updateCoordTr];
	}
	gtk_dps_area_map_area_on_cache(GTK_DPS_AREA(widget));
}

- (void)loadCache
{
	// backup cache ���顢dps area �˥��ԡ�����
	if (nil == drawing_engine) {
		return;
	}
	if (NO == coord_tr.updated) {
		[self updateCoordTr];
	}
	printf("-------- loadCache ----------\n");
	gtk_dps_area_map_cache_on_area(GTK_DPS_AREA(widget));
}
- (void)redrawAll
{
	[drawing_engine redrawAll : GTK_DPS_AREA(widget)];
}
- (void)redrawRect: (NSRect *)rect
{
	GC       x_gc;
	Display  *x_display;
	Window   x_window;
	int      width, height;
	int      x_x, x_y;
	NSRect   x_rect;

	if (!drawing_engine) {
		return ;
    }

	if (redraw_lock_depth == 0) {
		/* total_redraw_rect ������ 
		x_display = GDK_WINDOW_XDISPLAY(widget->window);
        x_gc = GDK_GC_XGC(GTK_DPS_AREA(widget)->gdk_dps_context->gc);
        x_window = GDK_WINDOW_XWINDOW(widget->window);
		*/
		
		if (rect) {
			/* ���Τ򥳥ԡ����Ƥ⡢®�٤ϡ��ۤȤ�ɡ��Ѥ��ʤ�
			  
			x_rect = [self translateRectFromDPSToX: rect];
			XCopyArea(x_display,GTK_DPS_AREA(widget)->cache,x_window,x_gc,
					  (int)floor(x_rect.origin.x),
					  (int)floor(x_rect.origin.y),
					  (int)floor(x_rect.size.width),
					  (int)floor(x_rect.size.height),
					  (int)floor(x_rect.origin.x),
					  (int)floor(x_rect.origin.y));
			*/
			[self drawSelf:NULL];//gtk_dps_area_cache_map(GTK_DPS_AREA(widget));
		}
		else {
			[self drawSelf:NULL];//gtk_dps_area_cache_map(GTK_DPS_AREA(widget));
		}
	}
}
- (void)redrawRect: (const NSRect *)rect expandBy: (float)delta
{
	if (YES == NSRect_is_zero_rect(rect)){
		return;
	}
	if (delta == 0.0) { 
		[self redrawRect: rect];
	}
	else {
		NSRect expanded_rect;
		NSRect_copy(rect, &expanded_rect);
		NSRect_expand_by_delta (&expanded_rect, delta);
		[self redrawRect: &expanded_rect];
    }
}
- (void)redrawBBox: (id<PSBBox>)bbox
{
	NSRect rect;

	bbox_to_rect([bbox bboxCStructure], &rect);
	if (YES == NSRect_is_zero_rect(&rect)) {
		return;
	}  
	[self redrawRect: &rect];
}
- (void)redrawBBox: (id<PSBBox>)bbox  expandBy: (float)delta
{
	NSRect rect;

	bbox_to_rect([bbox bboxCStructure], &rect);

	if (YES == NSRect_is_zero_rect(&rect)) {
		return;
	}    
	if (delta == 0.0) { 
	}
	else {
		NSRect expanded_rect;
	
		NSRect_copy(&rect, &expanded_rect);
		NSRect_expand_by_delta (&expanded_rect, delta);
		[self redrawRect: &expanded_rect];
    }
}
- (void)redrawBBoxCStructure: (struct bbox *)bbox 
{
	NSRect rect;
	return;
	bbox_to_rect(bbox, &rect);
	if (YES == NSRect_is_zero_rect(&rect)) {
		return;
	}
	//[drawing_engine redrawRect: &rect];
	//[self redrawRect: &rect];
}
- (void)redrawBBoxCStructure: (struct bbox *)bbox expandBy: (float)delta
{
	NSRect rect;
	return;
	bbox_to_rect(bbox, &rect);
	if (YES == NSRect_is_zero_rect(&rect)){
		return;
	} 
	if (delta == 0.0) { 
		//[drawing_engine redrawRect: &rect];
	}
	else {
		NSRect expanded_rect;
	
		NSRect_copy(&rect, &expanded_rect);
		NSRect_expand_by_delta (&expanded_rect, delta);
		//[drawing_engine redrawRect: &expanded_rect];
    }
}
- (void)drawCurrent
{
	[drawing_engine drawCurrentLayer: GTK_DPS_AREA(widget)];
}
// �����Ȥο޷�����
- (void)redrawFigObj: (id<PSFigObj>)figobj
{
	printf("$$$$$$$$$$$$$ SUCK $$$$$$$$$$$$$$$$$$$");
	gdk_beep();
	[drawing_engine drawFig: figobj];
	return;

	if (bbox_is_zero_bbox([figobj bboxCStructure])) {
		/* bbox��zero�ξ��, 
		   figobj��bbox���׻��Ǥ��Ƥʤ�, �������޷��Ǥ��뤳�Ȥ��̣���Ƥ���. */
		// calc bbox
		if (YES == [self calcBBoxOfFigObj: figobj]) {
			[self redrawFigObj: figobj];
		}
		else {
			return;
		}
	}
	else if ([drawing_engine drawingMode] == PREVIEW_MODE) {
		float delta = 0.0;
		delta = [figobj deltaForExpandingBBox];
		[drawing_engine drawCurrentLayer:  GTK_DPS_AREA(widget)];
		//[drawing_engine drawFig: figobj];
		//gtk_dps_area_cache_begin(GTK_DPS_AREA(widget));
		{
			PSsetrgbcolor(0,0,0);
			drawing_engine_send_path ((PSPath *)figobj, YES);
			PSstroke();
			//[drawing_engine drawFig: figobj];[self redrawBBox: figobj expandBy: delta];
		}
		//gtk_dps_area_cache_end(GTK_DPS_AREA(widget));
		//[drawing_engine drawCurrentLayer:  GTK_DPS_AREA(widget)];
	}
	else {
		//[drawing_engine drawFig: figobj];
		[drawing_engine drawCurrentLayer:  GTK_DPS_AREA(widget)];
	
		//gtk_dps_area_cache_begin(GTK_DPS_AREA(widget));
		{
			PSsetrgbcolor(0,0,0);
			drawing_engine_send_path ((PSPath *)figobj, YES);
			PSstroke();
			//[drawing_engine drawFig: figobj];[self redrawBBox: figobj expandBy: 2.0];
		}
		//gtk_dps_area_cache_end(GTK_DPS_AREA(widget));
		//[drawing_engine drawCurrentLayer:  GTK_DPS_AREA(widget)];
	}
}
- redrawLockRetain
{
	redraw_lock_depth++;
	return self ;
}
- (void)redrawLockRelease
{
	redraw_lock_depth--;

}
- (int)redrawLockCount
{
	return redraw_lock_depth;
}
- (NSPoint)translatePointFromXToDPS: (NSPoint *)xpoint
{
	NSPoint dps_point;

	int x_x = (int)(xpoint->x), y_x = (int)(xpoint->y);
  
	coord_tr_x2dps(&coord_tr, x_x, y_x,
				   &(dps_point.x), &(dps_point.y));
  
	return dps_point;
}
- (NSPoint)translatePointFromDPSToX: (NSPoint *)dps_point
{
	NSPoint x_point;
	int     x_x, y_x;

	float x_dps = (dps_point->x), y_dps = (dps_point->y);
  
	coord_tr_dps2x(&coord_tr, x_dps, y_dps,
				   &x_x, &y_x);
  
	x_point.x = x_x;
	x_point.y = y_x;

	return x_point;
}
- (NSPoint)translatePointFromGdkEventToDPS: (GdkEvent *)event
{
	NSPoint xpoint;

	switch(event->type) {
    case GDK_MOTION_NOTIFY:
		xpoint.x = event->motion.x ;
		xpoint.y = event->motion.y ;
		break;
    case GDK_BUTTON_PRESS:
    case GDK_2BUTTON_PRESS:
    case GDK_3BUTTON_PRESS:
    case GDK_BUTTON_RELEASE:
		xpoint.x = event->button.x ;
		xpoint.y = event->button.y ;
		break;
    default:
		[NSException raise: GyveViewWrongGdkEventToTranslate
					 format: @"Wrong type of gdkEvent: %d", event->type];
    }
	return [self translatePointFromXToDPS: &xpoint];
}
- (NSRect)translateRectFromXToDPS: (NSRect *)rect_x
{
	NSRect rect_dps;
	NSPoint start_x, end_x;
	NSPoint start_dps, end_dps;
	
	start_x = rect_x->origin;
	end_x   = NSRect_end(rect_x);
	
	start_dps = [self translatePointFromXToDPS: &start_x];
	end_dps   = [self translatePointFromXToDPS: &end_x];
	
	NSRect_from_points(&rect_dps, &start_dps, &end_dps);
	
	return rect_dps;
}
- (NSRect)translateRectFromDPSToX: (NSRect *)rect_dps
{
	NSRect rect_x;
	NSPoint start_x, end_x;
	NSPoint start_dps, end_dps;
	
	start_dps = rect_dps->origin;
	end_dps   = NSRect_end(rect_dps);
	
	start_x = [self translatePointFromDPSToX: &start_dps];
	end_x   = [self translatePointFromDPSToX: &end_dps];
	
	NSRect_from_points(&rect_x, &start_x, &end_x);
	
	return rect_x;
}
- (NSSize)translateSizeFromXToDPS: (NSSize *)size_x
{
  NSRect rect_x;

  NSRect_from_NSSize(&rect_x, size_x);

  return [self translateRectFromXToDPS: &rect_x].size;
}

- (NSSize)dpsAreaSize
{
	NSRect rect_x;
	NSRect rect_dps;
	
	NSRect_from_gtkAllocation(&rect_x, &(widget->allocation));
	rect_dps = [self translateRectFromXToDPS: &rect_x];

	return rect_dps.size;
}

- (NSSize)documentSize
{
	if (drawing_engine){
		return [drawing_engine documentSize];
	} 
	else {
		return NSZeroSize;
	}
}
- (NSSize)dpsAreaSizeInX
{
	NSSize size;

	NSSize_from_gtkAllocation(&size, &(widget->allocation));

	return size;
}
- (NSSize)documentSizeInX
{
	NSSize result;

	float scale = [drawing_engine absoluteScale];
	result.width = document_size_x.width * scale;
	result.height = document_size_x.height * scale;

	return result;
}
@end


/*
 * Cateogry for subclass
 */
@implementation GyveView(Protected)
- (void) changeAreaSizeWidth: (int)w_x height: (int)h_x
{
	NSPoint offset;
	NSSize tmp;
	NSSize area_size, doc_size;
	float  scale;

	//coord_tr.updated = NO;
	//[self updateCoordTr];
	scale = [self absoluteScale];
	area_size = [self dpsAreaSizeInX];
	doc_size  = [self documentSizeInX];
	NSSize_diff(&area_size, &doc_size,  &tmp);
	offset.x = tmp.width/2.0;
	offset.y = tmp.height/2.0;
	offset.y = area_size.height - offset.y;
	
	gtk_dps_area_set_offset(GTK_DPS_AREA(widget),offset.x, offset.y);
	gtk_dps_area_set_scale(GTK_DPS_AREA(widget),scale);
	coord_tr.updated = NO;
	[self updateCoordTr];

	//[self updateCache];
	//[self redrawRect: NULL];
	if (GTK_WIDGET_REALIZED(widget)) {
		[drawing_engine redrawAll:GTK_DPS_AREA(widget)];
		[self updateCache];
		[self drawSelf: NULL];
	}
}
/** (?_?) **/
- (void)updateCoordTr
{
	NSPoint offset;
	DPSContext ctxt = DPSGetCurrentContext();

	[self dpsAreaBegin];
	{
		if (ctxt) {
			DPSWinstall_procs(ctxt); //�ɤΰ��֤��ɤ��Τ��ʡ�
			coord_tr_get(&coord_tr, ctxt);
			coord_tr.updated = YES;
			[self calcDocumentSize];
		}
		else {
			coord_tr.updated = NO;
		}
	}
	[self dpsAreaEnd];
}
- (void)realizeEvent
{
	[self updateCoordTr];
	x_display = GDK_WINDOW_XDISPLAY(widget->window);
	x_gc = GDK_GC_XGC(GTK_DPS_AREA(widget)->gdk_dps_context->gc);
	x_window = GDK_WINDOW_XWINDOW(widget->window);
	width = GTK_WIDGET(widget)->allocation.width;
	height = GTK_WIDGET(widget)->allocation.height;

	/** make cache **/ 
	[drawing_engine redrawAll:GTK_DPS_AREA(widget)];
	[self updateCache];
	[self drawSelf: NULL];
	
	//[self updateCoordTr];
	//[self updateCache];
}
/* cache �����ξ�硢 cache �򥳥ԡ�����������ɤ��Ϥ� */
- (void)exposeEvent: (GdkEventExpose*)e
{
	NSPoint a, b, xpoint;
	NSRect redraw_rect;
  
	NSSize area_size, doc_size;

	if (nil == drawing_engine) {
		return;
	}
	if (NO == coord_tr.updated) {
		[self updateCoordTr];
	}

	[self drawCache:NULL];
	return;
	/* GdkEventExpose e��������褹���ΰ��DPS�κ�ɸ�ϤǷ׻�����. */ 
	xpoint.x = (float)(e->area.x);
	xpoint.y = (float)(e->area.y);
	a = [self translatePointFromXToDPS: &xpoint];

	xpoint.x = (float)(e->area.x + e->area.width);
	xpoint.y = (float)(e->area.y + e->area.height);
	b = [self translatePointFromXToDPS: &xpoint];
	
	NSRect_from_points(&redraw_rect, &a, &b);
  
	if (e->count > 0) {
		/* e�Τ��Ȥ�, �ޤ� EventExpose ��³�����, �ΰ�򵭲����������, 
		   �����褷�ʤ�. */
		if (NO == receiving_expose_events_sequence) {
			/* Ϣ³����expoise���٥�Ȥκǽ�Ǥ����, 
			   redraw����å�����, expoise���٥����ν�����Ǥ���
			   ���Ȥ򼫳Ф���. */
			[self redrawLockRetain];
			receiving_expose_events_sequence = YES;
		}
    }  
	else {
		if (YES == receiving_expose_events_sequence) {
			/* 1�İʾ��event expose��κǸ�Υ��٥��. 
			   ����׻������ΰ��ä���, ���ޤޤǷ׻������ΰ��
			   ������̿���ȯ�Ԥ���. */
			[self redrawLockRelease];
			[self redrawRect: &redraw_rect];
	
			// �����ȿ޷�������
			//[drawing_engine drawCurrentLayer: GTK_DPS_AREA(widget)];
	
			receiving_expose_events_sequence = NO;
		}
		else {
			/* total_redraw_rect��zero�ΤȤ���, e�� EventExpose�����
			   �����ǤϤʤ�. ���ʤ��ñ�Ȥ�EventExpose�Ǥ���, 
			   ����׻������ΰ������褹��ɬ�פ�����. */
			[self redrawRect: &redraw_rect];

			// �����ȿ޷�������
			//[drawing_engine drawCurrentLayer: GTK_DPS_AREA(widget)];
		}
    }
}
- (GtkWidget *)dpsAreaWidget
{
	return widget;
}
- (void)calcDocumentSize
{
	NSSize tmp;
	NSSize size = [self documentSizeInX];
	if (drawing_engine) {
		tmp = [self translateSizeFromXToDPS: &size];
		[drawing_engine setDocumentSize: &tmp];
    }
}
- (BOOL)calcBBoxOfFigObj: (id<PSFigObj>)figobj
{
	if (drawing_engine) {
		return [drawing_engine calcBBoxOfFigObj: figobj];
	}
	else {
		return NO;
	}
}
@end

static void
expose_handler (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
#ifdef DEBUG
	printf("########## EXPOSE ############\n");
#endif
	[(GyveView *)data exposeEvent: event];
}

static void
realize_handler(GtkWidget *widget, gpointer data)
{
#ifdef DEBUG
	printf("########## REALIZE ############\n");
#endif
	[(GyveView *)data realizeEvent];
}

static void
size_allocate_handler(GtkWidget *widget, GtkAllocation  *allocation, 
					  gpointer data)
{
#ifdef DEBUG
	printf("########## SIZE_ALLOCATE ############\n");
#endif
	//[(GyveView *)data sizeAllocateEvent: allocation];

	[(GyveView *)data changeAreaSizeWidth: allocation->width
				 height: allocation->height];
}






