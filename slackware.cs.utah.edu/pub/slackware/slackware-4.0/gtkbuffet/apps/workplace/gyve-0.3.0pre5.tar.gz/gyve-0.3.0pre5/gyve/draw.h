/* draw.h generated from draw.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#ifndef DRAW_H
#define DRAW_H

#if  defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

extern void psw_try_paint( /* float x, y, r, g, b; */ );

extern void psw_alloc_string_buffer( /* char *bufname; int size; */ );

extern void psw_free_string_buffer( /* char *bufname; */ );

extern void psw_put_img_source_proc( /* char *bufname; */ );

extern void psw_rim_fill( /* float x_outer, y_outer, width_outer, height_outer, x_inner, y_inner, width_inner, height_inner; */ );

extern void psw_draw_center( /* float x0, y0, size; */ );

extern void psw_ellipse_stroke( /* float x, y, w, h; */ );

extern void psw_draw_handle( /* float x, y; */ );

extern void psw_draw_bbox_handles( /* float llx, lly, urx, ury; */ );

extern void psw_draw_bbox_rect( /* float llx, lly, urx, ury; */ );

extern void psw_draw_line( /* float x0, y0, x1, y1; */ );

#if  defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* DRAW_H */
