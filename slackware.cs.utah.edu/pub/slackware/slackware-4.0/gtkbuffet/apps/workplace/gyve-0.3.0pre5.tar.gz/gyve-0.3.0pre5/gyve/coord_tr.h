/* coord_tr.h generated from coord_tr.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#ifndef COORD_TR_H
#define COORD_TR_H

#if  defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

extern void psw_get_transform( /* DPSContext ctxt; float ctm[], invctm[]; int *x_offset, *y_offset; */ );

#if  defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* COORD_TR_H */
