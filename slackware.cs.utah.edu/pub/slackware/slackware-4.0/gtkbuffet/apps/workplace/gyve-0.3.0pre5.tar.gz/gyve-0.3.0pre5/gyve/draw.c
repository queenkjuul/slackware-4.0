/* draw.c generated from draw.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#include <DPS/dpsfriends.h>
#include <string.h>

#line 1 "draw.psw"
/* draw.psw --- 

   Copyright (C) 1998, 1999 Free Software Foundation, Inc.

   Written by:  Masatake YAMATO <masata-y@is.aist-nara.ac.jp>
   
   This file is part of the GNU Yellow Vector Editor

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
   
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 
#line 31 "draw.c"
void psw_try_paint(x, y, r, g, b)
float x, y, r, g, b; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjReal obj2;
    DPSBinObjReal obj3;
    DPSBinObjReal obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjReal obj6;
    DPSBinObjReal obj7;
    DPSBinObjReal obj8;
    DPSBinObjReal obj9;
    DPSBinObjReal obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjGeneric obj12;
    DPSBinObjGeneric obj13;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 14, 116,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 78},	/* gsave */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 111},	/* newpath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: r */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: g */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: b */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 157},	/* setrgbcolor */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_LITERAL|DPS_REAL, 0, 0, 5.0},
    {DPS_LITERAL|DPS_REAL, 0, 0, 5.0},
    {DPS_LITERAL|DPS_REAL, 0, 0, 360.0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 5},	/* arc */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 66},	/* fill */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 77},	/* grestore */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;

  _dpsP[6].val.realVal = x;
  _dpsP[7].val.realVal = y;
  _dpsP[2].val.realVal = r;
  _dpsP[3].val.realVal = g;
  _dpsP[4].val.realVal = b;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,116);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 30 "draw.psw"

#line 85 "draw.c"
void psw_alloc_string_buffer(bufname, size)
char *bufname; int size; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char sizeFlag;
    unsigned short topLevelCount;
    unsigned int nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjGeneric obj3;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 0, 4, 40,
    {DPS_LITERAL|DPS_NAME, 0, 0, 32},	/* param bufname */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},	/* param: size */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 165},	/* string */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  register int _dps_offset = 32;

  _dpsP[0].length = strlen(bufname);
  _dpsP[1].val.integerVal = size;
  _dpsP[0].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[0].length;

  _dpsF.nBytes = _dps_offset+8;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,40);
  DPSWriteStringChars(_dpsCurCtxt, (char *)bufname, _dpsP[0].length);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 34 "draw.psw"

#line 123 "draw.c"
void psw_free_string_buffer(bufname)
char *bufname; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char sizeFlag;
    unsigned short topLevelCount;
    unsigned int nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjGeneric obj2;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 0, 3, 32,
    {DPS_LITERAL|DPS_NAME, 0, 0, 24},	/* param bufname */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 113},	/* null */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  register int _dps_offset = 24;

  _dpsP[0].length = strlen(bufname);
  _dpsP[0].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[0].length;

  _dpsF.nBytes = _dps_offset+8;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,32);
  DPSWriteStringChars(_dpsCurCtxt, (char *)bufname, _dpsP[0].length);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 38 "draw.psw"

#line 158 "draw.c"
void psw_put_img_source_proc(bufname)
char *bufname; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char sizeFlag;
    unsigned short topLevelCount;
    unsigned int nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjGeneric obj3;
    DPSBinObjGeneric obj4;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 0, 1, 48,
    {DPS_EXEC|DPS_ARRAY, 0, 4, 8},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 31},	/* currentfile */
    {DPS_EXEC|DPS_NAME, 0, 0, 40},	/* param bufname */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 124},	/* readhexstring */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 117},	/* pop */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  register int _dps_offset = 40;

  _dpsP[2].length = strlen(bufname);
  _dpsP[2].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[2].length;

  _dpsF.nBytes = _dps_offset+8;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,48);
  DPSWriteStringChars(_dpsCurCtxt, (char *)bufname, _dpsP[2].length);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 42 "draw.psw"


/*
           outer       
   +-----------------+-------+
   |                 |       |
   |        c        |       |
   |                 |       |
   +----+------------|       |
   |    |            |       |
   |    |            |   b   |
   |    |   inner    |       |
   |  d |            |       |
   |    |            |       |
   |    |------------+-------+
   |    |                    |
   |    |        a           |
   +----+--------------------+
       
 */
#line 216 "draw.c"
void psw_rim_fill(x_outer, y_outer, width_outer, height_outer, x_inner, y_inner, width_inner, height_inner)
float x_outer, y_outer, width_outer, height_outer, x_inner, y_inner, width_inner, height_inner; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjReal obj1;
    DPSBinObjReal obj2;
    DPSBinObjReal obj3;
    DPSBinObjReal obj4;
    DPSBinObjReal obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjReal obj8;
    DPSBinObjReal obj9;
    DPSBinObjGeneric obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjReal obj12;
    DPSBinObjReal obj13;
    DPSBinObjGeneric obj14;
    DPSBinObjReal obj15;
    DPSBinObjReal obj16;
    DPSBinObjReal obj17;
    DPSBinObjReal obj18;
    DPSBinObjGeneric obj19;
    DPSBinObjGeneric obj20;
    DPSBinObjReal obj21;
    DPSBinObjGeneric obj22;
    DPSBinObjReal obj23;
    DPSBinObjReal obj24;
    DPSBinObjReal obj25;
    DPSBinObjGeneric obj26;
    DPSBinObjGeneric obj27;
    DPSBinObjGeneric obj28;
    DPSBinObjReal obj29;
    DPSBinObjReal obj30;
    DPSBinObjReal obj31;
    DPSBinObjGeneric obj32;
    DPSBinObjReal obj33;
    DPSBinObjReal obj34;
    DPSBinObjGeneric obj35;
    DPSBinObjReal obj36;
    DPSBinObjGeneric obj37;
    DPSBinObjReal obj38;
    DPSBinObjReal obj39;
    DPSBinObjGeneric obj40;
    DPSBinObjReal obj41;
    DPSBinObjReal obj42;
    DPSBinObjGeneric obj43;
    DPSBinObjGeneric obj44;
    DPSBinObjGeneric obj45;
    DPSBinObjReal obj46;
    DPSBinObjReal obj47;
    DPSBinObjReal obj48;
    DPSBinObjReal obj49;
    DPSBinObjGeneric obj50;
    DPSBinObjReal obj51;
    DPSBinObjReal obj52;
    DPSBinObjGeneric obj53;
    DPSBinObjReal obj54;
    DPSBinObjGeneric obj55;
    DPSBinObjGeneric obj56;
    DPSBinObjGeneric obj57;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 58, 468,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 78},	/* gsave */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_outer */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: width_outer */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_outer */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_outer */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 128},	/* rectfill */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: width_inner */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 1},	/* add */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: width_outer */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_outer */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: width_inner */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: height_outer */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_outer */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 128},	/* rectfill */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_outer */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: height_inner */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 1},	/* add */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_outer */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: width_inner */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 1},	/* add */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_outer */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: height_outer */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 1},	/* add */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: height_inner */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 1},	/* add */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 128},	/* rectfill */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_outer */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_outer */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x_outer */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_inner */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y_outer */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: height_inner */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 1},	/* add */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 128},	/* rectfill */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 77},	/* grestore */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;

  _dpsP[5].val.realVal =
  _dpsP[18].val.realVal =
  _dpsP[29].val.realVal =
  _dpsP[34].val.realVal =
  _dpsP[46].val.realVal =
  _dpsP[49].val.realVal = x_outer;
  _dpsP[2].val.realVal =
  _dpsP[9].val.realVal =
  _dpsP[25].val.realVal =
  _dpsP[38].val.realVal =
  _dpsP[47].val.realVal =
  _dpsP[52].val.realVal = y_outer;
  _dpsP[3].val.realVal =
  _dpsP[16].val.realVal = width_outer;
  _dpsP[23].val.realVal =
  _dpsP[39].val.realVal = height_outer;
  _dpsP[1].val.realVal =
  _dpsP[4].val.realVal =
  _dpsP[12].val.realVal =
  _dpsP[17].val.realVal =
  _dpsP[33].val.realVal =
  _dpsP[48].val.realVal = x_inner;
  _dpsP[8].val.realVal =
  _dpsP[15].val.realVal =
  _dpsP[24].val.realVal =
  _dpsP[30].val.realVal =
  _dpsP[41].val.realVal =
  _dpsP[51].val.realVal = y_inner;
  _dpsP[13].val.realVal =
  _dpsP[21].val.realVal =
  _dpsP[36].val.realVal = width_inner;
  _dpsP[31].val.realVal =
  _dpsP[42].val.realVal =
  _dpsP[54].val.realVal = height_inner;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,468);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 94 "draw.psw"

#line 387 "draw.c"
void psw_draw_center(x0, y0, size)
float x0, y0, size; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjReal obj2;
    DPSBinObjReal obj3;
    DPSBinObjReal obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjReal obj9;
    DPSBinObjGeneric obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjGeneric obj12;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 13, 108,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 78},	/* gsave */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 111},	/* newpath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x0 */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y0 */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: size */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 360},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 5},	/* arc */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 22},	/* closepath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 1.0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 155},	/* setlinewidth */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 167},	/* stroke */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 77},	/* grestore */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;

  _dpsP[2].val.realVal = x0;
  _dpsP[3].val.realVal = y0;
  _dpsP[4].val.realVal = size;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,108);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 104 "draw.psw"

#line 437 "draw.c"
void psw_ellipse_stroke(x, y, w, h)
float x, y, w, h; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjReal obj1;
    DPSBinObjReal obj2;
    DPSBinObjReal obj3;
    DPSBinObjReal obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 9, 76,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 111},	/* newpath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: w */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: h */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 360},
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* ellipse */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 167},	/* stroke */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  {
  static int _dpsT = 1;

  if (_dpsT) {
    static char *_dps_names[] = {
	"ellipse"};
    int *_dps_nameVals[1];
    _dps_nameVals[0] = (int *)&_dpsP[7].val.nameVal;

    DPSMapNames(_dpsCurCtxt, 1, (char **) _dps_names, _dps_nameVals);
    _dpsT = 0;
    }
  }


  _dpsP[1].val.realVal = x;
  _dpsP[2].val.realVal = y;
  _dpsP[3].val.realVal = w;
  _dpsP[4].val.realVal = h;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,76);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 110 "draw.psw"

#line 494 "draw.c"
void psw_draw_handle(x, y)
float x, y; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjReal obj0;
    DPSBinObjReal obj1;
    DPSBinObjGeneric obj2;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 3, 28,
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* handlerect */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  {
  static int _dpsT = 1;

  if (_dpsT) {
    static char *_dps_names[] = {
	"handlerect"};
    int *_dps_nameVals[1];
    _dps_nameVals[0] = (int *)&_dpsP[2].val.nameVal;

    DPSMapNames(_dpsCurCtxt, 1, (char **) _dps_names, _dps_nameVals);
    _dpsT = 0;
    }
  }


  _dpsP[0].val.realVal = x;
  _dpsP[1].val.realVal = y;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,28);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 115 "draw.psw"

#line 537 "draw.c"
void psw_draw_bbox_handles(llx, lly, urx, ury)
float llx, lly, urx, ury; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjReal obj0;
    DPSBinObjReal obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjReal obj3;
    DPSBinObjReal obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjReal obj6;
    DPSBinObjReal obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjReal obj9;
    DPSBinObjReal obj10;
    DPSBinObjGeneric obj11;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 12, 100,
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: llx */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: lly */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* handlerect */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: llx */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: ury */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* handlerect */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: urx */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: lly */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* handlerect */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: urx */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: ury */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* handlerect */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  {
  static int _dpsT = 1;

  if (_dpsT) {
    static char *_dps_names[] = {
	"handlerect",
	(char *) 0 ,
	(char *) 0 ,
	(char *) 0 };
    int *_dps_nameVals[4];
    _dps_nameVals[0] = (int *)&_dpsP[2].val.nameVal;
    _dps_nameVals[1] = (int *)&_dpsP[11].val.nameVal;
    _dps_nameVals[2] = (int *)&_dpsP[8].val.nameVal;
    _dps_nameVals[3] = (int *)&_dpsP[5].val.nameVal;

    DPSMapNames(_dpsCurCtxt, 4, (char **) _dps_names, _dps_nameVals);
    _dpsT = 0;
    }
  }


  _dpsP[0].val.realVal =
  _dpsP[3].val.realVal = llx;
  _dpsP[1].val.realVal =
  _dpsP[7].val.realVal = lly;
  _dpsP[6].val.realVal =
  _dpsP[9].val.realVal = urx;
  _dpsP[4].val.realVal =
  _dpsP[10].val.realVal = ury;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,100);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 122 "draw.psw"

#line 610 "draw.c"
void psw_draw_bbox_rect(llx, lly, urx, ury)
float llx, lly, urx, ury; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjReal obj0;
    DPSBinObjReal obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjReal obj3;
    DPSBinObjReal obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjReal obj6;
    DPSBinObjReal obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjReal obj9;
    DPSBinObjReal obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjReal obj12;
    DPSBinObjReal obj13;
    DPSBinObjGeneric obj14;
    DPSBinObjGeneric obj15;
    DPSBinObjGeneric obj16;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 17, 140,
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: llx */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: lly */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 107},	/* moveto */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: urx */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: lly */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 99},	/* lineto */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: urx */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: ury */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 99},	/* lineto */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: llx */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: ury */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 99},	/* lineto */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: llx */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: lly */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 99},	/* lineto */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 22},	/* closepath */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 167},	/* stroke */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;

  _dpsP[0].val.realVal =
  _dpsP[9].val.realVal =
  _dpsP[12].val.realVal = llx;
  _dpsP[1].val.realVal =
  _dpsP[4].val.realVal =
  _dpsP[13].val.realVal = lly;
  _dpsP[3].val.realVal =
  _dpsP[6].val.realVal = urx;
  _dpsP[7].val.realVal =
  _dpsP[10].val.realVal = ury;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,140);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 131 "draw.psw"

#line 675 "draw.c"
void psw_draw_line(x0, y0, x1, y1)
float x0, y0, x1, y1; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjReal obj0;
    DPSBinObjReal obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjReal obj3;
    DPSBinObjReal obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 7, 60,
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x0 */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y0 */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 107},	/* moveto */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x1 */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y1 */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 99},	/* lineto */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 167},	/* stroke */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;

  _dpsP[0].val.realVal = x0;
  _dpsP[1].val.realVal = y0;
  _dpsP[3].val.realVal = x1;
  _dpsP[4].val.realVal = y1;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,60);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 137 "draw.psw"
