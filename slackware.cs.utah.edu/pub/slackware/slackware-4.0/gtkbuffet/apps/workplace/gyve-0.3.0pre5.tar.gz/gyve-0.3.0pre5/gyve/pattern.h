/* pattern.h generated from pattern.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#ifndef PATTERN_H
#define PATTERN_H

#if  defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

extern void psw_define_user_pattern( /* DPSContext ctxt; int number; */ );

#if  defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* PATTERN_H */
