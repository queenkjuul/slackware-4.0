/* GyveEventHandler.m --- object that handles event on canvas

   Copyright (C) 1998, 1999 Free Software Foundation, Inc.

   Written by:  Masatake YAMATO <masata-y@is.aist-nara.ac.jp>
   
   This file is part of the GNU Yellow Vector Editor

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
   
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 

#include "utilities.h"
#include "public.h"
#include "popup_menu.h"
#include "GyveEventHandler.h"
#include "GyveBuffer.h"
#include "GyveWindow.h"
#include "Gyve.h"
#include "GyveCanvas.h"
#include "ToolBox.h"
#include "PaintStylePallet.h"
#include <gdk/gdkkeysyms.h>
#include <gdk/gdktypes.h>

static GtkWidget *popup_menu = NULL;

@implementation  GyveEventHandler
+ (void)initialize
{

	GtkItemFactoryEntry popup_menu_items[] =
	{
		{ "/_File", NULL, NULL, NULL, "<Branch>"},
		{ "/File/Print", NULL, menu_file_print, NULL},
		{ "/File/Export to GIMP", NULL, menu_file_export, NULL},
		{ "/_Edit", NULL, NULL, NULL,"<Branch>"},
		{ "/Edit/Cut", NULL, menu_edit_cut, NULL},
		{ "/Edit/Copy", NULL, menu_edit_copy, NULL},
		{ "/Edit/Paste", NULL, menu_edit_paste, NULL},
		{ "/Edit/Delete", NULL, menu_edit_delete, NULL},
		{ "/_Object", NULL, NULL, NULL,"<Branch>"},
		{ "/Object/Group/Create", NULL, menu_group_create, NULL},
		{ "/Object/Group/Release", NULL, menu_group_release, NULL},
		{ "/Object/Mask/Create", NULL, menu_mask_create, NULL},
		{ "/Object/Mask/Release", NULL, menu_mask_release, NULL},
		{ "/Object/Compound Paths/Create", NULL, menu_compound_paths_create, NULL},
		{ "/Object/Compound Paths/Release", NULL, menu_compound_paths_release, NULL},
		{ "/Object/Image/Random", NULL, menu_image_test_random, NULL},
		{ "/Object/Image/Import Xpm", NULL, menu_image_test_xpm, NULL},
		{ "/Object/Text/GYVE Logo", NULL, menu_text_logo, NULL},
		{ "/_Drawing Mode", NULL, NULL, NULL,"<Branch>"},
		{ "/Drawing Mode/Preview", NULL, menu_mode_preview, NULL},
		{ "/Drawing Mode/Artwork", NULL, menu_mode_artwork, NULL},
	};

	
	gint npopup_menu_items = sizeof(popup_menu_items)/sizeof(popup_menu_items[0]);
	popup_menu = popup_menu_new(popup_menu_items, npopup_menu_items, "<main>");
	
}
- init
{
	[self shouldNotImplement: _cmd];
	return nil;
}
- initWithBuffer: (GyveBuffer *)b
{
	[super init];
	dragging = NO;
	tool = nil;
	ASSGIN_NSOBJECT(b, buffer);
	ring_counter_init(&thinner, 2);
	return self ;
}
- (void)thinOutMotionEventBy: (int) n
{
	ring_counter_set_max(&thinner, n);
}
- (void)buttonPressEvent:  (GdkEventButton * )event  onCanvas: (GyveCanvas *)canvas 
{
	NSPoint dpspoint;
	NSObject <GyveTool> * new_tool = [ToolBox tool];

	[canvas dpsAreaBegin];

	[[Gyve application] setMode: document_implicit_mode];
	
	if (new_tool != tool) {
		ASSGIN_NSOBJECT(new_tool, tool);
		[GyveWindow setCurrentWindow: [GyveWindow lookUpWindowByCanvas: canvas]];
		if (tool)	{
			[tool startSessionOnCanvas: canvas withBuffer: buffer];
		}
    }

	[GyveWindow setLastClickedWindow: [GyveWindow lookUpWindowByCanvas: canvas]];
	/* SOME WRONG 
	if ([buffer countSelectedFigObjs] > 0) {
		NSObject<PSFigObj>* primitive_figobj;
		PSPaintStyle * paint_style;

		primitive_figobj = [[buffer selectionsLayer] lastPrimitiveFigObj];

		if ([primitive_figobj respondsToSelector: @selector(paintStyle)]) {
			paint_style = [primitive_figobj performSelector: 
												@selector(paintStyle)];
			[(PaintStylePallet *)[PaintStylePallet sharedObject] 
								 installPaintStyle: paint_style];
		}
    }
	*/	
	//[canvas dpsAreaBegin];
	button_number = event->button;
	if (3 == button_number) {
		popup_menu_popup(popup_menu, event->button, event->time);
	}
	else if (2 == button_number) {
		;
    }
	else if (1 == button_number) {
		dragging = YES;
		dpspoint = [canvas translatePointFromGdkEventToDPS: (GdkEvent *)event];
	
		if (tool) {
			[tool buttonPressEvent: event
				  onCanvas: canvas
				  atPoint: &dpspoint
				  withBuffer: buffer];
		}
		//[canvas redrawRect: NULL];
	}
}
- (void)buttonReleaseEvent:(GdkEventButton *)event   onCanvas:(GyveCanvas *)canvas
{
	NSPoint dpspoint;

	GyveCanvas * old_canvas = [[GyveWindow currentWindow] contentCanvas];
	GyveBuffer * old_buffer = [[GyveWindow currentWindow] contentBuffer];

	button_number = event->button;
	if (3 == button_number) {
		;// For menu
    }
	else if (2 == button_number) {
		;
    }
	else if (1 == button_number) {
fprintf(stderr,"*************0\n");
		dpspoint = [canvas translatePointFromGdkEventToDPS: (GdkEvent *)event];
fprintf(stderr,"*************1\n");
		if (tool) {
			[tool buttonReleaseEvent: event
				  onCanvas: canvas
				  atPoint: &dpspoint
				  withBuffer: buffer];
		}
    }

fprintf(stderr,"*************2\n");
	if (NO == dragging){
		if (tool) {
			[tool finishSessionOnCanvas: old_canvas withBuffer: old_buffer];
		}
	}

fprintf(stderr,"*************3\n");
	[canvas dpsAreaEnd];
	dragging = NO;
	button_number = NO;
fprintf(stderr,"*************END\n");

}
- (void)motionNotifyEvent: (GdkEventMotion *)event onCanvas:(GyveCanvas *)canvas
{
	NSPoint dpspoint;

	ring_counter_inc (&thinner);
	if (NO == ring_counter_is_striking(&thinner)) {
		return;
	}

	if (3 == button_number) {
		;// For menu
    }
	else if (2 == button_number) {
		;
    }
	else if (1 == button_number) {
		dpspoint = [canvas translatePointFromGdkEventToDPS: (GdkEvent *)event];
		if (YES == dragging) {
			if (tool) {
				[tool dragNotifyEvent: event
					  onCanvas: canvas
					  atPoint: &dpspoint
					  withBuffer: buffer];

			}
		}
		/* $B$3$l$C$FI,MW$G$9$+!)(B
		else {
				if (tool) {
					[tool motionNotifyEvent: event
						  onCanvas: canvas
						  atPoint: &dpspoint
						  withBuffer: buffer];
				}
		}
		*/
    }
}
- (void)enterNotifyEvent:(GdkEventCrossing *)event onCanvas:(GyveCanvas *)canvas
{
	/*
	NSObject <GyveTool> * new_tool = [ToolBox tool];
	GyveCanvas * old_canvas = [[GyveWindow currentWindow] contentCanvas];
	GyveBuffer * old_buffer = [[GyveWindow currentWindow] contentBuffer];
	GyveCanvas * new_canvas = canvas;

	[[Gyve application] setMode: document_implicit_mode];
	
	if ((NO == dragging) && ((old_canvas != new_canvas) || new_tool != tool)) {
		if (tool) {
			[tool finishSessionOnCanvas: old_canvas withBuffer: old_buffer];
		}
		ASSGIN_NSOBJECT(new_tool, tool);
		[GyveWindow setCurrentWindow: [GyveWindow lookUpWindowByCanvas: canvas]];
		if (tool)	{
			[tool startSessionOnCanvas: canvas withBuffer: buffer];
		}
    }
	*/
}
- (void)leaveNotifyEvent:(GdkEventCrossing *)event onCanvas:(GyveCanvas *)canvas
{
}
- (void)keyPressEvent:(GdkEventKey *)event onCanvas:(GyveCanvas *)canvas
{
	if (tool) {
		int c = event->keyval;
		if (c == GDK_Return) {
			c = '\n';
		}
		else if (c != 65505) { //UGLY: 65505 means SHIFT 
			[canvas dpsAreaBegin];
		}
		[tool keyPressEvent: event
			  ofCharacter: c
			  onCanvas: canvas
			  withBuffer: buffer];
	}
}
- (void)keyReleaseEvent:(GdkEventKey *)event onCanvas:(GyveCanvas *)canvas
{
	if (event->keyval != 65505) {
		[canvas dpsAreaEnd];
	}
}
- (void)dealloc
{
	[buffer release], buffer = nil;
	[tool release], tool     = nil;
	[super dealloc];
}
@end





