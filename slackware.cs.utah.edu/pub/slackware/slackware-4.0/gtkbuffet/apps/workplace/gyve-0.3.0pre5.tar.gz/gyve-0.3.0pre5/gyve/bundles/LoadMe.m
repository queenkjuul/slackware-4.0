#include <Foundation/NSObject.h>
#include <stdio.h>
@interface LoadMe: NSObject
- doit;
@end

@implementation LoadMe
- doit
{
  fprintf(stderr, "DO...\n");
  return self ;
}
@end
