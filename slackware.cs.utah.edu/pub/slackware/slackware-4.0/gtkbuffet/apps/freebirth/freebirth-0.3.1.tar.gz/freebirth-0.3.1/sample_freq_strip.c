/* Freebirth
 * Copyright (C) 1999 topher lafata <topher@topher.com>,
 *		      Jake Donham <jake@bitmechanic.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this program (see COPYING); if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */


#include <math.h>
#include "sample_freq_strip.h"

#ifndef __GTK_DIAL_H__
 #include "gtkdial.h"
#endif


static void freq_callback(GtkAdjustment *adj, gpointer data)
{
  event *e; 
  event_bookeeper *eb;
  double pitch;

  pitch = pow(2,adj->value);
  eb = (event_bookeeper*)data;
  e = event_pitch_change_new(eb->seq_handle,pitch);

  if(eb != NULL)
    clean_bookeeper(eb,sequencer);
  seq_register_event(sequencer,eb->step,e);
  event_list_add(eb->last_events,e);
}


GtkWidget *sample_freq_strip_new( int seq_handle, seq *s, 
				  int num_steps, GtkStyle *dial_style)
{
  GtkObject *range;
  GtkWidget *dial;
  GtkWidget *box;
  event_bookeeper *eb;
  
  int i;

  box = gtk_hbox_new(TRUE,10);
  for(i = 0; i < num_steps;i++)
    {
      eb = e_bookeeper_new(i, seq_handle);
      /* from one octave down to one up */
      range = gtk_adjustment_new(0,-1,1,0.1,0.1,0.1);
      dial = gtk_dial_new(GTK_ADJUSTMENT(range)); 
      gtk_signal_connect (GTK_OBJECT (range), "value_changed",
			  GTK_SIGNAL_FUNC (freq_callback), (gpointer)eb );
      GTK_ADJUSTMENT(range)->value = 0;
      freq_callback(GTK_ADJUSTMENT(range),(gpointer)eb);
      gtk_box_pack_start(GTK_BOX(box),dial,FALSE,FALSE,
			 2);      
      if((i + 1) % 4 == 0 && i != num_steps - 1)
	{
	  GtkWidget *sep = gtk_vseparator_new();
	  gtk_box_pack_start(GTK_BOX(box),
			     sep,FALSE,FALSE,0);
	  gtk_widget_show(sep);
	}
      
      gtk_widget_set_style(dial,dial_style);
      gtk_widget_set_usize(dial,25,25);
      gtk_widget_show(dial);
    }

  return box;
  
}




/*
  Local Variables:
  mode: font-lock
  End:
*/

