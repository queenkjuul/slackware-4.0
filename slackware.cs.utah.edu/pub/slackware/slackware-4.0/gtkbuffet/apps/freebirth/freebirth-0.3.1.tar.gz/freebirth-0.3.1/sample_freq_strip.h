/* Freebirth
 * Copyright (C) 1999 topher lafata <topher@topher.com>,
 *		      Jake Donham <jake@bitmechanic.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this program (see COPYING); if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */



#define __SAMPLE_FREQ_STRIP_H

#ifndef __RAW_WAVE_H
  #include "raw_wave.h"
#endif
#ifndef __SEQ_H
  #include "sequencer.h"
#endif


#include <gtk/gtk.h>

extern seq *sequencer;

GtkWidget *sample_freq_strip_new( int seq_handle,seq *s, 
				 int num_steps, GtkStyle *dial_style);


/*
  Local Variables:
  mode: font-lock
  End:
*/

