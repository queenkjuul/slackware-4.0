#define PACKAGE "gstripchart"
#define GNOMELOCALEDIR "/usr/local/share/locale"
