/*
 * chart, version 1.0.
 *
 * A stripchart-like plotting program with a file-based parameter
 * input mechanism and a Gtk-based display mechanism.
 *
 * Copyright 1998 by John Kodis, kodis@jagunet.com
 */

#include <ctype.h>
#include <math.h>
#include <setjmp.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>

#include "gtk/gtk.h"

static char *prog_name = "chart";
static char *config_file = NULL;
static float sleep_time = 5.0;
static int post_init = 0, iteration = 0;

/* 
 * Expr -- the info required to evaluate an expression.
 *
 * The last and now arrays are doubles in order to handle values that
 * are very large integers without loss of precision.  The resultant
 * val is expected to fall in a much narrower range with less need for
 * precision.  A float is used to conserve storage space in the
 * history list.  */
typedef struct
{
  char *eqn_base, *s, *eqn_src;
  float val;
  int vars;
  double *last, *now;
  jmp_buf err_jmp;
}
Expr;

static void eval_error(Expr *e, char *msg, ...)
{
  va_list args;
  e->val = 0.0;
  if (post_init)
    longjmp(e->err_jmp, 1);
  fflush(stdout);
  va_start(args, msg);
  fprintf(stderr, "%s: %s: ", prog_name, e->eqn_src? e->eqn_src: "");
  vfprintf(stderr, msg, args);
  fprintf(stderr, "\n");
  va_end(args);
  exit(EXIT_FAILURE);
}

static char *trimtb(char *s)
{
  char *e = s + strlen(s) - 1;
  while (e >= s && isspace(*e))
    *e-- = '\0';
  return s;
}

static char *skipbl(char *s)
{
  while (isspace(*s))
    s++;
  return s;
}

static void stripbl(Expr *e, int skip)
{
  e->s = skipbl(e->s + skip);
}

static double add_op(Expr *e);

static double num_op(Expr *e)
{
  double val;
  if (isdigit(*e->s) || (*e->s && strchr("+-.", *e->s) && isdigit(e->s[1])))
    {
      char *r;
      val = strtod(e->s, &r);
      stripbl(e, (int)(r - e->s));
    }
  else if (*e->s == '(')
    {
      stripbl(e, 1);
      val = add_op(e);
      if (*e->s == ')')
	stripbl(e, 1);
      else
	eval_error(e, "rparen expected");
    }
  else if (*e->s == '$' || *e->s == '~')
    {
      if (isdigit(e->s[1]))
	{
	  int i = 0, c = *e->s;
	  for (e->s++; isdigit(*e->s); e->s++)
	    i = i * 10 + *e->s-'0';
	  if (i > e->vars)
	    eval_error(e, "no such field: %d", i);
	  stripbl(e, 0);
	  val = e->now[i-1];
	  if (c == '~')
	    val -= e->last[i-1];
	}
      else
	{
	  struct timeval tv;
	  static int t_revised;
	  static double t_last, t_now;
	  switch (*++e->s)
	    {
	    case 'i':	/* interval, in seconds */
	      val = sleep_time;
	      if (e->s[-1] == '~')
		val = 0;
	      e->s++;
	      break;
	    case 't':	/* time of day, in seconds */
	      if (t_revised != iteration)
		{
		  t_revised = iteration;
		  gettimeofday(&tv, NULL);
		  t_last = t_now;
		  t_now = tv.tv_sec + tv.tv_usec / 1e6;
		}
	      val = t_now;
	      if (e->s[-1] == '~')
		val -= t_last;
	      e->s++;
	      break;
	    case '\0':
	      eval_error(e, "missing variable identifer");
	      break;
	    default:
	      eval_error(e, "invalid variable identifer");
	    }
	}
    }
  else
    eval_error(e, "number expected");
  return val;
}

static double mul_op(Expr *e)
{
  double val = num_op(e);
  while (*e->s=='*' || *e->s=='/' || *e->s=='%')
    {
      char c = *e->s;
      stripbl(e, 1);
      if (c == '*')
	val *= num_op(e);
      else if (c == '/')
	val /= num_op(e);
      else
	val = fmod(val, num_op(e));
    }
  return val;
}

static double add_op(Expr *e)
{
  double val = mul_op(e);
  while (*e->s=='+' || *e->s=='-')
    {
      char c = *e->s;
      stripbl(e, 1);
      if (c == '+')
	val += mul_op(e);
      else
	val -= mul_op(e);
    }
  return val;
}

static double eval(char *eqn, char *src, int vars, double *last, double *now)
{
  Expr e;
  e.eqn_base = e.s = eqn;
  e.eqn_src = src;
  e.vars = vars;
  e.last = last;
  e.now  = now;

  if (setjmp(e.err_jmp))
    return e.val;

  stripbl(&e, 0);
  e.val = add_op(&e);
  if (*e.s)
    eval_error(&e, "extra gunk at end");

  return e.val;
}

/*
 * Param -- struct describing a single parameter.
 */
typedef struct
{
  char *ident;		/* paramater name */
  char id_char;		/* single-char parameter name abbreviation */
  char *color_name;	/* the name of the fg color for this parameter */
  char *filename;	/* the file to read this parameter from */
  char *pattern;	/* marks the line in the file for this paramater */
  char *eqn;		/* equation used to compute this paramater value */
  char *eqn_src;	/* where the eqn was defined, for error reporting */
  int vars;		/* how many vars to read from the line in the file */
  double *last, *now;	/* the last and current vars, as enumerated above */
  int max_val, num_val;	/* how many vals are allocated and in use */
  int new_val;		/* index of the newest val */
  float *val;		/* value history */
  float max, min;	/* max and min values ever encountered */
  float top, bot;	/* highest and lowest values ever expected */
  GdkColor gdk_color;	/* the rgb values for the color */
  GdkGC *gdk_gc;	/* the graphics context entry for the color */
}
Param;

static int params;
static Param **param;

/*
 * display -- the routine called to redisplay new parameters.
 */
static void (*display)(void);

/*
 * defns_error -- reports error and exits during config file parsing.
 */
static void defns_error(char *fn, int ln, char *fmt, ...)
{
  va_list args;
  fflush(stdout);
  va_start(args, fmt);
  fprintf(stderr, "%s: ", prog_name);
  fprintf(stderr, "%s, line %d: ", fn, ln);
  vfprintf(stderr, fmt, args);
  fprintf(stderr, "\n");
  va_end(args);
  exit(EXIT_FAILURE);
}

/*
 * streq -- case-blind string comparison returning true on equality.
 */
static int streq(const char *s1, const char *s2)
{
  return strcasecmp(s1, s2) == 0;
}

/*
 * isident -- ctype-style test for identifier chars.
 */
static int isident(int c)
{
  return isalnum(c) || c=='-' || c=='_';
}

/* 
 * split -- breaks a 'key: val' string into two pieces, returning the
 * broken-out parts of the original string, and a count of how many
 * pieces were found, which should be 2.  This is ugly, and could
 * stand improvement. 
 */
static int split(char *str, char **key, char **val)
{
  int p=0;
  *key = *val = NULL;
  str = skipbl(str);
  if (isalpha(*str))
    {
      p = 1;
      *key = str;
      while (isident(*str))
	str++;
      if (*str)
	{
	  *str++ = '\0';
	  while (isspace(*str))
	    str++;
	  if (*str)
	    {
	      *val = str;
	      p = 2;
	    }
	}
    }
  return p;
}

/* 
 * read_param_defns -- reads parameter definitions from the
 * configuration file.  Allocates space and performs other param
 * initialization.
 */
static int read_param_defns(Param ***ppp)
{
  int i, lineno = 0, params = 0;
  Param **p = NULL;
  char fn[FILENAME_MAX];
  FILE *fd;

  *ppp = p;
  if (config_file)
    {
      strcpy(fn, config_file);
      if ((fd=fopen(fn, "r")) == NULL)
	defns_error(fn, lineno, "can't open config file \"%s\"", config_file);
    }
  else
    {
      sprintf(fn, "%s/%s", getenv("HOME"), ".chart.conf");
      if ((fd=fopen(fn, "r")) == NULL)
	{
	  strcpy(fn, "/etc/chart.conf");
	  if ((fd=fopen(fn, "r")) == NULL)
	    defns_error(fn, lineno, "can't open config file \"%s\"", fn);
	}
    }

  while (!feof(fd) && !ferror(fd))
    {
      char *bp, buf[1000]; /* FIX THIS */
      if (fgets(buf, sizeof(buf), fd))
	{
	  lineno++;
	  bp = skipbl(buf);
	  if (*bp && *bp != '#')
	    {
	      char *key, *val;
	      trimtb(bp);
	      split(bp, &key, &val);
	      /* An "identifier" keyword introduces a new parameter.
                 We bump the params count, and allocate and initialize
                 a new Param struct with default values. */
	      if (streq(key, "identifier"))
		{
		  params ++;
		  p = realloc(p, params * sizeof(*p));
		  p[params-1] = malloc(sizeof(*p[params-1]));
		  p[params-1]->ident = strdup(val);
		  p[params-1]->vars = 0;
		  p[params-1]->id_char = '*';
		  p[params-1]->pattern = NULL;
		  p[params-1]->filename = NULL;
		  p[params-1]->eqn = NULL;
		  p[params-1]->eqn_src = NULL;
		  p[params-1]->color_name = NULL;
		  p[params-1]->max_val = 1024;
		  p[params-1]->new_val = 0;
		  p[params-1]->num_val = 0;
		  p[params-1]->top = 1.0;
		  p[params-1]->bot = 0.0;
		}
	      else if (params == 0)
		defns_error(fn, lineno, "ident must be first");
	      else if (streq(key, "id_char"))
		p[params-1]->id_char = val[0];
	      else if (streq(key, "color"))
		{
		  p[params-1]->color_name = strdup(val);
		  if (!gdk_color_parse(val, &p[params-1]->gdk_color))
		    defns_error(fn, lineno, "unrecognized color: %s", val);
		}
	      else if (streq(key, "filename"))
		p[params-1]->filename = strdup(val);
	      else if (streq(key, "pattern"))
		p[params-1]->pattern = strdup(val);
	      else if (streq(key, "fields"))
		p[params-1]->vars = atoi(val);
	      else if (streq(key, "equation"))
		{
		  char src[FILENAME_MAX+20];
		  sprintf(src, "%s, line %d", fn, lineno);
		  p[params-1]->eqn_src = strdup(src);
		  p[params-1]->eqn = strdup(val);
		}
	      else if (streq(key, "maximum"))
		p[params-1]->top = atof(val);
	      else if (streq(key, "minimum"))
		p[params-1]->bot = atof(val);
	      else
		defns_error(fn, lineno, "invalid option: \"%s\"", bp);
	    }
	}
    }
  fclose(fd);

  /* Allocate space after sizes have been established. */
  for (i=0; i<params; i++)
    {
      p[i]->val  = malloc(p[i]->max_val * sizeof(p[i]->val[0]));
      p[i]->now  = malloc(p[i]->vars * sizeof(p[i]->now[0]));
      p[i]->last = malloc(p[i]->vars * sizeof(p[i]->last[0]));
    }

  *ppp = p;
  return params;
}

/* 
 * split_and_extract -- reads whitespace delimited floats into now values.
 */
static int split_and_extract(char *str, Param *p)
{
  int i = 0;
  char *t = strtok(str, " \t");
  while (t && i < p->vars)
    {
      p->now[i] = atof(t);
      t = strtok(NULL, " \t");
      i++;
    }
  return i;
}

static float get_value(Param *p)
{
  double val = 0;
  FILE *pu = NULL;
  char buf[1000];

  if (p->filename)
    if (*p->filename == '|')
      pu = popen(p->filename+1, "r");
    else
      pu = fopen(p->filename, "r");
  if (pu)
    {
      fgets(buf, sizeof(buf), pu);
      if (p->pattern)
	while (!ferror(pu) && !feof(pu) && !strstr(buf, p->pattern))
	  fgets(buf, sizeof(buf), pu);
      if (*p->filename == '|') pclose(pu); else fclose(pu);
    }

  /* Copy now vals to last vals, update now vals, and compute a new
     param value based on the new now vals.  */
  memcpy(p->last, p->now, p->vars * sizeof(*(p->last)));
  split_and_extract(buf, p);
  val = eval(p->eqn, p->eqn_src, p->vars, p->last, p->now);

  /* Put the new val into the val history. */
  p->new_val = (p->new_val+1) % p->max_val;
  p->val[p->new_val] = val;
  if (p->num_val < p->max_val)
    p->num_val++;

  /* Update min and max based on new parameter value. */
  if (post_init == 0)
    p->min = p->max = val;
  else if (val < p->min)
    p->min = val;
  else if (val > p->max)
    p->max = val;

  return val;
}

/*
 * no_display -- does everything but displaying stuff.  For timing purposes.
 */
static void no_display(void)
{
  int p;
  while (1)
    {
      usleep((int)(1e6 * sleep_time + 0.5));
      iteration++;
      for (p=0; p<params; p++)
	get_value(param[p]);
    }
}

/*
 * numeric_with_ident -- prints a line of numeric values.
 */
static void numeric_with_ident(void)
{
  int p;
  while (1)
    {
      usleep((int)(1e6 * sleep_time + 0.5));
      iteration++;
      for (p=0; p<params; p++)
	get_value(param[p]);

      for (p=0; p<params; p++)
	fprintf(stdout, "%12.3f", param[p]->val[param[p]->new_val]);
      fprintf(stdout, "\n");
      for (p=0; p<params; p++)
	fprintf(stdout, "%12s", param[p]->ident);
      fprintf(stdout, "\r");
      fflush(stdout);
    }
}

/*
 * numeric_with_graph -- creates a lame vertically scrolling plot.
 */
static void numeric_with_graph(void)
{
  int p, width=76;
  char buf[79+1];

  memset(buf, ' ', sizeof(buf));
  buf[sizeof(buf)-1] = '\0';

  while (1)
    {
      usleep((int)(1e6 * sleep_time + 0.5));
      iteration++;
      for (p=0; p<params; p++)
	get_value(param[p]);

      for (p=0; p<params; p++)
	{
	  float v = param[p]->val[param[p]->new_val];
	  float m = param[p]->max;
	  float s = (m<=0) ? 0 : v / m;
	  char per[8];
	  int i = (int)((width-1) * s + 0.5);
	  buf[i] = param[p]->id_char;
	  sprintf(per, "%d", (int)(100*s));
	  memcpy(buf+i+1, per, strlen(per));
	}
      trimtb(buf);
      fprintf(stdout, "%s\n", buf);
    }
}

/*
 * Gtk display handler stuff...
 */

static GdkPixmap *pixmap;
static GdkColormap *colormap;

static void destroy_handler(GtkWidget *widget, gpointer *data)
{
  gtk_main_quit();
}

static int val2y(float val, float top, int height)
{
  return height - (height * val / top);
}

static gint expose_handler(GtkWidget *widget, GdkEventExpose *event)
{
  int p, w = widget->allocation.width, h = widget->allocation.height;

  /* On the first time through allocate a new GC and copy the window's
     black gc into it. Subsequently, free any previous pixmap, create
     a pixmap of window size and depth, and fill it with bg color. */
  if (pixmap == NULL)
    {
      colormap = gdk_window_get_colormap(widget->window);
      for (p=0; p<params; p++)
	{
	  gdk_color_alloc(colormap, &param[p]->gdk_color);
	  param[p]->gdk_gc = gdk_gc_new(widget->window);
	  gdk_gc_set_foreground(param[p]->gdk_gc, &param[p]->gdk_color);
	}
    }
  else
    gdk_pixmap_unref(pixmap);
  pixmap = gdk_pixmap_new(widget->window, w, h, -1);
  gdk_draw_rectangle(
    pixmap, widget->style->bg_gc[GTK_WIDGET_STATE(widget)], TRUE, 0,0, w,h);

  /* Plot as much of the value history as is available and as the
     window will hold.  Plot points from newest to oldest until we run
     out of data or the window is full. */
  for (p=params; p--; )
    {
      float top = param[p]->top;
      int n = w > param[p]->num_val ? w : param[p]->num_val;
      int i, j = param[p]->new_val;
      int x0, x1 = w - 1;
      int y0, y1 = val2y(param[p]->val[j], top, h);
      for (i=0; i<n; i++)
	{
	  if (--j < 0) j = param[p]->max_val - 1;
	  x0 = x1; y0 = y1;
	  x1 = x0 - 1;
	  y1 = val2y(param[p]->val[j], top, h);
	  gdk_draw_line(pixmap, param[p]->gdk_gc, x0,y0, x1,y1);
	}
    }

  /* Draw the exposed portions of the pixmap in its window. */
  gdk_draw_pixmap(
    widget->window, widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
    pixmap,
    event->area.x, event->area.y,
    event->area.x, event->area.y,
    event->area.width, event->area.height);
  return 0;
}

static gint timer_handler(gpointer targ)
{
  GtkWidget *widget = targ;
  int p, w = widget->allocation.width, h = widget->allocation.height;

  /* Shift the pixmap one pixel left, and clear the RHS  */
  gdk_window_copy_area(
    pixmap, widget->style->fg_gc[GTK_WIDGET_STATE(widget)], 0, 0,
    pixmap, 1, 0, w-1, h);
  gdk_draw_rectangle(
    pixmap, widget->style->bg_gc[GTK_WIDGET_STATE(widget)], TRUE, 
    w-1, 0, 1, h);

  /* Collect new parameter values and plot each in the RHS of the
     pixmap. */
  iteration++;
  for (p=0; p<params; p++)
    get_value(param[p]);
  for (p=params; p--; )
    {
      float top = param[p]->top;
      int i = param[p]->new_val;
      int m = param[p]->max_val;
      int y1 = val2y(param[p]->val[i], top, h);
      int y0 = val2y(param[p]->val[(i+m-1) % m], top, h);
      gdk_draw_line(pixmap, param[p]->gdk_gc, w-2,y0, w-1,y1);
    }

  gdk_draw_pixmap(
    widget->window, widget->style->fg_gc[GTK_WIDGET_STATE(widget)], 
    pixmap, 0,0, 0,0, w,h);
  return 1;
}

static void gtk_graph(void)
{
  GtkWidget *window, *drawing;
  /* Determine the minimum and nominal window sizes. */
  const int min_w=80, min_h=50, nom_w=160, nom_h=100;

  /* Create a top-level window. Set the title and establish delete and
     destroy event handlers. */
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name(window, prog_name);
  gtk_signal_connect(
    GTK_OBJECT(window), "destroy",
    GTK_SIGNAL_FUNC(destroy_handler), NULL);
  gtk_signal_connect(
    GTK_OBJECT(window), "delete_event",
    GTK_SIGNAL_FUNC(destroy_handler), NULL);

  /* Create a drawing area.  Add it to the window, show it, and
     set its expose event handler. */
  drawing = gtk_drawing_area_new();
  gtk_drawing_area_size(GTK_DRAWING_AREA(drawing), nom_w, nom_h);
  gtk_container_add(GTK_CONTAINER(window), drawing);
  gtk_widget_show(drawing);
  gtk_signal_connect(
    GTK_OBJECT(drawing), "expose_event", 
    (GtkSignalFunc)expose_handler, NULL);
  gtk_widget_set_events(drawing, GDK_EXPOSURE_MASK);

  /* Create a timer event.  Its handler gets the drawing widget. */
  gtk_timeout_add(
    (int)(1000*sleep_time + 0.5), (GtkFunction)timer_handler, drawing);

  /* Show the top-level window, set its minimum size, and enter the
     main event loop. */
  gtk_widget_show(window);
  gdk_window_set_hints(
    window->window, 0,0,  min_w, min_h, 0,0, GDK_HINT_MIN_SIZE);
  gtk_main();
}

/*
 * usage -- prints the standard switch info, then exits.
 */
static void usage(char *fmt, ...)
{
  va_list args;
  fflush(stdout);
  if (fmt)
    {
      va_start(args, fmt);
      fprintf(stderr, "%s: ", prog_name);
      vfprintf(stderr, fmt, args);
      fprintf(stderr, "\n");
      va_end(args);
    }
  fprintf(stderr, 
	  "%s: usage:\n"
	  "\t-h\n"
	  "\t-f <config-file>\n"
	  "\t-i <interval>\n"
	  "\t-d none | text | graph | gtk\n", prog_name);
  exit(EXIT_FAILURE);
}

/*
 * get_opts -- handles switch options, with error reporting through usage().
 */
static void get_opts(int argc, char **argv)
{
  display = gtk_graph; /* set default display type */
  while (1)
    switch (getopt(argc, argv, "hf:i:d:"))
      {
      case 'f':
	config_file = optarg;
	break;
      case 'i':
	sleep_time = atof(optarg);
	break;
      case 'd':
	if (streq("none", optarg))
	  display = no_display;
	else if (streq("text", optarg))
	  display = numeric_with_ident;
	else if (streq("graph", optarg))
	  display = numeric_with_graph;
	else if (streq("gtk", optarg))
	  display = gtk_graph;
	else
	  usage("invalid display type: %s", optarg);
	break;
      case 'h':
      default:
	usage(NULL);
      case EOF:
	return;
      }
}

/*
 * main -- for the stripchart display program.
 */
int main(int argc, char **argv)
{
  int p;

  /* Initialize the Gtk stuff first, whether Gtk is used or not, since
     failure to do so will cause the color name to rgb translation
     done in read_param_defns to dump core. */
  gtk_init(&argc, &argv);

  /* Get program options and read in the parameter definition file. */
  prog_name = *argv;
  get_opts(argc, argv);
  params = read_param_defns(&param);

  /* Get an initial set of parameter values, then fire up the display
     processing. */
  iteration++;
  for (p=0; p<params; p++)
    get_value(param[p]);
  post_init = 1;

  if (display)
    (*display)();

  return EXIT_SUCCESS;
}
