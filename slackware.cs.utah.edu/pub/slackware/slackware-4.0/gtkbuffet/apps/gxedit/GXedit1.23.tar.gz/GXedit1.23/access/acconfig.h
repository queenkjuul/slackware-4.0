/* Define if prototype cannot use a type of float if followed by K&R defn. */
#undef NOPROTOFLOAT

/* turn off strict IEEE compliance in favour of speed */
#undef HAVE_NONSTDARITH
       
/* Define if we can find -lX11 */
#undef HAVE_LIBX11
       
/* Define if we can find nas -laudio */
#undef HAVE_NAS
       

