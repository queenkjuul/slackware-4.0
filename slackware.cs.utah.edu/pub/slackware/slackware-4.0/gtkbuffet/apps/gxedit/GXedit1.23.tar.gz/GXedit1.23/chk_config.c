/* GXedit
 * Copyright 1998 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/

/* This file goes around normal makefile limitations w/o a complex 
   configure script */

#include <stdio.h>
#include "config.h"

main(int argc, char *argv[])
{
 int i;
 printf("\n*** Here are the settings defined in config.h\n\n");

#ifdef GTK_1_1
 printf("Using development GTK 1.1.x \n");
#else
 printf("Using GTK 1.0.x \n");
#endif   

#ifdef GTKEDITOR_PATCH
 i = 1;
 printf("Using the GtkEditor patch \n");
#else
 i = 0;
 printf("Using normal text editing\n");
#endif

#ifdef USE_NET
 printf("Network features turned ON\n");
#else
 printf("Network features turned OFF\n");
#endif

#ifdef BG_ON_START
 printf("Go to the background when started\n");
#else
 printf("Do not go to the background when started\n");
#endif

 printf("\n*** If you want to modify any of these, you can halt the compile process now by pressing CTRL+C and editing config.h yourself.\n\n");

 sleep(5);

 if(i) system("make gxe-with-gtkeditor");
 else system("make gxe");
 exit(0);
}
