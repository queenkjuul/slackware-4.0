#!/bin/bash
# ftp.sh output_file host directory user pass
ftp -n $2 > $1 2> $1 <<EOC
user $4 $5
binary
cd $3
ls
bye
EOC
