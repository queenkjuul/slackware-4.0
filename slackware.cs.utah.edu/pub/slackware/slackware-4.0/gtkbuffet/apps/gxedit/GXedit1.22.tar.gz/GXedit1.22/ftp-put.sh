#!/bin/bash
# ftp-put.sh output_file host directory remote_file local_file user pass
ftp -n $2 > $1 2> $1 <<EOC
user $6 $7
binary
cd $3
put $5 $4
bye
EOC
