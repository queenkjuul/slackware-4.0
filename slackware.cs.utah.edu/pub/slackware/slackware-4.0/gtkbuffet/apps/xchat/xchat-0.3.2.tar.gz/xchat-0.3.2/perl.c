#ifdef USE_PERL
#undef PACKAGE
#include <assert.h>
#include <EXTERN.h>
#include <perl.h>
#include <XSUB.h>
#undef USE_GNOME
#include "xchat.h"
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

extern void PrintText(struct session *sess, char *text);
extern struct session *find_session_from_channel(char *chan, struct server *serv);
extern int handle_command(char *cmd, struct session *sess);
int perl_load_file(char *script_name);


static PerlInterpreter *my_perl;
struct session *perl_sess;

struct _perl_inbound_handlers
{
   char *message_type;
   char *handler_name;
};

struct _perl_command_handlers
{
   char *command_name;
   char *handler_name;
};

GSList *perl_inbound_handlers;
GSList *perl_command_handlers;

XS(XS_IRC_add_message_handler);
XS(XS_IRC_add_command_handler);
XS(XS_IRC_print);
XS(XS_IRC_send_raw);
XS(XS_IRC_command);

void perl_init(void)
{
   char *perl_args[] = { "", "-e", "0" };
   char load_file[]=
"sub load_file()
{
  (my $file_name) = @_;
  open FH, $file_name or return 2;
  local($/) = undef;
  $file = <FH>; 
  close FH; 
  eval $file;
  return 1 if $@;
#  $file;
  return 0;
}
";

   my_perl = perl_alloc();
   perl_construct(my_perl);
   perl_parse(my_perl, NULL, 3, perl_args, NULL);
   perl_eval_pv(load_file, TRUE);
   perl_inbound_handlers = g_slist_alloc();
   perl_command_handlers = g_slist_alloc();

   /* load up all the custom IRC perl functions */
   newXS("IRC::add_message_handler", XS_IRC_add_message_handler, "IRC");
   newXS("IRC::add_command_handler", XS_IRC_add_command_handler, "IRC");
   newXS("IRC::print", XS_IRC_print, "IRC");
   newXS("IRC::send_raw", XS_IRC_send_raw, "IRC");
   newXS("IRC::command", XS_IRC_command, "IRC");
}

void perl_end(void)
{
   perl_destruct(my_perl);
   perl_free(my_perl);
}

int perl_load_file(char *script_name)
{
   char *load_file;
   SV *return_val;
   
   load_file = malloc(strlen(script_name) + 50);
   sprintf(load_file, "&load_file(\"%s\")", script_name);
   return_val = perl_eval_pv(load_file, TRUE);
   free(load_file);
   return SvNV(return_val);

}

int perl_inbound(struct session *sess, struct server *serv, char *buf)
{
   GSList *handler;
   struct _perl_inbound_handlers *data;
   char *message_type, *tmp_mtype;
   char *tmp;
   char *call_handler;
   SV *handler_return;

   assert(buf != NULL);
   perl_sess = sess;
   call_handler = malloc(strlen(buf)+50);
   assert(call_handler != NULL);
   tmp_mtype = strdup(buf);
   assert(tmp_mtype!=NULL);
   message_type = tmp_mtype;
   tmp = strchr(message_type, ' ');
   if (tmp) *tmp = 0;
   if (message_type[0] == ':') /* server message */
   {
      message_type = ++tmp;
      tmp = strchr(message_type, ' ');
      *tmp = 0;
   }

   for (handler = perl_inbound_handlers; handler != g_slist_last(perl_inbound_handlers); handler = handler->next)
   {
      data = handler->data;
      if (!strcmp(message_type, data->message_type))
      {
	 sprintf(call_handler, "&%s('%s')", data->handler_name, buf);
	 handler_return = perl_eval_pv(call_handler, TRUE);
	 if (SvIV(handler_return))
	 {
	    assert(tmp_mtype!=NULL);
	    assert(call_handler!=NULL);
	    free(tmp_mtype);
	    free(call_handler);
	    return SvIV(handler_return);
	 }

      }
	 
   }
   assert(tmp_mtype!=NULL);
   assert(call_handler!=NULL);
   free(tmp_mtype);
   free(call_handler);
   return 0;
}

int perl_command(char *cmd, struct session *sess)
{
   GSList *handler;
   struct _perl_command_handlers *data;
   char *command_name;
   char *tmp;
   char *call_handler;
   char *args;
   SV *handler_return;
   
   args = NULL;
   perl_sess = sess;
   call_handler = malloc(strlen(cmd)+50);
   command_name = strdup(cmd);
   tmp = strchr(command_name, ' ');
   if (tmp) 
   {
      *tmp = 0;
      args = ++tmp;
   }
   
   for (handler = perl_command_handlers; handler != g_slist_last(perl_command_handlers); handler = handler->next)
   {
      data = handler->data;
      if (!strcmp(command_name, data->command_name))
      {
	 sprintf(call_handler, "&%s('%s')", data->handler_name, args);
	 handler_return = perl_eval_pv(call_handler, TRUE);
	 if (SvIV(handler_return))
	 {
	    free(command_name);
	    free(call_handler);
	    return SvIV(handler_return);
	 }

      }
	 
   }

   free(command_name);
   free(call_handler);
   return 0;
}

/* custom IRC perl functions for scripting */

/* print to main window */
/* IRC::main_print(output) */
XS(XS_IRC_print)
{
   int junk;
   char *output;

   dXSARGS;
   output = SvPV(ST(0), junk);
   PrintText(perl_sess, output);
   XSRETURN_EMPTY;
}

/* add handler for messages with message_type(ie PRIVMSG, 400, etc) */
/* IRC::add_message_handler(message_type, handler_name) */
XS(XS_IRC_add_message_handler)
{
   int junk;
   struct _perl_inbound_handlers *handler;
   
   dXSARGS;
   handler = malloc(sizeof(struct _perl_inbound_handlers));
   handler->message_type = strdup(SvPV(ST(0), junk));
   handler->handler_name = strdup(SvPV(ST(1), junk));
   perl_inbound_handlers = g_slist_insert(perl_inbound_handlers, handler, 0);
   XSRETURN_EMPTY;
}

/* add handler for commands with command_name */
/* IRC::add_command_handler(command_name, handler_name) */
XS(XS_IRC_add_command_handler)
{
   int junk;
   struct _perl_command_handlers *handler;
   
   dXSARGS;
   handler = malloc(sizeof(struct _perl_command_handlers));
   handler->command_name = strdup(SvPV(ST(0), junk));
   handler->handler_name = strdup(SvPV(ST(1), junk));
   perl_command_handlers = g_slist_insert(perl_command_handlers, handler, 0);
   XSRETURN_EMPTY;
}

/* send raw data to server */
/* IRC::send_raw(data) */
XS(XS_IRC_send_raw)
{
   char *data;
   int junk;

   dXSARGS;
   data = strdup(SvPV(ST(0), junk));
   send(perl_sess->server->sok, data, strlen(data), 0); 
   free(data);
   XSRETURN_EMPTY;
}

/* run internal xchat command */
/* IRC::command(command) */
XS(XS_IRC_command)
{
   char *command;
   int junk;

   dXSARGS;
   command = strdup(SvPV(ST(0), junk));
   handle_command(command, perl_sess);
   free(command);
   XSRETURN_EMPTY;
}
#endif
