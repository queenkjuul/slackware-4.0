
#define STAT_QUEUED 0
#define STAT_ACTIVE 1
#define STAT_FAILED 2
#define STAT_DONE 3
#define STAT_CONNECTING 4
#define STAT_ABORTED 5

#define TYPE_SEND 0
#define TYPE_RECV 1
#define TYPE_CHATRECV 2
#define TYPE_CHATSEND 3
#define TYPE_DRAWRECV 4
#define TYPE_DRAWSEND 5

struct dccwindow
{
   GtkWidget *window;
   GtkWidget *list;
   gint selected;
};

struct dcc_send
{
   struct session *sess;
   char *nick;
   GtkWidget *freq;
};
