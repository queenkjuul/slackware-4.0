/*
Copyright (c) 1998 Peter Zelezny.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

#include "xchat.h"
#include <fcntl.h>
#include <pwd.h>
#include <sys/stat.h>


extern struct xchatprefs prefs;


char *get_home_dir(void)
{
   static char xdir[80];
   struct passwd *pw;
   pw = getpwuid(getuid());
   strcpy(xdir, pw->pw_dir);
   return(xdir);
}

char *get_xdir(void)
{
   static char xdir[88];
   struct passwd *pw;
   pw = getpwuid(getuid());
   sprintf(xdir, "%s/.xchat", pw->pw_dir);
   return(xdir);
}

void check_prefs_dir(void)
{
   struct stat st;
   char *xdir = get_xdir();
   if(stat(xdir, &st) < 0) mkdir(xdir, S_IRUSR | S_IWUSR | S_IXUSR);
}

char *default_file(void)
{
   static char file[128];
   struct passwd *pw;
   pw = getpwuid(getuid());
   sprintf(file, "%s/.xchat/xchat.cfg", pw->pw_dir);
   return(file);
}

void load_config(void)
{
   int fh;
#ifndef USE_GNOME
   char buf[128], *dir;
   dir = get_home_dir();
   sprintf(buf, "%s/.gtkrc", dir);
   gtk_rc_parse(buf);
#endif
   memset(&prefs, 0, sizeof(struct xchatprefs));

   fh = open(default_file(), O_RDONLY);
   if(fh != -1)
   {
      read(fh, &prefs, sizeof(struct xchatprefs));
      close(fh);
      prefs.away = FALSE;
   } else {
      struct passwd *pw = getpwuid(getuid());
      strcpy(prefs.nick1, pw->pw_name);
      strcpy(prefs.nick2, pw->pw_name); strcat(prefs.nick2, "_");
      strcpy(prefs.nick3, pw->pw_name); strcat(prefs.nick3, "__");
      strcpy(prefs.realname, pw->pw_name);
      strcpy(prefs.username, pw->pw_name);
      prefs.autosave = TRUE;
      prefs.autodialog = TRUE;
      prefs.autorejoin = TRUE;
      prefs.autoreconnect = TRUE;
      prefs.tabchannels = TRUE;
      prefs.bg_color = 1;
      prefs.dialog_bg_color = 1;
      strcpy(prefs.awayreason, "I'm busy");
      sprintf(prefs.quitreason, "%s has no reason", prefs.nick1);
      strcpy(prefs.font_normal, "-adobe-courier-medium-r-normal--*-120-*-*-*-*-*-*");
      strcpy(prefs.font_bold, "-adobe-courier-bold-r-normal--*-120-*-*-*-*-*-*");
      strcpy(prefs.dialog_font_normal, prefs.font_normal);
      strcpy(prefs.dialog_font_bold, prefs.font_bold);
   }
   if(prefs.sounddir[0] == 0) strcpy(prefs.sounddir, get_home_dir());
   if(prefs.soundcmd[0] == 0) strcpy(prefs.soundcmd, "play");
}

void save_config(void)
{
   int fh;

   check_prefs_dir();

   fh = open(default_file(), O_WRONLY | O_CREAT, 0600);
   if(fh != -1)
   {
      write(fh, &prefs, sizeof(struct xchatprefs));
      close(fh);
   }
}
