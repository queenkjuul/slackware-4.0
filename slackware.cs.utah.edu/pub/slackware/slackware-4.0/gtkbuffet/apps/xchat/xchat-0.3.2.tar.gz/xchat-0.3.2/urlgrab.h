struct url
{
   struct url *next;
   char used;
   char misc;
   char urltext[256];
};
