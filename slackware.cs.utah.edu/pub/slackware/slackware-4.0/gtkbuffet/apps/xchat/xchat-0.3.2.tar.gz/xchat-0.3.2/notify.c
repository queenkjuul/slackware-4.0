/*
Copyright (c) 1998 Peter Zelezny.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

#include "xchat.h"
#include "notify.h"
#include "style.h"


extern void PrintText(struct session *sess, unsigned char *text);

extern GSList *serv_list;

long notify_selected = -1;
GSList *notify_list = 0;
GtkWidget *notify_window = 0;
GtkWidget *notify_guilist;

int notify_deluser(char *name);


void notify_closegui(void)
{
   if(notify_window)
   {
      gtk_widget_destroy(notify_window);
      notify_window = 0;
   }
}

void notify_gui_update(void)
{
   struct notify *notify;
   GSList *list = notify_list;
   gchar *new[1][3];

   if(!notify_window) return;

   gtk_clist_clear((GtkCList*)notify_guilist);
   while(list)
   {
      notify = (struct notify *)list->data;
      new[0][0] = notify->name;
      if(notify->ison)
	new[0][1] = "Online";
      else
	new[0][1] = "Offline";
      if(notify->servername[0])
	new[0][2] = notify->servername;
      else
	new[0][2] = "-";
      gtk_clist_append((GtkCList*)notify_guilist, new[0]);
      list = list->next;
   }
   //if(dccrwin.selected != -1)
     //gtk_clist_select_row((GtkCList*)dccrwin.list, dccrwin.selected, 0);
}

void notify_remove_clicked(GtkWidget *igad)
{
   if(notify_selected != -1)
   {
      char *name;
      gtk_clist_get_text(GTK_CLIST(notify_guilist), notify_selected, 0, &name);
      notify_deluser(name);
   }
}

void notify_row_selected(GtkWidget *clist, gint row, gint column,
		       GdkEventButton *even, gpointer none)
{
   if(none == 0)
     notify_selected = row;
   else
     notify_selected = -1;
}

void notify_opengui(void)
{
   GtkWidget *vbox, *bbox;
   GtkWidget *Remove;
#ifdef GTK_113
   GtkWidget *scrollwin;
#endif
   static gchar *titles[] = { "User", "Status", "Server" };

   if(notify_window)
   {
      notify_closegui();
      return;
   }
   
   notify_selected = -1;

   notify_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
   gtk_widget_set_usize(notify_window, 400, 120);
   gtk_window_set_title(GTK_WINDOW(notify_window), "X-Chat: Notify List");
   gtk_signal_connect(GTK_OBJECT(notify_window), "destroy",
                             GTK_SIGNAL_FUNC(notify_closegui), 0);

   vbox = gtk_vbox_new(FALSE, 0);
   gtk_container_border_width(GTK_CONTAINER(vbox), 4);
   gtk_container_add(GTK_CONTAINER(notify_window), vbox);
   gtk_widget_show(vbox);

#ifdef GTK_113
   scrollwin = gtk_scrolled_window_new(NULL, NULL); 
#endif
   notify_guilist = gtk_clist_new_with_titles(3, titles);
   gtk_signal_connect(GTK_OBJECT(notify_guilist),
		      "select_row", GTK_SIGNAL_FUNC(notify_row_selected), 0);
   gtk_signal_connect(GTK_OBJECT(notify_guilist),
		      "unselect_row", GTK_SIGNAL_FUNC(notify_row_selected), (gpointer)1);
   gtk_clist_set_border(GTK_CLIST(notify_guilist), GTK_SHADOW_OUT);
   gtk_clist_set_column_width(GTK_CLIST(notify_guilist), 0, 100);
   gtk_clist_set_column_width(GTK_CLIST(notify_guilist), 1, 60);
   gtk_clist_set_column_width(GTK_CLIST(notify_guilist), 2, 100);
#ifdef GTK_113
   gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrollwin), 
				  GTK_POLICY_AUTOMATIC,
				  GTK_POLICY_ALWAYS);
   gtk_container_add(GTK_CONTAINER(vbox), scrollwin);
   gtk_container_add(GTK_CONTAINER(scrollwin), notify_guilist); 
   gtk_widget_show(notify_guilist);
   gtk_widget_show(scrollwin);
#else
   gtk_clist_set_policy(GTK_CLIST(notify_guilist), GTK_POLICY_AUTOMATIC,
			      GTK_POLICY_AUTOMATIC);
   gtk_container_add(GTK_CONTAINER(vbox), notify_guilist); 
   gtk_widget_show(notify_guilist);
#endif

   bbox = gtk_hbox_new(FALSE, 0);
   gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 0);
   gtk_widget_show(bbox);

   /*Add = gtk_button_new_with_label("Add");
   gtk_signal_connect(GTK_OBJECT(Add), "clicked",
		      GTK_SIGNAL_FUNC(notify_add_clicked), 0);
   gtk_container_add(GTK_CONTAINER(bbox), Add);
   gtk_widget_show(Add);*/

   Remove = gtk_button_new_with_label("Remove");
   gtk_signal_connect(GTK_OBJECT(Remove), "clicked",
		      GTK_SIGNAL_FUNC(notify_remove_clicked), 0);
   gtk_container_add(GTK_CONTAINER(bbox), Remove); 
   gtk_widget_show(Remove);

   gtk_widget_show(notify_window);

   notify_gui_update();
}

void notify_markonline(struct session *sess, char *outbuf, char *word[])
{
   struct notify *notify;
   GSList *list = notify_list;
   int i, j;

   while(list)
   {
      notify = (struct notify *)list->data;
      i = 4;
      j = 0;
      while(*word[i])
      {	
	 if(!strcasecmp(notify->name, word[i]))
	 {
	    j++;
	    notify->checking = FALSE;
	    if(!notify->ison)
	    {
	       notify->ison = TRUE;
	       strcpy(notify->servername, sess->server->servername);
	       sprintf(outbuf, STARTON" Notify: %s is online.\n", notify->name);
	       PrintText(sess, outbuf);
	    }
	    break;
	 }
	 i++;
      }
      list = list->next;
   }
   notify_gui_update();
}

void notify_checklist(void)
{
   char *outbuf = malloc(4096);
   struct server *serv;
   struct notify *notify;
   GSList *list = notify_list;
   int i = 0;

   strcpy(outbuf, "ISON ");
   while(list)
   {
      i++;
      notify = (struct notify *)list->data;
      if(notify->checking) notify->ison = FALSE;
      notify->checking = TRUE;
      strcat(outbuf, notify->name);
      strcat(outbuf, " ");
      list = list->next;
   }
   if(i)
   {
      GSList *list = serv_list;
      strcat(outbuf, "\r\n");
      while(list)
      {
	 serv = (struct server *)list->data;
	 if(serv->flags&(1<<0)) // if CONNECTED
	    send(serv->sok, outbuf, strlen(outbuf), 0);
	 list = list->next;
      }
   }
   free(outbuf);
}

void notify_showlist(struct session *sess)
{
   char outbuf[256];
   struct notify *notify;
   GSList *list = notify_list;
   int i = 0;
   PrintText(sess, STARTON" \00308,02 \002-- Notify List --------------- \n");
   while(list)
   {
      i++;
      notify = (struct notify *)list->data;
      if(notify->ison)
      	sprintf(outbuf, STARTON"   %-20s online\n", notify->name);
      else
	sprintf(outbuf, STARTON"   %-20s offline\n", notify->name);
      PrintText(sess, outbuf);
      list = list->next;
   }
   if(i)
   {
     sprintf(outbuf, STARTON" %d users in notify list.\n", i);
     PrintText(sess, outbuf);
   } else
     PrintText(sess, STARTON" Notify list is empty.\n");
}

/*void notify_clearlist(void)
{
   struct notify *notify;
   GSList *list = notify_list;
   while(list)
   {
      notify = (struct notify *)list->data;
      free(notify);
      notify_list = g_slist_remove(notify_list, list);
      list = list->next;
   }
   notify_list = 0;
   notify_gui_update();
}*/

int notify_deluser(char *name)
{
   struct notify *notify;
   GSList *list = notify_list;
   while(list)
   {
      notify = (struct notify *)list->data;
      if(!strcasecmp(notify->name, name))
      {
	 notify_list = g_slist_remove(notify_list, notify);
	 free(notify);
	 notify_gui_update();
	 return 1;
      }
      list = list->next;
   }
   return 0;
}

void notify_adduser(char *name)
{
   struct notify *notify = malloc(sizeof(struct notify));
   if(notify)
   {
      notify->servername[0] = 0;
      notify->ison = FALSE;
      notify->checking = FALSE;
      strcpy(notify->name, name);
      notify_list = g_slist_append(notify_list, notify);
      notify_checklist();
      notify_gui_update();
   }
}
