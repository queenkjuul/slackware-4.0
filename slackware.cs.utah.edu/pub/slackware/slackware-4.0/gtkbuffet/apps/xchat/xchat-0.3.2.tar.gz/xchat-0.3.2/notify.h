struct notify
{
   char name[64];
   char servername[72];
   int ison:1;
   int checking:1;
};

