/*
Copyright (c) 1998 Peter Zelezny.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

#include "xchat.h"
#include <fcntl.h>
#include <sys/utsname.h>

extern struct session *current_tab;
extern struct xchatprefs prefs;
extern struct session firstsession;

typedef void (*menucallback) (GtkWidget *wid, gpointer data);

#define M_MENU 0
#define M_NEWMENURIGHT 6
#define M_MENUD 5
#define M_NEWMENU 1
#define M_END 2
#define M_SEP 3
#define M_MENUTOG 4

struct mymenu
{
   int type;
   char *text;
   menucallback callback;
   int state;
   int activate;
};

extern void notify_opengui(void);
extern void chanlist_opengui(struct server *serv);
extern void url_opengui(GtkWidget *, gpointer);
extern void cmd_help(struct session *sess, char *tbuf, char *word[], char *word_eol[]);
extern void xchat_cleanup(GtkWidget *wid, gpointer sess);
extern struct server *new_server(void);
extern struct session *new_session(struct server *, char *);
extern void PrintText(struct session *, char *);
extern void open_rawlog(struct server *);
extern void open_dcc_recv_window(GtkWidget *wid, gpointer sess);
extern void open_dcc_send_window(GtkWidget *wid, gpointer sess);
extern void open_dcc_chat_window(GtkWidget *wid, gpointer sess);
extern void open_server_list(GtkWidget *wid, gpointer sess);
extern void save_config(void);
extern void load_config(void);
extern void settings_opengui(struct session *sess);
extern void show_lastlog_window(void);
extern void search_lastlog(struct session *_sess, char *search);

struct session *menu_sess = 0;

void menu_open_server_list(GtkWidget *wid, gpointer none)
{
   open_server_list(0, menu_sess);
}

void menu_lastlog(GtkWidget *wid, gpointer none)
{
   show_lastlog_window();
   search_lastlog(menu_sess, NULL);
}

void menu_settings(GtkWidget *wid, gpointer sess)
{
   settings_opengui(menu_sess);
}

void menu_newserver(GtkWidget *wid, gpointer sess)
{
   struct server *serv = new_server();
   if(serv) new_session(serv, 0);
}

void menu_newchannel(GtkWidget *wid, gpointer sess)
{
   new_session(menu_sess->server, 0);
}

void menu_rawlog(GtkWidget *wid, gpointer sess)
{
   open_rawlog(menu_sess->server);
}

void menu_autorejoin(GtkWidget *wid, gpointer sess)
{
   prefs.autorejoin = !prefs.autorejoin;
}

void menu_autoreconnect(GtkWidget *wid, gpointer sess)
{
   prefs.autoreconnect = !prefs.autoreconnect;
}

void menu_autodialog(GtkWidget *wid, gpointer sess)
{
   prefs.autodialog = !prefs.autodialog;
}

void menu_saveexit(GtkWidget *wid, gpointer sess)
{
   prefs.autosave = !prefs.autosave;
}

void menu_close(GtkWidget *wid, gpointer sess)
{
   gtk_widget_destroy(menu_sess->window);
}

void menu_flushbuffer(GtkWidget *wid, gpointer sess)
{
   gtk_text_backward_delete((GtkText *)menu_sess->textgad,
			    gtk_text_get_length((GtkText *)((struct session *)menu_sess)->textgad));
}

GtkWidget *freq = 0;

void close_savebuffer(void)
{
   gtk_widget_destroy(freq);
   freq = 0;
}

void savebuffer_req_done(GtkWidget *wid, struct session *sess)
{
   int fh;
   char file[128];
   strcpy(file, gtk_file_selection_get_filename(GTK_FILE_SELECTION(freq)));
   close_savebuffer();

   fh = open(file, O_WRONLY | O_CREAT, 0600);
   if(fh != -1)
   {
      char *buf = gtk_editable_get_chars((GtkEditable*)sess->textgad, 0, -1);
      write(fh, buf, strlen(buf));
      g_free(buf);
      close(fh);
   }
}

void menu_savebuffer(GtkWidget *wid, gpointer sess)
{
   if(freq) close_savebuffer();
   freq = gtk_file_selection_new("Save review buffer");
   gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(freq)->cancel_button),
			     "clicked", (GtkSignalFunc) close_savebuffer, 0);
   gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(freq)->ok_button),
		      "clicked", (GtkSignalFunc) savebuffer_req_done, menu_sess);
   gtk_widget_show(freq);
}

void menu_wallops(GtkWidget *wid, gpointer sess)
{
   char tbuf[128];
   prefs.wallops = !prefs.wallops;
   if(((struct session *)menu_sess)->server->flags&(1<<0))
   {
      if(prefs.wallops)
        sprintf(tbuf, "MODE %s +w\r\n", ((struct session *)menu_sess)->server->nick);
      else
        sprintf(tbuf, "MODE %s -w\r\n", ((struct session *)menu_sess)->server->nick);
      send(((struct session *)menu_sess)->server->sok, tbuf, strlen(tbuf), 0);
   }
}

void menu_servernotice(GtkWidget *wid, gpointer sess)
{
   char tbuf[128];
   prefs.servernotice = !prefs.servernotice;
   if(((struct session *)menu_sess)->server->flags&(1<<0))
   {
      if(prefs.servernotice)
        sprintf(tbuf, "MODE %s +s\r\n", ((struct session *)menu_sess)->server->nick);
      else
        sprintf(tbuf, "MODE %s -s\r\n", ((struct session *)menu_sess)->server->nick);
      send(((struct session *)menu_sess)->server->sok, tbuf, strlen(tbuf), 0);
   }
}

void menu_away(GtkWidget *wid, gpointer sess)
{
   char tbuf[128];
   prefs.away = !prefs.away;
   if(((struct session *)menu_sess)->server->flags&(1<<0))
   {
      if(prefs.away)
      {
	 sprintf(tbuf, "AWAY :%s\r\n", prefs.awayreason);
	 send(((struct session *)menu_sess)->server->sok, tbuf, strlen(tbuf), 0);
      } else
	send(((struct session *)menu_sess)->server->sok, "AWAY\r\n", 6, 0);
   }
}

void menu_invisible(GtkWidget *wid, gpointer sess)
{
   char tbuf[128];
   prefs.invisible = !prefs.invisible;
   if(((struct session *)menu_sess)->server->flags&(1<<0))
   {
      if(prefs.invisible)
        sprintf(tbuf, "MODE %s +i\r\n", ((struct session *)menu_sess)->server->nick);
      else
        sprintf(tbuf, "MODE %s -i\r\n", ((struct session *)menu_sess)->server->nick);
      send(((struct session *)menu_sess)->server->sok, tbuf, strlen(tbuf), 0);
   }
}

void menu_help(GtkWidget *wid, gpointer sess)
{
   cmd_help(menu_sess, 0, 0, 0);
}

GtkWidget *about = 0;

void about_close(void)
{
   gtk_widget_destroy(about);
   about = 0;
}

void menu_savedefault(GtkWidget *wid, gpointer sess)
{
   save_config();
}

void menu_chanlist(GtkWidget *wid, gpointer sess)
{
   chanlist_opengui(((struct session *)menu_sess)->server);
}

void goto_url()
{
   popen("netscape -remote 'openURL(http://xchat.elitenet.org)'", "r"); 
}

void menu_about(GtkWidget *wid, gpointer sess)
{
   char buf[256];
   struct utsname un;

#ifdef USE_GNOME
   const gchar *author[] = { "Peter Zelezny <zed@mentasm.com>", 0 };
   uname(&un);
   sprintf(buf,            "Started on ..\t:\t27-July-1998\n"
			   "Web Page ....\t:\thttp://xchat.elitenet.org\n"
			   "Running on ..\t:\t%s %s\n", un.sysname, un.release);
   
   about = gnome_about_new("X-Chat",
			   VERSION,
			   "(C) 1998 Peter Zelezny",
			   author,
			   buf,
			   0);
   gtk_widget_show(about);
#else
   GtkWidget *label, *button;

   if(about) gtk_widget_destroy(about);

   uname(&un);

   about = gtk_dialog_new();
   gtk_window_position (GTK_WINDOW(about), GTK_WIN_POS_CENTER);
   gtk_window_set_title(GTK_WINDOW(about), "About X-Chat");

   sprintf(buf, "X-Chat "VERSION" by Peter Zelezny\n\n"
		"X-Chat was started on 27-Jun-1998\n\n"
	        "Author EMail: zed@mentasm.com\n\n"
		"Currently running on %s %s",
	        un.sysname, un.release);
   label = gtk_label_new(buf);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(about)->vbox), 10);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(about)->vbox), label, TRUE, TRUE, 10);
   gtk_widget_show(label);

   button = gtk_button_new_with_label("http://xchat.elitenet.org");
   gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC (goto_url), 0);
   gtk_box_pack_end(GTK_BOX(GTK_DIALOG(about)->vbox), button, TRUE, TRUE, 10);
   gtk_widget_show(button);

   button = gtk_button_new_with_label ("Ok");
   GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
   gtk_box_pack_start (GTK_BOX (GTK_DIALOG(about)->action_area), button, TRUE, TRUE, 10);
   gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC (about_close), 0);
   gtk_widget_grab_default (button);
   gtk_widget_show (button);

   gtk_widget_show(about);
#endif
}


GtkWidget *contrib = 0;

void contrib_close(void)
{
   if(contrib)
   {
      gtk_widget_destroy(contrib);
      contrib = 0;
   }
}

struct con
{
   gchar *name;
   gchar *help;
};

struct con con[] =
{
   {"Alien",             "Tabbed Nicks"},
   {"Fredrik Lindfeldt", "Configure script"},
   {"Fraser McCrossan",  "CTCP Sounds"},
   {"Erik Scrafford",    "Colored Nicks, Perl Scripting"},
   {"Shaleh",            "Getting X-Chat to Debian :)"},
   {"",                  ""},
   {"",                  "Anyone I forgot? Let me know"},
   {0, 0}
};

void menu_contrib(GtkWidget *none, gpointer sess)
{
   static gchar *titles[] = { "Name", "Helped with" };
   GtkWidget *button, *wid;
   
   if(contrib) contrib_close();

   contrib = gtk_dialog_new();
   gtk_widget_set_usize(contrib, 350, 250);
   gtk_window_position (GTK_WINDOW(contrib), GTK_WIN_POS_CENTER);
   gtk_window_set_title(GTK_WINDOW(contrib), "X-Chat Contributors");

   wid = gtk_clist_new_with_titles(2, titles);
   gtk_clist_set_column_width(GTK_CLIST(wid), 0, 120);
   gtk_clist_set_policy(GTK_CLIST(wid), GTK_POLICY_AUTOMATIC,
			      GTK_POLICY_AUTOMATIC);
   gtk_box_pack_end(GTK_BOX(GTK_DIALOG(contrib)->vbox), wid, TRUE, TRUE, 10);
   gtk_widget_show(wid);

#ifdef USE_GNOME
   button = gnome_stock_button(GNOME_STOCK_BUTTON_OK);
#else
   button = gtk_button_new_with_label ("Ok");
#endif
   GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX (GTK_DIALOG(contrib)->action_area), button, TRUE, TRUE, 10);
   gtk_signal_connect_object(GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC (contrib_close), 0);
   gtk_widget_grab_default(button);
   gtk_widget_show(button);

   {
      gchar *new[1][2];
      int i = 0;
      while(con[i].name)
      {
	 new[0][0] = con[i].name;
	 new[0][1] = con[i].help;
	 gtk_clist_append(GTK_CLIST(wid), new[0]);
	 i++;
      }
   }

   gtk_widget_show(contrib);
}

#ifdef USE_GNOME

GnomeUIInfo xchatmenu[] =
{
     {
	GNOME_APP_UI_ITEM,
	N_("Server List.."), 0,
	menu_open_server_list, 0, 0,
	GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_BOOK_RED,
	0, 0, 0
     },
     {
	GNOME_APP_UI_ITEM,
	N_("New Channel Window.."), N_(""),
	menu_newchannel, 0, 0,
	GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_NEW,
	0, 0, 0
     },
     {
	GNOME_APP_UI_ITEM,
	N_("New Server Window.."), 0,
	menu_newserver, 0, 0,
	GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_NEW,
	0, 0, 0
     },
     GNOMEUIINFO_SEPARATOR,
     {
	GNOME_APP_UI_ITEM,
	N_("Close"), 0,
	menu_close, 0, 0,
	GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_CLOSE,
	0, 0, 0
     },
     GNOMEUIINFO_SEPARATOR,
     {
	GNOME_APP_UI_ITEM,
	N_("Quit"), 0,
	xchat_cleanup, 0, 0,
	GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_QUIT,
	0, 0, 0
     },
     GNOMEUIINFO_END
};

GnomeUIInfo windowsmenu[] =
{
   {
      GNOME_APP_UI_ITEM,
      N_("Channel List Window.."), 0,
      menu_chanlist
   },   
   {
      GNOME_APP_UI_ITEM,
      N_("DCC Send Window.."), 0,
      open_dcc_send_window, 0, 0, 0, 0, 0, 0, 0
   },
   {
      GNOME_APP_UI_ITEM,
      N_("DCC Receive Window.."), 0,
      open_dcc_recv_window, 0, 0, 0, 0, 0, 0, 0
   },
   {
      GNOME_APP_UI_ITEM,
      N_("DCC Chat Window.."), 0,
      open_dcc_chat_window, 0, 0, 0, 0, 0, 0, 0
   },
   {
      GNOME_APP_UI_ITEM,
      N_("Raw Log Window.."), 0,
      menu_rawlog, 0, 0, 0, 0, 0, 0, 0
   },
   {
      GNOME_APP_UI_ITEM,
      N_("URL Grabber Window.."), 0,
      url_opengui, 0, 0, 0, 0, 0, 0, 0
   },
   {
      GNOME_APP_UI_ITEM,
      N_("Notify List Window.."), 0,
      (menucallback)notify_opengui, 0, 0, 0, 0, 0, 0, 0
   },
   {
      GNOME_APP_UI_ITEM,
      N_("Lastlog Window.."), 0,
      menu_lastlog, 0, 0, 0, 0, 0, 0, 0
   },
   GNOMEUIINFO_SEPARATOR,
   {
      GNOME_APP_UI_ITEM,
      N_("Flush Buffer"), 0,
      menu_flushbuffer, 0, 0, GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_TRASH, 0, 0, 0
   },
   {
      GNOME_APP_UI_ITEM,
      N_("Save Buffer.."), 0,
      menu_savebuffer, 0, 0, GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_SAVE, 0, 0, 0
   },
   GNOMEUIINFO_END
};

GnomeUIInfo usermodesmenu[] =
{
   {
      GNOME_APP_UI_TOGGLEITEM,
      N_("Invisible"), 0,
      menu_invisible, 0, 0, 0, 0, 0, 0, 0
   },
   {
      GNOME_APP_UI_TOGGLEITEM,
      N_("Receive Wallops"), 0,
      menu_wallops, 0, 0, GNOME_APP_PIXMAP_NONE, 0, 0, 0, 0
   },
      {
      GNOME_APP_UI_TOGGLEITEM,
      N_("Receive Server Notices"), 0,
      menu_servernotice, 0, 0, 0, 0, 0, 0, 0
   },
   GNOMEUIINFO_SEPARATOR,
   {
      GNOME_APP_UI_TOGGLEITEM,
      N_("Marked Away"), 0,
      menu_away, 0, 0, GNOME_APP_PIXMAP_NONE, 0, 0, 0, 0
   },
   GNOMEUIINFO_SEPARATOR,
   {
      GNOME_APP_UI_TOGGLEITEM,
      N_("Auto Rejoin on Kick"), 0,
      menu_autorejoin, 0, 0, 0, 0, 0, 0, 0
   },
   {
      GNOME_APP_UI_TOGGLEITEM,
      N_("Auto ReConnect to Server"), 0,
      menu_autoreconnect, 0, 0, GNOME_APP_PIXMAP_NONE, 0, 0, 0, 0
   },
   GNOMEUIINFO_SEPARATOR,
   {
      GNOME_APP_UI_TOGGLEITEM,
      N_("Auto Open Dialog Windows"), 0,
      menu_autodialog, 0, 0, 0, 0, 0, 0, 0
   },
   GNOMEUIINFO_END
};

GnomeUIInfo settingsmenu[] =
{
   {
      GNOME_APP_UI_ITEM,
      N_("Setup.."), 0,
      menu_settings, 0, 0,
      GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_PREF,
      0, 0, 0
   },
   GNOMEUIINFO_SEPARATOR,
   {
      GNOME_APP_UI_ITEM,
      N_("Save Settings now"), 0,
      menu_savedefault, 0, 0,
      GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_SAVE,
      0, 0, 0
   },
   {
      GNOME_APP_UI_TOGGLEITEM,
      N_("Save Settings on exit"), 0,
      menu_saveexit, 0, 0,
      GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_SAVE,
      0, 0, 0
   },
   GNOMEUIINFO_END
};

GnomeUIInfo helpmenu[] =
{
   {
      GNOME_APP_UI_ITEM,
      N_("Help.."), 0,
      menu_help, 0, 0,
      GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_PIXMAP_HELP,
      0, 0, 0
   },
   GNOMEUIINFO_SEPARATOR,
   {
      GNOME_APP_UI_ITEM,
      N_("Contributors.."), 0,
      menu_contrib, 0, 0,
      GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_SEARCH,
      0, 0, 0
   },
   GNOMEUIINFO_SEPARATOR,
   {
      GNOME_APP_UI_ITEM,
      N_("About X-Chat.."), 0,
      menu_about, 0, 0,
      GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_ABOUT,
      0, 0, 0
   },
   GNOMEUIINFO_END
};

GnomeUIInfo mainmenu[] =
{
   GNOMEUIINFO_SUBTREE(N_("X-Chat"), xchatmenu), 
   GNOMEUIINFO_SUBTREE(N_("Windows"), windowsmenu), 
   GNOMEUIINFO_SUBTREE(N_("User Modes"), usermodesmenu),
   GNOMEUIINFO_SUBTREE(N_("Settings"), settingsmenu),
   GNOMEUIINFO_SUBTREE(N_("Help"), helpmenu),
   GNOMEUIINFO_END
};

void createmenus(void *app, struct session *sess)
{
   if(!menu_sess) menu_sess = sess;
   gnome_app_create_menus(GNOME_APP(app), mainmenu);
   gtk_menu_item_right_justify(GTK_MENU_ITEM(mainmenu[4].widget));

   /* is it legal to poke in the initial values?? */
   ((GtkCheckMenuItem*)(usermodesmenu[0].widget))->active = prefs.invisible;
   ((GtkCheckMenuItem*)(usermodesmenu[1].widget))->active = prefs.wallops;
   ((GtkCheckMenuItem*)(usermodesmenu[2].widget))->active = prefs.servernotice;
   ((GtkCheckMenuItem*)(usermodesmenu[4].widget))->active = prefs.away;
   ((GtkCheckMenuItem*)(usermodesmenu[6].widget))->active = prefs.autorejoin;
   ((GtkCheckMenuItem*)(usermodesmenu[7].widget))->active = prefs.autoreconnect;
   ((GtkCheckMenuItem*)(usermodesmenu[9].widget))->active = prefs.autodialog;
   ((GtkCheckMenuItem*)(settingsmenu[3].widget))->active = prefs.autosave;
}

#else
static struct mymenu mymenu[] =
{
     {M_NEWMENU, "X-Chat", 0,0,1},
     {M_MENU, "Server List..", menu_open_server_list, 0, 1},
     {M_MENU, "New Server Window..", menu_newserver,0,1},
     {M_MENU, "New Channel Window..", menu_newchannel,0,1},
     {M_SEP, 0, 0,0,0},
     {M_MENU, "Close", menu_close,0,1},
     {M_SEP, 0, 0,0,0},
     {M_MENU, "Quit", xchat_cleanup,0,1}, /* 7 */
     
     {M_NEWMENU, "Windows", 0,0,1},
     {M_MENU, "Channel List Window..", menu_chanlist,0,1},
     {M_MENU, "DCC Send Window..", open_dcc_send_window,0,1},
     {M_MENU, "DCC Receive Window..", open_dcc_recv_window,0,1},
     {M_MENU, "DCC Chat Window..", open_dcc_chat_window,0,1},
     {M_MENU, "Raw Log Window..", menu_rawlog,0,1},
     {M_MENU, "URL Grabber Window..", url_opengui,0,1},
     {M_MENU, "Notify List Window..", (menucallback)notify_opengui,0,1},
     {M_MENU, "Lastlog Window..", menu_lastlog,0,1},
     {M_SEP, 0, 0,0,0},
     {M_MENU, "Flush Buffer", menu_flushbuffer,0,1},
     {M_MENU, "Save Buffer..", menu_savebuffer,0,1}, /* 19 */
     
     {M_NEWMENU, "User Modes", 0,0,1},
     {M_MENUTOG, "Invisible", menu_invisible,1,1},
     {M_MENUTOG, "Receive Wallops", menu_wallops,1,1},
     {M_MENUTOG, "Receive Server Notices", menu_servernotice,1,1},
     {M_SEP, 0, 0,0,0},
     {M_MENUTOG, "Marked Away", menu_away,0,1},
     {M_SEP, 0, 0,0},
     {M_MENUTOG, "Auto ReJoin on Kick", menu_autorejoin,0,1},
     {M_MENUTOG, "Auto ReConnect to Server", menu_autoreconnect,0,1},
     {M_SEP, 0, 0,0},
     {M_MENUTOG, "Auto Open Dialog Windows", menu_autodialog,0,1}, /* 30 */
     /*{M_MENUTOG, "Auto Accept DCC Chat", 0,0,0},   
     {M_MENUTOG, "Do BEEP Sounds", 0,0,0},
     {M_MENUTOG, "Play CTCP Sounds", 0,0,0},*/  

     {M_NEWMENU, "Settings", 0,0,1}, 
     {M_MENU, "Setup..", menu_settings,0,1},
/*     {M_MENU, "Lists..", 0,0,0},
     {M_MENU, "Function Keys..", 0,0,0},*/
     {M_SEP, 0, 0,0,0},
     {M_MENU, "Save Settings now", menu_savedefault,0,1},
     {M_MENUTOG, "Save Settings on exit", menu_saveexit,1,1}, 

     {M_NEWMENURIGHT, "Help", 0, 0, 1},
     {M_MENU, "Help..", menu_help, 0, 1},
     {M_SEP, 0, 0,0,0},
     {M_MENU, "Contributors..", menu_contrib, 0, 1},
     {M_SEP, 0, 0,0,0},
     {M_MENU, "About X-Chat..", menu_about, 0, 1},

     {M_END, 0, 0,0,0},
};


GtkWidget *createmenus(struct session *sess)
{
   int i = 0;
   GtkWidget *item;
   GtkWidget *menu = 0;
   GtkWidget *menu_item = 0;
   GtkWidget *menu_bar = gtk_menu_bar_new();
   
   if(!menu_sess) menu_sess = sess;

   mymenu[21].state = prefs.invisible;
   mymenu[22].state = prefs.wallops;
   mymenu[23].state = prefs.servernotice;
   mymenu[27].state = prefs.autorejoin;
   mymenu[28].state = prefs.autoreconnect;
   mymenu[30].state = prefs.autodialog;
   mymenu[35].state = prefs.autosave;

   while(1)
   {
      switch(mymenu[i].type)
      {
       case M_NEWMENURIGHT:
       case M_NEWMENU:
	 if(menu) gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu_item), menu);
	 menu = gtk_menu_new();
	 menu_item = gtk_menu_item_new_with_label(mymenu[i].text);
	 if(mymenu[i].type == M_NEWMENURIGHT)
	   gtk_menu_item_right_justify((GtkMenuItem*)menu_item);
	 gtk_menu_bar_append(GTK_MENU_BAR(menu_bar), menu_item);
	 gtk_widget_show(menu_item);
	 break;
       case M_MENU:
	 item = gtk_menu_item_new_with_label(mymenu[i].text);
	 if(mymenu[i].callback)
	   gtk_signal_connect_object(GTK_OBJECT(item), "activate",
				     GTK_SIGNAL_FUNC(mymenu[i].callback), (gpointer)sess);
	 gtk_menu_append(GTK_MENU(menu), item);
	 gtk_widget_show(item);
	 gtk_widget_set_sensitive(item, mymenu[i].activate);
	 break;
       case M_MENUTOG:
	 item = gtk_check_menu_item_new_with_label(mymenu[i].text);
	 gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(item), mymenu[i].state);
	 if(mymenu[i].callback)
	   gtk_signal_connect_object(GTK_OBJECT(item), "toggled",
				     GTK_SIGNAL_FUNC(mymenu[i].callback), (gpointer)sess);
	 gtk_menu_append(GTK_MENU(menu), item);
	 gtk_widget_show(item);
	 gtk_widget_set_sensitive(item, mymenu[i].activate);
	 break;
       case M_SEP:
	 item = gtk_menu_item_new();
	 gtk_widget_set_sensitive(item, FALSE);
	 gtk_menu_append(GTK_MENU(menu), item);
	 gtk_widget_show(item);	 
	 break;
       case M_END:
	 if(menu) gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu_item), menu);
	 return(menu_bar);
      }
      i++;
   }
}
#endif
