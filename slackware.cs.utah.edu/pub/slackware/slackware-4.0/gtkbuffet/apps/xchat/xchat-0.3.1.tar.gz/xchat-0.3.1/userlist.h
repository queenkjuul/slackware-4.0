struct user
{
   struct user *next;
   char user[64];
   char op;
   char voice;
};
