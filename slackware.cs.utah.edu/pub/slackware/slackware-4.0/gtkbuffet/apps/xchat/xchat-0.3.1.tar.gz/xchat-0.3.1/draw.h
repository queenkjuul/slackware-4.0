struct xchatpixel
{
   unsigned int x:16;
   unsigned int y:16;
};

struct dccdraw
{
   GtkWidget *window;
   GtkWidget *drawing_area;
   GdkPixmap *pixmap;
};
