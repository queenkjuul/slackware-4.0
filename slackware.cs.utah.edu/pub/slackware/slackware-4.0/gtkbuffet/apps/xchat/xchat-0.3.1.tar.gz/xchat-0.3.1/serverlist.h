struct serverentry
{
   char used;
   char unused;
   struct serverentry *next;
   long port;
   char channel[86];
   char server[100];
   char password[86];
   char comment[100];
   char future[102];
};

struct defaultserv
{
   char *channel;
   char *server;
   char *comment;
   long port;
};
