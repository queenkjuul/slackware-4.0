/*
  GNOME Disk Catalog
  Copyright (C) 1999 Tero Koskinen

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

#include <stdio.h>
#include <config.h>

#include <gtk/gtk.h>
#include <gnome.h>

#include "app.hh"
#include "tkstring.hh"

/* static error_t parse_an_arg(int ,char *,struct argp_state *)
{
  return 0;
  } */

/* static struct argp parser =
{
    NULL,parse_an_arg,NULL,NULL,NULL,NULL
    }; */

extern CatalogMainWindow *app;

static void session_die (gpointer /* client_data */)
{
  gtk_main_quit ();
}

static int save_state (GnomeClient        *client,
		       gint                /* phase */,
		       GnomeRestartStyle   /* save_style */,
		       gint                /* shutdown */ ,
		       GnomeInteractStyle  /* interact_style */,
		       gint                /* fast */,
		       gpointer            /* client_data */ )
{
  gchar *sess_id;
  gchar *argv[3];
  // gchar *s;
  // gint j;
  // gint xpos, ypos;
  gint argc=0;
  // gint xsize, ysize;
  gint x,y,w,h;

  gdk_window_get_geometry (app->app->window, &x, &y, &w, &h, NULL);

  gnome_config_push_prefix (gnome_client_get_config_prefix (client));
  gnome_config_set_int ("Geometry/x", x);
  gnome_config_set_int ("Geometry/y", y);
  gnome_config_set_int ("Geometry/w", w);
  gnome_config_set_int ("Geometry/h", h);

  gnome_config_pop_prefix ();
  gnome_config_sync();

  sess_id=gnome_client_get_id(client);
  // gdk_window_get_origin(wi.window, &xpos, &ypos);
  // gdk_window_get_size(wi.window, &xsize, &ysize);
	
  // argv[0] = (char *)client_data;
  argc=3;

  argv[0] = program_invocation_name;
  argv[1] = "--discard-session";
  argv[2] = gnome_client_get_config_prefix (client);
  gnome_client_set_discard_command (client, argc, argv);
 
  gnome_client_set_restart_command (client, 1, argv);
  gnome_client_set_clone_command (client, 1, argv);
  // g_free(argv[1]);
  return TRUE;
}

GnomeClient *newGnomeClient(const char *name)
{
  gchar *buf[1024];

  GnomeClient *client;

  // client = gnome_client_new();
  client=gnome_master_client();

  if (!client)
    return NULL;

  getcwd((char *)buf,sizeof(buf));
  gnome_client_set_current_directory(client, (char *)buf);

  gtk_object_ref(GTK_OBJECT(client));
  gtk_object_sink(GTK_OBJECT(client));

  gtk_signal_connect (GTK_OBJECT (client), "save_yourself",
		      GTK_SIGNAL_FUNC (save_state), (char*)name);
  gtk_signal_connect (GTK_OBJECT (client), "die",
		      GTK_SIGNAL_FUNC (session_die), NULL);
  return client;
}


int main(int argc,char **argv)
{
  GnomeClient *client;
  
  client=newGnomeClient(g_filename_pointer(argv[0]));
  bindtextdomain (PACKAGE, GNOMELOCALEDIR);
  textdomain (PACKAGE);
  // argp_program_version=VERSION;
  gnome_init("disk_catalog",VERSION,argc,argv);

  // prepare_app(g_filename_pointer(argv[0]));
  prepare_app("disk_catalog");
  
  gtk_main();
  return 0;
}

