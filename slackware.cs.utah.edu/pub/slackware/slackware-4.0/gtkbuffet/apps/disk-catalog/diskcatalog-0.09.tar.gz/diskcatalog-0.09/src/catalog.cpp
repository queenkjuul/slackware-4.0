/*
  GNOME disk_catalog
  Copyright (C) 1999 Tero Koskinen

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

#include <stdio.h>
#include <fstream.h>
#include <unistd.h>
#include <ftw.h>
#include <ctype.h>
#include <fnmatch.h>

#include <errno.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>

#include <gtk/gtk.h>
#include <gnome.h>

#include <config.h>
#include "catalog.hh"
#include "tkstring.hh"
// #include "sll.hh"

#define LINE_MAX_LEN 1024

TreeNode::TreeNode()
{
  /*  myName=TKString();
  myPath=TKString();
  myDisk=TKString(); */

  left=0;
  right=0;
}

TreeNode::TreeNode(const char *name,const char *path,const char *disk)
{
  myName=name;
  myPath=path;
  myDisk=disk;

  left=0;
  right=0;
}

TreeNode::~TreeNode()
{ }

int TreeNode::compare(TreeNode *n)
{
  char *na,*p,*d;
    /* TKString na,p,d; */
  if (n==0)
    return 0;
  d=n->getDisk()->myStr;
  p=n->getPath()->myStr;
  na=n->getName()->myStr; 
  if (strcmp(d,myDisk.myStr)==0)
    {
      if (strcmp(na,myName.myStr)==0)
	{
	  if (strcmp(p,myPath.myStr)==0)
	    return 0;
	  else if (greaterThan(p,myPath.myStr))
	    return 1;
	  else
	    return -1;
	}
      else if (greaterThan(na,myName.myStr))
	return 1;
      else return -1;
    }
  else if (greaterThan(d,myDisk.myStr))
    return 1;
  return -1;
}

void TreeNode::set(TreeNode *n,int compareNode)
{
  int rl=0;
  // TKString n,p,d;
  // d=n->getDisk();
  if (compareNode)
    rl=compare(n);
  else
    rl=1;
  // cout << "compare(n) = " << rl << endl;
  if (rl==-1)
    {
      // cout << rl << endl;
      if (left)
	left->set(n,compareNode);
      else
	left=n;
    }
  else 
    {
      if (right)
	right->set(n,compareNode);
      else
	right=n;
    }
}

void TreeNode::removeLeft(void)
{
  if (left)
    {
      left->removeLeft();
      left->removeRight();
      delete left;
      left=0;
    }
}

void TreeNode::removeRight(void)
{
  if (right)
    {
      right->removeLeft();
      right->removeRight();
      delete right;
      right=0;
    }
}

void TreeNode::addToList(GtkWidget *list)
{
  //  TKString t1,t2,t3;
  const char *ctmp[4];
  int r=0;
  if (left)
    left->addToList(list);
#ifndef MORE_SPEED_PLEASE
  if (myName.length()>0 && myPath.length()>0 && myDisk.length()>0)
    {
#endif
      ctmp[0]=myName.getStr();
      ctmp[1]=myPath.getStr();
      ctmp[2]=myDisk.getStr();
      ctmp[3]=myDescrpt.getStr();
      r=gtk_clist_append(GTK_CLIST(list), (char**)ctmp);
#ifndef MORE_SPEED_PLEASE
      gtk_clist_set_row_data(GTK_CLIST(list), r, (void*)myName.getStr());
    }
#endif
  if (right)
    right->addToList(list);
}

void TreeNode::addToList(TKString name,GtkWidget *list)
{
  //  TKString t1,t2,t3;
  const char *ctmp[4];
  int r=0;
  if (left)
    left->addToList(name,list);
#ifndef MORE_SPEED_PLEASE
  if (myName.length()>0 && myPath.length()>0 && myDisk.length()>0)
    {
#endif
      if (!fnmatch(name.getStr(),myName.getStr(),0))
	{
	  ctmp[0]=myName.getStr();
	  ctmp[1]=myPath.getStr();
	  ctmp[2]=myDisk.getStr();
	  ctmp[3]=myDescrpt.getStr();
	  r=gtk_clist_append(GTK_CLIST(list), (char**)ctmp);
#ifndef MORE_SPEED_PLEASE
	  gtk_clist_set_row_data(GTK_CLIST(list), r, (void*)myName.getStr());
#endif
	}
#ifndef MORE_SPEED_PLEASE
    }
#endif
  if (right)
    right->addToList(name,list);
}

void TreeNode::addDiskToList(TKString name,GtkWidget *list)
{
  //  TKString t1,t2,t3;
  const char *ctmp[4];
  int r=0;
  if (left)
    left->addDiskToList(name,list);
#ifndef MORE_SPEED_PLEASE
  if (myName.length()>0 && myPath.length()>0 && myDisk.length()>0)
    {
#endif
      if (!fnmatch(name.getStr(),myDisk.getStr(),0))
	{
	  ctmp[0]=myName.getStr();
	  ctmp[1]=myPath.getStr();
	  ctmp[2]=myDisk.getStr();
	  ctmp[3]=myDescrpt.getStr();
	  r=gtk_clist_append(GTK_CLIST(list), (char**)ctmp);
#ifndef MORE_SPEED_PLEASE
	  gtk_clist_set_row_data(GTK_CLIST(list), r, (void*)myDisk.getStr());
#endif

	}
#ifndef MORE_SPEED_PLEASE
    }
#endif
  if (right)
    right->addDiskToList(name,list);
}

void TreeNode::addDiffDiskToList(TKString name,GtkWidget *list)
{
  //  TKString t1,t2,t3;
  const char *ctmp[4];
  int r=0;
  if (left)
    left->addDiffDiskToList(myDisk,list);
#ifndef MORE_SPEED_PLEASE
  if (myName.length()>0 && myPath.length()>0 && myDisk.length()>0)
    {
#endif
      if (fnmatch(name.getStr(),myDisk.getStr(),0))
	{
	  ctmp[0]=myName.getStr();
	  ctmp[1]=myPath.getStr();
	  ctmp[2]=myDisk.getStr();
	  ctmp[3]=myDescrpt.getStr();
	  r=gtk_clist_append(GTK_CLIST(list), (char**)ctmp);
#ifndef MORE_SPEED_PLEASE
	  gtk_clist_set_row_data(GTK_CLIST(list), r, (void*)myDisk.getStr());
#endif
	}
#ifndef MORE_SPEED_PLEASE
    }
#endif
  if (right)
    right->addDiffDiskToList(myDisk,list);
}

void TreeNode::writeNode(ofstream & fout,int addDescription)
{
  if (left)
    left->writeNode(fout,addDescription);

  if (myName.length()>0 && myPath.length()>0 && myDisk.length()>0)
    {
      unsigned long len=0;
      len=myName.length();
      fout.write((char*)&len,2);
      fout.write(myName.getStr(),len);
      len=myPath.length();
      fout.write((char*)&len,2);
      fout.write(myPath.getStr(),len);
      len=myDisk.length();
      fout.write((char*)&len,2);
      fout.write(myDisk.getStr(),len);
      len=myDescrpt.length();
      if (addDescription)
	{
	  if (len>0)
	    {
	      fout.write((char*)&len,2);
	      fout.write(myDescrpt.getStr(),len);
	    }
	  else
	    {
	      int lentmp=1;
	      lentmp=1;
	      fout.write((char*)&lentmp,2);
	      fout.write("\0",1);
	    }
	}
    }
  if (right)
    right->writeNode(fout,addDescription);
}

void TreeNode::deleteNode(TKString name,TKString path,TKString disk)
{
  //  TKString t1,t2,t3;
  // const char *ctmp[3];
  // int r=0;
  if (left)
    left->deleteNode(name,path,disk);
#ifndef MORE_SPEED_PLEASE
  if (myName.length()>0 && myPath.length()>0 && myDisk.length()>0)
    {  
#endif
      if (!fnmatch(name.getStr(),myName.getStr(),0))
	{
	  if (!fnmatch(path.getStr(),myPath.getStr(),0))
	    {
	      if (!fnmatch(disk.getStr(),myDisk.getStr(),0))
		{
		  myName=TKString();
		  myPath=TKString();
		  myDisk=TKString();
		  myDescrpt=TKString();
		}
	    }
	}
#ifndef MORE_SPEED_PLEASE
    }
#endif
  if (right)
    right->deleteNode(name,path,disk);
}

void TreeNode::saveAsXml(xmlDocPtr & doc,
			 xmlNodePtr & tree,
			 TKString & disk,
			 int addDescription)
{
  xmlNodePtr node;
  if (left)
    left->saveAsXml(doc,tree,disk,addDescription);

  if (strcmp(disk.getStr(),myDisk.getStr())==0 || tree==NULL)
    {
      node=xmlNewChild(doc->root,NULL,(unsigned char*)"disk",NULL);
      xmlNewChild(node,NULL,(unsigned char*)"title",(unsigned char*)myDisk.getStr());
      xmlNewChild(node,NULL,(unsigned char*)"file",(unsigned char*)myName.getStr());
      xmlNewChild(node,NULL,(unsigned char*)"path",(unsigned char*)myPath.getStr());
      if (addDescription)
	{
	  if (myDescrpt.length()>0)
	    xmlNewChild(node,NULL,(unsigned char*)"description",
			(unsigned char*)myDescrpt.getStr());
	  else
	    xmlNewChild(node,NULL,(unsigned char*)"description",
			(unsigned char*)" ");
	}
      if (right)
	right->saveAsXml(doc,node,myDisk,addDescription);
    }
  else
    {
      xmlNewChild(tree,NULL,(unsigned char*)"file",
		  (unsigned char*)myName.getStr());
      xmlNewChild(tree,NULL,(unsigned char*)"path",
		  (unsigned char*)myPath.getStr());
      if (addDescription)
	{
	  if (myDescrpt.length()>0)
	    xmlNewChild(tree,NULL,(unsigned char*)"description",
			(unsigned char*)myDescrpt.getStr());
	  else
	    xmlNewChild(tree,NULL,(unsigned char*)"description",
			(unsigned char*)" ");
	}
      if (right)
	right->saveAsXml(doc,tree,disk,addDescription);
    }
}

void TreeNode::addDescription(TKString & name,
			      TKString & path,
			      TKString & disk,
			      TKString & des)
{
  if (left)
    left->addDescription(name,path,disk,des);
#ifndef MORE_SPEED_PLEASE
  if (myName.length()>0 && myPath.length()>0 && myDisk.length()>0)
    {
#endif
      if (!fnmatch(name.getStr(),myName.getStr(),0))
	{
	  if (!fnmatch(path.getStr(),myPath.getStr(),0))
	    {
	      if (!fnmatch(disk.getStr(),myDisk.getStr(),0))
		{
		  myDescrpt=des;
		}
	    }
	}
#ifndef MORE_SPEED_PLEASE
    }
#endif
  if (right)
    right->addDescription(name,path,disk,des);
}

int TreeNode::count(void)
{
  int a=0;
  int b=0;
  if (left)
    a=left->count();
  if (right)
    b=right->count();
  
  return a+b+1;
}

CatalogTree::CatalogTree():
  modified(0),
  root(0)
{

}

CatalogTree::~CatalogTree()
{
  if (root)
    removeAll();
}

void CatalogTree::add(TKString & name,TKString & path,TKString & disk)
{
  TreeNode *t;
  t=new TreeNode(name.getStr(),path.getStr(),disk.getStr());
  if (t)
    {
      if (!root)
	root=t;
      else
	root->set(t);
    }
}

void CatalogTree::addWithoutCompare(TKString & name,
				    TKString & path,
				    TKString & disk,
				    TKString & des)
{
  TreeNode *t;
  t=new TreeNode(name.getStr(),path.getStr(),disk.getStr());
  t->setDescrpt(des);
  if (t)
    {
      if (!root)
	{
	  root=t;
	  last=t;
	}
      else
	{
	  // root->set(t,0);
	  last->set(t,0);
	  last=t;
	}
    }
}

void CatalogTree::addWithoutCompare(const char *name,
				    const char *path,
				    const char *disk,
				    const char *des)
{
  TreeNode *t;
  t=new TreeNode(name,path,disk);
  if (des)
    {
      t->setDescrpt(des);
    }

  if (t)
    {
      if (!root)
	{
	  root=t;
	  last=t;
	}
      else
	{
	  // root->set(t,0);
	  last->set(t,0);
	  last=t;
	}
    }
}

void CatalogTree::removeAll(void)
{
  if (root)
    {
      root->removeLeft();
      root->removeRight();
      delete (root);
    }
  root=0;
}

void CatalogTree::removeNode(TKString name,TKString path,TKString disk)
{
  if (root)
    root->deleteNode(name,path,disk);
}


void CatalogTree::listAll(GtkWidget *list)
{
  gtk_clist_clear(GTK_CLIST(list));
  gtk_clist_freeze(GTK_CLIST(list));
  if (root)
    root->addToList(list);
  gtk_clist_thaw(GTK_CLIST(list));
}

long CatalogTree::count(void)
{
  if (root)
    return root->count();

  return 0;
}

void CatalogTree::listByName(TKString name,GtkWidget *list)
{
  gtk_clist_clear(GTK_CLIST(list));
  gtk_clist_freeze(GTK_CLIST(list));
  if (root)
    root->addToList(name,list);
  gtk_clist_thaw(GTK_CLIST(list));
}

void CatalogTree::listByDisk(TKString disk,GtkWidget *list)
{
  gtk_clist_clear(GTK_CLIST(list));
  gtk_clist_freeze(GTK_CLIST(list));
  if (root)
    root->addDiskToList(disk,list);
  gtk_clist_thaw(GTK_CLIST(list));
}

void CatalogTree::listByDiffDisk(TKString disk,GtkWidget *list)
{
  gtk_clist_clear(GTK_CLIST(list));
  gtk_clist_freeze(GTK_CLIST(list));
  if (root)
    root->addDiffDiskToList(disk,list);
  gtk_clist_thaw(GTK_CLIST(list));
}


int CatalogTree::saveCatalog(const char *file,int addDescription)
{
  long number=0;
  ofstream fout;
  fout.open(file);
  if (!fout)
    return 1;
  saveName=file;
  if (addDescription)
    {
      number=count();
      fout.write((char*)&number,4);
    }
  if (root)
    root->writeNode(fout,addDescription);
  fout.close();
  modified=0;
  return 0;
}

int CatalogTree::saveCatalog(int addDescription)
{
  if (saveName.length()>0 && saveName.getStr()!=0)
    {
      return saveCatalog(saveName.getStr(),addDescription);
    }
  return 1;
}

int CatalogTree::readCatalog(const char *file,GtkWidget *bar,
			     int readDescription)
{
  char buffer[LINE_MAX_LEN];
  gdouble value=0;
  long number=0;
#ifndef FAST_SAVE
  ifstream fin;
#endif
  TKString n,p;
  unsigned long len=0;
  // char *b1,*b2,*b3;
  char b1[4096]; // I hope this is enough
  char b2[4096];
  char b3[4096];

  int round=0;

  for (int a=0;a<LINE_MAX_LEN;a++) { buffer[a]='\0'; }

#ifdef FAST_SAVE

  int fd;
  struct stat sb;
  void *region;
  // caddr_t region;
  fd=open(file,O_RDONLY);
  if (fd<0)
    {
      return -1;
    }
  removeAll();

#else
  fin.open(file);
  if (!fin)
    return -1;
  else
    removeAll();
#endif


  if (bar)
    gnome_appbar_push(GNOME_APPBAR(bar),N_("Loading..."));

#ifdef FAST_SAVE
  int counter=0;

  if (fstat(fd,&sb))
    {
      return -1;
    }
  /* memomy mapping.. cool... */
  region=mmap(NULL,sb.st_size,PROT_READ,MAP_SHARED,fd,0);
  if (region==((caddr_t)-1))
    {
      return -1;
    }
  close(fd);

  counter=0;
  if (readDescription)
    {
      memcpy((void*)&number,region,4);
      counter+=4;
    }

  while(counter<sb.st_size && round<number)
    {
      memcpy((void*)&len,region+counter,2); /* is this ridiculous? */
      counter+=2;
      memcpy(b1,region+counter,len);
      counter+=len;
      b1[len]='\0';
#ifdef TK_DO_SANITY_CHECK
      if (counter<sb.st_size)
	break;
#endif
      memcpy((void*)&len,region+counter,2);
      counter+=2;
      memcpy(b2,region+counter,len);
      counter+=len;
#ifdef TK_DO_SANITY_CHECK
      if (counter<sb.st_size)
	break;
#endif
      b2[len]='\0';
      memcpy((void*)&len,region+counter,2);
      counter+=2;
      memcpy(b3,region+counter,len);
      counter+=len;
      b3[len]='\0';
#ifdef TK_DO_SANITY_CHECK
      if (counter<sb.st_size)
	break;
#endif
      if (readDescription != 0)
	{
	  char *b4;
	  memcpy((void*)&len,region+counter,2);
	  counter+=2;
	  b4=(char*)malloc(len+1);
	  if (!b4)
	    addWithoutCompare(b1,b2,b3,NULL);
	  else
	    {
	      memcpy(b4,region+counter,len);
	      b4[len]='\0';
	      addWithoutCompare(b1,b2,b3,b4);
	      free(b4);
	    }
	  counter+=len;
	}
      else
	addWithoutCompare(b1,b2,b3,NULL);
#if 0
    } /* now my xemacs behaves nicely */
#endif

#else

#warning "Old Method!"

  while(!fin.eof())
    {
      
      // TKString sb1,sb2,sb3;
      //      unsigned long len=0;
      //      char *b1,*b2,*b3;
      fin.read((char*)&len,2);

      // b1=new char[len+1];
      //      if (b1)
      
      fin.read(b1,len);
      b1[len]='\0';
      fin.read((char*)&len,2);
      // b2=new char[len+1];
      // if (b2)
      fin.read(b2,len);
      b2[len]='\0';
      fin.read((char*)&len,2);
      // b3=new char[len+1];
      // if (b3)
      fin.read(b3,len);
      b3[len]='\0';
      /* sb1=b1;
	 sb2=b2;
	 sb3=b3; */
      addWithoutCompare(b1,b2,b3);
      // delete [] b1;
      // delete [] b2;
      // delete [] b3;
#endif
      round++;

      if (round%250)
	while(gtk_events_pending())
	  gtk_main_iteration();

      if (! readDescription)
	{
	  value+=0.001;
	  if (value>1)
	    value=0;
	}
      else
	{
	  /* enough floats  :) */
	  value=(float)((float)(round)/(float)(number));
	}
      if (bar)
	{
	  gnome_appbar_set_progress(GNOME_APPBAR(bar),value);
	  gnome_appbar_refresh(GNOME_APPBAR(bar));
	}
    }
  if (bar)
    {
      gnome_appbar_pop(GNOME_APPBAR(bar));
      gnome_appbar_set_progress(GNOME_APPBAR(bar),0);
      gnome_appbar_refresh(GNOME_APPBAR(bar));
      gnome_appbar_set_status(GNOME_APPBAR(bar),g_filename_pointer(file));
    }
  saveName=file;

#ifdef FAST_SAVE
  //  close(fd);
  munmap((caddr_t)region,sb.st_size);
#else
  fin.close();
#endif
  modified=0;
  return 0;
}

int CatalogTree::saveCatalogAsXml(const char *file,int addDescription)
{
  xmlDocPtr doc;
  xmlNodePtr tree;
  TKString disk;
  unsigned char ver[]="1.0";
  tree=(xmlNodePtr)NULL;

  doc=xmlNewDoc(ver);
  doc->root=xmlNewDocNode(doc,NULL,(unsigned char*)"CATALOG",NULL);
  xmlSetProp(doc->root,(unsigned char*)"format",(unsigned char*)"standard");
  if (root)
    root->saveAsXml(doc,tree,disk,addDescription);

  xmlSetDocCompressMode(doc,0);
  xmlSaveFile(file,doc);
  xmlFreeDoc(doc);

  return 0;
}

void CatalogTree::executeCommand(TKString command,GtkWidget *list,
				 GtkWidget *bar,
				 int updateList)
{
  int update=0;
  TKString a,b,c,d;
  if (!list)
    return;

  update=updateList;

  a=giveNextWord(command);
  if (a.length()>0)
    {
      b=giveNextWord(command);

      if (b.length()>0)
	{

	  c=giveNextWord(command);
	  if (c.length()>0)
	    {
	      d=giveNextWord(command);
	      if (d.length()>0)
		{
		  if (a==TKString(_("delete")))
		    {
		      removeNode(b,c,d);
		      modified=1;
		      /* listAll(list); */
		    }
		  else if (a==TKString(_("describe")))
		    {
		      TKString e;
		      e=giveNextWord(command);
		      if (root)
			{
			  root->addDescription(b,c,d,e);
			  modified=1;
			}
		    }
		}
	      else
		{
		  if (a==TKString(_("search")) && b==TKString(_("file")))
		    {
		      listByName(c,list);
		      update=0;
		    }
		  else if (a==TKString(_("view")) && b==TKString(_("disk")))
		    {
		      listByDisk(c,list);
		      update=0;
		    }
		}
	    }
	  else
	    {
	      if (a==TKString(_("search")) || a==TKString(_("list")))
		{
		  if (b==TKString(_("all")))
		    {
		      /* listAll(list); */
                      update=1;
		    }
		  else
		    {
		      listByName(b,list);
		      update=0;
		    }
		}
	      else if (a==TKString(_("view")) && b==TKString(_("disks")))
		{
		  listByDiffDisk(TKString(),list);
		  update=0;
		}
	      else if (a==TKString(_("open")))
		{
		  gtk_clist_clear(GTK_CLIST(list));
		  readCatalog(b.getStr(),bar);
		  /* listAll(list); */
		}
	    }
	}
      else
	{
	  if (a==TKString(_("count")))
	    {
	      TKString tmp,tmp2;
	      const char *ctmp[3];
	      int i=0;
	      char buf[100];
	      i=count();
	      tmp="count";
	      tmp2="is";
	      sprintf(buf,"%d",i);
	      gtk_clist_clear(GTK_CLIST(list));
	      ctmp[0]=tmp.getStr();
	      ctmp[1]=tmp2.getStr();
	      ctmp[2]=(const char*)buf;
	      gtk_clist_append(GTK_CLIST(list), (char**)ctmp);
	      update=0;
	    }
	  else if (a==TKString(_("clear")))
	    {
	      gtk_clist_clear(GTK_CLIST(list));
	      update=0;
	    }
	  else
	    {
	      gtk_clist_clear(GTK_CLIST(list));
	      listByName(a,list);
	      update=0;
	    }
	}
    }
  if (update)
    listAll(list);
}
