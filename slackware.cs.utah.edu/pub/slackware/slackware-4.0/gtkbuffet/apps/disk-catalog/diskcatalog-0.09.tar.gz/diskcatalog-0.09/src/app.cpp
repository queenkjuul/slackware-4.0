/*
  GNOME Disk Catalog
  Copyright (C) 1999 Tero Koskinen

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

#include <fstream.h>
#include <ftw.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>

#include <gtk/gtk.h>
#include <gnome.h>

#include <config.h>
#include "app.hh"
#include "tkstring.hh"


CatalogTree ct;

// CatalogHandler ch;

void CatalogMainWindow::read_config(void)
{
  openCatalog=gnome_config_get_int("/disk_catalog/Options/OpenCatalogAtStartup");
  useDescription=gnome_config_get_int("/disk_catalog/Options/UseDescription");
  updateList=gnome_config_get_int("/disk_catalog/Options/UpdateList");
  // if (openCatalog)
  {
    defaultCatalog=gnome_config_get_string("/disk_catalog/Options/DefaultCatalog");
  }
  latest[0]=gnome_config_get_string("/disk_catalog/Files/1st");
  latest[1]=gnome_config_get_string("/disk_catalog/Files/2nd");
  latest[2]=gnome_config_get_string("/disk_catalog/Files/3rd");
  latest[3]=gnome_config_get_string("/disk_catalog/Files/4th");
}

void CatalogMainWindow::save_config()
{
  gnome_config_set_string("/disk_catalog/Options/DefaultCatalog",defaultCatalog);
  gnome_config_set_int("/disk_catalog/Options/OpenCatalogAtStartup",openCatalog);
  gnome_config_set_int("/disk_catalog/Options/UseDescription",useDescription);
  gnome_config_set_int("/disk_catalog/Options/UpdateList",updateList);
  gnome_config_set_string("/disk_catalog/Files/1st",latest[0]);
  gnome_config_set_string("/disk_catalog/Files/2nd",latest[1]);
  gnome_config_set_string("/disk_catalog/Files/3rd",latest[2]);
  gnome_config_set_string("/disk_catalog/Files/4th",latest[3]);

  gnome_config_sync();
}

void CatalogMainWindow::roll_latest(TKString newCatalog)
{

  TKString place;
  place=_("File");
  place+=TKString("/",1); // this could be just place+="/";
  place+=_("Open recent.../");
  
  // place+=latest[3];

  // if (latest[3].length()>0)
  gnome_app_remove_menus(GNOME_APP(app),(char*)place.getStr(),4);
  
  if (strcmp(latest[0].getStr(),newCatalog.getStr()))
    {
      for (int a=3;a>0;a--)
	{
	  latest[a]=latest[a-1];
	  // cout << "latest[" << a << "] = " << latest[a] << endl;
	}
      latest[0]=newCatalog;
    }
  /* else
     return; */
  
  GnomeUIInfo recent_menu_entry1[] = {
    GNOMEUIINFO_ITEM_DATA((char*)latest[0].getStr(),NULL,
			  open_recent_event,
			  (gpointer)latest[0].getStr(),NULL),
    
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry2[] = {
    GNOMEUIINFO_ITEM_DATA((char*)latest[1].getStr(),NULL,
			  open_recent_event,
			  (gpointer)latest[1].getStr(),NULL),
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry3[] = {
    GNOMEUIINFO_ITEM_DATA((char*)latest[2].getStr(),NULL,
			  open_recent_event,
			  (gpointer)latest[2].getStr(),NULL),
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry4[] = {
    GNOMEUIINFO_ITEM_DATA((char*)latest[3].getStr(),NULL,
			  open_recent_event,
			  (gpointer)latest[3].getStr(),NULL),
    GNOMEUIINFO_END
  };

  /*  GnomeUIInfo menu_separator[] = {
    GNOMEUIINFO_SEPARATOR,
    GNOMEUIINFO_END
    }; */

  /*  GnomeUIInfo menu_null[] = {
    GNOMEUIINFO_END
  };

  GnomeUIInfo menu_recent_files[] = {
    GNOMEUIINFO_SEPARATOR,
    GNOMEUIINFO_SUBTREE(_("Most recent catalogs"),menu_null),
    GNOMEUIINFO_END
    }; */

  place=_("File");
  
  place+=TKString("/",1)+_("Open recent...");
  place+=TKString("/",1);

  if (latest[3].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(app),(char*)place.getStr(),
			     recent_menu_entry4);
    }
  if (latest[2].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(app),(char*)place.getStr(),
			     recent_menu_entry3);
    }

  if (latest[1].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(app),(char*)place.getStr(),
			     recent_menu_entry2);
    }
  if (latest[0].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(app),(char*)place.getStr(),
			     recent_menu_entry1);
    }
}

/* GnomeUIInfo recent_menu[5]; */

CatalogMainWindow *app;

void create_recent_menu(void)
{
  GnomeUIInfo recent_menu_entry1[] = {
    GNOMEUIINFO_ITEM_DATA((char*)app->latest[0].getStr(),NULL,
			  open_recent_event,
			  (gpointer)app->latest[0].getStr(),NULL),
    
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry2[] = {
    GNOMEUIINFO_ITEM_DATA((char*)app->latest[1].getStr(),NULL,
			  open_recent_event,
			  (gpointer)app->latest[1].getStr(),NULL),
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry3[] = {
    GNOMEUIINFO_ITEM_DATA((char*)app->latest[2].getStr(),NULL,
			  open_recent_event,
			  (gpointer)app->latest[2].getStr(),NULL),
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry4[] = {
    GNOMEUIINFO_ITEM_DATA((char*)app->latest[3].getStr(),NULL,
			  open_recent_event,
			  (gpointer)app->latest[3].getStr(),NULL),
    GNOMEUIINFO_END
  };

  /*  GnomeUIInfo menu_separator[] = {
    GNOMEUIINFO_SEPARATOR,
    GNOMEUIINFO_END
    }; */

  GnomeUIInfo menu_null[] = {
    GNOMEUIINFO_END
  };

  GnomeUIInfo menu_recent_files[] = {
    //    GNOMEUIINFO_SEPARATOR,
    GNOMEUIINFO_SUBTREE(_("Open recent..."),menu_null),
    GNOMEUIINFO_END
  };

  TKString place,place2;

  place=_("File");
  
  place2=place+TKString("/",1)+_("_Open");
  place+=TKString("/",1)+_("Open recent...");
  place+=TKString("/",1);

  gnome_app_insert_menus(GNOME_APP(app->app),(char*)place2.getStr(),
			 menu_recent_files);

  if (app->latest[3].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(app->app),(char*)place.getStr(),
			     recent_menu_entry4);
    }
  if (app->latest[2].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(app->app),(char*)place.getStr(),
			     recent_menu_entry3);
    }

  if (app->latest[1].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(app->app),(char*)place.getStr(),
			     recent_menu_entry2);
    }
  if (app->latest[0].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(app->app),(char*)place.getStr(),
			     recent_menu_entry1);
    }
}

GtkWidget *create_entry(void)
{
  GtkWidget *w;
  w=gtk_entry_new();
  gtk_signal_connect(GTK_OBJECT(w),"activate",GTK_SIGNAL_FUNC(entry_command_event),w);
  return w;
}

GtkWidget *create_list(void)
{
  GtkWidget *w;
  char *titles[4]=
  {
    N_("Name"),
    N_("Path"),
    N_("Disk"),
    N_("Description"),
  };
  char *tmp[4];
  tmp[0]=_(titles[0]);
  tmp[1]=_(titles[1]);
  tmp[2]=_(titles[2]);
  tmp[3]=_(titles[3]);
  
  w=gtk_clist_new_with_titles(4,tmp);
  gtk_clist_set_selection_mode(GTK_CLIST(w), GTK_SELECTION_SINGLE);
  /*    gtk_clist_set_column_justification(GTK_CLIST(w), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification(GTK_CLIST(w), 2,  GTK_JUSTIFY_CENTER); */
  gtk_clist_set_column_width(GTK_CLIST(w),0,100);
  gtk_clist_set_column_width(GTK_CLIST(w),1,100);
  gtk_clist_set_column_width(GTK_CLIST(w),2,40);
  gtk_clist_set_column_width(GTK_CLIST(w),4,100);
  gtk_clist_column_titles_passive(GTK_CLIST(w));
  return w;
}

GtkWidget *create_preferences(void)
{
  GtkWidget *w;
  GtkWidget *vbox;
  GtkWidget *label;

  app->openCatalogTmp=app->openCatalog;
  app->useDescriptionTmp=app->useDescription;
  app->updateListTmp=app->updateList;
  w=gnome_property_box_new();
  
  vbox=gtk_vbox_new(FALSE,0);
  gtk_container_border_width(GTK_CONTAINER(vbox), GNOME_PAD);

  app->prefButton3=gtk_check_button_new_with_label(_("Update list after each command"));
  gtk_box_pack_start(GTK_BOX(vbox),app->prefButton3,FALSE,FALSE,0);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(app->prefButton3),
			      app->updateListTmp);
  gtk_signal_connect_object(GTK_OBJECT(app->prefButton3), "toggled",
                            GTK_SIGNAL_FUNC(gnome_property_box_changed),
                            GTK_OBJECT(w));
  gtk_signal_connect(GTK_OBJECT(app->prefButton3), "toggled",
		     GTK_SIGNAL_FUNC(toggled_prefButton3_event),NULL);


  app->prefButton2=gtk_check_button_new_with_label(_("Use new style catalog format (slower)"));
  gtk_box_pack_start(GTK_BOX(vbox),app->prefButton2,FALSE,FALSE,0);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(app->prefButton2),
			      app->useDescriptionTmp);
  gtk_signal_connect_object(GTK_OBJECT(app->prefButton2), "toggled",
                            GTK_SIGNAL_FUNC(gnome_property_box_changed),
                            GTK_OBJECT(w));
  gtk_signal_connect(GTK_OBJECT(app->prefButton2), "toggled",
		     GTK_SIGNAL_FUNC(toggled_prefButton2_event),NULL);

  
  app->prefButton1=gtk_check_button_new_with_label(_("Open catalog at startup"));
  gtk_box_pack_start(GTK_BOX(vbox),app->prefButton1,FALSE,FALSE,0);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(app->prefButton1),
			      app->openCatalogTmp);
  gtk_signal_connect_object(GTK_OBJECT(app->prefButton1), "toggled",
                            GTK_SIGNAL_FUNC(gnome_property_box_changed),
                            GTK_OBJECT(w));
  gtk_signal_connect(GTK_OBJECT(app->prefButton1), "toggled",
		     GTK_SIGNAL_FUNC(toggled_prefButton1_event),NULL);

  label=gtk_label_new(_("Catalog filename"));
  gtk_misc_set_alignment(GTK_MISC(label), 0.0, 0.5);
  gtk_box_pack_start(GTK_BOX(vbox),label,FALSE,FALSE,0);
  gtk_widget_show(label);
  app->prefEntry1=gtk_entry_new();
  if (app->defaultCatalog.length()>0)
    gtk_entry_set_text(GTK_ENTRY(app->prefEntry1),app->defaultCatalog);
  gtk_box_pack_start(GTK_BOX(vbox),app->prefEntry1,FALSE,FALSE,0);

  gtk_signal_connect_object(GTK_OBJECT(app->prefEntry1), "changed",
                            GTK_SIGNAL_FUNC(gnome_property_box_changed),
                            GTK_OBJECT(w));

  label=gtk_label_new(_("General"));
  gtk_widget_show(label);
  gtk_notebook_append_page(GTK_NOTEBOOK(GNOME_PROPERTY_BOX(w)->notebook),
			   vbox,label);

  gtk_signal_connect(GTK_OBJECT(w), "apply",
                     GTK_SIGNAL_FUNC(apply_prefs_event), NULL);

  gtk_widget_show(app->prefButton3);
  gtk_widget_show(app->prefButton2);
  gtk_widget_show(app->prefButton1);
  gtk_widget_show(app->prefEntry1);
  gtk_widget_show(vbox);

  return w;
}

void show_error(const char *msg)
{
  GtkWidget *w;
  w=gnome_message_box_new(msg,GNOME_MESSAGE_BOX_ERROR,
			  GNOME_STOCK_BUTTON_OK, NULL);
  gtk_widget_show(w);
}

// callbacks
void toggled_prefButton1_event(GtkWidget *,gpointer *)
{
  app->openCatalogTmp=!(app->openCatalogTmp);
}

void toggled_prefButton2_event(GtkWidget *,gpointer *)
{
  app->useDescriptionTmp=!(app->useDescriptionTmp);
}

void toggled_prefButton3_event(GtkWidget *,gpointer *)
{
  app->updateListTmp=!(app->updateListTmp);
}

void apply_prefs_event(GtkWidget *, gpointer *)
{
  gchar *s;
  // TKString catalogName;
  app->openCatalog=app->openCatalogTmp;
  app->useDescription=app->useDescriptionTmp;
  app->updateList=app->updateListTmp;
  s=gtk_entry_get_text(GTK_ENTRY(app->prefEntry1));
  if (app->openCatalog)
    app->defaultCatalog=s;
}

void entry_command_event(GtkWidget *,GtkWidget *entry)
{
  TKString command;
  command=gtk_entry_get_text(GTK_ENTRY(entry));
  /* cout << "Command: " << command << endl; */
  gtk_entry_set_text(GTK_ENTRY(entry),"");
  ct.executeCommand(command,app->list,app->bar,app->updateList);
}

void real_app_quit(GtkWidget *, gpointer *)
{
  app->save_config();
  delete(app);
  gtk_main_quit ();

}

void app_quit (GtkWidget *, gpointer *)
{
  GtkWidget *dialog;
  GtkWidget *label;
  if (ct.getModified() != 0)
    {
      label=gtk_label_new(_("Your catalog is not saved. Exit?"));
      dialog=gnome_dialog_new("Exit GNOME Disk Catalog?",
			      GNOME_STOCK_BUTTON_OK,
			      GNOME_STOCK_BUTTON_NO,NULL);
      gnome_dialog_set_close(GNOME_DIALOG(dialog),TRUE);
      gnome_dialog_button_connect(GNOME_DIALOG(dialog),0 /* ok button */,
				  GTK_SIGNAL_FUNC(real_app_quit),NULL);
      gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(dialog)->vbox),
			 label,TRUE,TRUE,TRUE);

      gtk_widget_show(label);
      gtk_widget_show(dialog);
      
    }
  else
    real_app_quit(NULL,NULL);
}

void about_cb(GtkWidget *,gpointer *)
{
  const gchar *authors[] = {"Tero Koskinen <tkoskine@jas.pspt.fi>",NULL };
  GtkWidget *about=gnome_about_new ( _("GNOME Disk Catalog"), VERSION,
				     _("Copyright (C) 1999 Tero Koskinen"),
				     authors,
                                     "The newest version can be found from\nhttp://jas.pspt.fi/~tkoskine/gnome/",NULL);
  gtk_widget_show (about);
}

void cancel_event(GtkWidget *,GtkWidget *me)
{
  /* gtk_widget_destroy(me); */
  gtk_widget_destroy(me);
  me=NULL;
}

void cancel_dialog_event(GtkWidget *,gpointer )
{
  gnome_dialog_close(GNOME_DIALOG(app->entryWindow));
  app->entryWindow=0;
}

void open_selected_file_event(GtkWidget *,GtkWidget *filesel)
{
  char filename[1024];
  ct.removeAll();
  gtk_clist_clear(GTK_CLIST(app->list));
  strcpy(filename,gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel)));
  gtk_widget_destroy(filesel);
  // gnome_appbar_push(GNOME_APPBAR(app->bar),_("Loading..."));
  if (ct.readCatalog(filename,app->bar,app->useDescription)==-1)
    show_error(_("Cannot read selected catalog"));
  else
    {
      listCatalogs(app->list);
      app->roll_latest(TKString(filename));
    }
  // gnome_appbar_pop(GNOME_APPBAR(app->bar));
}

void open_catalog_event(GtkWidget *, gpointer *)
{
  app->filesel=gtk_file_selection_new(_("Open catalog"));
  gtk_window_position (GTK_WINDOW (app->filesel), GTK_WIN_POS_MOUSE);
  gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(app->filesel)->cancel_button), "clicked",
		      (GtkSignalFunc) cancel_event,
		      app->filesel);
  gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION (app->filesel)->ok_button),
                      "clicked", GTK_SIGNAL_FUNC(open_selected_file_event),
                      GTK_OBJECT(app->filesel));
  gtk_widget_show(app->filesel);
}

void open_recent_event(GtkWidget *,gpointer *data)
{
  char *string;
  string=(char*)data;
  // cout << "Data: " << string << endl;
  
  if (string)
    {
      if (ct.readCatalog(string,app->bar,app->useDescription)==-1)
	show_error(_("Cannot read selected catalog"));
      else
	{
	  listCatalogs(app->list);
	  app->roll_latest(TKString(string));
	}
    }
}

void close_catalog_event(GtkWidget *,gpointer *)
{
  gtk_clist_clear(GTK_CLIST(app->list));
  ct.removeAll();
  ct.setSaveName(TKString());
  gnome_appbar_set_status(GNOME_APPBAR(app->bar),"");
}

void save_to_selected_file_event(GtkWidget *,GtkWidget *filesel)
{
  if (filesel)
    {
      ct.saveCatalog(gtk_file_selection_get_filename (GTK_FILE_SELECTION (filesel)),app->useDescription);
      gnome_appbar_refresh(GNOME_APPBAR(app->bar));
      gnome_appbar_set_status(GNOME_APPBAR(app->bar),g_filename_pointer(gtk_file_selection_get_filename (GTK_FILE_SELECTION (filesel))));
      gtk_widget_destroy(filesel);
    }
}

void save_xml_to_selected_file_event(GtkWidget *,GtkWidget *filesel)
{
  if (filesel)
    {
      ct.saveCatalogAsXml(gtk_file_selection_get_filename (GTK_FILE_SELECTION (filesel)),app->useDescription);
      gnome_appbar_refresh(GNOME_APPBAR(app->bar));
      gnome_appbar_set_status(GNOME_APPBAR(app->bar),g_filename_pointer(gtk_file_selection_get_filename (GTK_FILE_SELECTION (filesel))));
      gtk_widget_destroy(filesel);
    }
}

void save_as_catalog_event(GtkWidget *,gpointer *)
{
  app->filesel=gtk_file_selection_new(_("Save as catalog"));
  gtk_window_position (GTK_WINDOW (app->filesel), GTK_WIN_POS_MOUSE);
  gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(app->filesel)->cancel_button), 
		      "clicked",
		      (GtkSignalFunc) cancel_event,
		      app->filesel);
  gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION (app->filesel)->ok_button),
                      "clicked", GTK_SIGNAL_FUNC(save_to_selected_file_event),
                      GTK_OBJECT(app->filesel));
  gtk_widget_show(app->filesel);

}

void export_xml_catalog_event(GtkWidget *,gpointer *)
{
  app->filesel=gtk_file_selection_new(_("Export to XML format"));
  gtk_window_position (GTK_WINDOW (app->filesel), GTK_WIN_POS_MOUSE);
  gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION(app->filesel)->cancel_button), 
		      "clicked",
		      (GtkSignalFunc) cancel_event,
		      app->filesel);
  gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION (app->filesel)->ok_button),
                      "clicked", GTK_SIGNAL_FUNC(save_xml_to_selected_file_event),
                      GTK_OBJECT(app->filesel));
  gtk_widget_show(app->filesel);

}

void save_catalog_event(GtkWidget *,gpointer *)
{
  if (ct.saveCatalog(app->useDescription)==1)
    save_as_catalog_event(NULL,NULL);
}

void add_dir_to_catalog_event(GtkWidget *, GtkWidget *)
{
  app->defaultDir=gtk_entry_get_text(GTK_ENTRY(app->dirEntry));
  app->diskName=gtk_entry_get_text(GTK_ENTRY(app->diskEntry));
  addCatalog(gtk_entry_get_text(GTK_ENTRY(app->dirEntry)),gtk_entry_get_text(GTK_ENTRY(app->diskEntry)));
  /*   listCatalogs(app->list); */
  // gtk_widget_destroy(app->entryWindow);
  gnome_dialog_close(GNOME_DIALOG(app->entryWindow));
  app->entryWindow=0;
}

void add_to_catalog_event(GtkWidget *, gpointer *)
{
  GtkWidget *label;
  // GtkWidget *okButton;
  // GtkWidget *cancelButton;
  GtkWidget *table;

  // app->entryWindow=gtk_window_new(GTK_WINDOW_TOPLEVEL);
  if (app->entryWindow==0)
    {
      app->entryWindow=gnome_dialog_new(_("Choose directory"),
					GNOME_STOCK_BUTTON_OK,
					GNOME_STOCK_BUTTON_CANCEL,NULL);
      gnome_dialog_set_close(GNOME_DIALOG(app->entryWindow),FALSE);
      gnome_dialog_set_default(GNOME_DIALOG(app->entryWindow),0);
      /* gtk_window_set_title(GTK_WINDOW (app->entryWindow), "Choose directory");
	 gtk_container_border_width(GTK_CONTAINER(app->entryWindow),5);
	 gtk_widget_set_usize(app->entryWindow,200,120); */

      table=gtk_table_new(3,3,TRUE);
      gtk_table_set_row_spacings (GTK_TABLE (table), 1);
      gtk_table_set_col_spacings (GTK_TABLE (table), 1);
      gtk_container_border_width (GTK_CONTAINER (table), 1); 
      // gtk_container_add(GTK_CONTAINER(app->entryWindow),table);
	
      // button with OK
      /*  okButton=gtk_button_new_with_label("OK");
	  gtk_table_attach_defaults(GTK_TABLE(table),okButton,3,5,0,1);
	  gtk_signal_connect(GTK_OBJECT(okButton),"clicked",
	  GTK_SIGNAL_FUNC(add_dir_to_catalog_event),
	  app->entryWindow); */
      gnome_dialog_button_connect(GNOME_DIALOG(app->entryWindow),0,
				  GTK_SIGNAL_FUNC(add_dir_to_catalog_event),
				  app->entryWindow); 

      // cancel button
      /* cancelButton=gtk_button_new_with_label("Cancel");
	 gtk_signal_connect(GTK_OBJECT (cancelButton), "clicked",
	 GTK_SIGNAL_FUNC(cancel_event),app->entryWindow);
	 gtk_table_attach_defaults(GTK_TABLE(table),cancelButton,3,5,1,2); */
      gnome_dialog_button_connect(GNOME_DIALOG(app->entryWindow),1,
				  GTK_SIGNAL_FUNC(cancel_dialog_event),
				  app->entryWindow); 
  
	
      // text entries
      app->dirEntry=gtk_entry_new(); // directory
      gtk_table_attach_defaults(GTK_TABLE(table),app->dirEntry,0,3,1,2);
      if (app->defaultDir.length()>0)
	gtk_entry_set_text(GTK_ENTRY(app->dirEntry),app->defaultDir);
      else
	gtk_entry_set_text(GTK_ENTRY(app->dirEntry),getenv("HOME"));
  
      app->diskEntry=gtk_entry_new(); // disk
      gtk_table_attach_defaults(GTK_TABLE(table),app->diskEntry,0,3,3,4);
      if (app->diskName.length()>0)
	gtk_entry_set_text(GTK_ENTRY(app->diskEntry),app->diskName);
      else
	gtk_entry_set_text(GTK_ENTRY(app->diskEntry),_("Home"));
	
      // label
      label=gtk_label_new(_("Directory"));
      gtk_table_attach_defaults(GTK_TABLE(table),label,0,3,0,1);
      gtk_widget_show(label);
  
      label=gtk_label_new(_("Disk name"));
      gtk_table_attach_defaults(GTK_TABLE(table),label,0,3,2,3);

      gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(app->entryWindow)->vbox),
			 table,TRUE,TRUE,TRUE);
    
      gtk_widget_show(label);
      gtk_widget_show(app->dirEntry);
      gtk_widget_show(app->diskEntry);
      /* gtk_widget_show(cancelButton);
	 gtk_widget_show(okButton); */
      gtk_widget_show(table);
      gtk_widget_show(app->entryWindow);
    }
}

void search_dialog_clicked_event(gchar *string,gpointer )
{
  TKString s;
  if (string)
    {
      s=string;
      ct.executeCommand(s,app->list,app->bar,app->updateList);
    }
}

void search_from_catalog_event(GtkWidget *,gpointer *)
{
  GtkWidget *dialog;

  // dialog=gnome_request_string_dialog(N_("Enter file to be searched"),
  //				     search_dialog_clicked_event,NULL);

  dialog=gnome_request_dialog(FALSE,_("Enter file to be searched"),
			      NULL,1024,search_dialog_clicked_event,NULL,
			      NULL);

  gtk_widget_show(dialog);
}


void preferences_event(GtkWidget *, gpointer *)
{
  GtkWidget *w;
  // GtkWidget *vbox;
  // GtkWidget *label;
    
  // w=gnome_property_box_new();
    
  // vbox=gtk_vbox_new(FALSE,0);
  w=create_preferences();
  gtk_widget_show(w);
}



GnomeUIInfo filemenu[] = {
  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		N_("_New"),N_("New catalog"),
		close_catalog_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_NEW,
		'N',GDK_CONTROL_MASK,NULL},
  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		N_("_Open"),N_("Open catalog"),
		open_catalog_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_OPEN,
		'O',GDK_CONTROL_MASK,NULL},
  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		N_("_Save"),N_("Save catalog"),
		save_catalog_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_SAVE,
		'S',GDK_CONTROL_MASK,NULL},

  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		N_("Save as"),N_("Save as catalog"),
		save_as_catalog_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_SAVE_AS,
		'S',GdkModifierType(GDK_CONTROL_MASK|GDK_SHIFT_MASK),NULL},

  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		N_("Export to XML"),N_("Export to XML format"),
		export_xml_catalog_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_SAVE_AS,
		0,GdkModifierType(0),NULL},

  /*  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		N_("_Add"),N_("Add directory to current catalog"),
		add_to_catalog_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_BLANK,
		'A',GDK_CONTROL_MASK,NULL},
  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		_("Search"),_("Search file from current catalog"),
		search_from_catalog_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_SEARCH,
		0,(GdkModifierType)0,NULL}, */

  GNOMEUIINFO_SEPARATOR,
  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		_("_Preferences"),_("Preferences"),
		preferences_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_PREF,
		'P',GDK_CONTROL_MASK,NULL},
  GNOMEUIINFO_SEPARATOR,
  {GNOME_APP_UI_ITEM,
   N_("_Exit"),N_("Exit"),
   app_quit,NULL,NULL,
   GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_EXIT,
   'Q',GDK_CONTROL_MASK,NULL},
	 
  GNOMEUIINFO_END
};

GnomeUIInfo actionsmenu[] = {
  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		N_("_Add"),N_("Add directory to current catalog"),
		add_to_catalog_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_BLANK,
		'A',GDK_CONTROL_MASK,NULL},
  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		_("Search"),_("Search file from current catalog"),
		search_from_catalog_event,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_SEARCH,
		0,(GdkModifierType)0,NULL},
  GNOMEUIINFO_END,
};

GnomeUIInfo helpmenu[] = {
  (GnomeUIInfo){GNOME_APP_UI_ITEM,
		_("_About..."),NULL,
		about_cb,NULL,NULL,
		GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_ABOUT,
		0,(GdkModifierType)0,NULL},
  GNOMEUIINFO_SEPARATOR,
  GNOMEUIINFO_HELP("diskcatalog"),
  GNOMEUIINFO_END,
};

GnomeUIInfo mainmenu[] = {
  GNOMEUIINFO_SUBTREE(N_("_File"),filemenu),
  GNOMEUIINFO_SUBTREE(N_("_Actions"),actionsmenu),
  GNOMEUIINFO_SUBTREE(N_("_Help"),helpmenu),
  GNOMEUIINFO_END
};

GnomeUIInfo toolbar[]={
  GNOMEUIINFO_ITEM_STOCK(N_("New"),N_("New catalog"),
			 close_catalog_event,GNOME_STOCK_PIXMAP_NEW),
  GNOMEUIINFO_ITEM_STOCK(N_("Open"),N_("Open catalog"),
			 open_catalog_event,GNOME_STOCK_PIXMAP_OPEN),
  GNOMEUIINFO_ITEM_STOCK(N_("Save"),N_("Save catalog"),
			 save_catalog_event,GNOME_STOCK_PIXMAP_SAVE),
  GNOMEUIINFO_SEPARATOR,
  GNOMEUIINFO_ITEM_STOCK(N_("Add"),N_("Add files to catalog"),
			 add_to_catalog_event,GNOME_STOCK_PIXMAP_MULTIPLE),
  GNOMEUIINFO_ITEM_STOCK(N_("Search"),N_("Search file from current catalog"),
			 search_from_catalog_event,GNOME_STOCK_PIXMAP_SEARCH),
  GNOMEUIINFO_SEPARATOR,
  GNOMEUIINFO_ITEM_STOCK(N_("Exit"),N_("Exit"),
			 app_quit,GNOME_STOCK_PIXMAP_EXIT),
  GNOMEUIINFO_END
};


void prepare_app(const char *argv0)
{
  TKString app_title;
  app=new CatalogMainWindow();
  app->app=gnome_app_new((char*)argv0,PACKAGE);


  
  gtk_signal_connect(GTK_OBJECT(app->app),"delete_event",
		     GTK_SIGNAL_FUNC(app_quit),NULL);

  app_title="GNOME Disk Catalog";
  app_title+=TKString(" ",1)+VERSION;
  gtk_window_set_title(GTK_WINDOW(app->app),app_title);
  gtk_widget_set_usize(app->app,450,350);
  gtk_window_set_policy(GTK_WINDOW(app->app), TRUE, TRUE, FALSE);

  gnome_app_create_menus(GNOME_APP(app->app),mainmenu);
  gtk_menu_item_right_justify(GTK_MENU_ITEM(mainmenu[2].widget));

  create_recent_menu();
  // gnome_app_create_toolbar(GNOME_APP(app->app), toolbar);

  // app->table=gtk_table_new(3,7,FALSE);
  app->table=gtk_vbox_new(FALSE,0);
  
  app->list=create_list();
  // gtk_table_attach_defaults(GTK_TABLE(app->table),app->list,0,3,1,7);
  // gtk_box_pack_start(GTK_BOX(app->table),app->list,FALSE,FALSE,0);
  
  app->commandEntry=create_entry();
  // gtk_table_attach_defaults(GTK_TABLE(app->table),app->commandEntry,0,3,0,1);
  gtk_box_pack_start(GTK_BOX(app->table),app->commandEntry,FALSE,FALSE,0);

  GtkWidget *scrolled;

  scrolled = gtk_scrolled_window_new(NULL, NULL);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled),
				  GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
  gtk_container_add (GTK_CONTAINER (scrolled),app->list);

  gtk_box_pack_start(GTK_BOX(app->table),scrolled,TRUE,TRUE,0);
  gtk_widget_show(scrolled);
    
    // statusbar
  app->bar=gnome_appbar_new(TRUE, TRUE,GNOME_PREFERENCES_USER);
  gnome_app_set_statusbar(GNOME_APP(app->app),app->bar);
  gnome_app_set_contents(GNOME_APP(app->app),app->table);

  gnome_app_create_toolbar(GNOME_APP(app->app), toolbar);
  
  // gtk_widget_show(app->list);
  // gtk_widget_show(app->table);
  gtk_widget_show_all(app->app);

  // cout << "adding catalog..." << endl;
  // addCatalog("/home/tero/c++/gnome/disk_catalog/src");
  // ct.readCatalog("/home/tero/tmp/catalog.test");
  // cout << "listing catalog..." << endl;
  // listCatalogs(app->list);
  // ct.saveCatalog("/home/tero/tmp/catalog.test");
  // ct.removeAll();
  // ct.readCatalog("/home/tero/tmp/catalog.test");
  if (app->openCatalog && app->defaultCatalog.length()>0)
    {
      ct.readCatalog(app->defaultCatalog,app->bar,app->useDescription);
      listCatalogs(app->list);
    }
}

int addFile(const char *file,const struct stat *,int flag)
{
  TKString a1,a2;
  if (flag==FTW_F)
    {
      // cout << "file:" << file << endl;
      
      int a=0; // ,b=0;
      a=strlen(file)-1;
      while(file[a] != '/' && a>0) { a--; }
      if (file[a]=='/') a++;
      if (a>0)
	{
	  a1=TKString(file+a);
	  a2=TKString(file,a-1);
	}
      else
	{
	  a1=TKString(file);
	  a2=TKString();
	}
      // cout << a1 << ":" << a2 << endl;
      ct.add(a1,a2,app->currentDisk);
    }
  return 0;
}

void addCatalog(const char *dir,const char *disk)
{
  // cout << "Adding catalog: " << dir << endl;
  app->currentDisk=disk;
  ftw(dir,addFile,10);
  ct.setModified(1);
  if (app->updateList)
    {
      ct.listAll(app->list);
    }
}

void listCatalogs(GtkWidget *list)
{
  gtk_clist_clear(GTK_CLIST(list));
  gtk_clist_freeze(GTK_CLIST(list));
  ct.listAll(list);
  gtk_clist_thaw(GTK_CLIST(list));
}
