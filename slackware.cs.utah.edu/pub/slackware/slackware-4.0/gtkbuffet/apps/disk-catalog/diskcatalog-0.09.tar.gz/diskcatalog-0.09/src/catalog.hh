/*
  GNOME Disk Catalog
  Copyright (C) 1999 Tero Koskinen

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

#include <fstream.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gnome.h>

/* xml support */
#include <gnome-xml/parser.h>
#include <gnome-xml/tree.h>

#include <config.h>
#include "tkstring.hh"
// #include "sll.hh"

#ifndef TK_CATALOG_H
#define TK_CATALOG_H

class TreeNode
{
public:
  TreeNode();
  TreeNode(const char *name,const char *path,const char *disk);
  ~TreeNode();

  TreeNode *getLeft(void) const { return left; }
  TreeNode *getRight(void) const { return right; }
  void set(TreeNode *n,int compareNode=1);
  void removeLeft(void);
  void removeRight(void);

  const TKString *getName(void) const { return & myName; }
  const TKString *getPath(void) const { return & myPath; }
  const TKString *getDisk(void) const { return & myDisk; }
  const TKString *getDescrpt(void) const { return & myDescrpt; }

  TKString _getName(void) const { return myName; }
  TKString _getPath(void) const { return myPath; }
  TKString _getDisk(void) const { return myDisk; }
  TKString _getDescrpt(void) const { return myDescrpt; }

  void setName(TKString & n) { myName=n; }
  void setPath(TKString & p) { myPath=p; }
  void setDisk(TKString & d) { myDisk=d; }
  void setDescrpt(TKString & d) { myDescrpt=d; }
  void setDescrpt(const char *d) { myDescrpt=d; }

  void addToList(GtkWidget *list);
  void addToList(TKString name,GtkWidget *list);
  void addDiskToList(TKString disk,GtkWidget *list);
  void addDiffDiskToList(TKString disk,GtkWidget *list);
  void writeNode(ofstream & fout,int addDescription=1);
  void deleteNode(TKString name,TKString path,TKString disk);

  void saveAsXml(xmlDocPtr & doc,
		 xmlNodePtr & tree,
		 TKString & disk,
		 int addDescription=1);

  void addDescription(TKString & name,
		      TKString & path,
		      TKString & disk,
		      TKString & des);

  int count(void);

private:
  int compare(TreeNode *n); // -1 = n "smaller", 0=equal, 1=n "bigger"
  TreeNode *left;
  TreeNode *right;

  TKString myName;
  TKString myPath;
  TKString myDisk;
  TKString myDescrpt; /* description */
};

class CatalogTree
{
public:
  CatalogTree();
  ~CatalogTree();
  
  void add(TKString & name,TKString & path,TKString & disk);
  void addWithoutCompare(TKString & name,TKString & path,TKString & disk,
			 TKString & description);
  void addWithoutCompare(const char *name,const char *path,const char *disk,
			 const char *description=0);
  void removeAll(void);
  void removeNode(TKString name,TKString path,TKString disk);

  void listAll(GtkWidget *list);
  long count(void);
  void listByName(TKString name,GtkWidget *list);
  void listByDisk(TKString disk,GtkWidget *list);
  void listByDiffDisk(TKString disk,GtkWidget *list);
  int saveCatalog(const char *file,int addDescription=1);
  int saveCatalog(int addDescription=1);
  int readCatalog(const char *file,GtkWidget *bar,int readDescription=1);

  int saveCatalogAsXml(const char *file,int addDescription=1);
  
  void executeCommand(TKString command,GtkWidget *list,GtkWidget *bar=0,int updateList=0);

  void setSaveName(TKString name) { saveName=name; }
  
  /*  TKString getName(TKString path);
  TKString getDisk(TKString name);
  TKString getPath(TKString name); */
  int getModified(void) const { return modified; }
  void setModified(int m) { modified=m; }
private:
  int modified;
  TreeNode *root;
  TKString saveName;
  TreeNode *last;
  
};
#endif
