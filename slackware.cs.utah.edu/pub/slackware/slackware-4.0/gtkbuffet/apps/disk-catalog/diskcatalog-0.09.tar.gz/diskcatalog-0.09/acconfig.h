#undef ENABLE_NLS
#undef HAVE_CATGETS
#undef HAVE_DEVGTK
#undef HAVE_GETTEXT
#undef HAVE_LC_MESSAGES
#undef HAVE_STPCPY
#undef HAVE_LIBSM
#undef HAVE_PROGRAM_INVOCATION_SHORT_NAME
#undef HAVE_PROGRAM_INVOCATION_NAME
#undef PACKAGE
#undef VERSION

#undef HAVE_ESD
#undef HAVE_LIBESD

#undef HAVE_LIBGTOP

/* Define if LibGTop has support for multiple processors. */
#undef HAVE_LIBGTOP_SMP

/* Define if there is no `u_int64_t' and `int64_t'. */
#undef u_int64_t
#undef int64_t

#undef HAVE_DEVGTK

/* LibGTop major, minor and micro version. */
#undef LIBGTOP_MAJOR_VERSION
#undef LIBGTOP_MINOR_VERSION
#undef LIBGTOP_MICRO_VERSION

/* LibGTop version and numerical version code ("1.234.567" -> 1234567). */
#undef LIBGTOP_VERSION
#undef LIBGTOP_VERSION_CODE

/* LibGTop server version, increased each time the protocol changes. */
#undef LIBGTOP_SERVER_VERSION

#undef HAVE_ZVT_TERM_RESET
