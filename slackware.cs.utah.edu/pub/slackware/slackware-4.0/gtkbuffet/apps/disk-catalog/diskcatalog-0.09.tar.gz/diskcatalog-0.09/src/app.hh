/*
  GNOME Disk Catalog
  Copyright (C) 1999 Tero Koskinen

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

#include <gtk/gtk.h>
#include <gnome.h>

#include <fstream.h>

#include <config.h>

#include "catalog.hh"

#ifndef TK_APP_H
#define TK_APP_H

class CatalogMainWindow
{
public:
  CatalogMainWindow() { entryWindow=0; useDescription=0; read_config(); };
  ~CatalogMainWindow() { save_config(); };
  
  void read_config(void);
  void save_config(void);
  void roll_latest(TKString newCatalog);

  GtkWidget *app;
  GtkWidget *bar;
  GtkWidget *table;
  GtkWidget *list;
  GtkWidget *filesel;
  GtkWidget *commandEntry;
  
  GtkWidget *dirEntry;
  GtkWidget *diskEntry;
  GtkWidget *entryWindow;

  // preferences...
  GtkWidget *prefButton1; /* open catalog ar startup */
  GtkWidget *prefButton2; /* use old/new catalog style */
  GtkWidget *prefButton3; /* update list after every command */
  GtkWidget *prefEntry1;
  int openCatalog; /* open catalog at startup */
  int useDescription; /* use description entry */
  int updateList; /* update list after each command */
  int openCatalogTmp;
  int useDescriptionTmp;
  int updateListTmp;

  TKString currentDisk;
  TKString defaultCatalog;
  TKString defaultDir;
  TKString diskName;

  TKString latest[4]; /* latest catalogs */
  /*  GtkWidget *text;
      GtkWidget *entry; */
  
private:
  
};

void create_recent_menu(void);
GtkWidget *create_entry(void);
GtkWidget *create_list(void);
GtkWidget *create_preferences(void);
void show_error(const char *msg);

// callbacks
void toggled_prefButton1_event(GtkWidget *,gpointer *);
void toggled_prefButton2_event(GtkWidget *,gpointer *);
void toggled_prefButton3_event(GtkWidget *,gpointer *);
void apply_prefs_event(GtkWidget *, gpointer *);
void entry_command_event(GtkWidget *,GtkWidget *);
void real_app_quit(GtkWidget *, gpointer *);
void app_quit (GtkWidget *, gpointer *);
void about_cb(GtkWidget*, gpointer *);
void prepare_app(const char *argv0);
void cancel_event(GtkWidget *,GtkWidget *me);
void cancel_dialog_event(GtkWidget *,gpointer );
void open_selected_file_event(GtkWidget *,GtkWidget *);
void open_catalog_event(GtkWidget *, gpointer *);
void open_recent_event(GtkWidget *,gpointer *);
void close_catalog_event(GtkWidget *,gpointer *);
void save_to_selected_file_event(GtkWidget *,GtkWidget *);
void save_as_catalog_event(GtkWidget *,gpointer *);
void save_catalog_event(GtkWidget *,gpointer *);
void add_dir_to_catalog_event(GtkWidget *,GtkWidget *);
void add_to_catalog_event(GtkWidget *,gpointer *);
void search_dialog_clicked_event(gchar *,gpointer );
void search_from_catalog_event(GtkWidget *,gpointer *);
void preferences_event(GtkWidget *, gpointer *);

// other functions
int addFile(const char *file,struct stat *sb,int flag);
void addCatalog(const char *dir,const char *disk);
void listCatalogs(GtkWidget *list);

#endif
