// TKString.hh
//
// (c) Tero Koskinen 1999
// My own string class
//
// Version 0.1.1

#include <iostream.h>
#include <string.h>
#include <ctype.h>

#ifndef TK_STRING_H
#define TK_STRING_H

class TKString
{
public:
  TKString();
  TKString(int size);
  TKString(const char *buffer,int size);
  TKString(const TKString & t);
  TKString(const char *);
  ~TKString();
    
  TKString & operator=(const TKString & t);
  TKString & operator=(const char *str);
  char & operator[](unsigned int p);
  char operator[](unsigned int p) const;
  // bool isEmpty(void) const;
  unsigned int length(void) const;
  const char *getStr(void) const { return myStr; }
  char *getStr(void) { return myStr; }
    
  TKString operator+(const TKString &);
  TKString operator+(const char *str);
  void operator+=(const TKString &);
  void operator+=(const char *str);
    
  operator const char*(void) const;
  
  void setDelete(int d) { deleteMyStr=d; }
    
  /* friend TKString operator+(const TKString & s1,const TKString & s1); */
  /* friend TKString operator+(const char *str,const TKString & s1); */


  char *myStr;
private:
  /*  char *myStr; */
  unsigned int myLength;
  int deleteMyStr;
};

// these would make your a little bit easier...
bool operator==(const TKString & s1,const TKString & s2);
/* {
  return strcmp(s1.getStr(),s2.getStr())==0;
  } */

bool operator>(const TKString & s1,const TKString & s2);
bool greaterThan(char *s1,char *s2);
  /* {
  int a=0,b=0,c=0;
  a=s1.length();
  b=s2.length();
  if (a<b)
    c=a;
  else
    c=b;
  for (int i=0;i<c;i++)
    {
      if (s1[i]>s2[i])
	return 1;
      else if (s1[i]<s2[i])
	return 0;
    }
  if (a>b)
    return 1;
  return 0;
}
*/
bool operator<(const TKString & s1,const TKString & s2);
  /* {
  int a=0,b=0,c=0;
  a=s1.length();
  b=s2.length();
  if (a<b)
    c=a;
  else
    c=b;
  for (int i=0;i<c;i++)
    {
      if (s1[i]<s2[i])
	return 1;
      else if (s1[i]>s2[i])
	return 0;
    }
  if (a<b)
    return 1;
  return 0;
  } */


bool operator!=(const TKString & s1,const TKString & s2);
  /* {
  return strcmp(s1.getStr(),s2.getStr())!=0;
  } */

TKString operator+(const char *str,const TKString & s1);
/* TKString operator+(const TKString & s1,const TKString & s1); */

// some little utils next
int wordLength(const char *s);
int stringLength(const char *s);
int nextWord(const char *s);
int nextString(const char *s);
TKString giveNextWord(TKString & sentence);

#endif // TK_STRING_H

