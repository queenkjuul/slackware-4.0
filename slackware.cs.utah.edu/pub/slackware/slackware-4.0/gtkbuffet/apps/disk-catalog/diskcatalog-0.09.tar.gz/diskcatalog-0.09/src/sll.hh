
#ifndef TK_SINGLE_LIST_H
#define TK_SINGLE_LIST_H

typedef enum
{
  SLL_OK,
  SLL_ERR,
  SLL_NULL_POINTER,
  SLL_OUT_OF_MEMORY,
  SLL_DATA_EXISTS,
  SLL_UNKNOWN
} SLL_Return;

template <class T>
class SingleLinkedList
{
public:
  SingleLinkedList();
  ~SingleLinkedList();

  SLL_Return add(T *t,int addFirst=0);
  void deleteAll(void);

  T *getNext(void);
  T *getFirst(int setNewCurrent=1);
  T *get(int getFirstData=0);

  void begin(void) { current=root; }
private:
  
  class SLL_Node {
  public:
    SLL_Node(T *d) { data=d;next=0; }
    SLL_Node() { next=0;data=0; }
    ~SLL_Node() { if (data) delete data; }
    
    SLL_Node *getNext(void) { return next; }
    void setNext(SLL_Node *p) { if (next) next->setNext(p); else next=p; }
    T *getData(void) { return data; }
    int setData(T *d,int overWrite=0) { if (!data) data=d; else if (overWrite) { delete data; data=d; } else return SLL_DATA_EXISTS; return SLL_OK; }
  private:
    SLL_Node *next;
    T *data;
  };
  
  SLL_Node *root;
  SLL_Node *current;
};

template <class T>
SingleLinkedList<T>::SingleLinkedList():
  root(0)
{ }

template <class T>
SingleLinkedList<T>::~SingleLinkedList()
{
  deleteAll();
}

template <class T>
SLL_Return SingleLinkedList<T>::add(T *t,int addFirst)
{
  SLL_Node *p;
  p=new SLL_Node(t);
  if (!p)
    return SLL_OUT_OF_MEMORY;
  if (!root)
    {
      root=p;
      current=root;
    }
  else
    {
      SLL_Node *o;
      if (addFirst)
	{
	  o=root;
	  root=p;
	  p->setNext(o);
	}
      else
	{
	  root->setNext(p);
	}
    }
  return SLL_OK;
}

template <class T>
void SingleLinkedList<T>::deleteAll(void)
{
  SLL_Node *p;
  SLL_Node *o;
    
  if (root)
    {
      p=root;
      while(p)
	{
	  o=p->getNext();
	  delete p;
	  p=o;
	}
      root=0;
      current=0;
    }
}

template <class T>
T *SingleLinkedList<T>::getNext(void)
{
  SLL_Node *p;
  if (!root)
    return 0;
  else if (!root && !current)
    return 0;
  if (current)
    {
      p=current;
      current=current->getNext();
      return p->getData();
    }
  /*	else if (root)
	{
	current=root->getNext();
	return root->getData();
	} */
  return 0;
}

template <class T>
T *SingleLinkedList<T>::getFirst(int setNewCurrent)
{
  if (root)
    {
      if (setNewCurrent)
	current=root->getNext();
      return root->getData();
    }
  return 0;
}

template <class T>
T *SingleLinkedList<T>::get(int getFirstData)
{
  if (getFirstData)
    {
      return getFirst(0);
    }
  return getNext();
}

#endif

	    
