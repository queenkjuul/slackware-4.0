/* incluye los pixmpas */
#include "xpm/about.xpm"
#include "xpm/azul.xpm"
#include "xpm/rojo.xpm"
#include "xpm/verde.xpm"
#include "xpm/negro.xpm"
#include "xpm/winner.xpm"
#include "xpm/gameover.xpm"
#include "xpm/fondo.xpm"
#include "xpm/icono.xpm"


