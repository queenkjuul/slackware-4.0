#ifndef __BN_SERVER__
#define __BN_SERVER__

#include <gnome.h>
#include "protocol.h"

#define BNVERH 0
#define BNVERL 71
#define BNVERM 1

typedef struct tabla_typ
{
	int  x,y;
	char p[10][10];
} tabla;

struct st_datos 
{
	gchar server_name[50];			/* server name */
	gint debug;					/* debug mode */
	gint port;					/* donde va el port */
	gint nro_tot[MAXPLAYER];		/* 1 int por jugador */
	gint nro_fd[MAXPLAYER];			/* 1 file descriptor por jugador */
	gint hits[MAXPLAYER];			/* how many hits has a player received */
	tabla table[MAXPLAYER];
	gchar names[MAXPLAYER][MAXNAMELEN]; /* other players's name */
	gint tag[MAXPLAYER];			/* gdk que lee */
	gchar robotname[MAXNAMELEN];		/* Nombre del robot */
};

struct st_datos usuario;

char tempbuf[MSGMAXLEN];		/* varible general */
						/* La necesito ? */

#endif __BN_SERVER__
