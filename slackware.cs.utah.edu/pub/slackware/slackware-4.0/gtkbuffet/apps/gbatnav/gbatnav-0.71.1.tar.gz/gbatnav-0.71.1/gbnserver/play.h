#ifndef __BN_PLAY__
# define __BN_PLAY__

gint play_batnav( gint );
gint quejugador( gint );

#endif __BN_PLAY__
