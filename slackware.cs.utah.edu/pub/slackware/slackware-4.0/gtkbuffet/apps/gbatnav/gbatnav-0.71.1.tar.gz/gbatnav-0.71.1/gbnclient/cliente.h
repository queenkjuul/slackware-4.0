/*
 * Batalla Naval (c) 1995,96,97,98 Ricardo Quesada
 * (rquesada@dc.uba.ar)
 * 
 * Funciones del Batalla Naval.
 * 
 */


#ifndef  __BN_CLIENTE__
# define __BN_CLIENTE__

# ifdef __cplusplus
extern "C" {
# endif __cplusplus

# define GBNVERH 0
# define GBNVERL 71
# define GBNVERM 1

# define LARGO 20
# define ANCHO 20
   
# include <sys/types.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include "protocol.h"


/*
 * Estructuras y Funciones Principales
 */
struct usuario 
{
	gchar server_name[50];             /* server name */
	gint port;                         /* server port */
	gint random;			     /* Random Number 0.59.38 */	
	gchar nombre[MAXNAMELEN];          /* user name */
	gchar names[MAXPLAYER][MAXNAMELEN];/* other players's name */
   
	gint play;                         /* already playing ? */
	gint numjug;                       /* number of player */
	gint usrfrom;                      /* player who is owner of enemy window */
   
	gchar tomsg[MSGMAXLEN];            /* usuadas para mandar mensajes */
	gint  towho;
	gint  lecho;                       /* local echo */
   
	gchar status[6][16];               /* nombre de los status */
	gint  hide;                        /* flag de hide my board  */
   
	gint tag;                          /* propio de GDK_INPUT_ADD */
	gchar tempclit[MSGMAXLEN];         /* Variable usada por el cliente */

	gint pages[MAXPLAYER];             /* Variable de las paginas . only GTK ? */
	gint autorobot;                    /* Autolanzamiento del robot */				
	gint debug_level;                  /* Debug level usado por ttyfill */
} usuario;

/* variables que tienen que ver al juego propiamente dicho */
gint sock;
struct sockaddr_in server;
struct hostent *host_info;
gchar mitabla[10][10];          /* mi tabla de barcos */
gchar barquitos[4];             /* tama�os de los barcos 1 de 4, 2 de 3, etc. */
gchar bnsup;                    /* usado por bnwrite */
gchar temp[10];                 /* Un temporal que se puede borrar ? */


/* ---- Variables Globales ---- */
/* Variables - GTK */
/* contenedores */
GtkWidget *window;
GtkWidget *hbox;
GtkWidget *vbox;

/* left */
GtkWidget *notebook_left;
GtkWidget *label_left; 
GtkWidget *drawing_left;
GtkWidget *hbox_text_help;
GtkWidget *text_help;
GtkWidget *vscrollbar_help;

/* center */
GtkWidget *vbox_buttons;
GtkWidget *button_connect;
GtkWidget *button_disconnect;
GtkWidget *button_sendboard;
GtkWidget *button_start;
GtkWidget *button_sendmsg;
GtkWidget *button_status;
GtkWidget *button_config;
GtkWidget *button_quit;

/* right */
GtkWidget *notebook_right;
GtkWidget *label_right_about;
GtkWidget *drawing_right_about;
GtkWidget *label_right[MAXPLAYER];
GtkWidget *label_right2[MAXPLAYER];
GtkWidget *drawing_right[MAXPLAYER];

/* otros */
GtkWidget *hbox_text;
GtkWidget *vscrollbar;
GtkWidget *separator;
GtkWidget *text;


/* Pixmaps */
GdkPixmap *barco1 ;
GdkPixmap *barco1_t ;
GdkPixmap *barco1_h ;
GdkPixmap *barco2h ;
GdkPixmap *barco2h_t ;
GdkPixmap *barco2h_h ;
GdkPixmap *barco2v ;
GdkPixmap *barco2v_t ;
GdkPixmap *barco2v_h ;
GdkPixmap *barco3h ;
GdkPixmap *barco3h_t ;
GdkPixmap *barco3h_h ;
GdkPixmap *barco3v ;
GdkPixmap *barco3v_t ;
GdkPixmap *barco3v_h ;
GdkPixmap *barco4h ;
GdkPixmap *barco4h_t ;
GdkPixmap *barco4h_h ;
GdkPixmap *barco4v ;
GdkPixmap *barco4v_t ;
GdkPixmap *barco4v_h ;

GdkPixmap *fondo ;
GdkPixmap *agua ;
GdkPixmap *about_pix ;
GdkPixmap *icono ;
GdkBitmap *mask ;

GtkWidget *hbox_status;
GtkWidget *statusbar_left;
GtkWidget *statusbar_right;

/* Usadas por Configure */
GtkWidget *conf_spinner_port;
GtkWidget *conf_entry_server;
GtkWidget *conf_entry_name;
GtkWidget *conf_check_button;
GtkWidget *conf_cb_ttyfill;

/* Usadas por Sendmsg */
GtkWidget *send_spinner_towho;
GtkWidget *send_entry_message;
GtkWidget *send_toggle_button;


   
# ifdef __cplusplus
}
# endif __cplusplus
   
#endif __BN_CLIENTE__
