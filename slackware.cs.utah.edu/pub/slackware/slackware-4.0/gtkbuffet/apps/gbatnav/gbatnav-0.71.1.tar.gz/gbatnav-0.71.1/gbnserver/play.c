/*
	play.c
	Funcion que se encarga de poner las reglas al juego y todo eso
*/
#include <config.h>
#include <gnome.h>
#include <unistd.h>
#include "protocol.h"	
#include "server.h"
#include "robot.h"
#include "robot_cliente.h"		/* Solo para saber la version */
#include "g_interface.h"


gint
quejugador( gint fd )
{
	gint i ;
	for(i=0;i<MAXPLAYER;i++)
	{
		if(usuario.nro_fd[i]==fd )
			break;
	}
	if( i==MAXPLAYER )
	{
		printf("Error en quejugador.\n");
		return 0;
	}
	return i;
}


/* Reading boards from player x */
void bnrea( int fd, struct protocolo *proto)
{
	int x,j;
	char outbuf[MSGMAXLEN];
	
	x=proto->bnptip1-1;  /* which player do you want to read */
	j=quejugador( fd );
	textfill(j,_("Reading board from player %i"),x+1);
	if( usuario.nro_tot[x]>=PLAY || usuario.nro_tot[x]<=PERDIO ) 
	{
		rtable(outbuf,x,proto->bnptip2);
		bnwrite(fd,outbuf,BNREA,x,0,j);       /* i'm sending the board */
	}
	/*
	Me pidio leer por un pibe que no esta jugando con board
	De esta manera le digo (sobretodo a los robots) que me pidio leer
	por uno que no va.
	*/
	else 
	{
		textfill(j,_("Reading from dead player"));
		bnwrite(fd,outbuf,BNREA,-1,0,j);
	}	
}

/* Sending board (after connect) */
void bnwri( int fd, struct protocolo *proto)
{
	int i,j;
	char outbuf[MSGMAXLEN];

	j=quejugador( fd );

	for(i=0;i<MAXPLAYER;i++) 
	{
		if( usuario.nro_tot[i]==PLAY || usuario.nro_tot[i]==TURN )
		break;
	}
	if(i!=MAXPLAYER) 
	{ /* im sorry but people is playing */
		textfill(j,_("Sending a board... Sorry, people are playing"));
		bnwrite(fd,outbuf,BNWAI,0,0,0);
	}
	else 
	{
		if( wtable(j,proto)==TRUE)  
		{
			textfill(j,_("Sending a valid board"));
			usuario.nro_tot[j]=BOARD;
			outbuf[0]=1;
			broadcast(outbuf,BNCON,CONNEC,j,j+1,0,0);
		}
		else 
		{
			textfill(j,_("Sending and invalid board"));
			usuario.nro_tot[j]=CONNEC;
			outbuf[0]=0;
		}
		bnwrite(fd,outbuf,BNWRI,0,0,0);
	}
}


/* Te dice que jugador sos (De 0 a MAXPLAYER)*/
void bnjug(int fd, struct protocolo *proto)
{
	gint i;
	gchar outbuf[MSGMAXLEN];

	i = quejugador( fd );

	if(proto->bnpver<BNPVERPLAY)
	{
			textfill(i,_("*** Error: old client. Protocol version: 0x%X. Aborting..."),proto->bnpver);
			sprintf(outbuf,_("Error: update client from http://www.pjn.gov.ar/~rquesada/batnav.html"));
			bnwrite(fd,outbuf,BNMSG,i+1,0,i+1);
			bnexit(i,0);
			gdk_input_remove( usuario.tag[i] );
			close(fd);
	}
	else  
	{
		if( proto->bnpver!=BNPVER )
		{
			textfill(i,_("*** Warning: Protocol version: 0x%X."),proto->bnpver);
			sprintf(outbuf,_("Warning: Different version of protocol"));
			bnwrite(fd,outbuf,BNMSG,i+1,0,i+1);
		}
		strncpy(usuario.names[i],proto->bnpmsg,MAXNAMELEN-1);
		strcpy(outbuf,usuario.server_name);
		bnwrite(fd,outbuf,BNJUG,i+1,0,i+1);

		switch(proto->bnptip1)
		{
			case XCLI:
				textfill(i,_("Using XView client version %i.%i"),proto->bnptip2,proto->jugador);
				break;
			case NCLI:
				textfill(i,_("Using ncurses client version %i.%i"),proto->bnptip2,proto->jugador);
				break;
			case WCLI:
				textfill(i,_("Using Windows client version %i.%i"),proto->bnptip2,proto->jugador);
				break;
			case GCLI:
				textfill(i,_("Using GTK client version %i.%i"),proto->bnptip2,proto->jugador);
				break;
			case GNCLI:
				textfill(i,_("Using GNOME client version %i.%i.%i. Protocol ver: 0x%X"),proto->bnptip2,proto->jugador,proto->bnpmsg[MSGMAXLEN-1],proto->bnpver);
				break;
			case RCLI:
				textfill(i,_("Using robot client version %i.%i.%i. Protocol ver: 0x%X"),proto->bnptip2,proto->jugador,proto->bnpmsg[MSGMAXLEN-1],proto->bnpver);
				break;
			default:
				textfill(i,_("Using unknown client version %i.%i"),proto->bnptip2,proto->jugador);
				break;
		}
	}	
}

/* Disparar en x,y */
void bnhit(int fd, struct protocolo *proto)
{
	int i,j,x,y;
	char outbuf[MSGMAXLEN];

	j=quejugador(fd);

	if(usuario.nro_tot[j]==TURN) 
	{  /* Esta diparando al que le toca ? */
		x=outbuf[0]=proto->bnpmsg[0];
		y=outbuf[1]=proto->bnpmsg[1];
		textfill(j,_("Firing at %i,%i"),x+1,y+1);
		for(i=0;i<MAXPLAYER;i++) 
		{
			if(usuario.nro_tot[i]==PLAY || usuario.nro_tot[i]==PERDIO)
			{ /* Solo a los que esten en PLAY o PERDIO. TURN es el que dispara */ 
				if(!eshundido(i,x,y))
				{	/* no es hundido */
					if(usuario.table[i].p[x][y]>=BARCO) 
					{
						outbuf[2]=TOCADO;
						usuario.table[i].p[x][y]=TOCADO;
					}
					else  /* usuario.table[i].p[x][y]<=NOBARCO */
					{
						outbuf[2]=AGUA;
						usuario.table[i].p[x][y]=AGUA;
					}
					bnwrite(usuario.nro_fd[i],outbuf,BNHIT,0,0,i+1);
				}
			}
		}

		/* Siguiente jugador*/
		usuario.nro_tot[j]=PLAY;  /* Se te acabo el turno */
		for(i=j+1;i<MAXPLAYER;i++) 
		{
			if(usuario.nro_tot[i]==PLAY)
			break;
		}
		if(i==MAXPLAYER) 
		{                            /* llego al ultimo */
			for(i=0;i<MAXPLAYER;i++) 
			{ /* Busca al primero */
				if(usuario.nro_tot[i]==PLAY)
				break;
			}
		}
		if( (i==j) || (i==MAXPLAYER)) 
		{     /* Si el turno es para el mismo, entonces gano*/
			textfill(i,_("I'm the winner"));
			bnwrite(usuario.nro_fd[i],outbuf,BNWIN,0,0,i+1);
			sprintf(outbuf,"%s[%i] is the winner.",usuario.names[i],i+1);
			broadcast(outbuf,BNEXT,CONNEC,i,i+1,2,0); 
			broadcast(outbuf,BNOVR,CONNEC,-1,0,0,0);

			/* Se acabo el juego, limpiar tableros... */
			for(i=0;i<MAXPLAYER;i++)
			{
				if(usuario.nro_tot[i]>=CONNEC)
				{  /* Si el usuario estaba conectado limpiar todo */
					usuario.nro_tot[i]=CONNEC;
					usuario.hits[i]=0;
					ctable(i);
				}
			}
		}
		else  
		{ /* El turno no es para el mismo */
			usuario.nro_tot[i]=TURN; /* siguiente turno */
			bnwrite(usuario.nro_fd[i],outbuf,BNTRN,0,0,i+1);
			broadcast(outbuf,BNWHO,PLAY,i,i+1,0,0); /* informa de quien es */
			textfill(i,_("It's my turn"));
		}
	}
	else 
	{ /* It's not your turn */
		textfill(j,_("Firing but it's not your turn"));
		return;
	}
}

/* Start the game */
void bnstr( int fd, struct protocolo *proto)
{
	int i,j,x;
	char outbuf[MSGMAXLEN];

	j=quejugador(fd);

	x=0; /* used as a temp variable */
	for(i=0;i<MAXPLAYER;i++) 
	{
		if(usuario.nro_tot[i]==BOARD)
		x++;
	}
	if(x<2)  
	{ /* Se requieren al menos 2 jugadores */
		bnwrite(usuario.nro_fd[j],outbuf,BNSOL,0,0,j);
	}
	else  
	{
		textfill(j,_("Starting game"));
		for(i=0;i<MAXPLAYER;i++) 
		{
			outbuf[i]=usuario.nro_tot[i];  /* show status of other players */
			strcpy(&outbuf[MAXPLAYER+i*MAXNAMELEN],usuario.names[i]);
		}
		for(i=0;i<MAXPLAYER;i++) 
		{ /* Cambia el estado de BOARD a PLAY */
			if(usuario.nro_tot[i]==BOARD) 
			{ 
				bnwrite(usuario.nro_fd[i],outbuf,BNSTR,0,0,i+1);
				usuario.nro_tot[i]=PLAY; /* started */
			}
		}
		for(i=0;i<MAXPLAYER;i++) 
		{ /*  Asigna el turno al siguiente */
			if(usuario.nro_tot[i]==PLAY) 
			{
				bnwrite(usuario.nro_fd[i],outbuf,BNTRN,0,0,i+1);
				usuario.nro_tot[i]=TURN;
				break; /* started */
			}
		}
	}
}


/************************************************************************
	play_batnav
	Funcion principal de este modulo
*************************************************************************/
gint play_batnav( gint fd ) 
{
	gint i,j,x,y;
	struct protocolo proto;
	gchar outbuf[MSGMAXLEN];
   
	if( read(fd,&proto,MAXLEN) != MAXLEN ) 
		return(-1);

	if( (proto.bnphead[0]!='B') || (proto.bnphead[1]!='N') || (proto.bnphead[2]!='P'))
		return(-1);
   
	j=quejugador( fd );
   
	switch (proto.bnptip0) 
	{
		case BNREA:
			bnrea(fd,&proto);
			break;
		case BNWRI:
			bnwri(fd,&proto);
			break;
		case BNJUG:
			bnjug(fd,&proto);
			break;
		case BNVER:
			textfill(j,_("Asking server version"));
			outbuf[0]=BNVERH;
			outbuf[1]=BNVERL;
			outbuf[2]=BNVERM;
			bnwrite(fd,outbuf,BNVER,0,0,0);
			break;
		case BNMSG:
			textfill(j,_("Sending message"));
			sprintf(outbuf,"[%s_%i] ",usuario.names[j],j+1);  /* from who */
			strcat(outbuf,proto.bnpmsg);
			if(proto.bnptip1==0)
				broadcast(outbuf,BNMSG,CONNEC,j,0,0,j+1);
			else 
			{
				if(usuario.nro_tot[proto.bnptip1-1]>=1)
					bnwrite(usuario.nro_fd[proto.bnptip1-1],outbuf,BNMSG,0,0,j+1);
			}
			if(proto.bnptip2==1)         
				bnwrite(fd,outbuf,BNMSG,0,0,j+1);
			break;
		case BNTST:
			textfill(j,_("Testing"));
			bnwrite(fd,outbuf,BNTST,0,0,0);
			break;
		case BNEXT:
			bnexit(j,0);
			textfill(j,_("Quiting the game"));
			gdk_input_remove( usuario.tag[j] );
			close(fd);
			break;
		case BNHIT:
			bnhit(fd,&proto);
			break;
		case BNSTR:
			bnstr(fd,&proto);
			break;
		case BNSTS: 
			textfill(j,_("Asking status"));
			for(i=0;i<MAXPLAYER;i++) 
			{
				outbuf[i]=usuario.nro_tot[i];
				strcpy(&outbuf[MAXPLAYER+i*MAXNAMELEN],usuario.names[i]);
			}
			bnwrite(fd,outbuf,BNSTS,0,0,i+1);
			break;
		case BNRON:	/* Empezar con el Robot */
			textfill(j,_("Starting robot version %s"),ROBOTVER);
			cliente.autostart = (int) proto.bnpmsg[0];
			sprintf(outbuf,_("Starting robot version %s"),ROBOTVER);
			bnwrite(fd,outbuf,BNRON,0,0,i+1);
			printf("forking...\n");
			if( fork()==0 )
			{	/* soy el hijo */
				  robot_init();
				  textfill(j,_("Bug in BNRON")); 
			}
			break;
		case BNSCR:	/* Envio de score */
			textfill(j,_("BNSCR: Scores not implemented yet"));
			break;
		default:
			textfill(j,_("default:Unknown code %X"),proto.bnptip0);
			break;
	}
	return 0;
}
