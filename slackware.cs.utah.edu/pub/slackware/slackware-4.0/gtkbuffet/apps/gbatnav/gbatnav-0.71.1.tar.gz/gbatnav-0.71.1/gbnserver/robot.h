int robot_init( void );
