#ifndef __BN_CHECK__
# define __BN_CHECK__

int algoritmo(int num_jug)  ;

#endif __BN_CHECK__
