
/* 
	Includes de gbnclient
	Funcion que chequea el port y esas cosas
*/


#ifndef  __BN_GBNCLIENT__
# define __BN_GBNCLIENT__

# ifdef __cplusplus
extern "C" {
# endif __cplusplus

gint 
sacar_usrpage( gint jugador );

gint
buscar_usr( gint usr );

gint 
expose_event( GtkWidget *widget, GdkEventExpose *event );

gint 
button_press_event (GtkWidget *widget, GdkEventButton *event);

gint 
expose_event_about (GtkWidget *widget, GdkEventExpose *event);

gint 
page_switch( GtkWidget *widget, GtkNotebookPage *page, gint page_num );

gint 
expose_event_right( GtkWidget *widget, GdkEventExpose *event );

gint
button_press_event_right( GtkWidget *widget, GdkEventButton *event );

size_t 
bnwrite(int fd,char *buf,char tip0,char tip1,char tip2,char jugyo );

void 
iwtable( char *dest);

void
filtermiboard();

void
putintemp( char *table );

void
showboard( GdkPixmap *pixmap );

void
fillboard( char *filltable, int a );

void
inteliclient( char *table);

void
destroy_window( GtkWidget *widget, GtkWidget **window );

void
do_exit( GtkWidget *widget, void *data );

int
play( void );

void
status( );

gint
configure_apply( GtkWidget *widget, GtkWidget *window );

gint
configure_ok( GtkWidget *widget, GtkWidget *window );

void
configure( void );

gint
sendmsg_ok( GtkWidget *widget, GtkWidget *window );

void
bnsendmsg( void );

void
init_datos( void );

int
init_cliente( void );

int init_robot( void );

   
# ifdef __cplusplus
}
# endif __cplusplus

# endif __BN_GBNCLIENT__
