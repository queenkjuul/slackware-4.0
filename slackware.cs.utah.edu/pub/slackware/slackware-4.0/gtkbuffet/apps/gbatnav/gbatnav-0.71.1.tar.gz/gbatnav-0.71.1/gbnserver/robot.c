/*
 * Codigo del robot
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <signal.h>

#include "server.h"
#include "robot_proceso.h"
#include "robot_cliente.h"

int robot_init( void )
{
	struct sockaddr_in server;
	struct hostent *host_info;
	struct protocolo proto;
	char outbuf[MSGMAXLEN];
	int i;
	fd_set readfds;
#ifndef __linux
	struct timeval tout=  { 0,250000 };
#else
	struct timeval tout;
#endif

	printf("Inicializando robot...");
	cliente.random=gnome_config_get_int("/gbnserver/data/random=2004");
	cliente.sock=socket(AF_INET,SOCK_STREAM,0);
	if(cliente.sock <0) 
	{
		printf("Error creating stream socket\n");
		return(1);
	}
	host_info = gethostbyname("localhost");
	if(host_info==NULL) 
	{
		close(cliente.sock);       
		printf("Unknown localhost.\n");
		return(2);
	}
	server.sin_family=host_info->h_addrtype;
	memcpy( (char*) &server.sin_addr, host_info->h_addr,host_info->h_length);
	server.sin_port=htons(usuario.port);
     
	if(connect(cliente.sock,(struct sockaddr *)&server,sizeof(server))< 0) 
	{
		close(cliente.sock);          
		printf("El servidor no esta corriendo?.\n");
		return(2);
	}
     
	strncpy(outbuf,usuario.robotname,MAXNAMELEN);
	outbuf[MSGMAXLEN-1]=ROBOTVERM;
	bnwrite(cliente.sock,outbuf,BNJUG,RCLI,ROBOTVERH,ROBOTVERL);
	printf("OK\n");

	while(1)
	{
		FD_SET(cliente.sock,&readfds);
		if(select(FD_SETSIZE,&readfds,NULL,NULL,&tout)) 
		{
			if( read(cliente.sock,&proto,MAXLEN) == MAXLEN)
				  proceso(&proto);
			else
			{
				printf("Robot: maxlen!=maxlen... killing myself\n");
				kill(getpid(),SIGKILL);
			}
		}
	}
}

void robot_play( void )
{
}

void robot_cerebro( void )
{
}
