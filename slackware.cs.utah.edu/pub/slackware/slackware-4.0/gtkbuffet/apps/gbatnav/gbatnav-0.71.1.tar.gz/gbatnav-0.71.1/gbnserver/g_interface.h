#ifndef __BN_G_INTERFACE__
#define __BN_G_INTERFACE__

#include <stdarg.h>
#include <gnome.h>
#include "protocol.h"

void
init_screen();

void
textfill( gint, gchar *, ... );

#endif __BN_G_INTERFACE__
