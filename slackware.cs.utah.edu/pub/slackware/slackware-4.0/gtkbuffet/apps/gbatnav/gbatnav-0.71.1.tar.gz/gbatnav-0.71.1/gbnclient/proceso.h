/* 
	Includes de proceso
	Funcion que chequea el port y esas cosas
*/


#ifndef  __BN_PROCESO__
# define __BN_PROCESO__

# ifdef __cplusplus
extern "C" {
# endif __cplusplus


void 
proceso( gpointer data, gint sock, GdkInputCondition GDK_INPUT_READ );

   
# ifdef __cplusplus
}
# endif __cplusplus

# endif __BN_PROCESO__
