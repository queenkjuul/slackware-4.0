/****************************************************************************
 	Funcion basada en la del cliente.
	Comportamiento del Robot a nivel BNP
 ****************************************************************************/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <signal.h>
#include <netdb.h>
#include <stdio.h>
#include <syslog.h>
#include <errno.h>
#include <string.h>

#include <config.h>
#include <gnome.h>

#include "robot_cliente.h"
#include "robot_random_board.h"
#include "robot_ai.h"
#include "protocol.h"

/* convierte un char[10][10] a un char[100] */
void 
iwtable( char *dest)
{
	gint i,x,y;
	x=0;
	y=0;

	for(i=0;i<100;i++) 
	{
		dest[i]=cliente.mitabla[x][y];
		x++;
		if(x>=10) 
		{ 
			x=0;
			y++;
		}
	}
}
/* convierte un char[100] a un char[10][10] */
void 
poner_en_board( gint d, char *orig)
{
	gint i,x,y;
	x=0;
	y=0;

	for(i=0;i<100;i++) 
	{
		cliente.boards[d][x][y]=orig[i];
		x++;
		if(x>=10) 
		{ 
			x=0;
			y++;
		}
	}
}

void ttyfill(char *msg)
{
/*	  printf("Robot_%i: %s",cliente.numjug,msg); */
}

void
que_usrfrom( void )
{ /* Esta funcion tiene algo que ver con el AI */
	gint i;
	
	for(i=cliente.numjug;i<MAXPLAYER;i++)
	{
		if( cliente.estados[i]>=BOARD )
		{
			cliente.usrfrom=i;
			return;
		}
	}
	for(i=0;i<cliente.numjug;i++)
	{
		if( cliente.estados[i]>=BOARD )
		{
			cliente.usrfrom=i;
			return;
		}
	}
	ttyfill("que_usrfrom:Error, aca no tendria que llegar\n");
}


void
bn_wri( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];
	if(proto->bnpmsg[0]==1) /* Board OK */
	{
		ttyfill("Ready to play\n");
		if(cliente.autostart)
			bnwrite(cliente.sock,outbuf,BNSTR,0,0,cliente.numjug);
	}
     	else /* Board not OK */
	{
		ttyfill("Board not OK... this is a bug... killing myself\n");
		kill(getpid(),SIGKILL);
	}
}

void
bn_str( struct protocolo *proto )
{
	gint i;

	for(i=0;i<MAXPLAYER;i++)
		cliente.estados[i]=proto->bnpmsg[i];

	que_usrfrom();
}

void
bn_ext( struct protocolo *proto )
{
	gint i;
	gchar outbuf[MSGMAXLEN];

	i=proto->bnptip1-1;
	cliente.estados[i]=DISCON;

	que_usrfrom();
}

void
bn_jug( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];

	cliente.numjug=proto->bnptip1;
	sprintf(outbuf,"Connected to server:%s. You are player number:%i\n",proto->bnpmsg,cliente.numjug);
	ttyfill(outbuf);
	bnwrite(cliente.sock,outbuf,BNVER,0,0,cliente.numjug);
}

void
bn_ver( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];

	sprintf(outbuf,"bnserver version:%i.%i.%i\n",proto->bnpmsg[0],proto->bnpmsg[1],proto->bnpmsg[2]);
	ttyfill(outbuf);
	generar();
	iwtable( outbuf );
	bnwrite(cliente.sock,outbuf,BNWRI,cliente.numjug,0,cliente.numjug);
}

void 
bn_msg( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];

	sprintf(outbuf,"%s\n",proto->bnpmsg);
	ttyfill(outbuf);
}

void
bn_all()
{
	ttyfill("Server is full. Try later. Killing myself\n");
	kill(getpid(),SIGKILL);
}

void
bn_wai()
{
	ttyfill("People are playing.Try later. Killing myself\n");
	kill(getpid(),SIGKILL);
}

void
bn_trn()
{
	gchar outbuf[MSGMAXLEN];
	bnwrite(cliente.sock,outbuf,BNREA,cliente.usrfrom+1,0,cliente.numjug);
}

void
bn_rea( struct protocolo *proto )
{
	gint x,y;	
	gint a;
	gchar outbuf[MSGMAXLEN];

	a=proto->bnptip1;			/* Due�o de la board que estoy leyendo */
	if(a==cliente.usrfrom)
	{
		poner_en_board(a,proto->bnpmsg);
		robot_ai(&x,&y);	
		outbuf[0]=x; 
		outbuf[1]=y; 
		bnwrite(cliente.sock,outbuf,BNHIT,0,0,cliente.numjug);
	}
	else
		bnwrite(cliente.sock,outbuf,BNREA,cliente.usrfrom+1,0,cliente.numjug);
}


void
bn_los()
{
	ttyfill("You lost!\n");
	return;
}

void
bn_win()
{
	ttyfill("You are the winner!\n");
	return;
}

void
bn_over()
{
	ttyfill("Game Over. Killing myself\n");
	kill(getpid(),SIGKILL);
}


void 
proceso( struct protocolo *proto )
{
	switch(proto->bnptip0)
	{
		case BNREA: /* Read from player bnptip1 */
			bn_rea( proto );
     			break;
		case BNWRI: /* Check board */
			bn_wri( proto );
     			break;
   		case BNJUG: /* Connecting */
			bn_jug( proto );
			break ;	
   		case BNVER: /* Server version */
     			bn_ver( proto );	
			break;
   		case BNMSG: /* Receiving message */
     			bn_msg( proto );	
			break;
		case BNSTR: /* The game starts now */
			bn_str( proto );
			break;
		case BNEXT: /* Player not playing any more */
			bn_ext( proto );
			break;
   		case BNALL: /* The server if full */
     			bn_all();	
			break;
   		case BNWAI: /* Estan jugando. Espera a que terminen */
     			bn_wai();
     			break;
   		case BNTRN: /* Es mi turno */
     			bn_trn();	
			break;
   		case BNLOS: /* Perdiste padre */
     			bn_los();
			break;
   		case BNWIN: /* Ganaste titan */
     			bn_win();
			break;
   		case BNOVR: /* Game Over para todos */
     			bn_over();
			break;
   		default: /* Codigo de servidor no reconocido */
     			break;
	}
}
