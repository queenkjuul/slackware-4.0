#include <gnome.h>
#include "robot_cliente.h"
#include "protocol.h"

void
pcell( gint b, gint x, gint y, gint estado )
{
	if(x<0 || x>9 || y<0 || y>9)
		return;
	cliente.boards[b][x][y]=estado;
}

void
inteliclient( gint b)
{
	gint i,x,y;
   
	x=0;
	y=0;
   
	for(i=0;i<100;i++)
	{
		switch(cliente.boards[b][x][y])
		{
			case HUNDIDO:
			case TOCADO:
				pcell(b,x-1,y-1,AGUA);
				pcell(b,x-1,y+1,AGUA);
				pcell(b,x+1,y-1,AGUA);							
				pcell(b,x+1,y+1,AGUA);
				break;
			case NOBARCO:
				if(x<9 && cliente.boards[b][x+1][y]==HUNDIDO)
					pcell(b,x,y,AGUA);
	     
				if(x>0 && cliente.boards[b][x-1][y]==HUNDIDO)
					pcell(b,x,y,AGUA);
	     
				if(y<9 && cliente.boards[b][x][y+1]==HUNDIDO)
					pcell(b,x,y,AGUA);
	     
				if(y>0 && cliente.boards[b][x][y-1]==HUNDIDO)
					pcell(b,x,y,AGUA);
				break;
			default:
				break;
		}
		x++;
		if(x==10)
		{
			x=0;
			y++;
		}
	}
}

void
buscar_next_free( gint b, gint i, gint j, gint *x, gint *y )
{
	gint k;	

	for(k=0;k<100;k++)
	{
		if( cliente.boards[b][i][j]==NOBARCO )
		{
			*x = i;
			*y = j;
			return;
		}
		i++;
		if(i==10)
		{
			i=0;
			j++;
			if(j==10)
				j=0;
		}

	}
	ttyfill("buscar_next_free: Aca no tengo que llegar\n");
	*x = 2;
	*y = 2;
}

gint
buscar_tocado( gint b, gint *x, gint *y)
{
	gint k;	
	gint i,j;

	i=0;j=0;
	for(k=0;k<100;k++)
	{
		if( cliente.boards[b][i][j]==TOCADO )
		{
			*x = i;
			*y = j;
			return TRUE;
		}
		i++;
		if(i==10)
		{
			i=0;
			j++;
		}
	}
	return FALSE;
}


gint
que_soy_board( gint b, gint x , gint y )
{
	if( x<0 || x>9 || y<0 || y>9)
		return AGUA;	/* -1 */
	else
		return cliente.boards[b][x][y];
}

gint
r_tocado_hit( gint b, gint *x, gint *y, gint i, gint j )
{
	gint a;

	a=que_soy_board( b,*x,*y);
	if(a==NOBARCO)
		return TRUE;
	if(a==TOCADO)
	{
		*x=*x+i;
		*y=*y+j;
		return r_tocado_hit( b, x, y, i, j);
	}
	else
		return FALSE;
}

void
buscar_tocado_hit( gint b, gint *xx, gint *yy )
{
	gint x,y;

	
	x=*xx;
	y=*yy;
	
	if(!(que_soy_board(b,x,y-1)==TOCADO || que_soy_board(b,x,y+1)==TOCADO ))
	{
		if( r_tocado_hit( b, &x, &y, -1, 0 ))
		{
			*xx=x;
			*yy=y;
			return;
		}
		x=*xx;
		y=*yy;
		if( r_tocado_hit( b, &x, &y, +1, 0 ))
		{
			*xx=x;
			*yy=y;
			return;
		}
	}

	x=*xx;
	y=*yy;
	if( r_tocado_hit( b, &x, &y, 0, -1 ))
	{
		*xx=x;
		*yy=y;
		return;
	}
	x=*xx;
	y=*yy;
	if( r_tocado_hit( b, &x, &y, 0, +1 ))
	{
		*xx=x;
		*yy=y;
		return;
	}

}
void
robot_ai( int *x, int*y)
{
	gint xx,yy;

	inteliclient(cliente.usrfrom);
	
	if( buscar_tocado( cliente.usrfrom, &xx, &yy) )
	{
		buscar_tocado_hit( cliente.usrfrom, &xx, &yy );
		*x = xx;
		*y = yy;
		return;
	}
	else
	{
		xx = (int) (10.0*rand()/(RAND_MAX+1.0));
		yy = (int) (10.0*rand()/(RAND_MAX+1.0));
		buscar_next_free( cliente.usrfrom, xx, yy, &xx, &yy );
		*x = xx;
		*y = yy;
		return ;
	}
}
