
void
bnsendmsg( void );
