/****************************************************************************
 *                        Funcion que lee el SOCKET
 *                y a partir de ahi hace lo que debe hacer 
 ****************************************************************************/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <syslog.h>
#include <errno.h>
#include <string.h>

#include <config.h>
#include <gnome.h>

#include "gbnclient.h"
#include "protocol.h"
#include "cliente.h"
#include "g_interface.h"
#include "pantalla.h"


void
bn_tst()
{
}

void
bn_wri( struct protocolo *proto )
{
	if(proto->bnpmsg[0]==1) /* Board OK */
 	{
		ttyfill(_("The board's OK. Press 'Start' and enjoy the game"),0);
		usuario.play=BOARD;

		gtk_widget_hide( button_sendboard );
		gtk_widget_show( button_start );
		gtk_widget_set_sensitive(button_start,TRUE);
	}
     	else /* Board not OK */
	{
		ttyfill(_("ERROR: The board's not OK. Check it, please"),0);
		usuario.play=CONNEC;
	}
	return ;
}

void
bn_jug( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];

	usuario.numjug=proto->bnptip1;

	if(proto->bnpver<BNPVERPLAY)
	{
		sprintf(outbuf,"*** Warning: Server too old. BNPVER 0x%X"
				   "\n*** It is wise to upgrade the server",proto->bnpver);
		ttyfill(outbuf,0);
	}

	sprintf(outbuf,"Connected to server:%s. You are player number:%i",proto->bnpmsg,usuario.numjug);
	foot_right(outbuf);
	ttyfill(outbuf,0);

	usuario.play = CONNEC;
	     
	gtk_widget_hide( button_connect );
	gtk_widget_show( button_disconnect );
	     
	gtk_widget_set_sensitive(button_sendboard,TRUE);
	gtk_widget_set_sensitive(button_status,TRUE);
	gtk_widget_set_sensitive(button_sendmsg,TRUE);
	     
	     
	bnwrite(sock,outbuf,BNVER,usuario.usrfrom,bnsup,usuario.numjug);
	return ;
}

void
bn_ver( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];

	sprintf(outbuf,"bnserver version:%i.%i.%i",proto->bnpmsg[0],proto->bnpmsg[1],proto->bnpmsg[2]);
	ttyfill(outbuf,0);
	return ;
}

void 
bn_msg( struct protocolo *proto )
{
	ttyfill(proto->bnpmsg,0);
	return ;
}

void
bn_all()
{
	ttyfill(_("Server is full. Try later"),0);
	close(sock);
	return ;
}

void
bn_wai()
{
	ttyfill(_("You can't start a game while people are playing.Try later"),0);
	return ;
}

void
bn_hit( struct protocolo *proto )
{	   	
	gchar temptable[100];
	gchar outbuf[MSGMAXLEN];	
	gint x,y;

	x = (gint) proto->bnpmsg[0];
	y = (gint) proto->bnpmsg[1];
	if( x<0 || x>9 || y<0 || y>9)
	{ /* Esto nunca debe pasar */
		ttyfill(_("Bug in server. Invalid shoot"),0);
		return;
	}
	
	if(usuario.play>=PLAY) 
	{
		mitabla[x][y]=(int)proto->bnpmsg[2];
		if(usuario.hide==FALSE)
		{
			iwtable(temptable);
			fillboard(temptable,0);
		}
	}
	bnwrite(sock,outbuf,BNREA,usuario.usrfrom,bnsup,usuario.numjug);
	return ;
}

void
bn_rea( struct protocolo *proto )
{
	if(usuario.play>=PLAY)
	{
		putintemp(proto->bnpmsg);
		fillboard(proto->bnpmsg,1);
		inteliclient(proto->bnpmsg);
	}
	return ;
}

void
bn_str( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];
	gchar outbufi[MSGMAXLEN];
	gint i,j;

	ttyfill(_("Wait for your turn"),0); 
	sprintf(outbuf,_("Available players:"));
	     
	for(i=0;i<MAXPLAYER;i++)
		usuario.pages[i]=i;
	     
	for(i=0;i<100;i++)
		usuario.tempclit[i]=NOBARCO;

	j = g_list_length( GTK_NOTEBOOK(notebook_right)->children);
	for (i = 0; i < j; i++)
		gtk_notebook_remove_page ( GTK_NOTEBOOK( notebook_right), 0);
    
	for(i=0;i<MAXPLAYER;i++)
	{
		if(proto->bnpmsg[i]>=BOARD)
		{
			strcpy(usuario.names[i],&proto->bnpmsg[MAXPLAYER+i*MAXNAMELEN]);
			sprintf(outbufi,"[%s_%i]",usuario.names[i],i+1);
			strcat(outbuf,outbufi);
		       
			label_right[i] = gtk_label_new( usuario.names[i] );
			label_right2[i] = gtk_label_new( usuario.names[i] );		       
			drawing_right[i] = gtk_drawing_area_new();
			gtk_drawing_area_size(GTK_DRAWING_AREA(drawing_right[i]),200,200);
			gtk_signal_connect (GTK_OBJECT (drawing_right[i]), "expose_event",
		   		(GtkSignalFunc) expose_event_right, NULL);
			gtk_signal_connect (GTK_OBJECT (drawing_right[i]), "button_press_event",
		   		(GtkSignalFunc) button_press_event_right, NULL);
			gtk_widget_set_events (drawing_right[i], GDK_EXPOSURE_MASK
		      		|GDK_BUTTON_PRESS_MASK);

			gtk_widget_show( label_right[i] );
			gtk_widget_show( label_right2[i] );
			gtk_widget_show( drawing_right[i] );
		       	gtk_notebook_append_page_menu ( GTK_NOTEBOOK(notebook_right),
				drawing_right[i],
				label_right[i],
				label_right2[i] );
		}
		else /* si no pasa eso */
			sacar_usrpage(i);
	}
	ttyfill(outbuf,0);
	     
	sprintf(outbuf,"You are %s_%i",usuario.names[usuario.numjug-1],usuario.numjug);
	foot_left(outbuf);

	if(usuario.play==BOARD) 
	{
		usuario.play=PLAY;
		gtk_widget_set_sensitive(button_start,FALSE);
	}
	     
	/*
	* pone automaticamente al proximo jugador 
	*/
	i = buscar_usr( usuario.numjug - 1 );
	gtk_notebook_set_page( GTK_NOTEBOOK( notebook_right ),i );
	gtk_notebook_next_page( GTK_NOTEBOOK(notebook_right));
	i = gtk_notebook_current_page( GTK_NOTEBOOK( notebook_right ));
	usuario.usrfrom = usuario.pages[ i ] +1 ;
	return ;
}

void
bn_con( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];

	sprintf(outbuf,"Player %i is ready to play",proto->bnptip1);
	ttyfill(outbuf,0);
	return ;
}
	   		
void
bn_who( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];

	sprintf(outbuf,"It's %s_%i turn",usuario.names[proto->bnptip1-1],proto->bnptip1);
	foot_right(outbuf);
	ttyfill(outbuf,1);
	return ;
}

void
bn_trn()
{
	usuario.play=TURN;                    /* oh, it is my turn */
	ttyfill(_("It's my turn"),1);
	foot_right(_("It's my turn"));
	return;
}

void
bn_ext( struct protocolo *proto )
{
	gint i;

	i=proto->bnptip1-1;

	remove_page( sacar_usrpage(i) );
	     
	usuario.names[i][0]=0;
	ttyfill(proto->bnpmsg,0);
	     
	for(i=0;i<MAXPLAYER;i++) 
	{       
		if( usuario.numjug-1!=i && strcmp(usuario.names[i],"")!=0 ) 
			usuario.usrfrom=i+1;
	}
	return ;
}

void
bn_los()
{
	usuario.play=PERDIO;  /* oh, i lost the game */
	ttyfill(_("You lost!"),0);
	g_box_lost();
	return;
}

void
bn_win()
{
	usuario.play=PERDIO;
	ttyfill(_("You are the winner!"),0);
	g_box_win();
	return;
}

void
bn_over()
{
	gint i;

	usuario.play=CONNEC;                    /* oh, I won the game */
	for(i=0;i<MAXPLAYER;i++)
		usuario.names[i][0]=0;       /* clear all names */
	ttyfill(_("Game Over. Start a new game"),0);
	gtk_widget_show( button_sendboard );
	gtk_widget_hide( button_start );
	return;
}

void
bn_sol()
{
	gchar outbuf[MSGMAXLEN];

	if( usuario.autorobot==TRUE)
	{
		outbuf[0]=TRUE;			/* Autostart Game */
		bnwrite(sock,outbuf,BNRON,0,0,usuario.numjug);
	     	ttyfill(_("Autolaunching a robot..."),0);
	}
	else
	     	ttyfill(_("If you want to play alone, launch a robot"),0);
	return;
}

void
bn_sts( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];
	gint i;

	for(i=0;i<MAXPLAYER;i++) 
	{
		sprintf(outbuf,"Nro %i %s %s"
  			,i+1
			,usuario.status[(int)proto->bnpmsg[i]]
			,&proto->bnpmsg[MAXPLAYER+i*MAXNAMELEN]
		);
		ttyfill(outbuf,0);
	}
}

void
bn_ron( struct protocolo *proto )
{
	ttyfill(proto->bnpmsg,0);
}

void
bn_default( struct protocolo *proto )
{
	gchar outbuf[MSGMAXLEN];

	sprintf(outbuf,"SERVER sending code %X. Ummm... update the client please",proto->bnptip0);
	ttyfill(outbuf,0);
	return ;
}

void 
proceso( gpointer data, gint sock, GdkInputCondition GDK_INPUT_READ )
{
	struct protocolo proto;
   
	if( read(sock,&proto,MAXLEN) == MAXLEN)
	{
		switch(proto.bnptip0)
		{
			case BNTST: /* Test */
				bn_tst();
				break;
			case BNWRI: /* Check board */
				bn_wri( &proto );
     				break;
	   		case BNJUG: /* Connecting */
				bn_jug( &proto );
				break ;	
	   		case BNVER: /* Server version */
	     			bn_ver( &proto );	
				break;
	   		case BNMSG: /* Receiving message */
	     			bn_msg( &proto );	
				break;
	   		case BNALL: /* The server if full */
	     			bn_all();	
				break;
	   		case BNWAI: /* Estan jugando. Espera a que terminen */
	     			bn_wai();
	     			break;
	   		case BNHIT: /* me dispararon */
	     			bn_hit( &proto );
				break;
	   		case BNREA: /* Leer tabla de algun jugador */
	     			bn_rea( &proto );
				break;
	   		case BNSTR: /* Empezo la partida */
	     			bn_str( &proto );
				break;
	   		case BNCON: /* Se conecto uno */
	     			bn_con( &proto );
				break;
	   		case BNWHO: /* Es el turno de... */ 
	     			bn_who( &proto );
				break;
	   		case BNTRN: /* Es mi turno */
	     			bn_trn();	
				break;
	   		case BNEXT: /* Alguien se fue, creo ? */
	     			bn_ext( &proto );
				break;
	   		case BNLOS: /* Perdiste padre */
	     			bn_los();
				break;
	   		case BNWIN: /* Ganaste titan */
	     			bn_win();
				break;
	   		case BNOVR: /* Game Over para todos */
	     			bn_over();
				break;
	   		case BNSOL: /* jefe, no se puede jugar solo */
	     			bn_sol();
				break;
	   		case BNSTS: /* ver status del servidor */
	     			bn_sts( &proto );
				break;
	   		case BNRON: /* Starting Robot */
	     			bn_ron( &proto );
				break;
	   		default: /* Codigo de servidor no reconocido */
				bn_default( &proto );
	     			break;
		}
	}
}
