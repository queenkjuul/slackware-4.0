/*
	Includes de g_interface
*/


#ifndef  __BN_G_INTERFACE__
# define __BN_G_INTERFACE__

# ifdef __cplusplus
extern "C" {
# endif __cplusplus

gboolean
g_do_exit(GtkWidget *widget, gpointer data);

gboolean
g_box_lost();

gboolean
g_box_win();

void 
about( GtkWidget *widget, gpointer data );

int
save_state (GnomeClient        *client,
	gint                phase,
	GnomeRestartStyle   save_style,
	gint                shutdown,
	GnomeInteractStyle  interact_style,
	gint                fast,
	gpointer            client_data);


void 
init_X( );

# ifdef __cplusplus
}
# endif __cplusplus

# endif __BN_G_INTERFACE__
