/*
 * Gnome Batalla Naval
 * Cliente Gnome
 * 
 * (c) 1998 Ricardo Quesada
 * mailto: rquesada@dc.uba.ar
 * http://www.pjn.gov.ar/~rquesada
 *  
 */

/* ---- Includes Generales ---- */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <syslog.h>
#include <errno.h>
#include <string.h>

#include <config.h>
#include <gnome.h>

#include "protocol.h"
#include "cliente.h"
#include "proceso.h"
#include "g_interface.h"
#include "pantalla.h"
#include "gbnclient.h"
#include "sendmsg.h"
#include "configure.h"

error_t parse_an_arg (int key, char *arg, struct argp_state *state);
gint n=0,p=0,s=0;

/* This describes all the arguments we understand.  */
struct argp_option options[] =
{
	{ NULL, 'p', N_("PORT"), 0, N_("Port number. Default is 1995"), 1 },
	{ NULL, 's', N_("SERVER"), 0, N_("Server name. Default is localhost"), 1 },
	{ NULL, 'n', N_("PLAYERNAME"), 0, N_("Player name. Default is your login name"), 1 },
	{ NULL, 0, NULL, 0, NULL, 0 }
};

/* Our parser.  */
struct argp parser =
{
	options,
	parse_an_arg,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
};


/* Funcion que saca a un usuario */
gint sacar_usrpage( gint jugador )
{
	gint i,j,k;
   
	j=32; /* no es nada esto, pero sirve para el debug */
   
	for(i=0;i<MAXPLAYER;i++)
	{
		if (usuario.pages[i]==jugador)
		{
			j=i;
			for( k=i; k < (MAXPLAYER-1); k++ )
				usuario.pages[k]=usuario.pages[k+1];
			usuario.pages[MAXPLAYER-1]=-32;
		}
	}
	return j;
}

/* Funcion que busca un usuario en una page */
gint buscar_usr( gint usr )
{
	gint i,j;

	j=-20;
	for(i=0;i<MAXPLAYER;i++)
	{
		if(usuario.pages[i]==usr)
		{
			j=i;
			break;
		}
	}
	return j;
}

/* Mini ventanida de help */
void bn_help( void )
{
	gtk_text_freeze(GTK_TEXT(text_help));
	gtk_widget_realize(text_help);
	gtk_text_insert( GTK_TEXT(text_help),NULL,NULL,NULL
		,_("BATALLA NAVAL -\n"
		"\tHIDE,HELP & CREDITS"
		"\n\n\n" 
		"HIDE\n"
		"Use this option to hide your ships from your enemies, "
		"in case you are playing in the same room with them, of course."
		"\n\n\n"
		"HELP\n"
		"First you must fill your board.\n "
		"(The 'Random' button will generate a valid board)\n"
		"Press 'My board' in this "
		"notebook, and complete it with:\n"
		" - 4 ships of 1 unit\n"
		" - 3 ships of 2 units\n"
		" - 2 ships of 3 units\n"
		" - 1 ship of 4 units\n"
		"\n"
		"Remember that the ships must be put horizontally or vertically "
		"only, and that they must be one cell away from the others ships.\n"
		"Then 'Connect' to the server, if there is an error 'Config' your client.\n"
		"Then 'Send-your-Board' to the server and wait others players. "
		"You can view the 'Status' of the server, "
		"and when there are enough players 'Start' the game. OK?"
		"\n\n\n"
		"CREDITS\n"
		"Un-original idea by:\n"
		"Sebastian Cativa Tolosa & Ricardo Quesada\n\n"
		"Server, Gnome Client, GTK Client, XView Client & ncurses Client by:\n"
		"Ricardo Quesada\n\n"
		"Win 16 client & bugfixes by:\n"
		"Horacio Pe�a\n\n"
		"Gfx of little ships by:\n"
		"Francisco Carrasco\n\n"
		"\n\n\n"
		"e-mail's:\n"
		"Sebastian Cativa Tolosa\n(scativa@dc.uba.ar)\n\n"
		"Horacio Pe�a\n(horape@compendium.com.ar)\n\n"
		"Ricardo Quesada\n(rquesada@pjn.gov.ar)\n\n")
		,-1 );
	
	gtk_text_thaw(GTK_TEXT(text_help));
   
}
/****************************************************************************
 *                     FUNCIONES DE LOS EVENTOS DEL MOUSE
 ****************************************************************************/

/* Left */
gint 
expose_event( GtkWidget *widget, GdkEventExpose *event )
{
	gint i,j;
   
	for(i=0;i<10;i++)
	{
		for(j=0;j<10;j++)
			pmicell( i,j, mitabla[i][j] );
	}
   
	/* Dibuja las lineas */
	for(i=0;i<10;i++)
	{
		gdk_draw_line (widget->window,
			widget->style->black_gc,
			0,LARGO*i,
			ANCHO*10,LARGO*i);
		gdk_draw_line (widget->window,
			widget->style->black_gc,
			ANCHO*i,0,
			ANCHO*i,LARGO*10);
	}
   
	return FALSE;
}


// Se�al PRESS_BUTTON
gint 
button_press_event (GtkWidget *widget, GdkEventButton *event)
{
	gint x,y;
   
	x=event->x / ANCHO;
	y=event->y / LARGO;
   
	if( usuario.play==BOARD )
	{
		ttyfill(_("You've already sent your board to the server. You can't modify it"),0);
		return TRUE;
	}
	else if( usuario.play==PLAY || usuario.play==TURN)
	{ /* de esta manero acepto que lo que hayan perdido modifiquen su board */
		ttyfill(_("You can't modify your board while playing"),0);
		return TRUE;
	}
	if ( event->button == 1 ) /* Boton izquierdo */
	{
		gdk_draw_pixmap( widget->window,
			widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
			barco1,
			0,0,
			x*ANCHO+1,y*LARGO+1,
			ANCHO-1,LARGO-1);
		mitabla[x][y]=1;
	}
	else if ( event->button == 3 ) /* Boton derecho */
	{
		gdk_draw_pixmap( widget->window,
			widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
			fondo,
			x*ANCHO+1,y*LARGO+1,
			x*ANCHO+1,y*LARGO+1,
			ANCHO-1,LARGO-1);				  
		mitabla[x][y]=0;
	}		
	return TRUE;
}

/* Right About */
gint 
expose_event_about (GtkWidget *widget, GdkEventExpose *event)
{
	gdk_draw_pixmap( widget->window,
		widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		about_pix,
		0,0,
		0,0,
		200,200
	);
	return FALSE;
}

/* Right, page switch */
gint 
page_switch( GtkWidget *widget, GtkNotebookPage *page, gint page_num )
{
	gchar outbuf[MSGMAXLEN];
   
	if( usuario.play>=PLAY )
	{
		usuario.usrfrom = usuario.pages[ page_num ] + 1;
		bnwrite(sock,outbuf,BNREA,usuario.usrfrom,bnsup,usuario.numjug);
	}
	return TRUE;
}

/* Right panel */
gint 
expose_event_right( GtkWidget *widget, GdkEventExpose *event )
{
	gint i;
   
	for(i=0;i<10;i++)
	{
		gdk_draw_line (widget->window,
			widget->style->black_gc,
			0,LARGO*i,
			ANCHO*10,LARGO*i);
		gdk_draw_line (widget->window,
			widget->style->black_gc,
			ANCHO*i,0,
			ANCHO*i,LARGO*10);
	}
	
	fillboard(usuario.tempclit,1);
	inteliclient(usuario.tempclit);
	return FALSE;
}

gint 
button_press_event_right( GtkWidget *widget, GdkEventButton *event )
{
	gint x,y;
	gchar outbuf[MSGMAXLEN];
   
	x=event->x / ANCHO;
	y=event->y / LARGO;
   
	if(usuario.play < PLAY)
	{
		ttyfill(_("First try to start the game"),0);
		return TRUE;
	}
	else if(usuario.play==PLAY)
	{
		ttyfill(_("Wait for your turn"),0);
		return TRUE;
	}
	else if(usuario.play==PERDIO)
	{
		ttyfill(_("The game is over for you"),0);
		return TRUE;
	}
   
	if ( event->button == 1 )	/* Boton izquierdo */
	{
		usuario.play=PLAY;
		outbuf[0]=x;
		outbuf[1]=y;
		bnwrite(sock,outbuf,BNHIT,0,0,usuario.numjug);
/* FIXME. REM in v0.71.1
		bnwrite(sock,outbuf,BNREA,usuario.usrfrom,bnsup,usuario.numjug);
*/
	}
	return TRUE;
}

void 
remove_page( gint page_num )
{
	gtk_notebook_remove_page( GTK_NOTEBOOK( notebook_right ), page_num );
}

/*************************************************************************
 * 
 *                    CODIGO GENERICO
 *                   ( mentira !!!!! )
 * 
 *************************************************************************/
size_t 
bnwrite(int fd,char *buf,char tip0,char tip1,char tip2,char jugyo )
{
	gint i;
   
	struct protocolo proto;
	proto.bnptip0=tip0;
	proto.bnptip1=tip1;
	proto.bnptip2=tip2;
	proto.jugador=jugyo;
	for(i=0;i<MSGMAXLEN;i++)
		proto.bnpmsg[i]=buf[i];
	strcpy(proto.bnphead,BNPHEAD);
	proto.bnpver=BNPVER;
	return( write(fd,&proto,MAXLEN) ) ;
}

/* convierte un char[10][10] a un char[100] */
void 
iwtable( char *dest)
{
	gint i,x,y;
	x=0;
	y=0;

	for(i=0;i<100;i++) 
	{
		dest[i]=mitabla[x][y];
		x++;
		if(x>=10) 
		{ 
			x=0;
			y++;
		}
	}
}

/* pone por default la misma tabla que jugue antes */
void
filtermiboard()  
{
	gint x,y;
   
	for(x=0;x<10;x++) 
	{
		for(y=0;y<10;y++) 
		{
			if( mitabla[x][y] >= BARCO ) 
				mitabla[x][y]=BARCO;
			else if( mitabla[x][y] <= NOBARCO ) 
				mitabla[x][y]=NOBARCO;
		}
	}
}


/*
 * Pone en un temporal datos ( Usados ppalmente por Cli GTK )
 */
void
putintemp( char *table )
{
	gint i;
	for(i=0;i<100;i++)
		usuario.tempclit[i]=table[i];
}

void
showboard( GdkPixmap *pixmap )
{
	gint i;
   
	i = gtk_notebook_current_page( GTK_NOTEBOOK( notebook_right ) );
	i = usuario.pages[ i ] ;  /* puto bug resuelto */
   
	gdk_draw_pixmap( drawing_right[i]->window,
		drawing_right[i]->style->fg_gc[GTK_WIDGET_STATE(drawing_right[i])],
		pixmap,
		0,0,
		0,0,
		200,200
	);
}

/* funcion que rellena los tableros
 * IN: char * - relleno
 * IN: int - 0 - left board
 *         - 1 - right board
 */
void
fillboard( char *filltable, int a )
{
	gint i,j;
	gint k;
   
	i=0;j=0;
   
	for(k=0;k<100;k++)
	{
		if(a==0) /* izquierda */
			pmicell( i,j, filltable[k]);
		else 	/* a==1 (derecha) */
			ptucell( i,j, filltable[k]);
	
		i++;
		if (i==10)
		{
			j++;i=0;
		}
	}
}

void
inteliclient( char *table)
{
	gint i,x,y;
   
	x=0;
	y=0;
   
	for(i=0;i<100;i++)
	{
		switch(table[i])
		{
			case HUNDIDO:
			case TOCADO:
				ptucell(x-1,y-1,AGUA);
				ptucell(x-1,y+1,AGUA);
				ptucell(x+1,y-1,AGUA);							
				ptucell(x+1,y+1,AGUA);
				break;
			case NOBARCO:
				if(x<9 && table[i+1]==HUNDIDO)
					ptucell(x,y,AGUA);
	     
				if(x>0 && table[i-1]==HUNDIDO)
					ptucell(x,y,AGUA);
	     
				if(y<9 && table[i+10]==HUNDIDO)
					ptucell(x,y,AGUA);
	     
				if(y>0 && table[i-10]==HUNDIDO)
					ptucell(x,y,AGUA);
				break;
			default:
				break;
		}
		x++;
		if(x==10)
		{
			x=0;
			y++;
		}
	}
}


/***************************************************************************
 *                       FUNCIONES DE LOS BOTONES
 ***************************************************************************/
/* Dis/Connect esta en las funciones INIT con el nombre de init_cliente */

/* quit */
void
destroy_window( GtkWidget *widget, GtkWidget **window )
{
	*window = NULL;
}


void
do_exit(GtkWidget *widget, gpointer data)
{
	g_do_exit( widget, data);
}


/* Boton SendBoard y Start */
int
play( void )
{
	gchar outbuf[MSGMAXLEN];
	gchar temptable[100];
   
	/* Send Board */
	if( usuario.play==CONNEC)  
	{
		filtermiboard();
		iwtable(temptable);
		fillboard(temptable,0);
	
		iwtable( outbuf );
		bnwrite(sock,outbuf,BNWRI,usuario.numjug,0,usuario.numjug);
		return( TRUE );
 	}
   
	/* Start */
	else if(usuario.play==BOARD) 
		bnwrite(sock,outbuf,BNSTR,usuario.numjug,0,usuario.numjug);
   
	return(TRUE);
}

/* Boton Status */
void
status( )
{
	gchar tempbuf[MSGMAXLEN];
	bnwrite(sock,tempbuf,BNSTS,0,0,usuario.numjug);
}


/***************************************************************************
 *                               FUNCIONES INIT
 ***************************************************************************/
void
init_datos( void )
{
	gint i,j;

	usuario.play = DISCON;
	usuario.usrfrom=1;
	usuario.lecho=1;

	for(i=0;i<10;i++) 
	{          /* clean tabla */
		for(j=0;j<10;j++)
			mitabla[i][j]=0;
	}

	for(i=0;i<MAXPLAYER;i++)
	{
		usuario.names[i][0]=0;       /* clear all names */
		usuario.pages[i]=i;
	}
	strcpy(usuario.status[DISCON],_("[not connected]"));
	strcpy(usuario.status[CONNEC],_("[connected    ]"));
	strcpy(usuario.status[BOARD], _("[ready to play]"));
	strcpy(usuario.status[PLAY],  _("[playing      ]"));
	strcpy(usuario.status[TURN],  _("[playing turn ]"));
	strcpy(usuario.status[PERDIO],_("[game over    ]"));
	usuario.hide=FALSE;
}

int init_robot( void )
{
	gchar tempbuf[MSGMAXLEN];
	if( usuario.play>=CONNEC )
	{
		tempbuf[0]=FALSE;					/* Dont autostart game */
		bnwrite(sock,tempbuf,BNRON,0,0,usuario.numjug);
		return 0;
	}
	else
	{
		ttyfill(_("Try to connect to the server first"),0);
		return(-1);
	}
}

int init_cliente( void )
{
	gchar outbuf[MSGMAXLEN];
	gint i;

	if(usuario.play==DISCON) 
	{
		/* Probando otra vez las gnome_net_connect_tcp 
		Anduvieron :-) */
		sock = gnome_net_connect_tcp( usuario.server_name,
			usuario.port,
			NULL,		/* gchar myhost ? */
			(gint) NULL,		/* gint myport ? */
			NULL );	/* GnomeNetFn */

		if(sock<0)
		{
			ttyfill(_("Error: Is the server running?"),0);
			return -1;
		}
		usuario.tag = gdk_input_add( sock, GDK_INPUT_READ, proceso, temp );
     
     
		strncpy(outbuf,usuario.nombre,MAXNAMELEN);
		outbuf[MSGMAXLEN-1]=GBNVERM;
		bnwrite(sock,outbuf,BNJUG,GNCLI,GBNVERH,GBNVERL);       /* WHO AM I */
		return(0);
	}
	else if(usuario.play!=DISCON) 
	{
		gtk_widget_show( button_connect );
		gtk_widget_hide( button_disconnect );
		gtk_widget_show( button_sendboard );
		gtk_widget_hide( button_start );

		gtk_widget_set_sensitive(button_sendboard,FALSE);
		gtk_widget_set_sensitive(button_sendmsg,FALSE);
		gtk_widget_set_sensitive(button_status,FALSE);
		gtk_widget_set_sensitive(button_sendmsg,FALSE);

		ttyfill(_("Press 'Connect' again to join a game"),0);
		foot_right(_("Press 'Connect' again to join a game"));
		foot_left("Batalla Naval");
		for(i=0;i<MAXPLAYER;i++)
		{
			usuario.names[i][0]=0;
			usuario.pages[i]=i;
		}
		usuario.play=DISCON;
		bnwrite(sock,outbuf,BNEXT,0,0,usuario.numjug);

		close(sock);
		gdk_input_remove( usuario.tag );	
	}
	return(0);
}

error_t 
parse_an_arg (int key, char *arg, struct argp_state *state)
{
	gchar temporal[100];

	sprintf(temporal,"/gbnclient/data/playername=%s",getenv("LOGNAME"));

	switch(key)
	{
		case 'n':
			strncpy( usuario.nombre,arg,MAXNAMELEN);
			n=1;
			break;
		case 'p':
 			usuario.port=atoi(arg);
			p=1;
			break;
		case 's':
			strncpy( usuario.server_name,arg,50);
			s=1;
			break;
		case ARGP_KEY_SUCCESS:
			if(!n)
				strncpy(usuario.nombre,gnome_config_get_string(temporal),MAXNAMELEN);
			if(!p)
				usuario.port = gnome_config_get_int("/gbnclient/data/port=1995");
			if(!s)
				strncpy( usuario.server_name,gnome_config_get_string("/gbnclient/data/servername=localhost"),50);

			usuario.random = gnome_config_get_int("/gbnclient/data/random=1995");
			usuario.autorobot = gnome_config_get_int("/gbnclient/data/autorobot=1");
			usuario.debug_level = gnome_config_get_int("/gbnclient/data/debuglevel=0");
			break;
		default:
			return ARGP_ERR_UNKNOWN;
	}
	return 0;
}


/****************************************************************************
 *                           MAIN * MAIN * MAIN
 ****************************************************************************/

int main (int argc, char *argv[])
{
	gint i;
	GnomeClient *client;

	bindtextdomain( PACKAGE, GNOMELOCALEDIR );
	textdomain( PACKAGE );
  
	client = gnome_client_new_default ();
	gtk_signal_connect (GTK_OBJECT (client), "save_yourself",
   		GTK_SIGNAL_FUNC (save_state), argv[0]);



	gnome_init("Gnome Batalla Naval client v"VERSION, &parser, argc, argv, 0, NULL);
   
	init_datos();                  
	init_X();              
	init_cliente();
   
	gtk_main ();
	gtk_object_unref(GTK_OBJECT(client));
	return 0;
}
