
void
robot_ai( int *x, int*y);
