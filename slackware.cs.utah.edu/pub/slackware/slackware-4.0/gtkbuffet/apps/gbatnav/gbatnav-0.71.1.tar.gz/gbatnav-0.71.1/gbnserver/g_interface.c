/******************************************************************************
 *                               g_interface                                  *
 *                             gnome interface						*
 *****************************************************************************/
#include <config.h>
#include <gnome.h>
#include <stdarg.h>

#include "server.h"

GtkWidget *text[MAXPLAYER];
GtkWidget *vscrollbar[MAXPLAYER];

void
textfill(gint pl, gchar *fmt, ... )
{
	gchar messg[200];
	gchar messg2[200];
   	gfloat new_value ;
	gint h,w;

	va_list args;

	va_start( args, fmt );

	sprintf(messg,"\n%s: ",usuario.names[pl]);	
	vsprintf(messg2,fmt,args);
	strncat(messg,messg2,200);
	va_end( args );

	gtk_text_freeze(GTK_TEXT(text[pl]));
  	gtk_widget_realize(text[pl]);
  	gtk_text_insert( GTK_TEXT(text[pl]),NULL,NULL,NULL,messg,-1);
	gtk_text_thaw(GTK_TEXT(text[pl]));

	gdk_window_get_size( GTK_TEXT(text[pl])->text_area, &w, &h );

	if( GTK_RANGE( vscrollbar[pl] )->adjustment->upper >= h ) {
		new_value = GTK_RANGE( vscrollbar[pl] )-> adjustment->upper - h;
		GTK_RANGE(vscrollbar[pl])->adjustment->value = new_value;
		GTK_RANGE(vscrollbar[pl])->timer = 0; 
		gtk_signal_emit_by_name (GTK_OBJECT (GTK_RANGE(vscrollbar[pl])->adjustment), "value_changed");
     	}
}

static void
message_dlg_clicked(GtkWidget *widget, int button,gpointer data)
{
	if (button == 0) /* Yes */
		gtk_main_quit();
	else /* No */
		gnome_dialog_close(GNOME_DIALOG(widget));
}

gboolean
g_do_exit(GtkWidget *widget, gpointer data)
{
	static GtkWidget *box = NULL;

	if (box == NULL)
	{
		box = gnome_message_box_new (_("Really quit?"),
			GNOME_MESSAGE_BOX_QUESTION,
			GNOME_STOCK_BUTTON_YES,
			GNOME_STOCK_BUTTON_NO,
			NULL);
		gtk_signal_connect (GTK_OBJECT (box), "clicked",
			GTK_SIGNAL_FUNC (message_dlg_clicked), NULL);

		gnome_dialog_set_modal (GNOME_DIALOG(box));
		gnome_dialog_close_hides(GNOME_DIALOG(box), TRUE);
	}
	gtk_widget_show (box);
	return TRUE;
}
void about(GtkWidget *widget, gpointer data)
{
   GtkWidget *about;
   gchar *authors[] = {
      "Ricardo Quesada (rquesada@pjn.gov.ar)",
      NULL
   };
   
   about = gnome_about_new (_("Batalla Naval server"), VERSION,
			    "(C) 1998 Ricardo Quesada",
			    (const char**) authors,
			    _("A multiplayer, multirobot, networked battleship game"),
			    "gnome-gbatnav.png");
   gtk_widget_show (about);
}

GnomeUIInfo gamemenu[] = 
{
     {GNOME_APP_UI_ITEM, N_("Exit"), NULL, g_do_exit, NULL, NULL,
	GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_EXIT, 0, 0, NULL},
   
     {GNOME_APP_UI_ENDOFINFO, NULL, NULL, NULL, NULL, NULL,
	GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL}
};

GnomeUIInfo helpmenu[] = 
{
	{ GNOME_APP_UI_HELP, NULL, NULL, NULL, NULL, NULL,
		GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
	
	{ GNOME_APP_UI_ITEM, N_("About..."), NULL, about, NULL, NULL,
		GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_ABOUT, 0, 0, NULL },

	{ GNOME_APP_UI_ENDOFINFO}
};

GnomeUIInfo mainmenu[] = 
{
     {GNOME_APP_UI_SUBTREE, N_("Game"), NULL, gamemenu, NULL, NULL,
	GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
   
     {GNOME_APP_UI_SUBTREE, N_("Help"), NULL, helpmenu, NULL, NULL,
	GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
   
     {GNOME_APP_UI_ENDOFINFO}

};


/*****************************************************************************
 *                                    INIT SCREEN                            *
 ****************************************************************************/
void init_screen(void) 
{
	GtkWidget *window;
	GtkWidget *hbox_text;
	GtkWidget *vbox;

	gint i ;

#ifdef ENABLE_NLS
# define ELEMENTS(x) (sizeof(x) / sizeof(x[0])) 
	{
		int i;
		for (i = 0; i < ELEMENTS(mainmenu); i++)
			mainmenu[i].label = gettext(mainmenu[i].label);
		for (i = 0; i < ELEMENTS(gamemenu); i++)
			gamemenu[i].label = gettext(gamemenu[i].label);
		for (i = 0; i < ELEMENTS(helpmenu); i++)
			helpmenu[i].label = gettext(helpmenu[i].label);
	}
#endif /* ENABLE_NLS */
   
	window = gnome_app_new ("gbnserver", _("Gnome Batalla Naval server") );
//	gtk_window_set_policy(GTK_WINDOW(window), FALSE, FALSE, TRUE);
	gnome_app_create_menus(GNOME_APP(window), mainmenu);
	gtk_menu_item_right_justify(GTK_MENU_ITEM(mainmenu[1].widget));
	gtk_widget_realize (window);
   
	gtk_signal_connect ( GTK_OBJECT( window), "destroy",
		GTK_SIGNAL_FUNC( g_do_exit ),
		GTK_OBJECT(window) );
	gtk_signal_connect ( GTK_OBJECT( window), "delete_event",
		GTK_SIGNAL_FUNC( g_do_exit ),
		GTK_OBJECT(window) );

	/* horizontal box - text */
	vbox = gtk_vbox_new ( FALSE, 0);
	gnome_app_set_contents(GNOME_APP(window), vbox );
	gtk_container_border_width ( GTK_CONTAINER(vbox), 0);
	gtk_widget_show ( vbox ); 
   	
	for(i=0;i<MAXPLAYER;i++)
	{
		hbox_text = gtk_hbox_new ( FALSE, 0);
		gtk_container_add ( GTK_CONTAINER(vbox), hbox_text );
		gtk_widget_show( hbox_text );
	
		text[i] = gtk_text_new(NULL,NULL);
		gtk_widget_set_usize(text[i],500,74);
		gtk_box_pack_start( GTK_BOX(hbox_text), text[i], TRUE,TRUE,0);
		gtk_widget_show(text[i]);
   
		vscrollbar[i] = gtk_vscrollbar_new (GTK_TEXT(text[i])->vadj);
		gtk_range_set_update_policy( GTK_RANGE( vscrollbar[i] ), GTK_UPDATE_CONTINUOUS );
		gtk_box_pack_start( GTK_BOX(hbox_text), vscrollbar[i], FALSE,TRUE,0);
		gtk_widget_show (vscrollbar[i]);

		gtk_text_freeze(GTK_TEXT(text[i]));
  		gtk_widget_realize(text[i]);
  		gtk_text_insert( GTK_TEXT(text[i]),NULL,NULL,NULL,"Batalla Naval - Gnome Server v"VERSION" by Riq (c) 1998",-1);
		gtk_text_thaw(GTK_TEXT(text[i]));
		textfill(i,_("Port number: %i, Server Name: %s, Maxplayers: %i, Protocol: 0x%X"),usuario.port,usuario.server_name,MAXPLAYER,BNPVER);
   
	}

	/* show window */
	gtk_widget_show( window);
}

