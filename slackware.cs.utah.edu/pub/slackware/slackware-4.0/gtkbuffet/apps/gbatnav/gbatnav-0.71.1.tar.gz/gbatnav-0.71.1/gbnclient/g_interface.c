/******************************************************************************
 *                        FUNCIONES GNOMES  y/o GTK                           *
 *****************************************************************************/

#include <string.h>

#include <config.h>
#include <gnome.h>

#include "gbnclient.h"
#include "protocol.h"
#include "cliente.h"
#include "proceso.h"
#include "pantalla.h"
#include "random_board.h"
#include "configure.h"
#include "sendmsg.h"

/* pixmaps */
#include "xpm/about.xpm"
#include "xpm/agua.xpm"
#include "xpm/icono.xpm"
#include "xpm/fondo.xpm"

#include "xpm/barco1.xpm"
#include "xpm/barco1_t.xpm"
#include "xpm/barco1_h.xpm"
#include "xpm/barco2h.xpm"
#include "xpm/barco2h_t.xpm"
#include "xpm/barco2h_h.xpm"
#include "xpm/barco2v.xpm"
#include "xpm/barco2v_t.xpm"
#include "xpm/barco2v_h.xpm"
#include "xpm/barco3h.xpm"
#include "xpm/barco3h_t.xpm"
#include "xpm/barco3h_h.xpm"
#include "xpm/barco3v.xpm"
#include "xpm/barco3v_t.xpm"
#include "xpm/barco3v_h.xpm"
#include "xpm/barco4h.xpm"
#include "xpm/barco4h_t.xpm"
#include "xpm/barco4h_h.xpm"
#include "xpm/barco4v.xpm"
#include "xpm/barco4v_t.xpm"
#include "xpm/barco4v_h.xpm"

#include "xpm/robot.xpm"
#include "xpm/random.xpm"

static void
message_dlg_clicked(GtkWidget *widget, int button,gpointer data)
{
	if (button == 0) /* Yes */
		gtk_main_quit();
	else /* No */
		gnome_dialog_close(GNOME_DIALOG(widget));
}

gboolean
g_do_exit(GtkWidget *widget, gpointer data)
{
	static GtkWidget *box = NULL;

	if (box == NULL)
	{
		box = gnome_message_box_new (_("Really quit?"),
			GNOME_MESSAGE_BOX_QUESTION,
			GNOME_STOCK_BUTTON_YES,
			GNOME_STOCK_BUTTON_NO,
			NULL);
		gtk_signal_connect (GTK_OBJECT (box), "clicked",
			GTK_SIGNAL_FUNC (message_dlg_clicked), NULL);

		gnome_dialog_set_modal (GNOME_DIALOG(box));
		gnome_dialog_close_hides(GNOME_DIALOG(box), TRUE);
	}
	gtk_widget_show (box);
	return TRUE;
}


static void
g_cerrar(GtkWidget *widget, int button,gpointer data)
{
	gnome_dialog_close(GNOME_DIALOG(widget));
}

gboolean
g_box_lost()
{
	static GtkWidget *box = NULL;

	if (box == NULL )
	{
		box = gnome_message_box_new (_("Game Over: You lost!"),
			GNOME_MESSAGE_BOX_INFO,
			GNOME_STOCK_BUTTON_OK,
			NULL);
		
		gtk_signal_connect (GTK_OBJECT (box), "clicked",
			GTK_SIGNAL_FUNC (g_cerrar), NULL);

		gnome_dialog_set_modal( GNOME_DIALOG(box));
		gnome_dialog_close_hides(GNOME_DIALOG(box), TRUE);
	}
	gtk_widget_show( box );
	return TRUE;
}

gboolean
g_box_win()
{
	static GtkWidget *box = NULL;

	if (box == NULL )
	{
		box = gnome_message_box_new (_("Game Over: You are the Winner!"),
			GNOME_MESSAGE_BOX_INFO,
			GNOME_STOCK_BUTTON_OK,
			NULL);
		
		gtk_signal_connect (GTK_OBJECT (box), "clicked",
			GTK_SIGNAL_FUNC (g_cerrar), NULL);

		gnome_dialog_set_modal( GNOME_DIALOG(box));
		gnome_dialog_close_hides(GNOME_DIALOG(box), TRUE);
	}
	gtk_widget_show( box );
	return TRUE;
}

void 
about( GtkWidget *widget, gpointer data )
{
	GtkWidget *about;
	gchar *authors[] = 
	{
		"Ricardo Quesada (rquesada@pjn.gov.ar)",
		NULL
	};
   
	about = gnome_about_new (_("Batalla Naval client"), VERSION,
			"(C) 1998 Ricardo Quesada",
			(const char**) authors,
			_("A multiplayer, multirobot, networked battleship game."),
			"gnome-gbatnav.png");
	gtk_widget_show (about);
}

GnomeUIInfo gamemenu[] = 
{
	{ GNOME_APP_UI_ITEM, N_("Config..."), NULL, configure, NULL, NULL,
		GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_PROP, 0, 0, NULL },

	{ GNOME_APP_UI_ITEM, N_("Generate random board"), NULL, generar, NULL, NULL,
		GNOME_APP_PIXMAP_DATA, random_xpm, 0, 0, NULL },

	{ GNOME_APP_UI_ITEM, N_("Launch a robot in server"), NULL, init_robot, NULL, NULL, 
		GNOME_APP_PIXMAP_DATA, robot_xpm, 0, 0, NULL }, 

	{ GNOME_APP_UI_ITEM, N_("Scores..."), NULL, NULL, NULL, NULL, 
		GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_SCORES, 0, 0, NULL }, 
	
	GNOMEUIINFO_SEPARATOR, 
	
	{ GNOME_APP_UI_ITEM, N_("Exit"), NULL, do_exit, NULL, NULL, 
		GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_EXIT, 0, 0, NULL },
   
	{ GNOME_APP_UI_ENDOFINFO}
};

GnomeUIInfo helpmenu[] = 
{
	{ GNOME_APP_UI_HELP, NULL, NULL, NULL, NULL, NULL,
		GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
	
	{ GNOME_APP_UI_ITEM, N_("About..."), NULL, about, NULL, NULL,
		GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_ABOUT, 0, 0, NULL },

	{ GNOME_APP_UI_ENDOFINFO}
};

GnomeUIInfo mainmenu[] = 
{
	{ GNOME_APP_UI_SUBTREE, N_("Game"), NULL, gamemenu, NULL, NULL,
		GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL },
   
	{ GNOME_APP_UI_SUBTREE, N_("Help"), NULL, helpmenu, NULL, NULL,
		GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL },
   
	{ GNOME_APP_UI_ENDOFINFO }
};

GnomeUIInfo main_toolbarinfo[] =
{
	{GNOME_APP_UI_ITEM, N_("Config"), N_("Config the client"),
	configure, NULL, NULL,
	GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_PROP, 0, 0, NULL},
	
	{GNOME_APP_UI_ITEM, N_("Random"), N_("Generate a random board"),
	generar, NULL, NULL,
	GNOME_APP_PIXMAP_DATA, random_xpm, 0, 0, NULL},

	GNOMEUIINFO_SEPARATOR,

	{GNOME_APP_UI_ITEM, N_("Robot"), N_("Launch a robot in server"),
	init_robot, NULL, NULL,
	GNOME_APP_PIXMAP_DATA, robot_xpm, 0, 0, NULL},
  
	GNOMEUIINFO_SEPARATOR,
	
	{GNOME_APP_UI_ITEM, N_("Exit"), N_("Quit Batalla Naval"),
	do_exit, NULL, NULL,
	GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_EXIT, 0, 0, NULL},

	{GNOME_APP_UI_ENDOFINFO}
};

/* A little helper function.  */
static char *
nstr (int n)
{
	char buf[50];
	sprintf (buf, "%d", n);
	return strdup (buf);
}


int
save_state (GnomeClient        *client,
	gint                phase,
	GnomeRestartStyle   save_style,
	gint                shutdown,
	GnomeInteractStyle  interact_style,
	gint                fast,
	gpointer            client_data)
{
	char *argv[20];
	int i = 0, j;
	gint xpos, ypos;

	gdk_window_get_origin (window->window, &xpos, &ypos);

	argv[i++] = (char *) client_data;
	argv[i++] = "-p";
	argv[i++] = nstr (usuario.port);
	argv[i++] = "-u";
	argv[i++] = usuario.nombre;
	argv[i++] = "-s";
	argv[i++] = usuario.server_name;
	argv[i++] = "-a";
	argv[i++] = nstr (xpos);
	argv[i++] = "-b";
	argv[i++] = nstr (ypos);

	gnome_client_set_restart_command (client, i, argv);
	/* i.e. clone_command = restart_command - '--sm-client-id' */
	gnome_client_set_clone_command (client, 0, NULL);

	for (j = 2; j < i; j += 2)
		free (argv[j]);

	return TRUE;
}

/*****************************************************************************
 *                                   INIT X                                  *
 *****************************************************************************/
void 
init_X( )
{
	GtkTooltips *tooltips;
	GdkColor yellow={ 4, 0, 0, 8 };
	GdkColor black={ 4, 0, 0, 0 };

#ifdef ENABLE_NLS
# define ELEMENTS(x) (sizeof(x) / sizeof(x[0])) 
	{
		int i;
		for (i = 0; i < ELEMENTS(mainmenu); i++)
			mainmenu[i].label = gettext(mainmenu[i].label);
		for (i = 0; i < ELEMENTS(gamemenu); i++)
			gamemenu[i].label = gettext(gamemenu[i].label);
		for (i = 0; i < ELEMENTS(helpmenu); i++)
			helpmenu[i].label = gettext(helpmenu[i].label);
	}
#endif /* ENABLE_NLS */
   
	window = gnome_app_new ("gbnclient", _("Gnome Batalla Naval client") );
	gtk_window_set_policy(GTK_WINDOW(window), FALSE, FALSE, TRUE);

	gnome_app_create_menus(GNOME_APP(window), mainmenu);
	gnome_app_create_toolbar(GNOME_APP(window), main_toolbarinfo);

	gtk_menu_item_right_justify(GTK_MENU_ITEM(mainmenu[1].widget));
	gtk_widget_realize (window);
   
	gtk_signal_connect ( GTK_OBJECT( window), "destroy",
		GTK_SIGNAL_FUNC( do_exit ),
		GTK_OBJECT(window) );
	gtk_signal_connect ( GTK_OBJECT( window), "delete_event",
		GTK_SIGNAL_FUNC( do_exit ),
		GTK_OBJECT(window) );
  
	tooltips=gtk_tooltips_new();
	gtk_object_set_data (GTK_OBJECT (window), "tooltips", tooltips);

//	gtk_tooltips_set_colors( tooltips, &black, &yellow);

	/* Box que contiene a box_left, box_button, box_right  */
	vbox = gtk_vbox_new ( FALSE, 0);
	gnome_app_set_contents(GNOME_APP(window), vbox );
   
	gtk_container_border_width ( GTK_CONTAINER(vbox), 0);
	gtk_widget_show ( vbox ); 

	/* box horizontal */
	hbox = gtk_hbox_new ( FALSE, 0);
	gtk_container_add ( GTK_CONTAINER(vbox), hbox );
	gtk_container_border_width ( GTK_CONTAINER(hbox), 0);
	gtk_widget_show( hbox );
   
	/******************** LEFT *******************/
	notebook_left = gtk_notebook_new();
	gtk_notebook_set_tab_pos( GTK_NOTEBOOK(notebook_left),GTK_POS_TOP );
	gtk_box_pack_start( GTK_BOX(hbox),notebook_left,TRUE,TRUE,0);
	gtk_widget_show (notebook_left);
   
	// respecto al drawing_left
	drawing_left = gtk_drawing_area_new();
	gtk_drawing_area_size(GTK_DRAWING_AREA(drawing_left),200,200);
	gtk_widget_show( drawing_left );
   

	// se�ales de la drawing area
	gtk_signal_connect (GTK_OBJECT (drawing_left), "expose_event",
		(GtkSignalFunc) expose_event, NULL);
	gtk_signal_connect (GTK_OBJECT (drawing_left), "button_press_event",
		(GtkSignalFunc) button_press_event, NULL);
	gtk_widget_set_events (drawing_left, GDK_EXPOSURE_MASK
		|GDK_BUTTON_PRESS_MASK);
//	gtk_widget_set_extension_events (drawing_left, GDK_EXTENSION_EVENTS_ALL);

   
//	respecto al drawing_about
	hbox_text_help = gtk_hbox_new ( FALSE, 0);
	gtk_widget_show( hbox_text_help );
   
	text_help = gtk_text_new(NULL,NULL);
	gtk_box_pack_start( GTK_BOX(hbox_text_help), text_help, TRUE,TRUE,0);
	gtk_widget_show(text_help);
   
	vscrollbar_help = gtk_vscrollbar_new (GTK_TEXT (text_help)->vadj);
	gtk_box_pack_start( GTK_BOX(hbox_text_help), vscrollbar_help, FALSE,TRUE,0);
	gtk_widget_show (vscrollbar_help);
   
	label_left = gtk_label_new(_("My board"));
	gtk_notebook_append_page ( GTK_NOTEBOOK(notebook_left),drawing_left,label_left);
	label_left = gtk_label_new(_("Hide / Help / Credits"));
	gtk_notebook_append_page ( GTK_NOTEBOOK(notebook_left),hbox_text_help,label_left);

	bn_help();
      
	/* center */
   
	vbox_buttons = gtk_vbox_new ( FALSE, 10);
	gtk_container_add ( GTK_CONTAINER (hbox), vbox_buttons );
	gtk_container_border_width( GTK_CONTAINER(vbox_buttons),10);
	gtk_widget_show( vbox_buttons );
   
	button_connect = gtk_button_new_with_label("Connect");
	gtk_box_pack_start( GTK_BOX(vbox_buttons), button_connect, TRUE,TRUE,0);
	gtk_signal_connect_object( GTK_OBJECT (button_connect), "clicked",
		GTK_SIGNAL_FUNC(init_cliente),
		GTK_OBJECT (window) );
	gtk_widget_show(button_connect);
	gtk_tooltips_set_tip (tooltips,button_connect,
		_("Connect to the bnserver"), 
		_("Connect to the bnserver"));
   
	button_disconnect = gtk_button_new_with_label("Disconnect");
	gtk_box_pack_start( GTK_BOX(vbox_buttons), button_disconnect, TRUE,TRUE,0);
	gtk_signal_connect_object( GTK_OBJECT (button_disconnect), "clicked",
		GTK_SIGNAL_FUNC(init_cliente),
		GTK_OBJECT (window) );
	gtk_widget_hide(button_disconnect);
	gtk_tooltips_set_tip (tooltips,button_disconnect,
		_("Disconnect from the bnserver"), 
		_("Disconnect from the bnserver"));
   
	button_sendboard = gtk_button_new_with_label ("Send Board");
	gtk_box_pack_start( GTK_BOX(vbox_buttons), button_sendboard,TRUE,TRUE,0);
	gtk_signal_connect_object( GTK_OBJECT (button_sendboard), "clicked",
		GTK_SIGNAL_FUNC(play),
		GTK_OBJECT (window) );
	gtk_widget_set_sensitive(button_sendboard,FALSE);
	gtk_widget_show(button_sendboard);
	gtk_tooltips_set_tip (tooltips,button_sendboard,
		_("Send your board (ships) to the bnserver"),
		_("Send your board (ships) to the bnserver"));

   
	button_start = gtk_button_new_with_label("Start");
	gtk_box_pack_start( GTK_BOX(vbox_buttons), button_start, TRUE,TRUE,0);
	gtk_signal_connect_object( GTK_OBJECT (button_start), "clicked",
		GTK_SIGNAL_FUNC(play),
		GTK_OBJECT (window) );
	gtk_widget_hide(button_start);
	gtk_tooltips_set_tip (tooltips,button_start,
		_("Start the game"),
		_("Start the game"));
   
	button_sendmsg = gtk_button_new_with_label ("Send Message");
	gtk_box_pack_start( GTK_BOX(vbox_buttons), button_sendmsg,TRUE,TRUE,0);
	gtk_signal_connect_object( GTK_OBJECT (button_sendmsg), "clicked",
		GTK_SIGNAL_FUNC(bnsendmsg),
		GTK_OBJECT (window) );
	gtk_widget_set_sensitive(button_sendmsg,FALSE);
	gtk_widget_show(button_sendmsg);
	gtk_tooltips_set_tip (tooltips,button_sendmsg,
		_("Send a message to your enemies"),
		_("Send a message to your enemies"));
   
	button_status = gtk_button_new_with_label ("Status");
	gtk_box_pack_start( GTK_BOX(vbox_buttons), button_status,TRUE,TRUE,0);
	gtk_signal_connect_object( GTK_OBJECT (button_status), "clicked",
		GTK_SIGNAL_FUNC(status),
		GTK_OBJECT (window) );
	gtk_widget_set_sensitive(button_status,FALSE);
	gtk_widget_show(button_status);		
	gtk_tooltips_set_tip (tooltips,button_status,
		_("The status of the bnserver & your enemies"),
		_("The status of the bnserver & your enemies"));
   

	/* right */
	notebook_right = gtk_notebook_new();
	gtk_signal_connect ( GTK_OBJECT ( notebook_right ), "switch_page",
		GTK_SIGNAL_FUNC ( page_switch ), NULL );
	gtk_notebook_set_tab_pos( GTK_NOTEBOOK(notebook_right),GTK_POS_TOP );
	gtk_box_pack_start( GTK_BOX(hbox),notebook_right,TRUE,TRUE,0);
 	gtk_container_border_width( GTK_CONTAINER( notebook_right), 0 );
	gtk_notebook_set_scrollable( GTK_NOTEBOOK(notebook_right) , TRUE );
	gtk_notebook_set_show_tabs( GTK_NOTEBOOK(notebook_right) , TRUE );
	gtk_notebook_popup_enable( GTK_NOTEBOOK(notebook_right) );
	gtk_widget_realize( notebook_right );
	gtk_widget_show (notebook_right);

	drawing_right_about = gtk_drawing_area_new();
	gtk_drawing_area_size(GTK_DRAWING_AREA(drawing_right_about),200,200);
	gtk_signal_connect (GTK_OBJECT (drawing_right_about), "expose_event",
		(GtkSignalFunc) expose_event_about, NULL );
	gtk_widget_set_events (drawing_right_about, GDK_EXPOSURE_MASK );
	gtk_widget_show( drawing_right_about);
	label_right_about = gtk_label_new("Batalla Naval" );
	gtk_widget_show( drawing_right_about);
	gtk_notebook_append_page( GTK_NOTEBOOK( notebook_right), drawing_right_about, label_right_about );
   

	/* Ventana de texto de abajo */
	separator = gtk_hseparator_new ();
	gtk_box_pack_start ( GTK_BOX(vbox), separator, FALSE,TRUE, 0);

	gtk_widget_show(separator);
   
	hbox_text = gtk_hbox_new ( FALSE, 0);
	gtk_container_add ( GTK_CONTAINER(vbox), hbox_text );
	gtk_widget_show( hbox_text );
   
	text = gtk_text_new(NULL,NULL);
	gtk_box_pack_start( GTK_BOX(hbox_text), text, TRUE,TRUE,0);
	gtk_widget_show(text);
   
	vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
	gtk_range_set_update_policy( GTK_RANGE( vscrollbar ), GTK_UPDATE_CONTINUOUS );
	gtk_box_pack_start( GTK_BOX(hbox_text), vscrollbar, FALSE,TRUE,0);
	gtk_widget_show (vscrollbar);
   
	gtk_text_freeze(GTK_TEXT(text));
	gtk_widget_realize(text); 
	gtk_text_insert( GTK_TEXT(text),NULL,NULL,NULL,"Batalla Naval - Gnome Client v"VERSION" by Riq (c) 1998",-1);
   
	gtk_text_thaw(GTK_TEXT(text));

   
	/* StatusBar */
	hbox_status = gtk_hbox_new ( FALSE, 0);
	gtk_container_add ( GTK_CONTAINER(vbox), hbox_status );
	gtk_container_border_width ( GTK_CONTAINER(hbox_status), 0);
	gtk_widget_show ( hbox_status ); 
   
	statusbar_right = gtk_statusbar_new();
	gtk_box_pack_end( GTK_BOX( hbox_status ), statusbar_right, TRUE,TRUE, 0);
	gtk_widget_show( statusbar_right );

	statusbar_left = gtk_statusbar_new();
	gtk_box_pack_end( GTK_BOX( hbox_status ), statusbar_left, TRUE,TRUE, 0);
	gtk_widget_show( statusbar_left );

	foot_left("Batalla Naval");
	foot_right("Gnome client v"VERSION);

	      
	/* Pixmaps */
	barco1 =    gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco1_xpm );
	barco1_t =  gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco1_t_xpm );
	barco1_h =  gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco1_h_xpm );

	barco2h =   gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco2h_xpm );
	barco2h_t = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco2h_t_xpm );
	barco2h_h = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco2h_h_xpm );

	barco2v =   gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco2v_xpm );
	barco2v_t = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco2v_t_xpm );
	barco2v_h = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco2v_h_xpm );

	barco3h =   gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco3h_xpm );
	barco3h_t = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco3h_t_xpm );
	barco3h_h = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco3h_h_xpm );

	barco3v =   gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco3v_xpm );
	barco3v_t = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco3v_t_xpm );
	barco3v_h = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco3v_h_xpm );

	barco4h =   gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco4h_xpm );
	barco4h_t = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco4h_t_xpm );
	barco4h_h = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco4h_h_xpm );

	barco4v =   gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco4v_xpm );
	barco4v_t = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco4v_t_xpm );
	barco4v_h = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],barco4v_h_xpm );

	fondo =     gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],fondo_xpm );
	agua =      gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],agua_xpm );
	about_pix = gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],about_xpm );
	icono =     gdk_pixmap_create_from_xpm_d( window->window, &mask, &window->style->bg[GTK_STATE_NORMAL],icono_xpm );

	gdk_window_set_icon (window->window, NULL, icono , mask );

   
	/* Principal */   
	gtk_widget_show( window);
}
