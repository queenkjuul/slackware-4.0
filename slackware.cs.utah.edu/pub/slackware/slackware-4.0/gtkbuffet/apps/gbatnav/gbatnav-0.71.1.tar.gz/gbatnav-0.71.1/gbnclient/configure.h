void configure( void );
