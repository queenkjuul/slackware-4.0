/*
	Batalla Naval (c) 1995,98 Ricardo Quesada 
	(rquesada@dc.uba.ar)

	Servidor para Gnome
 
	Modificaciones para adaptar cliente Win16 y bugfixes por:
	Horacio Pe�a ( horape@compendium.com.ar )
	
	24/3/98 0.59.0	Empece a Gnomizarlo 
	05/7/98 ?		Ver en que estado esta el codigo
	17/7/98 0.59.41	Algoritmo de validez de tablas mas descente
	28/7/98 0.59.43	Modularizar el servidor, bugs, de todo.
				Cambiar un poco el protocolo
	07/8/98 0.59.47	Empezar con el robot ( de enserio :-)
	22/8/98 0.79.0	Tratar de gnomefizarlo con menus y esas cosas...
						
 */

/* INCLUDES */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/resource.h>
#include <signal.h>
#include <unistd.h>
#include <netinet/in.h>
#include <stdio.h>
#include <syslog.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

/* Includes de la interface */
#include <config.h>
#include <gnome.h>

#include "protocol.h"                  /* definicion del protocolo */
#include "server.h"
#include "check_board.h"
#include "play.h"
#include "g_interface.h"


/* VARIABLES GLOBALES y STRUCT y TYPEDEF y ... */

/* Estas, antes estaban en main */
gint sock;
struct sockaddr_in server;
struct sockaddr client;
struct rlimit limit_info;

struct st_datos usuario;

gint p=0,d=0;				/* Usadas para pasar los argumentos */

static error_t parse_an_arg (int key, char *arg, struct argp_state *state);
/* This describes all the arguments we understand.  */
static struct argp_option options[] =
{
	{ NULL, 'p', N_("PORT"), 0, N_("Port number. Default is 1995"), 1 },
	{ NULL, 'd', N_("DEBUG"), 0, N_("Debug mode. Default is 0 [0|1]"), 1 },
	{ NULL, 0, NULL, 0, NULL, 0 }
};

/* Our parser.  */
static struct argp parser =
{
	options,
	parse_an_arg,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
};
static error_t parse_an_arg (int key, char *arg, struct argp_state *state)
{
	gchar temporal[100];

	switch(key)
	{
		case 'p':
			usuario.port=atoi(arg);
			p=1;
			break;
		case 'd':
			usuario.debug=atoi(arg);
			d=1;
			break;
		case ARGP_KEY_SUCCESS:
			if(!p)
				usuario.port = gnome_config_get_int("/gbnserver/data/port=1995");
			if(!d)
				usuario.debug= gnome_config_get_int("/gbnserver/data/debug=0");

			strncpy(usuario.robotname,gnome_config_get_string("/gbnserver/data/robotname=Robot"),MAXNAMELEN);
			break;
		default:
			return ARGP_ERR_UNKNOWN;
	}

	gnome_config_set_int("/gbnserver/data/port",usuario.port);
	gnome_config_set_int("/gbnserver/data/debug",usuario.debug);
	gnome_config_set_string("/gbnserver/data/robotname",usuario.robotname);
	gnome_config_sync();

	return 0;
}


/*****************************************************************************
 *                                   FUNCIONES
 *****************************************************************************/

/***************************************************************************** 
 *                           funciones TCP/IP
 ***************************************************************************/
void bnwrite(int fde,char *buf,char tip0,char tip1,char tip2,char jugyo ) 
{
	int i;
	struct protocolo proto;

	proto.bnptip0=tip0;
	proto.bnptip1=tip1;
	proto.bnptip2=tip2;
	proto.jugador=jugyo;
	for(i=0;i<MSGMAXLEN;i++)
		proto.bnpmsg[i]=buf[i];
	strcpy(proto.bnphead,BNPHEAD);
	proto.bnpver=BNPVER;
	write(fde,&proto,MAXLEN);
}

/* manda el mensaje msg a todos los que cumplan nro_tot>=estado menos a nojug */
void broadcast(char *msg,char tip0,int estado, int nojug,char tip1,char tip2,char jugyo) 
{
	char msgnew[MSGMAXLEN];
	int i;
   
	for(i=0;i<MSGMAXLEN;i++)
		msgnew[i]=msg[i];
   
	for(i=0;i<MAXPLAYER;i++) 
	{
		if(i!=nojug && usuario.nro_tot[i]>=estado) 
			bnwrite(usuario.nro_fd[i],msg,tip0,tip1,tip2,jugyo);
	}
}

/***************************************************************************
 *            FUNCIONES RELACIONADAS CON LAS TABLAS y WPRINTD
 ***************************************************************************/

/* write to  board */
int wtable( int jug,struct protocolo *proto ) 
{
	int i,x,y;
	x=0;y=0;
	for(i=0;i<100;i++) 
	{
		usuario.table[jug].p[x][y]=proto->bnpmsg[i];
		x++;
		if(x>=10) 
		{
			x=0;
			y++;
		}
	}
	return( algoritmo(jug));
}
/* read from board */
void rtable( char outbuf[],int jug,char sup) 
{
	int i,x,y;
	x=0;y=0;
	for(i=0;i<100;i++) 
	{
		if(usuario.table[jug].p[x][y]==BARCO)
			outbuf[i]=NOBARCO;
		else
			outbuf[i]=usuario.table[jug].p[x][y];
		x++;
		if(x>=10) 
		{
			x=0;
			y++;
		}
	}
}
/* clean board */
void ctable( int jug) 
{
	int i,x,y;
	x=0;y=0;
	for(i=0;i<100;i++) 
	{
		usuario.table[jug].p[x][y]=NOBARCO;
		x++;
		if(x>=10) 
		{
			x=0;
			y++;
		}
	}
}
/*****************************************************************************
 *                EL BARCO ESTA HUNDIDO ? y todo tipo de funciones
 *****************************************************************************/
int quebarco( int i,int x, int y) 
{
	if( (x<0) || (x>9) || (y<0) || (y>9) )
		return NOBARCO;
	return( usuario.table[i].p[x][y]);
}

/* Se fija si el barco es hundido */
int r_eshundido(int i,	/* Numero de Jugador */
		    int x,	/* X del barco */
		    int y,	/* Y del barco */
		    int xx,	/* Direccion X del barco */
		    int yy	/* Direccion Y del barco */
		    )
{
	if(quebarco(i,x,y)<=NOBARCO)
		  return 0;
	if(quebarco(i,x,y)==TOCADO)
		  return r_eshundido(i,x+xx,y+yy,xx,yy);
	return 1;	/* No es hundido */
}

/* Pinta al barco hundido */
void r_pihundido(int i,	/* Numero de Jugador */
		    int x,	/* X del barco */
		    int y,	/* Y del barco */
		    int xx,	/* Direccion X del barco */
		    int yy	/* Direccion Y del barco */
		    )
{
	if(quebarco(i,x,y)<=NOBARCO)
		  return;
	if(quebarco(i,x,y)==TOCADO)
	{
		usuario.table[i].p[x][y]=HUNDIDO;
		tempbuf[0]=(char)x;
		tempbuf[1]=(char)y;
		tempbuf[2]=HUNDIDO;
		bnwrite(usuario.nro_fd[i],tempbuf,BNHIT,0,0,i+1);

		return r_pihundido(i,x+xx,y+yy,xx,yy);
	}
	printf("server: gbnserver.c: r_pihundido error\n");
}
int eshundido(int i,int x,int y) 
{
	gint a;

	if(quebarco(i,x,y)<=NOBARCO)
		return FALSE;
	if(quebarco(i,x,y)==HUNDIDO)
		  return TRUE;

	usuario.table[i].p[x][y]=TOCADO;	/* Tocado por ahora */
	a =	r_eshundido(i,x-1,y,-1,0) + 
		r_eshundido(i,x+1,y,+1,0) + 
		r_eshundido(i,x,y-1,0,-1) + 
		r_eshundido(i,x,y+1,0,+1);
	if(a==0)
	{
		r_pihundido(i,x,y,-1,0);
		r_pihundido(i,x+1,y,+1,0);
		r_pihundido(i,x,y-1,0,-1);
		r_pihundido(i,x,y+1,0,+1);

		usuario.hits[i]++;
		if(usuario.hits[i]==10) 
		{ /* con 10 barcos hundidos uno pierde */
			textfill(i,_("I lost"));
			bnwrite(usuario.nro_fd[i],tempbuf,BNLOS,0,0,i+1);
			usuario.nro_tot[i]=PERDIO;
			sprintf(tempbuf,"%s[%i] is dead",usuario.names[i],i+1);
			broadcast(tempbuf,BNEXT,CONNEC,i,i+1,1,0);      /* informs that i is dead */
		}
		return TRUE;
	}
	return FALSE;
}
/***************************************************************************** 
 *                           funciones CONTROL DE CHILD Y JUEGO
 ***************************************************************************/

void bnexit( int num_jug, int modo_quit )
{
	gchar outbuf[MSGMAXLEN];
	gint i,j,k;

	/* 
	Nuevo y fundamental (0.70.0) 
	Nota. Primero tiene que decir que uno se fue. y luego
	Pasar el turno. Si los robots se quedan esperando
	*/
	j=0;
	for(k=0;k<MAXPLAYER;k++)
	{
		if( usuario.nro_tot[k]==PLAY || usuario.nro_tot[k]==TURN )
		{
			j++;
			i=k;
		}
	}
	if(j==1)
	{	/* Entonces solo queda un jugador... por ende el ganador */
		bnwrite(usuario.nro_fd[i],outbuf,BNWIN,0,0,i+1);
		sprintf(outbuf,"%s[%i] is the winner.",usuario.names[i],i+1);
		broadcast(outbuf,BNEXT,CONNEC,i,i+1,2,0); 
		broadcast(outbuf,BNOVR,CONNEC,-1,0,0,0);

		/* Se acabo el juego, limpiar tableros... */
		for(i=0;i<MAXPLAYER;i++)
		{
			if(usuario.nro_tot[i]>=CONNEC)
			{  /* Si el usuario estaba conectado limpiar todo */
				usuario.nro_tot[i]=CONNEC;
				usuario.hits[i]=0;
				ctable(i);
			}
		}
		return;
	}
/* 
 * Si el tipo que abandona es el que tiene el turno tiene 
 * que pasar al siguiente
 */
	if(usuario.nro_tot[num_jug]==TURN)
	{         
		for(i=num_jug;i<MAXPLAYER;i++)
		{ 
			if(usuario.nro_tot[i]==PLAY)
				break;
		}
		if(i==MAXPLAYER) 
		{ 
			for(i=0;i<MAXPLAYER;i++) 
			{
				if(usuario.nro_tot[i]==PLAY)
				break;
			}
		}
		if(i!=MAXPLAYER)
		{       
			usuario.nro_tot[i]=TURN;                     
			bnwrite(usuario.nro_fd[i],outbuf,BNTRN,0,0,i+1);
//			sleep(1);                              
		}
	}
	if(modo_quit==0)
		sprintf(outbuf,"%s[%i] quits the game.",usuario.names[num_jug],num_jug+1);
	else /* modo_quit==1 */
		sprintf(outbuf,"%s[%i] aborts the game.",usuario.names[num_jug],num_jug+1);

	usuario.nro_tot[num_jug]=DISCON;
	usuario.hits[num_jug]=0;
	ctable(num_jug);  
	usuario.nro_fd[num_jug]=0;
	usuario.names[num_jug][0]=0;
	
	broadcast(outbuf,BNEXT,PLAY,num_jug,num_jug+1,0,0);

}


void
ex_loop( gpointer data, gint que_sock, GdkInputCondition GDK_INPUT_READ)
{
	gint i,j, client_len;
	gchar outbuf[MSGMAXLEN];
		
	if(que_sock==sock)
	{
		/* Sera asi como se hace. Se aceptan sugerencias */	
		client_len = sizeof(client);
		que_sock=accept(sock,(struct sockaddr *)&client,&client_len);
		if(que_sock==-1)
		{
			printf("accept ERROR\n");
			return;
		}
		i = gdk_input_add( que_sock, GDK_INPUT_READ, ex_loop, NULL );
		for(j=0;j<MAXPLAYER;j++)
		{
			if(usuario.nro_tot[j]==DISCON )
				break;
		}
		if(j==MAXPLAYER)
		{
			bnwrite(que_sock,outbuf,BNALL,i+1,0,i+1);
			gdk_input_remove( i );
			close(que_sock);
			return;
		}
		usuario.nro_tot[j]=CONNEC;
		usuario.nro_fd[j]=que_sock;
		usuario.tag[j]=i;
		textfill(j,"Accepting a new connection",NULL);
	}
	if(play_batnav(que_sock)<0) 
	{
		i = quejugador( que_sock );
		
		textfill(i,"Quitting the game",NULL);
		bnexit(i,1);
		gdk_input_remove( usuario.tag[i] );
		close( que_sock );
	}
}

/*****************
 * main function *
 *****************/
void main(int argc, char *argv[]) 
{
	gint i ;
   
	bindtextdomain (PACKAGE, GNOMELOCALEDIR);
	textdomain (PACKAGE);
	gnome_score_init("gbatnav");

	gnome_init("Batalla Naval server v"VERSION, &parser, argc, argv, 0, NULL);

	gethostname(usuario.server_name,MSGMAXLEN);        
   
	printf("Batalla Naval server v"VERSION" (c) 1995,98\n"
		"by Ricardo Quesada (rquesada@pjn.gov.ar)\n"
		"Running... (port=%i, name=%s, max players=%i )\n"
		"gbnserver -d 1 for debug mode.\n",usuario.port,usuario.server_name,MAXPLAYER);
   
	/* Set default parameters */
	for(i=0;i<MAXPLAYER;i++) 
	{
		usuario.nro_tot[i]=0;
		usuario.nro_fd[i]=0;
		ctable(i);
	}
   
	if(getrlimit(RLIMIT_NOFILE,&limit_info) <0)  
	{
		perror("gbnserver getrlimit error");
		exit(1);
	}
   
	sock=socket(AF_INET,SOCK_STREAM,0);
	if(sock <0) 
	{
		perror("gbnserver socket error");
		exit(1);
	}
	server.sin_family=AF_INET;
	server.sin_addr.s_addr=htonl(INADDR_ANY);
	server.sin_port=htons(usuario.port);
	if(bind(sock,(struct sockaddr *)&server,sizeof(server))< 0) 
	{
		perror("gbnserver bind error");
		exit(2);
	}
   
	init_screen();

	signal(SIGCHLD,SIG_IGN);	/* prevent zombies (para el robot) */

	listen(sock,10);
	
	gdk_input_add( sock, GDK_INPUT_READ, ex_loop, NULL );
	gtk_main();
}
