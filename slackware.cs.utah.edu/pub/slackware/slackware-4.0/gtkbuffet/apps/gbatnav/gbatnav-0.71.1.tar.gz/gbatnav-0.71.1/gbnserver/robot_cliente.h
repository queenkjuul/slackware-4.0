/*
 * Batalla Naval (c) 1995,96,97,98 Ricardo Quesada
 * (rquesada@dc.uba.ar)
 * 
 * Funciones del Batalla Naval.
 * 
 */

#ifndef  __BN_CLIENTE__
# define __BN_CLIENTE__

# ifdef __cplusplus
extern "C" {
# endif __cplusplus

#include <gnome.h>
# include "protocol.h"

#define ROBOTVER "0.0.4" 
#define ROBOTVERH 0
#define ROBOTVERL 0
#define ROBOTVERM 4

struct cliente 
{
	gint sock;					/* socket */
	gint random;				/* Random Number 0.59.38 */	
	gchar names[MAXPLAYER][MAXNAMELEN];	/* other players's name */
	gchar boards[MAXPLAYER][10][10];	/* Board de los enemigos */ 
	gchar estados[MAXPLAYER];		/* Estado de los jugadores */
	gint play;					/* estado */
	gint numjug;				/* number of player */
	gint usrfrom;				/* player who is owner of enemy window */
	gchar mitabla[10][10];			/* mi tabla de barcos */
	gint autostart;				/* autostart the game */
} cliente;

# ifdef __cplusplus
}
# endif __cplusplus
   
#endif __BN_CLIENTE__
