/*****************************************************************************/
/*  gftp.c - the main user interface for the ftp program                     */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"
#include <gdk/gdkkeysyms.h>
#include "options.h"

int main(int argc, char *argv[]) {
   GtkWidget *window, *ui;

   signal(SIGCHLD, sig_child);
#ifdef GNOME
   gnome_init("gFTP", "1.12", argc, argv);
#else
   gtk_init(&argc, &argv);
#endif
   if(argc > 1 && strcmp(argv[1], "--help") == 0) usage();

   read_config_file();
   window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
   gtk_signal_connect(GTK_OBJECT(window), "delete_event", GTK_SIGNAL_FUNC(exitCB), NULL);
   gtk_signal_connect(GTK_OBJECT(window), "destroy", GTK_SIGNAL_FUNC(exitCB), NULL);
   gtk_window_set_title(GTK_WINDOW(window), version);
   
   ui = CreateFTPWindows(window);
   gtk_container_add(GTK_CONTAINER(window), ui);
   gtk_widget_show(window);

   ftp_log(LOG_MISC, "%s, Copyright (C) 1998-1999 Brian Masney <", version);
   ftp_log(LOG_RECV, "masneyb@newwave.net");
   ftp_log(LOG_MISC, ">\nIf you have any questions, comments, or suggestions about this program, please feel free to email them to me.\ngFTP comes with ABSOLUTELY NO WARRANTY; for details, see the COPYING file. ");
   ftp_log(LOG_MISC, "This is free software, and you are welcome to redistribute it under certain conditions; for details, see the COPYING file\n");
   init_gftp(argc, argv, window);
   gtk_widget_show(window);
                
   add_local_files(&window1); 
   gtk_timeout_add(1000, update_downloads, NULL);

   gtk_main();
   return(0);
}  
/*****************************************************************************/
void sig_child(int signo) {
   struct viewedit_data *prevdata, *curdata;
   struct ftp_transfer_data *newtdata;
   struct stat st;
   int status;
   pid_t pid;
   
   /* BIG FIXME */
   pid = wait(&status);
   curdata = prevdata = viewedit_processes;
   while(curdata != NULL) {
      if(curdata->pid == pid) {
         if(!(curdata->flags & VIEWEDIT_VIEW_FILE)) {
            /* We was editing the file. Upload it */
            if(stat(curdata->filename, &st) == -1) {
               ftp_log(LOG_MISC, "Error: Cannot get information about file %s: %s\n", curdata->filename, g_strerror(errno));
            }
            else if(st.st_mtime == curdata->st.st_mtime) {
               ftp_log(LOG_MISC, "File %s was not changed in the file editor so it will not be uploaded\n", curdata->remote_filename);
            }
            else {
               ftp_log(LOG_MISC, "File %s was changed in the file editor. Uploading it back to the remote host\n", curdata->remote_filename);
               newtdata = transfer_one_file (curdata->filename, curdata->remote_filename, 0);
               newtdata->hdata->files->size = st.st_size;
               newtdata->hdata->files->flags |= FILE_TRANS_DONE_RM;
               add_file_transfer (newtdata);
            }
         }
         else if(curdata->flags & VIEWEDIT_RM_FILE) unlink(curdata->filename);

         if(curdata == prevdata) viewedit_processes = viewedit_processes->next;
         else prevdata->next = curdata->next;
         free(curdata);
         break;
      }
      prevdata = curdata;
      curdata = curdata->next;
   }
}
/*****************************************************************************/
void init_gftp (int argc, char *argv[], GtkWidget *parent) {
   struct pix_ext *tempext;
   GtkWidget *sort_wid;
   struct utsname unme;
   struct passwd *pw;
   struct hostent *hent;

   window1.local = window2.local = -1;
   if (*emailaddr == '\0') {
      /* If there is no email address specified, then we'll just use the
         currentuser@currenthost */
      pw = getpwuid (geteuid ());
      uname (&unme);
      if (strchr (unme.nodename, '.')) {
         g_snprintf (emailaddr, sizeof (emailaddr), "%s@%s", pw->pw_name, unme.nodename);
      }
      else {
         hent = gethostbyname (unme.nodename);
         if (hent != NULL) {
            g_snprintf (emailaddr, sizeof (emailaddr), "%s@%s", pw->pw_name, hent->h_name);
         }
         else {
            g_snprintf (emailaddr, sizeof (emailaddr), "%s@%s", pw->pw_name, unme.nodename);
         }
      }
      emailaddr[sizeof (emailaddr)-1] = '\0';
      write_config_file ();
   }
                        
   open_xpm ("dotdot.xpm", parent, &dotdot_pixmap, &dotdot_mask, 1);
   open_xpm ("dir.xpm", parent, &dir_pixmap, &dir_mask, 1);
   open_xpm ("linkdir.xpm", parent, &linkdir_pixmap, &linkdir_mask, 1);
   open_xpm ("linkfile.xpm", parent, &linkfile_pixmap, &linkfile_mask, 1);
   open_xpm ("exe.xpm", parent, &exe_pixmap, &exe_mask, 1);
   open_xpm ("doc.xpm", parent, &doc_pixmap, &doc_mask, 1);
   open_xpm ("up.xpm", parent, &up_pixmap, &up_mask, 1);
   open_xpm ("down.xpm", parent, &down_pixmap, &down_mask, 1);
   
   if (window1.sortasds) sort_wid = gtk_pixmap_new (down_pixmap, down_mask);
   else sort_wid = gtk_pixmap_new (up_pixmap, up_mask);
   gtk_widget_show(sort_wid);
   gtk_clist_set_column_widget (GTK_CLIST (window1.listbox), 0, sort_wid);

   if (window2.sortasds) sort_wid = gtk_pixmap_new (down_pixmap, down_mask);
   else sort_wid = gtk_pixmap_new (up_pixmap, up_mask);
   gtk_widget_show (sort_wid);
   gtk_clist_set_column_widget(GTK_CLIST(window2.listbox), 0, sort_wid);

   tempext = registered_exts;
   while (tempext != NULL) {
      open_xpm (tempext->filename, parent, &tempext->pixmap, &tempext->mask, 1);
      tempext = tempext->next;
   }
   if (argc > 2) usage ();
   else if (argc == 2) {
      if (gftp_parse_url (window2.hdata->ftpdata, argv[1]) == 0) {
         fix_display ();
         ftp_connect (window2.hdata);
      }
      else usage ();
   }
}
/*****************************************************************************/
void usage (void) {
   printf ("usage: gftp [[ftp://][user:pass@]ftp-site[:port][/directory]]\n");
   exit (0);
}
/*****************************************************************************/
GtkWidget *CreateFTPWindows(GtkWidget *ui) {
   GtkWidget *box, *dlbox, *winpane, *dlpane, *logpane, *vscrollbar, *mainvbox, *tempwid;
   GtkItemFactory *factory;
   GtkAccelGroup *accel_group;
   char *dltitles[3] = {"Filename", "Progress", "Hostname"};
   GtkItemFactoryEntry menu_items[] = {
      {"/_FTP",			NULL,	0,		0,	"<Branch>"},
      {"/FTP/tearoff",		NULL,	0,		0,	"<Tearoff>"},
      {"/FTP/Ascii", 		NULL, 	change_setting,	1,	"<RadioItem>"},
      {"/FTP/Binary", 		NULL, 	change_setting,	2,	"/FTP/Ascii"},
      {"/FTP/sep", 		NULL, 	0, 		0,	"<Separator>"},
      {"/FTP/_Options...", 	"<control>O",	options_dialog, 0},
      {"/FTP/sep", 		NULL, 	0, 		0,	"<Separator>"},
      {"/FTP/_Quit", 		"<control>Q", 	exitCB,	0},
      {"/_Local",		NULL,	0,		0,	"<Branch>"},
      {"/Local/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Local/Change Filespec...", NULL, change_filespec, 0},
      {"/Local/Select All", 	NULL, 	selectall, 	0},
      {"/Local/Select All Files", 	NULL, 	selectallfiles, 	0},
      {"/Local/Deselect All", 	NULL, 	deselectall, 	0},
      {"/Local/sep",		NULL,	0,		0,	"<Separator>"},
      {"/Local/Change Directory", NULL,	chfunc, 	0},
      {"/Local/Chmod...",	NULL,	chmod_dialog,	0},
      {"/Local/Make Directory...", NULL, mkdir_dialog, 	0},
      {"/Local/Rename...", 	NULL, 	rename_dialog, 	0},
      {"/Local/Delete...", 	NULL, 	delete_dialog, 	0},
      {"/Local/Edit...",	NULL,	edit_dialog,	0},
      {"/Local/View...",	NULL,	view_dialog,	0},
      {"/Local/Refresh", 	NULL, 	refresh, 	0},
      {"/_Remote",		NULL,	0,		0,	"<Branch>"},
      {"/Remote/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Remote/_Connect...", 	"<control>C", 	connect_dialog, 0},
      {"/Remote/Open _URL...",	"<control>U",	openurl_dialog,	0},
      {"/Remote/_Disconnect", 	"<control>D", 	disconn, 	0},
      {"/Remote/sep",		NULL,	0,		0,	"<Separator>"},
      {"/Remote/Change Filespec...", NULL, change_filespec, 0},
      {"/Remote/Select All", 	NULL, 	selectall, 	0},
      {"/Remote/Select All Files", 	NULL, 	selectallfiles, 	0},
      {"/Remote/Deselect All", 	NULL, 	deselectall, 	0},
      {"/Remote/sep",		NULL,	0,		0,	"<Separator>"},
      {"/Remote/Change Directory", NULL, chfunc, 	0},
      {"/Remote/Chmod...",	NULL,	chmod_dialog,	0},
      {"/Remote/Make Directory...", NULL, mkdir_dialog,	0},
      {"/Remote/Rename...", 	NULL, 	rename_dialog, 	0},
      {"/Remote/Delete...", 	NULL, 	delete_dialog, 	0},
      {"/Remote/Edit...",	NULL,	edit_dialog,	0},
      {"/Remote/View...",	NULL,	view_dialog,	0},
      {"/Remote/Refresh", 	NULL, 	refresh, 	0},
      {"/_Transfers",		NULL,	0,		0,	"<Branch>"},
      {"/Transfers/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Transfers/Stop Transfer", NULL, stop_transfer,	0},
      {"/Transfers/sep",	NULL,	0,		0,	"<Separator>"},
      {"/Transfers/Retrieve Files", "<control>R",  retrmenu,	0},
      {"/Transfers/Put Files",	"<control>P",	putmenu,	0},
      {"/L_ogging",		NULL,	0,		0,	"<Branch>"},
      {"/Logging/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Logging/Clear", 	NULL, 	clearlog, 	0},
      {"/Logging/View log...", 	NULL, 	viewlog, 	0},
      {"/Logging/Save log...", 	NULL, 	savelog, 	0},
      {"/Tool_s",		NULL,	0,		0,	"<Branch>"},
      {"/Tools/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Tools/Compare Windows", NULL, 	compare_windows,  0},
      {"/_Help", 		NULL, 	0,		0,	"<LastBranch>"},
      {"/Help/tearoff",		NULL,	0,		0,	"<Tearoff>"},
      {"/Help/About...", 	NULL, 	about_dialog,	0}};
   int i;
      
   mainvbox = gtk_vbox_new (FALSE, 0);
   gtk_widget_show (mainvbox);

   accel_group = gtk_accel_group_new ();
   factory = gtk_item_factory_new (GTK_TYPE_MENU_BAR, "<main>", accel_group);

   i = 0;
   /* FTP Menu */
   gtk_item_factory_create_items (factory, 8, menu_items, &window2);
   i += 8;
   /* Local Menu */
   gtk_item_factory_create_items (factory, 15, menu_items + i, &window1);
   i += 15;
   /* Remote Menu */
   gtk_item_factory_create_items (factory, 19, menu_items + i, &window2);
   i += 19;
   /* Transfers Menu */
   gtk_item_factory_create_items (factory, 6, menu_items + i, NULL);
   i += 6;
   /* Logging Menu */
   gtk_item_factory_create_items (factory, 5, menu_items + i, NULL);
   i += 5;
   /* Tools Menu */
   gtk_item_factory_create_items (factory, 3, menu_items + i, NULL);
   i += 3;
   /* Help Menu */
   gtk_item_factory_create_items (factory, 3, menu_items + i, NULL);
   i += 3;
   
   gtk_accel_group_attach (accel_group, GTK_OBJECT (ui));
   gtk_box_pack_start (GTK_BOX (mainvbox), factory->widget, FALSE, FALSE, FALSE);
   gtk_widget_show (factory->widget);

   tempwid = gtk_item_factory_get_widget (factory, menu_items[2].path);
   gtk_check_menu_item_set_state (GTK_CHECK_MENU_ITEM (tempwid), FALSE);

   tempwid = gtk_item_factory_get_widget (factory, menu_items[3].path);
   gtk_check_menu_item_set_state (GTK_CHECK_MENU_ITEM (tempwid), TRUE);

#if 0
   GtkWidget *hostedit, *useredit, *passedit, *portedit;
   tempwid = gtk_handle_box_new ();
   gtk_box_pack_start (GTK_BOX (mainvbox), tempwid, FALSE, FALSE, FALSE);
   gtk_widget_show (tempwid);
   
   toolbar = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_ICONS);
   gtk_container_border_width (GTK_CONTAINER (toolbar), 3);
   gtk_container_add (GTK_CONTAINER (tempwid), toolbar);
   gtk_widget_show (toolbar);
   
   tempwid = toolbar_pixmap (mainvbox, tb_jump_to_xpm);
   gtk_toolbar_append_item (GTK_TOOLBAR (toolbar), "Connect", "Connect", NULL,
   	tempwid, NULL, NULL);
   gtk_toolbar_append_space (GTK_TOOLBAR (toolbar));
   	
   tempwid = toolbar_pixmap (mainvbox, tb_preferences_xpm);
   gtk_toolbar_append_item (GTK_TOOLBAR (toolbar), "Options", "Options", NULL,
   	tempwid, NULL, NULL);
   gtk_toolbar_append_space (GTK_TOOLBAR (toolbar));

   tempwid = toolbar_pixmap (mainvbox, tb_refresh_xpm);
   gtk_toolbar_append_item (GTK_TOOLBAR (toolbar), "Refresh", "Refresh", NULL,
   	tempwid, NULL, NULL);
   gtk_toolbar_append_space (GTK_TOOLBAR (toolbar));
   
   tempwid = gtk_handle_box_new ();
   gtk_box_pack_start (GTK_BOX (mainvbox), tempwid, FALSE, FALSE, FALSE);
   gtk_widget_show (tempwid);
   
   toolbar = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
   gtk_container_border_width (GTK_CONTAINER (toolbar), 3);
   gtk_container_add (GTK_CONTAINER (tempwid), toolbar);
   gtk_widget_show (toolbar);
   
   tempwid = gtk_label_new ("Host: ");
   gtk_widget_show (tempwid);
   gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), tempwid, NULL, NULL);
   
   hostedit = gtk_entry_new ();
   gtk_widget_set_usize (hostedit, 150, 0);
   gtk_widget_show (hostedit);
   gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), hostedit, NULL, NULL);
   gtk_toolbar_append_space (GTK_TOOLBAR (toolbar));

   tempwid = gtk_label_new ("Port: ");
   gtk_widget_show (tempwid);
   gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), tempwid, NULL, NULL);
   
   portedit = gtk_entry_new ();
   gtk_widget_set_usize (portedit, 25, 0);
   gtk_widget_show (portedit);
   gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), portedit, NULL, NULL);
   gtk_toolbar_append_space (GTK_TOOLBAR (toolbar));

   tempwid = gtk_label_new ("User: ");
   gtk_widget_show (tempwid);
   gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), tempwid, NULL, NULL);
   
   useredit = gtk_entry_new ();
   gtk_widget_set_usize (useredit, 75, 0);
   gtk_widget_show (useredit);
   gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), useredit, NULL, NULL);
   gtk_toolbar_append_space (GTK_TOOLBAR (toolbar));

   tempwid = gtk_label_new ("Pass: ");
   gtk_widget_show (tempwid);
   gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), tempwid, NULL, NULL);
   
   passedit = gtk_entry_new ();
   gtk_widget_set_usize (passedit, 75, 0);
   gtk_widget_show (passedit);
   gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), passedit, NULL, NULL);
#endif
   
   winpane = gtk_hpaned_new ();
   box = gtk_hbox_new (FALSE, 0);
   window1.local = 1;
   local_frame = CreateFTPWindow (&window1);
   window1.local = -1;

   gtk_box_pack_start (GTK_BOX (box), local_frame, TRUE, TRUE, FALSE);
   gtk_widget_show (local_frame);

   dlbox = gtk_vbox_new (FALSE, 0);
   gtk_container_border_width (GTK_CONTAINER (dlbox), 5);

   tempwid = gtk_button_new_with_label ("->");
   gtk_box_pack_start (GTK_BOX (dlbox), tempwid, TRUE, FALSE, FALSE);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (putCB), (gpointer) NULL);
   gtk_widget_show (tempwid);

   tempwid = gtk_button_new_with_label ("<-");
   gtk_box_pack_start (GTK_BOX (dlbox), tempwid, TRUE, FALSE, FALSE);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (retrCB), (gpointer) NULL);
   gtk_widget_show (tempwid);

   gtk_box_pack_start (GTK_BOX (box), dlbox, FALSE, FALSE, FALSE);
   gtk_widget_show (dlbox);
   gtk_widget_show (box);
   gtk_paned_pack1 (GTK_PANED (winpane), box, 1, 1);
   
   remote_frame = CreateFTPWindow (&window2);
   gtk_paned_pack2 (GTK_PANED (winpane), remote_frame, 1, 1);
   gtk_widget_show (remote_frame);
   gtk_widget_show (winpane);

   dlpane = gtk_vpaned_new ();
   gtk_paned_pack1 (GTK_PANED (dlpane), winpane, 1, 1);

   transfer_scroll = gtk_scrolled_window_new (NULL, NULL);
   gtk_widget_set_usize (transfer_scroll, 1, transfer_height);
   gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (transfer_scroll),
   	GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
   dlwdw = gtk_clist_new_with_titles (3, dltitles);
   gtk_container_add (GTK_CONTAINER (transfer_scroll), dlwdw);
   gtk_clist_set_column_width (GTK_CLIST (dlwdw), 0, 100);
   gtk_clist_set_column_width (GTK_CLIST (dlwdw), 1, 250);
   gtk_clist_set_column_width (GTK_CLIST (dlwdw), 2, 100);
   gtk_container_border_width (GTK_CONTAINER (dlwdw), 5);
   gtk_signal_connect (GTK_OBJECT (dlwdw), "select_row", GTK_SIGNAL_FUNC (selectdl), NULL);
   gtk_signal_connect (GTK_OBJECT (dlwdw), "unselect_row", GTK_SIGNAL_FUNC (unselectdl), NULL);
   gtk_paned_pack2 (GTK_PANED (dlpane), transfer_scroll, 1, 1);
   gtk_widget_show (dlwdw);
   gtk_widget_show (transfer_scroll);
   gtk_widget_show (dlpane);

   logpane = gtk_vpaned_new ();
   gtk_paned_pack1 (GTK_PANED (logpane), dlpane, 1, 1);

   log_table = gtk_table_new (1, 2, FALSE);
   gtk_widget_set_usize (log_table, 1, log_height);
   logwdw = gtk_text_new (NULL, NULL);
   gtk_text_set_editable (GTK_TEXT (logwdw), FALSE);
   gtk_text_set_word_wrap (GTK_TEXT (logwdw), TRUE);
   gtk_table_attach (GTK_TABLE (log_table), logwdw, 0, 1, 0, 1,
   	GTK_FILL | GTK_EXPAND, GTK_FILL | GTK_EXPAND | GTK_SHRINK, 0, 0);
   gtk_widget_show (logwdw);

   vscrollbar = gtk_vscrollbar_new (GTK_TEXT (logwdw)->vadj);
   gtk_table_attach (GTK_TABLE (log_table), vscrollbar, 1, 2, 0, 1,
   	GTK_FILL, GTK_EXPAND | GTK_FILL | GTK_SHRINK, 0, 0);
   gtk_widget_show (vscrollbar);
   gtk_widget_show (log_table);
   
   gtk_paned_pack2 (GTK_PANED (logpane), log_table, 1, 1);
   gtk_widget_show (logpane);      
   gtk_box_pack_start (GTK_BOX (mainvbox), logpane, TRUE, TRUE, TRUE);

   return (mainvbox);
}   
/*****************************************************************************/
GtkWidget *toolbar_pixmap (GtkWidget *widget, char **xpmdata) {
   GtkWidget *pix;
   GdkPixmap *pixmap;
   GdkBitmap *bitmap;
   
   pixmap = gdk_pixmap_create_from_xpm_d (widget->window, &bitmap, 
  	&widget->style->bg[GTK_STATE_NORMAL], xpmdata);

   pix = gtk_pixmap_new (pixmap, bitmap);
   gtk_widget_show (pix);

   gdk_pixmap_unref (pixmap);
   gdk_pixmap_unref (bitmap);
   return (pix);
}
/*****************************************************************************/
GtkWidget *CreateFTPWindow(struct ftp_window_data *wdata) {
   char *titles[7] = {"", "Filename", "Size", "User", "Group", "Date", "Attribs"};
   const GtkTargetEntry possible_types[] = {
      {"STRING",			0,	0},
      {"text/plain", 			0, 	0},
      {"application/x-rootwin-drop", 	0, 	1}};
   GtkWidget *box, *scroll_list, *parent;

   strncpy(wdata->filespec, "*", sizeof(wdata->filespec));
   wdata->filespec[sizeof(wdata->filespec)-1] = '\0';
   wdata->hdata = new_hdata();
   wdata->hdata->wdata = wdata;
   wdata->sortcol = 1;
   wdata->sortasds = 1;
   wdata->totalitems = wdata->numselected = 0;

   parent = gtk_frame_new(NULL);
   gtk_widget_set_usize(parent, wdata->local ? listbox_local_width : listbox_remote_width,
      listbox_file_height);
   gtk_container_border_width(GTK_CONTAINER(parent), 5);

   box = gtk_vbox_new(FALSE, 0);
   gtk_container_border_width(GTK_CONTAINER(box), 5);
   gtk_container_add(GTK_CONTAINER(parent), box);
   
   wdata->diredit = gtk_entry_new_with_max_length(MAXSTR);
   gtk_box_pack_start(GTK_BOX(box), wdata->diredit, FALSE, FALSE, FALSE);
   gtk_signal_connect(GTK_OBJECT(wdata->diredit), "activate", GTK_SIGNAL_FUNC(chdiredit), (gpointer) wdata);
   gtk_widget_show(wdata->diredit);
   
   wdata->hoststxt = gtk_label_new("Not connected");
   gtk_misc_set_alignment(GTK_MISC(wdata->hoststxt), 0, 0);
   gtk_box_pack_start(GTK_BOX(box), wdata->hoststxt, FALSE, FALSE, FALSE);
   gtk_widget_show(wdata->hoststxt);

   scroll_list = gtk_scrolled_window_new(NULL, NULL);
   gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll_list),
      GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
   wdata->listbox = gtk_clist_new_with_titles(7, titles);
   gtk_container_add(GTK_CONTAINER(scroll_list), wdata->listbox);
   gtk_drag_source_set(wdata->listbox, GDK_BUTTON2_MASK, possible_types, 3,
      GDK_ACTION_COPY | GDK_ACTION_MOVE);
   gtk_drag_dest_set(wdata->listbox, GTK_DEST_DEFAULT_ALL, possible_types, 2,
      GDK_ACTION_COPY | GDK_ACTION_MOVE);
   gtk_clist_set_selection_mode(GTK_CLIST(wdata->listbox), GTK_SELECTION_EXTENDED);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 0, 16);
   gtk_clist_set_column_justification(GTK_CLIST(wdata->listbox), 0, GTK_JUSTIFY_CENTER);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 1, listbox_filename_width);
   gtk_clist_set_column_justification(GTK_CLIST(wdata->listbox), 2, GTK_JUSTIFY_RIGHT);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 2, 85);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 3, 65);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 4, 65);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 5, 120);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 6, 75);
   gtk_box_pack_start(GTK_BOX(box), scroll_list, TRUE, TRUE, TRUE);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "click_column", GTK_SIGNAL_FUNC(sortrows), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "select_row", GTK_SIGNAL_FUNC(selectrow), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "unselect_row", GTK_SIGNAL_FUNC(unselectrow), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "button_press_event", GTK_SIGNAL_FUNC(list_dblclick), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "key_press_event", GTK_SIGNAL_FUNC(list_enter), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "drag_data_get", GTK_SIGNAL_FUNC(listbox_drag), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "drag_data_received", GTK_SIGNAL_FUNC(listbox_get_drag_data), (gpointer) wdata);
   gtk_widget_show(wdata->listbox);
   gtk_widget_show(scroll_list);

   gtk_widget_show(box);
   gtk_widget_show(parent);

   return(parent);
}
/*****************************************************************************/
void listbox_drag (GtkWidget *widget, GdkDragContext *context, GtkSelectionData *selection_data, guint info, guint32 clk_time, gpointer data) {
   struct ftp_window_data *wdata;
   struct ftp_file_data *tempfle;
   size_t totlen, oldlen;
   char tempstr[MAXSTR];
   char *str = NULL;
   
   totlen = 0;
   wdata = (struct ftp_window_data *) data;
   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Drag-N-Drop: Not connected to a remote site\n");
      return;
   }
   if (wdata->numselected == 0) {
      ftp_log (LOG_MISC, "Drag-N-Drop: You must have at least one item selected\n");
      return;
   }

   if ((tempfle = get_next_selected_filename (wdata->hdata->files)) == NULL) {
      ftp_log (LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
      return;
   }

   while (tempfle != NULL) {
      if (totlen != 0) totlen--;
      oldlen = totlen;
      if (wdata->local == 1) {
          g_snprintf (tempstr, sizeof(tempstr), "%s/%s\n", GFTP_GET_DIRECTORY (wdata->hdata->ftpdata), tempfle->file);
      }
      else {
         g_snprintf (tempstr, sizeof (tempstr), "%s://%s:%s@%s:%d%s/%s\n", 
            wdata->hdata->protocol == ftp ? "ftp" : "http",
            GFTP_GET_USERNAME (wdata->hdata->ftpdata), 
            GFTP_GET_PASSWORD (wdata->hdata->ftpdata), 
            GFTP_GET_HOSTNAME (wdata->hdata->ftpdata),
            GFTP_GET_PORT (wdata->hdata->ftpdata),
            GFTP_GET_DIRECTORY (wdata->hdata->ftpdata), tempfle->file);
      }
      tempstr[sizeof(tempstr)-1] = '\0';
      remove_double_slashes (tempstr+6);
      totlen += strlen (tempstr)+1;
      str = g_realloc (str, totlen);
      strcpy (str+oldlen, tempstr);
      tempfle = get_next_selected_filename (tempfle->next);
   }

   if(totlen > 1) str[totlen-2] = '\0';
   gtk_selection_data_set (selection_data, selection_data->target, 8,
      str, strlen (str));
   g_free (str);
}
/*****************************************************************************/
void listbox_get_drag_data(GtkWidget *widget, GdkDragContext *context, gint x, gint y, GtkSelectionData *selection_data, guint info, guint32 clk_time, struct ftp_window_data *wdata) {
   struct ftp_transfer_data *tdata, *newtdata, *temptdata, *new_file_transfers;
   struct ftp_file_data *newfle;
   char *newpos, *oldpos, *pos;
   char *tempstr, tempchar;
   int finish_drag;
   struct stat st;
   
   finish_drag = 0;
   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Drag-N-Drop: Not connected to a remote site\n");
      return;
   }
   new_file_transfers = NULL;
   if ((selection_data->length >= 0) && (selection_data->format == 8)) {
      if (!wdata->local) {
         tdata = new_tdata();
         copy_hdata_struct (window2.hdata, tdata->hdata);
         if(wdata->local) {
            tdata->flags |= TRANSFER_DIRECTION;
            tdata->hdata->wdata = &window2;
         }
         else {
            tdata->hdata->wdata = &window1;
         }
         tdata->curfle = NULL;
         tdata->next = new_file_transfers;
         new_file_transfers = tdata;
      }
      else tdata = NULL;

      oldpos = (char *) selection_data->data;
      while ((newpos = strchr (oldpos, '\n')) || (newpos = strchr (oldpos, '\0'))) {
         tempstr = g_malloc (newpos - oldpos + 1);
         tempchar = *newpos;
         *newpos = '\0';
         strcpy (tempstr, oldpos);
         *newpos = tempchar;

         if (!wdata->local && strncmp (oldpos, "ftp://", 6) == 0) {
            ftp_log (LOG_MISC, "Drag-N-Drop: Ignoring file %s: Cannot drag a ftp site to a ftp site\n", tempstr);
            if (*newpos == '\0') break;
            oldpos = newpos + 1;
            continue;
         }
         else if (wdata->local && strncmp (oldpos, "ftp://", 6) != 0) {
            ftp_log (LOG_MISC, "Drag-N-Drop: Ignoring file %s: Cannot drag a local file to the local window\n", tempstr);
            if (*newpos == '\0') break;
            oldpos = newpos + 1;
            continue;
         }
         else {
            newfle = g_malloc0 (sizeof (struct ftp_file_data));
            if (wdata->local) {
               newtdata = new_tdata ();
               if (wdata->local) {
                  newtdata->flags |= TRANSFER_DIRECTION;
                  newtdata->hdata->wdata = &window2;
               }
               else {
                  newtdata->hdata->wdata = &window1;
               }
               newtdata->curfle = NULL;
               if (gftp_parse_url (newtdata->hdata->ftpdata, tempstr) != 0) {
                  ftp_log (LOG_MISC, "Drag-N-Drop: Ignoring url %s: Not a valid url\n", tempstr);
                  if (*newpos == '\0') break;
                  oldpos = newpos + 1;
                  free_hdata (newtdata->hdata);
                  g_free (newtdata);
                  continue;
               }
               
               pos = strrchr (GFTP_GET_DIRECTORY (newtdata->hdata->ftpdata), '/');
               if (pos == NULL) pos = GFTP_GET_DIRECTORY (newtdata->hdata->ftpdata);
               if (newfle->remote_file) g_free (newfle->remote_file);
               if (newfle->file) g_free (newfle->file);
               if (wdata->local) {
                  newfle->remote_file = g_strjoin (NULL, GFTP_GET_DIRECTORY (newtdata->hdata->ftpdata), NULL);
                  newfle->file = g_strjoin (NULL, GFTP_GET_DIRECTORY (window1.hdata->ftpdata), "/", pos, NULL);
               }
               else {
                  newfle->file = g_strjoin (NULL, GFTP_GET_DIRECTORY (newtdata->hdata->ftpdata), NULL);
                  newfle->remote_file = g_strjoin (NULL, GFTP_GET_DIRECTORY (window1.hdata->ftpdata), "/", pos, NULL);
               }
               newfle->flags = get_file_transfer_mode (newfle->file);
               remove_double_slashes (newfle->file);
               newfle->size = 0;
               *pos = '\0';
               gftp_set_directory (newtdata->hdata->ftpdata, "");
               temptdata = new_file_transfers;
               while (temptdata != NULL) {
                  if (compare_hdata_structs (temptdata->hdata, newtdata->hdata)) {
                     tdata = temptdata;
                     break;
                  }
                  temptdata = temptdata->next;
               }
               if (temptdata == NULL) {
                  newtdata->next = new_file_transfers;
                  new_file_transfers = newtdata;
                  tdata = newtdata;
               }
               else {
                  tdata = temptdata;
                  free_hdata (newtdata->hdata);
                  g_free (newtdata);
               }
            }
            else {
               stat (tempstr, &st);
               strncpy (newfle->file, tempstr, sizeof (newfle->file));
               newfle->size = st.st_size;
            }
            newfle->next = NULL;
            if (tdata->hdata->last == NULL) tdata->hdata->files = newfle;
            else tdata->hdata->last->next = newfle;
            tdata->hdata->last = newfle;
            tdata->hdata->totalfiles++;
            if (tdata->curfle == NULL) tdata->curfle = newfle;
            finish_drag = 1;
         }
         if (*newpos == '\0') break;
         oldpos = newpos + 1;
      }
   }
   if (finish_drag) {
      temptdata = new_file_transfers;
      while (temptdata != NULL) {
         dotrans (temptdata);
         temptdata = temptdata->next;
      }
      add_file_transfer (new_file_transfers);
   }
   gtk_drag_finish(context, finish_drag, FALSE, clk_time);
}
/*****************************************************************************/
void sortrows (GtkCList *clist, gint column, gpointer data) {
   struct ftp_file_data *tempfle, *prevfle, *curfle, *dirs, *files;
   struct ftp_window_data *wdata;
   GtkWidget *sort_wid;

   wdata = (struct ftp_window_data *) data;
   if (!wdata->hdata->files) return;
   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Sort: Not connected to a remote site\n");
      return;
   }
   
   gtk_label_set (GTK_LABEL(wdata->hoststxt), "Sorting...");
   fix_display ();
   if (column == 0) {
      wdata->sortasds = !wdata->sortasds;
      column = wdata->sortcol;
      sort_wid = gtk_clist_get_column_widget (clist, 0);
      gtk_widget_destroy (sort_wid);
      if (wdata->sortasds) sort_wid = gtk_pixmap_new (down_pixmap, down_mask);
      else sort_wid = gtk_pixmap_new (up_pixmap, up_mask);
      gtk_widget_show (sort_wid);
      gtk_clist_set_column_widget (clist, 0, sort_wid);
   }
   else wdata->sortcol = column;
   dirs = files = NULL;
   while (wdata->hdata->files != NULL) {
      curfle = wdata->hdata->files;
      wdata->hdata->files = wdata->hdata->files->next;
      if (sort_dirs_first && curfle->flags & FILE_ISDIR) tempfle = prevfle = dirs;
      else tempfle = prevfle = files;
      if (column == 1) {
         while (tempfle != NULL && (wdata->sortasds ?
         	strcmp (tempfle->file, curfle->file) <= 0 :
         	strcmp (tempfle->file, curfle->file) >= 0)) {
            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if (column == 2) {
         while (tempfle != NULL && (wdata->sortasds ? 
         	tempfle->size <= curfle->size : 
         	tempfle->size >= curfle->size)) {
            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if (column == 3) {
         while (tempfle != NULL && (wdata->sortasds ?
         	strcmp (tempfle->user, curfle->user) <= 0 :
         	strcmp (tempfle->user, curfle->user) >= 0)) {
            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if (column == 4) {
         while (tempfle != NULL && (wdata->sortasds ?
         	strcmp (tempfle->group, curfle->group) <= 0 :
         	strcmp (tempfle->group, curfle->group) >= 0)) {
            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if (column == 5) { 
         while (tempfle != NULL && (wdata->sortasds ? 
         	tempfle->datetime <= curfle->datetime : 
         	tempfle->datetime >= curfle->datetime)) {
            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if (column == 6) {
         while (tempfle != NULL && (wdata->sortasds ?
         	strcmp (tempfle->attribs, curfle->attribs) <= 0 :
         	strcmp (tempfle->attribs, curfle->attribs) >= 0)) {
            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }

      if (tempfle == NULL || tempfle == prevfle) {
         if (prevfle == tempfle) {
            if (sort_dirs_first && curfle->flags & FILE_ISDIR) {
               curfle->next = dirs;
               dirs = curfle;
            }
            else {
               curfle->next = files;
               files = curfle;
            }
         }
         else {
            curfle->next = NULL;
            prevfle->next = curfle;
         }
      }
      else {            
         curfle->next = prevfle->next;
         prevfle->next = curfle;
      }
   }
   if (dirs == NULL) wdata->hdata->files = files;
   else {
      tempfle = dirs;
      wdata->hdata->files = dirs;
      while (tempfle->next != NULL) tempfle = tempfle->next;
      tempfle->next = files;
   }
      
   gtk_clist_freeze (clist);
   deselectall (wdata);
   gtk_clist_clear (clist);
   tempfle = wdata->hdata->files;
   while (tempfle != NULL) {
      add_file_listbox (wdata, tempfle);
      tempfle = tempfle->next;
   }
   gtk_clist_thaw (clist);
   update_ftp_info (wdata);
}
/*****************************************************************************/
void delete_ftp_file_info (struct ftp_window_data *wdata) {
   gtk_clist_clear (GTK_CLIST (wdata->listbox));
   free_file_list (wdata->hdata->files);
   wdata->hdata->last = NULL;
   wdata->hdata->files = NULL;
}
/*****************************************************************************/
void queue_log (int type, char *format, ...) {
   struct ftp_log_queue *newlog, *templog;
   char tempstr[MAXSTR];
   va_list argp;
   
   newlog = g_malloc (sizeof(struct ftp_log_queue));
   newlog->type = type;
   va_start (argp, format);
   g_vsnprintf (tempstr, sizeof(tempstr), format, argp);
   tempstr[sizeof(tempstr)-1] = '\0';
   strncpy (newlog->msg, tempstr, sizeof (newlog->msg));
   newlog->next = NULL;
   pthread_mutex_lock (&log_mutex);
   if (file_transfer_logs == NULL) file_transfer_logs = newlog;
   else {
      templog = file_transfer_logs;
      while (templog->next != NULL) templog = templog->next;
      templog->next = newlog;
   }
   pthread_mutex_unlock (&log_mutex);
}
/*****************************************************************************/
void ft_log (gftp_logging_type level, void *ptr, const char *string, ...) {
   struct ftp_log_queue *newlog, *templog;
   va_list argp;
   
   newlog = g_malloc (sizeof(struct ftp_log_queue));
   newlog->type = level;
   va_start (argp, string);
   g_vsnprintf (newlog->msg, sizeof (newlog->msg), string, argp);
   newlog->msg[sizeof(newlog->msg)-1] = '\0';
   newlog->next = NULL;
   pthread_mutex_lock (&log_mutex);
   if (file_transfer_logs == NULL) file_transfer_logs = newlog;
   else {
      templog = file_transfer_logs;
      while (templog->next != NULL) templog = templog->next;
      templog->next = newlog;
   }
   pthread_mutex_unlock (&log_mutex);
}
/*****************************************************************************/
void log (gftp_logging_type level, void *ptr, const char *string, ...) {
   char tempstr[MAXSTR];
   GdkColormap *cmap;
   GdkColor fore;
   va_list argp;
   guint pos;
   int upd;

   upd = GTK_TEXT (logwdw)->vadj->upper - GTK_TEXT (logwdw)->vadj->page_size == GTK_TEXT (logwdw)->vadj->value;
   cmap = gdk_colormap_get_system ();
   fore.red = fore.green = fore.blue = 0;
   if (level == gftp_logging_send) fore.green = 0x8600;
   else if (level == gftp_logging_recv) fore.blue = 0xffff;
   else fore.red = 0xffff;
   if (!gdk_color_alloc(cmap, &fore)) g_error ("Could not allocate color for log window");
   gtk_text_freeze (GTK_TEXT (logwdw));
   pos = gtk_text_get_length (GTK_TEXT(logwdw));

   va_start (argp, string);
   g_vsnprintf (tempstr, sizeof (tempstr), string, argp);
   tempstr[sizeof (tempstr)-1] = '\0';
   gtk_text_insert (GTK_TEXT (logwdw), NULL, &fore, NULL, tempstr, -1);
   
   gtk_text_set_point (GTK_TEXT (logwdw), pos+strlen(tempstr));
   gtk_text_thaw (GTK_TEXT (logwdw));
   if (upd) {
      gtk_adjustment_set_value (GTK_TEXT (logwdw)->vadj, 
      		GTK_TEXT (logwdw)->vadj->upper - GTK_TEXT (logwdw)->vadj->page_size);
   }
   fix_display ();
}
/*****************************************************************************/
void ftp_log (int type, char *format, ...) {
   char tempstr[MAXSTR];
   GdkColormap *cmap;
   GdkColor fore;
   va_list argp;
   guint pos;
   int upd;
   
   upd = GTK_TEXT (logwdw)->vadj->upper - GTK_TEXT (logwdw)->vadj->page_size == GTK_TEXT (logwdw)->vadj->value;
   cmap = gdk_colormap_get_system ();
   fore.red = fore.green = fore.blue = 0;
   if (type == LOG_SEND) fore.green = 0x8600;
   else if (type == LOG_RECV) fore.blue = 0xffff;
   else fore.red = 0xffff;
   if (!gdk_color_alloc (cmap, &fore)) g_error ("Could not allocate color for log window");
   gtk_text_freeze (GTK_TEXT (logwdw));
   pos = gtk_text_get_length (GTK_TEXT (logwdw));

   va_start (argp, format);
   g_vsnprintf (tempstr, sizeof (tempstr), format, argp);
   tempstr[sizeof (tempstr)-1] = '\0';
   gtk_text_insert (GTK_TEXT (logwdw), NULL, &fore, NULL, tempstr, -1);
   
   gtk_text_set_point (GTK_TEXT (logwdw), pos+strlen (tempstr));
   gtk_text_thaw (GTK_TEXT (logwdw));
   if (upd) {
      gtk_adjustment_set_value (GTK_TEXT (logwdw)->vadj, 
      		GTK_TEXT (logwdw)->vadj->upper - GTK_TEXT (logwdw)->vadj->page_size);
   }
   fix_display ();
}
/*****************************************************************************/
void update_ftp_info (struct ftp_window_data *wdata) {
   char *tempstr, *dir;
   
   dir = GFTP_GET_DIRECTORY (wdata->hdata->ftpdata);
   if (wdata->local == 1) {
      tempstr = g_strjoin (NULL, "Local [", strcmp (wdata->filespec, "*") == 0 ? "All Files" : wdata->filespec, "]", NULL);
      gtk_label_set (GTK_LABEL (wdata->hoststxt), tempstr);
      if (dir != NULL) gtk_entry_set_text (GTK_ENTRY (wdata->diredit), dir);
      else gtk_entry_set_text (GTK_ENTRY (wdata->diredit), "");
      g_free (tempstr);
   }
   else if (wdata->local == 0) {
      tempstr = g_strjoin (NULL, GFTP_GET_HOSTNAME (wdata->hdata->ftpdata), wdata->cached ? " (Cached) [" : " [", strcmp(wdata->filespec, "*") == 0 ? "All Files" : wdata->filespec, "]", NULL);
      gtk_label_set (GTK_LABEL(wdata->hoststxt), tempstr);
      if (dir != NULL) gtk_entry_set_text (GTK_ENTRY(wdata->diredit), dir);
      else gtk_entry_set_text (GTK_ENTRY (wdata->diredit), "");
      g_free (tempstr);
   }
   else {
      gtk_label_set (GTK_LABEL (wdata->hoststxt), "Not connected");
      gtk_entry_set_text (GTK_ENTRY (wdata->diredit), "");
   }
   fix_display ();
}
/*****************************************************************************/
void change_setting (struct ftp_window_data *wdata, int menuitem, GtkWidget *checkmenu) {
   switch (menuitem) {
      case 1 : if (wdata->hdata) gftp_set_data_type (wdata->hdata->ftpdata, gftp_type_ascii);
               break;
      case 2 : if (wdata->hdata) gftp_set_data_type (wdata->hdata->ftpdata, gftp_type_binary);
               break;
   }
}
/*****************************************************************************/
void selectrow (GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data) {
   struct ftp_window_data *wdata;
   struct ftp_file_data *tempfle;
   int i;
   
   wdata = (struct ftp_window_data *) data;
   i = 0;
   tempfle = wdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_SHOWN) {
         if (i == row) {
            if (!(tempfle->flags & FILE_SELECTED)) wdata->numselected++;
            tempfle->flags |= FILE_SELECTED;
            break;
         }
         i++;
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void unselectrow (GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data) {
   struct ftp_window_data *wdata;
   struct ftp_file_data *tempfle;
   int i;
   
   wdata = (struct ftp_window_data *) data;
   i = 0;
   tempfle = wdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_SHOWN) {
         if (i == row) {
            if (tempfle->flags & FILE_SELECTED) wdata->numselected--;
            tempfle->flags &= ~(FILE_SELECTED);
            break;
         }
         i++;
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void selectall (struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   int i = 0;
   
   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Select All: Not connected to a remote site\n");
      return;
   }
   tempfle = wdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_SHOWN) {
         if (strcmp (tempfle->file, "..") != 0) {
            gtk_clist_select_row (GTK_CLIST(wdata->listbox), i++, 0);
         }
         else {
            gtk_clist_unselect_row (GTK_CLIST(wdata->listbox), i++, 0);
         }
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void selectallfiles (struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   int i = 0;
   
   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Select All Files: Not connected to a remote site\n");
      return;
   }
   tempfle = wdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_SHOWN) {
         if (tempfle->flags & FILE_ISDIR)  {
            gtk_clist_unselect_row (GTK_CLIST (wdata->listbox), i++, 0);
         }
         else {
            gtk_clist_select_row (GTK_CLIST (wdata->listbox), i++, 0);
         }
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void deselectall (struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   int i = 0;
   
   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Deselect All: Not connected to a remote site\n");
      return;
   }
   tempfle = wdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_SHOWN) {
         gtk_clist_unselect_row (GTK_CLIST (wdata->listbox), i++, 0);
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void list_dblclick (GtkWidget *widget, GdkEventButton *event, gpointer data) {
   struct ftp_window_data *wdata;
   struct ftp_file_data *tempfle;
   int success;
   long flagcopy;
   
   wdata = (struct ftp_window_data *) data;
   if (wdata->local == -1 || wdata->numselected != 1) return;
   if (event->type == GDK_2BUTTON_PRESS) {
      if ((tempfle = get_next_selected_filename (wdata->hdata->files)) == NULL) {
         ftp_log (LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
         return;
      }
      flagcopy = tempfle->flags;
      success = 0;
      if ((!wdata->local && ((tempfle->flags & FILE_ISDIR) || (tempfle->flags & FILE_ISLINK))) ||
      		(wdata->local && tempfle->flags & FILE_ISDIR)) {
            success = chdirfunc (data);
      }
      if (!(flagcopy & FILE_ISDIR) && !success) view_dialog (data);
   }
}
/*****************************************************************************/
void list_enter (GtkWidget *widget, GdkEventKey *event, gpointer data) {
   struct ftp_window_data *wdata;
   struct ftp_file_data *tempfle;
   int success;
   
   wdata = (struct ftp_window_data *) data;
   if (wdata->local != -1 && wdata->numselected == 1 &&
   	event->type == GDK_KEY_PRESS && event->keyval == GDK_Return) {
      if ((tempfle = get_next_selected_filename (wdata->hdata->files)) == NULL) {
         ftp_log (LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
         return;
      }
      success = 0;
      if ((!wdata->local && ((tempfle->flags & FILE_ISDIR) || (tempfle->flags & FILE_ISLINK))) ||
      		(wdata->local && tempfle->flags & FILE_ISDIR)) {
            success = chdirfunc (data);
      }
      if (!(tempfle->flags & FILE_ISDIR) && !success) view_dialog (data);
   }
   else if (event->type == GDK_KEY_PRESS && (event->keyval == GDK_KP_Delete || event->keyval == GDK_Delete)) {
      delete_dialog (data);
   }
}
/*****************************************************************************/
void chfunc (struct ftp_window_data *wdata) {
   chdirfunc (wdata);
}
/*****************************************************************************/
int chdirfunc (struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   char *newdir, tempstr[MAXSTR];
   
   if (wdata->local == -1) {
      ftp_log(LOG_MISC, "Chdir: Not connected to a remote site\n");
      return(0);
   }
   else if (wdata->numselected != 1) {
      ftp_log(LOG_MISC, "Chdir: You must only have one item selected\n");
      return(0);
   }

   if ((tempfle = get_next_selected_filename (wdata->hdata->files)) == NULL) {
      ftp_log (LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
      return (0);
   }
   if (wdata->local == 0) {
      newdir = g_strjoin (NULL, GFTP_GET_DIRECTORY (wdata->hdata->ftpdata), "/", tempfle->file, NULL);
      remove_double_slashes (newdir);
      expand_path (newdir, tempstr, sizeof (tempstr));
      g_free (newdir);
      if (gftp_set_directory (wdata->hdata->ftpdata, tempstr) == 0) {
         update_ftp_info (wdata);
         gtk_clist_freeze (GTK_CLIST (wdata->listbox));
         delete_ftp_file_info (wdata);
         ftp_list_files (wdata, 1);
         gtk_clist_thaw (GTK_CLIST (wdata->listbox));
         return (1);
      }
      else return (0);
   }
   else if (wdata->local == 1) {
      if (chdir(tempfle->file) == 0) {
         ftp_log (LOG_MISC, "Successfully changed local directory to %s\n", tempfle->file);
         update_ftp_info (wdata);
         gtk_clist_freeze (GTK_CLIST (wdata->listbox));
         delete_ftp_file_info (wdata);
         add_local_files (wdata);
         gtk_clist_thaw (GTK_CLIST (wdata->listbox));
         return (1);
      }
      else {
         ftp_log (LOG_MISC, "Could not change %s directory to %s: %s\n", 
            wdata->local == 1 ? "local" : "remote", tempfle->file, g_strerror (errno));
      }
   }
   return (0);
}
/*****************************************************************************/
void chdiredit (GtkWidget *widget, struct ftp_window_data *wdata) {
   char tempstr[MAXSTR];
   
   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Chdir: Not connected to a remote site\n");
      return;
   }
   if (!expand_path(gtk_entry_get_text (GTK_ENTRY (wdata->diredit)), tempstr, sizeof (tempstr))) return;
   if (wdata->local == 0 && gftp_set_directory (wdata->hdata->ftpdata, tempstr) == 0) {
      update_ftp_info (wdata);
      gtk_clist_freeze (GTK_CLIST (wdata->listbox));
      delete_ftp_file_info (wdata);
      ftp_list_files (wdata, 1);
      gtk_clist_thaw (GTK_CLIST (wdata->listbox));
   }
   else if (wdata->local == 1) {
      if (chdir(tempstr) == 0) {
         ftp_log (LOG_MISC, "Successfully changed local directory to %s\n", tempstr);
         update_ftp_info (wdata);
         gtk_clist_freeze (GTK_CLIST (wdata->listbox));
         delete_ftp_file_info (wdata);
         add_local_files (wdata);
         gtk_clist_thaw (GTK_CLIST (wdata->listbox));
      }
      else {
         ftp_log (LOG_MISC, "Could not change %s directory to %s: %s\n", 
            wdata->local == 1 ? "local" : "remote", tempstr, g_strerror (errno));
      }
   }
}
/*****************************************************************************/
void refresh(struct ftp_window_data *wdata) {
   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Refresh: Not connected to a remote site\n");
      return;
   }
   gtk_clist_freeze (GTK_CLIST (wdata->listbox));
   delete_ftp_file_info (wdata);
   if (wdata->local == 0) ftp_list_files (wdata, 0);
   else add_local_files (wdata);
   gtk_clist_thaw (GTK_CLIST (wdata->listbox));
   update_ftp_info (wdata);
}
/*****************************************************************************/
void disconn (struct ftp_window_data *wdata) {
   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Disconnect: Not connected to a remote site\n");
      return;
   }
   disconnect (wdata);
}
/*****************************************************************************/
void fix_display (void) {
   while (gtk_events_pending ()) gtk_main_iteration ();
}
/*****************************************************************************/
gint update_downloads (gpointer data) {
   struct ftp_transfer_data *tdata, *prevtdata;
   char *add_data[3] = {NULL, NULL, NULL}, *pos;
   struct ftp_window_data *tempwdata;
   struct ftp_log_queue *templog;
   gint num, flag, i;
   char *tempstr;
   pthread_t tid;
   
   if (file_transfer_logs != NULL) {
      while (file_transfer_logs != NULL) {
         templog = file_transfer_logs;
         file_transfer_logs = file_transfer_logs->next;
         log (templog->type, NULL, templog->msg);
         free (templog);
      }
   }
   if (file_transfers == NULL) {
      gtk_timeout_add (1000, update_downloads, data);
      return (0);
   }
   else {
      tdata = prevtdata = file_transfers;
      num = 0;
      pthread_mutex_lock (&transfer_mutex);
      while (tdata != NULL) {
         if (tdata->flags & TRANSFER_ON_NEXT_FILE) {
            tdata->flags &= ~(TRANSFER_ON_NEXT_FILE);
            while (tdata->updfle != tdata->curfle) {
               if (tdata->updfle->flags & FILE_TRANS_DONE_VIEW) {
                  view_file (tdata->updfle->file, 1, 1, 1, tdata->updfle->remote_file);
               }
               else if (tdata->updfle->flags & FILE_TRANS_DONE_EDIT) {
                  view_file (tdata->updfle->file, 0, 1, 1, tdata->updfle->remote_file);
               }
               else if (tdata->updfle->flags & FILE_TRANS_DONE_RM) {
                  unlink (tdata->updfle->file);
               }
               tdata->updfle = tdata->updfle->next;
            }
            tempwdata = (tdata->flags & TRANSFER_DIRECTION) ? &window1 : &window2;
            if (refresh_files && ((tdata->flags & TRANSFER_DIRECTION) || compare_hdata_structs (tdata->hdata, tempwdata->hdata))) {
               refresh (tempwdata);
            }
         }
      
         if (tdata->flags & TRANSFER_SHOW) {
            i = 0;
            for (i=0; i<tdata->num_dirs_to_be_made; i++) {
               if (tdata->flags & TRANSFER_DIRECTION) {
                  mkdir (tdata->dirs_to_be_made[i], 488);
               }
               else {
                  gftp_make_directory (tdata->hdata->ftpdata, tdata->dirs_to_be_made[i]);
               }
               g_free (tdata->dirs_to_be_made[i]);
            }
            g_free (tdata->dirs_to_be_made);
            g_snprintf(tdata->progressstr, sizeof(tdata->progressstr), "Waiting... (%d file%s)", 
               tdata->hdata->totalfiles, tdata->hdata->totalfiles > 1 ? "s" : "");
            tdata->progressstr[sizeof(tdata->progressstr)-1] = '\0';
            gtk_clist_insert (GTK_CLIST(dlwdw), num, add_data);
            tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
            tdata->flags |= TRANSFER_UPDATE | TRANSFER_CREATED | TRANSFER_NEED_UPDATED;
            tdata->curfle = tdata->hdata->files;
            tdata->updfle = tdata->hdata->files;
         }
         else if (tdata->flags & TRANSFER_DONE) {
            tempwdata = (tdata->flags & TRANSFER_DIRECTION) ? &window1 : &window2;
            if ((tdata->flags & TRANSFER_DIRECTION) || compare_hdata_structs (tdata->hdata, tempwdata->hdata)) {
               refresh (tempwdata);
            }
            if (tdata->flags & TRANSFER_CREATED) {
               /* We have to release the mutex because when the list item gets
                  deleted, it will call my deselect function. This func will
                  also lock the mutex */
               pthread_mutex_unlock (&transfer_mutex);
               gtk_clist_remove (GTK_CLIST (dlwdw), num);
               pthread_mutex_lock (&transfer_mutex);
            }

            free_hdata (tdata->hdata);

            if (tdata == prevtdata) {
               flag = 1;
               file_transfers = file_transfers->next;
            }
            else {
               flag = 0;
               prevtdata->next = tdata->next;
            }
            if ((tdata->flags & TRANSFER_STARTED) && (do_one_transfer_at_a_time || file_transfers == NULL)) transfer_in_progress = 0;
            g_free (tdata);
            if (flag) tdata = prevtdata = file_transfers;
            else tdata = prevtdata->next;
            continue;
         }

         if ((tdata->curfle != NULL) && (tdata->flags & (TRANSFER_UPDATE | TRANSFER_NEED_UPDATED))) {
            if (!(tdata->flags & TRANSFER_STARTED) && start_file_transfers && (!do_one_transfer_at_a_time || (do_one_transfer_at_a_time && !transfer_in_progress))) {
               transfer_in_progress = 1;
               tdata->flags |= TRANSFER_STARTED;
               if (tdata->flags & TRANSFER_DIRECTION) pthread_create (&tid, NULL, &ftp_get_files, tdata);  
               else pthread_create (&tid, NULL, &ftp_put_files, tdata);
            }            

            pos = strrchr (tdata->curfle->file, '/');
            if (pos == NULL) pos = tdata->curfle->file;
            else pos++;
            gtk_clist_set_text (GTK_CLIST(dlwdw), num, 0, pos);

            gtk_clist_set_text (GTK_CLIST(dlwdw), num, 1, tdata->progressstr);

            tempstr = g_strjoin (NULL, GFTP_GET_HOSTNAME (tdata->hdata->ftpdata), GFTP_GET_DIRECTORY (tdata->hdata->ftpdata), NULL);
            gtk_clist_set_text (GTK_CLIST(dlwdw), num, 2, tempstr);
            g_free (tempstr);
            tdata->flags &= ~(TRANSFER_NEED_UPDATED);
         }
         num++;
         prevtdata = tdata;
         tdata = tdata->next;
      }
      pthread_mutex_unlock (&transfer_mutex);
   }
   gtk_timeout_add (1000, update_downloads, data);
   return (0);
}
/*****************************************************************************/
void selectdl (GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data) {
   struct ftp_transfer_data *tdata;
   int i;
   
   tdata = file_transfers;
   if (tdata == NULL) return;
   for (i=0; i<row; i++) {
      tdata = tdata->next;
      if (tdata == NULL) return;
   }
   pthread_mutex_lock (&transfer_mutex);
   tdata->flags |= TRANSFER_SELECTED;
   pthread_mutex_unlock (&transfer_mutex);
}
/*****************************************************************************/
void unselectdl (GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data) {
   struct ftp_transfer_data *tdata;
   int i;
   
   tdata = file_transfers;
   if (tdata == NULL) return;
   for (i=0; i<row; i++) {
      tdata = tdata->next;
      if (tdata == NULL) return;
   }
   pthread_mutex_lock (&transfer_mutex);
   tdata->flags &= ~(TRANSFER_SELECTED);
   pthread_mutex_unlock (&transfer_mutex);
}
/*****************************************************************************/
void stop_transfer (GtkWidget *widget, gpointer data) {
   struct ftp_transfer_data *temptdata;

   if (file_transfer_logs != NULL) {
      ftp_log (LOG_MISC, "There are currently no file transfers in progress to stop\n");
      return;
   }
   pthread_mutex_lock (&transfer_mutex);
   temptdata = file_transfers;
   while (temptdata != NULL) {
      if (temptdata->flags & TRANSFER_SELECTED) {
         temptdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
         temptdata->flags |= (temptdata->flags & TRANSFER_STARTED) ? TRANSFER_CANCEL : TRANSFER_DONE;
         ftp_log (LOG_MISC, "Stopping the transfer of %s\n", temptdata->curfle->file);
      }
      temptdata = temptdata->next;
   }
   pthread_mutex_unlock (&transfer_mutex);
}
/*****************************************************************************/
void compare_windows (gpointer data) {
   struct ftp_file_data *curfle, *tempfle;
   gint num;

   if (window2.local == -1) {
      ftp_log (LOG_MISC, "Compare Windows: Not connected to a remote site\n");
      return;
   }
   
   deselectall (&window1);
   deselectall (&window2);
   
   /* Select the items in Window1 that aren't in Window2 */
   curfle = window1.hdata->files;
   num = 0;
   while (curfle != NULL) {
      tempfle = window2.hdata->files;
      if (!(curfle->flags & FILE_ISDIR)) {
         while (tempfle != NULL) {
            if (strcmp (tempfle->file, curfle->file) == 0 && tempfle->size == curfle->size) {
               break;
            }
            tempfle = tempfle->next;
         }
      }
      if (tempfle == NULL) gtk_clist_select_row (GTK_CLIST(window1.listbox), num, 0);
      num++;
      curfle = curfle->next;
   }

   /* Select the items in Window2 that aren't in Window1 */
   curfle = window2.hdata->files;
   num = 0;
   while (curfle != NULL) {
      tempfle = window1.hdata->files;
      if (!(curfle->flags & FILE_ISDIR)) {
         while (tempfle != NULL) {
            if (strcmp (tempfle->file, curfle->file) == 0 && tempfle->size == curfle->size) {
               break;
            }
            tempfle = tempfle->next;
         }
      }
      if (tempfle == NULL) gtk_clist_select_row (GTK_CLIST(window2.listbox), num, 0);
      num++;
      curfle = curfle->next;
   }
}
/*****************************************************************************/
