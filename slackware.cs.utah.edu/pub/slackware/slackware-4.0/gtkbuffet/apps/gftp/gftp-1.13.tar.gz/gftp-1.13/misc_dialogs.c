/*****************************************************************************/
/*  misc_dialogs.c - various dialogs                                         */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

extern struct ftp_transfer_data *file_transfers;
extern int save_geometry, listbox_local_width, listbox_remote_width, 
	listbox_file_height, log_height, transfer_height;
extern GtkWidget *local_frame, *remote_frame, *log_table, *transfer_scroll,
	*logwdw;
static GdkPixmap *logo_pixmap;
static GdkBitmap *logo_mask;
static GtkWidget *edit, *conn_diag;
extern char version[];

static void dochange_filespec(GtkWidget *widget, struct ftp_window_data *wdata);
static void doexit(GtkWidget *widget, gpointer data);
static void do_reconnect(GtkWidget *widget, struct ftp_host_data *hdata);
static void dont_reconnect(GtkWidget *widget, struct ftp_host_data *hdata);
static void dosavelog(GtkWidget *widget, GtkFileSelection *fs);

void about_dialog (gpointer data) {
   const char no_license_agreement[] = "Cannot find the license agreement file COPYING. Please make sure it is in either " BASE_CONF_DIR " or in " SHARE_DIR;
   GtkWidget *tempwid, *dialog, *notebook, *box, *label, *view, *vscroll;
   char tempstr[MAXSTR];
   FILE *fd;
   
   dialog = gtk_dialog_new();
   gtk_window_set_title(GTK_WINDOW(dialog), "About gFTP");
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), 10);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->vbox), 5);
   gtk_box_set_homogeneous(GTK_BOX(GTK_DIALOG(dialog)->action_area), TRUE);
   gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
   gtk_signal_connect(GTK_OBJECT(dialog), "delete_event", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_signal_connect(GTK_OBJECT(dialog), "destroy", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_realize (dialog);
      
   notebook = gtk_notebook_new();
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), notebook, TRUE, TRUE, TRUE);
   gtk_widget_show(notebook);
   
   box = gtk_vbox_new(TRUE, 5);
   gtk_container_border_width(GTK_CONTAINER(box), 10);
   gtk_widget_show(box);
   
   open_xpm ("gftp-logo.xpm", dialog, &logo_pixmap, &logo_mask, 0);
   tempwid = gtk_pixmap_new(logo_pixmap, logo_mask);
   gtk_box_pack_start(GTK_BOX(box), tempwid, FALSE, FALSE, FALSE);
   gtk_widget_show(tempwid);

   g_snprintf (tempstr, sizeof (tempstr), "%s\nCopyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>\nOfficial Homepage: http://www.newwave.net/~masneyb\nLogo by: Aaron Worley <planet_hoth@yahoo.com>", version);
   tempstr[sizeof(tempstr)-1] = '\0';
   tempwid = gtk_label_new(tempstr);
   gtk_box_pack_start(GTK_BOX(box), tempwid, FALSE, FALSE, FALSE);
   gtk_widget_show(tempwid);

   label = gtk_label_new("About");
   gtk_widget_show(label);
   
   gtk_notebook_append_page(GTK_NOTEBOOK(notebook), box, label);

   box = gtk_vbox_new(FALSE, 5);
   gtk_container_border_width(GTK_CONTAINER(box), 10);
   gtk_widget_show(box);

   tempwid = gtk_table_new(1, 2, FALSE);
   gtk_box_pack_start(GTK_BOX(box), tempwid, TRUE, TRUE, TRUE);
   gtk_widget_show(tempwid);

   view = gtk_text_new(NULL, NULL);
   gtk_text_set_editable(GTK_TEXT(view), FALSE);
   gtk_text_set_word_wrap(GTK_TEXT(view), TRUE);
   gtk_table_attach(GTK_TABLE(tempwid), view, 0, 1, 0, 1,
   	GTK_FILL | GTK_EXPAND, GTK_FILL | GTK_EXPAND | GTK_SHRINK, 0, 0);
   gtk_widget_show(view);

   vscroll = gtk_vscrollbar_new(GTK_TEXT(view)->vadj);
   gtk_table_attach(GTK_TABLE(tempwid), vscroll, 1, 2, 0, 1,
   	GTK_FILL, GTK_EXPAND | GTK_FILL | GTK_SHRINK, 0, 0);
   gtk_widget_show(vscroll);

   label = gtk_label_new("License Agreement");
   gtk_widget_show(label);
   
   gtk_notebook_append_page(GTK_NOTEBOOK(notebook), box, label);

   tempwid = gtk_button_new_with_label("  Close  ");
   GTK_WIDGET_SET_FLAGS(tempwid, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), tempwid, FALSE, FALSE, FALSE);
   gtk_signal_connect(GTK_OBJECT(tempwid), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_grab_default(tempwid);
   gtk_widget_show(tempwid);

   expand_path(SHARE_DIR "/COPYING", tempstr, sizeof(tempstr));
   if(access(tempstr, F_OK) != 0) {
      expand_path(BASE_CONF_DIR "/COPYING", tempstr, sizeof(tempstr));
      if(access(tempstr, F_OK) != 0) {
         gtk_text_insert(GTK_TEXT(view), NULL, NULL, NULL, no_license_agreement, strlen(no_license_agreement));
         gtk_widget_show(dialog);
         return;
      }
   }
   if((fd = fopen(tempstr, "r")) == NULL) {
      gtk_text_insert(GTK_TEXT(view), NULL, NULL, NULL, no_license_agreement, strlen(no_license_agreement));
      gtk_widget_show(dialog);
      return;
   }
   memset(tempstr, 0, sizeof(tempstr));
   while(fread(tempstr, 1, sizeof(tempstr)-1, fd)) {
      gtk_text_insert(GTK_TEXT(view), NULL, NULL, NULL, tempstr, strlen(tempstr));
      memset(tempstr, 0, sizeof(tempstr));
   }
   fclose(fd);
   gtk_widget_show(dialog);
}         
/*****************************************************************************/
GtkWidget *MakeEditDialog(char *diagtxt, char *infotxt, 
	char *oktxt, void (*okfunc)(), void *okptr,
	char *canceltxt, void (*cancelfunc)(), void *cancelptr) {
   GtkWidget *text, *edit, *ok, *cancel, *dialog;
   
   dialog = gtk_dialog_new();
   gtk_grab_add(dialog);
   gtk_window_set_title(GTK_WINDOW(dialog), diagtxt);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), 10);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->vbox), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->action_area), 15);
   gtk_box_set_homogeneous(GTK_BOX(GTK_DIALOG(dialog)->action_area), TRUE);
   gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
   if(cancelfunc) {
      gtk_signal_connect(GTK_OBJECT(dialog), "delete_event", GTK_SIGNAL_FUNC(cancelfunc), (gpointer) cancelptr);
      gtk_signal_connect(GTK_OBJECT(dialog), "destroy", GTK_SIGNAL_FUNC(cancelfunc), (gpointer) cancelptr);
   }
   gtk_signal_connect(GTK_OBJECT(dialog), "delete_event", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_signal_connect(GTK_OBJECT(dialog), "destroy", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   
   text = gtk_label_new(infotxt);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), text, TRUE, TRUE, FALSE);
   gtk_widget_show(text);
   
   edit = gtk_entry_new_with_max_length(MAXSTR);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), edit, TRUE, TRUE, FALSE);
   if(okfunc) {
      gtk_signal_connect(GTK_OBJECT(edit), "activate", GTK_SIGNAL_FUNC(okfunc), (gpointer) okptr);
   }
   gtk_signal_connect(GTK_OBJECT(edit), "activate", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_show(edit);

   ok = gtk_button_new_with_label(oktxt);
   GTK_WIDGET_SET_FLAGS(ok, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), ok, TRUE, TRUE, FALSE);
   if(okfunc) {
      gtk_signal_connect(GTK_OBJECT(ok), "clicked", GTK_SIGNAL_FUNC(okfunc), (gpointer) okptr);
   }
   gtk_signal_connect(GTK_OBJECT(ok), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_grab_default(ok);
   gtk_widget_show(ok);
            
   cancel = gtk_button_new_with_label(canceltxt);
   GTK_WIDGET_SET_FLAGS(cancel, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), cancel, TRUE, TRUE, FALSE);
   gtk_signal_connect(GTK_OBJECT(cancel), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   if(cancelfunc) {
      gtk_signal_connect(GTK_OBJECT(cancel), "clicked", GTK_SIGNAL_FUNC(cancelfunc), (gpointer) cancelptr);
   }
   gtk_widget_show(cancel);

   gtk_widget_show(dialog);
   return(edit);
}         
/*****************************************************************************/
GtkWidget *MakeYesNoDialog(char *diagtxt, char *infotxt, int erase, int num, ...) {
   GtkWidget *text, *tempwid, *dialog;
   typedef void (*func)();
   func myfunc;
   va_list argp;
   char *tempstr;
   void *ptr;
   int i;
   
   dialog = gtk_dialog_new();
   gtk_grab_add(dialog);
   gtk_window_set_title(GTK_WINDOW(dialog), diagtxt);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), 10);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->vbox), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->action_area), 15);
   gtk_box_set_homogeneous(GTK_BOX(GTK_DIALOG(dialog)->action_area), TRUE);
   gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
   
   text = gtk_label_new(infotxt);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), text, TRUE, TRUE, FALSE);
   gtk_widget_show(text);

   va_start(argp, num);
   for(i=0; i<num; i++) {
      tempstr = va_arg(argp, char *);
      myfunc = va_arg(argp, func);
      ptr = va_arg(argp, void *);
      
      tempwid = gtk_button_new_with_label(tempstr);
      gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), tempwid, TRUE, TRUE, TRUE);
      if(myfunc) {
         gtk_signal_connect(GTK_OBJECT(tempwid), "clicked", GTK_SIGNAL_FUNC(myfunc), (gpointer) ptr);
      }
      if (erase) {
         gtk_signal_connect(GTK_OBJECT(tempwid), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
      }
      gtk_widget_show(tempwid);
   }
            
   gtk_widget_show(dialog);
   return(dialog);
}         
/*****************************************************************************/
void delete_modal_dialog(GtkWidget *widget, gpointer data) {
   gtk_widget_destroy((GtkWidget *) data);
}
/*****************************************************************************/
void change_filespec(struct ftp_window_data *wdata) {
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Change Filespec: Not connected to a remote site\n");
      return;
   }
   edit = MakeEditDialog("Change Filespec", "Enter the new file specification",
      "Change", dochange_filespec, wdata,
      "Cancel", NULL, NULL);
}
/*****************************************************************************/
static void dochange_filespec(GtkWidget *widget, struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   char *edttext;

   edttext = gtk_entry_get_text(GTK_ENTRY(edit));
   if(*edttext == '\0') {
     ftp_log(LOG_MISC, "Change Filespec: Operation canceled...you must enter a string\n");
     return;
   }
   strncpy(wdata->filespec, edttext, sizeof(wdata->filespec));
   wdata->filespec[sizeof(wdata->filespec)-1] = '\0';
   wdata->numselected = 0;

   gtk_clist_freeze(GTK_CLIST(wdata->listbox));
   gtk_clist_clear(GTK_CLIST(wdata->listbox));
   tempfle = wdata->hdata->files;
   while(tempfle != NULL) {
      add_file_listbox(wdata, tempfle);
      tempfle = tempfle->next;
   }
   gtk_clist_thaw(GTK_CLIST(wdata->listbox));
   update_ftp_info(wdata);
}
/*****************************************************************************/
void exitCB(gpointer data) {
   if(file_transfers == NULL) doexit(NULL, NULL);
   else {
      MakeYesNoDialog("Exit", "There are file transfers in progress.\nAre you sure you want to exit?", 1, 2,
      	"Exit", doexit, NULL,
      	"Don't Exit", NULL, NULL);
   }
}
/*****************************************************************************/
static void doexit(GtkWidget *widget, gpointer data) {
   if(save_geometry) {
      listbox_local_width = GTK_WIDGET (local_frame)->allocation.width;
      listbox_remote_width = GTK_WIDGET (remote_frame)->allocation.width;
      listbox_file_height = GTK_WIDGET (remote_frame)->allocation.height;
      log_height = GTK_WIDGET (log_table)->allocation.height;
      transfer_height = GTK_WIDGET (transfer_scroll)->allocation.height;
   }
   write_config_file ();
   clear_cache_files ();
   gtk_main_quit ();
}
/*****************************************************************************/
void reconnect_dialog (struct ftp_host_data *hdata) {
   char *tempstr;

   tempstr = g_strjoin (NULL, "Error: Could not connect to host ", GFTP_GET_HOSTNAME (hdata->ftpdata), ". What would you like to do?", NULL);
   conn_diag = MakeYesNoDialog ("Reconnect", tempstr, 0, 2,
   	"Retry Connection", do_reconnect, hdata,
   	"Cancel", dont_reconnect, hdata);
   g_free (tempstr);
}
/*****************************************************************************/
static void do_reconnect (GtkWidget *widget, struct ftp_host_data *hdata) {
   gtk_widget_destroy (conn_diag);
   conn_diag = NULL;
   ftp_connect (hdata);
}
/*****************************************************************************/
static void dont_reconnect (GtkWidget *widget, struct ftp_host_data *hdata) {
   gtk_widget_destroy (conn_diag);
   hdata->wait = 0;
}
/*****************************************************************************/
void viewlog(gpointer data) {
   char tempstr[MAXSTR], *txt;
   guint textlen;
   FILE *fd;

   make_temp_filename(tempstr, NULL, sizeof(tempstr));
   fd = fopen(tempstr, "w");
   if(fd == NULL) {
      ftp_log(LOG_MISC, "Error: Cannot open %s: %s\n", tempstr, g_strerror(errno));
      return;
   }
   textlen = gtk_text_get_length(GTK_TEXT(logwdw));
   txt = gtk_editable_get_chars(GTK_EDITABLE(logwdw), 0, -1);
   if(!fwrite(txt, 1, textlen, fd)) {
      ftp_log(LOG_MISC, "Error: Error writing to %s\n", tempstr);
   }
   fclose(fd);
   view_file(tempstr, 1, 1, 0, NULL);
}
/*****************************************************************************/
void savelog(gpointer data) {
   GtkWidget *filew;
   
   filew = gtk_file_selection_new ("Save Log");

   gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button), "clicked", GTK_SIGNAL_FUNC(dosavelog), filew);
   gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), filew);
   gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->cancel_button), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), filew);
   gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), "gftp.log");
   gtk_widget_show(filew);
}
/*****************************************************************************/
static void dosavelog(GtkWidget *widget, GtkFileSelection *fs) {
   char *filename, *txt;
   guint textlen;
   FILE *fd;

   filename = gtk_file_selection_get_filename(GTK_FILE_SELECTION (fs));
   fd = fopen(filename, "w");
   if(fd == NULL) {
      ftp_log(LOG_MISC, "Error: Cannot open %s: %s\n", filename, g_strerror(errno));
      return;
   }
   textlen = gtk_text_get_length(GTK_TEXT(logwdw));
   txt = gtk_editable_get_chars(GTK_EDITABLE(logwdw), 0, -1);
   if(!fwrite(txt, 1, textlen, fd)) {
      ftp_log(LOG_MISC, "Error: Error writing to %s\n", filename);
   }
   else {
      ftp_log(LOG_MISC, "Successfully wrote the log file to %s\n", filename);
   }
   fclose(fd);
   free(txt);
}
/*****************************************************************************/
void clearlog(gpointer data) {
   guint pos;
   
   pos = gtk_text_get_length(GTK_TEXT(logwdw));
   gtk_text_set_point(GTK_TEXT(logwdw), pos);
   gtk_text_backward_delete(GTK_TEXT(logwdw), pos);
}
/*****************************************************************************/
