/*****************************************************************************/
/*  mkdir_dialog.c - make directory dialog box and ftp routines              */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

static void domkdir (GtkWidget *widget, gpointer data);
static struct ftp_window_data *wdata;
static GtkWidget *edit;

void mkdir_dialog (gpointer data) {
   wdata = (struct ftp_window_data *) data;

   if (wdata->local == -1) {
      ftp_log (LOG_MISC, "Mkdir: Not connected to a remote site\n");
      return;
   }
   else if (wdata->hdata->protocol != ftp) {
      ftp_log (LOG_MISC, "Mkdir: You must be connected through the FTP protocol to make a directory\n");
      return;
   }

   edit = MakeEditDialog ("Make Directory", "Enter name of directory to create",
   	"Create", domkdir, edit,
   	"Cancel", NULL, NULL);
}
/*****************************************************************************/
static void domkdir(GtkWidget *widget, gpointer data) {
   char *edttext;
   int success;
   
   edttext = gtk_entry_get_text (GTK_ENTRY (edit));
   if (*edttext == '\0') {
     ftp_log (LOG_MISC, "Mkdir: Operation canceled...you must enter a string\n");
     return;
   }
   if (wdata->local == 1) {
      success = mkdir (edttext, 488) == 0;
      if (!success) {
         ftp_log (LOG_MISC, "Error: Could not make directory %s: %s\n", edttext, g_strerror (errno));
      }
      else {
         ftp_log (LOG_MISC, "Successfully made directory %s\n", edttext);
      }
   }
   else success = gftp_make_directory (wdata->hdata->ftpdata, edttext) == 0;
   if (success) refresh ((gpointer) wdata);
}
/*****************************************************************************/
