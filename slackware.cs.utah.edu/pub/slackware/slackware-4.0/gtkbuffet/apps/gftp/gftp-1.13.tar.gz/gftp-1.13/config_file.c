/*****************************************************************************/
/*  config_file.c - config file routines                                     */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

extern struct conn_categories *hostcat;
extern struct pix_ext *registered_exts;
extern char firewall_host[MAXSTR], firewall_username[MAXSTR], firewall_password[MAXSTR],
            view_program[MAXSTR], edit_program[MAXSTR], emailaddr[MAXSTR];
extern int use_cache, use_firewall, firewall_port, start_file_transfers, do_one_transfer_at_a_time,
           listbox_local_width, listbox_remote_width, listbox_file_height,
           transfer_height, log_height, save_geometry, passive_transfer,
           listbox_filename_width, sort_dirs_first, smart_remote_symlinks,
           use_default_dl_types, confirm_delete, refresh_files;
extern struct ftp_window_data window2;

struct config_vars {
   char key[30], /* Our config file variable name */
        description[35], /* How this field will show up in the options dialog */
        type; /* Type Character or Integer */
   void *var; /* Pointer to our variable */
   int len, /* Length of this field. Used only for char strings */
       general_option : 1; /* Will this go into the general settings tab */
   char comment[MAXSTR]; /* Comment to write out to the config file */
   GtkWidget *widget;
}; 

struct proxy_type_tag {
   char key[30];
   int show_host_port,
       show_user_pass;
};

static void proxy_toggle(GtkList *list, GtkWidget *child, gpointer data);
static void apply_changes (GtkWidget *widget, gpointer data);
static int proxy_num;

struct config_vars config_file_vars[] = {
/* You MUST keep the firewall stuff up here as the first entries and in the 
   same order. The options dialog relies on it being here */
   {"usefirewall", 		"Connect via FTP proxy", 	'I', &use_firewall, 		0, 			0, "# (*) Connect to the ftp server via a FTP Proxy.\n# 0 = Disable firewall support\n# 1 = Login firewall via SITE command\n# 2 = Login firewall via USER/PASS\n# 3 = Login via USER user@host:port", NULL},
   {"firewall_host", 		"Proxy hostname:", 		'C', firewall_host, 		sizeof(firewall_host), 	0, "# (*) Firewall hostname", NULL},
   {"firewall_port", 		"Proxy port:", 			'I', &firewall_port, 		10,			0, "# (*) Port to connect to on the firewall", NULL},
   {"firewall_username", 	"Proxy username:", 		'C', firewall_username,		sizeof(firewall_username), 0, "# (*) Your firewall username", NULL},
   {"firewall_password", 	"Proxy password:", 		'C', firewall_password, 	sizeof(firewall_password), 0, "# (*) Your firewall password", NULL},
   {"email", 			"Email address:", 		'C', emailaddr, 		sizeof(emailaddr), 	1, "# Enter your email address here", NULL},
   {"view_program", 		"View program:", 		'C', view_program, 		sizeof(view_program), 	1, "# The default program used to view files. If this is blank, the internal\n# file viewer will be used", NULL},
   {"edit_program", 		"Edit program:", 		'C', edit_program, 		sizeof(edit_program), 	1, "# The default program used to edit files.", NULL},
   {"confirm_delete",		"Confirm delete",		'I', &confirm_delete,		0,			1, "# Confirm when deleting files", NULL},
   {"one_transfer", 		"Do one transfer at a time",	'I', &do_one_transfer_at_a_time,0, 			1, "# Do only one transfer at a time?", NULL},
   {"passive_transfer",		"Passive file transfers", 	'I', &passive_transfer,		0, 			1, "# Send PASV command or PORT command for data transfers", NULL},
   {"refresh_files",		"Refresh after each file transfer",	'I', &refresh_files,		0,			1, "# Refresh the listbox after each file is transfered", NULL},
   {"save_geometry", 		"Save geometry", 		'I', &save_geometry, 		0, 			1, "# Save the size of each widget for next startup", NULL},
/*   {"smart_remote_symlinks", 	"Smart remote symlinks", 	'I', &smart_remote_symlinks, 	0, 			1, "# Set this if you want gFTP to try to resolve remote symlinks", NULL},*/
   {"sort_dirs_first", 		"Sort directories first", 	'I', &sort_dirs_first, 		0, 			1, "# Put the directories first then the files", NULL},
   {"start_transfers",		"Start file transfers", 	'I', &start_file_transfers, 	0, 			1, "# Automatically start the file transfers when they get queued?", NULL},
   {"usecache", 		"Use cache", 			'I', &use_cache, 		0, 			1, "# Do you want to use the cache?", NULL},
/*   {"view_log_on_login_fail", 	"View log after login fail",	'I', &view_log_after_login_fail,0, 			1, "# Will view the session log after a login failure", NULL},*/
/*   {"idle_seconds", 		"Anti-idle timeout", 		'I', &idle_seconds, 		10, 			1, "# (*) How many seconds to wait before sending a NOOP command to keep the connection alive", NULL},*/
   {"use_default_dl_types", 	"", 				'I', &use_default_dl_types, 	0, 			0, "# (*) If this is set, and there is a ext= line below for the file extension,\n# it will download the file as specified below", NULL},
   {"listbox_local_width",	"", 				'I', &listbox_local_width, 	0, 			0, "# The default width of the local files listbox", NULL},
   {"listbox_remote_width", 	"", 				'I', &listbox_remote_width, 	0, 			0, "# The default width of the remote files listbox", NULL},
   {"listbox_file_height", 	"", 				'I', &listbox_file_height, 	0, 			0, "# The default height of the local/remote files listboxes", NULL},
   {"transfer_height", 		"", 				'I', &transfer_height, 		0, 			0, "# The default height of the transfer listbox", NULL},
   {"log_height", 		"", 				'I', &log_height, 		0, 			0, "# The default height of the logging window", NULL},
   {"filename_width", 		"", 				'I', &listbox_filename_width, 	0, 			0, "# (*) The width of the filename column in the file listboxes", NULL},
   {"", "", 0, NULL}};

struct proxy_type_tag proxy_type[] = {
   {"none", 		0, 0},
   {"SITE command", 	1, 1},
   {"user@host", 	1, 1},
   {"user@host:port",	1, 0},
   {"AUTHENTICATE",	1, 1},
   {"HTTP Proxy",	1, 0},
   {"", 0, 0}};

void options_dialog(gpointer data) {
   GtkWidget *tempwid, *dialog, *notebook, *box, *intbox, *chartbl, *table, *label;
   GList *proxy_list;
   char tempstr[30];
   int num, tbl_len;

   proxy_list = NULL;   
   dialog = gtk_dialog_new();
   gtk_window_set_title(GTK_WINDOW(dialog), "Options");
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), 10);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->vbox), 5);
   gtk_box_set_homogeneous(GTK_BOX(GTK_DIALOG(dialog)->action_area), TRUE);
   gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
   gtk_signal_connect(GTK_OBJECT(dialog), "delete_event", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_signal_connect(GTK_OBJECT(dialog), "destroy", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   
   notebook = gtk_notebook_new();
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), notebook, TRUE, TRUE, TRUE);
   gtk_widget_show(notebook);
   
   box = gtk_vbox_new(FALSE, 0);
   gtk_container_border_width(GTK_CONTAINER(box), 10);
   gtk_widget_show(box);

   tempwid = gtk_label_new("General");
   gtk_widget_show(tempwid);
   gtk_notebook_append_page(GTK_NOTEBOOK(notebook), box, tempwid);   

   tbl_len = 1;
   chartbl = gtk_table_new(tbl_len, 2, FALSE);
   gtk_table_set_row_spacings(GTK_TABLE(chartbl), 5);
   gtk_table_set_col_spacings(GTK_TABLE(chartbl), 5);
   gtk_box_pack_start(GTK_BOX(box), chartbl, FALSE, FALSE, FALSE);
   gtk_widget_show(chartbl);
   
   intbox = gtk_vbox_new(FALSE, 0);
   gtk_box_pack_start(GTK_BOX(box), intbox, TRUE, TRUE, TRUE);
   gtk_widget_show(intbox);

   num = 0;
   while(config_file_vars[num].var != NULL) {
      if(config_file_vars[num].general_option) {
         if(config_file_vars[num].type == 'I' && config_file_vars[num].len == 0) {
            tempwid = gtk_check_button_new_with_label(config_file_vars[num].description);
            gtk_box_pack_start(GTK_BOX(intbox), tempwid, FALSE, FALSE, FALSE);
            gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (tempwid), *(int *) config_file_vars[num].var);
            gtk_widget_show(tempwid);
            config_file_vars[num].widget = tempwid;
         }
         else {
            tbl_len++;
            gtk_table_resize (GTK_TABLE (chartbl), tbl_len, 2);
            
            tempwid = gtk_label_new(config_file_vars[num].description);
            gtk_misc_set_alignment(GTK_MISC(tempwid), 1, 0.5);
            gtk_table_attach_defaults(GTK_TABLE(chartbl), tempwid, 0, 1, tbl_len-1, tbl_len);
            gtk_widget_show(tempwid);

            tempwid = gtk_entry_new_with_max_length(config_file_vars[num].len);
            gtk_table_attach_defaults(GTK_TABLE(chartbl), tempwid, 1, 2, tbl_len-1, tbl_len);
            if (config_file_vars[num].type == 'I') {
               g_snprintf (tempstr, sizeof (tempstr), "%d", *(int *) config_file_vars[num].var);
               gtk_entry_set_text (GTK_ENTRY (tempwid), tempstr);
            }
            else {
               gtk_entry_set_text (GTK_ENTRY (tempwid), config_file_vars[num].var);
            }
            gtk_widget_show(tempwid);
            config_file_vars[num].widget = tempwid;
         }
      }
      num++;
   }

   box = gtk_vbox_new(FALSE, 5);
   gtk_container_border_width(GTK_CONTAINER(box), 10);
   gtk_widget_show(box);

   tempwid = gtk_label_new("Proxy Server");
   gtk_widget_show(tempwid);
   gtk_notebook_append_page(GTK_NOTEBOOK(notebook), box, tempwid);   

   table = gtk_table_new(5, 2, FALSE);
   gtk_table_set_row_spacings(GTK_TABLE(table), 5);
   gtk_table_set_col_spacings(GTK_TABLE(table), 5);
   gtk_box_pack_start(GTK_BOX(box), table, FALSE, FALSE, FALSE);
   gtk_widget_show(table);

   tempwid = gtk_label_new("Proxy server type");
   gtk_misc_set_alignment(GTK_MISC(tempwid), 1, 0.5);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 0, 1, 0, 1);
   gtk_widget_show(tempwid);

   tempwid = gtk_label_new(config_file_vars[1].description);
   gtk_misc_set_alignment(GTK_MISC(tempwid), 1, 0.5);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 0, 1, 1, 2);
   gtk_widget_show(tempwid);

   tempwid = gtk_entry_new_with_max_length(config_file_vars[1].len);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 1, 2, 1, 2);
   gtk_entry_set_text (GTK_ENTRY (tempwid), config_file_vars[1].var);
   gtk_widget_show(tempwid);
   config_file_vars[1].widget = tempwid;

   tempwid = gtk_label_new(config_file_vars[2].description);
   gtk_misc_set_alignment(GTK_MISC(tempwid), 1, 0.5);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 0, 1, 2, 3);
   gtk_widget_show(tempwid);

   tempwid = gtk_entry_new_with_max_length(config_file_vars[2].len);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 1, 2, 2, 3);
   g_snprintf (tempstr, sizeof (tempstr), "%d", *(int *) config_file_vars[2].var);
   gtk_entry_set_text (GTK_ENTRY (tempwid), tempstr);
   gtk_widget_show(tempwid);
   config_file_vars[2].widget = tempwid;

   tempwid = gtk_label_new(config_file_vars[3].description);
   gtk_misc_set_alignment(GTK_MISC(tempwid), 1, 0.5);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 0, 1, 3, 4);
   gtk_widget_show(tempwid);

   tempwid = gtk_entry_new_with_max_length(config_file_vars[3].len);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 1, 2, 3, 4);
   gtk_entry_set_text (GTK_ENTRY (tempwid), config_file_vars[3].var);
   gtk_widget_show(tempwid);
   config_file_vars[3].widget = tempwid;

   tempwid = gtk_label_new(config_file_vars[4].description);
   gtk_misc_set_alignment(GTK_MISC(tempwid), 1, 0.5);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 0, 1, 4, 5);
   gtk_widget_show(tempwid);

   tempwid = gtk_entry_new_with_max_length(config_file_vars[4].len);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 1, 2, 4, 5);
   gtk_entry_set_text (GTK_ENTRY (tempwid), config_file_vars[4].var);
   gtk_entry_set_visibility(GTK_ENTRY(tempwid), FALSE);
   gtk_widget_show(tempwid);
   config_file_vars[4].widget = tempwid;

   tempwid = gtk_combo_new();
   gtk_signal_connect(GTK_OBJECT(GTK_COMBO(tempwid)->list), "select_child", GTK_SIGNAL_FUNC(proxy_toggle), NULL);
   gtk_table_attach_defaults(GTK_TABLE(table), tempwid, 1, 2, 0, 1);
   gtk_widget_show(tempwid);
   config_file_vars[0].widget = tempwid;

   num = 0;
   while (*proxy_type[num].key != '\0') {
      label = gtk_list_item_new_with_label (proxy_type[num].key);
      gtk_widget_show (label);
      proxy_list = g_list_append(proxy_list, label);
      num++;
   }
   gtk_list_prepend_items(GTK_LIST(GTK_COMBO(tempwid)->list), proxy_list);
   proxy_num = *(int *) config_file_vars[0].var;
   gtk_list_select_item (GTK_LIST(GTK_COMBO(tempwid)->list), proxy_num);

   tempwid = gtk_button_new_with_label("  OK  ");
   GTK_WIDGET_SET_FLAGS(tempwid, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), tempwid, FALSE, FALSE, FALSE);
   gtk_signal_connect(GTK_OBJECT(tempwid), "clicked", GTK_SIGNAL_FUNC(apply_changes), (gpointer) NULL);
   gtk_signal_connect(GTK_OBJECT(tempwid), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_show(tempwid);

   tempwid = gtk_button_new_with_label("  Cancel  ");
   GTK_WIDGET_SET_FLAGS(tempwid, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), tempwid, FALSE, FALSE, FALSE);
   gtk_signal_connect(GTK_OBJECT(tempwid), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_show(tempwid);

   tempwid = gtk_button_new_with_label("  Apply  ");
   GTK_WIDGET_SET_FLAGS(tempwid, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), tempwid, FALSE, FALSE, FALSE);
   gtk_signal_connect(GTK_OBJECT(tempwid), "clicked", GTK_SIGNAL_FUNC(apply_changes), (gpointer) NULL);
   gtk_widget_grab_default(tempwid);
   gtk_widget_show(tempwid);

   gtk_widget_show(dialog);
}
/*****************************************************************************/
static void proxy_toggle(GtkList *list, GtkWidget *child, gpointer data) {
   gint pos;
   
   pos = gtk_list_child_position (list, child);
   proxy_num = pos;
   gtk_widget_set_sensitive (config_file_vars[1].widget, proxy_type[proxy_num].show_host_port);
   gtk_widget_set_sensitive (config_file_vars[2].widget, proxy_type[proxy_num].show_host_port);
   gtk_widget_set_sensitive (config_file_vars[3].widget, proxy_type[proxy_num].show_user_pass);
   gtk_widget_set_sensitive (config_file_vars[4].widget, proxy_type[proxy_num].show_user_pass);
}
/*****************************************************************************/
static void apply_changes (GtkWidget *widget, gpointer data) {
   char *tempstr;
   int num;
   
   *(int *) config_file_vars[0].var = proxy_num;
   num = 1;
   while (config_file_vars[num].var != NULL) {
      if (config_file_vars[num].widget != NULL) {
         if(config_file_vars[num].type == 'I' && config_file_vars[num].len == 0) {
            *(int *) config_file_vars[num].var = GTK_TOGGLE_BUTTON (config_file_vars[num].widget)->active;
         }
         else {
            tempstr = gtk_entry_get_text (GTK_ENTRY (config_file_vars[num].widget));
            if (config_file_vars[num].type == 'I') {
               *(int *) config_file_vars[num].var = strtol (tempstr, (char **) NULL, 10);
            }
            else {
               strncpy ((char *) config_file_vars[num].var, tempstr, config_file_vars[num].len);
               ((char *) config_file_vars[num].var)[config_file_vars[num].len-1] = '\0';
            }
         }
      }
      num++;
   }
   window2.hdata->ftpdata->proxy_type = use_firewall;
   gftp_set_proxy_hostname (window2.hdata->ftpdata, firewall_host);
   gftp_set_proxy_username (window2.hdata->ftpdata, firewall_username);
   gftp_set_proxy_password (window2.hdata->ftpdata, firewall_password);
   gftp_set_proxy_port (window2.hdata->ftpdata, firewall_port);
   write_config_file ();
}
/*****************************************************************************/
void read_config_file(void) {
   struct conn_categories *newcat, *tempcat, *prevcat;
   struct conn_hosts *newhost, *temphost, *prevhost;
   struct pix_ext *tempext;
   char tempstr[MAXSTR], temp1str[MAXSTR], category[MAXSTR], *curpos;
   FILE *conffile;
   int line=0, pos;
   
   hostcat = NULL;
   newhost = NULL;
   registered_exts = NULL;
   if(!expand_path(CONFIG_FILE, tempstr, sizeof(tempstr))) {
      printf("gFTP Error: Bad config file name %s\n", CONFIG_FILE);
      exit(0);
   }
   if(access(tempstr, F_OK) == -1) {
      expand_path(BASE_CONF_DIR, temp1str, sizeof(temp1str));
      if(access(temp1str, F_OK) == -1) {
         if(mkdir(temp1str, 488) != 0) {
            printf("gFTP Error: Could not make directory %s: %s\n", temp1str, g_strerror(errno));
            exit(-1);
         }
      }
      g_snprintf(temp1str, sizeof(temp1str), "%s/gftprc", SHARE_DIR);
      temp1str[sizeof(temp1str)-1] = '\0';
      if(access(temp1str, F_OK) == -1) {
         printf("gFTP Error: Cannot find master config file %s\n", temp1str);
         printf("Did you do a make install?\n");
         exit(-1);
      }
      copyfile(temp1str, tempstr);
      chmod(tempstr, S_IRUSR | S_IWUSR);
   }
   chmod(tempstr, S_IRUSR | S_IWUSR);
   conffile = fopen(tempstr, "r");
   if(conffile == NULL) {
      printf("gFTP Error: Cannot open config file %s: %s\n", CONFIG_FILE, g_strerror(errno));
      exit(0);
   }
   while(fgets(tempstr, sizeof(tempstr), conffile)) {
      if(tempstr[strlen(tempstr)-1] == '\n') {
         tempstr[strlen(tempstr)-1] = '\0';
         if(tempstr[strlen(tempstr)-2] == '\r') tempstr[strlen(tempstr)-2] = '\0';
      }
      line++;
      pos = 0;
      while(config_file_vars[pos].var != NULL) {
         if(strncmp(config_file_vars[pos].key, tempstr, strlen(config_file_vars[pos].key)) == 0) {
            curpos = tempstr + strlen(config_file_vars[pos].key) + 1;
            if(config_file_vars[pos].type == 'C') {
               strncpy(config_file_vars[pos].var, curpos, config_file_vars[pos].len);
               ((char *) config_file_vars[pos].var)[config_file_vars[pos].len-1] = '\0';
               break;
            }
            else {
               *(int *) config_file_vars[pos].var = strtol(curpos, (char **) NULL, 10);
               break;
            }
         }
         pos++;
      }
      if(strncmp(tempstr, "host=", 5) == 0) {
         newhost = g_malloc(sizeof(struct conn_hosts));
         curpos = tempstr+5;
         parse_args(curpos, 8, line,
            category, sizeof(category),
            newhost->hostdescr, sizeof(newhost->hostdescr),
            newhost->hostname, sizeof(newhost->hostname),
            newhost->port, sizeof(newhost->port),
            newhost->dir, sizeof(newhost->dir),
            newhost->user, sizeof(newhost->user),
            newhost->pass, sizeof(newhost->pass),
            newhost->firewall, sizeof(newhost->firewall));
         newhost->next = NULL;
         if(newhost->firewall[0] == '\0') newhost->firewall[0] = '1';
         if(newhost->user[0] == '\0') {
            strncpy(newhost->user, ANON_LOGIN, sizeof(newhost->user));
            newhost->user[sizeof(newhost->user)-1] = '\0';
            if(newhost->pass[0] == '\0') {
               strncpy(newhost->pass, "@EMAIL@", sizeof(newhost->pass));
               newhost->pass[sizeof(newhost->pass)-1] = '\0';
            }
         }
         if(strcmp(category, "") == 0 || strcmp(newhost->hostdescr, "") == 0) {
            printf("gFTP Error: Error in config file on line %d: You must specify a category and a host\ndescription.\n", line);
            exit(0);
         }
         tempcat = prevcat = hostcat;          
         while(tempcat != NULL) {
            if(strcmp(tempcat->name, category) == 0) {
               temphost = prevhost = tempcat->hosts;
               while(temphost != NULL) {
                  if(strcmp(temphost->hostdescr, newhost->hostdescr) > 0) {
                     newhost->next = temphost;
                     if(temphost == prevhost) tempcat->hosts = newhost;
                     else prevhost->next = newhost;
                     break;
                  }
                  else {
                     prevhost = temphost;
                     temphost = temphost->next;
                  }
               }
               if(temphost == NULL) {
                  prevhost->next = newhost;
                  newhost->next = NULL;
               }
               break;
            }
            else if(strcmp(tempcat->name, category) > 0) {
               newcat = g_malloc(sizeof(struct conn_categories));
               newcat->next = tempcat;
               if(prevcat == tempcat) hostcat = newcat;
               else prevcat->next = newcat;
               strncpy(newcat->name, category, sizeof(newcat->name));
               newcat->name[sizeof(newcat->name)-1] = '\0';
               newcat->hosts = newhost;
               break;
            }
            prevcat = tempcat;
            tempcat = tempcat->next;
         }
         if(tempcat == NULL) {
            newcat = g_malloc(sizeof(struct conn_categories));
            if(hostcat == NULL) {
               newcat->next = hostcat;
               hostcat = newcat;
            }
            else {
               newcat->next = prevcat->next;;
               prevcat->next = newcat;
            }
            strncpy(newcat->name, category, sizeof(newcat->name));
            newcat->name[sizeof(newcat->name)-1] = '\0';
            newcat->hosts = newhost;
         }
      }
      else if(strncmp(tempstr, "ext=", 4) == 0) {
         curpos = tempstr+4;
         tempext = g_malloc(sizeof(struct pix_ext));
         parse_args(curpos, 4, line, 
            tempext->ext, sizeof(tempext->ext),
            tempext->filename, sizeof(tempext->filename),
            tempext->ascii_binary, sizeof(tempext->ascii_binary),
            tempext->view_program, sizeof(tempext->view_program));
         g_snprintf(tempstr, sizeof(tempstr), "%s/%s", SHARE_DIR, tempext->filename);
         tempstr[sizeof(tempstr)-1] = '\0';
         if(!expand_path(tempstr, temp1str, sizeof(temp1str))) {
            printf("gFTP Error: Bad file name %s in config file on line %d\n", tempext->filename, line);
            exit(0);
         }
         if(*tempext->filename != '\0' && access(temp1str, F_OK) != 0) {
            g_snprintf(tempstr, sizeof(tempstr), "%s/%s", BASE_CONF_DIR, tempext->filename);
            tempstr[sizeof(tempstr)-1] = '\0';
            if(!expand_path(tempstr, temp1str, sizeof(temp1str))) {
               printf("gFTP Error: Bad file name %s in config file on line %d\n", tempext->filename, line);
               exit(0);
            }
            if(access(temp1str, F_OK) != 0) {
               printf("gFTP Error: Error on line %d: %s doesn't exist in %s or %s\n", line, tempext->filename, SHARE_DIR, BASE_CONF_DIR);
               exit(0);
            }
         }
         tempext->stlen = strlen(tempext->ext);
         tempext->next = registered_exts;
         registered_exts = tempext;
      }         
      else if(config_file_vars[pos].var == NULL && *tempstr != '#' && *tempstr != '\0') {
         printf("gFTP Warning: Skipping line %d in config file: %s\n", line, tempstr);
      }
   }
   return;
}
/*****************************************************************************/
void write_config_file(void) {
   struct conn_categories *tempcat;
   struct conn_hosts *temphost;
   struct pix_ext *tempext;
   char tempstr[MAXSTR];
   FILE *conffile;
   int pos;

   if(!expand_path(CONFIG_FILE, tempstr, sizeof(tempstr))) {
      printf("gFTP Error: Bad config file name %s\n", CONFIG_FILE);
      exit(0);
   }
   conffile = fopen(tempstr, "w+");
   if(conffile == NULL) {
      printf("gFTP Error: Cannot open config file %s: %s\n", CONFIG_FILE, g_strerror(errno));
      exit(0);
   }
   
   g_snprintf(tempstr, sizeof(tempstr), "# Config file for gFTP\n# Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);
   g_snprintf(tempstr, sizeof(tempstr), "# Warning: Any comments that you add to this file WILL be overwritten\n# If a entry has a (*) in it's comment, you can't change it inside gFTP\n\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);

   pos = 0;
   while(config_file_vars[pos].var != NULL) {
      fwrite(config_file_vars[pos].comment, 1, strlen(config_file_vars[pos].comment), conffile);
      fwrite("\n", 1, 1, conffile);
      if(config_file_vars[pos].type == 'C') {
         g_snprintf(tempstr, sizeof(tempstr), "%s=%s\n", 
            config_file_vars[pos].key, (char *) config_file_vars[pos].var);
      }
      else {
         g_snprintf(tempstr, sizeof(tempstr), "%s=%d\n", 
            config_file_vars[pos].key, *(int *) config_file_vars[pos].var);
      }
      tempstr[sizeof(tempstr)-1] = '\0';
      fwrite(tempstr, 1, strlen(tempstr), conffile);
      fwrite("\n", 1, 1, conffile);
      pos++;
   }

   g_snprintf(tempstr, sizeof(tempstr), "# host=Category:Host Descr:hostname:port:start dir:username:password:firewall\n# If you set the password to @EMAIL@, gFTP will automatically change that to\n# your email address.\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);
   g_snprintf(tempstr, sizeof(tempstr), "# If you set the firewall argument to 1, gFTP will try to connect to your\n# FTP proxy if you have one. It is usually best to leave this set at 1 because\n# gFTP won't use it if you don't have a FTP proxy\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);
   tempcat = hostcat;
   while(tempcat != NULL) {
      temphost = tempcat->hosts;
      while(temphost != NULL) {
         g_snprintf(tempstr, sizeof(tempstr), "host=%s:%s:%s:%s:%s:%s:%s:%c\n", tempcat->name, 
            temphost->hostdescr, temphost->hostname, temphost->port, temphost->dir, 
            temphost->user, temphost->pass, temphost->firewall[0]);
         tempstr[sizeof(tempstr)-1] = '\0';
         fwrite(tempstr, 1, strlen(tempstr), conffile);
         temphost = temphost->next;
      }
      tempcat = tempcat->next;
   }
   
   g_snprintf(tempstr, sizeof(tempstr), "\n# ext=file extenstion:XPM file:Ascii or Binary (A or B):viewer program\n# Note: All arguments except the file extension are optional\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);
   tempext = registered_exts;
   while(tempext != NULL) {
      g_snprintf(tempstr, sizeof(tempstr), "ext=%s:%s:%c:%s\n", tempext->ext, tempext->filename, *tempext->ascii_binary == '\0' ? ' ' : *tempext->ascii_binary, tempext->view_program);
      tempstr[sizeof(tempstr)-1] = '\0';
      fwrite(tempstr, 1, strlen(tempstr), conffile);
      tempext = tempext->next;
   }
   fclose(conffile);
}
/*****************************************************************************/
int copyfile(char *source, char *dest) {
   FILE *srcfd, *destfd;
   char buf[8192];
   size_t n;
   
   srcfd = fopen(source, "rb");
   if(srcfd == NULL) {
      return(0);
   }
   
   destfd = fopen(dest, "wb");
   if(destfd == NULL) {
      fclose(srcfd);
      return(0);
   }
   
   while((n = fread(buf, 1, sizeof(buf), srcfd)) > 0) {
      fwrite(buf, 1, n, destfd);
   }
   fclose(srcfd);
   fclose(destfd);
   return(1);
}
/*****************************************************************************/
int parse_args(char *str, int numargs, int lineno, char *first, ...) {
   char *curpos, *endpos, *dest;
   va_list argp;
   size_t len, newlen;
   int ret = 1;
   
   va_start(argp, first);
   curpos = str;
   
   dest = first;
   len = va_arg(argp, size_t);
   memset(dest, 0, len);
   while(numargs > 1) {
      endpos = strchr(curpos, ':');
      if(endpos == NULL) {
         printf("gFTP Warning: Line %d doesn't have enough arguments\n", lineno);
         ret = 0;
         break;
      }
      newlen = endpos-curpos+1 > len ? len : endpos-curpos+1;
      strncpy(dest, curpos, newlen);
      dest[newlen-1] = '\0';
      curpos = endpos + 1;
      dest = va_arg(argp, char *);
      len = va_arg(argp, size_t);
      memset(dest, 0, len);
      numargs--;
   }
   newlen = strlen(curpos) > len ? len : strlen(curpos)+1;
   strncpy(dest, curpos, newlen);
   dest[newlen-1] = '\0';
   va_end(argp);
   while(numargs > 1) {
      dest = va_arg(argp, char *);
      len = va_arg(argp, size_t);
      memset(dest, 0, len);
      numargs--;
   }
   return(1);
}
/*****************************************************************************/
