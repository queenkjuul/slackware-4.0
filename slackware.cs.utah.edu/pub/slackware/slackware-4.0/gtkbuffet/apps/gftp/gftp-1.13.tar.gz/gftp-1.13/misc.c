/*****************************************************************************/
/*  misc.c - general purpose routines                                        */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

extern GdkPixmap *dotdot_pixmap, *dir_pixmap, *linkdir_pixmap, *linkfile_pixmap,
	*exe_pixmap, *doc_pixmap;
extern GdkBitmap *dotdot_mask, *dir_mask, *linkdir_mask, *linkfile_mask, 
	*exe_mask, *doc_mask;
extern char firewall_host[MAXSTR], firewall_username[MAXSTR], firewall_password[MAXSTR];
extern struct ftp_transfer_data *file_transfers;
extern pthread_mutex_t transfer_mutex;
extern struct ftp_window_data window1, window2;
extern struct pix_ext *registered_exts;
extern int use_default_dl_types, use_firewall, firewall_port;
extern char emailaddr[MAXSTR];

char *insert_commas (unsigned long number, char *dest, int size) {
   char *frompos, *topos, *src;
   int num, rem, i;
   
   src = g_malloc (size);
   g_snprintf (src, size, "%ld", number);
   src[size-1] = '\0';

   num = strlen (src) / 3 - 1;
   rem = strlen (src) % 3;
   if (strlen (src) + num + (rem == 0 ? 0 : 1) + 1 > size) {
      if (strlen (src) < size) strncpy (dest, src, size);
      else memset (dest, 'X', size-1);
      dest[size-1] = '\0';
      g_free (src);
      return (dest);
   }
   frompos = src;
   topos = dest;
   for (i=0; i<rem; i++) *topos++ = *frompos++;
   if (*frompos != '\0') {
      if (rem != 0) *topos++ = ',';
      while (num > 0) {
         for (i=0; i<3; i++) *topos++ = *frompos++;
         *topos++ = ',';
         num--;
      }
      for (i=0; i<3; i++) *topos++ = *frompos++;
   }
   *topos = '\0';
   g_free (src);
   return (dest);
}
/*****************************************************************************/
void add_local_files (struct ftp_window_data *wdata) {
   char tempstr[MAXSTR];

   wdata->local = 1;
   wdata->cached = 0;
   wdata->totalitems = wdata->numselected = 0;
   gftp_set_directory (wdata->hdata->ftpdata, getcwd (tempstr, sizeof (tempstr)));
   if ((wdata->hdata->files = get_local_files (NULL, &wdata->totalitems)) == NULL) {
      wdata->local = -1;
      wdata->totalitems = wdata->numselected = 0;
   }
   else sortrows (GTK_CLIST(wdata->listbox), wdata->sortcol, (gpointer) wdata);
   update_ftp_info (wdata);
}
/*****************************************************************************/
struct ftp_file_data *get_local_files (char *path, int *total) {
   struct ftp_file_data *files;
   char curdir[MAXSTR];
   FILE *dir;
   
   *total = 0;
   if (path != NULL) {
      if (getcwd (curdir, sizeof (curdir)) == NULL) return (NULL);
      if (chdir(path) == -1) return (NULL);
   }
   dir = popen ("/bin/ls -al", "r");
   files = parse_local_file (dir, 1, total, ftp);
   pclose (dir);
   if (path != NULL) chdir (curdir);
   return (files);
}
/*****************************************************************************/
struct ftp_file_data *parse_local_file (FILE *fd, int local, int *total, protocol_type proto) {
   struct ftp_file_data *files, *newfle, *lastfle;
   char tempstr[MAXSTR];
   int isdotdot = 0;
   struct stat st;
   gftp_file fle;

   lastfle = files = NULL;
   while (fgets (tempstr, sizeof (tempstr)-1, fd)) {
      if (tempstr[strlen(tempstr)-1] == '\n') tempstr[strlen(tempstr)-1] = '\0';
      if (tempstr[strlen(tempstr)-1] == '\r') tempstr[strlen(tempstr)-1] = '\0';

      if (proto == ftp ? gftp_parse_ls (tempstr, &fle) == 0 : parse_html_line (tempstr, &fle)) {
         if (strcmp (fle.file, ".") == 0) continue;
         if (strcmp(fle.file, "..") == 0) isdotdot = 1;

         newfle = g_malloc0 (sizeof (struct ftp_file_data));
         memcpy (newfle, &fle, sizeof (gftp_file));
         newfle->flags = 0;
         if (local) {
            stat (newfle->file, &st);
            if (S_ISDIR (st.st_mode)) newfle->flags |= FILE_ISDIR;
            if (newfle->attribs[0] == 'l') newfle->flags |= FILE_ISLINK;
            if ((strchr (newfle->attribs, 'x') != NULL) && !(newfle->flags & FILE_ISDIR)
            	&& !(newfle->flags & FILE_ISLINK)) newfle->flags |= FILE_ISEXE;
         }
         else {
            if (strchr (newfle->attribs, 'd') != NULL) newfle->flags |= FILE_ISDIR;
            if (strchr (newfle->attribs, 'l') != NULL) newfle->flags |= FILE_ISLINK;
            if ((strchr (newfle->attribs, 'x') != NULL) && !(newfle->flags & FILE_ISDIR)
            	&& !(newfle->flags & FILE_ISLINK)) newfle->flags |= FILE_ISEXE;
         }
         newfle->next = NULL;
         if (lastfle == NULL) files = newfle;
         else lastfle->next = newfle;
         lastfle = newfle;  
         (*total)++;
      }
   }
   if (!isdotdot) {
      newfle = g_malloc0 (sizeof (struct ftp_file_data));
      newfle->file = g_malloc (3);
      strcpy (newfle->file, "..");
      /* The other fields will all be 0 */
      
      newfle->next = NULL;
      newfle->flags = FILE_ISDIR;
      if (lastfle == NULL) files = newfle;
      else lastfle->next = newfle;
      (*total)++;
   }
   return (files);
}
/*****************************************************************************/
void add_file_listbox (struct ftp_window_data *wdata, struct ftp_file_data *fle) {
   char *add_data[7] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL};
   struct pix_ext *tempext;
   char tempstr[50];
   size_t stlen;
   gint num;

   if (match_filename_wildcard (fle->file, wdata->filespec)) {
      fle->flags |= FILE_SHOWN;
   }
   else {
      fle->flags &= ~(FILE_SHOWN | FILE_SELECTED);
      return;
   }
   stlen = strlen (fle->file);
   num = gtk_clist_append (GTK_CLIST (wdata->listbox), add_data);
   if (fle->flags & FILE_SELECTED) {
      gtk_clist_select_row (GTK_CLIST (wdata->listbox), num, 0);
      wdata->numselected++;
   }
   if (strcmp(fle->file, "..") == 0) {
      gtk_clist_set_pixmap (GTK_CLIST (wdata->listbox), num, 0, dotdot_pixmap, dotdot_mask);
   }
   else if ((fle->flags & FILE_ISLINK) && (fle->flags & FILE_ISDIR)) {
      gtk_clist_set_pixmap (GTK_CLIST (wdata->listbox), num, 0, linkdir_pixmap, linkdir_mask);
   }
   else if (fle->flags & FILE_ISLINK) {
      gtk_clist_set_pixmap (GTK_CLIST (wdata->listbox), num, 0, linkfile_pixmap, linkfile_mask);
   }
   else if (fle->flags & FILE_ISDIR) {
      gtk_clist_set_pixmap (GTK_CLIST (wdata->listbox), num, 0, dir_pixmap, dir_mask);
   }
   else if (fle->flags & FILE_ISEXE) {
      gtk_clist_set_pixmap (GTK_CLIST (wdata->listbox), num, 0, exe_pixmap, exe_mask);
   }
   else {
      tempext = registered_exts;
      while (tempext != NULL) {
         if (stlen >= tempext->stlen &&
            strcmp (&fle->file[stlen-tempext->stlen], tempext->ext) == 0) {

            if (*tempext->filename != '\0') {
               gtk_clist_set_pixmap (GTK_CLIST (wdata->listbox), num, 0, tempext->pixmap, tempext->mask);
            }
            else if (toupper(*tempext->ascii_binary) == 'A') {
               fle->flags |= FILE_ASCII;
            }
            break;
         }
         tempext = tempext->next;
      }
      if (tempext == NULL) {
         gtk_clist_set_pixmap (GTK_CLIST (wdata->listbox), num, 0, doc_pixmap, doc_mask);
      }
   }
   gtk_clist_set_text (GTK_CLIST (wdata->listbox), num, 1, fle->file);

   if (fle->attribs && (*fle->attribs == 'b' || *fle->attribs == 'c')) {
      g_snprintf (tempstr, sizeof (tempstr), "%d, %d", (int) fle->size >> 16, (int) fle->size & 0xFF);
   }
   else {
      insert_commas (fle->size, tempstr, sizeof (tempstr));
   }
   tempstr[sizeof (tempstr) - 1] = '\0';
   gtk_clist_set_text (GTK_CLIST (wdata->listbox), num, 2, tempstr);

   if (fle->user) {
      gtk_clist_set_text (GTK_CLIST (wdata->listbox), num, 3, fle->user);
   }
   if (fle->group) {
      gtk_clist_set_text (GTK_CLIST (wdata->listbox), num, 4, fle->group);
   }

   gtk_clist_set_text (GTK_CLIST (wdata->listbox), num, 5, ctime (&fle->datetime));
   
   if (fle->attribs) {
      gtk_clist_set_text (GTK_CLIST (wdata->listbox), num, 6, fle->attribs);
   }
}
/*****************************************************************************/
long file_countlf (FILE *filefd, long endpos) {
   char tempstr[MAXSTR];
   long num = 0, curpos, mypos;
   size_t n;
   int i;
            
   curpos = ftell (filefd);
   fseek (filefd, 0, SEEK_SET);
   mypos = 0;
   while ((n=fread (tempstr, 1, sizeof (tempstr), filefd)) > 0) {
      for (i=0; i<n; i++) {
         if ((tempstr[i] == '\n') && (i > 0) && (tempstr[i-1] != '\r')
            && (endpos == 0 || mypos+i <= endpos)) ++num;
      }
      mypos += n;
   }
   fseek (filefd, curpos, SEEK_SET);
   return (num);
}
/*****************************************************************************/
char *alltrim (char *str) {
   char *pos, *newpos;
   int diff;

   pos = str + strlen (str);
   while (*pos == ' ') *pos-- = '\0';
   
   pos = str;
   diff = 0;
   while (*pos++ == ' ') diff++;

   pos = str + diff;
   newpos = str;
   while (*pos != '\0') *newpos++ = *pos++;
   *newpos = '\0';
   return (str);
}
/*****************************************************************************/
int expand_path (char *src, char *dest, size_t size) {
   char *prevpos, *pos, *endpos, tempchar, *newstr, *str;
   struct passwd *pw;
   size_t len;
   
   pw = NULL;
   if (strcmp(src, "~") == 0 || strncmp (src, "~/", 2) == 0) pw = getpwuid (geteuid ());
   else if (strncmp(src, "~", 1) == 0) {
      if ((pos = strchr (src, '/')) == NULL) {
         *dest = '\0';
         return (0);
      }
      tempchar = *pos;
      *pos = '\0';
      pw = getpwnam (src+1);
      *pos = tempchar;
   }
   
   newstr = g_malloc (size);
   memset (newstr, 0, size);
   len = size-1;
   str = g_malloc (strlen (src) + 1);
   strcpy (str, src);
   endpos = str;
   while ((pos = strchr (endpos, '/')) != NULL) {
      pos++;
      if ((endpos = strchr (pos, '/')) == NULL) endpos = strchr (pos, '\0');
      tempchar = *endpos;
      *endpos = '\0';
      if (strcmp (pos, "..") == 0) {
         *(pos-1) = '\0';
         if ((prevpos = strrchr (newstr, '/')) != NULL) *prevpos = '\0';
      }
      else if (strcmp (pos, ".") != 0) {
         len -= strlen (pos);
         if (len < 1) break;
         strncat (newstr, pos-1, len);
      }
      *endpos = tempchar;
      if (*endpos == '\0') break;
      endpos = pos+1;
   }
   g_free (str);
   if (*newstr == '\0') {
      *newstr = '/';
      *(newstr+1) = '\0';
   }
   
   if (pw != NULL) {
      if (pos == NULL) {
         strncpy (dest, pw->pw_dir, size);
      }
      else {
         g_snprintf (dest, size, "%s%s", pw->pw_dir, newstr);
      }
      dest[size-1] = '\0';
   }
   else {
      strncpy (dest, newstr, size);
      dest[size-1] = '\0';
   }

   g_free (newstr);   
   return (1);
}
/*****************************************************************************/
void remove_double_slashes (char *string) {
   char *newpos, *oldpos;
   
   oldpos = newpos = string;
   while (*oldpos != '\0') {
      *newpos++ = *oldpos++;
      if (*oldpos == '\0') break;
      while (*(newpos-1) == '/' && *(oldpos) == '/') oldpos++;
   }
   *newpos = '\0';
}
/*****************************************************************************/
char *make_temp_filename (char *destbuf, char *ext, int size) {
   char tempstr[MAXSTR];
   
   expand_path (BASE_CONF_DIR "/temp", tempstr, sizeof(tempstr));
   if (access (tempstr, F_OK) == -1) mkdir (tempstr, 0x1C0);

   srand (time (NULL));
   g_snprintf (destbuf, size, "%s/temp%ld%s", tempstr, 1+(long) (99999999.0*rand()/(RAND_MAX+1.0)), ext == NULL ? "" : ext);
   destbuf[size-1] = '\0';
   while (access (destbuf, F_OK) != -1) {
      g_snprintf (destbuf, size, "%s/temp%ld%s", tempstr, 1+(long) (99999999.0*rand()/(RAND_MAX+1.0)), ext == NULL ? "" : ext);
      destbuf[size-1] = '\0';
   }
   return (destbuf);
}
/*****************************************************************************/
void free_file_list (struct ftp_file_data *filelist) {
   struct ftp_file_data *tempfle;
   
   while (filelist != NULL) {
      tempfle = filelist;
      filelist = filelist->next;
      free_fdata (tempfle);
   }
}
/*****************************************************************************/
void free_fdata (struct ftp_file_data *fle) {
   if (fle->file) g_free (fle->file);
   if (fle->user) g_free (fle->user);
   if (fle->group) g_free (fle->group);
   if (fle->attribs) g_free (fle->attribs);
   g_free (fle);
}
/*****************************************************************************/
void free_hdata (struct ftp_host_data *hdata) {
   free_file_list (hdata->files);
   gftp_request_destroy (hdata->ftpdata);
   g_free (hdata);
}
/*****************************************************************************/
struct ftp_host_data *new_hdata (void) {
   struct ftp_host_data *hdata;
   
   hdata = g_malloc0 (sizeof (struct ftp_host_data));
   hdata->files = hdata->last = NULL;
   hdata->ftpdata = gftp_request_new ();
   gftp_set_username (hdata->ftpdata, ANON_LOGIN);
   gftp_set_password (hdata->ftpdata, emailaddr);
   gftp_set_proxy_hostname (hdata->ftpdata, firewall_host);
   gftp_set_proxy_username (hdata->ftpdata, firewall_username);
   gftp_set_proxy_password (hdata->ftpdata, firewall_password);
   gftp_set_proxy_port (hdata->ftpdata, firewall_port);
   gftp_set_data_type (hdata->ftpdata, gftp_type_binary);
   gftp_logging (hdata->ftpdata, 1, log, NULL);
   hdata->ftpdata->proxy_type = use_firewall;
   if (use_firewall == 5) hdata->protocol = http;
   else hdata->protocol = ftp; 
   return (hdata);
}
/*****************************************************************************/
struct ftp_transfer_data *new_tdata (void) {
   struct ftp_transfer_data *tdata;

   tdata = g_malloc0 (sizeof (struct ftp_transfer_data));
   tdata->hdata = new_hdata ();
   gftp_logging (tdata->hdata->ftpdata, 1, ft_log, NULL);
   tdata->flags = TRANSFER_NEW; /* Signal to make this listbox entry */
   tdata->curtrans = 0;
   tdata->starttime = time (NULL);
   tdata->dirs_to_be_made = g_malloc (sizeof (char *));;
   tdata->dirs_to_be_made = NULL;
   tdata->num_dirs_to_be_made = 0;
   return (tdata);
}
/*****************************************************************************/
void copy_hdata_struct (struct ftp_host_data *hdata, struct ftp_host_data *newhdata) {
   char *str;

   if ((str = GFTP_GET_HOSTNAME (hdata->ftpdata))) {
      gftp_set_hostname (newhdata->ftpdata, str);
   }
   if ((str = GFTP_GET_USERNAME (hdata->ftpdata))) {
      gftp_set_username (newhdata->ftpdata, str);
   }
   if ((str = GFTP_GET_PASSWORD (hdata->ftpdata))) {
      gftp_set_password (newhdata->ftpdata, str);
   }
   if ((str = GFTP_GET_DIRECTORY (hdata->ftpdata))) {
      gftp_set_directory (newhdata->ftpdata, str);
   }
   gftp_set_port (newhdata->ftpdata, GFTP_GET_PORT (hdata->ftpdata));
   if ((str = GFTP_GET_PROXY_HOSTNAME (hdata->ftpdata))) {
      gftp_set_proxy_hostname (newhdata->ftpdata, str);
   }
   if ((str = GFTP_GET_PROXY_USERNAME (hdata->ftpdata))) {
      gftp_set_proxy_username (newhdata->ftpdata, str);
   }
   if ((str = GFTP_GET_PROXY_PASSWORD (hdata->ftpdata))) {
      gftp_set_proxy_password (newhdata->ftpdata, str);
   }
   gftp_set_proxy_port (newhdata->ftpdata, GFTP_GET_PROXY_PORT (hdata->ftpdata));
   GFTP_SET_LOGGING (newhdata->ftpdata, GFTP_GET_LOGGING (hdata->ftpdata));
   gftp_set_data_type (newhdata->ftpdata, GFTP_GET_DATA_TYPE (hdata->ftpdata));
   newhdata->ftpdata->transfer_type = hdata->ftpdata->transfer_type;
   newhdata->ftpdata->logging_function = hdata->ftpdata->logging_function;
   newhdata->ftpdata->user_data = hdata->ftpdata->user_data;
   newhdata->protocol = hdata->protocol;
}
/*****************************************************************************/
void copy_fdata_struct (struct ftp_file_data *fle, struct ftp_file_data *newfle) {
   if (fle->file) {
      newfle->file = g_malloc (strlen (fle->file) + 1);
      strcpy (newfle->file, fle->file);
   }
   if (fle->remote_file) {
      newfle->remote_file = g_malloc (strlen (fle->remote_file) + 1);
      strcpy (newfle->remote_file, fle->remote_file);
   }
   if (fle->user) {
      newfle->user = g_malloc (strlen (fle->user) + 1);
      strcpy (newfle->user, fle->user);
   }
   if (fle->group) {
      newfle->group = g_malloc (strlen (fle->group) + 1);
      strcpy (newfle->group, fle->group);
   }
   if (fle->attribs) {
      newfle->attribs = g_malloc (strlen (fle->attribs) + 1);
      strcpy (newfle->attribs, fle->attribs);
   }
   newfle->datetime = fle->datetime;
   newfle->size = fle->size;
   newfle->remote_size = fle->remote_size;
   newfle->flags = fle->flags;
}
/*****************************************************************************/
void add_file_transfer (struct ftp_transfer_data *tdata) {
   struct ftp_transfer_data *temptdata;
   
   pthread_mutex_lock (&transfer_mutex);
   if (file_transfers == NULL) file_transfers = tdata;
   else {
      temptdata = file_transfers;
      while (temptdata->next != NULL) temptdata = temptdata->next;
      temptdata->next = tdata;
   }
   pthread_mutex_unlock (&transfer_mutex);
}
/*****************************************************************************/
struct ftp_transfer_data *transfer_one_file (char *local_file, char *remote_file, int dl_or_up) {
   struct ftp_transfer_data *newtdata;

   newtdata = new_tdata ();
   copy_hdata_struct (window2.hdata, newtdata->hdata);
   newtdata->hdata->files = g_malloc0 (sizeof (struct ftp_file_data));
   newtdata->hdata->files->remote_file = g_malloc (strlen (remote_file) + 1);
   strcpy (newtdata->hdata->files->remote_file, remote_file);
   newtdata->hdata->files->file = g_malloc (strlen (local_file) + 1);
   strcpy (newtdata->hdata->files->file, local_file);
   newtdata->hdata->files->next = NULL;
   newtdata->hdata->files->size = 0;
   newtdata->curfle = newtdata->hdata->files;
   newtdata->hdata->totalfiles = 1;
   newtdata->flags = TRANSFER_SHOW;
   if (dl_or_up) {
      /* We're downloading this file */
      newtdata->flags |= TRANSFER_DIRECTION;
      newtdata->hdata->wdata = &window2;
      newtdata->hdata->files->flags |= get_file_transfer_mode(remote_file);
   }
   else {
      /* We're uploading this file */
      newtdata->hdata->wdata = &window1;
      newtdata->hdata->files->flags |= get_file_transfer_mode(local_file);
   }
   return (newtdata);
}
/*****************************************************************************/
int compare_hdata_structs(struct ftp_host_data *hdata1, struct ftp_host_data *hdata2) {
   char *strarr[4][2];
   int i, ret;

   ret = 1;
   if(GFTP_GET_PORT (hdata1->ftpdata) == GFTP_GET_PORT (hdata2->ftpdata) &&
   	hdata1->protocol == hdata2->protocol) {
      strarr[0][0] = GFTP_GET_HOSTNAME (hdata1->ftpdata);
      strarr[0][1] = GFTP_GET_HOSTNAME (hdata2->ftpdata);
      strarr[1][0] = GFTP_GET_USERNAME (hdata1->ftpdata);
      strarr[1][1] = GFTP_GET_USERNAME (hdata2->ftpdata);
      strarr[2][0] = GFTP_GET_PASSWORD (hdata1->ftpdata);
      strarr[2][1] = GFTP_GET_PASSWORD (hdata2->ftpdata);
      strarr[3][0] = GFTP_GET_DIRECTORY (hdata1->ftpdata);
      strarr[3][1] = GFTP_GET_DIRECTORY (hdata2->ftpdata);
      for (i=0; i<4; i++) {
         if (strarr[i][0] && strarr[i][0] && strcmp (strarr[i][0], strarr[i][1]) != 0) {
            ret = 0;
            break;
         }
      }
   }
   else ret = 0;
   return (ret);
}
/*****************************************************************************/
int match_filename_wildcard (char *filename, char *wildcard) {
   char *filepos, *wcpos, *pos, *search_pos, oldchar;
   size_t len;
   
   filepos = filename;
   wcpos = wildcard;
   if (*filepos == '\0' || *wcpos == '\0') return (0);
   while (1) {
      if (*wcpos == '\0') return (1);
      else if (*filepos == '\0') return (0);
      else if (*wcpos == '?') {
         wcpos++;
         filepos++;
      }
      else if (*wcpos == '*' && *(wcpos+1) == '\0') return (1);
      else if (*wcpos == '*') {
         search_pos = pos = wcpos+1;
         while (*pos != '*' && *pos != '?' && *pos != '\0') pos++;
         oldchar = *pos;
         *pos = '\0';
         len = strlen (search_pos);
         filepos = strstr (filepos, search_pos);
         *pos = oldchar;
         if (filepos == NULL) return (0);
         wcpos += len + 1;
         filepos += len;
      }
      else if (*wcpos++ != *filepos++) return (0);
   }
}
/*****************************************************************************/
struct ftp_file_data *get_next_selected_filename (struct ftp_file_data *filelist) {
   struct ftp_file_data *tempfle;
   
   tempfle = filelist;
   while (tempfle != NULL) {
      if ((tempfle->flags & FILE_SHOWN) && (tempfle->flags & FILE_SELECTED)) {
         return (tempfle);
      }
      tempfle = tempfle->next;
   }
   return (NULL);
}
/*****************************************************************************/
int ftp_connect (struct ftp_host_data *hdata) {
   int success;
   
   if (hdata->protocol == ftp) {
      success = gftp_connect (hdata->ftpdata) == 0;
   }
   else success = 1;

   if (success && hdata->wdata->hdata == hdata) {
      ftp_list_files (hdata->wdata, 1);
      hdata->wait = 0;
   }
   else if (!success && hdata->wdata->hdata == hdata) { /* FIXME */
      hdata->wait = 1;
      reconnect_dialog (hdata);
   }

   while (hdata->wait) {
      while (gtk_events_pending ()) gtk_main_iteration ();
   }
   if (GFTP_CONNECTED (hdata->ftpdata)) success = 1;
   return (success);
}
/*****************************************************************************/
void disconnect (struct ftp_window_data *wdata) {
   gftp_disconnect (wdata->hdata->ftpdata);
   gftp_set_username (wdata->hdata->ftpdata, ANON_LOGIN);
   gftp_set_password (wdata->hdata->ftpdata, emailaddr);
   delete_ftp_file_info (wdata);
   wdata->local = -1;
   update_ftp_info (wdata);
}
/*****************************************************************************/
void open_xpm (char *filename, GtkWidget *parent, GdkPixmap **pixmap, GdkBitmap **mask, int quit_on_err) {
   char tempstr[MAXSTR], *temp1str;
   GtkStyle *style;

   style = gtk_widget_get_style (parent);
   temp1str = g_strjoin (NULL, SHARE_DIR, "/", filename, NULL);
   expand_path (temp1str, tempstr, sizeof (tempstr));
   if (access (tempstr, F_OK) != 0) {
      g_free (temp1str);
      temp1str = g_strjoin (NULL, BASE_CONF_DIR, "/", filename, NULL);
      expand_path (temp1str, tempstr, sizeof (tempstr));
      if (access (tempstr, F_OK) != 0) {
         if (!quit_on_err) return;
         printf ("gFTP Error: Cannot find file %s in %s or %s\n", filename, SHARE_DIR, BASE_CONF_DIR);
         exit (-1);
      }
   }
   *pixmap = gdk_pixmap_create_from_xpm (parent->window, mask, &style->bg[GTK_STATE_NORMAL], tempstr);
   if (*pixmap == NULL) {
      if (!quit_on_err) return;
      printf("gFTP Error: Error opening file %s\n", tempstr);
      exit (-1);
   }
   g_free (temp1str);
}
/*****************************************************************************/
unsigned long get_file_transfer_mode (char *filename) {
   struct pix_ext *tempext;
   unsigned long flags;
   int stlen;

   flags = 0;   
   stlen = strlen (filename);
   tempext = registered_exts;
   while (use_default_dl_types && tempext != NULL) {
      if (stlen >= tempext->stlen &&
      		strcmp (&filename[stlen-tempext->stlen], tempext->ext) == 0) {
         if (toupper (*tempext->ascii_binary == 'A')) flags = FILE_ASCII;
         else if (toupper (*tempext->ascii_binary != 'B')) {
            tempext = NULL;
            break;
         }
         break;
      }
      tempext = tempext->next;
   }
   if (tempext == NULL && GFTP_GET_DATA_TYPE (window2.hdata->ftpdata) == gftp_type_ascii) {
      flags = FILE_ASCII;
   }
   return (flags);
}
/*****************************************************************************/
