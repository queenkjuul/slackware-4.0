/*****************************************************************************/
/*  file_transfer.c - contains the ui and network routines for file transfer */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

struct recursive_transfer {
   struct ftp_transfer_data *tdata;
   char *path;
   char *dest;
};

extern struct ftp_transfer_data *file_transfers;
extern pthread_mutex_t transfer_mutex;
extern struct ftp_window_data window1, window2;
extern struct pix_ext *registered_exts;
extern int use_firewall, passive_transfer, use_default_dl_types;

static GtkWidget *dialog, *status;
static int skip_same_state;
static struct ftp_transfer_data *inittrans(int direction);
static void get_local_files_and_dirs(struct recursive_transfer *transdata);
static void asktrans(struct ftp_transfer_data *tdata);
static void trans_selectrow (GtkCList *clist, gint row, gint column, GdkEventButton *event, struct ftp_transfer_data *tdata);
static void trans_unselectrow (GtkCList *clist, gint row, gint column, GdkEventButton *event, struct ftp_transfer_data *tdata);
static void trans_selectall (GtkWidget *widget, struct ftp_transfer_data *tdata);
static void trans_unselectall (GtkWidget *widget, struct ftp_transfer_data *tdata);
static void overwrite (GtkWidget *widget, struct ftp_transfer_data *tdata);
static void resume (GtkWidget *widget, struct ftp_transfer_data *tdata);
static void skip (GtkWidget *widget, struct ftp_transfer_data *tdata);
static void ok(GtkWidget *widget, struct ftp_transfer_data *tdata);
static void cancel(GtkWidget *widget, struct ftp_transfer_data *tdata);
 
void retrCB (GtkWidget *widget, gpointer data) {
   struct ftp_transfer_data *tdata;
   
   if (window2.local == -1) {
      ftp_log (LOG_MISC, "Retrieve Files: Not connected to a remote site\n");
      return;
   }
   else if (window2.numselected == 0) {
      ftp_log (LOG_MISC, "Retrieve Files: You must have at least one item selected\n");
      return;
   }
   tdata = inittrans (1);
   dotrans (tdata);
}
/*****************************************************************************/
void retrmenu (gpointer data) {
   retrCB (NULL, data);
}
/*****************************************************************************/
void putCB (GtkWidget *widget, gpointer data) {
   struct ftp_transfer_data *tdata;
   
   if (window2.local == -1) {
      ftp_log (LOG_MISC, "Put Files: Not connected to a remote site\n");
      return;
   }
   else if (window1.numselected == 0) {
      ftp_log (LOG_MISC, "Put Files: You must have at least one item selected\n");
      return;
   }
   tdata = inittrans (0);
   dotrans (tdata);
}
/*****************************************************************************/
void putmenu (gpointer data) {
   putCB (NULL, data);
}
/*****************************************************************************/
static struct ftp_transfer_data *inittrans (int direction) {
   struct ftp_file_data *newfle, *tempfle;
   struct recursive_transfer transdata;
   struct ftp_transfer_data *tdata;
   char *tempstr, *temp1str;
   GtkWidget *tempwid, *vbox;
   
   skip_same_state = 0;
   dialog = NULL;
   pthread_mutex_lock (&transfer_mutex);
   tdata = new_tdata ();
   if (direction) tdata->flags |= TRANSFER_DIRECTION;
   copy_hdata_struct (window2.hdata, tdata->hdata);
   gftp_logging (tdata->hdata->ftpdata, 1, ft_log, NULL);
   tdata->hdata->wdata = direction ? &window2 : &window1;
   tdata->hdata->totalfiles = tdata->hdata->wdata->numselected;
   tdata->hdata->totaldirs = 0;
   tdata->hdata->last = NULL;
   if ((tempfle = get_next_selected_filename (tdata->hdata->wdata->hdata->files)) == NULL) {
      ftp_log (LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
      return (NULL);
   }
   while (tempfle != NULL) {
      if (strcmp (tempfle->file, "..") == 0) {
         ftp_log (LOG_MISC, "Transfer Files: Skipping the transfer of the .. directory\n");
         tempfle = get_next_selected_filename (tempfle->next);
         continue;
      }
      else if (tempfle->flags & FILE_ISDIR) {
         if (dialog == NULL) {
            dialog = gtk_window_new (GTK_WINDOW_DIALOG);
            gtk_grab_add (dialog);
            gtk_window_set_title (GTK_WINDOW (dialog), "Getting directory listings");
            gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_MOUSE);
            gtk_signal_connect (GTK_OBJECT (dialog), "delete_event", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
            gtk_signal_connect (GTK_OBJECT (dialog), "destroy", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
    
            vbox = gtk_vbox_new (FALSE, 5);
            gtk_container_border_width (GTK_CONTAINER (vbox), 10);
            gtk_container_add (GTK_CONTAINER (dialog), vbox);
            gtk_widget_show (vbox);

            tempwid = gtk_label_new ("Please wait while getting directory listings");
            gtk_box_pack_start (GTK_BOX (vbox), tempwid, TRUE, TRUE, FALSE);
            gtk_widget_show (tempwid);

            status = gtk_label_new ("");
            gtk_box_pack_start (GTK_BOX (vbox), status, TRUE, TRUE, FALSE);
            gtk_widget_show (status);
            gtk_widget_show (dialog);
            fix_display ();
         }

         if (direction) {
            tempstr = g_strjoin (NULL, GFTP_GET_DIRECTORY (window2.hdata->ftpdata), "/", tempfle->file, NULL);
            temp1str = g_strjoin (NULL, GFTP_GET_DIRECTORY (window1.hdata->ftpdata), "/", tempfle->file, NULL);
         }
         else {
            temp1str = g_strjoin (NULL, GFTP_GET_DIRECTORY (window2.hdata->ftpdata), "/", tempfle->file, NULL);
            tempstr = g_strjoin (NULL, GFTP_GET_DIRECTORY (window1.hdata->ftpdata), "/", tempfle->file);
         }
         transdata.tdata = tdata;
         transdata.path = tempstr;
         transdata.dest = temp1str;
         get_local_files_and_dirs(&transdata);
         tdata->hdata->totaldirs++;
         g_free (tempstr);
         g_free (temp1str);
      }
      else {
         newfle = g_malloc0 (sizeof (struct ftp_file_data));
         copy_fdata_struct (tempfle, newfle);

         if (newfle->file) g_free (newfle->file);
         if (newfle->remote_file) g_free (newfle->remote_file);
         newfle->file = g_strjoin (NULL, GFTP_GET_DIRECTORY (window1.hdata->ftpdata), "/", tempfle->file, NULL);
         newfle->remote_file = g_strjoin (NULL, GFTP_GET_DIRECTORY (window2.hdata->ftpdata), "/", tempfle->file, NULL);

         newfle->flags = get_file_transfer_mode (newfle->file);
         newfle->next = NULL;
         if (tdata->hdata->last == NULL) tdata->hdata->files = newfle;
         else tdata->hdata->last->next = newfle;
         tdata->hdata->last = newfle;
      }
      tempfle = get_next_selected_filename (tempfle->next);
   }
   tdata->curfle = tdata->prevfle = tdata->hdata->files;
   tdata->next = NULL;
   pthread_mutex_unlock (&transfer_mutex);
   add_file_transfer (tdata);

   if (dialog != NULL) delete_modal_dialog (NULL, dialog);
   return (tdata);
}
/*****************************************************************************/
static void get_local_files_and_dirs(struct recursive_transfer *transdata) {
   struct ftp_file_data *newfle, *tempfle;
   char *newpath, *newdest;
   int i;
   
   transdata->tdata->num_dirs_to_be_made++;
   transdata->tdata->dirs_to_be_made = g_realloc (transdata->tdata->dirs_to_be_made, transdata->tdata->num_dirs_to_be_made * sizeof(char *));
   transdata->tdata->dirs_to_be_made[transdata->tdata->num_dirs_to_be_made-1] = g_malloc (strlen (transdata->dest) + 1);
   strcpy (transdata->tdata->dirs_to_be_made[transdata->tdata->num_dirs_to_be_made-1], transdata->dest);
   if(transdata->tdata->flags & TRANSFER_DIRECTION) newfle = get_remote_files (transdata->tdata->hdata, transdata->path, &i, 1, 0, GTK_LABEL (status));
   else newfle = get_local_files (transdata->path, &i);

   tempfle = newfle;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_ISDIR && strcmp (tempfle->file, ".") != 0 && strcmp (tempfle->file, "..") != 0) {
         transdata->tdata->hdata->totaldirs++;
         newpath = g_strjoin (NULL, transdata->path, "/", tempfle->file, NULL);
         newdest = g_strjoin (NULL, transdata->dest, "/", tempfle->file, NULL);
         tempfle = tempfle->next;
         get_local_files_and_dirs (transdata);
         g_free (newpath);
         g_free (newdest);
      }
      else if (!(tempfle->flags & FILE_ISDIR)) {
         transdata->tdata->hdata->totalfiles++;
         newpath = g_strjoin (NULL, transdata->path, "/", tempfle->file, NULL);
         newdest = g_strjoin (NULL, transdata->dest, "/", tempfle->file, NULL);
         if (tempfle->file) g_free (tempfle->file);
         if (tempfle->remote_file) g_free (tempfle->remote_file);
         if (transdata->tdata->flags & TRANSFER_DIRECTION) {
            tempfle->file = newdest;
            tempfle->remote_file = newpath;
         }
         else {
            tempfle->file = newpath;
            tempfle->remote_file = newdest;
         }
         tempfle->flags = get_file_transfer_mode (tempfle->file);
         
         if (transdata->tdata->hdata->last == NULL) {
            transdata->tdata->hdata->files = tempfle;
            tempfle = tempfle->next;
            transdata->tdata->hdata->files->next = NULL;
            transdata->tdata->hdata->last = transdata->tdata->hdata->files;
         }
         else {
            transdata->tdata->hdata->last->next = tempfle;
            tempfle = tempfle->next;
            transdata->tdata->hdata->last = transdata->tdata->hdata->last->next;
            transdata->tdata->hdata->last->next = NULL;
         }
      }
      else tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void dotrans (struct ftp_transfer_data *tdata) {
   struct ftp_file_data *tempfle, *filelist;
   char *pos, origch, *filelist_dir;
   struct stat flestat;
   int total, same;
   
   same = 0;
   filelist = NULL;
   filelist_dir = NULL;
   pthread_mutex_lock (&transfer_mutex);
   while (tdata->curfle != NULL) {
      if (tdata->flags & TRANSFER_DIRECTION) {
         /* We are downloading these files */
         if (stat (tdata->curfle->file, &flestat) != -1) {
            tdata->curfle->remote_size = tdata->curfle->size;
            tdata->curfle->size = flestat.st_size;
            tdata->curfle->flags |= FILE_TRANS_EXISTS;
            same = 1;
         }
      }
      else {
         /* We are uploading these files */
         pos = strrchr (tdata->curfle->remote_file, '/');
         if (pos == NULL) pos = tdata->curfle->remote_file;
         origch = *pos;
         *pos = '\0';
         if (strcmp (tdata->curfle->remote_file, GFTP_GET_DIRECTORY (window2.hdata->ftpdata)) == 0) {
            tempfle = window2.hdata->files;
         }
         else {
            if (filelist == NULL || strcmp (tdata->curfle->remote_file, filelist_dir) != 0) {
               free_file_list (filelist);
               filelist_dir = tdata->curfle->remote_file;
               filelist = get_remote_files (tdata->hdata, filelist_dir, &total, 1, 0, 0);
            }
            tempfle = filelist;
         }
         *pos++ = origch;
         while (tempfle != NULL) {
            if (strcmp (tempfle->file, pos) == 0) {
               tdata->curfle->remote_size = tempfle->size;
               tdata->curfle->flags |= FILE_TRANS_EXISTS;
               same = 1;
            }
            tempfle = tempfle->next;
         }
      }
      tdata->prevfle = tdata->curfle;
      tdata->curfle = tdata->curfle->next;
   }
   free_file_list (filelist);
   if (same == 0) {
      tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
      tdata->flags |= TRANSFER_SHOW;
      pthread_mutex_unlock (&transfer_mutex);
   }
   else {
      pthread_mutex_unlock (&transfer_mutex);
      asktrans (tdata);
   }
}
/*****************************************************************************/
static void asktrans (struct ftp_transfer_data *tdata) {
   char *dltitles[4] = {"Filename", "Local Size", "Remote Size", "Action"};
   char *add_data[4] = {NULL, NULL, NULL, NULL};
   GtkWidget *tempwid, *scroll, *hbox;
   struct ftp_file_data *tempfle;
   char tempstr[20], *pos;
   size_t len;
   int i;

   dialog = gtk_dialog_new ();
   gtk_grab_add (dialog);
   gtk_window_set_title (GTK_WINDOW (dialog), (tdata->flags & TRANSFER_DIRECTION) ? "Download Files" : "Upload Files");
   gtk_container_border_width (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), 10);
   gtk_container_border_width (GTK_CONTAINER (GTK_DIALOG (dialog)->action_area), 5);
   gtk_box_set_spacing (GTK_BOX (GTK_DIALOG (dialog)->vbox), 5);
   gtk_box_set_spacing (GTK_BOX (GTK_DIALOG (dialog)->action_area), 35);
   gtk_box_set_homogeneous (GTK_BOX (GTK_DIALOG (dialog)->action_area), TRUE);
   gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_MOUSE);
               
   tempwid = gtk_label_new ("The following file(s) exist on both the local and remote computer\nPlease select what you would like to do");
   gtk_box_pack_start (GTK_BOX (GTK_DIALOG(dialog)->vbox), tempwid, FALSE, FALSE, FALSE);
   gtk_widget_show (tempwid);

   scroll = gtk_scrolled_window_new (NULL, NULL);
   gtk_widget_set_usize (scroll, 450, 200);
   gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scroll),
   	GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
   tdata->clist = gtk_clist_new_with_titles (4, dltitles);
   gtk_container_add (GTK_CONTAINER (scroll), tdata->clist);
   gtk_clist_set_selection_mode (GTK_CLIST (tdata->clist), GTK_SELECTION_EXTENDED);
   gtk_clist_set_column_width (GTK_CLIST (tdata->clist), 0, 100);
   gtk_clist_set_column_justification (GTK_CLIST (tdata->clist), 1, GTK_JUSTIFY_RIGHT);
   gtk_clist_set_column_width (GTK_CLIST (tdata->clist), 1, 85);
   gtk_clist_set_column_justification (GTK_CLIST (tdata->clist), 2, GTK_JUSTIFY_RIGHT);
   gtk_clist_set_column_width (GTK_CLIST (tdata->clist), 2, 85);
   gtk_clist_set_column_width (GTK_CLIST (tdata->clist), 3, 85);
   gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), scroll, TRUE, TRUE, TRUE);
   gtk_signal_connect (GTK_OBJECT (tdata->clist), "select_row", GTK_SIGNAL_FUNC (trans_selectrow), (gpointer) tdata);
   gtk_signal_connect (GTK_OBJECT (tdata->clist), "unselect_row", GTK_SIGNAL_FUNC (trans_unselectrow), (gpointer) tdata);
   gtk_widget_show (tdata->clist);
   gtk_widget_show (scroll);

   tempfle = tdata->hdata->files;
   while (tempfle != NULL) {
      tempfle->flags &= ~(FILE_SELECTED);
      if (tempfle->flags & FILE_TRANS_EXISTS) {
         pos = tempfle->remote_file;
         len = strlen (GFTP_GET_DIRECTORY (window2.hdata->ftpdata));
         if (strncmp (pos, GFTP_GET_DIRECTORY (window2.hdata->ftpdata), len) == 0) {
            pos = tempfle->remote_file + len + 1;
         }
         add_data[0] = pos;
         add_data[3] = "Overwrite";
         i = gtk_clist_append (GTK_CLIST (tdata->clist), add_data);
         
         insert_commas (tempfle->size, tempstr, sizeof (tempstr));
         gtk_clist_set_text (GTK_CLIST (tdata->clist), i, 1, tempstr);

         insert_commas (tempfle->remote_size, tempstr, sizeof (tempstr));
         gtk_clist_set_text (GTK_CLIST (tdata->clist), i, 2, tempstr);
      }
      tempfle = tempfle->next;
   }

   hbox = gtk_hbox_new (TRUE, 20);
   gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), hbox, TRUE, TRUE, TRUE);
   gtk_widget_show (hbox);

   tempwid = gtk_button_new_with_label ("Overwrite");
   gtk_box_pack_start (GTK_BOX (hbox), tempwid, TRUE, TRUE, FALSE);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (overwrite), (gpointer) tdata);
   gtk_widget_show (tempwid);

   tempwid = gtk_button_new_with_label ("Resume");
   gtk_box_pack_start (GTK_BOX (hbox), tempwid, TRUE, TRUE, FALSE);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (resume), (gpointer) tdata);
   gtk_widget_show (tempwid);

   tempwid = gtk_button_new_with_label ("Skip File");
   gtk_box_pack_start (GTK_BOX (hbox), tempwid, TRUE, TRUE, FALSE);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (skip), (gpointer) tdata);
   gtk_widget_show (tempwid);

   hbox = gtk_hbox_new (TRUE, 20);
   gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), hbox, TRUE, TRUE, TRUE);
   gtk_widget_show (hbox);

   tempwid = gtk_button_new_with_label ("Select All");
   gtk_box_pack_start (GTK_BOX (hbox), tempwid, TRUE, TRUE, FALSE);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (trans_selectall), (gpointer) tdata);
   gtk_widget_show (tempwid);

   tempwid = gtk_button_new_with_label ("Deselect All");
   gtk_box_pack_start (GTK_BOX (hbox), tempwid, TRUE, TRUE, FALSE);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (trans_unselectall), (gpointer) tdata);
   gtk_widget_show (tempwid);
   
   tempwid = gtk_button_new_with_label ("OK");
   GTK_WIDGET_SET_FLAGS (tempwid, GTK_CAN_DEFAULT);
   gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area), tempwid, TRUE, TRUE, FALSE);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (ok), (gpointer) tdata);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (delete_modal_dialog), (gpointer) dialog);
   gtk_widget_grab_default (tempwid);
   gtk_widget_show (tempwid);

   tempwid = gtk_button_new_with_label ("Cancel");
   GTK_WIDGET_SET_FLAGS (tempwid, GTK_CAN_DEFAULT);
   gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area), tempwid, TRUE, TRUE, FALSE);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (cancel), (gpointer) tdata);
   gtk_signal_connect (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (delete_modal_dialog), (gpointer) dialog);
   gtk_widget_show (tempwid);

   gtk_widget_show(dialog);
}
/*****************************************************************************/
static void trans_selectrow (GtkCList *clist, gint row, gint column, GdkEventButton *event, struct ftp_transfer_data *tdata) {
   struct ftp_file_data *tempfle;
   int i;
   
   i = 0;
   tempfle = tdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_TRANS_EXISTS) {
         if (i == row) {
            tempfle->flags |= FILE_SELECTED;
            break;
         }
         i++;
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
static void trans_unselectrow (GtkCList *clist, gint row, gint column, GdkEventButton *event, struct ftp_transfer_data *tdata) {
   struct ftp_file_data *tempfle;
   int i;
   
   i = 0;
   tempfle = tdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_TRANS_EXISTS) {
         if (i == row) {
            tempfle->flags &= ~(FILE_SELECTED);
            break;
         }
         i++;
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
static void trans_selectall (GtkWidget *widget, struct ftp_transfer_data *tdata) {
   struct ftp_file_data *tempfle;
   int i;
   
   i = 0;
   tempfle = tdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_TRANS_EXISTS) {
         gtk_clist_select_row (GTK_CLIST (tdata->clist), i++, 0);
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
static void trans_unselectall (GtkWidget *widget, struct ftp_transfer_data *tdata) {
   struct ftp_file_data *tempfle;
   int i;
   
   i = 0;
   tempfle = tdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_TRANS_EXISTS) {
         gtk_clist_unselect_row (GTK_CLIST (tdata->clist), i++, 0);
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
static void overwrite (GtkWidget *widget, struct ftp_transfer_data *tdata) {
   struct ftp_file_data *tempfle;
   int i;
   
   i = 0;
   tempfle = tdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_TRANS_EXISTS) {
         if (tempfle->flags & FILE_SELECTED) {
            tempfle->flags &= ~(FILE_RESTART | FILE_TRANS_SKIP);
            gtk_clist_set_text (GTK_CLIST (tdata->clist), i, 3, "Overwrite");
         }
         i++;
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
static void resume (GtkWidget *widget, struct ftp_transfer_data *tdata) {
   struct ftp_file_data *tempfle;
   int i;
   
   i = 0;
   tempfle = tdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_TRANS_EXISTS) {
         if (tempfle->flags & FILE_SELECTED) {
            tempfle->flags &= ~(FILE_TRANS_SKIP);
            tempfle->flags |= FILE_RESTART;
            gtk_clist_set_text (GTK_CLIST (tdata->clist), i, 3, "Resume");
         }
         i++;
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
static void skip (GtkWidget *widget, struct ftp_transfer_data *tdata) {
   struct ftp_file_data *tempfle;
   int i;
   
   i = 0;
   tempfle = tdata->hdata->files;
   while (tempfle != NULL) {
      if (tempfle->flags & FILE_TRANS_EXISTS) {
         if (tempfle->flags & FILE_SELECTED) {
            tempfle->flags &= ~(FILE_RESTART);
            tempfle->flags |= FILE_TRANS_SKIP;
            gtk_clist_set_text (GTK_CLIST (tdata->clist), i, 3, "Skip");
         }
         i++;
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
static void ok (GtkWidget *widget, struct ftp_transfer_data *tdata) {
   struct ftp_file_data *curfle, *lastfle;
   
   curfle = lastfle = tdata->hdata->files;
   pthread_mutex_lock (&transfer_mutex);
   while (curfle != NULL) {
      if (curfle->flags & FILE_TRANS_SKIP) {
         if (curfle == lastfle) {
            tdata->hdata->files = tdata->hdata->files->next;
            free_fdata (curfle);
            curfle = lastfle = tdata->hdata->files;
         }
         else {
            lastfle->next = curfle->next;
            free_fdata (curfle);
            curfle = lastfle->next;
         }
         tdata->hdata->totalfiles--;
      }
      else {
         lastfle = curfle;
         curfle = curfle->next;
      }
   }
   tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
   if (tdata->hdata->files == NULL) tdata->flags |= TRANSFER_DONE;
   else tdata->flags |= TRANSFER_SHOW;
   pthread_mutex_unlock (&transfer_mutex);
}
/*****************************************************************************/
static void cancel (GtkWidget *widget, struct ftp_transfer_data *tdata) {
   pthread_mutex_lock (&transfer_mutex);
   tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
   tdata->flags |= TRANSFER_DONE;
   pthread_mutex_unlock (&transfer_mutex);
}
/*****************************************************************************/
void *ftp_get_files(void *ptr) {
   char buf[8192], gotstr[100], ofstr[100], *pos, *tempstr;
   struct ftp_transfer_data *tdata;
   int i, j, dlmode, num;
   long startsize, size;
   FILE *writefd;
   time_t t;
   float kbs;
   ssize_t n;

   j = num = 0;
   tdata = (struct ftp_transfer_data *) ptr;
   pthread_detach (pthread_self ());
   GFTP_SET_LOGGING (tdata->hdata->ftpdata, 1);
   if (ftp_connect (tdata->hdata)) {
      while (!(tdata->flags & TRANSFER_CANCEL) && tdata->curfle != NULL) {
         GFTP_SET_LOGGING (tdata->hdata->ftpdata, 1);
         dlmode = FTP_BINARY;
         if (tdata->hdata->protocol == ftp) {
            if (tdata->curfle->flags & FILE_ASCII) {
               dlmode = FTP_ASCII;
               gftp_set_data_type (tdata->hdata->ftpdata, gftp_type_ascii);
            }
            else {
               dlmode = FTP_BINARY;
               gftp_set_data_type (tdata->hdata->ftpdata, gftp_type_binary);
            }
         }

         if ((writefd = fopen (tdata->curfle->file, tdata->curfle->flags & FILE_RESTART ? "a" : "w")) == NULL) {
            queue_log (LOG_MISC, "Cannot create %s: %s\n", tdata->curfle->file , g_strerror (errno));
            pthread_mutex_lock (&transfer_mutex);
            tdata->curfle->flags |= FILE_TRANS_DONE;
            tdata->flags |= TRANSFER_ON_NEXT_FILE;
            tdata->prevfle = tdata->curfle;
            tdata->curfle = tdata->curfle->next;
            pthread_mutex_unlock (&transfer_mutex);
            continue;
         }
         if (tdata->curfle->flags & FILE_RESTART) {
            startsize = tdata->curfle->size;
            if (dlmode == FTP_ASCII) {
               startsize += file_countlf (writefd, startsize);
            }
         }
         else startsize = 0;

         GFTP_SET_LOGGING (tdata->hdata->ftpdata, 1);
         if (tdata->hdata->protocol == ftp ?
         	gftp_get_file (tdata->hdata->ftpdata, tdata->curfle->remote_file, startsize) != 0 :
         	!http_get_file (tdata->hdata, tdata->curfle->remote_file)) {
            queue_log (LOG_MISC, "Cannot download file %s from %s\n", tdata->curfle->file , GFTP_GET_HOSTNAME (tdata->hdata->ftpdata));
            pthread_mutex_lock (&transfer_mutex);
            tdata->curfle->flags |= FILE_TRANS_DONE;
            tdata->flags |= TRANSFER_ON_NEXT_FILE;
            tdata->prevfle = tdata->curfle;
            tdata->curfle = tdata->curfle->next;
            pthread_mutex_unlock (&transfer_mutex);
            continue;
         }
         
         size = 0;
         if (tdata->hdata->protocol == ftp) {
            if ((pos = strchr (GFTP_GET_LAST_RESPONSE (tdata->hdata->ftpdata), '(')) != NULL) {
               size = strtol (pos+1, (char **) NULL, 10);
            }
         }
         else {
            tempstr = NULL;
            /* Remove proxy header */
            while ((n = read (GFTP_GET_DATA_FD (tdata->hdata->ftpdata), &buf, sizeof (buf)-1)) > 0) {
               if (tempstr == NULL) {
                  tempstr = g_malloc (strlen (buf) + 1);
                  strcpy (tempstr, buf);
               }
               else {
                  tempstr = g_realloc (tempstr, strlen (buf) + strlen (tempstr) + 1);
                  strcat (tempstr, buf);
               }
               if ((pos = strstr (buf, "Content-Length: ")) != NULL) {
                  size = strtol (pos+16, (char **) NULL, 10);
               }
               if ((pos = strstr (buf, "\r\n\r\n")) != NULL) {
                  printf ("Getting crlf crlf\n");
                  pos += 4;
                  fwrite (pos, 1, n - (pos - buf), writefd);
                  g_free (tempstr);
                  break;
               }
            }
         }         

         pthread_mutex_lock (&transfer_mutex);
         tdata->curfle->size = size;
         tdata->starttime = time (NULL);
         tdata->curtrans = 0;
         pthread_mutex_unlock (&transfer_mutex);
         insert_commas (tdata->curfle->size, ofstr, sizeof (ofstr));

         memset (buf, 0, sizeof (buf));
         while (!(tdata->flags & TRANSFER_CANCEL) && (n = read (GFTP_GET_DATA_FD (tdata->hdata->ftpdata), &buf, sizeof (buf)-1)) > 0) {
            pthread_mutex_lock (&transfer_mutex);
            tdata->curtrans += n;
            insert_commas (tdata->curfle->flags & FILE_RESTART ?
            	tdata->curtrans+startsize : tdata->curtrans, 
            	gotstr, sizeof (gotstr));

            if ((t = time (NULL)-tdata->starttime)) {
               kbs = ((float) tdata->curtrans / 1024) / (float) t;
            }
            else kbs = 0;
            
            g_snprintf (tdata->progressstr, sizeof (tdata->progressstr), 
            	"Recv %s of %s at %.2fkbs (%d of %d)", gotstr, ofstr, kbs, 
            	num, tdata->hdata->totalfiles);
            tdata->flags |= TRANSFER_NEED_UPDATED;
            pthread_mutex_unlock (&transfer_mutex);
            
            if(dlmode == FTP_ASCII) { 
               for(i=0, j=0; i<n; i++) if(buf[i] != '\r') buf[j++] = buf[i];
               buf[j] = '\0';
            }
            if (!fwrite (buf, 1, dlmode == FTP_ASCII ? j : n, writefd)) break;
         }   
         fclose (writefd);
         if (tdata->hdata->protocol == ftp) {
            if (gftp_end_transfer (tdata->hdata->ftpdata) != 0) {
               queue_log (LOG_MISC, "Could not download %s\n", tdata->curfle->remote_file);
            }
            else {
               queue_log (LOG_MISC, "Successfully downloaded %s\n", tdata->curfle->remote_file);
            }
         }
         else close (GFTP_GET_DATA_FD (tdata->hdata->ftpdata));
         pthread_mutex_lock (&transfer_mutex);
         tdata->curfle->flags |= FILE_TRANS_DONE;
         tdata->flags |= TRANSFER_ON_NEXT_FILE;
         tdata->prevfle = tdata->curfle;
         tdata->curfle = tdata->curfle->next;
         pthread_mutex_unlock (&transfer_mutex);
      }
      if (tdata->hdata->protocol == ftp) gftp_disconnect (tdata->hdata->ftpdata);
   }

   pthread_mutex_lock (&transfer_mutex);
   tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
   tdata->flags |= TRANSFER_DONE;
   pthread_mutex_unlock (&transfer_mutex);
   pthread_exit (NULL);
}
/*****************************************************************************/
void *ftp_put_files(void *ptr) {
   char *tempstr, buf[8192], gotstr[100], ofstr[100], *pos, *newbuf, ret;
   struct ftp_transfer_data *tdata;
   int i, j=0, num, dlmode;
   long startsize;
   FILE *readfd;
   time_t t;
   float kbs;
   ssize_t n, newsize;

   num = 0;
   tdata = (struct ftp_transfer_data *) ptr;
   pthread_detach(pthread_self());
   GFTP_SET_LOGGING (tdata->hdata->ftpdata, 0);
   if(ftp_connect(tdata->hdata)) {
      while (!(tdata->flags & TRANSFER_CANCEL) && tdata->curfle != NULL) {
         GFTP_SET_LOGGING (tdata->hdata->ftpdata, 1);
         dlmode = FTP_BINARY;
         if (tdata->hdata->protocol == ftp) {
            if (tdata->curfle->flags & FILE_ASCII) {
               dlmode = FTP_ASCII;
               gftp_set_data_type (tdata->hdata->ftpdata, gftp_type_ascii);
            }
            else {
               dlmode = FTP_BINARY;
               gftp_set_data_type (tdata->hdata->ftpdata, gftp_type_binary);
            }
         }

         if(!(readfd = fopen(tdata->curfle->file, "r"))) {
            queue_log(LOG_MISC, "Error: Cannot open local file %s: %s\n", tdata->curfle->file, g_strerror(errno));
            pthread_mutex_lock (&transfer_mutex);
            tdata->curfle->flags |= FILE_TRANS_DONE;
            tdata->flags |= TRANSFER_ON_NEXT_FILE;
            tdata->prevfle = tdata->curfle;
            tdata->curfle = tdata->curfle->next;
            pthread_mutex_unlock (&transfer_mutex);
            continue;
         }

         if(tdata->curfle->flags & FILE_RESTART) {
            tempstr = g_strjoin (NULL, "SIZE ", tdata->curfle->remote_file, "\r\n", NULL);
            ret = gftp_send_command(tdata->hdata->ftpdata, tempstr);
            g_free (tempstr);
            if (ret != '2') {
               queue_log(LOG_MISC, "Cannot get size of %s on %s\n", tdata->curfle->remote_file, GFTP_GET_HOSTNAME (tdata->hdata->ftpdata));
               pthread_mutex_lock (&transfer_mutex);
               tdata->curfle->flags |= FILE_TRANS_DONE;
               tdata->flags |= TRANSFER_ON_NEXT_FILE;
               tdata->prevfle = tdata->curfle;
               tdata->curfle = tdata->curfle->next;
               pthread_mutex_unlock (&transfer_mutex);
               continue;
            }

            pos = GFTP_GET_LAST_RESPONSE (tdata->hdata->ftpdata) + 4;
            startsize = strtol(pos, (char **) NULL, 10);
            if(dlmode == FTP_ASCII) {
               startsize += file_countlf(readfd, startsize);
            }
            fseek(readfd, startsize, SEEK_SET);
         }
         else startsize = 0;
         
         if (gftp_put_file (tdata->hdata->ftpdata, tdata->curfle->remote_file, startsize) != 0) {
            queue_log(LOG_MISC, "Cannot put file %s to %s\n", tdata->curfle->remote_file, GFTP_GET_HOSTNAME (tdata->hdata->ftpdata));
            pthread_mutex_lock (&transfer_mutex);
            tdata->curfle->flags |= FILE_TRANS_DONE;
            tdata->flags |= TRANSFER_ON_NEXT_FILE;
            tdata->prevfle = tdata->curfle;
            tdata->curfle = tdata->curfle->next;
            pthread_mutex_unlock (&transfer_mutex);
            continue;
         }

         pthread_mutex_lock(&transfer_mutex);
         tdata->starttime = time(NULL);
         tdata->curtrans = 0;
         pthread_mutex_unlock(&transfer_mutex);
         insert_commas(tdata->curfle->size, ofstr, sizeof(ofstr));

         memset (buf, 0, sizeof (buf));
         while(!(tdata->flags & TRANSFER_CANCEL) && (n = fread(&buf, 1, sizeof(buf)-1, readfd)) > 0) {
            pthread_mutex_lock(&transfer_mutex);
            tdata->curtrans += n;
            
            if(tdata->curfle->flags & FILE_RESTART) {
               insert_commas(startsize+tdata->curtrans, gotstr, sizeof(gotstr));
            }
            else {
               insert_commas(tdata->curtrans, gotstr, sizeof(gotstr));
            }
            
            if((t = time(NULL)-tdata->starttime)) {
               kbs = ((float) tdata->curtrans / 1024) / (float) t;
            }
            else kbs = 0;
            
            g_snprintf(tdata->progressstr, sizeof(tdata->progressstr), 
            	"Sent %s of %s at %.2fkbs (%d of %d)",
            	gotstr, ofstr, kbs, num, tdata->hdata->totalfiles);
            tdata->flags |= TRANSFER_NEED_UPDATED;
            pthread_mutex_unlock(&transfer_mutex);

            if(dlmode == FTP_ASCII) { 
               newsize = 1;
               for(i=0; i<n; i++) {
                  newsize++;
                  if(i > 0 && buf[i] == '\n' && buf[i-1] != '\r') newsize++;
               }
               newbuf = g_malloc(newsize);
               for(i=0,j=0; i<n; i++) {
                  if(i > 0 && buf[i] == '\n' && buf[i-1] != '\r') newbuf[j++] = '\r';
                  newbuf[j++] = buf[i];
               }
               newbuf[newsize-1] = '\0';
            }
            else {
               newbuf = buf;
               newsize = n;
            }

            if(!write(GFTP_GET_DATA_FD (tdata->hdata->ftpdata), newbuf, newsize)) {
               if(dlmode == FTP_ASCII) g_free(newbuf);
               queue_log(LOG_MISC, "Cannot write %s to %s\n", tdata->curfle->file, GFTP_GET_HOSTNAME (tdata->hdata->ftpdata));
               pthread_mutex_lock (&transfer_mutex);
               tdata->curfle->flags |= FILE_TRANS_DONE;
               tdata->flags |= TRANSFER_ON_NEXT_FILE;
               tdata->prevfle = tdata->curfle;
               tdata->curfle = tdata->curfle->next;
               pthread_mutex_unlock (&transfer_mutex);
               continue;
            }
            if(dlmode == FTP_ASCII) g_free(newbuf);
         }   
         fclose(readfd);
         if (gftp_end_transfer (tdata->hdata->ftpdata) != 0) {
            queue_log(LOG_MISC, "Could not upload %s to %s\n", tdata->curfle->remote_file, GFTP_GET_HOSTNAME (tdata->hdata->ftpdata));
         }
         else {
            queue_log(LOG_MISC, "Successfully uploaded %s to %s\n", tdata->curfle->remote_file, GFTP_GET_HOSTNAME (tdata->hdata->ftpdata));
         }
         pthread_mutex_lock(&transfer_mutex);
         tdata->curfle->flags |= FILE_TRANS_DONE;
         tdata->flags |= TRANSFER_ON_NEXT_FILE;
         tdata->prevfle = tdata->curfle;
         tdata->curfle = tdata->curfle->next;
         pthread_mutex_unlock(&transfer_mutex);
      }
      gftp_disconnect(tdata->hdata->ftpdata);
   }

   pthread_mutex_lock(&transfer_mutex);
   tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
   tdata->flags |= TRANSFER_DONE;
   pthread_mutex_unlock(&transfer_mutex);
   pthread_exit(NULL);
}
/*****************************************************************************/
