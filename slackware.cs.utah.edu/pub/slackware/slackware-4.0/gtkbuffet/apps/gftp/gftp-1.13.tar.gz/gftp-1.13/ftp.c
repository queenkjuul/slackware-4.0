/*****************************************************************************/
/*  ftp.c - contains most of the core network routines                       */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

extern char firewall_host[MAXSTR], firewall_username[MAXSTR], firewall_password[MAXSTR];
extern int use_cache, use_firewall, firewall_port, passive_transfer, smart_remote_symlinks;
extern pthread_mutex_t idle_mutex;

static gftp_readline_buffer readln_buffer;

int ftp_list_files (struct ftp_window_data *wdata, int load_from_cache) {
   wdata->totalitems = wdata->numselected = 0;
   wdata->local = 0;

   update_ftp_info (wdata);
   if ((wdata->hdata->files = get_remote_files (wdata->hdata, NULL, &wdata->totalitems, load_from_cache, 1, GTK_LABEL (wdata->hoststxt))) == NULL) {
      wdata->totalitems = wdata->numselected = 0;
      wdata->local = -1;
   }
   else sortrows (GTK_CLIST (wdata->listbox), wdata->sortcol, (gpointer) wdata);
   update_ftp_info (wdata);
   return (wdata->hdata->files != NULL);
}
/*****************************************************************************/
struct ftp_file_data *get_remote_files(struct ftp_host_data *hdata, char *path, int *total, int load_from_cache, int log, GtkLabel *up_wid) {
   char logstr[MAXSTR], description[MAXSTR], commastr[20], *curdir, *tempstr, *dir, nodir = '\0';
   struct ftp_file_data *files, *newfle, *lastfle;
   gftp_file fle;
   int isdotdot, got;
   size_t dltotal;
   time_t lasttime;
   FILE *fd;
   
   *total = 0;
   isdotdot = 0;
   curdir = NULL;
   fd = NULL;
   if(path != NULL) {
      curdir = g_malloc (strlen (GFTP_GET_DIRECTORY (hdata->ftpdata)) + 1);
      strcpy (curdir, GFTP_GET_DIRECTORY (hdata->ftpdata));
      if(gftp_set_directory (hdata->ftpdata, path) != 0) return (NULL);
   }

   if (up_wid != NULL) {
      update_ftp_info (hdata->wdata);
      gtk_label_set (up_wid, "Receiving file names...");
      fix_display ();
   }
   
   g_snprintf (description, sizeof (description), "%s://%s:%s@%s:%d%s", 
   	hdata->protocol == ftp ? "ftp" : "http",
   	GFTP_GET_USERNAME (hdata->ftpdata), GFTP_GET_PASSWORD (hdata->ftpdata),
   	GFTP_GET_HOSTNAME (hdata->ftpdata), GFTP_GET_PORT (hdata->ftpdata),
   	path == NULL ? GFTP_GET_DIRECTORY (hdata->ftpdata) : path);
   description[sizeof (description)-1] = '\0';
   remove_double_slashes (description+6);

   if (use_cache && load_from_cache && (fd = find_cache_entry (description)) != NULL) {
      files = parse_local_file (fd, 0, total, hdata->protocol);
      if (hdata->wdata->hdata == hdata) hdata->wdata->cached = 1;
      fclose (fd);
      return (files);
   }

   if (use_cache) fd = new_cache_entry (description);
   if (hdata->protocol == ftp) {
      if (gftp_list_files (hdata->ftpdata) != 0) {
         update_ftp_info (hdata->wdata);
         return (NULL);
      }
   }
   else {
      dir = GFTP_GET_DIRECTORY (hdata->ftpdata);
      if (dir == NULL) dir = &nodir;
      if (!http_connect (hdata)) return (NULL);
      tempstr = g_strjoin (NULL, "GET ftp://", GFTP_GET_USERNAME (hdata->ftpdata), 
      	":", GFTP_GET_PASSWORD (hdata->ftpdata), "@", GFTP_GET_HOSTNAME (hdata->ftpdata), 
      	dir, " HTTP/1.1\r\n", NULL);
      ftp_log (LOG_SEND, tempstr);
      write (hdata->ftpdata->datafd, tempstr, strlen (tempstr));
      g_free (tempstr);
      ftp_log (LOG_MISC, "Retrieving directory listing...\n");
   }
   
   memset (&readln_buffer, 0, sizeof (readln_buffer));
   files = lastfle = NULL;
   lasttime = time (NULL);
   dltotal = 0;
   while (hdata->protocol == ftp ? (got = gftp_get_next_file (hdata->ftpdata, &fle)) > 0 :
   	(got = http_get_next_file (hdata->ftpdata, &fle)) > 0) {
      dltotal += got;
      if (!fle.file) continue; /* Invalid entry */
      if (strcmp (fle.file, ".") == 0) continue;
      if(strcmp(fle.file, "..") == 0) isdotdot = 1;

      if (up_wid != NULL && time (NULL)-lasttime >= 1) {
         insert_commas (dltotal, commastr, sizeof (commastr));
         g_snprintf (logstr, sizeof (logstr), "Retrieving file names...%s bytes", commastr);
         logstr[sizeof (logstr)-1] = '\0';
         gtk_label_set (up_wid, logstr);
         fix_display ();
         lasttime = time (NULL);
      }
      if (use_cache && fd != NULL) {
         fwrite (GFTP_GET_LAST_DIRENT (hdata->ftpdata), 1, strlen (GFTP_GET_LAST_DIRENT (hdata->ftpdata)), fd);
         fwrite ("\n", 1, 1, fd);
      }
      newfle = g_malloc0 (sizeof (struct ftp_file_data));
      memcpy (newfle, &fle, sizeof (gftp_file));
      newfle->flags = 0;
      if (strchr (newfle->attribs, 'd') != NULL) newfle->flags |= FILE_ISDIR;
      if (strchr (newfle->attribs, 'l') != NULL) newfle->flags |= FILE_ISLINK;
      if ((strchr (newfle->attribs, 'x') != NULL) && !(newfle->flags & FILE_ISDIR)
      		&& !(newfle->flags & FILE_ISLINK)) newfle->flags |= FILE_ISEXE;
      newfle->next = NULL;
      if (lastfle == NULL) files = newfle;
      else lastfle->next = newfle;
      lastfle = newfle;
      (*total)++;
   }
   
   if (fd != NULL) fclose (fd);
   if (hdata->protocol == ftp) gftp_end_transfer (hdata->ftpdata);
   else {
      close (hdata->ftpdata->datafd);
      ftp_log (LOG_MISC, "Finished retrieving directory listing\n");
   }
   
   if (files != NULL && !isdotdot) {
      newfle = g_malloc0 (sizeof(struct ftp_file_data));
      newfle->file = g_malloc (3);
      strcpy (newfle->file, "..");

      newfle->flags = FILE_ISDIR;
      newfle->next = NULL;
      if (lastfle == NULL) files = newfle;
      else lastfle->next = newfle;
      (*total)++;
   }

   if (hdata->wdata->hdata == hdata) hdata->wdata->cached = 0;
   if (path != NULL) if (gftp_set_directory (hdata->ftpdata, curdir) != 0) return (NULL);
   return (files);
}
/*****************************************************************************/
int http_get_next_file (gftp_request *request, gftp_file *fle) {
   char *tempstr;

   if (GFTP_GET_LAST_DIRENT (request)) g_free (GFTP_GET_LAST_DIRENT (request));
   if ((tempstr = gftp_read_line (GFTP_GET_DATA_FD (request), &readln_buffer)) == NULL) {
      GFTP_GET_LAST_DIRENT (request) = NULL;
      return (0);
   }
   if (parse_html_line (tempstr, fle) == 0) {
      memset (fle, 0, sizeof (gftp_file));
   }
   GFTP_GET_LAST_DIRENT (request) = tempstr;

   return (strlen (tempstr));
}
/*****************************************************************************/
int http_connect (struct ftp_host_data *hdata) {
   struct sockaddr_in proxyaddr;
   struct hostent *host;
   int proxyfd, curhost;

   if ((proxyfd = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) {
      if (hdata->ftpdata->logging) {
         hdata->ftpdata->logging_function (gftp_logging_error, hdata->ftpdata->user_data, "Failed to create a socket: %s\n",
      		g_strerror (errno));
      }
      return (0);
   }

   if (hdata->ftpdata->logging) {
      hdata->ftpdata->logging_function (gftp_logging_misc, hdata->ftpdata->user_data, "Looking up %s...\n", 
      		GFTP_GET_PROXY_HOSTNAME (hdata->ftpdata));
   }
   memset (&proxyaddr, 0, sizeof (proxyaddr));
   proxyaddr.sin_family = AF_INET;
   proxyaddr.sin_port = htons (GFTP_GET_PROXY_PORT (hdata->ftpdata));
   if ((host = gethostbyname (GFTP_GET_PROXY_HOSTNAME (hdata->ftpdata))) == NULL) {
      if (hdata->ftpdata->logging) {
         hdata->ftpdata->logging_function (gftp_logging_error, hdata->ftpdata->user_data, "Cannot look up hostname %s: %s\n", 
         	GFTP_GET_PROXY_HOSTNAME (hdata->ftpdata), g_strerror (errno));
      }
      close (proxyfd);
      return (0);
   }
   curhost = 0;
   while (host->h_addr_list[curhost] != NULL) {
      if (hdata->ftpdata->logging) {
         hdata->ftpdata->logging_function (gftp_logging_misc, hdata->ftpdata->user_data, 
         	"Trying %s:%d...\n", host->h_name, GFTP_GET_PROXY_PORT (hdata->ftpdata));
      }
      memcpy (&proxyaddr.sin_addr, host->h_addr_list[curhost], host->h_length);
      if (connect (proxyfd, (struct sockaddr *) &proxyaddr, sizeof (proxyaddr)) == -1 && hdata->ftpdata->logging) {
         hdata->ftpdata->logging_function (gftp_logging_error, hdata->ftpdata->user_data, "Cannot connect to %s: %s\n", 
         	host->h_name, g_strerror (errno));
      }
      else break;
      curhost++;
   }

   if (host->h_addr_list[curhost] == NULL) {
      close (proxyfd);
      return (0);
   }
   if (hdata->ftpdata->logging) {
      hdata->ftpdata->logging_function (gftp_logging_misc, hdata->ftpdata->user_data, "Connected to %s:%d\n", host->h_name, GFTP_GET_PROXY_PORT (hdata->ftpdata));
   }
   hdata->ftpdata->datafd = proxyfd;
   return (1);
}
/*****************************************************************************/
int http_get_file (struct ftp_host_data *hdata, char *filename) {
   char *tempstr;
   
   if (!http_connect (hdata)) return (0);
   tempstr = g_strjoin (NULL, "GET ftp://", GFTP_GET_USERNAME (hdata->ftpdata), 
      	":", GFTP_GET_PASSWORD (hdata->ftpdata), "@", GFTP_GET_HOSTNAME (hdata->ftpdata), 
        "/", filename, " HTTP/1.1\r\n", NULL);
   if (hdata->ftpdata->logging) {
      hdata->ftpdata->logging_function (gftp_logging_send, hdata->ftpdata->user_data, tempstr);
   }
   write (GFTP_GET_DATA_FD (hdata->ftpdata), tempstr, strlen (tempstr));
   g_free (tempstr);
   if (hdata->ftpdata->logging) {
      hdata->ftpdata->logging_function (gftp_logging_send, hdata->ftpdata->user_data, "Retrieving file: %s...\n", filename);
   }
   return (1);
}
/*****************************************************************************/
int parse_html_line (char *tempstr, gftp_file *fle) {
   char *stpos, *pos, month[4], tempchar;
   struct tm t;
   
   memset (fle, 0, sizeof (gftp_file));

   if ((pos = strstr (tempstr, "<A HREF")) == NULL) return (0);
   if (strstr (pos+7, "<A HREF") != NULL) return (0);

   /* Find the filename */
   while (*pos != '"' && *pos != '\0') pos++;
   if (*pos == '\0') return (0);
   pos++;
   stpos = pos;
   while (*pos != '"' && *pos != '\0') pos++;
   if (*pos == '\0') return (0);
   tempchar = *pos;
   *pos = '\0';

   /* Copy file attributes. Just about the only thing we can get is whether it
      is a directory or not */
   fle->attribs = g_malloc (11);
   strcpy (fle->attribs, "----------");
   if (*(pos-1) == '/') {
      *(pos-1) = '\0';
      *fle->attribs = 'd';
   }
   else *fle->attribs = '-';

   /* Copy filename */
   fle->file = g_malloc (strlen (stpos) + 1);
   strcpy (fle->file, stpos);
   if (*(pos-1) == '\0') *(pos-1) = '/';
   *pos = tempchar;

   /* Now move on to get the date. */
   pos++;
   if ((pos = strstr (pos, "</A>")) == NULL) return (0);
   pos += 4;
   while (1) {
      /* Some proxy servers (Squid) return the space between the file and date
         with ". . . . . ." between them */
      while (*pos == ' ') pos++;
      if (*pos == '.') pos++;
      else break;
   }
   
   /* Now get the date */
   memset (&t, 0, sizeof (t));
   memset (month, 0, sizeof (month));
   if (*pos == '[') {
      /* Copy month */
      pos++;
      strncpy (month, pos, 3);
      pos += 3;
      
      /* Copy day */
      while (*pos == ' ') pos++;
      t.tm_mday = strtol (pos, (char **) NULL, 10);
      while (*pos != ' ' && *pos != '\0') pos++;

      /* Copy year */ 
      while (*pos == ' ') pos++;
      t.tm_year = strtol (pos, (char **) NULL, 10);
      while (*pos != ' ' && *pos != '\0') pos++;
   }
   else {
      sscanf (pos, "%02d-%3s-%04d %02d:%02d", &t.tm_mday, month, &t.tm_year, 
      		&t.tm_hour, &t.tm_min);
      while (*pos != ' ' && *pos != '\0') pos++;
      if (*pos == '\0') return (1);
      while (*pos == ' ') pos++;
      while (*pos != ' ' && *pos != '\0') pos++;
      if (*pos == '\0') return (1);
      while (*pos == ' ') pos++;
   }
   fle->datetime = mktime (&t);
   fle->size = strtol (pos, (char **) NULL, 10) * 1024;
   return (1);
}
/*****************************************************************************/
