#include "helperfuncs.h"

FILE *
get_fileptr_stdin() {
  return stdin;
}

FILE *
get_fileptr_stdout() {
  return stdout;
}

FILE *
get_fileptr_stderr() {
  return stderr;
}
