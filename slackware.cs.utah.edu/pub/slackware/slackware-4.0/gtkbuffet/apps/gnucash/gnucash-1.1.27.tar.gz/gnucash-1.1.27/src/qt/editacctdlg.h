#ifndef _EDITACCTDLG_H
#define _EDITACCTDLG_H

#include <qdialog.h>

class EditAcctDlg : public QDialog {
  Q_OBJECT
    
public:

  EditAcctDlg();
  ~EditAcctDlg();

protected slots:
  void notesCallback ();

};

#endif

