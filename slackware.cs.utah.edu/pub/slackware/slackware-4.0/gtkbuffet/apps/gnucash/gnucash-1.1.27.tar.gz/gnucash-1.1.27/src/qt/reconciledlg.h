#ifndef _RECONCILEDLG_H
#define _RECONCILEDLG_H

#include <qdialog.h>

class ReconcileDlg : public QDialog {
  Q_OBJECT
    
public:
  ReconcileDlg();
  ~ReconcileDlg();

};

#endif

