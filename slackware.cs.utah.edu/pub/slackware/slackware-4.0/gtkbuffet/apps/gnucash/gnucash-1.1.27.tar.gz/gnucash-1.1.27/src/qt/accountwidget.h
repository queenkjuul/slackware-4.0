#ifndef _ACCOUNTWIDGET_H
#define _ACCOUNTWIDGET_H

#include <ktopwidget.h>
#include <qmenubar.h>
#include <qlist.h>
#include <qpopmenu.h>

#define ID_ACTIV_TRANSFER 1
#define ID_ACTIV_RECONCILE 2
#define ID_ACTIV_ADJBAL 3
#define ID_ACTIV_REPORT 4
#define ID_ACTIV_DELETE 5
#define ID_ACTIV_CLOSE 6

#define ID_HELP_ABOUT   100
#define ID_HELP_HELP    101
#define ID_HELP_LICENSE 103

class AccountWidget : public KTopLevelWidget {
  Q_OBJECT
    
public:

  AccountWidget();
  ~AccountWidget();
  
private:
    KMenuBar *menu;
    
protected:
    int initMenu();
    void initGeometry();

    void doTransfer ();
    void doReconcile ();
    void doAdjustBalance ();

protected slots:
    void menuCallback (int item);
};

#endif

