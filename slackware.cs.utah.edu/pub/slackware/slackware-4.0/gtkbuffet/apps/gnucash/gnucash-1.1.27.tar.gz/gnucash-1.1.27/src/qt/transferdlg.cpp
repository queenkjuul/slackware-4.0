#undef HAVE_CONFIG_H
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

/* #include <unistd.h>
#include <time.h>
#include <qpopmenu.h>
#include <qkeycode.h>
#include <qaccel.h> 
#include <qfiledlg.h> 
#include <string.h>
#include <stdlib.h>
#include <kmsgbox.h> 
#include <qmsgbox.h> 
#include <ktopwidget.h>
#include <ktoolbar.h>
#include "accwidget.h"
#include "klocale.h"
#include <kiconloader.h>
#include <kwm.h> */

#include <qpushbt.h>
#include <qlabel.h>
#include <qlined.h>
#include <qcombo.h>

#include <kapp.h>
#include "transferdlg.h"

TransferDlg::TransferDlg() {
  QLabel *lb;
  QLineEdit *le;
  QComboBox *co;

  QPushButton *pb;

  lb = new QLabel (this),
  lb->setText ("Date");
  lb->setGeometry (319,10,100,25);
  lb->setAlignment (AlignRight);

  le = new QLineEdit (this);
  le->setGeometry (437,8,144,25);

  lb = new QLabel (this),
  lb->setText ("Description");
  lb->setGeometry (8,41,100,25);
  lb->setAlignment (AlignRight);

  le = new QLineEdit (this);
  le->setGeometry (110,42,228,25);

  lb = new QLabel (this),
  lb->setText ("$");
  lb->setGeometry (351,44,39,25);

  le = new QLineEdit (this);
  le->setGeometry (402,43,176,25);

  lb = new QLabel (this),
  lb->setText ("Memo");
  lb->setGeometry (7,81,83,25);

  le = new QLineEdit (this);
  le->setGeometry (89,77,251,25);

  lb = new QLabel (this),
  lb->setText ("From");
  lb->setGeometry (10,117,71,25);
  lb->setAlignment (AlignRight);

  co = new QComboBox (FALSE,this);
  co->setGeometry (88,115,150,25);
    
  lb = new QLabel (this),
  lb->setText ("To");
  lb->setGeometry (317,116,47,25);
  lb->setAlignment (AlignRight);

  co = new QComboBox (FALSE,this);
  co->setGeometry (373,116,150,25);

  pb = new QPushButton (this);
  pb->setText ("Cancel");
  pb->setGeometry (145,174,100,30);

  connect( pb, SIGNAL(clicked()), SLOT(reject()) );

  pb = new QPushButton (this);
  pb->setText ("Transfer");
  pb->setGeometry (266,174,100,30);

  connect( pb, SIGNAL(clicked()), SLOT(accept()) );

  setCaption(klocale->translate("Money Transfer"));
  resize(588,214);
}

TransferDlg::~TransferDlg() {
}

#include "transferdlg.moc"




