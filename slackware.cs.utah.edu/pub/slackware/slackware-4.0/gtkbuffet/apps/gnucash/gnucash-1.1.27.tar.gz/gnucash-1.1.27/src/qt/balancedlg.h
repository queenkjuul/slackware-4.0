#ifndef _BALANCEDLG_H
#define _BALANCEDLG_H

#include <qdialog.h>

class BalanceDlg : public QDialog {
  Q_OBJECT
    
public:
  BalanceDlg();
  ~BalanceDlg();

};

#endif

