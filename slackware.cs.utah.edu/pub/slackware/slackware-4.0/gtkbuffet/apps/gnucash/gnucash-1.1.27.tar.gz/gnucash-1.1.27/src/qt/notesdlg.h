#ifndef _NOTESDLG_H
#define _NOTESDLG_H

#include <qdialog.h>

class NotesDlg : public QDialog {
    Q_OBJECT
    
public:
  NotesDlg();
  ~NotesDlg();
};

#endif

