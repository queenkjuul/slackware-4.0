#undef HAVE_CONFIG_H
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

/* #include <unistd.h>
#include <time.h>
#include <qpopmenu.h>
#include <qkeycode.h>
#include <qaccel.h> 
#include <qfiledlg.h> 
#include <string.h>
#include <stdlib.h>
#include <kmsgbox.h> 
#include <qmsgbox.h> 
#include <ktopwidget.h>
#include <ktoolbar.h>
#include "accwidget.h"
#include "klocale.h"
#include <kiconloader.h>
#include <kwm.h> */

#include <qlabel.h>
#include <qpushbt.h>
#include <qlined.h>

#include <kapp.h>
#include "balancedlg.h"

BalanceDlg::BalanceDlg() {
  QLabel *lb;
  QPushButton *pb;
  QLineEdit *le;

  lb = new QLabel (this);
  lb->setAlignment (AlignRight);
  lb->setText ("Date");
  lb->setGeometry (8,19,156,25); 

  le = new QLineEdit (this); 
  le->setGeometry (175,15,181,25);

  lb = new QLabel (this);
  lb->setAlignment (AlignRight);
  lb->setText ("New Balance $");
  lb->setGeometry (8,57,156,25);  

  le = new QLineEdit (this); 
  le->setGeometry (175,53,181,25);

  lb = new QLabel (this);
  lb->setFrameStyle (QFrame::HLine | QFrame::Sunken);
   lb->setGeometry (1,89,364,21);

  pb = new QPushButton (this);
  pb->setGeometry (17,114,100,30);
  pb->setText ("OK");

  connect( pb, SIGNAL(clicked()), SLOT(accept()) );

  pb = new QPushButton (this);
  pb->setGeometry (127,114,100,30);
  pb->setText ("Cancel");

  connect( pb, SIGNAL(clicked()), SLOT(reject()) );


  pb = new QPushButton (this);
  pb->setGeometry (234,114,100,30);
  pb->setText ("Help");

  setCaption(klocale->translate("Savings: Adjust Balance"));
  resize(367,157);
}

BalanceDlg::~BalanceDlg() {
}

#include "balancedlg.moc"




