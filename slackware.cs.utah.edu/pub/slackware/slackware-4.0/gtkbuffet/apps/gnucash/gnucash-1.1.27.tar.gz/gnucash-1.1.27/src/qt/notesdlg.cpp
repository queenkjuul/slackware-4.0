#undef HAVE_CONFIG_H
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

/* #include <unistd.h>
#include <time.h>
#include <qpopmenu.h>
#include <qkeycode.h>
#include <qaccel.h> 
#include <qfiledlg.h> 
#include <string.h>
#include <stdlib.h>
#include <kmsgbox.h> 
#include <qmsgbox.h> 
#include <ktopwidget.h>
#include <ktoolbar.h>
#include "accwidget.h"
#include "klocale.h"
#include <kiconloader.h>
#include <kwm.h> */

#include <qlabel.h>
#include <qmlined.h>
#include <qpushbt.h>

#include <kapp.h>
#include "notesdlg.h"

NotesDlg::NotesDlg() {
  QPushButton *pb;
  QLabel *lb;
  QMultiLineEdit *mle;

  mle = new QMultiLineEdit (this);
  mle->setGeometry (0,4,458,167);

  lb = new QLabel (this);
  lb->setFrameStyle (QFrame::HLine | QFrame::Sunken);
  lb->setGeometry (0,172,459,10);
  
  pb = new QPushButton (this);
  pb->setText ("OK");
  pb->setGeometry (110,186,100,30);

  connect( pb, SIGNAL(clicked()), SLOT(accept()) );

  pb = new QPushButton (this);
  pb->setText ("Cancel");
  pb->setGeometry (228,186,100,30);

  connect( pb, SIGNAL(clicked()), SLOT(reject()) );

  setCaption(klocale->translate("Notes"));
  resize(462,225);
}

NotesDlg::~NotesDlg() {
}

#include "notesdlg.moc"




