
/* SWIG insists that the entry function to the module be gnucash(), so
   we redirect the name */

void
gnucash_guile_init();
