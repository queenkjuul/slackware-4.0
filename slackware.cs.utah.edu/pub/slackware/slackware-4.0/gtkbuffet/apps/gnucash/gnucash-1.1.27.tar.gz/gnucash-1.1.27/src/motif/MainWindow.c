/********************************************************************\
 * MainWindow.c -- the main window, and associated helper functions * 
 *                 and callback functions for xacc (X-Accountant)   *
 * Copyright (C) 1997 Robin D. Clark                                *
 * Copyright (C) 1998 Linas Vepstas                                 *
 *                                                                  *
 * This program is free software; you can redistribute it and/or    *
 * modify it under the terms of the GNU General Public License as   *
 * published by the Free Software Foundation; either version 2 of   *
 * the License, or (at your option) any later version.              *
 *                                                                  *
 * This program is distributed in the hope that it will be useful,  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    *
 * GNU General Public License for more details.                     *
 *                                                                  *
 * You should have received a copy of the GNU General Public License*
 * along with this program; if not, write to the Free Software      *
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *                                                                  *
 *   Author: Rob Clark                                              *
 * Internet: rclark@cs.hmc.edu                                      *
 *  Address: 609 8th Street                                         *
 *           Huntington Beach, CA 92648-4632                        *
\********************************************************************/

#include <Xm/Xm.h>
#include <Xm/ArrowB.h>
#include <Xm/Form.h>
#include <Xm/Label.h>
#include <Xm/LabelGP.h>
#include <Xm/List.h>
#include <Xm/MainW.h>
#include <Xm/PanedW.h>
#include <Xm/Protocols.h>
#include <Xm/RowColumn.h>
#include <Xm/Text.h>
#include <Xbae/Matrix.h>

#include "config.h"

#include "AdjBWindow.h"
#include "Account.h"
#include "AccWindow.h"
#include "BuildMenu.h"
#include "Destroy.h"
#include "FileBox.h"
#include "FileDialog.h"
#include "Group.h"
#include "HelpWindow.h"
#include "LedgerUtils.h"
#include "top-level.h"
#include "messages.h"
#include "MainWindow.h"
#include "RecnWindow.h"
#include "RegWindow.h"
#include "Reports.h"
#include "Scrub.h"
#include "TransLog.h"
#include "util.h"
#include "XferWindow.h"
#include "xtutil.h"
#include "gnucash.h"

typedef struct _MainArrow {

  Account *account;
  Widget   arrowb;   /* arrow button in the main window */
  short    expand;   /* expand display of subaccounts in main window */
  int      PreviousArrowReason; /* arrow workaround */

} MainArrow;

static MainArrow **arrowList = NULL;

/* This static indicates the debugging module that this .o belongs to.  */
static short module = MOD_GUI;

/** PROTOTYPES ******************************************************/
static void xaccMainWindowRedisplayBalance (void);
static void closeMainWindow ( Widget mw, XtPointer cd, XtPointer cb );
static void listCB          ( Widget mw, XtPointer cd, XtPointer cb );
static void fileMenubarCB   ( Widget mw, XtPointer cd, XtPointer cb );
static void accountMenubarCB( Widget mw, XtPointer cd, XtPointer cb );
static void expandListCB    ( Widget mw, XtPointer cd, XtPointer cb );
static void helpMenubarCB   ( Widget mw, XtPointer cd, XtPointer cb );

static void ArrowEventCallback (Widget w, XtPointer pClientData,
                                XEvent *event, Boolean *ContDispatch);

/** GLOBALS *********************************************************/
/* hack alert -- most of these globals should be moved to a struct! */
static Account *selected_acc = NULL;     /* The selected account */
static Widget accountlist;
static Widget baln_widget;
static Widget show_widget;
short show_categories = 1;

enum {
  FMB_NEW,
  FMB_OPEN,
  FMB_IMPORT,
  FMB_SAVE,
  FMB_SAVEAS,
  FMB_QUIT,
};

enum {
  AMB_NEW,
  AMB_OPEN,
  AMB_LEDGER,
  AMB_EDIT,
  AMB_DEL,
  AMB_TRNS,
  AMB_RPRT,
  AMB_SHOW,
  AMB_SCRUB,
  AMB_CAT,
};

/* Pixel values are used to color the balance field text 
 * when computing the balance */
#if !USE_NO_COLOR
#  define POSITIVE_BALANCE "black"
#  define NEGATIVE_BALANCE "red"
Pixel   posPixel, negPixel;
Boolean havePixels = False;
#endif

#define XACC_MAIN_ACC_ARRW 0
#define XACC_MAIN_ACC_NAME 1
#define XACC_MAIN_ACC_TYPE 2
#define XACC_MAIN_ACC_BALN 3
#define XACC_MAIN_NUM_COLS 4

/********************************************************************\
\********************************************************************/

MainArrow *
xaccMainArrow (Widget acctrix, Account *acc )
{
   MainArrow *arrowData;
   int height;

   FETCH_FROM_LIST (MainArrow, arrowList, acc, account, arrowData);

   arrowData->expand = 0;

   /* adjust arrow size for font size */
   height = XbaeMatrixGetRowPixelHeight (acctrix);
   arrowData->arrowb = XtVaCreateManagedWidget ("accarrow", 
                                      xmArrowButtonWidgetClass, acctrix,
                                      XmNwidth, height,
                                      XmNheight, height,
                                      XmNshadowThickness, 0,
                                      XmNarrowDirection, XmARROW_DOWN, 
                                      NULL);

   XtAddCallback (arrowData->arrowb, XmNactivateCallback, 
                         expandListCB, (XtPointer *) arrowData);

#define __XACC_DO_ARROW_CALLBACK
#ifdef  __XACC_DO_ARROW_CALLBACK
   /* add a button press event handler just in case the 
    * XmNactivate callback is broken. See notes for the
    * ArrowEventCallback for details.  -- Linas */
   arrowData->PreviousArrowReason = 0;
   XtAddEventHandler(arrowData->arrowb, 
                     ButtonPressMask | ButtonReleaseMask,
                     False, (XtEventHandler) ArrowEventCallback,
                     (XtPointer) arrowData);
#endif /* __XACC_DO_ARROW_CALLBACK */

   return arrowData;
}

/********************************************************************\
\********************************************************************/

void
xaccDestroyMainArrow (Account *acc )
{
   MainArrow *arrowData;

   FIND_IN_LIST (MainArrow, arrowList, acc, account, arrowData); 
   if (!arrowData) return;

   REMOVE_FROM_LIST (MainArrow, arrowList, acc, account); 

   XtRemoveCallback (arrowData->arrowb, XmNactivateCallback,
                     expandListCB, (XtPointer *) arrowData);

#ifdef  __XACC_DO_ARROW_CALLBACK
   arrowData->PreviousArrowReason = 0;
   XtRemoveEventHandler (arrowData->arrowb, 
                         ButtonPressMask | ButtonReleaseMask,
                         False, (XtEventHandler) ArrowEventCallback,
                         (XtPointer) arrowData);
#endif /* __XACC_DO_ARROW_CALLBACK */
   XtUnmanageChild (arrowData->arrowb);
   XtDestroyWidget (arrowData->arrowb);
   arrowData->arrowb = NULL;
   free (arrowData);
}

/********************************************************************\
 * xaccMainWindowAddAcct                                            *
 *                                                                  *
 * Args:   none                                                     *
 * Return: none                                                     *
\********************************************************************/
void
xaccMainWindowAddAcct (Widget acctrix, AccountGroup *grp, int depth )
{

  int   i, j, k, currow;
  char  buf[BUFSIZE];
  char *amt;
  int nacc;
  
  /* Add all the top-level accounts to the list */
  nacc = xaccGroupGetNumAccounts (grp);
  for( i=0; i<nacc; i++ )
    {
    String cols[XACC_MAIN_NUM_COLS];
    Account *acc = xaccGroupGetAccount( grp, i );
    double dbalance;
    int acc_type;
    char * acc_name;
    AccountGroup *acc_children;
    
    acc_type = xaccAccountGetType (acc);
    if ((0 == show_categories) && 
       ((INCOME == acc_type) || (EXPENSE == acc_type))) continue;
    /* fill in the arrow and the account type fileds */
    cols[XACC_MAIN_ACC_ARRW] = XtNewString("");
    cols[XACC_MAIN_ACC_TYPE] = XtNewString(xaccAccountGetTypeStr(acc_type));

    /* fill in the account name field, indenting for sub-accounts */
    buf[0] = 0x0;
    for (j=0; j<depth; j++) {
       strcat (buf, "    ");
    }

    acc_name = xaccAccountGetName (acc);
    strcat (buf, acc_name);
    cols[XACC_MAIN_ACC_NAME] = XtNewString(buf);

    /* fill in the balance column */
    dbalance = xaccAccountGetBalance (acc);
    /* if the account has children, add in thier balance */
    acc_children = xaccAccountGetChildren (acc);
    if (acc_children) {
       dbalance += xaccGroupGetBalance (acc_children);
    }
    
    /* the meaning of "balance" for income and expense 
     * accounts is reversed, since a deposit of a paycheck in a
     * bank account will appear as a debit of the corresponding
     * amount in the income account */
    if ((EXPENSE == acc_type) ||
        (INCOME  == acc_type) ) {
      dbalance = -dbalance;
    }
    amt = xaccPrintAmount (dbalance, PRTSYM | PRTSEP);
    cols[XACC_MAIN_ACC_BALN] = XtNewString(amt);
    
    XtVaGetValues (acctrix, XmNrows, &currow, NULL);
    XbaeMatrixAddRows( acctrix, currow, cols, NULL, NULL, 1 );

    for (k=0; k<XACC_MAIN_NUM_COLS; k++) {
      XtFree (cols[k]);
    }
    
#if !USE_NO_COLOR
    /* Set the color of the text, depending on whether the
     * balance is negative or positive */
    if( 0.0 > dbalance )
      XbaeMatrixSetCellColor( acctrix, currow, XACC_MAIN_ACC_BALN, negPixel );
    else
      XbaeMatrixSetCellColor( acctrix, currow, XACC_MAIN_ACC_BALN, posPixel );    
#endif

    /* associate a pointer to the actual account with the row */
    XbaeMatrixSetRowUserData ( acctrix, currow, (XtPointer) acc); 

    /* If the account has sub-accounts, then add an arrow button 
     * next to the account name.  Clicking on the arrow button will 
     * expand the display to list the sub-accounts.  The arrow button
     * will be a cell-wdiget, and will be stored with the account 
     * structure */
    if (acc_children) {
       MainArrow *arrowData;

       arrowData = xaccMainArrow (acctrix, acc);
       XbaeMatrixSetCellWidget (acctrix, currow, XACC_MAIN_ACC_ARRW, arrowData->arrowb);
       XtManageChild (arrowData->arrowb);

       /* recursively display children accounts */
       if (arrowData->expand) {
          xaccMainWindowAddAcct (acctrix, acc_children, depth+1);
       }
    } else {
       /* if there are no children, make sure that there is no
        * arrow too.  This situation can occur if a sub-account
        * has been deleted. 
        */
       XbaeMatrixSetCellWidget (acctrix, currow, XACC_MAIN_ACC_ARRW, NULL);
       xaccDestroyMainArrow (acc);
    }
  }
}

/********************************************************************\
 * refreshMainWindow                                                *
 *                                                                  *
 * Args:   none                                                     *
 * Return: none                                                     *
 * Global: data        - the data from the datafile                 *
 *         accountlist - the widget that has the list of accounts   *
\********************************************************************/
void
refreshMainWindow( void )
  {

  int   nrows;
  int   row_from_top = 0;
  AccountGroup *grp;

  /* During refresh, we remove and re-add all displayed accounts.
   * We need to do this because the refresh may be due to an account 
   * having been added, or due to an expansion of sub-accounts.
   * However, doing this will cause the window to be scrolled
   * to the top row, which is visually quite annoying.  Thus, we
   * will save the current selected, visible row, and rescroll
   * the redrawn window to put this row back to its original location.
   * So -- first, figure out whats visible, and then restore.
   */
  if (selected_acc) {
    int i, toprow;
    XtVaGetValues( accountlist, XmNrows, &nrows, NULL );

    for (i=0; i<nrows; i++) {
      Account * racc;
      racc = (Account *) XbaeMatrixGetRowUserData (accountlist, i);
      if (racc == selected_acc) break;
    }
    XtVaGetValues( accountlist, XmNtopRow, &toprow, NULL );
    row_from_top = i - toprow;
    if (0 > row_from_top) row_from_top = 0;  /* this should neve happen !? */
  }

  XtVaGetValues( accountlist, XmNrows, &nrows, NULL );
  XbaeMatrixDeleteRows( accountlist, 0, nrows );
  
  grp = xaccSessionGetGroup (current_session);
  if (!grp) grp = topgroup;
  xaccRecomputeGroupBalance (grp);  
  xaccMainWindowAddAcct (accountlist, grp, 0);
  xaccMainWindowRedisplayBalance ();

  /* find the selected account in the new window, 
   * and scroll to it. */
  if (selected_acc) {
    int i, toprow;
    XtVaGetValues( accountlist, XmNrows, &nrows, NULL );

    for (i=0; i<nrows; i++) {
      Account * racc;
      racc = (Account *) XbaeMatrixGetRowUserData (accountlist, i);
      if (racc == selected_acc) break;
    }
    if (i == nrows) i = 0;  /* if selected acct was deleted, scroll to top */
    toprow = i - row_from_top;
    
    /* set this row to be the top visible row */
    XtVaSetValues( accountlist, XmNtopRow, toprow, NULL );
    XbaeMatrixSelectRow( accountlist, i );
  }
}

/********************************************************************\
\********************************************************************/

/* --------------------------------------------------------------------
 * This callback is provided in order to have a separate means of detecting
 * the arrow button activation.  It seems that some (all?) versions of Motif
 * have trouble correctly computing the XmCR_ACTIVATE reason for the arrow
 * button.  In particular, this occurs when the ArrowButton widget has been
 * reparented.  (XbaeMatrix will reparent a widget so that it will
 * be properly clipped, e.g. when it is inside of a scrolling window.
 * The clipping is vitally important to get the widget properly drawn).
 * 
 * In a way, one might argue that it is not surpirsing that a reparented
 * window (XReparentWindow) will confuse the widget: after all, the widget
 * coordinets with respect to the parent widget differ from the window
 * coordinates compared to the parent window.  However, this argument
 * seems flawed: Motif seems to be able to correctly compute and deliver
 * the XmCR_ARM reason when a button is pressed.  Why can't it get the
 * the XmCR_ACTIVATE reason when the very same button is relased?
 * Also, the very same versions of Motif have no problem recognizing
 * that a button press and release has occured in the window, and have
 * no problem calling this callback.  So, somehow, the activate computation 
 * seems broken.
 * 
 * Thus, this callback provides an alternate way of getting the arrow
 * button to work properly.  -- Linas Vepstas October 1997
 */

static void 
ArrowEventCallback(Widget w, XtPointer pClientData,
                   XEvent *event, Boolean *ContDispatch)

{
    XButtonEvent *bev = (XButtonEvent *) event;
    XmArrowButtonCallbackStruct many;

    /* if its not the left mouse button, return */
    if (1 != bev->button) return;

    /* emulate the arm and activate callbacks */
    switch ( event->type ) {
        case ButtonPress:
            many.reason = XmCR_ARM;
            many.event = event;
            many.click_count = 1;
            expandListCB (w, pClientData, (XtPointer) &many);
            break;
        case ButtonRelease:
            many.reason = XmCR_ACTIVATE;
            many.event = event;
            many.click_count = 1;
            expandListCB (w, pClientData, (XtPointer) &many);
            break;
    }
} /* ArrowEventCallback */


/********************************************************************\
\********************************************************************/

static void 
expandListCB( Widget mw, XtPointer pClientData, XtPointer cb)
{
  XmAnyCallbackStruct *info = (XmAnyCallbackStruct *) cb;
  MainArrow *ad = (MainArrow *)pClientData;

  /* a "fix" to avoid double invocation */
  switch ( info->reason ) {
      case XmCR_ACTIVATE:
          /* avoid double invocation */
          if (XmCR_ACTIVATE == ad->PreviousArrowReason) return;
          ad -> PreviousArrowReason = XmCR_ACTIVATE;
          break;

      default:
      case XmCR_ARM:
          /* avoid double invocation */
          if (XmCR_ARM == ad->PreviousArrowReason) return;
          ad -> PreviousArrowReason = XmCR_ARM;
          return;
  }

  /* change arrow direction, mark account as needing expansion */
  if (ad->expand) {
     ad->expand = 0;
     XtVaSetValues (mw, 
                    XmNarrowDirection, XmARROW_DOWN, 
                    NULL);
  } else {
     ad->expand = 1;
     XtVaSetValues (mw, 
                    XmNarrowDirection, XmARROW_UP, 
                    NULL);
  }

  /* redraw the main window */
  selected_acc = ad->account;
  refreshMainWindow ();
}

/********************************************************************\
 * mainWindow -- the main window... (normally) the first window     *
 *   that pops up.  Has list of accounts that the user can open.    *
 *   Opening an account produces a register window.  The user       *
 *   can also create new accounts and edit existing accounts.       *
 *                                                                  *
 * Args:   parent   - the parent of the window to be created        *
 * Return: none                                                     *
 * Global: data        - the data from the datafile                 *
 *         accountlist - the widget that has the list of accounts   *
\********************************************************************/

void
mainWindow(void)
  {
  Widget parent = gnc_get_ui_data();  
  Widget   mainwindow,menubar,actionform,buttonform,pane,button,widget;
  Widget   helpmenu;
  int      position;
  
  /******************************************************************\
   * Set up the menubar                                             *
  \******************************************************************/
  MenuItem fileMenu[] = {
    { NEW_FILE_E_STR,  &xmPushButtonWidgetClass, 'N', NULL, NULL, True,
      fileMenubarCB, (XtPointer)FMB_NEW,    (MenuItem *)NULL, 0 },
    { OPEN_FILE_E_STR, &xmPushButtonWidgetClass, 'O', NULL, NULL, True,
      fileMenubarCB, (XtPointer)FMB_OPEN,   (MenuItem *)NULL, 0 },
    { IMPORT_QIF_E_STR,&xmPushButtonWidgetClass, 'I', NULL, NULL, True,
      fileMenubarCB, (XtPointer)FMB_IMPORT, (MenuItem *)NULL, 0 },
    { "",              &xmSeparatorWidgetClass,   0,  NULL, NULL, True,
      NULL,          NULL,                  (MenuItem *)NULL, 0 },
    { SAVE_STR,        &xmPushButtonWidgetClass, 'S', NULL, NULL, True,
      fileMenubarCB, (XtPointer)FMB_SAVE,   (MenuItem *)NULL, 0 },
    { SAVE_AS_E_STR,   &xmPushButtonWidgetClass, 'A', NULL, NULL, True,
      fileMenubarCB, (XtPointer)FMB_SAVEAS, (MenuItem *)NULL, 0 },
    { "",              &xmSeparatorWidgetClass,   0,  NULL, NULL, True,
      NULL,          NULL,                  (MenuItem *)NULL, 0 },
    { QUIT_STR,        &xmPushButtonWidgetClass, 'Q', NULL, NULL, True,
      fileMenubarCB, (XtPointer)FMB_QUIT,   (MenuItem *)NULL, 0 },
    { NULL,          NULL,                        0,  NULL, NULL, False, 
      NULL,          (XtPointer)0,          (MenuItem *)NULL, 0 },
  };

  MenuItem accountMenu[] = {
    { NEW_ACC_E_STR,        &xmPushButtonWidgetClass, 'N', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_NEW,  (MenuItem *)NULL, 0 },
    { OPEN_ACC_E_STR,       &xmPushButtonWidgetClass, 'O', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_OPEN, (MenuItem *)NULL, 0 },
    { OPEN_SUB_STR,         &xmPushButtonWidgetClass, 'S', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_LEDGER, (MenuItem *)NULL, 0 },
    { EDIT_ACCT_E_STR,      &xmPushButtonWidgetClass, 'E', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_EDIT, (MenuItem *)NULL, 0 },
    { DEL_ACC_E_STR,        &xmPushButtonWidgetClass, 'D', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_DEL,  (MenuItem *)NULL, 0 },
    { "",                   &xmSeparatorWidgetClass,    0, NULL, NULL, True,
      NULL,         NULL,                    (MenuItem *)NULL, 0 },
    { TRANSFER_STR,         &xmPushButtonWidgetClass, 'T', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_TRNS, (MenuItem *)NULL, 0 },
    { REPORT_STR,           &xmPushButtonWidgetClass, 'R', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_RPRT, (MenuItem *)NULL, 0 },
    { SCRUB_STR,            &xmPushButtonWidgetClass, 'C', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_SCRUB, (MenuItem *)NULL, 0 },
    { HIDE_INC_EXP_E_STR,   &xmPushButtonWidgetClass, 'I', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_SHOW, (MenuItem *)NULL, 0 },
#if 0
    { "Edit Categories...", &xmPushButtonWidgetClass, 'C', NULL, NULL, True,
      accountMenubarCB, (XtPointer)AMB_CAT,  (MenuItem *)NULL, 0 },
#endif
    { NULL,         NULL,                          0, NULL, NULL, False, 
      NULL,              (XtPointer)0,       (MenuItem *)NULL, 0 },
  };
  
  MenuItem helpMenu[] = {
    { ABOUT_E_STR,          &xmPushButtonWidgetClass, 'A', NULL, NULL, True,
      helpMenubarCB, (XtPointer)HMB_ABOUT, (MenuItem *)NULL, 0 },
    { HELP_E_STR,           &xmPushButtonWidgetClass, 'H', NULL, NULL, True,
      helpMenubarCB, (XtPointer)HMB_MAIN,  (MenuItem *)NULL, 0 },
    { ACCOUNTS_E_STR,       &xmPushButtonWidgetClass, 'C', NULL, NULL, True,
      helpMenubarCB, (XtPointer)HMB_ACC,   (MenuItem *)NULL, 0 },
    { "",                   &xmSeparatorWidgetClass,    0, NULL, NULL, True,
      NULL,         NULL,                  (MenuItem *)NULL, 0 },
    { LICENSE_E_STR,        &xmPushButtonWidgetClass, 'L', NULL, NULL, True,
      helpMenubarCB, (XtPointer)HMB_LIC,   (MenuItem *)NULL, 0 },
    { NULL,         NULL,                          0, NULL, NULL, False, 
      NULL,              (XtPointer)0,     (MenuItem *)NULL, 0 },
  };
  
  {
  /* make sure that the user is given a chance to save unsaved work
   * if the window manager close window button is hit.  */
  Atom protocol;
  protocol = XmInternAtom (XtDisplay (gnc_get_ui_data()),
                           "WM_DELETE_WINDOW", False);
  XmAddWMProtocolCallback ( gnc_get_ui_data(), protocol, fileMenubarCB,
                            (XtPointer) FMB_QUIT);
  }

  mainwindow = XtVaCreateManagedWidget( "mainwindow", 
                        xmMainWindowWidgetClass, parent, 
                        XmNdeleteResponse,       XmDESTROY,
                        /*
                         * Let the window find its own size, 
                         * based on the font sizes.
                         * XmNwidth,     450,
                         * XmNheight,    240,
                         */
                        XmNtraversalOn,   True,              /* enable tab groups */
                        XmNkeyboardFocusPolicy, XmEXPLICIT,  /* enable tab groups */
                        NULL );
  
  /* Umm... this doesn't seem to be getting called */
  XtAddCallback( mainwindow, XmNdestroyCallback, 
                 closeMainWindow, (XtPointer)NULL );
  
  menubar = XmCreateMenuBar( mainwindow, "menubar", NULL, 0 );  
  
  BuildMenu( menubar, XmMENU_PULLDOWN, FILE_STR,   'F', False, 0, fileMenu );
  BuildMenu( menubar, XmMENU_PULLDOWN, ACCOUNT_STR,'A', False, 0, accountMenu );
  helpmenu = BuildMenu( menubar, XmMENU_PULLDOWN, HELP_STR,   'H', False, 0, helpMenu );
  XtVaSetValues( menubar,
		 XmNmenuHelpWidget,	helpmenu,
		 NULL );

  /* hack alert -- 8 is very sensitive to menu changes! */
  show_widget = accountMenu[8].widget;

  XtManageChild( menubar );
  
  /******************************************************************\
   * If they haven't already been initialize, initialize the Pixel  *
   * values that are used for foreground colors for the balance     *
  \******************************************************************/
#if !USE_NO_COLOR
  if( !havePixels )
    {
    XrmValue colorValue, pixelValue;
    
    colorValue.size = strlen(POSITIVE_BALANCE);
    colorValue.addr = (XtPointer)POSITIVE_BALANCE;
    pixelValue.size = sizeof(Pixel);
    pixelValue.addr = (XtPointer)0;
    
    XtConvertAndStore( parent,
                       XtRString, &colorValue,
                       XtRPixel,  &pixelValue );
    
    posPixel = (*(Pixel *)pixelValue.addr);
    
    colorValue.size = strlen(NEGATIVE_BALANCE);
    colorValue.addr = (XtPointer)NEGATIVE_BALANCE;
    pixelValue.size = sizeof(Pixel);
    pixelValue.addr = (XtPointer)0;
    
    XtConvertAndStore( parent,
                       XtRString, &colorValue,
                       XtRPixel,  &pixelValue );
    
    negPixel = (*(Pixel *)pixelValue.addr);
    
    havePixels = True;
    }
#endif
  
  /* Create a PanedWindow Manager for the dialog box... the paned 
   * window is the parent of the two forms which comprise the two
   * areas of the dialog box */
  pane = XtVaCreateWidget( "pane", 
                           xmPanedWindowWidgetClass, mainwindow,
                           XmNsashWidth,     1,
                           XmNsashHeight,    1,
                           XmNtraversalOn,   True,
                           NULL );
  
  
  /******************************************************************\
   * The account list -- the top part of the window                 *
  \******************************************************************/

  /* form to help place the accountlist */
  actionform = XtVaCreateWidget( "form", 
                                 xmFormWidgetClass, pane,
                                 NULL );
  
  /* Create a matrix widget to hold the account list... the
   * listCB helps make this matrix think it is a list.  We
   * use the matrix instead of a list to get the accounts
   * up in columns */
    {
    String   labels[XACC_MAIN_NUM_COLS]     = {"",  ACC_NAME_STR, TYPE_STR, BALN_STR};
    short    colWidths[]        = {2,20,10,12};
    unsigned char alignments[XACC_MAIN_NUM_COLS] = {
                                   XmALIGNMENT_CENTER,
                                   XmALIGNMENT_BEGINNING,
                                   XmALIGNMENT_CENTER,
                                   XmALIGNMENT_END};
    
    accountlist
      = XtVaCreateWidget( "list",
                          xbaeMatrixWidgetClass,  actionform,
                          XmNvisibleRows,         8,
                          XmNcolumns,             XACC_MAIN_NUM_COLS,
                          XmNcolumnWidths,        colWidths,
                          XmNcolumnAlignments,    alignments,
                          XmNcolumnLabelAlignments,    alignments,
                          XmNcolumnLabels,        labels,
                          XmNtraversalOn,         True,  /* enable tab groups */
                          XmNtraverseFixedCells,  False,
                          XmNnavigationType,      XmEXCLUSIVE_TAB_GROUP,
                          XmNfill,                True,
                          XmNcellMarginHeight,    0,
                          XmNcellMarginWidth,     0,
                          XmNgridType,            XmGRID_NONE,
                          XmNcellShadowThickness, 0,
                          XmNverticalScrollBarDisplayPolicy,XmDISPLAY_STATIC,
                          XmNtopAttachment,       XmATTACH_FORM,
                          XmNleftAttachment,      XmATTACH_FORM,
                          XmNbottomAttachment,    XmATTACH_FORM,
                          XmNrightAttachment,     XmATTACH_FORM,
                          NULL);
    XtAddCallback( accountlist, XmNenterCellCallback,
                   listCB, (XtPointer)NULL );
    
    /* If the user double-clicks on an account in the list, open
     * up the detail view (ie the register window, or whatever) for
     * that type of account */
    XtAddCallback( accountlist, XmNdefaultActionCallback, 
                   accountMenubarCB, (XtPointer)AMB_OPEN );
    }
 
  /******************************************************************\
   * The button area -- has buttons to create a new account, or     *
   * delete an account, or whatever other button I think up         *
   * NOTE: the buttons are just shortcuts to the account menubar,   *
   *       and this is why all the callbacks are accountMenubarCB   *
  \******************************************************************/

  /* create form that will contain most everything in this window...
   * The fractionbase divides the form into segments, so we have
   * better control over where to put the buttons */
  buttonform = XtVaCreateWidget( "form", 
                                  xmFormWidgetClass, pane,
                                  XmNfractionBase,   22,
                                  XmNnavigationType, XmSTICKY_TAB_GROUP, 
                                  NULL );
  
  position = 0;                    /* puts the buttons in the right place */
  
  /* The "Open" button */
  widget = XtVaCreateManagedWidget( OPEN_STR,
                                    xmPushButtonWidgetClass, buttonform,
                                    XmNtopAttachment,      XmATTACH_FORM,
                                    XmNbottomAttachment,   XmATTACH_FORM,
                                    XmNleftAttachment,     XmATTACH_POSITION,
                                    XmNleftPosition,       position,
                                    XmNrightAttachment,    XmATTACH_POSITION,
                                    XmNrightPosition,      position+3,
                                    XmNshowAsDefault,      True,
                                    XmNnavigationType,     XmTAB_GROUP,
                                    NULL );

  XtAddCallback( widget, XmNactivateCallback, 
                 accountMenubarCB, (XtPointer)AMB_OPEN );

  /* The "New" button, to create a new account */
  position += 3;
  widget = XtVaCreateManagedWidget( NEW_STR, 
                                    xmPushButtonWidgetClass, buttonform,
                                    XmNtopAttachment,      XmATTACH_FORM,
                                    XmNbottomAttachment,   XmATTACH_FORM,
                                    XmNleftAttachment,     XmATTACH_POSITION,
                                    XmNleftPosition,       position,
                                    XmNrightAttachment,    XmATTACH_POSITION,
                                    XmNrightPosition,      position+3,
                                    XmNshowAsDefault,      True,
                                    XmNnavigationType,     XmTAB_GROUP,
                                    NULL );
  
  XtAddCallback( widget, XmNactivateCallback, 
                 accountMenubarCB, (XtPointer)AMB_NEW );
  
  /* The "Edit" button */
  position += 3;
  widget = XtVaCreateManagedWidget( EDIT_STR, 
                                    xmPushButtonWidgetClass, buttonform,
                                    XmNtopAttachment,      XmATTACH_FORM,
                                    XmNbottomAttachment,   XmATTACH_FORM,
                                    XmNleftAttachment,     XmATTACH_POSITION,
                                    XmNleftPosition,       position,
                                    XmNrightAttachment,    XmATTACH_POSITION,
                                    XmNrightPosition,      position+3,
                                    XmNshowAsDefault,      True,
                                    XmNnavigationType,     XmTAB_GROUP,
                                    NULL );
  
  XtAddCallback( widget, XmNactivateCallback, 
                 accountMenubarCB, (XtPointer)AMB_EDIT );
  
  /* The "Delete" button */
  position += 3;
  widget = XtVaCreateManagedWidget( DELETE_STR, 
                                    xmPushButtonWidgetClass, buttonform,
                                    XmNtopAttachment,      XmATTACH_FORM,
                                    XmNbottomAttachment,   XmATTACH_FORM,
                                    XmNleftAttachment,     XmATTACH_POSITION,
                                    XmNleftPosition,       position,
                                    XmNrightAttachment,    XmATTACH_POSITION,
                                    XmNrightPosition,      position+3,
                                    XmNshowAsDefault,      True,
                                    XmNnavigationType,     XmTAB_GROUP,
                                    NULL );
  
  XtAddCallback( widget, XmNactivateCallback, 
                 accountMenubarCB, (XtPointer)AMB_DEL );

  button = widget;
  
  
  /* ---------------------------------------------------------------- */

  /* The Asset and Profit field labels: */ 
  position +=5;
  widget = XtVaCreateManagedWidget( ASSETS_C_STR,
                                    xmLabelGadgetClass,    buttonform,
                                    XmNtopAttachment,      XmATTACH_FORM,
                                    XmNleftAttachment,     XmATTACH_POSITION,
                                    XmNleftPosition,       position,
                                    XmNrightAttachment,    XmATTACH_POSITION,
                                    XmNrightPosition,      position+3,
                                    NULL );
  widget = XtVaCreateManagedWidget( PROFITS_C_STR,
                                    xmLabelGadgetClass,    buttonform,
                                    XmNtopAttachment,      XmATTACH_WIDGET,
                                    XmNtopWidget,          widget,
                                    XmNbottomAttachment,   XmATTACH_FORM,
                                    XmNleftAttachment,     XmATTACH_POSITION,
                                    XmNleftPosition,       position,
                                    XmNrightAttachment,    XmATTACH_POSITION,
                                    XmNrightPosition,      position+3,
                                    NULL );
  
  /* and the balance fields: */
  position += 3;
  widget = XtVaCreateManagedWidget( "text",
                                    xmTextWidgetClass,     buttonform,
                                    XmNeditable,           False,
                                    XmNeditMode,           XmMULTI_LINE_EDIT,
                                    XmNcursorPositionVisible, False,
                                    XmNmarginHeight,       0,
                                    XmNmarginWidth,        1,
                                    XmNtopAttachment,      XmATTACH_FORM,
                                    XmNbottomAttachment,   XmATTACH_FORM,
                                    XmNleftAttachment,     XmATTACH_POSITION,
                                    XmNleftPosition,       position,
                                    XmNrightAttachment,    XmATTACH_POSITION,
                                    XmNrightPosition,      position+5,
                                    XmNtraversalOn,        False,  /* dont tab here */
                                    NULL );
  baln_widget = widget;
  
  /* ---------------------------------------------------------------- */
    
  refreshMainWindow();
  XtManageChild(accountlist);
  
  /* Fix button area of the pane to its current size, and not let 
   * it resize. */
  XtManageChild( buttonform );
    {
    Dimension h;
    XtVaGetValues( button, XmNheight, &h, NULL );
    XtVaSetValues( buttonform, XmNpaneMaximum, h, XmNpaneMinimum, h, NULL );
    }
  
  XtManageChild( actionform );
  XtManageChild( pane );
  }

/********************************************************************\
 * closeMainWindow                                                  *
 *   frees memory allocated for an mainWindow, and other cleanup    * 
 *   stuff                                                          * 
 *                                                                  * 
 * Args:   mw - the widget that called us                           * 
 *         cd -                                                     * 
 *         cb -                                                     * 
 * Return: none                                                     *
\********************************************************************/
void 
closeMainWindow( Widget mw, XtPointer cd, XtPointer cb )
  {
  
#ifdef __XACC_DO_ARROW_CALLBACK
  /* this remove core-dumps motif, Don't know why --linas */
  /* XtRemoveEventHandler(mw->arrowb, 
   *                    ButtonPressMask | ButtonReleaseMask,
   *                    True, (XtEventHandler) ArrowEventCallback,
   *                    (XtPointer) mw);
   */
#endif /* __XACC_DO_ARROW_CALLBACK */

  DEBUG("closed MainWindow, coresize = %d\n", _coresize());
  gnc_shutdown(0);	/* XXX - Need prototype */
  }

/********************************************************************\
 * compute profits and asssets
\********************************************************************/
static void
xaccMainWindowRedisplayBalance (void)
{
   int i;
   double  assets  = 0.0;
   double  profits = 0.0;
   char buf[BUFSIZE];
   char * amt;
   AccountGroup *grp;
   Account *acc;
   int nacc;
   
   grp = xaccSessionGetGroup (current_session);
   if (!grp) grp = topgroup;
   nacc = xaccGroupGetNumAccounts (grp);
   for (i=0; i<nacc; i++) {
      int acc_type;
      AccountGroup *acc_children;

      acc = xaccGroupGetAccount (grp,i);
  
      acc_type = xaccAccountGetType (acc);
      acc_children = xaccAccountGetChildren (acc);

      switch (acc_type) {
         case BANK:
         case CASH:
         case ASSET:
         case STOCK:
         case MUTUAL:
         case CREDIT:
         case LIABILITY:
            assets += xaccAccountGetBalance (acc);
            if (acc_children) {
               assets += xaccGroupGetBalance (acc_children);
            }
            break;
         case INCOME:
         case EXPENSE:
            profits -= xaccAccountGetBalance (acc); /* flip the sign !! */
            if (acc_children) {
               profits -= xaccGroupGetBalance (acc_children); /* flip the sign !! */
            }
            break;
         case EQUITY:
         default:
            break;
      }
   }
  
   amt = xaccPrintAmount (assets, PRTSYM | PRTSEP);
   strcpy (buf, amt);
   strcat (buf, "\n");
   amt = xaccPrintAmount (profits, PRTSYM | PRTSEP);
   strcat (buf, amt);
   
   XmTextSetString( baln_widget, buf );
}

/********************************************************************\
 * listCB -- makes the matrix widget behave like a list widget      * 
 *                                                                  * 
 * Args:   mw - the widget that called us                           * 
 *         cd -                                                     * 
 *         cb -                                                     * 
 * Return: none                                                     * 
 * Global: accountlist - the widget that has the list of accounts   *
\********************************************************************/
static void
listCB( Widget mw, XtPointer cd, XtPointer cb )
  {
  XbaeMatrixEnterCellCallbackStruct *cbs =
    (XbaeMatrixEnterCellCallbackStruct *)cb;
  
  cbs->doit = False;
  cbs->map  = False;
  
  selected_acc = (Account *) XbaeMatrixGetRowUserData (accountlist, cbs->row);

  XbaeMatrixDeselectAll(accountlist);
  XbaeMatrixSelectRow( accountlist, cbs->row );
  }


/********************************************************************\
 * fileMenubarCB -- handles file menubar choices                    * 
 *                                                                  * 
 * Args:   mw - the widget that called us                           * 
 *         cd -                                                     * 
 *         cb - const that lets us know which choice was selected   * 
 * Return: none                                                     * 
 * Global: data        - the data from the datafile                 *
 *         datafile    - the name of the user's datafile            *
 *         toplevel    - the toplevel widget                        *
\********************************************************************/

#define SHOW_IO_ERR_MSG(io_error) {				\
  switch (io_error) {						\
     case ERR_FILEIO_NO_ERROR:					\
        break;							\
     case ERR_FILEIO_FILE_NOT_FOUND:				\
        sprintf (buf, FILE_NOT_FOUND_MSG, newfile);		\
        errorBox (buf);				                \
        break;							\
     case ERR_FILEIO_FILE_EMPTY:				\
        sprintf (buf, FILE_EMPTY_MSG, newfile);			\
        errorBox (buf);				                \
        break;							\
     case ERR_FILEIO_FILE_TOO_NEW:				\
        errorBox (FILE_TOO_NEW_MSG);			        \
        break;							\
     case ERR_FILEIO_FILE_TOO_OLD:				\
        if (!verifyBox( FILE_TOO_OLD_MSG )) {		        \
           xaccFreeAccountGroup (newgrp);			\
           newgrp = NULL;					\
        }							\
        break;							\
     case ERR_FILEIO_FILE_BAD_READ:				\
        if (!verifyBox( FILE_BAD_READ_MSG )) {	                \
           xaccFreeAccountGroup (newgrp);			\
           newgrp = NULL;					\
        }							\
        break;							\
     default:							\
        break;							\
  }								\
}
      

static void
fileMenubarCB( Widget mw, XtPointer cd, XtPointer cb )
  {
  int button = (int) cd;
  
  /*
   * which of the file menubar options was chosen
   *   FMB_NEW    -  New datafile
   *   FMB_OPEN   -  Open datfile
   *   FMB_IMPORT -  Open & merge in Quicken QIF File
   *   FMB_SAVE   -  Save datafile
   *   FMB_SAVEAS -  Save datafile As
   *   FMB_QUIT   -  Quit
   */
  
  switch( button )
    {
    case FMB_NEW:
      DEBUG("FMB_NEW\n");
      gncFileNew();
      break;

    case FMB_OPEN: 
      DEBUG("FMB_OPEN\n");
      gncFileOpen();
      break;

    case FMB_IMPORT: 
      DEBUG("FMB_IMPORT\n");
      gncFileQIFImport();
      break;

    case FMB_SAVE:
      DEBUG("FMB_SAVE\n");
      gncFileSave();
      break;

    case FMB_SAVEAS: 
      DEBUG("FMB_SAVEAS\n");
      gncFileSaveAs();
      break;

    case FMB_QUIT:
      DEBUG("FMB_QUIT\n");
      gnc_shutdown(0);
      return;                      /* to avoid the refreshMainWindow */

    default:
      PERR("fileMenubarCB(): We shouldn't be here!");
    }
  refreshMainWindow();
  }

/********************************************************************\
 * accountMenubarCB -- handles account menubar choices              * 
 *                                                                  * 
 * Args:   mw - the widget that called us                           * 
 *         cd - const that lets us know which choice was selected   * 
 *         cb -                                                     * 
 * Return: none                                                     * 
 * Global: data         - the data from the datafile                *
 *         selected_acc - the selected account                      *
 *         toplevel     - the toplevel widget                       *
\********************************************************************/
static void
accountMenubarCB( Widget mw, XtPointer cd, XtPointer cb )
  {
  Widget toplevel = gnc_get_ui_data();  
  int button = (int)cd;
  
  /*
   * which of the file menubar options was chosen
   *   AMB_NEW    -  New account
   *   AMB_OPEN   -  Open account
   *   AMB_LEDGER -  Open account and subaccounts in one register
   *   AMB_EDIT   -  Edit account
   *   AMB_DEL    -  Delete account
   *   AMB_SHOW   -  Show catagories
   *   AMB_SCRUB  -  Clean up single entry messes
   *   AMB_CAT    -  Edit catagories
   */
  
  switch( button )
    {
    case AMB_NEW:
      DEBUG("AMB_NEW\n");
      accWindow(topgroup);
      break;

    case AMB_OPEN:
      DEBUG("AMB_OPEN\n");
      {
        Account *acc = selected_acc;
        if( NULL == acc ) {
          int make_new = verifyBox (ACC_NEW_MSG);
          if (make_new) {
            accWindow(topgroup);
          }
        } else {
          regWindowSimple(acc);
        }
      }
      break;

    case AMB_LEDGER:
      DEBUG("AMB_LEDGER\n");
      {
        Account *acc = selected_acc;
        if( NULL == acc ) {
          int make_new = verifyBox (ACC_NEW_MSG);
          if (make_new) {
            accWindow(topgroup);
          }
        } else {
          regWindowAccGroup(acc);
        }
      }
      break;

    case AMB_EDIT:
      DEBUG("AMB_EDIT\n");
      {
        Account *acc = selected_acc;
        if( NULL == acc ) {
          errorBox (ACC_EDIT_MSG);
        } else {
          editAccWindow( acc );
        }
      }
      break;

    case AMB_DEL:
      DEBUG("AMB_DEL\n");
      {
        Account *acc = selected_acc;
        if( NULL == acc ) {
          errorBox (ACC_DEL_MSG);
        } else {
          char msg[1000];
          sprintf (msg, ACC_DEL_SURE_MSG, xaccAccountGetName (acc));
          if( verifyBox(msg) ) {

            /* before deleting the account, make 
             * sure that we close any misc register 
             * windows, if they are open */
            xaccAccountWindowDestroy (selected_acc);
            xaccRemoveAccount (selected_acc);
            xaccFreeAccount (selected_acc);
            selected_acc = NULL;
            refreshMainWindow();
            }
          }
        }
      break;

    case AMB_TRNS:
      DEBUG("AMB_TRNS\n");
      xferWindow(toplevel, topgroup);
      break;

    case AMB_RPRT:
      DEBUG("AMB_RPRT\n");
      simpleReportWindow(toplevel);
      break;

    case AMB_SHOW: {
      XmString str;
      DEBUG("AMB_SHOW\n");
      if (show_categories) {
         show_categories = 0;
         str = XmStringCreateLtoR (SHOW_INC_EXP_E_STR, XmSTRING_DEFAULT_CHARSET);
      } else {
         show_categories = 1;
         str = XmStringCreateLtoR (HIDE_INC_EXP_E_STR, XmSTRING_DEFAULT_CHARSET);
      }
      XtVaSetValues (show_widget, XmNlabelString, str, NULL);
      XmStringFree (str);
      refreshMainWindow();
      }
      break;

    case AMB_SCRUB:
      DEBUG("AMB_SCRUB\n");
      {
        Account *acc = selected_acc;
        if( NULL != acc ) {
            xaccAccountTreeScrubOrphans (acc);
            xaccAccountTreeScrubImbalance (acc);

            /* hack alert -- should refresh account windows too ... */
            refreshMainWindow();
        }
      }
      break;

    case AMB_CAT:
      DEBUG("AMB_CAT\n");
      break;

    default:
      PERR ("AccountMenuBarCB(): We shouldn't be here!\n");
    }
  }


void
gnc_show_help(const gncHelpTypes t) {
  helpMenubarCB(NULL, (XtPointer)HMB_MAIN,  (MenuItem *)NULL);
}

/********************************************************************\
 * helpMenubarCB -- handles help menubar choices                    * 
 *                                                                  * 
 * Args:   mw - the widget that called us                           * 
 *         cd - const that lets us know which choice was selected   * 
 *         cb -                                                     * 
 * Return: none                                                     * 
 * Global: toplevel    - the toplevel widget                        *
\********************************************************************/
void
helpMenubarCB( Widget mw, XtPointer cd, XtPointer cb )
  {
  Widget toplevel = gnc_get_ui_data();
  int button = (int)cd;
  
  /*
   * which of the file menubar options was chosen
   *   HMB_ABOUT   -  About this program
   *   HMB_MAIN    -  Display help window for the main window
   *   HMB_REGWIN  -  Display help window for the Register Window
   *   HMB_RECNWIN -  Display help window for the Reconcile Window
   *   HMB_LIC     -  GPL Licence info
   */
  
  switch( button )
    {
    case HMB_ABOUT:
      DEBUG("HMB_ABOUT");
      helpWindow( toplevel, ABOUT_STR, HH_ABOUT );
      break;
    case HMB_ACC:
      DEBUG("HMB_ACC");
      helpWindow( toplevel, HELP_STR, HH_ACC );
      break;
    case HMB_REGWIN:
      /* When the user selects "Help" in the RegWindow */
      DEBUG("HMB_REGWIN");
      helpWindow( toplevel, HELP_STR, HH_REGWIN );
      break;
    case HMB_RECNWIN:
      /* When the user selects "Help" in the RecnWindow */
      DEBUG("HMB_RECNWIN");
      helpWindow( toplevel, HELP_STR, HH_RECNWIN );
      break;
    case HMB_ADJBWIN:
      /* When the user selects "Help" in the AdjBWindow */
      DEBUG("HMB_ADJBWIN");
      helpWindow( toplevel, HELP_STR, HH_ADJBWIN );
      break;
    case HMB_MAIN:
      /* When the user selects "Help" in the MainWindow */
      DEBUG("HMB_HELP");
      helpWindow( toplevel, HELP_STR, HH_MAIN );
      break;
    case HMB_LIC:
      /* The GNU Public License */
      DEBUG("HMB_LIC");
      helpWindow( toplevel, LICENSE_STR, HH_GPL );
      break;
    default:
      PERR("helpMenubarCB(): Not a valid help menu selection.");
    }
  }

/********************* END OF FILE **********************************/
