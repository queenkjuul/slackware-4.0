/* -*-gnucash-c-*-
   gnucash.c -- gnucash startup function.
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
                                                                   
   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.
                                                                   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   
   (C) 1998 Rob Browning <rlb@cs.utexas.edu>
*/

#ifdef KDE
extern "C" {
#endif

#define _GNU_SOURCE
#include <stdio.h>

#include <guile/gh.h>

#include "FileDialog.h"
#include "top-level.h"
#include "util.h"
#include "gnucash.h"

static int guile_is_initialized = 0;
static int gargc;
static char **gargv;

/* ============================================================== */

void
gnc_set_double_entry_restriction(const int state) {

  if(state == 0) {
    gh_eval_str("(gnc:config-var-set! gnc:*double-entry-restriction* #f)");
  } else if(state == 1) {
    gh_eval_str("(gnc:config-var-set! gnc:*double-entry-restriction* 'force)");
  } else if(state == 2) {
    gh_eval_str("(gnc:config-var-set! gnc:*double-entry-restriction* 'collect)");
  } else {
    char *tmp = NULL;
    asprintf(&tmp, "(gnc:config-var-set! gnc:*double-entry-restriction* %d)", state);
    assert(tmp);
    gh_eval_str(tmp);
    free(tmp);
  }
}

/* ============================================================== */

static char *
reverse_scan_argv_for_string_arg(const char *target,
                                 const int argc,
                                 char *argv[])
{
  char *result = NULL;
  
  int i;
  for(i = argc - 1; (!result) && (i > 0); i--)
  {
    if(strcmp(target, argv[i]) == 0)
    {
      assert((i + 1) < argc); /* FIXME: This needs to cause a usage failure */
      result = argv[i + 1];
    }
  }
  return result;
}

/* ============================================================== */

static int
reverse_scan_argv_for_arg(const char *target,
                          const int argc,
                          const char *argv[]) {
  int result = 0;
  
  int i;
  for(i = argc - 1; (!result) && (i > 0); i--) {
    if(strcmp(target, argv[i]) == 0) {
      result = 1;
    }
  }
  return result;
}

/* ============================================================== */

static int
running_as_shell(const int argc, const char *argv[]) {
  return(reverse_scan_argv_for_arg("--shell", argc, argv));
}

/* ============================================================== */

/* Because swig doesn't declare the prototype anywhere */
void gnucash_swig_init();

static void 
gnucash_main_helper(int argc, const char *argv[])
{  
  char *startup_dir = NULL;
  char *startup_file = NULL;
  guile_is_initialized = 1;

  gnucash_swig_init();

  /* This has to be done from C because it's the one arg we *have* to
     have (if present) before we start up guile.  It's used to find
     the guile code.  The last --startup-dir on the command line
     wins. */

  startup_dir = reverse_scan_argv_for_string_arg("--startup-dir", argc, (char **)argv);
  
  if(!startup_dir)
  {
    startup_dir = GNC_STARTUP_DIR;
  }

  asprintf(&startup_file, "%s/init.scm", startup_dir);
  assert(startup_file);
  
  fprintf(stderr, "gnucash: startup-dir is %s\n", startup_dir);
  fprintf(stderr, "gnucash: startup-file is %s\n", startup_file);
  
  /* We can't just use gh_eval_str here because --startup-dir might have
     double quotes or other funny chars in it.  */

  gh_define("gnc:_startup-dir-default_", gh_str02scm(startup_dir));

  if(running_as_shell(argc, argv)) {
    /* Add the "--" to keep gh_repl from interpreting the gnucash args */
    
    int scm_argc = argc + 1;
    char **scm_argv = malloc(scm_argc * sizeof(char *));
    assert(scm_argv);

    scm_argv[0] = (char *) argv[0];
    scm_argv[1] = "--";
    memcpy(&(scm_argv[2]), &(argv[1]), (argc - 1) * sizeof(char *));
    gh_repl(scm_argc, scm_argv);
    
  } else {
    /* This should be gh_lookup, but that appears to be broken */
    SCM scm_main;
    
    if(gh_eval_file(startup_file) == SCM_BOOL_F) {
      fprintf(stderr, "gnucash: (load %s) failed\n", startup_file);
      exit(1);
    }

    scm_main = gh_eval_str("gnc:main");
    
    if(gh_procedure_p(scm_main)) {
      gh_call0(scm_main);
    } else {
      fprintf(stderr, "gnucash: gnc:main doesn't exist.  Aborting.\n");
      exit(1);
    }
  }
  exit(0);
}

/* ============================================================== */

void
gnc_shutdown (int exit_status) {
  static int handled_shutdown = 0;

  if(guile_is_initialized) {
    /* This should be gh_lookup, but that appears to be broken */
    SCM scm_shutdown = gh_eval_str("gnc:shutdown");

    if(gh_procedure_p(scm_shutdown)) {
      SCM scm_exit_code = gh_long2scm(exit_status);

      gh_call1(scm_shutdown, scm_exit_code);
      /* this will never execute */
      handled_shutdown = 1;
    }
  } else {
    _gnc_shutdown_(exit_status);
    exit(exit_status);
  }
}

/* ============================================================== */

void
_gnc_shutdown_(int exit_status) {
  /* Put any C level routines that must be called at shutdown here
     gnc:shutdown will call this eventually...
  */

  /* These calls should probably eventually be moved to the scheme
     side... */
  gncFileQuerySave();
  /*XtUnmapWidget(gnc_get_ui_data());*/     /* make it disappear quickly */
  gncFileQuit();
  gnc_ui_shutdown();
}

/* ============================================================== */

int
main(int argc, char *argv[])
{
  gargc = argc;
  gargv = argv;
  
  gh_enter(argc, argv, gnucash_main_helper);
  /* This will never return. */
  
  assert(0);  /* Just to be anal */
  return 0;   /* Just to shut gcc up. */
}

#ifdef KDE
}
#endif

/* ==================== END OF FILE ============================== */


