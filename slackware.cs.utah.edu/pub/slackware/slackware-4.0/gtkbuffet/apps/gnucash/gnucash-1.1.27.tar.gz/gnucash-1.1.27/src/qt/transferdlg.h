#ifndef _TRANSFERDLG_H
#define _TRANSFERDLG_H

#include <qdialog.h>

class TransferDlg : public QDialog {
  Q_OBJECT
    
public:

  TransferDlg();
  ~TransferDlg();

};

#endif

