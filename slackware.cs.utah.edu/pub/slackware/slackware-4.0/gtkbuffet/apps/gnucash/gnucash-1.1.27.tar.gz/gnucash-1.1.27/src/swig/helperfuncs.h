#ifndef __HELPERFUNCS_H__
#define __HELPERFUNCS_H__

#include <stdio.h>

FILE *get_fileptr_stdin();
FILE *get_fileptr_stdout();
FILE *get_fileptr_stderr();

#endif
