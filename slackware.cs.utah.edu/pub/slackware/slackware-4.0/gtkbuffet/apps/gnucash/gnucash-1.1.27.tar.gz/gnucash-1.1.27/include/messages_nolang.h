/********************************************************************\
 * messages_nolang.h -- artificial, language independent messages   *
 * for GnuCash (eX-Accountant)                                      *
 * Copyright (C) 1997 Robin D. Clark                                *
 * Copyright (C) 1997, 1998, 1999 Linas Vepstas                     *
 *                                                                  *
 * This program is free software; you can redistribute it and/or    *
 * modify it under the terms of the GNU General Public License as   *
 * published by the Free Software Foundation; either version 2 of   *
 * the License, or (at your option) any later version.              *
 *                                                                  *
 * This program is distributed in the hope that it will be useful,  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    *
 * GNU General Public License for more details.                     *
 *                                                                  *
 * You should have received a copy of the GNU General Public License*
 * along with this program; if not, write to the Free Software      *
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
\********************************************************************/

#ifndef __XACC_MESSAGES_NOLANG_H__
#define __XACC_MESSAGES_NOLANG_H__

/* with colons at end */
#define ACC_CODE_C_STR      ACC_CODE_STR      ":"
#define ACC_NAME_C_STR      ACC_NAME_STR      ":"
#define ASSETS_C_STR        ASSETS_STR        ":"
#define BALN_C_STR          BALN_STR          ":"
#define CLEARED_C_STR       CLEARED_STR       ":"
#define CREDITS_C_STR       CREDITS_STR       ":"
#define CURRENCY_C_STR      CURRENCY_STR      ":"
#define DEBITS_C_STR        DEBITS_STR        ":"
#define DESC_C_STR          DESC_STR          ":"
#define DIFF_C_STR          DIFF_STR          ":"
#define END_BALN_C_STR      END_BALN_STR      ":"
#define FROM_C_STR          FROM_STR          ":"
#define PARENT_ACC_C_STR    PARENT_ACC_STR    ":"
#define PREV_BALN_C_STR     PREV_BALN_STR     ":"
#define PROFITS_C_STR       PROFITS_STR       ":"
#define QUOTE_SRC_C_STR     QUOTE_SRC_STR     ":"
#define SECURITY_C_STR      SECURITY_STR      ":"
#define TO_C_STR            TO_STR            ":"
#define TOTAL_C_STR         TOTAL_STR         ":"

/* with elipses at end (for menu items) */
#define ABOUT_E_STR         ABOUT_STR         "..."
#define ACCOUNTS_E_STR      ACCOUNTS_STR      "..."
#define ADJ_BALN_E_STR      ADJ_BALN_STR      "..."
#define DEL_ACC_E_STR       DEL_ACC_STR       "..."
#define EDIT_ACCT_E_STR     EDIT_ACCT_STR     "..."
#define HELP_E_STR          HELP_STR          "..."
#define HIDE_INC_EXP_E_STR  HIDE_INC_EXP_STR  "..."
#define IMPORT_QIF_E_STR    IMPORT_QIF_STR    "..."
#define LICENSE_E_STR       LICENSE_STR       "..."
#define NEW_ACC_E_STR       NEW_ACC_STR       "..."
#define NEW_FILE_E_STR      NEW_FILE_STR      "..."
#define OPEN_ACC_E_STR      OPEN_ACC_STR      "..."
#define OPEN_FILE_E_STR     OPEN_FILE_STR     "..."
#define PRINT_E_STR         PRINT_STR         "..."
#define RECONCILE_E_STR     RECONCILE_STR     "..."
#define REPORT_E_STR        REPORT_STR        "..."
#define SAVE_E_STR          SAVE_STR          "..."
#define SAVE_AS_E_STR       SAVE_AS_STR       "..."
#define SHOW_INC_EXP_E_STR  SHOW_INC_EXP_STR  "..."
#define SIMPLE_E_STR        SIMPLE_STR        "..."
#define TRANSFER_E_STR      TRANSFER_STR      "..."

#endif /* __XACC_MESSAGES_NOLANG_H__ */
