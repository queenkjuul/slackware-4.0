/********************************************************************\
 * messages.h -- French Language strings & messages for GnuCash     *
 * Copyright (C) 1997 Robin D. Clark                                *
 * Copyright (C) 1997,1998 Linas Vepstas                            *
 * Copyright (C) 1998 Yannick LE NY (traduction en francais)        *
 *                                                                  *
 * This program is free software; you can redistribute it and/or    *
 * modify it under the terms of the GNU General Public License as   *
 * published by the Free Software Foundation; either version 2 of   *
 * the License, or (at your option) any later version.              *
 *                                                                  *
 * This program is distributed in the hope that it will be useful,  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    *
 * GNU General Public License for more details.                     *
 *                                                                  *
 * You should have received a copy of the GNU General Public License*
 * along with this program; if not, write to the Free Software      *
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *                                                                  *
\********************************************************************/

#ifndef __GNUCASH_MESSAGES_FR_H__
#define __GNUCASH_MESSAGES_FR_H__

#include "config.h"



/** DIALOG BOX MESSAGES: ********************************************/
#define ACC_NEW_MSG       "Voulez-vous cr�er un nouveau compte?\n"\
                          "Sinon, s�lectionnez alors un compte\n"\
                          "� ouvrir dans la fenetre principale.\n"
#define ACC_EDIT_MSG      "Pour afficher un compte, vous devez d'abord \n"\
                          "choisir un compte � afficher.\n"
#define ACC_DEL_MSG       "Pour supprimer un compte, vous devez d'abord \n"\
                          "choisir un compte � supprimer.\n"
#define ACC_DEL_SURE_MSG  "Etes-vous sur de vouloir supprimer le compte %s ?"
#define ACC_NO_NAME_MSG   "Un nom doit etre donn� au compte! \n"
#define FILE_TOO_OLD_MSG  "Ce fichier provient d'une ancienne version de "\
                          "GnuCash.  Voulez-vous continuer?"
#define FILE_TOO_NEW_MSG  "Ce fichier semble provenir d'une nouvelle version "\
                          "de GnuCash.  Voulez-vous continuer?"
#define FILE_BAD_READ_MSG "Il y a une erreur de lecture du fichier. "\
                          "Voulez-vous continuer?"
#define FILE_NOT_FOUND_MSG "Le fichier \n    %s\n ne peut pas etre trouv�."
#define FILE_EMPTY_MSG    "Le fichier \n    %s\n est vide."
#define FMB_SAVE_MSG      "Des changements ont �t� fait depuis la derniere "\
                          "sauvegarde.\nEnregistrer les changements dans le fichier?"
#define RECN_TRANS_WARN   "Attention! Ceci est une transaction de rapprochement. "\
                          "Voulez-vous continuer?"
#define TRANS_DEL_MSG     "Etes-vous sur de vouloir \n supprimer la transaction \n %s ?"
#define XFER_NSF_MSG      "Il doit y avoir au moins deux comptes\n"\
                          "cr��s avant que vous puissiez transf�rer des fonds."
#define XFER_DIFF_MSG     "Le \"depuis\" et \"vers\" les comptes\n doivent etre differents!"
#define XFER_SAME_MSG     "Vous ne pouvez pas transf�rer depuis et vers le meme compte!"
#define XFER_NO_ACC_MSG   "Vous devez sp�cifier un compte � transf�rer depuis, \n"\
                          "ou vers,ou l'un et l'autre, pour cette transaction; \n"\
                          "autrement il ne sera pas enregistr�."




/** MISC INTERNATIONALIZATION STRINGS: ******************************/
/* hack alert -- Linux seems not to support localeconv()
 * for getting currency symbols & monetary units.  Besides,
 * I couldn't find a routine that would print currency amounts anyway...
 */


/* ought to define UK_DATES here, but we're doing it in date.h
 * so that date.c is aware of it */



#define CURRENCY_SYMBOL  "F"



/* phrases */

#define ACC_NAME_STR     "Nom du compte"
#define ACC_TYPE_STR     "Type du compte"
#define ADJ_BALN_STR     "Ajuster le solde"
#define EDIT_ACCT_STR    "Afficher un compte"
#define END_BALN_STR     "Solde final"
#define LOST_ACC_STR     "Comptes perdus/abandonn�s"
#define NEW_BALN_STR     "Nouveau solde"
#define OPEN_BALN_STR    "Solde initial"
#define PICK_ONE_STR     "Choisissez en un"
#define PARENT_ACC_STR   "Compte parent"
#define PREV_BALN_STR    "Pr�c�dent solde"
#define PURCH_PRIC_STR   "Prix d'achat"
#define SALE_PRIC_STR    "Prix de vente"
#define SETUP_ACCT_STR   "Dresser un compte"
#define TOT_SHRS_STR     "Nombre"
#define XFER_MONEY_STR   "Transfert d'argent"
#define XFRM_STR         "Transfert depuis"
#define XFTO_STR         "Transferer �"


/* single words */
#define ACTION_STR       "Action"
#define AMT_STR          "Montant"
#define APPR_STR         "Appr�ciation"
#define ASSETS_STR       "Avoirs"
#define BACK_STR         "Pr�c�dent"
#define BALN_STR         "Solde"
#define BOUGHT_STR       "Achet�"
#define BUY_STR          "Acheter"
#define CANCEL_STR       "Annuler"
#define CHARGE_STR       "Prix"
#define CLEARED_STR      "Solde point�"
#define CLOSE_STR        "Fermer"
#define CREATE_STR       "Cr��r"
#define CREDIT_STR       "Cr�dit"
#define CREDITS_STR      "Cr�dits"
#define DATE_STR         "Date"
#define DEBIT_STR        "Debit"
#define DEBITS_STR       "Debits"
#define DECREASE_STR     "R�duire"
#define DEFICIT_STR      "D�ficit"
#define DELETE_STR       "Supprimer"
#define DEPOSIT_STR      "Depot"
#define DEPR_STR         "D�pr�ciation"
#define DESC_STR         "Description"
#define DIFF_STR         "Diff�rence"
#define DIST_STR         "Dist"    /* Distribution */
#define DIV_STR          "Div"     /* Dividend */
#define EDIT_STR         "Afficher"
#define EXPENSE_STR      "D�pense"
#define FORWARD_STR      "Suivant"
#define HELP_STR         "Aide"
#define INCOME_STR       "Revenus"
#define INCREASE_STR     "Augmenter"
#define INT_STR          "Int"     /* Interest */
#define LTCG_STR         "LTCG"    /* Long Term Capital Gains */
#define MEMO_STR         "Memo"
#define NEW_STR          "Nouveau"
#define NO_STR           "Non"
#define NONE_STR         "(aucun)"
#define NOTES_STR        "Notes"
#define NUM_STR          "Num"
#define OK_STR           "Ok"
#define OPEN_STR         "Ouvrir"
#define PAYMENT_STR      "Paiement"
#define PRICE_STR        "Cours"
#define PROFITS_STR      "Profits"
#define REBATE_STR       "Rabais"
#define RECEIVE_STR      "Re�u"
#define RECONCILE_STR    "Rapprocher"
#define RECORD_STR       "Enregistrer"
#define REPORT_STR       "Rapport"
#define SAVE_STR         "Sauvegarder"
#define SELL_STR         "Vendre"
#define SOLD_STR         "Vendu"
#define SPEND_STR        "Depense"
#define SPLIT_STR        "Diviser"
#define STCG_STR         "STCG"   /* Short Term Captial Gains */
#define SURPLUS_STR      "Exc�dent"
#define TOTAL_STR        "Total"
#define TRANSFER_STR     "Transf�rer"
#define VALUE_STR        "Montant"
#define WARN_STR         "ATTENTION"
#define WITHDRAW_STR     "Se retirer"
#define YES_STR          "Oui"

/* with elipses, colons at end */
#include "messages_nolang.h"

#endif /* __GNUCASH_MESSAGES_FR_H__ */
