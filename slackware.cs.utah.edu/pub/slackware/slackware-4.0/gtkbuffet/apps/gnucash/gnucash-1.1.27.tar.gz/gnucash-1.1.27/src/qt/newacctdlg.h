#ifndef _NEWACCTDLG_H
#define _NEWACCTDLG_H

#include <qdialog.h>

class NewAcctDlg : public QDialog {
  Q_OBJECT
    
public:

  NewAcctDlg();
  ~NewAcctDlg();

protected slots:
  void notesCallback ();
  
};

#endif

