// Contains the version of GnuCash

#include <glib.h>

gchar *VERSION = "1.1.25";
