#undef HAVE_CONFIG_H
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

/* #include <unistd.h>
#include <time.h>
#include <qpopmenu.h>
#include <qkeycode.h>
#include <qaccel.h> 
#include <qfiledlg.h> 
#include <string.h>
#include <stdlib.h>
#include <kmsgbox.h> 
#include <qmsgbox.h> 
#include <ktopwidget.h>
#include <ktoolbar.h>
#include "accwidget.h"
#include "klocale.h"
#include <kiconloader.h>
#include <kwm.h> */

#include <qlabel.h>
#include <qpushbt.h>
#include <qlined.h>
#include <qradiobt.h>
#include <qbttngrp.h>

#include <kapp.h>
#include "newacctdlg.h"
#include "notesdlg.h"

NewAcctDlg::NewAcctDlg() {
  QLabel *l;
  QRadioButton *rb;
  QLineEdit *le;
  QPushButton *pb;

  /* account types */
  QButtonGroup *bg = new QButtonGroup (this, "Account type");
  bg->setGeometry (6,24,340,186);

  rb = new QRadioButton ("Bank",bg);
  rb->setGeometry (24,20,100,30);

  rb = new QRadioButton ("Cash",bg);
  rb->setGeometry (24,45,100,30);

  rb = new QRadioButton ("Asset",bg);
  rb->setGeometry (24,70,100,30); 

  rb = new QRadioButton ("Credit Card",bg);
  rb->setGeometry (24,95,100,30);

  rb = new QRadioButton ("Liability",bg);
  rb->setGeometry (24,120,100,30);


  rb = new QRadioButton ("Stock",bg);
  rb->setGeometry (198,20,100,30);

  rb = new QRadioButton ("Mutual Fund",bg);
  rb->setGeometry (198,45,100,30);

  rb = new QRadioButton ("Income",bg);
  rb->setGeometry (198,70,100,30);

  rb = new QRadioButton ("Expense",bg);
  rb->setGeometry (198,95,100,30);

  rb = new QRadioButton ("Equity",bg);
  rb->setGeometry (198,120,100,30); 

  /* inputs */
  l = new QLabel (this);
  l->setText ("Account Name");
  l->setAlignment (AlignRight);
  l->setGeometry (32,231,100,25);

  le = new QLineEdit (this);
  le->setGeometry (140,227,146,25); 

  l = new QLabel (this);
  l->setText ("Description");
  l->setAlignment (AlignRight);
  l->setGeometry (32,268,100,25);

  le = new QLineEdit (this);
  le->setGeometry (141,265,194,25); 

  l = new QLabel (this);
  l->setText ("Parent Account");
  l->setAlignment (AlignRight);
  l->setGeometry (32,304,100,25);

  pb = new QPushButton (this);
  pb->setGeometry (141,304,100,25);
  pb->setText ("Pick One");
    
  /* button bar */

  pb = new QPushButton (this);
  pb->setGeometry (15,361,100,30);
  pb->setText ("Notes");

  connect( pb, SIGNAL(clicked()), SLOT(notesCallback()) );
   
  pb = new QPushButton (this);
  pb->setGeometry (123,361,100,30);
  pb->setText ("Cancel");

  connect( pb, SIGNAL(clicked()), SLOT(reject()) );

  pb = new QPushButton (this);
  pb->setGeometry (236,361,100,30);
  pb->setText ("Create");

  connect( pb, SIGNAL(clicked()), SLOT(accept()) );

  /* misc */

  setCaption(klocale->translate("New Account"));
  resize(352, 400);
}

NewAcctDlg::~NewAcctDlg() {
}

void NewAcctDlg::notesCallback (void) {
  NotesDlg *nd = new NotesDlg();
  nd->exec();   
}

#include "newacctdlg.moc"




