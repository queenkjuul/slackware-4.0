#include <gtk/gtk.h>
#include <glib.h>
#include <gdk/gdk.h>
#include <gdk/gdkprivate.h>
#include <X11/Xlib.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include "common.h"
#include "make_tree.h"
#include "make_dir_list.h"
#include "pixmaps.h"
#include "rq.h"

struct _file_info
  {
    char *name;
    struct stat info;
  };

typedef struct _file_info fileInfo;

static void
getListDimensions (GtkWidget * list, gint files, gint * rows, gint * columns)
{
  gint hi1, hi2;
  g_return_if_fail (GTK_IS_WIDGET (list));
  g_return_if_fail (rows != NULL);
  g_return_if_fail (columns != NULL);
  switch (dir_list_mode)
    {
    case LARGE_ICONS:
      *columns = get_widget_width (list) / LARGE_ICONS_LIST_COLUMN_WIDTH;
      *rows = files / *columns + 1;
      break;
    case SMALL_ICONS:
      *columns = get_widget_width (list) / SMALL_ICONS_LIST_COLUMN_WIDTH;
      *rows = files / *columns + 1;
      break;
    case LIST_VIEW:
      *rows = get_widget_height (list) / SMALL_ICONS_LIST_COLUMN_HEIGHT - 1;
      *columns = files / *rows + 1;
      break;
    case DETAILED_VIEW:
      break;
    };
}

static void
incrementCoords (gint * x, gint * y, gint max_x, gint max_y)
{
  /* The simpliest way. Faster would be to set x_incr and y_incr and bounding rules */
  switch (dir_list_mode)
    {
    case LARGE_ICONS:
    case SMALL_ICONS:
      (*x)++;
      if (*x >= max_x)
	{
	  *x = 0;
	  (*y)++;
	};
      break;
    case LIST_VIEW:
      (*y)++;
      if (*y >= max_y)
	{
	  *y = 0;
	  (*x)++;
	};
      break;
    default:
      (*x)++;
      if (*x >= max_x)
	{
	  *x = 0;
	  (*y)++;
	};
    };
}

static gchar *
constructLabelText (char *text, gint width, GtkWidget * widget)
{
  GdkFont *sfont;
  gint hgi1, hgi2, hgi3, hgi4;
  gchar *hgc1, *hgc2, *hgc3;
  g_return_val_if_fail (widget != NULL, NULL);
  g_return_val_if_fail (GTK_IS_WIDGET (widget), NULL);
  g_return_val_if_fail (width != 0, NULL);
  sfont = (GdkFont *) (widget->style->font);
  hgi1 = 0;
  hgc1 = g_malloc0 (strlen (text) + 1);
  hgc2 = hgc1;
  while (*text != '\000' && hgi1 < width)
    {
      hgi1 += gdk_char_width (sfont, *text);
      *hgc2++ = *text++;
    };
  if (hgi1 >= width)
    {
      hgc2 -= 3;
      strcpy (hgc2, "...");
    };
  return hgc1;
}

static gint
getIconIndex (fileInfo * file)
{
  /* basic wrapper for future multiicon handler */
  gint hi1;
  g_return_val_if_fail (file != NULL, 1);
  if (S_ISDIR (file->info.st_mode))
    hi1 = FOLDER_LARGE;
  else
    hi1 = FILE_LARGE;
  if (dir_list_mode > LARGE_ICONS)
    hi1 += 2;
  return hi1;
}

static GtkWidget *
createTableItemView (fileInfo * file)
{
  GtkWidget *hGW1, *hGW2, *hGW3;
  gint hgi1, hgi2, hgi3, hgi4;
  gchar *hgc1;
  switch (dir_list_mode)
    {
    case LARGE_ICONS:
      hgi1 = LARGE_ICONS_LIST_COLUMN_WIDTH;
      hgi2 = LARGE_ICONS_LIST_COLUMN_HEIGHT;
      hgi4 = 2;
      hGW1 = gtk_vbox_new (FALSE, 1);
      break;
    case SMALL_ICONS:
      hgi1 = SMALL_ICONS_LIST_COLUMN_WIDTH;
      hgi2 = SMALL_ICONS_LIST_COLUMN_HEIGHT;
      hgi4 = 18;
      hGW1 = gtk_hbox_new (FALSE, 1);
      break;
    case LIST_VIEW:
      hgi1 = SMALL_ICONS_LIST_COLUMN_WIDTH;
      hgi2 = SMALL_ICONS_LIST_COLUMN_HEIGHT;
      hgi4 = 18;
      hGW1 = gtk_hbox_new (FALSE, 1);
      break;
    default:
      hgi1 = SMALL_ICONS_LIST_COLUMN_WIDTH;
      hgi2 = LARGE_ICONS_LIST_COLUMN_HEIGHT;
      hgi4 = 2;
      hGW1 = gtk_hbox_new (FALSE, 1);
      /* Max of two */
      break;
    };
  gtk_widget_set_usize (hGW1, hgi1, hgi2);
  hgi3 = getIconIndex (file);
  hGW2 = gtk_pixmap_new (pixMaps[hgi3], bitMaps[hgi3]);
  gtk_widget_show (hGW2);
  gtk_box_pack_start (GTK_BOX (hGW1), hGW2, FALSE, FALSE, 2);
  hGW3 = gtk_label_new ("");
  gtk_widget_show (hGW3);
  hgc1 = constructLabelText (file->name, hgi1 - hgi4, GTK_WIDGET (hGW3));
  gtk_label_set_text (GTK_LABEL (hGW3), hgc1);
  gtk_box_pack_start (GTK_BOX (hGW1), hGW3, FALSE, FALSE, 0);
  return hGW1;
}

void
sortList (GList * dirInfo)
{
  GList *hpG1, *hpG2, *hpG3;
  gpointer hg1;
  fileInfo *hf1, *hf2;
  hpG1 = g_list_first (dirInfo);
  hpG3 = g_list_last (dirInfo);
  while (hpG1 != hpG3)
    {
      hpG2 = hpG3;
      while (hpG2 != hpG1)
	{
	  hf1 = (fileInfo *) hpG1->data;
	  hf2 = (fileInfo *) hpG2->data;
	  switch (sort_mode)
	    {
	    case SORT_BY_NAME:
	      if (strcmp (hf1->name, hf2->name) > 0)
		{
		  hg1 = hpG1->data;
		  hpG1->data = hpG2->data;
		  hpG2->data = hg1;
		};
	      break;
	    case SORT_BY_TYPE:
	      /* Later */
	      break;
	    case SORT_BY_DATE:
	      /* Later */
	      break;
	    case SORT_BY_SIZE:
	      /* Later */
	      break;
	    };
	  hpG2 = hpG2->prev;
	};
      hpG1 = hpG1->next;
    };
}

GList *
getDirInfo (gchar * dir)
{
  struct dirent *hpd1;
  fileInfo *hf1;
  DIR *hpD1;
  GList *fileList = NULL;
  GList *dirList = NULL;
  gchar *hpg1 = g_malloc (PATH_MAX);
  hpD1 = opendir (dir);
  if (!hpD1)
    return NULL;
  while ((hpd1 = readdir (hpD1)) != NULL)
    {
      /* Preparing full path for stat'ing
         Maybe, would be better to cd to this dir and stat relative
         names instead of absolute ? Maybe, faster ? */
      if (!strcmp (".", hpd1->d_name))
	continue;
      strcpy (hpg1, dir);
      append_slash (hpg1);
      strcat (hpg1, hpd1->d_name);
      hf1 = g_malloc (sizeof (fileInfo));
      hf1->name = g_malloc (strlen (hpd1->d_name) + 1);
      strcpy (hf1->name, hpd1->d_name);
      stat (hpg1, &hf1->info);
      if (!S_ISDIR (hf1->info.st_mode))
	fileList = g_list_append (fileList, hf1);
      else
	dirList = g_list_append (dirList, hf1);
    };
  sortList (fileList);
  sortList (dirList);
  /* Don't know , when (in which version of glib) g_list_concat appears. 
     1.0.6 is safe :). May be, configure must check this and use wrapper ? */
  g_list_concat (dirList, fileList);
  return dirList;
}

void
make_dir_list (char *dir)
{
  gchar *hc1[5];
  gint hi1, hi2, hi3, hi4, hi5;
  struct tm *htm1;
  GList *hGL1, *hGL2;
  GtkTreeItem *hGTI1;
  GtkWidget *hGW1;
  if (IN_MAKE_DIR_LIST != 0)
    return;
  IN_MAKE_DIR_LIST = 1;
  hGL1 = getDirInfo (dir);
  hGL2 = hGL1;
  switch (dir_list_mode)
    {
    case LIST_VIEW:
    case LARGE_ICONS:
    case SMALL_ICONS:
      /* Now */
      g_list_free (GTK_TABLE (main_list)->children);
      GTK_TABLE (main_list)->children = NULL;
      gtk_table_resize (GTK_TABLE (main_list), 1, 1);
      getListDimensions (main_listwin, g_list_length (hGL1), &hi2, &hi1);
      gtk_table_resize (GTK_TABLE (main_list), hi2, hi1);
      /* hi1 - number of columns, hi2 - number of rows */
      hi3 = 0;
      hi4 = 0;
      while (hGL1 != NULL)
	{
	  hGW1 = createTableItemView ((fileInfo *) (hGL1->data));
	  gtk_widget_show (hGW1);
	  gtk_table_attach (GTK_TABLE (main_list), hGW1, hi3, hi3 + 1, hi4, hi4 + 1,
			    GTK_EXPAND | GTK_FILL, 0, 0, 0);
	  hGL1 = hGL1->next;
	  incrementCoords (&hi3, &hi4, hi1, hi2);
	};
      gtk_table_set_col_spacings (GTK_TABLE (main_list), 0);
      gtk_table_set_row_spacings (GTK_TABLE (main_list), 0);
      gtk_widget_show (main_list);
      break;
    case DETAILED_VIEW:
      gtk_clist_clear (GTK_CLIST (main_list));
      gtk_clist_freeze (GTK_CLIST (main_list));
      while (hGL1 != NULL)
	{
	  for (hi1 = 0; hi1 < 5; hi1++)
	    hc1[hi1] = NULL;
	  hi1 = gtk_clist_append (GTK_CLIST (main_list), hc1);
	  hc1[0] = strdup (((fileInfo *) (hGL1->data))->name);
	  hc1[1] = g_malloc (16);
	  snprintf (hc1[1], 15, "%d", ((fileInfo *) (hGL1->data))->info.st_size);
	  htm1 = gmtime (&(((fileInfo *) (hGL1->data))->info.st_atime));
	  hc1[2] = g_malloc (8);
	  snprintf (hc1[2], 7, "%o", ((fileInfo *) (hGL1->data))->info.st_mode);
	  hc1[3] = g_malloc (16);
	  strftime (hc1[3], 15, "%d-%b-%Y", htm1);
	  gtk_clist_set_text (GTK_CLIST (main_list), hi1, 1, hc1[1]);
	  gtk_clist_set_text (GTK_CLIST (main_list), hi1, 2, hc1[2]);
	  gtk_clist_set_text (GTK_CLIST (main_list), hi1, 3, hc1[3]);
	  hi2 = getIconIndex ((fileInfo *) (hGL1->data));
	  gtk_clist_set_pixtext (GTK_CLIST (main_list), hi1, 0, hc1[0], 1, \
				 pixMaps[hi2], bitMaps[hi2]);
	  for (hi1 = 0; hi1 < 4; hi1++)
	    g_free (hc1[hi1]);
	  hGL1 = hGL1->next;
	};
      gtk_clist_thaw (GTK_CLIST (main_list));
      break;
    };
  g_list_free (hGL1);
  IN_MAKE_DIR_LIST = 0;
}

void
create_dir_list (GtkWidget * list)
{
  switch (dir_list_mode)
    {
    case LARGE_ICONS:
    case SMALL_ICONS:
    case LIST_VIEW:
      main_list = gtk_table_new (1, 1, TRUE);
      break;
    case DETAILED_VIEW:
      main_list = gtk_clist_new_with_titles (NUM_OF_TITLES, main_titles);
      gtk_clist_set_column_width (GTK_CLIST (main_list), 0, 150);	/* Name */
      gtk_clist_set_column_width (GTK_CLIST (main_list), 1, 70);	/* Size */
      gtk_clist_set_column_width (GTK_CLIST (main_list), 2, 90);	/* Perms */
      gtk_clist_set_column_width (GTK_CLIST (main_list), 3, 90);	/* Date */
      gtk_clist_column_titles_show (GTK_CLIST (main_list));
      gtk_clist_set_selection_mode (GTK_CLIST (main_list), GTK_SELECTION_BROWSE);
      break;
    };
  gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (main_listwin), main_list);
  putRequest (MAKE_DIR_LIST, (gpointer) & main_dir, NULL);
  gtk_widget_show (main_list);
};
