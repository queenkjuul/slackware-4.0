#ifndef __ITEMFACTORY_H__
#define __ITEMFACTORY_H__

#ifdef __cplusplus
extern "C"
{
#endif				/* __cplusplus */

  void get_main_menu (GtkWidget * window, GtkWidget ** menubar);

#ifdef __cplusplus
}
#endif				/* __cplusplus */

#endif				/* __ITEMFACTORY_H__ */
