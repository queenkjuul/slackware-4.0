#ifndef __TREE_H_
#define __TREE_H_

extern GtkWidget *constructTree (void);
/* Returns root CTree ready for gtk_container_add */

#endif /* __TREE_H_ */
