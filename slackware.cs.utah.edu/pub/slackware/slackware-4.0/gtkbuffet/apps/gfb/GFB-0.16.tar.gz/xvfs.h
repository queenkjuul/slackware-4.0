#ifndef __XVFS_H__
#define __XVFS_H__

typedef enum
  {
    NONE = 0,
    SWAP,
    PROC,
    AFFS,
    EXT2,
    HPFS,
    ISO9660,
    MINIX,
    MSDOS,
    NCPFS,
    NFS,
    SMBFS,
    SYSV,
    UFS,
    VFAT,
    OTHER
  }
FileSystemType;

typedef enum
{
    DEVICE_HD,
    DEVICE_CD,
    DEVICE_FLOPPY,
    DEVICE_REMOVABLE,
    DEVICE_NETWORK,
    DEVICE_TAPE,
    DEVICE_OTHER
} DeviceType;

extern gchar *FileSystemName[];

typedef struct _XVFS XVFS;

struct _XVFS
  {
    FileSystemType type;
    DeviceType devType;
    gboolean mounted;
    gchar *label;
/*
 Allocating it now... Now ,  NOW !!!
 J. Morrison, "When the music's over"
*/
    gchar current_directory[PATH_MAX];
    gchar mount_point[PATH_MAX];
  };

extern gboolean vfsHasSubdirs (XVFS vfsItem);
extern GList *vfsGetSubdirs (XVFS vfsItem);
extern GList *vfsGetXtabInfo (gchar *);
extern XVFS *vfsFindItem(GList *, gchar *);

#endif /* __XVFS_H__ */
