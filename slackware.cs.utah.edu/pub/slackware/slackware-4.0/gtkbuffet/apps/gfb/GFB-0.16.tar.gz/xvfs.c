#ifndef __XVFS_C_
#define __XVFS_C_

#include <gtk/gtk.h>
#include <glib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <mntent.h>
#include <dirent.h>
#include <linux/major.h>
#include "xvfs.h"

#ifdef SCSI_DISK0_MAJOR
#define SCSI_DISK_MAJOR_ SCSI_DISK0_MAJOR 
#else
#define SCSI_DISK_MAJOR_ SCSI_DISK_MAJOR
#endif 

gchar *FileSystemName[] =
{
  "none",
  "swap",
  "proc",
  "affs",
  "ext2",
  "hpfs",
  "iso9660",
  "minix",
  "msdos",
  "ncpfs",
  "nfs",
  "smbfs",
  "sysv",
  "ufs",
  "vfat",
  "other"
};

DeviceType
vfsGetDeviceType(struct stat *sBuf, FileSystemType fsType)
{
    DeviceType devType;
    gint major = sBuf->st_rdev>>8;
    if (S_ISBLK(sBuf->st_mode))
    {
        switch (major)
        {
        case FLOPPY_MAJOR:
            devType=DEVICE_FLOPPY;
            break;
        case IDE0_MAJOR:
        case SCSI_DISK_MAJOR_:
        case XT_DISK_MAJOR:
        case IDE1_MAJOR:
        case IDE2_MAJOR:
        case IDE3_MAJOR:
            devType=DEVICE_HD;
            break;
        case SCSI_CDROM_MAJOR:
        case CDU31A_CDROM_MAJOR:
        case GOLDSTAR_CDROM_MAJOR:
        case OPTICS_CDROM_MAJOR:
        case SANYO_CDROM_MAJOR:
        case MITSUMI_X_CDROM_MAJOR:
        case MITSUMI_CDROM_MAJOR:
        case CDU535_CDROM_MAJOR:
        case MATSUSHITA_CDROM_MAJOR:
        case MATSUSHITA_CDROM2_MAJOR:
        case MATSUSHITA_CDROM3_MAJOR:
        case MATSUSHITA_CDROM4_MAJOR:
        case AZTECH_CDROM_MAJOR:
        case CM206_CDROM_MAJOR:
            devType=DEVICE_CD;
            break;
        };
    }
    else
    if (S_ISCHR(sBuf->st_mode))
    {
        switch (major)
        {
        case SCSI_TAPE_MAJOR:
        case QIC02_TAPE_MAJOR:
        case QIC117_TAPE_MAJOR:
        case IDETAPE_MAJOR:
            devType=DEVICE_TAPE;
            break;
        };
    }
    else
        devType=DEVICE_OTHER;
    return devType;
}

static void
vfsFixDeviceType(XVFS *vfsItem)
{
    /*
     Small routine needed in difficult situations
     */
    if (vfsItem->type == ISO9660) vfsItem->devType = DEVICE_CD;
    else
    if ((vfsItem->type == NFS) || ( vfsItem->type == NCPFS) || (vfsItem->type == SMBFS))
        vfsItem->devType = DEVICE_NETWORK;
}

gboolean
vfsHasSubdirs (XVFS vfsItem)
{
    /*
     We could possibly do a simple call to vfsGetSubdirs() and just check
     for return != NULL, but this could result in increased reaction times on large
     subdirs (fileops must be minimalised :)
     */
  DIR *dir;
  struct dirent *dEnt;
  struct stat sBuf;
  gchar hgc1[PATH_MAX];
  dir = opendir ((char *) vfsItem.current_directory);
  if (!dir) return FALSE;
  while ((dEnt = readdir (dir)) != NULL)
  {
      strcpy((char *)&hgc1, vfsItem.current_directory);
      append_slash((char *)&hgc1);
      strcat((char *)&hgc1, dEnt->d_name);
      stat ((char *)&hgc1, &sBuf);
      if (S_ISDIR (sBuf.st_mode) && (dEnt->d_name[0] != '.'))
	return TRUE;
/*
   "We found them, commander..." (c)"Command&Conquer" by Westwood Studios
*/
    };
  return FALSE;
};

GList *
vfsGetXtabInfo (gchar *tabFile)
{
  /* returns list of mounted filesystems */
  XVFS *vfsItem;
  struct mntent *mntEntry;
  struct stat sBuf;
  GList *hGL1 = NULL;
  gboolean mounted = FALSE;
  FILE *xTab = setmntent (tabFile, "r");
  g_return_val_if_fail (xTab != NULL, NULL);
  if (!strcmp(tabFile,"/etc/mtab")) mounted = TRUE;
  while ((mntEntry = getmntent (xTab)) != NULL)
    {
      vfsItem = g_malloc (sizeof (XVFS));
      vfsItem->mounted = mounted;
      vfsItem->label = NULL;
      /* Just compares predefined FS id strings with real ones */
      for (vfsItem->type = NONE; vfsItem->type < OTHER; vfsItem->type++)
	if (!strcmp (mntEntry->mnt_type, FileSystemName[vfsItem->type]))
            break;
      if (!stat(mntEntry->mnt_fsname, &sBuf))
          vfsItem->devType = vfsGetDeviceType(&sBuf, vfsItem->type);
      vfsFixDeviceType(vfsItem);
      strcpy ((char *) (vfsItem->mount_point), mntEntry->mnt_dir);
      strcpy ((char *) (vfsItem->current_directory), (char *) (vfsItem->mount_point));
      hGL1 = g_list_append (hGL1, (gpointer) vfsItem);
    };
    endmntent (xTab);
  return hGL1;
}


GList *
vfsGetSubdirs (XVFS vfsItem)
{
  DIR *dir;
  struct dirent *dEnt;
  struct stat sBuf;
  GList *hGL1 = NULL;
  XVFS *vfsItem_;
  gchar *hgc1;
  dir = opendir ((char *) vfsItem.current_directory);
  g_return_val_if_fail (dir != NULL, NULL);
  hgc1 = g_malloc0(PATH_MAX);
  while ((dEnt = readdir (dir)) != NULL)
  {
      strcpy(hgc1, vfsItem.current_directory);
      append_slash(hgc1);
      strcat(hgc1, dEnt->d_name);
      stat (hgc1, &sBuf);
      if (S_ISDIR(sBuf.st_mode) && (dEnt->d_name[0] != '.' ))
      {
          vfsItem_ = g_malloc(sizeof(XVFS));
          strcpy(vfsItem_->current_directory, hgc1);
          hGL1 = g_list_append (hGL1, vfsItem_);
      };
  };
  closedir(dir);
  g_free(hgc1);
  return hGL1;
}

XVFS *
vfsFindItem(GList *list, gchar *path)
{
    GList *hGL1;
    g_return_val_if_fail(list != NULL, NULL);
    g_return_val_if_fail(path != NULL, NULL);
    for (hGL1 = list; hGL1 != NULL; hGL1 = hGL1->next)
        if (!strcmp(((XVFS *)hGL1->data)->current_directory, path))
            return hGL1->data;
    return NULL;
}

#endif
/*__XVFS_C_  */
