#ifndef __MAKE_TREE_H__
#define __MAKE_TREE_H__

#ifdef __cplusplus
extern "C"
{
#endif				/* __cplusplus */

  extern int make_root_tree (GtkWidget * clist);
  extern int make_tree (GtkTree *, char *);
  extern void item_expand (GtkTreeItem * item, gpointer data);
  extern GtkWidget *createTreeItemView (char *, int);
  extern void add_fake_subtree (GtkWidget *);
  extern void getFullPath (GtkTreeItem *, char *);
  extern GtkTreeItem *findItemByText (GtkTree *, char *);
  extern GtkTreeItem *expandTreeByPath (char *);
#ifdef __cplusplus
}
#endif				/* __cplusplus */

#endif				/* __MAKE_DIR_LIST_H__ */
