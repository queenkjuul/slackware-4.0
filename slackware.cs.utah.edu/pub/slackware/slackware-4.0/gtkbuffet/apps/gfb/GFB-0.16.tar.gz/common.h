#include <assert.h>

#define CONFIG_FILE "/.gfbrc"
#define NUM_OF_TITLES 4
#define SMALL_ICONS_LIST_COLUMN_WIDTH 128;
#define SMALL_ICONS_LIST_COLUMN_HEIGHT 18;
#define LARGE_ICONS_LIST_COLUMN_WIDTH 128;
#define LARGE_ICONS_LIST_COLUMN_HEIGHT 84;


extern GtkWidget *main_window;
extern GtkWidget *main_vbox;
extern GtkWidget *treelist_vbox;
extern GtkWidget *main_menubar;
extern GtkWidget *main_buttonbar;
extern GtkWidget *main_hpaned;
extern GtkWidget *main_treewin;
extern GtkWidget *main_tree;
extern GtkWidget *main_listwin;
extern GtkWidget *main_list;
extern GtkWidget *main_statusbar;
extern GtkWidget *main_history_box;
extern GtkWidget *toolbox_hbox;
extern GtkWidget *main_toolbox;
extern char main_dir[PATH_MAX];
extern char CurrentTreePath[PATH_MAX];
extern gchar *main_titles[NUM_OF_TITLES];
extern gchar *Labels[];
extern int main_window_usize_x, main_window_usize_y, main_treewin_usize_x,
  main_treewin_usize_y;
extern int dir_list_mode, sort_mode;
extern int IN_ITEM_SELECT, IN_MAKE_DIR_LIST, IN_TREE_EXPAND;


enum
  {
    LARGE_ICONS,
    SMALL_ICONS,
    LIST_VIEW,
    DETAILED_VIEW
  };

enum
  {
    SORT_BY_NAME,
    SORT_BY_TYPE,
    SORT_BY_SIZE,
    SORT_BY_DATE
  };


extern void append_slash (char *);
extern void remove_slash (char *);
extern gint get_widget_width (GtkWidget *);
extern gint get_widget_height (GtkWidget *);
