// -*- C++ -*-
// File: pixmaps.h
//
// Created: Fri Jan  1 19:16:11 1999
//
// $Id: pixmaps.h,v 1.7 1999/02/15 16:58:19 yarick Exp $
//
enum
  {
    TREE_FOLDER_CLOSED,
    TREE_FOLDER_OPEN,
    FILE_LARGE,
    FOLDER_LARGE,
    FILE_SMALL,
    FOLDER_SMALL,
    TOOLBAR_CUT,
    TOOLBAR_COPY,
    TOOLBAR_PASTE,
    TOOLBAR_UPDIR,
    TOOLBAR_DELETE,
    TOOLBAR_OPTIONS,
    WORLD,
    MY_COMPUTER,
    NETWORK,
    MOUNTED,
    AVAILABLE,
    DEV_CDROM,
    DEV_FLOPPY,
    DEV_HD,
    DEV_ZIP,
    PIXMAPS_NUMBER
  };

GdkPixmap *pixMaps[PIXMAPS_NUMBER];
GdkBitmap *bitMaps[PIXMAPS_NUMBER];

extern void createPixmaps (void);
