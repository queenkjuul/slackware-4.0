#ifndef __TREE_C_
#define __TREE_C

/*
 Fully independant tree view module.
 the only thing it requires is the window widget where tree widget will be placed.
 all other fileops must be done through requests and VFS calls.
*/
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <glib.h>
#include <strings.h>
#include <X11/Xlib.h>	/* I feel this will be nesessary for interface tweakings */
#include "common.h"
#include "xvfs.h"
#include "pixmaps.h"
#include "rq.h"
#include "tree.h"

#ifdef __DEBUG__
#include "debug.h"
#endif

gchar *FakeSubTree[] =
{"Fake"};
gchar *zeroString = "";

gint deviceIconIndex[] = {DEV_HD, DEV_CDROM, DEV_FLOPPY, DEV_ZIP, NETWORK, DEV_HD, DEV_HD};
    
/*
 This will be expanded
*/
typedef enum
  {
    NODE_WORLD,			/* All that stuff */
    NODE_LOCAL,			/* My computer                     */
    NODE_NETWORK,		/* Network Neiborghood             */
    NODE_MOUNTED_FSes,		/* Mounted Filesystems             */
    NODE_AVAILABLE_FSes,	/* Available for mounting          */
    NODE_MOUNTPOINT,		/* Mount point for Filesystem      */
    NODE_SUBDIR			/* Directory with possible subdirs */
  }
treeNodeType;

typedef struct
  {
    XVFS vfsInfo;
    treeNodeType nodeType;
    gboolean visible;
  }
treeNode;

GtkCTree *base_tree = NULL;
GtkCTreeNode *WorldNode, *LocalNode, *NetworkNode, *MountedNode, *AvailableNode,
 *HotlistNode;
/*
  Statically allocated for faster access
  */
GList *MountedList, *AvailableList;
     
guint expandHandler, collapseHandler, selectHandler;
/*
 In case of signal blocking
*/

void
sortGList(GList *list)
{
    GList *hGL1, *hGL2, *hGL3, *hGL4;
    XVFS *hX1, *hX2 , *hX3;
    g_return_if_fail(list != NULL);
    hGL4 = g_list_first(list);
    hGL3 = g_list_last(list);
    for (hGL1 = hGL4; hGL1 != hGL3; hGL1 = hGL1->next)
        for (hGL2 = hGL3; hGL2 != hGL1; hGL2 = hGL2->prev)
        {
            hX1 = (XVFS *)hGL1->data;
            hX2 = (XVFS *)hGL2->data;
            if (strcmp(hX1->current_directory, hX2->current_directory) >0 )
            {
                hX3 = hX1;
                hGL1->data = hGL2->data;
                hGL2->data = hX3;
            };
        };
};


static gchar *
getLabelFromPath (gchar * path)
{
  gchar *hgc1, *hgc2, *hgc3;
  if (!strcmp (path, "/"))
    return Labels[5];
  hgc2 = strdup (path);
  remove_slash (hgc2);
  hgc1 = hgc2 + strlen (hgc2) - 1;
  while (*hgc1-- != '/');
  hgc1 = strdup (hgc1 + 2);	/* May be dangerous ! */
  free (hgc2);
  return hgc1;
}

void
fillTheFields (treeNode * node, treeNodeType type, XVFS * vfsInfo, gint * pixindex1, gint * pixindex2)
{
  gboolean mounted, visible;
  gchar *label;
  mounted = visible = TRUE;
  switch (type)
    {
    case NODE_WORLD:
    case NODE_LOCAL:
    case NODE_NETWORK:
    case NODE_MOUNTED_FSes:
    case NODE_AVAILABLE_FSes:
      label = Labels[type - NODE_WORLD];
      *pixindex1 = *pixindex2 = WORLD + (type - NODE_WORLD);
/*
 I don't think that main nodes must have different pixmaps, but you can change this
*/
      break;
    case NODE_MOUNTPOINT:
      label = getLabelFromPath (vfsInfo->current_directory);
      if (vfsInfo->type <= PROC) visible = FALSE;
      *pixindex1 = *pixindex2 = deviceIconIndex[vfsInfo->devType];
      break;
    case NODE_SUBDIR:
      label = getLabelFromPath (vfsInfo->current_directory);
      *pixindex1 = TREE_FOLDER_CLOSED;
      *pixindex2 = TREE_FOLDER_OPEN;
      break;

    };
/*
 Isn't 'politically correct', but it must work
*/
  if (vfsInfo != NULL)
    memcpy (&(node->vfsInfo), vfsInfo, sizeof (XVFS));
  node->vfsInfo.label = label;
  node->nodeType = type;
  node->visible = visible;
}

gboolean
nodeHasSubdirs (treeNode * node)
/*
 Do not know wether this func is really useful. Somebody, point this out for me
*/
{
  switch (node->nodeType)
    {
    case NODE_WORLD:
    case NODE_LOCAL:
    case NODE_MOUNTED_FSes:
      return TRUE;
      break;
    case NODE_NETWORK:
      return FALSE;		/* Will call vfsHasNetworkInterfaces or similar. Later. */
      break;
    case NODE_AVAILABLE_FSes:
      return FALSE;		/* Will call vfsHasAvailableFSes or similar. Later. */
      break;
    case NODE_MOUNTPOINT:
    case NODE_SUBDIR:
      return vfsHasSubdirs (node->vfsInfo);
      break;
    default:
      return FALSE;
      break;
    };
}

void
addFakeChild (GtkCTreeNode * node)
{
  g_return_if_fail (node != NULL);
  gtk_ctree_insert_node (base_tree, node, NULL, &FakeSubTree[0], 1, NULL, NULL, NULL, NULL, FALSE, FALSE);
}

void
gtk_ctree_node_remove_children(GtkCTree *tree, GtkCTreeNode * node)
{
  GtkCTreeNode *hGCTN1;
  GList *hGL1 = NULL;
  g_return_if_fail (tree != NULL);
  g_return_if_fail (node != NULL);
  hGCTN1 = GTK_CTREE_ROW (node)->children;
  if (hGCTN1 == NULL) return;
  for (hGCTN1 = GTK_CTREE_ROW(node)->children; hGCTN1; hGCTN1 = GTK_CTREE_ROW(hGCTN1)->sibling)
      hGL1 = g_list_append(hGL1, hGCTN1);
  gtk_clist_freeze(GTK_CLIST(tree));
  for (;hGL1;hGL1 = hGL1->next)
      gtk_ctree_remove_node(tree, GTK_CTREE_NODE(hGL1->data));
  g_list_free(hGL1);
  gtk_clist_thaw(GTK_CLIST(tree));
}

GtkCTreeNode *
constructTreeNode (GtkCTreeNode * parent, treeNodeType type, XVFS * vfsInfo)
{
  GtkCTreeNode *hGCTN1;
  gint hgi1, hgi2;
  gboolean hasChildren = FALSE;
  treeNode *htN1 = g_malloc0 (sizeof (treeNode));
  fillTheFields (htN1, type, vfsInfo, &hgi1, &hgi2);
  hasChildren = nodeHasSubdirs(htN1);
  if (htN1->visible)
  {
      hasChildren = nodeHasSubdirs(htN1);
      hGCTN1 = gtk_ctree_insert_node (base_tree, parent, NULL, &(htN1->vfsInfo.label), 1,
				      pixMaps[hgi1], bitMaps[hgi1],
				      pixMaps[hgi2], bitMaps[hgi2],
				      !hasChildren, FALSE);
      gtk_ctree_node_set_row_data (base_tree, hGCTN1, (gpointer) htN1);
      if (type<NODE_MOUNTPOINT) return hGCTN1;
      if ( hasChildren ) addFakeChild( hGCTN1 );
      return hGCTN1;
    };
  g_free (htN1);
  return NULL;
}

gint
tree_expand (GtkCTree * tree, GtkCTreeNode * node, gpointer data)
{
    treeNode *node_;
    XVFS *vfsItem, *hXVFS1;
    gchar *hgc1;
    DeviceType devType;
    treeNodeType tnType;
    FileSystemType fsType;
    GList *hGL1 = NULL;
    node_ = gtk_ctree_node_get_row_data (tree, node);
    if (node_->nodeType < NODE_MOUNTPOINT ) return TRUE;
/*
 Is everybody in ?
 Is everybody in ?
 IS EVERYBODY IN ?!
 The ceremony is about to begin ...
 (c) Jim Morrison.
*/
    gtk_clist_freeze(GTK_CLIST(tree));
    gtk_signal_handler_block(GTK_OBJECT(base_tree), collapseHandler);
    gtk_ctree_node_remove_children(tree, node);
    gtk_signal_handler_unblock(GTK_OBJECT(base_tree), collapseHandler);
    hGL1 = vfsGetSubdirs(node_->vfsInfo);
    sortGList( hGL1 );
    for ( ; hGL1 ; hGL1 = hGL1->next)
    {
        vfsItem = (XVFS *)hGL1->data;
        hXVFS1 = vfsFindItem(MountedList, vfsItem->current_directory);
        if ( hXVFS1 )
        {
            devType = hXVFS1->devType;
            tnType = NODE_MOUNTPOINT;
            fsType = hXVFS1->type;
        }
        else
        {
            devType = node_->vfsInfo.devType;
            tnType = NODE_SUBDIR;
            fsType = node_->vfsInfo.type;
        };
        vfsItem->type = fsType;
        vfsItem->mounted = TRUE;
        vfsItem->devType = devType;
        strcpy(vfsItem->mount_point, node_->vfsInfo.mount_point);
        constructTreeNode(node, tnType, vfsItem);
    };
    gtk_clist_thaw(GTK_CLIST(tree));
    g_list_free(g_list_first(hGL1));
    return TRUE;
}

gint
tree_collapse (GtkCTree * tree, GtkCTreeNode * node, gpointer data)
{
  treeNode *node_;
  GtkCTreeNode *hGCTN1;
  node_ = gtk_ctree_node_get_row_data (tree, node);
  if (node_->nodeType < NODE_MOUNTPOINT) return TRUE;
  gtk_ctree_node_remove_children(tree, node);
  addFakeChild(node);
  return TRUE;
}

gint
tree_select_row (GtkCTree * tree, GtkCTreeNode * node, gpointer data)
{
  treeNode *node_;
  node_ = gtk_ctree_node_get_row_data (tree, node);
  if (node_->nodeType < NODE_MOUNTPOINT ) return TRUE;
  putRequest(MAKE_DIR_LIST, node_->vfsInfo.current_directory, NULL);
  return TRUE;

}


GtkWidget *
constructTree ()
{
  GList *hGL1, *hGL2;
  base_tree = GTK_CTREE (gtk_ctree_new (1, 0));
  g_return_val_if_fail (GTK_IS_CTREE (base_tree), NULL);
  expandHandler = gtk_signal_connect (GTK_OBJECT (base_tree), "tree_expand", GTK_SIGNAL_FUNC (tree_expand), NULL);
  collapseHandler = gtk_signal_connect (GTK_OBJECT (base_tree), "tree_collapse", GTK_SIGNAL_FUNC (tree_collapse), NULL);
  selectHandler = gtk_signal_connect (GTK_OBJECT (base_tree), "tree_select_row", GTK_SIGNAL_FUNC (tree_select_row), NULL);
  gtk_ctree_set_line_style (base_tree, GTK_CTREE_LINES_DOTTED);
  WorldNode = constructTreeNode (NULL, NODE_WORLD, NULL);
  LocalNode = constructTreeNode (WorldNode, NODE_LOCAL, NULL);
  NetworkNode = constructTreeNode (WorldNode, NODE_NETWORK, NULL);
  MountedNode = constructTreeNode (LocalNode, NODE_MOUNTED_FSes, NULL);
  AvailableNode = constructTreeNode (LocalNode, NODE_AVAILABLE_FSes, NULL);
  MountedList =  vfsGetXtabInfo ("/etc/mtab");
  AvailableList = vfsGetXtabInfo ("/etc/fstab");
  constructTreeNode(MountedNode, NODE_MOUNTPOINT, vfsFindItem(MountedList, "/"));
  gtk_clist_set_row_height (GTK_CLIST (base_tree), 18);
  return GTK_WIDGET (base_tree);
}



#endif /* __TREE_C_ */
