extern void debug_on (void);
extern void debug_off (void);
extern void debug_out (char *);
extern void dbgprintf (char *,...);
