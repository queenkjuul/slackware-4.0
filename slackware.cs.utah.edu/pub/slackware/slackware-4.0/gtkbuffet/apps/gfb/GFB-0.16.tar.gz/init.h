// -*- C++ -*-
// File: init.h
//
// Created: Tue Dec  8 01:19:43 1998
//
// $Id: init.h,v 1.1.1.1 1999/01/25 18:32:07 yarick Exp $
//
extern void init_rc ();
extern void init_widgets ();
