/* +++Date last modified: 05-Jul-1997 */

/* =======================================================================
   CFG.c       Generic configuration file handler.

   A. Reitsma, Delft, The Netherlands.
   v1.00  94-07-09  Public Domain.
   ---------------------------------------------------------------------- */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <glib.h>
#include "cfg.h"

GList *configParams;

char *
strlwr (char *String)
{
  while (*String)
    tolower (*String++);
};

int
CfgRead (FILE * CfgFile, CfgStrings * CfgInfo)
{
  char Buffer[BUFFERSIZE];
  char *WorkPtr;
  char *CfgName;
  char *CfgData;
  CfgStrings *Cfg;

  if (!fgets (Buffer, BUFFERSIZE, CfgFile))
    return ERR_EOF;
  if (NULL != (WorkPtr = strchr (Buffer, ';')))
    *WorkPtr = '\0';
  else
    WorkPtr = Buffer + strlen (Buffer);

  WorkPtr--;
  while (isspace (*WorkPtr) && WorkPtr >= Buffer)
    *WorkPtr-- = '\0';
  WorkPtr = Buffer;
  while (isspace (*WorkPtr))
    WorkPtr++;
  if (!strlen (WorkPtr))
    return ERR_PARSING;

  CfgName = strtok (WorkPtr, " =");
  if (NULL != CfgName)
    {
      strlwr (CfgName);
      CfgData = strtok (NULL, "");
      while (isspace (*CfgData))
	CfgData++;
      if ('=' == *CfgData)
	CfgData++;
      while (isspace (*CfgData))
	CfgData++;

      CfgInfo->name = strdup (CfgName);
      CfgInfo->data = strdup (CfgData);
      return NO_PROBLEMS;
    }
  return ERR_PARSING;
}

char *
getConfParmValue (char *name)
{
  GList *pointer = configParams;
  CfgStrings *data_ptr = NULL;
  while (pointer != NULL)
    {
      data_ptr = (CfgStrings *) pointer->data;
      if (!data_ptr->name)
	return NULL;
      if (!strcmp (data_ptr->name, name))
	return data_ptr->data;
      pointer = pointer->next;
    };
  return NULL;
};

/* ==== CFG.c end ===================================================== */
