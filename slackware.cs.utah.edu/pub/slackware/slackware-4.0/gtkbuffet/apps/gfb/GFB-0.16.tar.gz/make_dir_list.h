#ifndef __MAKE_DIR_LIST_H__
#define __MAKE_DIR_LIST_H__

#ifdef __cplusplus
extern "C"
{
#endif				/* __cplusplus */


  extern void make_dir_list (char *);
  extern void create_dir_list (GtkWidget *);

#ifdef __cplusplus
}

#endif				/* __cplusplus */

#endif				/* __MAKE_DIR_LIST_H__ */
