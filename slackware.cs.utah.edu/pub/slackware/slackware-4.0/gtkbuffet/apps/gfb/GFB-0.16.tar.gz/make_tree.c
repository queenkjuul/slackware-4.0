#include <gtk/gtk.h>
#include <glib.h>
#include <unistd.h>
#include <dirent.h>
#include <strings.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include "make_dir_list.h"
#include "make_tree.h"
#include "common.h"
#include "pixmaps.h"
#include "rq.h"

char CurrentTreePath[PATH_MAX];

gint
compare_strings (gpointer a, gpointer b)
{
  if ((char *) a == (char *) b)
    return 0;
  if ((char *) a == NULL)
    return -1;
  if ((char *) b == NULL)
    return 1;
  return strcmp ((char *) a, (char *) b);
}

void
getFullPath (GtkTreeItem * item, char *path)
{
  GList *list = g_list_alloc ();
  GList *tmpListRef;
  GtkWidget *itemBox;
  GtkLabel *label;
  GtkTree *tempTree;
  gchar *text, *tempPath;
  GtkTreeItem *tempItem = item;
  int counter;
  tempPath = path;
  *tempPath = '\000';
  do
    {
      itemBox = GTK_WIDGET (gtk_container_children (GTK_CONTAINER (tempItem))->data);
      label = GTK_LABEL (gtk_container_children
			 (GTK_CONTAINER (itemBox))->next->data);
      gtk_label_get (label, &text);
      g_list_append (list, (gpointer) text);
      tempTree = GTK_TREE (GTK_WIDGET (tempItem)->parent);
      if ((void *) tempTree != (void *) main_tree)
	tempItem = GTK_TREE_ITEM (tempTree->tree_owner);
    }
  while ((void *) tempTree != (void *) main_tree);
  list = g_list_reverse (list);
  tmpListRef = list;
  for (counter = 1; counter <= g_list_length (list); counter++)
    {
      if (tmpListRef->data != NULL)
	strcat (tempPath, (char *) tmpListRef->data);
      append_slash (tempPath);
      tmpListRef = tmpListRef->next;
    };
  g_list_free (list);
};

gchar *
getItemText (GtkTreeItem * item)
{
  gchar *tmpStr1, *tmpStr2;
  GtkWidget *itemBox = GTK_WIDGET (gtk_container_children (GTK_CONTAINER (item))->data);
  GtkLabel *itemLabel = GTK_LABEL (gtk_container_children
				   (GTK_CONTAINER (itemBox))->next->data);
  gtk_label_get (itemLabel, &tmpStr1);
  tmpStr2 = g_malloc (strlen (tmpStr1) + 1);
  strcpy (tmpStr2, tmpStr1);
  return tmpStr2;

}

GtkTreeItem *
findItemByText (GtkTree * tree, char *text)
{
  GList *children, *listStart;
  GtkWidget *label;
  GtkTreeItem *currItem;
  char *hc1;
  int notDone = 1;
  children = tree->children;
  listStart = children;
  while ((children) && (notDone))
    {
      currItem = GTK_TREE_ITEM (children->data);
      hc1 = getItemText (currItem);
      notDone = strcmp (hc1, text);
      children = children->next;
      g_free (hc1);
    };
  if (!notDone)
    return currItem;
  else
    {
      debug_out ("Item not found");
      return NULL;
    };
}

gint
findItemPos (GtkTree * tree, GtkTreeItem * item)
{
  gint hi1 = 0;
  GList *hGL1 = tree->children;
  while ((void *) hGL1->data != (void *) item)
    {
      hi1++;
      hGL1 = hGL1->next;
    };
  return hi1;
}

GtkTreeItem *
expandTreeByPath (char *path)
{
  char *hc1, *hc2, *hc3;
  GtkTreeItem *hGTI1;
  GtkTree *hGT1;
  if (IN_TREE_EXPAND != 0)
    return NULL;
  IN_TREE_EXPAND = 1;
  if (!strcmp ((char *) &CurrentTreePath, path))
    {
      IN_TREE_EXPAND = 0;
      return NULL;
    };
  hc1 = path;
  if (*hc1 != '/')
    {
      IN_TREE_EXPAND = 0;
      return NULL;
    };
  hGTI1 = findItemByText (GTK_TREE (main_tree), "/");
  if (!hGTI1)
    {
      debug_out ("Root tree NOT FOUND !");
      IN_TREE_EXPAND = 0;
      return NULL;
    };
  gtk_tree_item_remove_subtree (hGTI1);
  add_fake_subtree (GTK_WIDGET (hGTI1));
  gtk_tree_item_expand (hGTI1);
  hc1++;
  hc2 = g_malloc (strlen (hc1) + 1);
  remove_slash (path);
  while (*hc1 != '\000')
    {
      hc3 = hc2;
      while ((*hc1 != '\000') && (*hc1 != '/'))
	*hc3++ = *hc1++;
      if (*hc1 == '/')
	hc1++;
      *hc3++ = '\000';
      hGT1 = GTK_TREE (GTK_TREE_ITEM_SUBTREE (hGTI1));
      hGTI1 = findItemByText (hGT1, hc2);
      if (hGTI1->subtree != NULL)
	gtk_tree_item_expand (hGTI1);
    };
  g_free (hc2);
  strcpy ((char *) &CurrentTreePath, path);
  putRequest (SELECT_TREE_ITEM, hGT1, (gpointer) findItemPos (hGT1, hGTI1));
  IN_TREE_EXPAND = 0;
  return hGTI1;
}

void
item_expand (GtkTreeItem * item, gpointer data)
{
  gchar *fullPath = g_malloc0 (PATH_MAX);
  GtkTree *subTree = GTK_TREE (gtk_tree_new ());
  getFullPath (item, fullPath);
  gtk_widget_hide (GTK_WIDGET (item));
  gtk_tree_item_remove_subtree (item);
  gtk_tree_item_set_subtree (item, GTK_WIDGET (subTree));
  make_tree (subTree, fullPath);
  gtk_widget_show (GTK_WIDGET (item));
  g_free (fullPath);
  gtk_signal_handler_block_by_data (GTK_OBJECT (item), "MyExpand");
  gtk_tree_item_expand (item);
  gtk_signal_handler_unblock_by_data (GTK_OBJECT (item), "MyExpand");
}

void
item_select (GtkTreeItem * item, gpointer data)
{
  char *path, *tempText;
  GtkWidget *itemBox;
  if (IN_ITEM_SELECT != 0)
    return;
  IN_ITEM_SELECT = 1;
  getFullPath (item, (char *) &main_dir);
  tempText = getItemText (item);
  itemBox = GTK_WIDGET (gtk_container_children (GTK_CONTAINER (item))->data);
  gtk_widget_hide (GTK_WIDGET (item));
  gtk_container_remove (GTK_CONTAINER (item), itemBox);
  gtk_container_add (GTK_CONTAINER (item), createTreeItemView (tempText, 1));
  gtk_widget_show (GTK_WIDGET (item));
  g_free (tempText);
  putRequest (MAKE_DIR_LIST, (char *) &main_dir, NULL);
  IN_ITEM_SELECT = 0;
}

void
item_deselect (GtkTreeItem * item, gpointer data)
{
  char *tempText = getItemText (item);
  GtkWidget *itemBox = GTK_WIDGET (gtk_container_children (GTK_CONTAINER (item))->data);
  gtk_widget_hide (GTK_WIDGET (item));
  gtk_container_remove (GTK_CONTAINER (item), itemBox);
  gtk_container_add (GTK_CONTAINER (item), createTreeItemView (tempText, 0));
  gtk_widget_show (GTK_WIDGET (item));
  g_free (tempText);
}

void
connect_signals (GtkTreeItem * item)
{
  gtk_signal_connect (GTK_OBJECT (item), "expand",
		      GTK_SIGNAL_FUNC (item_expand), "MyExpand");
  gtk_signal_connect (GTK_OBJECT (item), "select",
		      GTK_SIGNAL_FUNC (item_select), "MySelect");
  gtk_signal_connect (GTK_OBJECT (item), "deselect",
		      GTK_SIGNAL_FUNC (item_deselect), "MyDeselect");
}

int
has_subdirs (char *dir)
{
  DIR *dp;
  struct dirent *entry;
  struct stat statbuf;
  char *temp_path = malloc (PATH_MAX);
  if ((dp = opendir (dir)) == NULL)
    {
      free (temp_path);
      return FALSE;
    };
  while ((entry = readdir (dp)) != NULL)
    {
      strncpy (temp_path, dir, PATH_MAX);
      append_slash (temp_path);
      strcat (temp_path, entry->d_name);
      stat (temp_path, &statbuf);
      if (S_ISDIR (statbuf.st_mode))
	{
	  if (strcmp (".", entry->d_name) == 0 ||
	      strcmp ("..", entry->d_name) == 0)
	    continue;
	  closedir (dp);
	  free (temp_path);
	  return TRUE;
	}
    }
  closedir (dp);
  free (temp_path);
  return FALSE;
}

GtkWidget *
createTreeItemView (char *text, int opened)
{
  GtkWidget *label, *pmw, *box;
  int pixmap_index;
  box = gtk_hbox_new (FALSE, 0);
  switch (opened)
    {
    case 0:
      pixmap_index = TREE_FOLDER_CLOSED;
      break;
    case 1:
      pixmap_index = TREE_FOLDER_OPEN;
      break;
    case 2:
      pixmap_index = TREE_FOLDER_CLOSED;
      break;
    };
  pmw = gtk_pixmap_new (pixMaps[pixmap_index],
			bitMaps[pixmap_index]);
  gtk_widget_show (pmw);
  label = gtk_label_new (text);
  gtk_widget_show (label);
  gtk_box_pack_start (GTK_BOX (box), pmw, FALSE, FALSE, 1);
  gtk_box_pack_start (GTK_BOX (box), label, FALSE, FALSE, 1);
  gtk_widget_show (box);
  return box;
}

void
add_fake_subtree (GtkWidget * ti)
{
  GtkWidget *fst = gtk_tree_new ();	//create fake subtree

  gtk_tree_item_set_subtree (GTK_TREE_ITEM (ti), fst);
}

int
make_tree (GtkTree * dirs_tree, char *dir)
{
  GtkWidget *treeitem;
  DIR *temp_dir;
  struct dirent *dir_ent;
  struct stat temp_stat;
  int result_, counter;
  char *temp_path;

  GList *dirList, *listItem;
  char *temp_label;
  temp_path = g_malloc0 (PATH_MAX);
  if ((temp_dir = opendir (dir)) == NULL)
    {
      free (temp_path);
      return 1;
    };
  dirList = g_list_alloc ();
  while ((dir_ent = readdir (temp_dir)) != NULL)
    {
      strcpy (temp_path, dir);
      append_slash (temp_path);
      strcat (temp_path, dir_ent->d_name);
      if (stat (temp_path, &temp_stat) != -1)
	{
	  if (!S_ISDIR (temp_stat.st_mode))
	    continue;
	  if (strchr (dir_ent->d_name, '.') ==
	      dir_ent->d_name)
	    continue;
	  temp_label = g_malloc0 (strlen (dir_ent->d_name) + 1);
	  strncpy (temp_label, dir_ent->d_name, strlen (dir_ent->d_name));
	  g_list_insert_sorted (dirList,
		   (gpointer) temp_label, (GCompareFunc) & compare_strings);
	};
    };
  listItem = dirList;
  for (counter = 1; counter <= g_list_length (dirList); counter++)
    {
      if (!listItem->data)
	{
	  listItem = listItem->next;
	  continue;
	};
      treeitem = gtk_tree_item_new ();
      gtk_container_add (GTK_CONTAINER (treeitem),
			 createTreeItemView ((char *) (listItem->data), 0));
      strcpy (temp_path, dir);
      append_slash (temp_path);
      strcat (temp_path, listItem->data);
      gtk_tree_append (dirs_tree, treeitem);
      if (has_subdirs (temp_path))
	add_fake_subtree (treeitem);
      connect_signals (GTK_TREE_ITEM (treeitem));
      gtk_widget_show (treeitem);
      listItem = listItem->next;
    };
  g_list_free (dirList);
  free (temp_path);
  return 0;
};

int
make_root_tree (GtkWidget * tree)
{
  GtkWidget *root;		//Root tree

  root = gtk_tree_item_new ();
  gtk_container_add (GTK_CONTAINER (root),
		     createTreeItemView ("/", FALSE));
  gtk_tree_append (GTK_TREE (tree), root);
  connect_signals (GTK_TREE_ITEM (root));
  gtk_widget_show (root);
  add_fake_subtree (root);
}
