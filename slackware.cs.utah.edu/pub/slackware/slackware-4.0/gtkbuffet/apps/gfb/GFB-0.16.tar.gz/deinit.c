// -*- C++ -*-
// File: deinit.c
//
// Created: Tue Dec  8 01:27:03 1998
//
// $Id: deinit.c,v 1.3 1999/02/14 20:00:06 yarick Exp $
//
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <gtk/gtk.h>
#include <glib.h>
#include "common.h"
#include "cfg.h"
#include "deinit.h"
#include "debug.h"

void
save_rc ()
{
  /* proto for options saving in .rc (on exit etc.) */
  char *CfgFileName = g_malloc (PATH_MAX);
  FILE *CfgFile;
  char *tmpStr1;
  int tmpInt1;
  strcpy (CfgFileName, getenv ("HOME"));
  strcat (CfgFileName, CONFIG_FILE);
  if ((CfgFile = fopen (CfgFileName, "w")) == NULL)
    {
      perror ("Error writing ~/.gfbrc");
      g_free (CfgFileName);
      return;
    };
  tmpInt1 = main_window->allocation.width;
  fprintf (CfgFile, "main_window_usize_x = %d\n", tmpInt1);
  tmpInt1 = main_window->allocation.height;
  fprintf (CfgFile, "main_window_usize_y = %d\n", tmpInt1);
  tmpInt1 = GTK_HPANED (main_hpaned)->paned.child1_size;
  fprintf (CfgFile, "main_treewin_usize_x = %d\n", tmpInt1);
  fprintf (CfgFile, "dir_list_mode = %d\n", dir_list_mode);
  fprintf (CfgFile, "sort_mode = %d\n", sort_mode);
  fclose (CfgFile);
};

void
main_exit_func ()
{
  deInitQueue ();
  save_rc ();
  debug_off ();
  gtk_main_quit ();
};
