#include <assert.h>
#include <rpc/types.h>		/* For HOSTNAME stuff. */
#include <gtk/gtk.h>
#include <strings.h>
#include "common.h"

GtkWidget *main_window;
GtkWidget *treelist_vbox;
GtkWidget *main_vbox;
GtkWidget *main_menubar;
GtkWidget *main_buttonbar;
GtkWidget *main_hpaned;
GtkWidget *main_treewin;
GtkWidget *main_tree;
GtkWidget *main_listwin;
GtkWidget *main_list;
GtkWidget *main_statusbar;
GtkWidget *main_history_box;
GtkWidget *toolbox_hbox;
GtkWidget *main_toolbox;
char main_dir[PATH_MAX];
gchar *main_titles[] =
{"Filename", "Size", "Permissions", "Date"};
int main_window_usize_x = 500;
int main_window_usize_y = 400;
int main_treewin_usize_x = 300;
int main_treewin_usize_y = 400;
int dir_list_mode = LARGE_ICONS;
int sort_mode = SORT_BY_NAME;
int IN_ITEM_SELECT = 0;
int IN_MAKE_DIR_LIST = 0;
int IN_TREE_EXPAND = 0;

void
append_slash (gchar * path)
{
  int endptr;
  if (path == NULL)
    return;
  endptr = strlen (path);
  if ((char) *(path + endptr - 1) != '/')
    strcat (path, "/");
}

void
remove_slash (gchar * path)
{
  int endptr;
  if (path == NULL)
    return;
  endptr = strlen (path) - 1;
  if (((char) *(path + endptr) == '/') && (endptr != 0))
    *(path + endptr) = '\000';
}

gchar *
skip_slashes (gchar * path)
{
  while (*(path++) == '/');
  return --path;
}

gint
get_widget_width (GtkWidget * widget)
{
  g_return_val_if_fail (widget != NULL, 0);
  g_return_val_if_fail (GTK_IS_WIDGET (widget), 0);

  if (widget->allocation.width >= 2)
    return widget->allocation.width;
  else
    return 0;
}

gint
get_widget_height (GtkWidget * widget)
{
  g_return_val_if_fail (widget != NULL, 0);
  g_return_val_if_fail (GTK_IS_WIDGET (widget), 0);

  if (widget->allocation.width >= 2)
    return widget->allocation.height;
  else
    return 0;
}
