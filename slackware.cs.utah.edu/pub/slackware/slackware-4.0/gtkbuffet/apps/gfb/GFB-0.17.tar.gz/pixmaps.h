// -*- C++ -*-
// File: pixmaps.h
//
// Created: Fri Jan  1 19:16:11 1999
//
// $Id: pixmaps.h,v 1.8 1999/03/13 21:24:26 Steven Exp $
//
enum
  {
    NODE_WORLD_PIX,
    NODE_LOCALHOST_PIX,
    NODE_NETWORK_PIX,
    TREE_FOLDER_CLOSED,
    TREE_FOLDER_OPEN,
    FILE_LARGE,
    FOLDER_LARGE,
    FILE_SMALL,
    FOLDER_SMALL,
    TOOLBAR_CUT,
    TOOLBAR_COPY,
    TOOLBAR_PASTE,
    TOOLBAR_UPDIR,
    TOOLBAR_DELETE,
    TOOLBAR_OPTIONS,
    MOUNTED,
    AVAILABLE,
    DEV_CDROM,
    DEV_FLOPPY,
    DEV_HD,
    DEV_ZIP,
    PIXMAPS_NUMBER
  };

GdkPixmap *pixMaps[PIXMAPS_NUMBER];
GdkBitmap *bitMaps[PIXMAPS_NUMBER];

extern void createPixmaps (void);
