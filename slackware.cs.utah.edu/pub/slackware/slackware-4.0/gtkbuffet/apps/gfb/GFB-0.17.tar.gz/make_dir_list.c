/* make_dir_list.c -- Filelist panel handling routines.

 * Copyright (C) 1999 Steve Hill <sjhill@plutonium.net>
 *                    Yarick Rastrigin <yarick@relex.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <X11/Xlib.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <stdio.h>
#include <time.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkprivate.h>
#include <glib.h>
#include "common.h"
#include "tree.h"
#include "make_dir_list.h"
#include "pixmaps.h"
#include "rq.h"

struct _file_info
  {
    char *name;
    struct stat info;
    gboolean selected;
  };
typedef struct _file_info fileInfo;

static gint num_of_rows, num_of_columns;
static GList *lists = NULL;
GList *current_directory = NULL;
static gchar *data_id = "Filelist";


gint find_list_num(GtkList *list)
{
    GList *hGL1; gint hi1 = 0;
    g_return_val_if_fail(GTK_IS_LIST(list), -1);
    for (hGL1 = lists; hGL1->data != list; hGL1 = hGL1->next)
        hi1++;
    return hi1;
}

GtkList *find_list(gint pos)
{
    GList *hGL1 = lists;
    while ((pos-- > 0) && (hGL1))
        hGL1 = hGL1->next;
    return GTK_LIST(hGL1->data);
}

gint get_item_pos(GtkList *list, GtkWidget *child)
{
    gint row = 0;
    gint col = 0;
    gint pos = 0;
    row = gtk_list_child_position(list, child);
    col = find_list_num(list);
    switch (dir_list_mode)
    {
    case LARGE_ICONS:
    case SMALL_ICONS:
        pos = (row * num_of_columns) + col;
        break;
    case LIST_VIEW:
        pos = (col * num_of_rows) + row;
        break;
    };
    return pos;
}

gboolean ctrl_pressed(gchar *keys)
{
    gchar hgc1, hgc2;
    /* Fixme. Someone probably will write single-line expression */
    hgc1 = *(keys+4) & 0x20;
    hgc2 = *(keys+13) & 0x20;
    if ((hgc1 != 0) || (hgc2 != 0)) return TRUE;
    return FALSE;
}

gboolean shift_pressed(gchar *keys)
{
    gchar hgc1, hgc2;
    /* Fixme. Someone probably will write single-line expression */
    hgc1 = *(keys+6) & 0x04;
    hgc2 = *(keys+7) & 0x40;
    if ((hgc1 != 0) || (hgc2 != 0)) return TRUE;
    return FALSE;
}

GList *find_pre_selected(gint pos)
{
    GList *hGL1 = g_list_nth(current_directory, pos);
    while ((hGL1 != current_directory) && ((fileInfo *)hGL1->data)->selected == FALSE)
           hGL1 = hGL1->prev;
    if ((hGL1 == current_directory) && ((fileInfo *)hGL1->data)->selected == FALSE)
        return NULL;
    return hGL1;
}

GList *find_post_selected(gint pos)
{
    GList *hGL1 = g_list_nth(current_directory, pos);
    while ((hGL1->next != NULL) && ((fileInfo *)hGL1->data)->selected == FALSE)
           hGL1 = hGL1->next;
    if ((hGL1->next == NULL) && ((fileInfo *)hGL1->data)->selected == FALSE)
        return NULL;
    return hGL1;
}

void select_region(GList *start, GList *finish)
{
    while (start->prev != finish)
    {
        ((fileInfo *)start->data)->selected = TRUE;
        start = start->next;
    }
}

void select_child(GtkList *list, GtkWidget *child)
{
    gint pos, prev_pos, last_pos;
    GList *hGL1;
    fileInfo *hfI1 = NULL;
    gchar *keys = g_malloc0(32);
    XQueryKeymap(gdk_display, keys);
    pos = get_item_pos(list, child);
    hfI1 = (fileInfo *)g_list_nth_data(current_directory, pos);
    if (ctrl_pressed(keys))
        hfI1->selected = TRUE;
    else
        if (shift_pressed(keys))
        {
            hGL1 = find_pre_selected(pos);
            if (hGL1 == NULL)
            {
                /* So we have no prev item selected */
                hGL1 = find_post_selected(pos);
                if (hGL1 != NULL)
                    select_region(g_list_nth(current_directory, pos), hGL1);
            }
            else
                    select_region(hGL1, g_list_nth(current_directory, pos) );
        }
        else
        {
            for (hGL1 = current_directory; hGL1; hGL1 = hGL1->next)
                ((fileInfo *)(hGL1->data))->selected = FALSE;
            hfI1->selected = TRUE;
        };
   g_free(keys);
   putRequest(SELECT_ITEMS, NULL, NULL);
}

void unselect_child(GtkList *list, GtkWidget *child)
{
    gint pos;
    GList *hGL1;
    fileInfo *hfI1 = NULL;
    gchar *keys = g_malloc0(32);
    XQueryKeymap(gdk_display, keys);
    pos = get_item_pos(list, child);
    hfI1 = (fileInfo *)g_list_nth_data(current_directory, pos);
    if (ctrl_pressed(keys))
        hfI1->selected = FALSE;
    else
    {
        for (hGL1 = current_directory;hGL1; hGL1 = hGL1->next)
            ((fileInfo *)(hGL1->data))->selected = FALSE;
        hfI1->selected = TRUE;
    };
    g_free(keys);
    putRequest(SELECT_ITEMS, NULL, NULL);
}

static void
get_list_dimensions (GtkWidget * list, gint files, gint * rows, gint * columns)
{
  gint hi1;
  g_return_if_fail (GTK_IS_WIDGET (list));
  g_return_if_fail (rows != NULL);
  g_return_if_fail (columns != NULL);
  switch (dir_list_mode)
    {
    case LARGE_ICONS:
      *columns = get_widget_width (list) / LARGE_ICONS_LIST_COLUMN_WIDTH;
      *rows = files / *columns;
      break;
    case SMALL_ICONS:
      *columns = get_widget_width (list) / SMALL_ICONS_LIST_COLUMN_WIDTH;
      *rows = files / *columns;
      break;
    case LIST_VIEW:
      /* Someone tell me, why this construction gives an error during compile
           *rows = (get_widget_height(list)/SMALL_ICONS_LIST_COLUMN_HEIGHT) - 1;
      */
      hi1 = get_widget_height(list)/SMALL_ICONS_LIST_COLUMN_HEIGHT;
      *rows = hi1 - 1;
      *columns = files / *rows + 1;
      break;
    case DETAILED_VIEW:
      break;
    };
}

static void
increment_coords (gint * x, gint * y, gint max_x, gint max_y)
{
  /* The simpliest way. Faster would be to set x_incr and y_incr and bounding rules */
  switch (dir_list_mode)
    {
    case LARGE_ICONS:
    case SMALL_ICONS:
      (*x)++;
      if (*x >= max_x)
	{
	  *x = 0;
	  (*y)++;
	};
      break;
    case LIST_VIEW:
      (*y)++;
      if (*y >= max_y)
	{
	  *y = 0;
	  (*x)++;
	};
      break;
    default:
      (*x)++;
      if (*x >= max_x)
	{
	  *x = 0;
	  (*y)++;
	};
    };
}

void block_select_handlers()
{
   GList *hGL1;
   for (hGL1 = lists;hGL1; hGL1 = hGL1->next)
   {
       gtk_signal_handler_block_by_func(GTK_OBJECT(hGL1->data),
                                        GTK_SIGNAL_FUNC(select_child),
                                        data_id);
       gtk_signal_handler_block_by_func(GTK_OBJECT(hGL1->data),
                                        GTK_SIGNAL_FUNC(unselect_child),
                                        data_id);

   };
}

void unblock_select_handlers()
{
   GList *hGL1;
   for (hGL1 = lists;hGL1; hGL1 = hGL1->next)
   {
       gtk_signal_handler_unblock_by_func(GTK_OBJECT(hGL1->data),
                                          GTK_SIGNAL_FUNC(select_child),
                                          data_id);
       gtk_signal_handler_unblock_by_func(GTK_OBJECT(hGL1->data),
                                          GTK_SIGNAL_FUNC(unselect_child),
                                          data_id);
   }
}

void select_items()
{
    gint row = 0;
    gint col = 0;
    GList *hGL1 = current_directory;
    GtkList *hGTL1;
    while (hGL1 != NULL)
    {
        hGTL1 = g_list_nth_data(lists, col);
        if (((fileInfo *)(hGL1->data))->selected == TRUE)
            gtk_list_select_item(hGTL1, row);
        else
            gtk_list_unselect_item(hGTL1, row);
        increment_coords(&col, &row, num_of_columns, num_of_rows);
        hGL1 = hGL1->next;
    };
}


static gchar *
constructLabelText (char *text, gint width, GtkWidget * widget)
{
  GdkFont *sfont;
  gint hgi1;
  gchar *hgc1, *hgc2;
  g_return_val_if_fail (widget != NULL, NULL);
  g_return_val_if_fail (GTK_IS_WIDGET (widget), NULL);
  g_return_val_if_fail (width != 0, NULL);
  sfont = (GdkFont *) (widget->style->font);
  hgi1 = 0;
  hgc1 = g_malloc0 (strlen (text) + 1);
  hgc2 = hgc1;
  while (*text != '\000' && hgi1 < width)
    {
      hgi1 += gdk_char_width (sfont, *text);
      *hgc2++ = *text++;
    };
  if (hgi1 >= width)
    {
      hgc2 -= 3;
      strcpy (hgc2, "...");
    };
  return hgc1;
}

static gint
getIconIndex (fileInfo * file)
{
  /* basic wrapper for future multiicon handler */
  gint hi1;
  g_return_val_if_fail (file != NULL, 1);
  if (S_ISDIR (file->info.st_mode))
    hi1 = FOLDER_LARGE;
  else
    hi1 = FILE_LARGE;
  if (dir_list_mode > LARGE_ICONS)
    hi1 += 2;
  return hi1;
}

static GtkWidget *
create_table_item_view (fileInfo * file)
{
  GtkWidget *hGW1, *hGW2, *hGW3;
  gint hgi1, hgi2, hgi3, hgi4;
  gchar *hgc1;
  switch (dir_list_mode)
    {
    case LARGE_ICONS:
      hgi1 = LARGE_ICONS_LIST_COLUMN_WIDTH;
      hgi2 = LARGE_ICONS_LIST_COLUMN_HEIGHT;
      hgi4 = 2;
      hGW1 = gtk_vbox_new (FALSE, 1);
      break;
    case SMALL_ICONS:
      hgi1 = SMALL_ICONS_LIST_COLUMN_WIDTH;
      hgi2 = SMALL_ICONS_LIST_COLUMN_HEIGHT;
      hgi4 = 18;
      hGW1 = gtk_hbox_new (FALSE, 1);
      break;
    case LIST_VIEW:
      hgi1 = SMALL_ICONS_LIST_COLUMN_WIDTH;
      hgi2 = SMALL_ICONS_LIST_COLUMN_HEIGHT;
      hgi4 = 18;
      hGW1 = gtk_hbox_new (FALSE, 1);
      break;
    default:
      hgi1 = SMALL_ICONS_LIST_COLUMN_WIDTH;
      hgi2 = LARGE_ICONS_LIST_COLUMN_HEIGHT;
      hgi4 = 2;
      hGW1 = gtk_hbox_new (FALSE, 1);
      /* Max of two */
      break;
    };
  gtk_widget_set_usize (hGW1, hgi1, hgi2);
  hgi3 = getIconIndex (file);
  hGW2 = gtk_pixmap_new (pixMaps[hgi3], bitMaps[hgi3]);
  gtk_widget_show (hGW2);
  gtk_box_pack_start (GTK_BOX (hGW1), hGW2, FALSE, FALSE, 2);
  hGW3 = gtk_label_new ("");
  gtk_widget_show (hGW3);
  hgc1 = constructLabelText (file->name, hgi1 - hgi4, GTK_WIDGET (hGW3));
  gtk_label_set_text (GTK_LABEL (hGW3), hgc1);
  gtk_box_pack_start (GTK_BOX (hGW1), hGW3, FALSE, FALSE, 0);
  return hGW1;
}

void
sortList (GList * dirInfo)
{
  GList *hpG1, *hpG2, *hpG3;
  gpointer hg1;
  fileInfo *hf1, *hf2;
  hpG1 = g_list_first (dirInfo);
  hpG3 = g_list_last (dirInfo);
  while (hpG1 != hpG3)
    {
      hpG2 = hpG3;
      while (hpG2 != hpG1)
	{
	  hf1 = (fileInfo *) hpG1->data;
	  hf2 = (fileInfo *) hpG2->data;
	  switch (sort_mode)
	    {
	    case SORT_BY_NAME:
	      if (strcmp (hf1->name, hf2->name) > 0)
		{
		  hg1 = hpG1->data;
		  hpG1->data = hpG2->data;
		  hpG2->data = hg1;
		};
	      break;
	    case SORT_BY_TYPE:
	      /* Later */
	      break;
	    case SORT_BY_DATE:
	      /* Later */
	      break;
	    case SORT_BY_SIZE:
	      /* Later */
	      break;
	    };
	  hpG2 = hpG2->prev;
	};
      hpG1 = hpG1->next;
    };
}

GList *
getDirInfo (gchar * dir)
{
  struct dirent *hpd1;
  fileInfo *hf1;
  DIR *hpD1;
  GList *fileList = NULL;
  GList *dirList = NULL;
  gchar *hpg1 = g_malloc (PATH_MAX);
  hpD1 = opendir (dir);
  if (!hpD1)
    return NULL;
  while ((hpd1 = readdir (hpD1)) != NULL)
    {
      /* Preparing full path for stat'ing
         Maybe, would be better to cd to this dir and stat relative
         names instead of absolute ? Maybe, faster ? */
      if (!strcmp (".", hpd1->d_name))
	continue;
      strcpy (hpg1, dir);
      append_slash (hpg1);
      strcat (hpg1, hpd1->d_name);
      hf1 = g_malloc (sizeof (fileInfo));
      /* Setting filename */
      hf1->name = g_malloc (strlen (hpd1->d_name) + 1);
      strcpy (hf1->name, hpd1->d_name);
      stat (hpg1, &hf1->info);
      hf1->selected = FALSE;
      if (!S_ISDIR (hf1->info.st_mode))
          fileList = g_list_append (fileList, hf1);
      else
          dirList = g_list_append (dirList, hf1);
    };
  sortList (fileList);
  sortList (dirList);
  g_list_concat (dirList, fileList);
  return dirList;
}

void
make_dir_list (char *dir)
{
  gchar *hc1[5];
  gint hi1, hi2, hi3, hi4;
  struct tm *htm1;
  GList *hGL1, *hGL2;
  GtkWidget *hGW1;
  GtkList *hGTL1;
  GtkListItem *hGLI1;
  
/* Non-reentrant function */
  if (IN_MAKE_DIR_LIST != 0)
    return;
/* Setting lock */
  IN_MAKE_DIR_LIST = 1;
/* Freeing prev dir list, if exists */
  for (hGL1 = current_directory;hGL1 != NULL; hGL1 = hGL1->next)
      if (hGL1->data)
          g_free(hGL1->data);
  g_list_free(current_directory);
  current_directory = getDirInfo (dir);
  hGL1 = current_directory;
  switch (dir_list_mode)
    {
    case LIST_VIEW:
    case LARGE_ICONS:
    case SMALL_ICONS:
      /* Deleting old lists, if any */
      while (lists != NULL)
	{
	  if (lists->data != NULL)
	    gtk_widget_destroy (lists->data);
	  lists = lists->next;
	};
      get_list_dimensions (main_listwin, g_list_length (hGL1), &num_of_rows, &num_of_columns);
      /* Creating list of lists */
      for (hi3 = 0; hi3 < num_of_columns; hi3++)
      {
          hGW1 = gtk_list_new();
          gtk_list_set_selection_mode(GTK_LIST(hGW1), GTK_SELECTION_MULTIPLE);
          lists = g_list_append (lists, hGW1);
      };
      /* hi3 - column, hi4 - row */
      hi3 = 0; hi4 = 0;
      while (hGL1 != NULL)
      {
          /* Creating pixmap + text*/
          hGW1 = create_table_item_view ((fileInfo *) (hGL1->data));
          gtk_widget_show (hGW1);
          /* Creating list item */
          hGLI1 = GTK_LIST_ITEM(gtk_list_item_new());
          /* Inserting item view into item*/
          gtk_container_add(GTK_CONTAINER(hGLI1), hGW1);
          gtk_widget_show(GTK_WIDGET(hGLI1));
          /* Retrieving list to add item */
          hGTL1 = GTK_LIST(find_list( hi3 ));
          hGL2 = g_list_alloc();
          hGL2->data = hGLI1;
          gtk_list_append_items(hGTL1, hGL2);
          hGL1 = hGL1->next;
          increment_coords (&hi3, &hi4, num_of_columns, num_of_rows);
      };
      for (hGL1 = g_list_first(lists);hGL1 != NULL; hGL1 = hGL1->next)
      {
          gtk_widget_show(GTK_WIDGET(hGL1->data));
          gtk_signal_connect(GTK_OBJECT(hGL1->data), "select_child",
                            GTK_SIGNAL_FUNC(select_child), data_id);
          gtk_signal_connect(GTK_OBJECT(hGL1->data), "unselect_child",
                            GTK_SIGNAL_FUNC(unselect_child), data_id);
          gtk_box_pack_start(GTK_BOX(main_list), hGL1->data, TRUE, TRUE, 0);
      };
      gtk_widget_show (main_list);
      break;
    case DETAILED_VIEW:
        gtk_clist_clear (GTK_CLIST (main_list));
        gtk_clist_freeze (GTK_CLIST (main_list));
        while (hGL1 != NULL)
        {
            for (hi1 = 0; hi1 < 5; hi1++)
                hc1[hi1] = NULL;
            hi1 = gtk_clist_append (GTK_CLIST (main_list), hc1);
            hc1[0] = strdup (((fileInfo *) (hGL1->data))->name);
            hc1[1] = g_malloc (16);
            snprintf (hc1[1], 15, "%d", ((fileInfo *) (hGL1->data))->info.st_size);
            htm1 = gmtime (&(((fileInfo *) (hGL1->data))->info.st_atime));
            hc1[2] = g_malloc (8);
            snprintf (hc1[2], 7, "%o", ((fileInfo *) (hGL1->data))->info.st_mode);
            hc1[3] = g_malloc (16);
            strftime (hc1[3], 15, "%d-%b-%Y", htm1);
            gtk_clist_set_text (GTK_CLIST (main_list), hi1, 1, hc1[1]);
            gtk_clist_set_text (GTK_CLIST (main_list), hi1, 2, hc1[2]);
            gtk_clist_set_text (GTK_CLIST (main_list), hi1, 3, hc1[3]);
            hi2 = getIconIndex ((fileInfo *) (hGL1->data));
            gtk_clist_set_pixtext (GTK_CLIST (main_list), hi1, 0, hc1[0], 1, \
                                   pixMaps[hi2], bitMaps[hi2]);
            for (hi1 = 0; hi1 < 4; hi1++)
                g_free (hc1[hi1]);
            hGL1 = hGL1->next;
        };
        gtk_clist_thaw (GTK_CLIST (main_list));
        break;
    };
    IN_MAKE_DIR_LIST = 0;
}

void
create_dir_list (GtkWidget * list)
{
  main_list = gtk_hbox_new (TRUE, 0);
  switch (dir_list_mode)
    {
    case DETAILED_VIEW:
      num_of_columns = 1;
      lists = g_list_append (lists,gtk_clist_new (NUM_OF_TITLES));
      gtk_clist_set_column_width (GTK_CLIST (lists->data), 0, 150);	/* Name */
      gtk_clist_set_column_width (GTK_CLIST (lists->data), 1, 70);	/* Size */
      gtk_clist_set_column_width (GTK_CLIST (lists->data), 2, 90);	/* Perms */
      gtk_clist_set_column_width (GTK_CLIST (lists->data), 3, 90);	/* Date */
      gtk_clist_column_titles_show (GTK_CLIST (lists->data));
      gtk_clist_set_selection_mode (GTK_CLIST (lists->data), GTK_SELECTION_BROWSE);
      gtk_widget_show (lists->data);
      gtk_box_pack_start (GTK_BOX(main_list), GTK_WIDGET (lists->data), TRUE, TRUE, 0);
      break;
    };
  gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (main_listwin), main_list);
  putRequest (MAKE_DIR_LIST, (gpointer) & main_dir, NULL);
  gtk_widget_show (main_list);
};
