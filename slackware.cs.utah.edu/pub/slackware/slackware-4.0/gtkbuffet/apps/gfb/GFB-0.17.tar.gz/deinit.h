// -*- C++ -*-
// File: deinit.h
//
// Created: Tue Dec  8 01:25:39 1998
//
// $Id: deinit.h,v 1.1.1.1 1999/01/25 18:32:07 yarick Exp $
//
extern void save_rc ();
extern void main_exit_func ();
