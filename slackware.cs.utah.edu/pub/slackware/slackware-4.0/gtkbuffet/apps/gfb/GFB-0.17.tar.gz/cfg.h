/* +++Date last modified: 05-Jul-1997 */

/* =======================================================================
   CFG.h       Configuration file handler.
   A. Reitsma, Delft, The Netherlands.
   v1.00  94-07-09  Public Domain.
   ---------------------------------------------------------------------- */
#define LINE_LEN_MAX    128	/* actual max line length  */
#define BUFFERSIZE      LINE_LEN_MAX +2		/* ... including \n and \0 */
enum RetVal
  {
    NO_PROBLEMS,
    ERR_FOPEN,
    ERR_EOF,
    ERR_MEM,
    ERR_PARSING
  };

struct _CfgStrings
  {
    char *name;
    char *data;
  };

typedef struct _CfgStrings CfgStrings;
extern GList *configParams;

extern int CfgRead (FILE *, CfgStrings *);
extern char *getConfParmValue (char *);


/* ==== CFG.h end ===================================================== */
