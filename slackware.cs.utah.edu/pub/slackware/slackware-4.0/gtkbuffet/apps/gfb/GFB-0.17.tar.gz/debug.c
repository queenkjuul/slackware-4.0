#define DEBUG

#include <signal.h>
#include <stdio.h>
#include <stdarg.h>
#include "debug.h"

#define debug_file "debug.output"

struct sigaction new_11, new_4;
FILE *debug_fil;
void
sigsegv (int arg)
{
  debug_out (" *** SIGSEGV. Check memory access *** ");
  debug_off ();
  abort ();
};
void
sigill (int arg)
{
  debug_out (" *** SIGILL. Check execution flow ***");
  debug_off ();
  abort ();
};
void
debug_on ()
{
#ifdef __DEBUG__
  debug_fil = fopen (debug_file, "w");
  new_11.sa_handler = &sigsegv;
  new_11.sa_flags = SA_ONESHOT;
  if (sigaction (SIGSEGV, &new_11, NULL))
    {
      debug_out ("Error installing SIGSEGV handler");
      fclose (debug_fil);
      abort ();
    };
  new_4.sa_handler = &sigill;
  new_4.sa_flags = SA_ONESHOT;
  if (sigaction (SIGILL, &new_4, NULL))
    {
      debug_out ("Error installing SIGILL handler");
      fclose (debug_fil);
      abort ();
    };
  debug_out ("Started debugging");
#endif
};
void
debug_off ()
{
#ifdef __DEBUG__
  new_11.sa_handler = SIG_DFL;
  new_4.sa_handler = SIG_DFL;
  sigaction (SIGSEGV, &new_11, NULL);
  sigaction (SIGILL, &new_4, NULL);
  debug_out ("Stopped debugging");
  fclose (debug_fil);
#endif
};
void
debug_out (char *s)
{
#ifdef __DEBUG__
  fprintf (debug_fil, "%s\n", s);
//  fprintf( stderr, "%s\n", s);
#endif
};
void
dbgprintf (char *format,...)
{
#ifdef __DEBUG__
  va_list vl;
  va_start (vl, format);
  vfprintf (debug_fil, format, vl);
//  vfprintf( stderr, format, vl );
  va_end (vl);
#endif
};
#undef DEBUG
