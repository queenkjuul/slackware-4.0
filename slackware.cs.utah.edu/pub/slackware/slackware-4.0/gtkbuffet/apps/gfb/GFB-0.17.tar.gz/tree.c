/* tree.h -- creates directory tree and handles the GUI filesystem interface.

 * Copyright (C) 1999 Yarick Rastrigin <yarick@relex.ru>
 *                    Steve Hill <sjhill@plutonium.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <strings.h>

#include <glib.h>
#include <gdk/gdk.h>
#include <gtk/gtk.h>
#include "common.h"
#include "gvfs.h"
#include "pixmaps.h"
#include "rq.h"
#include "tree.h"

#ifdef __DEBUG__
#include "debug.h"
#endif

typedef enum
  {
    NODE_WORLD,			/* Base node for entire tree */
    NODE_LOCALHOST,		/* Local Host Node           */
    NODE_NETWORK,		/* Network Node              */
    NODE_HOTLIST,		/* Hotlist Node              */
    NODE_FILESYSTEM,		/* Virtual Filesystem Node   */
    NODE_DIR			/* Directory Node            */
  }
TreeNodeType;

typedef struct
  {
    GVFS vfsInfo;
    TreeNodeType node_type;
    gpointer data;
  }
TreeNode;

static GtkCTree *base_tree = NULL;
static GtkCTreeNode *world_node, *localhost_node, *network_node, *hotlist_node;
static guint collapse_handler, expand_handler, select_handler;
static GList *MountedList;
static gchar *last_path;

static GtkCTreeNode *construct_tree_node (GtkCTreeNode * parent,
					  TreeNodeType type, GVFS * vfsInfo);
static gint tree_collapse (GtkCTree * tree, GtkCTreeNode * node, gpointer data);
static gint tree_expand (GtkCTree * tree, GtkCTreeNode * node, gpointer data);
static gint tree_select_row (GtkCTree * tree, GtkCTreeNode * node,
			     gpointer data);

GtkWidget *
construct_tree (void)
{
  /* Create the base tree. */
  base_tree = GTK_CTREE (gtk_ctree_new (1, 0));
  g_return_val_if_fail (GTK_IS_CTREE (base_tree), NULL);
  gtk_ctree_set_line_style (base_tree, GTK_CTREE_LINES_DOTTED);
  gtk_clist_set_row_height (GTK_CLIST (base_tree), 18);

  /* Connect the signal handlers. */
  collapse_handler = gtk_signal_connect (GTK_OBJECT (base_tree),
		    "tree_collapse", GTK_SIGNAL_FUNC (tree_collapse), NULL);
  expand_handler = gtk_signal_connect (GTK_OBJECT (base_tree),
			"tree_expand", GTK_SIGNAL_FUNC (tree_expand), NULL);
  select_handler = gtk_signal_connect (GTK_OBJECT (base_tree),
		"tree_select_row", GTK_SIGNAL_FUNC (tree_select_row), NULL);

  /* Create primary container nodes. */
  world_node = construct_tree_node (NULL, NODE_WORLD, NULL);
  localhost_node = construct_tree_node (world_node, NODE_LOCALHOST, NULL);
  network_node = construct_tree_node (world_node, NODE_NETWORK, NULL);

  /* Construct node for root filesystem. */
  MountedList = vfsGetXtabInfo ("/etc/mtab");
  construct_tree_node (localhost_node, NODE_FILESYSTEM, vfsFindItem (MountedList, "/"));

  /* Initialize the last path expanded. */
  last_path = g_malloc0 (PATH_MAX);

  /* Return the tree object. */
  return GTK_WIDGET (base_tree);
}

void
sortGList (GList * list)
{
  GList *hGL1, *hGL2, *hGL3, *hGL4;
  GVFS *hX1, *hX2, *hX3;
  g_return_if_fail (list != NULL);
  hGL4 = g_list_first (list);
  hGL3 = g_list_last (list);
  for (hGL1 = hGL4; hGL1 != hGL3; hGL1 = hGL1->next)
    for (hGL2 = hGL3; hGL2 != hGL1; hGL2 = hGL2->prev)
      {
	hX1 = (GVFS *) hGL1->data;
	hX2 = (GVFS *) hGL2->data;
	if (strcmp (hX1->current_directory, hX2->current_directory) > 0)
	  {
	    hX3 = hX1;
	    hGL1->data = hGL2->data;
	    hGL2->data = hX3;
	  };
      };
};

static gchar *
getLabelFromPath (gchar * path)
{
  gchar *hgc1, *hgc2;
  if (!strcmp (path, "/"))
    return "/";
  hgc2 = g_strdup (path);
  remove_slash (hgc2);
  hgc1 = hgc2 + strlen (hgc2) - 1;
  while (*hgc1-- != '/');
  hgc1 = strdup (hgc1 + 2);	/* May be dangerous ! */
  g_free (hgc2);
  return hgc1;
}

void
fill_the_fields (TreeNode * node, TreeNodeType type, GVFS * vfsInfo, gint * pixindex1, gint * pixindex2)
{
  gchar *label;

  switch (type)
    {
    case NODE_WORLD:
      label = "World";
      *pixindex1 = *pixindex2 = NODE_WORLD_PIX;
      break;

    case NODE_LOCALHOST:
      label = LOCAL_HOSTNAME;
      *pixindex1 = *pixindex2 = NODE_LOCALHOST_PIX;
      break;

    case NODE_NETWORK:
      label = "Network";
      *pixindex1 = *pixindex2 = NODE_NETWORK_PIX;
      break;

    case NODE_FILESYSTEM:
      label = getLabelFromPath (vfsInfo->current_directory);
      *pixindex1 = *pixindex2 = DEV_HD;
      break;

    case NODE_DIR:
      label = getLabelFromPath (vfsInfo->current_directory);
      *pixindex1 = TREE_FOLDER_CLOSED;
      *pixindex2 = TREE_FOLDER_OPEN;
      break;
    case NODE_HOTLIST:
      break;
    };
/*
   Isn't 'politically correct', but it must work
 */
  if (vfsInfo != NULL)
    memcpy (&(node->vfsInfo), vfsInfo, sizeof (GVFS));
  node->vfsInfo.label = label;
  node->node_type = type;
}

gboolean
nodeHasSubdirs (TreeNode * node)
/*
   Do not know wether this func is really useful. Somebody, point this out for me
 */
{
  switch (node->node_type)
    {
    case NODE_WORLD:
    case NODE_LOCALHOST:
      return TRUE;
      break;
    case NODE_NETWORK:
      return FALSE;		/* Will call vfsHasNetworkInterfaces or similar. Later. */
      break;
    case NODE_FILESYSTEM:
    case NODE_DIR:
      return vfsHasSubdirs (node->vfsInfo);
      break;
    default:
      return FALSE;
      break;
    };
}

void
add_empty_child (GtkCTreeNode * node)
{
  g_return_if_fail (node != NULL);
  gtk_ctree_insert_node (base_tree, node, NULL, NULL, 1, NULL, NULL,
			 NULL, NULL, FALSE, FALSE);
}

void
gtk_ctree_node_remove_children (GtkCTree * tree, GtkCTreeNode * node)
{
  GtkCTreeNode *hGCTN1;
  GList *hGL1 = NULL;
  g_return_if_fail (tree != NULL);
  g_return_if_fail (node != NULL);
  hGCTN1 = GTK_CTREE_ROW (node)->children;
  if (hGCTN1 == NULL)
    return;
  for (hGCTN1 = GTK_CTREE_ROW (node)->children; hGCTN1; hGCTN1 = GTK_CTREE_ROW (hGCTN1)->sibling)
    hGL1 = g_list_append (hGL1, hGCTN1);
  gtk_clist_freeze (GTK_CLIST (tree));
  for (; hGL1; hGL1 = hGL1->next)
    gtk_ctree_remove_node (tree, GTK_CTREE_NODE (hGL1->data));
  g_list_free (hGL1);
  gtk_clist_thaw (GTK_CLIST (tree));
}

GtkCTreeNode *
construct_tree_node (GtkCTreeNode * parent, TreeNodeType type, GVFS * vfsInfo)
{
  GtkCTreeNode *hGCTN1;
  gint hgi1, hgi2;
  gboolean hasChildren;
  TreeNode *htN1;

  hasChildren = FALSE;
  htN1 = (TreeNode *) g_malloc0 (sizeof (TreeNode));

  fill_the_fields (htN1, type, vfsInfo, &hgi1, &hgi2);
  hasChildren = nodeHasSubdirs (htN1);
  hGCTN1 = gtk_ctree_insert_node (base_tree, parent, NULL,
				  &(htN1->vfsInfo.label), 1,
				  pixMaps[hgi1], bitMaps[hgi1],
				  pixMaps[hgi2], bitMaps[hgi2],
				  !hasChildren, FALSE);
  gtk_ctree_node_set_row_data (base_tree, hGCTN1, (gpointer) htN1);
  if (type < NODE_FILESYSTEM)
    return hGCTN1;
  if (hasChildren)
    add_empty_child (hGCTN1);
  return hGCTN1;
}

static gint
tree_expand (GtkCTree * tree, GtkCTreeNode * node, gpointer data)
{
  TreeNode *node_;
  GVFS *vfsItem, *hGVFS1;
  DeviceType dev_type;
  TreeNodeType tnType;
  FileSystemType fs_type;
  GdkCursor *normal_cursor, *clock_cursor;
  GdkWindowAttr *winAttr;
  GList *hGL1 = NULL;
  node_ = gtk_ctree_node_get_row_data (tree, node);
  if (node_->node_type < NODE_FILESYSTEM)
    return TRUE;
/*
   Is everybody in ?
   Is everybody in ?
   IS EVERYBODY IN ?!
   The ceremony is about to begin ...
   (c) Jim Morrison.
 */
  gdk_window_get_user_data (GTK_WIDGET (main_window)->window, (gpointer) & winAttr);
  normal_cursor = winAttr->cursor;
  clock_cursor = gdk_cursor_new (GDK_WATCH);
  gdk_window_set_cursor (GTK_WIDGET (main_window)->window, clock_cursor);
  gtk_signal_handler_block (GTK_OBJECT (base_tree), collapse_handler);
  gtk_ctree_node_remove_children (tree, node);
  gtk_signal_handler_unblock (GTK_OBJECT (base_tree), collapse_handler);
  gtk_clist_freeze (GTK_CLIST (tree));
  hGL1 = vfsGetSubdirs (node_->vfsInfo);
  sortGList (hGL1);
  for (; hGL1; hGL1 = hGL1->next)
    {
      vfsItem = (GVFS *) hGL1->data;
      hGVFS1 = vfsFindItem (MountedList, vfsItem->current_directory);
      if (hGVFS1)
	{
	  dev_type = hGVFS1->dev_type;
	  tnType = NODE_FILESYSTEM;
	  fs_type = hGVFS1->fs_type;
	}
      else
	{
	  dev_type = node_->vfsInfo.dev_type;
	  tnType = NODE_DIR;
	  fs_type = node_->vfsInfo.fs_type;
	};
      vfsItem->fs_type = fs_type;
      vfsItem->dev_type = dev_type;
      vfsItem->mount_point = node_->vfsInfo.mount_point;
      construct_tree_node (node, tnType, vfsItem);
    };
  gtk_clist_thaw (GTK_CLIST (tree));
  g_list_free (g_list_first (hGL1));
  gdk_window_set_cursor (GTK_WIDGET (main_window)->window, normal_cursor);
  return TRUE;
}

static gint
tree_collapse (GtkCTree * tree, GtkCTreeNode * node, gpointer data)
{
  TreeNode *node_;
  node_ = gtk_ctree_node_get_row_data (tree, node);
  if (node_->node_type < NODE_FILESYSTEM)
    return TRUE;
  gtk_ctree_node_remove_children (tree, node);
  add_empty_child (node);
  return TRUE;
}

static gint
tree_select_row (GtkCTree * tree, GtkCTreeNode * node, gpointer data)
{
  TreeNode *node_;
  node_ = gtk_ctree_node_get_row_data (tree, node);
  if (node_->node_type < NODE_FILESYSTEM)
    return TRUE;
  putRequest (MAKE_DIR_LIST, node_->vfsInfo.current_directory, NULL);
  return TRUE;
}

GList *
buildDirsList (gchar * path)
{
  GList *hGL1 = NULL;
  gchar *hgc1 = strdup (path);
  gchar *hgc2, *hgc3;
  hgc1 = skip_slashes (hgc1);
  /* Ready for parsing */
  while (*hgc1 != '\000')
    {
      hgc3 = hgc1;
      hgc1 = strchr (hgc1, '/');
      *(hgc1++) = '\000';
      hgc2 = strdup (hgc3);
      hGL1 = g_list_append (hGL1, hgc2);
      hgc1 = skip_slashes (hgc1);
    };
  return hGL1;
}

void
expand_tree_by_path (gchar * new_path)
{
  GList *hGL1;
  gchar *path = strdup (new_path);
  GtkCTreeNode *hGCTN1, *hGCTN2, *hGCTN3;
  gchar *hgc1;
  g_return_if_fail (new_path != NULL);
  if (*path != '/')
    {
      gchar *full_path = g_malloc (PATH_MAX);
      strcpy (full_path, (char *) &main_dir);
      append_slash (full_path);
      strcat (full_path, path);
      append_slash (full_path);
      expand_tree_by_path (full_path);
      g_free (full_path);
      return;
    };
  append_slash (path);
  if (!strcmp (path, last_path))
    return;
  gtk_clist_freeze (GTK_CLIST (base_tree));
  hGL1 = buildDirsList (path);
  if (GTK_CTREE_ROW (world_node)->expanded == 0)
    gtk_ctree_expand (base_tree, world_node);

  if (GTK_CTREE_ROW (localhost_node)->expanded == 0)
    gtk_ctree_expand (base_tree, localhost_node);

  hGCTN1 = GTK_CTREE_ROW (localhost_node)->children;
  if (GTK_CTREE_ROW (hGCTN1)->expanded == 1)
    gtk_ctree_collapse (base_tree, hGCTN1);
  gtk_ctree_expand (base_tree, hGCTN1);
  while (hGL1 != NULL)
    {
      for (hGCTN2 = GTK_CTREE_ROW (hGCTN1)->children; \
	   gtk_ctree_is_ancestor (base_tree, hGCTN1, hGCTN2); \
	   hGCTN2 = GTK_CTREE_ROW (hGCTN2)->sibling)
	{
	  gtk_ctree_node_get_pixtext (base_tree, hGCTN2, 0, &hgc1, NULL, NULL, NULL);
	  if (!strcmp (hgc1, hGL1->data))
	    hGCTN3 = hGCTN2;
	  else if (GTK_CTREE_ROW (hGCTN2)->expanded == 1)
	    gtk_ctree_collapse (base_tree, hGCTN2);
	};
      if (GTK_CTREE_ROW (hGCTN3)->expanded == 1)
	gtk_ctree_collapse (base_tree, hGCTN3);
      gtk_ctree_expand (base_tree, hGCTN3);
      hGCTN1 = hGCTN3;
      hGL1 = hGL1->next;
    };
  gtk_signal_handler_block (GTK_OBJECT (base_tree), select_handler);
  gtk_ctree_select (base_tree, hGCTN1);
  gtk_signal_handler_unblock (GTK_OBJECT (base_tree), select_handler);
  strcpy (last_path, path);
  gtk_clist_thaw (GTK_CLIST (base_tree));
};
