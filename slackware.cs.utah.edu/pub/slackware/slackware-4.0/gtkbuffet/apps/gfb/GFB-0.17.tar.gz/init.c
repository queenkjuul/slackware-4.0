// -*- C++ -*-
// File: init.c
//
// Created: Tue Dec  8 01:18:13 1998
//
// $Id: init.c,v 1.19 1999/03/17 16:12:56 yarick Exp $
//
#include <gtk/gtk.h>
#include <glib.h>
#include <strings.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "common.h"
#ifndef MAXHOSTNAMELEN
#include <rpc/types.h>
#endif
#include "itemfactory.h"
#include "filebrowser.h"
#include "make_dir_list.h"
#include "tree.h"
#include "history_box.h"
#include "debug.h"
#include "cfg.h"
#include "init.h"
#include "deinit.h"
#include "pixmaps.h"
#include "rq.h"
#include "gvfs.h"
#include "mount_list.h"

void
init_rc ()
{
  //proto for .rc file parsing func
  char *CfgFileName = g_malloc (PATH_MAX);
  FILE *CfgFile;
  CfgStrings *CfgParm;
  char *tmpStr1;
//, *hostname;
  int tmpInt1;
  strcpy (CfgFileName, getenv ("HOME"));
  strcat (CfgFileName, CONFIG_FILE);
  if ((CfgFile = fopen (CfgFileName, "r")) == NULL)
    {
      perror ("Error opening ~/.gfbrc");
      g_free (CfgFileName);
      return;
    };
  do
    {
      CfgParm = g_malloc (sizeof (CfgStrings));
      CfgParm->name = NULL;
      CfgParm->data = NULL;
      configParams = g_list_append (configParams, (gpointer) CfgParm);
    }
  while (!CfgRead (CfgFile, CfgParm));
  g_free (CfgFileName);
  fclose (CfgFile);
  tmpStr1 = getConfParmValue ("main_window_usize_x");
  if (tmpStr1 != NULL)
    tmpInt1 = atoi (tmpStr1);
  if (tmpInt1 != 0)
    main_window_usize_x = tmpInt1;
  tmpStr1 = getConfParmValue ("main_window_usize_y");
  if (tmpStr1 != NULL)
    tmpInt1 = atoi (tmpStr1);
  if (tmpInt1 != 0)
    main_window_usize_y = tmpInt1;
  tmpStr1 = getConfParmValue ("main_treewin_usize_x");
  if (tmpStr1 != NULL)
    tmpInt1 = atoi (tmpStr1);
  if (tmpInt1 != 0)
    main_treewin_usize_x = tmpInt1;
  tmpStr1 = getConfParmValue ("main_treewin_usize_y");
  if (tmpStr1 != NULL)
    tmpInt1 = atoi (tmpStr1);
  if (tmpInt1 != 0)
    main_treewin_usize_y = tmpInt1;
  tmpStr1 = getConfParmValue ("dir_list_mode");
  if (tmpStr1 != NULL)
    tmpInt1 = atoi (tmpStr1);
  dir_list_mode = tmpInt1;
  tmpStr1 = getConfParmValue ("sort_mode");
  if (tmpStr1 != NULL)
    tmpInt1 = atoi (tmpStr1);
  sort_mode = tmpInt1;
}

void
create_toolbtns (void)
{
  GtkWidget *pm;
  GtkStyle *style;
  style = gtk_widget_get_style (main_window);
  pm = gtk_pixmap_new (pixMaps[TOOLBAR_UPDIR], bitMaps[TOOLBAR_UPDIR]);
  gtk_widget_show (pm);
  gtk_toolbar_append_space (GTK_TOOLBAR (main_toolbox));
  gtk_toolbar_append_item (GTK_TOOLBAR (main_toolbox), "Up",
			   "Up one level", "Private", pm, NULL, NULL);
  gtk_toolbar_append_space (GTK_TOOLBAR (main_toolbox));
  pm = gtk_pixmap_new (pixMaps[TOOLBAR_CUT], bitMaps[TOOLBAR_CUT]);
  gtk_widget_show (pm);
  gtk_toolbar_append_item (GTK_TOOLBAR (main_toolbox), "Cut",
			   "Cut selected file(s)", "Private", pm, NULL,
			   NULL);
  pm = gtk_pixmap_new (pixMaps[TOOLBAR_COPY], bitMaps[TOOLBAR_COPY]);
  gtk_widget_show (pm);
  gtk_toolbar_append_item (GTK_TOOLBAR (main_toolbox), "Copy",
			   "Copy selected file(s)", "Private", pm, NULL,
			   NULL);
  pm = gtk_pixmap_new (pixMaps[TOOLBAR_PASTE], bitMaps[TOOLBAR_PASTE]);
  gtk_widget_show (pm);
  gtk_toolbar_append_item (GTK_TOOLBAR (main_toolbox), "Paste",
			   "Paste selected file(s)", "Private", pm, NULL,
			   NULL);
  gtk_toolbar_append_space (GTK_TOOLBAR (main_toolbox));
  pm = gtk_pixmap_new (pixMaps[TOOLBAR_DELETE], bitMaps[TOOLBAR_DELETE]);
  gtk_widget_show (pm);
  gtk_toolbar_append_item (GTK_TOOLBAR (main_toolbox), "Delete",
			   "Delete selected file(s)", "Private", pm, NULL,
			   NULL);
  pm = gtk_pixmap_new (pixMaps[TOOLBAR_OPTIONS],
		       bitMaps[TOOLBAR_OPTIONS]);
  gtk_widget_show (pm);
  gtk_toolbar_append_item (GTK_TOOLBAR (main_toolbox), "Options",
			   "Options", "Private", pm, NULL,
			   NULL);

}

void
construct_toolbox ()
{
// constructing toolbox (dir and buttons)

  toolbox_hbox = gtk_hbox_new (FALSE, 10);
  gtk_widget_set_usize (GTK_WIDGET (toolbox_hbox), 400, 30);
  main_history_box = history_box_new ();
  gtk_widget_show (main_history_box);
  gtk_box_pack_start (GTK_BOX (toolbox_hbox), main_history_box, TRUE, TRUE, 0);
  main_toolbox = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL,
				  GTK_TOOLBAR_ICONS);
  create_toolbtns ();
  gtk_box_pack_start (GTK_BOX (toolbox_hbox), main_toolbox, TRUE,
		      TRUE, 0);
  gtk_widget_show (main_toolbox);
}

void
init_widgets ()
{
//func for widgets init (size, pos, lastdir, etc. ) 
  strcpy (CurrentTreePath, "/");
  initQueue ();
  main_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_usize (GTK_WIDGET (main_window),
			main_window_usize_x, main_window_usize_y);

  gtk_signal_connect (GTK_OBJECT (main_window), "destroy",
		      GTK_SIGNAL_FUNC (main_exit_func), NULL);
  gtk_window_set_title (GTK_WINDOW (main_window), "GTK File Browser");
  gtk_widget_show (main_window);

  createPixmaps ();

  main_vbox = gtk_vbox_new (FALSE, 0);
  treelist_vbox = gtk_vbox_new (FALSE, 0);

  get_main_menu (main_window, &main_menubar);
  gtk_widget_show (main_menubar);

  main_listwin = gtk_scrolled_window_new (NULL, NULL);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (main_listwin),
				GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

  main_treewin = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_usize (main_treewin, main_treewin_usize_x, 1);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (main_treewin),
				GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_widget_show (main_treewin);
  main_tree = construct_tree ();
  gtk_widget_show (main_tree);
  gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (main_treewin), main_tree);

  main_hpaned = gtk_hpaned_new ();

  gtk_paned_add1 (GTK_PANED (main_hpaned), main_treewin);
  gtk_widget_show (main_treewin);
  gtk_paned_add2 (GTK_PANED (main_hpaned), main_listwin);
  create_dir_list (main_list);
  gtk_widget_show (main_listwin);

  gtk_widget_show (main_hpaned);

  main_statusbar = gtk_statusbar_new ();
  gtk_widget_show (main_statusbar);

  gtk_box_pack_start (GTK_BOX (treelist_vbox), main_hpaned, TRUE, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (treelist_vbox), main_statusbar, FALSE, FALSE, 0);
  construct_toolbox ();
  gtk_box_pack_start (GTK_BOX (main_vbox), main_menubar, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox), toolbox_hbox, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox), treelist_vbox, TRUE, TRUE, 0);
  gtk_container_add (GTK_CONTAINER (main_window), main_vbox);
  gtk_widget_show (treelist_vbox);
  gtk_widget_show (toolbox_hbox);
  gtk_widget_show (main_vbox);
  putRequest (EXPAND_TREE, main_dir, NULL);
}

void
init_filesystem (void)
{
  /* Get the local hostname. */
  if ((gethostname (LOCAL_HOSTNAME, MAXHOSTNAMELEN) != 0) &&
      (getdomainname (LOCAL_HOSTNAME, MAXHOSTNAMELEN) != 0))
    strcpy (LOCAL_HOSTNAME, "LocalHost");

  /* Build the local fileystem mount list. */
  if (build_mount_list () == 0)
    exit (1);

  /* Build the SMB share list. */

  /* Initialize the virtual filesystem layer. */
  if (gvfs_initialize () == 0)
    exit (1);
}

void
gfb_init (void)
{
  /* Initialize the filesystem data. */
  init_filesystem ();

  /* Load and initialize resources and configuration. */
  init_rc ();

  /* Create GUI objects and hook up events. */
  init_widgets ();
}
