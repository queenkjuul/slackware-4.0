/* gvfs.h -- The virtual filesystem layer interface.

 * Copyright (C) 1999 Steve Hill <sjhill@plutonium.net>
 *                    Yarick Rastrigin <yarick@relex.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef __GVFS_H__
#define __GVFS_H__

typedef enum
  {
    NONE,
    AFFS,
    EXT2,
    HPFS,
    ISO9660,
    MINIX,
    MSDOS,
    NCPFS,
    NFS,
    SMBFS,
    SYSV,
    UFS,
    VFAT,
    OTHER
  }
FileSystemType;

typedef enum
  {
    DEVICE_HD,
    DEVICE_CD,
    DEVICE_FLOPPY,
    DEVICE_NETWORK,
    DEVICE_OTHER
  }
DeviceType;

extern gchar *FileSystemName[];

typedef struct _GVFS GVFS;

struct _GVFS
  {
    GVFS *next;
    gchar *mount_point;
    gchar *device_name;
    gboolean read_only;
    FileSystemType fs_type;
    DeviceType dev_type;

    void *(*opendir) (GVFS * gvfs, gchar * dirname);
    void *(*readdir) (void *gvfs_info);
    int (*closedir) (void *gvfs_info);


    gchar *label;
    gchar current_directory[PATH_MAX];
  };

/* Other filesystems. */
extern GVFS gvfs_local_fs_ops;

gboolean vfsHasSubdirs (GVFS vfsItem);
GList *vfsGetSubdirs (GVFS vfsItem);
GList *vfsGetXtabInfo (gchar *);
GVFS *vfsFindItem (GList *, gchar *);

/* Initializes the virtual filesystem layer. */
guint gvfs_initialize (void);

/* Shutdown the virtual filesystem layer. */
void gvfs_shutdown (void);

/* Check to see if directory exists. */
gboolean gvfs_dir_exist (gchar * path);

/* Returns the current directory. */
gchar *gvfs_get_current_dir (void);

#endif /* __GVFS_H__ */
