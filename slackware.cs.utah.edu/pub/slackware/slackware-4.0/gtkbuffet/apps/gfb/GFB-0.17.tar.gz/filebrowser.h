#ifndef __FILEBROWSER_H__
#define __FILEBROWSER_H__

#ifdef __cplusplus
extern "C"
{
#endif				/* __cplusplus */

  void file_quit_cmd_callback (GtkWidget * widget, gpointer data);

#ifdef __cplusplus
}
#endif				/* __cplusplus */

#endif				/* __FILEBROWSER_H__ */
