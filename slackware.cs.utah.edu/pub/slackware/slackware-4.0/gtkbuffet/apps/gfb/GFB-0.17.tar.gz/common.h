#ifndef __CONFIG_H_
#define __CONFIG_H_

#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN 64
#endif
/*
 Sorry for incorrect solution, but
 #include <rpc/types.h>
 generates lots of warnings
 about redefinitions of TRUE, FALSE and some other symbols.
 Libc guys can't even think about someone (glib, for example) could or will
 redefine this :)
*/

#define CONFIG_FILE "/.gfbrc"
#define NUM_OF_TITLES 4
#define SMALL_ICONS_LIST_COLUMN_WIDTH 128;
#define SMALL_ICONS_LIST_COLUMN_HEIGHT 18;
#define LARGE_ICONS_LIST_COLUMN_WIDTH 128;
#define LARGE_ICONS_LIST_COLUMN_HEIGHT 84;

gchar LOCAL_HOSTNAME [MAXHOSTNAMELEN];

extern GtkWidget *main_window;
extern GtkWidget *main_vbox;
extern GtkWidget *treelist_vbox;
extern GtkWidget *main_menubar;
extern GtkWidget *main_buttonbar;
extern GtkWidget *main_hpaned;
extern GtkWidget *main_treewin;
extern GtkWidget *main_tree;
extern GtkWidget *main_listwin;
extern GtkWidget *main_list;
extern GtkWidget *main_statusbar;
extern GtkWidget *main_history_box;
extern GtkWidget *toolbox_hbox;
extern GtkWidget *main_toolbox;
extern char main_dir[PATH_MAX];
char CurrentTreePath[PATH_MAX];
extern gchar *main_titles[NUM_OF_TITLES];
extern int main_window_usize_x, main_window_usize_y, main_treewin_usize_x,
  main_treewin_usize_y;
extern int dir_list_mode, sort_mode;
extern int IN_ITEM_SELECT, IN_MAKE_DIR_LIST, IN_TREE_EXPAND;


enum
  {
    LARGE_ICONS,
    SMALL_ICONS,
    LIST_VIEW,
    DETAILED_VIEW
  };

enum
  {
    SORT_BY_NAME,
    SORT_BY_TYPE,
    SORT_BY_SIZE,
    SORT_BY_DATE
  };


extern void append_slash (gchar *);
extern void remove_slash (gchar *);
extern gchar *skip_slashes (gchar *);
extern gint get_widget_width (GtkWidget *);
extern gint get_widget_height (GtkWidget *);

#endif /* __CONFIG_H_ */
