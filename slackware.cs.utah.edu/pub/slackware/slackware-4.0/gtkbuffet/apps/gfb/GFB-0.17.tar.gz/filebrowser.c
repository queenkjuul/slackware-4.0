#include <unistd.h>
#include <gtk/gtk.h>
#include <strings.h>

#include "common.h"
#include "itemfactory.h"
#include "filebrowser.h"
#include "make_dir_list.h"
#include "tree.h"
#include "history_box.h"
#include "debug.h"
#include "init.h"
#include "deinit.h"

int
main (int argc, char *argv[])
{

  gtk_init (&argc, &argv);
  debug_on ();
  getcwd (main_dir, PATH_MAX);
  gfb_init ();
  gtk_widget_show (main_window);
  gtk_main ();
  main_exit_func ();
  return 0;

}

void
file_quit_cmd_callback (GtkWidget * widget, gpointer data)
{
  g_print ("%s\n", (char *) data);
  gtk_exit (0);
}
