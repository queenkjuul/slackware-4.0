#ifndef __MAKE_DIR_LIST_H__
#define __MAKE_DIR_LIST_H__

#ifdef __cplusplus
extern "C"
{
#endif				/* __cplusplus */

  extern GList *current_directory;
  extern void make_dir_list (char *);
  extern void create_dir_list (GtkWidget *);
  extern void select_items(void);
  extern void block_select_handlers(void);
  extern void unblock_select_handlers(void);
  
  
#ifdef __cplusplus
}

#endif				/* __cplusplus */

#endif				/* __MAKE_DIR_LIST_H__ */
