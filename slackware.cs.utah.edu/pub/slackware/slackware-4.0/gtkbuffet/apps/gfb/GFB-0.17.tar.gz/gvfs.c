/* gvfs.c -- The virtual filesystem layer interface.

 * Copyright (C) 1999 Steve Hill <sjhill@plutonium.net>
 *                    Yarick Rastrigin <yarick@relex.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <dirent.h>
#include <mntent.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/major.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <strings.h>

#include <glib.h>
#include <gtk/gtk.h>

#include "common.h"
#include "gvfs.h"

#ifdef SCSI_DISK0_MAJOR
#define SCSI_DISK_MAJOR_ SCSI_DISK0_MAJOR
#else
#define SCSI_DISK_MAJOR_ SCSI_DISK_MAJOR
#endif

static gchar *current_directory = NULL;
static GVFS *vfs_handlers = &gvfs_local_fs_ops;

gchar *FileSystemName[] =
{
  "none",
  "swap",
  "proc",
  "affs",
  "ext2",
  "hpfs",
  "iso9660",
  "minix",
  "msdos",
  "ncpfs",
  "nfs",
  "smbfs",
  "sysv",
  "ufs",
  "vfat",
  "other"
};

guint
gvfs_initialize (void)
{
  /* Set current directory. */
  current_directory = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));
  getcwd (current_directory, PATH_MAX);

  /* Register the virtual filesystem layer handlers. */

  return 1;
}

void
gvfs_shutdown (void)
{
  g_free (current_directory);
  g_free (vfs_handlers);
}

DeviceType
vfsGetDeviceType (struct stat *sBuf, FileSystemType fsType)
{
  DeviceType devType;
  gint major = sBuf->st_rdev >> 8;
  if (S_ISBLK (sBuf->st_mode))
    {
      switch (major)
	{
	case FLOPPY_MAJOR:
	  devType = DEVICE_FLOPPY;
	  break;
	case IDE0_MAJOR:
	case SCSI_DISK_MAJOR_:
	case XT_DISK_MAJOR:
	case IDE1_MAJOR:
	case IDE2_MAJOR:
	case IDE3_MAJOR:
	  devType = DEVICE_HD;
	  break;
	case SCSI_CDROM_MAJOR:
	case CDU31A_CDROM_MAJOR:
	case GOLDSTAR_CDROM_MAJOR:
	case OPTICS_CDROM_MAJOR:
	case SANYO_CDROM_MAJOR:
	case MITSUMI_X_CDROM_MAJOR:
	case MITSUMI_CDROM_MAJOR:
	case CDU535_CDROM_MAJOR:
	case MATSUSHITA_CDROM_MAJOR:
	case MATSUSHITA_CDROM2_MAJOR:
	case MATSUSHITA_CDROM3_MAJOR:
	case MATSUSHITA_CDROM4_MAJOR:
	case AZTECH_CDROM_MAJOR:
	case CM206_CDROM_MAJOR:
	  devType = DEVICE_CD;
	  break;
	};
    }
  else
    devType = DEVICE_OTHER;
  return devType;
}

static void
vfsFixDeviceType (GVFS * vfsItem)
{
  /*
     Small routine needed in difficult situations
   */
  if (vfsItem->fs_type == ISO9660)
    vfsItem->dev_type = DEVICE_CD;
  else if ((vfsItem->fs_type == NFS) || (vfsItem->fs_type == NCPFS) || (vfsItem->fs_type == SMBFS))
    vfsItem->dev_type = DEVICE_NETWORK;
}

gboolean
vfsHasSubdirs (GVFS vfsItem)
{
  /*
     We could possibly do a simple call to vfsGetSubdirs() and just check
     for return != NULL, but this could result in increased reaction times on large
     subdirs (fileops must be minimalised :)
   */
  DIR *dir;
  struct dirent *dEnt;
  struct stat sBuf;
  gchar hgc1[PATH_MAX];
  dir = opendir ((char *) vfsItem.current_directory);
  if (!dir)
    return FALSE;
  while ((dEnt = readdir (dir)) != NULL)
    {
      strcpy ((char *) &hgc1, vfsItem.current_directory);
      append_slash ((char *) &hgc1);
      strcat ((char *) &hgc1, dEnt->d_name);
      stat ((char *) &hgc1, &sBuf);
      if (S_ISDIR (sBuf.st_mode) && (dEnt->d_name[0] != '.'))
	return TRUE;
/*
   "We found them, commander..." (c)"Command&Conquer" by Westwood Studios
 */
    };
  return FALSE;
};

GList *
vfsGetXtabInfo (gchar * tabFile)
{
  /* returns list of mounted filesystems */
  GVFS *vfsItem;
  struct mntent *mntEntry;
  struct stat sBuf;
  GList *hGL1 = NULL;
  gboolean mounted = FALSE;
  FILE *xTab = setmntent (tabFile, "r");
  g_return_val_if_fail (xTab != NULL, NULL);
  if (!strcmp (tabFile, "/etc/mtab"))
    mounted = TRUE;
  while ((mntEntry = getmntent (xTab)) != NULL)
    {
      vfsItem = g_malloc (sizeof (GVFS));
      vfsItem->label = NULL;
      /* Just compares predefined FS id strings with real ones */
      for (vfsItem->fs_type = NONE; vfsItem->fs_type < OTHER; vfsItem->fs_type++)
	if (!strcmp (mntEntry->mnt_type, FileSystemName[vfsItem->fs_type]))
	  break;
      if (!stat (mntEntry->mnt_fsname, &sBuf))
	vfsItem->dev_type = vfsGetDeviceType (&sBuf, vfsItem->fs_type);
      vfsFixDeviceType (vfsItem);
      vfsItem->mount_point = g_strdup (mntEntry->mnt_dir);
      strcpy (vfsItem->current_directory, vfsItem->mount_point);
      hGL1 = g_list_append (hGL1, (gpointer) vfsItem);
    };
  endmntent (xTab);
  return hGL1;
}


GList *
vfsGetSubdirs (GVFS vfsItem)
{
  DIR *dir;
  struct dirent *dEnt;
  struct stat sBuf;
  GList *hGL1 = NULL;
  GVFS *vfsItem_;
  gchar *hgc1;
  dir = opendir ((char *) vfsItem.current_directory);
  g_return_val_if_fail (dir != NULL, NULL);
  hgc1 = g_malloc0 (PATH_MAX);
  while ((dEnt = readdir (dir)) != NULL)
    {
      strcpy (hgc1, vfsItem.current_directory);
      append_slash (hgc1);
      strcat (hgc1, dEnt->d_name);
      stat (hgc1, &sBuf);
      if (S_ISDIR (sBuf.st_mode) && (dEnt->d_name[0] != '.'))
	{
	  vfsItem_ = g_malloc (sizeof (GVFS));
	  strcpy (vfsItem_->current_directory, hgc1);
	  hGL1 = g_list_append (hGL1, vfsItem_);
	};
    };
  closedir (dir);
  g_free (hgc1);
  return hGL1;
}

GVFS *
vfsFindItem (GList * list, gchar * path)
{
  GList *hGL1;
  g_return_val_if_fail (list != NULL, NULL);
  g_return_val_if_fail (path != NULL, NULL);
  for (hGL1 = list; hGL1 != NULL; hGL1 = hGL1->next)
    if (!strcmp (((GVFS *) hGL1->data)->current_directory, path))
      return hGL1->data;
  return NULL;
}

gboolean
gvfs_dir_exist (gchar * path)
{
  DIR *dir;

  if ((dir = opendir (path)) != NULL)
    {
      closedir (dir);
      return TRUE;
    }
  else
    return FALSE;
}

gchar *
gvfs_get_current_dir (void)
{
  return current_directory;
}
