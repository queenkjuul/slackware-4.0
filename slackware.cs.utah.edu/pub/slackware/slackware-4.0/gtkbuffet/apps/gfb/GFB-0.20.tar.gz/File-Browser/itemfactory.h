#ifndef __ITEMFACTORY_H__
#define __ITEMFACTORY_H__

#ifdef __cplusplus
extern "C"
{
#endif				/* __cplusplus */

  typedef enum
    {
      OPEN,
      PRINT,
      NEW_FILE,
      NEW_DIR,
      NEW_LINK,
      DELETE,
      RENAME,
      PROPERTIES,
      CUT,
      COPY,
      PASTE,
      SELECT_ALL,
      INVERT_SEL,
      TOOLBAR,
      STATUS_BAR,
      NEW_FOLDER,
      NEW_SYMLINK,
      REFRESH,
      SET_LARGE_ICONS,
      SET_SMALL_ICONS,
      SET_LIST_VIEW,
      SET_DETAILED_VIEW
    }
  GFBMenuItemActions;

  extern void get_main_menu (GtkWidget * window, GtkWidget ** menubar);
#ifdef __cplusplus
}
#endif				/* __cplusplus */

#endif				/* __ITEMFACTORY_H__ */
