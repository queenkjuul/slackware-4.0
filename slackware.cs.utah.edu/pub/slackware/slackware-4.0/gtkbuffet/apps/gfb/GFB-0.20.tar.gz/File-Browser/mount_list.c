/* mount_list.c -- maintains the list of mounted filesystems. Large portions
 *                 of this module borrowed from Midnight Commander.
 *              
 * Copyright (C) 1999 Steve Hill <sjhill@plutonium.net> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <mntent.h>

#include <glib.h>

#include "mount_list.h"

static struct mount_entry *mounted_list = NULL;
static guint num_entries = 0;

guint
build_mount_list (void)
{
  struct mntent *mnt;
  struct mount_entry *entry;
  struct mount_entry *tail = NULL;
  FILE *fp;

  /* Make sure we can read the current mount table. */
  if ((fp = setmntent ("/etc/mtab", "r")) == NULL)
    return 0;

  /* Set to NULL, since we could be rebuilding list. */
  mounted_list = NULL;

  /* Fill in the mounted filesystem list. */
  while ((mnt = getmntent (fp)))
    {
      entry = (struct mount_entry *) g_malloc (sizeof (struct mount_entry));
      entry->devname = g_strdup (mnt->mnt_fsname);
      entry->mountpoint = g_strdup (mnt->mnt_dir);
      entry->type = g_strdup (mnt->mnt_type);
      entry->options = g_strdup (mnt->mnt_opts);
      entry->next = NULL;

      /* Add to the linked list. */
      if (mounted_list == NULL)
	{
	  mounted_list = entry;
	  tail = entry;
	  num_entries++;
	}
      else
	{
	  /* Ignore the /proc filesystem. */
	  if (strcmp (entry->devname, "/proc") != 0)
	    {
	      tail->next = entry;
	      tail = entry;
	      num_entries++;
	    }
	}
    }

  /* Function 'endmntent' should always return a 1. */
  if (endmntent (fp) != 1)
    return 0;

  /* Return successfully. */
  return num_entries;
}

struct mount_entry *
get_mount_list (void)
{
  return mounted_list;
}

gboolean
dir_is_mount_point (gchar * path)
{
  struct mount_entry *entry;

  /* Check to make sure path is a local filesystem. */
  if (*path != '/')
    return FALSE;

  /* Point to the beginning of the list. */
  entry = mounted_list;

  /* Step through the list and see if there is a match. */
  while (entry->next != NULL)
    {
      if (strcmp (entry->mountpoint, path) == 0)
	return TRUE;

      entry = entry->next;
    }

  /* Looks like we did not find a match. */
  return FALSE;
}
