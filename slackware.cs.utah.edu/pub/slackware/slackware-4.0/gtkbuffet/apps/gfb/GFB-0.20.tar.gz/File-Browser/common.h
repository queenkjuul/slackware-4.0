#ifndef __CONFIG_H_
#define __CONFIG_H_

#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN 64
#endif
/*
   Sorry for incorrect solution, but
   #include <rpc/types.h>
   generates lots of warnings
   about redefinitions of TRUE, FALSE and some other symbols.
   Libc guys can't even think about someone (glib, for example) could or will
   redefine this :)
 */

#define CONFIG_FILE ".gfb/gfbrc"
#define NUM_OF_TITLES 4

gchar LOCAL_HOSTNAME[MAXHOSTNAMELEN];

extern GtkWidget *main_window;
extern GtkWidget *main_vbox;
extern GtkWidget *treelist_vbox;
extern GtkWidget *main_menubar;
extern GtkWidget *main_buttonbar;
extern GtkWidget *main_hpaned;
extern GtkWidget *main_treewin;
extern GtkWidget *main_tree;
extern GtkWidget *main_listwin;
extern GtkWidget *main_list;
extern GtkWidget *main_statusbar;
extern GtkWidget *main_history_box;
extern GtkWidget *toolbox_hbox;
extern GtkWidget *main_toolbox;
extern gchar *main_titles[NUM_OF_TITLES];
extern gint main_window_usize_x, main_window_usize_y, main_treewin_usize_x,
  main_treewin_usize_y;
extern gint IN_ITEM_SELECT, IN_MAKE_DIR_LIST, IN_TREE_EXPAND;
extern gint main_window_destroy_handler;

extern void append_slash (gchar *);
extern gint get_widget_width (GtkWidget *);
extern gint get_widget_height (GtkWidget *);

extern gchar *get_main_window_width (void);
extern gchar *get_main_window_height (void);
extern gchar *get_main_treewin_width (void);
extern gchar *get_main_treewin_height (void);

extern void set_main_window_width (gchar *);
extern void set_main_window_height (gchar *);
extern void set_main_treewin_width (gchar *);
extern void set_main_treewin_height (gchar *);

#endif /* __CONFIG_H_ */
