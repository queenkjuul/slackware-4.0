// -*- C++ -*-
// File: pixmaps.c
//
// Created: Fri Jan  1 19:11:33 1999
//
// $Id: pixmaps.c,v 1.8 1999/04/04 22:54:55 Steven Exp $
//
#include <gtk/gtk.h>
#include <glib.h>
#include "common.h"
#include "pixmaps.h"
#include "xpms/treefolderopen.xpm"
#include "xpms/treefolderclosed.xpm"
#include "xpms/filelarge.xpm"
#include "xpms/filesmall.xpm"
#include "xpms/folderlarge.xpm"
#include "xpms/foldersmall.xpm"
#include "xpms/copy.xpm"
#include "xpms/cut.xpm"
#include "xpms/delete.xpm"
#include "xpms/options.xpm"
#include "xpms/paste.xpm"
#include "xpms/updir.xpm"
#include "xpms/MyComputer.xpm"
#include "xpms/Network.xpm"
#include "xpms/cdrom.xpm"
#include "xpms/floppy.xpm"
#include "xpms/hdisk.xpm"
#include "xpms/Mounted.xpm"
#include "xpms/Available.xpm"
#include "xpms/World.xpm"
#include "xpms/zip.xpm"

void
createPixmaps ()
{
  GtkStyle *main_style = gtk_widget_get_style (main_window);
  GdkColor *transp_color = &main_style->bg[GTK_STATE_NORMAL];
  pixMaps[TREE_FOLDER_CLOSED] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[TREE_FOLDER_CLOSED],
				  transp_color,
				  (gchar **) treefolderclosed_xpm);
  pixMaps[TREE_FOLDER_OPEN] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[TREE_FOLDER_OPEN],
				  transp_color,
				  (gchar **) treefolderopen_xpm);
  pixMaps[TOOLBAR_UPDIR] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[TOOLBAR_UPDIR],
				  transp_color,
				  (gchar **) updir_xpm);
  pixMaps[TOOLBAR_CUT] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[TOOLBAR_CUT],
				  transp_color,
				  (gchar **) cut_xpm);
  pixMaps[TOOLBAR_COPY] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[TOOLBAR_COPY],
				  transp_color,
				  (gchar **) copy_xpm);
  pixMaps[TOOLBAR_PASTE] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[TOOLBAR_PASTE],
				  transp_color,
				  (gchar **) paste_xpm);
  pixMaps[TOOLBAR_DELETE] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[TOOLBAR_DELETE],
				  transp_color,
				  (gchar **) delete_xpm);
  pixMaps[TOOLBAR_OPTIONS] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[TOOLBAR_OPTIONS],
				  transp_color,
				  (gchar **) options_xpm);
  pixMaps[FOLDER_LARGE] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[FOLDER_LARGE],
				  transp_color,
				  (gchar **) folderlarge_xpm);
  pixMaps[FOLDER_SMALL] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[FOLDER_SMALL],
				  transp_color,
				  (gchar **) foldersmall_xpm);
  pixMaps[FILE_LARGE] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[FILE_LARGE],
				  transp_color,
				  (gchar **) filelarge_xpm);
  pixMaps[FILE_SMALL] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[FILE_SMALL],
				  transp_color,
				  (gchar **) filesmall_xpm);
  pixMaps[NODE_LOCALHOST_PIX] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[NODE_LOCALHOST_PIX],
				  transp_color,
				  (gchar **) MyComputer_xpm);
  pixMaps[NODE_NETWORK_PIX] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[NODE_NETWORK_PIX],
				  transp_color,
				  (gchar **) Network_xpm);
  pixMaps[MOUNTED] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[MOUNTED],
				  transp_color,
				  (gchar **) Mounted_xpm);
  pixMaps[AVAILABLE] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[AVAILABLE],
				  transp_color,
				  (gchar **) Available_xpm);


  pixMaps[DEV_CDROM] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[DEV_CDROM],
				  transp_color,
				  (gchar **) cdrom_xpm);
  pixMaps[DEV_FLOPPY] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[DEV_FLOPPY],
				  transp_color,
				  (gchar **) floppy_xpm);
  pixMaps[DEV_HD] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[DEV_HD],
				  transp_color,
				  (gchar **) hdisk_xpm);

  pixMaps[DEV_ZIP] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[DEV_ZIP],
				  transp_color,
				  (gchar **) zip_xpm);
  pixMaps[NODE_WORLD_PIX] =
    gdk_pixmap_create_from_xpm_d (main_window->window,
				  &bitMaps[NODE_WORLD_PIX],
				  transp_color,
				  (gchar **) World_xpm);
}
