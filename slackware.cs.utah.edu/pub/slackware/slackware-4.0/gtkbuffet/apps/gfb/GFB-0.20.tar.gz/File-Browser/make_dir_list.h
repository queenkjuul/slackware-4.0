/* make_dir_list.h -- Directory list panel.

 * Copyright (C) 1999 Yarick Rastrigin <yarick@relex.ru>
 *                    Steve Hill <sjhill@plutonium.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef __MAKE_DIR_LIST_H__
#define __MAKE_DIR_LIST_H__

#ifdef __cplusplus
extern "C"
{
#endif				/* __cplusplus */

#define SMALL_ICONS_LIST_COLUMN_WIDTH 128;
#define SMALL_ICONS_LIST_COLUMN_HEIGHT 18;
#define LARGE_ICONS_LIST_COLUMN_WIDTH 128;
#define LARGE_ICONS_LIST_COLUMN_HEIGHT 84;

/* Type definition for how files are displayed. */
  typedef enum
    {
      LARGE_ICONS,
      SMALL_ICONS,
      LIST_VIEW,
      DETAILED_VIEW
    }
  DirListMode;

/* Type definition for how files are sorted. */
  typedef enum
    {
      SORT_BY_NAME,
      SORT_BY_TYPE,
      SORT_BY_SIZE,
      SORT_BY_DATE
    }
  DirListSortMode;

/* Change file listing mode. */
  extern void set_dir_list_mode (gchar * state);

/* Get the current listing mode. */
  extern gchar *get_dir_list_mode (void);

/* Change file sorting mode. */
  extern void set_dir_list_sort_mode (gchar * state);

/* Get the current listing mode. */
  extern gchar *get_dir_list_sort_mode (void);

  extern GList *current_directory;
  extern void make_dir_list (char *);
  extern void change_dir_list_mode (DirListMode);
  extern void create_dir_list (GtkWidget *);
  extern void select_items (void);
  extern void block_select_handlers (void);
  extern void unblock_select_handlers (void);
  extern DirListMode dir_list_mode;
  extern DirListSortMode dir_list_sort_mode;
#ifdef __cplusplus
}
#endif				/* __cplusplus */

#endif				/* __MAKE_DIR_LIST_H__ */
