/* gvfs.c -- The virtual filesystem layer interface.

 * Copyright (C) 1999 Steve Hill <sjhill@plutonium.net>
 *                    Yarick Rastrigin <yarick@relex.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <dirent.h>
#include <stdio.h>
#include <strings.h>

#include <glib.h>
#include <gtk/gtk.h>
#include <sys/stat.h>
#include <unistd.h>

#include "common.h"
#ifdef __DEBUG__
#include "debug.h"
#endif
#include "gvfs.h"

static GVFS *gvfs_handlers = &gvfs_local_fs_ops;
static GVFS *gvfs_type (gchar * path);

static gchar *current_directory = NULL;

gboolean 
is_file (void *stat_info)
{
  return !(S_ISDIR (((struct stat *) (stat_info))->st_mode));
}

gboolean 
is_dir (void *stat_info)
{
  return (S_ISDIR (((struct stat *) (stat_info))->st_mode));
}

gint
gvfs_register (GVFS * gvfs)
{
  int res;

  /* Check for NULL filesystem handler. */
  if (!gvfs)
    {
#ifdef __DEBUG__
      debug_out ("Attempted registering of NULL virtual filesystem handler.");
#endif
      exit (1);
    }

  /* If the filesystem handler has an initialization function, go ahead
   * and execute it.
   */
  res = (gvfs->init) ? (*gvfs->init) (gvfs) : 1;

  /* Check the return value of the filesystem handler's initialization
   * function. If it did not initialize successfully, do not add it
   * to the list of valid virtual filesystem handlers.
   */
  if (!res)
    return 0;

  /* Add the handler to the list and return succesfully. */
  gvfs->next = gvfs_handlers;
  gvfs_handlers = gvfs;

  return 1;
}

guint
gvfs_initialize (void)
{
  /* Set current directory. */
  current_directory = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));
  getcwd (current_directory, PATH_MAX);

  /* Register the virtual filesystem layer handlers. */
  gvfs_register (&gvfs_smb_fs_ops);

  return 1;
}

void
gvfs_shutdown (void)
{
  g_free (current_directory);
}

gboolean
gvfs_dir_exist (gchar * path)
{
  DIR *dir;

  if ((dir = opendir (path)) != NULL)
    {
      closedir (dir);
      return TRUE;
    }
  else
    return FALSE;
}

gchar *
gvfs_get_current_dir (void)
{
  return g_strdup (current_directory);
}

gboolean
gvfs_has_subdirs (gchar * path)
{
  DIR *dir;
  struct dirent *dir_entry;
  struct stat dir_entry_status;
  gboolean exists;
  gchar *working_path;
  GVFS *gvfs;

  /* Allocate space for path and initialize value. */
  working_path = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));
  exists = FALSE;

  /* Get the proper GVFS handler. */
  gvfs = gvfs_type (path);
  if (gvfs == NULL)
    {
      debug_out ("NULL handler in 'gvfs_has_subdirs'.");
      return exists;
    }

  /* Open the directory for reading. */
  dir = (*gvfs->opendir) (gvfs, path);
  if (dir != NULL)
    {
      while ((dir_entry = (*gvfs->readdir) (dir)) != NULL)
	{
	  /* Exclude the "." and ".." directories. */
	  if ((strcmp (dir_entry->d_name, ".") != 0) &&
	      (strcmp (dir_entry->d_name, "..") != 0))
	    {
	      /* Create the absolute path. */
	      strcpy (working_path, path);
	      strcat (working_path, "/");
	      strcat (working_path, dir_entry->d_name);

	      /* See if directory entry is a directory. */
	      (*gvfs->stat) (working_path, &dir_entry_status);
	      if (S_ISDIR (dir_entry_status.st_mode))
		exists = TRUE;
	    }
	}

      /* Close the directory. */
      (*gvfs->closedir) (dir);
    }

  /* Return the value. */
  return exists;
}

GList *
gvfs_get_x_list (gchar * path, FSItemTypeCheckFunc check_func, gboolean need_sort, GList ** stat_info)
{
  DIR *dir;
  struct dirent *dir_entry;
  struct stat dir_entry_status;
  GList *dir_list, *first, *last, *list1, *list2;
  gchar *working_path, *str1, *str2, *str3;
  GVFS *gvfs;
  gpointer stat_data;

  /* Allocate space for path. */
  working_path = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));

  /* Get the proper GVFS handler. */
  gvfs = gvfs_type (path);
  if (gvfs == NULL)
    {
      debug_out ("NULL handler in 'gvfs_get_subdirs'.");
      return NULL;
    }

  /* Open the directory for reading. */
  dir_list = NULL;
  dir = (*gvfs->opendir) (gvfs, path);
  if (dir != NULL)
    {
      while ((dir_entry = (*gvfs->readdir) (dir)) != NULL)
	{
	  /* Exclude the "." and ".." directories. */
	  if ((strcmp (dir_entry->d_name, ".") != 0) &&
	      (strcmp (dir_entry->d_name, "..") != 0))
	    {
	      /* Create the absolute path. */
	      strcpy (working_path, path);
	      strcat (working_path, "/");
	      strcat (working_path, dir_entry->d_name);

	      /* See if directory entry is a directory. */
	      (*gvfs->stat) (working_path, &dir_entry_status);
	      if (check_func (&dir_entry_status))
		dir_list = g_list_append (dir_list, g_strdup (dir_entry->d_name));
	      if (stat_info != NULL)
		{
		  stat_data = g_malloc (sizeof (struct stat));
		  memcpy (stat_data, &dir_entry_status, sizeof (struct stat));
		  *stat_info = g_list_append (*stat_info, stat_data);
		};
	    }
	}

      /* Close the directory. */
      (*gvfs->closedir) (dir);
    }
  else
    return NULL;

  /* Sort the subdirectory list. */
  if (dir_list == NULL)
    return NULL;

  if (!need_sort)
    return dir_list;

  first = g_list_first (dir_list);
  last = g_list_last (dir_list);
  for (list1 = first; list1 != last; list1 = list1->next)
    for (list2 = last; list2 != list1; list2 = list2->prev)
      {
	str1 = (gchar *) list1->data;
	str2 = (gchar *) list2->data;

	if (strcmp (str1, str2) > 0)
	  {
	    str3 = str1;
	    list1->data = list2->data;
	    list2->data = str3;
	  }
      }

  /* Return the list. */
  return dir_list;
}

static GVFS *
gvfs_type (gchar * path)
{
  GVFS *gvfs;
  gchar *gvfs_type;
  guint length;

  /* Set return pointer to NULL. */
  gvfs = NULL;

  /* Check to see if path is on the local filesystem structure. */
  if (*path == '/')
    {
      gvfs = &gvfs_local_fs_ops;
      return gvfs;
    }

  /* Check to see what kind of filesystem we have. */
  length = strcspn (path, ":");
  if (length < 1)
    return gvfs;
  gvfs_type = (gchar *) g_malloc0 ((length + 1) * sizeof (gchar));
  strncpy (gvfs_type, path, length);

  /* Check to see if path is a FTP site. */
  if (strcmp (gvfs_type, "ftp") == 0)
    gvfs = &gvfs_ftp_fs_ops;

  /* Check to see if path is a SMB share. */
  if (strcmp (gvfs_type, "smb") == 0)
    gvfs = &gvfs_smb_fs_ops;

  /* Free memory and return GVFS pointer. */
  g_free (gvfs_type);
  return gvfs;
}
