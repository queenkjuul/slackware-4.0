#include <gtk/gtk.h>
#include <glib.h>
#include <strings.h>
#include "dialogs.h"
