/* gvfs.h -- The virtual filesystem layer interface.

 * Copyright (C) 1999 Steve Hill <sjhill@plutonium.net>
 *                    Yarick Rastrigin <yarick@relex.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef __GVFS_H__
#define __GVFS_H__

#include <sys/stat.h>

#include "gvfs_ftp.h"
#include "gvfs_local.h"
#include "gvfs_smb.h"

typedef struct _GVFS GVFS;
typedef gboolean (*FSItemTypeCheckFunc) (void *item_stat_info);

struct _GVFS
  {
    GVFS *next;
    gboolean read_only;

      gint (*init) (GVFS * gvfs);
    void *(*opendir) (GVFS * gvfs, gchar * dirname);
    void *(*readdir) (void *gvfs_info);
      gint (*closedir) (void *gvfs_info);
      gint (*stat) (gchar * path, struct stat * buf);
  };

typedef enum
  {
    NODE_WORLD,			/* Base node for tree */
    NODE_LOCALHOST,		/* Local Host Node    */
    NODE_NETWORK,		/* Network Node       */
    NODE_HOTLIST,		/* Hotlist Node       */
    NODE_HOTLIST_ENTRY,		/* Hotlist Entry      */
    NODE_FILESYSTEM,		/* Filesystem Node    */
    NODE_DIR,			/* Directory Node     */
    FLI_MOUNTPOINT,		/* FileList Mountpoint */
    FLI_DIR,			/* FileList Directory */
    FLI_FILE			/* FileList ord. file */

  }
UniversalItemType;

typedef struct
  {
    UniversalItemType type;
    gchar *data;
  }
UniversalItem;

/* Other filesystems. */
extern GVFS gvfs_ftp_fs_ops;
extern GVFS gvfs_local_fs_ops;
extern GVFS gvfs_smb_fs_ops;

/* Initializes the virtual filesystem layer. */
guint gvfs_initialize (void);

/* Shutdown the virtual filesystem layer. */
void gvfs_shutdown (void);

/* Check to see if directory exists. */
gboolean gvfs_dir_exist (gchar * path);

/* Returns the current directory. */
gchar *gvfs_get_current_dir (void);

/* Check to see if a directory has childer (subdirectories). */
gboolean gvfs_has_subdirs (gchar * path);

/* Returns a list of possibly sorted dir entries excluding "." and ".." entries. */
GList *gvfs_get_x_list (gchar * path, FSItemTypeCheckFunc check_func, gboolean need_sort, GList ** stat_info);

/* Returns a list of files  */
GList *gvfs_get_files (gchar * path);

gboolean is_file (void *);
gboolean is_dir (void *);
#endif /* __GVFS_H__ */
