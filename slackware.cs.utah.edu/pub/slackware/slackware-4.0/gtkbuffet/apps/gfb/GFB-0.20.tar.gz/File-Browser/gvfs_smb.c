/* gvfs_smb.c -- GVFS handler for SMB filesystem operations.

 * Copyright (C) 1999 Steve Hill <sjhill@plutonium.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>

#include <glib.h>

#include "gvfs.h"
#include "gvfs_smb.h"

gint
smb_init (GVFS * gvfs)
{
  return 1;
}

void *
smb_opendir (GVFS * gvfs, gchar * dirname)
{
}

void *
smb_readdir (void *gvfs_info)
{
}

gint
smb_closedir (void *gvfs_info)
{
}

gint
smb_stat (gchar * path, struct stat *buf)
{
}

GVFS gvfs_smb_fs_ops =
{
  NULL,
  FALSE,
  smb_init,
  smb_opendir,
  smb_readdir,
  smb_closedir,
  smb_stat,
};
