/* history_box - dynamic directory input box with history
 * Copyright (C) 1999 Steve Hill <sjhill@plutonium.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <dirent.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/types.h>

#include <gtk/gtk.h>

#include "common.h"
#include "gvfs.h"
#include "history_box.h"
#include "rq.h"

static GtkCombo *combo = NULL;
static GList *dir_history = NULL;
static guint inputbox_change_id = 0;

static void inputbox_changed (GtkWidget * widget, gpointer data);
static void history_item_selected (GtkWidget * widget, gpointer data);

GtkWidget *
history_box_new (void)
{
  if (combo == NULL)
    {
      /* Initialize the directory history with current directory. */
      dir_history = g_list_append (dir_history, gvfs_get_current_dir ());

      /* Instantiate new combo object and give it the directory list. */
      combo = GTK_COMBO (gtk_combo_new ());
      gtk_combo_set_popdown_strings (combo, dir_history);

      /* Disable activation when an item typed in the entry box matches
       * that of one in the list. Otherwise, it pops up the whole list.
       */
      gtk_combo_disable_activate (combo);

      /* Hook up the signals. We use the 'changed' signal so that the
       * file list pane will be dynamically updated as the path is
       * typed in.
       */
      inputbox_change_id = gtk_signal_connect (GTK_OBJECT (combo->entry),
		      "activate", GTK_SIGNAL_FUNC (inputbox_changed), NULL);
      gtk_signal_connect (GTK_OBJECT (combo->list), "select_child",
			  GTK_SIGNAL_FUNC (history_item_selected), NULL);
    }
  return GTK_WIDGET (combo);
}

GtkWidget *
history_box_new_with_history (GList * list)
{
  GtkWidget *widget;

  /* Make call to generic constructor. */
  widget = history_box_new ();

  /* Clear out the history list. */
  history_box_clear_history ();

  /* Fill in saved history list. */
  while (list != NULL)
    {
      dir_history = g_list_append (dir_history, list->data);
      list = list->next;
    }
  gtk_combo_set_popdown_strings (combo, dir_history);

  /* Return inputbox with history. */
  return widget;
}

void
history_box_destroy (void)
{
  gtk_widget_destroy (GTK_WIDGET (combo));
  g_list_free (dir_history);
}

void
history_box_clear_history (void)
{
  /* Block signals. */
  gtk_signal_handler_block (GTK_OBJECT (combo->list), combo->list_change_id);
  gtk_signal_handler_block (GTK_OBJECT (combo->entry), combo->entry_change_id);
  gtk_signal_handler_block (GTK_OBJECT (combo->entry), inputbox_change_id);

  /* Clear the history list and add in the current directory. */
  g_list_free (dir_history);
  dir_history = NULL;
  dir_history = g_list_append (dir_history, gvfs_get_current_dir ());
  gtk_combo_set_popdown_strings (combo, dir_history);

  /* Unblock signals. NOTE: Signals should always be unblocked in the
   * opposite order that they were blocked. Segmentation faults will
   * occur if this is not done!
   */
  gtk_signal_handler_unblock (GTK_OBJECT (combo->entry), inputbox_change_id);
  gtk_signal_handler_unblock (GTK_OBJECT (combo->entry), combo->entry_change_id);
  gtk_signal_handler_unblock (GTK_OBJECT (combo->list), combo->list_change_id);
}

GList *
history_box_get_history (void)
{
  GList *new_list, *temp_list;

  /* Allocate new list. */
  new_list = g_list_alloc ();

  /* Populate the new list. */
  temp_list = dir_history;
  do
    {
      new_list = g_list_append (new_list, temp_list->data);
      temp_list = temp_list->next;
    }
  while (temp_list != NULL);

  /* Return new list. */
  return new_list;
}

static void
inputbox_changed (GtkWidget * widget, gpointer data)
{
  gchar *history_str;
  GList *temp_list = NULL;
  gboolean found = FALSE;
  guint i, length;

  /* Get a new directory string. */
  if (GTK_IS_ENTRY (widget) && (data == NULL))
    history_str = g_strdup (gtk_entry_get_text (GTK_ENTRY (widget)));
  else
    history_str = g_strdup (data);

  /* If the user types in a directory ending with more than two '.'
   * characters, we change the path to be the parent directory.
   */
  length = strlen (history_str) - 1;
  if ((*(history_str + length) == '.') && (*(history_str + length - 1) == '.'))
    {
      i = 0;
      do
	{
	  *(history_str + length) = '\0';
	  length = strlen (history_str) - 1;

	  if (*(history_str + length) == '/')
	    i++;
	}
      while (i < 2);
    }

  /* If the path typed in ends with "/." then chop those two
   * characters off.
   */
  length = strlen (history_str) - 1;
  if ((*(history_str + length) == '.') && (*(history_str + length - 1) == '/'))
    *(history_str + length) = '\0';

  /* Chop off all forward slashes at the end of the path except for
   * the root directory.
   */
  length = strlen (history_str) - 1;
  if (length != 0)
    while (*(history_str + length) == '/')
      {
	*(history_str + length) = '\0';
	length = strlen (history_str) - 1;
      }

  /* Get the directory listing.  */
  if (gvfs_dir_exist (history_str))
    {
      /* See if path is already in the history. */
      temp_list = dir_history;
      while (temp_list != NULL)
	{
	  if (strcmp ((char *) temp_list->data, history_str) == 0)
	    {
	      found = TRUE;
	      break;
	    }
	  temp_list = temp_list->next;
	}

      /* Block signals. */
      gtk_signal_handler_block (GTK_OBJECT (combo->list), combo->list_change_id);
      gtk_signal_handler_block (GTK_OBJECT (combo->entry), combo->entry_change_id);
      gtk_signal_handler_block (GTK_OBJECT (combo->entry), inputbox_change_id);

      /* If then path is already in the history, display it in the
       * the text entry area. Otherwise, add it to the history list.
       */
      if (found == TRUE)
	gtk_entry_set_text (GTK_ENTRY (combo->entry), history_str);
      else
	{
	  dir_history = g_list_prepend (dir_history, g_strdup (history_str));
	  gtk_combo_set_popdown_strings (combo, dir_history);
	}

      /* Request that the directory list and tree state be updated. */
      putRequest (MAKE_DIR_LIST, history_str, NULL);
      putRequest (EXPAND_TREE, history_str, NULL);

      /* Unblock signals. NOTE: Signals should always be unblocked in the
       * opposite order that they were blocked. Segmentation faults will
       * occur if this is not done!
       */
      gtk_signal_handler_unblock (GTK_OBJECT (combo->entry), inputbox_change_id);
      gtk_signal_handler_unblock (GTK_OBJECT (combo->entry), combo->entry_change_id);
      gtk_signal_handler_unblock (GTK_OBJECT (combo->list), combo->list_change_id);
    }
}

static void
history_item_selected (GtkWidget * widget, gpointer data)
{
  GtkListItem *list_item;
  GtkLabel *label;
  gchar *str;

  /* Make sure data is an actual list item. */
  if (GTK_IS_LIST_ITEM (data))
    {
      /* Extract label text which is the new path. */
      list_item = GTK_LIST_ITEM (data);
      label = GTK_LABEL (GTK_BIN (list_item)->child);
      gtk_label_get (label, &str);

      /* Emit the signal to cause the file list window to be updated. */
      gtk_signal_emit_by_name (GTK_OBJECT (combo->entry), "activate", str);
    }
}
