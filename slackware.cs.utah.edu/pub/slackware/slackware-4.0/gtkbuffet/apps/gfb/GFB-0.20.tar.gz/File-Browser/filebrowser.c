#include <strings.h>
#include <unistd.h>

#include <gtk/gtk.h>

#include "common.h"
#include "debug.h"
#include "filebrowser.h"
#include "init_deinit.h"

int
main (int argc, char *argv[])
{
  gtk_init (&argc, &argv);
  debug_on ();
  gfb_init ();
  gtk_widget_show (main_window);
  gtk_main ();
  gfb_exit ();
  return 0;
}
