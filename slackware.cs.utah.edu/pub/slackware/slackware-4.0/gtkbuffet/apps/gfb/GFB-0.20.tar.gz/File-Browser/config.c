/* config.c -- configuration manager based on libPropList.

 * Copyright (C) 1999 Yarick Rastrigin <yarick@relex.ru>
 *                    Steve Hill <sjhill@plutonium.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <glib.h>
#include <proplist.h>

#include "common.h"
#include "make_dir_list.h"

typedef char *(*GetValueFunc) (void);
typedef void (*SetValueFunc) (char *);

typedef struct
  {
    gchar *name, *default_value;
    GetValueFunc get_func;
    SetValueFunc set_func;
  }
config_item;


config_item config[] =
{
  {
    "main_window_width",
    "500",
    get_main_window_width,
    set_main_window_width
  },
  {
    "main_window_height",
    "400",
    get_main_window_height,
    set_main_window_height
  },
  {
    "main_treewin_width",
    "300",
    get_main_treewin_width,
    set_main_treewin_width,
  },
  {
    "main_treewin_height",
    "400",
    get_main_treewin_height,
    set_main_treewin_height,
  },
  {
    "dir_list_mode",
    "2",
    get_dir_list_mode,
    set_dir_list_mode,
  },
  {
    "sort_mode",
    "0",
    get_dir_list_sort_mode,
    set_dir_list_sort_mode
  }
};

void
load_config (gchar * filename)
{
    proplist_t hpt1 = NULL;
    proplist_t hpt2 = NULL;
    proplist_t hpt3 = NULL;
  gint hgi1, hgi2;
  gchar *hgc1;
  hgi1 = sizeof (config) / sizeof (config_item);
  hpt1 = PLGetProplistWithPath (filename);
  for (hgi2 = 0; hgi2 < hgi1; hgi2++)
    {
      hpt2 = PLMakeString (config[hgi2].name);
      if (hpt1 != NULL)
	{
	  hpt3 = PLGetDictionaryEntry (hpt1, hpt2);
	  if (hpt3 != NULL)
	    hgc1 = PLGetString (hpt3);
	  else
	    hgc1 = config[hgi2].default_value;
	}
      else
	hgc1 = config[hgi2].default_value;
      config[hgi2].set_func (hgc1);
      PLRelease (hpt2);
      if (hpt3 != NULL) PLRelease (hpt3);
    };
}

void
save_config (gchar * filename)
{
    proplist_t hpt1 = NULL;
    proplist_t hpt2 = NULL;
    proplist_t hpt3 = NULL;
  gint hgi1, hgi2;
  hgi1 = sizeof (config) / sizeof (config_item);
  /* F...ing libPropList don't allows creation of empty dictionary, so we must
     process first parameter separately.
   */
  hpt2 = PLMakeString (config[0].name);
  hpt3 = PLMakeString (config[0].get_func ());
  hpt1 = PLMakeDictionaryFromEntries (hpt2, hpt3, NULL);
  PLRelease (hpt2);
  PLRelease (hpt3);
  for (hgi2 = 1; hgi2 < hgi1; hgi2++)
    {
      hpt2 = PLMakeString (config[hgi2].name);
      hpt3 = PLMakeString (config[hgi2].get_func ());
      hpt1 = PLInsertDictionaryEntry (hpt1, hpt2, hpt3);
      PLRelease (hpt2);
      PLRelease (hpt3);
    };
  hpt2 = PLMakeString (filename);
  hpt1 = PLSetFilename (hpt1, hpt2);
  PLSave (hpt1, NO);
  PLRelease (hpt2);
  PLRelease (hpt1);
}
