/* tree.c -- creates directory tree and handles the GUI filesystem interface.

 * Copyright (C) 1999 Yarick Rastrigin <yarick@relex.ru>
 *                    Steve Hill <sjhill@plutonium.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <strings.h>

#include <glib.h>
#include <gdk/gdk.h>
#include <gtk/gtk.h>
#include "common.h"
#include "gvfs.h"
#include "pixmaps.h"
#include "rq.h"
#include "tree.h"
#include "mount_list.h"

#ifdef __DEBUG__
#include "debug.h"
#endif

static GtkCTree *base_tree = NULL;
static GtkCTreeNode *world_node, *localhost_node, *network_node, *hotlist_node;
static guint collapse_handler, expand_handler, select_handler;
static gboolean show_hidden_directories = TRUE;

static GtkCTreeNode *construct_tree_node (GtkCTreeNode * parent,
				     UniversalItemType type, gchar * label);
static void add_empty_child (GtkCTreeNode * node);
static void gtk_ctree_node_remove_children (GtkCTree * tree,
					    GtkCTreeNode * node);
static gint tree_expand (GtkCTree * tree, GtkCTreeNode * node, gpointer data);
static gint tree_collapse (GtkCTree * tree, GtkCTreeNode * node, gpointer data);
static gint tree_select_row (GtkCTree * tree, GtkCTreeNode * node,
			     gpointer data);
static void get_complete_path (GtkCTreeNode * ctree_node, gchar ** path);

GtkWidget *
construct_tree (void)
{
  /* Create the base tree. */
  base_tree = GTK_CTREE (gtk_ctree_new (1, 0));
  g_return_val_if_fail (GTK_IS_CTREE (base_tree), NULL);
  gtk_ctree_set_line_style (base_tree, GTK_CTREE_LINES_DOTTED);
  gtk_clist_set_row_height (GTK_CLIST (base_tree), 18);

  /* Connect the signal handlers. */
  collapse_handler = gtk_signal_connect (GTK_OBJECT (base_tree),
		    "tree_collapse", GTK_SIGNAL_FUNC (tree_collapse), NULL);
  expand_handler = gtk_signal_connect (GTK_OBJECT (base_tree),
			"tree_expand", GTK_SIGNAL_FUNC (tree_expand), NULL);
  select_handler = gtk_signal_connect (GTK_OBJECT (base_tree),
		"tree_select_row", GTK_SIGNAL_FUNC (tree_select_row), NULL);

  /* Create primary container nodes. */
  world_node = construct_tree_node (NULL, NODE_WORLD, "World");
  localhost_node = construct_tree_node (world_node, NODE_LOCALHOST,
					LOCAL_HOSTNAME);
  network_node = construct_tree_node (world_node, NODE_NETWORK, "Network");

  /* Construct node for root filesystem. */
  construct_tree_node (localhost_node, NODE_FILESYSTEM, "/");

  /* Return the tree object. */
  return GTK_WIDGET (base_tree);
}

GtkCTreeNode *
construct_tree_node (GtkCTreeNode * parent, UniversalItemType type, gchar * label)
{
  GtkCTreeNode *ctree_node = NULL;
  gboolean has_subdirs;
  gchar *path;
  UniversalItem *node_data;

  /* Create a new data structure and initialize variables. */
  node_data = (UniversalItem *) g_malloc0 (sizeof (UniversalItem));
  has_subdirs = FALSE;

  /* Find out what kind of node is being created. Types are arranged
   * in the case statement from most to least common for speed.
   */
  switch (type)
    {
    case NODE_DIR:
      /* Fill in the data structure. */
      node_data->data = (gchar *) g_malloc0 ((strlen (label) + 2) *
					     sizeof (gchar));
      strcpy (node_data->data, label);
      strcat (node_data->data, "/");
      node_data->type = type;

      /* See if this directory has subdirectories. */
      path = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));
      get_complete_path (parent, &path);
      strcat (path, node_data->data);
      has_subdirs = gvfs_has_subdirs (path);
      g_free (path);

      /* Create new node. */
      ctree_node = gtk_ctree_insert_node (base_tree, parent, NULL,
					  &label, 1,
		   pixMaps[TREE_FOLDER_CLOSED], bitMaps[TREE_FOLDER_CLOSED],
		       pixMaps[TREE_FOLDER_OPEN], bitMaps[TREE_FOLDER_OPEN],
					  !has_subdirs, FALSE);

      /* Add an empty node if subdirectories exist. */
      if (has_subdirs)
	add_empty_child (ctree_node);
      break;

    case NODE_HOTLIST_ENTRY:
      break;

    case NODE_FILESYSTEM:
      /* Fill in the data structure. */
      node_data->data = (gchar *) g_malloc0 ((strlen (label) + 2) *
					     sizeof (gchar));
      strcpy (node_data->data, label);
      if (strcmp (label, "/") != 0)
	strcat (node_data->data, "/");
      node_data->type = type;

      /* Check to see if this is the root directory. Otherwise, see
       * if the mount point has subdirectories.i
       */
      if (strcmp (label, "/") == 0)
	has_subdirs = TRUE;
      else
	{
	  path = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));
	  get_complete_path (parent, &path);
	  strcat (path, label);
	  has_subdirs = gvfs_has_subdirs (path);
	  g_free (path);
	}

      /* Create new node. */
      ctree_node = gtk_ctree_insert_node (base_tree, parent, NULL,
					  &label, 1,
					  pixMaps[DEV_HD], bitMaps[DEV_HD],
					  pixMaps[DEV_HD], bitMaps[DEV_HD],
					  !has_subdirs, FALSE);

      /* Add an empty node if subdirectories exist. */
      if (has_subdirs)
	add_empty_child (ctree_node);
      break;

    case NODE_HOTLIST:
      break;

    case NODE_WORLD:
      /* Fill in the data structure. */
      node_data->data = g_strdup (label);
      node_data->type = type;

      /* Create new node. */
      ctree_node = gtk_ctree_insert_node (base_tree, parent, NULL,
					  &label, 1,
			   pixMaps[NODE_WORLD_PIX], bitMaps[NODE_WORLD_PIX],
			   pixMaps[NODE_WORLD_PIX], bitMaps[NODE_WORLD_PIX],
					  FALSE, FALSE);
      break;

    case NODE_LOCALHOST:
      /* Fill in the data structure. */
      node_data->data = g_strdup (label);
      node_data->type = type;

      /* Create new node. */
      ctree_node = gtk_ctree_insert_node (base_tree, parent, NULL,
					  &label, 1,
		   pixMaps[NODE_LOCALHOST_PIX], bitMaps[NODE_LOCALHOST_PIX],
		   pixMaps[NODE_LOCALHOST_PIX], bitMaps[NODE_LOCALHOST_PIX],
					  FALSE, FALSE);
      break;

    case NODE_NETWORK:
      /* Fill in the data structure. */
      node_data->data = g_strdup (label);
      node_data->type = type;

      /* Create new node. */
      ctree_node = gtk_ctree_insert_node (base_tree, parent, NULL,
					  &label, 1,
		       pixMaps[NODE_NETWORK_PIX], bitMaps[NODE_NETWORK_PIX],
		       pixMaps[NODE_NETWORK_PIX], bitMaps[NODE_NETWORK_PIX],
					  FALSE, FALSE);

      /* Add an empty node. */
      add_empty_child (ctree_node);
      break;
    default:
        break;
    };

  /* Add data record to node. */
  gtk_ctree_node_set_row_data (base_tree, ctree_node, (gpointer) node_data);

  /* Return the new tree node. */
  return ctree_node;
}

static void
add_empty_child (GtkCTreeNode * node)
{
  /* Die if we were given a NULL node. */
  g_return_if_fail (node != NULL);

  /* Add an empty child. */
  gtk_ctree_insert_node (base_tree, node, NULL, NULL, 1, NULL, NULL,
			 NULL, NULL, FALSE, FALSE);
}

static void
gtk_ctree_node_remove_children (GtkCTree * tree, GtkCTreeNode * node)
{
  GtkCTreeNode *child;
  GList *sibling_list;

  /* Die if the tree or node is NULL. */
  g_return_if_fail (tree != NULL);
  g_return_if_fail (node != NULL);

  /* Get the child node and make sure it's not NULL. */
  child = GTK_CTREE_ROW (node)->children;
  if (child == NULL)
    return;

  /* Get the list of siblings. */
  sibling_list = NULL;
  for (; child; child = GTK_CTREE_ROW (child)->sibling)
    sibling_list = g_list_append (sibling_list, child);

  /* Remove all of the sibling nodes. */
  gtk_clist_freeze (GTK_CLIST (tree));
  for (; sibling_list; sibling_list = sibling_list->next)
    gtk_ctree_remove_node (tree, GTK_CTREE_NODE (sibling_list->data));
  gtk_clist_thaw (GTK_CLIST (tree));

  /* Free up memory. */
  g_list_free (sibling_list);
}

static gint
tree_expand (GtkCTree * tree, GtkCTreeNode * node, gpointer data)
{
  GdkCursor *normal_cursor, *clock_cursor;
  GdkWindowAttr *win_attr;
  GList *dir_list;
  gchar *path, *work_path;
  UniversalItem *node_data;

  /* Grab the data structure. */
  node_data = gtk_ctree_node_get_row_data (tree, node);

  /* If the node type is not a filesystem or directory, were done. */
  if ((node_data->type != NODE_FILESYSTEM) && (node_data->type != NODE_DIR))
    return TRUE;

  /* Change the cursor from the arrow to the clock cursor since
   * we don't know how long reading the directory structure is
   * going to take. */
  gdk_window_get_user_data (GTK_WIDGET (main_window)->window,
			    (gpointer) & win_attr);
  normal_cursor = win_attr->cursor;
  clock_cursor = gdk_cursor_new (GDK_WATCH);
  gdk_window_set_cursor (GTK_WIDGET (main_window)->window, clock_cursor);

  /* Block the signals while we remove old children of this node. */
  gtk_signal_handler_block (GTK_OBJECT (base_tree), collapse_handler);
  gtk_ctree_node_remove_children (tree, node);
  gtk_signal_handler_unblock (GTK_OBJECT (base_tree), collapse_handler);
  gtk_clist_freeze (GTK_CLIST (tree));

  /* Get all of the subdirectories and create nodes for them. */
  path = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));
  work_path = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));
  get_complete_path (node, &path);
  dir_list = gvfs_get_x_list (path, is_dir, TRUE, NULL);

  while (dir_list)
    {
      /* Check the state variable and filter directories if required. */
      if ((*((gchar *) dir_list->data) == '.') && !show_hidden_directories)
	{
	  dir_list = dir_list->next;
	  continue;
	}

      /* Create the full path. */
      strcpy (work_path, path);
      strcat (work_path, dir_list->data);

      /* Check to see if we have a mount point. */
      if (dir_is_mount_point (work_path) == TRUE)
	construct_tree_node (node, NODE_FILESYSTEM, dir_list->data);
      else
	construct_tree_node (node, NODE_DIR, dir_list->data);

      /* Move onto the next entry. */
      dir_list = dir_list->next;
    }

  /* Thaw out the list and set the cursor back to normal. */
  gtk_clist_thaw (GTK_CLIST (tree));
  gdk_window_set_cursor (GTK_WIDGET (main_window)->window, normal_cursor);

  /* Free memory up. */
  g_list_free (g_list_first (dir_list));
  g_free (work_path);
  g_free (path);

  /* Return successfully. */
  return TRUE;
}

static gint
tree_collapse (GtkCTree * tree, GtkCTreeNode * node, gpointer data)
{
  UniversalItem *node_data;

  /* Grab the data structure. */
  node_data = gtk_ctree_node_get_row_data (tree, node);

  /* If the node type is not a filesystem or directory, were done. */
  if ((node_data->type != NODE_FILESYSTEM) && (node_data->type != NODE_DIR))
    return TRUE;

  /* Destroy all of the node's children and then add an empty
   * so the node can be expanded again.
   */
  gtk_ctree_node_remove_children (tree, node);
  add_empty_child (node);
  return TRUE;
}

static gint
tree_select_row (GtkCTree * tree, GtkCTreeNode * node, gpointer data)
{
  gchar *path;
  UniversalItem *node_data;

  /* Grab the data structure. */
  node_data = gtk_ctree_node_get_row_data (tree, node);

  /* If the node type is a not filesystem or directory, were done. */
  if ((node_data->type != NODE_FILESYSTEM) && (node_data->type != NODE_DIR))
    return TRUE;

  /* Get the complete path of the directory. */
  path = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));
  get_complete_path (node, &path);

  /* Send out the request. Have to copy string so we can properly
   * free dynamic memory.
   */
  putRequest (MAKE_DIR_LIST, g_strdup (path), NULL);

  /* Free the memory. */
  g_free (path);

  /* Return succesfully. */
  return TRUE;
}

void
expand_tree_by_path (gchar * new_path)
{
  GList *parsed_path_list = NULL;
  GtkCTreeNode *node1, *node2;
  GtkCTreeNode *node3 = NULL;
  gchar *label, *token;

  /* Return if the path is NULL. */
  g_return_if_fail (new_path != NULL);

  /* Parse the path so that we can walk down the tree. */
  while ((token = strsep (&new_path, "/")) != NULL)
    if (strcmp (token, "") != 0)
      parsed_path_list = g_list_append (parsed_path_list, token);

  /* Freeze the tree list so we can begin. */
  gtk_clist_freeze (GTK_CLIST (base_tree));

  /* Expand the world node if it is not already. */
  if (GTK_CTREE_ROW (world_node)->expanded == 0)
    gtk_ctree_expand (base_tree, world_node);


/**********************************/
  if (GTK_CTREE_ROW (localhost_node)->expanded == 0)
    gtk_ctree_expand (base_tree, localhost_node);

  node1 = GTK_CTREE_ROW (localhost_node)->children;
  if (GTK_CTREE_ROW (node1)->expanded == 1)
    gtk_ctree_collapse (base_tree, node1);
  gtk_ctree_expand (base_tree, node1);
  while (parsed_path_list != NULL)
    {
      for (node2 = GTK_CTREE_ROW (node1)->children; \
	   gtk_ctree_is_ancestor (base_tree, node1, node2); \
	   node2 = GTK_CTREE_ROW (node2)->sibling)
	{
	  gtk_ctree_node_get_pixtext (base_tree, node2, 0, &label, NULL, NULL, NULL);
	  if (!strcmp (label, parsed_path_list->data))
	    node3 = node2;
	  else if (GTK_CTREE_ROW (node2)->expanded == 1)
	    gtk_ctree_collapse (base_tree, node2);
	};
      if (GTK_CTREE_ROW (node3)->expanded == 1)
	gtk_ctree_collapse (base_tree, node3);
      gtk_ctree_expand (base_tree, node3);
      node1 = node3;
      parsed_path_list = parsed_path_list->next;
    };
/**********************************/


  /* Select the final node and clean things up. */
  gtk_signal_handler_block (GTK_OBJECT (base_tree), select_handler);
  gtk_ctree_select (base_tree, node1);
  gtk_signal_handler_unblock (GTK_OBJECT (base_tree), select_handler);
  gtk_clist_thaw (GTK_CLIST (base_tree));
};

static void
get_complete_path (GtkCTreeNode * current_node, gchar ** path)
{
  GtkCTreeNode *parent_node;
  gchar *work_path;
  UniversalItem *node_data;

  /* Set the initial state to denote we are not currently
   * in a recursion. */
  static guint state = 0;

  /* Grab the node data. */
  node_data = gtk_ctree_node_get_row_data (base_tree, current_node);

  /* Check to see if the first time the procedure has been entered. */
  if (state == 0)
    {
      strcpy (*path, node_data->data);
      state = 1;
    }
  else
    {
      work_path = (gchar *) g_malloc0 (PATH_MAX * sizeof (gchar));
      strcpy (work_path, node_data->data);
      strcat (work_path, *path);
      strcpy (*path, work_path);
      g_free (work_path);
    }

  /* Get the parent node and its data. */
  parent_node = (GtkCTreeNode *) GTK_CTREE_ROW (current_node)->parent;
  node_data = gtk_ctree_node_get_row_data (base_tree, parent_node);

  /* See if we need to recurse or not. */
  if ((node_data->type == NODE_FILESYSTEM) || (node_data->type == NODE_DIR))
    get_complete_path (parent_node, path);

  /* Reset the state. */
  state = 0;
}

void
tree_set_list_hidden (gboolean state)
{
  show_hidden_directories = state;
}

gboolean
tree_get_list_hidden (void)
{
  return show_hidden_directories;
}
