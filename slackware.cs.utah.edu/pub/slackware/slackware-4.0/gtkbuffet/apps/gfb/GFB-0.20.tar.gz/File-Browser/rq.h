/*
   Requests Queue header file
 */

struct reQue
  {
    int reqId;
    gpointer data1, data2;
  };


extern struct reQue requestQ[16];	/* Sixteen requests in queue. I hope, that's enough */
extern int reqs;
enum
  {
    NO_ACTION,
    MAKE_DIR_LIST,
    SELECT_ITEM,
    SELECT_ITEMS,
    SELECT_TREE_ITEM,
    EXPAND_TREE,
    REFRESH_PANELS,
    CHANGE_DIR_LIST_MODE
  };

extern void initQueue (void);
extern void deInitQueue (void);
extern void putRequest (int, gpointer, gpointer);
