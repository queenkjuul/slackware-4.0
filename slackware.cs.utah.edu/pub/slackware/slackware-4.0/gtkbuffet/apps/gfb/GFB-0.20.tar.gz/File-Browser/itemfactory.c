#include <gtk/gtk.h>
#include <strings.h>

#include "init_deinit.h"
#include "filebrowser.h"
#include "make_dir_list.h"
#include "itemfactory.h"
#include "rq.h"

static GtkItemFactory *hGIF = NULL;
/* Temp fix */
static gboolean if_initialised = FALSE;

static void
gtk_ifactory_cb (gpointer callback_data,
		 GFBMenuItemActions callback_action,
		 GtkWidget * widget)
{
  if (!if_initialised)
    return;
  switch (callback_action)
    {
    case REFRESH:
      putRequest (REFRESH_PANELS, NULL, NULL);
      break;
    case SET_LARGE_ICONS:
      putRequest (CHANGE_DIR_LIST_MODE, (void *) LARGE_ICONS, NULL);
      break;
    case SET_SMALL_ICONS:
      putRequest (CHANGE_DIR_LIST_MODE, (void *) SMALL_ICONS, NULL);
      break;
    case SET_LIST_VIEW:
      putRequest (CHANGE_DIR_LIST_MODE, (void *) LIST_VIEW, NULL);
      break;
    default:
      g_message ("MenuItem selected: \"%s\"\n", gtk_item_factory_path_from_widget (widget));
      break;
    };

}

void 
correct_menu_radio_buttons ()
{
  gint hgi1 = LARGE_ICONS;
  GtkWidget *hGW1;
  GSList *hGSL1 = NULL;
  hGW1 = gtk_item_factory_get_widget_by_action (hGIF, SET_LARGE_ICONS);
  hGSL1 = GTK_RADIO_MENU_ITEM (hGW1)->group;
  while (hgi1++ != dir_list_mode)
    hGSL1 = hGSL1->next;
  gtk_check_menu_item_set_active (GTK_CHECK_MENU_ITEM (hGSL1->data), TRUE);
}


static GtkItemFactoryEntry menu_items[] =
{
  {"/_File", NULL, 0, 0, "<Branch>"},
  {"/File/_Open", NULL, gtk_ifactory_cb, OPEN, 0},
  {"/File/_Print", "<control>P", gtk_ifactory_cb, PRINT, 0},
  {"/File/sep1", NULL, 0, 0, "<Separator>"},
  {"/File/Ne_w", NULL, 0, 0, "<Branch>"},
  {"/File/New/_Directory", NULL, gtk_ifactory_cb, NEW_DIR, 0},
  {"/File/New/_File", NULL, gtk_ifactory_cb, 0},
  {"/File/New/_Link", NULL, gtk_ifactory_cb, 0},
  {"/File/sep2", NULL, 0, 0, "<Separator>"},
  {"/File/Dele_te", NULL, gtk_ifactory_cb, 0},
  {"/File/Rena_me", NULL, gtk_ifactory_cb, 0},
  {"/File/P_roperties", NULL, gtk_ifactory_cb, 0},
  {"/File/_Exit", "<control>E", gfb_exit, 0},

  {"/_Edit", NULL, 0, 0, "<Branch>"},
  {"/Edit/Cu_t", "<control>X", gtk_ifactory_cb, 0},
  {"/Edit/_Copy", "<control>C", gtk_ifactory_cb, 0},
  {"/Edit/_Paste", "<control>V", gtk_ifactory_cb, 0},
  {"/Edit/sep3", NULL, 0, 0, "<Separator>"},
  {"/Edit/Select _All", "<control>A", gtk_ifactory_cb, 0},
  {"/Edit/_Invert Selection", NULL, gtk_ifactory_cb, 0},

  {"/_View", NULL, 0, 0, "<Branch>"},
  {"/View/_Toolbar", NULL, gtk_ifactory_cb, 0, "<CheckItem>"},
  {"/View/_Status _Bar", NULL, gtk_ifactory_cb, 0, "<CheckItem>"},
  {"/View/sep4", NULL, 0, 0, "<Separator>"},
  {"/View/Lar_ge Icons", NULL, gtk_ifactory_cb, SET_LARGE_ICONS, "<RadioItem>"},
  {"/View/S_mall Icons", NULL, gtk_ifactory_cb, SET_SMALL_ICONS, "/View/Large Icons"},
  {"/View/_List", NULL, gtk_ifactory_cb, SET_LIST_VIEW, "/View/Small Icons"},
  {"/View/_Details", NULL, gtk_ifactory_cb, SET_DETAILED_VIEW, "/View/List"},
  {"/View/sep5", NULL, 0, 0, "<Separator>"},
  {"/View/Arrange _Icons", NULL, 0, 0, "<Branch>"},
  {"/View/Arrange Icons/by _Name", NULL, gtk_ifactory_cb, 2, "<RadioItem>"},
  {"/View/Arrange Icons/by _Type", NULL, gtk_ifactory_cb, 0, "/View/Arrange Icons/by Name"},
  {"/View/Arrange Icons/by _Size", NULL, gtk_ifactory_cb, 0, "/View/Arrange Icons/by Type"},
  {"/View/Arrange Icons/by _Date", NULL, gtk_ifactory_cb, 0, "/View/Arrange Icons/by Size"},
  {"/View/Arrange Icons/sep6", NULL, 0, 0, "<Separator>"},
  {"/View/Arrange Icons/_Auto Arrange", NULL, gtk_ifactory_cb, 0, "<CheckItem>"},
  {"/View/Lin_e up Icons", NULL, gtk_ifactory_cb, 0,},
  {"/View/sep6", NULL, 0, 0, "<Separator>"},
  {"/View/_Refresh", NULL, gtk_ifactory_cb, REFRESH, 0},
  {"/View/_Options", NULL, gtk_ifactory_cb, 0,},

  {"/_Tools", NULL, 0, 0, "<Branch>"},
  {"/Tools/_Add to Hotlist", NULL, gtk_ifactory_cb, 0,},
  {"/Tools/_Hotlist", NULL, 0, 0, "<Branch>"},
  {"/Tools/Hotlist/Fake 1", NULL, gtk_ifactory_cb, 0,},
  {"/Tools/Hotlist/Fake 2", NULL, gtk_ifactory_cb, 0,},
  {"/Tools/sep7", NULL, 0, 0, "<Separator>"},
  {"/Tools/_Find", NULL, 0, 0, "<Branch>"},
  {"/Tools/Find/_Files or Directories", NULL, gtk_ifactory_cb, 0,},
  {"/Tools/Find/_Computer", NULL, gtk_ifactory_cb, 0,},
  {"/Tools/sep8", NULL, 0, 0, "<Separator>"},
  {"/Tools/_Mount Filesystem", NULL, gtk_ifactory_cb, 0,},
  {"/Tools/_Umount Filesystem", NULL, gtk_ifactory_cb, 0,},
  {"/Tools/sep9", NULL, 0, 0, "<Separator>"},
  {"/Tools/_Go to...", NULL, gtk_ifactory_cb, 0,},

  {"/_Help", NULL, 0, 0, "<LastBranch>"},
  {"/Help/_Help Topics", NULL, gtk_ifactory_cb, 0},
  {"/Help/sep10", NULL, 0, 0, "<Separator>"},
  {"/Help/_About", NULL, gtk_ifactory_cb, 0},
};

void
get_main_menu (GtkWidget * window, GtkWidget ** menubar)
{
  int nmenu_items = sizeof (menu_items) / sizeof (menu_items[0]);
  GtkAccelGroup *accel_group = gtk_accel_group_new ();
  GtkItemFactory *item_factory = gtk_item_factory_new (GTK_TYPE_MENU_BAR, "<Main>", accel_group);
  gtk_item_factory_create_items (item_factory, nmenu_items, menu_items, NULL);
  gtk_accel_group_attach (accel_group, GTK_OBJECT (window));
  /* gtk_window_add_accelerator_table(GTK_WINDOW(window), subfactory->table); */
  *menubar = gtk_item_factory_get_widget (item_factory, "<Main>");
  hGIF = item_factory;
  correct_menu_radio_buttons ();
  if_initialised = TRUE;
}
