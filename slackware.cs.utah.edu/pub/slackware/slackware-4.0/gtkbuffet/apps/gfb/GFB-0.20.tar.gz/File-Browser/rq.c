/*
   Request queue functions
 */
#include <gtk/gtk.h>
#include <glib.h>

#include "common.h"
#include "rq.h"
#include "make_dir_list.h"
#include "tree.h"
#include "debug.h"
#include "gvfs.h"

struct reQue requestQ[16];	/* Sixteen requests in queue. I'm hoping that's enough */
gint reqs, cbTag;

void
putRequest (int reqType, gpointer data1, gpointer data2)
{
  if (reqs >= 15)
    return;
  if (reqType != NO_ACTION)
    requestQ[reqs].reqId = reqType;
  if (data1 != NULL)
    requestQ[reqs].data1 = data1;
  else
    requestQ[reqs].data1 = NULL;
  if (data2 != NULL)
    requestQ[reqs].data2 = data2;
  else
    requestQ[reqs].data2 = NULL;
  reqs++;
}

void
shiftReQ ()
{
  int hi1;
  if (reqs == 0)
    return;
  for (hi1 = 1; hi1 <= 15; hi1++)
    requestQ[hi1 - 1] = requestQ[hi1];
  requestQ[15].reqId = 0;
  requestQ[15].data1 = NULL;
  requestQ[15].data2 = NULL;
  reqs--;
}

int
rqCallBack ()
{
  if (reqs > 0)
    {
      switch (requestQ[0].reqId)
	{
	case MAKE_DIR_LIST:
	  make_dir_list ((char *) (requestQ[0].data1));
	  break;
	case SELECT_TREE_ITEM:
	  //gtk_tree_select_item (GTK_TREE (requestQ[0].data1), (gint) requestQ[0].data2);
	  break;
	case EXPAND_TREE:
	  expand_tree_by_path ((char *) (requestQ[0].data1));
	  break;
	case SELECT_ITEMS:
	  block_select_handlers ();
	  select_items ();
	  unblock_select_handlers ();
	  break;
	case REFRESH_PANELS:
	  make_dir_list ((char *) gvfs_get_current_dir ());
	  break;
	case CHANGE_DIR_LIST_MODE:
	  change_dir_list_mode ((gint) (requestQ[0].data1));
	  break;
	default:
	  debug_out ("Strange reqId");
	  break;
	};
      shiftReQ ();
    };
  return 1;
}


void
initQueue ()
{
  int hi1;
  for (hi1 = 0; hi1 <= 15; hi1++)
    {
      requestQ[hi1].reqId = NO_ACTION;
      requestQ[hi1].data1 = NULL;
      requestQ[hi1].data2 = NULL;
    };
  reqs = 0;
  cbTag = gtk_idle_add ((GtkFunction) rqCallBack, NULL);
}

void
deInitQueue ()
{
  gtk_idle_remove (cbTag);
}
