#define _GNU_SOURCE
#include <assert.h>
#include <rpc/types.h>		/* For HOSTNAME stuff. */
#include <gtk/gtk.h>
#include <strings.h>
#include <stdio.h>
#include "common.h"

GtkWidget *main_window;
GtkWidget *treelist_vbox;
GtkWidget *main_vbox;
GtkWidget *main_menubar;
GtkWidget *main_buttonbar;
GtkWidget *main_hpaned;
GtkWidget *main_treewin;
GtkWidget *main_tree;
GtkWidget *main_listwin;
GtkWidget *main_list;
GtkWidget *main_statusbar;
GtkWidget *main_history_box;
GtkWidget *toolbox_hbox;
GtkWidget *main_toolbox;
gchar *main_titles[] =
{"Filename", "Size", "Permissions", "Date"};
gint main_window_usize_x;
gint main_window_usize_y;
gint main_treewin_usize_x;
gint main_treewin_usize_y;
int IN_ITEM_SELECT = 0;
int IN_MAKE_DIR_LIST = 0;
int IN_TREE_EXPAND = 0;
gint main_window_destroy_handler = 0;

void
append_slash (gchar * path)
{
  int endptr;
  if (path == NULL)
    return;
  endptr = strlen (path);
  if ((char) *(path + endptr - 1) != '/')
    strcat (path, "/");
}

gint
get_widget_width (GtkWidget * widget)
{
  g_return_val_if_fail (widget != NULL, 0);
  g_return_val_if_fail (GTK_IS_WIDGET (widget), 0);

  if (widget->allocation.width >= 2)
    return widget->allocation.width;
  else
    return 0;
}

gint
get_widget_height (GtkWidget * widget)
{
  g_return_val_if_fail (widget != NULL, 0);
  g_return_val_if_fail (GTK_IS_WIDGET (widget), 0);

  if (widget->allocation.width >= 2)
    return widget->allocation.height;
  else
    return 0;
}

gchar *
get_main_window_width ()
{
  gchar *hgc1 = g_malloc0 (8);
  snprintf (hgc1, 7, "%d", get_widget_width (main_window));
  return hgc1;

}

gchar *
get_main_window_height ()
{
  gchar *hgc1 = g_malloc0 (8);
  snprintf (hgc1, 7, "%d", get_widget_height (main_window));
  return hgc1;

}

void
set_main_window_width (gchar * width)
{
  main_window_usize_x = atoi (width);
}

void
set_main_window_height (gchar * height)
{
  main_window_usize_y = atoi (height);
}

gchar *
get_main_treewin_width ()
{
  gchar *hgc1 = g_malloc0 (8);
  main_treewin_usize_x = get_widget_width (main_treewin);
  snprintf (hgc1, 7, "%d", main_treewin_usize_x);
  return hgc1;

}
gchar *
get_main_treewin_height ()
{
  gchar *hgc1 = g_malloc0 (8);
  main_treewin_usize_y = get_widget_height (main_treewin);
  snprintf (hgc1, 7, "%d", main_treewin_usize_y);
  return hgc1;

}

void
set_main_treewin_width (gchar * width)
{
  main_treewin_usize_x = atoi (width);
}

void
set_main_treewin_height (gchar * height)
{
  main_treewin_usize_y = atoi (height);
}
