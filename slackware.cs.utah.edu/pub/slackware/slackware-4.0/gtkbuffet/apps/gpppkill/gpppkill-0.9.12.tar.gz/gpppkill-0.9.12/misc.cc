/*
 *  gpppkill. X11/GTK+ program that kill pppd if it not recive a minimal amount 
 *  of bytes during certain time. It also plot the amount bytes/seg recived.
 *  Copyright (C) 1998  Oliver Schulze L.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  You can reach the author at: 
 *    oliver@pla.net.py
 *
 *  gpppkill Home Page:
 *    http://www.pla.net.py/home/oliver/gpppkill/
 *  
 *  A copy of the GNU General Public License is included with this program.
 */
#include "misc.h"

//######################### Miscelaneus Functions ##############################
//##############################################################################
/*------------------------------------------------------------------------------
 *	Recive una cadena y la muestra en una ventana de dialogo.
 *	Muestra un solo boton: OK 
 *	Al oprimir OK se le llama otra vez a messagebox("", (char *)NULL) para 
 *		cerrar el dialog box y seguir la ejecucion del programa.
 *	La ejecucion del programa se detiene aqui.
 */
void messagebox(char *str, ...)
{
	static GtkWidget	*window = NULL;
	GtkWidget					*button,
										*label,
										*vbox_main,
										*vbox,
										*separador,
										*hbox;
	char *cad;
	va_list ap;	//esta la lista variable de argumentos

	if(!window) {

		window = gtk_window_new(GTK_WINDOW_DIALOG);

		gtk_signal_connect (GTK_OBJECT(window), "destroy",
												GTK_SIGNAL_FUNC(gtk_widget_destroyed),
												&window);

		gtk_signal_connect (GTK_OBJECT(window), "delete_event",
												GTK_SIGNAL_FUNC(delete_event_messagebox),
												NULL);

		gtk_window_set_wmclass(GTK_WINDOW (window), "messagebox", "Gpppkill");
		gtk_window_set_title (GTK_WINDOW (window), PROGRAMA " Message:");
		gtk_window_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
		gtk_container_border_width (GTK_CONTAINER (window), 2*CONTAINER_ANCHO);

		vbox_main = gtk_vbox_new(FALSE, 0);
		gtk_container_add(GTK_CONTAINER(window), vbox_main);
		gtk_widget_show(vbox_main);

		vbox = gtk_vbox_new(FALSE, 0);
		gtk_box_pack_start( GTK_BOX(vbox_main), vbox, FALSE, FALSE, 5);
		gtk_widget_show(vbox);

		separador = gtk_hseparator_new();
		gtk_box_pack_start(GTK_BOX(vbox_main), separador, FALSE, TRUE, 5);
		gtk_widget_show(separador);
		
		hbox = gtk_hbox_new(FALSE, 0);
		gtk_box_pack_start( GTK_BOX(vbox_main), hbox, FALSE, FALSE, 5);
		gtk_widget_show(hbox);

		button = gtk_button_new_with_label ("OK");
		gtk_signal_connect (GTK_OBJECT(button), "clicked",
												GTK_SIGNAL_FUNC(ok_messagebox),
												NULL);

		GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);	
		gtk_box_pack_start ( GTK_BOX(hbox), button, 
												TRUE, FALSE, 10);
		gtk_widget_grab_default (button);
		gtk_widget_show(button);

		label = gtk_label_new((gchar *)str);
		//gtk_misc_set_padding (GTK_MISC(label), 10, 10);
		//gtk_misc_set_alignment(GTK_MISC(label) , 0, 0);
		gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_CENTER);
		gtk_box_pack_start (GTK_BOX(vbox), label, TRUE, TRUE, 5);
		gtk_widget_show (label);

		va_start(ap, str);	//marcar el ultimo argumento fijo
		while( (cad = va_arg(ap, char *)) != NULL )  {
			label = gtk_label_new((gchar *)cad);
			//gtk_misc_set_padding (GTK_MISC(label), 10, 10);
			//gtk_misc_set_alignment(GTK_MISC(label) , 10, 10);
			gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_CENTER);
			gtk_box_pack_start (GTK_BOX(vbox), label, TRUE, TRUE, 5);
			gtk_widget_show (label);
		};
		va_end(ap);	//finalizar la lista de argumento variables	
	}
	else {
		va_start(ap, str);	//marcar el ultimo argumento fijo
		va_end(ap);	//finalizar la lista de argumento variables	
	}

  if (!GTK_WIDGET_VISIBLE (window)) {
		//gtk_window_activate_focus(GTK_WINDOW(window));
		//gtk_widget_grab_focus(window);
		gtk_window_set_policy(GTK_WINDOW(window), 0, 0, 1);
    gtk_grab_add(window);
		gtk_widget_grab_focus(button);
    gtk_widget_show(window);
    gtk_main();
  }
  else {
    gtk_widget_destroy (window);
    gtk_main_quit();
  }
}

/*------------------------------------------------------------------------------
 *	Muestra un mensaje en una ventana dialog por INTERVALO_QUICKMESSAGE seg.
 *		la primera que se la llama muestra el mensaje.
 *		la segunda vez(por medio del timeout), se destruye a si misma.
 */
void quickmessage(char *str, ...)
{
	static GtkWidget	*window = NULL;
	GtkWidget					*label,
										*vbox_main,
										*vbox,
										*frame;
	char *cad;
	int  num_lineas;
	static gint timeout_id;
	
	va_list ap;	//esta la lista variable de argumentos

	if(!window) {

		window = gtk_window_new(GTK_WINDOW_DIALOG);

		gtk_signal_connect (GTK_OBJECT(window), "destroy",
												GTK_SIGNAL_FUNC(gtk_widget_destroyed),
												&window);

		gtk_signal_connect (GTK_OBJECT(window), "delete_event",
												GTK_SIGNAL_FUNC(delete_event_quickmessage),
												&timeout_id);

		gtk_window_set_wmclass(GTK_WINDOW (window), "gpppkill_quickmessage", "Gpppkill");
		gtk_window_set_title (GTK_WINDOW (window), PROGRAMA " QuickMessage" );
		//gtk_window_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
		gtk_window_position(GTK_WINDOW(window), GTK_WIN_POS_MOUSE);
		gtk_container_border_width (GTK_CONTAINER (window), 2*CONTAINER_ANCHO);

		vbox_main = gtk_vbox_new(FALSE, 0);
		gtk_container_add(GTK_CONTAINER(window), vbox_main);
		gtk_widget_show(vbox_main);

		frame = gtk_frame_new(NULL);
		gtk_box_pack_start( GTK_BOX(vbox_main), frame, FALSE, FALSE, 2);
		gtk_widget_show(frame);

		vbox = gtk_vbox_new(FALSE, 5);
		gtk_container_add(GTK_CONTAINER(frame), vbox);
		gtk_widget_show(vbox);

		label = gtk_label_new((gchar *)str);
		//gtk_misc_set_padding (GTK_MISC(label), 10, 10);
		//gtk_misc_set_alignment(GTK_MISC(label) , 0, 0);
		gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_CENTER);
		gtk_box_pack_start (GTK_BOX(vbox), label, TRUE, TRUE, 5);
		gtk_widget_show (label);

		num_lineas = 1;
		va_start(ap, str);	//marcar el ultimo argumento fijo
		while( (cad = va_arg(ap, char *)) != NULL )  {
			label = gtk_label_new((gchar *)cad);
			//gtk_misc_set_padding (GTK_MISC(label), 10, 10);
			//gtk_misc_set_alignment(GTK_MISC(label) , 0, 0);
			gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_CENTER);
			gtk_box_pack_start (GTK_BOX(vbox), label, TRUE, TRUE, 5);
			gtk_widget_show (label);
			num_lineas++;
		};
		va_end(ap);	//finalizar la lista de argumento variables	
	}

  if (!GTK_WIDGET_VISIBLE (window)) {
		//gtk_window_activate_focus(GTK_WINDOW(window));
		//gtk_widget_grab_focus(window);
    gtk_widget_show(window);
    num_lineas = num_lineas * INTERVALO_QUICKMESSAGE;
		//Llamo aqui al timeout para que el tiempo que se vea la ventada se cuente a partir
		//de que sea mostrada con gtk_widget_show().
		timeout_id = gtk_timeout_add( num_lineas, 
																(GtkFunction) quickmessage,
																"");
  }
  else {
		gtk_timeout_remove(timeout_id);
    gtk_widget_destroy(window);
  }
}
