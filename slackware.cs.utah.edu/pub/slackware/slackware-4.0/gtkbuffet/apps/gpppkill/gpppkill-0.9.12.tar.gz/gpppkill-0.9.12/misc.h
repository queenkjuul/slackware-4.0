#ifndef	_MISC_HPP_OSL_
#define _MISC_HPP_OSL_

#include <iostream.h>
#include <gtk/gtk.h>

#include "gpppkill_config.h"
#include "callbacks.h"

//Miscelaneus Functions
void messagebox(char *str, ...);
void quickmessage(char *str, ...);


#endif
