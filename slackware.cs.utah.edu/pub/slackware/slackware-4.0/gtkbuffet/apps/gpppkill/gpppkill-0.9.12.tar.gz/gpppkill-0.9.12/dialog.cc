/*
 *  gpppkill. X11/GTK+ program that kill pppd if it not recive a minimal amount 
 *  of bytes during certain time. It also plot the amount bytes/seg recived.
 *  Copyright (C) 1998  Oliver Schulze L.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  You can reach the author at: 
 *    oliver@pla.net.py
 *
 *  gpppkill Home Page:
 *    http://www.pla.net.py/home/oliver/gpppkill/
 *  
 *  A copy of the GNU General Public License is included with this program.
 */
#include "dialog.h"

// ############################### class dialog ################################

/*------------------------------------------------------------------------------
 *	Pregunta si se quiere terminar el enlace por causa de alguna opcion.
 *	return:
 *		0 -> no se quiere terminar el enlace ppp
 *		1 -> si se quiere terminar el enlace ppp
 */
dialog::dialog(void)
{
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

	gtk_container_border_width (GTK_CONTAINER (window), 2*CONTAINER_ANCHO);

	gtk_signal_connect (GTK_OBJECT(window), "destroy",
											GTK_SIGNAL_FUNC(gtk_widget_destroyed),
											&window);

	construir_box();

	resultado = 0;
}

/*------------------------------------------------------------------------------
 *	Construir los vbox y hbox.
 */
void dialog::construir_box(void)
{
	// el dialog es un vbox dentro de una ventana
	vbox_main = gtk_vbox_new(FALSE, 0);
	gtk_container_add(GTK_CONTAINER(window), vbox_main);
	gtk_widget_show(vbox_main);

	// un vbox encima del separator
	vbox = gtk_vbox_new(FALSE, 0);
	gtk_box_pack_start( GTK_BOX(vbox_main), vbox, FALSE, FALSE, 2);
	gtk_widget_show(vbox);

	// el separator
	separator = gtk_hseparator_new();
	gtk_box_pack_start(GTK_BOX(vbox_main), separator, FALSE, TRUE, 5);
	gtk_widget_show(separator);

	// un hbox debajo del saparator, para los botones.
	hbox = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start( GTK_BOX(vbox_main), hbox, FALSE, FALSE, 5);
	gtk_widget_show(hbox);
}

/*------------------------------------------------------------------------------
*/
GtkWidget *dialog::getwindow(void)
{
	return window;
}

// ############################# class warning #############################

/*------------------------------------------------------------------------------
 *	parameters:
 *		opcion:
 *			1 -> causa idletime_left == 0
 *			2 -> causa onlinetime_left == 0
 */
warning::warning(int opcion)
{
	causa = opcion;

	tiempo_total = 0;

	incremento = 0.01;

	warn_beep = 1;
}

/*------------------------------------------------------------------------------
 */
int warning::mostrar()
{
	if(!tiempo_total)
		return -1;
		
	cargar_widget();
	conectar_signal();
	
	gtk_grab_add(window);	//No permitir focus en la ventana pppkill
	gtk_widget_show(window);

	gtk_main();

	//loop

	//gtk_widget_destroy(window);
	//gtk_main_quit();

	return resultado;
}

/*------------------------------------------------------------------------------
 */
void warning::cargar_widget()
{
	GtkWidget *table;
	char str[120];
	
	// propiedades de la ventana
	gtk_window_set_wmclass(GTK_WINDOW (window), "gpppkill_warning", "Gpppkill");
	gtk_window_set_title (GTK_WINDOW (window), PROGRAMA " Option message" );
	gtk_window_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
	//gtk_window_position(GTK_WINDOW(window), GTK_WIN_POS_MOUSE);

	// linea 1
	sprintf(str, " The pppd is about to be killed. ");
	label = gtk_label_new(str);
	gtk_box_pack_start (GTK_BOX(vbox), label, FALSE, FALSE, 1);
	gtk_widget_show (label);

	// tabla
	table = gtk_table_new(3, 3, FALSE);
	gtk_box_pack_start (GTK_BOX(vbox), table, FALSE, FALSE, 1);
	gtk_widget_show(table);

	//fila 1
	label = gtk_label_new("interface");
	//gtk_table_attach_defaults(GTK_TABLE(table), label, 0, 1, 0, 1);
	gtk_table_attach(GTK_TABLE(table), label, 0, 1, 0, 1,
                  GTK_EXPAND, GTK_EXPAND, 0, 0);
	gtk_widget_show(label);

	label = gtk_label_new(":");
	gtk_table_attach(GTK_TABLE(table), label, 1, 2, 0, 1,
                  GTK_SHRINK, GTK_SHRINK, 0, 0);
	gtk_widget_show(label);

	sprintf(str, "%s", interface);
	label = gtk_label_new(str);
	gtk_table_attach(GTK_TABLE(table), label, 2, 3, 0, 1,
                  GTK_EXPAND, GTK_EXPAND, 0, 0);
	gtk_widget_show(label);

	// fila 2
	label = gtk_label_new("pid");
	gtk_table_attach(GTK_TABLE(table), label, 0, 1, 1, 2,
                  GTK_EXPAND, GTK_EXPAND, 0, 0);
	gtk_widget_show(label);

	label = gtk_label_new(":");
	gtk_table_attach(GTK_TABLE(table), label, 1, 2, 1, 2,
                  GTK_SHRINK, GTK_SHRINK, 0, 0);
	gtk_widget_show(label);

	sprintf(str, "%ld", pppd_pid);
	label = gtk_label_new(str);
	gtk_table_attach(GTK_TABLE(table), label, 2, 3, 1, 2,
                  GTK_EXPAND, GTK_EXPAND, 0, 0);
	gtk_widget_show (label);

	// fila 3
	label = gtk_label_new("cause");
	gtk_table_attach(GTK_TABLE(table), label, 0, 1, 2, 3,
                  GTK_EXPAND, GTK_EXPAND, 0, 0);
	gtk_widget_show(label);

	label = gtk_label_new(":");
	gtk_table_attach(GTK_TABLE(table), label, 1, 2, 2, 3,
                  GTK_SHRINK, GTK_SHRINK, 0, 0);
	gtk_widget_show(label);

	if(causa == 1)
		label = gtk_label_new("idletime option");
	else
		label = gtk_label_new("onlinetime option");
	gtk_table_attach(GTK_TABLE(table), label, 2, 3, 2, 3,
                  GTK_EXPAND, GTK_EXPAND, 0, 0);
	gtk_widget_show (label);

	// linea 5
	//           "---------------------------------"
	sprintf(str, " What would you like to do?      ");
	label = gtk_label_new(str);
	gtk_box_pack_start (GTK_BOX(vbox), label, TRUE, TRUE, 1);
	gtk_widget_show (label);

	// progres bar
	pbar = gtk_progress_bar_new ();
	gtk_widget_set_events (pbar, GDK_ENTER_NOTIFY_MASK | GDK_LEAVE_NOTIFY_MASK);
	gtk_widget_set_usize (pbar, 200, 20);
	gtk_box_pack_start (GTK_BOX (vbox), pbar, TRUE, TRUE, 0);
	gtk_widget_show (pbar);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip (tooltips, pbar, " Countdown is in progress... ", "");
	gtk_tooltips_set_delay (tooltips, 0);

	// botones
	ok_button = gtk_button_new_with_label (" kill ppp ");
	GTK_WIDGET_SET_FLAGS (ok_button, GTK_CAN_DEFAULT);	
	gtk_box_pack_start ( GTK_BOX(hbox), ok_button, 
											TRUE, FALSE, 10);
	gtk_widget_grab_default (ok_button);
	gtk_widget_show(ok_button);

	if(causa == 1)
		cancel_button = gtk_button_new_with_label ("  Restart idletime  ");
	else
		cancel_button = gtk_button_new_with_label (" Restart onlinetime ");
	GTK_WIDGET_SET_FLAGS (cancel_button, GTK_CAN_DEFAULT);	
	gtk_box_pack_start ( GTK_BOX(hbox), cancel_button, 
											TRUE, FALSE, 10);
	gtk_widget_show(cancel_button);
}

/*------------------------------------------------------------------------------
 */
void warning::conectar_signal()
{
	gtk_signal_connect (GTK_OBJECT(window), "delete_event",
											GTK_SIGNAL_FUNC(warning_delete_event_callback),
											this);
	//callbacks
	gtk_signal_connect (GTK_OBJECT(ok_button), "clicked",
											GTK_SIGNAL_FUNC(warning_ok_callback),
											this);
	gtk_signal_connect (GTK_OBJECT(cancel_button), "clicked",
											GTK_SIGNAL_FUNC(warning_cancel_callback),
											this);

	timeout_id = gtk_timeout_add(intervalo, warning_timeout_callback, this);
}

/*------------------------------------------------------------------------------
 */
void warning::quit()
{
  gtk_timeout_remove(timeout_id);
	gtk_main_quit();
	gtk_widget_destroy(window);

}


// --- set
/*------------------------------------------------------------------------------
 */
void warning::settiempo_total(int total)
{
	total = total * 1000;	//total esta en segundos, pasar a mseg.
	tiempo_total = total;
	intervalo = total/100;	//el progress bar tiene 100 pasos
}

/*------------------------------------------------------------------------------
 */
void warning::setpppd_pid(long pid)
{
	pppd_pid = pid;
}

/*------------------------------------------------------------------------------
 */
void warning::setinterface(char *str)
{
	strcpy(interface, str);
}

/*------------------------------------------------------------------------------
 */
void warning::setwarn_beep(char beep)
{
	warn_beep = beep;
}

//------------------------------- callback -------------------------------------

/*------------------------------------------------------------------------------
 */
void warning_ok_callback(GtkButton *button, warning *w)
{
	w->resultado = 1;
	
	w->quit();
}

/*------------------------------------------------------------------------------
 */
void warning_cancel_callback(GtkButton *button, warning *w)
{
	w->resultado = 0;
	w->quit();
}

/*------------------------------------------------------------------------------
 */
gint warning_timeout_callback(warning *w)
{
	gfloat val;
/*
	static long tiempo = 0;
	static char str[30];
	
	tiempo += w->intervalo;	//aumentar un intervalo mas hasta que sea multiplo de 1000, osea 1 seg.


	g_print("timepo: %ld\n", tiempo);
	if( !(tiempo%1000) ) {
		sprintf(str, "seconds left: %d", ((w->tiempo_total)-(int)tiempo)/1000);
		gtk_label_set(GTK_LABEL(w->label_time), str);
		gdk_beep();
		//g_print("quedan: %d segundos\n", (w->tiempo_total)-(int)tiempo);
	}
*/
	int beep;

	val = GTK_PROGRESS_BAR(w->pbar)->percentage;
	//g_print("val: %f\n", val);

	if(w->warn_beep) {
		beep = (int)(val*100);
		beep++;
		if( !(beep%10) || (beep==1))
			gdk_beep();
	}
	
	if(val < 1.0) {
		val += (w->incremento);
		gtk_progress_bar_update(GTK_PROGRESS_BAR(w->pbar), val);
		return gtk_true();
	}
	else {
		w->resultado = 1;
		w->quit();
		//return gtk_false();	//remuevo el timeout
		return gtk_true();	//no remuevo el timeout
	}
}

// X11 callback
/*------------------------------------------------------------------------------
 *	Si retorno FALSE, gtk envia la signal destroy al widget
 */
gint warning_delete_event_callback(GtkWidget *widget, GdkEventAny *event, warning *w)
{
	w->resultado = 0;
	w->quit();
	
	//return gtk_false();
	return gtk_true();
}
