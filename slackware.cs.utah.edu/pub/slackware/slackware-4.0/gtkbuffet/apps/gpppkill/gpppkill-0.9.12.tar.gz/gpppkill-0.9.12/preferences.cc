/*
 *  gpppkill. X11/GTK+ program that kill pppd if it not recive a minimal amount 
 *  of bytes during certain time. It also plot the amount bytes/seg recived.
 *  Copyright (C) 1998  Oliver Schulze L.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  You can reach the author at: 
 *    oliver@pla.net.py
 *
 *  gpppkill Home Page:
 *    http://www.pla.net.py/home/oliver/gpppkill/
 *  
 *  A copy of the GNU General Public License is included with this program.
 */
#include "preferences.h"

//########################## class preferences ###########################

//------------------------------------------------------------------------------
preferences::preferences(gpppkill *g)
{
	gpppk = g;
	glist_interface = NULL;

	idletime = 0;
	onlinetime = 0;
	interface = 0;
	byte_in = 0;
	byte_out = 0;
	option_warn = 0;
	warntime = 0;
	warn_beep = 0;
	idletime_button = 0;
	onlinetime_button = 0;
}

/*------------------------------------------------------------------------------
 */
int preferences::mostrar(void)
{

	gtk_window_set_title(GTK_WINDOW(window), PROGRAMA " " VERSION " Preferences");
	gtk_window_position( GTK_WINDOW(window), GTK_WIN_POS_MOUSE);

	cargar_widget();
	conectar_signal();

	gtk_grab_add(window);	//No permitir focus en la ventana pppkill
	gtk_widget_show(window);
	gtk_main();

	// loop

	g_list_free(glist_interface);
	glist_interface = NULL;
	
	resultado = interface;

	return resultado;
}

/*------------------------------------------------------------------------------
 */
void preferences::cargar_widget(void)
{
	//este es el vbox que pongo en el container window
	//vbox_main = gtk_vbox_new(FALSE, 2);
	//gtk_container_add(GTK_CONTAINER(window), vbox_main);
	//gtk_widget_show(vbox_main);

	//cargar el notebook
	cargar_notebook();

	//cargo un separador a vbox_main
	//separador = gtk_hseparator_new();
	//gtk_box_pack_start(GTK_BOX(vbox_main), separador, FALSE, TRUE, 5);
	//gtk_widget_show(separador);
	
	//cargo los botones
	cargar_botones();

	//-------------- mostrar todo ------------
	//gtk_window_activate_focus(GTK_WINDOW(window));
	//gtk_widget_grab_focus(window);
}

/*------------------------------------------------------------------------------
 */
void preferences::conectar_signal(void)
{
	gtk_signal_connect (GTK_OBJECT(window), "delete_event",
												GTK_SIGNAL_FUNC(preferences_delete_event_callback),
												this);

	// para ver si se cambio de estado spinner_idle_*
	gtk_signal_connect (GTK_OBJECT(spinner_idle_h), "changed", 
                      GTK_SIGNAL_FUNC (preferences_idletime_callback), this);
	gtk_signal_connect (GTK_OBJECT(spinner_idle_m), "changed", 
                      GTK_SIGNAL_FUNC (preferences_idletime_callback), this);
	gtk_signal_connect (GTK_OBJECT(spinner_idle_s), "changed", 
                      GTK_SIGNAL_FUNC (preferences_idletime_callback), this);

	// para ver si se cambio de estado spinner_online_*
	gtk_signal_connect (GTK_OBJECT(spinner_online_h), "changed", 
                      GTK_SIGNAL_FUNC (preferences_onlinetime_callback), this);
	gtk_signal_connect (GTK_OBJECT(spinner_online_m), "changed", 
                      GTK_SIGNAL_FUNC (preferences_onlinetime_callback), this);
	gtk_signal_connect (GTK_OBJECT(spinner_online_s), "changed", 
                      GTK_SIGNAL_FUNC (preferences_onlinetime_callback), this);

	// lo que cambia en realidad es el entry del widget combo. (combo->entry)
	gtk_signal_connect (GTK_OBJECT(GTK_COMBO(combo)->entry), "changed", 
                      GTK_SIGNAL_FUNC (preferences_combo_callback), this);

	// botones OK | CANCEL
	gtk_signal_connect (GTK_OBJECT(button_ok), "clicked",
											GTK_SIGNAL_FUNC(preferences_ok_callback),
											this);

	gtk_signal_connect (GTK_OBJECT(button_cancel), "clicked",
											GTK_SIGNAL_FUNC(preferences_cancel_callback),
											this);

	// max byte in, max byte out
	gtk_signal_connect (GTK_OBJECT(spinner_byte_in), "changed", 
                      GTK_SIGNAL_FUNC (preferences_byte_in_callback), this);

	gtk_signal_connect (GTK_OBJECT(spinner_byte_out), "changed", 
                      GTK_SIGNAL_FUNC (preferences_byte_out_callback), this);

	// warnnings
	gtk_signal_connect(GTK_OBJECT(button_option_warn), "toggled",
	                   GTK_SIGNAL_FUNC(preferences_button_option_warn_callback), this);

	gtk_signal_connect(GTK_OBJECT(spinner_warntime), "changed",
	                   GTK_SIGNAL_FUNC(preferences_spinner_warntime_callback), this);

	gtk_signal_connect(GTK_OBJECT(button_warn_beep), "toggled",
	                   GTK_SIGNAL_FUNC(preferences_button_warn_beep_callback), this);

	// start up options 
	gtk_signal_connect (GTK_OBJECT(idletime_on_button), "toggled",
                      GTK_SIGNAL_FUNC (preferences_idletime_button_callback), this);

	gtk_signal_connect (GTK_OBJECT(onlinetime_on_button), "toggled",
                      GTK_SIGNAL_FUNC (preferences_onlinetime_button_callback), this);

}

/*------------------------------------------------------------------------------
 */
void preferences::quit(void)
{
	gtk_widget_destroy(window);
	gtk_main_quit();
}

/*------------------------------------------------------------------------------
 *	Carga el notebook a un vbox.
 */
void preferences::cargar_notebook(void)
{
	GtkWidget	*frame,
						*vbox_frame,
						*notebook,
						*label;

	//creo un notebook y lo coloco en el vbox_main
	notebook = gtk_notebook_new ();
	gtk_notebook_set_tab_pos (GTK_NOTEBOOK (notebook), GTK_POS_TOP);
	gtk_box_pack_start(GTK_BOX(vbox), notebook, FALSE, FALSE, 5);
	gtk_widget_show(notebook);

	// --- pagina UNO ---
	//creo un frame y lo coloco en la primera hoja del notebook
	frame = gtk_frame_new("pppkill Options");
	gtk_container_border_width(GTK_CONTAINER(frame), CONTAINER_ANCHO);
	label = gtk_label_new(" Times/Interface ");
	gtk_notebook_append_page(GTK_NOTEBOOK (notebook), frame, label);
	gtk_widget_show(frame);

	//creo un vbox y lo coloco dentro de frame
	vbox_frame = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(frame), vbox_frame);
	gtk_widget_show(vbox_frame);

	//cargo el vbox_frame
	cargar_spinner_idle(vbox_frame);
	cargar_spinner_online(vbox_frame);
	cargar_interface(vbox_frame);

	// --- pagina DOS ---
	frame = gtk_frame_new("Bytes in/out");
	gtk_container_border_width(GTK_CONTAINER(frame), CONTAINER_ANCHO);
	label = gtk_label_new(" Bytes ");
	gtk_notebook_append_page(GTK_NOTEBOOK (notebook), frame, label);
	gtk_widget_show(frame);

	//creo un vbox y lo coloco dentro de frame
	vbox_frame = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(frame), vbox_frame);
	gtk_widget_show(vbox_frame);

	//cargar en contenido de la pagina 2
	cargar_byte_in(vbox_frame);
	cargar_byte_out(vbox_frame);

	// --- pagina TRES ---
	frame = gtk_frame_new("Warnings messages");
	gtk_container_border_width(GTK_CONTAINER(frame), CONTAINER_ANCHO);
	label = gtk_label_new(" Warnings ");
	gtk_notebook_append_page(GTK_NOTEBOOK (notebook), frame, label);
	gtk_widget_show(frame);

	//creo un vbox y lo coloco dentro de frame
	vbox_frame = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(frame), vbox_frame);
	gtk_widget_show(vbox_frame);

	//cargar en contenido de la pagina 3
	cargar_option_warning(vbox_frame);

	// --- pagina CUATRO ---
	frame = gtk_frame_new("Start Up Options");
	gtk_container_border_width(GTK_CONTAINER(frame), CONTAINER_ANCHO);
	label = gtk_label_new(" Start Up ");
	gtk_notebook_append_page(GTK_NOTEBOOK (notebook), frame, label);
	gtk_widget_show(frame);

	//creo un vbox y lo coloco dentro de frame
	vbox_frame = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(frame), vbox_frame);
	gtk_widget_show(vbox_frame);

	//cargar en contenido de la pagina 4
	cargar_idletime_on(vbox_frame);
	cargar_onlinetime_on(vbox_frame);
}

/*------------------------------------------------------------------------------
 *	Carga un hbox con un label y spinner a un vbox.
 */
void preferences::cargar_spinner_idle(GtkWidget *vbox)
{
	GtkWidget	*event_box,
						*hbox_aux,
						*label;
	GtkTooltips   *tooltips;
	GtkAdjustment *adj;

	//-------------- idletime ----------------
	hbox_aux  = gtk_hbox_new(FALSE, 0);
	event_box = gtk_event_box_new ();

	label = gtk_label_new("Maximal idle time :");
	//gtk_misc_set_padding (GTK_MISC(label), 10, 10);
	//gtk_misc_set_alignment(GTK_MISC(label) , 1, 0);

	//colocar el label en el event box
	gtk_container_add(GTK_CONTAINER(event_box) , label);
	gtk_widget_show(label);

	//colcar el event_box en el hbox
	gtk_box_pack_start(GTK_BOX(hbox_aux), event_box, FALSE, FALSE, 10);
	gtk_widget_show(event_box);

	// --- spinner seconds
	adj = (GtkAdjustment *) gtk_adjustment_new (gpppk->getidletime()%60, 0.0,
																							59.0, 1.0, 
																							5.0    , 0.0);
	spinner_idle_s = gtk_spin_button_new (adj, 1.0, 0);
	gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner_idle_s), TRUE);
	gtk_widget_set_usize(spinner_idle_s, 40, 0);
	gtk_spin_button_set_update_policy(GTK_SPIN_BUTTON(spinner_idle_s), GTK_UPDATE_SNAP_TO_TICKS);
	gtk_box_pack_end (GTK_BOX(hbox_aux), spinner_idle_s, FALSE, FALSE, 10);
	gtk_widget_show(spinner_idle_s);

	label = gtk_label_new("S:");
	gtk_box_pack_end(GTK_BOX(hbox_aux), label, FALSE, FALSE, 1);
	gtk_widget_show(label);

	// --- spinner minute
	adj = (GtkAdjustment *) gtk_adjustment_new ( (gpppk->getidletime()/60)%60, 0.0, 
																							59.0, 1.0, 
																							5.0    , 0.0);
	spinner_idle_m = gtk_spin_button_new (adj, 1.0, 0);
	gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner_idle_m), TRUE);
	gtk_widget_set_usize(spinner_idle_m, 40, 0);
	gtk_spin_button_set_update_policy(GTK_SPIN_BUTTON(spinner_idle_m), GTK_UPDATE_SNAP_TO_TICKS);
	gtk_box_pack_end (GTK_BOX(hbox_aux), spinner_idle_m, FALSE, FALSE, 10);
	gtk_widget_show(spinner_idle_m);

	label = gtk_label_new("M:");
	gtk_box_pack_end(GTK_BOX(hbox_aux), label, FALSE, FALSE, 1);
	gtk_widget_show(label);

	// --- spinner hour
	adj = (GtkAdjustment *) gtk_adjustment_new (gpppk->getidletime()/3600, 0.0,
																							999999.0, 1.0, 
																							5.0    , 0.0);
	spinner_idle_h = gtk_spin_button_new (adj, 1.0, 0);
	gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner_idle_h), TRUE);
	gtk_widget_set_usize(spinner_idle_h, 65, 0);
	gtk_spin_button_set_update_policy(GTK_SPIN_BUTTON(spinner_idle_h), GTK_UPDATE_SNAP_TO_TICKS);
	gtk_box_pack_end (GTK_BOX(hbox_aux), spinner_idle_h, FALSE, FALSE, 10);
	gtk_widget_show(spinner_idle_h);

	label = gtk_label_new("H:");
	gtk_box_pack_end(GTK_BOX(hbox_aux), label, FALSE, FALSE, 1);
	gtk_widget_show(label);


	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, event_box   , "This es the maximal amount of idle (inactivity) time to wait before stoping pppd", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, spinner_idle_h, "hours", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, spinner_idle_m, "minutes", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, spinner_idle_s, "seconds", "");

	//gtk_box_pack_start( GTK_BOX( GTK_DIALOG (window)->vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_box_pack_start( GTK_BOX(vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_widget_show(hbox_aux);
}

/*------------------------------------------------------------------------------
 *	Carga un hbox con un label y spinner a un vbox.
 */
void preferences::cargar_spinner_online(GtkWidget *vbox)
{
	GtkWidget	*event_box,
						*hbox_aux,
						*label;
	GtkTooltips   *tooltips;
	GtkAdjustment *adj;

	//-------------- idletime ----------------
	hbox_aux  = gtk_hbox_new(FALSE, 0);
	event_box = gtk_event_box_new ();

	label = gtk_label_new("Maximal online time:");
	//gtk_misc_set_padding (GTK_MISC(label), 10, 10);
	//gtk_misc_set_alignment(GTK_MISC(label) , 1, 0);

	//colocar el label en el event box
	gtk_container_add(GTK_CONTAINER(event_box) , label);
	gtk_widget_show(label);

	//colcar el event_box en el hbox
	gtk_box_pack_start(GTK_BOX(hbox_aux), event_box, FALSE, FALSE, 10);
	gtk_widget_show(event_box);

	// --- second
	adj = (GtkAdjustment *) gtk_adjustment_new (gpppk->getonlinetime()%60, 0.0, 
																							59.0, 1.0, 
																							5.0    , 0.0);
	spinner_online_s = gtk_spin_button_new (adj, 1.0, 0);
	gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner_online_s), TRUE);
	gtk_widget_set_usize(spinner_online_s, 40, 0);
	gtk_box_pack_end (GTK_BOX(hbox_aux), spinner_online_s, FALSE, FALSE, 10);
	gtk_widget_show(spinner_online_s);

	label = gtk_label_new("S:");
	gtk_box_pack_end(GTK_BOX(hbox_aux), label, FALSE, FALSE, 1);
	gtk_widget_show(label);
	
	// --- minute
	adj = (GtkAdjustment *) gtk_adjustment_new ( (gpppk->getonlinetime()/60)%60, 0.0, 
																							59.0, 1.0, 
																							5.0    , 0.0);
	spinner_online_m = gtk_spin_button_new (adj, 1.0, 0);
	gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner_online_m), TRUE);
	gtk_widget_set_usize(spinner_online_m, 40, 0);
	gtk_box_pack_end (GTK_BOX(hbox_aux), spinner_online_m, FALSE, FALSE, 10);
	gtk_widget_show(spinner_online_m);

	label = gtk_label_new("M:");
	gtk_box_pack_end(GTK_BOX(hbox_aux), label, FALSE, FALSE, 1);
	gtk_widget_show(label);

	// --- hour
	adj = (GtkAdjustment *) gtk_adjustment_new (gpppk->getonlinetime()/3600, 0.0, 
																							999999.0, 1.0, 
																							5.0    , 0.0);
	spinner_online_h = gtk_spin_button_new (adj, 1.0, 0);
	gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner_online_h), TRUE);
	gtk_widget_set_usize(spinner_online_h, 65, 0);
	gtk_box_pack_end (GTK_BOX(hbox_aux), spinner_online_h, FALSE, FALSE, 10);
	gtk_widget_show(spinner_online_h);

	label = gtk_label_new("H:");
	gtk_box_pack_end(GTK_BOX(hbox_aux), label, FALSE, FALSE, 1);
	gtk_widget_show(label);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, event_box   , "This the maximal amount of time that the ppp will stay up.", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, spinner_online_h, "hours", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, spinner_online_m, "minutes", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, spinner_online_s, "seconds", "");


	//gtk_box_pack_start( GTK_BOX( GTK_DIALOG (window)->vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_box_pack_start( GTK_BOX(vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_widget_show(hbox_aux);
}

/*------------------------------------------------------------------------------
 *	Carga un hbox(con un label y spinner adentro) a un vbox.
 */
void preferences::cargar_byte_in(GtkWidget *vbox) 
{
	GtkWidget	*event_box,
						*hbox_aux,
						*label;
	GtkTooltips   *tooltips;
	GtkAdjustment *adj;

	//-------------- transmicion minima -------------
	hbox_aux  = gtk_hbox_new(FALSE, 0);
	event_box = gtk_event_box_new ();

	label = gtk_label_new("Minimal bytes in:");
	//gtk_misc_set_padding (GTK_MISC(label), 10, 10);
	//gtk_misc_set_alignment(GTK_MISC(label) , 1, 0);
	gtk_widget_show(label);

	//colocar el label en el event box
	gtk_container_add(GTK_CONTAINER(event_box) , label);
	gtk_widget_show(event_box);

	gtk_box_pack_start (GTK_BOX(hbox_aux), event_box, FALSE, FALSE, 10);

	adj = (GtkAdjustment *) gtk_adjustment_new (gpppk->getbyte_min_in(), 1.0, 
																							32767.0, 1.0, 
																							5.0, 0.0);
	spinner_byte_in = gtk_spin_button_new (adj, 1.0, 0);	//acelerado
	gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner_byte_in), TRUE);
	gtk_widget_set_usize(spinner_byte_in, 65, 22);
	//gtk_spin_button_set_numeric ((GtkSpinButton *)spinner_byte, (guint)1);
	gtk_box_pack_end (GTK_BOX(hbox_aux), spinner_byte_in, FALSE, FALSE, 10);
	gtk_widget_show(spinner_byte_in);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, event_box   , "If you recive less bytes/sec than this amount, the ppp link is in inactivity", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, spinner_byte_in, "If you recive less bytes/sec than this amount, the ppp link is in inactivity", "");

	//gtk_box_pack_start(GTK_BOX( GTK_DIALOG (window)->vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_box_pack_start(GTK_BOX(vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_widget_show(hbox_aux);
}

/*------------------------------------------------------------------------------
 *	Carga un hbox(con un label y spinner adentro) a un vbox.
 */
void preferences::cargar_byte_out(GtkWidget *vbox) 
{
	GtkWidget	*event_box,
						*hbox_aux,
						*label;
	GtkTooltips   *tooltips;
	GtkAdjustment *adj;

	//-------------- transmicion minima -------------
	hbox_aux  = gtk_hbox_new(FALSE, 0);
	event_box = gtk_event_box_new ();

	label = gtk_label_new("Minimal bytes out:");
	//gtk_misc_set_padding (GTK_MISC(label), 10, 10);
	//gtk_misc_set_alignment(GTK_MISC(label) , 1, 0);
	gtk_widget_show(label);

	//colocar el label en el event box
	gtk_container_add(GTK_CONTAINER(event_box) , label);
	gtk_widget_show(event_box);

	gtk_box_pack_start (GTK_BOX(hbox_aux), event_box, FALSE, FALSE, 10);

	adj = (GtkAdjustment *) gtk_adjustment_new (gpppk->getbyte_min_out(), 1.0, 
																							32767.0, 1.0, 
																							5.0, 0.0);
	spinner_byte_out = gtk_spin_button_new (adj, 1.0, 0);	//acelerado
	gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner_byte_out), TRUE);
	gtk_widget_set_usize(spinner_byte_out, 65, 22);
	//gtk_spin_button_set_numeric ((GtkSpinButton *)spinner_byte, (guint)1);
	gtk_box_pack_end (GTK_BOX(hbox_aux), spinner_byte_out, FALSE, FALSE, 10);
	gtk_widget_show(spinner_byte_out);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, event_box   , "If you recive less bytes/sec than this amount, the ppp link is in inactivity", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, spinner_byte_out, "If you recive less bytes/sec than this amount, the ppp link is in inactivity", "");

	//gtk_box_pack_start(GTK_BOX( GTK_DIALOG (window)->vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_box_pack_start(GTK_BOX(vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_widget_show(hbox_aux);
}

/*------------------------------------------------------------------------------
 *	Cargar un hbox(con un label y un combo adentro) a un vbox
 */
void preferences::cargar_interface(GtkWidget *vbox)
{
	GtkWidget	*event_box,
						*hbox_aux,
						*label;
	GtkTooltips   *tooltips;
	int   num_e = 0;
	int   i;

	//------------------- interface -----------------
	hbox_aux  = gtk_hbox_new(FALSE, 0);
	event_box = gtk_event_box_new ();

	label = gtk_label_new("ppp Interface name:");
	//gtk_misc_set_padding (GTK_MISC(label), 10, 10);
	//gtk_misc_set_alignment(GTK_MISC(label) , 1, 0);
	gtk_widget_show(label);

	//colocar el label en el event box
	gtk_container_add(GTK_CONTAINER(event_box) , label);
	gtk_widget_show(event_box);

	gtk_box_pack_start (GTK_BOX(hbox_aux), event_box, FALSE, FALSE, 10);

	//actualizar la lista de pppd que estan corriendo
	gpppk->borrar_dlista_pid();
	gpppk->cargar_dlista_pid();
		
	num_e = (gpppk->getdlista_pid())->numero_de_elementos();
	if(num_e) {
		for(i = 1; i<=num_e; i++) {
			glist_interface = g_list_append(glist_interface, 
												(gpppk->getdlista_pid())->get_dnodo_interface(i));
		}
	}
	else {
		glist_interface = g_list_append(glist_interface, STR_NO_PPPD);
	}

	combo = gtk_combo_new ();
	gtk_combo_set_popdown_strings (GTK_COMBO (combo), glist_interface);
	gtk_widget_set_usize(GTK_WIDGET(GTK_COMBO(combo)->entry), 48, 22);
	gtk_combo_set_value_in_list( GTK_COMBO(combo), 1, 0);
	gtk_combo_set_use_arrows_always( GTK_COMBO(combo), 1);
	gtk_entry_set_editable( GTK_ENTRY(GTK_COMBO(combo)->entry), FALSE);
	gtk_box_pack_end (GTK_BOX (hbox_aux), combo, FALSE, FALSE, 10);
	gtk_widget_show (combo);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, event_box,
	"This is the name of the ppp interface from which to obtain the statistic", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, combo    , 
	"This is the name of the ppp interface from which to obtain the statistic", "");

	if( !num_e )
		gtk_widget_set_sensitive(label, gtk_false());

	//gtk_box_pack_start( GTK_BOX ( GTK_DIALOG (window)->vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_box_pack_start( GTK_BOX(vbox), hbox_aux, TRUE, TRUE, 3);
	gtk_widget_show(hbox_aux);
}

/*------------------------------------------------------------------------------
 *	Cargar un hbox(con dos botones OK y CANCEL adentro) en un vbox.
 */
void preferences::cargar_botones(void)
{
	//cargo un hbox a vbox
	//hbox = gtk_hbox_new(TRUE, 0);
	//gtk_box_pack_start( GTK_BOX(vbox), hbox, FALSE, FALSE, 5);
	//gtk_widget_show(hbox);

	//------------------- botones ----------------
	button_ok = gtk_button_new_with_label("   OK   ");

	button_cancel = gtk_button_new_with_label(" CANCEL ");

	GTK_WIDGET_SET_FLAGS(button_ok, GTK_CAN_DEFAULT);	
	//GTK_WIDGET_SET_FLAGS(button_ok, GTK_HAS_FOCUS);	
	//gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window)->action_area), button_ok, TRUE, FALSE, 10);
	gtk_box_pack_start (GTK_BOX(hbox), button_ok, TRUE, FALSE, 10);
	gtk_widget_show(button_ok);
	//gtk_widget_set_sensitive(button_ok, gtk_false());

	GTK_WIDGET_SET_FLAGS(button_cancel, GTK_CAN_DEFAULT);	
	//GTK_WIDGET_SET_FLAGS(button_cancel, GTK_HAS_FOCUS);	
	//GTK_WIDGET_SET_FLAGS(button_cancel, GTK_HAS_DEFAULT);	
	//gtk_box_pack_start(GTK_BOX (GTK_DIALOG (window)->action_area), button_cancel, TRUE, FALSE, 10);
	gtk_box_pack_start(GTK_BOX(hbox), button_cancel, TRUE, FALSE, 10);
	gtk_widget_show(button_cancel);

	button_ok_sensitive();	//estados iniciales de los botones
}

/*------------------------------------------------------------------------------
 */
void preferences::cargar_option_warning(GtkWidget *vbox)
{
	GtkWidget *frame_warn,
	          *vbox_warn,
	          *event_box,
						*hbox_aux;
	GtkTooltips   *tooltips;
	GtkAdjustment *adj;

	frame_warn = gtk_frame_new("Options warnings");
	gtk_container_border_width(GTK_CONTAINER(frame_warn), CONTAINER_ANCHO);
	gtk_box_pack_start(GTK_BOX(vbox), frame_warn, TRUE, TRUE, 3);
	gtk_widget_show(frame_warn);

	vbox_warn = gtk_vbox_new(FALSE, 0);
	gtk_container_add(GTK_CONTAINER(frame_warn), vbox_warn);
	gtk_widget_show(vbox_warn);

	// --- boton_option_warn
	button_option_warn = gtk_check_button_new_with_label("Option warning");
	gtk_widget_show(button_option_warn);

	if(gpppk->rc->load_option_warn())
		gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button_option_warn), TRUE);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, button_option_warn, "Show a warning message when an option is trying to kill the pppd?", "");

	gtk_box_pack_start(GTK_BOX(vbox_warn), button_option_warn, TRUE, TRUE, 0);

	// --- spinner_warntime
	hbox_aux  = gtk_hbox_new(FALSE, 0);
	event_box = gtk_event_box_new ();

	label_warntime = gtk_label_new("Seconds to warn before kill the pppd: ");
	gtk_widget_show(label_warntime);

	//colocar el label en el event box
	gtk_container_add(GTK_CONTAINER(event_box) , label_warntime);
	gtk_box_pack_start (GTK_BOX(hbox_aux), event_box, FALSE, FALSE, 10);
	gtk_widget_show(event_box);

	adj = (GtkAdjustment *) gtk_adjustment_new (gpppk->getwarntime(), 0.0, 
																							59.0, 1.0, 
																							5.0 , 0.0);
	spinner_warntime = gtk_spin_button_new (adj, 1.0, 0);	//acelerado
	gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner_warntime), TRUE);
	gtk_widget_set_usize(spinner_warntime, 40, 0);
	gtk_box_pack_end (GTK_BOX(hbox_aux), spinner_warntime, FALSE, FALSE, 10);
	gtk_widget_show(spinner_warntime);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, event_box, "How many seconds do you want " PROGRAMA " warn you that the pppd is about to be stoped?", "");
	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, spinner_warntime, "How many seconds do you want " PROGRAMA " warn you that the pppd is about to be stoped?", "");

	gtk_box_pack_start(GTK_BOX(vbox_warn), hbox_aux, TRUE, TRUE, 0);
	gtk_widget_show(hbox_aux);

	// --- button_warn_beep
	button_warn_beep = gtk_check_button_new_with_label("Audible warning (beep)");
	gtk_widget_show(button_warn_beep);

	if(gpppk->rc->load_warn_beep())
		gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button_warn_beep), TRUE);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, button_warn_beep, "Use an audible bell, alias beep?", "");

	gtk_box_pack_start(GTK_BOX(vbox_warn), button_warn_beep, TRUE, TRUE, 0);

	option_warn_sensitive();
}

/*------------------------------------------------------------------------------
 *	Carga un toggle button en un vbox.
 */
void preferences::cargar_idletime_on(GtkWidget *vbox) 
{
	GtkTooltips *tooltips;

	idletime_on_button = gtk_check_button_new_with_label ("Start idle_time option on start up");
	gtk_widget_show(idletime_on_button);

	if(gpppk->rc->load_idletime_on())
		gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(idletime_on_button), TRUE);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, idletime_on_button, "Start the idle_time option when " PROGRAMA " start?", "");

	gtk_box_pack_start(GTK_BOX(vbox), idletime_on_button, TRUE, TRUE, 3);
}

/*------------------------------------------------------------------------------
 *	Carga un toggle button en un vbox.
 */
void preferences::cargar_onlinetime_on(GtkWidget *vbox) 
{
	GtkTooltips *tooltips;

	onlinetime_on_button = gtk_check_button_new_with_label ("Start online_time on start up.");
	gtk_widget_show(onlinetime_on_button);

	if(gpppk->rc->load_onlinetime_on())
		gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(onlinetime_on_button), TRUE);

	tooltips = gtk_tooltips_new();
	gtk_tooltips_set_tip(tooltips, onlinetime_on_button, "Start the online_time option when " PROGRAMA " start?", "");

	gtk_box_pack_start(GTK_BOX(vbox), onlinetime_on_button, TRUE, TRUE, 3);
}

/*------------------------------------------------------------------------------
 *	Setea el frame_warn un/sensitive de acuerdo a:
 *		preferences::button_warn_option.
 */
void preferences::option_warn_sensitive(void)
{
	if(GTK_TOGGLE_BUTTON(button_option_warn)->active) {
		gtk_widget_set_sensitive(label_warntime, gtk_true());
		gtk_widget_set_sensitive(spinner_warntime, gtk_true());
		gtk_widget_set_sensitive(button_warn_beep, gtk_true());
	}
	else {
		gtk_widget_set_sensitive(label_warntime, gtk_false());
		gtk_widget_set_sensitive(spinner_warntime, gtk_false());
		gtk_widget_set_sensitive(button_warn_beep, gtk_false());
	}
}

/*------------------------------------------------------------------------------
 *	Setea el preferences::button_ok un/sensitive de acuerdo a un OR de todas 
 *		las banderas de preferences.
 */
void preferences::button_ok_sensitive(void)
{
	int warn_aux;
	//sacado de preferences::ok()
	if(gpppk->rc->load_option_warn()) {
		warn_aux = (option_warn || warntime || warn_beep);	//option_warn representa a warntime
		//option_warn = warn_beep;	//option_warn representa a warn_beep
	}

	if( idletime || onlinetime || byte_in || byte_out || idletime_button
	    || onlinetime_button || interface || warn_aux) {
		//button_ok tiene el focus
		gtk_widget_set_sensitive(button_ok, gtk_true());
		GTK_WIDGET_UNSET_FLAGS(button_cancel, GTK_HAS_FOCUS);	
		GTK_WIDGET_UNSET_FLAGS(button_cancel, GTK_HAS_DEFAULT);	
		GTK_WIDGET_SET_FLAGS(button_ok, GTK_HAS_FOCUS);
		GTK_WIDGET_SET_FLAGS(button_ok, GTK_HAS_DEFAULT);
		gtk_widget_queue_draw(button_cancel);	//actualizar el boton sin HAS_DEFAULT
	}
	else {	//button_cancel tiene el focus
		gtk_widget_set_sensitive(button_ok, gtk_false());
		GTK_WIDGET_UNSET_FLAGS(button_ok, GTK_HAS_FOCUS);
		GTK_WIDGET_UNSET_FLAGS(button_ok, GTK_HAS_DEFAULT);	
		GTK_WIDGET_SET_FLAGS(button_cancel, GTK_HAS_FOCUS);
		GTK_WIDGET_SET_FLAGS(button_cancel, GTK_HAS_DEFAULT);	
		gtk_widget_queue_draw(button_cancel);	//actualizar el boton sin HAS_DEFAULT
	}
}

/*------------------------------------------------------------------------------
 *	Se llama desde el callback cuando se oprimio OK
 */
void preferences::ok(void)
{
	char ppp[7];
	int idle, byte_in_tmp, byte_out_tmp, online, aux;
	
	if(idletime) {
		aux = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner_idle_h));
		aux = aux * 3600;
		idle = aux;
		aux = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner_idle_m));
		aux = aux * 60;
		idle = idle + aux;
		aux = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner_idle_s));
		idle = idle + aux;

		gpppk->setidletime(idle);

		gpppk->rc->save_idletime(idle);
	}

	if(onlinetime) {
		aux = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner_online_h));
		aux = aux * 3600;
		online = aux;
		aux = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner_online_m));
		aux = aux * 60;
		online = online + aux;
		aux = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner_online_s));
		online = online + aux;

		gpppk->setonlinetime(online);

		gpppk->rc->save_onlinetime(online);
	}	

	if(byte_in) {
		byte_in_tmp  = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner_byte_in));

		gpppk->setbyte_min_in(byte_in_tmp);

		gpppk->rc->save_byte_min_in(byte_in_tmp);
	}

	if(byte_out) {
		byte_out_tmp = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner_byte_out));

		gpppk->setbyte_min_out(byte_out_tmp);

		gpppk->rc->save_byte_min_out(byte_out_tmp);
	}

	if(idletime_button) 
		gpppk->rc->save_idletime_on(GTK_TOGGLE_BUTTON(idletime_on_button)->active);

	if(onlinetime_button)
		gpppk->rc->save_onlinetime_on(GTK_TOGGLE_BUTTON(onlinetime_on_button)->active);

	if(interface) {
		strcpy(ppp, (char *)gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo)->entry)));

		//serciorarme de que la cadena es un nombre de pppxx
		if( !strcmp(STR_NO_PPPD, (char *)ppp) )
			interface = 0;
		else {
			gpppk->setinterface((char *)ppp);

			gpppk->rc->save_pppInterface(ppp);
		}
	}

	if(option_warn)
		gpppk->rc->save_option_warn(GTK_TOGGLE_BUTTON(button_option_warn)->active);

	if(gpppk->rc->load_option_warn()) {
		if(warntime) {
			option_warn = warntime;	//option_warn representa a warntime
			aux = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinner_warntime));
			gpppk->setwarntime(aux);
			gpppk->rc->save_warntime(aux);
		}
		if(warn_beep) {
			option_warn = warn_beep;	//option_warn representa a warn_beep
			gpppk->rc->save_warn_beep(GTK_TOGGLE_BUTTON(button_warn_beep)->active);
			gpppk->setwarn_beep(GTK_TOGGLE_BUTTON(button_warn_beep)->active);
		}
	}

	if( idletime || onlinetime || byte_in || byte_out || idletime_button
	    || onlinetime_button || interface || option_warn)
		quickmessage("preferences_ok_callback():", "Preferences saved.", (char *)NULL);

	resultado = 1;
	quit();
}

/*------------------------------------------------------------------------------
 *	Se llama desde el callback cuando se oprimio CANCEL
 */
void preferences::cancel(void)
{
	resultado = 0;
	quit();
}

// ### callbacks ###############################################################

/*------------------------------------------------------------------------------
 *	Para el boton OK de preferences.
 */
void preferences_ok_callback(GtkWidget *widget, preferences *pref)
{
	widget = widget;	//unused parameter
	pref->ok();
}

/*------------------------------------------------------------------------------
 *	Para el boton CANCEL de preferences.
 */
void preferences_cancel_callback(GtkWidget *widget, preferences *pref)
{
	widget = widget;	//unused parameter
	pref->cancel();
}

/*------------------------------------------------------------------------------
 *	Para el tiempo idletime de preferences.
 */
void preferences_idletime_callback(GtkEditable *editable, preferences *pref)
{
	pref->idletime = 1;
	pref->button_ok_sensitive();
}

/*------------------------------------------------------------------------------
 *	Para el tiempo onlinetime de preferences.
 */
void preferences_onlinetime_callback(GtkEditable *editable, preferences *pref)
{
	pref->onlinetime = 1;
	pref->button_ok_sensitive();
}

/*------------------------------------------------------------------------------
 *	Para el tiempo byte_in de preferences.
 */
void preferences_byte_in_callback(GtkEditable *editable, preferences *pref)
{
	pref->byte_in = 1;
	pref->button_ok_sensitive();
}

/*------------------------------------------------------------------------------
 *	Para el tiempo byte_out de preferences.
 */
void preferences_byte_out_callback(GtkEditable *editable, preferences *pref)
{
	pref->byte_out = 1;
	pref->button_ok_sensitive();
}

/*------------------------------------------------------------------------------
 *	Para el cambio de idletime_button de preferences.
 */
void preferences_idletime_button_callback(GtkToggleButton *toggle_button, preferences *pref)
{
	//es un toggle button, solo tiene dos opciones
	pref->idletime_button = !(pref->idletime_button);
	pref->button_ok_sensitive();
}

/*------------------------------------------------------------------------------
 *	Para el cambio de onlinetime_button de preferences.
 */
void preferences_onlinetime_button_callback(GtkToggleButton *toggle_button, preferences *pref)
{
	//es un toggle button, solo tiene dos opciones
	pref->onlinetime_button = !(pref->onlinetime_button);
	pref->button_ok_sensitive();
}

/*------------------------------------------------------------------------------
 *	Para el cambio de interface de preferences.
 */
void preferences_combo_callback(GtkEditable *editable, preferences *pref)
{
	pref->interface = 1;
	pref->button_ok_sensitive();
}

/*------------------------------------------------------------------------------
 *	Para habilitar la opcion warning.
 */
void preferences_button_option_warn_callback(GtkToggleButton *toggle_button, preferences *pref)
{
	//es un toggle button, solo tiene dos opciones
	pref->option_warn = !(pref->option_warn);

	pref->option_warn_sensitive();
	pref->button_ok_sensitive();
}

/*------------------------------------------------------------------------------
 *	Para el tiempo warntime.
 */
void preferences_spinner_warntime_callback(GtkEditable *editable, preferences *pref)
{
	pref->warntime = 1;
	pref->button_ok_sensitive();
}

/*------------------------------------------------------------------------------
 *	Para habilitar la warning beep.
 */
void preferences_button_warn_beep_callback(GtkToggleButton *toggle_button, preferences *pref)
{
	//es un toggle button, solo tiene dos opciones
	pref->warn_beep = !(pref->warn_beep);
	pref->button_ok_sensitive();
}

// ### X11 events ##############################################################
/*------------------------------------------------------------------------------
 *	Para la clase preferences.
 *	Si retorno FALSE, gtk envia la signal destroy al widget
 *	Cuando se oprime el boton close de la ventana del windwow manager.
 */
gint preferences_delete_event_callback(GtkWidget *widget, GdkEventAny *event, preferences *pref)
{
	pref->cancel();

	return gtk_true();
}
