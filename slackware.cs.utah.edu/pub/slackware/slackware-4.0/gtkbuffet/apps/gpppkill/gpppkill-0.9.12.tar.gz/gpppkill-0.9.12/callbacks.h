#ifndef	_CALLBACKS_HPP_OSL_
#define _CALLBACKS_HPP_OSL_

#include <iostream.h>
#include <gtk/gtk.h>

#include "gpppkill_config.h"
#include "gpppkill.h"

void ok_messagebox(GtkButton *button);
gint delete_event_quickmessage(GtkWidget *widget, GdkEventAny *event, gint *timeout_id);
gint delete_event_messagebox(GtkWidget *widget, GdkEventAny *event);

#endif