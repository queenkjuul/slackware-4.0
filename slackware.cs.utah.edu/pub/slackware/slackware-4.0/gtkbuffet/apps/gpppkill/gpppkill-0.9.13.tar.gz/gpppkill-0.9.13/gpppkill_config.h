#ifndef _GPPPKILL_CONFIG_OSL_H_
#define _GPPPKILL_CONFIG_OSL_H_

#define PROGRAMA	"gpppkill"
#define VERSION		"0.9.13"
#define FECHA     "05-dec-98"

//usado para el ancho del borde de un container.(i.e. gpppkill::window)
#define CONTAINER_ANCHO 2	

#define	DRAW_ANCHO				200
#define	DRAW_ALTO					100
#define DEF_LINEA_ANCHO	    2	//cabiado por gpppkill::dibujar_frame_graf()::linea_ancho
#define INTERVALO				 1000
#define INTERVALO_QUICKMESSAGE 1100
#define KILL_INTERVALO				 1000
#define KILLTIME_OFF_STR "--:--:--"

//labels
#define DEF_LABEL_IN_OUT "00000"
#define DEF_LABEL_PROMEDIO_IN_OUT "00.000"
#define DEF_LABEL_TOTAL_IN_OUT "000000000"
#define DEF_LABEL_INTERFACE "ppp--"
#define DEF_LABEL_PID "-----"

// warning time
#define DEF_WARNTIME 15

#endif
