/*
 *  gpppkill. X11/GTK+ program that kill pppd if it not recive a minimal amount 
 *  of bytes during certain time. It also plot the amount bytes/seg recived.
 *  Copyright (C) 1998  Oliver Schulze L.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  You can reach the author at: 
 *    oliver@pla.net.py
 *
 *  gpppkill Home Page:
 *    http://www.pla.net.py/home/oliver/gpppkill/
 *  
 *  A copy of the GNU General Public License is included with this program.
 */
#ifndef _DIALOG_OSL_H_
#define _DIALOG_OSL_H_

#include <iostream.h>
#include <gtk/gtk.h>

#include "gpppkill_config.h"

class dialog {
	protected:
		GtkWidget	*window,
		          *vbox_main,
		          *vbox,
		          *separator,
		          *hbox;
		int resultado;

		void construir_box(void);
		virtual void cargar_widget(void) = 0;
		virtual void conectar_signal(void) = 0;
		virtual void quit(void) = 0;
		
	public:
		dialog();
		//~dialog();	//no usar si no es un destructor virtual

		GtkWidget *getwindow(void);

		virtual int mostrar(void) = 0;
} ; 

class warning : public dialog {
	private:
		//class gpppkill *gpppk;
		GtkWidget *label,
		          //*label_time,
		          *pbar,
		          *ok_button,
		          *cancel_button;
		GtkTooltips *tooltips;
		gint timeout_id,
		     intervalo;
		gfloat incremento;
		long pppd_pid;
		int tiempo_total,
		    causa;
		char interface[10],
		     warn_beep;

		void conectar_signal(void);
		void cargar_widget(void);
		void quit(void);

		// callbacks
		friend gint warning_delete_event_callback(GtkWidget *widget, GdkEventAny *event, warning *w);
		friend void warning_ok_callback(GtkButton *button, warning *w);
		friend void warning_cancel_callback(GtkButton *button, warning *w);
		friend gint warning_timeout_callback(warning *w);

	public:
		warning(int opcion);
		
		int mostrar(void);

		// set
		void settiempo_total(int total);
		void setpppd_pid(long pid);
		void setinterface(char *str);
		void setwarn_beep(char beep);
} ;

#endif