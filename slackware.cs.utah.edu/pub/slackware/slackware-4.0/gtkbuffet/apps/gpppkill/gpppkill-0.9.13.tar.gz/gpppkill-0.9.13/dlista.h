/*
 *  gpppkill. X11/GTK+ program that kill pppd if it not recive a minimal amount 
 *  of bytes during certain time. It also plot the amount bytes/seg recived.
 *  Copyright (C) 1998  Oliver Schulze L.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  You can reach the author at: 
 *    oliver@pla.net.py
 *
 *  gpppkill Home Page:
 *    http://www.pla.net.py/home/oliver/gpppkill/
 *  
 *  A copy of the GNU General Public License is included with this program.
 */
#ifndef _DLISTA_OSL_HPP
#define _DLISTA_OSL_HPP

#include <iostream.h>
#include <stdio.h>
#include <string.h>

#define DEBUG_DLISTA 0

//class dnodo
class dnodo {
	public:
		dnodo();
		~dnodo();
		
		class dnodo *sigte,
								*anterior;
		long pid;
		char interface[7];
} ;

//class dlista. alias directorio
class dlista {
	protected:
		class dnodo *inicio, *final;
		void agregar_nodo(dnodo *p);
		void borrar_nodo(dnodo *p);
	public:
		dlista();
		~dlista();
		void borrar_dlista();
		int  numero_de_elementos(void);
		void agregar(long nuevo_pid);
		long get_dnodo_pid(int index);
		long get_dnodo_pid(char *match);
		char *get_dnodo_interface(int index);

		dnodo *get_inicio();
		dnodo *get_final();
} ;

#endif
