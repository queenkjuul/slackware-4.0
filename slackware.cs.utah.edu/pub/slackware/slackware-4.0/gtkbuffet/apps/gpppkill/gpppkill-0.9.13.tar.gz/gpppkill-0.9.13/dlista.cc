/*
 *  gpppkill. X11/GTK+ program that kill pppd if it not recive a minimal amount 
 *  of bytes during certain time. It also plot the amount bytes/seg recived.
 *  Copyright (C) 1998  Oliver Schulze L.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  You can reach the author at: 
 *    oliver@pla.net.py
 *
 *  gpppkill Home Page:
 *    http://www.pla.net.py/home/oliver/gpppkill/
 *  
 *  A copy of the GNU General Public License is included with this program.
 */
#include "dlista.h"

//############################# Class dnodo ###################################
//------------------------------------------------------------------------------
/*
 *	Constructor de la clase nodo.
 *	Aqui se inicializan todas las variables a cero o NULL.
 */
dnodo :: dnodo()
{
	sigte=NULL;
	anterior=NULL;

	pid = 0;
	strcpy(interface, "");

	if(DEBUG_DLISTA)
		cout << "Constructor  dnodo()\n";  	
}

/*
 *	Destructor, lo uso para debug. Para ver si se eliminana todos los nodos
 */
dnodo :: ~dnodo()
{
	if(DEBUG_DLISTA) 
		cout << "dnodo borrado" << endl;
}

//############################# Class dlista ###################################
//------------------------------------------------------------------------------
/*
 *	Constructor de la clase dlista.
 *	Se inicializan los punteros de la lista a NULL,
 *		que es la condicion de dlista vacia.
 */
dlista :: dlista()
{
	inicio=NULL;
	final=NULL;

	if(DEBUG_DLISTA)
		cout << "Constructor dlista()\n";
}

/*------------------------------------------------------------------------------
 *	Destructor de la clase dlista.
 */
dlista :: ~dlista()
{
	borrar_dlista();

	if(DEBUG_DLISTA)
		cout << "Destructor dlista()\n";
}

//------------------------------------------------------------------------------
/*
 *	Agrega un dnodo al final de la lista.
 *	Actualiza los puntero se hace falta.
 */
void dlista :: agregar_nodo(dnodo *p)
{
	if(inicio == NULL)  //primer elemento en la lista
		inicio = final = p;
	else {
		p->anterior = final;
		final->sigte = p;
		final = p;
	}
}

//------------------------------------------------------------------------------
/*	
 *	Borra un elemento de la lista
 *		y actualiza 'dlista::inicio' y 'dlista::final'.
 */
void dlista :: borrar_nodo(dnodo *p)
{
	if(p->anterior) { 
		if(p->sigte) {  //si esta en el medio
			p->anterior->sigte = p->sigte;
			p->sigte->anterior = p->anterior;
			p->sigte = p->anterior = NULL;
		}
		else { //es el ultimo elemento
			p->anterior->sigte = NULL;
			final = p->anterior;
			p->anterior = NULL;
		}
	}
	else { //es el primero
		if(p->sigte) { //hay mas de un elemento
			p->sigte->anterior = NULL;
			inicio = p->sigte;
			p->sigte = NULL; //no necesario
		}
		else  //es el unico elemento
			inicio = final = NULL;
	}
	if(p)
		delete p;
	else
		printf("dlista :: borrar(): tratando de borrar un puntero a NULL\n");
}

/*------------------------------------------------------------------------------
 *	Borra todos los nodos de la dlista.
 *	Actualiza los punteros de la lista a la condicion "vacia".
 */
void dlista :: borrar_dlista()
{
	dnodo *n;
	
	n = inicio;
	
	if(n) { 					//si hay algun elemento
		while(n->sigte) {
			n = n->sigte;         //paso al sigte
			if(n->anterior)
				delete (n->anterior);  //borro el anterior
			else
				printf("dlista::borrar_dlista(): tratando de borrar un puntero a NULL");
		};
		if(n)
			delete n;   //borro el ultimo
		else
			printf("dlista::borrar_dlista(): tratando de borrar un puntero a NULL");
	}
	
	inicio = final = NULL;
}

/*------------------------------------------------------------------------------
 *	Retorna el numero de elementos que hay en la dlista.
 *	return:
 *		0 -> no hay elementos.
 *	 >0 -> el numero de elementos.
 */
int dlista :: numero_de_elementos(void)
{
	int num;
	dnodo *n;
	
	num = 0;
	n   = inicio;
	
	if(n) { 					//si hay algun elemento
		num++;
		while(n->sigte) {
			num++;
			n = n->sigte;	//paso al sigte
		};
	}

	return num;
}

/*------------------------------------------------------------------------------
 */
void dlista :: agregar(long nuevo_pid)
{
	dnodo *n;
	int num;

	n = new dnodo();
	if(!n) {
		perror("dlista::agragar():\nNO memory for new()\n");
		exit(1);
	}

	n->pid = nuevo_pid;
	num = numero_de_elementos();

	sprintf(n->interface, "ppp%d", num);

	agregar_nodo(n);
}

/*------------------------------------------------------------------------------
 *	argument:
 *		index : numero de interface. La primera interface es la numero 1.
 *						que equivale a la interface ppp0
 *	return:
 *		>0 : ok -> se retorna el dnodo::pid
 *		-1 : error -> el indice del nodo es mayor que el numero de elementos
 *		-2 : error -> dnodo encontrado == NULL
 */
long dlista :: get_dnodo_pid(int index)
{
	int num, num_elementos;
	dnodo *n;
	
	num_elementos = numero_de_elementos();

	if(index && (index <= num_elementos))	{	//no se permite index==0
		n   = inicio;
		num = 1;

		while((num != index) && (n != NULL)) {
			num++;
			n = n->sigte;	//paso al sigte
		};
		if(n)
			return n->pid;
		else
			return (-2);
	}
	else
		return (-1);
}

/*------------------------------------------------------------------------------
 *	return:
 *	 >0:ok    --> se retorna el pid.
 *		0:error --> no se encuentra la interface especificada(match).
 *	 -1:error --> no hay ningun pppd corriendo.
 */
long dlista :: get_dnodo_pid(char *match)
{
	dnodo *n;
	
	n   = inicio;
	
	if(n) { //si hay algun elemento
		if(!strcmp(match, n->interface))	//busco en el primer nodo
			return n->pid;
		while(n->sigte) {	//sigo buscando
			n = n->sigte;	//paso al sigte
			if(!strcmp(match, n->interface))
				return n->pid;
		};
		return (long)0;	//no se encontro la interface
	}
	else
		return (long)-1;	//no hay ningun pppd corriendo.
}

/*------------------------------------------------------------------------------
 *	argument:
 *		index : numero de interface. La primera interface es la numero 1.
 *						que equivale a la interface ppp0
 *	return:
 *		(char *): ok -> se retorna dnodo::interface
 *		NULL    : error -> el indice del nodo es mayor que el numero de elementos
 *		                -> dnodo encontrado == NULL
 */
char *dlista :: get_dnodo_interface(int index)
{
	int num, num_elementos;
	dnodo *n;
	
	num_elementos = numero_de_elementos();

	if(index && (index <= num_elementos))	{	//no se permite index==0
		n   = inicio;
		num = 1;

		while((num != index) && (n != NULL)) {
			num++;
			n = n->sigte;	//paso al sigte
		};
		if(n)
			return n->interface;
		else
			return (char *)NULL;
	}
	else
		return (char *)NULL;
}

/*------------------------------------------------------------------------------
 *	Retorna el la direccion del nodo apuntado por dlista::inicio.
 */
dnodo *dlista :: get_inicio()
{
	return inicio;
}

/*------------------------------------------------------------------------------
 *	Retorna la direccion del dnodo apuntado por dlista::final .
 */
dnodo *dlista :: get_final()
{
	return final;
}
