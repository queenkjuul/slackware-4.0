#include <fcntl.h>
#include <linux/genhd.h>
#include <linux/fs.h>

#define IOMEGA_FSTAB "/etc/fstab"
#define LOCK_FILE "/etc/mtab~"
#define SECTOR_SIZE   512
#define MAXIMUM_PARTS 60

#define offset(b, n) ((struct partition *)((b) + 0x1be + \
                (n) * sizeof(struct partition)))




