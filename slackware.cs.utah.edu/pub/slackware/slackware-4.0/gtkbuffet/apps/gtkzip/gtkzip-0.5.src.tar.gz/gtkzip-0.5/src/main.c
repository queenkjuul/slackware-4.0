#include "gtkzip.h"
#include "plug_in.h"
#include "diskusage.h"
#include "scsi.h"

#include "default_skin.h"
#include <gdk/gdkx.h>
#include <X11/Xlib.h>

#include <config.h>

gchar* homedir(){
  gchar* home = getenv("HOME");
  if(home)
    return home;
  else{
    struct passwd* pw = getpwuid(getuid());
    if (pw)
      return pw->pw_dir;
    else
      return NULL ; 
  }
}

int isfile(char* s){
  struct stat st;
  
  if((!s)||(!*s)) return 0;
  if(stat(s,&st)<0) return 0;
  if(S_ISREG(st.st_mode)) return 1;
  return 0;
}

int isdir(char* s){
  struct stat st;
  
  if((!s)||(!*s)) return 0;
  if(stat(s,&st)<0) return 0;
  if(S_ISDIR(st.st_mode)) return 1;
  return 0;
}

SkinData* load_default_normal_skin(){
  SkinData* s;
//  GtkStyle* style;
  GdkPixmap* background;
  GdkPixmap* pixmap = NULL;
  GdkBitmap* mask = NULL;
  gint width, height;
  
  s = new_skin();

  //style = gtk_widget_get_style(mainwindow);
  background = get_pixmap_from_data((gchar**)background_xpm);
  
  gdk_window_get_size (background, &width, &height);

  gdk_imlib_data_to_pixmap(background_mask_xpm, &pixmap, &mask);
  //if(pixmap) gdk_imlib_free_pixmap(pixmap);
  
  s->background = background;
  s->mask = mask;
  s->width = width;
  s->height = height;

  s->b[0] = new_button_from_data((gchar**)mount_xpm, 
				 TRUE, TRUE, 
				 43, 12,
				 mount_button_pressed, NULL, NULL);
  s->b[1] = new_button_from_data((gchar**)eject_xpm, 
				 TRUE, FALSE, 
				 73, 12,
				 eject_button_pressed, NULL, NULL);
  s->b[2] = new_button_from_data((gchar**)lock_xpm, 
				 TRUE, TRUE, 
				 103, 12,
				 lock_button_pressed, NULL, NULL);
  s->b[3] = new_button_from_data((gchar**)unlock_xpm, 
				 TRUE, FALSE, 
				 133, 12,
				 unlock_button_pressed, NULL, NULL);
  return s;
}

SkinData* load_default_msg_skin(){
  SkinData* s;
//  GtkStyle* style;
  GdkPixmap* msg_background;
  GdkPixmap* pixmap = NULL;
  GdkBitmap* mask = NULL;
  gint width, height;
  
  s = new_skin();

//  style = gtk_widget_get_style(mainwindow);
  msg_background = get_pixmap_from_data((gchar**)msg_background_xpm);

  gdk_window_get_size(msg_background, &width, &height);

  gdk_imlib_data_to_pixmap(background_mask_xpm, &pixmap, &mask);
//  if(pixmap) gdk_imlib_free_pixmap(pixmap);

  s->background = msg_background;
  s->mask = mask;
  s->width = width;
  s->height = height;
  
  s->msg = new_font_from_data((gchar **)letters_xpm, 17, 45, 17);
  s->b[4] = new_button_from_data((gchar**)next_xpm, 
				 TRUE, FALSE, 
				 153, 16, 
				 NULL, NULL, hide_msg_window);
  return s;
}

void exec_function_helper(void* func){
  void (*f)();

  g_mutex_lock(main_mutex);
  if(!skin->b[0]){
    //g_print("-->wait!\n");
    g_cond_wait(main_cond, main_mutex);
  }
  //g_print("-->release\n");
  f = func; 
  f();
  g_mutex_unlock(main_mutex);
}

void exec_function1(GtkWidget* w, gpointer func){
  void (*f)();
  pthread_t thread;

  f = func;
  pthread_create (&thread, NULL, 
		  (void *(*)(void *)) exec_function_helper, f);
}

void exec_function2(GtkWidget* w, gpointer func){
  void (*f)() = func; f();
}

void mount_button_pressed(){
  gint s; 
  if(!is_mounted(dev)){
    if(mount_disk(dev)){
      status = HAVE_DISK;
      mount_status = STATUS_MOUNT;
      s = get_prot_mode(open_dev(dev));
      if(s == IOMEGA_PROTECTION_MODE_RO)
	lock_status = STATUS_NOR_LOCK;
      else if(s == IOMEGA_PROTECTION_MODE_ROPW)
	lock_status = STATUS_PWD_LOCK;
      else lock_status = STATUS_UNLOCK;
    }
    reset_msg();
    update_msg(msg);
  }
  else{
    if(umount_disk(dev)){
      status = HAVE_DISK;
      mount_status = STATUS_UMOUNT;
    }
    reset_msg();
    update_msg(msg);
  }
}

void eject_button_pressed(){
  if((is_mounted(dev)) != 0){
    umount_disk(dev);
    if((is_mounted(dev)) != 0) return;
  }
  reset_msg();
  if(!eject_disk(dev)){
    update_msg(msg);
    return;
  }
  update_msg("Eject...");
}

void lock_button_pressed(){
  gint s;
  reset_msg();
  if((is_mounted(dev)) != 0)
    update_msg(msg); 
  else{
    if((s=set_prot_mode(dev,2)) == WAIT){}
    else 
      update_msg(msg);
  }
}

void unlock_button_pressed(){ 
  gint s;
  reset_msg();
  if((is_mounted(dev)) != 0)
    update_msg(msg);
  else{
    if((s=set_prot_mode(dev,0)) == WAIT){}
    else
      update_msg(msg);
  }
}

void iconify_button_pressed(){
  Window xwindow;
  if(!mainwindow->window) return;
  xwindow = GDK_WINDOW_XWINDOW(mainwindow->window);
  XIconifyWindow(GDK_DISPLAY(), xwindow, 
		 DefaultScreen(GDK_DISPLAY()));
}

void hide_msg_window(){
  g_mutex_lock(main_mutex);
  gtk_timeout_remove(msg_timeout_tag);
  gtk_timeout_remove(scroll_msg_timeout_tag);
  delete_lock_pwd();
  skin = skin_normal;
  sync_window_to_skin();
  function_handler_id =
    gtk_signal_connect(GTK_OBJECT(mainwindow), 
		       "key_press_event",
		       (GtkSignalFunc)function_key_pressed,
		       NULL);
  g_cond_signal(main_cond);
  g_mutex_unlock(main_mutex);
}

void show_about_info(){
  gchar* command = g_strconcat(browser_command,
		 " http://home.netvigator.com/~sallymak/GtkZip&", NULL);
  system(command);
  g_free(command);
}

void show_zip_info(){
  gchar* command = g_strconcat(browser_command,
		 " http://www.iomega.com/product/zip/&", NULL);
  system(command);
  g_free(command);
}

void show_gtk_info(){
  gchar* command = g_strconcat(browser_command,
		 " http://www.gtk.org/&", NULL);
  system(command);
  g_free(command);
}

void function_key_pressed(GtkWidget *widget, GdkEventKey *event){
  static gint last_key = 0;
  static gint last_state = 0;
  static guint32 last_time = 0;
  
  if(event->keyval == last_key && event->state == last_state &&
      last_time + 500 >= event->time){
    return;
  }
  else{
    last_key = event->keyval;
    last_state = event->state;
    last_time = event->time;
  }
  if(event->state & GDK_CONTROL_MASK){
    switch(event->keyval){
      case 'q': 
	destroy_window();
	break;
      case 'a':
	exec_function1(NULL, show_about_info);
	break;
      case 'z':
	exec_function1(NULL, show_zip_info);
	break;
      case 'g':
	exec_function1(NULL, show_gtk_info);
	break;
      case 'i':
	iconify_button_pressed();
	break;
      default:
	break;
    }
  }
  else{
    switch(event->keyval){
      case 'm':
	exec_function1(NULL, mount_button_pressed);
	break;
      case 'e':
	exec_function1(NULL, eject_button_pressed);
      break;
      case 'l':
	exec_function1(NULL, lock_button_pressed);
	break;
      case 'u':
	exec_function1(NULL, unlock_button_pressed);
	break;
      default:
	break;
    }
  }
}

void destroy_window(){
  save_options();
  gtk_main_quit();
}

static void set_icon_for_window(GtkWidget *window){
  GdkPixmap* icon = NULL;
  GdkBitmap* mask = NULL;
  GtkStyle* style = gtk_widget_get_style(window);
  icon = gdk_pixmap_create_from_xpm_d(window->window, &mask,
				      &style->bg[GTK_STATE_NORMAL], 
				      (gchar **)gtkzip_icon_xpm);
  gdk_window_set_icon(window->window, NULL, icon, mask);
}

gint create_config_dir(){
  gchar *hmdir;
  gchar *rcdir;
  
  hmdir = homedir();
  if(!hmdir){
    printf("Unable to determine the home directory\n");
    return FALSE;
  }
  else if(!isdir(hmdir)){
    printf("Could not find home directory: %s\n", hmdir);
    return FALSE;
  }
  rcdir = g_strconcat(homedir(), "/.gtkzip", NULL);
  if(!isdir(rcdir)){
    printf("Creating gtkzip dir:%s\n", rcdir);
    if((mkdir (rcdir, 0755) < 0))
      printf("Could not create dir:%s\n", rcdir);
  }
  g_free(rcdir);
  rcdir = g_strconcat(homedir(), "/.gtkzip/skins", NULL);
  if (!isdir(rcdir)){
    printf("Creating gtkzip skin dir:%s\n", rcdir);
    if ( (mkdir (rcdir, 0755) < 0) )
      printf("Could not create dir:%s\n", rcdir);
  }
  g_free(rcdir);
  rcdir = g_strconcat(homedir(), "/.gtkzip/gtkrc", NULL);
  gtk_rc_parse (rcdir);
  g_free(rcdir);

  return TRUE;
}

void create_mnt_dir(){
  gint i;
  for(i=0; mnt_dirs[i]; i++){
    if(!isdir(mnt_dirs[i])){
      if((mkdir(mnt_dirs[i], 0755) < 0)){
	printf("Could not create mount point dir: %s\n", mnt_dir);
	exit(-1);
      }
    }
  }
}

void init_vars(){
  if(!check_scsi_dev(dev)) exit(-1);
  create_mnt_dir();
  if(!browser_command)
    browser_command = g_strdup("netscape");
  g_thread_init (NULL);
  main_mutex = g_mutex_new();
  main_cond = g_cond_new();
  plug_ins = plug_ins_alloc();
#if HAVE_LIBGTOP
  diskusage_init();
#endif
  
}

int main(int argc, char *argv[]){

  if(!create_config_dir()) return 0;

  gtk_init(&argc, &argv);
  gdk_imlib_init();
  
  mainwindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_signal_connect(GTK_OBJECT(mainwindow), 
		     "delete_event",
		     (GtkSignalFunc) destroy_window, 
		     NULL);
  function_handler_id =
    gtk_signal_connect(GTK_OBJECT(mainwindow), 
		       "key_press_event",
		       (GtkSignalFunc) function_key_pressed,
		       NULL);
  gtk_window_set_policy(GTK_WINDOW(mainwindow),
			 FALSE,
			 FALSE,
			 TRUE);
  gtk_container_border_width(GTK_CONTAINER(mainwindow), 0);
  gtk_window_set_title(GTK_WINDOW(mainwindow), "GtkZip");
  gtk_window_set_wmclass(GTK_WINDOW(mainwindow), 
			 "GtkZip",
			 "gtkzip");
  gtk_widget_realize(mainwindow);
  
  display_area = gtk_drawing_area_new();
  gtk_container_add(GTK_CONTAINER(mainwindow), display_area);
  setup_display(); 
  gtk_widget_show(display_area);
  gtk_widget_realize(display_area);
  set_icon_for_window(mainwindow);

  skin_normal = load_default_normal_skin();
  skin_msg = load_default_msg_skin();
  skin = skin_normal;
  sync_window_to_skin();

  if(!wm_decorations) gdk_window_set_decorations(mainwindow->window, 0);
  gtk_widget_show(mainwindow);
  
  if(load_options()){
    init_vars();
    sync_window_to_skin();
  }
  else{
    update_caution_msg("Thanks for using GtkZip...");
    lock_mode = TRUE;
    skin_msg->b[4] = NULL;
    show_config_window();
  }

  main_menu = create_main_menu();
    
  gtk_main();
  return 0;
}
