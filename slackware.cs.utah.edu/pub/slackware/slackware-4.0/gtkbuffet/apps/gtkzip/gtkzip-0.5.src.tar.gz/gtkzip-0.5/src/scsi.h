#define SCSI_IOCTL_SEND_COMMAND 1

typedef struct _sdata sdata;
struct _sdata{
  gint  inlen;
  gint  outlen;
  gchar cmd[256];
};
sdata scsi_cmd;

gint    pwd_msg_timeout_tag;

extern gint ioctl();

gint is_mounted(char* fs);
gint eject_disk(char* dev);
gint get_prot_mode(gint fd);
void delete_lock_pwd();
gint dump_prot_mode(char*  dev);
gint set_prot_mode (char* dev, gint mode);
gint open_dev(char* dev);
gint check_scsi_dev(char* rsd); 
