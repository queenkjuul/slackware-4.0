#include <stdio.h>
#include <mntent.h>
#include <errno.h>
#include <sys/mount.h>
#include <fcntl.h>
#include "gtkzip.h"

#define LOCK_FILE "/etc/mtab~"

gint umount_disk(gchar *dev){
  FILE* mtab;
  FILE* newmtab;
  struct mntent* mp;
  
  if(!is_mounted(dev)){
    sprintf(msg, "No disks are mounted!");
    return FALSE;
  }
  if(!(newmtab = fdopen(open(LOCK_FILE, O_WRONLY|O_CREAT|O_EXCL, 0666), "w"))){
    sprintf(msg, "Lock-file exists!");
    return FALSE;
  }
  if(!(mtab = setmntent(MOUNTED, "r"))){
    sprintf(msg, "%s : %s", MOUNTED, strerror(errno));
    endmntent(newmtab);
    unlink(LOCK_FILE);
    return FALSE;
  }
  while((mp = getmntent(mtab))){
    if(!mp->mnt_opts || !mp->mnt_opts[0]) mp->mnt_opts = "defaults";
    if(!strcmp(mnt_fsname, mp->mnt_fsname) ||
	!strcmp(mnt_dir, mp->mnt_dir)){ 
      if(umount(mnt_fsname) < 0){
	sprintf(msg, "%s", strerror(errno));
	endmntent(mtab);
	endmntent(newmtab);
	unlink(LOCK_FILE);
	return FALSE;
      } 
      else sprintf(msg, "Unmounted %s", mp->mnt_dir);
    }
    else addmntent(newmtab, mp);
  }
  endmntent(newmtab);
  endmntent(mtab);
  unlink(MOUNTED);
  link(LOCK_FILE, MOUNTED);
  unlink(LOCK_FILE);
  return TRUE;
}
