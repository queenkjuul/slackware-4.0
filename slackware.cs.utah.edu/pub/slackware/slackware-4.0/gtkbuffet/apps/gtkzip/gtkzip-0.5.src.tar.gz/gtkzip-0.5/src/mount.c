#include <mntent.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/genhd.h>

#include <config.h>

#if HAVE_EXT_FS
#include <linux/ext_fs.h>
#endif
#if HAVE_EXT2_FS
#include <linux/ext2_fs.h>
#endif
#if HAVE_MINIX_FS
#include <linux/minix_fs.h>
#endif

#include <sys/stat.h>
#include <sys/types.h>

#include "gtkzip.h"
#include "mount.h"
#include "scsi.h"

static int have_mtab_info = 0;
static int var_mtab_does_not_exist = 0;
static int var_mtab_is_a_symlink = 0;

static void get_mtab_info(void) {
  struct stat mtab_stat;
  
  if (!have_mtab_info) {
    if (lstat(MOUNTED, &mtab_stat))
      var_mtab_does_not_exist = 1;
    else if (S_ISLNK(mtab_stat.st_mode))
      var_mtab_is_a_symlink = 1;
    have_mtab_info = 1;
  }
}

int mtab_is_a_symlink(void) {
  get_mtab_info();
  return var_mtab_is_a_symlink;
}

int mtab_is_writable() {
  static int ret = -1;
  
  if (mtab_is_a_symlink())
    return 0;
  
  if (ret == -1) {
    int fd = open(MOUNTED, O_RDWR | O_CREAT, 0644);
    if (fd >= 0) {
      close(fd);
      ret = 1;
    } else
      ret = 0;
  }
  return ret;
}

gchar* get_fs_type(gchar* d, gchar* d1){
  int fd;
  char *type = NULL;
  union {
#if HAVE_MINIX_FS
    struct minix_super_block ms;
#endif
#if HAVE_EXT_FS
    struct ext_super_block es;
#endif
#if HAVE_EXT2_FS
    struct ext2_super_block e2s;
#endif
  } sb;

  struct stat statbuf;
  
  if(stat(d, &statbuf) || !S_ISBLK(statbuf.st_mode))
    return FALSE;
  
  if((fd = open(d, O_RDONLY)) < 0)
    return FALSE;

  if(lseek(fd, BLOCK_SIZE, SEEK_SET) != BLOCK_SIZE
     || read(fd, (char*)&sb, sizeof(sb)) != sizeof(sb)){
    close(fd); 
    return FALSE;
  }

#if HAVE_EXT2_FS
  if(sb.e2s.s_magic == EXT2_SUPER_MAGIC){
    //g_print("type --> ext2\n");
    type = "ext2";
  }
#endif
#if HAVE_MINIX_FS
  if(sb.ms.s_magic == MINIX_SUPER_MAGIC){
    //g_print("type --> minix\n");
    type = "minix";
  }
#endif
#if HAVE_EXT_FS
  if(sb.es.s_magic == EXT_SUPER_MAGIC){
    //g_print("type --> ext\n");
    type = "ext";
  }
#endif

  if(!type){
    struct partition* p;
    gchar buffer[SECTOR_SIZE]; 
    struct partition* part_table[4] = {
      offset(buffer, 0), offset(buffer, 1),
      offset(buffer, 2), offset(buffer, 3)
    };
    gint i;
    if(lseek(fd, 0, SEEK_SET) != 0
       || read(fd, buffer, SECTOR_SIZE) != SECTOR_SIZE){
      close(fd);
      return FALSE;  
    }
    for(i = 0 ; i < 4; i++){
      if((p = part_table[i])->sys_ind)
	break;
    }

    sprintf(d1, "%7s%-1d", d1, i+1);
    
    if(p->sys_ind == 1){
      //g_print("type --> msdos\n");
      type = "msdos";
    }
    else if(p->sys_ind == 0x4 || p->sys_ind == 0x6){
      //g_print("type --> vfat\n");
      type = "vfat";
    }
    else if(p->sys_ind == 0xb){
      //g_print("type --> fat32\n");
      type = "fat32";
    }
  }

  close(fd);
  return type;
}

gint mount_disk(gchar* dev){
  struct mntent mnt;
  gchar* fs_type;
  gchar* md;
  gchar* d;
  gint flags;
  
  md = g_strdup(mnt_dir);
  d = g_strdup(dev);
  fs_type = get_fs_type(dev, d);
   
  if(fs_type || 
     ((flags=(!dump_prot_mode(dev))?
       MS_NOSUID|MS_RDONLY:
       MS_NOSUID&~MS_RDONLY))){
    struct stat s;
    gint is_mount;
    
    if((stat(md, &s))){
      sprintf(msg, "Mnt dir not found!");
      return FALSE;
    }
    
    is_mount = mount(d, md, fs_type, 
		     0xc0ed0000|flags, "");
    if(is_mount == 0){
      mnt.mnt_fsname = d;
      mnt.mnt_dir = md;
      mnt.mnt_type = fs_type;
      mnt.mnt_opts = "defaults";
      mnt.mnt_freq = 0;
      mnt.mnt_passno = 0;

      if(mtab_is_writable()){
	FILE* fp = setmntent(MOUNTED, "a+");
	
	if(fp == NULL){
	  sprintf(msg, "Can't open %s!", MOUNTED);
	  return FALSE;
	}
	else{
	  if((addmntent(fp, &mnt)) == 1){
	    sprintf(msg, "Can't write %s!", MOUNTED);
	    return FALSE;
	  }
	  else{
	    endmntent(fp);
	    sprintf(msg, "Mounted disk on %s", md);
	  }
	}
      }
      return TRUE;
    }
    else {
      sprintf(msg, "Error: %s", strerror(errno));
      return FALSE;
    }
  }
  else{
    if(fs_type == NULL)
      sprintf(msg, "Wrong mnt type!");
    return FALSE;
  }
}
