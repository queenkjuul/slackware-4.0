#include "gtkzip.h"

GtkWidget* configwindow;
GtkWidget* default_skin_entry;

gchar* old_mnt_dir;
gchar* old_dev;

void hide_config_window(){
  gtk_widget_destroy(configwindow);
  configwindow = NULL;
}

void save_config_window(){
  save_options();
}

void ok_config_window(){
  if(!lock_mode)
    umount_disk(dev);
    
  if((strcmp(old_mnt_dir, save_mnt_dir) ||
     strcmp(old_dev, save_dev)) || lock_mode){
    
    reset_msg();
    if(!skin->b[0])
      gtk_timeout_remove(scroll_msg_timeout_tag);
    
    /* should free all the button */
    {
      gint i;
      for(i=0; i<5; i++)
	skin_msg->b[i] = NULL;
    }
    lock_mode = TRUE;

    update_caution_msg("Please restart GtkZip!");
  }
  save_config_window();
  hide_config_window();
}

void skin_item_selected(GtkWidget* clist, gint row, gint column,
			GdkEventButton* bevent, gpointer data){
  gchar* text = gtk_clist_get_row_data(GTK_CLIST(clist), row);
  if (text) gtk_entry_set_text(GTK_ENTRY(default_skin_entry),text);
}

void strset(char** dst, char* src)
{
  if(*dst != NULL)
    g_free(*dst);
  *dst = g_strdup(src);
}

void copy_string(GtkWidget* widget, gpointer data){
  gchar** val;
  
  val = data;
  strset(val, gtk_entry_get_text(GTK_ENTRY(widget)));
}

void set_timeout(GtkWidget* widget, gpointer data){
  int* val;
  
  val = data;
  *val = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (widget));
}

void create_config_window(gint start_tab){
  GtkWidget* configvbox;
  GtkWidget* configtabs;
  GtkWidget* hbox;
  GtkWidget* hbox1;
  GtkWidget* vbox;
  GtkWidget* button;
  GtkWidget* frame;
  GtkWidget* label;
  GtkWidget* entry;
  GtkWidget* table;
  GtkWidget* spinbutton;
  GtkAdjustment* adj;
  GtkStyle* style;
  gchar infostr[255];

  g_mutex_lock(main_mutex);

  old_mnt_dir  = mnt_dir;
  old_dev = dev;
  save_mnt_dir = g_strdup(mnt_dir);
  save_dev = g_strdup(dev);
  
  configwindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_signal_connect(GTK_OBJECT(configwindow), 
		      "delete_event",
		     (GtkSignalFunc) hide_config_window,
		      NULL);
  gtk_window_set_policy(GTK_WINDOW(configwindow),
			 FALSE, FALSE, TRUE);
  gtk_window_set_title(GTK_WINDOW(configwindow), 
			"GtkZip settings");
  gtk_container_border_width(GTK_CONTAINER(configwindow), 5);
  
  configvbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(configwindow), configvbox);
  gtk_widget_show(configvbox);

  hbox = gtk_hbox_new(TRUE, 0);
  gtk_box_pack_end(GTK_BOX(configvbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);
  
  button = gtk_button_new_with_label("Ok");
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_signal_connect(GTK_OBJECT(button), 
		      "clicked",
		     (GtkSignalFunc) ok_config_window, 
		      NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 20);
  gtk_widget_show(button);
  
  button = gtk_button_new_with_label("Save");
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_signal_connect(GTK_OBJECT(button), 
		      "clicked",
		     (GtkSignalFunc) save_config_window, 
		      NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 20);
  gtk_widget_grab_default(button);
  gtk_widget_show(button);
  
  button = gtk_button_new_with_label("Cancel");
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_signal_connect(GTK_OBJECT(button), 
		      "clicked",
		     (GtkSignalFunc) hide_config_window, 
		      NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 20);
  gtk_widget_show(button);

  configtabs = gtk_notebook_new();
  gtk_notebook_set_tab_pos(GTK_NOTEBOOK(configtabs), GTK_POS_TOP);
  gtk_box_pack_start(GTK_BOX(configvbox), configtabs, TRUE, TRUE, 0);

  hbox1 = gtk_hbox_new(FALSE, 0);
  gtk_container_border_width(GTK_CONTAINER(hbox1), 5);
  gtk_widget_show(hbox1);
  label = gtk_label_new("GtkZip settings");
  gtk_notebook_append_page(GTK_NOTEBOOK(configtabs), hbox1, label);

   /* general */
  frame = gtk_frame_new("Zip drive settings");
  gtk_container_border_width(GTK_CONTAINER (frame), 5);
  gtk_widget_show(frame);
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);

  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_border_width(GTK_CONTAINER(vbox), 5);
  gtk_container_add (GTK_CONTAINER(frame),vbox);
  gtk_widget_show(vbox);
  
  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);
  
  label = gtk_label_new("\tMount point:");
  gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
  gtk_widget_show (label);
  
  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);
  
  entry = gtk_entry_new();
  if(mnt_dir)
    gtk_entry_set_text(GTK_ENTRY(entry), mnt_dir);
  gtk_signal_connect(GTK_OBJECT (entry), "changed",
		     (GtkSignalFunc)copy_string,
		     &save_mnt_dir);
  gtk_box_pack_start(GTK_BOX(hbox), entry, TRUE, TRUE, 5);
  gtk_widget_show(entry);
  
  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);
  
  label = gtk_label_new("\tSCSI device:");
  gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
  gtk_widget_show (label);
  
  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);
  
  entry = gtk_entry_new();
  if(dev)
    gtk_entry_set_text(GTK_ENTRY(entry), dev);
  gtk_signal_connect(GTK_OBJECT(entry), "changed",
		     (GtkSignalFunc)copy_string,
		     &save_dev);
  gtk_box_pack_start(GTK_BOX(hbox), entry, TRUE, TRUE, 5);
  gtk_widget_show(entry);
  
  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);
  
  // interface
  frame = gtk_frame_new("Interface settings");
  gtk_container_border_width(GTK_CONTAINER (frame), 5);
  gtk_widget_show(frame);
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);

  vbox = gtk_vbox_new (FALSE, 2);
  gtk_container_border_width(GTK_CONTAINER(vbox), 5);
  gtk_container_add(GTK_CONTAINER(frame), vbox);
  gtk_widget_show(vbox);
  
  table = gtk_table_new(2, 2, FALSE);
  gtk_table_set_row_spacings(GTK_TABLE (table), 2);
  gtk_table_set_col_spacings(GTK_TABLE (table), 2);
  gtk_box_pack_end(GTK_BOX (vbox), table, TRUE, TRUE, 0);
  gtk_widget_show (table);
  
  label = gtk_label_new("\tScrolled message speed:");
  gtk_table_attach(GTK_TABLE(table), label, 0, 1, 0, 1,
		   GTK_FILL, GTK_FILL, 0, 0);
  gtk_widget_show (label);
  
  adj = (GtkAdjustment*)gtk_adjustment_new(scroll_msg_timeout, 500,
					   80000, 1, 5, 0);
  spinbutton = gtk_spin_button_new (adj, 1, 0);
  gtk_spin_button_set_numeric(GTK_SPIN_BUTTON(spinbutton), TRUE);
  gtk_widget_set_usize(spinbutton, 75, 0);
  gtk_table_attach(GTK_TABLE(table), spinbutton, 1, 2, 0, 1,
		   GTK_EXPAND | GTK_FILL, 0, 0, 0);
  gtk_signal_connect(GTK_OBJECT (spinbutton), "changed",
		     (GtkSignalFunc) set_timeout,
		     &scroll_msg_timeout);
  gtk_widget_show(spinbutton);
  
  label = gtk_label_new ("\tMessage timeout:");
  gtk_table_attach(GTK_TABLE(table), label, 0, 1, 1, 2,
		   GTK_FILL, GTK_FILL, 0, 0);
  gtk_widget_show(label);
  adj = (GtkAdjustment*)gtk_adjustment_new(msg_timeout, 0,
					   8000000, 1, 5, 0);
  spinbutton = gtk_spin_button_new (adj, 1, 0);
  gtk_spin_button_set_numeric(GTK_SPIN_BUTTON(spinbutton), TRUE);
  gtk_widget_set_usize (spinbutton, 75, 0);
  gtk_table_attach(GTK_TABLE(table), spinbutton, 1, 2, 1, 2,
		   GTK_EXPAND | GTK_FILL, 0, 0, 0);
  gtk_signal_connect(GTK_OBJECT (spinbutton), "changed",
		     (GtkSignalFunc) set_timeout,
		     &msg_timeout);
  gtk_widget_show(spinbutton);
  
}

void show_config_window(){
  if(configwindow){
    gdk_window_raise(configwindow->window);
    return;
  }
  
  create_config_window(0);
  gtk_widget_show_all(configwindow);
}
