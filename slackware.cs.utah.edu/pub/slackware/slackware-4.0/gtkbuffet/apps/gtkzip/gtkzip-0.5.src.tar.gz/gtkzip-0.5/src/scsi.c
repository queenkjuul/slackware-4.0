#include <stdio.h>
#include <mntent.h>
#include <unistd.h>
#include "gtkzip.h"
#include "scsi.h"

/* some private variable */
gchar lock_pwd[34];
gchar tpwd[34];
gint pwd_index = 0;
gint state = 0;
gint tfd = 0;
gint tmode = 0;

gint is_mounted(gchar* fs){
/* -1 = error,  0 = not mounted,  1 = mounted */ 
  struct mntent* mp;
  FILE* mtab;
  
  mtab = setmntent(MOUNTED,"r");
  if(!mtab){
    sprintf(msg, "Unable to access %s!", MOUNTED);
    return -1;
  }
  while((mp=getmntent(mtab))) 
    if(!strncmp(mp->mnt_fsname,fs,8)) break;
  if(mp != NULL){
    strcpy(mnt_fsname, mp->mnt_fsname);
    strcpy(mnt_dir, mp->mnt_dir);
    strcpy(mnt_type, mp->mnt_type);
    strcpy(msg, "Device is mounted!");
  }
  endmntent(mtab);
  return (mp != NULL);
}

gint is_raw_scsi(gchar*  fs){
  return ((strlen(fs) == 8) && (strncmp("/dev/sd",fs,7) == 0));
}

gint is_zip_drive(gint fd){
  gchar	id[25];
  gint	i;
  
  scsi_cmd.inlen = 0;
  scsi_cmd.outlen = 40;
  scsi_cmd.cmd[0] = 0x12;		/* inquiry */
  scsi_cmd.cmd[1] = 0;
  scsi_cmd.cmd[2] = 0;
  scsi_cmd.cmd[3] = 0;
  scsi_cmd.cmd[4] = 40;
  scsi_cmd.cmd[5] = 0;

  if(ioctl(fd,SCSI_IOCTL_SEND_COMMAND,(void* )&scsi_cmd)){
    sprintf(msg, "Inquiry ioctl error.");
    return FALSE;
  }
  
  for(i=0;i<24;i++) id[i] = scsi_cmd.cmd[i+8];
  id[24] = 0;
  
  sprintf(msg, "%s", id);
  if(!strncmp(id,"IOMEGA  ZIP 100",15)) return (1);
  else return FALSE;
}

gint motor(gint fd, gint mode){
  scsi_cmd.inlen = 0;
  scsi_cmd.outlen = 0;
  scsi_cmd.cmd[0] = 0x1b;		/* start/stop */
  scsi_cmd.cmd[1] = 0;
  scsi_cmd.cmd[2] = 0;
  scsi_cmd.cmd[3] = 0;
  scsi_cmd.cmd[4] = mode;
  scsi_cmd.cmd[5] = 0;
  
  if(ioctl(fd,SCSI_IOCTL_SEND_COMMAND,(void* )&scsi_cmd)){
    sprintf(msg, "Motor ioctl error.");
    return FALSE;
  }
  return TRUE;
}

gint unlock_door(gint fd){
  scsi_cmd.inlen = 0;
  scsi_cmd.outlen = 0;
  scsi_cmd.cmd[0] = 0x1e;		/* prevent/allow media removal */
  scsi_cmd.cmd[1] = 0;
  scsi_cmd.cmd[2] = 0;
  scsi_cmd.cmd[3] = 0;
  scsi_cmd.cmd[4] = 0;
  scsi_cmd.cmd[5] = 0;
  
  if(ioctl(fd,SCSI_IOCTL_SEND_COMMAND,(void* )&scsi_cmd)){
    sprintf(msg, "Unlock ioctl error.");
    return FALSE;
  }
  return TRUE;
}

gint eject_disk(gchar* dev){
  gint	fd;
  
  if((fd = open_dev(dev)))
    if(unlock_door(fd))
      if(motor(fd,1))
	if(motor(fd,2)){
	  close(fd);
	  status = NO_DISK;
	  mount_status = STATUS_UMOUNT;
	  return TRUE;
	}
  close(fd);
  return FALSE;
}

gint get_prot_mode(gint fd){
  scsi_cmd.inlen = 0;
  scsi_cmd.outlen = 256;
  scsi_cmd.cmd[0] = 6;		/* Iomega non-sense command */
  scsi_cmd.cmd[1] = 0;
  scsi_cmd.cmd[2] = 2;
  scsi_cmd.cmd[3] = 0;
  scsi_cmd.cmd[4] = 128;
  scsi_cmd.cmd[5] = 0;

  if(ioctl(fd,SCSI_IOCTL_SEND_COMMAND,(void* )&scsi_cmd)){
    sprintf(msg, "Non-sense ioctl error.");
    return(-1);
  }
  
  return (scsi_cmd.cmd[21] & 0x0f);	/* protection code */
}

gint dump_prot_mode(gchar*  dev){  /* explain protection codes */
  gint	s, fd;
  
  if(!(fd = open_dev(dev))) return (-1);
  s = get_prot_mode(fd);
  if(s == 0) sprintf(msg, "Disk full accessible...");
  if(s == 2) sprintf(msg, "Disk read only...");
  if(s == 3) sprintf(msg, "Disk pwd read only...");
  close(fd);
  return (s);
}

void delete_lock_pwd(){
  int i;
  for(i=0; i<34; i++)
    tpwd[i]=lock_pwd[i]='\0';
}

void set_prot_mode_helper(){
  gint len;
  gint i;
  len = strlen(lock_pwd);
  
  scsi_cmd.inlen = len;
  scsi_cmd.outlen = 0;
  scsi_cmd.cmd[0] = 0x0c;
  scsi_cmd.cmd[1] = tmode;
  scsi_cmd.cmd[2] = 0;
  scsi_cmd.cmd[3] = 0;
  scsi_cmd.cmd[4] = len;
  scsi_cmd.cmd[5] = 0;
  
  for(i=0;i<len;i++) scsi_cmd.cmd[6+i] = lock_pwd[i];
  
  gtk_signal_disconnect(GTK_OBJECT(mainwindow),
			msg_handler_id);
  function_handler_id =
    gtk_signal_connect(GTK_OBJECT(mainwindow), 
		     "key_press_event",
		     (GtkSignalFunc)function_key_pressed,
		     NULL);
  delete_lock_pwd();
  if(ioctl(tfd,SCSI_IOCTL_SEND_COMMAND,(void* )&scsi_cmd)){
    close(tfd);
    reset_msg();
    gtk_timeout_remove(scroll_msg_timeout_tag);
    update_msg("Wrong pwd!");
  }
  else{
    close(tfd);
    dump_prot_mode(dev);
    eject_disk(dev);	
    reset_msg();
    gtk_timeout_remove(scroll_msg_timeout_tag);
    update_msg(msg);
  }
}

void msg_key_pressed(GtkWidget *widget, GdkEventKey *event){
  static gint last_key = 0;
  static gint last_state = 0;
  static guint32 last_time = 0;
    
  if(pwd_index >= 34){
    update_caution_msg("Pwd too long!");
    return;
  }
  if(event->keyval == last_key && event->state == last_state &&
      last_time + 100 >= event->time){
    return;
  }
  else{
    last_key = event->keyval;
    last_state = event->state;
    last_time = event->time;
  }
  
  if(event->state & GDK_CONTROL_MASK){
    switch(event->keyval){
      case 'c': 
	hide_msg_window();
	break;
      default:
	break;
    }
  }
	
  if(state==0){
    switch(event->keyval){
      case 'n':
      case 'N':{
	set_prot_mode_helper();
	break;
      }
      case 'p':
      case 'P':{
	state = 1;
	tmode = IOMEGA_PROTECTION_MODE_ROPW;
	reset_msg();
	gtk_timeout_remove(scroll_msg_timeout_tag);
	update_caution_msg("Pwd?");
	break;
      }
    }
  }
  else{
    reset_msg();
    gtk_timeout_remove(scroll_msg_timeout_tag);
    switch(event->keyval){
      case ENTER_KEY:{
	set_prot_mode_helper();
	break;
      }
      case BACKSPACE_KEY:{
	if(pwd_index){
	  tpwd[--pwd_index] = '\0';
	  lock_pwd[pwd_index] = '\0';
	  update_caution_msg(tpwd);
	}
	break;
      }
      default:{
	strncat(tpwd, "*", 1);
	sprintf(lock_pwd, "%s%c", lock_pwd, event->keyval);
	pwd_index++;
	update_caution_msg(tpwd);
	break;
      }
    }
  }
}

int set_prot_mode(gchar* dev, int mode){
  gint	i;
  gint oldmode;
  gint len;
  
  if(!(tfd = open_dev(dev))){
    sprintf (msg, "No disk!");
    return FALSE;
  }
  tmode = mode;
  oldmode = get_prot_mode(tfd);

  switch(oldmode){
    case IOMEGA_PROTECTION_MODE_ROPW:{
      switch(mode){
	case IOMEGA_PROTECTION_MODE_ROPW:{
	  sprintf (msg, "Change pwd not supported!");
	  return FALSE;
	}
	case IOMEGA_PROTECTION_MODE_RO:
	case IOMEGA_PROTECTION_MODE_RW:{
	  state = 1;
	  update_caution_msg("Pwd?");
	  gtk_signal_disconnect(GTK_OBJECT(mainwindow),
				function_handler_id);
	  msg_handler_id =
	    gtk_signal_connect(GTK_OBJECT(mainwindow), 
			       "key_press_event",
			       (GtkSignalFunc)msg_key_pressed,
			       NULL);
	  return WAIT;
	}
	default:{
	  sprintf(msg, "Mode not supported!");
	  return FALSE;
	}
      }
      break;
    }
    case IOMEGA_PROTECTION_MODE_RO:
    case IOMEGA_PROTECTION_MODE_RW:{
      switch (mode){
	case IOMEGA_PROTECTION_MODE_RO:
	case IOMEGA_PROTECTION_MODE_ROPW:{
	  state = 0;
	  update_caution_msg("Nor/Pwd protected?");
	  gtk_signal_disconnect(GTK_OBJECT(mainwindow),
			function_handler_id);
	  msg_handler_id =
	    gtk_signal_connect(GTK_OBJECT(mainwindow), 
			       "key_press_event",
			       (GtkSignalFunc)msg_key_pressed,
			       NULL);
	  return WAIT;
	}
	case IOMEGA_PROTECTION_MODE_RW:{
	  len = 0;
	  break;
	}
	default:{
	  sprintf(msg, "Mode not supported!");
	  return FALSE;
	}
      }
      break;
    }
    case -1:{
      sprintf (msg, "Read mode failed!");
      return FALSE;
    }
    default:{
      sprintf (msg, "Read mode failed!");
      return FALSE;
    }
  }

  scsi_cmd.inlen = len;
  scsi_cmd.outlen = 0;
  scsi_cmd.cmd[0] = 0x0c;
  scsi_cmd.cmd[1] = mode;
  scsi_cmd.cmd[2] = 0;
  scsi_cmd.cmd[3] = 0;
  scsi_cmd.cmd[4] = len;
  scsi_cmd.cmd[5] = 0;

  if(ioctl(tfd,SCSI_IOCTL_SEND_COMMAND,(void* )&scsi_cmd)){
    close(tfd);
    reset_msg();
    gtk_timeout_remove(scroll_msg_timeout_tag);
    update_msg("Can't set protection mode!");
  }
  
  close(tfd);
  dump_prot_mode(dev);
  eject_disk(dev);	/* so linux can reset the wp mode */
  return TRUE;
}

gint open_dev(gchar* dev){
  gint	zfd;
  
  zfd = open(dev,0);
  if(zfd < 0){
    sprintf(msg, "Unable to open %s!", dev);
    return FALSE;;
  }
  return (zfd);
}

gint check_scsi_dev(gchar* rsd){ 
  gint zfd;
  gint s;
  if(!is_raw_scsi(dev)){
    lock_mode = TRUE;
    /* should free all the button */
    {gint i;
    for(i=0; i<5; i++)
      skin_msg->b[i] = NULL;
    }
    sprintf(msg, "%s is not a raw scsi device!", dev);
    update_caution_msg(msg);
    show_config_window();
  }
  else if(geteuid()){
    printf("GtkZip permission error: Your effective user id is %d.\n", geteuid());
    printf("Check the suid bit and ownership on the executable.\n");
    return FALSE;
  }
  else if(!(zfd = open_dev(dev))){
    status = NO_DISK;
    mount_status = STATUS_UMOUNT;
  }
  else if(!(dtype=is_zip_drive(zfd))){
    lock_mode = TRUE;
    /* should free all the button */
    {gint i;
    for(i=0; i<5; i++)
      skin_msg->b[i] = NULL;
    }
    update_caution_msg("Unable to identify an Zip drive!");
    show_config_window();
  }
  else{
    if(is_mounted(dev))
      mount_status = STATUS_MOUNT;
    else mount_status = STATUS_UMOUNT;
    s = get_prot_mode(zfd);
    if(s == IOMEGA_PROTECTION_MODE_RO)
      lock_status = STATUS_NOR_LOCK;
    else if(s == IOMEGA_PROTECTION_MODE_ROPW)
      lock_status = STATUS_PWD_LOCK;
    else lock_status = STATUS_UNLOCK;
    close(zfd);
    status = HAVE_DISK;
  }
  return TRUE;
}
