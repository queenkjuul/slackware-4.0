#include "gtkzip.h"

extern FILE* yyin;
extern void yylex();

void write_char_option(FILE *f, gchar *label, gchar *text){
  if (text)
    fprintf(f,"%s: %s\n", label, text);
  else
    fprintf(f,"%s: \n", label);
}

void write_int_option(FILE *f, gchar *label, gint n){
  fprintf(f,"%s: %d\n", label, n);
}

void save_options(){
  FILE* f;
  gchar* rc_path;
  gchar* rcdir;
  
  rcdir = g_strconcat(homedir(), "/.gtkzip", NULL);
  if (!isdir(rcdir)){
    printf("Creating gtkzip dir:%s\n", rcdir);
    if((mkdir (rcdir, 0755) < 0)){
      printf("Could not create dir:%s\n", rcdir);
      printf("Config not saved!\n");
      g_free(rcdir);
      return;
    }
  }
  
  rc_path = g_strconcat(rcdir, "/gtkziprc", NULL);
  g_free(rcdir);
  
  f = fopen(rc_path,"w");
  if(!f){
    printf("error saving config file: %s\n", rc_path);
    g_free(rc_path);
    return;
  }
  
  fprintf(f,"######################################################################\n");
  fprintf(f,"#                         GtkZip config file           version %s #\n", VERSION);
  fprintf(f,"#                                                                    #\n");
  fprintf(f,"#  Everything in this file can be changed in the option dialogs.     #\n");
  fprintf(f,"#      (so there should be no need to edit this file by hand)        #\n");
  fprintf(f,"#                                                                    #\n");
  fprintf(f,"######################################################################\n");
  
  fprintf(f,"\n##### Zip drive settings #####\n\n");

  write_char_option(f, "Zip_Mount_Point", (!save_mnt_dir)?mnt_dir:save_mnt_dir);
  write_char_option(f, "Zip_Device", (!save_dev)?dev:save_dev);

  fprintf(f,"\n##### Interface settings #####\n\n");

  write_int_option(f, "Scroll_Mesg_Timeout", scroll_msg_timeout);
  write_int_option(f, "Mesg_Timeout", msg_timeout);

  fprintf(f,"\n######################################################################\n");
  fprintf(f,"#                      end of GTkZip config file                     #\n");
  fprintf(f,"######################################################################\n");
  
  fclose(f);
  
  g_free(rc_path);
}

gint load_options(){
  gchar* rc_path;
  rc_path = g_strconcat(homedir(), "/.gtkzip/gtkziprc", NULL);
  if(!(yyin = fopen(rc_path, "r")))
    return FALSE;
  yylex();  
  g_free(rc_path);
  return TRUE;
}
