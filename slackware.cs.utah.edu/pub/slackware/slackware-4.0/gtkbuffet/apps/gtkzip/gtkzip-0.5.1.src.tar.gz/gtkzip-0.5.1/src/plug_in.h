typedef struct _PlugIn PlugIn;
struct _PlugIn{
  gchar name[20];
  SkinData* skin;
  void (*func)();
  void (*cb_funcs[5])();
};

//#define pi_skin skin
#define plug_in_get_status() status
#define plug_in_get_mount_status() mount_status
#define plug_in_get_mnt_dir() mnt_dir

GList* plug_ins;

GList* plug_ins_alloc();
gint plug_ins_length();
PlugIn* plug_ins_nth(gint i);
void insert_plug_in(PlugIn* p);

void plug_in_draw_skin(SkinData* s);
void plug_in_update_msg(gchar* m, gint t1);
void plug_in_undraw_skin();

