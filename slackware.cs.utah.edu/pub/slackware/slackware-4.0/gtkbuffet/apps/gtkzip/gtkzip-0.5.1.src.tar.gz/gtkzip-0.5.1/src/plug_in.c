#include "gtkzip.h"
#include "plug_in.h"

GList* plug_ins_alloc(){
  return g_list_alloc();
}

void insert_plug_in(PlugIn* p){
  plug_ins = g_list_append(plug_ins, (gpointer)p);
}

gint plug_ins_length(){
  return g_list_length(plug_ins);
}

PlugIn* plug_ins_nth(gint i){
  return (PlugIn*)g_list_nth_data(plug_ins, i);
}

void plug_in_draw_skin(SkinData* s){
  skin = (s)?s:skin_msg;
  gtk_drawing_area_size(GTK_DRAWING_AREA(display_area), skin->width, skin->height);
  gtk_widget_set_usize(mainwindow, skin->width, skin->height);
  gtk_widget_shape_combine_mask(mainwindow, skin->mask, 0, 0);
}

void plug_in_update_msg(gchar* m, gint t1){
  if(!skin) return;
  
  if(scroll_msg_timeout_tag != 0)
    gtk_timeout_remove(scroll_msg_timeout_tag);

  draw_font(skin->msg, m);
  scroll_msg_timeout_tag =
    gtk_timeout_add(t1,(GtkFunction)update_scroll_msg,m);
}

void plug_in_undraw_skin(){
  msg_timeout_tag =
    gtk_timeout_add(0, 
		    (GtkFunction)hide_msg_window, 
		    NULL);
}
