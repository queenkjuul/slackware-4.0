void diskusage_init();
