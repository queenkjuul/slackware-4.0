#include "gtkzip.h"
#include "icon.xpm"

#define DEF_DEV	"/dev/sda" 		      
#define ZIP_MOUNT_POINT	"/mnt/zip"

gchar msg[256];
gchar mnt_type[64];
gchar mnt_fsname[64];
gint dtype;
gint status;
gint mount_status;
gint lock_status;
gchar* dev =  DEF_DEV;
gchar* mnt_dir = ZIP_MOUNT_POINT;
gchar* mnt_dirs[256];
gchar* save_mnt_dir;
gchar* save_dev;

/* main window widgets */
GtkWidget* mainwindow;
GtkWidget* display_area;
GtkWidget* main_menu;

/* skin variables */
SkinData* skin = NULL;
SkinData* skin_normal = NULL;
SkinData* skin_msg = NULL;
SkinData* save_skin_normal = NULL;
SkinData* save_skin_msg = NULL;
gchar* default_skin = NULL;

/* misc */
gint wm_decorations = FALSE;
gchar* browser_command = NULL;
gchar* skin_dir = NULL;
gchar** gtkzip_icon_xpm = icon_xpm;
gint msg_timeout_tag;
gint scroll_msg_timeout_tag;
gint function_handler_id;
gint msg_handler_id;

gint msg_timeout = 13888;
gint scroll_msg_timeout = 1388;

gint name_scroll_pos = -1;
gint name_scroll_dir = SCROLL_RIGHT;
gint lock_mode = FALSE;

GMutex* main_mutex;
GCond* main_cond;
