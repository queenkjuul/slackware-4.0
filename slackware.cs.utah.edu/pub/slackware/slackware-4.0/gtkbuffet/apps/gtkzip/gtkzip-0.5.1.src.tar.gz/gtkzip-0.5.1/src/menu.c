#include "gtkzip.h"
#include "plug_in.h"

GtkWidget* create_main_menu(){
  GtkWidget* menu;
  GtkWidget* button;
  GtkWidget* info;
  GtkWidget* info_menu;
  GtkWidget* plug_in;
  GtkWidget* plug_in_menu;

  gint i;
  gint pl;
  PlugIn* tmp_plug_in;
  
  menu = gtk_menu_new();

  button = gtk_menu_item_new_with_label("Mount/Umount");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) exec_function1,
		      (gpointer)mount_button_pressed);
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Eject");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) exec_function1,
		      (gpointer)eject_button_pressed);
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Lock");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) exec_function1,
		      (gpointer)lock_button_pressed);
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Unlock");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) exec_function1,
		      (gpointer)unlock_button_pressed); 
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  /* start plug-in */

  plug_in = gtk_menu_item_new_with_label("Plug-ins");
  gtk_menu_append(GTK_MENU(menu), plug_in);
  gtk_widget_show(plug_in);
 
  plug_in_menu = gtk_menu_new();

  pl = plug_ins_length();
  if(pl == 0){
    button = gtk_menu_item_new_with_label("Plug-ins (empty)");
    gtk_menu_append(GTK_MENU(plug_in_menu),button);
    gtk_widget_show(button);
  }
  for(i=1; i<pl; i++){
    tmp_plug_in = plug_ins_nth(i);
    button = gtk_menu_item_new_with_label(tmp_plug_in->name); 
    gtk_signal_connect (GTK_OBJECT (button), 
			"activate",
			(GtkSignalFunc)exec_function1,
			(gpointer)(tmp_plug_in->func));
    gtk_menu_append(GTK_MENU(plug_in_menu),button);
    gtk_widget_show(button);
  }
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(plug_in), plug_in_menu);
   
  /* end plug-in */
  
  button = gtk_menu_item_new();
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Preferences...");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc)show_config_window,
		      NULL);
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  info = gtk_menu_item_new_with_label("Info...");
  gtk_menu_append(GTK_MENU(menu), info);
  gtk_widget_show(info);

  info_menu = gtk_menu_new();

  button = gtk_menu_item_new_with_label("Gtk.org");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) show_gtk_info,
		      NULL);
  gtk_menu_append(GTK_MENU(info_menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Iomega.com");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) show_zip_info,
		      NULL);
  gtk_menu_append(GTK_MENU(info_menu),button);
  gtk_widget_show(button);
  
  button = gtk_menu_item_new_with_label("About GtkZip");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) show_about_info,
		      NULL);
  gtk_menu_append(GTK_MENU(info_menu),button);
  gtk_widget_show(button);
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(info), info_menu);

  button = gtk_menu_item_new();
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Iconify");
  gtk_signal_connect (GTK_OBJECT (button), "activate",
		      (GtkSignalFunc) iconify_button_pressed, NULL);
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Exit");
  gtk_signal_connect (GTK_OBJECT (button), "activate",
		      (GtkSignalFunc) destroy_window, NULL);
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  return menu;
}

GtkWidget* create_exit_menu(){
  GtkWidget* menu;
  GtkWidget* button;
  GtkWidget* info;
  GtkWidget* info_menu;

  menu = gtk_menu_new();

  button = gtk_menu_item_new_with_label("Preferences...");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc)show_config_window,
		      NULL);
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  info = gtk_menu_item_new_with_label("Info...");
  gtk_menu_append(GTK_MENU(menu), info);
  gtk_widget_show(info);

  info_menu = gtk_menu_new();

  button = gtk_menu_item_new_with_label("Gtk.org");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) show_gtk_info,
		      NULL);
  gtk_menu_append(GTK_MENU(info_menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Iomega.com");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) show_zip_info,
		      NULL);
  gtk_menu_append(GTK_MENU(info_menu),button);
  gtk_widget_show(button);
  
  button = gtk_menu_item_new_with_label("About GtkZip");
  gtk_signal_connect (GTK_OBJECT (button), 
		      "activate",
		      (GtkSignalFunc) show_about_info,
		      NULL);
  gtk_menu_append(GTK_MENU(info_menu),button);
  gtk_widget_show(button);
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(info), info_menu);

  button = gtk_menu_item_new();
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Iconify");
  gtk_signal_connect (GTK_OBJECT (button), "activate",
		      (GtkSignalFunc) iconify_button_pressed, NULL);
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  button = gtk_menu_item_new_with_label("Exit");
  gtk_signal_connect (GTK_OBJECT (button), "activate",
		      (GtkSignalFunc) destroy_window, NULL);
  gtk_menu_append(GTK_MENU(menu),button);
  gtk_widget_show(button);

  return menu;
}
