#include "gtkzip.h"

void update_msg(gchar* m){
  skin = skin_msg;

  if(!skin) return;

  gtk_drawing_area_size(GTK_DRAWING_AREA(display_area), skin->width, skin->height);
  gtk_widget_set_usize(mainwindow, skin->width, skin->height);
  gtk_widget_shape_combine_mask(mainwindow, skin->mask, 0, 0);
  
  gtk_signal_disconnect(GTK_OBJECT(mainwindow),
			function_handler_id);
  msg_timeout_tag =
    gtk_timeout_add(msg_timeout, 
		    (GtkFunction)hide_msg_window, 
		    NULL);

  draw_font(skin->msg, m);
  scroll_msg_timeout_tag =
    gtk_timeout_add(scroll_msg_timeout, 
		    (GtkFunction)update_scroll_msg, 
		    m);
}

gint update_scroll_msg(gchar* m){
  redraw_font(m);
  return 1;
}

void update_caution_msg(gchar* m){
  skin = skin_msg;

  if(!skin) return;

  gtk_drawing_area_size(GTK_DRAWING_AREA(display_area), skin->width, skin->height);
  gtk_widget_set_usize(mainwindow, skin->width, skin->height);
  gtk_widget_shape_combine_mask(mainwindow, skin->mask, 0, 0);
  
  draw_font(skin->msg, m);
  scroll_msg_timeout_tag =
    gtk_timeout_add(scroll_msg_timeout, 
		    (GtkFunction)update_scroll_msg, 
		    m);
}

void update_all_display_info(){
  gint i;

  if(!skin) return;

  for(i; i < 5; i++)
    if(skin->b[i])
      draw_button(skin->b[i], FALSE, FALSE, TRUE);
    
  if(status == NO_DISK){
    change_button_light(skin->b[0], FALSE);  
    change_button_light(skin->b[2], FALSE);
  }
  if(mount_status == STATUS_UMOUNT){
    if(status == HAVE_DISK) {
    }
    change_button_light(skin->b[0], FALSE);
  }
  else if(mount_status == STATUS_MOUNT){
    change_button_light(skin->b[0], TRUE);
  }
  if(lock_status == STATUS_NOR_LOCK ||
     lock_status == STATUS_UNLOCK){
    change_button_light(skin->b[2], FALSE);
  }
  else if(lock_status == STATUS_PWD_LOCK){
    change_button_light(skin->b[2], TRUE);
  }
}

void redraw_font(gchar* m){
  FontData* font;
  if(skin->msg){
    font = skin->msg;
    if(strlen(m) > font->length){
      if(name_scroll_dir == SCROLL_RIGHT){
	if(name_scroll_pos == -1){
	  draw_font(skin->msg, m);
	  name_scroll_pos++; }
	else if(name_scroll_pos < strlen(m) - font->length){
	  draw_font(skin->msg, m+name_scroll_pos);
	  name_scroll_pos++; }
	else{
	  name_scroll_dir = SCROLL_LEFT;
	  draw_font(skin->msg, m+name_scroll_pos);
	  name_scroll_pos--; }
      }
      else if(name_scroll_dir == SCROLL_LEFT){
	if(name_scroll_pos == 0){
	  name_scroll_dir = SCROLL_RIGHT;
	  draw_font(skin->msg, m+name_scroll_pos);
	  name_scroll_pos++; } 
	else{
	  draw_font(skin->msg, m+name_scroll_pos);
	  name_scroll_pos--; }
      }
    }
    else draw_font(skin->msg, m);
  }
}

void reset_msg(){
  name_scroll_pos = -1;
  name_scroll_dir = SCROLL_RIGHT;
}
