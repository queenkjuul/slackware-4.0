#include "gtkzip.h"

static gint in_drag;
static gint in_move;
static gint move_x_pos;
static gint move_y_pos;
static gint orig_x_mpos;
static gint orig_y_mpos;

static ButtonData* current_button;

static const gchar iso_ascii[]={
  ' ','|','c','L','c','Y','|','S','\"','c',' ','<','!','-','r','~',
  'o',' ','2','3','\'','u','p','.',',','1',' ','>',' ',' ',' ','?',
  'A','A','A','A','A','A','A','C','E','E','E','E','I','I','I','I',
  'D','N','O','O','O','O','O','x','0','U','U','U','U','Y','P','B',
  'a','a','a','a','a','a','a','c','e','e','e','e','i','i','i','i',
  'o','n','o','o','o','o','o','/','o','u','u','u','u','y','p','y'
};

GdkPixmap* get_pixmap_from_data(gchar** data)
{
  GdkPixmap* pixmap = NULL;
  GdkBitmap* mask = NULL;
  
  gdk_imlib_data_to_pixmap(data, &pixmap, &mask);
  if(mask) gdk_imlib_free_bitmap(mask);
  return pixmap;
}

SkinData* new_skin(){
  SkinData* s;
  s = g_new0(SkinData, 1);
  return s;
}

void change_button_light(ButtonData* button, gint lit){
  gint l = 0;
  
  if(!button || !button->has_light) return; 
  
  button->lit = lit;
  
  if(button->pushed)
    l = button->width * (1 + (2 * button->lit));
  else
    l = button->width * 2 * button->lit;
  
  gdk_draw_pixmap(skin->background,
		  display_area->style->fg_gc[GTK_WIDGET_STATE(display_area)],
		  button->pixmap, 
		  l, 0, 
		  button->x, button->y, button->width, 
		  button->height);
  redraw_skin();
}

ButtonData* new_button(GdkPixmap* pixmap,
		       gint prelight,
		       gint light,
		       gint x, gint y, 
		       void(*click1_func)(void* ), 
		       void(*press_func)(void* ), 
		       void(*click2_func)(void* )){
  ButtonData* button;
  gint width;
  gint height;
    
  button = g_new0(ButtonData, 1);

  gdk_window_get_size(pixmap, &width, &height);
  
  button->pixmap = pixmap;
  button->has_light = light;
  button->has_prelight = prelight;
  button->pushed = FALSE;
  button->lit = FALSE;
  button->prelit = FALSE;
  button->x = x;
  button->y = y;

  button->width = 
    width / (2 + (light*prelight) + prelight + (2*light));
  button->height = height;
  
  button->press_func = press_func;
  button->click2_func = click2_func;
  button->click1_func = click1_func;
  
  return button;
}

ButtonData* new_button_from_data(gchar** data, 
				 gint prelight, 
				 gint light, 
				 gint x, gint y, 
				 void(*click1_func)(void* ), 
				 void(*press_func)(void* ),
				 void(*click2_func)(void* )){
  GdkPixmap* pixmap;
  
  pixmap = get_pixmap_from_data(data);
  
  return new_button(pixmap, 
		    prelight, 
		    light,
		    x, y, 
		    click1_func, 
		    press_func, 
		    click2_func);
}

FontData* new_font(GdkPixmap* pixmap, gint length, gint x, gint y){
  FontData* font;
  gint width;
  gint height;
  
  font = g_new0(FontData, 1);
  
  gdk_window_get_size(pixmap, &width, &height);
  
  font->pixmap = pixmap;
  
  font->length = length;
  font->char_width = width / 32;
  font->char_height = height / 3;
  font->width = font->char_width*  length;
  font->height = font->char_height;
  font->x = x;
  font->y = y;
  
  return font;
}

FontData*  new_font_from_data(gchar** data, gint length, gint x, gint y){
  GdkPixmap* pixmap;

  pixmap = get_pixmap_from_data(data);

  return new_font(pixmap, length, x, y);
}

void sync_window_to_skin(){
  if(!skin) return;
  
  gtk_drawing_area_size(GTK_DRAWING_AREA(display_area), skin->width, skin->height);
  gtk_widget_set_usize(mainwindow, skin->width, skin->height);
  gtk_widget_shape_combine_mask(mainwindow, skin->mask, 0, 0);
  
  update_all_display_info();
}

static void free_button(ButtonData* button){
  if(!button) return;
  if(button->pixmap) gdk_imlib_free_pixmap(button->pixmap);
  g_free(button);
}

static void free_font(FontData* font){
  if (!font) return;
  if (font->pixmap) gdk_imlib_free_pixmap(font->pixmap);
  g_free(font);
}

void free_skin(SkinData* s){
  gint i;
  if(!s) return;
  if(s->background) gdk_imlib_free_pixmap(s->background);
  if(s->mask) gdk_imlib_free_bitmap(s->mask);
  if(s->msg) free_font(s->msg);
  for(i=0; i<5; i++)
    if(s->b[i]) free_button(s->b[i]);
  g_free(s);
}

void redraw_skin(){
  gdk_window_set_back_pixmap(display_area->window, 
			     skin->background, FALSE);
  gdk_window_clear(display_area->window);
}

void draw_button(ButtonData* button, 
		 gint prelight, gint pressed, gint force){
  gint l = 0;
  
  if(!button){ return; }
  
  if(force){
    if(button->prelit)
      l = button->width * (2 + (2 * button->has_light) + button->lit);
    else
      l = button->width * (button->pushed + (2 * button->lit));
    gdk_draw_pixmap(skin->background,
		    display_area->style->fg_gc[GTK_WIDGET_STATE(display_area)],
		    button->pixmap, l, 0, 
		    button->x, button->y, 
		    button->width, button->height);
    redraw_skin();
    return;
  }
  if(button->has_prelight && prelight && !button->prelit){
    button->prelit = TRUE;
    l = button->width * ((2 * button->has_light) + 2 + button->lit);
    gdk_draw_pixmap(skin->background,
		    display_area->style->fg_gc[GTK_WIDGET_STATE(display_area)],
		    button->pixmap, l, 0, 
		    button->x, button->y, 
		    button->width, button->height);
    redraw_skin();
  }
  if(!prelight && button->prelit){
    button->prelit = FALSE;
    if(pressed && !button->pushed){
      button->pushed = TRUE;
      l = button->width * (1 + ( 2 * button->lit));
    }
    else
      l = button->width * button->lit * 2;
    
    gdk_draw_pixmap(skin->background,
		     display_area->style->fg_gc[GTK_WIDGET_STATE(display_area)],
		     button->pixmap, l, 0, 
		     button->x, button->y, 
		     button->width, button->height);
    redraw_skin();
  }
  if(!pressed && button->pushed){
    button->pushed = FALSE;
    if(prelight){
      if(button->has_prelight)
	l = button->width * (2 + (2 * button->has_light) + button->lit);
      else
	l = button->width * (2 * button->lit);
    }
    else
      l = button->width * 2 * button->lit;
    gdk_draw_pixmap(skin->background,
		     display_area->style->fg_gc[GTK_WIDGET_STATE(display_area)],
		     button->pixmap, l, 0, 
		     button->x, button->y, 
		     button->width, button->height);
    redraw_skin();
  }
  if(pressed && !button->pushed){
    button->pushed = TRUE;
    l = button->width * (1 + ( 2 * button->lit));
    gdk_draw_pixmap(skin->background,
		     display_area->style->fg_gc[GTK_WIDGET_STATE(display_area)],
		     button->pixmap, l, 0, 
		     button->x, button->y,
		     button->width, button->height);
    redraw_skin();
  }
}

void draw_font(FontData* font, gchar* text){
  gint i;
  gint px, py;
  guint8 c;
  gint l;
  
  if(!font) return;
  
  l = strlen(text);
  
  for(i=0; i < font->length; i++){
    if(i < l){
      c = text[i];
      if(c > 127){
        if(c > 159)
          c = iso_ascii[c - 160];
	else
          c = ' ';
      }
      c -= 32;
      py = c / 32;
      px = c - (py * 32);
      px = px * font->char_width;
      py = py * font->char_height;
      gdk_draw_pixmap(skin->background,
		      display_area->style->fg_gc[GTK_WIDGET_STATE(display_area)],
		      font->pixmap, 
		      px, py, 
		      font->x + i * font->char_width, font->y,
		      font->char_width, font->char_height);
    }
    else
      gdk_draw_pixmap(skin->background,
		      display_area->style->fg_gc[GTK_WIDGET_STATE(display_area)],
		      font->pixmap, 
		      0, 0, 
		      font->x + i * font->char_width, font->y,
		      font->char_width, font->char_height);
  }
  redraw_skin();
}

static void check_button_motion_proximity(ButtonData* button, gint x, gint y){
  if(!button){ return; }
  if(x >= button->x && x < button->x + button->width &&
      y >= button->y && y < button->y + button->height){
    draw_button(button, TRUE, FALSE, FALSE);
  }
  else{
    draw_button(button, FALSE, FALSE, FALSE);
  }
}

static void display_motion(GtkWidget* w, GdkEventMotion* event, gpointer data){
  ButtonData* button;
  gint x = (float)event->x;
  gint y = (float)event->y;

  if(!skin) return;
  
  if(in_move){
    GdkModifierType modmask;
    gint pos_x, pos_y;
    gint new_x, new_y;
    gdk_window_get_pointer(NULL, &pos_x, &pos_y, &modmask);
    new_x = pos_x - move_x_pos;
    new_y = pos_y - move_y_pos;
    gdk_window_move(mainwindow->window, new_x, new_y);
    return;
  }
  
  if(current_button){
    button = current_button;
    
    if(x >= button->x && x < button->x + button->width &&
	y >= button->y && y < button->y + button->height){
      draw_button(button, FALSE, TRUE, FALSE);
    }
    else{
      draw_button(button, FALSE, FALSE, FALSE);
    }
    return;
  }
  
  {gint i;
  for(i=0; i<5; i++)
    check_button_motion_proximity(skin->b[i], x ,y);
  }
  //if(!lock_mode) check_button_motion_proximity(skin->b8, x ,y);
}	

static gint check_button_press_proximity(ButtonData* button, 
					 gint x, gint y){
  if(!button) return FALSE;

  if(x >= button->x && x < button->x + button->width &&
      y >= button->y && y < button->y + button->height){
    draw_button(button, FALSE, TRUE, FALSE);
    current_button = button;
    if(button->press_func){}
    in_drag = TRUE;
    return TRUE;
  }
  return FALSE;
}

static void display_pressed(GtkWidget* w, GdkEventButton* event, gpointer data){
  GdkModifierType modmask;
  gint x = (float)event->x;
  gint y = (float)event->y;

  if(!skin) return;

  if(event->button == 3){
    if(!lock_mode)
      gtk_menu_popup(GTK_MENU(main_menu), NULL, NULL, NULL, NULL,
		     event->button, event->time);
    else
      gtk_menu_popup(GTK_MENU(create_exit_menu()), NULL, NULL, NULL, NULL,
		     event->button, event->time);
      return;
  }
  
  { 
    gint i;
    for(i=0; i<5; i++)
      if(check_button_press_proximity(skin->b[i], x, y)) return;
  }
  
  in_move = TRUE;
  gdk_window_get_pointer(NULL, &orig_x_mpos, &orig_y_mpos, &modmask);
  move_x_pos = x;
  move_y_pos = y;
  in_drag = TRUE;
}

static void display_released(GtkWidget* w, 
			     GdkEventButton* event, 
			     gpointer data){
  gint x = (float)event->x;
  gint y = (float)event->y;
  
  if(!skin) return;

  if(current_button){
    ButtonData* button = current_button;
    if(x >= button->x && x < button->x + button->width &&
	y >= button->y && y < button->y + button->height){
      draw_button(button, FALSE, FALSE, FALSE);
      
      if(button->click2_func)
	exec_function2(NULL, button->click2_func);
      if(button->click1_func)
	exec_function1(NULL, button->click1_func);
    }
  }
  else{
    GdkModifierType modmask;
    gint pos_x;
    gint pos_y;
    gdk_window_get_pointer(NULL, &pos_x, &pos_y, &modmask);
    if(pos_x == orig_x_mpos && pos_y == orig_y_mpos)
      gdk_window_raise(mainwindow->window);
  }
  
  current_button = NULL;
  in_drag = FALSE;
  in_move = FALSE;
}

static void display_leave(){
  gint i;

  if(!skin) return;

  if(!current_button){
    for(i=0; i<5; i++)
      draw_button(skin->b[i], FALSE, FALSE, FALSE);
    //if(!lock_mode) draw_button(skin->b8, FALSE, FALSE, FALSE);
  }
}

void setup_display(){
  gtk_widget_set_events(display_area, 
			GDK_ENTER_NOTIFY_MASK | 
			GDK_LEAVE_NOTIFY_MASK | 
			GDK_POINTER_MOTION_MASK |
			GDK_BUTTON_PRESS_MASK | 
			GDK_BUTTON_RELEASE_MASK);
  gtk_signal_connect(GTK_OBJECT(display_area),
		     "motion_notify_event",
		     (GtkSignalFunc) display_motion, 
		     NULL);
  gtk_signal_connect(GTK_OBJECT(display_area),
		     "button_press_event",
		     (GtkSignalFunc) display_pressed,
		     NULL);
  gtk_signal_connect(GTK_OBJECT(display_area),
		     "button_release_event",
		     (GtkSignalFunc) display_released,
		     NULL);
  gtk_signal_connect(GTK_OBJECT(display_area),
		     "leave_notify_event",
		     (GtkSignalFunc) display_leave,
		     NULL);
  current_button = NULL;
}

