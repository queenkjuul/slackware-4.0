#include <pwd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <dirent.h>

#include <pthread.h>

#include <gdk/gdk.h>
#include <gtk/gtk.h>
#include <gdk_imlib.h>

#define VERSION "0.5"

#define STATUS_MOUNT 100
#define STATUS_UMOUNT 101
#define STATUS_NOR_LOCK 102
#define STATUS_PWD_LOCK 103
#define STATUS_UNLOCK 104

#define SCROLL_RIGHT 114
#define SCROLL_LEFT 115

#define NO_DISK 105
#define HAVE_DISK 106
#define WAIT 107

#define IOMEGA_PROTECTION_MODE_RW 0x00	
#define IOMEGA_PROTECTION_MODE_RO 0x02	
#define IOMEGA_PROTECTION_MODE_ROPW 0x03	

#define ENTER_KEY 0xFF0D
#define BACKSPACE_KEY 0xFF08

typedef struct _ButtonData ButtonData;
struct _ButtonData{
  GdkPixmap* pixmap;
  gint sections;
  gint has_light;
  gint has_prelight;
  gint pushed;
  gint lit;
  gint prelit;
  gint width;
  gint height;
  gint x;
  gint y;
  void (*press_func)();
  void (*click1_func)();
  void (*click2_func)();
};

typedef struct _FontData FontData;
struct _FontData{
  GdkPixmap* pixmap;
  gint length;
  gint char_width;
  gint char_height;
  gint width;
  gint height;
  gint x;
  gint y;
};

typedef struct _SkinData SkinData;
struct _SkinData{
  gint width;
  gint height;
  FontData* msg;
  GdkPixmap* background;
  GdkBitmap* mask;
  ButtonData* b[5];
};

/* main window widgets */
extern GtkWidget* mainwindow;
extern GtkWidget* display_area;
extern GtkWidget* main_menu;

/* skin variables */
extern SkinData* skin;
extern SkinData* skin_normal;
extern SkinData* skin_msg;
extern SkinData* save_skin_normal;
extern SkinData* save_skin_msg;
extern gchar* default_skin;

/* misc */
extern gint wm_decorations;
extern gchar* browser_command;
extern gchar* skin_dir;
extern gchar** gtkzip_icon_xpm;

/* timeout tag */
extern gint msg_timeout_tag;
extern gint scroll_msg_timeout_tag;

/* handler id */
extern gint function_handler_id;
extern gint msg_handler_id;

/* timeout */
extern gint msg_timeout;
extern gint scroll_msg_timeout;

extern gint name_scroll_pos;
extern gint name_scroll_dir;

extern gint lock_mode;

extern gchar* dev;
extern gchar msg[256];
extern gchar* mnt_dir;
extern gchar* mnt_dirs[256];
extern gchar mnt_type[64];
extern gchar mnt_fsname[64];
extern gint dtype;
extern gint status;
extern gint mount_status;
extern gint lock_status;
extern gchar* save_mnt_dir;
extern gchar* save_dev;

extern GMutex* main_mutex;
extern GCond* main_cond;

/* main.c routines */
gchar* homedir();
int isfile(char* s);
int isdir(char* s);
void mount_button_pressed();
void eject_button_pressed();
void lock_button_pressed();
void unlock_button_pressed();
void iconify_button_pressed();
void show_about_info();
void show_zip_info();
void show_gtk_info();
void hide_msg_window();
void destroy_window();
void function_key_pressed(GtkWidget *widget,
			  GdkEventKey *event);
void exec_function1(GtkWidget* w, gpointer i);
void exec_function2(GtkWidget* w, gpointer i);

/* gtkziprc.c routines */
gint load_options();
void save_options();

/* config.c routines */
void show_config_window();

/* display.c routines */
void update_msg(gchar* m);
gint update_scroll_msg(gchar* m);
void update_caution_msg(gchar* m);
void update_all_display_info();
void redraw_font(gchar* m);
void reset_msg();

/* skinui.c routines */
GdkPixmap* get_pixmap_from_data(gchar** data);
FontData* new_font_from_file(gchar *file, gint length, 
			     gint x, gint y);
SkinData* new_skin();
ButtonData* new_button_from_data(gchar** data, 
				 gint prelight, 
				 gint light, 
				 gint x, gint y,
				 void (*click_func)(void* ), 
				 void (*press_func)(void* ),
				 void (*release_func)(void* ));
FontData * new_font_from_data(gchar** data, gint length, gint x, gint y);
void sync_window_to_skin();
void free_skin(SkinData* s);
void redraw_skin();
void change_button_light(ButtonData *button, gint lit);
void draw_button(ButtonData* button, 
		 gint prelight, gint pressed, gint force);
void draw_font(FontData* font, gchar* text);
void setup_display();

/* menu.c routines */
GtkWidget* create_main_menu();
GtkWidget* create_exit_menu();

/* mount.c routines */
gint mount_disk(gchar *dev);

/* umount.c routines */
gint umount_disk(gchar *dev);
