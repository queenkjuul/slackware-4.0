#include "gtkzip.h"
#include "plug_in.h"
#include "diskusage.h"

#include <config.h>

#include <glibtop.h>
#include <glibtop/fsusage.h>
#include <glibtop/mountlist.h>

#include "default_skin/next.xpm"
#include "default_skin/background_mask.xpm"
#include "default_skin/msg_background.xpm"
#include "default_skin/letters.xpm"

PlugIn* pi;
gchar* disk_mnt_dir;
gchar* disk_mnt_type;
gchar* dev_name;
gint used_space;
gint diskusage_cs;

void next_button_pressed(){
  gchar* m;
  gchar us[20];
  
  switch (diskusage_cs){
    case 0:
      m = g_strconcat("Mnt dir: ", disk_mnt_dir, NULL);
      break;
    case 1:
      m = g_strconcat("Dev name: ", dev_name, NULL);
      break;
    case 2:
      m = g_strconcat("Mnt type: ", disk_mnt_type, NULL);
      break;
    case 3:
      sprintf(us, "%u", used_space);
      m = g_strconcat("Used space: ", us, "%", NULL);
      break;
    case 4:
      plug_in_undraw_skin();
      diskusage_cs = 0;
      return;
  }
  plug_in_update_msg(m, 1000);
  diskusage_cs++;
} 

SkinData* load_skin(){
  SkinData* s;
  GtkStyle* style;
  GdkPixmap* msg_background;
  GdkPixmap* pixmap = NULL;
  GdkBitmap* mask = NULL;
  gint width, height;
  
  s = new_skin();
  
  style = gtk_widget_get_style(mainwindow);
  msg_background = get_pixmap_from_data((gchar**)msg_background_xpm);
  
  gdk_window_get_size(msg_background, &width, &height);
  
  gdk_imlib_data_to_pixmap(background_mask_xpm, &pixmap, &mask);
  if(pixmap) gdk_imlib_free_pixmap(pixmap);

  s->background = msg_background;
  s->mask = mask;
  s->width = width;
  s->height = height;
  
  s->msg = new_font_from_data((gchar **)letters_xpm, 17, 45, 17);
  s->b[4] = new_button_from_data((gchar**)next_xpm, 
				 TRUE, FALSE, 
				 153, 16, 
				 NULL, NULL, next_button_pressed);
  return s;
}

void diskusage_cb(){
  glibtop_fsusage fsu;
  glibtop_mountlist ml1;
  glibtop_mountentry* ml2;
  gint i;

  ml2 = glibtop_get_mountlist(&ml1, 0);

  if(plug_in_get_mount_status() == STATUS_MOUNT){
    for(i=0; i<ml1.number; i++){
      if(strcmp(plug_in_get_mnt_dir(), ml2[i].mountdir)!=0)
	continue;
      
      if(disk_mnt_dir) free(disk_mnt_dir);
      disk_mnt_dir = g_new(gchar, strlen(ml2[i].mountdir)+1);
      strcpy(disk_mnt_dir, ml2[i].mountdir);
      
      if(disk_mnt_type) free(disk_mnt_type);
      disk_mnt_type = g_new(gchar, strlen(ml2[i].type)+1);
      strcpy(disk_mnt_type, ml2[i].type);
      
      if(dev_name) free(dev_name);
      dev_name = g_new(gchar, strlen(ml2[i].devname)+1);
      strcpy(dev_name, ml2[i].devname);

      glibtop_get_fsusage(&fsu, ml2[i].mountdir);

      used_space = (fsu.blocks-fsu.bavail)*100/fsu.blocks; 
    }
    plug_in_draw_skin(pi->skin);
    plug_in_update_msg("Diskusage plug in...", 1000);
    diskusage_cs = 0;
  }
  else{
    plug_in_draw_skin(pi->skin);
    plug_in_update_msg("Disk Umounted!", 1000);
    diskusage_cs = 4;
  }
  
}

void diskusage_init(){
  pi = g_new(PlugIn, 1);
  pi->skin = load_skin();
  strcpy(pi->name, "Diskusage");
  pi->func = diskusage_cb;
  pi->cb_funcs[0] = next_button_pressed;
  insert_plug_in(pi);
}
