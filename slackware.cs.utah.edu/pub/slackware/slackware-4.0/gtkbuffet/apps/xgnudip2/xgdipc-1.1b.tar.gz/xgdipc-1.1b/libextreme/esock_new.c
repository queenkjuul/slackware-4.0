#include "extreme.h"

int esock_new(char *ip , int port) {
  int sockfd;
  struct hostent *he;
  struct sockaddr_in their_addr; 

  if ((he=gethostbyname(ip)) == NULL)
     return(-1);

  sockfd = socket(AF_INET, SOCK_STREAM, 0);

  their_addr.sin_family = AF_INET;
  their_addr.sin_port = htons(port);
  their_addr.sin_addr = *((struct in_addr *)he->h_addr);
  bzero(&(their_addr.sin_zero), 8);

  if ((connect(sockfd, (struct sockaddr *)&their_addr, sizeof(struct sockaddr))) ==-1)
    return(-1);
   
  return(sockfd);
}     

