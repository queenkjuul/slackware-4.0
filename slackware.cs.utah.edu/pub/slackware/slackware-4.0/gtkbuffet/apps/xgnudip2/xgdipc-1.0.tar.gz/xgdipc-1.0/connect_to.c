#include "xgdipc.h" 


void connect_to (GtkWidget *widget) {
 GtkWidget *window;
 GtkWidget *table;
 GtkWidget *button;
 GtkWidget *label1, *label2, *btnlabel;
 GtkWidget *box1;

 int sock, temp;
 char *srv_out;
 char *crypt_pass, client_salt[2];
 char *crypt_server, server_userpass[40];

 FILE *fout;
 
 fout = fopen (path_xgdip2, "w");

 if (GTK_TOGGLE_BUTTON (checkbutton)->active) 
 {
    gdip_savepass = 'y';
 } else {
    gdip_savepass = 'n';
 }
 
 if (GTK_TOGGLE_BUTTON (checkbutton1)->active)
 {
    gdip_autoquit = 'y';
 } else {
    gdip_autoquit = 'n';
 }

 strcpy(gdip_username, gtk_entry_get_text(GTK_ENTRY(text1)));
 if ((strcmp(gdip_pass, gtk_entry_get_text(GTK_ENTRY(text2)))) != 0) {
    sprintf(client_salt, "%c%c", gdip_username[0], gdip_username[1]);
    crypt_pass = crypt(gtk_entry_get_text(GTK_ENTRY(text2)), client_salt);
    strcpy (gdip_pass, crypt_pass);
 }
 
 strcpy (gdip_server, gtk_entry_get_text(GTK_ENTRY(text3))); 
 strcpy (gdip_username, gtk_entry_get_text(GTK_ENTRY(text1)));

 if (GTK_TOGGLE_BUTTON (checkbutton)->active)
 {
    fprintf(fout, "%c %c %s %s %s", gdip_savepass, gdip_autoquit, gdip_server, gdip_username, gdip_pass);
 } else {
    fprintf(fout, "%c %c %s %s x", gdip_savepass, gdip_autoquit, gdip_server, gdip_username);
 }
 fclose(fout);

 // gtk_widget_hide(widget);

 window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 gtk_signal_connect (GTK_OBJECT (window), "destroy", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);   
 gtk_window_set_title (GTK_WINDOW (window), "X-GnuDIP2 Connecting");
 gtk_container_border_width (GTK_CONTAINER (window), 10);
 gtk_window_set_policy (GTK_WINDOW (window), FALSE, FALSE, FALSE);
 
 table = gtk_table_new (6, 3, TRUE);
 gtk_container_add (GTK_CONTAINER (window), table);
 
 label1 = gtk_label_new ("Connecting. . .");
 gtk_table_attach_defaults (GTK_TABLE (table), label1, 1, 2, 0, 1);
 gtk_widget_show(label1); 

 label2 = gtk_label_new ("Initalizing . . .");
 gtk_table_attach_defaults (GTK_TABLE(table), label2, 0, 3, 2, 3);
 gtk_widget_show(label2); 

 button = gtk_button_new();
 
   btnlabel = gtk_label_new("Cancel");
   gtk_container_add (GTK_CONTAINER(button), btnlabel); 
   gtk_widget_show(btnlabel);

 gtk_table_attach_defaults (GTK_TABLE(table), button, 1, 2, 5, 6);
 gtk_widget_show(button);

 gtk_widget_show(table);
 gtk_widget_show(window);

 gtk_label_set (GTK_LABEL (label2), "Connecting to host . . .");
 if ( (sock = esock_new(gdip_server, 3495)) != -1)
 {
  gtk_label_set (GTK_LABEL (label2), "Waiting for Salts . . .");
  srv_out = esock_read(sock);
 
  gtk_label_set (GTK_LABEL (label2), "Encryting Password . . .");
  crypt_server = crypt(gdip_pass, srv_out);

  gtk_label_set (GTK_LABEL (label2), "Sending Username and Password . . ."); 
  sprintf(server_userpass, "%s:%s\n", gdip_username, crypt_server); 
  temp = esock_write(sock, server_userpass);

  gtk_label_set (GTK_LABEL (label2), "Checking status . . ."); 
  srv_out = esock_read(sock);
  
  if (srv_out[0] == '1')
  {
   gtk_label_set (GTK_LABEL (label2), "ERROR: Invalid Login");

   gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (restore_window), window);   
   
  }
  else if (srv_out[0] == '0')
  {
   gtk_label_set (GTK_LABEL (label2), "Successfully Authenticated.");

   gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);   
   
   gtk_label_set(GTK_LABEL(btnlabel), "Close");
   
   if (GTK_TOGGLE_BUTTON (checkbutton1)->active)
      gtk_main_quit();
  }
  else
  {
   gtk_label_set (GTK_LABEL (label2), srv_out);
   gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (restore_window), window);   
   gtk_label_set(GTK_LABEL(btnlabel), "Ok");
  }
 }
 else
 {
  gtk_label_set (GTK_LABEL (label2), "ERROR: Could Not Connect To Host");
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (restore_window), window);   
   gtk_label_set(GTK_LABEL(btnlabel), "Ok");
 }
}

