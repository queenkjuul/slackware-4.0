#include "extreme.h"

int esock_write(int sockfd, char *buf) {
   int put;
   put = write(sockfd, buf, strlen(buf));

   return(put);

} 
