/*******************************************
*   mikelib v0.1                           *
*                                          *
*     This is a library with a bunch       *
*     of usefull functions                 *
*                                          *
*                                          *
*******************************************/

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h> 

#define BUFLEN 100

int strparse(char *string, const char *delim, int sections, ...);

int esock_new(char *ip, int port);
char *esock_read(int sockfd);
int esock_write(int sockfd, char *buf);
 
