#include <gtk/gtk.h>
#include <stdio.h>
#include <unistd.h>
#include <strings.h>

#include "libextreme/extreme.h"

#ifdef HAVE_CONFIG_H
  #include <config.h>
#endif

GtkWidget *text1;
GtkWidget *text2;
GtkWidget *text3;
GtkWidget *mode_update;
GtkWidget *mode_offline;
GtkWidget *checkbutton;
GtkWidget *checkbutton1;

char path_xgdip2[256];
char gdip_savepass, gdip_autoquit, gdip_server[50], gdip_username[20], gdip_pass[20];

void connect_to (GtkWidget *widget);
void restore_window (GtkWidget *thisw, GtkWidget *widget);

#if (GTK_MINOR_VERSION < 1 && GTK_MAJOR_VERSION <= 1)
void get_main_menu(GtkWidget *window, GtkWidget **menubar);
#else
void get_main_menu(GtkWidget *window, GtkWidget *vbox);
#endif

void show_about(GtkWidget *widget, gpointer data);
