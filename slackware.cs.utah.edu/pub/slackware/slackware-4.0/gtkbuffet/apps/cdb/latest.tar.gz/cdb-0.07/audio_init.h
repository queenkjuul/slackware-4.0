int audio_close(int audiodsp);
int audio_init();
