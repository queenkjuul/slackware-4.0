/* CDB/BC Wave   Copyright 1998 Bryan Chafy */
/* If you reuse this code for your own purpose, you must include this
   copyright notice. */


#include <gtk/gtk.h>
#include <stdio.h>
#include "colors.h"

void color_init(GtkWidget *widget)
{
  static GdkColormap *cmap;
  static GdkColor c[10];

  int i;

static unsigned short color_vals[33] =
{

/*RED   GREEN  BLUE   */
0x0000,0xffff,0x0000,
0xffff,0x0000,0xffff,
0xffff,0xffff,0x0000,
0x0000,0x0000,0xffff,
0xffff,0x0000,0x0000,
0x0000,0xffff,0xffff,
0x28a2,0x8a28,0x5144,
0xffff,0xdfd7,0xaeba,
0xffff,0xffff,0xffff,
0x79e7,0x7df7,0x79e7,
0,0,0

};


 cmap = gdk_colormap_get_system();
// cmap = gtk_widget_get_colormap (widget);

for (i=0;i<11;i++){

c[i].red = color_vals[i*3];
c[i].green = color_vals[i*3+1];
c[i].blue = color_vals[i*3+2];

if (!gdk_color_alloc (cmap, &c[i]))
        g_error ("Couldn't allocate a color");

gc_color[i] = gdk_gc_new (widget->window);
gdk_gc_set_foreground (gc_color[i], &c[i]);

}
}
