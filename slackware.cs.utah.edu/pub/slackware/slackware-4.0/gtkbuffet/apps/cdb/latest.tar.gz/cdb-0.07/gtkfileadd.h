/* GTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#ifndef __GTK_FILEADD_H__
#define __GTK_FILEADD_H__


#include <gdk/gdk.h>
#include <gtk/gtkwindow.h>
#include <gtk/gtkgc.h>


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define GTK_FILE_ADD(obj)          GTK_CHECK_CAST (obj, gtk_file_add_get_type (), GtkFileAdd)
#define GTK_FILE_ADD_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, gtk_file_add_get_type (), GtkFileAddClass)
#define GTK_IS_FILE_ADD(obj)       GTK_CHECK_TYPE (obj, gtk_file_add_get_type ())


typedef struct _GtkFileAdd       GtkFileAdd;
typedef struct _GtkFileAddClass  GtkFileAddClass;

struct _GtkFileAdd
{
  GtkWindow window;

  GtkWidget *dir_list;
  GtkWidget *file_list;
  GtkWidget *added_list;
  GtkWidget *selection_entry;
  GtkWidget *removeb_selection_entry;
  GtkWidget *selection_text;
  GtkWidget *main_vbox;
  GtkWidget *ok_button;
  GtkWidget *cancel_button;
  GtkWidget *add_button;
  GtkWidget *remove_button;
  GtkWidget *tracks;
  GtkWidget *gaps;

  gpointer cmpl_state;
};

struct _GtkFileAddClass
{
  GtkWindowClass parent_class;
};


guint      gtk_file_add_get_type     (void);
GtkWidget* gtk_file_add_new          (const gchar           *title);
void       gtk_file_add_set_filename (GtkFileAdd      *fileadd,
					    const gchar           *filename);
gchar*     gtk_file_add_get_filename (GtkFileAdd      *fileadd);
void cddraw (GtkWidget * widget,  GdkEventExpose *event,  gpointer bladata);  



#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __GTK_FILEADD_H__ */
