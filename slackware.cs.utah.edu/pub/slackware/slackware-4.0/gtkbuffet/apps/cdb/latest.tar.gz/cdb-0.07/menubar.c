#include <gtk/gtk.h>
#include <stdio.h>
#include "main.h"
#include "fancy_buttons.h"

extern front_panel panel;
extern GList *files_list;
extern GtkCombo *cb;


static void
cb_changed(GtkWidget *widget)
{

printf("combo changed %d\n",0);

}


static void
set_toolbar_horizontal (GtkWidget *widget,
                        gpointer   data)
{
}

static void
set_toolbar_vertical (GtkWidget *widget,
                      gpointer   data)
{
}



void cdb_menubar(GtkWidget *main_vbox, GtkWidget *window)
{
GtkWidget *menubar;
GtkWidget *menuitem;
GtkWidget *btest;
GtkWidget *subitem;
GtkWidget *toolbar;

    GtkWidget *pixmapwid;
    GdkPixmap *pixmap;
    GdkBitmap *mask;
    GtkStyle *style;



/*  GtkAcceleratorTable *accel;  */



  menubar = gtk_menu_bar_new ();

  gtk_box_pack_start (GTK_BOX (main_vbox), menubar, FALSE, TRUE, 0);
  gtk_widget_show (menubar);                                        

gtk_widget_set_usize (GTK_WIDGET (menubar), 0, 25);



/*
   get_main_menu(&menubar, &accel);
   gtk_window_add_accelerator_table(GTK_WINDOW(window), accel);
   gtk_box_pack_start(GTK_BOX(main_vbox), menubar, FALSE, TRUE, 0);
   gtk_widget_show(menubar);
 */

                            
  btest = gtk_menu_new ();
  subitem = gtk_menu_item_new_with_label ("Add/Remove Files");
  gtk_menu_append (GTK_MENU (btest), subitem);                
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",
                      GTK_SIGNAL_FUNC (files_cmd_callback),
                      &panel);                             
  gtk_widget_show (subitem);    
                            
  subitem = gtk_menu_item_new_with_label ("Generate Subcodes" );
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",         
                      GTK_SIGNAL_FUNC (generate_subcodes),
                      NULL);                              
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);                  
                            
  subitem = gtk_menu_item_new_with_label ("Generate Cue Sheet" );
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",          
                      GTK_SIGNAL_FUNC (generate_cuesheet),
                      NULL);                              
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);                  
                            
  subitem = gtk_menu_item_new_with_label ("Generate Raw Image" );
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",          
                      GTK_SIGNAL_FUNC (generate_rawimage),
                      NULL);                              
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);                  
                            
  subitem = gtk_menu_item_new_with_label ("Split Tracks" );
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",    
                      GTK_SIGNAL_FUNC (split_tracks),  
                      NULL);                         
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);                  
  subitem = gtk_menu_item_new_with_label ("Exit");
  gtk_menu_append (GTK_MENU (btest), subitem);    
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",
                      GTK_SIGNAL_FUNC (file_quit_cmd_callback),
                      "END");                                  
  gtk_widget_show (subitem);   

  menuitem = gtk_menu_item_new_with_label ("File");
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (menuitem), btest);
  gtk_menu_bar_append (GTK_MENU_BAR (menubar), menuitem);
  gtk_widget_show (menuitem);

/*
  btest = gtk_menu_new ();
  subitem = gtk_menu_item_new_with_label ("Undo");
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);                
                                            
  subitem = gtk_menu_item_new_with_label ("Redo");
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);

  menuitem = gtk_menu_item_new_with_label ("Edit");
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (menuitem), btest);
  gtk_menu_bar_append (GTK_MENU_BAR (menubar), menuitem);
  gtk_widget_show (menuitem);
*/

  btest = gtk_menu_new ();
  subitem = gtk_menu_item_new_with_label ("CD Attributes...");
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",
                      GTK_SIGNAL_FUNC (mode23_cmd_callback),
                      NULL);
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);               

  subitem = gtk_menu_item_new_with_label ("Media Type...");  /* cdda, xa, ecd */
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",
                      GTK_SIGNAL_FUNC (mediatype_callback),
                      NULL);
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);

  subitem = gtk_menu_item_new_with_label ("Audio Device...");
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",
                      GTK_SIGNAL_FUNC (audiodev_callback),
                      NULL);
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);
                                           
  subitem = gtk_menu_item_new_with_label ("Subcode Type...");
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",
                      GTK_SIGNAL_FUNC (subctype_callback),
                      NULL);
  gtk_menu_append (GTK_MENU (btest), subitem);
  gtk_widget_show (subitem);

  menuitem = gtk_menu_item_new_with_label ("Options");
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (menuitem), btest);
  gtk_menu_bar_append (GTK_MENU_BAR (menubar), menuitem);
  gtk_widget_show (menuitem);

  btest = gtk_menu_new ();
  subitem = gtk_menu_item_new_with_label ("About");
  gtk_menu_append (GTK_MENU (btest), subitem);    
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",
                      GTK_SIGNAL_FUNC (about_cmd_callback),
                      NULL);  
  gtk_widget_show (subitem);                 
                                           
  subitem = gtk_menu_item_new_with_label ("On CD Builder");
  gtk_menu_append (GTK_MENU (btest), subitem);    
  gtk_signal_connect (GTK_OBJECT (subitem), "activate",
                      GTK_SIGNAL_FUNC (oncdb_cmd_callback),
                      NULL);  
  gtk_widget_show (subitem);         

  menuitem = gtk_menu_item_new_with_label ("Help");
  gtk_menu_item_right_justify (GTK_MENU_ITEM (menuitem));
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (menuitem), btest);
  gtk_menu_bar_append (GTK_MENU_BAR (menubar), menuitem);
  gtk_widget_show (menuitem);




toolbar = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_ICONS);
gtk_container_border_width (GTK_CONTAINER (toolbar), 2); 
// gtk_toolbar_set_button_relief (GTK_TOOLBAR (toolbar), GTK_RELIEF_NONE);


  style = gtk_widget_get_style(window);
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)tracksp_xpm );         

    pixmapwid = gtk_pixmap_new( pixmap, mask );

     gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                              "Vertical", "Create track (+)", "Track/Create",
                               pixmapwid,
                               (GtkSignalFunc) set_track, NULL);

  style = gtk_widget_get_style(window);
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)trackusp_xpm );         

    pixmapwid = gtk_pixmap_new( pixmap, mask );

     gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                              "Vertical", "Combine tracks (-)", "Track/Combine",
                               pixmapwid,
                               (GtkSignalFunc) unset_track, NULL);


  style = gtk_widget_get_style(window);
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)indexad_xpm );         

    pixmapwid = gtk_pixmap_new( pixmap, mask );

     gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                              "Vertical", "Set Index (+)", "Index/Set",
                               pixmapwid,
                               (GtkSignalFunc) set_index, NULL);

  style = gtk_widget_get_style(window);
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)indexsub_xpm);         

    pixmapwid = gtk_pixmap_new( pixmap, mask );

     gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                              "Vertical", "Unset Index (-)", "Index/Unset",
                               pixmapwid,
                               (GtkSignalFunc) unset_index, NULL);


  style = gtk_widget_get_style(window);
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)gap_xpm);         

    pixmapwid = gtk_pixmap_new( pixmap, mask );

     gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                              "Vertical", "Set Gap", "Gap/Set",
                               pixmapwid,
                               (GtkSignalFunc) set_gap, NULL);


  style = gtk_widget_get_style(window);
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)waveupd_xpm);         
  pixmapwid = gtk_pixmap_new( pixmap, mask );

  panel.wave_update_toggle = gtk_toggle_button_new();
  gtk_signal_connect (GTK_OBJECT (panel.wave_update_toggle), "clicked",   
                      GTK_SIGNAL_FUNC (wave_update_callback),          
                      NULL);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), 
  panel.wave_update_toggle, "Wave update"," ");
  gtk_widget_show (panel.wave_update_toggle);

  gtk_container_add( GTK_CONTAINER(panel.wave_update_toggle), pixmapwid );
  gtk_widget_show( pixmapwid );




 gtk_toolbar_append_space (GTK_TOOLBAR (toolbar));



 cb = gtk_combo_new ();
/*      gtk_combo_set_popdown_strings (GTK_COMBO (cb), files_list);
      gtk_entry_set_text (GTK_ENTRY (GTK_COMBO(cb)->entry), "hello world");
      gtk_editable_select_region (GTK_EDITABLE (GTK_COMBO(cb)->entry),
                                  0, -1);
*/

 gtk_signal_connect (GTK_OBJECT (cb->list), "button_press_event",
                      GTK_SIGNAL_FUNC (cb_changed),
                      NULL);


gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), cb, "This is an unusable GtkEntry ;)",
"Hey don't click me!!!");
gtk_widget_show (GTK_WIDGET(cb));

 gtk_toolbar_append_space (GTK_TOOLBAR (toolbar));



  style = gtk_widget_get_style( window );
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)ch_XPM );          
  pixmapwid = gtk_pixmap_new( pixmap, mask );

  panel.fourchannel_toggle = gtk_toggle_button_new();
  gtk_signal_connect (GTK_OBJECT (panel.fourchannel_toggle), "clicked",
                      GTK_SIGNAL_FUNC (fourchannel_callback),
                      NULL);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar), 
  panel.fourchannel_toggle, "Toggle 4-channel bit"," ");
  gtk_widget_show (panel.fourchannel_toggle);

  gtk_container_add( GTK_CONTAINER(panel.fourchannel_toggle), pixmapwid );
  gtk_widget_show( pixmapwid );



  style = gtk_widget_get_style( window );
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)pre_XPM );          
  pixmapwid = gtk_pixmap_new( pixmap, mask );

  panel.emphasis_toggle = gtk_toggle_button_new();
  gtk_signal_connect (GTK_OBJECT (panel.emphasis_toggle), "clicked",
                          (GtkSignalFunc) emphasis_callback,        
                          NULL);                            
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar),
               panel.emphasis_toggle, "Toggle pre-emphasis bit"," ");
  gtk_widget_show (panel.emphasis_toggle);
  gtk_container_add( GTK_CONTAINER(panel.emphasis_toggle), pixmapwid );
  gtk_widget_show( pixmapwid );



  style = gtk_widget_get_style(window);
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)copy_XPM );         
  pixmapwid = gtk_pixmap_new( pixmap, mask );
  panel.permision_toggle = gtk_toggle_button_new();
  gtk_signal_connect (GTK_OBJECT (panel.permision_toggle), "clicked",
                      GTK_SIGNAL_FUNC (permission_callback),         
                      NULL);                                
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar),
               panel.permision_toggle, "Toggle copy-disalow bit"," ");
  gtk_widget_show (panel.permision_toggle);
  gtk_container_add( GTK_CONTAINER(panel.permision_toggle), pixmapwid );
  gtk_widget_show( pixmapwid );



  style = gtk_widget_get_style(window);
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)mixer_xpm );         
    pixmapwid = gtk_pixmap_new( pixmap, mask );
                                               
     gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                              "Vertical", "Launch mixer program", "Toolbar/Mixer",
                               pixmapwid,                                               
                               (GtkSignalFunc) mixer,  NULL);

  style = gtk_widget_get_style(window);
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)smart_xpm );         
    pixmapwid = gtk_pixmap_new( pixmap, mask );
                                               
     gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                              "Vertical", "Smart Scan", "Toolbar/SmartScan",
                               pixmapwid,                                               
                               (GtkSignalFunc) set_toolbar_vertical, toolbar);




 gtk_box_pack_start (GTK_BOX (main_vbox), toolbar, FALSE, TRUE, 0);
 gtk_widget_show (toolbar);                                        

}
