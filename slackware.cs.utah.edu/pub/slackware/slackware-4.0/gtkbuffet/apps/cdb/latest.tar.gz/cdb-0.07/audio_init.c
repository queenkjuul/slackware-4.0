
/*

audio_init 

This is a OS specific function.   It sets up a device to play
44.1khz, 16 bit sound to.  A file desciptor for the appropriate
device is returned.

Currently, this function works only with Linux.  Other OS specific
calls should be handled here.

*/

#include <gtk/gtk.h>
#include "gtkfileadd.h"
#include "pad.h"


#include <stdio.h>
#include <malloc.h>
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <strings.h>
#include <linux/soundcard.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include "main.h"

extern struct audiosys audio;

int audio_close(int audiodsp)
{
return (close(audiodsp));
}



/*

for /dev/audio

int audio_init()
{   
int audiodsp;
audiodsp = open (audio.dsp, O_WRONLY, 0);
                                         
   if (audiodsp < 0) {
      perror (audio.dsp);
      return (-1);       
   }

return (audiodsp);

}
*/


int audio_init()
{

char *command;
int tmp;
int dsp_speed = 44100;
int dsp_stereo = 1;
int samplesize = 16;
int audiodsp;
int abuf_size;

audiodsp = open (audio.dsp, O_WRONLY, 0);

   if (audiodsp < 0) {
      perror (audio.dsp);
      return (-1);
   }

   tmp = samplesize;
   ioctl(audiodsp, SNDCTL_DSP_SAMPLESIZE, &samplesize);
   if (tmp != samplesize) {
      fprintf(stderr, "Unable to set the sample size\n");
      return(-1);
   }

   if (ioctl (audiodsp, SNDCTL_DSP_STEREO, &dsp_stereo)==-1) {
      fprintf (stderr, "%s: Unable to set mono/stereo\n", command);
      perror (audio.dsp);
      return (-1);
   }

   if (ioctl (audiodsp, SNDCTL_DSP_SPEED, &dsp_speed) == -1) {
      fprintf (stderr, "%s: Unable to set audio speed\n", command);
      perror (audio.dsp);
      return (-1);
   }

   ioctl (audiodsp, SNDCTL_DSP_GETBLKSIZE, &abuf_size);
   if (abuf_size < 1024 || abuf_size > (2*65536)) {
      if (abuf_size == -1)
        perror (audio.dsp);
      else
        fprintf (stderr, "Invalid audio buffers size %d\n", abuf_size);
      return (-1);
   }

return (audiodsp);


}

