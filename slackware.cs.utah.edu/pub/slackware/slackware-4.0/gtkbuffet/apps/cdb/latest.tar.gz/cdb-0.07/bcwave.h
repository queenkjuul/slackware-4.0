/* CDB/BC Wave   Copyright 1998 Bryan Chafy */
/* If you reuse this code for your own purpose, you must include this
   copyright notice. */


void unselect(GtkWidget *widget, gint start, gint end);
void c_unselect(GtkWidget *widget, gint start, gint end);
static gint wave_c_button_press_event (GtkWidget *widget, GdkEventButton *event);
static gint wave_button_press_event (GtkWidget *widget, GdkEventButton *event);
static gint wave_motion_notify_event (GtkWidget *widget, GdkEventMotion *event);
static gint wave_expose_event (GtkWidget * widget, GdkEventExpose * event);
static gint wave_c_expose_event (GtkWidget * widget, GdkEventExpose * event);
int scanwave (char * filename, int start, int end, int offset);
int smart_scanwave (char * filename, float level, int time);
int wave_set_cursor(int location);
int wave_set_gap (int start, int end);
int wave_set_track (int start, int end);
int wave_set_index (int start, int end);
int wave_ignore_area();
int wave_window ();
