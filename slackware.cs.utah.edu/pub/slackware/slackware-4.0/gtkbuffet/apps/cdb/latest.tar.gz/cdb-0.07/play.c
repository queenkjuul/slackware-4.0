/* 
 * play.c:
 *  Plays audio from circular buffer.  Accurate to 2352 bytes.
*/

#include <gtk/gtk.h>
#include "gtkfileadd.h"
#include "pad.h"
#include "audio_init.h"

#include <stdio.h>
#include <malloc.h>
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <strings.h>
#include <linux/soundcard.h>
#include <sys/stat.h>
#include <errno.h>
#include <limits.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <signal.h>
#include "main.h"

#ifdef DEBUG
#define printit(x)  printf(x) 
#else
#define printit(x) 
#endif

extern int shmid, playid;
extern struct cd_type cd;
extern struct audiosys audio;
extern GtkWidget *list, *status_display;

unsigned int cvt(ch)
int ch;             
{      

  int mask;

  if (ch < 0) {
    ch = -ch;
    mask = 0x7f;
  } else {
    mask = 0xff;
  }

  if (ch < 32) {
    ch = (0xF0 | 15) - (ch / 2);
  } else if (ch < 96) {
    ch = (0xE0 | 15) - (ch - 32) / 4;
  } else if (ch < 224) {
    ch = (0xD0 | 15) - (ch - 96) / 8;
  } else if (ch < 480) {
    ch = (0xC0 | 15) - (ch - 224) / 16;
  } else if (ch < 992) {
    ch = (0xB0 | 15) - (ch - 480) / 32;
  } else if (ch < 2016) {
    ch = (0xA0 | 15) - (ch - 992) / 64;
  } else if (ch < 4064) {
    ch = (0x90 | 15) - (ch - 2016) / 128;
  } else if (ch < 8160) {
    ch = (0x80 | 15) - (ch - 4064) /  256;
  } else {
    ch = 0x80;
  }
return (mask & ch);
}


int audioplay(int cmd) {
static int l,x,ii;

static int current=0;
static int audiodsp, abuf_size;
static int setup=0;
static int blksize = 599760/2352;
static char gapdata[2352];
static char audiobuf[2352];
static char *shmptr;
static play_file *playdata;
static char *pd;

/* static int tmpint; */

if (setup ==0)  {
setup =1;

audiodsp = audio_init();

if ( (pd = shmat(playid,0,0)) == (void*) -1 )
  {
   perror ("shmat pd error:");
   exit(-1);
  }


if ( (shmptr = shmat(shmid,0,0)) == (void*) -1 )
  {
   perror ("shmat shmptr error:"); 
   exit(-1);
  }

playdata = (play_file *)pd;

if (audiodsp == -1)
{

if (audio.pid)
{
playdata->command = -1;
waitpid(audio.pid, NULL,0); 
}
                                  
getplaydata(-1);

shmdt(pd);
shmdt(shmptr);
setup=0;
audio.pid = 0;
gtk_label_set (GTK_LABEL (status_display), "ERROR, Cannot initialize dsp"); 

return -1;
}



playdata->reading = 0;
abuf_size = 2352;

for (x=0;x<abuf_size;x++)
gapdata[x]=(char)0;

}

if (cmd==-1)
{
audio_close(audiodsp);
printf("detaching\n");
shmdt(pd);
shmdt(shmptr);
setup=0;
return 0;
}




/* play silence for gap */
if (cmd==1)
{
l = write (audiodsp, &gapdata[0], abuf_size);

 if (l < 0) {
     perror (audio.dsp);

  if (shmctl(shmid, IPC_RMID, 0) < 0) {
         perror("shmctl error");
            exit(-1);}

  if (shmctl(playid, IPC_RMID, 0) < 0) {
         perror("shmctl error");       
            exit(-1);}

     printf ("error writing audio\n");
     exit (-1);
            }


 if (l == 0)
 {
  if (shmctl(shmid, IPC_RMID, 0) < 0) {
         perror("shmctl error");
            exit(-1);}

  if (shmctl(playid, IPC_RMID, 0) < 0) {
         perror("shmctl error");       
            exit(-1);}

  close (audiodsp);
  printf("done\n");
  exit(0);
 }

return(0);

}

/* play normal file from buffer */
current = ( (playdata->reading) +1) % blksize;

if (current != playdata->writing)
 {
 playdata->reading = current;

if (!audio.endianinv)
 {
 l = write (audiodsp, &shmptr[(playdata->reading)*abuf_size], abuf_size);
 }
else
  {
/* invert the endian arrangement and write to a new buffer */
	    for (ii=0; ii<abuf_size; ii+=2) {
               audiobuf[ii] = shmptr[((playdata->reading)*abuf_size) +ii+1 ];
               audiobuf[ii+1] = shmptr[((playdata->reading)*abuf_size)+ii];
	    }

#if 0

            for (ii=0; ii<abuf_size; ii+=20) {
               audiobuf[ii] = shmptr[((playdata->reading)*abuf_size) +ii+1 ];
               audiobuf[ii+1] = shmptr[((playdata->reading)*abuf_size)+ii];

tmpint = (int)(audiobuf[ii+1] | (int)(audiobuf[ii] << 8));

audiobuf[ii/20] = cvt((tmpint/512) * 128);
            }
 l = write (audiodsp, &audiobuf[0], abuf_size/20);
#endif

 l = write (audiodsp, &audiobuf[0], abuf_size);


  }
 }
else
{
if (playdata->command == 0)
return (-1);
else
// printit("play buffer underrun, I/O too slow?\n");
l=1;
}


 if (l < 0) {
     perror (audio.dsp);
     printf ("error writing audio\n");

  if (shmctl(shmid, IPC_RMID, 0) < 0) {
         perror("shmctl error");
            }

  if (shmctl(playid, IPC_RMID, 0) < 0) {
         perror("shmctl error");       
            }

     exit (-1);
            }


 if (l == 0)
 {  
  if (shmctl(shmid, IPC_RMID, 0) < 0) {
         perror("shmctl error");
            }

  if (shmctl(playid, IPC_RMID, 0) < 0) {
         perror("shmctl error");       
            }

  close (audiodsp);
  printf("done\n");
  exit(0);
 }


playdata->location = playdata->loc[playdata->reading];
playdata->filenum = playdata->fid[playdata->reading];
return (playdata->location);
   
}



void playcommand (int command, int index, int start)
{
/*
 commands are:

 -1 - exit
 0  - stop
 1  - play/continue from current
 2  - play at filestart location or new file
*/

int shmsize = 599760;
static play_file *playdata;
static int setonce =0;

if (!setonce) {
shmid = shmget(IPC_PRIVATE, shmsize, SHM_R | SHM_W);
playid = shmget(IPC_PRIVATE, sizeof(play_file), SHM_R | SHM_W);
setonce =1;

if (shmid == -1 || playid == -1)
{
perror("shmget error");
exit(-1);
}

playdata = getplaydata();

}


if (command==-1)
{
setonce = 0;
playdata->command = command;
      waitpid(audio.pid, NULL,0); 

audioplay(-1);
getplaydata(-1);
shmdt( (char*)playdata);

  if (shmctl(shmid, IPC_RMID, 0) < 0) {
         perror("shmctl error");
            exit(-1);}

  if (shmctl(playid, IPC_RMID, 0) < 0) {
         perror("shmctl error");       
            exit(-1);}

    audio.pid = 0;

printf("detached locally\n");

      return;
}

playdata->command = command;
playdata->fileidx = index;
playdata->filestart = start;

if (command==2)
while (playdata->command!=1);

}


play_file* getplaydata(int reset)
{
static play_file *playdata;
static char *pd;
static int setonce=0;

if (reset == -1) {
setonce = 0;
return NULL;
}

if (!setonce) {
setonce = 1;

if ( (pd = shmat(playid,0,0)) == (void*) -1 )
  {
   perror ("shmat pd error:");
   exit(-1);
  }
playdata = (play_file *)pd;

}

return (playdata);
}


void killme()
{
printf("child exiting\n");
playcommand(-1,0,0);
}

void readaudiofile()
{
static int abuf_size = 2352;
static int fd;
int t,l,pid;
int shmsize = 599760;
int blksize = shmsize/2352;
int fileend;
char *shmptr;

play_file *playdata;
char *pd;

int current=0;

   pid = fork();

   if (pid==-1) {
      perror ("fork");
      return;
   }


   if (pid!=0) {


audio.pid = pid;

return;

             } else {

/* child reads from files and puts them in the circular buffer */

signal (SIGTERM, killme);

abuf_size=2352;

if ( (pd = shmat(playid,0,0)) ==  (void*) -1 )
  {
   perror ("shmat pd error:");
   exit(-1);
  }

playdata = (play_file *)pd;

if ( (shmptr = shmat(shmid,0,0)) == (void*) -1 )
  {
   perror ("shmat shmptr error:");
   exit(-1);
  }

fd = open(cd.file[playdata->fileidx].filename, O_RDONLY);
fileend = lseek(fd,0,SEEK_END);
lseek(fd,0,SEEK_SET);

l=read (fd, shmptr, abuf_size*5);

for (t=0;t<5;t++)
{
playdata->loc[t] = 2352*(t+1);
playdata->fid[t] = playdata->fileidx;
}

playdata->writing = current = 5;

      while (1) {

 switch (playdata->command)
   {

    case 1:

current = (playdata->writing +1) % blksize;

if (current != playdata->reading)
 {
 playdata->writing = current;
 l=read (fd, &shmptr[(playdata->writing)*2352], abuf_size);
 playdata->loc[playdata->writing] = lseek(fd,0,SEEK_CUR);
 playdata->fid[playdata->writing] = playdata->fileidx;
 }
  else
 {
// printit("write collision\n");
usleep(15000);
}

if (playdata->loc[playdata->writing] >= fileend)
if (playdata->fileidx<cd.numberoffiles-1)
{
close(fd);
playdata->fileidx++;
fd = open(cd.file[playdata->fileidx].filename, O_RDONLY);
fileend = lseek(fd,0,SEEK_END);
lseek(fd,0,SEEK_SET);
}
else
{
close(fd);
printf("stopping fileplay\n");
playdata->command=0;
}

   break;


   case 2:
close(fd);
fd = open(cd.file[playdata->fileidx].filename, O_RDONLY);
fileend = lseek(fd,0,SEEK_END);
lseek(fd,playdata->filestart,SEEK_SET);
playdata->writing = (playdata->reading);

current = (playdata->writing +1) % blksize;

if (current != playdata->reading)
 {
 playdata->writing = current;
 l=read (fd, &shmptr[(playdata->writing)*2352], abuf_size);
 playdata->loc[playdata->writing] = lseek(fd,0,SEEK_CUR);
 playdata->fid[playdata->writing] = playdata->fileidx;
 playdata->command=1;
 }
  else
 {
// printit("write collision\n");
usleep(15000);
}
  break;

  case 0:
   
   while (playdata->command == 0)
     usleep(15000);

   break;

  case -1:

     close (fd);

      shmdt(pd);
      shmdt(shmptr);

     _exit(0);
    
     break;

}


if (l<=0) {
            close (fd);

  if (shmctl(shmid, IPC_RMID, 0) < 0) {
         perror("shmctl error");
            exit(-1);}

  if (shmctl(playid, IPC_RMID, 0) < 0) {
         perror("shmctl error");       
            exit(-1);}

            audio.pid = 0;

         perror("misc error");       

            break;
         }

   }

printf("DONE\n");
sleep (4);

  return;
      }
return;
   }
