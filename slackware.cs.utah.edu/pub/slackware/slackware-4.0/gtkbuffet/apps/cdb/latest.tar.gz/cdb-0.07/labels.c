#include <gtk/gtk.h>
#include <stdio.h>
#include "main.h"

extern front_panel panel;
extern GtkWidget *time_darea, *ttime_darea, *block_darea;

void panel_setup(GtkWidget *window,  GtkWidget *blatest)
{
GtkWidget *frame;
GtkWidget *display;

time_darea = gtk_drawing_area_new ();
ttime_darea =  gtk_drawing_area_new ();
block_darea =  gtk_drawing_area_new ();
gtk_widget_set_usize (time_darea, 5,5);
gtk_widget_set_usize (ttime_darea, 5,5);
gtk_widget_set_usize (block_darea, 5,5);



      display = gtk_label_new ("Track");
      gtk_misc_set_padding (GTK_MISC (display), 3, 3);

      gtk_table_attach (GTK_TABLE (blatest), display, 0, 1, 0, 1,
                    0,0, 0, 0);
      gtk_widget_show (display);

      display = gtk_label_new ("Index");
      gtk_misc_set_padding (GTK_MISC (display), 3, 3);

      gtk_table_attach (GTK_TABLE (blatest), display, 1, 2, 0, 1,
                    0,0, 0, 0);
      gtk_widget_show (display);

      display = gtk_label_new ("Track Time");
      gtk_misc_set_padding (GTK_MISC (display), 13, 3);

      gtk_table_attach (GTK_TABLE (blatest), display, 2, 3, 0, 1,
                  0, 0, 0, 0);
      gtk_widget_show (display);

      display = gtk_label_new ("Total Time");
      gtk_misc_set_padding (GTK_MISC (display), 13, 3);

      gtk_table_attach (GTK_TABLE (blatest), display, 3, 4, 0, 1,
                    0,0, 0, 0);
      gtk_widget_show (display);

      display = gtk_label_new ("Block");
      gtk_misc_set_padding (GTK_MISC (display), 13, 3);

      gtk_table_attach (GTK_TABLE (blatest), display, 4, 5, 0, 1,
                    0,0, 0, 0);
      gtk_widget_show (display);


      panel.totaltrack=gtk_label_new("0");
      gtk_misc_set_padding (GTK_MISC (panel.totaltrack), 3, 3);
      gtk_table_attach (GTK_TABLE (blatest), panel.totaltrack, 0, 1, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (panel.totaltrack);

      panel.totalindex=gtk_label_new("0");
      gtk_misc_set_padding (GTK_MISC (panel.totalindex), 3, 3);
      gtk_table_attach (GTK_TABLE (blatest), panel.totalindex, 1, 2, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (panel.totalindex);



      panel.track=gtk_label_new("0");
      gtk_misc_set_padding (GTK_MISC (panel.track), 3, 3);
      gtk_table_attach (GTK_TABLE (blatest), panel.track, 0, 1, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (panel.track);

      panel.index=gtk_label_new("0");
      gtk_misc_set_padding (GTK_MISC (panel.index), 3, 3);
      gtk_table_attach (GTK_TABLE (blatest), panel.index, 1, 2, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (panel.index);

      panel.track_time=gtk_label_new("0:00");
      gtk_misc_set_padding (GTK_MISC (panel.track_time), 3, 3);
      gtk_table_attach (GTK_TABLE (blatest), panel.track_time, 2, 3, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (panel.track_time);

      panel.total_time=gtk_label_new("0:00");
      gtk_misc_set_padding (GTK_MISC (panel.total_time), 3, 3);
      gtk_table_attach (GTK_TABLE (blatest), panel.total_time, 3, 4, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (panel.total_time);

      panel.block=gtk_label_new("0");
      gtk_misc_set_padding (GTK_MISC (panel.block), 3, 3);
      gtk_table_attach (GTK_TABLE (blatest), panel.block, 4, 5, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (panel.block);


gtk_table_attach (GTK_TABLE (blatest),time_darea, 2,3,2,3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (time_darea);

gtk_table_attach (GTK_TABLE (blatest),ttime_darea, 3,4,2,3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show (ttime_darea);

gtk_table_attach (GTK_TABLE (blatest),block_darea, 4,5,2,3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
 gtk_widget_show (block_darea);

/*
      frame = gtk_frame_new (NULL);
      gtk_table_attach (GTK_TABLE (blatest), frame, 0, 5, 0, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (frame);
*/


}
