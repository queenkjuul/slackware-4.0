/* CDB/BC Wave   Copyright 1998 Bryan Chafy */
/* If you reuse this code for your own purpose, you must include this
   copyright notice. */

#include <gtk/gtk.h>
#include <stdio.h>
#include "gtkwviewport.h"
#include "colors.h"
#include "bcwave.h"
#include "main.h"

/* make larger for better performance, currently ~11meg (dynamic) */
/* should be divisible by 2352 */
#define READBUF 11760000

/* Make larger for more cells, currenty 500000*9 bytes (4.5meg) */
/* WAVBUF * 2352 is total bytes to be held in cells */
/* Each cell holds a value for every 2352 bytes */
/* So a WAVBUF of 500000 can hold 1.17GB of wav data */
#define WAVBUF 500000

/* With the current configuration, ~16MB free memory are needed */

#define SPACER 14
#define AUDIO_RESOLUTION 65535   /* 16 bit samples */


extern struct audiosys audio;
extern GtkWidget *status_display;

GtkWidget *darea;
GtkWidget *c_darea;
GtkAdjustment *adjustment;
GtkWidget *viewport;
GtkWidget *wviewport;
GtkWidget *frame0;

unsigned short leftto[WAVBUF];
unsigned short leftfrom[WAVBUF];
unsigned short rightto[WAVBUF];
unsigned short rightfrom[WAVBUF];
unsigned char color[WAVBUF];

int anchorx = -1;
int c_anchorx = -1;
int c_selection = -1;
int selection_start = -1;
int selection_end = -1;
long cell;
long selection_cell;
int vh,vh2,vh4,lefth;
int cvh,cvh2,clefth;

long bytes=0;
FILE *fp;


void wave_init()
{
int i;

fp = NULL;

anchorx = -1;
c_anchorx = -1;
c_selection = -1;
selection_start = -1;
selection_end = -1;

cell = selection_cell = bytes = 0;


for (i=0;i<WAVBUF;i++)
{
leftto[i] = 0;
leftfrom[i] = 0;
rightto[i] = 0;
rightfrom[i] = 0;
color[i] = 0;
}

if (darea != NULL)
{
gdk_draw_rectangle(darea->window, darea->style->bg_gc[GTK_STATE_NORMAL], TRUE,
0,0,wviewport->allocation.width,wviewport->allocation.height);

gdk_draw_rectangle(c_darea->window, c_darea->style->bg_gc[GTK_STATE_NORMAL], TRUE,
0,0,viewport->allocation.width,viewport->allocation.height);
}

if (adjustment != NULL) {
adjustment->upper = 0;
gtk_adjustment_set_value (adjustment, 0);
}


}


void unselect(GtkWidget *widget, gint start, gint end)
{
  static int i;

  for (i = start; i <= end; i++)
      {                                    

gdk_draw_line (widget->window,
                       widget->style->bg_gc[GTK_WIDGET_STATE (widget)],
                       i, 1,
                       i, vh-2);

gdk_draw_point (widget->window,
                        widget->style->white_gc, i, vh4);

gdk_draw_point (widget->window,
                        widget->style->white_gc, i, vh4 + vh2);
       

        gdk_draw_point (widget->window,
                        gc_color[1], i, vh2);

        gdk_draw_line (widget->window,
                       gc_color[color[cell + i]],
                       i , 1+ leftfrom[cell + i]/lefth,
                       i , 1+ leftto[cell + i]/lefth);

        gdk_draw_line (widget->window,
                       gc_color[color[cell + i]],
                 i ,1+ rightfrom[cell + i]/lefth + vh2,
                 i ,1+ rightto[cell + i ]/lefth + vh2);
      }

}

void c_unselect(GtkWidget *widget, gint start, gint end)
{                                                  

  static int currentwidth;
  static int numlines;    
  static int offset;  

  static int i;        
               
currentwidth=viewport->allocation.width - 7;
numlines = bytes/2352;
offset = numlines / currentwidth + 1;
                           

    for (i = start; i <= end; i++)
      {                                    
        gdk_draw_line (widget->window,
                       widget->style->bg_gc[GTK_WIDGET_STATE (widget)],
                       i, 0,
                       i, cvh);

        gdk_draw_line (widget->window,
                       gc_color[color[i*offset]],
                       i , leftfrom[i*offset]/clefth,
                       i , leftto[i*offset]/clefth);

      }

}


static gint
wave_c_button_press_event (GtkWidget *widget, GdkEventButton *event)
       {

  static int currentwidth;
  static int numlines;
  static int offset;

currentwidth=viewport->allocation.width - 7;
numlines = bytes/2352;
offset = numlines / currentwidth + 1;


if (event->button == 1) {

if (c_anchorx > -1)
c_unselect(widget,c_selection/offset,c_selection/offset);

c_anchorx = (int)event->x;
c_selection = c_anchorx * offset;

gtk_adjustment_set_value(adjustment,((int)event->x * offset)-currentwidth/2);

        gdk_draw_line (widget->window,
                       widget->style->white_gc,
                       event->x, 0,
                       event->x, cvh);

        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                        event->x, leftfrom[(int)event->x * offset]/clefth,
                        event->x, leftto[(int)event->x * offset]/clefth);


             }

adjust(widget,event->x * offset * 2352,1);
adjust(widget,event->x * offset * 2352,0);

         return TRUE;
       }


static gint
wave_button_press_event (GtkWidget *widget, GdkEventButton *event)
       {

if (event->button == 1) {

if (anchorx > -1)
unselect(widget,anchorx,anchorx);

anchorx = (int)event->x;

if (selection_start > -1)
{
if (selection_start < event->x - widget->allocation.width)
selection_start = event->x - widget->allocation.width;

if (selection_end > event->x + widget->allocation.width)
selection_end = event->x + widget->allocation.width;

unselect(widget,selection_start,selection_end);
}

selection_start = -1;
selection_end = -1;

        gdk_draw_line (widget->window,
                       widget->style->white_gc,
                       event->x, 1,
                       event->x, vh-2);

        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                        event->x, 1+ leftfrom[cell + (int)event->x]/lefth,
                        event->x, 1+ leftto[cell + (int)event->x]/lefth);

        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                event->x, 1+rightfrom[cell + (int)event->x]/lefth + vh2,
                event->x, 1+rightto[cell +  (int)event->x]/lefth + vh2);
             }

adjust(widget,(cell + (int)event->x) * 2352,1);
adjust(widget,(cell + (int)event->x) * 2352,0);

         return TRUE;
       }



static gint
wave_motion_notify_event (GtkWidget *widget, GdkEventMotion *event)
       {
         int x, y;
         int start;
         int end; 
         int i;
         GdkModifierType state;


         if (event->is_hint)
           gdk_window_get_pointer (event->window, &x, &y, &state);
         else
           {
             x = event->x;
             y = event->y;
             state = event->state;
           }

           
if (state & GDK_BUTTON1_MASK)
{


if (event->x > anchorx)
{
start = anchorx;
end = (int)event->x;
}
else
{
end = anchorx;
start = (int)event->x;
if (start<0)
start = 0;
}

selection_cell = cell;

if(selection_start == -1){
for (i=start;i<=end;i++)
{
        gdk_draw_line (widget->window,
                       widget->style->white_gc,
                       i, 1,
                       i, vh-2);

        gdk_draw_point (widget->window,
                        widget->style->black_gc, i, vh2);

        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                        i, 1+ leftfrom[cell + i]/lefth,
                        i, 1+ leftto[cell + i]/lefth);

        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                i, 1+rightfrom[cell + i]/lefth + vh2,
                i, 1+rightto[cell +  i]/lefth + vh2);
}
selection_start = start;             
selection_end = end;    
return TRUE;
}


if (selection_end>end)
{
    if (end>anchorx)
    {
     unselect(widget,end+1,selection_end);
     selection_start = start;
     selection_end = end;
    }
    else
    {
     unselect(widget,anchorx+1,selection_end);
     selection_start = end;
     selection_end = anchorx;
    }
return TRUE;
}

if (selection_start<start)
{
   if(start<anchorx)
   {
     unselect(widget,selection_start,start-1);
     selection_start = start;
     selection_end = end;
   }
   else
   {
     unselect(widget,selection_start,anchorx-1);
     selection_start = anchorx;
     selection_end = start;
   }
return TRUE;
}


if(end>selection_end)
for (i=selection_end;i<=end;i++)
{
        gdk_draw_line (widget->window,
                       widget->style->white_gc,
                       i, 1,
                       i, vh-2);

        gdk_draw_point (widget->window,
                        widget->style->black_gc, i, vh2);

        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                        i, 1+ leftfrom[cell + i]/lefth,
                        i, 1+ leftto[cell + i]/lefth);

        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                i, 1+rightfrom[cell + i]/lefth + vh2,
                i, 1+rightto[cell +  i]/lefth + vh2);
}

if (start<selection_start)
for (i=start;i<=selection_start;i++)
{                       
        gdk_draw_line (widget->window,
                       widget->style->white_gc,
                       i, 1,                   
                       i, vh-2);
                               
        gdk_draw_point (widget->window,
                        widget->style->black_gc, i, vh2);
                                                         
        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                        i, 1+ leftfrom[cell + i]/lefth,
                        i, 1+ leftto[cell + i]/lefth); 
                                                      
        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                i, 1+rightfrom[cell + i]/lefth + vh2,
                i, 1+rightto[cell + i]/lefth + vh2);
}


selection_start = start;
selection_end = end;

}
         
         return TRUE;
       }


static gint
wave_expose_event (GtkWidget * widget, GdkEventExpose * event)
{
  static int i;
  static int warea;
  static int ieareax;
  static int cieareax;

cell = 30000 * ((long) adjustment->value / 30000);

if (event->type == 13)
{
if (event->area.width > viewport->allocation.width)
event->area.width = viewport->allocation.width;

if (event->area.x < (event->area.width - viewport->allocation.width))
event->area.x = (event->area.width - viewport->allocation.width);


vh = (wviewport->allocation.height-SPACER);
vh2 = vh/2;
vh4 = vh/4;
lefth = (AUDIO_RESOLUTION/(vh2-2));
}

warea=event->area.x + event->area.width;


  if (event->area.x <= bytes / 2352) {

  gdk_draw_line (widget->window, gc_color[1],
		 event->area.x, 0,
		 warea, 0);

  gdk_draw_line (widget->window, gc_color[1],
		 event->area.x, vh2,
		 warea,  vh/2);

  gdk_draw_line (widget->window, gc_color[1],
		 event->area.x, vh,
		 warea,  vh);

    for (i = 0; i < event->area.width; i++)
      {

ieareax=i+event->area.x;
cieareax=cell+i+event->area.x;

/* in a selection */
if (cell == selection_cell && ieareax>=selection_start && ieareax<=selection_end)
{

        gdk_draw_line (widget->window,
                       widget->style->white_gc,
                       ieareax, 1,
                       ieareax, vh-2);

        gdk_draw_point (widget->window,
                        widget->style->black_gc, ieareax, vh4);

         gdk_draw_line (widget->window,
                       widget->style->black_gc,
                       ieareax, 1+ leftfrom[cieareax]/lefth,
                       ieareax, 1+ leftto[cieareax]/lefth); 

        gdk_draw_line (widget->window,
                       widget->style->black_gc,
               ieareax, 1+ rightfrom[cieareax]/lefth + vh2,
               ieareax, 1+ rightto[cieareax]/lefth + vh2);

}
else
{
  gdk_draw_point (widget->window,
                        widget->style->white_gc, ieareax, vh4);

  gdk_draw_point (widget->window,
                        widget->style->white_gc, ieareax, vh2 + vh4 );

	gdk_draw_line (widget->window,
		       gc_color[color[cieareax]],
		       ieareax, 1+ leftfrom[cieareax]/lefth,
		       ieareax, 1+ leftto[cieareax]/lefth);

	gdk_draw_line (widget->window,
		       gc_color[color[cieareax]],
	       ieareax, 1+rightfrom[cieareax]/lefth + vh2,
	       ieareax, 1+rightto[cieareax]/lefth + vh2);
}
      }

}




  return FALSE;
}

static gint
wave_c_expose_event (GtkWidget * widget, GdkEventExpose * event)
{                                                        
  static int i;

  static int currentwidth;
  static int numlines;
  static int offset;

if (event->type == 13)
{
cvh = (viewport->allocation.height);
cvh2 = cvh/2;
clefth = (AUDIO_RESOLUTION/(cvh-2));
}


currentwidth=viewport->allocation.width - 7;
numlines = bytes/2352;
offset = numlines / currentwidth + 1;

// printf ("w=%d nl=%d offset=%d\n",currentwidth,numlines,offset);


if (event->area.x <= bytes / 2352)
    for (i = 0; i <= currentwidth; i++)
      {

if( i*offset<=c_selection && (i+1)*offset>c_selection)
{
        gdk_draw_line (widget->window,
                       widget->style->white_gc,
                       i, 0,
                       i, cvh);

        gdk_draw_line (widget->window,
                       widget->style->black_gc,
                       i,  leftfrom[i*offset]/clefth,
                       i,  leftto[i*offset]/clefth);


gtk_adjustment_set_value(adjustment,(i * offset)-currentwidth/2);


}
else
{


        gdk_draw_line (widget->window,
                       widget->style->bg_gc[GTK_WIDGET_STATE (widget)],
                       i, 0,
                       i, cvh);

      
         if(i*offset <= numlines) 
         {


        gdk_draw_line (widget->window,
                       gc_color[color[i*offset]],
                       i,  leftfrom[i*offset]/clefth,
                       i,  leftto[i*offset]/clefth);
          }
}

      }

  return FALSE;
}



/* start, end, pad are in bytes */
int scanwave (char * filename, int start, int end, int offset)
{
  unsigned char * readbuf;
  short lmax, lmin, rmax, rmin;
  int i, j, x;                    
  short lchannel, rchannel;
  unsigned char *chl;      
  unsigned char *chr;
  int val=0;
  int ender;
  int padval = 0;
  int countb,countc, countend;
  static unsigned char mycolor=0;
  
  countb = 0;
  countend = end/2352;
  offset = offset/2352;
  chl = &lchannel;
  chr = &rchannel;

  fp = fopen (filename, "r");
                  
  if (fp == NULL)
    {            
      printf ("error opening file\n");
      return -1;
    }


if(start%4)
{
printf("bad offset at start\n");
}

if(end%4)
{
printf("bad offset at end\n");
}

if (end-start>WAVBUF * 2352)
    {                   
      printf ("Error, file too large.\nRecompile with a larger WAVBUF\n");
      fclose(fp);                                                         
      return -1;
    }          
     
readbuf = (char *)malloc(READBUF);

if (readbuf == NULL)              
{                   
printf ("Error, cannot allocate %d bytes.\n1 - Recompile with a smaller READBUF\n",READBUF);
      fclose(fp);
      return -1;
}    

bytes += end-start;
          

printf("Please Wait! Scanning Files\n");

fseek (fp, (long)start, SEEK_SET);

while(countb<countend){
start+=val;

val = fread(&readbuf[0],1,READBUF,fp);

if (val+start > end)
ender=end;
else
ender = val+start;


if ((ender - start) % 2352)  /* pad bytes here */
{
printf("Warning, Padded %d bytes\n", 2352 - (ender - start) % 2352);
padval = 2352 - (ender - start) % 2352;

for (x=0;x<padval;x++)
readbuf[x+ (val/2352)] = 0;

ender += padval;
}

// printf("start = %d end = %d val = %d ender = %d\n",start,end,val,ender);

countc = 0;

for (i=start;i<ender;i+=2352)
{

lmax = rmax = -32767;
lmin = rmin = 32767;

for (j=0;j<2352;j+=16)  // was 4
{
chl[0]=readbuf[j+countc];
chl[1]=readbuf[j+countc+1];
chr[0]=readbuf[j+countc+2];
chr[1]=readbuf[j+countc+3];

if (rchannel>rmax)
rmax = rchannel;

if (rchannel<rmin)
rmin = rchannel;

if (lchannel>lmax)
lmax = lchannel;

if (lchannel<lmin)
lmin = lchannel;

}

leftfrom[countb+offset] = lmin+32768;
leftto[countb+offset] = lmax+32768;
rightfrom[countb+offset] = rmin+32768;
rightto[countb+offset] = rmax+32768;
color[countb+offset]=mycolor;
countb++;
countc+=2352;
}
printf("scanning %s %f pct done\n", filename, 100*((float)countb/(float)countend));
}

fclose (fp);
free(readbuf);
mycolor++;
mycolor%=8;

printf("scanning %s 100 pct done\n", filename);

  adjustment->upper = (gfloat) (bytes/2352);
  gtk_adjustment_set_value (adjustment, (bytes/2352));
  gtk_adjustment_set_value (adjustment, 0);

return padval;
}



int smart_scanwave (char * filename, float level, int time)
{
  unsigned char * readbuf;
  short lmax, lmin, rmax, rmin;
  int i, j, x;                    
  short lchannel, rchannel;       
  unsigned char *chl;      
  unsigned char *chr;      
  int val=0;    
  int ender;
  int padval = 0;
  int start = 0;
  int end;
  int cv=0;
  int blank=0;
  int countb, countend;

level = 32767.0 * level;


  fp = fopen (filename, "r");
                             
  if (fp == NULL) 
    {            
      printf ("error opening file\n");
      return -1;                      
    }           
                             
  fseek (fp, 0L, SEEK_END);
  bytes = ftell (fp);      
  fseek (fp, 0L, SEEK_SET);
                 
  countb = 0;
  countend = end/2352;
  chl = &lchannel;    
  chr = &rchannel;
                  
               
if(start%4)
{          
printf("bad offset at start\n");
}                               
 
if(end%4)
{        
printf("bad offset at end\n");
}                             
 
if (end-start>WAVBUF * 2352)
    {                       
      printf ("Error, file too large.\nRecompile with a larger WAVBUF\n");
      fclose(fp);                                                         
      return -1;                                                          
    }           
               
readbuf = (char *)malloc(READBUF);
                                  
if (readbuf == NULL)              
{                                 
printf ("Error, cannot allocate %d bytes.\n1 - Recompile with a smaller READBUF\n",READBUF);
      fclose(fp);   
      return -1; 
}               
               
fseek (fp, (long)start, SEEK_SET);
                                  
while(countb<countend){
start+=val;            
           
printf("done\nreading...\n");
val = fread(&readbuf[0],READBUF,1,fp);
printf("done\nparsing\n");            
                          
if (val+start > end)
ender=end;          
else      
ender = val+start;
                  
if ((ender - start) % 2352)  /* pad bytes here */
{                                                
printf("Warning, Padded %d bytes\n", 2352 - (ender - start) % 2352);
padval = 2352 - (ender - start) % 2352;                             

for (x=0;x<padval;x++)
readbuf[x+ender] = 0;

ender += padval;
}

for (i=start;i<ender;i+=2352)
{

lmax = rmax = -32767;
lmin = rmin = 32767;

for (j=0;j<2352;j+=16)  // was 4
{
chl[0]=readbuf[j+i];
chl[1]=readbuf[j+i+1];
chr[0]=readbuf[j+i+2];
chr[1]=readbuf[j+i+3];

if (rchannel>rmax)
rmax = rchannel;

if (rchannel<rmin)
rmin = rchannel;

if (lchannel>lmax)
lmax = lchannel;

if (lchannel<lmin)
lmin = lchannel;

}

leftfrom[countb] = lmin;
leftto[countb] = lmax;
rightfrom[countb] = rmin;
rightto[countb] = rmax;

if(blank<=time && abs(lmin) < level && abs(lmax) < level && abs(rmin) < level && abs(rmax) < level)
{
blank++;
if (blank>time)
  cv++;
/* SET NEW TRACK HERE */
}
else
blank=0;

color[countb]=cv%9;

countb++;
}
}

fclose (fp);
free(readbuf);
return padval;
}

int wave_set_cursor(int location)
{
static int currentwidth;
static int numlines;
static int offset;
static int c_last_location, c_location;
static int last_location = -1;
static int rel_location;
static int last_rel_location;
static int i=0;

rel_location = location % 30000;
last_rel_location = last_location % 30000;

currentwidth=viewport->allocation.width - 7;
numlines = bytes/2352;
offset = numlines / currentwidth + 1;

c_last_location = last_location / offset; 
c_location = location/ offset;

if (audio.wave_update)
gtk_adjustment_set_value(adjustment,((int)location )-currentwidth/2);
i++;


        gdk_draw_line (darea->window,
                       gc_color[4],
                       rel_location, 1,            
                       rel_location, vh-2);
                                      

        gdk_draw_line (c_darea->window,
                      gc_color[4],
                       c_location, 0,
                       c_location, cvh);


if (last_location > -1)
{
        gdk_draw_line (darea->window,
                       darea->style->black_gc,
                       last_rel_location, 1,            
                       last_rel_location, vh-2);

        gdk_draw_point (darea->window,
                        gc_color[1], last_rel_location, vh2);
                                      
        gdk_draw_line (darea->window,
                       gc_color[color[last_location]],
                        last_rel_location, 1+ leftfrom[last_location]/lefth,
                        last_rel_location, 1+ leftto[last_location]/lefth);

        gdk_draw_line (darea->window,
                       gc_color[color[last_location]],
                last_rel_location, 1+rightfrom[last_location]/lefth + vh2,
                last_rel_location, 1+rightto[last_location]/lefth + vh2);

if (c_last_location*offset != c_location*offset) {

        gdk_draw_line (c_darea->window,
                       c_darea->style->black_gc,
                       c_last_location, 0,
                       c_last_location, cvh);

        gdk_draw_line (c_darea->window,
                       gc_color[color[last_location]],
                        c_last_location, leftfrom[c_last_location*offset]/clefth,
                        c_last_location, leftto[c_last_location*offset]/clefth);

}
}


last_location = location;

return 0;
}



int wave_set_gap (int start, int end)
{
int i;

bytes += (end-start);

start/=2352;
end/=2352;


for (i=start;i<end;i++)
{
leftto[i]=32767;
leftfrom[i]=32767;
rightto[i]=32767;
rightfrom[i]=32767;
color[i] = 9;
}

return 0;
}

int wave_set_track (int start, int end)
{
return 0;
}

int wave_set_index (int_start, int_end)
{
return 0;
}

int wave_ignore_area()
{
return 0;
}


int 
wave_window ()
{
  /* GtkWidget is the storage type for widgets */
  static GtkStyle *new_style;
  static GtkStyle *new_style2;
  static GdkColor col;
  static GdkColormap *cmap;

  GtkWidget *window;
  GtkWidget *scrollbar;
  GtkWidget *box;
  GtkWidget *tbox;
  GtkWidget *box1;
  GtkWidget *box0;
  GtkWidget *main_box;
  GtkWidget *play_box;
  GtkWidget *button_table;
  GtkWidget *sub_button_table;
  GtkWidget *newbox;
  GtkWidget *pbar;

  GtkWidget *frame;
  GtkWidget *bframe;
  GtkWidget *vpaned;


  /* this is called in all GTK applications.  arguments are parsed from
   * the command line and are returned to the application. */

  /* create a new window */
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window), "BC Wave");
  gtk_signal_connect (GTK_OBJECT (window), "delete_event",
		      GTK_SIGNAL_FUNC (gtk_false), NULL);
  gtk_container_border_width (GTK_CONTAINER (window), 1);
  gtk_widget_set_usize (GTK_WIDGET (window), 600, 0);

  adjustment = (GtkAdjustment *) gtk_adjustment_new (1.0, 1.0, (gfloat)bytes/2352, 1.0, 1.0, 1.0);

  wviewport = gtk_wviewport_new (adjustment, NULL);
  viewport = gtk_viewport_new (NULL,NULL);
  scrollbar = gtk_hscrollbar_new (adjustment);

  gtk_widget_set_usize (GTK_WIDGET (viewport), 600, 80);
  gtk_widget_set_usize (GTK_WIDGET (wviewport), 600, 200);

  main_box =  gtk_vbox_new (FALSE, 0);
  gtk_container_add (GTK_CONTAINER (window), main_box);
  gtk_container_border_width (GTK_CONTAINER(main_box), 0);
  gtk_widget_show (main_box);

  cdb_menubar(main_box, window);



  vpaned = gtk_vpaned_new ();
  gtk_container_add (GTK_CONTAINER (main_box), vpaned);
  gtk_container_border_width (GTK_CONTAINER(vpaned), 0);
  gtk_widget_show (vpaned);


  tbox = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (tbox);
  gtk_paned_add1 (GTK_PANED (vpaned), tbox);


  box = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (box);
  gtk_paned_add2 (GTK_PANED (vpaned), box);


  gtk_box_pack_start (GTK_BOX (tbox), viewport, TRUE, TRUE, 1);
  gtk_box_pack_start (GTK_BOX (box), wviewport, TRUE, TRUE, 1);
  gtk_box_pack_start (GTK_BOX (box), scrollbar, FALSE, TRUE, 1);
  gtk_widget_show (tbox);
  gtk_widget_show (box);
  gtk_widget_show (viewport);
  gtk_widget_show (wviewport);
  gtk_widget_show (scrollbar);

  /* main vbox */

  box0 = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (box0);        
  gtk_container_add (GTK_CONTAINER (viewport), box0);

  box1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (box1);
  gtk_container_add (GTK_CONTAINER (wviewport), box1);


  /* frame for wave */
  frame0 = gtk_frame_new (NULL);
  gtk_container_border_width (GTK_CONTAINER (frame0), 0);
  gtk_box_pack_start (GTK_BOX (box0), frame0, TRUE, TRUE, 0);
  gtk_widget_show (frame0);

  frame = gtk_frame_new (NULL);
  gtk_container_border_width (GTK_CONTAINER (frame), 0);
  gtk_box_pack_start (GTK_BOX (box1), frame, TRUE, TRUE, 0);
  gtk_widget_show (frame);


  play_box =  gtk_vbox_new (FALSE, 0);
  gtk_container_add (GTK_CONTAINER (main_box), play_box);
  gtk_container_border_width (GTK_CONTAINER(play_box), 0);
  gtk_widget_show (play_box);
gtk_box_set_child_packing (GTK_BOX (main_box), play_box, FALSE, FALSE, 0, GTK_PACK_START);


  button_table = gtk_table_new (2, 7, TRUE);
  gtk_box_pack_start (GTK_BOX (play_box), button_table, FALSE , TRUE , 1);
  gtk_widget_show (button_table); 

      bframe = gtk_frame_new (NULL);
      gtk_table_attach (GTK_TABLE (button_table), bframe, 0, 3, 0, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (bframe);



  sub_button_table = gtk_table_new (3, 5, TRUE);

  gtk_table_attach (GTK_TABLE (button_table),sub_button_table,3,7,0,2,
     GTK_FILL, GTK_FILL, 0, 0);

  gtk_widget_show (sub_button_table);

  play_buttons(window, button_table);
  panel_setup(window,sub_button_table);


  newbox = gtk_hbox_new (FALSE, 5);
  gtk_container_border_width (GTK_CONTAINER (newbox), 2);   
  gtk_box_pack_end (GTK_BOX (main_box),
                          newbox, FALSE, FALSE, 0);
  gtk_widget_show (newbox);


  status_display = gtk_label_new (" Welcome To CDB     ");
  gtk_box_pack_start (GTK_BOX (newbox), status_display, FALSE , FALSE , 5);
  gtk_widget_show (status_display);

  pbar = gtk_progress_bar_new ();
  gtk_widget_set_usize (pbar, 0, 16); 
  gtk_box_pack_start (GTK_BOX (newbox), pbar, TRUE, TRUE, 1);
  gtk_widget_show (pbar); 


  /* wave drawing area */
 
  c_darea = gtk_drawing_area_new ();
  darea = gtk_drawing_area_new ();

  gtk_widget_set_usize (darea, 32767, 270);
  gtk_widget_set_usize (c_darea, 32767, 135);

  gtk_widget_show (darea);
  gtk_widget_show (c_darea);

  gtk_widget_show (window);
  color_init(window);

  gtk_signal_connect (GTK_OBJECT (darea), "motion_notify_event",
                             (GtkSignalFunc) wave_motion_notify_event, NULL);
  gtk_signal_connect (GTK_OBJECT (darea), "button_press_event",
                             (GtkSignalFunc) wave_button_press_event, NULL);
  gtk_signal_connect (GTK_OBJECT (darea), "expose_event",
		      GTK_SIGNAL_FUNC (wave_expose_event), NULL);
  gtk_signal_connect (GTK_OBJECT (darea), "configure_event",
		      GTK_SIGNAL_FUNC (wave_expose_event), NULL);


/*

  gtk_signal_connect (GTK_OBJECT (c_darea), "motion_notify_event",
                             (GtkSignalFunc) wave_c_motion_notify_event, NULL);
*/


  gtk_signal_connect (GTK_OBJECT (c_darea), "button_press_event",
                             (GtkSignalFunc) wave_c_button_press_event, NULL);
  gtk_signal_connect (GTK_OBJECT (c_darea), "expose_event",
                      GTK_SIGNAL_FUNC (wave_c_expose_event), NULL);
  gtk_signal_connect (GTK_OBJECT (c_darea), "configure_event",
                      GTK_SIGNAL_FUNC (wave_c_expose_event), NULL);


/*
  gtk_widget_set_events (darea, GDK_EXPOSURE_MASK
                                | GDK_LEAVE_NOTIFY_MASK
                                | GDK_BUTTON_PRESS_MASK
                                | GDK_POINTER_MOTION_MASK
                                | GDK_POINTER_MOTION_HINT_MASK);
*/

 gtk_widget_set_events (darea, GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK 
                               | GDK_POINTER_MOTION_MASK);
 gtk_widget_set_events (c_darea, GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK
                               | GDK_POINTER_MOTION_MASK);


  gtk_container_add (GTK_CONTAINER (frame0), c_darea);
  gtk_container_add (GTK_CONTAINER (frame), darea);



cmap = gdk_colormap_get_system();
// cmap = gtk_widget_get_colormap (darea);
      col.red = 0;
      col.green = 0;
      col.blue = 0;
      if (!gdk_color_alloc (cmap, &col))
        g_error ("Couldn't allocate black");

 new_style = gtk_style_new ();
 new_style->bg[GTK_STATE_NORMAL] = col ;        
 new_style->bg_gc[GTK_STATE_NORMAL] = gdk_gc_new (darea->window);

 new_style2 = gtk_style_new ();
 new_style2->bg[GTK_STATE_NORMAL] = col;        
 new_style2->bg_gc[GTK_STATE_NORMAL] = gdk_gc_new (c_darea->window);

// gdk_gc_set_foreground (darea->style->bg_gc[GTK_STATE_NORMAL], &col);
// gdk_gc_set_foreground (c_darea->style->bg_gc[GTK_STATE_NORMAL], &col);
gtk_widget_set_style (darea, new_style); 
gtk_widget_set_style (c_darea, new_style2); 


  return 0;
}
