GdkGC *gc_color[10];
void color_init(GtkWidget *widget);

