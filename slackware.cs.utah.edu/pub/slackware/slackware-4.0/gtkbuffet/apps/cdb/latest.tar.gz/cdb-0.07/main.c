#include <gtk/gtk.h>
#include "gtkfileadd.h"
#include <signal.h>
#include "pad.h"
#include "main.h"

GtkWidget *time_darea, *ttime_darea, *block_darea;
GtkWidget *list, *status_display;
cd_type cd = {0};
front_panel panel;
audiosys audio;
cue_sheet_entry cue_sheet = {0};
static cdp entry;
int yesno=0;
gint mytag=0;
int stats2=0, af=0;

GList *files_list = NULL;

GtkCombo *cb;

int shmid, rdid, wtid, locid, playid;
GtkWidget *window;

int main (int argc, char *argv[])
{
          
  GtkWidget *main_vbox;
  GtkWidget *newbox;
  GtkWidget *blatest,*subtable;
  GtkWidget *pbar;
  GtkWidget *blatest2;
  GtkWidget *display;

  GtkWidget *frame;
  GtkWidget *scrolled_win;


  gtk_init (&argc, &argv);


  cd.catalog_num = strdup("0000000000000");
  cd.country = strdup("PRC");
  cd.owner = strdup("ME");
  cd.serial_num = strdup("ABC123");
  cd.year = strdup("1998");
  audio.mixer = strdup("xmixer");
  audio.dsp = strdup("/dev/dsp");
  audio.pid = 0;


/* show wave_window */
wave_init();
wave_window();

/*
      scrolled_win = gtk_scrolled_window_new (NULL, NULL);
      gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win),
                                      GTK_POLICY_AUTOMATIC,
                                      GTK_POLICY_AUTOMATIC);

      gtk_table_attach (GTK_TABLE (blatest), scrolled_win, 0, 2, 0, 9,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
      gtk_widget_show (scrolled_win);


panel.adjustment = (GtkAdjustment *) gtk_adjustment_new (0.0, 0.0, 0.0, (gfloat)CDASEC, (gfloat)CDASEC, 1.0);

blatest2 = gtk_hscale_new (GTK_ADJUSTMENT (panel.adjustment));

gtk_widget_set_events(blatest2,GDK_BUTTON_PRESS_MASK);
gtk_signal_connect(GTK_OBJECT(blatest2),"button_press_event",
GTK_SIGNAL_FUNC (adjust), (gpointer)1);

gtk_widget_set_events(blatest2,GDK_BUTTON_PRESS_MASK);
gtk_signal_connect(GTK_OBJECT(blatest2),"button_release_event",
GTK_SIGNAL_FUNC (adjust), (gpointer)0);

      gtk_widget_set_usize (GTK_WIDGET (blatest2), 150, 30);
      gtk_range_set_update_policy (GTK_RANGE (blatest2), GTK_UPDATE_DISCONTINUOUS);
      gtk_scale_set_digits (GTK_SCALE (blatest2), 0);
      gtk_scale_set_draw_value (GTK_SCALE (blatest2), TRUE);

      gtk_table_attach (GTK_TABLE (blatest), blatest2, 2, 7, 4, 5,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

      gtk_widget_show (blatest2); 

      panel.fine_adjustment = (GtkAdjustment *) gtk_adjustment_new (0.0, 0.0, 0.0, (gfloat)CDASEC, (gfloat)CDASEC, 1.0);

      blatest2 = gtk_hscale_new (GTK_ADJUSTMENT (panel.fine_adjustment));

gtk_widget_set_events(blatest2,GDK_BUTTON_PRESS_MASK);
gtk_signal_connect(GTK_OBJECT(blatest2),"button_press_event",
GTK_SIGNAL_FUNC (fine_adjust), (gpointer)1);

gtk_widget_set_events(blatest2,GDK_BUTTON_PRESS_MASK);
gtk_signal_connect(GTK_OBJECT(blatest2),"button_release_event",
GTK_SIGNAL_FUNC (fine_adjust), (gpointer)0);

      gtk_widget_set_usize (GTK_WIDGET (blatest2), 150, 30);
      gtk_range_set_update_policy (GTK_RANGE (blatest2), GTK_UPDATE_DISCONTINUOUS);
      gtk_scale_set_digits (GTK_SCALE (blatest2), 0);
      gtk_scale_set_draw_value (GTK_SCALE (blatest2), TRUE);

      gtk_table_attach (GTK_TABLE (blatest), blatest2, 2, 7, 5, 6,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

      gtk_widget_show (blatest2);
  gtk_widget_show (window);

*/







  gtk_main ();
  return (0);
}


void
file_quit_cmd_callback (GtkWidget * widget, gpointer data)
{
  g_print ("%s\n", (char *) data);
  
 if (audio.pid) {
  kill(audio.pid,SIGTERM);
 waitpid(audio.pid);
}

  gtk_exit (0);
}

void oncdb_cmd_callback (GtkWidget *widget) 
{
system ("xterm -e man cdb &");
}


void endian_toggle  (GtkWidget * widget)
{

    if (GTK_TOGGLE_BUTTON (widget)->active)
    audio.endianinv = 1;
    else
    audio.endianinv = 0;

}

void da_toggle  (GtkWidget * widget)
{

    if (GTK_TOGGLE_BUTTON (widget)->active)
    audio.da = 1;
    else
    audio.da = 0;

}

void audiodev_callback (GtkWidget * widget)
{                                            
GtkWidget *button;     
GtkWidget *label; 
GtkWidget *radiobutton;
static GtkWidget *dialog_window = NULL;
                                       
dialog_window = gtk_dialog_new();
                                 
gtk_window_position (GTK_WINDOW (dialog_window), GTK_WIN_POS_NONE);
                                                                   
gtk_signal_connect (GTK_OBJECT (dialog_window), "destroy",
                   (GtkSignalFunc) destroy_window, &dialog_window);
gtk_signal_connect (GTK_OBJECT (dialog_window), "delete_event",
                   (GtkSignalFunc) destroy_window, &dialog_window);

gtk_window_set_title (GTK_WINDOW (dialog_window), "Audio Device");
gtk_container_border_width (GTK_CONTAINER (dialog_window), 10);

button = gtk_button_new_with_label ("OK");
gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   (GtkSignalFunc) update_audio_properties,
                          GTK_OBJECT(dialog_window));
GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->action_area),
                          button, TRUE, TRUE, 0);
gtk_widget_grab_default (button); 
gtk_widget_show (button);

button = gtk_button_new_with_label ("Cancel");
gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   (GtkSignalFunc) gtk_widget_destroy,
                          GTK_OBJECT(dialog_window));
GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->action_area),
                          button, TRUE, TRUE, 0);
gtk_widget_grab_default (button); 
gtk_widget_show (button);

label = gtk_label_new ("Set Audio Devices\n");
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox),
                          label, TRUE, TRUE, 0);               
gtk_widget_show (label);

radiobutton = gtk_check_button_new_with_label ("Ulaw output");

gtk_signal_connect (GTK_OBJECT (radiobutton), "toggled",
                        GTK_SIGNAL_FUNC (da_toggle), NULL);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox),
                         radiobutton , TRUE, TRUE, 0);

gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radiobutton), audio.da);

gtk_widget_show (radiobutton);


radiobutton = gtk_check_button_new_with_label ("Invert Endian Order");

gtk_signal_connect (GTK_OBJECT (radiobutton), "toggled",
                        GTK_SIGNAL_FUNC (endian_toggle), NULL);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox),
                         radiobutton , TRUE, TRUE, 0);

gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radiobutton), audio.endianinv);

gtk_widget_show (radiobutton);

                        
label = gtk_label_new ("\nDSP Device ");
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox),
                          label, TRUE, TRUE, 0);
gtk_widget_show (label);                        
                        
audio.dsp_val = gtk_entry_new ();
/* gtk_widget_set_usize (entry, 0, 25); */
gtk_entry_set_text (GTK_ENTRY (audio.dsp_val), audio.dsp);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox), audio.dsp_val, TRUE, TRUE, 0);
gtk_widget_show (audio.dsp_val);                                                              

label = gtk_label_new ("\nMixer Program ");
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox),
                          label, TRUE, TRUE, 0);               
gtk_widget_show (label);                        
                        
audio.mixer_val = gtk_entry_new ();
/* gtk_widget_set_usize (entry, 0, 25); */
gtk_entry_set_text (GTK_ENTRY (audio.mixer_val), audio.mixer);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox), audio.mixer_val, TRUE, TRUE, 0);
gtk_widget_show (audio.mixer_val);                                                              
                        
if (!GTK_WIDGET_VISIBLE (dialog_window))
    gtk_widget_show (dialog_window); 
else                                   
    gtk_widget_destroy (dialog_window);
                                       
}



void subctoggle_info  (GtkWidget * widget, gpointer * data)
{

    if (GTK_TOGGLE_BUTTON (widget)->active)
    cd.subcode_type = (int) data;

}


void toggle_info (GtkWidget * widget, gpointer * data)
{
char * result;
result = (char *) data;

    if (GTK_TOGGLE_BUTTON (widget)->active) 
    {
if (strcmp("CDDA",result) != 0)
{
printf("%s not yet supported\n",result);
}
else
cd.media_type = strdup(result);
    
    } 


}

void mediatype_callback (GtkWidget * widget)
{                                            
char * mediatype[11] = {"CDDA", "CD-ROM", "XA", "CD-I", "CD Extra", "Enhanced", "UDF", "CD-G", "Video CD", "CD-MIDI", "CD-TEXT" };
GtkWidget *radiobutton;
GtkWidget *button;     
static GtkWidget *dialog_window = NULL;
int i;

dialog_window = gtk_dialog_new();
                                 
gtk_window_position (GTK_WINDOW (dialog_window), GTK_WIN_POS_NONE);
                                                                   
gtk_signal_connect (GTK_OBJECT (dialog_window), "destroy",
                   (GtkSignalFunc) destroy_window, &dialog_window);
gtk_signal_connect (GTK_OBJECT (dialog_window), "delete_event",    
                   (GtkSignalFunc) destroy_window, &dialog_window);
                                                                   
gtk_window_set_title (GTK_WINDOW (dialog_window), "Media");
gtk_container_border_width (GTK_CONTAINER (dialog_window), 10);

button = gtk_button_new_with_label ("OK");

gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   (GtkSignalFunc) gtk_widget_destroy,
                          GTK_OBJECT(dialog_window));

GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->action_area),
                          button, TRUE, TRUE, 0);
gtk_widget_grab_default (button); 
gtk_widget_show (button);

radiobutton = gtk_radio_button_new_with_label (NULL, mediatype[0]);

  gtk_signal_connect (GTK_OBJECT (radiobutton), "toggled",
                        GTK_SIGNAL_FUNC (toggle_info), (gpointer) mediatype[0]);

      gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox), radiobutton, TRUE, TRUE, 1);
      gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (radiobutton), TRUE);
      gtk_widget_show (radiobutton);

for (i=1; i<11; i++) {

radiobutton = gtk_radio_button_new_with_label (gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton)), mediatype[i]);
gtk_signal_connect (GTK_OBJECT (radiobutton), "toggled",
                    GTK_SIGNAL_FUNC (toggle_info), (gpointer) mediatype[i]);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox), radiobutton, TRUE, TRUE, 1);
gtk_widget_show (radiobutton);

}


if (!GTK_WIDGET_VISIBLE (dialog_window))
    gtk_widget_show (dialog_window);    
else                                   
    gtk_widget_destroy (dialog_window);

}

void subctype_callback (GtkWidget * widget)
{                                            
GtkWidget *radiobutton;                      
GtkWidget *button;                           
static GtkWidget *dialog_window = NULL;

dialog_window = gtk_dialog_new();      
                                       
gtk_window_position (GTK_WINDOW (dialog_window), GTK_WIN_POS_NONE);
                                                                   
gtk_signal_connect (GTK_OBJECT (dialog_window), "destroy",         
                   (GtkSignalFunc) destroy_window, &dialog_window);
gtk_signal_connect (GTK_OBJECT (dialog_window), "delete_event",    
                   (GtkSignalFunc) destroy_window, &dialog_window);
                                                                   
gtk_window_set_title (GTK_WINDOW (dialog_window), "Subcode");
gtk_container_border_width (GTK_CONTAINER (dialog_window), 10);

button = gtk_button_new_with_label ("OK");
                                          
gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   (GtkSignalFunc) gtk_widget_destroy,    
                          GTK_OBJECT(dialog_window)); 
                                                     
GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->action_area),
                          button, TRUE, TRUE, 0);                     
gtk_widget_grab_default (button);                
gtk_widget_show (button);
                         
radiobutton = gtk_radio_button_new_with_label (NULL, "Type 1");
gtk_signal_connect (GTK_OBJECT (radiobutton), "toggled",
                    GTK_SIGNAL_FUNC (subctoggle_info), (gpointer) 1);
      gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox), radiobutton, TRUE, TRUE, 1);
      gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (radiobutton), TRUE);  
      gtk_widget_show (radiobutton);                                      

radiobutton = gtk_radio_button_new_with_label (gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton)), "Type 2");
gtk_signal_connect (GTK_OBJECT (radiobutton), "toggled",
                    GTK_SIGNAL_FUNC (subctoggle_info), (gpointer) 2);
      gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox), radiobutton, TRUE, TRUE, 1);                
      gtk_widget_show (radiobutton);                                                              
                                    
radiobutton = gtk_radio_button_new_with_label (gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton)), "Type 3");
gtk_signal_connect (GTK_OBJECT (radiobutton), "toggled",
                    GTK_SIGNAL_FUNC (subctoggle_info), (gpointer) 3);
      gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox), radiobutton, TRUE, TRUE, 1);
      gtk_widget_show (radiobutton);                                                              
                                    
if (!GTK_WIDGET_VISIBLE (dialog_window))
    gtk_widget_show (dialog_window);    
else                                   
    gtk_widget_destroy (dialog_window);
                                       
}

void paddit_yes(GtkWidget * w,  GtkWidget * win)
{
yesno=1;
gtk_grab_remove(win);
gtk_main_quit();
gtk_widget_destroy(win);
}

void paddit_no(GtkWidget * w, GtkWidget * win)
{
yesno=0;
gtk_grab_remove(win);
gtk_main_quit();
gtk_widget_destroy(win);
}

void paddit (char * message)
{                                            
GtkWidget *label; 
GtkWidget *button;                           
static GtkWidget *dialog_window = NULL;
                                       
dialog_window = gtk_dialog_new();      
                                       
gtk_window_position (GTK_WINDOW (dialog_window), GTK_WIN_POS_CENTER);
                                                                   
gtk_signal_connect (GTK_OBJECT (dialog_window), "destroy",         
                   (GtkSignalFunc) destroy_window, &dialog_window);
gtk_signal_connect (GTK_OBJECT (dialog_window), "delete_event",    
                   (GtkSignalFunc) destroy_window, &dialog_window);

gtk_container_border_width (GTK_CONTAINER (dialog_window), 10);

button = gtk_button_new_with_label ("Yes");
gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   (GtkSignalFunc) paddit_yes,    
                          GTK_OBJECT(dialog_window)); 
GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->action_area),
                          button, TRUE, TRUE, 0);                     
gtk_widget_grab_default (button);                
gtk_widget_show (button);

button = gtk_button_new_with_label ("NO");
gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   (GtkSignalFunc) paddit_no,    
                          GTK_OBJECT(dialog_window));     
GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);       
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->action_area),
                          button, TRUE, TRUE, 0);                     
gtk_widget_grab_default (button);                                     
gtk_widget_show (button);

label = gtk_label_new (message);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox),
                          label, TRUE, TRUE, 0);               
gtk_widget_show (label);      
                         
if (!GTK_WIDGET_VISIBLE (dialog_window))
    gtk_widget_show (dialog_window);    
else                                   
    gtk_widget_destroy (dialog_window);

gtk_grab_add(dialog_window);
gtk_main();
}



void permission_callback (GtkWidget * widget)
{
int i = 0;
play_file *playinfo;

if (cd.numberoftracks < 1)
{
gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(panel.permision_toggle), 0);
return;
}


playinfo = getplaydata(0);


// find our track

while (playinfo->abslocation > cd.track[i].trackend)
i++;

if (GTK_TOGGLE_BUTTON (widget)->active) 
    cd.track[i].permission = 1;
   else 
     cd.track[i].permission = 0;
}

void emphasis_callback (GtkWidget * widget)
{
int i = 0;
play_file *playinfo;

// find our track

if (cd.numberoftracks < 1)
{
gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(panel.emphasis_toggle), 0);
return;
}


playinfo = getplaydata(0);

while (playinfo->abslocation > cd.track[i].trackend)
i++;



if (GTK_TOGGLE_BUTTON (widget)->active)
    cd.track[i].emphasis = 1;
   else
     cd.track[i].emphasis = 0;
}

void fourchannel_callback (GtkWidget * widget)
{
int i = 0;
play_file *playinfo;


if (cd.numberoftracks < 1)
{
gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(panel.fourchannel_toggle), 0);
return;
}

playinfo = getplaydata(0);

// find our track

while (playinfo->abslocation > cd.track[i].trackend)
i++;


if (GTK_TOGGLE_BUTTON (widget)->active)
    cd.track[i].fourchannel = 1;
   else
     cd.track[i].fourchannel = 0;
}


void wave_update_callback (GtkWidget * widget)
{
if (cd.numberoftracks < 1)
{
gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(panel.wave_update_toggle), 0);
return;
}


if (GTK_TOGGLE_BUTTON (widget)->active)
   audio.wave_update = 1;
   else
   audio.wave_update = 0;

}

void set_gap (GtkWidget * widget)
{                                            
GtkWidget *button;
GtkWidget *label; 
static GtkWidget *dialog_window = NULL;
char buffer[10];
static int i[2], j[2];
play_file *playinfo;

if (cd.numberoftracks < 1)
return;

j[0]=i[0]=0;
i[1]=0;
j[1]=1;


/*

while (playinfo->abslocation > cd.gap[g].gapend && cd.numberofgaps>(g+1))
g++;

if (cd.numberofgaps == 0 || cd.gap[g].gapend < cd.track[i].trackstart)
{
//this gap is not in our track, so there is no gap for this track
}

*/

// find our track

if (af!=0)
{

playinfo = getplaydata(0);

while (playinfo->abslocation > cd.track[i[0]].trackend)
i[0]++;
}
j[0]=i[0];

if (cd.track[i[0]].tracknum == 0)
return;

dialog_window = gtk_dialog_new();
                                 
gtk_window_position (GTK_WINDOW (dialog_window), GTK_WIN_POS_NONE);
                                                                   
gtk_signal_connect (GTK_OBJECT (dialog_window), "destroy",
                   (GtkSignalFunc) destroy_window, &dialog_window);
gtk_signal_connect (GTK_OBJECT (dialog_window), "delete_event",
                    (GtkSignalFunc) destroy_window, &dialog_window);

                                                                   
gtk_window_set_title (GTK_WINDOW (dialog_window), "Set Gap");
gtk_container_border_width (GTK_CONTAINER (dialog_window), 10);

button = gtk_button_new_with_label ("OK");

gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   (GtkSignalFunc) gtk_widget_destroy,    
                          GTK_OBJECT(dialog_window));
                                                     
GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->action_area),
                          button, TRUE, TRUE, 0);
gtk_widget_grab_default (button);                
gtk_widget_show (button);         



sprintf(buffer,"Gap for Track %d",cd.track[i[0]].tracknum);
label = gtk_label_new (buffer);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox),
                          label, TRUE, TRUE, 0);               
gtk_widget_show (label);                        


                        
                                    
if (!GTK_WIDGET_VISIBLE (dialog_window))
    gtk_widget_show (dialog_window); 
else                                   
    gtk_widget_destroy (dialog_window);

}



void about_cmd_callback (GtkWidget * widget)
{
GtkWidget *button;
GtkWidget *label;
static GtkWidget *dialog_window = NULL;

dialog_window = gtk_dialog_new();

gtk_window_position (GTK_WINDOW (dialog_window), GTK_WIN_POS_CENTER);

gtk_signal_connect (GTK_OBJECT (dialog_window), "destroy",
                   (GtkSignalFunc) destroy_window, &dialog_window);
gtk_signal_connect (GTK_OBJECT (dialog_window), "delete_event",
                   (GtkSignalFunc) destroy_window, &dialog_window);

gtk_window_set_title (GTK_WINDOW (dialog_window), "About");
gtk_container_border_width (GTK_CONTAINER (dialog_window), 0);

button = gtk_button_new_with_label ("OK");

gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   (GtkSignalFunc) gtk_widget_destroy,
                          GTK_OBJECT(dialog_window));

GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->action_area),
                          button, TRUE, TRUE, 0);
gtk_widget_grab_default (button); 
gtk_widget_show (button);

label = gtk_label_new ("CD Builder\nV0.07\nBy Bryan Chafy\n1998");
gtk_misc_set_padding (GTK_MISC (label), 10, 10);
gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog_window)->vbox),
                          label, TRUE, TRUE, 0);
gtk_widget_show (label);

if (!GTK_WIDGET_VISIBLE (dialog_window))
    gtk_widget_show (dialog_window); 
else                                   
    gtk_widget_destroy (dialog_window);

}

void 
set_index (GtkWidget *widget)
{
int i=0,j=0,g=0,p=0,loc;
play_file *playinfo;

if (cd.numberoftracks < 1)
return;

playinfo = getplaydata(0);
loc=playinfo->abslocation;

// find our track

while (loc > cd.track[i].trackend)
i++;

if (cd.track[i].numberofindexes >= 99)
return;

// find our index

while (loc > cd.track[i].index[j].indexend)
j++;

//test this also 

//check if in a gap.

while (playinfo->abslocation > cd.gap[g].gapend && cd.numberofgaps>(g+1))
g++;

if (loc < cd.gap[g].gapend && loc >= cd.gap[g].gapstart)
return;

if (cd.track[i].index[j+1].indexnum != 0)
{
for (p=cd.track[i].numberofindexes; p>j; p--)
{
memcpy(&cd.track[i].index[p],&cd.track[i].index[p-1], sizeof(index_type));
cd.track[i].index[p].indexnum++;
}
}

cd.track[i].index[j+1].indexend = cd.track[i].index[j].indexend;
cd.track[i].index[j].indexend = loc;
cd.track[i].index[j+1].indexstart = loc;
cd.track[i].index[j+1].indexnum = cd.track[i].index[j].indexnum + 1;
cd.track[i].numberofindexes++;
}

void
set_track (GtkWidget *widget)
{
int i=0,p=0;
play_file *playinfo;
int loc;

if (cd.numberoftracks >= 99 || cd.numberoftracks < 1)
return;

playinfo = getplaydata(0);
loc=playinfo->abslocation;

// find our track

while (playinfo->abslocation > cd.track[i].trackend)
i++;


if (cd.track[i+1].tracknum != 0)
{
for (p=cd.numberoftracks; p>i; p--)
{
memcpy(&cd.track[p],&cd.track[p-1], sizeof(track_type));
cd.track[p].tracknum++;
}
}

cd.track[i+1].trackend = cd.track[i].trackend;
cd.track[i].trackend = loc;
cd.track[i+1].trackstart = loc;
cd.track[i+1].tracknum = cd.track[i].tracknum + 1;
cd.numberoftracks++;

//for now, no gap and 1 index
cd.track[i+1].index[0].indexstart=cd.track[i+1].trackstart;
cd.track[i+1].index[0].indexend=cd.track[i+1].trackend;
cd.track[i+1].index[0].indexnum=1;
cd.track[i+1].numberofindexes=1;
cd.track[i+1].permission=0;
}

void
unset_track (GtkWidget *widget)
{

if (cd.numberoftracks <= 1)
return;

}

void 
unset_index (GtkWidget *widget)
{
int i=0,j=0,g=0,p=0,loc;
play_file *playinfo;

if (cd.numberoftracks < 1)
return;

playinfo = getplaydata(0);
loc=playinfo->abslocation;

// find our track

while (loc > cd.track[i].trackend)
i++;

if (cd.track[i].numberofindexes <= 1)
return;

// find our index

while (loc > cd.track[i].index[j].indexend)
j++;

if (cd.track[i].numberofindexes<2)  // must be at least 2 indexes
return;

//test this also 

//check if in a gap.

while (playinfo->abslocation > cd.gap[g].gapend && cd.numberofgaps>(g+1))
g++;

if (loc < cd.gap[g].gapend && loc >= cd.gap[g].gapstart)
return;

if (cd.track[i].index[j+1].indexnum != 0)
{
cd.track[i].index[j+1].indexstart = cd.track[i].index[j].indexstart;

for (p=j; p<cd.track[i].numberofindexes-1; p++)
{
memcpy(&cd.track[i].index[p],&cd.track[i].index[p+1], sizeof(index_type));
cd.track[i].index[p].indexnum--;
}

p = cd.track[i].numberofindexes-1;
cd.track[i].index[p].indexnum = cd.track[i].index[p].indexstart = cd.track[i].index[p].indexend = 0;

}
else
cd.track[i].index[j].indexnum = cd.track[i].index[j].indexstart = cd.track[i].index[j].indexend = 0;

cd.track[i].numberofindexes--;
}



void
advanced_callback (GtkWidget *widget)
{

}


static play_file *playinfo;
static GdkFont *font;

int updateit()
{
static int val;
static int stor=0;
static gchar buffer[10];
static gchar totalbuffer[10];
static gchar buff2[10];
static gchar ibuff[10],tbuff[10],totaltbuff[10],totalibuff[10];
static int current_min, current_second;

static int g=0, i=0, j=0;
static int mytrack, myindex;
static int gapval=0, gaptimeval;
static int fnum = 0;

if (!stats2) {
g=i=j=mytrack=myindex=0;
stats2=1;
return 1;
}

// find our track

while (playinfo->abslocation > cd.track[i].trackend)
i++;

// find our index

while (playinfo->abslocation > cd.track[i].index[j].indexend)
j++;


// find gap end (its just greater than our current location)

while (cd.gap[g].gapend <= playinfo->abslocation && cd.numberofgaps-1 > g)
g++;



// update the display of track/index

if (mytrack != cd.track[i].tracknum)
{
mytrack = cd.track[i].tracknum;
sprintf(tbuff,"%d",mytrack);
gtk_label_set (GTK_LABEL (panel.track), tbuff);

sprintf(totaltbuff,"%d",cd.numberoftracks);
gtk_label_set (GTK_LABEL (panel.totaltrack), totaltbuff);

// panel.fine_adjustment -> upper = (gfloat) (cd.track[i].trackend - cd.track[i].trackstart);
// gtk_adjustment_set_value(panel.fine_adjustment,0);

sprintf(totaltbuff,"%2d:%02d",(cd.track[i].trackend - cd.track[i].trackstart)/CDAMIN,(cd.track[i].trackend - cd.track[i].trackstart/CDASEC)%60);
gtk_label_set (GTK_LABEL(panel.track_time), totaltbuff);  

sprintf(totalibuff,"%d",cd.track[i].numberofindexes);
gtk_label_set (GTK_LABEL (panel.totalindex), totalibuff);

gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(panel.permision_toggle), cd.track[i].permission);
gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(panel.emphasis_toggle), cd.track[i].emphasis);
gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(panel.fourchannel_toggle), cd.track[i].fourchannel);
}

if (myindex != cd.track[i].index[j].indexnum)
{
myindex = cd.track[i].index[j].indexnum;
sprintf(ibuff,"%d",myindex);
gtk_label_set (GTK_LABEL (panel.index), ibuff);

}




// we are in a gap

if (playinfo->abslocation < cd.gap[g].gapend && playinfo->abslocation >= cd.gap[g].gapstart)
{

gtk_list_unselect_item (GTK_LIST(cb->list), fnum);
fnum = -1;

gapval += SECTOR;
gaptimeval =  cd.gap[g].gapsize - gapval;

playinfo->abslocation += SECTOR;

// play silence

if (audioplay(1) == -1)
{
stopit(NULL);
return 0;
}

current_min = (gaptimeval+CDASEC)/CDAMIN;
current_second = ((gaptimeval+CDASEC)/CDASEC)%60;

// gtk_adjustment_set_value(panel.fine_adjustment,playinfo->abslocation - cd.track[i].trackstart);

wave_set_cursor(playinfo->abslocation/SECTOR);

// blocks

gdk_draw_string (GTK_WIDGET (block_darea)->window, font,
GTK_WIDGET (block_darea)->style->bg_gc[0], 10, 10, buff2);

 sprintf(buff2,"%lo", playinfo->abslocation/SECTOR);

gdk_draw_string (GTK_WIDGET (block_darea)->window, font,
GTK_WIDGET (block_darea)->style->black_gc, 10, 10, buff2);

if (stor != ((gaptimeval+CDASEC)/CDASEC)%60 ) {
// gtk_adjustment_set_value(panel.adjustment,cd.gap[g].gapstart + gapval);

// track time

 gdk_draw_string (GTK_WIDGET (time_darea)->window, font,
 GTK_WIDGET (time_darea)->style->bg_gc[0], 10, 10, buffer);

sprintf(buffer,"-%2d:%02d",current_min, current_second);

 gdk_draw_string (GTK_WIDGET (time_darea)->window, font,
 GTK_WIDGET (time_darea)->style->black_gc, 10, 10, buffer);


// time remain


 gdk_draw_string (GTK_WIDGET (ttime_darea)->window, font,
 GTK_WIDGET (ttime_darea)->style->bg_gc[0], 10, 10, totalbuffer);

sprintf(totalbuffer,"%02d:%02d", (int)playinfo->abslocation/CDAMIN, (int)(playinfo->abslocation/CDASEC)%60);

 gdk_draw_string (GTK_WIDGET (ttime_darea)->window, font,
 GTK_WIDGET (ttime_darea)->style->black_gc, 10, 10, totalbuffer);


stor = current_second;
}

return 1;
}
else
{
gapval = 0;
}




// normal audio play


val = audioplay(0);

if (val == -1)
{

stopit(NULL);
return 0;

}



// update our list of tracks selection
if (fnum != playinfo->filenum)
{
fnum = playinfo->filenum;
gtk_list_select_item(GTK_LIST(cb->list), fnum);
}

playinfo->abslocation = val+cd.file[fnum].filestart;



/* faster system */
// gtk_adjustment_set_value(panel.fine_adjustment,playinfo->abslocation-cd.track[i].trackstart);


/* wave window update */
wave_set_cursor(playinfo->abslocation/SECTOR);

current_min = ((playinfo->abslocation - cd.track[i].index[0].indexstart)/CDAMIN);
current_second = ((playinfo->abslocation - cd.track[i].index[0].indexstart)/CDASEC)%60;

// blocks
gdk_draw_string (GTK_WIDGET (block_darea)->window, font,
GTK_WIDGET (block_darea)->style->bg_gc[0], 10, 10, buff2);

 sprintf(buff2,"%lo",playinfo->abslocation/SECTOR);

gdk_draw_string (GTK_WIDGET (block_darea)->window, font,
GTK_WIDGET (block_darea)->style->black_gc, 10, 10, buff2);




// updates for each second

if (stor != current_second) {

// gtk_adjustment_set_value(panel.adjustment,playinfo->abslocation);

/* slower system */
// gtk_adjustment_set_value(panel.fine_adjustment,playinfo->abslocation-cd.track[i].trackstart);

// track time

 gdk_draw_string (GTK_WIDGET (time_darea)->window, font,
 GTK_WIDGET (time_darea)->style->bg_gc[0], 10, 10, buffer);
sprintf(buffer,"%2d:%02d",current_min, current_second);

 gdk_draw_string (GTK_WIDGET (time_darea)->window, font,
 GTK_WIDGET (time_darea)->style->black_gc, 10, 10, buffer);

// time remain

 gdk_draw_string (GTK_WIDGET (ttime_darea)->window, font,
 GTK_WIDGET (ttime_darea)->style->bg_gc[0], 10, 10, totalbuffer);

sprintf(totalbuffer,"%02d:%02d", (int)playinfo->abslocation/CDAMIN, (int)(playinfo->abslocation/CDASEC)%60);

 gdk_draw_string (GTK_WIDGET (ttime_darea)->window, font,
 GTK_WIDGET (ttime_darea)->style->black_gc, 10, 10, totalbuffer);

stor = current_second;
}

return 1;
}


// ADJUSTMENT

void
fine_adjust(GtkWidget *widget, int x, int status)
{

/* testit */

int j=0,g=0,i=0;
static int paused=0;

if (!af)
return;


if (status)
{
if (mytag) {

gtk_idle_remove(mytag);
mytag=0;
paused = 0;
return;
}
else
paused = 1;
}
else
{

while (playinfo->abslocation > cd.track[i].trackend)
i++;

panel.adjustment->value = panel.fine_adjustment->value + cd.track[i].trackstart;

while (cd.file[j].fileend <= panel.adjustment->value && cd.numberoffiles-1 > j)
j++;

while (panel.adjustment->value > cd.gap[g].gapend && cd.numberofgaps>(g+1))
g++;

panel.adjustment->value -= ((int)panel.adjustment->value %2352);


if (panel.adjustment->value < cd.gap[g].gapend && panel.adjustment->value >= cd.gap[g].gapstart)
panel.adjustment->value = cd.file[j].filestart;

playinfo->abslocation=panel.adjustment->value;

if ( (int) ((int)panel.adjustment->value - (int)cd.file[j].filestart) < 0)
{
printf ("%d\n", j);
playcommand(2, j, 0);
}
else
{
printf ("%d %d %d\n", j, (int)panel.adjustment->value - (int)cd.file[j].filestart , (int)cd.file[j].fileend);
playcommand(2, j, panel.adjustment->value - cd.file[j].filestart);
}


stats2 = 0;

if (!paused)
mytag = gtk_idle_add(updateit,NULL);
else
gtk_adjustment_set_value(panel.adjustment,playinfo->abslocation);

}


}


void
adjust(GtkWidget *widget, int x, int status)
{
int i=0,j=0,g=0;
static int paused = 0;

if (!af)
return;

if (status)
{
if (mytag) {
           
gtk_idle_remove(mytag);
mytag=0;   
paused = 0;                                                               
return; 
}
else
paused = 1;
}
else
{
while (cd.file[j].fileend <= x)
j++;

while (x > cd.gap[g].gapend && cd.numberofgaps>(g+1))
g++;

x -= (x %2);

if (x < cd.gap[g].gapend && x >= cd.gap[g].gapstart)
x = cd.file[j].filestart;


playinfo->abslocation=x;
playcommand(2, j, x - cd.file[j].filestart);

stats2 = 0;

if (!paused)
mytag = gtk_idle_add(updateit,NULL);
else
{
while (playinfo->abslocation > cd.track[i].trackend)
i++;
/* panel.fine_adjustment -> upper = cd.track[i].trackend - cd.track[i].trackstart;
gtk_adjustment_set_value(panel.fine_adjustment,playinfo->abslocation - cd.track[i].trackstart);
*/
}


}      

}


void 
playit (GtkWidget *widget)
{
static char buff[32];
static int setonce=0;


if(!cd.numberoffiles) {
sprintf(buff,"ERROR: No files to process");
gtk_label_set (GTK_LABEL (status_display), buff);
return;
}

if (mytag) {

stats2 = 0;

gtk_idle_remove(mytag);
gtk_label_set (GTK_LABEL (status_display), "  Paused                   ");
mytag=0;
return;
}


sprintf(buff,"  Playing                   ");
gtk_label_set (GTK_LABEL (status_display), buff);

if (!af){
playcommand(1,0,0);
readaudiofile();
af=1;
}


if (!setonce) {
setonce = 1;
playinfo = getplaydata(0);
font = GTK_WIDGET (block_darea)->style->font;
}

mytag = gtk_idle_add(updateit,NULL);

}

void
stopit (GtkWidget *widget)
{

if (playinfo)
playinfo->abslocation=0;

stats2=0;

if (mytag) {
gtk_idle_remove(mytag);
mytag = 0;
}
else
return;

if (audio.pid)
playcommand(2,0,0);
else 
return;

gtk_label_set (GTK_LABEL (status_display), "  Stopped                  ");
// gtk_adjustment_set_value(panel.adjustment,0);
// gtk_adjustment_set_value(panel.fine_adjustment,0);

}

void
fwdit (GtkWidget *widget)
{
int i=0,j=0;

if (!af)
return;

// find our track
while (playinfo->abslocation > cd.track[i].trackend)
i++;

i++;

if (i >= cd.numberoftracks)
return;


// find our file

while (cd.file[j].fileend <= cd.track[i].trackstart)
j++;


if (cd.track[i].trackstart-cd.file[j].filestart < 0)
playcommand(2, j, 0);
else
playcommand(2, j, cd.track[i].trackstart-cd.file[j].filestart);

playinfo->abslocation=cd.file[j].filestart;

stats2=0;

}

void
backit (GtkWidget *widget)
{

int i=0,j=0;

if (!af)
return;

// find our track
while (playinfo->abslocation > cd.track[i].trackend)
i++;

i--;

if (i<0)
return;


// find our file

while (cd.file[j].fileend <= cd.track[i].trackstart)
j++;


if (cd.track[i].trackstart-cd.file[j].filestart < 0)
playcommand(2, j, 0);
else
playcommand(2, j, cd.track[i].trackstart-cd.file[j].filestart);

playinfo->abslocation=cd.file[j].filestart;

stats2=0;

}




void
destroy_window (GtkWidget  *widget,
                GtkWidget **window)
{
  *window = NULL;  
}

int setup_files(char* filename, int auto_tracks, int auto_gaps)
{
int filesize;
int totalsize, indexstart;
int i,j,k;
int current;

j=cd.numberofgaps;   
i=cd.numberoffiles;
k=cd.numberoftracks;

cd.numberoffiles++;
totalsize = cd.totaldatasize;

filesize = initfile(filename);
cd.file[i].filesize = filesize;
cd.file[i].filename = strdup(filename);


if (auto_gaps)
{
cd.gap[j].gapsize = (CDASEC*2);
cd.gap[j].gapstart = cd.totaldatasize;
cd.totaldatasize+=(CDASEC*2);
cd.gap[j].gapend = cd.totaldatasize;
cd.numberofgaps++;

wave_set_gap(cd.gap[j].gapstart,cd.gap[j].gapend);
}

cd.file[i].filestart = cd.totaldatasize;
indexstart = cd.totaldatasize;
cd.totaldatasize+=filesize;
cd.file[i].fileend = cd.totaldatasize;

scanwave(cd.file[i].filename,0,cd.file[i].filesize,cd.file[i].filestart);

if (auto_tracks)
{
cd.track[k].tracknum = cd.numberoffiles;
cd.track[k].trackstart = totalsize;

cd.track[k].numberofindexes=1;
cd.track[k].index[0].indexnum=1;
cd.track[k].index[0].indexstart=indexstart;

cd.track[k].trackend = cd.totaldatasize;

cd.track[k].index[0].indexend=cd.track[k].trackend;

cd.numberoftracks++;
}
else
{

/* no auto_tracks, so assign the whole of the data to a single track 1 */

cd.numberoftracks=1;
cd.track[0].tracknum = 1;
cd.track[0].trackstart = cd.file[0].filestart;
cd.track[0].numberofindexes=1;
cd.track[0].index[0].indexnum=1;
cd.track[0].index[0].indexstart= cd.track[0].trackstart;

cd.track[0].trackend = cd.track[0].index[0].indexend = cd.totaldatasize;

}

cd.totalsector=(cd.totaldatasize/SECTOR);

/*
current = panel.adjustment -> value;
panel.adjustment -> upper = (gfloat)cd.totaldatasize;
if (current)
gtk_adjustment_set_value(panel.adjustment,0);
else
gtk_adjustment_set_value(panel.adjustment,1);
gtk_adjustment_set_value(panel.adjustment,current);
*/

return (0);
}


  /* Get the selected filename and print it to the console */
void file_ok_sel (GtkWidget *w, GtkWidget *fs)
{
gchar buffer[64];
GList *files_list=NULL;
GtkWidget *list_item;
int i=0, j=0, k=0;

/* clear out main list */
gtk_list_select_item( GTK_LIST (cb->list), 0);
while(GTK_LIST (cb->list) -> selection){
gtk_list_remove_items (GTK_LIST (cb->list), GTK_LIST(cb->list) -> selection);
gtk_list_select_item( GTK_LIST (cb->list), 0);
}

// gtk_combo_set_popdown_strings (GTK_COMBO(cb), files_list);                  

/* clear out data structures */
cd.numberoffiles = cd.numberoftracks = cd.totaldatasize = cd.numberofgaps = cd.totalsector = 0;


for(j=0;j<1000;j++) {
 cd.file[j].filestart = cd.file[j].fileend = cd.file[j].filesize = 0;
 cd.gap[j].gapstart = cd.gap[j].gapend = cd.gap[j].gapsize = 0;
}

for(j=0;j<99;j++) {
  cd.track[j].trackstart = cd.track[j].trackend = cd.track[j].tracknum = cd.track[j].permission = cd.track[j].numberofindexes = 0;

  for(k=0;k<99;k++)
   cd.track[j].index[k].indexnum = cd.track[j].index[k].indexstart = cd.track[j].index[k].indexend = 0;
}

wave_init();



/* printf("ITEMS ARE:\n"); */



gtk_list_select_item( GTK_LIST (GTK_FILE_ADD(fs)->added_list), 0);
while(GTK_LIST(GTK_FILE_ADD(fs)->added_list) -> selection)
{
/* printf("%s \n", (gchar*)gtk_object_get_user_data(GTK_LIST(GTK_FILE_ADD(fs)->added_list)->selection->data)); */
sprintf(buffer, "%s", (gchar*)gtk_object_get_user_data(GTK_LIST(GTK_FILE_ADD(fs)->added_list)->selection->data));
files_list = g_list_append (files_list, g_strdup(buffer));

setup_files(buffer, GTK_TOGGLE_BUTTON(GTK_FILE_ADD(fs)->tracks)->active, GTK_TOGGLE_BUTTON(GTK_FILE_ADD(fs)->gaps)->active);

list_item = gtk_list_item_new_with_label (buffer);
gtk_object_set_user_data (GTK_OBJECT (list_item), files_list->data);
// gtk_container_add (GTK_CONTAINER (list), list_item);
gtk_widget_show (list_item);

gtk_list_unselect_item (GTK_LIST (GTK_FILE_ADD(fs)->added_list), i);
i++;
gtk_list_select_item(GTK_LIST (GTK_FILE_ADD(fs)->added_list), i);
}

gtk_combo_set_popdown_strings (GTK_COMBO(cb), files_list);                  

/* gtk_list_remove_items (GTK_LIST (GTK_FILE_ADD(fs)->added_list), GTK_LIST(GTK_FILE_ADD(fs)->added_list) -> selection); */

gtk_widget_destroy(fs);

sprintf(buffer,"%d", cd.totaldatasize/2352);
gtk_label_set (GTK_LABEL(panel.block), buffer);
sprintf(buffer,"%d", cd.numberoftracks);
gtk_label_set (GTK_LABEL(panel.totaltrack), buffer);
sprintf(buffer,"%2d:%02d",(cd.totaldatasize/CDASEC)/60,(cd.totaldatasize/CDASEC)%60);
gtk_label_set (GTK_LABEL(panel.total_time), buffer);


/* stop audio play for this session  */

stopit(NULL);

if (audio.pid>0) {
playcommand(-1,0,0);
af=0;
}

}


void file_add_sel (GtkWidget *w, GtkWidget *fs)
{
gchar buffer[64];
GtkWidget *list_item;
GList *files_list = NULL;
int bytes;

sprintf (buffer, "%s", gtk_file_add_get_filename (GTK_FILE_ADD (fs)) );

bytes = filesize(buffer);
if (bytes) {
cddraw(fs,NULL,(gpointer)(bytes/CDAMIN));
files_list = g_list_prepend (files_list, g_strdup(buffer));
list_item = gtk_list_item_new_with_label (buffer);
gtk_object_set_user_data (GTK_OBJECT (list_item), files_list->data);
gtk_container_add (GTK_CONTAINER (GTK_FILE_ADD(fs)->added_list), list_item);
gtk_widget_show (list_item);
}
}


void file_rem_sel (GtkWidget *w, GtkWidget *f)
{
GList *items;
gchar buffer[64];
int bytes;
static GtkFileAdd *fs;

fs=GTK_FILE_ADD(f);

items= GTK_LIST(fs->added_list) -> selection;

while(items){
  if (GTK_IS_LIST_ITEM(items->data))
        sprintf(buffer, "%s", (char *)gtk_object_get_user_data(items->data));

	bytes = filesize(buffer);
	if (bytes)
	  cddraw(f,NULL,(gpointer)(-bytes/CDAMIN));

        items=items->next;
             }

gtk_list_remove_items (GTK_LIST (fs->added_list), GTK_LIST(fs->added_list) -> selection);
/*g_list_free(items); */

}

void 
files_cmd_callback (GtkWidget *widget)
{
static GtkWidget *filew;
GtkWidget *list_item;
gchar buffer[64];
int i=0;


/* Create a new file selection widget */
filew = gtk_file_add_new ("Add/Remove Files");

      gtk_window_position (GTK_WINDOW (filew), GTK_WIN_POS_MOUSE);

          gtk_signal_connect (GTK_OBJECT (filew), "destroy",
                              (GtkSignalFunc) destroy_window, &filew);

          gtk_signal_connect (GTK_OBJECT (filew), "delete_event",
                              (GtkSignalFunc) destroy_window, &filew);

          /* Connect the add_button to file_add_sel function */
          gtk_signal_connect (GTK_OBJECT (GTK_FILE_ADD (filew)->add_button),
                              "clicked", (GtkSignalFunc) file_add_sel, filew );

          gtk_signal_connect (GTK_OBJECT (GTK_FILE_ADD (filew)->remove_button),
                              "clicked", (GtkSignalFunc) file_rem_sel, filew );

          gtk_signal_connect (GTK_OBJECT (GTK_FILE_ADD (filew)->ok_button),
                              "clicked", (GtkSignalFunc) file_ok_sel, filew );

          /* Connect the cancel_button to destroy the widget */
          gtk_signal_connect_object (GTK_OBJECT (GTK_FILE_ADD (filew)->cancel_button),
                               "clicked", (GtkSignalFunc) gtk_widget_destroy,
                                     GTK_OBJECT (filew));

gtk_list_select_item(GTK_LIST (cb->list), 0);
while(GTK_LIST(cb->list) -> selection)
{
sprintf(buffer, "%s", gtk_entry_get_text(GTK_ENTRY(cb->entry)));

// sprintf(buffer, "%s", (gchar*)gtk_object_get_user_data(li));

printf("%s\n",buffer);

files_list = g_list_prepend (files_list, g_strdup(buffer));
list_item = gtk_list_item_new_with_label (buffer);
gtk_object_set_user_data (GTK_OBJECT (list_item), files_list->data);
gtk_container_add (GTK_CONTAINER (GTK_FILE_ADD(filew)->added_list), list_item);
gtk_widget_show (list_item);
gtk_list_unselect_item (GTK_LIST (cb->list), i);
i++;
gtk_list_select_item(GTK_LIST (cb->list), i);
}


          gtk_widget_show(filew);  
}

void generate_cuesheet(GtkWidget *w)
{
FILE *fp;
int sector=0, i=0;
int idx=0, gapidx=0;
static char buff[32];

if(!cd.numberoffiles) {
sprintf(buff,"ERROR: No files to process");
gtk_label_set (GTK_LABEL (status_display), buff);
return;
}


fp = fopen ("cue_sheet", "w+");

if (fp == NULL)
{
printf("error creating cue_sheet\n");
}

/* 
   For dataform byte:

7 6   5 4 3 2 1 0
 Y    ------------ Data form of main data
 +---------------- Data form of subchannel

For CDDA, data form of main data is:
  00h for 2352 bytes of data
  01h for 2352 bytes of 0's

Subchannel data form is:

78
--
00 for 96 bytes of 0's *
01 for 96 bytes of raw data 
11 for 24*4 bytespack data

* The spec states P and Q subchannel contained within the subcode data
  shall be ignored.  P and Q subchannel info is generated by the drive and
  based on the content of the cue sheet.

*/


/* leadin entry */
cue_sheet.ctladr = 0x01;
cue_sheet.tno = 0;
cue_sheet.index = 0;
cue_sheet.dataform = 0x01;  /* all vales set per x3t10-1048d cue sheet */
cue_sheet.scms = 0;
cue_sheet.min = 0;
cue_sheet.sec = 0;
cue_sheet.frac = 0;

fputc(cue_sheet.ctladr,fp);
fputc(cue_sheet.tno,fp);
fputc(cue_sheet.index,fp);
fputc(cue_sheet.dataform,fp);
fputc(cue_sheet.scms,fp);
fputc(cue_sheet.min,fp);
fputc(cue_sheet.sec,fp);
fputc(cue_sheet.frac,fp);


/* data entries */

for (i=0;i<cd.numberoftracks;i++)
{
cue_sheet.ctladr = 0;
cue_sheet.tno = 0;      
cue_sheet.index = 0;
cue_sheet.dataform = 0;
cue_sheet.scms = 0;                                                      
cue_sheet.min = 0; 
cue_sheet.sec = 0;
cue_sheet.frac = 0;

idx=0;

while(sector<cd.track[i].trackend)
 {

 if (cd.gap[gapidx].gapend <= sector && (gapidx+1)<cd.numberofgaps) 
  gapidx++;

 if (cd.gap[gapidx].gapstart <= sector && cd.gap[gapidx].gapend > sector)
  {
        /* we are in a gap, only write it once per encounter */

    if (cd.gap[gapidx].gapstart == sector) {
        cue_sheet.ctladr = 0x01;
        cue_sheet.tno = cd.track[i].tracknum;
        cue_sheet.index = 0;
        cue_sheet.dataform = 0;  /* 0's forsubcode data, 2352 bytes */
        cue_sheet.scms = 0;                                                     
        cue_sheet.min = (cd.gap[gapidx].gapstart/CDASEC)/60;
        cue_sheet.sec = (cd.gap[gapidx].gapstart/CDASEC)%60;
        cue_sheet.frac = (cd.gap[gapidx].gapstart/SECTOR)%75;

        fputc(cue_sheet.ctladr,fp);
        fputc(cue_sheet.tno,fp);   
        fputc(cue_sheet.index,fp);
        fputc(cue_sheet.dataform,fp);
        fputc(cue_sheet.scms,fp);    
        fputc(cue_sheet.min,fp); 
        fputc(cue_sheet.sec,fp);
        fputc(cue_sheet.frac,fp);
/* printf("gapend=%d\n",cd.gap[gapidx].gapend);    */
        }
  }
 else
  {
/* printf("track=%d index=%d indexnumbs=%d sector=%d indexend=%d indexstart=%d\n",cd.track[i].tracknum,idx,cd.track[i].numberofindexes,sector,cd.track[i].index[idx].indexend,cd.track[i].index[idx].indexstart);
*/

  if (cd.track[i].index[idx].indexend <= sector && (idx+1)<cd.track[i].numberofindexes) 
       idx++;

  /* we are in a track, write out index starts */

  if (cd.track[i].index[idx].indexstart == sector) {

        cue_sheet.ctladr = 0x01;
        cue_sheet.tno = cd.track[i].tracknum;
        cue_sheet.index = cd.track[i].index[idx].indexnum;
        cue_sheet.dataform = 0;  /* 0's forsubcode data, 2352 bytes */
        cue_sheet.scms = 0;                                                     
        cue_sheet.min = (cd.track[i].index[idx].indexstart/CDASEC)/60;
        cue_sheet.sec = (cd.track[i].index[idx].indexstart/CDASEC)%60;
        cue_sheet.frac = (cd.track[i].index[idx].indexstart/SECTOR)%75;

        fputc(cue_sheet.ctladr,fp);
        fputc(cue_sheet.tno,fp);   
        fputc(cue_sheet.index,fp);
        fputc(cue_sheet.dataform,fp);
        fputc(cue_sheet.scms,fp);    
        fputc(cue_sheet.min,fp); 
        fputc(cue_sheet.sec,fp);
        fputc(cue_sheet.frac,fp);
/* printf("newidx\n");  */
        }
  }
sector+=SECTOR;
 }
}



/* leadout entry */
cue_sheet.ctladr = 0x01;
cue_sheet.tno = 0xAA;      
cue_sheet.index = 0x01;
cue_sheet.dataform = 0x01;  /* all vales set per x3t10-1048d cue sheet */
cue_sheet.scms = 0;                                                      
cue_sheet.min = (cd.totaldatasize/CDASEC)/60; 
cue_sheet.sec = (cd.totaldatasize/CDASEC)%60;
cue_sheet.frac =(cd.totaldatasize/SECTOR)%75;
                   
fputc(cue_sheet.ctladr,fp);
fputc(cue_sheet.tno,fp);   
fputc(cue_sheet.index,fp);
fputc(cue_sheet.dataform,fp);
fputc(cue_sheet.scms,fp);
fputc(cue_sheet.min,fp);
fputc(cue_sheet.sec,fp);
fputc(cue_sheet.frac,fp);

fclose(fp);

gtk_label_set (GTK_LABEL (status_display), " Done                ");
}


void generate_subcodes (GtkWidget *widget)
{
FILE *fp;
static char buff[32];

if(!cd.numberoffiles) {
sprintf(buff,"ERROR: No files to process");
gtk_label_set (GTK_LABEL (status_display), buff);
return;
}

fp = fopen ("subcodes.sub", "w+");

if (fp == NULL)
{
printf("error creating subcodes.sub\n");
}

sprintf(buff,"Generating Leadin... ");
gtk_label_set (GTK_LABEL (status_display), buff);
leadin(fp);

sprintf(buff," Generating Data...  ");
gtk_label_set (GTK_LABEL (status_display), buff);
data(fp);

sprintf(buff," Generating Leadout  ");
gtk_label_set (GTK_LABEL (status_display), buff);
leadout(fp);

fclose(fp);
sprintf(buff," Done                   ");
gtk_label_set (GTK_LABEL (status_display), buff);
}

void generate_rawimage()
{}

void split_tracks()
{}

int leadout(FILE *fp)
{
channel data;
int i,j,k;
int idx=0;
int sector, finishsector;
int abstimecount=0;
int tracktimecount=0;
unsigned char hz[900];
unsigned short crccode;

for(j=0;j<4;j++)
for(i=0;i<225;i++)
hz[i+(225*j)]=(j%2)*0xFF;


sector=cd.totaldatasize + SECTOR;
finishsector = (sector + CDASEC*3);
abstimecount=cd.totalsector + 1;

for(k=0;k<12;k++)
 {
 data.p[k] = 0;
 data.q[k] = 0;
 data.r[k] = 0;
 data.s[k] = 0;
 data.t[k] = 0;
 data.u[k] = 0;
 data.v[k] = 0;
 data.w[k] = 0;
 }

data.q[0] = 0x41;   /* 0100 , no pre-emph, copy OK, x, stereo | mode1 */
data.q[1] = 0xAA;   /* AA leadout track */
data.q[2] = bcd(1); /* always 1 for leadout */

while(sector<=finishsector)
{
  for(k=0;k<12;k++){    
     idx+=k;
     data.p[k] = hz[idx%900];  /* for p channel, set to 2 hz  */
}

  data.q[3] = bcd((tracktimecount/75)/60);
  data.q[4] = bcd((tracktimecount/75)%60);
  data.q[5] = bcd(tracktimecount%75);

  data.q[7] = bcd((abstimecount/75)/60);
  data.q[8] = bcd((abstimecount/75)%60);
  data.q[9] = bcd(abstimecount%75);

  crccode = crc (&data.q[0]);
  data.q[10] = crccode >> 8;
  data.q[11] = crccode & 0x00FF;

/* write sector data to file */

for (j=0;j<12;j++){
fputc(data.p[j],fp);
fputc(data.q[j],fp);
fputc(data.r[j],fp);
fputc(data.s[j],fp);
fputc(data.t[j],fp);
fputc(data.u[j],fp);
fputc(data.v[j],fp);
fputc(data.w[j],fp);

#if 0
printf("%2x ",data.p[j]);
printf("%2x ",data.q[j]);
printf("%2x ",data.r[j]);
printf("%2x ",data.s[j]);
printf("%2x ",data.t[j]);
printf("%2x ",data.u[j]);
printf("%2x ",data.v[j]);
printf("%2x\n",data.w[j]);
#endif
  }

tracktimecount++;
abstimecount++;
sector+=SECTOR;
}

return(1);
}



int data(FILE *fp)
{
channel data;
int i,j,k;
int gapidx=0;
int idx=0;
int sector=0;
int abstimecount=0;
int tracktimecount=0;
int gaptimecount;
unsigned short crccode;

for(k=0;k<12;k++)
 {
 data.p[k] = 0;
 data.q[k] = 0;
 data.r[k] = 0;
 data.s[k] = 0;
 data.t[k] = 0;
 data.u[k] = 0;
 data.v[k] = 0;
 data.w[k] = 0;
 }

gaptimecount = cd.gap[0].gapsize/SECTOR;

for (i=0;i<cd.numberoftracks;i++)
{
tracktimecount=0;
idx=0;

  data.q[0] = 0x41;   /* 0100 , no pre-emph, copy OK, x, stereo | mode1 */
  data.q[1] = bcd(cd.track[i].tracknum);  /* TNO */

while(sector<cd.track[i].trackend)
{
/* increment abs time */

  data.q[7] = bcd((abstimecount/75)/60);
  data.q[8] = bcd((abstimecount/75)%60);
  data.q[9] = bcd(abstimecount%75);

/* gaps must be sorted */
if (cd.gap[gapidx].gapend <= sector && (gapidx+1)<cd.numberofgaps) 
{
gapidx++;
gaptimecount = cd.gap[gapidx].gapsize/SECTOR;
}

  if (cd.gap[gapidx].gapstart <= sector && cd.gap[gapidx].gapend > sector)
   {
     for(k=0;k<12;k++)    /* might need fixing, but for now...   */
       data.p[k] = 0xFF;  /* for p channel, a set is mandatory.  */

#if 0
printf("GAP\n");
#endif
    
     /* write a gap here, index = 0, decrement gap time  */

    data.q[2] = 0;      /* index always 0 for a gap */
                        /* count down time */
    data.q[3] = bcd((gaptimecount/75)/60);
    data.q[4] = bcd((gaptimecount/75)%60);
    data.q[5] = bcd(gaptimecount%75);
    gaptimecount--;

   }
  else
   {

#if 0
printf("DATA\n");
#endif

   if (data.p[0] == 0xFF)
     for(k=0;k<12;k++) /* might need fixing, but for now...   */
       data.p[k] = 0;  /* for p channel, a set is mandatory.  */
 
    if (cd.track[i].index[idx].indexend <= sector && (idx+1)<cd.track[i].numberofindexes) 
       idx++;

    data.q[2] = bcd(cd.track[i].index[idx].indexnum);  /* index in track */

    /* track relative time */
    data.q[3] = bcd((tracktimecount/75)/60);
    data.q[4] = bcd((tracktimecount/75)%60);
    data.q[5] = bcd(tracktimecount%75);
    tracktimecount++;
   }

crccode = crc (&data.q[0]);
data.q[10] = crccode >> 8;
data.q[11] = crccode & 0x00FF;

/* write sector data to file */

for (j=0;j<12;j++){
fputc(data.p[j],fp);
fputc(data.q[j],fp);
fputc(data.r[j],fp);
fputc(data.s[j],fp);
fputc(data.t[j],fp);
fputc(data.u[j],fp);
fputc(data.v[j],fp);
fputc(data.w[j],fp);

#if 0
printf("%2x ",data.p[j]);
printf("%2x ",data.q[j]);
printf("%2x ",data.r[j]);
printf("%2x ",data.s[j]);
printf("%2x ",data.t[j]);
printf("%2x ",data.u[j]);
printf("%2x ",data.v[j]);
printf("%2x\n",data.w[j]);
#endif
  }

sector+=SECTOR;
abstimecount++;

}
}

return(0);
}


int leadin(FILE *fp)
{
channel *temp=NULL,*leader=NULL,*start=NULL;
int i,j,k;
int timecount=0;
unsigned short crccode;

if (cd.numberoftracks){
leader = (channel*)malloc(sizeof(channel));
start = leader;
}

for(i=1;i<(cd.numberoftracks*3 + 9);i++)
{
leader->next = (channel*)malloc(sizeof(channel));
leader = leader->next;
}

leader->next = NULL;
leader = start;


/* loop for track numbers */
for(i=0;i<cd.numberoftracks;i++)
for(j=0;j<3;j++)
{
 for(k=0;k<12;k++)
 {
 leader->p[k] = 0;
 leader->q[k] = 0;
 leader->r[k] = 0;
 leader->s[k] = 0;
 leader->t[k] = 0;
 leader->u[k] = 0;
 leader->v[k] = 0;
 leader->w[k] = 0;
 }

leader->q[0] = 0x41;   /* 0100 , no pre-emph, copy OK, x, stereo | mode1 */
leader->q[1] = 0;      /* TNO always 0 for lead in */
leader->q[2] = bcd(i+1); /* TOC pointer */


timecount++;
leader->q[3]=bcd((timecount/75)/60);
leader->q[4]=bcd((timecount/75)%60);
leader->q[5]=bcd(timecount%75);

leader->q[6] = 0;      /* always 0 */

leader->q[7]=bcd(cd.track[i].trackstart / CDAMIN);
leader->q[8]=bcd((cd.track[i].trackstart % CDAMIN) / CDASEC);
leader->q[9]=bcd(((cd.track[i].trackstart % CDAMIN) % CDASEC) / SECTOR);

crccode = crc (leader->q);
leader->q[10] = crccode >> 8;
leader->q[11] = crccode & 0x00FF;

leader=leader->next;
}


/* loop for A0, A1, A2 */
for(i=0;i<3;i++)
for(j=0;j<3;j++)
{
 for(k=0;k<12;k++)
 {
 leader->p[k] = 0;
 leader->q[k] = 0;
 leader->r[k] = 0;
 leader->s[k] = 0;
 leader->t[k] = 0;
 leader->u[k] = 0;
 leader->v[k] = 0;
 leader->w[k] = 0;
 }

leader->q[0] = 0x41;   /* 0100 , no pre-emph, copy OK, x, stereo | mode1 */
leader->q[1] = 0;      /* TNO always 0 for lead in */
leader->q[2] = i + 0xA0;

timecount++;
leader->q[3]=bcd((timecount/75)/60);
leader->q[4]=bcd((timecount/75)%60);
leader->q[5]=bcd(timecount%75);

leader->q[6] = 0;      /* always 0 */

if (i==0) {  /* A0 data, number of first track of disc */
leader->q[7]=bcd(1);
leader->q[8]=0;
leader->q[9]=0;
}

if (i==1){   /* A1 data, number of last track of disc */
leader->q[7]=bcd(cd.numberoftracks);
leader->q[8]=0;
leader->q[9]=0;
}

if (i==2) {  /* A2 data, absolute time location of start of leadout */
leader->q[7]=bcd(cd.totaldatasize / CDAMIN);
leader->q[8]=bcd((cd.totaldatasize % CDAMIN) / CDASEC);
leader->q[9]=bcd(((cd.totaldatasize % CDAMIN) % CDASEC) / SECTOR);
}

crccode = crc (leader->q);

leader->q[10] = crccode >> 8;
leader->q[11] = crccode & 0x00FF;

leader=leader->next;
}

leader = start;

while (leader) {
for (i=0;i<12;i++){
fputc(leader->p[i],fp);
fputc(leader->q[i],fp);
fputc(leader->r[i],fp);
fputc(leader->s[i],fp);
fputc(leader->t[i],fp);
fputc(leader->u[i],fp);
fputc(leader->v[i],fp);
fputc(leader->w[i],fp);

#if 0
printf("%2x ",leader->p[i]);
printf("%2x ",leader->q[i]);
printf("%2x ",leader->r[i]);
printf("%2x ",leader->s[i]);
printf("%2x ",leader->t[i]);
printf("%2x ",leader->u[i]);
printf("%2x ",leader->v[i]);
printf("%2x\n",leader->w[i]);
#endif
  }
temp=leader;
leader=leader->next;
free(temp);
}

return(0);
}

void update_audio_properties (GtkWidget * widget,  GtkWidget *window)
{
audio.mixer = strdup(gtk_entry_get_text(GTK_ENTRY(audio.mixer_val)));
audio.dsp   = strdup(gtk_entry_get_text(GTK_ENTRY(audio.dsp_val)));

gtk_widget_destroy (window);
}

void update_properties (GtkWidget * widget,  GtkWidget *window)
{
cd.catalog_num = strdup(gtk_entry_get_text(GTK_ENTRY(entry.catalog_num)));
cd.country = strdup(gtk_entry_get_text(GTK_ENTRY(entry.country)));
cd.owner = strdup(gtk_entry_get_text(GTK_ENTRY(entry.owner)));
cd.year = strdup(gtk_entry_get_text(GTK_ENTRY(entry.year)));
cd.serial_num = strdup(gtk_entry_get_text(GTK_ENTRY(entry.serial_num)));

gtk_widget_destroy (window);
}

void mode23_cmd_callback (GtkWidget * widget)
{
GtkWidget *button;
GtkWidget *label;
GtkWidget *wintable;
GtkWidget *frame;

static GtkWidget *dialog_window = NULL;

dialog_window = gtk_dialog_new();

/*gtk_window_position (GTK_WINDOW (dialog_window), GTK_WIN_POS_CENTER);*/

gtk_signal_connect (GTK_OBJECT (dialog_window), "destroy",
                   (GtkSignalFunc) destroy_window, &dialog_window);
gtk_signal_connect (GTK_OBJECT (dialog_window), "delete_event",
                   (GtkSignalFunc) destroy_window, &dialog_window);

  wintable = gtk_table_new (6, 7, TRUE);
  gtk_container_add (GTK_CONTAINER (GTK_DIALOG (dialog_window)->action_area), wintable);
  gtk_widget_show (wintable);

gtk_window_set_title (GTK_WINDOW (dialog_window), "CD Properties");
gtk_container_border_width (GTK_CONTAINER (dialog_window), 0);

frame = gtk_frame_new (NULL);
gtk_table_attach (GTK_TABLE (wintable), frame, 0, 7, 0, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (frame);

label = gtk_label_new ("Mode 2");
gtk_table_attach (GTK_TABLE (wintable), label, 0, 1, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (label);


label = gtk_label_new ("Catalog #:");
gtk_misc_set_padding (GTK_MISC (label), 10, 10);
gtk_table_attach (GTK_TABLE (wintable), label, 0, 1, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (label);

entry.catalog_num = gtk_entry_new ();
gtk_entry_set_text (GTK_ENTRY (entry.catalog_num), cd.catalog_num);
gtk_table_attach (GTK_TABLE (wintable), entry.catalog_num, 1, 3, 1, 2,
                    GTK_SHRINK, GTK_SHRINK , 0, 0);
gtk_widget_show (entry.catalog_num);

frame = gtk_frame_new (NULL);
gtk_table_attach (GTK_TABLE (wintable), frame, 0, 7, 2, 5,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (frame);

/*
button = gtk_check_button_new_with_label ("Mode 3");
gtk_table_attach (GTK_TABLE (wintable), button, 0, 1, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (button);
*/

label = gtk_label_new ("Mode 3");
gtk_table_attach (GTK_TABLE (wintable), label, 0, 1, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (label);

label = gtk_label_new ("Country");
gtk_table_attach (GTK_TABLE (wintable), label, 0, 1, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (label);

entry.country = gtk_entry_new ();
gtk_entry_set_text (GTK_ENTRY (entry.country), cd.country);
gtk_table_attach (GTK_TABLE (wintable), entry.country, 1, 3, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (entry.country);

label = gtk_label_new ("Owner");
gtk_table_attach (GTK_TABLE (wintable), label, 0, 1, 4, 5,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (label);

entry.owner = gtk_entry_new ();
gtk_entry_set_text (GTK_ENTRY (entry.owner), cd.owner);
gtk_table_attach (GTK_TABLE (wintable), entry.owner, 1, 3, 4, 5,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (entry.owner);

label = gtk_label_new ("Year");
gtk_table_attach (GTK_TABLE (wintable), label, 3, 4, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (label);

entry.year = gtk_entry_new ();
gtk_entry_set_text (GTK_ENTRY (entry.year), cd.year);
gtk_table_attach (GTK_TABLE (wintable), entry.year, 4, 6, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (entry.year);

label = gtk_label_new ("Serial#");
gtk_table_attach (GTK_TABLE (wintable), label, 3, 4, 4, 5,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (label);

entry.serial_num = gtk_entry_new ();
gtk_entry_set_text (GTK_ENTRY (entry.serial_num), cd.serial_num);
gtk_table_attach (GTK_TABLE (wintable), entry.serial_num, 4, 6, 4, 5,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_show (entry.serial_num);

button = gtk_button_new_with_label ("Cancel");
gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                   (GtkSignalFunc) gtk_widget_destroy,
                          GTK_OBJECT(dialog_window));
GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
gtk_table_attach (GTK_TABLE (wintable), button, 4, 6, 5, 6,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_grab_default (button);
gtk_widget_show (button);

button = gtk_button_new_with_label ("OK");
gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                    GTK_SIGNAL_FUNC (update_properties),
                       GTK_OBJECT(dialog_window));
GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
gtk_table_attach (GTK_TABLE (wintable), button, 1, 3, 5, 6,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
gtk_widget_grab_default (button);
gtk_widget_show (button);


if (!GTK_WIDGET_VISIBLE (dialog_window))
    gtk_widget_show (dialog_window);
else
    gtk_widget_destroy (dialog_window);

}

void mixer (GtkWidget *widget)
{
char cmd[50];

strcpy(cmd, audio.mixer);
strcat(cmd, " &");

system (cmd);
}
