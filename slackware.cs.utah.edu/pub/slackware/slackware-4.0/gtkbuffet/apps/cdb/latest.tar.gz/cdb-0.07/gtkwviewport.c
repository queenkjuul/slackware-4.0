/* GTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h> 
#include <sys/param.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <pwd.h>
#include "fnmatch.h"

#include "gtk/gtksignal.h"
#include "gtkwviewport.h"
#include "gdk/gdkkeysyms.h"
#include "gtk/gtkbutton.h"
#include "gtk/gtkentry.h"
#include "gtk/gtkhbox.h"
#include "gtk/gtklabel.h"
#include "gtk/gtklist.h"
#include "gtk/gtklistitem.h"
#include "gtk/gtkmain.h"
#include "gtk/gtkscrolledwindow.h"
#include "gtk/gtksignal.h"
#include "gtk/gtkvbox.h"
#include "gtk/gtktable.h"
#include "gtk/gtkcheckbutton.h"

static void gtk_wviewport_class_init               (GtkWViewportClass *klass);
static void gtk_wviewport_init                     (GtkWViewport      *wviewport);
static void gtk_wviewport_finalize                 (GtkObject        *object);
static void gtk_wviewport_map                      (GtkWidget        *widget);
static void gtk_wviewport_unmap                    (GtkWidget        *widget);
static void gtk_wviewport_realize                  (GtkWidget        *widget);
static void gtk_wviewport_unrealize                (GtkWidget        *widget);
static void gtk_wviewport_paint                    (GtkWidget        *widget,
						   GdkRectangle     *area);
static void gtk_wviewport_draw                     (GtkWidget        *widget,
						   GdkRectangle     *area);
static gint gtk_wviewport_expose                   (GtkWidget        *widget,
						   GdkEventExpose   *event);
static void gtk_wviewport_add                      (GtkContainer     *container,
						   GtkWidget        *widget);
static void gtk_wviewport_size_request             (GtkWidget        *widget,
						   GtkRequisition   *requisition);
static void gtk_wviewport_size_allocate            (GtkWidget        *widget,
						   GtkAllocation    *allocation);
// static gint gtk_wviewport_need_resize              (GtkContainer     *container);
static void gtk_wviewport_adjustment_changed       (GtkAdjustment    *adjustment,
						   gpointer          data);
static void gtk_wviewport_adjustment_value_changed (GtkAdjustment    *adjustment,
						   gpointer          data);

static GtkBinClass *parent_class;

extern long bytes;

guint
gtk_wviewport_get_type (void)
{
  static guint wviewport_type = 0;

  if (!wviewport_type)
    {
      GtkTypeInfo wviewport_info =
      {
	"GtkWViewport",
	sizeof (GtkWViewport),
	sizeof (GtkWViewportClass),
	(GtkClassInitFunc) gtk_wviewport_class_init,
	(GtkObjectInitFunc) gtk_wviewport_init,
	(GtkArgSetFunc) NULL,
        (GtkArgGetFunc) NULL,
      };

      wviewport_type = gtk_type_unique (gtk_bin_get_type (), &wviewport_info);
    }

  return wviewport_type;
}

static void
gtk_wviewport_class_init (GtkWViewportClass *class)
{
  GtkObjectClass *object_class;
  GtkWidgetClass *widget_class;
  GtkContainerClass *container_class;

  object_class = (GtkObjectClass*) class;
  widget_class = (GtkWidgetClass*) class;
  container_class = (GtkContainerClass*) class;
  parent_class = (GtkBinClass*) gtk_type_class (gtk_bin_get_type ());

  object_class->finalize = gtk_wviewport_finalize;
  
  widget_class->map = gtk_wviewport_map;
  widget_class->unmap = gtk_wviewport_unmap;
  widget_class->realize = gtk_wviewport_realize;
  widget_class->unrealize = gtk_wviewport_unrealize;
  widget_class->draw = gtk_wviewport_draw;
  widget_class->expose_event = gtk_wviewport_expose;
  widget_class->size_request = gtk_wviewport_size_request;
  widget_class->size_allocate = gtk_wviewport_size_allocate;

  container_class->add = gtk_wviewport_add;
// container_class->need_resize = gtk_wviewport_need_resize;
}

static void
gtk_wviewport_init (GtkWViewport *wviewport)
{
  GTK_WIDGET_UNSET_FLAGS (wviewport, GTK_NO_WINDOW);
  GTK_WIDGET_SET_FLAGS (wviewport, GTK_BASIC);

  wviewport->shadow_type = GTK_SHADOW_IN;
  wviewport->view_window = NULL;
  wviewport->bin_window = NULL;
  wviewport->hadjustment = NULL;
  wviewport->vadjustment = NULL;
}

GtkWidget*
gtk_wviewport_new (GtkAdjustment *hadjustment,
		  GtkAdjustment *vadjustment)
{
  GtkWViewport *wviewport;

  wviewport = gtk_type_new (gtk_wviewport_get_type ());

  if (!hadjustment)
    hadjustment = (GtkAdjustment*) gtk_adjustment_new (0.0, 0.0, 0.0, 0.0, 0.0, 0.0);

  if (!vadjustment)
    vadjustment = (GtkAdjustment*) gtk_adjustment_new (0.0, 0.0, 0.0, 0.0, 0.0, 0.0);

  gtk_wviewport_set_hadjustment (wviewport, hadjustment);
  gtk_wviewport_set_vadjustment (wviewport, vadjustment);

  return GTK_WIDGET (wviewport);
}

static void
gtk_wviewport_finalize (GtkObject *object)
{
  GtkWViewport *wviewport = GTK_WVIEWPORT (object);

  gtk_object_unref (GTK_OBJECT (wviewport->hadjustment));
  gtk_object_unref (GTK_OBJECT (wviewport->vadjustment));

  GTK_OBJECT_CLASS(parent_class)->finalize (object);
}

GtkAdjustment*
gtk_wviewport_get_hadjustment (GtkWViewport *wviewport)
{
  g_return_val_if_fail (wviewport != NULL, NULL);
  g_return_val_if_fail (GTK_IS_WVIEWPORT (wviewport), NULL);

  return wviewport->hadjustment;
}

GtkAdjustment*
gtk_wviewport_get_vadjustment (GtkWViewport *wviewport)
{
  g_return_val_if_fail (wviewport != NULL, NULL);
  g_return_val_if_fail (GTK_IS_WVIEWPORT (wviewport), NULL);

  return wviewport->vadjustment;
}

void
gtk_wviewport_set_hadjustment (GtkWViewport   *wviewport,
			      GtkAdjustment *adjustment)
{
  g_return_if_fail (wviewport != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (wviewport));
  g_return_if_fail (adjustment != NULL);

  if (wviewport->hadjustment != adjustment)
    {
      if (wviewport->hadjustment)
	{
	  gtk_signal_disconnect_by_data (GTK_OBJECT (wviewport->hadjustment),
					 (gpointer) wviewport);
	  gtk_object_unref (GTK_OBJECT (wviewport->hadjustment));
	}

      wviewport->hadjustment = adjustment;
      gtk_object_ref (GTK_OBJECT (wviewport->hadjustment));
      gtk_object_sink (GTK_OBJECT (wviewport->hadjustment));
      
      gtk_signal_connect (GTK_OBJECT (adjustment), "changed",
			  (GtkSignalFunc) gtk_wviewport_adjustment_changed,
			  (gpointer) wviewport);
      gtk_signal_connect (GTK_OBJECT (adjustment), "value_changed",
			  (GtkSignalFunc)gtk_wviewport_adjustment_value_changed,
			  (gpointer) wviewport);

      gtk_wviewport_adjustment_changed (adjustment, (gpointer) wviewport);
    }
}

void
gtk_wviewport_set_vadjustment (GtkWViewport   *wviewport,
			      GtkAdjustment *adjustment)
{
  g_return_if_fail (wviewport != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (wviewport));
  g_return_if_fail (adjustment != NULL);

  if (wviewport->vadjustment != adjustment)
    {
      if (wviewport->vadjustment)
	{
	  gtk_signal_disconnect_by_data (GTK_OBJECT (wviewport->vadjustment),
					 (gpointer) wviewport);
	  gtk_object_unref (GTK_OBJECT (wviewport->vadjustment));
	}

      wviewport->vadjustment = adjustment;
      gtk_object_ref (GTK_OBJECT (wviewport->vadjustment));
      gtk_object_sink (GTK_OBJECT (wviewport->vadjustment));
      
      gtk_signal_connect (GTK_OBJECT (adjustment), "changed",
			  (GtkSignalFunc) gtk_wviewport_adjustment_changed,
			  (gpointer) wviewport);
      gtk_signal_connect (GTK_OBJECT (adjustment), "value_changed",
			  (GtkSignalFunc)gtk_wviewport_adjustment_value_changed,
			  (gpointer) wviewport);

      gtk_wviewport_adjustment_changed (adjustment, (gpointer) wviewport);
    }
}

void
gtk_wviewport_set_shadow_type (GtkWViewport   *wviewport,
			      GtkShadowType  type)
{
  g_return_if_fail (wviewport != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (wviewport));

  if ((GtkShadowType) wviewport->shadow_type != type)
    {
      wviewport->shadow_type = type;

      if (GTK_WIDGET_VISIBLE (wviewport))
	{
	  gtk_widget_size_allocate (GTK_WIDGET (wviewport), &(GTK_WIDGET (wviewport)->allocation));
	  gtk_widget_queue_draw (GTK_WIDGET (wviewport));
	}
    }
}


static void
gtk_wviewport_map (GtkWidget *widget)
{
  GtkBin *bin;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (widget));

  GTK_WIDGET_SET_FLAGS (widget, GTK_MAPPED);
  bin = GTK_BIN (widget);

  gdk_window_show (widget->window);

  if (bin->child &&
      GTK_WIDGET_VISIBLE (bin->child) &&
      !GTK_WIDGET_MAPPED (bin->child))
    gtk_widget_map (bin->child);
}

static void
gtk_wviewport_unmap (GtkWidget *widget)
{
  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (widget));

  GTK_WIDGET_UNSET_FLAGS (widget, GTK_MAPPED);
  
  gdk_window_hide (widget->window);
}

static void
gtk_wviewport_realize (GtkWidget *widget)
{
  GtkBin *bin;
  GtkWViewport *wviewport;
  GdkWindowAttr attributes;
  gint attributes_mask;
  gint event_mask;
  gint border_width;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (widget));

  border_width = GTK_CONTAINER (widget)->border_width;

  bin = GTK_BIN (widget);
  wviewport = GTK_WVIEWPORT (widget);
  GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED);

  attributes.x = widget->allocation.x + border_width;
  attributes.y = widget->allocation.y + border_width;
  attributes.width = widget->allocation.width - border_width * 2;
  attributes.height = widget->allocation.height - border_width * 2;
  attributes.window_type = GDK_WINDOW_CHILD;
  attributes.wclass = GDK_INPUT_OUTPUT;
  attributes.visual = gtk_widget_get_visual (widget);
  attributes.colormap = gtk_widget_get_colormap (widget);

  event_mask = gtk_widget_get_events (widget) | GDK_EXPOSURE_MASK;
  attributes.event_mask = event_mask;

  attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;

  widget->window = gdk_window_new (gtk_widget_get_parent_window (widget),
				   &attributes, attributes_mask);
  gdk_window_set_user_data (widget->window, wviewport);

  if (wviewport->shadow_type != GTK_SHADOW_NONE)
    {
      attributes.x = widget->style->klass->xthickness;
      attributes.y = widget->style->klass->ythickness;
    }
  else
    {
      attributes.x = 0;
      attributes.y = 0;
    }

  attributes.width = MAX (1, widget->allocation.width - attributes.x * 2 - border_width * 2);
  attributes.height = MAX (1, widget->allocation.height - attributes.y * 2 - border_width * 2);
  attributes.event_mask = 0;

  wviewport->view_window = gdk_window_new (widget->window, &attributes, attributes_mask);
  gdk_window_set_user_data (wviewport->view_window, wviewport);

  attributes.x = 0;
  attributes.y = 0;

  if (bin->child)
    {
      attributes.width = wviewport->hadjustment->upper;
      attributes.height = wviewport->vadjustment->upper;
    }
  
  attributes.event_mask = event_mask;

  wviewport->bin_window = gdk_window_new (wviewport->view_window, &attributes, attributes_mask);
  gdk_window_set_user_data (wviewport->bin_window, wviewport);

  if (bin->child)
    gtk_widget_set_parent_window (bin->child, wviewport->bin_window);

  widget->style = gtk_style_attach (widget->style, widget->window);
  gtk_style_set_background (widget->style, widget->window, GTK_STATE_NORMAL);
  gtk_style_set_background (widget->style, wviewport->bin_window, GTK_STATE_NORMAL);
  
  gdk_window_show (wviewport->bin_window);
  gdk_window_show (wviewport->view_window);
}

static void
gtk_wviewport_unrealize (GtkWidget *widget)
{
  GtkWViewport *wviewport;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (widget));

  wviewport = GTK_WVIEWPORT (widget);

  gdk_window_set_user_data (wviewport->view_window, NULL);
  gdk_window_destroy (wviewport->view_window);
  wviewport->view_window = NULL;

  gdk_window_set_user_data (wviewport->bin_window, NULL);
  gdk_window_destroy (wviewport->bin_window);
  wviewport->bin_window = NULL;

  if (GTK_WIDGET_CLASS (parent_class)->unrealize)
    (* GTK_WIDGET_CLASS (parent_class)->unrealize) (widget);
}

static void
gtk_wviewport_paint (GtkWidget    *widget,
		    GdkRectangle *area)
{
  GtkWViewport *wviewport;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (widget));
  g_return_if_fail (area != NULL);

  if (GTK_WIDGET_DRAWABLE (widget))
    {
      wviewport = GTK_WVIEWPORT (widget);

      gtk_draw_shadow (widget->style, widget->window,
		       GTK_STATE_NORMAL, wviewport->shadow_type,
		       0, 0, -1, -1);
    }
}

static void
gtk_wviewport_draw (GtkWidget    *widget,
		   GdkRectangle *area)
{
  GtkWViewport *wviewport;
  GtkBin *bin;
  GdkRectangle tmp_area;
  GdkRectangle child_area;
  gint border_width;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (widget));
  g_return_if_fail (area != NULL);

  if (GTK_WIDGET_DRAWABLE (widget))
    {
      wviewport = GTK_WVIEWPORT (widget);
      bin = GTK_BIN (widget);

      border_width = GTK_CONTAINER (widget)->border_width;
      
      tmp_area = *area;
      tmp_area.x -= border_width;
      tmp_area.y -= border_width;
      
      gtk_wviewport_paint (widget, &tmp_area);

      if (bin->child)
	{
          tmp_area.x += wviewport->hadjustment->value - widget->style->klass->xthickness;
	  tmp_area.y += wviewport->vadjustment->value - widget->style->klass->ythickness;

	  if (gtk_widget_intersect (bin->child, &tmp_area, &child_area))
	    gtk_widget_draw (bin->child, &child_area);
	}
    }
}

static gint
gtk_wviewport_expose (GtkWidget      *widget,
		     GdkEventExpose *event)
{
  GtkWViewport *wviewport;
  GtkBin *bin;
  GdkEventExpose child_event;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (GTK_IS_WVIEWPORT (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  if (GTK_WIDGET_DRAWABLE (widget))
    {
      wviewport = GTK_WVIEWPORT (widget);
      bin = GTK_BIN (widget);

      if (event->window == widget->window)
	gtk_wviewport_paint (widget, &event->area);

      child_event = *event;
      if ((event->window == wviewport->bin_window) &&
	  (bin->child != NULL) &&
	  GTK_WIDGET_NO_WINDOW (bin->child) &&
	  gtk_widget_intersect (bin->child, &event->area, &child_event.area)) 
	gtk_widget_event (bin->child, (GdkEvent*) &child_event);
    }

  return FALSE;
}

static void
gtk_wviewport_add (GtkContainer *container,
		  GtkWidget    *widget)
{
  GtkBin *bin;

  g_return_if_fail (container != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (container));
  g_return_if_fail (widget != NULL);

  bin = GTK_BIN (container);

  if (!bin->child)
    {
      gtk_widget_set_parent (widget, GTK_WIDGET (container));
      gtk_widget_set_parent_window (widget, GTK_WVIEWPORT (container)->bin_window);
      if (GTK_WIDGET_VISIBLE (widget))
	{
	  if (GTK_WIDGET_MAPPED (widget->parent) &&
	      !GTK_WIDGET_MAPPED (widget))
	    gtk_widget_map (widget);
	}

      bin->child = widget;

      if (GTK_WIDGET_VISIBLE (widget) && GTK_WIDGET_VISIBLE (container))
        gtk_widget_queue_resize (widget);
    }
}

static void
gtk_wviewport_size_request (GtkWidget      *widget,
			   GtkRequisition *requisition)
{
  GtkWViewport *wviewport;
  GtkBin *bin;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (widget));
  g_return_if_fail (requisition != NULL);

  wviewport = GTK_WVIEWPORT (widget);
  bin = GTK_BIN (widget);

  requisition->width = (GTK_CONTAINER (widget)->border_width +
			GTK_WIDGET (widget)->style->klass->xthickness) * 2 + 5;

  requisition->height = (GTK_CONTAINER (widget)->border_width * 2 +
			 GTK_WIDGET (widget)->style->klass->ythickness) * 2 + 5;

  if (bin->child && GTK_WIDGET_VISIBLE (bin->child))
    gtk_widget_size_request (bin->child, &bin->child->requisition);
}

static void
gtk_wviewport_size_allocate (GtkWidget     *widget,
			    GtkAllocation *allocation)
{
  GtkWViewport *wviewport;
  GtkBin *bin;
  GtkAllocation child_allocation;
  gint hval, vval;
  gint border_width;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (widget));
  g_return_if_fail (allocation != NULL);

  widget->allocation = *allocation;
  wviewport = GTK_WVIEWPORT (widget);
  bin = GTK_BIN (widget);

  border_width = GTK_CONTAINER (widget)->border_width;

  child_allocation.x = 0;
  child_allocation.y = 0;

  if (wviewport->shadow_type != GTK_SHADOW_NONE)
    {
      child_allocation.x = GTK_WIDGET (wviewport)->style->klass->xthickness;
      child_allocation.y = GTK_WIDGET (wviewport)->style->klass->ythickness;
    }

  child_allocation.width = MAX (1, allocation->width - child_allocation.x * 2 - border_width * 2);
  child_allocation.height = MAX (1, allocation->height - child_allocation.y * 2 - border_width * 2);

  if (GTK_WIDGET_REALIZED (widget))
    {
      gdk_window_move_resize (widget->window,
			      allocation->x + border_width,
			      allocation->y + border_width,
			      allocation->width - border_width * 2,
			      allocation->height - border_width * 2);

      gdk_window_move_resize (wviewport->view_window,
			      child_allocation.x,
			      child_allocation.y,
			      child_allocation.width,
			      child_allocation.height);
    }

  wviewport->hadjustment->page_size = child_allocation.width;
  wviewport->hadjustment->page_increment = wviewport->hadjustment->page_size / 2;
  wviewport->hadjustment->step_increment = 10;

  wviewport->vadjustment->page_size = child_allocation.height;
  wviewport->vadjustment->page_increment = wviewport->vadjustment->page_size / 2;
  wviewport->vadjustment->step_increment = 10;

  hval = wviewport->hadjustment->value;
  vval = wviewport->vadjustment->value;

  if (bin->child && GTK_WIDGET_VISIBLE (bin->child))
    {
      wviewport->hadjustment->lower = 0;
      wviewport->hadjustment->upper = MAX (bin->child->requisition.width,
					  child_allocation.width);

// printf("requisition.width = %d  child_allocation.width=%d \n",bin->child->requisition.width,child_allocation.width);

      hval = CLAMP (hval, 0,
		    wviewport->hadjustment->upper -
		    wviewport->hadjustment->page_size);

      wviewport->vadjustment->lower = 0;
      wviewport->vadjustment->upper = MAX (bin->child->requisition.height,
					  child_allocation.height);

      vval = CLAMP (vval, 0,
		    wviewport->vadjustment->upper -
		    wviewport->vadjustment->page_size);
    }

  if (bin->child && GTK_WIDGET_VISIBLE (bin->child))
    {
      child_allocation.x = 0;
      child_allocation.y = 0;

      child_allocation.width = wviewport->hadjustment->upper;
      child_allocation.height = wviewport->vadjustment->upper;

      if (!GTK_WIDGET_REALIZED (widget))
        gtk_widget_realize (widget);

      gdk_window_resize (wviewport->bin_window,
			 child_allocation.width,
			 child_allocation.height);

      child_allocation.x = 0;
      child_allocation.y = 0;
      gtk_widget_size_allocate (bin->child, &child_allocation);
    }

wviewport->hadjustment->upper = (gfloat)(bytes/2352);


  gtk_signal_emit_by_name (GTK_OBJECT (wviewport->hadjustment), "changed");
  gtk_signal_emit_by_name (GTK_OBJECT (wviewport->vadjustment), "changed");
  if (wviewport->hadjustment->value != hval)
    {
      wviewport->hadjustment->value = hval;
      gtk_signal_emit_by_name (GTK_OBJECT (wviewport->hadjustment), "value_changed");
    }
  if (wviewport->vadjustment->value != vval)
    {
      wviewport->vadjustment->value = vval;
      gtk_signal_emit_by_name (GTK_OBJECT (wviewport->vadjustment), "value_changed");
    }
}

/*
static gint
gtk_wviewport_need_resize (GtkContainer *container)
{
  GtkBin *bin;

  g_return_val_if_fail (container != NULL, FALSE);
  g_return_val_if_fail (GTK_IS_WVIEWPORT (container), FALSE);

  if (GTK_WIDGET_REALIZED (container))
    {
      bin = GTK_BIN (container);

      gtk_widget_size_request (bin->child, &bin->child->requisition);

      gtk_widget_size_allocate (GTK_WIDGET (container),
				&(GTK_WIDGET (container)->allocation));
    }

  return FALSE;
}
*/

static void
gtk_wviewport_adjustment_changed (GtkAdjustment *adjustment,
				 gpointer       data)
{
  GtkWViewport *wviewport;

  g_return_if_fail (adjustment != NULL);
  g_return_if_fail (data != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (data));

  wviewport = GTK_WVIEWPORT (data);
}

static void
gtk_wviewport_adjustment_value_changed (GtkAdjustment *adjustment,
				       gpointer       data)
{
  GtkWViewport *wviewport;
  GtkBin *bin;
  GtkAllocation child_allocation;
  gint width, height;

  g_return_if_fail (adjustment != NULL);
  g_return_if_fail (data != NULL);
  g_return_if_fail (GTK_IS_WVIEWPORT (data));

  wviewport = GTK_WVIEWPORT (data);
  bin = GTK_BIN (data);

  if (bin->child && GTK_WIDGET_VISIBLE (bin->child))
    {

// printf("%ld\n",(long)wviewport->hadjustment->value);

      gdk_window_get_size (wviewport->view_window, &width, &height);

      child_allocation.x = 0;
      child_allocation.y = 0;

      if (wviewport->hadjustment->lower != (wviewport->hadjustment->upper -
					   wviewport->hadjustment->page_size))
	child_allocation.x =  wviewport->hadjustment->lower - ((long)wviewport->hadjustment->value)%30000;

      if (wviewport->vadjustment->lower != (wviewport->vadjustment->upper -
					   wviewport->vadjustment->page_size))
	child_allocation.y = wviewport->vadjustment->lower - wviewport->vadjustment->value;

      if (GTK_WIDGET_REALIZED (wviewport))
	gdk_window_move (wviewport->bin_window,
			 child_allocation.x,
			 child_allocation.y);
    }
}
