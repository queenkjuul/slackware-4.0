#ifndef __MAIN_H__
#define __MAIN_H__

#ifdef __cplusplus
extern "C"
{
#endif				/* __cplusplus */

typedef struct audiosys {
int pid;
char *dsp;
char *mixer;
int endianinv;
int da;
int wave_update;
GtkWidget *mixer_val;
GtkWidget *dsp_val;
} audiosys;

typedef struct play_file {
int command;
int fileidx;
int filestart;
int location;
long abslocation;
int loc[256];
int fid[256];
int filenum;
int reading;
int writing;
} play_file;

typedef struct gap_type {
int gapsize;
int gapstart;
int gapend;
} gap_type;

typedef struct index_type {
int indexnum;
int indexstart;
int indexend;
} index_type;

typedef struct track_type {
int trackstart;
int trackend;
int tracknum;
short permission;
short emphasis;
short fourchannel;
int tracktype;  /* cdda, data, etc */

int numberofindexes;
index_type index[99];
} track_type;

typedef struct file_type {
char *filename;
int filesize;
int filestart;
int fileend;
} file_type;

typedef struct cd_type {

int subcode_type;  /* per scsi MMC spec */
char *media_type;    /* CDDA, Data, etc */

char *catalog_num;  /* mode 2 info */

char *country;
char *owner;        /* mode 3 info */
char *year;
char *serial_num;

int totaldatasize;
int totalsector;
int numberoftracks;
int numberoffiles;
int numberofgaps;
file_type file[1000]; 
gap_type gap[1000];
track_type track[99];
} cd_type;

typedef struct front_panel {
GtkWidget *totaltrack;
GtkWidget *totalindex;

GtkWidget *track;
GtkWidget *index;
GtkWidget *track_time;
GtkWidget *total_time;
GtkWidget *block;

GtkWidget *permision_toggle;
GtkWidget *fourchannel_toggle;
GtkWidget *emphasis_toggle;
GtkWidget *wave_update_toggle;

GtkAdjustment *adjustment;
GtkAdjustment *fine_adjustment;
} front_panel;

typedef struct channel {
unsigned char p[12];
unsigned char q[12];
unsigned char r[12];
unsigned char s[12];
unsigned char t[12];
unsigned char u[12];
unsigned char v[12];
unsigned char w[12];
struct channel *next;
} channel;

typedef struct cdp {
GtkWidget *catalog_num;
GtkWidget *serial_num;
GtkWidget *year;
GtkWidget *owner;
GtkWidget *country;
} cdp;

typedef struct cue_sheet_entry {
unsigned char ctladr;
unsigned char tno;
unsigned char index;
unsigned char dataform;
unsigned char scms;
unsigned char min;
unsigned char sec;
unsigned char frac;
} cue_sheet_entry;



  void file_quit_cmd_callback (GtkWidget * widget, gpointer data);
  void about_cmd_callback (GtkWidget * widget);
  void permission_callback (GtkWidget * widget);
  void fourchannel_callback (GtkWidget * widget);
  void wave_update_callback (GtkWidget * widget);
  void emphasis_callback (GtkWidget * widget);
  void audiodev_callback (GtkWidget * widget);
  void mediatype_callback (GtkWidget * widget);
  void subctype_callback (GtkWidget * widget);
  void destroy_window (GtkWidget * widget, GtkWidget ** window);
  void oncdb_cmd_callback (GtkWidget * widget);
  void files_cmd_callback (GtkWidget * widget);
  void mode23_cmd_callback (GtkWidget * widget);
  void playit (GtkWidget * widget);
  void stopit (GtkWidget * widget);
  void fwdit (GtkWidget * widget);
  void backit (GtkWidget * widget);
  void adjust (GtkWidget * widget, int x,  int status);
  void fine_adjust (GtkWidget * widget, int x,  int status);
  void set_track (GtkWidget * widget);
  void unset_track (GtkWidget * widget);
  void set_index (GtkWidget * widget);
  void unset_index (GtkWidget * widget);
  void set_gap (GtkWidget * widget);
  void advanced_callback (GtkWidget * widget);
  void generate_subcodes (GtkWidget * widget);
  void generate_cuesheet (GtkWidget * widget);
  void generate_rawimage ();
  void split_tracks();
  void paddit(char * message);
  void playcommand(int , int, int);
  int getfilenum();
  play_file* getplaydata();
  int audioplay(int cmd);
  void readaudiofile();
  void update_audio_properties (GtkWidget *widget,  GtkWidget *window);
  void mixer (GtkWidget *widget);
  int leader(FILE *fp);
  int data(FILE *fp);
  int leadout(FILE *fp);
  int leadin(FILE *fp);
  short crc (unsigned char *input);

#ifdef __cplusplus
}
#endif				/* __cplusplus */

#endif				/* __MAIN_H__ */
