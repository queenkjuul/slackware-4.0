#include<stdio.h>
#include<string.h>

/* CD's are accurate to 1/75th of a second */

#define SECTOR 2352
#define CDASEC 176400 /* 2352 * 75 bytes */
#define CDAMIN 10584000
#define SUBCSEC 7200  /* 96 * 75 bytes */

unsigned char bcd(int val);
int initfile(char *filename);
int autogap(char *filename, int bytes);
int filesize(char *filename);
extern void paddit(char * message);
