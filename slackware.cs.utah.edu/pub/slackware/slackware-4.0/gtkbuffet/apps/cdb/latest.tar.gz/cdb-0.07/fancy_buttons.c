#include <gtk/gtk.h>
#include <stdio.h>
#include "main.h"
#include "fancy_buttons.h"


void play_buttons(GtkWidget *window, GtkWidget *blatest)
{
    GtkWidget *pixmapwid;
    GdkPixmap *pixmap;
    GdkBitmap *mask;
    GtkStyle *style;
    GtkWidget *blatest2;
          


// play button
              
 gtk_widget_realize(window);                            


  blatest2 = gtk_button_new();


  gtk_signal_connect (GTK_OBJECT (blatest2), "clicked",
                          (GtkSignalFunc) playit,
                          NULL);
  gtk_table_attach (GTK_TABLE (blatest), blatest2, 0, 1, 0, 1,
                  GTK_FILL | GTK_EXPAND ,GTK_FILL | GTK_EXPAND , 2, 2);

  gtk_widget_show (blatest2);

  style = gtk_widget_get_style( blatest2 );
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)xpm_data );

  pixmapwid = gtk_pixmap_new( pixmap, mask );
  gtk_container_add( GTK_CONTAINER(blatest2), pixmapwid );
  gtk_widget_show( pixmapwid );

// stop button

  style = gtk_widget_get_style( window );
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)stop_XPM );          

    pixmapwid = gtk_pixmap_new( pixmap, mask );
    gtk_widget_show( pixmapwid );

  blatest2 = gtk_button_new();
  gtk_container_add( GTK_CONTAINER(blatest2), pixmapwid );

  gtk_signal_connect (GTK_OBJECT (blatest2), "clicked",
                          (GtkSignalFunc) stopit,
                          NULL);
  gtk_table_attach (GTK_TABLE (blatest), blatest2, 1, 2, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 2, 2);
  gtk_widget_show (blatest2);

// back button

  style = gtk_widget_get_style( window );
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)back_XPM );          

    pixmapwid = gtk_pixmap_new( pixmap, mask );
    gtk_widget_show( pixmapwid );

  blatest2 = gtk_button_new();
  gtk_container_add( GTK_CONTAINER(blatest2), pixmapwid );

  gtk_signal_connect (GTK_OBJECT (blatest2), "clicked",
                          (GtkSignalFunc) backit,
                          NULL);
  gtk_table_attach (GTK_TABLE (blatest), blatest2, 0, 1, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 2, 2);
  gtk_widget_show (blatest2);

// fwd button

  style = gtk_widget_get_style( window );
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)fwd_XPM );

    pixmapwid = gtk_pixmap_new( pixmap, mask );
    gtk_widget_show( pixmapwid );

  blatest2 = gtk_button_new();
  gtk_container_add( GTK_CONTAINER(blatest2), pixmapwid );

  gtk_signal_connect (GTK_OBJECT (blatest2), "clicked",
                          (GtkSignalFunc) fwdit,
                          NULL);
  gtk_table_attach (GTK_TABLE (blatest), blatest2, 1, 2, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 2, 2);
  gtk_widget_show (blatest2);


// record button

  style = gtk_widget_get_style( window );
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                                 &style->bg[GTK_STATE_NORMAL],
                                                 (gchar **)record2_xpm );         
                                                                     
    pixmapwid = gtk_pixmap_new( pixmap, mask );
    gtk_widget_show( pixmapwid );              
                                 
  blatest2 = gtk_button_new();
  gtk_container_add( GTK_CONTAINER(blatest2), pixmapwid );

/*  not yet implemented
  gtk_signal_connect (GTK_OBJECT (blatest2), "clicked",
                          (GtkSignalFunc) mixer,
                          NULL);
*/


  gtk_table_attach (GTK_TABLE (blatest), blatest2, 2, 3, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 2, 2);
  gtk_widget_show (blatest2);


}
