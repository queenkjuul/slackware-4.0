/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#include <string.h>
#include <sys/time.h>

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "aim.h"

GtkWidget *prefs=NULL;
int sounds;
int extrasounds;
int enter_sends;
int show_time;
int remember_pass;
int auto_login;
char ourname[80];
char mypassword[16];
struct away_message *awayroot;



void load_prefs()
{
	FILE *f;
	struct away_message *a, *b;
	char *tmp;
	char *tmp2;
	char buf[BUF_LONG];

        /* Attention gAIM Dev Team:  Had to add the two following lines.
           There were segfaults every time this function was called.
           Tsk Tsk, Heh.. Forgot to allocate the pointers.  
           If you guys need any help,suggestions.. email me
           rflynn@blueridge.net */

	tmp = malloc(255);  /* Have to allocate memory to pointers */
        tmp2 = malloc(255);

	awayroot = NULL;

	if (getenv("HOME")) {
		snprintf(buf, sizeof(buf), "%s/.gaimrc", getenv("HOME"));
		if ((f = fopen(buf,"r"))) {
			while(fgets(buf, sizeof(buf), f)>0) {
				if (buf[0] == '#')
					continue;
				sscanf(buf, "%s %s", tmp, tmp2);
				
				if (!strcasecmp(tmp, "username")) {
					sscanf(buf, "%s %[A-Za-z 0-9]\n", tmp, tmp2);
					snprintf(ourname, sizeof(ourname), "%s", tmp2);
				} else
				if (!strcasecmp(tmp, "password")) {
					snprintf(mypassword, sizeof(mypassword), "%s", tmp2);
				} else
				if (!strcasecmp(tmp, "sounds")) {
					sscanf(tmp2, "%d", &sounds);
				} else
				if (!strcasecmp(tmp, "extrasounds")) {
					sscanf(tmp2, "%d", &extrasounds);
				} else
				if (!strcasecmp(tmp, "enter_sends")) {
					sscanf(tmp2, "%d", &enter_sends);
				} else
				if (!strcasecmp(tmp, "show_time")) {
					sscanf(tmp2, "%d", &show_time);	
				} else
				if (!strcasecmp(tmp, "remember_pass")) {
					sscanf(tmp2, "%d", &remember_pass);	
				} else
				if (!strcasecmp(tmp, "auto_login")) {
					sscanf(tmp2, "%d", &auto_login);	
				} else
				if (!strcasecmp(tmp, "away_mess")) {
					fgets(buf, sizeof(buf), f);
					if (!strlen(buf) || !strlen(tmp2))
						continue;
					a = malloc(sizeof(struct away_message));
					snprintf(a->name, sizeof(a->name), "%s", tmp2);
					snprintf(a->message, sizeof(a->message), "%s", buf);
					/* Get rid of the \n ya doofus */
					a->message[strlen(a->message) - 1] = '\0';
					a->next = NULL;
					if (awayroot == NULL)
						awayroot = a;
					else
						b->next = a;
					b = a;
				}
			}
			fclose(f);
		} else {
			/* defaults*/
			sounds = 1;
			extrasounds = 1;
			enter_sends = 1;
			show_time = 1;
		}
	}
	

       free(tmp);  free(tmp2); /* Free up those pointers, boys */
}

void save_prefs()
{
	FILE *f;
	struct away_message *a;
	char buf[BUF_LONG];
	if (getenv("HOME")) {
		snprintf(buf, sizeof(buf), "%s/.gaimrc", getenv("HOME"));
		if ((f = fopen(buf,"w"))) {
			fprintf(f, "username %s\n", ourname);
			if (remember_pass) {
				fprintf(f, "password %s\n",mypassword);
			} else {
				fprintf(f, "password none\n");
			}
			fprintf(f, "sounds %d\n", sounds);
			fprintf(f, "extrasounds %d\n", extrasounds);
			fprintf(f, "enter_sends %d\n", enter_sends);
			fprintf(f, "show_time %d\n", show_time);
			fprintf(f, "remember_pass %d\n", remember_pass);
			fprintf(f, "auto_login %d\n", auto_login);
			a = awayroot;
			while(a != NULL) {
				fprintf(f, "away_mess %s\n", a->name);
				fprintf(f, "%s\n", a->message);
				a=a->next;
			}
			fclose(f);
		}
	}
}

void set_option(GtkWidget *w, int *data)
{
	*data = !(*data);
	save_prefs();
#if 0
	printf("Data %p set to %d\n",data, *data);
#endif
}

static void handle_delete()
{
	gtk_widget_hide(prefs);
}

void build_prefs()
{
	GtkWidget *bbox;
	GtkWidget *vbox;
	GtkWidget *close;
	GtkWidget *sound;
	GtkWidget *extra;
	GtkWidget *enter;
	GtkWidget *time;
	GtkWidget *notebook;
	GtkWidget *general;
	GtkWidget *label;
	
	/* Notebooks */
	notebook = gtk_notebook_new();
	general = gtk_vbox_new(FALSE, 0);
	label = gtk_label_new("General");
	gtk_widget_show(label);
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook), general, label);
	
	/* General */
	sound = gtk_check_button_new_with_label("Enable buddy logon/logoff sounds");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(sound), sounds);
	extra = gtk_check_button_new_with_label("Enable send/receive message sounds");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(extra), extrasounds);
	enter = gtk_check_button_new_with_label("Enter sends message");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(enter), enter_sends);
	time = gtk_check_button_new_with_label("Show time on messages");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(time), show_time);
	gtk_box_pack_start(GTK_BOX(general), sound, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(general), enter, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(general), extra, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(general), time, FALSE, FALSE, 0);
	gtk_signal_connect(GTK_OBJECT(sound), "clicked", GTK_SIGNAL_FUNC(set_option), &sounds);
	gtk_signal_connect(GTK_OBJECT(extra), "clicked", GTK_SIGNAL_FUNC(set_option), &extrasounds);
	gtk_signal_connect(GTK_OBJECT(enter), "clicked", GTK_SIGNAL_FUNC(set_option), &enter_sends);
	gtk_signal_connect(GTK_OBJECT(time), "clicked", GTK_SIGNAL_FUNC(set_option), &show_time);
	
	vbox = gtk_vbox_new(FALSE, 5);
	bbox = gtk_hbox_new(FALSE, 5);
	close = gtk_button_new_with_label("Close");
	
	/* Pack the button(s) in the button box */
	gtk_box_pack_end(GTK_BOX(bbox), close, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), notebook, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox),bbox, FALSE, FALSE, 5);

	gtk_widget_show(notebook);
	gtk_widget_show(sound);
	gtk_widget_show(extra);
	gtk_widget_show(enter);
	gtk_widget_show(general);
	gtk_widget_show(close);
	gtk_widget_show(time);
	gtk_widget_show(bbox);
	gtk_widget_show(vbox);
	prefs = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_realize(prefs);
	aol_icon(prefs->window);
	gtk_container_add(GTK_CONTAINER(prefs), vbox);
	gtk_container_border_width(GTK_CONTAINER(prefs), 10);
	gtk_window_set_title(GTK_WINDOW(prefs), "Preferences");
	gtk_signal_connect(GTK_OBJECT(close), "clicked", GTK_SIGNAL_FUNC(handle_delete), NULL);
	gtk_signal_connect(GTK_OBJECT(prefs),"delete_event", 
		           GTK_SIGNAL_FUNC(handle_delete), NULL);
	
}

void show_prefs()
{
	if (!prefs)
		build_prefs();
	gtk_widget_show(prefs);
}

	
