/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#include <netdb.h>
#include <gtk/gtk.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include "aim.h"

/* descriptor for talking to TOC */
static int toc_fd;
static int seqno;
static unsigned int peer_ver=0;
static int state;
static int inpa=-1;

struct conv *cnvroot=NULL;
struct buddy_chat *chatroot=NULL;

char toc_addy[16];
char *quad_addr;

char ourname[80];
struct away_message *awaymessage;

unsigned int *get_address(char *hostname)
{
	struct hostent *hp;
	unsigned int *sin=NULL;
	if ((hp=gethostbyname(hostname))) {
		sin = (unsigned int *)malloc(sizeof(struct sockaddr_in));
		memcpy(sin, hp->h_addr, hp->h_length);
	}
	return sin;
}

char *condense(char *s)
{
	static char buf[BUF_LEN];
	int x=0;
	while(*s) {
		if (*s != ' ') {
			buf[x] = *s;
			x++;
		}
		s++;
	}
	buf[x]='\0';
	return buf;
}

int connect_address(unsigned int addy, unsigned short port)
{
	struct sockaddr_in sin;

	sin.sin_addr.s_addr = addy;
	sin.sin_family = AF_INET;
	sin.sin_port = htons(port);
	
	toc_fd = socket(AF_INET, SOCK_STREAM, 0);
	
	if (toc_fd > -1) {
		quad_addr=strdup(inet_ntoa(sin.sin_addr));
		if (connect(toc_fd, &sin, sizeof(sin)) > -1) {
			return 0;
		}
	}
	return -1;
}

void toc_close()
{
	if (inpa > 0)
		gdk_input_remove(inpa);
	close(toc_fd);
	toc_fd=-1;
	inpa=-1;
}

unsigned char *roast_password(char *pass)
{
	/* Trivial "encryption" */
	static char rp[256];
	static char *roast = ROAST;
	int pos=2;
	int x;
	strcpy(rp, "0x");
	for (x=0;(x<150) && pass[x]; x++) 
		pos+=sprintf(&rp[pos],"%02x", pass[x] ^ roast[x % strlen(roast)]);
	rp[pos]='\0';
	return rp;
}

int escape_message(char *msg)
{
	char *c, *cpy;
	int cnt=0;
	/* Assumes you have a buffer able to cary at least BUF_LEN * 2 bytes */
	if (strlen(msg) > BUF_LEN) {
		fprintf(stderr, "Warning:  truncating message to 1024 bytes\n");
		msg[1023]='\0';
	}
	
	cpy = strdup(msg);
	c = cpy;
	while(*c) {
		switch(*c) {
		case '$':
		case '[':
		case ']':
		case '(':
		case ')':
		case '#':
			msg[cnt++]='\\';
			/* Fall through */
		default:
			msg[cnt++]=*c;
		}
		c++;
	}
	msg[cnt]='\0';
	free(cpy);
	return cnt;
}

int escape_text(char *msg)
{
	char *c, *cpy;
	int cnt=0;
	/* Assumes you have a buffer able to cary at least BUF_LEN * 2 bytes */
	if (strlen(msg) > BUF_LEN) {
		fprintf(stderr, "Warning:  truncating message to 1024 bytes\n");
		msg[1023]='\0';
	}
	
	cpy = strdup(msg);
	c = cpy;
	while(*c) {
		switch(*c) {
		case '{':
		case '}':
		case '\\':
		case '"':
			msg[cnt++]='\\';
			/* Fall through */
		default:
			msg[cnt++]=*c;
		}
		c++;
	}
	msg[cnt]='\0';
	free(cpy);
	return cnt;
}

char *print_header(void *hdr_v)
{
	static char s[80];
	struct sflap_hdr *hdr = (struct sflap_hdr *)hdr_v;
	snprintf(s,sizeof(s), "[ ast: %c, type: %d, seqno: %d, len: %d ]",
		hdr->ast, hdr->type, ntohs(hdr->seqno), ntohs(hdr->len));
	return s;
}

void print_buffer(char *buf, int len)
{
#if 0
	int x;
	printf("[ ");
	for (x=0;x<len;x++) 
		printf("%d ", buf[x]);
	printf("]\n");
#endif
}

int sflap_send(char *buf, int olen, int type)
{
	int len;
	int slen=0;
	struct sflap_hdr hdr;
	char obuf[1024];
	if (olen < 0)
		len = escape_message(buf);
	else
		len = olen;
	hdr.ast = '*';
	hdr.type = type;
	hdr.seqno = htons(seqno++ & 0xffff);
	hdr.len = htons(len + (type == TYPE_SIGNON ? 0 : 1));
/*	fprintf(stdout,"Escaped message is '%s'\n",buf); */
	memcpy(obuf, &hdr, sizeof(hdr));
	slen += sizeof(hdr);
	memcpy(&obuf[slen], buf, len);
	slen += len;
	if (type != TYPE_SIGNON) {
		obuf[slen]='\0';
		slen += 1;
	}
	print_buffer(obuf, slen); 
	return write(toc_fd, obuf, slen);
}

int wait_reply(char *buffer, int buflen)
{
	int res;
	struct sflap_hdr *hdr=(struct sflap_hdr *)buffer;
	char *c;
	res = read(toc_fd, buffer, sizeof(struct sflap_hdr));
	if (res < 0)
		return res;
	res += read(toc_fd, buffer + sizeof(struct sflap_hdr), ntohs(hdr->len));
	if (res >= sizeof(struct sflap_hdr)) 
		buffer[res]='\0';
	else
		return res - sizeof(struct sflap_hdr);
		
#if 0
	fprintf(stdout, "Rcv: %s %s\n",print_header(buffer), "");
#endif
	switch(hdr->type) {
	case TYPE_SIGNON:
		memcpy(&peer_ver, buffer + sizeof(struct sflap_hdr), 4);
		peer_ver = ntohl(peer_ver);
		seqno = ntohs(hdr->seqno);
		state = STATE_SIGNON_REQUEST;
		break;
	case TYPE_DATA:
		if (!strncasecmp(buffer + sizeof(struct sflap_hdr), "SIGN_ON:", strlen("SIGN_ON:")))
			state = STATE_SIGNON_ACK;
		else 
		if (!strncasecmp(buffer + sizeof(struct sflap_hdr), "CONFIG:", strlen("CONFIG:")))
			state = STATE_CONFIG;
		else
		if (state != STATE_CONFIG && !strncasecmp(buffer + sizeof(struct sflap_hdr), "ERROR:", strlen("ERROR:"))) {
			c = strtok(buffer + sizeof(struct sflap_hdr) + strlen("ERROR:"), ":");
			handle_error(c);
		}
#ifdef DEBUG
		fprintf(stderr, "Data: %s\n",buffer + sizeof(struct sflap_hdr));
#endif
		break;
	default:
		fprintf(stderr, "Unknown/unimplemented packet type %d\n",hdr->type);
	}
	return res;
}

#ifdef USE_XMHTML
void gethtmlw(char *user, 
GtkWidget **html, int *sound)
#else
void gettextw(char *user, GtkWidget **text, int *sound)
#endif
{
	struct conv *c, *t;
	c = cnvroot;
	t = cnvroot;
	while(c) {
		if (!strcasecmp(user, c->name)) 
			break;
		t=c;
		c=c->next;
	}
	if (!c) {
		c = (struct conv *)malloc(sizeof(struct conv));
		if (!c)
			return;
		if (!t) {
			cnvroot = c;
		} else {
			t->next = c;
		}
		c->next = NULL;
		snprintf(c->name, sizeof(c->name), "%s", user);
		show_conv(c);
	}
	*sound = c->makesound;
#ifdef USE_XMHTML
	*html = c->html;
#else
	*text = c->text;
#endif
}


void delcnv(char *user)
{	
	struct conv *c, *t;
	
	if (!c)
		return;
		
	if (!strcasecmp(cnvroot->name,user)) {
		cnvroot = cnvroot->next;
		return;
	} else {
		t = cnvroot;
		c = cnvroot->next;
		while(c) {
			if (!strcasecmp(c->name, user)) {
				t->next = c->next;
				free(c);
				return;
			}
			t = c;
			c = c->next;
		}
	}
}

void close_error(GtkWidget *w, GtkWidget *w2)
{
	gtk_widget_destroy(w2);
}


void close_invite(GtkWidget *w, GtkWidget *w2)
{
	gtk_widget_destroy(w2);
}


void chat_invite_callback(GtkWidget *w, GtkWidget *w2)
{
	int *i = gtk_object_get_user_data(GTK_OBJECT(w2));
	char buf[BUF_LONG];
	snprintf(buf, strlen(buf), "toc_chat_accept %d",  *i);
	sflap_send(buf, -1, TYPE_DATA);
	gtk_widget_destroy(w2);
}


void handle_error(char *c)
{

	int no = atoi(c);
	char *w = strtok(NULL, ":");
	char buf[256];
	char buf2[32];
	GtkWidget *d;
	GtkWidget *label;
	GtkWidget *close;
	
	
	switch(no) {
		case 901:
			snprintf(buf, sizeof(buf), "%s not logged on.", w);
			break;
		case 902:
			snprintf(buf, sizeof(buf), "Warning of %s not allowed.", w);
			break;
		case 903:
			snprintf(buf, sizeof(buf), "A message has been dropped, you are exceeding the server speed limit.");
			break;
		case 950:
			snprintf(buf, sizeof(buf), "Chat in %s is not available.", w);
			break;
		case 960:
			snprintf(buf, sizeof(buf), "You are sending messages too fast to %s.", w);
			break;
		case 961:
			snprintf(buf, sizeof(buf), "You missed an IM from %s because it was too big.", w);
			break;
		case 962:
			snprintf(buf, sizeof(buf), "You missed an IM from %s because it was sent too fast.", w);
			break;
		case 980:
			snprintf(buf, sizeof(buf), "Incorrect nickname or password.");
			break;
		case 981:
			snprintf(buf, sizeof(buf), "The service is temporarily unavailable.");
			break;
		case 982:
			snprintf(buf, sizeof(buf), "Your warning level is currently too high to log in.");
			break;
		case 983:
			snprintf(buf, sizeof(buf), "You have been connecting and disconnecting too frequently.  Wait ten minutes and try again.  If you continue to try, you will need to wait even longer.");
			break;
		case 989:
			snprintf(buf, sizeof(buf), "You have been connecting and disconnecting too frequently.  Wait ten minutes and try again.  If you continue to try, you will need to wait even longer.");
			break;
		default:
			snprintf(buf, sizeof(buf), "An unknown error, %d, has occured.  Info: %s", no, w);
	}
	
	d = gtk_dialog_new();

	label = gtk_label_new(buf);
	gtk_widget_show(label);
	close = gtk_button_new_with_label("Close");
	gtk_widget_show(close);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(d)->vbox),
		label, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(d)->action_area), 
		close, FALSE, FALSE, 5);
		
//	gtk_widget_set_usize(d, 200, 110);
/*	gtk_container_set_border_width(GTK_CONTAINER(d), 0);
*/
	snprintf(buf2, sizeof(buf2), "Error %d", no);
	gtk_window_set_title(GTK_WINDOW(d), buf2);
	gtk_signal_connect(GTK_OBJECT(close), "clicked", GTK_SIGNAL_FUNC(close_error), d);
//	aol_icon(d->window);
	gtk_widget_show(d);
}


void toc_callback( gpointer          data,
                            gint              source, 
                            GdkInputCondition condition )
{
	char buf[BUF_LEN];
	char *c;
	char *l;
	char *evil;
	char *signon;
	char *idle;
	char *uc;
	
	int sound;
	if (wait_reply(buf, sizeof(buf)) < 0) {
		signoff();
		hide_progress("Connection Closed");
		return;
	};
	c=strtok(buf+sizeof(struct sflap_hdr),":");	/* Ditch the first part */
	if (!strcasecmp(c,"UPDATE_BUDDY")) {
	
		struct person *p;
		
		c = strtok(NULL,":"); /* c is name */
		
		p = get_person(c);
		
		
		if (p == NULL) {
			printf("Error, no such person\n");
			return;
		}
		
		/* Parse! */
			
		
		l = strtok(NULL,":"); /* l is T/F logged status */
		
		if (!strncasecmp(l,"T",1))
			p->present = 1;
		else
			p->present = 0;
		
		evil = strtok(NULL, ":");
		sscanf(evil, "%d", &p->evil);
		
		signon = strtok(NULL, ":");
		sscanf(signon, "%ld", &p->signon);
		
		idle = strtok(NULL, ":");
		sscanf(idle, "%d", &p->idle);
		
		uc = strtok(NULL, ":");
/*		printf("%s:%s\n", c, uc); */
		p->uc = 0; /* Initialize this dumbass! *slap forehead */
		
		
		
		if (uc[0] == 'A')
			p->uc |= UC_AOL;
		
		switch(uc[1]) {
			case 'A':
				p->uc |= UC_ADMIN;
				break;
			case 'U':
				p->uc |= UC_UNCONFIRMED;
				break;
			case 'O':
				p->uc |= UC_NORMAL;
				break;
			default:
				break;
		}
		
		set_buddy(p);
		
	} else 
	if (!strcasecmp(c, "ERROR")) {
		c = strtok(NULL,":");
		handle_error(c);
	} else
	if (!strcasecmp(c, "NICK")) {
		c = strtok(NULL,":");
		snprintf(ourname, sizeof(ourname), "%s", c);
		fprintf(stdout, "We are %s\n",ourname);
	} else
	if (!strcasecmp(c, "IM_IN")) {
		char *a, *m;
#ifdef USE_XMHTML
		GtkWidget *html;
#else
		GtkWidget *text;
#endif
		c = strtok(NULL,":");
		a = strtok(NULL,":");
		m = a;
		while(*m && (*m != ':')) m++;
		m++;
#ifdef USE_XMHTML
		gethtmlw(c, &html, &sound);
		conv_write(html, c, a, m, sound);
#else
		gettextw(c, &text, &sound);
		conv_write(text, c, a, m, sound);
#endif
		if (awaymessage != NULL) {
			char tmp[BUF_LONG];
			snprintf(tmp, 1024, "toc_send_im %s \"%s\" auto", c, awaymessage->message);
			sflap_send(tmp, -1, TYPE_DATA);
#ifdef USE_XMHTML
			write_to_conv(html, ourname, awaymessage->message, WFLAG_SEND | WFLAG_AUTO);
#else
			write_to_conv(text, ourname, awaymessage->message, WFLAG_SEND | WFLAG_AUTO);
#endif
			
		}


	} else
	if (!strcasecmp(c, "GOTO_URL")) {
		char *name;
		char *url;

		char tmp[256];
		
		name = strtok(NULL, ":");
		url = strtok(NULL, ":");


		snprintf(tmp, sizeof(tmp), "http://%s:%d/%s", toc_addy, TOC_PORT, url);
#ifdef USE_GHTTP
		new_show_html(NULL,fix_url(tmp));
#else
		show_html(NULL, fix_url(tmp));
#endif /* USE_GHTTP */
//		fprintf(stdout, "Name: %s\n%s\n", name, url);
		
	} else
	if (!strcasecmp(c, "CHAT_JOIN")) {
		char *name;
		struct buddy_chat *b;
		b = chatroot;
	
		if (!b) {
			b = (struct buddy_chat *)malloc(sizeof(struct buddy_chat));
			chatroot = b;
		} else {
			while(b->next)
				b = b->next;
			b->next = (struct buddy_chat *)malloc(sizeof(struct buddy_chat));
			b = b->next;
		}
		b->next = NULL;
		sscanf(strtok(NULL, ":"), "%d", &b->id);
		name = strtok(NULL, ":");
		snprintf(b->name, 80, "%s", name);
		show_new_buddy_chat(b);

	} else
	if (!strcasecmp(c, "CHAT_UPDATE_BUDDY")) {
		int id;
		char *in;
		char *buddy;

		struct buddy_chat *b = chatroot;
		

		sscanf(strtok(NULL, ":"), "%d", &id);

		in = strtok(NULL, ":");

		while(b) {
			if (id == b->id)
				break;	
			b = b->next;

		}
		if (!b)
			return;

		
		if (!strcasecmp(in, "T")) {
			while((buddy = strtok(NULL, ":")) != NULL) {
				add_chat_buddy(b, buddy);
			}
		} else {
			while((buddy = strtok(NULL, ":")) != NULL) {
				remove_chat_buddy(b, buddy);
			}
		}

	} else
	if (!strcasecmp(c, "CHAT_LEFT")) {
		int id;
		struct buddy_chat *b = chatroot;
		struct buddy_chat *p = NULL;


		sscanf(strtok(NULL, ":"), "%d", &id);
		while(b) {
			if (id == b->id) {
				break;	
			}
			p = (struct buddy_chat *)b;
			b = b->next;

		}
		if (!b)
			return;

		gtk_widget_destroy(GTK_WIDGET(b->window));
		
		if (p) {
			p->next = b->next;
		} else {
			chatroot = NULL;
		}
			
		
		free((void *)b);
		b = NULL;

	} else
	if (!strcasecmp(c, "CHAT_IN")) {
		int id, w;
		char *who, *whisper, *message;
		struct buddy_chat *b = chatroot;

	
		sscanf(strtok(NULL, ":"), "%d", &id);
		who = strtok(NULL, ":");
		whisper = strtok(NULL, ":");
		message = strtok(NULL, ":");

		while(b) {
			if (id == b->id)
				break;	
			b = b->next;

		}
		if (!b)
			return;
		if (!strcasecmp(whisper, "T"))
			w = 1;
		else	
			w = 0;
	
		chat_write(b, who, w, message);

	} else
	if (!strcasecmp(c, "CHAT_INVITE")) {
		GtkWidget *d;
		GtkWidget *label;
		GtkWidget *yesbtn;
		GtkWidget *nobtn;
		char *name;
		char *who;
		char *message;
		int id;

		char buf2[BUF_LONG];

		name = strtok(NULL, ":");
		sscanf(strtok(NULL, ":"), "%d", &id);
		who = strtok(NULL, ":");
		message = strtok(NULL, ":");

		snprintf(buf2, sizeof(buf2), "User '%s' invites you to buddy chat room: '%s'\n%s", who, name, message);

		d = gtk_dialog_new();


		label = gtk_label_new(buf2);
		gtk_widget_show(label);
		yesbtn = gtk_button_new_with_label("Yes");
		gtk_widget_show(yesbtn);
		nobtn = gtk_button_new_with_label("No");
		gtk_widget_show(nobtn);
		gtk_box_pack_start(GTK_BOX(GTK_DIALOG(d)->vbox),
			label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(GTK_DIALOG(d)->action_area), 
			yesbtn, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(GTK_DIALOG(d)->action_area),
			nobtn, FALSE, FALSE, 5);


//		gtk_widget_set_usize(d, 200, 110);
		gtk_object_set_user_data(GTK_OBJECT(d), &id);


		gtk_window_set_title(GTK_WINDOW(d), "Buddy chat invite");
		gtk_signal_connect(GTK_OBJECT(nobtn), "clicked", GTK_SIGNAL_FUNC(close_invite), d);
		gtk_signal_connect(GTK_OBJECT(yesbtn), "clicked", GTK_SIGNAL_FUNC(chat_invite_callback), d);

	
		gtk_widget_show(d);
	} else {
		fprintf(stdout,"don't know what to do with %s\n", c);
	}
	
}


int toc_signon(char *username, char *password)
{
	char buf[BUF_LONG];
	int res;
	struct signon so;
	
	strncpy(ourname, username, sizeof(ourname));
	
	if ((res = write(toc_fd, FLAPON, strlen(FLAPON))) < 0)
		return res;
	/* Wait for signon packet */

	state = STATE_FLAPON;

	if ((res = wait_reply(buf, sizeof(buf)) < 0))
		return res;
	
	if (state != STATE_SIGNON_REQUEST) {
#ifdef DEBUG
		fprintf(stderr, "State should be %d, but is %d instead\n", STATE_SIGNON_REQUEST, state);
#endif
		return -1;
	}
	
	/* Compose a response */
	
	snprintf(so.username, sizeof(so.username), "%s", username);
	so.ver = ntohl(1);
	so.tag = ntohs(1);
	so.namelen = htons(strlen(so.username));	
	
	sflap_send((char *)&so, ntohs(so.namelen) + 8, TYPE_SIGNON);
	
	snprintf(buf, sizeof(buf), 
		"toc_signon %s %d %s %s %s \"%s\"",
		AUTH_HOST, AUTH_PORT, condense(username), roast_password(password), LANGUAGE, REVISION);
		
	return sflap_send(buf, -1, TYPE_DATA);
}

int toc_wait_signon()
{
	/* Wait for the SIGNON to be approved */
	char buf[BUF_LEN];
	int res;
	res = wait_reply(buf, sizeof(buf));
	if (res < 0)
		return res;
	if (state != STATE_SIGNON_ACK) {
#ifdef DEBUG
		fprintf(stderr, "State should be %d, but is %d instead\n",STATE_SIGNON_ACK, state);
#endif
		return -1;
	}
	return 0;
}
char *toc_wait_config()
{
	/* Waits for configuration packet, returning the contents of the packet */
	static char buf[BUF_LEN];
	char buf2[BUF_LEN];
	int res;
	res = wait_reply(buf, sizeof(buf));
	if (res < 0)
		return NULL;
	if (state != STATE_CONFIG) {
#ifdef DEBUG
		fprintf(stderr, "State should be %d, but is %d instead\n",STATE_CONFIG, state);
#endif
		return NULL;
	}
	snprintf(buf2, sizeof(buf2), "toc_init_done");
	sflap_send(buf2, -1, TYPE_DATA);
	/* At this point, it's time to setup automatic handling of incoming packets */
	inpa = gdk_input_add(toc_fd, GDK_INPUT_READ, toc_callback, NULL);
	return buf;
}
