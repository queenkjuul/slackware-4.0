/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#ifdef USE_XMHTML
#include <gtk-xmhtml/gtk-xmhtml.h>
#endif
#include "aim.h"
#include "pixmaps/bold.xpm"
#include "pixmaps/italic.xpm"
#include "pixmaps/small.xpm"
#include "pixmaps/normal.xpm"
#include "pixmaps/big.xpm"
#include "pixmaps/speaker.xpm"
#include "pixmaps/aimicon2.xpm"

int state_lock=0;

struct away_message *awaymessage;
struct conv *cnvroot;


static char *date()
{
	static char date[80];
	time_t tme;
	time(&tme);
	strftime(date, sizeof(date), "%H:%M:%S", localtime(&tme));
	return date;
}

int count_tag(GtkWidget *entry, char *s1, char *s2)
{
	char *p1, *p2;
	int res=0;
	char *tmp, *tmpo, h;
	tmpo = gtk_entry_get_text(GTK_ENTRY(entry));
	h = tmpo[GTK_EDITABLE(entry)->current_pos];
	tmpo[GTK_EDITABLE(entry)->current_pos]='\0';
	tmp=tmpo;
	do {
		p1 = strstr(tmp, s1);
		p2 = strstr(tmp, s2);
		if (p1 && p2) {
			if (p1 < p2) {
				res=1;
				tmp = p1 +strlen(s1);
			} else if (p2 < p1) {
				res = 0;
				tmp = p2 + strlen(s2);
			}
		} else {
			if (p1) {
				res = 1;
				tmp = p1 + strlen(s1);
			} else if (p2) {
				res = 0;
				tmp = p2 + strlen(s2);
			}
		}
	} while (p1 || p2);
	tmpo[GTK_EDITABLE(entry)->current_pos]=h;
	return res;
}

void quiet_set(GtkWidget *tb, int state)
{
	state_lock=1;
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(tb), state);
	state_lock=0;
}

int invert_tags(GtkWidget *entry, char *s1, char *s2, int really)
{
	int start = GTK_EDITABLE(entry)->selection_start_pos;
	int finish = GTK_EDITABLE(entry)->selection_end_pos;
	char *s;
	
	s = gtk_entry_get_text(GTK_ENTRY(entry));
	if (!strncasecmp(&s[start], s1, strlen(s1)) &&
	    !strncasecmp(&s[finish - strlen(s2)], s2, strlen(s2))) {
	   	if (really) {
	    		gtk_editable_delete_text(GTK_EDITABLE(entry), start, start + strlen(s1));
			gtk_editable_delete_text(GTK_EDITABLE(entry), finish - strlen(s2) - strlen(s1), finish - strlen(s1));
		}
		return 1;
	}
	return 0;
}


void remove_tags(GtkWidget *entry, char *tag)
{
	char *s;
	char *t;
	int start = GTK_EDITABLE(entry)->selection_start_pos;
	int finish = GTK_EDITABLE(entry)->selection_end_pos;
	s = gtk_entry_get_text(GTK_ENTRY(entry));
	t = s;
	while((t = strstr(t, tag))) {
		if (((t-s) < finish) && ((t-s) >= start)) 
			gtk_editable_delete_text(GTK_EDITABLE(entry), (t-s), (t-s) + strlen(tag));
		else t++;
	}
}

static void surround(GtkWidget *entry, char *pre, char *post)
{
	int pos = GTK_EDITABLE(entry)->current_pos;
	int dummy;
	int start, finish;
	if (GTK_EDITABLE(entry)->has_selection) {
		remove_tags(entry, pre);
		remove_tags(entry, post);
		start = GTK_EDITABLE(entry)->selection_start_pos;
		finish = GTK_EDITABLE(entry)->selection_end_pos;
		if (start > finish) {
			dummy = finish;
			finish = start;
			start = dummy;
		}
		dummy = start;
		gtk_editable_insert_text(GTK_EDITABLE(entry), pre, strlen(pre), &dummy);
		dummy = finish + strlen(pre);
		gtk_editable_insert_text(GTK_EDITABLE(entry), post, strlen(post), &dummy);
		gtk_editable_select_region(GTK_EDITABLE(entry), start, finish + strlen(pre) + strlen(post));
		
	} else {
		gtk_editable_insert_text(GTK_EDITABLE(entry), pre, strlen(pre), &pos);
		gtk_editable_insert_text(GTK_EDITABLE(entry), post, strlen(post), &dummy);
		gtk_entry_set_position(GTK_ENTRY(entry), pos);
	}
	gtk_widget_grab_focus(entry);
}

static void advance_past(GtkWidget *entry, char *pre, char *post)
{
	char *s, *s2;
	int pos;
	if (invert_tags(entry, pre, post, 1))
		return;
	s = gtk_entry_get_text(GTK_ENTRY(entry));
	pos = GTK_EDITABLE(entry)->current_pos;
#ifdef DEBUG
	printf("Currently at %d\n",pos);
#endif
	s2= strstr(&s[pos], post);
	if (s2)
		pos = s2 - s + strlen(post);
	else
		pos=-1;
#ifdef DEBUG
	printf("Setting position to %d\n",pos);
#endif
	gtk_entry_set_position(GTK_ENTRY(entry), pos);
	gtk_widget_grab_focus(entry);
}

static void do_bold(GtkWidget *bold, GtkWidget *entry)
{
	if (state_lock)
		return;
	if (GTK_TOGGLE_BUTTON(bold)->active)
		surround(entry, "<B>","</B>");
	else
		advance_past(entry, "<B>", "</B>");
}

static void do_italic(GtkWidget *italic, GtkWidget *entry)
{
	if (state_lock)
		return;
	if (GTK_TOGGLE_BUTTON(italic)->active)
		surround(entry, "<I>","</I>");
	else
		advance_past(entry, "<I>", "</I>");
}

static void do_small(GtkWidget *small, GtkWidget *entry)
{
	if (state_lock)
		return;
	surround(entry, "<FONT SIZE=\"+1\">","</FONT>");
}

static void do_normal(GtkWidget *normal, GtkWidget *entry)
{
	surround(entry, "<FONT SIZE=\"+3\">","</FONT>");
}

static void do_big(GtkWidget *big, GtkWidget *entry)
{
	surround(entry, "<FONT SIZE=\"+5\">","</FONT>");
}


struct both {
	char name[80];
#ifdef USE_XMHTML
	GtkWidget *html;
#else
	GtkWidget *text;
#endif
	GtkWidget *entry;
	GtkWidget *window;
	GtkWidget *italic;
	GtkWidget *bold;
	int *makesound;
	int mapped; /* Bad hack! Can't figure out minimization! */
};


void check_everything(GtkWidget *entry)
{
	struct both *b;
	b = (struct both *)gtk_object_get_user_data(GTK_OBJECT(entry));
	if (!b) return;
	if (invert_tags(entry, "<B>", "</B>", 0))
		quiet_set(b->bold, TRUE);
	else if (count_tag(entry, "<B>", "</B>")) 
		quiet_set(b->bold, TRUE);
	else
		quiet_set(b->bold,FALSE);
	if (invert_tags(entry, "<I>", "</I>", 0))
		quiet_set(b->italic, TRUE);
	else if (count_tag(entry, "<I>", "</I>"))  
		quiet_set(b->italic, TRUE);
	else
		quiet_set(b->italic, FALSE);
}


static int
entry_key_pressed(GtkWidget *w, GtkWidget *entry)
{
	check_everything(w);
	return TRUE;	
}


static int close_callback(GtkWidget *widget, struct both *both)
{
	both = (struct both *)gtk_object_get_user_data(GTK_OBJECT(widget));
	delcnv(both->name);
	gtk_widget_destroy(both->window);
	free(both);
	return TRUE;
}

static void add_callback(GtkWidget *widget, struct both *both)
{
	add_buddy_from_convo(both->name);
}

static void map_event_callback(GtkWidget *widget, struct both *both)
{
	struct both *bth = gtk_object_get_user_data(GTK_OBJECT(widget));
	aol_icon(widget->window);
	bth->mapped = 1;

}

static void unmap_event_callback(GtkWidget *widget, struct both *both)
{
	struct both *bth = gtk_object_get_user_data(GTK_OBJECT(widget));
	bth->mapped = 0;
}

static void info_callback(GtkWidget *widget, struct both *both)
{
	char *send = malloc(256);
	snprintf(send, 255, "toc_get_info %s", both->name);
	sflap_send(send, strlen(send), TYPE_DATA);
	free(send);
}

static void fix_text(GtkWidget *text)
{
	float f;
#if 0
	printf("Placing at (%f - %f) = %f\n",GTK_TEXT(text)->vadj->upper, (float)text->allocation.height, f);
#endif
	f = GTK_TEXT(text)->vadj->upper;
	f = f - text->allocation.height;
	if (f < 0)
		f=0;
	/* Special case */
	else if (text->allocation.height == 1) f = 0;
	while(gtk_events_pending())
		gtk_main_iteration();
	gtk_adjustment_set_value(GTK_TEXT(text)->vadj, f);
}




#ifdef USE_XMHTML
void write_to_conv(GtkWidget *html, char *who, char *what, int flags)
#else
void write_to_conv(GtkWidget *text, char *who, char *what, int flags)
#endif
{
	char buf[BUF_LONG];
	char buf2[BUF_LONG];


#ifndef USE_XMHTML
	
	GdkColor *colour;  
	static GdkColormap *map;
	struct both *both = gtk_object_get_user_data(GTK_OBJECT(text));	
	
	map = gdk_window_get_colormap(both->window->window);
	colour = (GdkColor *)malloc(sizeof(GdkColor));
	if (flags & WFLAG_SEND) {
		colour->red = 0;
		colour->green = 0;
		colour->blue = 65535;
	} else {
		colour->red = 65535;
		colour->green = 0;
		colour->blue = 0;
	}
	gdk_color_alloc(map, colour);

	if (flags & WFLAG_AUTO)
		sprintf(buf2, "%s", AUTO_RESPONSE);
	else
		buf2[0]=0; /* sprintf(buf2, ""); */

	if (show_time)
		snprintf(buf, sizeof(buf), "%s %s: %s", date(), who, buf2);
	else
		snprintf(buf, sizeof(buf), "%s: %s", who, buf2);
	gtk_text_set_point(GTK_TEXT(text), gtk_text_get_length(GTK_TEXT(both->text)));
	gtk_text_freeze(GTK_TEXT(text));
	gtk_text_insert(GTK_TEXT(text), getfont(1,0,0,3), colour, NULL, buf, strlen(buf));
	html_print(text, what);
	gtk_text_thaw(GTK_TEXT(text));
	fix_text(text);
#else
	char colour[10];
	
	if (flags & WFLAG_RECV)
		colour = "#0000ff";
	else
		colour = "#ff0000";

	if (flags & WFLAG_AUTO)
		sprintf(buf2, "%s", AUTO_RESPONSE);
	else
		buf2[0]=0; /* sprintf(buf2, ""); */

	if (show_time) 
		snprintf(buf, sizeof(buf), "<FONT COLOR=\"%s\"><B>%s %s: %s</B></FONT> ", colour, date(), who, buf2);
	else
		snprintf(buf, sizeof(buf), "<FONT COLOR=\"%s\"><B>%s: %s</B></FONT> ", colour, who, buf2);
	html_write(both->html, buf);
	html_write(both->html, what);
	html_write(both->html,"<BR>");
	html_update(both->html);

#endif
}
	

static void send_callback(GtkWidget *widget, struct both *both)
{
	char buf[BUF_LONG];
	char buf2[BUF_LONG];

	strncpy(buf, gtk_entry_get_text(GTK_ENTRY(both->entry)), sizeof(buf)/2);
	if (!strlen(buf))
		return;
#ifndef USE_XMHTML
	write_to_conv(both->text, ourname, buf, WFLAG_SEND);
#else
	write_to_conv(both->html, ourname, buf, WFLAG_SEND);
#endif

	gtk_entry_set_text(GTK_ENTRY(both->entry), "");

	escape_text(buf);
	snprintf(buf2, sizeof(buf2), "toc_send_im %s \"%s\"", condense(both->name), buf);
	sflap_send(buf2, -1, TYPE_DATA);
	quiet_set(both->bold, FALSE);
	quiet_set(both->italic, FALSE);
	if (*(both->makesound))
		play_sound(SEND);


	if (awaymessage != NULL) {
		do_im_back();
	}


	gtk_widget_grab_focus(both->entry);


}

#ifdef USE_XMHTML
void conv_write(GtkWidget *html, char *who, char *a, char *what, int sound)
#else
void conv_write(GtkWidget *text, char *who, char *a, char *what, int sound)
#endif
{
#ifndef USE_XMHTML
	struct both *bth = gtk_object_get_user_data(GTK_OBJECT(text));

	if (!strncasecmp(a, "T", 1))	
		write_to_conv(text, who, what, WFLAG_RECV | WFLAG_AUTO);
	else
		write_to_conv(text, who, what, WFLAG_RECV);
#else
	struct both *bth = gtk_object_get_user_data(GTK_OBJECT(html));
	if (!strncasecmp(a, "T", 1))	
		write_to_conv(html, who, what, WFLAG_RECV | WFLAG_AUTO);
	else
		write_to_conv(html, who, what, WFLAG_RECV);
#endif


	if (!bth->mapped) {
		GdkPixmap *icon_pm;
		GdkBitmap *icon_bm;
		icon_pm = gdk_pixmap_create_from_xpm_d(bth->window->window, &icon_bm,
			NULL, (gchar **)aimicon2_xpm);
		gdk_window_set_icon(bth->window->window, NULL, icon_pm, icon_bm);
	}



	if (sound)
		play_sound(RECEIVE);
}

void show_conv(struct conv *cnv)
{
	GtkWidget *win;
	char buf[256];
#ifdef USE_XMHTML
	GtkWidget *html;
#else
	GtkWidget *text;
#endif
	GtkWidget *send;
	GtkWidget *info;
	GtkWidget *warn;
	GtkWidget *color;
	GtkWidget *close;
	GtkWidget *add;
	GtkWidget *entry;
	GtkWidget *toolbar;
	GtkWidget *tbox;
	GtkWidget *bbox;
	GtkWidget *vbox;
#ifndef USE_XMHTML
	GtkWidget *vsb;
#endif
	GdkPixmap *bold_i;
	GtkWidget *bold_p;
	GdkPixmap *small_i;
	GtkWidget *small_p;
	GtkWidget *small;
	GdkPixmap *normal_i;
	GtkWidget *normal_p;
	GtkWidget *normal;
	GdkPixmap *big_i;
	GtkWidget *big_p;
	GtkWidget *big;
	GdkPixmap *italic_i;
	GtkWidget *italic_p;
	GdkPixmap *speaker_i;
	GtkWidget *speaker_p;
	GtkWidget *speaker;
	GtkWidget *italic=NULL;
	GtkWidget *bold=NULL;
	GdkBitmap *mask;
	struct both *bth;
	
	win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_realize(win);
	aol_icon(win->window);
	send = gtk_button_new_with_label("Send");
	info = gtk_button_new_with_label("Info");
	warn = gtk_button_new_with_label("Warn");
	color = gtk_button_new_with_label("Color");
	close = gtk_button_new_with_label("Close");
	add = gtk_button_new_with_label("Add");
#ifdef USE_XMHTML
	html = gtk_xmhtml_new();
#else
	text = gtk_text_new(NULL, NULL);
	GTK_OBJECT(text)->flags &= ~GTK_CAN_FOCUS;
#endif
	bbox = gtk_hbox_new(TRUE, 0);
	tbox = gtk_hbox_new(FALSE, 0);
	vbox = gtk_vbox_new(FALSE, 0);
	entry = gtk_entry_new();

	gtk_widget_realize(win);
	/* Toolbar */
	toolbar = gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_ICONS);
	speaker_i = gdk_pixmap_create_from_xpm_d ( win->window, &mask,
             &win->style->white, speaker_xpm );
	speaker_p = gtk_pixmap_new(speaker_i, mask);
	gtk_widget_show(speaker_p);
	cnv->makesound=1;
	bold_i = gdk_pixmap_create_from_xpm_d ( win->window, &mask,
             &win->style->white, bold_xpm );
	bold_p = gtk_pixmap_new(bold_i, mask);
	gtk_widget_show(bold_p);
	italic_i = gdk_pixmap_create_from_xpm_d ( win->window, &mask,
             &win->style->white, italic_xpm );
	italic_p = gtk_pixmap_new(italic_i, mask);
	gtk_widget_show(italic_p);
	small_i = gdk_pixmap_create_from_xpm_d ( win->window, &mask,
             &win->style->white, small_xpm );
	small_p = gtk_pixmap_new(small_i, mask);
	gtk_widget_show(small_p);
	normal_i = gdk_pixmap_create_from_xpm_d ( win->window, &mask,
             &win->style->white, normal_xpm );
	normal_p = gtk_pixmap_new(normal_i, mask);
	gtk_widget_show(normal_p);
	big_i = gdk_pixmap_create_from_xpm_d ( win->window, &mask,
             &win->style->white, big_xpm );
	big_p = gtk_pixmap_new(big_i, mask);
	gtk_widget_show(big_p);


	bold = gtk_toolbar_append_element(GTK_TOOLBAR(toolbar),
	                                  GTK_TOOLBAR_CHILD_TOGGLEBUTTON, NULL,
					  "Bold", "Bold Text", "Bold", bold_p,
					  GTK_SIGNAL_FUNC(do_bold), entry);
	italic = gtk_toolbar_append_element(GTK_TOOLBAR(toolbar), 
		                            GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
					    NULL, "Italics", "Italics Text",
					    "Italics", italic_p, GTK_SIGNAL_FUNC(do_italic), entry);
	gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
	small = gtk_toolbar_append_item(GTK_TOOLBAR(toolbar), "Small", "Decrease font size", "Small", small_p, GTK_SIGNAL_FUNC(do_small), entry);
	normal = gtk_toolbar_append_item(GTK_TOOLBAR(toolbar), "Normal", "Normal font size", "Normal", normal_p, GTK_SIGNAL_FUNC(do_normal), entry);
	big = gtk_toolbar_append_item(GTK_TOOLBAR(toolbar), "Big", "Increase font size", "Big", big_p, GTK_SIGNAL_FUNC(do_big), entry);
	gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
	speaker = gtk_toolbar_append_element(GTK_TOOLBAR(toolbar), 
		                            GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
					    NULL, "Sound", "Enable sounds",
					    "Sound", speaker_p, GTK_SIGNAL_FUNC(set_option), &cnv->makesound);
	cnv->makesound=0;
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(speaker), TRUE);
	gtk_widget_show(toolbar);
	
	bth = (struct both *)malloc(sizeof (struct both));
	bth->window = win;
#ifdef USE_XMHTML
	bth->html = html;
#else
	bth->text = text;
#endif
	bth->entry = entry;
	bth->makesound = &cnv->makesound;
	bth->bold = bold;
	bth->italic = italic;
	
	gtk_object_set_user_data(GTK_OBJECT(entry), bth);

	

	gtk_signal_connect(GTK_OBJECT(entry), "activate", GTK_SIGNAL_FUNC(send_callback),bth);
	/* Text box */
#ifdef USE_XMHTML
	gtk_box_pack_start(GTK_BOX(tbox), html, FALSE, FALSE, 0);
#else
	gtk_box_pack_start(GTK_BOX(tbox), text, TRUE, TRUE, 0);
  	vsb = gtk_vscrollbar_new (GTK_TEXT(text)->vadj);
	gtk_text_set_word_wrap(GTK_TEXT(text), TRUE);
        gtk_box_pack_start(GTK_BOX(tbox), vsb, FALSE, FALSE, 0);
        gtk_widget_show (vsb);	
#endif

#ifdef USE_XMHTML
	gtk_widget_set_usize(html, 320, 150);
#else	
	gtk_widget_set_usize(text, 320, 150);
#endif

	/* Ready and pack buttons */
	gtk_object_set_user_data(GTK_OBJECT(win), bth);
	gtk_object_set_user_data(GTK_OBJECT(close), bth);
	gtk_signal_connect(GTK_OBJECT(close), "clicked", GTK_SIGNAL_FUNC(close_callback),bth);
	gtk_signal_connect(GTK_OBJECT(send), "clicked", GTK_SIGNAL_FUNC(send_callback),bth);
	gtk_signal_connect(GTK_OBJECT(add), "clicked", GTK_SIGNAL_FUNC(add_callback), bth);
	gtk_signal_connect(GTK_OBJECT(info), "clicked", GTK_SIGNAL_FUNC(info_callback), bth);

	gtk_box_pack_start(GTK_BOX(bbox), send, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(bbox), info, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(bbox), warn, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(bbox), color, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(bbox), add, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(bbox), close, TRUE, TRUE, 5);
	
	/* pack and fill the rest */

	
	gtk_box_pack_start(GTK_BOX(vbox), tbox, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), toolbar, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), entry, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);

	


	gtk_widget_show(send);
	gtk_widget_show(info);
	gtk_widget_show(warn);
	gtk_widget_show(color);
	gtk_widget_show(close);	
	gtk_widget_show(add);
	gtk_widget_show(bbox);
	gtk_widget_show(vbox);
	gtk_widget_show(tbox);
	gtk_widget_show(entry);
#ifdef GTK_XMHTML
	gtk_widget_show(html);
#if 0
	gtk_xmhtml_source(GTK_XMHTML(html), "<BODY BGCOLOR=white><H2>This <U>is</U> <A HREF=\"http://localhost\">a link</A></H2></BODY><BR><FONT BACK=blue><H3>Some more sample text</H3></FONT>");
#endif
	gtk_object_set_user_data(GTK_OBJECT(html), bth);
#else
	gtk_object_set_user_data(GTK_OBJECT(text), bth);
	gtk_widget_show(text);
#endif
	
	gtk_container_add(GTK_CONTAINER(win),vbox);
	gtk_container_border_width(GTK_CONTAINER(win), 10);
	snprintf(buf, sizeof(buf), "Conversation with %s\n",cnv->name);
	gtk_window_set_title(GTK_WINDOW(win), buf);
	gtk_window_set_focus(GTK_WINDOW(win),entry);
	snprintf(bth->name, sizeof(bth->name), "%s", cnv->name);
#ifdef USE_XMHTML
	cnv->html = html;
#else
	cnv->text = text;
#endif

	gtk_signal_connect(GTK_OBJECT(win), "delete_event", GTK_SIGNAL_FUNC(close_callback),bth);
	gtk_signal_connect(GTK_OBJECT(win), "unmap_event", GTK_SIGNAL_FUNC(unmap_event_callback), bth);
	gtk_signal_connect(GTK_OBJECT(win), "map_event", GTK_SIGNAL_FUNC(map_event_callback), bth);
	gtk_signal_connect(GTK_OBJECT(entry), "key_press_event", GTK_SIGNAL_FUNC(entry_key_pressed), NULL);
	
	gtk_widget_show(win);
	
}


