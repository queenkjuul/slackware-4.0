/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#if (GTK_MINOR_VERSION < 1)
#define OLD_GTK
#else
#undef OLD_GTK
#endif

#define GAIM_VERSION "0.01"

#ifdef USE_APPLET
#include <applet-lib.h>
#endif /* USE_APPLLET */

struct person {
	char name[80];
	GtkWidget *item;
	GtkWidget *label;
	GtkWidget *pix;
	GtkWidget *idletime;
	int present;
	int evil;
	long signon;
	int idle;
	int uc;
	struct person *next;
};

struct away_message {
	char name[80];
	char message[1024];
	struct away_message *next;
};

#define UC_AOL		1
#define UC_ADMIN 	2
#define UC_UNCONFIRMED	4
#define UC_NORMAL	8

#define WFLAG_SEND 1
#define WFLAG_RECV 2
#define WFLAG_AUTO 4


#define AUTO_RESPONSE "<AUTO-REPLY> : "

struct category {
	GtkWidget *item;
	GtkWidget *tree;
	char name[80];
	struct person *members;
	struct category *next;
};

struct buddy_chat {
	GtkWidget *window;
	GtkWidget *text;
	GtkWidget *list;
	GtkWidget *entry;
	int makesound;
	int id;
	char name[80];
	struct buddy_chat *next;
};

struct conv {
	char name[80];
#ifdef USE_XMHTML
	GtkWidget *html;
#else
	GtkWidget *text;
#endif
	int makesound;
	struct conv *next;
};

/*
	1.  gethostbyname();
	2.  connect();
	3.  toc_signon();
	4.  toc_wait_signon();
	5.  toc_wait_config();
	6.  actually done..
*/

#define STATE_FLAPON 1
#define STATE_SIGNON_REQUEST 2
#define STATE_SIGNON_ACK 3
#define STATE_CONFIG 4

struct sflap_hdr {
	unsigned char ast;
	unsigned char type;
	unsigned short seqno;
	unsigned short len;
};

struct signon {
	unsigned int ver;
	unsigned short tag;
	unsigned short namelen;
	char username[80];
};

#define LOGIN_STEPS 5


/* These should all be runtime selectable */

#define TOC_HOST "toc.oscar.aol.com"
#define TOC_PORT 9898
#define AUTH_HOST "login.oscar.aol.com"
#define AUTH_PORT 5190
#define LANGUAGE "english"

#define BUF_LEN 1024
#define BUF_LONG BUF_LEN * 2


#define TYPE_SIGNON    1  
#define TYPE_DATA      2
#define TYPE_ERROR     3
#define TYPE_SIGNOFF   4
#define TYPE_KEEPALIVE 5

#define VERSION 0001

#undef EXACT

#ifdef EXACT
#define REVISION "TIK:$Revision: 1.32 $"
#define FLAPON "FLAPON\r\r\n\r\r\nFLAPON\r\r\n\r\r\n"
#else
#define REVISION "gaim:$Revision: 1.32 $"
#define FLAPON "FLAPON\r\n\r\n"
#endif

#define ROAST "Tic/Toc"

#define STYLE_ITALIC 0x01000000
#define STYLE_BOLD 0x020000000

#define FIXED_FONT "-*-courier-medium-r-*-*-*-%d-*-*-*-*-*-*"
#define FIXED_BOLD_FONT "-*-courier-bold-r-*-*-*-%d-*-*-*-*-*-*"
#define FIXED_ITALIC_FONT "-*-courier-medium-o-*-*-*-%d-*-*-*-*-*-*"
#define FIXED_BOLD_ITALIC_FONT "-*-courier-bold-o-*-*-*-%d-*-*-*-*-*-*"
#define PROP_FONT "-*-helvetica-medium-r-*-*-*-%d-*-*-*-*-*-*"
#define PROP_BOLD_FONT "-*-helvetica-bold-r-*-*-*-%d-*-*-*-*-*-*"
#define PROP_ITALIC_FONT "-*-helvetica-medium-o-*-*-*-%d-*-*-*-*-*-*"
#define PROP_BOLD_ITALIC_FONT "-*-helvetica-bold-o-*-*-*-%d-*-*-*-*-*-*"

#define BUDDY_ARRIVE 0
#define BUDDY_LEAVE 1
#define SEND 2
#define RECEIVE 3

extern char *quad_addr;
extern void show_buddy_list();
#ifdef USE_APPLET
extern void applet_show_login(AppletWidget *widget, gpointer data);
extern GtkWidget *applet;
#endif /* USE_APPLET */
extern unsigned int *get_address(char *);
extern char *fix_url(char *);
#ifdef USE_GHTTP
extern void new_show_html(GtkWidget *, char *);
#endif /* USE_GHTTP */
extern void show_html(GtkWidget *, char *);
extern int connect_address(unsigned int, unsigned short);
extern int toc_signon(char *, char *);
extern int toc_wait_signon(void);
extern char *toc_wait_config(void);
extern void add_buddy_from_convo(char *);
extern void show_buddy_list(char *);
extern void join_chat();
extern int sflap_send(char *, int , int );
extern struct person *get_person(char *);
extern void set_buddy(struct person *);
extern void show_im(char *who);
extern void show_conv(struct conv *);
extern int escape_text(char *);
extern void show_new_buddy_chat(struct buddy_chat *);
extern void add_chat_buddy(struct buddy_chat *, char *);
extern void remove_chat_buddy(struct buddy_chat *, char *);
extern void chat_write(struct buddy_chat *, char *, int, char *);
extern void handle_error(char *);
extern char toc_addy[];
extern void delcnv(char *);
#ifdef USE_XMHTML
extern void html_write(GtkWidget *, char *);
extern void html_update(GtkWidget *);
#else
extern void html_print(GtkWidget *text, char *buf);

#endif
extern void conv_write(GtkWidget *, char *, char *, char *, int);
void write_to_conv(GtkWidget *, char *, char *, int);
extern GdkFont *getfont(int, int, int, int);
extern void display_login();
extern void destroy_buddy();
extern void signoff();
extern void toc_close();
extern void hide_progress(char *);
extern void show_prefs();
extern void play_sound(int);
extern void do_im_back();
extern char *condense(char *);
extern void set_option(GtkWidget *, int *);
extern void load_prefs();
extern void save_prefs();

extern int sounds;
extern int extrasounds;
extern int enter_sends;
extern int show_time;
extern int remember_pass;
extern int auto_login;
extern char ourname[];
extern char mypassword[];
extern struct conv *cnvroot;
extern struct buddy_chat *chatroot;
extern struct away_message *awayroot;
extern struct away_message *awaymessage;
extern void show_away_message();

extern void aol_icon(GdkWindow *);
