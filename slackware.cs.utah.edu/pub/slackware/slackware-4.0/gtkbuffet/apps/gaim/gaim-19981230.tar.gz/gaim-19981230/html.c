/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>
#include <gtk/gtk.h>
#ifdef USE_XMHTML
#include <gtk-xmhtml/gtk-xmhtml.h>
#endif
#ifdef USE_GHTTP
#include <ghttp.h>
#endif /* USE_GHTTP */
#include "aim.h"

#define MAX_SIZE 7

int font_sizes[] = { 80, 100, 120, 140, 200, 300, 400 };

GdkFont *fixed_font[] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL };
GdkFont *fixed_bold_font[] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL };
GdkFont *fixed_italic_font[] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL };
GdkFont *fixed_bold_italic_font[] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL };
GdkFont *prop_font[] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL };
GdkFont *prop_bold_font[] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL };
GdkFont *prop_italic_font[] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL };
GdkFont *prop_bold_italic_font[] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL };

struct font_state {
	int size;
	int owncolor;
	int ownbg;
	GdkColor *color;
	GdkColor *bgcol;
	struct font_state *next;
};

struct font_state *push_state(struct font_state *current)
{
	struct font_state *tmp;
	tmp = (struct font_state *)malloc(sizeof(struct font_state));
	tmp->next = current;
	tmp->color = current->color;
	tmp->bgcol = current->bgcol;
	tmp->size = current->size;
	tmp->owncolor = 0;
	tmp->ownbg = 0;
	return tmp;
}

char *fix_url(gchar *buf) {
  char *new,*tmp;
  int size;

  size=8;
  size+=strlen(quad_addr);
  tmp=strchr(strchr(buf,':')+1,':');
  size+=strlen(tmp);
  new=malloc(size);
  strcpy(new,"http://");
  strcat(new,quad_addr);
  strcat(new,tmp);
  return(new);
}

void show_html(GtkWidget *ignored, char *msg)
{
	char buf[BUF_LEN];
	snprintf(buf, sizeof(buf), "netscape -remote 'OpenURL(%s)'", msg);
	system(buf);
}

#ifdef USE_GHTTP
void new_show_html(GtkWidget *ignored, char *msg)
{
  ghttp_request *req = ghttp_request_new();

  ghttp_set_uri(req,msg);
  ghttp_set_header(req, http_hdr_Connection, "close");
  ghttp_prepare(req);
  ghttp_process(req);
  printf("-----\n%s\n-----",ghttp_get_body(req));
  ghttp_close(req);
  ghttp_clean(req);
}
#endif /* USE_GHTTP */

void show_info(char *who)
{
}

#ifdef USE_XMHTML
void html_write(GtkWidget *html, char *buf)
{
	char *c;
	int d;
	c = (char *)gtk_object_get_user_data(GTK_OBJECT(html));
	if (c)
		d = strlen(c);
	else
		d=0;
	c = (char *)realloc(c, d + strlen(buf) + 1);
	strcpy(&c[d], buf);
	gtk_object_set_user_data(GTK_OBJECT(html), c);
	fprintf(stdout,"Set html to '%s'\n", c);
}

void html_update(GtkWidget *html)
{
	gtk_xmhtml_source(GTK_XMHTML(html), (char *)gtk_object_get_user_data(GTK_OBJECT(html)));
	gtk_adjustment_set_value(GTK_ADJUSTMENT(GTK_XMHTML(html)->vsba), 1);
}

#else
GdkColor *get_color(int colorv, GdkColormap *map)
{
	GdkColor *color;
#if 0	
	fprintf(stdout,"color is %x\n",colorv);
#endif									
	color = (GdkColor *)malloc(sizeof(GdkColor));
	color->red = ((colorv & 0xff0000) >> 16) * 256;
	color->green = ((colorv & 0xff00) >> 8) * 256;
	color->blue = ((colorv & 0xff)) * 256;
#if 0
	fprintf(stdout,"Colors are %d, %d, %d\n",color->red, color->green, color->blue);
#endif
	gdk_color_alloc(map, color);
	return color;
	
}


void html_print(GtkWidget *text, char *buf)
{
	GdkColormap *map;
	GdkFont *cfont;
	char ws[BUF_LEN], tag[BUF_LEN], *c;
	int intag=0,wpos=0, tpos=0, colorv, bold=0, italic=0, fixed=0;
	struct font_state *current, *tmp;
	struct font_state def_state = { 3, 0, 0, NULL, NULL, NULL };
	
	current = &def_state;
	map = gdk_window_get_colormap(text->window);
	cfont = getfont(bold, italic, fixed, current->size);
	c=buf;
	while(*c) {
		if (*c == '<') {
			if (!intag) {
				ws[wpos]=0;
				if (wpos) 
					gtk_text_insert(GTK_TEXT(text), cfont, current->color, current->bgcol, ws, strlen(ws));
				wpos=0;
				intag=1;
			} else {
				tag[tpos++]=*c;
			}
		} else if (*c == '>') {
			if (intag) {
				tag[tpos]=0;
				if (!strcasecmp(tag, "B"))
					bold = 1;
				else if (!strcasecmp(tag, "I"))
					italic = 1;
				else if (!strcasecmp(tag, "PRE"))
					fixed = 1;
				else if (!strcasecmp(tag, "/B"))
					bold = 0;
				else if (!strcasecmp(tag, "/I"))
					italic = 0;
				else if (!strcasecmp(tag, "/PRE"))
					fixed = 0;
				else if (!strncasecmp(tag,"FONT", strlen("FONT"))) {
					char *d;
					/* Push a new state onto the stack, based on the old state */
					current = push_state(current);
					strtok(tag," ");
					while((d=strtok(NULL," "))) {
						if (!strncasecmp(d,"COLOR=",strlen("COLOR="))) {
							d+=strlen("COLOR=");
							if (*d == '\"') d++;
							if (*d == '#') d++;
							if (sscanf(d, "%x", &colorv)) {
								current->color = get_color(colorv, map);
								current->owncolor = 1;
							} else fprintf(stdout,"didn't find color in '%s'\n",d);
						} else 
						if (!strncasecmp(d,"BACK=",strlen("BACK="))) {
							d+=strlen("BACK=");
							if (*d == '\"') d++;
							if (*d == '#') d++;
							if (sscanf(d, "%x", &colorv)) {
								current->bgcol = get_color(colorv, map);
								current->ownbg = 1;
							} else fprintf(stdout,"didn't find color in '%s'\n",d);
						} else if (!strncasecmp(d,"SIZE=",strlen("SIZE="))) {
							d+=strlen("SIZE=");
							if (*d == '\"') d++;
							if (*d == '+') d++;
							if (sscanf(d, "%d", &colorv)) {
#if 0
								fprintf(stdout,"size is %d\n",colorv);
#endif									
								current->size = colorv;
							} else fprintf(stdout,"didn't find size in '%s'\n",d);
						} else if (strncasecmp(d,"PTSIZE=", strlen("PTSIZE="))) {
							fprintf(stdout,"Unknown font keyword '%s'\n",d);
						}
					}
				} else if (!strncasecmp(tag,"BODY BGCOLOR", strlen("BODY BGCOLOR"))) {
					/* Ditch trailing \" */
					tag[strlen(tag)-1]=0;
					if (sscanf(tag + strlen("BODY BGCOLOR=\"#"), "%x", &colorv)) {
						current->bgcol = get_color(colorv, map);
						current->ownbg = 1;
					}
				} else if (!strcasecmp(tag, "/FONT")) {
					/* Pop a font state off the list if possible, freeing
					   any resources it used */
					if (current->next) {
						if (current->ownbg)
							free(current->bgcol);
						if (current->owncolor)
							free(current->color);
						tmp=current;
						current=current->next;
						free(tmp);
					}
						
				} else if (!strcasecmp(tag, "/BODY")) {
					if (current->next) {
						if (current->ownbg)
							free(current->bgcol);
						if (current->owncolor)
							free(current->color);
						tmp=current;
						current=current->next;
						free(tmp);
					}	/* tags we ignore below */
				} else if (!strcasecmp(tag, "BR")) {
						gtk_text_insert(GTK_TEXT(text), cfont, current->color, current->bgcol, "\n", 1);

				} else if (strcasecmp(tag, "HTML") && strcasecmp(tag, "/HTML") &&
					   strcasecmp(tag, "P") && strcasecmp(tag, "/P")){
					if (tpos) {
						gtk_text_insert(GTK_TEXT(text), cfont, current->color, current->bgcol, "<", 1);
						gtk_text_insert(GTK_TEXT(text), cfont, current->color, current->bgcol, tag, strlen(tag));
						gtk_text_insert(GTK_TEXT(text), cfont, current->color, current->bgcol, ">", 1);
					}
					fprintf(stdout,"tag: %s\n",tag);
				}
				cfont = getfont(bold,italic,fixed,current->size);
				tpos=0;
				intag = 0;
			} else {
				ws[wpos++]=*c;
			}
		} else {
			if (intag) {
				tag[tpos++]=*c;
			} else {
				ws[wpos++]=*c;
			}
		}
		c++;
	}
	while(current->next) {
		if (current->ownbg)
			free(current->bgcol);
		if (current->owncolor)
			free(current->color);
		tmp = current;
		current = current->next;
		free(tmp);
	}
	ws[wpos]=0;
	tag[tpos]=0;
	if (wpos) {
		gtk_text_insert(GTK_TEXT(text), cfont, current->color, current->bgcol, ws, strlen(ws));
	}
	if (tpos) {
		gtk_text_insert(GTK_TEXT(text), cfont, current->color, current->bgcol, "<", 1);
		gtk_text_insert(GTK_TEXT(text), cfont, current->color, current->bgcol, tag, strlen(tag));
	}
	gtk_text_insert(GTK_TEXT(text), cfont, current->color, current->bgcol, "\n", 1);
}


GdkFont *font_load(char *fmt, int size)
{
	char buf[256];
	snprintf(buf, sizeof(buf), fmt, font_sizes[size]);
#ifdef DEBUG
	printf("loading font %s\n",buf);
#endif
	return gdk_font_load(buf);
}

GdkFont *getfont(int bold, int italic, int fixed, int size)
{
	if (size > MAX_SIZE) size = MAX_SIZE;
	if (size < 1) size=1;
	size--;
	if (fixed) {
		if (bold) {
			if (italic) {
				if (!fixed_bold_italic_font[size])
					fixed_bold_italic_font[size] = font_load(FIXED_BOLD_ITALIC_FONT,size);
				return fixed_bold_italic_font[size];
					
			} else {
				if (!fixed_bold_font[size])
					fixed_bold_font[size] = font_load (FIXED_BOLD_FONT,size);
				return fixed_bold_font[size];
			}
		} else if (italic) {
			if (!fixed_italic_font[size])
				fixed_italic_font[size] = font_load(FIXED_ITALIC_FONT,size);
				
			return fixed_italic_font[size];
		} else {
			if (!fixed_font[size]) 
				fixed_font[size] = font_load(FIXED_FONT,size);
			return fixed_font[size];
		}
	} else {
		if (bold) {
			if (italic) {
				if (!prop_bold_italic_font[size])
					prop_bold_italic_font[size] = font_load(PROP_BOLD_ITALIC_FONT,size);
				return prop_bold_italic_font[size];
					
			} else {
				if (!prop_bold_font[size])
					prop_bold_font[size] = font_load (PROP_BOLD_FONT,size);
				return prop_bold_font[size];
			}
		} else if (italic) {
			if (!prop_italic_font[size])
				prop_italic_font[size] = font_load(PROP_ITALIC_FONT,size);
				
			return prop_italic_font[size];
		} else {
			if (!prop_font[size]) 
				prop_font[size] = font_load(PROP_FONT,size);
			return prop_font[size];
		}
	}
}

#endif
