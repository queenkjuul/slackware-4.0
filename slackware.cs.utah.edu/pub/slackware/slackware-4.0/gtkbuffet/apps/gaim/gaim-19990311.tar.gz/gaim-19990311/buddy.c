/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#ifdef USE_APPLET
#include <gnome.h>
#include <applet-widget.h>
#endif /* USE_APPLET */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <gtk/gtk.h>
#include "aim.h"
#include "pixmaps/admin_icon.xpm"
#include "pixmaps/aol_icon.xpm"
#include "pixmaps/free_icon.xpm"
#include "pixmaps/dt_icon.xpm"
#include "pixmaps/no_icon.xpm"
#include "pixmaps/login_icon.xpm"
#include "pixmaps/logout_icon.xpm"

static void do_away_menu();

static GtkTooltips *tips;
static GtkWidget *buddies;
static GtkWidget *addbuddy=NULL;
static GtkWidget *editpane;
static GtkWidget *buddypane;
static GtkWidget *permitpane;
static GtkWidget *awaymess=NULL;
static GtkWidget *imaway=NULL;
static GtkWidget *entryaway;
static GtkWidget *titleaway;
static GtkWidget *addbudentry;
static GtkWidget *addpermentry;
static GtkWidget *addperm;
static GtkWidget *combo;
static GtkWidget *tree;
static GtkWidget *permtree;
static GtkWidget *blist;
static GtkWidget *awaymenu;


struct category *croot=NULL;
char ourname[80];
int permdeny;
GList *permit;
GList *deny;
struct conv *cnvroot;
struct away_message *awaymessage = NULL;
struct away_message *awayroot = NULL;

void destroy_buddy()
{
	if (blist)
		gtk_widget_destroy(blist);
	blist=NULL;
}

void destroy_add_perm()
{
        if (addperm)
                gtk_widget_destroy(addperm);
        addperm=NULL;
}

void update_num_categories()
{
        struct category *c = croot;
        int pres, total;
        char buf[BUF_LONG];
        struct person *m;
        if (!show_cat_nums)
                return;
        while(c) {
                m = c->members;
                pres = 0;
                total = 0;
                while(m) {
                        if (m->present)
                                pres++;
                        total++;


                        m = m->next;
                }
                g_snprintf(buf, sizeof(buf), "%s  (%d/%d)", c->name, pres, total);
                gtk_label_set(GTK_LABEL(c->label), buf);
                c = c->next;

        }
        
}

#ifdef USE_APPLET
void applet_destroy_buddy() {
        struct category *c, *c2;
        struct person *p, *p2;
        c = croot;
        while(c) {
                p = c->members;
                while(p) {
                        p2 = p;
                        p = p->next;
                        g_free(p2);
                }
                c2 = c;
                c = c->next;
                g_free(c2);
        }
        croot=NULL;
	destroy_buddy();
        applet_widget_unregister_callback(APPLET_WIDGET(applet),"away");
	if(!awaymess)
        	applet_widget_register_callback(APPLET_WIDGET(applet),
      			"away",
                	_("Away Message"),
                	show_away_mess,
                	NULL);
	else
		applet_widget_register_callback(APPLET_WIDGET(applet),
                	"away",
                        _("Back"),
                        (AppletCallbackFunc) do_im_back,
                        NULL);
	if(!blist) {
		applet_widget_register_callback(APPLET_WIDGET(applet),
			"buddy",
			_("Buddy List"),
			(AppletCallbackFunc)make_buddy,
			NULL);
	}
}
#endif

static void destroy_add_buddy()
{
	if (addbuddy)
		gtk_widget_destroy(addbuddy);
	addbuddy=NULL;
}


static void destroy_away_mess()
{
	if (awaymess)
		gtk_widget_destroy(awaymess);
	awaymess=NULL;
}


#ifndef USE_APPLET
static void destroy_im_away()
{
	if (imaway)
		gtk_widget_destroy(imaway);
	imaway=NULL;
}
#endif /* USE_APPLET */


void signoff()
{
	struct category *c, *c2;
	struct person *p, *p2;
	c = croot;
	while(c) {
		p = c->members;
		while(p) {
			p2 = p;
			p = p->next;
			g_free(p2);
		}
		c2 = c;
		c = c->next;
		g_free(c2);
	}
        croot=NULL;
	toc_close();
	destroy_add_buddy();
	destroy_buddy();
	hide_progress("");
#ifdef USE_APPLET
        applet_widget_unregister_callback(APPLET_WIDGET(applet),"signoff");
	applet_widget_unregister_callback(APPLET_WIDGET(applet),"away");
	applet_widget_unregister_callback(APPLET_WIDGET(applet),"buddy");
        applet_widget_register_callback(APPLET_WIDGET(applet),
                "signon",
                _("Signon"),
                applet_show_login,
                NULL);
#else
        display_login();
#endif /* USE_APPLET */
}

void handle_click_category(GtkWidget *widget, GdkEventButton *event, gpointer func_data)
{
	if (event->type == GDK_2BUTTON_PRESS) {
		if (GTK_TREE_ITEM(widget)->expanded)
			gtk_tree_item_collapse(GTK_TREE_ITEM(widget));
		else
			gtk_tree_item_expand(GTK_TREE_ITEM(widget));
	} else {
	}
#if 0
	gtk_tree_item_select(GTK_TREE_ITEM(widget));
#endif
}

void handle_click_person(GtkWidget *widget, GdkEventButton *event, struct person *p)
{

	if (event->type == GDK_2BUTTON_PRESS) {
		show_im(p->name);
	} else {
	}
#if 0
	gtk_tree_item_select(GTK_TREE_ITEM(widget));
#endif
}



void remove_person(char *cat, char *person)
{
	struct category *c;
	int elsewhere=0;
	struct person *p, *p2;

	
	c = croot;
	while(c) {
		if (!strcasecmp(c->name, cat)) {
			p = c->members;
			p2 = c->members;
			if (!p) continue;
			
			while(p) {
				if (!strcasecmp(p->name, person)) {

//					printf("Found '%s' in group '%s'\n", p
//					       ->name, c->name);
					if (p == c->members)
                                                c->members = p->next;
					else
						p2->next = p->next;
					gtk_tree_remove_item(GTK_TREE(c->tree), p->item);
					g_free(p);
				}
				p2 = p;
				p=p->next;
			}
		} else {
			p = c->members;
			while(p) {
				if (!strcasecmp(p->name, person))
					elsewhere++;
				p=p->next;
			}
		}
		c=c->next;
	}
	if (!elsewhere) {
		char buf[BUF_LONG];
		g_snprintf(buf, sizeof(buf)/2, "toc_remove_buddy %s", condense(person));
#if 0
		fprintf(stdout, "Sending '%s'\n",buf);
#endif
		sflap_send(buf, -1, TYPE_DATA);
        }
        update_num_categories();
}

void remove_category(char *cat)
{
        struct category *c = croot, *c2 = croot;
        struct person *p, *p2;


	
        while(c) {
                if (!strcasecmp(c->name, cat)) {
                        // hide it first for speed
                        gtk_widget_hide(c->item);
                        p = c->members;
                        while(p) {
                                p2 = p->next;
                                remove_person(c->name, p->name);
                                // use this so it gets taken care of
                                // the right way, tho maybe a little
                                // slower;
                                p = p2;
                        }
                        gtk_tree_remove_item(GTK_TREE(buddies), c->item);
                        if (c == croot) {
                                if (c->next)
                                        croot = c->next;
                                else
                                        croot = NULL;
                        } else {
                                c2->next = c->next;
                        }

                        g_free(c);




                        c = croot;
                        while (c) {
//                                printf("A%s\n", c->name);
                                c = c->next;
                        }
                        return;
                        
                

                }
                c2 = c;
                c = c->next;
        }
}


void build_config(char *s, int len)
{
	struct category *c = croot;
        struct person *p;
        GList *plist = permit;
        GList *dlist = deny;
        int pos=0;
        if (!permdeny)
                permdeny = 1;
	pos += g_snprintf(&s[pos], len - pos, "toc_set_config {m %d\n", permdeny);
	while(c) {
		pos += g_snprintf(&s[pos], len - pos, "g %s\n", c->name);
		p = c->members;
		while(p) {
			pos += g_snprintf(&s[pos], len - pos, "b %s\n", condense(p->name));
			p=p->next;
		}
		c=c->next;
        }
        while(plist) {
                pos += g_snprintf(&s[pos], len - pos, "p %s\n", condense((char *)plist->data));
                plist=plist->next;

        }
        while(dlist) {
                pos += g_snprintf(&s[pos], len - pos, "d %s\n", condense((char *)dlist->data));
                dlist=dlist->next;
        }
	pos += g_snprintf(&s[pos], len - pos, "}");
}

static void build_permit_tree()
{
	GtkWidget *ti;
        GtkWidget *sub;
        GList *plist = permit;
        GList *dlist = deny;


        ti = gtk_tree_item_new_with_label("Permit");
        sub = gtk_tree_new();
        gtk_widget_show(ti);
        gtk_widget_show(sub);
        gtk_tree_prepend(GTK_TREE(permtree), ti);
        gtk_tree_item_set_subtree(GTK_TREE_ITEM(ti), sub);
        gtk_tree_item_expand(GTK_TREE_ITEM(ti));
        
        while(plist) {
                ti = gtk_tree_item_new_with_label((char *)plist->data);
                gtk_widget_show(ti);
                gtk_tree_prepend(GTK_TREE(sub), ti);
                plist = plist->next;
        }


        ti = gtk_tree_item_new_with_label("Deny");
        sub = gtk_tree_new();
        gtk_widget_show(ti);
        gtk_widget_show(sub);
        gtk_tree_prepend(GTK_TREE(permtree), ti);
        gtk_tree_item_set_subtree(GTK_TREE_ITEM(ti), sub);
        gtk_tree_item_expand(GTK_TREE_ITEM(ti));
        
        while(dlist) {
                ti = gtk_tree_item_new_with_label((char *)dlist->data);
                gtk_widget_show(ti);
                gtk_tree_prepend(GTK_TREE(sub), ti);
                dlist = dlist->next;
        }

	
}

static void build_edit_tree()
{
	GtkWidget *ti;
	GtkWidget *sub;
	struct category *c;
	struct person *p;

	gtk_widget_hide(tree);
	
	c = croot;
	while(c) {
		ti = gtk_tree_item_new_with_label(c->name);
		sub = gtk_tree_new();
		gtk_widget_show(ti);
		gtk_widget_show(sub);
		gtk_tree_prepend(GTK_TREE(tree), ti);
		gtk_tree_item_set_subtree(GTK_TREE_ITEM(ti), sub);
		gtk_tree_item_expand(GTK_TREE_ITEM(ti));
		p = c->members;
		while(p) {
			ti = gtk_tree_item_new_with_label(p->name);
			gtk_widget_show(ti);
			gtk_tree_prepend(GTK_TREE(sub), ti);
			p=p->next;
 		}
		c=c->next;
	}

	gtk_widget_show(tree);
	
}

int add_person(char *category, char *person)
{
	struct category *c;
	struct person *p;
	int result=0;
	c = croot;
	while(c) {
		if (!strcasecmp(category, c->name)) {
			GdkPixmap *pm;
			GdkBitmap *bm;
			GtkWidget *box;
			p = (struct person *)g_new(struct person, 1);
			if (!p)
				return 0;
			p->next = c->members;
			p->present=0;
			c->members = p;
			p->item = gtk_tree_item_new();

			box = gtk_hbox_new(FALSE, 1);
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)login_icon_xpm);
			p->pix = gtk_pixmap_new(pm, bm);
			
			gtk_widget_show(p->pix);

			p->label = gtk_label_new(person);
			gtk_misc_set_alignment(GTK_MISC(p->label), 0.0, 0.5);

			p->idletime = gtk_label_new("");
		
			gtk_box_pack_start(GTK_BOX(box), p->pix, FALSE, FALSE, 1);
			gtk_box_pack_start(GTK_BOX(box), p->label, TRUE, TRUE, 1);
			gtk_box_pack_start(GTK_BOX(box), p->idletime, FALSE, FALSE, 1);
	

			gtk_container_add(GTK_CONTAINER(p->item), box);
		
			gtk_widget_show(p->label);
			gtk_widget_show(box);

			gtk_object_set_user_data(GTK_OBJECT(p->item), p);
		

			gtk_signal_connect(GTK_OBJECT(p->item), 
			   "button_press_event",
			   GTK_SIGNAL_FUNC(handle_click_person),
			   p);
			g_snprintf(p->name, sizeof(p->name), "%s", person);
			gtk_tree_append(GTK_TREE(c->tree),p->item);
			result++;
		}
		c=c->next;
        }
	return result;
}


void add_category(char *category)
{
	struct category *c;
	c = (struct category *)g_new(struct category, 1);
	if (!c)
		return;
	
	strncpy(c->name, category, sizeof(c->name));
        c->item = gtk_tree_item_new();
        c->label = gtk_label_new(c->name);
        gtk_misc_set_alignment(GTK_MISC(c->label), 0.0, 0.5);
        gtk_widget_show(c->label);
        gtk_container_add(GTK_CONTAINER(c->item), c->label);
	c->tree = gtk_tree_new();
	gtk_widget_show(c->item);
	gtk_widget_show(c->tree);
	gtk_tree_append(GTK_TREE(buddies), c->item);
	gtk_tree_item_set_subtree(GTK_TREE_ITEM(c->item), c->tree);
	gtk_tree_item_expand(GTK_TREE_ITEM(c->item));
	gtk_signal_connect(GTK_OBJECT(c->item), 
      			   "button_press_event",
			   GTK_SIGNAL_FUNC(handle_click_category),
			   NULL);
	c->next = croot;
	c->members = NULL;
        croot = c;
}


static void do_add_perm(GtkWidget *w, GSList *buttons)
{

        char *who;
        char *name;
        int d = 0;
        char buf[BUF_LONG];


        who = gtk_entry_get_text(GTK_ENTRY(addpermentry));

        name = g_malloc(strlen(who) + 2);
        g_snprintf(name, strlen(who) + 2, "%s", who);
        
        if (addperm) {

                while(buttons) {
                        if((int)gtk_object_get_user_data(GTK_OBJECT(buttons->data)) == 2) {
                                if (GTK_TOGGLE_BUTTON(buttons->data)->active)
                                        d = 1;
                        }
                        buttons = buttons->next;
                }
                        
                if (d) {
                        deny = g_list_append(deny, name);
        		g_snprintf(buf, sizeof(buf)/2, "toc_add_deny %s", condense(name));
                        sflap_send(buf, -1, TYPE_DATA);
                } else {
                        permit = g_list_append(permit, name);
                        g_snprintf(buf, sizeof(buf)/2, "toc_add_permit %s", condense(name));
                        sflap_send(buf, -1, TYPE_DATA);
                }

                        
                gtk_tree_clear_items(GTK_TREE(permtree), 0, -1);
                build_permit_tree();

              

                build_config(buf, sizeof(buf)/2);

                sflap_send(buf, -1, TYPE_DATA);
              
                gtk_widget_destroy(addperm);
                addperm = NULL;
        }
}


static void do_add_buddy()
{
	char *cat, *who;
	char buf[BUF_LONG];
	who = gtk_entry_get_text(GTK_ENTRY(addbudentry));
	cat = gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo)->entry));
	if (addbuddy) {
#if 0
		fprintf(stdout, "Add '%s' to '%s'\n", who, cat);
#endif
                if (!add_person(cat,who)) {
			add_category(cat);
			add_person(cat,who);
		}
		
                gtk_tree_clear_items(GTK_TREE(tree), 0, -1);
                build_edit_tree();

		build_config(buf, sizeof(buf)/2);
#if 0
		fprintf(stdout,"Sending '%s'\n",buf);
#endif
		sflap_send(buf, -1, TYPE_DATA);
		g_snprintf(buf, sizeof(buf)/2, "toc_add_buddy %s", condense(who));
#if 0
		fprintf(stdout, "Also sending '%s'\n", buf);
#endif
		sflap_send(buf, -1, TYPE_DATA);
		gtk_widget_destroy(addbuddy);
	}
        addbuddy=NULL;
        update_num_categories();
}

static void do_del_buddy(GtkWidget *w, GtkTree *tree)
{
	GtkLabel *label, *plabel;
	GtkWidget *item, *pitem;
	char *c, *d;
	GList *i;
	int level;
	char buf[BUF_LONG];
	
	i = GTK_TREE_SELECTION(tree);
	if (i) {
		item = GTK_WIDGET(i->data);
		label = GTK_LABEL(GTK_BIN(item)->child);
		gtk_label_get(label, &c);
		level = GTK_TREE(item->parent)->level;
		if (level > 0) {
			pitem = GTK_WIDGET(GTK_TREE(item->parent)->tree_owner);
			plabel = GTK_LABEL(GTK_BIN(pitem)->child);
			gtk_label_get(plabel, &d);
//			fprintf(stdout,"Delete buddy '%s' from '%s'\n", c, d);
			remove_person(d, c);
                } else {
                        remove_category(c);
//			fprintf(stdout,"Delete group '%s'\n",c);
		}
		gtk_tree_clear_items(GTK_TREE(tree), 0, -1);
		build_edit_tree();
		build_config(buf, sizeof(buf)/2);
		sflap_send(buf, -1, TYPE_DATA);
        } else {
//                fprintf(stdout,"Delete empty buddy!\n");
        }
        update_num_categories();
}

static void do_del_perm(GtkWidget *w, GtkTree *permtree)
{
	GtkLabel *label, *plabel;
	GtkWidget *item, *pitem;
	char *c, *d;
	GList *i;
	
        GList *plist;
        GList *dlist;
	int level;
	char buf[BUF_LONG];

        plist = permit;
        dlist = deny;
        
	i = GTK_TREE_SELECTION(permtree);
	if (i) {
		item = GTK_WIDGET(i->data);
		label = GTK_LABEL(GTK_BIN(item)->child);
		gtk_label_get(label, &c);
		level = GTK_TREE(item->parent)->level;
		if (level > 0) {
			pitem = GTK_WIDGET(GTK_TREE(item->parent)->tree_owner);
			plabel = GTK_LABEL(GTK_BIN(pitem)->child);
			gtk_label_get(plabel, &d);
  //      		fprintf(stdout,"Delete buddy '%s' from '%s'\n", c, d);
                        if (!strcasecmp(d, "Permit")) {
                                while(plist) {
                                        if (!strcasecmp((char *)(plist->data), c)) {
                                                permit = g_list_remove(permit, plist->data);
                                                break;
                                        }

                                        plist = plist->next;
                                }

                        } else {
                                while(dlist) {
                                        if (!strcasecmp((char *)(dlist->data), c)) {
                                                deny = g_list_remove(deny, dlist->data);
                                                
                                                break;
                                        }
                                        dlist = dlist->next;
                                }

                        }

                        
                } else {
                        /* Can't delete groups here! :) */
                        return;
		}
		gtk_tree_clear_items(GTK_TREE(permtree), 0, -1);
		build_permit_tree();
		build_config(buf, sizeof(buf)/2);
		sflap_send(buf, -1, TYPE_DATA);
	}
//		fprintf(stdout,"Delete empty buddy!\n");
}

static GList *categories()
{
	GList *tmp=NULL;
	GtkWidget *li;
	struct category *c;
	c=croot;
	if (!c) {
		li=gtk_list_item_new_with_label("Buddies");
		gtk_widget_show(li);
		tmp = g_list_prepend(tmp, li);
	}
	while(c) {
		li=gtk_list_item_new_with_label(c->name);
		gtk_widget_show(li);
		tmp=g_list_prepend(tmp, li);
		c=c->next;
	}
	return tmp;
}

void do_im_back(GtkWidget *w, GtkWidget *x)
{
#ifdef USE_APPLET
  applet_widget_unregister_callback(APPLET_WIDGET(applet),"away");
  if(!blist) applet_widget_unregister_callback(APPLET_WIDGET(applet),"buddy");
  applet_widget_register_callback(APPLET_WIDGET(applet),
                "away",
                _("Away Message"),
                show_away_mess,
                NULL);
	if(!blist) {
	        applet_widget_register_callback(APPLET_WIDGET(applet),
        	        "buddy",
                	_("Buddy List"),
      		        (AppletCallbackFunc)make_buddy,
                	NULL);
	}
#endif /* USE_APPLET */
	if (imaway) {

		gtk_widget_destroy(imaway);
		imaway=NULL;
	}
	awaymessage = NULL;
}

static void do_away_mess(GtkWidget *w, struct away_message *a)
{
#ifdef USE_APPLET
  applet_widget_unregister_callback(APPLET_WIDGET(applet),"away");
  if(!blist) applet_widget_unregister_callback(APPLET_WIDGET(applet),"buddy");
  applet_widget_register_callback(APPLET_WIDGET(applet),
                                  "away",
                                  _("Back"),
                                  (AppletCallbackFunc) do_im_back,
                                  NULL);
  if(!blist) applet_widget_register_callback(APPLET_WIDGET(applet),
                "buddy",
                _("Buddy List"),
                (AppletCallbackFunc)make_buddy,
                NULL);
  gtk_widget_destroy(awaymess);
  awaymess=NULL;
#else

	GtkWidget *back;
	GtkWidget *label;
	GtkWidget *bbox;
	GtkWidget *vbox;
	GtkWidget *topbox;
	struct away_message *b;
        struct conv *c;

	
	if (awaymess) {
		a = awayroot;

		b = g_new(struct away_message, 1);

		g_snprintf(b->name, sizeof(b->name), "%s", gtk_entry_get_text(GTK_ENTRY(titleaway)));
                g_snprintf(b->message, sizeof(b->message), "%s", gtk_entry_get_text(GTK_ENTRY(entryaway)));
		
                if (strlen(b->name)) {
			b->next = NULL;
			if (a == NULL) {
				awayroot = b;
				a = b;
			} else {
				while(1) {
					if (a->next == NULL) {
						a->next = b;
						break;
					}
					a = a->next;
				}
			}
			a = a->next;
			
			save_prefs();
			do_away_menu();
		}

		a = b;
		
		gtk_widget_destroy(awaymess);
		awaymess=NULL;
	}
	if (!imaway) {
		imaway = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(imaway);
		aol_icon(imaway->window);
		back = gtk_button_new_with_label("I'm Back!");
		bbox = gtk_hbox_new(TRUE, 10);
		topbox = gtk_hbox_new(FALSE, 5);
		vbox = gtk_vbox_new(FALSE, 5);
		
		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), back, TRUE, TRUE, 10);
		
		label = gtk_label_new("Away Message: ");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		label = gtk_label_new(a->message);

		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
	
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), topbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(imaway), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_im_away), imaway);
		gtk_signal_connect(GTK_OBJECT(back), "clicked",
			   GTK_SIGNAL_FUNC(do_im_back), imaway);

		/* Finish up */
		gtk_widget_show(back);
		gtk_widget_show(topbox);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		if (strlen(a->name))
			gtk_window_set_title(GTK_WINDOW(imaway), a->name);
		else
                        gtk_window_set_title(GTK_WINDOW(imaway), "Away!");
		gtk_window_set_focus(GTK_WINDOW(imaway), back);
		gtk_container_add(GTK_CONTAINER(imaway), vbox);
		awaymessage = a;

        }
        /* New away message... Clear out the old sent_aways */
        c = cnvroot;
        while(c) {
                c->sent_away = 0;
                c = c->next;
        }
        
	gtk_widget_show(imaway);
#endif /* USE_APPLET */
}


void rem_away_mess(GtkWidget *w, struct away_message *a)
{

	struct away_message *b = awayroot, *c = awayroot;

	while(b) {

		if (b == a) {
			
			c->next = b->next;
			
			if (b == awayroot) {
				awayroot = b->next;


			}

			g_free(b);

			save_prefs();
			do_away_menu();
			return;

		}

		c = b;
                b = b->next;
	}


}

void show_away_mess()
{
	GtkWidget *cancel;
	GtkWidget *away;
	GtkWidget *label;
	GtkWidget *bbox;
	
	GtkWidget *vbox;
	GtkWidget *topbox;
	if (!awaymess) {
		awaymess = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(awaymess);
		aol_icon(awaymess->window);
		cancel = gtk_button_new_with_label("Cancel");
		away = gtk_button_new_with_label("Away!");
		bbox = gtk_hbox_new(TRUE, 10);
		topbox = gtk_hbox_new(FALSE, 5);
		vbox = gtk_vbox_new(FALSE, 5);
		entryaway = gtk_entry_new();
		titleaway = gtk_entry_new();
		
		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), away, TRUE, TRUE, 10);
		gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 10);
		
		label = gtk_label_new("Title");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), titleaway, FALSE, FALSE, 5);
		label = gtk_label_new("Away Message");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), entryaway, FALSE, FALSE, 5);

		
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), topbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(awaymess), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_away_mess), awaymess);
		gtk_signal_connect(GTK_OBJECT(cancel), "clicked",
			   GTK_SIGNAL_FUNC(destroy_away_mess), awaymess);
		gtk_signal_connect(GTK_OBJECT(away), "clicked",
			   GTK_SIGNAL_FUNC(do_away_mess), awaymess);
		gtk_signal_connect(GTK_OBJECT(entryaway), "activate",
			   GTK_SIGNAL_FUNC(do_away_mess), awaymess);
		/* Finish up */
		gtk_widget_show(away);
		gtk_widget_show(cancel);
		gtk_widget_show(entryaway);
		gtk_widget_show(titleaway);
		gtk_widget_show(topbox);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_window_set_title(GTK_WINDOW(awaymess), "Away Message");
		gtk_window_set_focus(GTK_WINDOW(awaymess), entryaway);
		gtk_container_add(GTK_CONTAINER(awaymess), vbox);
	}
	gtk_widget_show(awaymess);
}


static void show_add_buddy()
{
	GtkWidget *cancel;
	GtkWidget *add;
	GtkWidget *label;
	GtkWidget *bbox;
	GtkWidget *vbox;
	GtkWidget *topbox;
	if (!addbuddy) {
		addbuddy = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(addbuddy);
		aol_icon(addbuddy->window);
		cancel = gtk_button_new_with_label("Cancel");
		add = gtk_button_new_with_label("Add");
		bbox = gtk_hbox_new(TRUE, 10);
		topbox = gtk_hbox_new(FALSE, 5);
		vbox = gtk_vbox_new(FALSE, 5);
		addbudentry = gtk_entry_new();
		combo = gtk_combo_new();
		/* Fix the combo box */
		gtk_list_append_items(GTK_LIST(GTK_COMBO(combo)->list), categories());
		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), add, TRUE, TRUE, 10);
		gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 10);
		
		label = gtk_label_new("Add");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), addbudentry, FALSE, FALSE, 5);
		label = gtk_label_new("to group");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), combo, FALSE, FALSE, 5);
		
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), topbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(addbuddy), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_add_buddy), addbuddy);

		gtk_signal_connect(GTK_OBJECT(cancel), "clicked",
			   GTK_SIGNAL_FUNC(destroy_add_buddy), addbuddy);
		gtk_signal_connect(GTK_OBJECT(add), "clicked",
			   GTK_SIGNAL_FUNC(do_add_buddy), addbuddy);
		gtk_signal_connect(GTK_OBJECT(addbudentry), "activate",
			   GTK_SIGNAL_FUNC(do_add_buddy), addbuddy);
		/* Finish up */
		gtk_widget_show(add);
		gtk_widget_show(cancel);
		gtk_widget_show(combo);
		gtk_widget_show(addbudentry);
		gtk_widget_show(topbox);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_window_set_title(GTK_WINDOW(addbuddy), "Add Buddy");
		gtk_window_set_focus(GTK_WINDOW(addbuddy), addbudentry);
		gtk_container_add(GTK_CONTAINER(addbuddy), vbox);
	}
	gtk_widget_show(addbuddy);
}



static void show_add_perm()
{
	GtkWidget *cancel;
	GtkWidget *add;
	GtkWidget *label;
	GtkWidget *bbox;
        GtkWidget *vbox;
        GtkWidget *rbox;
        GtkWidget *topbox;
        GtkWidget *which;
	if (!addperm) {
		addperm = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(addperm);
		aol_icon(addperm->window);
		cancel = gtk_button_new_with_label("Cancel");
		add = gtk_button_new_with_label("Add");
		bbox = gtk_hbox_new(TRUE, 10);
		topbox = gtk_hbox_new(FALSE, 5);
                vbox = gtk_vbox_new(FALSE, 5);
                rbox = gtk_vbox_new(FALSE, 5);
                addpermentry = gtk_entry_new();

                which = gtk_radio_button_new_with_label(NULL, "Permit");
                gtk_box_pack_start(GTK_BOX(rbox), which, FALSE, FALSE, 0);
                gtk_object_set_user_data(GTK_OBJECT(which), (int *)1);
                gtk_widget_show(which);

                which = gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON(which)), "Deny");
                gtk_box_pack_start(GTK_BOX(rbox), which, FALSE, FALSE, 0);
                gtk_object_set_user_data(GTK_OBJECT(which), (int *)2);
                gtk_widget_show(which);
                
		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), add, TRUE, TRUE, 10);
		gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 10);
		
		label = gtk_label_new("Add");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), addpermentry, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), rbox, FALSE, FALSE, 5);
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), topbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(addperm), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_add_perm), addperm);

		gtk_signal_connect(GTK_OBJECT(cancel), "clicked",
			   GTK_SIGNAL_FUNC(destroy_add_perm), addperm);
		gtk_signal_connect(GTK_OBJECT(add), "clicked",
			   GTK_SIGNAL_FUNC(do_add_perm), gtk_radio_button_group(GTK_RADIO_BUTTON(which)));
		gtk_signal_connect(GTK_OBJECT(addpermentry), "activate",
			   GTK_SIGNAL_FUNC(do_add_perm), gtk_radio_button_group(GTK_RADIO_BUTTON(which)));
		/* Finish up */
		gtk_widget_show(add);
		gtk_widget_show(cancel);
		gtk_widget_show(addpermentry);
		gtk_widget_show(topbox);
		gtk_widget_show(bbox);
                gtk_widget_show(vbox);
                gtk_widget_show(rbox);
		gtk_window_set_title(GTK_WINDOW(addperm), "Add Permit/Deny");
		gtk_window_set_focus(GTK_WINDOW(addperm), addpermentry);
		gtk_container_add(GTK_CONTAINER(addperm), vbox);
	}
	gtk_widget_show(addperm);
}

void import_callback(GtkWidget *widget, void *null)
{
}

void export_callback(GtkWidget *widget, void *null)
{
	char buf[BUF_LONG], buf2[BUF_LONG];
        FILE *f;
	
	build_config(buf, sizeof(buf)/2);

	if (getenv("HOME")) {
		g_snprintf(buf2, sizeof(buf2), "%s/gaim-buddy", getenv("HOME"));
		if ((f = fopen(buf2,"w"))) {
			fprintf(f, "%s\n",  buf);
			fclose(f);
		}
	}
	


	
}


void add_buddy_from_convo(char *buddy)
{
	show_add_buddy();
	gtk_entry_set_text(GTK_ENTRY(addbudentry), buddy);
}



void do_quit()
{
	exit(0);
}

void info_callback(GtkWidget *widget, GtkTree *tree)
{
	GList *i;
	char send[256];
	struct person *p;
	i = GTK_TREE_SELECTION(tree);
	if (i) {
		p = gtk_object_get_user_data(GTK_OBJECT(i->data));
	}
	g_snprintf(send, sizeof(send), "toc_get_info %s", p->name);
	sflap_send(send, -1, TYPE_DATA);
	
}

void im_callback(GtkWidget *widget, GtkTree *tree)
{
	GList *i;
	struct person *p;
	i = GTK_TREE_SELECTION(tree);
	if (i) {
		p = gtk_object_get_user_data(GTK_OBJECT(i->data));
	}
	show_im(p->name);
}

void chat_callback(GtkWidget *widget, GtkTree *tree)
{
	join_chat();
}

struct person *get_person(char *who)
{
	struct category *c;
        struct person *p;
        char *lookinfor = g_malloc(strlen(who)+1);

        strcpy(lookinfor, condense(who));
        c = croot;
        while(c) {
                p=c->members;
//                printf("Looking for %s in cat %s\n", lookinfor, c->name);
		while(p) {
			if (!strcasecmp(condense(p->name),lookinfor)) {
				g_free(lookinfor);
				return p;
			}
			p=p->next;
		}
		c=c->next;
	}
	g_free(lookinfor);
	return NULL;
}

gint log_timeout(char *name)
{
	struct person *p = get_person(name);

	if(!p)
		return FALSE;
			
	if (!p->present)
		gtk_widget_hide(p->item);
	else
		set_buddy(p);
	return FALSE;
}

void set_buddy(struct person *p)
{
	char *who;
	char infotip[256];
        char idlet[16], sep[4];
        char hours[256], minutes[256], idle[256], warn[256];
	int i, hrs, min, tm, t;
	GdkPixmap *pm;
	GdkBitmap *bm;
	
	if (p->present) {
                g_snprintf(idlet, sizeof(idlet), "(%d)", p->idle);
		gtk_widget_hide(p->idletime);
		if (p->idle)
			gtk_label_set(GTK_LABEL(p->idletime), idlet);
		else
			gtk_label_set(GTK_LABEL(p->idletime), "");
		gtk_widget_show(p->idletime);


                time((time_t *)&t);
                tm = (t - p->signon) /  60;
                hrs = tm / 60;
                min = tm % 60;

                if (min) {
			if (min == 1)
				g_snprintf(minutes, sizeof(minutes), "%d minute.", min);
			else
				g_snprintf(minutes, sizeof(minutes), "%d minutes.", min);
                        sprintf(sep, ", ");
		} else {
			if (!hrs)
				g_snprintf(minutes, sizeof(minutes), "%d minutes.", min);
			else {
				minutes[0] = '.';
				minutes[1] = '\0';
			}
		}

		if (hrs) {
                        if (hrs == 1)
				g_snprintf(hours, sizeof(hours), "%d hour%s", hrs, sep);
			else
                                g_snprintf(hours, sizeof(hours), "%d hours%s", hrs, sep);
		} else
			hours[0] = '\0';
		
		if (p->idle) {
                        if (p->idle == 1)
				g_snprintf(idle, sizeof(idle), "Idle: %d minute.\n", p->idle);
			else
				g_snprintf(idle, sizeof(idle), "Idle: %d minutes.\n", p->idle);
		} else
			idle[0] = '\0';

		if (p->evil) {
			g_snprintf(warn, sizeof(warn), "Warnings: %d%%\n", p->evil);

		} else
			warn[0] = '\0';
		
		i = g_snprintf(infotip, sizeof(infotip), "Name: %s                \nLogged in: %s%s\n%s%s", p->name, hours, minutes, warn, idle);
		
		gtk_tooltips_set_tip(tips, GTK_WIDGET(p->item), infotip, "");
		

		if (!GTK_WIDGET_VISIBLE(p->item)) {
			play_sound(BUDDY_ARRIVE);

			who = g_malloc(sizeof(p->name) + 10);
			strcpy(who, p->name);
	
			gtk_label_set(GTK_LABEL(p->label), who);
			g_free(who);
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm,
				NULL, (gchar **)login_icon_xpm);
			gtk_widget_hide(p->pix);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
			gtk_widget_show(p->pix);
			gtk_widget_show(p->item);
                        gtk_timeout_add(10000, (GtkFunction) log_timeout, p->name);
                        update_num_categories();
			return;
		}
		gtk_widget_hide(p->pix);
		if (p->uc & UC_AOL) {

			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)aol_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		} else if (p->uc & UC_NORMAL) {
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)free_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		} else if (p->uc & UC_ADMIN) {
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)admin_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		} else if (p->uc & UC_UNCONFIRMED) {
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)dt_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		} else {
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm,
				NULL, (gchar **)no_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		}
		gtk_widget_show(p->pix);
		
	


	} else {
		if (GTK_WIDGET_VISIBLE(p->item)) {
			play_sound(BUDDY_LEAVE);
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm,
				NULL, (gchar **)logout_icon_xpm);
			gtk_widget_hide(p->pix);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
			gtk_widget_show(p->pix);
                        gtk_timeout_add(10000, (GtkFunction)log_timeout, p->name);
                        update_num_categories();

		}
	}
}

void parse_buddy_list(char *config)
{
	char *c;
        char current[256];
        char *name;
        char buf[BUF_LONG];
        char buf2[BUF_LONG];
        char bufperm[BUF_LONG];
        char bufdeny[BUF_LONG];
        int pos=0, ppos=0, dpos=0;
        /* Clean out the permit/deny list!*/
        g_list_free(permit);
        g_list_free(deny);
        permit = NULL;
        deny = NULL;

        
        pos+=g_snprintf(buf, sizeof(buf)/2, "toc_add_buddy");
        ppos+=g_snprintf(bufperm, sizeof(bufperm)/2, "toc_add_permit");
        dpos+=g_snprintf(bufdeny, sizeof(bufdeny)/2, "toc_add_deny");
        /* Skip first token, "CONFIG:xxx" */
        c = strtok(config + sizeof(struct sflap_hdr), "\n");
        sscanf(c + strlen(c) - 1, "%d", &permdeny);
        if (!permdeny)
                permdeny = 1;
        while((c=strtok(NULL,"\n"))) {
		if (*c == 'g') {
			strncpy(current,c+2, sizeof(current));
			add_category(current);
		} else if (*c == 'b') {
			pos+=g_snprintf(buf + pos, sizeof(buf)/2 -pos, " %s", condense(c + 2));
			add_person(current, c+2);
                } else if (*c == 'p') {
                        ppos+=g_snprintf(bufperm + ppos, sizeof(bufperm)/2 -ppos, " %s", condense(c + 2));
                        name = g_malloc(strlen(c+2) + 2);
                        g_snprintf(name, strlen(c+2) + 1, "%s", c+2);
                        permit = g_list_prepend(permit, name);
                } else if (*c == 'd') {
                        dpos+=g_snprintf(bufdeny + dpos, sizeof(bufdeny)/2 -dpos, " %s", condense(c + 2));
                        name = g_malloc(strlen(c+2) + 2);
                        g_snprintf(name, strlen(c+2) + 1, "%s", c+2);
                        deny = g_list_prepend(deny, name);
                }
	}
#if 0
	fprintf(stdout, "Sending message '%s'\n",buf);
#endif
	sflap_send(buf, -1, TYPE_DATA);
        sflap_send(bufperm, -1, TYPE_DATA);
        sflap_send(bufdeny, -1, TYPE_DATA);
        g_snprintf(buf2, sizeof(buf2), "toc_init_done");
	sflap_send(buf2, -1, TYPE_DATA);

}


static void do_away_menu()
{
	GtkWidget *menuitem;
	static GtkWidget *remmenu;
	GtkWidget *remitem;
	GtkWidget *sep;
	GList *l;
	struct away_message *a = awayroot;
	

	l = gtk_container_children(GTK_CONTAINER(awaymenu));
	
	while(l) {
		gtk_widget_destroy(GTK_WIDGET(l->data));
		l = l->next;
	}


	remmenu = gtk_menu_new();
	
	

	menuitem = gtk_menu_item_new_with_label("New Away Message");
	gtk_menu_append(GTK_MENU(awaymenu), menuitem);
	gtk_widget_show(menuitem);
	gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(show_away_mess), NULL);


	while(a) {

		remitem = gtk_menu_item_new_with_label(a->name);
		gtk_menu_append(GTK_MENU(remmenu), remitem);
		gtk_widget_show(remitem);
		gtk_signal_connect(GTK_OBJECT(remitem), "activate", GTK_SIGNAL_FUNC(rem_away_mess), a);

		a = a->next;

	}
	
	menuitem = gtk_menu_item_new_with_label("Remove Away Message");
	gtk_menu_append(GTK_MENU(awaymenu), menuitem);
	gtk_widget_show(menuitem);
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menuitem), remmenu);
	gtk_widget_show(remmenu);
	

	sep = gtk_hseparator_new();
	menuitem = gtk_menu_item_new();
	gtk_menu_append(GTK_MENU(awaymenu), menuitem);
	gtk_container_add(GTK_CONTAINER(menuitem), sep);
	gtk_widget_set_sensitive(menuitem, FALSE);
	gtk_widget_show(menuitem);
	gtk_widget_show(sep);

	a = awayroot;
	
	while(a) {

		menuitem = gtk_menu_item_new_with_label(a->name);
		gtk_menu_append(GTK_MENU(awaymenu), menuitem);
		gtk_widget_show(menuitem);
		gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(do_away_mess), a);

		a = a->next;

	}

}

void show_buddy_list(char *config)
{
	/* Build the buddy list, based on *config */

	GtkWidget *im;
	GtkWidget *sw;
	GtkWidget *info;
	GtkWidget *chat;
	GtkWidget *menu;
	GtkWidget *menubar;
	GtkWidget *vbox;
	GtkWidget *hbox;
	GtkWidget *sep;
	GtkWidget *menuitem;
        GtkWidget *notebook;
        GtkWidget *label;
        GtkWidget *add;
        GtkWidget *remove;
	GtkWidget *bbox;
        GtkWidget *tbox;
        GtkWidget *addperm;
        GtkWidget *remperm;
        GtkWidget *xbox;
        GtkWidget *pbox;
        
	blist      = gtk_window_new(GTK_WINDOW_TOPLEVEL);


	/* Icon */
	gtk_widget_realize(blist);
	aol_icon(blist->window);
        
	menubar = gtk_menu_bar_new();
	
	menu = gtk_menu_new();

	menuitem = gtk_menu_item_new_with_label("File");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menuitem), menu);
	gtk_menu_bar_append(GTK_MENU_BAR(menubar), menuitem);
	gtk_widget_show(menuitem);


	menuitem = gtk_menu_item_new_with_label("Add A Buddy");
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_widget_show(menuitem);
	gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(show_add_buddy), NULL);


	sep = gtk_hseparator_new();
	menuitem = gtk_menu_item_new();
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_container_add(GTK_CONTAINER(menuitem), sep);
	gtk_widget_set_sensitive(menuitem, FALSE);
	gtk_widget_show(menuitem);
	gtk_widget_show(sep);

        menuitem = gtk_menu_item_new_with_label("Import Buddy List");
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_widget_show(menuitem);
	gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(import_callback), NULL);


        menuitem = gtk_menu_item_new_with_label("Export Buddy List");
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_widget_show(menuitem);
	gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(export_callback), NULL);


	

	sep = gtk_hseparator_new();
	menuitem = gtk_menu_item_new();
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_container_add(GTK_CONTAINER(menuitem), sep);
	gtk_widget_set_sensitive(menuitem, FALSE);
	gtk_widget_show(menuitem);
	gtk_widget_show(sep);

	menuitem = gtk_menu_item_new_with_label("Signoff");
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_widget_show(menuitem);
	gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(signoff), NULL);


#ifndef USE_APPLET
	menuitem = gtk_menu_item_new_with_label("Quit");
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_widget_show(menuitem);
	gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(do_quit), NULL); 
#else
	menuitem = gtk_menu_item_new_with_label("Close");
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_widget_show(menuitem);
	gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(applet_destroy_buddy), NULL);
#endif

	menu = gtk_menu_new();

	menuitem = gtk_menu_item_new_with_label("Tools");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menuitem), menu);
	gtk_menu_bar_append(GTK_MENU_BAR(menubar), menuitem);
	gtk_widget_show(menuitem);

	menuitem = gtk_menu_item_new_with_label("Preferences");
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_widget_show(menuitem);
	gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(show_prefs), NULL);

	awaymenu = gtk_menu_new();

	menuitem = gtk_menu_item_new_with_label("Away");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menuitem), awaymenu);
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_widget_show(menuitem);

	do_away_menu();

	menu = gtk_menu_new();

	menuitem = gtk_menu_item_new_with_label("Help");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menuitem), menu);
	gtk_menu_item_right_justify(GTK_MENU_ITEM(menuitem));
	gtk_menu_bar_append(GTK_MENU_BAR(menubar), menuitem);
	gtk_widget_show(menuitem);

	menuitem = gtk_menu_item_new_with_label("About");
	gtk_menu_append(GTK_MENU(menu), menuitem);
	gtk_widget_show(menuitem);
	gtk_signal_connect(GTK_OBJECT(menuitem), "activate", GTK_SIGNAL_FUNC(show_about), NULL);

	gtk_widget_show(menubar);


	vbox       = gtk_vbox_new(FALSE, 10);
        
        notebook = gtk_notebook_new();

 
        

        /* Do buddy list stuff */

        buddypane = gtk_vbox_new(FALSE, 0);
        
        im         = gtk_button_new_with_label("Im");
	info       = gtk_button_new_with_label("Info");
	chat       = gtk_button_new_with_label("Chat");

	hbox       = gtk_hbox_new(TRUE, 10);

	buddies    = gtk_tree_new();
	sw         = gtk_scrolled_window_new(NULL, NULL);
	



        
	tips = gtk_tooltips_new();
	gtk_object_set_data(GTK_OBJECT(blist), "Buddy List", tips);
	
 
	
	/* Now the buddy list */
#if (GTK_MINOR_VERSION > 1) || ((GTK_MICRO_VERSION > 4) && (GTK_MINOR_VERSION > 0))
	gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(sw), buddies);
#else
	gtk_container_add(GTK_CONTAINER(sw),buddies);
#endif
#if 0
	/* we don't do this for any of the other panes, lets keep it
	   homogenous.
	*/
	gtk_container_border_width(GTK_CONTAINER(sw), 10);	 
#endif
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(sw),
				       GTK_POLICY_AUTOMATIC,GTK_POLICY_AUTOMATIC);
	gtk_widget_set_usize(sw,200,200);
	gtk_widget_show(buddies);
	gtk_widget_show(sw);

	/* Put the buttons in the hbox */
	gtk_widget_show(im);
	gtk_widget_show(chat);
	gtk_widget_show(info);

	gtk_box_pack_start(GTK_BOX(hbox), im, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(hbox), info, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(hbox), chat, TRUE, TRUE, 0);
        gtk_container_border_width(GTK_CONTAINER(hbox), 10);

        gtk_box_pack_start(GTK_BOX(buddypane), sw, TRUE, TRUE, 0);
        gtk_box_pack_start(GTK_BOX(buddypane), hbox, FALSE, FALSE, 0);

        gtk_widget_show(hbox);
        gtk_widget_show(buddypane);



        /* Swing the edit buddy */
        editpane = gtk_vbox_new(FALSE, 0);

        
       	add = gtk_button_new_with_label("Add");
       	remove = gtk_button_new_with_label("Remove");
       	tree = gtk_tree_new();
       	bbox = gtk_hbox_new(TRUE, 10);
       	tbox = gtk_scrolled_window_new(NULL, NULL);
       	/* Put the buttons in the box */
       	gtk_box_pack_start(GTK_BOX(bbox), add, TRUE, TRUE, 10);
       	gtk_box_pack_start(GTK_BOX(bbox), remove, TRUE, TRUE, 10);


       	/* And the boxes in the box */
       	gtk_box_pack_start(GTK_BOX(editpane), tbox, TRUE, TRUE, 5);
       	gtk_box_pack_start(GTK_BOX(editpane), bbox, FALSE, FALSE, 5);

	/* Handle closes right */

	

       	/* Finish up */
       	gtk_widget_show(add);
       	gtk_widget_show(remove);
       	gtk_widget_show(tree);
       	gtk_widget_show(tbox);
       	gtk_widget_show(bbox);
	gtk_widget_show(editpane);


	/* Permit/Deny */

	permitpane = gtk_vbox_new(FALSE, 0);


        addperm = gtk_button_new_with_label("Add");
        remperm = gtk_button_new_with_label("Remove");
        
       	permtree = gtk_tree_new();
       	pbox = gtk_hbox_new(TRUE, 10);
       	xbox = gtk_scrolled_window_new(NULL, NULL);
       	/* Put the buttons in the box */
       	gtk_box_pack_start(GTK_BOX(pbox), addperm, TRUE, TRUE, 10);
        gtk_box_pack_start(GTK_BOX(pbox), remperm, TRUE, TRUE, 10);
        


       	/* And the boxes in the box */
       	gtk_box_pack_start(GTK_BOX(permitpane), xbox, TRUE, TRUE, 5);
       	gtk_box_pack_start(GTK_BOX(permitpane), pbox, FALSE, FALSE, 5);

	/* Handle closes right */

	

       	/* Finish up */
       	gtk_widget_show(addperm);
        gtk_widget_show(remperm);
       	gtk_widget_show(permtree);
       	gtk_widget_show(xbox);
       	gtk_widget_show(pbox);
	gtk_widget_show(permitpane);



        label = gtk_label_new("Online");
        gtk_notebook_append_page(GTK_NOTEBOOK(notebook), buddypane, label);
        label = gtk_label_new("Edit Buddies");
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook), editpane, label);
	label = gtk_label_new("Permit");
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook), permitpane, label);

        gtk_widget_show_all(notebook);

	/* Pack things in the vbox */
        gtk_widget_show(vbox);


        gtk_widget_show(notebook);

        /* Enable buttons */
	
	gtk_signal_connect(GTK_OBJECT(im), "clicked", GTK_SIGNAL_FUNC(im_callback), buddies);
	gtk_signal_connect(GTK_OBJECT(info), "clicked", GTK_SIGNAL_FUNC(info_callback), buddies);
	gtk_signal_connect(GTK_OBJECT(chat), "clicked", GTK_SIGNAL_FUNC(chat_callback), buddies);
       	gtk_signal_connect(GTK_OBJECT(remove), "clicked", GTK_SIGNAL_FUNC(do_del_buddy), tree);
       	gtk_signal_connect(GTK_OBJECT(add), "clicked", GTK_SIGNAL_FUNC(show_add_buddy), editpane);
        gtk_signal_connect(GTK_OBJECT(addperm), "clicked", GTK_SIGNAL_FUNC(show_add_perm), permtree);
        gtk_signal_connect(GTK_OBJECT(remperm), "clicked", GTK_SIGNAL_FUNC(do_del_perm), permtree);
	gtk_box_pack_start(GTK_BOX(vbox), menubar, FALSE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(vbox), notebook, TRUE, TRUE, 0);

        gtk_container_add(GTK_CONTAINER(blist), vbox);

#ifndef USE_APPLET
        gtk_signal_connect(GTK_OBJECT(blist), "delete_event", GTK_SIGNAL_FUNC(do_quit), buddies);
#else
	gtk_signal_connect(GTK_OBJECT(blist), "delete_event", GTK_SIGNAL_FUNC(applet_destroy_buddy), NULL);
#endif


        
	parse_buddy_list(config);
        gtk_window_set_title(GTK_WINDOW(blist), "Buddy List");

        /* The edit tree */
        gtk_tree_clear_items(GTK_TREE(tree), 0, -1);
       	build_edit_tree();
#if (GTK_MINOR_VERSION > 1) || ((GTK_MINOR_VERSION > 0) && (GTK_MICRO_VERSION > 4))
       	gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(tbox), tree);
#else
       	gtk_container_add(GTK_CONTAINER(tbox), tree);
#endif
       	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(tbox),
                                       GTK_POLICY_AUTOMATIC,GTK_POLICY_AUTOMATIC);


        /* The permit tree */
        gtk_tree_clear_items(GTK_TREE(permtree), 0, -1);
       	build_permit_tree();
#if (GTK_MINOR_VERSION > 1) || ((GTK_MINOR_VERSION > 0) && (GTK_MICRO_VERSION > 4))
       	gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(xbox), permtree);
#else
       	gtk_container_add(GTK_CONTAINER(xbox), permtree);
#endif
       	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(xbox),
                                       GTK_POLICY_AUTOMATIC,GTK_POLICY_AUTOMATIC);

	gtk_widget_show(blist);
}
