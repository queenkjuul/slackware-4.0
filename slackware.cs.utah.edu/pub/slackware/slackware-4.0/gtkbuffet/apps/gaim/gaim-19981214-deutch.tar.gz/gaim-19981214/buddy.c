/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#ifdef USE_APPLET
#include <gnome.h>
#include <applet-lib.h>
#endif /* USE_APPLET */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <gtk/gtk.h>
#include "aim.h"
#include "admin_icon.xpm"
#include "aol_icon.xpm"
#include "free_icon.xpm"
#include "dt_icon.xpm"
#include "no_icon.xpm"
#include "login_icon.xpm"
#include "logout_icon.xpm"



static GtkTooltips *tips;
static GtkWidget *buddies;
static GtkWidget *addbuddy=NULL;
static GtkWidget *editbuddy=NULL;
static GtkWidget *awaymess=NULL;
static GtkWidget *imaway=NULL;
static GtkWidget *entryaway;
static GtkWidget *entry;
static GtkWidget *combo;
static GtkWidget *tree;
static GtkWidget *blist;
static struct category *croot=NULL;

char ourname[80];
char *away_message;

void destroy_buddy()
{
	if (blist)
		gtk_widget_destroy(blist);
	blist=NULL;
}

static void destroy_add_buddy()
{
	if (addbuddy)
		gtk_widget_destroy(addbuddy);
	addbuddy=NULL;
}

static void destroy_away_mess()
{
	if (awaymess)
		gtk_widget_destroy(awaymess);
	awaymess=NULL;
}

static void destroy_edit_buddy()
{
	if (editbuddy)
		gtk_widget_destroy(editbuddy);
	editbuddy=NULL;
}

#ifndef USE_APPLET
static void destroy_im_away()
{
	if (imaway)
		gtk_widget_destroy(imaway);
	imaway=NULL;
}
#endif /* USE_APPLET */


void signoff()
{
	struct category *c, *c2;
	struct person *p, *p2;
	c = croot;
	while(c) {
		p = c->members;
		while(p) {
			p2 = p;
			p = p->next;
			free(p2);
		}
		c2 = c;
		c = c->next;
		free(c2);
	}
	croot=NULL;
	toc_close();
	destroy_add_buddy();
	destroy_edit_buddy();
	destroy_buddy();
	hide_progress("");
#ifdef USE_APPLET
        applet_widget_unregister_callback(APPLET_WIDGET(applet),"signoff");
	applet_widget_unregister_callback(APPLET_WIDGET(applet),"away");
        applet_widget_register_callback(APPLET_WIDGET(applet),
                "signon",
                _("Signon"),
                applet_show_login,
                NULL);
#else
        display_login();
#endif /* USE_APPLET */
}

void handle_click_category(GtkWidget *widget, GdkEventButton *event, gpointer func_data)
{
	if (event->type == GDK_2BUTTON_PRESS) {
		if (GTK_TREE_ITEM(widget)->expanded)
			gtk_tree_item_collapse(GTK_TREE_ITEM(widget));
		else
			gtk_tree_item_expand(GTK_TREE_ITEM(widget));
	} else {
	}
#if 0
	gtk_tree_item_select(GTK_TREE_ITEM(widget));
#endif
}

void handle_click_person(GtkWidget *widget, GdkEventButton *event, struct person *p)
{

	if (event->type == GDK_2BUTTON_PRESS) {
		show_im(p->name);
	} else {
	}
#if 0
	gtk_tree_item_select(GTK_TREE_ITEM(widget));
#endif
}

void remove_person(char *cat, char *person)
{
	struct category *c;
	int elsewhere=0;
	struct person *p, *p2;
	
	c = croot;
	while(c) {
		if (!strcasecmp(c->name, cat)) {
			p = c->members;
			if (!p) continue;
			if (!strcasecmp(p->name, person)) {
#if 0
				printf("Found '%s' as first entry in group '%s'\n",p->name, c->name);
#endif
				c->members = c->members->next;
				gtk_container_remove(GTK_CONTAINER(p->item->parent), p->item);
				if (!c->members) {
					/* Reconnect tree if empty... What is up with this anyway? */
					c->tree = gtk_tree_new();
					gtk_widget_show(c->tree);
					gtk_tree_item_set_subtree(GTK_TREE_ITEM(c->item), c->tree);
					gtk_tree_item_expand(GTK_TREE_ITEM(c->item));
				};
				free(p);
			} else {
				while(p && p->next) {
					if (!strcasecmp(p->next->name, person)) {
						p2 = p->next;
#if 0
						printf("Found '%s' in group '%s'\n", p->next->name, c->name);
#endif
						p->next = p->next->next;
						gtk_container_remove(GTK_CONTAINER(p2->item->parent), p2->item);
						free(p2);
					}
					p=p->next;
				}
			}
		} else {
			p = c->members;
			while(p) {
				if (!strcasecmp(p->name, person))
					elsewhere++;
				p=p->next;
			}
		}
		c=c->next;
	}
	if (!elsewhere) {
		char buf[BUF_LONG];
		snprintf(buf, sizeof(buf)/2, "toc_remove_buddy %s", condense(person));
#if 0
		fprintf(stdout, "Sending '%s'\n",buf);
#endif
		sflap_send(buf, -1, TYPE_DATA);
	}
}

void build_config(char *s, int len)
{
	struct category *c = croot;
	struct person *p;
	int pos=0;
	pos += snprintf(&s[pos], len - pos, "toc_set_config {m 1\n");
	while(c) {
		pos += snprintf(&s[pos], len - pos, "g %s\n", c->name);
		p = c->members;
		while(p) {
			pos += snprintf(&s[pos], len - pos, "b %s\n", condense(p->name));
			p=p->next;
		}
		c=c->next;
	}
	pos += snprintf(&s[pos], len - pos, "}");
}

static void build_edit_tree(GtkTree *tree)
{
	GtkWidget *ti;
	GtkWidget *sub;
	struct category *c;
	struct person *p;
	
	c = croot;
	while(c) {
		ti = gtk_tree_item_new_with_label(c->name);
		sub = gtk_tree_new();
		gtk_widget_show(ti);
		gtk_widget_show(sub);
		gtk_tree_prepend(tree, ti);
		gtk_tree_item_set_subtree(GTK_TREE_ITEM(ti), sub);
		gtk_tree_item_expand(GTK_TREE_ITEM(ti));
		p = c->members;
		while(p) {
			ti = gtk_tree_item_new_with_label(p->name);
			gtk_widget_show(ti);
			gtk_tree_prepend(GTK_TREE(sub), ti);
			p=p->next;
		}
		c=c->next;
	}
	
}

int add_person(char *category, char *person)
{
	struct category *c;
	struct person *p;
	int result=0;
	c = croot;
	while(c) {
		if (!strcasecmp(category, c->name)) {
			GdkPixmap *pm;
			GdkBitmap *bm;
			GtkWidget *box;
			p = (struct person *)malloc(sizeof (struct person));
			if (!p)
				return 0;
			p->next = c->members;
			p->present=0;
			c->members = p;
			p->item = gtk_tree_item_new();

			box = gtk_hbox_new(FALSE, 1);
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)login_icon_xpm);
			p->pix = gtk_pixmap_new(pm, bm);
			
			gtk_widget_show(p->pix);

			p->label = gtk_label_new(person);
			gtk_misc_set_alignment(GTK_MISC(p->label), 0.0, 0.5);

			p->idletime = gtk_label_new("");
		
			gtk_box_pack_start(GTK_BOX(box), p->pix, FALSE, FALSE, 1);
			gtk_box_pack_start(GTK_BOX(box), p->label, TRUE, TRUE, 1);
			gtk_box_pack_start(GTK_BOX(box), p->idletime, FALSE, FALSE, 1);
	
	
			gtk_container_add(GTK_CONTAINER(p->item), box);
		
			gtk_widget_show(p->label);
			gtk_widget_show(box);

			gtk_object_set_user_data(GTK_OBJECT(p->item), p);
		

			gtk_signal_connect(GTK_OBJECT(p->item), 
			   "button_press_event",
			   GTK_SIGNAL_FUNC(handle_click_person),
			   p);
			snprintf(p->name, sizeof(p->name), "%s", person);
			gtk_tree_append(GTK_TREE(c->tree),p->item);
			result++;
		}
		c=c->next;
	}
	return result;
}


void add_category(char *category)
{
	struct category *c;
	c = (struct category *)malloc(sizeof(struct category));
	if (!c)
		return;
	
	strncpy(c->name, category, sizeof(c->name));
	c->item = gtk_tree_item_new_with_label(c->name);
	c->tree = gtk_tree_new();
	gtk_widget_show(c->item);
	gtk_widget_show(c->tree);
	gtk_tree_append(GTK_TREE(buddies), c->item);
	gtk_tree_item_set_subtree(GTK_TREE_ITEM(c->item), c->tree);
	gtk_tree_item_expand(GTK_TREE_ITEM(c->item));
	gtk_signal_connect(GTK_OBJECT(c->item), 
      			   "button_press_event",
			   GTK_SIGNAL_FUNC(handle_click_category),
			   NULL);
	c->next = croot;
	c->members = NULL;
	croot = c;
}

static void do_add_buddy()
{
	char *cat, *who;
	char buf[BUF_LONG];
	who = gtk_entry_get_text(GTK_ENTRY(entry));
	cat = gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo)->entry));
	if (addbuddy) {
#if 0
		fprintf(stdout, "Add '%s' to '%s'\n", who, cat);
#endif
		if (!add_person(cat,who)) {
			add_category(cat);
			add_person(cat,who);
		}
		
		if (editbuddy) {
			gtk_tree_clear_items(GTK_TREE(tree), 0, -1);
			build_edit_tree(GTK_TREE(tree));
		} 
		build_config(buf, sizeof(buf)/2);
#if 0
		fprintf(stdout,"Sending '%s'\n",buf);
#endif
		sflap_send(buf, -1, TYPE_DATA);
		snprintf(buf, sizeof(buf)/2, "toc_add_buddy %s", condense(who));
#if 0
		fprintf(stdout, "Also sending '%s'\n", buf);
#endif
		sflap_send(buf, -1, TYPE_DATA);
		gtk_widget_destroy(addbuddy);
	}
	addbuddy=NULL;
}

static void do_del_buddy(GtkWidget *w, GtkTree *tree)
{
	GtkLabel *label, *plabel;
	GtkWidget *item, *pitem;
	char *c, *d;
	GList *i;
	int level;
	char buf[BUF_LONG];
	
	i = GTK_TREE_SELECTION(tree);
	if (i) {
		item = GTK_WIDGET(i->data);
		label = GTK_LABEL(GTK_BIN(item)->child);
		gtk_label_get(label, &c);
		level = GTK_TREE(item->parent)->level;
		if (level > 0) {
			pitem = GTK_WIDGET(GTK_TREE(item->parent)->tree_owner);
			plabel = GTK_LABEL(GTK_BIN(pitem)->child);
			gtk_label_get(plabel, &d);
			fprintf(stdout,"Delete buddy '%s' from '%s'\n", c, d);
			remove_person(d, c);
		} else {
			fprintf(stdout,"Delete group '%s'\n",c);
		}
		gtk_tree_clear_items(GTK_TREE(tree), 0, -1);
		build_edit_tree(GTK_TREE(tree));
		build_config(buf, sizeof(buf)/2);
		sflap_send(buf, -1, TYPE_DATA);
	} else 
		fprintf(stdout,"Delete empty buddy!\n");
}

static GList *categories()
{
	GList *tmp=NULL;
	GtkWidget *li;
	struct category *c;
	c=croot;
	if (!c) {
		li=gtk_list_item_new_with_label("Buddies");
		gtk_widget_show(li);
		tmp = g_list_append(tmp, li);
	}
	while(c) {
		li=gtk_list_item_new_with_label(c->name);
		gtk_widget_show(li);
		tmp=g_list_append(tmp, li);
		c=c->next;
	}
	return tmp;
}

void do_im_back()
{
#ifdef USE_APPLET
  applet_widget_unregister_callback(APPLET_WIDGET(applet),"away");
  applet_widget_register_callback(APPLET_WIDGET(applet),
                "away",
                _("Away Message"),
                show_away_message,
                NULL);
#endif /* USE_APPLET */
	if (imaway) {

		gtk_widget_destroy(imaway);
		imaway=NULL;
	}
	away_message = NULL;
}

static void do_away_mess()
{
#ifdef USE_APPLET
  applet_widget_unregister_callback(APPLET_WIDGET(applet),"away");
  applet_widget_register_callback(APPLET_WIDGET(applet),
                                  "away",
                                  _("Back"),
                                  do_im_back,
                                  NULL);
  gtk_widget_destroy(awaymess);
  awaymess=NULL;
#else
	GtkWidget *back;
	GtkWidget *label;
	GtkWidget *bbox;
	
	GtkWidget *vbox;
	GtkWidget *topbox;

	if (awaymess && !imaway) {
		imaway = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(imaway);
		aol_icon(imaway->window);
		back = gtk_button_new_with_label("I'm Back!");
		bbox = gtk_hbox_new(TRUE, 10);
		topbox = gtk_hbox_new(FALSE, 5);
		vbox = gtk_vbox_new(FALSE, 5);
		
		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), back, TRUE, TRUE, 10);
		
		label = gtk_label_new("Away Message: ");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		label = gtk_label_new(gtk_entry_get_text(GTK_ENTRY(entryaway)));
		away_message = malloc(strlen(gtk_entry_get_text(GTK_ENTRY(entryaway))));
		strcpy(away_message, gtk_entry_get_text(GTK_ENTRY(entryaway)));

		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
	
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), topbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(imaway), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_im_away), awaymess);
		gtk_signal_connect(GTK_OBJECT(back), "clicked",
			   GTK_SIGNAL_FUNC(do_im_back), awaymess);

		/* Finish up */
		gtk_widget_show(back);
		gtk_widget_show(topbox);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_window_set_title(GTK_WINDOW(imaway), "I'm Away!");
		gtk_window_set_focus(GTK_WINDOW(imaway), back);
		gtk_container_add(GTK_CONTAINER(imaway), vbox);
		gtk_widget_destroy(awaymess);
		awaymess=NULL;
	}
	gtk_widget_show(imaway);
#endif /* USE_APPLET */
}





void show_away_message()
{
	GtkWidget *cancel;
	GtkWidget *away;
	GtkWidget *label;
	GtkWidget *bbox;
	
	GtkWidget *vbox;
	GtkWidget *topbox;
	if (!awaymess) {
		awaymess = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(awaymess);
		aol_icon(awaymess->window);
		cancel = gtk_button_new_with_label("Cancel");
		away = gtk_button_new_with_label("Away!");
		bbox = gtk_hbox_new(TRUE, 10);
		topbox = gtk_hbox_new(FALSE, 5);
		vbox = gtk_vbox_new(FALSE, 5);
		entryaway = gtk_entry_new();
		
		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), away, TRUE, TRUE, 10);
		gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 10);
		
		label = gtk_label_new("Away Message");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), entryaway, FALSE, FALSE, 5);
		
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), topbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(awaymess), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_away_mess), awaymess);
		gtk_signal_connect(GTK_OBJECT(cancel), "clicked",
			   GTK_SIGNAL_FUNC(destroy_away_mess), awaymess);
		gtk_signal_connect(GTK_OBJECT(away), "clicked",
			   GTK_SIGNAL_FUNC(do_away_mess), awaymess);
		gtk_signal_connect(GTK_OBJECT(entryaway), "activate",
			   GTK_SIGNAL_FUNC(do_away_mess), awaymess);
		/* Finish up */
		gtk_widget_show(away);
		gtk_widget_show(cancel);
		gtk_widget_show(entryaway);
		gtk_widget_show(topbox);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_window_set_title(GTK_WINDOW(awaymess), "Away Message");
		gtk_window_set_focus(GTK_WINDOW(awaymess), entryaway);
		gtk_container_add(GTK_CONTAINER(awaymess), vbox);
	}
	gtk_widget_show(awaymess);
}


static void show_add_buddy()
{
	GtkWidget *cancel;
	GtkWidget *add;
	GtkWidget *label;
	GtkWidget *bbox;
	GtkWidget *vbox;
	GtkWidget *topbox;
	if (!addbuddy) {
		addbuddy = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(addbuddy);
		aol_icon(addbuddy->window);
		cancel = gtk_button_new_with_label("Cancel");
		add = gtk_button_new_with_label("Add");
		bbox = gtk_hbox_new(TRUE, 10);
		topbox = gtk_hbox_new(FALSE, 5);
		vbox = gtk_vbox_new(FALSE, 5);
		entry = gtk_entry_new();
		combo = gtk_combo_new();
		/* Fix the combo box */
		gtk_list_append_items(GTK_LIST(GTK_COMBO(combo)->list), categories());
		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), add, TRUE, TRUE, 10);
		gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 10);
		
		label = gtk_label_new("Add");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), entry, FALSE, FALSE, 5);
		label = gtk_label_new("to group");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), combo, FALSE, FALSE, 5);
		
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), topbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(addbuddy), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_add_buddy), addbuddy);

		gtk_signal_connect(GTK_OBJECT(cancel), "clicked",
			   GTK_SIGNAL_FUNC(destroy_add_buddy), addbuddy);
		gtk_signal_connect(GTK_OBJECT(add), "clicked",
			   GTK_SIGNAL_FUNC(do_add_buddy), addbuddy);
		gtk_signal_connect(GTK_OBJECT(entry), "activate",
			   GTK_SIGNAL_FUNC(do_add_buddy), addbuddy);
		/* Finish up */
		gtk_widget_show(add);
		gtk_widget_show(cancel);
		gtk_widget_show(combo);
		gtk_widget_show(entry);
		gtk_widget_show(topbox);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_window_set_title(GTK_WINDOW(addbuddy), "Add Buddy");
		gtk_window_set_focus(GTK_WINDOW(addbuddy), entry);
		gtk_container_add(GTK_CONTAINER(addbuddy), vbox);
	}
	gtk_widget_show(addbuddy);
}

void add_buddy_from_convo(char *buddy)
{
	show_add_buddy();
	gtk_entry_set_text(GTK_ENTRY(entry), buddy);
}


void show_edit_buddy()
{
	GtkWidget *close;
	GtkWidget *add;
	GtkWidget *remove;
	GtkWidget *bbox;
	GtkWidget *vbox;
	GtkWidget *tbox;
	if (!editbuddy) {
		editbuddy = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(editbuddy);
		aol_icon(editbuddy->window);
		add = gtk_button_new_with_label("Add");
		remove = gtk_button_new_with_label("Remove");
		close = gtk_button_new_with_label("Close");
		tree = gtk_tree_new();
		bbox = gtk_hbox_new(TRUE, 10);
		tbox = gtk_scrolled_window_new(NULL, NULL);
		vbox = gtk_vbox_new(FALSE, 5);
		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), add, TRUE, TRUE, 10);
		gtk_box_pack_start(GTK_BOX(bbox), remove, TRUE, TRUE, 10);
		gtk_box_pack_start(GTK_BOX(bbox), close, TRUE, TRUE, 10);
		
		/* The tree */
		build_edit_tree(GTK_TREE(tree));
#if (GTK_MINOR_VERSION > 1) || ((GTK_MINOR_VERSION > 0) && (GTK_MICRO_VERSION > 4))
		gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(tbox), tree);
#else
		gtk_container_add(GTK_CONTAINER(tbox), tree);
#endif
		gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(tbox),
				       GTK_POLICY_AUTOMATIC,GTK_POLICY_AUTOMATIC);
		gtk_widget_set_usize(tbox, 150,200);

		
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), tbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(editbuddy), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_edit_buddy), editbuddy);
		gtk_signal_connect(GTK_OBJECT(close), "clicked",
			   GTK_SIGNAL_FUNC(destroy_edit_buddy), tree);
		gtk_signal_connect(GTK_OBJECT(remove), "clicked",
			   GTK_SIGNAL_FUNC(do_del_buddy), tree);
		gtk_signal_connect(GTK_OBJECT(add), "clicked",
			   GTK_SIGNAL_FUNC(show_add_buddy), editbuddy);
		/* Finish up */
		gtk_widget_show(add);
		gtk_widget_show(close);
		gtk_widget_show(remove);
		gtk_widget_show(tree);
		gtk_widget_show(tbox);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_window_set_title(GTK_WINDOW(editbuddy), "Edit Buddy List");
		gtk_container_border_width(GTK_CONTAINER(editbuddy), 10);
		gtk_container_add(GTK_CONTAINER(editbuddy), vbox);
	}
	gtk_widget_show(editbuddy);
}

void do_quit()
{
	exit(0);
}

void info_callback(GtkWidget *widget, GtkTree *tree)
{
	GList *i;
	char send[256];
	struct person *p;
	i = GTK_TREE_SELECTION(tree);
	if (i) {
		p = gtk_object_get_user_data(GTK_OBJECT(i->data));
	}
	snprintf(send, sizeof(send), "toc_get_info %s", p->name);
	sflap_send(send, -1, TYPE_DATA);
	
}

void im_callback(GtkWidget *widget, GtkTree *tree)
{
	GList *i;
	struct person *p;
	i = GTK_TREE_SELECTION(tree);
	if (i) {
		p = gtk_object_get_user_data(GTK_OBJECT(i->data));
	}
	show_im(p->name);
}

void chat_callback(GtkWidget *widget, GtkTree *tree)
{
	join_chat();
}

struct person *get_person(char *who)
{
	struct category *c;
	struct person *p;
	char lookinfor[strlen(who)+1];
	strcpy(lookinfor, condense(who));
	c=croot;
	while(c) {
		p=c->members;
		while(p) {
			if (!strcasecmp(condense(p->name),lookinfor)) {
				return p;
			}
			p=p->next;
		}
		c=c->next;
	}
	return NULL;
}

gint log_timeout(struct person *p)
{
	if (!p->present)
		gtk_widget_hide(p->item);
	else
		set_buddy(p);
	return FALSE;
}

void set_buddy(struct person *p)
{
	char *who;
	char infotip[256];
	char idlet[16];
	int i;
	GdkPixmap *pm;
	GdkBitmap *bm;
	
	who = malloc(sizeof(p->name) + 10);
	strcpy(who, p->name);
	
	if (p->present) {
		
		gtk_label_set(GTK_LABEL(p->label), who);
		snprintf(idlet, sizeof(idlet), "(%d)", p->idle);
		gtk_label_set(GTK_LABEL(p->idletime), idlet);

		
		i = snprintf(infotip, sizeof(infotip), "Name: %s                    \nLogged in: %s\nMinutes idle: %d\n", p->name, ctime(&p->signon), p->idle);

		gtk_tooltips_set_tip(tips, GTK_WIDGET(p->item), infotip, "");
		

		if (!GTK_WIDGET_VISIBLE(p->item)) {
			play_sound(BUDDY_ARRIVE);
			gtk_widget_show(p->item);
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm,
				NULL, (gchar **)login_icon_xpm);

			gtk_timeout_add(10000, (GtkFunction) log_timeout, p);
			return;
		}
		gtk_widget_hide(p->pix);
		if (p->uc & UC_AOL) {

			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)aol_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		} else if (p->uc & UC_NORMAL) {
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)free_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		} else if (p->uc & UC_ADMIN) {
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)admin_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		} else if (p->uc & UC_UNCONFIRMED) {
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm, 
				NULL, (gchar **)dt_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		} else {
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm,
				NULL, (gchar **)no_icon_xpm);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
		}
		gtk_widget_show(p->pix);
		
	


	} else {
		if (GTK_WIDGET_VISIBLE(p->item)) {
			play_sound(BUDDY_LEAVE);
			pm = gdk_pixmap_create_from_xpm_d(blist->window, &bm,
				NULL, (gchar **)logout_icon_xpm);
			gtk_widget_hide(p->pix);
			gtk_pixmap_set(GTK_PIXMAP(p->pix), pm, bm);
			gtk_widget_show(p->pix);
			gtk_timeout_add(10000, (GtkFunction)log_timeout, p);

		}
	}
	free(who);
}

void parse_buddy_list(char *config)
{
	char *c;
	char current[256];
	char buf[BUF_LONG];
	int pos=0;
	pos+=snprintf(buf, sizeof(buf)/2, "toc_add_buddy");
	/* Skip first token, "CONFIG:xxx" */
	strtok(config + sizeof(struct sflap_hdr), "\n");
	while((c=strtok(NULL,"\n"))) {
		if (*c == 'g') {
			strncpy(current,c+2, sizeof(current));
			add_category(current);
		} else {
			pos+=snprintf(buf + pos, sizeof(buf)/2 -pos, " %s", condense(c + 2));
			add_person(current, c+2);
		}
	}
#if 0
	fprintf(stdout, "Sending message '%s'\n",buf);
#endif
	sflap_send(buf, -1, TYPE_DATA);
}

void show_buddy_list(char *config)
{
	/* Build the budy list, based on *config */

	GtkWidget *im;
	GtkWidget *sw;
	GtkWidget *info;
	GtkWidget *chat;
	GtkWidget *menu;
	GtkWidget *vbox;
	GtkWidget *hbox;
	GtkMenuFactory *factory;
	GtkMenuFactory *subfactory;
	static GtkMenuEntry menu_items[] =
        {
           {"<Main>/File/Add A Buddy", "<control>A", show_add_buddy, NULL},
           {"<Main>/File/Edit Buddy List", "<control>E", show_edit_buddy, NULL},
           {"<Main>/File/Edit Permit Deny", "<control>P", NULL, NULL},
	   {"<Main>/File/<separator>", NULL, NULL, NULL},
           {"<Main>/File/Signoff", "<control>O", signoff, NULL},
           {"<Main>/File/Quit", "<control>Q", do_quit, NULL},
           {"<Main>/Tools/Preferences", NULL, show_prefs, NULL},
	   {"<Main>/Tools/Away Message", NULL, show_away_message, NULL},
        };	
        int nmenu_items = sizeof(menu_items) / sizeof(menu_items[0]);

        im         = gtk_button_new_with_label("Im");
	info       = gtk_button_new_with_label("Info");
	chat       = gtk_button_new_with_label("Chat");
	blist      = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	hbox       = gtk_hbox_new(TRUE, 10);
	vbox       = gtk_vbox_new(FALSE, 10);
	buddies    = gtk_tree_new();
	sw         = gtk_scrolled_window_new(NULL, NULL);
	
	/* Icon */
	gtk_widget_realize(blist);
	aol_icon(blist->window);
	
	tips = gtk_tooltips_new();
	gtk_object_set_data(GTK_OBJECT(blist), "Buddy List", tips);
	
	/* Enable buttons */
	
	gtk_signal_connect(GTK_OBJECT(im), "clicked", GTK_SIGNAL_FUNC(im_callback), buddies);
	gtk_signal_connect(GTK_OBJECT(blist), "delete_event", GTK_SIGNAL_FUNC(do_quit), buddies);
	gtk_signal_connect(GTK_OBJECT(info), "clicked", GTK_SIGNAL_FUNC(info_callback), buddies);
	gtk_signal_connect(GTK_OBJECT(chat), "clicked", GTK_SIGNAL_FUNC(chat_callback), buddies);

	
	/* Populate Menu */

        factory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);
        subfactory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);

        gtk_menu_factory_add_subfactory(factory, subfactory, "<Main>");
        gtk_menu_factory_add_entries(factory, menu_items, nmenu_items);
#ifdef OLD_GTK
        gtk_window_add_accelerator_table(GTK_WINDOW(blist), subfactory->table);	
#else
        gtk_window_add_accel_group(GTK_WINDOW(blist), subfactory->accel_group);	
#endif

	menu = subfactory->widget;
	
	
	/* Now the buddy list */
#if (GTK_MINOR_VERSION > 2) || ((GTK_MICRO_VERSION > 4) && (GTK_MINOR_VERSION > 0))
	gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(sw), buddies);
#else
	gtk_container_add(GTK_CONTAINER(sw),buddies);
#endif
	gtk_container_border_width(GTK_CONTAINER(sw), 10);	 
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(sw),
				       GTK_POLICY_AUTOMATIC,GTK_POLICY_AUTOMATIC);
	gtk_widget_set_usize(sw,200,200);
	gtk_widget_show(buddies);
	gtk_widget_show(sw);

	/* Put the buttons in the hbox */
	gtk_widget_show(im);
	gtk_widget_show(chat);
	gtk_widget_show(info);

	gtk_box_pack_start(GTK_BOX(hbox), im, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(hbox), info, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(hbox), chat, TRUE, TRUE, 0);
	gtk_container_border_width(GTK_CONTAINER(hbox), 10);	 

	gtk_widget_show(hbox);

	/* Pack things in the vbox */
	gtk_widget_show(vbox);
	
	gtk_box_pack_start(GTK_BOX(vbox), menu, FALSE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(vbox),sw, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, TRUE, 0);

	gtk_container_add(GTK_CONTAINER(blist), vbox);
	gtk_widget_show(menu);
	
	parse_buddy_list(config);
	gtk_window_set_title(GTK_WINDOW(blist), "Buddy List");
	gtk_widget_show(blist);
};
