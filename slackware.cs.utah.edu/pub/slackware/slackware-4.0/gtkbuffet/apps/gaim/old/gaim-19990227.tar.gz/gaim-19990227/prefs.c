/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#include <string.h>
#include <sys/time.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "aim.h"

GtkWidget *prefs=NULL;
int sounds;
int extrasounds;
int enter_sends;
int show_time;
int remember_pass;
int auto_login;
int permdeny;
int show_cat_nums;
char ourname[80];
char mypassword[16];
struct away_message *awayroot;



void load_prefs()
{
	FILE *f;
	struct away_message *a, *b;
	char *tmp;
	char *tmp2;
	char buf[BUF_LONG];

	tmp = g_malloc(256);  /* Have to allocate memory to pointers */
        tmp2 = g_malloc(256);

	awayroot = NULL;

	if (getenv("HOME")) {
		g_snprintf(buf, sizeof(buf), "%s/.gaimrc", getenv("HOME"));
		if ((f = fopen(buf,"r"))) {
			while(fgets(buf, sizeof(buf), f)>0) {
				if (buf[0] == '#')
					continue;
				sscanf(buf, "%s %[A-Za-z 0-9]\n", tmp, tmp2);
				
				if (!strcasecmp(tmp, "username")) {
					g_snprintf(ourname, sizeof(ourname), "%s", tmp2);
				} else if (!strcasecmp(tmp, "password")) {
					g_snprintf(mypassword, sizeof(mypassword), "%s", tmp2);
				} else if (!strcasecmp(tmp, "sounds")) {
					sscanf(tmp2, "%d", &sounds);
				} else if (!strcasecmp(tmp, "extrasounds")) {
					sscanf(tmp2, "%d", &extrasounds);
				} else if (!strcasecmp(tmp, "enter_sends")) {
					sscanf(tmp2, "%d", &enter_sends);
				} else if (!strcasecmp(tmp, "show_time")) {
					sscanf(tmp2, "%d", &show_time);	
				} else if (!strcasecmp(tmp, "remember_pass")) {
					sscanf(tmp2, "%d", &remember_pass);	
                                } else if (!strcasecmp(tmp, "auto_login")) {
                                        sscanf(tmp2, "%d", &auto_login);
                                } else if (!strcasecmp(tmp, "show_cat_nums")) {
                                        sscanf(tmp2, "%d", &show_cat_nums);
				} else
				if (!strcasecmp(tmp, "away_mess")) {
					fgets(buf, sizeof(buf), f);
					if (!strlen(buf) || !strlen(tmp2))
						continue;
					a = (struct away_message *)g_new(struct away_message, 1);
					g_snprintf(a->name, sizeof(a->name), "%s", tmp2);
					g_snprintf(a->message, sizeof(a->message), "%s", buf);
					/* Get rid of the \n ya doofus */
					a->message[strlen(a->message) - 1] = '\0';
					a->next = NULL;
					if (awayroot == NULL)
						awayroot = a;
					else
						b->next = a;
					b = a;
				}
			}
			fclose(f);
		} else {
			/* defaults*/
			sounds = 1;
			extrasounds = 1;
			enter_sends = 1;
			show_time = 1;
		}
	}
	

       g_free(tmp);
       g_free(tmp2);
}

void save_prefs()
{
	FILE *f;
	struct away_message *a;
	char buf[BUF_LONG];
	if (getenv("HOME")) {
		g_snprintf(buf, sizeof(buf), "%s/.gaimrc", getenv("HOME"));
		if ((f = fopen(buf,"w"))) {
			fprintf(f, "username %s\n", ourname);
			if (remember_pass) {
				fprintf(f, "password %s\n",mypassword);
			} else {
				fprintf(f, "password none\n");
			}
			fprintf(f, "sounds %d\n", sounds);
			fprintf(f, "extrasounds %d\n", extrasounds);
			fprintf(f, "enter_sends %d\n", enter_sends);
			fprintf(f, "show_time %d\n", show_time);
			fprintf(f, "remember_pass %d\n", remember_pass);
                        fprintf(f, "auto_login %d\n", auto_login);
                        fprintf(f, "show_cat_nums %d\n", show_cat_nums);
			a = awayroot;
			while(a != NULL) {
				fprintf(f, "away_mess %s\n", a->name);
				fprintf(f, "%s\n", a->message);
				a=a->next;
                        }
                        fclose(f);
                        chmod(buf, S_IRUSR | S_IWUSR);
                }
                
	}
}

void set_option(GtkWidget *w, int *data)
{
        *data = !(*data);
        if (data == &show_cat_nums)
                update_num_categories();
	save_prefs();
#if 0
	printf("Data %p set to %d\n",data, *data);
#endif
}

static void set_permit(GtkWidget *w, int *data)
{
        char buf[BUF_LONG];
	permdeny = (int)data;
//	printf("BLAH BLAH %d %d", permdeny, (int) data);
	/* We don't save this 'at home', it's on the server.
	 * So, we gotta resend the config to the server. */
	build_config(buf, sizeof(buf)/2);
	sflap_send(buf, -1, TYPE_DATA);
	      

}

static void handle_delete()
{
	gtk_widget_hide(prefs);
}

void build_prefs()
{
	GtkWidget *bbox;
	GtkWidget *vbox;
	GtkWidget *close;
	GtkWidget *sound;
	GtkWidget *extra;
	GtkWidget *enter;
	GtkWidget *time;
        GtkWidget *autolog;
        GtkWidget *shownum;
	GtkWidget *notebook;
        GtkWidget *general;
        GtkWidget *perm_deny;
	GtkWidget *label;
        GtkWidget *permopt;
        
	/* Notebooks */
	notebook = gtk_notebook_new();
	general = gtk_vbox_new(FALSE, 0);
	label = gtk_label_new("General");
	gtk_widget_show(label);
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook), general, label);
	
	/* General */
	sound = gtk_check_button_new_with_label("Enable buddy logon/logoff sounds");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(sound), sounds);
	extra = gtk_check_button_new_with_label("Enable send/receive message sounds");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(extra), extrasounds);
	enter = gtk_check_button_new_with_label("Enter sends message");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(enter), enter_sends);
	time = gtk_check_button_new_with_label("Show time on messages");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(time), show_time);
	autolog = gtk_check_button_new_with_label("Auto-Login");
        gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(autolog),auto_login);
        shownum = gtk_check_button_new_with_label("Show numbers in groups");
        gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(shownum), show_cat_nums);
	gtk_box_pack_start(GTK_BOX(general), sound, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(general), enter, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(general), extra, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(general), time, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(general), autolog, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(general), shownum, FALSE, FALSE, 0);
	gtk_signal_connect(GTK_OBJECT(sound), "clicked", GTK_SIGNAL_FUNC(set_option), &sounds);
	gtk_signal_connect(GTK_OBJECT(extra), "clicked", GTK_SIGNAL_FUNC(set_option), &extrasounds);
	gtk_signal_connect(GTK_OBJECT(enter), "clicked", GTK_SIGNAL_FUNC(set_option), &enter_sends);
	gtk_signal_connect(GTK_OBJECT(time), "clicked", GTK_SIGNAL_FUNC(set_option), &show_time);
        gtk_signal_connect(GTK_OBJECT(autolog), "clicked", GTK_SIGNAL_FUNC(set_option), &auto_login);
        gtk_signal_connect(GTK_OBJECT(shownum), "clicked", GTK_SIGNAL_FUNC(set_option), &show_cat_nums);

        perm_deny = gtk_vbox_new(FALSE, 0);
        label = gtk_label_new("Permit/Deny");
        gtk_widget_show(label);
        gtk_notebook_append_page(GTK_NOTEBOOK(notebook), perm_deny, label);

        permopt = gtk_radio_button_new_with_label(NULL, "Allow anyone to contact me");
        gtk_box_pack_start(GTK_BOX(perm_deny), permopt, FALSE, FALSE, 0);
        gtk_signal_connect(GTK_OBJECT(permopt), "clicked", GTK_SIGNAL_FUNC(set_permit), (void *)1);
	gtk_widget_show(permopt);
	if (permdeny == 1)
		gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(permopt), TRUE);

        permopt = gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON(permopt)), "Permit only people in Permit group");
        gtk_box_pack_start(GTK_BOX(perm_deny), permopt, FALSE, FALSE, 0);
        gtk_signal_connect(GTK_OBJECT(permopt), "clicked", GTK_SIGNAL_FUNC(set_permit), (void *)3);
	gtk_widget_show(permopt);
	if (permdeny == 3)
		gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(permopt), TRUE);


        permopt = gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON(permopt)), "Permit all except those in Deny group");
        gtk_box_pack_start(GTK_BOX(perm_deny), permopt, FALSE, FALSE, 0);
        gtk_signal_connect(GTK_OBJECT(permopt), "clicked", GTK_SIGNAL_FUNC(set_permit), (void *)4);
        gtk_widget_show(permopt);
	if (permdeny == 4)
		gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(permopt), TRUE);

        
	
	vbox = gtk_vbox_new(FALSE, 5);
	bbox = gtk_hbox_new(FALSE, 5);
	close = gtk_button_new_with_label("Close");
	
	/* Pack the button(s) in the button box */
	gtk_box_pack_end(GTK_BOX(bbox), close, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), notebook, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox),bbox, FALSE, FALSE, 5);

	gtk_widget_show(notebook);
	gtk_widget_show(sound);
	gtk_widget_show(extra);
	gtk_widget_show(enter);
	gtk_widget_show(general);
        gtk_widget_show(close);
        gtk_widget_show(shownum);
	gtk_widget_show(time);
	gtk_widget_show(autolog);
	gtk_widget_show(bbox);
        gtk_widget_show(vbox);
        gtk_widget_show(perm_deny);
	prefs = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_realize(prefs);
	aol_icon(prefs->window);
	gtk_container_add(GTK_CONTAINER(prefs), vbox);
	gtk_container_border_width(GTK_CONTAINER(prefs), 10);
	gtk_window_set_title(GTK_WINDOW(prefs), "Preferences");
	gtk_signal_connect(GTK_OBJECT(close), "clicked", GTK_SIGNAL_FUNC(handle_delete), NULL);
	gtk_signal_connect(GTK_OBJECT(prefs),"delete_event", 
		           GTK_SIGNAL_FUNC(handle_delete), NULL);
	
}

void show_prefs()
{
	if (!prefs)
		build_prefs();
	gtk_widget_show(prefs);
}

	
