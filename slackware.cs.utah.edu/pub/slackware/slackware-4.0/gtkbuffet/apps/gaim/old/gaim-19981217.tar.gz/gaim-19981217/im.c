/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#include <string.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <stdio.h>
#include "aim.h"

struct both {
	GtkWidget *text;
	GtkWidget *window;
	GtkWidget *who;
};

static void send_msg(char *who, GtkWidget *msg)
{
	char buf[BUF_LONG];
	char buf2[BUF_LONG];
	gchar *c;
	strncpy(buf, (c=gtk_editable_get_chars(GTK_EDITABLE(msg), 0, -1)), sizeof(buf)/2);
	g_free(c);

	escape_text(buf);
	snprintf(buf2, sizeof(buf)/2, "toc_send_im %s \"%s\"",
		condense(who), buf);
#if 0
	fprintf(stdout,"Sending %s\n",buf2);
#endif
	sflap_send(buf2, -1, TYPE_DATA);
	play_sound(SEND);
		
}

static void cancel_callback(GtkWidget *widget, struct both *both)
{
	gtk_widget_destroy(both->window);
	free(both);
}

static void send_callback(GtkWidget *widget, struct both *both)
{
#if 0
	fprintf(stdout,"Send!\n");
#endif
	send_msg(gtk_entry_get_text(GTK_ENTRY(both->who)),
		 both->text);
	gtk_widget_destroy(both->window);
	free(both);
}

void show_im(char *name)
{
	GtkWidget *win;
	GtkWidget *label;
	GtkWidget *who;
	GtkWidget *whoc;
	GtkWidget *bbox; 
	GtkWidget *text;
	GtkWidget *send;
	GtkWidget *cancel;
	GtkWidget *vbox;
	struct both *bth;

	win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_realize(win);
	aol_icon(win->window);
	label = gtk_label_new("To:");
	who = gtk_entry_new();
	whoc = gtk_hbox_new(FALSE, 0);
	vbox = gtk_vbox_new(FALSE, 0);
	bbox = gtk_hbox_new(TRUE, 10);
	text = gtk_text_new(NULL, NULL);
	send = gtk_button_new_with_label("Send");
	cancel = gtk_button_new_with_label("Cancel");
	
	bth = (struct both *)malloc(sizeof (struct both));
	bth->window = win;
	bth->text = text;
	bth->who = who;
	
	/* Buttons */
	gtk_box_pack_start(GTK_BOX(bbox), send, TRUE, TRUE, 10);
	gtk_signal_connect(GTK_OBJECT(send), "clicked", GTK_SIGNAL_FUNC(send_callback), bth);
	gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 10);
	gtk_signal_connect(GTK_OBJECT(cancel), "clicked", GTK_SIGNAL_FUNC(cancel_callback),bth);
	
	/* Fix up the text entry area */
	
	gtk_text_set_editable(GTK_TEXT(text), TRUE);
	gtk_text_set_word_wrap(GTK_TEXT(text), TRUE);
	gtk_widget_set_usize(text, 300, 80);
	
	/* Pack the who box */
	gtk_widget_set_usize(who, 150, 0);	
	gtk_box_pack_start(GTK_BOX(whoc), label, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(whoc), who, FALSE, FALSE, 5);
	
	gtk_box_pack_start(GTK_BOX(vbox), whoc, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), text, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
	
	/* Who it is to */
	if (name) {
		/* FIXME:  Why the heck won't the focus go into the text widget? */
		gtk_entry_set_text(GTK_ENTRY(who), name);
		gtk_window_set_focus(GTK_WINDOW(win), text);
		gtk_text_set_point(GTK_TEXT(text), 0);
		gtk_text_set_editable(GTK_TEXT(text), TRUE);
		gtk_editable_select_region(GTK_EDITABLE(text), 0, 0);
	} else {
		gtk_window_set_focus(GTK_WINDOW(win), who);
	}
	/* Show everything */
	
	gtk_widget_show(bbox);
	gtk_widget_show(cancel);
	gtk_widget_show(send);
	gtk_widget_show(text);
	gtk_widget_show(label);
	gtk_widget_show(who);
	gtk_widget_show(whoc);
	gtk_widget_show(vbox);
	gtk_container_add(GTK_CONTAINER(win), vbox);
	gtk_window_set_title(GTK_WINDOW(win), "Send IM");
	gtk_widget_show(win);
	
}
