/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include "aim.h"

GtkWidget *prefs=NULL;
int sounds=1;
int extrasounds=1;
int enter_sends=1;
int show_time=1;

void set_option(GtkWidget *w, int *data)
{
	*data = !(*data);
#if 0
	printf("Data %p set to %d\n",data, *data);
#endif
}

static void handle_delete()
{
	gtk_widget_hide(prefs);
}

void build_prefs()
{
	GtkWidget *bbox;
	GtkWidget *vbox;
	GtkWidget *close;
	GtkWidget *sound;
	GtkWidget *extra;
	GtkWidget *enter;
	GtkWidget *time;
	GtkWidget *notebook;
	GtkWidget *general;
	GtkWidget *label;
	
	/* Notebooks */
	notebook = gtk_notebook_new();
	general = gtk_vbox_new(FALSE, 0);
	label = gtk_label_new("General");
	gtk_widget_show(label);
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook), general, label);
	
	/* General */
	sound = gtk_check_button_new_with_label("Enable buddy logon/logoff sounds");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(sound), TRUE);
	extra = gtk_check_button_new_with_label("Enable send/receive message sounds");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(extra), TRUE);
	enter = gtk_check_button_new_with_label("Enter sends message");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(enter), TRUE);
	time = gtk_check_button_new_with_label("Show time on messages");
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(time), TRUE);
	gtk_box_pack_start(GTK_BOX(general), sound, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(general), enter, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(general), extra, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(general), time, FALSE, FALSE, 0);
	gtk_signal_connect(GTK_OBJECT(sound), "clicked", GTK_SIGNAL_FUNC(set_option), &sounds);
	gtk_signal_connect(GTK_OBJECT(extra), "clicked", GTK_SIGNAL_FUNC(set_option), &extrasounds);
	gtk_signal_connect(GTK_OBJECT(enter), "clicked", GTK_SIGNAL_FUNC(set_option), &enter_sends);
	gtk_signal_connect(GTK_OBJECT(time), "clicked", GTK_SIGNAL_FUNC(set_option), &show_time);
	
	vbox = gtk_vbox_new(FALSE, 5);
	bbox = gtk_hbox_new(FALSE, 5);
	close = gtk_button_new_with_label("Close");
	
	/* Pack the button(s) in the button box */
	gtk_box_pack_end(GTK_BOX(bbox), close, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), notebook, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox),bbox, FALSE, FALSE, 5);

	gtk_widget_show(notebook);
	gtk_widget_show(sound);
	gtk_widget_show(extra);
	gtk_widget_show(enter);
	gtk_widget_show(general);
	gtk_widget_show(close);
	gtk_widget_show(time);
	gtk_widget_show(bbox);
	gtk_widget_show(vbox);
	prefs = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_realize(prefs);
	aol_icon(prefs->window);
	gtk_container_add(GTK_CONTAINER(prefs), vbox);
	gtk_container_border_width(GTK_CONTAINER(prefs), 10);
	gtk_window_set_title(GTK_WINDOW(prefs), "Preferences");
	gtk_signal_connect(GTK_OBJECT(close), "clicked", GTK_SIGNAL_FUNC(handle_delete), NULL);
	gtk_signal_connect(GTK_OBJECT(prefs),"delete_event", 
		           GTK_SIGNAL_FUNC(handle_delete), NULL);
	
}

void show_prefs()
{
	if (!prefs)
		build_prefs();
	gtk_widget_show(prefs);
}
