/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#ifdef USE_XMHTML
#include <gtk-xmhtml/gtk-xmhtml.h>
#endif
#include "aim.h"

char ourname[80];

static GtkWidget *joinchat;
static GtkWidget *entry;
static GtkWidget *invite;
static GtkWidget *inviteentry;
static GtkWidget *invitemess;

/* Since no event is generated, we manually need to generate one */

static char *date()
{
	static char date[80];
	time_t tme;
	time(&tme);
	strftime(date, sizeof(date), "%H:%M:%S", localtime(&tme));
	return date;
}

static void destroy_join_chat()
{
	if (joinchat)
		gtk_widget_destroy(joinchat);
	joinchat=NULL;
}

static void destroy_invite()
{
	if (invite)
		gtk_widget_destroy(invite);
	invite=NULL;
}




static void fix_text(GtkWidget *text)
{
	float f;
#if 0
	printf("Placing at (%f - %f) = %f\n",GTK_TEXT(text)->vadj->upper, (float)text->allocation.height, f);
#endif
	f = GTK_TEXT(text)->vadj->upper;
	f = f - text->allocation.height;
	if (f < 0)
		f=0;
	/* Special case */
	else if (text->allocation.height == 1) f = 0;
	while(gtk_events_pending())
		gtk_main_iteration();
	gtk_adjustment_set_value(GTK_TEXT(text)->vadj, f);
}



static void do_join_chat()
{
	char *group;
	char buf[BUF_LONG];

	group = gtk_entry_get_text(GTK_ENTRY(entry));

	if (joinchat) {
		g_snprintf(buf, sizeof(buf)/2, "toc_chat_join 4 %s", condense(group));

		sflap_send(buf, -1, TYPE_DATA);
		gtk_widget_destroy(joinchat);
	}
	joinchat=NULL;
}



void join_chat()
{
	GtkWidget *cancel;
	GtkWidget *join;
	GtkWidget *label;
	GtkWidget *bbox;
	GtkWidget *vbox;
	GtkWidget *topbox;
	if (!joinchat) {
		joinchat = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(joinchat);
		aol_icon(joinchat->window);
		cancel = gtk_button_new_with_label("Cancel");
		join = gtk_button_new_with_label("Join");
		bbox = gtk_hbox_new(TRUE, 10);
		topbox = gtk_hbox_new(FALSE, 5);
		vbox = gtk_vbox_new(FALSE, 5);
		entry = gtk_entry_new();

		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), join, TRUE, TRUE, 10);
		gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 10);
		
		label = gtk_label_new("Join what group:");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), entry, FALSE, FALSE, 5);
	
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), topbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(joinchat), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_join_chat), joinchat);

		gtk_signal_connect(GTK_OBJECT(cancel), "clicked",
			   GTK_SIGNAL_FUNC(destroy_join_chat), joinchat);
		gtk_signal_connect(GTK_OBJECT(join), "clicked",
			   GTK_SIGNAL_FUNC(do_join_chat), joinchat);
		gtk_signal_connect(GTK_OBJECT(entry), "activate",
			   GTK_SIGNAL_FUNC(do_join_chat), joinchat);
		/* Finish up */
		gtk_widget_show(join);
		gtk_widget_show(cancel);
		gtk_widget_show(entry);
		gtk_widget_show(topbox);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_window_set_title(GTK_WINDOW(joinchat), "Join Chat");
		gtk_window_set_focus(GTK_WINDOW(joinchat), entry);
		gtk_container_add(GTK_CONTAINER(joinchat), vbox);
	}
	gtk_widget_show(joinchat);
}


static void do_invite(GtkWidget *w, struct buddy_chat *b)
{
	char *buddy;
	char *mess;
	char buf[BUF_LONG];

	buddy = gtk_entry_get_text(GTK_ENTRY(inviteentry));
	mess = gtk_entry_get_text(GTK_ENTRY(invitemess));

	if (invite) {
		g_snprintf(buf, sizeof(buf)/2, "toc_chat_invite %d \"%s\" %s", b->id, mess, buddy);

		sflap_send(buf, -1, TYPE_DATA);
		gtk_widget_destroy(invite);
	}
	invite=NULL;
}



static void invite_callback(GtkWidget *w, struct buddy_chat *b)
{
	GtkWidget *cancel;
	GtkWidget *invite_btn;
	GtkWidget *label;
	GtkWidget *bbox;
	GtkWidget *vbox;
	GtkWidget *topbox;
	if (!invite) {
		invite = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_widget_realize(invite);
		aol_icon(invite->window);
		cancel = gtk_button_new_with_label("Cancel");
		invite_btn = gtk_button_new_with_label("Invite");
		bbox = gtk_hbox_new(TRUE, 10);
		topbox = gtk_hbox_new(FALSE, 5);
		vbox = gtk_vbox_new(FALSE, 5);
		inviteentry = gtk_entry_new();
		invitemess = gtk_entry_new();

		/* Put the buttons in the box */
		gtk_box_pack_start(GTK_BOX(bbox), invite_btn, TRUE, TRUE, 10);
		gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 10);
		
		label = gtk_label_new("Invite who?");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), inviteentry, FALSE, FALSE, 5);
		label = gtk_label_new("With message:");
		gtk_widget_show(label);
		gtk_box_pack_start(GTK_BOX(topbox), label, FALSE, FALSE, 5);
		gtk_box_pack_start(GTK_BOX(topbox), invitemess, FALSE, FALSE, 5);
	
		/* And the boxes in the box */
		gtk_box_pack_start(GTK_BOX(vbox), topbox, TRUE, TRUE, 5);
		gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
		
		/* Handle closes right */
		gtk_signal_connect(GTK_OBJECT(invite), "delete_event",
			   GTK_SIGNAL_FUNC(destroy_invite), invite);

		gtk_signal_connect(GTK_OBJECT(cancel), "clicked",
			   GTK_SIGNAL_FUNC(destroy_invite), b);
		gtk_signal_connect(GTK_OBJECT(invite_btn), "clicked",
			   GTK_SIGNAL_FUNC(do_invite), b);
		gtk_signal_connect(GTK_OBJECT(inviteentry), "activate",
			   GTK_SIGNAL_FUNC(do_invite), b);
		/* Finish up */
		gtk_widget_show(invite_btn);
		gtk_widget_show(cancel);
		gtk_widget_show(inviteentry);
		gtk_widget_show(invitemess);
		gtk_widget_show(topbox);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_window_set_title(GTK_WINDOW(invite), "Invite to Buddy Chat");
		gtk_window_set_focus(GTK_WINDOW(invite), inviteentry);
		gtk_container_add(GTK_CONTAINER(invite), vbox);
	}
	gtk_widget_show(invite);
}

void chat_write(struct buddy_chat *b, char *who, int w, char *message)
{

	char buf[BUF_LONG];
	char buf2[BUF_LONG];
	char buf3[BUF_LONG];
	GdkColor *colour;
	static GdkColormap *map;

	map = gdk_window_get_colormap(b->window->window);
	colour = (GdkColor *)g_new(GdkColor, 1);
		colour->red = 0;
		colour->green = 0;
		colour->blue = 0;
	gdk_color_alloc(map, colour);



	if (w)
		g_snprintf(buf, sizeof(buf), "*%s*", who);
	else
		g_snprintf(buf, sizeof(buf), "%s", who);

	if (show_time)
		g_snprintf(buf2, sizeof(buf2), "%s %s: ", date(), buf);
	else
		g_snprintf(buf2, sizeof(buf2), "%s: ", buf);

	gtk_text_set_point(GTK_TEXT(b->text), gtk_text_get_length(GTK_TEXT(b->text)));
	gtk_text_freeze(GTK_TEXT(b->text));
	gtk_text_insert(GTK_TEXT(b->text), getfont(1,0,0,3), colour, NULL, buf2, strlen(buf2));
//	printf("%s\n", message);
	g_snprintf(buf3, strlen(buf3), "%s", message);
	html_print(b->text, message);
	gtk_text_thaw(GTK_TEXT(b->text));
	fix_text(b->text);

}

static int close_callback(GtkWidget *widget, struct buddy_chat *b)
{
	char buf[BUF_LONG];

	g_snprintf(buf, sizeof(buf), "toc_chat_leave %d", b->id);
	sflap_send(buf, -1, TYPE_DATA);
	
	/* Don't destroy the window yet... We'll do that when we get the 
	   CHAT_LEAVE */	
	/* FIXME!! Add a timeout so the window will be destroyed 
	 * if the chat room no longer exists and the CHAT_LEAVE never
	 * arrives */
//	gtk_widget_destroy(b->window);
//	free(b);
	return TRUE;
}


static void whisper_callback(GtkWidget *widget, struct buddy_chat *b)
{
	char buf[BUF_LONG];
	char buf2[BUF_LONG];
	GList *selected;
	char *who;

	strncpy(buf, gtk_entry_get_text(GTK_ENTRY(b->entry)), sizeof(buf)/2);
	if (!strlen(buf))
		return;

	selected = GTK_LIST(b->list)->selection;

	if (!selected)
		return;
	

	who = GTK_LABEL(gtk_container_children(GTK_CONTAINER(selected->data))->data)->label;

	if (!who)
		return;

	gtk_entry_set_text(GTK_ENTRY(b->entry), "");

	escape_text(buf);
	g_snprintf(buf2, sizeof(buf2), "toc_chat_whisper %d %s \"%s\"", b->id, who, buf);
	sflap_send(buf2, -1, TYPE_DATA);

	g_snprintf(buf2, sizeof(buf2), "%s->%s", ourname, who);

	chat_write(b, buf2, 1, buf);

	gtk_widget_grab_focus(GTK_WIDGET(b->entry));


}


static void send_callback(GtkWidget *widget, struct buddy_chat *b)
{
	char buf[BUF_LONG];
	char buf2[BUF_LONG];

	strncpy(buf, gtk_entry_get_text(GTK_ENTRY(b->entry)), sizeof(buf)/2);
	if (!strlen(buf))
		return;


	gtk_entry_set_text(GTK_ENTRY(b->entry), "");

	escape_text(buf);
	g_snprintf(buf2, sizeof(buf2), "toc_chat_send %d \"%s\"", b->id, buf);
	sflap_send(buf2, -1, TYPE_DATA);

	gtk_widget_grab_focus(GTK_WIDGET(b->entry));


}



void add_chat_buddy(struct buddy_chat *b, char *buddy)
{
	char buf[32];
	GtkWidget *list_item;


	g_snprintf(buf, sizeof(buf), "%s", buddy);
	list_item = gtk_list_item_new_with_label(buf);
	gtk_widget_show(list_item);

	gtk_container_add(GTK_CONTAINER(b->list), list_item);


}

void remove_chat_buddy(struct buddy_chat *b, char *buddy)
{	
	GList *tmp_list;
	GList *clear_list;
	GtkWidget *list_item;
	char *who;
	printf("Removebuddy %s\n", buddy);
	tmp_list = GTK_LIST(b->list)->children;

	while(tmp_list) {
		list_item = GTK_WIDGET(tmp_list->data);
		who = GTK_LABEL(gtk_container_children(GTK_CONTAINER(list_item))->data)->label;
		printf("%s\n", who);
		if (!strcasecmp(who, buddy))
			break;
		
		tmp_list = tmp_list->next;
	}
	if (tmp_list == NULL)
		return;

	clear_list = g_list_prepend(clear_list, tmp_list->data);
	gtk_list_remove_items(GTK_LIST(b->list), clear_list);
	


}




void show_new_buddy_chat(struct buddy_chat *b)
{
	GtkWidget *win;

	GtkWidget *text;
	GtkWidget *send;
	GtkWidget *list;
	GtkWidget *vsb;
	GtkWidget *invite_btn;
	GtkWidget *whisper;
	GtkWidget *close;
	GtkWidget *chatentry;
	GtkWidget *tbox;
	GtkWidget *bbox;
	GtkWidget *vbox;

//	printf("new_buddy_chat\n");
	
	win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_realize(win);
	aol_icon(win->window);
	b->window = win;

	close = gtk_button_new_with_label("Close");
	invite_btn = gtk_button_new_with_label("Invite");
	whisper = gtk_button_new_with_label("Whisper");
	send = gtk_button_new_with_label("Send");

	text = gtk_text_new(NULL, NULL);
	GTK_OBJECT(text)->flags &= ~GTK_CAN_FOCUS;
	
	b->text = text;

	list = gtk_list_new();
	b->list = list;

	bbox = gtk_hbox_new(TRUE, 0);
	tbox = gtk_hbox_new(FALSE, 0);
	vbox = gtk_vbox_new(FALSE, 0);
	chatentry = gtk_entry_new();

	gtk_widget_realize(win);


	b->makesound=1;

	gtk_object_set_user_data(GTK_OBJECT(text), b);
	gtk_object_set_user_data(GTK_OBJECT(chatentry), b);
	b->entry = chatentry;
	
	/* Hack something so we know have an entry click event */

	gtk_signal_connect(GTK_OBJECT(chatentry), "activate", GTK_SIGNAL_FUNC(send_callback),b);
	/* Text box */

	gtk_box_pack_start(GTK_BOX(tbox), text, TRUE, TRUE, 0);
  	vsb = gtk_vscrollbar_new (GTK_TEXT(text)->vadj);
	gtk_text_set_word_wrap(GTK_TEXT(text), TRUE);
        gtk_box_pack_start(GTK_BOX(tbox), vsb, FALSE, FALSE, 0);
        gtk_widget_show (vsb);	
	gtk_box_pack_start(GTK_BOX(tbox), list, TRUE, TRUE, 0);
	gtk_widget_show(list);



	gtk_widget_set_usize(text, 320, 150);
	gtk_widget_set_usize(list, 150, 150);


	/* Ready and pack buttons */
	gtk_object_set_user_data(GTK_OBJECT(win), b);
	gtk_object_set_user_data(GTK_OBJECT(close), b);
	gtk_signal_connect(GTK_OBJECT(close), "clicked", GTK_SIGNAL_FUNC(close_callback),b);
	gtk_signal_connect(GTK_OBJECT(send), "clicked", GTK_SIGNAL_FUNC(send_callback),b);
	gtk_signal_connect(GTK_OBJECT(invite_btn), "clicked", GTK_SIGNAL_FUNC(invite_callback), b);
	gtk_signal_connect(GTK_OBJECT(whisper), "clicked", GTK_SIGNAL_FUNC(whisper_callback), b);


	gtk_box_pack_start(GTK_BOX(bbox), send, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(bbox), whisper, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(bbox), invite_btn, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(bbox), close, TRUE, TRUE, 5);
	
	/* pack and fill the rest */
	
	
	gtk_box_pack_start(GTK_BOX(vbox), tbox, TRUE, TRUE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), chatentry, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);

	gtk_widget_show(send);
	gtk_widget_show(invite_btn);
	gtk_widget_show(whisper);
	gtk_widget_show(close);	
	gtk_widget_show(bbox);
	gtk_widget_show(vbox);
	gtk_widget_show(tbox);
	gtk_widget_show(chatentry);

	gtk_object_set_user_data(GTK_OBJECT(text), b);
	gtk_widget_show(text);

	
	gtk_container_add(GTK_CONTAINER(win),vbox);
	gtk_container_border_width(GTK_CONTAINER(win), 10);

	gtk_window_set_title(GTK_WINDOW(win), b->name);
	gtk_window_set_focus(GTK_WINDOW(win), chatentry);

	gtk_signal_connect(GTK_OBJECT(win), "delete_event", GTK_SIGNAL_FUNC(close_callback),b);

	gtk_widget_show(win);

	
}


