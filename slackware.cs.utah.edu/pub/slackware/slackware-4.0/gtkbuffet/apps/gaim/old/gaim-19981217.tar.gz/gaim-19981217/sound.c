/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <gtk/gtk.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/signal.h>
#include "aim.h"
#include "BuddyArrive.h"
#include "BuddyLeave.h"
#include "Send.h"
#include "Receive.h"

static int pid=0;

void child_handler(int signal)
{
	waitpid(0, NULL,WNOHANG);
	pid = 0;
}

static void iot_handler(int signal) {
	exit(0);
}

static void play(char *data, int size)
{
	int fd;
	int status;
	
	signal(SIGCHLD,child_handler);
	
	if (pid > 0) {
		waitpid(pid, &status, WNOHANG);
		if (!WIFEXITED(status) && !WIFSIGNALED(status)) 
			return;
	}
	
	pid = fork();
	
	if (pid <0)
		return;
	else if (pid == 0) {
		int x;
		signal(SIGIOT, iot_handler);
		for (x=0;x<255;x++)
			close(x);
		fd = open("/dev/audio", O_WRONLY | O_NONBLOCK | O_EXCL);
		if (fd < 0)
			exit(0);
		write(fd, data, size);
		close(fd);
		exit(0);
	}
}

void play_sound(int sound)
{
	switch(sound) {
	case BUDDY_ARRIVE:
		if (sounds)
			play(BuddyArrive, sizeof(BuddyArrive));\
		break;
	case BUDDY_LEAVE:
		if (sounds)
			play(BuddyLeave, sizeof(BuddyLeave));\
		break;
	case SEND:
		if (extrasounds)
			play(Send, sizeof(Send));\
		break;
	case RECEIVE:
		if (extrasounds)
			play(Receive, sizeof(Receive));\
		break;
	}
			
}
