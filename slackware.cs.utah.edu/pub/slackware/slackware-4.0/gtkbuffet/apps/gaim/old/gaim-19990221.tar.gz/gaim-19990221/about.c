/*
 * tik AOL Instant Messenger Client
 *
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#ifdef USE_APPLET
#include <gnome.h>
#include <applet-widget.h>
#endif /* USE_APPLET */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <gtk/gtk.h>
#include "aim.h"
#include "pixmaps/logo.xpm"

static GtkWidget *about=NULL;

static void destroy_about()
{
	if (about)
		gtk_widget_destroy(about);
	about = NULL;
}



void show_about(GtkWidget *w, void *null)
{
	GtkWidget *button;
	GtkWidget *vbox;
	GtkWidget *pixmap;
	GtkWidget *label;
	GtkStyle *style;
	GdkPixmap *pm;
	GdkBitmap *bm;

	if (!about) {
		about = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_window_set_title(GTK_WINDOW(about), "About GAIM");
		gtk_container_border_width(GTK_CONTAINER(about), 2);
		gtk_widget_set_usize(about, 435, 300);

		gtk_widget_show(about);
        	aol_icon(about->window);

		
		vbox = gtk_vbox_new(FALSE, 0);
		gtk_container_add(GTK_CONTAINER(about), vbox);
		gtk_widget_show(vbox);
		
		style = gtk_widget_get_style(about);
		pm = gdk_pixmap_create_from_xpm_d(about->window, &bm, 
			&style->bg[GTK_STATE_NORMAL], (gchar **)aol_logo);
		pixmap = gtk_pixmap_new(pm, bm);
		gtk_box_pack_start(GTK_BOX(vbox), pixmap, TRUE, TRUE, 0);
		gtk_widget_show(pixmap);
		
		label = gtk_label_new("GAIM is a 'clone' of AOL's Instant Messenger client\nwritten under the GTK\nIt is developed by:\nJim Duchek <jimduchek@ou.edu> <IM:Zilding> (Maintainer)\nMark Spencer <markster@marko.net> <IM: Markster97> (Original Author)\nPeter Jones <pjones@redhat.com> (GNOME & applet stuff)\n");
		gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 0);
		gtk_widget_show(label);
		
		button = gtk_button_new_with_label("Close");
		gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
			GTK_SIGNAL_FUNC(destroy_about), GTK_OBJECT(about));
		GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
		gtk_box_pack_start(GTK_BOX(vbox), button, TRUE, TRUE, 0);
		gtk_widget_grab_default(button);
		gtk_widget_show(button);
	
	} else
	gtk_widget_show(about);

}
