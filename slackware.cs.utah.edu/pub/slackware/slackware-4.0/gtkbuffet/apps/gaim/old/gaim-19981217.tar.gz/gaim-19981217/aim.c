/*
 * tiktok AOL Instant Messenger Client
 * Copyright (C) 1998, Mark Spencer <markster@marko.net>
 * 
 * Distributed under the terms of the GNU General Public License
 *
 */

#ifdef USE_THEMES
#include <gnome.h>
#else
#ifdef USE_APPLET
#include <gnome.h>
#include <applet-lib.h>
#endif /* USE_APPLET */
#endif /* USE_THEMES */
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "aim.h"
#ifndef USE_APPLET
#include "logo.xpm"
#endif /* USE_APPLET */
#include "aimicon.xpm"

static GtkWidget *name;
static GtkWidget *pass;
static GtkWidget *signon;
static GtkWidget *cancel;
static GtkWidget *window;
static GtkWidget *progress;
static GtkWidget *remember;
static GtkWidget *notice;
#ifdef USE_APPLET
GtkWidget *applet;
#endif /* USE_APPLET */

char toc_addy[16];

void xor_buf(char *buf)
{
	while (*buf) {
		*buf = *buf ^ 0xFA;
		buf++;
	}
}

void aol_icon(GdkWindow *w)
{

	GdkPixmap *icon_pm;
	GdkBitmap *icon_bm;
	icon_pm = gdk_pixmap_create_from_xpm_d(w, &icon_bm,
		NULL, (gchar **)aimicon_xpm);
	gdk_window_set_icon(w, NULL, icon_pm, icon_bm);
}

void cancel_logon(void)
{
#ifdef USE_APPLET
  applet_widget_unregister_callback(APPLET_WIDGET(applet),"signoff");
  applet_widget_register_callback(APPLET_WIDGET(applet),
				  "signon",
				  _("Signon"),
				  applet_show_login,
				  NULL);
  gtk_widget_hide(window);
#else
	exit(0);
#endif /* USE_APPLET */
}

void set_progress(int howfar, char *whattosay)
{
	gtk_progress_bar_update(GTK_PROGRESS_BAR(progress),
				((float)howfar / (float)LOGIN_STEPS));
	gtk_statusbar_pop(GTK_STATUSBAR(notice), 1);
	gtk_statusbar_push(GTK_STATUSBAR(notice), 1, whattosay);	
#ifdef HIDE_PROGRESS
	gtk_widget_show(progress);
#endif
	while (gtk_events_pending())
               gtk_main_iteration();

	/* Why do I need these? */
	usleep(10);
	while (gtk_events_pending())
               gtk_main_iteration();
	       
}

void hide_progress(char *why)
{
	gtk_progress_bar_update(GTK_PROGRESS_BAR(progress),
				0);
	gtk_statusbar_pop(GTK_STATUSBAR(notice), 1);
	gtk_statusbar_push(GTK_STATUSBAR(notice), 1, why);	
#ifdef HIDE_PROGRESS
	gtk_widget_hide(progress);
#endif
	while (gtk_events_pending())
               gtk_main_iteration();

	/* Why do I need these? */
	usleep(10);
	while (gtk_events_pending())
               gtk_main_iteration();
	       
}

void dologin(GtkWidget *widget, GtkWidget *window)
{
	FILE *f;
	char *username = gtk_entry_get_text(GTK_ENTRY(name));
	char *password = gtk_entry_get_text(GTK_ENTRY(pass));
	char *e;
#if 0
	char *config = strdup("asdfasdfCONFIG: m 1\ng Buddies\nb markster97");
#else
	char *config;
#endif
#if 0
	struct conv *conv = malloc(sizeof (struct conv));
#endif
	struct in_addr *sin;
	char buf[80];

#if 0
	strcpy(conv->name,"markster");
	show_conv(conv);
	return;
#endif
	
	if (!strlen(username)) {
		hide_progress("Please enter your logon");
		return;
	}
	if (!strlen(password)) {
		hide_progress("You must give your password");
		return;
	}
	
	set_progress(1, "Looking up " TOC_HOST);
	
	sin = (struct in_addr *)get_address(TOC_HOST);
	if (!sin) {
		hide_progress("Unable to lookup "  TOC_HOST);
		return;
	}
	
	snprintf(toc_addy, sizeof(toc_addy), "%s", inet_ntoa(*sin));
	snprintf(buf, sizeof(buf), "Connecting to %s", inet_ntoa(*sin));
	
	set_progress(2, buf);
	
	if (connect_address(sin->s_addr, TOC_PORT)) {
		snprintf(buf, sizeof(buf), "Connect to %s failed",
			 inet_ntoa(*sin));
		hide_progress(buf);
		return;
	}
	
	snprintf(buf, sizeof(buf), "Signon: %s",username);
	
	set_progress(3, buf);
	
	if (toc_signon(username, password) < 0) {
		hide_progress("Disconnected.");
		return;
	}
	
	snprintf(buf, sizeof(buf), "Waiting for reply...");
	set_progress(4, buf);
	if (toc_wait_signon() < 0) {
		hide_progress("Authentication Failed");
		return;
	}
	if (getenv("HOME")) {
		snprintf(buf, sizeof(buf), "%s/.gaim-login", getenv("HOME"));
		if ((f = fopen(buf,"w"))) {
			fprintf(f, "%s\n", username);
			if (GTK_TOGGLE_BUTTON(remember)->active) {
				e = strdup(password);
				xor_buf(e);
				fprintf(f, "%s\n",e);
				free(e);
			}
			fclose(f);
		}
	}
		
	snprintf(buf, sizeof(buf), "Retrieving config...");
	set_progress(5, buf);
	if ((config=toc_wait_config()) == NULL) {
		hide_progress("No Configuration");
		return;
	}
	
	gtk_widget_hide(window);

	show_buddy_list(config);
}



void doenter(GtkWidget *widget, GtkWindow *window)
{
	if (widget == name) {
		gtk_entry_set_text(GTK_ENTRY(pass),"");
		gtk_entry_select_region(GTK_ENTRY(name), 0, 0);
		gtk_window_set_focus(window,pass);
	} else if (widget == pass) {
		gtk_window_set_focus(window,signon);		
	} else {
		g_print("what did you press enter on?\n");
	}
}

void display_login()
{
	gtk_widget_show(window);
}

void show_login()
{
	GtkWidget *reg;
	GtkWidget *bbox;
	GtkWidget *label;
	GtkWidget *table;
#ifndef USE_APPLET
	GtkWidget *pmw;
	GdkPixmap *pm;
	GtkStyle *style;
	GdkBitmap *mask;
#endif /* USE_APPLET */
	FILE *f;
	char buf[256];
	
	window   = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	signon   = gtk_button_new_with_label("Signon");
	cancel   = gtk_button_new_with_label("Cancel");
	reg      = gtk_button_new_with_label("Register");
	table    = gtk_table_new(8, 2, FALSE);
	name     = gtk_entry_new();
	pass     = gtk_entry_new();
	notice   = gtk_statusbar_new();
	progress = gtk_progress_bar_new();

	
	gtk_window_set_wmclass(GTK_WINDOW(window), "GAIM", "GAIM");

	
	gtk_widget_realize(window);
	
	
	aol_icon(window->window);
	
	if (getenv("HOME")) {
		snprintf(buf, sizeof(buf), "%s/.gaim-login", getenv("HOME"));
		f = fopen(buf,"r");
	}
	
	/* Make the buttons do stuff */
	/* Clicking the button initiates a login */
	gtk_signal_connect(GTK_OBJECT(signon), "clicked",
			   GTK_SIGNAL_FUNC(dologin), window);
	gtk_signal_connect(GTK_OBJECT(cancel), "clicked",
			   GTK_SIGNAL_FUNC(cancel_logon),window);
	/* Register opens the right URL */
	gtk_signal_connect(GTK_OBJECT(reg), "clicked",
			   GTK_SIGNAL_FUNC(show_html), "http://www.aol.com/aim");
	/* Enter in the username clears the password and sets
	   the pointer in the password field */
	gtk_signal_connect(GTK_OBJECT(name), "activate",
			   GTK_SIGNAL_FUNC(doenter), window);
			   
	gtk_signal_connect(GTK_OBJECT(pass), "activate",
			   GTK_SIGNAL_FUNC(doenter), window);
	gtk_signal_connect(GTK_OBJECT(window), "delete_event",
			   GTK_SIGNAL_FUNC(cancel_logon), window);
	/* Homogenous spacing, 10 padding */
	bbox = gtk_hbox_new(TRUE, 10);
	
	gtk_box_pack_start(GTK_BOX(bbox), reg, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(bbox), signon, TRUE, TRUE, 0);

#ifndef USE_APPLET	
	/* Logo at the top */
	style = gtk_widget_get_style(window);
	pm = gdk_pixmap_create_from_xpm_d(window->window, &mask,
		&style->bg[GTK_STATE_NORMAL], (gchar **)aol_logo);
	pmw = gtk_pixmap_new( pm, mask);
	gtk_table_attach(GTK_TABLE(table), pmw, 0,2,0,1,0,0,5,5);
	gtk_widget_show(pmw);
#endif /* USE_APPLET */
	
	/* Labels for selectors and text boxes */
#if 0	
	label = gtk_label_new("TOC: ");
	gtk_table_attach(GTK_TABLE(table), label, 0,1,1,2,0,0, 5, 5);
	gtk_widget_show(label);
#endif
	label = gtk_label_new("Screen Name: ");
	gtk_table_attach(GTK_TABLE(table), label, 0,1,2,3,0,0, 5, 5);
	gtk_widget_show(label);
	label = gtk_label_new("Password: ");
	gtk_table_attach(GTK_TABLE(table), label, 0,1,3,4,0,0, 5, 5);
	gtk_widget_show(label);
	remember = gtk_check_button_new_with_label("Remember Password");
	gtk_table_attach(GTK_TABLE(table), remember, 0,2,4,5,0,0, 5, 5);
	gtk_widget_show(remember);

	/* Adjust sizes of inputs */
	gtk_widget_set_usize(name,80,0);
	gtk_widget_set_usize(pass,80,0);

	/* Status and label */
	gtk_widget_show(notice);

	gtk_widget_set_usize(progress,150,0);
#ifndef HIDE_PROGRESS
	gtk_widget_show(progress);
#endif
	gtk_table_attach(GTK_TABLE(table), progress, 0, 2, 5, 6, 0, 0, 5, 5);
	gtk_widget_set_usize(GTK_STATUSBAR(notice)->label, 150, 0);
	gtk_table_attach(GTK_TABLE(table), notice, 0, 2, 7, 8, 0, 0, 5, 5);

	/* Attach the buttons at the bottom */
	gtk_widget_show(signon);
	gtk_widget_show(cancel);
	gtk_widget_show(reg);
	gtk_widget_show(bbox);
	gtk_table_attach(GTK_TABLE(table), bbox, 0,2,6,7,0,0, 5, 5);
	
	/* Text fields */
	
	gtk_table_attach(GTK_TABLE(table),name,1,2,2,3,0,0,5,5);
	gtk_widget_show(name);
	gtk_table_attach(GTK_TABLE(table),pass,1,2,3,4,0,0,5,5);
	gtk_entry_set_visibility(GTK_ENTRY(pass), FALSE);
	gtk_widget_show(pass);
	
	gtk_container_border_width(GTK_CONTAINER(bbox), 10);	 
	
	gtk_container_add(GTK_CONTAINER(window),table );
	
	gtk_widget_show(table);
	gtk_window_set_title(GTK_WINDOW(window),"Login");
	if (f) {
		fgets(buf, sizeof(buf), f);
		buf[strlen(buf)-1]='\0';
		gtk_entry_set_text(GTK_ENTRY(name), buf);
		gtk_entry_select_region(GTK_ENTRY(name), 0, -1);
		if (fgets(buf, sizeof(buf), f) > 0) {
			buf[strlen(buf)-1]='\0';
			xor_buf(buf);
			gtk_entry_set_text(GTK_ENTRY(pass), buf);
			gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(remember), TRUE);
		}
		fclose(f);
		gtk_widget_grab_focus(signon);
	} else
		gtk_widget_grab_focus(name);

	gtk_widget_show(window);
	
}

#ifdef USE_APPLET
void applet_show_login(AppletWidget *widget, gpointer data) {
        show_login();
        applet_widget_unregister_callback(APPLET_WIDGET(applet),"signon");
        applet_widget_register_callback(APPLET_WIDGET(applet),
                "signoff",
                _("Signoff"),
                signoff,
                NULL);
	applet_widget_register_callback(APPLET_WIDGET(applet),
		"away",
		_("Away Message"),
		show_away_message,
		NULL);
}
#endif

#ifdef USE_APPLET
void applet_show_about(AppletWidget *widget, gpointer data) {
  const gchar *authors[] = {"Mark Spencer <markster@marko.net>",
			    "Jim Duchek <jimduchek@ou.edu>",
			    "Peter Jones <pjones@redhat.com>",
			    NULL};
  GtkWidget *about=gnome_about_new(_("GAIM"),
				   _(GAIM_VERSION),
				   _(""),
				   authors,
				   "",
				   NULL);
  gtk_widget_show(about);
}

void applet_show_properties(AppletWidget *widget, gpointer data) {
  GnomePropertyConfigurator *configurator;

  configurator=gnome_property_configurator_new();
  gnome_property_configurator_request_foreach(configurator,
					      GNOME_PROPERTY_READ);
  gnome_property_configurator_setup(configurator);
  gnome_property_configurator_request_foreach(configurator,
					      GNOME_PROPERTY_SETUP);
  gtk_window_set_title(GTK_WINDOW(configurator->property_box),
		       "GAIM");
  gtk_widget_hide(GNOME_PROPERTY_BOX(configurator->property_box)->help_button);
gtk_widget_hide(GNOME_PROPERTY_BOX(configurator->property_box)->help_button);
  gtk_widget_show(configurator->property_box);
}
#endif

int main(int argc, char *argv[])
{
#ifdef USE_APPLET
        GtkWidget *icon;
        GdkPixmap *icon_pm;
        GdkBitmap *icon_bm;

        applet_widget_init_defaults("GAIM",GAIM_VERSION,argc,argv,NULL,0,NULL);
        applet=applet_widget_new();
        if(!applet) g_error(_("Can't create GAIM applet!"));

	icon_pm=gdk_pixmap_create_from_xpm_d(applet->window,&icon_bm,
		NULL, (gchar **)aimicon_xpm);
	icon=gtk_pixmap_new(icon_pm,icon_bm);

        applet_widget_add(APPLET_WIDGET(applet),icon); 
	applet_widget_set_tooltip(APPLET_WIDGET(applet),"GAIM");

	applet_widget_register_stock_callback(APPLET_WIDGET(applet),
					      "about",
					      GNOME_STOCK_MENU_ABOUT,
					      _("About..."),
					      applet_show_about,
					      NULL);
#ifdef PETERS_EVIL_TEST_MODE
	applet_widget_register_callback(APPLET_WIDGET(applet),
					"properties",
					_("Properties"),
					applet_show_properties,
					NULL);
#endif
        gtk_widget_show(icon);
        gtk_widget_show(applet);
#elif defined USE_THEMES         
        gnome_init("GAIM",NULL,argc,argv);
#else
        gtk_init(&argc, &argv);
#endif /* USE_THEMES */
	
	strcpy(ourname,"<unknown>");

#ifdef USE_APPLET
#ifndef PETERS_EVIL_TEST_MODE
	applet_widget_register_callback(APPLET_WIDGET(applet),
					"prefs",
					_("Preferences"),
					show_prefs,
					NULL);
#endif
        applet_widget_register_callback(APPLET_WIDGET(applet),
					"signon",
					_("Signon"),
					applet_show_login,
					NULL);
	applet_widget_gtk_main();
#else	
	show_login();
	gtk_main();
#endif /* USE_APPLET */	
	return 0;
	
}

