/* Here you will find functions that renders x-y plots
 C. Steenberg 07/10/1998
 */

#include <math.h>
#include <glib.h>
#include <gtk/gtk.h>
#include <string.h>
#include "object_tree.h"
#include "xy_2d.h"


/* find these in ../fc_yor/fc_yor.c */
extern int *fc_yor_data_dims,fc_yor_init;
extern double *fc_yor_data;
extern char *yor_command;
extern gchar *fc_input_buf,yor_init,fc_yor_busy;
extern gint fc_input_received;

fc_node *new_xy_2d_node(fc_node *mother)
{ fc_node *xy_node;
  xy_2d *xy_info;
  guint index,i,j;

  if (!mother) return (NULL);
  xy_node=new_child_node(mother, 5, XY_2D_NODE);
  if (!xy_node) return (NULL);
  index=mother->n_children-1;

  xy_node->is_container=FALSE;
  xy_node->parent_node=mother;
  xy_node->node_data=(gpointer)g_malloc(sizeof(xy_2d));
  if (!xy_node->node_data)
   { fc_remove_child(mother,index);
     return(NULL);
   }
  xy_info=xy_node->node_data;
  xy_info->version=XY_2D_NODE_VERSION;
  xy_info->depth=0;
  xy_info->line_type=0; /*solid line */
  xy_info->line_color=new_fc_color(0,60000,0); /* default color=black */
  xy_info->marker_color=new_fc_color(60000,0,0); /* default color=black */
  xy_info->fill_color=NULL;
  xy_info->pre_cmd=NULL;
  xy_info->post_cmd=NULL;
  for (i=0; i<6; i++)
    { xy_info->var[i]=NULL;
      xy_info->var_function[i]=NULL;
      xy_info->data[i]=NULL;
      xy_info->var_flag[i]|=XY_RECALC;
    }
  xy_info->marker_font=strdup(DEFAULT_FONT);
  xy_info->marker_unit=POINTS;
  xy_info->marker_size=10;
  xy_info->marker_rot=0;
  xy_info->cap_unit=POINTS;
  xy_info->cap_size=9;
  xy_info->line_unit=POINTS;
  xy_info->line_width=0.5;

  xy_info->marker_text=NULL;
  xy_info->flags=XY_DRAW_LINE|XY_DRAW_MARKER;

  return(xy_node);
}

gint fc_destroy_2d(fc_node *xy_node)
{ xy_2d* xy_info;
  box_side *side;
  gint i;

  if (!xy_node) return(0);
  xy_info=(xy_2d *)(xy_node->node_data);
  if (xy_info)
   { if (xy_info->marker_color) g_free(xy_info->marker_color);
     if (xy_info->line_color) g_free(xy_info->line_color);
     if (xy_info->fill_color) g_free(xy_info->fill_color);
     if (xy_info->marker_text) g_free(xy_info->marker_text);
     if (xy_info->marker_font) g_free(xy_info->marker_font);
     if (xy_info->pre_cmd) g_free(xy_info->pre_cmd);
     if (xy_info->post_cmd) g_free(xy_info->post_cmd);
     for (i=0;i<6;i++)
       { if (xy_info->var[i]) g_free(xy_info->var[i]);
         if (xy_info->var_function[i]) g_free(xy_info->var_function[i]);
       }
    g_free(xy_info);
   }

  fc_remove_child_pointer(xy_node->parent_node,xy_node);
}

gint xy_set_marker_text(fc_node *xy_node, gchar *text)
{xy_2d* xy_info;

  if (!xy_node) return(0);
  xy_info=(xy_2d *)(xy_node->node_data);
  if (xy_info)
    xy_info->marker_text=strdup(text);
  else return(0);
  
  return(1);
}

gint xy_set_marker(fc_node *xy_node, gchar marker)
{xy_2d* xy_info;

  if (!xy_node) return(0);
  xy_info=(xy_2d *)(xy_node->node_data);
  if (xy_info)
    xy_info->marker_text=strdup(" ");
  else return(0);
  xy_info->marker_text[0]=marker;    
  return(1);
}


gint xy_unset_flag(fc_node *xy_node, guint32 flag)
{guint32 xorflag;
 if (!xy_node) return(0);
 xorflag=0xffffffff^flag;
 ((xy_2d *)(xy_node->node_data))->flags&=xorflag;
 return(1);
}


gint xy_set_flag(fc_node *xy_node, guint32 flag)
{
 if (!xy_node) return(0);
 ((xy_2d *)(xy_node->node_data))->flags|=flag;
 return(1);
}


gint xy_set_line_type(fc_node *xy_node, gchar type)
{ 
 if (!xy_node) return(0);
 ((xy_2d *)(xy_node->node_data))->line_type=type;
 return(1);
}

gint xy_set_line_color(fc_node *xy_node, guint16 r,guint16 g,guint16 b)
{ fc_color *color;
 if (!xy_node) return(0);
 color= ((xy_2d *)(xy_node->node_data))->line_color;
 if (!color) 
  { ((xy_2d *)(xy_node->node_data))->line_color=new_fc_color(r,g,b);
    return(1);
  }
 color->r=r;
 color->g=g;
 color->b=b;
 return(1);
}

gint xy_set_marker_color(fc_node *xy_node, guint16 r,guint16 g,guint16 b)
{ fc_color *color;
 if (!xy_node) return(0);
 color= ((xy_2d *)(xy_node->node_data))->marker_color;
 if (!color) 
  { ((xy_2d *)(xy_node->node_data))->marker_color=new_fc_color(r,g,b);
    return(1);
  }
 color->r=r;
 color->g=g;
 color->b=b;
 return(1);
}


gint xy_set_precmd(fc_node *xy_node, gchar *precmd)
{xy_2d* xy_info;

  if (!xy_node) return(0);
  xy_info=(xy_2d *)(xy_node->node_data);
  if (xy_info)
    xy_info->pre_cmd=strdup(precmd);
  else return(0);
  
  return(1);
}

gint xy_set_postcmd(fc_node *xy_node, gchar *postcmd)
{xy_2d* xy_info;

  if (!xy_node) return(0);
  xy_info=(xy_2d *)(xy_node->node_data);
  if (xy_info)
    xy_info->pre_cmd=strdup(postcmd);
  else return(0);
  
  return(0);
}

gint xy_set_var(fc_node *xy_node, gchar which, gchar *var)
{xy_2d* xy_info;

  if (!xy_node||which>5) return(0);
  xy_info=(xy_2d *)(xy_node->node_data);
  if (xy_info)
    xy_info->var[which]=strdup(var);
  else return(0);
  
  return(0);
}

gint xy_set_var_func(fc_node *xy_node, gchar which, gchar *func)
{xy_2d* xy_info;

  if (!xy_node||which>5) return(0);
  xy_info=(xy_2d *)(xy_node->node_data);
  if (xy_info)
    xy_info->var_function[which]=strdup(func);
  else return(0);
  
  return(0);
}

gint xy_yor_command(gchar *lcmd)
{ gint i;
  char *cmd;
  if (!lcmd) return(0);
  i=strlen(lcmd);
  cmd=(char *)g_malloc((i+2)*sizeof(char));
  strcpy(cmd,lcmd);
  cmd[i]=' ';
  cmd[i+1]='\n';
  cmd[i+1]='\0';
  yor_command=cmd;
  do {} while (CheckForTasks(1));
  yor_command=NULL;
  return(1);
}


gint xy_resolve_yor_funcs(fc_node *xy_node)
{ xy_2d* xy_info;
  gint i,j,num_elems;
  gchar *cmd_str, func_calculated=FALSE;

  if (!xy_node || fc_yor_busy) return(0);
  xy_info=(xy_2d *)(xy_node->node_data);
  if (!xy_info) return(0);
  
  for (i=0;i<6;i++)
    { printf("var[%d]=%s var_func[%d]=%s\n",i,xy_info->var[i],i,xy_info->var_function[i]);
/*      if ( (xy_info->var[i] || xy_info->var_function[i]) && 
         ((xy_info->var_flag[i] &XY_RECALC)>0 || (xy_info->var_flag[i] &XY_CALC)==0))*/
      if ( xy_info->var[i] || xy_info->var_function[i] )
       { cmd_str=0;
/* Case 1: the variable and the function exists */
         if (xy_info->var[i] && xy_info->var_function[i])
	  { cmd_str=(gchar *)g_malloc((strlen(xy_info->var[i])+
                     strlen(xy_info->var_function[i])+10)*sizeof(gchar));
            cmd_str[0]='\0';
	    strcat(cmd_str,xy_info->var[i]);
  	    strcat(cmd_str,"=");
	    strcat(cmd_str,xy_info->var_function[i]);
            xy_yor_command(cmd_str);
            xy_info->var_flag[i] |=XY_CALC; /* calculated expression */
            cmd_str[0]='\0';
            sprintf(cmd_str,"fc_info,%s; ",xy_info->var[i]);
            xy_yor_command(cmd_str);
         if (cmd_str) g_free(cmd_str);
	  }
/* Case 2: only the variable exists */
         if (xy_info->var[i] && !xy_info->var_function[i])
	  { cmd_str=(char *)g_malloc(strlen(xy_info->var[i])*sizeof(char)+20);
         printf("cmd_str=%x\n",cmd_str);
            cmd_str[0]='\0';
	    sprintf(cmd_str,"fc_info,%s; ",xy_info->var[i]);
         printf("cmd_str=%s, len=%d, max=%d\n",cmd_str,strlen(cmd_str),
                strlen(xy_info->var[i])*sizeof(char)+20);
            xy_yor_command(cmd_str);
         if (cmd_str) g_free(cmd_str);
	  }

/* Case 3: only the function exists */
         if (!xy_info->var[i] && xy_info->var_function[i]) 
           if (xy_info->data[i]==NULL || (xy_info->var_flag[i]&XY_RECALC)>0)
	  { printf("xy_resolve No store 0.1\n");
	    cmd_str=(gchar *)g_malloc(strlen(xy_info->var_function[i])*sizeof(gchar)+10);
            cmd_str[0]='\0';
	    sprintf(cmd_str,"fc_info,%s; ",xy_info->var_function[i]);
            xy_yor_command(cmd_str);
	    func_calculated=TRUE;
         if (cmd_str) g_free(cmd_str);
	  }

	 num_elems=0;
         if (fc_yor_data_dims[0]>0 && 
	 ((xy_info->var_flag[i] &XY_STORE_RESULT)>0 || func_calculated==TRUE))
	  { if (xy_info->data_dims[i]) g_free(xy_info->data_dims[i]);
	    xy_info->data_dims[i]=(gint *)g_malloc((fc_yor_data_dims[0]+1)*sizeof(gint));
            xy_info->data_dims[i][0]=fc_yor_data_dims[0];
	    for (j=1;j<=fc_yor_data_dims[0];j++)
	     { num_elems+=fc_yor_data_dims[j];
	       xy_info->data_dims[i][j]=fc_yor_data_dims[j];
	     }
            if (xy_info->data[i]) g_free(xy_info->data[i]);
	    xy_info->data[i]=(double *)g_malloc(num_elems*sizeof(double));
	    for (j=0;j<num_elems;j++)
  	     xy_info->data[i][j]=fc_yor_data[j];
	  }
         else if (fc_yor_data_dims[0]>0)
	  { printf("xy_resolve No store 1\n");
	    if (xy_info->data_dims[i]) g_free(xy_info->data_dims[i]);
	    xy_info->data_dims[i]=(gint *)g_malloc((fc_yor_data_dims[0]+3)*sizeof(gint));
            printf("xy_resolve No store 2\n");
	    for (j=0;j<=fc_yor_data_dims[0];j++)
	       { xy_info->data_dims[i][j]=fc_yor_data_dims[j];
	         printf("element=%d\n",xy_info->data_dims[i][j]);
	       }
 	    xy_info->data[i]=(double *)fc_yor_data;
	    printf("fc_yor_data=%x\n",fc_yor_data);
          }
/*         if (cmd_str) g_free(cmd_str);*/
       }
    }
}

gint xy_preproc_points(double *x_points, double *y_points,
                       gint num_elems, gint *n_pe, gint *pe,
		       guint32 logx, guint32 logy,
		       double minx, double maxx, double miny, double maxy)
{ gint i;

  *n_pe=0;
  if (!logx && !logy)
   { for (i=0;i<num_elems;i++)
     if (x_points[i]>=minx && x_points[i]<=maxx &&
         y_points[i]>=miny && y_points[i]<=maxy)
        pe[(*n_pe)++]=i;
     return(1);
    }
  if (!logx && logy)
   { for (i=0;i<num_elems;i++)
     if (x_points[i]>=minx && x_points[i]<=maxx &&
         y_points[i]>=miny && y_points[i]<=maxy && y_points[i]>0)
        pe[(*n_pe)++]=i;
     return(1);
    }
  if (logx && !logy)
   { for (i=0;i<num_elems;i++)
     if (x_points[i]>=minx && x_points[i]<=maxx && x_points[i]>0 &&
         y_points[i]>=miny && y_points[i]<=maxy)
        pe[(*n_pe)++]=i;
     return(1);
    }
  if (logx && logy)
   { for (i=0;i<num_elems;i++)
     if (x_points[i]>=minx && x_points[i]<=maxx && x_points[i]>0 &&
         y_points[i]>=miny && y_points[i]<=maxy && y_points[i]>=0)
        pe[(*n_pe)++]=i;
     return(1);
    }
  for (i=0;i<*n_pe;i++)
  return(1);
}
        
gint xy_render_final(xy_2d *xy_info,double *x_points,double *y_points,
                     gint n_pe,gint *xy_indices,guint32 logx, guint32 logy)
{gint i;
 double x,y,px,py;

 if (n_pe==0) return(0);
  
 if (xy_info->line_color && (xy_info->flags & XY_DRAW_LINE)>0)
  { pencolor(xy_info->line_color->r,
             xy_info->line_color->g,
             xy_info->line_color->b);
    filltype(0);
    linemod(line_types[xy_info->line_type]);
    flinewidth(xy_info->line_width*unit_to_page[xy_info->line_unit]);
/* The following looks stupid, but it is faster this way :-) */
    if (!logx && !logy)
      { px=cur_sys_hor_m*x_points[xy_indices[0]]+cur_sys_hor_c;
        py=cur_sys_ver_m*y_points[xy_indices[0]]+cur_sys_ver_c;
      }
    if (logx && logy)
      { px=cur_sys_hor_m*log10(x_points[xy_indices[0]])+cur_sys_hor_c;
        py=cur_sys_ver_m*log10(y_points[xy_indices[0]])+cur_sys_ver_c;
      }
    if (!logx && logy)
      { px=cur_sys_hor_m*x_points[xy_indices[0]]+cur_sys_hor_c;
        py=cur_sys_ver_m*log10(y_points[xy_indices[0]])+cur_sys_ver_c;
      }
    if (logx && !logy)
      { px=cur_sys_hor_m*log10(x_points[xy_indices[0]])+cur_sys_hor_c;
        py=cur_sys_ver_m*y_points[xy_indices[0]]+cur_sys_ver_c;
      }

    if (!logx && !logy)
     for (i=1;i<n_pe;i++)
      { x=cur_sys_hor_m*x_points[xy_indices[i]]+cur_sys_hor_c;
        y=cur_sys_ver_m*y_points[xy_indices[i]]+cur_sys_ver_c;
	fline(px,py,x,y);
	px=x;
	py=y;
      }
    if (logx && logy)
     for (i=1;i<n_pe;i++)
      { x=cur_sys_hor_m*log10(x_points[xy_indices[i]])+cur_sys_hor_c;
        y=cur_sys_ver_m*log10(y_points[xy_indices[i]])+cur_sys_ver_c;
	fline(px,py,x,y);
	px=x;
	py=y;

      }
    if (!logx && logy)
     for (i=1;i<n_pe;i++)
      { x=cur_sys_hor_m*x_points[xy_indices[i]]+cur_sys_hor_c;
        y=cur_sys_ver_m*log10(y_points[xy_indices[i]])+cur_sys_ver_c;
	fline(px,py,x,y);
	printf("x=%2.3e m=%2.3e y=%2.3e\n",x,y,log10(y_points[xy_indices[i]]));
	px=x;
	py=y;
      }
    if (logx && !logy)
     for (i=1;i<n_pe;i++)
      { x=cur_sys_hor_m*log10(x_points[xy_indices[i]])+cur_sys_hor_c;
        y=cur_sys_ver_m*y_points[xy_indices[i]]+cur_sys_ver_c;
	fline(px,py,x,y);
	px=x;
	py=y;
      }
     }

 if (xy_info->marker_color && (xy_info->flags & XY_DRAW_MARKER)>0 &&
     xy_info->marker_text)
  { double size;
    gchar marker=0;
    int mtype;
    pencolor(xy_info->marker_color->r,
             xy_info->marker_color->g,
             xy_info->marker_color->b);
    filltype(0);
    size=xy_info->marker_size*unit_to_page[xy_info->marker_unit];
    if (xy_info->marker_text[0]>31) /* Marker is a text string */
     { ffontsize(size);
       fontname(xy_info->marker_font);
       ftextangle(xy_info->marker_rot);
     }
    else 
     { marker=1;
       mtype=xy_info->marker_text[0];
     }

    printf("marker=%d rot=%1.2f r=%d g=%d b=%d\n",marker,xy_info->marker_rot,
             xy_info->marker_color->r,
             xy_info->marker_color->g,
             xy_info->marker_color->b);    
    if (!logx && !logy)
     for (i=0;i<n_pe;i++)
      { x=cur_sys_hor_m*x_points[xy_indices[i]]+cur_sys_hor_c;
        y=cur_sys_ver_m*y_points[xy_indices[i]]+cur_sys_ver_c;
	if (marker)
	 fmarker(x,y,mtype,size);
        else
	 { fmove(x,y);
/*	   alabel('c','c',xy_info->marker_text);*/
	 }
      }
printf("xy logx + logy\n");
    if (logx && logy)
     for (i=0;i<n_pe;i++)
      { x=cur_sys_hor_m*log10(x_points[xy_indices[i]])+cur_sys_hor_c;
        y=cur_sys_ver_m*log10(y_points[xy_indices[i]])+cur_sys_ver_c;
	if (marker)
	 fmarker(x,y,mtype,size);
        else
	 { fmove(x,y);
	  /* alabel('c','c',xy_info->marker_text);*/
	 }
      }
printf("xy !logx + logy\n");
    if (!logx && logy)
     for (i=0;i<n_pe;i++)
      { x=cur_sys_hor_m*x_points[xy_indices[i]]+cur_sys_hor_c;
        y=cur_sys_ver_m*log10(y_points[xy_indices[i]])+cur_sys_ver_c;
	if (marker)
	 fmarker(x,y,mtype,size);
        else
	 { fmove(x,y);
/*	   alabel('c','c',xy_info->marker_text);*/
	 }
      }
printf("xy logx + !logy\n");
    if (logx && !logy)
     for (i=0;i<n_pe;i++)
      { x=cur_sys_hor_m*log10(x_points[xy_indices[i]])+cur_sys_hor_c;
        y=cur_sys_ver_m*y_points[xy_indices[i]]+cur_sys_ver_c;
	if (marker)
	 fmarker(x,y,mtype,size);
        else
	 { fmove(x,y);
/*	   alabel('c','c',xy_info->marker_text);*/
	 }
      }
printf("xy FIN\n");
  }
printf("xy FIN\n");
return(1);
}
      
gint xy_render(fc_node *xy_node,guint32 logx, guint32 logy,
               double minx, double maxx, double miny, double maxy)
{ xy_2d *xy_info;
  double *x_points,*y_points; 
  gint i,j,num_elems, *xy_indices, n_pe;
  gchar free_x=FALSE;

  if (!xy_node|| xy_node->node_type!=XY_2D_NODE) return(0);
  xy_info=(xy_2d *)xy_node->node_data;
  if (!xy_info|| !xy_info->data_dims[XY_Y_POINT]||
  xy_info->data_dims[XY_Y_POINT][0]==0 ||
  xy_info->data_dims[XY_Y_POINT][1]==0) return (0); /* no Y data points!*/
  num_elems=0; 
  for (j=1;j<=xy_info->data_dims[XY_Y_POINT][0];j++)
    num_elems+=xy_info->data_dims[XY_Y_POINT][j];  

  y_points=xy_info->data[XY_Y_POINT];
  xy_indices=(gint *)g_malloc(num_elems*sizeof(gint));
  if (!xy_info->data_dims[XY_X_POINT]|| /* This means no X data points */
  xy_info->data_dims[XY_X_POINT][0]==0 ||
  xy_info->data_dims[XY_X_POINT][1]==0)
   { x_points=(double *)g_malloc(num_elems*sizeof(double));
     for (i=0;i<num_elems;i++)
      x_points[i]=i;
     free_x=TRUE;
    } 
  else 
   x_points=xy_info->data[XY_X_POINT];  
  xy_preproc_points(x_points, y_points,num_elems, &n_pe, xy_indices, 
                    logx,  logy, minx, maxx, miny, maxy);
  xy_render_final(xy_info,x_points,y_points,n_pe,xy_indices,logx,logy);
printf("xy_render FIN\n");
  if (free_x) g_free(x_points);
  return(1);  
}
