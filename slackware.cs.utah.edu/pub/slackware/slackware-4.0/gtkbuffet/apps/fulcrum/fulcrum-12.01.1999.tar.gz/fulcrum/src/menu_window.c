/* Menu bar and items
 C. Steenberg 24/10/1998
 */

#include <glib.h>
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <string.h>
#include "object_tree.h"
#include "fulcrum.h"
#include "doc_dialog.h"
#include "page_dialog.h"
#include "menu_window.h"

  fc_menu_struct file_menu_data[]={
        {6,DEF_ICON,"New", "N", GDK_n, 0, NULL, NULL, NULL, NULL},
        {0,DEF_ICON,"Open", "", GDK_o, 0, NULL, NULL, NULL, NULL, NULL, NULL},
        {0,DEF_ICON,"Save", "", GDK_s, 0, NULL, NULL, NULL, NULL, NULL, NULL},
        {0,DEF_ICON,"Save as", "", GDK_a, 0, NULL, NULL, NULL, NULL, NULL, NULL},
        {0,DEF_ICON,"", "", 0, 0, NULL, NULL, NULL, NULL, NULL, NULL},
        {0,DEF_ICON,"Quit", "", GDK_q, GDK_MOD1_MASK, fc_main_exit, NULL, NULL, NULL, NULL, NULL}
      };
  fc_menu_struct new_object_menu_data[]={
        {5,1,"Document", "D", GDK_d, GDK_MOD1_MASK, create_new_doc_dialog, NULL, NULL, NULL, NULL, NULL},
        {0,2,"Page", "P", GDK_p, GDK_MOD1_MASK, create_new_page_dialog, NULL, NULL, NULL, NULL, NULL},
        {0,3,"2D Plain Box", "P", GDK_o, GDK_MOD1_MASK, NULL, NULL, NULL, NULL, NULL, NULL},
        {0,3,"2D XY Box", "B", GDK_b, GDK_MOD1_MASK, NULL, NULL, NULL, NULL, NULL, NULL},
        {0,4,"2D XY Line/Scatter plot", "L", 0, 0, NULL, NULL, NULL, NULL, NULL, NULL},
      };

  fc_menu_struct object_menu_data[]={
        {2,DEF_ICON,"New", "N", GDK_n, GDK_MOD1_MASK, NULL, NULL,
         (gpointer) &new_object_menu_data, NULL, NULL, NULL},
        {0,DEF_ICON,"Delete", "D", GDK_o, GDK_MOD1_MASK, NULL, NULL, NULL, NULL, NULL, NULL},
      };

  fc_menu_struct top_menu_data[]={
        {2,DEF_ICON,"File", "", GDK_f, GDK_MOD1_MASK|GDK_MOD2_MASK, NULL,NULL,
         (gpointer) &file_menu_data, NULL, NULL, NULL},
        {0,DEF_ICON,"Object", "", GDK_o, GDK_MOD1_MASK|GDK_MOD2_MASK, NULL, NULL,
         (gpointer) &object_menu_data, NULL, NULL, NULL},
      };

gint widget_hide_r(fc_menu_struct *menu_data)
{ gtk_widget_hide(GTK_WIDGET(menu_data->menu));
  if (menu_data->parent) 
    widget_hide_r(menu_data->parent);
  return(TRUE);
}
  
  
  
gint fc_menu_keypress (GtkWidget      *widget,
                       GdkEventKey    *event,
                       gpointer        menu_data_p,
                       gpointer        menu_data_1)
{ fc_menu_struct *menu_data;
  gchar items,i;
  GtkWidget *menu_widget;

  menu_data=(fc_menu_struct*) menu_data_p;
  items=menu_data[0].num;
  printf("key=%d state=%d menu_data=%x widget=%x\n",event->keyval,event->state,menu_data,
         menu_data[0].widget);
  for (i=0;i<items;i++)
     if (event->keyval==menu_data[i].key && event->state==menu_data[i].mask)
      { if (GTK_MENU_ITEM(menu_data[i].widget)->submenu)
         gtk_menu_item_select (GTK_MENU_ITEM(menu_data[i].widget));
        else
         { gtk_menu_item_activate (GTK_MENU_ITEM(menu_data[i].widget));
           gtk_menu_item_deselect (GTK_MENU_ITEM(menu_data[i].widget));
           gtk_widget_hide(GTK_WIDGET(menu_data[i].menu));
         }
        break;
      }
  return(TRUE);
}

int init_menu_r(GtkWidget *top_item,fc_menu_struct *menu_data,
                fc_menu_struct *parent)
{ guint i,n_items;
  GtkWidget *menubar,*menu, *menu_item, *hbox, *label, *pixwidget;
  if (!top_item || !menu_data) return (FALSE);
  n_items=menu_data[0].num;

  menu=gtk_menu_new();
  for (i=0;i<n_items;i++)
   { if ( (!menu_data[i].lname
         ||strlen(menu_data[i].lname)==0)&&(!menu_data[i].rname
         ||strlen(menu_data[i].rname)==0))
      menu_item=gtk_menu_item_new ();
     else
      { menu_item=gtk_menu_item_new ();
        hbox=gtk_hbox_new(FALSE,0);
        if (menu_data[i].npix<999 && fc_tree_icon[menu_data[i].npix])
         { pixwidget=gtk_pixmap_new (fc_tree_icon[menu_data[i].npix],
           fc_tree_icon_mask[menu_data[i].npix]);
           gtk_box_pack_start(GTK_BOX(hbox),pixwidget,FALSE,FALSE,0);
           gtk_misc_set_alignment (GTK_MISC (pixwidget), 0, 0);
           gtk_widget_show(pixwidget);
         }

        if (menu_data[i].lname && strlen(menu_data[i].lname)>0)
         { label=gtk_label_new(menu_data[i].lname);
           gtk_box_pack_start(GTK_BOX(hbox),label,FALSE,FALSE,5);
           gtk_widget_show(label);
         }
        if (menu_data[i].rname && strlen(menu_data[i].rname)>0)
         { label=gtk_label_new(menu_data[i].rname);
           gtk_box_pack_end(GTK_BOX(hbox),label,FALSE,FALSE,5);
           gtk_widget_show(label);
         }
        gtk_widget_show(hbox);
        gtk_container_add (GTK_CONTAINER (menu_item), hbox);
      }
     gtk_menu_append(GTK_MENU(menu),menu_item);
     if (menu_data[i].callback)
       gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                                 GTK_SIGNAL_FUNC(menu_data[i].callback),
                                 (gpointer) (menu_data[i].data));
     menu_data[i].widget=menu_item;
     menu_data[i].menu=menu;
     menu_data[i].parent=parent;

     if (menu_data[i].sub_menu) init_menu_r(menu_item,
         (fc_menu_struct *)menu_data[i].sub_menu,menu_data);
     gtk_widget_show(menu_item);
   }
/*  gtk_signal_connect( GTK_OBJECT(menu), "key_press_event",
                                 GTK_SIGNAL_FUNC(fc_menu_keypress),
                                 (gpointer) menu_data);
  printf("signal connected with %x, widget=%x\n",menu_data,menu_data[0].widget);*/
  gtk_menu_item_set_submenu( GTK_MENU_ITEM(top_item), menu );
  return(TRUE);
}



int init_menu_top(GtkWidget *window, GtkWidget *menubar,
                  fc_menu_struct *menu_data)
{ guint i,n_items;
  GtkWidget *menu, *menu_item, *hbox, *label, *pixwidget;

  if (!menubar || !menu_data) return (FALSE);
  n_items=menu_data[0].num;
  printf("n_items=%d\n",n_items);

  for (i=0;i<n_items;i++)
   { if ((!menu_data[i].lname
         ||strlen(menu_data[i].lname)==0)&&(!menu_data[i].rname
         ||strlen(menu_data[i].rname)==0))
      menu_item=gtk_menu_item_new ();
     else
      { menu_item=gtk_menu_item_new ();
        hbox=gtk_hbox_new(FALSE,0);
        if (menu_data[i].npix<999 && fc_tree_icon[menu_data[i].npix])
         { pixwidget=gtk_pixmap_new (fc_tree_icon[menu_data[i].npix],
           fc_tree_icon_mask[menu_data[i].npix]);
           gtk_box_pack_start(GTK_BOX(hbox),pixwidget,FALSE,FALSE,0);
           gtk_misc_set_alignment (GTK_MISC (pixwidget), 0, 0);
           gtk_widget_show(pixwidget);
         }

        if (menu_data[i].lname && strlen(menu_data[i].lname)>0)
         { label=gtk_label_new(menu_data[i].lname);
           gtk_box_pack_start(GTK_BOX(hbox),label,FALSE,FALSE,0);
           gtk_misc_set_alignment (GTK_MISC (label), 0, 0);
           gtk_widget_show(label);
         }
        if (menu_data[i].rname && strlen(menu_data[i].rname)>0)
         { label=gtk_label_new(menu_data[i].rname);
           gtk_box_pack_end(GTK_BOX(hbox),label,FALSE,FALSE,0);
           gtk_widget_show(label);
         }
        gtk_widget_show(hbox);
        gtk_container_add (GTK_CONTAINER (menu_item), hbox);
      }
     gtk_menu_bar_append( GTK_MENU_BAR (menubar), menu_item );
     if (menu_data[i].callback)
       gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                                 GTK_SIGNAL_FUNC(menu_data[i].callback),
                                 (gpointer) menu_data[i].data);
     menu_data[i].widget=menu_item;
     menu_data[i].menu=NULL;
     menu_data[i].parent=NULL;
     if (menu_data[i].sub_menu) init_menu_r(menu_item,
         (fc_menu_struct *)menu_data[i].sub_menu,menu_data);
     gtk_widget_show(menu_item);
   }
/*  gtk_signal_connect( GTK_OBJECT(window), "key_press_event",
                                 GTK_SIGNAL_FUNC(fc_menu_keypress),
                                 (gpointer) menu_data);
  printf("signal connected with %x, widget=%x\n",menu_data,
         menu_data[0].widget);*/
  return(TRUE);
}
    
void fc_init_menu(GtkWidget *table, GtkWidget *window)
{ gint i,n_items;
  GtkWidget *menubar,*file_menu, *menu_item;

  menubar=gtk_menu_bar_new();
  gtk_table_attach(GTK_TABLE(table), menubar, 0, 2, 0, 1,
                               GTK_FILL,
                               GTK_FILL,0,0);
  init_menu_top(window,menubar,top_menu_data);
  gtk_widget_show(menubar);
  
}
