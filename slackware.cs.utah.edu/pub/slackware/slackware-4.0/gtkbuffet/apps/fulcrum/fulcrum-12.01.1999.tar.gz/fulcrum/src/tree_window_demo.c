exit(1);
  /* Add new box system as a demo */
   for (i=101;i<=100;i+=20)
     { box_node=new_box_2d_norm(page_node,1,10, 1,100, 0.005*i,0.008*i, 0.005*i,0.009*i);
      box_set_depth(box_node,100-i);
     }
     box_node=new_box_2d_norm(page_node,1,100, 1,1e4, 0.55,0.85, 0.6,0.9);
     box_logxy(box_node,1,1);
     box_set_depth(box_node,0);

     box_set_tick_flag(box_node,TOP_SIDE,0,LABEL_DRAW_GRID);
     box_set_tick_flag(box_node,TOP_SIDE,1,LABEL_DRAW_GRID);
     box_set_tick_line_type(box_node,TOP_SIDE,1,1);

     box_set_tick_flag(box_node,RIGHT_SIDE,0,LABEL_DRAW_GRID|LABEL_EXP);
     box_set_tick_flag(box_node,RIGHT_SIDE,1,LABEL_DRAW_GRID);
     box_set_tick_line_type(box_node,RIGHT_SIDE,1,1);

     box_set_tick_color(box_node,RIGHT_SIDE,1,0,0,60000);
     box_set_tick_color(box_node,RIGHT_SIDE,1,0,0,60000);

     box_set_tick_flag(box_node,LEFT_SIDE,0,LABEL_EXP);
     box_unset_tick_flag(box_node,RIGHT_SIDE,0,LABEL_DEFAULT);
     box_unset_tick_flag(box_node,LEFT_SIDE,0,LABEL_DEFAULT);
     box_side_label_offset(box_node,LEFT_SIDE,24.0);
     box_side_label_offset(box_node,RIGHT_SIDE,24.0);

   depth_sort_children(page_node->list_children,page_node->n_children);

/* New xy line */
    xy_node=new_xy_defaults(box_node);
    xy_set_var_func(xy_node,XY_X_POINT,"spanl(1,100,10);");
    xy_set_var(xy_node,XY_X_POINT,"x");
    xy_set_var_func(xy_node,XY_Y_POINT,"x^3");
    xy_set_var(xy_node,XY_Y_POINT,"y");
    xy_set_marker_text(xy_node,"\\c+");
    xy_set_line_color(xy_node,0,0,0);
    xy_set_marker_color(xy_node,0,60000,0);

/* New xy line */
    xy_node=new_xy_defaults(box_node);
    xy_set_var(xy_node,XY_X_POINT,"x");
    xy_set_var_func(xy_node,XY_Y_POINT,"x^2");
    xy_set_var(xy_node,XY_Y_POINT,"y1");
xy_set_marker(xy_node,5);
    /*    xy_set_marker_text(xy_node,"\\c+");*/
    xy_set_line_color(xy_node,0,0,60000);
    xy_set_marker_color(xy_node,60000,0,0);

     box_node=new_box_2d_norm(page_node,1,100, 1,1e4, 0.15,0.85, 0.1,0.5);
     box_logxy(box_node,1,1);
     box_set_depth(box_node,0);

     box_set_tick_flag(box_node,RIGHT_SIDE,0,LABEL_EXP);
     box_set_tick_flag(box_node,LEFT_SIDE,0,LABEL_EXP);

     box_unset_tick_flag(box_node,RIGHT_SIDE,0,LABEL_DEFAULT);
     box_unset_tick_flag(box_node,LEFT_SIDE,0,LABEL_DEFAULT);

     box_side_label_offset(box_node,LEFT_SIDE,24.0);
     box_side_label_offset(box_node,RIGHT_SIDE,24.0);
     box_side_label_depth(box_node,LEFT_SIDE,2);
     box_side_label_depth(box_node,BOTTOM_SIDE,2);

     box_side_label_depth(box_node,TOP_SIDE,0);
     box_side_label_depth(box_node,RIGHT_SIDE,0);

   depth_sort_children(page_node->list_children,page_node->n_children);

/* New xy line */
    xy_node=new_xy_defaults(box_node);
    xy_set_var_func(xy_node,XY_X_POINT,"spanl(1,100,10);");
    xy_set_var(xy_node,XY_X_POINT,"x");
/*    xy_set_var_func(xy_node,XY_Y_POINT,"x^3");*/
    xy_set_var(xy_node,XY_Y_POINT,"y");
xy_set_marker(xy_node,5);
/*    xy_set_marker_text(xy_node,"\\c+");  */
    xy_set_line_color(xy_node,0,0,0);
    xy_set_marker_color(xy_node,0,60000,0);

/* New xy line */
    xy_node=new_xy_defaults(box_node);
    xy_set_var(xy_node,XY_X_POINT,"x");
/*    xy_set_var_func(xy_node,XY_Y_POINT,"x^2");*/
    xy_set_var(xy_node,XY_Y_POINT,"y1");
    xy_set_marker(xy_node,5);
/*    xy_set_marker_text(xy_node,"\\DI");   */
    xy_set_line_color(xy_node,0,0,60000);
    xy_set_marker_color(xy_node,60000,0,0);



