/* Some prototypes for fulcrum.c
 C. Steenberg 24/10/1998
 */

void fc_main_exit (GtkWidget *widget, GdkEvent *event, gpointer *data);