/* box_2d.h prototypes for functions in box_2d.h */

box_side *box_side_default(gint index, box_data_2d *box_info);
gint fc_destroy_box_side(box_side *side);
fc_node *new_box_2d_node(fc_node *mother,
                    double x_min_system, double x_max_system,
                    double y_min_system, double y_max_system,
                    double x_min_box, double x_max_box,
                    double y_min_box, double y_max_box);
gint fc_destroy_box(fc_node *box_node);

gint box_side_ndigits(fc_node *object,gchar side, gchar ndigits);
gint box_set_label_color(fc_node *object,gchar side, guint16 r,guint16 g,guint16 b);
gint box_set_tick_color(fc_node *object,gchar side, gchar tick_level, guint16 r,guint16 g,guint16 b);
gint box_set_tick_line_type(fc_node *object,gchar side, gchar tick_level, gchar type);
gint box_unset_tick_flag(fc_node *object,gchar side, gchar tick_level, guint32 flag);
gint box_set_tick_flag(fc_node *object,gchar side, gchar tick_level, guint32 flag);
gint box_unset_flag(fc_node *object,gchar side, guint32 flag);
gint box_set_flag(fc_node *object,gchar side, guint32 flag);

gint box_set_side_pos(fc_node *object, gchar side, double pos);
gint box_set_depth(fc_node *object,gint depth);
/* This function turns on/of the log scaling of a dimension */
gint box_logxy(fc_node *box_node, gint logx, gint logy);

fc_node *new_box_2d(fc_node *page, double x_min_system, double x_max_system,
                    double y_min_system, double y_max_system,
                    double x_min_box, double x_max_box,
                    double y_min_box, double y_max_box);


fc_node *new_box_2d_norm(fc_node *page, double x_min_system, double x_max_system,
                    double y_min_system, double y_max_system,
                    double x_min_box, double x_max_box,
                    double y_min_box, double y_max_box);
		    
fc_node *new_box_2d_abs(fc_node *page, double x_min_system, double x_max_system,
                    double y_min_system, double y_max_system,
                    double x_min_box, double x_max_box,
                    double y_min_box, double y_max_box);

