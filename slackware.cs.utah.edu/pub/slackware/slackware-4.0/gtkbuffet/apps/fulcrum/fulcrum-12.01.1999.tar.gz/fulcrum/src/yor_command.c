/* In this file you will find all the functions and data for the passing of 
   commands to the yorick interpreter
   C. Steenberg 18/9/1998
*/

#include <glib.h>
#include <gtk/gtk.h>
#include <gtk/gtkeditable.h>
#include "gtk_mtext.h"
#include <string.h>


