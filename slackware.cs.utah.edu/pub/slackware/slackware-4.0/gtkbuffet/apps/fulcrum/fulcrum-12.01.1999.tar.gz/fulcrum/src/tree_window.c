#include <glib.h>
#include <gtk/gtk.h>
#include <stdio.h>
#include "object_tree.h"
#include "render_page.h"
#include "graph_window.h"
#include "box_2d.h"
#include "xy_2d.h"
#include "doc_dialog.h"
#include "page_dialog.h"

char fc_tree_icon_file[TREE_ICONS][256]={"2d_box.xpm","folder_blue.xpm",
"p_src.xpm","package.xpm","line_2d.xpm","mini-ball.xpm"};
GdkPixmap *fc_tree_icon[TREE_ICONS];
GdkBitmap *fc_tree_icon_mask[TREE_ICONS];
char fc_icon_search_path[TREE_PATHS][256]={FULCRUM_PIXMAP_PATH,"./","./src/","/usr/share/icons/"};
fc_node *select_tree;

void item_selected (GtkWidget *widget, gpointer data)
{ new_child_node_pointer(select_tree, (fc_node *)data);
}

void item_deselected (GtkWidget *widget, gpointer data)
{ fc_remove_child_pointer_nofree(select_tree, (fc_node *)data);
}

void menu_destroy (GtkWidget *widget, gpointer data)
{ gtk_widget_destroy(widget);
}

fc_node *fc_widget_find(GtkWidget *widget, fc_node *search_node)
{ int i;
  fc_node *fc_node_look;
  if (search_node->n_children==0)
   return(NULL);
  for (i=0;i<search_node->n_children;i++)
    if (((fc_node *)search_node->list_children[i])->item==widget)
     return(search_node->list_children[i]);
   for (i=0;i<search_node->n_children;i++)
     { fc_node_look=fc_widget_find(widget, (fc_node *)search_node->list_children[i]);
       if (fc_node_look)
       return(fc_node_look);
     }
  return(NULL);
}

gint switch_to_doc(GtkWidget *widget, gpointer *data)
{ fc_node *doc;
  doc=(fc_node *)data;
  if (doc!=current_doc)
       { current_doc=doc;
         if (doc->n_children>0)
  	  { current_page=doc->list_children[0];
            fc_graph_replot=TRUE;
            drawing_area_configure_event(drawing_area,(gpointer)1);
            gtk_widget_queue_draw(fc_graph_gscroll);
	  }    
	 else current_page=NULL;
       }
  return(TRUE);
}

gint switch_to_page(GtkWidget *widget, gpointer *data)
{ fc_node *page;
  page=(fc_node *)data;
  if (page!=current_page)
       { current_page=page;
         current_doc=page->parent_node;
         fc_graph_replot=TRUE;
         drawing_area_configure_event(drawing_area,(gpointer)1);
         gtk_widget_queue_draw(fc_graph_gscroll);
       }
  return(TRUE);
}

gint doc_menu(gpointer *data,GdkEventButton *event)
{ GtkWidget *menu, *menu_item;

  menu=gtk_menu_new();
  menu_item=gtk_menu_item_new_with_label("Document");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  menu_item=gtk_menu_item_new();
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  menu_item=gtk_menu_item_new_with_label("Switch to");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(switch_to_doc),data);
  menu_item=gtk_menu_item_new_with_label("Edit");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(create_new_doc_dialog),data);
  menu_item=gtk_menu_item_new_with_label("New page");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(create_new_page_dialog),NULL);
  menu_item=gtk_menu_item_new_with_label("Save");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  menu_item=gtk_menu_item_new_with_label("Delete");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_menu_popup (GTK_MENU(menu), NULL, NULL, NULL, NULL,
                    event->button, event->time);
  gtk_signal_connect (GTK_OBJECT (menu), "unmap_event",
                      GTK_SIGNAL_FUNC (menu_destroy),
                      NULL);
  return(TRUE);
}

gint page_menu(gpointer *data,GdkEventButton *event)
{ GtkWidget *menu, *menu_item;

  menu=gtk_menu_new();
  menu_item=gtk_menu_item_new_with_label("Page");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  menu_item=gtk_menu_item_new();
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  menu_item=gtk_menu_item_new_with_label("Switch to");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(switch_to_page),data);
  menu_item=gtk_menu_item_new_with_label("Edit");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(create_new_page_dialog),data);
  menu_item=gtk_menu_item_new_with_label("Save");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  menu_item=gtk_menu_item_new_with_label("Delete");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_menu_popup (GTK_MENU(menu), NULL, NULL, NULL, NULL,
                    event->button, event->time);
  gtk_signal_connect (GTK_OBJECT (menu), "unmap_event",
                      GTK_SIGNAL_FUNC (menu_destroy),
                      NULL);
  return(TRUE);
}


gint tree_item_clicked (GtkWidget *widget, GdkEventButton *event, gpointer data)
{ fc_node *object;

  object=(fc_node *)data;
  switch (event->button)
   { case 2:
      switch (object->node_type)
      { case DOCUMENT_NODE: switch_to_doc(NULL,data);
                            break;
        case  PAGE_NODE   : switch_to_page(NULL,data);
                            break;
      } break;
    case 3:
      switch (object->node_type)
      { case DOCUMENT_NODE: doc_menu(data,event);
                            break;
        case PAGE_NODE    : page_menu(data,event);
                            break;
      } break;
   }
  return(TRUE);
}


/* call this only once! */
gint new_root(GtkWidget *gscroll)
{ GtkWidget *tree;
  fc_mother_node=new_fc_node(5,MOTHER_NODE);
  if (!fc_mother_node)
   { g_error("Could not create mother node!");
     return(0);
   }

  tree = gtk_tree_new();
  gtk_widget_show(tree);
  if (!tree) return(0);
  fc_mother_node->tree=tree;
  fc_mother_node->item=NULL; /* because it doesn't appear on screen */
#if GTK_MAJOR_VERSION==1 && GTK_MINOR_VERSION==1 && GTK_MICRO_VERSION>=5
  gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(gscroll), 
                                        tree);
#else
  gtk_container_add(GTK_CONTAINER(gscroll), tree);
#endif
  gtk_tree_set_selection_mode(GTK_TREE(tree), GTK_SELECTION_MULTIPLE);
  gtk_tree_set_view_lines(GTK_TREE(tree), TRUE);
  gtk_tree_set_view_mode(GTK_TREE(tree), GTK_TREE_VIEW_LINE);

  return(1);
}

fc_node *new_document(fc_node *mother, char *doc_name)
{ GtkWidget *doc_tree, *doc_item,*label,*box,*pixwidget;
  fc_node *doc_node;

/* create document tree item widget */
  doc_node=new_doc_node(mother, doc_name);
  printf("created doc node %x\n",doc_node);
  doc_item = gtk_tree_item_new();
  box=gtk_hbox_new(FALSE,0);
  gtk_container_add(GTK_CONTAINER(doc_item),box);
  gtk_signal_connect (GTK_OBJECT (doc_item), "select",
                             GTK_SIGNAL_FUNC (item_selected),
                             (gpointer)doc_node);

  gtk_signal_connect (GTK_OBJECT (doc_item), "deselect",
                             GTK_SIGNAL_FUNC (item_deselected),
                             (gpointer)doc_node);
   gtk_signal_connect (GTK_OBJECT (doc_item), "button_press_event",
                      (GtkSignalFunc) tree_item_clicked, (gpointer)doc_node);
  if (fc_tree_icon[1])
   {  pixwidget=gtk_pixmap_new (fc_tree_icon[1], fc_tree_icon_mask[1]);
      gtk_box_pack_start (GTK_BOX (box),
                        pixwidget, FALSE, FALSE, 1);
      gtk_widget_show(pixwidget);
   }

  label=gtk_label_new(doc_name);
  doc_node->label=label;
  gtk_box_pack_start (GTK_BOX (box),
                        label, FALSE, FALSE, 1);


  gtk_widget_show(doc_item);
  ((fc_node *)(mother->list_children[mother->n_children-1]))->item=doc_item;

  gtk_tree_append(GTK_TREE(fc_mother_node->tree), doc_item);

  gtk_tree_item_expand(GTK_TREE_ITEM(doc_item));

  doc_tree=gtk_tree_new();
  gtk_widget_show(label);
  gtk_widget_show(box);
  gtk_widget_show(doc_tree);
  ((fc_node *)(mother->list_children[mother->n_children-1]))->tree=doc_tree;
  doc_node->tree=doc_tree;
  doc_node->item=doc_item;

  return(doc_node);
}

fc_node *new_page_defaults(fc_node *doc)
{ GtkWidget *page_tree, *page_item,*label,*box,*pixwidget;
  char page_number[20];
  fc_node *page_node;

  page_node=new_page_node_defaults(doc); /* create default page */
  sprintf(page_number,"p.%d",doc->n_children);
/* create root tree item widget */
  page_item = gtk_tree_item_new();
  ((fc_node *)(doc->list_children[doc->n_children-1]))->item=page_item;
  if (!doc->is_container)
   { gtk_tree_item_set_subtree(GTK_TREE_ITEM(doc->item),GTK_WIDGET(doc->tree));
     doc->is_container=TRUE;
   }
  gtk_signal_connect (GTK_OBJECT (page_item), "select",
                             GTK_SIGNAL_FUNC (item_selected),
                             (gpointer)page_node);

  gtk_signal_connect (GTK_OBJECT (page_item), "deselect",
                             GTK_SIGNAL_FUNC (item_deselected),
                             (gpointer)page_node);
   gtk_signal_connect(GTK_OBJECT (page_item), "button_press_event",
                      (GtkSignalFunc) tree_item_clicked, (gpointer)page_node);

  gtk_tree_append(GTK_TREE(doc->tree), page_item);
  gtk_tree_item_expand(GTK_TREE_ITEM(page_item));

  box=gtk_hbox_new(FALSE,0);
  gtk_container_add(GTK_CONTAINER(page_item),box);
  if (fc_tree_icon[2])
   {  pixwidget=gtk_pixmap_new (fc_tree_icon[2], fc_tree_icon_mask[2]);
      gtk_box_pack_start (GTK_BOX (box),
                        pixwidget, FALSE, FALSE, 1);
      gtk_widget_show(pixwidget);
   }


  label=gtk_label_new(page_number);
  page_node->label=label;
  gtk_box_pack_start (GTK_BOX (box),
                        label, FALSE, FALSE, 1);

  gtk_widget_show(label);
  gtk_widget_show(box);
  gtk_widget_show(page_item);

  page_tree=gtk_tree_new();
  gtk_widget_show(page_tree);
  ((fc_node *)(doc->list_children[doc->n_children-1]))->tree=page_tree;
  page_node->tree=page_tree;
  page_node->item=page_item;

  return(page_node);
}


fc_node *new_box_2d(fc_node *page, double x_min_system, double x_max_system,
                    double y_min_system, double y_max_system,
                    double x_min_box, double x_max_box,
                    double y_min_box, double y_max_box)
{ GtkWidget *box_tree, *box_item,*label,*box,*pixwidget;
  char box_number[20];
  fc_node *box_node;

box_node=(fc_node *)new_box_2d_node(page, x_min_system, x_max_system,
                    y_min_system, y_max_system,
                    x_min_box, x_max_box,
                    y_min_box, y_max_box); /* create box system */
  sprintf(box_number,"sys %d",page->n_children);
/* create box tree item widget */
  box_item = gtk_tree_item_new();
  ((fc_node *)(page->list_children[page->n_children-1]))->item=box_item;
  if (!page->is_container)
   { gtk_tree_item_set_subtree(GTK_TREE_ITEM(page->item),GTK_WIDGET(page->tree));
     page->is_container=TRUE;
   }
  gtk_tree_append(GTK_TREE(page->tree), box_item);
  gtk_tree_item_expand(GTK_TREE_ITEM(box_item));
  gtk_signal_connect (GTK_OBJECT (box_item), "select",
                             GTK_SIGNAL_FUNC (item_selected),
                             (gpointer)box_node);

  gtk_signal_connect (GTK_OBJECT (box_item), "deselect",
                             GTK_SIGNAL_FUNC (item_deselected),
                             (gpointer)box_node);


  box=gtk_hbox_new(FALSE,0);
  gtk_container_add(GTK_CONTAINER(box_item),box);
  if (fc_tree_icon[3])
   {  pixwidget=gtk_pixmap_new (fc_tree_icon[3], fc_tree_icon_mask[3]);
      gtk_box_pack_start (GTK_BOX (box),
                        pixwidget, FALSE, FALSE, 1);
      gtk_widget_show(pixwidget);
   }

  label=gtk_label_new(box_number);
  box_node->label=label;
  gtk_box_pack_start (GTK_BOX (box),
                        label, FALSE, FALSE, 1);

  gtk_widget_show(label);
  gtk_widget_show(box);
  gtk_widget_show(box_item);

  box_tree=gtk_tree_new();
  gtk_widget_show(box_tree);
  ((fc_node *)(page->list_children[page->n_children-1]))->tree=box_tree;
  return(box_node);
}

fc_node *new_xy_defaults(fc_node *box_node)
{ GtkWidget *xy_tree, *xy_item, *label,*box,*pixwidget;
  char xy_name[20];
  fc_node *xy_node;

  xy_node=new_xy_2d_node(box_node); /* create default line */
  sprintf(xy_name,"line %d",box_node->n_children);
/* create root tree item widget */
  xy_item = gtk_tree_item_new();
  ((fc_node *)(box_node->list_children[box_node->n_children-1]))->item=xy_item;
  if (!box_node->is_container)
   { gtk_tree_item_set_subtree(GTK_TREE_ITEM(box_node->item),GTK_WIDGET(box_node->tree));
     box_node->is_container=TRUE;
   }
  gtk_tree_append(GTK_TREE(box_node->tree), xy_item);
  gtk_tree_item_expand(GTK_TREE_ITEM(xy_item));
  gtk_signal_connect (GTK_OBJECT (xy_item), "select",
                             GTK_SIGNAL_FUNC (item_selected),
                             (gpointer)xy_node);
  gtk_signal_connect (GTK_OBJECT (xy_item), "deselect",
                             GTK_SIGNAL_FUNC (item_deselected),
                             (gpointer)xy_node);


  box=gtk_hbox_new(FALSE,0);
  gtk_container_add(GTK_CONTAINER(xy_item),box);
  if (fc_tree_icon[4])
   {  pixwidget=gtk_pixmap_new (fc_tree_icon[4], fc_tree_icon_mask[4]);
      gtk_box_pack_start (GTK_BOX (box),
                        pixwidget, FALSE, FALSE, 1);
      gtk_widget_show(pixwidget);
   }

  label=gtk_label_new(xy_name);
  xy_node->label=label;
  gtk_box_pack_start (GTK_BOX (box),
                        label, FALSE, FALSE, 1);

  gtk_widget_show(label);
  gtk_widget_show(box);
  gtk_widget_show(xy_item);

  xy_tree=gtk_tree_new();
  gtk_widget_show(xy_tree);
  ((fc_node *)(box_node->list_children[box_node->n_children-1]))->tree=xy_tree;
  xy_node->tree=xy_tree;
  xy_node->item=xy_item;

  return(xy_node);
}

int fc_init_tree_win(GtkWidget *hpane,GtkWidget *main_win)
{ GtkWidget *gscroll,*doc_tree, *doc_item, *page_subtree, *page_item;
  fc_node *doc_node,*page_node, *box_node, *xy_node;
  GtkStyle *style;
  gint i,j;
  FILE *filep;
  char filename[512];
  gscroll=gtk_scrolled_window_new(NULL,NULL);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(gscroll),
                                 GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_paned_add1(GTK_PANED(hpane),gscroll);
  gtk_widget_show(gscroll);
/* Read in pixmaps from a file */
  style = gtk_widget_get_style(main_win);

  for (i=0;i<TREE_ICONS;i++)
   { 
     for (j=0;j<TREE_PATHS;j++)
      { filename[0]='\0';
        strcat(filename,fc_icon_search_path[j]);
        strcat(filename,fc_tree_icon_file[i]);
        filep=fopen(filename,"r");
        if (filep!=NULL) break;
      }
      if (j<TREE_PATHS)
       fc_tree_icon[i] =
         gdk_pixmap_create_from_xpm (main_win->window, &fc_tree_icon_mask[i],
                                      &style->bg[GTK_STATE_NORMAL],
                                      filename);
     else
      { printf("Could not open %s, tried paths:\n",fc_tree_icon_file[i]);
         for (j=0;j<TREE_PATHS;j++)
          printf("%s%s\n",fc_icon_search_path[j],fc_tree_icon_file[i]);
	 printf("\n"); 
      }
   }
/* Add new document as a demo */
  new_root(gscroll);
  select_tree=new_mother_node();
  
/*  doc_node=new_document(fc_mother_node,"Doc 1");
  printf("new document\n");
  current_doc=doc_node;

  page_node=new_page_defaults(doc_node);
  current_page=page_node;     
  printf("new page\n");
   depth_sort_children(page_node->list_children,page_node->n_children);
  current_page=page_node;     

  page_node=new_page_defaults(doc_node);
  gtk_tree_item_expand(GTK_TREE_ITEM(page_node->item));*/

  return(1);
}
