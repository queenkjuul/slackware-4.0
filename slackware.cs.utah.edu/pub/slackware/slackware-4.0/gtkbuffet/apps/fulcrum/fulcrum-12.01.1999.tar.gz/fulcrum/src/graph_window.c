/* All the functions and data for the setup and display of the graphics window
   C. Steenberg 12/09/1998
*/

#include <glib.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#ifndef GTK_HAVE_GDK_RGB
#include "gdkrgb.h"
#endif
#include <stdio.h>
#include <string.h>
#include "gdkprivate.h"
#include <plot.h>
#include "object_tree.h"
#include "render_page.h"
extern double page_magn,screen_dpi;
double page_magn_x,page_magn_y;
gchar fc_render_busy=FALSE, fc_graph_configure=TRUE, fc_graph_busy=FALSE,
      fc_graph_replot=FALSE,fc_fit_width=FALSE,fc_fit_whole=TRUE;

#define EVENT_METHOD(i,x) GTK_WIDGET_CLASS(GTK_OBJECT(i)->klass)->x

static GdkPixmap *pixmap = NULL;
int pl_handle=0,first_time=1;
gchar fc_expand_graph_window=1,fc_show_graph_rulers=1;
gint gwidth=100,gheight=100,gwidth_min=20,gheight_min=20, in_configure=0, render_tag;
GtkWidget *left_vruler, *top_hruler, *right_vruler, *bottom_hruler,
          *graph_label, *fc_graph_gscroll, *graph_frame, *drawing_area, 
	  *align, *gtable;



#define MAXORDER 12
void draw_c_curve (double dx, double dy, int order)
{
  if (order >= MAXORDER)
    fcontrel (dx, dy);        /* continue path along (dx, dy) */
  else
    {
      draw_c_curve (0.5 * (dx - dy), 0.5 * (dx + dy), order + 1);
      draw_c_curve (0.5 * (dx + dy), 0.5 * (dy - dx), order + 1);      
    }
}

static gint
notebook_configure_event (GtkWidget *widget, GdkEventConfigure *event)
{ gint width,height;
  page_data *page_info;
  gint xsize,ysize,setpar=0;

  width=widget->allocation.width;
  height=widget->allocation.height;

/* The next section is a very ugly hack, but it works, for now... */
  if (fc_show_graph_rulers)
   { xsize=2*left_vruler->allocation.width;
     xsize+=GTK_SCROLLED_WINDOW(fc_graph_gscroll)->vscrollbar->allocation.width+10;
     ysize=2*top_hruler->allocation.height;
     ysize+=GTK_SCROLLED_WINDOW(fc_graph_gscroll)->hscrollbar->allocation.height+10;
   }
  else
   { xsize=GTK_SCROLLED_WINDOW(fc_graph_gscroll)->vscrollbar->allocation.width+9;
     ysize=GTK_SCROLLED_WINDOW(fc_graph_gscroll)->hscrollbar->allocation.height+9;
   }
if (!fc_expand_graph_window)
 { if (width>gwidth+xsize) width=gwidth+xsize;
   if (height>gheight+ysize) height=gheight+ysize;
 }
  gtk_widget_set_usize( GTK_WIDGET (fc_graph_gscroll), width, height);
  return(TRUE);
}


static gint
align_configure_event (GtkWidget *widget, GdkEventConfigure *event)
{ double width,height;
  page_data *page_info;
  gint xdiff,ydiff,setpar=0;
  width=widget->allocation.width;
  height=widget->allocation.height;
  if (current_page)
  { page_info=(page_data *)(current_page->node_data);
    if (height>width)
      width=(page_info->x_max/page_info->y_max)*height;
    else
      height=(page_info->y_max/page_info->x_max)*width;

    if (height<widget->allocation.height)
     {  width=(page_info->x_max/page_info->y_max)*widget->allocation.height;
        height=(page_info->y_max/page_info->x_max)*width;
     }
    if (width<widget->allocation.width)
     {  height=(page_info->y_max/page_info->x_max)*widget->allocation.width;
        width=(page_info->x_max/page_info->y_max)*height;
     }
  }
  else return(TRUE);
  
  if (height/width>2) width=ceil(height/2);
   page_info->x_max_screen=width;
   page_info->y_max_screen=height;
  gwidth=width;
  gheight=height;
  if (gwidth<=0) gwidth=1;
  if (gheight<=0) gheight=1;

  gtk_drawing_area_size(GTK_DRAWING_AREA(drawing_area),gwidth,gheight);  	
  gtk_widget_set_usize( GTK_WIDGET (drawing_area), gwidth,gheight);
  printf("\nheight=%d width=%d h/w=%2.2f cp=%x\n",gheight,gwidth,height/width,current_page);
  printf("  aheight=%d awidth=%d i_c=%d\n",widget->allocation.height,
            widget->allocation.width,in_configure);

  return(TRUE);
}

gint create_plot(GtkWidget *widget,page_data *page_info, double width, double height)
{ char geometry[20];
  double y_max;
    if (pl_handle>0)
     { selectpl(0);
       deletepl(pl_handle);
     }
    if (pixmap)
      gdk_pixmap_unref(pixmap);
    
    gtk_ruler_set_range(GTK_RULER(top_hruler),0,page_info->x_max,0,page_info->x_max);
    gtk_ruler_set_range(GTK_RULER(left_vruler),0,page_info->y_max,0,page_info->y_max);

    gtk_ruler_set_range(GTK_RULER(bottom_hruler),0,page_info->x_max,0,page_info->x_max);
    gtk_ruler_set_range(GTK_RULER(right_vruler),0,page_info->y_max,0,page_info->y_max);

    
    pixmap = gdk_pixmap_new(widget->window,
  			  gwidth,
  			  gheight,
  			  -1);
    if (!pixmap)
     { printf("Pixmap could not be created!");
       return (FALSE);
     }
    printf("geometry=%dx%d\n",gwidth,
  			   gheight);

    sprintf(geometry,"%dx%d",gwidth,
  			   gheight);
    parampl ("XDRAWABLE_DISPLAY", ((GdkWindowPrivate*)pixmap)->xdisplay);
    parampl ("XDRAWABLE_DRAWABLE1", &(((GdkWindowPrivate*)pixmap)->xwindow));
    parampl ("XDRAWABLE_DRAWABLE2", &(((GdkWindowPrivate*)pixmap)->xwindow));
    parampl ("BITMAPSIZE", geometry);

    pl_handle = newpl ("Xdrawable", NULL, NULL, stderr);

    selectpl (pl_handle);
    openpl ();
    y_max=width/height;
    fspace (0.0, 0.0, width/height, 1.0);
    bgcolor(page_info->bg_color->r,page_info->bg_color->g,
             page_info->bg_color->b);
    erase ();      /* erase Plotter's graphics display, aka draw it*/
    return(TRUE);
}


gint drawing_area_configure_event (GtkWidget *widget, GdkEventConfigure *event)
{gchar *bg_colorname = "white", geometry[20],flag=FALSE;
 double width,height, tw,th;
 page_data *page_info;
 gint xdiff,ydiff,setpar=0, new_gheight, new_gwidth;
 GdkEventConfigure my_event;
 GtkRequisition req; 
 GtkAllocation alloc;
 double y_max;

 
  if (fc_render_busy || fc_graph_busy|| !current_page) return(FALSE);
  width=widget->allocation.width;
  height=widget->allocation.height;
  fc_graph_busy=TRUE;
    printf("\ngeometry_1=%dx%d\n",gwidth,
  			   gheight);

  if (fc_graph_configure)
  {  
#if GTK_MAJOR_VERSION==1 && GTK_MINOR_VERSION==1 && GTK_MICRO_VERSION>=6
      width=GTK_BIN(fc_graph_gscroll)->child->allocation.width-
            left_vruler->allocation.width-right_vruler->allocation.width-4;
      if (width<gwidth_min) width=gwidth_min;
      height=GTK_BIN(fc_graph_gscroll)->child->allocation.height-
            top_hruler->allocation.height-bottom_hruler->allocation.height-4;
      if (height<gheight_min) height=gheight_min;
#else
      width=GTK_SCROLLED_WINDOW(fc_graph_gscroll)->viewport->allocation.width-
            left_vruler->allocation.width-right_vruler->allocation.width-4;
      if (width<gwidth_min) width=gwidth_min;
      height=GTK_SCROLLED_WINDOW(fc_graph_gscroll)->viewport->allocation.height-
            top_hruler->allocation.height-bottom_hruler->allocation.height-4;
      if (height<gheight_min) height=gheight_min;
#endif
    page_info=(page_data *)(current_page->node_data);
    if (fc_fit_whole)
     { tw=(page_info->x_max/page_info->y_max)*height;
       th=(page_info->y_max/page_info->x_max)*width;
       if (tw<width)
        height=(page_info->y_max/page_info->x_max)*width;
       if (th<height)
        width=(page_info->x_max/page_info->y_max)*height;
     }
    else
      if (!fc_fit_width)
        width=(page_info->x_max/page_info->y_max)*height;
      else
        height=(page_info->y_max/page_info->x_max)*width;

/*    if (height<widget->allocation.height)
     {  width=(page_info->x_max/page_info->y_max)*widget->allocation.height;
        height=(page_info->y_max/page_info->x_max)*width;
     }
    if (width<widget->allocation.width)
     {  height=(page_info->y_max/page_info->x_max)*widget->allocation.width;
        width=(page_info->x_max/page_info->y_max)*height;
     }*/
  if (height/width>2) width=ceil(height/2);
  if (width<=0) width=1;
  if (height<=0) height=1;
  new_gwidth=width;
  new_gheight=height;
  printf("geometry_1.5=%dx%d\n",new_gwidth,
  			   new_gheight);
   }
  else 
   { page_info=(page_data *)(current_page->node_data); 
     switch (page_info->units)
     { case INCHES:   page_info->x_max_screen=page_info->x_max*screen_dpi*page_magn;
                 page_info->y_max_screen=page_info->y_max*screen_dpi*page_magn;
                 break;
       case CM    :   page_info->x_max_screen=page_info->x_max*screen_dpi*page_magn/2.54;
                 page_info->y_max_screen=page_info->y_max*screen_dpi*page_magn/2.54;
                 break;
       case MM    :   page_info->x_max_screen=page_info->x_max*screen_dpi*page_magn/25.4;
                 page_info->y_max_screen=page_info->y_max*screen_dpi*page_magn/25.4;
                 break;
       case POINTS:   page_info->x_max_screen=page_info->x_max*screen_dpi*page_magn/72.72;
                 page_info->y_max_screen=page_info->y_max*screen_dpi*page_magn/72.72;
                 break;
       case PIXELS:   page_info->x_max_screen=page_info->x_max*page_magn;
                 page_info->y_max_screen=page_info->y_max*page_magn;
                 break;
     }
     new_gwidth=page_info->x_max_screen;
     new_gheight=page_info->y_max_screen;
  }

  if (new_gwidth!=gwidth || new_gheight!=gheight || fc_graph_replot)
   { gwidth=new_gwidth;
     gheight=new_gheight;
     gtk_widget_set_usize( GTK_WIDGET (drawing_area), gwidth,gheight);
     printf("geometry_2=%dx%d\n",gwidth,
  			   gheight);

     page_info->x_max_screen=gwidth;
     page_info->y_max_screen=gheight;
     create_plot(widget,page_info,gwidth,gheight);
 
     if (current_page&&gwidth>20)
        render_page(current_page);
     fc_graph_replot=FALSE;
   }
  fc_graph_busy=FALSE;
  return TRUE;
}

gint g_render_page(void)
{ printf("g_render_page\n");
  selectpl (pl_handle);
  if (current_page&&gwidth>20)
    render_page(current_page);
  if (!fc_render_busy)
    { closepl();
      gtk_timeout_remove(render_tag);
      gtk_widget_queue_draw(drawing_area);
    }
  return(1);

}

gint g_render_update(gpointer data)
{ printf("g_render_update\n");
  gtk_widget_queue_draw(drawing_area);
}
/* Redraw the screen from the backing pixmap */
static gint
expose_event (GtkWidget *widget, GdkEventExpose *event)
{
  if (pixmap)
  gdk_draw_pixmap(widget->window,
		  widget->style->fg_gc[GTK_WIDGET_STATE (widget)],
		  pixmap,
		  event->area.x, event->area.y,
		  event->area.x, event->area.y,
		  event->area.width, event->area.height);

  return FALSE;
}

static gint
motion_notify_event (GtkWidget *widget, GdkEventMotion *event)
{
  int x, y;
  GdkModifierType state;

  if (event->is_hint)
    gdk_window_get_pointer (event->window, &x, &y, &state);
  else
    {
      x = event->x;
      y = event->y;
      state = event->state;
    }
  
  return TRUE;
}

void button_event (GtkWidget *widget, GdkEvent *event, gpointer *data)
{   gtk_drawing_area_size (GTK_DRAWING_AREA (drawing_area), gwidth, gheight);
    gtk_widget_set_usize( GTK_WIDGET (drawing_area), gwidth,gheight);
    printf("button_event\n");
}

gint redraw_graph(GtkWidget *widget, gpointer *data)
{ fc_graph_replot=TRUE;
  drawing_area_configure_event(drawing_area,(gpointer)1);
  gtk_widget_queue_draw(fc_graph_gscroll);
  return(TRUE);
}

gint redraw_width(GtkWidget *widget, gpointer *data)
{ fc_graph_configure=TRUE;
  fc_fit_width=TRUE;
  fc_fit_whole=FALSE;
  fc_graph_replot=TRUE;
  drawing_area_configure_event(drawing_area,(gpointer)1);
  gtk_widget_queue_draw(fc_graph_gscroll);
  gtk_adjustment_set_value(GTK_RANGE(GTK_SCROLLED_WINDOW(fc_graph_gscroll)->hscrollbar)->adjustment,0);
  gtk_adjustment_set_value(GTK_RANGE(GTK_SCROLLED_WINDOW(fc_graph_gscroll)->vscrollbar)->adjustment,0);
  return(TRUE);
}

gint redraw_height(GtkWidget *widget, gpointer *data)
{ fc_graph_configure=TRUE;
  fc_fit_width=FALSE;
  fc_fit_whole=FALSE;
  fc_graph_replot=TRUE;
  drawing_area_configure_event(drawing_area,(gpointer)1);
  gtk_widget_queue_draw(fc_graph_gscroll);
  gtk_adjustment_set_value(GTK_RANGE(GTK_SCROLLED_WINDOW(fc_graph_gscroll)->hscrollbar)->adjustment,0);
  gtk_adjustment_set_value(GTK_RANGE(GTK_SCROLLED_WINDOW(fc_graph_gscroll)->vscrollbar)->adjustment,0);
  return(TRUE);
}

gint redraw_full(GtkWidget *widget, gpointer *data)
{ fc_graph_configure=TRUE;
  fc_fit_width=FALSE;
  fc_fit_whole=TRUE;
  fc_graph_replot=TRUE;
  drawing_area_configure_event(drawing_area,(gpointer)1);
  gtk_widget_queue_draw(fc_graph_gscroll);
  return(TRUE);
}

gint redraw_zoom(GtkWidget *widget, gpointer *data)
{ fc_graph_configure=FALSE;
  fc_fit_width=FALSE;
  fc_fit_whole=FALSE;
  fc_graph_replot=TRUE;
  drawing_area_configure_event(drawing_area,(gpointer)1);
  gtk_widget_queue_draw(fc_graph_gscroll);
  return(TRUE);
}


gint tab_menu(GtkWidget *widget,GdkEventButton *event, gpointer data)
{ GtkWidget *menu, *menu_item;
  gchar zoom_label[50]="Draw with zoom ";
  printf("button clicked in drawing\n");

  menu=gtk_menu_new();
  menu_item=gtk_menu_item_new_with_label("Plot window");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  menu_item=gtk_menu_item_new();
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  menu_item=gtk_menu_item_new_with_label("Redraw");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(redraw_graph),NULL);
  menu_item=gtk_menu_item_new_with_label("Fit to width");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(redraw_width),NULL);

  menu_item=gtk_menu_item_new_with_label("Fit to height");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(redraw_height),NULL);

  menu_item=gtk_menu_item_new_with_label("Maximize page");
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(redraw_full),NULL);

  sprintf(zoom_label,"Draw with zoom %2.0f%%",page_magn*100);
  menu_item=gtk_menu_item_new_with_label(zoom_label);
  gtk_menu_append(GTK_MENU (menu), menu_item);
  gtk_widget_show(menu_item);
  gtk_signal_connect( GTK_OBJECT(menu_item), "activate",
                      GTK_SIGNAL_FUNC(redraw_zoom),NULL);

  gtk_menu_popup (GTK_MENU(menu), NULL, NULL, NULL, NULL,
                    event->button, event->time);
  gtk_signal_connect (GTK_OBJECT (menu), "unmap_event",
                      GTK_SIGNAL_FUNC (gtk_widget_destroy),
                      NULL);
  return(TRUE);
}


gint notebook_clicked (GtkWidget *widget, GdkEventButton *event, gpointer data)
{ fc_node *object;

  switch (event->button)
   { case 3: tab_menu(widget,event,NULL);
   }
  return(TRUE);
}


int fc_init_graph_win(GtkWidget *notebook)
{ GtkWidget *window, *button, *event_box, *event_box_top;
  page_data *page_info;
  double ratio;

  gtable = gtk_table_new (3,3,FALSE);
  fc_graph_gscroll=gtk_scrolled_window_new(NULL,NULL);
  align=gtk_alignment_new(0.5,0.5,0,0);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(fc_graph_gscroll),
                                 GTK_POLICY_ALWAYS, GTK_POLICY_ALWAYS);
#if GTK_MAJOR_VERSION==1 && GTK_MINOR_VERSION==1 && GTK_MICRO_VERSION>=5
  gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(fc_graph_gscroll), 
                                        align);
#else
 gtk_container_add (GTK_CONTAINER (fc_graph_gscroll), align);
#endif
  gtk_container_add (GTK_CONTAINER (align), gtable);
  gtk_range_set_update_policy
      (GTK_RANGE(GTK_SCROLLED_WINDOW(fc_graph_gscroll)->hscrollbar),
        GTK_UPDATE_DELAYED);
    gtk_range_set_update_policy
      (GTK_RANGE(GTK_SCROLLED_WINDOW(fc_graph_gscroll)->vscrollbar),
        GTK_UPDATE_DELAYED);
  drawing_area = gtk_drawing_area_new ();

  if (current_page)
   { page_info=(page_data *)(current_page->node_data); 
     ratio=page_info->x_max/page_info->y_max;
     switch (page_info->units)
     { case INCHES:   page_info->x_max_screen=page_info->x_max*screen_dpi*page_magn;
                 page_info->y_max_screen=page_info->y_max*screen_dpi*page_magn;
                 break;
       case CM    :   page_info->x_max_screen=page_info->x_max*screen_dpi*page_magn/2.54;
                 page_info->y_max_screen=page_info->y_max*screen_dpi*page_magn/2.54;
                 break;
       case MM    :   page_info->x_max_screen=page_info->x_max*screen_dpi*page_magn/25.4;
                 page_info->y_max_screen=page_info->y_max*screen_dpi*page_magn/25.4;
                 break;
       case POINTS:   page_info->x_max_screen=page_info->x_max*screen_dpi*page_magn/72.72;
                 page_info->y_max_screen=page_info->y_max*screen_dpi*page_magn/72.72;
                 break;
       case PIXELS:   page_info->x_max_screen=page_info->x_max*page_magn;
                 page_info->y_max_screen=page_info->y_max*page_magn;
                 break;
     }
     gwidth=page_info->x_max_screen;
     gheight=page_info->y_max_screen;
  }
  else
  { gwidth=100;
    gheight=100;
  }
  gtk_widget_set_usize( GTK_WIDGET (drawing_area), gwidth,gheight);

  gtk_table_attach(GTK_TABLE(gtable), drawing_area, 1,2,1,2,
                   0,0,0,0);
  /* Signals used to handle backing pixmap */

  gtk_widget_set_events (drawing_area, GDK_EXPOSURE_MASK
			 | GDK_LEAVE_NOTIFY_MASK
			 | GDK_BUTTON_PRESS_MASK
			 | GDK_POINTER_MOTION_MASK
			 | GDK_POINTER_MOTION_HINT_MASK);


  gtk_signal_connect (GTK_OBJECT (drawing_area), "expose_event",
		      (GtkSignalFunc) expose_event, NULL);
  gtk_signal_connect (GTK_OBJECT(drawing_area),"configure_event",
		      (GtkSignalFunc) drawing_area_configure_event, NULL);


  /* Event signals */

  gtk_signal_connect (GTK_OBJECT (drawing_area), "motion_notify_event",
		      (GtkSignalFunc) motion_notify_event, NULL);
  gtk_signal_connect (GTK_OBJECT (drawing_area), "button_press_event",
                      (GtkSignalFunc) notebook_clicked, NULL);



  /* Add top and left rulers */
  top_hruler=gtk_hruler_new();
  left_vruler=gtk_vruler_new();

  gtk_table_attach(GTK_TABLE(gtable), top_hruler, 1,2,0,1,
                   GTK_FILL,
                   GTK_FILL,0,0);
  gtk_table_attach(GTK_TABLE(gtable), left_vruler,0,1,1,2,
                   GTK_FILL,
                   GTK_FILL,0,0);

  if (fc_show_graph_rulers)
   { gtk_widget_show (top_hruler);
     gtk_widget_show (left_vruler);
   }

   gtk_signal_connect_object(GTK_OBJECT(drawing_area),"motion_notify_event",
     (GtkSignalFunc)EVENT_METHOD(top_hruler,motion_notify_event),GTK_OBJECT(top_hruler));
   gtk_signal_connect_object(GTK_OBJECT(drawing_area),"motion_notify_event",
     (GtkSignalFunc)EVENT_METHOD(left_vruler,motion_notify_event),GTK_OBJECT(left_vruler));

  /* Add bottom and right rulers */
  bottom_hruler=gtk_hruler_new();
  right_vruler=gtk_vruler_new();

  
  gtk_table_attach(GTK_TABLE(gtable), bottom_hruler, 1,2,2,3,
                   GTK_FILL,
                   GTK_FILL,0,0);
  gtk_table_attach(GTK_TABLE(gtable), right_vruler,2,3,1,2,
                   GTK_FILL,
                   GTK_FILL,0,0);
  if (fc_show_graph_rulers)
   { gtk_widget_show (bottom_hruler);
     gtk_widget_show (right_vruler);
   };

   gtk_signal_connect_object(GTK_OBJECT(drawing_area),"motion_notify_event",
     (GtkSignalFunc)EVENT_METHOD(bottom_hruler,motion_notify_event),GTK_OBJECT(bottom_hruler));
   gtk_signal_connect_object(GTK_OBJECT(drawing_area),"motion_notify_event",
     (GtkSignalFunc)EVENT_METHOD(right_vruler,motion_notify_event),GTK_OBJECT(right_vruler));
   if (current_page){
    gtk_ruler_set_range(GTK_RULER(top_hruler),0,page_info->x_max,0,page_info->x_max);
    gtk_ruler_set_range(GTK_RULER(left_vruler),0,page_info->y_max,0,page_info->y_max);
  
    gtk_ruler_set_range(GTK_RULER(bottom_hruler),0,page_info->x_max,0,page_info->x_max);
    gtk_ruler_set_range(GTK_RULER(right_vruler),0,page_info->y_max,0,page_info->y_max);
   }
  else {
    gtk_ruler_set_range(GTK_RULER(top_hruler),0,100,0,100);
    gtk_ruler_set_range(GTK_RULER(left_vruler),0,100,0,100);
  
    gtk_ruler_set_range(GTK_RULER(bottom_hruler),0,100,0,100);
    gtk_ruler_set_range(GTK_RULER(right_vruler),0,100,0,100);
   }

   graph_label=gtk_label_new("Plot window");
   gtk_notebook_insert_page(GTK_NOTEBOOK(notebook),fc_graph_gscroll,graph_label,1);
 
/*   gtk_signal_connect (GTK_OBJECT(event_box_top),"expose_event",
		      (GtkSignalFunc) notebook_configure_event, NULL);*/

   gtk_widget_show (drawing_area);
   gtk_widget_show (gtable);
   gtk_widget_show (graph_label);
   gtk_widget_show (fc_graph_gscroll);
   gtk_widget_show (align);
}