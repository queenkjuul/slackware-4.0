int *fc_yor_data_dims, fc_yor_init=0;
double *fc_yor_data;

void fc_info_c(int *dims, double *var)
{ 
  printf("fc_yor fc_yor_data=%x\n",var);
  fc_yor_data_dims=dims;
  fc_yor_data=var;
}

void fc_init_c(int init)
{   printf("fc_yor_init 1\n");
    fc_yor_init=1;
}