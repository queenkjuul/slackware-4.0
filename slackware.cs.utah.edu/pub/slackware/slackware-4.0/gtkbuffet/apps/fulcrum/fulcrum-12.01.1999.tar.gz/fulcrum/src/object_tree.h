/* Implements object tree structure and functions for inserting and removing
   subtrees and objects.
   C. Steenberg 13/09/1998
*/

#include <time.h>
#include <gdk/gdk.h>

/* Node types */
#define MOTHER_NODE 1
#define DOCUMENT_NODE 2
#define PAGE_NODE 3
#define BOX_2D_NODE 4
#define XY_2D_NODE 5

#define NODE_VERSION 1
#define DOC_VERSION 1
#define PAGE_VERSION 1
#define BOX_2D_VERSION 1
#define BOX_SIDE_VERSION 1
#define XY_2D_NODE_VERSION 1

#define PIXELS 1
#define POINTS 2
#define MM     3
#define CM     4
#define INCHES 5

extern double fc_units_per_inch[5];

typedef struct _fc_color
{ guint16 r;
  guint16 g;
  guint16 b;
} fc_color;


typedef struct _fc_node
{ char version;
  char is_container;
  gint max_children; /* Number of children that memory has been alloced for */
  gint n_children;   /* Number of children created */
  gpointer *list_children;
  gpointer parent_node;
  gint node_type,node_icon;
  gpointer node_data;
  GtkWidget *tree, *item, *label;
} fc_node;

typedef struct _doc_data
{ char version;
  char *doc_name;
  char *creator_name;
  GtkTree *tree;
  GtkTreeItem *tree_item;
  time_t create_time;
  time_t modify_time;
} doc_data;

typedef struct _page_data
{ char version;
  GtkTree *tree;
  GtkTreeItem *tree_item;
  gint units;
  char orientation;
  char *papertype;
  fc_color *bg_color;
  double x_max;
  double y_max;
  double x_max_screen;
  double y_max_screen;
} page_data;

typedef struct _labeltext
{ char *font, *text;
  char text_v_just;
  char text_h_just;

  double text_size;
  double offset;
  char offset_units;
  fc_color *color;
}  labeltext;

#define BOX_DATA_FILL_BG

#define BOX_DRAW_SIDE          0x0001
#define BOX_NUMBER_INTERVALS_1 0x0002
#define BOX_NUMBER_INTERVALS_2 0x0004
#define BOX_NUMBER_INTERVALS_3 0x0008
#define BOX_NUMBER_INTERVALS_4 0x0010
#define BOX_NUMBER_INTERVALS_5 0x0020
#define BOX_LOG10_INTERVAL     0x0040
#define BOX_LN_INTERVAL        0x0080
#define BOX_TICKS_OUTWARD      0x0100
#define BOX_TICKS_INWARD       0x0200
#define BOX_NO_TICKS           0x0400
#define BOX_POS_NORMAL         0x0800
#define BOX_POS_SPES           0x1000

#define LABEL_DEFAULT          0x0001
#define LABEL_EXP              0x0002
#define LABEL_E                0x0004
#define LABEL_e                0x0008
#define LABEL_H_M              0x0010
#define LABEL_H_M_S            0x0020
#define LABEL_HhM              0x0040
#define LABEL_HhM_S            0x0080
#define LABEL_HHM              0x0100
#define LABEL_HHM_S            0x0200
#define LABEL_IGNORE_TRAILING_0 0x0400
#define LABEL_NO_LABELS        0x0800
#define LABEL_IGNORE_LEADING_1 0x1000
#define LABEL_ALIGN_DECADE     0x2000
#define LABEL_DRAW_GRID        0x4000

#define DEFAULT_FONT           "NewCenturySchlbk-Roman"
/*#define DEFAULT_FONT           "HersheySerif"*/
#define DEFAULT_FONT_SIZE      12
#define DEFAULT_FONT_UNIT      POINTS
#define DEFAULT_FONT_ROT       0 /* degrees relative to positive X-axis*/

#define TOP_SIDE 0
#define RIGHT_SIDE 1
#define BOTTOM_SIDE 2
#define LEFT_SIDE 3

#define XY_X_POINT 0
#define XY_X_ERR_2 1
#define XY_X_ERR_1 2
#define XY_Y_POINT 3
#define XY_Y_ERR_1 4
#define XY_Y_ERR_2 5

#define XY_RECALC_ALL        0x0001
#define XY_VARS_CALCULATED   0x0002
#define XY_X_ERR_PM          0x0004
#define XY_Y_ERR_PM          0x0008
#define XY_X_ERR_ABS         0x0010
#define XY_Y_ERR_ABS         0x0020
#define XY_FILL_TOP          0x0040
#define XY_FILL_RIGHT        0x0080
#define XY_FILL_DOWN         0x0100
#define XY_FILL_LEFT         0x0200
#define XY_X_ERR_CAPS        0x0400
#define XY_Y_ERR_CAPS        0x0800
#define XY_DRAW_LINE         0x1000
#define XY_DRAW_MARKER       0x2000

#define XY_CALC              0x0001
#define XY_RECALC            0x0002
#define XY_STORE_RESULT      0x0004

typedef struct _box_side
{ char version, box_line_type,tick_line_type[5], pos; /* pos=t, b, l, r */

  guint32 flags; /* 32 info flags should be enough */
  fc_color *tick_color[5], *text_color, *label_color;
  guint32 label_format[5]; /* flags to represent types of formatting */
  char label_digits, label_unit,line_unit;
  double side_pos, label_offset,box_line_width,tick_line_width[5], tick_offset;
  gint align_decade;
  guint sub_intervals[5];
  double sub_interval_base[5];
  double tick_len[5];   /* tick lengths for five levels of ticks */
  double tick_label_size[5];   /* text sizes for five levels of ticks */
  double tick_label_rot[5];   /* text rotation for five levels of ticks */
  char label_depth;
  char *tick_font, *label_font, *label;
  char label_v_just,label_h_just;
  char tick_label_v_just,tick_label_h_just;
  double text_size,label_pos,label_min,label_max;
}  box_side;
  
typedef struct _system_data_2d
{ char version;
  GtkTree *tree;
  GtkTreeItem *tree_item;
  gint depth;
  
  fc_color *fg_color, *bg_color;
  char *text_font, *label;
  char text_h_just, text_v_just;
  double text_size, text_x, text_y;
  double x_min_system, x_max_system, /* The coordinate system of the box */
         y_min_system, y_max_system; 
  double x_min_box, x_max_box, /* The position of the box in the parent's */
         y_min_box, y_max_box; /* system  */
} system_data_2d;

typedef struct _box_data_2d
{ char version;
  GtkTree *tree;
  GtkTreeItem *tree_item;

  gint depth;
  box_side *side[4];
  char *label_text, box_data_flags;
  double text_rot,text_offset;
  fc_color *text_color, *fg_color, *bg_color;
  char *text_font, text_unit,text_side;
  char text_v_just;
  char text_h_just;
  double text_size;
  double x_min_system, x_max_system, /* The coordinate system of the box */
         y_min_system, y_max_system; 
  double x_min_box, x_max_box, /* The position of the box in the parent's */
         y_min_box, y_max_box; /* system  */
} box_data_2d;

typedef struct _xy_2d
{ char version;
  GtkTree *tree;
  GtkTreeItem *tree_item;
  gint depth;

  fc_color *line_color, *marker_color, *fill_color;
  char *pre_cmd, *post_cmd, line_type, line_unit;
  char *var[6], *var_function[6];
  char *marker_font, *marker_text, marker_unit, cap_unit;
  double marker_size, marker_rot,cap_size,line_width;
  double *data[6];
  gint *data_dims[6];
  guint32 flags, var_flag[6];
} xy_2d;

typedef struct _generic_object
{ char version;
  GtkTree *tree;
  GtkTreeItem *tree_item;
  gint depth;
} generic_object;
/*Papertype information */
#define PORTRAIT 1
#define LANDSCAPE 2
#define MAX_PAPERS 2
/* Line type info */
extern char line_types[5][30];

/*Icons in tree widget*/
#define TREE_ICONS 6
#define TREE_PATHS 4
#define DEF_ICON 999
extern char fc_tree_icon_name[TREE_ICONS][256];
extern GdkPixmap *fc_tree_icon[TREE_ICONS];
extern GdkBitmap *fc_tree_icon_mask[TREE_ICONS];

/* Prototypes */
fc_node *new_fc_node(guint num_children, gint node_type);
fc_node *new_mother_node(void);
fc_node *new_doc_node(fc_node *mother, char *doc_name);
fc_node *new_page_node_defaults(fc_node *mother);
fc_node *new_page_node(fc_node *mother, gint units,
                       double x_max, double y_max, char *papertype,
                       gint orientation);
fc_node * new_child_node(fc_node *mother, guint num_children, gint node_type);
fc_node *new_child_node_pointer(fc_node *mother, fc_node *new_node);
gint sort_children(gpointer *list, gint num_children);
gint depth_sort_children(gpointer *list, gint num_children);
gint fc_remove_child(fc_node *node, gint child_number);
gint fc_remove_child_nosort(fc_node *node, gint child_number);
gint fc_remove_child_pointer_nosort(fc_node *node, fc_node *child_node);
gint fc_remove_child_pointer(fc_node *node, fc_node *child_node);
gint fc_remove_child_pointer_nofree(fc_node *node, fc_node *child_node);
gint fc_destroy_page(fc_node *page_node);
gint fc_destroy_document(fc_node *doc_node);

/* This one should prbably find its way into a general utilities file */
fc_color *new_fc_color(guint16 r, guint16 g, guint16 b);

/* Some defaults */
extern char papertypes[MAX_PAPERS][20];
extern double paper_x[MAX_PAPERS];
extern double paper_y[MAX_PAPERS];
extern gint paper_units[2];
extern gint default_paper; /* default is this index */
extern gint default_orient;
extern fc_node *fc_mother_node, *current_doc, *current_page;
