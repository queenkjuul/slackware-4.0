extern GtkWidget *drawing_area, *fc_graph_gscroll;
extern gint gwidth,gheight;
gint create_plot(GtkWidget *widget,page_data *page_info, double width, double height);
gint drawing_area_configure_event (GtkWidget *widget, GdkEventConfigure *event);
extern gchar fc_graph_replot;