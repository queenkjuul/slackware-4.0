/* New document dialog created with help from glade 0.3.5
 C. Steenberg 24/10/1998
 */

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include "object_tree.h"
#include "tree_window.h"

GtkWidget *new_doc_dialog;
GtkWidget *toggle;
gchar doc_dialog_busy=FALSE;
fc_node *doc_node=NULL;
/* Cancel pressed, or called after new document created */
void new_doc_cancel (GtkWidget *widget, gpointer *data)
{ gtk_widget_destroy(new_doc_dialog);
  doc_dialog_busy=FALSE;
}
/* OK pressed, or Enter pressed */
void new_doc_enter (GtkWidget *widget, gpointer *data)
{ char *buffer;
  if (!widget || !toggle || !fc_mother_node) return;
  buffer = (char *)strdup(gtk_entry_get_text(GTK_ENTRY(widget)));
/*  if (buffer==NULL || strlen(buffer)==0)
   { new_doc_cancel(widget,data);
     return;
   }*/
  if (!doc_node)
   doc_node=new_document(fc_mother_node,buffer);
  else
   { g_free(((doc_data *)doc_node->node_data)->doc_name);
     ((doc_data *)doc_node->node_data)->doc_name=buffer;
     gtk_label_set(GTK_LABEL(doc_node->label),buffer);
     printf("label name=%s\n",((doc_data *)doc_node->node_data)->doc_name);
   }
  if (GTK_TOGGLE_BUTTON (toggle)->active || !current_doc)
    current_doc=doc_node;
     doc_node=NULL;
  new_doc_cancel(widget,data);
}

void create_new_doc_dialog (GtkWidget *widget, gpointer data)
{
  GtkWidget *dialog_vbox1;
  GtkWidget *hbox1;
  GtkWidget *doc_new_label;
  GtkWidget *new_doc_entry;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbox2;
  GtkWidget *button1;
  GtkWidget *button2;

  if (doc_dialog_busy) return;
  doc_dialog_busy=TRUE;
  printf("create_new_doc_dialog: widget=%x data=%x\n",widget,data);
 
  doc_node=(fc_node *)data;
  new_doc_dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (new_doc_dialog), "new_doc_dialog", new_doc_dialog);
  GTK_WINDOW (new_doc_dialog)->type = GTK_WINDOW_DIALOG;
  if (!doc_node)
      gtk_window_set_title (GTK_WINDOW (new_doc_dialog), "fulcrum: New document");
  else
      gtk_window_set_title (GTK_WINDOW (new_doc_dialog), "fulcrum: Edit document");
  gtk_window_set_policy (GTK_WINDOW (new_doc_dialog), TRUE, TRUE, TRUE);
  gtk_window_position (GTK_WINDOW (new_doc_dialog), GTK_WIN_POS_MOUSE);
  
  dialog_vbox1 = GTK_DIALOG (new_doc_dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (new_doc_dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_object_set_data (GTK_OBJECT (new_doc_dialog), "hbox1", hbox1);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), hbox1, FALSE, FALSE, 0);

  doc_new_label = gtk_label_new ("Document name: ");
  gtk_object_set_data (GTK_OBJECT (new_doc_dialog), "doc_new_label", doc_new_label);
  gtk_widget_show (doc_new_label);
  gtk_box_pack_start (GTK_BOX (hbox1), doc_new_label, TRUE, TRUE, 5);
  gtk_label_set_justify (GTK_LABEL (doc_new_label), GTK_JUSTIFY_RIGHT);

  new_doc_entry = gtk_entry_new ();
  gtk_object_set_data (GTK_OBJECT (new_doc_dialog), "new_doc_entry", new_doc_entry);
  gtk_widget_show (new_doc_entry);
  gtk_box_pack_start (GTK_BOX (hbox1), new_doc_entry, TRUE, TRUE, 0);
  gtk_signal_connect_object (GTK_OBJECT (new_doc_entry), "activate",
                             GTK_SIGNAL_FUNC (new_doc_enter),
                             GTK_OBJECT (new_doc_entry));
  if (doc_node)
   gtk_entry_set_text(GTK_ENTRY(new_doc_entry),((doc_data *)(doc_node->node_data))->doc_name);
  gtk_widget_grab_focus (new_doc_entry);

  toggle=gtk_check_button_new_with_label("Switch to document");
  gtk_widget_show (toggle);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), toggle, TRUE, FALSE, 0);
  gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (toggle), TRUE);
  
  dialog_action_area1 = GTK_DIALOG (new_doc_dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (new_doc_dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_border_width (GTK_CONTAINER (dialog_action_area1), 5);

  hbox2 = gtk_hbox_new (FALSE, 0);
  gtk_object_set_data (GTK_OBJECT (new_doc_dialog), "hbox2", hbox2);
  gtk_widget_show (hbox2);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbox2, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label ("OK");
  gtk_object_set_data (GTK_OBJECT (new_doc_dialog), "button1", button1);
  gtk_widget_show (button1);
  gtk_box_pack_start (GTK_BOX (hbox2), button1, TRUE, TRUE, 5);
  gtk_widget_grab_focus (button1);
  gtk_signal_connect_object (GTK_OBJECT (button1), "clicked",
                             GTK_SIGNAL_FUNC (new_doc_enter),
                             GTK_OBJECT (new_doc_entry));

  button2 = gtk_button_new_with_label ("Cancel");
  gtk_object_set_data (GTK_OBJECT (new_doc_dialog), "button2", button2);
  gtk_widget_show (button2);
  gtk_box_pack_start (GTK_BOX (hbox2), button2, TRUE, TRUE, 5);
  gtk_widget_grab_focus (button1);
  gtk_signal_connect_object (GTK_OBJECT (button2), "clicked",
                             GTK_SIGNAL_FUNC (new_doc_cancel),
                             GTK_OBJECT (new_doc_entry));


  gtk_widget_show (new_doc_dialog);
}
