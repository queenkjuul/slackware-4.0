/* Implements object tree structure and functions for inserting and removing
   subtrees and objects.
   C. Steenberg 13/09/1998
*/

#include <glib.h>
#include <gtk/gtk.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <pwd.h>
#include <sys/types.h>
#include "object_tree.h"

char papertypes[MAX_PAPERS][20]={"letter","a4"};
double paper_x[MAX_PAPERS]={8.5,21.5};
double paper_y[MAX_PAPERS]={11,29.5};
gint paper_units[2]={INCHES,CM};
gint default_paper=1; /* default is this index */
gint default_orient=PORTRAIT;
double fc_units_per_inch[5]={0,72.72,25.4,2.54,1};

char line_types[5][30]={"solid","dotted","dotdashed","shortdashed",
"longdashed"};

fc_node *fc_mother_node, *current_doc, *current_page;

/* Prototypes */
fc_node *new_fc_node(guint num_children, gint node_type);
fc_node *new_mother_node(void);
fc_node *new_doc_node(fc_node *mother, char *doc_name);
fc_node *new_page_node_defaults(fc_node *mother);
fc_node *new_page_node(fc_node *mother, gint units,
                       double x_max, double y_max, char *papertype,
                       gint orientation);
fc_node *new_box_2d_node(fc_node *mother, double x_min_system, double x_max_system,
                    double y_min_system, double y_max_system,
                    double x_min_box, double x_max_box,
                    double y_min_box, double y_max_box);
fc_node * new_child_node(fc_node *mother, guint num_children, gint node_type);
fc_node *new_child_node_pointer(fc_node *mother, fc_node *new_node);
gint sort_children(gpointer *list, gint num_children);
gint depth_sort_children(gpointer *list, gint num_children);
gint fc_remove_child(fc_node *node, gint child_number);
gint fc_remove_child_nosort(fc_node *node, gint child_number);
gint fc_remove_child_pointer_nosort(fc_node *node, fc_node *child_node);
gint fc_remove_child_pointer(fc_node *node, fc_node *child_node);
gint fc_remove_child_pointer_nofree(fc_node *node, fc_node *child_node);
gint fc_destroy_box_side(box_side *side);
gint fc_destroy_box(fc_node *box_node);
gint fc_destroy_page(fc_node *page_node);
gint fc_destroy_document(fc_node *doc_node);

/* Methods */

fc_node *new_fc_node(guint num_children, gint node_type)
{ fc_node *new_node;

  new_node=(fc_node *)g_malloc(sizeof(fc_node));
  if (!new_node) return(NULL);

/* pre-allocate an array of num_children pointers to be used for future children */
  new_node->list_children=(gpointer *)g_malloc(num_children*sizeof(gpointer));
  if (!new_node->list_children&&num_children>0)
   { free(new_node);
     return(NULL);
   }

 new_node->max_children=num_children;
 new_node->node_type=node_type;
 new_node->n_children=0;

 return(new_node);
}

fc_node *new_mother_node(void)
{ fc_node *mother_node;
   mother_node=new_fc_node(5, MOTHER_NODE);
  if (!mother_node) return (NULL);

  mother_node->is_container=FALSE;
  mother_node->parent_node=NULL;
  mother_node->node_data=NULL;
  
  return(mother_node);
}

fc_node *new_doc_node(fc_node *mother, char *doc_name)
{ gint index;
  struct passwd *user_passwd;
  fc_node *doc_node;
  uid_t user_id;
  if (!mother) return (NULL);
  doc_node=new_child_node(mother, 0, DOCUMENT_NODE);
  if (!doc_node) return (NULL);
  
  index=mother->n_children-1;

  doc_node->is_container=FALSE;
  doc_node->parent_node=mother;
  doc_node->node_data=(gpointer)g_malloc(sizeof(doc_data));
  if (!doc_node->node_data)
   { fc_remove_child(mother,index);
     return(NULL);
   }
  ((doc_data *)(doc_node->node_data))->doc_name=(char *)strdup(doc_name);
  ((doc_data *)(doc_node->node_data))->version=DOC_VERSION;

  user_id=getuid();
  user_passwd=getpwuid(user_id);  
  ((doc_data *)(doc_node->node_data))->creator_name=user_passwd->pw_gecos;
  return(doc_node);
}

/* -------------------------------------------------------------------------
   Create a new page node and set up the node_data structure for the page.
   The page node is entered into the list_children array of the parent.
   Inputs: mother node, required
   Then supply either units as PIXELS along with the x_max and y_max, or
   the papertype and orientation. Valid papertypes are defined in 'papertypes'
   array.
*/

fc_node *new_page_node(fc_node *mother, gint units,
                       double x_max, double y_max, char *papertype,
                       gint orientation)
{ gint index, page_setup_done=0;
  fc_node *page_node;
  gint paper_index=0; /* Default paper is letter */

  if (!mother) return (NULL);
  page_node=new_child_node(mother, 5, PAGE_NODE);
  if (!page_node) return (NULL);
  
  index=mother->n_children-1;

  page_node->is_container=FALSE;
  page_node->parent_node=mother;
  page_node->node_data=(gpointer)g_malloc(sizeof(page_data));
  if (!page_node->node_data)
   { fc_remove_child(mother,index);
     return(NULL);
   }

  ((page_data *)(page_node->node_data))->version=PAGE_VERSION;

/* Set up paper type parameters from input provided */
  if (units==PIXELS)
   {  ((page_data *)(page_node->node_data))->x_max=x_max;
      ((page_data *)(page_node->node_data))->y_max=y_max;
      ((page_data *)(page_node->node_data))->units=PIXELS;  
      ((page_data *)(page_node->node_data))->papertype=NULL;
      ((page_data *)(page_node->node_data))->orientation=PORTRAIT;
      page_setup_done=TRUE;
   }
  
  if (!page_setup_done)
   { if (!papertype) /* set default papertype */
      { ((page_data *)(page_node->node_data))->papertype=papertypes[default_paper];
        ((page_data *)(page_node->node_data))->units=paper_units[default_paper];
        paper_index=default_paper;
      }
     else
     { for (paper_index=0;paper_index<MAX_PAPERS;paper_index++)
        if (strcmp(papertype,papertypes[paper_index])==0) /* yeah, we found a match */
         break;
       if (paper_index>=MAX_PAPERS) /* no match found, use default */
        paper_index=0;
        
       ((page_data *)(page_node->node_data))->papertype=papertypes[paper_index];
       ((page_data *)(page_node->node_data))->units=paper_units[paper_index];
       if (orientation==LANDSCAPE && orientation==PORTRAIT)
        ((page_data *)(page_node->node_data))->orientation=orientation;      
       else ((page_data *)(page_node->node_data))->orientation=PORTRAIT;
      }
       if (orientation==LANDSCAPE || orientation==PORTRAIT)
        ((page_data *)(page_node->node_data))->orientation=orientation;      
       else ((page_data *)(page_node->node_data))->orientation=default_orient;


     if (((page_data *)(page_node->node_data))->orientation==PORTRAIT)
      { ((page_data *)(page_node->node_data))->x_max=paper_x[paper_index];
        ((page_data *)(page_node->node_data))->y_max=paper_y[paper_index];
      }
     else
      { ((page_data *)(page_node->node_data))->x_max=paper_y[paper_index];
        ((page_data *)(page_node->node_data))->y_max=paper_x[paper_index];
      }     
     page_setup_done=TRUE;     
    }        
  ((page_data *)(page_node->node_data))->x_max_screen=0;
  ((page_data *)(page_node->node_data))->y_max_screen=0;
  ((page_data *)(page_node->node_data))->bg_color=new_fc_color(0xffff,0xffff,0xffff);
  return(page_node);
}

fc_node *new_page_node_defaults(fc_node *mother)
{ new_page_node(mother, 0,0,0,NULL,0);
}

fc_color *new_fc_color(guint16 r, guint16 g, guint16 b)
{ fc_color *new_color;

  new_color=(fc_color *)g_malloc(sizeof(fc_color));
  if (!new_color)
   return(NULL);
  new_color->r=r;
  new_color->g=g;
  new_color->b=b;

 return(new_color);
}

gint fc_destroy_page(fc_node *page_node)
{ page_data *page_info;
  gint i;

  if (page_node==NULL) return(0);
  page_info=(page_data *)(page_node->node_data);
  if (page_info)
   { if ((page_info->bg_color)!=NULL) g_free(page_info->bg_color);
      g_free(page_info);
   }
  for (i=0;i<page_node->n_children;i++)
    switch ( ((fc_node *)(page_node->list_children[i]))->node_type)
      { case BOX_2D_NODE: fc_destroy_box((fc_node *)(page_node->list_children[i]));
                          break;
      }


  fc_remove_child_pointer(page_node->parent_node,page_node);
  return(1);
}

gint fc_destroy_document(fc_node *doc_node)
{ doc_data *doc_info;
  gint i;

  if (!doc_node) return(0);
  doc_info=(doc_data *)(doc_node->node_data);
  if (doc_info)
   { if (doc_info->doc_name) g_free(doc_info->doc_name);
     if (doc_info->creator_name) g_free(doc_info->creator_name);
      g_free(doc_info);
   }
  for (i=0;i<doc_node->n_children;i++)
    switch ( ((fc_node *)(doc_node->list_children[i]))->node_type)
      { case PAGE_NODE: fc_destroy_page((fc_node *)(doc_node->list_children[i]));
                          break;
      }

 fc_remove_child_pointer(doc_node->parent_node,doc_node);
  return(1);
}


fc_node *new_child_node(fc_node *mother, guint num_children, gint node_type)
{ fc_node *new_node;
  gpointer *temp_pt;
  gint i;

  new_node=new_fc_node(num_children, node_type);
  if (new_node==NULL) return (0);
  new_node->is_container=FALSE;

 /* we need to expand array of children pointers*/
  if (mother->n_children==mother->max_children)
   { if (mother->max_children>0)
      temp_pt=g_malloc(mother->max_children*sizeof(gpointer)*2);
     else temp_pt=g_malloc(sizeof(gpointer)*10);
     for (i=0;i<mother->max_children;i++)
       temp_pt[i]=mother->list_children[i];
     g_free(mother->list_children);
     mother->list_children=temp_pt;
     if (mother->max_children>0)
      mother->max_children*=2;
     else mother->max_children=10;
   }
  mother->list_children[mother->n_children++]=(gpointer)new_node;

  return(new_node);
}

fc_node *new_child_node_pointer(fc_node *mother, fc_node *new_node)
{ gpointer *temp_pt;
  gint i;

  if (new_node==NULL) return (0);
  new_node->is_container=FALSE;

 /* we need to expand array of children pointers*/
  if (mother->n_children==mother->max_children)
   { if (mother->max_children>0)
      temp_pt=g_malloc(mother->max_children*sizeof(gpointer)*2);
     else temp_pt=g_malloc(sizeof(gpointer)*10);
     for (i=0;i<mother->max_children;i++)
       temp_pt[i]=mother->list_children[i];
     g_free(mother->list_children);
     mother->list_children=temp_pt;
     if (mother->max_children>0)
      mother->max_children*=2;
     else mother->max_children=10;
   }
  mother->list_children[mother->n_children++]=(gpointer)new_node;

  return(new_node);
}


int compare_depths(void *el1,void *el2)
{ generic_object *go1,*go2;
  fc_node *node;

  node=(fc_node *)el1;
  go1=(generic_object *)(node->node_data);

  node=(fc_node *)el2;
  go2=(generic_object *)(node->node_data);

  if (go1->depth<go2->depth)
   return(-1);
  if (go1->depth>go2->depth)
   return(1);
  return(0);
}

gint depth_sort_children(gpointer *list, gint num_children)
{ gint i,j;
  gpointer temp;

  for (i=0;i<num_children-1;i++)
     for (j=i+1;j<num_children;j++)
      if (compare_depths(list[j],list[i])<0)
       { temp=list[i];
         list[i]=list[j];
         list[j]=temp;
       }

  return(1);
}

gint sort_children(gpointer *list, gint num_children)
{ gint i,last_null=-1, last_nnull=-1,ex;
  gpointer *temp_pt;

  if (!num_children) return(1); /* no pointers to sort!*/
  for (ex=1;ex>0;)
   { last_null=-1;
     ex=0;
     if (last_nnull>=0) i=last_nnull;
     else i=0;
     last_null=-1;
     for(; i<num_children&&ex==0;i++)
      { if (last_null==-1 && !list[i])
         { last_null=i;
           continue;
         }
       if ((last_nnull==-1||last_null==-1) && list[i])
        last_nnull=i;
  
        if (last_null>=0 && list[i]) /* we can do an exchange */
         { list[last_null]=list[i];
           list[i]=NULL;
           ex=1;
         }
       }
    if (last_nnull>=0) i=last_nnull; /* This should never happen! */
    else i=0;
   }
 return(1);
}

/* Remove a child from the list. NB this assumes that the list of pointers
   are non-null up to n_children!
*/

gint fc_remove_child(fc_node *node, gint child_number)
{
  if (node->list_children[child_number]==NULL)
   return(1);

/*fc_remove needs to be called recursively! */
  g_free(node->list_children[child_number]);
  node->list_children[child_number]=NULL;
  sort_children(node->list_children,  node->max_children);
  node->n_children--;
}

/* Remove a child node _without_ sorting the non-null pointers to be at the 
   front of the array 'list_children'. Use with caution!
*/
gint fc_remove_child_nosort(fc_node *node, gint child_number)
{
  if (node->list_children[child_number]==NULL)
   return(1);

/*fc_remove needs to be called recursively! */
  g_free(node->list_children[child_number]);
  node->list_children[child_number]=NULL;
}

/* Removes the first child-node from the mothers list_children with pointer
   child_node.
*/

gint fc_remove_child_pointer(fc_node *node, fc_node *child_node)
{ guint i;
  if (node->max_children==0 || node->n_children==0 || !node)
   return(1);
 
  for (i=0;i<node->max_children;i++)
     if (node->list_children[i]==child_node) break;
      
/*fc_remove needs to be called recursively! */
  g_free(node->list_children[i]);
  node->list_children[i]=NULL;
  sort_children(node->list_children,  node->max_children);
  node->n_children--;
}

gint fc_remove_child_pointer_nofree(fc_node *node, fc_node *child_node)
{ guint i;
  if (node->max_children==0 || node->n_children==0 || !node)
   return(1);
 
  for (i=0;i<node->max_children;i++)
     if (node->list_children[i]==child_node) break;
      
/*fc_remove needs to be called recursively! */
  node->list_children[i]=NULL;
  sort_children(node->list_children,  node->max_children);
  node->n_children--;
}

gint fc_remove_child_pointer_nosort(fc_node *node, fc_node *child_node)
{ guint i;
  if (node->max_children==0 || node->n_children==0 || !node)
   return(1);
 
  for (i=0;i<node->max_children;i++)
     if (node->list_children[i]==child_node) break;
      
/*fc_remove needs to be called recursively! */
  g_free(node->list_children[i]);
  node->list_children[i]=NULL;
}

#ifdef fc_tree_test
gint main(void)
#else
gint tree_test(void)
#endif
{ fc_node *mother_node;
  gint i,j;
  char doc_name[256];
  fc_node *doc_node, *page_node;
  doc_data *doc_info;
  page_data *page_info;

  mother_node=new_fc_node(5,MOTHER_NODE);
  if (!mother_node)
   g_error("Could not create mother node!");

for (i=0;i<2;i++)
{  sprintf(doc_name,"Document %d",i);
   new_doc_node(mother_node, doc_name);
   doc_node=(fc_node *)(mother_node->list_children[i]);
   doc_info=(doc_data *)(doc_node->node_data);
   g_print("child_node[%d of %d]=%x name=%s creator=%s\n",i,mother_node->max_children-1,
     doc_node,doc_info->doc_name,doc_info->creator_name);
     for (j=0;j<4;j++)
       { new_page_node_defaults(doc_node);
         page_node=(fc_node *)(doc_node->list_children[j]);
         page_info=(page_data *)(page_node->node_data);
         g_print("  page_node[%d of %d]=%x ptype=%s orient=%d\n",j,doc_node->max_children-1,
         page_node,page_info->papertype,page_info->orientation);
         g_print("  xmax=%3.1f ymax=%3.1f units=%d\n",page_info->x_max,
         page_info->y_max,page_info->units);

       }
   }

  return(1);
}
