/* Companion to render_page.c */


/* Prototypes */
int render_box_2d(fc_node *box_node, double x_max, double y_max, gchar doc_units);
int render_system(fc_node *box_node, double x_max, double y_max, gchar doc_units);
int render_page(fc_node *page);
