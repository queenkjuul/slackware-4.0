#include <gtk/gtk.h>
#include <string.h>
#include "gtksheet.h"
#include "gtksheetentry.h"

#define DEFAULT_PRECISION 3
#define DEFAULT_SPACE 8

GtkWidget *sheet_label;
GtkWidget *notebook;
GtkWidget **sheets;
GtkWidget *status_box;
GtkWidget *location;
GtkWidget *entry;


static void
popup_activated(GtkWidget *widget, gpointer data)
{
 GtkSheet *sheet;
 gint i;

 if(!GTK_IS_SHEET(widget->parent->parent)) printf("HOPLA\n"); 
 sheet=GTK_SHEET(widget->parent->parent);

 if((char *)data == "Add Column")
   gtk_sheet_add_column(sheet,1);

 if((char *)data == "Add Row")
   gtk_sheet_add_row(sheet,1);

 if((char *)data == "Insert Row"){
   if(sheet->state==GTK_SHEET_ROW_SELECTED)
     gtk_sheet_insert_rows(sheet,sheet->range.row0,                       
                               sheet->range.rowi-sheet->range.row0+1);
 }

 if((char *)data == "Insert Column"){
   if(sheet->state==GTK_SHEET_COLUMN_SELECTED)
     gtk_sheet_insert_columns(sheet,sheet->range.col0,                       
                              sheet->range.coli-sheet->range.col0+1);

 } 

 if((char *)data == "Delete Row"){
   if(sheet->state==GTK_SHEET_ROW_SELECTED)
     gtk_sheet_delete_rows(sheet,sheet->range.row0,
                              sheet->range.rowi-sheet->range.row0+1);
 }

 if((char *)data == "Delete Column"){
   if(sheet->state==GTK_SHEET_COLUMN_SELECTED)
     gtk_sheet_delete_columns(sheet,sheet->range.col0,
                              sheet->range.coli-sheet->range.col0+1);   
 } 

 if((char *)data == "Clear Cells"){
   if(sheet->state!=GTK_SHEET_NORMAL)
     gtk_sheet_range_clear(sheet, &sheet->range);
 } 

}

static GtkWidget *
build_menu(GtkWidget *sheet)
{
	static char *items[]={
		"Add Column",
		"Add Row",
		"Insert Row",
		"Insert Column",
		"Delete Row",
                "Delete Column",
                "Clear Cells"
	};
	GtkWidget *menu;
	GtkWidget *item;
	int i;

	menu=gtk_menu_new();
	menu->parent=sheet;

	for (i=0; i < (sizeof(items)/sizeof(items[0])) ; i++){
	 	item=gtk_menu_item_new_with_label(items[i]);
	 	gtk_signal_connect(GTK_OBJECT(item),"activate",
				   (GtkSignalFunc) popup_activated,
				   items[i]);
                GTK_WIDGET_SET_FLAGS (item, GTK_SENSITIVE | GTK_CAN_FOCUS);
                switch(i){
                  case 2:
                    if(GTK_SHEET(sheet)->state!=GTK_SHEET_ROW_SELECTED)
                     GTK_WIDGET_UNSET_FLAGS (item, 
                                            GTK_SENSITIVE | GTK_CAN_FOCUS);
                    break;
                  case 3:
                    if(GTK_SHEET(sheet)->state!=GTK_SHEET_COLUMN_SELECTED)
                     GTK_WIDGET_UNSET_FLAGS (item, 
                                            GTK_SENSITIVE | GTK_CAN_FOCUS);
                    break;
                  case 4:
                    if(GTK_SHEET(sheet)->state!=GTK_SHEET_ROW_SELECTED)
                     GTK_WIDGET_UNSET_FLAGS (item, 
                                            GTK_SENSITIVE | GTK_CAN_FOCUS);
                    break;
                  case 5:
                    if(GTK_SHEET(sheet)->state!=GTK_SHEET_COLUMN_SELECTED)
                     GTK_WIDGET_UNSET_FLAGS (item, 
                                            GTK_SENSITIVE | GTK_CAN_FOCUS);
                    break;
                } 

		gtk_widget_show(item);
	    	gtk_menu_append(GTK_MENU(menu),item);
	}

	return menu;
}

void
do_popup(GtkWidget *widget, GdkEventButton *event, gpointer data)
{
   static GtkWidget *popup;
   GdkModifierType mods;
   GtkWidget *sheet;

   sheet=GTK_WIDGET(widget);

   gdk_window_get_pointer (sheet->window, NULL, NULL, &mods);
   if(mods&GDK_BUTTON3_MASK){ 

    if(popup)
       g_free(popup);

    popup=build_menu(sheet);

    gtk_menu_popup(GTK_MENU(popup), NULL, NULL, NULL, NULL,
		   event->button, event->time);
   }
}

void
format_text (GtkSheet *sheet, int *justification, gchar *text, char *label)
{
  double auxval;
  int digspace=0;
  int cell_width, char_width;
  double val;
  int format;
  double space;
  int intspace;
  int nonzero=FALSE;
  int ipos;
  char nchar;
  enum {EMPTY, TEXT, NUMERIC};

  cell_width=sheet->column[sheet->active_cell.col].width;
  char_width = gdk_char_width (GTK_WIDGET(sheet)->style->font,(gchar)'X');
  space= (double)cell_width/(double)char_width;

  intspace=MIN(space, DEFAULT_SPACE);

  format=EMPTY;
  if(strlen(text) != 0)
  { 
        for(ipos=0; ipos<strlen(text); ipos++){

          switch(nchar=text[ipos]){
           case '.':
           case ' ': case ',':
           case '-': case '+':
           case 'd': case 'D':
           case 'E': case 'e':
           case '1': case '2': case '3': case '4': case '5': case '6':
           case '7': case '8': case '9':
            nonzero=TRUE;
            break;
           case '0':
            break;
           default:
            format=TEXT;
          }
          if(format != EMPTY) break;
        }
        val=atof(text);
        if(format!=EMPTY || (val==0. && nonzero))
             format = TEXT;
        else
             format = NUMERIC;
  }

  switch(format){
    case TEXT:
    case EMPTY:
      strcpy(label, text);
      return;
    case NUMERIC:
      val=atof(text);
      *justification = GTK_JUSTIFY_RIGHT;
  }

  auxval= val < 0 ? -val : val;

  while(auxval<1 && auxval != 0.){
   auxval=auxval*10.;
   digspace+=1;
  }

  if(digspace+DEFAULT_PRECISION+1>intspace || digspace > DEFAULT_PRECISION){
    sprintf (label, "%*.*E", intspace, DEFAULT_PRECISION, val);
  }
  else
    {
    sprintf (label, "%*.*f", intspace, DEFAULT_PRECISION, val);
    if(strlen(label) > space)
      sprintf (label, "%*.*E", intspace, DEFAULT_PRECISION, val);
  }
}

void
parse_numbers(GtkWidget *widget, gpointer data)
{
 GtkSheet *sheet;
 char label[400];
 int justification;

 sheet=GTK_SHEET(widget);

 justification = GTK_SHENTRY(sheet->sheet_entry)->justification;
 format_text(sheet, &justification, GTK_SHENTRY(sheet->sheet_entry)->text,
             label);

 gtk_sheet_set_cell(sheet, sheet->active_cell.row,
			   sheet->active_cell.col,
                           justification, label); 

}

void
build_example1(GtkWidget *widget)
{
 GtkSheet *sheet;
 gchar name[10];
 gint i;

 sheet=GTK_SHEET(widget);

 for(i=0; i<=sheet->maxcol; i++){
   name[0]='A'+i;
   name[1]='\0';
   gtk_sheet_column_button_add_label(sheet, i, name);
   gtk_sheet_set_column_title(sheet, i, name);
 }
}

void
show_sheet_entry(GtkWidget *widget, gpointer data)
{
 char *text;
 GtkSheet *sheet;
 GtkSHEntry *sheet_entry;

 if(!GTK_WIDGET_HAS_FOCUS(widget)) return;

 sheet=GTK_SHEET(GTK_NOTEBOOK(notebook)->cur_page->child);

 if(text=GTK_ENTRY(entry)->text){
   sheet_entry=GTK_SHENTRY(sheet->sheet_entry);
   gtk_shentry_set_text(sheet_entry, text, sheet_entry->justification);
 }
}

void 
activate_sheet_entry(GtkWidget *widget, gpointer data)
{
  GtkSheet *sheet;
  gint row, col;

  sheet=GTK_SHEET(GTK_NOTEBOOK(notebook)->cur_page->child);
  row=sheet->active_cell.row;
  col=sheet->active_cell.col;

  gtk_sheet_set_cell(sheet, row, col, 
                     GTK_SHENTRY(sheet->sheet_entry)->justification,
                     GTK_SHENTRY(sheet->sheet_entry)->text);

}

void
show_entry(GtkWidget *widget, gpointer data)
{
 char *text;
 
 if(!GTK_WIDGET_HAS_FOCUS(widget)) return;

 if(text=GTK_SHENTRY(widget)->text)
                          gtk_entry_set_text(GTK_ENTRY(entry), text);

}

void 
activate_sheet_cell(GtkWidget *widget, gint row, gint column, gpointer data)
{
  char cell[100];

  if(GTK_SHEET(widget)->column[column].name)
   sprintf(cell,"  %s:%d  ",GTK_SHEET(widget)->column[column].name, row);
  else
   sprintf(cell, " ROW: %d COLUMN: %d ", row, column);

  gtk_label_set(GTK_LABEL(location), cell);

  gtk_entry_set_max_length(GTK_ENTRY(entry), 
	GTK_SHENTRY(GTK_SHEET(widget)->sheet_entry)->text_max_length); 
}

int fc_init_sheet_win(GtkWidget *notebook)
{
  GtkWidget *label; 
  GtkWidget *label2,*sheet_table1,*sheet_table2;
  gint i;
  char *title[]= {"Example 1",
                  "Example 2",
                  "Example 3"};
  char *folder[]= {"Sheet 1",
                   "Folder 2",
                   "Folder 3"};

   sheet_table1 = gtk_table_new (1,2,FALSE);
   sheet_table2 = gtk_table_new (2,1,FALSE);
   gtk_table_attach(GTK_TABLE(sheet_table1), sheet_table2, 0,1,0,1,
                   GTK_FILL|GTK_SHRINK,
                   GTK_FILL|GTK_SHRINK,0,0);


  location=gtk_label_new("");
  gtk_table_attach(GTK_TABLE(sheet_table2), location, 0,1,0,1,
                   GTK_FILL|GTK_SHRINK|GTK_EXPAND,
                   GTK_FILL|GTK_SHRINK,0,0);
   gtk_widget_show(location);


  entry=gtk_entry_new();
  gtk_table_attach(GTK_TABLE(sheet_table2), entry, 0,1,0,1,
                   GTK_FILL|GTK_SHRINK|GTK_EXPAND,
                   GTK_FILL|GTK_SHRINK,0,0);
   gtk_widget_show(entry);

   sheets=(GtkWidget **)realloc(sheets, sizeof(GtkWidget *));
  for(i=0; i<1; i++){
   sheets[i]=gtk_sheet_new(100,26,title[i]);

   gtk_table_attach(GTK_TABLE(sheet_table1), sheets[i], 0,1,1,2,
                    GTK_FILL|GTK_SHRINK|GTK_EXPAND,
                    GTK_FILL|GTK_SHRINK|GTK_EXPAND,0,0);

   gtk_widget_show(sheets[i]);

   gtk_signal_connect(GTK_OBJECT(GTK_SHEET(sheets[i])->sheet_entry),
                      "changed",
                      (GtkSignalFunc)show_entry, NULL);

   gtk_signal_connect(GTK_OBJECT(sheets[i]),
                      "activate_cell",
                      (GtkSignalFunc)activate_sheet_cell, NULL);
  }

  gtk_signal_connect(GTK_OBJECT(entry),
                      "changed",
                      (GtkSignalFunc)show_sheet_entry, NULL);

  gtk_signal_connect(GTK_OBJECT(entry),
                      "activate",
                      (GtkSignalFunc)activate_sheet_entry, NULL);
  build_example1(sheets[0]);

   sheet_label=gtk_label_new(folder[0]);
   gtk_notebook_append_page(GTK_NOTEBOOK(notebook),sheet_table1,sheet_label);
   gtk_widget_show(sheet_label);
   gtk_widget_show(sheet_table1);
   gtk_widget_show(sheet_table2);
  return(0);
}

 
