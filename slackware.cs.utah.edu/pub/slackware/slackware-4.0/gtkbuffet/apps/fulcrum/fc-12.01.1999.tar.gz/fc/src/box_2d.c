/* box_2d.c functions to create/destroy/change boxes and box sides */

#include <glib.h>
#include <gtk/gtk.h>
#include <string.h>
#include "object_tree.h"
#include "box_2d.h"

box_side *box_side_default(gint index, box_data_2d *box_info)
{ box_side *side_pt;
  char i;

  side_pt=(box_side *)g_malloc(sizeof(box_side));
  if (!side_pt) return(NULL);
     side_pt->version=BOX_SIDE_VERSION;

     side_pt->label=strdup("Axis label");
     side_pt->tick_font=strdup(DEFAULT_FONT);
     side_pt->label_font=strdup(DEFAULT_FONT);
     side_pt->label_digits=1;
     side_pt->label_depth=1;
     side_pt->label_unit=POINTS;
     side_pt->label_color=new_fc_color(0,0,0); /* default color=black */
     side_pt->label_offset=20; /* POINTS */
     side_pt->label_pos=0.5; /* POINTS */
     side_pt->tick_offset=6; /* POINTS */
/*     side_pt->label=NULL; /* No default label! */
     side_pt->text_size=13; /* label_unit's */

     side_pt->text_color=new_fc_color(0,0,0); /* for tick labels */
     side_pt->line_unit=POINTS;
     side_pt->box_line_width=0.5; /* POINT */
     side_pt->box_line_type=0;

     side_pt->sub_intervals[0]=5;
     side_pt->sub_intervals[1]=4;
     side_pt->sub_interval_base[0]=0;
     side_pt->sub_interval_base[1]=0;

     side_pt->tick_len[0]=9;
     side_pt->tick_len[1]=6;

     side_pt->tick_label_size[0]=11;
     side_pt->tick_label_size[1]=9;

     switch (index)
      { case 0: side_pt->pos='t';
                side_pt->tick_label_h_just='c';
                side_pt->tick_label_v_just='x';
                side_pt->label_h_just='c';
                side_pt->label_v_just='x';
                side_pt->label_min=box_info->x_min_system;
                side_pt->label_max=box_info->x_max_system;
                break;
        case 1: side_pt->pos='r';
                side_pt->tick_label_h_just='l';
                side_pt->tick_label_v_just='c';
                side_pt->label_h_just='c';
                side_pt->label_v_just='x';
                side_pt->label_min=box_info->y_min_system;
                side_pt->label_max=box_info->y_max_system;
                break;
        case 2: side_pt->pos='b';
                side_pt->tick_label_h_just='c';
                side_pt->tick_label_v_just='t';
                side_pt->label_h_just='c';
                side_pt->label_v_just='t';
                side_pt->label_min=box_info->x_min_system;
                side_pt->label_max=box_info->x_max_system;
                break;
        case 3: side_pt->pos='l';
                side_pt->tick_label_h_just='r';
                side_pt->tick_label_v_just='c';
                side_pt->label_h_just='c';
                side_pt->label_v_just='x';
                side_pt->label_min=box_info->y_min_system;
                side_pt->label_max=box_info->y_max_system;
                break;
      }
     for (i=0; i<5;i++)
      { side_pt->tick_label_rot[i]=0;
        side_pt->tick_line_type[i]=0;
        side_pt->tick_color[i]=new_fc_color(0,0,0); /* tick line colors */
        side_pt->tick_line_width[i]=0.25; /* POINT */
      }
     for (i=2; i<5;i++)
       { side_pt->sub_intervals[i]=0;
         side_pt->sub_interval_base[i]=0;
         side_pt->tick_len[i]=0;
         side_pt->tick_label_size[i]=0;
        }
     side_pt->flags=BOX_DRAW_SIDE | BOX_TICKS_INWARD |
                    BOX_POS_NORMAL;

     side_pt->label_format[0]=LABEL_DEFAULT | LABEL_IGNORE_LEADING_1|
              LABEL_IGNORE_TRAILING_0;
     for (i=1; i<5;i++)
      side_pt->label_format[i]=LABEL_DEFAULT | LABEL_IGNORE_LEADING_1|
              LABEL_IGNORE_TRAILING_0;

   return(side_pt);
}

gint fc_destroy_box_side(box_side *side)
{
  if (!side) return(0);
    if(side->label) g_free(side->label);
    if(side->tick_font) g_free(side->tick_font);
    if(side->label_font) g_free(side->label_font);

    if(side->label_color) g_free(side->label_color);
    if(side->text_color) g_free(side->text_color);
    if(side->tick_color) g_free(side->tick_color);

  g_free(side);
  return(1);
}

fc_node *new_box_2d_node(fc_node *mother,
                    double x_min_system, double x_max_system,
                    double y_min_system, double y_max_system,
                    double x_min_box, double x_max_box,
                    double y_min_box, double y_max_box)
{ fc_node *box_node;
  box_data_2d *box_info;
  guint index,i,j;

  if (!mother) return (NULL);
  box_node=new_child_node(mother, 5, BOX_2D_NODE);
  if (!box_node) return (NULL);

  index=mother->n_children-1;

  box_node->is_container=FALSE;
  box_node->parent_node=mother;
  box_node->node_data=(gpointer)g_malloc(sizeof(box_data_2d));
  if (!box_node->node_data)
   { fc_remove_child(mother,index);
     return(NULL);
   }
/* Set up the coordinate system and position of the box */
  box_info=(box_data_2d *)(box_node->node_data);
  box_info->version= BOX_2D_VERSION;
  box_info->depth=0; /* default depth */

  box_info->x_min_system=x_min_system;
  box_info->x_max_system=x_max_system;
  box_info->y_min_system=y_min_system;
  box_info->y_max_system=y_max_system;

  box_info->x_min_box=x_min_box;
  box_info->x_max_box=x_max_box;
  box_info->y_min_box=y_min_box;
  box_info->y_max_box=y_max_box;

  box_info->text_color=new_fc_color(0,0,0); /* default color=black */
  box_info->fg_color=new_fc_color(0,0,0); /* default color=black */
  box_info->bg_color=new_fc_color(60000,60000,60000); /* default color=gray */

  box_info->text_unit=POINTS;
  box_info->text_font=strdup(DEFAULT_FONT);
  box_info->text_size=18;
  box_info->text_offset=40;
  box_info->text_rot=0;
  box_info->text_side='t';
  box_info->label_text=strdup("System label");
  box_info->text_h_just='c';
  box_info->text_v_just='x';

  
  for (index=0;index<4;index++)
     box_info->side[index]=box_side_default(index,box_info);

 return(box_node);
}


gint fc_destroy_box(fc_node *box_node)
{ box_data_2d* box_info;
  box_side *side;
  gint i;

  if (!box_node) return(0);
  box_info=(box_data_2d *)(box_node->node_data);
  if (box_info)
   { if (box_info->text_color) g_free(box_info->text_color);
     if (box_info->fg_color) g_free(box_info->fg_color);
     if (box_info->bg_color) g_free(box_info->bg_color);
     if (box_info->text_font) g_free(box_info->text_font);
     if (box_info->label_text) g_free(box_info->label_text);

  for (i=0;i<4;i++)
    fc_destroy_box_side((box_side *)(box_info->side[i]));
    g_free(box_info);
   }

  fc_remove_child_pointer(box_node->parent_node,box_node);
}


gint box_side_ndigits(fc_node *object,gchar side, gchar ndigits)
{
 if (!object) return(0);
 ((box_data_2d *)(object->node_data))->side[side]->label_digits=ndigits;
 return(1);
}

gint box_side_label_offset(fc_node *object,gchar side, double l_offset)
{
 if (!object) return(0);
 ((box_data_2d *)(object->node_data))->side[side]->label_offset=l_offset;
 return(1);
}

gint box_side_label_depth(fc_node *object,gchar side, gchar depth)
{
 if (!object) return(0);
 ((box_data_2d *)(object->node_data))->side[side]->label_depth=depth;
 return(1);
}


gint box_set_text_color(fc_node *object,gchar side, guint16 r,guint16 g,guint16 b)
{ fc_color *color;
 if (!object || side>3) return(0);
 color= ((box_data_2d *)(object->node_data))->side[side]->text_color;
 if (!color) 
  { ((box_data_2d *)(object->node_data))->side[side]->text_color=
     new_fc_color(r,g,b);
    return(1);
  }
 color->r=r;
 color->g=g;
 color->b=b;
 return(1);
}

gint box_set_label_color(fc_node *object,gchar side, guint16 r,guint16 g,guint16 b)
{ fc_color *color;
 if (!object || side>3) return(0);
 color= ((box_data_2d *)(object->node_data))->side[side]->label_color;
 if (!color) 
  { ((box_data_2d *)(object->node_data))->side[side]->label_color
    =new_fc_color(r,g,b);
    return(1);
  }
 color->r=r;
 color->g=g;
 color->b=b;
 return(1);
}

gint box_set_tick_color(fc_node *object,gchar side, gchar tick_level, guint16 r,guint16 g,guint16 b)
{ fc_color *color;
 if (!object || tick_level>4 || side>3) return(0);
 color= ((box_data_2d *)(object->node_data))->side[side]->tick_color[tick_level];
 if (!color) 
  { ((box_data_2d *)(object->node_data))->side[side]->tick_color[tick_level]
    =new_fc_color(r,g,b);
    return(1);
  }
 color->r=r;
 color->g=g;
 color->b=b;
 return(1);

}

gint box_set_tick_line_type(fc_node *object,gchar side, gchar tick_level, gchar type)
{ fc_color *color;
 if (!object || tick_level>4 || side>3) return(0);
 ((box_data_2d *)(object->node_data))->side[side]->tick_line_type[tick_level]=type;
 return(1);
}


gint box_unset_tick_flag(fc_node *object,gchar side, gchar tick_level, guint32 flag)
{guint32 xorflag;
 if (!object || tick_level>4 || side>3) return(0);

 xorflag=0xffffffff^flag;
 ((box_data_2d *)(object->node_data))->side[side]->label_format[tick_level]&=xorflag;

 return(1);
}


gint box_set_tick_flag(fc_node *object,gchar side, gchar tick_level, guint32 flag)
{
 if (!object || tick_level>4 || side>3) return(0);
 else ((box_data_2d *)(object->node_data))->side[side]->label_format[tick_level]|=flag;

 return(1);
}


gint box_unset_flag(fc_node *object,gchar side, guint32 flag)
{guint32 xorflag;
 if (!object || side>3) return(0);
 xorflag=0xffffffff^flag;
 ((box_data_2d *)(object->node_data))->side[side]->flags&=xorflag;

 return(1);
}


gint box_set_flag(fc_node *object,gchar side, guint32 flag)
{
 if (!object || side>3) return(0);
 else ((box_data_2d *)(object->node_data))->side[side]->flags|=flag;

 return(1);
}

gint box_set_side_pos(fc_node *object, gchar side, double pos)
{
 if (!object) return(0);
 else ((box_data_2d *)(object->node_data))->side[side]->side_pos=pos;

 return(1);
}


gint box_set_depth(fc_node *object,gint depth)
{
 if (!object) return(0);
 else ((box_data_2d *)(object->node_data))->depth=depth;
 
 return(1);
}

/* This function turns on/of the log scaling of a dimension */
gint box_logxy(fc_node *box_node, gint logx, gint logy)
{ 
  box_side *side;
  box_data_2d *box_info;
  guint32 flag;

  if (box_node->node_type!=BOX_2D_NODE)
   return(0);
  
  flag=0xffffffff^BOX_LOG10_INTERVAL;
  
  printf("flag=%x\n",flag);

  box_info=(box_data_2d *)(box_node->node_data);

  if (logx)
   { box_info->side[TOP_SIDE]->flags|=BOX_LOG10_INTERVAL;
     box_info->side[BOTTOM_SIDE]->flags|=BOX_LOG10_INTERVAL;

     box_info->side[TOP_SIDE]->sub_interval_base[0]=0;
     box_info->side[TOP_SIDE]->sub_interval_base[1]=10;
     box_info->side[TOP_SIDE]->sub_intervals[1]=10;

     box_info->side[BOTTOM_SIDE]->sub_interval_base[0]=0;
     box_info->side[BOTTOM_SIDE]->sub_interval_base[1]=10;
     box_info->side[BOTTOM_SIDE]->sub_intervals[1]=10;
   }
  else
   { box_info->side[TOP_SIDE]->flags&=flag;
     box_info->side[BOTTOM_SIDE]->flags&=flag;

     box_info->side[TOP_SIDE]->sub_interval_base[0]=0;
     box_info->side[TOP_SIDE]->sub_interval_base[1]=0;


     box_info->side[BOTTOM_SIDE]->sub_interval_base[0]=0;
     box_info->side[BOTTOM_SIDE]->sub_interval_base[1]=0;

   }

  if (logy)
   { box_info->side[RIGHT_SIDE]->flags|=BOX_LOG10_INTERVAL;
     box_info->side[LEFT_SIDE]->flags|=BOX_LOG10_INTERVAL;

     box_info->side[RIGHT_SIDE]->sub_interval_base[0]=0;
     box_info->side[RIGHT_SIDE]->sub_interval_base[1]=10;
     box_info->side[RIGHT_SIDE]->sub_intervals[1]=10;
     
     box_info->side[LEFT_SIDE]->sub_interval_base[0]=0;
     box_info->side[LEFT_SIDE]->sub_interval_base[1]=10;
     box_info->side[LEFT_SIDE]->sub_intervals[1]=10;

   }
  else
   { box_info->side[RIGHT_SIDE]->flags&=flag;
     box_info->side[LEFT_SIDE]->flags&=flag;
     
     box_info->side[RIGHT_SIDE]->sub_interval_base[0]=0;
     box_info->side[RIGHT_SIDE]->sub_interval_base[1]=0;

     box_info->side[LEFT_SIDE]->sub_interval_base[0]=0;
     box_info->side[LEFT_SIDE]->sub_interval_base[1]=0;
     
   }
  return(1);
}
  

fc_node *new_box_2d_norm(fc_node *page, double x_min_system, double x_max_system,
                    double y_min_system, double y_max_system,
                    double x_min_box, double x_max_box,
                    double y_min_box, double y_max_box)
{ double nx_max;
  fc_node *new_box;

  nx_max=((page_data *)(page->node_data))->x_max/
         ((page_data *)(page->node_data))->y_max;
           
  new_box=new_box_2d(page, x_min_system, x_max_system,
                     y_min_system, y_max_system,
                     x_min_box*nx_max, x_max_box*nx_max,
                     y_min_box, y_max_box);
  return(new_box);
}

fc_node *new_box_2d_abs(fc_node *page, double x_min_system, double x_max_system,
                    double y_min_system, double y_max_system,
                    double x_min_box, double x_max_box,
                    double y_min_box, double y_max_box)
{ double x_max;
  fc_node *new_box;

  x_max=((page_data *)(page->node_data))->x_max;
           
  new_box=new_box_2d(page, x_min_system, x_max_system,
                     y_min_system, y_max_system,
                     x_min_box/x_max, x_max_box/x_max,
                     y_min_box/x_max, y_max_box/x_max);
  return(new_box);
}
