/* Here you will find functions that renders the page and coordinate systems
 C. Steenberg 20/9/1998
 */
#include <glib.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <stdio.h>
#include <string.h>
#include <plot.h>
#include "object_tree.h"
#include "render_page.h"
#include <math.h>
#include "xy_2d.h"

extern double page_magn,screen_dpi;
extern char fc_render_busy, fc_yor_busy;
extern int pl_handle;
extern gint render_tag;
char tick_labels[1000][20];
guint idc[1000],fc_child_render;
double unit_to_page[5], cur_sys_hor_m, cur_sys_hor_c, 
                        cur_sys_ver_m, cur_sys_ver_c;

extern gint g_render_update(gpointer data);
extern gint fc_idle_add(char *busy_flag);

/* This utility function eliminates duplicate tick mark entries */
gint eliminate_copies(double *ticks, guint *nticks, guint *tick_level_end, 
                      guint *sub_level,box_side *side_pt)
{ guint i,j,k, l_nticks;
  double l_tick_level_end[5];

if (side_pt->label_min<=side_pt->label_max) 
 {

  for (i=0;i<5;i++)
    l_tick_level_end[i]=tick_level_end[i];
  tick_level_end[0]=0;
  l_nticks=*nticks;
  *nticks=0;
  for (k=0;k<l_tick_level_end[0];k++)
    if (ticks[k]>=side_pt->label_min &&
        ticks[k]<=side_pt->label_max) /* tick within bounds */
     { idc[(*nticks)++]=k;
       tick_level_end[0]++;
     }


  for (i=1;i<5;i++) /* 5 sublevels...*/
    { if (sub_level[i]==0) break; /* no more ticks */
      tick_level_end[i]=tick_level_end[i-1];
      for (k=l_tick_level_end[i-1];k<l_tick_level_end[i];k++)
        { if (i==1) j=0;
          else j=l_tick_level_end[i-2];
          for (;j<l_tick_level_end[i-1];j++)
              if (ticks[k]==ticks[j]) break;
          if (j>=l_tick_level_end[i-1] && ticks[k]>=side_pt->label_min
                                       && ticks[k]<=side_pt->label_max) /* no copy found */
           { idc[(*nticks)++]=k;
             tick_level_end[i]++;
           }
        }
     }
 }
else  
 {
  for (i=0;i<5;i++)
    l_tick_level_end[i]=tick_level_end[i];
  tick_level_end[0]=0;
  l_nticks=*nticks;
  *nticks=0;
  for (k=0;k<l_tick_level_end[0];k++)
    if (ticks[k]>=side_pt->label_max &&
        ticks[k]<=side_pt->label_min) /* tick within bounds */
     { idc[(*nticks)++]=k;
       tick_level_end[0]++;
     }


  for (i=1;i<5;i++) /* 5 sublevels...*/
    { if (sub_level[i]==0) break; /* no more ticks */
      tick_level_end[i]=tick_level_end[i-1];
      for (k=l_tick_level_end[i-1];k<l_tick_level_end[i];k++)
        { if (i==1) j=0;
          else j=l_tick_level_end[i-2];
          for (;j<l_tick_level_end[i-1];j++)
              if (ticks[k]==ticks[j]) break;
          if (j<=l_tick_level_end[i-1] && ticks[k]>=side_pt->label_max
                                       && ticks[k]<=side_pt->label_min) /* no copy found */
           { idc[(*nticks)++]=k;
             tick_level_end[i]++;
           }
        }
     }
  }
 
 return(1);
}
              
gint subdivide_interval(double int_min, double int_max, gint intervals, 
                       double *ticks, guint *nticks,
                       guint32 flags,  guint32 lflags,
                       char sublevel, char ndigits, box_side *side_pt)
{ guint i,old_nticks;
  double delta,exponent,mantissa,tick_number,tick_min,power;
  char label[30],format[30],format_exp[30];
  guint32 labelflag;

  i=0;
  old_nticks=*nticks;

/* First the simple linear case */
  if ((flags&BOX_LOG10_INTERVAL)==0 && (flags &BOX_LN_INTERVAL)==0) /* Not logaritmic */
   { delta=(int_max-int_min)/intervals;
     if (!(lflags&LABEL_ALIGN_DECADE) || sublevel>0)
      tick_min=int_min;
     else
      tick_min=pow(10,side_pt->align_decade)*
               floor(int_min/pow(10,side_pt->align_decade));
     for (i=0;i<=intervals;i++)
      { ticks[*nticks]=tick_min+i*delta;

        if ((lflags&LABEL_NO_LABELS)==0)
         {  switch (lflags&(LABEL_DEFAULT | LABEL_EXP | LABEL_E | LABEL_e|
                          LABEL_H_M | LABEL_H_M_S | LABEL_HhM | LABEL_HhM_S|
                          LABEL_HHM | LABEL_HHM_S))
           { case (LABEL_EXP) :
             case (LABEL_E) :
             case (LABEL_e) :
              if (ticks[*nticks]!=0)
               { exponent=log10(fabs(ticks[*nticks]));
                 if (exponent!=0)
                  exponent=exponent/fabs(exponent)*floor(fabs(exponent));
               }
              else exponent=0;
             mantissa=ticks[*nticks]/pow(10,exponent);
            if (side_pt->sub_interval_base[sublevel]==0)
             {if ((lflags&LABEL_IGNORE_TRAILING_0)>0
                   &&fabs(mantissa)==floor(fabs(mantissa)))
                   sprintf(format,"%%1.0f");
              else
                  sprintf(format,"%%1.%df",ndigits);
              if ((lflags&LABEL_IGNORE_LEADING_1)>0&&mantissa==1)
               {if ((lflags&LABEL_EXP)>0)
                 sprintf(format_exp,"10\\sp%%1.0f");
                if ((lflags&LABEL_E)>0)
                 sprintf(format_exp,"E%%1.0f");
                if ((lflags&LABEL_e)>0)
                 sprintf(format_exp,"e%%1.0f");
                sprintf(tick_labels[*nticks], format_exp,exponent);
               }
              else
               {if ((lflags&LABEL_EXP)>0)
                 sprintf(format_exp,"%s\\mu10\\sp%%1.0f",format);
                if ((lflags&LABEL_E)>0)
                 sprintf(format_exp,"%sE%%1.0f",format);
                if ((lflags&LABEL_e)>0)
                 sprintf(format_exp,"%se%%1.0f",format);
                sprintf(tick_labels[*nticks], format_exp,mantissa,exponent);
               }
              }
              else
               sprintf(tick_labels[*nticks], format,
               i*side_pt->sub_interval_base[sublevel]/side_pt->sub_intervals[sublevel]);              
              break;
            case (LABEL_DEFAULT) :
            default:
             if (side_pt->sub_interval_base[sublevel]==0)
              tick_number=ticks[*nticks];
             else
              tick_number=i*side_pt->sub_interval_base[sublevel]/side_pt->sub_intervals[sublevel];
             if ((lflags&LABEL_IGNORE_TRAILING_0)>0
                   &&fabs(tick_number)==floor(fabs(tick_number)))
                  sprintf(format,"%%1.0f");
             else
                  sprintf(format,"%%1.%df",ndigits);

             sprintf(tick_labels[*nticks], format,tick_number);
           }
        }
       (*nticks)++;
     }
    }

  if ((flags&BOX_LOG10_INTERVAL)>0&&int_min>0 && int_max>0) /*Log scale */
   { power=(int_max-int_min)/fabs(int_max-int_min);
     if (sublevel==0)
      { tick_min=pow(10,floor(log10(int_min)));
        delta=1;
      }
     else
      { tick_min=int_min;
        if (int_max>int_min)
         delta=int_min;
        else
         delta=int_max;

      }
     for (i=0;i<intervals;i++)
      { if (sublevel==0)
         ticks[*nticks]=tick_min*pow(10,power*i);
        else
         ticks[*nticks]=tick_min+i*power*delta;
        if ((lflags&LABEL_NO_LABELS)==0)
         {  switch (lflags&(LABEL_DEFAULT | LABEL_EXP | LABEL_E | LABEL_e|
                          LABEL_H_M | LABEL_H_M_S | LABEL_HhM | LABEL_HhM_S|
                          LABEL_HHM | LABEL_HHM_S))
           { case (LABEL_EXP) :
             case (LABEL_E) :
             case (LABEL_e) :
              if (ticks[*nticks]!=0)
               { exponent=log10(fabs(ticks[*nticks]));
                 if (exponent!=0)
                  exponent=exponent/fabs(exponent)*floor(fabs(exponent));
               }
              else exponent=0;
             mantissa=ticks[*nticks]/pow(10,exponent);
            if (side_pt->sub_interval_base[sublevel]==0)
             {if ((lflags&LABEL_IGNORE_TRAILING_0)>0
                   &&fabs(mantissa)==floor(fabs(mantissa)))
                   sprintf(format,"%%1.0f");
              else
                  sprintf(format,"%%1.%df",ndigits);
              if ((lflags&LABEL_IGNORE_LEADING_1)>0&&mantissa==1)
               {if ((lflags&LABEL_EXP)>0)
                 sprintf(format_exp,"10\\sp%%1.0f");
                if ((lflags&LABEL_E)>0)
                 sprintf(format_exp,"E%%1.0f");
                if ((lflags&LABEL_e)>0)
                 sprintf(format_exp,"e%%1.0f");
                sprintf(tick_labels[*nticks], format_exp,exponent);
               }
              else
               {if ((lflags&LABEL_EXP)>0)
                 sprintf(format_exp,"%s\\mu10\\sp%%1.0f",format);
                if ((lflags&LABEL_E)>0)
                 sprintf(format_exp,"%sE%%1.0f",format);
                if ((lflags&LABEL_e)>0)
                 sprintf(format_exp,"%se%%1.0f",format);
                sprintf(tick_labels[*nticks], format_exp,mantissa,exponent);
               }
              }
              else
               { sprintf(tick_labels[*nticks], format,
                 (i+1)*side_pt->sub_interval_base[sublevel]/side_pt->sub_intervals[sublevel]);
               }
              break;
            case (LABEL_DEFAULT) :
            default:
             if (side_pt->sub_interval_base[sublevel]==0)
              tick_number=ticks[*nticks];
             else
              tick_number=(i+1);
             if ((lflags&LABEL_IGNORE_TRAILING_0)>0
                   &&fabs(tick_number)==floor(fabs(tick_number)))
                  sprintf(format,"%%1.0f");
             else
                  sprintf(format,"%%1.%df",ndigits);

             sprintf(tick_labels[*nticks], format,tick_number);
           }
        }
       (*nticks)++;
     }
    }
  return(i);
}

gint render_ticks(fc_node* box_node, box_data_2d *box_data, box_side *side_pt,
                  double *unit_to_page, double *ticks, guint* tick_level_end,
                  guint nticks)
{ double system_to_page,y1,y2,x1,x2,m,c,y_level,x_level,dir=0,len,pos,l_offset;
  guint level=0,i,j,k;
  char v_just,h_just;

  v_just=side_pt->tick_label_v_just;
  h_just=side_pt->tick_label_h_just;

if  (!(side_pt->flags&BOX_LOG10_INTERVAL) && !(side_pt->flags&BOX_LN_INTERVAL)) /* Not a log scale */
 { if ((side_pt->pos=='t' || side_pt->pos=='b'))
   { m=cur_sys_hor_m;
     c=cur_sys_hor_c;
     if (side_pt->flags&BOX_POS_SPES)
      y_level=m*side_pt->side_pos+c;
     else
      { if (side_pt->pos=='t') y_level=box_data->y_max_box;
        else y_level=box_data->y_min_box;
      }
   }

  if ((side_pt->pos=='l' || side_pt->pos=='r'))
   { m=cur_sys_ver_m;
     c=cur_sys_ver_c;
     if (side_pt->flags&BOX_POS_SPES)
      x_level=m*side_pt->side_pos+c;
     else
      { if (side_pt->pos=='r') x_level=box_data->x_max_box;
        else x_level=box_data->x_min_box;
      }
   }
/* Draw the line the tick marks stick to */
   if (side_pt->flags &  BOX_DRAW_SIDE)
    { flinewidth(side_pt->box_line_width*unit_to_page[side_pt->line_unit]);
      linemod(line_types[side_pt->box_line_type]);
      pencolor(box_data->fg_color->r,
               box_data->fg_color->g,
               box_data->fg_color->b);
      switch (side_pt->pos)
       { case 'b':
         case 't': fline(box_data->x_min_box,y_level,
                   box_data->x_max_box,y_level);
                   break;
         case 'r':
         case 'l': fline(x_level,box_data->y_min_box,
                   x_level,box_data->y_max_box);
                   break;
       }
     }
  if ((side_pt->pos=='l' || side_pt->pos=='b'))
   dir=-1;
  else dir=1; /* Direction to go for ticks going outward */

 /* Now draw the ticks! */
  if ((side_pt->pos=='t' || side_pt->pos=='b')) /* ticks are vertical */
   { for (i=0;i<5;i++) /* 5 tick levels */
       { if (side_pt->tick_len[i]==0) break;
         pencolor(side_pt->tick_color[i]->r,
                         side_pt->tick_color[i]->g,
                  side_pt->tick_color[i]->b);
         linemod(line_types[side_pt->tick_line_type[i]]);
         flinewidth(side_pt->tick_line_width[i]*unit_to_page[side_pt->line_unit]);
         len=side_pt->tick_len[i]*unit_to_page[side_pt->line_unit];
         if (i==0) j=0;
         else j=tick_level_end[i-1];
         k=j;
         if ((side_pt->flags&BOX_TICKS_OUTWARD)>0)
          for (;j<tick_level_end[i];j++)
            { pos=m*ticks[idc[j]]+c;
              fline(pos,y_level,pos,y_level+len*dir);
            }
         if ((side_pt->flags&BOX_TICKS_INWARD)>0)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*ticks[idc[j]]+c;
              fline(pos,y_level,pos,y_level-len*dir);
            }
         if ((side_pt->label_format[i]&LABEL_DRAW_GRID)>0)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*ticks[idc[j]]+c;
              fline(pos,box_data->y_min_box,pos,box_data->y_max_box);
            }
         if (i<side_pt->label_depth)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*ticks[idc[j]]+c;
              fontname(side_pt->tick_font);
              ffontsize(side_pt->tick_label_size[i]*unit_to_page[side_pt->label_unit]);
              ftextangle(side_pt->tick_label_rot[i]);
              l_offset=side_pt->tick_offset*unit_to_page[side_pt->label_unit];
              fmove(pos,y_level+l_offset*dir);
              alabel(h_just,v_just,tick_labels[idc[j]]);
            }
        }
    }
  else
   { for (i=0;i<5;i++) /* 5 tick levels */
       { len=side_pt->tick_len[i]*unit_to_page[side_pt->line_unit];
         pencolor(side_pt->tick_color[i]->r,
                         side_pt->tick_color[i]->g,
                  side_pt->tick_color[i]->b);
         linemod(line_types[side_pt->tick_line_type[i]]);
         flinewidth(side_pt->tick_line_width[i]*unit_to_page[side_pt->line_unit]);
         if (i==0) j=0;
         else j=tick_level_end[i-1];
         k=j;
         if (side_pt->flags&BOX_TICKS_OUTWARD)
          for (;j<tick_level_end[i];j++)
            { pos=m*ticks[idc[j]]+c;
              fline(x_level,pos,x_level+len*dir,pos);
            }
         if (side_pt->flags&BOX_TICKS_INWARD)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*ticks[idc[j]]+c;
              fline(x_level,pos,x_level-len*dir,pos);
            }
         if ((side_pt->label_format[i]&LABEL_DRAW_GRID)>0)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*ticks[idc[j]]+c;
              fline(box_data->x_min_box,pos,box_data->x_max_box,pos);
            }

         if (i<side_pt->label_depth)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*ticks[idc[j]]+c;
              fontname(side_pt->tick_font);
              ffontsize(side_pt->tick_label_size[i]*unit_to_page[side_pt->label_unit]);
              ftextangle(side_pt->tick_label_rot[i]);
              l_offset=side_pt->tick_offset*unit_to_page[side_pt->label_unit];
              fmove(x_level+l_offset*dir,pos);
              alabel(h_just,v_just,tick_labels[idc[j]]);
            }

        }
    }
  }
 else /* LOG axis */
 { if ((side_pt->pos=='t' || side_pt->pos=='b'))
   { m=cur_sys_hor_m;
     c=cur_sys_hor_c;
     if (side_pt->flags&BOX_POS_SPES)
      y_level=m*log10(side_pt->side_pos)+c;
     else
      { if (side_pt->pos=='t') y_level=box_data->y_max_box;
        else y_level=box_data->y_min_box;
      }
   }

  if ((side_pt->pos=='l' || side_pt->pos=='r'))
   { m=cur_sys_ver_m;
     c=cur_sys_ver_c;
     if (side_pt->flags&BOX_POS_SPES)
      x_level=m*log10(side_pt->side_pos)+c;
     else
      { if (side_pt->pos=='r') x_level=box_data->x_max_box;
        else x_level=box_data->x_min_box;
      }
   }

/* Draw the line the tick marks stick to */
   if (side_pt->flags &  BOX_DRAW_SIDE)
    { flinewidth(side_pt->box_line_width*unit_to_page[side_pt->line_unit]);
      linemod(line_types[side_pt->box_line_type]);
      pencolor(box_data->fg_color->r,
               box_data->fg_color->g,
               box_data->fg_color->b);
      switch (side_pt->pos)
       { case 'b':
         case 't': fline(box_data->x_min_box,y_level,
                   box_data->x_max_box,y_level);
                   break;
         case 'r':
         case 'l': fline(x_level,box_data->y_min_box,
                   x_level,box_data->y_max_box);
                   break;
       }
     }


  if ((side_pt->pos=='l' || side_pt->pos=='b'))
   dir=-1;
  else dir=1; /* Direction to go for ticks going outward */

 /* Now draw the ticks! */
  if ((side_pt->pos=='t' || side_pt->pos=='b')) /* ticks are vertical */
   { for (i=0;i<5;i++) /* 5 tick levels */
       {
         pencolor(side_pt->tick_color[i]->r,
                         side_pt->tick_color[i]->g,
                  side_pt->tick_color[i]->b);
         linemod(line_types[side_pt->tick_line_type[i]]);
         flinewidth(side_pt->tick_line_width[i]*unit_to_page[side_pt->line_unit]);

         if (side_pt->tick_len[i]==0) break;
         len=side_pt->tick_len[i]*unit_to_page[side_pt->line_unit];
         if (i==0) j=0;
         else j=tick_level_end[i-1];
         k=j;
         if ((side_pt->flags&BOX_TICKS_OUTWARD)>0)
          for (;j<tick_level_end[i];j++)
            { pos=m*log10(ticks[idc[j]])+c;
              fline(pos,y_level,pos,y_level+len*dir);
            }
         if ((side_pt->flags&BOX_TICKS_INWARD)>0)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*log10(ticks[idc[j]])+c;
              fline(pos,y_level,pos,y_level-len*dir);
            }
         if ((side_pt->label_format[i]&LABEL_DRAW_GRID)>0)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*log10(ticks[idc[j]])+c;
              fline(pos,box_data->y_min_box,pos,box_data->y_max_box);
            }
         if (i<side_pt->label_depth)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*log10(ticks[idc[j]])+c;
              fontname(side_pt->tick_font);
              ffontsize(side_pt->tick_label_size[i]*unit_to_page[side_pt->label_unit]);
              ftextangle(side_pt->tick_label_rot[i]);
              l_offset=side_pt->tick_offset*unit_to_page[side_pt->label_unit];
              pencolor(side_pt->label_color->r,
                       side_pt->label_color->g,
                       side_pt->label_color->b);
              fmove(pos,y_level+l_offset*dir);
              alabel(h_just,v_just,tick_labels[idc[j]]);
            }
        }
    }
  else
   { for (i=0;i<5;i++) /* 5 tick levels */
       { len=side_pt->tick_len[i]*unit_to_page[side_pt->line_unit];
         pencolor(side_pt->tick_color[i]->r,
                         side_pt->tick_color[i]->g,
                  side_pt->tick_color[i]->b);
         linemod(line_types[side_pt->tick_line_type[i]]);
         flinewidth(side_pt->tick_line_width[i]*unit_to_page[side_pt->line_unit]);

         if (i==0) j=0;
         else j=tick_level_end[i-1];
         k=j;
         if (side_pt->flags&BOX_TICKS_OUTWARD)
          for (;j<tick_level_end[i];j++)
            { pos=m*log10(ticks[idc[j]])+c;
              fline(x_level,pos,x_level+len*dir,pos);
            }
         if (side_pt->flags&BOX_TICKS_INWARD)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*log10(ticks[idc[j]])+c;
              fline(x_level,pos,x_level-len*dir,pos);
            }
         if ((side_pt->label_format[i]&LABEL_DRAW_GRID)>0)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*log10(ticks[idc[j]])+c;
              fline(box_data->x_min_box,pos,box_data->x_max_box,pos);
            }
         if (i<side_pt->label_depth)
          for (j=k;j<tick_level_end[i];j++)
            { pos=m*log10(ticks[idc[j]])+c;
              fontname(side_pt->tick_font);
              ffontsize(side_pt->tick_label_size[i]*unit_to_page[side_pt->label_unit]);
              ftextangle(side_pt->tick_label_rot[i]);
              l_offset=side_pt->tick_offset*unit_to_page[side_pt->label_unit];
              pencolor(side_pt->label_color->r,
                       side_pt->label_color->g,
                       side_pt->label_color->b);
              fmove(x_level+l_offset*dir,pos);
              alabel(h_just,v_just,tick_labels[idc[j]]);
            }

        }
    }
  }
return(1);
}

gint render_box_side_2d(fc_node* box_node, box_data_2d *box_data, box_side *side_pt)
{ double ticks[1000], l_offset=0,pos=0.5;
  char units;
  guint i,j,nticks,tick_level_end[5];

     
/* Now calculate tick positions */     
   nticks=0;
 if (side_pt->sub_intervals[0]>0) /* If the numer of major intervals==0 -> no ticks*/
   for (i=0;i<5;i++) /* 5 tick levels */
    { if (i==0) tick_level_end[i]=0;
      else tick_level_end[i]=tick_level_end[i-1];
      if (i==0 && side_pt->sub_intervals[i]>0)
       { if ((side_pt->pos=='t' || side_pt->pos=='b'))
          tick_level_end[i]+=subdivide_interval(box_data->x_min_system,
                              box_data->x_max_system,
                              side_pt->sub_intervals[i], ticks, &nticks,
                              side_pt->flags,side_pt->label_format[i],
                              (char) i,side_pt->label_digits,side_pt);
         else
          tick_level_end[i]+=subdivide_interval(box_data->y_min_system,
                              box_data->y_max_system,
                              side_pt->sub_intervals[i], ticks, &nticks,
                              side_pt->flags, side_pt->label_format[i],(char) i,side_pt->label_digits,
                              side_pt);
       }
      if (i>0 && side_pt->sub_intervals[i]>0)
       { if (i==1) j=0;
         else j=tick_level_end[i-2];
         for (;j<tick_level_end[i-1]-1;j++)
          tick_level_end[i]+=subdivide_interval(ticks[j],
                              ticks[j+1],
                              side_pt->sub_intervals[i], ticks, &nticks,
                              side_pt->flags, side_pt->label_format[i],(char) i,side_pt->label_digits,
                              side_pt);
       }
     }

 eliminate_copies(ticks, &nticks, tick_level_end, side_pt->sub_intervals,side_pt);
 
 render_ticks(box_node, box_data, side_pt,
               unit_to_page, ticks, tick_level_end,
               nticks);
 if (side_pt->label)
 { fontname(side_pt->tick_font);
   ffontsize(side_pt->text_size*unit_to_page[side_pt->label_unit]);
   l_offset=side_pt->label_offset*unit_to_page[side_pt->label_unit];
   pencolor(box_data->text_color->r,box_data->text_color->g,box_data->text_color->b);
   switch (side_pt->pos)
   { case 'l': ftextangle(90);
               pos=side_pt->label_pos*(box_data->y_min_box+box_data->y_max_box);
               fmove(box_data->x_min_box-l_offset,pos);
               alabel(side_pt->label_h_just,side_pt->label_v_just,side_pt->label);
               break;
    case 'r': ftextangle(270);
               pos=side_pt->label_pos*(box_data->y_min_box+box_data->y_max_box);
               fmove(box_data->x_max_box+l_offset,pos);
               alabel(side_pt->label_h_just,side_pt->label_v_just,side_pt->label);
               break;
    case 't': ftextangle(0);
               pos=side_pt->label_pos*(box_data->x_min_box+box_data->x_max_box);
               fmove(pos,box_data->y_max_box+l_offset);
               alabel(side_pt->label_h_just,side_pt->label_v_just,side_pt->label);
               break;
    case 'b': ftextangle(0);
               pos=side_pt->label_pos*(box_data->x_min_box+box_data->x_max_box);
               fmove(pos,box_data->y_min_box-l_offset);
               alabel(side_pt->label_h_just,side_pt->label_v_just,side_pt->label);
               break;
   }
  }
  return(1);
}
    
int render_box_2d(fc_node *box_node, double x_max, double y_max, char doc_units)
{ box_data_2d *box_data;
  gint i;
  double text_x,text_y;

  box_data= (box_data_2d *)(box_node->node_data);

  /* Draw background of system */
  color(box_data->bg_color->r,box_data->bg_color->g,box_data->bg_color->b);
  filltype(1);
  fbox(box_data->x_min_box,box_data->y_min_box,
       box_data->x_max_box,box_data->y_max_box);

  /* Render the four sides of the box */
  for (i=0;i<4;i++)
    render_box_side_2d(box_node, box_data,box_data->side[i]);

  /* Determine the position of the system label */
  if (box_data->text_font)
   fontname(box_data->text_font);
   ffontsize(box_data->text_size*unit_to_page[box_data->text_unit]);
   ftextangle(box_data->text_rot);
   switch (box_data->text_side)
   { case 'l': text_x=box_data->x_min_box-
               unit_to_page[box_data->text_unit]*box_data->text_offset;
               text_y=0.5*(box_data->y_max_box+box_data->y_min_box);
               break;
     case 'r': text_x=box_data->x_max_box+
               unit_to_page[box_data->text_unit]*box_data->text_offset;
               text_y=0.5*(box_data->x_max_box+box_data->x_min_box);
               break;
     case 't': text_y=box_data->y_max_box+
               unit_to_page[box_data->text_unit]*box_data->text_offset;
               text_x=0.5*(box_data->x_max_box+box_data->x_min_box);
               break;
     case 'b': text_y=box_data->y_max_box-
               unit_to_page[box_data->text_unit]*box_data->text_offset;
               text_x=0.5*(box_data->x_max_box+box_data->x_min_box);
   }

  /* Draw the label */
   fmove(text_x,text_y);
   alabel(box_data->text_h_just,box_data->text_v_just,box_data->label_text);

  return(1);
}

int render_system(fc_node *box_node, double x_max, double y_max, char doc_units)
{ gint i;
  char units;
  box_data_2d *box_data;
  box_side *side_t, *side_r;
  double x1,x2,y1,y2;
  double minx, maxx, miny, maxy;
  
  box_data= (box_data_2d *)(box_node->node_data);
  side_t=box_data->side[TOP_SIDE];
  side_r=box_data->side[RIGHT_SIDE];

  unit_to_page[PIXELS]=1/(page_magn*((page_data *)current_page->node_data)->y_max_screen);
  units=((page_data *)current_page->node_data)->units;

  switch (units)
   { case PIXELS: for (i=1; i<5; i++)
                    unit_to_page[i]=screen_dpi/
                     (((page_data *)current_page->node_data)->y_max*
                        fc_units_per_inch[i]);
                  break;
     default: for (i=1; i<5; i++)
                unit_to_page[i]=fc_units_per_inch[units]/
                     (((page_data *)current_page->node_data)->y_max*
                      fc_units_per_inch[i]);
    }

/* Calculate the transformations from system coordinates to page coordinates */
 if  (!(side_t->flags&BOX_LOG10_INTERVAL) && !(side_t->flags&BOX_LN_INTERVAL)) /* Not a log scale */
   { y1=box_data->x_min_box;
     y2=box_data->x_max_box;
     x1=box_data->x_min_system;
     x2=box_data->x_max_system;
     if (x2==x1) return(0); /* Uh-oh! */
     cur_sys_hor_m=(y2-y1)/(x2-x1);
     cur_sys_hor_c=y1-cur_sys_hor_m*x1;
    }
  if  (!(side_r->flags&BOX_LOG10_INTERVAL) && !(side_t->flags&BOX_LN_INTERVAL)) /* Not a log scale */    
   { y1=box_data->y_min_box;
     y2=box_data->y_max_box;
     x1=box_data->y_min_system;
     x2=box_data->y_max_system;
     if (x2==x1) return(0); /* Uh-oh! */
     cur_sys_ver_m=(y2-y1)/(x2-x1);
     cur_sys_ver_c=y1-cur_sys_ver_m*x1;  
   }
 if  ((side_t->flags&BOX_LOG10_INTERVAL)>0)
   { y1=box_data->x_min_box;
     y2=box_data->x_max_box;
     x1=log10(box_data->x_min_system);
     x2=log10(box_data->x_max_system);
     if (x2==x1) return(0); /* Uh-oh */
     cur_sys_hor_m=(y2-y1)/(x2-x1);
     cur_sys_hor_c=y1-cur_sys_hor_m*x1;
   }
 if  ((side_r->flags&BOX_LOG10_INTERVAL)>0)
   { y1=box_data->y_min_box;
     y2=box_data->y_max_box;
     x1=log10(box_data->y_min_system);
     x2=log10(box_data->y_max_system);
     if (x2==x1) return(0); /* Uh-oh */
     cur_sys_ver_m=(y2-y1)/(x2-x1);
     cur_sys_ver_c=y1-cur_sys_ver_m*x1;
   }

 /*Now draw the box */
  render_box_2d(box_node,x_max, y_max, doc_units);

  if (box_data->x_min_system<box_data->x_max_system)
   { minx=box_data->x_min_system;
     maxx=box_data->x_max_system;
   }
  else
   { minx=box_data->x_max_system;
     maxx=box_data->x_min_system;
   }

  if (box_data->y_min_system<box_data->y_max_system)
   { miny=box_data->y_min_system;
     maxy=box_data->y_max_system;
   }
  else
   { miny=box_data->y_max_system;
     maxy=box_data->y_min_system;
   }
     
  for (i=0;i<box_node->n_children;i++)
   if ((fc_node *)box_node->list_children[i])
    switch (((fc_node *)box_node->list_children[i])->node_type)
       { case XY_2D_NODE: 
         xy_resolve_yor_funcs(((fc_node *)box_node->list_children[i]));
	 xy_render(((fc_node *)box_node->list_children[i]),
	           (side_t->flags&BOX_LOG10_INTERVAL), 
		   (side_r->flags&BOX_LOG10_INTERVAL), 
                   minx, maxx, miny, maxy);
	break;
       }

  return(1);
}

int render_page(fc_node *page)
{ guint i,j;
  char doc_units;
  static double x_max, y_max;
  page_data *page_info;

  return(1);
  printf("render_page\n");
  if (!fc_render_busy)
   { fc_render_busy=TRUE;
     fc_idle_add(&fc_render_busy);
     fc_child_render=0;
     render_tag=gtk_timeout_add(250,g_render_update,NULL);
   }

  x_max=((page_data *)(page->node_data))->x_max;
  y_max=((page_data *)(page->node_data))->y_max;

  if (fc_yor_busy) return(0); /* wait for yorick to finish first */
  if (fc_child_render<page->n_children)
   { switch (((fc_node *)page->list_children[fc_child_render])->node_type)
         { case 
	   BOX_2D_NODE: render_system(page->list_children[fc_child_render],
	                x_max, y_max, doc_units);
			break;
	 }
	 
     fc_child_render++;
   }
  else
  { fc_render_busy=FALSE;
    g_render_update(NULL);
    gtk_timeout_remove(render_tag);
  }
  return (1);
}