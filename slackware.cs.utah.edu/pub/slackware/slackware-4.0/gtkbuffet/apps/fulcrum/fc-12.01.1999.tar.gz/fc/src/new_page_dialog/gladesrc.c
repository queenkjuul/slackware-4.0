/*  Note: You are free to use whatever license you want.
    Eventually you will be able to edit it within Glade. */

/*  <PROJECT NAME>
 *  Copyright (C) <YEAR> <AUTHORS>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include "gladesig.h"
#include "gladesrc.h"

GtkWidget*
get_widget                             (GtkWidget       *widget,
                                        gchar           *widget_name)
{
  GtkWidget *found_widget;

  if (widget->parent)
    widget = gtk_widget_get_toplevel (widget);
  found_widget = (GtkWidget*) gtk_object_get_data (GTK_OBJECT (widget),
                                                   widget_name);
  if (!found_widget)
    g_warning ("Widget not found: %s", widget_name);
  return found_widget;
}

/* This is an internally used function to set notebook tab widgets. */
void
set_notebook_tab                       (GtkWidget       *notebook,
                                        gint             page_num,
                                        GtkWidget       *widget)
{
  GtkNotebookPage *page;
  GtkWidget *notebook_page;

  page = (GtkNotebookPage*) g_list_nth (GTK_NOTEBOOK (notebook)->children, page_num)->data;
  notebook_page = page->child;
  gtk_widget_ref (notebook_page);
  gtk_notebook_remove_page (GTK_NOTEBOOK (notebook), page_num);
  gtk_notebook_insert_page (GTK_NOTEBOOK (notebook), notebook_page,
                            widget, page_num);
  gtk_widget_unref (notebook_page);
}

GtkWidget*
create_dialog1 ()
{
  GtkWidget *dialog1;
  GtkWidget *dialog_vbox1;
  GtkWidget *table1;
  GtkWidget *button4;
  GtkWidget *label6;
  GtkWidget *checkbutton4;
  GtkWidget *label5;
  GtkObject *spinbutton2_adj;
  GtkWidget *spinbutton2;
  GtkObject *spinbutton1_adj;
  GtkWidget *spinbutton1;
  GtkWidget *checkbutton2;
  GtkWidget *optionmenu1;
  GtkWidget *optionmenu1_menu;
  GtkWidget *glade_menuitem;
  GtkWidget *optionmenu2;
  GtkWidget *optionmenu2_menu;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbox1;
  GtkWidget *button1;
  GtkWidget *button2;
  GtkTooltips *tooltips;

  tooltips = gtk_tooltips_new ();

  dialog1 = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (dialog1), "dialog1", dialog1);
  GTK_WINDOW (dialog1)->type = GTK_WINDOW_DIALOG;
  gtk_window_set_title (GTK_WINDOW (dialog1), "fulcrum: New page");
  gtk_window_set_policy (GTK_WINDOW (dialog1), TRUE, TRUE, TRUE);

  dialog_vbox1 = GTK_DIALOG (dialog1)->vbox;
  gtk_object_set_data (GTK_OBJECT (dialog1), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  table1 = gtk_table_new (4, 3, FALSE);
  gtk_object_set_data (GTK_OBJECT (dialog1), "table1", table1);
  gtk_widget_show (table1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), table1, TRUE, TRUE, 0);
  gtk_container_border_width (GTK_CONTAINER (table1), 1);
  gtk_table_set_row_spacings (GTK_TABLE (table1), 8);

  button4 = gtk_button_new_with_label ("");
  gtk_object_set_data (GTK_OBJECT (dialog1), "button4", button4);
  gtk_widget_show (button4);
  gtk_table_attach (GTK_TABLE (table1), button4, 1, 2, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, button4, "On-screen backgound colour", NULL);

  label6 = gtk_label_new ("Background colour:");
  gtk_object_set_data (GTK_OBJECT (dialog1), "label6", label6);
  gtk_widget_show (label6);
  gtk_table_attach (GTK_TABLE (table1), label6, 0, 1, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label6), GTK_JUSTIFY_RIGHT);

  checkbutton4 = gtk_check_button_new_with_label ("Switch to this page");
  gtk_object_set_data (GTK_OBJECT (dialog1), "checkbutton4", checkbutton4);
  gtk_widget_show (checkbutton4);
  gtk_table_attach (GTK_TABLE (table1), checkbutton4, 0, 1, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, checkbutton4, "Switch to this page upon creation", NULL);
  gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (checkbutton4), TRUE);

  label5 = gtk_label_new ("Width x Height: ");
  gtk_object_set_data (GTK_OBJECT (dialog1), "label5", label5);
  gtk_widget_show (label5);
  gtk_table_attach (GTK_TABLE (table1), label5, 0, 1, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  spinbutton2_adj = gtk_adjustment_new (21.5, 0, 1000, 0.5, 10, 10);
  spinbutton2 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton2_adj), 1, 1);
  gtk_object_set_data (GTK_OBJECT (dialog1), "spinbutton2", spinbutton2);
  gtk_widget_show (spinbutton2);
  gtk_table_attach (GTK_TABLE (table1), spinbutton2, 2, 3, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  GTK_WIDGET_SET_FLAGS (spinbutton2, GTK_CAN_DEFAULT);
  gtk_widget_grab_default (spinbutton2);
  gtk_tooltips_set_tip (tooltips, spinbutton2, "Height", NULL);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spinbutton2), TRUE);
  gtk_spin_button_set_update_policy (GTK_SPIN_BUTTON (spinbutton2), GTK_UPDATE_IF_VALID | GTK_UPDATE_SNAP_TO_TICKS);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinbutton2), TRUE);

  spinbutton1_adj = gtk_adjustment_new (29.5, 0, 1000, 0.5, 10, 10);
  spinbutton1 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton1_adj), 1, 1);
  gtk_object_set_data (GTK_OBJECT (dialog1), "spinbutton1", spinbutton1);
  gtk_widget_show (spinbutton1);
  gtk_table_attach (GTK_TABLE (table1), spinbutton1, 1, 2, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  GTK_WIDGET_SET_FLAGS (spinbutton1, GTK_CAN_DEFAULT);
  gtk_widget_grab_default (spinbutton1);
  gtk_tooltips_set_tip (tooltips, spinbutton1, "Width", NULL);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spinbutton1), TRUE);
  gtk_spin_button_set_update_policy (GTK_SPIN_BUTTON (spinbutton1), GTK_UPDATE_IF_VALID);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinbutton1), TRUE);

  checkbutton2 = gtk_check_button_new_with_label ("Use defaults");
  gtk_object_set_data (GTK_OBJECT (dialog1), "checkbutton2", checkbutton2);
  gtk_widget_show (checkbutton2);
  gtk_table_attach (GTK_TABLE (table1), checkbutton2, 0, 1, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, checkbutton2, "Use papertype defaults or inherit from previous pages", NULL);
  gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (checkbutton2), TRUE);

  optionmenu1 = gtk_option_menu_new ();
  gtk_object_set_data (GTK_OBJECT (dialog1), "optionmenu1", optionmenu1);
  gtk_widget_show (optionmenu1);
  gtk_table_attach (GTK_TABLE (table1), optionmenu1, 1, 2, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, optionmenu1, "Paper type", NULL);
  optionmenu1_menu = gtk_menu_new ();
  glade_menuitem = gtk_menu_item_new_with_label ("Papertype:");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu1_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("Letter");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu1_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("A4");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu1_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("User defined");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu1_menu), glade_menuitem);
  gtk_option_menu_set_menu (GTK_OPTION_MENU (optionmenu1), optionmenu1_menu);
  gtk_option_menu_set_history (GTK_OPTION_MENU (optionmenu1), 2);

  optionmenu2 = gtk_option_menu_new ();
  gtk_object_set_data (GTK_OBJECT (dialog1), "optionmenu2", optionmenu2);
  gtk_widget_show (optionmenu2);
  gtk_table_attach (GTK_TABLE (table1), optionmenu2, 2, 3, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, optionmenu2, "Paper units", NULL);
  optionmenu2_menu = gtk_menu_new ();
  glade_menuitem = gtk_menu_item_new_with_label ("Units:");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("Pixels");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("Points");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("mm");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("cm");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("inches");
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  gtk_option_menu_set_menu (GTK_OPTION_MENU (optionmenu2), optionmenu2_menu);
  gtk_option_menu_set_history (GTK_OPTION_MENU (optionmenu2), 4);

  dialog_action_area1 = GTK_DIALOG (dialog1)->action_area;
  gtk_object_set_data (GTK_OBJECT (dialog1), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_object_set_data (GTK_OBJECT (dialog1), "hbox1", hbox1);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbox1, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label ("OK");
  gtk_object_set_data (GTK_OBJECT (dialog1), "button1", button1);
  gtk_widget_show (button1);
  gtk_box_pack_start (GTK_BOX (hbox1), button1, TRUE, TRUE, 5);
  gtk_widget_grab_focus (button1);

  button2 = gtk_button_new_with_label ("Cancel");
  gtk_object_set_data (GTK_OBJECT (dialog1), "button2", button2);
  gtk_widget_show (button2);
  gtk_box_pack_start (GTK_BOX (hbox1), button2, TRUE, TRUE, 5);

  return dialog1;
}

