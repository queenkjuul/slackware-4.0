#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include "object_tree.h"
#include "doc_dialog.h"
#include "page_dialog.h"
#include "render_page.h"
#include "graph_window.h"

GtkWidget *dialog2;

GtkWidget *page_dialog;
GtkWidget *spinbutton1;
GtkWidget *spinbutton2;
GtkWidget *checkbutton2;
GtkWidget *checkbutton4;
GtkWidget *optionmenu1;
GtkWidget *optionmenu2;
GtkWidget *radio1, *radio2;
GtkObject *spinbutton2_adj;
GtkObject *spinbutton1_adj;
GtkWidget *color_button;
GtkWidget *colorsel_d;
GtkStyle  *button_style;
GdkGC *button_gc;

gchar page_dialog_busy=FALSE,papertype=1,orientation=PORTRAIT,paperunits=CM,
      user_units=PIXELS, info_dialog_busy=FALSE;
double page_x=21.5,page_y=29.5,user_x=100,user_y=100;
page_data *page_info;
guint16 bg_red=0xffff;
guint16 bg_green=0xffff;
guint16 bg_blue=0xffff;

fc_node *page_node=NULL;

GtkWidget* info_dialog ();
int set_widget_fg_color(GtkWidget *widget, guint16 r, guint16 g, guint16 b);
void defaults_toggled(GtkWidget *widget, gpointer *data)
{
 set_dialog_state();
}

void units_changed(GtkWidget *widget, gpointer *data)
{ guint type;
  type=(guint)data;
  paperunits=type;
}


void pagetype_changed(GtkWidget *widget, gpointer *data)
{ guint type;
  type=(guint)data;
  if (papertype==99)
   { user_x=(gfloat)(GTK_ADJUSTMENT(spinbutton1_adj)->value);
     user_y=(gfloat)(GTK_ADJUSTMENT(spinbutton2_adj)->value);
     user_units=paperunits;
     printf("user_x=%2.1f user_y=%2.1f user_units=%d\n",user_x,user_y,user_units);
   }
  if (type==0)
   { papertype=99;
     set_dialog_state();
     printf("user_x=%2.1f user_y=%2.1f user_units=%d\n",user_x,user_y,user_units);
     page_x=user_x;
     page_y=user_y;
     gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton1_adj),
                               (gfloat)page_x);
     gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton2_adj),
                               (gfloat)page_y);
     paperunits=user_units;
     gtk_option_menu_set_history (GTK_OPTION_MENU (optionmenu2),user_units-1);
     set_dialog_state();
     return;
   }
  papertype=type-1;
  paperunits=paper_units[papertype];
  printf("papertype=%d paperunits=%d\n",papertype,paperunits);
  gtk_option_menu_set_history (GTK_OPTION_MENU (optionmenu2),
                               paperunits-1);

  if (orientation==PORTRAIT)
   {  page_x=paper_x[papertype];
      page_y=paper_y[papertype];
      gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton1_adj),
                                (gfloat)page_x);
      gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton2_adj),
                                (gfloat)page_y);
   }
  else
   {  page_x=paper_y[papertype];
      page_y=paper_x[papertype];
      gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton1_adj),
                                (gfloat)page_x);
      gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton2_adj),
                                (gfloat)page_y);
   }

  set_dialog_state();
  return;
}

void portrait(GtkWidget *widget, gpointer *data)
{ double temp;
  printf("papertype=%d\n",papertype);
  if (papertype<99)
   { page_x=paper_x[papertype];
     page_y=paper_y[papertype];
     gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton1_adj),
                               (gfloat)page_x);
     gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton2_adj),
                               (gfloat)page_y);
     orientation=PORTRAIT;
   }
}

void landscape(GtkWidget *widget, gpointer *data)
{ double temp;
  printf("papertype=%d\n",papertype);
  if (papertype<99)
   { page_x=paper_y[papertype];
     page_y=paper_x[papertype];
     gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton1_adj),
                               (gfloat)page_x);
     gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton2_adj),
                               (gfloat)page_y);
     orientation=LANDSCAPE;
   }
}


int set_dialog_state(void)
{ 
  if (GTK_TOGGLE_BUTTON (checkbutton2)->active)
   { set_widget_fg_color(color_button,bg_red,bg_green,bg_blue);
     if (current_page||page_node) /* there are previous page(s)*/
      { if (page_node)
          page_info=(page_data *)(page_node->node_data);
        else
          page_info=(page_data *)(current_page->node_data);
        orientation=page_info->orientation;
        paperunits=page_info->units;
        page_x=page_info->x_max;
        page_y=page_info->y_max;
	bg_red=page_info->bg_color->r;
	bg_green=page_info->bg_color->g;
	bg_blue=page_info->bg_color->b;
      }
     else
     {  paperunits=paper_units[papertype];
        page_x=paper_x[papertype];
        page_y=paper_y[papertype];
        if (page_y>page_x)
	 orientation=PORTRAIT;
	else
	 orientation=LANDSCAPE;
	bg_red=0xffff;
	bg_green=0xffff;
	bg_blue=0xffff;
     }
    }
      { gtk_option_menu_set_history (GTK_OPTION_MENU (optionmenu1), papertype+1);
        gtk_option_menu_set_history (GTK_OPTION_MENU (optionmenu2), paperunits-1);
        if (orientation==PORTRAIT)
 	 { gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (radio1), TRUE);
	   gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (radio2), FALSE);
	 }
	else
 	 { gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (radio2), TRUE);
	   gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (radio1), FALSE);
	 }
	gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton1_adj),
                               (gfloat)page_x);
        gtk_adjustment_set_value(GTK_ADJUSTMENT(spinbutton2_adj),
                               (gfloat)page_y);
        set_widget_fg_color(color_button,bg_red,bg_green,bg_blue);
      }

  if (GTK_TOGGLE_BUTTON (checkbutton2)->active)
   { printf("toggle2=ACTIVE\n");
     gtk_widget_set_sensitive(optionmenu1,FALSE);
     gtk_widget_set_sensitive(optionmenu2,FALSE);
     gtk_widget_set_sensitive(spinbutton1,FALSE);
     gtk_widget_set_sensitive(spinbutton2,FALSE);
     gtk_widget_set_sensitive(radio1,FALSE);
     gtk_widget_set_sensitive(radio2,FALSE);
     gtk_widget_set_sensitive(color_button,FALSE);
     set_widget_fg_color(color_button,bg_red,bg_green,bg_blue);
    }
  else
   { printf("toggle2=INACTIVE\n");
     if (papertype<99)
      { gtk_widget_set_sensitive(optionmenu1,TRUE);
        gtk_widget_set_sensitive(optionmenu2,FALSE);
        gtk_widget_set_sensitive(spinbutton1,FALSE);
        gtk_widget_set_sensitive(spinbutton2,FALSE);
        gtk_widget_set_sensitive(radio1,TRUE);
        gtk_widget_set_sensitive(radio2,TRUE);
	gtk_widget_set_sensitive(color_button,TRUE);
      }
     else
      { gtk_widget_set_sensitive(optionmenu1,TRUE);
        gtk_widget_set_sensitive(optionmenu2,TRUE);
        gtk_widget_set_sensitive(spinbutton1,TRUE);
        gtk_widget_set_sensitive(spinbutton2,TRUE);
        gtk_widget_set_sensitive(radio1,FALSE);
        gtk_widget_set_sensitive(radio2,FALSE);
	gtk_widget_set_sensitive(color_button,TRUE);
      }

   }   
 return(1);
}

void new_page_cancel (GtkWidget *widget, gpointer *data)
{ gtk_widget_destroy(page_dialog);
  page_dialog_busy=FALSE;
  spinbutton1=NULL;
  spinbutton2=NULL;
}

void info_dialog_cancel (GtkWidget *widget, gpointer *data)
{ gtk_widget_destroy(dialog2);
  info_dialog_busy=FALSE;
}

void info_dialog_doc (GtkWidget *widget, gpointer *data)
{ gtk_widget_destroy(dialog2);
  create_new_doc_dialog(NULL,NULL);
  info_dialog_busy=FALSE;
}

void get_spin_value (GtkWidget *widget, gpointer *data)
{ char *buffer;
  GtkEntry *entry;
  GtkSpinButton *spin;

  if (!data) return;
  spin=(GtkSpinButton *)data;
  entry=&((*spin).entry);
  g_return_if_fail (GTK_IS_ENTRY (entry));
  buffer = gtk_entry_get_text(GTK_ENTRY(entry));
  if (data==(gpointer)spinbutton1)
   page_x=atof(buffer);
  else
   page_y=atof(buffer);
}

void new_page_create (GtkWidget *widget, gpointer *data)
{ page_data *page_info, *cpage_info;
  gchar first_page;

  if (!current_doc)
   { info_dialog();
     return;
   }
  
  gtk_signal_disconnect_by_func (GTK_OBJECT (spinbutton2_adj),
                    GTK_SIGNAL_FUNC (get_spin_value), (gpointer)spinbutton2);
  gtk_signal_disconnect_by_func (GTK_OBJECT (spinbutton1_adj),
                    GTK_SIGNAL_FUNC (get_spin_value), (gpointer)spinbutton1);

  if (!page_node)
   { new_page_defaults(current_doc);
     page_node=current_doc->list_children[current_doc->n_children-1];
   }
  page_info=(page_data *)(page_node->node_data);

  page_info->units=paperunits;
  page_info->orientation=orientation;
  if (papertype<99)
   page_info->papertype=papertypes[papertype];
  else
  page_info->papertype=NULL;
  page_info->x_max=page_x;
  page_info->y_max=page_y;
  page_info->bg_color->r=bg_red;
  page_info->bg_color->g=bg_green;
  page_info->bg_color->b=bg_blue;
  page_info->x_max_screen=drawing_area->allocation.width;
  page_info->y_max_screen=drawing_area->allocation.height;
  if (GTK_TOGGLE_BUTTON (checkbutton4)->active || !current_page)
   { if (!current_page) first_page=TRUE;
     else
       { first_page=FALSE;
         cpage_info=(page_data *)(current_page->node_data);
       }

     if (!first_page&&  page_info->x_max==cpage_info->x_max&&
                        page_info->y_max==page_info->y_max)
      { current_page=page_node;
        create_plot(drawing_area,page_info,(double)drawing_area->allocation.width,
                 (double)drawing_area->allocation.height);
        gtk_widget_queue_draw(drawing_area);
      }
     else
      { current_page=page_node;
        drawing_area_configure_event(drawing_area,NULL);
      }
   
   }
  page_node=NULL;
  new_page_cancel(widget,data);
}

int set_widget_fg_color(GtkWidget *widget, guint16 r, guint16 g, guint16 b)
{ int i;
  GdkColor fg_color;
  GdkColormap   *colormap;
  guint32 rgb;

  if (!widget->window ) return;
  rgb=(r&0xff00)*256+(g&0xff00) + b/256;

  for (i=0;i<4;i++)
   { widget->style->fg[i].red=r;
     widget->style->fg[i].green=g;
     widget->style->fg[i].blue=b;
   }
   
  gtk_widget_queue_draw(color_button);
  return(TRUE);
}

void destroy_color_selection (GtkWidget *widget, gpointer *data)
{ gtk_widget_destroy(GTK_WIDGET(colorsel_d));
}

void set_color_selection (GtkWidget *widget, gpointer *data)
{ gdouble col_array[3];
  gtk_color_selection_get_color
   (GTK_COLOR_SELECTION(GTK_COLOR_SELECTION_DIALOG(colorsel_d)->colorsel),
   col_array);  
  bg_red=col_array[0]*0xffff;
  bg_green=col_array[1]*0xffff;
  bg_blue=col_array[2]*0xffff;
  set_widget_fg_color(color_button,bg_red,bg_green,bg_blue);
  gtk_widget_destroy(GTK_WIDGET(colorsel_d));  
}
  
void create_color_selection (GtkWidget *widget, gpointer *data)
{ gdouble col_array[3],temp;

  colorsel_d=gtk_color_selection_dialog_new("fulcrum: Select color");
  temp=bg_red;
  col_array[0]=temp/65535;
  temp=bg_green;
  col_array[1]=temp/65535;
  temp=bg_blue;
  col_array[2]=temp/65535;
  gtk_color_selection_set_color
  (GTK_COLOR_SELECTION(GTK_COLOR_SELECTION_DIALOG(colorsel_d)->colorsel),col_array);
  gtk_signal_connect
  (GTK_OBJECT (GTK_COLOR_SELECTION_DIALOG(colorsel_d)->cancel_button), "clicked",
   GTK_SIGNAL_FUNC (destroy_color_selection),
   NULL);
  gtk_signal_connect
  (GTK_OBJECT (GTK_COLOR_SELECTION_DIALOG(colorsel_d)->ok_button), "clicked",
   GTK_SIGNAL_FUNC (set_color_selection), NULL);

  gtk_widget_show(colorsel_d);
  gtk_widget_hide(GTK_WIDGET(GTK_COLOR_SELECTION_DIALOG(colorsel_d)->help_button)); 
}

GtkWidget* info_dialog ()
{
  GtkWidget *dialog_vbox2;
  GtkWidget *info_label;
  GtkWidget *dialog_action_area2;
  GtkWidget *hbox2;
  GtkWidget *ok_button;
  GtkWidget *cancel_button;

  dialog2 = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (dialog2), "dialog2", dialog2);
  gtk_window_set_title (GTK_WINDOW (dialog2), "fulcrum: Create document?");
  gtk_window_set_policy (GTK_WINDOW (dialog2), TRUE, TRUE, FALSE);
  GTK_WINDOW (dialog2)->type = GTK_WINDOW_DIALOG;
  gtk_window_position (GTK_WINDOW (dialog2), GTK_WIN_POS_MOUSE);
  
  dialog_vbox2 = GTK_DIALOG (dialog2)->vbox;
  gtk_object_set_data (GTK_OBJECT (dialog2), "dialog_vbox2", dialog_vbox2);
  gtk_widget_show (dialog_vbox2);

  info_label = gtk_label_new ("There are no documents to place page in!\n\nCreate one now?");
  gtk_object_set_data (GTK_OBJECT (dialog2), "info_label", info_label);
  gtk_widget_show (info_label);
  gtk_box_pack_start (GTK_BOX (dialog_vbox2), info_label, TRUE, TRUE, 5);
  gtk_misc_set_padding (GTK_MISC (info_label), 10, 10);

  dialog_action_area2 = GTK_DIALOG (dialog2)->action_area;
  gtk_object_set_data (GTK_OBJECT (dialog2), "dialog_action_area2", dialog_action_area2);
  gtk_widget_show (dialog_action_area2);
  gtk_container_border_width (GTK_CONTAINER (dialog_action_area2), 10);

  hbox2 = gtk_hbox_new (FALSE, 0);
  gtk_object_set_data (GTK_OBJECT (dialog2), "hbox2", hbox2);
  gtk_widget_show (hbox2);
  gtk_box_pack_start (GTK_BOX (dialog_action_area2), hbox2, TRUE, TRUE, 0);

  ok_button = gtk_button_new_with_label ("OK");
  gtk_object_set_data (GTK_OBJECT (dialog2), "ok_button", ok_button);
  gtk_widget_show (ok_button);
  gtk_box_pack_start (GTK_BOX (hbox2), ok_button, TRUE, TRUE, 5);
  gtk_signal_connect (GTK_OBJECT (ok_button), "clicked",
                             GTK_SIGNAL_FUNC (info_dialog_doc),
                             NULL);

  cancel_button = gtk_button_new_with_label ("Cancel");
  gtk_object_set_data (GTK_OBJECT (dialog2), "cancel_button", cancel_button);
  gtk_widget_show (cancel_button);
  gtk_box_pack_start (GTK_BOX (hbox2), cancel_button, TRUE, TRUE, 5);
  gtk_signal_connect (GTK_OBJECT (cancel_button), "clicked",
                             GTK_SIGNAL_FUNC (info_dialog_cancel),
                             NULL);
 gtk_widget_show (dialog2);
}


GtkWidget* create_new_page_dialog (GtkWidget *widget, gpointer data)
{
  GtkWidget *dialog_vbox1;
  GtkWidget *table1;
  GtkWidget *label6;
  GtkWidget *label7;
  GtkWidget *label5;
  GtkWidget *optionmenu1_menu;
  GtkWidget *glade_menuitem;
  GtkWidget *optionmenu2_menu;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbox1;
  GtkWidget *button1;
  GtkWidget *button2;
  GtkTooltips *tooltips;
  GSList *rlist;
  GtkStyle *style;

#ifndef GTK_HAVE_GDK_RGB
    gdk_rgb_init ();
#endif

  gtk_widget_set_default_colormap (gdk_rgb_get_cmap ());
  gtk_widget_set_default_visual (gdk_rgb_get_visual ());


  if (page_dialog_busy) return;
  page_node=(fc_node *)data;
  
  page_dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (page_dialog), "page_dialog", page_dialog);
  GTK_WINDOW (page_dialog)->type = GTK_WINDOW_DIALOG;
  if (!page_node)
   gtk_window_set_title (GTK_WINDOW (page_dialog), "fulcrum: New page");
  else
   gtk_window_set_title (GTK_WINDOW (page_dialog), "fulcrum: Edit page");
  gtk_window_set_policy (GTK_WINDOW (page_dialog), TRUE, TRUE, TRUE);
  gtk_window_position (GTK_WINDOW (page_dialog), GTK_WIN_POS_MOUSE);

  tooltips = gtk_tooltips_new ();
  style=gtk_widget_get_style(GTK_WIDGET(page_dialog));
  gtk_tooltips_set_colors( tooltips,
                           &style->light[4],
                           &style->black);
  
  
  dialog_vbox1 = GTK_DIALOG (page_dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (page_dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  table1 = gtk_table_new (4, 4, TRUE);
  gtk_object_set_data (GTK_OBJECT (page_dialog), "table1", table1);
  gtk_widget_show (table1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), table1, TRUE, TRUE, 0);
  gtk_container_border_width (GTK_CONTAINER (table1), 1);
  gtk_table_set_row_spacings (GTK_TABLE (table1), 8);

  color_button = gtk_button_new_with_label("");
  gtk_object_set_data (GTK_OBJECT (page_dialog), "color_button", color_button);

  gtk_widget_show (color_button);
  gtk_signal_connect (GTK_OBJECT (color_button), "clicked",
                             GTK_SIGNAL_FUNC (create_color_selection),
                             NULL);
  
  gtk_table_attach (GTK_TABLE (table1), color_button, 2, 3, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, color_button, "On-screen backgound colour", NULL);
  
  set_widget_fg_color(color_button,bg_red,bg_green,bg_blue);
  label6 = gtk_label_new ("Background colour:");
  gtk_object_set_data (GTK_OBJECT (page_dialog), "label6", label6);
  gtk_widget_show (label6);
  gtk_table_attach (GTK_TABLE (table1), label6, 1, 2, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label6), GTK_JUSTIFY_RIGHT);

  radio1=gtk_radio_button_new_with_label(NULL,"Portrait");
  rlist=gtk_radio_button_group(GTK_RADIO_BUTTON(radio1));
  radio2=gtk_radio_button_new_with_label(rlist,"Landscape");

  gtk_table_attach (GTK_TABLE (table1), radio1, 2, 3, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_table_attach (GTK_TABLE (table1), radio2, 3, 4, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_widget_show (radio1);
  gtk_widget_show (radio2);
  gtk_signal_connect (GTK_OBJECT (radio1), "clicked",
                             GTK_SIGNAL_FUNC (portrait),
                             NULL);
  gtk_signal_connect (GTK_OBJECT (radio2), "clicked",
                             GTK_SIGNAL_FUNC (landscape),
                             NULL);

  checkbutton4 = gtk_check_button_new_with_label ("Switch to this page");
  gtk_object_set_data (GTK_OBJECT (page_dialog), "checkbutton4", checkbutton4);
  gtk_widget_show (checkbutton4);
  gtk_table_attach (GTK_TABLE (table1), checkbutton4, 0, 1, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, checkbutton4, "Switch to this page upon creation", NULL);
  gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (checkbutton4), TRUE);

  label7 = gtk_label_new ("Paper type: ");
  gtk_object_set_data (GTK_OBJECT (page_dialog), "label7", label7);
  gtk_label_set_justify (GTK_LABEL (label7), GTK_JUSTIFY_RIGHT);
  gtk_widget_show (label7);
  gtk_table_attach (GTK_TABLE (table1), label7, 0, 1, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label5 = gtk_label_new ("Width x Height: ");
  gtk_object_set_data (GTK_OBJECT (page_dialog), "label5", label5);
  gtk_label_set_justify (GTK_LABEL (label5), GTK_JUSTIFY_RIGHT);
  gtk_widget_show (label5);
  gtk_table_attach (GTK_TABLE (table1), label5, 0, 1, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  
  spinbutton2_adj = gtk_adjustment_new (page_y, 0, 1000, 0.5, 10, 10);
  gtk_signal_connect (GTK_OBJECT (spinbutton2_adj), "value_changed",
                    GTK_SIGNAL_FUNC (get_spin_value), (gpointer)spinbutton2);
  spinbutton2 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton2_adj), 1, 1);
  gtk_signal_connect (GTK_OBJECT (spinbutton2_adj), "value_changed",
                    GTK_SIGNAL_FUNC (get_spin_value), (gpointer)spinbutton2);
  gtk_object_set_data (GTK_OBJECT (page_dialog), "spinbutton2", spinbutton2);
  gtk_widget_show (spinbutton2);
  gtk_table_attach (GTK_TABLE (table1), spinbutton2, 2, 3, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  GTK_WIDGET_SET_FLAGS (spinbutton2, GTK_CAN_DEFAULT);
  gtk_widget_grab_default (spinbutton2);
  gtk_tooltips_set_tip (tooltips, spinbutton2, "Height", NULL);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spinbutton2), TRUE);
  gtk_spin_button_set_update_policy (GTK_SPIN_BUTTON (spinbutton2), GTK_UPDATE_IF_VALID);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinbutton2), TRUE);

  spinbutton1_adj = gtk_adjustment_new (page_x, 0, 1000, 0.5, 10, 10);
  spinbutton1 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton1_adj), 1, 1);
  gtk_signal_connect (GTK_OBJECT (spinbutton1_adj), "value_changed",
                    GTK_SIGNAL_FUNC (get_spin_value), (gpointer)spinbutton1);

  gtk_object_set_data (GTK_OBJECT (page_dialog), "spinbutton1", spinbutton1);
  gtk_widget_show (spinbutton1);
  gtk_table_attach (GTK_TABLE (table1), spinbutton1, 1, 2, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  GTK_WIDGET_SET_FLAGS (spinbutton1, GTK_CAN_DEFAULT);
  gtk_widget_grab_default (spinbutton1);
  gtk_tooltips_set_tip (tooltips, spinbutton1, "Width", NULL);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spinbutton1), TRUE);
  gtk_spin_button_set_update_policy (GTK_SPIN_BUTTON (spinbutton1), GTK_UPDATE_IF_VALID);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinbutton1), TRUE);

  checkbutton2 = gtk_check_button_new_with_label ("Use defaults (global or inherited)");
  gtk_object_set_data (GTK_OBJECT (page_dialog), "checkbutton2", checkbutton2);
  gtk_widget_show (checkbutton2);
  gtk_table_attach (GTK_TABLE (table1), checkbutton2, 0, 2, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, checkbutton2, "Use papertype defaults or inherit from previous pages", NULL);
  if (!page_node)
   gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (checkbutton2), TRUE);
  else
   gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (checkbutton2), FALSE);

  gtk_signal_connect (GTK_OBJECT (checkbutton2), "clicked",
                             GTK_SIGNAL_FUNC (defaults_toggled),
                             NULL);

  optionmenu1 = gtk_option_menu_new ();
  gtk_object_set_data (GTK_OBJECT (page_dialog), "optionmenu1", optionmenu1);
  gtk_widget_show (optionmenu1);
  gtk_table_attach (GTK_TABLE (table1), optionmenu1, 1, 2, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, optionmenu1, "Paper type", NULL);
  optionmenu1_menu = gtk_menu_new ();
  glade_menuitem = gtk_menu_item_new_with_label ("User defined");
  gtk_widget_show (glade_menuitem);
  gtk_signal_connect( GTK_OBJECT(glade_menuitem), "activate",
                 GTK_SIGNAL_FUNC(pagetype_changed), (gpointer)0);
  gtk_menu_append (GTK_MENU (optionmenu1_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("Letter");
  gtk_widget_show (glade_menuitem);
  gtk_signal_connect( GTK_OBJECT(glade_menuitem), "activate",
                 GTK_SIGNAL_FUNC(pagetype_changed), (gpointer)1);
  gtk_menu_append (GTK_MENU (optionmenu1_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("A4");
  gtk_widget_show (glade_menuitem);
  gtk_signal_connect( GTK_OBJECT(glade_menuitem), "activate",
                 GTK_SIGNAL_FUNC(pagetype_changed), (gpointer)2);
  gtk_menu_append (GTK_MENU (optionmenu1_menu), glade_menuitem);
  gtk_option_menu_set_menu (GTK_OPTION_MENU (optionmenu1), optionmenu1_menu);
  gtk_option_menu_set_history (GTK_OPTION_MENU (optionmenu1), papertype+1);

  optionmenu2 = gtk_option_menu_new ();
  gtk_object_set_data (GTK_OBJECT (page_dialog), "optionmenu2", optionmenu2);
  gtk_widget_show (optionmenu2);
  gtk_table_attach (GTK_TABLE (table1), optionmenu2, 3, 4, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_tooltips_set_tip (tooltips, optionmenu2, "Paper units", NULL);
  optionmenu2_menu = gtk_menu_new ();
  glade_menuitem = gtk_menu_item_new_with_label ("Pixels");
  gtk_widget_show (glade_menuitem);
  gtk_signal_connect( GTK_OBJECT(glade_menuitem), "activate",
                 GTK_SIGNAL_FUNC(units_changed), (gpointer)1);

  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("Points");
  gtk_widget_show (glade_menuitem);
  gtk_signal_connect( GTK_OBJECT(glade_menuitem), "activate",
                 GTK_SIGNAL_FUNC(units_changed), (gpointer)2);

  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("mm");
  gtk_widget_show (glade_menuitem);
  gtk_signal_connect( GTK_OBJECT(glade_menuitem), "activate",
                 GTK_SIGNAL_FUNC(units_changed), (gpointer)3);

  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("cm");
  gtk_signal_connect( GTK_OBJECT(glade_menuitem), "activate",
                 GTK_SIGNAL_FUNC(units_changed), (gpointer)4);
  gtk_widget_show (glade_menuitem);

  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  glade_menuitem = gtk_menu_item_new_with_label ("inches");
  gtk_widget_show (glade_menuitem);
  gtk_signal_connect( GTK_OBJECT(glade_menuitem), "activate",
                 GTK_SIGNAL_FUNC(units_changed), (gpointer)5);

  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
  gtk_option_menu_set_menu (GTK_OPTION_MENU (optionmenu2), optionmenu2_menu);
  gtk_option_menu_set_history (GTK_OPTION_MENU (optionmenu2), paperunits-1);

  dialog_action_area1 = GTK_DIALOG (page_dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (page_dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_object_set_data (GTK_OBJECT (page_dialog), "hbox1", hbox1);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbox1, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label ("OK");
  gtk_object_set_data (GTK_OBJECT (page_dialog), "button1", button1);
  gtk_widget_show (button1);
  gtk_widget_grab_focus (button1);
  gtk_box_pack_start (GTK_BOX (hbox1), button1, TRUE, TRUE, 5);
  gtk_widget_grab_focus (button1);
  gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                             GTK_SIGNAL_FUNC (new_page_create),
                             NULL);

  
  button2 = gtk_button_new_with_label ("Cancel");
  gtk_object_set_data (GTK_OBJECT (page_dialog), "button2", button2);
  gtk_widget_show (button2);
  gtk_box_pack_start (GTK_BOX (hbox1), button2, TRUE, TRUE, 5);
  gtk_signal_connect (GTK_OBJECT (button2), "clicked",
                             GTK_SIGNAL_FUNC (new_page_cancel),
                             NULL);

  if (orientation=PORTRAIT)
    portrait(NULL,NULL);
  else
    landscape(NULL,NULL);

  gtk_widget_show(page_dialog);

  set_dialog_state();
  if (!current_doc)
   info_dialog();
}
