/* This file extracted from the GTK tutorial. */

/* entry.c */
#include <glib.h>
#include <gtk/gtk.h>
#include <gtk/gtkeditable.h>
#include "gtk_mtext.h"
GtkWidget *mtext;
int items=0;

void enter_callback(GtkWidget *widget, GtkMText *mtext)
{ gchar *buffer;
  GtkMTextHistItem *hist_item;
  gint i,len,n,create=FALSE;
  GList *list;
  gpointer pt;
  
  items++;
  buffer=gtk_editable_get_chars(GTK_EDITABLE(mtext), mtext->prompt_index,-1);
  if (!buffer) return;
  n=g_list_length(mtext->history)-1;
  len=strlen(buffer);
  if (len>0)
   {hist_item=NULL;
    if (n>0)
     { pt=(g_list_nth (mtext->history, n))->data;
       hist_item=(GtkMTextHistItem *)pt;
     }
    if (hist_item==NULL || n==0 || hist_item->len>0)
     { hist_item=(GtkMTextHistItem *) g_malloc(sizeof(GtkMTextHistItem));
       create=TRUE;
     }
    if (hist_item)
     { hist_item->entry=buffer;
       hist_item->len=strlen(buffer);
       if (create==TRUE)
        list=g_list_append(mtext->history,(gpointer *) hist_item);
       len=g_list_length(mtext->history);
       mtext->hist_mark=len-1;
     }
   }
    gtk_mtext_set_point(GTK_MTEXT(mtext),gtk_mtext_get_length(mtext));
    gtk_mtext_insert(GTK_MTEXT(mtext),NULL,NULL,NULL,"\n",2);

    gtk_mtext_insert(GTK_MTEXT(mtext),NULL,NULL,NULL,"Some Output\n",-1);

    gtk_mtext_insert(GTK_MTEXT(mtext),NULL,NULL,NULL,GTK_MTEXT(mtext)->prompt,GTK_MTEXT(mtext)->prompt_len);
    mtext->prompt_index=gtk_mtext_get_point(mtext);

    items=n;
    if (items>3)
      gtk_mtext_remove_hist_n(GTK_MTEXT(mtext), 1);
}

/* our callback.
 * the data passed to this function is printed to stdout */
void callback (GtkWidget *widget, gpointer *data)
{
    gtk_mtext_change_prompt(GTK_MTEXT(mtext), (gchar *)data,
                            strlen((gchar *)data));
    gtk_mtext_clear_input(GTK_MTEXT(mtext));
    gtk_mtext_show_history_item(GTK_MTEXT(mtext),2);
}

/* this callback quits the program */
void delete_event (GtkWidget *widget, GdkEvent *event, gpointer *data)
{
    gtk_main_quit ();
}


int main (int argc, char *argv[])
{   guint i;

    GtkWidget *window;
    GtkWidget *vbox, *hbox, *vscrollbar, *table, *table2;
    
    GtkWidget *button;
    GtkWidget *check;

    gtk_init (&argc, &argv);

    /* create a new window */
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_usize( GTK_WIDGET (window), 200, 100);
    gtk_window_set_title(GTK_WINDOW (window), "GTK Entry");
    gtk_signal_connect(GTK_OBJECT (window), "delete_event",
                       (GtkSignalFunc) gtk_exit, NULL);
    /* create a 2x2 table */
    table = gtk_table_new (2,3,FALSE);

    /* put the table in the main window */
    gtk_container_add (GTK_CONTAINER (window), table);
    table2 = gtk_table_new (2,1,FALSE);

    
    mtext = gtk_mtext_new (NULL,NULL);
    gtk_widget_set_usize( GTK_WIDGET (mtext), 20, 10);
    gtk_signal_connect(GTK_OBJECT(mtext), "activate",
		       GTK_SIGNAL_FUNC(enter_callback),
		       GTK_MTEXT(mtext));
    gtk_mtext_set_editable (GTK_MTEXT (mtext), TRUE);
    gtk_mtext_set_word_wrap (GTK_MTEXT (mtext), TRUE);

    gtk_table_attach (GTK_TABLE(table2), mtext, 0, 1, 0, 1,
                      GTK_FILL | GTK_EXPAND | GTK_SHRINK,
                      GTK_FILL | GTK_EXPAND | GTK_SHRINK,0,0);

    vscrollbar = gtk_vscrollbar_new (GTK_MTEXT(mtext)->vadj);
    gtk_table_attach (GTK_TABLE(table2), vscrollbar, 1, 2, 0, 1,
                               GTK_FILL,
                               GTK_FILL,0,0);

    
    gtk_widget_show (mtext);
    gtk_widget_show (vscrollbar);

    gtk_table_attach (GTK_TABLE(table), table2, 0, 2, 2, 3,
                      GTK_FILL | GTK_EXPAND | GTK_SHRINK,
                      GTK_FILL | GTK_EXPAND | GTK_SHRINK,0,0);

    gtk_widget_show (table2);

    gtk_widget_realize(mtext);
    gtk_mtext_set_prompt(GTK_MTEXT(mtext),"> ",2);
    gtk_mtext_set_point(GTK_MTEXT(mtext),0);
    gtk_mtext_insert(GTK_MTEXT(mtext),NULL,NULL,NULL,GTK_MTEXT(mtext)->prompt,GTK_MTEXT(mtext)->prompt_len);
    gtk_mtext_set_point(GTK_MTEXT(mtext),GTK_MTEXT(mtext)->prompt_len);
    GTK_MTEXT(mtext)->prompt_index=GTK_MTEXT(mtext)->prompt_len;/*GTK_MTEXT_INDEX(GTK_MTEXT(mtext),GTK_MTEXT(mtext)->prompt_len);*/
    
/*    for (i=0;i<20;i++)
      gtk_mtext_insert_before_prompt(GTK_MTEXT(mtext),NULL,NULL,NULL,"0123456789\n",-1);*/


    /* create first button */
    button = gtk_button_new_with_label ("button 1");

    /* when the button is clicked, we call the "callback" function
     * with a pointer to "button 1" as it's argument */
    gtk_signal_connect (GTK_OBJECT (button), "clicked",
              GTK_SIGNAL_FUNC (callback), (gpointer) "button 1 > ");


    /* insert button 1 into the upper left quadrant of the table */
    gtk_table_attach (GTK_TABLE(table), button, 0, 1, 0, 1,
                              GTK_FILL,
                              GTK_FILL,0,0);

    gtk_widget_show (button);

    /* create second button */

    button = gtk_button_new_with_label ("button 2");

    /* when the button is clicked, we call the "callback" function
     * with a pointer to "button 2" as it's argument */
    gtk_signal_connect (GTK_OBJECT (button), "clicked",
              GTK_SIGNAL_FUNC (callback), (gpointer) "button 2 > ");
    /* insert button 2 into the upper right quadrant of the table */
    gtk_table_attach (GTK_TABLE(table), button, 1, 2, 0, 1,
                               GTK_FILL,
                               GTK_FILL,0,0);

    gtk_widget_show (button);

    /* create "Quit" button */
    button = gtk_button_new_with_label ("Quit");

    /* when the button is clicked, we call the "delete_event" function
     * and the program exits */
    gtk_signal_connect (GTK_OBJECT (button), "clicked",
                        GTK_SIGNAL_FUNC (delete_event), NULL);

    /* insert the quit button into the both 
     * lower quadrants of the table */
    gtk_table_attach(GTK_TABLE(table), button, 0, 2, 1, 2,
                               GTK_FILL,
                               GTK_FILL,0,0);

    gtk_widget_show (button);

    gtk_widget_show (table);

    
    gtk_widget_show(window);

    gtk_main();
    return(0);
}
