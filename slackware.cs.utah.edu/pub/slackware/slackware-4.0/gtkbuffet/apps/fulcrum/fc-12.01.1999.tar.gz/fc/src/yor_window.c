/* In this file you will find all the functions and data for the window that
   handles the I/O of the yorick interpreter.
*/

#include <glib.h>
#include <gtk/gtk.h>
#include <gtk/gtkeditable.h>
#include "gtk_mtext.h"
#include <string.h>

GtkWidget *mtext;
gint items=0,filedes[2], fc_input=0,fc_gui=TRUE;
char iobuf[100], *fc_input_buf, yor_init=TRUE, fc_yor_busy=0;
extern int yPendingIn;
gint fc_input_received=0,fc_init=1,fc_err_wait=0,yor_tag=0;
extern gint fc_idle_add(char *busy_flag);

gint yor_update(gpointer data)
{
 gtk_widget_queue_draw(mtext);
}

void enter_callback(GtkWidget *widget, GtkMText *mtext)
{ char *buffer;
  GtkMTextHistItem *hist_item;
  gint i,len,n,create=FALSE;
  GList *list;
  gpointer pt;

if (!yor_init)
{ items++;
  buffer=gtk_editable_get_chars(GTK_EDITABLE(mtext), mtext->prompt_index,-1);
  (char *)fc_input_buf=strdup((char *)buffer);
  if (!buffer) return;
  n=g_list_length(mtext->history)-1;
  fc_input=len=strlen(buffer);
  /* Signal yorick that there is some input to process */
  yPendingIn=1;
  if (len>0)
   {hist_item=NULL;
    if (n>0)
     { pt=(g_list_nth (mtext->history, n))->data;
       hist_item=(GtkMTextHistItem *)pt;
     }
    if (hist_item==NULL || n==0 || hist_item->len>0)
     { hist_item=(GtkMTextHistItem *) g_malloc(sizeof(GtkMTextHistItem));
       create=TRUE;
     }
    if (hist_item)
     { hist_item->entry=buffer;
       hist_item->len=strlen(buffer);
       if (create==TRUE)
        list=g_list_append(mtext->history,(gpointer *) hist_item);
       len=g_list_length(mtext->history);
       mtext->hist_mark=len-1;
     }
   }

    items=n;
    if (items>10)
      gtk_mtext_remove_hist_n(GTK_MTEXT(mtext), 1);
}
    fc_input_received=1;
    if (!yor_init)
     fc_fputs_dumb("\n");
    yor_init=FALSE;

    gtk_mtext_freeze(mtext);
    fc_idle_add (&fc_yor_busy);
    yor_tag=gtk_timeout_add(250,yor_update,NULL);
}

int fc_put_prompt(void)
{  gtk_mtext_thaw(GTK_MTEXT(mtext));
   gtk_mtext_insert(GTK_MTEXT(mtext),NULL,NULL,NULL,GTK_MTEXT(mtext)->prompt,GTK_MTEXT(mtext)->prompt_len);
   GTK_MTEXT(mtext)->prompt_index=gtk_mtext_get_point(GTK_MTEXT(mtext));
   GTK_MTEXT(mtext)->cursor_mark.index=GTK_MTEXT(mtext)->prompt_index;
   GTK_EDITABLE (mtext)->current_pos = GTK_MTEXT(mtext)->cursor_mark.index;
  return(0);
}


int fc_fputs_dumb(const char *string)
{  gtk_mtext_set_point(GTK_MTEXT(mtext),gtk_mtext_get_length(GTK_MTEXT(mtext)));
   gtk_mtext_insert(GTK_MTEXT(mtext),NULL,NULL,NULL,(char *)string,strlen((char *)string));

return(0);
}

int fc_fputs_prompt(const char *string)
{ gint len;
  double upper;
  len=strlen(string);
  gtk_mtext_set_point(GTK_MTEXT(mtext),gtk_mtext_get_length(GTK_MTEXT(mtext)));
   if (!strcmp(string,GTK_MTEXT(mtext)->prompt)) /* unchanged prompt */
    { gtk_mtext_insert(GTK_MTEXT(mtext),NULL,NULL,NULL,GTK_MTEXT(mtext)->prompt,GTK_MTEXT(mtext)->prompt_len);
      GTK_MTEXT(mtext)->prompt_index=gtk_mtext_get_point(GTK_MTEXT(mtext));
    }
   else
    { gtk_mtext_set_prompt(GTK_MTEXT(mtext),
      (char *)string, strlen((char *)string));
      gtk_mtext_insert(GTK_MTEXT(mtext),NULL,NULL,NULL,GTK_MTEXT(mtext)->prompt,GTK_MTEXT(mtext)->prompt_len);
      GTK_MTEXT(mtext)->prompt_index=gtk_mtext_get_point(GTK_MTEXT(mtext));
    }
  GTK_MTEXT(mtext)->cursor_mark.index=GTK_MTEXT(mtext)->prompt_index;
  GTK_EDITABLE (mtext)->current_pos = GTK_MTEXT(mtext)->cursor_mark.index;
  
  gtk_timeout_remove(yor_tag);
  gtk_mtext_thaw(GTK_MTEXT(mtext));
  gtk_mtext_scroll_bottom(GTK_MTEXT(mtext));
  fc_yor_busy=FALSE;
  yor_init=FALSE;
return(len);
}

int fc_init_text_win(GtkWidget *vpane1)
{ GtkWidget *vscrollbar,*table;

    table = gtk_table_new (2,1,FALSE);
    mtext = gtk_mtext_new (NULL,NULL);

    gtk_widget_set_usize( GTK_WIDGET (mtext), 20, 10);
    gtk_signal_connect(GTK_OBJECT(mtext), "activate",
		       GTK_SIGNAL_FUNC(enter_callback),
		       GTK_MTEXT(mtext));
    gtk_mtext_set_editable (GTK_MTEXT (mtext), TRUE);
    gtk_mtext_set_word_wrap (GTK_MTEXT (mtext), TRUE);

    gtk_table_attach (GTK_TABLE(table), mtext, 0, 1, 0, 1,
                      GTK_FILL | GTK_SHRINK|GTK_EXPAND,
                      GTK_FILL | GTK_SHRINK|GTK_EXPAND,0,0);

    vscrollbar = gtk_vscrollbar_new (GTK_MTEXT(mtext)->vadj);
    gtk_table_attach (GTK_TABLE(table), vscrollbar, 1, 2, 0, 1,
                               GTK_FILL,
                               GTK_FILL,0,0);
    gtk_widget_show (mtext);
    gtk_widget_show (vscrollbar);
    gtk_paned_add2(GTK_PANED(vpane1),table);
    gtk_widget_show(table);
    gtk_widget_realize(mtext);
    gtk_mtext_set_prompt(GTK_MTEXT(mtext),"> ",2);   
    enter_callback(mtext, GTK_MTEXT(mtext));
    return(1);
}
