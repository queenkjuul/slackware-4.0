/* xy_2d.h prototypes for functions to create/destroy/modify xy_2d objects */

extern double unit_to_page[5], cur_sys_hor_m, cur_sys_hor_c, 
                               cur_sys_ver_m, cur_sys_ver_c;


fc_node *new_xy_2d_node(fc_node *mother);
gint fc_destroy_2d(fc_node *xy_node);

gint xy_set_marker_text(fc_node *xy_node, gchar *text);
gint xy_unset_flag(fc_node *xy_node, guint32 flag);
gint xy_set_flag(fc_node *xy_node, guint32 flag);
gint xy_set_precmd(fc_node *xy_node, gchar *precmd);
gint xy_set_postcmd(fc_node *xy_node, gchar *postcmd);
gint xy_set_var(fc_node *xy_node, gchar which, gchar *var);
gint xy_set_var_func(fc_node *xy_node, gchar which, gchar *func);
gint xy_resolve_yor_funcs(fc_node *xy_node);

gint xy_preproc_points(double *x_points, double *y_points,
                       gint num_elems, gint *n_pe, gint *pe,
		       guint32 logx, guint32 logy,
		       double minx, double maxx, double miny, double maxy);
gint xy_render_final(xy_2d *xy_info,double *x_points,double *y_points,
                     gint n_pe,gint *xy_indices,guint32 logx, guint32 logy);
gint xy_render(fc_node *xy_node,guint32 logx, guint32 logy,
               double minx, double maxx, double miny, double maxy);
	       

