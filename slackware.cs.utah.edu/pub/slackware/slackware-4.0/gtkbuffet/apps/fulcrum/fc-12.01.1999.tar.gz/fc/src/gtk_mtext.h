/* GTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
#ifndef __GTK_MTEXT_H__
#define __GTK_MTEXT_H__


#include <gdk/gdk.h>
#include <gtk/gtkadjustment.h>
#include <gtk/gtkeditable.h>
#include <glib.h>
/*#include <gtk/gtktext.h>*/
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define GTK_MTEXT(obj)          GTK_CHECK_CAST (obj, gtk_mtext_get_type (), GtkMText)
#define GTK_MTEXT_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, gtk_mtext_get_type (), GtkMTextClass)
#define GTK_IS_MTEXT(obj)       GTK_CHECK_TYPE (obj, gtk_mtext_get_type ())

typedef struct _GtkMPropertyMark   GtkMPropertyMark;
typedef struct _GtkMText           GtkMText;
typedef struct _GtkMTextClass      GtkMTextClass;
typedef struct _GtkMTextHistItem   GtkMTextHistItem;


struct _GtkMPropertyMark
{
  /* Position in list. */
  GList* property;

  /* Offset into that property. */
  guint offset;

  /* Current index. */
  guint index;
}; 



struct _GtkMText
{
  GtkEditable editable;

  GdkWindow *text_area;

  GtkAdjustment *hadj;
  GtkAdjustment *vadj;

  GdkGC *gc;

  GdkPixmap* line_wrap_bitmap;
  GdkPixmap* line_arrow_bitmap;

		      /* GAPPED TEXT SEGMENT */

  /* The text, a single segment of text a'la emacs, with a gap
   * where insertion occurs. */
  guchar* text;
  /* The allocated length of the text segment. */
  guint text_len;
  /* The gap position, index into address where a char
   * should be inserted. */
  guint gap_position;
  /* The gap size, s.t. *(text + gap_position + gap_size) is
   * the first valid character following the gap. */
  guint gap_size;
  /* The last character position, index into address where a
   * character should be appeneded.  Thus, text_end - gap_size
   * is the length of the actual data. */
  guint text_end;
			/* LINE START CACHE */

  /* A cache of line-start information.  Data is a LineParam*. */
  GList *line_start_cache;
  /* Index to the start of the first visible line. */
  guint first_line_start_index;
  /* The number of pixels cut off of the top line. */
  guint first_cut_pixels;
  /* First visible horizontal pixel. */
  guint first_onscreen_hor_pixel;
  /* First visible vertical pixel. */
 guint first_onscreen_ver_pixel;

			     /* FLAGS */

  /* True iff the cursor has been placed yet. */
  guint has_cursor : 1;
  /* True iff this buffer is wrapping lines, otherwise it is using a
   * horizontal scrollbar. */
  guint line_wrap : 1;
  /* Frozen, don't do updates. @@@ fixme */
  guint freeze : 1;
  guint word_wrap : 1;

			/* TEXT PROPERTIES */

  /* A doubly-linked-list containing TextProperty objects. */
  GList *text_properties;
  /* The end of this list. */
  GList *text_properties_end;
  /* The first node before or on the point along with its offset to
   * the point and the buffer's current point.  This is the only
   * PropertyMark whose index is guaranteed to remain correct
   * following a buffer insertion or deletion. */
  GtkMPropertyMark point;

			  /* SCRATCH AREA */

  guchar* scratch_buffer;
  guint   scratch_buffer_len;

			  /* PROMPT */

  guchar* prompt;
  guint   prompt_len;
  guint   prompt_index;        /* Where it is in the buffer. */
  GList*  history;
  guint   hist_mark;
  
			   /* SCROLLING */

  gint last_ver_value;

			     /* CURSOR */

  gint            cursor_pos_x;       /* Position of cursor. */
  gint            cursor_pos_y;       /* Baseline of line cursor is drawn on. */
  GtkMPropertyMark cursor_mark;        /* Where it is in the buffer. */
  gchar           cursor_char;        /* Character to redraw. */
  gchar           cursor_char_offset; /* Distance from baseline of the font. */
  gint            cursor_virtual_x;   /* Where it would be if it could be. */
  gint            cursor_drawn_level; /* How many people have undrawn. */

			  /* Current Line */

  GList *current_line;

			   /* Tab Stops */

  GList *tab_stops;
  gint default_tab_width;

  /* Timer used for auto-scrolling off ends */
  gint timer;
  
  guint button;			/* currently pressed mouse button */
};

struct _GtkMTextClass
{
  GtkEditableClass parent_class;
};

struct _GtkMTextHistItem
{   gint              len;
    gchar            *entry;
};


guint      gtk_mtext_get_type        (void);
GtkWidget* gtk_mtext_new             (GtkAdjustment *hadj,
				     GtkAdjustment *vadj);
void       gtk_mtext_set_editable    (GtkMText       *text,
				     gint           editable);
void       gtk_mtext_set_word_wrap   (GtkMText       *text,
				     gint           word_wrap);
void       gtk_mtext_set_adjustments (GtkMText       *text,
				     GtkAdjustment *hadj,
				     GtkAdjustment *vadj);
void       gtk_mtext_set_point       (GtkMText       *text,
				     guint          index);
guint      gtk_mtext_get_point       (GtkMText       *text);
guint      gtk_mtext_get_length      (GtkMText       *text);
void       gtk_mtext_freeze          (GtkMText       *text);
void       gtk_mtext_thaw            (GtkMText       *text);
void       gtk_mtext_insert          (GtkMText       *text,
				     GdkFont       *font,
				     GdkColor      *fore,
				     GdkColor      *back,
				     const char    *chars,
				     gint           length);
static void gtk_mtext_insert_1_at_point (GtkMText* text, gchar key);
gint       gtk_mtext_backward_delete (GtkMText       *text,
				     guint          nchars);
gint       gtk_mtext_forward_delete  (GtkMText       *text,
				     guint          nchars);
void gtk_mtext_set_prompt (GtkMText *text,
                      gchar    *prompt,
                      guint    len);
guint gtk_mtext_remove_hist_n(GtkMText *text, guint number);
gint gtk_mtext_clear_input(GtkMText *text);
gint gtk_mtext_show_history_item(GtkMText *text,guint item);
void gtk_mtext_append_input_to_history(GtkMText *text);
void gtk_mtext_scroll_bottom (GtkMText* text);

#define GTK_MTEXT_INDEX(t, index)  \
      ((index) < (t)->gap_position ? (t)->text[index] : \
                                     (t)->text[(index) + (t)->gap_size])

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __GTK_MTEXT_H__ */
