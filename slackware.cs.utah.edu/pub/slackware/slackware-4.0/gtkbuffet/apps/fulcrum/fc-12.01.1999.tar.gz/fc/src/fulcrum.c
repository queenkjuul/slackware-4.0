/* Fulcrum main initilization file */

#include <glib.h>
#include <gtk/gtk.h>
#include <gtk/gtkeditable.h>
#include "gtk_mtext.h"
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "plot.h"
#include "gdkprivate.h"
#include "object_tree.h"
#include "render_page.h"

extern GtkWidget *graph_label;
extern char fc_render_busy, fc_yor_busy;
char fc_idle_busy=0;
char *yor_command=NULL;
gint fulcrum_tag=0,fc_run=0;
int g_render_page(void);
extern void YMainLoop(void);

double page_magn=0.5,screen_dpi=100; /* 50% magnification */

gint fc_idle_calback(gpointer data);

gint fc_idle_add(char *busy_flag)
{ *busy_flag=TRUE;
  if (!fc_idle_busy)
   { fulcrum_tag=gtk_idle_add(fc_idle_calback,NULL);
     fc_idle_busy=TRUE;
   }
}
       

/* Wrapper that calls Yorick event loop that processes any input and/or
unfinished instructions */
gint fc_idle_calback(gpointer data)
{
  if (fc_render_busy) /* the page is being rendered */
    g_render_page();


  if (fc_yor_busy) /* yorick interpreter is busy */ 
   CheckForTasks(1);
   
  if (!fc_render_busy && !fc_yor_busy)
   { gtk_idle_remove(fulcrum_tag);
     fc_idle_busy=FALSE;
   }
  return(TRUE);
}


/* our callback.
 * the data passed to this function is printed to stdout */
void callback (GtkWidget *widget, gpointer *data)
{
/*    gtk_mtext_change_prompt(GTK_MTEXT(mtext), (char *)data,
                            strlen((char *)data));
    gtk_mtext_clear_input(GTK_MTEXT(mtext));
    gtk_mtext_show_history_item(GTK_MTEXT(mtext),2);*/
}


/* this callback quits the program */
void fc_main_exit (GtkWidget *widget, GdkEvent *event, gpointer *data)
{
/*    yor_command=strdup("write,10.0,format=\"Printing number %2.3e\\n\"");
    do {} while (CheckForTasks(1));
    return;*/
    YMainLoop(); /* quit yorick interpreter*/
    gtk_main_quit ();
}


int fulcrum (int argc, char **argv)
{   guint i;
    char i_buffer[]="Initilizing...";
    GtkWidget *window, *table, *table2, *hpane1, *hpane2, *notebook;
    GtkWidget *button;
    GtkWidget *check;
    GdkVisual *visual;
    
    gtk_set_locale ();
    gtk_init (&argc, &argv);
    
  /* create a new window */
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_usize( GTK_WIDGET (window), 450, 200);
    gtk_window_set_title(GTK_WINDOW (window), "fulcrum");
    gtk_signal_connect(GTK_OBJECT (window), "delete_event",
                       (GtkSignalFunc) fc_main_exit, NULL);
    gtk_widget_realize(window);
    /* create a 2x2 table */
    table = gtk_table_new (2,2,FALSE);
    table2 = gtk_table_new (1,1,FALSE);

    /* put the table in the main window*/
    gtk_container_add (GTK_CONTAINER (window), table);

    hpane1=gtk_hpaned_new();
    hpane2=gtk_hpaned_new();
    gtk_paned_add2(GTK_PANED(hpane2),hpane1);
    gtk_table_attach(GTK_TABLE(table), hpane2, 0,1,1,2,
                   GTK_FILL|GTK_EXPAND|GTK_SHRINK,
                   GTK_FILL|GTK_EXPAND|GTK_SHRINK,0,0);

    notebook=gtk_notebook_new();
    gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook),GTK_POS_TOP);
    gtk_table_attach(GTK_TABLE(table2), notebook, 0, 1, 0, 1,
                               GTK_FILL|GTK_EXPAND|GTK_SHRINK,
                               GTK_FILL|GTK_EXPAND|GTK_SHRINK,0,0);

    gtk_paned_add1(GTK_PANED(hpane1),table2);
    gtk_notebook_set_show_tabs(GTK_NOTEBOOK(notebook),TRUE);

    fc_init_tree_win(hpane2,window);
    fc_init_graph_win(notebook);
/*    fc_init_sheet_win(notebook); */
    fc_init_text_win(hpane1);
    fc_init_menu(table,window);
    gtk_widget_show (hpane1);
    gtk_widget_show (hpane2);
    gtk_widget_show (table);
    gtk_widget_show (table2);
    gtk_widget_show (notebook);
    gtk_widget_show (window);
    gtk_main();
    return(0);
}
