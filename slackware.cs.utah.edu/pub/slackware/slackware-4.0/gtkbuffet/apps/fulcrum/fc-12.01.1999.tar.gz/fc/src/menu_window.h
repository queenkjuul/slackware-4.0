#include <gtk/gtk.h>
typedef struct _fc_menu_struct
{ guint num,npix;
  gchar *lname,*rname;
  guint key, mask;
  gpointer callback, data, sub_menu, parent;
  GtkWidget *widget, *menu;
} fc_menu_struct;
