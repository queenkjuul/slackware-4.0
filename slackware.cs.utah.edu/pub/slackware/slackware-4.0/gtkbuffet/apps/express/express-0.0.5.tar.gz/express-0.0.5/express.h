#ifndef __EXPRESS_H__
#define __EXPRESS_H__

#include <gtk/gtk.h>
#include "bwindow.h"

#ifdef MULTIPLE_BROWSERS
typedef struct _browser_list {
  struct _browser_list *next;
  GtkWidget *browser;
} browser_list;

#define for_each_browser(b) \
  for(b=ak->browsers;b->next;b=b->next)

#endif

/*
 * AppKernel internal data
 */
typedef struct _app_kernel {
#ifdef MULTIPLE_BROWSERS
  gint num_browsers;
  browser_list *browsers;
#else
  GtkWidget *browser;
#endif
} app_kernel;

void express_init_app_kernel();
GtkWidget *express_new_browser();
GtkWidget *express_clone_browser(BWindow *b);
void express_close_browser(BWindow *b);
int cleanexit(int returncode);


#endif /* __EXPRESS_H__ */
