#include <stdio.h>
#include <stdlib.h>


void *pmalloc(size_t size, char *desc)
{
  void *ret;

  if((ret=malloc(size)) == NULL) {
    perror(desc);
  }

  return(ret);
}

