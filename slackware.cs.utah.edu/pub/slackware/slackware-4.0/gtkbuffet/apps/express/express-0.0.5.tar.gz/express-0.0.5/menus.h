#ifndef __MENUS_H__
#define __MENUS_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "bwindow.h"

GtkWidget *bwindow_get_menu_bar(BWindow *bwindow);
#if 0
void get_main_menu (BWindow *bwindow, GtkWidget **menubar, GtkAcceleratorTable **table);
void menus_create(BWindow *bwindow, GtkMenuEntry *entries, int nmenu_entries);
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __MENUS_H__ */

