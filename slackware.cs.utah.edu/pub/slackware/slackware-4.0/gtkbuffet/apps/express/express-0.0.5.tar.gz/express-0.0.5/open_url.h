#ifndef __OPEN_URL_H__
#define __OPEN_URL_H__

URL *open_url(BWindow *bwindow, char *url);

#endif /* __OPEN_URL_H__ */
