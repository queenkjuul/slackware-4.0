#ifndef __MENU_CALLBACKS_H__
#define __MENU_CALLBACKS_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define CMD_LEN 256

void bwindow_back_callback(GtkWidget *widget, gpointer data);
void bwindow_forward_callback(GtkWidget *widget, gpointer data);
void bwindow_home_callback(GtkWidget *widget, gpointer data);
void bwindow_reload_callback(GtkWidget *widget, gpointer data);
void bwindow_view_src_callback(GtkWidget *widget, gpointer data);
void bwindow_pipe_callback(GtkWidget *widget, gpointer data);
void bwindow_saveas_callback(GtkWidget *widget, gpointer data);
void bwindow_browse_callback(GtkWidget *widget, gpointer data);
void bwindow_edit_callback(GtkWidget *widget, gpointer data);
void file_newbrowser_callback(GtkWidget *widget, gpointer data);
void file_close_cmd_callback(GtkWidget *widget, gpointer data);
void file_quit_cmd_callback(GtkWidget *widget, gpointer data);
void bwindow_toolbar_icons(GtkWidget *widget, gpointer data);
void bwindow_toolbar_text(GtkWidget *widget, gpointer data);
void bwindow_toolbar_both(GtkWidget *widget, gpointer data);
void gtk_xmhtml_click(GtkWidget *widget, gpointer data);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __MENU_CALLBACKS_H__ */

