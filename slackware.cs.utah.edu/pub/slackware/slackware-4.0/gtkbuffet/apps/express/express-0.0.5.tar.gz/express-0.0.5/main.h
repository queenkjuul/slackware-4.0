#ifndef __MAIN_H__
#define __MAIN_H__

/* maybe one day there'll be stuff here again... */

#endif /* __MAIN_H__ */
