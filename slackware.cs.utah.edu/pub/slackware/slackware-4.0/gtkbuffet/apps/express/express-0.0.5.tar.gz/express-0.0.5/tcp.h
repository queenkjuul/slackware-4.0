#ifndef __TCP_H__
#define __TCP_H__

/*
 * connectsock - allocate & connect a socket using TCP or UDP
 */
int connectsock(char *host, char *service, char *protocol);

/*
 * connectsockproto - allocate & connect a socket using TCP or UDP
 * using known port number
 */
int connectsockproto(char *host, int proto, char *protocol);

int connectTCP(char *host, char *service);

int connectTCPproto(char *host, int proto);

#endif  /* __TCP_H__ */
