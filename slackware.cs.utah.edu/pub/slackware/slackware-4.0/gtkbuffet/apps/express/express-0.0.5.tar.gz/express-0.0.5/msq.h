#ifndef __MSQ_H__
#define __MSQ_H__

#include <gtk/gtk.h>
#include "bwindow.h"

enum {
  MSQ_UNUSED,   /* unused */
  MSQ_STATUS,  /* message for status line */
  MSQ_DATA     /* data ready */
};

int msq_snd_init(void);
void msq_snd(int snd_msqid, BWindow *bwindow, char *mtext);
void msq_rcv_init(void);
void msq_rcv_check(gpointer data);

#endif  /* __MSQ_H__ */
