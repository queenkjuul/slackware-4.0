#ifndef __ALERTS_H__
#define __ALERTS_H__

#include <gdk/gdk.h>
#include <gtk/gtkdialog.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void make_alert(GtkWidget *w, gpointer data);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __ALERTS_H__ */
