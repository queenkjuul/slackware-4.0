#include <gtk/gtk.h>
#include <strings.h>

#include "menus.h"
#include "bwindow.h"
#include "bwindow_callbacks.h"
#include "alerts.h"

#if 0
static void menus_remove_accel(BWindow *bwindow, GtkWidget * widget, gchar * signal_name, gchar * path);
static gint menus_install_accel(BWindow *bwindow, GtkWidget * widget, gchar * signal_name, gchar key, gchar modifiers, gchar * path);
#endif

void menus_init(BWindow *bwindow);
void menus_create(BWindow *bwindow, GtkMenuEntry * entries, int nmenu_entries);


GtkWidget *bwindow_get_menu_bar(BWindow *bwindow)
{
  GtkWidget *menu;
  GtkWidget *menu_bar;
  GtkWidget *root_menu;
  GtkWidget *menu_items;
#if 0
  char buf[128];
  int i;
#endif
  
  menu_bar = gtk_menu_bar_new();
  gtk_widget_show(menu_bar);

  menu = gtk_menu_new();
  root_menu = gtk_menu_item_new_with_label("File");
  gtk_widget_show(root_menu);

#ifdef MULTIPLE_BROWSERS
  menu_items = gtk_menu_item_new_with_label("New Web Browser");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(file_newbrowser_callback), bwindow);
  gtk_widget_show(menu_items);
#endif
  
#ifdef SUCK
  menu_items = gtk_menu_item_new_with_label("Open Location...");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
#endif
  
  menu_items = gtk_menu_item_new_with_label("Open File...");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(bwindow_browse_callback), bwindow);
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Save As...");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(bwindow_saveas_callback), bwindow);
  gtk_widget_show(menu_items);
  
#ifdef MULTIPLE_BROWSERS
  menu_items = gtk_menu_item_new_with_label("Close");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(file_close_cmd_callback), bwindow);
  gtk_widget_show(menu_items);
#endif
  
  menu_items = gtk_menu_item_new_with_label("Exit");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(file_quit_cmd_callback), bwindow);
  gtk_widget_show(menu_items);
  
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(root_menu), menu);
  gtk_menu_bar_append(GTK_MENU_BAR(menu_bar), root_menu);


  menu = gtk_menu_new();
  root_menu = gtk_menu_item_new_with_label("Edit");
  gtk_widget_show(root_menu);

  menu_items = gtk_menu_item_new_with_label("Undo");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Cut");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  

  menu_items = gtk_menu_item_new_with_label("Copy");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Paste");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Find");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Find Again");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(root_menu), menu);
  gtk_menu_bar_append(GTK_MENU_BAR(menu_bar), root_menu);


  menu = gtk_menu_new();
  root_menu = gtk_menu_item_new_with_label("View");
  gtk_widget_show(root_menu);

  menu_items = gtk_menu_item_new_with_label("Reload");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(bwindow_reload_callback), bwindow);
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Refresh");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Document Source");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(bwindow_view_src_callback), bwindow);
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Document Info");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(root_menu), menu);
  gtk_menu_bar_append(GTK_MENU_BAR(menu_bar), root_menu);

  menu = gtk_menu_new();
  root_menu = gtk_menu_item_new_with_label("Go");
  gtk_widget_show(root_menu);

  bwindow->backmenu = gtk_menu_item_new_with_label("Back");
  gtk_widget_set_sensitive(GTK_WIDGET(bwindow->backmenu), FALSE);
  gtk_menu_append(GTK_MENU (menu), bwindow->backmenu);
  gtk_signal_connect(GTK_OBJECT(bwindow->backmenu), "activate",
      GTK_SIGNAL_FUNC(bwindow_back_callback), bwindow);
  gtk_widget_show(bwindow->backmenu);
  
  bwindow->forwardmenu = gtk_menu_item_new_with_label("Forward");
  gtk_widget_set_sensitive(GTK_WIDGET(bwindow->forwardmenu), FALSE);
  gtk_menu_append(GTK_MENU (menu), bwindow->forwardmenu);
  gtk_signal_connect(GTK_OBJECT(bwindow->forwardmenu), "activate",
      GTK_SIGNAL_FUNC(bwindow_forward_callback), bwindow);
  gtk_widget_show(bwindow->forwardmenu);
  
  menu_items = gtk_menu_item_new_with_label("Home");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(bwindow_home_callback), bwindow);
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Stop Loading");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(root_menu), menu);
  gtk_menu_bar_append(GTK_MENU_BAR(menu_bar), root_menu);

  menu = gtk_menu_new();
  root_menu = gtk_menu_item_new_with_label("Bookmarks");
  gtk_widget_show(root_menu);

  menu_items = gtk_menu_item_new_with_label("Add Bookmark");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(root_menu), menu);
  gtk_menu_bar_append(GTK_MENU_BAR(menu_bar), root_menu);

  menu = gtk_menu_new();
  root_menu = gtk_menu_item_new_with_label("Options");
  gtk_widget_show(root_menu);

  menu_items = gtk_menu_item_new_with_label("General Preferences...");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Not implemented");
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Toolbar icons");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(bwindow_toolbar_icons), bwindow);
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Toolbar text");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(bwindow_toolbar_text), bwindow);
  gtk_widget_show(menu_items);
  
  menu_items = gtk_menu_item_new_with_label("Toolbar both");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(bwindow_toolbar_both), bwindow);
  gtk_widget_show(menu_items);
  
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(root_menu), menu);
  gtk_menu_bar_append(GTK_MENU_BAR(menu_bar), root_menu);

  menu = gtk_menu_new();
  root_menu = gtk_menu_item_new_with_label("Help");
  gtk_widget_show(root_menu);

  menu_items = gtk_menu_item_new_with_label("About Express...");
  gtk_menu_append(GTK_MENU (menu), menu_items);
  gtk_signal_connect(GTK_OBJECT(menu_items), "activate",
      GTK_SIGNAL_FUNC(make_alert), "Express by Conrad Parker, conradp@cse.unsw.edu.au . See http://www.cse.unsw.edu.au/~conradp/express/ for more details");
  gtk_widget_show(menu_items);
  
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(root_menu), menu);
  gtk_menu_bar_append(GTK_MENU_BAR(menu_bar), root_menu);

  return(menu_bar);
}

