#ifndef __OPTIONS_H__
#define __OPTIONS_H__

#define DEFAULT_HOME_URL (char *)"http://localhost/"

#define DEFAULT_HOME_PIXMAP   (char *)"pix/open.xpm"
#define DEFAULT_RELOAD_PIXMAP (char *)"pix/open.xpm"
#define DEFAULT_PIPE_PIXMAP   (char *)"pix/open.xpm"
#define DEFAULT_PRINT_PIXMAP  (char *)"pix/open.xpm"
#define DEFAULT_FIND_PIXMAP   (char *)"pix/open.xpm"
#define DEFAULT_STOP_PIXMAP   (char *)"pix/open.xpm"
#define DEFAULT_OPEN_PIXMAP   (char *)"pix/open.xpm"

#endif /* __OPTIONS_H__ */
