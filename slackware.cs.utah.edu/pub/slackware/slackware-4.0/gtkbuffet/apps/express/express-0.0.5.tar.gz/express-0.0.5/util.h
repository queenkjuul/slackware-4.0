#ifndef __UTIL_H__
#define __UTIL_H__

void *pmalloc(size_t size, char *desc);

#endif __UTIL_H__
