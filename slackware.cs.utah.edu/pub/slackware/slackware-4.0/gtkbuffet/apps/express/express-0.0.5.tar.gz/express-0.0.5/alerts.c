#include <gtk/gtk.h>

#include "alert.h"

void make_alert(GtkWidget *w, gpointer data)
{
  GtkWidget *a;

  a = alert_new((char *)data);
  gtk_widget_show(a);
}

