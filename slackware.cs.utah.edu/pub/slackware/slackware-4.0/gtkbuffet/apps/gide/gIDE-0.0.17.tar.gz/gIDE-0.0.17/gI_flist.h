/* $Header: /cvs/gIDE/gI_flist.h,v 1.2 1998/12/11 19:06:33 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef GI_FLIST_H
#define GI_FLIST_H

#include <gtk/gtk.h>

/*
 * Prototypes for 'gI_flist.c'
 */
void gen_files_list( gchar *dirname, GtkWidget *window );
GtkWidget *setup_list_window();
void flist( void );


typedef struct _gI_flist_item_info gI_flist_item_info;
struct _gI_flist_item_info
{
    GtkWidget *window;
    gchar *filename;
    glong isdir;
};

#define ISDIR "<Directory>"
#define ISLNK "<Symlink>"

#endif

