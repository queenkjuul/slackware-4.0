/* $Header: /cvs/gIDE/gI_hilite.h,v 1.6 1998/12/11 19:06:33 sk Exp $ */
/*  gIDE
 *  Copyright (C) 1998 Steffen Kern
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifdef HAVE_GTKTEXT_PATCH

#ifndef HILITE_H
#define HILITE_H

#include <gtk/gtk.h>
#include "gtkeditor.h"

GtkWidget*gI_hilite_get_pattern_widget                   (gI_pat_dialog *pd);
void      gI_hilite_set_buffer_patterns_cb               (void);
void      gI_hilite_add_pattern_dia_cb                   (GtkWidget     *dummy,
							  gI_pat_dialog *pd);
void      gI_hilite_add_pattern_dia                      (gI_pat_dialog *pd);
void      gI_hilite_add_named_pattern                    (const gchar    *patname,
			                  const GtkEditorHilitePatterns *pat);
void      gI_hilite_remove_pattern_dia_cb                (GtkWidget     *dummy,
							  gI_pat_dialog *pd);
void      gI_hilite_remove_pattern_dia                   (gI_pat_dialog *pd);
void      gI_hilite_set_pattern                          (GtkWidget     *buffer,
							  gchar         *patname);
void      gI_hilite_rehilite                             (void);

GtkEditorHilitePatterns*
          gI_hilite_get_pattern_by_name                  (gchar          *name);

#if !HAVE_LIBGUILE
void      gI_hilite_load_patterns                        (const gchar    *filename);
#endif
void      gI_hilite_save_patterns                        (const gchar    *filename);


#endif /*HILITE_H*/

#endif /*HAVE_GTKTEXT_PATCH*/
