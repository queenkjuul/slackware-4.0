/* $Header: /cvs/gIDE/gide.h,v 1.9 1999/01/08 17:37:53 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef GIDE_H
#define GIDE_H

#include <gtk/gtk.h>
#include "structs.h"

/* Header-File for gide.c */

/* Widgets: Main-Window & Box */
extern gI_window *main_window;
extern GtkWidget *main_vbox;

/* Widgets: Boxes */
extern GtkWidget *main_hbox1;
extern GtkWidget *main_hbox2;
extern GtkWidget *main_hbox3;

/* Widgets: misc */
extern GtkWidget *main_notebook;
extern GtkWidget *main_text1;
extern GtkWidget *main_frame;
extern GtkWidget *main_vscrollbar;
extern GtkWidget *main_hscrollbar;
extern GtkWidget *main_statusbar;
extern GtkWidget *main_table;

/* Configuration */
extern gI_config *cfg;

extern char *home;
extern char gide_path[MAXLEN];
extern char tools_path[MAXLEN];
extern char prj_path[MAXLEN];

void free_op_list( GList *op_list );

#endif

