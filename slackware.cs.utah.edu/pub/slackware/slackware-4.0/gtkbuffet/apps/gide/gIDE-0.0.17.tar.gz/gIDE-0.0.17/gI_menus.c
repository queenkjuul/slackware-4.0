/* $Header: /cvs/gIDE/gI_menus.c,v 1.32 1999/02/26 17:26:00 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#include <string.h>
#include "structs.h"
#include "gI_file.h"
#include "gI_edit.h"
#include "gI_compile.h"
#include "gI_search.h"
#include "gI_menus.h"
#include "gI_functions.h"
#include "gI_files.h"
#include "gI_tree.h"
#include "gI_prefs.h"
#include "gI_about.h"
#include "gI_help.h"
#include "gI_project.h"
#include "gI_tools.h"
#include "gI_hilite.h"
#include "gI_run.h"
#include "gI_debug.h"
#ifdef HAVE_GNOME
#include <gnome.h>
#include <libgnomeui/gnome-app.h>
#include <libgnomeui/gnome-stock.h>
#include <libgnome/gnome-help.h>
#endif

/******************************************************************
  First, We'll Create the structures for the GNOME Menubar
******************************************************************/

#ifdef HAVE_GNOME

static GList *pw_assoc = NULL;

void gI_PWassoc_add( gchar *path, GtkWidget *widget )
{
	gI_PWassoc *item;

	item = (gI_PWassoc *) g_malloc0( sizeof( gI_PWassoc ) );
	item->path = g_strdup( path ); 
	item->widget = widget;
	pw_assoc = g_list_append( pw_assoc, item );
}

void gI_PWassoc_free()
{
	gI_PWassoc *item;
	GList *tmp;

	tmp = g_list_first( pw_assoc );
	while( tmp )
	{
		if( tmp->data )
		{
			item = (gI_PWassoc *) tmp->data;
			g_free( item->path );
		}
	
		tmp = g_list_next( tmp );
	}
	
	g_list_free( pw_assoc );
}

GtkWidget *gI_PWassoc_lookup( gchar *path )
{
	gI_PWassoc *assoc;
	GList *tmp;

	tmp = g_list_first( pw_assoc );
	while( tmp )
	{
		if( tmp->data )
		{
			assoc = (gI_PWassoc *) tmp->data;
			
			if( !strcmp( assoc->path, path ) )
			{
				return( assoc->widget );
			}

			tmp = g_list_next( tmp );
		}
	}

	return( NULL );
}

void gI_PWassoc_remove( gchar *path )
{
	gI_PWassoc *assoc;
	GList *tmp;

	tmp = g_list_first( pw_assoc );
	while( tmp )
	{
		if( tmp->data )
		{
			assoc = (gI_PWassoc *) tmp->data;
			
			if( !strcmp( assoc->path, path ) )
			{
				g_list_remove( pw_assoc, assoc );
				break;	
			}
		}
		
		tmp = g_list_next( tmp );
	}
}


void create_menubar( GtkWidget *app, GtkWidget *vbox )
{
	GnomeUIInfo filemenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("_New"), N_("New Source File"), file_new, NULL, NULL,
			GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_NEW,
			'N', GDK_CONTROL_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Open"), N_("Open File"), file_open, NULL, NULL,
			GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_OPEN,
			'O', GDK_CONTROL_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Reload"), N_("Reload Current File"), file_reload, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'R', GDK_MOD1_MASK, NULL},
        GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("_Save"), N_("Save Current File"), file_save, NULL, NULL,
		        GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_SAVE,
			'S', GDK_CONTROL_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Save _As"), N_("Save As"), file_save_as, NULL, NULL,
		        GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
        GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
	        N_("_Print"), N_("Print Current File"), file_print, NULL, NULL,
		        GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_PRINT,
			'P', GDK_MOD1_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Close"), N_("Close Current File"), file_close, NULL, NULL,
			GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_CLOSE,
			'Q', GDK_CONTROL_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Close All"), N_("Close All"), close_all_files, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
        GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
	        N_("E_xit"), N_("Exit"), file_exit, NULL, NULL,
			GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_EXIT,
			'X', GDK_MOD1_MASK, NULL},
        GNOMEUIINFO_END
	};

	GnomeUIInfo deletemenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("To Begin of File"), N_("Delete to the beginning of the file"),
			edit_delete_to_bof, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("To End of File"), N_("Delete to the end of the file"),
			edit_delete_to_eof, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("To Begin of Line"), N_("Delete to the beginning of the line"),
			edit_delete_to_bol, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("To Begin of File"), N_("Delete to the beginning of the file"),
			edit_delete_to_bof, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},	
		{GNOME_APP_UI_ITEM,
		N_("To End of Line"), N_("Delete to the end of the line"),
			edit_delete_to_bof, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
	    GNOMEUIINFO_END
	};

	GnomeUIInfo editmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("_Undo"), N_("Undo Last Change"), edit_undo, NULL, NULL,
			GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_UNDO,
			'Z', GDK_CONTROL_MASK, NULL },
		{GNOME_APP_UI_ITEM,
		N_("_Redo"), N_("Redo Last Undid Change"), edit_redo, NULL, NULL,
			GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_REDO,
			'R', GDK_CONTROL_MASK, NULL},
		GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("Cut"), N_("Cut"), edit_cut, NULL, NULL,
			GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_CUT,
			'X', GDK_CONTROL_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Copy"), N_("Copy"), edit_copy, NULL, NULL,
			GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_COPY,
			'C', GDK_CONTROL_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Paste"), N_("Paste"), edit_paste, NULL, NULL,
			GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_PASTE,
			'V', GDK_CONTROL_MASK, NULL},
		GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("Date and Time"), N_("Edit Date and Time"), edit_date_time, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("Select _All"), N_("Select All"), edit_select_all, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'A', GDK_MOD1_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Select _Line"), N_("Select Line"), edit_select_line, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'L', GDK_MOD1_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Select _Word"), N_("Select Word"), NULL, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
       		GNOMEUIINFO_SEPARATOR,
		GNOMEUIINFO_SUBTREE(N_("_Delete"), deletemenu),
		GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_TOGGLEITEM,
		N_("Read Only"), N_("Edit Read Only"), edit_read_only, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
	        GNOMEUIINFO_END
	};

	GnomeUIInfo searchmenu[] = {
    	{GNOME_APP_UI_ITEM,
		N_("_Search"), N_("Search"), search_search, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'S', GDK_MOD1_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Search _Again"), N_("Search Again"), search_again, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'A', GDK_MOD1_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Search&Replace"), N_("Search and Replace"), search_replace, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("Goto Line"), N_("Goto Line"), search_goto_line, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'G', GDK_CONTROL_MASK, NULL},
		GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("Match Brace"), N_("Match Brace"), NULL, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		GNOMEUIINFO_END
	};

	GnomeUIInfo distmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("Create DEB"), N_("Create DEB"), NULL, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Create RPM"), N_("Create RPM"), NULL, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		GNOMEUIINFO_END
	};

	GnomeUIInfo projectmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("_New Project"), N_("New Project"), project_new, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Open Project"), N_("Open Project"), project_open, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Edit Project"), N_("Edit Project"), project_edit, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Close Project"), N_("Close Project"), project_close, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Delete Project"), N_("Delete Project"), project_delete, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("Build Project"), N_("Build Project"), build_project, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("Create Makefile"), N_("Create Makefile"), create_makefile, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Create Configure"), N_("Create Configure"), NULL, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		GNOMEUIINFO_SEPARATOR,
		GNOMEUIINFO_SUBTREE(N_("Create Distribution"), distmenu),
		GNOMEUIINFO_END
	};

	GnomeUIInfo runmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("Run"), N_("Run Application"), run_run, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			GDK_F6, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Parameters"), N_("Edit Runtime Parameters"), run_parameters, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},	
		GNOMEUIINFO_END
	};

	GnomeUIInfo compilemenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("Compile to _Exec."), N_("Create Executable"), compile_compile, (gpointer)COMPILE_EXEC, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Compile to _Obj."), N_("Create Objectfile"), compile_compile, (gpointer)COMPILE_OBJ, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Make"), N_("Make"), compile_make, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'M', GDK_CONTROL_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("_Link"), N_("Link"), compile_link, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'L', GDK_CONTROL_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Build _All"), N_("Build All"), NULL, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Syntax Check"), N_("check_syntax"), compile_syntax_check, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		GNOMEUIINFO_END
	};

	GnomeUIInfo debugmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("Start Debug"), N_("Start Debug"), debug_debug, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			GDK_F5, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Attach to Process"), N_("Attach to Process"), debug_attach, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Stop Debug"), N_("Stop Debug"), debug_stop_debug, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			GDK_F5, GDK_SHIFT_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Set/Clear Breakpoint"), N_("Set or Clear Breakpoint"), debug_set_breakpoint, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			GDK_F9, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Step Over"), N_("Step Over"), debug_step_over, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			GDK_F10, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Step Into"), N_("Step Into"), debug_step_into, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			GDK_F11, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Break"), N_("Break"), debug_break, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			GDK_F12, 0, NULL},
		GNOMEUIINFO_END
	};

	GnomeUIInfo toolsmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("ASCII Table"), N_("ASCII Table"), tools_ascii_table, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Calculator"), N_("Calculator"), tools_calculator, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("ProtoType Generator"), N_("Prototype Generator"), gen_proto, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		GNOMEUIINFO_SEPARATOR,
		GNOMEUIINFO_END
	};

	GnomeUIInfo prefmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("Preferences..."), N_("Edit Preferences"), show_preferences, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Custom Tools..."), N_("Custom Tools..."), custom_tools, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("Reload Config"), N_("Reload COnfig"), reload_config, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Set to Defaults"), N_("Set to Defaults"), set_to_defaults, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		GNOMEUIINFO_END
	};

#ifdef HAVE_GTKTEXT_PATCH
	GnomeUIInfo highlightmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("Define Regexps..."), N_("Define Regexps..."), gI_hilite_set_buffer_patterns_cb, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Re-Highlight"), N_("Re-Highlight"), gI_hilite_rehilite, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL, 0, 0, NULL},
		GNOMEUIINFO_END
	};
#endif

	GnomeUIInfo windowmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("Files"), N_("Files"), show_all_files, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'F', GDK_SHIFT_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Functions"), N_("Functions"),
		show_all_functions, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'F', GDK_CONTROL_MASK, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Tree"), N_("Tree"), show_tree, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			'T', GDK_SHIFT_MASK, NULL},
		GNOMEUIINFO_END
	};

	GnomeUIInfo helpmenu[] = {
		{GNOME_APP_UI_ITEM,
		N_("Help"), N_("Help"), show_help, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			GDK_F1, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("Manual Pages"), N_("Manual Pages"), help_man_page, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			GDK_F1, GDK_MOD1_MASK, NULL},
	    GNOMEUIINFO_SEPARATOR,
		{GNOME_APP_UI_ITEM,
		N_("About Help"), N_("About Help"), about_help, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		{GNOME_APP_UI_ITEM,
		N_("About gIDE"), N_("About gIDE"), about_gide, NULL, NULL,
			GNOME_APP_PIXMAP_NONE, NULL,
			0, 0, NULL},
		GNOMEUIINFO_END
	};

	GnomeUIInfo mainmenu[] = {
	    	GNOMEUIINFO_SUBTREE(N_("_File"), filemenu),
		GNOMEUIINFO_SUBTREE(N_("_Edit"), editmenu),
		GNOMEUIINFO_SUBTREE(N_("_Search"), searchmenu),
		GNOMEUIINFO_SUBTREE(N_("_Project"), projectmenu),
		GNOMEUIINFO_SUBTREE(N_("_Run"), runmenu),
		GNOMEUIINFO_SUBTREE(N_("_Compile"), compilemenu),
		GNOMEUIINFO_SUBTREE(N_("_Debug"), debugmenu),
		GNOMEUIINFO_SUBTREE(N_("_Tools"), toolsmenu),
		GNOMEUIINFO_SUBTREE(N_("Prefere_nces"), prefmenu),
#ifdef HAVE_GTKTEXT_PATCH
		GNOMEUIINFO_SUBTREE(N_("_Highlight"), highlightmenu),
#endif
		GNOMEUIINFO_SUBTREE(N_("_Windows"), windowmenu),
		GNOMEUIINFO_SUBTREE(N_("_Help"), helpmenu),
		GNOMEUIINFO_END
	};

	/* create menus (the widget field is filled here) */
	gnome_app_create_menus( GNOME_APP(app), mainmenu );

	/* install hints */
	gnome_app_install_statusbar_menu_hints(
		GTK_STATUSBAR( GNOME_APP( app )->statusbar ),
					   	mainmenu );

	/* now we create a GList with the widgets */
	/* File Menu */
	gI_PWassoc_add( "/File/New", filemenu[0].widget );
	gI_PWassoc_add( "/File/Open", filemenu[1].widget );
	gI_PWassoc_add( "/File/Reload", filemenu[2].widget );
	gI_PWassoc_add( "/File/Save", filemenu[4].widget );
	gI_PWassoc_add( "/File/Save As", filemenu[5].widget );
	gI_PWassoc_add( "/File/Print", filemenu[7].widget );
	gI_PWassoc_add( "/File/Close", filemenu[8].widget );
	gI_PWassoc_add( "/File/Close All", filemenu[9].widget );
	gI_PWassoc_add( "/File/Exit", filemenu[11].widget );

	/* Edit Menu */
	gI_PWassoc_add( "/Edit/Undo", editmenu[0].widget );
	gI_PWassoc_add( "/Edit/Redo", editmenu[1].widget );
	gI_PWassoc_add( "/Edit/Cut", editmenu[3].widget );
	gI_PWassoc_add( "/Edit/Copy", editmenu[4].widget );
	gI_PWassoc_add( "/Edit/Paste", editmenu[5].widget );
	gI_PWassoc_add( "/Edit/Date-Time", editmenu[7].widget );
	gI_PWassoc_add( "/Edit/Select All", editmenu[9].widget );
	gI_PWassoc_add( "/Edit/Select Line", editmenu[10].widget );
	gI_PWassoc_add( "/Edit/Select Word", editmenu[11].widget );
	gI_PWassoc_add( "/Edit/Delete/To begin of file", deletemenu[0].widget );
	gI_PWassoc_add( "/Edit/Delete/To end of file", deletemenu[1].widget );
	gI_PWassoc_add( "/Edit/Delete/To begin of line", deletemenu[2].widget );
	gI_PWassoc_add( "/Edit/Delete/To end of line", deletemenu[3].widget );
	gI_PWassoc_add( "/Edit/Read Only", editmenu[15].widget );

	/* Search Menu */
	gI_PWassoc_add( "/Search/Search", searchmenu[0].widget );
	gI_PWassoc_add( "/Search/Search Again", searchmenu[1].widget );
	gI_PWassoc_add( "/Search/Search and Replace", searchmenu[2].widget );
	gI_PWassoc_add( "/Search/Goto Line", searchmenu[4].widget );
	gI_PWassoc_add( "/Search/Match Brace", searchmenu[6].widget );

	/* Project Menu */
	gI_PWassoc_add( "/Project/New Project", projectmenu[0].widget );
	gI_PWassoc_add( "/Project/Open Project", projectmenu[1].widget );
	gI_PWassoc_add( "/Project/Edit Project", projectmenu[2].widget );
	gI_PWassoc_add( "/Project/Close Project", projectmenu[3].widget );
	gI_PWassoc_add( "/Project/Delete Project", projectmenu[4].widget );
	gI_PWassoc_add( "/Project/Build Project", projectmenu[6].widget );
	gI_PWassoc_add( "/Project/Create Makefile", projectmenu[8].widget );
	gI_PWassoc_add( "/Project/Create configure", projectmenu[9].widget );
	gI_PWassoc_add( "/Project/Create Distribution/Create DEB", distmenu[0].widget );
	gI_PWassoc_add( "/Project/Create Distribution/Create RPM", distmenu[1].widget );

	/* Run Menu */
	gI_PWassoc_add( "/Run/Run", runmenu[0].widget );
	gI_PWassoc_add( "/Run/Parameters", runmenu[1].widget );
	
	/* Compile Menu */
	gI_PWassoc_add( "/Compile/Compile to Exec.", compilemenu[0].widget );
	gI_PWassoc_add( "/Compile/Compile to Obj.", compilemenu[1].widget );
	gI_PWassoc_add( "/Compile/Make", compilemenu[2].widget );
	gI_PWassoc_add( "/Compile/Link", compilemenu[3].widget );
	gI_PWassoc_add( "/Compile/Build All", compilemenu[4].widget );
	gI_PWassoc_add( "/Compile/Syntax Check", compilemenu[5].widget );

	/* Debug Menu */
	gI_PWassoc_add( "/Debug/Start Debug", debugmenu[0].widget );
	gI_PWassoc_add( "/Debug/Attach to Process", debugmenu[1].widget );
	gI_PWassoc_add( "/Debug/Stop  Debug", debugmenu[2].widget );
	gI_PWassoc_add( "/Debug/Set|Clear Breakpoint", debugmenu[3].widget );
	gI_PWassoc_add( "/Debug/Step Over", debugmenu[4].widget );
	gI_PWassoc_add( "/Debug/Step Into", debugmenu[5].widget );
	gI_PWassoc_add( "/Debug/Break", debugmenu[6].widget );

	/* some menus missing .. add later */	
}

#endif /* HAVE_GNOME */


/******************************************************************
  Now, the regular GTK Menubar
******************************************************************/

static GtkItemFactoryEntry menu_items[] =
{

    /* File Menu */
    {"/_File",                 NULL, NULL, 0, "<Branch>"},
    {"/File/_New",             "<control>N",     file_new,             0},
    {"/File/_Open",            "<control>O",     file_open,            0},
    {"/File/_Reload",          "<alt>R",     file_reload,          0},
    {"/File/sep1",             NULL, NULL, 0, "<Separator>"},
    {"/File/_Save",            "<control>S",     file_save,            0},
    {"/File/Save _As",         NULL,         file_save_as,         0},
    {"/File/sep2",             NULL, NULL, 0, "<Separator>"},
    {"/File/_Print",           "<alt>P",     file_print,           0},
    {"/File/sep3",             NULL, NULL, 0, "<Separator>"},
    {"/File/_Close",           "<control>Q",     file_close,           0},
    {"/File/Close All",        NULL,         close_all_files,      0},
    {"/File/sep4",             NULL, NULL, 0, "<Separator>"},
    {"/File/E_xit",            "<alt>X",     file_exit,            0},

    /* Edit Menu */
    {"/_Edit",                 NULL, NULL, 0, "<Branch>"},
    {"/Edit/_Undo",            "<control>Z", edit_undo,    0},
    {"/Edit/_Redo",            "<control>R", edit_redo,    0},
    {"/Edit/sep1",             NULL, NULL, 0, "<Separator>"},
    {"/Edit/Cut",              "<control>X", edit_cut,     0},
    {"/Edit/_Copy",            "<control>C", edit_copy,    0},
    {"/Edit/_Paste",           "<control>V", edit_paste,   0},
    {"/Edit/sep2",             NULL, NULL, 0, "<Separator>"},
	{"/Edit/Date-Time",		   NULL, edit_date_time, 0},
    {"/Edit/sep3",             NULL, NULL, 0, "<Separator>"},
    {"/Edit/Select _All",      "<alt>A",     edit_select_all,  0},
    {"/Edit/Select _Line",     "<alt>L",     edit_select_line, 0},
    {"/Edit/Select _Word",     NULL, NULL, 0},
    {"/Edit/sep4",             NULL, NULL, 0, "<Separator>"},
	{"/Edit/_Delete",		   NULL, NULL, 0, "<Branch>"},
	{"/Edit/Delete/To begin of file",NULL, edit_delete_to_bof, 0},
	{"/Edit/Delete/To end of file",  NULL, edit_delete_to_eof, 0},
	{"/Edit/Delete/To begin of line",NULL, edit_delete_to_bol, 0},
	{"/Edit/Delete/To end of line",  NULL, edit_delete_to_eol, 0},
    {"/Edit/sep5",             NULL, NULL, 0, "<Separator>"},
    {"/Edit/Read Only",        NULL, edit_read_only, 0, "<CheckItem>"},

    /* Search Menu */
    {"/_Search",               NULL, NULL, 0, "<Branch>"},
    {"/Search/_Search",        "<alt>S", search_search, 0},
    {"/Search/Search _Again",  "<alt>N", search_again,  0},
    {"/Search/Search&Replace", NULL, search_replace, 0},
    {"/Search/sep1",           NULL, NULL, 0, "<Separator>"},
    {"/Search/Goto _Line",     "<control>G", search_goto_line, 0},
    {"/Search/sep2",           NULL, NULL, 0, "<Separator>"},
	{"/Search/Match Brace",	   NULL, NULL, 0},

    /* Project Menu */
    {"/_Project",              NULL, NULL, 0, "<Branch>"},
    {"/Project/_New Project",  NULL, project_new, 0},
    {"/Project/_Open Project", NULL, project_open, 0},
    {"/Project/_Edit Project", NULL, project_edit, 0},
    {"/Project/_Close Project",NULL, project_close, 0},
    {"/Project/_Delete Project",NULL, project_delete, 0},
    {"/Project/sep1",          NULL, NULL, 0, "<Separator>"},
    {"/Project/Build Project", NULL, build_project, 0},
    {"/Project/sep2",          NULL, NULL, 0, "<Separator>"},
    {"/Project/Create Makefile",NULL, create_makefile, 0},
    {"/Project/Create configure",NULL, NULL, 0},
    {"/Project/sep3",          NULL, NULL, 0, "<Separator>"},
    {"/Project/Create Distribution",NULL, NULL, 0, "<Branch>"},
    {"/Project/Create Distribution/Create DEB",NULL, NULL, 0},
    {"/Project/Create Distribution/Create RPM",NULL, NULL, 0},

    /* Run Menu */
    {"/_Run",                  NULL, NULL, 0, "<Branch>"},
    {"/Run/Run",               "F6", run_run, 0},
    {"/Run/Parameters",        NULL, run_parameters, 0},

    /* Compile Menu */
    {"/_Compile",              NULL, NULL, 0, "<Branch>"},
    {"/Compile/Compile to _Exec.",NULL, compile_compile, COMPILE_EXEC},
    {"/Compile/Compile to _Obj.", NULL, compile_compile, COMPILE_OBJ},
    {"/Compile/_Make",          "<control>M", compile_make, 0},
    {"/Compile/_Link",          "<control>L", compile_link, 0},
    {"/Compile/Build _All",     NULL, NULL, 0},
    {"/Compile/Syntax Check",   NULL, compile_syntax_check, 0},

    /* Debug Menu */
	{"/_Debug",                 NULL, NULL, 0, "<Branch>"},
	{"/Debug/Start Debug",      "F5", debug_debug, 0},
	{"/Debug/Attach to Process",NULL, debug_attach, 0},
	{"/Debug/Stop  Debug",		"<shift>F5", debug_stop_debug, 0},
	{"/Debug/Set|Clear Breakpoint","F9", debug_set_breakpoint, 0},
	{"/Debug/Step Over",		"F10", debug_step_over, 0},
	{"/Debug/Step Into",		"F11", debug_step_into, 0},
	{"/Debug/Break",			"F12", debug_break, 0},

    /* Tools Menu */
    {"/_Tools",                 NULL, NULL, 0, "<Branch>"},
	{"/Tools/ASCII Table",		NULL, tools_ascii_table, 0},
#ifdef HAVE_GNOME
	{"/Tools/Calculator",		NULL, tools_calculator, 0},
#endif
    {"/Tools/Prototypes Generator", NULL, gen_proto, 0},
    {"/Tools/sep1",             NULL, NULL, 0, "<Separator>"},
    
    /* Preferences Menu */
    {"/Prefere_nces",   NULL, NULL, 0, "<Branch>"},
    {"/Preferences/Preferences...",   NULL, show_preferences, 0},
    {"/Preferences/Custom Tools...",  NULL, custom_tools, 0},
    {"/Preferences/sep1",      NULL, NULL, 0, "<Separator>"},
    {"/Preferences/Reload Config",    NULL, reload_config, 0},
    {"/Preferences/Set to Defaults",  NULL, set_to_defaults, 0},

#ifdef HAVE_GTKTEXT_PATCH
    /* Highlight Menu */
    { "/_Highlight",  NULL, NULL, 0, "<Branch>"}, 
    { "/Highlight/Define Regexps...",  NULL, 
                           GTK_SIGNAL_FUNC (gI_hilite_set_buffer_patterns_cb),
                                             0 },
    { "/Highlight/Re-highlight",       NULL,
                           GTK_SIGNAL_FUNC (gI_hilite_rehilite), 0 },
#endif /*HAVE_GTKTEXT_PATCH*/

    /* Windows Menu */
    {"/_Windows",         NULL, NULL, 0, "<Branch>"},
    {"/Windows/Files",         "<shift>F", show_all_files, 0},
    {"/Windows/Functions",     "<control>F", show_all_functions, 0},
    {"/Windows/Tree",          "<shift>T", show_tree, 0},

    /* Help Menu */
    {"/_Help",             NULL, NULL, 0, "<LastBranch>"},
    {"/Help/Help",             "F1", show_help, 0},
    {"/Help/Manual Pages",     "<alt>F1", help_man_page, 0},
    {"/Help/sep1",      NULL, NULL, 0, "<Separator>"},
    {"/Help/About Help",       NULL, about_help, 0},
    {"/Help/About gIDE",       NULL, about_gide, 0}

};



/* globals */
static gint nmenu_items = sizeof(menu_items) / sizeof(menu_items[0]);
static gint initialize = TRUE;
GtkItemFactory *factory = NULL;

/* externs */
extern gI_window *main_window;

void get_main_menu(GtkWidget **menubar, GtkAccelGroup **group)
{
    if (initialize)
    	    menus_init( *group );
    
    if (menubar)
            *menubar = gtk_item_factory_get_widget( factory, "<Main>" );
}



void menus_init( GtkAccelGroup *group )
{
    if (initialize) {
        initialize = FALSE;
	
	factory = gtk_item_factory_new( GTK_TYPE_MENU_BAR, "<Main>", group );
	
	menus_create(menu_items, nmenu_items);
    }
}
	    
void menus_create( GtkItemFactoryEntry * entries, gint nmenu_entries )
{
    gtk_item_factory_create_items(factory, nmenu_entries, entries, NULL);
}



void menus_set_sensitive( gchar *path, gint sensitive )
{
	GtkWidget *widget = NULL;

#ifndef HAVE_GNOME
	g_return_if_fail( factory != NULL );
#endif
	g_return_if_fail( path != NULL );

	/*widget = gtk_item_factory_get_widget( factory, path );*/
	widget = menus_get_item_widget( path );
	if( widget )
		gtk_widget_set_sensitive( widget, sensitive );
	else
		g_warning("Unable to set sensitivity for menu which doesn't exist: %s", path);
}


#ifdef HAVE_GNOME
GtkWidget *menus_get_item_widget( gchar *path )
{
	GtkWidget *widget = NULL;

	g_return_val_if_fail( path != NULL, NULL );

	widget = gI_PWassoc_lookup( path );

	return( widget );
}

#else

GtkWidget *menus_get_item_widget( gchar *path )
{
	GtkWidget *widget = NULL;

	g_return_val_if_fail( factory != NULL, NULL );
	g_return_val_if_fail( path != NULL, NULL );

	widget = gtk_item_factory_get_widget( factory, path );

	return( widget );
}
#endif

