/* $Header: /cvs/gIDE/gI_window.c,v 1.63 1999/02/26 18:29:56 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#ifdef HAVE_GNOME
#include <gnome.h>
#else
#include "toolbar.h"
#endif
#include <stdio.h>
#include <string.h>
#include "structs.h"
#include "gI_document.h"
#include "gI_menus.h"
#include "gI_file.h"
#include "gI_edit.h"
#include "gI_help.h"
#include "gI_prefs.h"
#include "gI_search.h"
#include "gI_tools.h"
#include "gI_common.h"
#include "gI_window.h"
#include "gI_hilite.h"
#include "gI_project.h"

/* externs */
extern gI_config *cfg;
extern glong ro_not_change;


glong window_destroy( GtkWidget *widget, GdkEvent *event, gI_window *window )
{
    gint nod,i,changed=0;
    gI_document *current;
	gI_project *project;

	/* close opened project */
	if( (project = gI_project_get_current()) )
	{
		project_close( NULL, NULL );
	}	

    nod = gI_document_get_no( window );

    for(i=1;i<=nod;i++)
    {
        gtk_notebook_set_page( GTK_NOTEBOOK( window->notebook ), i );
        current = gI_document_get_current( window );
        if( current->changed == TRUE )
        {
            changed = TRUE;
            break;
        }
    }

    if( changed )
    {
	 	/*g_free(window->popup);
 		window->popup = NULL;*/
        file_exit_is_changed( window );
        return( TRUE );
    }
    else
    {
		/*if(window->popup)
			g_free(window->popup);
		if(window->search_history)
			g_list_free(window->search_history);
		if(window->search_history)
			g_list_free(window->search_history);*/
  
		gtk_main_quit();
		return( TRUE );
    }
}


/*
 ---------------------------------------------------------------------
     Function: create_pixmap()
     Desc: Creates pixmap and returns it
 ---------------------------------------------------------------------
*/

#ifndef HAVE_GNOME
static GtkWidget *create_pixmap( GtkWidget *gwindow, GdkWindow *window, GtkStyle *style, glong type )
{

    GdkBitmap *mask;
    GtkWidget *wpixmap;
    GdkPixmap *pixmap = NULL;
    GdkColor *background;

    background = &style->bg[GTK_STATE_NORMAL];
    
    if( type == 1 )
   pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, new_xpm );

    if( type == 2 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, open_xpm );

    if( type == 3 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, close_xpm );

    if( type == 4 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, save_xpm );

    if( type == 7 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, help_xpm );

    if( type == 8 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, exit_xpm );

    if( type == 5 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, copy_xpm );

    if( type == 6 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, paste_xpm );

    if( type == 9 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, cut_xpm );

    if( type == 10 )
   pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, print_xpm );

    if( type == 11 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, settings_xpm );

    if( type == 12 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, search_xpm );

    if( type == 13 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, reload_xpm );

    if( type == 14 )
    pixmap = gdk_pixmap_create_from_xpm_d( window, &mask, background, undo_xpm );

    if( !pixmap )
        g_error( "Invalid Pixmap-type!" );
    
    wpixmap = gtk_pixmap_new( pixmap, mask );

    return( wpixmap );
}
#endif


/*
 ---------------------------------------------------------------------
     Function: create_prjftree()
     Desc: Creates Project-File-Tree
 ---------------------------------------------------------------------
*/

void create_prjftree( gI_window *window, GtkWidget *hbox )

{
    if( cfg->prjftree )
    {
        if( window->tree_frame != NULL )
            return;

        window->tree_frame = gtk_frame_new( "Project Files" );
        gtk_box_pack_start( GTK_BOX( hbox ), window->tree_frame, FALSE, TRUE, 5 );
        gtk_widget_show( window->tree_frame );
    }
    else
    {
        if( window->tree_frame != NULL )
        {
            gtk_widget_destroy( window->tree_frame );
            window->tree_frame = NULL;
        }
    }
}


/*
 ---------------------------------------------------------------------
     Function: create_toolbar()
     Desc: Creates Toolbar
 ---------------------------------------------------------------------
*/

#ifdef HAVE_GNOME

void
create_toolbar (GtkWidget *app, GtkWidget *vbox)
{
   GnomeDockItem *dockitem;

   /* First, check to see if Custom toolbar is enabled, if it is, find out which buttons are
      enabled and then compile the structure and display the toolbar                */

  if (cfg->toolbar_custom)
    {
      glong i;
    

      GnomeUIInfo newbutton = GNOMEUIINFO_ITEM_STOCK (N_("New"),
				N_("New File"),
				file_new, GNOME_STOCK_PIXMAP_NEW);	

      GnomeUIInfo openbutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Open"),
                                N_ ("Open File"),
                                file_open, GNOME_STOCK_PIXMAP_OPEN);

      GnomeUIInfo closebutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Close"),
                                N_ ("Close Current File"),
                                file_close, GNOME_STOCK_PIXMAP_CLOSE);

      GnomeUIInfo savebutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Save"),
                                N_ ("Save Current File"),
                                file_save, GNOME_STOCK_PIXMAP_SAVE);

      GnomeUIInfo printbutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Print"),
                                N_ ("Print Current File"),
                                file_print, GNOME_STOCK_PIXMAP_PRINT);

      GnomeUIInfo reloadbutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Reload"),
                                N_ ("Reload Current File"),
                                file_reload, GNOME_STOCK_PIXMAP_REFRESH);

      GnomeUIInfo undobutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Undo"),
                                N_ ("Undo Last Change"),
                                edit_undo, GNOME_STOCK_PIXMAP_UNDO);

      GnomeUIInfo cutbutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Cut"),
                                N_ ("Cut Selection"),
                                edit_cut, GNOME_STOCK_PIXMAP_CUT);

      GnomeUIInfo copybutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Copy"),
                                N_ ("Copy Selection"),
                                edit_copy, GNOME_STOCK_PIXMAP_COPY);

      GnomeUIInfo pastebutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Paste"),
                                N_ ("Paste Cliboard"),
                                edit_paste, GNOME_STOCK_PIXMAP_PASTE);

      GnomeUIInfo searchbutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Search"),
                                N_ ("Search"),
                                search_search, GNOME_STOCK_PIXMAP_SEARCH);

      GnomeUIInfo prefsbutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Preferences"),
                                N_ ("Edit Preferences"),
                          show_preferences, GNOME_STOCK_PIXMAP_PREFERENCES);

      GnomeUIInfo helpbutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Help"),
                                N_ ("Help"),
                                show_help, GNOME_STOCK_PIXMAP_HELP);

      GnomeUIInfo exitbutton = GNOMEUIINFO_ITEM_STOCK (N_ ("Exit"),
                                N_ ("Exit gIDE"),
                                file_exit, GNOME_STOCK_PIXMAP_EXIT);
 

    GnomeUIInfo toolbar[50];

    for (i = 0; i < cfg->toolbar_custom_items_no; i++)
	{
	  if (!strcmp (cfg->toolbar_custom_items[i], "New"))
           {
		toolbar[i] = newbutton;
           };
        
          if (!strcmp (cfg->toolbar_custom_items[i], "Open"))
           {
		toolbar[i] = openbutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Close"))
           {
                toolbar[i] = closebutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Save"))
           {
                toolbar[i] = savebutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Reload"))
           {
                toolbar[i] = reloadbutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Print"))
           {
                toolbar[i] = printbutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Cut"))
           {
                toolbar[i] = cutbutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Copy"))
           {
                toolbar[i] = copybutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Undo"))
           {
                toolbar[i] = undobutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Paste"))
           {
                toolbar[i] = pastebutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Search"))
           {
                toolbar[i] = searchbutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Space"))
           {
                toolbar[i].type = GNOME_APP_UI_SEPARATOR;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Preferences"))
           {
                toolbar[i] = prefsbutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Help"))
           {
                toolbar[i] = helpbutton;
           };
          if (!strcmp (cfg->toolbar_custom_items[i], "Exit"))
           {
                toolbar[i] = exitbutton;
           };
  
        }
     i = i++;
     toolbar[i].type = GNOME_APP_UI_ENDOFINFO;

      /* destroy an existing toolbar */
      dockitem = gnome_app_get_dock_item_by_name( GNOME_APP( app ),
			   		    GNOME_APP_TOOLBAR_NAME );

      if( dockitem )
          gtk_widget_destroy( GTK_WIDGET( dockitem ) );


      gnome_app_create_toolbar( GNOME_APP (app), toolbar );

      return;
    }

    if( cfg->toolbar )
    {
      /* If the custom toolbar is not enabled complete and display the 
         real toolbar */

      GnomeUIInfo toolbar[] =
      {
	GNOMEUIINFO_ITEM_STOCK (N_ ("New"),
				N_ ("Create A New File"),
				file_new, GNOME_STOCK_PIXMAP_NEW),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Open"),
				N_ ("Open File"),
				file_open, GNOME_STOCK_PIXMAP_OPEN),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Close"),
				N_ ("Close Current File"),
				file_close, GNOME_STOCK_PIXMAP_CLOSE),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Save"),
				N_ ("Save Current File"),
				file_save, GNOME_STOCK_PIXMAP_SAVE),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Print"),
				N_ ("Print Current File"),
				file_print, GNOME_STOCK_PIXMAP_PRINT),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Reload"),
				N_ ("Reload Current File"),
				file_reload, GNOME_STOCK_PIXMAP_REFRESH),
	GNOMEUIINFO_SEPARATOR,
	GNOMEUIINFO_ITEM_STOCK (N_ ("Undo"),
				N_ ("Undo Last Change"),
				edit_undo, GNOME_STOCK_PIXMAP_UNDO),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Cut"),
				N_ ("Cut Selection"),
				edit_cut, GNOME_STOCK_PIXMAP_CUT),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Copy"),
				N_ ("Copy Selection"),
				edit_copy, GNOME_STOCK_PIXMAP_COPY),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Paste"),
				N_ ("Paste Cliboard"),
				edit_paste, GNOME_STOCK_PIXMAP_PASTE),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Search"),
				N_ ("Search"),
				search_search, GNOME_STOCK_PIXMAP_SEARCH),
	GNOMEUIINFO_SEPARATOR,
	GNOMEUIINFO_ITEM_STOCK (N_ ("Preferences"),
				N_ ("Edit Preferences"),
			  show_preferences, GNOME_STOCK_PIXMAP_PREFERENCES),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Help"),
				N_ ("Help"),
				show_help, GNOME_STOCK_PIXMAP_HELP),
	GNOMEUIINFO_ITEM_STOCK (N_ ("Exit"),
				N_ ("Exit gIDE"),
				file_exit, GNOME_STOCK_PIXMAP_EXIT),
	GNOMEUIINFO_END
      };

      /* destroy an existing toolbar */
      dockitem = gnome_app_get_dock_item_by_name( GNOME_APP( app ),
			   		    GNOME_APP_TOOLBAR_NAME );

      if( dockitem )
          gtk_widget_destroy( GTK_WIDGET( dockitem ) );

      gnome_app_create_toolbar( GNOME_APP (app), toolbar );

    }
    else
    {
        /* destroy an existing toolbar */
	dockitem = gnome_app_get_dock_item_by_name( GNOME_APP( app ),
			   		    GNOME_APP_TOOLBAR_NAME );

	if( dockitem )
		gtk_widget_destroy( GTK_WIDGET( dockitem ) );
    }
}

#else /* If gnome is *NOT* enabled do: */

void create_toolbar( gI_window *window, GtkWidget *vbox )

{
    GtkStyle *style;
    glong i;
    
    /* Toolbar or not Toolbar? */
    if( cfg->toolbar )
    {
        if( window->toolbar != NULL )
	{
	    gtk_widget_show( window->toolbar );
            return;
	}

        style = cfg->style;

        window->toolbar = gtk_toolbar_new( GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH );
        gtk_box_pack_start( GTK_BOX( vbox ), window->toolbar, FALSE, FALSE, 0 );

        if( cfg->toolbar_custom )
        {
            for(i=0;i<cfg->toolbar_custom_items_no;i++)
            {
                if( !strcmp( cfg->toolbar_custom_items[i], "New" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "New",
                                             "", create_pixmap( window->window, window->window->window, style, 1 ),
                                             GTK_SIGNAL_FUNC( file_new ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Open" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Open",
                                             "", create_pixmap( window->window, window->window->window, style, 2 ),
                                             GTK_SIGNAL_FUNC( file_open ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Close" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Close",
                                             "", create_pixmap( window->window, window->window->window, style, 3 ),
                                             GTK_SIGNAL_FUNC( file_close ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Save" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Save",
                                             "", create_pixmap( window->window, window->window->window, style, 4 ),
                                             GTK_SIGNAL_FUNC( file_save ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Print" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Print",
                                             "", create_pixmap( window->window, window->window->window, style, 10 ),
                                             GTK_SIGNAL_FUNC( file_print ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Cut" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Cut",
                                             "", create_pixmap( window->window, window->window->window, style, 9 ),
                                             GTK_SIGNAL_FUNC( edit_cut ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Copy" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Copy",
                                             "", create_pixmap( window->window, window->window->window, style, 5 ),
                                             GTK_SIGNAL_FUNC( edit_copy ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Paste" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Paste",
                                             "", create_pixmap( window->window, window->window->window, style, 6 ),
                                             GTK_SIGNAL_FUNC( edit_paste ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Search" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Search",
                                             "", create_pixmap( window->window, window->window->window, style, 12 ),
                                             GTK_SIGNAL_FUNC( search_search ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Space" ) )
                {
                    gtk_toolbar_append_space( GTK_TOOLBAR( window->toolbar ) );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Preferences" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Preferences",
                                             "", create_pixmap( window->window, window->window->window, style, 11 ),
                                             GTK_SIGNAL_FUNC( show_preferences ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Help" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Help",
                                             "", create_pixmap( window->window, window->window->window, style, 7 ),
                                             GTK_SIGNAL_FUNC( show_help ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Exit" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Exit",
                                             "", create_pixmap( window->window, window->window->window, style, 8 ),
                                             GTK_SIGNAL_FUNC( file_exit ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Reload" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Reload",
                                             "", create_pixmap( window->window, window->window->window, style, 13 ),
                                             GTK_SIGNAL_FUNC( file_reload ), NULL );
                }
                if( !strcmp( cfg->toolbar_custom_items[i], "Undo" ) )
                {
                    gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Undo",
                                             "", create_pixmap( window->window, window->window->window, style, 14 ),
                                             GTK_SIGNAL_FUNC( edit_undo ), NULL );
                }
            }
        }
        else
        {

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "New",
                                     "", create_pixmap( window->window, window->window->window, style, 1 ),
                                     GTK_SIGNAL_FUNC( file_new ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Open",
                                     "", create_pixmap( window->window, window->window->window, style, 2 ),
                                     GTK_SIGNAL_FUNC( file_open ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Close",
                                     "", create_pixmap( window->window, window->window->window, style, 3 ),
                                     GTK_SIGNAL_FUNC( file_close ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Reload",
                                     "", create_pixmap( window->window, window->window->window, style, 13 ),
                                     GTK_SIGNAL_FUNC( file_reload ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Save",
                                     "", create_pixmap( window->window, window->window->window, style, 4 ),
                                     GTK_SIGNAL_FUNC( file_save ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Print",
                                     "", create_pixmap( window->window, window->window->window, style, 10 ),
                                     GTK_SIGNAL_FUNC( file_print ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Undo",
                                     "", create_pixmap( window->window, window->window->window, style, 14 ),
                                     GTK_SIGNAL_FUNC( edit_undo ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Cut",
                                     "", create_pixmap( window->window, window->window->window, style, 9 ),
                                     GTK_SIGNAL_FUNC( edit_cut ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Copy",
                                     "", create_pixmap( window->window, window->window->window, style, 5 ),
                                     GTK_SIGNAL_FUNC( edit_copy ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Paste",
                                     "", create_pixmap( window->window, window->window->window, style, 6 ),
                                     GTK_SIGNAL_FUNC( edit_paste ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Search",
                                     "", create_pixmap( window->window, window->window->window, style, 12 ),
                                     GTK_SIGNAL_FUNC( search_search ), NULL );

            gtk_toolbar_append_space( GTK_TOOLBAR( window->toolbar ) );
            gtk_toolbar_append_space( GTK_TOOLBAR( window->toolbar ) );
            gtk_toolbar_append_space( GTK_TOOLBAR( window->toolbar ) );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Preferences",
                                     "", create_pixmap( window->window, window->window->window, style, 11 ),
                                     GTK_SIGNAL_FUNC( show_preferences ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Help",
                                     "", create_pixmap( window->window, window->window->window, style, 7 ),
                                     GTK_SIGNAL_FUNC( show_help ), NULL );

            gtk_toolbar_append_item( GTK_TOOLBAR( window->toolbar ), NULL, "Exit",
                                     "", create_pixmap( window->window, window->window->window, style, 8 ),
                                     GTK_SIGNAL_FUNC( file_exit ), NULL );

        }
        gtk_toolbar_append_space( GTK_TOOLBAR( window->toolbar ) );
        gtk_widget_show( window->toolbar );
    }
    else
    {
        if( window->toolbar != NULL )
        {
            gtk_widget_hide( window->toolbar );
            /*window->toolbar = NULL;*/
        }
    }
}
#endif


static void switchto_next_doc( GtkWidget *widget, GdkEventKey *kevent, gI_window *window )
{
	gint curpag;
	GtkNotebookPage *page;
	static guint KeyValSave = 0;

	g_assert( window != NULL );
	g_assert( window->notebook != NULL );

	if( kevent->type == GDK_KEY_PRESS
	 && kevent->keyval == GDK_Shift_L )
	{
		KeyValSave = kevent->keyval;

		return;
	}

	if( kevent->type != GDK_KEY_PRESS
	 || kevent->keyval != GDK_ISO_Left_Tab
	 || KeyValSave != GDK_Shift_L )
	{
		return;
	}

	curpag = gtk_notebook_get_current_page( GTK_NOTEBOOK( window->notebook ) );	
	if( curpag == gI_document_get_no( window )-1 )
		gtk_notebook_set_page( GTK_NOTEBOOK( window->notebook ), 0 );	
	else
		gtk_notebook_next_page( GTK_NOTEBOOK( window->notebook ) );

	page = (GtkNotebookPage *) GTK_NOTEBOOK( window->notebook )->cur_page;
	
	g_assert( page != NULL );

	gtk_widget_grab_focus( page->tab_label ); 
	gtk_widget_draw_focus( page->tab_label );

	gtk_signal_emit_stop_by_name( GTK_OBJECT( window->window ), "key_press_event" );
}



/*
 ---------------------------------------------------------------------
     Function: gI_window_new()
     Desc: Opens a new Session
 ---------------------------------------------------------------------
*/

gI_window *gI_window_new( void )
{
    gI_window *window;
    GtkWidget *vbox;
    gchar *title;

    window = g_malloc0( sizeof( gI_window ) );
    window->popup = g_malloc( sizeof(gI_text_popupmenu) );
    window->notebook = NULL;
    window->switch_page_id = FALSE;
    window->toolbar = NULL;

#ifdef HAVE_GNOME
  /* Initialize Gnome Application */
  window->window = gnome_app_new( "gIDE", NULL );
  gtk_signal_connect( GTK_OBJECT( window->window ), "delete_event",
      		      GTK_SIGNAL_FUNC (window_destroy), window );

  /* for small toolbar icons */
  /* this will be configurable in the future */
  /* maybe this value should be higher */
  if( gdk_screen_width() < 600 )
  	gnome_preferences_set_toolbar_labels( FALSE );
#else
  window->window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_signal_connect( GTK_OBJECT( window->window ), "delete_event",
                      GTK_SIGNAL_FUNC( window_destroy ), window );
#endif
  title = g_strconcat( "gIDE", " ", VERSION, NULL );
  gtk_window_set_title( GTK_WINDOW( window->window ), title );
  g_free( title );
  gtk_widget_set_usize( window->window, 800, 550 );
  gtk_widget_realize (window->window);

  /* Create The Layout of the window */
  vbox = gtk_vbox_new (FALSE, 0);
#ifdef HAVE_GNOME
  gnome_app_set_contents (GNOME_APP (window->window), vbox);
#else
  gtk_container_add( GTK_CONTAINER( window->window ), vbox );
#endif
  gtk_widget_show (vbox);

  /*
   * first part of splitted statusbar code:
   * create the widget,
   * for GNOME version: set statusbar in GnomeApp
   */
  window->statusbar = gtk_statusbar_new ();
#ifdef HAVE_GNOME
  gnome_app_set_statusbar( GNOME_APP( window->window ), window->statusbar );
#endif

#ifdef HAVE_GNOME
  window->menubar = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), window->menubar, FALSE, TRUE, 0);
  gtk_widget_show (window->menubar);
  create_menubar (window->window, window->menubar);
#else
    window->accel = gtk_accel_group_new();
    get_main_menu( &window->menubar, &window->accel );
    gtk_accel_group_attach( window->accel, GTK_OBJECT( window->window ) );

    gtk_box_pack_start( GTK_BOX( vbox ), window->menubar, FALSE, TRUE, 0 );
    gtk_widget_show( window->menubar );
#endif


  /* Add toolbar - Note: gcc/gnome seems temperamental about where these
     ifdefs are placed, so please don't remove the duplicated code below
     unless you make sure the toolbar works.*/

#ifdef HAVE_GNOME
  window->toolbar_box = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), window->toolbar_box, FALSE, TRUE, 0);
  gtk_widget_show (window->toolbar_box);
  create_toolbar (window->window, window->toolbar_box);
#else
  window->toolbar_box = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), window->toolbar_box, FALSE, TRUE, 0);
  gtk_widget_show (window->toolbar_box);
  create_toolbar( window, window->toolbar_box );
#endif

  /* Continue Layout */
  window->hpane = gtk_hpaned_new ();
  gtk_paned_gutter_size (GTK_PANED (window->hpane), 10 );
  gtk_paned_set_position( GTK_PANED( window->hpane ), 0 );
  gtk_box_pack_start (GTK_BOX (vbox), window->hpane, TRUE, TRUE, 0);
  gtk_widget_show (window->hpane);

  gI_window_create_popupmenu (window);

  window->tree_box = gtk_hbox_new (TRUE, 0);

  /* Project tree is on the left */
  gtk_paned_add1 (GTK_PANED (window->hpane), window->tree_box);

  create_prjftree (window, window->tree_box);

  gtk_widget_hide (window->tree_box);
  gtk_widget_show (window->tree_frame);

  gI_document_new (window);

  gtk_paned_add2 (GTK_PANED (window->hpane), window->notebook);
  gtk_widget_show (window->notebook);

  /* statusbar */
  /*
   * second part of statusbar code
   * we had to split the statusbar code, 'cause we need the
   * statusbar widget earlier to install the menu hints
   *
   * for non-GNOME-version: add statusbar widget to vbox
   */
#ifndef HAVE_GNOME
  gtk_box_pack_start (GTK_BOX (vbox), window->statusbar, FALSE, TRUE, 0);
#endif
  gtk_widget_show (window->statusbar);

  /* add tools */
  add_all_tools( window );

  /* autosave */
  if (cfg->autosave)
    {
      window->timeout_id = gtk_timeout_add (cfg->autosave_freq * 1000, (GtkFunction) file_autosave, NULL);
    }
  else
    {
      window->timeout_id = 0;
    }

	gtk_signal_connect( GTK_OBJECT( window->window ), "key_press_event",
			GTK_SIGNAL_FUNC( switchto_next_doc ), window );

	gtk_widget_show (window->window);

    gtk_widget_queue_draw( window->window );
    gtk_widget_queue_resize( window->window );

    gtk_widget_show_all( window->window );

    return( window );
}


/*
 ---------------------------------------------------------------------
     Function: gI_window_clear_statusbar()
     Desc: Clears the Statusbar of a Window
 ---------------------------------------------------------------------
*/

void gI_window_clear_statusbar( gI_window *window )
{
	gtk_statusbar_pop( GTK_STATUSBAR( window->statusbar ), STATUSBAR_CONTEXT_CURSOR_POSITION );
}


/*
 ---------------------------------------------------------------------
     Function: gI_window_create_popupmenu()
     Desc: Creates PopUp-Menu
 ---------------------------------------------------------------------
*/

void gI_window_create_popupmenu(gI_window *window)
{
    window->popup->menu=gtk_menu_new();
    window->popup->menu_swaphc=gtk_menu_item_new_with_label("Open (swap) .c/.h file");
    window->popup->menu_openfile_at_line=gtk_menu_item_new_with_label("Open Selected");
    window->popup->menu_separator1=gtk_menu_item_new();
    window->popup->menu_cut=gtk_menu_item_new_with_label("Cut");
    window->popup->menu_copy=gtk_menu_item_new_with_label("Copy");
    window->popup->menu_paste=gtk_menu_item_new_with_label("Paste");
    window->popup->menu_separator2=gtk_menu_item_new();
    window->popup->menu_save = gtk_menu_item_new_with_label( "Save" );
    window->popup->menu_print = gtk_menu_item_new_with_label( "Print" );
    window->popup->menu_close=gtk_menu_item_new_with_label("Close");
#ifdef HAVE_GTKTEXT_PATCH
    window->popup->menu_separator3 = gtk_menu_item_new();
    window->popup->menu_rehilite = gtk_menu_item_new_with_label( "Re-Highlight" );
#endif
	window->popup->menu_separator4 = gtk_menu_item_new();
	window->popup->menu_item_special = gtk_menu_item_new_with_label( "Special" );
	window->popup->menu_special = gtk_menu_new();
	window->popup->menu_special_delete = gtk_menu_item_new_with_label( "Delete active file" );
	window->popup->menu_special_insert = gtk_menu_item_new_with_label( "Insert file" );
	window->popup->menu_special_mail = gtk_menu_item_new_with_label( "Mail active document" );
	window->popup->menu_separator5 = gtk_menu_item_new();
	window->popup->menu_man = gtk_menu_item_new_with_label( "Show Manual Page" );

    gtk_menu_append( GTK_MENU(window->popup->menu), window->popup->menu_swaphc );
    gtk_menu_append(GTK_MENU(window->popup->menu),
                    window->popup->menu_openfile_at_line );

    gtk_menu_append( GTK_MENU(window->popup->menu),
                     window->popup->menu_separator1 );

    gtk_menu_append( GTK_MENU(window->popup->menu), window->popup->menu_cut );
    gtk_menu_append( GTK_MENU(window->popup->menu), window->popup->menu_copy );
    gtk_menu_append( GTK_MENU(window->popup->menu), window->popup->menu_paste );
    gtk_menu_append( GTK_MENU(window->popup->menu),
                     window->popup->menu_separator2 );
    gtk_menu_append( GTK_MENU( window->popup->menu ), window->popup->menu_save );
    gtk_menu_append( GTK_MENU( window->popup->menu ), window->popup->menu_print );
    gtk_menu_append( GTK_MENU(window->popup->menu), window->popup->menu_close );
#ifdef HAVE_GTKTEXT_PATCH
    gtk_menu_append( GTK_MENU( window->popup->menu ), window->popup->menu_separator3 );
    gtk_menu_append( GTK_MENU( window->popup->menu ), window->popup->menu_rehilite );
#endif
    gtk_menu_append( GTK_MENU( window->popup->menu ), window->popup->menu_separator4 );
    gtk_menu_append( GTK_MENU( window->popup->menu ), window->popup->menu_item_special );

	gtk_menu_item_set_submenu( GTK_MENU_ITEM( window->popup->menu_item_special ), window->popup->menu_special );

	gtk_menu_append( GTK_MENU( window->popup->menu_special ), window->popup->menu_special_insert );
	gtk_menu_append( GTK_MENU( window->popup->menu_special ), window->popup->menu_special_delete );
	gtk_menu_append( GTK_MENU( window->popup->menu_special ), window->popup->menu_special_mail );

    gtk_menu_append( GTK_MENU( window->popup->menu ), window->popup->menu_separator5 );
    gtk_menu_append( GTK_MENU( window->popup->menu ), window->popup->menu_man );

    gtk_widget_show(window->popup->menu_swaphc);
    gtk_widget_show(window->popup->menu_openfile_at_line);
    gtk_widget_show(window->popup->menu_separator1);
    gtk_widget_show(window->popup->menu_cut);
    gtk_widget_show(window->popup->menu_copy);
    gtk_widget_show(window->popup->menu_paste);
    gtk_widget_show(window->popup->menu_separator2);
    gtk_widget_show( window->popup->menu_save );
    gtk_widget_show( window->popup->menu_print );
    gtk_widget_show(window->popup->menu_close);
#ifdef HAVE_GTKTEXT_PATCH
    gtk_widget_show( window->popup->menu_separator3 );
    gtk_widget_show( window->popup->menu_rehilite );
#endif
    gtk_widget_show( window->popup->menu_separator4 );
    gtk_widget_show( window->popup->menu_item_special );
    gtk_widget_show( window->popup->menu_special_insert );
    gtk_widget_show( window->popup->menu_special_delete );
    gtk_widget_show( window->popup->menu_special_mail );

    gtk_widget_show( window->popup->menu_separator5 );
    gtk_widget_show( window->popup->menu_man );

    gtk_signal_connect(GTK_OBJECT(window->popup->menu_swaphc),"activate",
                       GTK_SIGNAL_FUNC(gI_document_cmd_swaphc),window);
    gtk_signal_connect(GTK_OBJECT(window->popup->menu_openfile_at_line),"activate",
                       GTK_SIGNAL_FUNC(gI_document_cmd_open_file_at_line),window);

    gtk_signal_connect(GTK_OBJECT(window->popup->menu_cut),"activate",
                       GTK_SIGNAL_FUNC(edit_cut),NULL);
    gtk_signal_connect(GTK_OBJECT(window->popup->menu_copy),"activate",
                       GTK_SIGNAL_FUNC(edit_copy),NULL);
    gtk_signal_connect(GTK_OBJECT(window->popup->menu_paste),"activate",
                       GTK_SIGNAL_FUNC(edit_paste),NULL);
    gtk_signal_connect( GTK_OBJECT( window->popup->menu_save ), "activate",
                        GTK_SIGNAL_FUNC( file_save ), NULL );
    gtk_signal_connect( GTK_OBJECT( window->popup->menu_print ), "activate",
                        GTK_SIGNAL_FUNC( file_print ), NULL );
    gtk_signal_connect(GTK_OBJECT(window->popup->menu_close),"activate",
                       GTK_SIGNAL_FUNC(file_close),NULL);
#ifdef HAVE_GTKTEXT_PATCH
    gtk_signal_connect( GTK_OBJECT( window->popup->menu_rehilite ), "activate",
                        GTK_SIGNAL_FUNC( gI_hilite_rehilite ), NULL );
#endif
    gtk_signal_connect( GTK_OBJECT( window->popup->menu_special_insert ), "activate",
                        GTK_SIGNAL_FUNC( special_insert_file ), NULL );
    gtk_signal_connect( GTK_OBJECT( window->popup->menu_special_delete ), "activate",
                        GTK_SIGNAL_FUNC( special_remove_current_file ), NULL );
    gtk_signal_connect( GTK_OBJECT( window->popup->menu_special_mail ), "activate",
                        GTK_SIGNAL_FUNC( special_mail_doc ), NULL );
    gtk_signal_connect( GTK_OBJECT( window->popup->menu_man ), "activate",
                        GTK_SIGNAL_FUNC( show_manpage ), NULL );
}


/*
 ---------------------------------------------------------------------
     Function: gI_window_set_statusbar()
     Desc: Sets the content of the Statusbar of a Window
 ---------------------------------------------------------------------
*/

void gI_window_set_statusbar( gI_document *document )
{
    gchar sb_msg[200];
    gchar buftxt[200];

    /* return, if no document is given */
    if( !document )
        return;
    
    if( document->filename != NULL )
    {
		g_snprintf( buftxt, sizeof(buftxt), "gIDE %s <%s>", VERSION, document->filename );
    }
    else
    {
		gchar *label, *label_dup;
		gchar *ptr;

		gtk_label_get( GTK_LABEL( document->label ), &label );

		label_dup = g_strdup( label );
		label = label_dup;

		ptr = strchr( label, '*' );
		if( ptr )
			*ptr = '\0';
	
		sprintf( buftxt, "gIDE %s %s", VERSION, label );

		g_free( label_dup );
	}

	g_snprintf( sb_msg, sizeof(sb_msg), "%s, Size: %d bytes %s / [row:%d, col:%d] %s %s",
				document->filename?document->filename:"(no file)",
				gtk_text_get_length( GTK_TEXT( document->text ) ),
				document->changed?"[modified]":"",
			    document->x, document->y,
				document->read_only?" / [read-only]":"",
				document->window->debug_window?" / [debug]":""
			  );

    gtk_window_set_title( GTK_WINDOW( document->window->window ), buftxt);

	gtk_statusbar_pop( GTK_STATUSBAR( document->window->statusbar ), STATUSBAR_CONTEXT_CURSOR_POSITION );
	gtk_statusbar_push( GTK_STATUSBAR( document->window->statusbar ), 
									  STATUSBAR_CONTEXT_CURSOR_POSITION, sb_msg );
}


static void set_undo_redo( gI_document *current )
{
	GList *op_list;

    if( !current )
    {
        menus_set_sensitive( "/Edit/Undo", FALSE );
        menus_set_sensitive( "/Edit/Redo", FALSE );
        return;
    }

	if( !current->op_list )
	{
        menus_set_sensitive( "/Edit/Undo", FALSE );
        menus_set_sensitive( "/Edit/Redo", FALSE );
		return;
	}

	op_list = current->op_list;

    /* no more operations to redo, set sensitive false */
    if( op_list->next == NULL )
    {
        menus_set_sensitive( "/Edit/Redo", FALSE );
        menus_set_sensitive( "/Edit/Undo", TRUE );
		return;
    }
	
	 /* no more operations to undo, set sensitive false */
    if( op_list->prev == NULL )
    {
        menus_set_sensitive( "/Edit/Undo", FALSE );
        menus_set_sensitive( "/Edit/Redo", TRUE );
		return;	
	}
}


/*
 ---------------------------------------------------------------------
     Function: gI_window_switch_notebookpage()
     Desc: This function is called, when the Notebook-Page is switched
 ---------------------------------------------------------------------
*/

void gI_window_switch_notebookpage( GtkWidget *widget, GtkNotebookPage *page, guint page_num, gI_window *window )
{
    gI_document *current;

    if( !window )
        return;

    if( gI_document_get_no( window ) < page_num )
    {
        return;
    }
    
    current = gI_document_get_nth( window, page_num+1 );
    if( !current )
    {
        return;
    }

    /* disconnect signal from menu item */
    /* gtk_signal_disconnect_by_func( GTK_OBJECT( menus_get_item_widget( "/Edit/Read Only" ) ), GTK_SIGNAL_FUNC( edit_read_only ), NULL ); */

    gI_window_set_visible_read_only( TRUE );

    /* set check menu item state & correct editable flag in widget */
    ro_not_change = 1; 
    gtk_check_menu_item_set_state( GTK_CHECK_MENU_ITEM( menus_get_item_widget( "/Edit/Read Only" ) ), current->read_only );
    if( current->read_only )
		gtk_text_set_editable( GTK_TEXT( current->text ), FALSE );
    else
		gtk_text_set_editable( GTK_TEXT( current->text ), TRUE ); 
    ro_not_change = 0;

    /* gtk_signal_connect( GTK_OBJECT( menus_get_item_widget( "/Edit/Read Only" ) ), "activate", GTK_SIGNAL_FUNC( edit_read_only ), NULL ); */ 

	set_undo_redo( current );   
 
    gI_window_clear_statusbar( window );

    gI_window_set_statusbar( current );

    gtk_widget_grab_focus( current->text );

	check_current_doc();
}


/*
 ---------------------------------------------------------------------
     Function: gI_window_set_visible_read_only()
     Desc: This function sets the Read-Only entry sensitive true or false 
 ---------------------------------------------------------------------
*/

void gI_window_set_visible_read_only( gint sensitive )
{
    menus_set_sensitive( "/Edit/Read Only", sensitive );
    if( sensitive == FALSE )
	gtk_check_menu_item_set_state( GTK_CHECK_MENU_ITEM( menus_get_item_widget( "/Edit/Read Only" ) ), FALSE ); 
}
