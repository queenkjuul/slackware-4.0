/* $Header: /cvs/gIDE/gI_clp.c,v 1.7 1998/12/11 19:06:32 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "structs.h"
#include "gI_clp.h"
#include "gI_file.h"


/* externs */
extern gI_window *main_window;
extern gI_config *cfg;


glong gI_cl_parse( gint argc, gchar **argv )
{
   gint parsed,argn;
   gchar modarg[STRLEN];

   if( argc == 1 )
       return( 0 );

   /* Init */
   parsed = 0;

   for(argn=1;argn<argc;argn++)
   {
       strcpy( modarg, argv[argn] );
       if( ispar( modarg ) )
       {
           strcpy( modarg, cleanarg( modarg ) );
	   if( strcmp( modarg, "noabout" ) == 0 )
               cfg->about = 0;
           if( strcmp( modarg, "version" ) == 0 )
           {
               printf("gIDE " VERSION "\t(c)opyright 1998 by Steffen Kern\n");
               exit( 0 );
           }
           if( strcmp( modarg, "help" ) == 0 )
           {
               printf("gIDE " VERSION "\t(c)opyright 1998 by Steffen Kern\n");
               printf("Syntax: %s filename\n",file_strip_name( argv[0] ) );
               printf("For further commandline parameters, read the manual page gide(1)\n" );
               exit( 0 );
           }
           if( strcmp( modarg, "cfgfile" ) == 0 )
           {
               if( (argc > argn+1) && (!ispar( modarg )) )
               {
                   cfg->cfgfile = realloc( cfg->cfgfile, (strlen( argv[argn+1] + 1) * sizeof( gchar ) ) );
                   strcpy( cfg->cfgfile, argv[argn+1] );
               }
               else
               {
                   g_error( "Missing Argument\n" );
                   exit( -1 );
               }
           }
           if( strcmp( modarg, "disable-font-stuff" ) == 0 )
           {
               g_print( "Font Stuff disabled\n" );
               cfg->disable_font_stuff = TRUE;
           }
       }
   }

   return( 1 );
}


gint gI_cl_files( gint argc, gchar **argv )
{
    gint i,nofargs;
    gchar pathandname[1024];
    /* Init */
    nofargs=0;

    /* get the filenames */
    for(i=1;i<argc;i++)
    {
        if( !ispar( argv[i] ) )
	{
            if( !ispar( argv[i-1] ) )
	    {
		if(strchr(argv[i],'/')==NULL)
		{
		    getcwd(pathandname,1024);
               	    strcat(pathandname,"/");
		    strncat(pathandname,argv[i],1024);
		}		
		else /* Path already exist dont append current dir */
		{
		    strncpy(pathandname,argv[i],1024);
		}
	        
		file_open_by_name( main_window, pathandname);
	    }      
	}
	nofargs++;
    }

    return( nofargs );
}


gint ispar( gchar *arg )
{
    if( arg[0] == '-' && arg[1] == '-' )
        return( 1 );
    else
        return( 0 );
}


gchar *cleanarg( gchar *arg )
{
    return( &arg[2] );
}
