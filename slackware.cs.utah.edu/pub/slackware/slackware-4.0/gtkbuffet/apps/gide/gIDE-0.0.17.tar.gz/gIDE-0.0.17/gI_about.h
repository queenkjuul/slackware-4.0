/* $Header: /cvs/gIDE/gI_about.h,v 1.5 1998/08/10 00:34:44 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef GI_ABOUT_H
#define GI_ABOUT_H

#include <gtk/gtk.h>

/*
 * Prototypes for 'gI_about.c'
 */
void about_gide( GtkWidget *widget, gpointer data );
void about_help( GtkWidget *widget, gpointer data );

#endif

