/* $Header: /cvs/gIDE/gI_edit.c,v 1.19 1999/01/09 04:57:06 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "structs.h"
#include "gI_document.h"
#include "gI_window.h"
#include "gI_edit.h"
#include "gI_menus.h"

/* externs */
extern gI_window *main_window;
extern glong ro_not_change;


/*
 ---------------------------------------------------------------------
     Function: edit_undo()
     Desc: Callback-Function /Edit/Undo
 ---------------------------------------------------------------------
*/

void edit_undo( GtkWidget *widget, gpointer data )
{
	gI_UndoItem *undo;
	gint from, to;
	gI_document *current;

	current = gI_document_get_current( main_window );
	if( !current )
	{
		menus_set_sensitive( "/Edit/Undo", FALSE );
		menus_set_sensitive( "/Edit/Redo", FALSE );
		return;
	}

	if( !current->op_list )
	{
		/* no list? set both sensitive false */
		menus_set_sensitive( "/Edit/Undo", FALSE );
		menus_set_sensitive( "/Edit/Redo", FALSE );
		return;
	}

	if( current->first_undo )
	{
		current->first_undo = 0;

		current->op_list = g_list_last( current->op_list );
	}

	undo = (gI_UndoItem *) current->op_list->data;
	if( !undo )
	{
		/* no undo item? set sensitive false */
		menus_set_sensitive( "/Edit/Undo", FALSE );
		return;
	}

	gtk_signal_disconnect( GTK_OBJECT( undo->document->text ),
						   undo->document->insert_id );
	gtk_signal_disconnect( GTK_OBJECT( undo->document->text ),
						   undo->document->delete_id );

	from = MIN( undo->from, undo->to );
	to = MAX( undo->from, undo->to ); 

	switch( undo->type )
	{
		case GI_UNDO_BEGIN:
			menus_set_sensitive( "/Edit/Undo", FALSE );
				break;
		case GI_UNDO_INSERT:
		{
			gtk_text_set_point( GTK_TEXT( undo->document->text ),
							    undo->from );
			gtk_editable_select_region( GTK_EDITABLE( undo->document->text ),
									 	from,
									 	to );
			gtk_editable_delete_selection( GTK_EDITABLE( undo->document->text ) );
			gtk_editable_set_position( GTK_EDITABLE( undo->document->text ),
									   from );
			break;
		}

		case GI_UNDO_DELETE:
		{
			gtk_text_set_point( GTK_TEXT( undo->document->text ),
							    undo->from );
			gtk_text_insert( GTK_TEXT( undo->document->text ),
							 NULL,
							 NULL,
							 NULL,
							 undo->data,
							 (undo->to-undo->from) );
			gtk_editable_set_position( GTK_EDITABLE( undo->document->text ),
									   to );
			break;
		}

		default:
		{
			g_warning( "Whats going on? Unknown UNDO type!\n" );
			break;
		}
	}	

/***
	gtk_signal_emit_stop_by_name( GTK_OBJECT( undo->document->text ),
								  "insert_text" );
	gtk_signal_emit_stop_by_name( GTK_OBJECT( undo->document->text ),
								  "delete_text" );
***/

    undo->document->insert_id = gtk_signal_connect( GTK_OBJECT( undo->document->text ), "insert_text",
                        GTK_SIGNAL_FUNC( gI_document_insert_text ), undo->document );
    undo->document->delete_id = gtk_signal_connect( GTK_OBJECT( undo->document->text ), "delete_text",
                        GTK_SIGNAL_FUNC( gI_document_delete_text ), undo->document );

	/* undo called, now we can allow a redo */
	menus_set_sensitive( "/Edit/Redo", TRUE );

	/* no more operations to undo, set sensitive false */
	if( current->op_list->prev == NULL )
	{
		menus_set_sensitive( "/Edit/Undo", FALSE );
		menus_set_sensitive( "/Edit/Redo", TRUE );
	}
	else
	{
		current->op_list = g_list_previous( current->op_list );
	}
}


/*
 ---------------------------------------------------------------------
     Function: edit_redo()
     Desc: Callback-Function /Edit/Redo
 ---------------------------------------------------------------------
*/

void edit_redo( GtkWidget *widget, gpointer data )
{
	gI_UndoItem *undo;
	gI_document *current;

	current = gI_document_get_current( main_window );
	if( !current )
	{
		menus_set_sensitive( "/Edit/Undo", FALSE );
		menus_set_sensitive( "/Edit/Redo", FALSE );
		return;
	}

	if( !current->op_list )
	{
		/* no list? set both sensitive false */
		menus_set_sensitive( "/Edit/Undo", FALSE );
		menus_set_sensitive( "/Edit/Redo", FALSE );
		return;
	}

	/* no more operations to redo, set sensitive false */
	if( current->op_list->next == NULL )
	{
		menus_set_sensitive( "/Edit/Redo", FALSE );
		return;
	}
	else
	{
		current->op_list = g_list_next( current->op_list ); 
	}

	if( current->op_list->next == NULL )
		menus_set_sensitive( "/Edit/Redo", FALSE );

	
	undo = (gI_UndoItem *) current->op_list->data;
	if( !undo )
	{
		/* no undo item? set sensitive false */
		menus_set_sensitive( "/Edit/Redo", FALSE );
		return;
	}

	gtk_signal_disconnect( GTK_OBJECT( undo->document->text ),
						   undo->document->insert_id );
	gtk_signal_disconnect( GTK_OBJECT( undo->document->text ),
						   undo->document->delete_id );

	switch( undo->type )
	{
		case GI_UNDO_DELETE:
		{
			gtk_text_set_point( GTK_TEXT( undo->document->text ),
							    undo->from );
			gtk_editable_select_region( GTK_EDITABLE( undo->document->text ),
									 	undo->from,
									 	undo->to );
			gtk_editable_delete_selection( GTK_EDITABLE( undo->document->text ) );
			break;
		}

		case GI_UNDO_INSERT:
		{
			gtk_text_set_point( GTK_TEXT( undo->document->text ),
							    undo->from );
			gtk_text_insert( GTK_TEXT( undo->document->text ),
							 NULL,
							 NULL,
							 NULL,
							 undo->data,
							 (undo->to-undo->from) );
			break;
		}

		default:
		{
			g_warning( "Whats going on? Unknown UNDO type!\n" );
			break;
		}
	}	

/***
	gtk_signal_emit_stop_by_name( GTK_OBJECT( undo->document->text ),
								  "insert_text" );
	gtk_signal_emit_stop_by_name( GTK_OBJECT( undo->document->text ),
								  "delete_text" );
***/

    undo->document->insert_id = gtk_signal_connect( GTK_OBJECT( undo->document->text ), "insert_text",
                        GTK_SIGNAL_FUNC( gI_document_insert_text ), undo->document );
    undo->document->delete_id = gtk_signal_connect( GTK_OBJECT( undo->document->text ), "delete_text",
                        GTK_SIGNAL_FUNC( gI_document_delete_text ), undo->document );
	menus_set_sensitive( "/Edit/Undo", TRUE );

}


/*
 ---------------------------------------------------------------------
     Function: edit_cut()
     Desc: Callback-Function /Edit/Cut
 ---------------------------------------------------------------------
*/

void edit_cut( GtkWidget *widget, gpointer data )
{
    gtk_editable_cut_clipboard( GTK_EDITABLE( gI_document_get_current( main_window ) -> text ) );
}


/*
 ---------------------------------------------------------------------
     Function: edit_copy()
     Desc: Callback-Function /Edit/Copy
 ---------------------------------------------------------------------
*/

void edit_copy( GtkWidget *widget, gpointer data )
{
    gtk_editable_copy_clipboard( GTK_EDITABLE( gI_document_get_current( main_window ) -> text ) );
}


/*
 ---------------------------------------------------------------------
     Function: edit_paste()
     Desc: Callback-Function /Edit/Paste
 ---------------------------------------------------------------------
*/

void edit_paste( GtkWidget *widget, gpointer data )
{
    gtk_editable_paste_clipboard( GTK_EDITABLE( gI_document_get_current( main_window ) -> text ) );
}


/*
 ---------------------------------------------------------------------
     Function: edit_select_all()
     Desc: Callback-Function /Edit/Select All
 ---------------------------------------------------------------------
*/

void edit_select_all( GtkWidget *widget, gpointer data )
{
    gtk_editable_select_region( GTK_EDITABLE( gI_document_get_current( main_window ) -> text ), 0, gtk_text_get_length( GTK_TEXT( gI_document_get_current( main_window ) -> text ) ) );
}


/*
 ---------------------------------------------------------------------
     Function: edit_select_line()
     Desc: Callback-Function /Edit/Select Line
 ---------------------------------------------------------------------
*/

void edit_select_line( GtkWidget *widget, gpointer data )
{
    gI_document *current;
    gint oldpoint;

    current = gI_document_get_current( main_window );

    oldpoint = gtk_text_get_point( GTK_TEXT( current->text ) );
/*    gtk_text_set_point( GTK_TEXT( current->text ), get_end_of_line( current->text, oldpoint ) ); */
    
    gtk_editable_select_region( GTK_EDITABLE( current ->text ), oldpoint,
                                get_end_of_line( current->text, oldpoint  ) );

/*    gtk_text_set_point( GTK_TEXT( current->text ), oldpoint ); */
}


/*
 ---------------------------------------------------------------------
     Function: edit_read_only()
     Desc: Callback-Function /Edit/Read Only
 ---------------------------------------------------------------------
*/

void edit_read_only( GtkWidget *widget, gpointer data )
{
    gI_document *current;

    if( ro_not_change )
	return;

    current = gI_document_get_current( main_window );
    if( !current )
    {
		return;
    }

    if( current->read_only )
    {
		current->read_only = 0;
	   	gtk_text_set_editable( GTK_TEXT( current->text ), TRUE ); 
    }
    else
    {
		current->read_only = 1;
	   	gtk_text_set_editable( GTK_TEXT( current->text ), FALSE ); 
    }

    gI_window_set_statusbar( current );
}


glong get_end_of_line( GtkWidget *text, glong point )
{
    static glong eol;
    
    for(eol=point;eol<gtk_text_get_length( GTK_TEXT( text ) );eol++)
    {
        if( gtk_editable_get_chars( GTK_EDITABLE( text ), eol, eol+1 )[0] == '\n' )
            break;
    }

    if( eol < 0 )
        eol = 0;
    if( eol > gtk_text_get_length( GTK_TEXT( text ) ) )
        eol = gtk_text_get_length( GTK_TEXT( text ) );

    return( eol );
}


glong get_begin_of_line( GtkWidget *text, glong point )
{
    static glong bol;

    for(bol=point;bol>0;bol--)
    {
        if( gtk_editable_get_chars( GTK_EDITABLE( text ), bol, bol-1 )[0] == '\n' )
            break;
    }

    if( bol < 0 )
        bol = 0;
    if( bol > gtk_text_get_length( GTK_TEXT( text ) ) )
        bol = gtk_text_get_length( GTK_TEXT( text ) );

    return( bol );
}


void edit_date_time( GtkWidget *widget, gpointer data )
{
	time_t t;	
	struct tm *st;
	gchar *timestr;
	gI_document *current;

	current = gI_document_get_current( main_window );
	if( !current )
		return;

	time(&t);
	
	st = localtime(&t);

	timestr = asctime( st );	

	gtk_text_insert( GTK_TEXT( current->text ), NULL, NULL, NULL,
					timestr, strlen(timestr) );	
}


void edit_delete_to_bol( GtkWidget *widget, gpointer data )
{
	gI_document *current;

	current = gI_document_get_current( main_window );
	if( !current )
		return;

	gtk_editable_select_region( GTK_EDITABLE( current->text ),
								gtk_text_get_point( GTK_TEXT( current->text ) ),
								get_begin_of_line( current->text,
							gtk_text_get_point( GTK_TEXT( current->text ) ) ) ); 

	gtk_editable_delete_selection( GTK_EDITABLE( current->text ) );
}


void edit_delete_to_eol( GtkWidget *widget, gpointer data )
{
	gI_document *current;

	current = gI_document_get_current( main_window );
	if( !current )
		return;

	gtk_editable_select_region( GTK_EDITABLE( current->text ),
								gtk_text_get_point( GTK_TEXT( current->text ) ),
								get_end_of_line( current->text,
							gtk_text_get_point( GTK_TEXT( current->text ) ) ) ); 

	gtk_editable_delete_selection( GTK_EDITABLE( current->text ) );
}


void edit_delete_to_bof( GtkWidget *widget, gpointer data )
{
	gI_document *current;

	current = gI_document_get_current( main_window );
	if( !current )
		return;

	gtk_editable_select_region( GTK_EDITABLE( current->text ),
								gtk_text_get_point( GTK_TEXT( current->text ) ),
								0 );

	gtk_editable_delete_selection( GTK_EDITABLE( current->text ) );
}


void edit_delete_to_eof( GtkWidget *widget, gpointer data )
{
	gI_document *current;

	current = gI_document_get_current( main_window );
	if( !current )
		return;

	gtk_editable_select_region( GTK_EDITABLE( current->text ),
	   			    gtk_text_get_point( GTK_TEXT( current->text ) ),
				    gtk_text_get_length( GTK_TEXT( current->text ) ) );

	gtk_editable_delete_selection( GTK_EDITABLE( current->text ) );
}


gI_UndoItem *gI_UndoItem_new( gI_document *document,
			      const gchar *data,
			      gint data_length,
			      gint from,
			      gint to,
			      gint type )
{
	gI_UndoItem *undo;

	g_return_val_if_fail( document != NULL, NULL );
	g_return_val_if_fail( data != NULL, NULL );

	undo = g_malloc0( sizeof( gI_UndoItem ) );

	undo->document = document;
	undo->data = g_malloc0( data_length+1 );
	strncpy( undo->data, data, data_length );
	undo->data[data_length] = '\0';
	undo->from = from;
	undo->to = to;
	undo->type = type;

	return( undo );
}


void gI_UndoItem_destroy( gI_UndoItem *undo )
{
	g_return_if_fail( undo != NULL );

	if( undo->data )
		g_free( undo->data );

	g_free( undo );
}


void gI_UndoItem_add( gI_UndoItem *undo )
{
	g_return_if_fail( undo != NULL );
	g_return_if_fail( undo->document != NULL );
	g_return_if_fail( undo->data != NULL );
	
	menus_set_sensitive( "/Edit/Undo", TRUE );
	
	if( !undo->document->op_list )
	{
		/* Create undo buffer */
		gI_UndoItem *marker = 
			gI_UndoItem_new( undo->document, "", 0,0,0, GI_UNDO_BEGIN );
		undo->document->op_list = 
			g_list_append( undo->document->op_list, marker );
	}
	else if ( g_list_next(undo->document->op_list) != NULL )
	{
		GList* node_to_remove;

		while ( ( node_to_remove = 
				  g_list_next( undo->document->op_list ) )!= NULL)
		{
			g_list_remove_link( undo->document->op_list,
						        node_to_remove );
			gI_UndoItem_destroy( node_to_remove->data );
			g_list_free( node_to_remove );
		}
	}
		
	g_list_append( undo->document->op_list, undo );
	undo->document->op_list = g_list_last( undo->document->op_list );	
}

