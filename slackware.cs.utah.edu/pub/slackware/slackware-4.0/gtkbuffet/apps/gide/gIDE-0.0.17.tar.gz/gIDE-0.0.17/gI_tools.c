/* $Header: /cvs/gIDE/gI_tools.c,v 1.24 1999/02/21 17:39:26 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#ifdef HAVE_GNOME
#include <gnome.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include "structs.h"
#include "gI_functions.h"
#include "gI_document.h"
#include "gI_tools.h"
#include "gI_file.h"
#include "gI_common.h"
#include "gI_menus.h"
#include "tools_help.h"


/* globals */
static GtkWidget *tools_window = NULL;
static GtkWidget *custom_tools_window = NULL;
static GtkWidget *cb_append;
static GtkWidget *e_source;
static GtkWidget *e_target;
static GtkWidget *cb_static;
static gchar org_line[MAXLEN];
static FILE *infile,*outfile;

static GtkWidget *e_cmdline;
static GtkWidget *e_menu_item_name;
static GtkWidget *r_new;
static GtkWidget *r_append;
static GtkWidget *r_box;
static GtkWidget *r_ignore;
static GtkWidget *e_name;
static GtkWidget *r_insert;
static GtkWidget *r_xterm;
static glong kz_edit = FALSE;


/* externs */
extern gI_window *main_window;
extern GtkItemFactory *factory;
extern gchar gide_path[];
extern gchar tools_path[];
extern gI_config *cfg;


/*
 * Callback: destroy tools_window
 */
static void tools_window_destroy( GtkWidget *widget, gpointer data )
{
    if( !tools_window )
        return;
    
    gtk_widget_destroy( tools_window );
    tools_window = NULL;
}


/*
 * Callback: destroy custom_tools_window
 */
static void custom_tools_window_destroy( GtkWidget *widget, gpointer data )
{
    if( !custom_tools_window )
        return;

    gtk_widget_destroy( custom_tools_window );
    custom_tools_window = NULL;
}


/*
 * Verify: checks the entries of the Prototype Generator Dialog.
 */
static glong check_entries()
{
    gchar *ptr;

    ptr = gtk_entry_get_text( GTK_ENTRY( e_source ) );
    if( ptr )
    {
        if( isempty( ptr ) )
            return( 0 );
    }
    else
        return( 0 );

    ptr = gtk_entry_get_text( GTK_ENTRY( e_target ) );
    if( ptr )
    {
        if( isempty( ptr ) )
            return( 0 );
    }
    else
        return( 0 );

    return( 1 );
}


/*
 * Callback: OK-Button in Prototype Generator
 */
static glong gen_proto_start( GtkWidget *widget, gpointer data )
{
    gchar *ptr;
    gchar source[STRLEN],target[STRLEN];
    glong i;
    gchar buf[MAXLEN];
    glong written;
    glong line = 0;
    static c_status c_status;
    gchar HelpString[MAXLEN];

    if( !check_entries() )
        return(-1);
    
    ptr = gtk_entry_get_text( GTK_ENTRY( e_source ) );
    strcpy( source, ptr );
    
    infile = fopen( source, "r" );
    if( infile == NULL )
    {
        printf("ERROR: can't open file %s\n",source);
        return( -1 );
    }

    init_cstatus( &c_status );

    while( !feof( infile ) )
    {
        fgets( buf, sizeof( buf ), infile );
        if( feof( infile ) )
            break;
        for(i=0;i<=strlen(buf);i++)
            c_parse_special(buf,i,&c_status);
    }
/*
    if( !config.ignore )
    {
        if( c_status.comment )
        {
            printf( "\nERROR: base parsing failed, unfinished comment\n" );
            return( -1 );
        }

        if( c_status.klammern_1 || c_status.klammern_2 || c_status.klammern_3 )
        {
            printf( "\nERROR: base parsing failed, numbers doesn't match: %ld, %ld, %ld\n", c_status.klammern_1,c_status.klammern_2,c_status.klammern_3 );
        return( -1 );
        }
    }
    else
    {
        if( c_status.comment || c_status.klammern_1 || c_status.klammern_2 || c_status.klammern_3 )
        {
            printf( "ignoring detected errors, continuation forced..." );
        }
    }
*/

    ptr = gtk_entry_get_text( GTK_ENTRY( e_target ) );
    strcpy( target, ptr );
    
    if( GTK_TOGGLE_BUTTON( cb_append )->active )
        outfile = fopen( target, "a" );
    else
        outfile = fopen( target, "w" );
    
    if( outfile == NULL )
    {
        printf("ERROR: can't open file %s\n",target);
        return( -1 );
    }

    /* Re-Init */
    rewind( infile );
    init_cstatus( &c_status );
 
    ptr = strrchr( target, '/' );
    if( !ptr )
        ptr = target;
    else
        ptr++;

    fprintf( outfile, "\n/*\n * Prototypes for '%s'\n */\n", ptr );


    while( !feof( infile ) )
    {
        fgets( buf, sizeof( buf ), infile );
        line++;
        if( feof( infile ) )
            break;
        c_parse_line( buf, line );
    }

    fclose( infile );
    written = ftell( outfile );
    fclose( outfile );

    sprintf( HelpString, "\n    Done!    \n    %ld bytes written to '%s'.    \n", written, target );
    error_dialog( HelpString, "Prototype Generator" );

    tools_window_destroy( NULL, NULL );
    
    return( 1 );
}


glong c_parse_line( gchar *buf, glong line )
{
    gchar key[MAXLEN];
    gchar *ptr;
    gchar cmp[MAXLEN];
    glong kc = 0;
    glong i;
    static c_status c_status;
    static glong waiting = 0;

    /* backup the complete original line */
    if( !waiting )
        strcpy( org_line, buf );
    else
        strcat( org_line, buf );

    for(i=0;i<strlen(buf);i++)
    {
        c_parse_special( buf, i, &c_status );

        if( c_status.comment || c_status.hyph || c_status.dhyph )
            continue;

        if( c_status.klammern_1 && waiting )
        {
            waiting = 0;
            ptr = strchr( org_line, ')' );
            if( !ptr )
            {
                printf("ERROR: incomplete function head.. this point should never be reached\n" );
                exit( -1 );
            }
            else
            {
                ptr = strchr( org_line, '{' );
                if( !ptr )
                {
                    printf("ERROR: something is going wrong here....aborting!\n" );
                    exit( -1 );
                }
                
                ptr--;
                
                while( *ptr != ')' )
                {
                    ptr--;
                }

                ptr++;
                *ptr = ';';
                ptr++;
                *ptr = '\0';
                if( !GTK_TOGGLE_BUTTON( cb_static )->active )
                {
                    fprintf( outfile, "%s\n",org_line);
                }
                else
                {
                    if( sscanf( org_line, "%s\n", cmp ) != 1 )
                    {
                        fprintf( outfile, "%s\n",org_line);
                    }
                    else
                    {
                        if( strcmp( cmp, "static" ) )
                        {
                            fprintf( outfile, "%s\n",org_line);
                        }
                    }
                }
                continue;
            }
        }

        if( buf[i] == ';' && waiting )
            waiting = 0;

        if( c_status.klammern_1 )
            continue;

        switch( buf[i] )
        {
            case '(':
                if( kc != 0 )
                {
                    key[kc] = '\0';
                    kc = 0;

                    waiting = 1;
                }
                break;

            case ')':
            case ';':
            case '=':
            case ' ':
            case '\t':
            case '/':
            case '*':
            case '+':
            case '-':
                kc = 0;
                break;

            default:
                key[kc] = buf[i];
                kc++;
                break;
        }
    }

    return( 1 );
}


/*
 * Dialog.: Prototype Generator
 */
void gen_proto( GtkWidget *widget, gpointer data )
{
    GtkWidget *vbox;
    GtkWidget *hbox;
    GtkWidget *label;
    GtkWidget *hsep;
    GtkWidget *button;
    

    if( tools_window )
        return;
    
    tools_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    gtk_widget_set_usize( tools_window, 300, 190 );
    gtk_window_set_title( GTK_WINDOW( tools_window ), "Tools - Prototype Generator" );
    gtk_signal_connect( GTK_OBJECT( tools_window ), "destroy",
                        GTK_SIGNAL_FUNC( tools_window_destroy ), NULL );

    vbox = gtk_vbox_new( FALSE, 0 );
    gtk_container_add( GTK_CONTAINER( tools_window ), vbox );
    gtk_widget_show( vbox );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 10 );
    gtk_widget_show( hbox );

    label = gtk_label_new( "C Source" );
    gtk_box_pack_start( GTK_BOX( hbox ), label, FALSE, TRUE, 5 );
    gtk_widget_show( label );

    e_source = gtk_entry_new_with_max_length( 255 );
    gtk_box_pack_start( GTK_BOX( hbox ), e_source, TRUE, TRUE, 5 );
    gtk_widget_grab_focus( e_source );
    gtk_widget_show( e_source );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 10 );
    gtk_widget_show( hbox );

    label = gtk_label_new( "Target File" );
    gtk_box_pack_start( GTK_BOX( hbox ), label, FALSE, TRUE, 5 );
    gtk_widget_show( label );

    e_target = gtk_entry_new_with_max_length( 255 );
    gtk_box_pack_start( GTK_BOX( hbox ), e_target, TRUE, TRUE, 5 );
    gtk_widget_show( e_target );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );

    cb_append = gtk_check_button_new_with_label( "Append to Targetfile" );
    gtk_box_pack_start( GTK_BOX( hbox ), cb_append, FALSE, TRUE, 5 );
    gtk_widget_show( cb_append );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );

    cb_static = gtk_check_button_new_with_label( "Skip Static Declarations" );
    gtk_box_pack_start( GTK_BOX( hbox ), cb_static, FALSE, TRUE, 5 );
    gtk_widget_show( cb_static );

    hsep = gtk_hseparator_new();
    gtk_box_pack_start( GTK_BOX( vbox ), hsep, FALSE, TRUE, 5 );
    gtk_widget_show( hsep );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 10 );
    gtk_widget_show( hbox );

#ifdef HAVE_GNOME
	button = gnome_stock_button( GNOME_STOCK_BUTTON_OK );
#else
    button = gtk_button_new_with_label( "Start!" );
#endif
    gtk_box_pack_start( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( gen_proto_start ), NULL );
    gtk_widget_show( button );

    gtk_widget_show( tools_window );
}



gI_tool *gI_tool_new()
{
    static gI_tool *tool;

    tool = g_malloc( sizeof( gI_tool ) );

    return( tool );
}


void gI_tool_init( gI_tool *tool )
{
}


static void gI_tool_save( gI_tool *tool )
{
    FILE *toolfile;
    gchar tfwp[MAXLEN];

    if( !tool )
        return;

    g_snprintf( tfwp, MAXLEN, "%s/%s.tl", tools_path, tool->name );
    
    toolfile = fopen( tfwp, "w" );
    if( !toolfile )
    {
        /* error handling */
        return;
    }


    fprintf( toolfile, "%s\n", tool->name );
    fprintf( toolfile, "%s\n", tool->menu_item_name );
    fprintf( toolfile, "%s\n", tool->cmdline );
    fprintf( toolfile, "%d\n", tool->output );


    fclose( toolfile );
}


void gI_tool_lookup( gchar *toolname )
{
    gchar *tf;
    FILE *toolfile;
    gI_tool *tool;
    gchar buf[STRLEN];

    g_snprintf( buf, STRLEN, "%s.tl", toolname );
    tf = g_strconcat( tools_path, "/", buf, NULL );
    if( file_exist( tf ) )
    {
        toolfile = fopen( tf, "r" );
        if( !toolfile )
        {
            /* error handling */
            /* .. this can't happen! */
            g_snprintf( buf, STRLEN, "\n    Unable to Open Tool File '%s'    \n", tf );
            error_dialog( buf, "File Error!" );
            return;
        }

        kz_edit = TRUE;

        tool = gI_tool_new();

        fgets( buf, MAXLEN, toolfile );
        rem_return( buf );
        tool->name = g_strdup( buf );
        fgets( buf, MAXLEN, toolfile );
        rem_return( buf );
        tool->menu_item_name = g_strdup( buf );
        fgets( buf, MAXLEN, toolfile );
        rem_return( buf );
        tool->cmdline = g_strdup( buf );
        fgets( buf, MAXLEN, toolfile );
        tool->output = atoi( buf );

        /* show! */
        gtk_entry_set_text( GTK_ENTRY( e_name ), tool->name );
        gtk_entry_set_text( GTK_ENTRY( e_cmdline ), tool->cmdline );
        gtk_entry_set_text( GTK_ENTRY( e_menu_item_name ), tool->menu_item_name );
        
        /* switch the right one on */
        switch( tool->output )
        {
            case TOOL_OUTPUT_NEW:
                gtk_widget_activate( r_new );
                break;

            case TOOL_OUTPUT_APPEND:
                gtk_widget_activate( r_append );
                break;

            case TOOL_OUTPUT_BOX:
                gtk_widget_activate( r_box );
                break;

            case TOOL_OUTPUT_IGNORE:
                gtk_widget_activate( r_ignore );
                break;

            case TOOL_OUTPUT_INSERT:
                gtk_widget_activate( r_insert );
                break;

			case TOOL_OUTPUT_XTERM:
				gtk_widget_activate( r_xterm );
        }

        g_free( tool );
    }

    g_free( tf );
}


static void show_tool( GtkWidget *widget, gpointer data )
{
    gI_tool_lookup( gtk_entry_get_text( GTK_ENTRY( e_name ) ) );
}


static void insert_parameters( gchar *target, gchar *source )
{
    glong source_len;
    glong i,j=0;
    gI_document *current;

    current = gI_document_get_current( main_window );
    source_len = strlen( source );
    
    for(i=0;i<source_len;i++)
    {
        if( source[i] != '%' )
        {
            target[j++] = source[i];
        }
        else
        {
            i++;

            switch( source[i] )
            {
                case 'f':
                    target[j] = '\0'; 
                    strcat( target, current->filename );
                    j += strlen( current->filename );
                    break;

                default:
                    target[j++] = '%';
                    target[j++] = source[i];
                    break;
            }
        }
    }

    target[j++] = '\0';
}


static void custom_tool_activate( GtkWidget *widget, gI_tool *tool )
{
    gchar exec_string[MAXLEN];
    gchar tmpstring[STRLEN];
    FILE *tmpfile;
    gchar *tempname = NULL;
    GtkWidget *text;
    gchar buf[MAXLEN];
    gchar title[STRLEN];
    GtkWidget *scrolled_win;
    gI_document *document;

    g_print( "tool->name: %s\n", tool->name );
    g_print( "tool->menu_item_name: %s\n",tool->menu_item_name);
    g_print( "tool->cmdline: %s\n",tool->cmdline);
    g_print( "tool->output: %d\n", tool->output);

    insert_parameters( exec_string, tool->cmdline );

    if( tool->output == TOOL_OUTPUT_IGNORE )
    {
        strcat( exec_string, " 1>/dev/null 2>&1" );
    }
    else
    {
		if( tool->output == TOOL_OUTPUT_XTERM )
		{
			g_snprintf( tmpstring, sizeof(tmpstring), "%s -T \"%s\"  -e %s &", cfg->xterm, tool->menu_item_name, exec_string );
			strcpy( exec_string, tmpstring );
		}
		else
		{
		        tempname = tempnam( cfg->tmpdir, g_strconcat( tool->name, "XXXXX", NULL ) );
   		    	g_snprintf( tmpstring, STRLEN, " 1>\"%s\" 2>&1", tempname );
   	     		strcat( exec_string, tmpstring );
		}
    }

    system( exec_string );

	if( tool->output == TOOL_OUTPUT_XTERM )
		return;  

    if( tool->output != TOOL_OUTPUT_IGNORE )
    {
        tmpfile = fopen( tempname, "r" );
        if( !tmpfile )
        {
            /* error handling */
            g_snprintf( buf, MAXLEN, "\n    Unable to Open Tool File '%s'    \n", tempname );
            error_dialog( buf, "File Error!" );
            return;
        }

        if( tool->output == TOOL_OUTPUT_BOX )
        {
            custom_tools_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
            gtk_widget_set_usize( custom_tools_window, 450, 250 );
            gtk_window_set_position( GTK_WINDOW( custom_tools_window ), GTK_WIN_POS_MOUSE );
            g_snprintf( title, STRLEN, "Output of '%s'", tool->name );
            gtk_window_set_title( GTK_WINDOW( custom_tools_window ), title );
            gtk_signal_connect( GTK_OBJECT( custom_tools_window ), "destroy",
                                GTK_SIGNAL_FUNC( custom_tools_window_destroy ), NULL );

            scrolled_win = gtk_scrolled_window_new( NULL, NULL );
            gtk_container_add( GTK_CONTAINER( custom_tools_window ), scrolled_win );
            gtk_widget_show( scrolled_win );
            
            text = gtk_text_new( NULL, gtk_scrolled_window_get_vadjustment( GTK_SCROLLED_WINDOW( scrolled_win ) ) );
            gtk_container_add( GTK_CONTAINER( scrolled_win ), text );
            gtk_widget_show( text );

            gtk_widget_realize( text );

            while( fgets( buf, MAXLEN, tmpfile ) )
            {
                gtk_text_insert( GTK_TEXT( text ), NULL, NULL, NULL, buf, strlen(buf) );
            }

            gtk_widget_show( custom_tools_window );
        }

        if( tool->output == TOOL_OUTPUT_NEW )
        {
            document = gI_document_new( main_window );

            while( fgets( buf, MAXLEN, tmpfile ) )
            {
                gtk_text_insert( GTK_TEXT( document->text ), NULL, NULL, NULL, buf, strlen(buf) );
            }

            gtk_signal_emit_by_name( GTK_OBJECT( document->text ), "changed" );

        }

        if( tool->output == TOOL_OUTPUT_APPEND )
        {
            document = gI_document_get_current( main_window );

            gtk_text_set_point( GTK_TEXT( document->text ), gtk_text_get_length( GTK_TEXT( document->text ) ) );

            while( fgets( buf, MAXLEN, tmpfile ) )
            {
                gtk_text_insert( GTK_TEXT( document->text ), NULL, NULL, NULL, buf, strlen(buf) );
            }

            gtk_signal_emit_by_name( GTK_OBJECT( document->text ), "changed" );
        }

        if( tool->output == TOOL_OUTPUT_INSERT )
        {
            document = gI_document_get_current( main_window );

            while( fgets( buf, MAXLEN, tmpfile ) )
            {
                gtk_text_insert( GTK_TEXT( document->text ), NULL, NULL, NULL, buf, strlen(buf) );
            }

            gtk_signal_emit_by_name( GTK_OBJECT( document->text ), "changed" );
        }

        fclose( tmpfile );

        remove( tempname );

        g_free( tempname );
    }
}


#ifdef HAVE_GNOME
void menu_add_tool( gI_window *window, gI_tool *tool )
{
    gchar entry[200];
    GtkWidget *widget;
    GtkMenuShell *menushell;
    GtkMenuBar *menubar;
    GtkWidget *parent;
    gint pos;

    menubar = GTK_MENU_BAR( GNOME_APP( window->window )->menubar );
    menushell = &menubar->menu_shell; 
    parent = gnome_app_find_menu_pos( GTK_WIDGET( menushell ), "Tools/<Separator>", &pos ); 

    widget = gtk_menu_item_new_with_label( tool->menu_item_name );
    gtk_menu_shell_insert( GTK_MENU_SHELL( parent ), widget, pos );
    gtk_signal_connect( GTK_OBJECT( widget ), "activate",
			GTK_SIGNAL_FUNC( custom_tool_activate ), (gpointer) tool );
    gtk_widget_show( widget );

    /* add new item to association list */
    g_snprintf( entry, 200, "/Tools/%s", tool->menu_item_name ); 
    gI_PWassoc_add( entry, widget ); 
}
#else
void menu_add_tool( gI_window *window, gI_tool *tool )
{
    GtkItemFactoryEntry ife[1];
    gchar entry[200];

    g_snprintf( entry, 200, "/Tools/%s", tool->menu_item_name ); 

    ife[0].path = entry;
    ife[0].accelerator = NULL;
    ife[0].callback = GTK_SIGNAL_FUNC( custom_tool_activate ); 
    ife[0].callback_action = 0;
    ife[0].item_type = NULL;

    gtk_item_factory_create_item( factory, ife, (gpointer) tool, 2 );
}
#endif


void menu_remove_tool( gchar *menu_item_name )
{
    gchar path[STRLEN];
    GtkWidget *widget;

    g_snprintf( path, STRLEN, "/Tools/%s", menu_item_name );

    widget = menus_get_item_widget( path );
    if( widget )
        gtk_widget_destroy( widget );
    else
		printf( "Unable to destroy %s\n",path );

#ifdef HAVE_GNOME
    /* remove association */
    gI_PWassoc_remove( path );
#endif
}


void rem_return( gchar *str )
{
    gchar *ptr;

    ptr = strrchr( str, '\n' );
    if( ptr )
    {
        *ptr = '\0';
    }
}


void add_all_tools( gI_window *window )
{
    DIR *dir;
    struct dirent *entry;
    FILE *toolfile;
    gchar buf[MAXLEN];
    gI_tool *tool;
    gchar tfwp[MAXLEN];

    dir = opendir( tools_path );

    while( (entry = readdir( dir ) ) )
    {
        if( !strstr( entry->d_name, ".tl" ) )
            continue;
        
        tool = gI_tool_new();
        
        g_snprintf( tfwp, MAXLEN, "%s/%s", tools_path, entry->d_name );
        toolfile = fopen( tfwp, "r" );
        if( !toolfile )
        {
            /* error handling */
            g_snprintf( buf, MAXLEN, "\n    Unable to Open Tool File '%s'    \n", entry->d_name );
            error_dialog( buf, "File Error!" );
            continue;
        }

        fgets( buf, MAXLEN, toolfile );
        rem_return( buf );
        tool->name = g_strdup( buf );
        fgets( buf, MAXLEN, toolfile );
        rem_return( buf );
        tool->menu_item_name = g_strdup( buf );
        fgets( buf, MAXLEN, toolfile );
        rem_return( buf );
        tool->cmdline = g_strdup( buf );
        fgets( buf, MAXLEN, toolfile );
        tool->output = atoi( buf );

        fclose( toolfile );

        menu_add_tool( window, tool );
    }

    closedir( dir );
}


static void custom_tools_help_select( GtkWidget *widget, gpointer data )
{
    static GtkWidget *help_window = NULL;
    GtkWidget *hbox, *vbox;
    GtkWidget *text;
    GtkWidget *vscrollbar;
    GtkWidget *button;
    GtkWidget *hsep;
    glong i;

    if( help_window )
        return;

    help_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    gtk_window_set_title( GTK_WINDOW( help_window ), "Custom Tools Help" );
    gtk_widget_set_usize( help_window, 600, 400 );

    vbox = gtk_vbox_new( FALSE, 0 );
    gtk_container_add( GTK_CONTAINER( help_window ), vbox );
    gtk_widget_show( vbox );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, TRUE, TRUE, 5 );
    gtk_widget_show( hbox );
    
    text = gtk_text_new( NULL, NULL );
    gtk_box_pack_start( GTK_BOX( hbox ), text, TRUE, TRUE, 5 );
    gtk_widget_show( text );

    vscrollbar = gtk_vscrollbar_new( GTK_TEXT( text )->vadj );
    gtk_box_pack_end( GTK_BOX( hbox ), vscrollbar, FALSE, TRUE, 5 );
    gtk_widget_show( vscrollbar );

    hsep = gtk_hseparator_new();
    gtk_box_pack_start( GTK_BOX( vbox ), hsep, FALSE, TRUE, 5 );
    gtk_widget_show( hsep );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 10 );
    gtk_widget_show( hbox );

#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_CLOSE );
#else
    button = gtk_button_new_with_label( "  Close  " );
#endif
    gtk_box_pack_start( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect_object( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( gtk_widget_destroy ), GTK_OBJECT( help_window ) );
    GTK_WIDGET_SET_FLAGS( button, GTK_CAN_DEFAULT );
    gtk_widget_grab_default( button );
    gtk_widget_show( button );

    gtk_widget_show( help_window );

    /* insert text */
    gtk_text_freeze( GTK_TEXT( text ) );
    for(i=0;i<(sizeof( tools_help_text ) / sizeof( tools_help_text[0] ) );i++)
        gtk_text_insert( GTK_TEXT( text ), NULL, &text->style->black, NULL, tools_help_text[i], strlen( tools_help_text[i] ) );
    gtk_text_thaw( GTK_TEXT( text ) );
}


static void cmdline_file_ok( GtkWidget *widget, GtkWidget *filesel )
{
    gchar *filename;

    filename = gtk_file_selection_get_filename( GTK_FILE_SELECTION( filesel ) );

    gtk_entry_set_text( GTK_ENTRY( e_cmdline ), filename );

    if( GTK_WIDGET_VISIBLE( filesel ) )
        gtk_widget_hide( filesel );
}


static void cmdline_file_cancel( GtkWidget *widget, GtkWidget *filesel )
{
    if( GTK_WIDGET_VISIBLE( filesel ) )
        gtk_widget_hide( filesel );
}


static void cmdline_browse_select( GtkWidget *widget, gpointer data )
{
    static GtkWidget *filesel = NULL;

    if( !filesel )
    {
        filesel = gtk_file_selection_new( "Select File..." );
        gtk_signal_connect( GTK_OBJECT( filesel ), "destroy",
                            GTK_SIGNAL_FUNC( cmdline_file_cancel ), filesel );
        gtk_signal_connect( GTK_OBJECT( GTK_FILE_SELECTION( filesel )->ok_button ), "clicked",
                            GTK_SIGNAL_FUNC( cmdline_file_ok ), filesel  );
        gtk_signal_connect( GTK_OBJECT( GTK_FILE_SELECTION( filesel )->cancel_button ), "clicked",
                            GTK_SIGNAL_FUNC( cmdline_file_cancel ), filesel );
    }

    if( !GTK_WIDGET_VISIBLE( filesel ) )
        gtk_widget_show( filesel );
}


static void custom_tools_ok_select( GtkWidget *widget, gpointer data )
{
    gI_tool *tool;
    gchar *ptr;

    ptr = gtk_entry_get_text( GTK_ENTRY( e_cmdline ) );
    if( !ptr || isempty( ptr ) )
        return;

    ptr = gtk_entry_get_text( GTK_ENTRY( e_menu_item_name ) );
    if( !ptr || isempty( ptr ) )
        return;

    ptr = gtk_entry_get_text( GTK_ENTRY( e_name ) );
    if( !ptr || isempty( ptr ) )
        return;

    if( kz_edit )
    {
        kz_edit = FALSE;
        menu_remove_tool( gtk_entry_get_text( GTK_ENTRY( e_menu_item_name ) ) );
    }

    tool = gI_tool_new();

    ptr = gtk_entry_get_text( GTK_ENTRY( e_name ) );
    tool->name = g_strdup( ptr );
    
    ptr = gtk_entry_get_text( GTK_ENTRY( e_menu_item_name ) );
    tool->menu_item_name = g_strdup( ptr );

    ptr = gtk_entry_get_text( GTK_ENTRY( e_cmdline ) );
    tool->cmdline = g_strdup( ptr );

    if( GTK_TOGGLE_BUTTON( r_new )->active )
        tool->output = TOOL_OUTPUT_NEW;
    if( GTK_TOGGLE_BUTTON( r_append )->active )
        tool->output = TOOL_OUTPUT_APPEND;
    if( GTK_TOGGLE_BUTTON( r_box )->active )
        tool->output = TOOL_OUTPUT_BOX;
    if( GTK_TOGGLE_BUTTON( r_ignore )->active )
        tool->output = TOOL_OUTPUT_IGNORE;
    if( GTK_TOGGLE_BUTTON( r_insert )->active )
        tool->output = TOOL_OUTPUT_INSERT;
    if( GTK_TOGGLE_BUTTON( r_xterm )->active )
        tool->output = TOOL_OUTPUT_XTERM;

    gI_tool_save( tool );

    menu_add_tool( main_window, tool );

    custom_tools_window_destroy( NULL, NULL );
}


/*
 ---------------------------------------------------------------------
     Function: custom_tools()
     Desc: Callback-Function /Preferences/Custom Tools...
 ---------------------------------------------------------------------
*/

void custom_tools( GtkWidget *widget, gpointer data )
{
    GtkWidget *vbox;
    GtkWidget *hbox;
    GtkWidget *label;
    GtkWidget *button;
    GtkWidget *frame;
    GtkWidget *frame_vbox;
    GSList *output_group;
    GtkWidget *hsep;


    if( custom_tools_window )
        return;

    custom_tools_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    gtk_widget_set_usize( custom_tools_window, 400, 415 );
    gtk_window_set_title( GTK_WINDOW( custom_tools_window ), "Tool Configuration..." );
    gtk_signal_connect( GTK_OBJECT( custom_tools_window ), "destroy",
                        GTK_SIGNAL_FUNC( custom_tools_window_destroy ), NULL );
    gtk_container_set_border_width( GTK_CONTAINER( custom_tools_window ), 10 );
    gtk_widget_realize( custom_tools_window );

    vbox = gtk_vbox_new( FALSE, 0 );
    gtk_container_add( GTK_CONTAINER( custom_tools_window ), vbox );
    gtk_widget_show( vbox );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

    label = gtk_label_new( "Name:" );
    gtk_box_pack_start( GTK_BOX( hbox ), label, FALSE, TRUE, 5 );
    gtk_widget_show( label );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );

    e_name = gtk_entry_new_with_max_length( 255 );
    gtk_box_pack_start( GTK_BOX( hbox ), e_name, FALSE, TRUE, 5 );
    gtk_widget_grab_focus( e_name );
    gtk_signal_connect( GTK_OBJECT( e_name ), "activate",
                        GTK_SIGNAL_FUNC( show_tool ), NULL );
    gtk_widget_show( e_name );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );
    
    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

    label = gtk_label_new( "Command Line:" );
    gtk_box_pack_start( GTK_BOX( hbox ), label, FALSE, TRUE, 5 );
    gtk_widget_show( label );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );

    e_cmdline = gtk_entry_new_with_max_length( 255 );
    gtk_box_pack_start( GTK_BOX( hbox ), e_cmdline, TRUE, TRUE, 5 );
    gtk_widget_show( e_cmdline );

    button = gtk_button_new_with_label( "   Browse...   " );
    gtk_box_pack_start( GTK_BOX( hbox ), button, FALSE, TRUE, 10 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( cmdline_browse_select ), NULL );
    gtk_widget_show( button );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );
    
    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

    label = gtk_label_new( "Menu Item Name:" );
    gtk_box_pack_start( GTK_BOX( hbox ), label, FALSE, TRUE, 5 );
    gtk_widget_show( label );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );

    e_menu_item_name = gtk_entry_new_with_max_length( 32 );
    gtk_box_pack_start( GTK_BOX( hbox ), e_menu_item_name, TRUE, TRUE, 5 );
    gtk_widget_show( e_menu_item_name );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 20 );
    gtk_widget_show( hbox );
    
    frame = gtk_frame_new( "Command Output" );
    gtk_box_pack_start( GTK_BOX( hbox ), frame, TRUE, TRUE, 5 );
    gtk_widget_show( frame );

    frame_vbox = gtk_vbox_new( FALSE, 0 );
    gtk_container_add( GTK_CONTAINER( frame ), frame_vbox );
    gtk_widget_show( frame_vbox );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( frame_vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );

    r_new = gtk_radio_button_new_with_label( NULL, "Create New File" );
    gtk_box_pack_start( GTK_BOX( hbox ), r_new, FALSE, TRUE, 5 );
    gtk_widget_show( r_new );

    output_group = gtk_radio_button_group( GTK_RADIO_BUTTON( r_new ) );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( frame_vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );
    
    r_append = gtk_radio_button_new_with_label( output_group, "Append to Current File" );
    gtk_box_pack_start( GTK_BOX( hbox ), r_append, FALSE, TRUE, 5 );
    gtk_widget_show( r_append );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( frame_vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );

    output_group = gtk_radio_button_group( GTK_RADIO_BUTTON( r_append ) );
    
    r_insert = gtk_radio_button_new_with_label( output_group, "Insert at Cursor Position" );
    gtk_box_pack_start( GTK_BOX( hbox ), r_insert, FALSE, TRUE, 5 );
    gtk_widget_show( r_insert );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( frame_vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );

    output_group = gtk_radio_button_group( GTK_RADIO_BUTTON( r_insert ) );   

    r_box = gtk_radio_button_new_with_label( output_group, "Output to Text Box" );
    gtk_box_pack_start( GTK_BOX( hbox ), r_box, FALSE, TRUE, 5 );
    gtk_widget_show( r_box );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( frame_vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );
 
    output_group = gtk_radio_button_group( GTK_RADIO_BUTTON( r_box ) );   
   
    r_ignore = gtk_radio_button_new_with_label( output_group, "Ignore Output" );
    gtk_box_pack_start( GTK_BOX( hbox ), r_ignore, FALSE, TRUE, 5 );
    gtk_widget_show( r_ignore );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( frame_vbox ), hbox, FALSE, TRUE, 0 );
    gtk_widget_show( hbox );
	
    output_group = gtk_radio_button_group( GTK_RADIO_BUTTON( r_ignore ) );   

    r_xterm = gtk_radio_button_new_with_label( output_group, "Run in XTerm" );
    gtk_box_pack_start( GTK_BOX( hbox ), r_xterm, FALSE, TRUE, 5 );
    gtk_widget_show( r_xterm );

    hsep = gtk_hseparator_new();
    gtk_box_pack_start( GTK_BOX( vbox ), hsep, FALSE, TRUE, 5 );
    gtk_widget_show( hsep );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_OK );
#else
    button = gtk_button_new_with_label( "OK" );
#endif
    gtk_box_pack_start( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( custom_tools_ok_select ), NULL );
    gtk_widget_show( button );

#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_CANCEL );
#else
    button = gtk_button_new_with_label( "Cancel" );
#endif
    gtk_box_pack_start( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( custom_tools_window_destroy ), NULL );
    gtk_widget_show( button );

#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_HELP );
#else
    button = gtk_button_new_with_label( "Help" );
#endif
    gtk_box_pack_start( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( custom_tools_help_select ), NULL );
    gtk_widget_show( button );

    gtk_widget_show( custom_tools_window );
}


static void tools_ascii_table_select( GtkWidget *clist, gint row, gint column, GdkEventButton *bevent )
{
	if( !bevent )
		return;

	if( bevent->type == GDK_2BUTTON_PRESS )
	{
		gI_document *current;
		gchar *ch;

		current = gI_document_get_current( main_window );
		if( !current )
			return;

		gtk_clist_get_text( GTK_CLIST( clist ), row, 0, &ch );
		ch += 2;
	
		gtk_text_insert( GTK_TEXT( current->text ), NULL, NULL, NULL, ch, 1 );	

		gI_document_set_changed( current );
	}
}


void tools_ascii_table( GtkWidget *widget, gpointer data )
{
	GtkWidget *window;
	GtkWidget *scrwindow;
	GtkWidget *clist;
	gchar *items[3];
	gchar ch[10];
	gchar dec[10];
	gchar hex[10];
	gint i;
	gchar *list_titles[] = { "Char", "Dec#", "Hex#" };

	window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
	gtk_signal_connect( GTK_OBJECT( window ), "destroy",
							GTK_SIGNAL_FUNC( gtk_widget_destroyed ), NULL );
	gtk_window_set_title( GTK_WINDOW( window ), "Tools - ASCII Table" );
	gtk_widget_set_usize( window, 200, 400 );

	scrwindow = gtk_scrolled_window_new( NULL, NULL );
	gtk_container_add( GTK_CONTAINER( window ), scrwindow );

	clist = gtk_clist_new_with_titles( 3, list_titles );
	gtk_signal_connect( GTK_OBJECT( clist ), "select_row",
						GTK_SIGNAL_FUNC( tools_ascii_table_select ), NULL );
	gtk_container_add( GTK_CONTAINER( scrwindow ), clist );
	gtk_clist_column_titles_passive( GTK_CLIST( clist ) );
	gtk_clist_set_column_width( GTK_CLIST( clist ), 0, 40 );
	gtk_clist_set_column_width( GTK_CLIST( clist ), 1, 40 );
	gtk_clist_set_column_width( GTK_CLIST( clist ), 2, 40 );

	/* fill list */
	for(i=0;i<256;i++)
	{
		sprintf( ch, "%3c", i );
		sprintf( dec, "%3d", i );
		sprintf( hex, "0x%2.2X", i );

g_print( "%s %s %s\n", ch, dec, hex );

		items[0] = ch;
		items[1] = dec;
		items[2] = hex;

		gtk_clist_append( GTK_CLIST( clist ), items );
	}

	gtk_widget_show_all( window );
}


#ifdef HAVE_GNOME
void tools_calculator( GtkWidget *widget, gpointer data )
{
	GtkWidget *window;
	GtkWidget *calc;

	window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
	gtk_window_set_title( GTK_WINDOW( window ), "Tools - Calculator" );
	gtk_signal_connect( GTK_OBJECT( window ), "destroy",
						GTK_SIGNAL_FUNC( gtk_widget_destroyed ),
						NULL );

	calc = gnome_calculator_new();
	gtk_container_add( GTK_CONTAINER( window ), calc );
	gtk_window_add_accel_group( GTK_WINDOW( window ),
								GNOME_CALCULATOR( calc )->accel );
	
	gtk_widget_show_all( window );		
}
#endif

