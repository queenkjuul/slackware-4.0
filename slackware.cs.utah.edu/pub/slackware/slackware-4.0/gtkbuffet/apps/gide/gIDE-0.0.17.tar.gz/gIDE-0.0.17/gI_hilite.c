/* $Header: /cvs/gIDE/gI_hilite.c,v 1.10 1998/12/21 15:35:13 sk Exp $ */
/*  gIDE
 *  Copyright (C) 1998 Steffen Kern
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifdef HAVE_GTKTEXT_PATCH

#include <gtk/gtk.h>
#include "gtkeditor.h"

#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include "structs.h"
#include "gI_document.h"
#include "gI_menus.h"

#include "gI_common.h"

#include "gI_hilite.h"

extern gI_window *main_window;

typedef struct _Pattern {
  gchar                   *name;
  GtkEditorHilitePatterns  pat;
} Pattern;
static GList *known_patterns = NULL;
static GList *known_pattern_names = NULL;

static void            patname_changed_cb          (GtkEntry    *nameentry,
						    gI_pat_dialog  *dd);
static void            install_pattern_cb          (GtkWidget   *dummy,
						    gI_pat_dialog  *dd);
static void            close_dialog                (GtkWidget   *dummy,
						    gI_pat_dialog  *dd);
static void            free_pattern                (Pattern     *pat);


/* --<pattern widget>--------------------------------------------------- */
GtkWidget*
gI_hilite_get_pattern_widget (gI_pat_dialog *pd)
{
  GtkWidget *vbox;
  GtkWidget *hbox;
  GtkWidget *label;
  GtkWidget *patname;

  GtkWidget *hseparator;
  GtkWidget *table;

  GtkWidget *combeg;
  GtkWidget *comend;
  GtkWidget *strbeg;
  GtkWidget *strend;
  GtkWidget *keywords;

  vbox = gtk_vbox_new (FALSE, 5);

  hbox = gtk_hbox_new (FALSE, 5);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 10);
  gtk_widget_show (hbox);

  label = gtk_label_new ("Pattern name:");
  gtk_widget_show (label);
  gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, TRUE, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_LEFT);
  gtk_misc_set_padding (GTK_MISC (label), 5, 0);

  patname = gtk_combo_new();
  pd->patname = GTK_COMBO (patname);
  if (known_pattern_names) {
    gtk_combo_set_popdown_strings (GTK_COMBO (patname), known_pattern_names);
  }
  gtk_signal_connect (GTK_OBJECT (GTK_COMBO (patname)->entry), "changed",
		      GTK_SIGNAL_FUNC (patname_changed_cb), pd);
  gtk_widget_show (patname);
  gtk_box_pack_start (GTK_BOX (hbox), patname, TRUE, TRUE, 5);

  hseparator = gtk_hseparator_new ();
  gtk_widget_show (hseparator);
  gtk_box_pack_start (GTK_BOX (vbox),
		      hseparator, TRUE, TRUE, 0);

  /*---------------------------------------------------*/

  table = gtk_table_new (3, 4, FALSE);
  gtk_widget_show (table);
  gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 10);

  label = gtk_label_new("Comment begin:");
  gtk_widget_show (label);
  gtk_table_attach (GTK_TABLE (table), label, 0, 1, 0, 1,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_LEFT);
  gtk_misc_set_padding (GTK_MISC (label), 5, 0);

  combeg = gtk_entry_new();
  pd->combeg = GTK_ENTRY (combeg);
  gtk_widget_show (combeg);
  gtk_table_attach (GTK_TABLE (table), combeg, 1, 2, 0, 1,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label = gtk_label_new ("Comment end:");
  gtk_widget_show (label);
  gtk_table_attach (GTK_TABLE (table), label, 2, 3, 0, 1,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_LEFT);
  gtk_misc_set_padding (GTK_MISC (label), 6, 0);

  comend = gtk_entry_new();
  pd->comend = GTK_ENTRY (comend);
  gtk_widget_show (comend);
  gtk_table_attach (GTK_TABLE (table), comend, 3, 4, 0, 1,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label = gtk_label_new ("String begin:");
  gtk_widget_show (label);
  gtk_table_attach (GTK_TABLE (table), label, 0, 1, 1, 2,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_LEFT);
  gtk_misc_set_padding (GTK_MISC (label), 5, 0);

  strbeg = gtk_entry_new();
  pd->strbeg = GTK_ENTRY (strbeg);
  gtk_widget_show (strbeg);
  gtk_table_attach (GTK_TABLE (table), strbeg, 1, 2, 1, 2,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label = gtk_label_new ("String end:");
  gtk_widget_show (label);
  gtk_table_attach (GTK_TABLE (table), label, 2, 3, 1, 2,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_LEFT);
  gtk_misc_set_padding (GTK_MISC (label), 5, 0);

  strend = gtk_entry_new ();
  pd->strend = GTK_ENTRY (strend);
  gtk_widget_show (strend);
  gtk_table_attach (GTK_TABLE (table), strend, 3, 4, 1, 2,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label = gtk_label_new ("Keywords:");
  gtk_widget_show (label);
  gtk_table_attach (GTK_TABLE (table), label, 0, 1, 2, 3,
		    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_LEFT);
  gtk_misc_set_padding (GTK_MISC (label), 5, 0);

  keywords = gtk_entry_new();
  pd->keywords = GTK_ENTRY (keywords);
  gtk_widget_show (keywords);
  gtk_table_attach (GTK_TABLE (table), keywords, 1, 4, 2, 3,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  return vbox;
}

/* --<menu callbacks>--------------------------------------------------- */
void
gI_hilite_set_buffer_patterns_cb (void)
{
  GtkWidget *dialog;
  GtkWidget *vbox;
  GtkWidget *bbox;
  GtkWidget *ok, *cancel;

  gI_document *doc = gI_document_get_current ( main_window );

  gI_pat_dialog *pd = g_new (gI_pat_dialog, 1);
  pd->buf = GTK_EDITOR ( doc->text );

  dialog = gtk_dialog_new ();
  pd->dialog = dialog;
  gtk_window_set_title (GTK_WINDOW (dialog), "Specify Patterns");
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_MOUSE);
  gtk_window_set_policy (GTK_WINDOW (dialog), FALSE, FALSE, FALSE);

  /*----------------------------------------------------------*/
  
  vbox = gI_hilite_get_pattern_widget (pd);
  gtk_widget_show (vbox);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), vbox, TRUE, TRUE, 5);
  

  /*----------------------------------------------------------*/

  bbox = gtk_hbutton_box_new ();
  gtk_button_box_set_layout (GTK_BUTTON_BOX (bbox), GTK_BUTTONBOX_END);

  ok = gtk_button_new_with_label  ("OK");
  GTK_WIDGET_SET_FLAGS (ok, GTK_CAN_DEFAULT);
  gtk_signal_connect (GTK_OBJECT (ok), "clicked",
		      GTK_SIGNAL_FUNC (install_pattern_cb), pd);
  gtk_widget_grab_default (ok);
  gtk_box_pack_start (GTK_BOX (bbox), ok, TRUE, TRUE, 10);
  gtk_widget_show (ok);

  cancel = gtk_button_new_with_label  ("Cancel");
  GTK_WIDGET_SET_FLAGS (cancel, GTK_CAN_DEFAULT);
  gtk_signal_connect (GTK_OBJECT (cancel), "clicked",
		      GTK_SIGNAL_FUNC (close_dialog), pd);
  gtk_box_pack_start (GTK_BOX (bbox), cancel, TRUE, TRUE, 10);
  gtk_widget_show (cancel);

  gtk_container_add (GTK_CONTAINER (GTK_DIALOG (dialog)->action_area), bbox);

  gtk_widget_show (bbox);
  gtk_widget_show (dialog);
}

void
gI_hilite_rehilite (void)
{
  gI_document *doc = gI_document_get_current ( main_window );
  GtkEditor *buf = GTK_EDITOR ( doc->text );
  gtk_editor_hilite_buffer (buf);
}

/* --<dialog callbacks>------------------------------------------ */
static gint
patcmp (Pattern *pat, gchar *name)
{
  g_assert (pat); g_assert (name);
  return strcmp (pat->name, name);
}

static void
patname_changed_cb (GtkEntry *nameentry, gI_pat_dialog *dd)
{
  GList *tmp;
  Pattern *pat;
  gchar *name = gtk_entry_get_text (nameentry);
  if ( (tmp = g_list_find_custom (known_pattern_names, name,
				  (GCompareFunc)strcmp)) ) {
    tmp = g_list_find_custom (known_patterns, name, (GCompareFunc)patcmp);
    g_assert (tmp);
    pat = (Pattern*)tmp->data;
    gtk_entry_set_text (dd->combeg, pat->pat.comment_start);
    gtk_entry_set_text (dd->comend, pat->pat.comment_end);
    gtk_entry_set_text (dd->strbeg, pat->pat.string_start);
    gtk_entry_set_text (dd->strend, pat->pat.string_end);
    gtk_entry_set_text (dd->keywords, pat->pat.keywords);
  }
}

static void
close_dialog (GtkWidget *dummy, gI_pat_dialog *dd)
{
  gtk_widget_destroy (dd->dialog);
  g_free (dd);
}

void
gI_hilite_add_pattern_dia (gI_pat_dialog *pd)
{
  Pattern *pat;
  GtkEditorHiliteRegexps *tmp;
  GList *tmpls;

  pat = g_new (Pattern, 1);
  pat->name = g_strdup (gtk_entry_get_text (GTK_ENTRY (pd->patname->entry)));
  pat->pat.comment_start = g_strdup (gtk_entry_get_text (pd->combeg));
  pat->pat.comment_end = g_strdup (gtk_entry_get_text (pd->comend));
  pat->pat.string_start = g_strdup (gtk_entry_get_text (pd->strbeg));
  pat->pat.string_end = g_strdup (gtk_entry_get_text (pd->strend));
  pat->pat.keywords = g_strdup (gtk_entry_get_text (pd->keywords));

  if (!(pat->name[0] && pat->pat.comment_start[0] && pat->pat.comment_end[0]
	&& pat->pat.string_start[0] && pat->pat.string_end[0]
	&& pat->pat.keywords[0])) {
    free_pattern (pat);
    error_dialog ("You must specify all entries!", "Pattern Error!");
    return;
  }

  if ( !(tmp = gtk_editor_new_regexps (&pat->pat)) ) {
    free_pattern (pat);
    error_dialog ("Regex compile error!", "Pattern Error!");
  } else {
    gtk_editor_destroy_regexps (tmp);
  }

  if ( (tmpls = g_list_find_custom (known_patterns, pat->name,
				  (GCompareFunc)patcmp)) ) {
    free_pattern ((Pattern*)tmpls->data);
    known_patterns = g_list_remove_link (known_patterns, tmpls);
    g_list_free_1 (tmpls);
  }
  known_patterns = g_list_prepend (known_patterns, pat);
  if ( !g_list_find_custom (known_pattern_names, pat->name,
			    (GCompareFunc)strcmp) ) {
    known_pattern_names = g_list_prepend (known_pattern_names, pat->name);
  }

  if (known_pattern_names) {
    gtk_combo_set_popdown_strings (pd->patname, known_pattern_names);
  }
}

void
gI_hilite_add_pattern_dia_cb (GtkWidget *dummy, gI_pat_dialog *pd)
{
  gI_hilite_add_pattern_dia (pd);
}


static void
add_pattern (Pattern *pat)
{
  GList *tmpls;
  GtkEditorHiliteRegexps *tmp;

  g_assert (pat);

  if ( !(tmp = gtk_editor_new_regexps (&pat->pat)) ) {
    free_pattern (pat);
    g_warning ("Regex compile error!");
  } else {
    gtk_editor_destroy_regexps (tmp);
  }

  if ( (tmpls = g_list_find_custom (known_patterns, pat->name,
				    (GCompareFunc)patcmp)) ) {
    free_pattern ((Pattern*)tmpls->data);
    known_patterns = g_list_remove_link (known_patterns, tmpls);
    g_list_free_1 (tmpls);
  }
  known_patterns = g_list_prepend (known_patterns, pat);
  if ( !g_list_find_custom (known_pattern_names, pat->name,
			    (GCompareFunc)strcmp) ) {
    known_pattern_names = g_list_prepend (known_pattern_names, pat->name);
  }
}

/* a wrapper used around add_pattern...needed as a hack for the guile
 * support...maybe it should be re-implemented later...*/
void
gI_hilite_add_named_pattern (const gchar *patname,
			     const GtkEditorHilitePatterns *pat)
{
  Pattern *new = g_new (Pattern, 1);
  new->name = g_strdup (patname);
  new->pat = *pat;
  add_pattern (new);
}

void
gI_hilite_remove_pattern_dia (gI_pat_dialog *pd)
{
  GList *tmp;
  /* NB! do *not* free */
  gchar *name =  gtk_entry_get_text (GTK_ENTRY (pd->patname->entry));

  if ( (tmp = g_list_find_custom (known_patterns, name,
				  (GCompareFunc)patcmp)) ) {
    free_pattern ((Pattern*)tmp->data);
    known_patterns = g_list_remove_link (known_patterns, tmp);
    g_list_free_1 (tmp);
  }
  if ( (tmp = g_list_find_custom (known_pattern_names, name,
				  (GCompareFunc)strcmp)) ) {
    known_pattern_names = g_list_remove_link (known_pattern_names, tmp);
    g_list_free_1 (tmp);
  }

  if (known_pattern_names) {
    gtk_combo_set_popdown_strings (pd->patname, known_pattern_names);
  }
}

void
gI_hilite_remove_pattern_dia_cb (GtkWidget *dummy, gI_pat_dialog *pd)
{
  gI_hilite_remove_pattern_dia (pd);
}


static void
install_pattern_cb (GtkWidget *dummy, gI_pat_dialog *pd)
{
  Pattern *pat;

  pat = g_new (Pattern, 1);
  pat->name = g_strdup (gtk_entry_get_text (GTK_ENTRY (pd->patname->entry)));
  pat->pat.comment_start = g_strdup (gtk_entry_get_text (pd->combeg));
  pat->pat.comment_end = g_strdup (gtk_entry_get_text (pd->comend));
  pat->pat.string_start = g_strdup (gtk_entry_get_text (pd->strbeg));
  pat->pat.string_end = g_strdup (gtk_entry_get_text (pd->strend));
  pat->pat.keywords = g_strdup (gtk_entry_get_text (pd->keywords));

  if (!(pat->name[0] && pat->pat.comment_start[0] && pat->pat.comment_end[0]
	&& pat->pat.string_start[0] && pat->pat.string_end[0]
	&& pat->pat.keywords[0])) {
    error_dialog ("You must specify all entries!", "Pattern Error!");
    return;
  }

  if ( !(gtk_editor_set_patterns (pd->buf, &pat->pat)) ) {
    free_pattern (pat);
    error_dialog ("Could not compile patterns!", "Pattern Error!");
    return ;
  } else {
    GList *tmp;
    if ( (tmp = g_list_find_custom (known_patterns, pat->name,
				    (GCompareFunc)patcmp)) ) {
      free_pattern ((Pattern*)tmp->data);
      known_patterns = g_list_remove_link (known_patterns, tmp);
      g_list_free_1 (tmp);
    }
    known_patterns = g_list_prepend (known_patterns, pat);
    if ( !g_list_find_custom (known_pattern_names, pat->name,
			      (GCompareFunc)strcmp) ) {
      known_pattern_names = g_list_prepend (known_pattern_names, pat->name);
    }
    gtk_editor_hilite_buffer (pd->buf);
  }

  gtk_widget_destroy (pd->dialog);
}

void
gI_hilite_set_pattern (GtkWidget *buf, gchar *pattern_name)
{
  GList *tmp;

  tmp = g_list_find_custom (known_patterns, pattern_name,
			    (GCompareFunc)patcmp);
  g_return_if_fail (tmp != NULL);

  gtk_editor_set_patterns (GTK_EDITOR (buf), &((Pattern*)tmp->data)->pat);
  gtk_editor_hilite_buffer (GTK_EDITOR (buf));
}

/* --<load'n'save>------------------------------------------------ */
/* FIXME: The non-guile stuff is *very* primitive...they should probably be
 * be reimplemented or discarded all together if we move entirely to guile */

#if !HAVE_LIBGUILE
static gchar*
check_string (FILE *file) 
{
  gchar buf[MAXLEN];
  gint c, i;

  while (isspace ( (c = fgetc (file)) ));
  if (c != '"') {
    return NULL;
  }
  
  i = 0;
  while (((c = fgetc(file)) != EOF)) {
    if (c == '\\') {
      switch ( (c = fgetc(file)) ) {
      case 'n': 
	buf[i] = '\n';
	break;
      case '"':
	buf[i] = '"';
	break;
      case EOF:
	return NULL;
	break;
      default:
	buf[i] = c;
      }
    } else if (c == '"') {
      break;
    } else {
      buf[i] = c;
    }
    i++;
    if (i > MAXLEN - 2)
      break;
  }
  buf[i] = 0;
  return g_strdup(buf);
}

static gboolean
checkc (FILE *file, gint c)
{
  gint tmp;
  while (isspace ( ( tmp = fgetc (file)) ));
  if (tmp == c) {
    return TRUE;
  } else {
    return FALSE;
  }
}

void
gI_hilite_load_patterns ( const gchar *filename )
{
  Pattern *pat;
  FILE *file = fopen (filename, "r");
  if (!file) {
    g_warning ("Could not open pattern config file: %s", filename);
    return;
  }

  while (checkc (file, '(')) {
    pat = g_new (Pattern, 1);

    if (! (pat->name = check_string (file)) ) {
      error_dialog ("Syntax error in pattern resource file", "Bad voodoo");
      g_free (pat);
      fclose (file);
      return;
    }
    
    if (! (pat->pat.comment_start = check_string (file)) ) {
      error_dialog ("Syntax error in pattern resource file", "Bad voodoo");
      g_free (pat->name);
      g_free (pat);
      fclose (file);
      return;
    }
    
    if (! (pat->pat.comment_end = check_string (file)) ) {
      error_dialog ("Syntax error in pattern resource file", "Bad voodoo");
      g_free (pat->name);
      g_free (pat->pat.comment_start);
      g_free (pat);
      fclose (file);
      return;
    }
    
    if (! (pat->pat.string_start = check_string (file)) ) {
      error_dialog ("Syntax error in pattern resource file", "Bad voodoo");
      g_free (pat->name);
      g_free (pat->pat.comment_start);
      g_free (pat->pat.comment_end);
      g_free (pat);
      fclose (file);
      return;
    }
    
    if (! (pat->pat.string_end = check_string (file)) ) {
      error_dialog ("Syntax error in pattern resource file", "Bad voodoo");
      g_free (pat->name);
      g_free (pat->pat.comment_start);
      g_free (pat->pat.comment_end);
      g_free (pat->pat.string_start);
      g_free (pat);
      fclose (file);
      return;
    }
    
    if (! (pat->pat.keywords = check_string (file)) ) {
      error_dialog ("Syntax error in pattern resource file", "Bad voodoo");
      g_free (pat->name);
      g_free (pat->pat.comment_start);
      g_free (pat->pat.comment_end);
      g_free (pat->pat.string_start);
      g_free (pat->pat.string_end);
      g_free (pat);
      fclose (file);
      return;
    }

    if (! checkc (file, ')') ) {
      error_dialog ("Syntax error in pattern resource file", "Bad voodoo");
      g_free (pat->name);
      g_free (pat->pat.comment_start);
      g_free (pat->pat.comment_end);
      g_free (pat->pat.string_start);
      g_free (pat->pat.string_end);
      g_free (pat->pat.keywords);
      g_free (pat);
      fclose (file);
      return;
    }

    add_pattern (pat);
  }

  fclose (file);
}
#endif /*!HAVE_LIBGUILE*/

static void
quotestr (const gchar *src, gchar *dst)
{
  gint i, j;
  gint len;

  g_assert (src);
  g_assert (dst);

  len = strlen (src);
  
  for (i = j = 0; (i < len) && (j < MAXLEN); i++, j++) {
    if (src[i] == '"' || src[i] == '\\') {
      dst[j++] = '\\';
    }
    dst[j] = src[i];
  }
  dst[j] = '\0';
}

#if HAVE_LIBGUILE
static void
save_pattern_map (Pattern *pat, FILE *file)
{
  gchar tmp[MAXLEN];
  fprintf (file, "(define %s '(", pat->name);
  quotestr (pat->pat.comment_start, tmp);
  fprintf (file, "\"%s\" ", tmp);
  quotestr (pat->pat.comment_end, tmp);
  fprintf (file, "\"%s\" ", tmp);
  quotestr (pat->pat.string_start, tmp);
  fprintf (file, "\"%s\" ", tmp);
  quotestr (pat->pat.string_end, tmp);
  fprintf (file, "\"%s\" ", tmp);
  quotestr (pat->pat.keywords, tmp);
  fprintf (file, "\"%s\"))\n", tmp);
}

static void
save_pattern_list_map (gchar *patname, FILE *file)
{
  fprintf (file, "%s ", patname);
}


void
gI_hilite_save_patterns ( const gchar *filename )
{
  FILE *file, *backup;
  gchar *backupname = g_strconcat (filename, "~", NULL);
  gchar *tmp;

  rename (filename, backupname);

  file = fopen (filename, "w");
  if (!file) {
    g_warning ("Could not open pattern config file: %s", filename);
    g_free (backupname);
    return;
  }

  /* write header */

  fprintf (file, ";;; gIDE %s Highligth pattern file\n;;;\n", VERSION);
  fprintf (file, ";;; Everything from the beginning of this file and on to\n");
  fprintf (file, ";;; \";;;AUTOMATIC-END\" should not be hand edited, since gIDE\n");
  fprintf (file, ";;; will change this when saving the preferences.\n;;;\n");
  fprintf (file, ";;; Add your hooks after \";;;AUTOMATIC-END\".\n");

  /* write the patterns */
  fprintf (file, "\n;; Pattern definitions\n");
  g_list_foreach (known_patterns, (GFunc)save_pattern_map, file);

  /* write pattern list */
  fprintf (file, "\n;; Pattern list\n");
  fprintf (file, "(define hilite-pattern-list\n\t'(");
  g_list_foreach (known_pattern_names, (GFunc)save_pattern_list_map, file);
  fprintf (file, "))\n");

  fprintf (file, "\n;;;AUTOMATIC-END\n");

  /* attach user hooks */
  if ( (backup = fopen (backupname, "r")) ) {
    tmp = g_malloc (MAXLEN);
    
    while ( fgets (tmp, MAXLEN, backup) ) {
      if (strncmp (tmp, ";;;AUTOMATIC-END", 16) == 0)
	break;			/* end of automatic generated */
    }
    while ( fgets (tmp, MAXLEN, backup) ) {
      fputs (tmp, file);
    }
    
    g_free (tmp);
    fclose (backup);
  }
  
  g_free (backupname);
  fclose (file);
}

#else  /* if !HAVE_LIBGUILE */
static void
save_pattern_map (Pattern *pat, FILE *file)
{
  gchar tmp[MAXLEN];
  fprintf (file, "(\"%s\"\n", pat->name);
  quotestr (pat->pat.comment_start, tmp);
  fprintf (file, "\t \"%s\"\n", tmp);
  quotestr (pat->pat.comment_end, tmp);
  fprintf (file, "\t \"%s\"\n", tmp);
  quotestr (pat->pat.string_start, tmp);
  fprintf (file, "\t \"%s\"\n", tmp);
  quotestr (pat->pat.string_end, tmp);
  fprintf (file, "\t \"%s\"\n", tmp);
  quotestr (pat->pat.keywords, tmp);
  fprintf (file, "\t \"%s\")\n", tmp);
}

void
gI_hilite_save_patterns ( const gchar *filename )
{
  FILE *file = fopen (filename, "w");
  if (!file) {
    g_warning ("Could not open pattern config file: %s", filename);
    return;
  }

  g_list_foreach (known_patterns, (GFunc)save_pattern_map, file);

  fclose (file);
}
#endif

/* --<misc.>------------------------------------------------------ */
static void
free_pattern (Pattern *pat)
{
  g_free (pat->pat.comment_start);
  g_free (pat->pat.comment_end);
  g_free (pat->pat.string_start);
  g_free (pat->pat.string_end);
  g_free (pat->pat.keywords);
  g_free (pat);
}

GtkEditorHilitePatterns*
gI_hilite_get_pattern_by_name (gchar *name)
{
  GList *tmp;

  g_return_val_if_fail (name != NULL, NULL);

  if (! (tmp = g_list_find_custom (known_patterns, name,
				   (GCompareFunc)patcmp)) ) {
    return NULL;
  }

  return &((Pattern*)tmp->data)->pat;
}

#endif /*HAVE_GTKTEXT_PATCH*/
