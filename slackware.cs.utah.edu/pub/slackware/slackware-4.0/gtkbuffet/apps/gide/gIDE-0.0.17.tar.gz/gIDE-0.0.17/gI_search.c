/* $Header: /cvs/gIDE/gI_search.c,v 1.17 1999/01/30 11:52:09 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#ifdef HAVE_GNOME
#include <gnome.h>
#endif
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#ifdef HAVE_GNU_REGEXP
#include "regex.h"
#endif

#include "structs.h"
#include "gI_document.h"
#include "gI_compile.h"
#include "gI_window.h"
#include "gI_common.h"
#include "gI_search.h"


/* globals */
static GtkWidget *search_window = NULL; 
static GtkWidget *line_entry;
static GtkWidget *search_entry;
static GtkWidget *replace_entry;
static glong kz_regexp = 0;
static glong kz_case = 0;
static glong kz_cursor = 0;
static glong kz_again = 0;
static gchar search_str[256];
static gchar replace_str[256];


/* externs */
extern gI_window *main_window;


static void search_window_destroy( GtkWidget *widget, gpointer data)
{
    gtk_widget_destroy( search_window );
    search_window = NULL;
}


static void _goto_line( GtkWidget *widget, gpointer data )
{
    gchar *line;
    gint _line;
    gI_document *current;

    gI_window_clear_statusbar( main_window );
    
    current = gI_document_get_current( main_window );

    line = gtk_entry_get_text( GTK_ENTRY( line_entry ) );
    _line = atoi( line );

    if( ( _line <= 0 ) || ( get_point_from_line( _line ) > gtk_text_get_length( GTK_TEXT( current->text ) ) ) )
    {
        /* error */
        error_dialog( "\n      Invalid Line!      \n", "Invalid Line" );
        return;
    }

    goto_line( _line );

    search_window_destroy( NULL, NULL );
}


/*
 ---------------------------------------------------------------------
     Function: search_goto_line()
     Desc: Callback-Function /Search/Goto Line
 ---------------------------------------------------------------------
*/

void search_goto_line( GtkWidget *widget, gpointer data )
{
    GtkWidget *vbox;
    GtkWidget *hbox;
    GtkWidget *label;
    GtkWidget *hsep;
    GtkWidget *button;

    if( search_window )
        return;

    search_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    gtk_widget_set_usize( search_window, 250, 100 );
    gtk_window_set_title( GTK_WINDOW( search_window ), "Goto Line..." );
    gtk_signal_connect( GTK_OBJECT( search_window ), "destroy",
                        GTK_SIGNAL_FUNC( search_window_destroy ), NULL );

    vbox = gtk_vbox_new( FALSE, 0 );
    gtk_container_add( GTK_CONTAINER( search_window ), vbox );
    gtk_widget_show( vbox );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, TRUE, TRUE, 5 );
    gtk_widget_show( hbox );

    label = gtk_label_new( "Line  " );
    gtk_box_pack_start( GTK_BOX( hbox ), label, TRUE, TRUE, 5 );
    gtk_widget_show( label );

    line_entry = gtk_entry_new_with_max_length( 10 );
    gtk_box_pack_start( GTK_BOX( hbox ), line_entry, TRUE, TRUE, 5 );
       gtk_signal_connect( GTK_OBJECT( line_entry ), "activate",
                       GTK_SIGNAL_FUNC( _goto_line ), NULL );
    gtk_widget_grab_focus( line_entry );
    gtk_widget_show( line_entry );

    hsep = gtk_hseparator_new();
    gtk_box_pack_start( GTK_BOX( vbox ), hsep, TRUE, TRUE, 5 );
    gtk_widget_show( hsep );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, TRUE, TRUE, 5 );
    gtk_widget_show( hbox );
    
#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_OK );
#else
    button = gtk_button_new_with_label( "   OK   " );
#endif
    gtk_box_pack_start( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( _goto_line ), NULL );
    GTK_WIDGET_SET_FLAGS( button, GTK_CAN_DEFAULT );
    gtk_widget_grab_default( button );
    gtk_widget_show( button );

#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_CANCEL );
#else
    button = gtk_button_new_with_label( " Cancel " );
#endif
    gtk_box_pack_end( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( search_window_destroy ), NULL );
    gtk_widget_show( button );
    
    gtk_widget_show( search_window );
}


static void _search_search( GtkWidget *widget, gpointer data )
{
    gchar *buf;
    gI_document *current;
    gint i;
    glong len,text_length;
    glong hit = 0;
    gchar search_result[STRLEN];
    glong found = 0;
#ifdef HAVE_GNU_REGEXP
    gchar errbuf[256];
    gchar errmsg[300]; 
    regex_t buffer;
    glong compile;
    gchar *text;
    regmatch_t regs[1];
    glong match;
#endif

	if(widget)  /* if not trying search again? */
		history_add_to_history(main_window->search_history,GTK_COMBO(search_entry));
 
   gI_window_clear_statusbar( main_window );
    
    current = gI_document_get_current( main_window );

    if( !kz_again )
    {
		gchar *search_p = gtk_entry_get_text( GTK_ENTRY( GTK_COMBO( search_entry )->entry ));

		g_return_if_fail( search_p != NULL );

        strcpy( search_str, gtk_entry_get_text(GTK_ENTRY( GTK_COMBO( search_entry )->entry )) );

		search_window_destroy( NULL, NULL );
    }
    
    buf = (gchar *) g_malloc0( sizeof( search_str ) );
    len = strlen( search_str );
    text_length = gtk_text_get_length( GTK_TEXT( current->text ) );

    if( !kz_cursor )
        i = 0;
    else
        i = gtk_text_get_point( GTK_TEXT( current->text ) );

    if( kz_regexp )
    {
#ifdef HAVE_GNU_REGEXP
       compile = regcomp( &buffer, search_str, REG_EXTENDED );
       if( compile != 0 )
       {
           regerror( compile, &buffer, errbuf, 256 );   
 	   sprintf( errmsg, "\n        %s        \n", errbuf ); 
           error_dialog( errmsg, "Regex Compile Error!" );
	   return;	
       }

       /* the stuff below needs to much memory, find a better way */
       text = gtk_editable_get_chars( GTK_EDITABLE( current->text ), 0, text_length );
       match = regexec( &buffer, text, 1, regs, 0 ); 
       if( match != 0 )
       {
           g_snprintf( search_result, STRLEN, "\n    [%s] not found!    \n", search_str );
           error_dialog( search_result, "Not Found!" );
     	   g_free( text );
       }
       else
       {
           /* scroll... */
	   		__goto_point( regs[0].rm_so );
		   gtk_editable_select_region( GTK_EDITABLE( current->text ), regs[0].rm_so, regs[0].rm_eo );
			gtk_text_set_point( GTK_TEXT( current->text ), regs[0].rm_eo+1 );
           regfree( &buffer );
           g_free( text );  
       }
#else
       error_dialog( "\n    Regular Expression Search only supported with the GNU regexp lib    \n", "Regexp Search Error!" );
#endif    
       return;
    }

    gtk_text_freeze( GTK_TEXT( current->text ) );

    for(;i<=(text_length-len);i++)
    {
        buf = gtk_editable_get_chars( GTK_EDITABLE( current->text ), i, i+len );
        if( kz_case )
            hit = strcmp( buf, search_str );
        else
            hit = strcasecmp( buf, search_str );

        if( hit == 0 )
        {
            found = TRUE;
            
            gtk_text_thaw( GTK_TEXT( current->text ) );

            /* scroll... */
	    __goto_point( i );	
            gtk_editable_select_region( GTK_EDITABLE( current->text ), i, i+len );
			gtk_text_set_point( GTK_TEXT( current->text ), i+len+1 );
            break;
        }
    	g_free( buf );
    }

    if( !found )
    {
        g_snprintf( search_result, STRLEN, "\n    [%s] not found!    \n", search_str );
		error_dialog( search_result, "Not Found!" );
    }
	else
	{
	}

    kz_again = FALSE;
}


static void cb_case_clicked( GtkWidget *widget, gpointer data )
{
    if( kz_case )
        kz_case = FALSE;
    else
        kz_case = TRUE;
}


static void cb_regexp_clicked( GtkWidget *widget, gpointer data )
{
    if( kz_regexp )
        kz_regexp = FALSE;
    else
        kz_regexp = TRUE;
}

/*
 ---------------------------------------------------------------------
     Function: search_search()
     Desc: Callback-Function /Search/Search
 ---------------------------------------------------------------------
*/

void search_search( GtkWidget *widget, gpointer data )
{
    GtkWidget *vbox;
    GtkWidget *hbox;
    GtkWidget *label;
    GtkWidget *hsep;
    GtkWidget *button;
    GtkWidget *cb_case;
    GtkWidget *cb_regexp;
	
    if( search_window )
        return;

    kz_case = 0;
    kz_cursor = 0;
    kz_regexp = 0;

    search_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    gtk_widget_set_usize( search_window, 300, 125 );
    gtk_window_set_title( GTK_WINDOW( search_window ), "Search..." );
    gtk_signal_connect( GTK_OBJECT( search_window ), "destroy",
                        GTK_SIGNAL_FUNC( search_window_destroy ), NULL );

    vbox = gtk_vbox_new( FALSE, 0 );
    gtk_container_add( GTK_CONTAINER( search_window ), vbox );
    gtk_widget_show( vbox );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 10 );
    gtk_widget_show( hbox );

    label = gtk_label_new( "Search for" );
    gtk_box_pack_start( GTK_BOX( hbox ), label, FALSE, TRUE, 5 );
    gtk_widget_show( label );

    search_entry = gtk_combo_new( );
    gtk_box_pack_start( GTK_BOX( hbox ), search_entry, TRUE, TRUE, 5 );
       gtk_signal_connect( GTK_OBJECT(GTK_COMBO( search_entry)->entry) , "activate",
                       GTK_SIGNAL_FUNC( _search_search ), NULL );
    gtk_widget_show( search_entry );

	if(!main_window->search_history)
		main_window->search_history=g_list_alloc();
	else
		history_add_to_combo(main_window->search_history,GTK_COMBO(search_entry));

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

    cb_case = gtk_check_button_new_with_label( "case sensitive" );
    gtk_box_pack_start( GTK_BOX( hbox ), cb_case, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( cb_case ), "clicked",
                        GTK_SIGNAL_FUNC( cb_case_clicked ), NULL );
    gtk_widget_show( cb_case );

    cb_regexp = gtk_check_button_new_with_label( "regular expression" );
    gtk_box_pack_start( GTK_BOX( hbox ), cb_regexp, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( cb_regexp ), "clicked",
                        GTK_SIGNAL_FUNC( cb_regexp_clicked ), NULL );
    gtk_widget_show( cb_regexp );

    hsep = gtk_hseparator_new();
    gtk_box_pack_start( GTK_BOX( vbox ), hsep, TRUE, TRUE, 5 );
    gtk_widget_show( hsep );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_OK );
#else
    button = gtk_button_new_with_label( "   OK   " );
#endif
    gtk_box_pack_start( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( _search_search ), NULL );
    GTK_WIDGET_SET_FLAGS( button, GTK_CAN_DEFAULT );
    gtk_widget_grab_default( button );
    gtk_widget_show( button );

#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_CANCEL );
#else
    button = gtk_button_new_with_label( " Cancel " );
#endif
    gtk_box_pack_end( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( search_window_destroy ), NULL );
    gtk_widget_show( button );

    if( search_str )
        gtk_entry_set_text( GTK_ENTRY(GTK_COMBO( search_entry )->entry), search_str );

    gtk_widget_grab_focus( search_entry );

    gtk_widget_show( search_window );
}


static void _search_replace( GtkWidget *widget, gpointer data )
{
    gchar *buf;
    gI_document *current;
    gint i;
    glong len,text_length;
    glong hit = 0;
    glong replace = 0;
    gchar search_result[STRLEN];
    glong found = 0;
	
	if(widget)
		history_add_to_history(main_window->search_replace_history,GTK_COMBO(search_entry));
 
   gI_window_clear_statusbar( main_window );
    
    current = gI_document_get_current( main_window );

    strcpy( search_str, gtk_entry_get_text( GTK_ENTRY(GTK_COMBO( search_entry)->entry ) ) );
    strcpy( replace_str, gtk_entry_get_text( GTK_ENTRY( replace_entry ) ) );
    if( strlen( search_str ) == 0 )
    {
        /* do something */
        error_dialog( "Search String Length == 0", "Error!" );
	return;
    }
    else
        search_window_destroy( NULL, NULL );

    buf = (gchar *) g_malloc0( sizeof( search_str ) );
    len = strlen( search_str );
    text_length = gtk_text_get_length( GTK_TEXT( current->text ) );

    if( !kz_cursor )
        i = 0;
    else
        i = gtk_text_get_point( GTK_TEXT( current->text ) );

    gtk_text_freeze( GTK_TEXT( current->text ) );

    for(;i<=(text_length-len-replace);i++)
    {
        buf = gtk_editable_get_chars( GTK_EDITABLE( current->text ), i, i+len );
        if( kz_case )
            hit = strcmp( buf, search_str );
        else
            hit = strcasecmp( buf, search_str );

        if( hit == 0 )
        {
            found = TRUE;
            
            gtk_text_thaw( GTK_TEXT( current->text ) );

            /* scroll... */
	    __goto_point( i );
            gtk_text_set_point( GTK_TEXT( current->text ), i+len );
            gtk_editable_select_region( GTK_EDITABLE( current->text ), i, i+len );

            gtk_editable_delete_selection( GTK_EDITABLE( current->text ) );
            gtk_editable_insert_text( GTK_EDITABLE( current->text ), replace_str, strlen( replace_str ), &i );
            gtk_text_set_point( GTK_TEXT( current->text ), i+strlen( replace_str ) );
            replace = replace + ( strlen( search_str ) - strlen( replace_str ) );
            gtk_text_freeze( GTK_TEXT( current->text ) );
        }
	g_free( buf );
    }

    if( !found )
    {
        g_snprintf( search_result, STRLEN, "\n    [%s] not found!    \n", search_str );
/*        gtk_statusbar_push( GTK_STATUSBAR( main_window->statusbar ), 1, search_result );	*/
	error_dialog( search_result, "Not Found!" );
    }


}


/*
 ---------------------------------------------------------------------
     Function: search_again()
     Desc: Callback-Function /Search/Search Again
 ---------------------------------------------------------------------
*/

void search_again( GtkWidget *widget, gpointer data )
{
    if( strlen( search_str ) == 0 )
        return;

    kz_cursor = TRUE;
    kz_again = TRUE;

    _search_search( NULL, NULL );
}


/*
 ---------------------------------------------------------------------
     Function: search_replace()
     Desc: Callback-Function /Search/Replace
 ---------------------------------------------------------------------
*/

void search_replace( GtkWidget *widget, gpointer data )
{
    GtkWidget *vbox;
    GtkWidget *hbox;
    GtkWidget *label;
    GtkWidget *hsep;
    GtkWidget *button;
    GtkWidget *cb_case;
    GtkWidget *cb_regexp;

    if( search_window )
        return;

    kz_case = 0;
    kz_cursor = 0;
    kz_regexp = 0;
    
    search_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    gtk_widget_set_usize( search_window, 300, 160 );
    gtk_window_set_title( GTK_WINDOW( search_window ), "Search&Replace..." );
    gtk_signal_connect( GTK_OBJECT( search_window ), "destroy",
                        GTK_SIGNAL_FUNC( search_window_destroy ), NULL );

    vbox = gtk_vbox_new( FALSE, 0 );
    gtk_container_add( GTK_CONTAINER( search_window ), vbox );
    gtk_widget_show( vbox );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 10 );
    gtk_widget_show( hbox );

    label = gtk_label_new( "Search for" );
    gtk_box_pack_start( GTK_BOX( hbox ), label, FALSE, TRUE, 5 );
    gtk_widget_show( label );

  	search_entry=gtk_combo_new();
    gtk_box_pack_start( GTK_BOX( hbox ), search_entry, TRUE, TRUE, 5 );
    gtk_widget_show( search_entry );

	if(!main_window->search_replace_history)
		main_window->search_replace_history=g_list_alloc();
	else
		history_add_to_combo(main_window->search_replace_history,GTK_COMBO(search_entry));

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

    label = gtk_label_new( "Replace with" );
    gtk_box_pack_start( GTK_BOX( hbox ), label, FALSE, TRUE, 5 );
       gtk_widget_show( label );

    replace_entry = gtk_entry_new_with_max_length( 255 );
    gtk_box_pack_start( GTK_BOX( hbox ), replace_entry, TRUE, TRUE, 5 );
       gtk_signal_connect( GTK_OBJECT( replace_entry ), "activate",
                       GTK_SIGNAL_FUNC( _search_replace ), NULL );
    gtk_widget_show( replace_entry );
    
    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

    cb_case = gtk_check_button_new_with_label( "case sensitive" );
    gtk_box_pack_start( GTK_BOX( hbox ), cb_case, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( cb_case ), "clicked",
                        GTK_SIGNAL_FUNC( cb_case_clicked ), NULL );
    gtk_widget_show( cb_case );

    cb_regexp = gtk_check_button_new_with_label( "regular expression" );
    gtk_box_pack_start( GTK_BOX( hbox ), cb_regexp, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( cb_regexp ), "clicked",
                        GTK_SIGNAL_FUNC( cb_regexp_clicked ), NULL );
    gtk_widget_show( cb_regexp );

    hsep = gtk_hseparator_new();
    gtk_box_pack_start( GTK_BOX( vbox ), hsep, TRUE, TRUE, 5 );
    gtk_widget_show( hsep );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_OK );
#else
    button = gtk_button_new_with_label( "   OK   " );
#endif
    gtk_box_pack_start( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( _search_replace ), NULL );
    GTK_WIDGET_SET_FLAGS( button, GTK_CAN_DEFAULT );
    gtk_widget_grab_default( button );
    gtk_widget_show( button );

#ifdef HAVE_GNOME
    button = gnome_stock_button( GNOME_STOCK_BUTTON_CANCEL );
#else
    button = gtk_button_new_with_label( " Cancel " );
#endif
    gtk_box_pack_end( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( search_window_destroy ), NULL );
    gtk_widget_show( button );

    if( search_str )
        gtk_entry_set_text( GTK_ENTRY(GTK_COMBO( search_entry)->entry ), search_str );
    if( replace_str )
        gtk_entry_set_text( GTK_ENTRY( replace_entry ), replace_str );

    gtk_widget_grab_focus( search_entry );

    gtk_widget_show( search_window );
}

void history_add_to_history(GList *list,GtkCombo *widget)
{
	gchar *nstr;
	gchar *str;
	GList *cur;

	nstr= gtk_entry_get_text(GTK_ENTRY( GTK_COMBO( widget )->entry ));
	cur=g_list_first(list);
	while(cur)
	{
		str=(gchar *)cur->data;
		if(str)
		{
			if(!strcasecmp(str,nstr))
				return ; /* already one */
		}
		cur=g_list_next(cur); 
	};
	g_list_append(list,g_strdup(nstr));
}

void history_add_to_combo(GList *list,GtkCombo *widget)
{
	GtkWidget *label;
	GtkWidget *listitem;
	gchar *str;
	GList *cur;

	cur=g_list_first(list);
	while(cur)
	{
		str=(gchar *)cur->data;
		if(str)
		{
			label=gtk_label_new(str);
			listitem=gtk_list_item_new();
			gtk_container_add(GTK_CONTAINER(listitem),label);
			gtk_widget_show(label);
			gtk_container_add(GTK_CONTAINER(GTK_COMBO(widget)->list),listitem);		
			gtk_widget_show(listitem);
		}
		cur=g_list_next(cur); 
	};
}


/*
 * this __goto_point() function really takes a point,
 * maybe we should re-name the functions one day
 * (there's a goto_point() function in gI_compile.[hc]
 * that takes a line as argument. the difference to
 * goto_line() is that it really goes to the line not
 * just makes them visible on the screen)
 */
void __goto_point( gint point )
{
    gI_document *current;
	double tl, ln, adjval;
	glong line;

    current = gI_document_get_current( main_window );
	if( !current )
		return;

	line = get_line_from_point( point );

	tl = (double) get_total_lines( current->text );
	ln = (double) line;	

	if( tl < 10.0 )
	{
		/* is on the screen */
		return;
	}

	if( ln > tl )
	{
		/* should not happen */
		return;
	}

	gtk_text_set_point( GTK_TEXT( current->text ), point );

	/* borrowed from gEdit */
	adjval = (ln * GTK_ADJUSTMENT( GTK_TEXT( current->text )->vadj )->upper ) / tl - GTK_ADJUSTMENT( GTK_TEXT( current->text )->vadj )->page_increment;

	gtk_adjustment_set_value( GTK_ADJUSTMENT( GTK_TEXT( current->text )->vadj ), adjval ); 

	/* track movement and set statusbar */
	gI_document_track_movement( current );
	gI_window_set_statusbar( current );		 
}
