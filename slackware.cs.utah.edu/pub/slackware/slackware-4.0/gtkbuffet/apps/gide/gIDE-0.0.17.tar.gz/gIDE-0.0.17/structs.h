/* $Header: /cvs/gIDE/structs.h,v 1.54 1999/01/26 19:23:56 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef STRUCTS_H
#define STRUCTS_H

#include <gtk/gtk.h>
#include <stdio.h>
/* Structs for gIDE */

#ifdef HAVE_GTKTEXT_PATCH
#include "gtkeditor.h"
#endif

/* defines */
#define STRLEN 1024
#define MAXLEN 4096
#define MAXFILES 256
#define MAXFUNC 1024
#define MAXPARM 16
#define MAX_TOOLBAR_ITEMS 25
#define MAX_PROJECT_FILES 50
#define MAX_PROJECT_TARGETS 50
#define MAX_TODO_ITEMS 250

/* #define strcpy(a,b) (char *)memcpy(a,b,(strlen(b)+1)) */
#define NOT_IMPLEMENTED printf( "%s(): Not Implemented!\n", __FUNCTION__ )

#define HISTORY "gide.history"
#define FUNC_IGN_FILE "functions.ignore"
#define FUNC_HL_FILE "functions.highlight"

#ifdef HAVE_LIBGUILE
#define CONFIG "gide.scm"
#define PATTERNS "patterns.scm"
#define GLOBASSOC "glob.scm"
#else
#define CONFIG "gide.conf"
#define PATTERNS "patterns"
#define GLOBASSOC "glob"
#endif

#define CSET_FILE "compile_sets"

typedef struct _gI_window gI_window;
typedef struct _gI_document gI_document;
typedef struct _gI_compile_window gI_compile_window;
typedef struct _gI_debug_window gI_debug_window;
typedef struct _gI_config gI_config;

#ifdef OLD_TODO_LIST /* TODO LIST */
typedef struct _gI_project gI_project;
typedef struct _gI_target gI_target;
typedef struct _gI_todo gI_todo;
#endif

typedef struct _gI_tool gI_tool;
typedef struct _gI_brkpnt gI_brkpnt;
typedef struct _gI_gdbcmd gI_gdbcmd;
typedef struct _gI_brkpnt_window gI_brkpnt_window;
typedef struct _gI_watch_window gI_watch_window;
typedef struct _gI_bt_window gI_bt_window;
typedef struct _gI_comp_dialog gI_comp_dialog;
typedef struct _gI_comp_set gI_comp_set;
#ifdef HAVE_GTKTEXT_PATCH
typedef struct _gI_pat_dialog gI_pat_dialog;
#endif
typedef struct _gI_text_popupmenu gI_text_popupmenu;

struct _search_history
{
	gchar *strings;
};
struct _gI_text_popupmenu
{
    GtkWidget *menu;
    GtkWidget *menu_swaphc;
    GtkWidget *menu_openfile_at_line;
    GtkWidget *menu_separator1;
    GtkWidget *menu_cut;
    GtkWidget *menu_copy;
    GtkWidget *menu_paste;
    GtkWidget *menu_separator2;
    GtkWidget *menu_save;
    GtkWidget *menu_print;
    GtkWidget *menu_close;
#ifdef HAVE_GTKTEXT_PATCH
    GtkWidget *menu_separator3;
    GtkWidget *menu_rehilite;
#endif
	GtkWidget *menu_separator4;
	GtkWidget *menu_item_special;
	GtkWidget *menu_special;
	GtkWidget *menu_special_delete;
	GtkWidget *menu_special_insert;
	GtkWidget *menu_special_mail;	
	GtkWidget *menu_separator5;
	GtkWidget *menu_man;
};

struct _gI_window
{
    GtkWidget *window;
    GtkWidget *notebook;
    GtkWidget *menubar;
    GtkWidget *statusbar;
    gI_text_popupmenu *popup;
    GList *documents;
	GList *search_history;
	GList *search_replace_history;
    GtkAccelGroup *accel;
    GtkWidget *toolbar_box;
	GtkWidget *hpane;
    GtkWidget *tree_box;
    GtkWidget *tree_frame;
    GtkWidget *toolbar;
    gint timeout_id;
    gint switch_page_id;
    gI_debug_window *debug_window;
    gint debug_id;
};

struct _gI_compile_window
{
	GtkWidget *window;
	GtkWidget *list;
	GtkWidget *comp_dialog;
	GtkWidget *close_button;
	gint pid;	
};

struct _gI_debug_window
{
	GtkWidget *window;
	GtkWidget *statusbar;
	GtkWidget *text;
	GtkWidget *entry;
	gI_brkpnt_window *brkpnt_window;
	gI_watch_window *watch_window;
	gI_bt_window *bt_window;
	GtkItemFactory *popup_menu;
	gint pid;
	gint chpid;
	gint fh_in;
	gint fh_out;
	gchar *sockname;
	gint input_id;
	GList *breakpoints;	
	GList *cmd_queue;
	gint state;
	gint wait_for;
};

struct _gI_config
{
    gint about;
    gchar *cfgfile;

    /* compile sets */
    GList *csets;

    /* compile */
    gchar *cc;
    gchar *ld;
    gchar *incpath;
    gchar *ccopt;
    gchar *libpath;
    gchar *ldopt;

    /* debug */
    gchar *db;
    
    /* directories */
    gchar *tmpdir;

    /* editor */
    gchar *fontname;
 /*   GdkFont *font;*/
	GtkStyle *style;
    gint disable_font_stuff;
    GdkColor *bgcol;
    GdkColor *fgcol;
    gint wordwrap;
    gint autosave;
    gint autosave_freq;
    gint use_redit;
    gchar *redit;
    gint highlight;
    gchar *ign_file;
    gint tab_width;
#ifdef HAVE_GTKTEXT_PATCH
    gint edtab;
#endif
    
    /* misc */
    gint toolbar;
    gint toolbar_custom;
    gchar *toolbar_custom_items[MAX_TOOLBAR_ITEMS];
    gint toolbar_custom_items_no;
    gchar *bash;
    gchar *make;
	gchar *man;
    gchar *xterm;
	gint sor;

	/* user/host */
	gchar *email;
	gchar *smtp;

    /* projects */
    gint prjftree;
    gint changelog;
    gint remdone;

#ifdef HAVE_GTKTEXT_PATCH
    /* highlighting */
    gchar *patternfile;
    gchar *globassocfile;
    gchar *hli_file;
#endif
};

struct _gI_document
{
    gI_window *window;
    gI_compile_window *compile_window;
    gint compile_id;
    GtkWidget *text;
    GtkWidget *label;
    gchar *filename;
    gint changed;
    gint changed_id;
    guint x;
    guint y;
    gint read_only;
    gint working;
	gint last_mod;
	gint insert_id;
	gint delete_id;	
	GList *op_list;
	gint first_undo;
};

#ifdef OLD_TODO_LIST
struct _gI_project
{
    gchar *filename;

    gchar *name;
    gchar *version;
    gchar *changelog;
    gchar *mtarget;

    gint targets_no;
    gI_target *targets[MAX_PROJECT_TARGETS];
    
    gint libs_no;
    gchar *libs[MAX_PROJECT_FILES];

    gchar *cpar;
    gchar *cinc;
    
    gchar *lpar;
    gchar *llib;

    gint todo_no;
    gI_todo *todo[MAX_TODO_ITEMS];
};

struct _gI_target
{
    gchar *name;

    gint sources_no;
    gchar *sources[MAX_PROJECT_FILES];
	gint build[MAX_PROJECT_FILES];
};

struct _gI_todo
{
    gchar *item;

    gint status;
};
#endif  /* TODO */

struct _gI_tool
{
    gchar *menu_item_name;
    gchar *name;
    gchar *cmdline;
    gint output;

    gchar *par_name[MAXPARM];
    gint par_no;
    gchar *par_args[MAXPARM];
};

struct _gI_brkpnt
{
	gchar *file;
	gint line;
	gint no;
};	

struct _gI_gdbcmd
{
	gchar *cmd;
	gint show;
	gint status;
};

struct _gI_brkpnt_window
{
	GtkWidget *window;
	GtkWidget *list;
	GtkItemFactory *popup_menu;
};

struct _gI_watch_window
{
	GtkWidget *window;
	GtkWidget *list;
	GtkItemFactory *popup_menu;
	gchar *data;
};

struct _gI_bt_window
{
	GtkWidget *window;
	GtkWidget *list;
	GtkItemFactory *popup_menu;
};

#ifdef HAVE_GTKTEXT_PATCH
struct _gI_pat_dialog
{
    GtkWidget *dialog;
    GtkEditor *buf;
    GtkCombo *patname;
    GtkEntry *combeg, *comend;
    GtkEntry *strbeg, *strend;
    GtkEntry *keywords;
};
#endif

struct _gI_comp_dialog
{
	GtkWidget *vbox;	
	GtkWidget *combo;
	GtkWidget *e_fpat;
	GtkWidget *e_compiler;
	GtkWidget *e_linker;
	GtkWidget *e_incpath;
	GtkWidget *e_ccopt;
	GtkWidget *e_libpath;
	GtkWidget *e_ldopt;
	GtkWidget *e_ccmdline_exec;
	GtkWidget *e_ccmdline_obj;
	GtkWidget *e_lcmdline;
};

struct _gI_comp_set
{
	gchar *cset;
	gchar *fpat;
	gchar *compiler;
	gchar *linker;
	gchar *incpath;
	gchar *ccopt;
	gchar *libpath;
	gchar *ldopt; 
	gchar *c_cmdline_exec;
	gchar *c_cmdline_obj;
	gchar *l_cmdline;
};

#endif
