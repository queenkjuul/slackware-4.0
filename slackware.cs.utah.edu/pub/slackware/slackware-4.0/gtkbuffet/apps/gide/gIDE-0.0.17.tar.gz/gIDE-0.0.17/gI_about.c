/* $Header: /cvs/gIDE/gI_about.c,v 1.11 1999/01/06 14:35:44 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#ifdef HAVE_GNOME
#include <gnome.h>
#else
#include "gide.xpm"
#endif
#include "about_gide.h"
#include <string.h>
#include "structs.h"
#include "about_help.h"


/* globals */
static GtkWidget *about_window;


static void about_destroy( GtkWidget *widget, gpointer data )
{
    if( about_window )
    {
        gtk_widget_destroy( about_window );
        about_window = NULL;
    }
}

#ifdef HAVE_GNOME
void about_gide( GtkWidget *widget, gpointer data )
{
	GtkWidget *about;

	about = gnome_about_new( "gIDE - Integrated Development Environment", VERSION,
							 "(C) 1998 the Free Software Foundation",
                             (const gchar **) authors,
                             "An Integrated Development mainly designed for C, but also useable for other programming languages.", NULL );

	gtk_widget_show( about );
}
#else
void about_gide( GtkWidget *widget, gpointer data )
{
    GtkWidget *pixmapwid, *button;
    GdkPixmap *pixmap;
    GdkBitmap *mask;
    GtkStyle *style;

    GtkWidget *vbox;
    GtkWidget *vscrollbar;
    GtkWidget *hbox;

    GtkWidget *text;
    GdkColor col;
    GdkColormap *cmap;
    glong i;

	GtkWidget *label;

    if( about_window )
        return;

    about_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    gtk_widget_set_usize( about_window, 500, 400 );
    gtk_window_set_title( GTK_WINDOW( about_window ), "About gIDE" );
    gtk_signal_connect( GTK_OBJECT( about_window ), "destroy",
                        GTK_SIGNAL_FUNC( about_destroy ), NULL );
    gtk_widget_show( about_window );

    vbox = gtk_vbox_new( FALSE, 0 );
    gtk_container_add( GTK_CONTAINER( about_window ), vbox );
    gtk_widget_show( vbox );

    /* now for the pixmap from gdk */
    style = gtk_widget_get_style( about_window );
    pixmap = gdk_pixmap_create_from_xpm_d( about_window->window,  &mask,
                                           &style->bg[GTK_STATE_NORMAL],
                                           (gchar **)gide_xpm );

    /* a pixmap widget to contain the pixmap */
    pixmapwid = gtk_pixmap_new( pixmap, mask );
    gtk_widget_show( pixmapwid );

    /* a button to contain the pixmap widget */
    button = gtk_button_new();
    gtk_container_add( GTK_CONTAINER(button), pixmapwid );
    gtk_box_pack_start( GTK_BOX( vbox ), button, FALSE, TRUE, 5 );
    GTK_WIDGET_SET_FLAGS( button, GTK_CAN_DEFAULT );
    gtk_widget_grab_default( button );
    gtk_widget_show( button );

    gtk_signal_connect( GTK_OBJECT(button), "clicked",
                        GTK_SIGNAL_FUNC(about_destroy), NULL );

	label = gtk_label_new( "gIDE " VERSION );
	gtk_box_pack_start( GTK_BOX( vbox ), label, FALSE, TRUE, 3 );	
	gtk_widget_show( label );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

    text = gtk_text_new( NULL, NULL );
    gtk_box_pack_start( GTK_BOX( hbox ), text, TRUE, TRUE, 5 );
    gtk_widget_show( text );

    vscrollbar = gtk_vscrollbar_new( GTK_TEXT( text )->vadj );
    gtk_box_pack_end( GTK_BOX( hbox ), vscrollbar, FALSE, TRUE, 5 );
    gtk_widget_show( vscrollbar );

    
    cmap = gdk_colormap_get_system();
    
    col.pixel = 0;
    col.red = 65535;
    col.green = 0;
    col.blue = 0;

    gdk_color_alloc(cmap,&col);

    /* insert about gide text */
    for(i=0;i<(sizeof( about_info )/sizeof( about_info[0] ));i++)
        gtk_text_insert( GTK_TEXT( text ), NULL, &col, NULL, about_info[i], strlen( about_info[i] ) );
}
#endif

void about_help( GtkWidget *widget, gpointer data )
{
    GtkWidget *text;
    GtkWidget *vbox;
    GtkWidget *hbox;
    GtkWidget *hsep;
    GtkWidget *button;
    glong i;
    
    if( about_window )
        return;

    about_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    gtk_widget_set_usize( about_window, 400, 200 );
    gtk_window_set_title( GTK_WINDOW( about_window ), "About Help" );
    gtk_signal_connect( GTK_OBJECT( about_window ), "destroy",
                        GTK_SIGNAL_FUNC( about_destroy ), NULL );

    vbox = gtk_vbox_new( FALSE, 0 );
    gtk_container_add( GTK_CONTAINER( about_window ), vbox );
    gtk_widget_show( vbox );
    
    text = gtk_text_new( NULL, NULL );
    gtk_box_pack_start( GTK_BOX( vbox ), text, TRUE, TRUE, 5 );
    gtk_widget_show( text );

    hsep = gtk_hseparator_new();
    gtk_box_pack_start( GTK_BOX( vbox ), hsep, FALSE, TRUE, 5 );
    gtk_widget_show( hsep );

    hbox = gtk_hbox_new( FALSE, 0 );
    gtk_box_pack_start( GTK_BOX( vbox ), hbox, FALSE, TRUE, 5 );
    gtk_widget_show( hbox );

	#ifdef HAVE_GNOME
	button = gnome_stock_button (GNOME_STOCK_BUTTON_CLOSE);
	#else
	button = gtk_button_new_with_label( "    Close    " );
	#endif
	
    gtk_box_pack_start( GTK_BOX( hbox ), button, TRUE, TRUE, 5 );
    gtk_signal_connect( GTK_OBJECT( button ), "clicked",
                        GTK_SIGNAL_FUNC( about_destroy ), NULL );
    GTK_WIDGET_SET_FLAGS( button, GTK_CAN_DEFAULT );
    gtk_widget_grab_default( button );
    gtk_widget_show( button );
    
    gtk_widget_show( about_window );

    /* insert about help text */
    for(i=0;i<(sizeof( about_help_text ) / sizeof( about_help_text[0] ) );i++)
        gtk_text_insert( GTK_TEXT( text ), NULL, NULL, NULL, about_help_text[i], strlen( about_help_text[i] ) );
}
