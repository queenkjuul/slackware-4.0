/* $Header: /cvs/gIDE/gI_menus.h,v 1.12 1999/02/11 12:08:48 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef GI_MENUS_H
#define GI_MENUS_H

#include <gtk/gtk.h>

/*
 * Prototypes for 'gI_menus.c'
 */
#ifdef HAVE_GNOME
void create_menubar(GtkWidget *app, GtkWidget *vbox);
#endif
void get_main_menu(GtkWidget **menubar, GtkAccelGroup **table);
void menus_init();
void menus_create( GtkItemFactoryEntry * entries, gint nmenu_entries );
gint menus_install_accel( GtkWidget *widget, gchar *signal_name, gchar key, gchar modifiers, gchar *path );
void menus_remove_accel(GtkWidget * widget, gchar * signal_name, gchar * path);
void menus_set_sensitive( gchar *path, gint sensitive );
GtkWidget *menus_get_item_widget( gchar *path );

typedef struct _pw_assoc gI_PWassoc;
struct _pw_assoc
{
	gchar *path;
	GtkWidget *widget;
};

void gI_PWassoc_add( gchar *path, GtkWidget *widget );
void gI_PWassoc_free();
GtkWidget *gI_PWassoc_lookup( gchar *path );
void gI_PWassoc_remove( gchar *path );

#endif

