/* $Header: /cvs/gIDE/help.h,v 1.5 1998/12/11 19:06:33 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef HELP_H
#define HELP_H

static gchar *help_text[] = {
    "\n\n",
    "\t    ShortCuts\n",
    "\t    ---------\n",
    "\n",
    "\t  Motion Shortcuts\n",
    "\n",
    "\tCtrl-A   Beginning of line\n",
    "\tCtrl-E   End of line\n",
    "\tCtrl-N   Next Line\n",
    "\tCtrl-P   Previous Line\n",
    "\tCtrl-B   Backward one character\n",
    "\tCtrl-F   Forward one character\n",
    "\tAlt-B    Backward one word\n",
    "\tAlt-F    Forward one word\n",
    "\n",
    "\t  Editing Shortcuts\n",
    "\n"
    "\tCtrl-H   Delete Backward Character (Backspace)\n",
    "\tCtrl-D   Delete Forward Character (Delete)\n",
    "\tCtrl-W   Delete Backward Word\n",
    "\tAlt-D    Delete Forward Word\n",
    "\tCtrl-K   Delete to end of line\n",
    "\tCtrl-U   Delete line\n",
    "\n",
    "\t  Selection Shortcuts\n",
    "\n",
    "\tCtrl-X   Cut to clipboard\n",
    "\tCtrl-C   Copy to clipboard\n",
    "\tCtrl-V   Paste from clipboard\n",
    "\tAlt-A    Select All\n",
    "\tAlt-L    Select Line\n",
    "\n\n"
};

#endif

