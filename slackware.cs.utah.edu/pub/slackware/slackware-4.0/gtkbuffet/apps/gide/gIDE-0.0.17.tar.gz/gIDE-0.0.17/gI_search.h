/* $Header: /cvs/gIDE/gI_search.h,v 1.9 1999/01/30 11:52:09 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef GI_SEARCH_H
#define GI_SEARCH_H

#include <gtk/gtk.h>

/*
 * Prototypes for 'gI_search.c'
 */
void search_goto_line( GtkWidget *widget, gpointer data );
void search_search( GtkWidget *widget, gpointer data );
void search_again( GtkWidget *widget, gpointer data );
void search_replace( GtkWidget *widget, gpointer data );
void __goto_point( gint point );
void history_add_to_history(GList *,GtkCombo *);
void history_add_to_combo(GList *,GtkCombo *);

#endif

