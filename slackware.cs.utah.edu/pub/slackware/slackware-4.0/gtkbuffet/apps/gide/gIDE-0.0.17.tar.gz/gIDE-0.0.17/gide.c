/* $Header: /cvs/gIDE/gide.c,v 1.48 1999/02/11 16:00:27 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#ifdef HAVE_GNOME
#include <gnome.h>
#endif
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>

#include "structs.h"
#include "gI_window.h"
#include "gI_file.h"
#include "gI_clp.h"
#include "gI_cfp.h"
#include "gide.h"
#include "gI_menus.h"
#include "gI_edit.h"


#ifdef HAVE_LIBGUILE
#include <guile/gh.h>
#include "gI_guilesupport.h"
#endif

#ifdef HAVE_GTKTEXT_PATCH
#include "gI_hilite.h"
#include "gI_globpatterns.h"
#endif

/* --<global vars.>----------------------------------------------- */
/* Widgets: Main-Window & Box */
gI_window *main_window;
GtkWidget *main_vbox;

/* Widgets: Boxes */
GtkWidget *main_hbox1;
GtkWidget *main_hbox2;
GtkWidget *main_hbox3;

/* Widgets: misc */
GtkWidget *main_notebook;
GtkWidget *main_text1;
GtkWidget *main_frame;
GtkWidget *main_vscrollbar;
GtkWidget *main_hscrollbar;
GtkWidget *main_statusbar;
GtkWidget *main_table;

/* Configuration */
gI_config *cfg;

gchar *home;
gchar gide_path[MAXLEN];
gchar tools_path[MAXLEN];
gchar prj_path[MAXLEN];
/* --</global vars.>---------------------------------------------- */


static void open_history( gchar *filename )
{
    FILE *history;
    gchar buf[MAXLEN];
    gchar historywp[MAXLEN];
    gchar *ptr;

    g_snprintf( historywp, MAXLEN, "%s/%s", gide_path, filename );

    history = fopen( historywp, "r" );
    if( history )
    {
        while( fgets( buf, sizeof(buf), history ) )
        {
            ptr = strchr( buf, '\n' );
            if( ptr )
                *ptr = '\0';
            file_open_by_name( main_window, buf );
        }
        fclose( history );
    }
}


void free_op_list( GList *op_list )
{
	GList *tmp;

	tmp = g_list_first( op_list );

	while( tmp )
	{
		if( tmp->data )
		{
			gI_UndoItem *undo;

			undo = (gI_UndoItem *) tmp->data;

			if( undo->data != NULL )
			{
				g_free( undo->data );	
			}

			g_free( undo );
		}

		tmp = g_list_next( tmp );
	}

	g_list_free( op_list );
}


static void free_docs( GList *documents )
{
	GList *tmp;

	tmp = g_list_first( documents );

	while( tmp )
	{
		if( tmp->data )
		{
			gI_document *document;

			document = (gI_document *) tmp->data;		

			if( document->filename != NULL )
			{
				g_free(	document->filename ); 
			}

			free_op_list( document->op_list );

			g_free( document );
		}	

		tmp = g_list_next( tmp );
	}

	g_list_free( documents );
}


static void free_window( gI_window *window )
{
	g_return_if_fail( window != NULL );

	g_free( window->popup );
	g_list_free( window->search_history );
	g_list_free( window->search_replace_history );

	g_free( window );
}


static void free_cfg( gI_config *cfg )
{
	g_return_if_fail( cfg != NULL );

	g_free( cfg->cfgfile );
	g_free( cfg->cc );
	g_free( cfg->ld );
	g_free( cfg->incpath );
	g_free( cfg->ccopt );
	g_free( cfg->libpath );
	g_free( cfg->ldopt );
	g_free( cfg->db );
	g_free( cfg->tmpdir );
	g_free( cfg->fontname );
	g_free( cfg->redit );
	g_free( cfg->ign_file );
	g_free( cfg->bash );
	g_free( cfg->make );
	g_free( cfg->man );
	g_free( cfg->xterm );
	g_free( cfg->email );
	g_free( cfg->smtp );
#ifdef HAVE_GTKTEXT_PATCH
	g_free( cfg->patternfile );
	g_free( cfg->globassocfile );
	g_free( cfg->hli_file );
#endif
	g_free( cfg );
}


void set_cfg_defaults()
{
    glong i;
    
    /*cfg->cfgfile = NULL;*/

    cfg->cc = (gchar *) realloc( cfg->cc, 10 );
    strcpy( cfg->cc, "gcc" );

    cfg->make = (gchar *) realloc( cfg->make, 10 );
    strcpy( cfg->make, "make" );

    cfg->tmpdir = (gchar *) realloc( cfg->tmpdir, 10 );
    strcpy( cfg->tmpdir, "/tmp" );

    cfg->fontname = (gchar *) realloc( cfg->fontname, 100 );
    strcpy( cfg->fontname, "-adobe-helvetica-medium-r-normal-*-*-120-*-*-p-*-iso8859-1" );
/*    cfg->font = NULL;*/
    cfg->disable_font_stuff = FALSE;
    cfg->bgcol = NULL;
    cfg->fgcol = NULL;
    
    cfg->wordwrap = TRUE;
    
    cfg->autosave = FALSE;
    cfg->autosave_freq = 0;
    cfg->use_redit = FALSE;
    cfg->redit = (gchar *) realloc( cfg->redit, 2 );
    strcpy( cfg->redit, "" );
    cfg->highlight = FALSE;
    cfg->ign_file = (gchar *) realloc( cfg->ign_file, 20 );
    strcpy( cfg->ign_file, "functions.ignore" );

    cfg->toolbar = TRUE;
    cfg->toolbar_custom = FALSE;
    cfg->toolbar_custom_items_no = 0;
    for(i=0;i<MAX_TOOLBAR_ITEMS;i++)
        cfg->toolbar_custom_items[i] = NULL;
    cfg->prjftree = TRUE;

#ifdef HAVE_GTKTEXT_PATCH
    cfg->hli_file = (gchar *) realloc( cfg->hli_file, 20 );
    strcpy( cfg->hli_file, "functions.highlight" );
    cfg->patternfile = (gchar *) realloc( cfg->patternfile, 20 );
    strcpy( cfg->patternfile, PATTERNS );
    cfg->globassocfile = (gchar *) realloc( cfg->globassocfile, 10 );
    strcpy( cfg->globassocfile, GLOBASSOC );
#endif

    cfg->tab_width = 4;
    cfg->incpath = (gchar *) realloc( cfg->incpath, 40 );
    strcpy( cfg->incpath, "/usr/include:/usr/local/include" );
    cfg->ccopt = (gchar *) realloc( cfg->ccopt, 2 );
    strcpy( cfg->ccopt, "" );
    cfg->libpath = (gchar *) realloc( cfg->libpath, 40 );
    strcpy( cfg->libpath, "/lib:/usr/lib:/usr/local/lib" );
    cfg->ldopt = (gchar *) realloc( cfg->ldopt, 2 );
    strcpy( cfg->ldopt, "" );

    cfg->bash = (gchar *) realloc( cfg->bash, 20 );
    strcpy( cfg->bash, "/bin/bash" );

    cfg->xterm = (gchar *) realloc( cfg->xterm, 10 );
    strcpy( cfg->xterm, "xterm" );

	cfg->man = (gchar *) realloc( cfg->man, 5 );
	strcpy( cfg->man, "man" );

#ifdef HAVE_GTKTEXT_PATCH
    cfg->edtab = TRUE;
#endif

    cfg->db = (gchar *) realloc( cfg->db, 10 );
    strcpy( cfg->db, "gdb" );

    cfg->smtp = (gchar *) realloc( cfg->smtp, 20 );
    strcpy( cfg->smtp, "127.0.0.1" );

    cfg->email = (gchar *) realloc( cfg->email, 1 );
    strcpy( cfg->email, "" );

	cfg->sor = 0;

	if( cfg->style )
		gtk_style_unref( cfg->style );
	cfg->style = gtk_style_new();
	gdk_font_unref( cfg->style->font );
	cfg->style->font = gdk_font_load( cfg->fontname );
}


static void handle_ic_stuff()
{
	/* start-up settings */
	menus_set_sensitive( "/Debug/Stop  Debug", FALSE );
	menus_set_sensitive( "/Debug/Set|Clear Breakpoint", FALSE );
	menus_set_sensitive( "/Debug/Break", FALSE );
	menus_set_sensitive( "/Debug/Step Into", FALSE );
	menus_set_sensitive( "/Debug/Step Over", FALSE );
	menus_set_sensitive( "/Edit/Undo", FALSE );
	menus_set_sensitive( "/Edit/Redo", FALSE );

	/* not implemented */
	menus_set_sensitive( "/Compile/Build All", FALSE );
	menus_set_sensitive( "/Project/Create configure", FALSE );
	menus_set_sensitive( "/Project/Create Distribution/Create DEB", FALSE );
	menus_set_sensitive( "/Project/Create Distribution/Create RPM", FALSE );
	menus_set_sensitive( "/Debug/Attach to Process", FALSE );	
	menus_set_sensitive( "/Search/Match Brace", FALSE );
	menus_set_sensitive( "/Edit/Select Word", FALSE );
}


#ifdef HAVE_LIBGUILE

static void real_main (gint argc, gchar *argv[])
{
  gint nofargs = 0;
  
  home = (gchar *)getenv( "HOME" );
  if( !home )
    {
      printf("ERROR: Environment Var HOME is not set!\n" );
      return;
    }

#ifndef HAVE_GNOME
     	sprintf(gide_path,"%s/.gtkrc",home);  
    	gtk_rc_parse(gide_path);   
	g_snprintf( gide_path, MAXLEN, "%s/.gide", home );
#else
    	g_snprintf( gide_path, MAXLEN, "%s/.gide", home );
#endif

    
  if( mkdir( gide_path, 00750 ) == 0 )
    {
      g_print("Created %s!\n",gide_path );
    }

  g_snprintf( tools_path, MAXLEN, "%s/tools", gide_path );
  
  if( mkdir( tools_path, 00750 ) == 0 )
    {
      g_print("Created %s!\n",tools_path);
    }

  g_snprintf( prj_path, MAXLEN, "%s/projects", gide_path );

  if( mkdir( prj_path, 00750 ) == 0 )
  {
      g_print( "Created %s!\n", prj_path );
  }

  
  cfg = (gI_config *) g_malloc0( sizeof( gI_config ) );
  
  /* Set Defaults */
  set_cfg_defaults();

  /* load compile sets */
  load_compile_sets( CSET_FILE );  
 
  /* initialise guilesupport */
  guile_init ();
 
  /* check parameter count */
  if( argc > 1 )
    {
      /* parse the commandline for program parameters */
      gI_cl_parse( argc, argv );
    }
  
  /* find config file */
  if( !cfg->cfgfile )
    cfg->cfgfile = (gchar *) getenv( "GIDECFG" );
  
  if( !cfg->cfgfile )
    {
      cfg->cfgfile = (gchar *) g_malloc0( (strlen( CONFIG ) + strlen( gide_path ) + 2 ) * sizeof( gchar ) );
      sprintf( cfg->cfgfile, "%s/%s", gide_path, CONFIG );
    }
  
  /* parse config file...with guile, we just treat the input file as a
   * scheme program.  This one file is responsible for configuring
   * everything, we don't need different files for patterns and glob
   * assoc.  */
  /* FIXME: we need another error handler... */
  gh_eval_file_with_standard_handler ( cfg->cfgfile );

  /* now guile has the config stuff...we're gonna extract it! */
  guile_extract_cfg ();

#if HAVE_GTKTEXT_PATCH
  guile_extract_pattern_list ();
  guile_extract_globassoc ();
#endif

	if( !cfg->disable_font_stuff )
    {
		GdkFont* new_font;
		if( cfg->style )
			gtk_style_unref( cfg->style );
        cfg->style = gtk_style_new();
        gdk_font_unref( cfg->style->font );
		if ( (new_font = gdk_font_load( cfg->fontname )) )
			cfg->style->font = new_font;
    }
  
  /* Open Main Window */
  main_window = gI_window_new();
  
  /* open the files */
  nofargs = gI_cl_files( argc, argv );
  if( nofargs == 0 )
    {
      /* no files given on the commandline, open files from last session */
      open_history( HISTORY );
    }
  
  handle_ic_stuff();
  
  /* GTK Main Loop */
  gtk_main();

	/* free docs */
	free_docs( main_window->documents );
	
	/* free window */
	free_window( main_window );	

#ifdef HAVE_GNOME
	/* free path/widget association for menus */
	gI_PWassoc_free();
#endif

	/* free config */
	free_cfg( cfg );
}


gint main (gint argc, gchar *argv[])
{
	/* GTK Init */
#ifdef HAVE_GNOME
	gnome_init("gIDE",VERSION,argc,argv);
#else 
	gtk_init( &argc, &argv );
#endif

  /* then we init, and enter guile */
  gh_enter ( argc, argv, real_main );

  return EXIT_SUCCESS;		/* will never be reached...but anyway */
}



#else  /* !HAVE_LIBGUILE */

gint main( gint argc, gchar **argv )
{
    gint nofargs = 0;
    gchar pfwp[STRLEN];
#ifdef HAVE_GTKTEXT_PATCH
    gchar *tmp;
#endif

    /* GTK Init */
    #ifdef HAVE_GNOME /* I dont know all params here */
	gnome_init("gIDE",VERSION,argc,argv);
    #else 
    	gtk_init( &argc, &argv );
    #endif
    
    home = (gchar *)getenv( "HOME" );
    if( !home )
    {
        printf("ERROR: Environment Var HOME is not set!\n" );
        return( -1 );
    }

   #ifndef HAVE_GNOME
     	sprintf(gide_path,"%s/.gtkrc",home);  
    	gtk_rc_parse(gide_path);   
	g_snprintf( gide_path, MAXLEN, "%s/.gide", home );
    #else
    	g_snprintf( gide_path, MAXLEN, "%s/.gide", home );
    #endif
     
    if( mkdir( gide_path, 00750 ) == 0 )
    {
        g_print("Created %s!\n",gide_path );
    }

    g_snprintf( tools_path, MAXLEN, "%s/tools", gide_path );

    if( mkdir( tools_path, 00750 ) == 0 )
    {
        g_print("Created %s!\n",tools_path);
    }

    g_snprintf( prj_path, MAXLEN, "%s/projects", gide_path );

    if( mkdir( prj_path, 00750 ) == 0 )
    {
        g_print("Created %s!\n",prj_path);
    }
        

    cfg = (gI_config *) g_malloc0( sizeof( gI_config ) );

    /* Set Defaults */
    set_cfg_defaults();
    
    /* load compile sets */
    load_compile_sets( CSET_FILE );  

    /* check parameter count */
    if( argc > 1 )
    {
        /* parse the commandline for program parameters */
        gI_cl_parse( argc, argv );
    }

    /* parse config file */
    if( !cfg->cfgfile )
        cfg->cfgfile = (gchar *) getenv( "GIDECFG" );

    if( !cfg->cfgfile )
    {
        cfg->cfgfile = (gchar *) g_malloc0( (strlen( CONFIG ) + strlen( gide_path ) + 2 ) * sizeof( gchar ) );
        sprintf( cfg->cfgfile, "%s/%s", gide_path, CONFIG );
    }

    /* parse config file */
        gI_cf_parse( cfg->cfgfile );
	
    if( !cfg->disable_font_stuff )
    {
		GdkFont* new_font;
		if( cfg->style )
			gtk_style_unref( cfg->style );
        cfg->style = gtk_style_new();
        gdk_font_unref( cfg->style->font );
		if( (new_font = gdk_font_load( cfg->fontname )) )
			cfg->style->font = new_font;
    }
	
#ifdef HAVE_GTKTEXT_PATCH
    g_snprintf( pfwp, STRLEN, cfg->patternfile );
    tmp = g_strconcat (gide_path, "/", cfg->patternfile, NULL);
    gI_hilite_load_patterns( tmp );
    g_free ( tmp );
    g_snprintf( pfwp, STRLEN, cfg->globassocfile );
    tmp = g_strconcat (gide_path, "/", cfg->globassocfile, NULL);
    gI_glob_load_globassoc ( tmp );
    g_free ( tmp );
#endif
    
    /* Open Main Window */
    main_window = gI_window_new();

    /* open the files */
    nofargs = gI_cl_files( argc, argv );
    if( nofargs == 0 )
    {
        /* no files given on the commandline, open files from last session */
        open_history( HISTORY );
    }

    gI_window_clear_statusbar( main_window );

    handle_ic_stuff();
    
    /* GTK Main Loop */
    gtk_main();

	/* free docs */
	free_docs( main_window->documents );
	
	/* free window */
	free_window( main_window );	

#ifdef HAVE_GNOME
	/* free path/widget association for menus */
	gI_PWassoc_free();
#endif

	/* free config */
	free_cfg( cfg );

    /* all�s great, return EXIT_SUCCESS */
    return( EXIT_SUCCESS );
}

#endif /*HAVE_LIBGUILE*/


