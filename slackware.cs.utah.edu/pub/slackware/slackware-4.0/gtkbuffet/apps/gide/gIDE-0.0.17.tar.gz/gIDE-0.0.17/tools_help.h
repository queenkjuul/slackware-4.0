/* $Header: /cvs/gIDE/tools_help.h,v 1.7 1999/02/14 09:28:20 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef TOOLS_HELP_H
#define TOOLS_HELP_H

static gchar *tools_help_text[] = {
    "\n",
    "\tName:\n",
    "\t\tName of the Tool, at the moment this name is only used for the filename.\n\n",
    "\tCommandline:\n",
    "\t\tThe Commandline to run the tool. %f gets replaced with the filename of the\n",
    "\t\tcurrent document.\n\n",
    "\tMenu Item Name:\n",
    "\t\tThe Name of the Menu-Item in the Tools-Menu.\n\n",
    "\tCommand Output:\n",
    "\t\t- 'Create New File': Creates a new \"Untitled\" File and inserts the output\n",
    "\t\t  of the command.\n",
    "\t\t- 'Append to current file': Appends the output of the command to the current\n",
    "\t\t  file.\n",
    "\t\t- 'Insert at Cursor Position': Inserts the output of the command at the current\n",
    "\t\t  Cursor position\n",
    "\t\t- 'Output to Text Box': Shows the ouput of the command a scrollable Text Box.\n",
    "\t\t- 'Ignore Output': The output of the command is redirected to /dev/null.\n",
    "\t\t- 'Run in XTerm': Run the command in a XTerm.\n",
    "\n"
};

#endif

