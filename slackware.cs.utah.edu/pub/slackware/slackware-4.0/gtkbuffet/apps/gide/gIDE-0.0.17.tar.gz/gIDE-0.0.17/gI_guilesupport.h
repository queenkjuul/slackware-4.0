/* $Header: /cvs/gIDE/gI_guilesupport.h,v 1.4 1998/08/10 00:34:46 sk Exp $ */
/*  gIDE
 *  Copyright (C) 1998 Steffen Kern
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifdef HAVE_LIBGUILE

#ifndef GUILESUPPORT_H
#define GUILESUPPORT_H

#include "structs.h"

/* gI_guilesupport -- module for interaction with guile.  Here is the
 * functions for initialising guile, for guile I/O.  Functions working
 * as wrappers between C and Scheme is found in gI_guilewrappers. */

/* -<init>----------------------------------------------------------- */
void        guile_init                        (void);
void        guile_extract_cfg                 (void);
#if HAVE_GTKTEXT_PATCH
void        guile_extract_pattern_list        (void);
void        guile_extract_globassoc           (void);
#endif

#endif /*GUILESUPPORT_H*/
#endif /*HAVE_LIBGUILE*/
