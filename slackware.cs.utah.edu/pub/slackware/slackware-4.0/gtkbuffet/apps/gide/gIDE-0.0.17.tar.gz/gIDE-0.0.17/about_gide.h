/* $Header: /cvs/gIDE/about_gide.h,v 1.9 1999/01/06 14:35:44 sk Exp $ */
/* gIDE
 * Copyright (C) 1998 Steffen Kern
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef ABOUT_GIDE_H
#define ABOUT_GIDE_H

#ifdef HAVE_GNOME
static gchar *authors[] = { "The gIDE Team", NULL };

/*
static gchar *authors[] = { "Steffen Kern", NULL };
static gchar *authors[] =
	{ "Steffen Kern", "Thomas Mailund Jensen", "Aaron Walker",
	  "Alexis Mikhailov", "Dave Smith", "Elladan",
	  "Joshua Thomas Green", "Manuel Estrada", "Mikael Hermansson",
	  "Paul Duran", "The Bear", "Tomi Petteri Pakarinen", NULL };  
*/
#else
static gchar *about_info[] = {
    "\n",
    "Credits:\n\n",
    "\tAaron Walker\n\t\tfor his ideas and testing the stuff i'm writing\n\n",
	"\tAlexis Mikhailov\n\t\tfor his huge patch (that i could not apply completely)\n\n", 
    "\tDave Smith\n\t\tfor creating, hosting and maintaining the new gIDE\n",
	"\t\twebsite and for his work on the GNOME support.\n\n",
	"\tElladan\n\t\tfor first cleaning up and now rewriting the project management\n\n",
    "\tJoshua Thomas Green\n\t\tfor the Multi-File-Selection patch\n\n", 
    "\tManuel Estrada\n\t\tfor the first 'debianization' patch\n\n",
    "\tMikael Hermansson\n\t\tfor the PopUp-Menu-Patch, bug reports\n",
	"\t\tand lots of other stuff\n\n", 
    "\tPaul Duran\n\t\tfor his 'GTK+ 1.1.x compatibility patch (that also fixed at lots of\n",
    "\t\tcompiler warnings)\n\n",
	"\tThe Bear\n\t\tfor his man page viewer\n\n",
	"\tTomi Petteri Pakarinen\n\t\tfor his bugfix patches and the new styles handling\n\n",
    "\n",
    ""
};
#endif

#endif

