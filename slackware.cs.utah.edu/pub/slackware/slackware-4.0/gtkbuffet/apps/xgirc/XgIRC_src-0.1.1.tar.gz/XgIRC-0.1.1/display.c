/* This file is part of XgIRC 0.1
   display.c - Interface building and display

   Copyright (C) 1998 A|vin (Julien Pieraut) <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "main.h"
#include "icons/logo.xpm"
#include "icons/green_off.xpm"
#include "icons/green_on.xpm"
#include "icons/red_off.xpm"
#include "icons/red_on.xpm"
#include "icons/connect.xpm"
#include "icons/deconnect.xpm"
#include "icons/setup.xpm"
#include "icons/close.xpm"
#include "icons/about.xpm"
#include "icons/query.xpm"
#include "icons/help.xpm"
#include "icons/exit.xpm"
#include "display.h"
#include "strings.h"
#include "callback.h"
#include "text.h"

GtkWidget *label_lagmeter;

gint
delete_event (GtkWidget * widget, gpointer data)
{
  return (FALSE);
}

void
update_status_bar (int scr)
{
  if (!GTK_IS_LABEL (status_chan1[scr]))
    {
#ifdef DEBUG
      g_print ("[D] ERROR : status_chan1[%d] is not a LABEL! Ignoring update... <display.c/update_status_bar>\n", scr);
#endif
      return;
    }
  if (scr <= total_channels)
    {
      sprintf (buf, "[o:%i no:%i t:%i] [%s]", channel[scr].nb_ops, channel[scr].nb_nops, channel[scr].nb_ops + channel[scr].nb_nops, channel[scr].modes);
      gtk_label_set (GTK_LABEL (status_chan1[scr]), buf);
      sprintf (buf, "Topic [by %s] : %s", channel[scr].topic_author, channel[scr].topic);
      gtk_label_set (GTK_LABEL (status_chan2[scr]), buf);
    }
}

void
choose_color (char *color_title)
{
  GtkWidget *color_selection;

  sprintf (buf, "Select %s color", color_title);
  color_selection = gtk_color_selection_dialog_new (buf);
  gtk_widget_show (color_selection);
}

/* ========================================================================== *
 * = Pop-up setup window                                                    = *
 * ========================================================================== */
void
setup (GtkWidget * widget, gpointer data)
{
  GtkWidget *box;
  GtkWidget *notebook;
  GtkWidget *box_confirm;
  GtkWidget *child_userinfo;
  GtkWidget *child_server;
  GtkWidget *child_colors;
  GtkWidget *child_general_options;
  GtkWidget *label_child_userinfo;
  GtkWidget *label_child_server;
  GtkWidget *label_child_colors;
  GtkWidget *label_child_general_options;
  GtkWidget *box_nick;
  GtkWidget *label_nick;
  GtkWidget *box_alternate_nick;
  GtkWidget *label_alternate_nick;
  GtkWidget *box_user;
  GtkWidget *label_user;
  GtkWidget *box_gecos;
  GtkWidget *label_gecos;
  GtkWidget *box_server;
  GtkWidget *label_server;
  GtkWidget *box_port;
  GtkWidget *label_port;
  GtkWidget *button_ok;
  GtkWidget *button_cancel;
  GtkWidget *box_color1;
  GtkWidget *label_color1;
  GtkWidget *drawingarea_color1;
  GtkWidget *box_general_options;

  if (setup_w)
    return;			/* If a previous setup window exists, don't make another one */

  setup_w = 1;
  window_setup = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window_setup), "XgIRC Setup");
  gtk_container_border_width (GTK_CONTAINER (window_setup), 3);
  notebook = gtk_notebook_new ();
  child_userinfo = gtk_vbox_new (FALSE, 5);
  child_server = gtk_vbox_new (FALSE, 5);
  child_colors = gtk_vbox_new (FALSE, 5);
  child_general_options = gtk_vbox_new (FALSE, 5);

/* === Confirmation box ================================================== */
  box_confirm = gtk_hbox_new (FALSE, 5);
  button_ok = gtk_button_new_with_label (" Save ");
  button_cancel = gtk_button_new_with_label (" Close ");
  gtk_box_pack_start (GTK_BOX (box_confirm), button_ok, FALSE, FALSE, 10);
  gtk_box_pack_end (GTK_BOX (box_confirm), button_cancel, FALSE, FALSE, 10);
  gtk_signal_connect (GTK_OBJECT (button_ok), "clicked", GTK_SIGNAL_FUNC (ok_setup_callback), NULL);
  gtk_signal_connect (GTK_OBJECT (button_cancel), "clicked", GTK_SIGNAL_FUNC (cancel_setup_callback), NULL);
  gtk_widget_show (button_ok);
  gtk_widget_show (button_cancel);
  gtk_widget_show (box_confirm);
/* ======================================================================= */

  box_nick = gtk_hbox_new (FALSE, 5);
  box_alternate_nick = gtk_hbox_new (FALSE, 5);
  box_user = gtk_hbox_new (FALSE, 5);
  box_gecos = gtk_hbox_new (FALSE, 5);
  box_server = gtk_hbox_new (FALSE, 5);
  box_port = gtk_hbox_new (FALSE, 5);
  box_color1 = gtk_hbox_new (FALSE, 5);
  box_general_options = general_options_box (window_setup);
  drawingarea_color1 = gtk_drawing_area_new ();
  gtk_drawing_area_size (GTK_DRAWING_AREA (drawingarea_color1), 20, 8);
  label_nick = gtk_label_new ("Nickname :  ");
  label_alternate_nick = gtk_label_new ("Alternate Nickname :  ");
  label_user = gtk_label_new ("Username :  ");
  label_gecos = gtk_label_new ("Realname :  ");
  label_server = gtk_label_new ("Server :  ");
  label_port = gtk_label_new ("Port :  ");
  label_color1 = gtk_label_new ("Not yet implemented");
  entry_nick = gtk_entry_new_with_max_length (NICK_MAXLEN);
  gtk_entry_set_text (GTK_ENTRY (entry_nick), me.nick);
  entry_alternate_nick = gtk_entry_new_with_max_length (NICK_MAXLEN);
  gtk_entry_set_text (GTK_ENTRY (entry_alternate_nick), me.altnick);
  entry_user = gtk_entry_new_with_max_length (15);
  gtk_entry_set_text (GTK_ENTRY (entry_user), me.user);
  entry_gecos = gtk_entry_new_with_max_length (60);
  gtk_entry_set_text (GTK_ENTRY (entry_gecos), me.gecos);
  gtk_entry_set_position (GTK_ENTRY (entry_gecos), 0);
  entry_server = gtk_entry_new_with_max_length (60);
  entry_port = gtk_entry_new_with_max_length (5);
  gtk_entry_set_text (GTK_ENTRY (entry_port), int_to_string (port));
  gtk_entry_set_text (GTK_ENTRY (entry_server), server);
  gtk_box_pack_start (GTK_BOX (box_nick), label_nick, FALSE, FALSE, 10);
  gtk_box_pack_end (GTK_BOX (box_nick), entry_nick, FALSE, FALSE, 10);
  gtk_box_pack_start (GTK_BOX (box_alternate_nick), label_alternate_nick, FALSE, FALSE, 10);
  gtk_box_pack_end (GTK_BOX (box_alternate_nick), entry_alternate_nick, FALSE, FALSE, 10);
  gtk_box_pack_start (GTK_BOX (box_user), label_user, FALSE, FALSE, 10);
  gtk_box_pack_end (GTK_BOX (box_user), entry_user, FALSE, FALSE, 10);
  gtk_box_pack_start (GTK_BOX (box_gecos), label_gecos, FALSE, FALSE, 10);
  gtk_box_pack_end (GTK_BOX (box_gecos), entry_gecos, FALSE, FALSE, 10);
  gtk_box_pack_start (GTK_BOX (box_server), label_server, FALSE, FALSE, 10);
  gtk_box_pack_end (GTK_BOX (box_server), entry_server, FALSE, FALSE, 10);
  gtk_box_pack_start (GTK_BOX (box_port), label_port, FALSE, FALSE, 10);
  gtk_box_pack_end (GTK_BOX (box_port), entry_port, FALSE, FALSE, 10);
  gtk_box_pack_start (GTK_BOX (box_color1), label_color1, FALSE, FALSE, 10);
  gtk_box_pack_start (GTK_BOX (box_color1), drawingarea_color1, FALSE, FALSE, 10);
  gtk_box_pack_start (GTK_BOX (child_userinfo), box_nick, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (child_userinfo), box_alternate_nick, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (child_userinfo), box_user, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (child_userinfo), box_gecos, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (child_server), box_server, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (child_server), box_port, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (child_colors), box_color1, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (child_general_options), box_general_options, TRUE, TRUE, 3);

/* === Main window box =================================================== */
  box = gtk_vbox_new (FALSE, 5);
  gtk_box_pack_start (GTK_BOX (box), notebook, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (box), box_confirm, TRUE, TRUE, 3);
  gtk_widget_show (box);
/* ======================================================================= */

  gtk_container_add (GTK_CONTAINER (window_setup), box);
  label_child_userinfo = gtk_label_new (" User ");
  label_child_server = gtk_label_new (" Server ");
  label_child_colors = gtk_label_new (" Colors ");
  label_child_general_options = gtk_label_new (" General options ");
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), child_userinfo, label_child_userinfo);
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), child_server, label_child_server);
//  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), child_general_options, label_child_general_options);
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), child_colors, label_child_colors);
  gtk_widget_show (label_nick);
  gtk_widget_show (label_alternate_nick);
  gtk_widget_show (entry_nick);
  gtk_widget_show (entry_alternate_nick);
  gtk_widget_show (box_nick);
  gtk_widget_show (box_alternate_nick);
  gtk_widget_show (label_user);
  gtk_widget_show (entry_user);
  gtk_widget_show (box_user);
  gtk_widget_show (label_gecos);
  gtk_widget_show (entry_gecos);
  gtk_widget_show (box_gecos);
  gtk_widget_show (label_server);
  gtk_widget_show (entry_server);
  gtk_widget_show (box_server);
  gtk_widget_show (label_port);
  gtk_widget_show (entry_port);
  gtk_widget_show (box_port);
  gtk_widget_show (box_color1);
  gtk_widget_show (label_color1);
  gtk_widget_show (box_general_options);
  gtk_widget_show (drawingarea_color1);
 /* gtk_widget_show (label_child_userinfo);
  gtk_widget_show (label_child_server);
  gtk_widget_show (label_child_general_options);
  gtk_widget_show (label_child_colors); */
  gtk_widget_show (child_userinfo);
  gtk_widget_show (child_server);
  gtk_widget_show (child_general_options);
  gtk_widget_show (child_colors);
  gtk_widget_show (notebook);
  gtk_widget_show (window_setup);
  gtk_widget_grab_focus (commandline);
}

/* ========================================================================== *
 * = Pop-up a dialog with about text                                        = *
 * ========================================================================== */
void
about (GtkWidget * widget, gpointer data)
{
  GtkWidget *text;
  GtkWidget *button_ok;
  GtkWidget *pixmapwid;
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GtkStyle *style;

  if (about_w == 2)
    {
      return;			/* If a previous about window exists, don't make another one */
    }
  if (about_w == 1)
    {
      gtk_widget_show (window_about);
      return;
    }
  about_w = 2;
  window_about = gtk_dialog_new ();
  gtk_window_set_title (GTK_WINDOW (window_about), "About XgIRC");
  text = gtk_label_new (ABOUT_TEXT);
  button_ok = gtk_button_new_with_label ("OK");
  gtk_widget_realize (window_about);
  style = gtk_widget_get_style (window_about);
  pixmap = gdk_pixmap_create_from_xpm_d (window_about->window, &mask, &style->bg[GTK_STATE_NORMAL], logo);
  pixmapwid = gtk_pixmap_new (pixmap, mask);
  gtk_box_pack_end (GTK_BOX (GTK_DIALOG (window_about)->vbox), text, TRUE, TRUE, 2);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window_about)->vbox), pixmapwid, TRUE, TRUE, 2);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window_about)->action_area), button_ok, TRUE, TRUE, 2);
  gtk_signal_connect (GTK_OBJECT (button_ok), "clicked", GTK_SIGNAL_FUNC (ok_about_callback), NULL);
  gtk_widget_show (text);
  gtk_widget_show (pixmapwid);
  gtk_widget_show (button_ok);
  gtk_widget_show (window_about);
  gtk_widget_grab_focus (commandline);
}

/* ========================================================================== *
 * = Pop-up dialog with error text 'string'                                 = *
 * ========================================================================== */
void
window_error (char *string)
{
  GtkWidget *window_error;
  GtkWidget *text;
  GtkWidget *button_ok;

  window_error = gtk_dialog_new ();
  gtk_window_set_title (GTK_WINDOW (window_error), "XgIRC Error");
  text = gtk_label_new (string);
  button_ok = gtk_button_new_with_label ("OK");
  gtk_box_pack_end (GTK_BOX (GTK_DIALOG (window_error)->vbox), text, TRUE, TRUE, 2);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (window_error)->action_area), button_ok, TRUE, TRUE, 2);
  gtk_signal_connect_object (GTK_OBJECT (button_ok), "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (window_error));
  gtk_widget_show (text);
  gtk_widget_show (button_ok);
  gtk_widget_show (window_error);
}

/* ========================================================================== *
 * = Returns the commandline box widget                                     = *
 * ========================================================================== */
GtkWidget *
commandline_box (GtkWidget * parent)
{
  GtkWidget *box;

  box = gtk_hbox_new (FALSE, 0);
  commandline = gtk_entry_new_with_max_length (ENTRY_MAXLEN);
  /* style = gtk_style_new();
     style->fg[GTK_STATE_NORMAL] = style->white;
     style->text[GTK_STATE_NORMAL] = style->black;
     style->base[GTK_STATE_NORMAL] = style->black;
     gtk_widget_set_style(commandline, style); */
  for (i = 0; i <= 255; i++)
    {
      strcpy (commandline_buffer[i], "");
    }
  gtk_box_pack_start (GTK_BOX (box), commandline, TRUE, TRUE, 0);
  gtk_signal_connect (GTK_OBJECT (commandline), "activate", GTK_SIGNAL_FUNC (enter_callback), commandline);
  gtk_signal_connect (GTK_OBJECT (commandline), "key_press_event", GTK_SIGNAL_FUNC (key_press_callback), commandline);

/* === We display the widget ============================================= */
  gtk_widget_show (commandline);
/* ======================================================================= */

  return (box);
}

/* ========================================================================== *
 * = Returns the screen box widget                                          = *
 * = Type : 0 = status window, 1 = channel window 2 = query window          = *
 * ========================================================================== */
GtkWidget *
screen_box (GtkWidget * parent, int type)
{
  GtkWidget *box;
  GtkWidget *box_top;
  GtkWidget *box_bottom;
  GtkWidget *box_screen;
  GtkWidget *box_status_chan;
  GtkWidget *box_status_chan1;
  GtkWidget *box_status_chan2;
  GtkWidget *box_userlist;
  GtkWidget *button_part;
  GtkWidget *box_button_part;
  GtkWidget *screen_vscrollbar;
  GtkWidget *window_userlist;
  GtkStyle *style;
  GdkPixmap *icon_close_pixmap;
  GtkWidget *icon_close_pixmapwid;
  GdkBitmap *mask;

  box = gtk_vbox_new (FALSE, 0);
  box_top = gtk_hbox_new (FALSE, 0);
  box_bottom = gtk_hbox_new (FALSE, 0);
  box_status_chan = gtk_vbox_new (FALSE, 0);
  box_status_chan1 = gtk_hbox_new (FALSE, 0);
  box_status_chan2 = gtk_hbox_new (FALSE, 0);
  box_button_part = gtk_hbox_new (FALSE, 0);
  style = gtk_style_new ();
  icon_close_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &mask, &style->bg[GTK_STATE_NORMAL], close_xpm);
  icon_close_pixmapwid = gtk_pixmap_new (icon_close_pixmap, mask);
  button_part = gtk_button_new ();
  gtk_box_pack_start (GTK_BOX (box_button_part), icon_close_pixmapwid, FALSE, FALSE, 0);
  gtk_container_add (GTK_CONTAINER (button_part), box_button_part);
  tooltips2 = gtk_tooltips_new ();
  gtk_tooltips_set_tip (tooltips2, button_part, "Close", NULL);
  if (!option_tooltips)
    gtk_tooltips_disable (tooltips2);
  status_chan1[current_screen] = gtk_label_new (" ");
  status_chan2[current_screen] = gtk_label_new (" ");
  strcpy (channel[current_screen].topic, "");
  update_status_bar (current_screen);
  screen[current_screen] = gtk_text_new (NULL, NULL);
  style->fg[GTK_STATE_NORMAL] = style->white;
  style->bg[GTK_STATE_NORMAL] = style->black;
  style->text[GTK_STATE_NORMAL] = style->white;
  style->base[GTK_STATE_NORMAL] = style->black;
  gtk_widget_set_style (screen[current_screen], style);
  window_userlist = gtk_scrolled_window_new (NULL, NULL);
  list_userlist[current_screen] = gtk_clist_new (1);
  gtk_clist_set_policy (GTK_CLIST (list_userlist[current_screen]), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_clist_set_column_title (GTK_CLIST (list_userlist[current_screen]), 1, "Users");
  gtk_clist_set_foreground (GTK_CLIST (list_userlist[current_screen]), 1, &color_nick2);
  gtk_signal_connect(GTK_OBJECT(list_userlist[current_screen]), "select_row", GTK_SIGNAL_FUNC(userlist_selection_callback), NULL);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (window_userlist), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  if (type == 1)
    gtk_signal_connect (GTK_OBJECT (button_part), "clicked", GTK_SIGNAL_FUNC (button_part_callback), NULL);
  if (type == 2)
    gtk_signal_connect (GTK_OBJECT (button_part), "clicked", GTK_SIGNAL_FUNC (button_close_query_callback), NULL);
  screen_vscrollbar = gtk_vscrollbar_new (GTK_TEXT (screen[current_screen])->vadj);
  box_screen = gtk_hbox_new (FALSE, 0);
  box_userlist = gtk_hbox_new (TRUE, 0);
  gtk_text_set_editable (GTK_TEXT (screen[current_screen]), FALSE);
  gtk_widget_set_usize (box_top, 0, 43);	/* 36 */
  gtk_widget_set_usize (box_userlist, 120, 400);
  gtk_box_pack_start (GTK_BOX (box_status_chan1), status_chan1[current_screen], FALSE, FALSE, 0);
  gtk_box_pack_end (GTK_BOX (box_status_chan1), button_part, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_status_chan2), status_chan2[current_screen], FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_status_chan), box_status_chan1, TRUE, TRUE, 0);
  gtk_box_pack_end (GTK_BOX (box_status_chan), box_status_chan2, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_top), box_status_chan, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (box_userlist), window_userlist, TRUE, TRUE, 3);
  gtk_box_pack_start (GTK_BOX (box_screen), screen[current_screen], TRUE, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (box_screen), screen_vscrollbar, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_bottom), box_screen, TRUE, TRUE, 0);
  gtk_box_pack_end (GTK_BOX (box_bottom), box_userlist, FALSE, FALSE, 0);
  gtk_container_add (GTK_CONTAINER (window_userlist), list_userlist[current_screen]);
  gtk_box_pack_end (GTK_BOX (box), box_top, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box), box_bottom, TRUE, TRUE, 0);
  GTK_WIDGET_UNSET_FLAGS (screen[current_screen], GTK_CAN_FOCUS);
  GTK_WIDGET_UNSET_FLAGS (screen_vscrollbar, GTK_CAN_FOCUS);
  GTK_WIDGET_UNSET_FLAGS (list_userlist[current_screen], GTK_CAN_FOCUS);
  gtk_range_set_update_policy (GTK_RANGE (screen_vscrollbar), GTK_UPDATE_CONTINUOUS);
  if (type == 1)
    gtk_widget_show (box_userlist);
  gtk_widget_show (screen[current_screen]);
  if (type == 1)
    gtk_widget_show (list_userlist[current_screen]);
  gtk_widget_show (screen_vscrollbar);
/*  if (type == 1)
   { */
  gtk_widget_show (status_chan1[current_screen]);
  gtk_widget_show (status_chan2[current_screen]);
/*     } */
  if (type == 1)
    gtk_widget_show (window_userlist);
  gtk_widget_show (button_part);
  gtk_widget_show (box_screen);
  gtk_widget_show (box_status_chan);
  gtk_widget_show (box_status_chan1);
  gtk_widget_show (box_status_chan2);
  gtk_widget_show (box_bottom);
  if (current_screen != 0)
    {
      gtk_widget_show (box_top);
      gtk_widget_show (icon_close_pixmapwid);
      gtk_widget_show (box_button_part);
    }
  return (box);
}

/* ========================================================================== *
 * = Returns the menu box widget                                              = *
 * ========================================================================== */
GtkWidget *
menu_box (GtkWidget * parent)
{
  GtkWidget *box;
  GtkWidget *boxl;
  GtkWidget *boxr;
  GtkWidget *box_buttons;
  GtkWidget *box_button_connect;
  GtkWidget *box_button_setup;
  GtkWidget *box_button_query;
  GtkWidget *box_button_about;
  GtkWidget *box_button_help;
  GtkWidget *box_button_quit;
  GtkWidget *box_status1;
  GtkWidget *box_status2;
//  GtkWidget *label_lagmeter1;
//  GtkWidget *label_lagmeter2;
  GtkWidget *label_stats1;
  GtkWidget *label_stats2;
  GtkWidget *logo_pixmapwid;
  GdkPixmap *logo_pixmap;
  GdkPixmap *icon_connect_pixmap;
  GdkPixmap *icon_deconnect_pixmap;
  GdkPixmap *icon_setup_pixmap;
  GtkWidget *icon_setup_pixmapwid;
  GdkPixmap *icon_about_pixmap;
  GtkWidget *icon_about_pixmapwid;
  GdkPixmap *icon_query_pixmap;
  GtkWidget *icon_query_pixmapwid;
  GdkPixmap *icon_help_pixmap;
  GtkWidget *icon_help_pixmapwid;
  GdkPixmap *icon_quit_pixmap;
  GtkWidget *icon_quit_pixmapwid;
  GdkBitmap *mask;
  GtkStyle *style;
  GtkWidget *button_query;
  GtkWidget *button_about;
  GtkWidget *button_help;
  GtkWidget *button_setup;
  GtkWidget *button_quit;

  box = gtk_hbox_new (FALSE, 0);
  boxl = gtk_vbox_new (FALSE, 0);
  boxr = gtk_vbox_new (FALSE, 0);
  status = gtk_label_new (STATUS_NOT_CONNECTED);
//  label_lagmeter1 = gtk_label_new ("] [ Lag: ");
  //  label_lagmeter2 = gtk_label_new ("]");
  label_lagmeter = gtk_label_new("] [ Lag:  0 ]");
  label_stats1 = gtk_label_new ("[ In:");
  label_stats2 = gtk_label_new ("Out:");
//  lagmeter = gtk_progress_bar_new ();
//  gtk_widget_set_usize (lagmeter, 100, 3);
  box_buttons = gtk_hbox_new (FALSE, 0);
  box_button_connect = gtk_hbox_new (FALSE, 0);
  box_button_setup = gtk_hbox_new (FALSE, 0);
  box_button_about = gtk_hbox_new (FALSE, 0);
  box_button_query = gtk_hbox_new (FALSE, 0);
  box_button_help = gtk_hbox_new (FALSE, 0);
  box_button_quit = gtk_hbox_new (FALSE, 0);
  box_status1 = gtk_hbox_new (FALSE, 0);
  box_status2 = gtk_hbox_new (FALSE, 0);
  gtk_container_border_width (GTK_CONTAINER (box), 0);
  gtk_container_border_width (GTK_CONTAINER (boxl), 0);
  gtk_container_border_width (GTK_CONTAINER (boxr), 0);
  gtk_widget_realize (parent);	/* Needed for gtk_widget_get_style */
  style = gtk_widget_get_style (parent);
  logo_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &mask, &style->bg[GTK_STATE_NORMAL], logo);
  logo_pixmapwid = gtk_pixmap_new (logo_pixmap, mask);
  green_off_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &green_off_pixmapm, &style->bg[GTK_STATE_NORMAL], green_off);
  green_pixmapwid = gtk_pixmap_new (green_off_pixmap, green_off_pixmapm);
  green_on_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &green_on_pixmapm, &style->bg[GTK_STATE_NORMAL], green_on);

  red_off_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &red_off_pixmapm, &style->bg[GTK_STATE_NORMAL], red_off);
  red_on_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &red_on_pixmapm, &style->bg[GTK_STATE_NORMAL], red_on);
  red1_pixmapwid = gtk_pixmap_new (red_off_pixmap, red_off_pixmapm);
  red2_pixmapwid = gtk_pixmap_new (red_off_pixmap, red_off_pixmapm);

  icon_connect_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &mask, &style->bg[GTK_STATE_NORMAL], connect_xpm);
  icon_connect_pixmapwid = gtk_pixmap_new (icon_connect_pixmap, mask);
  icon_deconnect_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &mask, &style->bg[GTK_STATE_NORMAL], deconnect_xpm);
  icon_deconnect_pixmapwid = gtk_pixmap_new (icon_deconnect_pixmap, mask);
  icon_setup_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &mask, &style->bg[GTK_STATE_NORMAL], setup_xpm);
  icon_setup_pixmapwid = gtk_pixmap_new (icon_setup_pixmap, mask);
  icon_about_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &mask, &style->bg[GTK_STATE_NORMAL], about_xpm);
  icon_about_pixmapwid = gtk_pixmap_new (icon_about_pixmap, mask);
  icon_query_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &mask, &style->bg[GTK_STATE_NORMAL], query_xpm);
  icon_query_pixmapwid = gtk_pixmap_new (icon_query_pixmap, mask);
  icon_help_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &mask, &style->bg[GTK_STATE_NORMAL], help_xpm);
  icon_help_pixmapwid = gtk_pixmap_new (icon_help_pixmap, mask);
  icon_quit_pixmap = gdk_pixmap_create_from_xpm_d (parent->window, &mask, &style->bg[GTK_STATE_NORMAL], exit_xpm);
  icon_quit_pixmapwid = gtk_pixmap_new (icon_quit_pixmap, mask);
  button_quit = gtk_button_new ();
  button_setup = gtk_button_new ();
  button_about = gtk_button_new ();
  button_query = gtk_button_new ();
  button_help = gtk_button_new ();
  button_connect = gtk_toggle_button_new ();
  tooltips1 = gtk_tooltips_new ();
  gtk_tooltips_set_tip (tooltips1, button_setup, "Setup", NULL);
  gtk_tooltips_set_tip (tooltips1, button_about, "About", NULL);
  gtk_tooltips_set_tip (tooltips1, button_help, "Help", NULL);
  gtk_tooltips_set_tip (tooltips1, button_connect, "Connect", NULL);
  gtk_tooltips_set_tip (tooltips1, button_quit, "Exit", NULL);
  if (!option_tooltips)
    gtk_tooltips_disable (tooltips1);
  gtk_box_pack_start (GTK_BOX (box_button_connect), icon_connect_pixmapwid, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_button_connect), icon_deconnect_pixmapwid, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_button_setup), icon_setup_pixmapwid, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_button_about), icon_about_pixmapwid, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_button_query), icon_query_pixmapwid, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_button_help), icon_help_pixmapwid, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_button_quit), icon_quit_pixmapwid, FALSE, FALSE, 0);
  gtk_container_add (GTK_CONTAINER (button_connect), box_button_connect);
  gtk_container_add (GTK_CONTAINER (button_setup), box_button_setup);
  gtk_container_add (GTK_CONTAINER (button_about), box_button_about);
  gtk_container_add (GTK_CONTAINER (button_query), box_button_query);
  gtk_container_add (GTK_CONTAINER (button_help), box_button_help);
  gtk_container_add (GTK_CONTAINER (button_quit), box_button_quit);
  gtk_signal_connect (GTK_OBJECT (button_about), "clicked", GTK_SIGNAL_FUNC (about), NULL);
  gtk_signal_connect (GTK_OBJECT (button_setup), "clicked", GTK_SIGNAL_FUNC (setup), NULL);
  gtk_signal_connect (GTK_OBJECT (button_quit), "clicked", GTK_SIGNAL_FUNC (quit_callback), NULL);
  gtk_signal_connect (GTK_OBJECT (button_connect), "clicked", GTK_SIGNAL_FUNC (button_connect_callback), NULL);
  gtk_box_pack_start (GTK_BOX (box_buttons), button_connect, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_buttons), button_setup, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_buttons), button_query, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_buttons), button_help, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_buttons), button_about, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_buttons), button_quit, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_status1), green_pixmapwid, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_status1), status, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_status2), label_stats1, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_status2), red1_pixmapwid, FALSE, FALSE, 3);
//  gtk_box_pack_start (GTK_BOX (box_status2), red2_pixmapwid, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_status2), label_stats2, FALSE, FALSE, 3);
//  gtk_box_pack_start (GTK_BOX (box_status2), red_off2_pixmapwid, FALSE, FALSE, 3);
//  gtk_box_pack_start (GTK_BOX (box_status2), red_on2_pixmapwid, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_status2), red2_pixmapwid, FALSE, FALSE, 3);
//  gtk_box_pack_start (GTK_BOX (box_status2), label_lagmeter1, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_status2), label_lagmeter, FALSE, FALSE, 3);
//  gtk_box_pack_start (GTK_BOX (box_status2), lagmeter, FALSE, FALSE, 3);
//  gtk_box_pack_start (GTK_BOX (box_status2), label_lagmeter2, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (boxl), box_buttons, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (boxl), box_status1, FALSE, FALSE, 5);
  gtk_box_pack_start (GTK_BOX (boxr), box_status2, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box), boxl, FALSE, FALSE, 0);
  gtk_box_pack_end (GTK_BOX (box), boxr, FALSE, FALSE, 0);
  GTK_WIDGET_UNSET_FLAGS (button_connect, GTK_CAN_FOCUS);
  GTK_WIDGET_UNSET_FLAGS (button_setup, GTK_CAN_FOCUS);
  GTK_WIDGET_UNSET_FLAGS (button_about, GTK_CAN_FOCUS);
  GTK_WIDGET_UNSET_FLAGS (button_help, GTK_CAN_FOCUS);
  GTK_WIDGET_UNSET_FLAGS (button_about, GTK_CAN_FOCUS);
  GTK_WIDGET_UNSET_FLAGS (button_quit, GTK_CAN_FOCUS);

  gtk_widget_show (boxl);
  gtk_widget_show (boxr);
  gtk_widget_show (box_buttons);
  gtk_widget_show (box_button_connect);
  gtk_widget_show (box_button_setup);
  gtk_widget_show (box_button_about);
  gtk_widget_show (box_button_query);
  gtk_widget_show (box_button_help);
  gtk_widget_show (box_button_quit);
  gtk_widget_show (box_status1);
  gtk_widget_show (box_status2);
  gtk_widget_show (button_connect);
  gtk_widget_show (button_setup);
/*  gtk_widget_show (button_query); */
  gtk_widget_show (button_about);
  gtk_widget_show (button_help);
  gtk_widget_show (button_quit);
  gtk_widget_show (status);
/*  gtk_widget_show (label_lagmeter1); */
/*  gtk_widget_show (label_lagmeter2); */
  gtk_widget_show (label_lagmeter);
  
  gtk_widget_show (label_stats1);
  gtk_widget_show (label_stats2);
/*  gtk_widget_show (lagmeter); */
/*  gtk_widget_show (logo_pixmapwid); */
  gtk_widget_show (green_pixmapwid);
  gtk_widget_show (red1_pixmapwid);
  gtk_widget_show (red2_pixmapwid);
  gtk_widget_show (icon_connect_pixmapwid);
  gtk_widget_show (icon_setup_pixmapwid);
  gtk_widget_show (icon_about_pixmapwid);
  gtk_widget_show (icon_query_pixmapwid);
  gtk_widget_show (icon_help_pixmapwid);
  gtk_widget_show (icon_quit_pixmapwid);
  return (box);
}

/* ========================================================================== *
 * = Color conversion (ripped)                                              = *
 * ========================================================================== */
static gushort
convert_color (unsigned c)
{
  if (c == 0)
    return (0);
  c *= 257;			/* scale from char to short */
  return (c > 0xffff) ? 0xffff : c;
}

void
extract_color (GdkColor * color, unsigned red, unsigned green, unsigned blue)
{
  color->red = convert_color (red);
  color->green = convert_color (green);
  color->blue = convert_color (blue);
}

/* ========================================================================== *
 * = Updates the userlist window of screen 'scr'                            = *
 * ========================================================================== */
void
update_userlist (int scr)
{
  char *buff;

  if (!GTK_IS_CLIST (list_userlist[scr]))
    {
#ifdef DEBUG
      g_print ("[D] ERROR : list_userlist[%d] is not a CLIST ! Ignoring update... <display.c/update_userlist>\n", scr);
#endif
      return;
    }
  gtk_clist_clear (GTK_CLIST (list_userlist[scr]));
  gtk_clist_freeze (GTK_CLIST (list_userlist[scr]));
  buff = (char *) malloc (NICK_MAXLEN);
  for (i = 1; i <= channel[scr].nb_ops; i++)
    {
      sprintf (buff, "@%s", channel[scr].ops[i]);
      gtk_clist_append (GTK_CLIST (list_userlist[scr]), (gchar **) & buff);
    }
  for (i = 1; i <= channel[scr].nb_nops; i++)
    {
      sprintf (buff, "%s", channel[scr].nops[i]);
      gtk_clist_append (GTK_CLIST (list_userlist[scr]), (gchar **) & buff);
    }
  gtk_clist_thaw (GTK_CLIST (list_userlist[scr]));
}

/* ========================================================================== *
 * = Resets led 1 state                                                     = *
 * ========================================================================== */
int
reset_led1 (gpointer data)
{
  gtk_pixmap_set (GTK_PIXMAP(red1_pixmapwid), red_off_pixmap, red_off_pixmapm);
  red_led1 = 0;
  return (0);
}

/* ========================================================================== *
 * = Resets led 2 state                                                     = *
 * ========================================================================== */
int
reset_led2 (gpointer data)
{
  gtk_pixmap_set (GTK_PIXMAP(red2_pixmapwid), red_off_pixmap, red_off_pixmapm);
  red_led2 = 0;
  return (0);
}

/* ========================================================================== *
 * = Updates the lagmeter to 'lag' seconds                                  = *
 * ========================================================================== */
void
update_lagmeter (int lag)
{
#ifdef DEBUG
  g_print ("[D] Updating lagmeter [Lag : %d] <display.c/update_lagmeter>\n", lag);
#endif
sprintf(buf ,"[ Lag : %d ]", lag); 
gtk_label_set(GTK_LABEL (label_lagmeter), buf);
/*  gtk_progress_bar_update (GTK_PROGRESS_BAR (lagmeter), (gfloat) lag / LAGMETER_SCALE); */
}

/* ========================================================================== *
 * = Returns the general options box widget                                 = *
 * ========================================================================== */
GtkWidget *
general_options_box (GtkWidget * parent)
{
  GtkWidget *box;
  GtkWidget *separator1;
  GtkWidget *separator2;
  GtkWidget *separator3;
  GtkWidget *box_tooltips_option;
  GtkWidget *tooltips_option_check_button;
  GtkWidget *box_whois_option;
  GtkWidget *whois_option_label;
  GtkWidget *whois_option_button1;
  GtkWidget *whois_option_button2;
  GtkWidget *whois_option_button3;
  GSList *whois_option_group;
  GtkWidget *box_wallops_option;
  GtkWidget *wallops_option_label;
  GtkWidget *wallops_option_button1;
  GtkWidget *wallops_option_button2;
  GtkWidget *wallops_option_button3;
  GSList *wallops_option_group;
  GtkWidget *userhost_option_label;
  GtkWidget *box_userhost_option1;

  box = gtk_vbox_new (FALSE, 0);

  box_tooltips_option = gtk_hbox_new (FALSE, 5);
  tooltips_option_check_button = gtk_check_button_new_with_label ("Enable tooltips");
  gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (tooltips_option_check_button), option_tooltips);
  gtk_signal_connect (GTK_OBJECT (tooltips_option_check_button), "clicked", GTK_SIGNAL_FUNC (tooltips_option_callback), NULL);
  gtk_box_pack_start (GTK_BOX (box), box_tooltips_option, FALSE, FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_tooltips_option), tooltips_option_check_button, FALSE, FALSE, 10);
  gtk_widget_show (box_tooltips_option);
  gtk_widget_show (tooltips_option_check_button);
  
  separator1 = gtk_hseparator_new ();
  gtk_box_pack_start (GTK_BOX (box), separator1, FALSE, FALSE, 0);
  gtk_widget_show (separator1);

  box_whois_option = gtk_hbox_new (FALSE, 5);
  whois_option_label = gtk_label_new ("Display whois :");
  whois_option_button1 = gtk_radio_button_new_with_label (NULL, "in status window");
  whois_option_group = gtk_radio_button_group (GTK_RADIO_BUTTON (whois_option_button1));
  whois_option_button2 = gtk_radio_button_new_with_label (whois_option_group, "in current window");
  whois_option_group = gtk_radio_button_group (GTK_RADIO_BUTTON (whois_option_button2));
  whois_option_button3 = gtk_radio_button_new_with_label (whois_option_group, "in both status and current window");
  whois_option_group = gtk_radio_button_group (GTK_RADIO_BUTTON (whois_option_button3));
  gtk_box_pack_start (GTK_BOX (box_whois_option), whois_option_label, FALSE, FALSE, 13);
  gtk_box_pack_end (GTK_BOX (box_whois_option), whois_option_button1, FALSE, FALSE, 3);
  gtk_box_pack_end (GTK_BOX (box_whois_option), whois_option_button2, FALSE, FALSE, 3);
  gtk_box_pack_end (GTK_BOX (box_whois_option), whois_option_button3, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box), box_whois_option, FALSE, FALSE, 0);
  gtk_widget_show (whois_option_label);
  gtk_widget_show (whois_option_button1);
  gtk_widget_show (whois_option_button2);
  gtk_widget_show (whois_option_button3);
  gtk_widget_show (box_whois_option);

  box_wallops_option = gtk_hbox_new (FALSE, 5);
  wallops_option_label = gtk_label_new ("Display wallops :");
  wallops_option_button1 = gtk_radio_button_new_with_label (NULL, "in status window");
  wallops_option_group = gtk_radio_button_group (GTK_RADIO_BUTTON (wallops_option_button1));
  wallops_option_button2 = gtk_radio_button_new_with_label (wallops_option_group, "in current window");
  wallops_option_group = gtk_radio_button_group (GTK_RADIO_BUTTON (wallops_option_button2));
  wallops_option_button3 = gtk_radio_button_new_with_label (wallops_option_group, "in both status and current window");
  wallops_option_group = gtk_radio_button_group (GTK_RADIO_BUTTON (wallops_option_button3));
  gtk_box_pack_start (GTK_BOX (box_wallops_option), wallops_option_label, FALSE, FALSE, 13);
  gtk_box_pack_end (GTK_BOX (box_wallops_option), wallops_option_button1, FALSE, FALSE, 3);
  gtk_box_pack_end (GTK_BOX (box_wallops_option), wallops_option_button2, FALSE, FALSE, 3);
  gtk_box_pack_end (GTK_BOX (box_wallops_option), wallops_option_button3, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box), box_wallops_option, FALSE, FALSE, 0);
  gtk_widget_show (wallops_option_label);
  gtk_widget_show (wallops_option_button1);
  gtk_widget_show (wallops_option_button2);
  gtk_widget_show (wallops_option_button3);
  gtk_widget_show (box_wallops_option);
  
  separator2 = gtk_hseparator_new ();
  gtk_box_pack_start (GTK_BOX (box), separator2, FALSE, FALSE, 0);
  gtk_widget_show (separator2);

  box_userhost_option1 = gtk_hbox_new (FALSE, 5);
  userhost_option_label = gtk_label_new ("Display user@host.domain in :");
  gtk_box_pack_start (GTK_BOX (box_userhost_option1), userhost_option_label, FALSE, FALSE, 13);
  gtk_box_pack_start (GTK_BOX (box), box_userhost_option1, FALSE, FALSE, 0);
  gtk_widget_show (userhost_option_label);
  gtk_widget_show (box_userhost_option1);

  separator3 = gtk_hseparator_new ();
  gtk_box_pack_start (GTK_BOX (box), separator3, FALSE, FALSE, 0);
  gtk_widget_show (separator3);

  return (box);
}
