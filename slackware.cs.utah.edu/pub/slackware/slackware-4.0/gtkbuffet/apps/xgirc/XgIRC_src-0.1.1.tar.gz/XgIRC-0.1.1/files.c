/* This file is part of XgIRC 0.1
   files.c - Files operations

   Copyright (C) 1998 A|vin (Julien Pieraut) <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <strings.h>
#include "main.h"
#include "files.h"
#include "text.h"
#include "system.h"

/* ========================================================================== *
 * = Returns current line from fd 'file' - Ignores lines beggining by '#'   = *
 * ========================================================================== */
char *
read_from_file (FILE * file)
{
  do
    {
      strcpy (buf, fgets (buf, MAXLEN, file));
      buf[strlen (buf) - 1] = '\0';	/* fgets takes the CR, so we must remove it */
    }
  while (buf[0] == '#');	/* Don't return it if that was a comment */
  return (buf); 
}

/* ========================================================================== *
 * = Appends 'string' to fd 'file'                                          = *
 * ========================================================================== */
void
append_to_file (FILE * file, char *string)
{
  while (*string != '\0')
    {
      putc (*string, file);
      string++;
    }
  putc ('\n', file);
}

/* ========================================================================== *
 * = Writes config file - Returns 1 if success, 0 otherwise                 = *
 * ========================================================================== */
int
write_config (void)
{
  FILE *file;

  file = fopen (full_path (CONFIG_FILE), "w");
  if (file == NULL)
    return (0);
  fseek (file, 0, 0);
  append_to_file (file, "############################################\n# XgIRC Config file - DO NOT MANUALLY EDIT #\n############################################");
 sprintf(buf, "version = %s", INTERNAL_VERSION);
 append_to_file(file, buf);
 append_to_file(file, "#\n# User info\n#");
  sprintf (buf, "nick = %s", me.nick);
  append_to_file (file, buf);
  sprintf (buf, "altnick = %s", me.altnick);
  append_to_file (file, buf);
  sprintf (buf, "username = %s", me.user);
  append_to_file (file, buf);
  sprintf (buf, "gecos = %s", me.gecos);
  append_to_file (file, buf);
  sprintf (buf, "server = %s", server);
  append_to_file (file, buf);
  sprintf (buf, "port = %i", port);
  append_to_file (file, buf);
  append_to_file (file, "#\n# Colors allocation\n#");
  sprintf (buf, "color_screen_bg = { %i %i %i }", (int) color_screen_bg.red / 256, (int) color_screen_bg.green / 256, (int) color_screen_bg.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_client_msg = { %i %i %i }", (int) color_client_msg.red / 256, (int) color_client_msg.green / 256, (int) color_client_msg.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_server_msg = { %i %i %i }", (int) color_server_msg.red / 256, (int) color_server_msg.green / 256, (int) color_server_msg.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_time1 = { %i %i %i }", (int) color_time1.red / 256, (int) color_time1.green / 256, (int) color_time1.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_time2 = { %i %i %i }", (int) color_time2.red / 256, (int) color_time2.green / 256, (int) color_time2.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_normal_msg = { %i %i %i }", (int) color_normal_msg.red / 256, (int) color_normal_msg.green / 256, (int) color_normal_msg.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_nick1 = { %i %i %i }", (int) color_nick1.red / 256, (int) color_nick1.green / 256, (int) color_nick1.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_nick2 = { %i %i %i }", (int) color_nick2.red / 256, (int) color_nick2.green / 256, (int) color_nick2.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_server = { %i %i %i }", (int) color_server.red / 256, (int) color_server.green / 256, (int) color_server.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_user = { %i %i %i }", (int) color_user.red / 256, (int) color_user.green / 256, (int) color_user.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_topic = { %i %i %i }", (int) color_topic.red / 256, (int) color_topic.green / 256, (int) color_topic.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_channel = { %i %i %i }", (int) color_channel.red / 256, (int) color_channel.green / 256, (int) color_channel.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_hostdomain = { %i %i %i }", (int) color_hostdomain.red / 256, (int) color_hostdomain.green / 256, (int) color_hostdomain.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_port = { %i %i %i }", (int) color_port.red / 256, (int) color_port.green / 256, (int) color_port.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_motd = { %i %i %i }", (int) color_motd.red / 256, (int) color_motd.green / 256, (int) color_motd.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_ctcp = { %i %i %i }", (int) color_ctcp.red / 256, (int) color_ctcp.green / 256, (int) color_ctcp.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_mode = { %i %i %i }", (int) color_mode.red / 256, (int) color_mode.green / 256, (int) color_mode.blue / 256);
  append_to_file (file, buf);
  sprintf (buf, "color_wallops = { %i %i %i }", (int) color_wallops.red / 256, (int) color_wallops.green / 256, (int) color_wallops.blue / 256);
  append_to_file (file, buf);
  append_to_file (file, "#\n# General options\n#");
  sprintf( buf, "option_tooltips = %i", option_tooltips);
  append_to_file (file, buf);
  sprintf(buf, "option_whois1 = %i", option_whois1);
  append_to_file (file, buf);
  sprintf(buf, "option_whois2 = %i", option_whois2);
  append_to_file (file, buf);
  sprintf(buf, "option_wallops1 = %i", option_wallops1);
  append_to_file (file, buf);
  sprintf(buf, "option_wallops2 = %i", option_wallops2);
  append_to_file (file, buf);
  sprintf(buf, "############################################\n# End of config file                       #\n############################################");
  append_to_file (file, buf);
  fclose (file);
  return (1);
}

/* ========================================================================== *
 * = Reads config file - Returns 1 if success, 0 otherwise                  = *
 * ========================================================================== */
int
read_config (void)
{
  FILE *file;
  int r, g, b;

  file = fopen (full_path (CONFIG_FILE), "r");
  if (file == NULL)
    return (0);
  fseek (file, 0, 0);

/* === Version check ======================================================== */
  strcpy(buf, read_from_file (file));
if (!strcomp(get_arg(buf, 1), "version") || !strcomp(get_arg(buf, 3), INTERNAL_VERSION)) return (0);
/* ========================================================================== */

/* === User info ============================================================ */
  strcpy (me.nick, get_arg (read_from_file (file), 3));
  strcpy (me.altnick, get_arg (read_from_file (file), 3));
  strcpy (me.user, get_arg (read_from_file (file), 3));
  strcpy (me.gecos, get_from_arg (read_from_file (file), 3));
  strcpy (server, get_arg (read_from_file (file), 3));
  port = atoi (get_arg (read_from_file (file), 3));
/* ========================================================================== */

/* === Colors allocation ==================================================== */
  cmap = gdk_colormap_get_system ();
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_screen_bg, r, g, b);
  gdk_color_alloc (cmap, &color_screen_bg);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_client_msg, r, g, b);
  gdk_color_alloc (cmap, &color_client_msg);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_server_msg, r, g, b);
  gdk_color_alloc (cmap, &color_server_msg);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_time1, r, g, b);
  gdk_color_alloc (cmap, &color_time1);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_time2, r, g, b);
  gdk_color_alloc (cmap, &color_time2);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_normal_msg, r, g, b);
  gdk_color_alloc (cmap, &color_normal_msg);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_nick1, r, g, b);
  gdk_color_alloc (cmap, &color_nick1);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_nick2, r, g, b);
  gdk_color_alloc (cmap, &color_nick2);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_server, r, g, b);
  gdk_color_alloc (cmap, &color_server);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_user, r, g, b);
  gdk_color_alloc (cmap, &color_user);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_topic, r, g, b);
  gdk_color_alloc (cmap, &color_topic);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_channel, r, g, b);
  gdk_color_alloc (cmap, &color_channel);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_hostdomain, r, g, b);
  gdk_color_alloc (cmap, &color_hostdomain);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_port, r, g, b);
  gdk_color_alloc (cmap, &color_port);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_motd, r, g, b);
  gdk_color_alloc (cmap, &color_motd);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_ctcp, r, g, b);
  gdk_color_alloc (cmap, &color_ctcp);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_mode, r, g, b);
  gdk_color_alloc (cmap, &color_mode);
  strcpy (buf, read_from_file (file));
  r = atoi (get_arg (buf, 4));
  g = atoi (get_arg (buf, 5));
  b = atoi (get_arg (buf, 6));
  extract_color (&color_wallops, r, g, b);
  gdk_color_alloc (cmap, &color_wallops);
/* ========================================================================== */

/* === General options ====================================================== */
option_tooltips = atoi (get_arg (read_from_file (file), 3));
option_whois1 = atoi (get_arg (read_from_file (file), 3));
option_whois2 = atoi (get_arg (read_from_file (file), 3));
option_wallops1 = atoi (get_arg (read_from_file (file), 3));
option_wallops2 = atoi (get_arg (read_from_file (file), 3));
/* ========================================================================== */

  fclose (file);
  return (1);
}
