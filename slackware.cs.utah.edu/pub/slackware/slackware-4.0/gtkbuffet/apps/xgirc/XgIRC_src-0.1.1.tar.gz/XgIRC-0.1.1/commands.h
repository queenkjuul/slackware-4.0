/* This file is part of XgIRC 0.1
   commands.h - Header file for commands.c

   Copyright (C) 1998 Julien Pieraut <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

int command_part (char *chan);
int command_join (char *chan);
int command_me (char *action);
int command_nick (char *nick);
int command_quote (char *text);
int command_whois (char *nick);
int command_topic (char *topic);
int command_query (char *nick);
int command_mode (char *mode);
int command_ctcp (char *what, char *ctcp, char *data);
int command_quit (char *text);
