/* This file is part of XgIRC 0.1
   menus.h - Header file for menus.c

   Copyright (C) 1998 Julien Pieraut <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "display.h"
#include "callback.h"

static GtkMenuEntry menu_items[] =
{
  {"<Main>/File/Exit", "<alt>Q", quit_callback, NULL},
  {"<Main>/Setup/Server setup", "<control>S", NULL, NULL},
  {"<Main>/Setup/User setup", "<control>U", NULL, NULL},
  {"<Main>/Setup/Colors setup", "<control>O", NULL, NULL},
  {"<Main>/Setup/General options", "<control>O", NULL, NULL},
  {"<Main>/DCC/Send", NULL, NULL, NULL},
  {"<Main>/DCC/Chat", NULL, NULL, NULL},
  {"<Main>/DCC/Options", NULL, NULL, NULL},
  {"<Main>/Commands/Open a new query", NULL, NULL, NULL},
  {"<Main>/Commands/Join a new channel", "<control>J", NULL, NULL},
  {"<Main>/Commands/Quit IRC", "<control>Q", NULL, NULL},
  {"<Main>/Help/Client help", "<control>H", NULL, NULL},
  {"<Main>/Help/IRC general info", NULL, NULL, NULL},
  {"<Main>/Help/About", NULL, about, NULL}
};
static int nmenu_items = sizeof (menu_items) / sizeof (menu_items[0]);
static int initialize = TRUE;
static GtkMenuFactory *factory = NULL;
static GtkMenuFactory *subfactory[1];
static GHashTable *entry_ht = NULL;
static void menus_remove_accel (GtkWidget * widget, gchar * signal_name, gchar * path);
static gint menus_install_accel (GtkWidget * widget, gchar * signal_name, gchar key, gchar modifiers, gchar * path);
void menus_init (void);
void menus_create (GtkMenuEntry * entries, int nmenu_entries);
