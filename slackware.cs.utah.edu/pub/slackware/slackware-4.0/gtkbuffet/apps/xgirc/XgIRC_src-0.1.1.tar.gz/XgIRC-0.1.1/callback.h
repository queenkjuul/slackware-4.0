/* This file is part of XgIRC 0.1
   callback.h -  Header file for callback.c

   Copyright (C) 1998 A|vin (Julien Pieraut) <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>

void button_connect_callback (GtkWidget * widget, gpointer data);
void ok_about_callback (GtkWidget * widget, gpointer data);
void ok_setup_callback (GtkWidget * widget, gpointer data);
void cancel_setup_callback (GtkWidget * widget, gpointer data);
void button_part_callback (GtkWidget * widget, gpointer data);
void button_close_query_callback (GtkWidget * widget, gpointer data);
void enter_callback (GtkWidget * widget, GtkWidget * entry);
void key_press_callback (GtkWidget * widget, GdkEventKey * event);
void quit_callback (GtkWidget * widget, gpointer data);
void tooltips_option_callback (GtkWidget * widget, gpointer data);
void whois_option1_callback (GtkWidget * widget, gpointer data);
void whois_option2_callback (GtkWidget * widget, gpointer data);
void wallops_option1_callback (GtkWidget * widget, gpointer data);
void wallops_option2_callback (GtkWidget * widget, gpointer data);
void userlist_selection_callback ( GtkWidget *clist, gint row, gint column, GdkEventButton *event, gpointer data);
