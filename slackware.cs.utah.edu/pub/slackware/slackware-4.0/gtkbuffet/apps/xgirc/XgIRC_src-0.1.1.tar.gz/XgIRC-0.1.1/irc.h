/* This file is part of XgIRC 0.1
   irc.h - header file for irc.c

   Copyright (C) 1998 Julien Pieraut <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define CTCP_VERSION_REPLY "XgIRC %s by A|vin"
#define CTCP_CLIENTINFO_REPLY "ACTION CLIENTINFO PING TIME VERSION"
#define COMMAND_CHAR '/'

void answer_ctcp (char *ctcp, char *nick, char *data, int scr);
int find_query (char *nick);
int find_channel (char *chn);
int connect_to_server (char *server, int port);
int close_server_connection (int s, char *reason);
void parse_from_server (int s);
void send_to_server (int s, char *string);
void remove_from_userlist (int chn, char *user);
void add_to_userlist (int chn, char *user);
int is_in_channel (int chn, char *nick);
int check_lag (gpointer data);
