/* This file is part of XgIRC 0.1
   strings.h - header file for strings.c

   Copyright (C) 1998 Julien Pieraut <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

int strcomp (char *s1, char *s2);
int count_args (char *line);
char *get_the_time (void);
int get_seconds_counter (void);
char *get_arg (char *line, int n);
char *get_from_arg (char *line, int n);
char *get_nick (char *string);
char *get_user (char *string);
char *get_hostdomain (char *string);
char *strip_fchr (char *string);
char *int_to_string (int n);
char *strip_strange_chars (char *string);
char *seconds_to_time (int seconds);
char *upper_case (char *string);
int is_in_string (char c, char *string);
int count_lines (char *string);
char * get_line(char *string, int n);
