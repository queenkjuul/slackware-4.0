/* This file is part of XgIRC 0.1
   callback.c - Callbacks functions

   Copyright (C) 1998 A|vin (Julien Pieraut) <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gdk/gdkkeysyms.h>
#include "main.h"
#include "callback.h"
#include "strings.h"
#include "text.h"
#include "display.h"
#include "files.h"

/* ========================================================================== *
 * = OK about window callback                                               = *
 * ========================================================================== */
void
ok_about_callback (GtkWidget * widget, gpointer data)
{
  about_w = 1;
  gtk_widget_hide (window_about);
}

/* ========================================================================== *
 * = OK setup window callback                                               = *
 * ========================================================================== */
void
ok_setup_callback (GtkWidget * widget, gpointer data)
{
  if (connected == -1)
    {
#ifdef DEBUG
      g_print ("[D] OK setup button pressed, writing config file...");
#endif
      strcpy (me.nick, gtk_entry_get_text (GTK_ENTRY (entry_nick)));
      strcpy (me.altnick, gtk_entry_get_text (GTK_ENTRY (entry_alternate_nick)));
      strcpy (me.user, gtk_entry_get_text (GTK_ENTRY (entry_user)));
      strcpy (me.gecos, gtk_entry_get_text (GTK_ENTRY (entry_gecos)));
      strcpy (server, gtk_entry_get_text (GTK_ENTRY (entry_server)));
      port = atoi (gtk_entry_get_text (GTK_ENTRY (entry_port)));
      if (write_config ())
	{
#ifdef DEBUG
	  g_print (" [OK] <callback.c/ok_setup_callback>\n");
#endif
	  /* gtk_widget_hide (window_setup); */
	}
      else
	{
#ifdef DEBUG
	  g_print (buf, " Error writing config file \"%s\". \n Check the permissions of this file \n and of its directory. ", CONFIG_FILE);
	  window_error (buf);
	  g_print (" [ERROR] <callback.c/ok_setup_callback>\n");
#endif
	}
    }
  else
    {
      window_error (" Cannot change userinfo \n while connecting to server, or \n if already connected. \n");
    }
}

/* ========================================================================== *
 * = Cancel setup window callback                                           = *
 * ========================================================================== */
void
cancel_setup_callback (GtkWidget * widget, gpointer data)
{
  gtk_widget_destroy (window_setup);
  setup_w = 0;
}

/* ========================================================================== *
 * = Tooltips option callback                                               = *
 * ========================================================================== */
void
tooltips_option_callback (GtkWidget * widget, gpointer data)
{
  if (GTK_TOGGLE_BUTTON (widget)->active)
    {
      option_tooltips = 1;
      gtk_tooltips_enable (tooltips1);
      gtk_tooltips_enable (tooltips2);
      return;
    }
  option_tooltips = 0;
  gtk_tooltips_disable (tooltips1);
  gtk_tooltips_disable (tooltips2);
}

/* ========================================================================== *
 * = Whois option 1 callback                                                = *
 * ========================================================================== */
void
whois_option1_callback (GtkWidget * widget, gpointer data)
{
  if (GTK_TOGGLE_BUTTON (widget)->active)
    {
      option_whois1 = 1;
      return;
    }
  option_whois1 = 0;
}

/* ========================================================================== *
 * = Whois option 2 callback                                                = *
 * ========================================================================== */
void
whois_option2_callback (GtkWidget * widget, gpointer data)
{
  if (GTK_TOGGLE_BUTTON (widget)->active)
    {
      option_whois2 = 1;
      return;
    }
  option_whois2 = 0;
}

/* ========================================================================== *
 * = Wallops option 1 callback                                              = *
 * ========================================================================== */
void
wallops_option1_callback (GtkWidget * widget, gpointer data)
{
  if (GTK_TOGGLE_BUTTON (widget)->active)
    {
      option_wallops1 = 1;
      return;
    }
  option_wallops1 = 0;
}

/* ========================================================================== *
 * = Wallops option 2 callback                                              = *
 * ========================================================================== */
void
wallops_option2_callback (GtkWidget * widget, gpointer data)
{
  if (GTK_TOGGLE_BUTTON (widget)->active)
    {
      option_wallops2 = 1;
      return;
    }
  option_wallops2 = 0;
}

/* ========================================================================== *
 * = Connect button callback                                                = *
 * ========================================================================== */
void
button_connect_callback (GtkWidget * widget, gpointer data)
{
  if (GTK_TOGGLE_BUTTON (widget)->active)
    {
      if (connect_to_server (server, port) < 0)
	{
	  gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (widget), FALSE);
	  gtk_label_set (GTK_LABEL (status), STATUS_NOT_CONNECTED);
	  gtk_pixmap_set (GTK_PIXMAP(green_pixmapwid), green_off_pixmap, green_off_pixmapm);
	  return;
	}
    }
  else
    {
      close_server_connection (s, "");
      for (i = 1; i <= total_screens; i++)
	{			/* We close all windows */
	  gtk_notebook_remove_page (GTK_NOTEBOOK (screen_notebook), 1);
	}
      gtk_widget_show (icon_connect_pixmapwid);
      gtk_widget_hide (icon_deconnect_pixmapwid);
      current_screen = 0;
      total_screens = 0;
      total_channels = 0;
      total_queries = 0;
      gtk_notebook_set_page (GTK_NOTEBOOK (screen_notebook), current_screen);	/* Back to the status window */
    }
}

/* ========================================================================== *
 * = Part channel button callback                                           = *
 * ========================================================================== */
void
button_part_callback (GtkWidget * widget, gpointer data)
{
  current_screen = gtk_notebook_current_page (GTK_NOTEBOOK (screen_notebook));	/* We get the current screen... */
#ifdef DEBUG
  g_print ("[D] Part button pressed on screen %i [Channel : %s] <callback.c/button_part_callback>\n", current_screen, channel[current_screen].name);
#endif
  command_part (channel[current_screen].name);
  gtk_widget_grab_focus (commandline);
}

/* ========================================================================== *
 * = Close query button callback                                            = *
 * ========================================================================== */
void
button_close_query_callback (GtkWidget * widget, gpointer data)
{
  current_screen = gtk_notebook_current_page (GTK_NOTEBOOK (screen_notebook));	/* We get the current screen... */
#ifdef DEBUG
  g_print ("[D] Close button pressed on screen %i [Query : %s] <callabck.c/button_close_query_callback>\n", current_screen, query[current_screen - total_channels].nick);
#endif
  gtk_notebook_remove_page (GTK_NOTEBOOK (screen_notebook), current_screen);
  for (i = current_screen; i <= total_screens - 1; i++)
    {
      screen[i] = screen[i + 1];
      strcpy (query[i - total_channels].nick, query[i - total_channels + 1].nick);
    }
  total_screens--;
  total_queries--;
  current_screen = current_screen--;
  gtk_notebook_set_page (GTK_NOTEBOOK (screen_notebook), current_screen);
  gtk_widget_grab_focus (commandline);
}

/* ========================================================================== *
 * = Enter key in commandline callback                                      = *
 * ========================================================================== */
void
enter_callback (GtkWidget * widget, GtkWidget * entry)
{
  int k;
  gchar *entry_text;
  char to_server[MAXLEN];

  current_screen = gtk_notebook_current_page (GTK_NOTEBOOK (screen_notebook));
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
  strcpy (current_channel, "status");
  if ((current_screen != 0) && (current_screen <= total_channels))	/* If the current screen is a channel screen */
    {
      strcpy (current_channel, channel[current_screen].name);
#ifdef DEBUG
      g_print ("[D] Typed text on screen %i [Channel : %s] : %s <callback.c/enter_callback>\n", current_screen, current_channel, entry_text);
#endif
    }
  if ((current_screen != 0) && (current_screen > total_channels))	/* If the current screen is a query screen */
    {
      strcpy (current_channel, query[current_screen - total_channels].nick);
#ifdef DEBUG
      g_print ("[D] Typed text on screen %i [Query : %s] : %s <callback.c/enter_callback>\n", current_screen, current_channel, entry_text);
#endif
    }
#ifdef DEBUG
  if (current_screen == 0)
    {
      g_print ("[D] Typed text on screen 0 [Status] : %s <callback.c/enter_callback>\n", entry_text);
    }
#endif
  if (!strcomp (entry_text, ""))
    {
      for (k = 1; k <= count_lines (entry_text); k++)
	{
	  send_to_server (s, get_line (entry_text, k));
	  for (i = 0; i <= 254; i++)
	    {
	      strcpy (commandline_buffer[255 - i], commandline_buffer[254 - i]);
	    }
	}
    }
  commandline_buffer_pos = 0;
  strcpy (commandline_buffer[0], entry_text);
  gtk_entry_set_text (GTK_ENTRY (entry), "");
}

/* ========================================================================== *
 * = Keypress in commandline callback                                       = *
 * ========================================================================== */
void
key_press_callback (GtkWidget * widget, GdkEventKey * event)
{
  switch (event->keyval)
    {
    case GDK_Up:
      gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event");
#ifdef DEBUG
      g_print ("[D] Up key pressed - Getting previous string in commandline buffer... [Current position : %i] ", commandline_buffer_pos);
#endif
      if (!strcomp (commandline_buffer[commandline_buffer_pos], ""))
	{
	  gtk_entry_set_text (GTK_ENTRY (commandline), commandline_buffer[commandline_buffer_pos]);
	  commandline_buffer_pos++;
	  if (commandline_buffer_pos == 256)
	    commandline_buffer_pos = 0;
	}
      else
	{
	  commandline_buffer_pos = 0;
	}
#ifdef DEBUG
      g_print ("[OK] <callback.c/key_press_callback>\n");
#endif
      return;
    case GDK_Down:
      gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event");
#ifdef DEBUG
      g_print ("[D] Down key pressed - Getting next string in commandline buffer... [Current position : %i] ", commandline_buffer_pos);
#endif
      commandline_buffer_pos--;
      if (commandline_buffer_pos == -1)
	commandline_buffer_pos = 255;
      while (strcomp (commandline_buffer[commandline_buffer_pos], "") && commandline_buffer_pos != 0)
	{
	  commandline_buffer_pos--;
	  if (commandline_buffer_pos == -1)
	    commandline_buffer_pos = 255;
	}
      gtk_entry_set_text (GTK_ENTRY (commandline), commandline_buffer[commandline_buffer_pos]);
#ifdef DEBUG
      g_print ("[OK] <callback.c/key_press_callback>\n");
#endif
      return;
    case GDK_Tab:
      gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event");
#ifdef DEBUG
      g_print ("[D] Tab key pressed <callback.c/key_press_callback>\n");
#endif
      return;
    }
}

/* ========================================================================== *
 * = Program quit callback                                                  = *
 * ========================================================================== */
void
quit_callback (GtkWidget * widget, gpointer data)
{
#ifdef DEBUG
  g_print ("[D] Exiting <callback.c/quit_callback>\n");
#endif
  gdk_input_remove (s);
  sprintf (buf, "QUIT :%s has no reason", me.nick);
  sendln (s, buf);
  gtk_main_quit ();
}

/* ========================================================================== *
 * = Userlist selection callback                                            = *
 * ========================================================================== */
void
userlist_selection_callback (GtkWidget * clist, gint row, gint column, GdkEventButton * event, gpointer data)
{
  gchar *text;

  gtk_clist_get_text (GTK_CLIST (clist), row, column, &text);
#ifdef DEBUG
  g_print ("[D] Row %d selected [%s] <callback.c/userlist_selection_callback>\n", row, text);
#endif
  return;
}
