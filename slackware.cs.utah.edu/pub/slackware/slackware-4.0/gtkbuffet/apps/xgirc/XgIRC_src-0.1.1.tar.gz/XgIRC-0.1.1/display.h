/* This file is part of XgIRC 0.1
   display.h - Header file for display.c

   Copyright (C) 1998 Julien Pieraut <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>

#define ABOUT_TEXT "\n XgIRC by A|vin (Julien Pieraut) \n\n Contact : alvin@another-world.com \n\n Web : http://www.xgirc.home.ml.org \n"
#define STATUS_NOT_CONNECTED "[ Not connected ]"
#define STATUS_CONNECTING "[ Connecting to %s:%i... ]"
#define STATUS_CONNECTED "[ %s (%s) on %s:%i ]"
#define ENTRY_MAXLEN 1024	/* Must be << MAXLEN */
#define MAX_SCREENS 256
#define LEDS_LIT_DURATION 400	/* In milliseconds */
#define LAGMETER_SCALE 60	/* IN seconds */

char commandline_buffer[MAX_SCREENS][MAXLEN];
int commandline_buffer_pos;
GtkWidget *screen[MAX_SCREENS];
GtkWidget *window_main;
GtkWidget *commandline;
GtkWidget *box_screen[MAX_SCREENS];
GtkWidget *status_chan1[MAX_SCREENS];
GtkWidget *status_chan2[MAX_SCREENS];
GtkWidget *screen_notebook;
GtkWidget *entry_nick;
GtkWidget *entry_alternate_nick;
GtkWidget *entry_user;
GtkWidget *entry_gecos;
GtkWidget *entry_server;
GtkWidget *entry_port;
GtkWidget *window_about;
GtkWidget *window_setup;
GtkWidget *button_connect;
GtkWidget *status;
GtkWidget *list_userlist[MAX_SCREENS];

GtkWidget *green_pixmapwid;
GtkWidget *red1_pixmapwid;
GtkWidget *red2_pixmapwid;

GdkPixmap *green_off_pixmap;
GdkPixmap *green_on_pixmap;
GdkPixmap *red_off_pixmap;
GdkPixmap *red_on_pixmap;

GdkBitmap *red_on_pixmapm;
GdkBitmap *red_off_pixmapm;
GdkBitmap *green_on_pixmapm;
GdkBitmap *green_off_pixmapm;


GtkWidget *lagmeter;
int red_led1, red_led2;
GtkWidget *icon_connect_pixmapwid;
GtkWidget *icon_deconnect_pixmapwid;
GtkTooltips *tooltips1, *tooltips2;

void update_status_bar (int scr);
gint delete_event (GtkWidget * widget, gpointer data);
void about (GtkWidget * widget, gpointer data);
void window_error (char *string);
GtkWidget *commandline_box (GtkWidget * parent);
void setup (GtkWidget * widget, gpointer data);
GtkWidget *screen_box (GtkWidget * parent, int type);
GtkWidget *menu_box (GtkWidget * parent);
static gushort convert_color (unsigned c);
void extract_color (GdkColor * color, unsigned red, unsigned green, unsigned blue);
void update_userlist (int scr);
int reset_led1 (gpointer data);
int reset_led2 (gpointer data);
void update_lagmeter (int lag);
GtkWidget *general_options_box (GtkWidget * parent);
