/* This file is part of XgIRC 0.1
   system.c - System-related functions

   Copyright (C) 1998 A|vin (Julien Pieraut) <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <pwd.h>
#include <sys/utsname.h>
#include "main.h"

/* ========================================================================== *
 * = Returns the string "hostname [proc_type - os_type os_version]"         = *
 * ========================================================================== */
char *
host (void)
{
  struct utsname un;
  char *os_type;
  char *os_version;
  char *proc_type;
  char *hostname;
  char *reply;

  if (uname (&un) < 0)
    {
      os_version = "";
      os_type = "unknown";
      proc_type = "";
      hostname = "";
    }
  else
    {
      os_version = un.release;
      os_type = un.sysname;
      proc_type = un.machine;
      hostname = un.nodename;
    }
  reply = (char *) malloc (strlen (os_version) + strlen (os_type) + strlen (proc_type) + strlen (hostname) + 8);
  sprintf (reply, "%s [%s - %s %s]", hostname, proc_type, os_type, os_version);
  return (reply);
}

/* ========================================================================== *
 * = Returns fullpath of filename 'file' (i.e without the ~ char)           = *
 * ========================================================================== */
char *
full_path (char *file)
{
  struct passwd *pwd;
  char *result, *home;

  if (*file != '~')
    return (file);
  home = getenv ("HOME");
  if (home == NULL)
    {
      if ((pwd = getpwuid (getuid ())) == NULL)
	home = NULL;
      else
	home = pwd->pw_dir;
    }
  if (home == NULL || *home == '\0')
    {
#ifdef DEBUG
      g_print ("[D] WARNING : Unable to locate home directory <system.c/full_path>");
#endif
      return (file);
    }
  result = (char *) g_malloc (strlen (file) + strlen (home));
  sprintf (result, "%s%s", home, file + 1);
  return result;
}
