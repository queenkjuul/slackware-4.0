/* This file is part of XgIRC 0.1
   text.h - Header file for text.c

   Copyright (C) 1998 Julien Pieraut <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#include <gdk/gdk.h>

#define CONNECTING_MSG "Connecting to "
#define CONNECTED_MSG "Connected to "
#define DISCONNECTED_MSG "Disconnected from "
#define ERROR_CONNECTING_MSG "Error connecting to "
#define ERROR_NOT_CONNECTED_MSG "Not connected to server"
#define ERROR_NOT_A_CMD_MSG "Invalid command name"
#define ERROR_NOT_ON_A_CHANNEL_MSG "You're not on a channel"
#define MOTD_HEADER_MSG "Message of the day :"
#define MOTD_FOOTER_MSG "End of MOTD"
#define DEFAULT_COLOR_SCREEN_BG_R 0
#define DEFAULT_COLOR_SCREEN_BG_G 0
#define DEFAULT_COLOR_SCREEN_BG_B 0
#define DEFAULT_COLOR_CLIENT_MSG_R 255
#define DEFAULT_COLOR_CLIENT_MSG_G 255
#define DEFAULT_COLOR_CLIENT_MSG_B 0
#define DEFAULT_COLOR_SERVER_MSG_R 255
#define DEFAULT_COLOR_SERVER_MSG_G 255
#define DEFAULT_COLOR_SERVER_MSG_B 0
#define DEFAULT_COLOR_TIME1_R 255
#define DEFAULT_COLOR_TIME1_G 0
#define DEFAULT_COLOR_TIME1_B 0
#define DEFAULT_COLOR_TIME2_R 255
#define DEFAULT_COLOR_TIME2_G 255
#define DEFAULT_COLOR_TIME2_B 255
#define DEFAULT_COLOR_NORMAL_MSG_R 255
#define DEFAULT_COLOR_NORMAL_MSG_G 255
#define DEFAULT_COLOR_NORMAL_MSG_B 255
#define DEFAULT_COLOR_NICK1_R 255
#define DEFAULT_COLOR_NICK1_G 255
#define DEFAULT_COLOR_NICK1_B 0
#define DEFAULT_COLOR_NICK2_R 200
#define DEFAULT_COLOR_NICK2_G 200
#define DEFAULT_COLOR_NICK2_B 255
#define DEFAULT_COLOR_SERVER_R 0
#define DEFAULT_COLOR_SERVER_G 255
#define DEFAULT_COLOR_SERVER_B 0
#define DEFAULT_COLOR_USER_R 180
#define DEFAULT_COLOR_USER_G 150
#define DEFAULT_COLOR_USER_B 255
#define DEFAULT_COLOR_TOPIC_R 50
#define DEFAULT_COLOR_TOPIC_G 230
#define DEFAULT_COLOR_TOPIC_B 30
#define DEFAULT_COLOR_CHANNEL_R 240
#define DEFAULT_COLOR_CHANNEL_G 110
#define DEFAULT_COLOR_CHANNEL_B 255
#define DEFAULT_COLOR_HOSTDOMAIN_R 90
#define DEFAULT_COLOR_HOSTDOMAIN_G 160
#define DEFAULT_COLOR_HOSTDOMAIN_B 215
#define DEFAULT_COLOR_PORT_R 200
#define DEFAULT_COLOR_PORT_G 200
#define DEFAULT_COLOR_PORT_B 20
#define DEFAULT_COLOR_MOTD_R 190
#define DEFAULT_COLOR_MOTD_G 170
#define DEFAULT_COLOR_MOTD_B 140
#define DEFAULT_COLOR_CTCP_R 255
#define DEFAULT_COLOR_CTCP_G 0
#define DEFAULT_COLOR_CTCP_B 0
#define DEFAULT_COLOR_MODE_R 255
#define DEFAULT_COLOR_MODE_G 200
#define DEFAULT_COLOR_MODE_B 0
#define DEFAULT_COLOR_WALLOPS_R 140
#define DEFAULT_COLOR_WALLOPS_G 150
#define DEFAULT_COLOR_WALLOPS_B 120

GdkColormap *cmap;
GdkColor color_client_msg;
GdkColor color_screen_bg;
GdkColor color_server_msg;
GdkColor color_time1;
GdkColor color_time2;
GdkColor color_normal_msg;
GdkColor color_nick1;
GdkColor color_nick2;
GdkColor color_server;
GdkColor color_user;
GdkColor color_topic;
GdkColor color_channel;
GdkColor color_hostdomain;
GdkColor color_port;
GdkColor color_motd;
GdkColor color_ctcp;
GdkColor color_mode;
GdkColor color_wallops;

void text_space (int scr);
void text_cr (int scr);
void text_time (int scr);
void text_client_msg (int scr);
void text_server_msg (int scr);
void text_connect (char *server, int port);
void text_connected (void);
void text_disconnect (void);
void text_ping_from_server (void);
void text_motd_header (void);
void text_motd_footer (void);
void text_motd (char *motd);
void text_channel_msg (int scr, char *nick, char *msg);
void text_own_channel_msg (char *nick, char *msg);
void text_join (int scr, char *nick, char *user, char *hostdomain);
void text_my_join (char *channel);
void text_server_raw (char *msg);
void text_part (int src, char *nick, char *user, char *hostdomain);
void text_my_part (char *channel);
void text_topic (int scr, char *nick, char *user, char *hostdomain, char *topic);
void text_me (int scr, char *nick, char *msg);
void text_ctcp (int scr, char *nick, char *ctcp);
void text_error_connect (char *server, int port);
void text_error_not_connected (void);
void text_error_not_a_cmd (char *cmd);
void text_error_not_on_a_channel (void);
void text_kick (int scr, char *by, char *nick, char *msg);
void text_nick (int scr, char *nick1, char *nick2);
void text_my_kick (char *nick, char *chn, char *msg);
void text_whois1 (int scr, char *nick, char *user, char *hostdomain, char *ircgecos);
void text_whois2 (int scr, char *nick, char *channels);
void text_whois3 (int scr, char *nick, char *server, char *serverinfo);
void text_whois4 (int scr, char *nick, char *idle, char *signon);
void text_error (int scr, char *what, char *msg);
void text_error2 (int scr, char *msg);
void text_quit (int scr, char *nick, char *user, char *hostdomain, char *msg);
void text_own_nick (int scr, char *nick);
void text_mode (int scr, char *nick, char *modes, char *data);
void text_notice (int scr, char *nick, char *msg, int type);
void text_wallops (char *nick, char *msg);
void text_server_wallops (char *msg);
void text_ctcp_reply (char *nick, char *ctcp, char *data);
