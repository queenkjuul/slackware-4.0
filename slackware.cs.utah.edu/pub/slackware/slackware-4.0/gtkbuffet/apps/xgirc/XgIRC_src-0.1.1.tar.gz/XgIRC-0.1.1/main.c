/* This file is part of XgIRC 0.1
   main.c - Main interface and program initialisation

   Copyright (C) 1998 A|vin (Julien Pieraut) <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "main.h"
#include "display.h"
#include "menus.h"
#include "text.h"

/* ========================================================================== *
 * = main()                                                                 = *
 * ========================================================================== */
main (int argc, char *argv[])
{
/* === Gtk initialisation =================================================== */
  gtk_init (&argc, &argv);
/* ========================================================================== */

/* === Main window initialisation =========================================== */
#ifdef DEBUG
  g_print ("[D] Interface initialisation... <main.c/main>");
#endif
  window_main = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window_main), "XgIRC");
  gtk_signal_connect (GTK_OBJECT (window_main), "delete_event", GTK_SIGNAL_FUNC (delete_event), NULL);
  gtk_signal_connect (GTK_OBJECT (window_main), "destroy", GTK_SIGNAL_FUNC (quit_callback), NULL);
  gtk_container_border_width (GTK_CONTAINER (window_main), 3);
  gtk_widget_set_usize (window_main, 640, 400);
/* ========================================================================== */

/* === Interface main widgets =============================================== */
  box_menu = menu_box (window_main);
  screen_notebook = gtk_notebook_new ();
  gtk_notebook_set_show_border (GTK_NOTEBOOK (screen_notebook), TRUE);
  GTK_WIDGET_UNSET_FLAGS (screen_notebook, GTK_CAN_FOCUS);
  box_screen[0] = screen_box (window_main, 0);
  gtk_notebook_append_page (GTK_NOTEBOOK (screen_notebook), box_screen[0], gtk_label_new ("Status"));
  box_commandline = commandline_box (window_main);
  get_main_menu (&menubar, &accel);
  gtk_window_add_accelerator_table (GTK_WINDOW (window_main), accel);
  gtk_widget_set_usize (menubar, 640, 26);
/* ========================================================================== */

/* === Main window packing ================================================== */
  box_main = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (box_main), menubar, FALSE, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (box_main), box_menu, FALSE, FALSE, 3);
  gtk_box_pack_start (GTK_BOX (box_main), screen_notebook, TRUE, TRUE, 3);
  gtk_box_pack_end (GTK_BOX (box_main), box_commandline, FALSE, FALSE, 3);
  gtk_container_add (GTK_CONTAINER (window_main), box_main);
/* ========================================================================== */

/* === Widgets Display ====================================================== */
  gtk_widget_show (screen_notebook);
  gtk_widget_show (box_menu);
  gtk_widget_show (box_screen[0]);
  gtk_widget_show (box_commandline);
  gtk_widget_show (box_main);
  gtk_widget_show (menubar);
  gtk_widget_show (window_main);
  gtk_widget_grab_focus (commandline);
#ifdef DEBUG
 g_print (" [OK]\n");
#endif
/* ========================================================================== */

/* Global variables initialisation ========================================== */
  strcpy (me.nick, DEFAULT_NICK);
  strcpy (me.altnick, me.nick);
  strcpy (me.user, DEFAULT_USER);
  strcpy (me.gecos, DEFAULT_GECOS);
  strcpy (me.usermode, DEFAULT_USERMODE);
  strcpy (server, DEFAULT_SERVER);
  port = DEFAULT_PORT;
  strcpy (current_channel, "none");
  connected = -1;
/*  total_channels = 0;
   total_screens = 0;            We don't count the status screen 
   setup_w = 0;                  Setup window flag 
   about_w = 0;                  About window flag
   total_queries = 0; */
  if (read_config ())
    {
#ifdef DEBUG
      g_print ("[D] Config file found ; loading it... <main.c/main> [OK]\n");
#endif
    }
  else
    {
#ifdef DEBUG
      g_print ("[D] Unable to find a valid XgIRC %s config file ; using defaults <main.c/main> [OK]\n", INTERNAL_VERSION);
#endif
      cmap = gdk_colormap_get_system ();
      extract_color (&color_screen_bg, DEFAULT_COLOR_SCREEN_BG_R, DEFAULT_COLOR_SCREEN_BG_G, DEFAULT_COLOR_SCREEN_BG_B);
      gdk_color_alloc (cmap, &color_screen_bg);
      extract_color (&color_client_msg, DEFAULT_COLOR_CLIENT_MSG_R, DEFAULT_COLOR_CLIENT_MSG_G, DEFAULT_COLOR_CLIENT_MSG_B);
      gdk_color_alloc (cmap, &color_client_msg);
      extract_color (&color_server_msg, DEFAULT_COLOR_SERVER_MSG_R, DEFAULT_COLOR_SERVER_MSG_G, DEFAULT_COLOR_SERVER_MSG_B);
      gdk_color_alloc (cmap, &color_server_msg);
      extract_color (&color_time1, DEFAULT_COLOR_TIME1_R, DEFAULT_COLOR_TIME1_G, DEFAULT_COLOR_TIME1_B);
      gdk_color_alloc (cmap, &color_time1);
      extract_color (&color_time2, DEFAULT_COLOR_TIME2_R, DEFAULT_COLOR_TIME2_G, DEFAULT_COLOR_TIME2_B);
      gdk_color_alloc (cmap, &color_time2);
      extract_color (&color_normal_msg, DEFAULT_COLOR_NORMAL_MSG_R, DEFAULT_COLOR_NORMAL_MSG_G, DEFAULT_COLOR_NORMAL_MSG_B);
      gdk_color_alloc (cmap, &color_normal_msg);
      extract_color (&color_nick1, DEFAULT_COLOR_NICK1_R, DEFAULT_COLOR_NICK1_G, DEFAULT_COLOR_NICK1_B);
      gdk_color_alloc (cmap, &color_nick1);
      extract_color (&color_nick2, DEFAULT_COLOR_NICK2_R, DEFAULT_COLOR_NICK2_G, DEFAULT_COLOR_NICK2_B);
      gdk_color_alloc (cmap, &color_nick2);
      extract_color (&color_server, DEFAULT_COLOR_SERVER_R, DEFAULT_COLOR_SERVER_G, DEFAULT_COLOR_SERVER_B);
      gdk_color_alloc (cmap, &color_server);
      extract_color (&color_user, DEFAULT_COLOR_USER_R, DEFAULT_COLOR_USER_G, DEFAULT_COLOR_USER_B);
      gdk_color_alloc (cmap, &color_user);
      extract_color (&color_topic, DEFAULT_COLOR_TOPIC_R, DEFAULT_COLOR_TOPIC_G, DEFAULT_COLOR_TOPIC_B);
      gdk_color_alloc (cmap, &color_topic);
      extract_color (&color_channel, DEFAULT_COLOR_CHANNEL_R, DEFAULT_COLOR_CHANNEL_G, DEFAULT_COLOR_CHANNEL_B);
      gdk_color_alloc (cmap, &color_channel);
      extract_color (&color_hostdomain, DEFAULT_COLOR_HOSTDOMAIN_R, DEFAULT_COLOR_HOSTDOMAIN_G, DEFAULT_COLOR_HOSTDOMAIN_B);
      gdk_color_alloc (cmap, &color_hostdomain);
      extract_color (&color_port, DEFAULT_COLOR_PORT_R, DEFAULT_COLOR_PORT_G, DEFAULT_COLOR_PORT_B);
      gdk_color_alloc (cmap, &color_port);
      extract_color (&color_motd, DEFAULT_COLOR_MOTD_R, DEFAULT_COLOR_MOTD_G, DEFAULT_COLOR_MOTD_B);
      gdk_color_alloc (cmap, &color_motd);
      extract_color (&color_ctcp, DEFAULT_COLOR_CTCP_R, DEFAULT_COLOR_CTCP_G, DEFAULT_COLOR_CTCP_B);
      gdk_color_alloc (cmap, &color_ctcp);
      extract_color (&color_mode, DEFAULT_COLOR_MODE_R, DEFAULT_COLOR_MODE_G, DEFAULT_COLOR_MODE_B);
      gdk_color_alloc (cmap, &color_mode);
      extract_color (&color_wallops, DEFAULT_COLOR_WALLOPS_R, DEFAULT_COLOR_WALLOPS_G, DEFAULT_COLOR_WALLOPS_B);
      gdk_color_alloc (cmap, &color_wallops);
      option_tooltips = DEFAULT_OPTION_TOOLTIPS;
      option_whois1 = DEFAULT_OPTION_WHOIS1;
      option_whois2 = DEFAULT_OPTION_WHOIS2;
      option_wallops1 = DEFAULT_OPTION_WALLOPS1;
      option_wallops2 = DEFAULT_OPTION_WALLOPS2;
    }
/* ========================================================================== */

/* === Gtk main loop and exit =============================================== */
#ifdef DEBUG
  g_print ("[D] Entering gtk main loop... <main.c/main>\n");
#endif
  gtk_main ();
  return 0;
/* ========================================================================== */

}
