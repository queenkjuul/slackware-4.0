/* This file is part of XgIRC 0.1
   main.h - Header file for main.c

   Copyright (C) 1998 Julien Pieraut <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>

/* ========================================================================== *
 * = Global defines                                                         = *
 * ========================================================================== */
#define MAXLEN 4096
#define INTERNAL_VERSION "0.1.1"
#define DEFAULT_GECOS "XgIRC User - http://www.xgirc.home.ml.org"
#define DEFAULT_NICK "XgIRC"
#define DEFAULT_USER "xgirc"
#define DEFAULT_USERMODE "+iw"
#define DEFAULT_PORT 6667
#define DEFAULT_SERVER "gimme.a.real.irc.server.org"
#define NICK_MAXLEN 15		/* Is nickname length limit 15 for networks such as Dalnet ? */
#define MAX_CHANNELS 10
#define MAX_QUERIES 100
#define USER_MAXLEN 16
#define GECOS_MAXLEN 256
#define USERMODE_MAXLEN 8
#define CHECK_LAG_DELAY 60000	/* In milliseconds */
#define DEFAULT_OPTION_TOOLTIPS 1
#define DEFAULT_OPTION_WHOIS1 0 
#define DEFAULT_OPTION_WHOIS2 1 
#define DEFAULT_OPTION_WALLOPS1 0 
#define DEFAULT_OPTION_WALLOPS2 1 

/* ========================================================================== *
 * = Global variables declaration                                           = *
 * ========================================================================== */
/* 'channel' referes here to channel or query */
char buf[MAXLEN];
int i, s, connected;
char current_channel[MAXLEN];
int total_screens;
int total_channels, total_queries;
char server[MAXLEN];
int port;
int setup_w, about_w;

int current_screen;

struct
  {
    char name[MAXLEN];
    char topic[MAXLEN];
    char topic_author[NICK_MAXLEN];
    char modes[MAXLEN];
    int nb_ops;
    int nb_nops;
    char ops[MAXLEN][NICK_MAXLEN];
    char nops[MAXLEN][NICK_MAXLEN];
    int names;
  }
channel[MAX_CHANNELS + 1];

struct
  {
    char nick[MAXLEN];
  }
query[MAX_QUERIES + 1];

struct
  {
    char nick[NICK_MAXLEN];
    char altnick[NICK_MAXLEN];
    char usermode[USERMODE_MAXLEN];
    char user[USER_MAXLEN];
    char gecos[GECOS_MAXLEN];
  }
me;

int current_lag, check_lag_tag;
int option_tooltips, option_whois1, option_whois2;
int option_wallops1, option_wallops2;

/* === main.h declarations ================================================== */
GtkWidget *box_main;
GtkWidget *box_menu;
GtkWidget *box_commandline;
GtkWidget *menubar;
GtkAcceleratorTable *accel;
/* ========================================================================== */
