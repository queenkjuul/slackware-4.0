/* This file is part of XgIRC 0.1
   commands.c - Handles user's commands

   Copyright (C) 1998 A|vin (Julien Pieraut) <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include "main.h"
#include "display.h"

/* ========================================================================== *
 * = Handles JOIN command                                                   = *
 * ========================================================================== */
int
command_join (char *chan)
{
#ifdef DEBUG
  g_print ("[D] Command : JOIN\n");
#endif
  sprintf (buf, "JOIN %s", chan);
  sendln (s, buf);
  return (1);
}

/* ========================================================================== *
 * = Handles PART command                                                   = *
 * ========================================================================== */
int
command_part (char *chan)
{
  int j;
#ifdef DEBUG
  g_print ("[D] Command : PART [%s]\n", chan);
#endif
  sprintf (buf, "PART %s", chan);
  gtk_notebook_remove_page (GTK_NOTEBOOK (screen_notebook), current_screen);
  for (i = current_screen; i <= total_channels - 1; i++)
    {
      strcpy (channel[i].name, channel[i + 1].name);
      strcpy (channel[i].topic, channel[i + 1].topic);
      strcpy (channel[i].modes, channel[i + 1].modes);
      channel[i].nb_ops = channel[i + 1].nb_ops;
      channel[i].nb_nops = channel[i + 1].nb_nops;
      for (j = 1; j <= channel[i].nb_ops; j++)
	{
	  strcpy (channel[i].ops[j], channel[i + 1].ops[j]);
	}
      for (j = 1; j <= channel[i].nb_nops; j++)
	{
	  strcpy (channel[i].nops[j], channel[i + 1].nops[j]);
	}
      screen[i] = screen[i + 1];
    }
  for (i = total_channels; i <= total_screens - 1; i++)
    {
      screen[i] = screen[i + 1];
    }
  total_channels--;
  total_screens--;
  current_screen--;
  gtk_notebook_set_page (GTK_NOTEBOOK (screen_notebook), current_screen);
  sendln (s, buf);
  return (1);
}

/* ========================================================================== *
 * = Handles ME command                                                     = *
 * ========================================================================== */
int
command_me (char *action)
{
#ifdef DEBUG
  g_print("[D] Command : ME\n");
  if (current_screen == 0)
    {
      text_error_not_on_a_channel ();
      return (1);		/* To avoid display of another error msg */
    }
#endif
  text_me (current_screen, me.nick, action);
  sprintf (buf, "PRIVMSG %s :\01ACTION %s\01", current_channel, action);
  sendln (s, buf);
  return (1);
}

/* ========================================================================== *
 * = Handles NICK command                                                   = *
 * ========================================================================== */
int
command_nick (char *nick)
{
#ifdef DEBUG
  g_print ("[D] Command : NICK [Nick : %s]\n", nick);
#endif
  sprintf (buf, "NICK %s", nick);
  sendln (s, buf);
  return (1);
}

/* ========================================================================== *
 * = Handles QUOTE command                                                  = *
 * ========================================================================== */
int
command_quote (char *text)
{
#ifdef DEBUG
  g_print ("[D] Command : QUOTE\n");
#endif
  sprintf (buf, "%s", text);
  sendln (s, buf);
  return (1);
}

/* ========================================================================== *
 * = Handles WHOIS command                                                  = *
 * ========================================================================== */
int
command_whois (char *nick)
{
#ifdef DEBUG
  g_print ("[D] Command : WHOIS\n");
#endif
  sprintf (buf, "WHOIS %s", nick);
  sendln (s, buf);
  return (1);
}

/* ========================================================================== *
 * = Handles TOPIC command                                                  = *
 * ========================================================================== */
int
command_topic (char *topic)
{
#ifdef DEBUG
  g_print ("[D] Command : TOPIC\n");
#endif
  sprintf (buf, "TOPIC %s :%s", current_channel, topic);
  sendln (s, buf);
  return (1);
}

/* ========================================================================== *
 * = Handles QUERY command                                                  = *
 * ========================================================================== */
int
command_query (char *nick)
{
  int qry;

#ifdef DEBUG
  g_print ("[D] Command : QUERY [Nick : %s]\n", nick);
#endif
  if (strlen (nick) > NICK_MAXLEN)
    {
      text_error (current_screen, nick, "Invalid nickname");
      return (1);		/* 0 would return another error message (Invalid command name) */
    }
  qry = find_query (nick);
  if (qry)			/* If a query window already exists */
    {
      current_screen = qry;
      strcpy (current_channel, nick);
      gtk_notebook_set_page (GTK_NOTEBOOK (screen_notebook), current_screen);	/* We switch to the query screen... */
    }
  else
    {
      total_screens++;
      total_queries++;
      current_screen = total_screens;
      strcpy (current_channel, nick);
      box_screen[total_screens] = screen_box (window_main, 2);
      gtk_notebook_append_page (GTK_NOTEBOOK (screen_notebook), box_screen[current_screen], gtk_label_new (nick));
      gtk_widget_show (box_screen[current_screen]);
      gtk_notebook_set_page (GTK_NOTEBOOK (screen_notebook), current_screen);	/* We switch to the query screen... */
      strcpy (query[total_queries].nick, nick);
    }
  return (1);
}

/* ========================================================================== *
 * = Handles MODE command                                                   = *
 * ========================================================================== */
int
command_mode (char *mode)
{
#ifdef DEBUG
  g_print ("[D] Command : MODE [%s]\n", mode);
#endif
  if (current_screen == 0 || current_screen > total_channels)
    {
      text_error_not_on_a_channel ();
      return (1);		/* To avoid display of another error msg */
    }
  sprintf (buf, "MODE %s %s", current_channel, mode);
  sendln (s, buf);
  return (1);
}

/* ========================================================================== * 
 * = Handles CTCP command                                                   = *
 * ========================================================================== */
int
command_ctcp (char *what, char *ctcp, char *data)
{
#ifdef DEBUG
  g_print ("[D] Command : CTCP [%s : %s %s]\n", what, ctcp, data);
#endif
  if (strcomp (ctcp, "ping"))
    {
      sprintf (buf, "PRIVMSG %s :\01%s %d\01", what, ctcp, get_seconds_counter ());
    }
  else
    {
      sprintf (buf, "PRIVMSG %s :\01%s %s\01", what, ctcp, data);
    }
  sendln (s, buf);
  return (1);
}

/* ========================================================================== *
 * = Handles QUIT command                                                   = *
 * ========================================================================== */
int
command_quit (char *text)
{
#ifdef DEBUG
  g_print ("[D] Command : QUIT [%s]\n", text);
#endif
  close_server_connection (s, text);
  return (1);
}

/* ========================================================================== *
 * = Handles MSG  command                                                   = *
 * ========================================================================== */

int
command_msg (char *nick, char *message)
{
	int qry;
	char lbuf[1500];
	
	qry = find_query (nick);
	if (qry)
	{
#ifdef DEBUG
		g_print ("[D] Command : PRIVMSG to %s, %s\n", nick, message);
#endif
		text_channel_msg (qry, me.nick, message);
	}
	else
	{
		total_screens++;
		total_queries++;
		current_screen = total_screens;
		box_screen[total_screens] = screen_box (window_main, 2);
		gtk_notebook_append_page (GTK_NOTEBOOK (screen_notebook), box_screen[total_screens], gtk_label_new (nick));
		gtk_widget_show (box_screen[total_screens]);
		gtk_notebook_set_page (GTK_NOTEBOOK (screen_notebook), current_screen);	/* We switch to the query screen... */
		strcpy (query[total_queries].nick, nick);
#ifdef DEBUG
		g_print ("[D] Command : PRIVMSG to %s, %s\n", nick, message);
#endif
		text_channel_msg (current_screen, me.nick, message);
	}
	sprintf (lbuf, "PRIVMSG %s :%s", nick, message);
	sendln (s, lbuf);
}
