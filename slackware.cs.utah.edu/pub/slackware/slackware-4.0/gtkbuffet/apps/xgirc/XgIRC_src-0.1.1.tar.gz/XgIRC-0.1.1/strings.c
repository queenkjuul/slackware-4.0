/* This file is part of XgIRC 0.1
   strings.c - Strings manipulation

   Copyright (C) 1998 A|vin (Julien Pieraut) <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <time.h>
#include <strings.h>
#include "main.h"
#include "strings.h"

/* ========================================================================== *
 * = Returns 1 if strings 'c1' & 'c2' are the sames                         = *
 * ========================================================================== */
int
strcomp (char *c1, char *c2)
{
  int i;

  if (strlen (c1) == 0 && strlen (c2) == 0)
    return 1;			/* Needed to compare 2 empty strings [05/26/98] */
  if (strlen (c1) != strlen (c2))
    return 0;
  for (i = 0; i <= strlen (c1) - 1; i++)
    {
      if (tolower (c1[i]) != tolower (c2[i]))
	return 0;
    }
  return 1;
}

/* ========================================================================== *
 * = Returns the number of words of string 'line'                           = *
 * ========================================================================== */
int
count_args (char *line)
{
  int result, i;
  result = 0;
  i = 0;
  while (line[i] != '\0')
    {
      if (line[i] == ' ')
	result++;
      i++;
    }
  return (result + 1);
}

/* ========================================================================== *
 * = Returns word 'n' of 'string'                                           = *
 * ========================================================================== */
char *
get_arg (char *string, int n)
{
  int i = 1;
  char *result, *p;

  result = (char *) malloc (strlen (string) + 1);
  do
    {
      if (i == n)
	{
	  p = result;
	  while (*string != ' ' && *string != '\0')
	    {
	      *p = *string;
	      p++;
	      string++;
	    }
	  *p = '\0';
	  return (result);

	}
      if (*string == ' ')
	i++;
      string++;
    }
  while (*string != '\0');
  return (" ");
}

/* ========================================================================== *
 * = Returns substring of 'string' from word 'n' to its end                 = *
 * ========================================================================== */
char *
get_from_arg (char *string, int n)
{
  int i = 1;
  char *result, *p;

  result = (char *) malloc (strlen (string) + 1);
  do
    {
      if (i == n)
	{
	  p = result;
	  while (*string != '\0')
	    {
	      *p = *string;
	      p++;
	      string++;
	    }
	  *p = '\0';
	  return (result);

	}
      if (*string == ' ')
	i++;
      string++;
    }
  while (*string != '\0');
  return (" ");
}

/* ========================================================================== *
 * = Returns a string with the current time (ripped)                        = *
 * ========================================================================== */
char *
get_the_time (void)
{
  time_t t;
  char *timebuf;
  struct tm *btime;

  timebuf = (char *) malloc (6);
  t = time ((time_t *) NULL);
  btime = localtime (&t);
  if (t && (sprintf (timebuf, "%-2.2d:%-2.2d", btime->tm_hour, btime->tm_min)))
    return (timebuf);
  return (NULL);
}

/* ========================================================================== *
 * = Returns the number of seconds passed since 70/01/01                    = *
 * ========================================================================== */
int
get_seconds_counter (void)
{
return(time(NULL));
}

/* ========================================================================== *
 * = Returns "nick" part of 'string' which format is nick!user@host.domain  = *
 * ========================================================================== */
char *
get_nick (char *string)
{
  char *result, *p;

  result = (char *) malloc (strlen (string) + 1);
  p = result;
  while (*string != '!' && *string != '\0')
    {
      *p = *string;
      string++;
      p++;
    }
  *p = '\0';
  return (result);
}

/* ========================================================================== *
 * = Returns "user" part of 'string' which format is nick!user@host.domain  = *
 * ========================================================================== */
char *
get_user (char *string)
{
  char *result, *p;

  result = (char *) malloc (strlen (string) + 1);
  while (*string != '!' && *string != '\0')
    string++;
  if (*string == '\0')
    return (NULL);
  p = result;
  string++;
  while (*string != '@' && *string != '\0')
    {
      *p = *string;
      string++;
      p++;
    }
  *p = '\0';
  return (result);
}

/* ========================================================================== *
 * = Returns "host.domain" part of 'string' which format is                 = *
 * = nick!user@host.domain                                                  = *
 * ========================================================================== */
char *
get_hostdomain (char *string)
{
  char *result, *p;

  result = (char *) malloc (strlen (string) + 1);
  while (*string != '@' && *string != '\0')
    string++;
  if (*string == '\0')
    return (NULL);
  p = result;
  string++;
  while (*string != '\0')
    {
      *p = *string;
      string++;
      p++;
    }
  *p = '\0';
  return (result);
}

/* ========================================================================== *
 * = Returns 'string' without the first char (such as ':' for a server msg) = *
 * ========================================================================== */
char *
strip_fchr (char *string)
{
  string++;
  return (string);
}

/* ========================================================================== *
 * = Returns string conversion of int 'n'                                   = *
 * ========================================================================== */
char *
int_to_string (int n)
{
  sprintf (buf, "%i", n);
  return (buf);
}

/* ========================================================================== *
 * = Returns 'string' without strange chars (such as char 1 for a CTCP)     = *
 * ========================================================================== */
char *
strip_strange_chars (char *string)
{
  char *result, *p;
  result = (char *) malloc (strlen (string) + 1);
  p = result;
  while (*string != '\0')
    {
      if (*string != 1 && *string != 10 && *string <= 126)
	{
	  *p = *string;
	  p++;
	}
      string++;
    }
  *p = '\0';
  return (result);
}

/* ========================================================================== *
 * = Returns time expression of a number of seconds                         = *
 * ========================================================================== */
char *
seconds_to_time (int seconds)
{
  int secs, mins = 0, hours = 0, days = 0;

  secs = seconds;
  if (secs < 60)
    {
      sprintf (buf, "%i seconds", secs);
      return (buf);
    }
  while (secs >= 60)
    {
      mins++;
      secs = secs - 60;
    }
  if (mins < 60)
    {
      sprintf (buf, "%i minutes %i seconds", mins, secs);
      return (buf);
    }
  while (mins >= 60)
    {
      hours++;
      mins = mins - 60;
    }
  if (hours >= 24)
    {
      sprintf (buf, "%i hours %i minutes %i seconds", hours, mins, secs);
      return (buf);
    }
  while (hours >= 24)
    {
      days++;
      hours = hours - 24;
    }
  sprintf (buf, "%i days %i hours %i minutes %i seconds", days, hours, mins, secs);
  return (buf);
}

/* ========================================================================== *
 * = Returns upper case conversion of a string                              = *
 * ========================================================================== */
char *
upper_case (char *string)
{
  char *p, *result;

  result = (char *) malloc (strlen (string) + 1);
  p = result;
  while (*string != '\0')
    {
      *p = toupper (*string);
      string++;
      p++;
    }
  *p = '\0';
  return (result);
}

/* ========================================================================== *
 * = Returns 1 if char 'c' is in 'string'                                   = *
 * ========================================================================== */
int
is_in_string (char c, char *string)
{
  while (*string != '\0')
    {
      if (c == *string)
	return (1);
      string++;
    }
  return (0);
}

/* ========================================================================== *
 * = Returns the number of lines in 'string' (CR & LF)                      = *
 * ========================================================================== */
int 
count_lines (char *string)
{
  char *p;
  int result = 0;

  p = string;
  for (i = 0; i <= strlen (string); i++)
    {
      if (*p == 10 || *p == 0)
	result++;
      p++;
    }
  return (result);
}

/* ========================================================================== *
 * = Returns line 'n' of 'string'                                           = *
 * ========================================================================== */
char *
get_line (char *string, int n)
{
  int i = 1;
  int length, j;
  char *result, *p;

  result = (char *) malloc (strlen (string) + 1);
  length = strlen (string);
  do
    {
      if (i == n)
	{
	  p = result;
	  while (*string != 0 && *string != 10)
	    {
	      *p = *string;
	      p++;
	      string++;
	    }
	  *p = '\0';
	  return (result);
	}
      if (*string == 0 || *string == 10)
	i++;
      string++;
      j++;
    }
  while (j != length);
  return ("");
}
