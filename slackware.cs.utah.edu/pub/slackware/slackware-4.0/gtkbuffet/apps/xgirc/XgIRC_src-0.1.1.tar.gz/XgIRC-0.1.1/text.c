/* This file is part of XgIRC 0.1
   text.c - Text formating functions

   Copyright (C) 1998 A|vin (Julien Pieraut) <alvin@another-world.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include "main.h"
#include "text.h"
#include "display.h"
#include "strings.h"

void
text_space (int scr)
{
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, NULL, NULL, " ", 1);
}

void
text_cr (int scr)
{
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, NULL, NULL, "\n", 1);
  gtk_widget_realize (screen_notebook);
}

void
text_client_msg (int scr)
{
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_client_msg, &color_screen_bg, "*** ", 4);
}

void
text_server_msg (int scr)
{
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_server_msg, &color_screen_bg, "** ", 3);
}

void
text_time (int scr)
{
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_time1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_time2, &color_screen_bg, get_the_time (), -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_time1, &color_screen_bg, "]", 1);
  text_space (scr);
}

void
text_connect (char *server, int port)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_client_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, CONNECTING_MSG, -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_server, &color_screen_bg, server, -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, ":", 1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_port, &color_screen_bg, int_to_string (port), -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);			/* CR must be placed *after* gtk_text_thaw in order to have the window scroll automaticaly */

}

void
text_connected (void)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_client_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, CONNECTED_MSG, -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_server, &color_screen_bg, server, -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, ":", 1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_port, &color_screen_bg, int_to_string (port), -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_disconnected (void)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_client_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, DISCONNECTED_MSG, -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_server, &color_screen_bg, server, -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, ":", 1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_port, &color_screen_bg, int_to_string (port), -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_ping_from_server (void)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_server_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, "Received ", -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_ctcp, &color_screen_bg, "PING ", -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, "from server", -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_motd_header (void)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_server_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_motd, &color_screen_bg, MOTD_HEADER_MSG, -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_motd_footer (void)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_server_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_motd, &color_screen_bg, MOTD_FOOTER_MSG, -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_motd (char *motd)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_server_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_motd, &color_screen_bg, motd, -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_channel_msg (int scr, char *nick, char *msg)
{
  if (!scr)
    return;			/* To avoid display in status window */
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "<", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, ">", 1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_server_raw (char *msg)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_server_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_own_channel_msg (char *nick, char *msg)
{
  gtk_text_freeze (GTK_TEXT (screen[current_screen]));
  text_time (current_screen);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_nick1, &color_screen_bg, "<", 1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_nick1, &color_screen_bg, ">", 1);
  text_space (current_screen);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_thaw (GTK_TEXT (screen[current_screen]));
  text_cr (current_screen);
}

void
text_join (int scr, char *nick, char *user, char *hostdomain)
{
  if (!scr)
    return;			/* To avoid display in status window */
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_user, &color_screen_bg, user, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "@", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_hostdomain, &color_screen_bg, hostdomain, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "]", 1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, "has joined channel", -1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_channel, &color_screen_bg, channel[scr].name, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_my_join (char *channel)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_server_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, "You have joined channel ", -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_channel, &color_screen_bg, channel, -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_part (int scr, char *nick, char *user, char *hostdomain)
{
  if (!scr)
    return;			/* To avoid display in status window */
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_user, &color_screen_bg, user, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "@", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_hostdomain, &color_screen_bg, hostdomain, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "]", 1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, "has left channel", -1);
/*  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_channel, &color_screen_bg, channel[scr].name, -1); */
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_my_part (char *channel)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_server_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, "You have left channel ", -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_channel, &color_screen_bg, channel, -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_topic (int scr, char *nick, char *user, char *hostdomain, char *topic)
{
  if (!scr)
    return;			/* To avoid display in status window */
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_user, &color_screen_bg, user, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "@", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_hostdomain, &color_screen_bg, hostdomain, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "]", 1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, "has changed topic to ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_topic, &color_screen_bg, topic, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_me (int scr, char *nick, char *msg)
{
  if (!scr)
    return;			/* To avoid display in status window */
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_server_msg, &color_screen_bg, "* ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_ctcp (int scr, char *nick, char *ctcp)
{
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_client_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, "CTCP ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_ctcp, &color_screen_bg, ctcp, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, " from ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_error_connect (char *server, int port)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_client_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, ERROR_CONNECTING_MSG, -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_server, &color_screen_bg, server, -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, ":", 1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_port, &color_screen_bg, int_to_string (port), -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_error_not_connected (void)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_client_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, ERROR_NOT_CONNECTED_MSG, -1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_error_not_a_cmd (char *cmd)
{
  current_screen = gtk_notebook_current_page (GTK_NOTEBOOK (screen_notebook));
  gtk_text_freeze (GTK_TEXT (screen[current_screen]));
  text_time (current_screen);
  text_client_msg (current_screen);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_normal_msg, &color_screen_bg, cmd, -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_normal_msg, &color_screen_bg, " : ", -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_normal_msg, &color_screen_bg, ERROR_NOT_A_CMD_MSG, -1);
  gtk_text_thaw (GTK_TEXT (screen[current_screen]));
  text_cr (current_screen);
}

void
text_error_not_on_a_channel (void)
{
  current_screen = gtk_notebook_current_page (GTK_NOTEBOOK (screen_notebook));
  gtk_text_freeze (GTK_TEXT (screen[current_screen]));
  text_time (current_screen);
  text_client_msg (current_screen);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_normal_msg, &color_screen_bg, ERROR_NOT_ON_A_CHANNEL_MSG, -1);
  gtk_text_thaw (GTK_TEXT (screen[current_screen]));
  text_cr (current_screen);
}

void
text_kick (int scr, char *by, char *nick, char *msg)
{
  if (!scr)
    return;			/* To avoid display in status window */
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, "was kicked by ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, by, -1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "]", 1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_my_kick (char *nick, char *chn, char *msg)
{
  gtk_text_freeze (GTK_TEXT (screen[0]));
  text_time (0);
  text_client_msg (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, "You were kicked from channel ", -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_channel, &color_screen_bg, chn, -1);
  text_space (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, "by ", -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  text_space (0);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_nick1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_insert (GTK_TEXT (screen[0]), NULL, &color_nick1, &color_screen_bg, "]", 1);
  gtk_text_thaw (GTK_TEXT (screen[0]));
  text_cr (0);
}

void
text_whois1 (int scr, char *nick, char *user, char *hostdomain, char *ircgecos)
{
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, " is ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_user, &color_screen_bg, user, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "@", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_hostdomain, &color_screen_bg, hostdomain, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, " [", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, ircgecos, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "]", 1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_whois2 (int scr, char *nick, char *channels)
{
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, " is on ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_channel, &color_screen_bg, channels, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_whois3 (int scr, char *nick, char *server, char *serverinfo)
{
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, " is using ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_server, &color_screen_bg, server, -1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, serverinfo, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "]", 1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_whois4 (int scr, char *nick, char *idle, char *signon)
{
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, " is idle since ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, seconds_to_time (atoi (idle)), -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_error (int scr, char *what, char *msg)
{
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  if (what[0] == '#')
    gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_channel, &color_screen_bg, what, -1);
  else
    gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, what, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, " : ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_error2 (int scr, char *msg)
{
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_nick (int scr, char *nick1, char *nick2)
{
  if (!scr)
    return;			/* To avoid display in status window */
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick1, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, " has changed nick to ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick2, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_quit (int scr, char *nick, char *user, char *hostdomain, char *msg)
{
  if (!scr)
    return;			/* To avoid display in status window */
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_user, &color_screen_bg, user, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "@", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_hostdomain, &color_screen_bg, hostdomain, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "]", 1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, "has quit IRC ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "]", 1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_own_nick (int scr, char *nick)
{
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_client_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, "You have changed your nick to ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_mode (int scr, char *nick, char *modes, char *data)
{
  int j;

  if (!scr)
    return;			/* To avoid display in status window */
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  text_server_msg (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, " has set mode ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_mode, &color_screen_bg, modes, -1);
  text_space (scr);
  for (j = 1; j <= count_args (data); j++)
    {
      if (is_in_channel (scr, get_arg (data, j)))
	{			/* If the current arg is a nick */
	  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, get_arg (data, j), -1);
	  text_space (scr);
	}
      else
	{
	  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, get_arg (data, j), -1);
	  text_space (scr);
	}
    }
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_notice (int scr, char *nick, char *msg, int type)
{
  gtk_text_freeze (GTK_TEXT (screen[scr]));
  text_time (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_time1, &color_screen_bg, "[", 1);
  if (type == 1)
    gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "#", 1);
  else
    gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "!", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_time1, &color_screen_bg, "] ", -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, "<", 1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_nick1, &color_screen_bg, ">", 1);
  text_space (scr);
  gtk_text_insert (GTK_TEXT (screen[scr]), NULL, &color_normal_msg, &color_screen_bg, msg, -1);
  gtk_text_thaw (GTK_TEXT (screen[scr]));
  text_cr (scr);
}

void
text_wallops (char *nick, char *msg)
{
  current_screen = gtk_notebook_current_page (GTK_NOTEBOOK (screen_notebook));
  gtk_text_freeze (GTK_TEXT (screen[current_screen]));
  text_time (current_screen);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_time1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_nick1, &color_screen_bg, "W", 1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_time1, &color_screen_bg, "] ", -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_nick1, &color_screen_bg, "<", 1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_nick1, &color_screen_bg, ">", 1);
  text_space (current_screen);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_wallops, &color_screen_bg, msg, -1);
  gtk_text_thaw (GTK_TEXT (screen[current_screen]));
  text_cr (current_screen);
}

void
text_ctcp_reply (char *nick, char *ctcp, char *data)
{
  current_screen = gtk_notebook_current_page (GTK_NOTEBOOK (screen_notebook));
  gtk_text_freeze (GTK_TEXT (screen[current_screen]));
  text_time (current_screen);
  text_client_msg (current_screen);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_normal_msg, &color_screen_bg, "CTCP ", -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_ctcp, &color_screen_bg, ctcp, -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_normal_msg, &color_screen_bg, " reply from ", -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_nick2, &color_screen_bg, nick, -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_normal_msg, &color_screen_bg, " : ", -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_normal_msg, &color_screen_bg, data, -1);
  gtk_text_thaw (GTK_TEXT (screen[current_screen]));
  text_cr (current_screen);
}

void
text_server_wallops (char *msg)
{
  current_screen = gtk_notebook_current_page (GTK_NOTEBOOK (screen_notebook));
  gtk_text_freeze (GTK_TEXT (screen[current_screen]));
  text_time (current_screen);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_time1, &color_screen_bg, "[", 1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_nick1, &color_screen_bg, "W", 1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_time1, &color_screen_bg, "] ", -1);
  gtk_text_insert (GTK_TEXT (screen[current_screen]), NULL, &color_wallops, &color_screen_bg, msg, -1);
  gtk_text_thaw (GTK_TEXT (screen[current_screen]));
  text_cr (current_screen);
}
