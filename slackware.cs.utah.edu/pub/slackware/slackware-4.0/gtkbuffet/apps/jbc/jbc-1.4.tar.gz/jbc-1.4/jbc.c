/********************************************************
 * jbc.c - Jon's Binary Clock                           *
 *                                                      *
 * Jon Anhold (jon@snoopy.net) 04.07.98                 *
 *                                                      *
 * Clock engine by Roger Gulbranson (rlg@iagnet.net).   *
 *                                                      *
 * Displays a binary clock using gtk+ 0.99.9            *
 *                                                      *
 * Now with much niftier pixmaps & blinking cursors     *
 *                                                      *
 * Please let me know what you think! This is my first  *
 * C project, as well as my first X11/GTK+ project.     *
 * If there's something you see that can be done better,*
 * I would really like to know. Drop me a note!         *
 ********************************************************/

#include "jbc.h"

/* initialize variables */
struct tm atime;		/* this is the time structure */
time_t thetime;  		/* variable to grab the time */
int d[6];        		/* array of digits */
int i;           		/* generic counter for the for's */
static digits[6] =		/* more digits stuff */
{0, 0, 0, 0, 0, 0};
int blink = 0;			/* to blink, or not to blink */
char **xpms[] =			/* array of xpms. thanks miguel */
{t0_xpm, t1_xpm, t2_xpm, t3_xpm, t4_xpm, t5_xpm, t6_xpm, t7_xpm, t8_xpm, t9_xpm};
char wtitle[] = "jbc!";		/* wtitle is the window titlebar text */
char buf[128];


/*
 * GtkWidget is the storage type for widgets 
 */
GtkWidget *window, *box,  *pw[10], *pwc[2], *pwbc[2], *event_box, *menu, *menu_about, *menu_quit, *root_menu, *aboutwindow;
/*
 * GdkPixmap is the storage type for pixmaps
 */ 
GdkPixmap *p[10], *pc[2], *pbc[2];
/*
 * GtkBitmaps is used for the pixmap masks
 */
GdkBitmap *mask, *mask2, *amask;
/*
 * ??
 */
GtkStyle *style;

void switchabout()
{
   GtkWidget *box1;
   GtkWidget *button;
   GtkWidget *wpixmap;
   GtkStyle *style;
   GdkPixmap *pixmap;
   GdkBitmap *mask;
   char fn[256];
   
   if (!aboutwindow)
   {
      aboutwindow= gtk_window_new(GTK_WINDOW_TOPLEVEL);
      gtk_widget_set_name(aboutwindow, "About");
      gtk_widget_set_uposition(aboutwindow, 377, 189);  

      gtk_window_set_policy (GTK_WINDOW(aboutwindow), TRUE, TRUE, FALSE);
         
      gtk_signal_connect (GTK_OBJECT (aboutwindow), "destroy",
                          GTK_SIGNAL_FUNC(gtk_widget_destroyed), &aboutwindow);
      gtk_window_set_title (GTK_WINDOW (aboutwindow), "About");
      gtk_container_border_width (GTK_CONTAINER (aboutwindow), 0);

      box1 = gtk_vbox_new (FALSE, 0);
      gtk_container_add (GTK_CONTAINER (aboutwindow), box1);
      gtk_widget_show (box1);

      button = gtk_button_new();
      gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(switchabout), NULL);
      gtk_box_pack_start(GTK_BOX(box1), button, TRUE, TRUE, 0);
      gtk_widget_show(button);
      
      style = gtk_widget_get_style(box1);
      pixmap = gdk_pixmap_create_from_xpm_d (window->window, &mask,
      	                                        &style->bg[GTK_STATE_NORMAL],
        	                                (gchar **) about_xpm);
      wpixmap = gtk_pixmap_new(pixmap, mask);
      gtk_container_add(GTK_CONTAINER(button), wpixmap);
      gtk_widget_show(wpixmap);

   }

   if (!GTK_WIDGET_VISIBLE(aboutwindow))
      gtk_widget_show(aboutwindow);
   else
   {
      gtk_widget_destroy(aboutwindow);
   }

   return;
}

gint jbc_menu() {
	menu = gtk_menu_new();
	menu_about = gtk_menu_item_new_with_label("About..");
	gtk_menu_append(GTK_MENU(menu), menu_about);
	gtk_signal_connect_object(GTK_OBJECT(menu_about), "activate",
		GTK_SIGNAL_FUNC(switchabout), (gpointer) g_strdup("About.."));
	menu_quit = gtk_menu_item_new_with_label("Quit");
	gtk_menu_append(GTK_MENU(menu), menu_quit);
	gtk_signal_connect_object(GTK_OBJECT(menu_quit), "activate",
		GTK_SIGNAL_FUNC(gtk_exit), (gpointer) g_strdup("quit"));
	gtk_widget_show(menu_about);
	gtk_widget_show(menu_quit);
	gtk_menu_popup(GTK_MENU(menu), NULL, NULL, NULL, NULL, NULL, 20);
}


/* do nifty clock stuff */
gint do_clock() {

      /* get unix time */
      thetime = time (NULL);
      /* 
       * localtime converts unix time into something usable,
       * broken down into the tm structure
       */
      localtime_r (&thetime, &atime);

      /* parse time into individual digits */
      d[0] = atime.tm_hour / 10;
      d[1] = atime.tm_hour % 10;
      d[2] = atime.tm_min / 10;
      d[3] = atime.tm_min % 10;
      d[4] = atime.tm_sec / 10;
      d[5] = atime.tm_sec % 10;

      /* routine that does the nifty blinking colons */
      if (d[5] != digits[5]) {
      if (blink == 0) /* if no blink, display colons */
	{
	  gtk_pixmap_set ((GtkPixmap *)pwc[0], pc[0], mask2);
	  gtk_pixmap_set ((GtkPixmap *)pwc[1], pc[1], mask2);
	  /* format wtitle[] for the window titlebar */
	  blink = 1;
	  sprintf(wtitle, "%02d:%02d:%02d", atime.tm_hour, atime.tm_min, atime.tm_sec);
	  /* set the titlebar text to the decimal time */
	  gtk_window_set_title (GTK_WINDOW (window), wtitle);
	}
      else /* otherwise display the blank spacer pixmaps */
	{
		  gtk_pixmap_set ((GtkPixmap *)pwc[0], pbc[0], mask2);
		  gtk_pixmap_set ((GtkPixmap *)pwc[1], pbc[1], mask2);
		  blink = 0;
		  sprintf(wtitle, "%02d %02d %02d", atime.tm_hour, atime.tm_min, atime.tm_sec);
                  gtk_window_set_title (GTK_WINDOW (window), wtitle);
	}
      }
      /* big routine to figure out what pixmaps to display for each digit */
      /* whee */
      for (i = 0; i < 6; ++i)
	{
	  /*
	   * this if statement makes sure we only update
	   * digits that have changed
	   */
	  if (d[i] != digits[i])
	    {
	      /* this function changes the pixmap that the widget is managing */
	      gtk_pixmap_set ((GtkPixmap *)pw[i], p[d[i]], mask);
	      /* set this so it doesn't update unless it has to */
	      digits[i] = d[i];
	    }
	}
      return 1;
}


/* main */
int
main (int argc, char *argv[])
{
  /* need this :) */
  gtk_init (&argc, &argv);

  /* create the window */
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  /* need the realize to prevent goofy warnings on startup */
  gtk_widget_realize (GTK_WIDGET (window));
  /* set the title of the window */
  gtk_window_set_title (GTK_WINDOW (window), "jbc!");
  /* when window recieves a delete event it will terminate the app */
  gtk_signal_connect (GTK_OBJECT (window), "destroy",
		      GTK_SIGNAL_FUNC (gtk_exit), NULL);
  /* set the window border width */
  gtk_container_border_width (GTK_CONTAINER (window), 0);


 
  /* ??? */
  style = gtk_widget_get_style (window);

  /* create GdkPixmaps from the included xpms */
  for (i = 0; i < 10; ++i)
    {
      p[i] = gdk_pixmap_create_from_xpm_d (window->window, &mask,
					   &style->bg[GTK_STATE_NORMAL],
					   (gchar **) xpms[i]);
    }

  /* not worth a for loop here */
  pc[0] = gdk_pixmap_create_from_xpm_d (window->window, &mask2,
					&style->bg[GTK_STATE_NORMAL],
					(gchar **) tcolon_xpm);
  pc[1] = gdk_pixmap_create_from_xpm_d (window->window, &mask2,
					&style->bg[GTK_STATE_NORMAL],
					(gchar **) tcolon_xpm);
  pbc[0] = gdk_pixmap_create_from_xpm_d (window->window, &mask2,
					 &style->bg[GTK_STATE_NORMAL],
					 (gchar **) tbcolon_xpm);
  pbc[1] = gdk_pixmap_create_from_xpm_d (window->window, &mask2,
					 &style->bg[GTK_STATE_NORMAL],
					 (gchar **) tbcolon_xpm);

  /* create GtkPixmap widgets from the pixmaps generated above */
  for (i = 0; i < 10; ++i)
    {
      pw[i] = gtk_pixmap_new (p[0], mask);
    }

  /* these aren't worth for loops either */
  pwc[0] = gtk_pixmap_new (pc[0], mask2);
  pwc[1] = gtk_pixmap_new (pc[1], mask2);
  pwbc[0] = gtk_pixmap_new (pbc[0], mask2);
  pwbc[1] = gtk_pixmap_new (pbc[1], mask2);

  /* show the pixmap widgets */
  for (i = 0; i < 10; ++i)
    {
      gtk_widget_show (pw[i]);
    }

  /* again.. not enough for for's */
  gtk_widget_show (pwc[0]);
  gtk_widget_show (pwc[1]);
  gtk_widget_show (pwbc[0]);
  gtk_widget_show (pwbc[1]);

  /* create the gtk_hbox to pile these pixmap widgets into */
  box = gtk_hbox_new (FALSE, 0);

  /* created the event box widget to trap events */
  event_box = gtk_event_box_new ();
  /* put the event box into the window */
  gtk_container_add (GTK_CONTAINER (window), event_box);
  /* set the size. this needs to be done or it's 200x200 */
  gtk_widget_set_usize (event_box, 116, 70);
  /* set the event type on the event box */
  gtk_widget_set_events (event_box, GDK_BUTTON_PRESS);
  /* when a buttons clicked in the window, call gtk_exit() */
  gtk_signal_connect (GTK_OBJECT(event_box), "button_press_event",
  		      GTK_SIGNAL_FUNC (jbc_menu), NULL);
  /* realize the event box */
  gtk_widget_realize (GTK_WIDGET (event_box));
  /* change the cursor to the nifty little hand thingy */
  gdk_window_set_cursor (event_box->window, gdk_cursor_new (GDK_HAND1));


  /* pile the widgets into the box 
   *
   * can't for loop here, because of the colons. 
   *
   */
  gtk_container_add (GTK_CONTAINER (box), pw[0]);
  gtk_container_add (GTK_CONTAINER (box), pw[1]);
  gtk_container_add (GTK_CONTAINER (box), pwc[0]);
  gtk_container_add (GTK_CONTAINER (box), pw[2]);
  gtk_container_add (GTK_CONTAINER (box), pw[3]);
  gtk_container_add (GTK_CONTAINER (box), pwc[1]);
  gtk_container_add (GTK_CONTAINER (box), pw[4]);
  gtk_container_add (GTK_CONTAINER (box), pw[5]);
  gtk_container_add (GTK_CONTAINER (event_box), box);

  /* show the window widget and the box widget */
  gtk_widget_show (window);
  gtk_widget_show (box);
  gtk_widget_show (event_box);

  /* this tells gtk_main() to call do_clock() every 900 milliseconds */
  gtk_timeout_add (250, do_clock, NULL);

  /* call gtk_main that sits and waits for events */
  sleep(1);
  gtk_main();

  return(0);  
}
/* end */
