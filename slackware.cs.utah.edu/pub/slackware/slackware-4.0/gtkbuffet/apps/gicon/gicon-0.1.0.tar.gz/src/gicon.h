
/*

  Dedicated to Evelyn Reimann, the most wonderful girl I ever met.
  
 */

#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk_imlib.h>
#include <gdk_imlib_private.h>
#include <gif_lib.h>

int                   numofpics=0;
unsigned char         *data[MAX_PICTURES];

int                   tick=0;
int                   idtagoftimer;
char                  run[4096];
char                  cmd[4096];

int                   w[MAX_PICTURES], h[MAX_PICTURES];

GdkPixmap             *p[MAX_PICTURES];
GdkPixmap             *m[MAX_PICTURES];
GdkImlibImage         *im[MAX_PICTURES];
int                   where_x, where_y;

GdkWindowAttr         attr;
GtkWidget             *mainwidget;


extern void cja_load_image(char *);
extern void cja_LoadGIF(char *, int *, int *, int *);

extern void parse_command_line(int *, char ***, char *, int *);


int timer( gpointer);
int run_program (GtkWidget *, GdkEvent *, gpointer);
