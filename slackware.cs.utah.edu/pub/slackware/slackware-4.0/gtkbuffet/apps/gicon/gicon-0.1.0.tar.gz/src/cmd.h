
/*

  Dedicated to Evelyn Reimann, the most wonderful girl I ever met.
  
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern char                  run[4096];
extern char                  cmd[4096];
extern int                   where_x, where_y;

void parse_command_line(int *, char ***, char *, int *);
