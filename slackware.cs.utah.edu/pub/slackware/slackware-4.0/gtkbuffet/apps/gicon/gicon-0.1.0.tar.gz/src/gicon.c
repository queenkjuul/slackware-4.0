
/*

  Dedicated to Evelyn Reimann, the most wonderful girl I ever met.
  
 */

#include "gicon.h"



int main (int argc, char *argv[])
{
  int i;
  char picturename[4096];
  int speed=3*100;


  parse_command_line(&argc,&argv,picturename,&speed);

  gtk_init (&argc, &argv);
  gdk_init(&argc, &argv);
  gdk_imlib_init();

  cja_load_image(picturename);

  for(i=0;i<numofpics;i++){
    w[i]=im[i]->rgb_width;
    h[i]=im[i]->rgb_height;
    
    gdk_imlib_render(im[i],w[0],h[0]);
    p[i]=gdk_imlib_move_image(im[i]);
    m[i]=gdk_imlib_move_mask(im[i]);
  }

  mainwidget=gtk_window_new(GTK_WINDOW_POPUP);
  gtk_widget_set_events(mainwidget, gtk_widget_get_events( mainwidget ) | GDK_BUTTON_PRESS_MASK );
  gtk_signal_connect(GTK_OBJECT(mainwidget), "button_press_event",GTK_SIGNAL_FUNC(run_program), NULL);
  gtk_widget_set_usize(mainwidget,w[0],h[0]);
  gtk_widget_set_uposition(mainwidget,where_x,where_y);
  gtk_widget_shape_combine_mask(mainwidget,m[0],0,0);
  
  attr.window_type=GDK_WINDOW_CHILD;
  attr.wclass=GDK_INPUT_OUTPUT;
  attr.event_mask= gtk_widget_get_events(mainwidget) | GDK_STRUCTURE_MASK| GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK|GDK_BUTTON_RELEASE_MASK |GDK_POINTER_MOTION_MASK;
  attr.width=w[0];
  attr.height=h[0];
  attr.x=where_x;
  attr.y=where_y;
  attr.visual=gdk_imlib_get_visual();
  attr.colormap=gdk_imlib_get_colormap();  

  mainwidget->window=gdk_window_new(NULL,&attr,GDK_WA_VISUAL | GDK_WA_COLORMAP | GDK_WA_X |GDK_WA_Y);
 
  gdk_window_set_back_pixmap(mainwidget->window,p[0],0);
  gdk_window_shape_combine_mask(mainwidget->window,m[0],0,0);
  gdk_window_clear(mainwidget->window);

  gdk_flush();
  gtk_widget_show(mainwidget);
  gdk_window_show(mainwidget->window);
  
  idtagoftimer=gtk_timeout_add(speed,timer,NULL);

  /*Timer is called here because it takes a second to load gtk_main and during that time a gray area is showed instead of the picture.*/
  timer(NULL);
  gtk_main ();
          
  return 0;
}
/* I am sure that there are nicer ways to execure a program.*/
int run_program (GtkWidget *widget, GdkEvent *event, gpointer client_data)
{
  int pid,tty;

  fflush(stdout);
  tty=open("dev/tty",2);
  if((pid = fork()) == 0){
    close(0); dup(tty);
    close(1); dup(tty);
    close(2); dup(tty);
    close(tty);
    if(cmd[0]=='\0')
      execlp(run,run,(char *) 0);
    else
      execlp(run,run,cmd,(char *) 0);
    exit(127);
  }
  close(tty);

  return 0;
}


int timer(gpointer client_data)
{
 
  /*
  gtk_widget_set_usize(mainwidget,w[tick],h[tick]);
  gdk_window_resize(mainwidget->window,w[tick],h[tick]);
  */

  gdk_window_set_back_pixmap(mainwidget->window,p[tick],0);
  gdk_window_shape_combine_mask(mainwidget->window,m[tick],0,0);
  gdk_window_clear(mainwidget->window);
  gdk_flush();
 
  tick++;
  if(tick>=numofpics)tick=0;
  return 1;
}

