
/*

  Dedicated to Evelyn Reimann, the most wonderful girl I ever met.
  
 */

#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk_imlib.h>
#include <gdk_imlib_private.h>
#include <gif_lib.h>

extern int                   numofpics;
extern unsigned char         *data[MAX_PICTURES];

extern int                   w[MAX_PICTURES], h[MAX_PICTURES];

extern GdkImlibImage         *im[MAX_PICTURES];

void cja_load_image(char *);
void cja_LoadGIF(char *, int *, int *, int *);

