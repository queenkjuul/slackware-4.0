/* gnome-sql - GNOME SQL interface
 * Copyright (c) 1998 by Rodrigo Moya

 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#if !defined(_GNOME_SQL_)
#  define _GNOME_SQL_ 0

/* header files */
#include <gnome.h>

/* SQL data types (agree with ANSI type numbering) */
#define GNOME_SQL_CHAR	   1
#define GNOME_SQL_NUMERIC  2
#define GNOME_SQL_DECIMAL  3
#define GNOME_SQL_INTEGER  4
#define GNOME_SQL_SMALLINT 5
#define GNOME_SQL_FLOAT    6
#define GNOME_SQL_REAL	   7
#define GNOME_SQL_DOUBLE   8
#define GNOME_SQL_VARCHAR  12

/* gnome_sql_describe_table() defines */
#define GNOME_SQL_TABLE_FIELD_NAME_POS     0
#define GNOME_SQL_TABLE_FIELD_TYPE_POS     1
#define GNOME_SQL_TABLE_FIELD_LENGTH_POS   2
#define GNOME_SQL_TABLE_FIELD_PREC_POS     3
#define GNOME_SQL_TABLE_FIELD_COMMENTS_POS 4

/* database connection */
typedef enum
{
  GNOME_SQL_DRIVER_NONE     = 0,
  GNOME_SQL_DRIVER_POSTGRES = 1
} GnomeSqlDriver;

typedef enum
{
  GNOME_SQL_RESULT_ERROR = -1,
  GNOME_SQL_RESULT_OK    = -1000
} GnomeSqlResult;

struct _GnomeSqlRowset;

typedef struct _GnomeDatabase
{
  gpointer private_data;
  GnomeSqlDriver driver;
  GList *rowsets;
  gchar *dbname, *login, *password, *host;
  gboolean logging_enabled;
  /* driver interface */
  struct _GnomeSqlRowset * (*describe_table)(struct _GnomeDatabase *, const gchar *);
  gboolean (*disconnect)(struct _GnomeDatabase *);
  GnomeSqlResult (*execute_command)(struct _GnomeDatabase *, const gchar *);
  const gchar * (*get_current_database)(struct _GnomeDatabase *);
  const gchar * (*get_last_error)(struct _GnomeDatabase *);
  GList * (*get_tables)(struct _GnomeDatabase *);
  const gchar * (*get_user)(struct _GnomeDatabase *);
  gboolean (*is_logging_enabled)(struct _GnomeDatabase *);
  gboolean (*start_logging)(struct _GnomeDatabase *, const gchar *);
  gboolean (*stop_logging)(struct _GnomeDatabase *);
  /* transaction processing */
  gboolean (*begin_transaction)(struct _GnomeDatabase *);
  gboolean (*commit_transaction)(struct _GnomeDatabase *);
  gboolean (*rollback_transaction)(struct _GnomeDatabase *);
  /* result sets */
  struct _GnomeSqlRowset * (*open_rowset)(struct _GnomeDatabase *, 
                                          const gchar *);
  gboolean (*close_rowset)(struct _GnomeDatabase *, struct _GnomeSqlRowset *);
} GnomeDatabase;

extern gboolean gnome_sql_begin_transaction (GnomeDatabase *);
extern gboolean gnome_sql_commit_transaction (GnomeDatabase *);
extern GnomeDatabase *gnome_sql_connect (GnomeSqlDriver , gchar *, gchar *, 
                                         gchar *, gchar *);
extern struct _GnomeSqlRowset *gnome_sql_describe_table (GnomeDatabase *,
                                                         const gchar *);
extern gboolean gnome_sql_disconnect (GnomeDatabase *);
extern GnomeSqlResult gnome_sql_execute_command (GnomeDatabase *, 
                                                 const gchar *);
extern const gchar *gnome_sql_get_current_database (GnomeDatabase *);
extern GnomeSqlDriver gnome_sql_get_driver (GnomeDatabase *);
extern const gchar *gnome_sql_get_last_error (GnomeDatabase *);
extern GList *gnome_sql_get_tables (GnomeDatabase *);
extern const gchar *gnome_sql_get_user (GnomeDatabase *);
extern gboolean gnome_sql_is_logging_enabled (GnomeDatabase *);
extern gboolean gnome_sql_rollback_transaction (GnomeDatabase *);
extern gboolean gnome_sql_start_logging (GnomeDatabase *, const gchar *);
extern gboolean gnome_sql_stop_logging (GnomeDatabase *);

/* result sets */
typedef struct _GnomeSqlRowset
{
  gpointer private_data;
  GnomeDatabase *database;
  /* functions */
  gint (*get_field_count)(struct _GnomeSqlRowset *);
  gchar * (*get_field_name)(struct _GnomeSqlRowset *, gint );
  gint (*get_field_position)(struct _GnomeSqlRowset *, const gchar *);
  gint (*get_field_size)(struct _GnomeSqlRowset *, gint );
  gchar * (*get_field_value)(struct _GnomeSqlRowset *, gint , gint );
  gint (*get_row_count)(struct _GnomeSqlRowset *);
} GnomeSqlRowset;

extern gboolean gnome_sql_close_rowset (GnomeDatabase *, GnomeSqlRowset *);
extern GnomeDatabase *gnome_sql_rowset_get_database (GnomeSqlRowset *);
extern gint gnome_sql_rowset_get_field_count (GnomeSqlRowset *);
extern gchar *gnome_sql_rowset_get_field_name (GnomeSqlRowset *, gint );
extern gint gnome_sql_rowsetget_field_position (GnomeSqlRowset *, gchar *);
extern gint gnome_sql_rowset_get_field_size (GnomeSqlRowset *, gint );
extern gchar *gnome_sql_rowset_get_field_value (GnomeSqlRowset *, gint , gint );
extern gint gnome_sql_rowset_get_row_count (GnomeSqlRowset *);
extern GnomeSqlRowset *gnome_sql_open_rowset (GnomeDatabase *, const gchar *);
					      
#endif


