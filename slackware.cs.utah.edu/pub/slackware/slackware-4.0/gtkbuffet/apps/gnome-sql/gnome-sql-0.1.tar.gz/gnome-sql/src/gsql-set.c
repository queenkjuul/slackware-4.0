/* gnome-sql - GNOME SQL Interface
 * Copyright (c) 1998 by Rodrigo Moya

 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* header files */
#include <gnome-sql.h>

/* function definitions */
gboolean gnome_sql_close_rowset (GnomeDatabase *gdb, GnomeSqlRowset *grs)
{
  g_return_val_if_fail(gdb != NULL && grs != NULL, FALSE);
  if (gdb->close_rowset != NULL)
    {
      if ((*gdb->close_rowset)(gdb, grs))
	{
	  gdb->rowsets = g_list_remove(gdb->rowsets, grs);
	  return (TRUE);
	}
    }
  return (FALSE);
}

GnomeDatabase *gnome_sql_rowset_get_database (GnomeSqlRowset *grs)
{
  return (grs != NULL ? grs->database : NULL);
}

gint gnome_sql_rowset_get_field_count (GnomeSqlRowset *rset)
{
  g_return_val_if_fail(rset != NULL, -1);
  if (rset->get_field_count != NULL)
      return ((*rset->get_field_count)(rset));
  return (-1);
}

gchar *gnome_sql_rowset_get_field_name (GnomeSqlRowset *rset, gint index)
{
  return ((rset != NULL) && (rset->get_field_name != NULL) ?
	  (*rset->get_field_name)(rset, index) : NULL);
}

gint 
gnome_sql_rowset_get_field_position (GnomeSqlRowset *rset, gint index)
{
  return ((rset != NULL) && (rset->get_field_position != NULL) ?
	  (*rset->get_field_position)(rset, index) : -1);
}

gint 
gnome_sql_rowset_get_field_size (GnomeSqlRowset *rset, gint index)
{
  return ((rset != NULL) && (rset->get_field_size != NULL) ?
	  (*rset->get_field_size)(rset, index) : -1);
}

gchar *
gnome_sql_rowset_get_field_value (GnomeSqlRowset *rset, gint row, gint col)
{
  g_return_val_if_fail(rset != NULL && rset->get_field_value != NULL, NULL);
  return ((*rset->get_field_value)(rset, row, col));
}

gint 
gnome_sql_rowset_get_row_count (GnomeSqlRowset *rset)
{
  return ((rset != NULL) && (rset->get_row_count != NULL) ?
	  (*rset->get_row_count)(rset) : -1);
}

GnomeSqlRowset *gnome_sql_open_rowset (GnomeDatabase *gdb, 
				       const gchar *query)
{
  GnomeSqlRowset *rset;
  /* check parameters */
  g_return_val_if_fail(gdb != NULL, NULL);
  g_return_val_if_fail(query != NULL, NULL);
  if (gdb->open_rowset != NULL)
    {
      rset = (*gdb->open_rowset)(gdb, query);
      if (rset != NULL)
	{
	  rset->database = gdb;
	  /* create rowset list if not yet created */
	  gdb->rowsets = g_list_append(gdb->rowsets, rset);
	  return (rset);
	}
    }
  return (NULL);
}

