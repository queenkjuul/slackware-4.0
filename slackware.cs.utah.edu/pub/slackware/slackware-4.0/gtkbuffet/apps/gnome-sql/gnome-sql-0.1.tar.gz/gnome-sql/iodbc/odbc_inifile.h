#ifndef __ODBC_INIFILE__
#define __ODBC_INIFILE__

#include <glib.h>
#include <stdio.h>

typedef struct _ini_section{
  GString* name;
  GList*   value_pairs;
} ODBC_ini_section;

typedef struct _ini_value_pair
{
  GString* name;
  GString* value;
}ODBC_ini_value_pair;



GList*              odbc_ini_parse               (FILE* f,               gchar* id);
GString*            odbc_ini_find_value          (ODBC_ini_section* sec, gchar* key);
ODBC_ini_section*   odbc_ini_find_section        (GList* sections,       gchar* name);

#endif
