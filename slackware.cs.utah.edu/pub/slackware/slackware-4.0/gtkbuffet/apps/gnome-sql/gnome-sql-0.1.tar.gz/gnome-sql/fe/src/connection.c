/* gnome-sql - GUI front-end
 * Copyright (c) 1998 by Rodrigo Moya
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "gsqlfe.h"

/* data types */
struct GSQLFE_DriverInfo
{
  gboolean is_ok;
  GtkWidget *tab;
  gchar label[32];
  GList *children;
  GtkWidget * (*create_notebook_tab)(GtkWidget *, struct GSQLFE_DriverInfo *);
  GnomeDatabase * (*ok_callback)(gint );
};

/* function prototypes */
static GtkWidget *pq_create_notebook_tab (GtkWidget *, struct GSQLFE_DriverInfo *);
static GnomeDatabase *pq_ok_callback (gint );

/* global variables */
static struct GSQLFE_DriverInfo l_drivers[] =
  {
    /* PostGres SQL interface */
    { TRUE, NULL, "PostgreSQL", NULL, pq_create_notebook_tab, pq_ok_callback },
    { FALSE, NULL, "\0", NULL, NULL, NULL }
  };
static gboolean l_connecting = FALSE;
static GnomeDatabase *l_database = NULL;

/* static function */
static void 
dialog_clicked_cb(GnomeDialog *dialog, gint button_number, 
                  gpointer data)
{
  register gint cnt;
  switch (button_number)
    {
    case 0 : /* OK button */
      {
        gint cur_tab = gtk_notebook_current_page(GTK_NOTEBOOK(data));
        if (l_drivers[cur_tab].ok_callback != NULL)
          {
            GnomeDatabase *db;
            /* create driver connection */
            db = (*l_drivers[cur_tab].ok_callback)(cur_tab);
            if (db != NULL)
              {
                /* free memory */
                for (cnt = 0; l_drivers[cnt].is_ok != FALSE; cnt++)
                  {
                    if (l_drivers[cnt].children != NULL)
                      {
                        GList *node;
                        while ((node = g_list_first(l_drivers[cnt].children)))
                          l_drivers[cnt].children = g_list_remove(l_drivers[cnt].children,
                                                                  node->data);
                      }
                  }
                /* close dialog */
                l_connecting = FALSE;
                db_new_connection(db);
                gnome_dialog_close(dialog);
              }
          }
        break;
      }
    case 1 : /* Cancel button */
      /* free memory */
      for (cnt = 0; l_drivers[cnt].is_ok != FALSE; cnt++)
        {
          if (l_drivers[cnt].children != NULL)
            {
              GList *node;
              while ((node = g_list_first(l_drivers[cnt].children)))
                   l_drivers[cnt].children = g_list_remove(l_drivers[cnt].children,
                                                           node->data);
            }
        }
      /* close dialog */
      l_connecting = FALSE;
      gnome_dialog_close(dialog);
      break;
    }
}

/* PostgreSQL driver */
static GtkWidget *
pq_create_notebook_tab (GtkWidget *notebook, struct GSQLFE_DriverInfo *drvinfo)
{
  GtkWidget *tab, *w;
  /* check parameters */
  g_return_val_if_fail(drvinfo != NULL, NULL);
  /* create the table */
  tab = gtk_table_new(5, 4, FALSE);
  gtk_widget_show(tab);
  /* create widgets in the following order: */
  /* 1 - database name */
  ui_new_label_in_table(tab, "Database:", 0, 0, 2, 1);
  w = ui_new_entry_in_table(tab, "DBNAME", g_getenv("PGDATABASE"), 2, 0, 4, 1);
  drvinfo->children = g_list_append(drvinfo->children, (gpointer) w);
  /* 2 - login */
  ui_new_label_in_table(tab, "User:", 0, 1, 2, 2);
  w = ui_new_entry_in_table(tab, "LOGIN", g_get_user_name(), 2, 1, 4, 2);
  drvinfo->children = g_list_append(drvinfo->children, (gpointer) w);
  /* 3 - password */
  ui_new_label_in_table(tab, "Password:", 0, 2, 2, 3);
  w = ui_new_entry_in_table(tab, "PASSWORD", NULL, 2, 2, 3, 3);
  gtk_entry_set_visibility(GTK_ENTRY(w), FALSE);
  drvinfo->children = g_list_append(drvinfo->children, (gpointer) w);
  /* 4 - host */
  ui_new_label_in_table(tab, "Host:", 0, 3, 1, 4);
  w = ui_new_entry_in_table(tab, "HOST", g_getenv("PGHOST"), 1, 3, 2, 4);
  drvinfo->children = g_list_append(drvinfo->children, (gpointer) w);
  /* 5 - port */
  ui_new_label_in_table(tab, "Port:", 2, 3, 3, 4);
  w = ui_new_entry_in_table(tab, "PORT", g_getenv("PGPORT"), 3, 3, 4, 4);
  drvinfo->children = g_list_append(drvinfo->children, (gpointer) w);
  /* 6 - options */
  ui_new_label_in_table(tab, "Options:", 0, 4, 1, 5);
  w = ui_new_entry_in_table(tab, "OPTIONS", g_getenv("PGOPTIONS"), 1, 4, 2, 5);
  drvinfo->children = g_list_append(drvinfo->children, (gpointer) w);
  /* 7 - tty */
  ui_new_label_in_table(tab, "TTY:", 2, 4, 3, 5);
  w = ui_new_entry_in_table(tab, "TTY", g_getenv("PGTTY"), 3, 4, 4, 5);
  drvinfo->children = g_list_append(drvinfo->children, (gpointer) w);
  return (tab);
}

static GnomeDatabase *
pq_ok_callback (gint pos)
{
  gchar *dbname, *login, *password, *host, *port, *options, *tty;
  GList *node;
  GnomeDatabase *gdb;
  GtkWidget *w;
  /* initialize variables */
  dbname = login = password = host = port = options = tty = NULL;
  /* traverse children list */
  node = g_list_first(l_drivers[pos].children);
  while (node != NULL)
    {
      w = node->data;
      if (w != NULL)
        {
          gchar *name;
          name = gtk_widget_get_name(w);
          if (!g_strcasecmp(name, "DBNAME"))
            dbname = gtk_entry_get_text(GTK_ENTRY(w));
          else if (!g_strcasecmp(name, "LOGIN"))
            login = gtk_entry_get_text(GTK_ENTRY(w));
          else if (!g_strcasecmp(name, "PASSWORD"))
            password = gtk_entry_get_text(GTK_ENTRY(w));
          else if (!g_strcasecmp(name, "HOST"))
            host = gtk_entry_get_text(GTK_ENTRY(w));
          else if (!g_strcasecmp(name, "PORT"))
            port = gtk_entry_get_text(GTK_ENTRY(w));
          else if (!g_strcasecmp(name, "OPTIONS"))
            options = gtk_entry_get_text(GTK_ENTRY(w));
          else if (!g_strcasecmp(name, "TTY"))
            tty = gtk_entry_get_text(GTK_ENTRY(w));
        }
      /* move to next node in the list */
      node = g_list_next(node);
    }
  /* establish the connection to the PostgreSQL database */
  gdb = gnome_sql_connect(GNOME_SQL_DRIVER_POSTGRES, dbname, login, password, host);
  if (gdb == NULL)
    ui_show_error("Could not establish connection to database %s", dbname);
  return (gdb);
}

/* function definitions */
void 
db_open_connection (GtkWidget *w, gpointer data)
{
  register int cnt;
  GtkWidget *notebook;
  static GtkWidget *dialog;
  /* if we are already connecting... */
  if (l_connecting)
    {
      gtk_widget_show(dialog);	/* FIXME: want to get focus!!! */
      gtk_widget_grab_focus(dialog);
      return;
    }
  l_connecting = TRUE;
  /* create dialog box */
  dialog = gnome_dialog_new("Open Connection", 
                            GNOME_STOCK_BUTTON_OK,
                            GNOME_STOCK_BUTTON_CANCEL,
                            NULL);
  gnome_dialog_set_default(GNOME_DIALOG(dialog), 0);
  /* create notebook */
  notebook = gtk_notebook_new();
  gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook), GTK_POS_TOP);
  gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(dialog)->vbox), notebook,
                     TRUE, TRUE, GNOME_PAD);
  gtk_signal_connect(GTK_OBJECT(dialog), "clicked",
                     GTK_SIGNAL_FUNC(dialog_clicked_cb), (gpointer) notebook);
  /* add database drivers connection screens */
  for (cnt = 0; l_drivers[cnt].is_ok != FALSE; cnt++)
    {
      GtkWidget *driver_tab, *label;
      /* create internal information */
      driver_tab = (*l_drivers[cnt].create_notebook_tab)(notebook, &l_drivers[cnt]);
      if (driver_tab != NULL)
        {
          /* create the tab's label */
          label = gtk_label_new(l_drivers[cnt].label);
          gtk_notebook_append_page(GTK_NOTEBOOK(notebook), driver_tab,
                                   label);
        }
    }
  gtk_widget_show(notebook);
  /* finally show the dialog */
  gtk_widget_show(dialog);
}
