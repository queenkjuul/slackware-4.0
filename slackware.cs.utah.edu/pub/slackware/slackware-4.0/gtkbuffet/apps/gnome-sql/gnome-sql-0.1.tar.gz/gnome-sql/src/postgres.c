/* gnome-sql - GNOME SQL interface
 * Copyright (c) 1998 by Rodrigo Moya

 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* header files */
#include <gnome-sql.h>
#include <pgsql/libpq-fe.h>

/*function prototypes */
static postgres_close_rowset (GnomeDatabase *, GnomeSqlRowset *);

/* result sets */
static gboolean 
postgres_close_rowset (GnomeDatabase *gdb, GnomeSqlRowset *prs)
{
  g_return_val_if_fail(gdb != NULL && prs != NULL, FALSE);
  PQclear((PGresult *) prs->private_data);
  return (TRUE);
}

static gint 
postgres_get_field_count (GnomeSqlRowset *prs)
{
  if (prs != NULL)
    {
      PGresult *pgRes = (PGresult *) prs->private_data;
      return (PQnfields(pgRes));
    }
  else return (-1);
}

static gchar *
postgres_get_field_name (GnomeSqlRowset *prs, gint index)
{
  if (prs != NULL)
    {
      PGresult *pgRes = (PGresult *) prs->private_data;
      return (PQfname(pgRes, index));
    }
  return (NULL);
}

static gint 
postgres_get_field_position (GnomeSqlRowset *prs, const gchar *field_name)
{
  if (prs != NULL)
    {
      PGresult *pgRes = (PGresult *) prs->private_data;
      return (PQfnumber(pgRes, field_name));
    }
  return (-1);
}

static gint 
postgres_get_field_size (GnomeSqlRowset *prs, gint index)
{
  if (prs != NULL)
    {
      PGresult *pgRes = (PGresult *) prs->private_data;
      return (PQfsize(pgRes, index));
    }
  return (-1);
}

static gchar *
postgres_get_field_value (GnomeSqlRowset *prs, gint row, gint col)
{
  gchar *res;
  g_return_val_if_fail(prs != NULL, NULL);
  res = PQgetvalue((PGresult *) prs->private_data, row, col);
  if (res != NULL) return (res);
  else g_warning(PQerrorMessage((PGconn *) prs->database->private_data));
  return (NULL);
}

static gint 
postgres_get_row_count (GnomeSqlRowset *prs)
{
  if (prs != NULL)
    {
      PGresult *pgRes = (PGresult *) prs->private_data;
      return (PQntuples(pgRes));
    }
  return (-1);
}

/* database interface */
static gboolean
postgres_begin_transaction (GnomeDatabase *gdb)
{
  PGresult *res;
  int rc;
  /* check parameters */
  g_return_val_if_fail(gdb != NULL, FALSE);
  if (PQstatus((PGconn *) gdb->private_data) == CONNECTION_OK)
    {
      /* execute command */
      res = PQexec((PGconn *) gdb->private_data, "BEGIN");
      rc = PQresultStatus(res);
      PQclear(res);
      if (rc == PGRES_COMMAND_OK)
	return (TRUE);
      else g_warning(PQerrorMessage((PGconn *) gdb->private_data));
    }
  else g_warning("invalid connection handle");
  return (FALSE);
}

static gboolean
postgres_commit_transaction (GnomeDatabase *gdb)
{
  PGresult *res;
  int rc;
  /* check parameters */
  g_return_val_if_fail(gdb != NULL, FALSE);
  if (PQstatus((PGconn *) gdb->private_data) == CONNECTION_OK)
    {
      /* execute command */
      res = PQexec((PGconn *) gdb->private_data, "COMMIT");
      rc = PQresultStatus(res);
      PQclear(res);
      if (rc == PGRES_COMMAND_OK)
	return (TRUE);
      else g_warning(PQerrorMessage((PGconn *) gdb->private_data));
    }
  else g_warning("invalid connection handle");
  return (FALSE);
}

static GnomeSqlRowset *
postgres_describe_table (GnomeDatabase *gdb, const gchar *table)
{
  gchar *query;
  GnomeSqlRowset *rowset;
  /*check parameters */
  g_return_val_if_fail(gdb != NULL && table != NULL, NULL);
  /* construct query */
  query = g_strdup_printf("select b.attname, b.attlen \
                           from pg_class a, pg_attribute b \
                           where a.oid = b.attrelid \
                           and a.relname = '%s' order by b.attname",
                          table);
  rowset = gnome_sql_open_rowset(gdb, query);
  g_free((gpointer) query);
  return (rowset);
}

static gboolean 
postgres_disconnect (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL, FALSE);
  /* close driver connection */
  PQfinish((PGconn *) gdb->private_data);
  return (TRUE);
}

static GnomeSqlResult 
postgres_execute_command (GnomeDatabase *gdb,
					 const gchar *command)
{
  long rc = 0;
  /* check connection */
  g_return_val_if_fail(gdb != NULL, GNOME_SQL_RESULT_ERROR);
  if (PQstatus((PGconn *) gdb->private_data) == CONNECTION_OK)
    {
      PGresult *pgres = PQexec((PGconn *) gdb->private_data, command);
      switch (PQresultStatus(pgres))
	{
	case PGRES_EMPTY_QUERY :
          rc = 0;
          break;
	case PGRES_COMMAND_OK :
	case PGRES_COPY_OUT :
	case PGRES_COPY_IN :
	  rc = GNOME_SQL_RESULT_OK;
	  break;
	case PGRES_TUPLES_OK :
	  rc = PQntuples(pgres);
	  break;
	case PGRES_BAD_RESPONSE :
	case PGRES_NONFATAL_ERROR:
	case PGRES_FATAL_ERROR :
	  g_warning(PQerrorMessage((PGconn *) gdb->private_data));
	  rc = GNOME_SQL_RESULT_ERROR;
          break;
	}
      /* free memory */
      PQclear(pgres);
      return (rc);
    }
  else g_warning("invalid connection");
  return (GNOME_SQL_RESULT_ERROR);
}

static const gchar *
postgres_get_current_database (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL, NULL);
  if (PQstatus((PGconn *) gdb->private_data) == CONNECTION_OK)
    return (PQdb((PGconn *) gdb->private_data));
  else g_warning("invalid connection handle");
  return (NULL);
}

static const gchar *
postgres_get_last_error (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL, NULL);
  if (PQstatus((PGconn *) gdb->private_data) == CONNECTION_OK)
    return (PQerrorMessage((PGconn *) gdb->private_data));
  return ("Invalid connection handle");
}

static GList *
postgres_get_tables (GnomeDatabase *gdb)
{
  GList *result = NULL;
  GnomeSqlRowset *rowset;
  gchar query[2048], *str;
  /* check connection */
  g_return_val_if_fail(gdb != NULL, NULL);
  if (PQstatus((PGconn *) gdb->private_data) == CONNECTION_OK)
    {
      /* compound query string */
      sprintf(query, 
              "SELECT a.relname FROM pg_database b, pg_class a %s '%s' %s",
              "WHERE b.datname = ",
              gnome_sql_get_current_database(gdb),
              "AND a.relowner = b.datdba ORDER BY a.relname");
      rowset = gnome_sql_open_rowset(gdb, (const gchar *) query);
      /* and add rowset to list */
      if (rowset != NULL)
        {
          register int cnt, total;
          total = gnome_sql_rowset_get_row_count(rowset);
          for (cnt = 0; cnt < total; cnt++)
            {
              str = g_malloc(gnome_sql_rowset_get_field_size(rowset, 0) + 1);
              strcpy(str, gnome_sql_rowset_get_field_value(rowset, cnt, 0));
              result = g_list_append(result, (gpointer) str);
            }
          /* close result set */
          gnome_sql_close_rowset(gdb, rowset);
          return (result);
        }
    }
  else g_warning("Invalid connection handle");
  return (NULL);
}

static const gchar *
postgres_get_user (GnomeDatabase *gdb)
{
  /* FIXME: is there a way to retrieve connected user's name? */
  g_return_val_if_fail(gdb != NULL, NULL);
  return (NULL);
}

static void
initialize_resultset (GnomeSqlRowset *prs)
{
  /* initialize structure */
  prs->get_field_count = postgres_get_field_count;
  prs->get_field_name = postgres_get_field_name;
  prs->get_field_size = postgres_get_field_size;
  prs->get_field_position = postgres_get_field_position;
  prs->get_field_value = postgres_get_field_value;
  prs->get_row_count = postgres_get_row_count;
}

static GnomeSqlRowset *
postgres_open_rowset (GnomeDatabase *gdb,
		      const gchar *query)
{
  static glong cursor_number = 0.0;
  gchar *tmp_query;
  g_return_val_if_fail(gdb != NULL, NULL);
  g_return_val_if_fail(query != NULL, NULL);
  cursor_number += 1;
  if (PQstatus(gdb->private_data) == CONNECTION_OK)
    {
      GnomeSqlRowset *prs = (GnomeSqlRowset *) g_malloc(sizeof(GnomeSqlRowset));
      if (prs != NULL)
	{
	  tmp_query = g_strdup_printf("DECLARE C%010ld CURSOR FOR %s",
	                              cursor_number, query);
	  prs->private_data = (gpointer) PQexec((PGconn *) gdb->private_data,
	                                        tmp_query);
	  g_free((gpointer) tmp_query);
	  switch (PQresultStatus((PGresult *) prs->private_data))
	    {
	    case PGRES_EMPTY_QUERY :
	    case PGRES_TUPLES_OK :
	    case PGRES_COMMAND_OK :
   	    case PGRES_COPY_OUT :
            case PGRES_COPY_IN :
            {
              gint res;
              PQclear(prs->private_data);
              tmp_query = g_strdup_printf("FETCH ALL IN C%010ld", cursor_number);
              prs->private_data = PQexec((PGconn *) gdb->private_data, tmp_query);
              res = PQresultStatus((PGresult *) prs->private_data);
              if (prs->private_data != NULL && (res == PGRES_EMPTY_QUERY ||
                  res == PGRES_TUPLES_OK))
                {
                  g_free((gpointer) tmp_query);
  	          initialize_resultset(prs);
	          return (prs);
	        }
	      g_free((gpointer) tmp_query);
	    }
	    case PGRES_BAD_RESPONSE :
	    case PGRES_NONFATAL_ERROR:
	    case PGRES_FATAL_ERROR :
	      /* try without declaring cursor */
	      prs->private_data = PQexec((PGconn *) gdb->private_data,
	                                  query);
 	      switch (PQresultStatus((PGresult *) prs->private_data))
	        {
	        case PGRES_EMPTY_QUERY :
  	        case PGRES_TUPLES_OK :
	        case PGRES_COMMAND_OK :
   	        case PGRES_COPY_OUT :
                case PGRES_COPY_IN :
                  initialize_resultset(prs);
                  return (prs);
	        }
	    default :
	      if (prs->private_data != NULL)
	        PQclear((PGresult *) prs->private_data);
	      g_warning(PQerrorMessage((PGconn *) gdb->private_data));
	      break;
	    }
	}
      else g_warning("Cannot allocate %d bytes", sizeof(GnomeSqlRowset));
    }
  else g_warning("invalid connection");
  return (NULL);
}

static gboolean
postgres_rollback_transaction (GnomeDatabase *gdb)
{
  PGresult *res;
  int rc;
  /* check parameters */
  g_return_val_if_fail(gdb != NULL, FALSE);
  if (PQstatus((PGconn *) gdb->private_data) == CONNECTION_OK)
    {
      /* execute command */
      res = PQexec((PGconn *) gdb->private_data, "ROLLBACK");
      rc = PQresultStatus(res);
      PQclear(res);
      if (rc == PGRES_COMMAND_OK)
	return (TRUE);
      else g_warning(PQerrorMessage((PGconn *) gdb->private_data));
    }
  else g_warning("invalid connection handle");
  return (FALSE);
}

static gboolean
postgres_start_logging (GnomeDatabase *gdb, const gchar *logfile)
{
  FILE *flog;
  g_return_val_if_fail(gdb != NULL && logfile != NULL, FALSE);
  /* open the specified file */
  if ((flog = fopen(logfile, "w")))
    {
      PQtrace((PGconn *) gdb->private_data, flog);
      return (TRUE);
    }
  else g_warning("could not open file %s", logfile);
  return (FALSE);
}

static gboolean
postgres_stop_logging (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL, FALSE);
  PQuntrace((PGconn *) gdb->private_data);
  return (TRUE);
}

/* public interface */
GnomeDatabase *
gnome_sql_connect_postgres (gchar *dbname, 
                            gchar *login, 
                            gchar *password,
                            gchar *host)
{
  GnomeDatabase *gdb;
  if ((gdb = (GnomeDatabase *) g_malloc(sizeof(GnomeDatabase))))
    {
      gdb->private_data = (void *) PQsetdbLogin(host, NULL, NULL, NULL,
						                dbname, login, password);
      if (PQstatus((PGconn *) gdb->private_data) == CONNECTION_OK)
	{
          /* initialize database structure */
	  gdb->begin_transaction = postgres_begin_transaction;
          gdb->close_rowset = postgres_close_rowset;
	  gdb->commit_transaction = postgres_commit_transaction;
	  gdb->describe_table = postgres_describe_table;
          gdb->disconnect = postgres_disconnect;
          gdb->execute_command = postgres_execute_command;
          gdb->get_current_database = postgres_get_current_database;
          gdb->get_last_error = postgres_get_last_error;
          gdb->get_tables = postgres_get_tables;
          gdb->get_user = postgres_get_user;
          gdb->open_rowset = postgres_open_rowset;
	  gdb->rollback_transaction = postgres_rollback_transaction;
	  gdb->start_logging = postgres_start_logging;
	  gdb->stop_logging = postgres_stop_logging;
          return (gdb);
	}
      else g_warning(PQerrorMessage((PGconn *) gdb->private_data));
    }
  else g_warning("Cannot allocate %ld bytes", sizeof(GnomeDatabase));
  return (NULL);
}
