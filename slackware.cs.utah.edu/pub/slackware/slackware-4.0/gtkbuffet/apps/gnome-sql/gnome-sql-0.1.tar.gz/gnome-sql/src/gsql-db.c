/* gnome-sql - GNOME SQL Interface
 * Copyright (c) 1998 by Rodrigo Moya

 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* header files */
#include <gnome-sql.h>

/* extern functions declaration */
GnomeDatabase *gnome_sql_connect_postgres (gchar *, gchar *, gchar *, gchar *);

/* global variables */
typedef GnomeDatabase * (*GSQL_DriverConnectFunction)(gchar *,
                                                         gchar *,
                                                         gchar *,
                                                         gchar *);
                                                         
static GSQL_DriverConnectFunction l_driverfn[] =
  {
    NULL,
    gnome_sql_connect_postgres
  };

/* function definitions */
gboolean
gnome_sql_begin_transaction (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL && gdb->begin_transaction != NULL, FALSE);
  return ((*gdb->begin_transaction)(gdb));
}

gboolean
gnome_sql_commit_transaction (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL && gdb->commit_transaction != NULL, FALSE);
  return ((*gdb->commit_transaction)(gdb));
}

GnomeDatabase *
gnome_sql_connect (GnomeSqlDriver drv, 
                   gchar *database, 
                   gchar *login,
                   gchar *password,
                   gchar *host)
{
  GnomeDatabase *gdb;
  g_return_val_if_fail(l_driverfn[drv] != NULL, NULL);
  gdb = (*l_driverfn[drv])(database, login, password, host);
  if (gdb != NULL)
    {
      gdb->dbname = (database != NULL ? g_strdup(database) : NULL);
      gdb->login = (login != NULL ? g_strdup(login) : NULL);
      gdb->password = (password != NULL ? g_strdup(password) : NULL);
      gdb->host = (host != NULL ? g_strdup(host) : NULL);
      /* initialize to NULL internal fields */
      gdb->rowsets = NULL;
      gdb->driver = drv;
      /* start transaction */
      gnome_sql_begin_transaction(gdb);
      return (gdb);
    }
  return (NULL);
}

GnomeSqlRowset *
gnome_sql_describe_table (GnomeDatabase *gdb, const gchar *table)
{
  g_return_val_if_fail(gdb != NULL && table != NULL &&
                       gdb->describe_table != NULL, NULL);
  return ((*gdb->describe_table)(gdb, table));
}

gboolean 
gnome_sql_disconnect (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL, FALSE);
  if (gdb->disconnect != NULL)
    {
      gboolean rc = (*gdb->disconnect)(gdb);
      if (rc)
        {
          /* free memory */
          if (gdb->dbname != NULL) g_free(gdb->dbname);
          if (gdb->login != NULL) g_free(gdb->login);
          if (gdb->password != NULL) g_free(gdb->password);
          if (gdb->host != NULL) g_free(gdb->host);
          g_free((gpointer) gdb);
        }
      return (rc);
    }
  return (FALSE);
}

GnomeSqlResult
gnome_sql_execute_command (GnomeDatabase *gdb,
					  const gchar *command)
{
  return ((gdb != NULL) && (gdb->execute_command)
	  ? (*gdb->execute_command)(gdb, command) :
	     GNOME_SQL_RESULT_ERROR);
}

const gchar *
gnome_sql_get_current_database (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL, NULL);
  if (gdb->get_current_database != NULL)
    {
      gchar *dbname = (*gdb->get_current_database)(gdb);
      if (dbname != NULL)
        return ((const gchar *) dbname);
    }
  /* return internally stored value */
  return (gdb->dbname);
}

GnomeSqlDriver 
gnome_sql_get_driver (GnomeDatabase *gdb)
{
  return (gdb != NULL ? gdb->driver : GNOME_SQL_DRIVER_NONE);
}

const gchar *
gnome_sql_get_last_error (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL && gdb->get_last_error != NULL, NULL);
  return ((*gdb->get_last_error)(gdb));
}

GList *
gnome_sql_get_tables (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL && gdb->get_tables != NULL, NULL);
  return ((*gdb->get_tables)(gdb));
}

const gchar *
gnome_sql_get_user (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL, NULL);
  if (gdb->get_user != NULL)
    {
      gchar *login = (*gdb->get_user)(gdb);
      if (login != NULL)
        return ((const gchar *) login);
    }
  /* return internally stored value */
  return (gdb->login);
}

gboolean
gnome_sql_is_logging_enabled (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL, FALSE);
  return (gdb->logging_enabled);
}

gboolean
gnome_sql_rollback_transaction (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL && gdb->rollback_transaction != NULL, FALSE);
  return ((*gdb->rollback_transaction)(gdb));
}

gboolean
gnome_sql_start_logging (GnomeDatabase *gdb, const gchar *logfile)
{
  g_return_val_if_fail(gdb != NULL && gdb->start_logging != NULL, FALSE);
  return ((*gdb->start_logging)(gdb, logfile));
}

gboolean
gnome_sql_stop_logging (GnomeDatabase *gdb)
{
  g_return_val_if_fail(gdb != NULL && gdb->stop_logging != NULL, FALSE);
  return ((*gdb->stop_logging)(gdb));
}