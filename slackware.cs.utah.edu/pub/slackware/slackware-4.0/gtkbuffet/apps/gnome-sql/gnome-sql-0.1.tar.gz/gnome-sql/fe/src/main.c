/* gnome-sql - GUI front-end
 * Copyright (c) 1998 by Rodrigo Moya

 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* header files */
#include "gsqlfe.h"

/* global variables */
GnomeApp *glb_app = NULL;
GtkWidget *wContainer = NULL, *wWorkArea = NULL, *wStatusBar = NULL;

/* function definitions */
static void prepare_app (void);

gint main (gint argc, gchar *argv[])
{
  /* initialize GNOME stuff */
  gnome_init("gsqlfe", NULL, argc, &argv);
  prepare_app();
  /* main loop */
  gtk_main();
  return (0);
}

/* callbacks */
static void about_cb (GtkWidget *w, gpointer data)
{
  const gchar *authors[] = { "Rodrigo Moya, Main programmer", 
			     "GNOME team, Ideas, tutorials, ...",
			     NULL };
  GtkWidget *about = gnome_about_new(_("GNOME-SQL"), _("Front-End"),
				     _("Copyright Rodrigo Moya (C) 1998"),
				     authors,
				     _("GNOME SQL FE - GNOME Database Front End"),
				     "/usr/share/pixmaps/gnome-logo.xpm");
  gtk_widget_show(about);
}

static void quit_cb (GtkWidget *w, gpointer data)
{
  db_close_all_connections(w, data);
  gtk_main_quit();
}

/* menu definitions */
GnomeUIInfo filemenu[] =
{
  { GNOME_APP_UI_ITEM, N_("New connection..."), N_("Open a new connection"),
      db_open_connection, NULL, NULL, GNOME_APP_PIXMAP_STOCK, 
      GNOME_STOCK_MENU_LINE_IN, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Disconnect"), N_("Close current connection"),
      db_close_connection, NULL, NULL, GNOME_APP_PIXMAP_STOCK, 
      GNOME_STOCK_MENU_STOP, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Disconnect All"), N_("Close all connections"),
      db_close_all_connections, NULL, NULL, GNOME_APP_PIXMAP_STOCK, 
      GNOME_STOCK_MENU_STOP, 0, 0, NULL },
  GNOMEUIINFO_SEPARATOR,
  { GNOME_APP_UI_ITEM, N_("Quit"), N_("Exit application"),
      quit_cb, NULL, NULL, GNOME_APP_PIXMAP_STOCK, GNOME_STOCK_MENU_QUIT, 
      0, 0, NULL },
  GNOMEUIINFO_END
};
GnomeUIInfo editmenu[] =
{
  { GNOME_APP_UI_ITEM, N_("Cut  \t\tCtl+X"), 
    N_("Cut selected text to clipboard"),
    sql_cut_text, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_MENU_CUT, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Copy\t\tCtl+C"), 
    N_("Copy selected text to clipboard"),
    sql_copy_text, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_MENU_COPY, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Paste\t\tCtl+V"), N_("Paste text from clipboard"),
    sql_paste_text, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_MENU_PASTE, 0, 0, NULL },
  GNOMEUIINFO_END
};
GnomeUIInfo sqlmenu[] =
{
  { GNOME_APP_UI_ITEM, N_("Run SQL"), N_("Execute command from SQL window"),
      db_exec_command, NULL, NULL, GNOME_APP_PIXMAP_STOCK, 
      GNOME_STOCK_MENU_EXEC, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Run as Script"), N_("Run SQL buffer as a script"),
      sql_run_script, NULL, NULL, GNOME_APP_PIXMAP_STOCK, 
      GNOME_STOCK_MENU_EXEC, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Load Script..."), N_("Load SQL script from disk"),
    NULL, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_MENU_OPEN, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Save to file..."), N_("Save current buffer to file"),
    NULL, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_MENU_SAVE, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Select SQL command..."), 
    N_("Select one of the last executed commands"),
    sql_select_command, NULL, NULL, GNOME_APP_PIXMAP_NONE,
    NULL, 0, 0, NULL },
  GNOMEUIINFO_SEPARATOR,
  { GNOME_APP_UI_ITEM, N_("Refresh"), N_("Refresh grid"),
    sql_refresh_grid, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_MENU_REFRESH, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Clear Window"), N_("Clear SQL window"),
    sql_clear_window, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_MENU_TRASH, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Print..."), N_("Print grid"),
    NULL, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_MENU_PRINT, 0, 0, NULL },
  GNOMEUIINFO_END
};
GnomeUIInfo databasemenu[] =
{
  { GNOME_APP_UI_ITEM, N_("Table Browser"), N_("Browse database tables"),
      db_table_browser, NULL, NULL, GNOME_APP_PIXMAP_NONE, 
      NULL, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Start/Stop Trace"), 
      N_("Start or stop database trace"),
      db_set_trace, NULL, NULL, GNOME_APP_PIXMAP_NONE,
      NULL, 0, 0, NULL },
  GNOMEUIINFO_SEPARATOR,
  { GNOME_APP_UI_ITEM, N_("Begin Transaction"), N_("Begin new transaction"),
      db_start_transaction, NULL, NULL, GNOME_APP_PIXMAP_STOCK, 
      GNOME_STOCK_MENU_LAST, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Commit"), N_("Commit changes"),
      db_commit, NULL, NULL, GNOME_APP_PIXMAP_STOCK, 
      GNOME_STOCK_MENU_REDO, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Rollback"), N_("Discard all changes"),
      db_rollback, NULL, NULL, GNOME_APP_PIXMAP_STOCK, 
      GNOME_STOCK_MENU_REVERT, 0, 0, NULL },
  GNOMEUIINFO_END
};
GnomeUIInfo optionsmenu[] =
{
  { GNOME_APP_UI_ITEM, N_("Preferences..."), N_("Configure user preferences"),
    NULL, NULL, NULL, GNOME_APP_PIXMAP_STOCK, 
    GNOME_STOCK_MENU_PREF, 0, 0, NULL },
  GNOMEUIINFO_SEPARATOR,
  { GNOME_APP_UI_ITEM, N_("Save Options"), N_("Save current configuration"),
    NULL, NULL, NULL, GNOME_APP_PIXMAP_NONE, 
    NULL, 0, 0, NULL },
  GNOMEUIINFO_END
};
GnomeUIInfo helpmenu[] =
{
  { GNOME_APP_UI_ITEM, N_("Contents"), N_("Online Help"),
    NULL, NULL, NULL, GNOME_APP_PIXMAP_NONE,
    NULL, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("SQL Reference"), N_("A short but concise SQL reference"),
    NULL, NULL, NULL, GNOME_APP_PIXMAP_NONE,
    NULL, 0, 0, NULL },
  GNOMEUIINFO_SEPARATOR,
  { GNOME_APP_UI_ITEM, N_("About gnome-sql..."), N_("About this program"),
    about_cb, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_MENU_ABOUT, 0, 0, NULL },
  GNOMEUIINFO_END
};
GnomeUIInfo mainmenu[] =
{
  GNOMEUIINFO_SUBTREE(N_("File"), filemenu),
  GNOMEUIINFO_SUBTREE(N_("Edit"), editmenu),
  GNOMEUIINFO_SUBTREE(N_("SQL"), sqlmenu),
  GNOMEUIINFO_SUBTREE(N_("Database"), databasemenu),
  GNOMEUIINFO_SUBTREE(N_("Options"), optionsmenu),
  GNOMEUIINFO_SUBTREE(N_("Help"), helpmenu),
  GNOMEUIINFO_END
};

/* toolbar */
GnomeUIInfo toolbar[] =
{
  { GNOME_APP_UI_ITEM, N_("Connect"), N_("Open a new connection"),
    db_open_connection, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_PIXMAP_LINE_IN, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Disconnect"), N_("Close current connection"),
    db_close_connection, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_PIXMAP_STOP, 0, 0, NULL },
  GNOMEUIINFO_SEPARATOR,
  { GNOME_APP_UI_ITEM, N_("Preferences"), N_("Configure user preferences"),
    NULL, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_PIXMAP_PREFERENCES, 0, 0, NULL },
  { GNOME_APP_UI_ITEM, N_("Help"), N_("Online Help"),
    NULL, NULL, NULL, GNOME_APP_PIXMAP_STOCK,
    GNOME_STOCK_PIXMAP_HELP, 0, 0, NULL },
  GNOMEUIINFO_END
};

static void prepare_app (void)
{
  /* create main window */
  glb_app = gnome_app_new("gsqlfe", "GNOME-SQL");
  gtk_widget_realize(GTK_WIDGET(glb_app));
  gtk_signal_connect(GTK_OBJECT(glb_app), "delete_event",
		     GTK_SIGNAL_FUNC(quit_cb), NULL);
  gtk_signal_connect(GTK_OBJECT(glb_app), "destroy",
                     GTK_SIGNAL_FUNC(quit_cb), NULL);
  /* FIXME: add a call to load_settings() to load user settings */
  gtk_widget_set_usize(GTK_WIDGET(glb_app), 600, 400);
  /* main window container */
  wContainer = gtk_vbox_new(FALSE, 0);
  /* create work area */
  wWorkArea = gtk_notebook_new();
  gtk_notebook_set_tab_pos(GTK_NOTEBOOK(wWorkArea), GTK_POS_BOTTOM);
  gtk_notebook_set_show_border(GTK_NOTEBOOK(wWorkArea), TRUE);
  gtk_box_pack_start(GTK_BOX(wContainer), wWorkArea, TRUE, TRUE, 0);
  gtk_widget_show(wWorkArea);
  /* show all the widget hierarchy */
  gnome_app_create_toolbar(glb_app, toolbar);
  gnome_app_set_contents(glb_app, wContainer);
  gnome_app_create_menus(glb_app, mainmenu);
  wStatusBar = gtk_statusbar_new();
  gnome_app_set_statusbar(GNOME_APP(glb_app), wStatusBar);
  gtk_widget_show(wContainer);
  gtk_widget_show(GTK_WIDGET(glb_app));
}
