/* GnomENIUS Calculator
 * Copyright (C) 1997 George Lebl.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef _EVAL_H_
#define _EVAL_H_

#include <gmp.h>

typedef enum {NUMBER_NODE,FUNCTION_NODE} node_type_t;
typedef enum {INTEGER_TYPE,FLOAT_TYPE,RATIONAL_TYPE} num_type_t;
typedef enum {BUILTIN_TYPE,USER_TYPE} func_type_t;


typedef struct tree_struct {
	node_type_t type;
	union {
		struct {
			num_type_t type;
			union {
				mpz_t ival;
				mpf_t fval;
				mpq_t rval;
			} data;
		} number;
		struct {
			func_type_t type;
			union {
				int builtin;
				char * user;
			} data;
		} function;
	} data;
	struct tree_struct *left;
	struct tree_struct *right;
} tree_t;

/* builtins */
#define E_PLUS 1
#define E_MINUS 2
#define E_MUL 3
#define E_DIV 4
#define E_NEG 5
#define E_EXP 6
#define E_FACT 7

/*functions for manipulating a tree*/
tree_t * makenum(num_type_t type, void * num);
tree_t * makefuncb(int func, tree_t *stack[], int *stackp);
/*no use functions FIXME*/

/*returns 1 or 2 depending if the operation has one or two branches*/
int branches(int op);

/*sets s to the string representation of the primitive, s has to be big
enough! */
void primstr(char *s, int op);

/*stack manipulation*/
int t_push(tree_t *n,tree_t *stack[],int *stackp);
tree_t *t_pop(tree_t *stack[],int *stackp);

/*functions for reclaiming memory*/
void freenode(tree_t *n);
void freetree(tree_t *n);

/*evaluate a treenode, the treenode will become a number node*/
/*the tree will be freed*/
tree_t *evalnode(tree_t *n);

/*make both number nodes the same type*/
void makesame(tree_t *l,tree_t *r);

/*make n an int if at all possible*/
void makeint(tree_t *n);

/*operations take two/one number nodes and return a number node*/
tree_t *plusop(tree_t *l,tree_t *r);
tree_t *minusop(tree_t *l,tree_t *r);
tree_t *mulop(tree_t *l,tree_t *r);
tree_t *divop(tree_t *l,tree_t *r);
tree_t *negop(tree_t *l);
tree_t *expop(tree_t *l, tree_t *r);
tree_t *factop(tree_t *l);

#endif
