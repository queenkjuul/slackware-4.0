/* GnomENIUS Calculator
 * Copyright (C) 1997 George Lebl.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <string.h>
#include <gmp.h>
#include <glib.h>
#include "eval.h"
#include "calc.h"

extern error_t error_num;

/*returns 10 01 or 11 depending if the operation has left, right or both
branches*/
int
branches(int op)
{
	switch(op) {
		case E_PLUS: return 3;
		case E_MINUS: return 3;
		case E_MUL: return 3;
		case E_DIV: return 3;
		case E_NEG: return 2;
		case E_EXP: return 3;
		case E_FACT: return 1;
	}
	return 0;
}

/*sets s to the string representation of the primitive, s has to be big
enough! */
void
primstr(char *s, int op)
{
	switch(op) {
		case E_PLUS: strcpy(s,"+"); return;
		case E_MINUS: strcpy(s,"-"); return;
		case E_MUL: strcpy(s,"*"); return;
		case E_DIV: strcpy(s,"/"); return;
		case E_NEG: strcpy(s,"~"); return;
		case E_EXP: strcpy(s,"^"); return;
		case E_FACT: strcpy(s,"!"); return;
	}
	strcpy(s,"<?>");
}

tree_t *
makenum(num_type_t type, void * num)
{
	tree_t *n;
	n=(tree_t *)g_malloc(sizeof(tree_t));
	n->type=NUMBER_NODE;
	n->data.number.type=type;
	if(type==INTEGER_TYPE)
		mpz_init_set(n->data.number.data.ival,
			*(mpz_t *)num);
	else if(type==FLOAT_TYPE)
		mpf_init_set(n->data.number.data.fval,
			*(mpf_t *)num);
	else { /* if(type==RATIONAL_TYPE) */
		mpq_init(n->data.number.data.rval);
		mpq_set(n->data.number.data.rval,
			*(mpq_t *)num);
	}
	n->left=NULL;
	n->right=NULL;
	makeint(n);
	return n;
}

tree_t *
makefuncb(int func,tree_t *stack[],int *stackp)
{
	tree_t *n;
	n=(tree_t *)g_malloc(sizeof(tree_t));
	n->type=FUNCTION_NODE;
	n->data.function.type=BUILTIN_TYPE;
	n->data.function.data.builtin=func;
	if(branches(func)&2)
		n->right=t_pop(stack,stackp);
	else
		n->right=NULL;
	if(branches(func)&1)
		n->left=t_pop(stack,stackp);
	else
		n->left=NULL;
	return n;
}

int
t_push(tree_t *n,tree_t *stack[],int *stackp)
{
	stack[++(*stackp)]=n;
	return TRUE;
}

tree_t *
t_pop(tree_t *stack[],int *stackp)
{
	if(*stackp==-1)
		return NULL;
	else
		return stack[(*stackp)--];
}

void
freenode(tree_t *n)
{
	if(!n)
		return;
	if(n->type==NUMBER_NODE) {
		if(n->data.number.type==INTEGER_TYPE)
			mpz_clear(n->data.number.data.ival);
		else if(n->data.number.type==FLOAT_TYPE)
			mpf_clear(n->data.number.data.fval);
		else /*RATIONAL_TYPE*/
			mpq_clear(n->data.number.data.rval);
	} else
		if(n->data.function.type==USER_TYPE)
			g_free(n->data.function.data.user);
}

void
freetree(tree_t *n)
{
	if(n->left)
		freetree(n->left);
	if(n->right)
		freetree(n->right);
	freenode(n);
}

/*evaluate a treenode, the treenode will become a number node*/
/*or at least all the calculatable parts will be calculated so*/
/*it will be a reduced tree*/
/*the tree will be freed*/
tree_t *
evalnode(tree_t *n)
{
	tree_t *r=NULL;
	if(n==NULL)
		return NULL;
	if(n->type==NUMBER_NODE)
		return n;

	if(n->data.function.type!=BUILTIN_TYPE) /*FIXME: user functions*/
		return n;

	n->right=evalnode(n->right);
	if(n->right==NULL && (branches(n->data.function.data.builtin)&2)) {
		freetree(n);
		return NULL; /*an error occured*/
	}
	n->left=evalnode(n->left);
	if(n->left==NULL && (branches(n->data.function.data.builtin)&1)) {
		freetree(n);
		return NULL; /*an error occured */
	}
	/*can't evaluate!*/
	if((n->right!=NULL && n->right->type!=NUMBER_NODE) ||
		(n->left!=NULL && n->left->type!=NUMBER_NODE))
		return n;
	switch(n->data.function.data.builtin) {
		case E_PLUS: r=plusop(n->left,n->right); break;
		case E_MINUS: r=minusop(n->left,n->right); break;
		case E_MUL: r=mulop(n->left,n->right); break;
		case E_DIV: r=divop(n->left,n->right); break;
		case E_NEG: r=negop(n->right); break;
		case E_EXP: r=expop(n->left,n->right); break;
		case E_FACT: r=factop(n->left); break;
	}
	if(r!=NULL) {
		freetree(n);
		return r;
	} else if(error_num!=NO_ERROR) {
		/*something errored out*/
		freetree(n);
		return NULL;
	} /*r==NULL && error_num==NO_ERROR*/
	/*this error is not too serious, just this action can't be computed*/
	return n;
}


/*make node int if at all possible*/
void
makeint(tree_t *n)
{
	mpz_t ir;
	mpf_t fr;

	if(n->type!=NUMBER_NODE || n->data.number.type==INTEGER_TYPE)
		return;
	if(n->data.number.type==RATIONAL_TYPE) {
		mpq_canonicalize(n->data.number.data.rval);
		if(mpz_cmp_ui(mpq_denref(n->data.number.data.rval),1)==0) {
			mpz_init_set(ir,mpq_numref(n->data.number.data.rval));
			mpq_clear(n->data.number.data.rval);
			mpz_init_set(n->data.number.data.ival,ir);
			mpz_clear(ir);
			n->data.number.type=INTEGER_TYPE;
		}
	} else { /*type==FLOAT_TYPE*/
		/*gotta find a better way of doing this!*/
		mpz_init(ir);
		mpz_set_f(ir,n->data.number.data.fval);
		mpf_init(fr);
		mpf_set_z(fr,ir);
		if(mpf_cmp(fr,n->data.number.data.fval)==0) {
			n->data.number.type=INTEGER_TYPE;
			mpf_clear(n->data.number.data.fval);
			mpz_init_set(n->data.number.data.ival,ir);
		}
		mpf_clear(fr);
		mpz_clear(ir);
	}
}

/*make both number nodes the same type*/
void
makesame(tree_t *l,tree_t *r)
{
	mpf_t fr;
	mpq_t rr;

	if(l->type!=NUMBER_NODE || r->type!=NUMBER_NODE)
		return;
	if(l->data.number.type==r->data.number.type)
		return;

	if(r->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		if(l->data.number.type==INTEGER_TYPE) {
			mpf_set_z(fr,l->data.number.data.ival);
			mpz_clear(l->data.number.data.ival);
		} else if(l->data.number.type==RATIONAL_TYPE) {
			mpf_set_q(fr,l->data.number.data.rval);
			mpq_clear(l->data.number.data.rval);
		}
		mpf_init_set(l->data.number.data.fval,fr);
		l->data.number.type=FLOAT_TYPE;
		mpf_clear(fr);
	} else if(l->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		if(r->data.number.type==INTEGER_TYPE) {
			mpf_set_z(fr,r->data.number.data.ival);
			mpz_clear(r->data.number.data.ival);
		} else if(r->data.number.type==RATIONAL_TYPE) {
			mpf_set_q(fr,r->data.number.data.rval);
			mpq_clear(r->data.number.data.rval);
		}
		mpf_init_set(r->data.number.data.fval,fr);
		r->data.number.type=FLOAT_TYPE;
		mpf_clear(fr);
	} else if(r->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr); /*l is for sure integer!*/
		mpq_set_z(rr,l->data.number.data.ival);
		mpz_clear(l->data.number.data.ival);
		mpq_init(l->data.number.data.rval);
		mpq_set(l->data.number.data.rval,rr);
		l->data.number.type=RATIONAL_TYPE;
		mpq_clear(rr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr); /*r is for sure integer!*/
		mpq_set_z(rr,r->data.number.data.ival);
		mpz_clear(r->data.number.data.ival);
		mpq_init(r->data.number.data.rval);
		mpq_set(r->data.number.data.rval,rr);
		r->data.number.type=RATIONAL_TYPE;
		mpq_clear(rr);
	}
}

tree_t *
plusop(tree_t *l,tree_t *r)
{
	mpz_t ir;
	mpf_t fr;
	mpq_t rr;
	tree_t *n;

	makesame(l,r);

	/*if l is something so is r!*/
	if(l->data.number.type==INTEGER_TYPE) {
		mpz_init(ir);
		mpz_add(ir,l->data.number.data.ival,
			r->data.number.data.ival);
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	} else if(l->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		mpf_add(fr,l->data.number.data.fval,
			r->data.number.data.fval);
		n=makenum(FLOAT_TYPE,(void *)(&fr));
		mpf_clear(fr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr);
		mpq_add(rr,l->data.number.data.rval,
			r->data.number.data.rval);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	}
	return n;
}

tree_t *
minusop(tree_t *l,tree_t *r)
{
	mpz_t ir;
	mpf_t fr;
	mpq_t rr;
	tree_t *n;

	makesame(l,r);

	/*if l is something so is r!*/
	if(l->data.number.type==INTEGER_TYPE) {
		mpz_init(ir);
		mpz_sub(ir,l->data.number.data.ival,
			r->data.number.data.ival);
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	} else if(l->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		mpf_sub(fr,l->data.number.data.fval,
			r->data.number.data.fval);
		n=makenum(FLOAT_TYPE,(void *)(&fr));
		mpf_clear(fr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr);
		mpq_sub(rr,l->data.number.data.rval,
			r->data.number.data.rval);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	}
	return n;
}

tree_t *
mulop(tree_t *l,tree_t *r)
{
	mpz_t ir;
	mpf_t fr;
	mpq_t rr;
	tree_t *n;

	makesame(l,r);

	/*if l is something so is r!*/
	if(l->data.number.type==INTEGER_TYPE) {
		mpz_init(ir);
		mpz_mul(ir,l->data.number.data.ival,
			r->data.number.data.ival);
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	} else if(l->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		mpf_mul(fr,l->data.number.data.fval,
			r->data.number.data.fval);
		n=makenum(FLOAT_TYPE,(void *)(&fr));
		mpf_clear(fr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr);
		mpq_mul(rr,l->data.number.data.rval,
			r->data.number.data.rval);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	}
	return n;
}

tree_t *
divop(tree_t *l,tree_t *r)
{
	mpf_t fr;
	mpq_t rr;
	tree_t *n;

	makesame(l,r);
	/*fixme check for 0 denominator!!!!*/

	/*if l is something so is r!*/
	if(l->data.number.type==INTEGER_TYPE) {
		if(mpz_sgn(r->data.number.data.ival)==0) {
			g_warning("Division by zero! Ignoring!");
			return NULL;
		}
		mpq_init(rr);
		mpq_set_z(rr,l->data.number.data.ival);
		mpz_set(mpq_denref(rr),r->data.number.data.ival);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	} else if(l->data.number.type==FLOAT_TYPE) {
		if(mpf_sgn(r->data.number.data.fval)==0) {
			g_warning("Division by zero! Ignoring!");
			return NULL;
		}
		mpf_init(fr);
		mpf_div(fr,l->data.number.data.fval,
			r->data.number.data.fval);
		n=makenum(FLOAT_TYPE,(void *)(&fr));
		mpf_clear(fr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		if(mpq_sgn(r->data.number.data.rval)==0) {
			g_warning("Division by zero! Ignoring!");
			return NULL;
		}
		mpq_init(rr);
		mpq_div(rr,l->data.number.data.rval,
			r->data.number.data.rval);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	}
	return n;
}

tree_t *
negop(tree_t *r)
{
	mpz_t ir;
	mpf_t fr;
	mpq_t rr;
	tree_t *n;

	if(r->data.number.type==INTEGER_TYPE) {
		mpz_init(ir);
		mpz_neg(ir,r->data.number.data.ival);
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	} else if(r->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		mpf_neg(fr,r->data.number.data.fval);
		n=makenum(FLOAT_TYPE,(void *)(&fr));
		mpf_clear(fr);
	} else if(r->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr);
		mpq_neg(rr,r->data.number.data.rval);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	}
	return n;
}

tree_t *
expop(tree_t *l, tree_t *r)
{
	g_warning("Can't yet do exponantiation! Ignoring!");
	return NULL;
	
/*	mpz_t ir;
	mpf_t fr;
	mpq_t rr;
	tree_t *n;

	if(r->data.number.type==RATIONAL_TYPE) {
		mpf_init(fr);
		mpf_set_q(fr,r->data.number.data.rval);
		r->data.number.type=FLOAT_TYPE;
		mpf_init_set(r->data.number.data.fval,fr);
		mpf_clear(fr);
	}
	if(l->data.number.type==RATIONAL_TYPE &&
		r->data.number.type==INTEGER_TYPE) {
		if(mpz_sgn(r->data.number.data.ival)==-1) {
			mpf_init(fr);
			mpf_set_q(fr,l->data.number.data.rval);
			l->data.number.type=FLOAT_TYPE;
			mpf_init_set(l->data.number.data.fval,fr);
			mpf_clear(fr);
		} else if(mpz_cmp_ui(l->data.number.data.ival,ULONG_MAX)>0) {
			mpf_init(fr);
			mpf_set_q(fr,l->data.number.data.rval);
			l->data.number.type=FLOAT_TYPE;
			mpf_init_set(l->data.number.data.fval,fr);
			mpf_clear(fr);
		}
		mpz_init(ir);
		mpz_pow_ui(ir,l->data.number.data.ival,
			r->data.number.data.ival);
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	}

	makesame(l,r);

	if(l->data.number.type==INTEGER_TYPE) {
		mpz_init(ir);
		mpz_mul(ir,l->data.number.data.ival,
			r->data.number.data.ival);
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	} else if(l->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		mpf_mul(fr,l->data.number.data.fval,
			r->data.number.data.fval);
		n=makenum(FLOAT_TYPE,(void *)(&fr));
		mpf_clear(fr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr);
		mpq_mul(rr,l->data.number.data.rval,
			r->data.number.data.rval);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	}
	return n;*/
}

tree_t *
factop(tree_t *l)
{
	mpz_t ir;
	tree_t *n;

	if(l->data.number.type==INTEGER_TYPE) {
		if(mpz_sgn(l->data.number.data.ival)==-1) {
			g_warning("Can't do factorials of negative numbers!"
				" Ignoring!");
			return NULL;
		}
		if(mpz_cmp_ui(l->data.number.data.ival,ULONG_MAX)>0) {
			g_warning("Number too large to compute factorial!"
				" Ignoring!");
			return NULL;
		}
		mpz_init(ir);
		mpz_fac_ui(ir,mpz_get_ui(l->data.number.data.ival));
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	} else {
		g_warning("Can't do factorials of rationals or floats!"
				" Ignoring!");
		return NULL;
	}
	return n;
}
