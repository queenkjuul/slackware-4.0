/* GnomENIUS Calculator
 * Copyright (C) 1997 George Lebl.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <glib.h>

#include "calc.h"
#include "eval.h"
#include "util.h"

int yyparse(void);

extern FILE *yyin;
extern char *yytext;

/* stack ... has to be global:-( */
tree_t *tstack[256/*MAX_STACK*/];
int tstackp=-1;

/*error .. global as well*/
error_t error_num;


/*formats a floating point with mantissa in p and exponent in e*/
char *
formatfloat(char *p,long int e)
{
	long int len;
	int i;
	if((e-1)<-8 || (e-1)>8) {
		p=my_realloc(p,strlen(p)+1,
			strlen(p)+1+((int)log10(abs(e))+2)+1);
		if(p[0]=='-') {
			shiftstr(p+2,1);
			p[2]='.';
		} else {
			shiftstr(p+1,1);
			p[1]='.';
		}
		sprintf(p,"%se%ld",p,e-1);
	} else if(e>0) {
		len=strlen(p);
		if(p[0]=='-')
			len--;
		if(e>len) {
			p=my_realloc(p,strlen(p)+1,
				strlen(p)+1+e-len);
			for(i=0;i<e-len;i++)
				strcat(p,"0");
		} else if(e<len) {
			if(p[0]=='-') {
				shiftstr(p+1+e,1);
				p[e+1]='.';
			} else {
				shiftstr(p+e,1);
				p[e]='.';
			}
		}
	} else { /*e<=0*/
		p=my_realloc(p,strlen(p)+1,
			strlen(p)+1+(-e)+2);
		if(p[0]=='-') {
			shiftstr(p+1,2+(-e));
			p[1]='0';
			p[2]='.';
			for(i=0;i<(-e);i++)
				p[i+3]='0';
		} else {
			shiftstr(p,2+(-e));
			p[0]='0';
			p[1]='.';
			for(i=0;i<(-e);i++)
				p[i+2]='0';
		}
	}
	return p;
}

/*make a string representation of an expression*/
char *
makeexprstr(char *s,tree_t *n)
{
	char *p,*p2;
	char tmp[20];
	long int e;

	if(!n)
		return s;
	
	if(n->type==NUMBER_NODE) {
		if(n->data.number.type==INTEGER_TYPE) {
			p=mpz_get_str(NULL,10,n->data.number.data.ival);
		} else if(n->data.number.type==FLOAT_TYPE) {
			p=mpf_get_str(NULL,&e,10,0,n->data.number.data.fval);
			p=formatfloat(p,e);
		} else { /*type==RATIONAL_TYPE*/
			p=mpz_get_str(NULL,10,
				mpq_numref(n->data.number.data.rval));
			p=appendstr(p,"/");
			p2=mpz_get_str(NULL,10,
				mpq_denref(n->data.number.data.rval));
			p=appendstr(p,p2);
			g_free(p2);
		}
		if(!s)
			return p;
		s=appendstr(s,p);
		g_free(p);
		return s;
	} else if(n->type==FUNCTION_NODE) {
		if(n->data.function.type==BUILTIN_TYPE) {
			s=appendstr(s,"(");
			s=makeexprstr(s,n->left);

			primstr(tmp,n->data.function.data.builtin);
			s=appendstr(s,tmp);

			s=makeexprstr(s,n->right);
			s=appendstr(s,")");
			return s;
		}
		/*FIXME user functions*/
	}
	s=appendstr(s,"(???)");
	return s;
}

char *
evalexp(char * str, notation_t not)
{
	int fd[2];
	char * p;

	error_num=NO_ERROR;
	
	mpf_set_default_prec(256);
	mp_set_memory_functions(g_malloc,my_realloc,my_free);

	pipe(fd);
	yyin=fdopen(fd[0],"r");

	if(not==INFIX_NOTATION)
		write(fd[1],"infix ",6);
	else if(not==POSTFIX_NOTATION)
		write(fd[1],"postfix ",8);
	else
		write(fd[1],"prefix ",7);
	write(fd[1],str,strlen(str));
	close(fd[1]);

	while(yyparse() && !feof(yyin))
		;

	close(fd[0]);

	/*catch parsing errors*/
	if(error_num!=NO_ERROR) {
		while(tstackp>-1)
			freetree(t_pop(tstack,&tstackp));
		return NULL;
	}

	/*stack is supposed to have only ONE entry*/
	if(tstackp!=0) {
		while(tstackp>-1)
			freetree(t_pop(tstack,&tstackp));
		g_warning("ERROR, Probably corrupt stack!");
		return NULL;
	}

	tstack[0]=evalnode(tstack[0]);

	/*catch evaluation errors*/
	if(error_num!=NO_ERROR) {
		while(tstackp>-1)
			freetree(t_pop(tstack,&tstackp));
		return NULL;
	}

	p=makeexprstr(NULL,tstack[0]);

	freetree(t_pop(tstack,&tstackp));

	return p;
}

void
yyerror(char *s)
{
	g_warning("ERROR: %s at '%s'",s,yytext);
	error_num=PARSE_ERROR;
}
