/* GnomENIUS Calculator
 * Copyright (C) 1997 George Lebl.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <gmp.h>
#include <glib.h>
#include "eval.h"

/*returns 1 or 2 depending if the operation has one or two
branches*/
int
branches(int op)
{
	switch(op) {
		case E_PLUS: return 2;
		case E_MINUS: return 2;
		case E_MUL: return 2;
		case E_DIV: return 2;
		case E_NEG: return 1;
		case E_EXP: return 2;
		case E_FACT: return 1;
	}
	return 0;
}

tree_t *
makenum(num_type_t type, void * num)
{
	tree_t *n;
	n=(tree_t *)g_malloc(sizeof(tree_t));
	n->type=NUMBER_NODE;
	n->data.number.type=type;
	if(type==INTEGER_TYPE)
		mpz_init_set(n->data.number.data.ival,
			*(mpz_t *)num);
	else
		mpf_init_set(n->data.number.data.fval,
			*(mpf_t *)num);
	n->left=NULL;
	n->right=NULL;
	return n;
}

tree_t *
makefuncb(int func,tree_t *stack[],int *stackp)
{
	tree_t *n;
	n=(tree_t *)g_malloc(sizeof(tree_t));
	n->type=FUNCTION_NODE;
	n->data.function.type=BUILTIN_TYPE;
	n->data.function.data.builtin=func;
	if(branches(func)==2)
		n->right=t_pop(stack,stackp);
	else
		n->right=NULL;
	n->left=t_pop(stack,stackp);
	return n;
}

int
t_push(tree_t *n,tree_t *stack[],int *stackp)
{
	stack[++(*stackp)]=n;
	return TRUE;
}

tree_t *
t_pop(tree_t *stack[],int *stackp)
{
	if(*stackp==-1)
		return NULL;
	else
		return stack[(*stackp)--];
}

void
freenode(tree_t *n)
{
	if(!n)
		return;
	if(n->type==NUMBER_NODE) {
		if(n->data.number.type==INTEGER_TYPE)
			mpz_clear(n->data.number.data.ival);
		else
			mpf_clear(n->data.number.data.fval);
	} else
		if(n->data.function.type==USER_TYPE)
			g_free(n->data.function.data.user);
}

void
freetree(tree_t *n)
{
	if(n->left)
		freetree(n->left);
	if(n->right)
		freetree(n->right);
	freenode(n);
}

/*evaluate a treenode, the treenode will become a number node*/
/*or at least all the calculatable parts will be calculated so*/
/*it will be a reduced tree*/
/*the tree will be freed*/
tree_t *
evalnode(tree_t *n)
{
	tree_t *r=NULL;
	if(n==NULL)
		return NULL;
	if(n->type==NUMBER_NODE)
		return n;

	n->right=evalnode(n->right);
	n->left=evalnode(n->left);
	if((n->right!=NULL && n->right->type!=NUMBER_NODE) ||
		(n->left!=NULL && n->left->type!=NUMBER_NODE))
		return n;
	if(n->data.function.type!=BUILTIN_TYPE) /*FIXME: user functions*/
		return n;
	switch(n->data.function.data.builtin) {
		case E_PLUS: r=plusop(n->left,n->right); break;
		case E_MINUS: r=minusop(n->left,n->right); break;
		case E_MUL: r=mulop(n->left,n->right); break;
		case E_DIV: r=divop(n->left,n->right); break;
		case E_NEG: r=negop(n->left); break;
		case E_EXP: r=expop(n->left,n->right); break;
		case E_FACT: r=factop(n->left); break;
	}
	if(r!=NULL) {
		freetree(n);
		return r;
	}
	g_warning("ERROR: NO RESULT!!!");
	/*something errored out*/
	return n;
}

/*make both number nodes the same type*/
void
makesame(tree_t *l,tree_t *r)
{
	mpf_t fr;
	mpq_t rr;

	if(l->type!=NUMBER_NODE || r->type!=NUMBER_NODE)
		return;
	if(l->data.number.type==r->data.number.type)
		return;

	if(r->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		if(l->data.number.type==INTEGER_TYPE) {
			mpf_set_z(fr,l->data.number.data.ival);
			mpz_clear(l->data.number.data.ival);
		} else if(l->data.number.type==RATIONAL_TYPE) {
			mpf_set_q(fr,l->data.number.data.rval);
			mpq_clear(l->data.number.data.rval);
		}
		mpf_init_set(l->data.number.data.fval,fr);
		l->data.number.type=FLOAT_TYPE;
		mpf_clear(fr);
	} else if(l->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		if(r->data.number.type==INTEGER_TYPE) {
			mpf_set_z(fr,r->data.number.data.ival);
			mpz_clear(r->data.number.data.ival);
		} else if(r->data.number.type==RATIONAL_TYPE) {
			mpf_set_q(fr,r->data.number.data.rval);
			mpq_clear(r->data.number.data.rval);
		}
		mpf_init_set(r->data.number.data.fval,fr);
		r->data.number.type=FLOAT_TYPE;
		mpf_clear(fr);
	} else if(r->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr); /*l is for sure integer!*/
		mpq_set_z(rr,l->data.number.data.ival);
		mpz_clear(l->data.number.data.ival);
		mpq_init(l->data.number.data.rval);
		mpq_set(l->data.number.data.rval,rr);
		l->data.number.type=RATIONAL_TYPE;
		mpq_clear(rr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr); /*r is for sure integer!*/
		mpq_set_z(rr,r->data.number.data.ival);
		mpz_clear(r->data.number.data.ival);
		mpq_init(r->data.number.data.rval);
		mpq_set(r->data.number.data.rval,rr);
		r->data.number.type=RATIONAL_TYPE;
		mpq_clear(rr);
	}
}

tree_t *
plusop(tree_t *l,tree_t *r)
{
	mpz_t ir;
	mpf_t fr;
	mpq_t rr;
	tree_t *n;

	makesame(l,r);

	/*if l is something so is r!*/
	if(l->data.number.type==INTEGER_TYPE) {
		mpz_init(ir);
		mpz_add(ir,l->data.number.data.ival,
			r->data.number.data.ival);
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	} else if(l->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		mpf_add(fr,l->data.number.data.fval,
			r->data.number.data.fval);
		n=makenum(FLOAT_TYPE,(void *)(&fr));
		mpf_clear(fr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr);
		mpq_add(rr,l->data.number.data.rval,
			r->data.number.data.rval);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	}
	return n;
}

tree_t *
minusop(tree_t *l,tree_t *r)
{
	mpz_t ir;
	mpf_t fr;
	mpq_t rr;
	tree_t *n;

	makesame(l,r);

	/*if l is something so is r!*/
	if(l->data.number.type==INTEGER_TYPE) {
		mpz_init(ir);
		mpz_sub(ir,l->data.number.data.ival,
			r->data.number.data.ival);
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	} else if(l->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		mpf_sub(fr,l->data.number.data.fval,
			r->data.number.data.fval);
		n=makenum(FLOAT_TYPE,(void *)(&fr));
		mpf_clear(fr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr);
		mpq_sub(rr,l->data.number.data.rval,
			r->data.number.data.rval);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	}
	return n;
}

tree_t *
mulop(tree_t *l,tree_t *r)
{
	mpz_t ir;
	mpf_t fr;
	mpq_t rr;
	tree_t *n;

	makesame(l,r);

	/*if l is something so is r!*/
	if(l->data.number.type==INTEGER_TYPE) {
		mpz_init(ir);
		mpz_mul(ir,l->data.number.data.ival,
			r->data.number.data.ival);
		n=makenum(INTEGER_TYPE,(void *)(&ir));
		mpz_clear(ir);
	} else if(l->data.number.type==FLOAT_TYPE) {
		mpf_init(fr);
		mpf_mul(fr,l->data.number.data.fval,
			r->data.number.data.fval);
		n=makenum(FLOAT_TYPE,(void *)(&fr));
		mpf_clear(fr);
	} else if(l->data.number.type==RATIONAL_TYPE) {
		mpq_init(rr);
		mpq_mul(rr,l->data.number.data.rval,
			r->data.number.data.rval);
		n=makenum(RATIONAL_TYPE,(void *)(&rr));
		mpq_clear(rr);
	}
	return n;
}

tree_t *
divop(tree_t *l,tree_t *r)
{
	return NULL;
}

tree_t *
negop(tree_t *l)
{
	return NULL;
}

tree_t *
expop(tree_t *l, tree_t *r)
{
	return NULL;
}

tree_t *
factop(tree_t *l)
{
	return NULL;
}
