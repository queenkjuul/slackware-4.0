/* GnomENIUS Calculator
 * Copyright (C) 1997 George Lebl.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <glib.h>

#include "parser.h"
#include "eval.h"
#include "genius.h"

int yyparse(void);

extern FILE *yyin;
extern char *yytext;

/* stack ... has to be global:-( */
tree_t *tstack[256/*MAX_STACK*/];
int tstackp=-1;

/*error .. global as well*/
int error_num;

/*simple realloc/free functions using g_malloc/g_free confogming to gmp*/
void *
my_realloc(void *ptr,size_t olds,size_t news)
{
	void *p;
	p=g_malloc(news);
	if(news<olds)
		memcpy(p,ptr,news);
	else
		memcpy(p,ptr,olds);
	g_free(ptr);
	return p;
}

void
my_free(void *ptr,size_t s)
{
	g_free(ptr);
}

/*use the output function to get a string (maximally 255 chars though!)*/
char *
my_mpf_get_str(int base, size_t n_digits, mpf_t op)
{
	char *out;
	int fd[2];
	int count;

	out=(char *)g_malloc(256);
	out[255]='\0';
	pipe(fd);
	mpf_out_str(fdopen(fd[1],"w"),base,n_digits,op);
	close(fd[1]);
	count=read(fd[0],out,255);
	close(fd[0]);
	if(count==0) {
		g_free(out);
		return NULL;
	}
	out=my_realloc(out,256,count+1);
	out[count]='\0';
	return out;
}


char *
evalexp(char * str, notation_t not)
{
	int fd[2];
	char * p;

	error_num=0;
	
	mpf_set_default_prec(256);
	mp_set_memory_functions(g_malloc,my_realloc,my_free);

	pipe(fd);
	yyin=fdopen(fd[0],"r");

	if(not==INFIX_NOTATION)
		write(fd[1],"infix ",6);
	else if(not==POSTFIX_NOTATION)
		write(fd[1],"postfix ",8);
	else
		write(fd[1],"prefix ",7);
	write(fd[1],str,strlen(str));
	close(fd[1]);

	do {
		yyparse();
	} while(!feof(yyin));

	close(fd[0]);

	if(error_num)
		return NULL;

	tstack[0]=evalnode(tstack[0]);

	if(tstackp!=0 || tstack[0]->type!=NUMBER_NODE) {
		g_warning("ERROR, Unevaluatable expression!");
		return NULL;
	}

	if(tstack[0]->data.number.type==INTEGER_TYPE) {
		p=mpz_get_str(NULL,10,tstack[0]->data.number.data.ival);
	} else if(tstack[0]->data.number.type==FLOAT_TYPE) {
		p=my_mpf_get_str(10,0,tstack[0]->data.number.data.fval);
	} else {
		p=NULL;
	}
	t_pop(tstack,&tstackp);

	return p;
}

int
yyerror(char *s)
{
	g_warning("ERROR: %s at '%s'",s,yytext);
	error_num=1;
	return 0;
}
