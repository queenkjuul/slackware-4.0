/* GnomENIUS Calculator
 * Copyright (C) 1997 George Lebl.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>

#include <string.h>
#include <stdlib.h>

#include "genius.h"
#include "calc.h"
#include "util.h"

/*Globals:*/

/*calculator state*/
/*static char * last_answer="0";*/
static notation_t notation=INFIX_NOTATION;
static int exactans=FALSE;
static int mkfloatsints=TRUE;
/*static int base=10;*/
GtkWidget *history; /*history list*/
GtkWidget *scrolledwin; /*history list scrolled window*/

/* show/hide frame */
void
showhide(GtkWidget * widget, gpointer * data)
{
	char *p;
	char *label;

	gtk_label_get(GTK_LABEL(GTK_BUTTON(widget)->child),&p);
	label=(char *)g_malloc(strlen(p)+1);
	strcpy(label,p);
	if(label[strlen(label)-1]=='>') {
		gtk_widget_show(GTK_WIDGET(data));
		label[strlen(label)-2]='\0';
		strcat(label,"<<");
	} else {
		gtk_widget_hide(GTK_WIDGET(data));
		label[strlen(label)-2]='\0';
		strcat(label,">>");
	}
	gtk_label_set(GTK_LABEL(GTK_BUTTON(widget)->child),label);
	g_free(label);
}

/* add the key's label to entry in data */
void
addkey(GtkWidget * widget, gpointer * data)
{
	char *p;
	char *t;
	int curpos;

	curpos=GTK_ENTRY(data)->current_pos;

	gtk_label_get(GTK_LABEL(GTK_BUTTON(widget)->child),&p);
	t=getentry((GtkWidget *)data);
	shiftstr(&t[curpos],1);
	t[curpos]=p[1];
	gtk_entry_set_text(GTK_ENTRY(data),t);
	gtk_entry_set_position(GTK_ENTRY(data),curpos+1);
	g_free(t);
}

/*is there a digit in t at pos?*/
int
isnum(char *t,int pos)
{
	if(t[pos]>='9' && t[pos]<='0')
		return TRUE;
	else
		return FALSE;
}

/*is there a letter in t at pos?*/
int
islet(char *t,int pos)
{
	if((t[pos]>='a' && t[pos]<='z') ||
		(t[pos]>='A' && t[pos]<='Z'))
		return TRUE;
	else
		return FALSE;
}

/*is there a primitive operation in t at pos?*/
int
isprim(char *t,int pos)
{
	if((t[pos]>='a' && t[pos]<='z') ||
		(t[pos]>='A' && t[pos]<='Z'))
		return TRUE;
	else
		return FALSE;
}

/*get a number from a string and make a new string (g_malloc) and 
advance pos*/
char *
getnum(char *t,int *pos)
{
	int i;
	char *p;

	if(&pos<0)
		return NULL;
	for(i=*pos;i<strlen(t);i++)
		if(isnum(t,i) || /*it may be a hex number!*/
			(t[i]=='x' && i==*pos+1 && t[*pos]=='0'))
			break;

	p=(char *)g_malloc(i-*pos+1);
	p[i-*pos]='\0';
	strncpy(p,&t[*pos],i-*pos);
	*pos=i;
	return p;
}


/* parse and evaluate the xpression and get answer and stick it down
  the history list*/
void
dorun(GtkWidget * widget, gpointer * data)
{
	char *t;
	char *o;
	GtkAdjustment *adj;

	t=getentry((GtkWidget *)data);
	if(exactans)
		o=evalexp(t,notation,0,mkfloatsints);
	else
		o=evalexp(t,notation,10,mkfloatsints);
	if(o)
		list_additem(history,t);
	g_free(t);
	if(!o)
		return;

	o=prependstr(o," =");
	list_additem(history,o);
	g_free(o);

	adj=gtk_scrolled_window_get_vadjustment(
		GTK_SCROLLED_WINDOW(scrolledwin));
	adj->value=adj->upper;
	gtk_range_set_adjustment(
		GTK_RANGE(GTK_SCROLLED_WINDOW(scrolledwin)->vscrollbar),adj);
}

/* quit */
void
destroy(GtkWidget * widget, gpointer * data)
{
	gtk_main_quit();
}

/*set notation functions*/
void
infixnot(GtkWidget * widget, gpointer * data)
{
	if(GTK_TOGGLE_BUTTON(widget)->active) notation=INFIX_NOTATION;
}
void
prefixnot(GtkWidget * widget, gpointer * data)
{
	if(GTK_TOGGLE_BUTTON(widget)->active) notation=PREFIX_NOTATION;
}
void
postfixnot(GtkWidget * widget, gpointer * data)
{
	if(GTK_TOGGLE_BUTTON(widget)->active) notation=POSTFIX_NOTATION;
}

/*option callback*/
void
optioncb(GtkWidget * widget, gpointer * data)
{
	if(GTK_TOGGLE_BUTTON(widget)->active)
		*(int *)data=TRUE;
	else
		*(int *)data=FALSE;
}

/*
 * Kind of a long main but all the gui stuff is here and that I guess
 * should be kept in one place
 */
int
main(int argc, char *argv[])
{
	GtkWidget *window;
	GtkWidget *w,*wt; /*widget temp variable*/
	GtkWidget *box,*boxm,*boxh,*boxt;
	GtkWidget *entry;
	GtkWidget *frame, *numframe, *sciframe,*optframe;
	GtkWidget *table;
	GtkTooltips *tips;


	/*numpad button labels*/
	char *numpad[5][4]={
		{" ^ "," ! "," ( "," ) "},
		{" 7 "," 8 "," 9 "," / "},
		{" 4 "," 5 "," 6 "," * "},
		{" 1 "," 2 "," 3 "," - "},
		{" 0 "," . "," ~ "," + "}
	};
	int x,y;

	gtk_init(&argc, &argv);

	/*set up the top level window*/
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_policy(GTK_WINDOW(window),1,1,1);
	gtk_window_set_title(GTK_WINDOW(window),"GnomENIUS Calculator");
	gtk_signal_connect(GTK_OBJECT(window), "destroy",
			   GTK_SIGNAL_FUNC(destroy), NULL);
	gtk_container_border_width(GTK_CONTAINER(window), 5);

	/*set up the tooltips*/
	tips=gtk_tooltips_new();


	/*the main box to put everything in*/
	boxm=gtk_vbox_new(FALSE,0);

	boxh=gtk_hbox_new(FALSE,0);

	frame=gtk_frame_new("Display");
	box=gtk_vbox_new(FALSE,0);

	scrolledwin=gtk_scrolled_window_new(NULL,NULL);
	gtk_widget_set_usize(scrolledwin,200,100);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledwin),
		GTK_POLICY_AUTOMATIC,GTK_POLICY_ALWAYS);
	gtk_box_pack_start(GTK_BOX(box),scrolledwin,TRUE,TRUE,0);
	gtk_widget_show(scrolledwin);

	history=gtk_list_new();
	gtk_container_add(GTK_CONTAINER(scrolledwin),history);
	gtk_widget_show(history);

	boxt=gtk_hbox_new(FALSE,0);
	entry=gtk_entry_new();
	gtk_box_pack_start(GTK_BOX(boxt),entry,TRUE,TRUE,0);
	gtk_widget_show(entry);
	w=gtk_button_new_with_label(" = ");
	gtk_signal_connect(GTK_OBJECT(w), "clicked",
		GTK_SIGNAL_FUNC(dorun), entry);
	gtk_box_pack_start(GTK_BOX(boxt),w,FALSE,FALSE,0);
	gtk_widget_show(w);
	gtk_box_pack_start(GTK_BOX(box),boxt,FALSE,FALSE,0);
	gtk_widget_show(boxt);



	gtk_container_add(GTK_CONTAINER(frame),box);
	gtk_widget_show(box);
	gtk_box_pack_start(GTK_BOX(boxh),frame,TRUE,TRUE,0);
	gtk_widget_show(frame);




	/*numpad*/
	numframe=gtk_frame_new("Numpad");
	table=gtk_table_new(7,6,0);
	gtk_table_set_col_spacings(GTK_TABLE(table),5);
	gtk_table_set_row_spacings(GTK_TABLE(table),5);
	for(x=0;x<4;x++) {
		for(y=0;y<5;y++) {
			w=gtk_button_new_with_label(numpad[y][x]);
			gtk_signal_connect(GTK_OBJECT(w), "clicked",
				GTK_SIGNAL_FUNC(addkey), entry);
			gtk_table_attach_defaults(GTK_TABLE(table),w,
				x+1,x+2,y+1,y+2);
			gtk_widget_show(w);
		}
	}


	gtk_container_add(GTK_CONTAINER(numframe),table);
	gtk_widget_show(table);
	gtk_box_pack_start(GTK_BOX(boxh),numframe,FALSE,FALSE,0);
	gtk_widget_show(numframe);

	/*scientific*/
	sciframe=gtk_frame_new("Scientific");
	gtk_box_pack_start(GTK_BOX(boxh),sciframe,FALSE,FALSE,0);
	/*gtk_widget_show(sciframe);*/
	


	gtk_box_pack_start(GTK_BOX(boxm),boxh,TRUE,TRUE,5);
	gtk_widget_show(boxh);



	/*options area*/
	optframe=gtk_frame_new("Options");
	box=gtk_vbox_new(FALSE,0);

	boxt=gtk_hbox_new(FALSE,0);
	wt=gtk_radio_button_new_with_label(NULL,
		"Prefix notation");
	gtk_signal_connect(GTK_OBJECT(wt), "toggled",
		   GTK_SIGNAL_FUNC(prefixnot),NULL);
	gtk_box_pack_start(GTK_BOX(boxt),wt,TRUE,TRUE,5);
	gtk_widget_show(wt);
	w=gtk_radio_button_new_with_label(
		gtk_radio_button_group(GTK_RADIO_BUTTON(wt)),
		"Infix notation");
	gtk_signal_connect(GTK_OBJECT(w), "toggled",
		   GTK_SIGNAL_FUNC(infixnot),NULL);
	gtk_box_pack_start(GTK_BOX(boxt),w,TRUE,TRUE,5);
	gtk_widget_show(w);
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(w),1);
	w=gtk_radio_button_new_with_label(
		gtk_radio_button_group(GTK_RADIO_BUTTON(wt)),
		"Postfix notation (RPN)");
	gtk_signal_connect(GTK_OBJECT(w), "toggled",
		   GTK_SIGNAL_FUNC(postfixnot),NULL);
	gtk_box_pack_start(GTK_BOX(boxt),w,TRUE,TRUE,5);
	gtk_widget_show(w);
	gtk_box_pack_start(GTK_BOX(box),boxt,FALSE,FALSE,5);
	gtk_widget_show(boxt);

	boxt=gtk_hbox_new(FALSE,0);
	w=gtk_check_button_new_with_label("Exact answers");
	gtk_signal_connect(GTK_OBJECT(w), "toggled",
		   GTK_SIGNAL_FUNC(optioncb),(gpointer *)&exactans);
	gtk_box_pack_start(GTK_BOX(boxt),w,TRUE,TRUE,5);
	gtk_widget_show(w);
	w=gtk_check_button_new_with_label("Make floats integers");
	gtk_signal_connect(GTK_OBJECT(w), "toggled",
		   GTK_SIGNAL_FUNC(optioncb),(gpointer *)&mkfloatsints);
	gtk_box_pack_start(GTK_BOX(boxt),w,TRUE,TRUE,5);
	gtk_widget_show(w);
	gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(w),1);
	gtk_box_pack_start(GTK_BOX(box),boxt,FALSE,FALSE,5);
	gtk_widget_show(boxt);

	gtk_container_add(GTK_CONTAINER(optframe),box);
	gtk_widget_show(box);
	gtk_box_pack_start(GTK_BOX(boxm),optframe,FALSE,FALSE,5);
	gtk_widget_show(optframe);

	/*action area*/
	boxh=gtk_hbox_new(FALSE,10);
	w=gtk_button_new_with_label("Numpad <<");
	gtk_signal_connect(GTK_OBJECT(w), "clicked",
			   GTK_SIGNAL_FUNC(showhide), numframe);
	gtk_box_pack_start(GTK_BOX(boxh),w,FALSE,FALSE,0);
	gtk_widget_show(w);
	w=gtk_button_new_with_label("Scientific >>");
	gtk_signal_connect(GTK_OBJECT(w), "clicked",
			   GTK_SIGNAL_FUNC(showhide), sciframe);
	gtk_box_pack_start(GTK_BOX(boxh),w,FALSE,FALSE,0);
	gtk_widget_show(w);
	w=gtk_button_new_with_label("Options <<");
	gtk_signal_connect(GTK_OBJECT(w), "clicked",
			   GTK_SIGNAL_FUNC(showhide), optframe);
	gtk_box_pack_start(GTK_BOX(boxh),w,FALSE,FALSE,0);
	gtk_widget_show(w);
	w=gtk_button_new_with_label("Quit");
	gtk_signal_connect_object(GTK_OBJECT(w), "clicked",
				  GTK_SIGNAL_FUNC(gtk_widget_destroy),
				  GTK_OBJECT(window));
	gtk_box_pack_end(GTK_BOX(boxh),w,FALSE,FALSE,0);
	gtk_widget_show(w);
	gtk_box_pack_start(GTK_BOX(boxm),boxh,FALSE,FALSE,5);
	gtk_widget_show(boxh);

	gtk_container_add(GTK_CONTAINER(window), boxm);
	gtk_widget_show(boxm);

	gtk_widget_show(window);

	gtk_main();

	return 0;
}
