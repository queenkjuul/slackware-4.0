/* Risk! for Linux..
 * util.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#include <gtk/gtk.h>

void copy_gdk_color(GdkColor *dest, GdkColor *source);
GtkWidget *gtk_dialog_new_no_separator();

