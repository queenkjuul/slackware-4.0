/* Risk! for Linux..
 * newgame.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#ifndef __NEWGAME_H__
#define __NEWGAME_H__

#include <gtk/gtk.h>

GtkWidget *new_game_dialog();
void new_game_cmd_callback(GtkWidget *widget, gpointer data);

#endif /* __NEWGAME_H__ */

