/* Risk! for Linux..
 * toolbar.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#include <gtk/gtk.h>

/* Use the coordinate display? */
/* #define COORDS_STATUS_BAR */

void set_status(char *new_label);
void set_country_status(char *new_label);
#ifdef COORDS_STATUS_BAR
void set_coords(int x, int y);
#endif
GtkWidget *toolbar_create();
GtkWidget *statusbar_create();

