/* Risk! for Linux..
 * game.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#ifndef __GAME_H__
#define __GAME_H__

#include <gtk/gtk.h>

void new_game_cmd_callback(GtkWidget *widget, gpointer data);
void start_game();
void place_army(int country);
void attack(int from, int to);
void fortify(int from, int to);
void country_click(GtkWidget *widget, int country); // Clicked on a country

#endif /* __GAME_H__ */

