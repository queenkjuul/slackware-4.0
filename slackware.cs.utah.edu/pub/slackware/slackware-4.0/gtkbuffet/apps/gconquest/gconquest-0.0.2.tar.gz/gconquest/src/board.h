/* Risk! for Linux..
 * board.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#include <gtk/gtk.h>

GtkWidget *board_new(GtkWidget *parent);
GdkPixmap *get_board_pixmap();
void draw_country_color(GtkWidget *widget, int country, int r, int g, int b);
void change_country_color(GtkWidget *widget, int country, int r, int g, int b);

