/* Risk! for Linux..
 * board_xpm.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#include <gtk/gtk.h>

GdkPixmap *BoardPixmap = NULL; // Points to the board's pixmap ...
GdkPixmap *BoardBackup = NULL; // Points to backup of the board's pixmap ...

GdkPixmap *create_board_pixmap(GtkWidget *parent) {
  #include "board.xpm"
  GtkStyle *style;
  GdkPixmap *board;
//  GdkBitmap *mask;

  style = gtk_widget_get_style(parent);
  BoardPixmap = gdk_pixmap_create_from_xpm_d (parent->window, NULL, NULL,
                                    (gchar **)board_xpm);
  BoardBackup = gdk_pixmap_create_from_xpm_d (parent->window, NULL, NULL,
                                    (gchar **)board_xpm);
}
