#include <gtk/gtk.h>
#include <stdio.h>

main(int argc, char **argv) {
  GtkWidget *window;
  GdkFont *font;

  gtk_init(&argc, &argv);

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_show(window);
  font = gdk_font_load("-*-blippo-*-*-*-*-20-*-*-*-*-*-*-*");
  gdk_draw_string(window->window, font, window->style->black_gc, 10, 50, "Hello World");
  gtk_main();
}

