/* Risk! for Linux..
 * game.c
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#include "gamedefs.h"
#include "game.h"

void country_click(GtkWidget *widget, int country) {
  if (country == -1) return;
  Countries[country].num_armies++;
}

void start_game() {

}

void place_army(int country);
void attack(int from, int to);
void fortify(int from, int to);
