/* Risk! for Linux..
 * util.c
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#include <gtk/gtk.h>

void copy_gdk_color(GdkColor *dest, GdkColor *source) {
  dest->pixel = source->pixel;
  dest->red = source->red;
  dest->green = source->green;
  dest->blue = source->blue;
}

GtkWidget *gtk_dialog_new_no_separator() {
  GtkWidget *dialog;
  GList *dialog_contents;

  dialog = gtk_dialog_new();
  dialog_contents = gtk_container_children(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox));
  gtk_container_remove(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox),
                       (GtkWidget *)(dialog_contents->data));

  return dialog;
}

