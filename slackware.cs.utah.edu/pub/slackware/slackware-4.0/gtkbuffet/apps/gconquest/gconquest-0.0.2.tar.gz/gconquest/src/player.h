/* Risk! for Linux..
 * player.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#ifndef __PLAYER_H__
#define __PLAYER_H__


#endif /* __PLAYER_H__ */

