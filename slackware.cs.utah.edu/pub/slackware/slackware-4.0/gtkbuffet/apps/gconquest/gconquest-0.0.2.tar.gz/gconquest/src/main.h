/* Risk! for Linux..
 * main.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#ifndef __MAIN_H__
#define __MAIN_H__

void file_quit_cmd_callback(GtkWidget *widget, gpointer data);
void about_box_cmd_callback(GtkWidget *widget, gpointer data);

#endif /* __MAIN_H__ */

