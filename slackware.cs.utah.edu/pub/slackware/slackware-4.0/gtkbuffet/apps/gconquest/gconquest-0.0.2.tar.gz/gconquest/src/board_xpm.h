/* Risk! for Linux..
 * board_xpm.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

#ifndef __BOARD_XPM_H__
#define __BOARD_XPM_H__

GdkPixmap *create_board_pixmap();	// Create board and set pointer

#endif /* __BOARD_XPM_H__ */

