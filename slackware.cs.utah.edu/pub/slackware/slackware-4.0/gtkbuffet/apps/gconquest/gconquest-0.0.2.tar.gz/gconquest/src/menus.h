/* Risk! for Linux..
 * menu.h
 *
 * Copyright (C) 1998 Joel Nordell
 *
 * This file is protected under the GPL license.
 */

     #ifndef __MENUS_H__
     #define __MENUS_H__

     #ifdef __cplusplus
     extern "C" {
     #endif /* __cplusplus */

     void get_main_menu (GtkWidget **menubar, GtkAcceleratorTable **table);
     void menus_create(GtkMenuEntry *entries, int nmenu_entries);

     #ifdef __cplusplus
     }
     #endif /* __cplusplus */

     #endif /* __MENUS_H__ */
