/* GTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
#include <gtk/gtkmain.h>
#include <gtk/gtksignal.h>
#include "pkfont.h"
#include "gtkdvi.h"
#include <math.h>

/*
 * Warning, black magic further ahead. (DVI renderer.)
 */

/* The default font size in dpi. */
#define DEFAULT_DPI 600

/* Forward declarations. */
static void gtk_dvi_class_init (GtkDviClass *class);
static void gtk_dvi_init (GtkDvi *dvi);
static void gtk_dvi_destroy (GtkObject *object);
static void gtk_dvi_realize (GtkWidget *widget);
static void gtk_dvi_size_request (GtkWidget      *widget,
				  GtkRequisition *requisition);
static void gtk_dvi_size_allocate (GtkWidget     *widget,
				   GtkAllocation *allocation);
static int gtk_dvi_expose (GtkWidget      *widget,
			   GdkEventExpose *event);
static void gtk_dvi_update_pixmap (GtkDvi *dvi);
static gboolean DVI_load( GtkDvi *dvi );
static void DVI_destroy( GtkDvi *dvi );
static void DVI_draw_to_pixmap( GtkDvi *dvi, GdkPixmap *pmap, 
				gint zoom, gint x1, gint y1, gint x2, gint y2);

static GtkWidgetClass *parent_class = NULL;

guint
gtk_dvi_get_type ()
{
  static guint dvi_type = 0;
  
  if ( ! dvi_type )
    {
      GtkTypeInfo dvi_info = 
      {
	"GtkDvi",
	sizeof (GtkDvi),
	sizeof (GtkDviClass),
	(GtkClassInitFunc) gtk_dvi_class_init,
	(GtkObjectInitFunc) gtk_dvi_init,
	(GtkArgSetFunc) NULL,
	(GtkArgGetFunc) NULL,
      };

      dvi_type = gtk_type_unique (gtk_widget_get_type (), &dvi_info);
    }

  return dvi_type;
}

static void
gtk_dvi_class_init (GtkDviClass *class)
{
  GtkObjectClass *object_class;
  GtkWidgetClass *widget_class;

  object_class = (GtkObjectClass*) class;
  widget_class = (GtkWidgetClass*) class;

  parent_class = gtk_type_class (gtk_widget_get_type ());
  
  object_class->destroy = gtk_dvi_destroy;

  widget_class->realize = gtk_dvi_realize;
  widget_class->expose_event = gtk_dvi_expose;
  widget_class->size_request = gtk_dvi_size_request;
  widget_class->size_allocate = gtk_dvi_size_allocate;
}

static void
gtk_dvi_init (GtkDvi *dvi)
{
  GTK_WIDGET_SET_FLAGS( GTK_WIDGET( dvi ), GTK_CAN_FOCUS );
  dvi->backing = NULL;
  dvi->file = NULL;
  dvi->zoom = GTK_DVI_DEFAULT_ZOOM;
  dvi->current_page = 0;
  dvi->ffinder = NULL;
  dvi->fonts = NULL;
  dvi->num_fonts = 0;
  dvi->pages = NULL;
  dvi->num_pages = 0;
  dvi->numerator = dvi->denominator = 0;
  dvi->magnification = 0;
  dvi->scaling = 0.0;
  dvi->maxheight = 0;
  dvi->maxwidth = 0;
  dvi->stacksize = 0;
  dvi->sp = 0;
  dvi->stack = NULL;
}

GtkWidget *
gtk_dvi_new (FILE *dvifile, PKFontFinder ffinder)
{
  GtkDvi *dvi;

  dvi = gtk_type_new (gtk_dvi_get_type ());
  dvi->ffinder = ffinder;
  dvi->file = dvifile;
  DVI_load( dvi ); /* This may fail. We don't care here. */

  return GTK_WIDGET (dvi);
}

static void
gtk_dvi_destroy (GtkObject *object)
{
  GtkDvi *dvi;

  g_return_if_fail (object != NULL);
  g_return_if_fail (GTK_IS_DVI (object));

  dvi = GTK_DVI (object);

  if (dvi->backing != NULL)
    gdk_pixmap_unref (dvi->backing);

  if (GTK_OBJECT_CLASS (parent_class)->destroy)
    (* GTK_OBJECT_CLASS (parent_class)->destroy) (object);
}

static void
gtk_dvi_realize (GtkWidget *widget)
{
  GtkDvi *dvi;
  GdkWindowAttr attributes;
  gint attributes_mask;
  
  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_DVI (widget));
  
  GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED);
  dvi = GTK_DVI (widget);
  
  attributes.x = widget->allocation.x;
  attributes.y = widget->allocation.y;
  attributes.width = widget->allocation.width;
  attributes.height = widget->allocation.height;
  attributes.wclass = GDK_INPUT_OUTPUT;
  attributes.window_type = GDK_WINDOW_CHILD;
  attributes.event_mask = gtk_widget_get_events (widget) | 
    GDK_EXPOSURE_MASK;
  attributes.visual = gtk_widget_get_visual (widget);
  attributes.colormap = gtk_widget_get_colormap (widget);
  
  attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;
  widget->window = gdk_window_new (gtk_widget_get_parent_window( widget ), 
				   &attributes, attributes_mask);
  
  widget->style = gtk_style_attach (widget->style, widget->window);
  
  gdk_window_set_user_data (widget->window, widget);
  
  gtk_style_set_background (widget->style, widget->window, GTK_STATE_ACTIVE);
}

static void 
gtk_dvi_size_request (GtkWidget      *widget,
		      GtkRequisition *requisition)
{
  gint zoom = GTK_DVI( widget )->zoom;
  requisition->width = ( GTK_DVI_DEFAULT_WIDTH * DEFAULT_DPI + 
			 zoom - 1) / ( zoom * 254 );
  requisition->height = ( GTK_DVI_DEFAULT_HEIGHT * DEFAULT_DPI + 
			  zoom - 1) / ( zoom * 254 );
  g_print( "Requested size (%d,%d).\n", requisition->width,
	   requisition->height );
}

static void
gtk_dvi_size_allocate (GtkWidget     *widget,
		       GtkAllocation *allocation)
{
  GtkDvi *dvi;
  
  g_return_if_fail (widget != NULL);
  g_return_if_fail (GTK_IS_DVI (widget));
  g_return_if_fail (allocation != NULL);
  
  if ( widget->allocation.x == allocation->x && 
       widget->allocation.y == allocation->y && 
       widget->allocation.width == allocation->width && 
       widget->allocation.height == allocation->height )
    {
      g_print( "Useless size_allocate call.\n" );
      return;
    }
  widget->allocation = *allocation;

  dvi = GTK_DVI (widget);

  if (GTK_WIDGET_REALIZED (widget))
    {  
      gdk_window_move_resize (widget->window,
			      allocation->x, allocation->y,
			      allocation->width, allocation->height);

      g_print( "Got a new size.\n" );
      /* Need to change pixmaps now. */
      gtk_dvi_update_pixmap (dvi);
    }
}

static int
gtk_dvi_expose (GtkWidget      *widget,
		GdkEventExpose *event)
{
  GtkDvi *dvi;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (GTK_IS_DVI (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  if (GTK_WIDGET_REALIZED (widget))
    {
      dvi = GTK_DVI (widget);
#ifdef PRINT_STUFF     
      g_print ("Exposed at (%d,%d) size (%d,%d).\n", event->area.x, 
	       event->area.y, event->area.width, event->area.height);
#endif
      if (!dvi->backing)
	gtk_dvi_update_pixmap (dvi);
    }
  return FALSE;
}

static void
gtk_dvi_update_pixmap (GtkDvi *dvi)
{
  GtkWidget *widget = GTK_WIDGET (dvi);

  if (GTK_WIDGET_REALIZED (widget))
    {
      if (dvi->backing)
	gdk_pixmap_unref (dvi->backing);
      dvi->backing = gdk_pixmap_new (widget->window, widget->allocation.width,
				     widget->allocation.height, -1);
      gdk_draw_rectangle (dvi->backing, widget->style->white_gc, TRUE,
			  0, 0, widget->allocation.width,
			  widget->allocation.height);

      if (dvi->file)
	{
#ifdef PRINT_STUFF
	  g_print( "Calling DVI_draw_to_pixmap.\n");
#endif
	  DVI_draw_to_pixmap( dvi, dvi->backing, 
			      dvi->zoom, 0, 0, 
			      widget->allocation.width, 
			      widget->allocation.height );
	}
      gdk_window_set_back_pixmap( widget->window, dvi->backing, 0 );
      gdk_window_clear( widget->window );
    }
  else
    {
#ifdef PRINT_STUFF
      g_print ("Can't update pixmap when not realized.\n");
#endif
    }
}

void
gtk_dvi_set_zoom (GtkDvi *dvi, gint zoom)
{
  g_return_if_fail (dvi != NULL);
  g_return_if_fail (GTK_IS_DVI (dvi));

  if (dvi->zoom != zoom && zoom >= GTK_DVI_MIN_ZOOM && 
                           zoom <= GTK_DVI_MAX_ZOOM)
    {
      dvi->zoom = zoom;
      g_print( "Zooming to %d.\n", dvi->zoom );
      gtk_widget_queue_resize (GTK_WIDGET (dvi));
    }
}

void
gtk_dvi_zoom_in (GtkDvi *dvi)
{
  g_return_if_fail (dvi != NULL);
  g_return_if_fail (GTK_IS_DVI (dvi));

  if (dvi->zoom < GTK_DVI_MAX_ZOOM)
    {
      dvi->zoom++;
      g_print( "Zooming to %d.\n", dvi->zoom );
      gtk_widget_queue_resize (GTK_WIDGET (dvi));
    }
}

void
gtk_dvi_zoom_out (GtkDvi *dvi)
{
  g_return_if_fail (dvi != NULL);
  g_return_if_fail (GTK_IS_DVI (dvi));

  if (dvi->zoom > GTK_DVI_MIN_ZOOM)
    {
      dvi->zoom--;
      g_print( "Zooming to %d.\n", dvi->zoom );
      gtk_widget_queue_resize (GTK_WIDGET (dvi));
    }
}

void
gtk_dvi_set_page (GtkDvi *dvi, gint page)
{
  g_return_if_fail (dvi != NULL);
  g_return_if_fail (GTK_IS_DVI (dvi));

  if (page >=0 && page < dvi->num_pages && page != dvi->current_page)
    {
      dvi->current_page = page;
      gtk_dvi_update_pixmap( dvi );
      gtk_widget_queue_draw( GTK_WIDGET( dvi ) );
    }
}

void
gtk_dvi_next_page (GtkDvi *dvi)
{
  g_return_if_fail (dvi != NULL);
  g_return_if_fail (GTK_IS_DVI (dvi));

  if (dvi->current_page < dvi->num_pages - 1)
    {
      dvi->current_page++;
      gtk_dvi_update_pixmap( dvi );
      gtk_widget_queue_draw( GTK_WIDGET( dvi ) );
    }
}

void gtk_dvi_prev_page (GtkDvi *dvi)
{
  g_return_if_fail (dvi != NULL);
  g_return_if_fail (GTK_IS_DVI (dvi));

  if (dvi->current_page > 0)
    {
      dvi->current_page--;
      gtk_dvi_update_pixmap( dvi );
      gtk_widget_queue_draw( GTK_WIDGET( dvi ) );
    }
}


/*
 * End of widget stuff.
 * The black magic of the DVI renderer begins ahead.
 */

#undef PRINT_STUFF

/* The DVI commands. */
#define DVI_FIRST    128
#define DVI_SET1     128
#define DVI_SET2     129
#define DVI_SET3     130
#define DVI_SET4     131
#define DVI_SETRULE  132
#define DVI_PUT1     133
#define DVI_PUT2     134
#define DVI_PUT3     135
#define DVI_PUT4     136
#define DVI_PUTRULE  137
#define DVI_NOP      138
#define DVI_BOP      139
#define DVI_EOP      140
#define DVI_PUSH     141
#define DVI_POP      142
#define DVI_RIGHT1   143
#define DVI_RIGHT2   144
#define DVI_RIGHT3   145
#define DVI_RIGHT4   146
#define DVI_W0       147
#define DVI_W1       148
#define DVI_W2       149
#define DVI_W3       150
#define DVI_W4       151
#define DVI_X0       152
#define DVI_X1       153
#define DVI_X2       154
#define DVI_X3       155
#define DVI_X4       156
#define DVI_DOWN1    157
#define DVI_DOWN2    158
#define DVI_DOWN3    159
#define DVI_DOWN4    160
#define DVI_Y0       161
#define DVI_Y1       162
#define DVI_Y2       163
#define DVI_Y3       164
#define DVI_Y4       165
#define DVI_Z0       166
#define DVI_Z1       167
#define DVI_Z2       168
#define DVI_Z3       169
#define DVI_Z4       170
#define DVI_FONTNUM0 171
/* There are 64 of these, FONTNUM0 through FONTNUMN. */
#define DVI_FONTNUMN 234
#define DVI_FNT1     235
#define DVI_FNT2     236
#define DVI_FNT3     237
#define DVI_FNT4     238
#define DVI_XXX1     239
#define DVI_XXX2     240
#define DVI_XXX3     241
#define DVI_XXX4     242
#define DVI_FNTDEF1  243
#define DVI_FNTDEF2  244
#define DVI_FNTDEF3  245
#define DVI_FNTDEF4  246
#define DVI_PRE      247
#define DVI_POST     248
#define DVI_POSTPOST 249
#define DVI_LAST     249

/* How many font pointers should we allocate at once? */
#define CHUNK_SIZE 50

typedef struct _DVIStack DVIStack;
struct _DVIStack
{
  /* Some elements here? */
  int h, hh, v, vv, w, x, y, z;
};

typedef struct _DVIFont DVIFont;
struct _DVIFont
{
  int scale;
  int designsize;
  int dpi;
  gchar *area, *name;
  PKFont *font;
};

/* A macro to access the fonts more easily. */
#define FONT(fnum) ((DVIFont *)dvi->fonts[ fnum ])
/* Ditto for the stack. */
#define STACK (((DVIStack *)dvi->stack)[ dvi->sp ])

/* A bunch of parameters that almost all routines need. */
typedef struct _DrawStatus DrawStatus;
struct _DrawStatus
{
  gint h, hh, v, vv, w, x, y, z; /* Coordinates. */
  gint f; /* Current font. */
  GdkGC **gcs; /* Various gray tones. */
  gint zoom; /* Zoom factor. */
  gint x1, y1, x2, y2; /* On-pixmap bounding box. */
  gint xoff, yoff; /* Offset to add to pixel coordinates in X and Y. */
};

static int fgetint( FILE *file )
{
  /* Shouldn't these definitions depend upon whether we're MSB or LSB? */
  return ( getc( file ) << 24 ) | ( getc( file ) << 16 ) |
    ( getc( file ) << 8 ) | ( getc( file ) );
}

static int fgetthree( FILE *file )
{
  return ( getc( file ) << 16 ) | ( getc( file ) << 8 ) | ( getc( file ) );
}

static int fgetsthree( FILE *file )
{
  return ( ((signed char)getc( file )) << 16 ) | ( getc( file ) << 8 ) |
    ( getc( file ) );
}

static int fgettwo( FILE *file )
{
  return ( getc( file ) << 8 ) | ( getc( file ) );
}

static int fgetstwo( FILE *file )
{
  return ( ((signed char)getc( file ) ) << 8 ) | ( getc( file ) );
}

static int fgetsc( FILE *file )
{
  return (signed char)getc( file );
}

static void freadn( FILE *file, int n )
{
  while ( n > 0 )
    {
      getc( file );
      n--;
    }
}

/* Load information about a DVI file. */
static gboolean DVI_load( GtkDvi *dvi )
{
  FILE *pkfile;
  int i, j, k, command, fnum, checksum, lastpage;

  if ( ! dvi->ffinder || ! dvi->file || getc( dvi->file ) != DVI_PRE || 
       getc( dvi->file ) != 2 )
    {
      fclose( dvi->file );
      dvi->file = NULL;
      return FALSE;
    }

  dvi->numerator = fgetint( dvi->file );
  dvi->denominator = fgetint( dvi->file );
  dvi->magnification = fgetint( dvi->file );
  dvi->scaling = ( dvi->numerator / 254000.0) * ( 1.0 * DEFAULT_DPI /
						  dvi->denominator );
  dvi->scaling *= dvi->magnification / 1000.0;
#ifdef PRINT_STUFF
  g_print( "Scaling factor %g.\n", dvi->scaling );
#endif
  freadn( dvi->file, getc( dvi->file ) );

  fseek( dvi->file, -5, SEEK_END );
  while ( ( i = getc( dvi->file ) ) == 223 )
    fseek( dvi->file, -2, SEEK_CUR );

  /* This should be the identification byte again. */
  if ( i != 2 )
    {
      fclose( dvi->file );
      dvi->file = NULL;
      return FALSE;
    }

  /* Go to the interesting arguments of the postamble. */
  fseek( dvi->file, -5, SEEK_CUR );
  i = fgetint( dvi->file );
  fseek( dvi->file, i + 1 , SEEK_SET );

  lastpage = fgetint( dvi->file );
  fseek( dvi->file, 12, SEEK_CUR );

  dvi->maxheight = fgetint( dvi->file );
  dvi->maxwidth = fgetint( dvi->file );
  dvi->stacksize = fgettwo( dvi->file );
  dvi->stack = g_new0( DVIStack, dvi->stacksize );
  dvi->num_pages = fgettwo( dvi->file );
  dvi->pages = g_new0( int, dvi->num_pages );

  /* Now come the font definitions. */
  command = getc( dvi->file );
  while ( command == DVI_FNTDEF1 || command == DVI_FNTDEF2 ||
	  command == DVI_FNTDEF3 || command == DVI_FNTDEF4 )
    {
      switch ( command )
	{
	case DVI_FNTDEF1:
	  fnum = getc( dvi->file );
	  break;
	case DVI_FNTDEF2:
	  fnum = fgettwo( dvi->file );
	  break;
	case DVI_FNTDEF3:
	  fnum = fgetthree( dvi->file );
	  break;
	default: /* DVI_FNTDEF4 */
	  fnum = fgetint( dvi->file );
	  break;
	}
      if ( dvi->num_fonts <= fnum )
	{
	  int newsize = fnum - dvi->num_fonts + 1;
	  if ( newsize < CHUNK_SIZE )
	    newsize = CHUNK_SIZE;
	  newsize += dvi->num_fonts;
	  dvi->fonts = g_realloc( dvi->fonts, sizeof( DVIFont * ) *
				  newsize );
	  for ( i = dvi->num_fonts; i < newsize; i++ )
	    dvi->fonts[ i ] = NULL;
	  dvi->num_fonts = newsize;
	}
#ifdef PRINT_STUFF
      g_print( "Defining font %d.\n", fnum );
#endif
      dvi->fonts[ fnum ] = g_new0( DVIFont, 1 );
      checksum = fgetint( dvi->file );
      FONT( fnum )->scale = fgetint( dvi->file );
      FONT( fnum )->designsize = fgetint( dvi->file );
      j = getc( dvi->file );
      k = getc( dvi->file );
      if ( j != 0 )
	{
	  FONT( fnum )->area = g_new0( char, j + 1 );
	  fread( FONT( fnum )->area, 1, j, dvi->file );
	}
      if ( k != 0 )
	{
	  FONT( fnum )->name = g_new0( char, k + 1 );
	  fread( FONT( fnum )->name, 1, k, dvi->file );
	}

      if ( FONT( fnum )->scale != FONT( fnum )->designsize )
	{
	  FONT( fnum )->dpi = (int)floor( 0.5 + 1.0 * DEFAULT_DPI * 
				   dvi->magnification * FONT( fnum )->scale / 
				   ( 1000.0 * FONT( fnum )->designsize));
	}
      else
	FONT( fnum )->dpi = DEFAULT_DPI;
      pkfile = dvi->ffinder( FONT( fnum )->name, FONT( fnum )->area,
			     FONT( fnum )->dpi );
      if ( ! pkfile )
	{
	  g_print( "Failed to find font.\n" );
	}
      else
	{
	  FONT( fnum )->font = PKF_load( pkfile );
	  if ( ! FONT( fnum )->font )
	    g_print( "Failed to load font.\n" );
	  else
	    {
	      /* Convert the tfm widths to dvi widths. */
	      int alpha, z, beta, b0, b1, b2, b3;
	      PKCharDef *pkchar;
	      alpha = 16;
	      z = FONT( fnum )->scale;
	      while ( z >= (1<<23) )
		{
		  z = z >> 1;
		  alpha = alpha << 1;
		}
	      beta = 256 / alpha;
	      alpha = alpha * z;
	      for ( i = 0; i < FONT( fnum )->font->allocated_chars;
		    i++ )
		{
		  pkchar = FONT( fnum )->font->chars[ i ];
		  if ( pkchar )
		    {
		      b0 = pkchar->tfm >> 24;
		      b1 = (pkchar->tfm >> 16) & 255;
		      b2 = (pkchar->tfm >> 8) & 255;
		      b3 = pkchar->tfm & 255;
		      pkchar->dviwidth = 
		       (((((b3 * z) / 256) + (b2 * z)) / 256) + (b1 * z))/beta;
		      if ( b0 > 0 )
			{
			  pkchar->dviwidth -= alpha;
			}
		    }
		}
	    }
	}

      command = getc( dvi->file );
    }

  /* Skim through the file, looking for bop commands. */
  i = dvi->num_pages - 1;
  while ( i >= 0 )
    {
      dvi->pages[ i ] = lastpage;
      fseek( dvi->file, lastpage + 41, SEEK_SET );
      lastpage = fgetint( dvi->file );
      i--;
    }

#ifdef PRINT_STUFF
  for ( i = 0; i < dvi->num_pages; i++ )
    g_print( "Page %d starts at %d.\n", i, dvi->pages[ i ] );
#endif

  return TRUE;
}

/* Unload the dvi file. */
static void DVI_destroy( GtkDvi *dvi )
{
  int i;
  DVIFont *fnt;

  g_return_if_fail( dvi != NULL );

  if ( dvi->stack )
    g_free( dvi->stack );
  dvi->stack = NULL;
  dvi->sp = 0;
  dvi->stacksize = 0;
  if ( dvi->pages )
    g_free( dvi->pages );
  dvi->pages = 0;
  for ( i = 0; i < dvi->num_fonts; i++ )
    if ( dvi->fonts[ i ] )
      {
	fnt = FONT( i );
	if ( fnt->font )
	  PKF_destroy( fnt->font );
	if ( fnt->area )
	  g_free( fnt->area );
	if ( fnt->name )
	  g_free( fnt->name );
	g_free( fnt );
      }
  if ( dvi->fonts )
    g_free( dvi->fonts );
  dvi->fonts = NULL;
  dvi->num_fonts = 0;
  fclose( dvi->file );
}

static GdkGC **make_gcs( GdkPixmap *pmap, GdkColormap *cmap, int zoom )
{
  int i, num;
  GdkGC **gcs;
  GdkColor col;
  
  num = zoom * zoom;
  gcs = g_new( GdkGC *, zoom * zoom + 1 );
  for ( i = 0; i < num + 1; i++ )
    {
      gcs[ i ] = gdk_gc_new( pmap );
      col.red = 65535 * ( num - i ) / ( num );
      /*g_print( "Color %d is %d.\n", i, col.red );*/
      col.green = col.blue = col.red;
      col.pixel = (gulong)(col.red*65536 + col.green*256 + col.blue);
      gdk_color_alloc( cmap, &col );
      gdk_gc_set_foreground( gcs[ i ], &col );
    }
  return gcs;
}

static int rule_pixels( GtkDvi *dvi, int units )
{
  int n = (int)floor( dvi->scaling * units );
  if ( n < dvi->scaling * units )
    return n + 1;
  else
    return n;
}

static void draw_rule( GdkPixmap *pmap, DrawStatus *st, 
		       int x, int y, int w, int h )
{
  int x1, x2, y1, y2;

#ifdef PRINT_STUFF
  g_print( "A rule at (%d,%d) size (%dx%d).\n", x, y, w, h );
#endif
  switch ( st->zoom )
    {
    default:
      gdk_draw_rectangle( pmap, st->gcs[ st->zoom * st->zoom ], TRUE,
			  x + st->xoff, y + st->yoff, w, h );
      break;
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
      /* Scaled rules are slightly off to the right. Dunno why. */

      /* Which rectangle should we draw in black? */
      /* Round the lower coordinates up. */
      x1 = (x + st->zoom - 1) / st->zoom;
      y1 = (y + st->zoom - 1) / st->zoom;
      /* Round the upper coordinates down. However, subtract one, to
	 go from width to coordinates... */
      x2 = (x + w - 1) / st->zoom;
      y2 = (y + h - 1) / st->zoom;
      if ( x2 >= x1 && y2 >= y1 )
	gdk_draw_rectangle( pmap, st->gcs[ st->zoom * st->zoom ], 
			    TRUE, x1 + st->xoff, y1 + st->yoff, 
			    x2 - x1 + 1, y2 - y1 + 1 );
      /* Now check out the edges, which we may have to draw in grey. */
      if ( x % st->zoom != 0 )
	{
	  if ( y2 >= y1 )
	    gdk_draw_line( pmap, 
			   st->gcs[ ( st->zoom - x % st->zoom ) * st->zoom ], 
			   x1 - 1 + st->xoff, y1 + st->yoff, 
			   x1 - 1 + st->xoff, y2 + st->yoff );
	  /* Perhaps the corner points, too? */
	  if ( y % st->zoom != 0 )
	    gdk_draw_point( pmap,
			    st->gcs[ ( st->zoom - x % st->zoom ) * 
				     ( st->zoom - y % st->zoom ) ],
			    x1 - 1 + st->xoff, y1 - 1 + st->yoff );
	  if ( ( y + h - 1 ) % st->zoom != 0 )
	    gdk_draw_point( pmap,
			    st->gcs[ ( st->zoom - x % st->zoom ) * 
				     ( ( y + h - 1 ) % st->zoom ) ],
			    x1 - 1 + st->xoff, y2 + 1 + st->yoff );
	}
      if ( ( x + w - 1 ) % st->zoom != 0 )
	{
	  if ( y2 >= y1 )
	    gdk_draw_line( pmap, 
			   st->gcs[ ( ( x + w - 1 ) % st->zoom ) * st->zoom ], 
			   x2 + 1 + st->xoff, y1 + st->yoff, 
			   x2 + 1 + st->xoff, y2 + st->yoff );
	  /* Perhaps the corner points, too? */
	  if ( y % st->zoom != 0 )
	    gdk_draw_point( pmap, 
			    st->gcs[ ( ( x + w - 1 ) % st->zoom ) * 
				     ( st->zoom - y % st->zoom ) ],
			    x2 + 1 + st->xoff, y1 - 1 + st->yoff );
	  if ( ( y + h - 1 ) % st->zoom != 0 )
	    gdk_draw_point( pmap, 
			    st->gcs[ ( ( x + w - 1 ) % st->zoom ) * 
				     ( ( y + h - 1 ) % st->zoom ) ],
			    x2 + 1 + st->xoff, y2 + 1 + st->yoff );
	}
      /* Now, the lower and upper edge. */
      if ( y % st->zoom != 0 && x2 > x1 )
	{
	  gdk_draw_line( pmap, 
			 st->gcs[ ( st->zoom - y % st->zoom ) * st->zoom ], 
			 x1 + st->xoff, y1 - 1 + st->yoff, 
			 x2 + st->xoff, y1 - 1 + st->yoff );
	}
      if ( ( y + h - 1 ) % st->zoom != 0 && x2 > x1 )
	{
	  gdk_draw_line( pmap, 
			 st->gcs[ ( ( y + h - 1 ) % st->zoom ) * st->zoom ], 
			 x1 + st->xoff, y2 + 1 + st->yoff, 
			 x2 + st->xoff, y2 + 1 + st->yoff );
	}
      break;
    }
}

static int pixel_round( GtkDvi *dvi, int val )
{
  return (int)floor( 0.5 + dvi->scaling * val );
}

#define MAX_DRIFT 2

static void adjust_h( GtkDvi *dvi, DrawStatus *st, int q )
{
  int hhh = pixel_round( dvi, st->h + q );
  if ( ABS( hhh - st->hh ) > MAX_DRIFT )
    {
      if ( hhh > st->hh )
	st->hh = hhh - MAX_DRIFT;
      else
	st->hh = hhh + MAX_DRIFT;
    }
  st->h += q;
}

static void adjust_v( GtkDvi *dvi, DrawStatus *st, int q )
{
  int vvv = pixel_round( dvi, st->v + q );
  if ( ABS( vvv - st->vv ) > MAX_DRIFT )
    {
      if ( vvv > st->vv )
	st->vv = vvv - MAX_DRIFT;
      else
	st->vv = vvv + MAX_DRIFT;
    }
  st->v += q;
}

static void out_space( GtkDvi *dvi, DrawStatus *st, int q )
{
#ifdef PRINT_STUFF
  g_print( "out_space by %d.\n", q );
#endif
  if ( ! dvi->fonts[ st->f ] || 
       q >= FONT( st->f )->font->space || 
       q <= -4 * FONT( st->f )->font->space )
    st->hh = pixel_round( dvi, st->h + q );
  else
    st->hh += pixel_round( dvi, q );
  adjust_h( dvi, st, q );
}

static void out_vmove( GtkDvi *dvi, DrawStatus *st, int q )
{
#ifdef PRINT_STUFF
  g_print( "out_vmove by %d.\n", q );
#endif
  if ( ! dvi->fonts[ st->f ] ||
       ABS( q ) >= 5 * FONT( st->f )->font->space )
    st->vv = pixel_round( dvi, st->v + q );
  else
    st->vv += pixel_round( dvi, q );
  adjust_v( dvi, st, q );
}

static void put_char( GtkDvi *dvi, DrawStatus *st, int cc, GdkPixmap *pmap )
{
  int x, y, i, j, k, l, w, h, val, xoff, yoff;
  PKCharDef *pkchar;

  if ( ! dvi->fonts[ st->f ] )
    {
      g_print( "No valid font selected.\n" );
      return;
    }

  if ( cc >= FONT( st->f )->font->allocated_chars ||
       ! FONT( st->f )->font->chars[ cc ] )
    {
      g_print( "Not a defined character.\n" );
      return;
    }

  pkchar = PKF_get_char( FONT( st->f )->font, cc );
  /* Adjust for offset of hot pixel. */
  switch ( st->zoom )
    {
    default:
      x = st->hh - pkchar->hoff;
      y = st->vv - pkchar->voff;
      w = st->hh - pkchar->hoff + pkchar->width;  
      h = st->vv - pkchar->voff + pkchar->height;
      break;
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
      x = ( st->hh - pkchar->hoff ) / st->zoom;
      y = ( st->vv - pkchar->voff ) / st->zoom;
      w = ( st->hh - pkchar->hoff + pkchar->width + st->zoom - 1)/st->zoom;
      h = ( st->vv - pkchar->voff + pkchar->height + st->zoom - 1)/st->zoom;
      break;
    }

#ifdef PRINT_STUFF
  g_print( "Putting character %d at (%d,%d).\n", cc, x, y );
#endif

  if ( x > st->x2 || y > st->y2 || w < st->x1 || h < st->y1 )
    return; /* Outside exposed area. */

  switch ( st->zoom )
    {
    default: /* 1 or anything else not listed above. */
      /* Loop over the whole grid. */
      for ( i = 0; i < pkchar->width; i++ )
	{
	  for ( j = 0; j < pkchar->height; j++ )
	    {
	      if ( pkchar->pixels[ j * pkchar->width + i ] )
		{
		  /* Draw a pixel! */
		  gdk_draw_point( pmap, st->gcs[ st->zoom * st->zoom],
				  x + i + st->xoff, y + j + st->yoff );
		}
	    }
	}
      break;
    case 2:
      xoff = ( st->hh - pkchar->hoff ) % 2;
      yoff = ( st->vv - pkchar->voff ) % 2;
      for ( i = 0; i < ( pkchar->width + 1 + xoff ) / 2; i++ )
	{
	  for ( j = 0; j < ( pkchar->height + 1 + yoff ) / 2; j++ )
	    {
	      val = 0;
	      if ( i*2 - xoff >= 0 )
		{
		  if ( j*2 - yoff >= 0 )
		    {
		      val += pkchar->pixels[ (j*2-yoff) * pkchar->width + 
					     i*2-xoff ];
		    }
		  if ( j*2 - yoff + 1 < pkchar->height )
		    {
		      val += pkchar->pixels[ (j*2-yoff+1) * pkchar->width + 
					     i*2-xoff ];
		    }
		}
	      if ( i*2 - xoff + 1 < pkchar->width )
		{
		  if ( j*2 - yoff >= 0 )
		    {
		      val += pkchar->pixels[ (j*2-yoff) * pkchar->width + 
					     i*2-xoff+1 ];
		    }
		  if ( j*2 - yoff + 1 < pkchar->height )
		    {
		      val += pkchar->pixels[ (j*2-yoff+1) * pkchar->width + 
					     i*2-xoff+1 ];
		    }
		}
	      if ( val )
		gdk_draw_point( pmap, st->gcs[ val ], 
				x + i + st->xoff, y + j + st->yoff );
	    }
	}
      break;
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
      xoff = st->zoom - ( st->hh - pkchar->hoff ) % st->zoom;
      yoff = st->zoom - ( st->vv - pkchar->voff ) % st->zoom;
      for ( i = -1; i < pkchar->width / st->zoom + 2; i++ )
	{
	  for ( j = -1; j < pkchar->height / st->zoom + 2; j++ )
	    {
	      val = 0;
	      for ( k = xoff; k < st->zoom + xoff; k++ )
		for ( l = yoff; l < st->zoom + yoff; l++ )
		  if ( i*st->zoom + k >= 0 && 
		       i*st->zoom + k < pkchar->width &&
		       j*st->zoom + l >= 0 && 
		       j*st->zoom + l < pkchar->height )
		    val += pkchar->pixels[ (j*st->zoom + l) * pkchar->width +
					   i*st->zoom + k ];
	      if ( val )
		gdk_draw_point( pmap, st->gcs[ val ], x + i + st->xoff,
				y + j + st->yoff );
	    }
	}
      break;
    }
}

static void advance_by_width( GtkDvi *dvi, DrawStatus *st, int cc )
{
  int width;

#ifdef PRINT_STUFF
  g_print( "Advancing by width of %d.\n", cc );
#endif

  /* Adjust for oriental fonts. ?? */
  if ( cc < 0 )
    cc = 255 - ( ( - 1 - cc ) % 256 );
  else if ( cc >= 256 )
    cc = cc % 256;
  if ( cc >= FONT( st->f )->font->allocated_chars ||
       ! FONT( st->f )->font->chars[ cc ] )
    width = 0;
  else
    {
      width = FONT( st->f )->font->chars[ cc ]->dviwidth;
      st->hh += FONT( st->f )->font->chars[ cc ]->width;
    }
  adjust_h( dvi, st, width );  
}

static void DVI_draw_to_pixmap( GtkDvi *dvi, GdkPixmap *pmap, 
				gint zoom, gint x1, gint y1, gint x2, gint y2 )
{
  int command, i, j;
  DrawStatus st;

  g_print( "Exposing...\n" );

  st.zoom = zoom;
  st.gcs = make_gcs( pmap, gtk_widget_get_colormap( GTK_WIDGET( dvi ) ), 
		     zoom );
  st.x1 = x1;
  st.y1 = y1;
  st.x2 = x2;
  st.y2 = y2;
  /* Add one inch of offset in both x and y directions. */
  st.xoff = (1*DEFAULT_DPI)/zoom;
  st.yoff = (1*DEFAULT_DPI)/zoom;

  gdk_draw_rectangle( pmap, st.gcs[ 0 ], TRUE,
		      x1 + st.xoff, y1 + st.yoff, x2 - x1 + 1, y2 - y1 + 1 );

  /* Empty the stack. */
  dvi->sp = 0;
  /* Seek to the beginning of the page. */
  fseek( dvi->file, dvi->pages[ dvi->current_page ] + 45, SEEK_SET );
  /* Set the coordinates to 0. */
  st.h = st.hh = st.v = st.vv = st.w = st.x = st.y = st.z = st.f = 0;

  command = getc( dvi->file );
  while ( command != DVI_EOP )
    {
      i = 0;
      if ( command < DVI_FIRST )
	{
	  put_char( dvi, &st, command, pmap );
	  advance_by_width( dvi, &st, command );
	}
      else if ( command >= DVI_FONTNUM0 && command <= DVI_FONTNUMN )
	{
	  i = command - DVI_FONTNUM0;
#ifdef PRINT_STUFF
	  g_print( "Selecting font %d.\n", i );
#endif
	  if ( i >= 0 && i < dvi->num_fonts && FONT( i ) )
	    st.f = i;
	  else
	    g_print( "Tried to select an undefined font.\n" );
	}
      else
	switch ( command )
	  {
	  case DVI_SET1:
	    i = getc( dvi->file );
	    put_char( dvi, &st, i, pmap );
	    advance_by_width( dvi, &st, i );
	    break;
	  case DVI_SET2:
	    i = fgettwo( dvi->file );
	    put_char( dvi, &st, i, pmap );
	    advance_by_width( dvi, &st, i );
	    break;
	  case DVI_SET3:
	    i = fgetthree( dvi->file );
	    put_char( dvi, &st, i, pmap );
	    advance_by_width( dvi, &st, i );
	    break;
	  case DVI_SET4:
	    i = fgetint( dvi->file );
	    put_char( dvi, &st, i, pmap );
	    advance_by_width( dvi, &st, i );
	    break;
	  case DVI_SETRULE:
	    j = fgetint( dvi->file );
	    i = fgetint( dvi->file );
	    if ( i > 0 && j > 0 )
	      {
		draw_rule( pmap, &st, st.hh, st.vv, 
			   rule_pixels( dvi, i ), rule_pixels( dvi, j ) );
	      }
	    st.hh += rule_pixels( dvi, i );
	    adjust_h( dvi, &st, rule_pixels( dvi, i ) );
	    break;
	  case DVI_PUT1:
	    i = getc( dvi->file );
	    put_char( dvi, &st, i, pmap );
	    break;
	  case DVI_PUT2:
	    i = fgettwo( dvi->file );
	    put_char( dvi, &st, i, pmap );
	    break;
	  case DVI_PUT3:
	    i = fgetthree( dvi->file );
	    put_char( dvi, &st, i, pmap );
	    break;
	  case DVI_PUT4:
	    i = fgetint( dvi->file );
	    put_char( dvi, &st, i, pmap );
	    break;
	  case DVI_PUTRULE:
	    j = fgetint( dvi->file );
	    i = fgetint( dvi->file );
	    if ( i > 0 && j > 0 )
	      {
		draw_rule( pmap, &st, st.hh, st.vv, 
			   rule_pixels( dvi, i ), rule_pixels( dvi, j ) );
	      }
	    break;
	  case DVI_NOP:
	    /* Don't have to do anything here. */
	    g_print( "A NOP.\n" );
	    break;
	  case DVI_BOP:
	    /* We shouldn't find this! */
	    g_print( "Unexpected BOP.\n" );
	    break;
	  case DVI_EOP:
	    /* We're finished with the page. */
	    break;
	  case DVI_PUSH:
#ifdef PRINT_STUFF
	    g_print( "Push.\n" );
#endif
	    if ( dvi->sp < dvi->stacksize )
	      {
		STACK.h = st.h;
		STACK.hh = st.hh;
		STACK.v = st.v;
		STACK.vv = st.vv;
		STACK.w = st.w;
		STACK.x = st.x;
		STACK.y = st.y;
		STACK.z = st.z;
		dvi->sp++;
	      }
	    else
	      g_print( "Trying to push on a full stack.\n" );
	    break;
	  case DVI_POP:
#ifdef PRINT_STUFF
	    g_print( "Pop.\n" );
#endif
	    if ( dvi->sp > 0 )
	      {
		dvi->sp--;
		st.h = STACK.h;
		st.hh = STACK.hh;
		st.v = STACK.v;
		st.vv = STACK.vv;
		st.w = STACK.w;
		st.x = STACK.x;
		st.y = STACK.y;
		st.z = STACK.z;
	      }
	    else
	      g_print( "Trying to pop an empty stack.\n" );
	    break;
	  case DVI_RIGHT1:
	    out_space( dvi, &st, fgetsc( dvi->file ) );
	    break;
	  case DVI_RIGHT2:
	    out_space( dvi, &st, fgetstwo( dvi->file ) );
	    break;
	  case DVI_RIGHT3:
	    out_space( dvi, &st, fgetsthree( dvi->file ) );
	    break;
	  case DVI_RIGHT4:
	    out_space( dvi, &st, fgetint( dvi->file ) );
	    break;
	  case DVI_W0:
	    out_space( dvi, &st, st.w );
	    break;
	  case DVI_W1:
	    st.w = fgetsc( dvi->file );
	    out_space( dvi, &st, st.w );
	    break;
	  case DVI_W2:
	    st.w = fgetstwo( dvi->file );
	    out_space( dvi, &st, st.w );
	    break;
	  case DVI_W3:
	    st.w = fgetsthree( dvi->file );
	    out_space( dvi, &st, st.w );
	    break;
	  case DVI_W4:
	    st.w = fgetint( dvi->file );
	    out_space( dvi, &st, st.w );
	    break;
	  case DVI_X0:
	    out_space( dvi, &st, st.x );
	    break;
	  case DVI_X1:
	    st.x = fgetsc( dvi->file );
	    out_space( dvi, &st, st.x );
	    break;
	  case DVI_X2:
	    st.x = fgetstwo( dvi->file );
	    out_space( dvi, &st, st.x );
	    break;
	  case DVI_X3:
	    st.x = fgetsthree( dvi->file );
	    out_space( dvi, &st, st.x );
	    break;
	  case DVI_X4:
	    st.x = fgetint( dvi->file );
	    out_space( dvi, &st, st.x );
	    break;
	  case DVI_DOWN1:
	    out_vmove( dvi, &st, fgetsc( dvi->file ) );
	    break;
	  case DVI_DOWN2:
	    out_vmove( dvi, &st, fgetstwo( dvi->file ) );
	    break;
	  case DVI_DOWN3:
	    out_vmove( dvi, &st, fgetsthree( dvi->file ) );
	    break;
	  case DVI_DOWN4:
	    out_vmove( dvi, &st, fgetint( dvi->file ) );
	    break;
	  case DVI_Y0:
	    out_vmove( dvi, &st, st.y );
	    break;
	  case DVI_Y1:
	    st.y = fgetsc( dvi->file );
	    out_vmove( dvi, &st, st.y );
	    break;
	  case DVI_Y2:
	    st.y = fgetstwo( dvi->file );
	    out_vmove( dvi, &st, st.y );
	    break;
	  case DVI_Y3:
	    st.y = fgetsthree( dvi->file );
	    out_vmove( dvi, &st, st.y );
	    break;
	  case DVI_Y4:
	    st.y = fgetint( dvi->file );
	    out_vmove( dvi, &st, st.y );
	    break;
	  case DVI_Z0:
	    out_vmove( dvi, &st, st.z );
	    break;
	  case DVI_Z1:
	    st.z = fgetsc( dvi->file );
	    out_vmove( dvi, &st, st.z );
	    break;
	  case DVI_Z2:
	    st.z = fgetstwo( dvi->file );
	    out_vmove( dvi, &st, st.z );
	    break;
	  case DVI_Z3:
	    st.z = fgetsthree( dvi->file );
	    out_vmove( dvi, &st, st.z );
	    break;
	  case DVI_Z4:
	    st.z = fgetint( dvi->file );
	    out_vmove( dvi, &st, st.z );
	    break;
	  case DVI_FNT4:
	    i = getc( dvi->file );
	    /* Fall through. */
	  case DVI_FNT3:
	    i = ( i << 8 ) | getc( dvi->file );
	    /* Fall through. */
	  case DVI_FNT2:
	    i = ( i << 8 ) | getc( dvi->file );
	    /* Fall through. */
	  case DVI_FNT1:
	    i = ( i << 8 ) | getc( dvi->file );
#ifdef PRINT_STUFF
	    g_print( "Selecting font %d.\n", i );
#endif
	    if ( i >= 0 && i < dvi->num_fonts && FONT( i ) )
	      st.f = i;
	    else
	      g_print( "An undefined font: %d.\n", i );
	    break;
	  case DVI_XXX4:
	    i = getc( dvi->file );
	    /* Fall through. */
	  case DVI_XXX3:
	    i = ( i << 8 ) | getc( dvi->file );
	    /* Fall through. */
	  case DVI_XXX2:
	    i = ( i << 8 ) | getc( dvi->file );
	    /* Fall through. */
	  case DVI_XXX1:
	    i = ( i << 8 ) | getc( dvi->file );
	    g_print( "A %d byte special.\n", i );
	    /* Just read out the special and ignore it, for now. */
	    freadn( dvi->file, i );
	    break;
	  case DVI_FNTDEF4:
	    getc( dvi->file );
	    /* Fall through. */
	  case DVI_FNTDEF3:
	    getc( dvi->file );
	    /* Fall through. */
	  case DVI_FNTDEF2:
	    getc( dvi->file );
	    /* Fall through. */
	  case DVI_FNTDEF1:
	    getc( dvi->file );
	    /* The fonts have already been defined. */
	    freadn( dvi->file, 12 );
	    i = getc( dvi->file ) + getc( dvi->file );
	    freadn( dvi->file, i );
	    break;
	  case DVI_PRE:
	    g_print( "Unexpected preamble.\n" );
	    break;
	  case DVI_POST:
	    g_print( "Unexpected postamble.\n" );
	    break;
	  case DVI_POSTPOST:
	    g_print( "Unexpected postpostamble.\n" );
	    break;
	  default:
	    g_print( "Unknown command %d.\n", command );
	    break;
	  }
      command = getc( dvi->file );
    }

  g_print( "Done.\n" );
}


