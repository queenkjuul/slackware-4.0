/* GTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
#ifndef __GTKDVI_H__
#define __GTKDVI_H__

#include <gdk/gdk.h>
#include <gtk/gtkwidget.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define GTK_DVI(obj)          GTK_CHECK_CAST (obj, gtk_dvi_get_type (), GtkDvi)
#define GTK_DVI_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, gtk_dvi_get_type (), GtkDviClass)
#define GTK_IS_DVI(obj)       GTK_CHECK_TYPE (obj, gtk_dvi_get_type ())


typedef struct _GtkDvi       GtkDvi;
typedef struct _GtkDviClass  GtkDviClass;

/* Some widget defaults. */
/* Width and height are in tenth of millimeters. */
/* This is A4 size. */ 
#define GTK_DVI_DEFAULT_WIDTH 2100
#define GTK_DVI_DEFAULT_HEIGHT 2970
#define GTK_DVI_DEFAULT_ZOOM 4
#define GTK_DVI_MIN_ZOOM 1
#define GTK_DVI_MAX_ZOOM 8

/* A function that finds a font for us. */
typedef FILE *(*PKFontFinder) (gchar *name, gchar *area, int dpi);

struct _GtkDvi
{
  GtkWidget widget;

  /* The file we're showing. */
  FILE *file;
  /* A function to call when we want a font opened. */
  PKFontFinder ffinder;
  /* Pointers to allocated fonts. This is really DVIFont **, but
   * I don't want to export that type. */
  gpointer *fonts;
  /* How many fonts in the array? */
  gint num_fonts; 
  /* Array of page offsets in the file. */
  gint *pages; 
  /* How many pages are there? */
  gint num_pages; 
  /* Defines measurement unit. */
  gint numerator, denominator; 
  /* The original magnifiction in the file. */
  gint magnification; 
  /* Converts units to pixels. */
  gfloat scaling; 
  /* Bounding box for pages. */
  gint maxheight, maxwidth; 
  /* How large is the space on the stack? */
  gint stacksize; 
  /* The stackpointer. */
  gint sp; 
  /* The actual stack. (DVIStack *) */
  gpointer stack; 
 
  /* Which page of that file? */
  gint current_page;
  /* At which zoom factor? */
  gint zoom;

  /* This is the pixmap we draw to, then copy to the screen. */
  GdkPixmap *backing;
};

struct _GtkDviClass
{
  GtkWidgetClass parent_class;
};


guint      gtk_dvi_get_type    (void);
/* This will take ownership of the file, i.e. will close it when
   done with it. */
GtkWidget* gtk_dvi_new         (FILE *dvifile, PKFontFinder ffinder );
void       gtk_dvi_set_dvi     (GtkDvi *dvi, FILE *dvifile);
void       gtk_dvi_set_page    (GtkDvi *dvi, gint page);
void       gtk_dvi_next_page   (GtkDvi *dvi);
void       gtk_dvi_prev_page   (GtkDvi *dvi);
void       gtk_dvi_set_zoom    (GtkDvi *dvi, gint zoom);
void       gtk_dvi_zoom_in     (GtkDvi *dvi);
void       gtk_dvi_zoom_out    (GtkDvi *dvi);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __GTKDVI_H__ */
