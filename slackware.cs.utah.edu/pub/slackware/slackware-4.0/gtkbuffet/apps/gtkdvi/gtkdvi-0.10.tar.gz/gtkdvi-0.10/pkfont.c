#include <pkfont.h>
#include <stdio.h>
#include <math.h>

/* Allocate at least this many pointers each time we realloc. */
#define CHUNK_SIZE 50

/* The PK command bytes. */
#define PK_FIRST_COMMAND 240
#define PK_XXX1 240
#define PK_XXX2 241
#define PK_XXX3 242
#define PK_XXX4 243
#define PK_YYY  244
#define PK_POST 245
#define PK_NOOP 246
#define PK_PRE  247
#define PK_LAST_COMMAND 247

static int fgetint( FILE *file )
{
  /* Shouldn't these definitions depend upon whether we're MSB or LSB? */
  return ( getc( file ) << 24 ) | ( getc( file ) << 16 ) |
    ( getc( file ) << 8 ) | ( getc( file ) );
}

static int fgetthree( FILE *file )
{
  return ( getc( file ) << 16 ) | ( getc( file ) << 8 ) | ( getc( file ) );
}

static int fgettwo( FILE *file )
{
  return ( getc( file ) << 8 ) | ( getc( file ) );
}

static int fgetstwo( FILE *file )
{
  return ( ((signed char)getc( file ) ) << 8 ) | ( getc( file ) );
}

static int fgetsc( FILE *file )
{
  return (signed char)getc( file );
}

static void freadn( FILE *file, int n )
{
  while ( n > 0 )
    {
      getc( file );
      n--;
    }
}

static int getnybble( char **c, int *state )
{
  int nybble;

  if ( *state == 0 )
    {
      *state = 1;
      return ( **c >> 4 ) & 15;
    }
  else 
    {
      *state = 0;
      nybble = **c & 15;
      (*c)++;
      return nybble;
    }
}

typedef struct _RLEStatus RLEStatus;
struct _RLEStatus
{
  int count;
  int repeat_count;
  int repeat_line;
  char *next_pixel;
  char *next_nybble;
  int nybble_status;
};


static void print_count( PKCharDef *the_char, RLEStatus *status )
{
  int i;

  if ( the_char->is_black )
    {
      for ( i = 0; i < status->count; i++ )
	{
	  *(status->next_pixel++) = 1;
	}
    }
  else
    {
      status->next_pixel += status->count;
    }
}

static int read_count( PKCharDef *the_char, RLEStatus *status )
{
  int i, j;
  
  i = getnybble( &status->next_nybble, &status->nybble_status );
  if ( i == 0 )
    {
      do
	{
	  j = getnybble( &status->next_nybble, &status->nybble_status );
	  i++;
	}
      while ( j == 0 );
      while ( i > 0 )
	{
	  j = ( j << 4 ) + getnybble( &status->next_nybble, 
				      &status->nybble_status );
	  i--;
	}
      return j - 15 + ( 13 - the_char->dyn_f ) * 16 + the_char->dyn_f;
    }
  else if ( i <= the_char->dyn_f )
    return i;
  else if ( i < 14 )
    return ( i - the_char->dyn_f - 1 ) * 16 + 
      getnybble( &status->next_nybble, &status->nybble_status ) +
      the_char->dyn_f + 1;
  else
    {
      if ( status->repeat_count != 0 )
	g_print( "Double repeat count!\n" );
      status->repeat_count = 1;
      if ( i == 14 )
	{
	  status->repeat_count = read_count( the_char, status );
	}
      /* Also figure out which line to repeat. */
      status->repeat_line = 
	(status->next_pixel - the_char->pixels)/the_char->width;
      return read_count( the_char, status );
    }
}

static void load_rle( PKCharDef *the_char )
{
  RLEStatus status;
  int rows_left = the_char->height;
  int h_bit = the_char->width;
  char *oldpixels = the_char->pixels;
  int reprow, postbytes;
  char *src, *dst;
  int i, j;

  status.nybble_status = 0;
  status.count = 0;
  status.next_nybble = the_char->pixels;
  status.repeat_count = 0;

  the_char->num_bytes = the_char->width * the_char->height;
  the_char->pixels = g_new0( char, the_char->num_bytes );

  status.next_pixel = the_char->pixels;

  while ( rows_left > 0 )
    {
      status.count = read_count( the_char, &status );
      print_count( the_char, &status );
      if ( status.count >= h_bit )
	{
	  if ( status.repeat_count > 0 )
	    {
	      /* We should repeat the last row! */
	      /* Which row is that? */
	      reprow = status.repeat_line;
	      postbytes = status.next_pixel - ( the_char->pixels + 
					    ( reprow + 1 ) * the_char->width );
	      /* First move the trailing bytes. */
	      src = status.next_pixel - postbytes;
	      dst = src + status.repeat_count * the_char->width;
	      for ( i = 0; i < postbytes; i++ )
		*(dst++) = *(src++);
	      /* Now copy the line. */
	      for( i = 0; i < status.repeat_count; i++ )
		{
		  src = the_char->pixels + reprow * the_char->width;
		  dst = src + (i+1)*the_char->width;
		  for ( j = 0; j < the_char->width; j++ )
		    *(dst++) = *(src++);
		}
	      status.next_pixel += status.repeat_count * the_char->width;
	    }
	  rows_left = rows_left - status.repeat_count - 1;
	  status.repeat_count = 0;
	  status.count = status.count - h_bit;
	  h_bit = the_char->width;
	  rows_left = rows_left - status.count / the_char->width;
	  status.count = status.count % the_char->width;
	}
      h_bit -= status.count;
      the_char->is_black = ! the_char->is_black;
    }
  if ( rows_left != 0 || h_bit != the_char->width )
    g_print( "More bits than required!\n" );
  g_free( oldpixels );
}

static void load_raster( PKCharDef *the_char )
{
  int i, bit;
  char *dest, *new_pixels, *src;

  new_pixels = g_new( char, the_char->width * the_char->height );
  dest = new_pixels;
  src = the_char->pixels;

  bit = 7;
  for ( i = 0; i < the_char->width * the_char->height; i++ )
    {
      if ( bit < 0 )
	{
	  src++;
	  bit = 7;
	}
      *(dest++) = ( *src >> bit ) & 1;
      bit--;
    }

  g_free( the_char->pixels );
  the_char->num_bytes = the_char->width * the_char->height;
  the_char->pixels = new_pixels;
}


/* Loads a PK font from a file. Returns NULL on failure. */
/* This loader is quite forgiving, perhaps too forgiving? */
PKFont *PKF_load( FILE *pkfile )
{
  int command, i;
  int cc;
  PKFont *font;
  PKCharDef *newchar;

  /* pk_pre command byte, then identification argument. */
  if ( getc( pkfile ) != 247 || getc( pkfile ) != 89 )
    {
      fclose( pkfile );
      return NULL;
    }

  font = g_new0( PKFont, 1 );

  /* Next a comment. */
  i = getc( pkfile );
  freadn( pkfile, i );
  /* The other arguments of the pk_pre command. */
  font->design_size = fgetint( pkfile );
  font->checksum = fgetint( pkfile );
  font->hppp = fgetint( pkfile );
  font->vppp = fgetint( pkfile );
  font->space = font->hppp/6;
  font->resolution = (int)floor((font->hppp*72.27)/65536+0.5);
  font->allocated_chars = 0;
  font->chars = 0;

  do
    {
      command = getc( pkfile );
      if ( command >= PK_FIRST_COMMAND )
	{
	  switch( command )
	    {
	    case PK_XXX1:
	      freadn( pkfile, getc( pkfile ) );
	      break;
	    case PK_XXX2:
	      freadn( pkfile, fgettwo( pkfile ) );
	      break;
	    case PK_XXX3:
	      freadn( pkfile, fgetthree( pkfile ) );
	      break;
	    case PK_XXX4:
	      freadn( pkfile, fgetint( pkfile ) );
	      break;
	    case PK_YYY:
	      fgetint( pkfile );
	      break;
	    case PK_POST:
	      break;
	    case PK_NOOP:
	      break;
	    case PK_PRE:
	      break;
	    default:
	      break;
	    }
	}
      else
	{
	  /* A character definition! */
	  newchar = g_new( PKCharDef, 1 );
	  newchar->dyn_f = command >> 4;
	  newchar->is_black = !!( command & 8 );
	  if ( ( command & 7 ) == 7 )
	    {
	      /* Long form. */
	      newchar->num_bytes = fgetint( pkfile );
	      cc = fgetint( pkfile );
	      newchar->tfm = fgetint( pkfile );
	      newchar->dx = fgetint( pkfile );
	      newchar->dy = fgetint( pkfile );
	      newchar->width = fgetint( pkfile );
	      newchar->height = fgetint( pkfile );
	      newchar->hoff = fgetint( pkfile );
	      newchar->voff = fgetint( pkfile );
	      newchar->num_bytes -= 7*4;
	    }
	  else if ( command & 4 )
	    {
	      /* Medium form. */
	      newchar->num_bytes = fgettwo( pkfile ) | 
		                   ( ( command & 3 ) << 16 );
	      cc = getc( pkfile );
	      newchar->tfm = fgetthree( pkfile );
	      newchar->dx = fgettwo( pkfile )<<16;
	      newchar->dy = 0;
	      newchar->width = fgettwo( pkfile );
	      newchar->height = fgettwo( pkfile );
	      newchar->hoff = fgetstwo( pkfile );
	      newchar->voff = fgetstwo( pkfile );
	      newchar->num_bytes -= 13;
	    }
	  else
	    {
	      /* Short form. */
	      newchar->num_bytes = getc( pkfile ) | ( ( command & 3 ) << 8 );
	      cc = getc( pkfile );
	      newchar->tfm = fgetthree( pkfile );
	      newchar->dx = getc( pkfile )<<16;
	      newchar->dy = 0;
	      newchar->width = getc( pkfile );
	      newchar->height = getc( pkfile );
	      newchar->hoff = fgetsc( pkfile );
	      newchar->voff = fgetsc( pkfile );
	      newchar->num_bytes -= 8;
	    }
	  newchar->is_loaded = FALSE;
	  newchar->pixels = g_new( char, newchar->num_bytes );
	  fread( newchar->pixels, 1, newchar->num_bytes, pkfile );
	  if ( font->allocated_chars <= cc )
	    {
	      int newsize = cc - font->allocated_chars + 1;
	      if ( newsize < CHUNK_SIZE )
		newsize = CHUNK_SIZE;
	      newsize += font->allocated_chars;
	      font->chars = g_realloc( font->chars, sizeof( PKCharDef * ) *
				                             newsize );
	      for ( i = font->allocated_chars; i < newsize; i++ )
		font->chars[ i ] = NULL;
	      font->allocated_chars = newsize;
	    }
	  if ( font->chars[ cc ] )
	    {
	      /* I guess this shouldn't happen, but, hey. */
	      if ( font->chars[ cc ]->pixels )
		g_free( font->chars[ cc ]->pixels );
	      g_free( font->chars[ cc ] );
	    }
	  font->chars[ cc ] = newchar;
	}
    }
  while ( command != PK_POST );

  fclose( pkfile );

  return font;
}

/* Free the memory occupied by the PK font. */
void PKF_destroy( PKFont *font )
{
  int i;

  if ( ! font )
    return;

  for ( i = 0; i < font->allocated_chars; i++ )
    if ( font->chars[ i ] )
      {
	if ( font->chars[ i ]->pixels )
	  g_free( font->chars[ i ]->pixels );
	g_free( font->chars[ i ] );
      }
  if ( font->chars )
    g_free( font->chars );
  g_free( font );
}

/* Gets a character and loads it if necessary. */
PKCharDef *PKF_get_char( PKFont *font, int charcode )
{
  PKCharDef *the_char;

  if ( ! font || ! font->chars || charcode < 0 ||
       charcode >= font->allocated_chars )
    return NULL;

  the_char = font->chars[ charcode ];

  if ( the_char && ! the_char->is_loaded )
    {
      /* Load the damn character. */
      if ( the_char->dyn_f != 14 )
	load_rle( the_char );
      else
	load_raster( the_char );
      the_char->is_loaded = 1;
    }
  return font->chars[ charcode ];
}
