#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "gtkdvi.h"
#include <gdk/gdkkeysyms.h>

gint key_release( GtkDvi *dvi, GdkEventKey *event, gpointer data )
{
  switch ( event->keyval )
    {
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
      gtk_dvi_set_zoom( dvi, event->keyval - '0' );
      return TRUE;
      break;
    case '-':
      gtk_dvi_zoom_out( dvi );
      return TRUE;
      break;
    case '+':
      gtk_dvi_zoom_in( dvi );
      return TRUE;
      break;
    case GDK_Page_Up:
      gtk_dvi_prev_page( dvi );
      return TRUE;
      break;
    case GDK_Page_Down:
      gtk_dvi_next_page( dvi );
      return TRUE;
      break;
    default:
      return FALSE;
      break;
    }
}

gint delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
  g_print ("Quitting.\n");
  
  return FALSE;
}

FILE *simple_finder( gchar *name, gchar *area, int dpi )
{
  gchar *fname;
  gchar buf[ 20 ];
  FILE *res;

  sprintf( buf, "%d", dpi );
  fname = g_strconcat( PKFONTDIR, name, ".", buf, "pk", NULL );
  res = fopen( fname, "r" );
  g_free( fname );

  if ( ! res )
    g_print( "Failed to find font '%s' at '%d' dpi.\n", name, dpi );

  return res;
}

int main( int argc, char **argv )
{
  FILE *file;
  GtkWidget *toplevel, *tmp, *dviw;
  
  if ( argc >= 2 )
    {
      gtk_init( &argc, &argv );

      g_print( "Trying '%s'.\n", argv[ 1 ] );
      file = fopen( argv[ 1 ], "r" );
      if ( ! file )
	{
	  g_print( "Failed to open file.\n" );
	  return 1;
	}

      toplevel = gtk_window_new( GTK_WINDOW_TOPLEVEL );
      gtk_signal_connect (GTK_OBJECT (toplevel), "delete_event",
			  GTK_SIGNAL_FUNC (delete_event), NULL);
      gtk_signal_connect (GTK_OBJECT (toplevel), "destroy",
                             GTK_SIGNAL_FUNC (gtk_main_quit), NULL);
           
      tmp = gtk_scrolled_window_new( NULL, NULL );
      gtk_container_add( GTK_CONTAINER( toplevel ), tmp );
      gtk_widget_show( tmp );

      dviw = gtk_dvi_new( file, simple_finder );
      gtk_widget_set_events( dviw, gtk_widget_get_events( dviw ) |
			     GDK_KEY_RELEASE_MASK );
      gtk_signal_connect( GTK_OBJECT( dviw ), "key_release_event",
			  GTK_SIGNAL_FUNC( key_release ), NULL );
      if ( argc >= 3 )
	gtk_dvi_set_zoom( GTK_DVI( dviw ), atoi( argv[ 2 ] ) );
      gtk_container_add( GTK_CONTAINER( tmp ), dviw );
      gtk_widget_show( dviw );

      gtk_widget_show( toplevel );

      gtk_main( );

      return 0;
    }
  else
    return 1;
}
