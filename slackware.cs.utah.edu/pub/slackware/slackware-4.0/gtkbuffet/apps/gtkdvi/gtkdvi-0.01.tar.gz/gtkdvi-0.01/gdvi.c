#include <stdio.h>
#include <stdlib.h>
#include <dvifile.h>
#include <gtk/gtk.h>

FILE *simple_finder( DVIFont *font )
{
  gchar *fname;
  gchar buf[ 20 ];
  FILE *res;

  sprintf( buf, "%d", font->dpi );
  fname = g_strconcat( "pk/", font->name, ".", buf, "pk", NULL );
  res = fopen( fname, "r" );
  g_free( fname );

  if ( ! res )
    g_print( "Failed to find font '%s' at '%d' dpi.\n", font->name, 
	     font->dpi );

  return res;
}

int main( int argc, char **argv )
{
  FILE *file;
  DVIFile *dvi;
  GtkWidget *toplevel, *tmp, *darea;
  
  if ( argc >= 2 )
    {
      gtk_init( &argc, &argv );

      g_print( "Trying '%s'.\n", argv[ 1 ] );
      file = fopen( argv[ 1 ], "r" );
      if ( ! file )
	{
	  g_print( "Failed to open file.\n" );
	  return 1;
	}

      if ( ! ( dvi = DVI_load( file, simple_finder ) ) )
	{
	  g_print( "Failed to load file.\n" );
	  return 1;
	}
      dvi->current_page = 0;
      dvi->zoom = 2;

      if ( argc >= 3 )
	dvi->zoom = atoi( argv[ 2 ] );

      toplevel = gtk_window_new( GTK_WINDOW_TOPLEVEL );

      tmp = gtk_scrolled_window_new( NULL, NULL );
      gtk_container_add( GTK_CONTAINER( toplevel ), tmp );
      gtk_widget_show( tmp );

      darea = gtk_drawing_area_new( );
      g_print( "Drawing area is 0x%p.\n", darea );
      DVI_hook_darea( dvi, darea );
      gtk_container_add( GTK_CONTAINER( tmp ), darea );
      gtk_widget_show( darea );

      gtk_widget_show( toplevel );

      gtk_main( );

      fclose( file );

      DVI_destroy( dvi );

      return 0;
    }
  else
    return 1;
}
