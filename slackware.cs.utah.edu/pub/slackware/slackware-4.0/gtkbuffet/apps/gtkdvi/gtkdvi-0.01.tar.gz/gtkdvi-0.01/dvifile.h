#ifndef __DVIFILE_H
#define __DVIFILE_H

#include <gtk/gtk.h>
#include <stdio.h>
#include <pkfont.h>

typedef struct _DVIStack DVIStack;
struct _DVIStack
{
  /* Some elements here? */
  int h, hh, v, vv, w, x, y, z;
};

typedef struct _DVIFont DVIFont;
struct _DVIFont
{
  int scale;
  int designsize;
  int dpi;
  gchar *area, *name;
  PKFont *font;
};

typedef FILE *(*PKFontFinder)( DVIFont *font );

typedef struct _DVIFile DVIFile;
struct _DVIFile
{
  FILE *file; /* The file we're reading our stuff from. */
  PKFontFinder ffinder; /* A function to call when we want a font opened. */
  DVIFont **fonts; /* Pointers to the allocated fonts. */
  int num_fonts; /* How big is the array? */
  int *pages; /* Array of page offsets in the file. */
  int num_pages; /* How many pages are there? */
  int current_page; /* What page are we now 'on'? */
  int numerator, denominator; /* Defines measurement unit. */
  int magnification; /* The original magnifiction in the file. */
  float scaling; /* Converts units to pixels. */
  int maxheight, maxwidth; /* Bounding box for pages. */
  int stacksize; /* How large is the space on the stack? */
  int sp; /* The stackpointer. */
  DVIStack *stack; /* The actual stack. */
  int zoom; /* The zoom factor. */
};

/* Load information about a DVI file. */
DVIFile *DVI_load( FILE *file, PKFontFinder ffinder );
/* Free up the memory taken by this structure. */
void DVI_destroy( DVIFile *dvi );
/* Draw this file on a drawing area widget. */
void DVI_hook_darea( DVIFile *dvi, GtkWidget *darea );

#endif
