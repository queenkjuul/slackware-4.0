#ifndef __PKFONT_H
#define __PKFONT_H

#include <glib.h>
#include <stdio.h>

typedef struct _PKCharDef PKCharDef;
struct _PKCharDef
{
  gint tfm;      /* TFM width. */
  gint dviwidth; /* Width in dvi units. Computed by load dvi. */
  gint dx;       /* Horizontal escapement. What is this? */
  gint dy;       /* Vertical escapement. What is this? */
  gint width;    /* Width of bounding box in pixels. */
  gint height;   /* Ditto height. */
  gint hoff;     /* Horizontal offset of hot pixel. */
  gint voff;     /* Ditto vertical. */
  gboolean is_loaded; /* Has this character been parsed yet? */
  gchar *pixels; /* If is_loaded, then actual pixels, one per char,
		    otherwise raw data from file. */
  int num_bytes; /* How many bytes does pixels point to? */
  /* Stuff that's only used if it's not been loaded yet. */
  gint dyn_f;    /* Dynamic packing factor. */
  gboolean is_black; /* First run is a black one. */
};

typedef struct _PKFont PKFont;
struct _PKFont
{
  gint design_size; /* Unsure what this is, exactly. */
  gint checksum;    /* To compare with dvi, tfm and gf files. */
  gint hppp, vppp;  /* Horizontal and vertical pixels per point. */
  gint space;       /* Difference between big and small spaces. */
  gint resolution;  /* Approximate dpi, computed. */
  gint allocated_chars; /* How many pointers allocated in chars. */
  PKCharDef **chars;/* The characters. */
};

/* Loads a PK font from a file. Returns NULL on failure. */
PKFont *PKF_load( FILE *pkfile );

/* Free the memory occupied by the PK font. */
void PKF_destroy( PKFont *font );

/* Gets a character and loads it if necessary. */
PKCharDef *PKF_get_char( PKFont *font, int charcode );

#endif
