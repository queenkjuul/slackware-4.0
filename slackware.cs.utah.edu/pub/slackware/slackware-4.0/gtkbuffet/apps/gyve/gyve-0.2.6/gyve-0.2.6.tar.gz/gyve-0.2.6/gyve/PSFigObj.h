/* PSFigObj.h --- protocol for general figure objects

   Copyright (C) 1998, 1999 Free Software Foundation, Inc.

   Written by:  Masatake YAMATO <masata-y@is.aist-nara.ac.jp>
   
   This file is part of the GNU Yellow Vector Editor

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
   
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 

#ifndef GYVE_FIG_OBJ_H
#define GYVE_FIG_OBJ_H 

#include <gyve/PSBBox.h>

@protocol PSFigObj<PSBBox, NSCopying>
- (BOOL)isFigObjProxy;
- (id<PSFigObj>)targetForFigObjProxy;
- markAsSelected;
- (BOOL)isSelected;
- (void)unMarkAsSelected;
- (BOOL)isLockedFigObj;
- (void)setFigObjLock: (BOOL)l;
- (float)deltaForExpandingBBox;
- (Class)selectedProxyClass;
@end

@interface PSFigObjProxy: NSObject<PSFigObj>
{
  NSObject <PSFigObj> * target;
}
+ proxyForFigObj: (NSObject<PSFigObj> *)figobj;
- initForFigObj: (NSObject<PSFigObj> *)figobj;
- (void)dealloc;
- (BOOL)isFigObjProxy;
- (NSObject<PSFigObj> *)targetForFigObjProxy;
- (void)setTargetForFigObjProxy: (NSObject<PSFigObj> *)newfig;
- markAsSelected;
- (BOOL)isSelected;
- (void)unMarkAsSelected;
- (BOOL)isLockedFigObj;
- (void)setFigObjLock: (BOOL)l;
@end

#endif /* Not def: GYVE_FIG_OBJ_H */
