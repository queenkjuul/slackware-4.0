/* pattern.c generated from pattern.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#include <DPS/dpsfriends.h>
#include <string.h>

#line 1 "pattern.psw"
/* pattern.psw --- 

   Copyright (C) 1998, 1999 Free Software Foundation, Inc.

   Written by:  Masatake YAMATO <masata-y@is.aist-nara.ac.jp>
   
   This file is part of the GNU Yellow Vector Editor

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
   
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 
#line 31 "pattern.c"
void psw_define_user_pattern(ctxt, number)
DPSContext ctxt; int number; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjGeneric obj2;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 3, 28,
    {DPS_LITERAL|DPS_INT, 0, 0, 0},	/* param: number */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 372},	/* defineuserobject */
    }; /* _dpsQ */
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;

  _dpsP[0].val.integerVal = number;
  DPSBinObjSeqWrite(ctxt,(char *) &_dpsF,28);
  DPSSYNCHOOK(ctxt)
}
#line 25 "pattern.psw"
