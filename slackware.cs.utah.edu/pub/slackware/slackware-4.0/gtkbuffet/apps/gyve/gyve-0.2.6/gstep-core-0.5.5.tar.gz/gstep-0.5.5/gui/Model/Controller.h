#import <AppKit/AppKit.h>

@interface Controller : NSObject
{
    id textField;
}
- (void)buttonPressed:(id)sender;
- (id)window;
@end
