/* text.h generated from text.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#ifndef TEXT_H
#define TEXT_H

#if  defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

extern void psw_set_text_style( /* char *fontname; float size; */ );

extern void psw_draw_text_element( /* float x, y; char *text; float *x_new, *y_new; */ );

extern void psw_draw_text_element_with_highlight( /* float x, y, h; char *text; float *x_new, *y_new; */ );

extern void psw_get_text_element_bbox( /* float x, y; char *text; float bbox[]; */ );

extern void psw_get_font_bbox( /* float bbox[]; */ );

extern void psw_get_font_matrix( /* float matrix[]; */ );

extern void psw_calc_text_element_width( /* float x, y; char *text; float *x_new, *y_new; */ );

#if  defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* TEXT_H */
