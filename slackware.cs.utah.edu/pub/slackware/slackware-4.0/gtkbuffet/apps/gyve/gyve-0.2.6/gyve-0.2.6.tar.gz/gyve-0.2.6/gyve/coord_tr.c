/* coord_tr.c generated from coord_tr.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#include <DPS/dpsfriends.h>
#include <string.h>

#line 1 "coord_tr.psw"
/* coord_tr.psw --- 

   Copyright (C) 1998, 1999 Free Software Foundation, Inc.

   Written by:  Masatake YAMATO <masata-y@is.aist-nara.ac.jp>
   
   This file is part of the GNU Yellow Vector Editor

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
   
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 
#line 31 "coord_tr.c"
void psw_get_transform(ctxt, ctm, invctm, x_offset, y_offset)
DPSContext ctxt; float ctm[], invctm[]; int *x_offset, *y_offset; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjGeneric obj3;
    DPSBinObjGeneric obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjGeneric obj9;
    DPSBinObjGeneric obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjGeneric obj12;
    DPSBinObjGeneric obj13;
    DPSBinObjGeneric obj14;
    DPSBinObjGeneric obj15;
    DPSBinObjGeneric obj16;
    DPSBinObjGeneric obj17;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 18, 148,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 104},	/* matrix */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 39},	/* currentmatrix */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 56},	/* dup */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 104},	/* matrix */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 94},	/* invertmatrix */
    {DPS_LITERAL|DPS_INT, 0, 0, 1},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* currentXoffset */
    {DPS_LITERAL|DPS_INT, 0, 0, 3},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_INT, 0, 0, 2},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 4},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 70},	/* flush */
    }; /* _dpsQ */
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  static DPSResultsRec _dpsR[] = {
    { dps_tFloat },
    { dps_tFloat },
    { dps_tInt, -1 },
    { dps_tInt, -1 },
    };
    _dpsR[0].count = 6;
    _dpsR[0].value = (char *)ctm;
    _dpsR[1].count = 6;
    _dpsR[1].value = (char *)invctm;
    _dpsR[2].value = (char *)x_offset;
    _dpsR[3].value = (char *)y_offset;

  {
  static int _dpsT = 1;

  if (_dpsT) {
    static char *_dps_names[] = {
	"currentXoffset"};
    int *_dps_nameVals[1];
    _dps_nameVals[0] = (int *)&_dpsP[9].val.nameVal;

    DPSMapNames(ctxt, 1, (char **) _dps_names, _dps_nameVals);
    _dpsT = 0;
    }
  }


  DPSSetResultTable(ctxt, _dpsR, 4);
  DPSBinObjSeqWrite(ctxt,(char *) &_dpsF,148);
  DPSAwaitReturnValues(ctxt);
}
#line 28 "coord_tr.psw"

