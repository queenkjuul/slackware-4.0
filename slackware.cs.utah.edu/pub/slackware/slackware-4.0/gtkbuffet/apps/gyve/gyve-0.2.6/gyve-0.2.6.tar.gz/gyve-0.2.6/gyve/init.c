/* init.c generated from init.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#include <DPS/dpsfriends.h>
#include <string.h>

#line 1 "init.psw"
/* init.psw --- 

   Copyright (C) 1998, 1999 Free Software Foundation, Inc.

   Written by:  Masatake YAMATO <masata-y@is.aist-nara.ac.jp>
   
   This file is part of the GNU Yellow Vector Editor

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
   
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 

/* Special exceptions:
   Some procedures are from Blue Book. */
#line 34 "init.c"
void DPSWinstall_procs(ctxt)
DPSContext ctxt; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjGeneric obj3;
    DPSBinObjGeneric obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjGeneric obj9;
    DPSBinObjGeneric obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjGeneric obj12;
    DPSBinObjGeneric obj13;
    DPSBinObjGeneric obj14;
    DPSBinObjGeneric obj15;
    DPSBinObjGeneric obj16;
    DPSBinObjGeneric obj17;
    DPSBinObjGeneric obj18;
    DPSBinObjGeneric obj19;
    DPSBinObjGeneric obj20;
    DPSBinObjGeneric obj21;
    DPSBinObjGeneric obj22;
    DPSBinObjGeneric obj23;
    DPSBinObjGeneric obj24;
    DPSBinObjGeneric obj25;
    DPSBinObjGeneric obj26;
    DPSBinObjGeneric obj27;
    DPSBinObjGeneric obj28;
    DPSBinObjGeneric obj29;
    DPSBinObjGeneric obj30;
    DPSBinObjGeneric obj31;
    DPSBinObjGeneric obj32;
    DPSBinObjGeneric obj33;
    DPSBinObjGeneric obj34;
    DPSBinObjGeneric obj35;
    DPSBinObjGeneric obj36;
    DPSBinObjGeneric obj37;
    DPSBinObjGeneric obj38;
    DPSBinObjGeneric obj39;
    DPSBinObjGeneric obj40;
    DPSBinObjGeneric obj41;
    DPSBinObjGeneric obj42;
    DPSBinObjGeneric obj43;
    DPSBinObjGeneric obj44;
    DPSBinObjGeneric obj45;
    DPSBinObjGeneric obj46;
    DPSBinObjGeneric obj47;
    DPSBinObjGeneric obj48;
    DPSBinObjGeneric obj49;
    DPSBinObjGeneric obj50;
    DPSBinObjGeneric obj51;
    DPSBinObjGeneric obj52;
    DPSBinObjGeneric obj53;
    DPSBinObjGeneric obj54;
    DPSBinObjGeneric obj55;
    DPSBinObjGeneric obj56;
    DPSBinObjGeneric obj57;
    DPSBinObjGeneric obj58;
    DPSBinObjGeneric obj59;
    DPSBinObjGeneric obj60;
    DPSBinObjGeneric obj61;
    DPSBinObjGeneric obj62;
    DPSBinObjGeneric obj63;
    DPSBinObjGeneric obj64;
    DPSBinObjGeneric obj65;
    DPSBinObjGeneric obj66;
    DPSBinObjGeneric obj67;
    DPSBinObjGeneric obj68;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 17, 556,
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* ellipsedict */
    {DPS_LITERAL|DPS_INT, 0, 0, 8},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 53},	/* dict */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* ellipsedict */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* mtrx */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 104},	/* matrix */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 120},	/* put */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* ellipse */
    {DPS_EXEC|DPS_ARRAY, 0, 39, 240},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* handlesize */
    {DPS_LITERAL|DPS_INT, 0, 0, 4},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* handlerect */
    {DPS_EXEC|DPS_ARRAY, 0, 13, 136},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* handlesize */
    {DPS_LITERAL|DPS_INT, 0, 0, 2},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 54},	/* div */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* handlesize */
    {DPS_LITERAL|DPS_INT, 0, 0, 2},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 54},	/* div */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* handlesize */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* handlesize */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 128},	/* rectfill */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* ellipsedict */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 13},	/* begin */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* endangle */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* startangle */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* yrad */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* xrad */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_LITERAL|DPS_NAME, 0, DPSSYSNAME, 426},	/* y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_LITERAL|DPS_NAME, 0, DPSSYSNAME, 425},	/* x */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* savematrix */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* mtrx */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 39},	/* currentmatrix */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 51},	/* def */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 425},	/* x */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 426},	/* y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 173},	/* translate */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* xrad */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* yrad */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 139},	/* scale */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 1},
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* startangle */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* endangle */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 5},	/* arc */
    {DPS_EXEC|DPS_NAME, 0, 0, 0},	/* savematrix */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 156},	/* setmatrix */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 57},	/* end */
    }; /* _dpsQ */
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  {
  static int _dpsT = 1;

  if (_dpsT) {
    static char *_dps_names[] = {
	"ellipsedict",
	(char *) 0 ,
	(char *) 0 ,
	"mtrx",
	(char *) 0 ,
	"ellipse",
	"handlesize",
	(char *) 0 ,
	(char *) 0 ,
	(char *) 0 ,
	(char *) 0 ,
	"handlerect",
	"endangle",
	(char *) 0 ,
	"startangle",
	(char *) 0 ,
	"yrad",
	(char *) 0 ,
	"xrad",
	(char *) 0 ,
	"savematrix",
	(char *) 0 };
    int *_dps_nameVals[22];
    _dps_nameVals[0] = (int *)&_dpsP[0].val.nameVal;
    _dps_nameVals[1] = (int *)&_dpsP[30].val.nameVal;
    _dps_nameVals[2] = (int *)&_dpsP[4].val.nameVal;
    _dps_nameVals[3] = (int *)&_dpsP[5].val.nameVal;
    _dps_nameVals[4] = (int *)&_dpsP[51].val.nameVal;
    _dps_nameVals[5] = (int *)&_dpsP[8].val.nameVal;
    _dps_nameVals[6] = (int *)&_dpsP[11].val.nameVal;
    _dps_nameVals[7] = (int *)&_dpsP[28].val.nameVal;
    _dps_nameVals[8] = (int *)&_dpsP[27].val.nameVal;
    _dps_nameVals[9] = (int *)&_dpsP[22].val.nameVal;
    _dps_nameVals[10] = (int *)&_dpsP[17].val.nameVal;
    _dps_nameVals[11] = (int *)&_dpsP[14].val.nameVal;
    _dps_nameVals[12] = (int *)&_dpsP[32].val.nameVal;
    _dps_nameVals[13] = (int *)&_dpsP[64].val.nameVal;
    _dps_nameVals[14] = (int *)&_dpsP[35].val.nameVal;
    _dps_nameVals[15] = (int *)&_dpsP[63].val.nameVal;
    _dps_nameVals[16] = (int *)&_dpsP[38].val.nameVal;
    _dps_nameVals[17] = (int *)&_dpsP[58].val.nameVal;
    _dps_nameVals[18] = (int *)&_dpsP[41].val.nameVal;
    _dps_nameVals[19] = (int *)&_dpsP[57].val.nameVal;
    _dps_nameVals[20] = (int *)&_dpsP[50].val.nameVal;
    _dps_nameVals[21] = (int *)&_dpsP[66].val.nameVal;

    DPSMapNames(ctxt, 22, (char **) _dps_names, _dps_nameVals);
    _dpsT = 0;
    }
  }


  DPSBinObjSeqWrite(ctxt,(char *) &_dpsF,556);
  DPSSYNCHOOK(ctxt)
}
#line 62 "init.psw"

