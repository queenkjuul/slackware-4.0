/* init.h generated from init.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#ifndef INIT_H
#define INIT_H

#if  defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

extern void DPSWinstall_procs( /* DPSContext ctxt; */ );

#if  defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* INIT_H */
