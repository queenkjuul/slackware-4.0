#ifndef __RunLoop_h_GNUSTEP_BASE_INCLUDE
#define __RunLoop_h_GNUSTEP_BASE_INCLUDE

#include <Foundation/NSRunLoop.h>

#define	RunLoop NSRunLoop
#define	RunLoopDefaultMode	NSDefaultRunLoopMode

#endif /* __RunLoop_h_GNUSTEP_BASE_INCLUDE */
