/* text.c generated from text.psw
   by unix pswrap V1.009  Wed Apr 19 17:50:24 PDT 1989
 */

#include <DPS/dpsfriends.h>
#include <string.h>

#line 1 "text.psw"
/* text.psw ---

   Copyright (C) 1998, 1999 Free Software Foundation, Inc.

   Written by:  Masatake YAMATO <masata-y@is.aist-nara.ac.jp>
   
   This file is part of the GNU Yellow Vector Editor

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
   
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 
#line 31 "text.c"
void psw_set_text_style(fontname, size)
char *fontname; float size; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char sizeFlag;
    unsigned short topLevelCount;
    unsigned int nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjReal obj2;
    DPSBinObjGeneric obj3;
    DPSBinObjGeneric obj4;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 0, 5, 48,
    {DPS_LITERAL|DPS_NAME, 0, 0, 40},	/* param fontname */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 67},	/* findfont */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: size */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 140},	/* scalefont */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 149},	/* setfont */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  register int _dps_offset = 40;

  _dpsP[0].length = strlen(fontname);
  _dpsP[2].val.realVal = size;
  _dpsP[0].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[0].length;

  _dpsF.nBytes = _dps_offset+8;
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,48);
  DPSWriteStringChars(_dpsCurCtxt, (char *)fontname, _dpsP[0].length);
  DPSSYNCHOOK(_dpsCurCtxt)
}
#line 25 "text.psw"

#line 71 "text.c"
void psw_draw_text_element(x, y, text, x_new, y_new)
float x, y; char *text; float *x_new, *y_new; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char sizeFlag;
    unsigned short topLevelCount;
    unsigned int nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjReal obj1;
    DPSBinObjReal obj2;
    DPSBinObjGeneric obj3;
    DPSBinObjGeneric obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjGeneric obj9;
    DPSBinObjGeneric obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjGeneric obj12;
    DPSBinObjGeneric obj13;
    DPSBinObjGeneric obj14;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 0, 15, 128,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 111},	/* newpath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 107},	/* moveto */
    {DPS_LITERAL|DPS_STRING, 0, 0, 120},	/* param text */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 160},	/* show */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 40},	/* currentpoint */
    {DPS_LITERAL|DPS_INT, 0, 0, 1},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 2},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 70},	/* flush */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  register int _dps_offset = 120;
  static DPSResultsRec _dpsR[] = {
    { dps_tFloat, -1 },
    { dps_tFloat, -1 },
    };
    _dpsR[0].value = (char *)x_new;
    _dpsR[1].value = (char *)y_new;


  _dpsP[1].val.realVal = x;
  _dpsP[2].val.realVal = y;
  _dpsP[4].length = strlen(text);
  _dpsP[4].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[4].length;

  _dpsF.nBytes = _dps_offset+8;
  DPSSetResultTable(_dpsCurCtxt, _dpsR, 2);
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,128);
  DPSWriteStringChars(_dpsCurCtxt, (char *)text, _dpsP[4].length);
  DPSAwaitReturnValues(_dpsCurCtxt);
}
#line 32 "text.psw"

#line 140 "text.c"
void psw_draw_text_element_with_highlight(x, y, h, text, x_new, y_new)
float x, y, h; char *text; float *x_new, *y_new; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char sizeFlag;
    unsigned short topLevelCount;
    unsigned int nBytes;

    DPSBinObjReal obj0;
    DPSBinObjReal obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjReal obj3;
    DPSBinObjReal obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjGeneric obj9;
    DPSBinObjReal obj10;
    DPSBinObjReal obj11;
    DPSBinObjGeneric obj12;
    DPSBinObjGeneric obj13;
    DPSBinObjGeneric obj14;
    DPSBinObjGeneric obj15;
    DPSBinObjGeneric obj16;
    DPSBinObjGeneric obj17;
    DPSBinObjGeneric obj18;
    DPSBinObjGeneric obj19;
    DPSBinObjGeneric obj20;
    DPSBinObjGeneric obj21;
    DPSBinObjGeneric obj22;
    DPSBinObjGeneric obj23;
    DPSBinObjGeneric obj24;
    DPSBinObjGeneric obj25;
    DPSBinObjGeneric obj26;
    DPSBinObjGeneric obj27;
    DPSBinObjGeneric obj28;
    DPSBinObjGeneric obj29;
    DPSBinObjGeneric obj30;
    DPSBinObjReal obj31;
    DPSBinObjReal obj32;
    DPSBinObjReal obj33;
    DPSBinObjGeneric obj34;
    DPSBinObjGeneric obj35;
    DPSBinObjReal obj36;
    DPSBinObjReal obj37;
    DPSBinObjGeneric obj38;
    DPSBinObjGeneric obj39;
    DPSBinObjGeneric obj40;
    DPSBinObjGeneric obj41;
    DPSBinObjGeneric obj42;
    DPSBinObjGeneric obj43;
    DPSBinObjGeneric obj44;
    DPSBinObjGeneric obj45;
    DPSBinObjGeneric obj46;
    DPSBinObjGeneric obj47;
    DPSBinObjGeneric obj48;
    DPSBinObjGeneric obj49;
    DPSBinObjGeneric obj50;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 0, 51, 416,
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 111},	/* newpath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 107},	/* moveto */
    {DPS_LITERAL|DPS_STRING, 0, 0, 408},	/* param text */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 166},	/* stringwidth */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 117},	/* pop */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 111},	/* newpath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 107},	/* moveto */
    {DPS_LITERAL|DPS_STRING, 0, 0, 408},	/* param text */
    {DPS_LITERAL|DPS_BOOL, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 17},	/* charpath */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 68},	/* flattenpath */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 115},	/* pathbbox */
    {DPS_LITERAL|DPS_INT, 0, 0, 4},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 9},	/* array */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 11},	/* astore */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 2},	/* aload */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 117},	/* pop */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 117},	/* pop */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 169},	/* sub */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 62},	/* exch */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 117},	/* pop */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 128},	/* rectfill */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 78},	/* gsave */
    {DPS_LITERAL|DPS_REAL, 0, 0, 1.0},
    {DPS_LITERAL|DPS_REAL, 0, 0, 1.0},
    {DPS_LITERAL|DPS_REAL, 0, 0, 1.0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 157},	/* setrgbcolor */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 111},	/* newpath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 107},	/* moveto */
    {DPS_LITERAL|DPS_STRING, 0, 0, 408},	/* param text */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 160},	/* show */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 40},	/* currentpoint */
    {DPS_LITERAL|DPS_INT, 0, 0, 1},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 77},	/* grestore */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 2},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 70},	/* flush */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  register int _dps_offset = 408;
  static DPSResultsRec _dpsR[] = {
    { dps_tFloat, -1 },
    { dps_tFloat, -1 },
    };
    _dpsR[0].value = (char *)x_new;
    _dpsR[1].value = (char *)y_new;


  _dpsP[0].val.realVal =
  _dpsP[3].val.realVal =
  _dpsP[10].val.realVal =
  _dpsP[36].val.realVal = x;
  _dpsP[1].val.realVal =
  _dpsP[4].val.realVal =
  _dpsP[11].val.realVal =
  _dpsP[37].val.realVal = y;
  _dpsP[6].length =
  _dpsP[13].length =
  _dpsP[39].length = strlen(text);
  _dpsP[39].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[39].length;
  _dpsP[13].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[13].length;
  _dpsP[6].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[6].length;

  _dpsF.nBytes = _dps_offset+8;
  DPSSetResultTable(_dpsCurCtxt, _dpsR, 2);
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,416);
  DPSWriteStringChars(_dpsCurCtxt, (char *)text, _dpsP[39].length);
  DPSWriteStringChars(_dpsCurCtxt, (char *)text, _dpsP[13].length);
  DPSWriteStringChars(_dpsCurCtxt, (char *)text, _dpsP[6].length);
  DPSAwaitReturnValues(_dpsCurCtxt);
}
#line 53 "text.psw"

#line 295 "text.c"
void psw_get_text_element_bbox(x, y, text, bbox)
float x, y; char *text; float bbox[]; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char sizeFlag;
    unsigned short topLevelCount;
    unsigned int nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjReal obj1;
    DPSBinObjReal obj2;
    DPSBinObjGeneric obj3;
    DPSBinObjGeneric obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjGeneric obj9;
    DPSBinObjGeneric obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjGeneric obj12;
    DPSBinObjGeneric obj13;
    DPSBinObjGeneric obj14;
    DPSBinObjGeneric obj15;
    DPSBinObjGeneric obj16;
    DPSBinObjGeneric obj17;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 0, 18, 152,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 111},	/* newpath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 107},	/* moveto */
    {DPS_LITERAL|DPS_STRING, 0, 0, 144},	/* param text */
    {DPS_LITERAL|DPS_BOOL, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 17},	/* charpath */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 68},	/* flattenpath */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 115},	/* pathbbox */
    {DPS_LITERAL|DPS_INT, 0, 0, 4},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 9},	/* array */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 11},	/* astore */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 1},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 70},	/* flush */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  register int _dps_offset = 144;
  static DPSResultsRec _dpsR[] = {
    { dps_tFloat },
    };
    _dpsR[0].count = 4;
    _dpsR[0].value = (char *)bbox;


  _dpsP[1].val.realVal = x;
  _dpsP[2].val.realVal = y;
  _dpsP[4].length = strlen(text);
  _dpsP[4].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[4].length;

  _dpsF.nBytes = _dps_offset+8;
  DPSSetResultTable(_dpsCurCtxt, _dpsR, 1);
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,152);
  DPSWriteStringChars(_dpsCurCtxt, (char *)text, _dpsP[4].length);
  DPSAwaitReturnValues(_dpsCurCtxt);
}
#line 59 "text.psw"

#line 369 "text.c"
void psw_get_font_bbox(bbox)
float bbox[]; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjGeneric obj3;
    DPSBinObjGeneric obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjGeneric obj9;
    DPSBinObjGeneric obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjGeneric obj12;
    DPSBinObjGeneric obj13;
    DPSBinObjGeneric obj14;
    DPSBinObjGeneric obj15;
    DPSBinObjGeneric obj16;
    DPSBinObjGeneric obj17;
    DPSBinObjGeneric obj18;
    DPSBinObjGeneric obj19;
    DPSBinObjGeneric obj20;
    DPSBinObjGeneric obj21;
    DPSBinObjGeneric obj22;
    DPSBinObjGeneric obj23;
    DPSBinObjGeneric obj24;
    DPSBinObjGeneric obj25;
    DPSBinObjGeneric obj26;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 27, 220,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 32},	/* currentfont */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* FontBBox */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 75},	/* get */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 56},	/* dup */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 75},	/* get */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 56},	/* dup */
    {DPS_LITERAL|DPS_INT, 0, 0, 1},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 75},	/* get */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 56},	/* dup */
    {DPS_LITERAL|DPS_INT, 0, 0, 2},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 75},	/* get */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 56},	/* dup */
    {DPS_LITERAL|DPS_INT, 0, 0, 3},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 75},	/* get */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 1},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 70},	/* flush */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  static DPSResultsRec _dpsR[] = {
    { dps_tFloat },
    };
    _dpsR[0].count = 4;
    _dpsR[0].value = (char *)bbox;

  {
  static int _dpsT = 1;

  if (_dpsT) {
    static char *_dps_names[] = {
	"FontBBox"};
    int *_dps_nameVals[1];
    _dps_nameVals[0] = (int *)&_dpsP[1].val.nameVal;

    DPSMapNames(_dpsCurCtxt, 1, (char **) _dps_names, _dps_nameVals);
    _dpsT = 0;
    }
  }


  DPSSetResultTable(_dpsCurCtxt, _dpsR, 1);
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,220);
  DPSAwaitReturnValues(_dpsCurCtxt);
}
#line 67 "text.psw"

#line 465 "text.c"
void psw_get_font_matrix(matrix)
float matrix[]; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char topLevelCount;
    unsigned short nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjGeneric obj1;
    DPSBinObjGeneric obj2;
    DPSBinObjGeneric obj3;
    DPSBinObjGeneric obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjGeneric obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 9, 76,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 32},	/* currentfont */
    {DPS_LITERAL|DPS_NAME, 0, 0, 0},	/* FontMatrix */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 75},	/* get */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 1},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 70},	/* flush */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  static DPSResultsRec _dpsR[] = {
    { dps_tFloat },
    };
    _dpsR[0].count = 6;
    _dpsR[0].value = (char *)matrix;

  {
  static int _dpsT = 1;

  if (_dpsT) {
    static char *_dps_names[] = {
	"FontMatrix"};
    int *_dps_nameVals[1];
    _dps_nameVals[0] = (int *)&_dpsP[1].val.nameVal;

    DPSMapNames(_dpsCurCtxt, 1, (char **) _dps_names, _dps_nameVals);
    _dpsT = 0;
    }
  }


  DPSSetResultTable(_dpsCurCtxt, _dpsR, 1);
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,76);
  DPSAwaitReturnValues(_dpsCurCtxt);
}
#line 71 "text.psw"

#line 525 "text.c"
void psw_calc_text_element_width(x, y, text, x_new, y_new)
float x, y; char *text; float *x_new, *y_new; 
{
  typedef struct {
    unsigned char tokenType;
    unsigned char sizeFlag;
    unsigned short topLevelCount;
    unsigned int nBytes;

    DPSBinObjGeneric obj0;
    DPSBinObjReal obj1;
    DPSBinObjReal obj2;
    DPSBinObjGeneric obj3;
    DPSBinObjGeneric obj4;
    DPSBinObjGeneric obj5;
    DPSBinObjReal obj6;
    DPSBinObjGeneric obj7;
    DPSBinObjGeneric obj8;
    DPSBinObjGeneric obj9;
    DPSBinObjReal obj10;
    DPSBinObjGeneric obj11;
    DPSBinObjGeneric obj12;
    DPSBinObjGeneric obj13;
    DPSBinObjGeneric obj14;
    DPSBinObjGeneric obj15;
    DPSBinObjGeneric obj16;
    DPSBinObjGeneric obj17;
    } _dpsQ;
  static _dpsQ _dpsF = {
    DPS_DEF_TOKENTYPE, 0, 18, 152,
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 111},	/* newpath */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 107},	/* moveto */
    {DPS_LITERAL|DPS_STRING, 0, 0, 144},	/* param text */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 166},	/* stringwidth */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: y */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 1},	/* add */
    {DPS_LITERAL|DPS_INT, 0, 0, 1},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_REAL, 0, 0, 0},	/* param: x */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 1},	/* add */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_LITERAL|DPS_INT, 0, 0, 0},
    {DPS_LITERAL|DPS_INT, 0, 0, 2},
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 119},	/* printobject */
    {DPS_EXEC|DPS_NAME, 0, DPSSYSNAME, 70},	/* flush */
    }; /* _dpsQ */
  register DPSContext _dpsCurCtxt = DPSPrivCurrentContext();
  register DPSBinObjRec *_dpsP = (DPSBinObjRec *)&_dpsF.obj0;
  register int _dps_offset = 144;
  static DPSResultsRec _dpsR[] = {
    { dps_tFloat, -1 },
    { dps_tFloat, -1 },
    };
    _dpsR[0].value = (char *)x_new;
    _dpsR[1].value = (char *)y_new;


  _dpsP[1].val.realVal =
  _dpsP[10].val.realVal = x;
  _dpsP[2].val.realVal =
  _dpsP[6].val.realVal = y;
  _dpsP[4].length = strlen(text);
  _dpsP[4].val.stringVal = _dps_offset;
  _dps_offset += _dpsP[4].length;

  _dpsF.nBytes = _dps_offset+8;
  DPSSetResultTable(_dpsCurCtxt, _dpsR, 2);
  DPSBinObjSeqWrite(_dpsCurCtxt,(char *) &_dpsF,152);
  DPSWriteStringChars(_dpsCurCtxt, (char *)text, _dpsP[4].length);
  DPSAwaitReturnValues(_dpsCurCtxt);
}
#line 79 "text.psw"

	