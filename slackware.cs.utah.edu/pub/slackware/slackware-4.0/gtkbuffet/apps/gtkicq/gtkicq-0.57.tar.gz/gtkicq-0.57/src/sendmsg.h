extern int search_wait;
extern ProgressData *search_pdata;
