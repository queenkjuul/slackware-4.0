extern void playsound( char *filename );
