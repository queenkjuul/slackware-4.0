#ifndef _DIALOG_H
#define _DIALOG_H

void OK_Box( char *header, char *message );

#endif
