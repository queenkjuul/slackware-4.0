GtkWidget *ChatWindowNew( int cindex, int sock );
