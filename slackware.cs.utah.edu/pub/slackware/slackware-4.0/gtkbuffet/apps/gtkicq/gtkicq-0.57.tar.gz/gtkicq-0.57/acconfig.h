#undef VERSION
#undef PACKAGE
#undef HAVE_LIBSM
