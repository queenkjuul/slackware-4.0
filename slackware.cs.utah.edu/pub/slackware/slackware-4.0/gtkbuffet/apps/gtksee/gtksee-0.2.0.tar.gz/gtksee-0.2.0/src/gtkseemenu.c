/*
 * GTK See -- a image viewer based on GTK+
 * Copyright (C) 1998 Hotaru Lee <hotaru@163.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "gtypes.h"
#include "gtkseemenu.h"

static GtkWidget *thumbnails_item, *small_icons_item, *details_item;

GtkWidget*
get_main_menu(GtkWidget *window)
{
	GtkWidget *menubar, *menu, *menu_item;
	GSList *group;
	
	menubar = gtk_menu_bar_new();
	gtk_widget_show(menubar);
	
	/* File menu */
	menu = gtk_menu_new();
	
	menu_item = gtk_menu_item_new_with_label("View");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_file_view), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("Refresh");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_file_refresh), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("About");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_file_about), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new();
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_widget_show(menu_item);

	menu_item = gtk_menu_item_new_with_label("Quit");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_file_quit), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("File");
	gtk_widget_show(menu_item);
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu_item), menu);
	gtk_menu_bar_append(GTK_MENU_BAR(menubar), menu_item);
	
	/* View menu */
	menu = gtk_menu_new();
	
	thumbnails_item = gtk_radio_menu_item_new_with_label(NULL, "Thumbnails");
	group = gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM(thumbnails_item));
	gtk_signal_connect(GTK_OBJECT(thumbnails_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_thumbnails), NULL);
	gtk_menu_append(GTK_MENU(menu), thumbnails_item);
	gtk_widget_show(thumbnails_item);
	
	small_icons_item = gtk_radio_menu_item_new_with_label(group, "Small icons");
	group = gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM(small_icons_item));
	gtk_signal_connect(GTK_OBJECT(small_icons_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_small_icons), NULL);
	gtk_menu_append(GTK_MENU(menu), small_icons_item);
	gtk_widget_show(small_icons_item);
	
	details_item = gtk_radio_menu_item_new_with_label(group, "Details");
	group = gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM(details_item));
	gtk_signal_connect(GTK_OBJECT(details_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_details), NULL);
	gtk_menu_append(GTK_MENU(menu), details_item);
	gtk_widget_show(details_item);
	
	menu_item = gtk_menu_item_new();
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_widget_show(menu_item);

	menu_item = gtk_check_menu_item_new_with_label("Hide non-images");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_hide), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_check_menu_item_new_with_label("Fast preview");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_preview), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("View");
	gtk_widget_show(menu_item);
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu_item), menu);
	gtk_menu_bar_append(GTK_MENU_BAR(menubar), menu_item);
	
	return menubar;
}

void
menu_set_list_type(ImageListType type)
{
	switch (type)
	{
	  case IMAGE_LIST_THUMBNAILS:
		gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(thumbnails_item), TRUE);
		break;
	  case IMAGE_LIST_SMALL_ICONS:
		gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(small_icons_item), TRUE);
		break;
	  case IMAGE_LIST_DETAILS:
	  default:
		gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(details_item), TRUE);
		break;
	}
}
