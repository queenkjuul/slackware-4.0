/*
 * GTK See -- a image viewer based on GTK+
 * Copyright (C) 1998 Hotaru Lee <hotaru@163.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "gtypes.h"
#include "scanline.h"
#include "imagelist.h"
#include "detect.h"
#include "dndviewport.h"
#include "viewertoolbar.h"
#include "viewerstatus.h"
#include "viewer.h"

#include "pixmaps/gtksee.xpm"
#include "pixmaps/blank.xpm"

#define MAX_WIDTH (gdk_screen_width()-10)
#define MAX_HEIGHT (gdk_screen_height()-80)

static GtkWidget *window, *imagelist;
static GdkImage *loaded_image;
static ImageInfo *current;
static gboolean fit_screen;
static GtkWidget *frame;
static RotateType rtype;
static gchar viewing_image[256];
static gboolean viewer_busy;
static GdkCursor *viewer_watch_cursor = NULL;

static gboolean slide_show;
static gint timeout_callback_tag;

void		view_current_image	();
void		viewer_set_busy_cursor	();
void		viewer_set_normal_cursor();
void		viewer_key_release	(GtkWidget *widget,
					 GdkEvent *event,
					 gpointer data);
void		viewer_slideshow_next	(gpointer data);

void
viewer_set_busy_cursor()
{
	if (!viewer_busy)
	{
		viewer_busy = TRUE;
		gdk_window_set_cursor(window->window, viewer_watch_cursor);
		while (gtk_events_pending()) gtk_main_iteration();
	}
}

void
viewer_set_normal_cursor()
{
	if (viewer_busy)
	{
		viewer_busy = FALSE;
		gdk_window_set_cursor(window->window, NULL);
	}
}

void
view_current_image()
{
	GtkWidget *viewport;
	gboolean too_big, need_scale;
	GList *list;
	gchar buffer[64];
	gint width, height, tmp;
	
	if (viewer_busy) return;

	viewer_set_busy_cursor();
	
	/* remove old image if exists */
	list = gtk_container_children(GTK_CONTAINER(frame));
	if (list != NULL && list->data != NULL)
	{
		gtk_container_remove(
			GTK_CONTAINER(frame),
			GTK_WIDGET(list->data));
	}
	if (loaded_image != NULL) gdk_image_destroy(loaded_image);
	loaded_image = NULL;
	
	/* setting window title */
	sprintf(buffer, "%s - GTK See", current->name);
	gtk_window_set_title(GTK_WINDOW(window), buffer);
	
	if (!current -> valid)
	{
		set_viewer_status_type(current->type_pixmap, current->type_mask);
		set_viewer_status_name(current->name);
		set_viewer_status_size(current->size);
		set_viewer_status_prop("Invalid");
		set_viewer_status_zoom(100);
		viewer_set_normal_cursor();
		return; 
	}
	
	/* setting status bar */
	set_viewer_status_type(current->type_pixmap, current->type_mask);
	set_viewer_status_name(current->name);
	set_viewer_status_size(current->size);
	image_convert_info(current, buffer);
	set_viewer_status_prop(buffer);

	strcpy(viewing_image, image_list_get_dir(IMAGE_LIST(imagelist)));
	if (viewing_image[strlen(viewing_image) - 1] != '/') strcat(viewing_image,"/");
	strcat(viewing_image, current->name);
	
	if (current -> width < 0)
	{
		if (detect_image_type(viewing_image ,current))
		{
			/* we should refresh the image info */
			image_convert_info(current, buffer);
			set_viewer_status_prop(buffer);
			image_list_update_info(IMAGE_LIST(imagelist), current);
		}
	}
		
	switch (rtype)
	{
		case ROTATE_90:
		case ROTATE_270:
			width = current->height;
			height = current->width;
			break;
		case ROTATE_180:
		case ROTATE_NONE:
		default:
			width = current->width;
			height = current->height;
			break;
	}
	too_big = (width > MAX_WIDTH || height > MAX_HEIGHT);
	need_scale = (fit_screen && too_big);
	
	viewport = dnd_viewport_new();
	if (need_scale)
	{
		if (MAX_WIDTH * height < MAX_HEIGHT * width)
		{
			set_viewer_status_zoom(MAX_WIDTH * 100 / width);
			tmp = width;
			width = MAX_WIDTH;
			height = width * height / tmp;
		} else
		{
			set_viewer_status_zoom(MAX_HEIGHT * 100 / height);
			tmp = height;
			height = MAX_HEIGHT;
			width = height * width / tmp;
		}
		gtk_widget_set_usize(
			viewport,
			width,
			height);
	} else
	{
		set_viewer_status_zoom(100);
		gtk_widget_set_usize(
			viewport,
			min(width,MAX_WIDTH),
			min(height,MAX_HEIGHT));
	}
	gtk_widget_show(viewport);
	gtk_container_add(GTK_CONTAINER(frame), viewport);
	
	/* allow the user to drag the viewport while displaying */
	gtk_grab_add(viewport);
	
	/* for slideshow: disable timeout temporarily before loading */
	if (slide_show)
	{
		gtk_timeout_remove(timeout_callback_tag);
	}
	
	/* creating new image */
	if (need_scale)
	{
		loaded_image = load_scaled_image(viewing_image, current,
			MAX_WIDTH, MAX_HEIGHT,
			rtype,
			window,
			viewport,
			(slide_show ? 0 : (SCANLINE_INTERACT | SCANLINE_DISPLAY)));
	} else
	{
		loaded_image = load_scaled_image(viewing_image, current,
			-1, -1,
			rtype,
			window,
			viewport,
			(slide_show ? 0 : (SCANLINE_INTERACT | SCANLINE_DISPLAY)));
	}
	gtk_grab_remove(viewport);
	if (slide_show)
	{
		timeout_callback_tag = gtk_timeout_add(
			SLIDESHOW_DELAY,
			(GtkFunction)viewer_slideshow_next, NULL);
	}
	viewer_set_normal_cursor();
}

void
viewer_toolbar_browse(GtkWidget *widget, gpointer data)
{
	if (viewer_busy) return;
	
	if (loaded_image != NULL) gdk_image_destroy(loaded_image);
	if (slide_show) gtk_timeout_remove(timeout_callback_tag);
	show_browser();
}

void
viewer_toolbar_next_image(GtkWidget *widget, gpointer data)
{
	ImageInfo *tmp;
	
	if (viewer_busy) return;
	
	tmp = image_list_get_next(IMAGE_LIST(imagelist), current);
	if (tmp == NULL) return;
	current = tmp;
	viewer_next_enable(image_list_get_next(IMAGE_LIST(imagelist), current) != NULL);
	viewer_prev_enable(image_list_get_previous(IMAGE_LIST(imagelist), current) != NULL);
	rtype = ROTATE_NONE;
	view_current_image();
}

void
viewer_toolbar_prev_image(GtkWidget *widget, gpointer data)
{
	ImageInfo *tmp;
	
	if (viewer_busy) return;
	
	tmp = image_list_get_previous(IMAGE_LIST(imagelist), current);
	if (tmp == NULL) return;
	current = tmp;
	viewer_next_enable(image_list_get_next(IMAGE_LIST(imagelist), current) != NULL);
	viewer_prev_enable(image_list_get_previous(IMAGE_LIST(imagelist), current) != NULL);
	rtype = ROTATE_NONE;
	view_current_image();
}

void
viewer_toolbar_fitscreen_toggled(GtkWidget *widget, gpointer data)
{
	if (viewer_busy) return;

	fit_screen = GTK_TOGGLE_BUTTON(widget)->active;
	view_current_image();
}

void
viewer_toolbar_slideshow_toggled(GtkWidget *widget, gpointer data)
{
	slide_show = GTK_TOGGLE_BUTTON(widget)->active;
	if (slide_show)
	{
		timeout_callback_tag = gtk_timeout_add(
			SLIDESHOW_DELAY,
			(GtkFunction)viewer_slideshow_next, NULL);
	} else
	{
		gtk_timeout_remove(timeout_callback_tag);
	}
}

void
viewer_slideshow_next(gpointer data)
{
	ImageInfo *tmp;
	
	if (viewer_busy) return;
	
	tmp = image_list_get_next(IMAGE_LIST(imagelist), current);
	if (tmp == NULL) current = image_list_get_first(IMAGE_LIST(imagelist));
	else current = tmp;
	viewer_next_enable(image_list_get_next(IMAGE_LIST(imagelist), current) != NULL);
	viewer_prev_enable(image_list_get_previous(IMAGE_LIST(imagelist), current) != NULL);
	rtype = ROTATE_NONE;
	view_current_image();
}

void
viewer_toolbar_rotate_left(GtkWidget *widget, gpointer data)
{
	if (viewer_busy) return;

	rtype = (rtype - 1 + MAX_ROTATE_TYPES) % MAX_ROTATE_TYPES;
	view_current_image();
}

void
viewer_toolbar_rotate_right(GtkWidget *widget, gpointer data)
{
	if (viewer_busy) return;

	rtype = (rtype + 1) % MAX_ROTATE_TYPES;
	view_current_image();
}

void
viewer_toolbar_refresh(GtkWidget *widget, gpointer data)
{
	view_current_image();
}

void
viewer_key_release(GtkWidget *widget, GdkEvent *event, gpointer data)
{
	if (viewer_busy) return;
	
	switch (event->key.keyval)
	{
	  case GDK_Home:
		current = image_list_get_first(IMAGE_LIST(imagelist));
		viewer_next_enable(image_list_get_next(IMAGE_LIST(imagelist), current) != NULL);
		viewer_prev_enable(FALSE);
		rtype = ROTATE_NONE;
		view_current_image();
		break;
	  case GDK_End:
		current = image_list_get_last(IMAGE_LIST(imagelist));
		viewer_next_enable(FALSE);
		viewer_prev_enable(image_list_get_previous(IMAGE_LIST(imagelist), current) != NULL);
		rtype = ROTATE_NONE;
		view_current_image();
		break;
	  case GDK_Page_Up:
		viewer_toolbar_prev_image(widget, NULL);
		break;
	  case GDK_Page_Down:
		viewer_toolbar_next_image(widget, NULL);
		break;
	  case GDK_Escape:
		viewer_toolbar_browse(widget, NULL);
	  default:
		break;
	}
}

GtkWidget*
get_viewer_window(GtkWidget *il)
{
	GtkWidget *toolbar, *table, *statusbar;
	GdkPixmap *pixmap;
	GdkBitmap *mask;
	GtkStyle *style;
	GdkEventMask event_mask;
	
	/* creating viewer window */
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_signal_connect (GTK_OBJECT(window), "delete_event",
		GTK_SIGNAL_FUNC(gtk_main_quit), NULL);
	gtk_container_border_width(GTK_CONTAINER(window), 2);
	gtk_window_set_policy(GTK_WINDOW(window), FALSE, TRUE, TRUE);
	
	gtk_window_set_title(GTK_WINDOW(window), "GTK See");
	gtk_window_set_wmclass(GTK_WINDOW(window), "viewer", "GTKSee");
	event_mask = gtk_widget_get_events(window);
	event_mask |= GDK_KEY_PRESS_MASK | GDK_KEY_RELEASE_MASK;
	gtk_widget_set_events(window, event_mask);
	gtk_signal_connect(
		GTK_OBJECT(window),
		"key_release_event",
		GTK_SIGNAL_FUNC(viewer_key_release),
		NULL);
	gtk_widget_set_uposition(window, 0, 0);
	
	gtk_widget_realize(window);
	
	style = gtk_widget_get_style(window);
	pixmap = gdk_pixmap_create_from_xpm_d(
		window->window,
		&mask, &style->bg[GTK_STATE_NORMAL],
		(gchar **)gtksee_xpm);
	gdk_window_set_icon(window->window, NULL, pixmap, mask);
	gdk_window_set_icon_name(window->window, "GTK See Icon");
	
	/* creating toolbar */
	toolbar = get_viewer_toolbar(window);
	gtk_widget_show(toolbar);
	
	/* creating frame */
	frame = gtk_frame_new(NULL);
	gtk_widget_show(frame);
	
	/* creating viewer statusbar */
	pixmap = gdk_pixmap_create_from_xpm_d(
		window->window,
		&mask, &style->bg[GTK_STATE_NORMAL],
		(gchar **)blank_xpm);
	statusbar = get_viewer_status_bar(pixmap, mask);
	gtk_widget_show(statusbar);
	
	/* creating viewer table */
	table = gtk_table_new(3, 1, FALSE);
	gtk_widget_show(table);
	
	/* adding toolbar, frame & statusbar into table */
	gtk_table_attach(GTK_TABLE(table), toolbar, 0, 1, 0, 1, GTK_FILL|GTK_EXPAND, 0, 0, 2);
	gtk_table_attach_defaults(GTK_TABLE(table), frame, 0, 1, 1, 2);
	gtk_table_attach(GTK_TABLE(table), statusbar, 0, 1, 2, 3, GTK_FILL|GTK_EXPAND, 0, 0, 2);
	
	/* adding table into viewer window */
	gtk_widget_unrealize(window);
	gtk_container_add(GTK_CONTAINER(window), table);
	gtk_widget_show(window);
	
	/* setting pointers and values... */
	imagelist = il;
	rtype = ROTATE_NONE;
	if (viewer_watch_cursor == NULL)
	{
		viewer_watch_cursor = gdk_cursor_new(GDK_WATCH);
	}
	
	/* view the selected image if selected,
	 * otherwise, view the first.
	 */
	current = image_list_get_selected(IMAGE_LIST(imagelist));
	if (current == NULL || !current->valid || current->width < 0)
		current = image_list_get_first(IMAGE_LIST(imagelist));
	gtk_widget_show(window);
	
	fit_screen = FALSE;
	slide_show = FALSE;
	loaded_image = NULL;
	
	viewer_next_enable(image_list_get_next(IMAGE_LIST(imagelist), current) != NULL);
	viewer_prev_enable(image_list_get_previous(IMAGE_LIST(imagelist), current) != NULL);
	view_current_image();
	
	viewer_busy = FALSE;
	
	return window;
}
