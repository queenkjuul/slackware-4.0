//
// w_control.cc
//
// Control window for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.1.18
//


#include <iostream.h>
#include <time.h>

#include "w_control.h"
#include "map.h"
#include "w_sky_prefs.h"
#include "w_lighting_prefs.h"
#include "w_trees_prefs.h"
#include "w_preview_prefs.h"
#include "w_render_prefs.h"
#include "w_palette_prefs.h"


//
// Menufactory stuff...
//

static GtkMenuEntry menu_items[] =
{
	{ "<Main>/File/About",							0,	0,	0 },
	{ "<Main>/File/<separator>",					0,	0,	0 },
	{ "<Main>/File/Quit",							0,	0,	0 },
	{ "<Main>/Windows/Preview",						0,	0,	0 },
	{ "<Main>/Windows/Output",						0,	0,	0 },
	{ "<Main>/Preferences/Sky...",					0,	0,	0 },
	{ "<Main>/Preferences/Lighting...",				0,	0,	0 },
	{ "<Main>/Preferences/Trees...",				0,	0,	0 },
	{ "<Main>/Preferences/Preview...",				0,	0,	0 },
	{ "<Main>/Preferences/Rendering...",			0,	0,	0 },
	{ "<Main>/Preferences/Palette...",				0,	0,	0 },
//	{ "<Main>/Preferences/Pref2/Pointless sub 1",	0,	0,	0 },
//	{ "<Main>/Preferences/Pref2/Pointless sub 2",	0,	0,	0 }
};

static int nmenu_items = sizeof(menu_items)/sizeof(menu_items[0]);




//
// Constructor/destructors
//
w_control::w_control(void)
{
	debug("Called w_control constructor");

	set_title("Control");
	d_pixmap = 0;

	// Initalise a few bits and pieces...
	settings.order = 6;
	settings.map_size = int (pow(2, settings.order));
	settings.fract_dimen = 0.65;

	// Default size for render window
	settings.output_width = 480;
	settings.output_height = 360;
	
	settings.type = GOURAUD;

	// Initialise window states...
	settings.preview = true;
	settings.output = true;
	settings.prefs_sky = false;
	settings.prefs_lighting = false;
	settings.prefs_trees = false;
	settings.prefs_preview = false;
	settings.prefs_rendering = false;
}


w_control::~w_control(void)
{
	debug("Called w_control destructor");

	// Close any other opened windows...
	delete preview_win;
	delete output_win;
	delete preview_win;
}


//
// Open main window and set up widgets...
//
int w_control::open_windows(void)
{
	// Set control window size...
//	set_usize(460, 280);

	// A partially successful attempt to disallow resizing
	set_policy(0, 0, 0);

	// Container related japes...
	main_box = new Gtk_VBox(FALSE, 0);
	main_box->border_width(0);
	add(main_box);
	main_box->show();


	// Do menu...
	mfactory = new Gtk_MenuFactory(GTK_MENU_FACTORY_MENU_BAR);
	submfactory = new Gtk_MenuFactory(GTK_MENU_FACTORY_MENU_BAR);
	mfactory->add_subfactory(submfactory,"<Main>");
	mfactory->add_entries(menu_items,nmenu_items);

	mfactory->add_entry("<Main>/File/Quit", "Q",
					MenuFactoryConnector<w_control, char *>(this,
					&menu_quit_callback, "Connected to method"));
	mfactory->add_entry("<Main>/File/About", "A",
					MenuFactoryConnector<w_control, char *>(this,
					&menu_about_callback, "Connected to method"));
	mfactory->add_entry("<Main>/Windows/Preview", "P",
					MenuFactoryConnector<w_control, char *>(this,
					&menu_preview_callback, "Connected to method"));
	mfactory->add_entry("<Main>/Windows/Output", "O",
					MenuFactoryConnector<w_control, char *>(this,
					&menu_output_callback, "Connected to method"));

	mfactory->add_entry("<Main>/Preferences/Sky...", "",
					MenuFactoryConnector<w_control, char *>(this,
					&prefs_sky_callback, "Connected to method"));
	mfactory->add_entry("<Main>/Preferences/Lighting...", "",
					MenuFactoryConnector<w_control, char *>(this,
					&prefs_lighting_callback, "Connected to method"));
	mfactory->add_entry("<Main>/Preferences/Trees...", "",
					MenuFactoryConnector<w_control, char *>(this,
					&prefs_trees_callback, "Connected to method"));
	mfactory->add_entry("<Main>/Preferences/Preview...", "",
					MenuFactoryConnector<w_control, char *>(this,
					&prefs_preview_callback, "Connected to method"));
	mfactory->add_entry("<Main>/Preferences/Rendering...", "",
					MenuFactoryConnector<w_control, char *>(this,
					&prefs_rendering_callback, "Connected to method"));
	mfactory->add_entry("<Main>/Preferences/Palette...", "",
					MenuFactoryConnector<w_control, char *>(this,
					&prefs_palette_callback, "Connected to method"));


	mbar = new Gtk_MenuBar(GTK_MENU_BAR(submfactory->gtkobj()->widget));
	main_box->pack_start(mbar, FALSE, FALSE, 0);
	mbar->show();


	// All boxes packed into one big HBox...
	horiz_box = new Gtk_HBox(FALSE, 0);
	horiz_box->border_width(4);
	main_box->pack_start(horiz_box);
	horiz_box->show();


	// Relief window box...
	left_box = new Gtk_VBox(FALSE, 4);
	left_box->border_width(4);
	horiz_box->add(left_box);
	left_box->show();

	sep = new Gtk_VSeparator;
	horiz_box->add(sep);
	sep->show();

	// Generation controls box...
	right_box = new Gtk_VBox(FALSE, 4);
	right_box->border_width(4);
	horiz_box->add(right_box);
	right_box->show();

	//..controls..
	control_box = new Gtk_VBox(FALSE, 4);
	control_box->border_width(4);
	right_box->add(control_box);
	control_box->show();

	// ..and buttons..
	bottom_box = new Gtk_HBox(TRUE, 0);
	bottom_box->border_width(4);
	//right_box->add(bottom_box);
	right_box->pack_start(bottom_box, FALSE, FALSE, 0);
	bottom_box->show();

	// Install relief view...
	relief_drawing_area  = new w_relief_drawingarea;
	relief_drawing_area->set_events(GDK_EXPOSURE_MASK);
	relief_drawing_area->size(RELIEF_MAP_SIZE, RELIEF_MAP_SIZE);
	left_box->add(relief_drawing_area);
	relief_drawing_area->show();

	// Make a frame for controls... 
	f1 = new Gtk_Frame("Controls");
	control_box->pack_start(f1, TRUE, TRUE, 2);

	// Stick a box in it...
	frame_box = new Gtk_VBox(FALSE, 4);
	f1->add(frame_box);
	frame_box->show();

	// Fractal dimension slider...
	Gtk_HBox *fd_box = new Gtk_HBox(FALSE, 0);
	fd_box->show();
	frame_box->add(fd_box);

	adj_dimen = new Gtk_Adjustment(0.65,	// Value
									 0.0,	// Lower
									 2.0,	// Upper
									 0.01,	// Step increment
									 0.01,	// Page increment
									 1.0);	// Page size
	sc_dimen = new Gtk_HScale(adj_dimen);
//	sc_dimen->set_usize(80,40);
	sc_dimen->set_update_policy(GTK_UPDATE_DELAYED);
	sc_dimen->set_draw_value(TRUE);
	sc_dimen->set_digits(2);
	sc_dimen->show();

 	l_dimen = new Gtk_Label("Fract dimension ");
	l_dimen->show();

	fd_box->pack_start(l_dimen, TRUE, TRUE, 0);
	fd_box->pack_start(sc_dimen, TRUE, TRUE, 0);
	connect_to_method(adj_dimen->value_changed, this, &dimen_callback);


	// Fractal size slider...
	Gtk_HBox *fs_box = new Gtk_HBox(FALSE, 0);
	fs_box->show();
	frame_box->add(fs_box);
	adj_size = new Gtk_Adjustment(settings.order,	// Value
									 1.0,	// Lower
									 9.0,	// Upper
									 1.0,	// Step increment
									 1.0,	// Page increment
									 1.0);	// Page size
	sc_size = new Gtk_HScale(adj_size);
//	sc_size->set_usize(80,40);
	sc_size->set_update_policy(GTK_UPDATE_DELAYED);
	sc_size->set_draw_value(TRUE);
	sc_size->set_digits(0);
	sc_size->show();

	l_size = new Gtk_Label("Fractal size");
	l_size->show();

	fs_box->pack_start(l_size, TRUE, TRUE, 0);
	fs_box->pack_start(sc_size, TRUE, TRUE, 0);
	connect_to_method(adj_size->value_changed, this, &size_callback);


	// Set up buttons...
	randomise_button = new Gtk_Button("Randomise");
	generate_button = new Gtk_Button("Generate");
	render_button = new Gtk_Button("Render");
	quit_button = new Gtk_Button("Quit");

	connect_to_method(generate_button->clicked, this, &generate_callback);
	connect_to_method(randomise_button->clicked, this, &randomise_callback);
	connect_to_method(render_button->clicked, this, &render_callback);
	connect_to_method(quit_button->clicked, this, &quit_callback);


	bottom_box->pack_start(randomise_button, TRUE, TRUE, 0);
	bottom_box->pack_start(generate_button, TRUE, TRUE, 0);
	bottom_box->pack_start(render_button, TRUE, TRUE, 0);
	bottom_box->pack_start(quit_button, TRUE, TRUE, 0);

	randomise_button->show();
	generate_button->show();
	render_button->show();
	quit_button->show();

	bottom_box->show();
	f1->show();


	// Open other windows...
	preview_win = new w_preview;
	preview_win->open_window(settings.map_size);
	preview_win->show();

	output_win = new w_output;
	output_win->open_window(settings.output_width, settings.output_height);
	output_win->show();

	// Initialise and render a 'flat' map
	srand(seed);
	relief_map = new fbm_map(RELIEF_MAP_ORDER);
	srand(seed);
	preview_map = new fbm_map(settings.order);
	preview_win->render(preview_map->get_data(), settings.map_size);

	// All okay
	return 0;	
}


//
// Callbacks for buttons...
//
void w_control::generate_callback(void)
{
	// Reseed random generator...
	clock_t t;
	time(&t);

	seed = t;
	srand(seed);

	// Nuke any previous map...
	delete relief_map;
	delete preview_map;
	srand(seed);
	relief_map = new fbm_map(RELIEF_MAP_ORDER, settings.fract_dimen);
	srand(seed);
	preview_map = new fbm_map(settings.order, settings.fract_dimen);

	// Should render the preview to the relief window...
//	relief_win->render(relief_map->get_data(), RELIEF_MAP_SIZE);
	render_relief(relief_map->get_data());
	preview_win->render(preview_map->get_data(), settings.map_size);

}


void w_control::quit_callback(void)
{
	gtk_main_quit();
}


void w_control::randomise_callback(void)
{
	//g_print("Randomise button selected\n");

	clock_t t;
	time(&t);

	// Update seed value
	seed = t;
	srand(seed);
}


void w_control::render_callback(void)
{
	// To allow rerendering at different detail levels, we need to
	//  reseed the generator with the same value
	srand(seed);

	// Render to output window...
	float a, b, c;
	preview_win->get_rotation(&a, &b, &c);
	output_win->set_rotation(a, b, c);
	output_win->render(settings.map_size, settings.fract_dimen, settings.type);
}


// Called when fractal dimension slider is changed...
void w_control::dimen_callback(void)
{
	settings.fract_dimen = (GTK_ADJUSTMENT(adj_dimen->gtkobject)->value);
}


// Called when fractal size slider is moved...
void w_control::size_callback(void)
{
	settings.order = int ((GTK_ADJUSTMENT(adj_size->gtkobject)->value));
	settings.map_size = int (pow(2, settings.order));

	// Initialise and render a 'flat' map
	delete relief_map;
	delete preview_map;
	srand(seed);
	relief_map = new fbm_map(RELIEF_MAP_ORDER);
//	relief_win->render(relief_map->get_data(), RELIEF_MAP_SIZE);
	srand(seed);
	preview_map = new fbm_map(settings.order);
	preview_win->render(preview_map->get_data(), settings.map_size);

}



//
// Various callbacks
//
void w_control::menu_quit_callback(char *data)
{
	cout << "Called menu_quit_callback() " << endl;
	Gtk_Main::instance()->quit();
}


void w_control::menu_about_callback(char *data)
{
	cout << "Called menu_about_callback() " << endl;
}


void w_control::menu_preview_callback(char *data)
{
	cout << "Called menu_preview_callback()" << endl;

	if (settings.preview) {
		preview_win->hide();
		settings.preview = false;
	} else {
		preview_win->show();
		settings.preview = true;
	}

}


void w_control::menu_output_callback(char *data)
{
	cout << "Called menu_output_callback()" << endl;

	if (settings.output) {
		output_win->hide();
		settings.output = false;
	} else {
		output_win->show();
		settings.output = true;
	}
}


void w_control::render_relief(const float *relief)
{
	int size = RELIEF_MAP_SIZE;

	guint16 *buf = (guint16 *) relief_drawing_area->d_image->mem;
	int index = 0;
	for (int y=0; y<size; y++) {
		for (int x=0; x<size; x++) {
			int height = int (relief[index++]*10);
			if (height < 0){
				plot(buf, 0, 0, 0xffff);			// blue
			} else if (height < 3) {
				plot(buf, 0, 0xffff, 0);			// green
			} else if (height < 6) {
				plot(buf, 35584, 17664, 4864);		// brown
			} else {
				plot(buf, 0xffff, 0xffff, 0xffff);	// white
			}
			buf++;
		}
		index++;		// Generated map is [size+1][size+1], so skip pixel per line
	}

	// Tell gtk to update rendered image...
	GdkRectangle update_rect;
	update_rect.x = 0;
	update_rect.y = 0;
	update_rect.width = GTK_WIDGET(gtkobject)->allocation.width;
	update_rect.height = GTK_WIDGET(gtkobject)->allocation.height;

	gtk_widget_draw(GTK_WIDGET(gtkobject), &update_rect);
}



//
// Quick and dirty way to poke pixels directly into screen memory
//
void w_control::plot(guint16 *buf, guint32 r, guint32 g, guint32 b) {
	guint32 rgb;
	rgb =	( (((r) >> 11) << 11)		// 5 bits of red
			| (((g) >> 10) <<  5)		// 6 bits of green
			| (((b) >> 11) <<  0));		// 5 bits of blue
	*buf = rgb;
}



void w_control::prefs_sky_callback(char *data)
{
	if (!settings.prefs_sky) {
		w_sky_prefs *wsp = new w_sky_prefs;
		wsp->show();
		settings.prefs_sky = true;
	}
}


void w_control::prefs_lighting_callback(char *data)
{
	if (!settings.prefs_lighting) {
		w_lighting_prefs *wlp = new w_lighting_prefs;
		wlp->show();
		settings.prefs_lighting = true;
	}
}


void w_control::prefs_trees_callback(char *data)
{
	if (!settings.prefs_trees) {
		w_trees_prefs *wtp = new w_trees_prefs;
		wtp->show();
		settings.prefs_trees = true;
	}
}


void w_control::prefs_preview_callback(char *data)
{
	if (!settings.prefs_preview) {
		w_preview_prefs *wpp = new w_preview_prefs;
		wpp->show();
		settings.prefs_preview = true;
	}
}


Connection c;

void w_control::prefs_rendering_callback(char *data)
{
	if (!settings.prefs_rendering) {
		wrp = new w_render_prefs((const str_settings& ) settings);
		wrp->show();
		settings.prefs_rendering = true;
		c = connect_to_method(wrp->sig_button_pressed, this, &prefs_rendering_button);
	}
}

void w_control::prefs_rendering_button(enum_button b)
{
	// Deal with button press appropriately
	switch (b) {
		case OK:
			settings.type = wrp->get_render_type();
			settings.prefs_rendering = false;
			break;
		case APPLY:
			settings.type = wrp->get_render_type();
			break;
		case CANCEL:
			settings.prefs_rendering = false;
			break;
	}
}


void w_control::prefs_palette_callback(char *data)
{
	if (!settings.prefs_palette) {
		w_palette_prefs *wpp = new w_palette_prefs;
		wpp->show();
		settings.prefs_palette = true;
		//c = connect_to_method(wpp->sig_button_pressed, this, &prefs_palette_button);
	}
}




