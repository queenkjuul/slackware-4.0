//
// terrain.cc
//
// Create a fractal landscape object
//
// Copyright (c) J. Belson	1997.12.16
//


#include <iostream.h>
#include <math.h>

#include <gtk--.h>

#include "terrain.h"


// Creates and initialises a terrain object
// On entry:	size is the map width as 2^size
terrain::terrain(void)
{
	debug("Terrain constructor called");

	// Initialise degrees of rotation
	x_rot = y_rot = z_rot = 0.0;

}


terrain::~terrain()
{
	debug("Terrain destructor called");

	// Free any point data we allocated...
	delete [] model.data;
	delete [] model.tri;
}


// Get current rotation
void terrain::get_rotation(float *a, float *b, float *c)
{

	*a = x_rot;
	*b = y_rot;
	*c = z_rot;

}


// Create a terrain object from the fbm_map
// On entry		- relief is pointer to array of height fields
//				  size is the width of the map
int terrain::generate_terrain(const float *relief, int size)
{
	debug("Generating terrain object");

	// Store pointer to height field
	height_field = relief;

	map_size = size;
	model.size = size;

	// Calculate terrain position in world from size
	xpos = 0.0;
	ypos = -size/2.0;
	zpos = size*1.25;

	// Populate model structure with data from height data...
	model.num_tri = 0;
	int idx = 0;
	model.data = new struct point [size*size];


	transform(0.0, 0.0, 0.0);


	float thresh1, thresh2, thresh3;
	thresh1 = -(size/2);
	thresh2 = thresh1 * 0.9375;
	thresh3 = thresh1 * 0.875;

	// ...now fill in triangle structures...
	model.tri = new struct str_tri [2 * size*size];
	idx = 0;
	int src=0;
	for (int y=0; y<size-1; y++) {
		for (int x=0; x<size; x++) {
			// Don't want to split triangle across landscape (cuz it looks stupid)
			if (x != size-1) {
				//
				// First triangle...
				//
				model.tri[idx].v1 = src;
				model.tri[idx].v2 = src + 1;
				model.tri[idx].v3 = src + size + 1;
				normal_vector(&model.tri[idx]);
				
				// Colour according to lowest point
				float y = model.data[model.tri[idx].v1].y;
				if (y < model.data[model.tri[idx].v2].y) {
					y = model.data[model.tri[idx].v2].y;
				}
				if (y < model.data[model.tri[idx].v3].y) {
					y = model.data[model.tri[idx].v3].y;
				}
				guint32 r, g, b;
				if (y <= thresh1) {
					r = 0; g = 0; b = 0xffff;
				} else if (y < thresh2){
					r = 0; g = 0xb000; b = 0;
				} else if (y < thresh3) {
					r = 35584; g = 17664; b = 4864;
				} else {
					r = 0xffff; g = 0xffff; b = 0xffff;
				}

				model.tri[idx].col.r = r;
				model.tri[idx].col.g = g;
				model.tri[idx].col.b = b;

				model.num_tri++;
				idx++;

				//
				// Second triangle...
				//
				model.tri[idx].v1 = src;
				model.tri[idx].v2 = src + size + 1;
				model.tri[idx].v3 = src + size;
				normal_vector(&model.tri[idx]);

				// Colour according to lowest point
				y = model.data[model.tri[idx].v1].y;
				if (y < model.data[model.tri[idx].v2].y) {
					y = model.data[model.tri[idx].v2].y;
				}
				if (y < model.data[model.tri[idx].v3].y) {
					y = model.data[model.tri[idx].v3].y;
				}
				if (y <= thresh1) {
					r = 0; g = 0; b = 0xffff;
				} else if (y < thresh2){
					r = 0; g = 0xb000; b = 0;
				} else if (y < thresh3) {
					r = 35584; g = 17664; b = 4864;
				} else {
					r = 0xffff; g = 0xffff; b = 0xffff;
				}

				model.tri[idx].col.r = r;
				model.tri[idx].col.g = g;
				model.tri[idx].col.b = b;

				model.num_tri++;
				idx++;

			}
			src++;
		}
	}


	return 0;
}



//
// Transform the terrain object from original data according to
//  current rotation/translation values
void terrain::transform(float a, float b, float c)
{
	debug("terrain::transform()");

	// Update terrain's local rotation
	x_rot += a;
	y_rot += b;
	z_rot += c;	

	// Repopulate model structure with data from height data...
	//model.data = new struct point [size*size];
	//model.num_tri = 0;
	int src_x, src_z;
	src_z = 0;
	int idx = 0;
	for (int z=map_size/2; z>-map_size/2; z--) {
		src_x = 0;
		for (int x=-map_size/2; x<map_size/2; x++) {
			model.data[idx].x = x;
			model.data[idx].y = map_size*0.19*height_field[index(src_x, src_z)];
			model.data[idx].z = z;

			idx++;
			src_x++;
		}
		src_z++;
	}

	// Apply transformation...
	rotate();
	translate(xpos, ypos, zpos);

	// Update surface normals
	for (int i=0; i<model.num_tri; i++) {
		normal_vector(&model.tri[i]);
	}

}



// Rotate terrain object b current object
// Currently doing it the easy way, will probably
//  switch to matricies later.
void terrain::rotate()
{
	int index = 0;
	int size = model.size;

	// Rotate about y axis
	for (int i=0; i<(size)*(size); i++) {
		float old_x = model.data[index].x;
		float old_z = model.data[index].z;
		model.data[index].x = old_x*cos(y_rot) + old_z*sin(y_rot);
		model.data[index].z = -old_x*sin(y_rot) + old_z*cos(y_rot);
		index++;
	}
}


// Translate terrain object by (x, y, z), leveling off at sea level
// Currently doing it the easy way, will probably
//  switch to matricies later.
void terrain::translate(float x, float y, float z)
{
	int index = 0;
	int size = model.size;

	for (int i=0; i<(size)*(size); i++) {
		model.data[index].x += x;
		if (model.data[index].y < 0.0) {
			model.data[index].y = y;
		} else {
			model.data[index].y += y;
		}
		model.data[index].z += z;
		index++;
	}
}


//
// Calculate normal vector for triangle
//
void terrain::normal_vector(str_tri *tri)
{
	struct point v1, v2;

	float x1, y1, z1, x2, y2, z2, x3, y3, z3;

	x1 = model.data[tri->v1].x;
	y1 = model.data[tri->v1].y;
	z1 = model.data[tri->v1].z;

	x2 = model.data[tri->v2].x;
	y2 = model.data[tri->v2].y;
	z2 = model.data[tri->v2].z;

	x3 = model.data[tri->v3].x;
	y3 = model.data[tri->v3].y;
	z3 = model.data[tri->v3].z;

	v1.x = x1 - x2;
	v1.y = y1 - y2;
	v1.z = z1 - z2;

	v2.x = x3 - x2;
	v2.y = y3 - y2;
	v2.z = z3 - z2;

	tri->normal.x = (v1.y*v2.z) - (v1.z*v2.y);
	tri->normal.y = (v1.z*v2.x) - (v1.x*v2.z);
	tri->normal.z = (v1.x*v2.y) - (v1.y*v2.x);

}
