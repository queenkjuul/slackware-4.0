//
// Various structures
//
// Copyright (c) J. Belson	1998.3.14
//


#ifndef _STRUCTS_H_
#define _STRUCTS_H_


enum render_type {
	WIREFRAME,
	LAMBERT,
	GOURAUD,
	PHONG
};


// We need a global structure to store the programs
//  settings.  The control class passes relevent information
//  on to other classes, who can also return relevent values.
struct str_settings {

	int map_size;			// Width of the map in points.
	int order;				// Width of map as 2^order.
	int render_size;		// Width of render map in points.

	float fract_dimen;		// Fractal dimension, 0 - 1

	int output_width,		// Required width of output
		output_height;		//   window.
	render_type type;		// Rendering method to use.

	// Keep track of which windows are open...
	bool	preview;
	bool	output;
	bool	prefs_sky;
	bool	prefs_lighting;
	bool	prefs_trees;
	bool	prefs_preview;
	bool	prefs_rendering;
	bool	prefs_palette;
};


// A point in 3d space
struct point {
	float	x, y, z;
};


// Point transformed to 2d, keep depth
struct coord {
	float x, y, depth;
};

// A 3d map object
struct str_object_3d {
	struct point *data;
	int size;
};

// A 2d map object
struct str_object_2d {
	struct coord *data;
	int size;
};

// Structure defining a colour
struct str_col {
	guint32	r, g, b;
};

// Triangle defined by three vertices
struct str_tri {
	int v1, v2, v3;			// Indicies for triangle vertices
	struct str_col col;		// Basic colour of polygon
	point normal;			// Surface normal vector
	bool visible;			// Should polygon be rendered?
};


// 3d object arranged as triangles
struct str_model_3d {
	int num_tri;			// Number of triangles in the model
	struct point *data;		// List of model vertices
	struct str_tri *tri;	// Pointer to array of faces
	int size;
};


// 2d object arranged as triangles
struct str_model_2d {
	int num_tri;			// Number of triangles in the model
	struct coord *data;		// List of model vertices
	struct str_tri *tri;	// Pointer to array of faces
	int size;
};

#endif	// _STRUCTS_H_
