//
// w_prefs.h
//
// Parent prefs window
//
// Copyright (c) J. Belson	1998.07.06
//


#ifndef _W_PREFS_H_
#define _W_PREFS_H_

#include <iostream.h>
#include <gtk--.h>

#include "structs.h"


enum enum_button {
	OK, APPLY, CANCEL
};


class w_prefs : public Gtk_Window {

private:
	// Function to delete this instance
	static int my_delete_obj(w_prefs *o) {
		cout << "deleting" << endl;
		o->hide();
		delete o;
		return 0;
	}

public:
	w_prefs(char *frame_name);

	// This signal emitted when a button is pressed..
	Signal1<enum_button> sig_button_pressed;

protected:

	Gtk_HBox *frame_box;

	void ok_callback(void);
	void apply_callback(void);
	void cancel_callback(void);

};

#endif	// _W_PREFS_H_



