//
// renderer.cc
//
// Class to handle different rendering methods
//
// Copyright (c) J. Belson	1998.3.14
//


#include <iostream.h>
#include <gtk--.h>

#include "renderer.h"


renderer::renderer(void)
{
	debug("Called renderer constructor");

	light.x = 0;
	light.y = -1;
	light.z	= 0;
}

renderer::~renderer(void)
{
	debug("Called renderer destructor");

	// Free memory...
	delete [] model_2d.data;
	delete [] model_2d.tri;

}


//
// Transform supplied 3-d array into 2-d
//
void renderer::transform(void)
{
	debug("renderer::transform");

	int scale = 1;
	int size = model_3d->size;
	model_2d.size = size;

	// Initialise the model structure
	model_2d.data = new struct coord [(size/scale)*(size/scale)];

	// Transform all the points into 2d...
	int index = 0;
	for (int y=0; y<size/scale; y++) {
		for (int x=0; x<size/scale; x++) {
			model_2d.data[index].x = model_3d->data[index].x /
										(model_3d->data[index].z/(size/scale));
			model_2d.data[index].y = model_3d->data[index].y /
										(model_3d->data[index].z/(size/scale));
			model_2d.data[index].depth = model_3d->data[index].z;
			index++;
		}
	}

	// Copy triangle structures...
	model_2d.tri = new struct str_tri [model_3d->num_tri];
	for (int i=0; i<model_3d->num_tri; i++) {
		model_2d.tri[i] = model_3d->tri[i];		// Copy by assignment (hopefully)
	}
	model_2d.num_tri = model_3d->num_tri;

}


//
// Render using wireframe, backface culling but no hidden-face removal
//
void renderer::render_wire(void)
{
	debug("Called renderer::render_wire");


	int size = model_3d->size;
	//int scale = 1;

	// Draw each triangle in object_2d...
	for (int index = 0; index<model_2d.num_tri; index++) {

		float x1, y1, x2, y2, x3, y3;
		x1 = model_2d.data[model_2d.tri[index].v1].x;
		y1 = model_2d.data[model_2d.tri[index].v1].y;
		x2 = model_2d.data[model_2d.tri[index].v2].x;
		y2 = model_2d.data[model_2d.tri[index].v2].y;
		x3 = model_2d.data[model_2d.tri[index].v3].x;
		y3 = model_2d.data[model_2d.tri[index].v3].y;

		gdk_draw_line(pixmap, white_gc,
			int (width/2 + x1*(float (width)/float (size))),
			int (height/10 - y1*(float (height)/float (size))),
			int (width/2 + x2*(float (width)/float (size))),
			int (height/10 - y2*(float (height)/float (size))));
		gdk_draw_line(pixmap, white_gc,
			int (width/2 + x2*(float (width)/float (size))),
			int (height/10 - y2*(float (height)/float (size))),
			int (width/2 + x3*(float (width)/float (size))),
			int (height/10 - y3*(float (height)/float (size))));
		gdk_draw_line(pixmap, white_gc,
			int (width/2 + x3*(float (width)/float (size))),
			int (height/10 - y3*(float (height)/float (size))),
			int (width/2 + x1*(float (width)/float (size))),
			int (height/10 - y1*(float (height)/float (size))));
	}

}



//
// Render using Gouraud shading
//
void renderer::render_gouraud(void)
{
	debug("Called renderer::render_gouraud");

	int size = model_3d->size;

	//guint16 *buf = (guint16 *) image->mem;
	int index = 0;

	table1 = new float [height];
	table2 = new float [height];
	norm1 = new point[height];
	norm2 = new point[height];


	// Draw each triangle in str_model...
	//for (index=0; index<model_2d.num_tri; index++) {
	for (int y=0; y<size-1; y++) {
		for (int x=0; x<size-1; x++) {

			// Kludge edge triangle since they don't have a full set of neighbours
			if (x==0 || x==size-2 || y==0 || y==size-2) {
				point normal[4] = { {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0} };
			// Apply offsets to vertices, then render them
			point vert[3];

			vert[0].x = width/2   + model_2d.data[model_2d.tri[index].v1].x * float (width)/float (size);
			vert[0].y = height/10 - model_2d.data[model_2d.tri[index].v1].y * float (width)/float (size);
			vert[1].x = width/2   + model_2d.data[model_2d.tri[index].v2].x * float (width)/float (size);
			vert[1].y = height/10 - model_2d.data[model_2d.tri[index].v2].y * float (width)/float (size);
			vert[2].x = width/2   + model_2d.data[model_2d.tri[index].v3].x * float (width)/float (size);
			vert[2].y = height/10 - model_2d.data[model_2d.tri[index].v3].y * float (width)/float (size);

			point n1[3] = { normal[0], normal[1], normal[2] };

			fill_gouraud_polygon(vert, n1, &model_2d.tri[index].col); 

			index++;

			vert[0].x = width/2   + model_2d.data[model_2d.tri[index].v1].x * float (width)/float (size);
			vert[0].y = height/10 - model_2d.data[model_2d.tri[index].v1].y * float (width)/float (size);
			vert[1].x = width/2   + model_2d.data[model_2d.tri[index].v2].x * float (width)/float (size);
			vert[1].y = height/10 - model_2d.data[model_2d.tri[index].v2].y * float (width)/float (size);
			vert[2].x = width/2   + model_2d.data[model_2d.tri[index].v3].x * float (width)/float (size);
			vert[2].y = height/10 - model_2d.data[model_2d.tri[index].v3].y * float (width)/float (size);

			point n2[3] = { normal[0], normal[2], normal[3] };

			fill_gouraud_polygon(vert, n2, &model_2d.tri[index].col); 

			index++;

			} else {

			//
			// Fill in a square at a time, a square consisting of
			//  two triangles sharing a hypoteneus.  This way there
			//  are only 4 normal averages to compute.
			//

			// Calculate the average surface normal at each corner,
			//  starting top left, mmoving clockwise.
			point normal[4];
			normal[0].x = 	(get_normal(index)->x +
							get_normal(index + 1)->x +
							get_normal(index - 2)->x +
							get_normal(index - (2*size + 1))->x +  
							get_normal(index - (2*size + 2))->x +
							get_normal(index - (2*size - 1))->x) / 6;
			normal[0].y = 	(get_normal(index)->y +
							get_normal(index + 1)->y +
							get_normal(index - 2)->y +
							get_normal(index - (2*size + 1))->y +  
							get_normal(index - (2*size + 2))->y +
							get_normal(index - (2*size - 1))->y) / 6;
			normal[0].z = 	(get_normal(index)->z +
							get_normal(index + 1)->z +
							get_normal(index - 2)->z +
							get_normal(index - (2*size + 1))->z +  
							get_normal(index - (2*size + 2))->z +
							get_normal(index - (2*size - 1))->z) / 6;

			normal[1].x = 	(get_normal(index)->x +
							get_normal(index - (2*size - 1))->x +
							get_normal(index - (2*size))->x +
							get_normal(index - (2*size - 3))->x +
							get_normal(index + 2)->x +  
							get_normal(index + 3)->x) / 6;
			normal[1].y = 	(get_normal(index)->y +
							get_normal(index - (2*size - 1))->y +
							get_normal(index - (2*size))->y +
							get_normal(index - (2*size - 3))->y +
							get_normal(index + 2)->y +  
							get_normal(index + 3)->y) / 6;
			normal[1].z = 	(get_normal(index)->z +
							get_normal(index - (2*size - 1))->z +
							get_normal(index - (2*size))->z +
							get_normal(index - (2*size - 3))->z +
							get_normal(index + 2)->z +  
							get_normal(index + 3)->z) / 6;

			normal[2].x = 	(get_normal(index)->x +
							get_normal(index + 3)->x +
							get_normal(index + (2*size + 2))->x +
							get_normal(index + (2*size + 3))->x +
							get_normal(index + (2*size))->x +
							get_normal(index + 1)->x) / 6;
			normal[2].y = 	(get_normal(index)->y +
							get_normal(index + 3)->y +
							get_normal(index + (2*size + 2))->y +
							get_normal(index + (2*size + 3))->y +
							get_normal(index + (2*size))->y +
							get_normal(index + 1)->y) / 6;
			normal[2].z = 	(get_normal(index)->z +
							get_normal(index + 3)->z +
							get_normal(index + (2*size + 2))->z +
							get_normal(index + (2*size + 3))->z +
							get_normal(index + (2*size))->z +
							get_normal(index + 1)->z) / 6;

			normal[3].x = 	(get_normal(index + 1)->x +
							get_normal(index + (2*size))->x +
							get_normal(index + (2*size + 1))->x +
							get_normal(index + (2*size - 2))->x +
							get_normal(index - 1)->x +
							get_normal(index - 2)->x) / 6;
			normal[3].y = 	(get_normal(index)->y +
							get_normal(index + (2*size))->y +
							get_normal(index + (2*size + 1))->y +
							get_normal(index + (2*size - 2))->y +
							get_normal(index - 1)->y +
							get_normal(index - 2)->y) / 6;
			normal[3].z = 	(get_normal(index)->z +
							get_normal(index + (2*size))->z +
							get_normal(index + (2*size + 1))->z +
							get_normal(index + (2*size - 2))->z +
							get_normal(index - 1)->z +
							get_normal(index - 2)->z) / 6;


			// Apply offsets to vertices, then render them
			point vert[3];

			vert[0].x = width/2   + model_2d.data[model_2d.tri[index].v1].x * float (width)/float (size);
			vert[0].y = height/10 - model_2d.data[model_2d.tri[index].v1].y * float (width)/float (size);
			vert[1].x = width/2   + model_2d.data[model_2d.tri[index].v2].x * float (width)/float (size);
			vert[1].y = height/10 - model_2d.data[model_2d.tri[index].v2].y * float (width)/float (size);
			vert[2].x = width/2   + model_2d.data[model_2d.tri[index].v3].x * float (width)/float (size);
			vert[2].y = height/10 - model_2d.data[model_2d.tri[index].v3].y * float (width)/float (size);

			point n1[3] = { normal[0], normal[1], normal[2] };

			fill_gouraud_polygon(vert, n1, &model_2d.tri[index].col); 

			index++;

			vert[0].x = width/2   + model_2d.data[model_2d.tri[index].v1].x * float (width)/float (size);
			vert[0].y = height/10 - model_2d.data[model_2d.tri[index].v1].y * float (width)/float (size);
			vert[1].x = width/2   + model_2d.data[model_2d.tri[index].v2].x * float (width)/float (size);
			vert[1].y = height/10 - model_2d.data[model_2d.tri[index].v2].y * float (width)/float (size);
			vert[2].x = width/2   + model_2d.data[model_2d.tri[index].v3].x * float (width)/float (size);
			vert[2].y = height/10 - model_2d.data[model_2d.tri[index].v3].y * float (width)/float (size);

			point n2[3] = { normal[0], normal[2], normal[3] };

			fill_gouraud_polygon(vert, n2, &model_2d.tri[index].col); 

			index++;

			}
		}
	}

	delete [] norm1;
	delete [] norm2;
	delete [] table1;
	delete [] table2;

}




//
// Gouraud shaded fill routine
// On entry		: v[3] is array of (x, y) coordinates describing triangle
//				  n[3] surface normals of each vertice
//
void renderer::fill_gouraud_polygon(point *v, point *n, struct str_col *c)
{
	guint16 *buf = (guint16 *) image->mem;

	int mid, highest = 0, lowest = 0;

	// Calculate illumination intensity
	float inten;

	// Find highest and lowest vertices...
	for (int i=1; i<3; i++) {
		if (v[i].y > v[highest].y) {
			highest = i;
		}
		if (v[i].y < v[lowest].y) {
			lowest = i;
		}
	}

	// Do (very) simple clipping
	for (int i=0; i<3; i++) {
		if (v[i].y > (height-2)) {
			v[i].y = (height-2);
		}
		if (v[i].y < 2) {
			v[i].y = 2;
		}
		if (v[i].x > (width-2)) {
			v[i].x = (width-2);
		}
		if (v[i].x < 2) {
			v[i].x = 2;
		}
	}

	// Deduce other point using advanced mathematics
	mid = 3 - highest - lowest;

	// Calculate points for lowest to highest vertices...
	float x_step = (float (n[highest].x) - float (n[lowest].x)) /
								(float (v[highest].y) - float(v[lowest].y));
	float y_step = (float (n[highest].y) - float (n[lowest].y)) /
								(float (v[highest].y) - float(v[lowest].y));
	float z_step = (float (n[highest].z) - float (n[lowest].z)) /
								(float (v[highest].y) - float(v[lowest].y));

	float curr_x = v[lowest].x;
	point curr_n = { n[lowest].x, n[lowest].y, n[lowest].z };
	float delta = (v[highest].x - v[lowest].x) / (v[highest].y - v[lowest].y);
	for (int i= int(v[lowest].y); i<= int(v[highest].y); i++) {
		table1[i] = curr_x;
		norm1[i] = curr_n;
		curr_x += delta;
		curr_n.x += x_step;
		curr_n.y += y_step;
		curr_n.z += z_step;
	}

	// Calculate points for lowest to mid, then mid to highest vertices...
	x_step = (float (n[highest].x) - float (n[lowest].x)) /
								(float (v[highest].y) - float(v[lowest].y));
	y_step = (float (n[highest].y) - float (n[lowest].y)) /
								(float (v[highest].y) - float(v[lowest].y));
	z_step = (float (n[highest].z) - float (n[lowest].z)) /
								(float (v[highest].y) - float(v[lowest].y));

	curr_x = v[lowest].x;
	curr_n.x = n[lowest].x;
	curr_n.y = n[lowest].y;
	curr_n.z = n[lowest].z;
	curr_x = v[lowest].x;
	delta = (v[mid].x - v[lowest].x) / (v[mid].y - v[lowest].y);
	for (int i= int(v[lowest].y); i<int(v[mid].y); i++) {
		table2[i] = curr_x;
		norm2[i] = curr_n;
		curr_x += delta;
		curr_n.x += x_step;
		curr_n.y += y_step;
		curr_n.z += z_step;
	}
	x_step = (float (n[highest].x) - float (n[lowest].x)) /
								(float (v[highest].y) - float(v[lowest].y));
	y_step = (float (n[highest].y) - float (n[lowest].y)) /
								(float (v[highest].y) - float(v[lowest].y));
	z_step = (float (n[highest].z) - float (n[lowest].z)) /
								(float (v[highest].y) - float(v[lowest].y));
	curr_x = v[mid].x;
	delta = (v[highest].x - v[mid].x) / (v[highest].y - v[mid].y);
	for (int i=int(v[mid].y); i<int (v[highest].y); i++) {
		table2[i] = curr_x;
		norm2[i] = curr_n;
		curr_x += delta;
		curr_n.x += x_step;
		curr_n.y += y_step;
		curr_n.z += z_step;
	}

	// Calculated colour stored here...
	struct str_col shaded_c;

	// Can now fill in the lines...
	for (int y = int(v[lowest].y); y<int(v[highest].y); y++) {
		if (table1[y] < table2[y]) {
			curr_n = norm1[y];

			// Calculate step between pixels...
			x_step = (norm2[y].x - norm1[y].x) / (table2[y] - table1[y]);
			y_step = (norm2[y].y - norm1[y].y) / (table2[y] - table1[y]);
			z_step = (norm2[y].z - norm1[y].z) / (table2[y] - table1[y]);

			for (int x = int (table1[y]); x<int (table2[y]); x++) {
				// Calculate light intensity...
				inten = get_angle(&light, curr_n.x, curr_n.y, curr_n.z);
				// Adjust brightness as appropriate...
				shaded_c.r = int (c->r * inten);
				shaded_c.g = int (c->g * inten);
				shaded_c.b = int (c->b * inten);
				set_pixel(buf, x, y, calc_colour(&shaded_c));
				curr_n.x += x_step;
				curr_n.y += y_step;
				curr_n.z += z_step;
			}
		} else {
			curr_n = norm1[y];

			x_step = (norm1[y].x - norm2[y].x) / (table1[y] - table2[y]);
			y_step = (norm1[y].y - norm2[y].y) / (table1[y] - table2[y]);
			z_step = (norm1[y].z - norm2[y].z) / (table1[y] - table2[y]);

			for (int x = int (table2[y]); x<int (table1[y]); x++) {
				inten = get_angle(&light, curr_n.x, curr_n.y, curr_n.z);
				shaded_c.r = int (c->r * inten);
				shaded_c.g = int (c->g * inten);
				shaded_c.b = int (c->b * inten);
				set_pixel(buf, x, y, calc_colour(&shaded_c));
				curr_n.x += x_step;
				curr_n.y += y_step;
				curr_n.z += z_step;
			}
		}
	}
}



//
// Render using Lambert shading
//
void renderer::render_lambert(void)
{
	debug("Called renderer::render_lambert");

	int size = model_3d->size;

	//guint16 *buf = (guint16 *) image->mem;
	int index = 0;

	table1 = new float [height];
	table2 = new float [height];

	// Draw each triangle in str_model...
	for (index=0; index<model_2d.num_tri; index++) {

		point vert[3];

		vert[0].x = width/2   + model_2d.data[model_2d.tri[index].v1].x * float (width)/float (size);
		vert[0].y = height/10 - model_2d.data[model_2d.tri[index].v1].y * float (width)/float (size);
		vert[1].x = width/2   + model_2d.data[model_2d.tri[index].v2].x * float (width)/float (size);
		vert[1].y = height/10 - model_2d.data[model_2d.tri[index].v2].y * float (width)/float (size);
		vert[2].x = width/2   + model_2d.data[model_2d.tri[index].v3].x * float (width)/float (size);
		vert[2].y = height/10 - model_2d.data[model_2d.tri[index].v3].y * float (width)/float (size);

		fill_polygon(vert, &model_2d.tri[index].normal, &model_2d.tri[index].col); 

	}
	
	delete [] table1;
	delete [] table2;

}


//
// Simple polygon fill routine
//
void renderer::fill_polygon(point *v, struct point *n, struct str_col *c)
{
	guint16 *buf = (guint16 *) image->mem;

	int mid, highest = 0, lowest = 0;

	// Calculate illumination intensity
	float inten = get_angle(&light, n->x, n->y, n->z);

	// Find highest and lowest vertices...
	for (int i=1; i<3; i++) {
		if (v[i].y > v[highest].y) {
			highest = i;
		}
		if (v[i].y < v[lowest].y) {
			lowest = i;
		}
	}


	// Do (very) simple clipping
	for (int i=0; i<3; i++) {
		if (v[i].y > (height-2)) {
			v[i].y = (height-2);
		}
		if (v[i].y < 2) {
			v[i].y = 2;
		}
		if (v[i].x > (width-2)) {
			v[i].x = (width-2);
		}
		if (v[i].x < 2) {
			v[i].x = 2;
		}
	}

	// Deduce other point using advanced mathematics
	mid = 3 - highest - lowest;

	// Calculate points for lowest to highest vertices...
	float curr_x = v[lowest].x;
	float delta = (v[highest].x - v[lowest].x) / (v[highest].y - v[lowest].y);
	for (int i= int(v[lowest].y); i<= int(v[highest].y); i++) {
		//set_pixel(buf, curr_x, i, 0xffff);
		table1[i] = curr_x;
		curr_x += delta;
	}

	// Calculate points for lowest to mid, then mid to highest vertices...
	curr_x = v[lowest].x;
	delta = (v[mid].x - v[lowest].x) / (v[mid].y - v[lowest].y);
	for (int i= int(v[lowest].y); i<int(v[mid].y); i++) {
		//set_pixel(buf, curr_x, i, 0xffff);
		table2[i] = curr_x;
		curr_x += delta;
	}
	curr_x = v[mid].x;
	delta = (v[highest].x - v[mid].x) / (v[highest].y - v[mid].y);
	for (int i=int(v[mid].y); i<int (v[highest].y); i++) {
		//set_pixel(buf, curr_x, i, 0xffff);
		table2[i] = curr_x;
		curr_x += delta;
	}

	struct str_col shaded_c;
	shaded_c.r = int (c->r * inten);
	shaded_c.g = int (c->g * inten);
	shaded_c.b = int (c->b * inten);

	// Can now fill in the lines...
	for (int y = int(v[lowest].y); y<int(v[highest].y); y++) {
		if (table1[y] < table2[y]) {
			for (int x = int (table1[y]); x<int (table2[y]); x++) {
				set_pixel(buf, x, y, calc_colour(&shaded_c));
			}
		} else {
			for (int x = int (table2[y]); x<int (table1[y]); x++) {
				set_pixel(buf, x, y, calc_colour(&shaded_c));
			}
		}
	}
}


// Get the angle between two vectors...
float renderer::get_angle(struct point *l, float x, float y, float z)
{
	float top = (l->x*x + l->y*y + l->z*z);
	float bottom = sqrt(l->x*l->x + l->y*l->y + l->z*l->z) * sqrt(x*x + y*y + z*z);

	if (top/bottom < 0) {
		top =- top;
	}

	return top/bottom;
}


//
// Initialise renderer class...
//
// GdkPixmap version, used by w_preview
//
void renderer::setup(int w, int h, int, const struct str_model_3d *obj, GdkPixmap *p, GdkGC *gc)
{
	debug("Setting up renderer");

	width = w;
	height = h;
	model_3d = obj;
	pixmap = p;

	white_gc = gc;

	// Transform to 2d...
	transform();

}

// GdkImage version
void renderer::setup(int w, int h, int, const struct str_model_3d *obj, GdkImage *im)
{
	debug("Setting up renderer");

	width = w;
	height = h;
	model_3d = obj;
	image = im;

	// Transform to 2d...
	transform();
}


//
// Calculate surface normal for specified plane
//
float renderer::normal(
			float x1, float y1, float z1,
			float x2, float y2, float z2,
			float x3, float y3, float z3)
{
	float c = (x3*((z1*y2) - (y1*z2)) + y3*((x1*z2) - (z1*x2)) + z3*((y1*x2) - (x1*y2)));

	return c;
}


//
// Render using current parameters...
//
void renderer::render(render_type rt) {
	switch (rt) {
		case WIREFRAME:		render_wire();
							break;
		case LAMBERT:		render_lambert();
							break;
		case GOURAUD:		render_gouraud();
							break;
		case PHONG:			render_phong();
							break;
		default:			cerr << "Unknown render type in renderer::render" << endl;
	}
}


void renderer::set_pixel(guint16 *buf, int x, int y, guint16 val)
{
	if (x<0 || x>=width || y<0 || y>=height) {
		return;
	}

	guint32 rgb;
	guint16 *p = buf + (y*width) + x;
	//guint32 r = 0, g = val, b = 0;

	// Assumes 16-bit display
	rgb = val;
	*p = rgb;
}



guint16 renderer::calc_colour(struct str_col *c)
{
	guint16 rgb;
	rgb =   ( (((c->r) >> 11) << 11)		// 5 bits of red
			| (((c->g) >> 10) <<  5)		// 6 bits of green
			| (((c->b) >> 11) <<  0));		// 5 bits of blue
	return rgb;
}


// Calculate normal vector of a triangle
void renderer::normal_vector(struct point *p,
				float x1, float y1, float z1,
				float x2, float y2, float z2,
				float x3, float y3, float z3) {
	struct point v1, v2;
	v1.x = x1 - x2;
	v1.y = y1 - y2;
	v1.z = z1 - z2;

	v2.x = x3 - x2;
	v2.y = y3 - y2;
	v2.z = z3 - z2;

	p->x = (v1.y*v2.z) - (v1.z*v2.y);
	p->y = (v1.z*v2.x) - (v1.x*v2.z);
	p->z = (v1.x*v2.y) - (v1.y*v2.x);
}


// Plot a point into a buffer...
void renderer::plot(guint16 *buf, guint32 r, guint32 g, guint32 b) {
	guint16 rgb;
	// Assumes 16-bit display
	rgb =	( (((r) >> 11) << 11)		// 5 bits of red
			| (((g) >> 10) <<  5)		// 6 bits of green
			| (((b) >> 11) <<  0));		// 5 bits of blue
	*buf = rgb;
}
