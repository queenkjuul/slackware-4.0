//
// calc.cc
//
//
// Calc.cc
//
// Copyright (c) J. Belson	1998.1.2
//

#include <iostream.h>
#include <math.h>
#include <stdlib.h>

#include "calc.h"


// Generate a floating point number between 0 and 1
float ran1(void)
{
	return (1.0*rand()/(RAND_MAX+1.0));
}


//
// Generate Gaussian random number
// (Piece of example code nabbed off the 'Net)
//
float gasdev(void)
{
	float x1, x2, w, y1, y2;
 
	do {
		x1 = 2.0 * ran1() - 1.0;
		x2 = 2.0 * ran1() - 1.0;
		w = x1 * x1 + x2 * x2;
	} while ( w >= 1.0 );

	w = sqrt( (-2.0 * log( w ) ) / w );
	y1 = x1 * w;
	y2 = x2 * w;

	return y1;
}

