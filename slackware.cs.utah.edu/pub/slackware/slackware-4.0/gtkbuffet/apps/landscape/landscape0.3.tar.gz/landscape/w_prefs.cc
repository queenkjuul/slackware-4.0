//
// Parent prefs window
//
// Copyright (c) J. Belson	1998.07.06
//


#include "w_prefs.h"


// Open window and create widgets
w_prefs::w_prefs(char *frame_name)
{
	cout << "w_prefs constructor" << endl;
	set_title("Prefs...");

	Gtk_VBox *main_box = new Gtk_VBox(FALSE, 0);
	main_box->border_width(4);
	add(main_box);

	Gtk_Frame *frame = new Gtk_Frame(frame_name);
	frame->show();
	frame->border_width(4);
	main_box->pack_start(frame, TRUE, TRUE, 0);

	frame_box = new Gtk_HBox(FALSE, 0);
	frame_box->show();
	frame->add(frame_box);

	Gtk_HBox *button_box = new Gtk_HBox(TRUE, 0);
	button_box->border_width(4);
	button_box->show();
	main_box->pack_start(button_box, FALSE, FALSE, 0);


	// Ok/Apply/Cancel buttons
	Gtk_Button *okay_button = new Gtk_Button("Okay");
	Gtk_Button *apply_button = new Gtk_Button("Apply");
	Gtk_Button *cancel_button = new Gtk_Button("Cancel");
	button_box->pack_start(okay_button, TRUE, FALSE, 0);
	button_box->pack_start(apply_button, TRUE, FALSE, 0);
	button_box->pack_start(cancel_button, TRUE, FALSE, 0);
	connect_to_method(okay_button->clicked, this, &ok_callback);
	connect_to_method(apply_button->clicked, this, &apply_callback);
	connect_to_method(cancel_button->clicked, this, &cancel_callback);
	okay_button->show();
	apply_button->show();
	cancel_button->show();

	main_box->show();	
}



//
// Button callbacks
//
void w_prefs::ok_callback(void)
{
	sig_button_pressed(OK);
	// Delete this object...
	Gtk_Main::instance()->idle_add((GtkFunction) &my_delete_obj, this);
}

void w_prefs::apply_callback(void)
{
	sig_button_pressed(APPLY);
}

void w_prefs::cancel_callback(void)
{
	sig_button_pressed(CANCEL);

	// Delete this object...
	Gtk_Main::instance()->idle_add((GtkFunction) &my_delete_obj, this);
}
