//
// map.h
//
// Create a fractal landscape
//
// Copyright (c) J. Belson	1997.12.29
//


#ifndef _MAP_H_
#define	_MAP_H_


class fbm_map {

private:
	// Array of height fields, [(map_size+1) * (map_size+1)]
	float *relief;

	// Width of map
	int map_size;

	// Seed for random number generator, set to
	//  a -ve value on first function call
	long idum;

	// Calculate average of x terms + std_dev*gasdev())
	inline float av(float delta, float x0, float x1, float x2, float x3);
	inline float av(float delta, float x0, float x1, float x2);

	// Function to give array offset from x and y...
	inline int index(int x, int y) {
		return (y*(map_size+1) + x);
	}

	void debug(char *msg) {
		//cout << "msg" << endl;
	}

public:
	// Constructor and destructor...
	fbm_map(int size, float fd, unsigned int seed) {
		srand(seed);
		fbm_map(size, fd);
	}
	fbm_map(int size, float fd);
	fbm_map(int size);
	~fbm_map();

	// Quick debugging hack
	void dump_map(void);
	
	// Generate relief map
	int generate(int order, float std_dev, float h);

	// Read height from relief
	float read_map(int pos) {
		if ((pos < 0) || (pos>(map_size+1)*(map_size+1))) {
			cerr << "Attempting to read relief element " << pos;
			cerr << ". Max is " << ((map_size+1)*(map_size+1)) << endl;
		}
		return relief[pos];
	}

	// Return a pointer to the height data for rendering purposes
	const float *get_data(void) {
		return (const float *) relief;
	}

	friend float gasdev(long *idum);

};


#endif	// _MAP_H
