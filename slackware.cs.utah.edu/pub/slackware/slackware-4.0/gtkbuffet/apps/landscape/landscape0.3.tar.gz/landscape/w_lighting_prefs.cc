//
// w_lighting_prefs.cc
//
// Prefs window for lighting
//
// Copyright (c) J. Belson	1998.06.30
//


#include "w_lighting_prefs.h"



// Open window and create widgets
w_lighting_prefs::w_lighting_prefs(void) : w_prefs("Lighting prefs")
{

}

