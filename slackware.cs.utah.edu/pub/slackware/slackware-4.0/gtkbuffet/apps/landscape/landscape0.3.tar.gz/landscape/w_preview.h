//
// w_preview.h
//
// 3-d preview window for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.1.18
//


#ifndef _W_PREVIEW_H_
#define _W_PREVIEW_H_

#include <iostream.h>
#include <gtk--.h>

#include "renderer.h"
#include "terrain.h"



//
// Derive new drawingarea class to handle rendering
//

class w_preview_drawingarea : public Gtk_DrawingArea {

private:

	// Class to handle rendering...
	renderer *rend;

	// Render relief map into here
	GdkPixmap *pixmap;

	// Store arguments to render() each time it is called,
	//  so configure...() can call it when necessary
	int obj_size;
	const struct str_model_3d *obj;

	void debug(char *msg) {
		cout << msg << endl;
	}

public:
	w_preview_drawingarea(void) {
		debug("Called preview_drawingarea constructor");
		pixmap = 0;
		obj_size = 0;
		set_events(GDK_EXPOSURE_MASK);
	}
	~w_preview_drawingarea() {
		delete rend;
	};

	// Catch expose events
	virtual gint expose_event_impl(GdkEventExpose* e);

	// Catch configure events.
	virtual gint configure_event_impl(GdkEventConfigure* e);

	// Clear the bcking pixmap
	void clear_screen(void);
	
	// Render into d_image using supplied data...
	void rerender(void) {
		if (obj==0) {
			cerr << "rerender called before render" << endl;
			return;
		}
		render(obj_size, obj);
	}
	void render(int size, const struct str_model_3d *object);
};



class w_preview : public Gtk_Window{

private:
	GtkWidget *button;
	Gtk_Button *but;
	Gtk_VBox *box;
	w_preview_drawingarea *drawing_area;
	terrain *my_terrain;

	const struct str_model_3d *model;

	// Current size of window...
	int width, height;

	// Mapsize
	int mapsize;

	// User is rotating the preview
	bool rotating;
	int ref_x;

	void debug(char *msg) {
		//cout << msg << endl;
	}

public:

	w_preview(void);
	~w_preview(void);

	int open_window(int map_size);
	int close_window(void);

	void set_size(int s) {
		width = height = s;
	}

	// Quick and dirty way to poke pixels directly into screen memory
	void plot(guint16 *buf, guint32 r, guint32 g, guint32 b);

	// Render map to memory...
	void render(const float *relief, int size);

	// Return pointer to str_model_3d, which contains model at
	//  current orientation
	const struct str_model_3d *get_data(void) {
		return (const struct str_model_3d *) my_terrain->get_data();
	}

	// Get current rotation of preview terrain
	void get_rotation(float *a, float *b, float *c);

	// Overloaded events
	gint button_press_event_impl(GdkEventButton *e);
	gint button_release_event_impl(GdkEventButton *e);
	gint motion_notify_event_impl(GdkEventMotion *e);
};


#endif	// _W_PREVIEW_H_
