//
// w_preview_prefs.h
//
// Prefs window for preview
//
// Copyright (c) J. Belson	1998.06.30
//


#ifndef _W_PREVIEW_PREFS_H_
#define _W_PREVIEW_PREFS_H_

#include <iostream.h>
#include <gtk--.h>

#include "w_prefs.h"


class w_preview_prefs : public w_prefs {

private:


public:
	w_preview_prefs();


};

#endif	// _W_PREVIEW_PREFS_H_
