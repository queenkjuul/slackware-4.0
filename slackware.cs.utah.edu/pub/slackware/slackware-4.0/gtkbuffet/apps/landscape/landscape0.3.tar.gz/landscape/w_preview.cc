//
// w_preview.cc
//
// 3-d preview window for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.1.18
//

#include "w_preview.h"
#include "terrain.h"

#include <iostream.h>
#include <gtk--.h>


//
// Constructor/destructor
//
w_preview::w_preview(void)
{
	debug("Called preview window constructor");

	set_title("Preview");

	rotating = 0;
}


w_preview::~w_preview(void)
{
	debug("Called preview window destructor");
	
	// Free any memory
	delete drawing_area;
}


// Get rotation from terrain object
void w_preview::get_rotation(float *a, float *b, float *c)
{
	my_terrain->get_rotation(a, b, c);
}


//
// Open preview display area
//
int w_preview::open_window(int map_size)
{
	// Initialise size of window
	width = height = map_size;

	// Create derived DrawingArea to handle rendering
	drawing_area = new w_preview_drawingarea;

	drawing_area->set_events(GDK_EXPOSURE_MASK |
							GDK_BUTTON_PRESS_MASK |
							GDK_BUTTON_RELEASE_MASK |
							GDK_POINTER_MOTION_MASK |
							GDK_POINTER_MOTION_HINT_MASK);
	//drawing_area->size(map_size, map_size);
	add(drawing_area);
	drawing_area->show();

	// No errors
	return 0;
}


//
// Close preview display area
//
int w_preview::close_window(void)
{

	return 0;
}


// Quick and dirty way to poke pixels directly into screen memory
void w_preview::plot(guint16 *buf, guint32 r, guint32 g, guint32 b) {
	guint32 rgb;
	rgb =	( (((r) >> 11) << 11)		// 5 bits of red
			| (((g) >> 10) <<  5)		// 6 bits of green
			| (((b) >> 11) <<  0));		// 5 bits of blue
	*buf = rgb;
}



// Render map to w_preview_drawingarea's pixmap...
void w_preview::render(const float *relief, int size)
{
	debug("Rendering preview");

	mapsize = size;

	// Create a terrain object
	delete my_terrain;
	my_terrain = new terrain();

	// Generate fractal terrain...
	my_terrain->generate_terrain(relief, size);
	// ...and retrive data
	model = my_terrain->get_data();

	drawing_area->clear_screen();

	// Draw the landscape as a series of contour lines.
	// Scale the lines to fit the current preview window size.
	drawing_area->render(size, model);

	// Persuade gtk to update rendered image...
	GdkRectangle update_rect;
	update_rect.x = 0;
	update_rect.y = 0;
	update_rect.width = GTK_WIDGET(gtkobject)->allocation.width;
	update_rect.height = GTK_WIDGET(gtkobject)->allocation.height;
	gtk_widget_draw(GTK_WIDGET(gtkobject), &update_rect);

}


//
// Overloaded event implementations...
//
gint w_preview::button_press_event_impl(GdkEventButton *e)
{
	// User want to rotate the preview
	rotating = 1;
	ref_x = (int) e->x;		// Note current x position

	return Gtk_Widget::button_press_event_impl(e);
}


gint w_preview::button_release_event_impl(GdkEventButton *e)
{
	// Rotation completed
	rotating = 0;

	return Gtk_Widget::button_release_event_impl(e);
}


gint w_preview::motion_notify_event_impl(GdkEventMotion *e)
{
	int x, y;
	GdkModifierType state;

	if (e->is_hint) {
		gdk_window_get_pointer(e->window,
							&x,
							&y,
							&state);
	} else {
		x = int (e->x);
		y = int (e->y);
		//state = e->state;
	}

	if (rotating) {

		// Apply rotation
		my_terrain->transform(0.0, (ref_x - x)/500.0 , 0.0);
		ref_x = int(e->x);

		// Rerender the new data
		drawing_area->clear_screen();
		drawing_area->render(mapsize, model);

		// Persuade gtk to update rendered image...
		GdkRectangle update_rect;
		update_rect.x = 0;
		update_rect.y = 0;
		update_rect.width = GTK_WIDGET(gtkobject)->allocation.width;
		update_rect.height = GTK_WIDGET(gtkobject)->allocation.height;
		gtk_widget_draw(GTK_WIDGET(gtkobject), &update_rect);

	}


	return Gtk_Widget::motion_notify_event_impl(e);
}



gint w_preview_drawingarea::expose_event_impl(GdkEventExpose* e)
{
	//printf("Got expose in preview_drawingarea\n");

	// Call parent expose handler...
	Gtk_Widget::expose_event_impl(e);                           

	gdk_draw_pixmap(GTK_WIDGET(gtkobject)->window,
				GTK_WIDGET(gtkobject)->style->fg_gc[GTK_WIDGET_STATE(GTK_WIDGET(gtkobject))],
				pixmap,
				e->area.x, e->area.y,
				e->area.x, e->area.y,
				e->area.width, e->area.height);

	return 0;                                                 
}


gint w_preview_drawingarea::configure_event_impl(GdkEventConfigure* e)
{ 
	//printf("Got configure in preview_drawingarea\n");

	// Call baseclass configure function
	Gtk_Widget::configure_event_impl(e);                           

	if (pixmap) {
		gdk_pixmap_unref(pixmap);
	}

	pixmap = gdk_pixmap_new(GTK_WIDGET(gtkobject)->window,
								GTK_WIDGET(gtkobject)->allocation.width,
								GTK_WIDGET(gtkobject)->allocation.height,
								-1);

	gdk_draw_rectangle(pixmap,	GTK_WIDGET(gtkobject)->style->black_gc,
								TRUE, 0, 0,
								GTK_WIDGET(gtkobject)->allocation.width,
								GTK_WIDGET(gtkobject)->allocation.height);

	// Re-render terrain using data from previous invocation
	rerender();

	return 0;                                                 
}


// Clear backing pixmap
void w_preview_drawingarea::clear_screen(void)
{
	gdk_draw_rectangle(pixmap,	GTK_WIDGET(gtkobject)->style->black_gc,
								TRUE, 0, 0,
								GTK_WIDGET(gtkobject)->allocation.width,
								GTK_WIDGET(gtkobject)->allocation.height);

}


// Render using supplied arguments
void w_preview_drawingarea::render(int size, const struct str_model_3d *model)
{
	int width = GTK_WIDGET(gtkobject)->allocation.width;
	int height = GTK_WIDGET(gtkobject)->allocation.height;

	// Store values...
	obj = model;
	obj_size = size;

	// Create class to handle rendering
	rend = new renderer;

	// Set up the renderer class with necessary values...
	rend->setup(width,
				height,
				size,
				model,
				pixmap,
				GTK_WIDGET(gtkobject)->style->white_gc);

	// ...and render it
	rend->render(WIREFRAME);

	delete rend;
}

