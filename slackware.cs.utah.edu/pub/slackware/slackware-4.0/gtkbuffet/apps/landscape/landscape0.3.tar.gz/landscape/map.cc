//
// map.cc
//
// Create a fractal landscape
//
// Copyright (c) J. Belson	1997.12.29
//


#include <iostream.h>
#include <math.h>

#include <gtk--.h>

#include "calc.h"
#include "map.h"


// Create an array of height field, size * size
// On entry		: order is width of map as power of 2
//				: fd is fractal dimention
fbm_map::fbm_map(int order, float fd)
{
	debug("Called map constructor");

	// Store map size...
	map_size = (int) pow(2, order);

	// Create a co-ord array [size]x[size]
	relief = new float [(map_size + 1) * (map_size + 1)];

	// Create map...
	generate(order,		// Map width is 2^order
			0.5,		// Standard deviation
			fd);		// Fractal dimension (0-1)
}


//
// Rewrite of fBm generation routine.
// On entry		: order is map size, ie. width = pow(2, order)
//				: h is Hurst exponent
int fbm_map::generate(int order, float std_dev, float h)
{
	float scale_factor = std_dev;

	int step = map_size;

	debug("fbm_map::generate");

	// Start by setting the corners to 0.0 and the centre to gasdev()
	relief[index(0, 0)] = 0.0;
	relief[index(0, map_size)] = 0.0;
	relief[index(map_size, 0)] = 0.0;
	relief[index(map_size, map_size)] = 0.0;
	relief[index(map_size/2, map_size/2)] = scale_factor*gasdev();


	// Initialise all points to zero
	for (int y=0; y<map_size+1; y++) {
		for (int x=0; x<map_size+1; x++) {
			relief[index(x, y)] = 0.0;
		}
	}


	while (step > 1) {

		scale_factor *= pow(0.5, 0.5*h);

		// Do diagonal interpolations...
		for (int x = step/2; x < map_size; x += step) {
			for (int y=step/2; y < map_size; y += step) {
				relief[index(x, y)] += 	av(scale_factor, relief[index(x - step/2 , y - step/2)],
													relief[index(x + step/2, y - step/2)],
													relief[index(x + step/2, y + step/2)],
													relief[index(x - step/2, y + step/2)]);
			}
		}

		// Deal with edge points...
		for (int x = step/2; x < map_size; x += step) {
			relief[index(x, 0)] = av(scale_factor, relief[index(x - step/2, 0)],
													relief[index(x + step/2, 0)],
													relief[index(x, step/2)]);

			relief[index(x, map_size)] = av(scale_factor, relief[index(x - step/2, map_size)],
													relief[index(x + step/2, map_size)],
													relief[index(x, map_size - step/2)]);
			relief[index(0, x)] = av(scale_factor, relief[index(0, x - step/2)],
													relief[index(0, x + step/2)],
													relief[index(step/2, x)]);
			relief[index(map_size, x)] = av(scale_factor, relief[index(map_size, x - step/2)],
													relief[index(map_size, x + step/2)],
													relief[index(map_size - step/2, x)]);
		}


		scale_factor *= pow(0.5, 0.5*h);


		// Now do parallel interpolations...
		for (int x = step/2; x < map_size; x += step) {
			for (int y = step; y < map_size; y += step) {
				relief[index(x, y)] = av(scale_factor, relief[index(x - step/2 , y)],
														relief[index(x, y - step/2)],
														relief[index(x + step/2, y)],
														relief[index(x, y + step/2)]);

				relief[index(y, x)] = av(scale_factor, relief[index(y - step/2 , x)],
														relief[index(y, x - step/2)],
														relief[index(y + step/2, x)],
														relief[index(y, x + step/2)]);
			}
		}

		step >>= 1;
	}

	return 0;
}


// Create an array of height field, size * size
// On entry		: order is width of map as power of 2
fbm_map::fbm_map(int order)
{
	debug("Called map constructor");

	// Store map size...
	map_size = (int) pow(2, order);

	// Create a co-ord array [size]x[size]
	relief = new float [(map_size + 1) * (map_size + 1)];

	// Initialise all points to zero
	for (int y=0; y<map_size+1; y++) {
		for (int x=0; x<map_size+1; x++) {
			relief[index(x, y)] = -1.0;
		}
	}
}


fbm_map::~fbm_map()
{
	debug("Called map destructor");

	delete [] relief;
}


// Just dump the map, for debugging purposes
void fbm_map::dump_map(void)
{
	cout << "Dumping relief map :\n";
	for (int y=0; y<map_size; y++) {
		for (int x=0; x<map_size; x++) {
			cout.width(2);
			cout << (int)(10*relief[index(x, y)]) << " ";
		}
		cout << endl;
	}
}



//
// Average 4 points and apply random addition...
//
float fbm_map::av(float delta, float x0, float x1, float x2, float x3)
{
	return (x0+x1+x2+x3)/4.0 + delta*gasdev();
}


//
// Average 3 points and apply random addition...
//
float fbm_map::av(float delta, float x0, float x1, float x2)
{
	return (x0+x1+x2)/3.0 + delta*gasdev();
}
