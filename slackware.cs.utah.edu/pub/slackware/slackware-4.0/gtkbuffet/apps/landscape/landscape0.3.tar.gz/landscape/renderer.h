//
// renderer.h
//
// Class to handle different rendering methods
//
// Copyright (c) J. Belson	1998.3.14
//


#ifndef _RENDERER_H_
#define _RENDERER_H_

#include <iostream.h>
#include <gtk--.h>

#include "structs.h"
#include "terrain.h"


class renderer {

private:

	// Size of area to render into
	int width, height;

	// Pointer to array and its size
	const struct str_model_3d *model_3d;
	str_model_2d model_2d;

	// Pixmap/Image to render into
	GdkPixmap *pixmap;
	GdkImage *image;
	GdkGC *white_gc;

	// Two tables for storing polygon edges
	float *table1, *table2;
	// Two tables for storing interpolated normals
	point *norm1, *norm2;

	// Lighting vector
	point light;

	// Perform 3d to 2d transformation
	void transform(void);

	// Different types of rendering...
	void render_wire(void);
	void render_lambert(void);
	void render_gouraud(void);
	void render_phong(void){};

	// Determine sign of surface normal (x1,y1,z1),(x2,y2,z2)
	float normal(float x1, float y1, float z1,
				 float x2, float y2, float z2,
				 float x3, float y3, float z3);

	// Access the normal vector for specified triangle
	point *get_normal(int idx) {
		return &(model_2d.tri[idx].normal);
	}

	// Draw filled polygon
	void fill_polygon(point *v, struct point *n, struct str_col *c);
	void fill_gouraud_polygon(point *v, point *n, struct str_col *c);

	// Get the angle between two vectors...
	float get_angle(struct point *l, float x, float y, float z);

	// Calculate normal vector of a triangle
	void normal_vector(struct point *p,
					float x1, float y1, float z1,
					float x2, float y2, float z2,
					float x3, float y3, float z3);


	// Plot a point into a buffer...
	void plot(guint16 *buf, guint32 r, guint32 g, guint32 b);

	void set_pixel(guint16 *buf, int x, int y, guint16 val);

	guint16 calc_colour(struct str_col *c);

	// Print debug messages
	void debug(char *msg) {
		//cout << msg << endl;
	}

public:
	renderer();
	~renderer();

	// Pass current width/height/size etc...
	void setup(int w, int h, int s, const struct str_model_3d *obj, GdkPixmap *p, GdkGC *gc);
	void setup(int w, int h, int s, const struct str_model_3d *ibj, GdkImage *im);

	// Render using current parameters...
	void render(render_type rt);

};

#endif	// _RENDERER_H_
