//
// w_palette_prefs.h
//
// Prefs window for palette
//
// Copyright (c) J. Belson	1998.06.30
//


#ifndef _W_PALETTE_PREFS_H_
#define _W_PALETTE_PREFS_H_

#include <iostream.h>
#include <gtk--.h>

#include "w_prefs.h"


class w_palette_prefs : public w_prefs {

private:


public:
	w_palette_prefs();


};

#endif	// _W_PALETTE_PREFS_H_
