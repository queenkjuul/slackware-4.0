//
// w_preview_prefs.cc
//
// Control window for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.1.18
//


#include "w_preview_prefs.h"



w_preview_prefs::w_preview_prefs(void) : w_prefs("Preview prefs")
{


}


