//
// terrain.h
//
// Create a fractal landscape
//
// Copyright (c) J. Belson	1997.12.16
//


#ifndef _TERRAIN_H_
#define	_TERRAIN_H_

#include "calc.h"
#include "map.h"

#include "structs.h"

class terrain {

private:
	// 3d object structure
	str_model_3d model;

	// Fractal height data
	const float *height_field;

	// Current rotation about object centre
	float x_rot, y_rot, z_rot;

	// Map size in pixels
	int map_size;

	// Current terrain position in world
	float xpos, ypos, zpos;

	// Used to normalise relief map from -MAX_HEIGHTto +MAX_HEIGHT
	const float MAX_HEIGHT = 50;

	// Used in perspective transform
	const int DEPTH = 500;

	int index(int x, int y) {
		return (y*(map_size + 1) + x);
	}

	// Rotate terrain
	void rotate( /*float a, float b, float c*/ );

	// Translate terrain
	void translate(float x, float y, float z);	

	void normal_vector(str_tri *tri);
	void normal_vector(struct point *p,
					float x1, float y1, float z1,
					float x2, float y2, float z2,
					float x3, float y3, float z3);

	// Print debug messages
	void debug(char *msg) {
		//cout << msg << endl;
	}

protected:


public:
	// Constructor and destructor...
	terrain(void);
	~terrain();

	// Create a relief map object
	int generate_terrain(const float *relief, int size);

	// Transform the object with a/b/c rotations
	void transform(float a, float b, float c);

	// Get current terrain rotation
	void get_rotation(float *a, float *b, float *c);

	// Access transformed terrain object
	const struct str_model_3d *get_data(void) {
		return (const struct str_model_3d *) &model;
	}
};

#endif	// _TERRAIN_H_
