//
// w_output.h
//
// Output window for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.1.18
//


#ifndef _W_OUTPUT_H_
#define _W_OUTPUT_H_

#include <iostream.h>
#include <gtk--.h>

#include "renderer.h"
#include "terrain.h"
#include "map.h"

//
// Derive new drawingarea class to handle rendering
//

class w_output_drawingarea : public Gtk_DrawingArea {

private:

	// Class to handle rendering...
	renderer *rend;

	// Render relief map into here
	GdkPixmap *pixmap;

	// Render relief map into here
	GdkImage *d_image;

	// Store arguments to render() each time it is called,
	//  so configure...() can call it when necessary
	int obj_size;
	const struct str_model_3d *obj;

	void debug(char *msg) {
		//cout << msg << endl;
	}

public:
	w_output_drawingarea();
	~w_output_drawingarea();

	// Catch expose events
	virtual gint expose_event_impl(GdkEventExpose* e);

	// Catch configure events.
	virtual gint configure_event_impl(GdkEventConfigure* e);

	// Clear the backing pixmap
	void clear_screen(void);

	// Render map to memory...
	void render(int size, const struct str_model_3d *relief, render_type type);

};



class w_output : public Gtk_Window {

private:
	GtkWidget *window;
	GdkPixmap *d_pixmap;
	GdkImage *my_image;
	w_output_drawingarea *drawing_area;

	// Height field
	fbm_map *my_map;

	// Terrain object created from height field
	terrain *my_terrain;

	// Width of height field to be rendered
	int map_size;
	int map_order;

	// Required rotation of terrain to be rendered...
	float x_rot, y_rot, z_rot;

	// Size of required output image
	int width, height;

	void debug(char *msg) {
		//cout << msg << endl;
	}

public:
	w_output(void);
	~w_output(void);
	
	int open_window(int width, int height);
	int close_window(void);

	void set_size(int s) {
		width = height = s;
		drawing_area->size(s, s);
	}

	void render(int size, float fd, render_type type);

	// Set required rotation
	void set_rotation(float a, float b, float c);

	// Catch expose events
	virtual gint expose_event_impl(GdkEventExpose* e);

	// Catch configure events.
	virtual gint configure_event_impl(GdkEventConfigure* e);

};

#endif	// _W_OUTPUT_H_
