//
// my_drawingarea.h
//
// Inherit class from Gtk_DrawingArea
//
// Copyright (c) J. Belson	1998.2.3
//


#ifndef _MY_DRAWINGAREA_H_
#define _MY_DRAWINGAREA_H_

#include <iostream.h>
#include <gtk--.h>



#endif	// _MY_DRAWINGAREA_H_
