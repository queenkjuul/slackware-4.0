//
// w_output.cc
//
// Render window for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.1.18
//

#include "w_output.h"
#include "terrain.h"
#include "renderer.h"

#include <iostream.h>
#include <gtk--.h>


w_output::w_output(void)
{
	debug("Called output window constructor");

	d_pixmap = 0;

	// Default map size
	map_order = 8;
	map_size = int (pow(2, map_order));

	x_rot = y_rot = z_rot;

	set_title("Output");
}


w_output::~w_output(void)
{
	debug("Called output window destructor");
}


void w_output::set_rotation(float a, float b, float c)
{
	x_rot = a;
	y_rot = b;
	z_rot = c;
}


//
// Open output window
//
int w_output::open_window(int w, int h)
{
	// Store size
	width = w;
	height = h;

	// A partially successful attempt to disallow resizing
	set_policy(0, 0, 0);

	// Create derived DrawingArea to handle rendering
	drawing_area = new w_output_drawingarea();

	drawing_area->set_events(GDK_EXPOSURE_MASK |
							GDK_BUTTON_PRESS_MASK |
							GDK_BUTTON_RELEASE_MASK |
							GDK_POINTER_MOTION_MASK);
	drawing_area->size(width, height);
	add(drawing_area);
	drawing_area->show();

	// No errors
	return 0;
}


void w_output::render(int size, float fd, render_type type)
{
	debug("Rendering output");

	delete my_map;
	my_map = new fbm_map(map_order, fd);

	delete my_terrain;
	my_terrain = new terrain;
	my_terrain->generate_terrain(my_map->get_data(), map_size);

	// Rotate by required amount...
	my_terrain->transform(x_rot, y_rot, z_rot);

	drawing_area->clear_screen();

	// Do actual rendering...
	drawing_area->render(map_size, my_terrain->get_data(), type);

	// Persuade gtk to update rendered image...
	GdkRectangle update_rect;
	update_rect.x = 0;
	update_rect.y = 0;
	update_rect.width = GTK_WIDGET(gtkobject)->allocation.width;
	update_rect.height = GTK_WIDGET(gtkobject)->allocation.height;
	gtk_widget_draw(GTK_WIDGET(gtkobject), &update_rect);

}




//
// Constructor/destructor
//
w_output_drawingarea::w_output_drawingarea()
{
	debug("Called output_drawingarea constructor");
	d_image = 0;
	obj_size = 0;
	set_events(GDK_EXPOSURE_MASK);
}

w_output_drawingarea::~w_output_drawingarea()
{
	delete rend;
}


//
// Overloaded event implementations...
//
gint w_output_drawingarea::expose_event_impl(GdkEventExpose* e)
{
	//printf("Got expose in output_drawingarea\n");

	// Call parent expose handler...
	Gtk_Widget::expose_event_impl(e);                           

	gdk_draw_image(GTK_WIDGET(gtkobject)->window,
			GTK_WIDGET(gtkobject)->style->fg_gc[GTK_WIDGET_STATE(GTK_WIDGET(gtkobject))],
			d_image,
			e->area.x, e->area.y,
			e->area.x, e->area.y,
			e->area.width, e->area.height);


	return 0;                                                 
}


gint w_output_drawingarea::configure_event_impl(GdkEventConfigure* e)
{ 
	//printf("Got configure in output_drawingarea\n");

	// Call baseclass configure function
	Gtk_Widget::configure_event_impl(e);                           

	if (d_image) {
		gdk_image_destroy(d_image);
	}

	d_image = gdk_image_new(GDK_IMAGE_NORMAL,
					gdk_window_get_visual(GTK_WIDGET(gtkobject)->window),
					GTK_WIDGET(gtkobject)->allocation.width,
					GTK_WIDGET(gtkobject)->allocation.height);

	clear_screen();

	gdk_draw_image(GTK_WIDGET(gtkobject)->window,
					GTK_WIDGET(gtkobject)->style->white_gc, d_image,
					0,0,0,0, 
					GTK_WIDGET(gtkobject)->allocation.width,
					GTK_WIDGET(gtkobject)->allocation.height);


	// Re-render terrain using data from previous invocation
	//rerender();

	return 0;                                                 
}


// Clear backing pixmap
void w_output_drawingarea::clear_screen(void)
{
	int width = GTK_WIDGET(gtkobject)->allocation.width;
	int height = GTK_WIDGET(gtkobject)->allocation.height;

	if (d_image) {
		gdk_image_destroy(d_image);
	}

	d_image = gdk_image_new(GDK_IMAGE_NORMAL,
					gdk_window_get_visual(GTK_WIDGET(gtkobject)->window),
					GTK_WIDGET(gtkobject)->allocation.width,
					GTK_WIDGET(gtkobject)->allocation.height);

	// Crap way of setting background colour...
	guint16 *buf = (guint16 *) d_image->mem;
	int r=0x5fff, g=0x5fff, b=0xefff;
	for (int y=0; y<height; y++) {
		for (int x=0; x<width; x++) {
			*buf++ =	( (((r) >> 11) << 11)		// 5 bits of red
						| (((g) >> 10) <<  5)		// 6 bits of green
						| (((b) >> 11) <<  0));		// 5 bits of blue
		}
	}

	gdk_draw_image(GTK_WIDGET(gtkobject)->window,
					GTK_WIDGET(gtkobject)->style->white_gc, d_image,
					0,0,0,0, 
					GTK_WIDGET(gtkobject)->allocation.width,
					GTK_WIDGET(gtkobject)->allocation.height);
}


// Render using supplied arguments
void w_output_drawingarea::render(int size, const struct str_model_3d *object, render_type type)
{
	int width = GTK_WIDGET(gtkobject)->allocation.width;
	int height = GTK_WIDGET(gtkobject)->allocation.height;

	// Store values...
	obj = object;
	obj_size = size;

	// Allocate renderer class
	rend = new renderer;

	// Set up the renderer class with necessary values...
	rend->setup(width,
				height,
				size,
				object,
				d_image);

	// ...and render it
	rend->render(type);

	// Free class..
	delete rend;

}


// Catch expose events
gint w_output::expose_event_impl(GdkEventExpose* e)
{
	//printf("expose in output window\n");
	Gtk_Widget::expose_event_impl(e);                           

	return 0;                                                 
}
	
	
// Catch configure events.
gint w_output::configure_event_impl(GdkEventConfigure* e)
{ 
	//printf("configure in output window\n");

	// Call baseclass configure function
	Gtk_Widget::configure_event_impl(e);    

	return 0;                                                 
}
