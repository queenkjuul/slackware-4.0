//
// w_rendering_prefs.h
//
// Prefs window for renderering
//
// Copyright (c) J. Belson	1998.6.30
//


#ifndef _W_RENDER_PREFS_H_
#define _W_RENDER_PREFS_H_

#include <iostream.h>
#include <gtk--.h>

#include "structs.h"
#include "w_prefs.h"



class w_render_prefs : public w_prefs {

private:
	struct str_render_settings {
		render_type type;		// Rendering algorithm
	} render_settings;

	Gtk_RadioButton *render_type1, *render_type2, *render_type3;

	// Callbacks
	void render_gouraud_callback(void);
	void render_lambert_callback(void);

public:
	w_render_prefs(const str_settings& settings);

	// Access functions...
	render_type get_render_type(void) const {
		return render_settings.type;
	}

};


#endif	// _W_RENDER_PREFS_H_
