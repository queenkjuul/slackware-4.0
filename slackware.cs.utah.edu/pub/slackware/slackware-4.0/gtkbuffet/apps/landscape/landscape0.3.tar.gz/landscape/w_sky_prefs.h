//
// w_sky_prefs.h
//
// Prefs window for sky
//
// Copyright (c) J. Belson	1998.6.30
//


#ifndef _W_SKY_PREFS_H_
#define _W_SKY_PREFS_H_

#include <iostream.h>
#include <gtk--.h>

#include "w_prefs.h"


class w_sky_prefs : public w_prefs {

private:


public:
	w_sky_prefs();


};

#endif	// _W_SKY_PREFS_H_
