//
// w_relief_drawingarea.cc
//
// Relief view for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.6.23
//

#include "w_relief_drawingarea.h"

#include <iostream.h>
#include <gtk--.h>




// Catch expose events in my_drawingarea
gint w_relief_drawingarea::expose_event_impl(GdkEventExpose* e)
{
	//printf("Got expose in relief_drawingarea\n");

	// Call parent expose handler...
	Gtk_Widget::expose_event_impl(e);                           

	gdk_draw_image(GTK_WIDGET(gtkobject)->window,
			GTK_WIDGET(gtkobject)->style->fg_gc[GTK_WIDGET_STATE(GTK_WIDGET(gtkobject))],
			d_image,
			e->area.x, e->area.y,
			e->area.x, e->area.y,
			e->area.width, e->area.height);

	return 0;                                                 
}


// Catch configure events.
gint w_relief_drawingarea::configure_event_impl(GdkEventConfigure* e)
{ 
	//printf("Got configure in my_drawingarea\n");

	// Call baseclass configure function
	Gtk_Widget::configure_event_impl(e);                           

	if (d_image) {
		gdk_image_destroy(d_image);
	}

	d_image = gdk_image_new(GDK_IMAGE_NORMAL,
					gdk_window_get_visual(GTK_WIDGET(gtkobject)->window),
					GTK_WIDGET(gtkobject)->allocation.width,
					GTK_WIDGET(gtkobject)->allocation.height);

	gdk_draw_image(GTK_WIDGET(gtkobject)->window,
					GTK_WIDGET(gtkobject)->style->white_gc, d_image,
					0,0,0,0, 
					GTK_WIDGET(gtkobject)->allocation.width,
					GTK_WIDGET(gtkobject)->allocation.height);

	return 0;                                                 
}

