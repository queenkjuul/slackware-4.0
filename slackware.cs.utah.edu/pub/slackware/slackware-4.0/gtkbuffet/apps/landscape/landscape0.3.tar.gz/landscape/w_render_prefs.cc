//
// w_render_prefs.cc
//
// Prefs window for renderer
//
// Copyright (c) J. Belson	1998.06.30
//

#include "w_render_prefs.h"
#include "renderer.h"


w_render_prefs::w_render_prefs(const str_settings& settings) :
			w_prefs("Render prefs")
{
	cout << "w_render_prefs constructor" << endl;

	// Controls
	Gtk_Label *l_type = new Gtk_Label("Render type");
	l_type->show();
	frame_box->add(l_type);

	render_type1 = new Gtk_RadioButton(NULL, "Lambert");
	frame_box->pack_start(render_type1, TRUE, TRUE, 0);
	render_type1->show();

	connect_to_method(render_type1->toggled, this, &render_lambert_callback);

	render_type2 = new Gtk_RadioButton(render_type1->group(), "Gouraud");
	frame_box->pack_start(render_type2, TRUE, TRUE, 0);
	render_type2->show();

	connect_to_method(render_type2->toggled, this, &render_gouraud_callback);

	render_settings.type = settings.type;
	if (render_settings.type == LAMBERT) {
		render_type1->set_state(true);
		render_type2->set_state(false);
	} else {
		render_type1->set_state(false);
		render_type2->set_state(true);
	}
}


void w_render_prefs::render_lambert_callback(void)
{
	if (render_type1->get_state()) {
		cout << "Landbert rendering" << endl;
	}
	render_settings.type = LAMBERT;
}


void w_render_prefs::render_gouraud_callback(void)
{
	if (render_type2->get_state()) {
		cout << "Gouraud rendering" << endl;
	}
	render_settings.type = GOURAUD;
}



