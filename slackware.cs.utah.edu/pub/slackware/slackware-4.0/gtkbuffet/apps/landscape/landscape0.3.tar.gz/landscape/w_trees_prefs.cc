//
// w_trees_prefs.cc
//
// Prefs window for trees
//
// Copyright (c) J. Belson	1998.06.30
//


#include "w_trees_prefs.h"


// Open window and create widgets
w_trees_prefs::w_trees_prefs(void) : w_prefs("Tree prefs")
{

}
