//
// w_control.h
//
// Control window for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.1.18
//


#ifndef _W_CONTROL_H_
#define _W_CONTROL_H_

#include <iostream.h>
#include <gtk--.h>

#include "w_preview.h"
#include "w_output.h"
#include "map.h"
#include "terrain.h"
#include "renderer.h"
#include "w_relief_drawingarea.h"
#include "structs.h"
#include "w_render_prefs.h"
#include "w_prefs.h"


class w_control : public Gtk_Window {

private:

	str_settings settings;

	// Pointers to other windows classes...
	w_output		*output_win;
	w_preview		*preview_win;
	w_render_prefs	*wrp;

	// Classes for handling fractal...
	fbm_map		*preview_map;
	fbm_map		*relief_map;

	// Render relief into here...
	w_relief_drawingarea *relief_drawing_area;

	// Random seed
	unsigned int seed;

	// Menu stuff
    Gtk_MenuBar		*mbar;
    Gtk_MenuFactory	*mfactory;
    Gtk_MenuFactory *submfactory;

	// Assorted widgets...
	Gtk_VBox *main_box;
	Gtk_HBox *horiz_box;
	Gtk_VBox *left_box;
	Gtk_VBox *middle_box;
	Gtk_VBox *right_box;
	Gtk_HBox *bottom_box;
	Gtk_VBox *frame_box;
	Gtk_Separator *sep;
	Gtk_Notebook *nb;
	Gtk_VBox	*control_box;
	Gtk_Frame	*f1, *f2, *f3, *f4, *f5;
	Gtk_Box		*b1, *b2, *b3, *b4, *b5, *b6, *b7;
	Gtk_Label	*l1, *l2, *l3, *l4, *l5;

	// Render type...
	Gtk_Label *l_type;

	// Fractal size
	Gtk_Adjustment *adj_size;
	Gtk_Scale *sc_size;
	Gtk_Label *l_size;

	// Fractal dimension
	Gtk_Adjustment *adj_dimen;
	Gtk_Scale *sc_dimen;
	Gtk_Label *l_dimen;

	// Control buttons
	Gtk_Button *randomise_button;
	Gtk_Button *generate_button;
	Gtk_Button *render_button;
	Gtk_Button *quit_button;

	// Rendering space...
	Gtk_DrawingArea *drawing_area;
	Gtk_Pixmap *pixmap;
	GdkPixmap *d_pixmap;

	// Menu...
	GtkMenuFactory *factory;
    GtkWidget *menubar;

	enum enumConsts {
		RELIEF_MAP_SIZE = 256,
		RELIEF_MAP_ORDER = 8
	};

	void delete_event(void) {
		cout << "Close button event detected in control window" << endl;
	}

	// Render the relief view...
	void render_relief(const float *relief);
	void plot(guint16 *buf, guint32 r, guint32 g, guint32 b);


	// Button callbacks...
	void generate_callback(void );
	void generate_callback2(void );
	void quit_callback(void);
	void randomise_callback(void);
	void render_callback(void);
	void dimen_callback(void);
	void size_callback(void);

	// Radio button callbacks
	void render_lambert_callback(void);
	void render_gouraud_callback(void);

	// Menu callbacks...
	void menu_quit_callback(char *data);
	void menu_about_callback(char *data);
	void menu_preview_callback(char *data);
	void menu_output_callback(char *data);
	void prefs_sky_callback(char *data);
	void prefs_lighting_callback(char *data);
	void prefs_trees_callback(char *data);
	void prefs_preview_callback(char *data);
	void prefs_rendering_callback(char *data);
	void prefs_rendering_button(enum_button i);
	void prefs_palette_callback(char *data);

	gint expose_event(GtkWidget *widget, GdkEventExpose *event);
	gint configure_event(GtkWidget *widget, GdkEventConfigure *event);

	void debug(char *msg) {
		cout << msg << endl;
	}

public:

	w_control();
	~w_control();
	
	int open_windows(void);
	int close_window(void);

};


#endif	// _W_CONTROL_H_
