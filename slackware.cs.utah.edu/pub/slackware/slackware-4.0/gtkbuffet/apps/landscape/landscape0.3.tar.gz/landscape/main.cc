//
// main.cc
//
// Main program for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.1.9
//

#include <iostream.h>

#include <gtk--.h>

#include "w_control.h"


int main(int argc, char **argv)
{
	Gtk_Main m(&argc, &argv);

	cout << "\n\nLandscape v0.3, Copyright 1998 J. Belson\n\n" << endl;

	w_control *c = new w_control;
	c->open_windows();
	c->show();

	m.run();

	return 0;
}
