//
// w_palette_prefs.cc
//
// Control window for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.07.08
//


#include "w_palette_prefs.h"


w_palette_prefs::w_palette_prefs(void) : w_prefs("Palette prefs")
{


}

