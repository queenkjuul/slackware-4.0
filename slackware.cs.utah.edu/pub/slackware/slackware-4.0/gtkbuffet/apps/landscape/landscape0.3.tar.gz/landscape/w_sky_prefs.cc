//
// w_sky_prefs.cc
//
// Prefs window for sky
//
// Copyright (c) J. Belson	1998.06.30
//


#include "w_sky_prefs.h"



// Open window and create widgets
w_sky_prefs::w_sky_prefs(void) : w_prefs("Sky prefs")
{

}
