//
// calc.h
//
// Copyright (c) J. Belson	1998.1.2
//


#ifndef _CALC_H_
#define _CALC_H_

	// Generate random real number
	float ran1(void);

	// Generate Gaussian random number, zero mean, unit variance
	float gasdev(void);

#endif	// _CALC_H_
