//
// w_relief_drawingarea.h
//
// Relief view for fractal landscape renderer
//
// Copyright (c) J. Belson	1998.6.23
//

#ifndef _W_RELIEF_DRAWINGAREA_H_
#define _W_RELIEF_DRAWINGAREA_H_

#include <iostream.h>
#include <gtk--.h>

#include "map.h"


//
// Derive new drawingarea class to handle rendering
//

class w_relief_drawingarea : public Gtk_DrawingArea {

	// Relief needs access to d_image...
	//friend class w_relief;
	friend class w_control;

private:
	// Render relief map into here
	GdkImage *d_image;

	void debug(char *msg) {
		cout << msg << endl;
	}
	
public:
	w_relief_drawingarea() {
		debug("Called relief_drawingarea constructor");
		d_image = 0;
		set_events(GDK_EXPOSURE_MASK);
	}
	~w_relief_drawingarea() {};

	// Catch expose events
	virtual gint expose_event_impl(GdkEventExpose* e);

	// Catch configure events.
	virtual gint configure_event_impl(GdkEventConfigure* e);

};



#endif	// _W_RELIEF_DRAWINGAREA_H_

