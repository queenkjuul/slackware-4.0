/* GMP3 - A front end for mpg123
 * Copyright (C) 1998 Brett Kosinski
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
 
#include <gtk/gtk.h>
#include <string.h>
#include "gmp3.h"

void bufferEntryCallback(GtkWidget *widget, gpointer *data)
{
  char *entryString;

  entryString = gtk_entry_get_text(GTK_ENTRY(widget));
  if (strlen(entryString) == 0)     
    options.bufferSize = 0;
  else
    sscanf(entryString, "%d", &options.bufferSize);
}

void noBufferCallback(GtkWidget *widget, GtkWidget *entry)
{
  if (GTK_WIDGET_VISIBLE(entry))
    {
      gtk_entry_set_text(GTK_ENTRY(entry), "");    
      gtk_widget_hide(entry);
      options.bufferSize = 0;
    }
  else
    gtk_widget_show(entry);      
}

void lineOutCallback(GtkWidget *widget, gpointer *data)
{
  options.lineOut = ! options.lineOut;
} 

void outputCallback(GtkWidget *widget, int outputType)
{
  if (GTK_TOGGLE_BUTTON(widget)->active)
    options.output = outputType;
}

void downSampleCallback(GtkWidget *widget, int sampleVal)
{
  if (GTK_TOGGLE_BUTTON(widget)->active)
    options.downSample = sampleVal;
}

void borderCallback(GtkWidget *widget, gpointer *data)
{
  options.managed = ! options.managed;
}

void toolTipsCallback(GtkWidget *widget, gpointer *data)
{
  options.toolTips = ! options.toolTips;
}

void autoparseCallback(GtkWidget *widget, gpointer *data)
{
  options.autoparse = ! options.autoparse;
}

void createOptionsDialog()
{
  GtkWidget *optionsDialog;

  GtkWidget *button;
  GtkWidget *entry;    
  GtkWidget *label;
  GtkWidget *hbox;
  GtkWidget *vbox;
  GtkWidget *separator;
  char strBuffer[50];

  optionsDialog = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(optionsDialog), "Options");
  
  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(optionsDialog), vbox);
  gtk_widget_show(vbox);
  
/* Set up the buffer size widgets. */

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 0);
  gtk_widget_show(hbox);   

  button = gtk_check_button_new_with_label("Buffer");
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  
  entry = gtk_entry_new();
  gtk_box_pack_start(GTK_BOX(hbox), entry, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(entry), "changed",
                     GTK_SIGNAL_FUNC(bufferEntryCallback), NULL);
  
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(noBufferCallback), entry);
                     
  if (options.bufferSize != 0)
    {
      gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);
      gtk_widget_show(entry);
      
      sprintf(strBuffer, "%d", options.bufferSize);
      gtk_entry_set_text(GTK_ENTRY(entry), strBuffer);
    }      
    
/* Now the downsampling stuff */  

  separator = gtk_hseparator_new();
  gtk_widget_show(separator);
  gtk_box_pack_start(GTK_BOX(vbox), separator, TRUE, TRUE, 0);

  label = gtk_label_new("Down Sampling");
  gtk_widget_show(label);
  gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 0);  

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 0);
  gtk_widget_show(hbox);   

  button = gtk_radio_button_new_with_label(NULL, "1:1");
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  
  if (options.downSample == 0)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);
    
  gtk_signal_connect(GTK_OBJECT(button), "toggled",
                     GTK_SIGNAL_FUNC(downSampleCallback), (int *)(0));

  button = gtk_radio_button_new_with_label(
           gtk_radio_button_group(GTK_RADIO_BUTTON(button)), "1:2");
           
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  
  if (options.downSample == 2)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);
    
  gtk_signal_connect(GTK_OBJECT(button), "toggled",
                     GTK_SIGNAL_FUNC(downSampleCallback), (int *)(2));  

  button = gtk_radio_button_new_with_label(
           gtk_radio_button_group(GTK_RADIO_BUTTON(button)), "1:4");
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  
  if (options.downSample == 4)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);
    
  gtk_signal_connect(GTK_OBJECT(button), "toggled",
                     GTK_SIGNAL_FUNC(downSampleCallback), (int *)(4));  
                     
/* Lineout checkbox */

  separator = gtk_hseparator_new();
  gtk_widget_show(separator);
  gtk_box_pack_start(GTK_BOX(vbox), separator, TRUE, TRUE, 0);

  label = gtk_label_new("Output Target");
  gtk_widget_show(label);
  gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 0);  

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 0);
  gtk_widget_show(hbox);   
                         
  button = gtk_check_button_new_with_label("Output to Lineout");  
  
  if (options.lineOut)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);

  gtk_widget_show(button);  
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(lineOutCallback), NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  
/* Output type */

  separator = gtk_hseparator_new();
  gtk_widget_show(separator);
  gtk_box_pack_start(GTK_BOX(vbox), separator, TRUE, TRUE, 0);

  label = gtk_label_new("Output Type");
  gtk_widget_show(label);
  gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 0);  

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 0);
  gtk_widget_show(hbox);   

  button = gtk_radio_button_new_with_label(NULL, "Left");
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  
  if (options.output == LEFT)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);
    
  gtk_signal_connect(GTK_OBJECT(button), "toggled",
                     GTK_SIGNAL_FUNC(outputCallback), (int *)(LEFT));

  button = gtk_radio_button_new_with_label(
           gtk_radio_button_group(GTK_RADIO_BUTTON(button)), "Right");
           
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  
  if (options.output == RIGHT)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);
    
  gtk_signal_connect(GTK_OBJECT(button), "toggled",
                     GTK_SIGNAL_FUNC(outputCallback), (int *)(RIGHT));  

  button = gtk_radio_button_new_with_label(
           gtk_radio_button_group(GTK_RADIO_BUTTON(button)), "Stereo");
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  
  if (options.output == STEREO)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);
    
  gtk_signal_connect(GTK_OBJECT(button), "toggled",
                     GTK_SIGNAL_FUNC(outputCallback), (int *)(STEREO));  

  button = gtk_radio_button_new_with_label(
           gtk_radio_button_group(GTK_RADIO_BUTTON(button)), "Mono");
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  
  if (options.output == MONO)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);
    
  gtk_signal_connect(GTK_OBJECT(button), "toggled",
                     GTK_SIGNAL_FUNC(outputCallback), (int *)(MONO));  
                                          
/* Border checkbox */

  separator = gtk_hseparator_new();
  gtk_widget_show(separator);
  gtk_box_pack_start(GTK_BOX(vbox), separator, TRUE, TRUE, 0);

  label = gtk_label_new("Miscellaneous Properties");
  gtk_widget_show(label);
  gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 0);  

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 0);
  gtk_widget_show(hbox);   
                         
  button = gtk_check_button_new_with_label("Window is managed");  
  
  if (options.managed)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);

  gtk_widget_show(button);  
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(borderCallback), NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
                     
/* Tooltips Stuff */

  button = gtk_check_button_new_with_label("Enable Tooltips");  
  
  if (options.toolTips)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);

  gtk_widget_show(button);  
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(toolTipsCallback), NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);

/* Autoparsing Toggle */

  button = gtk_check_button_new_with_label("Enable Autoparsing");  
  
  if (options.autoparse)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(button), TRUE);

  gtk_widget_show(button);  
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(autoparseCallback), NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
                     
/* Control Buttons */

  separator = gtk_hseparator_new();
  gtk_widget_show(separator);
  gtk_box_pack_start(GTK_BOX(vbox), separator, TRUE, TRUE, 0);

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 0);
  gtk_widget_show(hbox);   
  
  button = gtk_button_new_with_label("Save");
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(saveRCFile), NULL);
  
  button = gtk_button_new_with_label("Close");
  gtk_widget_show(button);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
                            GTK_SIGNAL_FUNC(gtk_widget_destroy),
                            GTK_OBJECT(optionsDialog));
                                          
  gtk_widget_show(optionsDialog);
}