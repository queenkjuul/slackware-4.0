/* GMP3 - A front end for mpg123
 * Copyright (C) 1998 Brett Kosinski
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
 
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/time.h>
#include <strings.h>
#include "pixmap.h"
#include "control_funcs.h"
#include "shape.h"
#include "albumnlist.h"
#include "playlist.h"
#include "songlist.h"
#include "mixerpanel.h"
#include "gmp3.h"
#include "mixer.h"
#include "rc_parser.h"
#include "opt_dialog.h"

GdkWindow *root_win;

program_window mainWindow;
configType options;

GtkWidget *mainMenu;

pid_t mpgPID;

int smallSize = FALSE;
int playing = FALSE;
int doneSong = TRUE;
int paused = FALSE;
int loopOne = FALSE;
int loopAll = FALSE;
int shuffle = FALSE;
long int startSecs = 0;
long int currSecs = 0;
int oldSeconds = 0;

void bringToFront(GtkWidget *widget, GdkEventVisibility *event);
void createSmallWindow();
void createBigWindow();
void resizeMainWindow();
void installSigHandler();

void childKill(int signal)
{
  int status;      
  
  waitpid(-1, &status, WNOHANG | WUNTRACED);
  if (! WIFSTOPPED(&status))
    {
      mpgPID = 0;
      doneSong = TRUE;
    
      g_print("mpg123 exited\n");
    }  
  
  installSigHandler();
}

void installSigHandler()
{
  signal(SIGCHLD, childKill);
}

#define TOKENCOUNT 9

void loadRCFile()
{  
  tokenInfo tokens[TOKENCOUNT] = { { "buffer_size", INTEGER, NULL },
                                   { "downsample", INTEGER, NULL },
                                   { "output_type", INTEGER, NULL },
                                   { "send_to_lineout", BOOLEAN, NULL },
                                   { "managed", BOOLEAN, NULL },
                                   { "tooltips", BOOLEAN, NULL },
                                   { "autoload", STRING, NULL },
                                   { "autoparse", BOOLEAN, NULL},
                                   { "mixerapp", STRING, NULL } };
                          
  char *homeDir = getenv("HOME");
  char *rcFile = (char *)malloc(strlen(homeDir)+strlen(RCFILENAME)+2);
  
  strcpy(rcFile, homeDir);
  strcat(rcFile, "/");
  strcat(rcFile, RCFILENAME);
  
  options.bufferSize = 1500;
  options.downSample = 0;              /* Create default settings. */
  options.output = 2;
  options.lineOut = FALSE;
  options.managed = TRUE;
  options.toolTips = TRUE;
  options.playListName = (char *)malloc(255);
  options.playListName[0] = '\0';
  options.autoparse = FALSE;  
  options.mixerApp = (char *)malloc(255);
  options.mixerApp[0] = '\0';

  tokens[0].dataBuffer = &options.bufferSize;
  tokens[1].dataBuffer = &options.downSample;
  tokens[2].dataBuffer = &options.output;     /* Set up the tokens correctly */
  tokens[3].dataBuffer = &options.lineOut;
  tokens[4].dataBuffer = &options.managed;
  tokens[5].dataBuffer = &options.toolTips;
  tokens[6].dataBuffer = options.playListName;
  tokens[7].dataBuffer = &options.autoparse;
  tokens[8].dataBuffer = options.mixerApp;
  
  parseFile(rcFile, tokens, TOKENCOUNT);

  if (options.playListName[0] != '\0')  /* Read playlist from autoload param */
    loadLists(options.playListName);
  
  free(rcFile);
}  

void saveRCFile()
{
  FILE *outputFile;
  char *homeDir = getenv("HOME");
  char *rcFile = (char *)malloc(strlen(homeDir)+strlen(RCFILENAME)+2);
  
  strcpy(rcFile, homeDir);
  strcat(rcFile, "/");
  strcat(rcFile, RCFILENAME);
  
  outputFile = fopen(rcFile, "w");
  
  if (outputFile)
    {  
      fprintf(outputFile, "buffer = %d\n", options.bufferSize);
      fprintf(outputFile, "downsample = %d\n", options.downSample);
      fprintf(outputFile, "output_type = %d\n", options.output);
  
      if (options.lineOut)
        fprintf(outputFile, "send_to_lineout = TRUE\n");
      else
        fprintf(outputFile, "send_to_lineout = FALSE\n");
  
      if (options.managed)
        fprintf(outputFile, "managed = TRUE\n");
      else
        fprintf(outputFile, "managed = FALSE\n");
    
      
      if (options.toolTips)
        fprintf(outputFile, "tooltips = TRUE\n");
      else
        fprintf(outputFile, "tooltips = FALSE\n");  
        
      if (options.autoparse)
        fprintf(outputFile, "autoparse = TRUE\n");
      else
        fprintf(outputFile, "autoparse = FALSE\n");    
        
      if (options.playListName[0] != '\0')
        fprintf(outputFile, "autoload = %s\n", options.playListName);

      if (options.mixerApp[0] != '\0')
        fprintf(outputFile, "mixerapp = %s\n", options.mixerApp);
              
      fclose(outputFile);    
    }  
}

void loadCommandlineFiles(int argc, char *argv[])
{
  int i;
  
  for (i = 1; i < argc; i++)
    {
      addSongToList(argv[i], playList);
      
      playing = TRUE;
      doneSong = TRUE;
    }
}

void printSongName()
{          
  char *currentSongName;

  if ((playList == NULL) || (g_list_first(playList)->next == NULL))
    return;

  currentSongName = ((songEntry *)(currentSong->data))->title;
          
  if ((currentSongName == NULL) || (strlen(currentSongName) <= 0))
    currentSongName = ((songEntry *)(currentSong->data))->fileName;
            
  gtk_label_set(GTK_LABEL(mainWindow.songTitleLabel), currentSongName);
}

void resetClock()
{
  gtk_label_set(GTK_LABEL(mainWindow.timeLabel), "0:00");
}

int playLoop()
{  
  if (playing && doneSong)
    {    
      if (! nextSong(TRUE))
        {
          play(NULL, &options);

          playing = TRUE;
          doneSong = FALSE;
                    
          printSongName();
        }  
      else
        {
          if (shuffle)
            clearPlayedFlags();
            
          playing = FALSE;
          doneSong = TRUE;
          
          currentSong = g_list_first(playList)->next;
        }  
                
      startSecs = currSecs;  
    }      
    
  return TRUE;    
}

int adjustTimer()
{    
  char secondStr[4];
  char timeStr[8];
  struct timeval time;
  struct timezone zone;
  int seconds;
  
  gettimeofday(&time, &zone);
  currSecs = time.tv_sec;

  if (playing && ! doneSong && ! paused)
    {           
      seconds = currSecs - startSecs;
      
      if (oldSeconds != currSecs)
        { 
          oldSeconds = currSecs;
        
          sprintf(secondStr, "%d", seconds % 60);
        
          if (strlen(secondStr) > 1)
            sprintf(timeStr, "%d:%s", seconds / 60, secondStr);
          else
            sprintf(timeStr, "%d:0%s", seconds / 60, secondStr);  
            
          gtk_label_set(GTK_LABEL(mainWindow.timeLabel), timeStr);  
       }   
    }
  else if (paused)
         {
           seconds = currSecs - startSecs;  
           
           if (currSecs != oldSeconds)
             {               
               oldSeconds = currSecs;       /* This part adjusts for pausing */   
               startSecs++;                 /* time. */
             }
         }  
         
  return TRUE;         
}

void stopCallback()
{
  if (paused)
    gtk_widget_hide(mainWindow.pausedLabel);
    
  stop();  
}

void playCallback()
{
  if (playing)
    return;
      
  if (shuffle)
    {
      clearPlayedFlags();
      nextSong(TRUE);
    }

  resetClock();
  play(NULL, &options);    
}

void togglePause()
{    
  pauseSong();  
  
  if (paused)
    gtk_widget_show(mainWindow.pausedLabel);
  else
    gtk_widget_hide(mainWindow.pausedLabel);  
}

void toggleShuffle()
{
  if (shuffle)
    {
      shuffle = FALSE;
      gtk_widget_hide(mainWindow.shuffleLabel);
    }  
  else
    {
      shuffle = TRUE;
      gtk_widget_show(mainWindow.shuffleLabel);
    }  
}

void toggleLoop()
{
  if (loopAll || loopOne)
    {
      loopOne = loopAll;
      loopAll = FALSE;
      
      if (loopOne)
        gtk_label_set(GTK_LABEL(mainWindow.repeatLabel), "Repeat");
      else 
        gtk_widget_hide(mainWindow.repeatLabel);    
    }
  else
    {
      gtk_label_set(GTK_LABEL(mainWindow.repeatLabel), "Repeat All");
      gtk_widget_show(mainWindow.repeatLabel);
    
      loopAll = TRUE;       
    }  
}

void quitCallback()
{
  if ((playing) && (! doneSong))
    stop();
   
  gtk_main_quit();
}

void destroy_window(GtkWidget *widget, GtkWidget **window)
{  
  *window = NULL;
}

void volumeSliderCallback(GtkAdjustment *adjustment, gpointer *data)
{
  mixerSettings.globalVolume = adjustment->value;
  
  if (mixerExists)
    setVolume();
}

GtkWidget *createButton(GtkWidget *window, char *fileName)
{  
  GtkWidget *button;
  GtkWidget *pixmapwid;

  pixmapwid = new_pixmap(fileName, window->window, 
                         &window->style->bg[GTK_STATE_NORMAL]);                                             
  button = gtk_button_new();                           
  gtk_container_add(GTK_CONTAINER(button), pixmapwid);     
  gtk_widget_show(pixmapwid);
  
  return button;
}

GtkWidget *createMenu()
{
  GtkWidget *menu;
  GtkWidget *menuItems;
  
  menu = gtk_menu_new();    
                       
  gtk_widget_realize(menu);
  gdk_window_set_cursor(menu->window, gdk_cursor_new(GDK_LEFT_PTR));  
  
  menuItems = gtk_menu_item_new_with_label("Playlist Editor...");
  gtk_menu_append(GTK_MENU(menu), menuItems);
  gtk_signal_connect(GTK_OBJECT(menuItems), "activate",
                     GTK_SIGNAL_FUNC(createListDialog), NULL);
  gtk_widget_show(menuItems);                     

  if (mixerExists || (options.mixerApp[0] != '\0'))
    {
      menuItems = gtk_menu_item_new_with_label("Mixer Panel...");
      gtk_menu_append(GTK_MENU(menu), menuItems);
      gtk_signal_connect(GTK_OBJECT(menuItems), "activate",
                         GTK_SIGNAL_FUNC(openMixer), NULL);
      gtk_widget_show(menuItems);                     
    }  
                       
  menuItems = gtk_menu_item_new_with_label("Options...");
  gtk_menu_append(GTK_MENU(menu), menuItems);
  gtk_signal_connect(GTK_OBJECT(menuItems), "activate",
                     GTK_SIGNAL_FUNC(createOptionsDialog), NULL);
  gtk_widget_show(menuItems);

  menuItems = gtk_menu_item_new_with_label("Toggle Size");
  gtk_menu_append(GTK_MENU(menu), menuItems);
  gtk_signal_connect(GTK_OBJECT(menuItems), "activate",
                     GTK_SIGNAL_FUNC(resizeMainWindow), NULL);
  gtk_widget_show(menuItems);

  menuItems = gtk_menu_item_new_with_label("Quit");
  gtk_menu_append(GTK_MENU(menu), menuItems);
  gtk_signal_connect(GTK_OBJECT(menuItems), "activate",
                     GTK_SIGNAL_FUNC(quitCallback), NULL);
  gtk_widget_show(menuItems);                        
  
  return menu;
}

void createButtons()
{  
  mainWindow.backButton = createButton(mainWindow.window, "back.xpm");
  mainWindow.playButton = createButton(mainWindow.window, "play.xpm");                     
  mainWindow.forwardButton = createButton(mainWindow.window, "forward.xpm");
  mainWindow.stopButton = createButton(mainWindow.window, "stop.xpm");
  mainWindow.pauseButton = createButton(mainWindow.window, "pause.xpm");  
  mainWindow.shuffleButton = createButton(mainWindow.window, "shuffle.xpm");
  mainWindow.repeatButton = createButton(mainWindow.window, "repeat.xpm");  
 
 /* ugly tooltip code added by Ice */
 /* plus some modification by the author to support the rc file. */
 /* made tooltips code work with gtk 0.99.4 */

  if (options.toolTips)
    {
      mainWindow.Tooltips = gtk_tooltips_new ();

      gtk_tooltips_set_tip (mainWindow.Tooltips, mainWindow.backButton, "Previous Song", NULL);
      gtk_tooltips_set_tip (mainWindow.Tooltips, mainWindow.playButton, "Play", NULL);
      gtk_tooltips_set_tip (mainWindow.Tooltips, mainWindow.forwardButton, "Next Song", NULL);
      gtk_tooltips_set_tip (mainWindow.Tooltips, mainWindow.stopButton, "Stop", NULL);
      gtk_tooltips_set_tip (mainWindow.Tooltips, mainWindow.pauseButton, "Pause", NULL);
      gtk_tooltips_set_tip (mainWindow.Tooltips, mainWindow.shuffleButton, "Shuffle", NULL);
      gtk_tooltips_set_tip (mainWindow.Tooltips, mainWindow.repeatButton, "Repeat", NULL);
    }      
}

void loadDecorations()
{
  mainWindow.decoration = new_pixmap("bar.xpm", mainWindow.window->window, 
                                      &mainWindow.window->style->bg[GTK_STATE_NORMAL]);
}

void insertButtonBar()
{
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), mainWindow.backButton, 0, 0);
  gtk_widget_set_usize(mainWindow.backButton, 22, 22);
  gtk_widget_show(mainWindow.backButton);      
  gtk_signal_connect(GTK_OBJECT(mainWindow.backButton), "clicked",
                     GTK_SIGNAL_FUNC(back), &options);
  gtk_signal_connect(GTK_OBJECT(mainWindow.backButton), "clicked",
                     GTK_SIGNAL_FUNC(printSongName), NULL);
  gtk_signal_connect(GTK_OBJECT(mainWindow.backButton), "clicked",
                     GTK_SIGNAL_FUNC(resetClock), NULL);
  
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), mainWindow.playButton, 22, 0);
  gtk_widget_set_usize(mainWindow.playButton, 22, 22);
  gtk_widget_show(mainWindow.playButton);
  gtk_signal_connect(GTK_OBJECT(mainWindow.playButton), "clicked",
                     GTK_SIGNAL_FUNC(playCallback), &options);
  gtk_signal_connect(GTK_OBJECT(mainWindow.playButton), "clicked",
                     GTK_SIGNAL_FUNC(printSongName), NULL);
                     
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), mainWindow.forwardButton, 44, 0);
  gtk_widget_set_usize(mainWindow.forwardButton, 22, 22);
  gtk_widget_show(mainWindow.forwardButton);                         
  gtk_signal_connect(GTK_OBJECT(mainWindow.forwardButton), "clicked",
                     GTK_SIGNAL_FUNC(forward), &options);
  gtk_signal_connect(GTK_OBJECT(mainWindow.forwardButton), "clicked",
                     GTK_SIGNAL_FUNC(printSongName), NULL);
  gtk_signal_connect(GTK_OBJECT(mainWindow.forwardButton), "clicked",
                     GTK_SIGNAL_FUNC(resetClock), NULL);
  
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), mainWindow.stopButton, 66, 0);    
  gtk_widget_set_usize(mainWindow.stopButton, 22, 22);  
  gtk_widget_show(mainWindow.stopButton);
  gtk_signal_connect(GTK_OBJECT(mainWindow.stopButton), "clicked",
                     GTK_SIGNAL_FUNC(stopCallback), NULL);
  
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), mainWindow.pauseButton, 88, 0);
  gtk_widget_set_usize(mainWindow.pauseButton, 22, 22);
  gtk_widget_show(mainWindow.pauseButton);  
  gtk_signal_connect(GTK_OBJECT(mainWindow.pauseButton), "clicked",
                     GTK_SIGNAL_FUNC(togglePause), NULL);
  
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), mainWindow.shuffleButton, 110, 0);
  gtk_widget_set_usize(mainWindow.shuffleButton, 22, 22);
  gtk_widget_show(mainWindow.shuffleButton);  
  gtk_signal_connect(GTK_OBJECT(mainWindow.shuffleButton), "clicked",
                     GTK_SIGNAL_FUNC(toggleShuffle), NULL);
  
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), mainWindow.repeatButton, 132, 0);
  gtk_widget_set_usize(mainWindow.repeatButton, 22, 22);
  gtk_widget_show(mainWindow.repeatButton);  
  gtk_signal_connect(GTK_OBJECT(mainWindow.repeatButton), "clicked",
                     GTK_SIGNAL_FUNC(toggleLoop), NULL);
}

void moveButtonBar(int xOffs, int yOffs, int dxOffs, int dyOffs)
{
  gtk_fixed_move(GTK_FIXED(mainWindow.fixed), mainWindow.backButton, xOffs, yOffs);
  gtk_fixed_move(GTK_FIXED(mainWindow.fixed), mainWindow.playButton, 22+xOffs, yOffs);  
  gtk_fixed_move(GTK_FIXED(mainWindow.fixed), mainWindow.forwardButton, 44+xOffs, yOffs);
  gtk_fixed_move(GTK_FIXED(mainWindow.fixed), mainWindow.stopButton, 66+xOffs, yOffs);  
  gtk_fixed_move(GTK_FIXED(mainWindow.fixed), mainWindow.pauseButton, 88+xOffs, yOffs);
  gtk_fixed_move(GTK_FIXED(mainWindow.fixed), mainWindow.shuffleButton, 110+xOffs, yOffs);  
  gtk_fixed_move(GTK_FIXED(mainWindow.fixed), mainWindow.repeatButton, 132+xOffs, yOffs);
  gtk_fixed_move(GTK_FIXED(mainWindow.fixed), mainWindow.decoration, dxOffs, dyOffs);
}

void createBigWindow()
{
  gtk_widget_hide(mainWindow.window);
  
  gtk_widget_set_usize(mainWindow.fixed, 154, 72);
  gtk_widget_set_usize(mainWindow.window, 154, 72);
  gtk_widget_set_uposition(mainWindow.eventBox, 4, 5);
  gtk_widget_show(mainWindow.songTitleLabel);
  
  moveButtonBar(0, 50, 0, 0);   
  gtk_widget_show(mainWindow.window); 
  
  smallSize = FALSE;
}

void createSmallWindow()
{
  gtk_widget_hide(mainWindow.window);

  gtk_widget_set_usize(mainWindow.window, 159, 22);
  gtk_widget_set_usize(mainWindow.fixed, 159, 22);
  gtk_widget_set_uposition(mainWindow.eventBox, 0, 0);
  gtk_widget_hide(mainWindow.songTitleLabel);
  
  moveButtonBar(5, 0, 100, 100);    
  gtk_widget_show(mainWindow.window);
  
  smallSize = 1; 
}

void createMainWindow()
{
  GtkObject *adjustment;
  GtkWidget *fixed;
  GtkWidget *pixmap;
  GtkWidget *eventBox;
  GtkWidget *songTitleEventBox;
  GtkStyle *style;
  GdkFont *font;
  
  if (! options.managed)
    mainWindow.window = gtk_window_new(GTK_WINDOW_POPUP);
  else
    mainWindow.window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
      
  mainWindow.fixed = gtk_fixed_new(); 
  gtk_container_add(GTK_CONTAINER(mainWindow.window), mainWindow.fixed); 
  gtk_widget_show(mainWindow.fixed);  
    
  style = gtk_style_new();
  style->bg[GTK_STATE_NORMAL].red = 60;
  style->bg[GTK_STATE_NORMAL].green = 66;  
  style->bg[GTK_STATE_NORMAL].blue = 60;  
  
  mainWindow.eventBox = gtk_event_box_new();
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), mainWindow.eventBox, 4, 5);
  gtk_widget_set_usize(mainWindow.eventBox, 146, 23);
  gtk_widget_set_style(mainWindow.eventBox, style);
  gtk_widget_show(mainWindow.eventBox);  
  
  fixed = gtk_fixed_new();
  gtk_widget_set_style(fixed, style);
  gtk_container_add(GTK_CONTAINER(mainWindow.eventBox), fixed);
  
  gtk_widget_set_events(mainWindow.eventBox, 
                        gtk_widget_get_events(mainWindow.eventBox) |
                        GDK_BUTTON_MOTION_MASK | GDK_BUTTON_PRESS_MASK);
                          
  gtk_signal_connect(GTK_OBJECT(mainWindow.eventBox), "delete_event",
                     GTK_SIGNAL_FUNC(quitCallback),                    
                     NULL);
  gtk_signal_connect(GTK_OBJECT(mainWindow.eventBox), "button_press_event",
                     GTK_SIGNAL_FUNC(shape_pressed), &mainWindow);
  gtk_signal_connect(GTK_OBJECT(mainWindow.eventBox), "button_release_event",
                     GTK_SIGNAL_FUNC(shape_released), &mainWindow);
  gtk_signal_connect(GTK_OBJECT(mainWindow.eventBox), "motion_notify_event",
                     GTK_SIGNAL_FUNC(shape_motion), &mainWindow);
                     
  adjustment = gtk_adjustment_new(mixerSettings.globalVolume, 0.0, 101.0, 
                                  1.0, 5.0, 1.0);
  gtk_signal_connect(GTK_OBJECT(adjustment), "value_changed",
                     GTK_SIGNAL_FUNC(volumeSliderCallback), NULL);
 
  mainWindow.volumeControl = gtk_hscale_new(GTK_ADJUSTMENT(adjustment));
  gtk_scale_set_draw_value(GTK_SCALE(mainWindow.volumeControl), FALSE);
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), mainWindow.volumeControl, 1, 36);
  gtk_widget_set_usize(mainWindow.volumeControl, 152, 12);   
  gtk_widget_show(mainWindow.volumeControl);  
                     
  gtk_widget_realize(mainWindow.fixed);
  gdk_window_set_cursor(mainWindow.fixed->window, gdk_cursor_new(GDK_LEFT_PTR));
                     
  createButtons();                     
  loadDecorations();

  pixmap = new_pixmap("bar1.xpm", mainWindow.window->window, 
                      &mainWindow.window->style->bg[GTK_STATE_NORMAL]);
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), pixmap, 0, 0);
  gtk_widget_show(pixmap);  

  pixmap = new_pixmap("bar2.xpm", mainWindow.window->window,
                      &mainWindow.window->style->bg[GTK_STATE_NORMAL]);  
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), pixmap, 0, 0);
  gtk_widget_show(pixmap);    
  
  pixmap = new_pixmap("bar3.xpm", mainWindow.window->window,
                      &mainWindow.window->style->bg[GTK_STATE_NORMAL]);
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), pixmap, 0, 28);
  gtk_widget_show(pixmap);    
  
  pixmap = new_pixmap("bar4.xpm", mainWindow.window->window,
                      &mainWindow.window->style->bg[GTK_STATE_NORMAL]);
  gtk_fixed_put(GTK_FIXED(mainWindow.fixed), pixmap, 150, 0); 
  gtk_widget_show(pixmap);
  
  mainWindow.icon_pos = g_new(CursorOffset, 1);
  gtk_object_set_user_data(GTK_OBJECT(mainWindow.eventBox), 
                           mainWindow.icon_pos);                           

  songTitleEventBox = gtk_event_box_new();
  gtk_fixed_put(GTK_FIXED(fixed), songTitleEventBox, 0, 1);
  gtk_widget_set_usize(songTitleEventBox, 104, 15);
  gtk_widget_set_style(songTitleEventBox, style);
  gtk_widget_show(songTitleEventBox);

  eventBox = gtk_event_box_new();
  gtk_fixed_put(GTK_FIXED(fixed), eventBox, 105, 1);
  gtk_widget_set_usize(eventBox, 35, 15);
  gtk_widget_set_style(eventBox, style);
  gtk_widget_show(eventBox);

  mainWindow.timeLabel = gtk_label_new("0:00");
  
  font = gdk_font_load("-*-helvetica-medium-r-normal-*-*-120-*-*-*-*-*-*");
  style = gtk_style_new();  
  style->fg[GTK_STATE_NORMAL].red = 0;
  style->fg[GTK_STATE_NORMAL].green = 65535;
  style->fg[GTK_STATE_NORMAL].blue = 0;   
  style->font = font;
  
  gtk_widget_set_style(mainWindow.timeLabel, style);
  
  gtk_container_add(GTK_CONTAINER(eventBox), mainWindow.timeLabel);
  gtk_widget_show(mainWindow.timeLabel);
    
  font = gdk_font_load("-*-helvetica-medium-r-normal-*-*-80-*-*-*-*-*-*");
  style = gtk_style_new();  
  style->fg[GTK_STATE_NORMAL].red = 0;
  style->fg[GTK_STATE_NORMAL].green = 65535;
  style->fg[GTK_STATE_NORMAL].blue = 0;   
  style->font = font;

  mainWindow.repeatLabel = gtk_label_new("");
  gtk_widget_set_style(mainWindow.repeatLabel, style);
  gtk_fixed_put(GTK_FIXED(fixed), mainWindow.repeatLabel, 0, 14);
  
  mainWindow.shuffleLabel = gtk_label_new("Shuffle");
  gtk_widget_set_style(mainWindow.shuffleLabel, style);
  gtk_fixed_put(GTK_FIXED(fixed), mainWindow.shuffleLabel, 109, 14);
  
  mainWindow.pausedLabel = gtk_label_new("Paused");
  gtk_widget_set_style(mainWindow.pausedLabel, style);
  gtk_fixed_put(GTK_FIXED(fixed), mainWindow.pausedLabel, 60, 14);
  
  mainWindow.songTitleLabel = gtk_label_new("");
  gtk_misc_set_alignment(GTK_MISC(mainWindow.songTitleLabel), 0.0, 0.5);  
  gtk_widget_set_style(mainWindow.songTitleLabel, style);
  gtk_container_add(GTK_CONTAINER(songTitleEventBox), mainWindow.songTitleLabel);
  gtk_widget_show(mainWindow.songTitleLabel);
  
  gtk_widget_show(fixed);
  
  insertButtonBar(); 
}

void resizeMainWindow(GtkWidget *widget, gpointer *data)
{        
  if (smallSize == 1)    
    createBigWindow();
  else
    createSmallWindow();      
}

int main(int argc, char *argv[])
{
  installSigHandler();
  gtk_init(&argc, &argv);
  root_win = gdk_window_foreign_new(GDK_ROOT_WINDOW());    

  g_print("GMP3 Version %s\n", VERSION);   
  initializeMixer();
  initializePlaylist();  
  initializeAlbumnList(TRUE);

  loadRCFile();
  
  loadCommandlineFiles(argc, argv);
    
  createMainWindow();
  loadDecorations(); 
  createBigWindow();
  mainMenu = createMenu();

  gtk_timeout_add(1000, (GtkFunction) adjustTimer, NULL);
  adjustTimer();
  
  gtk_timeout_add(100, (GtkFunction) playLoop, NULL);

  gtk_main();  
  destroyPlaylist();
  destroyAlbumnList();
  closeMixer();
  
  return 0;
}
