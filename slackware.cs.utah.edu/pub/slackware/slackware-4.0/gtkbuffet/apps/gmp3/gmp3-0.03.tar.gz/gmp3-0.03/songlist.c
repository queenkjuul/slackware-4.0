/* GMP3 - A front end for mpg123
 * Copyright (C) 1998 Brett Kosinski
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
 
#include <gtk/gtk.h>
#include <glib.h>
#include "playlist.h"
#include "songlist.h"
#include "common.h"

/*********************************/
/* songEntry management routines */
/*********************************/

songEntry *newSong(char *fileName, char *title)
{
  songEntry *newEntry;
  
  newEntry = (songEntry *)malloc(sizeof(songEntry));
  
  newEntry->fileName = (char *)malloc(strlen(fileName)+2);
  strcpy(newEntry->fileName,fileName);
  
  if (title != NULL)
    {
      newEntry->title = (char *)malloc(strlen(title)+2);  
      strcpy(newEntry->title,title);
    }  
  else
    newEntry->title = NULL;  
  
  newEntry->played = FALSE;
  
  return newEntry;
}

/**************************/
/* Generic song list code */
/**************************/

/*
  This function may be a little unclear.  It converts the playList to text
  widgets and places them in the GTK list widget provided.
*/

void constructList(GtkWidget *list, GList *songs)
{
  char *songName;
  GList *tempList = g_list_first(songs)->next;
  GtkWidget *label;
  GtkWidget *listItem;  
  
  while (tempList != NULL)
    {
      if ((((songEntry *)tempList->data)->title == NULL) ||
         (strlen(((songEntry *)tempList->data)->title) <= 0))
        songName = ((songEntry *)tempList->data)->fileName;
      else
        songName = ((songEntry *)tempList->data)->title;              

      listItem = gtk_list_item_new();      
      gtk_widget_show(listItem);                  

      label = gtk_label_new(songName);      
      gtk_misc_set_alignment(GTK_MISC(label), 0.0, 0.5);
      gtk_widget_show(label);
      gtk_container_add(GTK_CONTAINER(listItem), label);
      
      gtk_object_set_data(GTK_OBJECT(listItem), list_item_key, 
                          songName);
                          
      gtk_container_add(GTK_CONTAINER(list), listItem);                          
                                            
      tempList = tempList->next;
    }
}

/*
  This function must be called if any changes are made to the playList when
  the Playlist Editor is open.  This is called by the file picker to make
  changes to the list.
*/  

void updateList(GtkWidget *list, GList *songList)
{
  gtk_list_clear_items(GTK_LIST(list), 0, -1);  
  constructList(list, songList);
}

GList *findInList(GList *list, char *fileName)
{
  GList *tmpList;
  
  tmpList = g_list_first(list)->next;

  if (tmpList == NULL)
    return NULL;
  
  while (tmpList != NULL)
    {    
      if ((((songEntry *)tmpList->data)->title != NULL) &&
          (strcmp(((songEntry *)tmpList->data)->title, fileName) == 0))
        break;
      else if (strcmp(((songEntry *)tmpList->data)->fileName, fileName) == 0)
        break;
     
      tmpList = tmpList->next;
    }
  
  return tmpList;
}

void addToList(GList *list, songEntry *entry)
{
  g_list_append(list, entry);    
}

void removeFromList(GList *list, char *fileName)
{
  GList *tmpList;
  
  tmpList = g_list_first(list)->next;

  if (tmpList == NULL)
    return;
  
  while (tmpList != NULL)
    {    
      if ((((songEntry *)tmpList->data)->title != NULL) &&
          (strcmp(((songEntry *)tmpList->data)->title, fileName) == 0))
        break;
      else if (strcmp(((songEntry *)tmpList->data)->fileName, fileName) == 0)
        break;
     
      tmpList = tmpList->next;
    }
  
  if (currentSong == tmpList)                  /* Condition for playlist */
    currentSong = g_list_first(list);

  g_list_remove(list, tmpList->data);  
}
