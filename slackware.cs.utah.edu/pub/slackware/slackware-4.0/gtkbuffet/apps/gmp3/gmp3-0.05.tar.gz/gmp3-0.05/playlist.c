/* Copyright (C) 1998 Brett Kosinski
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
 
#include <gtk/gtk.h>
#include <string.h>
#include "playlist.h"
#include "songlist.h"
#include "albumnlist.h"
#include "common.h"
#include "fileseldefs.h"
#include "gmp3.h"

const char *playlist_id_string = "*gmp3_playlist*";

GList *playList;         /* Active Playlist */
GList *albumnList;       /* List of Albumns */
GList *currentSong;      /* Current location in active play list */
GList *currentSongList;  /* List of songs in currently selected albumn */
 
GtkWidget *albumnFileSel = NULL;
GtkWidget *playListFileSel = NULL;
GtkWidget *albumnDialog = NULL;
GtkWidget *loadDialog = NULL;
GtkWidget *saveDialog = NULL;
GtkWidget *propertiesDialog = NULL;

typedef struct {  
  GtkWidget *albumnListWid;
  GtkWidget *songListWid;
  GtkWidget *playListWid;
  GtkWidget *editorWindow; 
  GtkWidget *playListMenu;
  GtkWidget *songListMenu;
  GtkWidget *albumnListMenu;
} list_window;

list_window listDialog = { NULL, NULL, NULL, NULL, NULL, NULL, NULL };

void showFileSel(GtkWidget *widget, GtkWidget *fileSel);

/********************************/
/* Playlist management routines */
/********************************/

void initializePlaylist()
{ 
  playList = g_list_alloc();
  currentSong = NULL;
  
  currentSong = playList;  
}

void destroyPlaylist()
{
  g_list_free(playList);    
}

void clearPlayedFlags()
{
  GList *tmpList;
  
  tmpList = g_list_first(playList)->next;
  
  while (tmpList)
    {
      ((songEntry *)tmpList->data)->played = FALSE;
      
      tmpList = tmpList->next;
    }
}

/*******************************/
/* Albumn List Management Code */
/*******************************/

void initializeAlbumnList(int createAssorted)
{
  albumnType *assortedAlbumn;
  char *albumnTitle = (char *)malloc(9);
  
  albumnList = g_list_alloc();
  
  if (createAssorted)
    {
      strcpy(albumnTitle, "Assorted");
      assortedAlbumn = newAlbumn(albumnTitle); 
      currentSongList = assortedAlbumn->songList;    
  
      addToAlbumnList(albumnList, assortedAlbumn);
    }
  else
    currentSongList = NULL;    
}

void destroySongList(GList *list, gpointer *data)
{
  g_list_free(list);
}

void destroyAlbumnList()
{
  g_list_foreach(albumnList, (GFunc) destroySongList, NULL);  
  g_list_free(albumnList);  
  
  currentSongList = NULL;
}

/******************************/
/* Albumn File Load/Save Code */
/******************************/

void saveLists(char *fileName)
{
  GList *currentAlbumnNode;
  GList *currentListPos;
  albumnType *currentAlbumn;
  FILE *outputFile;
  
  outputFile = fopen(fileName, "w");

  if (! outputFile)
    return;

  currentAlbumnNode = g_list_first(albumnList)->next;
  
  if (currentAlbumnNode == NULL)
    return;
    
  fprintf(outputFile, "%s\n", playlist_id_string);    
    
  while (currentAlbumnNode)
    {
      currentAlbumn = currentAlbumnNode->data;
      currentListPos = currentAlbumn->songList;
      fprintf(outputFile, "\\%s\n", currentAlbumn->albumnName);
      
      currentListPos = currentListPos->next;      
      while (currentListPos)
        {
          fprintf(outputFile, "%s", 
                  ((songEntry *)(currentListPos->data))->fileName);
          if (((songEntry *)(currentListPos->data))->title != NULL)
            fprintf(outputFile, " %s\n", ((songEntry *)(currentListPos->data))->title);
          else
            fprintf(outputFile, "\n");  
                    
          currentListPos = currentListPos->next;          
        }
        
      currentAlbumnNode = currentAlbumnNode->next;
    }  
    
  fclose(outputFile);  
}

void loadLists(char *fileName)
{
  FILE *inputFile;
  char name[255];
  char title[255];
  char tempbuffer[255];
  char buffer;
  albumnType *currentAlbumn = NULL;
  songEntry *currentSong = NULL;
  
  inputFile = fopen(fileName, "r");
  
  if (! inputFile)
    return;
  
  fgets(tempbuffer, 255, inputFile);
  if (strlen(tempbuffer) > 0)
    tempbuffer[strlen(tempbuffer)-1] = '\0';
    
  if (strcmp(tempbuffer, playlist_id_string))
    return;
  
  if (inputFile)
    {
      destroyPlaylist();
      initializePlaylist();
      
      destroyAlbumnList();
      initializeAlbumnList(FALSE);
      
      while (! feof(inputFile))
        {
          buffer = fgetc(inputFile);          
          
          if (buffer == '\\')
            {
              fgets(name, 255, inputFile);
              if (strlen(name) > 0)
                name[strlen(name)-1] = '\0';
              
              currentAlbumn = newAlbumn(name);
              addToAlbumnList(albumnList, currentAlbumn);
              
              if (currentSongList == NULL)
                currentSongList = currentAlbumn->songList;
            }
          else if (currentAlbumn != NULL)
            {                
              ungetc(buffer, inputFile);
              fscanf(inputFile, "%s", name);
              
              if (feof(inputFile))
                continue;
              
              fgets(title, 255, inputFile);              
              if (strlen(title) > 0)
                title[strlen(title)-1] = '\0';
                
              if (strlen(title) > 0)              
                currentSong = newSong(name, &title[1]);
              else
                currentSong = newSong(name, NULL);
                  
              addToList(currentAlbumn->songList, currentSong);
            }  
        }
    }
}

/**************************/
/* Code to pop up a menu. */
/**************************/

static gint popupMenu(GtkWidget *widget, GdkEventButton *event, GtkWidget **menu)
{
  if (event->button == 3)
    {
      gtk_menu_popup(GTK_MENU(*menu), NULL, NULL, NULL, NULL,
                     3, event->time);
                     
      return TRUE;
    }
    
  return TRUE;
}

/*******************/
/* Signal Handlers */
/*******************/

/* Generic code for grabbing a song from a list and adding it to
   a playlist. */

void addSongToList(char *fileName, GList *list)
{
  char *newFileName;
  char *title;
  int startPos = 0, strPos = 0, offset = 0;  
  songEntry *entry;  
  
  newFileName = (char *)malloc(strlen(fileName)+1);
  strcpy(newFileName, fileName);

  if (options.autoparse)
    {  
      for (startPos = 0; newFileName[startPos] != '\0'; startPos++)
       if (newFileName[startPos] == '/') offset = startPos;      
  
      for (startPos = offset; (newFileName[startPos] != '\0') && 
                              (newFileName[startPos] != '-'); startPos++);

      if (newFileName[startPos] != '\0')
        {
          startPos++;          
          title = (char *)malloc(strlen(newFileName)-startPos+1);
      
          for (strPos = 0; (strPos <= strlen(newFileName)-startPos); strPos++)
            {
              title[strPos] = newFileName[strPos+startPos];
              if (title[strPos] == '_') title[strPos] = ' ';
            }  
        }
      else
        {      
          title = (char *)malloc(strlen(newFileName)+1);
          strcpy(title, newFileName);
      
          for (strPos = 0; strPos < strlen(title); strPos++)
            if (title[strPos] == '_') title[strPos] = ' ';
        }

/* This is a rather memory inefficient way to strip off the extension from the
   title, but it works, and you only lose about 4 bytes per string. */
    
      for (strPos = 0; (title[strPos] != '.') && (title[strPos] != '\0'); strPos++);     
      title[strPos] = '\0';  
    }
  else
    {
      title = (char *)malloc(strlen(newFileName) + 1);
      strcpy(title, newFileName);
    }   
  
  entry = newSong(newFileName, title);  
  addToList(list, entry);    
}

/* Playlist Signals */

void deleteFromPlayListHandler(GtkWidget *widget, GtkWidget *list)
{
  GList *tmpList = GTK_LIST(list)->selection;  
  GtkObject *listItem;
  char *fileName;
  
  if (tmpList == NULL)
    return;

  while (tmpList)
    {
      listItem = GTK_OBJECT(tmpList->data);  
      fileName = gtk_object_get_data(listItem, list_item_key);     
      removeFromList(playList, fileName);
      
      tmpList = tmpList->next;
    }
  
  updateList(list, playList);
}

void addDirToPlayListHandler(GtkWidget *widget, GtkWidget *filesel)
{
  char *data;
  char *fullFileName;
  GtkWidget *list;
  
  CompletionState *cmpl_state;
  int rowNum = 0;
  int totalLen = 0;

  cmpl_state = GTK_FILE_SELECTION(filesel)->cmpl_state;
  list = GTK_FILE_SELECTION(filesel)->file_list;  
  
  do
    {
      data = gtk_clist_get_row_data(GTK_CLIST(list), rowNum);
      rowNum++;
      if (data != NULL)
        {
          totalLen = strlen(data);
          totalLen = totalLen + strlen(cmpl_state->reference_dir->fullname);

          fullFileName = (char *)malloc(totalLen+1);
          fullFileName[0] = '\0';
      
          strcpy(fullFileName, cmpl_state->reference_dir->fullname);
          strcat(fullFileName, "/");
          strcat(fullFileName, data);
      
          addSongToList(fullFileName, playList);
        }  
    }  
  while (data != NULL);  
}

void addToPlayListHandler(GtkWidget *widget, GtkWidget *list)
{
  char *fileName;
  
  fileName = gtk_file_selection_get_filename(GTK_FILE_SELECTION(playListFileSel));
  addSongToList(fileName, playList);
}

void updatePlayListHandler(GtkWidget *widget, GtkWidget *list)
{
  updateList(list, playList);
}

/* Song List Signals */

void deleteFromSongListHandler(GtkWidget *widget, GtkWidget *list)
{
  GList *tmpList = GTK_LIST(list)->selection;  
  GtkObject *listItem;
  char *fileName;
  
  if (tmpList == NULL)
    return;

  while (tmpList)
    {
      listItem = GTK_OBJECT(tmpList->data);  
      fileName = gtk_object_get_data(listItem, list_item_key);     
      removeFromList(currentSongList, fileName);
      
      tmpList = tmpList->next;
    }
  
  updateList(list, currentSongList);
}

void updateSongListHandler(GtkWidget *widget, GtkWidget *list)
{
  updateList(list, currentSongList);
}

void addToSongListHandler(GtkWidget *widget, GtkWidget *list)
{
  char *fileName;
  
  if (g_list_length(albumnList) < 2)
    return;

  fileName = gtk_file_selection_get_filename(GTK_FILE_SELECTION(albumnFileSel));
  
  addSongToList(fileName, currentSongList);  
}

void addDirToSongListHandler(GtkWidget *widget, GtkWidget *filesel)
{
  char *data;
  char *fullFileName;
  GtkWidget *list;
  
  CompletionState *cmpl_state;
  int rowNum = 0;
  int totalLen = 0;

  cmpl_state = GTK_FILE_SELECTION(filesel)->cmpl_state;
  list = GTK_FILE_SELECTION(filesel)->file_list;  
  
  do
    {
      data = gtk_clist_get_row_data(GTK_CLIST(list), rowNum);
      rowNum++;
      if (data != NULL)
        {
          totalLen = strlen(data);
          totalLen = totalLen + strlen(cmpl_state->reference_dir->fullname);

          fullFileName = (char *)malloc(totalLen+1);
          fullFileName[0] = '\0';
      
          strcpy(fullFileName, cmpl_state->reference_dir->fullname);
          strcat(fullFileName, "/");
          strcat(fullFileName, data);
      
          addSongToList(fullFileName, currentSongList);
        }  
    }  
  while (data != NULL);  
  
}

void copyToPlayList(GtkWidget *widget, GtkWidget *list)
{
  GList *tmpList = g_list_last(GTK_LIST(list)->selection);
  GtkObject *listItem;
  char *fileName;
  GList *wantedNode;
  songEntry *entry;
  int listCount = 0;
   
  if (tmpList == NULL)
    return;

  while (tmpList)
    {
      listItem = GTK_OBJECT(tmpList->data);  
      fileName = gtk_object_get_data(listItem, list_item_key);     
      wantedNode = findInList(currentSongList, fileName);
      
      if (wantedNode == NULL)
        return;
      
      entry = newSong(((songEntry *)wantedNode->data)->fileName,
                      ((songEntry *)wantedNode->data)->title);
      entry->played = FALSE;                                                 
      addToList(playList, entry);

      tmpList = tmpList->prev;
      listCount++;
    }
    
  tmpList = g_list_first(GTK_LIST(list)->selection);
  
  while (tmpList->next)
    {
      tmpList = tmpList->next;
      gtk_list_unselect_child(GTK_LIST(list), tmpList->prev->data);
    }
    
  gtk_list_unselect_child(GTK_LIST(list), tmpList->data);  
}

/* AlbumnList Signals */

void deleteFromAlbumnListHandler(GtkWidget *widget, GtkWidget *list)
{
  GList *tmpList = GTK_LIST(list)->selection;  
  GtkObject *listItem;
  char *albumnName;
  
  if (tmpList == NULL)
    return;

  while (tmpList)
    {
      listItem = GTK_OBJECT(tmpList->data);  
      albumnName = gtk_object_get_data(listItem, list_item_key);     
      removeFromList(albumnList, albumnName);
      
      tmpList = tmpList->next;
    }
  
  updateAlbumnList(list, albumnList);
}

void addToAlbumnListHandler(GtkWidget *widget, GtkWidget *entry)
{
  char *albumnName;
  char *newAlbumnName;
  albumnType *albumn;
  
  albumnName = gtk_entry_get_text(GTK_ENTRY(entry));
  newAlbumnName = (char *)malloc(strlen(albumnName)+1);
  strcpy(newAlbumnName, albumnName);
  
  if (newAlbumnName[0] == '\0')
    return;
  
  albumn = newAlbumn(newAlbumnName);  
  addToAlbumnList(albumnList, albumn);    
}

void updateAlbumnListHandler(GtkWidget *widget, GtkWidget *list)
{
  updateAlbumnList(list, albumnList);
}

void changeAlbumnHandler(GtkWidget *widget, list_window *window)
{
  GList *tmpList;
  GList *chosenSongList;
  char *albumnName;  
  GtkObject *listItem;
  
  tmpList = GTK_LIST(window->albumnListWid)->selection;
  
  if (tmpList != NULL)
    {  
      listItem = GTK_OBJECT(tmpList->data);
  
      albumnName = gtk_object_get_data(listItem, list_item_key);
      chosenSongList = findInAlbumnList(albumnList, albumnName);      
  
      if ((chosenSongList != NULL) && (chosenSongList != currentSongList))
        {
          currentSongList = chosenSongList;                  
          currentSong = playList;
          updateSongListHandler(NULL, window->songListWid);              
        }  
    }    
}

void copyWholeAlbumnHandler(GtkWidget *widget, GtkWidget *playListWid)
{
  GList *songListPtr;
  songEntry *currentSongEntry;
  songEntry *newSongEntry;

  songListPtr = g_list_first(currentSongList)->next;  

  if (songListPtr == NULL)
    return;
    
  while (songListPtr)
    {
      currentSongEntry = songListPtr->data;
      
      newSongEntry = newSong(currentSongEntry->fileName, 
                             currentSongEntry->title);
      addToList(playList, newSongEntry);      
      
      songListPtr = songListPtr->next;
    }
    
  updatePlayListHandler(NULL, playListWid);
}

/**********************/
/* Common Dialog Code */
/**********************/

void destroyDialog(GtkWidget *widget, GtkWidget **dialog)
{
  if ((*dialog) && (GTK_WIDGET_VISIBLE(*dialog)))
    gtk_widget_hide(*dialog);
}

void showDialog(GtkWidget *widget, GtkWidget **dialog)
{
  if ((*dialog) && (! GTK_WIDGET_VISIBLE(*dialog)))
    gtk_widget_show(*dialog);
}

/**************************/
/* Song Properties Dialog */
/**************************/

void changeSongName(GtkWidget *entry, GList *selection)
{
  char *newTitle;

  if (! GTK_WIDGET_VISIBLE(listDialog.editorWindow))
    return;

  if (selection == NULL)
    return;
  
  newTitle = gtk_entry_get_text(GTK_ENTRY(entry));
  
  if ((newTitle == NULL) || (strlen(newTitle) <= 0))
    return;

  if (((songEntry *)(selection->data))->title != NULL)
    free(((songEntry *)(selection->data))->title);
    
  ((songEntry *)(selection->data))->title = (char *)malloc(strlen(newTitle)+2);
  strcpy(((songEntry *)(selection->data))->title, newTitle);    
}

void destroySongPropertiesDialog(GtkWidget *widget, gpointer *data)
{  
  if (propertiesDialog)
    {
      gtk_widget_destroy(propertiesDialog);
      propertiesDialog = NULL;
    }
}

void createSongPropertiesDialog(GtkWidget *song, GtkWidget *listWid)
{
  GtkWidget *entry;
  GtkWidget *button;
  GtkWidget *vbox;   
  GtkWidget *hbox;
  GtkWidget *label;
  GtkObject *listItem;
  GList *tmpList = GTK_LIST(listWid)->selection;    
  char *selectedName;
  GList *selectedSong;
  
  if (propertiesDialog)
    return;
  
  if (tmpList == NULL)
    return;
    
  listItem = tmpList->data;
  
  selectedName = gtk_object_get_data(listItem, list_item_key);
  selectedSong = findInList(currentSongList, selectedName);
  
  if (selectedSong == NULL)
    return;
  
  propertiesDialog = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(propertiesDialog), "Song Properties");
        
  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(propertiesDialog), vbox);
  gtk_widget_show(vbox);
        
  hbox = gtk_hbox_new(FALSE, 5);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);
  
  label = gtk_label_new("Song Name:");
  gtk_widget_show(label);
  gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);

  entry = gtk_entry_new();
  if (((songEntry *)(selectedSong->data))->title != NULL)
    gtk_entry_set_text(GTK_ENTRY(entry), ((songEntry *)(selectedSong->data))->title);
    
  gtk_box_pack_start(GTK_BOX(hbox), entry, FALSE, FALSE, 0);
  gtk_widget_show(entry);
  gtk_signal_connect(GTK_OBJECT(entry), "destroy",
                     GTK_SIGNAL_FUNC(changeSongName), selectedSong);
                     
  button = gtk_button_new_with_label("Okay");
  gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);
  gtk_widget_show(button);
  
/* I make sure the entry is destroyed first, to make sure the name is changed.
   Then, update is called.  This ensures the order is correct. */  
  
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
                             GTK_SIGNAL_FUNC(gtk_widget_destroy),
                             GTK_OBJECT(entry));
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(updateSongListHandler), listWid);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(destroySongPropertiesDialog), 
                     NULL);
                     
  gtk_signal_connect(GTK_OBJECT(propertiesDialog), "delete_event",
                     GTK_SIGNAL_FUNC(gtk_true), NULL);                     
                     
  gtk_widget_show(propertiesDialog);                     
}

/*************************/
/* File Save Dialog Code */
/*************************/

void saveDialogOkayHandler(GtkWidget *widget, GtkWidget *fileSel)
{
  char *fileName;
  
  fileName = gtk_file_selection_get_filename(GTK_FILE_SELECTION(fileSel));  
  
  if (fileName != NULL)
    saveLists(fileName);
}

void createSaveDialog(GtkWidget *widget, gpointer *data)
{
  if (! saveDialog)
    {
      saveDialog = gtk_file_selection_new("Select Playlist");
      gtk_widget_destroy(GTK_FILE_SELECTION(saveDialog)->help_button);
      
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(saveDialog)->ok_button),
                         "clicked", GTK_SIGNAL_FUNC(saveDialogOkayHandler),
                         saveDialog);
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(saveDialog)->ok_button),
                         "clicked", GTK_SIGNAL_FUNC(destroyDialog),
                         &saveDialog);                         
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(saveDialog)->cancel_button),
                         "clicked", GTK_SIGNAL_FUNC(destroyDialog),
                         &saveDialog);
      gtk_signal_connect(GTK_OBJECT(saveDialog), "delete_event",
                         GTK_SIGNAL_FUNC(destroyDialog),
                         &saveDialog);                         
      gtk_widget_show(saveDialog);
    }
  else
    {
      if (GTK_WIDGET_VISIBLE(saveDialog))
        return;
      else
        gtk_widget_show(saveDialog);  
    }  
}

/*************************/
/* File Load Dialog Code */
/*************************/

void loadDialogOkayHandler(GtkWidget *widget, GtkWidget *fileSel)
{
  char *fileName;
  
  fileName = gtk_file_selection_get_filename(GTK_FILE_SELECTION(fileSel));
  
  if (fileName != NULL)
    loadLists(fileName);
}

void createLoadDialog(GtkWidget *widget, list_window *listDialog)
{
  if (! loadDialog)
    {
      loadDialog = gtk_file_selection_new("Select Playlist");
      
      gtk_widget_destroy(GTK_FILE_SELECTION(loadDialog)->help_button);
      
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(loadDialog)->ok_button),
                         "clicked", GTK_SIGNAL_FUNC(loadDialogOkayHandler),
                         loadDialog);
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(loadDialog)->ok_button),
                         "clicked", GTK_SIGNAL_FUNC(updatePlayListHandler),
                         listDialog->playListWid);
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(loadDialog)->ok_button),
                         "clicked", GTK_SIGNAL_FUNC(updateSongListHandler),
                         listDialog->songListWid);
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(loadDialog)->ok_button),
                         "clicked", GTK_SIGNAL_FUNC(updateAlbumnListHandler),
                         listDialog->albumnListWid);      
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(loadDialog)->ok_button),
                         "clicked", GTK_SIGNAL_FUNC(destroyDialog),
                         &loadDialog);
                                                        
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(loadDialog)->cancel_button),
                         "clicked", GTK_SIGNAL_FUNC(destroyDialog),
                         &loadDialog);
      gtk_signal_connect(GTK_OBJECT(loadDialog), "delete_event",
                         GTK_SIGNAL_FUNC(destroyDialog), &loadDialog);                         
      gtk_widget_show(loadDialog);
    }
  else
    {
      if (GTK_WIDGET_VISIBLE(loadDialog))
        return;
      else
        gtk_widget_show(loadDialog);  
    }  
}

/**********************/
/* File Selector Code */
/**********************/

void createFileDialog(GtkWidget **fileSel, GtkWidget *list, GList *songList,
                      char *title, 
                      GtkSignalFunc addFunc, 
                      GtkSignalFunc addDirFunc,
                      GtkSignalFunc updateFunc)
{
  GtkWidget *button;
  GtkWidget *hbox;
  GtkWidget *dirButton;
  
  if (! *fileSel)
    {
      *fileSel = gtk_file_selection_new(title);
  
      gtk_widget_destroy(GTK_FILE_SELECTION(*fileSel)->ok_button);
      gtk_widget_destroy(GTK_FILE_SELECTION(*fileSel)->cancel_button);

      hbox = gtk_hbox_new(FALSE, 5);
      gtk_widget_show(hbox);
      gtk_box_pack_end(GTK_BOX(GTK_FILE_SELECTION(*fileSel)->main_vbox),
                       hbox, TRUE, TRUE, 0);                             
                       
      button = gtk_button_new_with_label("Add Songs");      
      gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
      GTK_FILE_SELECTION(*fileSel)->ok_button = button;
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
      gtk_widget_grab_default(button);
      gtk_widget_show(button);

      dirButton = gtk_button_new_with_label("Add Dir");      
      gtk_box_pack_start(GTK_BOX(hbox), dirButton, TRUE, TRUE, 0);
      GTK_WIDGET_SET_FLAGS(dirButton, GTK_CAN_DEFAULT);     
      gtk_widget_show(dirButton);
      
      button = gtk_button_new_with_label("Close");      
      gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, TRUE, 0);
      GTK_FILE_SELECTION(*fileSel)->cancel_button = button;
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);     
      gtk_widget_show(button);
      
//      gtk_clist_set_selection_mode(GTK_CLIST(GTK_FILE_SELECTION(fileSel)->file_list),
//                                   GTK_SELECTION_MULTIPLE);

      gtk_signal_connect(GTK_OBJECT(*fileSel), "destroy",
                         GTK_SIGNAL_FUNC(destroyDialog), fileSel);
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(*fileSel)->cancel_button),
                         "clicked", GTK_SIGNAL_FUNC(destroyDialog), fileSel);
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(*fileSel)->ok_button),
                         "clicked", addFunc, list);
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(*fileSel)->ok_button),
                         "clicked", updateFunc, list);
      gtk_signal_connect(GTK_OBJECT(dirButton), "clicked", addDirFunc, 
                         *fileSel);
      gtk_signal_connect(GTK_OBJECT(dirButton), "clicked", updateFunc, list);
      gtk_signal_connect(GTK_OBJECT(*fileSel), "delete_event",
                         GTK_SIGNAL_FUNC(destroyDialog), fileSel);
    }          
}

/*********************************************/
/* Code to add an albumn to the albumn list. */
/*********************************************/

void createAlbumnDialog(GtkWidget *widget, GtkWidget *list)
{
  GtkWidget *entry;
  GtkWidget *button;
  GtkWidget *vbox;
  GtkWidget *hbox;
  GtkWidget *label;  
  
  if (! albumnDialog)
    {
      albumnDialog = gtk_window_new(GTK_WINDOW_TOPLEVEL);
      gtk_window_set_title(GTK_WINDOW(albumnDialog), "Enter Albumn Name");
            
      vbox = gtk_vbox_new(FALSE, 5);
      gtk_container_border_width(GTK_CONTAINER(vbox), 5);
      gtk_container_add(GTK_CONTAINER(albumnDialog), vbox);                 
      gtk_widget_show(vbox);

      hbox = gtk_hbox_new(FALSE, 5);
      gtk_container_border_width(GTK_CONTAINER(vbox), 5);
      gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
      gtk_widget_show(hbox);
      
      label = gtk_label_new("Albumn Title:");
      gtk_widget_show(label);
      gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
            
      entry = gtk_entry_new();
      gtk_widget_show(entry);
      gtk_box_pack_start(GTK_BOX(hbox), entry, FALSE, FALSE, 0);      
      
      button = gtk_button_new_with_label("Okay");
      gtk_widget_show(button);
      gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(addToAlbumnListHandler), entry);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(updateAlbumnListHandler), list);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(destroyDialog), &albumnDialog);
      gtk_signal_connect(GTK_OBJECT(albumnDialog), "delete_event", 
                         GTK_SIGNAL_FUNC(gtk_true), NULL);

      gtk_widget_show(albumnDialog);
    }
  else
    {
      if (GTK_WIDGET_VISIBLE(albumnDialog))
        return;
      else
        gtk_widget_show(albumnDialog);
    }
}

/*************/
/* Menu Code */
/*************/

void createAlbumnListMenu(GtkWidget *list, GtkWidget **albumnListMenu,
                          GtkWidget *playListWid)
{  
  GtkWidget *menuItem;

  if (*albumnListMenu != NULL)
    return;

  *albumnListMenu = gtk_menu_new();
  
  gtk_widget_realize(*albumnListMenu);
  gdk_window_set_cursor((*albumnListMenu)->window, gdk_cursor_new(GDK_LEFT_PTR));

  menuItem = gtk_menu_item_new_with_label("Add to Playlist");
  gtk_menu_append(GTK_MENU(*albumnListMenu), menuItem);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(copyWholeAlbumnHandler), playListWid);
  gtk_widget_show(menuItem);                     

  menuItem = gtk_menu_item_new_with_label("Create Albumn...");
  gtk_menu_append(GTK_MENU(*albumnListMenu), menuItem);
  gtk_widget_show(menuItem);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(createAlbumnDialog), list); 
  
  menuItem = gtk_menu_item_new_with_label("Delete Albumn");
  gtk_menu_append(GTK_MENU(*albumnListMenu), menuItem);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(deleteFromAlbumnListHandler), list);
                     
  gtk_widget_show(menuItem);  
}

void createSongListMenu(GtkWidget *list, GtkWidget *playListWid, 
                        GtkWidget **songListMenu)
{  
  GtkWidget *menuItem;

  if (*songListMenu != NULL)
    return;

  *songListMenu = gtk_menu_new();
  
  gtk_widget_realize(*songListMenu);
  gdk_window_set_cursor((*songListMenu)->window, gdk_cursor_new(GDK_LEFT_PTR));

  menuItem = gtk_menu_item_new_with_label("Add To Playlist");
  gtk_menu_append(GTK_MENU(*songListMenu), menuItem);
  gtk_widget_show(menuItem);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(copyToPlayList), list);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(updatePlayListHandler), playListWid);                     

  menuItem = gtk_menu_item_new_with_label("Add Song(s)...");
  gtk_menu_append(GTK_MENU(*songListMenu), menuItem);
  gtk_widget_show(menuItem);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(showDialog), &albumnFileSel);
  
  menuItem = gtk_menu_item_new_with_label("Delete song(s)");
  gtk_menu_append(GTK_MENU(*songListMenu), menuItem);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(deleteFromSongListHandler), list);
  gtk_widget_show(menuItem);                     
                     
  menuItem = gtk_menu_item_new_with_label("Song Properties...");
  gtk_menu_append(GTK_MENU(*songListMenu), menuItem);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(createSongPropertiesDialog),
                     list);
  gtk_widget_show(menuItem);  
}

void createPlayListMenu(GtkWidget *list, GtkWidget **playListMenu)
{  
  GtkWidget *menuItem;

  if (*playListMenu != NULL)
    return;

  *playListMenu = gtk_menu_new();
  
  gtk_widget_realize(*playListMenu);
  gdk_window_set_cursor((*playListMenu)->window, gdk_cursor_new(GDK_LEFT_PTR));

  menuItem = gtk_menu_item_new_with_label("Add Song(s)...");
  gtk_menu_append(GTK_MENU(*playListMenu), menuItem);
  gtk_widget_show(menuItem);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(showDialog), &playListFileSel);
                     
  gtk_widget_show(menuItem);  
  
  menuItem = gtk_menu_item_new_with_label("Remove song(s)");
  gtk_menu_append(GTK_MENU(*playListMenu), menuItem);
  gtk_signal_connect(GTK_OBJECT(menuItem), "activate",
                     GTK_SIGNAL_FUNC(deleteFromPlayListHandler), list);
  gtk_widget_show(menuItem);                     
}

/*******************************/
/* New GtkList Signal Handlers */
/*******************************/

static gint
my_gtk_list_button_press (GtkWidget *widget,
                          GdkEventButton *event)
{
  GtkList *list;
  GtkWidget *item;
  
  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (GTK_IS_LIST (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);
  
  list = GTK_LIST (widget);
  item = gtk_get_event_widget ((GdkEvent *) event);
  
  if (!item)
    return FALSE;
    
  while (!gtk_type_is_a (GTK_WIDGET_TYPE(item), gtk_list_item_get_type()))
    item = item->parent;
    
  if (event->button == 1)
    gtk_list_select_child (list, item);
  
  return FALSE;
}

static gint
my_gtk_list_button_release (GtkWidget *widget,
                            GdkEventButton *event)
{
  GtkList *list;
  GtkWidget *item;
  
  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (GTK_IS_LIST (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);
  
  list = GTK_LIST (widget);
  item = gtk_get_event_widget ((GdkEvent *) event);
  
  return FALSE;
}                            

/************************/
/* Playlist Dialog Code */
/************************/

void createListDialog()
{
  GtkWidget *scrolledWindow;
  GtkWidget *button;
  GtkWidget *vbox;  
  GtkWidget *hbox;
  GtkWidget *eventBox;   
  GtkWidgetClass *class;
    
  if (! listDialog.editorWindow)
    {
      listDialog.editorWindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
      gtk_window_set_title(GTK_WINDOW(listDialog.editorWindow), "Playlist Editor");        
      gtk_signal_connect_object(GTK_OBJECT(listDialog.editorWindow), "delete_event",
                                GTK_SIGNAL_FUNC(gtk_widget_hide),
                                GTK_OBJECT(listDialog.editorWindow));
                     
      vbox = gtk_vbox_new(FALSE, 5);
      gtk_container_border_width(GTK_CONTAINER(vbox), 5);
      gtk_container_add(GTK_CONTAINER(listDialog.editorWindow), vbox);
      gtk_widget_show(vbox);
      
      hbox = gtk_hbox_new(FALSE, 5);
      gtk_container_border_width(GTK_CONTAINER(hbox), 5);
      gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 0);
      gtk_widget_show(hbox);

/* Contruct playList */
                    
      scrolledWindow = gtk_scrolled_window_new(NULL, NULL);
      gtk_widget_set_usize(scrolledWindow, 250, 150);
      gtk_widget_show(scrolledWindow);            
      gtk_box_pack_start(GTK_BOX(vbox), scrolledWindow, TRUE, TRUE, 0);            

      eventBox = gtk_event_box_new();
      gtk_widget_show(eventBox);      
                                                 
      listDialog.playListWid = gtk_list_new();
      gtk_widget_show(listDialog.playListWid);  
      gtk_container_add(GTK_CONTAINER(eventBox), listDialog.playListWid);
      gtk_list_set_selection_mode(GTK_LIST(listDialog.playListWid), 
                                  GTK_SELECTION_MULTIPLE);
      
      createFileDialog(&playListFileSel, listDialog.playListWid, playList,
                       "Add to Play List", 
                       GTK_SIGNAL_FUNC(addToPlayListHandler),
                       GTK_SIGNAL_FUNC(addDirToPlayListHandler),
                       GTK_SIGNAL_FUNC(updatePlayListHandler));
      
      createPlayListMenu(listDialog.playListWid, &listDialog.playListMenu);

      gtk_widget_set_events(eventBox, gtk_widget_get_events(eventBox) |
                            GDK_BUTTON_PRESS_MASK);
      gtk_signal_connect(GTK_OBJECT(eventBox), "button_press_event",
                         GTK_SIGNAL_FUNC(popupMenu), 
                         &listDialog.playListMenu);      
      gtk_container_add(GTK_CONTAINER(scrolledWindow), eventBox);
 
      constructList(listDialog.playListWid, playList);      

/* Construct songList */                          

      scrolledWindow = gtk_scrolled_window_new(NULL, NULL);
      gtk_widget_set_usize(scrolledWindow, 250, 150);
      gtk_widget_show(scrolledWindow);            
      gtk_box_pack_start(GTK_BOX(hbox), scrolledWindow, TRUE, TRUE, 0);            

      eventBox = gtk_event_box_new();
      gtk_widget_show(eventBox);      
      
      listDialog.songListWid = gtk_list_new();
      gtk_widget_show(listDialog.songListWid);  
      gtk_container_add(GTK_CONTAINER(eventBox), listDialog.songListWid);
      gtk_list_set_selection_mode(GTK_LIST(listDialog.songListWid), 
                                  GTK_SELECTION_MULTIPLE);

      createFileDialog(&albumnFileSel, listDialog.songListWid, currentSongList,
                       "Add to Albumn", 
                       GTK_SIGNAL_FUNC(addToSongListHandler),
                       GTK_SIGNAL_FUNC(addDirToSongListHandler),
                       GTK_SIGNAL_FUNC(updateSongListHandler));

      createSongListMenu(listDialog.songListWid, 
                         listDialog.playListWid, 
                        &listDialog.songListMenu);
      
      gtk_widget_set_events(eventBox, gtk_widget_get_events(eventBox) |
                            GDK_BUTTON_PRESS_MASK);
      gtk_signal_connect(GTK_OBJECT(eventBox), "button_press_event",
                         GTK_SIGNAL_FUNC(popupMenu), &listDialog.songListMenu);      
      gtk_container_add(GTK_CONTAINER(scrolledWindow), eventBox); 
      
      constructList(listDialog.songListWid, currentSongList);
      
/* Construct albumnList */
                    
      scrolledWindow = gtk_scrolled_window_new(NULL, NULL);
      gtk_widget_set_usize(scrolledWindow, 250, 150);
      gtk_widget_show(scrolledWindow);            
      gtk_box_pack_start(GTK_BOX(hbox), scrolledWindow, TRUE, TRUE, 0);            
      gtk_box_reorder_child(GTK_BOX(hbox), scrolledWindow, 0);      

      eventBox = gtk_event_box_new();
      gtk_widget_show(eventBox);      
                                                  
      listDialog.albumnListWid = gtk_list_new();
      gtk_widget_show(listDialog.albumnListWid);  
      gtk_container_add(GTK_CONTAINER(eventBox), listDialog.albumnListWid);
      gtk_signal_connect(GTK_OBJECT(listDialog.albumnListWid), 
                         "selection_changed",
                         GTK_SIGNAL_FUNC(changeAlbumnHandler), 
                         &listDialog);
      createAlbumnListMenu(listDialog.albumnListWid, &listDialog.albumnListMenu,
                           listDialog.playListWid);
      
      gtk_widget_set_events(eventBox, gtk_widget_get_events(eventBox) |
                            GDK_BUTTON_PRESS_MASK);
      gtk_signal_connect(GTK_OBJECT(eventBox), "button_press_event",
                         GTK_SIGNAL_FUNC(popupMenu), 
                         &listDialog.albumnListMenu);
      gtk_container_add(GTK_CONTAINER(scrolledWindow), eventBox); 
      
      constructAlbumnList(listDialog.albumnListWid, albumnList);      
            
/* Create Button */      
      
      hbox = gtk_hbox_new(FALSE, 5);
      gtk_container_border_width(GTK_CONTAINER(hbox), 5);      
      gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 0);
      gtk_widget_show(hbox);            
      
      button = gtk_button_new_with_label("Close");
      gtk_widget_show(button);
      gtk_box_pack_end(GTK_BOX(hbox), button, TRUE, TRUE, 0);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(destroyDialog),
                         &(listDialog.editorWindow));
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(destroyDialog),
                         &albumnFileSel);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(destroyDialog),
                         &playListFileSel);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(destroyDialog),
                         &albumnDialog);                         
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(destroyDialog),
                         &saveDialog);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(destroyDialog),                         
                         &loadDialog);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(destroySongPropertiesDialog),
                         NULL);                                
                         
      button = gtk_button_new_with_label("Save");
      gtk_widget_show(button);
      gtk_box_pack_end(GTK_BOX(hbox), button, TRUE, TRUE, 0);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(createSaveDialog),
                         NULL);
                         
      button = gtk_button_new_with_label("Load");
      gtk_widget_show(button);
      gtk_box_pack_end(GTK_BOX(hbox), button, TRUE, TRUE, 0);
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         GTK_SIGNAL_FUNC(createLoadDialog),
                         &listDialog);
 
      class = GTK_WIDGET_CLASS(GTK_OBJECT(listDialog.playListWid)->klass);
      class->button_press_event = my_gtk_list_button_press;
      class->button_release_event = my_gtk_list_button_release;

      gtk_widget_show(listDialog.editorWindow);
    }
  else
    {
      if (GTK_WIDGET_VISIBLE(listDialog.editorWindow))
        return;
      else
        gtk_widget_show(listDialog.editorWindow);  
    }  
}
