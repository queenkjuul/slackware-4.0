#!/bin/bash
#
# Pretty obvious, I think... this script wraps mpg123 so that it can be
# called with Synaesthesia, a neat music visualization program.
#

mpg123 -s $@ | synaesthesia pipe 44100 4
