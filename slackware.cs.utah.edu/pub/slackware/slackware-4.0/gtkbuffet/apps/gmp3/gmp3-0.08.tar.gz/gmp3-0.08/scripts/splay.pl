#!/usr/bin/perl
#
# This is a little wrapper script to allow splay to be used with Gmp3.  This
# could easily be modified to support other players.  As you can see, it's
# quite simple.  Moreover, there is nothing saying you HAVE to wrap an 
# mp3 player... :)
#
# Note, script output is displayed only if Gmp3 has been compiled with 
# debugging on.
#

use Getopt::Long;

print("SPlay wrapper script...\n");

GetOptions qw(-b=i -2 -4 -ol -0 -1 -m -a);
$filename = pop(@ARGV);

$args = "";

# Buffer conversion is a guess... I don't know how it actually should work.

if ($opt_b)
  { $args = $args . "-t " . ($opt_b/10) . " "; }
if ($opt_2)
  { $args = $args . "-2 "; }    
if ($opt_4)                     # Make 1/2 and 1/4 downsample the same
  { $args = $args . "-2 "; }
if ($opt_ol)
  {}                            # No splay equivalent
if ($opt_0)
  { $args = $args . "-m "; }
if ($opt_1)
  { $args = $args . "-m "; }    # Just make -0, -1, and -m play mono
if ($opt_m)
  { $args = $args . "-m "; }
if ($opt_a)
  { $args = $args . "-d " . $opt_a . " "; }

print("Execing... splay $args $filename\n");
system("splay $args $filename\n");
