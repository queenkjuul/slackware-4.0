#!/usr/bin/perl
#
# This script can be used to play mp3's compressed with gzip... note that
# you really don't get much of a space savings here, but it's another
# example of what you can do by using scripts with Gmp3.
#

$filename = pop(@ARGV);
$args = "";

foreach $val (@ARGV)
  { $args = $args . $val . " "; }

system("gunzip -c $filename | mpg123 $args -");
