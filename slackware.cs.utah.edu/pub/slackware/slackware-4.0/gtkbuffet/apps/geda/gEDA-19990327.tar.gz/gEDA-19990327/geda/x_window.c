/* gEDA - GNU Electronic Design Automation
 * gschem - GNU Schematic Capture
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h>
#include <signal.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"

#include "prototype.h"

GtkWidget *xpm_label_box( GtkWidget *parent,
                          gchar     *xpm_filename,
                          gchar     *label_text )
{
    GtkWidget *box1;
    GtkWidget *label;
    GtkWidget *pixmapwid;
    GdkPixmap *pixmap;
    GdkBitmap *mask;
    GtkStyle *style;

    /* Create box for xpm and label */
    box1 = gtk_vbox_new (FALSE, 0); /* was hbox */
#if GTK_DEVEL
    gtk_container_set_border_width (GTK_CONTAINER (box1), 2);
#endif

    /* Get the style of the button to get the
     * background color. */
    style = gtk_widget_get_style(parent);

    /* Now on to the xpm stuff */
    pixmap = gdk_pixmap_create_from_xpm (parent->window, &mask,
					 &style->bg[GTK_STATE_NORMAL],
					 xpm_filename);
    pixmapwid = gtk_pixmap_new (pixmap, mask);

    /* Create a label for the button */
    label = gtk_label_new (label_text);

    /* Pack the pixmap and label into the box */
    gtk_box_pack_start (GTK_BOX (box1),
			pixmapwid, FALSE, FALSE, 3);

    gtk_box_pack_start (GTK_BOX (box1), label, FALSE, FALSE, 3);

    gtk_widget_show(pixmapwid);
    gtk_widget_show(label);

    return(box1);
}

/* stays the same */
void
x_window_create(void)
{
#if GTK_DEVEL
        GtkAccelGroup *accel;
#else
        GtkAcceleratorTable *accel;
#endif
	/* GtkWidget *label;*/
	GtkWidget *main_box;
	GtkWidget *menubar;
	GtkWidget *main_window;

	GtkWidget *button;
	GtkWidget *box1;

	TOOL *t_current;

        main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	
	gtk_widget_set_name (main_window, "gEDA");

	/* 	
         * gtk_widget_set_uposition (main_window, 0, 0);
	 */
	

#if 0
/* for now this is commented out.... */
/* this was causing problems with the multi window stuff */
	gtk_signal_connect (GTK_OBJECT (main_window), "destroy",
                            GTK_SIGNAL_FUNC(i_callback_quit),
                            NULL);
#endif

#if 0
        gtk_signal_connect (GTK_OBJECT (main_window), "delete_event",
                            GTK_SIGNAL_FUNC (i_callback_close),
                            NULL); 
#endif

	/* Containers first */        
        main_box = gtk_vbox_new(FALSE, 1);
        gtk_container_border_width(GTK_CONTAINER(main_box), 0);
        gtk_container_add(GTK_CONTAINER(main_window), main_box);
        gtk_widget_show(main_box);

        get_main_menu(&geda_head, &menubar, &accel);
#if GTK_DEVEL	
        gtk_window_add_accel_group(GTK_WINDOW(main_window), 
					 accel);
#else
        gtk_window_add_accelerator_table(GTK_WINDOW(main_window), 
					 accel);
#endif
        gtk_box_pack_start(GTK_BOX(main_box), menubar, FALSE, FALSE, 0);
        gtk_widget_show(menubar);

	/* now do the individual tools */
	t_current = geda_head.tool_head;
	gtk_widget_realize(main_window);

	while(t_current != NULL) {

		if (t_current->tid != -1) {
			button = gtk_button_new ();

			gtk_signal_connect (GTK_OBJECT (button), "clicked",
                        	GTK_SIGNAL_FUNC (i_callback_launch), t_current);

		        box1 = xpm_label_box(main_window, t_current->icon, t_current->tool);

			gtk_container_add (GTK_CONTAINER (main_box), button);
			gtk_container_add (GTK_CONTAINER (button), box1);

			gtk_widget_show(box1);
        		gtk_widget_show (button);
		}
		t_current = t_current->next;
	}
	
        gtk_widget_show(main_window);
}
