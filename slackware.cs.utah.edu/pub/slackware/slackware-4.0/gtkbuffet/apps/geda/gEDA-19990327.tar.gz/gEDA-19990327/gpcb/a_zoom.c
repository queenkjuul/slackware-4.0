/* gEDA - GNU Electronic Design Automation
 * gschem/gpcb - GNU Schematic Capture and Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#include <config.h>
#include <stdio.h>
#include <math.h>

#include <guile/gh.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"

#include "prototype.h"
#include "../libgeda/prototype.h"


/* dir is either ZOOM_IN or ZOOM_OUT which are defined in globals.h */
void
a_zoom(TOPLEVEL *w_current, int dir)
{
	float i;
	double new_aspect;
	int diff_x, diff_y;
	int zoom_scale;
	

	switch(dir) {
		case(ZOOM_IN):

       			if (w_current->page_current->zoom_factor >= 
			   w_current->max_zoom ) {
				w_current->page_current->zoom_factor = 
					w_current->max_zoom;
				return;
			}

        		i = (w_current->page_current->right - 
				w_current->page_current->left)/4;
        		w_current->page_current->right -= (int) i;
        		w_current->page_current->left += (int) i;
			/* rint is a hack */
        		i = (w_current->page_current->bottom - 
				w_current->page_current->top)/4; 
        		w_current->page_current->bottom -= (int) i;
        		w_current->page_current->top += (int) i;
	
			break;

		case(ZOOM_OUT):


			if (w_current->page_current->zoom_factor <= 1 ) {
				w_current->page_current->zoom_factor = 0;
	
				w_current->page_current->left = 
						w_current->init_left;
				w_current->page_current->top = 
						w_current->init_top;
				w_current->page_current->right = 
						w_current->init_right;
				w_current->page_current->bottom = 
						w_current->init_bottom;
				set_window(w_current, 
					w_current->page_current->left, 
					w_current->page_current->right, 
					w_current->page_current->top, 
					w_current->page_current->bottom);
				return;
			} else {

				i = (w_current->page_current->right - 
				     w_current->page_current->left)/2;
        			w_current->page_current->right = 
					(i + w_current->page_current->right >
					w_current->init_right
		 			? w_current->init_right : 
					i + w_current->page_current->right);
        			w_current->page_current->left = 
					(w_current->page_current->left - 
					i < 0 ? 0 : 
					w_current->page_current->left - i);

        			i = (w_current->page_current->bottom - 
				     	w_current->page_current->top)/2;
        			w_current->page_current->bottom = 
					(i + w_current->page_current->bottom > 
					w_current->init_bottom ? 
					w_current->init_bottom : 
					i + w_current->page_current->bottom);
        			w_current->page_current->top = 
					(w_current->page_current->top - i < 0 
					? 0 : w_current->page_current->top - i);
			}
		break;

		case(ZOOM_FULL):
			w_current->page_current->zoom_factor=0;
			w_current->page_current->left = w_current->init_left;
			w_current->page_current->top = w_current->init_top;
			w_current->page_current->right = 
						w_current->init_right;
			w_current->page_current->bottom = 
						w_current->init_bottom;

#if DEBUG
			printf("Zooming Full\n");
#endif


		break;
	}

#if DEBUG
/*	printf("-------------------\n");
	printf("zoomfactor: %d\n", zoom_factor);
	printf("left: %d, right: %d, top: %d, bottom: %d\n",
				left, right, top, bottom);	 */
#endif


	diff_x = w_current->page_current->right - 
			w_current->page_current->left;		
	diff_y = w_current->page_current->bottom - 
			w_current->page_current->top;		

	new_aspect = (float) fabs(w_current->page_current->right - 
			w_current->page_current->left) / 
		     (float) fabs(w_current->page_current->bottom - 
			w_current->page_current->top);

#if DEBUG
/*	printf("wxh: %d %d\n", diff_x, diff_y);
        printf("diff is: %f\n", fabs(new_aspect - coord_aspectratio));*/
#endif

	/* Make sure aspect ratio is correct */
	if (fabs(new_aspect - w_current->page_current->coord_aspectratio)) {

		if (new_aspect > w_current->page_current->coord_aspectratio) {
#if DEBUG
			printf("new larger then coord\n");	
			printf("implies that height is too large\n"); 
#endif
			w_current->page_current->bottom = 
				w_current->page_current->top + 
				(w_current->page_current->right - 
				 w_current->page_current->left) / 
				w_current->page_current->coord_aspectratio; 
		} else {
#if DEBUG
			printf("new smaller then coord\n");
			printf("implies that width is too small\n"); 
#endif
			w_current->page_current->right = 
				w_current->page_current->left + 
				(w_current->page_current->bottom - 
				 w_current->page_current->top) * 
				w_current->page_current->coord_aspectratio; 
                }
#if DEBUG 
                printf("invalid aspectratio corrected\n");
#endif
        }


	set_window(w_current, 
		w_current->page_current->left, 
		w_current->page_current->right, 
		w_current->page_current->top, 
		w_current->page_current->bottom);

/* don't have to do this since scrollbars will do the redraw */
/* o_redraw_all();*/

	diff_x = fabs(w_current->page_current->right - 
		      w_current->page_current->left);
	
#ifdef HAS_RINT
	zoom_scale = (int) rint(w_current->init_right / diff_x);
#else 
	zoom_scale = (int) w_current->init_right / diff_x;
#endif

	w_current->page_current->zoom_factor = zoom_scale;

}

void
get_page_bounds(TOPLEVEL *w_current, int *left, int *right, int *top, int *bottom)
{
  COMPONENT_T *comp;

/* These probably aren't the best defaults */
  *left = w_current->init_right;
  *right = 0;
  *top = 0;
  *bottom = w_current->init_bottom;

/* Currently just use components to determine size of page */
  comp = w_current->current_page->components;
  while (comp != NULL) {
    *left = min(*left, comp->bb.left);
    *right = max(*right, comp->bb.right);
    *top = max(*top, comp->bb.top);
    *bottom = min(*bottom, comp->bb.bottom);
    comp = comp->next;
  }

}

void
a_zoom_limits(TOPLEVEL *w_current, OBJECT *o_current) 
{
	int lleft, lright, ltop, lbottom;
	double new_aspect,delta_x,delta_y,pad_x,pad_y;
	int zoom_scale;
	int diff_x;

	if (w_current->current_page->components == NULL) {
		return;	
	}	

	get_page_bounds(w_current, &lleft, &lright, &ltop, &lbottom);

	/* ok, now add some padding on all sides */
	delta_x = (float) fabs(lright - lleft);
	pad_x = delta_x/20.0;
	delta_y = (float) fabs(ltop - lbottom);
	pad_y = delta_y/20.0;
	
	lleft = lleft - (int)pad_x;
	lright = lright + (int)pad_x;
	ltop = ltop + (int)pad_y;
	lbottom = lbottom - (int)pad_y;

	delta_x = (float) fabs(lleft - lright);
	delta_y = (float) fabs(ltop - lbottom);

	w_current->page_current->left = lleft;
	w_current->page_current->right = lright;

	w_current->page_current->top = ltop;
	w_current->page_current->bottom = lbottom;

	new_aspect = delta_x/delta_y;
	
	/* Make sure aspect ratio is correct */
	if (fabs(new_aspect - w_current->page_current->coord_aspectratio)) {
		if (new_aspect > w_current->page_current->coord_aspectratio) {
			/* calculate neccesary padding on Y */
			w_current->page_current->top = 
				w_current->page_current->bottom + (
				w_current->page_current->right - 
				w_current->page_current->left) /
				w_current->page_current->coord_aspectratio; 

		} else {
			/* calculate necessary padding on X */
			w_current->page_current->right = 
				w_current->page_current->left + (
				w_current->page_current->top - w_current->page_current->bottom) * 
				w_current->page_current->coord_aspectratio; 

                }
#if DEBUG
                printf("invalid aspectratio corrected\n");
#endif
        }
	
	new_aspect = (float) fabs(
		w_current->page_current->right - 
		w_current->page_current->left) / 
		(float) fabs(w_current->page_current->top - 
			     w_current->page_current->bottom);

#if DEBUG 
	printf("final %f\n", new_aspect);
#endif

	diff_x = fabs(w_current->page_current->right - 
		      w_current->page_current->left);
	
#ifdef HAS_RINT
	zoom_scale = (int) rint(w_current->init_right / diff_x);
#else 
	zoom_scale = (int) w_current->init_right / diff_x;
#endif
	
	if (zoom_scale > w_current->max_zoom) {
		zoom_scale = w_current->max_zoom;	
	}
	
	if (zoom_scale < w_current->min_zoom) {
		zoom_scale = w_current->min_zoom;	
	}

	w_current->page_current->zoom_factor = zoom_scale;

	set_window(w_current, 
		w_current->page_current->left, 
		w_current->page_current->right, 
		w_current->page_current->bottom, 
		w_current->page_current->top); 
}

/* I think this works okay, but it isn't perfect! */
void
a_zoom_box(TOPLEVEL *w_current)
{
	int world_left, world_top, world_bottom, world_right;
	int x1, y1, x2, y2;
	int zoom_scale;
	int diff_x, diff_y;
	
	int tmp;
	
	if( w_current->last_x < w_current->start_x ) {
		tmp = w_current->last_x;
		w_current->last_x = w_current->start_x;
		w_current->start_x = tmp;
	}
	if( w_current->last_y < w_current->start_y ) {
		tmp = w_current->last_y;
		w_current->last_y = w_current->start_y;
		w_current->start_y = tmp;
	}

	SCREENtoWORLD(w_current,  w_current->start_x, w_current->start_y,
					&x1, &y1);

	SCREENtoWORLD(w_current,  w_current->last_x, w_current->last_y,
					&x2, &y2);

	diff_x = abs(x1 - x2);
	diff_y = abs(y1 - y2);
	if (diff_x == 0 || diff_y == 0) {
		s_log_message("Zoom too small!  Cannot zoom further.\n");
		return;
	}
	

	world_left = w_current->page_current->left = min(x1, x2);
	world_top = w_current->page_current->top = min(y1, y2);
	world_right = w_current->page_current->right = max(x1, x2);
	world_bottom = w_current->page_current->bottom = max(y1, y2);

#if DEBUG
	printf("screen %d %d to %d %d\n", 
		w_current->start_x, w_current->start_y,
				w_current->last_x, w_current->last_y);
	printf("raw %d %d to %d %d\n", 
			world_left, world_top, world_right,world_bottom);
#endif


	if (diff_x > diff_y) { 
		world_bottom = w_current->page_current->bottom = 
			w_current->page_current->top + 
			(w_current->page_current->right - 
			 w_current->page_current->left) / 1.333333333;

	} else {

		world_right = w_current->page_current->right = 
			w_current->page_current->left + 
			(w_current->page_current->bottom - 
			 w_current->page_current->top) * 1.333333333;
	}


#if DEBUG 
/*	printf("final %d %d to %d %d\n", w_current->page_current->left, 
			w_current->page_current->top, 
			w_current->page_current->right, 
			w_current->page_current->bottom);

	new_aspect = (float) fabs(w_current->page_current->right - 
		 	 w_current->page_current->left) / 
			(float) fabs(w_current->page_current->bottom - 
			 w_current->page_current->top);

	printf("final aspect %f\n", new_aspect);*/
#endif

	set_window(w_current, 
		world_left, world_right, 
		world_top, world_bottom); 

	diff_x = fabs(w_current->page_current->right - 
			w_current->page_current->left);
	
#ifdef HAS_RINT
	zoom_scale = (int) rint(w_current->init_right / diff_x);
#else 
	zoom_scale = (int) w_current->init_right / diff_x;
#endif

	w_current->page_current->zoom_factor = zoom_scale;
	w_current->DONT_REDRAW=1;
        w_current->DONT_RECALC=1;
        w_current->DONT_RESIZE=1;
        x_hscrollbar_update(w_current);
        x_vscrollbar_update(w_current);
        o_redraw_all(w_current);
        w_current->DONT_RESIZE=0;
        w_current->DONT_RECALC=0;
        w_current->DONT_REDRAW=0;
}

void
a_zoom_box_start(TOPLEVEL *w_current, int x, int y)
{
	int box_width, box_height;

        w_current->last_x = w_current->start_x = x;
        w_current->last_y = w_current->start_y = y; 

	box_width = abs(w_current->last_x - w_current->start_x);
	box_height = abs(w_current->last_y - w_current->start_y);


	gdk_gc_set_foreground(w_current->xor_gc, &white);
	gdk_draw_rectangle(w_current->window, w_current->xor_gc, 
		   FALSE, w_current->start_x, w_current->start_y, 
			box_width, box_height);

}


void
a_zoom_box_end(TOPLEVEL *w_current, int x, int y)
{
	int box_width, box_height;
	int box_left, box_top;

	if (w_current->inside_action == 0) {
                o_redraw(w_current, w_current->page_current->object_head);
		return;
        }

	box_width = abs(w_current->last_x - w_current->start_x);
	box_height = abs(w_current->last_y - w_current->start_y);	

	if( w_current->last_y < w_current->start_y )
		box_top = w_current->last_y;
	else
		box_top = w_current->start_y;

	if( w_current->last_x < w_current->start_x )
		box_left = w_current->last_x;
	else
		box_left = w_current->start_x;
	
	gdk_gc_set_foreground(w_current->xor_gc, &white);
	gdk_draw_rectangle(w_current->window, w_current->xor_gc, 
			FALSE, box_left, box_top,
                        box_width, box_height); 

	/* erase the box */
#if 0
	gdk_gc_set_foreground(w_current->gc, &white);
	gdk_draw_rectangle(w_current->window, w_current->gc, 
			FALSE, box_left, box_top,
                        box_width, box_height); 
#endif

	a_zoom_box(w_current);

}

void
a_zoom_box_rubberband(TOPLEVEL *w_current, int x, int y)
{
	int box_width, box_height;
	int box_left, box_top;

	if (w_current->inside_action == 0) {
                o_redraw(w_current, w_current->page_current->object_head);
		return;
        }

	box_width = abs(w_current->last_x - w_current->start_x);
	box_height = abs(w_current->last_y - w_current->start_y);

	if( w_current->last_y < w_current->start_y )
		box_top = w_current->last_y;
	else
		box_top = w_current->start_y;

	if( w_current->last_x < w_current->start_x )
		box_left = w_current->last_x;
	else
		box_left = w_current->start_x;

	gdk_gc_set_foreground(w_current->xor_gc, &white);
	gdk_draw_rectangle(w_current->window, w_current->xor_gc, 
		    FALSE, box_left, box_top, 
			box_width, box_height);

       w_current->last_x = (int) x; 
       w_current->last_y = (int) y;

	box_width = abs(w_current->last_x - w_current->start_x);
	box_height = abs(w_current->last_y - w_current->start_y);

	if( w_current->last_y < w_current->start_y )
		box_top = w_current->last_y;
	else
		box_top = w_current->start_y;

	if( w_current->last_x < w_current->start_x )
		box_left = w_current->last_x;
	else
		box_left = w_current->start_x;

	gdk_draw_rectangle(w_current->window, w_current->xor_gc,
		 FALSE, box_left, box_top, 
		 box_width, box_height);
}                                                       

