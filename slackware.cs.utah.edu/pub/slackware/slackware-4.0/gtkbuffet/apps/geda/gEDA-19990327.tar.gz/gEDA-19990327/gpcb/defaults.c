/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <math.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"

#include "colors.h"

#include "pcb_struct.h"

GdkColor *
backgroundColor(TOPLEVEL *w_current)
{
        GdkColor *result;

        result = &black;

        return result;
}

GdkColor *
netColor(TOPLEVEL *w_current)
{
	GdkColor *result;

	result = &white;

	return result;
}

GdkColor *
selectedColor(layer_type layer)
{
        GdkColor *result;

	result = &grey;

	return result;
}

char *
newID(char *str)
{
  static int cnt=1;

  sprintf(str, "U%d", cnt++);
  return str;
}

int
scaleRadius(TOPLEVEL *w_current, int radius)
{
	float fs,f0,f1,f;
	float i;
	int result;

        f0 = w_current->page_current->left;
        f1 = w_current->page_current->right;
        fs = w_current->width;
        f = w_current->width / (f1 - f0);
        i = f * (double)(radius);

#ifdef HAS_RINT
        result = rint(i);
#else
        result = i;
#endif
	return result;
}

GdkColor *
layerToColor(layer_type layer)
{
	GdkColor *result;

	switch (layer) {
	case LAYER_ALL:
		result = &white;
	break;

	case LAYER_1:
		result = &red;
	break;
		
	case LAYER_2:
		result = &red;
	break;
		
	default:
		result = &red;
	break;
	}
	return result;
}
