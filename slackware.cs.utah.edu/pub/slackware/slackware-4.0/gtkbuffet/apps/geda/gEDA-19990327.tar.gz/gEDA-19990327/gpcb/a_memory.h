/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef A_MEMORY_H
#define A_MEMORY_H
#include "pcb_struct.h"

PAGE_T *new_page();

SELECTION_T *new_selection();

COMPONENT_T *new_component();

FOOTPRINT_T *new_footprint();

TRACK_T *new_track();

TRACK_SEG_T *new_track_seg();

NET_T *new_net();

VIA_T *new_via();

PAD_T *new_pad();

#endif
