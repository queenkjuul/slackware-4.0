/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <math.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"

#include "colors.h"

#include "pcb_struct.h"
#include "a_memory.h"
#include "defaults.h"
#include "net.h"

#include "prototype.h"
#include "../libgeda/prototype.h"

void
o_net_rubberband(TOPLEVEL *w_current, NET_T *net, int mouse_x, int mouse_y)
{
  int d_x, d_y, s_x, s_y;

  SCREENtoWORLD(w_current, net->src_x, net->src_y, &s_x, &s_y);
  SCREENtoWORLD(w_current, mouse_x, mouse_y, &d_x, &d_y);

  net_draw(w_current,net, DRAW_XOR);
  net->dst_x = d_x;
  net->dst_y = d_y;
  net_draw(w_current,net, DRAW_XOR);
}

void
net_draw(TOPLEVEL *w_current, NET_T *net, drawing_type modifier)
{
  int src_x, src_y, dst_x, dst_y;
	
  WORLDtoSCREEN(w_current, net->src_x, net->src_y, &src_x, &src_y);
  WORLDtoSCREEN(w_current, net->dst_x, net->dst_y, &dst_x, &dst_y);

  if (!net->routed) {  /* Don't draw this net if it has been routed */
    if (modifier == DRAW_XOR) {
      gdk_gc_set_foreground(w_current->outline_xor_gc, netColor(w_current));
      gdk_gc_set_line_attributes(w_current->outline_xor_gc, 0, GDK_LINE_SOLID, GDK_CAP_NOT_LAST, GDK_JOIN_MITER);
      gdk_draw_line(w_current->window, w_current->outline_xor_gc, src_x, src_y, dst_x, dst_y);
    }
    else {
      gdk_gc_set_foreground(w_current->gc, netColor(w_current));
      gdk_gc_set_line_attributes(w_current->gc, 0, GDK_LINE_SOLID, GDK_CAP_NOT_LAST, GDK_JOIN_MITER);
      gdk_draw_line(w_current->window, w_current->gc, src_x, src_y, dst_x, dst_y);
    }
  }

}

void
printNet(NET_T *net)
{
  printf("Net: ");
  printf("  %d,%d to %d,%d\n", net->src_x, net->src_y, net->dst_x, net->dst_y);
}
