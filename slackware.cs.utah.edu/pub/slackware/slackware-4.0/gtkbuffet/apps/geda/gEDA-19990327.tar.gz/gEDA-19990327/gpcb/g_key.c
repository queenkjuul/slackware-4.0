/* gEDA - GNU Electronic Design Automation
 * gschem/gpcb - GNU Schematic Capture and Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h> 
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <sys/stat.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h> 
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"  

#include "prototype.h"
#include "../libgeda/prototype.h"

/* this is needed so that these routines know which window they are changing */
static TOPLEVEL *window_current;

void
set_window_current_key(TOPLEVEL *w_current)
{
	window_current = w_current;
}

/* for now this only supports single chars, not shift/alt/ctrl etc... */
void
g_key_execute(int state, int keyval)
{
	char guile_string[50]; /* size hack */
	char modifier[10];

	if (keyval == 0) {
		return;
	}
	
	if (state & GDK_SHIFT_MASK) {
		strcpy(modifier, "\"Shift ");
	} else if (state & GDK_CONTROL_MASK) {
		strcpy(modifier, "\"Control ");
	} else if (state & GDK_MOD1_MASK) {
		strcpy(modifier, "\"Alt ");
	} else {
		modifier[0] = '\"';
		modifier[1] = '\0';
	}

	/* don't pass the raw modifier key presses to the guile code */	
	if ( strstr(XKeysymToString(keyval), "Alt")) {
		return;
	}

	if ( strstr(XKeysymToString(keyval), "Shift")) {
		return;
	}

	if ( strstr(XKeysymToString(keyval), "Control")) {
		return;
	}

	sprintf(guile_string, "(press-key %s%s\")", modifier, XKeysymToString (keyval));
	
#if DEBUG
	printf("_%s_\n", guile_string);
#endif

	gh_eval_str(guile_string);

#if 0 /* playing with thi's guile stuff */
	gh_eval_str("(display (reverse last-command-sequence))");
	printf("\n");
#endif
		
}

SCM g_key_file_new (void) 
{
	i_callback_file_new(NULL, window_current);
	return(gh_int2scm(0));
}


SCM
g_key_file_new_window (void) 
{
	i_callback_file_new_window(NULL, window_current);
	return(gh_int2scm(0));
}


/* don't use the widget parameter on this function, or do some checking... */
/* since there is a call: widget = NULL, data = 0 (will be w_current) */ 
/* This should be renamed to page_open perhaps... */
SCM 
g_key_file_open (void) 
{
	i_callback_file_open(NULL, window_current);
	return(gh_int2scm(0));
}


/* don't use the widget parameter on this function, or do some checking... */
/* since there is a call: widget = NULL, data = 0 (will be w_current) */ 
SCM 
g_key_file_save (void) 
{
	i_callback_file_save(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_file_saveas (void) 
{
	i_callback_file_saveas(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_file_print (void) 
{
	i_callback_file_print(NULL, window_current);
	return(gh_int2scm(0));
}


/* don't use the widget parameter on this function, or do some checking... */
/* since there is a call: widget = NULL, data = 0 (will be w_current) */ 
/* this function closes a window */
SCM
g_key_file_close_window (void)
{
	/* close the current window */
	i_callback_file_close(NULL, window_current);
	return(gh_int2scm(0));
}


SCM
g_key_file_quit (void)
{
	i_callback_file_quit(NULL, window_current);
	return(gh_int2scm(0));
}


/* Edit menu */

/* Select also does not update the middle button shortcut */
SCM 
g_key_edit_select (void)
{
	i_callback_edit_select(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_copy (void)
{
	i_callback_edit_copy(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_copy_hotkey (void)
{
	i_callback_edit_copy_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_move (void)
{
	i_callback_edit_move(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_move_hotkey (void)
{
	i_callback_edit_move_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_delete (void)
{
	i_callback_edit_delete(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_rotate_90 (void)
{
	i_callback_edit_rotate_90(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_rotate_90_hotkey (void)
{
	i_callback_edit_rotate_90_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_mirror (void)
{
	i_callback_edit_rotate_90(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_mirror_hotkey (void)
{
	i_callback_edit_mirror_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_edit_slot (void)
{
	i_callback_edit_slot(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_edit (void)
{
	i_callback_edit_edit(NULL, window_current);
	return(gh_int2scm(0));
}


/* locks all objects in selection list */
SCM 
g_key_edit_lock (void)
{
	i_callback_edit_lock(NULL, window_current);
	return(gh_int2scm(0));
}


/* unlocks all objects in selection list */
SCM 
g_key_edit_unlock (void)
{
	i_callback_edit_unlock(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_edit_translate (void)
{
	i_callback_edit_translate(NULL, window_current);
	return(gh_int2scm(0));
}

/* embedds all objects in selection list */
SCM 
g_key_edit_embed (void)
{
	i_callback_edit_embed(NULL, window_current);
	return(gh_int2scm(0));
}

/* unembedds all objects in selection list */
SCM 
g_key_edit_unembed (void)
{
	i_callback_edit_unembed(NULL, window_current);
	return(gh_int2scm(0));
}

/* View menu */

/* repeat middle shortcut doesn't make sense on redraw, just hit right button */
SCM 
g_key_view_redraw (void)
{
	i_callback_view_redraw(NULL, window_current);
	return(gh_int2scm(0));
}


/* repeat middle shortcut would get into the way of what user is try to do */
SCM 
g_key_view_zoom_full (void)
{
	i_callback_view_zoom_full(NULL, window_current);
	return(gh_int2scm(0));
}

/* repeat middle shortcut would get into the way of what user is try to do */
SCM 
g_key_view_zoom_limits (void)
{
	i_callback_view_zoom_limits(NULL, window_current);
	return(gh_int2scm(0));
}

/* repeat middle shortcut would get into the way of what user is try to do */
SCM 
g_key_view_zoom_in (void)
{
	i_callback_view_zoom_in(NULL, window_current);
	return(gh_int2scm(0));
}

/* repeat middle shortcut would get into the way of what user is try to do */
SCM 
g_key_view_zoom_out (void)
{
	i_callback_view_zoom_out(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_view_zoom_box (void)
{
	i_callback_view_zoom_box(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_view_zoom_box_hotkey (void)
{
	i_callback_view_zoom_box_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_view_pan (void)
{
	i_callback_view_pan(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_view_pan_hotkey (void)
{
	i_callback_view_pan_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}

SCM  
g_key_view_updatenets (void)
{
	i_callback_view_updatenets(NULL, window_current);
	return(gh_int2scm(0));
}


SCM  
g_key_page_manager (void)
{
	i_callback_page_manager(NULL, window_current);
	return(gh_int2scm(0));
}

SCM  
g_key_page_next (void)
{
	i_callback_page_next(NULL, window_current);
	return(gh_int2scm(0));
}


SCM  
g_key_page_prev (void)
{
	i_callback_page_prev(NULL, window_current);
	return(gh_int2scm(0));
}


SCM  
g_key_page_new (void)
{
	i_callback_page_new(NULL, window_current);
	return(gh_int2scm(0));
}


SCM  
g_key_page_close (void)
{
	i_callback_page_close(NULL, window_current);
	return(gh_int2scm(0));
}


SCM  
g_key_page_discard (void)
{
	i_callback_page_discard(NULL, window_current);
	return(gh_int2scm(0));
}


SCM  
g_key_page_print (void)
{
	i_callback_page_print(NULL, window_current);
	return(gh_int2scm(0));
}

/* Add menu */ 
SCM 
g_key_add_component (void)
{
	i_callback_add_component(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_add_attribute (void)
{
	i_callback_add_attribute(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_add_net (void)
{
	i_callback_add_net(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_net_hotkey (void)
{
	i_callback_add_net_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_text (void)
{
	i_callback_add_text(NULL, window_current);
	return(gh_int2scm(0));
}


SCM 
g_key_add_line (void)
{
	i_callback_add_line(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_line_hotkey (void)
{
	i_callback_add_line_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_box (void)
{
	i_callback_add_box(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_box_hotkey (void)
{
	i_callback_add_box_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_circle (void)
{
	i_callback_add_circle(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_circle_hotkey (void)
{
	i_callback_add_circle_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_arc (void)
{
	i_callback_add_arc(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_arc_hotkey (void)
{
	i_callback_add_arc_hotkey(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_add_pin (void)
{
/*	i_callback_add_pin(NULL, window_current); */
	return(gh_int2scm(0));
}

SCM 
g_key_add_pin_hotkey (void)
{
/*	i_callback_add_pin_hotkey(NULL, window_current); */
	return(gh_int2scm(0));
}


/* Hierarchy menu */
SCM 
g_key_hierarchy_open_symbol (void)
{
	i_callback_hierarchy_open_symbol(NULL, window_current);

	return(gh_int2scm(0));
}

/* Attributes menu */
SCM  
g_key_attributes_attach (void)
{
	i_callback_attributes_attach(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_attributes_detach (void)
{
	i_callback_attributes_detach(NULL, window_current);
	return(gh_int2scm(0));
}

SCM
g_key_attributes_show_name (void)
{
	i_callback_attributes_show_name(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_attributes_show_value (void)
{
	i_callback_attributes_show_value(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_attributes_show_both (void)
{
	i_callback_attributes_show_both(NULL, window_current);
	return(gh_int2scm(0));
}

SCM 
g_key_attributes_visibility_toggle (void)
{
	i_callback_attributes_visibility_toggle(NULL, window_current);
	return(gh_int2scm(0));
}

/* Script menu */
/* not currently implemented */
SCM 
g_key_script_console (void)
{

	return(gh_int2scm(0));
}

/* Layers menu */

/* Options menu */

/* repeat last command doesn't make sense on options either??? (does it?) */
SCM
g_key_options_text_size (void)
{
	i_callback_options_text_size(NULL, window_current);
	return(gh_int2scm(0));
}     

/* repeat last command doesn't make sense on options either??? (does it?) */
SCM
g_key_options_afeedback (void) 
{
	i_callback_options_afeedback(NULL, window_current);
	return(gh_int2scm(0));
}

SCM
g_key_options_grid (void)
{
	i_callback_options_grid(NULL, window_current);
	return(gh_int2scm(0));
}

SCM
g_key_options_snap (void) 
{
	i_callback_options_snap(NULL, window_current);
	return(gh_int2scm(0));
}

SCM
g_key_options_snap_size (void)
{
	i_callback_options_snap_size(NULL, window_current);
	return(gh_int2scm(0));
}   

SCM g_key_options_show_log_window (void)
{
	i_callback_options_show_status(NULL, window_current);
	return(gh_int2scm(0));
}

/* for now this prints out the font_set structure */
SCM  
g_key_misc (void)
{
	i_callback_misc(NULL, window_current);
	return(gh_int2scm(0));
}

/* be sure that you don't use the widget parameter in this one, since it is 
being called with a null, I suppose we should call it with the right param.
hack */
SCM
g_key_cancel(void)
{
	i_callback_cancel(NULL, window_current);
	return(gh_int2scm(0));
}

