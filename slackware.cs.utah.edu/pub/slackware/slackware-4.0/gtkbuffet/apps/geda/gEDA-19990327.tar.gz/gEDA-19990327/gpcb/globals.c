/* gEDA - GNU Electronic Design Automation
 * gschem/gpcb - GNU Schematic Capture and Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "defines.h"
#include "globals.h"
#include "struct.h"
#include "x_states.h"
#include "colors.h"

#include "x_log.h"

/*#include "prototype.h" */

char rc_filename[256]; /* size is hack */  

/* color stuff */
GdkColormap *colormap; 
GdkVisual *visual; 

/* colors */
GdkColor white;
GdkColor black;
GdkColor red;
GdkColor green;
GdkColor blue;
GdkColor cyan;
GdkColor yellow;
GdkColor grey;
GdkColor grey90;
GdkColor darkgreen;
GdkColor darkred;
GdkColor darkyellow;
GdkColor darkcyan;
GdkColor darkblue;
GdkColor darkgrey; 


int logfile_fd=-1;
int do_logging=TRUE;
int logging_dest=LOG_WINDOW;

/* these are required by libgeda */
void (*arc_draw_func)() = NULL;
void (*box_draw_func)() = NULL;
void (*circle_draw_func)() = NULL;
/*void (*complex_draw_func)() = o_complex_draw; */
void (*complex_draw_func)() = NULL;
/*void (*line_draw_func)() = o_line_draw; */
void (*line_draw_func)() = NULL;
void (*pin_draw_func)() = NULL;
/*void (*net_draw_func)() = o_net_draw; */
void (*net_draw_func)() = NULL;
/*void (*ntext_draw_func)() = o_ntext_draw; */
void (*ntext_draw_func)() = NULL;
/*void (*select_func)() = o_select; */
void (*select_func)() = NULL;
void (*pin_conn_recalc_func)() = NULL;
/*void (*net_conn_recalc_func)() = o_net_conn_recalc_draw; */
void (*net_conn_recalc_func)() = NULL;
void (*x_log_update_func)() = x_log_update;

/* command line options */
int quiet_mode=FALSE;
int verbose_mode=FALSE;
