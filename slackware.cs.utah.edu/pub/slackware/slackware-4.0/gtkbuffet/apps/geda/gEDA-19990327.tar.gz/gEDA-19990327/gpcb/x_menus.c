/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board layout
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <gtk/gtk.h>

#include <guile/gh.h>

#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif


#include "struct.h"
#include "defines.h"
#include "globals.h"

#include "prototype.h"
#include "../libgeda/prototype.h"


void menus_init(TOPLEVEL *w_current);
void menus_create(TOPLEVEL *w_current, GtkMenuEntry * entries, int nmenu_entries);


    /* this is the GtkMenuEntry structure used to create new menus.  The
     * first member is the menu definition string.  The second, the
     * default accelerator key used to access this menu function with
     * the keyboard.  The third is the callback function to call when
     * this menu item is selected (by the accelerator key, or with the
     * mouse.) The last member is the data to pass to your callback function.
     */


/* no longer static */
/* but it can be static again */
GtkMenuEntry menu_items[] =
{
/*	{"<Main>/File/New Window", NULL, i_callback_file_new_window, NULL}, */
/*	{"<Main>/File/New Page", NULL, i_callback_file_new, NULL}, */
	{"<Main>/File/Open Page...", NULL, i_callback_file_open, NULL},
	{"<Main>/File/Save Page", NULL, i_callback_file_save, NULL},
	{"<Main>/File/Save Page as....", NULL, i_callback_file_saveas, NULL},
/*	{"<Main>/File/Print...", NULL, i_callback_file_print, NULL}, */
	{"<Main>/File/<separator>", NULL, NULL, NULL},
/*	{"<Main>/File/Close Window", NULL, i_callback_file_close, NULL}, */
	{"<Main>/File/Quit gpcb", NULL, i_callback_file_quit, NULL},
	/* because i_callback_file_quit returns an int, the compiler complains*/

	{"<Main>/Edit/Select Mode", NULL, i_callback_edit_select, NULL},
	{"<Main>/Edit/Edit...", NULL, i_callback_edit_edit, NULL},
/*	{"<Main>/Edit/Copy Mode", NULL, i_callback_edit_copy, NULL}, */
	{"<Main>/Edit/Move Mode", NULL, i_callback_edit_move, NULL},
/*	{"<Main>/Edit/Delete", NULL, i_callback_edit_delete, NULL}, */
	{"<Main>/Edit/<separator>", NULL, NULL, NULL},
	{"<Main>/Edit/Route", NULL, i_callback_route_net, NULL},
/*	{"<Main>/Edit/Rotate 90 Mode", NULL, i_callback_edit_rotate_90, NULL}, */
/*	{"<Main>/Edit/Mirror Mode", NULL, i_callback_edit_mirror, NULL}, */
/*	{"<Main>/Edit/<separator>", NULL, NULL, NULL}, */
/*	{"<Main>/Edit/Slot...", NULL, i_callback_edit_slot, NULL}, */
/*	{"<Main>/Edit/Lock", NULL, i_callback_edit_lock, NULL}, */
/*	{"<Main>/Edit/Unlock", NULL, i_callback_edit_unlock, NULL}, */
/*	{"<Main>/Edit/Symbol Translate...", NULL, i_callback_edit_translate, NULL}, */
/*	{"<Main>/Edit/Embed Component", NULL, i_callback_edit_embed, NULL}, */
/*	{"<Main>/Edit/Unembed Component", NULL, i_callback_edit_unembed, NULL}, */

	{"<Main>/View/Redraw", NULL, i_callback_view_redraw, NULL},
	{"<Main>/View/Pan", NULL, i_callback_view_pan, NULL},
	{"<Main>/View/Zoom box", NULL, i_callback_view_zoom_box, NULL},
	{"<Main>/View/Zoom limits", NULL, i_callback_view_zoom_limits, NULL},
	{"<Main>/View/Zoom in", NULL, i_callback_view_zoom_in, NULL},
	{"<Main>/View/Zoom out", NULL, i_callback_view_zoom_out, NULL},
	{"<Main>/View/Zoom full", NULL, i_callback_view_zoom_full, NULL},
/*	{"<Main>/View/Update nets", NULL,  i_callback_view_updatenets, NULL}, */
	/* change name of update nets */

/*	{"<Main>/Page/Manager...", NULL,  i_callback_page_manager, NULL}, */
/*	{"<Main>/Page/Next", NULL,  i_callback_page_next, NULL}, */
/*	{"<Main>/Page/Prev", NULL,  i_callback_page_prev, NULL}, */
/*	{"<Main>/Page/Close", NULL,  i_callback_page_close, NULL}, */
/*	{"<Main>/Page/Discard", NULL,  i_callback_page_discard, NULL}, */
/*	{"<Main>/Page/Print struct", NULL,  i_callback_page_print, NULL}, */

	{"<Main>/Add/Component...", NULL, i_callback_add_component, NULL},
	{"<Main>/Add/Net", NULL, i_callback_add_line, NULL},
/*	{"<Main>/Add/Attribute...", NULL, i_callback_add_attribute, NULL}, */
/*	{"<Main>/Add/Text", NULL, i_callback_add_text, NULL}, */
/*	{"<Main>/Add/<separator>", NULL, NULL, NULL}, */
/*	{"<Main>/Add/Line", NULL, i_callback_add_line, NULL}, */
/*	{"<Main>/Add/Box", NULL, i_callback_add_box, NULL}, */
/*	{"<Main>/Add/Circle", NULL, i_callback_add_circle, NULL}, */
/*	{"<Main>/Add/Arc", NULL, i_callback_add_arc, NULL}, */
/*	{"<Main>/Add/Pin", NULL, i_callback_add_pin, NULL}, */

/*	{"<Main>/Hierarchy/Open Symbol", NULL, i_callback_hierarchy_open_symbol, NULL}, */

/*	{"<Main>/Attributes/Attach", NULL, i_callback_attributes_attach, NULL}, */
/*	{"<Main>/Attributes/Deattach", NULL, i_callback_attributes_detach, NULL}, */
/*	{"<Main>/Attributes/Show Value", NULL, i_callback_attributes_show_value, NULL}, */
/*	{"<Main>/Attributes/Show Name", NULL, i_callback_attributes_show_name, NULL}, */
/*	{"<Main>/Attributes/Show Both", NULL, i_callback_attributes_show_both, NULL}, */
/*	{"<Main>/Attributes/Toggle Vis", NULL, i_callback_attributes_visibility_toggle, NULL}, */

/* to be added later hack */
/* {"<Main>/Script/Console", "<shift>~", i_callback_script_console, NULL},*/

/* to be added later hack */
/* 	{"<Main>/Layers/Visibility...", NULL, NULL, NULL},
	{"<Main>/Options/Colors...", NULL, NULL, NULL},*/


/*	{"<Main>/Options/Text Size...", NULL, i_callback_options_text_size, NULL}, */
	{"<Main>/Options/Toggle Grid", NULL, i_callback_options_grid, NULL},
	{"<Main>/Options/Toggle Snap", NULL, i_callback_options_snap, NULL},
	{"<Main>/Options/Snap Grid Spacing...", NULL, i_callback_options_snap_size, NULL},
/*	{"<Main>/Options/Toggle Outline", NULL, i_callback_options_afeedback, NULL}, */
/*	{"<Main>/Options/Show Log Window", NULL, i_callback_options_show_status, NULL}, */
#if 0 /* experimental */
	{"<Main>/Options/MISC (preview)", NULL, i_callback_preview, NULL},
#endif

/* to be added later hack */
	/* {"<Main>/Help", NULL, NULL, NULL},*/


	{"<Popup>/Component...", NULL, i_callback_add_component, NULL},
	{"<Popup>/Net", NULL, i_callback_add_line, NULL},
/*	{"<Popup>/Attribute...", NULL, i_callback_add_attribute, NULL}, */
/*	{"<Popup>/Text", NULL, i_callback_add_text, NULL}, */
	{"<Popup>/<separator>", NULL, NULL, NULL},
	{"<Popup>/Select", NULL, i_callback_edit_select, NULL},
	{"<Popup>/Edit...", NULL, i_callback_edit_edit, NULL},
/*	{"<Popup>/Copy", NULL, i_callback_edit_copy, NULL}, */
	{"<Popup>/Move", NULL, i_callback_edit_move, NULL},
/*	{"<Popup>/Delete", NULL, i_callback_edit_delete, NULL}, */
};

/* calculate the number of menu_item's */
int nmenu_items = sizeof(menu_items) / sizeof(menu_items[0]);

void 
#if GTK_DEVEL
get_main_menu(TOPLEVEL *w_current, GtkWidget ** menubar, GtkAccelGroup ** accel)
#else
get_main_menu(TOPLEVEL *w_current, GtkWidget ** menubar, GtkAcceleratorTable ** table)
#endif
{
	int i;
/* put this back in when you add the help button  
	GtkMenuPath *menu_path;
*/
	w_current->factory = NULL;	
	w_current->entry_ht = NULL;	

	/* Init the callback data to the passed in window */
	for ( i = 0 ; i < nmenu_items; i++) {
		menu_items[i].callback_data = w_current;	
	}

	menus_init(w_current);

        
        if (menubar)
                *menubar = w_current->subfactory[0]->widget;
#if GTK_DEVEL
        if (accel)
                *accel = w_current->subfactory[0]->accel_group;
#else
        if (table)
                *table = w_current->subfactory[0]->table;
#endif

/* to be added after you add the help hack 
	menu_path = gtk_menu_factory_find (w_current->factory, "<Main>/Help");
	gtk_menu_item_right_justify(GTK_MENU_ITEM(menu_path->widget));
*/
}

void
#if GTK_DEVEL
get_main_popup(TOPLEVEL *w_current, GtkWidget ** menu, GtkAccelGroup ** accel)
#else
get_main_popup(TOPLEVEL *w_current, GtkWidget ** menu, GtkAcceleratorTable ** table)
#endif
{
	/* be sure that you called get_main_menu first */
	
        if (menu)
                *menu = w_current->subfactory[1]->widget;
#if GTK_DEVEL
        if (accel)
                *accel = w_current->subfactory[1]->accel_group;
#else
        if (table)
                *table = w_current->subfactory[1]->table;
#endif
}

void 
menus_init(TOPLEVEL *w_current)
{
           
        w_current->factory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);

        w_current->subfactory[0] = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);
       	gtk_menu_factory_add_subfactory(w_current->factory, w_current->subfactory[0], "<Main>");

	w_current->subfactory[1] = gtk_menu_factory_new (GTK_MENU_FACTORY_MENU);
	gtk_menu_factory_add_subfactory (w_current->factory, w_current->subfactory[1], "<Popup>"); 

	/* menurc? hack */
	menus_create(w_current, menu_items, nmenu_items);
}

void 
menus_create(TOPLEVEL *w_current, GtkMenuEntry * entries, int nmenu_entries)
{
	char *accelerator;
        int i;
        
        if (w_current->entry_ht)
                for (i = 0; i < nmenu_entries; i++) {
                    accelerator = g_hash_table_lookup(w_current->entry_ht, entries[i].path);
			if (accelerator) {
				if (accelerator[0] == '\0')
                               		entries[i].accelerator = NULL;
                        	else
                                	entries[i].accelerator = accelerator;
                    	}
                }

        gtk_menu_factory_add_entries(w_current->factory, entries, nmenu_entries);
       
}

/* need to look at this... here and the setup */
gint
do_popup (TOPLEVEL *w_current, GdkEventButton *event)
{
	GtkWidget *menu=NULL; /* was static */

	if (!menu)
		menu = w_current->popup_menu; 

	if (menu == NULL) {
		printf("null menu\n");
	}

	gtk_menu_popup (GTK_MENU (menu), NULL, NULL, NULL, NULL, 
		event->button, event->time);

	return FALSE;
}

