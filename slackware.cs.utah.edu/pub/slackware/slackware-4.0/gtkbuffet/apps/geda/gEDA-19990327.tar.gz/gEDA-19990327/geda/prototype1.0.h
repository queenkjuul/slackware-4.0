/* g_rc.c */
void g_rc_parse(void);
SCM g_rc_version(SCM version);
SCM g_rc_projects_filename(SCM path);
SCM g_rc_tool(SCM tool_name, SCM icon_name, SCM path_name, SCM params_name);
/* g_register.c */
void g_register_funcs(void);
/* geda.c */
void geda_quit(void);
void main_prog(int argc, char *argv[]);
int main(int argc, char *argv[]);
/* globals.c */
/* i_callbacks.c */
void i_callback_file_quit(GtkWidget *widget, gpointer data);
void i_callback_launch(GtkWidget *widget, gpointer data);
/* t_basic.c */
TOOL *t_return_tool_tail(TOOL *head);
TOOL *t_return_tool_head(TOOL *tail);
void t_add(char *tool, char *icon, char *path, char *params);
void t_print(TOOL *list);
/* x_menus.c */
void get_main_menu(GEDA *w_current, GtkWidget **menubar, GtkAcceleratorTable **table);
void menus_init(GEDA *w_current);
void menus_create(GEDA *w_current, GtkMenuEntry *entries, int nmenu_entries);
/* x_window.c */
GtkWidget *xpm_label_box(GtkWidget *parent, gchar *xpm_filename, gchar *label_text);
void x_window_create(void);
