/* STILL NEED to clean up line lengths in aa and tr */

/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board layout
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef X_LOG_H
#define X_LOG_H

#include <config.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>
#include <glib.h>

#include <guile/gh.h>


#include "struct.h"   
#include "defines.h"
#include "colors.h"   
#include "paths.h"
#include "globals.h"
#include "x_states.h"


#include "prototype.h"
#include "../libgeda/prototype.h"

static GtkWidget *stwindow=NULL;
static GtkWidget *sttext=NULL;

void
x_log_read(void);

void
x_log_update(char *buf);

void
x_log_close(GtkWidget *w, TOPLEVEL *w_current);

void
x_log_setup_win (TOPLEVEL *w_current);

#endif
