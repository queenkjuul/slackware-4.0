/* gEDA - GNU Electronic Design Automation
 * gschem/gpcb - GNU Schematic Capture and Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <math.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"

#include "colors.h"

#include "prototype.h"
#include "../libgeda/prototype.h"


void
o_box_draw(TOPLEVEL *w_current, OBJECT *o_current)
{
	int wleft, wright, wtop, wbottom; /* world bounds */
/*printf("o_box_draw\n"); */
return;

	if (o_current->line_points == NULL) {
		return;
	}

	o_box_recalc(w_current, o_current);

	/* Get read to check for visibility of this line by using it's */
        /* bounding box */
        world_get_box_bounds(w_current, o_current->line_points, &wleft, &wtop,
&wright, &wbottom);

        if (!visible(w_current, wleft, wtop, wright, wbottom)) {
                return;
        }

	if (w_current->override_color != -1 ) {
		gdk_gc_set_foreground(w_current->gc, 
			x_get_color(w_current->override_color));
		gdk_draw_rectangle(w_current->window, 
			w_current->gc, FALSE, 
			o_current->line_points->screen_x1, 
			o_current->line_points->screen_y1, 
			abs(o_current->line_points->screen_x2 - 
					o_current->line_points->screen_x1), 
			abs(o_current->line_points->screen_y2 -
					o_current->line_points->screen_y1)); 
		gdk_draw_rectangle(w_current->backingstore, 
			w_current->gc, FALSE, 
			o_current->line_points->screen_x1, 
			o_current->line_points->screen_y1, 
			abs(o_current->line_points->screen_x2 - 
					o_current->line_points->screen_x1), 
			abs(o_current->line_points->screen_y2 -
					o_current->line_points->screen_y1)); 
	} else {
		gdk_gc_set_foreground(w_current->gc, 
			x_get_color(o_current->color));
		gdk_draw_rectangle(w_current->window, 
			w_current->gc, FALSE, 
			o_current->line_points->screen_x1, 
			o_current->line_points->screen_y1, 
			abs(o_current->line_points->screen_x2 - 
					o_current->line_points->screen_x1), 
			abs(o_current->line_points->screen_y2 -
					o_current->line_points->screen_y1)); 
		gdk_draw_rectangle(w_current->backingstore, 
			w_current->gc, FALSE, 
			o_current->line_points->screen_x1, 
			o_current->line_points->screen_y1, 
			abs(o_current->line_points->screen_x2 -
					o_current->line_points->screen_x1), 
			abs(o_current->line_points->screen_y2 -
					o_current->line_points->screen_y1)); 
	}

}

void
o_box_draw_xor(TOPLEVEL *w_current, int dx, int dy, OBJECT *o_current)
{
	int screen_x1, screen_y1;
	int screen_x2, screen_y2;
/*printf("o_box_draw_xor\n"); */
return;
	if (o_current->line_points == NULL) {
		return;
	}

	screen_x1 = o_current->line_points->screen_x1;
	screen_y1 = o_current->line_points->screen_y1;
	screen_x2 = o_current->line_points->screen_x2;
	screen_y2 = o_current->line_points->screen_y2;

        gdk_gc_set_foreground(w_current->outline_xor_gc, 
		x_get_darkcolor(o_current->color));
	gdk_draw_rectangle(w_current->window, 
			w_current->outline_xor_gc, FALSE,
			screen_x1+dx, 
			screen_y1+dy, 
			abs(screen_x2-screen_x1), 
			abs(screen_y2-screen_y1)); 
}


void
o_box_start(TOPLEVEL *w_current, int x, int y)
{
	int box_width, box_height;
/*printf("o_box_start\n"); */
return;
        w_current->last_x = w_current->start_x = fix_x(w_current, x);
        w_current->last_y = w_current->start_y = fix_y(w_current, y); 

	box_width = abs(w_current->last_x - w_current->start_x);
	box_height = abs(w_current->last_y - w_current->start_y);

/* 
	printf("start_x,y %d %d\n", w_current->start_x, w_current->start_y);
*/
	
	gdk_gc_set_foreground(w_current->xor_gc, 
			x_get_color(w_current->select_color));
	gdk_draw_rectangle(w_current->window, w_current->xor_gc, 
			FALSE, w_current->start_x, w_current->start_y,
			box_width, box_height);
}

void
o_box_end(TOPLEVEL *w_current, int x, int y)
{
        int x1, y1;
        int x2, y2;
	int box_width, box_height;
	int box_left, box_top;

/*printf("o_box_end\n"); */
return;
}                         

void
o_box_rubberbox(TOPLEVEL *w_current, int x, int y)
{
	int box_width, box_height;
	int box_left, box_top;

return;
	if (w_current->inside_action == 0) {
                o_redraw(w_current, w_current->page_current->object_head);
		return;
        }

	box_width = abs(w_current->last_x - w_current->start_x);
	box_height = abs(w_current->last_y - w_current->start_y);

	if( w_current->last_y < w_current->start_y )
                box_top = w_current->last_y;
        else
                box_top = w_current->start_y;

        if( w_current->last_x < w_current->start_x )
                box_left = w_current->last_x;
        else
                box_left = w_current->start_x;

	gdk_gc_set_foreground(w_current->xor_gc, 
			x_get_color(w_current->select_color) );
	gdk_draw_rectangle(w_current->window, w_current->xor_gc, 
			FALSE, box_left, box_top,
			box_width, box_height);

        w_current->last_x = fix_x(w_current, x);
        w_current->last_y = fix_y(w_current, y);

/*        if (diff_x >= diff_y) {
                last_y = start_y;
        } else {
                last_x = start_x;
        }*/

	box_width = abs(w_current->last_x - w_current->start_x);
	box_height = abs(w_current->last_y - w_current->start_y);

        if( w_current->last_y < w_current->start_y )
                box_top = w_current->last_y;
        else
                box_top = w_current->start_y;

        if( w_current->last_x < w_current->start_x )
                box_left = w_current->last_x;
        else
                box_left = w_current->start_x;



	gdk_gc_set_foreground(w_current->xor_gc, 
		x_get_color(w_current->select_color) );
	gdk_draw_rectangle(w_current->window, w_current->xor_gc, 
		FALSE, box_left, box_top, 
		box_width, box_height);
}                                                       

