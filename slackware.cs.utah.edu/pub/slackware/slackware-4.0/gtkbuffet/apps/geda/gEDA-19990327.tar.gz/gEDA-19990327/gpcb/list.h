/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board layout
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef LIST_H
#define LIST_H

#include <config.h>
#include <stdio.h>
#include <signal.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "o_types.h"
#include "struct.h"
#include "a_memory.h"
#include "pcb_struct.h"
#include "globals.h"
#include "defines.h"

#include "prototype.h"
#include "../libgeda/prototype.h"

extern FOOTPRINT_T *recent_footprint;

FOOTPRINT_T *
footprint_defined(PAGE_T *page, FOOTPRINT_ID id);

void
component_add(PAGE_T *page, FOOTPRINT_T *foot, char *id, int x, int y);

void
o_component_add(PAGE_T *page, char *id, int x, int y);

void 
o_selections_free(PAGE_T *page);

void
o_selection_add(PAGE_T *page, SELECTION_T *selection);

FOOTPRINT_T *
footprint_add(PAGE_T *page, char *footDef);

void
o_footprint_add(PAGE_T *page, OBJECT *object, int x, int y);

void
net_add(PAGE_T *page, NET_T *net);

void
pad_add(FOOTPRINT_T *foot, char *padDef);

void
track_add(PAGE_T *page, TRACK_T *newTrack);

void
o_pad_add(PAGE_T *page, OBJECT *object, int x, int y);

#endif
