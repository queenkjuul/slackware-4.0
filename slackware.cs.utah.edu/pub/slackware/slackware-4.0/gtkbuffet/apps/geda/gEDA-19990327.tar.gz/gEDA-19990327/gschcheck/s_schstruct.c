/* gEDA - GNU Electronic Design Automation
 * gschcheck - GNU Schematic Check 
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h>
#include <signal.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "globals.h"
#include "defines.h"

#include "prototype.h"
#include "../libgeda/prototype.h"


/* call this for every sheet that needs to be checked */
SYMCHECK *
s_schstruct_init(void)
{
	SYMCHECK *s_schcheck;
	
	s_schcheck = (SYMCHECK *) malloc(sizeof(SYMCHECK));

	return(s_schcheck);
}

/* return >1 if there were errors */
/* return 0 if there were no errors */
int
s_schstruct_print(SYMCHECK *s_current)
{
	int status=0;

	/* increment status for every error found */

	return(status);
}

void
s_schstruct_free(SYMCHECK *s_current)
{
	if (s_current) {

		free(s_current);
	}
}
