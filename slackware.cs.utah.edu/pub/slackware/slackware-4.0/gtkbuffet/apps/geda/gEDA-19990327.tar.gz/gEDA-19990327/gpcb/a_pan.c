/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Schematic Capture and Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.     
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "globals.h"
#include "defines.h"

#include "prototype.h"
#include "../libgeda/prototype.h"


void
a_pan(TOPLEVEL *w_current, int x, int y)
{
	int pan_x, pan_y;
	int ix, iy, center_x, center_y;

	pan_x = mil_x(w_current, x);
	pan_y = mil_y(w_current, y);


	center_x = 
		(w_current->page_current->right - 
		 w_current->page_current->left)/2 + 
		w_current->page_current->left;

        center_y = 
		(w_current->page_current->bottom - 
	         w_current->page_current->top)/2 + 
		w_current->page_current->top;

        ix = center_x - pan_x;
        if ( w_current->page_current->right - ix > w_current->init_right ) {

            w_current->page_current->left = 
		w_current->init_right - 
		(w_current->page_current->right - 
		 w_current->page_current->left);

            w_current->page_current->right = 
		w_current->init_right;

        } else if (w_current->page_current->left - ix < w_current->init_left) {

            w_current->page_current->right = 
		w_current->init_left + 
		(w_current->page_current->right - 
		 w_current->page_current->left);

            w_current->page_current->left = w_current->init_left;

        } else {

            w_current->page_current->left=w_current->page_current->left - ix;
            w_current->page_current->right=w_current->page_current->right - ix;
        }                         	

	iy = center_y - pan_y;

        if ( w_current->page_current->bottom - iy > w_current->init_bottom ) {

            w_current->page_current->top = 
		w_current->init_bottom - 
		(w_current->page_current->bottom - 
		 w_current->page_current->top);

            w_current->page_current->bottom = w_current->init_bottom;

        } else if ( w_current->page_current->top - iy < w_current->init_top ) {

            w_current->page_current->bottom = 
		w_current->init_top + 
		(w_current->page_current->bottom - 
	 	 w_current->page_current->top);

            w_current->page_current->top = w_current->init_top;

        } else {

            w_current->page_current->top=w_current->page_current->top-iy;
            w_current->page_current->bottom=w_current->page_current->bottom-iy;
        }

	w_current->DONT_REDRAW=1;
	w_current->DONT_RECALC=1;
	w_current->DONT_RESIZE=1;
	x_hscrollbar_update(w_current);
	x_vscrollbar_update(w_current);
	o_redraw_all(w_current);
	w_current->DONT_REDRAW=0;
	w_current->DONT_RECALC=0;
	w_current->DONT_RESIZE=0;

#if DEBUG
/*	printf("left: %d, right: %d, top: %d, bottom: %d\n", 
			left, right, top, bottom); 
	printf("aspect: %f\n", (float) fabs(right - left) / (float) 
			fabs(bottom-top));
	printf("zoomfactor: %d\n", zoom_factor); */
#endif

}

