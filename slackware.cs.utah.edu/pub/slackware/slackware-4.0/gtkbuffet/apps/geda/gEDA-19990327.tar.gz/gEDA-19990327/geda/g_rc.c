/* gEDA - GNU Electronic Design Automation
 * geda - gEDA Program Manager
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h> 
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <sys/stat.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h> 
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"  

#include "prototype.h"
#include "../libgeda/prototype.h"

/* misc prototypes from libgeda */
int g_read_file(char *filename);
void s_log_message(const gchar *format, ...);


void
g_rc_parse(void)
{
	char *HOME;
	char filename[256]; /* hack */
	int found_rc=0;

	/* Let's try a the system one - GEDARCDIR/system-gedarc */
	sprintf(filename, "%s/system-gedarc", GEDARCDIR);
	if ( access(filename, R_OK) == 0 ) {
		g_read_file(filename);
		found_rc = 1;
		s_log_message("Read system-gedarc file [%s]\n", filename);
	} else {
		s_log_message("Did not find system-gedarc file [%s]\n", filename);
	}

	/* now search the proper rc location (in ~/.gEDA) */
	HOME = (char *)  getenv("HOME");
	if (HOME) {
		sprintf(filename, "%s/.gEDA/gedarc", HOME);
		if ( access(filename, R_OK) == 0) {
			g_read_file(filename);
			found_rc = 1;
			s_log_message("Read ~/.gEDA/gedarc file [%s]\n", filename);
		} else {
			s_log_message("Did not find ~/.gEDA/gedarc file [%s]\n", filename);
		}
	}

	/* try the local directory for a geda */ 
	sprintf(filename, "./gedarc");
	if ( access(filename, R_OK) == 0 ) {
		g_read_file(filename);
		found_rc = 1;
		s_log_message("Read local gedarc file [%s]\n", filename);
	} else {
		s_log_message("Did not find local gedarc file [%s]\n", filename);
	}

	/* Oh well I couldn't find any rcfile, exit! */

	if (!found_rc) {
		s_log_message("Could not find any gedarc files!\n");
		fprintf(stderr, "Could not find any gedarc files\n");
		exit(-1);
	}
}

SCM
g_rc_version(SCM version)
{        
	char *string;

        string = gh_scm2newstr(version, NULL);

        if ( strcmp(string, VERSION) != 0 ) {
                fprintf(stderr, "Found a version [%s] gedarc file\n",
                                        string);
                fprintf(stderr, "While geda is in ALPHA, please be sure that you have the latest rc file.\n");
        }

        if (string) {
                free(string);
        }

        return(gh_int2scm(0));
}


SCM
g_rc_projects_filename(SCM path)
{
	int ret;
	struct stat buf;
	char *string;

	string = gh_scm2newstr(path, NULL);

	/* take care of any shell variables */
	string = expand_env_variables(string);

	ret = stat(string, &buf);
	
	if (ret < 0) {
		fprintf(stderr, "Invalid path [%s] passed to projects-filename\n", string);
	} else {
		printf("%s\n", string);
#if 0

		if (S_ISDIR(buf.st_mode)) {
			if (project_current->font_directory)
				free(project_current->font_directory);

			project_current->font_directory = malloc(sizeof(char)*(
					strlen(string)+1));
			strcpy(project_current->font_directory, string);

		} else {
			if (string) free(string);
			return(gh_int2scm(-1)); 
		}
#endif
	}

	if (string) {
		free(string);
	}

	return(gh_int2scm(0)); 
}

SCM
g_rc_tool(SCM tool_name, SCM icon_name, SCM path_name, SCM params_name)
{
	char *tool;
	char *path;
	char *icon;
	char *params;

	tool = gh_scm2newstr(tool_name, NULL);
	icon = gh_scm2newstr(icon_name, NULL);
	path = gh_scm2newstr(path_name, NULL);
	params = gh_scm2newstr(params_name, NULL);

	t_add(tool, icon, path, params);

	return(gh_int2scm(0)); 
}

