/* gEDA - GNU Electronic Design Automation
 * gschcheck - GNU Schematic Check 
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h>
#include <signal.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "globals.h"
#include "defines.h"

#include "prototype.h"
#include "../libgeda/prototype.h"


int
s_check_all(TOPLEVEL *pr_current)
{
	PAGE *p_current;
	int return_status=0;

	p_current = pr_current->page_head;


	while(p_current != NULL) {
		if (p_current->pid != -1) {

			if (p_current->object_head) {
				return_status = return_status + 
					s_check_sheet(pr_current, p_current, 
						       p_current->object_head);
				if (verbose_mode) printf("\n");
			}

		}

		p_current = p_current->next;
	}

	return(return_status);
}

int
s_check_sheet(TOPLEVEL *pr_current, PAGE *p_current, OBJECT *object_head)
{
	OBJECT *o_current=NULL;
	SYMCHECK *s_schcheck=NULL;
	int errors=0;

	s_schcheck = s_schstruct_init();

	o_current = object_head;

	if (verbose_mode) {
		printf("Checking: %s\n", p_current->page_filename);
	}	

	/* this is where all the checks go 
	 * Look at:
	 * gsymcheck/s_symstruct.c, gsymcheck/s_check.c and the structure 
	 * in include/struct.h to see how things are setup */
	  

	/* basically this function performs the checks filling the SYMCHECK
	 * structure which is then printed/acted on by the following function:
	 */ 
	errors = s_schstruct_print(s_schcheck);

	s_schstruct_free(s_schcheck);
	return(errors);
}

