/* gEDA - GNU Electronic Design Automation
 * gschem - GNU Schematic Capture
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <gtk/gtk.h>

#include <guile/gh.h>

#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif


#include "struct.h"
#include "defines.h"
#include "globals.h"

#include "prototype.h"


void menus_init(GEDA *w_current);
void menus_create(GEDA *w_current, GtkMenuEntry * entries, int nmenu_entries);


    /* this is the GtkMenuEntry structure used to create new menus.  The
     * first member is the menu definition string.  The second, the
     * default accelerator key used to access this menu function with
     * the keyboard.  The third is the callback function to call when
     * this menu item is selected (by the accelerator key, or with the
     * mouse.) The last member is the data to pass to your callback function.
     */


/* no longer static */
/* but it can be static again */
GtkMenuEntry menu_items[] =
{
	{"<Main>/File/Quit", NULL, i_callback_file_quit, NULL}
};

/* calculate the number of menu_item's */
/* no longer static */
int nmenu_items = sizeof(menu_items) / sizeof(menu_items[0]);

void 
#if GTK_DEVEL
get_main_menu(GEDA *w_current, GtkWidget ** menubar, GtkAccelGroup ** accel)
#else
get_main_menu(GEDA *w_current, GtkWidget ** menubar, GtkAcceleratorTable ** table)
#endif
{
/* put this back in when you add the help button  
	GtkMenuPath *menu_path;
*/
	w_current->factory = NULL;	
	w_current->entry_ht = NULL;	

	menus_init(w_current);

        if (menubar)
                *menubar = w_current->subfactory[0]->widget;

#if GTK_DEVEL
        if (accel)
                *accel = w_current->subfactory[0]->accel_group;
#else
        if (table)
                *table = w_current->subfactory[0]->table;
#endif

/* to be added after you add the help hack 
	menu_path = gtk_menu_factory_find (w_current->factory, "<Main>/Help");
	gtk_menu_item_right_justify(GTK_MENU_ITEM(menu_path->widget));
*/
}

void 
menus_init(GEDA *w_current)
{
           
        w_current->factory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);

        w_current->subfactory[0] = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);
       	gtk_menu_factory_add_subfactory(w_current->factory, w_current->subfactory[0], "<Main>");

	w_current->subfactory[1] = gtk_menu_factory_new (GTK_MENU_FACTORY_MENU);
	gtk_menu_factory_add_subfactory (w_current->factory, w_current->subfactory[1], "<Popup>"); 

	/* menurc? hack */
	menus_create(w_current, menu_items, nmenu_items);
}

void 
menus_create(GEDA *w_current, GtkMenuEntry * entries, int nmenu_entries)
{
	char *accelerator;
        int i;
        
        if (w_current->entry_ht)
                for (i = 0; i < nmenu_entries; i++) {
                    accelerator = g_hash_table_lookup(w_current->entry_ht, entries[i].path);
			if (accelerator) {
				if (accelerator[0] == '\0')
                               		entries[i].accelerator = NULL;
                        	else
                                	entries[i].accelerator = accelerator;
                    	}
                }

        gtk_menu_factory_add_entries(w_current->factory, entries, nmenu_entries);
       
}
