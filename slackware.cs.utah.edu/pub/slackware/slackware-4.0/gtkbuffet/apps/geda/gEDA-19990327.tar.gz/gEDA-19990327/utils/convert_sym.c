/* convert_sym.c:
 *
 *  Convert a Viewlogic symbol/schematic to gEDA gschem format
 *
 *  accept one argument, the name of the file to 
 *  convert, converted output is displayed on stdout.
 *
 *     Copyright (C) 1999  Mike Jarabek
 *   
 *   This program is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License
 *   as published by the Free Software Foundation; either version 2
 *   of the License, or (at your option) any later version.
 *   
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *   
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * 	$Id: convert_sym.c,v 1.1 1999/03/26 05:01:51 geda Exp $	 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <config.h> /* added by AVH for integration into the gEDA tarball */

#if 0 /* removed by AVH just to make a -Wall -Werror happy */
#ifndef lint
static char vcid[] = "$Id: convert_sym.c,v 1.1 1999/03/26 05:01:51 geda Exp $";
#endif /* lint */
#endif

/* #define HAVE_SNPRINTF removed by AVH since config.h takes care of this now */

/* local defines */
#define MAX_TEXTLEN      1024
#define MAX_NODES         300

/* local function prototypes */
int convert_file(FILE *fp);
unsigned int strindex(char *s, char c);
unsigned int strrindex(char *s, char c);
void         strtolower(char *s);

/* conversion readers */
void do_bounding_box(char *buf);
void do_unnatached_attribute(char *buf, FILE *fp);
void do_attached_attribute(char *buf, FILE *fp);
void do_text(char *buf);
void do_line(char *buf, FILE *fp);
void do_pin(char *buf);
void do_box(char *buf);
void do_circle(char *buf);
void do_arc(char *buf);
void do_label(char *buf);
void do_net_start(void);
void do_net_node(void *buf);
void do_net_segment(char *buf);
void do_net_segment_bus(char *buf);
void do_instance(char *buf);

/* output objects */
void text_object(int x, int y, unsigned int color, unsigned int size,
		 unsigned int visibility, unsigned int show_name_value, 
		 int angle, char *text, unsigned int origin);
void attribute_object(int x, int y, unsigned int color, unsigned int  size,
		      unsigned int visibility, unsigned int show_name_value, 
		      int angle, char *name, char *value, unsigned int origin);
void line_object( int x1, int y1, int x2, int y2, unsigned int color);
void circle_object(int bx, int by, unsigned int radius, unsigned int bcolor);
void pin_object(int x1, int y1, int x2, int y2, unsigned int color);
void box_object(int x1, int y1, unsigned int width, unsigned int height,
		unsigned int color);
void arc_object(int x1, int y1, unsigned int radius, 
		int start_angle, int sweep_angle, unsigned int color);
void net_segment(int x1, int y1, int x2, int y2, unsigned int color);
void complex_object(int x, int y, unsigned int selectable, 
	       int angle, unsigned int mirror, char *name);
void begin_attach(void);
void end_attach(void);
void reset_attributes(void);



/* globals */
int attach_pending = 0;    /* keep track of whether the last object */
                           /* read may have attachments pending. */
int add_attributes = 0;    /* keep track of whether we are adding attributes */
			   /* to some previous object */
int pin_attributes = 0;    /* when true, we are adding attributes to a pin */
int net_attributes = 0;    /* when true, we are adding atrributes to a net */
int complex_attributes = 0;/* when true, we are adding attibutes to a complex*/
int pin_count      = 0;    /* to keep track of the number of pins */
int reading_net    = 0;    /* used to keep track of when we are reading a net*/
int segment_count  = 0;    /* the number of net segments read for a net */
int net_nodes_x[MAX_NODES];
int net_nodes_y[MAX_NODES];

int minx = 0;              /* bounding box for symbol */
int miny = 0;
int maxx = 0;
int maxy = 0;



int
main(int argc, char **argv)
{

  FILE *infile;
  char *infileName;

  if(argc != 2)
    {
      fprintf(stderr,"Usage:\n\t%s <viewlogic_filename>\n"
	      "Where:\n"
	      "\t<viewlogic_filename> is the name of the file you\n"
	      "\t  want to convert to gEDA format\n",argv[0]);
      return 1;
    }

  /* 'parse' arguments */
  infileName = argv[1];

  infile=fopen(infileName,"r");
  if(infile == NULL)
    {
      fprintf(stderr,"Error: Unable to open file `%s' in %s()\n",
	      infileName,__FUNCTION__);
      return 1;
    }

  convert_file(infile);

  fclose(infile);

  return 0;
}

/* convert the given file to geda */
int
convert_file(FILE *fp)
{
  char buf[MAX_TEXTLEN];

  /* output pre-amble */
  printf("v 19981025\n");
  reset_attributes();


  while(fgets(buf, MAX_TEXTLEN, fp) != NULL)/* loop over records in the file */
    {
      buf[strlen(buf)-1] = 0;  /* nuke trailing CR */
      switch(buf[0]) /* branch to appropriate handler */
	{
	case 'D': 
	  do_bounding_box(buf);
	  break;
	    
	case 'U':
	  do_unnatached_attribute(buf,fp);
	  break;

	case 'A':
	  do_attached_attribute(buf,fp);
	  break;

	case 'T':
	  do_text(buf);
	  break;

	case 'l':
	  do_line(buf, fp);
	  break;

	case 'P':
	  do_pin(buf);
	  break;

	case 'b':
	  do_box(buf);
	  break;

	case 'c':
	  do_circle(buf);
	  break;

	case 'a':
	  do_arc(buf);
	  break;

	case 'L':
	  do_label(buf);
	  break;

	  /* net stuff */
	case 'N':
	  do_net_start();
	  break;
	case 'J':
	  do_net_node(buf);
	  break;
	case 'S':
	  do_net_segment(buf);
	  break;
	case 'B':
	  do_net_segment_bus(buf);
	  break;
	
	case 'I':
	  do_instance(buf);
	  break;
	  /* ZZZZ */

	}
    }

  /* output post-amble */
  reset_attributes();


  return 0;
}

void
do_bounding_box(char *buf)
{
  /* just fetch the values and store */
  sscanf(buf,"D %d %d %d %d", &minx, &miny, &maxx, &maxy);

  minx *= 10;
  miny *= 10;
  maxx *= 10;
  maxy *= 10;
}


void
do_unnatached_attribute(char *buf, FILE *fp)
{
  int x,y,angle, textStart;
  unsigned int color, size, origin, viewvis;
  unsigned int visibility, show_name_value;
  char text[MAX_TEXTLEN];

  /* if we are inside of a pin definition, terminate */
  reset_attributes();

  /* for the moment just represent as text */
  
  /* viewlogic unnatached attributes have this format:
   * U #X #Y #SIZE #ROTATION #origin #Visibility ATTR_TEXT
   */
  sscanf(buf,"U %d %d %u %d %u %u %n", &x, &y, &size, &angle, &origin, 
	 &viewvis, &textStart); 

  x *= 10;   /* correct coordinates */
  y *= 10;

  color = 1;

  strncpy(text, &buf[textStart], MAX_TEXTLEN);  /* copy out the text */
  /* check for continuation chars */
  


  /* evaluate visibility for attributes */
  switch(viewvis)
    {
    case 0:   /* not at all visibile */
      visibility = 0;
      show_name_value = 0;
      break;

    case 1:   /* attribute and name visible */
      visibility = 1;
      show_name_value = 0;
      break;

    case 2:   /* only name visible */
      visibility = 2;
      show_name_value = 1;
      break;

    case 3:   /* only value visible */
      visibility = 1;
      show_name_value = 1;
      break;
      
    default:
      fprintf(stderr,"Error: Invalid visibility value %d in viewlogic file "
	      "in function %s()\n",viewvis,__FUNCTION__);
      return;
    }


  text_object( x, y, color, size, visibility, show_name_value, angle, text, \
	       origin);

}

void
do_attached_attribute(char *buf, FILE *fp)
{
  int x,y,angle, textStart;
  unsigned int color, size, origin, viewvis;
  unsigned int visibility, show_name_value;
  char text[MAX_TEXTLEN],text2[MAX_TEXTLEN];

  /* for the moment just represent as text */
  
  /* attached attributes have the following format:
   *    A #X #Y #SIZE #ROTATION #ORIGIN #VISIBILITY ATTR_TEXT
   */
  sscanf(buf,"A %d %d %u %d %u %u %n", &x, &y, &size, &angle, &origin, 
	 &viewvis, &textStart); 

  x *= 10;   /* correct coordinates */
  y *= 10;

  color = 1;

  strncpy(text, &buf[textStart], MAX_TEXTLEN);  /* copy out the text */

  /* evaluate visibility for attributes */
  switch(viewvis)
    {
    case 0:   /* not at all visibile */
      visibility = 0;
      show_name_value = 0;
      break;

    case 1:   /* attribute and name visible */
      visibility = 1;
      show_name_value = 0;
      break;

    case 2:   /* only name visible */
      visibility = 2;
      show_name_value = 1;
      break;

    case 3:   /* only value visible */
      visibility = 1;
      show_name_value = 1;
      break;
      
    default:
      fprintf(stderr,"Error: Invalid visibility value %d in viewlogic file "
	      "in function %s()\n",viewvis,__FUNCTION__);
      return;
    }

  begin_attach();
  if(pin_attributes) /* are we adding to a pin ? */
    {
      if(text[0] == '#')
	{
	  strncpy(text2, text, MAX_TEXTLEN);
#ifdef HAVE_SNPRINTF
	  snprintf(text, MAX_TEXTLEN, "pin%d=%s",pin_count,&text2[2]);
#else
	  sprintf(text, "pin%d=%s",pin_count,&text2[2]);
#endif
	  visibility = 1;         /* overide any previous settings */
	  show_name_value = 1;
	}
    }
  text_object( x, y, color, size, visibility, show_name_value, angle, text, \
	       origin);
}

void 
do_text(char *buf)
{
  int x,y,angle,textStart;
  unsigned int size, origin;
  unsigned int color,show_name_value;
  unsigned int visibility;
  char text[MAX_TEXTLEN];

  
  /* if we are inside of a pin definition, terminate */
  reset_attributes();

  /* viewlogic text have the following format:
   *  T #X #Y #SIZE #ROTATION #ORIGIN TEXT
   */
  sscanf(buf,"T %d %d %u %d %u %n",&x, &y, &size, &angle, 
	 &origin, &textStart);

  x *= 10;   /* correct coordinates */
  y *= 10;
  color = 3;
  visibility = 1;
  show_name_value = 0;
  strncpy(text, &buf[textStart], MAX_TEXTLEN);  /* copy out the text */

  text_object(x, y, color, size, visibility, show_name_value, angle, text, \
	      origin);

}

void
do_line(char *buf, FILE *fp)
{
  char *s;
  int x1,y1,x2,y2,pairStart;
  unsigned int pairs,color,i;
  

  /* if we are inside of a pin definition, terminate */
  reset_attributes();

      
  /* the viewlogic line primitive is composed of 
   *         l #PAIRS #X1 #Y1 #X2 #Y2 ...   - Line
   */

  sscanf(buf,"l %d %n",&pairs,&pairStart);

  color = 3;

  /* get initial two coordinates */
  s = strtok(&buf[pairStart]," ");
  x1 = atoi(s)*10;
  s = strtok(NULL," ");
  y1 = atoi(s)*10;

  /* represent this as a series of simple geda lines */
  for (i=0; i < (pairs-1); i++) 
    {
      s = strtok(NULL," ");
      if(s==NULL)           /* has it run onto the next line? */
	{
	  fgets(buf, MAX_TEXTLEN, fp);
	  s = strtok(buf," ");  /* and get the first one */
	}
	  
      x2 = atoi(s)*10;
      s = strtok(NULL," ");
      y2 = atoi(s)*10;
      line_object(x1,y1,x2,y2,color);

      /* shift new onto old */
      x1 = x2;
      y1 = y2;
    }
}


void 
do_pin(char *buf)
{
  unsigned int pindir, pinsense, color;
  unsigned int radius, radius2, bcolor;
  int x1, y1, x2, y2, bx, by;

  /* if we are inside of a pin definition, terminate */
  reset_attributes();
      
  /* viewlogic pin primitives have the following format:
   *  P #PININSTANCE #X1 #Y1 #X2 #Y2 # #PINDIRECTION #PINSENSE
   */

  sscanf(buf,"P %*d %d %d %d %d %*d %u %u",&x1, &y1, &x2, &y2, 
	 &pindir, &pinsense);

  x1 *= 10;
  y1 *= 10;
  x2 *= 10;
  y2 *= 10;
  color = 1;


  /* if this pin has to be of negative polarity, add a bitty bubble
   * and adjust the size of the pin
   */
  radius = 25;
  radius2 = 2*radius;
  bcolor = 6;
  
  if(pinsense == 1) {
    
    /* print "pindir:" pindir */
    /* get the bubble on the right end */

    /* one of the coordinates will match up with the bounding box
     * then just choose the other end for the bubble
     */

    if(x1 == minx)         /* left hand side of pin touches bounding box */
      {    
	bx = x2-radius;
	by = y2;
	x2 -= radius2;
      } 
    else if (x1 == maxx)   /* left end touches right side */
      { 
	bx = x2+radius;
	by = y2;
	x2 += radius2;
      }
    else if (x2 == minx)   /* right end touches left side */
      {
	bx = x1-radius;
	by = y1;
	x1 -= radius2;
      } 
    else if (x2 == maxx)   /* right end touches right side */
      {
	bx = x1+radius;
	by = y1;
	x1 += radius2;
      }
    else if (y1 == miny)   /* left end touches bottom */
      {
	bx = x2;
	by = y2-radius;
	y2 -= radius2;
      }
    else if (y1 == maxy)   /* left end touches top */
      {
	bx = x2;
	by = y2+radius;
	y2 += radius2;
      }
    else if (y2 == miny)   /* right end touches bottom */
      {
	bx = x1;
	by = y1-radius;
	y1 -= radius2;
      }
    else if (y2 == maxy)   /* right end touches top */
      {
	bx = x1;
	by = y1+radius;
	y1 += radius2;
      } 
    else
      {
	fprintf(stderr,"Error: Unable to determine pin sense in %s()\n"
		"\tBuffer:`%s'\n"
		"\tminx: %d, miny: %d, maxx: %d, maxy: %d\n",
		__FUNCTION__,buf, minx, miny, maxx, maxy);
	return;
      }

    circle_object(bx,by,radius,bcolor);
  }

  pin_object(x1,y1,x2,y2,color);


  add_attributes = 1;   /* add attributes */
  attach_pending = 1;   /* signal that an attachment could be coming */
  pin_attributes = 1;   /* and that they are pin attributes */
  pin_count++;          /* bump the number of pins */

}

void 
do_box(char *buf)
{
  int x1, y1, x2, y2, width, height;
  unsigned int color;

  
  /* if we are inside of a pin definition, terminate */
  reset_attributes();

  /* a viewlogic box has the following format:
   *  b #X1 #Y1 #X2 #Y2
   * geda view of a box has the corner, width and height
   */
  sscanf(buf, "b %d %d %d %d", &x1, &y1, &x2, &y2);

  x1 *= 10;
  y1 *= 10;
  x2 *= 10;
  y2 *= 10;

  width = x2-x1;
  height = y2-y1;
  color  = 3;

  box_object(x1,y1,width,height,color);
}

void
do_circle(char *buf)
{
  int x, y;
  unsigned int radius, color;

  /* if we are inside of a pin definition, terminate */
  reset_attributes();

  /* a circle has the following format:
   *  c #x #y #radius
   */
  sscanf(buf,"c %d %d %u",&x, &y, &radius);
  
  x *= 10;
  y *= 10;
  radius *=  10;
  color = 3;

  circle_object(x,y,radius,color);
}

void 
do_arc(char *buf)
{
  int x1, y1, x2, y2, x3, y3;
  unsigned int color;
  double x2p, y2p, x3p, y3p, yop, xop, xo, yo; 
  double to_rad;
  double gstart, sweep_angle, start_angle, end_angle;
  double radius;

  /* if we are inside of a pin definition, terminate */
  reset_attributes();

  /* arcs have the following format:
   *   a #X1 #Y1 #X2 #Y2 #X3 #Y3
   * we need to transform this into the geda convention of
   *   center, radius, start angle, stop angle.
   */

  sscanf(buf,"a %d %d %d %d %d %d", &x1, &y1, &x2, &y2, &x3, &y3);

  x1 *= 10;
  y1 *= 10;
  x2 *= 10;
  y2 *= 10;
  x3 *= 10;
  y3 *= 10;
  color = 3;

  x2p = x2 - x1;
  y2p = y2 - y1;

  x3p = x3 - x1;
  y3p = y3 - y1;

  /* printf("Buffer: `%s'\n",buf);
   * printf("Values: x2p: %f, y2p: %f, x3p: %f, y3p: %f\n",x2p, y2p, x3p, y3p);
   */
  if(fabs(x2p * y3p - y2p * x3p) < 0.00001)
    {
      /* some miscreant entered a degenerate arc, just output lines */
      line_object(x1,y1,x2,y2,color);
      line_object(x2,y2,x3,y3,color);
      return;
    }
      
  yop = ((x2p * ( x3p*x3p + y3p*y3p ) - x3p * ( x2p*x2p + y2p*y2p )) / 
	 (2 * (x2p * y3p - y2p * x3p)));

  xop = (x2p*x2p - 2*y2p*yop) / (2 * x2p);

  xo  = xop + x1;
  yo  = yop + y1;


  radius = sqrt(xop*xop + yop*yop);

  /* calculate start and end angles */
  to_rad = 180.0/atan2(0,-1);
  start_angle = atan2(y1-yo, x1-xo) * to_rad;
  end_angle = atan2(y3-yo, x3-xo) * to_rad;

  if(start_angle > end_angle)
    {
      gstart = end_angle;
      sweep_angle = start_angle - end_angle;
    } 
  else 
    {
      gstart = start_angle;
      sweep_angle = end_angle - start_angle;
    }

  /* end_angle   = 
   * end_angle   = int(atan2(y1-yo, x1-xo) * to_rad) % 360;
   * start_angle = int(atan2(y3-yo, x3-xo) * to_rad) % 360;
   */

  
  arc_object((int)xo,(int)yo, (unsigned int)radius,
	     (int)gstart,(int)sweep_angle, color);

}

void 
do_label(char *buf)
{
  int x, y, angle, textStart;
  unsigned int color, size, origin, visibility, show_name_value;
  char text[MAX_TEXTLEN];
  char text2[MAX_TEXTLEN];

  /* labels have the following format:
   *   L #X #Y #SIZE #ROTATION #ORIGIN #GLOBAL #VISIBILITY #OVERBAR TEXT
   */

  /* reproduce as simple text, unless it is a label for an object */

  sscanf(buf,"L %d %d %u %d %d %*d %*d %*d %n", 
	 &x, &y, &size, &angle, &origin, &textStart);


  x *= 10;
  y *= 10;
  color = 5;
  visibility = 1;
  show_name_value = 0;

  strncpy(text2, &buf[textStart], MAX_TEXTLEN);


  /* if we are inside a pin definition, mangle the pin name */
  if(net_attributes == 1) /* a label on a net is its netname */
    {
#ifdef HAVE_SNPRINTF
      snprintf(text, MAX_TEXTLEN, "net=%s", text2);
#else
      sprintf(text, "net=%s", text2);
#endif
      show_name_value = 1;
    }

  else if(complex_attributes == 1) /* a label on a complex is its designator */
    {
#ifdef HAVE_SNPRINTF
      snprintf(text, MAX_TEXTLEN, "uref=%s", text2);
#else
      sprintf(text, "uref=%s", text2);
#endif
      show_name_value = 1;
    }
  
  else
    strcpy(text,text2);     /* don't need to do anything, just copy */

  begin_attach();
  text_object(x, y, color, size, visibility, show_name_value, angle, text, \
	      origin);
}

/* four functions for doing net stuff */
void 
do_net_start(void)
{
  reset_attributes();

  reading_net = 1;
  segment_count = 0;
}

void 
do_net_node(void *buf)
{
  int x,y;

  /* in geda nets are composed of a number of segments, gschem connects
   * them together on the screen,  since viewlogic stores a net as a series
   * of nodes we need to tabulate them and only output segments when we
   * get connectivity information
   *
   * net segments have the following format:
   *  J #X #Y #SEGNUM  - Net segment
   */

  if(segment_count > MAX_NODES)
    {
      fprintf(stderr,"Error: too many nodes on a net in %s(), try increasing\n"
	      "\tMAX_NODES\n",__FUNCTION__);
      exit(1); /* this is fatal */
    }

  /* get the current info */
  sscanf(buf,"J %d %d",&x, &y);
  x *= 10;
  y *= 10;

  net_nodes_x[segment_count] = x;
  net_nodes_y[segment_count] = y;

  segment_count++;

}

void
do_net_segment(char *buf)
{
  unsigned int n1, n2, color;

  reset_attributes();

  /* net segment connectivity records have the following format:
   *  S #N1 #N2            - Net connectivity, Node N1 is connected to N2
   */

  sscanf(buf,"S %u %u",&n1, &n2);
  color = 4;

  /* output a geda net segment */
  net_segment(net_nodes_x[n1], net_nodes_y[n1], 
	      net_nodes_x[n2], net_nodes_y[n2], color);

  /* there could be attributes to follow */
  add_attributes = 1;   /* add attributes */
  attach_pending = 1;   /* signal that an attachment could be coming */
  net_attributes = 1;   /* and that they are net attributes */
}

void
do_net_segment_bus(char *buf)
{
  unsigned int n1, n2, color;

  reset_attributes();

  /* bus net segment connectivity records have the following format:
   *  B #N1 #N2            - Net connectivity, Node N1 is bussed to N2
   */

  sscanf(buf,"B %u %u",&n1, &n2);
  color = 4;

  /* output a geda net segment */ /* XXX should output a BUS segment here */
  net_segment(net_nodes_x[n1], net_nodes_y[n1], 
	      net_nodes_x[n2], net_nodes_y[n2], color);

  /* there could be attributes to follow */
  add_attributes = 1;   /* add attributes */
  attach_pending = 1;   /* signal that an attachment could be coming */
  net_attributes = 1;   /* and that they are net attributes */
}

void 
do_instance(char *buf)
{
  char lib[MAX_TEXTLEN], name[MAX_TEXTLEN], symName[MAX_TEXTLEN];
  unsigned int extension, selectable, mirror;
  int x, y, angle;

  reset_attributes();

  /* a component instance has the following format
   *  I #instance LIB:NAME #PAGE #X #Y #ROTATION #MAGNIFICATION  
   */

  sscanf(buf,"I %*d %s:%s %u %d %d", lib, name, &extension, &x, &y);

  x *= 10;
  y *= 10;
  selectable = 1;
  angle = 0;
  mirror = 0;   /* XXX need to add logic to decode rotation and mirror */

  /* fix case */
  strtolower(name);

  /* produce proper file name: */
#ifdef HAVE_SNPRINTF
  snprintf(symName, MAX_TEXTLEN, "%s.%d.sym",name,extension);
#else
  snprintf(symName, "%s.%d.sym",name,extension);
#endif

  complex_object(x, y, selectable, angle, mirror, symName);

  /* there could be attributes to follow */
  add_attributes = 1;     /* add attributes */
  attach_pending = 1;     /* signal that an attachment could be coming */
  complex_attributes = 1; /* and that they are complex attributes */

}

/* YYYY */

/* output a geda text object */
void
text_object(int x, int y, unsigned int color, unsigned int size,
	    unsigned int visibility, unsigned int show_name_value, 
	    int angle, char *text, unsigned int origin)
{
  unsigned int text_size;
  unsigned int textlen;

  /* fudge the text size, in viewdraw it is actually the height
   * in geda it is the point size
   */
  text_size = (int)(size * 0.72);

  /* emulate the viewdraw text origin by shifting the text around */
  
  /* if the origin is one of the ones that are along the center line,
   * adjust y
   */
  if ( (origin == 2) || (origin == 5) || (origin == 8) ) 
    {
      y -= (size*10) / 2;
    }

  if( (origin == 1) || (origin == 4) || (origin == 7) ) 
    {
      y -= size * 10;
    }

  /* approximate the length of the text */

  switch(show_name_value)
    {
    case 0:   /* measure whole text length */
      textlen = strlen(text);
      break;
  
    case 1:   /* measure just the value part */
      textlen = strlen(text) - strindex(text,'=') - 1;
      break;

    case 2:   /* measure just the name part */
      textlen = strindex(text,'=');
      break;
      
    default:
      fprintf(stderr,"Error: invalid show_name_value: %d in %s()\n",
	      show_name_value, __FUNCTION__);
      return;
    }

  /* fix text size */
  textlen = textlen * size * 10;

  /* if the origin is one of the middle ones
   * fix the x coordinate
   */
  if( (origin == 4) || (origin == 5) || (origin == 6) ) 
    {
      x -= textlen / 2;
    }

  if( (origin == 7) || (origin == 8) || (origin == 9) )
    {
      x -= textlen;
    }

  printf( "T %d %d %u %u %u %u %d\n%s\n", x, y, color, text_size, 
	  visibility, show_name_value, angle, text);

}


void
attribute_object(int x, int y, unsigned int color, unsigned int  size,
		 unsigned int visibility, unsigned int show_name_value, 
		 int angle, char *name, char *value, unsigned int origin) 
{

  char text[MAX_TEXTLEN];

  /* just add an = into the middle */
#ifdef HAVE_SNPRINTF
  snprintf(text, MAX_TEXTLEN, "%s=%s", name, value);
#else  
  sprintf(text, "%s=%s", name, value);
#endif

  text_object( x, y, color, size, visibility, show_name_value, \
	       angle, text, origin); 

}


void
line_object(int x1, int y1, int x2, int y2, unsigned int color)
{
  printf( "L %d %d %d %d %u\n",x1,y1,x2,y2,color);
}

void
circle_object(int bx, int by, unsigned int radius, unsigned int bcolor)
{  
  printf("V %d %d %u %u\n",bx,by,radius,bcolor);
}

void
pin_object(int x1, int y1, int x2, int y2, unsigned int color)
{
    printf("P %d %d %d %d %u\n",x1,y1,x2,y2,color);
}

void
box_object(int x1, int y1, unsigned int width, unsigned int height,
	   unsigned int color)
{
  printf("B %d %d %u %u %u\n",x1,y1,width,height,color);
}

void
arc_object(int x1, int y1, unsigned int radius, 
	   int start_angle, int sweep_angle, unsigned int color)
{
  printf("A %d %d %u %d %d %u\n",x1, y1, radius, 
	 start_angle, sweep_angle, color);
}

void
net_segment(int x1, int y1, int x2, int y2, unsigned int color )
{
  printf("N %d %d %d %d %u\n", x1, y1, x2, y2, color);
}

void
complex_object(int x, int y, unsigned int selectable, 
	       int angle, unsigned int mirror, char *name)
{
  printf("C %d %d %u %d %u %s\n", x, y, selectable, angle, mirror, name);
}


void
begin_attach(void)
{
  if(attach_pending == 1)  /* begin an attachment if one is pending*/
    {
      printf("{\n");
      attach_pending = 0;
    }
}

void
end_attach(void) 
{
  printf("}\n");
}

void
reset_attributes(void)
{

  /* if we are inside of some kind of attribute attachment
   * terminate it, but only if we output the begin_attach.
   */
  if((add_attributes == 1) && (attach_pending == 0))
    {
      end_attach();
    }

  attach_pending = 0;    /* keep track of whether the last object */
                         /* read may have attachments pending. */

  add_attributes = 0;    /* keep track of whether we are adding attributes */
			 /* to some previous object */
  pin_attributes = 0;    /* when true, we are adding attributes to a pin */
  net_attributes = 0;    /* when true, we are adding atrributes to a net */
  complex_attributes = 0;/* when true, we are addint attibutes to a complex */
}

/* return the index of character c in the string pointed to by s
 */
unsigned int
strindex(char *s, char c)
{
  char *p;
  unsigned int i;

  for(p=s, i=0; *p; p++,i++)
    if(*p == c)
      return i;

  return 0;
}

/* return the index of the last occurance of character c in 
 * the string pointed to by s
 */
unsigned int 
strrindex(char *s, char c)
{
  char *p;
  unsigned int i, loc;

  loc = 0;
  for(p=s, i=0; *p; p++, i++)
    if(*p == c)
      loc = i;

  return loc;
}

/* convert a string to lower case */
void
strtolower(char *s)
{
  char *p;

  for(p=s; *p; p++)
    *p = tolower(*p);

}
