/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h>
#include <math.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "pcb_struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"

#include "colors.h"

#include "footprint.h"
#include "list.h"

#include "prototype.h"
#include "../libgeda/prototype.h"

FOOTPRINT_T *
readFootprint(PAGE_T *page, char *filename) {
  FILE *fp;
  FOOTPRINT_T *newFoot = NULL;
  char inLine[132];

  fp = fopen(filename, "r");
  if (fp == NULL) {
    fprintf(stderr, "I couldn't find file %s\n", filename);
  }
  else {
    while (fgets(inLine, 132, fp) != NULL) {
      switch (inLine[0]) {
        case 'v':
        case 'V':
        break;

        case 'B':
          newFoot = footprint_add(page, inLine);
        break;

        case 'H':
          pad_add(newFoot, inLine);
        break;

        default:
          fprintf(stderr, "I don't understand this line in the footprint file:\n  %s\n", inLine);
        break;
      }
    }
    fclose(fp);
  }
  return newFoot;
}

void
writeComponents(FILE *fp, PAGE_T *page) {
  COMPONENT_T *comp;

  comp = page->components;
  while (comp != NULL) {
    fprintf(fp, "C %s %s ", comp->id, comp->footprint->id);
    fprintf(fp, "%d, %d\n", comp->x, comp->y);
    comp = comp->next;
  }
}

void
readComponent(char *str, PAGE_T *page) {
  FOOTPRINT_T *foot;
  char id[80];
  char footId[80];
  char filename[80];
  char pathNfile[132];
  char *tmp;
  char jnk;
  int x, y;

  sscanf(str, "%c %s %s %d, %d\n", &jnk, id, footId, &x, &y);

  foot = footprint_defined(page, footId);
  if (foot == NULL) {  /* Footprint hasn't been loaded yet */
    strcpy(filename, footId);
    strcat(filename, ".foot");
    tmp = s_clib_search(filename);
    if (tmp == NULL) {
      fprintf(stderr, "Footprint not found in component library.\n");
    }
    else {
      strcpy(pathNfile, tmp); /* Copy file path */
      strcat(pathNfile, "/"); /* divider */
      strcat(pathNfile, filename); /* and actual file name */
      foot = readFootprint(page, pathNfile);
    }
  }
  component_add(page, foot, id, x, y);
}

void
writeNets(FILE *fp, PAGE_T *page) {
  NET_T *net;

  net = page->nets;
  while (net != NULL) {
    if (net->src_comp == NULL) {
      printf("src_comp not set\n");
    }
    if (net->dst_comp == NULL) {
      printf("dst_comp not set\n");
    }
    if (net->src_comp->footprint == NULL) {
      printf("net->src_comp->footprint not set\n");
    }
    if (net->dst_comp->footprint == NULL) {
      printf("net->dst_comp->footprint not set\n");
    }
    if (net->src_comp->footprint->id == NULL) {
      printf("net->src_comp->footprint->id not set\n");
    }
    if (net->dst_comp->footprint->id == NULL) {
      printf("net->dst_comp->footprint->id not set\n");
    }
    if (net->src_pad == NULL) {
      printf("net->src_pad not set\n");
    }
    if (net->dst_pad == NULL) {
      printf("net->dst_pad not set\n");
    }
    if (net->src_pad->name == NULL) {
      printf("net->src_pad->name not set\n");
    }
    if (net->dst_pad->name == NULL) {
      printf("net->dst_pad->name not set\n");
    }
    fprintf(fp, "N %s %s to %s %s", net->src_comp->id, net->src_pad->name, 
      net->dst_comp->id, net->dst_pad->name);
    fprintf(fp, " %d,%d to %d,%d Routed:%d\n", net->src_x, net->src_y, net->dst_x, net->dst_y, net->routed);
    net = net->next;
  }
}

PAD_T *
findPad(FOOTPRINT_T *foot, PAD_NAME padId)
{
  PAD_T *pad;
  PAD_T *result = NULL;

  pad = foot->pads;
  while (pad != NULL) {
    if (!strcmp(pad->name, padId)) {
      result = pad;
      break;
    }
    pad = pad->next;
  }
  return result;
}

COMPONENT_T *
findComponent(PAGE_T *page, COMP_REF id)
{
  COMPONENT_T *comp;
  COMPONENT_T *result = NULL;

  comp = page->components;
  while (comp != NULL) {
    if (!strcmp(comp->id, id)) {
      result = comp;
      break;
    }
    comp = comp->next;
  }
  return result;
}

void
readNet(char *str, PAGE_T *page) {
  NET_T *net;
  COMPONENT_T *src_comp, *dst_comp;
  PAD_T *src_pad, *dst_pad;
  char srcId[10], dstId[10], srcPadStr[10], dstPadStr[10];
  int src_x, src_y, dst_x, dst_y;
  int routed;
  char jnk;

  sscanf(str, "%c %s %s to %s %s %d,%d to %d,%d Routed:%d\n", &jnk, srcId, srcPadStr, dstId, dstPadStr, &src_x, &src_y, &dst_x, &dst_y, &routed);

  net = new_net();

  net->src_x = src_x;
  net->src_y = src_y;
  net->dst_x = dst_x;
  net->dst_y = dst_y;

/* lookup pointers to source and destination components and pads */
  src_comp = findComponent(page, srcId);
  dst_comp = findComponent(page, dstId);
  net->src_comp = src_comp;
  net->dst_comp = dst_comp;
  net->routed = routed;

  if ((src_comp != NULL) && (dst_comp != NULL)) {
    src_pad = findPad(src_comp->footprint, srcPadStr);
    dst_pad = findPad(dst_comp->footprint, dstPadStr);
    net->src_pad = src_pad;
    net->dst_pad = dst_pad;
  }
  else {
    fprintf(stderr, "Couldn't find source or destination component\n");
  }
  net_add(page, net);
}

void
writeTracks(FILE *fp, PAGE_T *page) {
  TRACK_SEG_T *track;

  if (page->tracks != NULL) {
    track = page->tracks->track_segs;
    while (track != NULL) {
      fprintf(fp, "S %d,%d to %d,%d width:%d on layer:%d\n", track->src_x, track->src_y, track->dst_x, track->dst_y, track->width, track->layer);
      track = track->next;
    }
  }
}

void
readTrack(char *str, PAGE_T *page) {
  TRACK_SEG_T *track_seg;
  TRACK_T *track;
  int src_x, src_y, dst_x, dst_y, width, layer;
  char jnk;

  sscanf(str, "%c %d,%d to %d,%d width:%d on layer:%d\n", &jnk, &src_x, &src_y, &dst_x, &dst_y, &width, &layer);
  track_seg = new_track_seg();
  track_seg->src_x = src_x;
  track_seg->src_y = src_y;
  track_seg->dst_x = dst_x;
  track_seg->dst_y = dst_y;
  track_seg->width = width;
  track_seg->layer = layer;
/* add segment to tracks */
  
  if (page->tracks == NULL) {
    track = new_track();
    page->tracks = track;
    page->last_track = track;
  }

  track_seg->next = NULL;
  if (page->last_track->last_seg == NULL) {
    page->last_track->track_segs = track_seg;
    page->last_track->last_seg = track_seg;
  }
  else {
    page->last_track->last_seg->next = track_seg;
    page->last_track->last_seg = track_seg;
  }
}

void
file_open(PAGE_T *page, char *filename) {
  FILE *fp;
  char inLine[132];

  printf("Open file: %s\n", filename);
  fp = fopen(filename, "r");

  if (fp == NULL) {
    s_log_message("Unable to open page %s\n", filename);
    return;
  }

  while (fgets(inLine, 132, fp) != NULL) {
    switch (inLine[0]) {
      case 'C':
        readComponent(inLine, page);
      break;

      case 'N':
        readNet(inLine, page);
      break;

      case 'S':
        readTrack(inLine, page);
      break;

      default:
        fprintf(stderr, "I don't understand this line in the saved file:\n  %s\n", inLine);
      break;
    }
  }
    fclose(fp);

}

void
file_saveas(PAGE_T *page, char *filename) {
  FILE *fp;

  fp = fopen(filename, "w");

  if (fp == NULL) {
    s_log_message("Unable to save page as %s\n", filename);
    return;
  }

  writeComponents(fp, page);
  writeNets(fp, page);
  writeTracks(fp, page);
  fclose(fp);
}
