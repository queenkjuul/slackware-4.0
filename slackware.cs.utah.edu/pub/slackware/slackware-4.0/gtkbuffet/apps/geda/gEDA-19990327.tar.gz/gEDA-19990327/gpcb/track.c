/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <math.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"

#include "colors.h"

#include "pcb_struct.h"
#include "track.h"
#include "defaults.h"
#include "a_memory.h"
#include "list.h"
#include "net.h"

#include "prototype.h"
#include "../libgeda/prototype.h"

void
squareRoute(int src_x, int src_y, int *dst_x, int *dst_y)
{
  int diff_x, diff_y;

  diff_x = src_x - *dst_x;
  diff_y = src_y - *dst_y;

  if (diff_x < 0) 
    diff_x = -diff_x;
  if (diff_y < 0) 
    diff_y = -diff_y;
  if (diff_x < diff_y) { /* make it a vertical route */
    *dst_x = src_x;
  }
  else {  /* make it a horizontal route */
    *dst_y = src_y;
  }
}

void
endRoute(TOPLEVEL *w_current, int x, int y)
{
  w_current->current_page->routeTrack->net->routed = 1;
  track_add(w_current->current_page, w_current->current_page->routeTrack);
  free(w_current->current_page->routeNet); /* No longer need this temp net */
  w_current->current_page->routeNet = NULL;
  w_current->current_page->routeTrack = NULL;
  w_current->current_page->routeSeg = NULL;
}

void
continueRoute(TOPLEVEL *w_current, int x, int y)
{
  int m_x, m_y;
  TRACK_SEG_T *newSeg, *seg;

  SCREENtoWORLD(w_current, x, y, &m_x, &m_y);
  seg = w_current->current_page->routeSeg;

  squareRoute(seg->src_x, seg->src_y, &m_x, &m_y);
  seg->dst_x = m_x;
  seg->dst_y = m_y;
/* Set BBox */
  newSeg = new_track_seg();
  newSeg->src_x = seg->dst_x;
  newSeg->src_y = seg->dst_y;
  newSeg->dst_x = newSeg->src_x;
  newSeg->dst_y = newSeg->src_y;
  newSeg->width = seg->width;
  newSeg->layer = seg->layer;

  seg->next = newSeg;
  newSeg->next = NULL;
  w_current->current_page->routeSeg = newSeg;
}

void
route_start(TOPLEVEL *w_current, NET_T *net, int x, int y)
{
  TRACK_T *track;
  TRACK_SEG_T *seg;
  int m_x, m_y;

/* Erase original net */
  net_draw(w_current,net, DRAW_XOR);

  SCREENtoWORLD(w_current, x, y, &m_x, &m_y);

  track = new_track();
  track->net = net;
  w_current->current_page->routeTrack = track;
  w_current->current_page->routeNet = new_net();  /* This net is only used for drawing */

  seg = new_track_seg();
  track->track_segs = seg;
  track->last_seg = seg;

/* Setup coordinates for track segment */
  seg->src_x = net->src_x;
  seg->src_y = net->src_y;
  seg->width = 25;

/* Ensure routes only occur at right angles */
  squareRoute(seg->src_x, seg->src_y, &m_x, &m_y);

  seg->dst_x = m_x;
  seg->dst_y = m_y;

  w_current->current_page->routeNet->src_x = m_x;
  w_current->current_page->routeNet->src_y = m_y;

/* Setup coordinates for temporary drawing net */
  w_current->current_page->routeNet->dst_x = net->dst_x;
  w_current->current_page->routeNet->dst_y = net->dst_y;

  w_current->current_page->routeSeg = seg;

  seg_draw(w_current,seg, DRAW_XOR);
  net_draw(w_current,w_current->current_page->routeNet, DRAW_XOR);
}

void
route_rubberband(TOPLEVEL *w_current, int mouse_x, int mouse_y)
{
  TRACK_SEG_T *seg;
  NET_T *net;
  int m_x, m_y;

  seg = w_current->current_page->routeSeg;
  net = w_current->current_page->routeNet;
  SCREENtoWORLD(w_current, mouse_x, mouse_y, &m_x, &m_y);

  seg_draw(w_current,seg, DRAW_XOR);
  net_draw(w_current,net, DRAW_XOR);

/* Ensure routes only occur at right angles */
  squareRoute(seg->src_x, seg->src_y, &m_x, &m_y);
  seg->dst_x = m_x;
  seg->dst_y = m_y;
  net->src_x = m_x;
  net->src_y = m_y;
  seg_draw(w_current,seg, DRAW_XOR);
  net_draw(w_current,net, DRAW_XOR);
}

void
seg_draw(TOPLEVEL *w_current, TRACK_SEG_T *seg, drawing_type modifier)
{
  int src_x, src_y, dst_x, dst_y;

  WORLDtoSCREEN(w_current, seg->src_x, seg->src_y, &src_x, &src_y);
  WORLDtoSCREEN(w_current, seg->dst_x, seg->dst_y, &dst_x, &dst_y);


  if (modifier == DRAW_XOR) {
    gdk_gc_set_foreground(w_current->outline_xor_gc, layerToColor(seg->layer));
    gdk_gc_set_line_attributes(w_current->outline_xor_gc, scaleRadius(w_current, seg->width), GDK_LINE_SOLID, GDK_CAP_ROUND, GDK_JOIN_ROUND);
    gdk_draw_line(w_current->window, w_current->outline_xor_gc, src_x, src_y, dst_x, dst_y);
  }
  else {
    gdk_gc_set_foreground(w_current->gc, layerToColor(seg->layer));
    gdk_gc_set_line_attributes(w_current->gc, scaleRadius(w_current, seg->width), GDK_LINE_SOLID, GDK_CAP_ROUND, GDK_JOIN_ROUND);
    gdk_draw_line(w_current->window, w_current->gc, src_x, src_y, dst_x, dst_y);

  }

}

void
printSegment(TRACK_SEG_T *seg)
{
  printf("  Segment: %d,%d to %d,%d by %d on layer %d\n", seg->src_x, seg->src_y, seg->dst_x, seg->dst_y, seg->width, seg->layer);
}

void
printTrack(TRACK_T *track)
{
  TRACK_SEG_T *seg;

  printf("Track\n");
  seg = track->track_segs;
  while (seg != NULL) {
    printSegment(seg);
    seg = seg->next;
  }
}
