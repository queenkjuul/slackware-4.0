/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef O_BASIC_H
#define O_BASIC_H

#include <config.h>
#include <stdio.h>

/* instrumentation code */
#if 0
#include <sys/time.h>
#include <unistd.h>
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "a_memory.h"

#include "struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"
#include "x_states.h"
#include "colors.h"

#include "prototype.h"
#include "libgeda/prototype.h"

void
o_redraw_all(TOPLEVEL *w_current);

void
o_redraw(TOPLEVEL *w_current, OBJECT *object_list);

void
o_unselect_all(TOPLEVEL *w_current);

void
updateNetCoords(NET_T *net);

int
insideComponent(COMPONENT_T *comp, int x, int y);

int
onNet(NET_T *net, int x, int y);

int
insidePad(PAD_T *pad, int x, int y);

void
o_find(TOPLEVEL *w_current, int x, int y);

int
endNet(TOPLEVEL *w_current, NET_T *net, TRACK_SEG_T *seg, int x, int y);

NET_T *
find_net(TOPLEVEL *w_current, int x, int y);

COMPONENT_T *
find_component(TOPLEVEL *w_current, int x, int y);

PAD_T *
find_pad(TOPLEVEL *w_current, COMPONENT_T *comp, int x, int y);

OBJECT *
o_find_pad(TOPLEVEL *w_current, int x, int y);

void 
o_select(TOPLEVEL *w_current, OBJECT *selected);

void 
o_select_many(TOPLEVEL *w_current, OBJECT *selected, int count);

void
o_redraw_selected(TOPLEVEL *w_current);

void
o_unredraw_selected(TOPLEVEL *w_current);

void
o_erase_selected(TOPLEVEL *w_current);

void
o_erase_single(TOPLEVEL *w_current, OBJECT *object);

void 
o_unredraw_real(TOPLEVEL *w_current, OBJECT *list);

void
o_nets_translate(TOPLEVEL *w_current, int diff_x, int diff_y, OBJECT *o_current);

void
o_drawbounding(TOPLEVEL *w_current, OBJECT *o_current, GdkColor *color);

void
o_erasebounding(TOPLEVEL *w_current, OBJECT *o_current);

#endif
