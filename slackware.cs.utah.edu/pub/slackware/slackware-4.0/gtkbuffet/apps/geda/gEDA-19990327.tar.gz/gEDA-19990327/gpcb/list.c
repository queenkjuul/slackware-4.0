/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board layout
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#include <config.h>
#include <stdio.h>
#include <signal.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "o_types.h"
#include "struct.h"
#include "a_memory.h"
#include "component.h"
#include "pcb_struct.h"
#include "globals.h"
#include "defines.h"

#include "prototype.h"
#include "../libgeda/prototype.h"

FOOTPRINT_T *recent_footprint = NULL;

FOOTPRINT_T *
footprint_defined(PAGE_T *page, FOOTPRINT_ID id) {
	FOOTPRINT_T *c_foot;
	int cnt;

	cnt = strlen(id);
	cnt -= strlen(".foot");
	if (cnt >= 0) {
		if (!strcmp(&(id[cnt]), ".foot")) {
			id[cnt] = 0; /* Simple way to remove .foot from id */
		}
	}
	
	c_foot = page->footprints;
	while (c_foot != NULL) {
		if (!strcmp(c_foot->id, id)) {
			break;
		}
		c_foot = c_foot->next;
	}
	return c_foot;
}

void
component_add(PAGE_T *page, FOOTPRINT_T *foot, char *id, int x, int y)
{
  COMPONENT_T *new_comp;

  new_comp = new_component();

  new_comp->x = x;
  new_comp->y = y;

  new_comp->selected = FALSE;

  new_comp->id = malloc(strlen(id) + 1);
  strcpy(new_comp->id, id);

  if (foot == NULL) {
    fprintf(stderr, "Null footprint in component_add\n");
  }
  new_comp->footprint = foot;

  updateCompBB(new_comp);  /* Update the bounding box for this component */

  if (page->components == NULL) {
    page->components = new_comp;
    page->last_comp = new_comp;
  }
  else {
    page->last_comp->next = new_comp;
    page->last_comp = new_comp;
  }

}

void
o_component_add(PAGE_T *page, char *id, int x, int y)
{
	COMPONENT_T *new_comp;
	FOOTPRINT_T *oldFoot;

	new_comp = new_component();

	printf("Component %s created at %d, %d\n", id, x, y);
	new_comp->x = x;
	new_comp->y = y;

	new_comp->selected = FALSE;

	new_comp->id = malloc(strlen(id) + 1);
	strcpy(new_comp->id, id);

	oldFoot = footprint_defined(page, recent_footprint->id);

	if (oldFoot == NULL) {
		new_comp->footprint = recent_footprint; /* Ick, EWB */
	}
	else {
		new_comp->footprint = oldFoot;
	}

	updateCompBB(new_comp);  /* Update the bounding box for this component */

	if (page->components == NULL) {
		page->components = new_comp;
		page->last_comp = new_comp;
	}
	else {
		page->last_comp->next = new_comp;
		page->last_comp = new_comp;
	}
}

void 
o_selections_free(PAGE_T *page)
{
	SELECTION_T *current;
	SELECTION_T *next;

	current = page->selections;
	while (current != NULL) {
		next = current->next;
		free(current);
		current = next;
	}
	page->selections = NULL;
	page->last_selection = NULL;
}

void
o_selection_add(PAGE_T *page, SELECTION_T *selection)
{
        if (page->selections == NULL) {
                page->selections = selection;
                page->last_selection = selection;
        }
        else {
                page->last_selection->next = selection;
                page->last_selection = selection;
        }
}

FOOTPRINT_T *
footprint_add(PAGE_T *page, char *footDef)
{
  FOOTPRINT_T *new_foot;
  char jnk;
  int x, y, dx, dy, color;
  char name[80];

  new_foot = new_footprint();
  sscanf(footDef, "%c %d %d %d %d %d %s", &jnk, &x, &y, &dx, &dy, &color, name);

  new_foot->id = malloc(strlen(name));
  strcpy(new_foot->id, name);

  new_foot->box.x1 = x;
  new_foot->box.y1 = y + dy;
  new_foot->box.x2 = x + dx;
  new_foot->box.y2 = y;

  new_foot->bb.top = new_foot->box.y2;
  new_foot->bb.bottom = new_foot->box.y1;
  new_foot->bb.left = new_foot->box.x1;
  new_foot->bb.right = new_foot->box.x2;

/* Add footprint to list */
  if (page->footprints == NULL) {
    page->footprints = new_foot;
    page->last_foot = new_foot;
  }
  else {
    page->last_foot->next = new_foot;
    page->last_foot = new_foot;
  }
  return new_foot;
}

void
o_footprint_add(PAGE_T *page, OBJECT *object, int x, int y)
{
        FOOTPRINT_T *new_foot;

	if (footprint_defined(page, object->name) == NULL) {
	        new_foot = new_footprint();

		recent_footprint = new_foot;

		new_foot->id = malloc(strlen(object->name));
		strcpy(new_foot->id, object->name);

        	new_foot->box.x1 = object->line_points->x1 - x;
        	new_foot->box.y1 = object->line_points->y1 - y;
        	new_foot->box.x2 = object->line_points->x2 - x;
        	new_foot->box.y2 = object->line_points->y2 - y;

        	new_foot->bb.top = new_foot->box.y2;
        	new_foot->bb.bottom = new_foot->box.y1;
        	new_foot->bb.left = new_foot->box.x1;
        	new_foot->bb.right = new_foot->box.x2;

        	if (page->footprints == NULL) {
                	page->footprints = new_foot;
                	page->last_foot = new_foot;
        	}
        	else {
                	page->last_foot->next = new_foot;
                	page->last_foot = new_foot;
        	}
	}
	else {
/*		printf("Footprint already present\n"); */
	}
}

void
net_add(PAGE_T *page, NET_T *net)
{
        if (page->nets == NULL) {
                page->nets = net;
                page->last_net = net;
        }
        else {
                page->last_net->next = net;
                page->last_net = net;
        }
}

void
pad_add(FOOTPRINT_T *foot, char *padDef) {
  PAD_T *cur_pad;
  char pin[20];
  char jnk;
  int left, right, top, bottom;
  int x, y, radius, layer;

  cur_pad = new_pad();

/* Add pad types as they are supported */
  switch (padDef[0]) {
    case 'H':
      cur_pad->type = PAD_THRU_HOLE;
    break;

    default:
      cur_pad->type = PAD_NULL;
    break;
  }

  sscanf(padDef, "%c %d %d %d %d %s", &jnk, &x, &y, &radius, &layer, pin);
  cur_pad->name = malloc(strlen(pin) + 1);
  strcpy(cur_pad->name, pin);
  cur_pad->x = x;
  cur_pad->y = y;
  cur_pad->size = radius;

  if (foot->pads == NULL) {
    foot->pads = cur_pad;
    foot->last_pad = cur_pad;
  }
  else {
    foot->last_pad->next = cur_pad;
    foot->last_pad = cur_pad;
  }

/* Update bounding box of footprint */
  left = cur_pad->x - radius;
  right = cur_pad->x + radius;
  top = cur_pad->y + radius;
  bottom = cur_pad->y - radius;
  if (foot->bb.left > left) {
    foot->bb.left = left;
  }
  if (foot->bb.right < right) {
    foot->bb.right = right;
  }
  if (foot->bb.top < top) {
    foot->bb.top = top;
  }
  if (foot->bb.bottom > bottom) {
    foot->bb.bottom = bottom;
  }
}

void
track_add(PAGE_T *page, TRACK_T *newTrack)
{
  if (page->tracks == NULL) {
    page->tracks = newTrack;
    page->last_track = newTrack;
  }
  else {
    page->last_track->next = newTrack;
    page->last_track = newTrack;
  }
}
void
o_pad_add(PAGE_T *page, OBJECT *object, int x, int y)
{
	FOOTPRINT_T *foot;
        PAD_T *cur_pad;
	int radius;
	int left, right, top, bottom;

        cur_pad = new_pad();

/* Add pad types as they are supported */
	if (object->type == OBJ_THRU_HOLE) {
		cur_pad->type = PAD_THRU_HOLE;
	}
	else {
		cur_pad->type = PAD_NULL;
	}

	cur_pad->name = malloc(strlen(object->name) + 1);
	strcpy(cur_pad->name, object->name);

	radius = (object->line_points->x2 - object->line_points->x1) / 2;
        cur_pad->x = (object->line_points->x1 + radius) - x;
        cur_pad->y = (object->line_points->y1 - radius) - y;
        cur_pad->size = radius;

        if (page->last_foot == NULL) {
		fprintf(stderr, "Attempt to add pads to non-existant footprint\n");
        }
        else {
		foot = page->last_foot;
		if (foot->pads == NULL) {
			foot->pads = cur_pad;
			foot->last_pad = cur_pad;
		}
		else {
			foot->last_pad->next = cur_pad;
			foot->last_pad = cur_pad;
		}
		left = cur_pad->x - radius;
		right = cur_pad->x + radius;
		top = cur_pad->y + radius;
		bottom = cur_pad->y - radius;
		if (foot->bb.left > left) {
			foot->bb.left = left;
		}
		if (foot->bb.right < right) {
			foot->bb.right = right;
		}
		if (foot->bb.top < top) {
			foot->bb.top = top;
		}
		if (foot->bb.bottom > bottom) {
			foot->bb.bottom = bottom;
		}
        }
}

