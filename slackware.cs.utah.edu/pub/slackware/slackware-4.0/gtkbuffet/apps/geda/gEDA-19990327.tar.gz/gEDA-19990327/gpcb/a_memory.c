/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdlib.h>
#include <stdio.h>

#include "pcb_struct.h"

void out_of_memory() {
	exit(1);  /* This is obviously not a very friendly thing to do */
}

/* Allocate space for a new page structure and initialize it to sane values */
/* The page structure holds all the information about a single page. */
PAGE_T *new_page() {
	PAGE_T *page;

	page = (PAGE_T *)malloc(sizeof(PAGE_T));

	if (page == NULL) {
		fprintf(stderr, "Unable to allocate memory for new page\n");
		out_of_memory();
	}

	page->components = NULL;
	page->last_comp = NULL;
	page->nets = NULL;
	page->last_net = NULL;
	page->tracks = NULL;
	page->last_track = NULL;
	page->selections = NULL;
	page->last_selection = NULL;
	page->routeNet = NULL;

	return page;
}

SELECTION_T *new_selection() {
        SELECTION_T *selection;

        selection = (SELECTION_T *)malloc(sizeof(PAGE_T));

        if (selection == NULL) {
                fprintf(stderr, "Unable to allocate memory for new selection\n");
                out_of_memory();
        }

        selection->next = NULL;
        selection->object = NULL;

        return selection;
}

COMPONENT_T *new_component() {
        COMPONENT_T *component;

        component = (COMPONENT_T *)malloc(sizeof(COMPONENT_T));

        component->x = 0;
        component->y = 0;

        component->next = NULL;

        return component;
}

FOOTPRINT_T *new_footprint() {
	FOOTPRINT_T *footprint;

	footprint = (FOOTPRINT_T *)malloc(sizeof(FOOTPRINT_T));

	footprint->box.x1 = 0;
	footprint->box.y1 = 0;
	footprint->box.x2 = 0;
	footprint->box.y2 = 0;

	footprint->bb.top = 0;
	footprint->bb.left = 0;
	footprint->bb.right = 0;
	footprint->bb.bottom = 0;

	footprint->pads = NULL;
	footprint->next = NULL;

	return footprint;
}

TRACK_T *new_track() {
        TRACK_T *track;

        track = (TRACK_T *)malloc(sizeof(TRACK_T));

        if (track == NULL) {
                fprintf(stderr, "Unable to allocate memory for new track\n");
                out_of_memory();
        }

        track->track_segs = NULL;
        track->last_seg = NULL;
        track->net = NULL;
        track->next = NULL;

	track->bb.top = 0;
	track->bb.left = 0;
	track->bb.right = 0;
	track->bb.bottom = 0;

        return track;
}

TRACK_SEG_T *new_track_seg() {
        TRACK_SEG_T *track_seg;

        track_seg = (TRACK_SEG_T *)malloc(sizeof(TRACK_SEG_T));

        if (track_seg == NULL) {
                fprintf(stderr, "Unable to allocate memory for new track segment\n");
                out_of_memory();
        }

	track_seg->src_x = 0;
	track_seg->src_y = 0;
	track_seg->dst_x = 0;
	track_seg->dst_y = 0;

	track_seg->width = 0;

	track_seg->layer = LAYER_NONE;

        track_seg->bb.top = 0;
        track_seg->bb.left = 0;
        track_seg->bb.right = 0;
        track_seg->bb.bottom = 0;

        track_seg->next = NULL;

        return track_seg;
}

NET_T *new_net() {
	NET_T *net;

	net = (NET_T *)malloc(sizeof(NET_T));

	if (net == NULL) {
		fprintf(stderr, "Unable to allocate memory for new net\n");
		out_of_memory();
	}

	net->src_x = 0;
	net->src_y = 0;
	net->dst_x = 0;
	net->dst_y = 0;

	net->bb.top = 0;
	net->bb.left = 0;
	net->bb.right = 0;
	net->bb.bottom = 0;

	net->src_comp = NULL;
	net->dst_comp = NULL;

	net->src_pad = NULL;
	net->dst_pad = NULL;

	net->routed = 0;

	net->next = NULL;

        return net;
}

VIA_T *new_via() {
	VIA_T *via;

	via = (VIA_T *)malloc(sizeof(VIA_T));

	if (via == NULL) {
		fprintf(stderr, "Unable to allocate memory for new track\n");
		out_of_memory();
	}

	via->x = 0;
	via->y = 0;
	via->size = 0;

	via->bb.top = 0;
	via->bb.left = 0;
	via->bb.right = 0;
	via->bb.bottom = 0;

	return via;
}

PAD_T *new_pad() {
	PAD_T *pad;

	pad = (PAD_T *)malloc(sizeof(PAD_T));

	if (pad == NULL) {
		fprintf(stderr, "Unable to allocate memory for new pad\n");
		out_of_memory();
	}

	pad->type = PAD_NULL;

	pad->x = 0;
	pad->y = 0;
	pad->size = 0;

	pad->bb.top = 0;
	pad->bb.left = 0;
	pad->bb.right = 0;
	pad->bb.bottom = 0;

	return pad;
}

