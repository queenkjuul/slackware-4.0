/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <math.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"

#include "colors.h"

#include "pcb_struct.h"
#include "a_memory.h"
#include "footprint.h"

#include "prototype.h"
#include "../libgeda/prototype.h"

void 
updateCompBB(COMPONENT_T *comp)
{
	comp->bb.top = comp->y + comp->footprint->bb.top;
	comp->bb.bottom = comp->y + comp->footprint->bb.bottom;
	comp->bb.left = comp->x + comp->footprint->bb.left;
	comp->bb.right = comp->x + comp->footprint->bb.right;
}

void
component_rubberband(TOPLEVEL *w_current, int mouse_x, int mouse_y)
{
  int m_x, m_y;
  COMPONENT_T *comp;
  SCREENtoWORLD(w_current, mouse_x, mouse_y, &m_x, &m_y);

  comp = w_current->current_page->last_comp;

  o_footprint_draw(w_current, comp->footprint, comp->x, comp->y, DRAW_XOR);
  comp->x = m_x;
  comp->y = m_y;
  o_footprint_draw(w_current, comp->footprint, comp->x, comp->y, DRAW_XOR);
}

void
printComponent(COMPONENT_T *comp)
{
  printf("Component %s: at %d,%d", comp->id, comp->x, comp->y);
  printFootprint(comp->footprint);
  if (comp->selected) {
    printf(" is selected\n");
  }
  else {
    printf("\n");
  }
}
