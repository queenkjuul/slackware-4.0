/* gEDA - GNU Electronic Design Automation
 * gschem/gpcb - GNU Schematic Capture and Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"
#include "x_states.h"
#include "colors.h"

#include "prototype.h"
#include "../libgeda/prototype.h"


void
o_conn_draw_endpoint(TOPLEVEL *w_current, GdkGC *local_gc, int x, int y)
{
	int size;
	int x2size;
	int zoom_num;

	zoom_num = return_zoom_number(w_current->page_current->zoom_factor)+1;

	if (zoom_num <= 0) {
		zoom_num = 1;	
	}

	size = zoom_num;

	/* had +2 */
        /* size = (return_zoom_number(w_current->page_current->zoom_factor);*/
        x2size = 2*zoom_num;

	if (w_current->net_endpoint_mode == FILLEDBOX) {
		gdk_draw_rectangle(w_current->window, 
				local_gc, TRUE, x-size, y-size, 
				x2size, x2size);
		gdk_draw_rectangle(w_current->backingstore, 
				local_gc, TRUE, x-size, y-size, 
				x2size, x2size);
	} else if (w_current->net_endpoint_mode == EMPTYBOX) {

		gdk_draw_rectangle(w_current->window, 
				local_gc, FALSE, 
				x-size, y-size, x2size, x2size);
		gdk_draw_rectangle(w_current->backingstore, 
				local_gc, FALSE, 
				x-size, y-size, x2size, x2size);

	} else if (w_current->net_endpoint_mode == X) {

		gdk_draw_line(w_current->window, 
			local_gc, x-size, y-size, x+size, 
			y+size);
		gdk_draw_line(w_current->backingstore, 
			local_gc, x-size, y-size, x+size, 
			y+size);
		gdk_draw_line(w_current->window, 
				local_gc, x+size, y-size, 
				x-size, y+size);
		gdk_draw_line(w_current->backingstore, 
				local_gc, x+size, y-size, 
				x-size, y+size);

	} /* Else mode was set to NONE or garbage */
}

void
o_conn_draw_midpoint(TOPLEVEL *w_current, GdkGC *local_gc, int x, int y)
{
	int size;
	int zoom_num;

	zoom_num = return_zoom_number(w_current->page_current->zoom_factor);

#if DEBUG
	printf("zn %d\n", zoom_num);
#endif
	if (zoom_num <= 0) {
		zoom_num = 1;	
        	size = 3 * (zoom_num); 
	} else if (zoom_num == 1) {
		zoom_num = 2;	
        	size = 4; 
	} else {
        	size = 3 * (zoom_num); 
	}

#if DEBUG
	printf("size: %d\n", size);
#endif

	if (w_current->net_midpoint_mode == FILLED) {
		gdk_draw_arc(w_current->window, local_gc, 
			TRUE, x-size/2, y-size/2, 
			size, size, 0, FULL_CIRCLE);  	
		gdk_draw_arc(w_current->backingstore, 
			local_gc, TRUE, x-size/2, y-size/2, 
			size, size, 0, FULL_CIRCLE);  	
	} else if (w_current->net_midpoint_mode == EMPTY) {
		gdk_draw_arc(w_current->window, 
			local_gc, FALSE, x-size/2, y-size/2, 
			size, size, 0, FULL_CIRCLE);  	
		gdk_draw_arc(w_current->backingstore, 
			local_gc, FALSE, x-size/2, y-size/2, 
			size, size, 0, FULL_CIRCLE);  	
	} /* Else mode was set to NONE or garbage */
}

void
o_conn_draw(TOPLEVEL *w_current, OBJECT *head)
{
	OBJECT *o_current=NULL;

	o_current = head;
	
	while (o_current != NULL) {

		switch(o_current->type) {

			case(OBJ_NET):

			 /* reuse line's routine */
/*        		if (!o_line_visible(w_current, o_current->line_points)) { */
/*                		break; */
/*        		} */
	
				
		if (w_current->override_color != -1) {
                        gdk_gc_set_foreground(w_current->gc, 
				x_get_color(w_current->override_color));
                } else {
                        gdk_gc_set_foreground(w_current->gc, 
				x_get_color(w_current->net_endpoint_color));
                }   
                if (!(o_current->connected_to_1) &&
                        (o_current->connection_1 == CONNECTION_REGULAR) ){
                                o_conn_draw_endpoint(w_current,
					  w_current->gc,
                                          o_current->line_points->screen_x1,
                                          o_current->line_points->screen_y1);
                } else if ( (o_current->connected_to_1) &&
                        (o_current->connection_1 == CONNECTION_ROUND) ) {
                                o_conn_draw_midpoint(w_current,
					  w_current->gc,
                                          o_current->line_points->screen_x1,
                                          o_current->line_points->screen_y1);
                }                            

		
                if (!(o_current->connected_to_2) &&
                        (o_current->connection_2 == CONNECTION_REGULAR) ) {
                                o_conn_draw_endpoint(w_current,
	                                  w_current->gc,
                                          o_current->line_points->screen_x2,
                                          o_current->line_points->screen_y2);
                } else if ( (o_current->connected_to_2) &&
                        (o_current->connection_2 == CONNECTION_ROUND) ) {
                                o_conn_draw_midpoint(w_current,
					  w_current->gc,
                                          o_current->line_points->screen_x2,
                                          o_current->line_points->screen_y2);
                }
				break;

			/* I don't support drawing nets in complex objects */
		}
		o_current = o_current->next;
	}
}
