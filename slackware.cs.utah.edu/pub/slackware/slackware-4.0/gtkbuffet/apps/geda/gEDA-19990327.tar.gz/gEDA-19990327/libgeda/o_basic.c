/* Lots of Gross code... needs lots of cleanup */
/* mainly readability issues */

/* gEDA - GNU Electronic Design Automation
 * libgeda - gEDA's library
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h>

/* instrumentation code */
#if 0
#include <sys/time.h>
#include <unistd.h>
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>


#include "struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"
#include "x_states.h"
#include "colors.h"

#include "prototype.h"

int 
inside_region(int left, int top, int right, int bottom, int x, int y)
{
	return ((x >= left && x <= right && y >= top && y <= bottom) ? 1 : 0);
}

void
o_redraw_single(TOPLEVEL *w_current, OBJECT *o_current)
{
	if (o_current == NULL)
		return;
	
	if (w_current->DONT_REDRAW) /* highly experimental */
		return;

	if (o_current->draw_func != NULL && o_current->type != OBJ_HEAD) {
		w_current->inside_redraw = 1;
		(*o_current->draw_func)(w_current, o_current);
		w_current->inside_redraw = 0;
	}
}

