/* gEDA - GNU Electronic Design Automation
 * gpcb - GNU Printed Circuit Board
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <math.h>
#include <stdio.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "struct.h"
#include "defines.h"
#include "globals.h"
#include "s_passing.h"
#include "o_types.h"

#include "colors.h"

#include "pcb_struct.h"
#include "a_memory.h"
#include "defaults.h"
#include "component.h"
#include "track.h"
#include "net.h"
#include "pad.h"

#include "prototype.h"
#include "../libgeda/prototype.h"

void
o_footprint_move(TOPLEVEL *w_current)
{
  static int old_diff_x=0, old_diff_y=0;
  int diff_x, diff_y;
  int l_x, l_y, s_x, s_y;
  COMPONENT_T *comp;
  FOOTPRINT_T *foot;
  SELECTION_T *selection;

  SCREENtoWORLD(w_current, w_current->last_x, w_current->last_y, &l_x, &l_y);
  SCREENtoWORLD(w_current, w_current->start_x, w_current->start_y, &s_x, &s_y);
  
  diff_x = l_x - s_x;
  diff_y = l_y - s_y;
  if ((diff_x != old_diff_x) || (diff_y != old_diff_y)) {

    selection = w_current->current_page->selections;
    while (selection != NULL) {
      comp = selection->object;
      foot = comp->footprint;
      o_footprint_draw(w_current,foot,comp->x +old_diff_x, comp->y + old_diff_y, DRAW_XOR);
      o_footprint_draw(w_current,foot,comp->x +diff_x, comp->y + diff_y, DRAW_XOR);
      selection = selection->next;
    }
    old_diff_x = diff_x;
    old_diff_y = diff_y;
  }
}

void
o_footprint_draw(TOPLEVEL *w_current, FOOTPRINT_T *foot, int x, int y, drawing_type modifier)
{
/*	int wleft, wright, wtop, wbottom; Screen boundaries */
	PAD_T *pad;
	int s_x1, s_y1, s_x2, s_y2;  /* Screen coordinates */
	WORLDtoSCREEN(w_current, x+(foot->box.x1), y+(foot->box.y1), &s_x1, &s_y1);
	WORLDtoSCREEN(w_current, x+(foot->box.x2), y+(foot->box.y2), &s_x2, &s_y2);

	/* Find bounding box of viewable area */

	/* If not visible leave */

	if (modifier == DRAW_XOR) {
                gdk_gc_set_line_attributes(w_current->outline_xor_gc, 0, GDK_LINE_SOLID, GDK_CAP_NOT_LAST, GDK_JOIN_MITER);
		gdk_gc_set_foreground(w_current->outline_xor_gc,
			selectedColor(foot->outline_layer));
		gdk_draw_rectangle(w_current->window,
			w_current->outline_xor_gc, FALSE,
                        s_x1, s_y1, s_x2 - s_x1, s_y2 - s_y1);
	}
	else {
                gdk_gc_set_line_attributes(w_current->gc, 0, GDK_LINE_SOLID, GDK_CAP_NOT_LAST, GDK_JOIN_MITER);
		if (modifier == DRAW_CLEAR) {
			gdk_gc_set_foreground(w_current->gc,
				backgroundColor(w_current));

		}
		else if (modifier == DRAW_SELECTED) {
			gdk_gc_set_foreground(w_current->gc, 
				selectedColor(foot->outline_layer));
		}
		else {
			gdk_gc_set_foreground(w_current->gc, 
				layerToColor(foot->outline_layer));
		}
		gdk_draw_rectangle(w_current->window, 
			w_current->gc, FALSE, 
			s_x1, s_y1, s_x2 - s_x1, s_y2 - s_y1);
		gdk_draw_rectangle(w_current->backingstore, 
			w_current->gc, FALSE, 
			s_x1, s_y1, s_x2 - s_x1, s_y2 - s_y1);
	}

	pad = foot->pads;
	while (pad != NULL) {
		o_pad_draw(w_current, pad, x, y, modifier);
		pad = pad->next;
	}
}

void
printFootprint(FOOTPRINT_T *foot)
{
  printf("  %s", foot->id);
/*  printf("    Box: %d,%d to %d,%d\n", foot->box.x1, foot->box.y1, foot->box.x2, foot->box.y2); */
}

void
printPage(TOPLEVEL *w_current)
{
  COMPONENT_T *comp;
  FOOTPRINT_T *foot;
  TRACK_T *track;
  NET_T *net;

  comp = w_current->current_page->components;
  while (comp != NULL) {
    printComponent(comp);
    comp = comp->next;
  }
  printf("\n");

  foot = w_current->current_page->footprints;
  if (foot != NULL) {
    printf("Page contains the following footprints:\n");
  }
  while (foot != NULL) {
    printFootprint(foot);
    foot = foot->next;
  }
  printf("\n\n");

  net = w_current->current_page->nets;
  while (net != NULL) {
    printNet(net);
    net = net->next;
  }
  printf("\n");

  track = w_current->current_page->tracks;
  while (track != NULL) {
    printTrack(track);
    track = track->next;
  }
  printf("\n");
}
