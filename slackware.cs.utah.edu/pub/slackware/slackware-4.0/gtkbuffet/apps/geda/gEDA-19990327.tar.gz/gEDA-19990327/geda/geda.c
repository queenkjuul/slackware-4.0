/* gEDA - GNU Electronic Design Automation
 * geda - gEDA Program Manager
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h>
#include <signal.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>
#include "defines.h"
#include "globals.h"
#include "struct.h"

#include "prototype.h"
#include "libgeda/prototype.h"

/* misc prototypes from libgeda */
void s_log_init(char *filename);
void s_log_message(const gchar *format, ...);


void
geda_quit(void)
{

}

void 
main_prog(int argc, char *argv[])
{
	/* create log file right away */
	/* even if logging is enabled */
	s_log_init("geda.log");

	/* register guile (scheme) functions */
	g_register_funcs();

	g_rc_parse();

	gtk_init(&argc, &argv);

	s_log_message("gEDA: geda version %s - THIS IS AN ALPHA RELEASE!\n", VERSION);

	fprintf(stderr, "THIS IS AN ALPHA RELEASE! version %s\n", VERSION);

	x_window_create();


	fprintf(stderr, "This program doesn't do anything! (yet)\n");
	/* enter main loop */

	t_print(geda_head.tool_head);

#if 0
	printf("exec: %s\n", geda_head.tool_head->next->path);
	execvp(geda_head.tool_head->next->path, geda_head.tool_head->next->argv);
#endif

       	gtk_main();
}

int 
main (int argc, char *argv[])
{
  gh_enter (argc, argv, main_prog);
  return 0;
}
