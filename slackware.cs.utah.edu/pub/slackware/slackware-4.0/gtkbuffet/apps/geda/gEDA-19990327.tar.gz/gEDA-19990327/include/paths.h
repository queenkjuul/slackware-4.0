#define COMPONENT_LIBRARY 	"/home/ahvezda/projects/gEDA/lib/"
