/* gEDA - GNU Electronic Design Automation
 * libgeda - include files
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 */

#ifndef STRUCT_H
#define STRUCT_H

#include "pcb_struct.h"

/* gschem structures (gschem) */
typedef struct st_linepts LINEPTS;
typedef struct st_circle CIRCLE;
typedef struct st_attrib ATTRIB;
typedef struct st_object OBJECT;
typedef struct st_page PAGE;
typedef struct st_toplevel TOPLEVEL;

/* netlist structures (gnetlist) */
typedef struct st_netlist NETLIST;
typedef struct st_cpinlist CPINLIST;
typedef struct st_net NET;

/* sym check structures (gsymcheck) */
typedef struct st_symcheck SYMCHECK;

/* sch check structures (gsymcheck) */
typedef struct st_schcheck SCHCHECK;
 
/* gschem/gnetlist structure definitions */
struct st_linepts {
	int x1, y1;
	int snap_1;
	int x2, y2;
	int snap_2;
	int screen_x1, screen_y1;
	int screen_x2, screen_y2;
}; 

struct st_circle {
	int center_x, center_y;
	int radius;

	int screen_x, screen_y;
	int screen_left, screen_top;
	int screen_radius;

};


struct st_object {
	int type;				/* Basic information */
	int sid;
	char *name;

	int top;				/* Bounding box information */
	int left;				/* in screen coords */
	int right;
	int bottom;

	int selected;

	LINEPTS *line_points;		/* Describes a line */
	CIRCLE *circle;		/* Describes a line */

	/* net stuff */
	OBJECT *connected_to_1;	/* associated with x1, y1 */
	OBJECT *connected_to_2;	/* associated with x2, y2 */

	int connection_1;
	int connection_2;

	int visited;		/* used in gnetlist for travesal purposes */

	char *complex_basename;			/* Complex basename */
	char *complex_clib;			/* Complex Component Library */
	OBJECT *complex;		/* Complex pointer */
	OBJECT *complex_parent;		/* Complex parent object pointer */
					/* used only in complex head nodes */
	int x, y;		/* complex/text/arc origin */
				
	int screen_x, screen_y;	/* complex/text/arc screen origin */

	/* unused for now */
	void (*action_func)();			/* Execute function */
	void (*sel_func)();			/* Selected function */
	void (*draw_func)();			/* Draw function */

	int color; 				/* Which color */
	int saved_color; 			/* Saved color */
	
	int angle;				/* orientation, only multiples
					   	 * of 90 degrees allowed */   
						/* in degrees */
	int mirror;

	char *text_string;			/* text stuff */
	int text_size;
	int text_len;

        int snap_size;                          /* snap grid size */

	ATTRIB *attribs;		/* attribute stuff */
	ATTRIB *attached_to;	  /* when object is an attribute */
	int attribute;
	int show_name_value;
	int visibility; 

	OBJECT *prev;
	OBJECT *next;
}; 


struct st_attrib {
	OBJECT *object;	/* object attribute is connected to */
	
	OBJECT *copied_to; /* used when copying attributes */

	ATTRIB *prev;
	ATTRIB *next;
};


struct st_page {

	int pid;

	OBJECT *object_head;
	OBJECT *object_tail;
	OBJECT *object_parent;
	OBJECT *selection_head;
	OBJECT *selection_tail;
	OBJECT *complex_place_head;  /* used to place complex's and text */
	OBJECT *complex_place_tail; 
	OBJECT *attrib_place_head;
	OBJECT *attrib_place_tail; 
	OBJECT *object_lastplace;
	OBJECT *object_selected;

	char *page_filename; 
	int CHANGED;			/* changed flag */
	int zoom_factor;
	int left, right, top, bottom;		/* World coord limits */
	double coord_aspectratio;		/* Real worldcoords ratio (?) */
	int clist_row;				/* used in page manager */
						/* which row is the page in */

	PAGE *prev;
	PAGE *next;
};


struct st_toplevel {

	int wid;				/* Window id, always unique */

	int num_untitled;			/* keep track of untitled wins */
	
	int start_x;
	int start_y;
	int save_x;
	int save_y;
	int last_x;
	int last_y;
	int loc_x, loc_y;
	int distance;

	char *current_attribute;		/* used by attribute dialog */
						/* also used by text add 
						 * dialog 
						 */
	int current_visible;			/* in o_attrib.c */
	int current_show;
	/* have to decided on attribute list stuff */
	/* if it should go in here or not */
	/* leave outside for now */

	char *internal_basename;		
	char *internal_clib;     
	/* have to decided on component list stuff */
	/* if it should go in here or not */
	/* leave outside for now */


	char *series_name;			/* Current series basename */
	char *untitled_name;			/* untitled sch basename */
	char *font_directory; 			/* path of the vector fonts */
	char *scheme_directory; 		/* path of the scheme scripts */
	
	int event_state;			/* Current event state */

	int inside_action;			/* Are we doing an action? */

	int init_left, init_right; 		/* Starting values for above */
	int init_top, init_bottom; 

	int win_width, win_height;		/* Actual size of window (?) */
	int width, height;			/* height, width of window */
	int snap;				/* Snap on/off*/
	int grid;				/* Grid on/off*/
	int min_zoom;				/* minimum zoom factor */
	int max_zoom;				/* maximum zoom factor */
	int starting_width;			/* starting window width */
						/* used to control text */


	int override_color;			/* used in doing selections */
	int inside_redraw;			/* complex vs list redrawing */
	double window_aspectratio;		/* Window ratio (?) */
	int display_height;			/* display params */
	int display_width;			/* could me made global (?) */

	int DONT_DRAW_CONN;			/* misc flags */
	int DONT_RESIZE;
	int DONT_EXPOSE;
	int DONT_REDRAW;
	int DONT_RECALC;
	int FORCE_CONN_UPDATE;
	int ADDING_SEL;
	int REMOVING_SEL;

	int drawbounding_action_mode; 		/* outline vs bounding box */
	int last_drawb_mode;			/* last above mode */

	int CONTROLKEY;				/* control key pressed? */
	int SHIFTKEY;				/* shift key pressed? */

/* Page system used by gPCB */
	PAGE_T *current_page;

	/* page system */
	PAGE *page_head;	
	PAGE *page_tail;	
	PAGE *page_current;

	/* hierarchy system */

	void (*last_callback)();	  	/* Last i_call* cmd executed */
	char cwd[256]; /* size is hack */ 	/* current working directory */

	/* main window widgets */
	GtkWidget *main_window;
	GtkWidget *drawing_area;
	GtkWidget *popup_menu;
	GtkWidget *h_scrollbar;
	GtkWidget *v_scrollbar;    
	GtkObject *h_adjustment;
	GtkObject *v_adjustment;
	GtkWidget *left_button;
	GtkWidget *middle_button;
	GtkWidget *right_button;
	GtkWidget *filename_label;
	GtkWidget *status_label;

	
	GtkMenuFactory *factory;
	GtkMenuFactory *subfactory[2];
	GHashTable *entry_ht;

	/* Dialog boxes */
	GtkWidget *fowindow;			/* File open */
	GtkWidget *fswindow;			/* File save */
	GtkWidget *sowindow;			/* Script open */
	int saveas_flag;     			/* what action after save? */

	GtkWidget *aswindow;			/* Attribute select */
	GtkWidget *attr_list;
	GtkWidget *asentry_name;
	GtkWidget *asentry_value; 

	GtkWidget *cswindow;			/* component select */
	GtkWidget *clib_list;
	GtkWidget *basename_list;
	char current_clib[256]; /* hack */
	char current_basename[256]; 	

	GtkWidget *pwindow;			/* printing dialog box */
	GtkWidget *plib_list;			/* paper size box */
	GtkWidget *pfilename_entry; 

	GtkWidget *pswindow;			/* page select */
	GtkWidget *page_clist;
	int clist_sig;				/* used only in page manager */

	/* misc dialogs */
	GtkWidget *tiwindow;			/* text input */
	GtkWidget *tientry;
	GtkWidget *tewindow;			/* text edit */
	GtkWidget *teentry;
	GtkWidget *exwindow;			/* exit confirm */
	GtkWidget *aawindow;			/* arc attribs */
	GtkWidget *aaentry_start;
	GtkWidget *aaentry_sweep;  
	GtkWidget *trwindow;			/* translate */
	GtkWidget *trentry;
	GtkWidget *tswindow;			/* text size */
	GtkWidget *tsentry;			/* used in edit/edit and */
						/* Text size and the snap */
						/* size dialog boxes */
	
	GtkWidget *abwindow;			/* Help/About... dialog*/
	/* GtkWidget *preview; for the preview widget */

	/* this is the drawing_area's X drawable */
	GdkWindow *window; 
	
	/* graphics context stuff */
	GdkGC *gc;
	GdkGC *xor_gc;
	GdkGC *outline_xor_gc;
	GdkGC *bounding_xor_gc;

	/* backingstore pixmap */
	GdkPixmap *backingstore; 

	/* rc/user parameters */
	int graphic_color;
	int pin_color;
	int text_color;
	int text_caps;
	int attribute_color;
	int detachedattr_color;
	int text_size;
	int snap_size;		/* used by math funcs to the snapping */
	int grid_color;
	int background_color;
	int select_color;
	int bb_color;
	int net_endpoint_color;
	int net_color;
	int override_net_color;
	int override_pin_color;
	int pin_style;
	int net_style;
	int actionfeedback_mode; /* can be either OUTLINE or BOUNDINGBOX */
	int net_endpoint_mode; /* can be either NONE, FILLEDBOX, EMPTYBOX, X */
	int net_midpoint_mode; /* can be either NONE or FILLED or EMPTY */
	int object_clipping; /* controls whether objects are clipped */
	int embed_complex; /* controls if complex objects are embedded */
	int include_complex; /* controls if complex objects are included */
	int text_output; /* controls how text is printed (vector / PS font) */ 
	int scrollbars_flag; /* controls if scrollbars are displayed */ 
	int print_orientation; /* either landscape or portrait */
	int print_color; /* either TRUE or FALSE (color or no color) */
	int print_color_background; /* color used color ouput for background */ 
	int stroke_color; /* color of the stroke points */

	/* fixed init variables */
	int print_output_type;			/* either window or limits */


	/* landscape printing only */
	int paper_width, paper_height;

	TOPLEVEL *next;
	TOPLEVEL *prev; 
};


/* structures below are for gnetlist */

/* for every component in the object database */
struct st_netlist {

	int nlid;

	char *component_uref;
	
	OBJECT *object_ptr;
	
	CPINLIST *cpins;		

	NETLIST *prev;
	NETLIST *next;
};


/* for every pin on a component */
struct st_cpinlist {
        int plid;

	char *pin_number;

        char *net_name;			/* this is resolved at very end */

        NET *nets;
	int post_resolve_nets_needed; 	
					/* usually 0, but if there is a nets 
					 * which needs to be resolved, it will
					 * hold the sid of the connected net */

	int nets_is_copy;		/* TRUE when the nets pointer points
					 * to another duplicate net */

	CPINLIST *original;		/* if above is true, this hold the 
					 * cpinlist parent */

        CPINLIST *prev;
        CPINLIST *next;
};

/* the net run connected to a pin */
struct st_net {

        int nid;

        char *net_name;

        char *connected_to_1;
        char *connected_to_2;

	int net_is_duplicate;		/* normally 0, but if the net is 
					   described elsewhere this is true */
        NET *prev;
        NET *next;
};

struct st_symcheck {
        int graphical_symbol;
        int missing_device_attrib;
        char *device_attribute;
        int device_attribute_incorrect;
        int missing_pin_attrib;
        int missing_numslots_attrib;
        int unattached_attribs;
};

struct st_schcheck {
	int dummy;		/* just a variable */
};

#endif
