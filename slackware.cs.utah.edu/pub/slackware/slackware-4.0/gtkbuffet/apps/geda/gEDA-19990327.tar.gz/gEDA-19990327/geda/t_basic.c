/* gEDA - GNU Electronic Design Automation
 * geda - gEDA Program Manager
 * Copyright (C) 1998 Ales V. Hvezda
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <config.h>
#include <stdio.h> 
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <sys/stat.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h> 
#endif

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>

#include <guile/gh.h>

#include "defines.h"
#include "globals.h"  

#include "prototype.h"


#define DELIM " \r\n\t"

/* update object_tail or any list of that matter */
TOOL *
t_return_tool_tail(TOOL *head)
{
        TOOL *t_current=NULL;
        TOOL *ret_struct=NULL;

        t_current = head;
        while ( t_current != NULL ) { /* goto end of list */
                ret_struct = t_current;
                t_current = t_current->next;
        }

        return(ret_struct);
}

/* hack rename this to be s_return_head */
/* update object_tail or any list of that matter */
TOOL *
t_return_tool_head(TOOL *tail)
{
        TOOL *t_current=NULL;
        TOOL *ret_struct=NULL;

        t_current = tail;
        while ( t_current != NULL ) { /* goto end of list */
                ret_struct = t_current;
                t_current = t_current->prev;
        }

        return(ret_struct);
}

void
t_add(char *tool, char *icon, char *path, char *params) 
{
	char *string;
	TOOL *t_current; 
	TOOL *t_new; 
	int i;

	/* allocate head node if not already */
	if (geda_head.tool_head == NULL) {
		geda_head.tool_head = (TOOL *) malloc(sizeof(TOOL));
		geda_head.tool_head->tid = -1;
		geda_head.tool_head->tool = NULL;
		geda_head.tool_head->icon = NULL;
		geda_head.tool_head->path = NULL;
		geda_head.tool_head->argv[0] = NULL;
		geda_head.tool_head->prev = NULL;
		geda_head.tool_head->next = NULL;
	}		

	t_current = t_return_tool_tail(geda_head.tool_head); 

	t_new = (TOOL *) malloc(sizeof(TOOL));
	t_new->tool = tool;	
	t_new->icon = icon;	
	t_new->path = path;	
	

	t_new->argv[0] = (char *) malloc(sizeof(char)*(strlen(tool)+1));
	strcpy(t_new->argv[0], tool);

	string = strtok(params, DELIM);
	i = 1;
	while(string != NULL) {
		
		t_new->argv[i] = (char *) malloc(sizeof(char)*(strlen(string)+1));
		strcpy(t_new->argv[i], string);

		string = strtok(NULL, DELIM);
		i++;
		if (i == 50) {
			fprintf(stderr, "Too many arguments specified...\n");
			exit(-1);	
		}
	}

	t_new->argv[i] = NULL;

	t_current->next = t_new;	
	t_new->prev = t_current;
	t_new->next = NULL;
}

void
t_print(TOOL *list) 
{
	TOOL *t_current;
	int i;

	t_current = list;

	while(t_current != NULL) {
	
		if (t_current->tid != -1) {
			printf("name: %s\n", t_current->tool);
			printf("icon: %s\n", t_current->icon);
			printf("path: %s\n", t_current->path);
			printf("arguments: ");
			i=0;
			while(t_current->argv[i] != NULL) {
				printf("%s ", t_current->argv[i]);
	
				i++;
			}
			printf("\n");
		}	
		t_current = t_current->next;
	}
}

