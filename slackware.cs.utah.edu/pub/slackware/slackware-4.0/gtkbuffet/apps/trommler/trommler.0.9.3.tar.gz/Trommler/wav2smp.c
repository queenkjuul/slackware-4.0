
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef int INT32;
typedef short INT16;

#define TAG(a,b,c,d)  ((((((d<<8)+c)<<8)+b)<<8)+a)
/* ==================================================== */

void TuneSample(char *filename)
{
    char *ext;
    INT32 high,low;
    INT32 length;
    INT32 sum;
    INT32 i;
    INT32 *memory;
    INT16 *format;
    INT16 *data;
    FILE *fp;

    ext = strstr(filename,".wav");

    if( ext == 0 )
    {
        fprintf(stderr,"wave file %s must have .wav extension\n",filename);
        return;
    }
    
    fp = fopen(filename,"r");
    if( fp == 0 )
    {
        fprintf(stderr,"cannot open wave %s\n",filename);
        return;
    }

    fprintf(stderr,"loading sample wave %s\n",filename);
            
    fseek(fp,0,SEEK_END);
    length = ftell(fp);
    fseek(fp,0,SEEK_SET);
    memory = calloc(length,1);
    fread(memory,1,length,fp);
    fclose(fp);


    if( memory[0] != TAG('R','I','F','F') )
    {
        fprintf(stderr,"not an riff file\n");
        return;
    }


    if( memory[2] != TAG('W','A','V','E') )
    {
        fprintf(stderr,"not a wave file\n");
        return;
    }

    format = 0;
    for(i=0;i<length/4;i++)
    {
        if( memory[i] == TAG('f','m','t',' ') )
        {
            format = (INT16 *)&memory[i+2];
            break;
        }
    }
    
    if( format == 0)
    {
        fprintf(stderr,"could not find fmt chunk\n");
        return;
    }
    else
    {
        fprintf(stderr,"form: %d chann: %d  rate: %d  bpsec: %d algn: %d bits: %d\n",
                (INT32)format[0],
                (INT32)format[1],
                ((INT32*)format)[1],
                ((INT32*)format)[2],
                (INT32)format[6],
                (INT32)format[7]);
    }
    
    
    data = 0;
    for(i=0;i<length/4;i++)
    {
        if( memory[i] == TAG('d','a','t','a') )
        {
            data = (INT16 *) &memory[i+2];
            length = memory[i+1]/2;
            break;
        }
    }
    
    if( data == 0)
    {
        fprintf(stderr,"could not find data chunk\n");
        return;
    }
    else
    {
        fprintf(stderr,"file contains %d 16 bit samples\n",length);
    }
    
    
    
    sum = 0;
    for(i=15*length/16;i<length;i++)
    {
        sum += data[i];
    }

    high = 0;
    for(i=0;i<length;i++)
    {
        if( data[i] > high )
            high = data[i];
    }

    low = 0;
    for(i=0;i<length;i++)
    {
        if( data[i] < low )
            low = data[i];
    }
    
    sum /= length / 16;
    
    fprintf(stderr,"sum %d  high %d  low %d\n",sum,high,low);
    
    for(i=0;i<length;i++)
    {
        data[i]-= sum;
    }

    /*
    for(i=length-1;i>=0;i--)
    {
        if( data[i] > 20 || data[i] < -20 )
            break;
    }
    */
    

    ext[1] = 's';
    ext[2] = 'm';
    ext[3] = 'p';
    
    fp = fopen(filename,"w");
    if( fp == 0 )
    {
        fprintf(stderr,"cannot save sample %s\n",filename);
        return;
    }
    
    fprintf(stderr,"saving sample file %s\n",filename);
    fwrite(data,2,length,fp);
    fclose(fp);
    
    free(memory);
}


/* ==================================================== */

/* ==================================================== */ 
int main(int argc, char *argv[])
{
    if( argc == 1)
    {
        fprintf(stderr,"usage: wav2smp wave-file-1 wave-file-2 ...\n");
        return -1;
    }
    
    for(argc--,argv++; argc > 0; argc--,argv++)
    {
        TuneSample(*argv);
    }
    
    
    return 0;
}

/* ==================================================== */
/* ==================================================== */







