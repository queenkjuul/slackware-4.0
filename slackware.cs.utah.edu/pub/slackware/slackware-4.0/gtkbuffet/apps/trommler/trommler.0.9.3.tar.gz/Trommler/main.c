/*
 *  main.c 
 */   

#include "drum.h"
#include "export.h"

TYPE_GLOBAL Global;

int main(int argc, char *argv[])
{
    GLOBAL_SAMPLE_FREQUENCY = 44000;
    GLOBAL_SAMPLE_CHANNELS = 1;
    
    SongLoad("test.sng");
    SongSaveAsSample("test.smp");
}



