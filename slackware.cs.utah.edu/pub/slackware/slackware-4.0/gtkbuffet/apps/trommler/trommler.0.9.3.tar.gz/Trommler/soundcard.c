/*
    soundcard.c 

    Trommler version 0.9 - X11 Drum Machine
    Copyright (C) 1998 Robert Muth <muth@cs.arizona.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of June 1991.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program in form of the file COPYING; 
    if not, write to the 

    Free Software Foundation, Inc. <http://www.fsf.org>
    59 Temple Place, Suite 330, 
    Boston, MA 02111-1307  USA
*/

/*
Set sampling parameters always so that number of channels (mono/stereo) is set before selecting sampling
rate (speed). Failing to do this will make your program incompatible with SB Pro (44.1 kHz speed in mono but
just 22.05 kHz in stereo). Program which selects 44.1 kHz speed and then sets the device to stereo mode will
incorrectly believe that the device is still in 44.1 kHz mode (actually the speed is decreased to 22.05 kHz). 



AFMT_S16_LE is the standard 16 bit signed little endian (Intel) sample format used in PC soundcards.

ioctl(audio_fd, SNDCTL_DSP_RESET, 0) stops the device immediately and returns it to the state where it
                        can accept new parameters. 
Sampling rate is the parameter that determines much of the quality of an audio sample. OSS API permits selecting any frequency
between 1 Hz and 2 GHz. However in practice there are limits set by the audio device being used. The minimum frequency is
usually 5 kHz while the maximum frequency varies widely. Oldest sound cards supported at most 22.05 kHz (playback) or 11.025
kHz (recording). Next generation supported 44.1 kHz (mono) or 22.05 kHz (stereo). With modern sound devices the limit is 48
kHz (DAT quality) but there are still few popular cards that support just 44.1 kHz (audio CD quality).  

ioctl(audio_fd, SNDCTL_DSP_GETOPTR, &info);


These calls return information about recording and playback pointers (respectively). The count_info structure contains the
following fields:  
int bytes;  

Number of bytes processed since opening the device.
This field divided by the number of bytes/sample can be used as a precise timer.
However underruns, overruns and calls to some ioctl calls (SNDCTL_DSP_RESET,SNDCTL_DSP_POST and SNDCTL_DSP_SYNC)
decrease precision of the value. Also some operating systems don't
permit reading value of the actual DMA pointer so in these cases the value is truncated to previous fragment boundary.  

int blocks;  

Number of fragment transitions (hardware interrupts) processed since previous call to this ioctl (the value is reset to 0
after each call). This field is valid only when using direct access to audio buffer.  

int ptr;  

This field is a byte offset of current playback/recording position from the beginning of audio buffer. This field has little
value except when using direct access to audio buffer.  

*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/soundcard.h>
#include <sys/ioctl.h>
#include <fcntl.h>

struct
{
    int Dspfd;
    int Format;
    int Channels;
    int Rate;
    int BytesWritten;
}
Soundcard =
{
    -1,AFMT_S16_LE,1,44100,0    
};
    
extern void SoundcardWrite(char *buffer, int length )
{
    if( Soundcard.Dspfd < 0 )
    {
        fprintf(stderr,"Souncard (write) is not open\n");
        return;
    }

    write(Soundcard.Dspfd,buffer,length);
    Soundcard.BytesWritten += length;
}

extern int SoundcardUnplayedBytes()
{
    count_info ci;
    
    ioctl(Soundcard.Dspfd, SNDCTL_DSP_GETOPTR, &ci);

    return Soundcard.BytesWritten - ci.bytes;
}

extern int SoundcardBufferAvail()
{
    audio_buf_info abi;
    
    ioctl(Soundcard.Dspfd, SNDCTL_DSP_GETOSPACE, &abi);

    return abi.bytes;
}

extern int SoundcardBufferTotal()
{
    audio_buf_info abi;
    
    ioctl(Soundcard.Dspfd, SNDCTL_DSP_GETOSPACE, &abi);

    return abi.fragstotal * abi.fragsize;
}

extern int SoundcardUnprocessedBytes()
{
    count_info ci;
    
    ioctl(Soundcard.Dspfd, SNDCTL_DSP_GETOPTR, &ci);

    return Soundcard.BytesWritten - ci.bytes;
}

extern void  SoundcardClose()
{
    if( Soundcard.Dspfd < 0 )
    {
        fprintf(stderr,"Souncard (close) is not open\n");
        return;
    }
    
    close(Soundcard.Dspfd);
    Soundcard.Dspfd = -1;
}


extern void  SoundcardOpen()  
{
    int n;
    
    if( Soundcard.Dspfd >= 0 )
    {
        fprintf(stderr,"Souncard is open\n");
        close( Soundcard.Dspfd);
    }
    
    Soundcard.Dspfd = open ("/dev/dsp", O_WRONLY, 0);
    if( Soundcard.Dspfd < 0)
    {
        fprintf(stderr,"Cannot open souncard\n");
        return;
    }

    n = 0x0008000e;   /* choose 8 buffers with 2^14 bytes each */
    
    if( ioctl(Soundcard.Dspfd, SNDCTL_DSP_SETFRAGMENT, &n) )
    {
        fprintf(stderr,"Cannot set soundcard fragment\n");
        return;
    }

    

   /*
    *  Now this is tricky !!
    * information can e found here
    *
    * http://www.4front-tech.com/pguide/audio.html
    *
    * order
    * 1) format
    * 2) channels
    * 3) rate
    */

    Soundcard.BytesWritten = 0;
    
    if( ioctl(Soundcard.Dspfd, SNDCTL_DSP_SETFMT, &Soundcard.Format) )
    {
       fprintf(stderr,"Cannot set soundcard format\n");
       return;
    }

    printf("format: %d\n",Soundcard.Format);
    
    if( ioctl(Soundcard.Dspfd, SOUND_PCM_WRITE_CHANNELS, &Soundcard.Channels) )
    {
       fprintf(stderr,"Cannot set soundcard channels\n");
       return;
   }
    
    printf("channels: %d\n",Soundcard.Channels);
       
    if( ioctl(Soundcard.Dspfd, SOUND_PCM_WRITE_RATE, &Soundcard.Rate) )
    {
        fprintf(stderr,"Cannot set soundcard sample frequency\n");
        return;
    }    
}



#ifdef MAIN

int main(int argc,char *argv[])
{
    int i;

    SoundcardOpen();

    for(i=1;i<argc;i++)
    {
        FILE *fp;
        char *buffer;
        int length;

        fp = fopen(argv[i],"r");
        if( fp == 0)
        {
            fprintf(stderr,"cannot play %s\n",argv[i]);
            continue;
        }
        

        fseek(fp,0,SEEK_END);
        length= ftell(fp);
        fseek(fp,0,SEEK_SET);

        fprintf(stderr,"playing %s (%d)\n",argv[i],length);
        buffer = malloc(length);
        fread(buffer,1,length,fp);

        SoundcardWrite(buffer,length);
        free(buffer);
        fclose(fp);
    }

    SoundcardClose();
    
    return 0;


}


#endif









