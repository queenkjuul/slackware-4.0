/*
    drummer.h
    
    Trommler version 0.9 - X11 Drum Machine
    Copyright (C) 1998 Robert Muth <muth@cs.arizona.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of June 1991.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program in form of the file COPYING; 
    if not, write to the 

    Free Software Foundation, Inc. <http://www.fsf.org>
    59 Temple Place, Suite 330, 
    Boston, MA 02111-1307  USA
*/

#ifndef _DRUM_H
#define _DRUM_H

#define SAMPLE_FREQUENCY 44100
#define SAMPLE_CHANNELS 1

#define TIMER_MS_INTERVAL 50


#define MAX_DRUM_NUM 32
#define MAX_PATT_NUM 128
#define MAX_UNITS_NUM 8
#define MAX_BEATS_PER_UNIT_NUM 6
#define MAX_BEAT_NUM (MAX_UNITS_NUM * MAX_BEATS_PER_UNIT_NUM)
#define MAX_MEASURE_NUM 256
#define MAX_PATH_LEN 256
#define MAX_NAME_LEN 32
#define MAX_VOICE_NUM 32
#define MAX_UPM_NUM 512
#define MAX_DRUM_VOLUME 999
/* ==================================================== */

/* ==================================================== */

typedef signed short INT16;
typedef signed int   INT32;
typedef signed char  INT8;
typedef unsigned char  UINT8;
typedef char  CHAR;


/* ==================================================== */

/* ==================================================== */

typedef struct
{
    INT32  Length;
    INT16 *Sample;
    INT32 Volume;
}TYPE_VOICE;


/* ==================================================== */

/* ==================================================== */

typedef struct
{
    CHAR Name[MAX_NAME_LEN];
    CHAR Path[MAX_PATH_LEN];
    INT32 Volume;
    INT32 Key;
    INT32 Length;
    INT16 *Sample;
}TYPE_DRUM;

/* ==================================================== */

/* ==================================================== */

typedef struct
{
    INT32 Upms;
    CHAR  Path[MAX_PATH_LEN];
    CHAR  Name[MAX_NAME_LEN];
    INT32 Length;
    INT32 Measure[MAX_MEASURE_NUM];
}TYPE_SONG;

/* ==================================================== */

/* ==================================================== */

typedef struct
{
    INT16 Units;
    INT16 BeatsPerUnit;
    CHAR  Name[MAX_NAME_LEN];
    UINT8 Beat[MAX_DRUM_NUM][MAX_BEAT_NUM];
}TYPE_PATT;



/* ==================================================== */

/* ==================================================== */

typedef struct
{
    TYPE_DRUM Drum[MAX_DRUM_NUM];
    TYPE_SONG Song;
    TYPE_PATT Patt[MAX_PATT_NUM];
    TYPE_VOICE Voice[MAX_VOICE_NUM];
    INT8  FlagDebug;
    INT32 Buffer32[16*1024];
    INT16 Buffer16[16*1024];
}TYPE_GLOBAL;

/* ==================================================== */

/* ==================================================== */
extern TYPE_GLOBAL Global;

/* ==================================================== */



#define SONG_UPMS   Global.Song.Upms
#define SONG_NAME   Global.Song.Name
#define SONG_PATH   Global.Song.Path
#define SONG_LENGTH Global.Song.Length
#define SONG_MEASURE Global.Song.Measure

#define FOREACH_SONG_MEASURE(p) for(p=0;p<SONG_LENGTH;p++)
/* ==================================================== */

#define FOREACH_VOICE(v) for(v=0;v<MAX_VOICE_NUM;v++)

#define VOICE_LENGTH(v) Global.Voice[v].Length
#define VOICE_SAMPLE(v) Global.Voice[v].Sample
#define VOICE_VOLUME(v) Global.Voice[v].Volume

/* ==================================================== */

#define FOREACH_DRUM(d) for(d=0;d<MAX_DRUM_NUM;d++)

#define DRUM(d)        Global.Drum[d]
#define DRUM_SAMPLE(d) Global.Drum[d].Sample
#define DRUM_LENGTH(d) Global.Drum[d].Length
#define DRUM_PATH(d)   Global.Drum[d].Path
#define DRUM_NAME(d)   Global.Drum[d].Name
#define DRUM_VOLUME(d) Global.Drum[d].Volume
#define DRUM_KEY(d)    Global.Drum[d].Key

/* ==================================================== */

#define FOREACH_PATT(p) for(p=0;p<MAX_PATT_NUM;p++)
#define FOREACH_PATT_BEAT(p,b) for(b=0;b<PATT_BEATS(p);b++)

#define PATT_NAME(p)           Global.Patt[p].Name
#define PATT_UNITS(p)          Global.Patt[p].Units
#define PATT_BEATS_PER_UNIT(p) Global.Patt[p].BeatsPerUnit
#define PATT_BEATS(p)          (PATT_UNITS(p) * PATT_BEATS_PER_UNIT(p))
#define PATT_DRUM_BEAT(p,d,b)  Global.Patt[p].Beat[d][b]
/* ==================================================== */

#endif







