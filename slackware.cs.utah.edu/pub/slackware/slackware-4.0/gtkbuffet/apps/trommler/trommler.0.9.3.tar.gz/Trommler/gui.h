


#include <gtk/gtk.h>

#define TOPLEVEL_WIDTH 700
#define TOPLEVEL_HEIGHT 700
#define TOPLEVEL_TITLE "Trommler V0.9"


typedef struct
{
    GtkWidget *Toplevel;
    GtkWidget *Main;
    struct
    {
        GtkWidget *Menu;
        struct
        {
            GtkWidget *About;
            GtkWidget *Quit;
            GtkWidget *Loadsong;
            GtkWidget *Savesong;
            GtkWidget *Savesample;            
        }MENU;

        GtkWidget *Patt;
        struct
        {
            GtkWidget *Number;
            GtkWidget *Name;
            GtkWidget *Beats;
        }PATT;

        GtkWidget *Beatport;
        GtkWidget *Beat;
        struct
        {
            GtkWidget *Drum[MAX_DRUM_NUM];
                struct
                {
                    GtkWidget *Name;
                    GtkWidget *Beat[MAX_BEAT_NUM];                
                }DRUM[MAX_DRUM_NUM];
        }BEAT;
        
        GtkWidget *Song;
        struct
        {
            GtkWidget *Name;
            GtkWidget *Patts;
            GtkWidget *Bpms;
        }SONG;

        GtkWidget *Dummy;
        GtkWidget *Indexport;
        GtkWidget *Index;
        struct
        {
            GtkWidget *Pos[MAX_MEASURE_NUM];
            struct
            {
                GtkWidget *Label;
                GtkWidget *Patt;
            }POS[MAX_MEASURE_NUM];
        }INDEX;


        GtkWidget *Play;
        struct
        {
            GtkWidget *Playpatt;
            GtkWidget *Playsong;
            GtkWidget *Start;
            GtkWidget *Stop;
            GtkWidget *Playcurr;
        }PLAY;

    }MAIN;
    

        
#if 0
    GtkWidget *songPort;
    GtkWidget *songBox;
    GtkWidget *songPatt[MAX_SONG_LEN];
    GtkWidget *songNumber[MAX_SONG_LEN];
    GtkWidget *songEdit[MAX_SONG_LEN];
#endif
        


    struct
    {
        struct
        {
            GtkWidget *Popup;
            GtkWidget *Dialog;
        }ABOUT;

        
        struct
        {
            GtkWidget *Popup;
            GtkWidget *Dialog;
        }POSPATT;
        
        struct
        {
            GtkWidget *Popup;
            GtkWidget *Dialog;
        }PATTNAME;
        
        struct
        {
            GtkWidget *Popup;
            GtkWidget *Dialog;
        }SONGNAME;
        
        struct
        {
            GtkWidget *Popup;
            GtkWidget *Dialog;
        }DRUMNAME;

        struct
        {
            GtkWidget *Popup;
            GtkWidget *Dialog;
        }LOADSONG;

        struct
        {
            GtkWidget *Popup;
            GtkWidget *Dialog;
        }SAVESONG;

        struct
        {
            GtkWidget *Popup;
            GtkWidget *Dialog;
        }SAVESAMPLE;

        
    }DIALOG;
    
}
T_GUI_GLOBAL;

extern T_GUI_GLOBAL GUI;











