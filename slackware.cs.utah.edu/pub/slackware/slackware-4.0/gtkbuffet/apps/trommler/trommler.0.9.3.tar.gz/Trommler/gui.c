/*
    gui.c
    
    Trommler version 0.9 - X11 Drum Machine
    Copyright (C) 1998 Robert Muth <muth@cs.arizona.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of June 1991.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program in form of the file COPYING; 
    if not, write to the 

    Free Software Foundation, Inc. <http://www.fsf.org>
    59 Temple Place, Suite 330, 
    Boston, MA 02111-1307  USA
*/

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "drummer.h"
#include "version.h"
#include "export.h"

#undef DEBUG

/* ==================================================== */
/* ==================================================== */

#define PLAY_NONE    0
#define PLAY_PATTERN 1
#define PLAY_RANGE   2
#define PLAY_SONG    3

/* ==================================================== */
/* ==================================================== */

static struct
{
    int StartMeasure;
    int StopMeasure;
    int Pattern;
    

  
    int PlayMode;
    int PlayPattern;    
    int PlayBeat;
    int PlayMeasure;
    guint32 PlayInterval;
    guint32 PlayLength;
}
GuiCurrent;

/* ==================================================== */
/* ==================================================== */

struct
{
    GtkStyle *ButtonEven;
    GtkStyle *ButtonOdd;
    
    GtkTooltips *Tooltips;

    GtkWidget *Toplevel;
    
    GtkWidget *PatternNumber;
    GtkWidget *PatternName;
    GtkWidget *PatternCopy;
    GtkWidget *PatternSource;
    GtkWidget *PatternUnits;
    GtkWidget *PatternBeatsPerUnit;

    GtkWidget *DrumContainer;
    GtkWidget *DrumName[MAX_DRUM_NUM];
    GtkWidget *DrumVolume[MAX_DRUM_NUM];
    GtkWidget *DrumBeat[MAX_DRUM_NUM][MAX_BEAT_NUM];                

    GtkWidget *SongFile;
    GtkWidget *SongName;
    GtkWidget *SongMeasures;
    GtkWidget *SongBpms;

    
    GtkWidget *SongMeasureBox[MAX_MEASURE_NUM];
    GtkWidget *SongMeasurePattern[MAX_MEASURE_NUM];
    GtkWidget *SongRangeStart;
    GtkWidget *SongRangeStop;

    GtkWidget *PlayDisplay;
}GuiWidgets;


/* ==================================================== */
/* ==================================================== */
/* ==================================================== */
/* ==================================================== */

static void SetPlay()
{
    char buffer[64];
    sprintf(buffer,"%03d:%03d:%03d",
            GuiCurrent.PlayMeasure,
            GuiCurrent.PlayPattern,
            GuiCurrent.PlayBeat);
    
    gtk_label_set(GTK_LABEL(GuiWidgets.PlayDisplay),buffer);
}
/* ==================================================== */
/* ==================================================== */

static void SetDrumVolume(int drum)
{
    gtk_spin_button_set_value( GTK_SPIN_BUTTON(GuiWidgets.DrumVolume[drum]),(gfloat)DRUM_VOLUME(drum));
}

/* ==================================================== */
/* ==================================================== */

static void SetDrumName(int drum)
{
    gtk_entry_set_text(GTK_ENTRY(GuiWidgets.DrumName[drum]),DRUM_NAME(drum));
}

/* ==================================================== */
/* ==================================================== */

static void SetDrums()
{
    int i;
    for(i=0;i<MAX_DRUM_NUM;i++)
    {
        SetDrumName(i);
        SetDrumVolume(i);
    }
}

/* ==================================================== */
/* ==================================================== */

static void SetPatternLength(void)
{
    
    int i,j;
    int pattern =  GuiCurrent.Pattern;

    gtk_spin_button_set_value( GTK_SPIN_BUTTON(GuiWidgets.PatternBeatsPerUnit),(gfloat) PATT_BEATS_PER_UNIT(pattern));
    gtk_spin_button_set_value( GTK_SPIN_BUTTON(GuiWidgets.PatternUnits),(gfloat) PATT_UNITS(pattern));
    
    for(j=0;j<MAX_BEAT_NUM;j++)
    for(i=0;i<MAX_DRUM_NUM;i++)
    {
        GtkWidget *widget = GuiWidgets.DrumBeat[i][j];

        if( (j / PATT_BEATS_PER_UNIT(pattern)) & 1 )
            gtk_widget_set_style(widget,GuiWidgets.ButtonOdd);
        else
            gtk_widget_set_style(widget,GuiWidgets.ButtonEven);

#if 1                
        if( PATT_DRUM_BEAT(pattern,i,j) )
        {
            gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(widget),1);
            if( GTK_TOGGLE_BUTTON(widget)->active==0 )
                printf("BAD BUTTON BEHAVIOUR\n");
        }
        else
        {
            gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(widget),0);
            if( GTK_TOGGLE_BUTTON(widget)->active!=0 )
                printf("BAD BUTTON BEHAVIOUR\n");
        }
#endif
        
#if 0
        if( j < PATT_BEATS(pattern) )
            gtk_widget_set_sensitive(widget,1);
        else
            gtk_widget_set_sensitive(widget,0);
#else
        if( j < PATT_BEATS(pattern) )
            gtk_widget_show(widget);
        else
            gtk_widget_hide(widget);
#endif
    }


}

/* ==================================================== */
/* ==================================================== */

static void SetPatternNumber()
{
    gtk_spin_button_set_value( GTK_SPIN_BUTTON(GuiWidgets.PatternNumber),(gfloat)GuiCurrent.Pattern);
}

/* ==================================================== */
/* ==================================================== */

static void SetPatternName()
{
    gtk_entry_set_text(GTK_ENTRY(GuiWidgets.PatternName),PATT_NAME(GuiCurrent.Pattern));
}

/* ==================================================== */
/* ==================================================== */

static void SetPattern()
{
    SetPatternName();
    SetPatternNumber();
    SetPatternLength();    
}

/* ==================================================== */
/* ==================================================== */

static void SetSongLength()
{
    int i;

    gtk_spin_button_set_value( GTK_SPIN_BUTTON(GuiWidgets.SongMeasures),(gfloat)SONG_LENGTH);
    
    for(i=0;i<MAX_MEASURE_NUM;i++)
    {
        if( i < SONG_LENGTH )
            gtk_widget_show(GuiWidgets.SongMeasureBox[i]);
        else
            gtk_widget_hide(GuiWidgets.SongMeasureBox[i]);
    }
}

/* ==================================================== */
/* ==================================================== */

static void SetSongName()
{
    gtk_entry_set_text(GTK_ENTRY(GuiWidgets.SongName),SONG_NAME);
}

/* ==================================================== */
/* ==================================================== */

static void SetSongBpms()
{
    gtk_spin_button_set_value( GTK_SPIN_BUTTON(GuiWidgets.SongBpms),(gfloat)SONG_UPMS);
}

/* ==================================================== */
/* ==================================================== */

static void SetSongMeasure(pos)
{
    gchar buffer[16];

    sprintf(buffer,"%3d",SONG_MEASURE[pos]);
    gtk_entry_set_text(GTK_ENTRY(GuiWidgets.SongMeasurePattern[pos]),buffer);
}
/* ==================================================== */
/* ==================================================== */

static void SetSong()
{
    int i;
    
    for(i=0;i<MAX_MEASURE_NUM;i++)
        SetSongMeasure(i);
    SetSongLength();
    SetSongBpms();
    SetSongName();
    GuiCurrent.Pattern = 0;
    SetPattern();
    SetDrums();
    
    /* SetPlaycurr(); */
}

/* ==================================================== */
/* ==================================================== */
/* ==================================================== */
/* ==================================================== */
static int ActionPlayNothing()
{
    GuiCurrent.PlayMode = PLAY_NONE;
    return TRUE;
}
/* ==================================================== */
/* ==================================================== */
static int ActionPlayPattern()
{
    GuiCurrent.PlayMode = PLAY_PATTERN;
    return TRUE;
}
/* ==================================================== */
/* ==================================================== */
static int ActionPlayRange()
{
    GuiCurrent.PlayMode = PLAY_RANGE;
    
    return TRUE;
}
/* ==================================================== */
/* ==================================================== */
static int ActionPlaySong()
{
    GuiCurrent.PlayMode = PLAY_SONG;
    return TRUE;
}
/* ==================================================== */
/* ==================================================== */
static int ActionCopyPattern()
{
    GtkAdjustment *adjustment = gtk_spin_button_get_adjustment( GTK_SPIN_BUTTON(GuiWidgets.PatternSource));

    PattCopy(GuiCurrent.Pattern,(int)adjustment->value);
    SetPattern();
    return TRUE;
}
/* ==================================================== */
/* ==================================================== */
static int ActionBeatsRotateRight(GtkWidget *w)
{
    int drum;
    int beat;
    int pattern = GuiCurrent.Pattern;
    int tmp;
    
    for(drum=0;drum<MAX_DRUM_NUM;drum++)
    {
        tmp = PATT_DRUM_BEAT(pattern,drum,PATT_BEATS(pattern)-1);
        for(beat = PATT_BEATS(pattern)-1;beat > 0;beat--)
            PATT_DRUM_BEAT(pattern,drum,beat)=PATT_DRUM_BEAT(pattern,drum,beat-1);
        PATT_DRUM_BEAT(pattern,drum,0) = tmp;
    }
    
    SetPattern();
    return TRUE;
}
/* ==================================================== */
/* ==================================================== */
static int ActionBeatsRotateLeft(GtkWidget *w)
{
    int drum;
    int beat;
    int pattern = GuiCurrent.Pattern;
    int tmp;
    
    for(drum=0;drum<MAX_DRUM_NUM;drum++)
    {
        tmp = PATT_DRUM_BEAT(pattern,drum,0);
        for(beat = 0;beat < PATT_BEATS(pattern)-1;beat++)
            PATT_DRUM_BEAT(pattern,drum,beat)=PATT_DRUM_BEAT(pattern,drum,beat+1);
        PATT_DRUM_BEAT(pattern,drum,PATT_BEATS(pattern)-1) = tmp;
    }
    
    SetPattern();
    return TRUE;
}
/* ==================================================== */
/* ==================================================== */

static gint ActionToggleDrumBeat(GtkToggleButton *button)
{
    int drum = (int) gtk_object_get_data(GTK_OBJECT(button),"trommler_drum");
    int beat = (int) gtk_object_get_data(GTK_OBJECT(button),"trommler_beat");
    
    if( button->active )
        PATT_DRUM_BEAT(GuiCurrent.Pattern,drum,beat) = 1;
    else
        PATT_DRUM_BEAT(GuiCurrent.Pattern,drum,beat) = 0;
    return TRUE;
}

/* ==================================================== */
/* ==================================================== */
static gint ActionChangeDrumVolume(GtkAdjustment *adjustment)
{
    int drum =  (int) gtk_object_get_data(GTK_OBJECT(adjustment),"trommler_drum");
    DRUM_VOLUME(drum) = adjustment->value;
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */
static gint ActionChangePatternNumber(GtkAdjustment *adjustment)
{
    GuiCurrent.Pattern = adjustment->value;
    SetPatternName();
    SetPatternLength();
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionChangePatternNumber2(GtkObject *object)
{
    int measure = (int) gtk_object_get_data(object,"trommler_measure");

    GuiCurrent.Pattern = SONG_MEASURE[measure];
    SetPattern();
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionChangePatternUnits(GtkAdjustment *adjustment)
{
    PATT_UNITS(GuiCurrent.Pattern) = adjustment->value;
    SetPatternLength();
#if 1
    usleep(400000);
#endif
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionChangePatternBeatsPerUnit(GtkAdjustment *adjustment)
{
    PATT_BEATS_PER_UNIT(GuiCurrent.Pattern) = adjustment->value;
    SetPatternLength();
#if 1
    usleep(400000);
#endif
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionChangeSongLength(GtkAdjustment *adjustment)
{
    SONG_LENGTH = adjustment->value;
    SetSongLength();
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionChangeSongUPMS(GtkAdjustment *adjustment)
{
    SONG_UPMS = adjustment->value;
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionRestoreMeasurePattern(GtkWidget *widget )
{
    int measure = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_measure");
    SetSongMeasure(measure);
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionChangeMeasurePattern(GtkObject *object )
{
    int measure = (int) gtk_object_get_data(object,"trommler_measure");
    int pattern = atoi( gtk_entry_get_text(GTK_ENTRY(GuiWidgets.SongMeasurePattern[measure])));
    SONG_MEASURE[measure] = pattern;
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */

static gint ActionRestoreDrumName(GtkObject *object )
{
    int drum = (int) gtk_object_get_data(object,"trommler_drum");
    SetDrumName(drum);
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionChangeDrumName(GtkWidget *widget )
{
    int drum = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_drum");
    gchar *name = gtk_entry_get_text(GTK_ENTRY(GuiWidgets.DrumName[drum]));
    strcpy( DRUM_NAME(drum),name);
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */

static gint ActionRestoreSongName()
{
    SetSongName();
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */

static gint ActionChangeSongName()
{
    gchar *songname = gtk_entry_get_text( GTK_ENTRY(GuiWidgets.SongName) );
    strcpy(SONG_NAME,songname);
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */

static gint ActionRestorePatternName()
{
    SetPatternName();
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionChangePatternName()
{
    gchar *name = gtk_entry_get_text( GTK_ENTRY(GuiWidgets.PatternName) );
    strcpy(PATT_NAME(GuiCurrent.Pattern),name);
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */
static gint ActionChangeSongRangeStart(GtkWidget *widget)
{
    GuiCurrent.StartMeasure = GTK_ADJUSTMENT(widget)->value;
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */
static gint ActionSetStartMeasure(GtkWidget *widget)
{
    int measure = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_measure");
    GuiCurrent.StartMeasure = measure;
    gtk_spin_button_set_value( GTK_SPIN_BUTTON(GuiWidgets.SongRangeStart),measure);
    
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */
static gint ActionChangeSongRangeStop(GtkWidget *widget)
{
    GuiCurrent.StopMeasure = GTK_ADJUSTMENT(widget)->value;
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */
static gint ActionSetStopMeasure(GtkWidget *widget)
{
    int measure = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_measure");
    GuiCurrent.StartMeasure = measure;
    gtk_spin_button_set_value( GTK_SPIN_BUTTON(GuiWidgets.SongRangeStop),measure);

    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */
static gint ActionDeleteMeasure(GtkWidget *widget)
{
    int measure = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_measure");

    for( ;measure < MAX_MEASURE_NUM-1;measure++)
    {
        SONG_MEASURE[measure] = SONG_MEASURE[measure+1];
        SetSongMeasure(measure);        
    }

    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */
static gint ActionDuplicateMeasure(GtkWidget *widget)
{
    int measure = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_measure");
    int i;
    
#ifdef DEBUG
    printf("Duplicate Measure  %d\n",measure);
#endif
    
    for( i = MAX_MEASURE_NUM-1;i>measure;i--)
    {
        SONG_MEASURE[i] = SONG_MEASURE[i-1];
        SetSongMeasure(i);        
    }

    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */
static gint ActionClearDrumBeats(GtkWidget *widget)
{
    int beat;
    int pattern = GuiCurrent.Pattern;
    int drum = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_drum");

    for(beat=0;beat<MAX_BEAT_NUM;beat++)
    {
        GtkWidget *widget = GuiWidgets.DrumBeat[drum][beat];
        PATT_DRUM_BEAT(pattern,drum,beat)=0;
        gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(widget),0);
    }
                                        
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */

static int ActionDrumSwapFirst(GtkWidget *widget)
{
    int pattern;
    int beat;
    int drum = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_drum");
    int k;
    
    TYPE_DRUM temp;

    temp = DRUM(drum);
    DRUM(drum) = DRUM(0);
    DRUM(0) = temp;

    for(pattern=0; pattern<MAX_PATT_NUM;pattern++)
        for(beat=0; beat<MAX_BEAT_NUM;beat++)
        {
            k = PATT_DRUM_BEAT(pattern,drum,beat);
            PATT_DRUM_BEAT(pattern,drum,beat) = PATT_DRUM_BEAT(pattern,0,beat);
            PATT_DRUM_BEAT(pattern,0,beat) = k;
        }

    SetPattern();
    SetDrums();

    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionSaveSamplePatternOk(GtkFileSelection *filesel)
{
    int pattern = (int) gtk_object_get_data(GTK_OBJECT(filesel),"trommler_pattern");
    gchar *filename = gtk_file_selection_get_filename(filesel);

    PatternSaveAsSample(filename,pattern,SONG_UPMS);
    gtk_widget_destroy(GTK_WIDGET(filesel));
    return TRUE;    
}


static gint ActionSaveSamplePattern()
{
    char buffer[128];
    GtkWidget *filesel;

    sprintf(buffer,"Save Pattern %d Sample As",GuiCurrent.Pattern);
    filesel = gtk_file_selection_new(buffer);

    gtk_object_set_data(GTK_OBJECT(filesel),"trommler_pattern",
                        (gpointer) GuiCurrent.Pattern);

    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->cancel_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(gtk_widget_destroy),
                              GTK_OBJECT(filesel));
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->ok_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(ActionSaveSamplePatternOk),
                              GTK_OBJECT(filesel));
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(filesel),"*.*");
    gtk_widget_show(GTK_WIDGET(filesel));                                        
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */

static gint ActionSaveSampleRangeOk(GtkFileSelection *filesel)
{
    gchar *filename = gtk_file_selection_get_filename(filesel);
    SongSaveAsSample(filename,GuiCurrent.StartMeasure,GuiCurrent.StopMeasure);
    gtk_widget_destroy(GTK_WIDGET(filesel));
    return TRUE;    
}


static gint ActionSaveSampleRange()
{
    GtkWidget *filesel;
    filesel = gtk_file_selection_new("Save Range Sample As");
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->cancel_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(gtk_widget_destroy),
                              GTK_OBJECT(filesel));
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->ok_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(ActionSaveSampleRangeOk),
                              GTK_OBJECT(filesel));
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(filesel),"*.*");
    gtk_widget_show(GTK_WIDGET(filesel));    
                                    
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */

static gint ActionSaveSampleSongOk(GtkFileSelection *filesel)
{
    gchar *filename = gtk_file_selection_get_filename(filesel);
    SongSaveAsSample(filename,0,SONG_LENGTH-1);
    gtk_widget_destroy(GTK_WIDGET(filesel));
    return TRUE;    
}


static gint ActionSaveSampleSong()
{

    GtkWidget *filesel;
    filesel = gtk_file_selection_new("Save Song Sample As");
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->cancel_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(gtk_widget_destroy),
                              GTK_OBJECT(filesel));
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->ok_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(ActionSaveSampleSongOk),
                              GTK_OBJECT(filesel));
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(filesel),"*.*");
    gtk_widget_show(GTK_WIDGET(filesel));    
                                    
    return TRUE;    
}
/* ==================================================== */
/* ==================================================== */

static gint ActionLoadDrumOk(GtkFileSelection *filesel)
{
    int drum = (int) gtk_object_get_data(GTK_OBJECT(filesel),"trommler_drum");
    gchar *filename = gtk_file_selection_get_filename(filesel);
#ifdef DEBUG
    printf("load drum %d %s\n",drum,filename);
#endif
    DrumLoad(drum,filename);
    printf("destroying fileselector\n");
    
    gtk_widget_destroy(GTK_WIDGET(filesel));
    printf("destroying fileselector done\n");
    return TRUE;    
}


static gint ActionLoadDrum(GtkWidget *widget)
{
    char buffer[128];
    int drumindex; 
    GtkWidget *filesel;

    drumindex = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_drum");
    sprintf(buffer,"Load Drum %d",drumindex);
    filesel = gtk_file_selection_new(buffer);

    gtk_object_set_data(GTK_OBJECT(filesel),"trommler_drum",(gpointer) drumindex);

    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->cancel_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(gtk_widget_destroy),
                              GTK_OBJECT(filesel));
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->ok_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(ActionLoadDrumOk),
                              GTK_OBJECT(filesel));
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(filesel),"*.drum");
    gtk_widget_show(GTK_WIDGET(filesel));    
                                    
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionSaveSong()
{
    gchar *filename;
    gtk_label_get(GTK_LABEL(GuiWidgets.SongFile),&filename);
#ifdef DEBUG
    printf("save song %s\n",filename);
#endif
    SongSave(filename);
    
    return TRUE;
}

/* ==================================================== */
/* ==================================================== */

static gint ActionSaveSongOk(GtkFileSelection *filesel)
{
    gchar *filename = gtk_file_selection_get_filename(filesel);
    gtk_label_set(GTK_LABEL(GuiWidgets.SongFile),filename);
#ifdef DEBUG
    printf("save song as %s\n",filename);
#endif

    SongSave(filename);
    gtk_widget_destroy(GTK_WIDGET(filesel));
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionSaveSongAs()
{
    GtkWidget *widget = gtk_file_selection_new("Save Song");
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(widget)->cancel_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(gtk_widget_destroy),
                              GTK_OBJECT(widget));
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(widget)->ok_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(ActionSaveSongOk),
                              GTK_OBJECT(widget));
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(widget),"*.song");
    gtk_widget_show(GTK_WIDGET(widget));    
                                    
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionNewSong()
{
    gchar *filename = "no_name.sng";
    gtk_label_set(GTK_LABEL(GuiWidgets.SongFile),filename);
#ifdef DEBUG
    printf("new song %s\n",filename);
#endif
    SongClear();    
    SetSong();    
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionLoadSongOk(GtkFileSelection *filesel)
{
    gchar *filename = gtk_file_selection_get_filename(filesel);
    gtk_label_set(GTK_LABEL(GuiWidgets.SongFile),filename);
#ifdef DEBUG
    printf("load song %s\n",filename);
#endif
    SongLoad(filename);
    SetSong();
    
    gtk_widget_destroy(GTK_WIDGET(filesel));
    return TRUE;    
}

/* ==================================================== */
/* ==================================================== */

static gint ActionLoadSong()
{
    GtkWidget *widget=gtk_file_selection_new("Load Song");
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(widget)->cancel_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(gtk_widget_destroy),
                              GTK_OBJECT(widget));
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(widget)->ok_button),
                              "clicked",
                              GTK_SIGNAL_FUNC(ActionLoadSongOk),
                              GTK_OBJECT(widget));
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(widget),"*.sng");
    gtk_widget_show(GTK_WIDGET(widget));    
                                    
    return TRUE;    
}


/* ==================================================== */
/* ==================================================== */

static gint ActionQuit(GtkWidget *widget,GdkEvent *event)
{
    gtk_main_quit();
    return 0;
}

/* ==================================================== */
/* ==================================================== */

static gint ActionAbout()
{
    GtkWidget *dialog;
    GtkWidget *widget;
    static char message[] = "\n"
                            TROMMLER_INFO "\n"
                            TROMMLER_COPYRIGHT "\n"
                            "\n"
                            "Trommler comes with ABSOLUTELY NO WARRANTY;\n"
                            "for details see  the file COPYING.\n"
                            "This is free software, and you are welcome\n"
                            "to redistribute it under certain conditions;\n"
                            "for details see  the file COPYING.\n"
                            "\n"
                            "Please email comments and suggestions to:\n"
                            "muth@cs.arizona.edu\n";

    dialog = gtk_dialog_new();
    
    widget = gtk_label_new(message);
    gtk_box_pack_start( GTK_BOX(GTK_DIALOG(dialog)->vbox), widget, FALSE, FALSE, 0 );
    gtk_widget_show(widget);

    widget = gtk_button_new_with_label(" Ok ");
    gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area),
                       widget,TRUE,FALSE,0);
    gtk_signal_connect_object(GTK_OBJECT(widget), "clicked",
                GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(dialog));

    gtk_widget_show(widget);

    gtk_window_position(GTK_WINDOW(dialog),GTK_WIN_POS_MOUSE);
    gtk_widget_grab_focus(dialog);
    gtk_widget_show(dialog);
    
    return TRUE;    
}


/* ==================================================== */
/* ==================================================== */

static gint ActionMeasurePopup(GtkWidget *widget,GdkEvent *event)
{
    static GtkWidget *menu=NULL;
    
    GtkWidget *item;
    GdkEventButton *bevent = (GdkEventButton *) event;
    int measure = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_measure");

    if( event->type != GDK_BUTTON_PRESS ) return FALSE;
    
#ifdef DEBUG
    printf("popup for measure %d\n",measure);
#endif
        
    if( menu == 0)
    {
        menu = gtk_menu_new();

        item = gtk_menu_item_new_with_label("Show Pattern");
        gtk_signal_connect_object(GTK_OBJECT(item),
                                  "activate",
                                  GTK_SIGNAL_FUNC(ActionChangePatternNumber2),
                                  GTK_OBJECT(menu));
        gtk_menu_append( GTK_MENU(menu), item);
        gtk_widget_show(item);

        item = gtk_menu_item_new_with_label("Duplicate Measure");
        gtk_menu_append( GTK_MENU(menu), item);
        gtk_signal_connect_object(GTK_OBJECT(item),
                                  "activate",
                                  GTK_SIGNAL_FUNC(ActionDuplicateMeasure),
                                  GTK_OBJECT(menu));
        gtk_widget_show(item);

        item = gtk_menu_item_new_with_label("Delete Measure");
        gtk_menu_append( GTK_MENU(menu), item);
        gtk_signal_connect_object(GTK_OBJECT(item),
                                  "activate",
                                  GTK_SIGNAL_FUNC(ActionDeleteMeasure),
                                  GTK_OBJECT(menu));
        gtk_widget_show(item);

        item = gtk_menu_item_new_with_label("Set Range Start");
        gtk_menu_append( GTK_MENU(menu), item);
        gtk_signal_connect_object(GTK_OBJECT(item),
                                  "activate",
                                  GTK_SIGNAL_FUNC(ActionSetStartMeasure),
                                  GTK_OBJECT(menu));
        gtk_widget_show(item);

        item = gtk_menu_item_new_with_label("Set Range End");
        gtk_menu_append( GTK_MENU(menu), item);
        gtk_signal_connect_object(GTK_OBJECT(item),
                                  "activate",
                                  GTK_SIGNAL_FUNC(ActionSetStopMeasure),
                                  GTK_OBJECT(menu));
        gtk_widget_show(item);
    }
        
    gtk_object_set_data(GTK_OBJECT(menu),"trommler_measure",(gpointer) measure);

    gtk_menu_popup(GTK_MENU(menu),NULL,NULL,NULL,NULL,bevent->button,bevent->time);
    return TRUE;
}

/* ==================================================== */
/* ==================================================== */

static gint ActionDrumPopup(GtkWidget *widget,GdkEvent *event)
{
    static GtkWidget *menu=NULL;
#if 0
    static GtkWidget *file=NULL;
#endif
    GtkWidget *item;
    
    GdkEventButton *bevent = (GdkEventButton *) event;
    int drum = (int) gtk_object_get_data(GTK_OBJECT(widget),"trommler_drum");

    if( event->type != GDK_BUTTON_PRESS ) return FALSE;

#ifdef DEBUG
    printf("popup for drum %d\n",drum);    
#endif
        

    if( menu == 0)
    {
        menu = gtk_menu_new();

        item = gtk_menu_item_new_with_label("Load");
        gtk_menu_append( GTK_MENU(menu), item);
        gtk_signal_connect_object(GTK_OBJECT(item),
                                  "activate",
                                  GTK_SIGNAL_FUNC(ActionLoadDrum),
                                  GTK_OBJECT(menu));
        gtk_widget_show(item);

        item = gtk_menu_item_new_with_label("Clear");
        gtk_menu_append( GTK_MENU(menu), item);
        gtk_signal_connect_object(GTK_OBJECT(item),
                                  "activate",
                                  GTK_SIGNAL_FUNC(ActionClearDrumBeats),
                                  GTK_OBJECT(menu));
        gtk_widget_show(item);

        item = gtk_menu_item_new_with_label("Swap First");
        gtk_menu_append( GTK_MENU(menu), item);
        gtk_signal_connect_object(GTK_OBJECT(item),
                                  "activate",
                                  GTK_SIGNAL_FUNC(ActionDrumSwapFirst),
                                  GTK_OBJECT(menu));
        gtk_widget_show(item);

#if 0
        file = gtk_menu_item_new_with_label(buffer);
        gtk_menu_append( GTK_MENU(menu), file);
        gtk_widget_show(file);
#endif
    }


    gtk_object_set_data(GTK_OBJECT(menu),"trommler_drum",(gpointer) drum);
    
    gtk_menu_popup(GTK_MENU(menu),NULL,NULL,NULL,NULL,bevent->button,bevent->time);
    return TRUE;
}


gint KeyboardCallback(GtkWidget* widget, GdkEventKey* event, gpointer data)
{
    gint key = event->keyval;
#if 0
    printf("%04x\n",key);
#endif
    if( key >= GDK_KP_0 && key <=  GDK_KP_9 )
    {
        key -= GDK_KP_0;
        
        if( GuiCurrent.PlayMode == PLAY_PATTERN )
        {
            PATT_DRUM_BEAT(GuiCurrent.PlayPattern,key,GuiCurrent.PlayBeat) = 1;
            gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(GuiWidgets.DrumBeat[key][GuiCurrent.PlayBeat]), 1);
            
        }
    }


    return TRUE;
}


/* ==================================================== */
/* ==================================================== */
/* ==================================================== */
/* ==================================================== */
void CreateMeasures(GtkWidget *container)
{
    int i;
    GtkWidget *widget = gtk_hbox_new(FALSE,0);
    gtk_container_add(GTK_CONTAINER(container), widget);

    /* Beat Items */
    for (i=0;i<MAX_MEASURE_NUM;i++)  
    {
        GtkWidget *parent = widget;
        GtkWidget *widget = gtk_vbox_new(FALSE,0);
        GuiWidgets.SongMeasureBox[i] = widget;
        
        gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);        
        {
            GtkWidget *parent = widget;
            GtkWidget *widget;
            char buffer[16];
            sprintf(buffer,"%03d",i);

            /* popup menu button */
            
            widget = gtk_button_new_with_label(buffer);
            gtk_object_set_data(GTK_OBJECT(widget),"trommler_measure",(gpointer) i);
            gtk_box_pack_start(GTK_BOX(parent),widget,FALSE,FALSE,0);
            gtk_signal_connect_object( GTK_OBJECT(widget),"event",
                                       GTK_SIGNAL_FUNC(ActionMeasurePopup),
                                       GTK_OBJECT(widget));
            
            gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                 widget,
                                 "Measure Popup Menu",
                                 "");

            /* measure change entry */
            
            widget = gtk_entry_new();
            GuiWidgets.SongMeasurePattern[i] = widget;
            gtk_object_set_data(GTK_OBJECT(widget),"trommler_measure",(gpointer) i);
            gtk_box_pack_start(GTK_BOX(parent),widget,FALSE,FALSE,0);
            gtk_entry_set_max_length(GTK_ENTRY(widget),3);
            gtk_entry_set_text(GTK_ENTRY(widget),"???");
            gtk_entry_set_editable(GTK_ENTRY(widget),TRUE);
            gtk_widget_set_usize(widget,30,-1);
            gtk_signal_connect_object( GTK_OBJECT(widget),
                                       "activate",
                                       GTK_SIGNAL_FUNC(ActionChangeMeasurePattern),
                                       (gpointer) widget);
            gtk_signal_connect_object( GTK_OBJECT(widget),
                                       "focus_out_event",
                                       GTK_SIGNAL_FUNC(ActionRestoreMeasurePattern),
                                       (gpointer) widget);
        }
    }
}

/* ==================================================== */
/* ==================================================== */
void CreateBeats(GtkWidget *container)
{
    int i,j;
    char buffer[16];
    GtkWidget *widget;

    widget = gtk_vbox_new(FALSE,0);

    widget = gtk_table_new( MAX_DRUM_NUM,MAX_BEAT_NUM+3,0);
    GuiWidgets.DrumContainer = widget;
    
    gtk_container_add(GTK_CONTAINER(container),widget);
    
    for(i=0;i<MAX_DRUM_NUM;i++)
    {
        GtkWidget *parent = widget;
        GtkObject *adjustment;
        GtkWidget *widget;

        sprintf(buffer," %2d ",i);
        widget = gtk_toggle_button_new_with_label(buffer);
        gtk_object_set_data(GTK_OBJECT(widget),"trommler_drum",(gpointer) i);
        gtk_widget_set_usize(widget,30,-1);

        gtk_table_attach( GTK_TABLE(parent), widget, 0, 1, i, i+1, 0, 0, 0, 0);

        gtk_signal_connect_object( GTK_OBJECT(widget),
                                   "event",
                                   GTK_SIGNAL_FUNC(ActionDrumPopup),
                                   GTK_OBJECT(widget));
        gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                             widget,
                             "Drum Popup Menu",
                             "");
        
        
        /* drum volume */
        adjustment = gtk_adjustment_new(0.0, 0.0, MAX_DRUM_VOLUME-1.0,1.0, 1.0, 1.0);
        gtk_object_set_data(GTK_OBJECT(adjustment),"trommler_drum",(gpointer) i);
        widget = gtk_spin_button_new(GTK_ADJUSTMENT(adjustment),1.0,0);
        GuiWidgets.DrumVolume[i] = widget;

        gtk_signal_connect( GTK_OBJECT(adjustment),
                                "value_changed",
                            GTK_SIGNAL_FUNC(ActionChangeDrumVolume),
                            adjustment);

        gtk_table_attach( GTK_TABLE(parent), widget, 1, 2, i, i+1, 0, 0, 0, 0);

        gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                 widget,
                                 "Set drum volume (100 is normal)",
                                 "");

        /* */
        widget = gtk_entry_new();
        GuiWidgets.DrumName[i] = widget;
        gtk_object_set_data(GTK_OBJECT(widget),"trommler_drum",(gpointer) i);
        gtk_entry_set_text(GTK_ENTRY(widget),"Blechtrommel");
        gtk_entry_set_editable(GTK_ENTRY(widget),TRUE);
        
        gtk_table_attach( GTK_TABLE(parent), widget, 2, 3, i, i+1, 0, 0, 0, 0);
                
        gtk_signal_connect_object( GTK_OBJECT(widget),
                                       "activate",
                                       GTK_SIGNAL_FUNC(ActionChangeDrumName),
                                       GTK_OBJECT(widget));
        gtk_signal_connect_object( GTK_OBJECT(widget),
                                       "focus_out_event",
                                       GTK_SIGNAL_FUNC(ActionRestoreDrumName),
                                       GTK_OBJECT(widget));

        for(j=0;j<MAX_BEAT_NUM;j++)
        {
#if 0
            widget = gtk_toggle_button_new_with_label(" X ");
#else
            widget = gtk_toggle_button_new();
            gtk_widget_set_usize(widget,15,15);
#endif
            gtk_object_set_data(GTK_OBJECT(widget),"trommler_drum",(gpointer) i);
            gtk_object_set_data(GTK_OBJECT(widget),"trommler_beat",(gpointer) j);
            gtk_signal_connect_object( GTK_OBJECT(widget),
                                       "clicked",
                                       GTK_SIGNAL_FUNC(ActionToggleDrumBeat),
                                       GTK_OBJECT(widget));
            
            GuiWidgets.DrumBeat[i][j] = widget;

            gtk_table_attach( GTK_TABLE(parent), widget, 3+j, 4+j, i, i+1, GTK_FILL, GTK_FILL, 0, 0);
        }
    }
}


/* ==================================================== */
/* ==================================================== */

void CreateToplevel()
{
    GtkWidget *widget;
    GtkStyle *style;

    GuiWidgets.Tooltips = gtk_tooltips_new();
    
    widget = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title( GTK_WINDOW(widget), TROMMLER_INFO);
    gtk_widget_set_usize(widget,640,640);
    gtk_signal_connect_object(GTK_OBJECT(widget),"destroy",
                              GTK_SIGNAL_FUNC(ActionQuit),NULL);

    GuiWidgets.Toplevel = widget;

    gtk_signal_connect_object(GTK_OBJECT(widget),"key_press_event",GTK_SIGNAL_FUNC(KeyboardCallback),NULL);
    gtk_widget_set_events(widget,GDK_KEY_PRESS_MASK);
       
    style = gtk_widget_get_style( widget );


    GuiWidgets.ButtonEven = gtk_style_copy(style);

    memcpy(&GuiWidgets.ButtonEven->bg[GTK_STATE_NORMAL],&style->bg[GTK_STATE_ACTIVE],sizeof(GdkColor) );
    memcpy(&GuiWidgets.ButtonEven->bg[GTK_STATE_PRELIGHT],&style->bg[GTK_STATE_ACTIVE],sizeof(GdkColor) );
    memcpy(&GuiWidgets.ButtonEven->bg[GTK_STATE_ACTIVE],&style->black,sizeof(GdkColor) );
    GuiWidgets.ButtonEven->bg_gc[GTK_STATE_NORMAL] = style->bg_gc[GTK_STATE_ACTIVE];
    GuiWidgets.ButtonEven->bg_gc[GTK_STATE_PRELIGHT] = style->bg_gc[GTK_STATE_ACTIVE];
    GuiWidgets.ButtonEven->bg_gc[GTK_STATE_ACTIVE] = style->black_gc;

    GuiWidgets.ButtonOdd = gtk_style_copy(style);

    memcpy(&GuiWidgets.ButtonOdd->bg[GTK_STATE_NORMAL],&style->bg[GTK_STATE_PRELIGHT],sizeof(GdkColor) );
    memcpy(&GuiWidgets.ButtonOdd->bg[GTK_STATE_PRELIGHT],&style->bg[GTK_STATE_PRELIGHT],sizeof(GdkColor) );
    memcpy(&GuiWidgets.ButtonOdd->bg[GTK_STATE_ACTIVE],&style->black,sizeof(GdkColor) );
    GuiWidgets.ButtonOdd->bg_gc[GTK_STATE_NORMAL] = style->bg_gc[GTK_STATE_PRELIGHT];
    GuiWidgets.ButtonOdd->bg_gc[GTK_STATE_PRELIGHT] = style->bg_gc[GTK_STATE_PRELIGHT];
    GuiWidgets.ButtonOdd->bg_gc[GTK_STATE_ACTIVE] = style->black_gc;
        
    /* Vbox within toplevel */
    {
        GtkWidget *parent = widget;
        GtkWidget *widget = gtk_vbox_new(FALSE,0);
        gtk_container_add( GTK_CONTAINER(parent), widget);
        
        /* Menubar */
        {
            GtkWidget *parent = widget;
            GtkWidget *widget = gtk_hbox_new(FALSE,0);
            gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
            
            /* Menubar Items */
            {
                GtkWidget *parent = widget;
                GtkWidget *widget;

                widget = gtk_button_new_with_label("Quit ...");
                gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_signal_connect_object(GTK_OBJECT(widget),
                                          "clicked",
                                          GTK_SIGNAL_FUNC(ActionQuit),
                                          NULL);
                

                widget = gtk_button_new_with_label("About ...");
                gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_signal_connect_object(GTK_OBJECT(widget),
                                          "clicked",
                                          GTK_SIGNAL_FUNC(ActionAbout),
                                          NULL);
                
                widget = gtk_button_new_with_label("New Song");
                gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_signal_connect_object(GTK_OBJECT(widget),
                                          "clicked",
                                          GTK_SIGNAL_FUNC(ActionNewSong),
                                          NULL);
                
                widget = gtk_button_new_with_label("Load Song ...");
                gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_signal_connect_object(GTK_OBJECT(widget),
                                          "clicked",
                                          GTK_SIGNAL_FUNC(ActionLoadSong),
                                          NULL);
                
                widget = gtk_button_new_with_label("Save Song As ...");
                gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_signal_connect_object(GTK_OBJECT(widget),
                                          "clicked",
                                          GTK_SIGNAL_FUNC(ActionSaveSongAs),
                                          NULL);

                widget = gtk_button_new_with_label("Save Song");
                gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_signal_connect_object(GTK_OBJECT(widget),
                                          "clicked",
                                          GTK_SIGNAL_FUNC(ActionSaveSong),
                                          NULL);

                widget = gtk_label_new("a_song_file.sng");
                GuiWidgets.SongFile = widget;
                gtk_box_pack_end( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_widget_show(widget);
                
            }
        }
        
        /* Pattern Menu */
        {
            GtkObject *adjustment;
            GtkWidget *parent = widget;
            GtkWidget *widget = gtk_hbox_new(FALSE,0);
            gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
            
            /* Pattern Menu Items */
            {
                GtkWidget *parent = widget;
                GtkWidget *widget;

                widget = gtk_label_new("Pattern:");
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);

                adjustment = gtk_adjustment_new(0.0, 0.0, MAX_PATT_NUM-1.0, 1.0, 1.0, 0.0);
                widget = gtk_spin_button_new(GTK_ADJUSTMENT(adjustment),1.0,0);
                GuiWidgets.PatternNumber = widget;

                gtk_signal_connect( GTK_OBJECT(adjustment),
                                    "value_changed",
                                    GTK_SIGNAL_FUNC(ActionChangePatternNumber),
                                    adjustment);

                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Choose current pattern",
                                     "");
                
                
                /* pattern name change entry */
                
                widget = gtk_entry_new();
                GuiWidgets.PatternName = widget;
                gtk_entry_set_text(GTK_ENTRY(widget),"0123456789012345");
                gtk_entry_set_editable(GTK_ENTRY(widget),TRUE);
                gtk_entry_set_max_length(GTK_ENTRY(widget),16);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "activate",
                                           GTK_SIGNAL_FUNC(ActionChangePatternName),
                                           GTK_OBJECT(widget));
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "focus_out_event",
                                           GTK_SIGNAL_FUNC(ActionRestorePatternName),
                                           GTK_OBJECT(widget));
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Change pattern description",
                                     "");
                
                /* pattern rotation left */
                
                widget = gtk_button_new_with_label("< Rotate");
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionBeatsRotateLeft),
                                           GTK_OBJECT(widget));
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Rotate beats of current pattern to the left",
                                     "");

                /* copy pattern */
                
                widget = gtk_button_new_with_label(" Copy ");
                GuiWidgets.PatternCopy = widget;
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionCopyPattern),
                                           GTK_OBJECT(widget));
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Copy other pattern into current pattern",
                                     "");


                /* choose source pattern */

                adjustment = gtk_adjustment_new(0.0, 0.0, MAX_PATT_NUM-1.0, 1.0, 1.0, 0.0);
                widget = gtk_spin_button_new(GTK_ADJUSTMENT(adjustment),1.0,0);
                GuiWidgets.PatternSource = widget;
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);

                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Choose source pattern for copy",
                                     "");


                /* pattern rotation right */
                
                widget = gtk_button_new_with_label("Rotate >");
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionBeatsRotateRight),
                                           GTK_OBJECT(widget));
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                      widget,
                                      "Rotate beats of current pattern to the right",
                                      "");


                /* pattern length  */
                
                widget = gtk_label_new("  Units:");
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);

                adjustment = gtk_adjustment_new(1.0, 1.0, MAX_UNITS_NUM, 1.0, 1.0, 0.0);
                widget = gtk_spin_button_new(GTK_ADJUSTMENT(adjustment),1.0,0);

                GuiWidgets.PatternUnits = widget;

                gtk_signal_connect( GTK_OBJECT(adjustment),
                                    "value_changed",
                                    GTK_SIGNAL_FUNC(ActionChangePatternUnits),
                                    adjustment);


                                
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);


                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Set number of units in current pattern",
                                     "");

                /* pattern length  */
                
                widget = gtk_label_new("  BPUs:");
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);

                adjustment = gtk_adjustment_new(1.0, 1.0, MAX_BEATS_PER_UNIT_NUM, 1.0, 1.0, 0.0);
                widget = gtk_spin_button_new(GTK_ADJUSTMENT(adjustment),1.0,0);

                GuiWidgets.PatternBeatsPerUnit = widget;

                gtk_signal_connect( GTK_OBJECT(adjustment),
                                    "value_changed",
                                    GTK_SIGNAL_FUNC(ActionChangePatternBeatsPerUnit),
                                    adjustment);

                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);


                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Set number of beats per unit in current pattern",
                                     "");
            }
        }
        
        /* Beats */
        {
            GtkWidget *parent = widget;
            GtkWidget *widget = gtk_scrolled_window_new(NULL,NULL);
            gtk_box_pack_start( GTK_BOX(parent), widget, TRUE,TRUE,0);
            gtk_scrolled_window_set_policy( GTK_SCROLLED_WINDOW(widget),
                                            GTK_POLICY_AUTOMATIC,
                                            GTK_POLICY_AUTOMATIC);

            CreateBeats(widget);
        }

        /* Song Menu */
        {
            GtkObject *adjustment;
            GtkWidget *parent = widget;
            GtkWidget *widget = gtk_hbox_new(FALSE,0);
            gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
            
            /* song Menu Items */
            {
                GtkWidget *parent = widget;
                GtkWidget *widget;
                
                widget = gtk_entry_new();
                GuiWidgets.SongName = widget;
                gtk_entry_set_text(GTK_ENTRY(widget),"The song");
                gtk_entry_set_editable(GTK_ENTRY(widget),TRUE);
                gtk_entry_set_max_length(GTK_ENTRY(widget),16);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "activate",
                                           GTK_SIGNAL_FUNC(ActionChangeSongName),
                                           NULL);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "focus_out_event",
                                           GTK_SIGNAL_FUNC(ActionRestoreSongName),
                                           NULL);
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "change song description",
                                     "");
                /* */
                
                widget = gtk_label_new("  Measures:");
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);

                /* */
                
                adjustment = gtk_adjustment_new(0.0, 0.0, MAX_MEASURE_NUM, 1.0, 1.0, 1.0);
                widget = gtk_spin_button_new(GTK_ADJUSTMENT(adjustment),1.0,0);
                GuiWidgets.SongMeasures = widget;

                gtk_signal_connect_object( GTK_OBJECT(adjustment),
                                           "value_changed",
                                           GTK_SIGNAL_FUNC(ActionChangeSongLength),
                                           GTK_OBJECT(adjustment));

                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Set number of measure in song",
                                     "");

                /* */
                
                widget = gtk_label_new("  UPMs:");
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);

                /* */
                
                adjustment = gtk_adjustment_new (1.0, 1.0, MAX_UPM_NUM-1.0, 1.0, 1.0, 0.0);
                widget = gtk_spin_button_new(GTK_ADJUSTMENT(adjustment),1.0,0);
                GuiWidgets.SongBpms = widget;

                gtk_signal_connect_object( GTK_OBJECT(adjustment),
                                           "value_changed",
                                           GTK_SIGNAL_FUNC(ActionChangeSongUPMS),
                                           GTK_OBJECT(adjustment));


                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Set beats per minute in song",
                                     "");

                /* */
                
                widget = gtk_label_new(" Range: ");
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);

                /* */
                
                adjustment = gtk_adjustment_new (0.0, 0.0, MAX_MEASURE_NUM-1.0, 1.0, 1.0, 0.0);
                widget = gtk_spin_button_new(GTK_ADJUSTMENT(adjustment),1.0,0);
                GuiWidgets.SongRangeStart = widget;

                gtk_signal_connect_object( GTK_OBJECT(adjustment),
                                           "value_changed",
                                           GTK_SIGNAL_FUNC(ActionChangeSongRangeStart),
                                           GTK_OBJECT(adjustment));


                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Set first measure of song range",
                                     "");

                /* */
                
                widget = gtk_label_new("  to ");
                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);

                /* */
                
                adjustment = gtk_adjustment_new (0.0, 0.0, MAX_MEASURE_NUM-1.0, 1.0, 1.0, 0.0);
                widget = gtk_spin_button_new(GTK_ADJUSTMENT(adjustment),1.0,0);
                GuiWidgets.SongRangeStop = widget;

                gtk_signal_connect_object( GTK_OBJECT(adjustment),
                                           "value_changed",
                                           GTK_SIGNAL_FUNC(ActionChangeSongRangeStop),
                                           GTK_OBJECT(adjustment));


                gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
                gtk_tooltips_set_tip(GuiWidgets.Tooltips,
                                     widget,
                                     "Set last measure of song range",
                                     "");
                /* */
                
                widget = gtk_label_new("000:000:000");
                GuiWidgets.PlayDisplay = widget;
                gtk_box_pack_end( GTK_BOX(parent), widget,FALSE,FALSE,0);
            }
            
            gtk_widget_show(widget);
        }
        
        /* Song */
        {
            GtkWidget *parent = widget;
            GtkWidget *widget = gtk_scrolled_window_new(NULL,NULL);
            gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
            gtk_scrolled_window_set_policy( GTK_SCROLLED_WINDOW(widget),
                                            GTK_POLICY_ALWAYS,
                                            GTK_POLICY_AUTOMATIC);
            gtk_widget_set_usize(widget,-1,80);
            CreateMeasures(widget);
        }
        
        /* Play Menu */
        {
            GtkWidget *parent = widget;
            GtkWidget *widget = gtk_hbox_new(FALSE,0);
            gtk_box_pack_start( GTK_BOX(parent), widget, FALSE,FALSE,0);
            
            /* Play Menu Items */
            {
                GtkWidget *parent = widget;
                GtkWidget *widget;
                GtkWidget *leader;
                
                widget = gtk_label_new("Play ");
                gtk_box_pack_start(GTK_BOX(parent),widget,FALSE,FALSE,0);

                widget = gtk_radio_button_new_with_label(NULL,"Nothing");
                leader =  widget;
                gtk_box_pack_start(GTK_BOX(parent),widget,FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionPlayNothing),
                                           NULL);


                widget = gtk_radio_button_new_with_label( gtk_radio_button_group(GTK_RADIO_BUTTON (leader)),"Pattern");
                gtk_box_pack_start(GTK_BOX(parent),widget,FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionPlayPattern),
                                           NULL);
                
                widget = gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON (leader)),"Range");
                gtk_box_pack_start(GTK_BOX(parent),widget,FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionPlayRange),
                                           NULL);


                widget = gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON (leader)),"Song");
                gtk_box_pack_start(GTK_BOX(parent),widget,FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionPlaySong),
                                           NULL);

                widget = gtk_button_new_with_label("Save Pattern Sample ...");
                gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionSaveSamplePattern),
                                           NULL);

                widget = gtk_button_new_with_label("Save Range Sample ...");
                gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionSaveSampleRange),
                                           NULL);
            
                widget = gtk_button_new_with_label("Save Song Sample ...");
                gtk_box_pack_start( GTK_BOX(parent), widget,FALSE,FALSE,0);
                gtk_signal_connect_object( GTK_OBJECT(widget),
                                           "clicked",
                                           GTK_SIGNAL_FUNC(ActionSaveSampleSong),
                                           NULL);

            }
        }
    }
}    

/* ==================================================== */
/* ==================================================== */

static gint  SoundTimerInterrupt()
{
    int BufferBytesAvail = SoundcardBufferAvail();
    int BufferBytesTotal = SoundcardBufferTotal();
    int BytesCurrent;
    
 start:
    switch( GuiCurrent.PlayMode )
    {
    case PLAY_NONE:
        gtk_timeout_add(TIMER_MS_INTERVAL,SoundTimerInterrupt,NULL);
        return FALSE;
        
    case PLAY_PATTERN:
        GuiCurrent.PlayMeasure = 0;
        GuiCurrent.PlayPattern = GuiCurrent.Pattern;
        if( GuiCurrent.PlayBeat >= PATT_BEATS(GuiCurrent.PlayPattern) )
            GuiCurrent.PlayBeat = 0;
        break;
        
    case PLAY_RANGE:
        if( GuiCurrent.StartMeasure >= SONG_LENGTH ||
            GuiCurrent.StartMeasure <= 0 ||
            GuiCurrent.StopMeasure >=  SONG_LENGTH ||
            GuiCurrent.StopMeasure <= 0 ||
            GuiCurrent.StartMeasure > GuiCurrent.StopMeasure )
        {
            gtk_timeout_add(TIMER_MS_INTERVAL,SoundTimerInterrupt,NULL);
            return FALSE;
        }
        
        if( GuiCurrent.PlayMeasure > GuiCurrent.StopMeasure )
            GuiCurrent.PlayMeasure = GuiCurrent.StartMeasure;

        GuiCurrent.PlayPattern = SONG_MEASURE[GuiCurrent.PlayMeasure];
        if( GuiCurrent.PlayBeat >= PATT_BEATS(GuiCurrent.PlayPattern) )
        {
            GuiCurrent.PlayBeat = 0;
            GuiCurrent.PlayMeasure++;
            if( GuiCurrent.PlayMeasure >  GuiCurrent.StopMeasure )
            {
                GuiCurrent.PlayMeasure = GuiCurrent.StartMeasure;
                GuiCurrent.PlayPattern = SONG_MEASURE[GuiCurrent.PlayMeasure];
            }            
        }
        break;
        
    case PLAY_SONG:
        if( GuiCurrent.PlayMeasure >= SONG_LENGTH )
            GuiCurrent.PlayMeasure = 0;
        
        GuiCurrent.PlayPattern = SONG_MEASURE[GuiCurrent.PlayMeasure];
        if( GuiCurrent.PlayBeat >= PATT_BEATS(GuiCurrent.PlayPattern) )
        {
            GuiCurrent.PlayBeat = 0;
            GuiCurrent.PlayMeasure++;
            if( GuiCurrent.PlayMeasure >= SONG_LENGTH )
            {
                GuiCurrent.PlayMeasure = 0;
                GuiCurrent.PlayPattern = SONG_MEASURE[GuiCurrent.PlayMeasure];
            }            
        }
        break;
    default:
        fprintf(stderr,"illegal play mode\n");
        break;
    }

    BytesCurrent = 44100*2*60 / (SONG_UPMS * PATT_BEATS_PER_UNIT(GuiCurrent.PlayPattern));
    
    if( BytesCurrent < BufferBytesAvail || BufferBytesAvail > BufferBytesTotal/2)
    {
        BufferBytesAvail -= BytesCurrent;

        SetPlay();

        PlayBeat(NULL,
                 GuiCurrent.PlayPattern,
                 GuiCurrent.PlayBeat,
                 SONG_UPMS*PATT_BEATS_PER_UNIT(GuiCurrent.PlayPattern));
        GuiCurrent.PlayBeat++;
        if( BufferBytesAvail > 0 )
            goto start;
    }
    
    gtk_timeout_add(TIMER_MS_INTERVAL,SoundTimerInterrupt,NULL);
    return FALSE;
}

/* ==================================================== */
/* ==================================================== */


int main(int argc, char *argv[])
{
    gtk_init(&argc, &argv);

    CreateToplevel();
    gtk_widget_show_all(GuiWidgets.Toplevel);
    
    if( argc > 1 )
    {
        SongLoad(argv[1]);
        SetSong();
    }
    else
    {
        ActionNewSong();
    }
    
    SoundcardOpen();
    SoundTimerInterrupt();
    gtk_main();

    return 0;
}


/* ==================================================== */
/* ==================================================== */








