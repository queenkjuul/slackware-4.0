#define TROMMLER_INFO      "Trommler 0.9.1 - X11 Drum Machine"
#define TROMMLER_COPYRIGHT "Copyright (C) 1998 Robert Muth"


