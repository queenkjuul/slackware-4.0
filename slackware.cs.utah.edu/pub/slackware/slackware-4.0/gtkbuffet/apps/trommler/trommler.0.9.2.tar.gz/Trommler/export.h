/* automatically generted by genexport.perl*/
/* run  make headers  to update this file */
extern INT32 FindUnusedVoice();
extern void VoiceSetToDrum(INT32 voice,INT32 drum);
extern void BeatAssignDrumsToVoices(INT32 patt,INT32 beat);
extern void Convert32To16Bit(INT32 *src,INT16 *dst,INT32 length);
extern void VoicesExtractTo32Bit(INT32 *data, INT32 length);
extern void VoiceClear(INT32 voic);
extern void SongClear();
extern void PattClear(INT32 patt);
extern void DrumClear(INT32 drum);
extern void ClearAll();
extern void PlayBeat(FILE *fp, INT32 pattern, INT32 beat, INT32 bpms );
extern void SongSaveAsSample(char *filename,INT32 start,INT32 stop);
extern void PatternSaveAsSample(char *filename,INT32 patt,INT32 bmps);
extern void DrumLoad(INT32 drum,char *filename);
extern void SongSave(char *filename);
extern void SongLoad(char *filename);
extern void SoundcardWrite(char *buffer, int length );
extern void  SoundcardClose();
extern void  SoundcardOpen()  ;
