/*
   drummer.c

  Trommler version 0.9 - X11 Drum Machine
    Copyright (C) 1998 Robert Muth <muth@cs.arizona.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of June 1991.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program in form of the file COPYING; 
    if not, write to the 

    Free Software Foundation, Inc. <http://www.fsf.org>
    59 Temple Place, Suite 330, 
    Boston, MA 02111-1307  USA
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "drummer.h"
#include "export.h"

/* ==================================================== */
/* ==================================================== */

TYPE_GLOBAL Global;

/* ==================================================== */
/* ==================================================== */

extern INT32 FindUnusedVoice()
{
    int voice;
    FOREACH_VOICE(voice)
    {
        if( VOICE_LENGTH(voice)==0 )
            return voice;
    }

    fprintf(stderr,"not enough voices\n");
    return 0;
}


/* ==================================================== */

/* ==================================================== */

extern void VoiceSetToDrum(INT32 voice,INT32 drum)
{
    VOICE_SAMPLE(voice) = DRUM_SAMPLE(drum);
    VOICE_LENGTH(voice) = DRUM_LENGTH(drum);
    VOICE_VOLUME(voice) = DRUM_VOLUME(drum);
}

/* ==================================================== */

/* ==================================================== */

extern void BeatAssignDrumsToVoices(INT32 patt,INT32 beat)
{
    int drum;
    int voice;
    
    FOREACH_DRUM(drum)
    {
        if( PATT_DRUM_BEAT(patt,drum,beat) )
        {
           voice = FindUnusedVoice();
           VoiceSetToDrum(voice,drum);
#if 0
           fprintf(stderr,"setting voice %d to drum %d\n",voice,drum);
#endif
       }
    }
}

/* ==================================================== */

/* ==================================================== */

extern void Convert32To16Bit(INT32 *src,INT16 *dst,INT32 length)
{
    INT32 sample;

    for(sample=0; sample<length; sample++)
    {
        if( src[sample] >= (1<<15) )
            dst[sample] = (1<<15)-1;
        else if( src[sample] < -(1<<15) )
            dst[sample] = -(1<<15);
        else
            dst[sample] = src[sample];
    }
}

/* ==================================================== */

/* ==================================================== */

extern void VoicesExtractTo32Bit(INT32 *data, INT32 length)
{
    INT32 voice;
    INT32 sample;
    
    for(sample=0;sample < length; sample++)
    {
        data[sample] = 0;
    }
   
   
    FOREACH_VOICE(voice)
    {
        if( VOICE_LENGTH(voice)==0 ) continue;
        if( VOICE_LENGTH(voice) < length )
        {
            for(sample=0;sample < VOICE_LENGTH(voice); sample++)
                data[sample] += VOICE_VOLUME(voice)*VOICE_SAMPLE(voice)[sample]/100;
            VOICE_SAMPLE(voice) = 0;
            VOICE_LENGTH(voice) = 0;
        }
        else
        {
            for(sample=0;sample < length; sample++)
                data[sample] += VOICE_VOLUME(voice)*VOICE_SAMPLE(voice)[sample]/100;
            VOICE_SAMPLE(voice) += length;
            VOICE_LENGTH(voice) -= length;
        }
    }
}


/* ==================================================== */

/* ==================================================== */

extern void VoiceClear(INT32 voic)
{
    VOICE_LENGTH(voic) = 0;
    VOICE_SAMPLE(voic) = 0;
}

/* ==================================================== */

/* ==================================================== */

extern void SongClear()
{
    INT32 pos;
    INT32 drum;
    INT32 pattern;
    char buffer[16];
    
    strcpy(SONG_NAME,"No Name");
    strcpy(SONG_PATH,"");
    SONG_LENGTH = 0;
    SONG_BPMS = 240;
    FOREACH_SONG_MEASURE(pos)
        SONG_MEASURE[pos] = 0;

    FOREACH_DRUM(drum)
    {
        sprintf(buffer,"Drum %2d",drum);
        strcpy(DRUM_NAME(drum),buffer);
    }

    FOREACH_PATT(pattern)
    {
        sprintf(buffer,"Pattern %3d",pattern);
        strcpy(PATT_NAME(pattern),buffer);
    }
}

/* ==================================================== */

/* ==================================================== */

extern void PattClear(INT32 patt)
{
    INT32 beat;
    INT32 drum;
    
    /* INT32 drum,beat; */
    
    strcpy(PATT_NAME(patt),"");
    PATT_BEATS(patt) = 16;
    FOREACH_DRUM(drum)
        for(beat=0;beat <MAX_BEAT_NUM;beat++)
            PATT_DRUM_BEAT(patt,drum,beat) = 0;
}

/* ==================================================== */
/* ==================================================== */

extern void DrumClear(INT32 drum)
{
    strcpy(DRUM_NAME(drum),"");
    strcpy(DRUM_PATH(drum),"");
    DRUM_SAMPLE(drum) = 0;
    DRUM_KEY(drum) = 0;
    DRUM_LENGTH(drum) = 0;
    DRUM_VOLUME(drum) = 0;
}

/* ==================================================== */
/* ==================================================== */

extern void ClearAll()
{
    int i;
    SongClear();
    FOREACH_DRUM(i)
        DrumClear(i);
    FOREACH_PATT(i)
        PattClear(i);
}

/* ==================================================== */
/* ==================================================== */

extern void PlayBeat(FILE *fp, INT32 pattern, INT32 beat, INT32 bpms )
{
    INT32 length = SAMPLE_FREQUENCY * 60 * SAMPLE_CHANNELS / bpms;

    BeatAssignDrumsToVoices(pattern,beat);

    while( length>0 )
    {
        if( length >= (16*1024) )
        {
            VoicesExtractTo32Bit(Global.Buffer32,16*1024);
            Convert32To16Bit(Global.Buffer32,Global.Buffer16,16*1024);
            if( fp )
                fwrite(Global.Buffer16,16*1024,sizeof(INT16),fp);                
            else
                SoundcardWrite((char *)Global.Buffer16,2*16*1024);
            length -= 16*1024;
        }
        else
        {
            VoicesExtractTo32Bit(Global.Buffer32,length);
            Convert32To16Bit(Global.Buffer32,Global.Buffer16,length);
            if( fp )
                fwrite(Global.Buffer16,length,sizeof(INT16),fp);                
            else
                SoundcardWrite((char *)Global.Buffer16,2*length);
            length = 0;
        }
    }
}

/* ==================================================== */
/* ==================================================== */

extern void SongSaveAsSample(char *filename,INT32 start,INT32 stop)
{
    INT32 patt;
    INT32 beat;
    INT32 pos;
    INT32 voice;
    FILE *fp = fopen(filename, "w");

    printf("song: %s bpm: %d  start: %d stop %d beat\n",
           SONG_NAME,SONG_BPMS,start,stop);
    
    if( fp == 0 )
    {
        fprintf(stderr,"cannot open file %s\n",filename);
        return;
    }    
   
    FOREACH_VOICE(voice)
    {
        VoiceClear(voice);
    }
    
    for(pos=start;pos<=stop;pos++)
    {
        patt = SONG_MEASURE[pos];
        printf("processing patter: %d[%s]\n",patt,PATT_NAME(patt));
        
        FOREACH_PATT_BEAT(patt,beat)
        {
            printf("patt: %d[%s] beat: %d\n",patt,PATT_NAME(patt),beat);
            PlayBeat(fp,patt,beat,SONG_BPMS);
        }
        
    }
    fclose(fp);
}

/* ==================================================== */
/* ==================================================== */

extern void PatternSaveAsSample(char *filename,INT32 patt,INT32 bmps)
{
    INT32 beat;
    INT32 voice;
    FILE *fp = fopen(filename, "w");

    if( fp == 0 )
    {
        fprintf(stderr,"cannot open file %s\n",filename);
        return;
    }    
    
    FOREACH_VOICE(voice)
    {
        VoiceClear(voice);
    }
    
    printf("processing patter: %d[%s]\n",patt,PATT_NAME(patt));
        
    FOREACH_PATT_BEAT(patt,beat)
    {
        printf("patt: %d[%s] beat: %d\n",patt,PATT_NAME(patt),beat);
        PlayBeat(fp,patt,beat,SONG_BPMS);
    }
    
    fclose(fp);
}

/* ==================================================== */

/* ==================================================== */

extern void DrumLoad(INT32 drum,char *filename)
{
    FILE *fp = fopen(filename,"r");
    if( fp == 0 )
    {
        fprintf(stderr,"cannot load drum file %s\n",filename);
        strcpy(DRUM_PATH(drum),"NONE");
        DRUM_LENGTH(drum) = 0;
        return;
    }

    fprintf(stderr,"loading drum file %s\n",filename);
            
    strcpy(DRUM_PATH(drum),filename);
    fseek(fp,0,SEEK_END);
    DRUM_LENGTH(drum) = ftell(fp) / 2;
    fseek(fp,0,SEEK_SET);
    DRUM_SAMPLE(drum) = calloc(DRUM_LENGTH(drum),sizeof(INT16));
    fread(DRUM_SAMPLE(drum),sizeof(INT16),DRUM_LENGTH(drum),fp);
    fclose(fp);    
}


/* ==================================================== */

/* ==================================================== */ 
extern void SongSave(char *filename)
{
    int i,j,k;
    FILE *fp;
    
    fp = fopen(filename, "w" );
    
    if( fp == 0 )
    {
        fprintf(stderr,"cannot save file %s\n",filename);
        return;
    }

    fprintf(fp,
            "# \n"
            "# Songfile created by Drummer\n"
            "#\n");

    fprintf(fp,
            "# \n"
            "# Drums\n"
            "#\n");

    for(i=0;i<MAX_DRUM_NUM;i++)
    {
        fprintf(fp,"d %3d \"%s\" \"%s\" %3d %3d\n",
                i,DRUM_NAME(i),DRUM_PATH(i),DRUM_VOLUME(i),DRUM_KEY(i));
    }
    
    fprintf(fp,
            "# \n"
            "# Patterns\n"
            "#\n");

    for(i=0;i<MAX_PATT_NUM;i++)
    {
        if( PATT_BEATS(i) <= 0 ) continue;
        
        fprintf(fp,"p %3d \"%s\" %3d\n",i,PATT_NAME(i),PATT_BEATS(i));
        for(j=0;j<MAX_DRUM_NUM;j++)
        {
            char buffer[128];
            
            for(k=0;k<PATT_BEATS(i);k++)
                if( PATT_DRUM_BEAT(i,j,k) )
                    break;

            if( k == PATT_BEATS(i) ) continue;

            for(k=0;k<PATT_BEATS(i);k++)
                if( PATT_DRUM_BEAT(i,j,k) )
                    buffer[k] = '*';
                else
                    buffer[k] = '.';
            buffer[k] = 0;

            fprintf(fp,"b %3d %3d %s\n",i,j,buffer);
        }
    }

    fprintf(fp,
            "# \n"
            "# Song\n"
            "#\n");

    fprintf(fp,"s \"%s\" %4d %4d\n",SONG_NAME,SONG_BPMS,SONG_LENGTH);

    for(i=0;i<SONG_LENGTH;i++)
        fprintf(fp,"%d\n",SONG_MEASURE[i]);
               
    fprintf(fp,
            "#\n"
            "# eof\n"
            "#\n");

    fclose(fp);
}


/* ==================================================== */

/* ==================================================== */ 

extern void SongLoad(char *filename)
{
    FILE *fp;
    char buffer[4*1024];
    CHAR beats[MAX_BEAT_NUM];
    CHAR name[MAX_NAME_LEN];
    CHAR path[MAX_PATH_LEN];
    INT32 patt;
    INT32 drum;
    INT32 beat;
    INT32 vol;
    INT32 key;
    INT32 bpm;
    INT32 len;
    CHAR dummy;
    
    /* ==================================================== */

    ClearAll();

   /* ==================================================== */
   
   fp = fopen(filename, "r" );
   
   if( fp == 0 )
   {
       fprintf(stderr,"cannot load file %s\n",filename);
       return;
   }
   
   while(!feof(fp))
   {
       fgets(buffer,sizeof(buffer),fp);

       switch( buffer[0] )
       {
       case '\n':
       case '\t':
       case ' ':
       case '#':
           break;
       case 'p':
           sscanf(buffer,"%c %d \"%[^\"]\" %d",
                  &dummy,&patt,name,&beat);
#if 0
           fprintf(stderr,"patt: %d[%s]  beats: %d\n",patt,name,beat);
#endif
           strcpy(PATT_NAME(patt),name);
           PATT_BEATS(patt) = beat;
           break;

       case 'b':
           sscanf(buffer,"%c %d %d %s",
                  &dummy,&patt,&drum,beats);
#if 0
           fprintf(stderr,"patt: %d  drum: %d  beats: %s\n",patt,drum,beats);
#endif
           FOREACH_PATT_BEAT(patt,beat)
           {
               if( beats[beat] == '*' )
                   PATT_DRUM_BEAT(patt,drum,beat) = 1;
               else
                   PATT_DRUM_BEAT(patt,drum,beat) = 0;
           }
           break;

       case 'd':
           sscanf(buffer,"%c %d \"%[^\"]\" \"%[^\"]\" %d %d",
                  &dummy,&drum,name,path,&vol,&key);

           strcpy(DRUM_NAME(drum),name);
           strcpy(DRUM_PATH(drum),path);
           DRUM_VOLUME(drum) = vol;
           DRUM_KEY(drum) = key;
           DrumLoad(drum,DRUM_PATH(drum));
#if 0
           fprintf(stderr,"drum: %d [%s]  path: %s size: %d\n",
                   drum,DRUM_NAME(drum),DRUM_PATH(drum),DRUM_LENGTH(drum));
#endif
           break;

       case 's':
           sscanf(buffer,"%c \"%[^\"]\" %d %d",
                  &dummy,name,&bpm,&len);

           SONG_BPMS = bpm;
           strcpy(SONG_NAME,name);
           SONG_LENGTH = len;
#if 0
           fprintf(stderr,"song: %s bpm %d len: %d\n",SONG_NAME,SONG_BPMS,SONG_LENGTH);
#endif      
           for(patt=0; patt < len; patt++ )
           {
               fgets(buffer,sizeof(buffer),fp);
               sscanf(buffer,"%d",&SONG_MEASURE[patt]);
           }
           break;
       default:
           fprintf(stderr,"bad line in songfile: %s\n",filename);
           fprintf(stderr,buffer);
           break;
       }
   }   
}

/* ==================================================== */
/* ==================================================== */







