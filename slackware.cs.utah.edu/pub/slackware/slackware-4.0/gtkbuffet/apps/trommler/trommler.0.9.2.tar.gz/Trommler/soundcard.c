/*
    soundcard.c 

    Trommler version 0.9 - X11 Drum Machine
    Copyright (C) 1998 Robert Muth <muth@cs.arizona.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; version 2 of June 1991.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program in form of the file COPYING; 
    if not, write to the 

    Free Software Foundation, Inc. <http://www.fsf.org>
    59 Temple Place, Suite 330, 
    Boston, MA 02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/soundcard.h>
#include <sys/ioctl.h>
#include <fcntl.h>

static int dspfd = -1;

extern void SoundcardWrite(char *buffer, int length )
{
    if( dspfd < 0 )
    {
        fprintf(stderr,"Souncard (write) is not open\n");
        return;
    }

    write(dspfd,buffer,length);
}


extern void  SoundcardClose()
{
    if( dspfd < 0 )
    {
        fprintf(stderr,"Souncard (close) is not open\n");
        return;
    }
    
    close(dspfd);
    dspfd = -1;
}


extern void  SoundcardOpen()  
{
    int n;
    
    if( dspfd >= 0 )
    {
        fprintf(stderr,"Souncard is open\n");
    }
    
    dspfd = open ("/dev/dsp", O_WRONLY, 0);
    if( dspfd < 0)
    {
        fprintf(stderr,"Cannot open souncard\n");
        return;
    }

   /* Now this is tricky !! */

    n=0x0003000e;
    if( ioctl(dspfd, SNDCTL_DSP_SETFRAGMENT, &n) )
    {
        fprintf(stderr,"Cannot set souncard fragment size\n");
        return;
    }
    
    n=2048;
    if( ioctl(dspfd, SNDCTL_DSP_GETBLKSIZE, &n) )
    {
        fprintf(stderr,"Cannot get souncard block size\n");
        return;
    }
  
   n=16;
   if( ioctl(dspfd, SOUND_PCM_WRITE_BITS, &n) )
   {
       fprintf(stderr,"Cannot set souncard bit num\n");
       return;
   }

   n=0;   
   if( ioctl(dspfd, SNDCTL_DSP_GETFMTS, &n) )
   {
       fprintf(stderr,"Cannot get souncard format\n");
       return;
   }
   
   
   n=AFMT_S16_LE;
   if( ioctl(dspfd, SNDCTL_DSP_SETFMT, &n) )
    {
       fprintf(stderr,"Cannot set souncard format\n");
       return;
    }

   n=1;   
   if( ioctl(dspfd, SOUND_PCM_WRITE_CHANNELS, &n) )
   {
       fprintf(stderr,"Cannot set souncard channels\n");
       return;
   }

   
   n=44000;   
   if( ioctl(dspfd, SOUND_PCM_WRITE_RATE, &n) )
   {
       fprintf(stderr,"Cannot set souncard sample frequency\n");
       return;
   }
}


#ifdef MAIN

int main(int argc,char *argv[])
{
    int i;

    SoundcardOpen();

    for(i=1;i<argc;i++)
    {
        FILE *fp;
        char *buffer;
        int length;

        fp = fopen(argv[i],"r");
        if( fp == 0)
        {
            fprintf(stderr,"cannot play %s\n",argv[i]);
            continue;
        }
        

        fseek(fp,0,SEEK_END);
        length= ftell(fp);
        fseek(fp,0,SEEK_SET);

        fprintf(stderr,"playing %s (%d)\n",argv[i],length);
        buffer = malloc(length);
        fread(buffer,1,length,fp);

        SoundcardWrite(buffer,length);
        free(buffer);
        fclose(fp);
    }

    SoundcardClose();
    
    return 0;


}


#endif









