/* $Id: mjono.h,v 0.7 1997/07/18 10:07:42 oh Exp $
 *
 *  Copyright (C) 1997 Tero Koskinen
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; version 2 of the License.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <iostream.h>
#include <string.h>

#ifndef TK_MJONO_H
#define TK_MJONO_H 

class Mjono
{
public:
    // muodostinfunktiot
    Mjono();
    Mjono(const char *const);
    Mjono(const char *const,unsigned int pituus);
    Mjono(const Mjono &);
    ~Mjono();

    // uudelleen m��ritellyt operaattorit
    char & operator[](unsigned short paikka);
    char operator[](unsigned short paikka) const;
    Mjono operator+(const Mjono&);
    void operator+=(const Mjono&);
    Mjono & operator= (const Mjono &);

    // saantifunktiot
    unsigned short AnnaPituus() const { return senPituus; }
    const char * AnnaMjono() const { return senMerkkijono; }
    static int muodostinLaskuri;

private:
    Mjono (unsigned short);	// yksityinen muodostinfunktio
    char * senMerkkijono;
    unsigned short senPituus;

};

#endif
