#include <fstream.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

#ifdef USE_GTK
#include <gnome.h>
#include <gtk/gtk.h>
#else
#include <qapp.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qprogdlg.h> 
#include <ktablistbox.h>
#include <kapp.h>
#include <kfm.h>
#include <kurl.h>
#include <kstatusbar.h>
#endif

#include <zlib.h>
#include "config.h"
#include "zipheader.h"
#include "zippacket.h"
#include "utils.h"

#include "itoa.h"
#include "tkstring.h"
#include "linkedlist.h"

#include "my_bzip2.h"

#include "debug.h"

#ifndef BUF_LEN
#define BUF_LEN 4096
#endif

TKString methodToString(CentralDirRecord & cdr);
int gz_uncompress(gzFile in, FILE *out);


// ----------- ZipPacket luokan rutiinit --------------------

// apu funktio
TKString methodToString(CentralDirRecord & cdr)
{
  TKString apu;
  unsigned long ratio;
  switch(cdr.getMethod())
    {
    case 0:
      apu=TKString(" (stored ");
      break;
    case 1:
      apu=TKString(" (shrunk ");
      break;
    case 2:
    case 3:
    case 4:
    case 5:
      apu=TKString(" (reduced ");
      break;
    case 6:
      apu=TKString(" (imploded ");
      break;
    case 8:
      apu=TKString(" (deflated ");
      break;
    case 9:
    case 10:
      apu=TKString(" (unsupported ");
      break;
    default:
      apu=TKString(" (none ");
      break;
    }
  if (cdr.getUnCSize()>0)
    ratio=100-(unsigned long)(((cdr.getCSize()*100)/(cdr.getUnCSize()))+0.5);
  else
    ratio=0;
  // cout << "getC(): " << cdr.getCSize() << endl;
  // cout << "getUnC(): " << cdr.getUnCSize() << endl;
  // cout << "ratio: " << ratio << endl;
  apu+=itoa(ratio);
  apu+=TKString("%)");
  return apu;
}

ZipPacket::ZipPacket()
{
  opened=0;
  files=0;
  tmpFileExists=0;
}

ZipPacket::~ZipPacket()
{
  files=0;
  if (opened) // Hmmm... toimiikohan tama..
    fin.close();
}


// ouh, this is _very_ ugly function...
// I'll try to make this better in the future
#ifdef USE_GTK
int ZipPacket::open(char *file,GtkWidget *lista,int tmpfile)
#else
  int ZipPacket::open(const char *file,KTabListBox *lista,int tmpfile,QString url,QProgressDialog *prgdlg)
#endif
{
  BasicHeader bh;
  CentralDirRecord cdr;
  //    ArjFileHeader *h;
  ArjMainHeader *amh;
  int firstArjHeader=0;
#ifdef USE_GTK
  /*    GtkWidget *list_item;
	GList *dlist; */
  const char *ctmp[5];
  int r;
  TKString t1,t2,t3,t4;
#else

  QString str;
#endif
  unsigned long ratio;
  int fl=0;
  int out=0;
  int ok=1;
  int gzipType=0; // oletuksena luullaan ettei gzip-tiedosto
  TKString apu;
    
  if (opened)
    close(lista);
#ifdef USE_GTK
  /*	dlist=NULL; */
#endif
  tyhjennaTaulukko(tiedosto,FNAME_MAX);
  strncpy(tiedosto,file,strlen(file));
  fl=strlen(tiedosto);
	
  if (tmpfile==1) // ohoh.. tuli ongelma ei voida paatteesta paatella onko
    {			    // gzipilla vai zipilla pakattu tiedosto, pitaa testata
      int t=0;
      fin.open(file);
      if (!fin)
	{
	  TK_ASSERT(1,cerr << "Cannot open file " << file << endl;);
	  return -1;
	}
      t=zh.find(fin);
      fin.close();
      // TK_ASSERT(1,cout << "Dropped file type = " << t << endl;);
      if (t==0) // ei siis zipilla pakattu (on siis kyseess� gzip)
	gzipType=1;

    }
	
  if ((fl>GZ_SUFFIX_LEN && strcmp(tiedosto+fl-GZ_SUFFIX_LEN,GZ_SUFFIX)==0) || gzipType==1 || strcmp(tiedosto+fl-4,".tgz")==0)
    {
      gzFile gzin;
      gzin=gzopen(tiedosto,"rb");
      if (gzin!=NULL)
	{
#ifndef USE_GTK
	  QString str;
#endif
	  char ch;
	  int a=0;
	  int sf=0;
	  gzclose(gzin);
	  a=fl-1;
	  while(tiedosto[a]!='/'){ if (a<0) break; a--; }
	  while(tiedosto[fl-sf]!='.') { if (sf>=fl) break; sf++; }
	  if (sf>=fl)
	    sf=0;
	  // ch=tiedosto[fl-GZ_SUFFIX_LEN];
	  // tiedosto[fl-GZ_SUFFIX_LEN]='\0';
	  ch=tiedosto[fl-sf];
	  tiedosto[fl-sf]='\0';
#ifdef USE_GTK
	  /* list_item=gtk_list_item_new_with_label(tiedosto+a+1);
	     gtk_container_add(GTK_CONTAINER(lista),list_item);
	     gtk_object_set_data(GTK_OBJECT(list_item),list_item_data_key,tiedosto+a+1);
	     gtk_widget_show(list_item); */
	  ctmp[0]=(const char *)tiedosto+a+1;
	  ctmp[1]=(const char *)NULL;
	  ctmp[2]=(const char *)NULL;
	  ctmp[3]=(const char *)NULL;
	  ctmp[4]=(const char *)NULL;
	  int r=gtk_clist_append(GTK_CLIST(lista),(char**) ctmp);
	  gtk_clist_set_row_data(GTK_CLIST(lista), r, tiedosto+a+1);
#else
	  int g=0;
	  if (tmpfile!=1)
	    {
	      str=tiedosto+a+1;
	    }
	  else
	    {

	      g=strlen(url)-1;
	      while(url[g]!='/') { if (g<0) break; g--; }
	      // TK_ASSERT(1,cout << url << " g:" << g << " len:" << strlen(url) << endl;);
	      str=url;
	      fileUrl=url.copy();
	      if (g>=0)
		{
		  str.remove(0,g+1);
		  fileUrl.remove(0,g+1);
		}
	      str.truncate(str.length()-GZ_SUFFIX_LEN);
	      fileUrl.truncate(fileUrl.length()-GZ_SUFFIX_LEN);
				// TK_ASSERT(1,cout << "fileUrl: " << fileUrl << endl;);
	    }
	  str+=QString("\t?\t?\t?\t?");
	  // TK_ASSERT(1,cout << str << endl;);
	  lista->insertItem(str);
#endif
	  tiedosto[fl-sf]=ch;
	  fileType=2;
	  opened=2;
	  ok=1;
	  files++;
	  tmpFileExists=tmpfile;
	  return 0;
	}
      fileType=0;
    }
#ifdef USE_BZIP2
#ifdef USE_GTK
  if (openBzip2(file,lista,tmpfile)==0)
    {
      fileType=4;
      opened=2;
      ok=1;
      tmpFileExists=tmpfile;
      return 0;
    }
#else
  if (openBzip2(file,lista,tmpfile,url)==0)
    {
      fileType=4;
      opened=2;
      tmpFileExists=tmpfile;
      ok=1;
      return 0;
    }
#endif
#else
#warning No bzip2 support

#endif /* USE_BZIP2 */
  fin.open(file);
  if (!fin)
    {
      // cerr << "Cannot open file " << file << endl;
      return -1;
    }

  while(out==0)
    {
#ifndef USE_GTK
      //	    QProgressDialog prg(klocale->translate("Opening file..."),klocale->translate("Cancel"),3);
#endif
      int type=zh.find(fin);
      ok=0;
      switch(type)
	{
	case 0:
	  out=1;
	  break;
	case 1: // basicheader field
	  ok=1;
#ifndef USE_GTK
	  if (prgdlg)
	    {
	      prgdlg->setProgress(0);
	      prgdlg->repaint();
	      if (prgdlg->wasCancelled())
		{
		  ok=0;
		  out=1;
		  break;
		}
	    }
#endif /* ! USE_GTK */
	  bh.read(fin);
	  bhList.add(bh);
#ifdef SPEED_UP
	  bh.skip(fin);
#endif /* SPEED_UP */
	  break;
	case 2: // CentralDirRecord field
#ifndef USE_GTK
	  if (prgdlg)
	    {
	      prgdlg->setProgress(1);
	      prgdlg->repaint();
	      if (prgdlg->wasCancelled())
		{
		  ok=0;
		  out=1;
		  break;
		}
	    }
#endif
	  ok=1;
	  fileType=1;
	  cdr.read(fin);
	  cdList.add(cdr);
	  apu=TKString(cdr.getFilename());

	  if (cdr.getUnCSize()>0)
	    ratio=100-(unsigned long)(((cdr.getCSize()*100)/(cdr.getUnCSize()))+0.5);
	  else
	    ratio=0;
#ifndef USE_GTK				    
	  /* apu+=TKString("\t",1)+methodToString(cdr); */
	  apu+=TKString("\t",1)+convertDate(cdr.getLastModDate());
	  apu+=TKString("\t",1)+itoa(ratio) + "%";
	  apu+=TKString("\t",1)+itoa(cdr.getUnCSize());
	  apu+=TKString("\t",1)+itoa(cdr.getCSize());
#endif
#ifdef USE_GTK
	  t1=convertDate(cdr.getLastModDate());
	  t2=itoa(ratio)+"%";t3=itoa(cdr.getUnCSize());
	  t4=itoa(cdr.getCSize());
				
	  ctmp[0]=apu.getStr();ctmp[1]=t1.getStr();ctmp[2]=t2.getStr();
	  ctmp[3]=t3.getStr();ctmp[4]=t4.getStr();
			    
	  r=gtk_clist_append(GTK_CLIST(lista), (char**)ctmp);
	  gtk_clist_set_row_data(GTK_CLIST(lista), r, (void*)apu.getStr());
#else
	  lista->insertItem(apu.getStr());
#endif
	  files++;
	  break;
	case 3:
#ifndef USE_GTK
	  if (prgdlg)
	    {
	      prgdlg->setProgress(2);
	      prgdlg->repaint();
	      if (prgdlg->wasCancelled())
		{
		  ok=0;
		  out=1;
		  break;
		}
	    }
#endif
				// CentralDirRecordEnd field
	  ok=1;
	  fileType=1;
	  out=1;
	  break;
	case 4:
	  if (firstArjHeader==0)
	    {
	      amh=new ArjMainHeader();
	      amh->read(fin);
	      amList.add(amh);
	      firstArjHeader=1;
	      ok=1;
	      fileType=3;
	    }
	  else
	    {
	      ArjFileHeader *h=0;
	      int res=0;
	      h=new ArjFileHeader();
	      ok=1;
	      fileType=3;
	      res=h->read(fin);
	      if (res==2)
		{
		  out=1;
		  ok=1;
		  break;
		}
	      else if (res==1)
		{
		  ok=1;
		  break;
		}
	      afList.add(h);
	      apu=TKString(h->getFilename());

	      if (h->getUnCSize()>0)
		ratio=100-(unsigned long)(((h->getCSize()*100)/(h->getUnCSize()))+0.5);
	      else
		ratio=0;
#ifndef USE_GTK				    
	      /* apu+=TKString("\t",1)+methodToString(cdr); */
	      apu+=TKString("\t",1)+convertArjDate(h->getLastModDate());
	      apu+=TKString("\t",1)+itoa(ratio) + "%";
	      apu+=TKString("\t",1)+itoa(h->getUnCSize());
	      apu+=TKString("\t",1)+itoa(h->getCSize());
#endif
#ifdef USE_GTK
	      t1=convertDate(h->getLastModDate());
	      t2=itoa(ratio)+"%";t3=itoa(h->getUnCSize());
	      t4=itoa(h->getCSize());
				
	      ctmp[0]=apu.getStr();ctmp[1]=t1.getStr();ctmp[2]=t2.getStr();
	      ctmp[3]=t3.getStr();ctmp[4]=t4.getStr();
			    
	      r=gtk_clist_append(GTK_CLIST(lista), (char**)ctmp);
	      gtk_clist_set_row_data(GTK_CLIST(lista), r, (void*)apu.getStr());
#else
	      lista->insertItem(apu.getStr());
#endif
	      files++;
	    }
	  break;
	}
    }
  // opened=1;
  if (tmpfile)
    tmpFileExists=1;
  else
    tmpFileExists=0;
  fin.close();
#ifndef USE_GTK
  if (prgdlg)
    {
      prgdlg->setProgress(3);
      if (prgdlg->wasCancelled())
	{
	  ok=0;
	  out=1;
	}
    }
#endif

  if (!ok)
    {
      opened=0;
      return -2;
    }
  opened=2;

  return 0;
}

#ifdef USE_GTK
int ZipPacket::close(GtkWidget *lista)
#else
  int ZipPacket::close(KTabListBox *lista)
#endif
{
  if (opened)
    {
#ifdef USE_GTK
      /* gtk_list_clear_items(GTK_LIST(lista),0,cdList.getNodes()); */
      gtk_clist_clear(GTK_CLIST(lista));
#else
      lista->clear();
      lista->repaint();
#endif
      if (fileType==1)
	{

	  cdList.deleteAll();
	  bhList.deleteAll();
	}
      else if (fileType==3)
	{
	  amList.deleteAll();
	  afList.deleteAll();
	}
      files=0;
    }
  files=0;
  if (opened==1)
    fin.close();
#ifndef USE_GTK
  // TK_ASSERT(1,cout << "tmpfile is alive = " << tmpFileExists << endl;);
  if (tmpFileExists)
    KFM::removeTempFile(tiedosto);
#endif
  tmpFileExists=0;

  fileType=0;
  files=0;
  opened=0;
  return 0;
}

#ifndef USE_GTK
int ZipPacket::unZip(const char *path,int sfile,int options,QProgressDialog *progress,KStatusBar *bar,QWidget *qw)
#else
  int ZipPacket::unZip(const char *path,int sfile,int options)
#endif
{
  char filename[FNAME_MAX];
  char fname[FNAME_MAX];
  unsigned char *in;
  int file_now=0;
  int skip=0;
  if (sfile>=0)
    skip=1;
    
  BasicHeader h;
  ZipHeader zh;
  tyhjennaTaulukko(filename,FNAME_MAX);
  if (strlen(path))
    strcpy(filename,path);
  if (filename[strlen(filename)-1]!='/')
    strcat(filename,"/");
  if (fileType==1)
    {
      if (opened==2)
	{
	  fin.open(tiedosto);
	  if (!fin)
	    return -1;
	  opened=1;
	}
      else if (opened==0)
	return -1;
#ifndef USE_GTK
      // QProgressDialog progress(klocale->translate("Uncompressing file..."),klocale->translate("Cancel"),files,0,"progress",true);
#endif
      file_now=0;
      while (file_now++,zh.find(fin)==1)
	{
	  if (sfile>0 && options&SELECTED_FILE)
	    {
	      sfile--;
	      continue;
	    }
	  int b=0;
	  h.read(fin);
	  tyhjennaTaulukko(fname,FNAME_MAX);
	  b=h.getCSize();
	  if (b>0)
	    {
	      in=new unsigned char[b];
	      tyhjennaTaulukko((char*)in,b);
	      if (in)
		{
		  fin.read((char*)in,b);
		  // cout << "Tavuja luettu: " << fin.gcount() << endl;
		  if (strlen(filename))
		    strncpy(fname,filename,strlen(filename));
		  strncat(fname,(h.getFilename()),strlen(h.getFilename()));
				// cout << "filename: " << fname << endl;
		  makedirs(fname);
		  ofstream fout;
		  // #ifdef USE_GTK
		  //				    fout.open(fname);
		  // #else
		  TKString Fname;
		  if (options&LOWERCASE_FILENAMES)
		    Fname=TKString(fname).lcase();
		  else
		    Fname=fname;
		  TK_ASSERT(1,cout << Fname << endl;);
		  fout.open(Fname.getStr());
		  // #endif
		  if (!fout)
		    {
		      fin.close();
		      delete in;
		      return -1;
		    }	
		  else
		    {
		      if (h.getMethod()==8)
			b=inflatePacked(in,h.getCSize(),fout);
		      else if (h.getMethod()==0)
			{
			  fout.write(in,b);
			  b=Z_OK;
			}
		      else
			{
			  /*
			    fin.close();
			    delete in;
			    return -3;
			  */
			  b=-999;
			}
		    }
		  if (b!=Z_OK)
		    {
		      char eMessage[FNAME_MAX+30];
		      tyhjennaTaulukko(eMessage,FNAME_MAX+30);
		      strncpy(eMessage,"Error: Cannot uncompress properly file: ",40);
		      strcat(eMessage,filename);
		      // fin.close();
		      // delete in;
		      // return -1;
		      showMessage(eMessage);
		    }
		  delete in;
		  fout.close();
		}
	    }
	  if (skip==1)
	    break;
#ifndef USE_GTK
	  // all repaints are just for making sure that everything is really updated
	  if (progress)
	    {
	      // TK_ASSERT(1,cout << "Setting progress to " << file_now << "/" << files << endl;);
	      // progressdialog doesn't seem to work... :(
	      progress->setProgress(file_now);
	      progress->repaint();
	    }
	  if (bar)
	    {
	      int percent=0;
	      TKString pc;
	      percent=(int)(file_now*100/files);
	      pc=itoa(percent)+"%";
	      bar->changeItem(pc,1);
	      bar->repaint();
	    }
	  if (qw)
	    {
	      qw->repaint(true);
	    }
#endif
	}
      opened=2;
      fin.close();
#ifndef USE_GTK
      if (progress)
	progress->setProgress(files);
#endif
    }
  else if (fileType==2 || fileType==4) // gzip or bzip2
    {
      if (opened)
	{
	  if (opened==1)
	    {
	      fin.close();
	      opened=2;
	    }
	  int a=0;
	  int status=0;
	  a=strlen(tiedosto)-1;
	  while(tiedosto[a]!='/')
	    {
	      if (a<1)
		break;
	      a--;
	    }
	  if (a<0) a=0;
#ifndef	USE_GTK
	  if (tmpFileExists==1)
	    {
	      strcat(filename,fileUrl);
	    }
	  else
#endif		    
	    {
	      strcat(filename,tiedosto+a);
	    }
	  // TK_ASSERT(1,cout << __LINE__ << ":" << __FUNCTION__ << endl;);
	  // cout << "Tiedosto: " << tiedosto+a+1 << endl;
#ifndef USE_GTK

	  if (options&LOWERCASE_FILENAMES)
	    {
	      for (unsigned int i=0;i<strlen(filename);i++)
		filename[i]=tolower(filename[i]);
	    }
#endif
	  if (fileType==2)
	    status=gunzipFile(filename);
	  else if (fileType==4)
	    status=uncompressBzip2(tiedosto,filename);
	  TK_ASSERT(status,cout << "uncompress(" << filename << ") ok " << endl;);
	  if (status!=Z_OK)
	    return -1;
	}
    }
  return 0;
}

#ifdef USE_GTK
int ZipPacket::testcrc(GtkWidget *lista) // palautetaan 0, jos kunnossa, muuten -1
#else
  int ZipPacket::testcrc(QListBox *lista)
#endif
{
  unsigned char *buffer;
  unsigned long crc=0;
  ZipHeader zh;
  BasicHeader bh;
  char eMessage[FNAME_MAX];
#ifdef USE_GTK
  GtkWidget *list_item;
#else
  QString str;
#endif
  if (fileType!=1 || opened==0)
    return 0;

  if (opened==1)
    {
      fin.close();
      opened=2;
    }
		    	    
  crc=crc32(0L,Z_NULL,0);
  fin.open(tiedosto);
  if (!fin)
    {
#ifdef USE_GTK
      showError("Cannot open file ",16,tiedosto);
#else
      showError(klocale->translate("Cannot open file "),tiedosto);
#endif
      return 0;
    }
	
  while(zh.find(fin)==1)
    {
      unsigned long status=0;
      int bhSize=0;
      bh.read(fin);
      bhSize=bh.getCSize();
      if (bh.getCSize<=0)
	continue;
      if (bh.getMethod()!=8 && bh.getMethod()!=0)
	continue;
      buffer=new unsigned char[bhSize];
	    
      TK_ASSERT(!buffer,cout << "Name: " << bh.getFilename() << " bhSize: " << bhSize << endl;);
	    
      if (!buffer)
	{
	  sprintf(eMessage,"%d",bhSize);
#ifdef USE_GTK
	  showError("Cannot allocate temporary buffer size ",eMessage);
#else
	  showError(klocale->translate("Cannot allocate temporary buffer size "),eMessage);
#endif
	  fin.close();
	  return 0;
	}
      fin.read(buffer,bhSize);
      // cout << "Testing...";
      // cout.flush();
      if (bh.getMethod()==8)
	status=testInflated(buffer,bhSize,bh.getCrc32());
      else if (bh.getMethod()==0)
	status=testStored(buffer,bhSize,bh.getCrc32());
      else
	status=Z_OK;
      // cout << ".." << endl;
      if (status!=Z_OK)
	{
	  char eMessage[FNAME_MAX+30];
	  tyhjennaTaulukko(eMessage,FNAME_MAX+30);
	  strcpy(eMessage,bh.getFilename());
	  switch(status)
	    {
	    case -10:
#ifdef USE_GTK
	      strncat(eMessage," (crc error)",12);
#else
	      strncat(eMessage,klocale->translate(" (crc error)"),12);
#endif
	      break;
	    case Z_DATA_ERROR:
#ifdef USE_GTK
	      strncat(eMessage," (data error)",13);
#else
	      strncat(eMessage,klocale->translate(" (data error)"),13);
#endif
	      break;
	    }
#ifdef USE_GTK
	  list_item=gtk_list_item_new_with_label(eMessage);
	  gtk_container_add(GTK_CONTAINER(lista),list_item);
	  gtk_widget_show(list_item);
#else
	  lista->insertItem(eMessage);
#endif
	  // showError("Error in file ",14,bh.getFilename());
	  // cout << "Error in file " << bh.getFilename() << endl;
	}
      delete(buffer);
      if (fin.eof())
	break;
    }
  fin.close();
  return 0;
}

int ZipPacket::inflatePacked(unsigned char *compr,
			     unsigned long comprLen,ofstream & fout)
{
  int i=0;
  int windowBits=0;
  int status=Z_OK;
  unsigned char unCompr[0x8000+1];
  z_stream z;
  z.zalloc=Z_NULL;
  z.zfree=Z_NULL;
  z.opaque=0;
  for (i=0x8000,windowBits=0;!(i&1);i>>=1,++windowBits);
  
  z.avail_out=0x8000;
  z.next_out=unCompr;
  z.next_in=compr;
  z.avail_in=comprLen;
  
  status=inflateInit2(&z,-windowBits);
  if (status!=Z_OK)
    {
      // showMessage("Error initializing...");
      return status;
    }
  while(status!=Z_STREAM_END)
    {
      while(z.avail_out>0)
	{
	  status=inflate(&z,Z_PARTIAL_FLUSH);
	  
	  if (status==Z_STREAM_END)
	    break;
	  if (status!=Z_OK && status!=Z_STREAM_END)
	    {
	      // showMessage("Error at uncompressing");
	      return status;
	    }
	  if (z.avail_in<=0)
	    {
	      z.next_in=compr;
	      z.avail_in=comprLen;
	    }
	}
      // cout << "z.avail_out =" << z.avail_out << endl;
      fout.write(unCompr,0x8000-z.avail_out);
      z.next_out=unCompr;
      z.avail_out=0x8000;
    }
  while(status!=Z_STREAM_END)
    {
      status=inflate(&z,Z_PARTIAL_FLUSH);
      if (status==Z_STREAM_END)
	break;
      if (status!=Z_OK)
	return status;
      z.next_out=unCompr;
      z.avail_out=0x8000;
    }
  // cout << "Total out: " << z.total_out;
  status=inflateEnd(&z);
  if (status!=Z_OK)
    {
      // showMessage("Error at end");
      return status;
    }
  // cout << " OK" << endl;
  return Z_OK;
}

int ZipPacket::testInflated(unsigned char *compr,
			    unsigned long comprLen,unsigned long original_crc)
{
  int i=0;
  int windowBits=0;
  int status=Z_OK;
  unsigned char unCompr[0x8000+1];
  unsigned long crc;
  z_stream z;
  z.zalloc=Z_NULL;
  z.zfree=Z_NULL;
  z.opaque=0;
  for (i=0x8000,windowBits=0;!(i&1);i>>=1,++windowBits);
  
  crc=crc32(0L,Z_NULL,0);
  
  z.avail_out=0x8000;
  z.next_out=unCompr;
  z.next_in=compr;
  z.avail_in=comprLen;
  
  status=inflateInit2(&z,-windowBits);
  if (status!=Z_OK)
    {
      // showMessage("Error initializing...");
      return status;
    }
  while(status!=Z_STREAM_END)
    {
      while(z.avail_out>0)
	{
	  status=inflate(&z,Z_PARTIAL_FLUSH);
	  if (status==Z_STREAM_END)
	    break;
	  if (status!=Z_OK && status!=Z_STREAM_END)
	    {
	      // showMessage("Error at uncompressing");
	      return status;
	    }
	  if (z.avail_in<=0)
	    {
	      z.next_in=compr;
	      z.avail_in=comprLen;
	    }
	}
      if (0x8000-z.avail_out>0)
	crc=crc32(crc,unCompr,0x8000-z.avail_out);
      // cout << "z.avail_out =" << z.avail_out << endl;
      // fout.write(unCompr,0x8000-z.avail_out);
      z.next_out=unCompr;
      z.avail_out=0x8000;
    }
  while(status!=Z_STREAM_END)
    {
      status=inflate(&z,Z_PARTIAL_FLUSH);
      if (status==Z_STREAM_END)
	break;
      if (status!=Z_OK)
	return status;
      z.next_out=unCompr;
      z.avail_out=0x8000;
    }
  // cout << "Crc: " << crc << endl << "Orig crc: " << original_crc << endl;
  // cout << "Total out: " << z.total_out;
  status=inflateEnd(&z);
  if (status!=Z_OK)
    {
      // showMessage("Error at end");
      return status;
    }
  if (crc != original_crc)
    return -10;
  // cout << " OK" << endl;
  return Z_OK;
}

int ZipPacket::testStored(unsigned char *compr,
			  unsigned long comprLen,unsigned long original_crc)
{
  if (fileType==1)
    {
      /*  int i=0;
	  int windowBits=0; */
      // int status=Z_OK;
      unsigned char unCompr[0x8000+1];
      unsigned long crc;
      /*  z_stream z;
	  z.zalloc=Z_NULL;
	  z.zfree=Z_NULL;
	  z.opaque=0;
	  for (i=0x8000,windowBits=0;!(i&1);i>>=1,++windowBits); */
  
      crc=crc32(0L,Z_NULL,0);
  
      /*  z.avail_out=0x8000;
	  z.next_out=unCompr;
	  z.next_in=compr;
	  z.avail_in=comprLen; */
  
      /*  status=inflateInit2(&z,-windowBits);
	  if (status!=Z_OK)
	  {
	  // showMessage("Error initializing...");
	  return status;
	  } */
      unsigned int place=0;
      while(place<comprLen)
	{
	  int len=0x8000;
	  if (place+len>comprLen)
	    len=comprLen-place;
	  if (len>0)
	    {
	      memcpy(unCompr,compr,len);
	      crc=crc32(crc,unCompr,len);
	      place+=len;
	    }
	}
      /*  status=inflateEnd(&z);
	  if (status!=Z_OK)
	  {
	  // showMessage("Error at end");
	  return status;
	  } */
      if (crc != original_crc)
	{
	  return -10;
	}
      // cout << " OK" << endl;
    }
  return Z_OK;
}


unsigned long ZipPacket::getCSize(const char *name)
{
  if (fileType==1)
    {
      CDRNode *p;
      p=cdList.getNodeByName(name);
      if (!p)
	return 0;
      return p->h.getCSize();
    }
  else if (fileType==3)
    {
      ArjFileHeader *h;
      afList.begin();
      while(h=afList.get(),h)
	{
	  if (strcmp(h->getFilename(),name)==0)
	    {
	      return h->getCSize();
	    }
	}
    }
  return 0;
}

unsigned long ZipPacket::getUnCSize(const char *name)
{
  if (fileType==1)
    {
      CDRNode *p;
      p=cdList.getNodeByName(name);
      if (!p)
	return 0;
      return p->h.getUnCSize();
    }
  else if (fileType==3)
    {
      ArjFileHeader *h;
      afList.begin();
      while(h=afList.get(),h)
	{
	  if (strcmp(h->getFilename(),name)==0)
	    {
	      return h->getCSize();
	    }
	}
    }
  return 0;
}	

char *ZipPacket::getName(int index)
{
  char apu[FNAME_MAX];
  int a=0;
  CDRNode *p;
  tyhjennaTaulukko(apu,FNAME_MAX);
  if (fileType==1)
    {
      p=cdList.getNode(index);
      if (!p)
	return 0;
      return p->h.getFilename();
    }
  else if (fileType==3)
    {
      ArjFileHeader *k=0;
      afList.begin();
      for (int e=0;e<index;e++)
	{
	  k=afList.getNext();
	}
      if (!k)
	return 0;
      return k->getFilename();
    }
  a=strlen(tiedosto)-1;
  while(tiedosto[a]!='/') { if (a<0) break; a--; }
  strncpy(apu,tiedosto+a+1,strlen(tiedosto)-a-1-GZ_SUFFIX_LEN);
	
  return apu;
}

int ZipPacket::gunzipFile(char *filename)
{
  FILE *out;
  gzFile in;
  int len=strlen(filename);
  int status=0;
    
  /* TK_ASSERT(1,cout << "opening file " << tiedosto << endl;); */
  in=gzopen(tiedosto,"rb");
  if (in==0)
    {
      TK_ASSERT(1,cout << "Error in gz-file " << tiedosto << endl;);
      return -Z_ERRNO;
    }
  /* TK_ASSERT(1,cout << "gz-file ok" << endl;); */
  if (tmpFileExists==0)
    {
      int sf=0;
      if (strncmp(&filename[len-3],"tgz",3)==0)
	{
	  filename[len-1]='r';
	  filename[len-2]='a';
	}
      else
	{
	  while(filename[len-sf]!='.')
	    { 
	      if (sf>=len)
		break;
	      sf++;
	    }
	  if (sf>=len)
	    sf=0;
	  filename[len-sf]='\0';
	}
    }
  // cout << "gzfilename: " << filename << endl;
  out=fopen(filename,"w");
  if (out==NULL)
    {
      gzclose(in);
      return -Z_ERRNO;
    }
  /* TK_ASSERT(1,cout << __LINE__ << ":" << __FUNCTION__ << endl;); */
  status=gz_uncompress(in,out);
  fclose(out);
  if (gzclose(in) !=Z_OK)
    {
      /*
	#ifdef USE_GTK
	showError("Cannot uncompress file ",filename);
	#else
	showError(klocale->translate("Cannot uncompress file "),filename);
	#endif
      */
      return -Z_ERRNO;
    }   

  return status;
}


int gz_uncompress(gzFile in, FILE *out)
{
  char buf[BUF_LEN];
  int len=0;
  // int err;
  for (;;) {
    len = gzread(in, buf, BUF_LEN);
    if (len < 0) return -Z_ERRNO;
    if (len == 0) break;

    if ((int)fwrite(buf, 1, (unsigned)len, out) != len) {
      return -Z_ERRNO;
    }
  }
  //    if (fclose(out)) error("failed fclose");

  //    if (gzclose(in) != Z_OK) error("failed gzclose");
  return Z_OK;
} 

