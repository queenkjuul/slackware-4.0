/****************************************************************************
** MyWidget meta object code from reading C++ file 'xunzip.qt.h'
**
** Created: Thu Sep 17 22:23:57 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.18 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include "xunzip.qt.h"
#include <qmetaobj.h>


const char *MyWidget::className() const
{
    return "MyWidget";
}

QMetaObject *MyWidget::metaObj = 0;

void MyWidget::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(KTopLevelWidget::className(), "KTopLevelWidget") != 0 )
	badSuperclassWarning("MyWidget","KTopLevelWidget");
    if ( !KTopLevelWidget::metaObject() )
	KTopLevelWidget::initMetaObject();
    typedef void(MyWidget::*m1_t0)(KDNDDropZone*);
    typedef void(MyWidget::*m1_t1)(int,int);
    typedef void(MyWidget::*m1_t2)();
    typedef void(MyWidget::*m1_t3)();
    typedef void(MyWidget::*m1_t4)();
    typedef void(MyWidget::*m1_t5)();
    typedef void(MyWidget::*m1_t6)();
    typedef void(MyWidget::*m1_t7)(int,int);
    typedef void(MyWidget::*m1_t8)();
    m1_t0 v1_0 = &MyWidget::fileDrop;
    m1_t1 v1_1 = &MyWidget::showPopupMenu;
    m1_t2 v1_2 = &MyWidget::openfile;
    m1_t3 v1_3 = &MyWidget::closefile;
    m1_t4 v1_4 = &MyWidget::unzipfile;
    m1_t5 v1_5 = &MyWidget::testfile;
    m1_t6 v1_6 = &MyWidget::viewfile;
    m1_t7 v1_7 = &MyWidget::listItemSelected;
    m1_t8 v1_8 = &MyWidget::closeWindow;
    QMetaData *slot_tbl = new QMetaData[9];
    slot_tbl[0].name = "fileDrop(KDNDDropZone*)";
    slot_tbl[1].name = "showPopupMenu(int,int)";
    slot_tbl[2].name = "openfile()";
    slot_tbl[3].name = "closefile()";
    slot_tbl[4].name = "unzipfile()";
    slot_tbl[5].name = "testfile()";
    slot_tbl[6].name = "viewfile()";
    slot_tbl[7].name = "listItemSelected(int,int)";
    slot_tbl[8].name = "closeWindow()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    metaObj = new QMetaObject( "MyWidget", "KTopLevelWidget",
	slot_tbl, 9,
	0, 0 );
}


const char *DirDialog::className() const
{
    return "DirDialog";
}

QMetaObject *DirDialog::metaObj = 0;

void DirDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("DirDialog","QDialog");
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    metaObj = new QMetaObject( "DirDialog", "QDialog",
	0, 0,
	0, 0 );
}
