/****************************************************************************
** TestWindow meta object code from reading C++ file 'xunzip.qt.tw.h'
**
** Created: Wed May 20 18:56:15 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.18 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include "xunzip.qt.tw.h"
#include <qmetaobj.h>


const char *TestWindow::className() const
{
    return "TestWindow";
}

QMetaObject *TestWindow::metaObj = 0;

void TestWindow::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("TestWindow","QWidget");
    if ( !QWidget::metaObject() )
	QWidget::initMetaObject();
    typedef void(TestWindow::*m1_t0)();
    m1_t0 v1_0 = &TestWindow::closeWindow;
    QMetaData *slot_tbl = new QMetaData[1];
    slot_tbl[0].name = "closeWindow()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    metaObj = new QMetaObject( "TestWindow", "QWidget",
	slot_tbl, 1,
	0, 0 );
}
