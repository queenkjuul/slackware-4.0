/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/
// zipHeader.h

#include <fstream.h>

#ifdef USE_GTK
#include <gtk/gtk.h>
#else
#include <qapp.h>
#include <qlistbox.h>
#include <qprogdlg.h> 
#include <ktablistbox.h>
#include <kstatusbar.h>
#include <qstring.h>
#endif

#include <zlib.h>
#include "config.h"
#include "utils.h"
#include "sll.h" // yet another single linked list implementation


#ifndef TK_ZIP_HEADER
#define TK_ZIP_HEADER

class BasicHeader
{
public:
  BasicHeader();
  BasicHeader(const BasicHeader & op);
  ~BasicHeader();

  BasicHeader & operator=(const BasicHeader & op);
  
  void read(ifstream & fin);
  void skip(ifstream & fin);
  int find(ifstream & fin);

  unsigned int getVersion(void) const { return myVersion; }
  unsigned int getPFlag(void) const { return myFlag; }
  unsigned int getMethod(void) const { return myMethod; }
  unsigned int getLastModTime(void) const { return myLastModTime; }
  unsigned int getLastModDate(void) const { return myLastModDate; }
  unsigned long getCrc32(void) const { return myCrc32; }
  unsigned long getCSize(void) const { return myCSize; }
  unsigned long getUnCSize(void) const { return myUnCSize; }
  unsigned int getFilenameLength(void) const { return myFilenameLength; }
  unsigned int getExtraFieldLength(void) const { return myExtraFieldLength; }
  char *getFilename(void) const { return myFilename; }
  unsigned long getPlace(void) const { return myPlace; }
protected:
  unsigned int myVersion;
  unsigned int myFlag;
  unsigned int myMethod;
  unsigned int myLastModTime;
  unsigned int myLastModDate;
  unsigned long myCrc32;
  unsigned long myCSize;
  unsigned long myUnCSize;
  unsigned int myFilenameLength;
  unsigned int myExtraFieldLength;
  char *myFilename;
  unsigned long myPlace; // paikka mista header on alkanut
};

class ArjFileHeader: public BasicHeader
{
public:
  ArjFileHeader();
  int read(ifstream & fin);
  void skip(ifstream & fin);
  int find(ifstream & fin);
private:
  unsigned int myFileType;
  unsigned int myFileSpec;
//  unsigned long timeStamp;
};

class CentralDirRecord
{
public:
  CentralDirRecord();
  CentralDirRecord(const CentralDirRecord & op);  
  ~CentralDirRecord();
  
  CentralDirRecord & operator=(const CentralDirRecord & op);
  
  void read(ifstream & fin);
  int find(ifstream & fin);

  unsigned int getVersionMadeBy(void) const { return myVerMadeBy; }
  unsigned int getVersion(void) const { return myVersion; }
  unsigned int getPFlag(void) const { return myFlag; }
  unsigned int getMethod(void) const { return myMethod; }
  unsigned int getLastModTime(void) const { return myLastModTime; }
  unsigned int getLastModDate(void) const { return myLastModDate; }
  unsigned long getCrc32(void) const { return myCrc32; }
  unsigned long getCSize(void) const { return myCSize; }
  unsigned long getUnCSize(void) const { return myUnCSize; }
  unsigned int getFilenameLength(void) const { return myFilenameLength; }
  unsigned int getExtraFieldLength(void) const { return myExtraFieldLength; }
  unsigned int getCommentLength(void) const { return myCommentLength; }
  unsigned int getDiskNumber(void) const { return myDiskNumber; }
  unsigned int getInternalAttr(void) const { return myInternalAttr; }
  unsigned long getExternalAttr(void) const { return myExternalAttr; }
  unsigned long getRelOffsetLHeader(void) const { return myRelOffset; }
  
  char *getFilename(void) const { return myFilename; }
  char *getComment(void) const { return myComment; }
  unsigned long getPlace(void) const { return myPlace; }
protected:
  unsigned int myVerMadeBy;
  unsigned int myVersion;
  unsigned int myFlag;
  unsigned int myMethod;
  unsigned int myLastModTime;
  unsigned int myLastModDate;
  unsigned long myCrc32;
  unsigned long myCSize;
  unsigned long myUnCSize;
  unsigned int myFilenameLength;
  unsigned int myExtraFieldLength;
  unsigned int myCommentLength;
  unsigned int myDiskNumber;
  unsigned int myInternalAttr;
  unsigned long myExternalAttr;
  unsigned long myRelOffset;
  char *myFilename;
  char *myComment;
  unsigned long myPlace; // mista cdr alkaa
};

class ArjMainHeader: public CentralDirRecord
{
public:
  void read(ifstream & fin);
  int find(ifstream & fin);
private:

};

// ----- linked lists -----------

class BasicNode {
public:
  BasicNode():next(0) { }
  ~BasicNode() { next=0; }

  BasicNode *getNext(void) { return next; }
  void setNext(BasicNode *p) { if (next) next->setNext(p); else next=p; }
  BasicHeader h;
private:
  BasicNode *next;
};

class BasicHeaderList {
public:
  BasicHeaderList():root(0),nodes(0) { }
  ~BasicHeaderList() { if (root) deleteAll(); }

  int add(BasicHeader & bh);
  void deleteAll(void);
  unsigned int getNodes(void) { return nodes; }
  BasicNode *getNode(int index);
private:
  BasicNode *root;
  unsigned int nodes;
};

class CDRNode {
public:
  CDRNode():next(0) { }
  ~CDRNode() { next=0; }

  CDRNode *getNext(void) { return next; }
  void setNext(CDRNode *p) { if (next) next->setNext(p); else next=p; }
  CentralDirRecord h;
private:
  CDRNode *next;
};

class CentralDirRecordList {
public:
  CentralDirRecordList():root(0),nodes(0) { }
  ~CentralDirRecordList() { if (root) deleteAll(); }

  int add(CentralDirRecord & cdr);
  void deleteAll(void);
  unsigned int getNodes(void) { return nodes; }
  CDRNode *getNode(int index);
  CDRNode *getNodeByName(const char *name);
private:
  CDRNode *root;
  unsigned int nodes;
};

class ZipHeader
{
public:
  ZipHeader() { }
  ~ZipHeader() { }
 
  int find(ifstream & fin);
  // 0=not found, 1=local(basic) header,2=cdr,3=end of cd
  // 4=arj file header, 5=arj main header
};

#endif // TK_ZIP_HEADER
