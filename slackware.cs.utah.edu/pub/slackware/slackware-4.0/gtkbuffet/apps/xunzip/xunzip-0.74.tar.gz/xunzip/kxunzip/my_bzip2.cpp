/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/



#include <stdio.h>
#include <stdlib.h>
#include <zlib.h>
#include "config.h"

#ifdef USE_BZIP2

#include "bzip2.h"


#include "my_bzip2.h"

#ifdef USE_GTK
int openBzip2(char *file,GtkWidget *lista,int tmpfile)
#else
int openBzip2(const char *file,KTabListBox *lista,int tmpfile,QString url)
#endif
{
  int a=0;
  int c=0;
  char bzSuffix[]="bz2";
  // bzSuffix[2]='2';bzSuffix[1]='z';bzSuffix[0]='b';
  TKString name;
  a=testf_(file);
  if (a!=0)
    {
      // TK_ASSERT(1,cout << "bzip2: testf_ result = "  << a << endl;);
      return 1;
    }
  a=0;
#ifndef USE_GTK
  if (tmpfile==0)
    {
#endif
      a=strlen(file)-1;
      c=2;
      while(file[a]==bzSuffix[c] && a>=0 && c>=0) 
	{
	  // TK_ASSERT(1,cout << "file[a]: " << file[a] << " bzSuffix: " << bzSuffix[c] << endl;);
	  a--;
	  c--;
	}
      
      if (file[a]=='.')
	a--;
      name=TKString(file,a+1);
#ifndef USE_GTK
    }
  else
    {
      a=strlen(url)-1;
      c=2;
      while(url[a]==bzSuffix[c] && a>=0 && c>=0)
	{
	  a--;
	  c--;
	}
      if (url[a]=='.')
	a--;
      name=TKString(url,a);
    }      
#endif

#ifdef TK_DEBUG
  TK_ASSERT(1,cout << "filename: " << name << " a: " << a << endl;);
#endif

#ifdef USE_GTK
  const char *ctmp[5];
  ctmp[0]=(const char *)name.getStr();
  ctmp[1]=(const char *)NULL;
  ctmp[2]=(const char *)NULL;
  ctmp[3]=(const char *)NULL;
  ctmp[4]=(const char *)NULL;
  int r=gtk_clist_append(GTK_CLIST(lista),(char**) ctmp);
  gtk_clist_set_row_data(GTK_CLIST(lista), r, name);
#else
  QString str;
  str=name;
  str+=QString("\t?\t?\t?\t?");
  lista->insertItem(str);
#endif // USE_GTK

  return 0;
}

int uncompressBzip2(const char *infile,const char *outfile)
{
  /*  int sf=0;
    if (strncmp(filename[len-3],"tbz2",4)==0)
    {
      filename[len-2]='r';
      filename[len-3]='a';
      filename[len-1]='\0';
    }
  else
    {
      while(filename[len-sf]!='.')
	{ 
	  if (sf>=len)
	    break;
	  sf++;
	}
      if (sf>=len)
	sf=0;
      filename[len-sf]='\0';
      } */
  int status=uncompress_(infile,outfile);
  if (status<0)
    return Z_ERRNO;
  return Z_OK;
}

#endif // USE_BZIP2
