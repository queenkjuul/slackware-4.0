/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/
/* config.h */

#ifndef TK_ZIP_CONFIG_H
#define TK_ZIP_CONFIG_H

// #define USE_QT

// #define TK_DEBUG

#define FNAME_MAX 1024
#define DIRMODE 0755
#define ZIP_BASIC_HEADER 1
#define ZIP_CENTRAL_DIR_RECORD 2
#define ZIP_END_OF_CDR 3
#define ARJ_HEADER 4
#define GZ_SUFFIX ".gz"
#define GZ_SUFFIX_LEN 3

#define SPEED_UP
#define PRIVATE_ICON_PATH kapp->kde_datadir()+"/kxunzip/pics/"

#define LOWERCASE_FILENAMES 0x02
#define SELECTED_FILE 0x01
#define SET_ORIG_TIME 0x04

#ifndef USE_BZIP2
#define USE_BZIP2
#endif

#ifndef VERSION
#define VERSION "0.74"
#endif

#endif
