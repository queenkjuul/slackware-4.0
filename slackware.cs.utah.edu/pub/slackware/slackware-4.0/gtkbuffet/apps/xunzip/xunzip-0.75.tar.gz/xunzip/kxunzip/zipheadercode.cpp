/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/
// zipheadercode.cpp

#include <fstream.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

#ifdef USE_GTK
#include <gnome.h>
#include <gtk/gtk.h>
#else
#include <qapp.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qprogdlg.h> 
#include <ktablistbox.h>
#include <kapp.h>
#include <kfm.h>
#include <kurl.h>
#include <kstatusbar.h>
#endif

#include <zlib.h>
#include "config.h"
#include "zipheader.h"
#include "zippacket.h"
#include "utils.h"

#include "itoa.h"
#include "tkstring.h"
#include "linkedlist.h"

#include "debug.h"


// #define USE_EXTRA_ITEM

#define BUF_LEN 4096

TKString methodToString(CentralDirRecord & cdr);
int gz_uncompress(gzFile in, FILE *out);

// --------- BasicHeader rutiinit ------------------
// BasicHeaderin ja CentralDirectoryn muoto loytyy zip-paketin kuvauksesta
// (hae esim. ftp.simtel.netista samasta hakemistosta kuin info-zip loytyy)

BasicHeader::BasicHeader()
{
  myVersion=0;
  myFlag=0;
  myMethod=0;
  myLastModTime=0;
  myLastModDate=0;
  myCrc32=0;
  myCSize=0;
  myUnCSize=0;
  myFilenameLength=0;
  myExtraFieldLength=0;
  myFilename=0;
  myPlace=0;
}

BasicHeader::BasicHeader(const BasicHeader & op)
{
  myVersion=op.getVersion();
  myFlag=op.getPFlag();
  myMethod=op.getMethod();
  myLastModTime=op.getLastModTime();
  myLastModDate=op.getLastModDate();
  myCrc32=op.getCrc32();
  myCSize=op.getCSize();
  myUnCSize=op.getUnCSize();
  myFilenameLength=op.getFilenameLength();
  myExtraFieldLength=op.getExtraFieldLength();
  if (op.getFilename())
	{
	  int apu=strlen(op.getFilename());
	  myFilename=new char[apu];
	  if (myFilename)
		strncpy(myFilename,op.getFilename(),apu);
	}
  
  myPlace=op.getPlace();
}

BasicHeader::~BasicHeader()
{
  if (myFilename!=0)
    {
      delete myFilename;
      myFilename=0;
    }
}

BasicHeader & BasicHeader::operator=(const BasicHeader & op)
{
    if (this==&op)
	    return *this;
    myVersion=op.getVersion();
    myFlag=op.getPFlag();
    myMethod=op.getMethod();
    myLastModTime=op.getLastModTime();
    myLastModDate=op.getLastModDate();
    myCrc32=op.getCrc32();
    myCSize=op.getCSize();
    myUnCSize=op.getUnCSize();
    myFilenameLength=op.getFilenameLength();
    myExtraFieldLength=op.getExtraFieldLength();
	if (op.getFilename())
	  {
		int apu=strlen(op.getFilename());
		myFilename=new char[apu];
		if (myFilename)
		  strncpy(myFilename,op.getFilename(),apu);
	  }
    myPlace=op.getPlace();
    return *this;
};

void BasicHeader::read(ifstream & fin)
{
  // unsigned int inttmp;
  // unsigned long longtmp;
  if(!fin.eof())
    {
      // int status=1;
	  /* fin.read((char*)&inttmp,2); ei kelpaa */
	  myPlace=fin.tellg();
	  myVersion=readint(fin);
      myFlag=readint(fin);
      myMethod=readint(fin);
      myLastModTime=readint(fin);
      myLastModDate=readint(fin);
      myCrc32=readlong(fin);
      myCSize=readlong(fin);
      myUnCSize=readlong(fin);
      myFilenameLength=readint(fin);
      myExtraFieldLength=readint(fin);
      if (myFilenameLength>0)
		{
		  myFilename=new char[myFilenameLength+1];
		  if (myFilename)
			{
			  fin.read(myFilename,myFilenameLength);
			  myFilename[myFilenameLength]=0;
			}
		}
      if (myExtraFieldLength>0)
		fin.seekg(myExtraFieldLength,ios::cur); /* let's skip these... */
    }
}

void BasicHeader::skip(ifstream & fin)
{
    if (myCSize>0)
	    fin.seekg(myCSize,ios::cur);
}

// palautetaan 1, jos loydetty, muutoin 0
int BasicHeader::find(ifstream & fin)
{
  int mode=0; // mika tavu menossa
  char headerSign[5]={ 0x50,0x4b,0x03,0x04,0 };
  while(!fin.eof())
    {
      char ch;
      fin.get(ch);
      if (ch==headerSign[mode])
	mode++;
      else
	mode=0;
      if (mode>=4)
	return 1;
    }
  return 0;
}
#if 0
int ArjFileHeader::read(ifstream & fin)
{
  unsigned int inttmp;
  unsigned long longtmp;
  unsigned int headerSize,firstHeaderSize;
  unsigned char ch=0;
  TKString name,comment;
  if(!fin.eof())
    {
      // int status=1;
	  /* fin.read((char*)&inttmp,2); ei kelpaa */
	  myPlace=fin.tellg();
	  TK_ASSERT(1,cout << "Reading header: " << __LINE__ << endl;);
	  
	  headerSize=readint(fin); 	    // 2 bytes
	  if (headerSize>2600 || headerSize==0)
	      return 1;
	  firstHeaderSize=readbyte(fin);// 1 byte
	  TK_ASSERT(1,cout << "firstHeaderSize: " << firstHeaderSize << endl;);
	  myVersion=readbyte(fin);						// 1 byte
	  TK_ASSERT(1,cout << "myVersion: " << myVersion << endl;);
	  inttmp=readbyte(fin);								// 1 byte, host
	  myFlag=readbyte(fin);								// 1 byte
	  TK_ASSERT(1,cout << "myFlag: " << myFlag << endl;);
      myMethod=readbyte(fin);
      TK_ASSERT(1,cout << "myMethod: " << myMethod << endl);
	  myFileType=readbyte(fin);     // 1 byte
	  fin.get(ch);					            // reserved 1 byte
 	  TK_ASSERT(1,cout << "Reading header: " << __LINE__ << endl;);
      myLastModDate=readint(fin);   //
      myLastModTime=readint(fin);   // date, 4 bytes
      myCSize=readlong(fin);
      myUnCSize=readlong(fin);
      myCrc32=readlong(fin);
	  TK_ASSERT(1,cout << "Reading header: " << __LINE__ << endl;);
      myFileSpec=readint(fin);
      inttmp=readint(fin);          // 2 bytes,file access mode
      inttmp=readint(fin);								  // 2 bytes, host data
	  if (myFlag&0x08) // EXTFILE_FLAG set?
	  {
	      myExtraFieldLength=readlong(fin);
	      fin.seekg(myExtraFieldLength,ios::cur); /* skip extra data */
	  }
  	  TK_ASSERT(1,cout << "Reading header: " << __LINE__ << endl;);
	  char c[2]={ 0,0 };
	  TK_ASSERT(1,cout << "this should be: " << firstHeaderSize+myPlace+2 << " this is: " << fin.tellg() << endl;);
	  TK_ASSERT(1,cout << " a - b: " << fin.tellg()-firstHeaderSize-myPlace-2 << endl;);
	  while(fin.get(c[0]),c[0]!=0)
	  {
	      name+=TKString(c,1);
   	      if (fin.eof())
		      break;
	  }
	  cout << "Name: " << name << endl;
	  while(fin.get(c[0]),c[0]!=0)
	  {
	      comment+=TKString(c,1);
   	      if (fin.eof())
		      break;
	  }
	  
	  longtmp=readlong(fin); // header crc, 4 bytes
	  while(inttmp=readint(fin),inttmp!=0)
	  {
	      fin.seekg(inttmp+4,ios::cur);
	      if (fin.eof())
		      break;
	  }
      if (name.length()>0)
		{
		  myFilename=new char[name.length()+1];
		  if (myFilename)
			{
			  myFilenameLength=name.length();
			  strncpy(myFilename,name.getStr(),myFilenameLength);
			  myFilename[myFilenameLength]=0;
			}
		}

	  /*
      myFilenameLength=readint(fin);
      myExtraFieldLength=readint(fin);
      if (myFilenameLength>0)
		{
		  myFilename=new char[myFilenameLength+1];
		  if (myFilename)
			{
			  fin.read(myFilename,myFilenameLength);
			  myFilename[myFilenameLength]=0;
			}
		}
      if (myExtraFieldLength>0)
		fin.seekg(myExtraFieldLength,ios::cur);
      */
    }
  return 0;
}
#else

unsigned int read_byte(unsigned char *buffer,int & counter)
{
    int a=counter;
    counter++;
    return (unsigned int)buffer[a];
}

unsigned int read_int(unsigned char *buffer,int & counter)
{
    int b=0,c=0;
    b=read_byte(buffer,counter);
    c=read_byte(buffer,counter);
    return ((c<<8)+b);
}

unsigned int read_long(unsigned char *buffer,int & counter)
{
    unsigned long b=0,c=0,d=0,a=0;
    a=read_byte(buffer,counter);
    b=read_byte(buffer,counter);
    c=read_byte(buffer,counter);
    d=read_byte(buffer,counter);

    return ((d<<24)+(c<<16)+(b<<8)+a);
}

ArjFileHeader::ArjFileHeader()
{
  myVersion=0;
  myFlag=0;
  myMethod=0;
  myLastModTime=0;
  myLastModDate=0;
  myCrc32=0;
  myCSize=0;
  myUnCSize=0;
  myFilenameLength=0;
  myExtraFieldLength=0;
  myFilename=0;
  myPlace=0;
}

int ArjFileHeader::read(ifstream & fin)
{
  unsigned int inttmp;
  unsigned long longtmp;
  unsigned int headerSize=0,firstHeaderSize=0;
  // unsigned char ch=0;
  unsigned char *buffer=0;
  int counter=0;
  TKString name,comment;
  if(!fin.eof())
    {
      // int status=1;
	  /* fin.read((char*)&inttmp,2); ei kelpaa */
	  myPlace=fin.tellg();
	  TK_ASSERT(1,cout << "place: " << myPlace << endl;);
/*	  fin.seekg(-2,ios::cur);
	  inttmp=readint(fin);
	  if (inttmp!=0xEA60)
	  {
	      TK_ASSERT(1,cout << "Wrong header! (" << inttmp << ")" << endl);
	      TK_ASSERT(1,cout << "Should be " << 0xEA60 << endl;);
	      return 1;
	  } */
	  headerSize=readint(fin); 	    // 2 bytes
	  TK_ASSERT(1,cout << "headerSize: " << headerSize << endl;);
	  if (headerSize>2600)
	      return 1;
	  else if (headerSize==0)
	      return 2;
	  buffer=new unsigned char[headerSize+1];
	  tyhjennaTaulukko((char*)buffer,headerSize+1);
	  fin.read(buffer,headerSize);
	  firstHeaderSize=read_byte(buffer,counter);// 1 byte
 	  (void)read_byte(buffer,counter);          // 1 byte, archiver version
	  myVersion=read_byte(buffer,counter);						// 1 byte

	  inttmp=read_byte(buffer,counter);								// 1 byte, host
	  myFlag=read_byte(buffer,counter);								// 1 byte
      myMethod=read_byte(buffer,counter);
      TK_ASSERT(1,cout << "Method: " << myMethod << endl;);
	  myFileType=read_byte(buffer,counter);     // 1 byte
	  (void)read_byte(buffer,counter);          // reserved 1 byte
	  longtmp=read_long(buffer,counter);
      //myLastModTime=read_int(buffer,counter);   //
      //myLastModDate=read_int(buffer,counter);   // date, 4 bytes
      myLastModTime=(longtmp&0xFFFF);
      myLastModDate=((longtmp>>16)&0xFFFF);
      myCSize=read_long(buffer,counter);
      myUnCSize=read_long(buffer,counter);
      myCrc32=read_long(buffer,counter);
      myFileSpec=read_int(buffer,counter);
      inttmp=read_int(buffer,counter);          // 2 bytes,file access mode
      inttmp=read_int(buffer,counter);								  // 2 bytes, host data
      TK_ASSERT(1,cout << "host data: " << inttmp << endl;);
      
	  if (myFlag&0x08) // EXTFILE_FLAG set?
	  {
	      myExtraFieldLength=read_long(buffer,counter);
	      // fin.seekg(myExtraFieldLength,ios::cur); /* skip extra data */
	  }
	  // char c[2]={ 0,0 };
	  name=(char*)&buffer[firstHeaderSize];
	  if (buffer[firstHeaderSize+name.length()+1])
	      comment=(char*)&buffer[firstHeaderSize+name.length()+1];

	  longtmp=readlong(fin); // header crc, 4 bytes
	  while(inttmp=readint(fin),inttmp!=0)
	  {
	      fin.seekg(inttmp+4,ios::cur);
	      if (fin.eof())
		      break;
	  }
      if (name.length()>0)
		{
		  myFilename=new char[name.length()+1];
		  if (myFilename)
			{
			  myFilenameLength=name.length();
			  strncpy(myFilename,name.getStr(),myFilenameLength);
			  myFilename[myFilenameLength]=0;
			}
		}
    }
  if (buffer)
      delete [] buffer;
  return 0;
}

#endif

void ArjFileHeader::skip(ifstream & fin)
{
    if (myCSize>0)
	    fin.seekg(myCSize,ios::cur);
}


int ArjFileHeader::find(ifstream & fin)
{
  int mode=0; // mika tavu menossa
  char headerSign[3]={ 0x60,0xea,0 };
  while(!fin.eof())
  {
      char ch;
      fin.get(ch);
      if (ch==headerSign[mode])
	      mode++;
      else
	      mode=0;
      if (mode>=2)
	      return 1;
  }
  return 0;
}


// ---------- CentralDirRecord rutiinit --------------
CentralDirRecord::CentralDirRecord():
myFilename(0),
myComment(0)
{
  myVerMadeBy=0;
  myVersion=0;
  myFlag=0;
  myMethod=0;
  myLastModTime=0;
  myLastModDate=0;
  myCrc32=0;
  myCSize=0;
  myUnCSize=0;
  myFilenameLength=0;
  myExtraFieldLength=0;
  myCommentLength=0;
  myDiskNumber=0;
  myInternalAttr=0;
  myExternalAttr=0;
  myRelOffset=0;
}

CentralDirRecord::CentralDirRecord(const CentralDirRecord & op)
{
    myVerMadeBy=op.getVersionMadeBy();
    myVersion=op.getVersion();
    myFlag=op.getPFlag();
    myMethod=op.getMethod();
    myLastModTime=op.getLastModTime();
    myLastModDate=op.getLastModDate();
    myCrc32=op.getCrc32();
    myCSize=op.getCSize();
    myUnCSize=op.getUnCSize();
    myFilenameLength=op.getFilenameLength();
    myExtraFieldLength=op.getExtraFieldLength();
    myCommentLength=op.getCommentLength();
    myDiskNumber=op.getDiskNumber();
    myInternalAttr=op.getInternalAttr();
    myExternalAttr=op.getExternalAttr();
    myRelOffset=op.getRelOffsetLHeader();
	if (op.getFilename())
	  {
		if (myFilename)
		  {
			delete [] myFilename;
			myFilename=0;
		  }
		int apu=strlen(op.getFilename());
		myFilename=new char[apu+1];
		myFilenameLength=apu;
		if (myFilename)
		{
		  tyhjennaTaulukko(myFilename,apu+1);
		  strncpy(myFilename,op.getFilename(),apu);
		}
	  }
	if (op.getComment())
	  {
		int apu=strlen(op.getComment());
		if (myComment)
		  {
			delete myComment;
			myComment=0;
		  }
		myComment=new char[apu];
		if (myComment)
		  strncpy(myComment,op.getComment(),apu);
	  }
	myPlace=op.getPlace();
}

CentralDirRecord::~CentralDirRecord()
{
  if (myFilename)
    delete myFilename;
  if (myComment)
    delete myComment;
}

CentralDirRecord & CentralDirRecord::operator=(const CentralDirRecord & op)
{
    if (this==&op)
	    return *this;

    myVerMadeBy=op.getVersionMadeBy();
    myVersion=op.getVersion();
    myFlag=op.getPFlag();
    myMethod=op.getMethod();
    myLastModTime=op.getLastModTime();
    myLastModDate=op.getLastModDate();
    myCrc32=op.getCrc32();
    myCSize=op.getCSize();
    myUnCSize=op.getUnCSize();
    myFilenameLength=op.getFilenameLength();
    myExtraFieldLength=op.getExtraFieldLength();
    myCommentLength=op.getCommentLength();
    myDiskNumber=op.getDiskNumber();
    myInternalAttr=op.getInternalAttr();
    myExternalAttr=op.getExternalAttr();
    myRelOffset=op.getRelOffsetLHeader();
	if (op.getFilename())
    {
		if (myFilename)
	    {
			delete myFilename;
			myFilename=0;
		}
		unsigned int apu=strlen(op.getFilename());
		myFilename=new char[apu+1];
		myFilenameLength=apu;
		if (apu!=myFilenameLength)
		    cerr << __FUNCTION__ << "(): if (apu!=myFilenameLength)" << endl;
		if (myFilename)
		{
		    tyhjennaTaulukko(myFilename,apu+1);
		    strncpy(myFilename,op.getFilename(),apu);
		}
	}
	if (op.getComment())
	{
		int apu=strlen(op.getComment());
		if (myComment)
		  {
			delete myComment;
			myComment=0;
		  }
		myComment=new char[apu];
		if (myComment)
		{
		    tyhjennaTaulukko(myComment,apu+1);
			strncpy(myComment,op.getComment(),apu);
		}
	}
	myPlace=op.getPlace();
	return *this;
}

void CentralDirRecord::read(ifstream & fin)
{
  // unsigned int inttmp;
  // unsigned long longtmp;
  if(!fin.eof())
    {
	  // char ch;
      // int status=1;
      myPlace=fin.tellg();
      myVerMadeBy=readint(fin);
      myVersion=readint(fin);
      myFlag=readint(fin);
      myMethod=readint(fin);
      myLastModTime=readint(fin);
      myLastModDate=readint(fin,1);
	  myCrc32=readlong(fin);
      myCSize=readlong(fin);
      myUnCSize=readlong(fin);
      myFilenameLength=readint(fin);
      myExtraFieldLength=readint(fin);
      myCommentLength=readint(fin);
      myDiskNumber=readint(fin);
      myInternalAttr=readint(fin);
      myExternalAttr=readlong(fin);
      myRelOffset=readlong(fin);
      if (myFilenameLength>0)
		{
		  myFilename=new char[myFilenameLength+1];
		  if (myFilename)
		  {
			  tyhjennaTaulukko(myFilename,myFilenameLength+1);
			  fin.read(myFilename,myFilenameLength);
			  myFilename[myFilenameLength]=0;
		  }
		}
      if (myExtraFieldLength>0)
		fin.seekg(myExtraFieldLength,ios::cur); /* let's skip these... */
      if (myCommentLength>0)
		{
		  myComment=new char[myCommentLength+1];
		  if (myComment)
			{
			  fin.read(myComment,myCommentLength);
			  myComment[myCommentLength]=0;
			}
		}
    }
}

// palautetaan 1, jos loydetty, muutoin 0
int CentralDirRecord::find(ifstream & fin)
{
  int mode=0; // mika tavu menossa
  char headerSign[5]={ 0x50,0x4b,0x01,0x02,0 };
  while(!fin.eof())
    {
      char ch;
      fin.get(ch);
      if (ch==headerSign[mode])
	mode++;
      else
	mode=0;
      if (mode>=4)
	return 1;
    }
  return 0;
}


void ArjMainHeader::read(ifstream & fin)
{
//  unsigned int inttmp;
  // unsigned long longtmp;
  unsigned int headerSize; //  ,firstHeaderSize;
/*  unsigned char ch=0; */
  if(!fin.eof())
    {
      // int status=1;
	  /* fin.read((char*)&inttmp,2); ei kelpaa */
	  myPlace=fin.tellg();
	  
	  headerSize=readint(fin); 	    // 2 bytes
	  if (headerSize<2600)
	      fin.seekg(headerSize,ios::cur); // we do not need to read main header 
									      // at this moment
#if 0	      
	  firstHeaderSize=readbyte(fin);// 1 byte
	  myVersion=readbyte(fin);						// 1 byte
	  myFlag=readbyte(fin);								// 1 byte
      myMethod=readbyte(fin);
	  myFileType=readbyte(fin);     // 1 byte
	  fin.get(ch);					            // reserved 1 byte
      myLastModDate=readint(fin);   //
      myLastModTime=readint(fin);   // date, 4 bytes
      myCSize=readlong(fin);
      myUnCSize=readlong(fin);
      myCrc32=readlong(fin);
      myFileSpec=readint(fin);
      inttmp=readint(fin);

      myFilenameLength=readint(fin);
      myExtraFieldLength=readint(fin);
      if (myFilenameLength>0)
		{
		  myFilename=new char[myFilenameLength+1];
		  if (myFilename)
			{
			  fin.read(myFilename,myFilenameLength);
			  myFilename[myFilenameLength]=0;
			}
		}
      if (myExtraFieldLength>0)
		fin.seekg(myExtraFieldLength,ios::cur);
#endif // 0
    }
}


int ArjMainHeader::find(ifstream & fin)
{
  int mode=0; // mika tavu menossa
  char headerSign[3]={ 0x60,0xea,0 };
  while(!fin.eof())
  {
      char ch;
      fin.get(ch);
      if (ch==headerSign[mode])
	      mode++;
      else
	      mode=0;
      if (mode>=2)
	      return 1;
  }
  return 0;
}

RarMarker::RarMarker()
{
crc=0; size=0;
}

int RarMarker::find(ifstream & fin)
{
  int mode=0; // mika tavu menossa
  char headerSign[3]={ 0x52,0x61,0 };
  while(!fin.eof())
  {
      char ch;
      fin.get(ch);
      if (ch==headerSign[mode])
	mode++;
      else
	mode=0;
      if (mode>=2)
	break;
  }
  if (mode>=2)
    {
      int type;
      int flags;
      type=readbyte(fin);
      flags=readint(fin);
      size=readint(fin);
      crc=0x6152;
      if (type==0x72 && flags==0x1a21 && size==0x0007)
	return 1;
      else
	{
	  fin.seekg(-1,ios::cur);
	  return 0;
	}
    }
  return 0;
}

RarArchiveHeader::RarArchiveHeader()
{
  flags=0;
  size=0;
}

int RarArchiveHeader::find(ifstream & )
{
  return 1;
}

int RarArchiveHeader::read(ifstream & fin)
{
  int type;
  crc=readint(fin);
  type=readbyte(fin);
  flags=readint(fin);
  size=readint(fin);
  fin.seekg(size-7,ios::cur);
  if (fin.eof())
    return 0;
  return 1;
}

RarHeader::RarHeader()
{
  flags=0;
  size=0;
  addSize=0;
  type=0;
  crc=0;
}

int RarHeader::read(ifstream & fin)
{
  crc=readint(fin);
  type=readbyte(fin);
  flags=readint(fin);
  size=readint(fin);
  addSize=0;
  if (flags&0x8000)
    {
      addSize=readlong(fin);
    }
  return 1;
}

int RarComment::read(ifstream & fin)
{
  rh.read(fin);
  fin.seekg(rh.getSize()+rh.getAddSize()-7,ios::cur);
  return 1;
}

RarFileHeader::RarFileHeader()
{ }

int RarFileHeader::read(ifstream & fin)
{
  rh.read(fin);
  if (rh.getType()!=0x74)
    {
      fin.seekg(rh.getSize()+rh.getAddSize()-7,ios::cur);
      return 0;
    }
  return 1;
}

// -------------- ZipHeader rutiinit --------------------
// palautetaan 1,2,4 tai 4 jos loydetty joku header, muutoin 0
int ZipHeader::find(ifstream & fin)
{
  int mode=0; // mika tavu menossa
  char headerSign[3]={ 0x50,0x4b,0 };
  char arjHeaderSign[3]={ 0x60,0xea, 0 };
  while(1)
    {
      char ch;
      fin.get(ch);
      if (ch==headerSign[mode])
		mode++;
      else
		mode=0;
	  if (ch==arjHeaderSign[0])
	  {
	      fin.get(ch);
	      if (ch==arjHeaderSign[1])
		      return 4;
		  fin.seekg(-1,ios::cur);
	  }
      if (mode>=2)
		{
		  char a,b;
		  fin.get(a).get(b);
		  if (a==0x01 && b==0x02)
			return ZIP_CENTRAL_DIR_RECORD;
		  else if (a==0x03 && b==0x04)
			return ZIP_BASIC_HEADER;
		  else if (a==0x05 && b==0x06)
			return ZIP_END_OF_CDR;
		  fin.seekg(-2,ios::cur); // palataan 2 takaisin varmuuden vuoksi
		  mode=0;
		}
      if (fin.eof())
		return 0;
    }
  
  return 0;
}

// ------- BasicHeaderList luokan rutiinit  ---------------
int BasicHeaderList::add(BasicHeader & bh)
{
	BasicNode *p;
	p=new BasicNode();
	if (!p)
	    return -1;
	p->h=bh;
	if (!root)
	    root=p;
	else
	    root->setNext(p);
	nodes++;
	return 0;
}

void BasicHeaderList::deleteAll(void)
{
    BasicNode *p;
    BasicNode *o;
    if (root)
    {
	    p=root;
		while(p)
		{
		    o=p->getNext();
			if (p)
			  delete(p);
		    p=o;
			if (!p)
			  break;
		}
		root=0;
		nodes=0;
    }
}

BasicNode *BasicHeaderList::getNode(int index)
{
    BasicNode *p;
    if (!root)
	    return 0;
	p=root;
    for (int a=0;a<index;a++)
	{
	    if (!p->getNext())
		    break;
	    p=p->getNext();
    }
    return p;
}

int CentralDirRecordList::add(CentralDirRecord & cdr)
{
	CDRNode *p;
	p=new CDRNode();
	if (!p)
	    return -1;
	p->h=cdr;
	if (!root)
	    root=p;
	else
	    root->setNext(p);
	nodes++;
	return 0;
}

void CentralDirRecordList::deleteAll(void)
{
    CDRNode *p;
    CDRNode *o;
    if (root)
    {
	    p=root;
		while(p)
		{
		    o=p->getNext();
			if (p)
			  delete(p);
		    p=o;
			if (!p)
			  break;
		}
		root=0;
		nodes=0;
    }
}

CDRNode *CentralDirRecordList::getNode(int index)
{
    CDRNode *p;
    if (!root)
	    return 0;
	p=root;
    for (int a=0;a<index;a++)
	{
	    if (!p->getNext())
		    break;
	    p=p->getNext();
    }
    return p;
}

CDRNode *CentralDirRecordList::getNodeByName(const char *name)
{
    CDRNode *p;
    if (!root)
	    return 0;
	// cout << "Searching file: " << name << "." << endl;
	p=root;
	while(p)
	{
	    if (p)
	    {
		    if (p->h.getFilename())
		    {
			    // cout << "Comparing to: " << p->h.getFilename() << "." << endl;
			    if (!strcmp(p->h.getFilename(),name))
			    {
				    // cout << "Found!" << endl;
				    break;
				}
		    }
		}
		p=p->getNext();
    }
    return p;
}

