/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

#include <fstream.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#ifdef USE_GTK
#include <gtk/gtk.h>
#include <gnome.h>
#else
#include <qapp.h>
#include <qlistbox.h>
#include <qprogdlg.h> 
#include <ktablistbox.h>
#include <kstatusbar.h>
#include <qstring.h>
#endif

#include <zlib.h>

#include "config.h"
#include "utils.h"
#include "zipheader.h"
#include "debug.h"
#include "sll.h" // yet another single linked list...
#include "compress.h"

Compress::Compress()
{ }

Compress::~Compress()
{ }

int Compress::gzip_compress(const char *file,int deleteFile)
{
  char outfile[FNAME_MAX];
  int status=0;
  FILE *in;
  gzFile out;

  strcpy(outfile,file);
  strcat(outfile,GZ_SUFFIX);
  in=fopen(file,"rb");
  if (in==NULL)
    {
      return -1;
    }
  out=gzopen(outfile,"wb6");
  status=gz_compress(in,out);
  fclose(in);
  if (status==Z_OK)
    {
      if (deleteFile)
	unlink(file);
    }
  return status;
}

int Compress::gz_compress(FILE *in,gzFile out)
{
  char buf[GZIP_BUFFER_LEN];
  int len=0;
  // int status=0;

  while(1)
    {
      len = fread(buf, 1, sizeof(buf), in);
      if (ferror(in)) {
	gzclose(out);
	return Z_ERRNO;
      }
      if (len == 0) break;
      
      if (gzwrite(out, buf, (unsigned)len) != len) 
	{
	  gzclose(out);
	  return Z_ERRNO;
	}
    }
  return gzclose(out);
}
