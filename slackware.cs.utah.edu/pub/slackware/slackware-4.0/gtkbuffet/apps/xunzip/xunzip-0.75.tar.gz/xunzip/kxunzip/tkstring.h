// tkstring.h
//
// My own string class
// Version 0.1

/*
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <iostream.h>
#include <string.h>
#include <ctype.h>

#ifndef TK_STRING_H
#define TK_STRING_H

class TKString
{
public:
    TKString();
    TKString(int size);
    TKString(const char *buffer,int size);
    TKString(const TKString & t);
    TKString(const char *);
    ~TKString();
    
    TKString & operator=(const TKString & t);
    TKString & operator=(const char *str);
    char & operator[](unsigned int p);
    char operator[](unsigned int p) const;
    // bool isEmpty(void) const;
    unsigned int length(void) const;
    TKString lcase(void);
    const char *getStr() const { return myStr; }
    
    TKString operator+(const TKString &);
    TKString operator+(const char *str);
    void operator+=(const TKString &);
    void operator+=(const char *str);
    
    operator const char*(void) const;
private:
    char *myStr;
    unsigned int myLength;
};

// these would make your a little bit easier...
inline bool operator==(const TKString & s1,const TKString & s2)
{
    return strcmp(s1.getStr(),s2.getStr())==0;
}

inline bool operator!=(const TKString & s1,const TKString & s2)
{
    return strcmp(s1.getStr(),s2.getStr())!=0;
}

// some little utils next
int wordLenght(const char *s);
int stringLenght(const char *s);
int nextWord(const char *s);
int nextString(const char *s);

#endif // TK_STRING_H

