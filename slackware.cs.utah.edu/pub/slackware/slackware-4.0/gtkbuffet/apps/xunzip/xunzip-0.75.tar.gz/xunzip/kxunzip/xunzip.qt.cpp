/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

/* xunzip.qt.cpp */

#ifndef USE_GTK

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream.h>

#include <qapp.h>
#include <qpushbt.h>
#include <qfont.h>
#include <qlistbox.h>
#include <qlabel.h>
#include <qfiledlg.h>
#include <qframe.h>
#include <qlabel.h>
#include <qstrlist.h>
// #include <qslider.h>
#include <qmsgbox.h>
#include <qpopmenu.h>
#include <qmenubar.h>
#include <qdialog.h>
#include <qaccel.h>
#include <qprogdlg.h>
#include <qlined.h>
#include <qpixmap.h>
#include <qgrpbox.h>
#include <qchkbox.h>
#include <qbttngrp.h>
#include <qradiobt.h>
#include <qcursor.h>

#include <kstatusbar.h>
#include <ktoolbar.h>

#include <kapp.h>
#include <kkeydata.h>
#include <ktopwidget.h>
#include <klocale.h>
#include <kiconloader.h>
#include <kpopmenu.h>

#include <drag.h>

#include "zipheader.h"
#include "utils.h"
#include "config.h"
#include "tkstring.h"
#include "itoa.h"

#include "xunzip.qt.h"
#include "xunzip.qt.tw.h"


#include "debug.h"

// #include "xunzip.moc"
// #include "xunzip.tw.moc"

// extern ZipPacket zip;

QList<MyWidget> MyWidget::windowList;

MyWidget::MyWidget(QWidget *,const char *name) // ( QWidget *parent, const char *name )
//        : QWidget( parent, name )
    :KTopLevelWidget(name)
{
    QAccel *qa;
    KConfig *config;
    char eMessage[FNAME_MAX];
    pid_t pid;
    tyhjennaTaulukko(eMessage,FNAME_MAX);
    strcpy(eMessage,"KDE Xunzip ");
    strcat(eMessage,VERSION);

    // windows can delete themselves
    windowList.setAutoDelete(FALSE);

    // add the window
    windowList.append(this);
	    
    selected_file=-1;
    
    config=kapp->getConfig();

    setCaption(eMessage);

    tyhjennaTaulukko(eMessage,FNAME_MAX);
    pid=getpid();
    sprintf(eMessage,"/tmp/kxunzip.%d",(int)pid);
    mkdir(eMessage,0755);

    setMinimumSize( 300, 250 );
    setMaximumSize( 970, 500 );
    resize(350,250);
    
    kfm=new KFM;
/*
    quit = new QPushButton( "Quit", this, "quit" );
    quit->setGeometry( 190, 10, 55, 25 );
    quit->setFont( QFont( "Charter", 14, QFont::Bold ) );

    connect( quit, SIGNAL(clicked()), qApp, SLOT(quit()) );
    
    open=new QPushButton("Open",this,"open");
    open->setGeometry(5,10,55,25);
    open->setFont(QFont("Charter",14,QFont::Bold));
    connect(open,SIGNAL(clicked()),SLOT(openfile()));
    
    unzip=new QPushButton("Extract",this,"extract");
    unzip->setGeometry(65,10,55,25);
    unzip->setFont(QFont("Charter",14,QFont::Bold));
    connect(unzip,SIGNAL(clicked()),SLOT(unzipfile()));
    
    test=new QPushButton("Test",this,"test");
    test->setGeometry(125,10,60,25);
    test->setFont(QFont("Charter",14,QFont::Bold));
    connect(test,SIGNAL(clicked()),SLOT(testfile()));
*/
    createPopupMenu();
    createMenu();
    createToolbar();
    
	msg=new KStatusBar(this);
	msg->insertItem((char*)klocale->translate("  ***** Welcome to Xunzip *****  "),0);
	msg->insertItem("100%",1);
	msg->changeItem(" ",1);
	setStatusBar(msg);

    // fmain=new QFrame(this,"frame_0");
    // int colpos=0;
    
    lista=new KTabListBox( this );
    lista->setSeparator('\t');
    setView(lista);
    lista->setNumCols(5);
    lista->setColumn(0,klocale->translate("Name"),100);
    lista->setColumn(1,klocale->translate("Date"),70);
    lista->setColumn(2,klocale->translate("Ratio"),40);
    lista->setColumn(3,klocale->translate("Size"),70);
    lista->setColumn(4,klocale->translate("Packed"),this->width()-280);
    
/*    int twidth=0;
    for( int ii=0; ii<3; ii++ )
	    twidth+=lista->cellWidth( ii );
    lista->setColumnWidth( 3, ((this->width())-twidth) ); */
    /* if( lista->colXPos( 2, &colpos ) )
	    lista->setColumnWidth( 2, ((this->width())-colpos) );*/

    // lista->setGeometry(5,45,240,150);
    connect(lista,SIGNAL(highlighted(int,int)),SLOT(listItemSelected(int,int)));
    connect(lista,SIGNAL(popupMenu(int,int)),this,SLOT(showPopupMenu(int,int)));
    
    qa=new QAccel(this);
    qa->connectItem(qa->insertItem(Key_Enter),this,SLOT(viewfile()));
    qa->connectItem(qa->insertItem(Key_Return),this,SLOT(viewfile()));
        
    KDNDDropZone *dz = new KDNDDropZone( lista, DndURL );
    connect( dz, SIGNAL(dropAction(KDNDDropZone *)),SLOT( fileDrop(KDNDDropZone *)) ); 
/*    
    msg=new QLabel(this,"message");
    msg->setFrameStyle(QFrame::Panel|QFrame::Sunken);
    msg->setFont( QFont("times",12,QFont::Bold) );
    msg->setAlignment( AlignLeft );
    msg->setGeometry(5,200,240,20);
*/
	
    tb->show();
    // fmain->show();
    lista->show();
    msg->show();
    mainmenu->show();
    
    updateRects();
}

MyWidget::~MyWidget()
{
    TKString s,t;
    pid_t pid;
    char eMessage[FNAME_MAX];
    tyhjennaTaulukko(eMessage,FNAME_MAX);
    
    windowList.removeRef(this);
    
    pid=getpid();
    sprintf(eMessage,"/tmp/kxunzip.%d",(int)pid);
    while(!tmpList.atEnd())
      {
	s=tmpList.getNext();
	TK_ASSERT(1,cout << "Removing " << s << "..." << endl;);
	unlink(s.getStr());
      }
    if (windowList.count()<2)
      rmdir(eMessage);
    tmpList.removeAll();
    if (kfm) delete kfm;
    if (mainmenu) delete mainmenu;
    if (msg) delete msg;
    if (tb) delete tb;
    if (lista) delete lista;
    // if (pop) delete pop; // this causes segmentation faults
}

void MyWidget::closeWindow()
{
// quit app if closing last window
	if( windowList.count() > 1 )
		close(TRUE); // no need to quit app
	else
		qApp->quit();
}

void MyWidget::resizeEvent( QResizeEvent *re )
{
    int col = lista->numCols()-1;
    int colpos=0;
    KTopLevelWidget::resizeEvent( re );
    
    lista->resize( lista->width(), lista->height() );
    if( lista->colXPos( col, &colpos ) )
	    lista->setColumnWidth( col, ((this->width())-colpos) );
}

/* luodaan popup menu */
void MyWidget::createPopupMenu(void)
{
    pop=new QPopupMenu;
    CHECK_PTR(pop);
    pop->insertItem(klocale->translate("Extract..."),this,SLOT(unzipfile()));
    pop->insertItem(klocale->translate("View"),this,SLOT(viewfile()));    
//    pop->insertItem(klocale->translate("View"),this,SLOT());
    
}

void MyWidget::showPopupMenu(int row,int col)
{
    lista->setCurrentItem(row,col);
    pop->popup(QCursor::pos(),KPM_FirstItem);
}

/* luodaan normaali menu */
void MyWidget::createMenu(void)
{
  QPopupMenu *mfile,*mactions,*help;

  mfile=new QPopupMenu;
  CHECK_PTR(mfile);
  mfile->insertItem(klocale->translate("&New window"),this,SLOT(createNew()));
  mfile->insertSeparator();
  mfile->insertItem(klocale->translate("&Open file..."),this,SLOT(openfile()),CTRL+Key_O);
  mfile->insertItem(klocale->translate("&Close file"),this,SLOT(closefile()),CTRL+Key_C);
  mfile->insertSeparator();
  mfile->insertItem(klocale->translate("&Close"),this,SLOT(closeWindow()),CTRL+Key_W);
    
  mactions=new QPopupMenu;
  CHECK_PTR(mactions);
  mactions->insertItem(klocale->translate("&Extract"),this,SLOT(unzipfile()),CTRL+Key_E);
  mactions->insertItem(klocale->translate("&Test"),this,SLOT(testfile()),CTRL+Key_T);
  mactions->insertItem(klocale->translate("&View"),this,SLOT(viewfile()),CTRL+Key_V);
  help=kapp->getHelpMenu(true,klocale->translate("Xunzip --- (g)zip unpacker\nDistributed under GPL\n(c) 1998 Tero Koskinen\n"));
    
	    
  mainmenu=new KMenuBar(this,"main menu");
  CHECK_PTR(mainmenu);
  if (mainmenu)
    {
      mainmenu->insertItem(klocale->translate("&File"),mfile);
      mainmenu->insertItem(klocale->translate("&Actions"),mactions);
      mainmenu->insertSeparator();
      mainmenu->insertItem(klocale->translate("&Help"),help);
      // mainmenu->show();
      setMenu(mainmenu);
    }
}

void MyWidget::createToolbar(void)
{
    // bool status;
    KIconLoader *loader=kapp->getIconLoader();
    
    QPixmap pix;
    // QString ppath;
    // status=loader->insertDirectory(3,PRIVATE_ICON_PATH);
    // status=true;
        
    // ppath=kapp->kdedir()+QString("/share/toolbar/");
    tb=new KToolBar(this,"toolbar");
    
    // pix.load(ppath+"fileopen.xpm");
    pix=loader->loadIcon("fileopen.xpm");
    tb->insertButton(pix,0,SIGNAL(clicked()),this,SLOT(openfile()),TRUE,klocale->translate("Open"));

    //pix.load(ppath+"viewzoom.xpm");
    // if (status==true)
    // {
	    pix=loader->loadIcon("unzip.xpm");
	/*    TK_ASSERT(1,cout << "toolbaricon loaded via KIconLoader " << status << endl;);
	    TK_ASSERT(1,cout << PRIVATE_ICON_PATH << endl;);
    }
    else
	    pix.load(PRIVATE_ICON_PATH+"unzip.xpm"); */

    tb->insertButton(pix,1,SIGNAL(clicked()),this,SLOT(unzipfile()),TRUE,klocale->translate("Extract..."));
    pix=loader->loadIcon("viewzoom.xpm");
    tb->insertButton(pix,2,SIGNAL(clicked()),this,SLOT(viewfile()),TRUE,klocale->translate("View selected file"));

    tb->insertSeparator();
    // pix.load(ppath+"exit.xpm");
    pix=loader->loadIcon("exit.xpm");
    tb->insertButton(pix,3,SIGNAL(clicked()),this,SLOT(closeWindow()),TRUE,klocale->translate("Close window"));

    addToolBar(tb);
    tb->setBarPos(KToolBar::Top);
    enableToolBar(KToolBar::Show);
}


void MyWidget::createNew()
{
  MyWidget *w=new MyWidget();
  w->show();
}


// open archive
void MyWidget::openfile()
{
  //  char eMessage[40];
  QString fileName=QFileDialog::getOpenFileName();
  QProgressDialog progress(klocale->translate("Opening file..."),klocale->translate("Cancel"),3,this,"progress",true);
  if (!fileName.isNull())
    {
      // cout << fileName << endl;
      msg->changeItem((char*)klocale->translate("Opening...please wait..."),0);
      updateRects();
      if (zip.open(fileName,lista,0,QString("url:"),&progress)<0)
	showError(klocale->translate("Cannot open the file "),fileName);
      else
	{
	  /*	  tyhjennaTaulukko(eMessage,40);
	  strcpy(eMessage,"KDE Xunzip ");
	  strcat(eMessage,VERSION); */
	  setCaption(zip.getArchiveName());
	}
      msg->changeItem((char*)klocale->translate("Xunzip"),0);
    }
}

void MyWidget::closefile()
{
  char eMessage[40];
  tyhjennaTaulukko(eMessage,40);
  zip.close(lista);
  selected_file=-1;
  msg->changeItem((char*)klocale->translate("Xunzip"),0);
  strcpy(eMessage,"KDE Xunzip ");
  strcat(eMessage,VERSION);
  
  setCaption(eMessage);
}

// unzip file(s) from packet
void MyWidget::unzipfile()
{
    QString d;
    DirDialog *dir;
    dir=new DirDialog();
    int opts;
    if (zip.getType()==3) // ARJ-file
      {
	showMessage("Uncompression of ARJ not supported!");
	return;
      }
    QProgressDialog progress(klocale->translate("Uncompressing file..."),klocale->translate("Cancel"),zip.getFiles(),this,"progress",true);
    msg->changeItem(klocale->translate("Uncompressing..."),0);
    msg->changeItem("0%",1);
    if (dir->exec())
    {
	    int sfile=-1;
	    d=dir->getPath();
	    opts=dir->getOptions();
	    if (opts&SELECTED_FILE)
		    sfile=selected_file;
		else
		    sfile=-1;
	    if (d.isNull())
			return;
		if (zip.unZip(d,sfile,opts,&progress,msg,this)<0)
		{
		    showError(klocale->translate("Cannot extract to the directory "),d);
		}
	}
	msg->changeItem(klocale->translate("Xunzip"),0);
	msg->changeItem(" ",1);
}

// test files in packet
void MyWidget::testfile()
{
    TestWindow *tw;
    tw=new TestWindow(zip);
}

void MyWidget::viewfile()
{
    char eMessage[FNAME_MAX];
    TKString s,e;
    pid_t pid;
    tyhjennaTaulukko(eMessage,FNAME_MAX);
    pid=getpid();
    // TK_ASSERT(1,cout << "Viewing file..." << endl);
    if (selected_file>=0)
      {
	QProgressDialog progress(klocale->translate("Viewing file..."),klocale->translate("Cancel"),zip.getFiles(),this,"progress",true);
	sprintf(eMessage,"/tmp/kxunzip.%d/",(int)pid);
	if (zip.isTmpFile() && (zip.getType()==2 || zip.getType()==4))
	  e=zip.getUrl();
	else
	  e=zip.getName(selected_file);
	s=eMessage;
	TK_ASSERT(1,cout << (s+e) << endl;);
	TK_ASSERT(1,cout << "viewing file type: " << zip.getType() << endl);

	tmpList.add((s+e));
	if (zip.unZip(s,selected_file,SELECTED_FILE,&progress)<0)
	  {
	    showError(klocale->translate("Cannot view file "),(s+e));
	  }
	else
	  {
	    s+=e;
	    e="file:";
	    s=e+s;
	    TK_ASSERT(1,cout << "kfm->exec(" << s << ",0L);" << endl;);
	    kfm->exec(s,0L);
	  }
      }
}

void MyWidget::listItemSelected(int i,int col=0)
{
    // char eMessage[FNAME_MAX+100];
    unsigned long a=0,b=col;
    TKString apu;
    CDRNode *p;
    p=zip.getNode(i);
    if (p)
    {
	    a=p->h.getUnCSize();
	    b=p->h.getCSize();
	    
	    apu=TKString(p->h.getFilename()); // +TKString(" ")+itoa(b)+TKString("/")+itoa(a)+TKString(" bytes");
	    msg->changeItem((char*)klocale->translate(apu.getStr()),0);
	    selected_file=i;
	}
    else if (zip.getType()==2 || zip.getType()==4)
      selected_file=i;
    /*    else
	  selected_file=i; */
}

void MyWidget::fileDrop(KDNDDropZone *dz)
{
    // QStrList dlist;
    QString url;
    // QString file;
    // char *foo;
    
    url=dz->getURLList().first(); /* ennen dlist=dz->getURLList(); */
    if (!url.isNull())
	    kfmOpen(url);

/*  Vanha tapa...ei toimi "ftp:// tai http://" linkkien kanssa
    url=dlist.at(0);
    file=url.right(url.length()-5);
    foo=file.data();
    if (foo[strlen(foo)-1] != '/')
    {
	    zip.open(file,lista);
	}
*/

}

// Tassa ei tunnisteta annetun tiedoston tyyppia vaan suoraan
// pyydetaan kfm:aa avaamaan se
void MyWidget::kfmOpen(const QString url)
{
    QString file;
    QProgressDialog progress(klocale->translate("Opening file..."),klocale->translate("Cancel"),3,this,"progress",true);
    if (KFM::download(url,file))
    {
	    TK_ASSERT(1,cout << file << endl;);
	    if (zip.open(file,lista,1,url,&progress)<0)
	    {
		    showError(klocale->translate("Cannot open file "),url);
		    KFM::removeTempFile(file);
		}
	}
}

// yritetaan tunnistaa url:n tyyppi
// jos kyseessa on tavallinen tiedosto
// avataan se normaaliin tapaan, muuten
// pyydetaan kfm:aa siirtamaan se ensin omalle koneelle
void MyWidget::kfmOpen(const char *url)
{
    int a=0;
    if (strncmp(url,"ftp://",6)==0 || strncmp(url,"file:",5)==0 || strncmp(url,"http://",7)==0)
	    a=1;
    QString file;
    QProgressDialog progress(klocale->translate("Opening file..."),klocale->translate("Cancel"),3,this,"progress",true);
    if (a==1)
    {
	    if (KFM::download(url,file))
	    {
		    TK_ASSERT(1,cout << file << endl;);
		    if (zip.open(file,lista,1,url,&progress)<0)
		    {
			    showError(klocale->translate("Cannot open file"),url);
			    KFM::removeTempFile(file);
			}
	    }
	}
	else
	{
	    if (zip.open(url,lista,0,QString("url:"),&progress)<0)
	    {
		    showError(klocale->translate("Cannot open file"),url);
		}
	}
}


TestWindow::TestWindow(ZipPacket & zip,QWidget *parent=0,const char *name=0):
QWidget(parent,name)
{
    setCaption("Test");

    setMinimumSize( 200, 200 );
    setMaximumSize( 200, 200 );
    
    msg=new QLabel(this,"label");
    // msg->setFrameStyle(QFrame::Panel|QFrame::Sunken);
    msg->setFont( QFont("times",12,QFont::Bold) );
    msg->setAlignment( AlignLeft );
    msg->setGeometry(5,5,190,20);
    msg->setText(klocale->translate("Wait..."));
    
    lista1=new QListBox( this, "virhelista" );
    lista1->setGeometry(5,26,190,140);
    // connect(lista,SIGNAL(selected(int)),SLOT(listItemSelected(int)));
    
    ok=new QPushButton(klocale->translate("Ok"),this,"ok");
    ok->setGeometry(80,171,30,25);
    connect(ok,SIGNAL(clicked()),SLOT(closeWindow()));
    show();
    update();
        
    zip.testcrc(lista1);
    msg->setText(klocale->translate("Errors"));
    
}

TestWindow::~TestWindow()
{
    lista1->clear();
}

DirDialog::DirDialog(QWidget *parent=0,char *name=0) :
    QDialog(parent,name,TRUE)
{

    QButtonGroup *gb=new QButtonGroup(klocale->translate("Options"),this);
    gb->setAlignment(AlignLeft);
    gb->setGeometry(10,100,190,160);

    QGroupBox *g1=new QGroupBox(klocale->translate("Directory"),this);
    g1->setAlignment(AlignLeft);
    g1->setGeometry(10,10,200,80);
    QGroupBox *g2=new QGroupBox(klocale->translate("Extract"),this);
    g2->setAlignment(AlignLeft);
    g2->setGeometry(220,10,80,110);
    
    le=new QLineEdit(this);
    le->setGeometry(30,40,160,20);
    le->setText(getenv("HOME"));
    
    setCaption(klocale->translate("Extract"));
	
    rb1=new QRadioButton(klocale->translate("All files"),gb);
    rb1->setGeometry(10,20,160,30);
    rb1->setEnabled(TRUE);
	
    rb2=new QRadioButton(klocale->translate("Selected file"),gb);
    rb2->setGeometry(10,50,160,30);
    rb2->setEnabled(TRUE);
	
    rb1->setChecked(TRUE);
	
    cb1=new QCheckBox(klocale->translate("Lowercase names"),this);
    cb1->setGeometry(20,180,160,30);
    cb1->setEnabled(TRUE);
	
    cb2=new QCheckBox(klocale->translate("Set orig. time"),this);
    cb2->setGeometry(20,210,160,30);
    cb2->setEnabled(TRUE);

    QPushButton *b1=new QPushButton(klocale->translate("Ok"),this);
    b1->setGeometry(230,30,60,30);
    connect(b1,SIGNAL(clicked()),SLOT(accept()));
	
    QPushButton *b2=new QPushButton(klocale->translate("Cancel"),this);
    b2->setGeometry(230,70,60,30);
    connect(b2,SIGNAL(clicked()),SLOT(reject()));
}

const char *DirDialog::getPath(void)
{
    return le->text();
}


#endif

