// -*-c++-*-
/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

#include <fstream.h>

#ifdef USE_GTK
#include <gtk/gtk.h>
#include <gnome.h>
#else
#include <qapp.h>
#include <qlistbox.h>
#include <qprogdlg.h> 
#include <ktablistbox.h>
#include <kstatusbar.h>
#include <qstring.h>
#endif

#include <zlib.h>

#include "config.h"
#include "utils.h"
#include "zipheader.h"
#include "debug.h"
#include "sll.h" // yet another single linked list...

#ifndef TK_COMPRESS_H
#define TK_COMPRESS_H

class Compress
{
public:
  Compress();
  ~Compress();
  
  int gzip_compress(const char *infile,int deleteFile=0);
  const int GZIP_BUFFER_LEN=16384;
private:
  int gz_compress(FILE *in,gzFile out);
};

#endif
