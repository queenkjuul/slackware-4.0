/*

    Simple linked list
    
    (c) Tero Koskinen 1998
    
*/

#include "linkedlist.h"
#include "tkstring.h"

LL_Node::LL_Node(TKString s)
{
    data=s;
    next=0;
}

LL_Node::LL_Node()
{
    next=0;
}

TKString LL_Node::getData(void)
{
    return data;
}

LL_Node* LL_Node::getNext(void)
{
    return next;
}

void LL_Node::setNext(LL_Node *n)
{
    if (next)
	    next->setNext(n);
	else
	    next=n;
}

LL::LL()
{
    root=0;
    current=0;
}

LL::~LL()
{
    removeAll();
    root=0;
    current=0;
}

int LL::add(TKString s)
{
    LL_Node *p;
    
    p=new LL_Node(s);
    if (!p)
	    return 0;
    if (!root)
    {
	    root=p;
	    current=root;
	}
	else
	{
	    root->setNext(p);
	}
	return 1;
}

void LL::removeAll(void)
{
    LL_Node *p;
    LL_Node *o;
    if (root)
    {
	    p=root;
	    o=root->getNext();
	    while(p)
	    {
		    delete p;
		    p=o;
		    if (p)
			    o=p->getNext();
		}
    }
    root=0;
    current=0;
}

TKString LL::getFirst(void)
{
    if (root)
    {
	    current=root->getNext();
	    return root->getData();
	}
	return TKString();
}

TKString LL::getNext(void)
{
    if (current)
    {
	    LL_Node *p=current;
	    current=current->getNext();
	    return p->getData();
	}
	return TKString();
}

int LL::atEnd(void)
{
    if (!current)
    {
	    if (root)
		    current=root;
		return 1;
	}
	return 0;
}

