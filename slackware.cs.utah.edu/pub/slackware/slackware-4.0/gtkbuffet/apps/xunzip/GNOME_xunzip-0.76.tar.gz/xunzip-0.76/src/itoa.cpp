/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

// itoa.c, taken from my ircbot rutins
// sprintf() would be better...

#include "itoa.h"
#include "tkstring.h"

TKString itoa(int numero)
{
  const char ia[11+1]="0123456789\0";
  TKString luku;
  int a=numero;

  if (a<0)
    {
      luku=TKString("-",1);
      a=-a;
    }
  if (a!=0)
    {
      while(a!=0)
	{
	  int b=a%10;
	  a-=b;
	  a=(int)(a/10);
	  luku=TKString(&ia[b],1)+luku;
	}
    }
  else
    luku=TKString("0",1);
  return luku;
}

TKString itoa(unsigned int numero)
{
  const char ia[11+1]="0123456789\0";
  TKString luku;
  unsigned int a=numero;

/*  if (a<0)
    {
      luku=TKString("-",1);
      a=-a;
    } */
  if (a!=0)
    {
      while(a!=0)
	{
	  int b=a%10;
	  a-=b;
	  a=(int)(a/10);
	  luku=TKString(&ia[b],1)+luku;
	}
    }
  else
    luku=TKString("0",1);
  return luku;
}

TKString itoa(unsigned long numero)
{
  const char ia[11+1]="0123456789\0";
  TKString luku;
  unsigned long a=numero;

/*  if (a<0)
    {
      luku=TKString("-",1);
      a=-a;
    } */
  if (a!=0)
    {
      while(a!=0)
	{
	  int b=a%10;
	  a-=b;
	  a=(int)(a/10);
	  luku=TKString(&ia[b],1)+luku;
	}
    }
  else
    luku=TKString("0",1);
  return luku;
}

