/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

// utils.cpp

#include <fstream.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

#ifdef USE_GTK
#include <gtk/gtk.h>
#include <gnome.h>
#else
#include <qapp.h>
#include <qlistbox.h>
#include <qdialog.h>
#include <qmsgbox.h>

#include <kapp.h>
#include <kmsgbox.h>

#endif

#include "itoa.h"
#include "tkstring.h"
#include "utils.h"
#include "config.h"

#include "debug.h"

unsigned int readbyte(ifstream & fin)
{
    unsigned char ch=0;
    fin.get(ch);
    return ch;
}

unsigned int readint(ifstream & fin,int way)
{
  char ch;
  unsigned int a;
  if (way==0)
  {
      fin.get(ch);
      a=ch;
      fin.get(ch);
      a+=(ch<<8);
  }
  else
      fin.read((char*)&a,2);

  return a;
}

unsigned long readlong(ifstream & fin)
{
    // char a,b,c,d;
    unsigned long longtmp;
    // fin.get(a).get(b).get(c).get(d);
    fin.read((char*)&longtmp,4);
    return (longtmp);
}

void makedirs(const char *path)
{
    char dirname[FNAME_MAX]; // riittaakohan 1024 polun kooksi
    char *cp;
    
    strcpy(dirname,path);
    cp=dirname;
	while((cp=strchr(cp,'/')))
	{
	    *cp=0;
	    mkdir(dirname,DIRMODE);
	    *cp++='/';
	}
}

void tyhjennaTaulukko(char *taulukko,int koko)
{
    for (int a=0;a<koko;a++)
	    taulukko[a]='\0';
}

#ifdef USE_GTK
// tuhoa ilmoitusdialogi(showMessagen luoma)
/*
void delete_show_message (GtkWidget *, GtkWidget *data)
{
  gtk_widget_hide(data);
  gtk_widget_destroy(data);
}
*/

void my_system(const char *cmd)
{
    int pid;
    if (cmd==0)
	    return;
    pid=fork();
    if (pid==0)
    {
	    char *argv[4];
	    argv[0]="sh";
	    argv[1]="-c";
	    argv[2]=(char*)cmd;
	    argv[3]=0;;
	    execve("/bin/sh",argv,environ);
	    exit(127);
	}
}
#endif
// naytetaan haluttu viesti
void showMessage(const char *ilmoitus)
{
#ifdef USE_GTK
/*
  GtkWidget *label;
  GtkWidget *button;
  GtkWidget *window;
  GtkWidget *box;
  
  window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window), "Message");
  gtk_signal_connect(GTK_OBJECT (window), "destroy",(GtkSignalFunc) delete_show_message,window);
  // gtk_signal_connect(GTK_OBJECT (window), "delete_event",(GtkSignalFunc) delete_show_message,window);
  gtk_container_border_width (GTK_CONTAINER (window), 10);
  box=gtk_hbox_new(FALSE,0);
  gtk_container_add(GTK_CONTAINER(window),box);
  label = gtk_label_new (ilmoitus);
  gtk_misc_set_padding (GTK_MISC (label), 10, 10);
  gtk_box_pack_start (GTK_BOX (box), label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  button = gtk_button_new_with_label ("OK");
  gtk_signal_connect(GTK_OBJECT (button), "clicked",(GtkSignalFunc) delete_show_message,window);
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_widget_show(button);
  gtk_box_pack_start (GTK_BOX (box), button, TRUE, TRUE, 0);
  gtk_widget_grab_default (button);
  gtk_widget_show(box);
  gtk_widget_show(window);
*/
    GtkWidget *w;
    w=gnome_message_box_new(_(ilmoitus),GNOME_MESSAGE_BOX_GENERIC,
						  GNOME_STOCK_BUTTON_OK, NULL);
    gtk_widget_show(w);
#else
  // QMessageBox::message(klocale->translate("Message"),ilmoitus);
    KMsgBox::message(0,klocale->translate("Message"),ilmoitus);
#endif
}

void showError(const char *text,int size,const char *filename)
{
    
    char eMessage[FNAME_MAX+30];
    tyhjennaTaulukko(eMessage,FNAME_MAX+30);
    strncpy(eMessage,text,size);
    strcat(eMessage,filename);
#ifdef USE_GTK
    GtkWidget *w;
    w=gnome_message_box_new(_(eMessage),GNOME_MESSAGE_BOX_ERROR,
						  GNOME_STOCK_BUTTON_OK, NULL);
    gtk_widget_show(w);
#else    
    showMessage(eMessage);
#endif
}

void showError(const char *text,const char *filename)
{
    int len=strlen(text);
    char eMessage[FNAME_MAX+30];
    if (len>FNAME_MAX+30)
	    len=FNAME_MAX+30;
    tyhjennaTaulukko(eMessage,FNAME_MAX+30);
    strncpy(eMessage,text,len);
    strcat(eMessage,filename);
#ifdef USE_GTK
    GtkWidget *w;
    w=gnome_message_box_new(_(eMessage),GNOME_MESSAGE_BOX_ERROR,
						  GNOME_STOCK_BUTTON_OK, NULL);
    gtk_widget_show(w);
#else    
    showMessage(eMessage);
#endif
}

TKString convertDate(unsigned int d)
{
    unsigned int yr,mo,dy;
    TKString mdate;
    
    yr=((d>>9)&0x7f)+1980;
    mo=((d>>5)&0x0f);
    dy=d&0x1f;
    
    // TK_ASSERT(1,printf("yr:%d mo:%d dy:%d\n",yr,mo,dy););
    
    mdate=itoa(dy)+"-"+itoa(mo)+"-"+itoa(yr);
    return mdate;
}

TKString convertArjDate(unsigned int d)
{
	return convertDate(d);
}
