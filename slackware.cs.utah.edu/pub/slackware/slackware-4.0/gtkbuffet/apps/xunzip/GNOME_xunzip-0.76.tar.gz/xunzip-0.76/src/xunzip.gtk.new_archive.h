// -*-c++-*-
/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

// xunzip.gtk.cpp
// I am sorry about mixture of finnish and english comments :)

#ifdef USE_GTK

#include <unistd.h>
#include <fstream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

#include <gnome.h>

#include "zipheader.h"
#include "utils.h"
#include "config.h"
#include "tkstring.h"
#include "itoa.h"
#include "debug.h"
#include "linkedlist.h"
// #include "xunzip.gtk.h"
#include "zippacket.h"

#ifndef TK_NEW_ARCHIVE_H
#define TK_NEW_ARCHIVE_H

void cancel_event(GtkWidget *,GtkWidget *me);
void create_new_archive_selection(void);
void compress_it_event(GtkWidget *,GtkWidget *);
void add_event(GtkWidget *,GtkWidget *);

#endif

#endif // USE_GTK
