/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/



#include <stdio.h>
#include <stdlib.h>
#include <zlib.h>

#include "config.h"
#include "debug.h"

#ifdef USE_BZIP2

#include "bzip2.h"

#include "my_bzip2.h"

#ifdef USE_GTK
int openBzip2(char *file,GtkWidget *lista,int)
// the name of the last parameter is tmpfile,
// please add it if needed
#else
int openBzip2(const char *file,KTabListBox *lista,int tmpfile,QString url,QString & fileUrl)
#endif
{
  int a=0;
  int c=0;
  char bzSuffix[]="bz2";
  // bzSuffix[2]='2';bzSuffix[1]='z';bzSuffix[0]='b';

  TKString name;
  TK_ASSERT(1,cout << "Testing file " << file << endl;);
  a=testf_(file);
  if (a!=0)
    {
      TK_ASSERT(1,cout << "bzip2: testf_ result = "  << a << endl;);
      return 1;
    }
  a=0;
#ifndef USE_GTK
  if (tmpfile==0)
    {
#endif
      a=strlen(file)-1;
      c=2;
      while(file[a]==bzSuffix[c] && a>=0 && c>=0) 
	{
	  // TK_ASSERT(1,cout << "file[a]: " << file[a] << " bzSuffix: " << bzSuffix[c] << endl;);
	  a--;
	  c--;
	}
      
      if (file[a]=='.')
	a--;
      name=TKString(file,a+1);
#ifndef USE_GTK
    }
  else
    {
      a=strlen(url)-1;
      c=2;
      while(url[a]==bzSuffix[c] && a>=0 && c>=0)
	{
	  a--;
	  c--;
	}
      /* if (url[a]=='.')
	 a--; */
      name=TKString(url,a);
      TK_ASSERT(1,cout << "filename = " << name << endl;);
    }      
#endif
  TKString name2;
  int g=strlen(name)-1;
  while(name[g]!='/') { if (g<0) break; g--; }
  if (name[g]=='/')
    g++;
  name2=TKString(name.getStr()+g);
#ifndef USE_GTK
  if (tmpfile)
      fileUrl=name2.getStr();
#endif
  TK_ASSERT(1,cout << "Add to list name " << name2 << endl);
  name=name2;

  TK_ASSERT(1,cout << "filename: " << name << " a: " << a << endl;);

#ifdef USE_GTK
  const char *ctmp[5];
  ctmp[0]=(const char *)name.getStr();
  ctmp[1]=(const char *)NULL;
  ctmp[2]=(const char *)NULL;
  ctmp[3]=(const char *)NULL;
  ctmp[4]=(const char *)NULL;
  int r=gtk_clist_append(GTK_CLIST(lista),(char**) ctmp);
  gtk_clist_set_row_data(GTK_CLIST(lista), r, name);
#else
  QString str;
  str=name;
  str+=QString("\t?\t?\t?\t?");
  lista->insertItem(str);
#endif // USE_GTK

  return 0;
}

int uncompressBzip2(const char *infile,const char *outfile)
{
  TK_ASSERT(1,cout << "uncompress " << infile << " to " << outfile << endl;);
  int status=uncompress_(infile,outfile);
  TK_ASSERT(status,cout << "Error: " << status << endl;);
  if (status<0)
    return Z_ERRNO;
  return Z_OK;
}

#endif // USE_BZIP2
