/*
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/
// tkstring.cpp

#include <iostream.h>
#include <string.h>
#include <ctype.h>

#include "tkstring.h"

TKString::TKString()
{
    myStr=new char[1];
    myStr[0]='\0';
    myLength=0;
}

TKString::TKString(int size)
{
    if (size>0)
    {
	    myStr=new char[size+1];
	    for (int a=0;a<size;a++)
		    myStr[a]='\0';
		myLength=size;
    }
}

TKString::TKString(const char *str,int size)
{
    myLength=size;
    if (size>0)
    {
	    myStr=new char[myLength+1];
	    for (unsigned int a=0;a<myLength;a++)
		    myStr[a]=str[a];
		myStr[myLength]='\0';
	}
	else
	{
	    myStr=new char[1];
	    myStr[0]='\0';
	    myLength=0;
    }
}


TKString::TKString(const char *str)
{
    if (str!=0)
    {
	    myLength=strlen(str);
	    myStr=new char[myLength+1];
	    for (unsigned int a=0;a<myLength;a++)
		    myStr[a]=str[a];
	    myStr[myLength]='\0';
	}
	else
	{
	    myStr=new char[1];
	    myStr[0]='\0';
	    myLength=0;
    }
}

TKString::TKString(const TKString & t)
{
    myLength=t.length();
    myStr=new char[myLength+1];
    for (unsigned int a=0;a<myLength;a++)
	    myStr[a]=t[a];
	myStr[myLength]='\0';
}

TKString::~TKString()
{
    if (myStr)
	    delete myStr;
}

TKString & TKString::operator=(const TKString & t)
{
    if (this == &t)
	    return *this;
	delete [] myStr;
	myLength=t.length();
	myStr=new char[myLength+1];
	for (unsigned int a=0;a<myLength;a++)
	    myStr[a]=t[a];
	myStr[myLength]='\0';
	return *this;
}

TKString & TKString::operator=(const char *t)
{
    if (myStr == t)
	    return *this;
    if (t)
    {
	delete [] myStr;
	myLength=strlen(t);
	myStr=new char[myLength+1];
	for (unsigned int a=0;a<myLength;a++)
	    myStr[a]=t[a];
	myStr[myLength]='\0';
    }
	return *this;
}

char & TKString::operator[](unsigned int p)
{
    if (p>myLength)
	    return myStr[myLength-1];
    return myStr[p];
}

char TKString::operator[](unsigned int p) const
{
    if (p>myLength)
	    return myStr[myLength-1];
    return myStr[p];
}

unsigned int TKString::length(void) const
{
    return myLength;
}

TKString TKString::lcase(void)
{
    unsigned int a=0,b=0;
    b=myLength;
    TKString tmp(b);
    for (a=0;a<myLength;a++)
	    tmp[a]=tolower(myStr[a]);
	tmp[myLength]='\0';
	return tmp;
}

TKString TKString::operator+(const TKString & t)
{
    unsigned int a=0,b=0;
    
    b=myLength+t.length();
    TKString tmp(b);
    for (a=0;a<myLength;a++)
	    tmp[a]=myStr[a];
	for (unsigned int c=0;c<t.length();c++,a++)
	    tmp[a]=t[c];
	tmp[b]='\0';
	return tmp;
}

TKString TKString::operator+(const char *str)
{
    unsigned int a=0,b=0;
    
    b=myLength+strlen(str);
    TKString tmp(b);
    for (a=0;a<myLength;a++)
	    tmp[a]=myStr[a];
	for (unsigned int c=0;c<strlen(str);c++,a++)
	    tmp[a]=str[c];
	tmp[b]='\0';
	return tmp;
}

void TKString::operator+=(const TKString & t)
{
    unsigned int a=0,b=0;
    
    b=myLength+t.length();
    TKString tmp(b);
    for (a=0;a<myLength;a++)
	    tmp[a]=myStr[a];
	for (unsigned int c=0;c<t.length();c++,a++)
	    tmp[a]=t[c];
	tmp[b]='\0';
	*this=tmp;
}

void TKString::operator+=(const char *str)
{
    unsigned int a=0,b=0;
    
    b=myLength+strlen(str);
    TKString tmp(b);
    for (a=0;a<myLength;a++)
	    tmp[a]=myStr[a];
	for (unsigned int c=0;c<strlen(str);c++,a++)
	    tmp[a]=str[c];
	tmp[b]='\0';
	*this=tmp;
}

TKString::operator const char *() const
{
    return (const char*)myStr;
}

int wordLenght(const char *sentence)
{
	int a=0,b=0;
	
    while(sentence[a+b]==' ') b++; // skip space
    
    while(isalpha(sentence[a+b])) a++;
    
    return a;
}

int stringLenght(const char *sentence)
{
    int a=0;
    while(sentence[a]!=' ' && sentence[a]!='\n' && sentence[a]!='\0' && sentence[a]!='\r')
	    a++;
	return a;
}

int nextWord(const char *sentence)
{
    int a=0;
    while(sentence[a]==' ') a++;
    
	while(isalpha(sentence[a]))
	    a++;
	    
	while(sentence[a]==' ') a++;
	if (sentence[a]=='\n' || sentence[a]=='\0' || sentence[a]=='\r')
	    return -1;
	
	return a;
}

int nextString(const char *sentence)
{
    int a=0;
    while(sentence[a]==' ') a++;
	while(sentence[a]!=' ' && sentence[a]!='\n' && sentence[a]!='\0' &&  sentence[a]!='\r')
	    a++;
	    
	while(sentence[a]==' ') a++;
	if (sentence[a]=='\n' || sentence[a]=='\0' || sentence[a]=='\r')
	    return -1;
	
	return a;
}

