// debug.h


#ifndef TK_DEBUG_H
#define TK_DEBUG_H

/* #define TK_DEBUG */ /* DEBUG on/off? */

#ifdef TK_DEBUG
#define TK_ASSERT(x,y) if ((x)) y;
#else
#define TK_ASSERT(x,y)
#endif

#endif
