/* GNOME Xunzip - tar archive functions
   Copyright (c) 1999 Tero Koskinen
   

   tar.cpp: converted from tar.c in Chris Rogers' gxTar

 */

/* gxTar - Gnomified Archive Frontend
 * Copyright (C) 1998 Chris Rogers
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option) 
 * any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
 * GNU General Public License for more details.
 *  
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 * 02111-1307, USA.
 */

int tar_read(gchar * fle,GtkWidget *list) {

  gchar *text[COLNUM];
  gchar tmp[6][1024];
  FILE * fl;
  gchar cmd[1024];
  int j;


  sprintf(cmd, "tar -tvf \"%s\"",  fle);
  if ((fl = popen(cmd,"r")) == NULL) {
    return -1 ;
  }

  j = 0;
  while (!feof(fl))  
    {
      fscanf(fl,"%s %s %s %s %s",tmp[0],tmp[1],tmp[2],tmp[3],tmp[4]);
      text[3] = tmp[0];
      text[2] = tmp[2];
      text[1] = tmp[3];
      text[4] = NULL;

      fgets(tmp[5],1023,fl);
      /*strip the /n. also below, skip the first space*/
      tmp[5][strlen(tmp[5])-1] = '\0';

      text[0] = splitNamePath(tmp[5]+1,0);
      text[5] = splitNamePath(tmp[5]+1,1);
      
      gtk_clist_append( GTK_CLIST (list) , text);
      j++;
      g_free(text[0]);
      g_free(text[5]);
    }

  gtk_clist_remove (GTK_CLIST (list),j-1);
  pclose(fl);
  return 0; 
}
