/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

// xunzip.gtk.cpp
// I am sorry about mixture of finnish and english comments :)

#ifdef USE_GTK

#include <unistd.h>
#include <fstream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

#include <gtk/gtk.h>
#include <gnome.h>

#include "zipheader.h"
#include "utils.h"
#include "config.h"
#include "tkstring.h"
#include "itoa.h"
#include "debug.h"
#include "linkedlist.h"
#include "xunzip.gtk.h"
#include "zippacket.h"
#include "xunzip.gtk.new_archive.h"
#include "sll.h"

extern ZipPacket zip;
extern Widgetit wi;

class NewArchiveWindow
{
public:
  NewArchiveWindow();
  ~NewArchiveWindow();
  GtkWidget *window;
  // GtkWidget *box;
  SingleLinkedList<char> *files;
  GtkWidget *entry;
private:
  
};

NewArchiveWindow::NewArchiveWindow()
{
  files=new SingleLinkedList<char>;
}

NewArchiveWindow::~NewArchiveWindow()
{
  if (files)
    delete files;
}

NewArchiveWindow naw;

void cancel_event(GtkWidget *,GtkWidget *me)
{
  gtk_widget_destroy(me);
  me=NULL;
}

void create_new_archive_selection(void)
{
  /* GtkWidget *w;
  GtkWidget *table;
  GtkWidget *dummy; */
#if 0  
  // **** window ****
  w=gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(w),_("New archive"));
  gtk_widget_set_usize(w,250,200);
  
  // **** table ****
  table=gtk_table_new(7,5,TRUE);
  gtk_table_set_row_spacings (GTK_TABLE (table), 1);
  gtk_table_set_col_spacings (GTK_TABLE (table), 1);
  gtk_container_border_width (GTK_CONTAINER (table), 1); 
  gtk_container_add(GTK_CONTAINER(w),table);
  
  // **** ok button ****
  dummy=gtk_button_new_with_label(_("OK"));
  gtk_table_attach_defaults(GTK_TABLE(table),dummy,4,5,0,1);
  gtk_signal_connect(GTK_OBJECT(dummy),"clicked",
		     GTK_SIGNAL_FUNC(compress_it_event),w);
  gtk_widget_show(dummy);
  
  // **** cancel button ****
  dummy=gtk_button_new_with_label(_("Cancel"));
  gtk_signal_connect(GTK_OBJECT (dummy), "clicked",
		     (GtkSignalFunc) cancel_event,w);
  gtk_table_attach_defaults(GTK_TABLE(table),dummy,4,5,1,2);
  gtk_widget_show(dummy);

  // **** clist ***
  char *titles[1]={ N_("Which file should we compress?") };
  window.list=gtk_clist_new_with_titles(1,titles);
  gtk_clist_set_selection_mode(GTK_CLIST(window.list), GTK_SELECTION_SINGLE);
  gtk_clist_set_policy(GTK_CLIST(window.list),GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_table_attach_defaults(GTK_TABLE(table),window.list,0,4,1,7);
  gtk_widget_show(window.list);

  // **** text entry ****
  window.entry=gtk_entry_new();
  gtk_table_attach_defaults(GTK_TABLE(table),window.entry,0,3,0,1);
  gtk_signal_connect(GTK_OBJECT(window.entry),"activate",GTK_SIGNAL_FUNC(add_event),NULL);
  gtk_widget_show(window.entry);

  // **** browse button ****
  dummy=gtk_button_new_with_label(_("Browse"));
  /*  gtk_signal_connect(GTK_OBJECT (dummy), "clicked",
      (GtkSignalFunc) browse_event,w); */
  gtk_table_attach_defaults(GTK_TABLE(table),dummy,3,4,0,1);
  gtk_widget_show(dummy);
  
  // **** add button ****
  dummy=gtk_button_new_with_label(_("Add"));
  gtk_signal_connect(GTK_OBJECT (dummy), "clicked",
      (GtkSignalFunc) add_event,w);
  gtk_table_attach_defaults(GTK_TABLE(table),dummy,4,5,5,6);
  gtk_widget_show(dummy);

  dummy=gtk_button_new_with_label(_("Remove"));
  /*  gtk_signal_connect(GTK_OBJECT (dummy), "clicked",
      (GtkSignalFunc) remove_event,w); */
  gtk_table_attach_defaults(GTK_TABLE(table),dummy,4,5,6,7);
  gtk_widget_show(dummy);
  
  window.window=w;
  window.table=table;
  gtk_widget_show(table);
  gtk_widget_show(w);
#endif

  GSList *buttonGroup;
  GtkWidget *label;
  GtkWidget *rButton1;
  GtkWidget *rButton2;

  naw.window=gnome_dialog_new(_("New Archive / Compress file"),
			  GNOME_STOCK_BUTTON_OK,
			  GNOME_STOCK_BUTTON_CANCEL,NULL);

  gnome_dialog_set_close(GNOME_DIALOG(naw.window),FALSE);
  
  gnome_dialog_button_connect(GNOME_DIALOG(naw.window),1,
			      GTK_SIGNAL_FUNC(cancel_event),
			      naw.window); 

  gnome_dialog_button_connect(GNOME_DIALOG(naw.window),0,
			      GTK_SIGNAL_FUNC(compress_it_event),
			      naw.window); 


  gnome_dialog_set_default(GNOME_DIALOG(naw.window),0);
  
  label=gtk_label_new(_("Which file should we compress?"));
  gtk_misc_set_alignment(GTK_MISC(label), 0.0, 0.5);
  
  gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(naw.window)->vbox),label,
			 TRUE,TRUE,TRUE);
  
  naw.entry=gtk_entry_new();
  gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(naw.window)->vbox),naw.entry,
		     TRUE,TRUE,TRUE);

  label=gtk_label_new(_("Compression method"));
  gtk_misc_set_alignment(GTK_MISC(label), 0.0, 0.5);
  gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(naw.window)->vbox),label,
			 TRUE,TRUE,TRUE);

  rButton1=gtk_radio_button_new_with_label(NULL,_("gzip"));
  // gtk_table_attach_defaults(GTK_TABLE(taulukko),rButton1,0,5,3,4);
  gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(naw.window)->vbox),rButton1,
		     TRUE,TRUE,TRUE);
  buttonGroup=gtk_radio_button_group(GTK_RADIO_BUTTON(rButton1));
  rButton2=gtk_radio_button_new_with_label(buttonGroup,_("bzip2"));
  gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(naw.window)->vbox),rButton2,
		     TRUE,TRUE,TRUE);

  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(rButton2),FALSE);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(rButton1),TRUE);

  gtk_widget_set_sensitive(rButton2,FALSE);
  gtk_widget_show_all(naw.window);

}

void compress_it_event(GtkWidget *,GtkWidget *me)
{
  /* we don't need to check which compression method is used... */

  TKString name;
  gchar *s;
  s=gtk_entry_get_text(GTK_ENTRY(naw.entry));
  if (s)
    {
      name=s;
      name+=GZ_SUFFIX;
      Compress compress;
      int status=0;
      gtk_widget_destroy(me);
      me=NULL;
      status=compress.gzip_compress(s,0);
      if (status!=Z_OK)
	{
	  showError(_("Error occurred during compression. Code: "),itoa(status));
	}
      else
	{
	  if (zip.open((char*)name.getStr(),wi.lista)<0)
	    {
	      showError(_("Cannot open the file "),name.getStr());
	      gnome_appbar_set_default(GNOME_APPBAR(wi.bar),_("no open file"));
	    }
	  else
	    {
	      gnome_appbar_set_default(GNOME_APPBAR(wi.bar),g_filename_pointer(name));
	      wi.roll_latest(name);
	    }
	}
    }
  else
    showError(_("No filename given!"));
}

void add_event(GtkWidget *,GtkWidget *)
{
#if 0
  TKString file;
  file=gtk_entry_get_text(GTK_ENTRY(window.entry));
  if (file.length()>0)
    {
      char *ctmp[1];
      ctmp[0]=gtk_entry_get_text(GTK_ENTRY(window.entry));
      window.files->setAutodelete(0);
      window.files->add(gtk_entry_get_text(GTK_ENTRY(window.entry)));
      gtk_clist_append(GTK_CLIST(window.list),ctmp);
      TK_ASSERT(1,cout << "Adding " << file << endl;);
      gtk_entry_set_text(GTK_ENTRY(window.entry),"");
    }
#endif
}

#endif
