/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

// main.cpp

#include <unistd.h>
#include <fstream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

#ifdef USE_BZIP2
#include "bzip2.h"
#endif

#ifdef USE_GTK
#include <gtk/gtk.h>
#include <gnome.h>
#else

#include <qapp.h>
#include <qpushbt.h>
#include <qfont.h>
#include <qlistbox.h>
#include <qlabel.h>
#include <qfiledlg.h>
#include <qframe.h>
#include <qlabel.h>

#include <kapp.h>

#endif

#include "zipheader.h"
#include "zippacket.h"
#include "utils.h"
#include "config.h"
#include "tkstring.h"
#include "itoa.h"
#include "debug.h"
#include "linkedlist.h"

#ifndef USE_GTK
#include "xunzip.qt.h"
#else
#include "xunzip.gtk.h"
#endif


char *fstmp;
#ifdef USE_GTK
ZipPacket zip;
#endif

#ifndef USE_GTK
int parseArgs(int argc,char **argv);
#else

int parseArgs(void);

extern Widgetit wi;

static GList *file_list=0;
/*
static struct argp_option argp_options[]=
{
    { NULL,0,NULL,0,NULL,0 },
};
*/
/* static error_t parse_an_arg(int key,char *arg,struct argp_state *)
{
  if (key==ARGP_KEY_ARG)
  {

    file_list=g_list_append(file_list,arg);
  }
  return 0;
}

static struct argp parser =
{
    NULL,parse_an_arg,NULL,NULL,NULL,NULL
}; */
#endif

#ifndef USE_GTK
// Jos ei kaytetakaan gtk:ta (= kaytetaan qt:ta)
// If we don't use GTK we use Qt :)

// #include "xunzip.qt.h"

MyWidget *w;

// #include "xunzip.moc"

#endif

// ----------- Main -----------
int main(int argc,char **argv)
{
    int status;
#ifdef USE_GTK
    GnomeClient *client;
    /* client=gnome_master_client();
    gtk_signal_connect(GTK_OBJECT(client), "save_yourself",
		       GTK_SIGNAL_FUNC(save_state), (gpointer)argv[0]);
    gtk_signal_connect(GTK_OBJECT(client), "die",
		       GTK_SIGNAL_FUNC(session_die), NULL);
    */
    client=newGnomeClient(PACKAGE);
    bindtextdomain(PACKAGE, GNOMELOCALEDIR);
    textdomain(PACKAGE);
    // argp_program_version=VERSION;
    gnome_init("Xunzip",VERSION,argc,argv);
/*    gtk_init(&argc,&argv); */
    fstmp=NULL;
    TK_ASSERT(argc>1,for (int a=1;a<argc;a++) cout << argv[a] << endl;);
    alustaGTK(PACKAGE);

    if (argc>1) /* [FIXME] This isn't good way, but I don't know yet how
		   new gnome parameter parsing system works... */
      file_list=g_list_append(file_list,argv[1]);

#else
    KApplication k(argc,argv);
    w=new MyWidget();
    k.setMainWidget(w);
    w->show();
    parseArgs(argc,argv);
#endif

#ifdef USE_GTK
    parseArgs();
    gtk_main();
    status=0;
    zip.close(wi.lista);
#else
    status=k.exec();
    w->zip.close(w->lista);
#endif
    return status;
}
#ifndef USE_GTK
int parseArgs(int argc,char **argv)
#else
  int parseArgs(void)
#endif
{
#ifdef USE_GTK
  if (file_list)
    {
      char *fileName;
      fileName=(char*)file_list->data;
      if (zip.open(fileName,wi.lista)>=0)
	{
	  gnome_appbar_set_default(GNOME_APPBAR(wi.bar),g_filename_pointer(fileName));
	  wi.roll_latest(TKString(fileName));
	}
      g_list_free(file_list);
    }
#else
  if (argc<2)
    return 0;

		    	    
  for (int a=1;a<argc;a++)
    {
      if (argv[a][0]!='-')
	{
	  // if (zip.open(argv[a],w->lista)==-1)
	  w->kfmOpen(argv[a]);
	  w->setCaption(argv[a]);
	  return 0;
	}
    }
#endif
  return 0;
}

