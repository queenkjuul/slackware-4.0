/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/


// my_bzip2.h

// functions for bzip2 filehandling

#include <stdio.h>
#include <stdlib.h>

#ifdef USE_GTK
#include <gnome.h>
#include <gtk/gtk.h>
#else
#include <qapp.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qprogdlg.h> 
#include <ktablistbox.h>
#include <kapp.h>
#include <kfm.h>
#include <kurl.h>
#include <kstatusbar.h>
#endif

#include <zlib.h>
#include "config.h"
#include "zipheader.h"
#include "zippacket.h"
#include "utils.h"

#include "itoa.h"
#include "tkstring.h"
#include "linkedlist.h"

#include "config.h"
#include "debug.h"

#ifdef USE_BZIP2

#ifndef TK_BZIP2_H
#define TK_BZIP2_H

int uncompressBzip2(const char *infile,const char *outfile);

// openBzip2 returns 1 if failure
#ifdef USE_GTK
int openBzip2(char *file,GtkWidget *lista,int tmpfile);
#else
int openBzip2(const char *file,KTabListBox *lista,int tmpfile,QString url,QString & fileUrl);
#endif

#endif // TK_BZIP2_H
#endif // USE_BZIP2
