/*

    Simple linked list
    
    Copyright (c) Tero Koskinen 1998

*/

#include "tkstring.h"

#ifndef TK_LL_H
#define TK_LL_H

class LL_Node
{
public:
    LL_Node(TKString s);
    LL_Node();
    TKString getData(void);
    LL_Node *getNext(void);
    void setNext(LL_Node *n);
private:
    TKString data;
    LL_Node *next;
};

class LL
{
public:
    LL();
    ~LL();
    
    int add(TKString s);
    void removeAll(void);
    TKString getFirst(void);
    TKString getNext(void);
    int atEnd(void);
private:
    LL_Node *root;
    LL_Node *current;
};

#endif

