/* -*-c++-*-

    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

// xunzip.gtk.h

#ifdef USE_GTK

#include <unistd.h>
#include <fstream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

#include <gtk/gtk.h>
#include <glib.h>
#include <gnome.h>

#include "zipheader.h"
#include "utils.h"
#include "config.h"
#include "tkstring.h"
#include "itoa.h"
#include "debug.h"
#include "linkedlist.h"

#ifndef TK_XUNZIP_GTK_H
#define TK_XUNZIP_GTK_H

class AccelEntry
{
public:
    guchar key;
    GdkModifierType mod;
};

typedef struct _PrefButtons
{
  GtkWidget *deleteArchiveButton;
  GtkWidget *lowercaseFilenames;
  GtkWidget *saveSizeButton;
  GtkWidget *defaultDirEntry;

  int lowercaseFiles;
  int deleteArchive;
  int saveSize;
} PrefButtons;

class Widgetit
{
public:
  Widgetit();
  ~Widgetit();

  void saveConfig(void);
  const char* getLastFile(void); /* old, I just haven't removed it yet */
  void readConfig(void);
  void roll_latest(TKString newFile);

  GtkWidget *window;
  GtkWidget *lista;
  GtkWidget *taulukko;
  GtkWidget *entry;
  GtkWidget *entryWindow;
  GtkWidget *bar;
  TKString viewed_file;
  GtkWidget *filesel;
  int deleteArchive;
  int selected_row;
  int unzipOneFile;
  int lowercaseFiles;
  int saveSize;
  int leveys;
  int korkeus;
  int default_width;
  int default_height;
  TKString defaultDir;

  TKString latest[4]; /* latest files */
  
  LL tmpList;
  AccelEntry ae[6];

  PrefButtons pb;
};

void create_recent_menu(void);
void destroy_window (GtkWidget  *,GtkWidget **window);
void delete_event (GtkWidget *, gpointer *);
void delete_unCompress_event(GtkWidget *,gint number, GtkWidget *data);
// void dnd_drop(GtkWidget *, GdkEventDropDataAvailable *event);

void dnd_drop(GtkWidget *w,GdkDragContext *context,
	      gint x,gint y,
	      GtkSelectionData *selection_data ,guint info,
	      guint time, gpointer data);
#if 0
void dnd_drop(GtkWidget *w,GdkDragContext *context,
	      GtkSelectionData *selection_data,guint info,guint time,
	      gpointer data);
#endif

void select_row(GtkWidget *list,gpointer func_data);
void unselect_row(GtkWidget *list,gpointer func_data);
void selected_file_toggled (GtkWidget *, gint *);
void lowercase_selection_toggled (GtkWidget *widget, gint *have_selection);
gint lowercase_selection_clear (GtkWidget *widget, GdkEventSelection *,gint *have_selection);
void about_cb(GtkWidget *,gpointer *);
void unZip_event (GtkWidget *w, gint button_number,GtkWidget *e);
void view_event(GtkWidget *w,GtkWidget *e);
void unCompress_event(GtkWidget *widget,gpointer *data);
void delete_testcrc_event(GtkWidget *,GtkWidget *data);
void testcrc_event(GtkWidget *widget,gpointer *data);
void dir_selection_ok (GtkWidget *, GtkFileSelection *fs);
void dialog_clicked_cb(gchar *string, gpointer );
void create_view(TKString file);
void apply_prefs_event(GtkWidget *, PrefButtons *);
void toggled_archivebutton_event(GtkWidget *,PrefButtons *);
void toggled_lowercasefiles_event(GtkWidget *,PrefButtons *);
void preferences_event(GtkWidget *, gpointer *);
void filesel_hide(void);
void file_selection_ok (GtkWidget *, GtkFileSelection *fs);
void open_file_selection(GtkWidget *, gpointer *);
void open_recent_event(GtkWidget *,gpointer *);
void create_new_file_event(GtkWidget *,gpointer *);
GtkWidget *createList(void);
void create_file_selection (int type);
int connect_dnd(void);
void alustaGTK(char *argv0);

GnomeClient *newGnomeClient(char *name);
int save_state (GnomeClient        *client,
		gint                phase,
		GnomeRestartStyle   save_style,
		gint                shutdown,
		GnomeInteractStyle  interact_style,
		gint                fast,
		gpointer            client_data);
void session_die (gpointer client_data);

#endif
#endif
