// TKString.cpp
//
// Version 0.1

#include <iostream.h>
#include <string.h>

#include "tkstring.h"

TKString::TKString()
{
  myStr=new char[1];
  myStr[0]='\0';
  myLength=0;
  deleteMyStr=1;
}

TKString::TKString(int size)
{
  if (size>0)
    {
      myStr=new char[size+1];
      for (int a=0;a<size;a++)
	myStr[a]='\0';
      myLength=size;
    }
  deleteMyStr=1;
}

TKString::TKString(const char *str,int size)
{
  myLength=size;
  myStr=new char[myLength+1];
  for (unsigned int a=0;a<myLength;a++)
    myStr[a]=str[a];
  myStr[myLength]='\0';
  deleteMyStr=1;
}


TKString::TKString(const char *str)
{
  if (str)
    myLength=strlen(str);
  else
    myLength=0;
  myStr=new char[myLength+1];
  for (unsigned int a=0;a<myLength;a++)
    myStr[a]=str[a];
  myStr[myLength]='\0';
  deleteMyStr=1;
}

TKString::TKString(const TKString & t)
{
  myLength=t.length();
  myStr=new char[myLength+1];
  for (unsigned int a=0;a<myLength;a++)
    myStr[a]=t[a];
  myStr[myLength]='\0';
  deleteMyStr=1;
}

TKString::~TKString()
{
  if (deleteMyStr)
    if (myStr)
      delete myStr;
}

TKString & TKString::operator=(const TKString & t)
{
  if (this == &t)
    return *this;
  delete [] myStr;
  myLength=t.length();
  myStr=new char[myLength+1];
  for (unsigned int a=0;a<myLength;a++)
    myStr[a]=t[a];
  myStr[myLength]='\0';
  return *this;
}

TKString & TKString::operator=(const char *t)
{
  if (t==0) // quick fix...
    return *this;
  if (myStr == t)
    return *this;
  delete [] myStr;
  myLength=strlen(t);
  myStr=new char[myLength+1];
  for (unsigned int a=0;a<myLength;a++)
    myStr[a]=t[a];
  myStr[myLength]='\0';
  return *this;
}

char & TKString::operator[](unsigned int p)
{
  if (p>myLength)
    return myStr[myLength-1];
  return myStr[p];
}

char TKString::operator[](unsigned int p) const
{
  if (p>myLength)
    return myStr[myLength-1];
  return myStr[p];
}

unsigned int TKString::length(void) const
{
  return myLength;
}

TKString TKString::lcase(void)
{
  unsigned int a=0,b=0;
  b=myLength;
  TKString tmp(b);
  for (a=0;a<myLength;a++)
    tmp[a]=tolower(myStr[a]);
  tmp[myLength]='\0';
  return tmp;
}


TKString TKString::operator+(const TKString & t)
{
  unsigned int a=0,b=0;
    
  b=myLength+t.length();
  TKString tmp(b);
  for (a=0;a<myLength;a++)
    tmp[a]=myStr[a];
  for (unsigned int c=0;c<t.length();c++,a++)
    tmp[a]=t[c];
  tmp[b]='\0';
  return tmp;
}

TKString TKString::operator+(const char *str)
{
  unsigned int a=0,b=0;
  if (str)
    {
      b=myLength+strlen(str);
      TKString tmp(b);
      for (a=0;a<myLength;a++)
	tmp[a]=myStr[a];
      for (unsigned int c=0;c<strlen(str);c++,a++)
	tmp[a]=str[c];
      tmp[b]='\0';
      return tmp;
    }
  return TKString();
}

void TKString::operator+=(const TKString & t)
{
  unsigned int a=0,b=0;
    
  b=myLength+t.length();
  TKString tmp(b);
  for (a=0;a<myLength;a++)
    tmp[a]=myStr[a];
  for (unsigned int c=0;c<t.length();c++,a++)
    tmp[a]=t[c];
  tmp[b]='\0';
  *this=tmp;
}

void TKString::operator+=(const char *str)
{
  unsigned int a=0,b=0;
  if (str)
    {
      b=myLength+strlen(str);
      TKString tmp(b);
      for (a=0;a<myLength;a++)
	tmp[a]=myStr[a];
      for (unsigned int c=0;c<strlen(str);c++,a++)
	tmp[a]=str[c];
      tmp[b]='\0';
      *this=tmp;
    }
}

TKString::operator const char *() const
{
  return (const char*)myStr;
}

/*
TKString operator+(const TKString & s1,const TKString & s2)
{
    unsigned int a=0,b=0,c=0;
    
    b=s1.length()+s2.length();
    c=s1.length();
    TKString tmp(b);
    for (a=0;a<c;a++)
	    tmp[a]=s1[a];
	for (unsigned int d=0;a<b;a++,d++)
	    tmp[a]=s2[d];
	tmp[b]='\0';
	return tmp;
}
*/

TKString operator+(const char *s1,const TKString & s2)
{
    unsigned int a=0,b=0,c=0;
    
    c=strlen(s1);
    b=c+s2.length();

    TKString tmp(b);
    for (a=0;a<c;a++)
	    tmp[a]=s1[a];
	for (unsigned int d=0;a<b;a++,d++)
	    tmp[a]=s2[d];
	tmp[b]='\0';
	return tmp;
}


int wordLength(const char *sentence)
{
	int a=0,b=0;
	
    while(sentence[a+b]==' ') b++; // skip space
    
    while(isalpha(sentence[a+b])) a++;
    
    return a;
}

int stringLength(const char *sentence)
{
    int a=0;
    while(sentence[a]!=' ' && sentence[a]!='\n' && sentence[a]!='\0' && sentence[a]!='\r')
	    a++;
	return a;
}

int nextWord(const char *sentence)
{
    int a=0;
    while(sentence[a]==' ') a++;
    
	while(isalpha(sentence[a]))
	    a++;
	    
	while(sentence[a]==' ') a++;
	if (sentence[a]=='\n' || sentence[a]=='\0' || sentence[a]=='\r')
	    return -1;
	
	return a;
}

int nextString(const char *sentence)
{
    int a=0;
    while(sentence[a]==' ') a++;
	while(sentence[a]!=' ' && sentence[a]!='\n' && sentence[a]!='\0' &&  sentence[a]!='\r')
	    a++;
	    
	while(sentence[a]==' ') a++;
	if (sentence[a]=='\n' || sentence[a]=='\0' || sentence[a]=='\r')
	    return -1;
	
	return a;
}

bool operator==(const TKString & s1,const TKString & s2)
{
  return strcmp(s1.getStr(),s2.getStr())==0;
}

bool operator>(const TKString & s1,const TKString & s2)
{
  int a=0,b=0,c=0;
  a=s1.length();
  b=s2.length();
  if (a<b)
    c=a;
  else
    c=b;
  for (int i=0;i<c;i++)
    {
      if (s1[i]>s2[i])
	return 1;
      else if (s1[i]<s2[i])
	return 0;
    }
  if (a>b)
    return 1;
  return 0;
}

bool operator<(const TKString & s1,const TKString & s2)
{
  int a=0,b=0,c=0;
  a=s1.length();
  b=s2.length();
  if (a<b)
    c=a;
  else
    c=b;
  for (int i=0;i<c;i++)
    {
      if (s1[i]<s2[i])
	return 1;
      else if (s1[i]>s2[i])
	return 0;
    }
  if (a<b)
    return 1;
  return 0;
}


bool operator!=(const TKString & s1,const TKString & s2)
{
  return strcmp(s1.getStr(),s2.getStr())!=0;
}
