/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

// xunzip.gtk.cpp
// I am sorry about mixture of finnish and english comments :)

#ifdef USE_GTK

#include <unistd.h>
#include <fstream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

#include <gtk/gtk.h>
#include <gnome.h>

#include "zipheader.h"
#include "utils.h"
#include "config.h"
#include "tkstring.h"
#include "itoa.h"
#include "debug.h"
#include "linkedlist.h"
#include "xunzip.gtk.h"
#include "zippacket.h"
#include "xunzip.gtk.new_archive.h"

extern ZipPacket zip;
extern char *fstmp; // for file selection

Widgetit::Widgetit()
{
    filesel=0;
    leveys=390;
    korkeus=250;
    selected_row=-1;
    unzipOneFile=0;
    lowercaseFiles=0;
    deleteArchive=0;
    saveSize=0;
    ae[0].key='O';
    ae[1].key='P';
    ae[2].key='Q';
    ae[3].key='E';
    ae[4].key='T';
    ae[5].key='V';
    for (int a=0;a<6;a++)
      ae[a].mod=GDK_CONTROL_MASK;
	    
//    gnome_stock_menu_accel_parse("/gxunzip/Accelerators/");
}

Widgetit::~Widgetit()
{
    TKString s,t;
    pid_t pid;
    char eMessage[FNAME_MAX];
    tyhjennaTaulukko(eMessage,FNAME_MAX);

// just testing how gnome handles menu accel stuff...
#ifdef TK_DEBUG

    /*    guchar key;
	  guint8 mod; */
    
/*    if (gnome_stock_menu_accel(GNOME_STOCK_MENU_OPEN, &key, &mod))
	    printf("key: %d mod: %d\n",key,mod); */

#endif

    pid=getpid();
    sprintf(eMessage,"/tmp/gxunzip.%d",(int)pid);
    while(!tmpList.atEnd())
    {
	    s=tmpList.getNext();
   	    TK_ASSERT(1,cout << "Removing " << s << "..." << endl;);
	    unlink(s.getStr());
	}
    rmdir(eMessage);
    tmpList.removeAll();
    entryWindow=0;
}

void Widgetit::saveConfig(void)
{
  int x_size=0,y_size=0;

  if (zip.isOpen())
    gnome_config_set_string("/gxunzip/Files/Last",zip.getArchiveName());
  else
    gnome_config_clean_key("/gxunzip/Files/Last");

  gdk_window_get_size(window->window,&x_size,&y_size);
  // default_width=x_size;
  // default_height=y_size;
  if (saveSize)
    {
      gnome_config_set_int("/gxunzip/Size/Width",x_size);
      gnome_config_set_int("/gxunzip/Size/Height",y_size);
    }

  gnome_config_set_int("/gxunzip/Options/DeleteFileAfterUncompress",
		       deleteArchive);
  gnome_config_set_int("/gxunzip/Options/LowercaseFilenames",
		       lowercaseFiles);
  gnome_config_set_int("/gxunzip/Options/SaveSize",
		       saveSize);
  gnome_config_set_string("/gxunzip/Options/DefaultDirectory",
			  defaultDir);
  gnome_config_set_string("/gxunzip/Files/1st",latest[0]);
  gnome_config_set_string("/gxunzip/Files/2nd",latest[1]);
  gnome_config_set_string("/gxunzip/Files/3rd",latest[2]);
  gnome_config_set_string("/gxunzip/Files/4th",latest[3]);
  
  gnome_config_sync();
}

const char * Widgetit::getLastFile(void)
{
  return gnome_config_get_string("/gxunzip/Files/Last");
}

void Widgetit::readConfig(void)
{
  defaultDir=gnome_config_get_string("/gxunzip/Options/DefaultDirectory");

  saveSize=gnome_config_get_int("/gxunzip/Options/SaveSize");
  if (saveSize)
    {
      default_width=gnome_config_get_int("/gxunzip/Size/Width");
      default_height=gnome_config_get_int("/gxunzip/Size/Height");
    }
  deleteArchive=gnome_config_get_int("/gxunzip/Options/DeleteFileAfterUncompress");
  lowercaseFiles=gnome_config_get_int("/gxunzip/Options/LowercaseFilenames");

  latest[0]=gnome_config_get_string("/gxunzip/Files/1st");
  latest[1]=gnome_config_get_string("/gxunzip/Files/2nd");
  latest[2]=gnome_config_get_string("/gxunzip/Files/3rd");
  latest[3]=gnome_config_get_string("/gxunzip/Files/4th");
  
}

void Widgetit::roll_latest(TKString newFile)
{
  char buffer[FNAME_MAX];
  TKString cwd;
  TKString place;
  place=_("File");
  place+=TKString("/",1); // this could be just place+="/";
  place+=_("Most recent files/");

  cwd=getcwd(buffer,FNAME_MAX);
  cwd+="/";
  TK_ASSERT(1,cout << cwd << endl;);

  if (newFile[0]!='/')
    {
      newFile=cwd+newFile;
    }
  
  // place+=latest[3];

  if (latest[3].length()>0)
    gnome_app_remove_menus(GNOME_APP(window),(char*)place.getStr(),4);
  
  for (int a=3;a>0;a--)
    {
      latest[a]=latest[a-1];
      TK_ASSERT(1,cout << "latest[" << a << "] = " << latest[a] << endl;);
    }
  latest[0]=newFile;
  
  GnomeUIInfo recent_menu_entry1[] = {
    GNOMEUIINFO_ITEM_DATA((char*)latest[0].getStr(),NULL,
			  open_recent_event,
			  (gpointer)latest[0].getStr(),NULL),
    
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry2[] = {
    GNOMEUIINFO_ITEM_DATA((char*)latest[1].getStr(),NULL,
			  open_recent_event,
			  (gpointer)latest[1].getStr(),NULL),
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry3[] = {
    GNOMEUIINFO_ITEM_DATA((char*)latest[2].getStr(),NULL,
			  open_recent_event,
			  (gpointer)latest[2].getStr(),NULL),
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry4[] = {
    GNOMEUIINFO_ITEM_DATA((char*)latest[3].getStr(),NULL,
			  open_recent_event,
			  (gpointer)latest[3].getStr(),NULL),
    GNOMEUIINFO_END
  };

  place=_("File");
  
  place+=TKString("/",1)+_("Most recent files");
  place+=TKString("/",1);

  if (latest[3].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(window),(char*)place.getStr(),
			     recent_menu_entry4);
    }
  if (latest[2].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(window),(char*)place.getStr(),
			     recent_menu_entry3);
    }

  if (latest[1].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(window),(char*)place.getStr(),
			     recent_menu_entry2);
    }
  if (latest[0].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(window),(char*)place.getStr(),
			     recent_menu_entry1);
    }
}

Widgetit wi;

void create_recent_menu(void)
{
  GnomeUIInfo recent_menu_entry1[] = {
    GNOMEUIINFO_ITEM_DATA((char*)wi.latest[0].getStr(),NULL,
			  open_recent_event,
			  (gpointer)wi.latest[0].getStr(),NULL),
    
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry2[] = {
    GNOMEUIINFO_ITEM_DATA((char*)wi.latest[1].getStr(),NULL,
			  open_recent_event,
			  (gpointer)wi.latest[1].getStr(),NULL),
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry3[] = {
    GNOMEUIINFO_ITEM_DATA((char*)wi.latest[2].getStr(),NULL,
			  open_recent_event,
			  (gpointer)wi.latest[2].getStr(),NULL),
    GNOMEUIINFO_END
  };
  GnomeUIInfo recent_menu_entry4[] = {
    GNOMEUIINFO_ITEM_DATA((char*)wi.latest[3].getStr(),NULL,
			  open_recent_event,
			  (gpointer)wi.latest[3].getStr(),NULL),
    GNOMEUIINFO_END
  };

  /*  GnomeUIInfo menu_separator[] = {
    GNOMEUIINFO_SEPARATOR,
    GNOMEUIINFO_END
    }; */

  GnomeUIInfo menu_null[] = {
    GNOMEUIINFO_END
  };

  GnomeUIInfo menu_recent_files[] = {
    GNOMEUIINFO_SEPARATOR,
    GNOMEUIINFO_SUBTREE(_("Most recent files"),menu_null),
    GNOMEUIINFO_END
  };

  TKString place,place2;

  place=_("File");
  
  place2=place+TKString("/",1)+_("Preferences");
  place+=TKString("/",1)+_("Most recent files");
  place+=TKString("/",1);

  gnome_app_insert_menus(GNOME_APP(wi.window),(char*)place2.getStr(),
			 menu_recent_files);

  if (wi.latest[3].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(wi.window),(char*)place.getStr(),
			     recent_menu_entry4);
    }
  if (wi.latest[2].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(wi.window),(char*)place.getStr(),
			     recent_menu_entry3);
    }

  if (wi.latest[1].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(wi.window),(char*)place.getStr(),
			     recent_menu_entry2);
    }
  if (wi.latest[0].length()>0)
    {
      gnome_app_insert_menus(GNOME_APP(wi.window),(char*)place.getStr(),
			     recent_menu_entry1);
    }
}

void destroy_window (GtkWidget  *,GtkWidget **window)
{
  *window = NULL;
}


// Ohjelman lopetus
void delete_event (GtkWidget *, gpointer *)
{
  wi.saveConfig();
  zip.close(wi.lista);
  gtk_main_quit ();
}

// purkuikkunan poisto
void delete_unCompress_event(GtkWidget *, gint ,GtkWidget *)
{
  /*  gtk_widget_hide(data);
      gtk_widget_destroy(data); */
  gnome_dialog_close(GNOME_DIALOG(wi.entryWindow));
  wi.entryWindow=0;
}

// somebody dropped something?
// void dnd_drop(GtkWidget *, GdkEventDropDataAvailable *event)

void dnd_drop(GtkWidget * /* w */ ,GdkDragContext * /* context */ ,
	      gint /* x */,gint /* y */,
	      GtkSelectionData *selection_data ,guint /* info */,
	      guint /* time */, gpointer /* data */ )
  /*	      GtkWidget *widget, GdkDragContext *context,
			GtkSelectionData *selection_data, guint info,
			guint time, gpointer data) */
{
  TK_ASSERT(1,g_print("dnd_drop\n"););
  // TK_ASSERT(1,g_print("%s\n",event->data_type););
  if (selection_data)
    {
      if (selection_data->data)
	{
	  if (zip.open((char*)selection_data->data,wi.lista)<0)
	    {
	      showError(_("Cannot open the file "),(char*)selection_data->data);
	      gnome_appbar_set_default(GNOME_APPBAR(wi.bar),_("no open file"));
	    }
	  else
	    {
	      gnome_appbar_set_default(GNOME_APPBAR(wi.bar),g_filename_pointer((char*)(selection_data->data)));
	      wi.roll_latest(TKString((char*)(selection_data->data)));
	    }
	}
    }
  /*  if (event->data && !strcmp(event->data_type,"text/plain"));
  {
    if (zip.open((char*)event->data,wi.lista)<0)
      {
	showError(_("Cannot open the file "),(char*)event->data);
	gnome_appbar_set_default(GNOME_APPBAR(wi.bar),_("no open file"));
      }
    else
      {
	gnome_appbar_set_default(GNOME_APPBAR(wi.bar),g_filename_pointer((char*)(event->data)));
	wi.roll_latest(TKString((char*)(event->data)));
      }
      } */
} 

// user selected a row
void select_row(GtkCList *, gint row, gint , GdkEventButton *)
{
    // TK_ASSERT(1,cout << "select: " << row << endl;);
    wi.selected_row=row;
}

// user unselected a row
void unselect_row(GtkCList *, gint ,gint , GdkEventButton *)
{
    // TK_ASSERT(1,cout << "unselect: " << row << endl;);
    wi.selected_row=-1;
}

void selected_file_toggled (GtkWidget *, gint *)
{
    wi.unzipOneFile=!wi.unzipOneFile;
    // TK_ASSERT(1,cout << "wi.unzipOneFile: " << wi.unzipOneFile << endl;);
}

// void lowercase_selection_toggled (GtkWidget *widget, gint *have_selection)
void lowercase_selection_toggled (GtkWidget *, gint *)
{
    wi.lowercaseFiles=!wi.lowercaseFiles;
    // TK_ASSERT(wi.lowercaseFiles,cout << "Lowercase files" << endl;);
}

gint lowercase_selection_clear (GtkWidget *widget, GdkEventSelection *,gint *have_selection)
{
  *have_selection = FALSE;
  gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON(widget), FALSE);

  return TRUE;
}

void about_cb(GtkWidget *,gpointer *)
{
    const gchar *authors[] = {"Tero Koskinen <tkoskine@jas.pspt.fi>",NULL };
    GtkWidget *about=gnome_about_new ( _("GNOME Xunzip"), VERSION,
                                       _("Copyright 1998, under the GNU General Public License."),
                                       authors,
"The newest version can be found from\nhttp://jas.pspt.fi/~tkoskine/gnome/",NULL);
    gtk_widget_show (about);
}

void unZip_event (GtkWidget *,gint button_number, GtkWidget *)
{
  gchar *dir;
  int sfile=-1,options=0,status=0;
  TK_ASSERT(1,cout << "Unzipping to " << gtk_entry_get_text(GTK_ENTRY(wi.entry)) << "..." << endl;);
  TK_ASSERT(1,cout << "Button number " << button_number << endl;);
  if (button_number==0) // OK
    {
      if (zip.getType()==3 || zip.getType()==5) // ARJ or RAR file
	{
	  //	showMessage("Uncompression of ARJ not supported!");
	  return;
	}
      dir=gtk_entry_get_text(GTK_ENTRY(wi.entry));
      if (wi.unzipOneFile>0)
	{
	  sfile=wi.selected_row;
	  options|=SELECTED_FILE;
	}
      options|=wi.lowercaseFiles*LOWERCASE_FILENAMES;
      gnome_appbar_push(GNOME_APPBAR(wi.bar),_("Uncompressing..."));
      status=zip.unZip(dir,sfile,options,wi.bar);
      if (status<0)
	{
	  showError(_("Failed uncompress to "),dir);
	}
      
      gnome_appbar_pop(GNOME_APPBAR(wi.bar));
    }
  gnome_appbar_set_progress(GNOME_APPBAR(wi.bar),0);
  /*  gtk_widget_hide(w);
      gtk_widget_destroy(w); */
  gnome_dialog_close(GNOME_DIALOG(wi.entryWindow));
  wi.entryWindow=0;
}

void view_event(GtkWidget *,GtkWidget *)
{
  char eMessage[FNAME_MAX];
  TKString s,e;
  pid_t pid;
  tyhjennaTaulukko(eMessage,FNAME_MAX);
  if (zip.getType()==3)
    return;

  pid=getpid();
  if (wi.selected_row>=0)
    {
      // QProgressDialog progress(klocale->translate("Viewing file..."),klocale->translate("Cancel"),zip.getFiles(),this,"progress",true);
      sprintf(eMessage,"/tmp/gxunzip.%d/",(int)pid);
      e=zip.getName(wi.selected_row);
      s=eMessage;
      /* TK_ASSERT(1,cout << (s+e) << endl;); */

      /* wi.tmpList.add((s+e)); */
      /*      if (zip.unZip(s,wi.selected_row,SELECTED_FILE,wi.bar)<0)
	{
	  showError(_("Cannot view file "),(s+e));
	}
      else
      { */
	  s+=e;
	  // e="file:";
	  // s=e+s;
	  // TK_ASSERT(1,cout << "kfm->exec(" << s << ",0L);" << endl;);
	  // kfm->exec(s,0L);
	  create_view(s);
	  /*	} */
    }
}

void unCompress_event(GtkWidget *,gpointer *)
{
  GSList *buttonGroup;
  static int have_selection=FALSE;
  wi.unzipOneFile=0;
    
  // GtkWidget *window;

  GtkWidget *label;
  // GtkWidget *okButton;
  // GtkWidget *cancelButton;
  // GtkWidget *taulukko;
  GtkWidget *selectedFileButton;
  GtkWidget *rButton1;
  GtkWidget *rButton2;

  if (zip.getType()==3) // ARJ-file
    {
      showMessage(_("Uncompression of ARJ not supported!"));
      return;
    }
  else if (zip.getType()==5) // RAR-file
    {
      showMessage(_("Uncompression of RAR not supported!"));
      return;
    }

  if (wi.entryWindow==0)
    {
      // wi.entryWindow=gtk_window_new(GTK_WINDOW_TOPLEVEL);
      wi.entryWindow=gnome_dialog_new(_("Choose directory"),
				      GNOME_STOCK_BUTTON_OK,
				      GNOME_STOCK_BUTTON_CANCEL,NULL);
      gnome_dialog_set_close(GNOME_DIALOG(wi.entryWindow),FALSE);
      // gtk_window_set_title(GTK_WINDOW (wi.entryWindow), _("Choose directory"));
      // gtk_container_border_width(GTK_CONTAINER(wi.entryWindow),5);
      // gtk_widget_set_usize(wi.entryWindow,200,120);

      /* taulukko=gtk_table_new(5,5,TRUE);
      gtk_table_set_row_spacings (GTK_TABLE (taulukko), 1);
      gtk_table_set_col_spacings (GTK_TABLE (taulukko), 1);
      gtk_container_border_width (GTK_CONTAINER (taulukko), 1); 
      gtk_container_add(GTK_CONTAINER(wi.entryWindow),taulukko); */
	
  // button with OK
      /* okButton=gtk_button_new_with_label(_("OK"));
      gtk_table_attach_defaults(GTK_TABLE(taulukko),okButton,3,5,0,1);
      gtk_signal_connect(GTK_OBJECT(okButton),"clicked",
      GTK_SIGNAL_FUNC(unZip_event),wi.entryWindow); */
      /* gnome_dialog_button_connect(GNOME_DIALOG(wi.entryWindow),0,
				  GTK_SIGNAL_FUNC(unZip_event),
				  wi.entryWindow); */
      gtk_signal_connect(GTK_OBJECT(wi.entryWindow),"clicked",
			 GTK_SIGNAL_FUNC(unZip_event),wi.entryWindow);

      // cancel button
      /*    cancelButton=gtk_button_new_with_label(_("Cancel"));
      gtk_signal_connect(GTK_OBJECT (cancelButton), "clicked",(GtkSignalFunc) delete_unCompress_event,wi.entryWindow);
      gtk_table_attach_defaults(GTK_TABLE(taulukko),cancelButton,3,5,1,2); */

      gnome_dialog_button_connect(GNOME_DIALOG(wi.entryWindow),1,
				  GTK_SIGNAL_FUNC(delete_unCompress_event),
				  wi.entryWindow); 
      gnome_dialog_set_default(GNOME_DIALOG(wi.entryWindow),0);

      // label
      label=gtk_label_new(_("Where to extract?"));
      // gtk_table_attach_defaults(GTK_TABLE(taulukko),label,0,3,0,1);
      gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(wi.entryWindow)->vbox),label,
			 TRUE,TRUE,TRUE);
	
      // text entry
      wi.entry=gtk_entry_new();
      
      if (wi.defaultDir.length()<1)
	gtk_entry_set_text(GTK_ENTRY(wi.entry),getenv("HOME"));
      else
	gtk_entry_set_text(GTK_ENTRY(wi.entry),wi.defaultDir);

      // gtk_table_attach_defaults(GTK_TABLE(taulukko),wi.entry,0,3,1,2);
      gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(wi.entryWindow)->vbox),wi.entry,
			 TRUE,TRUE,TRUE);

	
  // "lowercase files" button
      selectedFileButton=gtk_check_button_new_with_label(_("Lowercase filenames"));
      gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(selectedFileButton),wi.lowercaseFiles);

      // gtk_table_attach_defaults(GTK_TABLE(taulukko),selectedFileButton,0,5,4,5);
      gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(wi.entryWindow)->vbox),selectedFileButton,
			 TRUE,TRUE,TRUE);

      gtk_signal_connect (GTK_OBJECT(selectedFileButton), "toggled",
			  GTK_SIGNAL_FUNC (lowercase_selection_toggled), &have_selection);
      gtk_signal_connect (GTK_OBJECT(selectedFileButton), "selection_clear_event",
			  GTK_SIGNAL_FUNC (lowercase_selection_clear), &have_selection);
	
      // radio button (all files/selected file)
      rButton1=gtk_radio_button_new_with_label(NULL,_("Selected file"));
      // gtk_table_attach_defaults(GTK_TABLE(taulukko),rButton1,0,5,3,4);
      gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(wi.entryWindow)->vbox),rButton1,
			 TRUE,TRUE,TRUE);

      gtk_signal_connect(GTK_OBJECT(rButton1),"toggled",
			 GTK_SIGNAL_FUNC(selected_file_toggled),NULL);
      buttonGroup=gtk_radio_button_group(GTK_RADIO_BUTTON(rButton1));
      rButton2=gtk_radio_button_new_with_label(buttonGroup,_("All files"));
      /* gtk_signal_connect(GTK_OBJECT(rButton2),"toggled",
     GTK_SIGNAL_FUNC(selected_file_toggled),NULL); */

      // gtk_table_attach_defaults(GTK_TABLE(taulukko),rButton2,0,5,2,3);
      gtk_box_pack_start(GTK_BOX(GNOME_DIALOG(wi.entryWindow)->vbox),rButton2,
			 TRUE,TRUE,TRUE);

      gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(rButton2),TRUE);
      gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(rButton1),FALSE);
      wi.unzipOneFile=0;

    
  //    gtk_signal_connect
      gtk_widget_show(rButton1);
      gtk_widget_show(rButton2);
      gtk_widget_show(selectedFileButton);
      gtk_widget_show(label);
      gtk_widget_show(wi.entry);
      /* gtk_widget_show(cancelButton);
	 gtk_widget_show(okButton); 
	 gtk_widget_show(taulukko); */
      gtk_widget_show(wi.entryWindow);
    }
  else
    {
      delete_unCompress_event(wi.entryWindow,1,wi.entryWindow);
    }
}

void delete_testcrc_event(GtkWidget *,GtkWidget *data)
{
    gtk_widget_hide(data);
    gtk_widget_destroy(data);
}

// testi-ikkuna
void testcrc_event(GtkWidget *,gpointer *)
{
  GtkWidget *window;
  GtkWidget *label;
  GtkWidget *taulukko;
  GtkWidget *lista;
  GtkWidget *swindow;
  GtkWidget *button;

  if (zip.isOpen() || zip.getType()==1)
    {

      // paaikkuna
      window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
      gtk_window_set_title(GTK_WINDOW(window),"Files with errors");
      gtk_signal_connect(GTK_OBJECT(window),"destroy",GTK_SIGNAL_FUNC(delete_testcrc_event),window);
      gtk_container_border_width(GTK_CONTAINER(window),10);
      gtk_widget_set_usize(window,200,200);
  
      // uusi taulukko
      taulukko=gtk_table_new(5,3,TRUE);
      gtk_table_set_row_spacings (GTK_TABLE (taulukko), 1);
      gtk_table_set_col_spacings (GTK_TABLE (taulukko), 1);
      gtk_container_border_width (GTK_CONTAINER (taulukko), 1); 
      gtk_container_add(GTK_CONTAINER(window),taulukko);

      // scrollattava lista (ikkuna, jossa lista)
      swindow=gtk_scrolled_window_new(NULL,NULL);
      gtk_widget_set_usize(swindow,100,100);
      gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (swindow),
				      GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC); 
      gtk_table_attach_defaults(GTK_TABLE(taulukko),swindow,0,3,1,4);

      // itse lista nyt
      lista=gtk_list_new();
      gtk_list_set_selection_mode (GTK_LIST (lista), GTK_SELECTION_MULTIPLE);
      gtk_list_set_selection_mode (GTK_LIST (lista), GTK_SELECTION_BROWSE);
      gtk_container_add(GTK_CONTAINER(swindow),lista);

      // kyltti    
      label=gtk_label_new("Files which have errors");
      gtk_table_attach_defaults(GTK_TABLE(taulukko),label,0,3,0,1);
    
      // ja ok-nappi
      button=gtk_button_new_with_label("OK");
      gtk_signal_connect(GTK_OBJECT (button), "clicked",(GtkSignalFunc) delete_testcrc_event,window);
      gtk_table_attach_defaults(GTK_TABLE(taulukko),button,1,2,4,5);
    
      gtk_widget_show(button);
      gtk_widget_show(label);
      gtk_widget_show(lista);
      gtk_widget_show(swindow);
      gtk_widget_show(taulukko);
      gtk_widget_show(window);
	
      zip.testcrc(lista);
    }
}

// hakemiston valinta onnistui hyvaksytysti
void dir_selection_ok (GtkWidget *, GtkFileSelection *fs)
{
    char tiedosto[256];
    for (int a=0;a<256;a++)
	    tiedosto[a]='\0';
    fstmp=gtk_file_selection_get_filename (GTK_FILE_SELECTION (fs));
    strncpy(tiedosto,fstmp,strlen(fstmp));
    filesel_hide();
    if (zip.unZip(tiedosto)<0)
	{
	    showMessage(_("Cannot uncompress the archive"));
	}
}

#if 0
  TKString s,e;
  pid_t pid;
  tyhjennaTaulukko(eMessage,FNAME_MAX);
  if (zip.getType()==3)
    return;

  pid=getpid();
  if (wi.selected_row>=0)
    {
      // QProgressDialog progress(klocale->translate("Viewing file..."),klocale->translate("Cancel"),zip.getFiles(),this,"progress",true);
      sprintf(eMessage,"/tmp/gxunzip.%d/",(int)pid);
      e=zip.getName(wi.selected_row);
      s=eMessage;
      /* TK_ASSERT(1,cout << (s+e) << endl;); */

      /* wi.tmpList.add((s+e)); */
      /*      if (zip.unZip(s,wi.selected_row,SELECTED_FILE,wi.bar)<0)
	{
	  showError(_("Cannot view file "),(s+e));
	}
      else
      { */
	  s+=e;
	  // e="file:";
	  // s=e+s;
	  // TK_ASSERT(1,cout << "kfm->exec(" << s << ",0L);" << endl;);
	  // kfm->exec(s,0L);
	  create_view(s);
	  /*	} */
    }
#endif



void dialog_clicked_cb(gchar *string, gpointer )
{
  TKString s,e;
  pid_t pid;
  char eMessage[FNAME_MAX];
  tyhjennaTaulukko(eMessage,FNAME_MAX);

  if (zip.getType()==3)
    return;

  pid=getpid();
  if (string)
    {
      sprintf(eMessage,"/tmp/gxunzip.%d/",(int)pid);
      e=zip.getName(wi.selected_row);
      s=eMessage;
      wi.tmpList.add((s+e));
      if (zip.unZip(s,wi.selected_row,SELECTED_FILE,wi.bar)<0)
	{
	  showError(_("Cannot view file "),(s+e));
	}
      else
	{
	  s=string;
	  s+=TKString(" ")+wi.viewed_file;
	  my_system(s);
	  wi.viewed_file=TKString();
	}
    }
}

void create_view(TKString file)
{
    GtkWidget *dialog;
//    GtkWidget *entry;
    wi.viewed_file=file;
    // dialog=gnome_request_string_dialog(_("View file with program"),dialog_clicked_cb,NULL);
    dialog=gnome_request_dialog(FALSE,_("View file with program"),
			       NULL,1024,dialog_clicked_cb,NULL,
			       NULL);

    gtk_widget_show(dialog);
}

void apply_prefs_event(GtkWidget *, PrefButtons *)
{
  gchar *s;
  s=gtk_entry_get_text(GTK_ENTRY(wi.pb.defaultDirEntry));
  if (s)
    wi.defaultDir=s;

  wi.deleteArchive=wi.pb.deleteArchive;
  wi.lowercaseFiles=wi.pb.lowercaseFiles;
  wi.saveSize=wi.pb.saveSize;
}

void toggled_archivebutton_event(GtkWidget *,PrefButtons *pb)
{
  pb->deleteArchive=!(pb->deleteArchive);
}

void toggled_lowercasefiles_event(GtkWidget *,PrefButtons *pb)
{
  pb->lowercaseFiles=!(pb->lowercaseFiles);
}

void toggled_savesize_event(GtkWidget *,PrefButtons *pb)
{
  pb->saveSize=!(pb->saveSize);
}


void preferences_event(GtkWidget *, gpointer *)
{
  GtkWidget *w;
  GtkWidget *vbox;
  GtkWidget *label;
  GtkWidget *label2;
  // GtkWidget *deleteArchiveButton;
  PrefButtons *pb;
  pb=&wi.pb;
  
  w=gnome_property_box_new();
  
  vbox=gtk_vbox_new(FALSE,0);
  gtk_container_border_width(GTK_CONTAINER(vbox), GNOME_PAD);
  
  pb->deleteArchiveButton=gtk_check_button_new_with_label(_("Delete compressed file after uncompression"));

  gtk_box_pack_start(GTK_BOX(vbox),pb->deleteArchiveButton,FALSE,FALSE,0);
  pb->lowercaseFilenames=gtk_check_button_new_with_label(_("Lowercase filenames"));
  gtk_box_pack_start(GTK_BOX(vbox),pb->lowercaseFilenames,FALSE,FALSE,0);

  pb->saveSizeButton=gtk_check_button_new_with_label(_("Save main window size when quitting"));
  gtk_box_pack_start(GTK_BOX(vbox),pb->saveSizeButton,FALSE,FALSE,0);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(pb->lowercaseFilenames),
			      wi.lowercaseFiles);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(pb->deleteArchiveButton),
			      wi.deleteArchive);
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(pb->saveSizeButton),
			      wi.saveSize);

  pb->deleteArchive=wi.deleteArchive;
  pb->lowercaseFiles=wi.lowercaseFiles;
  pb->saveSize=wi.saveSize;
  
  pb->defaultDirEntry=gtk_entry_new();
  gtk_entry_set_text(GTK_ENTRY(pb->defaultDirEntry),wi.defaultDir);
  gtk_box_pack_end(GTK_BOX(vbox),pb->defaultDirEntry,FALSE,FALSE,0);
  label2=gtk_label_new(_("Uncompression directory"));
  gtk_misc_set_alignment(GTK_MISC(label2), 0.0, 0.5);
  gtk_box_pack_end(GTK_BOX(vbox),label2,FALSE,FALSE,0);

  gtk_signal_connect(GTK_OBJECT(w), "apply",
                     GTK_SIGNAL_FUNC(apply_prefs_event), pb);
  gtk_signal_connect(GTK_OBJECT(pb->deleteArchiveButton), "toggled",
		     GTK_SIGNAL_FUNC(toggled_archivebutton_event),pb);
  gtk_signal_connect(GTK_OBJECT(pb->lowercaseFilenames), "toggled",
		     GTK_SIGNAL_FUNC(toggled_lowercasefiles_event),pb);
  gtk_signal_connect(GTK_OBJECT(pb->saveSizeButton), "toggled",
		     GTK_SIGNAL_FUNC(toggled_savesize_event),pb);

  gtk_signal_connect_object(GTK_OBJECT(pb->defaultDirEntry), "changed",
                            GTK_SIGNAL_FUNC(gnome_property_box_changed),
                            GTK_OBJECT(w));
  gtk_signal_connect_object(GTK_OBJECT(pb->deleteArchiveButton), "toggled",
                            GTK_SIGNAL_FUNC(gnome_property_box_changed),
                            GTK_OBJECT(w));
  gtk_signal_connect_object(GTK_OBJECT(pb->lowercaseFilenames), "toggled",
                            GTK_SIGNAL_FUNC(gnome_property_box_changed),
                            GTK_OBJECT(w));
  gtk_signal_connect_object(GTK_OBJECT(pb->saveSizeButton), "toggled",
                            GTK_SIGNAL_FUNC(gnome_property_box_changed),
                            GTK_OBJECT(w));
  
  label=gtk_label_new(_("General"));
  
  gtk_notebook_append_page(GTK_NOTEBOOK(GNOME_PROPERTY_BOX(w)->notebook),
			   vbox,label);
  
  gtk_window_set_title(GTK_WINDOW(w),_("Preferences"));
  
  gtk_widget_show(label2);
  gtk_widget_show(pb->saveSizeButton);
  gtk_widget_show(pb->defaultDirEntry);
  gtk_widget_show(pb->deleteArchiveButton);
  gtk_widget_show(pb->lowercaseFilenames);
  gtk_widget_show(label);
  gtk_widget_show(vbox);
  gtk_widget_show(w);
}

// piilotetaan hakemiston/tiedoston valintaikkuna
void filesel_hide(void)
{
  if (GTK_WIDGET_VISIBLE(wi.filesel))
    {
      gtk_widget_hide(wi.filesel);
      gtk_widget_destroy(wi.filesel);
      wi.filesel=NULL;
    }
}

// tiedosto valittu hyvaksytysti
void file_selection_ok (GtkWidget *, GtkFileSelection *fs)
{
  char tiedosto[256];
  for (int a=0;a<256;a++)
    tiedosto[a]='\0';
  fstmp=gtk_file_selection_get_filename (GTK_FILE_SELECTION (fs));
  strncpy(tiedosto,fstmp,strlen(fstmp));
  filesel_hide();
  if (tiedosto)
    {
      if (zip.open(tiedosto,wi.lista)<0)
	{
	  showError(_("Cannot open the file "),tiedosto);
	  gnome_appbar_set_default(GNOME_APPBAR(wi.bar),_("no open file"));
	}
      else
	{
	  gnome_appbar_set_default(GNOME_APPBAR(wi.bar),g_filename_pointer(tiedosto));
	  wi.roll_latest(TKString(tiedosto));
	}
    }
}

// luodaan/tuhotaan tiedoston valintaikkuna
void open_file_selection(GtkWidget *, gpointer *)
{
  if (wi.filesel==NULL)
    create_file_selection(0);
  else
    filesel_hide();
}

void open_recent_event(GtkWidget *,gpointer *data)
{
  char *string;
  string=(char*)data;

  TK_ASSERT(string,cout << "Data: " << string << endl;);
  
  if (string)
    {
      if (zip.open(string,wi.lista)<0)
	{
	  showError(_("Cannot open the file "),string);
	  gnome_appbar_set_default(GNOME_APPBAR(wi.bar),_("no open file"));
	}
      else
	{
	  gnome_appbar_set_default(GNOME_APPBAR(wi.bar),g_filename_pointer(string));
	  wi.roll_latest(TKString(string));
	}

    }
}


void create_new_file_event(GtkWidget *,gpointer *)
{
  create_new_archive_selection();
}

/* lista */
GtkWidget *createList(void)
{
  GtkWidget *w;
  char *titles[5]=
  {
    N_("Name"),
    N_("Date"),
    N_("Ratio"),
    N_("Size"),
    N_("Packed")
  };
  char *tmp[5];
  tmp[0]=_(titles[0]);
  tmp[1]=_(titles[1]);
  tmp[2]=_(titles[2]);
  tmp[3]=_(titles[3]);
  tmp[4]=_(titles[4]);
	
  w=gtk_clist_new_with_titles(5,tmp);
	
  gtk_clist_set_selection_mode(GTK_CLIST(w), GTK_SELECTION_SINGLE);
  /*    gtk_clist_set_column_justification(GTK_CLIST(w), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification(GTK_CLIST(w), 2,  GTK_JUSTIFY_CENTER); */
  gtk_clist_set_column_width(GTK_CLIST(w),0,90);
  gtk_clist_set_column_width(GTK_CLIST(w),1,70);
  gtk_clist_set_column_width(GTK_CLIST(w),2,30);
  gtk_clist_set_column_width(GTK_CLIST(w),3,70);
  gtk_clist_set_column_width(GTK_CLIST(w),4,70);
  gtk_clist_column_titles_passive(GTK_CLIST(w));
  // gtk_clist_set_policy(GTK_CLIST(w),GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

  

  return w;
}

int connect_dnd(void)
{
  static GtkTargetEntry drop_types[] = { { "text/plain",0,1 } };

  // gdk_window_dnd_drop_set(GTK_CLIST(wi.lista)->clist_window,TRUE,dropTypes,2,FALSE);
  /* gtk_signal_connect (GTK_OBJECT (wi.lista), "drop_data_available_event",
     GTK_SIGNAL_FUNC(dnd_drop), NULL); */

  /*  gtk_signal_connect(GTK_OBJECT(wi.lista),"drag_data_get",
      GTK_SIGNAL_FUNC(dnd_drop),NULL); */

  /*
    gtk_widget_dnd_drop_set(wi.lista, 1, dropTypes, 1, 0);
  */

  gtk_signal_connect (GTK_OBJECT (wi.lista), "drag_data_received",
                      GTK_SIGNAL_FUNC(dnd_drop), NULL);

  gtk_drag_dest_set (wi.lista,(GtkDestDefaults)(
                     GTK_DEST_DEFAULT_MOTION |
                     GTK_DEST_DEFAULT_HIGHLIGHT |
                     GTK_DEST_DEFAULT_DROP),
                     drop_types, sizeof(drop_types) / sizeof(drop_types[0]),
                     GDK_ACTION_COPY);

  return TRUE;
}

// luodaan ikkuna ja sihen tarvittavat widgetit
void alustaGTK(char *argv0)
{
  /* menu stuff */
  GnomeUIInfo filemenu[] = {
    (GnomeUIInfo){GNOME_APP_UI_ITEM,
		  N_("_New archive..."),N_("Create new archive"),
		  create_new_file_event,NULL,NULL,
		  GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_NEW,
		  'N',GDK_CONTROL_MASK,NULL},
    
    (GnomeUIInfo){GNOME_APP_UI_ITEM,
		  N_("_Open..."),N_("Open archive"),
		  open_file_selection,NULL,NULL,
		  GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_OPEN,
		  wi.ae[0].key,wi.ae[0].mod,NULL},
    
    GNOMEUIINFO_SEPARATOR,
    (GnomeUIInfo){GNOME_APP_UI_ITEM,
		  N_("_Preferences"),N_("Preferences"),
		  preferences_event,NULL,NULL,
		  GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_PREF,
		  wi.ae[1].key,wi.ae[1].mod,NULL},
    GNOMEUIINFO_SEPARATOR,
    {GNOME_APP_UI_ITEM,
     N_("_Exit"),N_("Exit"),
     delete_event,NULL,NULL,
     GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_EXIT,
     wi.ae[2].key,wi.ae[2].mod,NULL},
	 
    GNOMEUIINFO_END
  };

  GnomeUIInfo actionsmenu[] = {
    {GNOME_APP_UI_ITEM,
     N_("Extract..."),NULL,
     unCompress_event,NULL,NULL,
     GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_PROP,
     wi.ae[3].key,wi.ae[3].mod,NULL},
    {GNOME_APP_UI_ITEM,
     N_("Test"),NULL,
     testcrc_event,NULL,NULL,
     GNOME_APP_PIXMAP_NONE,NULL,
     wi.ae[4].key,wi.ae[4].mod,NULL},
    {GNOME_APP_UI_ITEM,
     N_("View"),NULL,
     view_event,NULL,NULL,
     GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_SEARCH,
     wi.ae[5].key,wi.ae[5].mod,NULL},

    GNOMEUIINFO_END
  };

  GnomeUIInfo helpmenu[] = {
    {GNOME_APP_UI_ITEM,
     N_("About..."),NULL,
     about_cb,NULL,NULL,
     GNOME_APP_PIXMAP_STOCK,GNOME_STOCK_MENU_ABOUT,
     0,(GdkModifierType)0,NULL},
    GNOMEUIINFO_SEPARATOR,
    GNOMEUIINFO_HELP("gxunzip"),
    GNOMEUIINFO_END,
  };    


  GnomeUIInfo mainmenu[] = {
    GNOMEUIINFO_SUBTREE(N_("_File"), filemenu),
    GNOMEUIINFO_SUBTREE(N_("_Actions"), actionsmenu),
#define MENU_HELP_POS 2
    GNOMEUIINFO_SUBTREE(N_("_Help"),helpmenu),
    GNOMEUIINFO_END
  };

  /* tyokalupalkki (toolbar) */
  GnomeUIInfo toolbar[]={
    GNOMEUIINFO_ITEM_STOCK(N_("Open"),N_("Open file..."),
			   open_file_selection,GNOME_STOCK_PIXMAP_OPEN),
    GNOMEUIINFO_SEPARATOR,
    GNOMEUIINFO_ITEM_STOCK(N_("Extract"),N_("Extract file..."),
			   unCompress_event,GNOME_STOCK_PIXMAP_PROPERTIES),
    GNOMEUIINFO_ITEM_STOCK(N_("View"),N_("View file"),
			   view_event,GNOME_STOCK_PIXMAP_SEARCH),
    GNOMEUIINFO_SEPARATOR,
    GNOMEUIINFO_ITEM_STOCK(N_("Exit"),N_("Exit"),
			   delete_event,GNOME_STOCK_PIXMAP_EXIT),
    GNOMEUIINFO_END
  };


  char eMessage[100];
  /*    char *dropTypes[] = { "text/plain" }; */
  //    char *dropTypes[]= { "url:ALL" };

  tyhjennaTaulukko(eMessage,100);
  strcpy(eMessage,"Xunzip ");
  strcat(eMessage,VERSION);

  // paaikkuna
  // wi.window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
  
  
  wi.window=gnome_app_new(argv0,"Xunzip");
  
  wi.readConfig();
	
  gtk_window_set_title(GTK_WINDOW(wi.window),eMessage);
  gtk_signal_connect(GTK_OBJECT(wi.window),"delete_event",GTK_SIGNAL_FUNC(delete_event),NULL);
  gtk_container_border_width(GTK_CONTAINER(wi.window),1);
  if (wi.default_width && wi.default_height)
    {
      wi.leveys=wi.default_width;
      wi.korkeus=wi.default_height;
    }
  gtk_window_set_policy(GTK_WINDOW(wi.window), TRUE, TRUE, FALSE);
  gtk_widget_set_usize(wi.window,wi.leveys,wi.korkeus);
  gtk_window_set_policy(GTK_WINDOW(wi.window), TRUE, TRUE, TRUE);

  // uusi vbox (ex. taulukko)
  // wi.taulukko=gtk_table_new(6,4,TRUE);
  wi.taulukko=gtk_vbox_new(FALSE,0);
  // gtk_table_set_row_spacings (GTK_TABLE (wi.taulukko), 1);
  // gtk_table_set_col_spacings (GTK_TABLE (wi.taulukko), 1);
    
  // clist
  wi.lista=createList();
  gtk_signal_connect(GTK_OBJECT(wi.lista),"select_row",GTK_SIGNAL_FUNC(select_row),NULL);
  gtk_signal_connect(GTK_OBJECT(wi.lista),"unselect_row",GTK_SIGNAL_FUNC(unselect_row),NULL);
  gtk_signal_connect(GTK_OBJECT (wi.lista),"realize",GTK_SIGNAL_FUNC (connect_dnd),NULL);
  // gnome_app_set_contents(GNOME_APP(wi.window), wi.lista);
  // gtk_table_attach_defaults(GTK_TABLE(wi.taulukko),wi.lista,0,4,0,6);
  GtkWidget *scrolled;

  scrolled = gtk_scrolled_window_new(NULL, NULL);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled),
				  GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
  gtk_container_add (GTK_CONTAINER (scrolled),wi.lista);

  gtk_box_pack_end(GTK_BOX(wi.taulukko),scrolled,TRUE,TRUE,0);
  gtk_widget_show(scrolled);
    
  gnome_app_create_menus(GNOME_APP(wi.window),mainmenu);
  gtk_menu_item_right_justify(GTK_MENU_ITEM(mainmenu[MENU_HELP_POS].widget));
  // toolbarin
  gnome_app_create_toolbar(GNOME_APP(wi.window), toolbar);

  create_recent_menu();

  // statusbar
  wi.bar=gnome_appbar_new(TRUE, TRUE,GNOME_PREFERENCES_USER);
  gnome_app_set_statusbar(GNOME_APP(wi.window),wi.bar);

  gtk_widget_show(wi.lista);
  gtk_widget_show(wi.taulukko);

  gnome_app_set_contents(GNOME_APP(wi.window), wi.taulukko);
  gtk_widget_realize(wi.window);
  gtk_window_set_policy(GTK_WINDOW(wi.window), TRUE, TRUE, TRUE);

  gtk_widget_show_all(wi.window);
}

// avataan ikkuna josta voi valita tiedoston/hakemiston
void create_file_selection (int type)
{
  if (type==0)
    wi.filesel = gtk_file_selection_new ("File selection");
  else
    wi.filesel = gtk_file_selection_new ("Directory selection");

  gtk_window_position (GTK_WINDOW (wi.filesel), GTK_WIN_POS_MOUSE);
  gtk_signal_connect (GTK_OBJECT (wi.filesel), "destroy",
		      (GtkSignalFunc) destroy_window,
		      &wi.filesel);
      
  if (type==0)
    gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION (wi.filesel)->ok_button),
			"clicked", (GtkSignalFunc) file_selection_ok,wi.filesel);
  else
    gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(wi.filesel)->ok_button),
		       "clicked",(GtkSignalFunc)dir_selection_ok,wi.filesel);
  gtk_signal_connect_object (GTK_OBJECT (GTK_FILE_SELECTION (wi.filesel)->cancel_button),
			     "clicked", (GtkSignalFunc) gtk_widget_destroy,
			     GTK_OBJECT (wi.filesel));
  gtk_widget_show(wi.filesel);
}

/* session management stuff */
GnomeClient
*newGnomeClient(char *name)
{
  gchar *buf[1024];

  GnomeClient *client;

  // client = gnome_client_new_default();
  client = gnome_master_client();

  if (!client)
    return NULL;

  getcwd((char *)buf,sizeof(buf));
  gnome_client_set_current_directory(client, (char *)buf);

  gtk_object_ref(GTK_OBJECT(client));
  gtk_object_sink(GTK_OBJECT(client));

  gtk_signal_connect (GTK_OBJECT (client), "save_yourself",
		      GTK_SIGNAL_FUNC (save_state), name);
  gtk_signal_connect (GTK_OBJECT (client), "die",
		      GTK_SIGNAL_FUNC (session_die), NULL);
  return client;
}

void
session_die (gpointer )
{
  wi.saveConfig();
  gtk_main_quit ();
}

int
save_state (GnomeClient        *client,
            gint                ,
            GnomeRestartStyle   ,
            gint                ,
            GnomeInteractStyle  ,
            gint                ,
            gpointer            client_data)
{
  gchar *sess_id;
  gchar *argv[2];
  // gchar *s;
  // gint j;
  // HelpWindow win;
  // gint xpos, ypos;
  gint argc=0;
  // gint xsize, ysize;

  sess_id=gnome_client_get_id(client);
  TK_ASSERT(1,g_message("Saving myself"););
  // gdk_window_get_origin(wi.window, &xpos, &ypos);
  // gdk_window_get_size(wi.window, &xsize, &ysize);
	
  argv[0] = (char *)client_data;
  /* argv[1] = "--geometry";
  argv[2] = g_malloc(32);
  sprintf(argv[2], "%dx%d+%d+%d", xsize, ysize, xpos, ypos);
  argc = 3; */
  argc=1;
  if (zip.isOpen())
    {
      argv[1]=(char*)g_malloc(strlen(zip.getArchiveName()));
      strcpy(argv[1],zip.getArchiveName());
      argc=2;
    }
  
    
  gnome_client_set_restart_command (client, argc, argv);
  /* i.e. clone_command = restart_command - '--sm-client-id' */
  gnome_client_set_clone_command (client, argc, argv);
  g_free(argv[1]);
  wi.saveConfig();
  return 1;
}

#endif /* USE_GTK */
