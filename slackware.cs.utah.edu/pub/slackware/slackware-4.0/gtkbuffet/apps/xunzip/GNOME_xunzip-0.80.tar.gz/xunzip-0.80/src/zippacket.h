// -*-c++-*-
/*
    Xunzip for Linux, handles gzip and zip files via zlib.
    Copyright (C) 1998 Tero Koskinen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 
*/

#include <fstream.h>

#ifdef USE_GTK
#include <gtk/gtk.h>
#include <gnome.h>
#else
#include <qapp.h>
#include <qlistbox.h>
#include <qprogdlg.h> 
#include <ktablistbox.h>
#include <kstatusbar.h>
#include <qstring.h>
#endif

#include <zlib.h>

#include "config.h"
#include "utils.h"
#include "zipheader.h"
#include "debug.h"
#include "sll.h" // yet another single linked list...
#include "compress.h"

#ifndef TK_ZIPPACKET_H
#define TK_ZIPPACKET_H


class ZipPacket
{
public:
  ZipPacket();
  ~ZipPacket();
#ifdef USE_GTK  
  int open(char *file,GtkWidget *lista,int tmpfile=0); // 0=OK,-1=NOT ok!
  int close(GtkWidget *lista);
#else
  int open(const char *file,KTabListBox *lista,int tmpfile=0,QString url=0,QProgressDialog *dlg=0); // jos tmpfile=1 file=kfm:n luoma aputiedosto
  int close(KTabListBox *lista);
#endif
  int isOpen(void) { return opened; }
#ifndef USE_GTK
  int unZip(const char *path,int sfile=-1,int options=0,QProgressDialog *progress=0,KStatusBar *bar=0,QWidget *qw=0); // return 0=OK,-1=NOT ok!
  int testcrc(QListBox *lista);
#else
  int unZip(const char *path,int sfile=-1,int options=0,GtkWidget *statusbar=0); // return 0=OK,-1=NOT ok!
  int testcrc(GtkWidget *lista);
#endif

  unsigned long getCSize(const char *name);
  unsigned long getUnCSize(const char *name);
  int getFiles(void) { return files; }
  char* getName(int index);
  char* getArchiveName(void) { return tiedosto; }
  CDRNode* getNode(int index) { return cdList.getNode(index); }
  int getType(void) { return fileType; }
  int isTmpFile(void) { return tmpFileExists; }
#ifndef USE_GTK
  QString getUrl() { return fileUrl; }
#endif

  // compression methods
  int compress(SingleLinkedList<char> & files,int type,int options=0);

#ifdef USE_GTK
  int openRar(GtkWidget *lista);
#endif

private:
  BasicHeaderList bhList;
  CentralDirRecordList cdList;
  SingleLinkedList<ArjMainHeader> amList;
  SingleLinkedList<ArjFileHeader> afList;
  SingleLinkedList<RarFileHeader> rarFileList;
  RarMarker rarMarker;
  RarArchiveHeader rarHeader;
  ZipHeader zh;
  ifstream fin;
  int opened;
  int files;
  char tiedosto[FNAME_MAX];
#ifndef USE_GTK
  QString fileUrl;
#endif
  
  int inflatePacked(unsigned char *compr,unsigned long comprLen,ofstream & fout);
  int testInflated(unsigned char *compr,unsigned long comprLen,unsigned long orig_crc);
  int testStored(unsigned char *compr,unsigned long comprLen,unsigned long original_crc);

  int gunzipFile(char *unComprFilename);
  int fileType; // 1=zipfile, 2=gzip, 3=arj ,4=bzip2, 5=rar
  int tmpFileExists;

  Compress cmpr;
};

#endif // TK_ZIPPACKET_H
