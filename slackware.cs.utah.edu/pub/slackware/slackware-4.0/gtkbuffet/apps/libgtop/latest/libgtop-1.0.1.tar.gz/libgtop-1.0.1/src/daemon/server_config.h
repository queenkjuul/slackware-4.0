#define SERVER_PORT		42800

#define SERVER_UID		99
#define SERVER_GID		99

#define HOST_TABLE_ENTRIES	1

const char *permitted_host_names [HOST_TABLE_ENTRIES] = 
{ NULL };

unsigned long permitted_hosts [HOST_TABLE_ENTRIES];
