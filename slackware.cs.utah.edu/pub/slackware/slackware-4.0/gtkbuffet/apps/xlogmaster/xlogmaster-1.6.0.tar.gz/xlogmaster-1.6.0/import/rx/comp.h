/* ,file-id archive://[lord]/420/rx/comp.h/1998-05-18
 */
#ifndef COMPH
#define COMPH

/*	Copyright (C) 1997 Tom Lord
 * 
 * This program is provided to you under the terms of the Liberty Software
 * License.  You are NOT permitted to redistribute, modify, or use it
 * except in very specific ways described by that license.
 *
 * This software comes with NO WARRANTY.
 * 
 * You should have received a copy of the Liberty Software License
 * along with this software; see the file =LICENSE.  If not, write to
 * the Tom Lord, 1810 Francisco St. #2, Berkeley CA, 94703, USA.  
 */



/* The interface for translating a regexp string to 
 * a regexp syntax tree.
 */

extern char *rx_error_msg[];
extern unsigned char rx_case_fold_translation_table[];
extern unsigned char rx_id_translation_table[];



extern unsigned char rx_id_translation[];

/* automatically generated __STDC__ prototypes */
extern int rx_parse (struct rx_exp_node ** rx_exp_p,
		     int *nsub,
		     const char *pattern,
		     int size,
		     int extended_p,
		     int no_newline,
		     int dfa_only,
		     int cset_size,
		     unsigned char *translate);
#endif  /* comph */
