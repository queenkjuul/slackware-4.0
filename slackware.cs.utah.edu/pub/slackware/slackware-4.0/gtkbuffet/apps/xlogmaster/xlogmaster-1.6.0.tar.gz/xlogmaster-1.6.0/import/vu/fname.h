/* ,file-id archive://[lord]/389/vu/./fname.h/1998-05-18
*/
#ifndef FNAMEH
#define FNAMEH

/*	Copyright (C) 1997 Tom Lord
 * 
 * This program is provided to you under the terms of the Liberty Software
 * License.  You are NOT permitted to redistribute, modify, or use it
 * except in very specific ways described by that license.
 *
 * This software comes with NO WARRANTY.
 * 
 * You should have received a copy of the Liberty Software License
 * along with this software; see the file =LICENSE.  If not, write to
 * the Tom Lord, 1810 Francisco St. #2, Berkeley CA, 94703, USA.  
 */





/* automatically generated __STDC__ prototypes */
extern char * file_name_tail (char * fname);
#endif  /* FNAMEH */
