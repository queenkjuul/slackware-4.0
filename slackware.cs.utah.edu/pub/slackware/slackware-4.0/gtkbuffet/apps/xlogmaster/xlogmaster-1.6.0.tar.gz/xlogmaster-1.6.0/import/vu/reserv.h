/* ,file-id archive://[lord]/397/vu/./reserv.h/1998-05-18
*/
#ifndef RESERVH
#define RESERVH

/*	Copyright (C) 1997 Tom Lord
 * 
 * This program is provided to you under the terms of the Liberty Software
 * License.  You are NOT permitted to redistribute, modify, or use it
 * except in very specific ways described by that license.
 *
 * This software comes with NO WARRANTY.
 * 
 * You should have received a copy of the Liberty Software License
 * along with this software; see the file =LICENSE.  If not, write to
 * the Tom Lord, 1810 Francisco St. #2, Berkeley CA, 94703, USA.  
 */



/* reserv: allocate a file descriptor, 
 *	   open to /dev/null with the given flags.
 *
 * unreserv: release a file descriptor allocated by
 *	     "reserv" for possible re-use.  It is an
 *	     undetected error to unreserv a descriptor
 *	     that was not allocated by reserv or that
 *	     has been closed.
 */


/* automatically generated __STDC__ prototypes */
extern int reserv (int * errn, int flags);
extern void unreserv (int fd);
#endif  /* RESERVH */
