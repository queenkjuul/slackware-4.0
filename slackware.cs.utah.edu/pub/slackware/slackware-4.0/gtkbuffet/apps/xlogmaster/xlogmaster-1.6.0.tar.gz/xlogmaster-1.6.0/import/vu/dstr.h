/* ,file-id archive://[lord]/385/vu/./dstr.h/1998-05-18
*/
#ifndef DSTRH
#define DSTRH

/*	Copyright (C) 1997 Tom Lord
 * 
 * This program is provided to you under the terms of the Liberty Software
 * License.  You are NOT permitted to redistribute, modify, or use it
 * except in very specific ways described by that license.
 *
 * This software comes with NO WARRANTY.
 * 
 * You should have received a copy of the Liberty Software License
 * along with this software; see the file =LICENSE.  If not, write to
 * the Tom Lord, 1810 Francisco St. #2, Berkeley CA, 94703, USA.  
 */



struct dstring
{
  unsigned int len;
  unsigned char *chr;
};


/* automatically generated __STDC__ prototypes */
extern void init_dstr (struct dstring * str, char * chr, int len);
extern void free_dstr (struct dstring * d);
extern void free_dstr_static (struct dstring * d);
extern void dstr_set (struct dstring * d, char * chr, int len);
extern void dstr_append (struct dstring * d, char * chr, int len);
extern int dstr_compare (struct dstring *d, char * chr, int len);
#endif  /* DSTRH */
