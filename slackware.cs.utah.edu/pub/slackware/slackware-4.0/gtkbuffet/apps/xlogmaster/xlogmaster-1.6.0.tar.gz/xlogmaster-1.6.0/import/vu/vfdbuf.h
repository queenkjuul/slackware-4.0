/* ,file-id archive://[lord]/405/vu/./vfdbuf.h/1998-05-18
*/
#ifndef VFDBUFH
#define VFDBUFH

/*	Copyright (C) 1997 Tom Lord
 * 
 * This program is provided to you under the terms of the Liberty Software
 * License.  You are NOT permitted to redistribute, modify, or use it
 * except in very specific ways described by that license.
 *
 * This software comes with NO WARRANTY.
 * 
 * You should have received a copy of the Liberty Software License
 * along with this software; see the file =LICENSE.  If not, write to
 * the Tom Lord, 1810 Francisco St. #2, Berkeley CA, 94703, USA.  
 */



extern struct vu_fs_discipline vu_fdbuf_vtable;


/* automatically generated __STDC__ prototypes */
extern int vfdbuf_copy_fd (int * errn, int sub_fd, int bufsize, int acc_flags);
extern void vfdbuf_shift (int fd, int amt);
extern void vfdbuf_eat (int fd, int amt);
extern int vfdbuf_flush (int * errn, int fd);
extern void vfdbuf_getbuf (char ** buf, int * buffered, int fd);
extern void vfdbuf_getbuf_space (char ** buf, int * buffered, int fd, int amt);
extern void vfdbuf_return (int fd, char * str, int len);
extern int vfdbuf_more (int * errn, char ** buf, int * buffered, int fd, int opt_amt);
extern int vfdbuf_eof (int * errn, int fd);
extern int vfdbuf_close (int * errn, int fd);
extern int vfdbuf_fsync (int * errn, int fd);
extern int vfdbuf_ftruncate (int * errn, int fd, int where);
extern int vfdbuf_read (int * errn, int fd, char * buf, int count);
extern int vfdbuf_write (int * errn, int fd, char * buf, int count);
extern int vfdbuf_lseek (int * errn, int fd, int offset, int whence);
#endif  /* VFDBUFH */
