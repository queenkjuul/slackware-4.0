/* ,file-id archive://[lord]/387/vu/./fmt.h/1998-05-18
*/
#ifndef FMTH
#define FMTH

/*	Copyright (C) 1997 Tom Lord
 * 
 * This program is provided to you under the terms of the Liberty Software
 * License.  You are NOT permitted to redistribute, modify, or use it
 * except in very specific ways described by that license.
 *
 * This software comes with NO WARRANTY.
 * 
 * You should have received a copy of the Liberty Software License
 * along with this software; see the file =LICENSE.  If not, write to
 * the Tom Lord, 1810 Francisco St. #2, Berkeley CA, 94703, USA.  
 */





/* automatically generated __STDC__ prototypes */
extern int fmt_uhex (int * errn, char * str, int size, unsigned long val);
extern int fmt_uint (int * errn, char * str, int size, unsigned long val);
extern int fmt_int (int * errn, char * str, int size, int val);
#endif  /* FMTH */
