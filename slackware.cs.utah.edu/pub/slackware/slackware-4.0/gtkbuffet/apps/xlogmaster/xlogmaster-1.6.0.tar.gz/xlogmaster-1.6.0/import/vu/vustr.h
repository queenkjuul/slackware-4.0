/* ,file-id archive://[lord]/409/vu/./vustr.h/1998-05-18
*/
#ifndef VUSTRH
#define VUSTRH

/*	Copyright (C) 1997 Tom Lord
 * 
 * This program is provided to you under the terms of the Liberty Software
 * License.  You are NOT permitted to redistribute, modify, or use it
 * except in very specific ways described by that license.
 *
 * This software comes with NO WARRANTY.
 * 
 * You should have received a copy of the Liberty Software License
 * along with this software; see the file =LICENSE.  If not, write to
 * the Tom Lord, 1810 Francisco St. #2, Berkeley CA, 94703, USA.  
 */





/* automatically generated __STDC__ prototypes */
extern int open_string (int * errn,
			char * str,
			int size,
			int flags,
			int permit_resize,
			int require_free);
extern int fd_string (char ** ret, int * szret, int * errn, int fd);
extern int vustr_open (int * errn, char * path, int flags, int mode);
extern int vustr_access (int * errn, char * path, int mode);
extern int vustr_chdir (int * errn, char * path);
extern int vustr_chmode (int * errn, char * path, int mode);
extern int vustr_chown (int * errn, char * path, int owner, int group);
extern int vustr_chroot (int * errn, char * path);
extern int vustr_closedir (int * errn, DIR * dir);
extern int vustr_close (int * errn, int fd);
extern int vustr_fchdir (int * errn, int fd);
extern int vustr_fstat (int * errn, int fd, struct stat * buf);
extern int vustr_fsync (int * errn, int fd);
extern int vustr_ftruncate (int * errn, int fd, int where);
extern int vustr_link (int * errn, char * from, char * to);
extern int vustr_lseek (int * errn, int fd, int offset, int whence);
extern int vustr_lstat (int * errn, char * path, struct stat * buf);
extern int vustr_mkdir (int * errn, char * path, int mode);
extern int vustr_opendir (int * errn, DIR ** retv, char * path);
extern int vustr_read (int * errn, int fd, char * buf, int count);
extern int vustr_readdir (int * errn, struct dirent * retv, DIR * dir);
extern int vustr_readlink (int * errn, char * path, char * buf, int bufsize);
extern int vustr_rename (int * errn, char * from, char * to);
extern int vustr_rmdir (int * errn, char * path);
extern int vustr_seekdir (int * errn, DIR * dir, int offset);
extern int vustr_stat (int * errn, char * path, struct stat * buf);
extern int vustr_symlink (int * errn, char * from, char * to);
extern int vustr_telldir (int * errn, DIR * dir);
extern int vustr_truncate (int * errn, char * path, int where);
extern int vustr_unlink (int * errn, char * path);
extern int vustr_utimes (int * errn, char * path, struct timeval * tvp);
extern int vustr_write (int * errn, int fd, char * buf, int count);
extern int vustr_fcntl (int * errn,
			int fd,
			int cmd,
			long arg);
extern int vustr_ioctl (int * errn,
			int fd,
			int request,
			void * params);
extern int vustr_dup (int * errn, int fd);
extern int vustr_dup2 (int * errn, int fd, int newfd);
#endif  /* VUSTRH */
