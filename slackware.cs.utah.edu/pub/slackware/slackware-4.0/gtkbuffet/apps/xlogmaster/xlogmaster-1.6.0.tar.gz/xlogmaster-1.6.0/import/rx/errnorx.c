/* ,file-id archive://[lord]/427/rx/errnorx.c/1998-05-18
 */
/*	Copyright (C) 1997 Tom Lord
 * 
 * This program is provided to you under the terms of the Liberty Software
 * License.  You are NOT permitted to redistribute, modify, or use it
 * except in very specific ways described by that license.
 *
 * This software comes with NO WARRANTY.
 * 
 * You should have received a copy of the Liberty Software License
 * along with this software; see the file =LICENSE.  If not, write to
 * the Tom Lord, 1810 Francisco St. #2, Berkeley CA, 94703, USA.  
 */



#include "errnorx.h"



char *rx_error_msg[] =
{
#undef RX_ERRNO
#define RX_ERRNO(A,B)	B,
  RX_ERRNO_LIST
};

