/* glob.h */
/* header file for filename globbing functions */

/*
gtkfind - a graphical "find" program
Copyright (C) 1998  Matthew Grossman <mattg@oz.net>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 */

#ifndef _GLOB_H
#define _GLOB_H

#include<string.h>
#include<stdio.h>
#include<stdlib.h>

#include<sys/types.h>

#include"config.h"

#ifdef NEED_ALLOCA_H
#include<alloca.h>
#endif /* NEED_ALLOCA_H */

char *match_squares(char *pattern, char *string);

int glob(char *pattern, char *string, char **registers, int c_reg);
char **glob_string(char *pattern, char *string, int copy_stringp);
char **allocate_glob_registers();
void free_glob_registers(char **registers);

char *copy_string(char *start, char *end);

#endif /* !_GLOB_H */
