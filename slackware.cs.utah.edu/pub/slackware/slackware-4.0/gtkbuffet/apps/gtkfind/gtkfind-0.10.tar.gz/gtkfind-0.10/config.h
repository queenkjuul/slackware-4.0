/* config.h */
/* edit this file to customize gtkfind to your site */
/* the defaults should work for most Linux systems */

/* if you are using a BSD system or for some other reason don't have a
   /usr/include/dirent.h file, uncomment this */
/* #define NO_DIRENT_H */

/* if you are using IRIX or need to include alloca.h to use alloca(3),
   uncomment this */
/* #define NEED_ALLOCA_H */

/* the path to xterm */
#define CONFIG_XTERM "/usr/X11R6/bin/xterm"

/* the path to man */
#define CONFIG_MAN "/usr/bin/man"
