/* flags.h */
/* the enum flag_t stuff, used to set flags instead of a bunch of global
   variables */

#ifndef FLAG_H
#define FLAG_H

enum flag_t { REGEXP_P = 0, SEARCH_SUBDIRS_P, SHELL_COMMAND_P,
	      PRINT_TO_STDOUT_P, PRINT_TO_WINDOW_P, PRINT_FILENAME_ANYWAY_P,
	      OWNER_READ_P, GROUP_READ_P, WORLD_READ_P, OWNER_WRITE_P,
	      GROUP_WRITE_P, WORLD_WRITE_P, OWNER_EXEC_P, GROUP_EXEC_P,
	      WORLD_EXEC_P, SETUID_P, SETGID_P, STICKY_P, DIRECTORY_P,
	      REGULAR_P, RAW_DEVICE_P, BLOCK_DEVICE_P, SYMLINK_P, SOCKET_P,
	      FIFO_P, UID_NOT_LOGIN_P, GID_NOT_GROUP_P, ATIME_ET_P,
	      ATIME_EQ_P, ATIME_LT_P, MTIME_ET_P, MTIME_EQ_P, MTIME_LT_P,
	      CTIME_ET_P, CTIME_EQ_P, CTIME_LT_P, WARNING_WINDOW_P,
	      LONG_OUTPUT_P};



int set_flag(enum flag_t f, int value);
int get_flag(enum flag_t f);
int reset_flags();


#endif /* !FLAG_H */
