/* flags.c */
/* this file contains the functions used to manipulate flags */

#include"flags.h"

/*
static int regexp_p = 0;
static int search_subdirs_p = 1;
static int shell_command_p = 0;
static int print_to_stdout_p = 0;
static int print_to_window_p = 1;
static int print_filename_anyway_p = 0;

static int owner_read_p = 0;
static int group_read_p = 0;
static int world_read_p = 0;

static int owner_write_p = 0;
static int group_write_p = 0;
static int world_write_p = 0;

static int owner_exec_p = 0;
static int group_exec_p = 0;
static int world_exec_p = 0;

static int setuid_p = 0;
static int setgid_p = 0;
static int sticky_p = 0;

static int directory_p = 0;
static int regular_p = 0;

static int raw_device_p = 0;
static int block_device_p = 0;
static int symlink_p = 0;
static int socket_p = 0;
static int fifo_p = 0;

static int uid_not_login_p = 0;
static int gid_not_group_p = 0;

static int atime_et_p = 0;
static int atime_eq_p = 0;
static int atime_lt_p = 0;

static int mtime_et_p = 0;
static int mtime_eq_p = 0;
static int mtime_lt_p = 0;

static int ctime_et_p = 0;
static int ctime_eq_p = 0;
static int ctime_lt_p = 0;

*/

#define MAX_FLAGS 256

static int flag_array[MAX_FLAGS] = {0};

int
set_flag(enum flag_t f, int value)
     /* set the flag f to value */
{
  int rv = 1;

  if(f >= MAX_FLAGS)
    rv = 0;
  else
    flag_array[(int)f] = value;
  
  return(rv);
}

int
get_flag(enum flag_t f)
     /* return the value of f */
{
  int rv = -1;

  rv = flag_array[(int)f];

  return(rv);
}

int
reset_flags()
     /* reset all flags that we want to reset to their default values */
{
  int rv = 0;
  int i = 0;

  for(i = 0; i < MAX_FLAGS; i++) {
    if(i == (int)SEARCH_SUBDIRS_P || i == (int)PRINT_TO_WINDOW_P ||
       i == (int)SHELL_COMMAND_P || i == (int)PRINT_TO_STDOUT_P ||
       i == (int)PRINT_FILENAME_ANYWAY_P || i == (int)WARNING_WINDOW_P ||
       i == (int)LONG_OUTPUT_P)
      /* do nothing */ ;
    else
      flag_array[i] = 0;
  }

  return(rv);
}
