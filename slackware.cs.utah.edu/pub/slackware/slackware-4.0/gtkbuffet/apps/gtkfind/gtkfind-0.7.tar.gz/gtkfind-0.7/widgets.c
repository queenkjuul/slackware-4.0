/* widgets.c */
/* gtkfind code for making and displaying the interface, callbacks... */

#include"widgets.h"

/* local variables */

static gfloat current_day = 0.0;
static gfloat current_month = 0.0;
static gfloat current_year = 0.0;
static gfloat current_hour = 0.0;
static gfloat current_minute = 0.0;
static gfloat current_second = 0.0;

void
make_widgets()
     /* make all the widgets and set them up properly */
{
  GtkWidget *hsep = NULL;
  GtkWidget *vbox = NULL;

  toplevel = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_container_border_width(GTK_CONTAINER(toplevel), 10);
  gtk_window_set_policy(GTK_WINDOW(toplevel), FALSE, TRUE, FALSE);
  gtk_signal_connect(GTK_OBJECT(toplevel), "delete_event",
		     GTK_SIGNAL_FUNC(quit), NULL);
  gtk_signal_connect(GTK_OBJECT(toplevel), "destroy", GTK_SIGNAL_FUNC(quit),
		     NULL);
  gtk_widget_show(toplevel);

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(toplevel), vbox);
  gtk_widget_show(vbox);

  make_directory_widgets(vbox);

  hsep = gtk_hseparator_new();
  gtk_container_add(GTK_CONTAINER(vbox), hsep);
  gtk_widget_show(hsep);

  make_notebook_widgets(vbox);
  
  hsep = gtk_hseparator_new();
  gtk_container_add(GTK_CONTAINER(vbox), hsep);
  gtk_widget_show(hsep);

  make_shell_widgets(vbox);
  
  
  hsep = gtk_hseparator_new();
  gtk_container_add(GTK_CONTAINER(vbox), hsep);
  gtk_widget_show(hsep);

  make_button_widgets(vbox);

  
  return;
}

void
make_button_widgets(GtkWidget *parent)
     /* make the "quit" and "find" buttons */
{
  GtkWidget *hbox = NULL;
  GtkWidget *button = NULL;
  GtkWidget *label = NULL;

  hbox = gtk_hbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(parent), hbox);
  gtk_widget_show(hbox);

  button = gtk_button_new();
  gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(quit),
		     NULL);
  gtk_container_add(GTK_CONTAINER(hbox), button);
  gtk_widget_show(button);

  label = gtk_label_new("Quit");
  gtk_container_add(GTK_CONTAINER(button), label);
  gtk_widget_show(label);

  button = gtk_button_new();
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
		     GTK_SIGNAL_FUNC(clear_find_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), button);
  gtk_widget_show(button);

  label = gtk_label_new("Clear");
  gtk_container_add(GTK_CONTAINER(button), label);
  gtk_widget_show(label);
  
  button = gtk_button_new();
  gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(find),
		     pattern);
  gtk_container_add(GTK_CONTAINER(hbox), button);
  gtk_widget_show(button);
		       
  label = gtk_label_new("Find");
  gtk_container_add(GTK_CONTAINER(button), label);
  gtk_widget_show(label);


  stop_button = gtk_button_new();
  gtk_signal_connect(GTK_OBJECT(stop_button), "clicked",
		     GTK_SIGNAL_FUNC(stop_find_callback),
		     NULL);
  gtk_container_add(GTK_CONTAINER(hbox), stop_button);
  
  label = gtk_label_new("Stop");
  gtk_container_add(GTK_CONTAINER(stop_button), label);
  gtk_widget_show(label);

  return;
}


void
make_shell_widgets(GtkWidget *parent)
     /* make the widgets associated with running shell commands */
{
  GtkWidget *toggle = NULL;
  GtkWidget *hbox = NULL;
  GtkWidget *label = NULL;
  GtkWidget *radio = NULL;
  GSList *gslist = NULL;

  /* output format selection */
  
  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(parent), hbox);
  gtk_widget_show(hbox);

  radio = gtk_radio_button_new_with_label(NULL, "Print only filename");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radio), TRUE);
  gtk_signal_connect(GTK_OBJECT(radio), "toggled",
		     GTK_SIGNAL_FUNC(output_format_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), radio);
  gtk_widget_show(radio);

  gslist = gtk_radio_button_group(GTK_RADIO_BUTTON(radio));
  
  radio = gtk_radio_button_new_with_label(gslist, "Print extra data");
  gtk_container_add(GTK_CONTAINER(hbox), radio);
  gtk_widget_show(radio);

  /* shell command stuff */
  
  toggle =
    gtk_check_button_new_with_label("Run a shell command?");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_container_add(GTK_CONTAINER(parent), toggle);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(shell_command_toggle_callback), NULL);
  gtk_widget_show(toggle);

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(parent), hbox);
  gtk_widget_show(hbox);

  label = gtk_label_new("Shell command:");
  gtk_container_add(GTK_CONTAINER(hbox), label);
  gtk_widget_show(label);
  
  shell_command = gtk_entry_new();
  gtk_container_add(GTK_CONTAINER(hbox), shell_command);
  gtk_widget_show(shell_command);

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(parent), hbox);
  gtk_widget_show(hbox);

  toggle =
    gtk_check_button_new_with_label("Print to stdout?");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle),
			      FALSE);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(print_to_stdout_toggle_callback), NULL);
  gtk_widget_show(toggle);

  toggle =
    gtk_check_button_new_with_label("Print to window?");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle),
			      TRUE);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(print_to_window_toggle_callback), NULL);
  set_flag(PRINT_TO_WINDOW_P, 1);
  gtk_widget_show(toggle);

  toggle =
    gtk_check_button_new_with_label("Always print filename?");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle),
			      FALSE);
  gtk_container_add(GTK_CONTAINER(parent), toggle);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(print_filename_anyway_toggle_callback),
		     NULL);
  gtk_widget_show(toggle);

  return;
}

void
make_directory_widgets(GtkWidget *parent)
     /* make the widgets involved with choosing the directory to search */
{
  GtkWidget *label = NULL;
  GtkWidget *toggle = NULL;
  GtkWidget *hbox = NULL;
  GtkWidget *button = NULL;

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(parent), hbox);
  gtk_widget_show(hbox);
  
  label = gtk_label_new("Search directory:");
  gtk_container_add(GTK_CONTAINER(hbox), label);
  gtk_widget_show(label);

  button = gtk_button_new_with_label("Choose Directory");
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
		     GTK_SIGNAL_FUNC(find_directory_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), button);
  gtk_widget_show(button);
  
  directory = gtk_entry_new();
  gtk_container_add(GTK_CONTAINER(parent), directory);
  gtk_widget_show(directory);
  
  toggle = gtk_check_button_new_with_label("Search subdirectories?");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), TRUE);
  gtk_container_add(GTK_CONTAINER(parent), toggle);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(search_subdirs_toggle_callback), NULL);
  set_flag(SEARCH_SUBDIRS_P, 1);
  gtk_widget_show(toggle);
  
  return;
}


void
make_notebook_widgets(GtkWidget *parent)
     /* make the notebook1 and its subwidgets, which we use to select
	the files to match by */
{
  GtkWidget *notebook = NULL;

  get_current_mdy(&current_day, &current_month, &current_year);

  
  notebook = gtk_notebook_new();
  gtk_notebook_set_tab_pos(GTK_NOTEBOOK(notebook), GTK_POS_TOP);
  gtk_container_add(GTK_CONTAINER(parent), notebook);
  gtk_widget_show(notebook);

  make_match_filename_widgets(notebook);

  make_match_atime_widgets(notebook);
  make_match_ctime_widgets(notebook);
  make_match_mtime_widgets(notebook);

  make_match_mode_widgets(notebook);
  make_match_type_widgets(notebook);
  make_match_login_widgets(notebook);

  make_match_contents_widgets(notebook);
  
  return;
}

void
make_match_contents_widgets(GtkWidget *notebook)
     /* make a widget that lets you match a file by a text string inside it */
{
  GtkWidget *frame = NULL;
  GtkWidget *label = NULL;
  GtkWidget *vbox = NULL;

  /* Match Filename */
  
  frame = gtk_frame_new("Match Contents");
  gtk_widget_show(frame);

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(frame), vbox);
  gtk_widget_show(vbox);

  /* regular expression matching isn't implemented */
  /*
  toggle = gtk_toggle_button_new_with_label("Use regular expressions?");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(regexp_toggle_callback), NULL);
  gtk_widget_show(toggle);
  */

  label = gtk_label_new("Match file containing text:");
  gtk_container_add(GTK_CONTAINER(vbox), label);
  gtk_widget_show(label);
  
  content_pattern = gtk_entry_new();
  gtk_container_add(GTK_CONTAINER(vbox), content_pattern);
  gtk_object_set_data(GTK_OBJECT(content_pattern), "reset_yourself",
		      reset_entry);
  gtk_widget_show(content_pattern);

  label = gtk_label_new("Contents");
  gtk_widget_show(label);
  
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

  return;

}

void
make_match_filename_widgets(GtkWidget *notebook)
     /* make the first frame of notebook */
{
  GtkWidget *frame = NULL;
  GtkWidget *label = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *hbox = NULL;

  
  /* Match Filename */
  
  frame = gtk_frame_new("Match Filename");
  gtk_widget_show(frame);

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(frame), vbox);
  gtk_widget_show(vbox);

  /* regular expression matching isn't implemented */
  /*
  toggle = gtk_toggle_button_new_with_label("Use regular expressions?");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(regexp_toggle_callback), NULL);
  gtk_widget_show(toggle);
  */

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(vbox), hbox);
  gtk_widget_show(hbox);

  label = gtk_label_new("Filename:");
  gtk_container_add(GTK_CONTAINER(hbox), label);
  gtk_widget_show(label);
  
  pattern = gtk_entry_new();
  gtk_container_add(GTK_CONTAINER(hbox), pattern);
  gtk_object_set_data(GTK_OBJECT(pattern), "reset_yourself", reset_entry);
  gtk_widget_show(pattern);

  label = gtk_label_new("Filename");
  gtk_widget_show(label);

  
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

  return;
}

void
make_match_atime_widgets(GtkWidget *notebook)
{

  GtkWidget *frame = NULL;
  GtkWidget *label = NULL;
  GtkWidget *whatis = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *toggle = NULL;
  GtkWidget *hbox = NULL;

    /* Match Atime */
  
  frame = gtk_frame_new("Match atime");
  gtk_widget_show(frame);

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(frame), vbox);
  gtk_widget_show(vbox);

  /* earlier than, later than, or equal too...you can select more than one */

  whatis = gtk_label_new("atime is the last time the file was read or executed");
  gtk_container_add(GTK_CONTAINER(vbox), whatis);
  gtk_widget_show(whatis);
  
  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(vbox), hbox);
  gtk_widget_show(hbox);

  toggle = gtk_check_button_new_with_label("Earlier than:");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(atime_et_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);
 
  toggle = gtk_check_button_new_with_label("Equal to:");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(atime_eq_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);
  
  toggle = gtk_check_button_new_with_label("Later than:");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(atime_lt_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  make_all_spinners(vbox,
		    &atime_day_spin, &atime_month_spin, &atime_year_spin,
		    &atime_hour_spin, &atime_minute_spin, &atime_second_spin);
  
  label = gtk_label_new("atime");
  gtk_widget_show(label);

  
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

  return;
}

void
make_match_ctime_widgets(GtkWidget *notebook)
{
  GtkWidget *frame = NULL;
  GtkWidget *label = NULL;
  GtkWidget *whatis = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *toggle = NULL;
  GtkWidget *hbox = NULL;

   /* Match Ctime */
  
  frame = gtk_frame_new("Match ctime");
  gtk_widget_show(frame);

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(frame), vbox);
  gtk_widget_show(vbox);

  whatis = gtk_label_new("ctime is the last time the file's inode was changed");
  gtk_container_add(GTK_CONTAINER(vbox), whatis);
  gtk_widget_show(whatis);
  
  /* earlier than, later than, or equal too...you can select more than one */
  
  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(vbox), hbox);
  gtk_widget_show(hbox);

  toggle = gtk_check_button_new_with_label("Earlier than:");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(ctime_et_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);
 
  toggle = gtk_check_button_new_with_label("Equal to:");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(ctime_eq_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);
  
  toggle = gtk_check_button_new_with_label("Later than:");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(ctime_lt_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  make_all_spinners(vbox,
		    &ctime_day_spin, &ctime_month_spin, &ctime_year_spin,
		    &ctime_hour_spin, &ctime_minute_spin, &ctime_second_spin);
  
  label = gtk_label_new("ctime");
  gtk_widget_show(label);

  
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);


  return;
}

void
make_match_mtime_widgets(GtkWidget *notebook)
{
  GtkWidget *frame = NULL;
  GtkWidget *label = NULL;
  GtkWidget *whatis = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *toggle = NULL;
  GtkWidget *hbox = NULL;


 /* Match Mtime */
  
  frame = gtk_frame_new("Match mtime");
  gtk_widget_show(frame);

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(frame), vbox);
  gtk_widget_show(vbox);

  whatis = gtk_label_new("mtime is the last time the file was written");
  gtk_container_add(GTK_CONTAINER(vbox), whatis);
  gtk_widget_show(whatis);
  
  /* earlier than, later than, or equal too...you can select more than one */
  
  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(vbox), hbox);
  gtk_widget_show(hbox);

  toggle = gtk_check_button_new_with_label("Earlier than:");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(mtime_et_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);
 
  toggle = gtk_check_button_new_with_label("Equal to:");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(mtime_eq_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);
  
  toggle = gtk_check_button_new_with_label("Later than:");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(mtime_lt_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  make_all_spinners(vbox,
		    &mtime_day_spin, &mtime_month_spin, &mtime_year_spin,
		    &mtime_hour_spin, &mtime_minute_spin, &mtime_second_spin);
  
  label = gtk_label_new("mtime");
  gtk_widget_show(label);

  
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

  
  return;
} 

void
make_match_mode_widgets(GtkWidget *notebook)
{
  GtkWidget *frame = NULL;
  GtkWidget *label = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *toggle = NULL;
  GtkWidget *hbox = NULL;


  /* Match Mode */

  frame = gtk_frame_new("Match Mode");
  gtk_widget_show(frame);

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(frame), hbox);
  gtk_widget_show(hbox);

  /* read */
  
  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);

  toggle = gtk_check_button_new_with_label("owner read");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(owner_read_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("group read");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(group_read_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("world read");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(world_read_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  /* write */
  
  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);
  
  toggle = gtk_check_button_new_with_label("owner write");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(owner_write_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("group write");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(group_write_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("world write");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(world_write_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  /* exec */

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);
  
  toggle = gtk_check_button_new_with_label("owner execute");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(owner_exec_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("group execute");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(group_exec_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("world execute");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(world_exec_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  
  label = gtk_label_new("Mode");
  gtk_widget_show(label);


  gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);

  return;
}

void
make_match_type_widgets(GtkWidget *notebook)
{
  GtkWidget *frame = NULL;
  GtkWidget *label = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *toggle = NULL;
  GtkWidget *hbox = NULL;


  /* Match Type */


  frame = gtk_frame_new("Match Type");
  gtk_widget_show(frame);

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(frame), hbox);
  gtk_widget_show(hbox);

  /* extra bits */
  
  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);

  toggle = gtk_check_button_new_with_label("setuid");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(setuid_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("setgid");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(setgid_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("sticky");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(sticky_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  /* directory or regular file */
  
  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);
  
  toggle = gtk_check_button_new_with_label("directory");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(directory_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("regular file");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(regular_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  /* special files */

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);
  
  toggle = gtk_check_button_new_with_label("raw device");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(raw_device_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("block device");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(block_device_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);


  toggle = gtk_check_button_new_with_label("symlink");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(symlink_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  
  toggle = gtk_check_button_new_with_label("socket");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(socket_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  
  toggle = gtk_check_button_new_with_label("fifo");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(toggle), FALSE);
  gtk_signal_connect(GTK_OBJECT(toggle), "toggled",
		     GTK_SIGNAL_FUNC(fifo_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(vbox), toggle);
  gtk_object_set_data(GTK_OBJECT(toggle), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(toggle);

  
  label = gtk_label_new("Type");
  gtk_widget_show(label);
  
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);


  return;
}

void
make_match_login_widgets(GtkWidget *notebook)
{
  GtkWidget *frame = NULL;
  GtkWidget *label = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *radio = NULL;
  GtkWidget *hbox = NULL;
  GSList *gslist = NULL;

  /* Match Login and/or Group */

  
  frame = gtk_frame_new("Match Login/Group");
  gtk_widget_show(frame);

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(frame), vbox);
  gtk_widget_show(vbox);
  
  /* login */

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(vbox), hbox);
  gtk_widget_show(hbox);

  radio = gtk_radio_button_new_with_label(NULL, "Match login");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radio), TRUE);
  gtk_signal_connect(GTK_OBJECT(radio), "toggled",
		     GTK_SIGNAL_FUNC(uid_not_login_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), radio);
  gtk_object_set_data(GTK_OBJECT(radio), "reset_yourself",
		      reset_toggle_button_down);
  gtk_widget_show(radio);

  gslist = gtk_radio_button_group(GTK_RADIO_BUTTON(radio));

  radio = gtk_radio_button_new_with_label(gslist, "Match uid");
  gtk_container_add(GTK_CONTAINER(hbox), radio);
  gtk_object_set_data(GTK_OBJECT(radio), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(radio);

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(vbox), hbox);
  gtk_widget_show(hbox);

  label = gtk_label_new("login/uid:");
  gtk_container_add(GTK_CONTAINER(hbox), label);
  gtk_widget_show(label);
  
  login_entry = gtk_entry_new();
  gtk_container_add(GTK_CONTAINER(hbox), login_entry);
  gtk_object_set_data(GTK_OBJECT(login_entry), "reset_yourself", reset_entry);
  gtk_widget_show(login_entry);

  
  /* group */

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(vbox), hbox);
  gtk_widget_show(hbox);

  radio = gtk_radio_button_new_with_label(NULL, "Match group");
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radio), TRUE);
  gtk_signal_connect(GTK_OBJECT(radio), "toggled",
		     GTK_SIGNAL_FUNC(gid_not_group_toggle_callback), NULL);
  gtk_container_add(GTK_CONTAINER(hbox), radio);
  gtk_object_set_data(GTK_OBJECT(radio), "reset_yourself",
		      reset_toggle_button_down);
  gtk_widget_show(radio);

  gslist = gtk_radio_button_group(GTK_RADIO_BUTTON(radio));

  radio = gtk_radio_button_new_with_label(gslist, "Match gid");
  gtk_container_add(GTK_CONTAINER(hbox), radio);
  gtk_object_set_data(GTK_OBJECT(radio), "reset_yourself",
		      reset_toggle_button_up);
  gtk_widget_show(radio);

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(vbox), hbox);
  gtk_widget_show(hbox);

  label = gtk_label_new("group/gid:");
  gtk_container_add(GTK_CONTAINER(hbox), label);
  gtk_widget_show(label);
  
  group_entry = gtk_entry_new();
  gtk_container_add(GTK_CONTAINER(hbox), group_entry);
  gtk_object_set_data(GTK_OBJECT(group_entry), "reset_yourself", reset_entry);
  gtk_widget_show(group_entry);


  
  label = gtk_label_new("Owner");
  gtk_widget_show(label);
  
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook), frame, label);


  return;
}


/* callbacks */


void
find_directory_callback()
     /* bring up a find file window to choose the directory to search */
{
  GtkWidget *filesel = NULL;

  filesel = gtk_file_selection_new("Find Directory");
  gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->ok_button),
		     "clicked", GTK_SIGNAL_FUNC(filesel_ok_callback), filesel);
  gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filesel)->cancel_button),
		     "clicked", GTK_SIGNAL_FUNC(filesel_cancel_callback),
		     filesel);

  gtk_widget_show(filesel);

  return;
}

void
filesel_ok_callback(GtkWidget *w, GtkFileSelection *filesel)
     /* we selected ok in the find directory widget */
{
  char *s = NULL;

  s = gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel));
  if(strlen(s) > 0) {
    gtk_entry_set_text(GTK_ENTRY(directory), s);
    gtk_widget_destroy(GTK_WIDGET(filesel));
  }

  return;
}

void
filesel_cancel_callback(GtkWidget *w, GtkFileSelection *filesel)
     /* we selected cancel in the find directory widget */
{
  gtk_widget_destroy(GTK_WIDGET(filesel));

  return;
}

void
print_filename_anyway_toggle_callback()
{
  get_flag(PRINT_FILENAME_ANYWAY_P) ? (set_flag(PRINT_FILENAME_ANYWAY_P, 0)) :
    (set_flag(PRINT_FILENAME_ANYWAY_P, 1));
  return;
}

void
search_subdirs_toggle_callback()
{
  get_flag(SEARCH_SUBDIRS_P) ? (set_flag(SEARCH_SUBDIRS_P, 0)) :
    (set_flag(SEARCH_SUBDIRS_P, 1));
  return;
}


void
regexp_toggle_callback()
{
  get_flag(REGEXP_P) ? (set_flag(REGEXP_P, 0)) : (set_flag(REGEXP_P, 1));
  return;
}

void
shell_command_toggle_callback()
{
  get_flag(SHELL_COMMAND_P) ? (set_flag(SHELL_COMMAND_P, 0)) :
    (set_flag(SHELL_COMMAND_P, 1));
  return;
}

void
print_to_stdout_toggle_callback()
{
  get_flag(PRINT_TO_STDOUT_P) ? (set_flag(PRINT_TO_STDOUT_P, 0)) :
    (set_flag(PRINT_TO_STDOUT_P, 1));
  return;
}

void
print_to_window_toggle_callback()
{
  get_flag(PRINT_TO_WINDOW_P) ? (set_flag(PRINT_TO_WINDOW_P, 0)) :
    (set_flag(PRINT_TO_WINDOW_P, 1));
  return;
}

void
owner_read_toggle_callback()
{
  get_flag(OWNER_READ_P) ? (set_flag(OWNER_READ_P, 0)) :
    (set_flag(OWNER_READ_P, 1));

  return;
}

void
group_read_toggle_callback()
{
  get_flag(GROUP_READ_P) ? (set_flag(GROUP_READ_P, 0)) :
    (set_flag(GROUP_READ_P, 1));

  return;
}

void
world_read_toggle_callback()
{
  get_flag(WORLD_READ_P) ? (set_flag(WORLD_READ_P, 0)) :
    (set_flag(WORLD_READ_P, 1));

  return;
}


void
owner_write_toggle_callback()
{
  get_flag(OWNER_WRITE_P) ? (set_flag(OWNER_WRITE_P, 0)) :
    (set_flag(OWNER_WRITE_P, 1));

  return;
}

void
group_write_toggle_callback()
{
  get_flag(GROUP_WRITE_P) ? (set_flag(GROUP_WRITE_P, 0)) :
    (set_flag(GROUP_WRITE_P, 1));

  return;
}

void
world_write_toggle_callback()
{
  get_flag(WORLD_WRITE_P) ? (set_flag(WORLD_WRITE_P, 0)) :
    (set_flag(WORLD_WRITE_P, 1));

  return;
}



void
owner_exec_toggle_callback()
{
  get_flag(OWNER_EXEC_P) ? (set_flag(OWNER_EXEC_P, 0)) :
    (set_flag(OWNER_EXEC_P, 1));

  return;
}

void
group_exec_toggle_callback()
{
  get_flag(GROUP_EXEC_P) ? (set_flag(GROUP_EXEC_P, 0)) :
    (set_flag(GROUP_EXEC_P, 1));

  return;
}

void
world_exec_toggle_callback()
{
  get_flag(WORLD_EXEC_P) ? (set_flag(WORLD_EXEC_P, 0)) :
    (set_flag(WORLD_EXEC_P, 1));

  return;
}

void
setuid_toggle_callback()
{
  get_flag(SETUID_P) ? (set_flag(SETUID_P, 0)) :
    (set_flag(SETUID_P, 1));

  return;
}


void
setgid_toggle_callback()
{
  get_flag(SETGID_P) ? (set_flag(SETGID_P, 0)) : (set_flag(SETGID_P, 1));

  return;
}

void
sticky_toggle_callback()
{
  get_flag(STICKY_P) ? (set_flag(STICKY_P, 0)) : (set_flag(STICKY_P, 1));

  return;
}

void
directory_toggle_callback()
{
  get_flag(DIRECTORY_P) ? (set_flag(DIRECTORY_P, 0)) :
    (set_flag(DIRECTORY_P, 1));

  return;
}


void
regular_toggle_callback()
{
  get_flag(REGULAR_P) ? (set_flag(REGULAR_P, 0)) :
    (set_flag(REGULAR_P, 1));

  return;
}


void
raw_device_toggle_callback()
{
  get_flag(RAW_DEVICE_P) ? (set_flag(RAW_DEVICE_P, 0)) :
    (set_flag(RAW_DEVICE_P, 1));

  return;
}


void
block_device_toggle_callback()
{
  get_flag(BLOCK_DEVICE_P) ? (set_flag(BLOCK_DEVICE_P, 0)) :
    (set_flag(BLOCK_DEVICE_P, 1));

  return;
}


void
symlink_toggle_callback()
{
  get_flag(SYMLINK_P) ? (set_flag(SYMLINK_P, 0)) : (set_flag(SYMLINK_P, 1));

  return;
}


void
socket_toggle_callback()
{
  get_flag(SOCKET_P) ? (set_flag(SOCKET_P, 0)) : (set_flag(SOCKET_P, 1));

  return;
}


void
fifo_toggle_callback()
{
  get_flag(FIFO_P) ? (set_flag(FIFO_P, 0)) : (set_flag(FIFO_P, 1));

  return;
}

void
uid_not_login_toggle_callback()
{
  get_flag(UID_NOT_LOGIN_P) ? (set_flag(UID_NOT_LOGIN_P, 0)) :
    (set_flag(UID_NOT_LOGIN_P, 1));

  return;
}

void
gid_not_group_toggle_callback()
{
  get_flag(GID_NOT_GROUP_P) ? (set_flag(GID_NOT_GROUP_P, 0)) :
    (set_flag(GID_NOT_GROUP_P, 1));

  return;
}


void
atime_et_toggle_callback()
{
  get_flag(ATIME_ET_P) ? (set_flag(ATIME_ET_P, 0)) :
    (set_flag(ATIME_ET_P, 1));

  return;
}


void
atime_eq_toggle_callback()
{
  get_flag(ATIME_EQ_P) ? (set_flag(ATIME_EQ_P, 0)) :
    (set_flag(ATIME_EQ_P, 1));

  return;
}


void
atime_lt_toggle_callback()
{
  get_flag(ATIME_LT_P) ? (set_flag(ATIME_LT_P, 0)) :
    (set_flag(ATIME_LT_P, 1));

  return;
}


void
ctime_et_toggle_callback()
{
  get_flag(CTIME_ET_P) ? (set_flag(CTIME_ET_P, 0)) :
    (set_flag(CTIME_ET_P, 1));

  return;
}


void
ctime_eq_toggle_callback()
{
  get_flag(CTIME_EQ_P) ? (set_flag(CTIME_EQ_P, 0)) :
    (set_flag(CTIME_EQ_P, 1));

  return;
}


void
ctime_lt_toggle_callback()
{
  get_flag(CTIME_LT_P) ? (set_flag(CTIME_LT_P, 0)) : (set_flag(CTIME_LT_P, 1));

  return;
}


void
mtime_et_toggle_callback()
{
  get_flag(MTIME_ET_P) ? (set_flag(MTIME_ET_P, 0)) : (set_flag(MTIME_ET_P, 1));

  return;
}


void
mtime_eq_toggle_callback()
{
  get_flag(MTIME_EQ_P) ? (set_flag(MTIME_EQ_P, 0)) : (set_flag(MTIME_EQ_P, 1));

  return;
}


void
mtime_lt_toggle_callback()
{
  get_flag(MTIME_LT_P) ? (set_flag(MTIME_LT_P, 0)) : (set_flag(MTIME_LT_P, 1));

  return;
}

void
make_all_spinners(GtkWidget *parent, GtkWidget **day,
		    GtkWidget **month, GtkWidget **year, GtkWidget **hour,
		    GtkWidget **minute, GtkWidget **second)
{
  GtkWidget *hbox = NULL;
  GtkWidget *vbox = NULL;
  GtkWidget *label = NULL;
  GtkAdjustment *adj = NULL;

  hbox = gtk_hbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(parent), hbox);
  gtk_widget_show(hbox);

  /* the day widget */
  
  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);

  label = gtk_label_new("Day");
  gtk_container_add(GTK_CONTAINER(vbox), label);
  gtk_widget_show(label);

  adj = (GtkAdjustment *)gtk_adjustment_new(current_day, 1.0, 31.0, 1.0, 2.0,
					    0.0);
  *day = gtk_spin_button_new(adj, 0, 0);
  gtk_spin_button_set_wrap(GTK_SPIN_BUTTON(*day), TRUE);
  gtk_container_add(GTK_CONTAINER(vbox), *day);
  gtk_object_set_data(GTK_OBJECT(*day), "reset_yourself",
		      reset_time_spin_button);
  gtk_object_set_data(GTK_OBJECT(*day), "default_value", &current_day);
  gtk_widget_show(*day);
  
  /* the month widget */

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);

  label = gtk_label_new("Month");
  gtk_container_add(GTK_CONTAINER(vbox), label);
  gtk_widget_show(label);

  adj = (GtkAdjustment *)gtk_adjustment_new(current_month, 1.0, 12.0, 1.0, 2.0,
					    0.0);
  *month = gtk_spin_button_new(adj, 0, 0);
  gtk_spin_button_set_wrap(GTK_SPIN_BUTTON(*month), TRUE);
  gtk_container_add(GTK_CONTAINER(vbox), *month);
  gtk_object_set_data(GTK_OBJECT(*month), "reset_yourself",
		      reset_time_spin_button);
  gtk_object_set_data(GTK_OBJECT(*month), "default_value", &current_month);
  gtk_widget_show(*month);

  
  /* the year widget */

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);

  label = gtk_label_new("Year");
  gtk_container_add(GTK_CONTAINER(vbox), label);
  gtk_widget_show(label);

  adj = (GtkAdjustment *)gtk_adjustment_new(current_year, 1.0, 3000.0, 1.0,
					    2.0, 0.0);
  *year = gtk_spin_button_new(adj, 0, 0);
  gtk_spin_button_set_wrap(GTK_SPIN_BUTTON(*year), TRUE);
  gtk_widget_set_usize(*year, 55, 0); /* make it 4 digits wide */
  gtk_container_add(GTK_CONTAINER(vbox), *year);
  gtk_object_set_data(GTK_OBJECT(*year), "reset_yourself",
		      reset_time_spin_button);
  gtk_object_set_data(GTK_OBJECT(*year), "default_value", &current_year);
  gtk_widget_show(*year);


  /* the hour widget */

    
  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);

  label = gtk_label_new("Hour");
  gtk_container_add(GTK_CONTAINER(vbox), label);
  gtk_widget_show(label);

  adj = (GtkAdjustment *)gtk_adjustment_new(0.0, 0.0, 23.0, 1.0, 2.0,
					    0.0);
  *hour = gtk_spin_button_new(adj, 0, 0);
  gtk_spin_button_set_wrap(GTK_SPIN_BUTTON(*hour), TRUE);
  gtk_container_add(GTK_CONTAINER(vbox), *hour);
  gtk_object_set_data(GTK_OBJECT(*hour), "reset_yourself",
		      reset_time_spin_button);
  gtk_object_set_data(GTK_OBJECT(*hour), "default_value", &current_hour);
  gtk_widget_show(*hour);


  /* the minute widget */

  
  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);

  label = gtk_label_new("Minute");
  gtk_container_add(GTK_CONTAINER(vbox), label);
  gtk_widget_show(label);

  adj = (GtkAdjustment *)gtk_adjustment_new(0.0, 0.0, 59.0, 1.0, 2.0,
					    0.0);
  *minute = gtk_spin_button_new(adj, 0, 0);
  gtk_spin_button_set_wrap(GTK_SPIN_BUTTON(*minute), TRUE);
  gtk_container_add(GTK_CONTAINER(vbox), *minute);
  gtk_object_set_data(GTK_OBJECT(*minute), "reset_yourself",
		      reset_time_spin_button);
  gtk_object_set_data(GTK_OBJECT(*minute), "default_value", &current_minute);
  gtk_widget_show(*minute);

  
  /* the second widget */

  vbox = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(hbox), vbox);
  gtk_widget_show(vbox);

  label = gtk_label_new("Second");
  gtk_container_add(GTK_CONTAINER(vbox), label);
  gtk_widget_show(label);

  adj = (GtkAdjustment *)gtk_adjustment_new(0.0, 0.0, 59.0, 1.0, 2.0,
					    0.0);
  *second = gtk_spin_button_new(adj, 0, 0);
  gtk_spin_button_set_wrap(GTK_SPIN_BUTTON(*second), TRUE);
  gtk_container_add(GTK_CONTAINER(vbox), *second);
  gtk_object_set_data(GTK_OBJECT(*second), "reset_yourself",
		      reset_time_spin_button);
  gtk_object_set_data(GTK_OBJECT(*second), "default_value", &current_second);
  gtk_widget_show(*second);

  return;
  
}

void
get_current_mdy(gfloat *current_day, gfloat *current_month,
		gfloat *current_year)
{
  struct tm *tm;
  time_t now = 0;

  now = time(NULL);
  tm = localtime(&now);

  *current_month = (gfloat)tm->tm_mon + 1;
  *current_day = (gfloat)tm->tm_mday;
  *current_year = (gfloat)tm->tm_year + 1900;

  return;
}

void
clear_find_callback()
     /* the "clear" button will reset the search pattern (ie the notebook
	stuff), and not change anything else */
{

  gtk_signal_emit_by_name(GTK_OBJECT(toplevel), "foreach", reset_widget);
  reset_flags();

  return;
}

void
reset_widget(GtkWidget *widget, gpointer callback_data)
     /* run on each widget in the program */
{
  caddr_t (*reset_function)();
  
  if(GTK_IS_CONTAINER(widget))
    gtk_signal_emit_by_name(GTK_OBJECT(widget), "foreach", reset_widget);
  
  reset_function = gtk_object_get_data(GTK_OBJECT(widget), "reset_yourself");
  if(reset_function)
    (*reset_function)(widget);

  return;
}
			 
void
reset_entry(GtkWidget *widget)
{
  gtk_entry_set_text(GTK_ENTRY(widget), "");

  return;
}

void
reset_toggle_button_up(GtkWidget *widget)
{
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(widget), FALSE);

  return;
}

void
reset_toggle_button_down(GtkWidget *widget)
{
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(widget), TRUE);

  return;
}

void
reset_time_spin_button(GtkWidget *widget)
     /* here we will save the default value of each spin button as we
	make it, then use it to reset the widget */
{
  gfloat *value = NULL;

  value = gtk_object_get_data(GTK_OBJECT(widget), "default_value");
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(widget), *value);


  return;
}

void
output_format_toggle_callback()
{
  get_flag(LONG_OUTPUT_P) ? (set_flag(LONG_OUTPUT_P, 0)) :
    (set_flag(LONG_OUTPUT_P, 1));

  return;
}

void
stop_find_callback()
{
  stop_flag = 1;
  return;
}
