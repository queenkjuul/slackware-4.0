/********************************************************************** 
 Copyright (C) 1998 - Gareth Owen
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
***********************************************************************/

#include "glaunch.h"
#include <string.h>
#include <unistd.h>

extern gchar * format_string;
extern option_flags ** opts;
extern GtkWidget * message_bar;

gint
setup_program(GtkWidget * boxarg, cmd_line * cmd) 
{
  /* boxarg is the vbox into which the text label and edit-box/button will
     be packed */
  gint i,j=0;  
  gchar * copy;
  gchar * tmp;
  GtkWidget *obj, *hbox;

  /* Allocate memory
     Initialise the data block */
  i=strlen(format_string);	/* Taken as a maximum for many things */
  copy = g_malloc(sizeof(gchar) * i);
  tmp = g_malloc(sizeof(gchar) * i);
  strcpy(copy, format_string);

  cmd->program = (gchar *) g_malloc(i * sizeof(gchar));
  cmd->data_ptr = (GtkWidget **) NULL;
  cmd->button_ptr = (GtkWidget **) NULL;

  /* Read the first two options from the format_string */
  strcpy(cmd->program, strtok(copy, ":"));

  /* Skip one option, which is just use-xterm-p */
  strtok(NULL,":");
  strtok(NULL,":");

  i=1;

  hbox = gtk_hbox_new(FALSE,0);

  /* Read the remaining and construct the buttons */
  while((tmp = strtok(NULL,":")) != (gchar *) NULL){

    switch (i % 3){
      case 0:
	/* Create the label */
	obj = gtk_label_new(tmp);
	/* put it in the box with the button/entry field */
	/* gtk_box_pack_start(box, object, center-p, FALSE, 0); */
	gtk_box_pack_start(GTK_BOX(hbox), obj,FALSE,FALSE, 0);
	gtk_widget_show(obj);
	/*  And add it to the master container */
	gtk_box_pack_start(GTK_BOX(boxarg), hbox, TRUE, TRUE, 0);
	gtk_widget_show(hbox);
	hbox = gtk_hbox_new(FALSE, 0);
	break;

      case 1:
	/* Ignore the flag, thats just an internal */
	break;

      case 2:

	/* Perform common things, mainly memory allocation */
	j = (i - 2)/3;
	/* Make opts point at a suitably sized bit of memory */
	opts = g_realloc((void *)opts, (j+1) * sizeof(option_flags *));
	opts[j] = g_malloc(sizeof(option_flags));
	cmd->data_ptr =
	  g_realloc((cmd->data_ptr), (j+1) * sizeof(GtkWidget *));

	/* Split on the value of the string */

	if(strcmp(tmp,"text")==0){
	  (opts[j])->type = TEXT_FIELD;
	  create_gui_textbox(j, cmd, hbox);
	  break;
	} /* tmp = "text" */

	if(strcmp(tmp,"comptext")==0){
	  (opts[j])->type = COMPULSORY_TEXT_FIELD;
	  create_gui_textbox(j, cmd, hbox);
	  break;
	} /* tmp = "comptext" */
	
	if(strcmp(tmp,"bool")==0){
	  /* Note down the option type for future reference */
	  (opts[j])->type = BOOLEAN;
	  create_gui_boolean(j, cmd, hbox);
	  break;
	} /* tmp = "bool" */

	if(strcmp(tmp,"file")==0){
	  /* Note down the option type for future reference */
	  (opts[j])->type = FILE_FIELD;
	  create_gui_filefield(j, cmd, hbox);
	  break;
	} /* tmp = "file" */

	if(strcmp(tmp,"compfile")==0){
	  /* Note down the option type for future reference */
	  (opts[j])->type = COMPULSORY_FILE_FIELD;
	  create_gui_filefield(j, cmd, hbox);
	  break;
	} /* tmp = "compfile" */
	
	fprintf(stderr, "Unknown data type: %s\n", tmp);
	exit(-1);
	break;
    } /* breaks jump to here. */
    i++;
  }

  /* We've now finished creating all the widgets that sit in the window */
  /* Since we're not keeping count, null terminate our list */
  cmd->data_ptr = g_realloc(cmd->data_ptr, (j+2) * sizeof (GtkWidget *));
  (cmd->data_ptr)[j+1] = NULL;

  /* Add a run button here */
  obj = gtk_button_new_with_label("Run");

  gtk_box_pack_start(GTK_BOX(boxarg), obj, TRUE, TRUE, 0);
  gtk_widget_show(obj);

  /* Connect a callback to actually run the thing */
  gtk_signal_connect(GTK_OBJECT(obj), "clicked",
		     GTK_SIGNAL_FUNC(start_process), cmd);


#ifdef USE_STATUSBAR
  /* Add a stausbar here */
  message_bar = gtk_statusbar_new();

  gtk_box_pack_start(GTK_BOX(boxarg), message_bar, TRUE, TRUE, 0);
  gtk_widget_show(message_bar);
#endif

  gtk_widget_show(boxarg);
  /*  (cmd->options)[i] = NULL; */
  return 0;
}
