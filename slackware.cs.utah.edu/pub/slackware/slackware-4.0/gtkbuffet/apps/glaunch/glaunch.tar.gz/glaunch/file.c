/********************************************************************** 
 Copyright (C) 1998 - Gareth Owen
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
***********************************************************************/
#include <gtk/gtk.h>
#include "glaunch.h"

/* Delete handler for the file window: Don't kill the app, just the
   file selection widget. */
gint
kill_widget (GtkWidget *widget, GdkEvent *event, gpointer data)
{
  gtk_widget_destroy(widget);
  return(TRUE);
}

gint
file_cancel_sel (GtkWidget *widget, gpointer gdata)
{
    gtk_widget_destroy(GTK_WIDGET(gdata));
    return(TRUE);
}

  
gint
file_ok_sel (GtkWidget *widget, gpointer gdata)
     /* gdata a pointer to an array of three (GtkWidget *). gdata[0] points
	to an GtkEntry, gdata[1] points to a GtkFileSelection,]
	points to a GtkWidget (button) */
{
  GtkWidget ** info;
  
  info = (GtkWidget **) gdata;

  /* set the text in the entry box */
  gtk_entry_set_text(GTK_ENTRY(info[0]),
		     gtk_file_selection_get_filename
		     (GTK_FILE_SELECTION(info[1])));

  gtk_widget_set_sensitive (info[0], TRUE); /* Make entry box editable */
  /* destroy the file selection box */
  gtk_widget_destroy (info[1]);
  gtk_signal_handler_unblock_by_data (GTK_OBJECT(info[2]), info[0]);

  g_free(info);
  
  return(TRUE);
}


gint				/* gdata holds a pointer to a GtkEntry */
get_filename(GtkWidget *sender, gpointer gdata)
{
  GtkWidget * file_dialog;
  GtkWidget ** info;

  file_dialog = gtk_file_selection_new("Select File: ");

  info = g_malloc(sizeof(GtkWidget *) * 3);

  *info = gdata;
  *(info+1) = file_dialog;
  *(info+2) = sender;
  
  gtk_file_selection_set_filename
    (GTK_FILE_SELECTION(file_dialog),
     gtk_entry_get_text(GTK_ENTRY(info[0])));
  
  gtk_signal_connect
    (GTK_OBJECT (file_dialog), "delete_event",
     GTK_SIGNAL_FUNC (kill_widget), NULL);
  
  gtk_signal_connect
    (GTK_OBJECT (GTK_FILE_SELECTION (file_dialog)->ok_button),
     "clicked", GTK_SIGNAL_FUNC(file_ok_sel),(gpointer) info);

  gtk_signal_connect
    (GTK_OBJECT (GTK_FILE_SELECTION (file_dialog)->cancel_button),
     "clicked", GTK_SIGNAL_FUNC(file_cancel_sel),
     (gpointer) file_dialog );

  gtk_signal_handler_block_by_data (GTK_OBJECT(sender), gdata);
  
  gtk_widget_set_sensitive (GTK_WIDGET(gdata), FALSE);
  gtk_widget_set_sensitive (file_dialog, TRUE);
  gtk_widget_show(file_dialog);

  return(TRUE);
}


/*
  Local Variables:
  save-place: t
  End:
*/
