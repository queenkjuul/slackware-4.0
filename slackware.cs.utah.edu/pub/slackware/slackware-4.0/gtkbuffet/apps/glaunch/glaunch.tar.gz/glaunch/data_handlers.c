/********************************************************************** 
 Copyright (C) 1998 - Gareth Owen
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
***********************************************************************/
#include "glaunch.h"

extern gint error_flag;

/* This function copies the args over itself, omitting terms as required */
/* Returns 1 if a line is written, 0 otherwise */
gint
copy_cmd_line(gint read, gint written,
	      gint type, gchar ** source, gchar ** dest){
  switch(type){
    case TEXT_FIELD:
    case FILE_FIELD:
    case COMPULSORY_TEXT_FIELD:
    case COMPULSORY_FILE_FIELD:
      {
	/* Text Box : Copy even fields and non star odd fields */
	/* Even fields are data */
	if(read%2 == 0){
	  return handle_text_data(read, written, type, source, dest);
	}
	else{
	  return handle_flag_data(read, written, type, source, dest);
	}
      } /* TEXT_FIELD/FILE_FIELD */
      
    case BOOLEAN:{
      /* Boolean : Ignore even fields and copy non-star odd fields */
      if((read%2 == 1) && (strcmp(source[read], "*") != 0)){
	dest = g_realloc(dest, (written + 1) * sizeof(gchar *));
	dest[written] = source[read];
	return 1;
      }
      return 0;
      break;
    } /* BOOLEAN */
    
    default: {
      fprintf(stderr,
	      "Fatal error: Unknown data type %d in copy_cmd_line, process.c",
	      type);
      exit(-1);
      break;		/* Broken */
    } /* Default */
  } /* End switch() */
}


gint handle_text_data(gint read, gint written, gint type,
		     gchar ** source, gchar ** dest)
{
  /* If the data is blank and compulsory*/
  if(strcmp(source[read], "") == 0){
    switch (IS_COMPULSORY(type)){
      case TRUE: {
	error_flag = EOMITTED_COMPULSORY; /* Flag an error */
	return 0;
	break;
      }	/* TRUE */

      case FALSE:{
	return 0;
	break;
      }
    } /* switch(compulsory) */
  }
  else { /* The data not blank */
    dest = g_realloc(dest, (written + 1) * sizeof(gchar *));
    dest[written] = source[read];
    return 1;
  } 
  return -1;			/* Bad stuff */
} 

gint handle_flag_data(gint read, gint written, gint type,
		     gchar ** source, gchar ** dest)
{
  /* Is this a placeholder, not a flag? */
  if(strcmp(source[read], "*") == 0){ return 0;}

  else if(strcmp(source[read + 1],"") == 0){
    /* Is the corresponding text data empty */
    if (IS_COMPULSORY(type)){
      /* flag an error */
      error_flag = EOMITTED_COMPULSORY;
      return 0;
    }
    else return 0;
  }
      
  /* Copy the flag across */
  else {
    dest = g_realloc(dest, (written + 1) * sizeof(gchar *));
    dest[written] = source[read];
    return 1;
  }
  return 0;			/* Should never get seen */
}

