/********************************************************************** 
 Copyright (C) 1998 - Gareth Owen
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
***********************************************************************/
#include <gtk/gtk.h>
#include "glaunch.h"

void create_gui_textbox(gint j, cmd_line * cmd, GtkWidget * box)
{
  /* Heres where to specify Widget class */
  (cmd->data_ptr)[j] = gtk_entry_new();
  gtk_entry_set_editable(GTK_ENTRY((cmd->data_ptr)[j]), TRUE);
  gtk_widget_show((cmd->data_ptr)[j]);
  gtk_box_pack_start(GTK_BOX(box), (cmd->data_ptr)[j],
		     FALSE,FALSE,0);
}

void create_gui_boolean(gint j, cmd_line * cmd, GtkWidget * box)
{
  /* Heres where to specify Widget class */
  (cmd->data_ptr)[j] = gtk_check_button_new();
  gtk_widget_show((cmd->data_ptr)[j]);
  gtk_box_pack_start(GTK_BOX(box), (cmd->data_ptr)[j],
		     FALSE,FALSE,0);
}

void create_gui_filefield(gint j, cmd_line * cmd, GtkWidget * box)
{
  
  /* Heres where to specify Widget class */
  (cmd->data_ptr)[j] = gtk_entry_new();
  gtk_entry_set_editable(GTK_ENTRY((cmd->data_ptr)[j]), TRUE);
  gtk_widget_show((cmd->data_ptr)[j]);
  
  /* Add a "Browse" Button and set the signal up */ 
  cmd->button_ptr =
    g_realloc((cmd->button_ptr), (j+1) * sizeof(GtkWidget *));
  (cmd->button_ptr)[j] = gtk_button_new_with_label("Browse");
  
  gtk_signal_connect(GTK_OBJECT((cmd->button_ptr)[j]), "clicked",
		     GTK_SIGNAL_FUNC(get_filename),
		     (cmd->data_ptr)[j]);
  
  gtk_widget_show((cmd->button_ptr)[j]);

  /* Pack out new widgets */
  gtk_box_pack_start(GTK_BOX(box), (cmd->data_ptr)[j],
		     FALSE,FALSE,0);
  gtk_box_pack_start(GTK_BOX(box), (cmd->button_ptr)[j],
		     FALSE,FALSE,0);
}
