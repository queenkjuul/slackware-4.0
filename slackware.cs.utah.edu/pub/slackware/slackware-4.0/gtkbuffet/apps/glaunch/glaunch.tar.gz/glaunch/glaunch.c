/********************************************************************** 
 Copyright (C) 1998 - Gareth Owen
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
***********************************************************************/
#include "glaunch.h"
#include <string.h>
#include <stdio.h>
#include <errno.h>

/* global variables */
gchar * format_string;		/* Don't forget to malloc these. */
gint error_flag;			/* Set if compulsory field omitted */
option_flags ** opts;		/* This is a pointer to an array of
				   option_flag structures, one for each
				   option parsed from the database.  Don't
				   forget to g_realloc() these. */

#ifdef USE_STATUSBAR
GtkWidget * message_bar;
#endif

/* Prototypes */
gchar * make_file(gchar * filename);
void delete_event (GtkWidget *widget, GdkEvent *event, gpointer data);
gint parse_file(gchar * filename, gchar * cmd_string);

gint
main (gint argc, gchar ** argv, gchar * envp)
{
  GtkWidget *window;
  GtkWidget *vbox;
  cmd_line * cmd;
  gchar * localfile;
  
  gtk_init(&argc, &argv);
  
  localfile = g_malloc(NAMELENGTH * sizeof(gchar *));
  
  /* Check for a command line param */
  if(argc < 2){
    fprintf(stderr, "Specify a command\n");
    exit(-1);
  }

  /* Set aside some memory for our global variable*/
  format_string = g_malloc(NAMELENGTH * sizeof (gchar));

  /* initialise the window */
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(window), argv[1]);
  /* vbox is a vertical box into which all the dialog info will be packed */
  vbox = gtk_vbox_new(FALSE,0);

  /* Read the files */
  /* If we fall through, format_string will be defined */

  localfile = make_file(LOCAL_CONFIG_FILE);

  if(parse_file(localfile, argv[1]) == -1){
    if(parse_file(GLOBAL_CONFIG_FILE, argv[1]) == -1){
      fprintf(stderr, "Can't find that program in %s or %s\n",
	      localfile, GLOBAL_CONFIG_FILE);
      exit(-1);
    }
  }

  /* Don't need to read the file again */
  g_free(localfile);
  
  /* A data block is the size of a pointer to a gcharacter + a pointer to a
     pointer to a gcharacter */
  cmd = g_malloc(sizeof(cmd_line));
  setup_program(vbox, cmd);

  gtk_signal_connect (GTK_OBJECT (window), "delete_event",
		      GTK_SIGNAL_FUNC (delete_event), NULL);

  gtk_container_add (GTK_CONTAINER (window), vbox);

  gtk_widget_show(window);

  gtk_main();
  return 0;
}


gchar *
make_file(gchar * filename)
{
  gchar * tmp_file;
  tmp_file = g_malloc(sizeof(gchar *) * (5 + strlen(getenv ("HOME"))));
  strcpy(tmp_file, getenv("HOME"));
  strcat(tmp_file, "/");
  strcat(tmp_file, filename);
  return tmp_file;
}

/* Default delete handler */
void
delete_event (GtkWidget *widget, GdkEvent *event, gpointer data)
{
  gtk_main_quit();
}


gint
parse_file(gchar * filename, gchar * cmd_string)
     /* returns 0 on success, -1 on failure.
	filename is the file to be read,
	cmd_string is the command being executed. */
{
  FILE * fileptr;
  gchar ** lineptr = (gchar **) NULL;
  size_t linesize = 0;
  gchar * tmp_string = NULL;	/* For strtok to mangle. */

  lineptr = g_malloc(sizeof (gchar **));
  *lineptr = NULL;


  if((fileptr = fopen(filename, "r")) == NULL)
    return -1;			/* Can't open the file */

  /* Read a line.  Use GNU getline to do the work */
  while(getline(lineptr, &linesize, fileptr) != -1){
    /* Line that start with # are comments */
    if(**lineptr != '#'){
      /* Get the name field */
      tmp_string = g_realloc(tmp_string, sizeof(gchar) * strlen(*lineptr));
      strcpy(tmp_string, *lineptr);
      strtok(tmp_string, ":");
      /* Check  */
      if(string_equal(strtok(NULL,":"), cmd_string) == 0){
	strcpy(format_string, *lineptr);
	/* Trim a trailing newline */
	if(format_string[strlen(format_string)-1] == '\n')
	  format_string[strlen(format_string)-1] = '\0';
	return 0;
      }
    }
  }
  return -1;
}

gint
string_equal(const gchar *S1, const gchar *S2)
{
  /* Returns 0 if strings are equal, nothing useful otherwise.
     Copes with NULL pointers tho' */
  if(S1 == NULL || S2 == NULL)
    return -1;
  else{
    return(strcmp(S1, S2));
  }
}


/*
  Local Variables:
  save-place: t
  End:
*/
