/********************************************************************** 
 Copyright (C) 1998 - Gareth Owen
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
***********************************************************************/
#define _GNU_SOURCE
#define IS_COMPULSORY(x) ((x) == COMPULSORY_TEXT_FIELD || \
			  (x) == COMPULSORY_FILE_FIELD)

#include <gtk/gtk.h>
/* #include "glaunch.xpm" */

#define MAX_BUTTONS 16
#define OPTLENGTH   256
#define OPTNUM      100
#define NAMELENGTH  128

struct _cmd_line {char * program;
  GtkWidget ** data_ptr;	/* Holds the data that is read */
  GtkWidget ** button_ptr;	/* For extra functionality: not always used */
};

struct _option_flags
{int type; /* 0=abitrary text, 1=boolean, 2=file */};

typedef struct _cmd_line cmd_line;
typedef struct _option_flags option_flags;
typedef struct _win_inf win_inf;

int setup_program(GtkWidget *boxarg, cmd_line * cmd);
int string_equal(const char *S1, const char *S2);
gint get_filename(GtkWidget *sender, gpointer gdata);
void start_process(GtkButton *sender, gpointer data);

int copy_cmd_line(int read, int written,
	      int type, char ** source, char ** dest);
int handle_flag_data(int read, int written, int type,
		     char ** source, char ** dest);
int handle_text_data(int read, int written, int type, 
		     char ** source, char ** dest);

void create_gui_textbox(int j, cmd_line * cmd, GtkWidget * box);
void create_gui_boolean(int j, cmd_line * cmd, GtkWidget * box);
void create_gui_filefield(int j, cmd_line * cmd, GtkWidget * box);

/* These are the types for parsing the config file */
/* They are the types for button/box combos,
   i.e. valid values for opt->type */
enum {TEXT_FIELD, BOOLEAN, FILE_FIELD,
      COMPULSORY_TEXT_FIELD, COMPULSORY_FILE_FIELD};

/* Used in primitive error reporting */
enum {ENOERROR,EOMITTED_COMPULSORY};
