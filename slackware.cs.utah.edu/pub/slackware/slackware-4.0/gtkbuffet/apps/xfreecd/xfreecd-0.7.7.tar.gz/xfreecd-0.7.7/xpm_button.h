/* XPM Pushbutton structures */

struct _bstate
{
  GdkPixmap	*up_pixmap;
  GdkBitmap	*up_mask;
  GdkPixmap	*dn_pixmap;
  GdkBitmap	*dn_mask;
};


struct _pbutton
{
  GtkWidget		*wid;		/* Button's Widget ID		*/
  struct _bstate	image;		/* up and down images		*/
  int			timer;
  void (*press)   (GtkWidget *widget, GdkEventButton *event);
  void (*release) (GtkWidget *widget, GdkEventButton *event);
  void (*clicked) (GtkWidget *widget, GdkEventButton *event);
  gchar 		*up_xpm;
  gchar 		*dn_xpm;
};

GtkWidget *xpm_button( GtkWidget *parent, struct _pbutton *pb );
