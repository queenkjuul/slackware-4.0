/* ------------------------------------------------------------------------
   cddbd include file for XfreeCD

   Copyright 1998 by Brian C. Lane
   nexus@tatoosh.com
   http://www.tatoosh.com/nexus

   ------------------------------------------------------------------------ */
#define DB_DIAG        0x00
#define DB_READ        0x01
#define DB_QUIT        0x02
#define DB_MOTD        0x03
#define DB_SITES       0x04
#define DB_WRITE       0x05

#define CDDBD_DONE_OK   0x00
#define CDDBD_OPEN_ERR  0x01
#define CDDBD_OPEN_OK   0x02
#define CDDBD_READ_ERR  0x03
#define CDDBD_WRITE_ERR 0x04
#define CDDBD_TMPF_ERR  0x05
#define CDDBD_FOPEN_ERR 0x06
#define CDDBD_DONE_ERR  0x07
#define CDDBD_MATCH_OK  0x08
#define CDDBD_ENTRY_OK  0x09
#define CDDBD_MOTD_LINE 0x0A
#define CDDBD_SITE_LINE 0x0B
#define CDDBD_INEX_LINE 0x0C
#define CDDBD_MAX       0x10


int start_cddbd( int * );

int readn( register int, register char *, register int );
int writen( register int, register char *, register int );
int readline( register int, register char *, register int );

