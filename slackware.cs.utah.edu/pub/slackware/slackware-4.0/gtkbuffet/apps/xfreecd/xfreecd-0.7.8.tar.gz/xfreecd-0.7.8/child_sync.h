/* ------------------------------------------------------------------------
   child_sync include file for XfreeCD

   Copyright 1998 by Brian C. Lane
   nexus@tatoosh.com
   http://www.tatoosh.com/nexus

   ------------------------------------------------------------------------ */
int parent_sync( int fd );
int child_sync( int fd );
