/* data_selectfile.c
 * $Id: data_selectfile.c,v 0.1 1998/11/17 03:41:09 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

GtkWidget* create_fileselection_data ()
{
	GtkWidget *fileselection_data;
	GtkWidget *ok_button1;
	GtkWidget *cancel_button1;

	fileselection_data = gtk_file_selection_new ("Select File");
	gtk_object_set_data (GTK_OBJECT (fileselection_data), "fileselection_data", fileselection_data);
	gtk_container_border_width (GTK_CONTAINER (fileselection_data), 10);

	ok_button1 = GTK_FILE_SELECTION (fileselection_data)->ok_button;
	gtk_object_set_data (GTK_OBJECT (fileselection_data), "ok_button1", ok_button1);
	gtk_widget_show (ok_button1);
	GTK_WIDGET_SET_FLAGS (ok_button1, GTK_CAN_DEFAULT);

	cancel_button1 = GTK_FILE_SELECTION (fileselection_data)->cancel_button;
	gtk_object_set_data (GTK_OBJECT (fileselection_data), "cancel_button1", cancel_button1);
	gtk_widget_show (cancel_button1);
	GTK_WIDGET_SET_FLAGS (cancel_button1, GTK_CAN_DEFAULT);

	return fileselection_data;
}
