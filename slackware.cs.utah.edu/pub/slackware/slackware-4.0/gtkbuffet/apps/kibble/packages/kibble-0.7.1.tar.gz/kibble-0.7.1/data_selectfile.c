/* data_selectfile.c
 * $Id: data_selectfile.c,v 0.4 1998/11/24 03:39:32 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

/* This variable does not necessarily have to be global. */
GtkWidget *fileselection_data;

/* Points to the text entry that is updated */
GtkWidget *entry_filename;

/* Opens the filesection_data window */
void on_button_browse_clicked (GtkButton *button, gpointer user_data){
	GtkWidget *fileselection_data;

	MODAL2(
	fileselection_data = create_fileselection_data ();
	gtk_widget_show (fileselection_data);
	)
}

void on_button_data_okay_clicked (GtkObject *dialog, gpointer user_data){
        gtk_entry_set_text (GTK_ENTRY (entry_filename),
		gtk_file_selection_get_filename(GTK_FILE_SELECTION
			(fileselection_data)));
	gtk_widget_show (entry_filename);

        if(GTK_IS_WINDOW(dialog))
                gtk_object_destroy (GTK_OBJECT(dialog));
        else
                gtk_object_destroy (GTK_OBJECT(user_data));

        modal_open--;
        g_assert(modal_open >= 1);
}

GtkWidget* create_fileselection_data ()
{
	GtkWidget *ok_button;
	GtkWidget *cancel_button;

	fileselection_data = gtk_file_selection_new ("Select File");
	gtk_object_set_data (GTK_OBJECT (fileselection_data), "fileselection_data", fileselection_data);
	gtk_container_border_width (GTK_CONTAINER (fileselection_data), 10);
	gtk_signal_connect_object (GTK_OBJECT (fileselection_data), "delete_event",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (fileselection_data));

	ok_button = GTK_FILE_SELECTION (fileselection_data)->ok_button;
	gtk_object_set_data (GTK_OBJECT (fileselection_data), "ok_button", ok_button);
	gtk_widget_show (ok_button);
	GTK_WIDGET_SET_FLAGS (ok_button, GTK_CAN_DEFAULT);
	gtk_signal_connect_object (GTK_OBJECT (ok_button), "clicked",
			GTK_SIGNAL_FUNC (on_button_data_okay_clicked),
			GTK_OBJECT (fileselection_data));

	cancel_button = GTK_FILE_SELECTION (fileselection_data)->cancel_button;
	gtk_object_set_data (GTK_OBJECT (fileselection_data), "cancel_button", cancel_button);
	gtk_widget_show (cancel_button);
	GTK_WIDGET_SET_FLAGS (cancel_button, GTK_CAN_DEFAULT);
	gtk_signal_connect_object (GTK_OBJECT (cancel_button), "clicked",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (fileselection_data));

	return fileselection_data;
}
