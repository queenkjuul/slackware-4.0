/* main_menu.c
 * $Id: main.c,v 0.6 1998/11/17 20:45:16 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

/* Stores the actual KB. Woo hoo, global! */
GtkWidget *tree_kb;

/* Keeps track of whether a modal window is open. This is a weird hack. */
gint modal_open = 0;

GtkWidget* get_widget (GtkWidget *widget, gchar *widget_name)
{
	GtkWidget *found_widget;

	if (widget->parent)
		widget = gtk_widget_get_toplevel (widget);
	found_widget = (GtkWidget*) gtk_object_get_data (GTK_OBJECT (widget),
			widget_name);
	if (!found_widget)
		g_warning ("Widget not found: %s", widget_name);
	return found_widget;
}

void not_implemented (void)
{
        /* Code idea borrowed from Glade */
        /* I hope the translations don't overflow the buffer! */
        gchar buf[1024];
        sprintf (buf, ("Feature not yet implemented\n"
			"Check http://wish.student.harvard.edu/kibble/\n"
			"for a potentially newer version\n"));
        show_message_box (buf);
}

/*
 * Shows a simple message box with a label and an 'OK' button.
 * e.g. show_message_box ("Error saving file");
 * Code taken from Glade's util.c
 */
void show_message_box (gchar *message)
{
	GtkWidget *dialog, *label, *button_okay;

	MODAL(
	dialog = gtk_dialog_new ();
	gtk_window_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
	gtk_container_border_width (GTK_CONTAINER (dialog), 5);

	label = gtk_label_new (message);
	gtk_misc_set_padding (GTK_MISC (label), 20, 20);
	gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), label,
			TRUE, TRUE, 0);
	gtk_widget_show (label);

	button_okay = gtk_button_new_with_label (("Okay"));
	gtk_widget_set_usize (button_okay, 80, -1);
	gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area), button_okay,
			FALSE, FALSE, 14);
	GTK_WIDGET_SET_FLAGS (button_okay, GTK_CAN_DEFAULT);
	/* Added this focus line */
        gtk_widget_grab_focus (button_okay);
	gtk_widget_grab_default (button_okay);
	gtk_widget_show (button_okay);

	gtk_signal_connect_object (GTK_OBJECT (dialog), "delete_event",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (dialog));
	gtk_signal_connect_object (GTK_OBJECT (button_okay), "clicked",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (dialog));
	gtk_widget_show (dialog);
	);
}

void destroy_modal (GtkObject *dialog, gpointer user_data)
{
	//gtk_object_destroy (dialog);
	gtk_object_destroy (GTK_OBJECT(user_data));

	modal_open--;
	g_assert(modal_open >= 0);
}

void destroy_program (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Write unsaved data? */

	gtk_main_quit ();
}

int main (int argc, char *argv[])
{
	GtkWidget *window_main;

	gtk_set_locale ();
	gtk_init (&argc, &argv);

	window_main = create_window_main ();
	gtk_widget_show (window_main);

	gtk_main ();
	return 0;
}
