/* main_menu.c
 * $Id: main_menu.c,v 0.19 1999/02/05 01:57:57 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void on_save_activate (GtkMenuItem *menuitem, gpointer user_data)
{
        debug_msg("saving kb\n");
	write_kbfile();
	show_message_box ("Save completed\nsuccessfully.\n");
}

void on_add_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
        debug_msg("add activated\n");
	/* If no tree item is currently selected */
	if((tree_kb == NULL || GTK_TREE(tree_kb)->selection == NULL) ||
			KB_ITEM_SELECTED == NULL){
		debug_msg("no tree item selected\n");
		show_message_box("No tree item is\ncurrently selected\n");
	} else {
		debug_msg("parent tree item = 0x%x\n" _
				(gint)KB_ITEM_SELECTED);
		create_dialog_add ();
	}
}

void on_view_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
        debug_msg("view activated\n");
	/* If no tree item is currently selected */
	if((tree_kb == NULL || GTK_TREE(tree_kb)->selection == NULL) ||
			KB_ITEM_SELECTED == NULL){
		debug_msg("no tree item selected\n");
		show_message_box("No tree item is\ncurrently selected\n");
	} else {
		debug_msg("tree item = 0x%x\n" _
				(gint)KB_ITEM_SELECTED);
		create_dialog_view ();
	}
}

void on_delete_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
        debug_msg("delete activated\n");
	/* If no tree item is currently selected */
	if((tree_kb == NULL || GTK_TREE(tree_kb)->selection == NULL) ||
			KB_ITEM_SELECTED == NULL){
		debug_msg("no tree item selected\n");
		show_message_box("No tree item is\ncurrently selected\n");
	} else {
		debug_msg("tree item = 0x%x\n" _
				(gint)KB_ITEM_SELECTED);
		create_dialog_delete ();
	}
}

void on_contents_activate (GtkMenuItem *menuitem, gpointer user_data)
{
        debug_msg("contents activated\n");
        not_implemented();
}

void on_index_activate (GtkMenuItem *menuitem, gpointer user_data)
{
        debug_msg("index activated\n");
        not_implemented();
}

void on_about_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Code idea borrowed from Glade */
	/* I hope the translations don't overflow the buffer! */
	gchar buf[1024];

        debug_msg("about activated\n");
	g_snprintf (buf, MAX_STR_LEN,
			("Kibble\n\n"
			"A Knowledge Base program.\n\n"
			"Version %s\n\n"
			"By Joseph P. Turian\n\n"
			"Email: kibble@wish.student.harvard.edu\n"
			"Web: http://wish.student.harvard.edu/kibble/\n"),
			VERSION);
	show_message_box (buf);
}

#ifdef GTK_HAVE_FEATURES_1_1_0
/* How the hell do I do F1 in this? */
#define GMC	(GtkItemFactoryCallback)
#define ON	0, NULL
static GtkItemFactoryEntry menu_items[] =
{
	{"/_File",		NULL,		NULL,	0, "<Branch>"},
	{"/File/_Save",		"<control>S",	GMC on_save_activate,	ON},
	{"/File/sep1",		NULL,		NULL,	0, "<Separator>"},
	{"/File/_Quit",		"<control>Q",	GMC destroy_program,	ON},
	{"/_Edit",		NULL,		NULL,	0, "<Branch>"},
	{"/Edit/_Add",		"<control>A",	GMC on_add_activate,	ON},
	{"/Edit/_View",		"<control>V",	GMC on_view_activate,	ON},
	{"/Edit/_Delete",	"<control>D",	GMC on_delete_activate,	ON},
	{"/_Help",		NULL,		NULL,	0, "<LastBranch>"},
	{"/Help/_Contents",	NULL,		GMC on_contents_activate, ON},
	{"/Help/_Index",	NULL,		GMC on_index_activate,	ON},
	{"/Help/sep2",		NULL,		NULL,	0, "<Separator>"},
	{"/Help/_About...",	NULL,		GMC on_about_activate,	ON},
};

void create_menu_main (GtkWidget *window_main, GtkWidget *vbox)
{
	guint		nmenu_items = (guint) (sizeof (menu_items) /
			sizeof (menu_items[0]));
	GtkAccelGroup	*accel_group;
	GtkItemFactory	*factory;


	debug_msg("creating 1.1.x main menu with item_factory\n");

	accel_group = gtk_accel_group_new ();
	factory = gtk_item_factory_new (GTK_TYPE_MENU_BAR, "<Main>",
			accel_group);
	gtk_item_factory_create_items (factory, nmenu_items, menu_items,
			NULL);
	gtk_accel_group_attach (accel_group, GTK_OBJECT (window_main));

	gtk_box_pack_start (GTK_BOX (vbox),  gtk_item_factory_get_widget
			(factory, "<Main>"), FALSE, FALSE, 0);

	gtk_widget_show (gtk_item_factory_get_widget (factory, "<Main>"));
}

#else

/* GtkMenuFactory is deprecated. Figure out GtkItemFactory. */
/* How the hell do I do F1 in this? */
static GtkMenuEntry menu_items[] =
{
	{"/File/Save",    "<control>S",
		(GtkMenuCallback)on_save_activate, NULL},
	{"/File/<separator>", NULL,	NULL, NULL},
	{"/File/Quit",    "<control>Q",
		(GtkMenuCallback)destroy_program, NULL},
	{"/Edit/Add",     "<control>A",
		(GtkMenuCallback)on_add_activate, NULL},
	{"/Edit/View",    "<control>V",
		(GtkMenuCallback)on_view_activate, NULL},
	{"/Edit/Delete",  "<control>D",
		(GtkMenuCallback)on_delete_activate, NULL},
	{"/Help/Contents", NULL,
		(GtkMenuCallback)on_contents_activate, NULL},
	{"/Help/Index",   NULL,
		(GtkMenuCallback)on_index_activate, NULL},
	{"/Help/<separator>", NULL,	NULL, NULL},
	{"/Help/About...", NULL,
		(GtkMenuCallback)on_about_activate, NULL},
};

void create_menu_main (GtkWidget *window_main, GtkWidget *vbox)
{
	gint            nmenu_items = sizeof (menu_items) / sizeof
		(menu_items[0]);
	GtkMenuFactory	*factory;
	GtkMenuFactory	*subfactory;
	GtkMenuPath	*menu_path;

        debug_msg("creating 1.0.x main menu with menu_factory\n");
	factory = gtk_menu_factory_new (GTK_MENU_FACTORY_MENU_BAR);
	subfactory = gtk_menu_factory_new (GTK_MENU_FACTORY_MENU_BAR);

	gtk_menu_factory_add_subfactory (factory, subfactory, "");
	gtk_menu_factory_add_entries (factory, menu_items, nmenu_items);
	gtk_window_add_accelerator_table (GTK_WINDOW (window_main),
			subfactory->table);

	menu_path = gtk_menu_factory_find (factory, "/Help");
	gtk_menu_item_right_justify (GTK_MENU_ITEM (menu_path->widget));

	g_assert (GTK_MENU_BAR (subfactory->widget) != NULL);
	gtk_box_pack_start (GTK_BOX (vbox), subfactory->widget, FALSE,
			FALSE, 0);
	gtk_widget_show (subfactory->widget);
}
#endif
