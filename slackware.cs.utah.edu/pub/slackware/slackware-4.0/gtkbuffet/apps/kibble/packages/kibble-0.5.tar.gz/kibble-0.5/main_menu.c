/* main_menu.c
 * $Id: main_menu.c,v 0.7 1998/11/18 10:02:43 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void on_new_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Reinitialize tree_kb and redraw it */
	not_implemented();
}

void on_open_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	GtkWidget *fileselection_kb;

	MODAL(
	fileselection_kb = create_fileselection_kb ();
	gtk_widget_show (fileselection_kb);

	not_implemented();
	)
}

void on_save_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	GtkWidget *fileselection_kb;

	MODAL(
	fileselection_kb = create_fileselection_kb ();
	gtk_widget_show (fileselection_kb);

	not_implemented();
	)
}

void on_save_as_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	GtkWidget *fileselection_kb;

	MODAL(
	fileselection_kb = create_fileselection_kb ();
	gtk_widget_show (fileselection_kb);

	not_implemented();
	)
}

void on_add_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
	GtkWidget *dialog_add;

	MODAL(

	/* If no tree item is currently selected */
	if(!current_tree_item){
		show_message_box("No tree item is\ncurrently selected\n");
		modal_open--; /* s_m_b increments it */
	} else {
		dialog_add = create_dialog_add ();
		gtk_widget_show (dialog_add);

		not_implemented();
	}
	)
}

void on_view_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
	GtkWidget *dialog_view;

	MODAL(

	/* If no tree item is currently selected */
	if(!current_tree_item){
		show_message_box("No tree item is\ncurrently selected\n");
		modal_open--; /* s_m_b increments it */
	} else {
		dialog_view = create_dialog_view ();
		gtk_widget_show (dialog_view);

		not_implemented();
	}
	)
}

void on_delete_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
	GtkWidget *dialog_delete;

	MODAL(

	/* If no tree item is currently selected */
	if(!current_tree_item){
		show_message_box("No tree item is\ncurrently selected\n");
		modal_open--; /* s_m_b increments it */
	} else {
		dialog_delete = create_dialog_delete ();
		gtk_widget_show (dialog_delete);

		not_implemented();
	}
	)
}

void on_contents_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	not_implemented();
}

void on_index_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	not_implemented();
}

void on_about_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Code idea borrowed from Glade */
	/* I hope the translations don't overflow the buffer! */
	gchar buf[1024];
	/* VERSION comes from configure.in -
	 * the only place it should be defined */
	sprintf (buf, ("Kibble\n\n"
			"A Knowledge Base program.\n\n"
			"Version %s\n\n"
			"By Joseph P. Turian\n\n"
			"Email: kibble@wish.student.harvard.edu\n"
			"Web: http://wish.student.harvard.edu/kibble/\n"),
			VERSION);
	show_message_box (buf);
}

/* GtkMenuFactory is deprecated. Figure out GtkItemFactory. */
/* static GtkMenuEntry menu_items[] =
{
	{"<Main>/File/New", "<control>N", NULL, NULL},
	{"<Main>/File/Open...", "<control>O", NULL, NULL},
	{"<Main>/File/Save", NULL, NULL, NULL},
	{"<Main>/File/Save As...", "<control>S", NULL, NULL},
	{"<Main>/File/<separator>", NULL, NULL, NULL},
	{"<Main>/File/Quit", "<control>Q", (GtkMenuCallback)destroy_program, NULL},
	{"<Main>/Edit/Add", "<control>A", NULL, NULL},
	{"<Main>/Edit/View", "<control>V", NULL, NULL},
	{"<Main>/Edit/Delete", "<control>D", NULL, NULL},
	{"<Main>/Help/Contents", "F1", NULL, NULL},
	{"<Main>/Help/Index", "<shift>F1", NULL, NULL},
	{"<Main>/Help/<separator>", NULL, NULL, NULL},
	{"<Main>/Help/About...", "<control>F1", NULL, NULL},
}; */

void create_menu_main (GtkWidget *window_main, GtkWidget *vbox1)
{
	GtkWidget *menubar;
	GtkWidget *menu;
	GtkWidget *menu_item;
	GtkAccelGroup *accel_group;

	/* This code should be with the main_window code */
	accel_group = gtk_accel_group_new ();
	gtk_window_add_accel_group (GTK_WINDOW (window_main), accel_group);

	menubar = gtk_menu_bar_new ();
	gtk_object_set_data (GTK_OBJECT (window_main), "menubar", menubar);
	gtk_widget_show (menubar);
	gtk_box_pack_start (GTK_BOX (vbox1), menubar, TRUE, FALSE, 0);

	menu_item = gtk_menu_item_new_with_label ("File");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menubar), menu_item);

	menu = gtk_menu_new ();
	gtk_widget_show (menu);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (menu_item), menu);

	menu_item = gtk_menu_item_new_with_label ("New");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_new_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_n, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Open...");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_open_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_o, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Save");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_save_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_s, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Save As...");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_save_as_activate),
			NULL);

	menu_item = gtk_menu_item_new ();
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);

	menu_item = gtk_menu_item_new_with_label ("Quit");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (destroy_program),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_q, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Edit");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menubar), menu_item);

	menu = gtk_menu_new ();
	gtk_widget_show (menu);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (menu_item), menu);

	menu_item = gtk_menu_item_new_with_label ("Add");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_add_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_a, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("View");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_view_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_v, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Delete");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_delete_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_d, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Help");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menubar), menu_item);
	gtk_menu_item_right_justify (GTK_MENU_ITEM (menu_item));

	menu = gtk_menu_new ();
	gtk_widget_show (menu);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (menu_item), menu);

	menu_item = gtk_menu_item_new_with_label ("Contents");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_contents_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_F1, 0, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Index");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_index_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_F1, GDK_SHIFT_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new ();
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);

	menu_item = gtk_menu_item_new_with_label ("About...");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_about_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_F1, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
}
