/* main_window.c
 * $Id: main_window.c,v 0.10 1998/12/07 02:42:53 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

GtkWidget* create_window_main ()
{
	GtkWidget *window_main;
	GtkWidget *vbox;
	GtkWidget *scrolledwindow;

	window_main = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window_main), "Kibble");
	gtk_window_position (GTK_WINDOW (window_main), GTK_WIN_POS_CENTER);
	gtk_window_set_policy (GTK_WINDOW (window_main), TRUE, TRUE, TRUE);
	gtk_widget_set_usize (GTK_WIDGET (window_main), 200, 200);
        gtk_signal_connect (GTK_OBJECT (window_main), "destroy",
                        GTK_SIGNAL_FUNC (destroy_program), NULL);

	vbox = gtk_vbox_new (FALSE, 0);
	gtk_widget_show (vbox);
	gtk_container_add (GTK_CONTAINER (window_main), vbox);

	create_menu_main (window_main, vbox);

	scrolledwindow = gtk_scrolled_window_new (NULL, NULL);
#ifdef GTK_HAVE_FEATURES_1_1_0
	/* Grrr... this should work with GTK 1.0.x, I don't know why it
	 * keeps snapping back to the original size. */
	gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow),
			GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
#endif
	gtk_box_pack_start (GTK_BOX (vbox), scrolledwindow, TRUE, TRUE, 10);

	tree_kb = gtk_tree_new ();
	gtk_widget_show (tree_kb);
	/* Check for CVS/very new GTK+ code */
#ifdef HAVE_GTK_SCROLLED_WINDOW_ADD_WITH_VIEWPORT
	gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW
			(scrolledwindow), tree_kb);
#else
	gtk_container_add (GTK_CONTAINER (scrolledwindow), tree_kb);
#endif
	gtk_widget_show (scrolledwindow);
	gtk_container_border_width (GTK_CONTAINER (tree_kb), 10);
	GTK_WIDGET_SET_FLAGS (tree_kb, GTK_CAN_FOCUS);
	GTK_WIDGET_SET_FLAGS (tree_kb, GTK_CAN_DEFAULT);
	gtk_tree_set_selection_mode (GTK_TREE (tree_kb), GTK_SELECTION_SINGLE);

	return window_main;
}
