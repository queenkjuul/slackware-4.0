/* data_selectfile.c
 * $Id: data_selectfile.c,v 0.2 1998/11/17 20:45:16 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

/* Opens the filesection_data window */
void on_button_browse_clicked (GtkButton *button, gpointer user_data){
	GtkWidget *fileselection_data;

	fileselection_data = create_fileselection_data ();
	gtk_widget_show (fileselection_data);

	modal_open++;

	/* Won't work because modal windows are open */
        /* not_implemented(); */
}

void on_button_data_okay_clicked (GtkButton *button, gpointer user_data){
	/* Destroy the window */
	/*	gtk_signal_connect_object (GTK_OBJECT (dialog), "delete_event",
		GTK_SIGNAL_FUNC (destroy_modal),
		GTK_OBJECT (dialog)); */
}

GtkWidget* create_fileselection_data ()
{
	GtkWidget *fileselection_data;
	GtkWidget *ok_button1;
	GtkWidget *cancel_button1;

	fileselection_data = gtk_file_selection_new ("Select File");
	gtk_object_set_data (GTK_OBJECT (fileselection_data), "fileselection_data", fileselection_data);
	gtk_container_border_width (GTK_CONTAINER (fileselection_data), 10);
	gtk_signal_connect_object (GTK_OBJECT (fileselection_data), "delete_event",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (fileselection_data));

	ok_button1 = GTK_FILE_SELECTION (fileselection_data)->ok_button;
	gtk_object_set_data (GTK_OBJECT (fileselection_data), "ok_button1", ok_button1);
	gtk_widget_show (ok_button1);
	GTK_WIDGET_SET_FLAGS (ok_button1, GTK_CAN_DEFAULT);

	cancel_button1 = GTK_FILE_SELECTION (fileselection_data)->cancel_button;
	gtk_object_set_data (GTK_OBJECT (fileselection_data), "cancel_button1", cancel_button1);
	gtk_widget_show (cancel_button1);
	GTK_WIDGET_SET_FLAGS (cancel_button1, GTK_CAN_DEFAULT);
	gtk_signal_connect_object (GTK_OBJECT (cancel_button1), "clicked",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (fileselection_data));

	return fileselection_data;
}
