/* about_window.c
 * $Id: about_dialog.c,v 0.2 1998/11/17 04:00:50 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void on_button_about_okay_clicked (GtkButton *button, gpointer user_data)
{
}

GtkWidget* create_dialog_about ()
{
	GtkWidget *dialog_about;
	GtkWidget *dialog_vbox2;
	GtkWidget *vbox5;
	GtkWidget *label3;
	GtkWidget *label4;
	GtkWidget *label5;
	GtkWidget *label6;
	GtkWidget *dialog_action_area2;
	GtkWidget *button_about_okay;

	dialog_about = gtk_dialog_new ();
	gtk_object_set_data (GTK_OBJECT (dialog_about), "dialog_about", dialog_about);
	gtk_window_set_title (GTK_WINDOW (dialog_about), "About...");
	gtk_window_set_policy (GTK_WINDOW (dialog_about), TRUE, TRUE, FALSE);

	dialog_vbox2 = GTK_DIALOG (dialog_about)->vbox;
	gtk_object_set_data (GTK_OBJECT (dialog_about), "dialog_vbox2", dialog_vbox2);
	gtk_widget_show (dialog_vbox2);

	vbox5 = gtk_vbox_new (FALSE, 5);
	gtk_object_set_data (GTK_OBJECT (dialog_about), "vbox5", vbox5);
	gtk_widget_show (vbox5);
	gtk_box_pack_start (GTK_BOX (dialog_vbox2), vbox5, TRUE, TRUE, 0);
	gtk_container_border_width (GTK_CONTAINER (vbox5), 10);

	label3 = gtk_label_new ("Kibble");
	gtk_object_set_data (GTK_OBJECT (dialog_about), "label3", label3);
	gtk_widget_show (label3);
	gtk_box_pack_start (GTK_BOX (vbox5), label3, TRUE, TRUE, 10);

	label4 = gtk_label_new ("A Knowledge Base program");
	gtk_object_set_data (GTK_OBJECT (dialog_about), "label4", label4);
	gtk_widget_show (label4);
	gtk_box_pack_start (GTK_BOX (vbox5), label4, TRUE, TRUE, 10);

	label5 = gtk_label_new ("Version 0.0.1");
	gtk_object_set_data (GTK_OBJECT (dialog_about), "label5", label5);
	gtk_widget_show (label5);
	gtk_box_pack_start (GTK_BOX (vbox5), label5, TRUE, TRUE, 0);

	label6 = gtk_label_new ("by Joseph Turian");
	gtk_object_set_data (GTK_OBJECT (dialog_about), "label6", label6);
	gtk_widget_show (label6);
	gtk_box_pack_start (GTK_BOX (vbox5), label6, TRUE, TRUE, 0);

	dialog_action_area2 = GTK_DIALOG (dialog_about)->action_area;
	gtk_object_set_data (GTK_OBJECT (dialog_about), "dialog_action_area2", dialog_action_area2);
	gtk_widget_show (dialog_action_area2);
	gtk_container_border_width (GTK_CONTAINER (dialog_action_area2), 10);

	button_about_okay = gtk_button_new_with_label ("Okay");
	gtk_object_set_data (GTK_OBJECT (dialog_about), "button_about_okay", button_about_okay);
	gtk_widget_show (button_about_okay);
	gtk_box_pack_start (GTK_BOX (dialog_action_area2), button_about_okay, TRUE, FALSE, 10);
	GTK_WIDGET_SET_FLAGS (button_about_okay, GTK_CAN_DEFAULT);
	gtk_widget_grab_focus (button_about_okay);
	gtk_widget_grab_default (button_about_okay);
	gtk_signal_connect (GTK_OBJECT (button_about_okay), "clicked",
			GTK_SIGNAL_FUNC (on_button_about_okay_clicked),
			NULL);

	return dialog_about;
}
