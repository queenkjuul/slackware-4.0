/* main_menu.c
 * $Id: main_menu.c,v 0.15 1998/12/05 02:55:56 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void on_save_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	write_kbfile();
	MODAL(
	show_message_box ("Save completed\nsuccessfully.\n");
	     )
}

void on_add_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
	GtkWidget *dialog_add;


	/* If no tree item is currently selected */
	if(!current_tree_item){
		MODAL(
		show_message_box("No tree item is\ncurrently selected\n");
		     )
	} else {
		MODAL(
		dialog_add = create_dialog_add ();
		gtk_widget_show (dialog_add);
		     )
	}
}

void on_view_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
	GtkWidget *dialog_view;

	/* If no tree item is currently selected */
	if(!current_tree_item){
		MODAL(
		show_message_box("No tree item is\ncurrently selected\n");
		     )
	} else {
		MODAL(
		dialog_view = create_dialog_view ();
		gtk_widget_show (dialog_view);
		     )
	}
}

void on_delete_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
	GtkWidget *dialog_delete;


	/* If no tree item is currently selected */
	if(!current_tree_item){
		MODAL(
		show_message_box("No tree item is\ncurrently selected\n");
		     )
	} else {
		MODAL(
		dialog_delete = create_dialog_delete ();
		gtk_widget_show (dialog_delete);
		     )
	}
}

void on_contents_activate (GtkMenuItem *menuitem, gpointer user_data)
{
        modal_not_implemented();
}

void on_index_activate (GtkMenuItem *menuitem, gpointer user_data)
{
        modal_not_implemented();
}

void on_about_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Code idea borrowed from Glade */
	/* I hope the translations don't overflow the buffer! */
	gchar buf[1024];
	/* VERSION comes from configure.in -
	 * the only place it should be defined */
	sprintf (buf, ("Kibble\n\n"
			"A Knowledge Base program.\n\n"
			"Version %s\n\n"
			"By Joseph P. Turian\n\n"
			"Email: kibble@wish.student.harvard.edu\n"
			"Web: http://wish.student.harvard.edu/kibble/\n"),
			VERSION);
	MODAL(
	show_message_box (buf);
	)
}

#ifdef GTK_HAVE_FEATURES_1_1_0
void create_menu_main (GtkWidget *window_main, GtkWidget *vbox)
{
	GtkWidget *menu_bar;
	GtkWidget *menu;
	GtkWidget *menu_item;
	GtkAccelGroup *accel_group;

	/* This code should be with the main_window code */
	accel_group = gtk_accel_group_new ();
	gtk_window_add_accel_group (GTK_WINDOW (window_main), accel_group);

	menu_bar = gtk_menu_bar_new ();
	gtk_widget_show (menu_bar);
	// Unneccessary, yes?
	// gtk_object_set_data (GTK_OBJECT (window_main), "menu_bar", menu_bar);
	gtk_box_pack_start (GTK_BOX (vbox), menu_bar, FALSE, FALSE, 0);

	menu_item = gtk_menu_item_new_with_label ("File");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu_bar), menu_item);

	menu = gtk_menu_new ();
	gtk_widget_show (menu);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (menu_item), menu);

	menu_item = gtk_menu_item_new_with_label ("Save");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_save_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_s, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new ();
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);

	menu_item = gtk_menu_item_new_with_label ("Quit");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (destroy_program),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_q, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Edit");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu_bar), menu_item);

	menu = gtk_menu_new ();
	gtk_widget_show (menu);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (menu_item), menu);

	menu_item = gtk_menu_item_new_with_label ("Add");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_add_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_a, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("View");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_view_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_v, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Delete");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_delete_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_d, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Help");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu_bar), menu_item);
	gtk_menu_item_right_justify (GTK_MENU_ITEM (menu_item));

	menu = gtk_menu_new ();
	gtk_widget_show (menu);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (menu_item), menu);

	menu_item = gtk_menu_item_new_with_label ("Contents");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_contents_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_F1, 0, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new_with_label ("Index");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_index_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_F1, GDK_SHIFT_MASK, GTK_ACCEL_VISIBLE);

	menu_item = gtk_menu_item_new ();
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);

	menu_item = gtk_menu_item_new_with_label ("About...");
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_about_activate),
			NULL);
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_F1, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_widget_show (menu_item);
}
#else

/* GtkMenuFactory is deprecated. Figure out GtkItemFactory. */
/* How the hell do I do F1 in this? */
static GtkMenuEntry menu_items[] =
{
	{"<Main>/File/Save",    "<control>S",
		(GtkMenuCallback)on_save_activate, NULL},
	{"<Main>/File/<separator>", NULL,	NULL, NULL},
	{"<Main>/File/Quit",    "<control>Q",
		(GtkMenuCallback)destroy_program, NULL},
	{"<Main>/Edit/Add",     "<control>A",
		(GtkMenuCallback)on_add_activate, NULL},
	{"<Main>/Edit/View",    "<control>V",
		(GtkMenuCallback)on_view_activate, NULL},
	{"<Main>/Edit/Delete",  "<control>D",
		(GtkMenuCallback)on_delete_activate, NULL},
	{"<Main>/Help/Contents", NULL,
		(GtkMenuCallback)on_contents_activate, NULL},
	{"<Main>/Help/Index",   NULL,
		(GtkMenuCallback)on_index_activate, NULL},
	{"<Main>/Help/<separator>", NULL,	NULL, NULL},
	{"<Main>/Help/About...", NULL,
		(GtkMenuCallback)on_about_activate, NULL},
};

void create_menu_main (GtkWidget *window_main, GtkWidget *vbox)
{
	gint            nmenu_items = sizeof (menu_items) / sizeof
		(menu_items[0]);
	GtkMenuFactory	*factory;
	GtkMenuFactory	*subfactory;
	GtkMenuPath	*menu_path;

	factory = gtk_menu_factory_new (GTK_MENU_FACTORY_MENU_BAR);
	subfactory = gtk_menu_factory_new (GTK_MENU_FACTORY_MENU_BAR);

	gtk_menu_factory_add_subfactory (factory, subfactory, "<Main>");
	gtk_menu_factory_add_entries (factory, menu_items, nmenu_items);
	gtk_window_add_accelerator_table (GTK_WINDOW (window_main),
			subfactory->table);

	menu_path = gtk_menu_factory_find (factory, "<Main>/Help");
	gtk_menu_item_right_justify (GTK_MENU_ITEM (menu_path->widget));

	g_assert (GTK_MENU_BAR (subfactory->widget));
	gtk_box_pack_start (GTK_BOX (vbox), subfactory->widget, FALSE,
			FALSE, 0);
	gtk_widget_show (subfactory->widget);
}
#endif
