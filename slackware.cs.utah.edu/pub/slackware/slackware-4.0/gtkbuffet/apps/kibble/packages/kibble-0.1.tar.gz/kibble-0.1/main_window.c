/* main_window.c
 * $Id: main_window.c,v 0.1 1998/11/17 03:44:00 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

GtkWidget* create_window_main ()
{
	GtkWidget *window_main;
	GtkWidget *vbox1;
	GtkWidget *menubar;
	GtkWidget *file;
	GtkWidget *menu4;
	GtkWidget *new;
	GtkWidget *open;
	GtkWidget *save;
	GtkWidget *save_as;
	GtkWidget *separator2;
	GtkWidget *quit;
	GtkWidget *edit;
	GtkWidget *menu5;
	GtkWidget *add;
	GtkWidget *view;
	GtkWidget *delete;
	GtkWidget *help;
	GtkWidget *menu6;
	GtkWidget *contents;
	GtkWidget *index;
	GtkWidget *separator1;
	GtkWidget *about;
	GtkWidget *tree_kb;
	GtkAccelGroup *accel_group;

	window_main = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_object_set_data (GTK_OBJECT (window_main), "window_main", window_main);
	gtk_window_set_title (GTK_WINDOW (window_main), "kibble");
	gtk_window_position (GTK_WINDOW (window_main), GTK_WIN_POS_CENTER);
	gtk_window_set_policy (GTK_WINDOW (window_main), TRUE, TRUE, TRUE);

	vbox1 = gtk_vbox_new (FALSE, 0);
	gtk_object_set_data (GTK_OBJECT (window_main), "vbox1", vbox1);
	gtk_widget_show (vbox1);
	gtk_container_add (GTK_CONTAINER (window_main), vbox1);

	menubar = gtk_menu_bar_new ();
	gtk_object_set_data (GTK_OBJECT (window_main), "menubar", menubar);
	gtk_widget_show (menubar);
	gtk_box_pack_start (GTK_BOX (vbox1), menubar, TRUE, FALSE, 0);

	file = gtk_menu_item_new_with_label ("File");
	gtk_object_set_data (GTK_OBJECT (window_main), "file", file);
	gtk_widget_show (file);
	gtk_container_add (GTK_CONTAINER (menubar), file);
	gtk_signal_connect (GTK_OBJECT (file), "activate",
			GTK_SIGNAL_FUNC (on_file_activate),
			NULL);

	menu4 = gtk_menu_new ();
	gtk_object_set_data (GTK_OBJECT (window_main), "menu4", menu4);
	gtk_widget_show (menu4);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (file), menu4);

	new = gtk_menu_item_new_with_label ("New");
	gtk_object_set_data (GTK_OBJECT (window_main), "new", new);
	gtk_widget_show (new);
	gtk_container_add (GTK_CONTAINER (menu4), new);
	gtk_signal_connect (GTK_OBJECT (new), "activate",
			GTK_SIGNAL_FUNC (on_new_activate),
			NULL);
	accel_group = gtk_accel_group_new ();
	gtk_window_add_accel_group (GTK_WINDOW (window_main), accel_group);
	gtk_widget_add_accelerator (new, "activate", accel_group,
			GDK_n, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	open = gtk_menu_item_new_with_label ("Open...");
	gtk_object_set_data (GTK_OBJECT (window_main), "open", open);
	gtk_widget_show (open);
	gtk_container_add (GTK_CONTAINER (menu4), open);
	gtk_signal_connect (GTK_OBJECT (open), "activate",
			GTK_SIGNAL_FUNC (on_open_activate),
			NULL);

	save = gtk_menu_item_new_with_label ("Save");
	gtk_object_set_data (GTK_OBJECT (window_main), "save", save);
	gtk_widget_show (save);
	gtk_container_add (GTK_CONTAINER (menu4), save);
	gtk_signal_connect (GTK_OBJECT (save), "activate",
			GTK_SIGNAL_FUNC (on_save_activate),
			NULL);
	gtk_widget_add_accelerator (save, "activate", accel_group,
			GDK_s, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	save_as = gtk_menu_item_new_with_label ("Save As...");
	gtk_object_set_data (GTK_OBJECT (window_main), "save_as", save_as);
	gtk_widget_show (save_as);
	gtk_container_add (GTK_CONTAINER (menu4), save_as);
	gtk_signal_connect (GTK_OBJECT (save_as), "activate",
			GTK_SIGNAL_FUNC (on_save_as_activate),
			NULL);

	separator2 = gtk_menu_item_new ();
	gtk_object_set_data (GTK_OBJECT (window_main), "separator2", separator2);
	gtk_widget_show (separator2);
	gtk_container_add (GTK_CONTAINER (menu4), separator2);

	quit = gtk_menu_item_new_with_label ("Quit");
	gtk_object_set_data (GTK_OBJECT (window_main), "quit", quit);
	gtk_widget_show (quit);
	gtk_container_add (GTK_CONTAINER (menu4), quit);
	gtk_signal_connect (GTK_OBJECT (quit), "activate",
			GTK_SIGNAL_FUNC (destroy),
			NULL);
	gtk_widget_add_accelerator (quit, "activate", accel_group,
			GDK_q, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	edit = gtk_menu_item_new_with_label ("Edit");
	gtk_object_set_data (GTK_OBJECT (window_main), "edit", edit);
	gtk_widget_show (edit);
	gtk_container_add (GTK_CONTAINER (menubar), edit);
	gtk_signal_connect (GTK_OBJECT (edit), "activate",
			GTK_SIGNAL_FUNC (on_edit_activate),
			NULL);

	menu5 = gtk_menu_new ();
	gtk_object_set_data (GTK_OBJECT (window_main), "menu5", menu5);
	gtk_widget_show (menu5);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (edit), menu5);

	add = gtk_menu_item_new_with_label ("Add");
	gtk_object_set_data (GTK_OBJECT (window_main), "add", add);
	gtk_widget_show (add);
	gtk_container_add (GTK_CONTAINER (menu5), add);
	gtk_signal_connect (GTK_OBJECT (add), "activate",
			GTK_SIGNAL_FUNC (on_add_activate),
			NULL);
	gtk_widget_add_accelerator (add, "activate", accel_group,
			GDK_a, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	view = gtk_menu_item_new_with_label ("View");
	gtk_object_set_data (GTK_OBJECT (window_main), "view", view);
	gtk_widget_show (view);
	gtk_container_add (GTK_CONTAINER (menu5), view);
	gtk_signal_connect (GTK_OBJECT (view), "activate",
			GTK_SIGNAL_FUNC (on_view_activate),
			NULL);
	gtk_widget_add_accelerator (view, "activate", accel_group,
			GDK_v, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	delete = gtk_menu_item_new_with_label ("Delete");
	gtk_object_set_data (GTK_OBJECT (window_main), "delete", delete);
	gtk_widget_show (delete);
	gtk_container_add (GTK_CONTAINER (menu5), delete);
	gtk_signal_connect (GTK_OBJECT (delete), "activate",
			GTK_SIGNAL_FUNC (on_delete_activate),
			NULL);
	gtk_widget_add_accelerator (delete, "activate", accel_group,
			GDK_d, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	help = gtk_menu_item_new_with_label ("Help");
	gtk_object_set_data (GTK_OBJECT (window_main), "help", help);
	gtk_widget_show (help);
	gtk_container_add (GTK_CONTAINER (menubar), help);
	gtk_menu_item_right_justify (GTK_MENU_ITEM (help));

	menu6 = gtk_menu_new ();
	gtk_object_set_data (GTK_OBJECT (window_main), "menu6", menu6);
	gtk_widget_show (menu6);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (help), menu6);

	contents = gtk_menu_item_new_with_label ("Contents");
	gtk_object_set_data (GTK_OBJECT (window_main), "contents", contents);
	gtk_widget_show (contents);
	gtk_container_add (GTK_CONTAINER (menu6), contents);
	gtk_signal_connect (GTK_OBJECT (contents), "activate",
			GTK_SIGNAL_FUNC (on_contents_activate),
			NULL);
	gtk_widget_add_accelerator (contents, "activate", accel_group,
			GDK_F1, 0, GTK_ACCEL_VISIBLE);

	index = gtk_menu_item_new_with_label ("Index");
	gtk_object_set_data (GTK_OBJECT (window_main), "index", index);
	gtk_widget_show (index);
	gtk_container_add (GTK_CONTAINER (menu6), index);
	gtk_signal_connect (GTK_OBJECT (index), "activate",
			GTK_SIGNAL_FUNC (on_index_activate),
			NULL);
	gtk_widget_add_accelerator (index, "activate", accel_group,
			GDK_F1, GDK_SHIFT_MASK, GTK_ACCEL_VISIBLE);

	separator1 = gtk_menu_item_new ();
	gtk_object_set_data (GTK_OBJECT (window_main), "separator1", separator1);
	gtk_widget_show (separator1);
	gtk_container_add (GTK_CONTAINER (menu6), separator1);

	about = gtk_menu_item_new_with_label ("About...");
	gtk_object_set_data (GTK_OBJECT (window_main), "about", about);
	gtk_widget_show (about);
	gtk_container_add (GTK_CONTAINER (menu6), about);
	gtk_signal_connect (GTK_OBJECT (about), "activate",
			GTK_SIGNAL_FUNC (on_about_activate),
			NULL);
	gtk_widget_add_accelerator (about, "activate", accel_group,
			GDK_F1, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	tree_kb = gtk_tree_new ();
	gtk_object_set_data (GTK_OBJECT (window_main), "tree_kb", tree_kb);
	gtk_widget_show (tree_kb);
	gtk_box_pack_start (GTK_BOX (vbox1), tree_kb, TRUE, TRUE, 10);
	gtk_widget_set_usize (tree_kb, 200, 150);
	gtk_container_border_width (GTK_CONTAINER (tree_kb), 10);
	GTK_WIDGET_SET_FLAGS (tree_kb, GTK_CAN_FOCUS);
	GTK_WIDGET_SET_FLAGS (tree_kb, GTK_CAN_DEFAULT);
	gtk_tree_set_selection_mode (GTK_TREE (tree_kb), GTK_SELECTION_MULTIPLE);

	return window_main;
}
