/* view_dialog.c
 * $Id: view_dialog.c,v 0.5 1998/11/18 10:02:43 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void on_button_view_okay_clicked (GtkButton *button, gpointer user_data)
{
/* Destroy the window */
/*	gtk_signal_connect_object (GTK_OBJECT (dialog), "delete_event",
		GTK_SIGNAL_FUNC (destroy_modal),
		GTK_OBJECT (dialog)); */
}

GtkWidget* create_dialog_view ()
{
	GtkWidget *dialog_view;
	GtkWidget *vbox1;
	GtkWidget *vbox2;
	GtkWidget *hbox;
	GtkWidget *label;
	GtkWidget *entry_name;
	GtkWidget *text_description;
	GtkWidget *frame;
	GtkWidget *vbox3;
	GtkWidget *entry_filename;
	GtkWidget *button_view;
	GtkWidget *button_browse;
	GtkWidget *action_area;
	GtkWidget *button_okay;
	GtkWidget *button_cancel;

	node *tree_node = gtk_object_get_data (GTK_OBJECT
			(current_tree_item), "node");

	dialog_view = gtk_dialog_new ();
	gtk_window_set_title (GTK_WINDOW (dialog_view), "View");
	gtk_window_set_policy (GTK_WINDOW (dialog_view), TRUE, TRUE, FALSE);
        gtk_signal_connect_object (GTK_OBJECT (dialog_view), "delete_event",
                        GTK_SIGNAL_FUNC (destroy_modal),
                        GTK_OBJECT (dialog_view));

	vbox1 = GTK_DIALOG (dialog_view)->vbox;
	gtk_widget_show (vbox1);

	vbox2 = gtk_vbox_new (FALSE, 0);
	gtk_widget_show (vbox2);
	gtk_box_pack_start (GTK_BOX (vbox1), vbox2, TRUE, TRUE, 0);
	gtk_container_border_width (GTK_CONTAINER (vbox2), 10);

	hbox = gtk_hbox_new (FALSE, 0);
	gtk_widget_show (hbox);
	gtk_box_pack_start (GTK_BOX (vbox2), hbox, TRUE, TRUE, 0);

	label = gtk_label_new ("Name:");
	gtk_widget_show (label);
	gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 3);
	gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_LEFT);

	entry_name = gtk_entry_new ();
	gtk_entry_set_text (GTK_ENTRY (entry_name), tree_node->name->str);
	gtk_object_set_data (GTK_OBJECT (dialog_view), "name", entry_name);
	gtk_widget_show (entry_name);
	gtk_box_pack_start (GTK_BOX (hbox), entry_name, TRUE, TRUE, 5);
	GTK_WIDGET_SET_FLAGS (entry_name, GTK_CAN_DEFAULT);
	gtk_widget_grab_default (entry_name);

	label = gtk_label_new ("Description:");
	gtk_widget_show (label);
	gtk_box_pack_start (GTK_BOX (vbox2), label, TRUE, TRUE, 3);
	gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_LEFT);

	text_description = gtk_text_new (NULL, NULL);
	gtk_text_insert (GTK_TEXT (text_description), NULL, NULL, NULL,
			tree_node->description->str,
			tree_node->description->len);
	gtk_object_set_data (GTK_OBJECT (dialog_view), "description", text_description);
	gtk_widget_show (text_description);
	gtk_box_pack_start (GTK_BOX (vbox2), text_description, TRUE, TRUE, 5);
	GTK_WIDGET_SET_FLAGS (text_description, GTK_CAN_DEFAULT);
	gtk_text_set_editable (GTK_TEXT(text_description), 1);

	frame = gtk_frame_new (NULL);
	gtk_widget_show (frame);
	gtk_box_pack_start (GTK_BOX (vbox2), frame, TRUE, TRUE, 3);

	vbox3 = gtk_vbox_new (FALSE, 0);
	gtk_widget_show (vbox3);
	gtk_container_add (GTK_CONTAINER (frame), vbox3);

	hbox = gtk_hbox_new (FALSE, 5);
	gtk_widget_show (hbox);
	gtk_box_pack_start (GTK_BOX (vbox3), hbox, TRUE, TRUE, 0);
	gtk_container_border_width (GTK_CONTAINER (hbox), 5);

	label = gtk_label_new ("Filename:");
	gtk_widget_show (label);
	gtk_box_pack_start (GTK_BOX (hbox), label, TRUE, TRUE, 0);

	entry_filename = gtk_entry_new ();
	gtk_entry_set_text (GTK_ENTRY (entry_filename), tree_node->filename->str);
	gtk_object_set_data (GTK_OBJECT (dialog_view), "filename", entry_filename);
	gtk_widget_show (entry_filename);
	gtk_box_pack_start (GTK_BOX (hbox), entry_filename, TRUE, TRUE, 0);

	hbox = gtk_hbox_new (FALSE, 5);
	gtk_widget_show (hbox);
	gtk_box_pack_start (GTK_BOX (vbox3), hbox, TRUE, TRUE, 0);

	button_view = gtk_button_new_with_label ("View");
	gtk_widget_show (button_view);
	gtk_box_pack_start (GTK_BOX (hbox), button_view, TRUE, FALSE, 0);
	GTK_WIDGET_SET_FLAGS (button_view, GTK_CAN_DEFAULT);

	button_browse = gtk_button_new_with_label ("Browse");
	gtk_widget_show (button_browse);
	gtk_box_pack_start (GTK_BOX (hbox), button_browse, TRUE, FALSE, 0);
	GTK_WIDGET_SET_FLAGS (button_browse, GTK_CAN_DEFAULT);
        gtk_signal_connect (GTK_OBJECT (button_browse), "clicked",
                        GTK_SIGNAL_FUNC (on_button_browse_clicked),
                        NULL);

	action_area = GTK_DIALOG (dialog_view)->action_area;
	gtk_widget_show (action_area);
	gtk_container_border_width (GTK_CONTAINER (action_area), 10);

	hbox = gtk_hbox_new (FALSE, 0);
	gtk_widget_show (hbox);
	gtk_box_pack_start (GTK_BOX (action_area), hbox, TRUE, TRUE, 0);

	button_okay = gtk_button_new_with_label ("Okay");
	gtk_widget_show (button_okay);
	gtk_box_pack_start (GTK_BOX (hbox), button_okay, TRUE, FALSE, 5);
	GTK_WIDGET_SET_FLAGS (button_okay, GTK_CAN_DEFAULT);
	gtk_widget_grab_focus (button_okay);
	gtk_widget_grab_default (button_okay);
	gtk_signal_connect (GTK_OBJECT (button_okay), "clicked",
			GTK_SIGNAL_FUNC (on_button_view_okay_clicked),
			NULL);

	button_cancel = gtk_button_new_with_label ("Cancel");
	gtk_widget_show (button_cancel);
	gtk_box_pack_start (GTK_BOX (hbox), button_cancel, TRUE, FALSE, 5);
	gtk_container_border_width (GTK_CONTAINER (button_cancel), 1);
	GTK_WIDGET_SET_FLAGS (button_cancel, GTK_CAN_DEFAULT);
	gtk_signal_connect (GTK_OBJECT (button_cancel), "clicked",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (dialog_view));

	return dialog_view;
}
