/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

#define PACKAGE "kibble"
#define VERSION "0.7.1"

/* Define if you have the getenv function.  */
#define HAVE_GETENV 1

/* Define if you have the gtk_scrolled_window_add_with_viewport function.  */
/* #undef HAVE_GTK_SCROLLED_WINDOW_ADD_WITH_VIEWPORT */

/* Define if you have the strcat function.  */
#define HAVE_STRCAT 1

/* Define if you have the strncpy function.  */
#define HAVE_STRNCPY 1
