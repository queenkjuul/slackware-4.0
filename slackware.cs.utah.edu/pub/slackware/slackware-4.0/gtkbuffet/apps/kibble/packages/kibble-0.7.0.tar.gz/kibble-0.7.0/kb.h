/* kb.h
 * $Id: kb.h,v 0.2 1998/12/01 02:42:49 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#define MAX_TREE_DEPTH	256	/* Maximum depth of the KB tree */
#define MAX_STR_LEN	512	/* Maximum length of arbitrary strings */
#define MAX_DESC_LEN	(MAX_STR_LEN*4)	/* Maximum length of descriptions */

#define DATA(str, dlg) (gtk_object_get_data (GTK_OBJECT (dlg), str))
#define TEXT_DATA(str, dlg) (gtk_entry_get_text (GTK_ENTRY (DATA (str, dlg))))

typedef struct{
	GString *name;
	GString *description;
	GString *filename;
} node;

/* Stores the actual KB. Woo hoo, global! */
extern GtkWidget *tree_kb;
extern GtkObject *current_tree_item;	/* Currently selected item */

void read_kbfile	(void);
gint read_tree_items	(gint indent, GtkWidget *subtree, FILE *ptr);
void write_kbfile	(void);
void write_node		(FILE *ptr, GtkWidget *tree, gint indent);
void on_tree_item_click (GtkObject *tree_item, GdkEventButton *event, gpointer func_data);
node *new_node		(void);
void free_node		(node *);
