/* kb.c
 * $Id: kb.c,v 0.1 1998/11/18 09:57:18 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

/* Stores the actual KB. Woo hoo, global! */
GtkWidget *tree_kb;
GtkObject *current_tree_item=NULL;	/* Currently selected item */

void on_tree_item_click (GtkObject *tree_item, GdkEventButton *event,
		gpointer func_data)
{
	g_assert (GTK_IS_TREE_ITEM(tree_item));
	current_tree_item = tree_item;

	if (event->type==GDK_2BUTTON_PRESS && event->button==1){
		/* I might get screwed up if it starts actually using
		 * the data */
		on_view_activate(NULL, NULL);
	} else if (event->button==3){
		/* I might get screwed up if it starts actually using
		 * the data */
		on_add_activate(NULL, NULL);
	}
}

node *new_node (void)
{
	node *node_ptr;
	node_ptr = g_malloc(sizeof(node));
	/* If we have this little memory, we're fucked anyhow */
	g_assert(node_ptr);
	node_ptr -> name	= g_string_new("");
	node_ptr -> description	= g_string_new("");
	node_ptr -> filename	= g_string_new("");

	return(node_ptr);
}

void free_node (node *node_ptr)
{
	/* What does g_string_free's 2nd arg do? */
	/* g_string_free(node_ptr -> name);
	 * g_string_free(node_ptr -> description);
	 * g_string_free(node_ptr -> filename); */
	g_free(node_ptr);
}
