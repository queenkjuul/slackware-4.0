/* add_dialog.c
 * $Id: add_dialog.c,v 0.4 1998/11/18 09:58:51 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void on_button_add_okay_clicked (GtkButton *button, gpointer user_data)
{
/* Destroy the window */
/*	gtk_signal_connect_object (GTK_OBJECT (dialog), "delete_event",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (dialog)); */
}

GtkWidget* create_dialog_add ()
{
	GtkWidget *dialog_add;
	GtkWidget *dialog_vbox1;
	GtkWidget *vbox4;
	GtkWidget *hbox1;
	GtkWidget *label1;
	GtkWidget *entry_name;
	GtkWidget *label2;
	GtkWidget *text_description;
	GtkWidget *frame1;
	GtkWidget *vbox8;
	GtkWidget *hbox11;
	GtkWidget *label24;
	GtkWidget *entry_add_filename;
	GtkWidget *hbox12;
	GtkWidget *button_add_view;
	GtkWidget *button_add_browse;
	GtkWidget *dialog_action_area1;
	GtkWidget *hbox2;
	GtkWidget *button_add_okay;
	GtkWidget *button_add_cancel;

	dialog_add = gtk_dialog_new ();
	gtk_object_set_data (GTK_OBJECT (dialog_add), "dialog_add", dialog_add);
	gtk_window_set_title (GTK_WINDOW (dialog_add), "Add");
	gtk_window_set_policy (GTK_WINDOW (dialog_add), TRUE, TRUE, FALSE);
        gtk_signal_connect_object (GTK_OBJECT (dialog_add), "delete_event",
                        GTK_SIGNAL_FUNC (destroy_modal),
                        GTK_OBJECT (dialog_add));

	dialog_vbox1 = GTK_DIALOG (dialog_add)->vbox;
	gtk_object_set_data (GTK_OBJECT (dialog_add), "dialog_vbox1", dialog_vbox1);
	gtk_widget_show (dialog_vbox1);

	vbox4 = gtk_vbox_new (FALSE, 0);
	gtk_object_set_data (GTK_OBJECT (dialog_add), "vbox4", vbox4);
	gtk_widget_show (vbox4);
	gtk_box_pack_start (GTK_BOX (dialog_vbox1), vbox4, TRUE, TRUE, 5);
	gtk_container_border_width (GTK_CONTAINER (vbox4), 10);

	hbox1 = gtk_hbox_new (FALSE, 0);
	gtk_object_set_data (GTK_OBJECT (dialog_add), "hbox1", hbox1);
	gtk_widget_show (hbox1);
	gtk_box_pack_start (GTK_BOX (vbox4), hbox1, TRUE, TRUE, 3);

	label1 = gtk_label_new ("Name:");
	gtk_object_set_data (GTK_OBJECT (dialog_add), "label1", label1);
	gtk_widget_show (label1);
	gtk_box_pack_start (GTK_BOX (hbox1), label1, TRUE, TRUE, 3);
	gtk_label_set_justify (GTK_LABEL (label1), GTK_JUSTIFY_LEFT);

	entry_name = gtk_entry_new ();
	gtk_object_set_data (GTK_OBJECT (dialog_add), "entry_name", entry_name);
	gtk_widget_show (entry_name);
	gtk_box_pack_start (GTK_BOX (hbox1), entry_name, TRUE, TRUE, 5);
	GTK_WIDGET_SET_FLAGS (entry_name, GTK_CAN_DEFAULT);
	gtk_widget_grab_default (entry_name);

	label2 = gtk_label_new ("Description:");
	gtk_object_set_data (GTK_OBJECT (dialog_add), "label2", label2);
	gtk_widget_show (label2);
	gtk_box_pack_start (GTK_BOX (vbox4), label2, TRUE, TRUE, 3);
	gtk_label_set_justify (GTK_LABEL (label2), GTK_JUSTIFY_LEFT);

	text_description = gtk_text_new (NULL, NULL);
	gtk_object_set_data (GTK_OBJECT (dialog_add), "text_description", text_description);
	gtk_widget_show (text_description);
	gtk_box_pack_start (GTK_BOX (vbox4), text_description, TRUE, TRUE, 5);
	GTK_WIDGET_SET_FLAGS (text_description, GTK_CAN_DEFAULT);
	gtk_text_set_editable (GTK_TEXT(text_description), 1);

	frame1 = gtk_frame_new (NULL);
	gtk_object_set_data (GTK_OBJECT (dialog_add), "frame1", frame1);
	gtk_widget_show (frame1);
	gtk_box_pack_start (GTK_BOX (vbox4), frame1, TRUE, TRUE, 3);

	vbox8 = gtk_vbox_new (FALSE, 0);
	gtk_object_set_data (GTK_OBJECT (dialog_add), "vbox8", vbox8);
	gtk_widget_show (vbox8);
	gtk_container_add (GTK_CONTAINER (frame1), vbox8);

	hbox11 = gtk_hbox_new (FALSE, 5);
	gtk_object_set_data (GTK_OBJECT (dialog_add), "hbox11", hbox11);
	gtk_widget_show (hbox11);
	gtk_box_pack_start (GTK_BOX (vbox8), hbox11, TRUE, TRUE, 0);
	gtk_container_border_width (GTK_CONTAINER (hbox11), 5);

	label24 = gtk_label_new ("Filename:");
	gtk_object_set_data (GTK_OBJECT (dialog_add), "label24", label24);
	gtk_widget_show (label24);
	gtk_box_pack_start (GTK_BOX (hbox11), label24, TRUE, TRUE, 0);

	entry_add_filename = gtk_entry_new ();
	gtk_object_set_data (GTK_OBJECT (dialog_add), "entry_add_filename", entry_add_filename);
	gtk_widget_show (entry_add_filename);
	gtk_box_pack_start (GTK_BOX (hbox11), entry_add_filename, TRUE, TRUE, 0);

	hbox12 = gtk_hbox_new (FALSE, 5);
	gtk_object_set_data (GTK_OBJECT (dialog_add), "hbox12", hbox12);
	gtk_widget_show (hbox12);
	gtk_box_pack_start (GTK_BOX (vbox8), hbox12, TRUE, TRUE, 0);

	button_add_view = gtk_button_new_with_label ("View");
	gtk_object_set_data (GTK_OBJECT (dialog_add), "button_add_view", button_add_view);
	gtk_widget_show (button_add_view);
	gtk_box_pack_start (GTK_BOX (hbox12), button_add_view, TRUE, FALSE, 0);
	GTK_WIDGET_SET_FLAGS (button_add_view, GTK_CAN_DEFAULT);

	button_add_browse = gtk_button_new_with_label ("Browse");
	gtk_object_set_data (GTK_OBJECT (dialog_add), "button_add_browse", button_add_browse);
	gtk_widget_show (button_add_browse);
	gtk_box_pack_start (GTK_BOX (hbox12), button_add_browse, TRUE, FALSE, 0);
	GTK_WIDGET_SET_FLAGS (button_add_browse, GTK_CAN_DEFAULT);
	gtk_signal_connect (GTK_OBJECT (button_add_browse), "clicked",
			GTK_SIGNAL_FUNC (on_button_browse_clicked),
			NULL);

	dialog_action_area1 = GTK_DIALOG (dialog_add)->action_area;
	gtk_object_set_data (GTK_OBJECT (dialog_add), "dialog_action_area1", dialog_action_area1);
	gtk_widget_show (dialog_action_area1);
	gtk_container_border_width (GTK_CONTAINER (dialog_action_area1), 10);

	hbox2 = gtk_hbox_new (FALSE, 0);
	gtk_object_set_data (GTK_OBJECT (dialog_add), "hbox2", hbox2);
	gtk_widget_show (hbox2);
	gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbox2, TRUE, TRUE, 0);

	button_add_okay = gtk_button_new_with_label ("Okay");
	gtk_object_set_data (GTK_OBJECT (dialog_add), "button_add_okay", button_add_okay);
	gtk_widget_show (button_add_okay);
	gtk_box_pack_start (GTK_BOX (hbox2), button_add_okay, TRUE, FALSE, 5);
	GTK_WIDGET_SET_FLAGS (button_add_okay, GTK_CAN_DEFAULT);
	gtk_widget_grab_focus (button_add_okay);
	gtk_widget_grab_default (button_add_okay);
	gtk_signal_connect (GTK_OBJECT (button_add_okay), "clicked",
			GTK_SIGNAL_FUNC (on_button_add_okay_clicked),
			NULL);

	button_add_cancel = gtk_button_new_with_label ("Cancel");
	gtk_object_set_data (GTK_OBJECT (dialog_add), "button_add_cancel", button_add_cancel);
	gtk_widget_show (button_add_cancel);
	gtk_box_pack_start (GTK_BOX (hbox2), button_add_cancel, TRUE, FALSE, 5);
	gtk_container_border_width (GTK_CONTAINER (button_add_cancel), 1);
	GTK_WIDGET_SET_FLAGS (button_add_cancel, GTK_CAN_DEFAULT);
	gtk_signal_connect (GTK_OBJECT (button_add_cancel), "clicked",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT(dialog_add));

	return dialog_add;
}
