/* delete_window.c
 * $Id: delete_dialog.c,v 0.2 1998/11/17 20:45:16 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void on_button_delete_okay_clicked (GtkButton *button, gpointer user_data)
{
/* Destroy the window */
/*	gtk_signal_connect_object (GTK_OBJECT (dialog), "delete_event",
		GTK_SIGNAL_FUNC (destroy_modal),
		GTK_OBJECT (dialog)); */
}

GtkWidget* create_dialog_delete ()
{
	GtkWidget *dialog_delete;
	GtkWidget *dialog_vbox3;
	GtkWidget *vbox6;
	GtkWidget *label8;
	GtkWidget *label9;
	GtkWidget *label10;
	GtkWidget *dialog_action_area3;
	GtkWidget *hbox3;
	GtkWidget *button_delete_okay;
	GtkWidget *button_delete_cancel;

	dialog_delete = gtk_dialog_new ();
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "dialog_delete", dialog_delete);
	gtk_window_set_title (GTK_WINDOW (dialog_delete), "Delete");
	gtk_window_set_policy (GTK_WINDOW (dialog_delete), TRUE, TRUE, FALSE);
	gtk_signal_connect_object (GTK_OBJECT (dialog_delete), "delete_event",                        GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (dialog_delete));

	dialog_vbox3 = GTK_DIALOG (dialog_delete)->vbox;
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "dialog_vbox3", dialog_vbox3);
	gtk_widget_show (dialog_vbox3);
	gtk_container_border_width (GTK_CONTAINER (dialog_vbox3), 10);

	vbox6 = gtk_vbox_new (FALSE, 0);
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "vbox6", vbox6);
	gtk_widget_show (vbox6);
	gtk_box_pack_start (GTK_BOX (dialog_vbox3), vbox6, TRUE, TRUE, 0);

	label8 = gtk_label_new ("Are you sure that you want");
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "label8", label8);
	gtk_widget_show (label8);
	gtk_box_pack_start (GTK_BOX (vbox6), label8, TRUE, TRUE, 0);

	label9 = gtk_label_new ("to delete this node");
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "label9", label9);
	gtk_widget_show (label9);
	gtk_box_pack_start (GTK_BOX (vbox6), label9, TRUE, TRUE, 0);

	label10 = gtk_label_new ("(and all of its subtrees)?");
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "label10", label10);
	gtk_widget_show (label10);
	gtk_box_pack_start (GTK_BOX (vbox6), label10, TRUE, TRUE, 0);

	dialog_action_area3 = GTK_DIALOG (dialog_delete)->action_area;
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "dialog_action_area3", dialog_action_area3);
	gtk_widget_show (dialog_action_area3);
	gtk_container_border_width (GTK_CONTAINER (dialog_action_area3), 10);

	hbox3 = gtk_hbox_new (FALSE, 0);
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "hbox3", hbox3);
	gtk_widget_show (hbox3);
	gtk_box_pack_start (GTK_BOX (dialog_action_area3), hbox3, TRUE, TRUE, 0);

	button_delete_okay = gtk_button_new_with_label ("Okay");
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "button_delete_okay", button_delete_okay);
	gtk_widget_show (button_delete_okay);
	gtk_box_pack_start (GTK_BOX (hbox3), button_delete_okay, TRUE, FALSE, 0);
	GTK_WIDGET_SET_FLAGS (button_delete_okay, GTK_CAN_DEFAULT);
	gtk_signal_connect (GTK_OBJECT (button_delete_okay), "clicked",
			GTK_SIGNAL_FUNC (on_button_delete_okay_clicked),
			NULL);

	button_delete_cancel = gtk_button_new_with_label ("Cancel");
	gtk_object_set_data (GTK_OBJECT (dialog_delete), "button_delete_cancel", button_delete_cancel);
	gtk_widget_show (button_delete_cancel);
	gtk_box_pack_start (GTK_BOX (hbox3), button_delete_cancel, TRUE, FALSE, 0);
	GTK_WIDGET_SET_FLAGS (button_delete_cancel, GTK_CAN_DEFAULT);
	gtk_widget_grab_focus (button_delete_cancel);
	gtk_widget_grab_default (button_delete_cancel);
	gtk_signal_connect (GTK_OBJECT (button_delete_cancel), "clicked",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (dialog_delete));
	g_assert (GTK_OBJECT (dialog_delete) != GTK_OBJECT (button_delete_cancel));

	return dialog_delete;
}
