/* kb_selectfile.c
 * $Id: kb_selectfile.c,v 0.3 1998/11/17 22:22:55 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void on_button_kb_okay_clicked (GtkButton *button, gpointer user_data){
/* Destroy the window */
/*	gtk_signal_connect_object (GTK_OBJECT (dialog), "delete_event",
	GTK_SIGNAL_FUNC (destroy_modal),
	GTK_OBJECT (dialog)); */
}

GtkWidget* create_fileselection_kb ()
{
	GtkWidget *fileselection_kb;
	GtkWidget *ok_button2;
	GtkWidget *cancel_button2;

	fileselection_kb = gtk_file_selection_new ("Select File");
	gtk_object_set_data (GTK_OBJECT (fileselection_kb), "fileselection_kb", fileselection_kb);
	gtk_container_border_width (GTK_CONTAINER (fileselection_kb), 10);
	gtk_signal_connect_object (GTK_OBJECT (fileselection_kb), "delete_event",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (fileselection_kb));

	ok_button2 = GTK_FILE_SELECTION (fileselection_kb)->ok_button;
	gtk_object_set_data (GTK_OBJECT (fileselection_kb), "ok_button2", ok_button2);
	gtk_widget_show (ok_button2);
	GTK_WIDGET_SET_FLAGS (ok_button2, GTK_CAN_DEFAULT);

	cancel_button2 = GTK_FILE_SELECTION (fileselection_kb)->cancel_button;
	gtk_object_set_data (GTK_OBJECT (fileselection_kb), "cancel_button2", cancel_button2);
	gtk_widget_show (cancel_button2);
	GTK_WIDGET_SET_FLAGS (cancel_button2, GTK_CAN_DEFAULT);
	gtk_signal_connect_object (GTK_OBJECT (cancel_button2), "clicked",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (fileselection_kb));

	return fileselection_kb;
}
