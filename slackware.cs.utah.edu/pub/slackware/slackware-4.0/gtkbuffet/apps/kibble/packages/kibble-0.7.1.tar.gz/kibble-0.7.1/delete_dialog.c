/* delete_dialog.c
 * $Id: delete_dialog.c,v 0.5 1998/12/03 02:51:53 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

GtkWidget *dialog_delete;

void on_button_delete_okay_clicked (GtkButton *button, gpointer user_data)
{
	if (current_tree_item == GTK_TREE(tree_kb)->children->data)
		new_root_node();

        /* Probably should release the subordinate nodes' malloc'ed
	 * mem. This is the cheesy cop-out way to delete the node */
	/* I should get around to using free_node */
	gtk_widget_destroy (GTK_WIDGET (current_tree_item));

        destroy_modal (GTK_OBJECT(dialog_delete), NULL);
}

GtkWidget* create_dialog_delete ()
{
	GtkWidget *dialog_vbox;
	GtkWidget *vbox;
	GtkWidget *label;
	GtkWidget *dialog_action_area;
	GtkWidget *hbox;
	GtkWidget *button_okay;
	GtkWidget *button_cancel;

	dialog_delete = gtk_dialog_new ();
	gtk_window_set_title (GTK_WINDOW (dialog_delete), "Delete");
	gtk_window_set_policy (GTK_WINDOW (dialog_delete), TRUE, TRUE, FALSE);
	gtk_signal_connect_object (GTK_OBJECT (dialog_delete), "delete_event",                        GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (dialog_delete));

	dialog_vbox = GTK_DIALOG (dialog_delete)->vbox;
	gtk_widget_show (dialog_vbox);
	gtk_container_border_width (GTK_CONTAINER (dialog_vbox), 10);

	vbox = gtk_vbox_new (FALSE, 5);
	gtk_widget_show (vbox);
	gtk_box_pack_start (GTK_BOX (dialog_vbox), vbox, TRUE, TRUE, 0);

	label = gtk_label_new ("Are you sure that you want");
	gtk_widget_show (label);
	gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);

	label = gtk_label_new ("to delete this node");
	gtk_widget_show (label);
	gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);

	label = gtk_label_new ("(and all of its subtrees)?");
	gtk_widget_show (label);
	gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);

	dialog_action_area = GTK_DIALOG (dialog_delete)->action_area;
	gtk_widget_show (dialog_action_area);
	gtk_container_border_width (GTK_CONTAINER (dialog_action_area), 10);

	hbox = gtk_hbox_new (FALSE, 0);
	gtk_widget_show (hbox);
	gtk_box_pack_start (GTK_BOX (dialog_action_area), hbox, TRUE, TRUE, 0);

	button_okay = gtk_button_new_with_label ("Okay");
	gtk_widget_show (button_okay);
	gtk_box_pack_start (GTK_BOX (hbox), button_okay, TRUE, FALSE, 0);
	GTK_WIDGET_SET_FLAGS (button_okay, GTK_CAN_DEFAULT);
	gtk_signal_connect (GTK_OBJECT (button_okay), "clicked",
			GTK_SIGNAL_FUNC (on_button_delete_okay_clicked),
			NULL);

	button_cancel = gtk_button_new_with_label ("Cancel");
	gtk_widget_show (button_cancel);
	gtk_box_pack_start (GTK_BOX (hbox), button_cancel, TRUE, FALSE, 0);
	GTK_WIDGET_SET_FLAGS (button_cancel, GTK_CAN_DEFAULT);
	gtk_widget_grab_focus (button_cancel);
	gtk_widget_grab_default (button_cancel);
	gtk_signal_connect (GTK_OBJECT (button_cancel), "clicked",
			GTK_SIGNAL_FUNC (destroy_modal),
			GTK_OBJECT (dialog_delete));
	g_assert (GTK_OBJECT (dialog_delete) != GTK_OBJECT (button_cancel));

	return dialog_delete;
}
