/* kb.c
 * $Id: kb.c,v 0.2 1998/12/01 02:42:49 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

/* Stores the actual KB. Woo hoo, global! */
GtkWidget *tree_kb;
GtkObject *current_tree_item=NULL;	/* Currently selected item */

/* Perhaps more error-checking could be done or more lenient rules
 * enforced.
 *
 * Call this AFTER create_window_main, which sets up tree_kb.
 * Some of this function may be redundant, but oh well.
 * I should check this for bugs more thoroughly, but it seems to work. */
void read_kbfile(void){
	gchar		kbfile[MAX_STR_LEN];
        FILE		*ptr;
	gint		ret;
        GtkWidget 	*kb_item;
        node		*node_ptr;

	strcpy (kbfile, getenv("HOME"));
	strcat (kbfile, KBFILE);

	ptr = fopen (kbfile, "rt");
	if (!ptr){
		/* Create a root node */
		kb_item = gtk_tree_item_new_with_label (g_string (KB root));

		node_ptr = new_node ();
		g_string_assign (node_ptr -> name, g_string (KB root));
		gtk_object_set_data (GTK_OBJECT (kb_item), "node",
				(gpointer)node_ptr);
		gtk_tree_append (GTK_TREE (tree_kb), kb_item);
		gtk_widget_show (kb_item);
		gtk_signal_connect (GTK_OBJECT (kb_item),
				"button_press_event",
				GTK_SIGNAL_FUNC (on_tree_item_click),
				NULL);
	} else {
		fscanf (ptr, "%d", &ret);
		fgetc (ptr);	/* Read ONE newline */
		/* Start at depth 0, hopefully. */
		g_assert (!ret);
		ret = read_tree_items(0, tree_kb, ptr);
		g_assert(ret == -1);
	}
}

/* Given that we are at tree depth "depth", chidren of "subtree", read
   tree items from "ptr" */
gint read_tree_items (gint depth, GtkWidget *subtree, FILE *ptr){
	gint		indent, desc_len, ret;
	gchar		tmpstr[MAX_DESC_LEN];
	node		*node_ptr;
	GtkWidget	*kb_item = NULL, *new_subtree;

	/* We assume the indentation has already been read. */
	ret = depth;
	while (!feof (ptr)){
		/* If we have not already read the indentation (at a
		   higher depth) */
		if(ret == -1){
			fscanf (ptr, "%d", &indent);
			fgetc (ptr);	/* Read ONE newline */
			g_assert (indent <= depth+1);
		} else {
			indent = ret;
			ret = -1;
		}
		/* If proper indentation, read the node and put it in
		   the tree */
		if (indent == depth){
			node_ptr = new_node ();

			/* Get the name */
			fgets (tmpstr, MAX_STR_LEN, ptr);
			/* Overwrite the final newline with NULL. */
			tmpstr[strlen (tmpstr) - 1] = 0;
			g_string_assign (node_ptr -> name, tmpstr);

			/* Get the description */
			fscanf (ptr, "%d", &desc_len);
			fgetc (ptr);	/* Read ONE newline */
			g_assert (desc_len < MAX_DESC_LEN);
			/* Silly little hack follows */
			tmpstr[0] = 0;
			do{
				fgets (tmpstr + strlen(tmpstr), MAX_DESC_LEN -
						strlen(tmpstr), ptr);
			} while (strlen (tmpstr) - 1 < desc_len);
			/* Overwrite the final newline with NULL. */
			tmpstr[strlen (tmpstr) - 1] = 0;
			g_assert (strlen (tmpstr) == desc_len);
			g_string_assign (node_ptr -> description, tmpstr);

			/* Get the filename */
			fgets (tmpstr, MAX_STR_LEN, ptr);
			/* Overwrite the final newline with NULL. */
			tmpstr[strlen (tmpstr) - 1] = 0;
			g_string_assign (node_ptr -> filename, tmpstr);

			/* Read the trailing newline */
			fscanf(ptr, "\n");

			kb_item = gtk_tree_item_new_with_label (node_ptr
					-> name -> str);
			gtk_object_set_data (GTK_OBJECT (kb_item), "node",
					(gpointer)node_ptr);
			gtk_tree_append (GTK_TREE (subtree), kb_item);
			gtk_widget_show (kb_item);
			gtk_signal_connect (GTK_OBJECT (kb_item),
					"button_press_event",
					GTK_SIGNAL_FUNC (on_tree_item_click),
					NULL);
		} else if (indent == depth + 1) {
			g_assert (kb_item);
			new_subtree = gtk_tree_new ();
			gtk_tree_item_set_subtree (GTK_TREE_ITEM (kb_item),
                                new_subtree);
			gtk_widget_show (new_subtree);

			ret = read_tree_items (indent, new_subtree, ptr);
			if(ret < depth){
				return ret;
			}
		} else if (indent < depth) {
			return indent;
		} else {
			/* What the fuck?!?!? */
			g_assert (0);
		}
	}
	return -1;
}

void write_kbfile(void){
	gchar kbfile[MAX_STR_LEN];
	FILE *ptr;

	strcpy (kbfile, getenv("HOME"));
	strcat (kbfile, KBFILE);

	ptr = fopen(kbfile, "wt");
	if(!ptr){
		g_error("Could not open kb file %s for writing.", kbfile);
	}

	write_node (ptr, tree_kb, 0);
	fclose(ptr);
}

void write_node (FILE *ptr, GtkWidget *tree, gint indent){
	GList	*glistptr;
	node	*tree_node;

	if(tree){
		glistptr = GTK_TREE(tree)->children;
		while(glistptr){
			/* Depth first search the tree */
			tree_node = gtk_object_get_data (GTK_OBJECT
					(glistptr->data), "node");
			fprintf(ptr, "%d\n%s\n%d\n%s\n%s\n\n",
					indent,
					tree_node->name->str,
					tree_node->description->len,
					tree_node->description->str,
					tree_node->filename->str);

			write_node(ptr, GTK_TREE_ITEM_SUBTREE (glistptr->data),
					indent+1);
			glistptr = glistptr->next;
		}
	}
}

void on_tree_item_click (GtkObject *tree_item, GdkEventButton *event,
		gpointer func_data)
{
	g_assert (GTK_IS_TREE_ITEM(tree_item));
	current_tree_item = tree_item;

	if (event->type==GDK_2BUTTON_PRESS && event->button==1){
		/* I might get screwed up if it starts actually using
		 * the data */
		on_view_activate(NULL, NULL);
	} else if (event->button==3){
		/* I might get screwed up if it starts actually using
		 * the data */
		on_add_activate(NULL, NULL);
	}
}

node *new_node (void)
{
	node *node_ptr;
	node_ptr = g_malloc(sizeof(node));
	/* If we have this little memory, we're fucked anyhow */
	g_assert(node_ptr);
	node_ptr -> name	= g_string_new("");
	node_ptr -> description	= g_string_new("");
	node_ptr -> filename	= g_string_new("");

	return(node_ptr);
}

void free_node (node *node_ptr)
{
	/* What does g_string_free's 2nd arg do? */
	/* g_string_free(node_ptr -> name);
	 * g_string_free(node_ptr -> description);
	 * g_string_free(node_ptr -> filename); */
	g_free(node_ptr);
}
