/* main_menu.c
 * $Id: main.c,v 0.1 1998/11/17 03:46:49 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

GtkWidget* get_widget (GtkWidget *widget, gchar *widget_name)
{
	GtkWidget *found_widget;

	if (widget->parent)
		widget = gtk_widget_get_toplevel (widget);
	found_widget = (GtkWidget*) gtk_object_get_data (GTK_OBJECT (widget),
			widget_name);
	if (!found_widget)
		g_warning ("Widget not found: %s", widget_name);
	return found_widget;
}

int main (int argc, char *argv[])
{
	GtkWidget *window_main;
	GtkWidget *dialog_add;
	GtkWidget *dialog_about;
	GtkWidget *dialog_delete;
	GtkWidget *dialog_view;
	GtkWidget *fileselection_data;
	GtkWidget *fileselection_kb;

	gtk_set_locale ();
	gtk_init (&argc, &argv);

	window_main = create_window_main ();
	gtk_widget_show (window_main);
	/* dialog_add = create_dialog_add ();
	   gtk_widget_show (dialog_add);
	   dialog_about = create_dialog_about ();
	   gtk_widget_show (dialog_about);
	   dialog_delete = create_dialog_delete ();
	   gtk_widget_show (dialog_delete);
	   dialog_view = create_dialog_view ();
	   gtk_widget_show (dialog_view);
	   fileselection_data = create_fileselection_data ();
	   gtk_widget_show (fileselection_data);
	   fileselection_kb = create_fileselection_kb ();
	   gtk_widget_show (fileselection_kb); */

	gtk_main ();
	return 0;
}

void destroy (GtkMenuItem *menuitem, gpointer user_data)
{
}
