/* main_menu.c
 * $Id: main_menu.c,v 0.12 1998/12/01 02:42:49 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void on_save_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	write_kbfile();
	MODAL(
	show_message_box ("Save completed\nsuccessfully.\n");
	     )
}

void on_add_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
	GtkWidget *dialog_add;


	/* If no tree item is currently selected */
	if(!current_tree_item){
		MODAL(
		show_message_box("No tree item is\ncurrently selected\n");
		     )
	} else {
		MODAL(
		dialog_add = create_dialog_add ();
		gtk_widget_show (dialog_add);
		     )
	}
}

void on_view_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
	GtkWidget *dialog_view;

	/* If no tree item is currently selected */
	if(!current_tree_item){
		MODAL(
		show_message_box("No tree item is\ncurrently selected\n");
		     )
	} else {
		MODAL(
		dialog_view = create_dialog_view ();
		gtk_widget_show (dialog_view);
		     )
	}
}

void on_delete_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Grab tree data, display error message if none selected */
	GtkWidget *dialog_delete;


	/* If no tree item is currently selected */
	if(!current_tree_item){
		MODAL(
		show_message_box("No tree item is\ncurrently selected\n");
		     )
	} else {
		MODAL(
		dialog_delete = create_dialog_delete ();
		gtk_widget_show (dialog_delete);
		     )
	}
}

void on_contents_activate (GtkMenuItem *menuitem, gpointer user_data)
{
        modal_not_implemented();
}

void on_index_activate (GtkMenuItem *menuitem, gpointer user_data)
{
        modal_not_implemented();
}

void on_about_activate (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Code idea borrowed from Glade */
	/* I hope the translations don't overflow the buffer! */
	gchar buf[1024];
	/* VERSION comes from configure.in -
	 * the only place it should be defined */
	sprintf (buf, ("Kibble\n\n"
			"A Knowledge Base program.\n\n"
			"Version %s\n\n"
			"By Joseph P. Turian\n\n"
			"Email: kibble@wish.student.harvard.edu\n"
			"Web: http://wish.student.harvard.edu/kibble/\n"),
			VERSION);
	MODAL(
	show_message_box (buf);
	)
}

/* GtkMenuFactory is deprecated. Figure out GtkItemFactory. */
/* static GtkMenuEntry menu_items[] =
{
	{"<Main>/File/Save", "<control>S", NULL, NULL},
	{"<Main>/File/<separator>", NULL, NULL, NULL},
	{"<Main>/File/Quit", "<control>Q", (GtkMenuCallback)destroy_program, NULL},
	{"<Main>/Edit/Add", "<control>A", NULL, NULL},
	{"<Main>/Edit/View", "<control>V", NULL, NULL},
	{"<Main>/Edit/Delete", "<control>D", NULL, NULL},
	{"<Main>/Help/Contents", "F1", NULL, NULL},
	{"<Main>/Help/Index", "<shift>F1", NULL, NULL},
	{"<Main>/Help/<separator>", NULL, NULL, NULL},
	{"<Main>/Help/About...", "<control>F1", NULL, NULL},
}; */

void create_menu_main (GtkWidget *window_main, GtkWidget *vbox1)
{
	GtkWidget *menubar;
	GtkWidget *menu;
	GtkWidget *menu_item;
#ifdef GTK_HAVE_FEATURES_1_1_0
	GtkAccelGroup *accel_group;
#endif

#ifdef GTK_HAVE_FEATURES_1_1_0
	/* This code should be with the main_window code */
	accel_group = gtk_accel_group_new ();
	gtk_window_add_accel_group (GTK_WINDOW (window_main), accel_group);
#endif

	menubar = gtk_menu_bar_new ();
	gtk_object_set_data (GTK_OBJECT (window_main), "menubar", menubar);
	gtk_widget_show (menubar);
	gtk_box_pack_start (GTK_BOX (vbox1), menubar, TRUE, FALSE, 0);

	menu_item = gtk_menu_item_new_with_label ("File");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menubar), menu_item);

	menu = gtk_menu_new ();
	gtk_widget_show (menu);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (menu_item), menu);

	menu_item = gtk_menu_item_new_with_label ("Save");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_save_activate),
			NULL);
#ifdef GTK_HAVE_FEATURES_1_1_0
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_s, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
#endif

	menu_item = gtk_menu_item_new ();
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);

	menu_item = gtk_menu_item_new_with_label ("Quit");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (destroy_program),
			NULL);
#ifdef GTK_HAVE_FEATURES_1_1_0
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_q, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
#endif

	menu_item = gtk_menu_item_new_with_label ("Edit");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menubar), menu_item);

	menu = gtk_menu_new ();
	gtk_widget_show (menu);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (menu_item), menu);

	menu_item = gtk_menu_item_new_with_label ("Add");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_add_activate),
			NULL);
#ifdef GTK_HAVE_FEATURES_1_1_0
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_a, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
#endif

	menu_item = gtk_menu_item_new_with_label ("View");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_view_activate),
			NULL);
#ifdef GTK_HAVE_FEATURES_1_1_0
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_v, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
#endif

	menu_item = gtk_menu_item_new_with_label ("Delete");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_delete_activate),
			NULL);
#ifdef GTK_HAVE_FEATURES_1_1_0
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_d, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
#endif

	menu_item = gtk_menu_item_new_with_label ("Help");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menubar), menu_item);
	gtk_menu_item_right_justify (GTK_MENU_ITEM (menu_item));

	menu = gtk_menu_new ();
	gtk_widget_show (menu);
	gtk_menu_item_set_submenu (GTK_MENU_ITEM (menu_item), menu);

	menu_item = gtk_menu_item_new_with_label ("Contents");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_contents_activate),
			NULL);
#ifdef GTK_HAVE_FEATURES_1_1_0
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_F1, 0, GTK_ACCEL_VISIBLE);
#endif

	menu_item = gtk_menu_item_new_with_label ("Index");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_index_activate),
			NULL);
#ifdef GTK_HAVE_FEATURES_1_1_0
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_F1, GDK_SHIFT_MASK, GTK_ACCEL_VISIBLE);
#endif

	menu_item = gtk_menu_item_new ();
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);

	menu_item = gtk_menu_item_new_with_label ("About...");
	gtk_widget_show (menu_item);
	gtk_container_add (GTK_CONTAINER (menu), menu_item);
	gtk_signal_connect (GTK_OBJECT (menu_item), "activate",
			GTK_SIGNAL_FUNC (on_about_activate),
			NULL);
#ifdef GTK_HAVE_FEATURES_1_1_0
	gtk_widget_add_accelerator (menu_item, "activate", accel_group,
			GDK_F1, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
#endif
}
