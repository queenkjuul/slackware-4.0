/* main.h
 * $Id: main.h,v 0.6 1998/11/18 09:58:51 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/* Keeps track of whether a modal window is open. This is a weird hack. */
extern gint modal_open;

/* I have the variable set at the end so that modal windows that open
 * in pairs can use MODAL */
#define MODAL(code)	if(!modal_open){ code; modal_open++; }

GtkWidget* get_widget	(GtkWidget *widget, gchar *widget_name);
void not_implemented	(void);
void show_message_box	(gchar *message);
void destroy_modal	(GtkObject *dialog, gpointer user_data);
void destroy_program	(GtkMenuItem *menuitem, gpointer user_data);
