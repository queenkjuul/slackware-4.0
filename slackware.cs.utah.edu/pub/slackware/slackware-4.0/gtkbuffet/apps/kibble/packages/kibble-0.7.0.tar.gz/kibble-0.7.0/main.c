/* main.c
 * $Id: main.c,v 0.13 1998/12/01 02:42:49 joseph Exp $
 */

/* kibble
 * Copyright (C) 1998, Joseph P. Turian
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "all.h"

void destroy_program (GtkMenuItem *menuitem, gpointer user_data)
{
	/* Write unsaved data */
	write_kbfile();

	/* Walk through the tree and g_free() the alloc'ed data */

	gtk_main_quit ();
}

int main (int argc, char *argv[])
{
	GtkWidget *window_main;

	gtk_set_locale ();
	gtk_init (&argc, &argv);

	window_main = create_window_main ();
	gtk_widget_show (window_main);
	read_kbfile ();

	gtk_main ();
	return 0;
}
