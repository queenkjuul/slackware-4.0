/* gtkmotd -- Display the message of the day in an X window
 * Copyright 1998 Nils Philippsen <nils@fht-esslingen.de>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <gtk/gtk.h>

#include "gtkmotd.h"

GtkStyle *style = NULL;
GdkFont *font = NULL;

void quit_program (GtkWidget *widget, gpointer data)
{
  if (style)
    gtk_style_unref (style);
  if (font)
    gdk_font_unref (font);
  gtk_main_quit ();
}

gint del_event (GtkWidget *widget, GdkEvent *event, gpointer data)
{
  return TRUE;
}

void display_main_window (void)
{
  GtkWidget *dialog;
  GtkWidget *label;
  GtkWidget *hbox;
  GtkWidget *text;
  GtkWidget *scrollbar;
  GtkWidget *button;

  gchar motd [1024];
  FILE *fd;

  dialog = gtk_dialog_new ();
  gtk_window_set_title (GTK_WINDOW (dialog), "Message of the Day");
  gtk_window_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
  gtk_container_border_width (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), 5);
  gtk_widget_set_usize (GTK_WIDGET (dialog),
                        (gint) (0.6 * gdk_screen_width ()),
                        (gint) (0.8 * gdk_screen_height ()));
  gtk_signal_connect (GTK_OBJECT (dialog), "delete_event",
                      GTK_SIGNAL_FUNC (del_event), NULL);

  label = gtk_label_new ("Message of the Day");
  gtk_misc_set_alignment (GTK_MISC (label), 0.0, 0.5);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), label,
                      FALSE, TRUE, 5);
  gtk_widget_show (label);

  hbox = gtk_hbox_new (FALSE, 5);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox),
                      hbox, TRUE, TRUE, 0);

  text = gtk_text_new (NULL, NULL);

  style = gtk_style_copy (gtk_widget_get_style (GTK_WIDGET (text)));
  gtk_style_ref (style);
  font = gdk_font_load ("-adobe-courier-medium-r-normal--*-120-*-*-*-*-*-*");
  gdk_font_ref (font);
  style->font = font;
  gtk_widget_set_style (GTK_WIDGET (text), style);

  gtk_text_set_editable (GTK_TEXT (text), FALSE);
  gtk_text_set_word_wrap (GTK_TEXT (text), TRUE);
  gtk_box_pack_start(GTK_BOX (hbox), text, TRUE, TRUE, 0);

  gtk_text_freeze (GTK_TEXT (text));

  if (fd = fopen (MOTD, "r")) {
    while (fgets (motd, 1024, fd)) {
      gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL,
                       motd, strlen (motd));
    }
    fclose (fd);
  } else {
    g_snprintf (motd, 1024, "The message of the day file could not be read.\n"
                            "Please contact your system administrator.\n");
    gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL,
                     motd, strlen (motd));
  }

  gtk_text_thaw (GTK_TEXT (text));

  gtk_widget_show (text);

  scrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
  gtk_box_pack_start(GTK_BOX (hbox), scrollbar, FALSE, FALSE, 0);
  gtk_widget_show (scrollbar);

  gtk_widget_show (hbox);

  button = gtk_button_new_with_label (" Close ");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area),
                      button, FALSE, FALSE, 0);
  GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
  gtk_widget_grab_default (button);
  gtk_signal_connect (GTK_OBJECT (button), "clicked",
                      GTK_SIGNAL_FUNC (quit_program), NULL);
  gtk_widget_show (button);

  gtk_widget_show (dialog);
}

int main (int argc, char *argv[])
{
  gtk_init (&argc, &argv);

#ifdef DEBUG
  signal (SIGSEGV, SIG_DFL);
#endif

  display_main_window ();

  gtk_main ();

  return EXIT_SUCCESS;
}
