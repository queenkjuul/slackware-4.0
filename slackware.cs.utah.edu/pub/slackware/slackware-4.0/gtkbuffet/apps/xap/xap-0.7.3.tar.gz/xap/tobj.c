/* test
 */
#include <stdio.h>
#include <glib.h>
#include "uri.h"

void main (int argc, char *argv[])
{
	GList *list;
	uri *u;

	printf ("clear: %s\n", uri_clear_path(argv[1]));

	uri_parse_list (argv[1], &list);
	while (list) {
		u = list->data;
		printf ("|%s|\n", u->url);
		list = list->next;
	}
	uri_parse_list (argv[1], &list);
	printf ("|%s|\n", uri_to_quoted_list(list));
}

