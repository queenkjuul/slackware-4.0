/*
 * xap_gui.c
 *
 * Copyright (C) 1999 Rasca, Berlin
 * EMail: thron@gmx.de
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include "xap_gui.h"
#include "gtk_exec.h"
#include "gtk_dnd.h"
#include "uri.h"
#include "io.h"
#include "gtk_dlg.h"

static GtkTargetEntry target_table[] = {
	{ "text/uri-list",	0,	TARGET_URI_LIST },
	{ "STRING",			0,	TARGET_STRING },
	{ "text/plain",		0,	TARGET_PLAIN },
};
#define NUM_TARGETS (sizeof(target_table)/sizeof(GtkTargetEntry))

typedef struct {
	char *path;
	char *label;
	GtkTooltips *tips;
	GtkWidget *w_label;
	GtkWidget *w_box;
	GtkWidget *w_box_menu;
	GtkWidget *w_btn_menu;
} page;

#define ACCEL 1
typedef struct {
	gchar *label;
	void *func;
	void *data;
	int flags;
	int key;
	int mod;
} menu_entry;

typedef struct {
	GtkWidget *notebook;
	GtkWidget *btn_menu;
	char *path;
	int last;
} cfg;

typedef struct {
	char *path;
	char *label;
} obj;

/*
 * gtk initializing
 */
void
gui_init (int *argc, char ***argv, char *rc)
{
	gtk_rc_add_default_file ("xap.rc");
	gtk_init (argc, argv);
	gtk_rc_parse (rc);
}

/*
 * callback if button was pressed (signal: "clicked")
 */
void
button_clicked (GtkWidget *button, obj *prog)
{
	char *args[3];
	int len;
	GdkEvent *event;

	if (!prog || !prog->path)
		return;
	event = gtk_get_current_event ();

	if (((GdkEventButton *)event)->state & GDK_MOD1_MASK) {
		args[0] = TERMINAL;
		args[1] = "-e";
		args[2] = prog->path;
		len = 3;
	} else {
		args[0] = prog->path;
		len = 1;
	}
	if (io_system_var (args, len) == -1)
		dlg_error ("Can't execute", prog->path);
	gdk_event_free (event);
}

/*
 * called on drag_motion event
 */
gboolean
button_drag_motion (GtkWidget *btn, GdkDragContext *context, gint x, gint y,
					guint time, void *data)
{
	GdkEventCrossing ev;

	ev.type = GDK_ENTER_NOTIFY;
	ev.window = btn->window;
	ev.send_event = TRUE;
	ev.subwindow = 0;
	ev.time = gdk_time_get ();
	ev.mode = GDK_CROSSING_GRAB;

	gdk_event_put ((GdkEvent *)&ev);
	return (TRUE);
}

/*
 * called on drag_leave event
 */
void
button_drag_leave (GtkWidget *btn, GdkDragContext *cnt, guint time, void *data)
{
	GdkEventCrossing ev;

	ev.type = GDK_LEAVE_NOTIFY;
	ev.window = btn->window;
	ev.send_event = TRUE;
	ev.subwindow = 0;
	ev.time = gdk_time_get ();
	ev.mode = GDK_CROSSING_GRAB;
	gdk_event_put ((GdkEvent *)&ev);
}


/*
 * called if a drop is on the program button
 */
void
button_drop_data (GtkWidget *button, GdkDragContext *context, gint x, gint y,
		GtkSelectionData *data, guint info, guint time, obj *prog)
{
	char *arg, **argv;
	int num, i, term = 0;
	GList *arg_list = NULL;

	if ((data->length <= 0) || (data->format != 8)) {
		gtk_drag_finish (context, FALSE, TRUE, time);
		return;
	}

#ifdef	DEBUG
	fprintf (stderr, "%s: button_drop_data() info=%d, len=%d\n", __FILE__,
			info, data->length);
#endif
	arg = g_malloc (data->length + 1);
	if (!arg) {
		gtk_drag_finish (context, FALSE, TRUE, time);
		return;
	}
		/* may be the sender didn't add a terminating null byte
		 */
	arg[data->length] = '\0';
	memcpy (arg, data->data, data->length);

	num = uri_parse_list (arg, &arg_list);
	g_free (arg);
	if (!num) {
		gtk_drag_finish (context, FALSE, TRUE, time);
		return;
	}
	/* assume the most apps don't want a "file:/"-prefix
	 */
	uri_remove_file_prefix_from_list (arg_list);

	if (context->action == GDK_ACTION_ASK) {
		/* startup in terminal window */
		term = 2;
	}
	argv = (char **) malloc (sizeof(char *) * (term + 1 + num));
	if (!argv) {
		gtk_drag_finish (context, FALSE, TRUE, time);
		uri_free_list (arg_list);
		return;
	}
	gtk_drag_finish (context, TRUE, TRUE, time);
	if (term) {
		argv[0] = TERMINAL;
		argv[1] = "-e";
	}
	argv[term] = prog->path;
	for (i = 0; i < num; i++) {
		argv[term+1+i] = (((uri_t *)(g_list_nth(arg_list, i)->data))->url);
	}

	if (io_system_var (argv, num+1+term) == -1)
		dlg_error ("Can't execute", prog->path);
	g_free (argv);
	uri_free_list (arg_list);
}

/*
 * prepare data for the drop target
 */
static void
button_drag_data_get (GtkWidget *btn, GdkDragContext *context,
		GtkSelectionData *data, guint info, guint time, gpointer mydata)
{
	obj *prog;
	int len;
	static char orig[PATH_MAX+3];

	prog = gtk_object_get_user_data(GTK_OBJECT(btn));
	if (!prog)
		return;
#ifdef DEBUG
	printf ("button_drag_data_det(): ->%s\n", prog->path);
#endif
	switch (info) {
		case TARGET_URI_LIST:
		case TARGET_STRING:
		case TARGET_PLAIN:
			/* text, uri-list, .. */
			len = readlink (prog->path, orig, PATH_MAX);
			if (len <= 0) {
				perror (prog->path);
				return;
			}
			orig[len] = '\0';
			if (info == TARGET_URI_LIST)
				orig[len+0] = 0x0D;
				orig[len+1] = 0x0A;
				orig[len+2] = 0x00;

			gtk_selection_data_set (data, data->target, 8, orig, 32);
			break;
		default:
			fprintf (stderr, "Unknown target: %d\n", info);
			break;
	}
}

/*
 * what is that for?
 */
void
menu_detach ()
{
}

/*
 * popup button menu
 */
static gint
pop_btn_menu (GtkWidget *button, GdkEventButton *event, GtkWidget *menu)
{
	if (event->button != 3)
		return (FALSE);
	gtk_object_set_user_data (GTK_OBJECT(menu), button);
	gtk_menu_popup (GTK_MENU(menu), NULL, NULL, NULL, NULL, 3, event->time);
	return (TRUE);
}

/*
 */
static GtkWidget *
new_icon (char *file, GdkWindow *window, GdkColor *bg)
{
	GtkWidget *wpix = NULL;
	GdkPixmap *pixmap, *mask;

#ifdef DEBUG
	printf ("new_icon() file=%s\n", file);
#endif
	pixmap = gdk_pixmap_create_from_xpm (window, &mask, bg, file);
	if (pixmap) {
		wpix = gtk_pixmap_new (pixmap, mask);
	}
	return (wpix);
}

/*
 * add program button
 */
void
add_program_button (char *label, char *path, GtkWidget *box, GtkWidget *menu,
		GtkTooltips *tips)
{
	obj *prog;
	GtkWidget *button, *icon;
	char file[PATH_MAX+1];

	prog = g_malloc (sizeof (obj));
	if (!prog)
		return;

	prog->label = strdup(label);
	prog->path = strdup(path);

	sprintf (file, "%s/%s/.icons/mini-%s.xpm",
				getenv("HOME"),
				XAP_PATH,
				prog->label);
	icon = new_icon (file, box->window, &box->style->bg[GTK_STATE_NORMAL]);

	if (!icon) {
		/* try global icon directory */
		sprintf (file, "%s/mini-%s.xpm", ICONDIR, prog->label);
		icon = new_icon (file, box->window, &box->style->bg[GTK_STATE_NORMAL]);
	}

	if (!icon) {
		button = gtk_button_new_with_label (prog->label);
	} else {
		button = gtk_button_new ();
		gtk_container_add (GTK_CONTAINER(button), icon);
		gtk_tooltips_set_tip (tips, button, prog->label, "ToolTips/");
		/* we have to send the buttons some events to get tooltips to work
		 */
		gtk_signal_connect (GTK_OBJECT(button), "drag_motion",
				GTK_SIGNAL_FUNC(button_drag_motion), NULL);
		gtk_signal_connect (GTK_OBJECT(button), "drag_leave",
				GTK_SIGNAL_FUNC(button_drag_leave), NULL);
	}
	gtk_signal_connect (GTK_OBJECT(button), "drag_data_get",
			GTK_SIGNAL_FUNC(button_drag_data_get), icon);

	gtk_object_set_user_data (GTK_OBJECT(button), prog);
	gtk_box_pack_start (GTK_BOX(box), button, FALSE, TRUE, 1);
	gtk_drag_dest_set (button, GTK_DEST_DEFAULT_ALL,
		target_table, NUM_TARGETS, GDK_ACTION_COPY|GDK_ACTION_ASK);
	gtk_drag_source_set (button, GDK_BUTTON1_MASK,
		target_table, NUM_TARGETS, GDK_ACTION_COPY|GDK_ACTION_MOVE);
	gtk_signal_connect (GTK_OBJECT(button), "clicked",
		GTK_SIGNAL_FUNC(button_clicked), (void *) prog);
	gtk_signal_connect (GTK_OBJECT(button), "drag_data_received",
		GTK_SIGNAL_FUNC (button_drop_data), (void *) prog);
	gtk_signal_connect (GTK_OBJECT(button), "button_press_event",
		GTK_SIGNAL_FUNC (pop_btn_menu), (void *) menu);
	gtk_widget_show_all (button);
}

/*
 * called if a drop is at the program-page label
 * this will create a new entry/button by linking the program
 */
void
page_drop_data (GtkWidget *label, GdkDragContext *context, gint x, gint y,
		GtkSelectionData *data, guint info, guint time, page *pg)
{
	char *arg, *f, *tf;
	char lnk[PATH_MAX+1];
	int len, num;
	GList *list;
	uri_t *uri;

	if ((data->length > 0) && (data->format == 8)) {
		len = data->length;
		arg = g_malloc (len + 1);
		arg[len] = '\0';
		memcpy (arg, data->data, len);

		num = uri_parse_list (arg, &list);
		g_free (arg);
		if (!num) {
			gtk_drag_finish (context, FALSE, TRUE, time);
			return;
		} else {
			gtk_drag_finish (context, TRUE, TRUE, time);
		}
		uri_remove_file_prefix_from_list (list);
		while (num) {
			num--;
			uri = (uri_t *) (g_list_nth (list, num))->data;
			if (uri) {
				f = uri->url;
				if (!io_is_exec (f)) {
					fprintf (stderr, "%s: not an executable!\n", f);
				} else {
					/* create link and add to page */
					tf = strrchr (f, '/');
					if (!tf)
						tf = f;
					else
						tf++;
					sprintf (lnk, "%s/%s", pg->path, tf);
					/* printf ("%s -> %s\n", f, lnk); */
					symlink (f, lnk);
					add_program_button (tf, lnk, pg->w_box,
						pg->w_btn_menu, pg->tips);
				}
			}
		}
		uri_free_list (list);
		return;
	}
	gtk_drag_finish (context, FALSE, TRUE, time);
}



/*
 * put page to the front if drag comes over
 */
gboolean
page_drag_motion (GtkWidget *label,
		GdkDragContext *context, gint x, gint y, guint time, int i)
{
	GtkNotebook *notebook = GTK_NOTEBOOK(label->parent);
	if (i != gtk_notebook_get_current_page (notebook)) {
		gtk_notebook_set_page (notebook, i);
	}
	return (1);
}

/*
 * process application subdirectory
 */
void
process_dir (GtkWidget *page, char *path, GtkWidget *menu, GtkTooltips *tips)
{
	DIR *dir;
	struct dirent *de;
	int len;
	char *name;

	dir = opendir (path);
	if (!dir) {
		perror (path);
		return;
	}
	while ((de = readdir(dir)) != NULL) {
		if (*de->d_name == '.') {
			/* ignore hidden files
			 */
			continue;
		}
		len = strlen (path) + strlen (de->d_name) + 2;
		name = g_malloc (len);
		sprintf (name, "%s/%s", path, de->d_name);
		add_program_button (de->d_name, name, page, menu, tips);
	}
	closedir (dir);
}

/*
 * add a page to the notebook and append the menu
 */
page *
add_page (GtkNotebook *notebook, char *label, char *base, void *btn_mn, int num)
{
	page *pg;

#ifdef DEBUG
	printf ("add_page() label=%s base=%s\n", label, base);
#endif
	pg = g_malloc (sizeof(page));
	if (!pg)
		return NULL;
	pg->label = g_strdup (label);
	pg->path = g_malloc (strlen(base) + strlen(label) + 2);
	sprintf (pg->path, "%s/%s", base, label);

	pg->w_btn_menu = btn_mn;
	pg->w_box = gtk_hbox_new (FALSE, 0);
	pg->w_label = gtk_label_new (pg->label);
	pg->tips = gtk_tooltips_new ();

	gtk_drag_dest_set (pg->w_label, GTK_DEST_DEFAULT_ALL,
			target_table, NUM_TARGETS, GDK_ACTION_COPY);
	gtk_signal_connect (GTK_OBJECT(pg->w_label), "drag_motion",
			GTK_SIGNAL_FUNC(page_drag_motion), (void *) num);
	gtk_signal_connect (GTK_OBJECT(pg->w_label), "drag_data_received",
			GTK_SIGNAL_FUNC(page_drop_data), (void *) pg);

	gtk_notebook_append_page (notebook, pg->w_box, pg->w_label);
	gtk_object_set_user_data (GTK_OBJECT(pg->w_label), pg);
	gtk_widget_show_all (GTK_WIDGET(notebook));
	return (pg);
}

/*
 */
void
build_pages (GtkNotebook *notebook, char *path, GtkWidget *menu, cfg *app)
{
	DIR *dir;
	struct dirent *de;
	char complete[PATH_MAX+1];
	page *pg;
	struct stat st;

	app->last = -1;
	dir = opendir (path);
	if (!dir) {
		perror (path);
		exit (1);
	}
	while ((de = readdir (dir)) != NULL) {
		if (io_is_hidden (de->d_name)) {
			/* skip ".", "..", ".trash", and so on
			 */
			continue;
		}
		sprintf (complete, "%s/%s", path, de->d_name);
		stat (complete, &st);
		if (!S_ISDIR(st.st_mode))
			continue;
		app->last++;
		pg = add_page (notebook, de->d_name, path, menu, app->last);
		if (pg)
			process_dir (pg->w_box, complete, menu, pg->tips);
	}
	closedir (dir);
}

/*
 * callback for menu entry "delete"
 */
static void
cb_delete (GtkWidget *item, gpointer *data)
{
	obj *prog;
	GtkWidget *button = gtk_object_get_user_data(GTK_OBJECT(item->parent));
	prog = gtk_object_get_user_data (GTK_OBJECT(button));
	if (prog) {
#ifdef DEBUG
		printf ("deleting: %s\n", prog->path);
#endif
		unlink (prog->path);
		gtk_widget_destroy(button);
	}
}


/*
 */
static void
cb_icon (GtkWidget *item, gpointer *data)
{
	GtkWidget *button, *icon;
	obj *prog;
	char src_icon_name[DLG_MAX+1];
	char new_icon_name[DLG_MAX+1];
	char *path, *p, buff[1024];
	struct stat s;
	FILE *ofp, *nfp;
	int len;
	GList *child;

	button = gtk_object_get_user_data (GTK_OBJECT(item->parent));
	prog = gtk_object_get_user_data (GTK_OBJECT(button));
	sprintf (src_icon_name, "%s/lib/icons/mini-%s.xpm", INSTDIR, prog->label);
	if (dlg_string ("Copy icon data from: ", src_icon_name) != DLG_RC_OK) {
		return;
	}
	if (stat (src_icon_name, &s) == -1) {
		dlg_error (src_icon_name, strerror(errno));
		return;
	}
	path = g_strdup(prog->path);
	p = strrchr (path, '/');
	*p = '\0';
	sprintf (new_icon_name, "%s/../.icons/mini-%s.xpm", path, prog->label);

	if (dlg_question ("New icon will be saved as", new_icon_name) != DLG_RC_OK){
		g_free (path);
		return ;
	}
	g_free (path);
	/* first try to create a pixmap */
	icon = new_icon (src_icon_name, button->window,
						&button->style->bg[GTK_STATE_NORMAL]);
	if (!icon) {
		dlg_error ("Can't create icon from", src_icon_name);
		return;
	}
	child = gtk_container_children (GTK_CONTAINER(button));
	while (child) {
		gtk_container_remove (GTK_CONTAINER(button), GTK_WIDGET(child->data));
		child = child->next;
	}

	gtk_container_add (GTK_CONTAINER(button), icon);
	gtk_widget_show (icon);

	/* check if it is still there */
	if (stat (new_icon_name, &s) != -1) {
		if (dlg_question ("Override icon?", new_icon_name)
				!= DLG_RC_OK){
			return ;
		}
	}
	ofp = fopen (src_icon_name, "rb");
	if (!ofp) {
		dlg_error (src_icon_name, strerror(errno));
		return;
	}
	nfp = fopen (new_icon_name, "wb");
	if (!nfp) {
		fclose (nfp);
		dlg_error (src_icon_name, strerror(errno));
		return;
	}
	while ((len = fread(buff, 1, 1024, ofp)) > 0) {
		fwrite (buff, 1, len, nfp);
	}
	fclose (nfp);
	fclose (ofp);
}

/*
 * callback for menu entry "rename"
 */
static void
cb_rename (GtkWidget *item, gpointer *data)
{
	obj *prog;
	GtkWidget *button, *child;
	char label[DLG_MAX];
	char *p, *name;
	int len;

	button = gtk_object_get_user_data(GTK_OBJECT(item->parent));
	prog = gtk_object_get_user_data (GTK_OBJECT(button));

	if (prog) {
		strcpy (label, prog->label);
		if (dlg_string ("New label: ", label) == DLG_RC_OK) {
			if (*label) {
				g_free (prog->label);
				prog->label = g_strdup(label);
				p = strrchr (prog->path, '/');
				if (!p) {
					printf ("fatal error!\n");
					exit (1);
				}
				len = p - prog->path + 1 + strlen (label) + 1;
				name = g_malloc (len);
				strncpy (name, prog->path, p - prog->path + 1);
				strcpy (name+(p-prog->path+1), label);
#ifdef DEBUG
				printf ("new: %s\n", name);
#endif
				rename (prog->path, name);
				g_free (prog->path);
				prog->path = name;
				child = GTK_BIN(button)->child;
				if (child && GTK_IS_LABEL(child)) {
					gtk_label_set_text (GTK_LABEL(child), prog->label);
				}
				p = strchr (label, ' ');
				if (p)
					dlg_warning ("Link should not have spaces!");
			}
		}
	}
}


/*
 */
void
cb_page_new (GtkWidget *item, gpointer *data)
{
	cfg *app = (cfg *)data;
	char name[DLG_MAX];
	char path[PATH_MAX+1];

#ifdef DEBUG
	printf ("cb_page_new() path=%s\n", app->path);
#endif
	strcpy (name, "tools");
	if (dlg_string ("New page:", name) == DLG_RC_OK) {
		sprintf (path, "%s/%s", app->path, name);
		if (mkdir (path, 0xFFFFFFFF) != -1) {
			app->last++;
			add_page (GTK_NOTEBOOK(app->notebook), name, app->path,
						app->btn_menu, app->last);
		}
	}

}

/*
 * execute a named program
 */
void
cb_exec (GtkWidget *w, gpointer data)
{
	dlg_execute ((char *)data, NULL);
}

/*
 * rename a page
 */
void
cb_page_rename (GtkWidget *item, gpointer data)
{
	cfg *app = (cfg *)data;
	char name[DLG_MAX], *p;
	char path[PATH_MAX+1];
	GtkWidget *nth, *label;
	int current;
	page *pg, *npg;

	current = gtk_notebook_get_current_page(GTK_NOTEBOOK(app->notebook));
	nth = gtk_notebook_get_nth_page (GTK_NOTEBOOK(app->notebook), current);
	label = gtk_notebook_get_tab_label (GTK_NOTEBOOK(app->notebook), nth);
	pg = gtk_object_get_user_data (GTK_OBJECT(label));
	strcpy (name, pg->label);
	
	if (dlg_string ("Rename notebook-page to:", name) != DLG_RC_OK) {
		return;
	}
	if (strcmp (name, pg->label) == 0)
		return;

	strcpy (path, pg->path);
	p = strrchr (path, '/');
	if (p)
		*(p+1) = '\0';
	strcat (path, name);

	if (rename (pg->path, path) == -1) {
		dlg_error (path, strerror(errno));
		return;
	}
	npg = add_page (GTK_NOTEBOOK(app->notebook),
				name, app->path, pg->w_btn_menu, current);
	if (npg)
		process_dir (npg->w_box, path, pg->w_btn_menu, pg->tips);
	gtk_notebook_remove_page (GTK_NOTEBOOK(app->notebook), current);
}

/*
 */
void
on_page_del (GtkWidget *item, gpointer *data)
{
}

/*
 * path: default value = "$HOME/.xap"
 * transient: boolean, should program run as transient window?
 */
void
gui_main (char *path, int transient, wgeo_t *geo)
{
	GtkWidget *top, *button_menu, *page_menu, *menu_item;
	GtkWidget *notebook;
	GtkAccelGroup *accel;

	menu_entry button_me[] = {
		{ NULL,		NULL,	NULL },
		{ "Rename ..",		cb_rename,		NULL },
		{ "Icon ..", 		cb_icon,		NULL },
		{ "Delete button",	cb_delete,		NULL },
		{ NULL,		NULL,	NULL },
		{ "Execute ..",		cb_exec, 		path },
		{ NULL,		NULL, 	NULL },
		{ "Quit",			gtk_main_quit,	NULL },
	};
#define LAST_BUTTON_MENU (sizeof(button_me)/sizeof(menu_entry))
	menu_entry page_me[] = {
		{ NULL,		NULL,	NULL },
		{ "New page ..",	cb_page_new,	NULL, ACCEL, GDK_n, GDK_MOD1_MASK },
		{ "Rename page ..",	cb_page_rename,	NULL},
		{ NULL,		NULL, 	NULL },
		{ "Execute ..",		cb_exec, 		path },
		{ NULL,		NULL, 	NULL },
		{ "Quit",			gtk_main_quit,	NULL, ACCEL, GDK_q, GDK_MOD1_MASK },
	};
#define LAST_PAGE_MENU (sizeof(page_me)/sizeof(menu_entry))
	int i;
	cfg app;


	top = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_signal_connect (GTK_OBJECT(top), "destroy",
		GTK_SIGNAL_FUNC (exit), NULL);

	accel = gtk_accel_group_new();
	gtk_accel_group_attach (accel, GTK_OBJECT(top));

	notebook = gtk_notebook_new ();
	gtk_notebook_set_homogeneous_tabs ((GtkNotebook *)notebook, 1);
	gtk_notebook_set_tab_hborder ((GtkNotebook *)notebook, 0);
	gtk_notebook_set_tab_vborder ((GtkNotebook *)notebook, 0);
	gtk_container_set_border_width (GTK_CONTAINER(notebook), 0);
	gtk_container_add (GTK_CONTAINER(top), notebook);

	app.path = g_strdup (path);
	app.notebook = notebook;

	button_menu = gtk_menu_new ();
	app.btn_menu = button_menu;
	for (i = 0; i < LAST_BUTTON_MENU; i++) {
		if (button_me[i].label)
			menu_item = gtk_menu_item_new_with_label (button_me[i].label);
		else
			menu_item = gtk_menu_item_new ();
		if (button_me[i].func) {
			if (button_me[i].data) {
				gtk_signal_connect (GTK_OBJECT(menu_item), "activate",
					GTK_SIGNAL_FUNC(button_me[i].func), button_me[i].data);
			} else {
				gtk_signal_connect (GTK_OBJECT(menu_item), "activate",
					GTK_SIGNAL_FUNC(button_me[i].func), (void *)path);
			}
		}
		gtk_menu_append (GTK_MENU(button_menu), menu_item);
		gtk_widget_show (menu_item);
	}
	gtk_menu_attach_to_widget (GTK_MENU(button_menu), GTK_WIDGET(notebook),
			menu_detach);

	page_menu = gtk_menu_new ();
	gtk_menu_set_accel_group (GTK_MENU(page_menu), accel);
	for (i = 0; i < LAST_PAGE_MENU; i++) {
		if (page_me[i].label)
			menu_item = gtk_menu_item_new_with_label (page_me[i].label);
		else
			menu_item = gtk_menu_item_new ();
		if (page_me[i].func) {
			if (page_me[i].data) {
				gtk_signal_connect (GTK_OBJECT(menu_item), "activate",
					GTK_SIGNAL_FUNC(page_me[i].func), page_me[i].data);
			} else {
				gtk_signal_connect (GTK_OBJECT(menu_item), "activate",
					GTK_SIGNAL_FUNC(page_me[i].func), (void *)&app);
			}
		}
		if (page_me[i].flags & ACCEL) {
			gtk_widget_add_accelerator(menu_item, "activate", accel,
				page_me[i].key, page_me[i].mod, GTK_ACCEL_VISIBLE);
		}
		gtk_menu_append (GTK_MENU(page_menu), menu_item);
		gtk_widget_show (menu_item);
	}
	gtk_menu_attach_to_widget (GTK_MENU(page_menu), GTK_WIDGET(notebook),
			menu_detach);

	gtk_notebook_popup_enable (GTK_NOTEBOOK(notebook));
	GTK_NOTEBOOK(notebook)->menu = page_menu;

	gtk_widget_show_all (top);
	build_pages (GTK_NOTEBOOK(notebook), path, button_menu, &app);

	if (transient)
		gtk_window_set_transient_for (GTK_WINDOW(top), GTK_WINDOW(top));

	if (geo) {
		if (geo->width > 0 && geo->height > 0) {
			gtk_widget_set_usize (top, geo->width,geo->height);
		}
		if (geo->x > -1 && geo->height > -1) {
			gtk_widget_set_uposition (GTK_WIDGET(top),geo->x,geo->y);
		}
	}
	gtk_main ();
}

