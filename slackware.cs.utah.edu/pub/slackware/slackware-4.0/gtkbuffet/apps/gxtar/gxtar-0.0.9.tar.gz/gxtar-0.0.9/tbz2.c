/* gxTar - Gnomified Archive Frontend
 * Copyright (C) 1998 Chris Rogers
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option) 
 * any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
 * GNU General Public License for more details.
 *  
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 * 02111-1307, USA.
 */

#include "tar.h"
#include "tbz2.h"


int tbz2_read(gchar * fle) {

  gchar *tmpOut;
  gchar *cmd;
  int result;

  tmpOut = tempnam("","gxtar");
  cmd = g_malloc(sizeof(gchar)*(17+strlen(fle)+strlen(tmpOut)));
  sprintf(cmd, "bunzip2 -c \"%s\" > %s",fle, tmpOut);
  result = system(cmd); 
  result = tar_read(tmpOut);
  unlink(tmpOut);
  g_free(cmd);
  return result;
}


int  tbz2_extract(gchar * dir){

  GList *selection;
  gint index;
  gchar *text;
  gchar *tmpOut;
  gchar *cmd;
  gint result;
  FILE * src;
  

  selection = GTK_CLIST(arch->listFiles)->selection;
  tmpOut = NULL;
  
  if (selection == NULL) {
    cmd = g_malloc(sizeof(gchar)*(34+strlen(dir)+strlen(arch->OpenFile)));
    sprintf(cmd, "cd \"%s\"; bun2zip -c \"%s\" | tar -xf - ", dir, arch->OpenFile);
  }else{
    tmpOut = tempnam("","gxtar");
    src = fopen(tmpOut,"w");
    
    while(selection) {
      index = (gint) selection->data;
      gtk_clist_get_text(GTK_CLIST(arch->listFiles), index, COLNUM-1, &text);
      fputs(text,src); 
      gtk_clist_get_text(GTK_CLIST(arch->listFiles), index, 0, &text);
      fputs(text,src); 
      fputc('\n',src);

      selection= selection->next;
    }
    fclose(src);
    cmd = g_malloc(sizeof(gchar)*(38+strlen(dir)+strlen(arch->OpenFile)+strlen(tmpOut)));
    sprintf(cmd, "cd \"%s\"; bunzip2 -c \"%s\" | tar -xf - -T %s", dir, arch->OpenFile, tmpOut);
  }
  
  result = system(cmd); 
  if (tmpOut != NULL) unlink(tmpOut);  
  g_free(cmd);
  return result;
}

int tbz2_add(gchar *fle){

  /*ok, since we can't directly add to zipped tars, lets pretend*/
  gchar *tmpOut;
  gchar *cmd;
  int result;
  tmpOut = tempnam("","gxtar");

  if (!arch->Blank) {
    cmd = g_malloc(sizeof(gchar)*(17+strlen(arch->OpenFile)+strlen(tmpOut)));
    sprintf(cmd, "bunzip2 -c \"%s\" > %s",arch->OpenFile, tmpOut);
    result = system(cmd); 
    g_free(cmd);
  }
  
  tar_add_actual(tmpOut,fle);
  
  cmd = g_malloc(sizeof(gchar)*(7+strlen(tmpOut)));
  sprintf(cmd, "bzip2 %s",tmpOut);
  result = system(cmd); 
  g_free(cmd);

  cmd = g_malloc(sizeof(gchar)*(11+strlen(tmpOut)+strlen(arch->OpenFile) ));
  sprintf(cmd, "mv %s.bz2 \"%s\"",tmpOut, arch->OpenFile);
  result = system(cmd); 
  g_free(cmd);

  unlink(tmpOut);

  cmd = g_malloc(sizeof(gchar)*(6+strlen(tmpOut)));
  sprintf(cmd,"%s.bz2",tmpOut);
  unlink(cmd);
  g_free(cmd);

  return 0;
}


int tbz2_delete(gchar *fle){

 /*ok, since we can't directly delete from  zipped tars, lets pretend*/
  gchar *tmpOut;
  gchar *cmd;
  int result;
  gint nullnum;


if (debug_off) nullnum = 13; else nullnum = 0;

  tmpOut = tempnam("","gxtar");
  cmd = g_malloc(sizeof(gchar)*(17+strlen(tmpOut)+strlen(arch->OpenFile) ));
  sprintf(cmd, "bunzip2 -c \"%s\" > %s",arch->OpenFile, tmpOut);
  result = system(cmd); 
  g_free(cmd);

  result = tar_delete_actual(tmpOut,fle);

  cmd = g_malloc(sizeof(gchar)*(7+strlen(tmpOut)+nullnum));
  sprintf(cmd, "bzip2 %s",tmpOut);
  if (debug_off) strcat(cmd, " >> /dev/null");
  result = system(cmd); 
  g_free(cmd);

  cmd = g_malloc(sizeof(gchar)*(14+strlen(tmpOut)+strlen(arch->OpenFile)+nullnum));
  sprintf(cmd, "mv -f %s.bz2 \"%s\"",tmpOut, arch->OpenFile);
  if (debug_off) strcat(cmd, " >> /dev/null");
  result = system(cmd); 
  g_free(cmd);
  
  unlink(tmpOut); 

  cmd = g_malloc(sizeof(gchar)*(5+strlen(tmpOut)+nullnum));
  sprintf(cmd,"%s.bz2",tmpOut);  
  unlink(cmd);
  g_free(cmd);

  return 0;
}

gchar * tbz2_view( gchar *fle){
  gchar * cmd;
  cmd = g_malloc(sizeof(gchar)*(30+strlen(fle)+strlen(arch->OpenFile)));
  sprintf(cmd, "bunzip2 -c \"%s\" | tar -xOf - \"%s\"",  arch->OpenFile, fle);
  return cmd;
}
