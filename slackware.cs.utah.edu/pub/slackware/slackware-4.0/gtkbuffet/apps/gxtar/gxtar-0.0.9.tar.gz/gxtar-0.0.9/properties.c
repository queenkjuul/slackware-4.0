
#include "properties.h"

/*
  -program locations
  -program paramaters??
  -prompt on other feature maybe?
  -mime types
*/


static GtkWidget *propbox = NULL;
int TRememberPosition;
int TPromptOnDelete;
int TPromptOnQuit;
gint Tdebug_off;
GtkWidget *wft, *wlw, *wlh;


static void rememberpos_cb( GtkWidget *widget, gpointer data)
{
  TRememberPosition = GTK_TOGGLE_BUTTON(widget)->active;
  gnome_property_box_changed(GNOME_PROPERTY_BOX(propbox));
}

static void promptondelete_cb( GtkWidget *widget, gpointer data)
{
  TPromptOnDelete = GTK_TOGGLE_BUTTON(widget)->active;
  gnome_property_box_changed(GNOME_PROPERTY_BOX(propbox));
}

static void promptonquit_cb( GtkWidget *widget, gpointer data)
{
  TPromptOnQuit = GTK_TOGGLE_BUTTON(widget)->active;
  gnome_property_box_changed(GNOME_PROPERTY_BOX(propbox));
}

static void tapedevice_cb( GtkWidget *widget, gpointer data)
{
  gnome_property_box_changed(GNOME_PROPERTY_BOX(propbox));
}

static void lessheight_cb( GtkWidget *widget, gpointer data)
{
  gnome_property_box_changed(GNOME_PROPERTY_BOX(propbox));
}

static void lesswidth_cb( GtkWidget *widget, gpointer data)
{
  gnome_property_box_changed(GNOME_PROPERTY_BOX(propbox));
}


static void apply_cb( GtkWidget   *w, gint pagenum, gpointer data)
{
  if (pagenum == 0) {
    
    RememberPosition = TRememberPosition;
    PromptOnDelete = TPromptOnDelete;
    PromptOnQuit = TPromptOnQuit;
    debug_off = Tdebug_off;
    
    if (ForcedTar != NULL) g_free(ForcedTar);
    ForcedTar = g_malloc(strlen(gtk_entry_get_text(GTK_ENTRY(wft)))+1);
    strcpy(ForcedTar, gtk_entry_get_text(GTK_ENTRY(wft)));

    less_w = atoi(gtk_entry_get_text(GTK_ENTRY(wlw)));
    less_h = atoi(gtk_entry_get_text(GTK_ENTRY(wlh)));

    /* now write these values back to the config */
    gnome_config_push_prefix ("gxtar/");
    gnome_config_set_int("Options/RememberPosition",RememberPosition);
    gnome_config_set_int("Options/PromptOnDelete", PromptOnDelete);
    gnome_config_set_int("Options/PromptOnQuit",  PromptOnQuit);
    gnome_config_set_int("Options/DebugOff", debug_off);
    gnome_config_set_int("Options/Less_W", less_w);
    gnome_config_set_int("Options/Less_H", less_h);
    gnome_config_set_string("Options/ForcedTar", ForcedTar);
    gnome_config_sync();
    gnome_config_pop_prefix();
  }
}

static void destroy_cb( GtkWidget   *w, gpointer data)
{
  gtk_widget_destroy (propbox);
  propbox = NULL;
}

void show_properties_dialog()
{
  GtkWidget *cpage;
  GtkWidget *hbox;
  GtkWidget *chkbox;
  GtkWidget *label;
  GtkWidget *textbox;
  gchar tlw[10];
  gchar tlh[10]; 

  if(propbox) return;

  /* Copy current setting into temporary */
  TRememberPosition = RememberPosition;
  TPromptOnDelete = PromptOnDelete;
  TPromptOnQuit = PromptOnQuit;
  Tdebug_off = debug_off;
  snprintf(tlw, 9, "%d",less_w);
  snprintf(tlh, 9, "%d",less_h);

  propbox = gnome_property_box_new();
  gtk_window_set_modal(GTK_WINDOW(propbox), TRUE);
  gtk_window_set_title(GTK_WINDOW(&GNOME_PROPERTY_BOX(propbox)->dialog.window), _("gxTar Preferences"));
  
  cpage = gtk_vbox_new(FALSE, 0);
  gtk_container_set_border_width(GTK_CONTAINER(cpage), GNOME_PAD_SMALL);
  
  hbox = gtk_hbox_new(TRUE, 0);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, TRUE, GNOME_PAD_SMALL);
  chkbox = gtk_check_button_new_with_label(_("Remember Position"));
  GTK_TOGGLE_BUTTON(chkbox)->active = TRememberPosition;
  gtk_signal_connect(GTK_OBJECT(chkbox), "clicked",
		     (GtkSignalFunc)rememberpos_cb, NULL);
  gtk_box_pack_start(GTK_BOX(hbox), chkbox, TRUE, TRUE, GNOME_PAD_SMALL);
  gtk_widget_show (chkbox);
  gtk_widget_show(hbox);

  hbox = gtk_hbox_new(TRUE, 0);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, TRUE, GNOME_PAD_SMALL);
  chkbox = gtk_check_button_new_with_label(_("Prompt On Delete"));
  GTK_TOGGLE_BUTTON(chkbox)->active = TPromptOnDelete;
  gtk_signal_connect(GTK_OBJECT(chkbox), "clicked",
		     (GtkSignalFunc)promptondelete_cb, NULL);
  gtk_box_pack_start(GTK_BOX(hbox), chkbox, TRUE, TRUE, GNOME_PAD_SMALL);
  gtk_widget_show (chkbox);
  gtk_widget_show(hbox);
  
  hbox = gtk_hbox_new(TRUE, 0);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, TRUE, GNOME_PAD_SMALL);
  chkbox = gtk_check_button_new_with_label(_("Prompt On Quit"));
  GTK_TOGGLE_BUTTON(chkbox)->active = TPromptOnQuit;
  gtk_signal_connect(GTK_OBJECT(chkbox), "clicked",
		     (GtkSignalFunc)promptonquit_cb, NULL);
  gtk_box_pack_start(GTK_BOX(hbox), chkbox, TRUE, TRUE, GNOME_PAD_SMALL);
  gtk_widget_show (chkbox);
  gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, FALSE, GNOME_PAD_SMALL);
  label = gtk_label_new("Tape Device:");
  textbox = gtk_entry_new();
  wft = textbox;
  if (ForcedTar != NULL)
    gtk_entry_set_text(GTK_ENTRY(textbox),  ForcedTar);

  gtk_signal_connect(GTK_OBJECT(textbox), "key_press_event",
		     (GtkSignalFunc) tapedevice_cb, NULL);

  gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, GNOME_PAD_SMALL);
  gtk_box_pack_start(GTK_BOX(hbox), textbox, FALSE, FALSE, GNOME_PAD_SMALL);
  gtk_widget_show (textbox);
  gtk_widget_show (label);
  gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, FALSE, GNOME_PAD_SMALL);
  label = gtk_label_new("Default Viewer Width:");
  textbox = gtk_entry_new();
  wlw = textbox;
  gtk_entry_set_text(GTK_ENTRY(textbox),  tlw);
  gtk_signal_connect(GTK_OBJECT(textbox), "key_press_event",
		     (GtkSignalFunc) lesswidth_cb, NULL);

  gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, GNOME_PAD_SMALL);
  gtk_box_pack_start(GTK_BOX(hbox), textbox, FALSE, FALSE, GNOME_PAD_SMALL);
  gtk_widget_show (textbox);
  gtk_widget_show (label);
  gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, FALSE, GNOME_PAD_SMALL);
  label = gtk_label_new("Default Viewer Height:");
  textbox = gtk_entry_new();
  wlh = textbox;
  gtk_entry_set_text(GTK_ENTRY(textbox),  tlh);
  gtk_signal_connect(GTK_OBJECT(textbox), "key_press_event",
		     (GtkSignalFunc) lessheight_cb, NULL);

  gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, GNOME_PAD_SMALL);
  gtk_box_pack_start(GTK_BOX(hbox), textbox, FALSE, FALSE, GNOME_PAD_SMALL);
  
  gtk_widget_show (textbox);
  gtk_widget_show (label);
  gtk_widget_show(hbox);

  gtk_widget_show(cpage);
  label = gtk_label_new(_("Configuration"));
  gtk_notebook_append_page(GTK_NOTEBOOK(GNOME_PROPERTY_BOX(propbox)->notebook), 
			   cpage, label);
  
  gtk_signal_connect (GTK_OBJECT (propbox), "destroy",
		      GTK_SIGNAL_FUNC (destroy_cb), NULL);
  gtk_signal_connect (GTK_OBJECT (propbox), "apply",
		      GTK_SIGNAL_FUNC (apply_cb), NULL);
  gtk_widget_show(propbox);
}
