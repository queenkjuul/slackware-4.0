#define VERSION "0.0.9"
#define PACKAGE "gxtar"
