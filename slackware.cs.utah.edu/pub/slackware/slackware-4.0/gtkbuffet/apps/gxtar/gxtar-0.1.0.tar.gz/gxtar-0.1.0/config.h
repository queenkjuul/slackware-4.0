#define VERSION "0.1.0"
#define PACKAGE "gxtar"
