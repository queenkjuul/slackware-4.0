
#include "properties.h"

/*
  -configuration screen
  -program locations
  -program paramaters??
  -prompt on delete y/n
  -prompt on other feature maybe?
  -mime types
*/

/*
tab - program locations
tab - mime types
tab - int RememberPosition;
      int PromptOnDelete;
      int PromptOnQuit;
      gchar * ForcedTar;
      gint debug_off;
*/


static GtkWidget         *propbox      = NULL;

int TRememberPosition;
int TPromptOnDelete;
int TPromptOnQuit;
gchar * TForcedTar = NULL;
gint Tdebug_off;
 


static void rememberpos_cb( GtkWidget *widget, gpointer data)
{
  TRememberPosition = GTK_TOGGLE_BUTTON(widget)->active;
  gnome_property_box_changed(GNOME_PROPERTY_BOX(propbox));
}

static void promptondelete_cb( GtkWidget *widget, gpointer data)
{
  TPromptOnDelete = GTK_TOGGLE_BUTTON(widget)->active;
  gnome_property_box_changed(GNOME_PROPERTY_BOX(propbox));
}

static void promptonquit_cb( GtkWidget *widget, gpointer data)
{
  TPromptOnQuit = GTK_TOGGLE_BUTTON(widget)->active;
  gnome_property_box_changed(GNOME_PROPERTY_BOX(propbox));
}


static void apply_cb( GtkWidget   *w, gint pagenum, gpointer data)
{
  if (pagenum == 0) {
    g_print("apply\n");
    
    RememberPosition = TRememberPosition;
    PromptOnDelete = TPromptOnDelete;
    PromptOnQuit = TPromptOnQuit;
    debug_off = Tdebug_off;
    
    if (ForcedTar != NULL) { g_free(ForcedTar); ForcedTar = NULL;}
    
    if (TForcedTar != NULL)
      {
	ForcedTar = g_malloc(strlen(TForcedTar)+1);
	strcpy(ForcedTar,TForcedTar);
      }
    
    /* now write these values back to the config */
    gnome_config_push_prefix ("gxtar/");
    gnome_config_set_int("Options/RememberPosition",RememberPosition);
    gnome_config_set_int("Options/PromptOnDelete", PromptOnDelete);
    gnome_config_set_int("Options/PromptOnQuit",  PromptOnQuit);
    gnome_config_set_int("Options/DebugOff", debug_off);
    gnome_config_sync();
    gnome_config_pop_prefix();
  }
}


static void destroy_cb( GtkWidget   *w, gpointer data)
{
  if (TForcedTar != NULL) g_free(TForcedTar);
  gtk_widget_destroy (propbox);
  propbox = NULL;
}


void show_properties_dialog()
{
  GtkWidget *cpage;
  GtkWidget *hbox;
  GtkWidget *vbox;
  GtkWidget *chkbox;
  GtkWidget *label;
  
  if(propbox) return;
  
  /* Copy current setting into temporary */
  TRememberPosition = RememberPosition;
  TPromptOnDelete = PromptOnDelete;
  TPromptOnQuit = PromptOnQuit;
  Tdebug_off = debug_off;
  if (ForcedTar != NULL) {
    TForcedTar = g_malloc(strlen(ForcedTar)+1);
    strcpy(TForcedTar,ForcedTar);
  }

  propbox = gnome_property_box_new();
  gtk_window_set_modal(GTK_WINDOW(propbox), TRUE);
  gtk_window_set_title(GTK_WINDOW(&GNOME_PROPERTY_BOX(propbox)->dialog.window), _("gxTar Preferences"));
  
  cpage = gtk_vbox_new(FALSE, GNOME_PAD);
  gtk_container_set_border_width(GTK_CONTAINER(cpage), GNOME_PAD_SMALL);
  
  hbox = gtk_hbox_new(TRUE, GNOME_PAD);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, TRUE, GNOME_PAD);
  chkbox = gtk_check_button_new_with_label(_("Remember Position"));
  GTK_TOGGLE_BUTTON(chkbox)->active = TRememberPosition;
  gtk_signal_connect(GTK_OBJECT(chkbox), "clicked",
		     (GtkSignalFunc)rememberpos_cb, NULL);
  gtk_box_pack_start(GTK_BOX(hbox), chkbox, TRUE, TRUE, GNOME_PAD);
  gtk_widget_show (chkbox);
  gtk_widget_show(hbox);

  hbox = gtk_hbox_new(TRUE, GNOME_PAD);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, TRUE, GNOME_PAD);
  chkbox = gtk_check_button_new_with_label(_("Prompt On Delete"));
  GTK_TOGGLE_BUTTON(chkbox)->active = TPromptOnDelete;
  gtk_signal_connect(GTK_OBJECT(chkbox), "clicked",
		     (GtkSignalFunc)promptondelete_cb, NULL);
  gtk_box_pack_start(GTK_BOX(hbox), chkbox, TRUE, TRUE, GNOME_PAD);
  gtk_widget_show (chkbox);
  gtk_widget_show(hbox);
  
  hbox = gtk_hbox_new(TRUE, GNOME_PAD);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, TRUE, GNOME_PAD);
  chkbox = gtk_check_button_new_with_label(_("Prompt On Quit"));
  GTK_TOGGLE_BUTTON(chkbox)->active = TPromptOnQuit;
  gtk_signal_connect(GTK_OBJECT(chkbox), "clicked",
		     (GtkSignalFunc)promptonquit_cb, NULL);
  gtk_box_pack_start(GTK_BOX(hbox), chkbox, TRUE, TRUE, GNOME_PAD);
  gtk_widget_show (chkbox);
  gtk_widget_show(hbox);


  hbox = gtk_hbox_new(TRUE, GNOME_PAD);
  gtk_box_pack_start(GTK_BOX(cpage), hbox, FALSE, TRUE, GNOME_PAD);
  chkbox = gtk_check_button_new_with_label(_("Tar Device"));
  GTK_TOGGLE_BUTTON(chkbox)->active = TPromptOnQuit;
  gtk_signal_connect(GTK_OBJECT(chkbox), "clicked",
		     (GtkSignalFunc)promptonquit_cb, NULL);
  gtk_box_pack_start(GTK_BOX(hbox), chkbox, TRUE, TRUE, GNOME_PAD);
  gtk_widget_show (chkbox);
  gtk_widget_show(hbox);

  gtk_widget_show(vbox);
  gtk_widget_show(cpage);
  label = gtk_label_new(_("Configuration"));
  gtk_notebook_append_page(GTK_NOTEBOOK(GNOME_PROPERTY_BOX(propbox)->notebook), 
			   cpage, label);
  
  gtk_signal_connect (GTK_OBJECT (propbox), "destroy",
		      GTK_SIGNAL_FUNC (destroy_cb), NULL);
  gtk_signal_connect (GTK_OBJECT (propbox), "apply",
		      GTK_SIGNAL_FUNC (apply_cb), NULL);
  gtk_widget_show(propbox);
}
