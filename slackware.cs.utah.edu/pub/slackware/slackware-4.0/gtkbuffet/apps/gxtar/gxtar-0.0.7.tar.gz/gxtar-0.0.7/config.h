#define VERSION "0.0.7"
#define PACKAGE "gxtar"
