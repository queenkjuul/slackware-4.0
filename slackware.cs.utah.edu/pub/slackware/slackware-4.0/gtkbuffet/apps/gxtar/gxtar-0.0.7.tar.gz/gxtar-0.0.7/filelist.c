/* gxTar - Gnomified Archive Frontend
 * Copyright (C) 1998 Chris Rogers
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option) 
 * any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
 * GNU General Public License for more details.
 *  
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 * 02111-1307, USA.
 */

#include "filelist.h"


static void clist_click_column (GtkCList *clist, gint column, gpointer data)
{

  if (column != clist->sort_column)
    gtk_clist_set_sort_column (clist, column);
  else {
    if (clist->sort_type == GTK_SORT_ASCENDING)
      clist->sort_type = GTK_SORT_DESCENDING;
    else
      clist->sort_type = GTK_SORT_ASCENDING;
  }

  
  gtk_clist_sort (clist);
}

void createFileList(GtkWidget * frame) {
  
  GtkWidget *scrolled_window;
  gchar *listTitles[6];
  
  listTitles[0] = g_malloc(sizeof(gchar) *5 );listTitles[0] = "Name\0";
  listTitles[1] = g_malloc(sizeof(gchar) *5 );listTitles[1] = "Date\0";
  listTitles[2] = g_malloc(sizeof(gchar) *5 );listTitles[2] = "Size\0";
  listTitles[3] = g_malloc(sizeof(gchar) *12 );listTitles[3] ="Permissions\0";
  listTitles[4] = g_malloc(sizeof(gchar) *6 );listTitles[4] = "Ratio\0";
  listTitles[5] = g_malloc(sizeof(gchar) *5 );listTitles[5] = "Path\0";
    
  arch = g_malloc(sizeof(struct archive));
  arch->listFiles  =  gtk_clist_new_with_titles( 6, listTitles);

  gtk_clist_set_column_width( GTK_CLIST (  arch->listFiles),0,45);
  gtk_clist_set_column_width( GTK_CLIST (  arch->listFiles),1,45);
  gtk_clist_set_column_width( GTK_CLIST (  arch->listFiles),2,45);
  gtk_clist_set_column_width( GTK_CLIST (  arch->listFiles),3,65);
  gtk_clist_set_column_width( GTK_CLIST (  arch->listFiles),4,45);
  gtk_clist_set_column_width( GTK_CLIST (  arch->listFiles),5,70);
  gtk_clist_set_selection_mode(GTK_CLIST (  arch->listFiles), GTK_SELECTION_EXTENDED);
  /*  gtk_clist_set_policy (GTK_CLIST (arch->listFiles),  GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC); */
  gtk_clist_column_titles_active(GTK_CLIST (  arch->listFiles));
  
  
  gtk_signal_connect (GTK_OBJECT (arch->listFiles), "click_column",
		      (GtkSignalFunc) clist_click_column, NULL);
  

  scrolled_window=gtk_scrolled_window_new(NULL, NULL);
  gtk_container_add(GTK_CONTAINER(scrolled_window), arch->listFiles);
  gtk_box_pack_start(GTK_BOX(frame), scrolled_window, TRUE, TRUE, 0);
  gtk_widget_show(scrolled_window);
  gtk_widget_show(arch->listFiles);
}

