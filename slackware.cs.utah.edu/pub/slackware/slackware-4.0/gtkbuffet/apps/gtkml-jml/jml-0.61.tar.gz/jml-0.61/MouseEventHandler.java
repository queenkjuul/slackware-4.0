/* JML - Java Markup Language
 * Copyright (C) 1998 Scott Dybiec
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

import java.awt.*;
import java.awt.event.*;


class MouseEventHandler extends MouseAdapter {
   private int event;
   public final static short ONCLICK=10;
   public final static short ONPRESS=11;
   public final static short ONRELEASE=12;
   public final static short ONENTER=13;
   public final static short ONLEAVE=14;
   public final static short ONTOGGLE=15;

   private int action;
   public final static short SENSITIZE=16;
   public final static short INSENSITIZE=17;
   public final static short TOGGLESENSITIVITY=18;
   public final static short SHOW=19;
   public final static short HIDE=20;
   public final static short TOGGLEVISIBILITY=21;
   public final static short SUBMITFORM=22;
   public final static short RESETFORM=23;
   public final static short CANCELFORM=24;

   private Component target;

   MouseEventHandler(int event, int action, Component target) {
      super();
      this.event = event;
      this.action = action;
      this.target = target;
   }

   public void mouseClicked(MouseEvent e) {
      if (event == ONCLICK) {
         //System.out.println("Event: mouseClicked");
         processAction();
      }
   }
                              
   public void mousePressed(MouseEvent e) {
      if (event == ONPRESS) {
         //System.out.println("Event: mousePressed");
         processAction();
      }
   }
                              
   public void mouseReleased(MouseEvent e) {
      if (event == ONRELEASE) {
         //System.out.println("Event: mouseReleased");
         processAction();
      }
   }
                              
   public void mouseEntered(MouseEvent e) {
      if (event == ONENTER) {
         //System.out.println("Event: mouseEntered");
         processAction();
      }
   }
                              
   public void mouseExited(MouseEvent e) {
      if (event == ONLEAVE) {
         //System.out.println("Event: mouseExited");
         processAction();
      }
   }
 
   public void redisplay(Component c) {
      c.invalidate();
      Component parent = c.getParent();
      while (parent != null) {
         Class cl = parent.getClass();
         String s = cl.getName();
         parent.invalidate();
         parent.validate();
         parent.repaint();
         if (s.equals("JBorderFrame")) {
            JBorderFrame f = (JBorderFrame)parent;
            f.pack();
         }
         parent = parent.getParent();
      }
   }
  
   public void processAction() { 
      switch (action) {
         case SENSITIZE:   target.setEnabled(true); redisplay(target); break;
         case INSENSITIZE: target.setEnabled(false); redisplay(target); break;
         case SHOW:        target.setVisible(true); redisplay(target); break;
         case HIDE:        target.setVisible(false); redisplay(target); break; 
         case TOGGLEVISIBILITY:  target.setVisible(!target.isVisible()); 
                                 redisplay(target); 
                                 break; 
         case TOGGLESENSITIVITY: target.setEnabled(!target.isEnabled()); 
                                 System.out.println("Process Event: ToggleSensitivity");
                                 if (target.isEnabled())
                                    System.out.println("Target is enabled");
                                 else
                                    System.out.println("Target is disabled");
                                 redisplay(target); 
                                 break;
      }
   }
}
                              

