//### This file created by BYACC 1.8(/Java extension  0.9)
//### Java capabilities added 7 Jan 97, Bob Jamison
//### Updated : 27 Nov 97  -- Bob Jamison, Joe Nieten
//###           Updateed to JDK1.1 and added LVAL type
//### Please send bug reports to rjamison@lincom-asg.com
//### static char yysccsid[] = "@(#)yaccpar	1.8 (Berkeley) 01/20/90";



//#line 2 "jmlparser.y"
/* JML - Java Markup Language
 * Copyright (C) 1998 Scott Dybiec
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */


import java.lang.Math;
import java.io.*;
import java.util.StringTokenizer;
import com.sun.java.swing.*;
import com.sun.java.swing.border.*;
import com.sun.java.swing.text.*;
import com.sun.java.swing.event.*;
import com.sun.java.swing.preview.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.Hashtable;
//#line 42 "jmlparser.java"




//#####################################################################
// class: jmlparser
// does : encapsulates yacc() parser functionality in a Java
//        class for quick code development
//#####################################################################
public class jmlparser extends Thread
{

boolean yydebug;        //do I want debug output?
int yynerrs;            //number of errors so far
int yyerrflag;          //was there an error?
int yychar;             //the current working character

//########## MESSAGES ##########
//###############################################################
// method: debug
//###############################################################
void debug(String msg)
{
  if (yydebug)
    System.out.println(msg);
}

//########## STATE STACK ##########
final static int YYSTACKSIZE = 500;  //maximum stack size
int statestk[],stateptr;             //state stack
//###############################################################
// methods: state stack push,pop,drop,peek
//###############################################################
void state_push(int state)
{
  if (stateptr>=YYSTACKSIZE)         //overflowed?
    return;
  statestk[++stateptr]=state;
}
int state_pop()
{
  if (stateptr<0)                    //underflowed?
    return -1;
  return statestk[stateptr--];
}
void state_drop(int cnt)
{
int ptr;
  ptr=stateptr-cnt;
  if (ptr<0)
    return;
  stateptr = ptr;
}
int state_peek(int relative)
{
int ptr;
  ptr=stateptr-relative;
  if (ptr<0)
    return -1;
  return statestk[ptr];
}
//###############################################################
// method: init_stacks : allocate and prepare stacks
//###############################################################
boolean init_stacks()
{
  statestk = new int[YYSTACKSIZE];
  stateptr = -1;
  val_init();
  return true;
}
//###############################################################
// method: dump_stacks : show n levels of the stacks
//###############################################################
void dump_stacks(int count)
{
int i;
  System.out.println("=index==state====value=     s:"+stateptr+"  v:"+valptr);
  for (i=0;i<count;i++)
    System.out.println(" "+i+"    "+statestk[i]+"      "+valstk[i]);
  System.out.println("======================");
}


//########## SEMANTIC VALUES ##########
//public class jmlparsersemantic is defined in jmlparserval.java


String   yytext;//user variable to return contextual strings
jmlparserval yyval; //used to return semantic vals from action routines
jmlparserval yylval;//the 'lval' (result) I got from yylex()
jmlparserval valstk[];
int valptr;
//###############################################################
// methods: value stack push,pop,drop,peek.
//###############################################################
void val_init()
{
  valstk=new jmlparserval[YYSTACKSIZE];
  yyval=new jmlparserval(0);
  yylval=new jmlparserval(0);
  valptr=-1;
}
void val_push(jmlparserval val)
{
  if (valptr>=YYSTACKSIZE)
    return;
  valstk[++valptr]=val;
}
jmlparserval val_pop()
{
  if (valptr<0)
    return new jmlparserval(-1);
  return valstk[valptr--];
}
void val_drop(int cnt)
{
int ptr;
  ptr=valptr-cnt;
  if (ptr<0)
    return;
  valptr = ptr;
}
jmlparserval val_peek(int relative)
{
int ptr;
  ptr=valptr-relative;
  if (ptr<0)
    return new jmlparserval(-1);
  return valstk[ptr];
}
//#### end semantic value section ####
public final static short NUMBER=257;
public final static short NL=258;
public final static short OPERATOR=259;
public final static short PAREN=260;
public final static short CARET=261;
public final static short QSTRING=262;
public final static short BADSTRING=263;
public final static short COMMA=264;
public final static short ID=265;
public final static short OBRACE=266;
public final static short CBRACE=267;
public final static short FORM=268;
public final static short TITLE=269;
public final static short HORIZONTALBOX=270;
public final static short VERTICALBOX=271;
public final static short HOMOGENEOUS=272;
public final static short SPACING=273;
public final static short FRAME=274;
public final static short BORDERWIDTH=275;
public final static short BUTTON=276;
public final static short TOGGLEBUTTON=277;
public final static short CHECKBUTTON=278;
public final static short LABEL=279;
public final static short WINDOW=280;
public final static short TOOLTIP=281;
public final static short ENTRY=282;
public final static short NOTEBOOK=283;
public final static short PAGE=284;
public final static short TABPOSITION=285;
public final static short TOP=286;
public final static short BOTTOM=287;
public final static short LEFT=288;
public final static short RIGHT=289;
public final static short RADIOBUTTON=290;
public final static short RADIOGROUP=291;
public final static short LIST=292;
public final static short LISTITEM=293;
public final static short FRAMESHADOW=294;
public final static short SHADOW_IN=295;
public final static short SHADOW_OUT=296;
public final static short SHADOW_NONE=297;
public final static short SHADOW_ETCHED_IN=298;
public final static short SHADOW_ETCHED_OUT=299;
public final static short WIDGET=300;
public final static short ONCLICK=301;
public final static short ONPRESS=302;
public final static short ONRELEASE=303;
public final static short ONENTER=304;
public final static short ONLEAVE=305;
public final static short ONTOGGLE=306;
public final static short SENSITIZE=307;
public final static short INSENSITIZE=308;
public final static short SHOW=309;
public final static short HIDE=310;
public final static short TOGGLESENSITIVITY=311;
public final static short TOGGLEVISIBILITY=312;
public final static short SUBMITFORM=313;
public final static short RESETFORM=314;
public final static short CANCELFORM=315;
public final static short JUSTIFY=316;
public final static short CENTER=317;
public final static short FILL=318;
public final static short FILECHOOSER=319;
public final static short DIRCHOOSER=320;
public final static short TABLE=321;
public final static short TABLEDATUM=322;
public final static short XPADDING=323;
public final static short YPADDING=324;
public final static short COMBOBOX=325;
public final static short COMBOITEM=326;
public final static short TRUE=327;
public final static short FALSE=328;
public final static short YYERRCODE=256;
final static short yylhs[] = {                           -1,
    0,    0,    2,    2,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,   11,   17,
   18,   18,   21,   22,   22,   23,   19,   19,   12,    3,
   24,   24,   25,   25,   26,   26,   27,   27,   27,   27,
   27,   27,    4,   28,   20,   20,    5,   29,    6,   30,
   31,   31,    7,    7,   32,   33,   34,   34,   34,   36,
   36,   37,   37,   38,   39,   39,   39,   39,   39,   39,
   40,   40,   40,   40,   40,   40,   40,   40,   40,   35,
   35,    8,   41,   43,   43,   44,   45,   45,   45,   42,
   42,   42,   42,   42,    9,   46,   47,   47,   48,   48,
   49,   10,   50,   51,   51,   52,   13,   14,   15,   53,
   54,   54,   55,   55,   56,   57,   58,   58,   59,   59,
   16,   60,   61,   61,   62,
};
final static short yylen[] = {                            2,
    1,    2,    0,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    7,    1,
    0,    1,    1,    1,    1,    1,    0,    2,    2,    8,
    1,    1,    0,    2,    0,    2,    1,    1,    1,    1,
    1,    1,    6,    1,    0,    2,    3,    1,    3,    1,
    0,    1,    1,    1,    3,    8,    1,    1,    1,    0,
    1,    1,    2,    3,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    0,
    2,    6,    1,    1,    2,    6,    1,    1,    1,    0,
    2,    2,    2,    2,    4,    1,    1,    2,    3,    7,
    1,    5,    1,    1,    2,    2,    2,    2,    6,    3,
    0,    1,    1,    2,    6,    5,    0,    2,    0,    2,
    4,    2,    1,    2,    2,
};
final static short yydefred[] = {                         0,
   31,   32,   44,   57,   58,   59,   48,   20,   50,   83,
   96,  103,    0,    0,    0,    0,    0,    0,    1,    5,
    6,    7,    8,    9,   10,   11,   12,   13,   14,   15,
   16,   17,   18,    0,    0,    0,    0,    0,   53,   54,
    0,    0,    0,    0,    0,    0,   29,   26,  107,  108,
    0,  122,    2,   23,    0,   22,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  110,    0,    0,    0,
   47,   52,   49,    0,   55,    0,  101,    0,   97,    0,
    0,    0,    0,    0,  123,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   95,   98,    0,    0,    0,  104,
    0,  125,  121,  124,   28,    0,   34,    0,    0,    0,
   46,    0,    0,   91,   92,   93,   94,    0,    0,   84,
    0,   99,  106,  102,  105,    0,    0,    0,  113,    0,
    0,    0,    0,   43,   81,   65,   66,   67,   68,   69,
   70,    0,    0,   62,    0,    0,   82,   85,    0,    0,
  109,  114,    0,   19,   37,   38,   39,   40,   41,   42,
   36,    0,    0,   63,   71,   72,   74,   75,   73,   76,
   77,   78,   79,    0,    0,    0,    0,    0,    0,   30,
   56,   64,    0,    0,    0,  118,    0,    0,   87,   89,
   88,    0,  100,  116,  120,    0,   86,  115,
};
final static short yydgoto[] = {                        109,
   19,  110,   20,   21,   22,   23,   24,   25,   26,   27,
   28,   29,   30,   31,   32,   33,   34,   55,   87,   92,
   56,    0,   49,   35,   89,  133,  161,   36,   37,   38,
   73,   39,   40,   41,  113,  142,  143,  144,  145,  174,
   42,   94,  119,  120,  192,   43,   78,   79,   80,   44,
   99,  100,   45,  127,  128,  129,  130,  179,  188,   46,
   84,   85,
};
final static short yysindex[] = {                       373,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0, -250, -255, -255, -249, -237,  373,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0, -230, -230, -230, -230, -230,    0,    0,
 -230, -230, -214, -230, -230, -207,    0,    0,    0,    0,
 -197,    0,    0,    0, -194,    0, -192, -191, -255, -188,
 -239, -190, -224, -187, -182, -227,    0, -173, -153, -173,
    0,    0,    0, -144,    0, -172,    0, -261,    0, -230,
 -171, -144, -255, -262,    0, -255, -144, -116, -144,  373,
 -115, -133, -113, -138,    0,    0, -221, -255, -256,    0,
 -170,    0,    0,    0,    0,  373,    0, -163,  373, -112,
    0, -255, -137,    0,    0,    0,    0, -105, -241,    0,
 -144,    0,    0,    0,    0,  -87,  -90, -170,    0,  -88,
  -80, -200,  373,    0,    0,    0,    0,    0,    0,    0,
    0,  373, -137,    0, -175, -173,    0,    0, -133,  -78,
    0,    0, -134,    0,    0,    0,    0,    0,    0,    0,
    0,  -79,  -77,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  -74, -133,  373,  -65,  -63, -131,    0,
    0,    0, -193,  -72,  -61,    0,  -60,  373,    0,    0,
    0,  -69,    0,    0,    0,  -59,    0,    0,
};
final static short yyrindex[] = {                         0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  -62,  -62,  -62,  -53,    1,    0,    0,
 -211,  -62,    0,  -62,  -62,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   32,
    0,    0,    0,    0,    0,    0,    0,  -64, -258,  156,
    0,    0,    0, -176,    0,  -82,    0,    0,    0, -211,
    0, -257,    0,    0,    0,    0,  187,    0,   63,  -50,
    0, -120,    0,    0,    0,    0,    0,    0,    0,    0,
  -47,    0,    0,    0,    0,  -50,    0,  218,  -46,    0,
    0,    0,  249,    0,    0,    0,    0,    0,    0,    0,
   94,    0,    0,    0,    0,    0,    0,  -45,    0,    0,
    0,    0,  -50,    0,    0,    0,    0,    0,    0,    0,
    0,  -50,  280,    0,    0, -162,    0,    0,  311,    0,
    0,    0,  125,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0, -160,  -50,    0,    0,  342,    0,
    0,    0,    0,    0,    0,    0,    0,  -50,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,
};
final static short yygindex[] = {                       223,
  -16, -103,   41,   42,    0,    0,    0,   43,    0,    0,
    0,    0,    0,    0,    0,    0,    0,   12,  -66,  -51,
    0,    0,  -15,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0, -135,    0,    0,   86,    0,    0,
    0,    0,    0,  111,    0,    0,    0,  153,    0,    0,
    0,  133,    0,    0,    0,  105,    0,    0,    0,    0,
    0,  150,
};
final static int YYTABLESIZE=698;
final static short yytable[] = {                         50,
   21,   53,  131,   90,  103,   95,   48,   51,   33,   45,
  124,   33,   33,  176,   47,   33,   33,   33,   33,   33,
   33,   33,   48,   33,   33,  147,   74,   52,   77,  162,
  101,   51,   33,   33,   54,  106,   98,  108,  163,  183,
   48,   33,  118,   71,  121,   75,   57,   58,   59,   60,
   21,   63,   61,   62,   21,   64,   65,   33,   66,   67,
   33,   33,   33,   83,   45,   77,   33,  102,   72,  149,
  105,   68,  184,   69,   70,   76,    1,    2,   81,  175,
    3,  122,  123,   82,  196,  155,  156,  157,  158,   10,
   45,   97,   53,   45,   45,   86,  135,   45,   83,   45,
   45,   45,   45,   45,   45,   45,   45,   27,   27,   80,
   80,   27,   93,   80,   45,   45,  159,  160,   27,   88,
   27,   98,   80,   45,   45,   45,   45,   45,   45,   45,
   91,  165,  166,  167,  168,  169,  170,  171,  172,  173,
  107,  111,   45,   45,   45,  118,   80,  112,   45,   80,
   80,  126,  132,   80,  134,   80,   80,   80,   80,   80,
  146,   80,   80,  136,  137,  138,  139,  140,  141,  150,
   80,   80,  114,  115,  116,  117,  151,  153,  177,   80,
   80,   80,   80,   80,   80,   80,  154,  180,  178,  181,
  182,  185,  187,  186,  193,  194,  195,  197,   80,   80,
   80,   90,   27,   21,   80,   27,   27,  198,   21,   27,
   27,   27,   27,   27,   27,   27,    3,   27,   27,  111,
    4,  112,   18,  189,  190,  191,   27,   27,  164,  148,
   96,  125,  152,  104,    0,   27,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   27,   27,   27,   21,    0,    0,
   27,    0,    0,    0,    0,    0,    0,   21,    0,    0,
   21,   21,    0,    0,   21,    0,   21,   21,   21,   21,
   21,    0,   21,   21,    0,    0,    0,    0,    0,    0,
    0,   21,   21,    0,    0,    0,    0,    0,   51,    0,
   21,   51,   51,    0,    0,   51,    0,   51,   51,   51,
   51,   51,    0,   51,   51,    0,    0,    0,    0,   21,
   21,   21,   51,   51,    0,   21,    0,    0,    0,   45,
    0,   51,   45,   45,    0,    0,   45,    0,   45,   45,
   45,   45,   45,    0,   45,   45,    0,    0,    0,    0,
   51,   51,   51,   45,   45,    0,   51,    0,    0,    0,
   45,    0,   45,   45,   45,    0,    0,   45,    0,   45,
   45,   45,   45,   45,   45,   45,   45,    0,   45,    0,
    0,   45,   45,   45,   45,   45,    0,   45,    0,    0,
    0,  117,    0,   45,  117,  117,    0,    0,  117,    0,
  117,  117,  117,  117,  117,    0,  117,  117,    0,    0,
    0,    0,   45,   45,   45,  117,  117,    0,   45,    0,
    0,    0,   27,    0,  117,   27,   27,    0,    0,   27,
    0,   27,   27,   27,   27,   27,    0,   27,   27,    0,
    0,    0,    0,  117,  117,  117,   27,   27,  117,  117,
    0,    0,    0,   45,    0,   27,   45,   45,    0,    0,
   45,    0,   45,   45,   45,   45,   45,    0,   45,   45,
    0,    0,    0,    0,   27,   27,   27,   45,   45,    0,
   27,    0,    0,    0,   35,    0,   45,   35,   35,    0,
    0,   35,    0,   35,   35,   35,   35,   35,    0,   35,
   35,    0,    0,    0,    0,   45,   45,   45,   35,   35,
    0,   45,    0,    0,    0,   60,    0,   35,   60,   60,
    0,    0,   60,    0,   60,   60,   60,   60,   60,    0,
   60,   60,    0,    0,    0,    0,   35,   35,   35,   60,
   60,    0,   35,    0,    0,    0,   61,    0,   60,   61,
   61,    0,    0,   61,    0,   61,   61,   61,   61,   61,
    0,   61,   61,    0,    0,    0,    0,   60,   60,   60,
   61,   61,    0,   60,    0,    0,    0,   80,    0,   61,
   80,   80,    0,    0,   80,    0,   80,   80,   80,   80,
   80,    0,   80,   80,    0,    0,    0,    0,   61,   61,
   61,   80,   80,    0,   61,    0,    0,    0,  119,    0,
   80,  119,  119,    0,    0,  119,    0,  119,  119,  119,
  119,  119,    0,  119,  119,    0,    0,    0,    0,   80,
   80,   80,  119,  119,    0,   80,    0,    0,    0,    0,
    0,  119,    1,    2,    0,    0,    3,    0,    4,    5,
    6,    7,    8,    0,    9,   10,    0,    0,    0,    0,
  119,  119,  119,   11,   12,    0,  119,    0,    0,    0,
    0,    0,   13,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,   14,   15,   16,    0,    0,    0,   17,
};
final static short yycheck[] = {                         15,
    0,   18,  106,   70,  267,  267,  262,  257,  267,  267,
  267,  270,  271,  149,  265,  274,  275,  276,  277,  278,
  279,  280,  262,  282,  283,  267,  266,  265,  290,  133,
   82,    0,  291,  292,  265,   87,  293,   89,  142,  175,
  262,  300,  284,   59,  266,   61,   35,   36,   37,   38,
  262,  266,   41,   42,  266,   44,   45,  316,  266,  257,
  319,  320,  321,  326,  322,  290,  325,   83,  257,  121,
   86,  266,  176,  266,  266,  266,  270,  271,  266,  146,
  274,   97,   98,  266,  188,  286,  287,  288,  289,  283,
  267,   80,  109,  270,  271,  269,  112,  274,  326,  276,
  277,  278,  279,  280,  281,  282,  283,  270,  271,  270,
  271,  274,  285,  274,  291,  292,  317,  318,  281,  273,
  283,  293,  283,  300,  301,  302,  303,  304,  305,  306,
  275,  307,  308,  309,  310,  311,  312,  313,  314,  315,
  257,  257,  319,  320,  321,  284,  267,  281,  325,  270,
  271,  322,  316,  274,  267,  276,  277,  278,  279,  280,
  266,  282,  283,  301,  302,  303,  304,  305,  306,  257,
  291,  292,  286,  287,  288,  289,  267,  266,  257,  300,
  301,  302,  303,  304,  305,  306,  267,  267,  323,  267,
  265,  257,  324,  257,  267,  257,  257,  267,  319,  320,
  321,  284,  267,  266,  325,  270,  271,  267,  262,  274,
  275,  276,  277,  278,  279,  280,  267,  282,  283,  267,
  267,  267,    0,  183,  183,  183,  291,  292,  143,  119,
   78,   99,  128,   84,   -1,  300,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  319,  320,  321,  257,   -1,   -1,
  325,   -1,   -1,   -1,   -1,   -1,   -1,  267,   -1,   -1,
  270,  271,   -1,   -1,  274,   -1,  276,  277,  278,  279,
  280,   -1,  282,  283,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,  291,  292,   -1,   -1,   -1,   -1,   -1,  267,   -1,
  300,  270,  271,   -1,   -1,  274,   -1,  276,  277,  278,
  279,  280,   -1,  282,  283,   -1,   -1,   -1,   -1,  319,
  320,  321,  291,  292,   -1,  325,   -1,   -1,   -1,  267,
   -1,  300,  270,  271,   -1,   -1,  274,   -1,  276,  277,
  278,  279,  280,   -1,  282,  283,   -1,   -1,   -1,   -1,
  319,  320,  321,  291,  292,   -1,  325,   -1,   -1,   -1,
  267,   -1,  300,  270,  271,   -1,   -1,  274,   -1,  276,
  277,  278,  279,  280,  281,  282,  283,   -1,  316,   -1,
   -1,  319,  320,  321,  291,  292,   -1,  325,   -1,   -1,
   -1,  267,   -1,  300,  270,  271,   -1,   -1,  274,   -1,
  276,  277,  278,  279,  280,   -1,  282,  283,   -1,   -1,
   -1,   -1,  319,  320,  321,  291,  292,   -1,  325,   -1,
   -1,   -1,  267,   -1,  300,  270,  271,   -1,   -1,  274,
   -1,  276,  277,  278,  279,  280,   -1,  282,  283,   -1,
   -1,   -1,   -1,  319,  320,  321,  291,  292,  324,  325,
   -1,   -1,   -1,  267,   -1,  300,  270,  271,   -1,   -1,
  274,   -1,  276,  277,  278,  279,  280,   -1,  282,  283,
   -1,   -1,   -1,   -1,  319,  320,  321,  291,  292,   -1,
  325,   -1,   -1,   -1,  267,   -1,  300,  270,  271,   -1,
   -1,  274,   -1,  276,  277,  278,  279,  280,   -1,  282,
  283,   -1,   -1,   -1,   -1,  319,  320,  321,  291,  292,
   -1,  325,   -1,   -1,   -1,  267,   -1,  300,  270,  271,
   -1,   -1,  274,   -1,  276,  277,  278,  279,  280,   -1,
  282,  283,   -1,   -1,   -1,   -1,  319,  320,  321,  291,
  292,   -1,  325,   -1,   -1,   -1,  267,   -1,  300,  270,
  271,   -1,   -1,  274,   -1,  276,  277,  278,  279,  280,
   -1,  282,  283,   -1,   -1,   -1,   -1,  319,  320,  321,
  291,  292,   -1,  325,   -1,   -1,   -1,  267,   -1,  300,
  270,  271,   -1,   -1,  274,   -1,  276,  277,  278,  279,
  280,   -1,  282,  283,   -1,   -1,   -1,   -1,  319,  320,
  321,  291,  292,   -1,  325,   -1,   -1,   -1,  267,   -1,
  300,  270,  271,   -1,   -1,  274,   -1,  276,  277,  278,
  279,  280,   -1,  282,  283,   -1,   -1,   -1,   -1,  319,
  320,  321,  291,  292,   -1,  325,   -1,   -1,   -1,   -1,
   -1,  300,  270,  271,   -1,   -1,  274,   -1,  276,  277,
  278,  279,  280,   -1,  282,  283,   -1,   -1,   -1,   -1,
  319,  320,  321,  291,  292,   -1,  325,   -1,   -1,   -1,
   -1,   -1,  300,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,  319,  320,  321,   -1,   -1,   -1,  325,
};
final static short YYFINAL=18;
final static short YYMAXTOKEN=328;
final static String yyname[] = {
"end-of-file",null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,"NUMBER","NL","OPERATOR","PAREN","CARET","QSTRING","BADSTRING",
"COMMA","ID","OBRACE","CBRACE","FORM","TITLE","HORIZONTALBOX","VERTICALBOX",
"HOMOGENEOUS","SPACING","FRAME","BORDERWIDTH","BUTTON","TOGGLEBUTTON",
"CHECKBUTTON","LABEL","WINDOW","TOOLTIP","ENTRY","NOTEBOOK","PAGE",
"TABPOSITION","TOP","BOTTOM","LEFT","RIGHT","RADIOBUTTON","RADIOGROUP","LIST",
"LISTITEM","FRAMESHADOW","SHADOW_IN","SHADOW_OUT","SHADOW_NONE",
"SHADOW_ETCHED_IN","SHADOW_ETCHED_OUT","WIDGET","ONCLICK","ONPRESS","ONRELEASE",
"ONENTER","ONLEAVE","ONTOGGLE","SENSITIZE","INSENSITIZE","SHOW","HIDE",
"TOGGLESENSITIVITY","TOGGLEVISIBILITY","SUBMITFORM","RESETFORM","CANCELFORM",
"JUSTIFY","CENTER","FILL","FILECHOOSER","DIRCHOOSER","TABLE","TABLEDATUM",
"XPADDING","YPADDING","COMBOBOX","COMBOITEM","TRUE","FALSE",
};
final static String yyrule[] = {
"$accept : widgetseries",
"widgetseries : widget",
"widgetseries : widgetseries widget",
"widgets :",
"widgets : widgetseries",
"widget : boxblock",
"widget : frameblock",
"widget : labelblock",
"widget : entryblock",
"widget : buttonblock",
"widget : notebookblock",
"widget : radiogroupblock",
"widget : listblock",
"widget : windowblock",
"widget : widgetinstance",
"widget : filechooser",
"widget : dirchooser",
"widget : tableblock",
"widget : comboboxblock",
"windowblock : window optid OBRACE title borderwidth widgets CBRACE",
"window : WINDOW",
"optid :",
"optid : identifier",
"identifier : ID",
"id : ID",
"id : QSTRING",
"qstring : QSTRING",
"title :",
"title : TITLE qstring",
"widgetinstance : WIDGET ID",
"boxblock : box optid OBRACE spacing borderwidth justify widgets CBRACE",
"box : HORIZONTALBOX",
"box : VERTICALBOX",
"spacing :",
"spacing : SPACING NUMBER",
"justify :",
"justify : JUSTIFY position",
"position : TOP",
"position : BOTTOM",
"position : LEFT",
"position : RIGHT",
"position : CENTER",
"position : FILL",
"frameblock : frame optid OBRACE title widgets CBRACE",
"frame : FRAME",
"borderwidth :",
"borderwidth : BORDERWIDTH NUMBER",
"labelblock : label optid qstring",
"label : LABEL",
"entryblock : entry optid maxlength",
"entry : ENTRY",
"maxlength :",
"maxlength : NUMBER",
"buttonblock : simplebutton",
"buttonblock : complexbutton",
"simplebutton : button optid qstring",
"complexbutton : button optid OBRACE borderwidth tooltip signals widgets CBRACE",
"button : BUTTON",
"button : TOGGLEBUTTON",
"button : CHECKBUTTON",
"signals :",
"signals : signalset",
"signalset : signal",
"signalset : signalset signal",
"signal : event action ID",
"event : ONCLICK",
"event : ONPRESS",
"event : ONRELEASE",
"event : ONENTER",
"event : ONLEAVE",
"event : ONTOGGLE",
"action : SENSITIZE",
"action : INSENSITIZE",
"action : TOGGLESENSITIVITY",
"action : SHOW",
"action : HIDE",
"action : TOGGLEVISIBILITY",
"action : SUBMITFORM",
"action : RESETFORM",
"action : CANCELFORM",
"tooltip :",
"tooltip : TOOLTIP qstring",
"notebookblock : notebook optid OBRACE tabposition pages CBRACE",
"notebook : NOTEBOOK",
"pages : pageblock",
"pages : pages pageblock",
"pageblock : PAGE OBRACE title tooltip container CBRACE",
"container : boxblock",
"container : notebookblock",
"container : frameblock",
"tabposition :",
"tabposition : TABPOSITION TOP",
"tabposition : TABPOSITION BOTTOM",
"tabposition : TABPOSITION LEFT",
"tabposition : TABPOSITION RIGHT",
"radiogroupblock : radiogroup OBRACE radiobuttons CBRACE",
"radiogroup : RADIOGROUP",
"radiobuttons : radiobuttonblock",
"radiobuttons : radiobuttons radiobuttonblock",
"radiobuttonblock : radiobutton optid qstring",
"radiobuttonblock : radiobutton optid OBRACE borderwidth tooltip widgets CBRACE",
"radiobutton : RADIOBUTTON",
"listblock : list optid OBRACE listitems CBRACE",
"list : LIST",
"listitems : listitemblock",
"listitems : listitems listitemblock",
"listitemblock : LISTITEM qstring",
"filechooser : FILECHOOSER qstring",
"dirchooser : DIRCHOOSER qstring",
"tableblock : table optid OBRACE borderwidth tableelements CBRACE",
"table : TABLE NUMBER NUMBER",
"tableelements :",
"tableelements : tabledata",
"tabledata : tabledatumblock",
"tabledata : tabledata tabledatumblock",
"tabledatumblock : tabledatum OBRACE xpad ypad widgets CBRACE",
"tabledatum : TABLEDATUM NUMBER NUMBER NUMBER NUMBER",
"xpad :",
"xpad : XPADDING NUMBER",
"ypad :",
"ypad : YPADDING NUMBER",
"comboboxblock : combobox OBRACE comboitems CBRACE",
"combobox : COMBOBOX ID",
"comboitems : comboitem",
"comboitems : comboitems comboitem",
"comboitem : COMBOITEM qstring",
};

//#line 641 "jmlparser.y"

String ins;
StringTokenizer st;
Yylex lexer;
Stack containerStack;
Hashtable instanceTable;

Font defaultFont = new Font("Dialog", Font.PLAIN, 12);
Font boldFont = new Font("Dialog", Font.BOLD, 12);
Font bigFont = new Font("Dialog", Font.PLAIN, 18);
Font bigBoldFont = new Font("Dialog", Font.BOLD, 18);
Font reallyBigFont = new Font("Dialog", Font.PLAIN, 18);
Font reallyBigBoldFont = new Font("Dialog", Font.BOLD, 24);
Font sansFont = new Font("SansSerif", Font.PLAIN, 12);


void yyerror(String s)
{
  System.out.println("par:"+s);
}

boolean newline;
int yylex()
{
  String s;
  int tok;
  Yytoken token;
    //System.out.print("yylex ");

    try
    {
      token = lexer.yylex();
    }
    catch (IOException e)
    {
      System.out.println(e.getMessage());
      token = null;
    }
    if (token != null)
    {
      //System.out.println("tok:"+token.m_text);
      tok = token.m_index;
      if (token.m_index == NUMBER)
      {
        Integer i;
        i = Integer.valueOf(token.m_text);
        yylval = new jmlparserval(i.intValue());
        return tok;
      }
      if ((token.m_index == OPERATOR) || 
          (token.m_index == NL) ||
          (token.m_index == CARET) ||
          (token.m_index == PAREN))
      {
        return token.m_text.charAt(0);
      }
      else
      {
        yylval = new jmlparserval(token.m_text);
        // System.out.println("Line: "+token.m_line);
        return tok;
      }
    }
    else
    {
      return 0;
    }
}

void dotest()
{
//  BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    System.out.println("Java Markup Language");
    containerStack = new Stack();
    lexer = new Yylex(System.in);
    instanceTable = new Hashtable();
    System.out.println("Done initializing Yylex");
    yyparse();
}

public static void main(String args[])
{
    jmlparser par = new jmlparser(false);
    par.dotest();
}
//#line 701 "jmlparser.java"
//###############################################################
// method: yylexdebug : check lexer state
//###############################################################
void yylexdebug(int state,int ch)
{
String s=null;
  if (ch < 0) ch=0;
  if (ch <= YYMAXTOKEN) //check index bounds
     s = yyname[ch];    //now get it
  if (s==null)
    s = "illegal-symbol";
  debug("state "+state+", reading "+ch+" ("+s+")");
}



//###############################################################
// method: yyparse : parse input and execute indicated items
//###############################################################
int yyparse()
{
int yyn;       //next next thing to do
int yym;       //
int yystate;   //current parsing state from state table
String yys;    //current token string
boolean doaction;
  init_stacks();
  yynerrs = 0;
  yyerrflag = 0;
  yychar = -1;          //impossible char forces a read
  yystate=0;            //initial state
  state_push(yystate);  //save it
  while (true) //until parsing is done, either correctly, or w/error
    {
    doaction=true;
    if (yydebug) debug("loop"); 
    //#### NEXT ACTION (from reduction table)
    for (yyn=yydefred[yystate];yyn==0;yyn=yydefred[yystate])
      {
      if (yydebug) debug("yyn:"+yyn+"  state:"+yystate+"  char:"+yychar);
      if (yychar < 0)      //we want a char?
        {
        yychar = yylex();  //get next token
        //#### ERROR CHECK ####
        if (yychar < 0)    //it it didn't work/error
          {
          yychar = 0;      //change it to default string (no -1!)
          if (yydebug)
            yylexdebug(yystate,yychar);
          }
        }//yychar<0
      yyn = yysindex[yystate];  //get amount to shift by (shift index)
      if ((yyn != 0) && (yyn += yychar) >= 0 &&
          yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
        {
        if (yydebug)
          debug("state "+yystate+", shifting to state "+yytable[yyn]+"");
        //#### NEXT STATE ####
        yystate = yytable[yyn];//we are in a new state
        state_push(yystate);   //save it
        val_push(yylval);      //push our lval as the input for next rule
        yychar = -1;           //since we have 'eaten' a token, say we need another
        if (yyerrflag > 0)     //have we recovered an error?
           --yyerrflag;        //give ourselves credit
        doaction=false;        //but don't process yet
        break;   //quit the yyn=0 loop
        }

    yyn = yyrindex[yystate];  //reduce
    if ((yyn !=0 ) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
      {   //we reduced!
      if (yydebug) debug("reduce");
      yyn = yytable[yyn];
      doaction=true; //get ready to execute
      break;         //drop down to actions
      }
    else //ERROR RECOVERY
      {
      if (yyerrflag==0)
        {
        yyerror("syntax error");
        yynerrs++;
        }
      if (yyerrflag < 3) //low error count?
        {
        yyerrflag = 3;
        while (true)   //do until break
          {
          if (stateptr<0)   //check for under & overflow here
            {
            yyerror("stack underflow. aborting...");  //note lower case 's'
            return 1;
            }
          yyn = yysindex[state_peek(0)];
          if ((yyn != 0) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
            if (yydebug)
              debug("state "+state_peek(0)+", error recovery shifting to state "+yytable[yyn]+" ");
            yystate = yytable[yyn];
            state_push(yystate);
            val_push(yylval);
            doaction=false;
            break;
            }
          else
            {
            if (yydebug)
              debug("error recovery discarding state "+state_peek(0)+" ");
            if (stateptr<0)   //check for under & overflow here
              {
              yyerror("Stack underflow. aborting...");  //capital 'S'
              return 1;
              }
            state_pop();
            val_pop();
            }
          }
        }
      else            //discard this token
        {
        if (yychar == 0)
          return 1; //yyabort
        if (yydebug)
          {
          yys = null;
          if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
          if (yys == null) yys = "illegal-symbol";
          debug("state "+yystate+", error recovery discards token "+yychar+" ("+yys+")");
          }
        yychar = -1;  //read another
        }
      }//end error recovery
    }//yyn=0 loop
    if (!doaction)   //any reason not to proceed?
      continue;      //skip action
    yym = yylen[yyn];          //get count of terminals on rhs
    if (yydebug)
      debug("state "+yystate+", reducing "+yym+" by rule "+yyn+" ("+yyrule[yyn]+")");
    yyval = val_peek(yym-1);   //get current semantic value
    switch(yyn)
      {
//########## USER-SUPPLIED ACTIONS ##########
case 1:
//#line 72 "jmlparser.y"
{ if ( (val_peek(0).obj != null) && (!containerStack.empty()) )
               {
                 Component widget = (Component)val_peek(0).obj;
                 System.out.println("Found widgetseries");
                 widget.setVisible(true);
                 
                 Class c = val_peek(0).obj.getClass();
                 String s = c.getName();
                 System.out.println("Adding component "+s);
                 Container container = (Container)containerStack.peek();
                 container.add(widget); 
               }
             }
break;
case 2:
//#line 87 "jmlparser.y"
{ if ( (val_peek(0).obj != null) && (!containerStack.empty()) )
               {
                 Component widget = (Component)val_peek(0).obj;
                 System.out.println("Found widgetseries widget");
                 widget.setVisible(true);
                 
                 Class c = val_peek(0).obj.getClass();
                 String s = c.getName();
                 System.out.println("Adding component "+s);
                 Container container = (Container)containerStack.peek();
                 container.add(widget); 
               }
             }
break;
case 19:
//#line 123 "jmlparser.y"
{ 
                       JBorderFrame frame = (JBorderFrame)val_peek(6).obj;
                       System.out.println("Found windowblock");
                       frame.setTitle(val_peek(3).sval);
                       if (val_peek(3) != null)
                         frame.setBorderSize(val_peek(2).ival);
                       containerStack.pop();
                       frame.pack();
                       frame.setVisible(true);
                       yyval.obj = frame;
                     }
break;
case 20:
//#line 136 "jmlparser.y"
{ 
                       JBorderFrame frame = new JBorderFrame();
                       frame.addWindowListener(new WindowAdapter() 
                           {
                             public void windowClosing(WindowEvent e)
                             { 
                               System.exit(0);
                             }
                           });
                       frame.getContentPane().setLayout(new BorderLayout());
                       /*frame.setSize(400, 350);*/
                       containerStack.push(frame.getContentPane());
                       yyval.obj = frame;
                     }
break;
case 21:
//#line 152 "jmlparser.y"
{ yyval = null; }
break;
case 23:
//#line 156 "jmlparser.y"
{ 
                      Component c = (Component)containerStack.peek();
                      if (instanceTable.get(val_peek(0).sval) == null)
                         instanceTable.put(val_peek(0).sval, c);
                      else
                         System.out.println("Duplicate identifier " + val_peek(0).sval);
                      yyval.sval = val_peek(0).sval; 
                   }
break;
case 24:
//#line 165 "jmlparser.y"
{ yyval.sval = val_peek(0).sval; }
break;
case 25:
//#line 166 "jmlparser.y"
{ 
                     System.out.println(
                      "Error: Unquoted string required, but quoted found.");
                     yyval = val_peek(0);  /* use it anyway */
                   }
break;
case 26:
//#line 172 "jmlparser.y"
{ yyval.sval = val_peek(0).sval; }
break;
case 27:
//#line 174 "jmlparser.y"
{ yyval = null; }
break;
case 28:
//#line 175 "jmlparser.y"
{ yyval.sval = val_peek(0).sval; }
break;
case 29:
//#line 178 "jmlparser.y"
{ 
                             System.out.println("Found widgetinstance "+val_peek(0).sval);
                             Component widget;
                             widget = (Component)instanceTable.get(val_peek(0).sval);
                             if (widget == null) {
                                System.out.println("Widget not found "+val_peek(0).sval);
                                yyval.obj = null;
                             }
                             else
                                yyval.obj = widget;
                           }
break;
case 30:
//#line 191 "jmlparser.y"
{
                 int gap;
                 Orientation o;
                 int justify;
                 JPanel box = (JPanel)val_peek(7).obj; 
                 System.out.println("borderwidth = " + val_peek(3).ival);
                 if (val_peek(3).ival != 0) {
                   Border emptyBorder = 
                     new EmptyBorder(val_peek(3).ival,val_peek(3).ival,val_peek(3).ival,val_peek(3).ival);
                   box.setBorder(emptyBorder);
                 }
                 Class c = box.getLayout().getClass();
                 String s = c.getName();
                 System.out.println("Box Layout type "+s);

                 if (val_peek(4) != null)
                    gap = val_peek(4).ival;
                 else
                    gap = 0;

                 if (val_peek(2) != null)
                    o = (Orientation)val_peek(2).obj;
                 else 
                    o = Orientation.CENTER;

                 if (s.equals("RowLayout"))
                    box.setLayout(new RowLayout(o, Orientation.FILL, gap));
                 else
                    box.setLayout(new ColumnLayout(Orientation.FILL, o, gap));
                 box.validate();
                 containerStack.pop();
               }
break;
case 31:
//#line 224 "jmlparser.y"
{ 
                           JPanel hbox = new JPanel();
                           LayoutManager mgr = new RowLayout(0); 
                           hbox.setLayout(mgr);
                           containerStack.push(hbox);
                           hbox.setOpaque(false);
                           System.out.println("Created HorizontalBox");
                           yyval.obj = hbox;
                         }
break;
case 32:
//#line 233 "jmlparser.y"
{
                           JPanel vbox = new JPanel();
                           LayoutManager mgr = new ColumnLayout(0);
                           vbox.setLayout(mgr);
                           containerStack.push(vbox);
                           vbox.setOpaque(false);
                           System.out.println("Created VerticalBox");
                           yyval.obj = vbox;
                          }
break;
case 33:
//#line 243 "jmlparser.y"
{ yyval = null; }
break;
case 34:
//#line 244 "jmlparser.y"
{ yyval.ival = val_peek(0).ival; }
break;
case 35:
//#line 247 "jmlparser.y"
{ yyval = null; }
break;
case 36:
//#line 248 "jmlparser.y"
{ yyval.obj = val_peek(0).obj; }
break;
case 37:
//#line 250 "jmlparser.y"
{ yyval.obj = Orientation.TOP; }
break;
case 38:
//#line 251 "jmlparser.y"
{ yyval.obj = Orientation.BOTTOM; }
break;
case 39:
//#line 252 "jmlparser.y"
{ yyval.obj = Orientation.LEFT; }
break;
case 40:
//#line 253 "jmlparser.y"
{ yyval.obj = Orientation.RIGHT; }
break;
case 41:
//#line 254 "jmlparser.y"
{ yyval.obj = Orientation.CENTER; }
break;
case 42:
//#line 255 "jmlparser.y"
{ yyval.obj = Orientation.FILL; }
break;
case 43:
//#line 258 "jmlparser.y"
{ 
                  JPanel titledPanel = (JPanel)val_peek(5).obj;
                  Border titledBorder = new TitledBorder(null, val_peek(2).sval,
                                            TitledBorder.LEFT, TitledBorder.TOP,
                                            null);
                  Border emptyBorder = new EmptyBorder(15,15,15,15);
                  Border compoundBorder = new CompoundBorder( titledBorder, 
                                                              emptyBorder);
                  /*titledPanel.setBorder(compoundBorder);*/
                  titledPanel.setBorder(titledBorder);

                  containerStack.pop();
                }
break;
case 44:
//#line 272 "jmlparser.y"
{ 
                     JPanel titledPanel = new JPanel();
                     titledPanel.setLayout(new RowLayout(Orientation.FILL, Orientation.FILL, 0));
                     containerStack.push(titledPanel);
                     yyval.obj = titledPanel;
                   }
break;
case 45:
//#line 279 "jmlparser.y"
{ yyval = new jmlparserval(0);; }
break;
case 46:
//#line 280 "jmlparser.y"
{ yyval.ival = val_peek(0).ival; }
break;
case 47:
//#line 283 "jmlparser.y"
{ 
                              JLabel label = (JLabel)containerStack.pop();
                              label.setFont(boldFont);
                              label.setText(val_peek(0).sval);
                              yyval.obj = label;
                            }
break;
case 48:
//#line 290 "jmlparser.y"
{ 
                     JLabel label = new JLabel();
                     label.setFont(boldFont);
                     containerStack.push(label);
                   }
break;
case 49:
//#line 297 "jmlparser.y"
{
                          JTextField tf = (JTextField)containerStack.pop();
                          tf.setColumns(val_peek(0).ival);
                          yyval.obj = tf;
                        }
break;
case 50:
//#line 303 "jmlparser.y"
{ 
                JTextField tf = new JTextField("");
                /*JLabel l = new JLabel("TF Label");*/
                /*l.setLabelFor(tf);*/
                containerStack.push(tf);
              }
break;
case 51:
//#line 310 "jmlparser.y"
{ yyval = new jmlparserval(10); }
break;
case 52:
//#line 311 "jmlparser.y"
{ yyval.ival = val_peek(0).ival; }
break;
case 55:
//#line 317 "jmlparser.y"
{
                                 AbstractButton b = (AbstractButton)val_peek(2).obj;
                                 /*b.setMargin(new Insets(2,4,2,4));*/
                                 b.setText(val_peek(0).sval);
                                 containerStack.pop();
                                 yyval.obj = val_peek(2).obj;
                               }
break;
case 56:
//#line 326 "jmlparser.y"
{ 
                      System.out.println("Found complex buttonblock");
                      JComponent button = (JComponent)val_peek(7).obj;
                      if (val_peek(3) != null)
                        button.setToolTipText(val_peek(3).sval);
                      containerStack.pop();
                      yyval.obj = val_peek(7).obj;
                    }
break;
case 57:
//#line 335 "jmlparser.y"
{ 
                              JButton button = new JButton();
                              button.setMargin(new Insets(0,0,0,0));
                              containerStack.push(button);
                              yyval.obj = button;
                            }
break;
case 58:
//#line 341 "jmlparser.y"
{ 
                              JToggleButton button = new JToggleButton();
                              button.setMargin(new Insets(0,0,0,0));
                              button.setLayout(new RowLayout(Orientation.CENTER,
                                                      Orientation.CENTER, 5));
                              containerStack.push(button);
                              yyval.obj = button;
                            }
break;
case 59:
//#line 349 "jmlparser.y"
{
                              JCheckBox button = new JCheckBox();
                              button.setMargin(new Insets(0,14,0,0));
                              containerStack.push(button);
                              yyval.obj = button;
                            }
break;
case 64:
//#line 365 "jmlparser.y"
{
                    Component component = (Component)containerStack.peek();
                    Component target = (Component)instanceTable.get(val_peek(0).sval);
                    
                    if (target == null)
                       System.out.println("Widget "+val_peek(0).sval+" not defined");
                    else {
                       MouseEventHandler handler = 
                           new MouseEventHandler(val_peek(2).ival, val_peek(1).ival, target);
                       component.addMouseListener(handler);
                    }
                  }
break;
case 65:
//#line 378 "jmlparser.y"
{ yyval.ival = MouseEventHandler.ONCLICK; }
break;
case 66:
//#line 379 "jmlparser.y"
{ yyval.ival = MouseEventHandler.ONPRESS; }
break;
case 67:
//#line 380 "jmlparser.y"
{ yyval.ival = MouseEventHandler.ONRELEASE; }
break;
case 68:
//#line 381 "jmlparser.y"
{ yyval.ival = MouseEventHandler.ONENTER; }
break;
case 69:
//#line 382 "jmlparser.y"
{ yyval.ival = MouseEventHandler.ONLEAVE; }
break;
case 70:
//#line 383 "jmlparser.y"
{ yyval.ival = MouseEventHandler.ONCLICK; }
break;
case 71:
//#line 386 "jmlparser.y"
{ yyval.ival = MouseEventHandler.SENSITIZE; }
break;
case 72:
//#line 387 "jmlparser.y"
{ yyval.ival = MouseEventHandler.INSENSITIZE; }
break;
case 73:
//#line 388 "jmlparser.y"
{ yyval.ival = MouseEventHandler.TOGGLESENSITIVITY; }
break;
case 74:
//#line 389 "jmlparser.y"
{ yyval.ival = MouseEventHandler.SHOW; }
break;
case 75:
//#line 390 "jmlparser.y"
{ yyval.ival = MouseEventHandler.HIDE; }
break;
case 76:
//#line 391 "jmlparser.y"
{ yyval.ival = MouseEventHandler.TOGGLEVISIBILITY; }
break;
case 77:
//#line 392 "jmlparser.y"
{ yyval.ival = MouseEventHandler.SENSITIZE; }
break;
case 78:
//#line 393 "jmlparser.y"
{ yyval.ival = MouseEventHandler.SENSITIZE; }
break;
case 79:
//#line 394 "jmlparser.y"
{ yyval.ival = MouseEventHandler.SENSITIZE; }
break;
case 80:
//#line 398 "jmlparser.y"
{ yyval = null; }
break;
case 81:
//#line 399 "jmlparser.y"
{ yyval.sval = val_peek(0).sval; }
break;
case 82:
//#line 402 "jmlparser.y"
{ 
                       containerStack.pop();
                       yyval.obj = val_peek(5).obj;
                     }
break;
case 83:
//#line 407 "jmlparser.y"
{
                          JTabbedPane tabs = new JTabbedPane();
                          containerStack.push(tabs);
                          yyval.obj = tabs;
                        }
break;
case 86:
//#line 417 "jmlparser.y"
{ 
            JTabbedPane tabs = (JTabbedPane)containerStack.peek();
            Container container = (Container)val_peek(1).obj;
            if (val_peek(2) != null) 
               tabs.addTab(val_peek(3).sval, null, container, val_peek(2).sval);
            else
               tabs.addTab(val_peek(3).sval, null, container);
          }
break;
case 87:
//#line 426 "jmlparser.y"
{ yyval.obj = val_peek(0).obj; }
break;
case 88:
//#line 427 "jmlparser.y"
{ yyval.obj = val_peek(0).obj; }
break;
case 89:
//#line 428 "jmlparser.y"
{ yyval.obj = val_peek(0).obj; }
break;
case 90:
//#line 430 "jmlparser.y"
{ }
break;
case 91:
//#line 431 "jmlparser.y"
{ }
break;
case 92:
//#line 432 "jmlparser.y"
{ }
break;
case 93:
//#line 433 "jmlparser.y"
{ }
break;
case 94:
//#line 434 "jmlparser.y"
{ }
break;
case 95:
//#line 437 "jmlparser.y"
{ 
                      System.out.println("Found radiogroupblock");
                      containerStack.pop();
                      yyval.obj = null;
                    }
break;
case 96:
//#line 443 "jmlparser.y"
{ 
                             System.out.println("Found radiogroup");
                             ButtonGroup radioGroup = new ButtonGroup();
                             containerStack.push(radioGroup);
                             yyval.obj = radioGroup;
                           }
break;
case 97:
//#line 452 "jmlparser.y"
{
                   ButtonGroup radioGroup = (ButtonGroup)containerStack.peek(); 
                   JRadioButton radioButton = (JRadioButton)val_peek(0).obj; 
                   radioGroup.add(radioButton);
                 }
break;
case 98:
//#line 458 "jmlparser.y"
{
                   ButtonGroup radioGroup = (ButtonGroup)containerStack.peek(); 
                   JRadioButton radioButton = (JRadioButton)val_peek(0).obj; 
                   radioGroup.add(radioButton);
                 }
break;
case 99:
//#line 466 "jmlparser.y"
{ 
               JRadioButton radioButton = (JRadioButton)containerStack.pop();  
               radioButton.setText(val_peek(0).sval);
               ButtonGroup group = (ButtonGroup)containerStack.pop();
               Container container = (Container)containerStack.peek();
               containerStack.push(group);
               container.add(radioButton); 
               yyval.obj = radioButton;
             }
break;
case 100:
//#line 477 "jmlparser.y"
{
               containerStack.pop();
               JRadioButton radioButton = (JRadioButton)val_peek(6).obj; 
               radioButton.setMargin(new Insets(0,9,0,0));
               ButtonGroup group = (ButtonGroup)containerStack.pop();
               Container container = (Container)containerStack.peek();
               containerStack.push(group);
               container.add(radioButton); 
               if (val_peek(2) != null)
                 radioButton.setToolTipText(val_peek(2).sval);
               yyval.obj = radioButton;
             }
break;
case 101:
//#line 492 "jmlparser.y"
{
                      JRadioButton radioButton = new JRadioButton();
                      containerStack.push(radioButton);
                      yyval.obj = radioButton;
                    }
break;
case 102:
//#line 500 "jmlparser.y"
{
                  JScrollPane scrollPane = (JScrollPane)containerStack.pop();
                  containerStack.pop();
                  yyval.obj = scrollPane;
                }
break;
case 103:
//#line 506 "jmlparser.y"
{
                 DefaultListModel model = new DefaultListModel();
                 containerStack.push(model);
                 JList listBox = new JList();
                 listBox.setModel(model);
                 JScrollPane scrollPane = new JScrollPane(listBox);
                 containerStack.push(scrollPane);
                 yyval.obj = model;
               }
break;
case 106:
//#line 521 "jmlparser.y"
{
               String label = new String(val_peek(0).sval);
               JScrollPane scrollPane = (JScrollPane)containerStack.pop();
               DefaultListModel model = (DefaultListModel)containerStack.peek();
               containerStack.push(scrollPane);
               model.addElement(label);
             }
break;
case 107:
//#line 530 "jmlparser.y"
{
               JFileChooser chooser = new JFileChooser(new File(val_peek(0).sval)); 
               yyval.obj = chooser;
             }
break;
case 108:
//#line 536 "jmlparser.y"
{
               /*JDirectoryPane dir = new JDirectoryPane(new File($2.sval)); */
               /*$$.obj = dir;*/
             }
break;
case 109:
//#line 542 "jmlparser.y"
{
                 JPanel table = (JPanel)val_peek(5).obj;
                 if (val_peek(4) != null) {
                   Border emptyBorder =
                     new EmptyBorder(val_peek(4).ival,val_peek(4).ival,val_peek(4).ival,val_peek(4).ival);
                   table.setBorder(emptyBorder);
                 }
                 System.out.println("Found tableblock");
                 containerStack.pop();
                 containerStack.pop();
               }
break;
case 110:
//#line 555 "jmlparser.y"
{
                  System.out.println("Found table");
                  JPanel table = new JPanel();
                  GridBagLayout mgr = new GridBagLayout();
                  table.setLayout(mgr);
                  containerStack.push(mgr);
                  containerStack.push(table);
                  table.setOpaque(false);
                  yyval.obj = table;
               }
break;
case 115:
//#line 575 "jmlparser.y"
{
                  GridBagConstraints gbc = (GridBagConstraints)val_peek(5).obj;
                  /*Seems like these two ought to work, but do not*/
                  /*gbc.ipadx = $3.ival;*/
                  /*gbc.ipady = $4.ival;*/
                  Insets inset = new Insets(val_peek(2).ival,val_peek(3).ival,val_peek(2).ival,val_peek(3).ival);
                  gbc.insets = inset;
                  Component c = (Component)containerStack.pop();
                  GridBagLayout gbl = (GridBagLayout)containerStack.peek();
                  containerStack.push(c);
                  gbl.setConstraints((Component)val_peek(1).obj, gbc);
               }
break;
case 116:
//#line 589 "jmlparser.y"
{
                  int left, right, top, bottom;
                  left = val_peek(3).ival;
                  right = val_peek(2).ival;
                  top = val_peek(1).ival;
                  bottom = val_peek(0).ival;
                  GridBagConstraints gbc = new GridBagConstraints();
                  gbc.gridx = left;
                  gbc.gridy = top;
                  gbc.gridwidth = right - left;
                  gbc.gridheight = bottom - top;
                  gbc.fill = GridBagConstraints.BOTH;
                  yyval.obj = gbc;
               }
break;
case 117:
//#line 605 "jmlparser.y"
{ yyval = new jmlparserval(0); }
break;
case 118:
//#line 606 "jmlparser.y"
{ yyval.ival = val_peek(0).ival; }
break;
case 119:
//#line 608 "jmlparser.y"
{ yyval = new jmlparserval(0); }
break;
case 120:
//#line 609 "jmlparser.y"
{ yyval.ival = val_peek(0).ival; }
break;
case 121:
//#line 613 "jmlparser.y"
{
                         containerStack.pop();
                         yyval.obj = val_peek(3).obj;
                      }
break;
case 122:
//#line 619 "jmlparser.y"
{   
                          JComboBox combobox = new JComboBox();
                          containerStack.push(combobox);
                          if (instanceTable.get(val_peek(0).sval) == null)
                             instanceTable.put(val_peek(0).sval, combobox);
                          else
                             System.out.println( "Duplicate ID " + val_peek(0).sval);
                          yyval.obj = combobox;
                       }
break;
case 125:
//#line 634 "jmlparser.y"
{ 
                            JComboBox cb = (JComboBox)containerStack.peek();
                            cb.addItem(val_peek(0).sval);
                         }
break;
//#line 1537 "jmlparser.java"
//########## END OF USER-SUPPLIED ACTIONS ##########
    }//switch
    //#### Now let's reduce... ####
    if (yydebug) debug("reduce");
    state_drop(yym);             //we just reduced yylen states
    yystate = state_peek(0);     //get new state
    val_drop(yym);               //corresponding value drop
    yym = yylhs[yyn];            //select next TERMINAL(on lhs)
    if (yystate == 0 && yym == 0)//done? 'rest' state and at first TERMINAL
      {
      debug("After reduction, shifting from state 0 to state "+YYFINAL+"");
      yystate = YYFINAL;         //explicitly say we're done
      state_push(YYFINAL);       //and save it
      val_push(yyval);           //also save the semantic value of parsing
      if (yychar < 0)            //we want another character?
        {
        yychar = yylex();        //get next character
        if (yychar<0) yychar=0;  //clean, if necessary
        if (yydebug)
          yylexdebug(yystate,yychar);
        }
      if (yychar == 0)          //Good exit (if lex returns 0 ;-)
         break;                 //quit the loop--all DONE
      }//if yystate
    else                        //else not done yet
      {                         //get next state and push, for next yydefred[]
      yyn = yygindex[yym];      //find out where to go
      if ((yyn != 0) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn]; //get new state
      else
        yystate = yydgoto[yym]; //else go to new defred
      debug("after reduction, shifting from state "+state_peek(0)+" to state "+yystate+"");
      state_push(yystate);     //going again, so push state & val...
      val_push(yyval);         //for next action
      }
    }//main loop
  return 0;//yyaccept!!
}
//## end of method parse() ######################################



//## run() --- for Thread #######################################
public void run()
{
   yyparse();
}
//## end of method run() ########################################



//## Constructor ################################################
public jmlparser()
{
}

public jmlparser(boolean debug_me)
{
  yydebug=debug_me;
}
//###############################################################



}
//################### END OF CLASS yaccpar ######################
