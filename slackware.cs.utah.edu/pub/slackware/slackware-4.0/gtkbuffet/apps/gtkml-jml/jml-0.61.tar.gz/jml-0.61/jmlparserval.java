

//########## SEMANTIC VALUES ##########
public class jmlparserval
{
public int ival;
public double dval;
public String sval;
public Object obj;
public jmlparserval(int val)
{
  ival=val;
}
public jmlparserval(double val)
{
  dval=val;
}
public jmlparserval(String val)
{
  sval=val;
}
public jmlparserval(Object val)
{
  obj=val;
}
}//end class
