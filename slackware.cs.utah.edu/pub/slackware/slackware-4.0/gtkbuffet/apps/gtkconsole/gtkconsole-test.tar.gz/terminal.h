#include <gtk/gtk.h>

#include "gtkconsole.h"

GtkWidget *R_gtk_terminal_text;
GtkWidget *R_gtk_terminal_status_bar;
gint R_gtk_terminal_status_cid;


void R_gtk_terminal_new();

/* R system dependent functions */


