#include "terminal-menu.h"

void R_gtk_terminal_menu_quit(GtkWidget *widget, 
			      gpointer data)
{
  gtk_main_quit();
}

static GtkMenuEntry menu_items[] =
{
  {"<Main>/File/Open...", "<control>O", NULL, NULL},
  {"<Main>/File/Save as...", NULL, NULL, NULL},
  {"<Main>/File/<separator>", NULL, NULL, NULL},
  {"<Main>/File/Quit", "<control>X", R_gtk_terminal_menu_quit, NULL},
  {"<Main>/Tools/Options", NULL, NULL, NULL},
  {"<Main>/Window/Change", NULL, NULL, NULL},
  {"<Main>/Help/About...", NULL, NULL, NULL}
};


void R_gtk_terminal_add_menu(GtkWidget *window, GtkWidget **menubar)
{
  gint nmenu_items;
  GtkMenuFactory *factory, *subfactory;

  nmenu_items = sizeof(menu_items) / sizeof(menu_items[0]);

  factory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);
  subfactory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);

  gtk_menu_factory_add_subfactory(factory, subfactory, "<Main>");
  gtk_menu_factory_add_entries(factory, menu_items, nmenu_items);
  gtk_window_add_accel_group(GTK_WINDOW(window), subfactory->accel_group);

  if(menubar)
    *menubar = subfactory->widget;
}
