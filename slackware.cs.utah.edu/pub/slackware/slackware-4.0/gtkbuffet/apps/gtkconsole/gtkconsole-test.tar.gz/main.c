#include <gtk/gtk.h>

#include "terminal.h"

int main(int argc, char *argv[])
{
  gtk_init(&argc, &argv);

  R_gtk_terminal_new();

  gtk_main();

  return 0;
}
