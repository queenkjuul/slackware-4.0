#include "terminal-toolbar.h"

#include "pixmaps/exit.xpm"

void R_gtk_terminaltb_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
  gtk_main_quit();
}

void R_gtk_terminal_toolbar_additems(GtkWidget *toolbar, GtkWidget *window)
{
  GdkPixmap *icon;
  GdkBitmap *mask;
  GtkWidget *iconw;

  icon = gdk_pixmap_create_from_xpm_d (window->window, &mask, &window->style->white, exit_xpm);

  iconw = gtk_pixmap_new(icon, mask);


  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "Quit",
			  "Quit R",
			  NULL,
			  iconw,
			  GTK_SIGNAL_FUNC(R_gtk_terminaltb_delete_event),
			  NULL);
}


