#include "terminal.h"
#include "terminal-toolbar.h"
#include "terminal-menu.h"

void R_WriteConsole(char *buf, int len)
{
  /*
    - disable input
    - change font to output font
    - append buf to end of text box
   */
}

void R_ReadConsole(char *prompt, char *buf, int len, int addtohistory)
{
  /*
    - change font to output font
    - append the prompt to end of text box
    - move cursor to end of text box
    - change font to input font
    - enable input
   */
}

/* File handling code identical to Unix */

/* Integrate some of the stuff from main(): eg arg processing */

void R_CleanUp(int ask)
{
    if(ask == 1) {
    /* display a dialog asking whether to save the workspace */
  }
    /*
      KillAllDevices();

#ifdef __FreeBSD__
  fpsetmask(~0);
#endif

#ifdef linux
  __setfpucw(_FPU_DEFAULT);
#endif

gtk_main_quit(); */
}




/* ************************************************
   GTK+ general stuff
************************************************ */

/*
  If a window delete event happens, quit the application.
*/
void R_gtk_terminal_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
  gtk_main_quit();
}


/*
  Catch cursor movement in the console window
*/
void R_gtk_terminal_cursor_move_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
  printf("Cursor moved\n");
}

void R_gtk_terminal_line_event(GtkWidget *widget)
{
  gchar buf[256];

  gtk_console_disable_input(GTK_CONSOLE(widget));
  gtk_console_read(GTK_CONSOLE(widget), buf, 256);
  gtk_console_write(GTK_CONSOLE(widget), "bash: ", strlen("bash: "));
  gtk_console_write(GTK_CONSOLE(widget), buf, strlen(buf) - 1); // print input with newline stripped
  gtk_console_write(GTK_CONSOLE(widget), ": command not found\n", strlen(": command not found\n"));
  gtk_console_enable_input(GTK_CONSOLE(R_gtk_terminal_text), "[lyndon@localhost]$ ", strlen("[lyndon@localhost]$ "));
}


/*
  Create and display an R terminal window.

  Assumes that there will only be one R terminal per application.
*/
void R_gtk_terminal_new()
{
  GtkWidget *window;
  GtkWidget *vbox;
  GtkWidget *menubar;
  GtkWidget *handlebox;
  GtkWidget *toolbar;
  GtkWidget *table;
  GtkWidget *vscrollbar;


  // Setup main window
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  gtk_window_set_title(GTK_WINDOW(window), "R console");
  gtk_widget_set_usize(window, 600, 500);
  gtk_window_set_policy(GTK_WINDOW(window), TRUE, TRUE, FALSE);
  gtk_container_border_width(GTK_CONTAINER(window), 0);


  // Setup a vbox
  // Could adjust either of the following numbers to change spacing
  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(window), vbox);
  gtk_widget_show(vbox);


  // Add the menubar
  R_gtk_terminal_add_menu(window, &menubar);
  gtk_box_pack_start(GTK_BOX(vbox), menubar, FALSE, TRUE, 0);
  gtk_widget_show(menubar);


  // Add a handlebox & toolbar
  handlebox = gtk_handle_box_new();
  gtk_box_pack_start(GTK_BOX(vbox), handlebox, FALSE, TRUE, 0);
  
  toolbar = gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
  gtk_container_border_width(GTK_CONTAINER(toolbar), 5);
  gtk_toolbar_set_space_size(GTK_TOOLBAR(toolbar), 5);

  gtk_container_add(GTK_CONTAINER(handlebox), toolbar);

  // Add the toolbar items
  gtk_widget_realize(window);
  R_gtk_terminal_toolbar_additems(toolbar, window);

  // Show the toolbar
  gtk_widget_show(toolbar);
  gtk_widget_show(handlebox);


  // Setup table
  // This table controls the layout of the text widget and its
  // associated scrollbar.
  table = gtk_table_new(1, 2, FALSE);
  gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
  gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
  gtk_widget_show (table);
  

  // Create the the text widget
  R_gtk_terminal_text = gtk_console_new (NULL, NULL);
  gtk_text_set_editable (GTK_TEXT (R_gtk_terminal_text), TRUE);
  gtk_table_attach (GTK_TABLE (table), R_gtk_terminal_text, 0, 1, 0, 1,
		    GTK_EXPAND | GTK_SHRINK | GTK_FILL,
		    GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_show (R_gtk_terminal_text);

  // Add a vertical scrollbar to the GtkText widget
  vscrollbar = gtk_vscrollbar_new (GTK_TEXT (R_gtk_terminal_text)->vadj);
  gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
		    GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_show (vscrollbar);


  // Add a status bar to the bottom of the window
  R_gtk_terminal_status_bar = gtk_statusbar_new();
  gtk_box_pack_start(GTK_BOX(vbox), R_gtk_terminal_status_bar, FALSE, TRUE, 0);
  gtk_widget_show(R_gtk_terminal_status_bar);
  R_gtk_terminal_status_cid = gtk_statusbar_get_context_id(GTK_STATUSBAR(R_gtk_terminal_status_bar), "Terminal status bar");


  // Add signal handlers
  gtk_signal_connect(GTK_OBJECT(window), "delete_event", GTK_SIGNAL_FUNC(R_gtk_terminal_delete_event), NULL);
  gtk_signal_connect(GTK_OBJECT(R_gtk_terminal_text), "console_line_ready", GTK_SIGNAL_FUNC(R_gtk_terminal_line_event), NULL);

  //  gtk_signal_connect(GTK_OBJECT(toolbar), "move_cursor", GTK_SIGNAL_FUNC(R_gtk_terminal_cursor_move_event), NULL);


  // Show the window
  gtk_widget_show(window);

  gtk_console_write(GTK_CONSOLE(R_gtk_terminal_text), "Welcome to the funky GtkConsole demo\n", strlen("Welcome to the funky GtkConsole demo\n"));
  gtk_console_enable_input(GTK_CONSOLE(R_gtk_terminal_text), "[lyndon@localhost]$ ", strlen("[lyndon@localhost]$ "));

  // finish up
  return;
}
