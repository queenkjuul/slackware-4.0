#include <gtk/gtk.h>

void R_gtk_terminal_add_menu(GtkWidget *window, GtkWidget **menubar);

