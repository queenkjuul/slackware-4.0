/* guichooser-0.1.0
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */

#include <gtk/gtk.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <getopt.h>

/* increase this if you have more than 32 window managers */
#define MAX_CHOICES 32


void usage(){
  printf("usage: ");
  printf("guichooser [-d {<wmscript>,quit}] [-w sec]\n");
  printf("       guichooser -h\n");
  printf("-d --default=<wmscript>  set wmscript as default\n");
  printf("-w --wait=sec  wait sec seconds before starting default\n");
  printf("-h --help      print this message\n");
  exit(1);
}

void findargs(int argc, char *argv[], int *run_delay, char **run_default){

  static struct option long_options[] = {
    {"default", 1, 0, 'd'},
    {"wait", 1, 0, 'w'},
    {"help", 0, 0, 'h'},
    {0, 0, 0, 0}
  };
  int longindex;
  int option;


  while( (option=getopt_long (argc, argv,"d:fw:h",
			      long_options,&longindex)) != EOF){
    switch(option){
    case 'd':
      *run_default=optarg;
      break;
    case 'w':
      *run_delay=atoi(optarg);
      break;
    case '?':
    case ':':
    case 'h':
      usage();
      exit(1);
    }
  }
  return;
}



int fileselect(struct dirent *entry){
  if(entry->d_name[0] == '.')
    return 0;
  else 
    return 1;
}

/* get choices from directory */
int getdir(char choices[][80]){
  char dirpath[256];
  int count, i;
  struct dirent **files;
  
  strcpy(dirpath,getenv("HOME"));
  strcat(dirpath,"/.guichooser/");
   
  count=scandir(dirpath,&files,fileselect,0);

  /* look in some installation dirs */
  if(count <= 0){
    if(system("cp -R /usr/local/share/guichooser/scripts $HOME/.guichooser"))
      if(system("cp -R /usr/X11R6/share/guichooser/scripts $HOME/.guichooser"))
	system("cp -R /usr/share/guichooser/scripts $HOME/.guichooser");
    count=scandir(dirpath,&files,fileselect,0);
  }
   
  if(count <= 0)
    return count;

  if(count > MAX_CHOICES)
    count = MAX_CHOICES;

  for (i=0;i<count;i++)
    strcpy(choices[i],files[i]->d_name);
  return count;
}

void do_choice(char *choice){
  char execpath[256];

  if(!strcmp(choice,"quit")){
    exit(1);
  }

  strcpy(execpath,getenv("HOME"));
  strcat(execpath,"/.guichooser/");
  strcat(execpath,choice);
  printf("\nrunning %s\n",choice); 

  execl(execpath,choice,0);
  printf("\ncan not exec\n");
  return;
}

gint do_default(gpointer run_default){
  do_choice((char *)run_default);
  return 1;
}

/* a callback */
void set_choice(GtkWidget *widget, gpointer script){
  alarm(0);
  do_choice((char *)script);
  return;
}


/* another callback */
void destroy (GtkWidget *widget, GdkEvent *event, gpointer something){
  gtk_main_quit ();
  return;
}



int main(int argc, char *argv[]){


  
  GtkWidget *box1;
  GtkWidget *button;
  GtkWidget *window;
  char *run_default=NULL;
  
  char choices[MAX_CHOICES][80];
  int count, i;
  int run_delay=0;
  
 
  gtk_init (&argc, &argv);

  findargs(argc, argv, &run_delay, &run_default);

  
  /* create a new window */
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  

  gtk_window_set_title (GTK_WINDOW (window), "gui chooser");
    
  
  /* sets the border width of the window. */
  gtk_container_border_width (GTK_CONTAINER (window), 10);

  /* we create a box to pack widgets into.  this is described in detail
   * in the "packing" section below.  The box is not really visible, it
   * is just used as a tool to arrange widgets. */
  box1 = gtk_vbox_new(FALSE, 0);
  
  /* put the box into the main window. */
  gtk_container_add (GTK_CONTAINER (window), box1);
  
  /* get the script names and create buttons */
  count=getdir(choices);
  for(i=0;i<count;i++){
    button = gtk_button_new_with_label (choices[i]);
    gtk_signal_connect (GTK_OBJECT (button), "clicked",
			GTK_SIGNAL_FUNC (set_choice), 
			(gpointer) choices[i]);
    
    
    gtk_box_pack_start(GTK_BOX(box1), button, TRUE, TRUE, 10);
    gtk_widget_show(button);
  }
  
  /* make a quit button */
  button = gtk_button_new_with_label (" Quit X ");
  
  
  gtk_signal_connect (GTK_OBJECT (button), "clicked",
		      GTK_SIGNAL_FUNC (set_choice),
		      (gpointer) "quit");

  
  
  
  gtk_signal_connect_object (GTK_OBJECT (window), "delete_event",
			     GTK_SIGNAL_FUNC (gtk_widget_destroy),
			     GTK_OBJECT (window));
  
  
  gtk_signal_connect (GTK_OBJECT (window), "destroy",
		      GTK_SIGNAL_FUNC (destroy), NULL);
  
  
  
  gtk_box_pack_start(GTK_BOX(box1), button, TRUE, TRUE, 10);
  gtk_widget_show(button);
  
  
  
  gtk_widget_show(box1);

  gtk_window_position (GTK_WINDOW (window),GTK_WIN_POS_CENTER);
  
  gtk_widget_show (window);
  
  

  if(run_default){
    if(run_delay)
      gtk_timeout_add(run_delay * 1000,do_default,run_default);
    
    else 
      do_choice(run_default);
    
  }
  gtk_main ();
  
 return 0;
}
/* example-end */

