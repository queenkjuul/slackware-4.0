//Network_Player.h

//This software may be used like stated in the GNU General Public License
//Written by Peter �sterlund -99 (peter.osterlund@mailbox.swipnet.se)

//A network player, communicating with another instance of this program.

#ifndef NETWORK_PLAYER_H
#define NETWORK_PLAYER_H

#include "Player.h"

#define BUFLEN 1024

class Network_Player: public Player
{
public:

    Network_Player(int , Square **, GtkWidget *, othello *);

    // To tell the player it is his turn
    void your_turn();

    // It is no longer your turn
    void end_turn();

    // Virtual in superclass
    void turn_no_ok();

    //Your opponent played 'sqr'
    virtual void opponent_played(int sqr);

    // Player configuration. Should call place->configure_complete() when
    // configuration is complete
    virtual void configure();

private:

    void server_connect(int port);
    static void accept_ready_s(gpointer data, gint fd, GdkInputCondition condition);
    void accept_ready();

    void client_connect(const char* host, int port);
    static void connect_ready_s(gpointer data, gint fd, GdkInputCondition condition);
    void connect_ready();
    const char* dns_lookup(const char* host) const;

    void check_connection();

    static void sock_read_s(gpointer data, gint fd, GdkInputCondition condition);
    void sock_read();
    void configure_complete();

    void queue_output(const char* buffer);
    static void sock_write_s(gpointer data, gint fd, GdkInputCondition condition);
    void sock_write();

    void connect_abort(const char* msg);
    static gint connect_abort_idle_s(gpointer data);
    gint connect_abort_idle();

    void set_message(const char* msg);


    void button_clicked(GtkWidget *widget);
    static gint delete_event(GtkWidget *widget, GdkEventAny* event, gpointer *data);
    static void button_clicked_s(GtkWidget *widget, gpointer *data);

    GtkWidget* create_window1();
    GtkWidget* get_widget(GtkWidget* widget, gchar* widget_name) const;


    GtkWidget* config_win;
    int status_id;
    int sockfd;

    enum Connection_State { NONE, SERVER, CLIENT, CHECK, CONNECTED };
    Connection_State connection_state;
    int connect_tag;
    int read_tag;
    int write_tag;

    char inbuf[BUFLEN];
    char outbuf[BUFLEN];
};

#endif //NETWORK_PLAYER_H
