//playertype.cc

//This software may be used like stated in the GNU General Public License
//Written by Peter �sterlund -99 (peter.osterlund@mailbox.swipnet.se)

#include "playertype.h"

Player_Types* Player_Types::theInstance_ = 0;

// ---------------

Player_Creator::Player_Creator(int pri, const char* name)
    : pri_(pri)
{
    strncpy(name_, name, MAX_PLAYER_NAME_LEN);
    name_[MAX_PLAYER_NAME_LEN - 1] = 0;

    Player_Types::instance().registerPlayerType(this);
}

// ---------------

Player_Types& Player_Types::instance()
{
    if (!theInstance_)
	theInstance_ = new Player_Types;

    return *theInstance_;
}

void Player_Types::registerPlayerType(Player_Creator* pc)
{
    vector<Player_Creator*>::iterator i = playerCreators.begin();

    while (i != playerCreators.end()) {
	if ((*i)->priority() > pc->priority())
	    break;
	++i;
    }
    playerCreators.insert(i, pc);
}

int Player_Types::numTypes() const
{
    return playerCreators.size();
}

const char* Player_Types::playerName(int type) const
{
    return getCreator(type)->name();
}

Player* Player_Types::createPlayer(int type, int w, Square **b, GtkWidget *ev, othello *func)
{
    return getCreator(type)->createPlayer(w, b, ev, func);
}

Player_Creator* Player_Types::getCreator(int type) const
{
    if ((type >= 0) && (type < numTypes()))
	return playerCreators[type];
    else
	return NULL;
}
