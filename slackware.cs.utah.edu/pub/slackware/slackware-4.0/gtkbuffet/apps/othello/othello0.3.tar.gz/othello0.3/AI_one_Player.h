//AI_one_Player.h 

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//An AI player

#ifndef AI_ONE_PLAYER_H
#define AI_ONE_PLAYER_H

#include "Player.h"

class AI_one_Player: public Player
{  

public:

  AI_one_Player(int , Square **, GtkWidget *, othello *);
  
  //To tell the player it is his turn
  void your_turn();
  
  //It is no longer your turn
  void end_turn();

  //Virtual i superclass
  void turn_no_ok();

private:
    static gint cal(AI_one_Player *);

    //To calculate a move
    gint cal_move();

};


#endif //AI_ONE_PLAYER_H
