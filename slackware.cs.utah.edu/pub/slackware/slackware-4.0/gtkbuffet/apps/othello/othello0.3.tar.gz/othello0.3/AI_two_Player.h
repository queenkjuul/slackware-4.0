//AI_two_Player.h

//This software may be used like stated in the GNU General Public License
//Written by Peter �sterlund -99 (peter.osterlund@mailbox.swipnet.se)

//An AI player

#ifndef AI_TWO_PLAYER_H
#define AI_TWO_PLAYER_H

#include "Player.h"

class AI_two_Player: public Player
{
public:

    AI_two_Player(int , Square **, GtkWidget *, othello *);

    // To tell the player it is his turn
    void your_turn();

    // It is no longer your turn
    void end_turn();

    // Virtual in superclass
    void turn_no_ok();

    // Player configuration. Should call place->configure_complete() when configuration
    // is complete
    void configure();


private:
    static gint config_abort_s(GtkWidget *widget, GdkEventAny* event, gpointer *data);
    static void config_done_s(GtkWidget *widget, gpointer *data);
    void config_done(GtkWidget *widget);

    static gint cal(AI_two_Player *);

    //To calculate a move
    int cal_move();

    // -------

    typedef unsigned char UBYTE;
    typedef UBYTE BoardType[10][16];

    void findMove(BoardType board, int& x, int& y, int player);
    int search(BoardType board, int oldscore, int player, 
	       int alpha, int beta, 
	       int ply, int depth, bool pass = false);
    int numFlip(BoardType board, int x, int y, int player);
    void flip(BoardType board, int x, int y, int player);
    int sumBricks(BoardType board, int player);
    int rankMove(BoardType board, int x, int y, int num);

    void moveBoard(BoardType from, BoardType to);


    int Combs;

    int antal;
    int nflip[8];
    int xstart[64], ystart[64];

    int fh, fhGood;

    GtkWidget* win_dialog;
    GtkObject* adj;
    double thinking_time;
};

#endif //AI_TWO_PLAYER_H
