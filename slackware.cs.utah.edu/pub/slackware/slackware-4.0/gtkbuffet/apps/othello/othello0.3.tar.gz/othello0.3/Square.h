//Square.h

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//One square on the playing board

#ifndef SQUARE_H
#define SQUARE_H

#include <gtk/gtk.h>


class Square
{
  //My own coordinates on the board
  int x; 
  int y;

  //Empty, White or Black?
  int state;

  //The adjoining squares
  Square *adjoining[8];

  //Setting an adjoining link
  void set_link(int, Square *);

  //Check possible flipps in one direction
  virtual int flipp_check(int i, int col, bool reallyflip);

  //A widget cointain a square
  GtkWidget *my_square;


  //For the flipping animation
  int start;
  int stop;

  //pix
  GdkPixmap **pix;

 public:

  //To do the flipping animation
  gint flip_me();
  
  //constructor
  Square(int, int, Square **);

  //to return the state
  virtual int who();

  //to place a new brick on the board, return how many bricks flipped
  int place(int col);

    // Returns true if placing col on this square is a legal move
    bool legalMove(int col) const;

  //To init some graphic
  virtual int graph_init(GdkPixmap **, GtkTable *);
    

};

#endif //SQUARE_H

