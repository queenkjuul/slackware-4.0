//Border.h

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//One border-square on the playing board

#ifndef BORDER_H
#define BORDER_H

#include "Square.h"

class Border: public Square
{

  int flipp_check(int i, int col, bool reallyflip);

public:

  Border(int, int, Square **);
  int who();
  int graph_init(GdkPixmap **, GtkTable *);

};

#endif //BORDER_H
