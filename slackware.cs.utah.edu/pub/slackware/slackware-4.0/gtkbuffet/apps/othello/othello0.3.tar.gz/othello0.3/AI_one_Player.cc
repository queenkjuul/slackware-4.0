//AI_one_Player.cc

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//An AI player

#include "AI_one_Player.h"
#include "playertype.h"
#include "othello.h"
#include <stdlib.h>
#include <time.h>

AI_one_Player::AI_one_Player(int w, Square **b, GtkWidget *c, othello *d):Player(w, b, c, d)
{
    srandom(time(NULL));
}

void
AI_one_Player::your_turn()
{
  gtk_timeout_add (500, cal, this); //500 if you would like to wait until after the animation
}

gint 
AI_one_Player::cal_move()
{
  //I'm at least unpridictable!!
  int xx = (int) (random() % 8) + 1;  
  int yy = (int) (random() % 8) + 1;

  place->try_move(xx + yy * 10);
  return 0;
}


void
AI_one_Player::end_turn()
{
}

void
AI_one_Player::turn_no_ok()
{
  gtk_idle_add (cal, this);
}

gint 
AI_one_Player::cal(AI_one_Player *me)
{
  return me->cal_move();
}

// ---------------

class AI_one_Creator : public Player_Creator {
public:
    AI_one_Creator() : Player_Creator(1, "AI") {}

    Player* createPlayer(int w, Square **b, GtkWidget *ev, othello *func);
};

Player* AI_one_Creator::createPlayer(int w, Square **b, GtkWidget *ev, othello *func)
{
    return new AI_one_Player(w, b, ev, func);
}

static AI_one_Creator theAIoneCreator;
