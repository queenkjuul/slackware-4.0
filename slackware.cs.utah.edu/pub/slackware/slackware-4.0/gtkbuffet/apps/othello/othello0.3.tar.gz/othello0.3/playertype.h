//playertype.h

//This software may be used like stated in the GNU General Public License
//Written by Peter �sterlund -99 (peter.osterlund@mailbox.swipnet.se)

#include <vector.h>
#include <gtk/gtkwidget.h>

class Player;
class Square;
class othello;

#define MAX_PLAYER_NAME_LEN 16

class Player_Creator
{
public:
    Player_Creator(int pri, const char* name);

    virtual Player* createPlayer(int w, Square **b, GtkWidget *ev, othello *func) = 0;

    int priority() const;
    const char* name() const;

private:
    int pri_;
    char name_[MAX_PLAYER_NAME_LEN];
};

class Player_Types {
public:
    static Player_Types& instance();

    void registerPlayerType(Player_Creator* pc);

    int numTypes() const;
    const char* playerName(int type) const;

    Player* createPlayer(int type, int w, Square **b, GtkWidget *ev, othello *func);

private:
    Player_Types() {};

    Player_Creator* getCreator(int type) const;

    static Player_Types* theInstance_;

    vector<Player_Creator*> playerCreators;
};


inline int Player_Creator::priority() const
{
    return pri_;
}

inline const char* Player_Creator::name() const
{
    return name_;
}
