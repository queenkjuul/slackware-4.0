//othello.cc

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

#include "othello.h"
#include "Square.h"
#include "Border.h"
#include "playertype.h"			    //Diffrent Player types

// #include <iostream.h>


static gint swap_pl(gpointer);
static gint same_pl(gpointer d);
static gint start(gpointer);
static gint pl_load(GtkWidget *, gpointer);

othello::othello(int argc, char **argv)
{
  //Initing the GTK graphics
  gtk_init (&argc, &argv);


  main_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_widget_realize (main_window);
  board_table = gtk_table_new (8, 8, 0);
  main_box = gtk_vbox_new (0,1);
  button_box = gtk_hbox_new (0,1);
  event_box = gtk_event_box_new();


  menu_bar = gtk_menu_bar_new();
  game_menu = gtk_menu_new();
  game_quit = gtk_menu_item_new_with_label("Quit");
  game_button = gtk_menu_item_new_with_label("Game");

  //Loading the images
  //Change to imlib

  pix[0] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/empty.xpm" );
  pix[1] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0001.xpm" );
  pix[2] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0002.xpm" );
  pix[3] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0003.xpm" );
  pix[4] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0004.xpm" );
  pix[5] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0005.xpm" );
  pix[6] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0006.xpm" );
  pix[7] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0007.xpm" );
  pix[8] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0008.xpm" );
  pix[9] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0009.xpm" );
  pix[10] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0010.xpm" );


  //Create the board

  int tmp_x;
  int tmp_y;
  for (int i = 0; i < 100; i++)
    {
    tmp_x = i % 10;
    tmp_y = (i - (i % 10)) / 10;
    if ((tmp_x < 1) || (tmp_y < 1) || (tmp_y > 8) || (tmp_x > 8))
      {
	board[tmp_x + (10 * tmp_y)] = new Border(tmp_x, tmp_y, board);
      }
    else
      {
	board[tmp_x + (10 * tmp_y)] = new Square(tmp_x, tmp_y, board);
      }


    board[tmp_x + (10 * tmp_y)]->graph_init(pix, GTK_TABLE(board_table));


    }



  //initing the score-trakers
  white = 2;
  black = 2;


  char str[16];
  sprintf(str, "White: %02d", white);
  w_score = gtk_label_new (str);
  sprintf(str, "Black: %02d", black);
  b_score = gtk_label_new (str);
  turn = gtk_label_new ("Turn: White");


  //Creating the players
  pick_players(argv, argc);


  gtk_main();
}

//Initing the main window
void othello::init_main()
{
  gtk_menu_append( GTK_MENU(game_menu), game_quit);
  gtk_menu_item_set_submenu( GTK_MENU_ITEM(game_button), game_menu);
  gtk_menu_bar_append( GTK_MENU_BAR(menu_bar), game_button );

  //binding some events
  gtk_signal_connect_object ( GTK_OBJECT(game_quit), "activate", GTK_SIGNAL_FUNC(gtk_main_quit), NULL);
  gtk_signal_connect (GTK_OBJECT (main_window), "delete_event", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);

  //Showing the windows
  gtk_container_border_width (GTK_CONTAINER (main_window), 0);
  gtk_container_border_width (GTK_CONTAINER (event_box), 5);
  gtk_container_border_width (GTK_CONTAINER (button_box), 5);


  gtk_box_pack_start (GTK_BOX (button_box), w_score, 1, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (button_box), turn, 1, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (button_box), b_score, 1, TRUE, 0);
  gtk_container_add  (GTK_CONTAINER (event_box), board_table);
  gtk_box_pack_start (GTK_BOX(main_box), menu_bar, 0, 0, 1);
  gtk_box_pack_start (GTK_BOX (main_box), event_box, 0, 0, 1);
  gtk_box_pack_start (GTK_BOX (main_box), button_box, 0, 0, 1);

  gtk_container_add (GTK_CONTAINER (main_window), main_box);
  gtk_widget_show(turn);
  gtk_widget_show(game_button);
  gtk_widget_show(game_quit);
  gtk_widget_show(menu_bar);
  gtk_widget_show(w_score);
  gtk_widget_show(b_score);
  gtk_widget_show(button_box);
  gtk_widget_show(board_table);
  gtk_widget_show(event_box);
  gtk_widget_show(main_box);
  gtk_widget_show( main_window );


  gtk_idle_add(start, this);

}


void othello::quit (GtkWidget *widget, gpointer data)
{
  gtk_main_quit ();
}


static gint start (gpointer data)
{

  othello *me = (othello *) data;
  //telling the first player to go
  me->col = 1;
  me->player[0]->your_turn();
  return 0;
}


static gint pl_load (GtkWidget *widget, gpointer data)
{
    othello *me = (othello *) data;
    me->load_pl();
    return 0;
}


void othello::end_game()
{
  win_dialog = gtk_dialog_new ();
  GtkWidget *button = gtk_button_new_with_label ("Quit");
  GtkWidget *label3;
  GtkWidget *sep1 = gtk_hseparator_new ();

  if (white > black)
    {
      label3 = gtk_label_new ("The winner is: White");
    }
  else if (white < black)
    {
      label3 = gtk_label_new ("The winner is: Black");
    }
  else
    {
      label3 = gtk_label_new ("No winner");
    }


  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (win_dialog)->vbox), label3, 0, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (win_dialog)->vbox), sep1, 0, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (win_dialog)->action_area), button, TRUE, TRUE, 0);


  gtk_window_set_title (GTK_WINDOW (win_dialog), "Game over");

  //bindings
  gtk_signal_connect (GTK_OBJECT (win_dialog), "delete_event", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);

  //Showing it

  gtk_container_border_width(GTK_CONTAINER (GTK_DIALOG (win_dialog)->vbox), 5);
  gtk_widget_show(button);
  gtk_widget_show(label3);
  gtk_widget_show(sep1);

  gtk_container_border_width (GTK_CONTAINER (win_dialog), 5);
  gtk_widget_show(win_dialog);

}


void
othello::load_pl()
{
  gtk_widget_hide(dialog);

  for (int i = 0; i < 2; i++) {
      GSList *test = gtk_radio_button_group(GTK_RADIO_BUTTON (plist[i]));
      Player_Types& pTypes = Player_Types::instance();
      for (int pt = pTypes.numTypes(); pt > 0; pt--) {
	  if ((GTK_RADIO_BUTTON(test->data)->check_button).toggle_button.active) {
	      player[i] = pTypes.createPlayer(pt - 1, i + 1, board, event_box, this);
	      break;
	  }
	  test = test->next;
      }
  }
  //  cout << (((GTK_RADIO_BUTTON((gtk_radio_button_group(GTK_RADIO_BUTTON (plist[0]))->next->next)->data))->check_button).toggle_button.active);

  configure_players(true);
}

void
othello::configure_complete(int who)
{
    if (player_configured[who - 1] != 2) {
	player_configured[who - 1] = 2;
	configure_players();
    }
}

void
othello::configure_players(bool start)
{
    if (start) {
	// Set both players to "not configured"
	for (int i = 0; i < 2; i++) {
	    player_configured[i] = 0;
	}
    }

    // Send configure request if not already done
    bool sent = false;
    for (int i = 0; i < 2; i++) {
	if (player_configured[i] == 0) {
	    player_configured[i] = 1;
	    player[i]->configure();
	    sent = true;
	}
    }
    if (sent)
	return;

    // Wait until both players are configured
    for (int i = 0; i < 2; i++) {
	if (player_configured[i] != 2)
	    return;
    }

    // Start game
    init_main();
}

void
othello::pick_players(char **argv, int argc)
{
  dialog = gtk_dialog_new ();
  GtkWidget *button = gtk_button_new_with_label ("OK");

  GtkWidget *listbox;
  GtkWidget *label[2];
  GtkWidget *pbox[2];
  GtkWidget *sep[2];

  for (int i = 0; i < 2; i++) {
      char buf[32];
      sprintf(buf, "Player %d", i + 1);
      label[i] = gtk_label_new(buf);

      sep[i] = gtk_hseparator_new();

      pbox[i] = gtk_vbox_new (0,1);

      gtk_box_pack_start (GTK_BOX (pbox[i]), label[i], 0, TRUE, 0);
      gtk_box_pack_start (GTK_BOX (pbox[i]), sep[i], 0, TRUE, 0);

      plist[i] = 0;
      Player_Types& pTypes = Player_Types::instance();
      for (int pt = 0; pt < pTypes.numTypes(); pt++) {
	  plist[i] = gtk_radio_button_new_with_label((plist[i] ?
						      gtk_radio_button_group (GTK_RADIO_BUTTON (plist[i])) :
						      NULL),
						     pTypes.playerName(pt));
	  gtk_widget_show(plist[i]);
	  gtk_box_pack_start (GTK_BOX (pbox[i]), plist[i], 0, TRUE, 0);
      }
  }

  listbox = gtk_hbox_new (0,1);

  for (int i = 0; i < 2; i++) {
      gtk_box_pack_start (GTK_BOX (listbox), pbox[i], 0, TRUE, 0);
  }

  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), listbox, 0, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area), button, TRUE, TRUE, 0);


  gtk_window_set_title (GTK_WINDOW (dialog), "Pick your players");

  //bindings
  gtk_signal_connect (GTK_OBJECT (dialog), "delete_event", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (pl_load), this);


  //Showing it
  gtk_widget_show(button);

  for (int i = 0; i < 2; i++) {
      gtk_widget_show(label[i]);
      gtk_widget_show(sep[i]);
      gtk_container_border_width (GTK_CONTAINER (pbox[i]), 5);
      gtk_widget_show(pbox[i]);
  }

  gtk_container_border_width (GTK_CONTAINER (listbox), 5);
  gtk_widget_show(listbox);
  gtk_container_border_width (GTK_CONTAINER (dialog), 5);
  gtk_widget_show(dialog);

}

bool othello::legalMoves(int col) const
{
    for (int x = 1; x <= 8; x++) {
	for (int y = 1; y <= 8; y++) {
	    if (board[x + 10 * y]->legalMove(col)) {
		return true;
	    }
	}
    }
    return false;
}

void othello::try_move (int sqr)
{
  int tmp = board[sqr]->place(col);

  if (tmp)
    {
      if (col == 1)
	{
	  white += tmp + 1;
	  black -= tmp;
	}
      else
	{
	  black += tmp + 1;
	  white -= tmp;
	}

      char str[16];
      sprintf(str, "White: %02d", white);
      gtk_label_set (GTK_LABEL(w_score), str);
      sprintf(str, "Black: %02d", black);
      gtk_label_set (GTK_LABEL(b_score), str);

      int othercol = (col % 2) + 1;

      player[othercol - 1]->opponent_played(sqr);

      if (legalMoves(othercol)) {
	  col = othercol;
	  gtk_idle_add(swap_pl, this);
      } else if (legalMoves(col)) {
	  gtk_idle_add(same_pl, this);
      } else {
	  end_game();
      }

      gtk_label_set(GTK_LABEL(turn), (col == 1) ? "Turn: White" : "Turn: Black");
    }
  else
    {
	player[col - 1]->turn_no_ok();
    }
}

static gint swap_pl(gpointer d)
{
  othello *me = (othello *) d;

  int c = me->col - 1;

  me->player[1 - c]->end_turn();
  me->player[c]->your_turn();

  //To stop the loop
  return 0;
}

static gint same_pl(gpointer d)
{
  othello *me = (othello *) d;

  int c = me->col - 1;

  me->player[c]->end_turn();
  me->player[c]->your_turn();

  //To stop the loop
  return 0;
}

void othello::process_events()
{
    while (gtk_events_pending())
	if (gtk_main_iteration() != 0)
	    exit(0);
}

int
main(int argc, char **argv)
{
    (void) new othello(argc, argv);
}
