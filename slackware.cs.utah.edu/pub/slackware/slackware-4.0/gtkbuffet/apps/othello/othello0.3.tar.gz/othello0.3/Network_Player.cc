//Network_Player.cc

//This software may be used like stated in the GNU General Public License
//Written by Peter �sterlund -99 (peter.osterlund@mailbox.swipnet.se)

//A network player, communicating with another instance of this program.

#include "Network_Player.h"
#include "playertype.h"
#include "othello.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <netdb.h>
#include <string.h>
#include <signal.h>

#define PROTOCOL_VERSION 1


void sighan(int)
{
    assert(0);
}

Network_Player::Network_Player(int w, Square **b, GtkWidget *c, othello *d)
    : Player(w, b, c, d)
{
    sockfd = -1;
    connect_tag = -1;
    read_tag = -1;
    write_tag = -1;
    inbuf[0] = 0;
    outbuf[0] = 0;

    signal(SIGBUS, sighan);
}

void
Network_Player::your_turn()
{
    assert(connection_state == CONNECTED);

    assert(read_tag == -1);
    read_tag = gdk_input_add(sockfd, GDK_INPUT_READ,
			     (GdkInputFunction)sock_read_s, this);
}

void
Network_Player::end_turn()
{
}

void
Network_Player::turn_no_ok()
{
    // Peer is cheating.
    assert(0);
}

void
Network_Player::opponent_played(int sqr)
{
    assert(connection_state == CONNECTED);

    int xx = sqr % 10;
    int yy = sqr / 10;

    char buffer[32];
    sprintf(buffer, "%d %d\n", xx, yy);

    queue_output(buffer);
}

void
Network_Player::configure()
{
    connection_state = NONE;

    config_win = create_window1();

    char buf[32];
    sprintf(buf, "Network player %d", who);
    gtk_window_set_title (GTK_WINDOW (config_win), buf);

    GtkWidget* tmp = get_widget(config_win, "statusbar");
    status_id = gtk_statusbar_get_context_id(GTK_STATUSBAR(tmp), "default");
    gtk_statusbar_push(GTK_STATUSBAR(tmp), status_id, "");

    gtk_widget_show(config_win);
}

void
Network_Player::server_connect(int port)
{
    connection_state = SERVER;

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	connect_abort(strerror(errno));
	return;
    }

    int tmp = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &tmp, sizeof(int)) < 0) {
	connect_abort(strerror(errno));
	return;
    }

    struct sockaddr_in serv_addr;
    bzero(&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
	connect_abort(strerror(errno));
	return;
    }

    listen(sockfd, 1);

    assert(connect_tag == -1);
    connect_tag = gdk_input_add(sockfd, GDK_INPUT_READ,
				(GdkInputFunction)accept_ready_s, this);
}

void
Network_Player::accept_ready_s(gpointer data, gint fd, GdkInputCondition condition)
{
    Network_Player* me = (Network_Player*) data;
    me->accept_ready();
}

void
Network_Player::accept_ready()
{
    gdk_input_remove(connect_tag);
    connect_tag = -1;

    struct sockaddr_in cli_addr;
    socklen_t clilen = sizeof(cli_addr);
    int newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
    if (newsockfd < 0) {
	connect_abort(strerror(errno));
	return;
    }
    close(sockfd);
    sockfd = newsockfd;

    // Set non-blocking mode
    int statusFlags = fcntl(sockfd, F_GETFL);
    if (statusFlags == -1) {
	connect_abort(strerror(errno));
	return;
    }
    statusFlags |= O_NONBLOCK;
    if (fcntl(sockfd, F_SETFL, statusFlags) < 0) {
	connect_abort(strerror(errno));
	return;
    }

    check_connection();
}

void
Network_Player::client_connect(const char* host, int port)
{
    connection_state = CLIENT;

    host = dns_lookup(host);

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	connect_abort(strerror(errno));
	return;
    }

    // Set non-blocking mode
    int statusFlags = fcntl(sockfd, F_GETFL);
    if (statusFlags == -1) {
	connect_abort(strerror(errno));
	return;
    }
    statusFlags |= O_NONBLOCK;
    if (fcntl(sockfd, F_SETFL, statusFlags) < 0) {
	connect_abort(strerror(errno));
	return;
    }

    // Start asynchronous connection
    struct sockaddr_in serv_addr;
    bzero(&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    serv_addr.sin_addr.s_addr = inet_addr(host);
    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
	if (errno != EINPROGRESS) {
	    connect_abort(strerror(errno));
	    return;
	}
    }

    assert(connect_tag == -1);
    connect_tag = gdk_input_add(sockfd, GDK_INPUT_WRITE,
				(GdkInputFunction)connect_ready_s, this);
}

void
Network_Player::connect_ready_s(gpointer data, gint fd, GdkInputCondition condition)
{
    Network_Player* me = (Network_Player*) data;
    me->connect_ready();
}

void
Network_Player::connect_ready()
{
    int value;
    socklen_t len;
    if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &value, &len) < 0) {
	connect_abort(strerror(errno));
	return;
    }
    if (value != 0) {
	connect_abort(strerror(value));
	return;
    }

    gdk_input_remove(connect_tag);
    connect_tag = -1;

    check_connection();
}

const char*
Network_Player::dns_lookup(const char* host) const
{
    struct hostent *h;
    if (((h = gethostbyname(host)) != NULL) && h->h_addr_list[0]) {
	static char buffer[64];
	sprintf(buffer, "%d.%d.%d.%d",
		(unsigned char)h->h_addr_list[0][0],
		(unsigned char)h->h_addr_list[0][1],
		(unsigned char)h->h_addr_list[0][2],
		(unsigned char)h->h_addr_list[0][3]);
	return buffer;
    }
    return host;
}

void
Network_Player::check_connection()
{
    connection_state = CHECK;

    char buffer[64];
    sprintf(buffer, "NWP %d %d\n", PROTOCOL_VERSION, who);
    queue_output(buffer);

    assert(read_tag == -1);
    read_tag = gdk_input_add(sockfd, GDK_INPUT_READ,
			     (GdkInputFunction)sock_read_s, this);
}

void
Network_Player::sock_read_s(gpointer data, gint fd, GdkInputCondition condition)
{
    Network_Player* me = (Network_Player*) data;
    me->sock_read();
}

void
Network_Player::sock_read()
{
    char c;
    int len = read(sockfd, &c, 1);

    if (len < 0) {
	if ((errno != EINTR) && (errno != EAGAIN)) {
	    connect_abort(strerror(errno));
	}
	return;
    }
    if (len == 0) {
	connect_abort("EOF");
	return;
    }

    int buflen = strlen(inbuf);

    if (buflen + 1 >= BUFLEN) {
	connect_abort("output buffer overflow");
	return;
    }

    inbuf[buflen++] = c;
    inbuf[buflen] = 0;

    if (c != '\n')
	return;

    if (connection_state == CHECK) {

	int version = -1;
	int w = -1;

	if ((sscanf(inbuf, "NWP %d %d", &version, &w) != 2) ||
	    (version != PROTOCOL_VERSION)) {
	    connect_abort("Invalid protocol version");
	    return;
	}

	if (w != 3 - who) {
	    connect_abort("Player color mismatch");
	    return;
	}

	inbuf[0] = 0;

	gdk_input_remove(read_tag);
	read_tag = -1;

	configure_complete();

    } else if (connection_state == CONNECTED) {
	int xx = -1;
	int yy = -1;

	if ((sscanf(inbuf, "%d %d", &xx, &yy) != 2) ||
	    (xx < 1) || (xx > 8) || (yy < 1) || (yy > 8)) {
	    connect_abort("Illegal move string");
	    return;
	}

	inbuf[0] = 0;

	gdk_input_remove(read_tag);
	read_tag = -1;

	place->try_move(xx + yy * 10);

    } else {
	assert(0);
    }
}

void
Network_Player::configure_complete()
{
    connection_state = CONNECTED;

    gtk_widget_destroy(config_win);
    place->configure_complete(who);
}

void
Network_Player::queue_output(const char* buffer)
{
    if (strlen(buffer) + strlen(outbuf) >= BUFLEN) {
	connect_abort("output buffer overflow");
	return;
    }

    strcat(outbuf, buffer);

    if ((write_tag == -1) && (strlen(outbuf) > 0)) {
	write_tag = gdk_input_add(sockfd, GDK_INPUT_WRITE,
				  (GdkInputFunction)sock_write_s, this);
    }
}

void
Network_Player::sock_write_s(gpointer data, gint fd, GdkInputCondition condition)
{
    Network_Player* me = (Network_Player*) data;
    me->sock_write();
}

void
Network_Player::sock_write()
{
    int buflen = strlen(outbuf);

    assert(sockfd != -1);
    int writelen = write(sockfd, outbuf, buflen);

    if (writelen < 0) {
	if (errno != EINTR) {
	    connect_abort(strerror(errno));
	}
	return;
    }

    memmove(&outbuf, &outbuf[writelen], strlen(&outbuf[writelen]) + 1);

    if (strlen(outbuf) == 0) {
	assert(write_tag != -1);
	gdk_input_remove(write_tag);
	write_tag = -1;
    }
}

void
Network_Player::connect_abort(const char* msg)
{
    if ((connection_state != CONNECTED) && (connection_state != NONE))
	set_message(msg);

    if (sockfd != -1) {
	close(sockfd);
	sockfd = -1;
    }

    gtk_idle_add(connect_abort_idle_s, this);
}

gint 
Network_Player::connect_abort_idle_s(gpointer data)
{
    Network_Player* me = (Network_Player*) data;
    return me->connect_abort_idle();
}

gint
Network_Player::connect_abort_idle()
{
    if (connect_tag != -1) {
	gdk_input_remove(connect_tag);
	connect_tag = -1;
    }

    if (read_tag != -1) {
	gdk_input_remove(read_tag);
	read_tag = -1;
    }

    if (write_tag != -1) {
	gdk_input_remove(write_tag);
	write_tag = -1;
    }

    inbuf[0] = 0;
    outbuf[0] = 0;

    connection_state = NONE;

    return FALSE;
}

void
Network_Player::set_message(const char* msg)
{
    GtkWidget* tmp = get_widget(config_win, "statusbar");
    gtk_statusbar_pop(GTK_STATUSBAR(tmp), status_id);
    gtk_statusbar_push(GTK_STATUSBAR(tmp), status_id, msg);
}

// ---------------

class Network_Player_Creator : public Player_Creator {
public:
    Network_Player_Creator() : Player_Creator(3, "Network") {}

    Player* createPlayer(int w, Square **b, GtkWidget *ev, othello *func);
};

Player* Network_Player_Creator::createPlayer(int w, Square **b, GtkWidget *ev, othello *func)
{
    return new Network_Player(w, b, ev, func);
}

static Network_Player_Creator theNetworkPlayerCreator;

// ---------------

void
Network_Player::button_clicked(GtkWidget *widget)
{
    if (widget == get_widget(widget, "connect")) {
	if (connection_state == NONE) {
	    set_message("connecting...");
	    GtkWidget* tmp = get_widget(widget, "port");
	    int port = atoi(gtk_entry_get_text(GTK_ENTRY(tmp)));

	    tmp = get_widget(widget, "server");
	    if ((GTK_RADIO_BUTTON(tmp)->check_button).toggle_button.active) {
		server_connect(port);
	    } else {
		tmp = get_widget(widget, "host");
		const char* host = gtk_entry_get_text(GTK_ENTRY(tmp));
		client_connect(host, port);
	    }
	}
    } else if (widget == get_widget(widget, "abort")) {
	if (connection_state != NONE) {
	    connect_abort("Aborted");
	}
    } else {
	assert(0);
    }
}

gint
Network_Player::delete_event(GtkWidget *widget, GdkEventAny* event, gpointer *data)
{
    return TRUE;
}

void
Network_Player::button_clicked_s(GtkWidget *widget, gpointer *data)
{
    Network_Player* me = (Network_Player*) data;

    me->button_clicked(widget);
}

GtkWidget*
Network_Player::create_window1()
{
  GtkWidget *window1;
  GtkWidget *vbox1;
  GtkWidget *frame1;
  GtkWidget *vbox2;
  GSList *group1_group = NULL;
  GtkWidget *server;
  GtkWidget *hbox1;
  GtkWidget *client;
  GtkWidget *host;
  GtkWidget *hbox2;
  GtkWidget *label1;
  GtkWidget *port;
  GtkWidget *hbox3;
  GtkWidget *connect;
  GtkWidget *abort;
  GtkWidget *statusbar;

  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_object_set_data (GTK_OBJECT (window1), "window1", window1);
  gtk_container_border_width (GTK_CONTAINER (window1), 5);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (delete_event),
                      NULL);
  gtk_window_set_policy (GTK_WINDOW (window1), TRUE, TRUE, FALSE);

  vbox1 = gtk_vbox_new (FALSE, 5);
  gtk_object_set_data (GTK_OBJECT (window1), "vbox1", vbox1);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (window1), vbox1);

  frame1 = gtk_frame_new (NULL);
  gtk_object_set_data (GTK_OBJECT (window1), "frame1", frame1);
  gtk_widget_show (frame1);
  gtk_box_pack_start (GTK_BOX (vbox1), frame1, TRUE, TRUE, 0);

  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_object_set_data (GTK_OBJECT (window1), "vbox2", vbox2);
  gtk_widget_show (vbox2);
  gtk_container_add (GTK_CONTAINER (frame1), vbox2);
  gtk_container_border_width (GTK_CONTAINER (vbox2), 2);

  server = gtk_radio_button_new_with_label (group1_group, "Server");
  group1_group = gtk_radio_button_group (GTK_RADIO_BUTTON (server));
  gtk_object_set_data (GTK_OBJECT (window1), "server", server);
  gtk_widget_show (server);
  gtk_box_pack_start (GTK_BOX (vbox2), server, TRUE, TRUE, 0);
  GTK_WIDGET_UNSET_FLAGS (server, GTK_CAN_FOCUS);
  gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (server), TRUE);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_object_set_data (GTK_OBJECT (window1), "hbox1", hbox1);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox1, TRUE, TRUE, 0);

  client = gtk_radio_button_new_with_label (group1_group, "Client");
  group1_group = gtk_radio_button_group (GTK_RADIO_BUTTON (client));
  gtk_object_set_data (GTK_OBJECT (window1), "client", client);
  gtk_widget_show (client);
  gtk_box_pack_start (GTK_BOX (hbox1), client, TRUE, TRUE, 0);
  GTK_WIDGET_UNSET_FLAGS (client, GTK_CAN_FOCUS);

  host = gtk_entry_new_with_max_length (50);
  gtk_object_set_data (GTK_OBJECT (window1), "host", host);
  gtk_widget_show (host);
  gtk_box_pack_start (GTK_BOX (hbox1), host, TRUE, TRUE, 5);
  gtk_widget_grab_focus (host);
  gtk_entry_set_text (GTK_ENTRY (host), "localhost");

  hbox2 = gtk_hbox_new (FALSE, 0);
  gtk_object_set_data (GTK_OBJECT (window1), "hbox2", hbox2);
  gtk_widget_show (hbox2);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox2, TRUE, TRUE, 0);

  label1 = gtk_label_new ("Port:");
  gtk_object_set_data (GTK_OBJECT (window1), "label1", label1);
  gtk_widget_show (label1);
  gtk_box_pack_start (GTK_BOX (hbox2), label1, TRUE, TRUE, 0);
  gtk_label_set_justify (GTK_LABEL (label1), GTK_JUSTIFY_RIGHT);

  port = gtk_entry_new ();
  gtk_object_set_data (GTK_OBJECT (window1), "port", port);
  gtk_widget_show (port);
  gtk_box_pack_start (GTK_BOX (hbox2), port, TRUE, TRUE, 5);
  gtk_entry_set_text (GTK_ENTRY (port), "5055");

  hbox3 = gtk_hbox_new (FALSE, 0);
  gtk_object_set_data (GTK_OBJECT (window1), "hbox3", hbox3);
  gtk_widget_show (hbox3);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox3, TRUE, TRUE, 0);

  connect = gtk_button_new_with_label ("Connect");
  gtk_object_set_data (GTK_OBJECT (window1), "connect", connect);
  gtk_widget_show (connect);
  gtk_box_pack_start (GTK_BOX (hbox3), connect, TRUE, TRUE, 5);
  GTK_WIDGET_UNSET_FLAGS (connect, GTK_CAN_FOCUS);
  gtk_signal_connect (GTK_OBJECT (connect), "clicked",
                      GTK_SIGNAL_FUNC (button_clicked_s),
                      this);

  abort = gtk_button_new_with_label ("Abort");
  gtk_object_set_data (GTK_OBJECT (window1), "abort", abort);
  gtk_widget_show (abort);
  gtk_box_pack_start (GTK_BOX (hbox3), abort, TRUE, TRUE, 5);
  GTK_WIDGET_UNSET_FLAGS (abort, GTK_CAN_FOCUS);
  gtk_signal_connect (GTK_OBJECT (abort), "clicked",
                      GTK_SIGNAL_FUNC (button_clicked_s),
                      this);

  statusbar = gtk_statusbar_new ();
  gtk_object_set_data (GTK_OBJECT (window1), "statusbar", statusbar);
  gtk_widget_show (statusbar);
  gtk_box_pack_start (GTK_BOX (vbox1), statusbar, TRUE, TRUE, 0);

  return window1;
}

GtkWidget*
Network_Player::get_widget(GtkWidget* widget, gchar* widget_name) const
{
  GtkWidget *found_widget;

  if (widget->parent)
    widget = gtk_widget_get_toplevel (widget);
  found_widget = (GtkWidget*) gtk_object_get_data (GTK_OBJECT (widget),
                                                   widget_name);
  assert(found_widget);

  return found_widget;
}
