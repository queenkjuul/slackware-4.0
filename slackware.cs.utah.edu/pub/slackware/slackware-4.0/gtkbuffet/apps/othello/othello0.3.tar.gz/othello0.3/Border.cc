//Border.cc

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//One border-square on the playing board


#include "Border.h"


Border::Border(int xx, int yy, Square **board):Square(xx, yy, board)
{}

//A border i allways empty.
int Border::who()
{
  return 0;
}

int Border::flipp_check(int i, int col, bool reallyflip)
{
  return 0;
}

//A border isn't shown
int Border::graph_init(GdkPixmap **a, GtkTable *b)
{
  return 0;
}
