//AI_two_Player.cc

//This software may be used like stated in the GNU General Public License
//Written by Peter �sterlund -99 (peter.osterlund@mailbox.swipnet.se)

//An AI player

#include "AI_two_Player.h"
#include "playertype.h"
#include "othello.h"
#include "Square.h"
#include <stdlib.h>

// #define DEBUG

AI_two_Player::AI_two_Player(int w, Square **b, GtkWidget *c, othello *d)
    : Player(w, b, c, d),
      thinking_time(0.5)
{
}

void
AI_two_Player::your_turn()
{
    // 500 if you would like to wait until after the animation
    gtk_timeout_add (500, cal, this);
}

int
AI_two_Player::cal_move()
{
    BoardType myboard;

    for (int y = 0; y < 8; y++) {
	for (int x = 0; x < 8; x++) {
	    myboard[x + 1][y + 1] = board[(x + 1) + 10 * (y + 1)]->who();
	}
    }

    int xx;
    int yy;

    findMove(myboard, xx, yy, place->col);

#ifdef DEBUG
    printf("xx:%d yy:%d\n\n", xx, yy);
#endif

    place->try_move(xx + yy * 10);
    return 0;
}

void
AI_two_Player::end_turn()
{
}

void
AI_two_Player::turn_no_ok()
{
    assert(0);
}

void
AI_two_Player::configure()
{
    win_dialog = gtk_dialog_new();

    // Widgets
    GtkWidget* button = gtk_button_new_with_label ("OK");

    GtkWidget* hbox = gtk_hbox_new(FALSE, 10);

    GtkWidget* label = gtk_label_new("Thinking time:");

    adj = gtk_adjustment_new(thinking_time, 0.0, 10.0, 0.1, 0.1, 0.0);
    GtkWidget* scale = gtk_hscale_new(GTK_ADJUSTMENT(adj));

    // Pack
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(hbox), scale, TRUE, TRUE, 0);

    gtk_box_pack_start(GTK_BOX(GTK_DIALOG(win_dialog)->vbox), hbox, FALSE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(GTK_DIALOG(win_dialog)->action_area), button, TRUE, TRUE, 0);

    // Set window title
    char buf[32];
    sprintf(buf, "AI(2) player %d", who);
    gtk_window_set_title(GTK_WINDOW(win_dialog), buf);

    //bindings
    gtk_signal_connect(GTK_OBJECT(win_dialog), "delete_event", GTK_SIGNAL_FUNC(config_abort_s), this);
    gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(config_done_s), this);

    //Show it
    gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(win_dialog)->vbox), 5);
    gtk_widget_show(button);
    gtk_widget_show(hbox);
    gtk_widget_show(label);
    gtk_widget_show(scale);

    gtk_container_border_width(GTK_CONTAINER(win_dialog), 5);
    gtk_widget_show(win_dialog);
}

gint
AI_two_Player::config_abort_s(GtkWidget *widget, GdkEventAny* event, gpointer *data)
{
    AI_two_Player* me = (AI_two_Player*)data;
    me->place->configure_complete(me->who);
    return FALSE;
}

void
AI_two_Player::config_done_s(GtkWidget *widget, gpointer *data)
{
    AI_two_Player* me = (AI_two_Player*) data;
    me->config_done(widget);
}

void
AI_two_Player::config_done(GtkWidget *widget)
{
    thinking_time = GTK_ADJUSTMENT(adj)->value;
    gtk_widget_destroy(win_dialog);
    place->configure_complete(who);
}

gint AI_two_Player::cal(AI_two_Player *me)
{
    return me->cal_move();
}

// ---------------

class AI_two_Creator : public Player_Creator {
public:
    AI_two_Creator() : Player_Creator(2, "AI(2)") {}

    Player* createPlayer(int w, Square **b, GtkWidget *ev, othello *func);
};

Player* AI_two_Creator::createPlayer(int w, Square **b, GtkWidget *ev, othello *func)
{
    return new AI_two_Player(w, b, ev, func);
}

static AI_two_Creator theAItwoCreator;


// ---------------

static int delta[8] = { -16, -15, 1, 17, 16, 15, -1, -17 };


#define WINSCORE  (10000)
#define LOSESCORE (-10000)

void
AI_two_Player::findMove(BoardType board, int& x, int& y, int player)
{
    UBYTE TmpBoard[10][16];
    UBYTE xMoves[64], yMoves[64];

    antal = 0;
    for (int i = 1; i < 9; i++)
	for (int j = 1; j < 9; j++)
	    if (board[i][j])
		antal++;
    for (int i = 0; i < 64; i++) {
	xstart[i] = 1;
	ystart[i] = 1;
    }

    GTimer* gt = g_timer_new();
    g_timer_start(gt);

    int NumMoves = 0;
    int depth = 2;
    Combs = 0;
    do {
#ifdef DEBUG
	printf("depth:%2d\n", depth);
#endif
	int alpha = 2 * LOSESCORE;
	int beta = 2 * WINSCORE;

	fh = fhGood = 0;

	int i, j;
	int NumLeft = 64;
	for (i = xstart[0], j = ystart[0]; NumLeft > 0; NumLeft--) {
	    int num;
	    if ((board[i][j] == 0) && ((num = numFlip(board, i, j, player)) > 0)) {
		moveBoard(board, TmpBoard);
		flip(TmpBoard, i, j, player);
		antal++;

		int tmpscore = rankMove(board, i, j, num);
		int score = -search(TmpBoard, -tmpscore, 3 - player, 
				    -beta, -(alpha-1), 1, depth - 1);
		antal--;

		if (score > alpha) {
		    NumMoves = 0;
		    xstart[0] = i; ystart[0] = j;
		}
		if (score >= alpha) {
		    xMoves[NumMoves] = i;
		    yMoves[NumMoves] = j;
		    NumMoves++;
		    alpha = score;
#ifdef DEBUG
		    printf("(%d,%d) score:%d\n", i, j, alpha);
#endif
		}
	    }
	    j++;
	    if (j > 8) {
		j = 1; i++;
		if (i > 8) i = 1;
	    }
	}
#ifdef DEBUG
	printf("combs:%d fh:%.2f\n", Combs, (double)fhGood / fh);
#endif
	depth++;
    } while ((g_timer_elapsed(gt, NULL) < thinking_time) && (depth + antal <= 64));
    assert(NumMoves > 0);
    int i = random() % NumMoves;
    x = xMoves[i]; y = yMoves[i];

    g_timer_destroy(gt);
}

// Compute score for a position, + is good for 'player' who is to make the
// first move
int
AI_two_Player::search(BoardType board, int oldscore, int player, 
		      int alpha, int beta, 
		      int ply, int depth, bool pass)
{
    int x, y;
    UBYTE TmpBoard[10][16];
    int NumLeft;


    if (depth <= 0)
	return oldscore;

    Combs++;
    if ((Combs & 2047) == 0)
	place->process_events();

    int validMoves = 0;
    for (x = xstart[ply], y = ystart[ply], NumLeft = 64; NumLeft > 0; NumLeft--) {
	int num;
	if ((board[x][y] == 0) && ((num = numFlip(board, x, y, player)) > 0)) {
	    validMoves++;
	    moveBoard(board, TmpBoard);
	    flip(TmpBoard, x, y, player);
	    antal++;
	    if (antal >= 64) {
		antal--; 
		return sumBricks(TmpBoard, player);
	    }

	    int tmpscore = oldscore + rankMove(board, x, y, num);
	    int score = -search(TmpBoard, -tmpscore, 3 - player,
				-beta, -alpha,
				ply + 1, depth - 1);
	    antal--;

	    if (score > alpha) {
		xstart[ply] = x; ystart[ply] = y;
		if (score >= beta) {
		    fh++;
		    if (validMoves == 1)
			fhGood++;
		    return score;
		}
		alpha = score;
	    }
	}
	y++;
	if (y > 8) {
	    y = 1; x++;
	    if (x > 8) x = 1;
	}
    }
    if (!validMoves) {
	if (pass) {
	    // Two passes in a row means game is over
	    return sumBricks(board, player);
	} else {
	    return -search(board, -oldscore, 3 - player, -beta, -alpha,
			   ply + 1, depth, true);
	}
    }
    return alpha;
}

int
AI_two_Player::numFlip(BoardType board, int x, int y, int player)
{
    UBYTE* ptr;
    UBYTE* orgptr = &board[x][y];
    int num = 0;
    for (int i = 7; i >= 0; i--) {
	nflip[i] = 0; x = delta[i];
	ptr = orgptr + x;
	if ( ((*ptr) + player) == 3) {
	    ptr += x; y = 1;
	    while ( ((*ptr) + player) == 3) {
		ptr += x; y++;
	    }
	    if (*ptr == player) {
		num += y; nflip[i] = y;
	    }
	}
    }
    return num;
}

void
AI_two_Player::flip(BoardType board, int x, int y, int player)
{
    UBYTE* ptr;
    UBYTE* orgptr = &board[x][y];
    *orgptr = player;
    for (int i = 7; i >= 0; i--) {
	y = nflip[i]; x = delta[i];
	ptr = orgptr;
	while (y > 0) {
	    ptr += x; *ptr = player;
	    y--;
	}
    }
}

int
AI_two_Player::sumBricks(BoardType board, int player)
{
    UBYTE* ptr = &board[1][1];
    int Score = 0;
    for (int i = 8; i > 0; i--) {
	for (int j = 8; j > 0; j--) {
	    if (*ptr == player) Score++;
	    else if (*ptr) Score--;
	    ptr++;
	}
	ptr += 8;
    }
    if (Score > 0) return(WINSCORE + Score);
    if (Score < 0) return(LOSESCORE + Score);
    return(0);
}

#if 0
#define CORNER 1
#define EDGE1 2
#define EDGE2 3
#define EDGE3 4
#define EDGE4 5
#define SQ11 6
#define SQ71 7
#define SQ77 8
#define SQ17 9

#define CSCORE 100
#define ESCORE 25

int
AI_two_Player::rankMove(BoardType board, int x, int y, int num)
{
    static int SquareType[10][16] = {
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,1,2,2,2,2,2,2,1,0 },
	{ 0,5,6,0,0,0,0,7,3,0 },
	{ 0,5,0,0,0,0,0,0,3,0 },
	{ 0,5,0,0,0,0,0,0,3,0 },
	{ 0,5,0,0,0,0,0,0,3,0 },
	{ 0,5,0,0,0,0,0,0,3,0 },
	{ 0,5,9,0,0,0,0,8,3,0 },
	{ 0,1,4,4,4,4,4,4,1,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
    };

    if (antal >= 55) return( 2*num + 1);
    switch(SquareType[x][y]) {
    case CORNER:
	return( (nflip[0]+nflip[2]+nflip[4]+nflip[6])*
		(2*(ESCORE-1)) + num + num + CSCORE );
    case EDGE1: case EDGE3:
	return( (nflip[2]+nflip[6])*(2*(ESCORE-1)) +
		num + num + ESCORE );
    case EDGE2: case EDGE4:
	return( (nflip[0]+nflip[4])*(2*(ESCORE-1)) +
		num + num + ESCORE );

    case SQ11: if (board[1][1] == 0) return( num * 2 - 50 ); else goto def;
    case SQ71: if (board[8][1] == 0) return( num * 2 - 50 ); else goto def;
    case SQ77: if (board[8][8] == 0) return( num * 2 - 50 ); else goto def;
    case SQ17: if (board[1][8] == 0) return( num * 2 - 50 ); else goto def;
    default: def: return( num * 2 + 1 );
    }
}

#else

#define S11 100
#define S22 -50
#define S21 -15
#define S31 30
#define S41 25
#define S33 3

int
AI_two_Player::rankMove(BoardType board, int x, int y, int num)
{
    switch(8 * x + y - 9) {
    case 0: case 7: case 56: case 63:
	return( (nflip[0]+nflip[2]+nflip[4]+nflip[6]) *
		(2*(S41-1))+num+num+S11 );
    case 1:
	if (board[1][1]) goto horedge;
	else return( (nflip[2]+nflip[6])*(2*(S41-1)) +
		     num+num+S21 );
    case 2:
	if (board[1][1]) goto horedge;
	else return( (nflip[2]+nflip[6])*(2*(S41-1)) +
		     num+num+S31 );
    case 3: case 4: case 59: case 60: horedge:
	return( (nflip[2]+nflip[6])*(2*(S41-1))+num+num+S41 );
    case 5:
	if (board[8][1]) goto horedge;
	else return( (nflip[2]+nflip[6])*(2*(S41-1)) +
		     num+num+S31 );
    case 6:
	if (board[8][1]) goto horedge;
	else return( (nflip[2]+nflip[6])*(2*(S41-1)) +
		     num+num+S21 );
    case 8:
	if (board[1][1]) goto veredge;
	else return( (nflip[0]+nflip[4])*(2*(S41-1)) +
		     num+num+S21 );
    case 9:
	if (board[1][1]) return(2*num + 1); else return(2*num + S22);
    case 14:
	if (board[8][1]) return(2*num + 1); else return(2*num + S22);
    case 15:
	if (board[8][1]) goto veredge;
	else return( (nflip[0]+nflip[4])*(2*(S41-1)) +
		     num+num+S21 );
    case 16:
	if (board[1][1]) goto veredge;
	else return( (nflip[0]+nflip[4])*(2*(S41-1)) +
		     num+num+S31 );
    case 18: case 21: case 42: case 45:
	return(2*num + S33);
    case 23:
	if (board[8][1]) goto veredge;
	else return( (nflip[0]+nflip[4])*(2*(S41-1)) +
		     num+num+S31 );
    case 24: case 31: case 32: case 39: veredge:
	return( (nflip[0]+nflip[4])*(2*(S41-1))+num+num+S41 );
    case 40:
	if (board[1][8]) goto veredge;
	else return( (nflip[0]+nflip[4])*(2*(S41-1)) +
		     num+num+S31 );
    case 47:
	if (board[8][8]) goto veredge;
	else return( (nflip[0]+nflip[4])*(2*(S41-1)) +
		     num+num+S31 );
    case 48:
	if (board[1][8]) goto veredge;
	else return( (nflip[0]+nflip[4])*(2*(S41-1)) +
		     num+num+S21 );
    case 49:
	if (board[1][8]) return(2*num + 1); else return(2*num + S22);
    case 54:
	if (board[8][8]) return(2*num + 1); else return(2*num + S22);
    case 55:
	if (board[8][8]) goto veredge;
	else return( (nflip[0]+nflip[4])*(2*(S41-1)) +
		     num+num+S21 );
    case 57:
	if (board[1][8]) goto horedge;
	else return( (nflip[2]+nflip[6])*(2*(S41-1)) +
		     num+num+S21 );
    case 58:
	if (board[1][8]) goto horedge;
	else return( (nflip[2]+nflip[6])*(2*(S41-1)) +
		     num+num+S31 );
    case 61:
	if (board[8][8]) goto horedge;
	else return( (nflip[2]+nflip[6])*(2*(S41-1)) +
		     num+num+S31 );
    case 62:
	if (board[8][8]) goto horedge;
	else return( (nflip[2]+nflip[6])*(2*(S41-1)) +
		     num+num+S21 );
    case 10: case 11: case 12: case 13:
    case 17: case 19: case 20: case 22:
    case 25: case 26: case 27: case 28: case 29: case 30:
    case 33: case 34: case 35: case 36: case 37: case 38:
    case 41: case 43: case 44: case 46:
    case 50: case 51: case 52: case 53:
	return(2*num + 1);
    }
    assert(0);
}
#endif

void
AI_two_Player::moveBoard(BoardType from, BoardType to)
{
//      printf("sizeof(BoardType) = %d\n", sizeof(BoardType));
    memcpy(to, from, sizeof(BoardType));
}
