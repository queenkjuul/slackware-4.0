//Player.h

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//The player superclass

#ifndef PLAYER_H
#define PLAYER_H

#include <gtk/gtk.h>

class othello;
class Square;


class Player
{

public:

  int who;
  Square **board;
  GtkWidget *event_box;
  othello *place;

  Player(int w, Square **b, GtkWidget *ev, othello *func);

  virtual ~Player() {};

  //To tell the player it is his turn
  virtual void your_turn() = 0;

  //The turn preformed isn't OK, redo it (usefull for AI)
  virtual void turn_no_ok() = 0;

  //It is no longer your turn
  virtual void end_turn() = 0;

  //Your opponent played 'sqr'
  virtual void opponent_played(int sqr);

  // Player configuration. Should call place->configure_complete() when
  // configuration is complete
  virtual void configure();

};

inline Player::Player(int w, Square **b, GtkWidget *ev, othello *func)
{
    who = w;
    board = b; 
    event_box = ev;
    place = func;
}

#endif //PLAYER_H

