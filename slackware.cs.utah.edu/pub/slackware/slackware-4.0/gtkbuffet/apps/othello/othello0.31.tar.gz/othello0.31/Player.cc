#include "Player.h"
#include "othello.h"

void
Player::opponent_played(int sqr)
{
}

void
Player::configure()
{
    place->configure_complete(who);
}
