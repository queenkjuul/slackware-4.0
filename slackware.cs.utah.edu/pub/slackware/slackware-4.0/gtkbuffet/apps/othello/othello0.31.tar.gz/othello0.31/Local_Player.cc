//Local_Player.cc

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//A local player, using the mouse

#include "Local_Player.h"
#include "playertype.h"
#include "othello.h"

//#include <iostream.h>

Local_Player::Local_Player(int w, Square **b, GtkWidget *c, othello *d):Player(w, b, c, d)
{
}

void Local_Player::your_turn()
{
  //  cout << "Player " << who << " signing on\n";
  handler = gtk_signal_connect (GTK_OBJECT(event_box), "button_press_event", (GtkSignalFunc) Local_Player::click, this);
}

void Local_Player::click(GtkWidget *widget, GdkEventButton *ev, Local_Player *me ) 
{
  me->make_move(ev);
}

void 
Local_Player::make_move(GdkEventButton *ev)
{
  int xx = (((int)ev->x - ((int) ev->x % 64)) / 64) + 1;
  int yy = (((int)ev->y - ((int)ev->y % 64)) / 64) + 1;

  place->try_move(xx + yy * 10);
}

void
Local_Player::end_turn()
{
  //  cout << "Player " << who << " signing off\n";
  gtk_signal_disconnect (GTK_OBJECT(event_box), handler);
}

void 
Local_Player::turn_no_ok()
{}

// ---------------

class Local_Player_Creator : public Player_Creator {
public:
    Local_Player_Creator() : Player_Creator(0, "Human") {}

    Player* createPlayer(int w, Square **b, GtkWidget *ev, othello *func);
};

Player* Local_Player_Creator::createPlayer(int w, Square **b, GtkWidget *ev, othello *func)
{
    return new Local_Player(w, b, ev, func);
}

static Local_Player_Creator theLocalPlayerCreator;
