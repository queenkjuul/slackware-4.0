//Square.cc

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//One square on the playing board

#include "Square.h"

gint flipp(Square *);

Square::Square(int xx, int yy, Square **board)
{
  //coordinates
  x = xx;
  y = yy;

  //All squares are empty in the begining
  state = 0;


  
  //creating the adjoining links
  int tmp_x;
  int tmp_y;
  for (int i = 1; i < 5; i++)
    {
        tmp_x = x - 1 + ((i - 1) % 3);
        tmp_y = y - 1 + (i == 4); 
        if((tmp_x >= 0) &&  (tmp_y >= 0) && (tmp_x < 10))
	  {
	    adjoining[i - 1] = board[tmp_x + (tmp_y * 10)]; //setting my adjoining links
	    board[tmp_x + (tmp_y * 10)]->set_link(9 - i, this); //setting me to others adjoining links
	  }
    }
  
  //If I'm one of the squares that have a brick at the start
  //White
  if ((x == 4) && (y == 4))
    {
      state = 1;
    }
    if ((x == 5) && (y == 5))
    {
      state = 1;
    }

    //Black
    if ((x == 4) && (y == 5))
    {
      state = 2;
    }
    if ((x == 5) && (y == 4))
    {
      state = 2;
    }

    start = state;
    stop = 0;

    }

int Square::graph_init(GdkPixmap **pixx, GtkTable *table)
{
  pix = pixx;
  //finding my image
  GdkPixmap *me;
  switch(state)
    {
    case 0:
      me = pix[0];
      break;
      
    case 1:
      me = pix[1];
      break;

    case 2:
      me = pix[10];
      break;
    }

  my_square = gtk_pixmap_new( me, NULL );
  gtk_table_attach (table, my_square, x - 1, x, y - 1, y, 0, 0, 0, 0); 
  gtk_widget_show (my_square);

  return 0;
}

gint flip(Square *me)
{
  return me->flip_me();
}

Square::flip_me()
{
  if (start == 0)
    {
      gtk_pixmap_set(GTK_PIXMAP(my_square), pix[stop], NULL);
      return 0;
    }
  
  if (start < stop)
    start++;
  if (start > stop)
    start--;

  gtk_pixmap_set(GTK_PIXMAP(my_square), pix[start], NULL);
  if (start == stop)
      return 0;
  
  return 1;

}

int Square::flipp_check(int i)
  // Returningvalues
  // 0   = empty, it's no good
  // 1   = hey, I'm that color, flip yourself
  // 2-? = me -1 bricks has been flipped
{

  //I'm empty
  if (state == 0) 
      return 0;
  
  //I'm that color
  if (state == Square::col) 
      return 1;


    int returkoll;

    //else, pass along to the next in the same direction
    returkoll = adjoining[i - 1]->flipp_check(i);
    if (returkoll == 0) //if no good, just pass along
      {
        return 0;
      }

    //else, flipp, adding 1 to returkoll
    start = state;
    stop = Square::col;
    
    if (start == 2)
      start = 10;  
    if (stop == 2)
      stop = 10;
    
    gtk_timeout_add (40, flip, this);
    state = Square::col;
    return (returkoll + 1);
}




Square::place()
{
  //If I'm not empty I'm failing
  if (state != 0) 
    {
      return 0;
    }

  int tmp;
  int flipped = 0;

  //check all 8 directions
  for (int i = 1; i < 9; i++) 
    {
      tmp = (adjoining[i - 1]->flipp_check(i)); 
      if (tmp > 1) {
	flipped += tmp - 1;  
      }
    }
  if (flipped <= 0) {
    return 0;
  }
  //if any flipped, change me too
  start = 0;
  stop = Square::col;
  if (stop == 2)
    stop = 10;
  gtk_timeout_add (40, flip, this);
  state = Square::col;
  Square::col = (Square::col % 2) + 1;
  return flipped;
}


Square::set_link(int i, Square *sq)
{
  adjoining[i - 1] = sq;
  return 0;
}

int Square::who()
{
  return state;
}

int Square::col = 1;
