//AI_one_Player.cc

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//An AI player

#include "AI_one_Player.h"
#include <stdlib.h>

gint cal(AI_one_Player *);


AI_one_Player::AI_one_Player(int w, Square **b, GtkWidget *c, othello *d):Player(w, b, c, d)
{
}

int AI_one_Player::your_turn()
{
  gtk_timeout_add (500, cal, this); //500 if you would like to wait untill after the animation
}


AI_one_Player::cal_move()
{
  //I'm at least unpridictable!!
  int xx = (int) (random() % 8) + 1;  
  int yy = (int) (random() % 8) + 1;

  place->try_move(xx + yy * 10);
  return 0;

}


AI_one_Player::end_turn()
{
}

AI_one_Player::turn_no_ok()
{
  gtk_timeout_add (1, cal, this);
}

gint cal(AI_one_Player *me)
{
  return me->cal_move();
}
