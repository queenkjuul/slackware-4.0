//Local_Player.h

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//A local player, using the mouse

#ifndef LOCAL_PLAYER_H
#define LOCAL_PLAYER_H

class Local_Player;

#include "Player.h"

class Local_Player: public Player
{
  
  gint handler;

 public:

  Local_Player(int , Square **, GtkWidget *, othello *);
  
  //To tell the player it is his turn
  int your_turn();
  
  //It is no loger your turn
  end_turn();

  //Virtual i superclass
  turn_no_ok();

  //Called upon mouseclick
  static gint click (GtkWidget *, GdkEventButton *, Local_Player *); 
  
  //Called by click
  make_move(GdkEventButton *);

  
};


#endif //LOCAL_PLAYER_H
