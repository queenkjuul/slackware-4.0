//othello.cc

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

#include <iostream.h>

#include "othello.h"

//Diffrent Player types
#include "Local_Player.h"
#include "AI_one_Player.h"

//For the Players
#define PLAYERS 2

gint swap_pl(gpointer);
gint start (gpointer);
gint pl_load(GtkWidget *, gpointer);
char *mk_str(char *, int);

othello::othello(int argc, char **argv)
{

  //Initing the GTK graphics
  gtk_init (&argc, &argv);

  
  main_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_widget_realize (main_window);
  board_table = gtk_table_new (8, 8, 0);
  main_box = gtk_vbox_new (0,1);
  button_box = gtk_hbox_new (0,1);
  event_box = gtk_event_box_new();



  menu_bar = gtk_menu_bar_new();
  game_menu = gtk_menu_new(); 
  game_quit = gtk_menu_item_new_with_label("Quit");
  game_button = gtk_menu_item_new_with_label("Game");

  //Loading the images
  //Change to imlib

  pix[0] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/empty.xpm" );
  pix[1] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0001.xpm" );
  pix[2] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0002.xpm" );
  pix[3] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0003.xpm" );
  pix[4] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0004.xpm" );
  pix[5] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0005.xpm" );
  pix[6] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0006.xpm" );
  pix[7] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0007.xpm" );
  pix[8] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0008.xpm" );
  pix[9] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0009.xpm" );
  pix[10] = gdk_pixmap_create_from_xpm( main_window->window, NULL, NULL, "./xpm/othell0010.xpm" );



  
  //Create the board
  
  int tmp_x;
  int tmp_y;
  for (int i = 0; i < 100; i++)
    {
    tmp_x = i % 10;
    tmp_y = (i - (i % 10)) / 10;
    if ((tmp_x < 1) || (tmp_y < 1) || (tmp_y > 8) || (tmp_x > 8)) 
      {
	board[tmp_x + (10 * tmp_y)] = new Border(tmp_x, tmp_y, board);
      }
    else
      {
	board[tmp_x + (10 * tmp_y)] = new Square(tmp_x, tmp_y, board);
      }

    
    board[tmp_x + (10 * tmp_y)]->graph_init(pix, GTK_TABLE(board_table));


    } 



  //initing the score-trakers
  white = 2;
  black = 2;


  str = "White:   ";
  w_score = gtk_label_new (mk_str(str, white));
  str = "Black:   ";
  b_score = gtk_label_new (mk_str(str, black));;
  turn = gtk_label_new ("Turn: White");


  

  //Creating the players

  pick_players(argv, argc);


  //Initing the main window
  //init_main();

  gtk_main ();

}

char *mk_str(char tmp[10], int num)
{
  //Could be made better, but it's late  
  char tmp2[11] = "0123456789";
  tmp[7] = tmp2[(num / 10)];
  tmp[8] = tmp2[(num % 10)];
  return tmp;
}

void othello::init_main()
{

  gtk_menu_append( GTK_MENU(game_menu), game_quit);
  gtk_menu_item_set_submenu( GTK_MENU_ITEM(game_button), game_menu);
  gtk_menu_bar_append( GTK_MENU_BAR(menu_bar), game_button );

  //binding some events
  gtk_signal_connect_object ( GTK_OBJECT(game_quit), "activate", GTK_SIGNAL_FUNC(gtk_main_quit), NULL);
  gtk_signal_connect (GTK_OBJECT (main_window), "delete_event", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);

  //Showing the windows
  gtk_container_border_width (GTK_CONTAINER (main_window), 0);
  gtk_container_border_width (GTK_CONTAINER (event_box), 5);
  gtk_container_border_width (GTK_CONTAINER (button_box), 5);


  gtk_box_pack_start (GTK_BOX (button_box), w_score, 1, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (button_box), turn, 1, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (button_box), b_score, 1, TRUE, 0);
  gtk_container_add  (GTK_CONTAINER (event_box), board_table);
  gtk_box_pack_start (GTK_BOX(main_box), menu_bar, 0, 0, 1);
  gtk_box_pack_start (GTK_BOX (main_box), event_box, 0, 0, 1);
  gtk_box_pack_start (GTK_BOX (main_box), button_box, 0, 0, 1);
  

  gtk_container_add (GTK_CONTAINER (main_window), main_box);
  gtk_widget_show(turn);
  gtk_widget_show(game_button);
  gtk_widget_show(game_quit);
  gtk_widget_show(menu_bar);
  gtk_widget_show(w_score);
  gtk_widget_show(b_score);
  gtk_widget_show(button_box);
  gtk_widget_show(board_table);
  gtk_widget_show(event_box);
  gtk_widget_show(main_box);
  gtk_widget_show( main_window );


  gtk_timeout_add (1, start, this);

}


void othello::quit (GtkWidget *widget, gpointer data)
{
  gtk_main_quit ();
}


gint start (gpointer data)
{

  othello *me = (othello *) data;
  //telling the first player to go
  me->col = 1;
  me->player1->your_turn();
  return 0;
}


gint pl_load (GtkWidget *widget, gpointer data)
{
  othello *me = (othello *) data;
   me->load_pl();
  return 0;
}


void othello::end_game()
{
  win_dialog = gtk_dialog_new ();
  GtkWidget *button = gtk_button_new_with_label ("Quit");
  GtkWidget *label3;
  GtkWidget *sep1 = gtk_hseparator_new ();

  if (white > black)
    {
      label3 = gtk_label_new ("The winner is: White");
    }
  else if (white < black)
    {
      label3 = gtk_label_new ("The winner is: Black");
    }
  else
    {
      label3 = gtk_label_new ("No winner");
    }


  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (win_dialog)->vbox), label3, 0, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (win_dialog)->vbox), sep1, 0, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (win_dialog)->action_area), button, TRUE, TRUE, 0);


  gtk_window_set_title (GTK_WINDOW (dialog), "Game over");

  //bindings
  gtk_signal_connect (GTK_OBJECT (dialog), "delete_event", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);
 

  //Showing it

  gtk_container_border_width(GTK_CONTAINER (GTK_DIALOG (win_dialog)->vbox), 5);
  gtk_widget_show(button);
  gtk_widget_show(label3);
  gtk_widget_show(sep1);

  gtk_container_border_width (GTK_CONTAINER (win_dialog), 5);
  gtk_widget_show(win_dialog);



}


othello::load_pl()
{
  gtk_widget_hide(dialog);


  GSList *test1;
  GSList *test2;

  int one = 0;
  int two = 0;

 
  test1 = gtk_radio_button_group(GTK_RADIO_BUTTON (plist[0]));
  test2 = gtk_radio_button_group(GTK_RADIO_BUTTON (plist[1]));

  for (int i = PLAYERS; i > 0; i--)
    {

      one += i * (GTK_RADIO_BUTTON(test1->data)->check_button).toggle_button.active;
      test1 = test1->next;

      two += i * (GTK_RADIO_BUTTON(test2->data)->check_button).toggle_button.active;
      test2 = test2->next;

      //  cout << (((GTK_RADIO_BUTTON((gtk_radio_button_group(GTK_RADIO_BUTTON (plist[0]))->next->next)->data))->check_button).toggle_button.active);

    }

#define PLAYER player1
#define NUM 1

  switch(one)
    {

#include "Sel_User"
    }

#undef PLAYER
#undef NUM

#define PLAYER player2
#define NUM 2

  switch(two)
    {
#include "Sel_User"
    }

#undef PLAYER
#undef NUM
	
  init_main();
}



int othello::pick_players(char **argv, int argc)
{
 
  dialog = gtk_dialog_new ();
  GtkWidget *button = gtk_button_new_with_label ("OK");
  GtkWidget *label2 = gtk_label_new ("Player 1");  
  GtkWidget *label3 = gtk_label_new ("Player 2");
  GtkWidget *sep1 = gtk_hseparator_new ();
  GtkWidget *sep2 = gtk_hseparator_new ();



  GtkWidget *listbox;
  GtkWidget *p1box;
  GtkWidget *p2box;



  p1box = gtk_vbox_new (0,1);

  gtk_box_pack_start (GTK_BOX (p1box), label2, 0, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (p1box), sep1, 0, TRUE, 0);


#define LIST plist[0]
#define BOX p1box

#include "User_Dialog"

#undef LIST
#undef BOX

  p2box = gtk_vbox_new (0,1);

  gtk_box_pack_start (GTK_BOX (p2box), label3, 0, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (p2box), sep2, 0, TRUE, 0);


#define LIST plist[1]
#define BOX p2box

#include "User_Dialog"

#undef LIST
#undef BOX


  listbox = gtk_hbox_new (0,1);

  gtk_box_pack_start (GTK_BOX (listbox), p1box, 0, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (listbox), p2box, 0, TRUE, 0);


  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), listbox, 0, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area), button, TRUE, TRUE, 0);


  gtk_window_set_title (GTK_WINDOW (dialog), "Pick your players");

  //bindings
  gtk_signal_connect (GTK_OBJECT (dialog), "delete_event", GTK_SIGNAL_FUNC (gtk_main_quit), NULL);
  gtk_signal_connect (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (pl_load), this);
 

  //Showing it

  gtk_widget_show(button);
  gtk_widget_show(label2);
  gtk_widget_show(sep1);
  gtk_container_border_width (GTK_CONTAINER (p1box), 5);
  gtk_widget_show(p1box);
  gtk_widget_show(label3);
  gtk_widget_show(sep2);
  gtk_container_border_width (GTK_CONTAINER (p2box), 5);
  gtk_widget_show(p2box);
  gtk_container_border_width (GTK_CONTAINER (listbox), 5);
  gtk_widget_show(listbox);
  gtk_container_border_width (GTK_CONTAINER (dialog), 5);
  gtk_widget_show(dialog);


}


void othello::try_move (int sqr)
{
  int tmp = board[sqr]->place();

  if (tmp)
    {
      if (col == 1)
	{
	  white += tmp + 1;
	  black -= tmp;
	  gtk_label_set (GTK_LABEL(turn), "Turn: Black");
	}
      else
	{
	  black += tmp + 1;
	  white -= tmp;
	  gtk_label_set (GTK_LABEL(turn), "Turn: White");
	}

      str = "White:   "; 
      gtk_label_set (GTK_LABEL(w_score), mk_str(str, white));
      str = "Black:   "; 
      gtk_label_set (GTK_LABEL(b_score), mk_str(str, black));


      col = (col % 2) + 1;
      if(black + white != 64)
	{
	  gtk_timeout_add (1, swap_pl, this);
	}
      else
	{
	  end_game();
	}

    }
  else
    {
      if (col == 1)
	{
	  player1->turn_no_ok();
	}

      if (col == 2)
	{
	  player2->turn_no_ok();
	}
    }

}

//Please don't tell:->
gint swap_pl(gpointer d)
{
  othello *me = (othello *) d;
  if (me->col == 1)
    {
      me->player2->end_turn();
      me->player1->your_turn();
    }
  if (me->col == 2)
    {
      me->player1->end_turn();
      me->player2->your_turn();
    }
  //To stop the loop
  return 0;
}

main(int argc, char **argv)
{
  new othello(argc, argv);
}
