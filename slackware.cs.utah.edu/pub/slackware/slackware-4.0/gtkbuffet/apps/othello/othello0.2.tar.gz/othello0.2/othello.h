//othello.h

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

#ifndef OTHELLO_H
#define OTHELLO_H

class othello;

#include "Square.h"
#include "Border.h"
#include "Player.h"

//GTK stuff
#include <gtk/gtk.h>

class othello
{
  //The board
  Square *board[100];


  //Widgets
  GtkWidget *event_box;
  GtkWidget *main_window;
  GtkWidget *board_table;
  GtkWidget *main_box;
  GtkWidget *button_box;
  GtkWidget *dialog;
  GtkWidget *plist[2];
  GtkWidget *w_score;
  GtkWidget *b_score;
  GtkWidget *turn;
  GtkWidget *win_dialog;

  GtkWidget *menu_bar;
  GtkWidget *game_menu;
  GtkWidget *game_quit;
  GtkWidget *game_button;


  //Pictures
  GdkPixmap  *pix[11];

  //To keep trak of the score
  int white;
  int black;
  char str[10];


 public:

  //The players
  Player *player1;
  Player *player2;

  //Whos turn
  int col;

  
  othello(int, char **);

  //To pick 2 players
  int pick_players(char **, int);
  load_pl();
    
  void quit (GtkWidget *, gpointer);

  //To make the move
  void try_move (int);

  //To init the main window
  void init_main();


  //To end the game and find the winner
  void end_game();




};

#endif //OTHELLO_H
