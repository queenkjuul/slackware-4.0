//Local_Player.cc

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//A local player, using the mouse

#include "Local_Player.h"

//#include <iostream.h>

Local_Player::Local_Player(int w, Square **b, GtkWidget *c, othello *d):Player(w, b, c, d)
{
}

int Local_Player::your_turn()
{
  //  cout << "Player " << who << " signing on\n";
  handler = gtk_signal_connect (GTK_OBJECT(event_box), "button_press_event", (GtkSignalFunc) Local_Player::click, this);
}

static gint Local_Player::click(GtkWidget *widget, GdkEventButton *ev, Local_Player *me ) 
{
  me->make_move(ev);

}

Local_Player::make_move(GdkEventButton *ev)
{
  
  int xx = (((int)ev->x - ((int) ev->x % 64)) / 64) + 1;
  int yy = (((int)ev->y - ((int)ev->y % 64)) / 64) + 1;

  place->try_move(xx + yy * 10);


}


Local_Player::end_turn()
{
  //  cout << "Player " << who << " signing off\n";
  gtk_signal_disconnect (GTK_OBJECT(event_box), handler);

}

Local_Player::turn_no_ok()
{}
