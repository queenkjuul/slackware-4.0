//Player.h

//This software may be used like stated in the GNU General Public License
//Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

//The player superclass

#ifndef PLAYER_H
#define PLAYER_H

class Player;

#include "othello.h"
#include "Square.h"
#include <gtk/gtk.h>


class Player
{
  
 public:

  int who;
  Square **board;
  GtkWidget *event_box;
  othello *place;

  Player(int w, Square **b, GtkWidget *ev, othello *func){who = w; board = b; event_box = ev; place = func;};

  //To tell the player it is his turn
  virtual your_turn() = 0;

  //The turn preformed isn't OK, redo it (usefull for AI)
  virtual turn_no_ok() = 0;

  //It is no loger your turn
  virtual end_turn() = 0;

};


#endif //PLAYER_H

