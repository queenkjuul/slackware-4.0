#!/usr/bin/perl

# This software may be used like stated in the GNU General Public License
# Written by Bjorn Ardo -98 (bjorn@hobbe.lub.lu.se)

# To add a player to the othello code
