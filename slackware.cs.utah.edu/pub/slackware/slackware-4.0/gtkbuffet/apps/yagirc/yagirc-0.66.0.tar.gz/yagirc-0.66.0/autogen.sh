aclocal -I macros $ACLOCAL_FLAGS
automake -a
autoconf
