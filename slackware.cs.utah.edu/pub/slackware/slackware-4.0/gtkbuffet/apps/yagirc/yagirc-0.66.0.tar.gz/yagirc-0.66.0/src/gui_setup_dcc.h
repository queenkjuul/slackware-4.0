#include "config.h"

#ifndef __GUI_SETUP_DCC_H
#define __GUI_SETUP_DCC_H

void gui_setup_dcc(GtkWidget *vbox);

#endif
