#include "config.h"

#ifndef __GUI_CONNECT_H
#define __GUI_CONNECT_H

void gui_connect_dialog(void);
void gui_servers_dialog(void);

#endif
