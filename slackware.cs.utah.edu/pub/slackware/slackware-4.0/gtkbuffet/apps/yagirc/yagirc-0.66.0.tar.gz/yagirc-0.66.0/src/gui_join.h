#include "config.h"

#ifndef __GUI_MENU_JOIN
#define __GUI_MENU_JOIN

extern GList *joinlist;

void gui_join_dialog(SERVER_REC *server);

#endif
