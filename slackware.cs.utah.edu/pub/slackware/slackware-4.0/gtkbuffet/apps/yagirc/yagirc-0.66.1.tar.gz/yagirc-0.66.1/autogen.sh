aclocal -I macros $ACLOCAL_FLAGS
automake
autoconf
./configure $@
