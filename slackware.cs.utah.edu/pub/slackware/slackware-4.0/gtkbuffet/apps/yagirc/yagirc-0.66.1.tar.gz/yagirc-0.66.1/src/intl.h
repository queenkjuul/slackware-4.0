#include "config.h"

/* Dummy header for libintl.h */

#ifndef USE_GNOME
	#ifdef ENABLE_NLS
		#undef __OPTIMIZE__
		#include <libintl.h>
		#ifndef _
		#define _(String) gettext((String))
		#endif
	#else
		#ifndef _
		#define _(String) (String)
		#endif
	#endif
#endif
#define N_(String) (String)
