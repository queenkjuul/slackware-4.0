# bind connects
ircBind("connected", "", -1, server_connected);

sub server_connected {
    ircCmd("join #yagirc");
}
