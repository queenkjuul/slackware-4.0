/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * Revision 0.2
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
*/

#include <vdk/menu.h>
#include <vdk/forms.h>
#include <vdk/vdkfont.h>
/* XPM */
/*
static char * small_tick_xpm[] = {
"22 22 4 1",
" 	c None",
".	c #000000000000",
"X	c #820782078207",
"o	c #FFFFFFFFFFFF",
"                      ",
"                      ",
"                      ",
"                      ",
"                      ",
"                .X.   ",
"               XoX.   ",
"              XoX.    ",
"             XoX.     ",
"       X    XoX.      ",
"      XoX  Xo..       ",
"     Xo  X.o X.       ",
"     .X   o ..        ",
"     ..X    X.        ",
"      ..X  X.         ",
"       ..X X.         ",
"        ..X.          ",
"         ...          ",
"          .           ",
"                      ",
"                      ",
"                      "};
*/
/* XPM */
static char * mini_bball_xpm[] = {
"16 14 4 1",
" 	c None s None",
".	c blue",
"X	c white",
"o	c gray50",
"                ",
"                ",
"                ",
"                ",
"      ...       ",
"     .XX..      ",
"     .XX..o     ",
"     .....o     ",
"      ...oo     ",
"       ooo      ",
"                ",
"                ",
"                ",
"                "};
/*
 */
VDKMenu::VDKMenu(VDKForm* owner): VDKObject(owner)
{
widget = gtk_menu_new();
//acTable = NULL;
}
/*
 */
VDKMenu::~VDKMenu()
{
  /*
    if(acTable)
    gtk_accelerator_table_unref(acTable);
  */
}

void 
VDKMenu::Separator()
{
GtkWidget* sep = gtk_menu_item_new ();
gtk_container_add (GTK_CONTAINER (widget), sep);
gtk_widget_show(sep);
}
/*
 */
void VDKMenu::SetFont(VDKFont* font)
{

ItemListIterator li(items);
for(;li;li++)
  li.current()->SetFont(font);
}
/*
 */
void VDKMenu::Popup(guint button, guint32 activate_time)
{
  gtk_menu_popup(GTK_MENU(widget),
		 NULL,NULL,NULL,NULL,
		 button, activate_time);
}
/*
 */
VDKMenuItem::VDKMenuItem(VDKMenu* menu ,
			 char* prompt, 
			 char** pix,
			 char key,
			 guint8 modkey):
  VDKObject(menu->Owner())
{
  widget = gtk_menu_item_new();
  box = gtk_hbox_new(FALSE,0);
  gtk_container_border_width(GTK_CONTAINER(box),1);
  // packs tick
  {
    GdkBitmap *mask;
    GtkStyle* style = gtk_widget_get_style(owner->Window());
    tickPixmap = gdk_pixmap_create_from_xpm_d(owner->Window()->window,
					      &mask,
					      &style->bg[GTK_STATE_NORMAL],
					      mini_bball_xpm);
    tickWidget = gtk_pixmap_new(tickPixmap,mask);
    gtk_box_pack_start(GTK_BOX(box),tickWidget,FALSE,FALSE,1);
  }
  // packs pixmap
  if(pix)
    {
      GdkBitmap *mask;
      GtkStyle* style = gtk_widget_get_style(owner->Window());
      pixmap = gdk_pixmap_create_from_xpm_d(owner->Window()->window,
					  &mask,
					  &style->bg[GTK_STATE_NORMAL],
					  pix);
      pixmapWidget = gtk_pixmap_new(pixmap,mask);
      gtk_box_pack_start(GTK_BOX(box),pixmapWidget,FALSE,FALSE,1);
      gtk_widget_show(pixmapWidget);
    }
  else
    pixmap = NULL;
  // packs label
  lbl  = gtk_label_new(prompt);
  gtk_box_pack_start(GTK_BOX(box),lbl,FALSE,FALSE,1);
  gtk_widget_show(lbl);
  gtk_widget_show(box);
  gtk_container_add(GTK_CONTAINER(widget),box);
  s_activated.obj = this;
  s_activated.signal = activate_signal;
  gtk_menu_append(GTK_MENU(menu->Widget()),widget);
  gtk_widget_show(widget);
  menu->AddItem(this);
  Parent(menu->Owner());
  // install accelerator
  // does'nt work
  // waiting for Gtk 1.2 ....
  /*
    if(key)
    {
    if(! menu->acTable)
    menu->acTable = gtk_accelerator_table_new();
    gtk_widget_install_accelerator(widget,
    menu->acTable,
    "activate",
    key,
    modkey);
    }
  */
gtk_signal_connect(GTK_OBJECT(widget),"activate",
		   GTK_SIGNAL_FUNC(VDKObject::VDKSignalPipe),
		   (gpointer) &s_activated);
ConnectDefaultSignals();
tickPixmap = NULL;
tickWidget = NULL;
ticked = false;
}
/*
 */
VDKMenuItem::VDKMenuItem(VDKMenubar* bar,char* prompt, char** pix, int align):
  VDKObject(bar->Owner())
{

 widget = gtk_menu_item_new();
 box = gtk_hbox_new(FALSE,0);
 gtk_container_border_width(GTK_CONTAINER(box),1);
 // packs pixmap
  if(pix)
    {
      GdkBitmap *mask;
      GtkStyle* style = gtk_widget_get_style(owner->Window());
      pixmap = gdk_pixmap_create_from_xpm_d(owner->Window()->window,
					  &mask,
					  &style->bg[GTK_STATE_NORMAL],
					  pix);
      pixmapWidget = gtk_pixmap_new(pixmap,mask);
      gtk_box_pack_start(GTK_BOX(box),pixmapWidget,FALSE,FALSE,1);
      gtk_widget_show(pixmapWidget);
    }
  else
    pixmap = NULL;
  // packs label
 lbl  = gtk_label_new(prompt);
 gtk_box_pack_start(GTK_BOX(box),lbl,FALSE,FALSE,1);
 gtk_widget_show(lbl);
 gtk_widget_show(box);
 gtk_container_add(GTK_CONTAINER(widget),box);
 s_activated.obj = this;
 s_activated.signal = activate_signal;
 gtk_signal_connect(GTK_OBJECT(widget),"activate",
		    GTK_SIGNAL_FUNC(VDKObject::VDKSignalPipe),
		    (gpointer) &s_activated);
 if(align == r_justify)
   gtk_menu_item_right_justify(GTK_MENU_ITEM(widget));
 gtk_menu_bar_append(GTK_MENU_BAR(bar->Widget()),widget);
 gtk_widget_show(widget);
 bar->AddItem(this);
 Parent(bar->Owner());
 tickPixmap = NULL;
 tickWidget = NULL;
 ticked = false;
}
/*
 */
void
VDKMenuItem::Tick(bool flag)
{
ticked = flag;
if(flag)
  {
    if(!tickWidget)
      {
	GdkBitmap *mask;
	GtkStyle* style = gtk_widget_get_style(owner->Window());
	tickPixmap = gdk_pixmap_create_from_xpm_d(owner->Window()->window,
						  &mask,
						  &style->bg[GTK_STATE_NORMAL],
						  mini_bball_xpm);
	tickWidget = gtk_pixmap_new(tickPixmap,mask);
	gtk_box_pack_start(GTK_BOX(box),tickWidget,FALSE,FALSE,1);
	gtk_widget_show(tickWidget);
      }
    else
      gtk_widget_show(tickWidget);
  }
else if(tickWidget) 
  gtk_widget_hide(tickWidget);
}
/*
 */
void VDKMenuItem::SetFont(VDKFont* font)
{
  _setFont_(lbl,font);
  ItemListIterator li(items);
  for(;li;li++)
    li.current()->SetFont(font);
}
/*
 */
VDKMenuItem::~VDKMenuItem()
{
  if(pixmap)
    gdk_pixmap_unref(pixmap);
  if(tickPixmap)
    gdk_pixmap_unref(tickPixmap);
}
/*
 */
void 
VDKMenuItem::Add(VDKMenu* submenu)
{
gtk_menu_item_set_submenu(GTK_MENU_ITEM(widget),submenu->Widget());
//gtk_menu_set_accelerator_table(GTK_MENU(submenu->Widget()),submenu->acTable);
AddItem(submenu);
submenu->Parent(this);
}
/*
 */
VDKMenubar::VDKMenubar(VDKForm* owner):
  VDKObject(owner)
{
widget = gtk_menu_bar_new();
}
/*
 */
VDKMenubar::~VDKMenubar()
{

}
/*
 */
void VDKMenubar::SetFont(VDKFont* font)
{

ItemListIterator li(items);
for(;li;li++)
  li.current()->SetFont(font);
}

/*
 */
VDKOptionMenu::VDKOptionMenu(VDKForm* owner):
  VDKObject(owner)
{
widget = gtk_option_menu_new ();
}
/*
 */
VDKOptionMenu::~VDKOptionMenu()
{

}

void VDKOptionMenu::Add(VDKMenu* menu)
{
  gtk_option_menu_set_menu (GTK_OPTION_MENU (widget), 
			    menu->Widget());
  AddItem(menu);
  menu->Parent(this);
}

