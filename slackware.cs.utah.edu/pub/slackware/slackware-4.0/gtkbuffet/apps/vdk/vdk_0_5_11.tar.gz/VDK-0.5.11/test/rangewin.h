/*
file: rangewin.h
*/
#include <vdk/vdk.h>
class RangeWin: public VDKForm
{
  VDKSlider *h_slider,*v_slider;
  VDKLabel *date_label,*label;
  VDKSpinButton *month,*day,*year;
public:
  RangeWin(VDKForm* owner, char* title = "Range & spins"):
    VDKForm(owner,title)
    {}
  ~RangeWin() 
    {}
  void Setup();
  bool HandleSliders(VDKObject* sender);
  bool HandleSpins(VDKObject* sender);
DECLARE_SIGNAL_MAP(RangeWin);
};

