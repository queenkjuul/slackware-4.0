/*
file: ttest.h
List, Heap and Btree 
template classes test
*/
#include <vdk/vdk.h>
/*
 */
class 
BTreeWindow: public VDKForm
{
  VDKText *text; 
  VDKLabelButton *start,*quit,*showsource;
 public:
  BTreeWindow(VDKApplication* owner):
    VDKForm(owner,"Sorted lists,Btrees and Heaps example")  {}
  ~BTreeWindow() { }
  void Setup();
  bool Start(VDKObject*);
  bool Quit(VDKObject*) { Close(); return true;}
  bool ShowSource(VDKObject*);
  DECLARE_SIGNAL_LIST(BTreeWindow);
};

/*
 */
class 
MyApp: public VDKApplication
{
  
public:
  MyApp(int* argc, char** argv): VDKApplication(argc,argv) {}
  ~MyApp() {}
  void Setup()
  {
    MainForm = new BTreeWindow(this);
    MainForm->Setup();
    MainForm->Show(); 
  }
};
