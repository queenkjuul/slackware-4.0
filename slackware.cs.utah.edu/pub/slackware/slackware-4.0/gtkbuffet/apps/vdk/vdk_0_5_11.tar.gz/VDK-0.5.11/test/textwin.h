/*
file: textwin.h
*/
#include <vdk/vdk.h>
class TextWin: public VDKPanedForm
{
  VDKText *text_h;
  VDKText *text_cc;
  char* file;
  VDKColor *navy,*siena,*white;
 public:
  TextWin(VDKForm* owner, char* title,char* f):
    VDKPanedForm(owner,title)
    {
      file = new char[strlen(f)+1];
      strcpy(file,f);
    }
  ~TextWin() 
    {
      navy->Destroy();
      siena->Destroy();
      white->Destroy();
      delete file; 
    }
  void Setup();
  void OnShow(VDKForm*);
};


