/*
file: tbarwin.h
*/
#include <vdk/vdk.h>
class ToolBarWin: public VDKForm
{
  VDKToolbar *toolbar;
  VDKEntry   *entry;
  VDKStatusbar *sbar;
  VDKFrame* frame,*frame1;
  VDKHandleBox *handlebox1;
public:
  ToolBarWin(VDKForm* owner):
    VDKForm(owner,"Cool & tool bars") {}
  ~ToolBarWin() {}
  void Setup();
  bool HandleToolBarSignals(VDKObject*);
  bool HandleEntry(VDKObject*);
  bool HandleChildAttached(VDKObject*);
  bool HandleChildDetached(VDKObject*);
  DECLARE_SIGNAL_MAP(ToolBarWin);
};
