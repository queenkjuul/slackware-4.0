/*
file: rcwin.h
*/
#include <vdk/vdk.h>
class RcWin: public VDKForm
{
  VDKText *text;
  VDKLabelButton *toggleBackground;
  char* file;
public:
  RcWin(VDKForm* owner, char* title,char* f):
    VDKForm(owner,title)
    {
      file = new char[strlen(f)+1];
      strcpy(file,f);
    }
  ~RcWin() 
    {
      delete file; 
    }
  void Setup();
  void OnShow(VDKForm*);
};

