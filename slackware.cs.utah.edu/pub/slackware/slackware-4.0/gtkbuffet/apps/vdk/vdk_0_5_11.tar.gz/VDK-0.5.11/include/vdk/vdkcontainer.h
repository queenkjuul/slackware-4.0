/*
Visual Development Kit (VDK)
version 0.2
file: vdkcontainer.h
overview:
this class implements a generic container
with 'value semantic".
*/
#ifndef _vdkcontainer_h
#define _vdkcontainer_h

template <class T>
class VDKContainer
{
 protected:
  T* data;
  int count;
 public:
  VDKContainer(int count=0): 
    data(count > 0 ? new T[count]: 0),count(count) {}
  VDKContainer(VDKContainer&);
  VDKContainer& operator=(VDKContainer&);
  virtual ~VDKContainer() { if(data) delete[] data; }
  
  int size() { return count ; }
  int operator==(VDKContainer& );
  T& operator[](int n) { return data[n]; }
};

//
// VDKContainer iterator
/*
  template <class T> class VDKContainerIterator {
  int count,p;
  T* data;
  public:
  VDKContainerIterator(VDKContainer<T>& c):
  count(c.size()),p(0),data(c.data) {}
  virtual ~VDKContainerIterator() {}
  void operator++() { p++; }
  void operator++(int) { p++; }
  operator int() { return p < count; }
  T& current() { return data[p]; }
  void restart() { p = 0; }
  };
*/

//==========================
// outside class definitions
//==========================
//copy inizializer
template <class T>
VDKContainer<T>::VDKContainer(VDKContainer<T> &v) 
{
  count = v.count;
  data = new T[count];
  for(int i = 0;i < count; i++) data[i] = v.data[i];
}
// assignement
template <class T>
VDKContainer<T>& VDKContainer<T>::operator=(VDKContainer<T>&v) 
{
  // avoid v = v;
  if(this !=&v) {
    if(data) delete[] data;
    count = v.count;
    data = count > 0 ? new T[count]: 0;
    for(int i = 0;i < count; i++)
      data[i] = v.data[i];
  }
  return *this;
}
// equality operator
template <class T> int
VDKContainer<T>::operator==(VDKContainer<T>& m) 
{
  int i;
  if(count != m.count) return 0;
  for(i = 0;(i < count)  && (data[i] == m[i]);i++) ;
  return i == count ? 1 : 0 ;
}

#endif

