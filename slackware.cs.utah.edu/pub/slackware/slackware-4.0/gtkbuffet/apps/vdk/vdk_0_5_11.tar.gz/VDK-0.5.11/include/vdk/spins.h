/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#ifndef _spins_h
#define _spins_h
#include <vdk/vdkobj.h>
#include <vdk/vdkprops.h>

class VDKSpinButton: public VDKObject
{
  static void FocusOutEvent(GtkWidget *w,
			    GdkEventFocus*,
			    gpointer wid);
  static void ValueChanged(GtkWidget *wid, gpointer gp);
  GtkObject* adj; 
 public:
  //properties
VDKReadOnlyValueProp<VDKSpinButton,float> ValueAsFloat;
VDKReadOnlyValueProp<VDKSpinButton,int>   ValueAsInt;
VDKReadWriteValueProp<VDKSpinButton, int>  Digits;
  VDKSpinButton(VDKForm* owner,
	    float defValue,
	    float lower,
	    float upper,
	    float step_increment,
	    float climb_rate);
  virtual ~VDKSpinButton();
  int GetDigit() { return Digits; }
  void SetDigits(int digits) 
    { gtk_spin_button_set_digits(GTK_SPIN_BUTTON(widget), digits); }
  float GetValueAsFloat() 
    { return gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(widget));}
  int GetValueAsInt() 
    { return gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(widget));}
};
#endif
