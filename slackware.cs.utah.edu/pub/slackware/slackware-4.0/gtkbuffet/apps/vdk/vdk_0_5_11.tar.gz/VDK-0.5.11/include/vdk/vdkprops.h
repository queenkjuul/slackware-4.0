/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-130
 */ 

#ifndef _vdk_props_h
#define _vdk_props_h
#include <vdk/vdkstring.h>
#include <vdk/vdkfont.h>
#include <stdio.h>
#define __rwproperty(ownerClass,propertyType) \
  VDKReadWriteValueProp<ownerClass, propertyType>
#define __rproperty(ownerClass,propertyType) \
  VDKReadOnlyValueProp<ownerClass, propertyType>
#define PFREAD_NULL  (PFRead) 0x0000
#define PFWRITE_NULL (PFWrite) 0x0000
//==================================================
/*
read/write values property
*/
template <class T, class S>
class VDKReadWriteValueProp 
{
  friend class T;
 protected:
  typedef S (T::*PFRead)(void);
  typedef void (T::*PFWrite)(S);

  VDKString name;
  T* object;
  S  (T::*get)(void);
  void (T::*set)(S);
  S value;
  VDKReadWriteValueProp(VDKReadWriteValueProp& p) { }
  void operator=(VDKReadWriteValueProp& p) { }
 public:

  VDKReadWriteValueProp(): 
    name(""),
    object(NULL),
    get(PFREAD_NULL),
    set(PFWRITE_NULL)
    { }

  VDKReadWriteValueProp(
			char* name,
			T* object,
			S defValue,
			void (T::*write)(S) = PFWRITE_NULL,
			S (T::*read)(void) =  PFREAD_NULL
			):
    name(name),object(object),
    get(read),set(write),
    value(defValue)
    { }

  virtual ~VDKReadWriteValueProp() {}
 
  // raw setting (functor)
  // caution using it in read only props breaks
  // data hiding and can lead in ugly errors.
  // user: use it at your own risk.
  virtual void operator()(S val) { value = val; }
  // setting prop value operator
  virtual void operator = (S val) 
    { 
      value = val;
      if(set && object) 
	((*object).*set)(val); 
    }
  // getting prop value operator
  virtual operator S() 
    { 
      if(get && object)
	return ((*object).*get)();
      else
	return value;
    }
  char* Name() { return name; }
};


/*
read only values property
*/
template <class T, class S>
class VDKReadOnlyValueProp: public VDKReadWriteValueProp<T,S> 
{
 void operator = (S) { }
 public:
 VDKReadOnlyValueProp():VDKReadWriteValueProp<T,S>() { }
 VDKReadOnlyValueProp(
		  char* name,
		  T* object,
		  S defValue,
		  S (T::*read)(void) = PFREAD_NULL,
		  void (T::*write)(S) = PFWRITE_NULL
		  ):
    VDKReadWriteValueProp<T,S>(
			       name,
			       object,
			       defValue,
			       write,
			       read) { }

  virtual ~VDKReadOnlyValueProp() {}
 
};
#endif
