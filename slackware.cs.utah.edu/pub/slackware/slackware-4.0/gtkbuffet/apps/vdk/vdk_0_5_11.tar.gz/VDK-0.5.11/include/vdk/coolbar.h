/*
 * ===========================
 * VDK Visual Develeopment Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#ifndef  _cool_bar_
#define  _cool_bar_

#include <vdk/boxes.h>
#include <vdk/coolbutton.h>
#include <vdk/vdkprops.h>
class VDKForm;

typedef VDKList<VDKCoolButton>   CoolButtonList;
typedef VDKListiterator<VDKCoolButton>   CoolButtonListIterator;

class VDKCoolbar : public VDKBox
{
 protected:
  static void ButtonPressedSignal(GtkWidget *wid , gpointer gp);
  CoolButtonList coolButtons;
 public:
  //
  VDKReadOnlyValueProp<VDKCoolbar, CoolButtonList*> ButtonList;
  //
  int ButtonPressed;
  VDKCoolbar(VDKForm* owner, int mode = h_box);
  VDKCoolButton*  AddCoolButton(
				char** pixdata,
				char** grayedpix = (char**) NULL,
				char* tip = (char*) NULL);
  virtual ~VDKCoolbar() {}
};


#endif
