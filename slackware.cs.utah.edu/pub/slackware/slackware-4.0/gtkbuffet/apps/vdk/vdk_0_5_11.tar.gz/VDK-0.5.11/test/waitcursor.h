/*
 */
#ifndef _wait_cursor_h
#define _wait_cursor_h
class WaitCursor
{
  GdkCursor *cursor;
  VDKForm* form;
 public:
  WaitCursor(VDKForm *form):form(form)
    {
      cursor = gdk_cursor_new (GDK_WATCH);
      gdk_window_set_cursor (form->Window()->window, cursor);
      gdk_cursor_destroy (cursor);
    }
  ~WaitCursor() 
    {
      cursor = gdk_cursor_new (GDK_LEFT_PTR);
      gdk_window_set_cursor (form->Window()->window, cursor);
      gdk_cursor_destroy (cursor);
    }
};
#endif
