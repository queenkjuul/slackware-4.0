/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#include <vdk/togglebutton.h>
#include <vdk/forms.h>  
#include <vdk/tooltips.h>

/*
should be investigated more since
seems to be unuseless, perhaps this
compiler is'nt full ANSI compliant
*/
/*
  template <class T>
  void vdk_cast(T** obj ,void* gp)
  {
  T* addr = reinterpret_cast<T*>(gp);
  *obj = dynamic_cast<T*>(addr);
  }
*/ 

void VDKToggleButton::ToggleEvent(GtkWidget *wid, gpointer gp)
{
    g_return_if_fail(wid != NULL);
    g_return_if_fail(gp != NULL);
    VDKToggleButton* obj = reinterpret_cast<VDKToggleButton*>(gp);
    obj->Checked(GTK_TOGGLE_BUTTON(wid)->active ? true : false);
    obj->SignalEmit(toggled_signal);
}
 
VDKToggleButton::VDKToggleButton (VDKForm* owner, char* tip) :
  VDKAbstractButton(owner),
  Checked ("Checked", this, false, &VDKToggleButton::SetChecked, &VDKToggleButton::GetChecked)
{
    widget = gtk_toggle_button_new ();
    connectId = gtk_signal_connect(GTK_OBJECT(widget),"toggled",
                                   GTK_SIGNAL_FUNC(VDKToggleButton::ToggleEvent),
                                   reinterpret_cast<gpointer>(this));
    if (tip)
        tooltip = new VDKTooltip(owner, this, tip);
    else
        tooltip = 0;

}
