/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-130
 */ 


#ifndef _vdktypes_h
#define _vdktypes_h
#include <gdk/gdktypes.h>
enum VDKCursorType
{
curDefault = -1,
curLeftPtr = GDK_LEFT_PTR,
curWatch = GDK_WATCH,
curCrossHair = GDK_CROSSHAIR,
curHandPtr = GDK_HAND2,
curPencil = GDK_PENCIL
};

enum VDKSignal 
{
  no_signal = -1,
  clicked_signal,
  pressed_signal,
  released_signal,
  enter_signal,
  leave_signal,
  activate_signal,
  select_row_signal,
  unselect_row_signal,
  click_column_signal,
  changed_signal,
  focus_out_signal,
  focus_in_signal,
  timer_tick_signal,
  realize_signal,
  switch_page_signal,
  toggled_signal,
  event_browser_signal,
  value_changed_signal,
  child_attached_signal,
  child_detached_signal,
  selection_changed_signal, // used in VDKCombo
  text_changed_signal, // used in VDKtext
  select_node_signal,
  unselect_node_signal,
  user_signal = 4096
};

enum VDKEvent
{
  no_event = GDK_NOTHING,	
  delete_event = GDK_DELETE,
  destroy_event = GDK_DESTROY,
  expose_event = GDK_EXPOSE,
  motion_notify_event = GDK_MOTION_NOTIFY,
  button_press_event = GDK_BUTTON_PRESS,
  double_click_event = GDK_2BUTTON_PRESS,
  triple_click_event = GDK_3BUTTON_PRESS,
  button_release_event = GDK_BUTTON_RELEASE,
  key_press_event = GDK_KEY_PRESS,
  key_release_event = GDK_KEY_RELEASE,
  enter_notify_event = GDK_ENTER_NOTIFY,
  leave_notify_event = GDK_LEAVE_NOTIFY,
  focus_change_event = GDK_FOCUS_CHANGE,
  configure_event = GDK_CONFIGURE,
  map_event = GDK_MAP,
  unmap_event = GDK_UNMAP,
  property_notify_event = GDK_PROPERTY_NOTIFY,
  selection_clear_event = GDK_SELECTION_CLEAR,
  selection_request_event = GDK_SELECTION_REQUEST,
  selection_notify_event = GDK_SELECTION_NOTIFY,
  proximity_in_event = GDK_PROXIMITY_IN,
  proximity_ou_event = GDK_PROXIMITY_OUT,
  client_event = GDK_CLIENT_EVENT,
  visibility_notify_event = GDK_VISIBILITY_NOTIFY,
  no_expose_event = GDK_NO_EXPOSE,
  drag_start_event = GDK_DRAG_ENTER,
  drag_stop_event = GDK_DRAG_LEAVE,
  dragging_event = GDK_DRAG_MOTION
};

enum { v_box, h_box, table_box };
enum { l_justify, c_justify, r_justify };
enum { h_separator, v_separator };
enum { shadow_none, shadow_in, shadow_out, 
       shadow_etched_in, shadow_etched_out };
enum { Class_level = 8192, Parent_level };

enum VDKUpdateType
{
 update_continuos = GTK_UPDATE_CONTINUOUS,
 update_discontinuos =  GTK_UPDATE_DISCONTINUOUS,
 update_delayed =  GTK_UPDATE_DELAYED
};

/* icon types */
#define MB_ICONSTOP          0x0010
#define MB_ICONQUESTION      0x0020
#define MB_ICONINFORMATION   0x0040
#define MB_ICONMASK          0x00F0
/* box type */
#define MB_OK                0x0000
#define MB_YESNO             0x0004
#define MB_TYPEMASK          0x000F
/* message box answers */
#define IDYES                0x0001
#define IDNO                 0x0002
#define IDOK                 0x0003
#define IDCANCEL             0x0004 /* (not yet implemented) */

/* some useful colors */
#define clWhite VDKRgb(255,255,255)
#define clBlack VDKRgb(0,0,0)
#define clYellow VDKRgb(255,255,0)
#define clRed   VDKRgb(255,0,0)
#define clGreen VDKRgb(0,255,0)
#define clBlue  VDKRgb(0,0,255)
#define clNavyBlue  VDKRgb(0,0,130)
#define clMaroon VDKRgb(146,89,28)
#define clSiena  VDKRgb(178,32,32)
#define clIvory  VDKRgb(255,255,223)
#define clAirBlue VDKRgb(89,186,231)
#define clLightBlue clAirBlue
#define clDodgerBlue VDKRgb(101,191,212)

/* some useful fonts */
#define fnFixed14 "-misc-fixed-medium-*-normal-*-14-*-*-*-*-*-*-*"
#define fnCourier12 "-*-courier-medium-r-*-*-12-*-*-*-*-*-iso8859-*"
#define fnCourier14 "-*-courier-medium-r-normal-*-14-*-*-*-*-*-*-*"
#define fnFixed12   "-*-fixed-medium-r-*-*-12-60-*-*-*-*-iso8859-*"
#define fnLucida12  "-*-lucida-medium-r-*-*-12-60-*-*-*-*-iso8859-*"
#define fnLucidaBold12 "-b&h-lucidatypewriter-bold-r-normal-*-*-120-*-*-m-*-iso8859-1"
#define fnLucidaTW18 "-b&h-lucidatypewriter-medium-r-normal-sans-19-190-75-75-m-110-iso8859-1"
#define fnTimesBold12 "-adobe-times-bold-r-normal-*-*-120-*-*-p-*-iso8859-1"
#define fnTimesBold14 "-adobe-times-bold-r-normal-*-*-140-*-*-p-*-iso8859-1"
#define fnTimes24 "-adobe-utopia-regular-r-normal-*-*-240-*-*-p-*-iso8859-1"
#define fnTimesBold24 "-adobe-times-bold-r-normal-*-*-240-*-*-p-*-iso8859-1"

#endif





