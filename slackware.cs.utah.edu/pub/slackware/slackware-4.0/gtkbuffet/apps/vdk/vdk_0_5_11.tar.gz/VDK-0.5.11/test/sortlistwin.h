/*
file: sortlistwin.h
*/
#include <vdk/vdk.h>

#define MAX_ADDR 6
#define MAX_COL 5
#define KEYPOS 0

// yet another address program !
typedef struct {
  char *items[MAX_COL];
} ynad;

class SortedListWindow: public VDKForm
{
  VDKCustomSortedList* list;
  VDKLabelButton *add,*del,*reload,*quit,*addmany;
 public:
  SortedListWindow(VDKForm* owner): 
    VDKForm(owner,"Sorted list example (with extended selection)") {}
  ~SortedListWindow() {}
  void Setup();
  bool Quit(VDKObject*) { Close(); return true;}
  bool DeleteRow(VDKObject*);
  bool AddRow(VDKObject*);
  bool AddManyRow(VDKObject*);
  bool Reload(VDKObject*);
  bool ListDoubleClick(VDKObject*);
  DECLARE_SIGNAL_MAP(SortedListWindow)
};




