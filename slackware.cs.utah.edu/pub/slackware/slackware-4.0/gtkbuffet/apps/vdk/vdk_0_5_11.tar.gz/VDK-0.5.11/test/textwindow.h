/*
file: textwindow.h
*/
#include <vdk/vdk.h>


class TextWindow: public VDKForm
{
  VDKText* text;
  VDKLabelButton *wordwrap;
  VDKColor *navy,*red,*blue,*green;
public:
  TextWindow(VDKForm* owner):
    VDKForm(owner,"This forms shows text widget")
    {}
  ~TextWindow() 
    {}
  void Setup();
  bool ToggleWordWrap(VDKObject*);
  bool OnRealizeText(VDKObject*);
  bool CanClose();
DECLARE_SIGNAL_MAP(TextWindow)
};
