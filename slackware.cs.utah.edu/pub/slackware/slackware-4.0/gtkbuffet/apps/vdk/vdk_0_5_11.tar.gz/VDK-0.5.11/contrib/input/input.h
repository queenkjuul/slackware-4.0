
#ifndef  _vdkinput_h_
#define  _vdkinput_h_
#include <vdk/vdkobj.h>

#define INP_SIGNAL (user_signal+1)

class VDKInput: public VDKObject
{
protected:
  static void HandleIO(gpointer obj, gint source, GdkInputCondition condition);
  gint tag;
  int fd;
  GdkInputCondition condition;
    
public:
  VDKInput (VDKForm* obj, int fd,GdkInputCondition condition = GDK_INPUT_READ);
  virtual ~VDKInput();
  int getfd(void) {return fd;}
};
#endif
