/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.5
 * October 1998
 * =========================== 
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 */
 

#include <vdk/vdkcustom.h>
#include <vdk/forms.h>
void VDKCustom::ColumnClick(GtkWidget* ,
		  gint column,
		  gpointer s)
{ 
  g_return_if_fail(s != NULL);
  VDKObjectSignal* signal = 
    reinterpret_cast<VDKObjectSignal*>(s);
  VDKCustom* obj = reinterpret_cast<VDKCustom*>(signal->obj);
  obj->SelectedTitle = column;
  obj->SignalEmit(signal->signal);
}
/////////////////////////////////////////////////
/*
 */
VDKCustom::VDKCustom(VDKForm* owner,
			     int columns,
			     char** titles,
			     GtkSelectionMode mode):
  VDKObject(owner),
  VPolicy("VPolicy",this,GTK_POLICY_AUTOMATIC,&VDKCustom::SetVPolicy),
  HPolicy("HPolicy",this,GTK_POLICY_AUTOMATIC,&VDKCustom::SetHPolicy),
  BorderShadow("BorderShadow",this,GTK_SHADOW_ETCHED_OUT,
	       &VDKCustom::SetBorderShadow),
  RowHeight("RowHeight",this,0,&VDKCustom::SetRowHeight),
  AutoResize("AutoResizeColumn",this,true,
	     &VDKCustom::SetAutoResize),
  SelectedTitle(-1),
  UnselectedBackground(NULL),
  UnselectedForeground(NULL),
  SelectedBackground(NULL), 
  SelectedForeground(NULL),
  columns(columns),
  mode(mode)
{
  SelectedTitle = -1;
  if(titles) 
    Titles = VDKObjectArray(columns);
  custom_widget = NULL;
  widget = gtk_scrolled_window_new (NULL, NULL);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (widget),
				  GTK_POLICY_AUTOMATIC, 
				  GTK_POLICY_AUTOMATIC);
} 
/*
 */
VDKCustom::~VDKCustom()
{
}

/*
 */
void
VDKCustom::ConnectSignals()
{
  s_list_click_column.obj = this;
  s_list_click_column.signal = click_column_signal;
  gtk_signal_connect(GTK_OBJECT(custom_widget),
		     "click_column",
		     GTK_SIGNAL_FUNC(VDKCustom::ColumnClick),
		     (gpointer) &s_list_click_column);
}
/*
 */
void 
VDKCustom::SetBackground(VDKRgb c, GtkStateType state)
{
  if( !custom_widget) 
    return;
  GtkStyle* style = custom_widget->style;
  g_return_if_fail(style != NULL);
  style = gtk_style_copy(style);
  gtk_style_ref(style);
  VDKColor *color = new VDKColor(Owner() ? Owner() : this ,
				 c.red,c.green,c.blue);
  gtk_style_ref(style);
  style->base[state] = *(color->Color());
  gtk_widget_set_style(custom_widget,style);
};
/*
 */
void 
VDKCustom::SetForeground(VDKRgb color, GtkStateType state)
{
  if(custom_widget) 
    _setForeground_(custom_widget,color.red,color.green,color.blue, state);
}
/* 
 */
void 
VDKCustom::SetFont(VDKFont* font)
{
  if(custom_widget) 
    _setFont_(custom_widget,font);
}

/*
 */
void VDKCustom::ActiveTitle(int col,bool flag)
{
if(Titles.size() <= 0)
  return;
if(flag) 
  gtk_clist_column_title_active(GTK_CLIST(custom_widget),col);
else
  gtk_clist_column_title_passive(GTK_CLIST(custom_widget),col);
}
/*
 */
void VDKCustom::ActiveTitles(bool flag)
{
for(int t = 0; t < columns; t++)
  ActiveTitle(t,flag);
}
/*
 */
void 
VDKCustom::EnableTitles(bool flag)
{
for(int t = 0; t < columns; t++)
  Titles[t]->Enable(flag);
}
/*
 */ 
GtkSelectionMode
VDKCustom::SelectionMode()  {  return mode; }

/*
 */ 
void
VDKCustom::ColumnSize(int col, int size)
{
if(col < 0 || col >= columns)
  return ;
gtk_clist_set_column_width (GTK_CLIST(custom_widget), col, size);
return;
}
/*
 */
void 
VDKCustom::SetAutoResize(bool flag)
{
  for(int i = 0; i < columns; i++)
    gtk_clist_set_column_auto_resize(GTK_CLIST(custom_widget),
				    i, (gboolean) flag);
  
}
/*
 */
void 
VDKCustom::AutoResizeColumn(int col,bool flag)
{
  gtk_clist_set_column_resizeable(GTK_CLIST(custom_widget),
				  col, (gboolean) flag);
}
