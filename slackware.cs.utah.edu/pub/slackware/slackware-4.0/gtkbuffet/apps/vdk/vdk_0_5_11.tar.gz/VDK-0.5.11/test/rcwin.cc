/*
file: rcwin.cc
*/
#include "rcwin.h"
 
void
RcWin::Setup()
{
VDKBox* box = new VDKBox(this,v_box);
box->Add(text = new VDKText(this));
Add(box);
}
/*
 */
void
RcWin::OnShow(VDKForm*)
{
text->LoadFromFile(file);
}




