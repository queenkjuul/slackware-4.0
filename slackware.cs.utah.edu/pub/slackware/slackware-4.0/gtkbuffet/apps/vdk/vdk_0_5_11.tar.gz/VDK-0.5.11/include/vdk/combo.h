/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-130
 */ 
/* This is a wrapper for GtkCombo.
   Author: Eric T. Wienke <eric@liquidsilver.com>
   =====================================================================
   Limitations: Listitems only setable via SetPopdownStrings which gets
   mapped to gtk_list_item_new_with_label. There is no high-level
   interface to GtkList and GtkListItem which would allow to insert
   any object to the List. Probably not really needed for a Combobox
   anyway.
   One problem is that the GetPopdownStrings won't work if Gtk functions
   are used to add anything else to the ListItems.
   Possible solution: Write wrappers for GtkList and GtkListItem and and
   provide a interface for them in the VDKCombo class. (too much work for
   this widget alone, would GtkList be of any other use?)
   ======================================================================
*/

#ifndef  _combo_h_
#define  _combo_h_

#include <vdk/vdkobj.h>
#include <vdk/value_sem_list.h>


typedef VDKValueList<VDKString> StringList;
typedef VDKValueListIterator<VDKString> StringListIterator;

/*
 */
class VDKCombo: public VDKObject
{
  static void FocusOutEvent(GtkWidget *w,
			    GdkEventFocus *event,
			    gpointer wid);
  static void FocusInEvent(GtkWidget *w,
			    GdkEventFocus *event,
			    gpointer wid);
 protected:
  int changeConnect;
  VDKObjectSignal s_activated, s_changed, s_selected;
  GList *popdownlist;
  StringList popdownstr;
  void SortList();
public:
  // properties
  VDKReadWriteValueProp<VDKCombo,char*> Text;
  VDKReadWriteValueProp<VDKCombo,bool>  Editable;
  VDKReadWriteValueProp<VDKCombo,bool>  Sorted;
  VDKReadWriteValueProp<VDKCombo,bool>  Hidden;
  VDKReadWriteValueProp<VDKCombo,bool>  CaseSensitive;
  VDKReadWriteValueProp<VDKCombo,StringList> PopdownStrings;
  VDKReadOnlyValueProp<VDKCombo,int> Selected;
  //
  VDKCombo(VDKForm* owner, char* def = (char*) NULL);
  virtual ~VDKCombo();
  void SetText(char* text);
  char* GetText(); 
  void SetEditable(bool flag)
    { gtk_entry_set_editable(GTK_ENTRY(GTK_COMBO(widget)->entry),flag); }
  bool GetEditable() 
    { return Editable; }
  void SetSorted(bool flag) 
    { if(flag && !Sorted) SortList(); }
  bool GetSorted() 
    { return Sorted; }
  void SetBackground(VDKRgb rgb, 
		     GtkStateType state);
  void SetHidden(bool flag)
    { gtk_entry_set_visibility(GTK_ENTRY(GTK_COMBO(widget)->entry), ! flag) ; }
  bool GetHidden()
    { return ! Hidden; }
  void SetPopdownStrings(StringList);
  StringList GetPopdownStrings();
  void SetCaseSensitive(bool flag)
    { gtk_combo_set_case_sensitive(GTK_COMBO(widget),flag); }
  bool GetCaseSensitive()
    { return (bool)(GTK_COMBO(widget)->case_sensitive); }
  void UseArrows(bool flag)
    { gtk_combo_set_use_arrows(GTK_COMBO(widget),flag); }
  void UseArrowsAlways(bool flag)
    { gtk_combo_set_use_arrows_always(GTK_COMBO(widget),flag); }
  void SetValueInList(int val, bool ok_if_empty)
    { gtk_combo_set_value_in_list(GTK_COMBO(widget),val,ok_if_empty); }
  void ClearList();
  void SelectItem(int item)
    { gtk_list_select_item(GTK_LIST(GTK_COMBO(widget)->list), item); }
  void UnselectItem(int item)
    { gtk_list_unselect_item(GTK_LIST(GTK_COMBO(widget)->list), item); }
  int GetSelected();
};
#endif
/*
not implemented:
void gtk_combo_set_item_string (GtkCombo *combo, GtkItem *item, gchar *item_value) 
Probably useless until GtkList and GtkListItem are implemented.
*/
