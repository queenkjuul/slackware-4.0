/*
 * ===========================
 * VDK Visual Developement Kit
 * Version 0.5
 * December 1998
 * ===========================
 *
 * Copyright (C) 1998, Ionutz Borcoman
 * Developed by Ionutz Borcoman <borco@borco-ei.eng.hokudai.ac.jp>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#ifndef _shaped_button_h_
#define _shaped_button_h_

#include <vdk/vdk.h>
#include <vdk/fixed.h>

class VDKShapedButton: public VDKFixed{
  bool					_down;
  bool					_in;

  VDKRawPixmap			*_pix;
  VDKRawPixmap			*_pixH;
  VDKPixmap				*_pixmap;

  static int onPress(GtkWidget *, GdkEvent*, gpointer gp);
  static int onRelease(GtkWidget *, GdkEvent*, gpointer gp);
  static int onEnter(GtkWidget *, GdkEvent*, gpointer gp);
  static int onLeave(GtkWidget *, GdkEvent*, gpointer gp);

public:
  VDKShapedButton(VDKForm* owner,char* pixfile,char* pixHfile, char * tooltip);
  ~VDKShapedButton(){};

};

#endif
