/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.5.0
 * November 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */
#include <vdk/vdkeditor.h>

VDKEditor::VDKEditor(VDKForm*owner,bool editable):
  VDKText(owner, editable, true)
{
  widget = gtk_hbox_new(FALSE,1);
  gtk_container_border_width(GTK_CONTAINER(widget),0);
  text = gtk_editor_new(NULL,NULL);
  gtk_text_set_editable(GTK_TEXT(text),editable);
  gtk_box_pack_start(GTK_BOX(widget),text,TRUE,TRUE,0);
  scrollbar = gtk_vscrollbar_new(GTK_TEXT(text)->vadj);
  gtk_box_pack_start(GTK_BOX(widget),scrollbar,FALSE,TRUE,0);
  gtk_widget_show(text);
  gtk_widget_show(scrollbar);
  /* setup event handler */   
  gtk_signal_connect (GTK_OBJECT (text), "key_press_event", 
		      GTK_SIGNAL_FUNC (VDKText::KeyEvent), this);
  ConnectDefaultSignals();
}
/*
 */
VDKEditor::~VDKEditor()
{
} 
/*
 */
int 
VDKEditor::LoadFromFile(char* filename)
{
  int result = VDKText::LoadFromFile(filename);
  if(result)
    {
       gtk_text_set_point (GTK_TEXT (text), 0);
       gtk_editor_hilite_screen (GTK_EDITOR(text));
    }
  return result;
}
/*
 */
void  VDKEditor::SetFont(VDKFont* font)
{
if(font)
  {
    GtkStyle* style = gtk_style_copy(gtk_widget_get_style(GTK_WIDGET(text))) ;
    gtk_style_ref(style);
    style->font = *font;
    gtk_widget_set_style(GTK_WIDGET(text),style);
  }
}
/*
 */
/////////////////////////////
/* hilite pattern test */
/* syntax table test */
void
VDKEditor::install_st (void)
{
  GdkColor red, brownish;
  GList *entries;
  GdkColormap *cmap = 
    gtk_widget_get_colormap(GTK_WIDGET (text));

  red.pixel = 0;
  red.red = 65535;
  red.green = 0;
  red.blue = 0;

  brownish.pixel = 0;
  brownish.red = 65535;
  brownish.green = 43908;
  brownish.blue = 16383;

  gdk_color_alloc(cmap, &red);
  gdk_color_alloc(cmap, &brownish);
  
  entries = gtk_editor_stentry_new 
    ("C-comment",
     "/\\*", "\\*/", 
     FALSE,
     NULL, &red, NULL,
     gtk_editor_stentry_new ("C++-comment",
			     "//", "\n", FALSE,
			     TextFont.font != NULL? 
			     *TextFont.font:
			     (GdkFont*) NULL, &red, NULL,
			     gtk_editor_stentry_new 
			     ("string",
			      "\"", "\"", FALSE,
			      TextFont.font != NULL? 
			      *TextFont.font:
			      (GdkFont*) NULL, &brownish, NULL,
			      gtk_editor_stentry_new 
			      ("chars",
			       "'", "'", FALSE,
			       TextFont.font != NULL? 
			       *TextFont.font:
			       (GdkFont*) NULL, &brownish, NULL,
			       NULL))));
  gtk_editor_install_stable (GTK_EDITOR(text), entries);
  gtk_editor_free_stentries (entries);
  /*
  gdk_gc_set_font(GTK_WIDGET(text)->style->fg_gc[GTK_WIDGET_STATE(text)],
		  TextFont.font != NULL ? 
			       *TextFont.font:
			       (GdkFont*) NULL);
  */
}

/*
 */
void
VDKEditor::install_pat (void)
{
  GdkColor blue, green;
  GList *entries;
  GdkColormap *cmap = gtk_widget_get_colormap (GTK_WIDGET (text));

  blue.pixel = 0;
  blue.red = 0;
  blue.green = 0;
  blue.blue = 65535;

  green.pixel = 0;
  green.red = 0;
  green.green = 65535;
  green.blue = 0;


  gdk_color_alloc (cmap, &blue);
  gdk_color_alloc (cmap, &green);

  entries = gtk_editor_pentry_new ("keywords",
				   "\\b\\(while\\|for\\|if\\|else\\)\\b",
				   TextFont.font != NULL? 
				   *TextFont.font:
				   (GdkFont*) NULL, &blue, NULL,
            gtk_editor_pentry_new ("foobar",
				   "\\b\\(foo\\|bar\\|baz\\)\\b",
				   TextFont.font != NULL? 
				   *TextFont.font:
				   (GdkFont*) NULL, &green, NULL, NULL));

  gtk_editor_install_patterns (GTK_EDITOR(text), entries);
  gtk_editor_free_pentries (entries);
}
 

