/*
file: nbookwin.h
*/
#include <vdk/vdk.h> 
class NoteBookWin: public VDKForm
{
  VDKNotebook  *book;
  VDKLabelButton *quit,*next,*prev,*rotate,*enable;
  VDKCustomList *list;
  VDKEntry *firstname,*address,*city,*phonenumber;
public:
  NoteBookWin(VDKForm* owner):
    VDKForm(owner,"This shows a notebook") {}
  ~NoteBookWin() {}
  void Setup();
  bool NextTab(VDKObject* );
  bool PrevTab(VDKObject* );
  bool RotateTab(VDKObject*); 
  bool EnableTab(VDKObject*); 
  void MakePage1();
  void MakePage2();
  bool ListSelection(VDKObject*);
  bool ListUnselection(VDKObject*);
  bool Quit(VDKObject*) { Close(); return true; }
  DECLARE_SIGNAL_MAP(NoteBookWin);
};
