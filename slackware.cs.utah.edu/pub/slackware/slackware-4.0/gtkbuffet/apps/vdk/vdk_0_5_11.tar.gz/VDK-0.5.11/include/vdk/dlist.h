/*
 * ===========================
 * VDK Visual Develeopment Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#ifndef _double_list_h
#define _double_list_h
// just a cosmetic capitalizing (suggestion by Ionutz Borcoman)
#define VDKListIterator VDKListiterator
/*
  ============
  VDKItem class
  ============
  */
template <class T> class VDKItem 
{

 public:
  T* x;
  VDKItem* next,*prev;
  VDKItem(T* x): x(x), next((VDKItem<T>*) 0),prev((VDKItem<T>*)0) 
    {
    }
~VDKItem() 
  {
  }
};
/*
================
doublelist class
================
*/

template <class T> class VDKList 
{
  
  VDKItem<T>* head,* tail;
  int count;
  
  // append to list
  void addToTail(VDKItem<T>* i) 
    {
      if(! head) head = tail = i;
      else { tail->next = i; i->prev=tail; tail = i; }
      count++;
    }
  // over head loading
  void addToHead(VDKItem<T>* i) 
    {
      if(! head) head = tail = i;
      else { head->prev = i; i->next = head; head = i; }
      count++;
    }
  // insert in order
  //void insertVDKItem(VDKItem<T>* i);
  
  // fetch an VDKItem at <n> position
  VDKItem<T>* fetch(int n);  
  
  // assign VDKItems to container
  void assign(VDKList& l);
  // on reference semantic copy-assign is prohibited 
  VDKList(VDKList& c) 
    {
      count = 0;
      head = tail = (VDKItem<T>* ) 0;
      assign(c);
    }
  
  VDKList& operator=(VDKList<T>& l) 
    {
      // avoid l = l;
      if(this != &l) { flush(); assign(l); }
      return *this;
    }

  /* class interface methods */
 public:
  VDKList() : head(0),tail(0),count(0) {}  
  ~VDKList() { flush(); } 
  /*
    since these liste serves only to manage
    new'ed objects ptrs, we must assure
    do not insert a obj ptr twice
    otherwise the same obj will be
    destroyed twice.. (crash !!)
  */
  void add(T* t) 
    { 
      if(!find(t))
	 addToTail(new VDKItem<T>(t)); 
    }
  void addH(T* t) 
    { 
      if(! find(t))
	addToHead(new VDKItem<T>(t)); 
    }
  T* find(T* x);
  T* listhead() { return fetch(0)->x; }
  // find position of type<T> object
  int at(T* x);
  T* operator[](int n) { return fetch(n)->x; }
  int  remove(T* x);
  int size() { return count; }
  void flush();
  VDKItem<T>* Head() { return head; }
};

/*
  ==================
  VDKList iterator
  ==================
  */
template <class T> class VDKListiterator 
{

  VDKItem<T> *head,*p;
 public:
  VDKListiterator(VDKList<T>& c) { p = head = c.Head(); }
  virtual ~VDKListiterator() {}
  void operator++() { p = p->next; }
  void operator++(int) { p = p->next; }
  operator int() { return p != (VDKItem<T>*) 0; }
  T* current() { return p->x; }
  VDKItem<T>* Next(VDKItem<T> *t) { return t->next;}
  VDKItem<T>* Head() { return head; }
  T* Now(VDKItem<T> * t) { return t->x; } 
  void restart() { p = head; }
};
//	 								
//NON-INLINE MEMBER FUNCTIONS
/*=======================
  PRIVATE:
  assign VDKItems copyng them
  from another list
  =======================*/
template <class T>
void VDKList<T>::assign(VDKList<T>& l) 
{
  VDKListiterator<T> ci(l);
  while(ci) { add(ci.current()); ci++; }
}

/*==========================
  PRIVATE:
  fetch VDKItem<T> at n position
  ===========================*/
template <class T>
VDKItem<T>* VDKList<T>::fetch(int n) {
  int t = 0;
  if(n >= count || n < 0) return (VDKItem<T>*) 0;
  VDKItem<T>* p = head;
  for( ;p && (t < n) ; t++, p = p->next);
  return p;
}
/*================================
  PRIVATE:
  find ordinal position of VDKItem
  containing a type<T> object,
  return -1 if not found
  ================================*/
template <class T>
int VDKList<T>::at(T* x) {
  register int t = 0;
  VDKItem<T>* p = head;
  for(; p && (p->x != x);p = p->next,t++) ;
  return p ? t : -1;
}
/*===========
  flushes list
  ============*/
template <class T>
void VDKList<T>::flush() 
{
  VDKItem<T>*p = head;
  VDKItem<T>*p1;
  while(p) {
    p1 = p->next;
    delete p;
    p = p1;
  }
  head = tail = 0;
  count = 0;
}
/*
  ============================
  find(type<T>) , iterate
  over container to find
  an object. 
  hint: compare pointers only..
  so is good only for identities.. 
  ============================
*/
template <class T>
T* VDKList<T>::find(T* x) {
  VDKItem<T>* p;
  for(p = head; p && (p->x != x); p = p->next) ;
return p ? p->x : (T*) 0;
}

/*
============================
remove a type<T>.
Return a 1 or 0 (not removed)
==============================
*/
template <class T>
int VDKList<T>::remove(T* x) 
{
  VDKItem<T>* cur;
  int n = at(x);
  // object not found
       if(n < 0) return 0;
       else cur = fetch(n);
  // removing head
       if(cur == head) {
	 head = cur->next;
	 // one element list
	      if(head != (VDKItem<T>*) 0) head->prev = (VDKItem<T>*) 0;
	      else tail = (VDKItem<T>*) 0;
       }
       else { // remove tail or intermediate element
		   cur->prev->next = cur->next;
       if(cur != tail) cur->next->prev = cur->prev;
       // remove tail
	    else tail = cur->prev;
       }
  delete cur;
  count--;
  return 1;
}
#endif





