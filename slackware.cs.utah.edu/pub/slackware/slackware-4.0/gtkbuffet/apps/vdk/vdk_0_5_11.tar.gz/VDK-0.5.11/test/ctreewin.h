/*
file: ctreewin.h
*/
#include <vdk/vdk.h>
class TreeWindow: public VDKForm
{
  VDKCustomTree *tree; 
  VDKLabelButton *quit,*remove,*build,*clear;
 public:
  TreeWindow(VDKForm* owner):
    VDKForm(owner,"Custom tree example")  {}
  ~TreeWindow() { }
  void Setup();
  bool Quit(VDKObject*);
  bool ShowSelection(VDKObject*);
  bool ShowExtendedSelection(VDKObject* obj, GdkEvent*);
  bool ClearTree(VDKObject* obj);
  bool RemoveSelection(VDKObject*);
  bool BuildTree(VDKObject*);

DECLARE_SIGNAL_LIST(TreeWindow);
DECLARE_EVENT_LIST(TreeWindow);
DECLARE_SIGNAL_MAP(TreeWindow);
};


