/*
file: panedwin.h
*/
#include <vdk/vdk.h>
class PanedWin: public VDKForm
{
  VDKPaned *paned;
  VDKPixmap *nicegirl,*monet;
  VDKLabelButton *quit,*flip;
public:
  PanedWin(VDKForm* owner):
    VDKForm(owner,"This shows a paned widget") {}
  ~PanedWin() {}
  void Setup();
  bool Flip(VDKObject*);
  bool Quit(VDKObject*) { Close(); return true; }
  DECLARE_SIGNAL_MAP(PanedWin);
};
