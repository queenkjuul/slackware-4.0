/*
 * ===========================
 * VDK Visual Develeopment Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#ifndef  _vdkcanvas_h_
#define  _vdkcanvas_h_ 

#include <vdk/vdkobj.h>
#include <vdk/colors.h>
#include <vdk/rawpixmap.h>
class VDKCanvas: public VDKObject
{
  bool dragFlag,startdragFlag;
  VDKColor* background;
  void DrawBackground();
  bool setFg,setBg,setF;
 public:
  static void ConfigureEvent(GtkWidget* w, GdkEventConfigure* event, void* o);
  static void ExposeEvent(GtkWidget* w, GdkEventExpose* event, void* o);
  static void ButtonPressEvent(GtkWidget* w, GdkEventButton* event, void* o);
  static void ButtonReleaseEvent(GtkWidget* w, GdkEventButton* event, void* o);
  static void MotionNotifyEvent(GtkWidget* w, GdkEventMotion* event, void* o);
  
  GdkPixmap *pixmap;
 public:
  VDKCanvas(VDKForm* owner, int w = 100, int h = 100);
  virtual ~VDKCanvas();
  void Clear();
  void DrawString(int x, int y, char* text);
  void DrawText(int x, int y, char* text, int n);
  void DrawPoint(int x, int y);
  void DrawLine(int x, int y, int x1, int y1);
  void DrawRect(int x, int y, int w, int h);
  void DrawArc(int filled,int x,int y, int width, 
	       int height,int angle1, int angle2);
  void DrawPolygon(int filled,GdkPoint *points, gint npoints);
  void DrawPoints(GdkPoint *points, int npoints);
  void DrawSegments(GdkSegment *segs, int nsegs);
  void DrawLines(GdkPoint *points, int npoints);
  void DrawPixmap(int x, int y,char *pixfile);
  void DrawPixmap(int x, int y, VDKRawPixmap* pix);
  void DrawPixmap(int x, int y, char ** data);
  void Redraw(); // with no expose
  // with no expose
  void SetForeground(VDKRgb color, GtkStateType state = GTK_STATE_NORMAL)
    { setFg = true; VDKObject::SetForeground(color,state); }
  void SetBackground(VDKRgb color, GtkStateType state = GTK_STATE_NORMAL)
    { setBg = true; VDKObject::SetBackground(color,state); }
  void SetFont(VDKFont* f)
    { setF = true; VDKObject::SetFont(f); }
};

#endif
