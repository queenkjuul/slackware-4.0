/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * Revision 0.2
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */


#ifndef _menu_h
#define _menu_h
#include <vdk/vdkobj.h>
#include <vdk/dlist.h>
#include <vdk/vdktypes.h>

class VDKForms;
class VDKMenubar;
class VDKOptionMenu;

/*
 */
class VDKMenu: public VDKObject
{

public:
  //  GtkAcceleratorTable* acTable;
  VDKMenu(VDKForm* owner);
  virtual ~VDKMenu();
  void Separator();
  virtual void SetFont(VDKFont* font);
  void Popup(guint button = 0,  guint32 activate_time = 0);
};

/*
 */
class VDKMenuItem: public VDKObject
{
  VDKObjectSignal s_activated;
  VDKMenu* menu;
  GtkWidget *box,*lbl,*pixmapWidget, *tickWidget;
  GdkPixmap* pixmap,*tickPixmap;
  bool ticked;
public:
  VDKMenuItem(VDKMenu* menu ,
	      char* prompt, 
	      char** pixmap = NULL,
	      char key = 0,
	      guint8 modkey = 0);
  VDKMenuItem(VDKMenubar* bar, 
	      char* prompt, char** pixmap = NULL,
	      int align = l_justify);
  virtual ~VDKMenuItem();
  void Add(VDKMenu* submenu);
  void Tick(bool flag);
  bool Checked() { return ticked; }
  virtual void SetFont(VDKFont* font);
}; 

/*
 */
class VDKMenubar: public VDKObject
{
public:
  VDKMenubar(VDKForm* owner);
  ~VDKMenubar();
  virtual void SetFont(VDKFont* font);
};

/*
 */
class VDKOptionMenu: public VDKObject
{
public:
  VDKOptionMenu(VDKForm* owner);
  ~VDKOptionMenu();
  void Add(VDKMenu* menu);
  virtual void SetFont(VDKFont* ) {}
};


#endif

