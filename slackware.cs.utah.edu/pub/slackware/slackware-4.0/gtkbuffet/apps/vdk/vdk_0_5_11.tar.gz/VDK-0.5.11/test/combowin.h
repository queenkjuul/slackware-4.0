/*
file: combowin.h
*/
#include <vdk/vdk.h>
#include <vdk/combo.h>
class ComboWin: public VDKForm
{
    VDKBox *entrybox1,*entrybox2,*entriesbox;
    VDKCombo *combobox;
    VDKLabel *label,*label2;
    VDKRadioButtonGroup *arrows;
    VDKRadioButton *arrows_on,*arrows_off;
    VDKLabelButton *buttonclear, *buttonadd;
public:
    
    ComboWin(VDKForm* owner, char* title = "Wrapping combo box"):
      VDKForm(owner,title) {}
    ~ComboWin() {}
    void Setup();
    
    // response functions
    bool Quit(VDKObject*);
    bool OnComboChange(VDKObject*);
    bool OnArrowToggle(VDKObject*);
    bool OnClearClick(VDKObject*);
    bool OnAddClick(VDKObject*);
    DECLARE_SIGNAL_MAP(ComboWin); 
};  



