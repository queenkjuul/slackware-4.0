/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
*/

#include <vdk/forms.h>
#include <vdk/vdkobj.h>
#include <gdk/gdkkeysyms.h>
#include <assert.h>
#include <vdk/colors.h>
#include <vdk/vdkfont.h>
#include <vdk/boxes.h>
#include <vdk/rawpixmap.h>
#include <gdk/gdkx.h>

#ifdef VDKDEBUG
int formC = 0;
int formD = 0;
int childRemoved = 0;
int objRemoved = 0;
#endif
/////////// ICONIFY STUFF /////////////
/* to iconify an existing window */
static void gdk_window_iconize (GdkWindow *window);
/* to maximise an existing window */
static void window_deiconify (GdkWindow *window);
/* to test if ... */
static gboolean window_is_iconified (GdkWindow *window);

/* to iconify an existing window */

void gdk_window_iconize (GdkWindow *window)
{
GdkWindowPrivate *Private;

g_return_if_fail (window != NULL);

Private = (GdkWindowPrivate*) window;
if (!Private->destroyed)
XIconifyWindow (Private->xdisplay, Private->xwindow,0);
}

/* to maximise an existing window */

void
window_deiconify (GdkWindow *window)
{
GdkWindowPrivate *Private;

Private = (GdkWindowPrivate*) window;
XMapRaised (Private->xdisplay, Private->xwindow);
} 

/* to test if ... */

gboolean
window_is_iconified (GdkWindow *window)
{
XWindowAttributes xattr;
GdkWindowPrivate *Private;

Private = (GdkWindowPrivate*) window;

xattr.map_state = IsUnmapped;
XGetWindowAttributes(Private->xdisplay, Private->xwindow, &xattr);
return (xattr.map_state == IsUnmapped); 
}
/*
 */
bool 
VDKForm::GetIconized()
{
return window_is_iconified(window->window);
}
/*
 */
void 
VDKForm::SetIconized(bool flag)
{
if(flag  && ! GetIconized())
  {
    gdk_window_iconize(window->window);
    OnIconize(this);
  }
else if (! flag && GetIconized())
  {
    window_deiconify(window->window);
    OnRestore(this);
  }
}
/*
 */
void 
VDKForm::OnIconize(VDKForm* sender) {}
void 
VDKForm::OnRestore(VDKForm* sender) {}
/////////////////////////////////////
/*
Delete event handler.
Checks if there are some
modals open up to the hierarchy,
in such case does not allow closure,
otherwise call CanClose()
 */
int VDKForm::DeleteEvent(GtkWidget* , GdkEvent* , gpointer gp)
{
  g_return_val_if_fail(gp != NULL,TRUE);
  VDKForm* form = reinterpret_cast<VDKForm*>(gp);
  if(!form->isModal)
    {
      bool doclose  =  !form->modalCount;
      VDKForm* own;
      for(own = form->Owner(); own; own = own->Owner())
	{
	  if(own->modalCount)
	    {
	      doclose = false;
	      break;
	    }
	}
      if(!doclose)
	return TRUE;
    }
  return form->CanClose() ? FALSE : TRUE;    
}
/*
Destroy event handler:
- if the form is modal one,close it.
- if the form is main form terminate app
Closes recursively all childs, remove himself
from owner list and notify his closure to
owner.
 */
void VDKForm::DestroyEvent (GtkWidget*, gpointer gp)
{
  g_return_if_fail(gp != NULL);
  VDKForm* form = reinterpret_cast<VDKForm*>(gp);
  // in modal form stops inner event loop
  // and re-activates parent
  if(form->IsModal())
    {
      form->Owner()->modalCount--;
      //--- gtk_grab_remove(form->Window()); 
      gtk_main_quit();
    }
  // Only MainForm does not have parent, so closes application
  if(!form->Owner()) 
    form->Application()->Terminate();
  else
    {
      form->CloseChilds();
      form->Owner()->RemoveChild(form);
      form->Owner()->OnChildClosing(form);
    }
}
/*
 */
void VDKForm::ConfigureEvent(GtkWidget* , GdkEventConfigure* ev , gpointer gp)
{
  g_return_if_fail(gp != NULL);
  VDKForm* form = reinterpret_cast<VDKForm*>(gp);
  VDKPoint p = form->Position;
  VDKPoint s(ev->width,ev->height);
  if(form->never_showed)
    {
      form->never_showed = false;
      // sets form initial position
      form->_oldPos = form->Position;
      form->Position(form->_oldPos);
      form->_oldSize = s;
      form->OnShow(form);
    }
  else if (p != form->_oldPos)
    {
      form->_oldPos = p;
      form->OnMove(form);
    }
  else if(s != form->_oldSize)
    {
      form->_oldSize = s;
      form->OnResize(form,s);
    }
  form->OnConfigure(form);   
}
/*
 */
void VDKForm::ExposeEvent(GtkWidget* , GdkEventExpose* ev, gpointer gp)
{
  // handle only last expose event 
  // TODO: check if it is a good strategy...
  g_return_if_fail(ev != NULL);
  g_return_if_fail(gp != NULL);
  if(ev->count == 0)
    {
      VDKForm* form = reinterpret_cast<VDKForm*>(gp);
      g_return_if_fail(form != NULL);
      form->OnExpose(form, ev->area);
    }
}
/*
 */
void VDKForm::RealizeSignal(GtkWidget* , gpointer gp)
{
  g_return_if_fail(gp != NULL);
  VDKForm* form = reinterpret_cast<VDKForm*>(gp);
  VDKPoint pos = form->Position;
  
  form->OnRealize(form);
}
/*
 */
void VDKForm::MapEvent(GtkWidget* , GdkEvent* ev ,gpointer gp)
{
  g_return_if_fail(gp != NULL);
  VDKForm* form = reinterpret_cast<VDKForm*>(gp);
  if( ! form->never_showed)
    form->OnRestore(form);
}
/*
 */
void VDKForm::UnmapEvent(GtkWidget* , GdkEvent* ev ,gpointer gp)
{
  g_return_if_fail(gp != NULL);
  VDKForm* form = reinterpret_cast<VDKForm*>(gp);
    form->OnIconize(form);
}
/* 
==================================================
*/
// MainForm constructor

VDKForm::VDKForm(VDKApplication* app, gchar *title, 
		 int mode, GtkWindowType display):
  VDKObject(NULL),
  app(app),
  // properties
  Visible("Visible",this,true,&VDKForm::SetVisible,&VDKForm::GetVisible),
  Title("Title",this,
	title ? VDKString(title) : VDKString(""),&VDKForm::SetTitle),
  Position("Position",this,VDKPoint(0,0),
	   &VDKForm::SetPosition,&VDKForm::GetPosition),
  Iconized("Iconized",this,false,
	   &VDKForm::SetIconized,&VDKForm::GetIconized)
  
{
  isModal = false;
  modalCount = 0;
  never_showed = true;
  assert(app->MainForm == NULL || ! "MainForm");
  widget = window = sigwid = gtk_window_new (display);
  if(title)
    gtk_window_set_title(GTK_WINDOW(window),title);
  // sets the border width of the window
  gtk_container_border_width (GTK_CONTAINER (window),1);
  box = new VDKBox(this,mode);
  items.add(box);
  //
  gtk_container_add(GTK_CONTAINER(window),box->Widget());
  gtk_widget_show(box->Widget());
  box->Parent(this);
  //connect signals  
  SignalsConnect();
  gtk_widget_realize(window);
#ifdef VDKDEBUG
  formC++;
#endif
}
/*
 */
void VDKForm::SignalsConnect()
{
gtk_signal_connect (GTK_OBJECT (window), "delete_event",
		      GTK_SIGNAL_FUNC (VDKForm::DeleteEvent), this);
gtk_signal_connect (GTK_OBJECT (window), "destroy",
		    GTK_SIGNAL_FUNC (VDKForm::DestroyEvent), this);
gtk_signal_connect (GTK_OBJECT (window), "configure_event",
		    GTK_SIGNAL_FUNC(VDKForm::ConfigureEvent),this);
gtk_signal_connect (GTK_OBJECT (window), "expose_event",
		    GTK_SIGNAL_FUNC(VDKForm::ExposeEvent),this);
gtk_signal_connect(GTK_OBJECT(window),"realize",
		   GTK_SIGNAL_FUNC(VDKForm::RealizeSignal),this);
gtk_signal_connect(GTK_OBJECT(window),"map_event",
		   GTK_SIGNAL_FUNC(VDKForm::MapEvent),this);
gtk_signal_connect(GTK_OBJECT(window),"unmap_event",
		   GTK_SIGNAL_FUNC(VDKForm::UnmapEvent),this);
}


/*
 */
VDKForm::VDKForm(VDKForm* owner, gchar* title , 
		 int mode, GtkWindowType display):
  VDKObject(owner),
  app(owner->Application()),
  Visible("Visible",this,true,&VDKForm::SetVisible,&VDKForm::GetVisible),
  Title("Title",this,
	title ? VDKString(title) : VDKString(""),&VDKForm::SetTitle),
  Position("Position",this,VDKPoint(0,0),
	   &VDKForm::SetPosition,&VDKForm::GetPosition),
  Iconized("Iconized",this,false,
	   &VDKForm::SetIconized,&VDKForm::GetIconized)
{
  isModal = false;        
  modalCount = 0;    
  never_showed = true;
  widget = window = gtk_window_new (display);
  if(title)
    gtk_window_set_title(GTK_WINDOW(window),title);
  // sets the border width of the window
  gtk_container_border_width (GTK_CONTAINER (window), 1); 
  box = new VDKBox(this,mode);
  items.add(box);
  gtk_container_add(GTK_CONTAINER(window),box->Widget());
  gtk_widget_show(box->Widget());
  box->Parent(this);
  // connect signals
  SignalsConnect();
  gtk_widget_realize(window);
  owner->AddChild(this);
  
#ifdef VDKDEBUG
  formC++;
#endif
}

/*
called whenever user does not override
*/
void VDKForm::Setup(void)
{
  gtk_widget_set_usize(GTK_WIDGET(box->Widget()),300,150);
}
/*
Destructor
 */
VDKForm::~VDKForm()
{
  // delete childs
  ChildListIterator li(childs);
  for(;li;li++)
    delete li.current();
  // STUB
  // delete raw objects
  /*
    RawListIterator lr(raws);
    for(;lr;lr++)
      delete lr.current();
  */
    CollectGarbage();
#ifdef VDKDEBUG
  formD++;
#endif
}

/*
CollectGarbage
*/
void VDKForm::CollectGarbage()
{

#ifdef VDKDEBUG
  int childs = 0;
  int objs = 0;
#endif
  // delete childs garbage
  ChildListIterator li(childsGarbage);
  VDKItem<VDKForm> *p = li.Head();
  VDKItem<VDKForm> *p1;
  while(p)
    {
#ifdef VDKDEBUG
      childs++;
#endif
      p1 = li.Next(p);
      delete li.Now(p);
      p = p1;
    }
  // this should be done
  // now so a new garbage will find
  // an empty list.
  childsGarbage.flush();
  // delete items garbage
  ItemListIterator lo(garbages);
  VDKItem<VDKObject> *o = lo.Head();
  VDKItem<VDKObject> *o1;
  while(o)
    {
#ifdef VDKDEBUG
      objs++;
#endif
      o1 = lo.Next(o);
      delete  lo.Now(o);
      o = o1;
    }
  // this should be done
  // now..
  garbages.flush();
  
#ifdef VDKDEBUG
  if(childs || objs)
    {
      printf("\nGarbage collect: %d child(s), %d object(s)",
	     childs,objs);
      fflush(stdout);
    }
#endif
}
/*
removes child
*/
void VDKForm::RemoveChild(VDKForm* child) 
{   
  if(childs.remove(child))
    {
      childsGarbage.add(child);
#ifdef VDKDEBUG
      childRemoved++;
#endif
      // removes child objects    
      ItemListIterator li(child->Items());
      for(;li;li++)
	{
	  li.current()->RemoveItems();
	  child->Garbages().add(li.current());
	}
#ifdef VDKDEBUG
      objRemoved += child->Items().size();
#endif
      child->Items().flush();
    }
}
/* 
   explicitely destroy this
*/ 

bool VDKForm::Destroy()
{
if(Owner() && ( Owner()->Childs().remove(this)  || 
     Owner()->ChildsGarbage().remove(this)) )
   {
     delete this;
     return true;
   }
else
  return false;
}

/*
  shows form:
  pos can be:
  - GTK_WIN_POS_NONE, (default)
  - GTK_WIN_POS_CENTER,
  - GTK_WIN_POS_MOUSE
  iteratively shows all childs
  */
void  VDKForm::Show( GtkWindowPosition pos)
{
  if(pos != GTK_WIN_POS_NONE)
    gtk_window_position(GTK_WINDOW(Window()),pos);
  gtk_widget_show (window);
  ChildListIterator li(childs);
  for(;li;li++)
    gtk_widget_show (li.current()->Window());
}
/*
iteratively hides all childs 
 */
void VDKForm::Hide()
{
  gtk_widget_hide (window);
  ChildListIterator li(childs);
  for(;li;li++)
    gtk_widget_hide (li.current()->Window());
}
/*
shows modal
*/
void VDKForm::ShowModal(GtkWindowPosition pos)
{
  isModal = true;
  Owner()->modalCount++;
  gtk_window_set_modal (GTK_WINDOW(window),TRUE);
  if(owner)
    // this makes modal child
    // to stay always on top
    // of his parent.
    // modal cannot be closed with WM sys menu
    // if parent is iconized modal will be as well
    gtk_window_set_transient_for(
		  GTK_WINDOW(window),
		  GTK_WINDOW(owner->Window())
		  );

  Show(pos);
  gtk_main();
}
/*
add a child window
*/
void VDKForm::AddChild(VDKForm* child) 
{ 
  childs.add(child); 
  child->Parent(this);
}
/*
add an object
*/
void VDKForm::Add(VDKObject* obj, int justify,
		  int expand, int fill, int padding)
{
  items.add(obj);
  obj->Setup(); 
  switch (justify)
    {
    case l_justify:
      gtk_box_pack_start(GTK_BOX(box->Widget()), 
			 obj->Widget(),expand,fill,padding);
      break;
    case r_justify:
      gtk_box_pack_end(GTK_BOX(box->Widget()), 
		       obj->Widget(),expand,fill,padding);
      break;
    default:
      gtk_box_pack_start(GTK_BOX(box->Widget()), 
			 obj->Widget(),expand,fill,padding);
    }
  gtk_widget_show(obj->Widget());
  obj->Parent(box);
}

/*
closes form
*/
void VDKForm::Close(void)
{
  
  if( GTK_IS_WIDGET(window) && !DeleteEvent(NULL,NULL,this))
    gtk_widget_destroy(window);
}
/*
closes form childs
(internally used)
*/
void VDKForm::CloseChilds(void)
{
  ChildListIterator li(childs);
  VDKItem<VDKForm> *p = li.Head();
  VDKItem<VDKForm> *p1;
  while(p)
    {
      p1 = li.Next(p);
      li.Now(p)->Close();
      p = p1;
    }
  /* */
  childs.flush();
}

/*
query to close form
*/
bool VDKForm::CanClose()
{
  return true;
}


/*
 */
void VDKForm::Raise()
{
  if(Visible)
    gdk_window_raise(window->window);
}
/*
 */
void VDKForm::Lower()
{
  if(Visible)
    gdk_window_lower(window->window);
}

/*
 */
void VDKForm::SetIcon(VDKRawPixmap* pix)
{
  gdk_window_set_icon (window->window, NULL,
		       *pix, pix->Mask());
  /*
    gdk_window_set_decorations (window->window, 
    GdkWMDecoration(GDK_DECOR_ALL | GDK_DECOR_MENU));
    gdk_window_set_functions (window->window, 
    GdkWMFunction(GDK_FUNC_ALL | GDK_FUNC_RESIZE));
  */
}
/*
 */
void VDKForm::SetIconName(char* name)
{
gdk_window_set_icon_name (window->window,name);
}
/*
 */
void 
VDKForm::SetPosition(VDKPoint p)   
{ 
  gdk_window_move(window->window,p.X(),p.Y());
}
/*
 */
VDKPoint 
VDKForm::GetPosition()   
{
  int x = 0,y = 0;
  if(window->window)
    gdk_window_get_root_origin(window->window,&x,&y);
  VDKPoint p(x,y);
  return p;
}
/*
 */
void
VDKForm::SetDefaultSize(VDKPoint p)
{
if(window)
  {
    gtk_window_set_default_size(GTK_WINDOW(window),p.X(),p.Y());
    _oldSize = p;
  }
}
/*
  ================================================
  General responses (place holders for subclasses)
  ================================================
*/
void VDKForm::OnExpose( VDKForm*, GdkRectangle) { }
void VDKForm::OnChildClosing(VDKForm* ) { }
void VDKForm::OnShow(VDKForm*) { }
void VDKForm::OnRealize(VDKForm*) { }
void VDKForm::OnConfigure(VDKForm*) {}
void VDKForm::OnMove(VDKForm* sender) {}
void VDKForm::OnResize(VDKForm* sender,VDKPoint& ) {}

/*
  transient parent stuff
  buggy
  void VDKForm::SetMotherLink(bool flag)
  {
  if(owner && flag) 
  gtk_window_set_transient_for(
  GTK_WINDOW(window),
  GTK_WINDOW(owner->Window()));
  }
*/


