/*
file: benchwin.h
*/
#include <vdk/vdk.h>
class BenchWin: public VDKForm
{
  VDKLabelButton *start,*target;
  VDKLabel *label;
public:
  BenchWin(VDKForm* owner, char* title = "Signal dispatch benchmark"):
    VDKForm(owner,title)
    {}
  ~BenchWin() 
    {}
  void Setup();
  bool Start(VDKObject*);
  bool Target(VDKObject*);
  DECLARE_SIGNAL_MAP(BenchWin);
};

