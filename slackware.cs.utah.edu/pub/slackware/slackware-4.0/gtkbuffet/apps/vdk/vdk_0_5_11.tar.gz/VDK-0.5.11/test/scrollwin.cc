/* 
file:scrollwin.cc
*/
#include "scrollwin.h"
#include <vdk/text.h>
DEFINE_SIGNAL_MAP(ScrollWin,VDKForm)
  ON_SIGNAL(quit,clicked_signal,Quit) 
END_SIGNAL_MAP

void
ScrollWin::Setup()
{   
// makes a scrolled
VDKScrolled* scrolled = new VDKScrolled(this);
VDKBox* box = new VDKBox(this); 
// add a pixmap and a button to box
box->Add(pixmap =  
    new VDKPixmap(this,
		  "./pixmaps/pippo.xpm"));
VDKTooltip* tip = new VDKTooltip(this,pixmap,
"My son Pietro (nickname Pippo)\rlikes Beatles !");
tip->SetColors(0,0,0,255,255,0);
box->Add(quit = 
	 new VDKLabelButton(this,
			    "That's enough",
			    "Close window"));
// add box to scrolled 
scrolled->Usize = VDKPoint(300,350);
scrolled->AddWithViewport(box);
Add(scrolled);
}



