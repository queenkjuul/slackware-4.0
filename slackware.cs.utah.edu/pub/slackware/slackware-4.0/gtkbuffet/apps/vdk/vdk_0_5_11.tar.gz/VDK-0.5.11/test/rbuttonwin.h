/*
file: rbuttonwin.h
*/
#include <vdk/vdk.h>
class RadioButtonWin: public VDKForm
{
  VDKRadioButtonGroup *group1,*group2; 
  VDKFrame *frame;
public:
  RadioButtonWin(VDKForm* owner):
    VDKForm(owner,"Radio buttons & frames") {}
  ~RadioButtonWin() {}
  void Setup();
  bool OnToggleRadioGroup(VDKObject* sender);
  DECLARE_SIGNAL_MAP(RadioButtonWin);
};
