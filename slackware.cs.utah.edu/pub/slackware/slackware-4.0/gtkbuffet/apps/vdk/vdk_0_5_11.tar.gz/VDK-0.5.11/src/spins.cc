/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
*/


#include <vdk/spins.h>
#include <vdk/forms.h>
void VDKSpinButton::FocusOutEvent(GtkWidget *,
				  GdkEventFocus*,
				  gpointer)
{

}
/*
 */
VDKSpinButton::VDKSpinButton(VDKForm* owner,
		     float defValue,
		     float lower,
		     float upper,
		     float step,
		     float climb):
  VDKObject(owner),
  ValueAsFloat("ValueAsFloat",this,defValue,&VDKSpinButton::GetValueAsFloat),
  ValueAsInt("ValueAsInt",this,int(defValue),&VDKSpinButton::GetValueAsInt),
  Digits("Digits",this,1,&VDKSpinButton::SetDigits)
{
 adj = gtk_adjustment_new (defValue, lower, upper, step, step, step);
 widget = gtk_spin_button_new (GTK_ADJUSTMENT (adj), climb, 1); 
 gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (widget), TRUE);
 s_value_changed.obj = this;
 s_value_changed.signal = value_changed_signal;
 gtk_signal_connect(adj,"value_changed",
		    GTK_SIGNAL_FUNC(VDKObject::VDKSignalPipe),
		    (gpointer) &s_value_changed);
 gtk_signal_connect(GTK_OBJECT(&GTK_SPIN_BUTTON(widget)->entry),
		       "focus_out_event",
		       GTK_SIGNAL_FUNC(VDKSpinButton::FocusOutEvent),
		       (gpointer) this);
}
 

VDKSpinButton::~VDKSpinButton()
{
} 




