/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */


#include <vdk/canvas.h>
#include <vdk/forms.h>
#include <vdk/rawpixmap.h>
/*
 */
void VDKCanvas::ConfigureEvent(GtkWidget* , GdkEventConfigure* , void* o)
{
  g_return_if_fail(o != NULL);
  VDKCanvas* canvas = reinterpret_cast<VDKCanvas*>(o);
  canvas->DrawBackground();
}  
/*
 */
void VDKCanvas::DrawBackground()
{
if(pixmap)
    gdk_pixmap_unref(pixmap);
  pixmap = gdk_pixmap_new(widget->window,
			  widget->allocation.width,
			  widget->allocation.height,
			  -1);
  gdk_draw_rectangle(pixmap,
		     widget->style->
		     bg_gc[GTK_WIDGET_STATE(widget)],
		     TRUE,
		     0,
		     0,
		     widget->allocation.width,
		     widget->allocation.height);
  return ;
}
/*
 */
void VDKCanvas::Clear()
{
DrawBackground();
gtk_widget_draw(widget,NULL);
}
/*
 */ 
void VDKCanvas::ExposeEvent(GtkWidget* w , GdkEventExpose* event, void* o)
{ 
  g_return_if_fail(o != NULL);
  VDKCanvas* canvas = reinterpret_cast<VDKCanvas*>(o);
  g_return_if_fail(canvas != NULL);
  // avoid to redrawing in case of
  // setting canvas foreG,backg or font
  if(canvas->setFg) 
    {
      canvas->setFg = false;
      return;
    }
  if(canvas->setBg)
    {
      canvas->setBg = false;
      return;
    }
  if(canvas->setF) 
    {
      canvas->setF = false;
      return;
    }
  gdk_draw_pixmap(canvas->widget->window,
		   canvas->widget->style->
		   bg_gc[GTK_WIDGET_STATE(canvas->widget)],
		  canvas->pixmap,
		  event->area.x,event->area.y,
		  event->area.x,event->area.y,
		  event->area.width,event->area.height);
  if(event->count == 0)
    canvas->VDKObject::VDKEventPipe(w, (GdkEvent*) event , canvas);
  return;
}
/*
 */
void VDKCanvas::Redraw()
{
if(pixmap)
 gdk_draw_pixmap(widget->window,
		 widget->style->bg_gc[GTK_WIDGET_STATE(widget)],
		 pixmap,
		 0,
		 0,
		 0,  
		 0,
		 widget->allocation.width,
		 widget->allocation.height);
return;
}
/*
 */
void VDKCanvas::MotionNotifyEvent(GtkWidget *w, 
				  GdkEventMotion* event, 
				  void* o)
{ 
  int x, y;
  g_return_if_fail(o != NULL);
  g_return_if_fail(w != NULL);
  VDKCanvas* obj = reinterpret_cast<VDKCanvas*>(o);
  GdkModifierType state;
  if (event->is_hint)
    gdk_window_get_pointer (event->window, &x, &y, &state);
  // checks wher the cursor is
  if( x < 0 
      || y < 0 
      || x > w->allocation.width 
      || y > w->allocation.height
      )
    return;
  if(obj->startdragFlag)
    {
      obj->startdragFlag = false;
      GdkEventMotion *motionEv = new GdkEventMotion;
      *motionEv = *event;
      motionEv->x = x;
      motionEv->y = y;
      motionEv->state = state;
      motionEv->type = (GdkEventType) drag_start_event;
      obj->VDKObject::VDKEventPipe(w, (GdkEvent*) motionEv , o);
      delete motionEv;
    }
  else if(event->state & GDK_BUTTON1_MASK)
    {
      GdkEventMotion *motionEv = new GdkEventMotion;
      *motionEv = *event;
      motionEv->x = x;
      motionEv->y = y;
      motionEv->state = state;
      motionEv->type = (GdkEventType) dragging_event;
      obj->VDKObject::VDKEventPipe(w, (GdkEvent*) motionEv , o);
      delete motionEv;
    }
  else
    {
      obj->dragFlag = false;
      obj->VDKObject::VDKEventPipe(w, (GdkEvent*) event , o);
    }
  return ;
}


/*
 */
void VDKCanvas::ButtonPressEvent(GtkWidget* , 
				 GdkEventButton* , void* o)
{
  g_return_if_fail(o != NULL);
  VDKCanvas* obj = reinterpret_cast<VDKCanvas*>(o);
  obj->dragFlag = obj->startdragFlag = true;
}
/*
 */
void VDKCanvas::ButtonReleaseEvent(GtkWidget *w , 
				   GdkEventButton* event, void* o)
{
  g_return_if_fail(o != NULL);
  g_return_if_fail(w != NULL);
  VDKCanvas* obj = reinterpret_cast<VDKCanvas*>(o);
  if(obj->dragFlag && ! obj->startdragFlag)
    {
      obj->dragFlag = false;
      GdkEventButton *buttonEv = new GdkEventButton;
      *buttonEv = *event;
      buttonEv->type = (GdkEventType) drag_stop_event;
      obj->VDKObject::VDKEventPipe(w, (GdkEvent*) buttonEv , o);
      delete buttonEv;
    }
  else
    obj->VDKObject::VDKEventPipe(w, (GdkEvent*) event , o);
  obj->startdragFlag = false;
}

/*
 */
VDKCanvas::VDKCanvas(VDKForm* owner,int w, int h):
  VDKObject(owner)
{
  setFg = false;
  pixmap = NULL;
  dragFlag = false;
  startdragFlag = false;
  widget = gtk_drawing_area_new();
  
  gtk_drawing_area_size(GTK_DRAWING_AREA(widget),w,h);
  
  gtk_widget_set_events(widget, 
			GDK_EXPOSURE_MASK |
			GDK_BUTTON_PRESS_MASK | 
			GDK_POINTER_MOTION_MASK |
			GDK_BUTTON_RELEASE_MASK |
			GDK_POINTER_MOTION_HINT_MASK);
    
  gtk_signal_connect (GTK_OBJECT (widget), "configure_event",
		      GTK_SIGNAL_FUNC(VDKCanvas::ConfigureEvent),this);
  gtk_signal_connect (GTK_OBJECT (widget), "configure_event",
		      GTK_SIGNAL_FUNC(VDKObject::VDKEventPipe),this);

  gtk_signal_connect (GTK_OBJECT (widget), "expose_event",
		      GTK_SIGNAL_FUNC(VDKCanvas::ExposeEvent),this);  
  gtk_signal_connect (GTK_OBJECT (widget), "expose_event",
  	      GTK_SIGNAL_FUNC(VDKObject::VDKEventPipe),this);

  gtk_signal_connect (GTK_OBJECT (widget), "motion_notify_event",
		      GTK_SIGNAL_FUNC(VDKCanvas::MotionNotifyEvent),this);
  

  gtk_signal_connect (GTK_OBJECT (widget), "button_press_event",
		      GTK_SIGNAL_FUNC(VDKCanvas::ButtonPressEvent),this);
  //  gtk_signal_connect (GTK_OBJECT (widget), "button_press_event",
  //	      GTK_SIGNAL_FUNC(VDKObject::VDKEventPipe),this);

  gtk_signal_connect (GTK_OBJECT (widget), "button_release_event",
		      GTK_SIGNAL_FUNC(VDKCanvas::ButtonReleaseEvent),this);
  ConnectDefaultSignals();
}

/*
 */
VDKCanvas::~VDKCanvas()
{
}
//===========================================================
extern void PixSize(int* width, int* height, char* filename);
/*
 */
void VDKCanvas::DrawPixmap(int x, int y, char ** data)
{
DrawPixmap(x,y,new VDKRawPixmap(this,data));
}
/*
 */
void VDKCanvas::DrawPixmap(int x, int y, char *pixfile)
{
DrawPixmap(x,y,new VDKRawPixmap(this,pixfile));
}
/*
 */
void VDKCanvas::DrawPixmap(int x, int y, VDKRawPixmap* pix)
{
if(pix)
  pix->Paint(x,y);
}
/*
 */
 void VDKCanvas::DrawString(int x, int y, char* text)
{
if(pixmap)
  gdk_draw_string(pixmap,
		  widget->style->font,
		  widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		  x,
		  y,
		  text);
} 
/*
 */
void VDKCanvas::DrawText(int x, int y, char* text, int n)
{
if(pixmap)
  gdk_draw_text(pixmap,
		  widget->style->font,
		  widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		  x,
		  y,
		  text,
		  n);
}
/*
 */
void VDKCanvas::DrawPoint(int x, int y)
{
if(pixmap)
  gdk_draw_point(pixmap,
		 widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		  x,
		  y);
}
/*
 */
void VDKCanvas::DrawLine(int x, int y, int x1, int y1) 
{
if(pixmap)
  gdk_draw_line(pixmap,
		 widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		  x,y,x1,y1);
}
/*
 */
void VDKCanvas::DrawRect(int x, int y, int w, int h)
{
if(pixmap)
  gdk_draw_rectangle(pixmap,
		     widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		     TRUE,
		     x,y,w,h);
} 
/*
 */
void VDKCanvas::DrawArc(gint filled,
			       gint x,
			       gint y,
			       gint width,
			       gint height,
			       gint angle1,
			       gint angle2)
{
  if(pixmap)
    gdk_draw_arc(pixmap,
		 widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		 filled,
		 x,
		 y,
		 width,
		 height,
		 angle1,
		 angle2);
}
/*
 */
void VDKCanvas::DrawPolygon(gint		filled,
				   GdkPoint     *points,
				   gint		npoints)
{
  if(pixmap)
    gdk_draw_polygon(pixmap,
		     widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		     filled,
		     points,
		     npoints);
}
/*
 */
void VDKCanvas::DrawPoints(GdkPoint     *points,
				  gint		npoints)
{
if(pixmap)
    gdk_draw_points(pixmap,
		    widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		    points,
		    npoints);
}
/*
 */
void VDKCanvas::DrawSegments(GdkSegment   *segs,
				    gint	 nsegs)
{
if(pixmap)
    gdk_draw_segments(pixmap,
		       widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		       segs,
		       nsegs);
}
/*
 */
void VDKCanvas::DrawLines(GdkPoint     *points,
				 gint          npoints)
{
if(pixmap)
    gdk_draw_lines(pixmap,
		   widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
		   points,
                   npoints);
}





