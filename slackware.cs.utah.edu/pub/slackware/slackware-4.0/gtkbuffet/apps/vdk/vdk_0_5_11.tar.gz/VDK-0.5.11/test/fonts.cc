// fonts
char *courier12 = "-*-courier-medium-r-*-*-12-60-*-*-*-*-iso8859-*";
char *fixed12 = "-*-fixed-medium-r-*-*-12-60-*-*-*-*-iso8859-*";
char *lucida12 = "-*-lucida-medium-r-*-*-12-60-*-*-*-*-iso8859-*";
char *timesbold12 = "-adobe-times-bold-r-normal-*-*-120-*-*-p-*-iso8859-1";
