/*
file: entrieswin.h
*/
#include <vdk/vdk.h>
#define MAX_ENTRIES 4
class EntriesWin: public VDKForm
{
  VDKEntry *normal, *date, *secret ;
  VDKNumericEntry  *numeric;
  VDKLabel *labels[MAX_ENTRIES];
  VDKTable *table;
  VDKBox   *hbox;
  VDKLabelButton *quit;
  VDKLabelButton *toggleEdit;
  VDKLabel* showtext;
public:
  EntriesWin(VDKForm* owner, char* title = "This shows various entries"):
    VDKForm(owner,title){}
  ~EntriesWin() {}
  void Setup();
  bool ShowText(VDKObject*);
  bool ToggleEdit(VDKObject*);
  bool SecretGetFocus(VDKObject*);
  bool Quit(VDKObject*);
  DECLARE_SIGNAL_MAP(EntriesWin);
};




