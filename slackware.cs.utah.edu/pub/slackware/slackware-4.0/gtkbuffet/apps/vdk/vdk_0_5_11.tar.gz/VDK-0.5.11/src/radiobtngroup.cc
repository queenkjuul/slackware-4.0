/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
*/

#include <vdk/radiobtngroup.h>
#include <vdk/forms.h>
static int defaultFlag = 0; // stop emit if raised

void VDKRadioButtonGroup::ToggleEvent(GtkWidget *wid, gpointer gp)
{
  g_return_if_fail(wid != NULL);
  g_return_if_fail(gp != NULL);
  VDKRadioButton* buttonToggled  = 
    reinterpret_cast<VDKRadioButton*> (gp);

  VDKRadioButtonGroup* group = buttonToggled->Group();
  int t = 0;
  int toggled = -1;
   if(defaultFlag)
    {
      defaultFlag--;
      return;
    }
  RadioButtonListIterator li(group->Buttons); 
  for(;li;li++,t++)
    {
      if(li.current() == buttonToggled)
	{
	toggled = t;
	break;
	}
    }
  if(toggled < 0)
    return;
  bool active = GTK_TOGGLE_BUTTON(wid)->active ? true : false;
  buttonToggled->Checked(active);
  if(active)
    {
      group->Selected(toggled);
      group->SignalEmit(toggled_signal);
    }
}
/*
 */
VDKRadioButton::VDKRadioButton(
			       VDKRadioButtonGroup* group, 
			       char* label):
  VDKCheckButton(group->Owner(),label),group(group)
{
gtk_signal_disconnect(GTK_OBJECT(widget),connectId);
gtk_widget_destroy(widget);
if(! group->group)
  {
    widget = gtk_radio_button_new_with_label(NULL,label);
    group->group = gtk_radio_button_group(GTK_RADIO_BUTTON(widget));
  }
else 
  {
    GtkWidget* wid  = group->Buttons[group->Buttons.size()-1]->Widget();
    widget = gtk_radio_button_new_with_label(group->group,label);
    group->group = gtk_radio_button_group(GTK_RADIO_BUTTON(wid)); 
  }
gtk_signal_connect(GTK_OBJECT(widget),"toggled",
		   GTK_SIGNAL_FUNC(VDKRadioButtonGroup::ToggleEvent),
		   (gpointer) this);
group->box->Add(this);
group->Buttons.add(this); 
}
/* 
 */
VDKRadioButtonGroup::VDKRadioButtonGroup(VDKForm* owner, 
					 int mode):
  VDKObject(owner),
  Selected(
	   "Selected",
	   this,
	   0, 
	   &VDKRadioButtonGroup::SetSelected
	   ),
  ButtonList("ButtonList",this,NULL)
{
box = new VDKBox(owner,mode);
widget = box->Widget(); 
owner->Objects().add(box);
group = NULL; 
ButtonList(&Buttons);   
}
/* 
 */ 
void VDKRadioButtonGroup::SetDefault(int bn)
{
if(bn >= 0 && bn < Buttons.size())
  {
    defaultFlag+=2; // deny "toggled" signal processing
    GtkWidget* wid = Buttons[bn]->Widget();
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(wid),TRUE);
    Selected(bn);
  }
}

void VDKRadioButtonGroup::SetSelected(int index)
{ 
  if(index >= 0 && index < Buttons.size())
    Buttons[index]->Checked = true; 
}










