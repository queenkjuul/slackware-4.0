/*
file: scrollwin.h
*/
#include <vdk/vdk.h>
class ScrollWin: public VDKForm
{
  VDKPixmap* pixmap;
  VDKLabelButton* quit;
public:
  ScrollWin(VDKForm* owner):
    VDKForm(owner,"Scrolled example") {}
  ~ ScrollWin() {}
  void Setup();
  bool Quit(VDKObject*) { Close(); return true; }
DECLARE_SIGNAL_MAP(ScrollWin);
};
