/*
 * ===========================
 * VDK Visual Develeopment Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#ifndef _button_h
#define _button_h
#ifndef yes
#define yes true
#define no false
#endif
#include <vdk/abstract_button.h>
#include <vdk/forms.h>
class VDKTooltip;
class VDKButton: public VDKAbstractButton
{
protected:
  VDKForm* owner;
  GtkWidget* box;
  void _add_default();
  GdkPixmap* def_pixmap;
  VDKTooltip* tip;
public:
  VDKButton(VDKForm* owner, char* tip = (char*) NULL);
  virtual ~VDKButton() 
    {
      if(def_pixmap)
	gdk_pixmap_unref(def_pixmap);
    }
  virtual void SetForeground(VDKRgb , GtkStateType ) {}
  virtual void SetFont(VDKFont*){}
};

#endif
