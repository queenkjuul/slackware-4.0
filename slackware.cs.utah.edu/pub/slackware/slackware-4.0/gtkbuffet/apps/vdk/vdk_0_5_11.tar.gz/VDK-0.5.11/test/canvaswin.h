/*
file:canvaswin.h
*/
#include <vdk/vdk.h>

/*
 */
class CanvasWin : public VDKForm
{
  VDKCanvas *canvas;

  VDKLabel  *label;
  VDKPixmapButton *mlButton;
  VDKLabelButton *clearButton,*nicelinux;
 public:
  CanvasWin(VDKForm* owner, 
	    char* title = "This shows a canvas"):
    VDKForm(owner,title){}
  ~CanvasWin() {}
  void Setup();
  bool OnMotion(VDKObject* sender, GdkEvent* event);
  bool OnExpose(VDKObject*, GdkEvent* event);
  bool OnConfigure(VDKObject*, GdkEvent* event);
  bool OnDragStart(VDKObject*, GdkEvent* event);
  bool OnDragging(VDKObject*, GdkEvent* ev);
  bool OnDragStop(VDKObject*, GdkEvent* ev);
  bool DrawNiceLinux(VDKObject*);
  bool OnMotherLink(VDKObject*);
  bool Clear(VDKObject*);
  DECLARE_EVENT_MAP(CanvasWin);
  DECLARE_SIGNAL_MAP(CanvasWin);
};
