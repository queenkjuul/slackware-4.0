/*
file:panedwin.cc
*/ 
#include "panedwin.h"
DEFINE_SIGNAL_MAP(PanedWin,VDKForm)
  ON_SIGNAL(quit,clicked_signal,Quit),
  ON_SIGNAL(flip,clicked_signal,Flip)
  
END_SIGNAL_MAP
static VDKRawPixmap* monetPix, *nicegirlPix;
/*
 */ 
void PanedWin::Setup()
{
  
  // a box to contain paned
  VDKBox *hbox1 = new VDKBox(this,h_box);
  hbox1->Add(paned = new VDKPaned(this,h_box));     
  monetPix = new VDKRawPixmap(this,"./pixmaps/monet.xpm");   
  nicegirlPix = new VDKRawPixmap(this,"./pixmaps/linuxGirl.xpm");
  nicegirl = new VDKPixmap(this,"./pixmaps/linuxGirl.xpm",
			   "By courtesy of B.Bellamy");
  monet = new VDKPixmap(this,"./pixmaps/monet.xpm","Claude Monet");
  paned->Add(nicegirl,1);
  paned->Add(monet,2); 
  // a box to contain a button
  VDKBox *hbox2 = new VDKBox(this,h_box);
  hbox2->Add(quit = new VDKLabelButton(this,"Quit it","Finish"));
  hbox2->Add(flip = new VDKLabelButton(this,"Flip","Flips pixmaps"));
  //  abox to contain hboxes
  VDKBox *box = new VDKBox(this);
  box->Add(hbox1);
  box->Add(hbox2);
  // add all stuff to form
  Add(box);    
}

/*
 */
bool PanedWin::Flip(VDKObject*)    
{ 
  VDKRawPixmap* old = nicegirl->SetPixmap();
  if(!old)  
      nicegirl->SetPixmap(monetPix);
  else
      nicegirl->SetPixmap(old == monetPix ? nicegirlPix : monetPix);
  old = monet->SetPixmap();
  if(!old)  
      monet->SetPixmap(nicegirlPix);
  else
      monet->SetPixmap(old == monetPix ? nicegirlPix : monetPix); 
return true;
}
 
 
 


 
