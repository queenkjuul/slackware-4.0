/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * revision to 0.5.0
 * October,November 1998
 * ===========================
 * 
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 */

#include <vdk/toolbar.h>
#include <vdk/forms.h>
#include <vdk/vdkobj.h>
#include <vdk/colors.h>
/*
 */
static GtkWidget*
new_pixmap (char      **pixdata,
	    GdkWindow *window,
	    GdkColor  *background);
/*
 */
void VDKToolbar::ButtonSignal(GtkWidget *wid, gpointer gp)
{
  int t = 0;
  g_return_if_fail(wid != NULL);
  g_return_if_fail(gp != NULL);
  VDKToolbar* toolbar = 
    reinterpret_cast<VDKToolbar*> (gp);
  GtkWidgetListIterator li(toolbar->widgets);
  for(;li;li++,t++)
    if(wid == li.current())
      break;
  if(t < toolbar->widgets.size())
    {
      toolbar->ButtonPressed(t);
      toolbar->SignalEmit(clicked_signal);
    }
  
}
/*
 */
VDKToolbar::VDKToolbar(VDKForm* owner, GtkOrientation orientation):
  VDKObject(owner),
  WidgetList("WidgetList",this,NULL),
  ButtonList("ButtonList",this,NULL),
  ButtonPressed("ButtonPressed",this,-1),
  Orientation("Orientation",this,
	      GTK_ORIENTATION_HORIZONTAL,&VDKToolbar::SetOrientation),
  Style("Style",this,GTK_TOOLBAR_ICONS,&VDKToolbar::SetStyle),
  Borderless("Borderless",this,true,&VDKToolbar::SetBorderless),
  Spacing("Spacing",this,2,&VDKToolbar::SetSpacing)
{
widget = gtk_toolbar_new(orientation,GTK_TOOLBAR_ICONS);
gtk_toolbar_set_space_size(GTK_TOOLBAR(widget),2);
gtk_toolbar_set_button_relief (GTK_TOOLBAR (widget), GTK_RELIEF_NONE);
WidgetList(&toolWidgets);
ButtonList(&widgets);
}

void VDKToolbar::AddWidget(VDKObject* obj,char* tip)
{
gtk_toolbar_append_widget(GTK_TOOLBAR(widget),
			  obj->Widget(),
			  tip,NULL);
gtk_widget_show(obj->Widget());
items.add(obj);
toolWidgets.add(obj);
} 

/*
*/ 
void VDKToolbar::AddButton(
			   char** pixdata,
			   char* tip,
			   char* text)
{
  GtkWidget *button;
  GtkWidget *pixmap = pixdata ? 
    new_pixmap (pixdata, 
		Owner()->Window()->window, 
		&widget->style->bg[GTK_STATE_NORMAL]) : NULL ;
  button = gtk_toolbar_append_item (GTK_TOOLBAR (widget),
				    text, 
				    NULL,
				    NULL,
				    pixmap,
				    GTK_SIGNAL_FUNC(VDKToolbar::ButtonSignal),
				    (gpointer) this);
  VDKObject* tbutton = new VDKObject(Owner(),button);
  Owner()->Items().add(tbutton);
  tool_buttons.add(tbutton);
  if(tip)
    tbutton->SetTip(tip);
  widgets.add(button);
  return ;
} 
 

GtkWidget*
new_pixmap (char      **pixdata,
	    GdkWindow *window,
	    GdkColor  *background)
{
  GtkWidget *wpixmap;
  GdkPixmap *pixmap;
  GdkBitmap *mask;

  pixmap = gdk_pixmap_create_from_xpm_d (window, &mask,
				       background,
				       pixdata);
  wpixmap = gtk_pixmap_new (pixmap, mask);

  return wpixmap;
}
 



