/*
File: testvdk.h
VDK 0.1 test program
*/               
#include <vdk/vdk.h>
#include <vdk/panelbar.h>
#include "waitcursor.h"
/*
main form
*/
class TestForm: public VDKForm
{
  VDKMenu* menu;
  VDKMenuItem *quit_menu,*testcode_menu,*rc_menu,*help_menu;
  VDKBox *vbox,*vbox1;
  VDKCustomList* list;
  VDKPixmap* pixmap;
  VDKLabel *label, *label1;
  VDKEventBrowser* browser;
  VDKPanelbar *bottombar;
  VDKTimer * timer;
public:
TestForm(VDKApplication* app, gchar* title, int mode);
~TestForm();
void Setup();
bool CanClose();
// response functions
 bool Quit(VDKObject*);
 bool TestCode(VDKObject*);
 bool RcCode(VDKObject*);
 bool HandleListSelection(VDKObject*); 
 bool HandleListUnselection(VDKObject*); 
 bool ChildList(VDKObject*); 
 bool HandleColumnClick(VDKObject*);
 void OnChildClosing(VDKForm* child); 
 bool OnClickLogo(VDKObject*, GdkEvent*);
 bool OnBrowser(VDKObject*);
 bool OnHelp(VDKObject*);
 bool TimerTick(VDKObject*);
 bool OnRealize(VDKObject*);
 bool OnUnrealize(VDKObject*);
 DECLARE_SIGNAL_MAP(TestForm); 
 DECLARE_EVENT_MAP(TestForm); 
 DECLARE_SIGNAL_LIST(TestForm);
};  
/*
test application
*/  
class TestApp: public VDKApplication
{
public:
TestApp(int* argc, char** argv);
~TestApp();
void Setup();
}; 
