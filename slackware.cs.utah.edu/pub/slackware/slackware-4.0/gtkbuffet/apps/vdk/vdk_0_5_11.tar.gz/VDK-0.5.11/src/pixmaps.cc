/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
*/


#include <vdk/pixmaps.h>
#include <vdk/forms.h>
#include <vdk/colors.h>
#include <vdk/tooltips.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <vdk/rawpixmap.h>
extern void PixSize(int* width, int* height, char* filename); 
/*
 */
VDKPixmap::VDKPixmap(VDKForm* owner,
		     char* pixfile, 
		     char* tipString):
  VDKObject(owner)
{
  width = height = 0;
  widget = gtk_event_box_new();
  GdkBitmap *mask;
  GtkStyle* style = gtk_widget_get_style(owner->Window());
  pixmap = gdk_pixmap_create_from_xpm(owner->Window()->window,
				      &mask,
				      &style->bg[GTK_STATE_NORMAL],
				      pixfile);
  if(pixmap != NULL)
    {
      pixmapWid = gtk_pixmap_new(pixmap,mask);
      gtk_widget_show(pixmapWid);
      PixSize(&width,&height,pixfile);
      gtk_widget_set_usize(widget,width,height);
      gtk_container_add(GTK_CONTAINER(widget),pixmapWid);
      if(tipString)
	tip = new VDKTooltip(owner,this,tipString);
      else
	tip = NULL;
    }
  else
    pixmapWid = NULL;
  gtk_signal_connect (GTK_OBJECT (widget), "button_press_event",
		      GTK_SIGNAL_FUNC(VDKObject::VDKEventPipe),this);
  ConnectDefaultSignals();
  oldRawPix = NULL;
}
/*
 */
VDKPixmap::VDKPixmap(VDKForm* owner,
		     char** pixdata, 
		     char* tipString):
  VDKObject(owner)
{
    width = height = 0;
    widget = gtk_event_box_new();
    GdkBitmap *mask;
    GtkStyle* style = gtk_widget_get_style(owner->Window());
    pixmap = gdk_pixmap_create_from_xpm_d(owner->Window()->window,
					  &mask,
					  &style->bg[GTK_STATE_NORMAL],
					  pixdata);
    if(pixmap != NULL)
      {
	pixmapWid = gtk_pixmap_new(pixmap,mask);
	sscanf (pixdata[0],"%d %d", &width, &height);
	gtk_widget_set_usize(widget,width+1,height+1);
	gtk_container_add(GTK_CONTAINER(widget),pixmapWid);
	gtk_widget_show(pixmapWid);
	if(tipString)
	  tip = new VDKTooltip(owner,this,tipString);
	else
	  tip = NULL;
      }
    else
      pixmapWid = NULL;
    gtk_signal_connect (GTK_OBJECT (widget), "button_press_event",
			GTK_SIGNAL_FUNC(VDKObject::VDKEventPipe),this);
    ConnectDefaultSignals();
    oldRawPix = NULL;
}

VDKPixmap::~VDKPixmap()
{
  // VDK 0.5
  // this caused a: 
  /*
    Gdk-ERROR **: BadAccess (attempt to access private resource denied)
    serial 2887 error_code 10 request_code 88 minor_code 0
    
    aborting...
    
    [1]+  IOT trap/Abort          (core dumped) testvdk
  */
  // problem should be further investigated...
  //---
  /*
    if(pixmap)
    gdk_pixmap_unref(pixmap);
  */
}
/*
 */
VDKRawPixmap* VDKPixmap::SetPixmap(char* file)
{
  return SetPixmap(new VDKRawPixmap(this,file));
}
/*
 */
VDKRawPixmap* VDKPixmap::SetPixmap(char** pixdata)
{
  return SetPixmap(new VDKRawPixmap(this,pixdata)); 
}
/*
 */
VDKRawPixmap* VDKPixmap::SetPixmap(VDKRawPixmap* newpix)
{
  VDKRawPixmap* oldpix;
  if((!pixmapWid) || (oldRawPix == newpix))
    return NULL;
  else
    {
      //TODO: review this bug (see paned win in test program) 
      // setting a new pixmap does not clear the previous
      oldpix = oldRawPix;
      if(pixmap)
	{
	  gdk_pixmap_unref(pixmap);
	  pixmap = NULL;
	}
      gtk_pixmap_set (GTK_PIXMAP(pixmapWid), 
		      *newpix, 
		      newpix->Mask());
      oldRawPix = newpix;  
      gtk_widget_queue_draw(pixmapWid);
    }
return oldpix;
}
/*
 */
void VDKPixmap::Clear()
{
  GtkWidget* wid;
  wid = pixmapWid;
  GdkPixmap *pix = pixmap ? pixmap : 
    oldRawPix ? *oldRawPix : NULL ;
 if(pix)
   gdk_draw_rectangle(pix,
		    wid->style->
		    bg_gc[GTK_WIDGET_STATE(wid)],
		    TRUE,
		    0,
		    0,
		    wid->allocation.width,
		    wid->allocation.height);
  gtk_widget_draw(wid,NULL);
}





