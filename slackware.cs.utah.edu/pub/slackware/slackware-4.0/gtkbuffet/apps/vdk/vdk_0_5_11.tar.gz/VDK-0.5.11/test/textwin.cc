/* 
file: textwin.cc
*/
#include "textwin.h"

void    
TextWin::Setup() 
{
  navy = new VDKColor(this,clNavyBlue);
  siena = new VDKColor(this,clSiena);
  white = new VDKColor(this,clWhite);
  Add((text_h = new VDKText(this)),1);  
  VDKBox* box = new VDKBox(this,v_box);
  box->Add( text_cc = new VDKText(this)); 
  Add(box,2);
  SetSize(400,320); 
 }

/* 
 */ 
void
TextWin::OnShow(VDKForm*)
{
  if(!Application()->HasResources())
    {
      text_h->TextFont.foreground = *navy;
      text_h->NormalBackground = clIvory; 
      text_cc->TextFont.foreground = *siena;
    }
  char buff[128];
  sprintf(buff,"%s.h",file); 
  text_h->LoadFromFile(buff);
  sprintf(buff,"%s.cc",file);
  text_cc->LoadFromFile(buff);
 }






