/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */


#ifndef _vdk_h
#define _vdk_h
#include <vdk/evhandle.h>
#include <vdk/evobjhandle.h>
#include <vdk/siglisthandle.h>
#include <vdk/evlisthandle.h>
#include <vdk/application.h>
#include <vdk/forms.h>
#include <vdk/boxes.h>
#include <vdk/label.h>
#include <vdk/button.h>
#include <vdk/label_button.h>
#include <vdk/pix_button.h>
#include <vdk/pixmaps.h>
#include <vdk/messagebox.h>
#include <vdk/separator.h>
#include <vdk/scrolledForm.h>
#include <vdk/menu.h>
#include <vdk/tooltips.h>
#include <vdk/vdkutils.h>
#include <vdk/vdkstring.h>
#include <vdk/vdkclist.h>
#include <vdk/vdkcsortlist.h>
#include <vdk/text.h>
#include <vdk/colors.h>
#include <vdk/entry.h>
#include <vdk/numentry.h>
#include <vdk/tables.h>
#include <vdk/vdkdate.h>
#include <vdk/vdkarray.h>
#include <vdk/value_sem_list.h>
#include <vdk/timer.h>
#include <vdk/progressbar.h>
#include <vdk/canvas.h>
#include <vdk/vdkcursor.h>
#include <vdk/vdkfont.h>
#include <vdk/panedform.h>
#include <vdk/paned.h>
#include <vdk/notebook.h>
#include <vdk/rawpixmap.h>
#include <vdk/rawobj.h>
#include <vdk/filedlg.h>
#include <vdk/checkbutton.h>
#include <vdk/radiobtngroup.h>
#include <vdk/frame.h>
#include <vdk/coolbutton.h>
#include <vdk/coolbar.h>
#include <vdk/toolbar.h>
#include <vdk/evbrowser.h>
#include <vdk/scrolled.h>
#include <vdk/slider.h>
#include <vdk/spins.h>
#include <vdk/handlebox.h>
#include <vdk/widcontain.h>
#include <vdk/statusbar.h>
#include <vdk/panelbar.h>
#include <vdk/combo.h>
#include <vdk/chart.h>
#include <vdk/fixed.h>
#include <vdk/vdkctree.h>
#include <vdk/vdkbtrees.h>
#include <vdk/vdkheap.h>
#include <vdk/togglebutton.h>
#include <vdk/pix_togglebutton.h>
#include <vdk/label_togglebutton.h>
#endif 






