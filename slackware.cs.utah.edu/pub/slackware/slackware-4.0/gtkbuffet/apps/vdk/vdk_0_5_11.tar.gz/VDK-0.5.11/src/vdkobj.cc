/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 */
#include "vdk/vdkobj.h"
#include "vdk/forms.h"
#include "vdk/evhandle.h"
#include "vdk/evobjhandle.h"
#include "vdk/colors.h"
#include "vdk/tooltips.h"
#include "vdk/vdkfont.h"

#ifdef VDKDEBUG
int objectC = 0;
int objectD = 0;
extern int objRemoved;
#endif

/*
 */ 
VDKObject::VDKObject(VDKForm* owner):
  // sets properties
    NormalBackground("NormalBackGround",this,
		     VDKRgb(255,255,255),
		     &VDKObject::SetNormalBackground),
    PrelightBackground("PrelightBackGround",this,
		       VDKRgb(255,255,255),
		       &VDKObject::SetPrelightBackground),
    InsensitiveBackground("InsensitiveBackGround",
			  this,
			  VDKRgb(255,255,255),
			  &VDKObject::SetInsensitiveBackground),

    ActiveBackground("ActiveBackGround",
		     this,
		     VDKRgb(255,255,255),
		     &VDKObject::SetActiveBackground),

    SelectedBackground("SelectedBackGround",
		       this,
		     VDKRgb(255,255,255),
		     &VDKObject::SetSelectedBackground),
    Foreground("Foreground",this,
	       VDKRgb(255,255,255),
	       &VDKObject::SetNormalForeground),

    Font("Font",this,NULL,&VDKObject::SetFont),
    Usize("Usize",this),
    Enabled("Enabled",this,true,&VDKObject::Enable),
    Cursor("Cursor",this,curDefault,&VDKObject::SetCursor),
    Visible("Visible",this,true,&VDKObject::SetVisible,&VDKObject::GetVisible),
    Tag(0),
    // 
    tip(NULL),
    owner(owner),
    widget(NULL),
    sigwid(NULL),
    parent(NULL)
    {
#ifdef VDKDEBUG
      objectC++;
#endif
    }


/*
 */
VDKObject::VDKObject(VDKForm* owner,GtkWidget* widget):
  // sets properties
    NormalBackground("NormalBackGround",this,
		     VDKRgb(255,255,255),
		     &VDKObject::SetNormalBackground),
    PrelightBackground("PrelightBackGround",this,
		       VDKRgb(255,255,255),
		       &VDKObject::SetPrelightBackground),
    InsensitiveBackground("InsensitiveBackGround",
			  this,
			  VDKRgb(255,255,255),
			  &VDKObject::SetInsensitiveBackground),
    ActiveBackground("ActiveBackGround",
		     this,
		     VDKRgb(255,255,255),
		     &VDKObject::SetActiveBackground),
    SelectedBackground("SelectedBackGround",
		       this,
		       VDKRgb(255,255,255),
		       &VDKObject::SetSelectedBackground),
    Foreground("Foreground",this,
	       VDKRgb(255,255,255),
	       &VDKObject::SetNormalForeground),
    Font("Font",this,NULL,&VDKObject::SetFont),
    //    Usize("Usize",this,VDKPoint(0,0),&VDKObject::SetUsize),
    Usize("Usize",this),
    Enabled("Enabled",this,true,&VDKObject::Enable),
    Cursor("Cursor",this,curDefault,&VDKObject::SetCursor),
    Visible("Visible",this,true,&VDKObject::SetVisible,&VDKObject::GetVisible),
    Tag(0),
    //
    tip(NULL), 
    owner(owner),
    widget(widget),
    sigwid(NULL),
    parent(NULL)
{
#ifdef VDKDEBUG
  objectC++;
#endif
}

/*
 */
void VDKObject::SetCursor(VDKCursorType curType)
{
  if(! widget)
    return;
  GdkCursor *cursor;
  if(curType == curDefault)
    curType = (VDKCursorType) GDK_LEFT_PTR; 
  cursor = gdk_cursor_new ((GdkCursorType) curType);
  gdk_window_set_cursor (widget->window, cursor);
  gdk_cursor_destroy (cursor);
}
/*
 */
void VDKObject::ConnectDefaultEvents()
{
}
/*
 */
void VDKObject::ConnectDefaultSignals()
{
  if(! widget)
    return;
  s_realize.obj = this;
  s_realize.signal = realize_signal;
  gtk_signal_connect(GTK_OBJECT(WrappedWidget()),"realize",
		     GTK_SIGNAL_FUNC(VDKObject::VDKSignalPipe),
		     (gpointer) &s_realize);
}
/*
 */
VDKObject::~VDKObject()
{
  /*
    delete items, garbage and raws
  */
  ItemListIterator li(items);
  for(;li;li++)
    delete li.current();
  
  ItemListIterator lg(garbages);
  for(;lg;lg++)
    delete lg.current(); 
  
  RawListIterator lr(raws);
  for(;lr;lr++)
    delete lr.current();
  
  // deletes signal unit list
  SignalUnitListIterator lu(suList);
  for(;lu;lu++)
    delete lu.current();

  // deletes event unit list
  EventUnitListIterator le(euList);
  for(;le;le++)
    delete le.current();
#ifdef VDKDEBUG
      objectD++;
#endif
  
}
/*
  ==================================
  SIGNAL HANDLING FOR STATIC TABLES
  AND DYNAMIC SIGNAL LISTS
  ==================================
  "the signal is considered treated if and only if a user response
  returned true".
  Signal flow:  
  1. to object level and up to his hierarchy if not treated.
  2. to parent level and up to parent hierarchy if not treated.
  if parent has a parent step 2 will be repeated until found
  a parent without parent.
  3. if yet not treated signal is lost.
*/
/*
=======================
handles signal calling
static tables routines
=======================
*/
void 
VDKObject::VDKSignalPipe(GtkWidget* w, void* s)
{
  g_return_if_fail(s != NULL);
  VDKObjectSignal* signal = 
    reinterpret_cast<VDKObjectSignal*>(s);
  VDKObject* obj = reinterpret_cast<VDKObject*>(signal->obj);
  // visits class level 
  if(obj->VDKObjectSignalResponse(w,signal->signal,obj,false))
    return;
  // visit parent level 
  VDKObject* parent;
  for(parent = obj->Parent(); parent; parent = parent->Parent())
    if(parent->VDKSignalResponse(w,signal->signal,obj,obj,false))
      break;
}

/* 
=======================
handles signal calling
dynamic list  routines
=======================
*/
void  
VDKObject::VDKSignalUnitPipe(GtkWidget* w, void* s)
{
  g_return_if_fail(s != NULL);
  VDKObjectSignalUnit* signal = 
    reinterpret_cast<VDKObjectSignalUnit*>(s);
  VDKObject* obj = reinterpret_cast<VDKObject*>(signal->obj);
  // visits class level if signal->owner == signal->obj
  // it depends if user call SignalEmit(obj,signal,func)
  // or SignalEmitParent(obj,signal,func)
  if(signal->owner == signal->obj) //SignalEmit()
    {
      if(obj->VDKSignalUnitResponse(w,(char*) signal->signal,obj))
	return;
    }
    // else visit parent level  user called SignalEmitParent()
  VDKObject* parent; 
  for(parent = obj->Parent(); parent; parent = parent->Parent())
    if(parent->VDKSignalUnitResponse(w,(char*) signal->signal,obj))
      break;
    
  
}
/*
=======================
handles events calling
static tables routines
=======================
 */
void 
VDKObject::VDKEventPipe(GtkWidget* w, GdkEvent* event, void* o)
{
  g_return_if_fail(o!= NULL);
  VDKObject* obj = reinterpret_cast<VDKObject*>(o);
  if(obj->VDKObjectEventResponse(w,event,o,false))
    return;
  VDKObject* parent;
  for(parent = obj->Parent(); parent; parent = parent->Parent())
    if(parent->VDKEventResponse(w,event,o,o, false))
      break;
}
/* 
=======================
handles events calling
dynamic list  routines
=======================
*/
void  
VDKObject::VDKEventUnitPipe(GtkWidget* w, GdkEvent* ev, void* s)
{
  g_return_if_fail(s != NULL);
  VDKObjectEventUnit* event = 
    reinterpret_cast<VDKObjectEventUnit*>(s);
  VDKObject* obj = reinterpret_cast<VDKObject*>(event->obj);
  // visits class level if event->owner == event->obj
  if(event->owner == event->obj)
    {
      if(obj->VDKEventUnitResponse(w,(char*) event->signal, ev, obj))
	return;
    }
    // visit parent level 
  VDKObject* parent; 
  for(parent = obj->Parent(); parent; parent = parent->Parent())
    if(parent->VDKEventUnitResponse(w,(char*) event->signal,ev, obj))
      break;
}
/*
==================
signal emitting
(static tables)
=================
*/
void VDKObject::SignalEmit(int sig)
{
  VDKObjectSignal signal;
  signal.obj = this;
  signal.signal = sig;
  VDKSignalPipe(widget,&signal);
}
/*
==================
signal emitting
(dyna tables)
=================
 */
void VDKObject::SignalEmit(char* sig)
{
  VDKObjectSignalUnit* signal = new VDKObjectSignalUnit(this,this,sig);
  suList.add(signal);
  VDKSignalUnitPipe(widget,signal);
}
/*
==================
signal emitting
to parent level
(dyna lists)
=================
 */  
void VDKObject::SignalEmitParent(char* sig)
{
  VDKObjectSignalUnit* signal = new VDKObjectSignalUnit(Parent(),this,sig);
  suList.add(signal);
  VDKSignalUnitPipe(widget,signal);
}
/* 
==================
signal emitting
to class or 
parent level
(static tables)
=================
private    
 */
void VDKObject::SignalEmit(int signal, int level)
{
  VDKObject* obj_parent;
  switch (level)
    {
      // visit class level
    case Class_level:
      if(VDKObjectSignalResponse(widget, signal, this,false))
	return;
      // visit level passing himself as sender
    case Parent_level:
      for(obj_parent = Parent(); obj_parent; obj_parent = obj_parent->Parent())
	if(obj_parent->VDKSignalResponse(widget, signal, 
					 this, this, false))
	  break;
    }
}

/*
======================================================================
*/ 

VDKForm*   
VDKObject::Owner() 
{ 
  return owner; 
} 
/*
 */
GtkWidget* 
VDKObject::Widget() 
{ 
  return widget ? GTK_WIDGET(widget): (GtkWidget*) NULL; 
}
/*
 */
GtkWidget* VDKObject::ConnectingWidget()
{
  return sigwid ? sigwid : widget;
}
/* 
 */ 
void 
VDKObject::SetFont(VDKFont* font)
{
  if(!widget) return;
  _setFont_(widget,font);
  ItemListIterator li(items);
  for(;li;li++)
	li.current()->SetFont(font);
}
/*
 */
void
VDKObject::_setFont_(GtkWidget* wid, VDKFont* font)
{
  if(GTK_IS_WIDGET(wid) && font)
    {
      GtkStyle* style = wid->style;
      g_return_if_fail(style != NULL);
      style = gtk_style_copy(style);
      gtk_style_ref(style);
      style->font = *font;
      gtk_widget_set_style(wid,style);
    }
}
/*
 */
void 
VDKObject::SetForeground(VDKRgb color, GtkStateType state)
{
  if(!widget) return;
  _setForeground_(widget,color.red,color.green,color.blue, state);
  ItemListIterator li(items);
  for(;li;li++)
    li.current()->SetForeground(color,state);
}
/*
 */
void 
VDKObject::SetBackground(VDKRgb color, GtkStateType state)
{
  if(!widget) return;
  _setBackground_(widget,color.red,color.green,color.blue, state);
  ItemListIterator li(items);
  for(;li;li++)
	li.current()->SetBackground(color,state);
}
/*
 */
void 
VDKObject::_setBackground_(GtkWidget* wid,
			   int red,int green, int blue, 
			   GtkStateType state)
{                  
  if(!GTK_IS_WIDGET(wid))
    return;
  GtkStyle* style = wid->style;
  g_return_if_fail(style != NULL);
  style = gtk_style_copy(style);
  gtk_style_ref(style);
  VDKColor *color = new VDKColor(Owner() ? Owner() : this ,red,green,blue);
  gtk_style_ref(style);
  style->bg[state] = *(color->Color());
  gtk_widget_set_style(wid,style);
}
/*
 */
void 
VDKObject::_setForeground_(GtkWidget* wid,
			   int red,int green, int blue,
			   GtkStateType state)
{ 
  if(!GTK_IS_WIDGET(wid))
      return;
  GtkStyle* style = wid->style;
  g_return_if_fail(style != NULL);
  style = gtk_style_copy(style);
   VDKColor *color = new VDKColor(Owner() ? Owner() : this, red,green,blue);
  gtk_style_ref(style);
  style->fg[state] = *(color->Color());
  gtk_widget_set_style(wid,style);
}
/*
 */
void 
VDKObject::SetSize(int w, int h)
{
  if(GTK_IS_WIDGET(widget))
     gtk_widget_set_usize(GTK_WIDGET(widget),w,h);
}
/*
 */
void 
VDKObject::Enable(bool flag)
{ 
  if(GTK_IS_WIDGET(widget))
     {
       gtk_widget_set_sensitive (widget, flag);
       Enabled(flag);
     }
}
/*
 */
void 
VDKObject::SetTip(char* t) 
{
  if(tip) 
    tip->SetTip(t);
  else
    // STUB
    tip = new VDKTooltip(Owner(), this, t);
}
/*
 */
void 
VDKObject::SetVisible(bool visible) 
{ 
  ItemListIterator li(items);
  for(;li;li++)
    li.current()->SetVisible(visible);
  ShowWidget(visible);
}
/*
 */
void VDKObject::ShowWidget(bool visible)
{
if(widget && GTK_IS_WIDGET(widget))
  {
    if(visible)
      gtk_widget_show(widget);
    else 
      gtk_widget_hide(widget);
  }
}
/*
 */
void 
VDKObject::Add(VDKObject*, int, int , 
	       int , int  )
{
g_warning("VDKObject::Add() unuseful call");
}
/*
 */

/*
 */
void VDKObject::AddItem(VDKObject* item) 
{ 
  items.add(item); 
}
/*
 */
void VDKObject::RemoveItem(VDKObject* item) 
{ 
  if(items.remove(item))
    {
      if(Owner())
	Owner()->Garbages().add(item); 
      else
	Garbages().add(item); 
    }
}
/*
recursively removes items
 */
void VDKObject::RemoveItems()
{
  if(items.size() > 0) 
    { 
      ItemListIterator li(items);
      for(;li;li++)
	{
	  li.current()->RemoveItems();
	  if(Owner())
	    Owner()->Garbages().add(li.current());
	  else
	    Garbages().add(li.current());
	}
#ifdef VDKDEBUG
      objRemoved += items.size();
#endif
      items.flush();
    } 
if(Owner())
  Owner()->Garbages().add(this);
else
  Garbages().add(this);
#ifdef VDKDEBUG
  objRemoved ++;
#endif
}

/*
explicitely destroy this
*/

bool VDKObject::Destroy()
{
  VDKObject* parent = NULL;
  for(parent = Parent() ; parent; parent = parent->Parent())
    if( Parent()->Items().remove(this) || 
	 Parent()->Garbages().remove(this) ) 
      break;
  if(parent)
    {
#ifdef VDKDEBUG
      printf("\ndestroyed:%p",this);
     fflush(stdout);
#endif
     if(widget && GTK_IS_WIDGET(widget))
       {
	 if (widget->parent)
#ifdef VDKDEBUG
	   {
#endif
	   gtk_container_remove (GTK_CONTAINER (widget->parent), widget);
#ifdef VDKDEBUG
	   printf(" (from gtk+ container)");
	   fflush(stdout);
	   }
#endif
	 else
	   {
	     SetVisible(false);
	     gtk_widget_unrealize(widget);
	   }
       }
     delete this;
     return true;
    } 
else
  return false;
}

/* 
 */
void VDKObject::Draw(GdkRectangle* area) 
{
  if(widget)
    gtk_widget_draw(widget,area); 
}

/*
 */
void SizeObjectProp::operator = (VDKPoint p)
{
  value = p;
  GtkWidget* wid = object->Widget();  
  if(wid)
    gtk_widget_set_usize(wid,p.X(), p.Y());
}

/*
 */
SizeObjectProp::operator VDKPoint()
{
  GtkWidget* wid = object->Widget();  
  return wid ? VDKPoint (wid->allocation.width,
			 wid->allocation.height) : VDKPoint(0,0);
}










