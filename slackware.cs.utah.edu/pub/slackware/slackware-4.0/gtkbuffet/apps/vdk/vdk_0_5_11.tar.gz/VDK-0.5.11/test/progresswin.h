/*
file: progresswin.h
*/
#include <vdk/vdk.h>
class ProgressWin: public VDKForm
{
  VDKProgressBar *bar;
  VDKLabelButton *stop,*start,*quit;
  VDKTimer *timer;
  VDKLabel *label;
public:
  ProgressWin(VDKForm* owner):
    VDKForm(owner,"This is a progress bar") {}
  ~ ProgressWin() {}
  void Setup();
  bool OnTimer(VDKObject*);
  bool Start(VDKObject*);
  bool Stop(VDKObject*);
  void OnShow(VDKForm* sender);
  bool CanClose();
  bool Quit(VDKObject*) { Close(); return true; }
DECLARE_SIGNAL_MAP(ProgressWin);
};
