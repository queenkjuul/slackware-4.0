/*
file: signalwin.h
*/
#include <vdk/vdk.h>
class SignalWin: public VDKForm
{
  VDKLabelButton *button;
  VDKPixmap      *pixmap;
  VDKLabel       *label;
  VDKCheckButton    *cb1,*cb2;
public:
  SignalWin(VDKForm* owner):
    VDKForm(owner,"More about signals and events") {}
  ~SignalWin() {}
  void Setup();
  bool ButtonClicked(VDKObject*);
  bool ButtonClicked1(VDKObject*);
  bool OnPixmapDoubleClick(VDKObject*,GdkEvent*);
  bool OnPixmapDoubleClick1(VDKObject*,GdkEvent*);
  bool OnLeaveButton(VDKObject*);
  bool OnToggleCb1(VDKObject*);
  bool OnToggleCb2(VDKObject*);
  DECLARE_SIGNAL_MAP(SignalWin);
  DECLARE_EVENT_MAP(SignalWin);
};
