/* GtkSamba-0.3.0
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */

#include "gtksamba.h"
#include <string.h>

static int smbwin_count=0;

int main (int argc, char *argv[]){
  char buff[1024];

  strcpy(buff,getenv("HOME"));
  strcat(buff,"/.gtkrc");

         
  gtk_init (&argc, &argv);
  gtk_rc_parse(buff);
  smbwin_new(NULL);
  g_print("Built with gtk+-%d.%d.%d\n",
	  GTK_MAJOR_VERSION, GTK_MINOR_VERSION, GTK_MICRO_VERSION);
	 
  gtk_main ();
          
  return 0;
}


SmbWin *smbwin_new(char *file){
  SmbWin *sw;
  
  
  char *service_title[1] = {
    "Service name"
  };
  

  smbwin_count++;
  
  sw=(SmbWin *)malloc(sizeof(SmbWin));

  sw->filepath[0]='\0';
  sw->sublist=NULL;
  sw->filew=NULL;
  sw->inserter=NULL;
  sw->diagwin=NULL;


  sw->window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
  
  gtk_window_set_title(GTK_WINDOW(sw->window), "Gtksamba");
  gtk_signal_connect(GTK_OBJECT(sw->window),
		     "delete_event",
		     GTK_SIGNAL_FUNC(sw_delete_event),
		     (gpointer) sw);
  gtk_widget_set_usize(GTK_WIDGET(sw->window), 500, 300);

  sw->vbox=gtk_vbox_new(FALSE, 5);
  gtk_container_border_width(GTK_CONTAINER(sw->vbox), 5);
  gtk_container_add(GTK_CONTAINER(sw->window), sw->vbox);
  gtk_widget_show(sw->vbox);

  sw_main_menu(sw);
  sw_toolbars(sw);

  sw->hpaned = gtk_hpaned_new ();
  gtk_box_pack_start(GTK_BOX(sw->vbox), sw->hpaned, FALSE, TRUE, 0);
  
  gtk_widget_show (sw->hpaned);

  sw->servicelist = gtk_clist_new_with_titles( 1, service_title);
 
  /* gtk_clist_set_column_width (GTK_CLIST(sw->servicelist), 0, 100);*/


  gtk_clist_set_selection_mode(GTK_CLIST(sw->servicelist),
			       GTK_SELECTION_BROWSE);
  gtk_signal_connect(GTK_OBJECT(sw->servicelist),
		     "select_row",
		     GTK_SIGNAL_FUNC(c_select_service),
		     sw);
#if (GTK_MINOR_VERSION < 2) && ((GTK_MICRO_VERSION < 5) || (GTK_MINOR_VERSION < 1))
  gtk_clist_set_policy(GTK_CLIST(sw->servicelist), 
		       GTK_POLICY_AUTOMATIC,
		       GTK_POLICY_AUTOMATIC);
  gtk_paned_add1 (GTK_PANED(sw->hpaned), sw->servicelist);
  gtk_widget_set_usize(GTK_WIDGET(sw->servicelist), 150, 250);
  gtk_widget_show (sw->servicelist);
#else
  sw->leftscroll = gtk_scrolled_window_new(NULL, NULL);
  
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(sw->leftscroll), 
				 GTK_POLICY_AUTOMATIC, 
				 GTK_POLICY_AUTOMATIC);
  gtk_widget_show (sw->leftscroll);
  gtk_paned_add1 (GTK_PANED(sw->hpaned), sw->leftscroll);
  gtk_container_add (GTK_CONTAINER(sw->leftscroll), sw->servicelist);
  gtk_widget_set_usize(GTK_WIDGET(sw->servicelist), 140, 250);
  gtk_widget_show (sw->servicelist);
#endif
  sw->rightnote = gtk_notebook_new ();
  gtk_notebook_set_show_tabs(GTK_NOTEBOOK (sw->rightnote),FALSE);
  gtk_notebook_set_show_border(GTK_NOTEBOOK (sw->rightnote),FALSE);
  gtk_paned_add2 (GTK_PANED(sw->hpaned), sw->rightnote);
  gtk_widget_show (sw->rightnote);

  if(file)
    smbwin_open_lists(sw,file);

  gtk_widget_show(sw->window);

  return sw;
}
  

gint sw_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data){
  c_make_exit_dialog(widget,data);
  return TRUE;
}


void c_smbwin_destroy(GtkWidget *widget, gpointer sw){
  
 
  if(SMB_WIN(sw)->diagwin)
    gtk_widget_destroy(SMB_WIN(sw)->diagwin);
  if(SMB_WIN(sw)->inserter)
    gtk_widget_destroy(SMB_WIN(sw)->inserter);
 
  
  smbwin_clear_lists(SMB_WIN(sw));
  gtk_widget_destroy(SMB_WIN(sw)->window);
  if(SMB_WIN(sw)->filew)
    gtk_widget_destroy(SMB_WIN(sw)->filew);
  free(SMB_WIN(sw));
  
  smbwin_count--;
  if(smbwin_count <= 0)
    gtk_main_quit();
}

void c_smbwin_close(GtkWidget *button, gpointer sw){
  smbwin_clear_lists(SMB_WIN(sw));
  SMB_WIN(sw)->filepath[0]='\0';
  gtk_window_set_title(GTK_WINDOW(SMB_WIN(sw)->window), "Gtksamba");

  return;

}
  


void c_smbwin_new(GtkWidget *button, gpointer nulldata){
  smbwin_new(NULL);
}


void smbwin_filesel_ok(GtkWidget *button, gpointer sw){
  gtk_widget_hide(GTK_WIDGET (SMB_WIN(sw)->filew));
  resensitize_sw(sw);
  if(SMB_WIN(sw)->write)
    write_smb_file(SMB_WIN(sw)->servicelist,
		   gtk_file_selection_get_filename 
		   (GTK_FILE_SELECTION (SMB_WIN(sw)->filew)));

  else
  smbwin_open_lists(SMB_WIN(sw), 
		    gtk_file_selection_get_filename 
		    (GTK_FILE_SELECTION (SMB_WIN(sw)->filew)));
  return;
}

void smbwin_filesel_cancel(GtkWidget *button, gpointer sw){
  gtk_widget_hide(GTK_WIDGET (SMB_WIN(sw)->filew));
  resensitize_sw(sw);
  return;
}

int smbwin_filesel_delete(GtkWidget *window, GdkEvent *event, 
			  gpointer sw){
  gtk_widget_hide(GTK_WIDGET (SMB_WIN(sw)->filew));
  resensitize_sw(sw);
  return TRUE;
}

void cw_make_sensitive
(GtkWidget *widget){
  if(widget)
    gtk_widget_set_sensitive(widget,TRUE);
  return;
}


void smbwin_filesel(GtkWidget *button, gpointer sw){

  desensitize_sw(sw);
  
  if(!SMB_WIN(sw)->filew){
    SMB_WIN(sw)->filew = gtk_file_selection_new ("File selection");
          

    gtk_signal_connect(GTK_OBJECT (SMB_WIN(sw)->filew),
		       "delete_event",
		       (GtkSignalFunc) smbwin_filesel_delete,
		       SMB_WIN(sw));
		       
		       
    /* Connect the ok_button to file_ok_sel function */
    gtk_signal_connect 
      (GTK_OBJECT (GTK_FILE_SELECTION (SMB_WIN(sw)->filew)->ok_button),
       "clicked", (GtkSignalFunc) smbwin_filesel_ok, SMB_WIN(sw));
          
    /* Connect the cancel_button to destroy the widget */
    gtk_signal_connect 
      (GTK_OBJECT (GTK_FILE_SELECTION (SMB_WIN(sw)->filew)->cancel_button),
       "clicked", (GtkSignalFunc) smbwin_filesel_cancel ,SMB_WIN(sw));
    

    
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(SMB_WIN(sw)->filew),
				    CONFILE);

  }
  gtk_widget_show(GTK_WIDGET (SMB_WIN(sw)->filew));

  return;

}

void c_conf_open(GtkWidget *widget, gpointer sw){
  smbwin_open_lists(SMB_WIN(sw),CONFILE);

}


void c_alt_open(GtkWidget *button, gpointer sw){
  SMB_WIN(sw)->write=0;
  smbwin_filesel(button, sw);
}

  

void c_write_conf(GtkWidget *widget, gpointer sw){
  write_smb_file(SMB_WIN(sw)->servicelist,SMB_WIN(sw)->filepath);
  return;
}

void c_write_alt(GtkWidget *button, gpointer sw){
  SMB_WIN(sw)->write=1;
  smbwin_filesel(button, sw);
}




void c_edit_param(GtkWidget *menu_item, gpointer sw){
  if(SMB_WIN(sw)->sublist && GTK_CLIST(SMB_WIN(sw)->sublist)->selection)
    make_edit_dialog(SMB_WIN(sw));
  else
    make_error_mesg("  Cannot edit parameter:  ",
		    "  nothing is selected  ");
  return;
}
  


void c_delete_param(GtkWidget *menu_item, gpointer sw){
  if(SMB_WIN(sw)->sublist && GTK_CLIST(SMB_WIN(sw)->sublist)->selection)
    make_del_dialog(SMB_WIN(sw));
  else
    make_error_mesg("  Cannot delete parameter:  ",
		    "  nothing is selected  ");
  return;
}

void c_delete_service(GtkWidget *menu_item, gpointer sw){
  if(GTK_CLIST(SMB_WIN(sw)->servicelist)->selection)
    make_del_service_dialog(SMB_WIN(sw));
  return;
}
void c_insert_service(GtkWidget *menu_item, gpointer sw){
  make_insert_service_dialog(SMB_WIN(sw));
}

void c_help_about(GtkWidget *widget, gpointer data){
  make_error_mesg(VERSION,
		  " by Perry Piplani coder@open-systems.com ");
}

void c_help_sel_param(GtkWidget *widget, gpointer data){
  int row;
  SmbWin *sw;
  char *text;
 
  sw=SMB_WIN(data);

  if(sw->sublist && GTK_CLIST(sw->sublist)->selection){
    row = (int)(GTK_CLIST(sw->sublist)->selection->data);
    gtk_clist_get_text(GTK_CLIST(sw->sublist),
		       row ,0,&text);
    make_param_help(text);
  }
  else
    make_error_mesg("  No parameter selected:  ",
		    "");
}

  

void c_param_diag_cancel(GtkWidget *button, gpointer data){
  SmbWin *sw;
 
  sw=SMB_WIN(data);

  resensitize_sw(sw);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;

}

void c_param_diag_delete(GtkWidget *button, GdkEvent *event, 
			  gpointer data){
  SmbWin *sw;

  sw=SMB_WIN(data);

  
  resensitize_sw(sw);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;

}

void c_make_exit_dialog(GtkWidget *widget, SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;

  desensitize_sw(sw);

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),"Exit");
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new("  Do you really want to quit?  ");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new(" ");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  button = gtk_button_new_with_label("Yes");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_smbwin_destroy),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);


  
  gtk_widget_show(sw->diagwin);
  return;
}

void desensitize_sw(SmbWin *sw){
  gtk_widget_set_sensitive(SMB_WIN(sw)->window,FALSE);
  if(sw->inserter)
    gtk_widget_set_sensitive(SMB_WIN(sw)->inserter,FALSE);
  return;
}


void resensitize_sw(SmbWin *sw){
  gtk_widget_set_sensitive(SMB_WIN(sw)->window,TRUE);
  if(sw->inserter)
    gtk_widget_set_sensitive(SMB_WIN(sw)->inserter,TRUE);
  return;
}



  

