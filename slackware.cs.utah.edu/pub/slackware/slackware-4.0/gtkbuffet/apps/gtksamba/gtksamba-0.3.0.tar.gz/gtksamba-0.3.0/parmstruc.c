/* GtkSamba-0.3.0
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */


#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "gtksamba.h"

/*** from smb.h *** defs for parm structure */

typedef enum
{
  P_BOOL,P_BOOLREV,P_CHAR,P_INTEGER,P_OCTAL,
  P_STRING,P_USTRING,P_GSTRING,P_UGSTRING,P_ENUM,P_SEP
} parm_type;

typedef enum
{
  P_LOCAL,P_GLOBAL,P_SEPARATOR,P_NONE
} parm_class;

struct enum_list {
	int value;
	char *name;
};

/* four members snipped */
struct parm_struct
{
	char *label;
	parm_type type;
	parm_class class;
	struct enum_list *enum_list;
	
};

/* value enums for emum list */

/* protocol types. It assumes that higher protocols include lower protocols
   as subsets */
enum protocol_types {PROTOCOL_NONE,PROTOCOL_CORE,PROTOCOL_COREPLUS,PROTOCOL_LANMAN1,PROTOCOL_LANMAN2,PROTOCOL_NT1};

/* security levels */
enum security_types {SEC_SHARE,SEC_USER,SEC_SERVER,SEC_DOMAIN};

/* printing types */
enum printing_types {PRINT_BSD,PRINT_SYSV,PRINT_AIX,PRINT_HPUX,
		     PRINT_QNX,PRINT_PLP,PRINT_LPRNG,PRINT_SOFTQ};

/* case handling */
enum case_handling {CASE_LOWER,CASE_UPPER};

/* Types of machine we can announce as. */
#define ANNOUNCE_AS_NT 1
#define ANNOUNCE_AS_WIN95 2
#define ANNOUNCE_AS_WFW 3



#define NEVER_MAP_TO_GUEST 0
#define MAP_TO_GUEST_ON_BAD_USER 1
#define MAP_TO_GUEST_ON_BAD_PASSWORD 2

#ifdef WITH_SSL
/* SSL version options */
enum ssl_version_enum {SMB_SSL_V2,SMB_SSL_V3,SMB_SSL_V23,SMB_SSL_TLS1};
#endif /* WITH_SSL */


static struct enum_list enum_protocol[] = {{PROTOCOL_NT1, "NT1"}, {PROTOCOL_LANMAN2, "LANMAN2"}, 
					   {PROTOCOL_LANMAN1, "LANMAN1"}, {PROTOCOL_CORE,"CORE"}, 
					   {PROTOCOL_COREPLUS, "COREPLUS"}, 
					   {PROTOCOL_COREPLUS, "CORE+"}, {-1, NULL}};

static struct enum_list enum_security[] = {{SEC_SHARE, "SHARE"},  {SEC_USER, "USER"}, 
					   {SEC_SERVER, "SERVER"}, {SEC_DOMAIN, "DOMAIN"},
                                           {-1, NULL}};

static struct enum_list enum_printing[] = {{PRINT_SYSV, "sysv"}, {PRINT_AIX, "aix"}, 
					   {PRINT_HPUX, "hpux"}, {PRINT_BSD, "bsd"},
					   {PRINT_QNX, "qnx"},   {PRINT_PLP, "plp"},
					   {PRINT_LPRNG, "lprng"}, {PRINT_SOFTQ, "softq"},
					   {-1, NULL}};

static struct enum_list enum_announce_as[] = {{ANNOUNCE_AS_NT, "NT"}, {ANNOUNCE_AS_WIN95, "win95"},
					      {ANNOUNCE_AS_WFW, "WfW"}, {-1, NULL}};

static struct enum_list enum_case[] = {{CASE_LOWER, "lower"}, {CASE_UPPER, "upper"}, {-1, NULL}};

static struct enum_list enum_lm_announce[] = {{0, "False"}, {1, "True"}, {2, "Auto"}, {-1, NULL}};


static struct enum_list enum_map_to_guest[] = {{NEVER_MAP_TO_GUEST, "Never"}, {MAP_TO_GUEST_ON_BAD_USER, "Bad User"}, {MAP_TO_GUEST_ON_BAD_PASSWORD, "Bad Password"}, {-1, NULL}};




#ifdef WITH_SSL
static struct enum_list enum_ssl_version[] = {{SMB_SSL_V2, "ssl2"}, {SMB_SSL_V3, "ssl3"},
  {SMB_SSL_V23, "ssl2or3"}, {SMB_SSL_TLS1, "tls1"}, {-1, NULL}};
#endif

/* param table modified with awk and some hand editing */
static struct parm_struct parm_table[] =
{
  {"Base Options", P_SEP, P_SEPARATOR},
  {"comment",          P_STRING,  P_LOCAL,   NULL},
  {"path",             P_STRING,  P_LOCAL,   NULL},
  {"directory",        P_STRING,  P_LOCAL,   NULL},
  {"workgroup",        P_USTRING, P_GLOBAL,   NULL},
  {"netbios name",     P_UGSTRING,P_GLOBAL,   NULL},
  {"netbios aliases",  P_STRING,  P_GLOBAL,   NULL},
  {"server string",    P_STRING,  P_GLOBAL,   NULL},
  {"interfaces",       P_STRING,  P_GLOBAL,   NULL},
  {"bind interfaces only", P_BOOL,P_GLOBAL,   NULL},

  {"Security Options", P_SEP, P_SEPARATOR},
  {"security",         P_ENUM,    P_GLOBAL,   enum_security},
  {"encrypt passwords",P_BOOL,    P_GLOBAL,   NULL},
  {"update encrypted", P_BOOL,    P_GLOBAL,   NULL},
  {"use rhosts",       P_BOOL,    P_GLOBAL,   NULL},
  {"map to guest",     P_ENUM,    P_GLOBAL,   enum_map_to_guest},
  {"null passwords",   P_BOOL,    P_GLOBAL,   NULL},
  {"password server",  P_STRING,  P_GLOBAL,   NULL},
  {"smb passwd file",  P_STRING,  P_GLOBAL,   NULL},
  {"hosts equiv",      P_STRING,  P_GLOBAL,   NULL},
  {"root directory",   P_STRING,  P_GLOBAL,   NULL},
  {"root dir",         P_STRING,  P_GLOBAL,   NULL},
  {"root",             P_STRING,  P_GLOBAL,   NULL},
  {"passwd program",   P_STRING,  P_GLOBAL,   NULL},
  {"passwd chat",      P_STRING,  P_GLOBAL,   NULL},
  {"passwd chat debug",P_BOOL,    P_GLOBAL,   NULL},
  {"username map",     P_STRING,  P_GLOBAL,   NULL},
  {"password level",   P_INTEGER, P_GLOBAL,   NULL},
  {"username level",   P_INTEGER, P_GLOBAL,   NULL},
  {"unix password sync", P_BOOL,  P_GLOBAL,   NULL},
  {"alternate permissions",P_BOOL,P_LOCAL,   NULL},
  {"revalidate",       P_BOOL,    P_LOCAL,   NULL},
  {"username",         P_STRING,  P_LOCAL,   NULL},
  {"user",             P_STRING,  P_LOCAL,   NULL},
  {"users",            P_STRING,  P_LOCAL,   NULL},
  {"guest account",    P_STRING,  P_LOCAL,   NULL},
  {"invalid users",    P_STRING,  P_LOCAL,   NULL},
  {"valid users",      P_STRING,  P_LOCAL,   NULL},
  {"admin users",      P_STRING,  P_LOCAL,   NULL},
  {"read list",        P_STRING,  P_LOCAL,   NULL},
  {"write list",       P_STRING,  P_LOCAL,   NULL},
  {"force user",       P_STRING,  P_LOCAL,   NULL},
  {"force group",      P_STRING,  P_LOCAL,   NULL},
  {"group",            P_STRING,  P_LOCAL,   NULL},
  {"read only",        P_BOOL,    P_LOCAL,   NULL},
  {"write ok",         P_BOOLREV, P_LOCAL,   NULL},
  {"writeable",        P_BOOLREV, P_LOCAL,   NULL},
  {"writable",         P_BOOLREV, P_LOCAL,   NULL},
  {"create mask",      P_OCTAL,   P_LOCAL,   NULL},
  {"create mode",      P_OCTAL,   P_LOCAL,   NULL},
  {"force create mode",P_OCTAL,   P_LOCAL,   NULL},
  {"directory mask",   P_OCTAL,   P_LOCAL,   NULL},
  {"directory mode",   P_OCTAL,   P_LOCAL,   NULL},
  {"force directory mode",   P_OCTAL,   P_LOCAL,   NULL},
  {"guest only",       P_BOOL,    P_LOCAL,   NULL},
  {"only guest",       P_BOOL,    P_LOCAL,   NULL},
  {"guest ok",         P_BOOL,    P_LOCAL,   NULL},
  {"public",           P_BOOL,    P_LOCAL,   NULL},
  {"only user",        P_BOOL,    P_LOCAL,   NULL},
  {"hosts allow",      P_STRING,  P_LOCAL,   NULL},
  {"allow hosts",      P_STRING,  P_LOCAL,   NULL},
  {"hosts deny",       P_STRING,  P_LOCAL,   NULL},
  {"deny hosts",       P_STRING,  P_LOCAL,   NULL},

#ifdef WITH_SSL
  {"Secure Socket Layer Options", P_SEP, P_SEPARATOR},
  {"ssl",              P_BOOL,    P_GLOBAL,   NULL},
  {"ssl hosts",        P_STRING,  P_GLOBAL,   NULL},
  {"ssl hosts resign", P_STRING,  P_GLOBAL,   NULL},
  {"ssl CA certDir",   P_STRING,  P_GLOBAL,   NULL},
  {"ssl CA certFile",  P_STRING,  P_GLOBAL,   NULL},
  {"ssl server cert",  P_STRING,  P_GLOBAL,   NULL},
  {"ssl server key",   P_STRING,  P_GLOBAL,   NULL},
  {"ssl client cert",  P_STRING,  P_GLOBAL,   NULL},
  {"ssl client key",   P_STRING,  P_GLOBAL,   NULL},
  {"ssl require clientcert",  P_BOOL,  P_GLOBAL,   NULL },
  {"ssl require servercert",  P_BOOL,  P_GLOBAL,   NULL },
  {"ssl ciphers",      P_STRING,  P_GLOBAL,   NULL},
  {"ssl version",      P_ENUM,    P_GLOBAL,   enum_ssl_version},
  {"ssl compatibility", P_BOOL,    P_GLOBAL,   NULL},
#endif

  {"Logging Options", P_SEP, P_SEPARATOR},
  {"log level",        P_INTEGER, P_GLOBAL,   NULL},
  {"debuglevel",       P_INTEGER, P_GLOBAL,   NULL},
  {"syslog",           P_INTEGER, P_GLOBAL,   NULL},
  {"syslog only",      P_BOOL,    P_GLOBAL,   NULL},
  {"log file",         P_STRING,  P_GLOBAL,   NULL},
  {"max log size",     P_INTEGER, P_GLOBAL,   NULL},
  {"timestamp logs",   P_BOOL,    P_GLOBAL,   NULL},
  {"debug timestamp",  P_BOOL,    P_GLOBAL,   NULL},
  {"status",           P_BOOL,    P_LOCAL,   NULL},

  {"Protocol Options", P_SEP, P_SEPARATOR},
  {"protocol",         P_ENUM,    P_GLOBAL,   enum_protocol},
  {"read bmpx",        P_BOOL,    P_GLOBAL,   NULL},
  {"read raw",         P_BOOL,    P_GLOBAL,   NULL},
  {"write raw",        P_BOOL,    P_GLOBAL,   NULL},
  {"nt smb support",   P_BOOL,    P_GLOBAL,   NULL},
  {"nt pipe support",   P_BOOL,    P_GLOBAL,   NULL},
  {"announce version", P_STRING,  P_GLOBAL,   NULL},
  {"announce as",      P_ENUM,    P_GLOBAL,   enum_announce_as},
  {"max mux",          P_INTEGER, P_GLOBAL,   NULL},
  {"max xmit",         P_INTEGER, P_GLOBAL,   NULL},
  {"name resolve order",  P_STRING,  P_GLOBAL,   NULL},
  {"max packet",       P_INTEGER, P_GLOBAL,   NULL},
  {"packet size",      P_INTEGER, P_GLOBAL,   NULL},
  {"max ttl",          P_INTEGER, P_GLOBAL,   NULL},
  {"max wins ttl",     P_INTEGER, P_GLOBAL,   NULL},
  {"min wins ttl",     P_INTEGER, P_GLOBAL,   NULL},
  {"time server",      P_BOOL,    P_GLOBAL,   NULL},

  {"Tuning Options", P_SEP, P_SEPARATOR},
  {"change notify timeout", P_INTEGER, P_GLOBAL,   NULL},
  {"deadtime",         P_INTEGER, P_GLOBAL,   NULL},
  {"getwd cache",      P_BOOL,    P_GLOBAL,   NULL},
  {"keepalive",        P_INTEGER, P_GLOBAL,   NULL},
  {"lpq cache time",   P_INTEGER, P_GLOBAL,   NULL},
  {"max connections",  P_INTEGER, P_LOCAL,   NULL},
  {"max disk size",    P_INTEGER, P_GLOBAL,   NULL},
  {"max open files",   P_INTEGER, P_GLOBAL,   NULL},
  {"min print space",  P_INTEGER, P_LOCAL,   NULL},
  {"read prediction",  P_BOOL,    P_GLOBAL,   NULL},
  {"read size",        P_INTEGER, P_GLOBAL,   NULL},
  {"shared mem size",  P_INTEGER, P_GLOBAL,   NULL},
  {"socket options",   P_GSTRING, P_GLOBAL,   NULL},
  {"stat cache size",  P_INTEGER, P_GLOBAL,   NULL},
  {"strict sync",      P_BOOL,    P_LOCAL,   NULL},
  {"sync always",      P_BOOL,    P_LOCAL,   NULL},

  {"Printing Options", P_SEP, P_SEPARATOR},
  {"load printers",    P_BOOL,    P_GLOBAL,   NULL},
  {"printcap name",    P_STRING,  P_GLOBAL,   NULL},
  {"printcap",         P_STRING,  P_GLOBAL,   NULL},
  {"printer driver file", P_STRING,  P_GLOBAL,   NULL},
  {"print ok",         P_BOOL,    P_LOCAL,   NULL},
  {"printable",        P_BOOL,    P_LOCAL,   NULL},
  {"postscript",       P_BOOL,    P_LOCAL,   NULL},
  {"printing",         P_ENUM,    P_LOCAL,   enum_printing},
  {"print command",    P_STRING,  P_LOCAL,   NULL},
  {"lpq command",      P_STRING,  P_LOCAL,   NULL},
  {"lprm command",     P_STRING,  P_LOCAL,   NULL},
  {"lppause command",  P_STRING,  P_LOCAL,   NULL},
  {"lpresume command", P_STRING,  P_LOCAL,   NULL},
  {"queuepause command", P_STRING, P_LOCAL, NULL},
  {"queueresume command", P_STRING, P_LOCAL, NULL},
  {"printer name",     P_STRING,  P_LOCAL,   NULL},
  {"printer",          P_STRING,  P_LOCAL,   NULL},
  {"printer driver",   P_STRING,  P_LOCAL,   NULL},
  {"printer driver location",   P_STRING,  P_LOCAL,   NULL},

  {"Filename Handling", P_SEP, P_SEPARATOR},
  {"strip dot",        P_BOOL,    P_GLOBAL,   NULL},
  {"character set",    P_STRING,  P_GLOBAL, NULL},
  {"mangled stack",    P_INTEGER, P_GLOBAL,   NULL},
  {"coding system",    P_STRING,  P_GLOBAL, NULL},
  {"client code page", P_INTEGER, P_GLOBAL,   NULL},
  {"default case",     P_ENUM, P_LOCAL,   enum_case},
  {"case sensitive",   P_BOOL,    P_LOCAL,   NULL},
  {"casesignames",     P_BOOL,    P_LOCAL,   NULL},
  {"preserve case",    P_BOOL,    P_LOCAL,   NULL},
  {"short preserve case",P_BOOL,  P_LOCAL,   NULL},
  {"mangle case",      P_BOOL,    P_LOCAL,   NULL},
  {"mangling char",    P_CHAR,    P_LOCAL,   NULL},
  {"hide dot files",   P_BOOL,    P_LOCAL,   NULL},
  {"delete veto files",P_BOOL,    P_LOCAL,   NULL},
  {"veto files",       P_STRING,  P_LOCAL,   NULL},
  {"hide files",       P_STRING,  P_LOCAL,   NULL},
  {"veto oplock files",P_STRING,  P_LOCAL,   NULL},
  {"map system",       P_BOOL,    P_LOCAL,   NULL},
  {"map hidden",       P_BOOL,    P_LOCAL,   NULL},
  {"map archive",      P_BOOL,    P_LOCAL,   NULL},
  {"mangled names",    P_BOOL,    P_LOCAL,   NULL},
  {"mangled map",      P_STRING,  P_LOCAL,   NULL},
  {"stat cache",       P_BOOL,    P_GLOBAL,   NULL},

  {"Domain Options", P_SEP, P_SEPARATOR},
  {"domain groups",    P_STRING,  P_GLOBAL,   NULL},
  {"domain admin group",P_STRING, P_GLOBAL,   NULL},
  {"domain guest group",P_STRING, P_GLOBAL,   NULL},
  {"domain admin users",P_STRING, P_GLOBAL,   NULL},
  {"domain guest users",P_STRING, P_GLOBAL,   NULL},
#ifdef USING_GROUPNAME_MAP
  {"groupname map",     P_STRING, P_GLOBAL,   NULL},
#endif
  {"machine password timeout", P_INTEGER, P_GLOBAL,   NULL},

  {"Logon Options", P_SEP, P_SEPARATOR},
  {"logon script",     P_STRING,  P_GLOBAL,   NULL},
  {"logon path",       P_STRING,  P_GLOBAL,   NULL},
  {"logon drive",      P_STRING,  P_GLOBAL,   NULL},
  {"logon home",       P_STRING,  P_GLOBAL,   NULL},
  {"domain logons",    P_BOOL,    P_GLOBAL,   NULL},

  {"Browse Options", P_SEP, P_SEPARATOR},
  {"os level",         P_INTEGER, P_GLOBAL,   NULL},
  {"lm announce",      P_ENUM,    P_GLOBAL,   enum_lm_announce},
  {"lm interval",      P_INTEGER, P_GLOBAL,   NULL},
  {"preferred master", P_BOOL,    P_GLOBAL,   NULL},
  {"prefered master",  P_BOOL,    P_GLOBAL,   NULL},
  {"local master",     P_BOOL,    P_GLOBAL,   NULL},
  {"domain master",    P_BOOL,    P_GLOBAL,   NULL},
  {"browse list",      P_BOOL,    P_GLOBAL,   NULL},
  {"browseable",       P_BOOL,    P_LOCAL,   NULL},
  {"browsable",        P_BOOL,    P_LOCAL,   NULL},

  {"WINS Options", P_SEP, P_SEPARATOR},
  {"dns proxy",        P_BOOL,    P_GLOBAL,   NULL},
  {"wins proxy",       P_BOOL,    P_GLOBAL,   NULL},
  {"wins server",      P_STRING,  P_GLOBAL,   NULL},
  {"wins support",     P_BOOL,    P_GLOBAL,   NULL},

  {"Locking Options", P_SEP, P_SEPARATOR},
  {"blocking locks",   P_BOOL,    P_LOCAL,   NULL},
  {"fake oplocks",     P_BOOL,    P_LOCAL,   NULL},
  {"kernel oplocks",   P_BOOL,    P_GLOBAL,   NULL},
  {"locking",          P_BOOL,    P_LOCAL,   NULL},
  {"ole locking compatibility",   P_BOOL,    P_GLOBAL,   NULL},
  {"oplocks",          P_BOOL,    P_LOCAL,   NULL},
  {"strict locking",   P_BOOL,    P_LOCAL,   NULL},
  {"share modes",      P_BOOL,    P_LOCAL,   NULL},

#ifdef WITH_LDAP
  {"Ldap Options", P_SEP, P_SEPARATOR},
  {"ldap server",      P_STRING,  P_GLOBAL,   NULL},
  {"ldap port",        P_INTEGER, P_GLOBAL,   NULL},
  {"ldap suffix",      P_STRING,  P_GLOBAL,   NULL},
  {"ldap filter",      P_STRING,  P_GLOBAL,   NULL},
  {"ldap root",        P_STRING,  P_GLOBAL,   NULL},
  {"ldap root passwd", P_STRING,  P_GLOBAL,   NULL},
#endif

  {"Miscellaneous Options", P_SEP, P_SEPARATOR},
  {"smbrun",           P_STRING,  P_GLOBAL,   NULL},
  {"config file",      P_STRING,  P_GLOBAL,   NULL},
  {"preload",          P_STRING,  P_GLOBAL,   NULL},
  {"auto services",    P_STRING,  P_GLOBAL,   NULL},
  {"lock dir",         P_STRING,  P_GLOBAL,   NULL},
  {"lock directory",   P_STRING,  P_GLOBAL,   NULL},
  {"default service",  P_STRING,  P_GLOBAL,   NULL},
  {"default",          P_STRING,  P_GLOBAL,   NULL},
  {"message command",  P_STRING,  P_GLOBAL,   NULL},
  {"dfree command",    P_STRING,  P_GLOBAL,   NULL},
  {"valid chars",      P_STRING,  P_GLOBAL, NULL},
  {"remote announce",  P_STRING,  P_GLOBAL,   NULL},
  {"remote browse sync",P_STRING, P_GLOBAL,   NULL},
  {"socket address",   P_STRING,  P_GLOBAL,   NULL},
  {"homedir map",      P_STRING,  P_GLOBAL,   NULL},
  {"time offset",      P_INTEGER, P_GLOBAL,   NULL},
  {"unix realname",    P_BOOL,    P_GLOBAL,   NULL},
  {"NIS homedir",      P_BOOL,    P_GLOBAL,   NULL},
  {"-valid",           P_BOOL,    P_LOCAL,   NULL},
  {"copy",             P_STRING,  P_LOCAL, NULL},
  {"include",          P_STRING,  P_LOCAL, NULL},
  {"exec",             P_STRING,  P_LOCAL,   NULL},
  {"preexec",          P_STRING,  P_LOCAL,   NULL},
  {"postexec",         P_STRING,  P_LOCAL,   NULL},
  {"root preexec",     P_STRING,  P_LOCAL,   NULL},
  {"root postexec",    P_STRING,  P_LOCAL,   NULL},
  {"available",        P_BOOL,    P_LOCAL,   NULL},
  {"volume",           P_STRING,  P_LOCAL,   NULL},
  {"fstype",           P_STRING,  P_LOCAL,   NULL},
  {"set directory",    P_BOOLREV, P_LOCAL,   NULL},
  {"wide links",       P_BOOL,    P_LOCAL,   NULL},
  {"follow symlinks",  P_BOOL,    P_LOCAL,   NULL},
  {"dont descend",     P_STRING,  P_LOCAL,   NULL},
  {"magic script",     P_STRING,  P_LOCAL,   NULL},
  {"magic output",     P_STRING,  P_LOCAL,   NULL},
  {"delete readonly",  P_BOOL,    P_LOCAL,   NULL},
  {"dos filetimes",    P_BOOL,    P_LOCAL,   NULL},
  {"dos filetime resolution",P_BOOL,P_LOCAL,  NULL},
  {"fake directory create times", P_BOOL,P_LOCAL,   NULL},
  {"panic action",     P_STRING,  P_GLOBAL,   NULL},

  {NULL,               P_BOOL,    P_NONE,   NULL}

};

int is_oct(int c){
  if(c >= '0' && c <= '7')
    return 1;
  else
    return 0;
}


void c_edit_to_delete(GtkWidget *button, gpointer data){
  SmbWin *sw;
  sw=SMB_WIN(data);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  make_del_dialog(SMB_WIN(sw));
  return;
}


void c_entry_diag_ok(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row;
  char *text, *p;

  sw=SMB_WIN(data);
  text = gtk_entry_get_text(GTK_ENTRY(sw->entry));
  
  switch(parm_table[sw->pindex].type){
  case P_INTEGER:
    for(p = text; p && isdigit(*p); p++);
    if(*p){
      make_error_mesg("Oops!","  Integer value required. ");
      return;
    }
    break;
      
  case P_OCTAL:
    for(p = text; p && is_oct(*p); p++);
    if(*p){
      make_error_mesg("  Octal value required  ","e.g. 0755");
      return;
    }
    break;
    
  default:
    break;
  }
  
  row = (int)(GTK_CLIST(sw->sublist)->selection->data);

  gtk_clist_set_text(GTK_CLIST(sw->sublist),row,1,text);

  resensitize_sw(sw);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}


void make_entry_dialog(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  GtkWidget *entrybox;
  char *text;
  int row;
  GtkRequisition requisition;

  row = (int)(GTK_CLIST(sw->sublist)->selection->data);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,0,&text);

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),text);
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new(text);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new("");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_entry_diag_ok),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("help");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_help_sel_param),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);


  button = gtk_button_new_with_label("delete");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_edit_to_delete),
                     (gpointer) sw);
  gtk_widget_show(button);
  
  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,1,&text);

  switch(parm_table[sw->pindex].type){
  case P_OCTAL:
  case P_CHAR:
  case P_INTEGER:
    break;
  default:
    label = gtk_label_new("Enter Value:");
    gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
			label, TRUE, TRUE, 0);
    gtk_widget_show (label);
  }
  

  entrybox = gtk_hbox_new(FALSE,0);
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		     entrybox, TRUE, TRUE, 5);
  gtk_widget_show(entrybox);

  if(parm_table[sw->pindex].type == P_OCTAL){
    label = gtk_label_new("Octal Value:");
    gtk_box_pack_start (GTK_BOX (entrybox), 
		      label, TRUE, TRUE, 10);
    gtk_widget_show (label);
  }
  else if(parm_table[sw->pindex].type == P_CHAR){
    label = gtk_label_new("Enter Character:");
    gtk_box_pack_start (GTK_BOX (entrybox), 
		      label, TRUE, TRUE, 10);
    gtk_widget_show (label);
  }
  else if(parm_table[sw->pindex].type == P_INTEGER){
    label = gtk_label_new("Integer Value:");
    gtk_box_pack_start (GTK_BOX (entrybox), 
			label, TRUE, TRUE, 10);
    gtk_widget_show (label);
  }

  if(parm_table[sw->pindex].type == P_CHAR){
    sw->entry = gtk_entry_new_with_max_length(1);
    gtk_widget_size_request(sw->entry,&requisition);
    gtk_widget_set_usize(sw->entry,20,requisition.height);
  }
  else if(parm_table[sw->pindex].type == P_OCTAL){
    sw->entry = gtk_entry_new_with_max_length(4);
    gtk_widget_size_request(sw->entry,&requisition);
    gtk_widget_set_usize(sw->entry,40,requisition.height);
  }
  else if(parm_table[sw->pindex].type == P_INTEGER){
    sw->entry = gtk_entry_new_with_max_length(5);
    gtk_widget_size_request(sw->entry,&requisition);
    gtk_widget_set_usize(sw->entry,50,requisition.height);
  }
  else
    sw->entry = gtk_entry_new();
  gtk_entry_set_text(GTK_ENTRY(sw->entry),text);
  gtk_entry_select_region (GTK_ENTRY (sw->entry),
			   0, GTK_ENTRY(sw->entry)->text_length);
  gtk_box_pack_start(GTK_BOX (entrybox), 
		     sw->entry, TRUE, TRUE, 10);
  gtk_signal_connect(GTK_OBJECT(sw->entry), "activate",
		     GTK_SIGNAL_FUNC(c_entry_diag_ok),
                     (gpointer) sw);
  gtk_widget_show(sw->entry);
  gtk_widget_grab_focus(sw->entry);
  
  gtk_widget_show(sw->diagwin);
  return;
}

void c_enum_diag_ok(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row, i;
  struct enum_list *elist;

  sw=SMB_WIN(data);
  row = (int)(GTK_CLIST(sw->sublist)->selection->data);
  
  elist = parm_table[sw->pindex].enum_list;

  for(i=0; elist[i].value != -1; i++){
    if (GTK_TOGGLE_BUTTON (sw->radio[i])->active){
      gtk_clist_set_text(GTK_CLIST(sw->sublist),row,1,elist[i].name);
      break;
    }
  }

  resensitize_sw(sw);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}


void make_enum_dialog(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  GSList *group=NULL;
  char *text;
  int row;
  struct enum_list *elist;
  int i;

  row = (int)(GTK_CLIST(sw->sublist)->selection->data);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,0,&text);

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),text);
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new(text);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new("");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_enum_diag_ok),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("help");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_help_sel_param),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);


  button = gtk_button_new_with_label("delete");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_edit_to_delete),
                     (gpointer) sw);
  gtk_widget_show(button);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
		     row ,1,&text);

  elist = parm_table[sw->pindex].enum_list;
  

  for(i=0; elist[i].value != -1; i++){
    if(i)
      group = gtk_radio_button_group (GTK_RADIO_BUTTON (sw->radio[i-1]));

    sw->radio[i] = gtk_radio_button_new_with_label(group, elist[i].name);
    gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
			sw->radio[i], TRUE, TRUE, 0);
    gtk_widget_show (sw->radio[i]);
    if(!strcasecmp(text,elist[i].name))
       gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(sw->radio[i]),TRUE);
    
  }
  sw->radio[i]=NULL;
  gtk_widget_show(sw->diagwin);
}

int is_true(char *s){
  if(!strcasecmp(s,"true") || 
     !strcasecmp(s,"yes") ||
     !strcasecmp(s,"1"))
    return 1;
  else
    return 0;
}

void c_bool_diag_toggle(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row;
  char *text;

  sw=SMB_WIN(data);
  row = (int)(GTK_CLIST(sw->sublist)->selection->data);
  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,1,&text);

  if(is_true(text))
    gtk_clist_set_text(GTK_CLIST(sw->sublist),row,1,"False");
  else
    gtk_clist_set_text(GTK_CLIST(sw->sublist),row,1,"True");

  resensitize_sw(sw);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}


void make_bool_dialog(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  char *text;
  int row;
  

  row = (int)(GTK_CLIST(sw->sublist)->selection->data);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,0,&text);

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),text);
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new(text);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new("");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  

  button = gtk_button_new_with_label("toggle");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_bool_diag_toggle),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("help");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_help_sel_param),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);


  button = gtk_button_new_with_label("delete");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_edit_to_delete),
                     (gpointer) sw);
  gtk_widget_show(button);


  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,1,&text);
  
  if(is_true(text))
    label = gtk_label_new("current value: True");
  else
    label = gtk_label_new("current value: False");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new("");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
    


  gtk_widget_show(sw->diagwin);
}


void make_edit_dialog(SmbWin *sw){
  int i;
  char *text;
  int row;

  desensitize_sw(sw);

  row = (int)(GTK_CLIST(sw->sublist)->selection->data);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,0,&text);
  
  for(i=0; 
      parm_table[i].label && strcasecmp(text,parm_table[i].label) ; 
      i++);

  if(!parm_table[i].label){
    make_entry_dialog(sw);
    return;
  }

  sw->pindex = i;
  switch (parm_table[i].type) 
    {
    case P_BOOL:
    case P_BOOLREV:
      make_bool_dialog(sw);
      return;
	
    case P_CHAR:
      make_entry_dialog(sw);
      return;
	
    case P_INTEGER:
      make_entry_dialog(sw);
      return;

    case P_OCTAL:
      make_entry_dialog(sw);
      return;	
      
    case P_STRING:
    case P_USTRING:
    case P_GSTRING:
    case P_UGSTRING:
      make_entry_dialog(sw);
      return;
      
    case P_ENUM:
      make_enum_dialog(sw);
      return;;
	
    default:
      make_entry_dialog(sw);
      return;
    }
  return;
}

/************************************************************/
/************************************************************/
/************************************************************/
/************************************************************/

void c_entry_insert_help(GtkWidget *button, gpointer data){

  make_param_help((char *)data);  
  return;
}


void c_enum_insert_ok(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row, i;
  char *text[2];
  struct enum_list *elist;

  sw=SMB_WIN(data);

  
  elist = parm_table[sw->pindex].enum_list;

  for(i=0; elist[i].value != -1; i++){
    if (GTK_TOGGLE_BUTTON (sw->radio[i])->active){
      text[0] = parm_table[sw->pindex].label;

      if(GTK_CLIST(SMB_WIN(sw)->sublist)->selection)
	row = (int)(GTK_CLIST(sw->sublist)->selection->data);
      else
	row=GTK_CLIST(sw->sublist)->rows;
      text[1] = elist[i].name;
      
      gtk_clist_insert(GTK_CLIST(sw->sublist),row,text);
      break;
    }
  }

  resensitize_sw(sw);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}


void make_enum_insert(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  GSList *group=NULL;
  struct enum_list *elist;
  int i;

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),
		       parm_table[sw->pindex].label);
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new(parm_table[sw->pindex].label);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new("");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  

  button = gtk_button_new_with_label("Insert");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_enum_insert_ok),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("help");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_entry_insert_help),
                     parm_table[sw->pindex].label);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);

  elist = parm_table[sw->pindex].enum_list;
  

  for(i=0; elist[i].value != -1; i++){
    if(i)
      group = gtk_radio_button_group (GTK_RADIO_BUTTON (sw->radio[i-1]));

    sw->radio[i] = gtk_radio_button_new_with_label(group, elist[i].name);
    gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
			sw->radio[i], TRUE, TRUE, 0);
    gtk_widget_show (sw->radio[i]);
    
  }
  sw->radio[i]=NULL;
  gtk_widget_show(sw->diagwin);
}



void c_entry_insert_ok(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row;
  char *text[2], *p;

  sw=SMB_WIN(data);
  
  text[1] = gtk_entry_get_text(GTK_ENTRY(sw->entry));
  for(; *text[1] && isspace(*text[1]); text[1]++);
  if(!strlen(text[1])){
    make_error_mesg("Oops!","  Field is empty. ");
    return;
  }
  
    
  switch(parm_table[sw->pindex].type){
  case P_INTEGER:
    for(p = text[1]; p && isdigit(*p); p++);
    if(*p){
      make_error_mesg("Oops!","  Integer value required. ");
      return;
    }
    break;
      
  case P_OCTAL:
    for(p = text[1]; p && is_oct(*p); p++);
    if(*p){
      make_error_mesg("  Octal value required  ","e.g. 0755");
      return;
    }
    break;
    
  default:
    break;
  }
  text[0] = parm_table[sw->pindex].label;

  if(GTK_CLIST(SMB_WIN(sw)->sublist)->selection)
    row = (int)(GTK_CLIST(sw->sublist)->selection->data);
  else
    row=GTK_CLIST(sw->sublist)->rows;

  gtk_clist_insert(GTK_CLIST(sw->sublist),row,text);

  resensitize_sw(sw);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}


void make_entry_insert(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  GtkWidget *entrybox;
  GtkRequisition requisition;

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),
		       parm_table[sw->pindex].label);
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new(parm_table[sw->pindex].label);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new("");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  

  button = gtk_button_new_with_label("Insert");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_entry_insert_ok),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("help");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_entry_insert_help),
                     parm_table[sw->pindex].label);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);

  switch(parm_table[sw->pindex].type){
  case P_OCTAL:
  case P_CHAR:
  case P_INTEGER:
    break;
  default:
    label = gtk_label_new("Enter Value:");
    gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
			label, TRUE, TRUE, 0);
    gtk_widget_show (label);
  }
  

  entrybox = gtk_hbox_new(FALSE,0);
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		     entrybox, TRUE, TRUE, 5);
  gtk_widget_show(entrybox);

  if(parm_table[sw->pindex].type == P_OCTAL){
    label = gtk_label_new("Octal Value:");
    gtk_box_pack_start (GTK_BOX (entrybox), 
		      label, TRUE, TRUE, 10);
    gtk_widget_show (label);
  }
  else if(parm_table[sw->pindex].type == P_CHAR){
    label = gtk_label_new("Enter Character:");
    gtk_box_pack_start (GTK_BOX (entrybox), 
		      label, TRUE, TRUE, 10);
    gtk_widget_show (label);
  }
  else if(parm_table[sw->pindex].type == P_INTEGER){
    label = gtk_label_new("Integer Value:");
    gtk_box_pack_start (GTK_BOX (entrybox), 
			label, TRUE, TRUE, 10);
    gtk_widget_show (label);
  }

  if(parm_table[sw->pindex].type == P_CHAR){
    sw->entry = gtk_entry_new_with_max_length(1);
    gtk_widget_size_request(sw->entry,&requisition);
    gtk_widget_set_usize(sw->entry,20,requisition.height);
  }
  else if(parm_table[sw->pindex].type == P_OCTAL){
    sw->entry = gtk_entry_new_with_max_length(4);
    gtk_widget_size_request(sw->entry,&requisition);
    gtk_widget_set_usize(sw->entry,40,requisition.height);
  }
  else if(parm_table[sw->pindex].type == P_INTEGER){
    sw->entry = gtk_entry_new_with_max_length(5);
    gtk_widget_size_request(sw->entry,&requisition);
    gtk_widget_set_usize(sw->entry,50,requisition.height);
  }
  else
    sw->entry = gtk_entry_new();;
  gtk_box_pack_start(GTK_BOX (entrybox), 
		     sw->entry, TRUE, TRUE, 10);
  gtk_signal_connect(GTK_OBJECT(sw->entry), "activate",
		     GTK_SIGNAL_FUNC(c_entry_insert_ok),
                     (gpointer) sw);
  gtk_widget_show(sw->entry);
  gtk_widget_grab_focus(sw->entry);
  
  gtk_widget_show(sw->diagwin);
  return;
}

void c_bool_insert_yes(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row;
  char *text[2];

  sw=SMB_WIN(data);
  
  
  text[0] = parm_table[sw->pindex].label;
  text[1] = "yes";

  if(GTK_CLIST(SMB_WIN(sw)->sublist)->selection)
    row = (int)(GTK_CLIST(sw->sublist)->selection->data);
  else
    row=GTK_CLIST(sw->sublist)->rows;

  gtk_clist_insert(GTK_CLIST(sw->sublist),row,text);

  resensitize_sw(sw);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}

void c_bool_insert_no(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row;
  char *text[2];

  sw=SMB_WIN(data);
  
  
  text[0] = parm_table[sw->pindex].label;
  text[1] = "no";

  if(GTK_CLIST(SMB_WIN(sw)->sublist)->selection)
    row = (int)(GTK_CLIST(sw->sublist)->selection->data);
  else
    row=GTK_CLIST(sw->sublist)->rows;

  gtk_clist_insert(GTK_CLIST(sw->sublist),row,text);

  resensitize_sw(sw);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}



void make_bool_insert(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  GtkWidget *separator;

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin), 
		       parm_table[sw->pindex].label);
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new(parm_table[sw->pindex].label);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new("");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  

  button = gtk_button_new_with_label("True");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_bool_insert_yes),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("False");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_bool_insert_no),
                     (gpointer) sw);
  gtk_widget_show(button);

  separator = gtk_vseparator_new();
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     separator, TRUE, TRUE, 0);
  gtk_widget_show(separator);

  button = gtk_button_new_with_label("help");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_entry_insert_help),
                     parm_table[sw->pindex].label);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);

  


  
  gtk_widget_show(sw->diagwin);
}



void inserter_action(SmbWin *sw){
  int j, row;
  char *text;

  if(!sw->sublist){
    make_error_mesg("  Select or create a service  ",
		    "to insert into");
    return;
  }

  if(parm_table[sw->pindex].class == P_GLOBAL){
    row = (int)(GTK_CLIST(sw->servicelist)->selection->data);
    gtk_clist_get_text(GTK_CLIST(sw->servicelist),
		       row ,0,&text);
    if(strcasecmp(text,"global")){
      make_error_mesg(" This parameter is global in scope only  ",
		      "  switch service to 'global' to insert it  ");
      return;
    }
  }

  desensitize_sw(sw);
  
  for(j=0; j < GTK_CLIST(sw->sublist)->rows; j++){
    gtk_clist_get_text(GTK_CLIST(sw->sublist),
		       j,0,&text);
    if(!strcasecmp(text,parm_table[sw->pindex].label)){
      gtk_clist_select_row(GTK_CLIST(sw->sublist),j,0);
      make_edit_dialog(sw);
      return;
    }
  }

  switch (parm_table[sw->pindex].type) 
    {
    case P_BOOL:
    case P_BOOLREV:
      make_bool_insert(sw);
      return;
	
    case P_CHAR:
      make_entry_insert(sw);
      return;
	
    case P_INTEGER:
      make_entry_insert(sw);
      return;

    case P_OCTAL:
      make_entry_insert(sw);
      return;	
      
    case P_STRING:
    case P_USTRING:
    case P_GSTRING:
    case P_UGSTRING:
      make_entry_insert(sw);
      return;
      
    case P_ENUM:
      make_enum_insert(sw);
      return;;
	
    default:
      make_entry_insert(sw);
      return;
    }


  make_entry_insert(sw);
  return;
}

      

void c_insertmenu_insert(GtkWidget *widget, SmbWin *sw){
  int i, row;
  GtkWidget *innerbook;
  GtkWidget *clist;
  GtkWidget *page;


  i = gtk_notebook_current_page(GTK_NOTEBOOK(sw->outbook));
  if(!(innerbook = g_list_nth_data(sw->inslists,i) )){
    make_error_mesg("  Cannot get active page1  ",
		    "");
    return;
  }
  i = gtk_notebook_current_page(GTK_NOTEBOOK(innerbook));
  if(!(page = g_list_nth_data(GTK_NOTEBOOK(innerbook)->children,i))){
    make_error_mesg("  Cannot get active page2  ",
		    ""); 
    return;
  }
  if(!(clist = ((GtkNotebookPage *)page)->child)){
    make_error_mesg("  Cannot get active list  ",
		    "");
    return;
  }
  
#if !((GTK_MINOR_VERSION < 2) && ((GTK_MICRO_VERSION < 5) || (GTK_MINOR_VERSION < 1)))
  /*** if gtk version !< 1.1.5 clist in scrolled *****/
  if(!(clist = gtk_container_children(GTK_CONTAINER(clist))->data)){
    make_error_mesg("  Cannot get active list  ",
		    "");
    return;
  }
#endif

  if(!GTK_CLIST(clist)->selection){
    make_error_mesg("  Select the parmater  ",
		    "  you wish to enter  ");
    return;
  }
  row = (int)(GTK_CLIST(clist)->selection->data);
  i = (int)gtk_clist_get_row_data(GTK_CLIST(clist),row);
  sw->pindex = i;
  inserter_action(sw);
  return;
}

void c_insertmenu_help(GtkWidget *widget, SmbWin *sw){
  int i, row;
  GtkWidget *innerbook;
  GtkWidget *clist;
  GtkWidget *page;


  i = gtk_notebook_current_page(GTK_NOTEBOOK(sw->outbook));
  if(!(innerbook = g_list_nth_data(sw->inslists,i) )){
    make_error_mesg("  Cannot get active page  ",
		    "");
    return;
  }
  i = gtk_notebook_current_page(GTK_NOTEBOOK(innerbook));
  if(!(page = g_list_nth_data(GTK_NOTEBOOK(innerbook)->children,i))){
    make_error_mesg("  Cannot get active page  ",
		    ""); 
    return;
  }
  if(!(clist = ((GtkNotebookPage *)page)->child)){
    make_error_mesg("  Cannot get active list  ",
		    "");
    return;
  }
  
#if !((GTK_MINOR_VERSION < 2) && ((GTK_MICRO_VERSION < 5) || (GTK_MINOR_VERSION < 1)))
  /*** if gtk version !< 1.1.5 clist in scrolled *****/
  if(!(clist = gtk_container_children(GTK_CONTAINER(clist))->data)){
    make_error_mesg("  Cannot get active list  ",
		    "");
    return;
  }
#endif

  if(!GTK_CLIST(clist)->selection){
    make_error_mesg("  Select the parmater  ",
		    "  you wish to enter  ");
    return;
  }
  row = (int)(GTK_CLIST(clist)->selection->data);
  i = (int)gtk_clist_get_row_data(GTK_CLIST(clist),row);
  make_param_help(parm_table[i].label);
  return;
}

void c_insertmenu_click(GtkWidget *clist,
          gint row,
          gint column,
          GdkEventButton *event,
          gpointer data){

  SmbWin *sw;
  int i;

  sw=SMB_WIN(data);
  
  if(event && event->type==GDK_2BUTTON_PRESS){
    i = (int)gtk_clist_get_row_data(GTK_CLIST(clist),row);
    sw->pindex = i;
    inserter_action(sw);
  }
  return;
}


void c_make_inserter(GtkWidget *widget, gpointer data){
  GtkWidget *button;
  GtkWidget *clist1, *clist2, *clist3;
  GtkWidget *innervbox;
  GtkWidget *innerbook;
#if !((GTK_MINOR_VERSION < 2) && ((GTK_MICRO_VERSION < 5) || (GTK_MINOR_VERSION < 1)))
  /*** if gtk version !< 1.1.5 *****/
  GtkWidget *scrolled1, *scrolled2, *scrolled3;
#endif

  SmbWin *sw;
  GtkWidget *label;
  int i;
  int row;
  
  sw=SMB_WIN(data);

  if(!(sw->inserter)){
    sw->inslists = NULL;
    clist1 = clist2 = clist3 = NULL;
    sw->inserter = gtk_dialog_new ();
    gtk_window_set_title(GTK_WINDOW(sw->inserter),"Insert Parameters");
    gtk_signal_connect_object (GTK_OBJECT (sw->inserter), 
			       "delete_event",
			       GTK_SIGNAL_FUNC(gtk_widget_hide),
			       GTK_OBJECT (sw->inserter));
    gtk_widget_set_usize(sw->inserter, 420, 300);

    button = gtk_button_new_with_label("Insert");
    gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->inserter)->action_area), 
		       button, TRUE, TRUE, 10);
    gtk_signal_connect(GTK_OBJECT(button), "clicked",
		       GTK_SIGNAL_FUNC(c_insertmenu_insert), sw);
    gtk_widget_show(button);

    button = gtk_button_new_with_label("Help");
    gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->inserter)->action_area), 
		       button, TRUE, TRUE, 10);
    gtk_signal_connect(GTK_OBJECT(button), "clicked",
		       GTK_SIGNAL_FUNC(c_insertmenu_help), sw);
    gtk_widget_show(button);


    button = gtk_button_new_with_label("Done");
    gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->inserter)->action_area), 
		       button, TRUE, TRUE, 10);
    gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
			      GTK_SIGNAL_FUNC(gtk_widget_hide),
			      GTK_OBJECT(sw->inserter));
    gtk_widget_show(button);

    sw->outbook = gtk_notebook_new ();
    gtk_notebook_set_tab_pos (GTK_NOTEBOOK (sw->outbook), GTK_POS_LEFT);
    gtk_notebook_set_show_border(GTK_NOTEBOOK (sw->outbook),TRUE);
    gtk_notebook_set_scrollable(GTK_NOTEBOOK (sw->outbook),TRUE);
    gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->inserter)->vbox), 
            sw->outbook, TRUE, TRUE, 0);
    gtk_widget_show(sw->outbook);

    for(i=0; parm_table[i].label; i++){
      if(parm_table[i].type == P_SEP){

	innervbox=gtk_vbox_new(FALSE,0);
	gtk_widget_show (innervbox);
	label = gtk_label_new(parm_table[i].label);
	gtk_widget_show (label);
	gtk_notebook_append_page (GTK_NOTEBOOK (sw->outbook), innervbox, label);
	

        label = gtk_label_new(" Available Parameters ");
	gtk_box_pack_start (GTK_BOX (innervbox), 
		      label, FALSE, TRUE, 0);
	gtk_widget_show (label);
	
	innerbook = gtk_notebook_new ();
	gtk_notebook_set_tab_pos (GTK_NOTEBOOK (innerbook), GTK_POS_TOP);
	gtk_notebook_set_show_border(GTK_NOTEBOOK (innerbook),TRUE);
	gtk_box_pack_start (GTK_BOX (innervbox), 
            innerbook, TRUE, TRUE, 0);
	gtk_widget_show (innerbook);

	clist1 = gtk_clist_new(1);
 	gtk_clist_set_selection_mode(GTK_CLIST(clist1),
			       GTK_SELECTION_BROWSE);
	clist2 = gtk_clist_new(1);
 	gtk_clist_set_selection_mode(GTK_CLIST(clist2),
			       GTK_SELECTION_BROWSE);
	clist3 = gtk_clist_new(1);
 	gtk_clist_set_selection_mode(GTK_CLIST(clist3),
			       GTK_SELECTION_BROWSE);

	gtk_signal_connect(GTK_OBJECT(clist1),
			   "select_row",
			   GTK_SIGNAL_FUNC(c_insertmenu_click),
			   sw);
	gtk_signal_connect(GTK_OBJECT(clist2),
			   "select_row",
			   GTK_SIGNAL_FUNC(c_insertmenu_click),
			   sw);
	gtk_signal_connect(GTK_OBJECT(clist3),
			   "select_row",
			   GTK_SIGNAL_FUNC(c_insertmenu_click),
			   sw);

	
#if (GTK_MINOR_VERSION < 2) && ((GTK_MICRO_VERSION < 5) || (GTK_MINOR_VERSION < 1))
	/*gtk version < 1.1.5 ****/	
	gtk_clist_set_policy(GTK_CLIST(clist1), 
		       GTK_POLICY_AUTOMATIC,
		       GTK_POLICY_AUTOMATIC);

	gtk_clist_set_policy(GTK_CLIST(clist2), 
		       GTK_POLICY_AUTOMATIC,
		       GTK_POLICY_AUTOMATIC);
	gtk_clist_set_policy(GTK_CLIST(clist3), 
		       GTK_POLICY_AUTOMATIC,
		       GTK_POLICY_AUTOMATIC);
	gtk_widget_show (clist1);
	gtk_widget_show (clist2);
	gtk_widget_show (clist3);

	label = gtk_label_new("  Global  ");
	gtk_widget_show (label);
	gtk_notebook_append_page (GTK_NOTEBOOK (innerbook), clist1, label);
	label = gtk_label_new("  Local  ");
	gtk_widget_show (label);
	gtk_notebook_append_page (GTK_NOTEBOOK (innerbook), clist2, label);
	label = gtk_label_new("  All  ");
	gtk_widget_show (label);
	gtk_notebook_append_page (GTK_NOTEBOOK (innerbook), clist3, label);

#else
	/**** gtk version >= 1.1.5 *****/
	scrolled1 = gtk_scrolled_window_new(NULL, NULL);
	scrolled2 = gtk_scrolled_window_new(NULL, NULL);
	scrolled3 = gtk_scrolled_window_new(NULL, NULL);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled1), 
				       GTK_POLICY_AUTOMATIC, 
				       GTK_POLICY_AUTOMATIC);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled2), 
				       GTK_POLICY_AUTOMATIC, 
				       GTK_POLICY_AUTOMATIC);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled3), 
				       GTK_POLICY_AUTOMATIC, 
				       GTK_POLICY_AUTOMATIC);
	gtk_container_add (GTK_CONTAINER (scrolled1), clist1);
	gtk_container_add (GTK_CONTAINER (scrolled2), clist2);
	gtk_container_add (GTK_CONTAINER (scrolled3), clist3);
	gtk_widget_show (clist1);
	gtk_widget_show (clist2);
	gtk_widget_show (clist3);
	gtk_widget_show (scrolled1);
	gtk_widget_show (scrolled2);
	gtk_widget_show (scrolled3);
	label = gtk_label_new("  Global  ");
	gtk_widget_show (label);
	gtk_notebook_append_page (GTK_NOTEBOOK (innerbook), scrolled1, label);
	label = gtk_label_new("  Local  ");
	gtk_widget_show (label);
	gtk_notebook_append_page (GTK_NOTEBOOK (innerbook), scrolled2, label);
	label = gtk_label_new("  All  ");
	gtk_widget_show (label);
	gtk_notebook_append_page (GTK_NOTEBOOK (innerbook), scrolled3, label);
#endif

	sw->inslists = g_list_append(sw->inslists,innerbook);

      }
      else {
	if(parm_table[i].class == P_GLOBAL){
	  row = gtk_clist_append(GTK_CLIST(clist1), &(parm_table[i].label) );
	  gtk_clist_set_row_data(GTK_CLIST(clist1), row, (gpointer)i);
	}
	else {
	  row = gtk_clist_append(GTK_CLIST(clist2), &(parm_table[i].label) );
	  gtk_clist_set_row_data(GTK_CLIST(clist2), row, (gpointer)i);
	}
	row = gtk_clist_append(GTK_CLIST(clist3), &(parm_table[i].label) );
	gtk_clist_set_row_data(GTK_CLIST(clist3), row, (gpointer)i);
      }
    }
    gtk_notebook_set_page(GTK_NOTEBOOK (sw->outbook),0);
  }
  gtk_widget_show(sw->inserter);
  return;
}
    
