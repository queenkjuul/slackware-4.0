/* GtkSamba-0.3.0
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */


#include "params.h"
#include "gtksamba.h"
#include <unistd.h>


BOOL sfunc(char *service, void *data){
  SmbWin *sw;
  char *sublist_titles[2] = {"Parameter","Value"};
  int last_row;
  GtkWidget *label;
#if (GTK_MINOR_VERSION >= 2) || ((GTK_MICRO_VERSION >= 5) && (GTK_MINOR_VERSION >= 1))
  GtkWidget *scrolled;
#endif
  
  sw=SMB_WIN(data);

  last_row = gtk_clist_append(GTK_CLIST(sw->servicelist),&service);
  
  sw->sublist = gtk_clist_new_with_titles( 2, sublist_titles);
#if (GTK_MINOR_VERSION < 2) && ((GTK_MICRO_VERSION < 5) || (GTK_MINOR_VERSION < 1))
  gtk_clist_set_policy(GTK_CLIST(sw->sublist), GTK_POLICY_AUTOMATIC,
                       GTK_POLICY_AUTOMATIC);
  gtk_clist_set_selection_mode(GTK_CLIST(sw->sublist),GTK_SELECTION_BROWSE);
  gtk_clist_set_column_width (GTK_CLIST(sw->sublist),0,125);
  gtk_widget_show(sw->sublist);
  label=gtk_label_new(service);
  gtk_widget_show(label);
  gtk_notebook_append_page (GTK_NOTEBOOK (sw->rightnote),sw->sublist , label);
#else
  gtk_clist_set_selection_mode(GTK_CLIST(sw->sublist),GTK_SELECTION_BROWSE);
  gtk_clist_set_column_width (GTK_CLIST(sw->sublist),0,125);
  scrolled = gtk_scrolled_window_new(NULL, NULL);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled), 
				 GTK_POLICY_AUTOMATIC, 
				 GTK_POLICY_AUTOMATIC);
  gtk_container_add (GTK_CONTAINER (scrolled), sw->sublist);
  gtk_widget_show (sw->sublist);
  gtk_widget_show(scrolled);
  label=gtk_label_new(service);
  gtk_widget_show(label);
  gtk_notebook_append_page (GTK_NOTEBOOK (sw->rightnote),scrolled , label);
#endif
  gtk_signal_connect(GTK_OBJECT(sw->sublist),
                         "select_row",
                         GTK_SIGNAL_FUNC(c_select_param),
                         sw);
  gtk_clist_set_row_data(GTK_CLIST(sw->servicelist),last_row,
          (gpointer)(sw->sublist));

    
  return True;
}

BOOL pfunc(char *pname, char *pvalue, void *data){
  SmbWin *sw;

  char *pair[2];
  
  sw=SMB_WIN(data);
  pair[0]=pname;
  pair[1]=pvalue;
  
  if (!sw->sublist)
    return False;
  gtk_clist_append(GTK_CLIST(sw->sublist),pair);
  return True;
}

void smbwin_open_lists(SmbWin *sw, char *file){

  smbwin_clear_lists(sw);

  if(file){
    strcpy(sw->filepath,file);
    gtk_window_set_title(GTK_WINDOW(sw->window),file);
    pm_process(file,sfunc,pfunc,sw);
    gtk_clist_select_row(GTK_CLIST(sw->servicelist),0,0);
    gtk_widget_show (sw->sublist);
  }

  return;
  
}

void smbwin_clear_lists(SmbWin *sw){
  int i;



  for(i=0; i < GTK_CLIST(sw->servicelist)->rows; i++)
    gtk_notebook_remove_page(GTK_NOTEBOOK(sw->rightnote),0);
  sw->sublist=NULL;
  gtk_clist_clear(GTK_CLIST(sw->servicelist));
  
  return;
}

  
void smbwin_delete_service(SmbWin *sw){
  int row;

  row = (int)(GTK_CLIST(sw->servicelist)->selection->data);
  sw->sublist=NULL;
  gtk_notebook_remove_page(GTK_NOTEBOOK(sw->rightnote),row);
  
  gtk_clist_remove(GTK_CLIST(sw->servicelist),row);
  
}

void smbwin_insert_service(char *service, SmbWin *sw){
  GtkWidget *sub;
#if (GTK_MINOR_VERSION >= 2) || ((GTK_MICRO_VERSION >= 5) && (GTK_MINOR_VERSION >= 1))
  GtkWidget *scrolled;
#endif
  GtkWidget *label;
  char *sublist_titles[2] = {"Parameter","Value"};
  int row;
  
  if(GTK_CLIST(sw->servicelist)->selection)
    row = (int)(GTK_CLIST(sw->servicelist)->selection->data);
  else
    row=0;
  
  gtk_clist_insert(GTK_CLIST(sw->servicelist),row,&service);
  
  sub = gtk_clist_new_with_titles( 2, sublist_titles);

#if (GTK_MINOR_VERSION < 2) && ((GTK_MICRO_VERSION < 5) || (GTK_MINOR_VERSION < 1))
  gtk_clist_set_policy(GTK_CLIST(sub), GTK_POLICY_AUTOMATIC,
                       GTK_POLICY_AUTOMATIC);
  gtk_clist_set_selection_mode(GTK_CLIST(sub),GTK_SELECTION_BROWSE);
  gtk_clist_set_column_width (GTK_CLIST(sub),0,125);
  gtk_widget_show(sub);
  label=gtk_label_new(service);
  gtk_widget_show(label);
  gtk_notebook_insert_page (GTK_NOTEBOOK (sw->rightnote),sub , label, row);
#else
  gtk_clist_set_selection_mode(GTK_CLIST(sub),GTK_SELECTION_BROWSE);
  gtk_clist_set_column_width (GTK_CLIST(sub),0,125);
  scrolled = gtk_scrolled_window_new(NULL, NULL);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled), 
				 GTK_POLICY_AUTOMATIC, 
				 GTK_POLICY_AUTOMATIC);
  gtk_container_add (GTK_CONTAINER (scrolled), sub);
  gtk_widget_show (sub);
  gtk_widget_show(scrolled);
  label=gtk_label_new(service);
  gtk_widget_show(label);
  gtk_notebook_insert_page (GTK_NOTEBOOK (sw->rightnote),scrolled , label, row);
#endif
  gtk_signal_connect(GTK_OBJECT(sub),
                         "select_row",
                         GTK_SIGNAL_FUNC(c_select_param),
                         sw);
  gtk_clist_set_row_data(GTK_CLIST(sw->servicelist),row,
          (gpointer)(sub));

  gtk_clist_select_row(GTK_CLIST(sw->servicelist),row,0);

    
  return;
}
  

void c_select_param(GtkWidget *widget,
          gint row,
          gint column,
          GdkEventButton *event,
          gpointer data){
  if(event && event->type==GDK_2BUTTON_PRESS)
    make_edit_dialog(SMB_WIN(data));
  return;
}

void c_select_service(GtkWidget *widget,
          gint row,
          gint column,
          GdkEventButton *event,
          gpointer data){
  SmbWin *sw;
  
  
  sw=SMB_WIN(data);
  gtk_notebook_set_page(GTK_NOTEBOOK(sw->rightnote),row);
  sw->sublist=gtk_clist_get_row_data(GTK_CLIST(sw->servicelist),row);

}



void write_smb_file(GtkWidget *servicelist,char *filepath){
  FILE *outfile;
  GtkWidget *params;
  char *text;
  int i, j;

  printf("writing to %s, %d sections\n",filepath,GTK_CLIST(servicelist)->rows);
  
  outfile=fopen(filepath,"w");
  
  if(!outfile)
    outfile=stdout;
  
  for(i=0; i < GTK_CLIST(servicelist)->rows; i++){
    params = gtk_clist_get_row_data(GTK_CLIST(servicelist),i);
    gtk_clist_get_text(GTK_CLIST(servicelist),
             i,0,&text);
    fprintf(outfile,";*******************section %s*****************\n",text);
    fprintf(outfile,"[%s]\n",text);
    
    for(j=0; j < GTK_CLIST(params)->rows; j++){
      
      gtk_clist_get_text(GTK_CLIST(params),
          j,0,&text);
      fprintf(outfile,"%s = ",text);
      
      gtk_clist_get_text(GTK_CLIST(params),
          j,1,&text);
      fprintf(outfile,"%s\n",text);
    }
  }
  if(outfile != stdout)
    fclose(outfile);
  return;
}


FILE *make_man_pipe(){
  FILE *man = NULL;
  char buff[80];
  int i = 0;
  char *mans[] = {
    "/usr/man/man5/smb.conf.5",
    "/usr/local/man/man5/smb.conf.5",
    "/usr/man/man5/smb.conf.5.gz",
    "/usr/local/man/man5/smb.conf.5.gz",
    NULL } ;

  for(;mans[i];i++){
    if(!access(mans[i], R_OK | F_OK)){
      if (i > 1) sprintf(buff,"gunzip %s -c | groff -Tlatin1 -mandoc | col -b", mans[i]);
      else sprintf(buff,"groff -Tlatin1 -mandoc %s | col -b",mans[i]);
      man = popen(buff,"r");
      break;
    }
  }

  return man;
}


void make_param_help(char *param){
  GtkWidget *diag;
  GtkWidget *text;
  GtkWidget *button;
  GtkWidget *vscrollbar;
  GtkWidget *hbox;
  char buff[256], *s;
  char *paramplus;
  FILE *man;
  int len;

  
 
  man = make_man_pipe();
  if(!man){
    make_error_mesg("  Cannot open man page  ",
          "  verify you have it installed  ");
    return;
  }

  len=strlen(param)+3;
  paramplus=(char *)malloc(sizeof(char)*len+1);
  sprintf(paramplus,"   %s",param);

  while( (s = fgets(buff,256,man)) ){
    if( (strstr(buff,"(G)") || strstr(buff,"(S)")) && 
	!strncasecmp(buff,paramplus,len))
      break;
  }
  if(!s) {
    sprintf(buff," Can't find '%s' in man page  ",param);  
    make_error_mesg(buff,"  You're version of Samba may not support it  ");
    return;
  }


  
  diag=gtk_dialog_new ();

  gtk_widget_set_usize(diag, 420, 200);

  gtk_signal_connect_object(GTK_OBJECT(diag), "delete_event",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_window_set_title(GTK_WINDOW(diag),"GtkSamba Parameter Help");
  gtk_window_position (GTK_WINDOW (diag),GTK_WIN_POS_CENTER);

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
           button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_widget_show(button);

  hbox=gtk_hbox_new(FALSE,0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
            hbox, TRUE, TRUE, 0);
  gtk_widget_show (hbox);
  
  text = gtk_text_new(NULL,NULL);
  gtk_box_pack_start (GTK_BOX (hbox), 
            text, TRUE, TRUE, 0);
 
  vscrollbar = gtk_vscrollbar_new (GTK_TEXT(text)->vadj);
  gtk_box_pack_start(GTK_BOX(hbox), vscrollbar, FALSE, FALSE, 0);
  gtk_widget_show (vscrollbar);

  gtk_widget_realize (text);
  gtk_text_freeze (GTK_TEXT (text));


  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, 
		   NULL,buff, -1);


  while(fgets(buff,256,man)){
    if(strstr(buff,"(G)") || strstr(buff,"(S)"))
       break;
    if(strstr(buff,"NOTE ABOUT USERNAME/PASSWORD VALIDATION"))
      break;
   if(!strncmp(buff,"smb.conf",8) || !strncmp(buff,"SMB.CONF",8)){
      fgets(buff,256,man);
      fgets(buff,256,man);
    }
    else {
      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, 
             NULL,buff, -1);
    }
  }
  pclose(man);
  
  gtk_widget_show(text);

  gtk_widget_show(diag);

}

void make_overview_page(GtkWidget *notebook, GtkWidget **text, char *title){
  GtkWidget *vscrollbar;
  GtkWidget *hbox;
  GtkWidget *label;

  hbox=gtk_hbox_new(FALSE,0);
  gtk_widget_show (hbox);

  label = gtk_label_new(title);
  gtk_widget_show (label);
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), hbox, label);
  
  *text = gtk_text_new(NULL,NULL);
  gtk_box_pack_start (GTK_BOX (hbox), 
            *text, TRUE, TRUE, 0);
  gtk_widget_realize (*text);
  gtk_text_freeze (GTK_TEXT (*text));
  gtk_widget_show (*text);
 
  vscrollbar = gtk_vscrollbar_new (GTK_TEXT(*text)->vadj);
  gtk_box_pack_start(GTK_BOX(hbox), vscrollbar, FALSE, FALSE, 0);
  gtk_widget_show (vscrollbar);
 
  
}

void c_make_overview(GtkWidget *widget, gpointer data){
  GtkWidget *diag;
  GtkWidget *button;
  GtkWidget *notebook;
  GtkWidget *servicetext;
  GtkWidget *specialtext;
  GtkWidget *paramstext;
  char buff[256];
  FILE *man;
  


  man = make_man_pipe();
  if(!man){
    make_error_mesg("  Cannot open man page  ",
          "  verify you have it installed  ");
    return;
  }

  

  diag=gtk_dialog_new ();

  gtk_widget_set_usize(diag, 420, 300);

  gtk_signal_connect_object(GTK_OBJECT(diag), "delete_event",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_window_set_title(GTK_WINDOW(diag),"smb.conf overview");
  gtk_window_position (GTK_WINDOW (diag),GTK_WIN_POS_CENTER);

  button = gtk_button_new_with_label("Quit Help");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
           button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_widget_show(button);

  button = gtk_button_new_with_label("Look Up Parameter");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
           button, TRUE, TRUE, 10);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
           GTK_SIGNAL_FUNC(c_make_param_lookup), NULL);
  gtk_widget_show(button);

  notebook = gtk_notebook_new ();
  gtk_notebook_set_tab_pos (GTK_NOTEBOOK (notebook), GTK_POS_TOP);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
            notebook, TRUE, TRUE, 0);
  gtk_widget_show(notebook);
  
  make_overview_page(notebook,&servicetext,"Services");
  make_overview_page(notebook,&specialtext,"Special Sections");
  make_overview_page(notebook,&paramstext,"Parameters");


  while(fgets(buff,256,man)){
    if(!strncmp(buff,"SERVICE DESCRIPTIONS",18)){
      gtk_text_insert (GTK_TEXT (servicetext), NULL, 
             &servicetext->style->black, 
             NULL,buff, -1);
      break;
    }
  }
  
  while(fgets(buff,256,man)){
    if(!strncmp(buff,"SPECIAL SECTIONS",14)){
      gtk_text_insert (GTK_TEXT (specialtext), NULL, 
             &specialtext->style->black, 
             NULL,buff, -1);
      break;
    }
    if(!strncmp(buff,"smb.conf",8) || !strncmp(buff,"SMB.CONF",8)){
      fgets(buff,256,man);
      fgets(buff,256,man);
    }
    else {
      gtk_text_insert (GTK_TEXT (servicetext), NULL, 
             &servicetext->style->black, 
             NULL,buff, -1);
    }
  }
  
  while(fgets(buff,256,man)){
    if(!strncmp(buff,"PARAMETERS",9)){
      gtk_text_insert (GTK_TEXT (paramstext), NULL, 
             &paramstext->style->black, 
             NULL,buff, -1);
      break;
    }
    if(!strncmp(buff,"smb.conf",8) || !strncmp(buff,"SMB.CONF",8)){
      fgets(buff,256,man);
      fgets(buff,256,man);
    }
    else {
      gtk_text_insert (GTK_TEXT (specialtext), NULL, 
             &specialtext->style->black, 
             NULL,buff, -1);
    }
  }

  
  while(fgets(buff,256,man)){
    if(strstr(buff,"COMPLETE LIST OF GLOBAL PARAMETERS")){
      break;
    }
    if(!strncmp(buff,"smb.conf",8) || !strncmp(buff,"SMB.CONF",8)){
      fgets(buff,256,man);
      fgets(buff,256,man);
    }
    else {
    gtk_text_insert (GTK_TEXT (paramstext), NULL, 
           &paramstext->style->black, 
           NULL,buff, -1);
    }
  }
  
  pclose(man);
  
  gtk_widget_show(diag);

}

void cw_lookup_select(GtkWidget *clist){
  int row;
  char *text, *param;
  
  if(GTK_CLIST(clist)->selection){
    row = (int)(GTK_CLIST(clist)->selection->data);
    gtk_clist_get_text(GTK_CLIST(clist),row,0,&text);

    param=(char *)malloc(strlen(text)+1);
    strcpy(param,text);
    text=strchr(param,'(');
    *(text-1)='\0';
    make_param_help(param+3);
    free(param);
  }
  return;
}
  

void c_lookup_select(GtkWidget *clist,
                    gint row,
                    gint column,
                    GdkEventButton *event,
                    gpointer data){
  char *text, *param;
  
  if(event && event->type==GDK_2BUTTON_PRESS){

    gtk_clist_get_text(GTK_CLIST(clist),row,0,&text);

    param=(char *)malloc(strlen(text)+1);
    strcpy(param,text);
    text=strchr(param,'(');
    *(text-1)='\0';
    make_param_help(param+3);
    free(param);
  }
  return;
}


void c_make_param_lookup(GtkWidget *widget, gpointer data){
  GtkWidget *diag;
  GtkWidget *clist;
  GtkWidget *button;
  char buff[256];
  FILE *man;
  char *text;
#if !((GTK_MINOR_VERSION < 2) && ((GTK_MICRO_VERSION < 5) || (GTK_MINOR_VERSION < 1)))
  GtkWidget *scrolled;
#endif
  
  text=buff;
  man = make_man_pipe();
  if(!man){
    make_error_mesg("  Cannot open man page  ",
          "  verify you have it installed  ");
    return;
  }

  diag=gtk_dialog_new ();
  gtk_widget_set_usize(diag, 200, 200);
  gtk_signal_connect_object(GTK_OBJECT(diag), "delete_event",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_window_set_title(GTK_WINDOW(diag),"parameter lookup");
  gtk_window_position (GTK_WINDOW (diag),GTK_WIN_POS_CENTER);
 

  clist=gtk_clist_new(1);
  gtk_clist_set_selection_mode(GTK_CLIST(clist),
                               GTK_SELECTION_BROWSE);
  gtk_signal_connect(GTK_OBJECT(clist),
                     "select_row",
                     GTK_SIGNAL_FUNC(c_lookup_select),
                     NULL);
#if (GTK_MINOR_VERSION < 2) && ((GTK_MICRO_VERSION < 5) || (GTK_MINOR_VERSION < 1))
  gtk_clist_set_policy(GTK_CLIST(clist), GTK_POLICY_AUTOMATIC,
                       GTK_POLICY_AUTOMATIC);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
            clist, TRUE, TRUE, 0);
  gtk_widget_show (clist);
#else
  scrolled = gtk_scrolled_window_new(NULL, NULL);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled), GTK_POLICY_AUTOMATIC, 
				 GTK_POLICY_AUTOMATIC);
  gtk_container_add (GTK_CONTAINER (scrolled), clist);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
            scrolled, TRUE, TRUE, 0);
  gtk_widget_show (clist);
  gtk_widget_show (scrolled);
#endif

    button = gtk_button_new_with_label("look up");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
           button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
             GTK_SIGNAL_FUNC(cw_lookup_select),
             GTK_OBJECT(clist));
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
           button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_widget_show(button);

  while(fgets(buff,256,man)){
    if( strstr(buff,"(G)") || strstr(buff,"(S)")) 
      gtk_clist_append(GTK_CLIST(clist),&text);
  }

  pclose(man);
  gtk_widget_show(diag);
}
  



void c_run_testparm(GtkWidget *menu_item, gpointer sw){
  GtkWidget *diag;
  GtkWidget *text;
  GtkWidget *button;
  GtkWidget *vscrollbar;
  GtkWidget *hbox;
  FILE *tpout;
  char tempath[256];
  char buff[256];
  
  if(!(GTK_CLIST(SMB_WIN(sw)->servicelist)->rows)){
    make_error_mesg("  oops!!  ",
                    "  Nothing to test  ");
    return;
  }
  
  tmpnam(tempath);
  write_smb_file(SMB_WIN(sw)->servicelist,tempath);
  
  
  sprintf(buff,"echo | testparm %s", tempath);
  
  tpout = popen(buff,"r");
  if(!tpout){
    make_error_mesg("  oops!!  ",
                    "  Can't run testparm  ");
    return;
  }
  
  
  
  diag=gtk_dialog_new ();

  gtk_widget_set_usize(diag, 500, 300);

  gtk_signal_connect_object(GTK_OBJECT(diag), "delete_event",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_window_set_title(GTK_WINDOW(diag),"testparm results");
  gtk_window_position (GTK_WINDOW (diag),GTK_WIN_POS_CENTER);

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
           button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_widget_show(button);

  hbox=gtk_hbox_new(FALSE,0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
            hbox, TRUE, TRUE, 0);
  gtk_widget_show (hbox);
  
  text = gtk_text_new(NULL,NULL);
  gtk_box_pack_start (GTK_BOX (hbox), 
            text, TRUE, TRUE, 0);
 
  vscrollbar = gtk_vscrollbar_new (GTK_TEXT(text)->vadj);
  gtk_box_pack_start(GTK_BOX(hbox), vscrollbar, FALSE, FALSE, 0);
  gtk_widget_show (vscrollbar);

  gtk_widget_realize (text);
  gtk_text_freeze (GTK_TEXT (text));

  while(fgets(buff,256,tpout))
      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, 
             NULL,buff, -1);
      
  
  pclose(tpout);
  
  unlink(tempath);  
  
  gtk_widget_show(text);

  gtk_widget_show(diag);
  
  return;

}

void c_run_smbstatus(GtkWidget *widget, gpointer data){
  GtkWidget *diag;
  GtkWidget *text;
  GtkWidget *button;
  GtkWidget *vscrollbar;
  GtkWidget *hbox;
  FILE *ssout;
  char buff[256];
  
  ssout = popen("smbstatus","r");
  if(!ssout){
    make_error_mesg("  oops!!  ",
                    "  Can't run smbstatus  ");
    return;
  }
  
  
  
  diag=gtk_dialog_new ();

  gtk_widget_set_usize(diag, 500, 300);

  gtk_signal_connect_object(GTK_OBJECT(diag), "delete_event",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_window_set_title(GTK_WINDOW(diag),"Samba Status");
  gtk_window_position (GTK_WINDOW (diag),GTK_WIN_POS_CENTER);

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
           button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
             GTK_SIGNAL_FUNC(gtk_widget_destroy),
             GTK_OBJECT(diag));
  gtk_widget_show(button);

  hbox=gtk_hbox_new(FALSE,0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
            hbox, TRUE, TRUE, 0);
  gtk_widget_show (hbox);
  
  text = gtk_text_new(NULL,NULL);
  gtk_box_pack_start (GTK_BOX (hbox), 
            text, TRUE, TRUE, 0);
 
  vscrollbar = gtk_vscrollbar_new (GTK_TEXT(text)->vadj);
  gtk_box_pack_start(GTK_BOX(hbox), vscrollbar, FALSE, FALSE, 0);
  gtk_widget_show (vscrollbar);

  gtk_widget_realize (text);
  gtk_text_freeze (GTK_TEXT (text));

  while(fgets(buff,256,ssout))
      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, 
             NULL,buff, -1);
      
  
  pclose(ssout);
  
  gtk_widget_show(text);

  gtk_widget_show(diag);
  
  return;

}
