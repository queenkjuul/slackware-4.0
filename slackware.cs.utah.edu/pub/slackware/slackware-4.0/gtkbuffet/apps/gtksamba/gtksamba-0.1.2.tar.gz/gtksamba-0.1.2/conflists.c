/* GtkSamba-0.1.2
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */


#include "params.h"
#include "gtksamba.h"


BOOL sfunc(char *service, void *data){
  SmbWin *sw;
  char *sublist_titles[2] = {"Parameter","Value"};
  int last_row;

  sw=SMB_WIN(data);

  last_row = gtk_clist_append(GTK_CLIST(sw->servicelist),&service);
  
  sw->sublist = gtk_clist_new_with_titles( 2, sublist_titles);
  gtk_clist_set_policy(GTK_CLIST(sw->sublist), GTK_POLICY_AUTOMATIC,
                       GTK_POLICY_AUTOMATIC);
  gtk_clist_set_selection_mode(GTK_CLIST(sw->sublist),GTK_SELECTION_BROWSE);
  gtk_clist_set_column_width (GTK_CLIST(sw->sublist),0,125);
  gtk_widget_ref (GTK_WIDGET(sw->sublist));
  gtk_signal_connect(GTK_OBJECT(sw->sublist),
                         "select_row",
                         GTK_SIGNAL_FUNC(c_select_param),
                         sw);
  gtk_clist_set_row_data(GTK_CLIST(sw->servicelist),last_row,
			 (gpointer)(sw->sublist));

    
  return True;
}

BOOL pfunc(char *pname, char *pvalue, void *data){
  SmbWin *sw;

  char *pair[2];
  
  sw=SMB_WIN(data);
  pair[0]=pname;
  pair[1]=pvalue;
  
  if (!sw->sublist)
    return False;
  gtk_clist_append(GTK_CLIST(sw->sublist),pair);
  return True;
}

void smbwin_open_lists(SmbWin *sw, char *file){

  smbwin_clear_lists(sw);

  if(file){
    strcpy(sw->filepath,file);
    gtk_window_set_title(GTK_WINDOW(sw->window),file);
    pm_process(file,sfunc,pfunc,sw);
    gtk_clist_select_row(GTK_CLIST(sw->servicelist),0,0);
    /*gtk_widget_set_usize(GTK_WIDGET(sw->servicelist), 150, 250);*/
    gtk_widget_show (sw->sublist);
  }

  return;
  
}

void smbwin_clear_lists(SmbWin *sw){
  int i;

  if(GTK_PANED(sw->hpaned)->child2)
    gtk_container_remove (GTK_CONTAINER(sw->hpaned),
			  GTK_PANED(sw->hpaned)->child2);

  for(i=0; i < GTK_CLIST(sw->servicelist)->rows; i++){
    sw->sublist = gtk_clist_get_row_data(GTK_CLIST(sw->servicelist),i);
    gtk_clist_clear(GTK_CLIST(sw->sublist));
    gtk_widget_destroy (GTK_WIDGET(sw->sublist));
    gtk_widget_unref (GTK_WIDGET(sw->sublist));
   
  }
  sw->sublist=NULL;
  gtk_clist_clear(GTK_CLIST(sw->servicelist));
  
  return;
}

  
void smbwin_delete_service(SmbWin *sw){
  int row;

  if(GTK_PANED(sw->hpaned)->child2)
    gtk_container_remove (GTK_CONTAINER(sw->hpaned),
			  GTK_PANED(sw->hpaned)->child2);
  
  if(sw->sublist){
    gtk_clist_clear(GTK_CLIST(sw->sublist));
    gtk_widget_destroy (GTK_WIDGET(sw->sublist));
    gtk_widget_unref (GTK_WIDGET(sw->sublist));
    sw->sublist=NULL;
  }

  row = (int)(GTK_CLIST(sw->servicelist)->selection->data);
  gtk_clist_remove(GTK_CLIST(sw->servicelist),row);
}

void smbwin_insert_service(char *service, SmbWin *sw){
  GtkWidget *sub;
  char *sublist_titles[2] = {"Parameter","Value"};
  int row;
  
  if(GTK_CLIST(sw->servicelist)->selection)
    row = (int)(GTK_CLIST(sw->servicelist)->selection->data);
  else
    row=0;
  
  gtk_clist_insert(GTK_CLIST(sw->servicelist),row,&service);
  
  sub = gtk_clist_new_with_titles( 2, sublist_titles);
  gtk_clist_set_policy(GTK_CLIST(sub), GTK_POLICY_AUTOMATIC,
                       GTK_POLICY_AUTOMATIC);
  gtk_clist_set_selection_mode(GTK_CLIST(sub),GTK_SELECTION_BROWSE);
  gtk_clist_set_column_width (GTK_CLIST(sub),0,125);
  gtk_widget_ref (GTK_WIDGET(sub));
  gtk_signal_connect(GTK_OBJECT(sub),
                         "select_row",
                         GTK_SIGNAL_FUNC(c_select_param),
                         sw);
  gtk_clist_set_row_data(GTK_CLIST(sw->servicelist),row,
			 (gpointer)(sub));

  gtk_clist_select_row(GTK_CLIST(sw->servicelist),row,0);

    
  return;
}
  

void c_select_param(GtkWidget *widget,
		    gint row,
		    gint column,
		    GdkEventButton *event,
		    gpointer data){
  if(event && event->type==GDK_2BUTTON_PRESS)
    make_string_dialog(SMB_WIN(data));
  return;
}

void c_select_service(GtkWidget *widget,
		    gint row,
		    gint column,
		    GdkEventButton *event,
		    gpointer data){
  SmbWin *sw;
  
  sw=SMB_WIN(data);
  
  if(GTK_PANED(sw->hpaned)->child2)
    gtk_container_remove (GTK_CONTAINER(sw->hpaned),
			  GTK_PANED(sw->hpaned)->child2);

  sw->sublist=gtk_clist_get_row_data(GTK_CLIST(sw->servicelist),row);
  if(sw->sublist){
    gtk_paned_add2 (GTK_PANED(sw->hpaned), GTK_WIDGET(sw->sublist));
    /*gtk_widget_set_usize(GTK_WIDGET(sw->servicelist), 150, 250);*/
    gtk_widget_show (GTK_WIDGET(sw->sublist));
  }
}



void write_smb_file(GtkWidget *servicelist,char *filepath){
  FILE *outfile;
  GtkWidget *params;
  char *text;
  int i, j;

  printf("writing to %s, %d sections\n",filepath,GTK_CLIST(servicelist)->rows);
  
  outfile=fopen(filepath,"w");
  
  if(!outfile)
    outfile=stdout;
  
  for(i=0; i < GTK_CLIST(servicelist)->rows; i++){
    params = gtk_clist_get_row_data(GTK_CLIST(servicelist),i);
    gtk_clist_get_text(GTK_CLIST(servicelist),
		       i,0,&text);
    fprintf(outfile,";*******************section %s*****************\n",text);
    fprintf(outfile,"[%s]\n",text);
    
    for(j=0; j < GTK_CLIST(params)->rows; j++){
      
      gtk_clist_get_text(GTK_CLIST(params),
			 j,0,&text);
      fprintf(outfile,"%s = ",text);
      
      gtk_clist_get_text(GTK_CLIST(params),
			 j,1,&text);
      fprintf(outfile,"%s\n",text);
    }
  }
  if(outfile != stdout)
    fclose(outfile);
  return;
}


FILE *make_man_pipe(){
  FILE *man = NULL;
  char buff[80];
  int i = 0;
  char *mans[] = {
    "/usr/man/man5/smb.conf.5",
    "/usr/local/man/man5/smb.conf.5",
    NULL } ;

  for(;mans[i];i++){
    sprintf(buff,"[ -f %s ]",mans[i]);
    if(!system(buff)){
      sprintf(buff,"groff -Tascii -mandoc %s | col -b",mans[i]);
      man = popen(buff,"r");
      break;
    }
  }

  return man;
}


void make_param_help(char *param){
  GtkWidget *diag;
  GtkWidget *text;
  GtkWidget *button;
  GtkWidget *vscrollbar;
  GtkWidget *hbox;
  char buff[256];
  char *paramplus;
  FILE *man;
  int len;

 
  man = make_man_pipe();
  if(!man){
    make_error_mesg("  Cannot open man page  ",
		    "  verify you have it installed  ");
    return;
  }

  len=strlen(param)+4;
  paramplus=(char *)malloc(sizeof(char)*len+1);
  sprintf(paramplus,"   %s ",param);

  diag=gtk_dialog_new ();

  gtk_widget_set_usize(diag, 420, 200);

  gtk_signal_connect_object(GTK_OBJECT(diag), "delete_event",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(diag));
  gtk_window_set_title(GTK_WINDOW(diag),"GtkSamba Parameter Help");
  gtk_window_position (GTK_WINDOW (diag),GTK_WIN_POS_CENTER);

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
		     button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(diag));
  gtk_widget_show(button);

  hbox=gtk_hbox_new(FALSE,0);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
		      hbox, TRUE, TRUE, 0);
  gtk_widget_show (hbox);
  
  text = gtk_text_new(NULL,NULL);
  gtk_box_pack_start (GTK_BOX (hbox), 
		      text, TRUE, TRUE, 0);
 
  vscrollbar = gtk_vscrollbar_new (GTK_TEXT(text)->vadj);
  gtk_box_pack_start(GTK_BOX(hbox), vscrollbar, FALSE, FALSE, 0);
  gtk_widget_show (vscrollbar);

  gtk_widget_realize (text);
  gtk_text_freeze (GTK_TEXT (text));

  while(fgets(buff,256,man)){
    if( (strstr(buff,"(G)") || strstr(buff,"(S)")) && 
	!strncmp(buff,paramplus,len)){
      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, 
		       NULL,buff, -1);
      break;
    }
  }

  while(fgets(buff,256,man)){
    if(strstr(buff,"(G)") || strstr(buff,"(S)"))
       break;
    if(strstr(buff,"NOTE ABOUT USERNAME/PASSWORD VALIDATION"))
      break;
   if(!strncmp(buff,"smb.conf",8) || !strncmp(buff,"SMB.CONF",8)){
      fgets(buff,256,man);
      fgets(buff,256,man);
    }
    else {
      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, 
		       NULL,buff, -1);
    }
  }
  pclose(man);
  
  gtk_widget_show(text);

  gtk_widget_show(diag);

}

void make_overview_page(GtkWidget *notebook, GtkWidget **text, char *title){
  GtkWidget *vscrollbar;
  GtkWidget *hbox;
  GtkWidget *label;

  hbox=gtk_hbox_new(FALSE,0);
  gtk_widget_show (hbox);

  label = gtk_label_new(title);
  gtk_widget_show (label);
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), hbox, label);
  
  *text = gtk_text_new(NULL,NULL);
  gtk_box_pack_start (GTK_BOX (hbox), 
		      *text, TRUE, TRUE, 0);
  gtk_widget_realize (*text);
  gtk_text_freeze (GTK_TEXT (*text));
  gtk_widget_show (*text);
 
  vscrollbar = gtk_vscrollbar_new (GTK_TEXT(*text)->vadj);
  gtk_box_pack_start(GTK_BOX(hbox), vscrollbar, FALSE, FALSE, 0);
  gtk_widget_show (vscrollbar);
 
  
}

void c_make_overview(GtkWidget *widget, gpointer data){
  GtkWidget *diag;
  GtkWidget *button;
  GtkWidget *notebook;
  GtkWidget *servicetext;
  GtkWidget *specialtext;
  GtkWidget *paramstext;
  char buff[256];
  FILE *man;
  


  man = make_man_pipe();
  if(!man){
    make_error_mesg("  Cannot open man page  ",
		    "  verify you have it installed  ");
    return;
  }

  

  diag=gtk_dialog_new ();

  gtk_widget_set_usize(diag, 420, 300);

  gtk_signal_connect_object(GTK_OBJECT(diag), "delete_event",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(diag));
  gtk_window_set_title(GTK_WINDOW(diag),"smb.conf overview");
  gtk_window_position (GTK_WINDOW (diag),GTK_WIN_POS_CENTER);

  button = gtk_button_new_with_label("Quit Help");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
		     button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(diag));
  gtk_widget_show(button);

  button = gtk_button_new_with_label("Look Up Parameter");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
		     button, TRUE, TRUE, 10);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
		     GTK_SIGNAL_FUNC(c_make_param_lookup), NULL);
  gtk_widget_show(button);

  notebook = gtk_notebook_new ();
  gtk_notebook_set_tab_pos (GTK_NOTEBOOK (notebook), GTK_POS_TOP);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
		      notebook, TRUE, TRUE, 0);
  gtk_widget_show(notebook);
  
  make_overview_page(notebook,&servicetext,"Services");
  make_overview_page(notebook,&specialtext,"Special Sections");
  make_overview_page(notebook,&paramstext,"Parameters");


  while(fgets(buff,256,man)){
    if(!strncmp(buff,"SERVICE DESCRIPTIONS",18)){
      gtk_text_insert (GTK_TEXT (servicetext), NULL, 
		       &servicetext->style->black, 
		       NULL,buff, -1);
      break;
    }
  }
  
  while(fgets(buff,256,man)){
    if(!strncmp(buff,"SPECIAL SECTIONS",14)){
      gtk_text_insert (GTK_TEXT (specialtext), NULL, 
		       &specialtext->style->black, 
		       NULL,buff, -1);
      break;
    }
    if(!strncmp(buff,"smb.conf",8) || !strncmp(buff,"SMB.CONF",8)){
      fgets(buff,256,man);
      fgets(buff,256,man);
    }
    else {
      gtk_text_insert (GTK_TEXT (servicetext), NULL, 
		       &servicetext->style->black, 
		       NULL,buff, -1);
    }
  }
  
  while(fgets(buff,256,man)){
    if(!strncmp(buff,"PARAMETERS",9)){
      gtk_text_insert (GTK_TEXT (paramstext), NULL, 
		       &paramstext->style->black, 
		       NULL,buff, -1);
      break;
    }
    if(!strncmp(buff,"smb.conf",8) || !strncmp(buff,"SMB.CONF",8)){
      fgets(buff,256,man);
      fgets(buff,256,man);
    }
    else {
      gtk_text_insert (GTK_TEXT (specialtext), NULL, 
		       &specialtext->style->black, 
		       NULL,buff, -1);
    }
  }

  
  while(fgets(buff,256,man)){
    if(strstr(buff,"COMPLETE LIST OF GLOBAL PARAMETERS")){
      break;
    }
    if(!strncmp(buff,"smb.conf",8) || !strncmp(buff,"SMB.CONF",8)){
      fgets(buff,256,man);
      fgets(buff,256,man);
    }
    else {
    gtk_text_insert (GTK_TEXT (paramstext), NULL, 
		     &paramstext->style->black, 
		     NULL,buff, -1);
    }
  }
  
  pclose(man);
  
  gtk_widget_show(diag);

}

void cw_lookup_select(GtkWidget *clist){
  int row;
  char *text, *param;
  
  if(GTK_CLIST(clist)->selection){
    row = (int)(GTK_CLIST(clist)->selection->data);
    gtk_clist_get_text(GTK_CLIST(clist),row,0,&text);

    param=(char *)malloc(strlen(text)+1);
    strcpy(param,text);
    text=strchr(param,'(');
    *(text-1)='\0';
    make_param_help(param+3);
    free(param);
  }
  return;
}
  

void c_lookup_select(GtkWidget *clist,
                    gint row,
                    gint column,
                    GdkEventButton *event,
                    gpointer data){
  char *text, *param;
  
  if(event && event->type==GDK_2BUTTON_PRESS){

    gtk_clist_get_text(GTK_CLIST(clist),row,0,&text);

    param=(char *)malloc(strlen(text)+1);
    strcpy(param,text);
    text=strchr(param,'(');
    *(text-1)='\0';
    make_param_help(param+3);
    free(param);
  }
  return;
}


void c_make_param_lookup(GtkWidget *widget, gpointer data){
  GtkWidget *diag;
  GtkWidget *clist;
  GtkWidget *button;
  char buff[256];
  FILE *man;
  char *text;

  text=buff;

  
  man = make_man_pipe();
  if(!man){
    make_error_mesg("  Cannot open man page  ",
		    "  verify you have it installed  ");
    return;
  }

  diag=gtk_dialog_new ();
  gtk_widget_set_usize(diag, 200, 200);
  gtk_signal_connect_object(GTK_OBJECT(diag), "delete_event",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(diag));
  gtk_window_set_title(GTK_WINDOW(diag),"parameter lookup");
  gtk_window_position (GTK_WINDOW (diag),GTK_WIN_POS_CENTER);
 

  clist=gtk_clist_new(1);
  gtk_clist_set_policy(GTK_CLIST(clist), GTK_POLICY_AUTOMATIC,
                       GTK_POLICY_AUTOMATIC);
  gtk_clist_set_selection_mode(GTK_CLIST(clist),
                               GTK_SELECTION_BROWSE);
  gtk_signal_connect(GTK_OBJECT(clist),
                     "select_row",
                     GTK_SIGNAL_FUNC(c_lookup_select),
                     NULL);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
		      clist, TRUE, TRUE, 0);
  gtk_widget_show (clist);

    button = gtk_button_new_with_label("look up");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
		     button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
			    GTK_SIGNAL_FUNC(cw_lookup_select),
			    GTK_OBJECT(clist));
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
		     button, TRUE, TRUE, 10);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(diag));
  gtk_widget_show(button);

  while(fgets(buff,256,man)){
    if( strstr(buff,"(G)") || strstr(buff,"(S)")) 
      gtk_clist_append(GTK_CLIST(clist),&text);
  }

  pclose(man);
  gtk_widget_show(diag);
}
  

