/* GtkSamba-0.1.2
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */


#include <gtk/gtk.h>
#include <strings.h>
#include "gtksamba.h"
#include "pix/share.xpm"
#include "pix/delshare.xpm"
#include "pix/delete.xpm"
#include "pix/exit.xpm"
#include "pix/new.xpm" 
#include "pix/open.xpm"
#include "pix/edit.xpm"
#include "pix/save.xpm"


void c_string_diag_ok(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row;

  sw=SMB_WIN(data);

  row = (int)(GTK_CLIST(sw->sublist)->selection->data);

  gtk_clist_set_text(GTK_CLIST(sw->sublist),row,1,
		     gtk_entry_get_text(GTK_ENTRY(sw->entry)));

  gtk_widget_set_sensitive(sw->window,TRUE);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}




void make_string_dialog(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  char *text;
  int row;

  gtk_widget_set_sensitive(SMB_WIN(sw)->window,FALSE);

  row = (int)(GTK_CLIST(sw->sublist)->selection->data);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,0,&text);

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),text);
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new(text);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new("");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_string_diag_ok),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("help");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_help_sel_param),
                     (gpointer) sw);
  gtk_widget_show(button);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
		     row ,1,&text);

  sw->entry = gtk_entry_new();
  gtk_entry_set_text(GTK_ENTRY(sw->entry),text);
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		     sw->entry, TRUE, TRUE, 0);
  gtk_widget_show(sw->entry);

  
  gtk_widget_show(sw->diagwin);
  return;
}

void c_insert_diag_ok(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row;
  char *text[2];

  sw=SMB_WIN(data);
 
  if(GTK_CLIST(SMB_WIN(sw)->sublist)->selection)
    row = (int)(GTK_CLIST(sw->sublist)->selection->data);
  else
    row=0;
    
  text[0]=gtk_entry_get_text(GTK_ENTRY(sw->entry));
  text[1]=gtk_entry_get_text(GTK_ENTRY(sw->entry2));

  for(; *text[0] && isspace(*text[0]); text[0]++);
  for(; *text[1] && isspace(*text[1]); text[1]++);
  
  if(strlen(text[0]) && strlen(text[1]))
    gtk_clist_insert(GTK_CLIST(sw->sublist),row,text);
  else
    make_error_mesg(" Cannot insert parameter ",
		       " One or more fields empty ");
  gtk_widget_set_sensitive(sw->window,TRUE);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
    
}

void make_insert_dialog(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  GtkWidget *separator;

  gtk_widget_set_sensitive(SMB_WIN(sw)->window,FALSE);

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),"New Parameter");
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new("New Parameter");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  
  separator = gtk_hseparator_new ();
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox),
		      separator, FALSE, TRUE, 5);
  gtk_widget_show (separator);

  label = gtk_label_new("Name:");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  sw->entry = gtk_entry_new();
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		     sw->entry, TRUE, TRUE, 0);
  gtk_widget_show(sw->entry);

  label = gtk_label_new("Value:");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  sw->entry2 = gtk_entry_new();
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		     sw->entry2, TRUE, TRUE, 0);
  gtk_widget_show(sw->entry2);
  

  button = gtk_button_new_with_label("insert");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_insert_diag_ok),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);


  gtk_widget_show(sw->diagwin);
  return;
}

void c_insert_service_diag_ok(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row;
  char *text;

  sw=SMB_WIN(data);
 
  if(GTK_CLIST(SMB_WIN(sw)->servicelist)->selection)
    row = (int)(GTK_CLIST(sw->servicelist)->selection->data);
  else
    row=0;
    
  text=gtk_entry_get_text(GTK_ENTRY(sw->entry));

  for(; *text && isspace(*text); text++);
  
  if(strlen(text))
    smbwin_insert_service(text,sw);
  else
    make_error_mesg(" Cannot insert service ",
		       " One or more fields empty ");
  gtk_widget_set_sensitive(sw->window,TRUE);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
    
}

void make_insert_service_dialog(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  GtkWidget *separator;

  gtk_widget_set_sensitive(SMB_WIN(sw)->window,FALSE);

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),"New Service");
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new("New Service");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  
  separator = gtk_hseparator_new ();
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox),
		      separator, FALSE, TRUE, 5);
  gtk_widget_show (separator);

  label = gtk_label_new("Name:");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  sw->entry = gtk_entry_new();
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		     sw->entry, TRUE, TRUE, 0);
  gtk_widget_show(sw->entry);
  

  button = gtk_button_new_with_label("insert");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_insert_service_diag_ok),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);


  gtk_widget_show(sw->diagwin);
  return;
}



void c_del_diag_ok(GtkWidget *button, gpointer data){
  SmbWin *sw;
  int row;

  sw=SMB_WIN(data);
  
  row = (int)(GTK_CLIST(sw->sublist)->selection->data);
  gtk_clist_remove(GTK_CLIST(sw->sublist),row);


  gtk_widget_set_sensitive(sw->window,TRUE);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}

void make_del_dialog(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  char *text;
  int row;

  gtk_widget_set_sensitive(SMB_WIN(sw)->window,FALSE);

  row = (int)(GTK_CLIST(sw->sublist)->selection->data);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,0,&text);

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),text);
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new("delete parameter:");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new(text);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  button = gtk_button_new_with_label("Delete");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_del_diag_ok),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);


  
  gtk_widget_show(sw->diagwin);
  return;
}

void c_del_service_ok(GtkWidget *button, gpointer data){
  SmbWin *sw;

  sw=SMB_WIN(data);
  
  smbwin_delete_service(sw);
  
  gtk_widget_set_sensitive(sw->window,TRUE);

  gtk_widget_destroy(sw->diagwin);
  sw->diagwin=NULL;
  return;
  
}

void make_del_service_dialog(SmbWin *sw){
  GtkWidget *button;
  GtkWidget *label;
  char *text;
  int row;

  gtk_widget_set_sensitive(SMB_WIN(sw)->window,FALSE);

  row = (int)(GTK_CLIST(sw->servicelist)->selection->data);

  gtk_clist_get_text(GTK_CLIST(sw->servicelist),
			row ,0,&text);

  sw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(sw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_param_diag_delete),
                     (gpointer) sw);
  
  gtk_window_set_title(GTK_WINDOW(sw->diagwin),text);
  gtk_window_position (GTK_WINDOW (sw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new("delete service:");
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);
  label = gtk_label_new(text);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (sw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  button = gtk_button_new_with_label("Delete");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_del_service_ok),
                     (gpointer) sw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (sw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_param_diag_cancel),
                     (gpointer) sw);
  gtk_widget_show(button);


  
  gtk_widget_show(sw->diagwin);
  return;
}



void make_error_mesg(char *message1, char *message2){
  GtkWidget *diag;
  GtkWidget *label;
  GtkWidget *button;

  diag=gtk_dialog_new ();

  gtk_signal_connect_object(GTK_OBJECT(diag), "delete_event",
                     GTK_SIGNAL_FUNC(gtk_widget_destroy),
                     GTK_OBJECT(diag));
  gtk_window_set_title(GTK_WINDOW(diag),"Message");
  gtk_window_position (GTK_WINDOW (diag),GTK_WIN_POS_CENTER);

  if(message1){
    label = gtk_label_new(message1);
    gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
			label, TRUE, TRUE, 0);
    gtk_widget_show (label);
  }

  if(message2){
    label = gtk_label_new(message2);
    gtk_box_pack_start (GTK_BOX (GTK_DIALOG (diag)->vbox), 
			label, TRUE, TRUE, 0);
    gtk_widget_show (label);
  }

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (diag)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(diag));
  gtk_widget_show(button);

  gtk_widget_show(diag);

  return;
  
}


void sw_main_menu(SmbWin *sw){
  GtkWidget *menubar;
  GtkWidget *menubox;

  GtkMenuEntry menu_items[] = {
    {"<Main>/File/Open smb.conf", "<control>E", c_conf_open, sw},
    {"<Main>/File/Open Alternate File", "<control>O", c_alt_open, sw},
    {"<Main>/File/Open From Server", "<control>N", NULL, NULL},
    {"<Main>/File/<separator>", NULL, NULL, NULL},
    {"<Main>/File/Write to Current File", "<control>W", c_write_conf, sw},
    {"<Main>/File/Write to Alternate File", "<control>A", c_write_alt, sw},
    {"<Main>/File/Write to Server", "<control>T", NULL, NULL},
    {"<Main>/File/<separator>", NULL, NULL, NULL},
    {"<Main>/File/Close", "<control>C", c_smbwin_close, sw},
    {"<Main>/File/New Window", NULL, c_smbwin_new, NULL},
    {"<Main>/File/Quit", "<control>Q", c_smbwin_destroy, sw},
    {"<Main>/Edit/Edit Parameter", NULL, c_edit_param, sw},
    {"<Main>/Edit/New Parameter", NULL, c_insert_param, sw},
    {"<Main>/Edit/New Service", NULL, c_insert_service, sw},
    {"<Main>/Edit/<separator>", NULL, NULL, NULL},
    {"<Main>/Edit/Delete Parameter", NULL, c_delete_param, sw},
    {"<Main>/Edit/Delete Service", NULL, c_delete_service, sw},
    {"<Main>/Options/Servers", NULL, NULL, NULL},
    {"<Main>/Options/Preferences", NULL, NULL, NULL},
    {"<Main>/Options/<separator>", NULL, NULL, NULL},
    {"<Main>/Options/Run Testparm", NULL, NULL, NULL},
    {"<Main>/Help/Overview", NULL, c_make_overview, NULL},
    {"<Main>/Help/Selected Parameter", NULL, c_help_sel_param, sw},
    {"<Main>/Help/Look Up Parameter", NULL, c_make_param_lookup, NULL},
    {"<Main>/Help/<separator>", NULL, NULL, NULL},
    {"<Main>/Help/About", NULL, c_help_about, sw},
  };

  int nmenu_items = sizeof(menu_items) / sizeof(menu_items[0]);
  GtkMenuFactory *factory;
  GtkMenuFactory *subfactory;

  factory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);
  subfactory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);
  
  gtk_menu_factory_add_subfactory(factory, subfactory, "<Main>");
  gtk_menu_factory_add_entries(factory, menu_items, nmenu_items);
  
  /*  gtk_window_add_accelerator_table(GTK_WINDOW(sw->window), 
      subfactory->table);
   */
  
  menubar = subfactory->widget;
  menubox = gtk_handle_box_new();
  gtk_container_add(GTK_CONTAINER(menubox), menubar);
  gtk_box_pack_start(GTK_BOX(sw->vbox), menubox, FALSE, TRUE, 0);
  gtk_widget_show(menubox);
  gtk_widget_show(menubar);
}

GtkWidget* make_pixmap(char **xpm,GtkWidget* window){
  GtkWidget *pixmapwid;
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GtkStyle *style;

  gtk_widget_realize(window);
  style = gtk_widget_get_style( window );
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
					 &style->bg[GTK_STATE_NORMAL],
					 xpm);

  /* a pixmap widget to contain the pixmap */
  pixmapwid = gtk_pixmap_new( pixmap, mask );
  return pixmapwid;
}


void sw_toolbars(SmbWin *sw){
  GtkWidget *toolbar;
  GtkWidget *toolbox;

  toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL,
			  GTK_TOOLBAR_BOTH);
  gtk_toolbar_set_space_size(GTK_TOOLBAR(toolbar),20);

  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "Open","Open Configuration","",
			  make_pixmap(open_xpm,sw->window),
			  GTK_SIGNAL_FUNC(c_alt_open), sw);

  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "Write","Write Configuration","",
			  make_pixmap(save_xpm,sw->window),
			  GTK_SIGNAL_FUNC(c_write_alt), sw);

  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));

  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "Insert","Insert Service","",
			  make_pixmap(share_xpm,sw->window),
			  GTK_SIGNAL_FUNC(c_insert_service), sw);
  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "Delete","Delete Service","",
			  make_pixmap(delshare_xpm,sw->window),
			  GTK_SIGNAL_FUNC(c_delete_service), sw);

  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));

  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "Edit","Edit Parameter","",
			  make_pixmap(edit_xpm,sw->window),
			  GTK_SIGNAL_FUNC(c_edit_param), sw);

  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "Insert","Insert Parameter","",
			  make_pixmap(new_xpm,sw->window),
			  GTK_SIGNAL_FUNC(c_insert_param), sw);
  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "Delete","Delete Parameter","",
			  make_pixmap(delete_xpm,sw->window),
			  GTK_SIGNAL_FUNC(c_delete_param), sw);

  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
  
  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "Exit","Quit Program","",
			  make_pixmap(exit_xpm,sw->window),
			  GTK_SIGNAL_FUNC(c_make_exit_dialog), sw);




  toolbox = gtk_handle_box_new();
  gtk_container_add(GTK_CONTAINER(toolbox), toolbar);
  gtk_box_pack_start(GTK_BOX(sw->vbox), toolbox, FALSE, TRUE, 0);
  gtk_widget_show(toolbox);
  gtk_widget_show(toolbar);

}

  
