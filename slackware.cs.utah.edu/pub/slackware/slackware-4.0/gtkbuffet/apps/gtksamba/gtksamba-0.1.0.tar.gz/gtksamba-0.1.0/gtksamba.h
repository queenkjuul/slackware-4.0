/* GtkSamba-0.1.0
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef GTKSAMBA_H
#define GTKSAMBA_H

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct smbwin {
  char filepath[1024];
  GtkWidget *window;
  GtkWidget *filew;
  GtkWidget *vbox;
  GtkWidget *menubar;
  GtkWidget *menubox;
  GtkWidget *hpaned;
  GtkWidget *servicelist;
  GtkWidget *sublist;
  int last_row;
  int write;
} SmbWin;

#define CONFILE "/etc/smb.conf"

#define SMB_WIN(obj) ((SmbWin *)(obj))

/* gtksamba.c */

SmbWin *smbwin_new(char *file);
void smbwin_open(SmbWin *sw, char *file);
gint sw_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data);
void c_smbwin_new(GtkWidget *button, gpointer nulldata);
void c_smbwin_close(GtkWidget *button, gpointer nulldata);
void c_smbwin_destroy(GtkWidget *widget, gpointer sw);
void c_alt_open(GtkWidget *button, gpointer sw);
void c_conf_open(GtkWidget *button, gpointer sw);
void c_write_conf(GtkWidget *widget, gpointer sw);
void c_write_alt(GtkWidget *widget, gpointer sw);

void sw_error(char *message);
void cw_make_sensitive(GtkWidget *widget);

/* diagmenu.c */

void sw_main_menu(SmbWin *sw);
void make_string_dialog(SmbWin *sw, int row);


/* conflists.c */

void smbwin_open_lists(SmbWin *sw, char *file);
void smbwin_clear_lists(SmbWin *sw);
void write_smb_file(GtkWidget *servicelist,char *filepath);
void smbwin_update(SmbWin *sw, int row, char *text);


void c_select_service(GtkWidget *widget,
		    gint row,
		    gint column,
		    GdkEventButton *event,
		    gpointer data);

void c_select_param(GtkWidget *widget,
		    gint row,
		    gint column,
		    GdkEventButton *event,
		    gpointer data);



#endif 





