/* GtkSamba-0.1.0
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */


#include "params.h"
#include "gtksamba.h"


BOOL sfunc(char *service, void *data){
  SmbWin *sw;
  char *sublist_titles[2] = {"Parameter","Value"};    

  sw=SMB_WIN(data);

  sw->last_row = gtk_clist_append(GTK_CLIST(sw->servicelist),&service);
  
  sw->sublist = gtk_clist_new_with_titles( 2, sublist_titles);
  gtk_clist_set_policy(GTK_CLIST(sw->sublist), GTK_POLICY_AUTOMATIC,
                       GTK_POLICY_AUTOMATIC);
  gtk_clist_set_column_width (GTK_CLIST(sw->sublist),0,125);
  gtk_widget_ref (GTK_WIDGET(sw->sublist));
  gtk_signal_connect(GTK_OBJECT( sw->sublist),
                         "select_row",
                         GTK_SIGNAL_FUNC(c_select_param),
                         sw);
  gtk_clist_set_row_data(GTK_CLIST(sw->servicelist),sw->last_row,
			 (gpointer)(sw->sublist));

    
  return True;
}

BOOL pfunc(char *pname, char *pvalue, void *data){
  SmbWin *sw;

  char *pair[2];
  
  sw=SMB_WIN(data);
  pair[0]=pname;
  pair[1]=pvalue;
  
  if (!sw->sublist)
    return False;
  gtk_clist_append(GTK_CLIST(sw->sublist),pair);
  return True;
}

void smbwin_open_lists(SmbWin *sw, char *file){

  smbwin_clear_lists(sw);
  if(!file)
    sw_error(NULL);

  strcpy(sw->filepath,file);
  gtk_window_set_title(GTK_WINDOW(sw->window),file);
  pm_process(file,sfunc,pfunc,sw);
  
  sw->sublist=gtk_clist_get_row_data(GTK_CLIST(sw->servicelist),0);
  gtk_paned_add2 (GTK_PANED(sw->hpaned), sw->sublist);
  /*gtk_widget_set_usize(GTK_WIDGET(sw->servicelist), 150, 250);*/
  gtk_widget_show (sw->sublist);

  return;
  
}

void smbwin_clear_lists(SmbWin *sw){
  int i;

  if(sw->sublist)
    gtk_container_remove (GTK_CONTAINER(sw->hpaned),sw->sublist);

  for(i=0; i < GTK_CLIST(sw->servicelist)->rows; i++){
    sw->sublist = gtk_clist_get_row_data(GTK_CLIST(sw->servicelist),i);
    gtk_clist_clear(GTK_CLIST(sw->sublist));
    gtk_widget_destroy (GTK_WIDGET(sw->sublist));
    gtk_widget_unref (GTK_WIDGET(sw->sublist));
   
  }
  sw->sublist=NULL;
  gtk_clist_clear(GTK_CLIST(sw->servicelist));
  
  return;
}

  
  

void c_select_param(GtkWidget *widget,
		    gint row,
		    gint column,
		    GdkEventButton *event,
		    gpointer data){

  make_string_dialog(SMB_WIN(data),row);
  return;
}

void c_select_service(GtkWidget *widget,
		    gint row,
		    gint column,
		    GdkEventButton *event,
		    gpointer data){
  SmbWin *sw;
  
  sw=SMB_WIN(data);
  

  gtk_container_remove (GTK_CONTAINER(sw->hpaned),sw->sublist);

  sw->sublist=gtk_clist_get_row_data(GTK_CLIST(sw->servicelist),row);
  gtk_paned_add2 (GTK_PANED(sw->hpaned), GTK_WIDGET(sw->sublist));
  /*gtk_widget_set_usize(GTK_WIDGET(sw->servicelist), 150, 250);*/
  gtk_widget_show (GTK_WIDGET(sw->sublist));

}



void write_smb_file(GtkWidget *servicelist,char *filepath){
  FILE *outfile;
  GtkWidget *params;
  char *text;
  int i, j;

  printf("writing to %s, %d sections\n",filepath,GTK_CLIST(servicelist)->rows);
  
  outfile=fopen(filepath,"w");
  
  if(!outfile)
    outfile=stdout;
  
  for(i=0; i < GTK_CLIST(servicelist)->rows; i++){
    params = gtk_clist_get_row_data(GTK_CLIST(servicelist),i);
    gtk_clist_get_text(GTK_CLIST(servicelist),
		       i,0,&text);
    fprintf(outfile,";*******************section %s*****************\n",text);
    fprintf(outfile,"[%s]\n",text);
    
    for(j=0; j < GTK_CLIST(params)->rows; j++){
      
      gtk_clist_get_text(GTK_CLIST(params),
			 j,0,&text);
      fprintf(outfile,"%s = ",text);
      
      gtk_clist_get_text(GTK_CLIST(params),
			 j,1,&text);
      fprintf(outfile,"%s\n",text);
    }
  }
  if(outfile != stdout)
    fclose(outfile);
  return;
}

void smbwin_update(SmbWin *sw, int row, char *text){
  gtk_clist_set_text(GTK_CLIST(sw->sublist),row,1,text);
  return;
}


  
  
