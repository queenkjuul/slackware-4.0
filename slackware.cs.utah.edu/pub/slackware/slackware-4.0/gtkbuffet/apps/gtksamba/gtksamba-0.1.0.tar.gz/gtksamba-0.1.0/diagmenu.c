/* GtkSamba-0.1.0
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */


#include <gtk/gtk.h>
#include <strings.h>
#include "gtksamba.h"

typedef struct string_diag {
  SmbWin *sw;
  int row;
  GtkWidget *diagwin;
  GtkWidget *entry;
} StringDiag;

#define STR_DIAG(obj) ((StringDiag *)(obj))

void c_string_diag_cancel(GtkWidget *button, gpointer data){
  StringDiag *dw;

  dw=STR_DIAG(data);

  gtk_widget_set_sensitive(SMB_WIN(dw->sw)->window,TRUE);

  gtk_widget_destroy(dw->diagwin);
  free(dw);
  return;

}

void c_string_diag_delete(GtkWidget *button, GdkEvent *event, 
			  gpointer data){
  StringDiag *dw;

  dw=STR_DIAG(data);

  gtk_widget_set_sensitive(SMB_WIN(dw->sw)->window,TRUE);

  gtk_widget_destroy(dw->diagwin);
  free(dw);
  return;

}


void c_string_diag_ok(GtkWidget *button, gpointer data){
  StringDiag *dw;

  dw=STR_DIAG(data);

  smbwin_update(SMB_WIN(dw->sw),dw->row,
		gtk_entry_get_text(GTK_ENTRY(dw->entry)));

  gtk_widget_set_sensitive(SMB_WIN(dw->sw)->window,TRUE);

  gtk_widget_destroy(dw->diagwin);
  free(dw);
  return;
  
}




void make_string_dialog(SmbWin *sw, int row){
  StringDiag *dw;
  GtkWidget *button;
  GtkWidget *label;
  char *text;

  dw=STR_DIAG(malloc(sizeof(StringDiag)));

  dw->row = row;
  dw->sw = sw;

  gtk_widget_set_sensitive(SMB_WIN(sw)->window,FALSE);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
			row ,0,&text);

  dw->diagwin = gtk_dialog_new ();

  gtk_signal_connect(GTK_OBJECT(dw->diagwin), "delete_event",
                     GTK_SIGNAL_FUNC(c_string_diag_delete),
                     (gpointer) dw);
  
  gtk_window_set_title(GTK_WINDOW(dw->diagwin),text);
  gtk_window_position (GTK_WINDOW (dw->diagwin),GTK_WIN_POS_CENTER);
  label = gtk_label_new(text);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dw->diagwin)->vbox), 
		      label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (dw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_string_diag_ok),
                     (gpointer) dw);
  gtk_widget_show(button);

  button = gtk_button_new_with_label("cancel");
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (dw->diagwin)->action_area), 
		     button, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(c_string_diag_cancel),
                     (gpointer) dw);
  gtk_widget_show(button);

  gtk_clist_get_text(GTK_CLIST(sw->sublist),
		     row ,1,&text);

  dw->entry = gtk_entry_new();
  gtk_entry_set_text(GTK_ENTRY(dw->entry),text);
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG (dw->diagwin)->vbox), 
		     dw->entry, TRUE, TRUE, 0);
  gtk_widget_show(dw->entry);

  
  gtk_widget_show(dw->diagwin);
  return;
}


  

void sw_main_menu(SmbWin *sw){

  GtkMenuEntry menu_items[] = {
    {"<Main>/File/Open smb.conf", "<control>E", c_conf_open, sw},
    {"<Main>/File/Open Alternate File", "<control>O", c_alt_open, sw},
    {"<Main>/File/Open From Server", "<control>N", NULL, NULL},
    {"<Main>/File/<separator>", NULL, NULL, NULL},
    {"<Main>/File/Write to Current File", "<control>W", c_write_conf, sw},
    {"<Main>/File/Write to Alternate File", "<control>A", c_write_alt, sw},
    {"<Main>/File/Write to Server", "<control>T", NULL, NULL},
    {"<Main>/File/<separator>", NULL, NULL, NULL},
    {"<Main>/File/Close", "<control>C", c_smbwin_close, sw},
    {"<Main>/File/New Window", NULL, c_smbwin_new, NULL},
    {"<Main>/File/Quit", "<control>Q", c_smbwin_destroy, sw},
    {"<Main>/Edit/New Parameter", NULL, NULL, NULL},
    {"<Main>/Edit/New Service", NULL, NULL, NULL},
    {"<Main>/Edit/<separator>", NULL, NULL, NULL},
    {"<Main>/Edit/Delete Parameter", NULL, NULL, NULL},
    {"<Main>/Edit/Delete Service", NULL, NULL, NULL},
    {"<Main>/Options/Servers", NULL, NULL, NULL},
    {"<Main>/Options/Preferences", NULL, NULL, NULL},
    {"<Main>/Options/<separator>", NULL, NULL, NULL},
    {"<Main>/Options/Run Testparm", NULL, NULL, NULL}
  };

  int nmenu_items = sizeof(menu_items) / sizeof(menu_items[0]);
  GtkMenuFactory *factory;
  GtkMenuFactory *subfactory;

  factory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);
  subfactory = gtk_menu_factory_new(GTK_MENU_FACTORY_MENU_BAR);
  
  gtk_menu_factory_add_subfactory(factory, subfactory, "<Main>");
  gtk_menu_factory_add_entries(factory, menu_items, nmenu_items);
  
  /*  gtk_window_add_accelerator_table(GTK_WINDOW(sw->window), subfactory->table);
   */
  
  sw->menubar = subfactory->widget;
  sw->menubox = gtk_handle_box_new();
  gtk_container_add(GTK_CONTAINER(sw->menubox), sw->menubar);
  gtk_box_pack_start(GTK_BOX(sw->vbox), sw->menubox, FALSE, TRUE, 0);
  gtk_widget_show(sw->menubox);
  gtk_widget_show(sw->menubar);
}


