/* GtkSamba-0.1.0
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */


#ifndef SMBPARAM_H
#define SMBPARAM_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>

typedef int BOOL;

#define True (1)
#define False (0)

#define DEBUGLEVEL (5)

#define DEBUG(level,body) ((DEBUGLEVEL>=(level))?(printf body):0)

BOOL pm_process( char *FileName,
		BOOL (*sfunc)(char *,void *),
		BOOL (*pfunc)(char *, char *,void *), void *data );
#endif 
