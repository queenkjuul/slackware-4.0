/* GtkSamba-0.1.4
 * copyright 1998 Perry Piplani
 * redistributable under the terms of the GPL:
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef GTKSAMBA_H
#define GTKSAMBA_H

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define VERSION "GtkSamba version 0.1.3"

typedef struct smbwin {
  char filepath[1024];
  GtkWidget *window;
  GtkWidget *filew;
  GtkWidget *vbox;
  GtkWidget *hpaned;
  GtkWidget *leftscroll;
  GtkWidget *rightscroll;
  GtkWidget *servicelist;
  GtkWidget *sublist;
  /****dialog***/
  GtkWidget *diagwin;
  GtkWidget *entry;
  GtkWidget *entry2;
  int last_row;
  int write;
} SmbWin;

#define CONFILE "/etc/smb.conf"

#define SMB_WIN(obj) ((SmbWin *)(obj))

/* gtksamba.c */

SmbWin *smbwin_new(char *file);
void smbwin_open(SmbWin *sw, char *file);
gint sw_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data);
void c_smbwin_new(GtkWidget *button, gpointer nulldata);
void c_smbwin_close(GtkWidget *button, gpointer nulldata);
void c_smbwin_destroy(GtkWidget *widget, gpointer sw);
void c_alt_open(GtkWidget *button, gpointer sw);
void c_conf_open(GtkWidget *button, gpointer sw);
void c_write_conf(GtkWidget *widget, gpointer sw);
void c_write_alt(GtkWidget *widget, gpointer sw);

void c_edit_param(GtkWidget *menu_item, gpointer sw);
void c_insert_param(GtkWidget *menu_item, gpointer sw);
void c_delete_param(GtkWidget *menu_item, gpointer sw);
void c_insert_service(GtkWidget *menu_item, gpointer sw);
void c_delete_service(GtkWidget *menu_item, gpointer sw);
void c_help_about(GtkWidget *widget, gpointer data);
void c_help_sel_param(GtkWidget *widget, gpointer data);

void sw_error(char *message);
void cw_make_sensitive(GtkWidget *widget);

void c_param_diag_cancel(GtkWidget *button, gpointer data);
void c_param_diag_delete(GtkWidget *button, GdkEvent *event, 
			  gpointer data);
void c_make_exit_dialog(GtkWidget *widget, SmbWin *sw);

/* diagmenu.c */

void sw_main_menu(SmbWin *sw);
void sw_toolbars(SmbWin *sw);
void make_string_dialog(SmbWin *sw);
void make_del_dialog(SmbWin *sw);
void make_insert_dialog(SmbWin *sw);
void make_del_service_dialog(SmbWin *sw);
void make_insert_service_dialog(SmbWin *sw);
void make_error_mesg(char *message1, char *message2);


/* conflists.c */

void smbwin_open_lists(SmbWin *sw, char *file);
void smbwin_clear_lists(SmbWin *sw);
void write_smb_file(GtkWidget *servicelist,char *filepath);
void smbwin_update(SmbWin *sw, int row, char *text);

void smbwin_delete_service(SmbWin *sw);
void smbwin_insert_service(char *service, SmbWin *sw);

void c_select_service(GtkWidget *widget,
		    gint row,
		    gint column,
		    GdkEventButton *event,
		    gpointer data);

void c_select_param(GtkWidget *widget,
		    gint row,
		    gint column,
		    GdkEventButton *event,
		    gpointer data);

void make_param_help(char *param);
void c_make_overview(GtkWidget *widget, gpointer data);
void c_make_param_lookup(GtkWidget *widget, gpointer data);
void c_run_testparm(GtkWidget *menu_item, gpointer sw);
void c_run_smbstatus(GtkWidget *widget, gpointer data);
#endif 





