/*
 * ===========================
 * langdrill: Language Drills
 * Version 0.1.5
 * 12/1998
 * ===========================
 *
 * Copyright (C) 1998, Ionutz Borcoman
 * Developed by Ionutz Borcoman <borco@usa.net>, <borco@borco-ei.eng.hokudai.ac.jp>
 *
 * Many thanks to Mario Motta <mmotta@guest.net> for the help given 
 * during developing this program.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef __main_hh__
#define __main_hh__

#include <fstream.h>
#include <unistd.h> 
#include <time.h>

#include <vdk/vdk.h>

#include "config.hh"
//#include "jputils.hh"

#define ESC 27
#define MAX_TITLE_LEN 255
#define MAX_FONT_LEN 255
#define MAX_SENSE_NAME 255

typedef VDKLabelButton * PVDKLabelButton;

typedef struct {
  char name[PATH_MAX];
  int  sense; // sense of translation (eng->jap/jap->eng)
  char directSenseName[MAX_SENSE_NAME];
  char reverseSenseName[MAX_SENSE_NAME];
  char quizAnswerNr[3]; // number of possible answers
  char hQuiz[4];
  char wQuiz[4];
  int  lessonNr;
  char **lessonTitle;
  char compatVersion[10];
} MyLangSetup;
  
//////////////////////////////
// The Main Form
//////////////////////////////

class MyLangForm: public VDKForm
{
  VDKBox				*_quizBox;

  VDKCustomList			*_clist;

  VDKCustomList			*_clistWords;
  VDKColor				*_backgroundWords;
  bool					_clistWordsUpdated;

  VDKEntry				*_quizAnswerNrEntry;

  VDKLabel				*_quizLabel;			// shows the quiz

  VDKLabelButton		*_loadButton;
  VDKLabelButton		*_reloadButton;
  VDKLabelButton		*_startButton;

  VDKLabelButton		**_quizAnswerButton;	// shows the answers
  int					*_slot; 	// store handles of dynamic added signals 

  VDKNotebook			*_book;

  VDKProgressBar		*_pbar;
  VDKRadioButtonGroup	*_senseGroup;
  VDKStatusbar			*_sbar;

  MyLangSetup _setup;

  MyConfig *_config;	// configuration tree
  
  int   *_argc;
  char **_argv;

  int _currentLesson;
  
  int _goodAnswers;
  int _goodTag;
  int _quizes;
  
  bool changeAnswerButtons();
  void clearLessons();
  void distribute(int *array, int nr, int nr_avail);
  bool findLangDrillRC();
  void loadLangDrillRC(bool isNew);
  void newRandowSet(int rows, int cols, int *set);
  bool parseLangDrillRC();
  void setActiveButtons(int keyTotalNr); 
  void showQuiz();

public:
  MyLangForm(VDKApplication *app, int *argc, char *argv[]);
  ~MyLangForm();

  void Setup();
  bool CanClose(){
	printf("now we close app\n");
	return true;
  }

  void QuizDestroy(int newNr, int oldNr);
  void QuizSetup(int newNr, int oldNr, int w, int h);

  bool LoadClicked( VDKObject* sender );
  bool QuizAnswerClicked( VDKObject* sender );
  bool ReloadClicked( VDKObject* sender );
  bool SelectRow( VDKObject* sender );
  bool SenseToggled( VDKObject* sender );
  bool SwitchPage( VDKObject* sender );
  bool StartClicked( VDKObject* );

  DECLARE_SIGNAL_MAP(MyLangForm);
  DECLARE_SIGNAL_LIST(MyLangForm);
};

#endif
