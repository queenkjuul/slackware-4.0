/*******************************************************************
 *
 * http://archive.redhat.com/gtk-list/1998-September/0771.html
 * From Pierre Hanser <hanser@club-internet.fr>
 * I do not make any claim on this code...but use it and be happy.
 *
 *******************************************************************/

#include <gdk/gdkx.h>
#include "iconic.hh"

/* to iconify an existing window */

void gdk_window_iconize (GdkWindow *window)
{
GdkWindowPrivate *Private;

g_return_if_fail (window != NULL);

Private = (GdkWindowPrivate*) window;
if (!Private->destroyed)
XIconifyWindow (Private->xdisplay, Private->xwindow,0);
}

/* to create a window in iconic state */

void window_iconify (GdkWindow *window)
{
XWMHints *xwmh;
GdkWindowPrivate *Private;

Private = (GdkWindowPrivate*) window;
xwmh = XGetWMHints (Private->xdisplay, Private->xwindow);
xwmh->initial_state = IconicState;
xwmh->flags |= StateHint;
XSetWMHints (Private->xdisplay, Private->xwindow, xwmh);
} 

/* useful with some window managers to get key presses */

gboolean window_wm_input (GdkWindow *window)
{
XWMHints *xwmh;
GdkWindowPrivate *Private;

Private = (GdkWindowPrivate*) window;
xwmh = XGetWMHints (Private->xdisplay, Private->xwindow);

if (xwmh == NULL) return false ;

xwmh->input = True;
xwmh->flags |= InputHint;
XSetWMHints (Private->xdisplay, Private->xwindow, xwmh);

return true ;
} 

/* to maximise an existing window */

void
window_deiconify (GdkWindow *window)
{
GdkWindowPrivate *Private;

Private = (GdkWindowPrivate*) window;
XMapRaised (Private->xdisplay, Private->xwindow);
} 

/* to test if ... */

gboolean
window_is_iconified (GdkWindow *window)
{
XWindowAttributes xattr;
GdkWindowPrivate *Private;

Private = (GdkWindowPrivate*) window;

xattr.map_state = IsUnmapped;
XGetWindowAttributes(Private->xdisplay, Private->xwindow, &xattr);
return (xattr.map_state == IsUnmapped); 
}

/* to modify the current icon */

gboolean window_affect_icon (GdkWindow *window)
{
XWMHints *xwmh;
GdkWindowPrivate *Private;

Private = (GdkWindowPrivate*) window;
xwmh = XGetWMHints (Private->xdisplay, Private->xwindow);

if (xwmh == NULL) return false ;

XSetWMHints (Private->xdisplay, Private->xwindow, xwmh);

return true ;
} 
