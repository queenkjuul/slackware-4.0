#ifndef __iconic_h__
#define __iconic_h__

/*******************************************************************
 *
 * http://archive.redhat.com/gtk-list/1998-September/0771.html
 * From Pierre Hanser <hanser@club-internet.fr>
 * I do not make any claim on this code...but use it and be happy.
 *
 *******************************************************************/

/* to iconify an existing window */
void gdk_window_iconize (GdkWindow *window);
/* to create a window in iconic state */
void window_iconify (GdkWindow *window);
/* to maximise an existing window */
void window_deiconify (GdkWindow *window);
/* useful with some window managers to get key presses */
gboolean window_wm_input (GdkWindow *window);
/* to test if ... */
gboolean window_is_iconified (GdkWindow *window);
/* to modify the current icon */
gboolean window_affect_icon (GdkWindow *window);

#endif
