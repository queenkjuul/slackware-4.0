/* main.h
 * May 16th, 1998 */

#ifndef MAIN_H
#define MAIN_H

char *version = {"0.1.2\0"};	/* version number */
int sound_opt = 0;
char secret[] = "vhkk qtkdr";

#endif /* MAIN_H */
