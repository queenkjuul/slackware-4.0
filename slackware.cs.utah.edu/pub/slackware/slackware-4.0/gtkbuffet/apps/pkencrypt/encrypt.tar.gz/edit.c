/* April 21st, 1998
 * By Will Darling
 * This module is for editing files! :-)
 */

#include <gtk/gtk.h>

extern void fileerror(char *filename);
extern GtkWidget *filename_entry;

void save_changes(void);

static GtkWidget *text_window = NULL;

void edit(void)
{
  GtkWidget *box1;
  GtkWidget *box2;
  GtkWidget *hbox;
  GtkWidget *close_button, *save_button;
  GtkWidget *separator;
  GtkWidget *table;
  GtkWidget *hscrollbar;
  GtkWidget *vscrollbar;
  GtkWidget *text;

  char *filename;
  FILE *file;

  text_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_usize(text_window, 500, 500);
  gtk_window_set_policy(GTK_WINDOW(text_window), TRUE, TRUE, FALSE);

  gtk_signal_connect(GTK_OBJECT(text_window), "destroy",
		     GTK_SIGNAL_FUNC(gtk_widget_destroyed), &text_window);

  gtk_window_set_title(GTK_WINDOW(text_window), "pkencrypt: edit");
  gtk_container_border_width(GTK_CONTAINER(text_window), 0);

  box1 = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(text_window), box1);
  gtk_widget_show(box1);

  box2 = gtk_vbox_new(FALSE, 10);
  gtk_container_border_width(GTK_CONTAINER(box2), 10);
  gtk_box_pack_start(GTK_BOX(box1), box2, TRUE, TRUE, 0);
  gtk_widget_show(box2);

  table = gtk_table_new(2, 2, FALSE);
  gtk_table_set_row_spacing(GTK_TABLE(table), 0, 2);
  gtk_table_set_col_spacing(GTK_TABLE(table), 0, 2);
  gtk_box_pack_start(GTK_BOX(box2), table, TRUE, TRUE, 0);
  gtk_widget_show(table);

  text = gtk_text_new(NULL, NULL);
  gtk_text_set_editable(GTK_TEXT(text), TRUE);
  gtk_table_attach(GTK_TABLE(table), text, 0, 1, 0, 1,
		   GTK_EXPAND | GTK_SHRINK | GTK_FILL,
		   GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_show(text);

  hscrollbar = gtk_hscrollbar_new(GTK_TEXT(text)->hadj);
  gtk_table_attach(GTK_TABLE(table), hscrollbar, 0, 1, 1, 2,
		   GTK_EXPAND | GTK_FILL | GTK_SHRINK, GTK_FILL, 0, 0);
  gtk_widget_show(hscrollbar);

  vscrollbar = gtk_vscrollbar_new(GTK_TEXT(text)->vadj);
  gtk_table_attach(GTK_TABLE(table), vscrollbar, 1, 2, 0, 1,
		   GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_show(vscrollbar);

  gtk_text_freeze(GTK_TEXT(text));
  gtk_widget_realize(text);

  filename = gtk_entry_get_text(GTK_ENTRY(filename_entry));
  file = fopen(filename, "r");
  if(file == NULL) 
  {
    fileerror(filename);
    return;
  }

  if(file)
  {
    char buffer[1024];
    int nchars;

    while(1)
    {
      nchars = fread(buffer, 1, 1024, file);
      gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL, buffer, nchars);

      if(nchars < 1024)
        break;
    }

    fclose(file);
  }

  gtk_text_thaw(GTK_TEXT(text));

  hbox = gtk_hbutton_box_new();
  gtk_box_pack_start(GTK_BOX(box2), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);

  separator = gtk_hseparator_new();
  gtk_box_pack_start(GTK_BOX(box1), separator, FALSE, TRUE, 0);
  gtk_widget_show(separator);

  box2 = gtk_hbox_new(FALSE, 10);
  gtk_container_border_width(GTK_CONTAINER(box2), 10);
  gtk_box_pack_start(GTK_BOX(box1), box2, FALSE, TRUE, 0);
  gtk_widget_show(box2);

  close_button = gtk_button_new_with_label("Close");
  save_button = gtk_button_new_with_label("Save Changes");

  gtk_signal_connect_object(GTK_OBJECT(save_button), "clicked",
		            GTK_SIGNAL_FUNC(save_changes),
			    GTK_OBJECT(text_window));

  gtk_signal_connect_object(GTK_OBJECT(close_button), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(text_window));

  gtk_box_pack_start(GTK_BOX(box2), save_button, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(box2), close_button, TRUE, TRUE, 0);

  gtk_widget_show(save_button);
  gtk_widget_show(close_button);
  gtk_widget_show(text_window);
}

void save_changes(void)
{
  GtkWidget *window;
  GtkWidget *label;
  /* FILE *file; */

  window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
  label=gtk_label_new("not yet implemented");

  gtk_container_add(GTK_CONTAINER(window), label);
 
  gtk_widget_show(label);
  gtk_widget_show(window);
}
