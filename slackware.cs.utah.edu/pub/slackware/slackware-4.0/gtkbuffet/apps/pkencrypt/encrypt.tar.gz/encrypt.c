/*
 * encryption and decryption functions 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <math.h>
#ifdef GLIBC_2
  #include <crypt.h>
#endif

#include "encrypt.h"
#include "/usr/local/ssl/include/blowfish.h"

FILE *input;
FILE *output;

extern void fileerror(char *filename);
extern void update_progress(void);

int enc(char *filename, char *word, int fe);
int dec(char *filename, char *word, int fe);

static unsigned char ecb_data[1][8]={
	{0xFE,0xDC,0xBA,0x98,0x76,0x54,0x32,0x10}};

int enc_type = DEFAULT;
/* int enc_type = BLOWFISH_CRYPTO;	*/
/* int enc_type = XOR_CRYPTO; 		*/
/* int enc_type = NO_CRYPTO;  		*/

int enc(char *filename, char *word, int fe)
{
  int c, count=0;
  char cofile[100];
  BF_KEY key;
  unsigned char out[8];
  char *enc_word;

  /****************************************************************/

  enc_word=crypt(word,word);

  input = fopen(filename, "r");
  if(input == NULL)
  {
    if(fe==CMD_LINE) fprintf(stderr, "%s: no such file or access denied\n", filename);
    else fileerror(filename);
    return 1;
  }

  strcpy(cofile, filename);
  strcat(cofile, ".enc");
  output = fopen(cofile, "w");


  /****************************************************************/

  switch(enc_type)
  {
    case 0:
  /*** BLOWFISH ***/

  fprintf(output, "%s\n", enc_word);

   do
   {
     c = getc(input);
      if(c != EOF) 
      {
        BF_set_key(&key,8,ecb_data[0]);
	BF_ecb_encrypt((unsigned char *)&c,out,&key,BF_ENCRYPT);
        putc((int)out[c], output);
	count++;
	update_progress();
      }
  } while(c != EOF);
  break;  

  /*** END ***/

    case 1:
  /*** XOR ***/

  fprintf(output, "%s\n", enc_word);

  do
  {
    c = getc(input);
    if(c != EOF)
    {
      c++;
      c=c+enc_word[6];
      putc(c, output);
      count++;
      update_progress();
    }
  } while(c != EOF);
  break;

  /*** END ***/

    default: break;
  }

  return 0;
}

int dec(char *filename, char *word, int fe)
{
  int c, count=0;
  char cofile[100];
  char *buffer;
  BF_KEY key;
  unsigned char out[8];
  char *enc_word;

  /***************************************************************/

  enc_word=crypt(word,word);

  input = fopen(filename, "r");
  if(input == NULL)
  {
    if(fe==CMD_LINE) fprintf(stderr, "%s: no such file or access denied\n", filename);
    else fileerror(filename);
    return 1;
  }

  strcpy(cofile, filename);
  strcat(cofile, ".dec");
  output = fopen(cofile, "w");

  /**************************************************************/

  switch(enc_type)
  {
    case 0:
  /*** BLOWFISH ***/

  buffer = (char*)malloc(BUFSIZ);
  fgets(buffer, BUFSIZ, input);

  strcat(enc_word, "\n");

  if(strcmp(buffer,enc_word)==0)
  {
    do
    {
      c = getc(input);
      if(c != EOF) 
      {
        BF_set_key(&key,8,ecb_data[0]);
	BF_ecb_encrypt((unsigned char *)&c,out,&key,BF_DECRYPT);
        putc((int)out[c], output);
	count++;
	update_progress();
      }
    } while(c != EOF);
    free(buffer);
  }

  else
  {
    fprintf(stderr, "incorrect password\n");
    free(buffer);
    exit(1);
  }
  break;

  /*** END ***/

    case 1:
  /*** XOR ***/

  buffer = (char*)malloc(BUFSIZ);
  fgets(buffer, BUFSIZ, input);

  strcat(enc_word, "\n");

  if(strcmp(buffer,enc_word)==0)
  {
    do
    {
      c = getc(input);
      if(c != EOF) 
      {
	c=c-enc_word[6];
        c--;
        putc(c, output);
	count++;
	update_progress();
      }
    } while(c != EOF);
    free(buffer);
  }

  else
  {
    fprintf(stderr, "incorrect password\n");
    free(buffer);
    exit(1);
  }
  break;

  /*** END ***/

    default: break;
  }

  return 0;
}
