/* help.c is for giving the ever so kind user our help */
/* by Will Darling - first written march 20th, 1998 */

#include <gtk/gtk.h>
#include "pix/pkenc.xpm"
#include "pix/net.xpm"

GtkWidget *about_window;

void close_win(void);
void gothere(void);
void bookmark(void);
extern GtkWidget *xpm_label_box(GtkWidget *parent, char **xpm_filename, char *label_text);

void about(void)
{
  GtkWidget *label, *label2, *button;
  GtkWidget *pixmapwid;
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GdkColor  c;

  about_window = gtk_dialog_new();
  label = gtk_label_new("About pkencrypt");
  label2 = gtk_label_new("GPL. (c) Will Darling, 1998");
  button = gtk_button_new_with_label("Ok");

  /************** load a pixmap logo ********************/
  gtk_widget_realize(about_window);
  pixmap = gdk_pixmap_create_from_xpm_d(about_window->window, &mask,
				      &c, pkenc_xpm);
  pixmapwid = gtk_pixmap_new(pixmap, mask);
  gtk_widget_show(pixmapwid);
  /************** end of load a pixmap logo *****************/

  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(about_window)->vbox), label, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(about_window)->vbox), label2, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(about_window)->vbox), pixmapwid, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(about_window)->action_area), button, TRUE, TRUE, 0);

  gtk_signal_connect(GTK_OBJECT(button), "clicked",
		     GTK_SIGNAL_FUNC(close_win), NULL);

  gtk_widget_show(label);
  gtk_widget_show(label2);
  gtk_widget_show(button);
  gtk_widget_show(about_window);
}

void help(void)
{
  GtkWidget *label;
  GtkWidget *button, *button2, *button3;
  GtkWidget *pixbox, *pixbox2;

  about_window = gtk_dialog_new();
  label = gtk_label_new("Please visit www.godin.on.ca/will/encrypt");
  button = gtk_button_new_with_label("Ok");
  button2 = gtk_button_new();
  button3 = gtk_button_new();

  pixbox = xpm_label_box(about_window, net_xpm, "Go there now!");
  gtk_widget_show(pixbox);
  gtk_container_add(GTK_CONTAINER(button2), pixbox);

  pixbox2 = xpm_label_box(about_window, net_xpm, "Add bookmark!");
  gtk_widget_show(pixbox2);
  gtk_container_add(GTK_CONTAINER(button3), pixbox2);

  gtk_signal_connect(GTK_OBJECT(button), "clicked",
		     GTK_SIGNAL_FUNC(close_win), NULL);
  gtk_signal_connect(GTK_OBJECT(button2), "clicked",
		     GTK_SIGNAL_FUNC(gothere), NULL);
  gtk_signal_connect(GTK_OBJECT(button3), "clicked",
		     GTK_SIGNAL_FUNC(bookmark), NULL);

  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(about_window)->vbox), label, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(about_window)->action_area), button, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(about_window)->action_area), button2, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(about_window)->action_area), button3, TRUE, TRUE, 0);

  gtk_widget_show(label);
  gtk_widget_show(button);
  gtk_widget_show(button2);
  gtk_widget_show(button3);
  gtk_widget_show(about_window);
}

void close_win(void)
{
  gtk_widget_destroy(about_window);
}

/*
 * maybe think about actually implementing the protocol to use netscape, 
 * but for now I'll just use system() calls. [WD]
 */

void gothere(void)
{
  gtk_widget_destroy(about_window);

  /* code to open netscape and go to a certain url */
  system("netscape -remote 'openURL(http://www.godin.on.ca/will/encrypt)'");  
}

void bookmark(void)
{
  gtk_widget_destroy(about_window);

  /* code to add a bookmark to netscape */
  system("netscape -remote 'addBookmark(http://www.godin.on.ca/will/encrypt,pkencrypt )'");
}
