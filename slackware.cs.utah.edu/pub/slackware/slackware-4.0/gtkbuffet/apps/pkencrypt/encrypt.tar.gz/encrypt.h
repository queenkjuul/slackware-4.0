/* encrypt.h
 * May somethingth, 1998 */

#ifndef ENCRYPT_H
#define ENCRYPT_H

#define DEFAULT		0
#define	BLOWFISH_CRYPTO	0
#define	XOR_CRYPTO	1
#define NO_CRYPTO	2	

#define CMD_LINE	0
#define	GUI		1

#endif /* ENCRYPT_H */
