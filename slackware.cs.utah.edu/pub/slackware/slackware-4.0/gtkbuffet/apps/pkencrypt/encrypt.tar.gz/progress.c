#include <gtk/gtk.h>
#include "encrypt.h"

extern int fetype;
int setup=0;

void update_progress(void)
{
  GtkWidget *update_window, *pbar;

  static int ptimer = 0;
  int pstat = TRUE;

  /****** function of it's own for the progress bar ******/

  gint progress(gpointer data)
  {
    gfloat pvalue;

    pvalue = GTK_PROGRESS_BAR(data)->percentage;

    if((pvalue >= 1.0) || (pstat == FALSE))
    {
      return FALSE;
    }

    pvalue += 0.01;

    gtk_progress_bar_update(GTK_PROGRESS_BAR(data), pvalue);

    return TRUE;
  }

  /****** end! ******/

  if(fetype == CMD_LINE)
    fprintf(stderr, ".");
  else if(fetype == GUI && setup == 0)
  {
    update_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(update_window), "progress..");

    pbar = gtk_progress_bar_new();

    gtk_container_add(GTK_CONTAINER(update_window), pbar);

    gtk_widget_show(pbar);
    gtk_widget_show(update_window);

    setup = 1;

    if((ptimer = gtk_timeout_add(50, progress, pbar)) == FALSE)
    {
      gtk_widget_destroy(pbar);
      gtk_widget_destroy(update_window);
    }
  }
}
