/* May 16th, 1998
 * By Will Darling
 * This module is for digitally signing files! :-)
 */

/* lots of work to be done! */

#include <gtk/gtk.h>
#include <string.h>
#include <stdio.h>

extern void fileerror(char *filename);
extern int read_config_var(char *, char *, char []);

extern GtkWidget *filename_entry;

void sign(void)
{
  GtkWidget *sign_window;
  GtkWidget *label;
  char *filename;
  FILE *file;
  char identity[100];
  char *v_file = ".encrc";

  filename = gtk_entry_get_text(GTK_ENTRY(filename_entry));
  file = fopen(filename, "a");
  if(file == NULL)
  {
    fileerror(filename);
    return;
  }

  if(file)
  {
    read_config_var(v_file, "IDENTITY", identity);
    fprintf(file, "%s\n", identity);
    fclose(file);
  }

  sign_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(sign_window), "Digital file signing");
  gtk_widget_set_usize(sign_window, 150, 60);
  label = gtk_label_new("Done");
  gtk_container_add(GTK_CONTAINER(sign_window), label);

  gtk_widget_show(label);
  gtk_widget_show(sign_window);
}
