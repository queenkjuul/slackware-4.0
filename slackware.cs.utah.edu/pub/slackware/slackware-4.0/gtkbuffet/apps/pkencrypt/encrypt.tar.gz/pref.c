#include <gtk/gtk.h>
#include "pix/radio.xpm"

void cancel_selection(void);
void ok_selection(void);

extern int read_config_var(char *, char *, char []);
extern int write_config_var(char *, char *, char []);

GtkWidget *pref_window;

void pref(void)
{
  GtkWidget *ok_button, *cancel_button;
  GtkWidget *sound_label, *level_label, *ident_label, *server_label, *remote_label, *type_label;
  GtkWidget *ident_entry, *server_entry;
  GtkWidget *box, *hbox1, *hbox2, *hbox3, *hbox4, *hbox5, *hbox6, *hboxtype;
  GtkWidget *radio1, *radio2, *radio3, *radio4, *radio5, *radio6;
  GtkWidget *radiobf, *radioxr, *radiono;
  GtkTooltips *tooltips;

  GtkWidget *pixmapwid;
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GdkColor  c;

  int enc_type;
  int remote_enc;
  int sound;
  int level;
  char temp_var[100];
  char identity[100];
  char server[100];

  char *v_file = ".encrc";

  read_config_var(v_file, "ENC_TYPE", temp_var);
  enc_type = atoi(temp_var);
  read_config_var(v_file, "REMOTE_ENC", temp_var);
  remote_enc = atoi(temp_var);
  read_config_var(v_file, "SOUND", temp_var);
  sound = atoi(temp_var);
  read_config_var(v_file, "LEVEL", temp_var);
  level = atoi(temp_var);
  read_config_var(v_file, "IDENTITY", identity);
  read_config_var(v_file, "SERVER", server);

  pref_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(pref_window), "pkencrypt preferences");

  /* load a pixmap up - the radio! */
  gtk_widget_realize(pref_window);
  pixmap = gdk_pixmap_create_from_xpm_d(pref_window->window, &mask,
				      &c, radio_xpm);
  pixmapwid = gtk_pixmap_new(pixmap, mask);
  gtk_widget_show(pixmapwid);
  /*** ok ***/ 

  tooltips = gtk_tooltips_new();

  ok_button = gtk_button_new_with_label("Ok");
  cancel_button = gtk_button_new_with_label("Cancel");

  ident_entry = gtk_entry_new();
  server_entry = gtk_entry_new();

  gtk_entry_set_text((GtkEntry*)ident_entry, identity);
  gtk_entry_set_text((GtkEntry*)server_entry, server);

  sound_label = gtk_label_new("Sound on exit?");
  type_label = gtk_label_new("Encryption type:");
  level_label = gtk_label_new("Level of encryption:");
  ident_label = gtk_label_new("Identitiy:");
  server_label = gtk_label_new("pk encrypt server:");
  remote_label = gtk_label_new("Use remote encryption?");

  box = gtk_vbox_new(FALSE, 0);
  hbox1 = gtk_hbox_new(FALSE, 0);
  hboxtype = gtk_hbox_new(FALSE, 0);
  hbox2 = gtk_hbox_new(FALSE, 0);
  hbox3 = gtk_hbox_new(FALSE, 0);
  hbox4 = gtk_hbox_new(FALSE, 0);
  hbox5 = gtk_hbox_new(FALSE, 0);
  hbox6 = gtk_hbox_new(FALSE, 0);

  gtk_container_border_width(GTK_CONTAINER(hbox3), 10);

  gtk_container_add(GTK_CONTAINER(pref_window), box);

  gtk_box_pack_start(GTK_BOX(hbox1), pixmapwid, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox1), sound_label, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hboxtype), type_label, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox2), level_label, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox4), ident_label, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox4), ident_entry, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox6), server_label, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox6), server_entry, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox3), ok_button, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox3), cancel_button, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hbox5), remote_label, TRUE, TRUE, 0);

   /* set up radio buttons */
  radio1 = gtk_radio_button_new_with_label(NULL, "Yes");
  gtk_box_pack_start(GTK_BOX(hbox1), radio1, TRUE, TRUE, 0);
  gtk_widget_show(radio1);

  radio2 = gtk_radio_button_new_with_label(
	   gtk_radio_button_group(GTK_RADIO_BUTTON(radio1)), "No");
  gtk_box_pack_start(GTK_BOX(hbox1), radio2, TRUE, TRUE, 0);
  gtk_widget_show(radio2);

  radio3 = gtk_radio_button_new_with_label(NULL, "64-Bit");
  gtk_box_pack_start(GTK_BOX(hbox2), radio3, TRUE, TRUE, 0);
  gtk_widget_show(radio3);

  radio4 = gtk_radio_button_new_with_label(
	   gtk_radio_button_group(GTK_RADIO_BUTTON(radio3)), "128-Bit");
  gtk_box_pack_start(GTK_BOX(hbox2), radio4, TRUE, TRUE, 0);
  gtk_widget_show(radio4);

  radio5 = gtk_radio_button_new_with_label(NULL, "Yes");
  gtk_box_pack_start(GTK_BOX(hbox5), radio5, TRUE, TRUE, 0);
  gtk_widget_show(radio5);

  radio6 = gtk_radio_button_new_with_label(
	   gtk_radio_button_group(GTK_RADIO_BUTTON(radio5)), "No");
  gtk_box_pack_start(GTK_BOX(hbox5), radio6, TRUE, TRUE, 0);
  gtk_widget_show(radio6);

  /* radio button stuff for encryption type */
  /* -------------------------------------- */

  radiobf = gtk_radio_button_new_with_label(NULL, "Blowfish");
  gtk_box_pack_start(GTK_BOX(hboxtype), radiobf, TRUE, TRUE, 0);
  gtk_widget_show(radiobf);

  radioxr = gtk_radio_button_new_with_label(
            gtk_radio_button_group(GTK_RADIO_BUTTON(radiobf)), "Xor");
  gtk_box_pack_start(GTK_BOX(hboxtype), radioxr, TRUE, TRUE, 0);
  radiono = gtk_radio_button_new_with_label(
	    gtk_radio_button_group(GTK_RADIO_BUTTON(radiobf)), "None");
  gtk_box_pack_start(GTK_BOX(hboxtype), radiono, TRUE, TRUE, 0);

  gtk_widget_show(radioxr);
  gtk_widget_show(radiono);

  /*** DONE WITH THE RADIO BUTTONS! */

  /* set the appropriate values according to the config file */
  if(sound==0)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radio2), TRUE);
  if(enc_type==0)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radiobf), TRUE);
  else if(enc_type==1)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radioxr), TRUE);
  else if(enc_type==2)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radiono), TRUE);
  if(level==128)
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radio4), TRUE);
  if(remote_enc==0)
  gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(radio6), TRUE);

  /* end of this craziness */

  /* initialize the tooltips stuff */

  gtk_tooltips_set_tip(tooltips, ident_entry, "Enter your name and e-mail address here", "ContextHelp/buttons/1"); 
  gtk_tooltips_set_tip(tooltips, server_entry, "If you're using remote encryption, enter your server name here", "ContextHelp/buttons/2");

  /* end of tooltips */

  /* attach the hboxes to the main vbox */
  gtk_box_pack_start(GTK_BOX(box), hbox1, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(box), hboxtype, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(box), hbox2, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(box), hbox4, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(box), hbox5, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(box), hbox6, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(box), hbox3, TRUE, TRUE, 0);

  /* attach the signals */
  gtk_signal_connect(GTK_OBJECT(ok_button), "clicked",
		     GTK_SIGNAL_FUNC(ok_selection), NULL);
  gtk_signal_connect(GTK_OBJECT(cancel_button), "clicked",
		     GTK_SIGNAL_FUNC(cancel_selection), NULL);

  /* find out some way to disable the server_entry widget */
  /* and put that code right here! */

  gtk_widget_show(sound_label);
  gtk_widget_show(type_label);
  gtk_widget_show(level_label);
  gtk_widget_show(ident_label);
  gtk_widget_show(server_label);
  gtk_widget_show(remote_label);
  gtk_widget_show(ident_entry);
  gtk_widget_show(server_entry);
  gtk_widget_show(ok_button);
  gtk_widget_show(cancel_button);
  gtk_widget_show(box);
  gtk_widget_show(hboxtype);
  gtk_widget_show(hbox1);
  gtk_widget_show(hbox2);
  gtk_widget_show(hbox3);
  gtk_widget_show(hbox4);
  gtk_widget_show(hbox5);
  gtk_widget_show(hbox6);
  gtk_widget_show(pref_window);
}

void cancel_selection(void)
{
  gtk_widget_destroy(pref_window);
}

void ok_selection(void)
{
  /* add code here to change the preferences */

  gtk_widget_destroy(pref_window);
}
