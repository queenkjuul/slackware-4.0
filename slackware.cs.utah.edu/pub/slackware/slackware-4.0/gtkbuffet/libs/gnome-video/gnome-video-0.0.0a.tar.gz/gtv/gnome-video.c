/*
 * GnomeVideo Widget - a widget to display Video/Tv signals from video device
 * Copyright 1998 Jan Gentsch
 *
 * Author: Jan Gentsch <gentsch@ifm.uni-hamburg.de>
 */


#include <gdk/gdk.h>
#include <gdk/gdkx.h>
#include "gnome-video.h"
#include <sys/ioctl.h>
#include <fcntl.h>


/*
 * Some Video related Definitions
 */
#define DEFAULT_WIDTH    320
#define DEFAULT_HEIGHT   240  

#define PAL_WIDTH 768
#define PAL_HEIGHT 576

#define NTSC_WIDTH 640
#define NTSC_HEIGHT 480

 guint gnome_video_get_type (void);
 static void gnome_video_class_init (GnomeVideoClass *class);
 static void gnome_video_init (GnomeVideo *gvideo);
 GtkWidget * gnome_video_new (const gchar* devname);
 static void gnome_video_finalize (GtkObject *object);
 static void gnome_video_realize (GtkWidget *widget);
 static void gnome_video_size_request (GtkWidget *widget, GtkRequisition *requisition);
 static void gnome_video_size_allocate (GtkWidget *widget, GtkAllocation *allocation);
 static gint gnome_video_expose_event (GtkWidget *widget, GdkEventExpose *event);
 static gint gnome_video_visibility_notify_event (GtkWidget *widget,
                                                  GdkEventVisibility *event);

 static gint gnome_video_configure_event     (GtkWidget *widget,
                                              GdkEventConfigure *event,
					      GnomeVideo *gvideo);
 static GdkFilterReturn rootwin_filter_func  (GdkXEvent *xevent,
                                              GdkEvent *event,
					      gpointer gvideo);
 static gint capture_continue                (gpointer gvideo);

 static void gnome_video_make_clipping_table (GnomeVideo *gvideo);


 static GtkWidgetClass *parent_class = NULL;

 static int one=1;
 static int zero=0; 


/* ------------------------------------------------------------------------ */

guint
gnome_video_get_type (void)
{
 static guint ttt_type = 0;
 
 if(!ttt_type)
    {
    GtkTypeInfo ttt_info =
       {
       "GnomeVideo",
       sizeof (GnomeVideo),
       sizeof (GnomeVideoClass),
       (GtkClassInitFunc) gnome_video_class_init,
       (GtkObjectInitFunc) gnome_video_init,
       (GtkArgSetFunc) NULL,
       (GtkArgGetFunc) NULL
       };

    ttt_type = gtk_type_unique (gtk_widget_get_type(), &ttt_info);
    }

 return ttt_type;
}


static void
gnome_video_class_init (GnomeVideoClass *class)
{
GtkObjectClass *object_class = (GtkObjectClass *) class;
GtkWidgetClass *widget_class = (GtkWidgetClass *) class;

parent_class = gtk_type_class (GTK_TYPE_WIDGET);

object_class->finalize = gnome_video_finalize;

widget_class->realize = gnome_video_realize;
/*widget_class->unrealize = gnome_video_unrealize;*/

widget_class->size_request = gnome_video_size_request;
widget_class->size_allocate = gnome_video_size_allocate;
widget_class->expose_event = gnome_video_expose_event;
widget_class->visibility_notify_event = gnome_video_visibility_notify_event;
}

static void
gnome_video_init (GnomeVideo *gvideo)
{

 gvideo->devname = NULL;
 gvideo->fbttv = 0;
 
 gvideo->cap_on   = FALSE;
 gvideo->norm     = PAL;
 gvideo->input    = TUNER;
 gvideo->delay    = 200;
 gvideo->bright   = 0;
 gvideo->color    = 254;
 gvideo->hue      = 0;
 gvideo->contrast = 216;

 gvideo->timer    = 0;

 gvideo->Channel_List = NULL;

}


GtkWidget *
gnome_video_new (const gchar* devname)
{
 GnomeVideo *gvideo;
 static char standard_dev[]="/dev/video";

 printf("video_new\n");
 
 gvideo = gtk_type_new(gnome_video_get_type ());
 
 if (devname != NULL)
    gvideo->devname = devname;  /* FIXME coyp string*/
 else
    gvideo->devname = standard_dev;
    
 return GTK_WIDGET (gvideo);
}

static void
gnome_video_finalize (GtkObject *object)
{
 GnomeVideo *gvideo;
 
 g_return_if_fail (object != NULL);
 g_return_if_fail (GNOME_IS_VIDEO(object));
 
 /* FIXME A lot more of cleaning up will be neccessary*/

 if (GTK_OBJECT_CLASS (parent_class)->finalize)
    (* GTK_OBJECT_CLASS (parent_class)->finalize) (object);
}


static void
gnome_video_realize (GtkWidget *widget)
{
 GnomeVideo *gvideo;
 GtkWidget *parent;
 GdkWindow *RootWindow;
 GdkWindowAttr attributes;
 gint attributes_mask;
 
 gint i;
 
 /* For xf86dga video */
 int major, minor;
 int rwidth, bank, ram;
 int flags;

 printf("realize\n");
 
 g_return_if_fail (widget != NULL);
 g_return_if_fail (GNOME_IS_VIDEO(widget));

 GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED);
 gvideo = GNOME_VIDEO(widget);
 
 attributes.x = widget->allocation.x;
 attributes.y = widget->allocation.y;
 attributes.width = widget->allocation.width;
 attributes.height = widget->allocation.height;
 attributes.wclass = GDK_INPUT_OUTPUT;
 attributes.window_type = GDK_WINDOW_CHILD;
 attributes.event_mask = gtk_widget_get_events (widget) |
                         GDK_ALL_EVENTS_MASK ; /* Be more precise !!*/

 attributes.visual = gtk_widget_get_visual (widget);
 attributes.colormap = gtk_widget_get_colormap (widget);
 
 attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;

 widget->window = gdk_window_new (widget->parent->window,
                                  &attributes, attributes_mask);
 widget->style = gtk_style_attach (widget->style, widget->window);

 gdk_window_set_user_data (widget->window, widget);
 gtk_style_set_background (widget->style, widget->window, GTK_STATE_ACTIVE);

 parent=widget;
 while(parent->parent != NULL)
     parent = parent->parent;

 if (parent->window == gdk_window_get_toplevel(widget->window))
    g_message("They are equal");

 gtk_signal_connect (GTK_OBJECT(parent), "configure_event",
                     GTK_SIGNAL_FUNC(gnome_video_configure_event),
		     widget);

 attributes.event_mask = gtk_widget_get_events (widget);

 /* --------------------------------------------- */
 /* --- Now we can start with the video stuff --- */
 /* --------------------------------------------- */

 /* --- We need to do a little of our own event handling --- */
 
 RootWindow = gdk_window_foreign_new(GDK_ROOT_WINDOW());
 gdk_window_add_filter(RootWindow, rootwin_filter_func, (gpointer) widget);

 XSelectInput(GDK_DISPLAY(), GDK_ROOT_WINDOW(),
              StructureNotifyMask | SubstructureNotifyMask);
	      /* Do I need both? */

 
 if ((gvideo->fbttv=open(gvideo->devname, O_RDWR)) < 0)
    {
    printf("Cannot open dev %s\n", gvideo->devname);
    gtk_main_quit(); /* FIXME I would like to be none Fatal */
    }

 if(ioctl(gvideo->fbttv, VIDIOCGCAP, &(gvideo->vcap)))
    ;
/*
 * #ifdef DEBUG
 */
 else
     {
     printf("Name: %s\n", gvideo->vcap.name);
     printf("Type: %i\n", gvideo->vcap.type);
     printf("Num channels: %i\n", gvideo->vcap.channels);
     printf("Num audio devices: %i\n", gvideo->vcap.audios);
     printf("MAX Supported width: %i\n", gvideo->vcap.maxwidth);
     printf(" And height: %i\n", gvideo->vcap.maxheight);
     printf("MIN Supported width: %i\n", gvideo->vcap.minwidth);
     printf(" And height: %i\n", gvideo->vcap.minheight);
     }
/*
 * #endif
 */

 gvideo->vchan = g_new(struct video_channel, gvideo->vcap.channels);
 for(i=0; i < gvideo->vcap.channels; i++)
    {
    (gvideo->vchan[i]).channel = i;
    ioctl(gvideo->fbttv, VIDIOCGCHAN, &(gvideo->vchan[i]));
      printf("Channel No %i,", (gvideo->vchan[i]).channel);
      printf("Name %s ", (gvideo->vchan[i]).name);
      printf("NoTuners %i,", (gvideo->vchan[i]).tuners);
      printf("Norm %i\n", (gvideo->vchan[i]).norm);
    }

 gvideo->vaudio = g_new(struct video_audio, gvideo->vcap.audios);
 for(i=0; i < gvideo->vcap.audios; i++)
    {
    (gvideo->vaudio[i]).audio = i;
    ioctl(gvideo->fbttv, VIDIOCGAUDIO, &(gvideo->vaudio[i]));
      printf("Audio No %i,", (gvideo->vaudio[i]).audio);
      printf("Name %s ", (gvideo->vaudio[i]).name);
      printf("Volume %i ", (gvideo->vaudio[i]).volume);
      printf("Mode %i\n", (gvideo->vaudio[i]).mode);
    }
    

 if(ioctl(gvideo->fbttv, VIDIOCGWIN, &(gvideo->vwin)))
    ;
 if(ioctl(gvideo->fbttv, VIDIOCGFBUF, &(gvideo->vbuf)))
    ;
 if(ioctl(gvideo->fbttv, VIDIOCGTUNER, &(gvideo->vtuner)))
    ;


/*  FIXME Check Capabilities !!!
 *  
 */
/*
 *  gdk_window_set_hints(widget->window, 0, 0,
 *                       gvideo->vcap.minwidth, gvideo->vcap.minheight,
 * 		      gvideo->vcap.maxwidth, gvideo->vcap.maxheight,
 * 		      0);
 */


 if(XF86DGAQueryVersion(GDK_DISPLAY(), &major, &minor))
    {
     XF86DGAQueryDirectVideo(GDK_DISPLAY(), XDefaultScreen(GDK_DISPLAY()),
			     &flags);
     XF86DGAGetVideoLL      (GDK_DISPLAY(), XDefaultScreen(GDK_DISPLAY()),
                             &(gvideo->vbuf.base), &rwidth, &bank, &ram);     
#ifdef DEBUG
     printf("XF86DGAGetVideoLL base %p rwidth %i bank %i ram %i\n",
             (gvideo->vbuf.base), rwidth, bank, ram);
#endif
    }

 gvideo->vbuf.width=gdk_screen_width();
 gvideo->vbuf.height=gdk_screen_height();
 gvideo->vbuf.depth = 16; /*FIXME FIXME FIXME NOW*/
 gvideo->vbuf.bytesperline=rwidth*(0x38&(gvideo->vbuf.depth+1))/8;

#ifdef DEBUG
  printf("vbuf.depth %i\n", gvideo->vbuf.depth);
  printf("vbuf.bytesperline %i\n", gvideo->vbuf.bytesperline);
#endif

 if(ioctl(gvideo->fbttv, VIDIOCSFBUF, &(gvideo->vbuf)))
    {
    printf("Cannot set Frame Buffer\n");
    gtk_main_quit(); /* FIXME Make non Fatal */
    }

 /* FIXME provisional */
 gvideo->vwin.clips=gvideo->cliprecs;
 gvideo->vwin.clipcount=0;
 gvideo->vwin.flags=0;


 ioctl (gvideo->fbttv, VIDIOCCAPTURE, &zero);
 gnome_video_set_input_source (gvideo, 0);
/* gnome_video_set_frequency (gvideo, 772);*/

}

static void
gnome_video_size_request (GtkWidget *widget, GtkRequisition *requisition)
{
/* FIXME Try to be a bit smarter */
requisition->width  = 320;
requisition->height = 240;
}

static void
gnome_video_size_allocate (GtkWidget *widget, GtkAllocation *allocation)
{
 GnomeVideo *gvideo;

 g_return_if_fail (widget != NULL);
 g_return_if_fail (GNOME_IS_VIDEO (widget));
 g_return_if_fail (allocation != NULL);

 gvideo = GNOME_VIDEO (widget);
 
 widget->allocation = *allocation;

 if (GTK_WIDGET_REALIZED (widget))
    {
    gdk_window_move_resize (widget->window, allocation->x, allocation->y,
                            allocation->width, allocation->height);
    }

}

static gint
gnome_video_expose_event (GtkWidget *widget, GdkEventExpose *event)
{
 GnomeVideo *gvideo;

 g_return_val_if_fail (widget != NULL, FALSE);
 g_return_val_if_fail (GNOME_IS_VIDEO (widget), FALSE);
 g_return_val_if_fail (event != NULL, FALSE);

 gvideo = GNOME_VIDEO (widget);

 gdk_window_get_origin (widget->window,
                            &(gvideo->vwin.x),
			    &(gvideo->vwin.y));

 gdk_window_get_size (widget->window,
                     &(gvideo->vwin.width),
		     &(gvideo->vwin.height));

 gnome_video_make_clipping_table (gvideo);

 if(ioctl(gvideo->fbttv, VIDIOCSWIN, &(gvideo->vwin)))
    printf("Failure Setting capture window\n");

 if(gvideo->cap_on && GTK_WIDGET_VISIBLE(gvideo))
    if(ioctl(gvideo->fbttv, VIDIOCCAPTURE, &one))
        printf("EXP Cant switch back on!\n");

return FALSE;
}



static gint
gnome_video_visibility_notify_event (GtkWidget *widget,
                                     GdkEventVisibility *event)
{
 GnomeVideo *gvideo;
 
 g_return_val_if_fail (widget != NULL, FALSE);
 g_return_val_if_fail (GNOME_IS_VIDEO (widget), FALSE);
 g_return_val_if_fail (event != NULL, FALSE);

 gvideo = GNOME_VIDEO (widget);

 if(event->state == GDK_VISIBILITY_UNOBSCURED)
    {
    gvideo->vwin.clipcount = 0;
    }
 if(event->state == GDK_VISIBILITY_FULLY_OBSCURED)
    {
    (gvideo->cliprecs[0]).x = 0;
    (gvideo->cliprecs[0]).y = 0;
    (gvideo->cliprecs[0]).width = gvideo->vwin.width;
    (gvideo->cliprecs[0]).height = gvideo->vwin.height;
    gvideo->vwin.clipcount = 1;
    }
 if(event->state == GDK_VISIBILITY_PARTIAL)
    {
    gnome_video_make_clipping_table (gvideo);
    }

 if(ioctl(gvideo->fbttv, VIDIOCSWIN, &(gvideo->vwin)))
    printf("VIS Failure Setting capture window\n");

 return FALSE;
}

static gint
gnome_video_configure_event (GtkWidget *widget,
                             GdkEventConfigure *event, GnomeVideo *gvideo)
{
 GdkEvent temp_event;

 if(ioctl(gvideo->fbttv, VIDIOCSWIN, &(gvideo->vwin)))
    printf("Failure Setting capture window\n");
 
 temp_event.type = GDK_EXPOSE;
 temp_event.expose.window = widget->window;
 temp_event.expose.send_event = TRUE;
 temp_event.expose.area.x = 0;
 temp_event.expose.area.y = 0;
 temp_event.expose.area.width = event->width;
 temp_event.expose.area.height = event->height;
 temp_event.expose.count = 0;
      
 gtk_widget_event (GTK_WIDGET(gvideo), &temp_event);


 return FALSE;
}


/*
   The Purpose of this Function is to capture Configure Events on the
   Root-Window. This is the only way AFAIK to be notified of toplevel
   window being moved before the move has been finished. Anyone has a better
   Idea, speak up!. (WMhints?) We restart capturing after a short timeout.
*/

static GdkFilterReturn
rootwin_filter_func (GdkXEvent *xevent, GdkEvent *event, gpointer gwidget)
{
 XEvent *xev;
 GtkWidget  *widget;
 GnomeVideo *gvideo;

 g_return_val_if_fail (xev != NULL, GDK_FILTER_CONTINUE);
 g_return_val_if_fail (gwidget != NULL, GDK_FILTER_CONTINUE);
 g_return_val_if_fail (GNOME_IS_VIDEO (gwidget), GDK_FILTER_CONTINUE);

 xev = (XEvent *) xevent;
 widget = GTK_WIDGET(gwidget);
 gvideo = GNOME_VIDEO(widget);
 
 if (xev->type != ConfigureNotify)
     return GDK_FILTER_CONTINUE;
     
 if(ioctl(gvideo->fbttv, VIDIOCCAPTURE, &zero))
     printf("FILT Cant switch off!\n");

 if (gvideo->timer)
    gtk_timeout_remove (gvideo->timer);
 gvideo->timer = gtk_timeout_add(40, capture_continue, (gpointer) widget);

 return GDK_FILTER_CONTINUE;
}

static gint
capture_continue (gpointer widget)
{
 GnomeVideo *gvideo;

 g_return_val_if_fail (widget != NULL, FALSE);
 g_return_val_if_fail (GNOME_IS_VIDEO (widget), FALSE);

 gvideo = GNOME_VIDEO(widget);

 gdk_window_get_origin (GTK_WIDGET(gvideo)->window,
                            &(gvideo->vwin.x),
			    &(gvideo->vwin.y));
 gdk_window_get_size (GTK_WIDGET(gvideo)->window,
                     &(gvideo->vwin.width),
		     &(gvideo->vwin.height));

 gnome_video_make_clipping_table (gvideo);

 ioctl(gvideo->fbttv, VIDIOCSWIN, &(gvideo->vwin));

 if(gvideo->cap_on && GTK_WIDGET_VISIBLE(gvideo))
     ioctl(gvideo->fbttv, VIDIOCCAPTURE, &one);


 return FALSE;
}

/* Calling for a better way !!! */
static void
gnome_video_make_clipping_table(GnomeVideo *gvideo)
{
 GtkWidget *parent;
 Window root, toplevel_win, swin;
 Window xparent, xroot;
 Window *children;
 int nchildren;
 XWindowAttributes attr;

 int clip_no = 0;
 int i = 0;

 g_return_if_fail (gvideo != NULL);

 g_message("Setting up clipping!");

 root = GDK_ROOT_WINDOW();

 parent = GTK_WIDGET(gvideo);
 while (parent->parent != NULL)
    parent = parent->parent;
    
 toplevel_win = GDK_WINDOW_XWINDOW(parent->window);

 XQueryTree (GDK_DISPLAY(), toplevel_win, &xroot, &xparent, &children, &nchildren);
 if(nchildren)
    XFree (children);
    

 swin = toplevel_win;   
 while (xparent != root)
    {
    swin = xparent;
    XQueryTree (GDK_DISPLAY(), swin, &xroot, &xparent, &children, &nchildren);
    if(nchildren)
       XFree (children);

    }

 XQueryTree (GDK_DISPLAY(), root, &xroot, &xparent, &children, &nchildren);
 
 i=0;
 while(children[i] != swin && i<nchildren)
    i++;

 for(i++; i<nchildren; i++)
    {
    XGetWindowAttributes (GDK_DISPLAY(), children[i], &attr);
    if (!(attr.map_state & IsViewable))
       continue;
    g_message("added rec");
    gvideo->cliprecs[clip_no].x = attr.x - gvideo->vwin.x;
    gvideo->cliprecs[clip_no].y =  attr.y - gvideo->vwin.y;
    gvideo->cliprecs[clip_no].width = attr.width + 2 * attr.border_width;
    gvideo->cliprecs[clip_no].height =  attr.height + 2 * attr.border_width;
    printf("x,y,w,h %i\t%i\t%i\t%i\n", gvideo->cliprecs[clip_no].x,
         gvideo->cliprecs[clip_no].y,
	 gvideo->cliprecs[clip_no].width,
	 gvideo->cliprecs[clip_no].height);
	 
    clip_no++;    
    }
 
 gvideo->vwin.clipcount = clip_no;
 
 
 printf("clipcount %i\n", gvideo->vwin.clipcount);
 XFree (children);
 
return;
}

/* ---User Functions--------------------------------------------------------- */


void
gnome_video_capture_on(GnomeVideo *gvideo, gboolean on)
{

 g_return_if_fail (gvideo != NULL);


 if(on && GTK_WIDGET_VISIBLE (GTK_WIDGET(gvideo)))
    {
    ioctl(gvideo->fbttv, VIDIOCCAPTURE, &one);
    }
 else
    {
    ioctl(gvideo->fbttv, VIDIOCCAPTURE, &zero);
    }

 gvideo->cap_on = on;
 /* FIXME Deal with Audio ???*/
 /* Should we close the bttv if capture off so others could use it ?? */
}

void gnome_video_set_input_source (GnomeVideo *gvideo, gint source)
{
 g_return_if_fail (gvideo != NULL);

 /* FIXME check valid */

 gvideo->input = source;
 if(ioctl (gvideo->fbttv, VIDIOCSCHAN, &(gvideo->input)))
    g_warning ("Could not change to input channel %i.\n", source);

 return;
}


/* ---Channel Functions------------------------------------------------------ */

void
gnome_video_set_channel_list (GnomeVideo *gvideo, GList *channels)
{
 #include "default_channels.h"
 guint32 freq_16;
 GVchannel *channel;
 
 g_return_if_fail (gvideo != NULL);

 if (gvideo->Channel_List != NULL)
    g_list_free(gvideo->Channel_List);

 if (channels != NULL)
    {
    gvideo->Channel_List = channels;
    }
 else
    {
    gvideo->Channel_List = g_list_alloc();

    channel = default_channel_list;
    gvideo->Channel_List->data = (gpointer) channel;
    channel++;
    while(channel->freq != 0)
       {
       gvideo->Channel_List = g_list_append (gvideo->Channel_List, channel);
       channel++;
       }
    }
 
 gvideo->Channel_List = g_list_first (gvideo->Channel_List);
 
 return;
}


void
gnome_video_set_channel (GnomeVideo *gvideo, GList *channel)
{

 g_return_if_fail (gvideo != NULL);
 g_return_if_fail (channel != NULL);

  gnome_video_set_frequency(gvideo,
     ((GVchannel *) channel->data)->freq +
     ((GVchannel *) channel->data)->finetune);

}


void
gnome_video_next_channel(GnomeVideo *gvideo, gboolean up)
{
 GList *channel_list;
 guint32 freq_16;

 g_return_if_fail (gvideo != NULL);

 if (up)
    {
    channel_list = g_list_next(gvideo->Channel_List);
    if(channel_list == NULL)
       channel_list = g_list_first (gvideo->Channel_List);
    }
 else
    {
    channel_list = g_list_previous(gvideo->Channel_List);
    if(channel_list == NULL)
       channel_list = g_list_last (gvideo->Channel_List);
    }

 gvideo->Channel_List = channel_list;
 gnome_video_set_frequency(gvideo,
    ((GVchannel *) channel_list->data)->freq +
    ((GVchannel *) channel_list->data)->finetune);

 return;
}

void
gnome_video_finetune (GnomeVideo *gvideo, gint freq_diff)
{

 g_return_if_fail (gvideo != NULL);

 ((GVchannel *) gvideo->Channel_List->data)->finetune = freq_diff;

 gnome_video_set_frequency(gvideo,
    ((GVchannel *) gvideo->Channel_List->data)->freq +
    ((GVchannel *) gvideo->Channel_List->data)->finetune);

 return;
 
}

void
gnome_video_set_frequency(GnomeVideo *gvideo, guint32 freq)
{

 g_return_if_fail (gvideo != NULL);

 if(ioctl(gvideo->fbttv, VIDIOCSFREQ, &freq))
    g_warning("Cannot set frequency %u", freq);
    
 return;
}


/* ---Audio Functions-------------------------------------------------------- */

