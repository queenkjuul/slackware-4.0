static GnomeUIInfo file_menu [] = {
        GNOMEUIINFO_ITEM_STOCK ("Exit", NULL, NULL, GNOME_STOCK_MENU_EXIT),
        GNOMEUIINFO_END
};
        
static GnomeUIInfo main_menu [] = {
        GNOMEUIINFO_SUBTREE ("File", &file_menu),
        GNOMEUIINFO_END
};


static GnomeUIInfo toolbar [] = {
       GNOMEUIINFO_ITEM_STOCK(N_("Capture"), N_("Toggle capturing on/off"),
                        capture_cb, GNOME_STOCK_PIXMAP_STOP),
       GNOMEUIINFO_ITEM_STOCK(N_("Up"), N_("Tune one channel up"),
                        channel_up_cb, GNOME_STOCK_PIXMAP_UP),
       GNOMEUIINFO_ITEM_STOCK(N_("Channel"), N_("Show Channel List"),
                        NULL, GNOME_STOCK_PIXMAP_BOOK_BLUE),
       GNOMEUIINFO_ITEM_STOCK(N_("Down"), N_("Tune one channel down"),
                        channel_down_cb, GNOME_STOCK_PIXMAP_DOWN),
       GNOMEUIINFO_ITEM_STOCK(N_(""), N_("Decrease Loudnes"),
                        NULL, GNOME_STOCK_PIXMAP_BACK),
       GNOMEUIINFO_ITEM_STOCK(N_("Mute"), N_("Toggle sound on/off"),
                        NULL, GNOME_STOCK_PIXMAP_VOLUME),
       GNOMEUIINFO_ITEM_STOCK(N_(""), N_("Increase Loudnes"),
                        NULL, GNOME_STOCK_PIXMAP_FORWARD),
       GNOMEUIINFO_END
};
