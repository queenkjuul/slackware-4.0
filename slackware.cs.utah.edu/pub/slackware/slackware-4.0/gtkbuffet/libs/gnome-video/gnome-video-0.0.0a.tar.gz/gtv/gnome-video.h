/*
 * GnomeVideo Widget - a widget to display Video/Tv signals from video device
 * Copyright 1998 Jan Gentsch
 * 
 * Author: Jan Gentsch <gentsch@ifm.uni-hamburg.de>
 */

#ifndef GNOME_VIDEO_H
#define GNOME_VIDEO_H

#include <gtk/gtkcontainer.h>
#include <bttv.h>
#include <videodev.h>
#include <libgnome/gnome-defs.h>

BEGIN_GNOME_DECLS

#define PAL 0
#define NTSC 1
#define SECAM 2

#define TUNER 0
#define COMP1 1
#define COMP2 2
#define SVHS  3


#define GNOME_VIDEO(obj)         GTK_CHECK_CAST (obj, gnome_video_get_type (), GnomeVideo)
#define GNOME_VIDEO_CLASS(klass) GTK_CHECK_CLASS_CAST (klass, gnome_video_get_type (), GnomeVideoCLASS)
#define GNOME_IS_VIDEO(obj)      GTK_CHECK_TYPE (obj, gnome_video_get_type ())

typedef struct _GnomeVideo      GnomeVideo;
typedef struct _GnomeVideoClass GnomeVideoClass;

typedef struct _GVchannel GVchannel;
struct _GVchannel{
  guint32 freq;
  guint   channel_number;
  char*   name;
  gint16  finetune;
};

struct _GnomeVideo {
        GtkWidget widget;
	
/* These are private. Do not ever use directly !!! */
        char *devname;           /* name of the bttv-device */
        int fbttv;               /* the bttv-device */

	gint cap_on;              /* caputring on/off  */
        gint norm;                /* input norm, PAL, NTSC, SECAM  */
        gint input;               /* input channel, TUNER, COMP1, COMP2, SVHS  */
        gint volume;                
        gint delay;               /* 200ms  */
        gint bright;              /* Brightness  */
        gint color;               /* intensity of colors  */
        gint hue;                 /* hue  */
        gint contrast;            /* contrast  */
  
        /* Structures for video4linux */
        struct video_window     vwin;
        struct video_buffer     vbuf; 
        struct video_tuner      vtuner; 
        struct video_capability vcap; 
        struct video_channel   *vchan;
        struct video_audio     *vaudio;
        struct video_picture    vpic;
        struct video_clip       cliprecs[MAX_CLIPRECS];

        gint timer;
        GList *Channel_List;
};

struct _GnomeVideoClass {
       GtkContainerClass parent_class;
       /* Channel Changed Signal */
};


guint gnome_video_get_type (void);
GtkWidget *gnome_video_new (const gchar* devname);

void gnome_video_capture_on (GnomeVideo *gvideo, gboolean on);
void gnome_video_set_input_source (GnomeVideo *gvideo, gint source);

void gnome_video_set_channel_list (GnomeVideo *gvideo, GList *channels);
void gnome_video_set_channel (GnomeVideo *gvideo, GList *channel);
void gnome_video_next_channel (GnomeVideo *gvideo, gboolean up);
void gnome_video_finetune (GnomeVideo *gvideo, gint freq_diff);
void gnome_video_set_frequency (GnomeVideo *gvideo, guint32 freq);

/*void gnome_video_set_audio_mode (GnomeVideo *gvideo, );*/
/*void gnome_video_set_audio_volume (GnomeVideo *gvideo,*/ 
/*void gnome_video_set_audio_volume (GnomeVideo *gvideo,*/
/*void gnome_video_get_audio_increment (GnomeVideo *gvideo,*/
/*void gnome_video_audio_mute (GnomeVideo *gvideo, gboolean mute);*/

END_GNOME_DECLS

#endif
