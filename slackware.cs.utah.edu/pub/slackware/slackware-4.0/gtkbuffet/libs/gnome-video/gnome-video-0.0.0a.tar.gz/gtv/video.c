#include <gnome.h>
#include "gnome-video.h"

 GtkWidget *app;
 GtkWidget *hbox;
 GtkWidget *gvideo;

static void capture_cb (GtkWidget *widget, void *data)
 {

 if(GNOME_VIDEO(gvideo)->cap_on)
    gnome_video_capture_on(GNOME_VIDEO(gvideo), FALSE);
 else
    gnome_video_capture_on(GNOME_VIDEO(gvideo), TRUE);

 }


static void channel_up_cb (GtkWidget *widget, void *data)
{
 gnome_video_next_channel(GNOME_VIDEO(gvideo), TRUE);
}
static void channel_down_cb (GtkWidget *widget, void *data)
{
 gnome_video_next_channel(GNOME_VIDEO(gvideo), FALSE);
}

#include "menu.h"

/*
 * #include <sys/types.h>
 * #include <sys/stat.h>
 */

static gint
gnome_video_configure_event (GtkWidget *widget, GdkEventConfigure *event)
{
 printf("gnome_video_configure_event\n");
return FALSE;
}

int
main(int argc, char **argv)
{

 gnome_init("Gnome-TV", "0.0.0", argc, argv);

 app = gnome_app_new ("gtv", "Gnome Television");
 hbox = gtk_hbox_new(FALSE, 0);
 gtk_container_border_width(GTK_CONTAINER(hbox), 5);

 gvideo = gnome_video_new(NULL);
  gnome_app_create_menus (GNOME_APP(app), main_menu);
 gnome_app_create_toolbar (GNOME_APP(app), toolbar);

 gnome_app_set_contents(GNOME_APP(app), hbox); 
 gtk_box_pack_start(GTK_BOX(hbox), GTK_WIDGET(gvideo), TRUE, TRUE, 3);

 gtk_widget_show_all(app);

 gnome_video_set_channel_list(GNOME_VIDEO(gvideo), NULL);
 gnome_video_set_input_source (GNOME_VIDEO(gvideo), 0);
 

 gtk_main();
}

