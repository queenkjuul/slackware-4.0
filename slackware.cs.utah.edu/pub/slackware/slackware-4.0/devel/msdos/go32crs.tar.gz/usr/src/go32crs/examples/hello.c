/*
 * $Id: hello.c,v 1.2 1993/10/09 01:27:16 root Exp $
 */
#include <stdio.h>

int main(int argc, char* argv[])
{
  printf("Hello World\n");
  return 0;
}
