#ifndef _IO_H_
#define _IO_H_
#ifdef __cplusplus
extern "C" {
#endif

int lock(int fd, long offset, long length);
int setmode(int handle, int mode);
long tell(int file);
int unlock(int fd, long offset, long length);

#define sopen(path, access, shflag, mode) \
	open((path), (access)|(shflag), (mode))

#ifdef __cplusplus
}
#endif

#endif

