/*
 * $Id$
 */
#include <iostream.h>

int main(int, char* [])
{
  cout << "Hello World\n";
  return 0;
}
