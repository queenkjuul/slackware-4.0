extern "C"
{
#include_next <netdb.h>
}
