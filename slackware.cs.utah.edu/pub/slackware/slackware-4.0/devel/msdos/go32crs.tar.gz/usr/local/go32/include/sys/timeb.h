#include <sys/types.h>

struct timeb
{
    time_t		time;		/* Seconds since the epoch	*/
    unsigned short	millitm;
    short		timezone;
    short		dstflag;
};

#ifdef __cplusplus
extern "C" {
#endif

extern int	ftime(struct timeb *);

#ifdef __cplusplus
}
#endif

