/*	
        gppbios.h
	Access to bios services.
	Borland C users use bios.h
	written by PJB King
*/


int biosequip(void);
int bioskey(int cmd);
int biosmemory(void);
int biosprint(int cmd, int byte, int port);
