#if !defined(mips) && !defined(___IBMR2__) && !defined(NO_UNDERSCORE)
#define NAMES_HAVE_UNDERSCORE
#endif

#if defined(VMS) || defined(___IBMR2__) || defined(linux)
#define NO_DOLLAR_IN_LABEL
#endif

#if defined(VMS) || defined(linux)
#define NO_ST_BLKSIZE
#endif
