/*  WARNING!  This file is obsolete!  Use <dirent.h>
*/

#define dirent direct
#include <dirent.h>
#undef dirent
