/* Copyright 1992 DJ Delorie */

struct atexit {
  struct atexit *next;
  void (*function)(int);
  int arg;
};

extern struct atexit *__atexit;
