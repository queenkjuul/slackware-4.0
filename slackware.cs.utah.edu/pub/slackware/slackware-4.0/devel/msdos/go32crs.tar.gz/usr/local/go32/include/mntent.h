#include <stdio.h>

#define	MNT_MNTTAB	"/etc/mnttab"

struct mntent
{
    char	*mnt_fsname;
    char	*mnt_dir;
    char	*mnt_type;
    char	*mnt_opts;
    int		mnt_freq;
    int		mnt_passno;
    long	mnt_time;
};

extern FILE		*setmntent(char *, char *);
extern struct mntent	*getmntent(FILE *);
extern int		addmntent(FILE *, struct mntent *);
extern char		*hasmntopt(struct mntent *, char *);
extern int		endmntent(FILE *);

