/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
#include <libc/ieee.h>

float_t __dj_float_epsilon = { 0x000000, 0x68, 0x0 };
