/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
#include <libc/ieee.h>

long_double_t __dj_long_double_max     = { 0xffffffffU, 0xffffffffU, 0x7ffe, 0x0 };
