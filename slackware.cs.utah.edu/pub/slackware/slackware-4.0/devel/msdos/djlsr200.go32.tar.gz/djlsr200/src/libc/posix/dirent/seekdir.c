/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
#include <dirent.h>

void
seekdir(DIR *dir, long loc)
{
  int i;
  rewinddir(dir);
  for (i=0; i<loc; i++)
    readdir(dir);
}
