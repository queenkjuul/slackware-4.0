/* Copyright (C) 1995 DJ Delorie, see COPYING.DJ for details */
#include <signal.h>

/* ARGSUSED */
int
sigprocmask(int _how, const sigset_t *_set, sigset_t *_oset)
{
  return 0;
}
