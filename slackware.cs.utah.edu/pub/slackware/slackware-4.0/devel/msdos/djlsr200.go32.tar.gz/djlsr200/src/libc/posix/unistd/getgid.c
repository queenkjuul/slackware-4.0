/* Copyright (C) 1995 DJ Delorie, see COPYING.DJ for details */
#include <unistd.h>

gid_t
getgid(void)
{
  return 42;
}

