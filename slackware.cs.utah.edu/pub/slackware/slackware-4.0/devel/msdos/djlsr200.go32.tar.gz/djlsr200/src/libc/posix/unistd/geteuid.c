/* Copyright (C) 1995 DJ Delorie, see COPYING.DJ for details */
#include <unistd.h>

uid_t
geteuid(void)
{
  return 42;
}
