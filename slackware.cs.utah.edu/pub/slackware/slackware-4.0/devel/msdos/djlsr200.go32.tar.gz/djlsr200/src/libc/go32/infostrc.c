/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
#include <sys/types.h>
#include <go32.h>

__Go32_Info_Block _go32_info_block;
