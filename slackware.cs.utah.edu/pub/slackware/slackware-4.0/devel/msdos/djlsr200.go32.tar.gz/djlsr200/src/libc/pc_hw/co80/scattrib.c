/* Copyright (C) 1995 DJ Delorie, see COPYING.DJ for details */
#include "sc.h"

unsigned char ScreenAttrib = 0x07;
