/* Copyright (C) 1995 DJ Delorie, see COPYING.DJ for details */
#include <signal.h>

/* ARGSUSED */
int
sigsuspend(const sigset_t *_set)
{
  return 0;
}
