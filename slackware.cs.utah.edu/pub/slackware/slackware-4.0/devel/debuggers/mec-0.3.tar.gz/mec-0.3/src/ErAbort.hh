// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ErAbort.hh
//   Abort due to internal error.
//
// File Created:	26 Mar 1995		Michael Chastain
// Last Edited:		22 Oct 1995		Michael Chastain

#if !defined(ER_ABORT_HH)
#define ER_ABORT_HH

void	ErAbort		( const char * );

#endif
