// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: MmSpace.hh
//   Target machine address spaces.
//   This is an enum.
//   These values are stored into files.
//
// File Created:	26 Oct 1995		Michael Chastain
// Last Edited:		26 Oct 1995		Michael Chastain

#if !defined(MM_SPACE_HH)
#define MM_SPACE_HH



enum	TyMmSpace
{
	tyMmBlank,
	tyMmUser,
	tyMmText,
	tyMmData,
	tyMmBss,
	tyMmBrk,
	tyMmLib,
	tyMmMmap,
	tyMmStack
};

#endif
