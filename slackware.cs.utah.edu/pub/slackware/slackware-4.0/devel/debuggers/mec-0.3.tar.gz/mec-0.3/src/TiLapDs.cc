// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiLapDs.cc
//   This is a template instantiation class.
//
// File Created:	28 Oct 1995		Michael Chastain
// Last Edited:		28 Oct 1995		Michael Chastain

#include <MmDs.hh>
#include <WhLap.hh>
#include <WhLap.cc>

template class WhLap <MmDs>;
