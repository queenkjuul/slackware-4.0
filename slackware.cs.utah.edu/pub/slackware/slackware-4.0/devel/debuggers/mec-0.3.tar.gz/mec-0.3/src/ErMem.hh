// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ErMem.hh
//   Abort due to memory exhaustion.
//
// File Created:	22 Oct 1995		Michael Chastain
// Last Edited:		22 Oct 1995		Michael Chastain

#if !defined(ER_MEM_HH)
#define ER_MEM_HH

void	ErMem		( );

#endif
