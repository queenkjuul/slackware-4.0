// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiLapArea.cc
//   This is a template instantiation class.
//
// File Created:	07 Nov 1995		Michael Chastain
// Last Edited:		07 Nov 1995		Michael Chastain

#include <MmArea.hh>
#include <WhLap.hh>
#include <WhLap.cc>

template class WhLap <MmArea>;
