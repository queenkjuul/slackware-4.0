// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ControlViewer.hh
//   Event filter.
//
// File Created:	12 Nov 1995		Michael Chastain
// Last Edited:		12 Nov 1995		Michael Chastain

#if !defined(CONTROL_VIEWER_HH)
#define CONTROL_VIEWER_HH

#include <WhLap.hh>

class	CxStore;

void	viewer_aw	( CxStore &, WhLap <CxStore> & );
void	viewer_bc	( CxStore &, WhLap <CxStore> & );

#endif
