// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListWord.cc
//   Template instantiation.
//
// File Created:	29 Jul 1994		Michael Chastain
// Last Edited:		16 Oct 1995		Michael Chastain

#include <MmType.hh>
#include <WhList.hh>
#include <WhList.cc>

template class WhList <MmWord>;
