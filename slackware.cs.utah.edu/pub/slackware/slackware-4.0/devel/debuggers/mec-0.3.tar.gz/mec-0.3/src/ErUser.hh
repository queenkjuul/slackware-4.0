// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ErUser.hh
//   Report user-generated error.
//
// File Created:	21 Oct 1995		Michael Chastain
// Last Edited:		08 Nov 1995		Michael Chastain

#if !defined(ER_USER_HH)
#define ER_USER_HH

#include <WhString.hh>

void	ErUser	( const WhString & );
void	ErUser	( const WhString &, const WhString &, const WhString &,
		  const WhString & );

#endif
