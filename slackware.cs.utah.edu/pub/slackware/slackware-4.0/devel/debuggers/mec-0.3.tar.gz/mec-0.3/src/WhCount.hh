// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: WhCount.hh
//   Count elements of an array.
//   This is a macro.
//
// File Created:	24 Sep 1994		Michael Chastain
// Last Edited:		27 Oct 1995		Michael Chastain

#if !defined(WH_COUNT_HH)
#define WH_COUNT_HH

#define WhCount(a)	( int( sizeof(a) / sizeof(a[0]) ) )

#endif
