// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: MmInsn.hh
//   Machine instructions.
//
// File Created:	16 Oct 1995		Michael Chastain
// Last Edited:		15 Nov 1995		Michael Chastain

#if !defined(MM_INSN_HH)
#define MM_INSN_HH

#include <MmType.hh>

extern const MmInsn	insnBpt		[ ];
extern const MmInsn	insnJumpDot	[ ];
extern const MmInsn	insnSysTrap	[ ];

#endif
