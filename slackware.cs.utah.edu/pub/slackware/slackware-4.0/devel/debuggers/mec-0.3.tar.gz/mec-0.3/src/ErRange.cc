// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ErRange.cc.
//   Abort due to index out of range.
//
// File Created:	28 Oct 1995		Michael Chastain
// Last Edited:		28 Oct 1995		Michael Chastain

#include <ErAbort.hh>
#include <ErRange.hh>



// Use low-level calls and no more dynamic memory.
void ErRange( )
{
    ErAbort( "ErRange: index out of range." );
}
