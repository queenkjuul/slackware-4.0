// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvExit.hh
//   An event, type 'exit'.
//
// File Created:	08 Nov 1995		Michael Chastain
// Last Edited:		12 Nov 1995		Michael Chastain

#if !defined(EV_EXIT_HH)
#define EV_EXIT_HH

#include <EvBase.hh>



class	EvExit			: public EvBase
{
    // Life cycle methods.
    public:
    				EvExit		(		   );
				~EvExit		(		   );

    // Flat interface (combiner).
    private:
	void			fromFlatEv	( WhFlatIn  &	   );
	void			toFlatEv	( WhFlatOut &	   ) const;

    // String interface (combiner).
    private:
	void			fmtStrEv	( WhString &	   ) const;

    // Process interface.
    public:
	void			fetch		( CxFetch &	   );
	void			storeAw		( CxStore &	   ) const;
	void			storeBc		( CxStore &	   ) const;

    // Instance data.
    private:
	bool			fStatus_;	// Exit status.
	int			iStatus_;	// Exit status.
};



#endif
