// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ErFatal.hh
//   Exit due to fatal external error.
//
// File Created:	10 Oct 1995		Michael Chastain
// Last Edited:		22 Oct 1995		Michael Chastain

#if !defined(ER_FATAL_HH)
#define ER_FATAL_HH

void	ErFatal		( const char * );

#endif
