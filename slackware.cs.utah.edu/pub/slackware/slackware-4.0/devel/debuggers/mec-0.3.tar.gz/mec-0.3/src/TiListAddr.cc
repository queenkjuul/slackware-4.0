// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListAddr.cc
//   Template instantiation.
//
// File Created:	08 Oct 1995		Michael Chastain
// Last Edited:		16 Oct 1995		Michael Chastain

#include <MmType.hh>
#include <WhList.hh>
#include <WhList.cc>

template class WhList <MmAddr>;
