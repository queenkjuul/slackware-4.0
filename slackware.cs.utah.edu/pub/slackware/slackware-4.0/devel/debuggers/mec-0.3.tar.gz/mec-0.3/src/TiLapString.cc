// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiLapString.cc
//   This is a template instantiation class.
//
// File Created:	10 Nov 1995		Michael Chastain
// Last Edited:		10 Nov 1995		Michael Chastain

#include <WhLap.hh>
#include <WhLap.cc>
#include <WhString.hh>

template class WhLap <WhString>;
