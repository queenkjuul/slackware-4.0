// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TySeg.hh
//   Functions for segment types.
//
// File Created:	20 Apr 1995		Michael Chastain
// Last Edited:		16 Oct 1995		Michael Chastain

#if !defined(TY_SEG_HH)
#define TY_SEG_HH

class	MmSeg;
class	WhString;

int	TySegGetSize	( int, int			);
void	TySegFmtSeg	( WhString &, const MmSeg &	);

#endif
