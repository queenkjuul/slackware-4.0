// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListCris.cc
//   This is a template instantiation class.
//
// File Created:	27 Mar 1995		Michael Chastain
// Last Edited:		21 Apr 1995		Michael Chastain

#include <RiLine.h>
#include <WhList.h>
#include <WhList.cc>

template class WhList <const RiLine *>;
