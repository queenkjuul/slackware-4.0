// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: WhAbort.h
//   Abort due to internal error.
//
// File Created:	26 Mar 1995		Michael Chastain
// Last Edited:		21 Apr 1995		Michael Chastain

#if !defined(WH_ABORT_H)
#define WH_ABORT_H

void	WhAbort		( const char *	);

#endif
