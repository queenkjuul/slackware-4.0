// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvExec.h
//   An event, type 'execution in'.
//
// File Created:	19 Sep 1994		Michael Chastain
// Last Edited:		03 Sep 1995		Michael Chastain

#if !defined(EV_EXEC_H)
#define EV_EXEC_H

#include <EvBase.h>



class	EvExec			: public EvBase
{
    // Destructor and copier.
    public:
				~EvExec		(		   );
	EvBase *		copy		(		   ) const;

    // Flat interface (combiner).
    private:
	MmRet			fromFlatEv	( MmFlat &	   );
	void			toFlatEv	( MmFlat &	   ) const;

    // String interface (combiner).
    private:
	void			fmtStrEv	( WhString &	   ) const;

    // Process interface.
    public:
	MmRet			fetch		( const PrProc &,
						  const MmMap &,
						  const EvSci *	   );
	MmRet			storeAfterWait	( PrProc &,
						  const EvSci *	   ) const;
	MmRet			storeBeforeCont	( PrProc &,
						  const EvSci *	   ) const;
};



#endif
