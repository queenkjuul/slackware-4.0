// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TySeg.h
//   Functions for segment types.
//
// File Created:	20 Apr 1995		Michael Chastain
// Last Edited:		21 Apr 1995		Michael Chastain

#if !defined(TY_SEG_H)
#define TY_SEG_H

class	MmSeg;
class	WhString;

bool	TySegIsValid	( int					);
int	TySegGetSize	( int, int				);
void	TySegFmtSeg	( int, WhString &, const MmSeg &	);

#endif
