// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: WhCount.h
//   Count elements of an array.
//   This is a macro.
//
// File Created:	24 Sep 1994		Michael Chastain
// Last Edited:		21 Apr 1995		Michael Chastain

#if !defined(WH_COUNT_H)
#define WH_COUNT_H

#define WhCount(a)	( sizeof(a) / sizeof(a[0]) )

#endif
