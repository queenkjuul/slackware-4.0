// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListWord.cc
//   Template instantiation.
//
// File Created:	29 Jul 1994		Michael Chastain
// Last Edited:		21 Apr 1995		Michael Chastain

#include <MmType.h>
#include <WhList.h>
#include <WhList.cc>

template class WhList <MmWord>;
