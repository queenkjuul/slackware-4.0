// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvBlank.cc
//   An event, type 'blank'.
//   This is a leaf class.
//
// File Created:	02 Oct 1994		Michael Chastain
// Last Edited:		03 Sep 1995		Michael Chastain

#include <EvBlank.h>
#include <WhAbort.h>



// Destructor.
EvBlank::~EvBlank( )
{
    ;
}



// Copier.
EvBase * EvBlank::copy( ) const
{
    return new EvBlank( *this );
}



// Flat input (combiner).
MmRet EvBlank::fromFlatEv( MmFlat & )
{
    return mmRetOk;
}



// Flat output (combiner).
void EvBlank::toFlatEv( MmFlat & ) const
{
    ;
}



// String output (combiner).
void EvBlank::fmtStrEv( WhString & strRet ) const
{
    strRet.appStrRaw( "<EvBlank>\n" );
}



// Fetch from process.
MmRet EvBlank::fetch( const PrProc &, const MmMap &, const EvSci * )
{
    WhAbort( "EvBlank::fetch: not implemented." );
    return mmRetOk;
}



// Store to process.
MmRet EvBlank::storeAfterWait( PrProc &, const EvSci * ) const
{
    WhAbort( "EvBlank::storeAfterWait: not implemented." );
    return mmRetOk;
}



// Store to process.
MmRet EvBlank::storeBeforeCont( PrProc &, const EvSci * ) const
{
    WhAbort( "EvBlank::storeBeforeCont: not implemented." );
    return mmRetOk;
}
