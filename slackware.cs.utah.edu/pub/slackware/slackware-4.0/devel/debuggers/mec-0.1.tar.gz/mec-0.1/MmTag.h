// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: MmTag.h
//   Unique tags for Mm classes.
//   This is used by all classes now.
//   This is an enum.
//
// File Created:	02 Jul 1995		Michael Chastain
// Last Edited:		02 Jul 1995		Michael Chastain

#if !defined(MM_TAG_H)
#define MM_TAG_H



enum	MmTag
{
    mmTagEnumLix	= 0xBABE0000,
    mmTagEvent		= 0xD00D0000,
    mmTagHistory	= 0xFACE0000
};



#endif
