// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListFlat.cc
//   This is a template instantiation class.
//
// File Created:	05 May 1995		Michael Chastain
// Last Edited:		05 May 1995		Michael Chastain

#include <MmFlat.h>
#include <WhList.h>
#include <WhList.cc>

template class WhList <MmFlat>;
