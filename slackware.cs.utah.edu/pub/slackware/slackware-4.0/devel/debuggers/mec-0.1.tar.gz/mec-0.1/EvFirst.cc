// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvFirst.cc
//   An event, type 'first event'.
//
// File Created:	31 May 1995		Michael Chastain
// Last Edited:		03 Sep 1995		Michael Chastain

#include <EvFirst.h>



// Destructor.
EvFirst::~EvFirst( )
{
    ;
}



// Copier.
EvBase * EvFirst::copy( ) const
{
    return new EvFirst( *this );
}



// Flat input (combiner).
MmRet EvFirst::fromFlatEv( MmFlat & )
{
    return mmRetOk;
}



// Flat output (combiner).
void EvFirst::toFlatEv( MmFlat & ) const
{
    ;
}



// String output (combiner).
void EvFirst::fmtStrEv( WhString & strRet ) const
{
    strRet.appStrRaw( "<EvFirst>\n" );
}



// Fetch from process.
MmRet EvFirst::fetch( const PrProc &, const MmMap &, const EvSci * )
{
    return mmRetOk;
}



// Store to process.
MmRet EvFirst::storeAfterWait( PrProc &, const EvSci * ) const
{
    return mmRetOk;
}



// Store to process.
MmRet EvFirst::storeBeforeCont( PrProc &, const EvSci * ) const
{
    return mmRetOk;
}
