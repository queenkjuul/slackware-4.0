// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListCcs.cc
//   This is a template instantiation class.
//
// File Created:	23 Feb 1995		Michael Chastain
// Last Edited:		21 Apr 1995		Michael Chastain

#include <WhList.h>
#include <WhList.cc>

template class WhList <const char *>;
