// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvFirst.h
//   An event, type 'first event'.
//
// File Created:	31 May 1995		Michael Chastain
// Last Edited:		03 Sep 1995		Michael Chastain

#if !defined(EV_FIRST_H)
#define EV_FIRST_H

#include <EvBase.h>



class	EvFirst			: public EvBase
{
    // Destructor and copier.
    public:
				~EvFirst	(		   );
	EvBase *		copy		(		   ) const;

    // Flat interface (combiner).
    private:
	MmRet			fromFlatEv	( MmFlat &	   );
	void			toFlatEv	( MmFlat &	   ) const;

    // String interface (combiner).
    private:
	void			fmtStrEv	( WhString &	   ) const;

    // Process interface.
    public:
	MmRet			fetch		( const PrProc &,
						  const MmMap &,
						  const EvSci *	   );
	MmRet			storeAfterWait	( PrProc &,
						  const EvSci *	   ) const;
	MmRet			storeBeforeCont	( PrProc &,
						  const EvSci *	   ) const;
};



#endif
