// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvExec.cc
//   An event, type 'execution in'.
//
// File Created:	19 Sep 1994		Michael Chastain
// Last Edited:		03 Sep 1995		Michael Chastain

#include <EvExec.h>



// Destructor.
EvExec::~EvExec( )
{
    ;
}



// Copier.
EvBase * EvExec::copy( ) const
{
    return new EvExec( *this );
}



// Flat input (combiner).
MmRet EvExec::fromFlatEv( MmFlat & )
{
    return mmRetOk;
}



// Flat output (combiner).
void EvExec::toFlatEv( MmFlat & ) const
{
    ;
}



// String output (combiner).
void EvExec::fmtStrEv( WhString & strRet ) const
{
    strRet.appStrRaw( "<EvExec> " );
}



// Fetch from process.
MmRet EvExec::fetch( const PrProc &, const MmMap &, const EvSci * )
{
    return mmRetOk;
}



// Store to process.
MmRet EvExec::storeAfterWait( PrProc &, const EvSci * ) const
{
    return mmRetOk;
}



// Store to process.
MmRet EvExec::storeBeforeCont( PrProc &, const EvSci * ) const
{
    return mmRetOk;
}
