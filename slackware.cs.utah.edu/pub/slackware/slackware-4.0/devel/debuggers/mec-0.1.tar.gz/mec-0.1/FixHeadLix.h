// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: FixHeadLix.h
//   Include this file to fix problems in Linux system header files.
//
// File Created:	27 Mar 1995		Michael Chastain
// Last Edited:		15 Sep 1995		Michael Chastain

#if !defined(FIX_HEAD_LIX_H)
#define FIX_HEAD_LIX_H



// Linux 1.3.11: 'include/asm-i386/byteorder.h' wants this.
extern __inline__ unsigned long  int __ntohl(unsigned long  int x);
extern __inline__ unsigned short int __ntohs(unsigned short int x);
#include <asm/byteorder.h>



// Linux 1.3.11: 'include/linux/cyclades.h' wants this.
// Linux 1.3.11: 'include/linux/serial.h' wants this.
#include <linux/termios.h>
#include <linux/tqueue.h>



// Linux 1.3.11: 'include/linux/mtio.h' wants this.
#include <linux/config.h>
#undef   CONFIG_QIC02_TAPE
#define  CONFIG_QIC02_TAPE 1
#include <linux/tpqic02.h>



// Linux 1.3.11: 'include/linux/resource.h' wants this.
#include <linux/time.h>



// Linux 1.3.27: 'include/linux/if_eql.h' wants this.
#include <linux/timer.h>



// Linux 1.3.27: 'include/linux/mroute.h' wants this.
#include <linux/sockios.h>
#include <linux/in.h>



#endif
