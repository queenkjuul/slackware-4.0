// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListChar.cc
//   This is a template instantiation class.
//
// File Created:	25 Jul 1994		Michael Chastain
// Last Edited:		21 Apr 1995		Michael Chastain

#include <WhList.h>
#include <WhList.cc>

template class WhList <char>;
