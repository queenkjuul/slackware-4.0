// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: Exe.h
//   Interpret exe structures.
//
// File Created:	06 May 1995		Michael Chastain
// Last Edited:		30 May 1995		Michael Chastain

#if !defined(EXE_H)
#define EXE_H

#include <MmFlat.h>
#include <MmRet.h>
#include <MmSeg.h>
#include <WhList.h>



MmRet	ExeExeToSeg	( const MmFlat &, WhList <MmSeg> &	);
MmRet	ExeLibToSeg	( const MmFlat &, WhList <MmSeg> &	);



#endif
