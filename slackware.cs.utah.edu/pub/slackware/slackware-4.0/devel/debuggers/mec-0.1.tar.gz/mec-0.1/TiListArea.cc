// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListArea.cc
//   This is a template instantiation class.
//
// File Created:	24 Apr 1995		Michael Chastain
// Last Edited:		24 Apr 1995		Michael Chastain

#include <MmArea.h>
#include <WhList.h>
#include <WhList.cc>

template class WhList <MmArea>;
