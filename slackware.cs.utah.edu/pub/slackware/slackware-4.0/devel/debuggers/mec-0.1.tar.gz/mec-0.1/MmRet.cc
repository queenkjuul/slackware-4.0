// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: MmRet.cc
//   Return values of Mm classes.
//   This is used by all classes now.
//   This is an enum.
//
// File Created:	06 May 1994		Michael Chastain
// Last Edited:		06 May 1995		Michael Chastain

#include <MmRet.h>



// Raise an error.
MmRet MmRetRaise( MmRet mmRet )
{
    return mmRet;
}
