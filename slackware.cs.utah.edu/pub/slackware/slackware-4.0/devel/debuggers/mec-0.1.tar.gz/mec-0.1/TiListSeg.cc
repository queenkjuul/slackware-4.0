// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListSeg.cc
//   This is a template instantiation class.
//
// File Created:	28 Jul 1994		Michael Chastain
// Last Edited:		21 Apr 1995		Michael Chastain

#include <MmSeg.h>
#include <WhList.h>
#include <WhList.cc>

template class WhList <MmSeg>;
