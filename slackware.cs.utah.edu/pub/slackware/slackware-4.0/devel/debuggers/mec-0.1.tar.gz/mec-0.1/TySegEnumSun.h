// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TySegEnumSun.h
//   Enumeration of all types of segments.
//
// Constraints:
//   These values are saved into files.
//   Their range must be dense (for fast validity checking).
//
// File Created:	21 Apr 1995		Michael Chastain
// Last Edited:		21 Apr 1995		Michael Chastain

#if !defined(TY_SEG_ENUM_SUN_H)
#define TY_SEG_ENUM_SUN_H

enum	TySegEnumSun
{
	tySegNil		= 0xFACE1001
};



// Manifest constants.
static const TySegEnumSun tySegMin	= tySegNil;
static const TySegEnumSun tySegMac	= tySegNil;



#endif
