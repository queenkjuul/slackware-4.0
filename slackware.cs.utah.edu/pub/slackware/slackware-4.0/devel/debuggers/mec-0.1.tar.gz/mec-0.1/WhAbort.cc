// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: WhAbort.cc.
//   Abort due to internal error.
//
// File Created:	26 Mar 1995		Michael Chastain
// Last Edited:		30 May 1995		Michael Chastain

#include <string.h>
#include <unistd.h>

#include <WhAbort.h>



// Use low-level calls and no more dynamic memory.
void WhAbort( const char * pcMessage )
{
    static char rgcTitle [] = "*** Internal error: ";
    ::write( 2, &rgcTitle[0], sizeof(rgcTitle)-1  );
    ::write( 2, pcMessage,    ::strlen(pcMessage) );
    ::write( 2, "\n",         1                   );
    ::abort( );
}
