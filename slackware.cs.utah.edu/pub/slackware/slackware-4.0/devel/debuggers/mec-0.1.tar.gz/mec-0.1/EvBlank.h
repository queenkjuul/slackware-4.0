// Copyright 1994, 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvBlank.h
//   An event, type 'blank'.
//   This is a leaf class.
//
// File Created:	02 Oct 1994		Michael Chastain
// Last Edited:		03 Sep 1995		Michael Chastain

#if !defined(EV_BLANK_H)
#define EV_BLANK_H

#include <EvBase.h>



class	EvBlank			: public EvBase
{
    // Destructor and copier.
    public:
				~EvBlank	(		   );
	EvBase *		copy		(		   ) const;

    // Flat interface (combiner).
    private:
	MmRet			fromFlatEv	( MmFlat &	   );
	void			toFlatEv	( MmFlat &	   ) const;

    // String interface (combiner).
    private:
	void			fmtStrEv	( WhString &	   ) const;

    // Process interface.
    public:
	MmRet			fetch		( const PrProc &,
						  const MmMap &,
						  const EvSci *	   );
	MmRet			storeAfterWait	( PrProc &,
						  const EvSci *	   ) const;
	MmRet			storeBeforeCont	( PrProc &,
						  const EvSci *	   ) const;
};



#endif
