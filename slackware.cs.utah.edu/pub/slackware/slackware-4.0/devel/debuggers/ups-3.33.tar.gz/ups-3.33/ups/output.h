@(#)output.h	1.5 06 Sep 1994 (UKC)

No longer used - replace by srcwin.c and the edit library.
