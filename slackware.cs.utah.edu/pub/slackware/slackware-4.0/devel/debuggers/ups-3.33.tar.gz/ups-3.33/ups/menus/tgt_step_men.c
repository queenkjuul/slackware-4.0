#include <stdio.h>
#include <local/menu3.h>

MENU tgt_step_men = {
	0x460,
	144,
	"Step",
	115,
	-1,
	-1,
	100,
	86,
	0,
	2,
	0,
	0,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
