/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.2 16 Sep 1994 */

#ifdef __STDC__
extern const char *arg__sccsdata[];
#else
extern char *arg__sccsdata[];
#endif
