/* %W% (UKC) %G% */

#define CHWIDTH(c,font) ((font)->ft_width_tab[c])
#define FONTHEIGHT(font) ((font)->ft_height)
