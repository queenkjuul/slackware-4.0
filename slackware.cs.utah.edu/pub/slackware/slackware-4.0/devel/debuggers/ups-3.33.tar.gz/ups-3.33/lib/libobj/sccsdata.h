/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.2 9/9/94 */

#ifdef __STDC__
extern const char *obj__sccsdata[];
#else
extern char *obj__sccsdata[];
#endif
