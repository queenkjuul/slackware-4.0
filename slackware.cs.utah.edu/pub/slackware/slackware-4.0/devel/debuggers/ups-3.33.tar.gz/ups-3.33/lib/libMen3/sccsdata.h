/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.2 4/6/95 */

#ifdef __STDC__
extern const char *Men3wn__sccsdata[];
#else
extern char *Men3wn__sccsdata[];
#endif
