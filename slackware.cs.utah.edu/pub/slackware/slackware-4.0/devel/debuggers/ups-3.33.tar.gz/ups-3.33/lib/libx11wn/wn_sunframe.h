/* wn_sunframe.h - header file for wn_sunframe.c */

/*  Copyright 1991 Mark Russell, University of Kent at Canterbury.
 *
 *  You can do what you like with this source code as long as
 *  you don't try to make money out of it and you include an
 *  unaltered copy of this message (including the copyright).
 */

/* @(#)wn_sunframe.h	1.2 4/7/91 (UKC) */

int _wn_grab_sun_args PROTO((int argc, char **argv));
int _wn_create_sun_window PROTO((char *title));
