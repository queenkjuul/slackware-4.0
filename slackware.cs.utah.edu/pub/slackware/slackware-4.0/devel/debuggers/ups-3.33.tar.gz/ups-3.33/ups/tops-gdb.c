/* tops-gdb.c - ups using the gdb based target driver for binaries */

/*  Copyright 1993 Mark Russell, University of Kent at Canterbury.
 *
 *  You can do what you like with this source code as long as
 *  you don't try to make money out of it and you include an
 *  unaltered copy of this message (including the copyright).
 */

char ups_tops_gdb_c_sccsid[] = "@(#)tops-gdb.c	1.1 09 Sep 1994 (UKC)";

#include <local/ukcprog.h>

#include "ups.h"
#include "symtab.h"
#include "target.h"
#include "xc.h"		/* for Xc_ops and Cc_ops */
#include "gd.h"		/* for Gd_ops */

xp_ops_t **
get_target_drivers()
{
	static xp_ops_t *drivers[] = {
		&Xc_ops,
		&Cc_ops,
		&Gd_ops,
		NULL
	};

	return drivers;
}
