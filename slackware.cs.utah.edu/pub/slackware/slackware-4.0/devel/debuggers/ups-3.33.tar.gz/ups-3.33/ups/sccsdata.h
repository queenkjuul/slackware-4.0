/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.2 9/9/94 */

#ifdef __STDC__
extern const char *ups__sccsdata[];
#else
extern char *ups__sccsdata[];
#endif
