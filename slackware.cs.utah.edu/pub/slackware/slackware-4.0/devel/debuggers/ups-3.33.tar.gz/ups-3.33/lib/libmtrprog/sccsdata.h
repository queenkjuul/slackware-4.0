/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.3 16 Sep 1994 */

#ifdef __STDC__
extern const char *mtrprog__sccsdata[];
#else
extern char *mtrprog__sccsdata[];
#endif
