@(#)proc.h	1.15 21/2/93 (UKC)

No longer used.
