#include <stdio.h>
#include <local/menu3.h>

MENU tgt_detach_men = {
	0x440,
	0,
	"Detach",
	119,
	-1,
	-1,
	100,
	86,
	0,
	0,
	0,
	0,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
