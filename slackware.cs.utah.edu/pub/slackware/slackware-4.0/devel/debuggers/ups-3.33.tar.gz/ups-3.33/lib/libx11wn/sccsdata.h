/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.2 16/9/94 */

#ifdef __STDC__
extern const char *wn__sccsdata[];
#else
extern char *wn__sccsdata[];
#endif
