/* ao_elfcore.h - header file for ao_elfcore.c */

/*  Copyright 1995 Mark Russell, University of Kent at Canterbury.
 *
 *  You can do what you like with this source code as long as
 *  you don't try to make money out of it and you include an
 *  unaltered copy of this message (including the copyright).
 */

/* @(#)ao_elfcore.h	1.1 24/5/95 (UKC) */

#ifdef NPRGREG
typedef struct {
	prgreg_t *regtab;
	prfpregset_t *p_fpregs;
} Elf_core_regs;
#endif

bool elf_get_core_info PROTO((alloc_pool_t *ap, const char *corepath, int fd,
			      bool want_messages, int *p_signo,
			      char **p_cmdname, const char **p_cmdline,
			      Core_segment **p_segments, int *p_nsegments,
			      char **p_regs));
