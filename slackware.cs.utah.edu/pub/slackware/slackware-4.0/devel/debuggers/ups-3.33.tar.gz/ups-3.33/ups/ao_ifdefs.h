/* ao_ifdefs.h - define AO_TARGET and AO_USE_PROC or AO_USE_PTRACE */

/*  Copyright 1995 Mark Russell, University of Kent at Canterbury.
 *
 *  You can do what you like with this source code as long as
 *  you don't try to make money out of it and you include an
 *  unaltered copy of this message (including the copyright).
 */

/* @(#)ao_ifdefs.h	1.1 24/5/95 (UKC) */

/*  Define AO_TARGET for the hosts that we have native a.out back ends for.
 *  Other machines have the gdb based back end only.
 */

#ifdef OS_SUNOS
#define AO_TARGET
#endif

#ifdef OS_ULTRIX
#define AO_TARGET
#endif

#ifdef OS_BSD44
#define AO_TARGET
#endif

#ifdef ARCH_CLIPPER
#define AO_TARGET
#endif

#ifdef OS_LINUX
#define AO_TARGET
#endif

/*  If we do have native support, should we use ptrace() or /proc?
 */
#ifdef AO_TARGET
#ifdef OS_SUNOS_5
#define AO_ELF
#define AO_USE_PROCFS
#else
#define AO_USE_PTRACE
#ifdef OS_LINUX
#define AO_ELF
#endif
#endif
#endif

#ifdef AO_USE_PTRACE
#if	defined(OS_SUNOS)
#define AO_PTRACE_SUN
#elif	defined(OS_LINUX)
#define AO_PTRACE_LINUX
#elif	defined(OS_ULTRIX)
#define AO_PTRACE_OTHER
#elif	defined(OS_BSD44)
#define AO_PTRACE_BSD
#else
#define AO_PTRACE_OTHER
#endif
#endif

