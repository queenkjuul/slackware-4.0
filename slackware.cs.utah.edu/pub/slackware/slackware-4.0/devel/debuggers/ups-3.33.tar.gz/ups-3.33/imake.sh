#! /bin/sh

# @(#)imake.sh	1.2 2/3/93 (UKC)

# This shell script unpacks the Imakefiles kindly provided by Rainer Klute
# (klute@irb.informatik.uni-dortmund.de).  Please send any Imake queries to
# him rather than me - I am not an Imake user so will not be able to help.
# Note that the Makefiles supplied with the distribution were not built with
# Imake - they are hand maintained by me.
#
# If you wish to use imake then say "sh imake.sh" and then proceed as normal
# with Imake.  Ignore the installation instructions in the README file if you
# follow this route.
#
# The script saves the original Makefiles in the file orig_makefiles.tar
# in this directory.  If you wish to revert to the original makefiles just
# untar this file.

[ -f orig_makefiles.tar ] || {
	echo Saving original makefiles ...
	tar cf orig_makefiles.tar `find . -name Makefile -print`
}

echo Extracting Imakefiles ...
sh imakefiles.shar

echo Making makefiles with xmkmf ... 
xmkmf -a
