/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.1 6/8/94 */

#ifdef __STDC__
extern const char *edit__sccsdata[];
#else
extern char *edit__sccsdata[];
#endif
