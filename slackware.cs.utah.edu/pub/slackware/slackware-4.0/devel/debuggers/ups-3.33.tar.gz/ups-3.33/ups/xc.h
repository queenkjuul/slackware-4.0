/* xc.h - the C interpreter back end ops structures */

/*  Copyright 1993 Mark Russell, University of Kent at Canterbury.
 *
 *  You can do what you like with this source code as long as
 *  you don't try to make money out of it and you include an
 *  unaltered copy of this message (including the copyright).
 */

/* @(#)xc.h	1.1 12/22/93 (UKC) */

extern xp_ops_t Xc_ops, Cc_ops;
