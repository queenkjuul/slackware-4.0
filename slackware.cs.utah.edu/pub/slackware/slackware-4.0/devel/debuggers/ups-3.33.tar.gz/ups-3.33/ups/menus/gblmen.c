#include <stdio.h>
#include <menu3.h>

MENU gbl_men = {
	0x440,
	29813,
	"Collapse",
	99,
	-1,
	-1,
	600,
	47,
	28,
	0,
	0,
	0,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
