/* %W% (UKC) %G% */

#define CP_NUM		10	/* total number of cursors */

#define CP_COMMAND	0
#define CP_NEW		1
#define CP_DIVVER	2
#define CP_DIVHOR	3
#define CP_DIVIDE	4
#define CP_WAIT		5
#define CP_RECT		6
#define CP_PULL		7
#define CP_BOX		8
#define CP_MOVE		9
