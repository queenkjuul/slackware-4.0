/* gd.h - the gdb back end ops structure */

/*  Copyright 1994 Mark Russell, University of Kent at Canterbury.
 *
 *  You can do what you like with this source code as long as
 *  you don't try to make money out of it and you include an
 *  unaltered copy of this message (including the copyright).
 */

/* @(#)gd.h	1.1 16 Apr 1994 (UKC) */

/*  Handle on the gdb based back end.
 */

extern xp_ops_t Gd_ops;
