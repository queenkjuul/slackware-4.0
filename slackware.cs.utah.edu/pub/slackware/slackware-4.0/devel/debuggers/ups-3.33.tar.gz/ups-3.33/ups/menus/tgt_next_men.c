#include <stdio.h>
#include <local/menu3.h>

MENU tgt_next_men = {
	0x440,
	0,
	"Next",
	110,
	-1,
	-1,
	100,
	86,
	0,
	-30584,
	0,
	0,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
