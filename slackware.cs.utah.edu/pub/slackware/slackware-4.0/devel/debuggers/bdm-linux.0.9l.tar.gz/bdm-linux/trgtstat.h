/* trgtstat.h - define target status bits */

#ifndef	TRGTSTAT_H
#define	TRGTSTAT_H

#define	TARGETRESET	1
#define	TARGETHALT	2
#define	TARGETSTOPPED	4
#define	TARGETPOWER	8
#define	TARGETNC	0x10

#endif

/* end of trgtstat.h */
