#define		NEWLINE	"\n"
