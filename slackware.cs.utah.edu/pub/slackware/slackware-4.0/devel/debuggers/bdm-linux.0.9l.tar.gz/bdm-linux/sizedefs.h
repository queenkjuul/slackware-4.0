/* sizedefs.h - define parameter types for BDM package
 * Copyright (C) 1992 by Scott Howard, all rights reserved
 * Permission is hereby granted to freely copy and use this code or derivations thereof
 * as long as no charge is made to anyone for its use
 *
 * this file defines the types BYTE, WORD, and LONG to declare types
 * that match the data sizes used in the target microcontroller(s)
 * BYTE is one byte, WORD is two bytes, LONG is 4 bytes
 * these are all unsigned quantities
 * change these definitions if you are using a compiler with different default sizes
 */

#ifndef	SIZEDEFS_H

#define	SIZEDEFS_H
#define	BYTE	unsigned char
#define	WORD	unsigned short
#define	LONG	unsigned int

#endif

/* end of sizedefs.h */
