/* textio.h - define name of routines to use for BDM driver package 
 * did some funny MS-DOS console stuff.  stdio.h is just fine...
 */

#include	<stdio.h>
#define	NEWLINE		"\n"

/* end of textio.h */
