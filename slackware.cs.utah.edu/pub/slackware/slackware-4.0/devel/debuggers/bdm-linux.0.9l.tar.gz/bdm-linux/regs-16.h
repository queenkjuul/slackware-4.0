/* regs-16.h - define CPU16 target register names */

#define	REG_CCR		0
#define	REG_K		1
#define	REG_IZ		2
#define	REG_IY		3
#define	REG_IX		4
#define	REG_E		5
#define	REG_D		6
#define	REG_H		7
#define	REG_I		8
#define	REG_AM0		9
#define	REG_AM1		10
#define	REG_AM2		11
#define	REG_XMYM	12
#define	REG_PK		13
#define	REG_PC		14
#define	REG_SK		15
#define	REG_SP		16

#define	REG_MINCPU	REG_CCR
#define	REG_MAXCPU	REG_D
#define	REG_MINDSP	REG_H
#define	REG_MAXDSP	REG_XMYM
#define	REG_MINPCSP	REG_PK
#define	REG_MAXPCSP	REG_SP
#define	REG_MAX		REG_SP

/* end of regs-16.h */
