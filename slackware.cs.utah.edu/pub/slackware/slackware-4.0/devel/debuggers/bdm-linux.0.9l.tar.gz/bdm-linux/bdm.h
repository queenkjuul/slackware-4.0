/* bdm.h  - declare function calls in bdm-pd.c and bdm-icd.c */

#include	"sizedefs.h"

void bdm_init (int,int);
void bdm_deinit (void);
LONG bdm_clk (WORD, int);

/* global variables used to give more info if errors occurr */

extern LONG last_addr;
extern char last_rw;
extern char RegsValid;

/* end of bdm.h */
