#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int io_fdesc;

linux_io_init()
{
	io_fdesc = open ("/dev/port",O_RDWR);

	if (io_fdesc < 3) {
		puts ("testport:  error on open");
		exit (1);
	}

	if (lseek (io_fdesc, 0x378, SEEK_SET) < 0) {
		puts ("testport:  error on lseek");
		exit (2);
	}
}

outportb(int p,unsigned char b)
{
	lseek (io_fdesc, p, SEEK_SET);
	write (io_fdesc, &b , 1);
}
int inportb(int p)
{
	char b;
	lseek (io_fdesc, p, SEEK_SET);
	read (io_fdesc, &b, 1);

	return (int)b;
}

disable()
{
}
enable()
{
}
static void bdm_dummy_call(int i)
{
}

bdm_delay(int i)
{
	int j;

	for (j=0;j<i;j++) bdm_dummy_call(j);
}
