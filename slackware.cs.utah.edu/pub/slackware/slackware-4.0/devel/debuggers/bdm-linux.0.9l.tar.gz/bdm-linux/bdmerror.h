/* bdmerror.h - define error codes for call to DriverError ()
 * Copyright (C) 1992 by Scott Howard, all rights reserved
 * Permission is hereby granted to freely copy and use this code or derivations thereof
 * as long as no charge is made to anyone for its use
 */

#define	BDM_FAULT_UNKNOWN	0
#define	BDM_FAULT_POWER		1
#define	BDM_FAULT_CABLE		2
#define	BDM_FAULT_RESPONSE	3
#define	BDM_FAULT_RESET		4
#define	BDM_FAULT_PORT		5
#define BDM_FAULT_BERR		6

/* end of bdmerror.h */
