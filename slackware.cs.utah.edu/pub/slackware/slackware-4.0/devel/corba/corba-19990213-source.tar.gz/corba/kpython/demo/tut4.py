#!/usr/local/bin/python

# Qt tutorial 4.

import sys
from kde import *


class MyWidget(QWidget):
	def __init__(self,*args):
		apply(QWidget.__init__,(self,) + args)

		self.setMinimumSize(200,120)
		self.setMaximumSize(200,120)

		self.quit = QPushButton("Quit",self,"quit")
		self.quit.setGeometry(62,40,75,30)
		self.quit.setFont(QFont("Times",18,QFontWeight.Bold))

		connect(self.quit,SIGNAL("clicked()"),qApp,SLOT("quit()"))


qApp = a = QApplication(sys.argv)

w = MyWidget()
w.setGeometry(100,100,200,120)
a.setMainWidget(w)
w.show()
a.exec_loop()
