#!/usr/local/bin/python

# A simple example using Qt signals connected to Python slots.

import sys
from kde import *


def handleClick():
	print "Calling QApplication.quit()"
	a.quit()


a = QApplication(sys.argv)
b = QPushButton("Press to Quit")

connect(b,SIGNAL("clicked()"),handleClick)

b.resize(100,30)
a.setMainWidget(b)
b.show()
a.exec_loop()
