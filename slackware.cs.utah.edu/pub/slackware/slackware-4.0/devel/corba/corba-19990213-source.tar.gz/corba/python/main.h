#ifndef __main_h__
#define __main_h__

#include <CORBA.h>

class KPythonModule;

extern CORBA::ORB_var pm_orb;
extern CORBA::BOA_var pm_boa;

extern KPythonModule* pm_module;

#endif
