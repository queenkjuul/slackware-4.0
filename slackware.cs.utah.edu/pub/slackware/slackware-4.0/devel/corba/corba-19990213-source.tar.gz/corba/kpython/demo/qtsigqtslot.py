#!/usr/local/bin/python

# A simple example using Qt signals connected to Qt slots.

import sys
from kde import *


a = QApplication(sys.argv)
b = QPushButton("Press to Quit")

connect(b,SIGNAL("clicked()"),a,SLOT("quit()"))

b.resize(100,30)
a.setMainWidget(b)
b.show()
a.exec_loop()
