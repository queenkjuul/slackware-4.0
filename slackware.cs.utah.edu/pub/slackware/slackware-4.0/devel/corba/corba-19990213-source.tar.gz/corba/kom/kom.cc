/*
 *  MICO --- a free CORBA implementation
 *  Copyright (C) 1997-98 Kay Roemer & Arno Puder
 *
 *  This file was automatically generated. DO NOT EDIT!
 */

#include <kom.h>

//--------------------------------------------------------
//  Implementation of stubs
//--------------------------------------------------------
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_EventType; };
#else
CORBA::TypeCodeConst KOM::_tc_EventType;
#endif

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_EventTypePattern; };
#else
CORBA::TypeCodeConst KOM::_tc_EventTypePattern;
#endif

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_EventTypeSeq; };
#else
CORBA::TypeCodeConst KOM::_tc_EventTypeSeq;
#endif

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst Base::_tc_UnknownSignal; };
#else
CORBA::TypeCodeConst KOM::Base::_tc_UnknownSignal;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::Base::UnknownSignal::UnknownSignal()
{
}

KOM::Base::UnknownSignal::UnknownSignal( const UnknownSignal& _s )
{
}

KOM::Base::UnknownSignal::~UnknownSignal()
{
}

KOM::Base::UnknownSignal&
KOM::Base::UnknownSignal::operator=( const UnknownSignal& _s )
{
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::Base::UnknownSignal &_e )
{
  _a.type( KOM::Base::_tc_UnknownSignal );
  return (_a.except_put_begin( "IDL:KOM/Base/UnknownSignal:1.0" ) &&
    _a.except_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::Base::UnknownSignal &_e )
{
  CORBA::String_var _repoid;
  return (_a.except_get_begin( _repoid ) &&
    _a.except_get_end() );
}

void KOM::Base::UnknownSignal::_throwit() const
{
  #ifdef HAVE_EXCEPTIONS
  throw UnknownSignal_var( (KOM::Base::UnknownSignal*)_clone() );
  #else
  CORBA::Exception::_throw_failed( _clone() );
  #endif
}

const char *KOM::Base::UnknownSignal::_repoid() const
{
  return "IDL:KOM/Base/UnknownSignal:1.0";
}

void KOM::Base::UnknownSignal::_encode( CORBA::DataEncoder &_en ) const
{
  CORBA::Any _a;
  _a <<= *this;
  _a.marshal( _en );
}

CORBA::Exception *KOM::Base::UnknownSignal::_clone() const
{
  return new UnknownSignal( *this );
}

KOM::Base::UnknownSignal *KOM::Base::UnknownSignal::_narrow( CORBA::Exception *_ex )
{
  if( _ex && !strcmp( _ex->_repoid(), "IDL:KOM/Base/UnknownSignal:1.0" ) )
    return (UnknownSignal *) _ex;
  return NULL;
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst Base::_tc_Connection; };
#else
CORBA::TypeCodeConst KOM::Base::_tc_Connection;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::Base::Connection::Connection()
{
}

KOM::Base::Connection::Connection( const Connection& _s )
{
  sig = ((Connection&)_s).sig;
  receiver = ((Connection&)_s).receiver;
  function = ((Connection&)_s).function;
}

KOM::Base::Connection::~Connection()
{
}

KOM::Base::Connection&
KOM::Base::Connection::operator=( const Connection& _s )
{
  sig = ((Connection&)_s).sig;
  receiver = ((Connection&)_s).receiver;
  function = ((Connection&)_s).function;
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::Base::Connection &_s )
{
  _a.type( KOM::Base::_tc_Connection );
  return (_a.struct_put_begin() &&
    (_a <<= ((KOM::Base::Connection&)_s).sig) &&
    (_a <<= (KOM::Base_ptr) ((KOM::Base::Connection&)_s).receiver) &&
    (_a <<= ((KOM::Base::Connection&)_s).function) &&
    _a.struct_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::Base::Connection &_s )
{
  return (_a.struct_get_begin() &&
    (_a >>= _s.sig) &&
    (_a >>= (KOM::Base_ptr&) _s.receiver) &&
    (_a >>= _s.function) &&
    _a.struct_get_end() );
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst Base::_tc_ConnectionSeq; };
#else
CORBA::TypeCodeConst KOM::Base::_tc_ConnectionSeq;
#endif

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst Base::_tc_EventFilter; };
#else
CORBA::TypeCodeConst KOM::Base::_tc_EventFilter;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::Base::EventFilter::EventFilter()
{
}

KOM::Base::EventFilter::EventFilter( const EventFilter& _s )
{
  receiver = ((EventFilter&)_s).receiver;
  function = ((EventFilter&)_s).function;
  events = ((EventFilter&)_s).events;
}

KOM::Base::EventFilter::~EventFilter()
{
}

KOM::Base::EventFilter&
KOM::Base::EventFilter::operator=( const EventFilter& _s )
{
  receiver = ((EventFilter&)_s).receiver;
  function = ((EventFilter&)_s).function;
  events = ((EventFilter&)_s).events;
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::Base::EventFilter &_s )
{
  _a.type( KOM::Base::_tc_EventFilter );
  return (_a.struct_put_begin() &&
    (_a <<= (KOM::Base_ptr) ((KOM::Base::EventFilter&)_s).receiver) &&
    (_a <<= ((KOM::Base::EventFilter&)_s).function) &&
    (_a <<= ((KOM::Base::EventFilter&)_s).events) &&
    _a.struct_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::Base::EventFilter &_s )
{
  return (_a.struct_get_begin() &&
    (_a >>= (KOM::Base_ptr&) _s.receiver) &&
    (_a >>= _s.function) &&
    (_a >>= _s.events) &&
    _a.struct_get_end() );
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst Base::_tc_EventFilterSeq; };
#else
CORBA::TypeCodeConst KOM::Base::_tc_EventFilterSeq;
#endif

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst Base::_tc_FilterMode; };
#else
CORBA::TypeCodeConst KOM::Base::_tc_FilterMode;
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::Base::FilterMode &_e )
{
  _a.type( KOM::Base::_tc_FilterMode );
  return (_a.enum_put( (CORBA::ULong) _e ));
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::Base::FilterMode &_e )
{
  CORBA::ULong _ul;
  if( !_a.enum_get( _ul ) )
    return FALSE;
  _e = (KOM::Base::FilterMode) _ul;
  return TRUE;
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst Base::_tc_RelativesSeq; };
#else
CORBA::TypeCodeConst KOM::Base::_tc_RelativesSeq;
#endif


// Stub interface Base
KOM::Base::~Base()
{
}

KOM::Base_ptr KOM::Base::_duplicate( Base_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KOM::Base::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KOM/Base:1.0" ) == 0 )
    return (void *)this;
  return NULL;
}

bool KOM::Base::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KOM/Base:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KOM::Base_ptr KOM::Base::_narrow( CORBA::Object_ptr _obj )
{
  KOM::Base_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KOM/Base:1.0" )))
      return _duplicate( (KOM::Base_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KOM::Base_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KOM/Base:1.0" ) ) {
      _o = new KOM::Base_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KOM::Base_ptr KOM::Base::_nil()
{
  return NULL;
}

KOM::Base_stub::~Base_stub()
{
}

void KOM::Base_stub::connect( const char* sig, KOM::Base_ptr obj, const char* function )
{
  CORBA::Request_var _req = this->_request( "connect" );
  _req->add_in_arg( "sig" ) <<= CORBA::Any::from_string( (char *) sig, 0 );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->add_in_arg( "function" ) <<= CORBA::Any::from_string( (char *) function, 0 );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::disconnect( const char* sig, KOM::Base_ptr obj, const char* function )
{
  CORBA::Request_var _req = this->_request( "disconnect" );
  _req->add_in_arg( "sig" ) <<= CORBA::Any::from_string( (char *) sig, 0 );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->add_in_arg( "function" ) <<= CORBA::Any::from_string( (char *) function, 0 );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::disconnectSignalNotify( KOM::Base_ptr obj, const char* sig, const char* function )
{
  CORBA::Request_var _req = this->_request( "disconnectSignalNotify" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->add_in_arg( "sig" ) <<= CORBA::Any::from_string( (char *) sig, 0 );
  _req->add_in_arg( "function" ) <<= CORBA::Any::from_string( (char *) function, 0 );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


KOM::Base::ConnectionSeq* KOM::Base_stub::describeConnections()
{
  CORBA::Request_var _req = this->_request( "describeConnections" );
  _req->result()->value()->type( KOM::Base::_tc_ConnectionSeq );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::Base::ConnectionSeq* _res = new ::KOM::Base::ConnectionSeq;
  *_req->result()->value() >>= *_res;
  return _res;
}


void KOM::Base_stub::connectNotify( KOM::Base_ptr obj )
{
  CORBA::Request_var _req = this->_request( "connectNotify" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::disconnectNotify( KOM::Base_ptr obj )
{
  CORBA::Request_var _req = this->_request( "disconnectNotify" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::receiveASync( const char* type, const CORBA::Any& value )
{
  CORBA::Request_var _req = this->_request( "receiveASync" );
  _req->add_in_arg( "type" ) <<= CORBA::Any::from_string( (char *) type, 0 );
  _req->add_in_arg( "value" ) <<= value;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::receive( const char* type, const CORBA::Any& value )
{
  CORBA::Request_var _req = this->_request( "receive" );
  _req->add_in_arg( "type" ) <<= CORBA::Any::from_string( (char *) type, 0 );
  _req->add_in_arg( "value" ) <<= value;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


CORBA::Boolean KOM::Base_stub::eventFilter( KOM::Base_ptr obj, const char* type, const CORBA::Any& value )
{
  CORBA::Request_var _req = this->_request( "eventFilter" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->add_in_arg( "type" ) <<= CORBA::Any::from_string( (char *) type, 0 );
  _req->add_in_arg( "value" ) <<= value;
  _req->result()->value()->type( CORBA::_tc_boolean );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  CORBA::Boolean _res;
  *_req->result()->value() >>= CORBA::Any::to_boolean( _res );
  return _res;
}


void KOM::Base_stub::installFilter( KOM::Base_ptr obj, const char* function, const KOM::EventTypeSeq& events, KOM::Base::FilterMode mode )
{
  CORBA::Request_var _req = this->_request( "installFilter" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->add_in_arg( "function" ) <<= CORBA::Any::from_string( (char *) function, 0 );
  _req->add_in_arg( "events" ) <<= events;
  _req->add_in_arg( "mode" ) <<= mode;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::uninstallFilter( KOM::Base_ptr obj )
{
  CORBA::Request_var _req = this->_request( "uninstallFilter" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::disconnectFilterNotify( KOM::Base_ptr obj )
{
  CORBA::Request_var _req = this->_request( "disconnectFilterNotify" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


KOM::Base::EventFilterSeq* KOM::Base_stub::describeEventFilters()
{
  CORBA::Request_var _req = this->_request( "describeEventFilters" );
  _req->result()->value()->type( KOM::Base::_tc_EventFilterSeq );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::Base::EventFilterSeq* _res = new ::KOM::Base::EventFilterSeq;
  *_req->result()->value() >>= *_res;
  return _res;
}


void KOM::Base_stub::adopt( KOM::Base_ptr obj )
{
  CORBA::Request_var _req = this->_request( "adopt" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::adoptNotify( KOM::Base_ptr obj )
{
  CORBA::Request_var _req = this->_request( "adoptNotify" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::leave( KOM::Base_ptr obj )
{
  CORBA::Request_var _req = this->_request( "leave" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::leaveNotify( KOM::Base_ptr obj )
{
  CORBA::Request_var _req = this->_request( "leaveNotify" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


KOM::Base::RelativesSeq* KOM::Base_stub::describeRelatives()
{
  CORBA::Request_var _req = this->_request( "describeRelatives" );
  _req->result()->value()->type( KOM::Base::_tc_RelativesSeq );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::Base::RelativesSeq* _res = new ::KOM::Base::RelativesSeq;
  *_req->result()->value() >>= *_res;
  return _res;
}


void KOM::Base_stub::incRef()
{
  CORBA::Request_var _req = this->_request( "incRef" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::decRef()
{
  CORBA::Request_var _req = this->_request( "decRef" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


CORBA::ULong KOM::Base_stub::refCount()
{
  CORBA::Request_var _req = this->_request( "refCount" );
  _req->result()->value()->type( CORBA::_tc_ulong );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  CORBA::ULong _res;
  *_req->result()->value() >>= _res;
  return _res;
}


void KOM::Base_stub::destroy()
{
  CORBA::Request_var _req = this->_request( "destroy" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::disconnectObject( KOM::Base_ptr obj )
{
  CORBA::Request_var _req = this->_request( "disconnectObject" );
  _req->add_in_arg( "obj" ) <<= (KOM::Base_ptr) obj;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Base_stub::disconnectAll()
{
  CORBA::Request_var _req = this->_request( "disconnectAll" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


#ifdef HAVE_NAMESPACE
namespace KOM { vector<CORBA::Narrow_proto> * Base::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KOM::Base::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_Base; };
#else
CORBA::TypeCodeConst KOM::_tc_Base;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KOM::Base_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "Base" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KOM::Base_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KOM::Base::_nil();
    return TRUE;
  }
  _obj = ::KOM::Base::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_Member; };
#else
CORBA::TypeCodeConst KOM::_tc_Member;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::Member::Member()
{
}

KOM::Member::Member( const Member& _s )
{
  obj = ((Member&)_s).obj;
  name = ((Member&)_s).name;
}

KOM::Member::~Member()
{
}

KOM::Member&
KOM::Member::operator=( const Member& _s )
{
  obj = ((Member&)_s).obj;
  name = ((Member&)_s).name;
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::Member &_s )
{
  _a.type( KOM::_tc_Member );
  return (_a.struct_put_begin() &&
    (_a <<= (KOM::Base_ptr) ((KOM::Member&)_s).obj) &&
    (_a <<= ((KOM::Member&)_s).name) &&
    _a.struct_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::Member &_s )
{
  return (_a.struct_get_begin() &&
    (_a >>= (KOM::Base_ptr&) _s.obj) &&
    (_a >>= _s.name) &&
    _a.struct_get_end() );
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_MemberSeq; };
#else
CORBA::TypeCodeConst KOM::_tc_MemberSeq;
#endif

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_UnknownMember; };
#else
CORBA::TypeCodeConst KOM::_tc_UnknownMember;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::UnknownMember::UnknownMember()
{
}

KOM::UnknownMember::UnknownMember( const UnknownMember& _s )
{
  name = ((UnknownMember&)_s).name;
}

KOM::UnknownMember::~UnknownMember()
{
}

KOM::UnknownMember&
KOM::UnknownMember::operator=( const UnknownMember& _s )
{
  name = ((UnknownMember&)_s).name;
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::UnknownMember &_e )
{
  _a.type( KOM::_tc_UnknownMember );
  return (_a.except_put_begin( "IDL:KOM/UnknownMember:1.0" ) &&
    (_a <<= ((KOM::UnknownMember&)_e).name) &&
    _a.except_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::UnknownMember &_e )
{
  CORBA::String_var _repoid;
  return (_a.except_get_begin( _repoid ) &&
    (_a >>= _e.name) &&
    _a.except_get_end() );
}

void KOM::UnknownMember::_throwit() const
{
  #ifdef HAVE_EXCEPTIONS
  throw UnknownMember_var( (KOM::UnknownMember*)_clone() );
  #else
  CORBA::Exception::_throw_failed( _clone() );
  #endif
}

const char *KOM::UnknownMember::_repoid() const
{
  return "IDL:KOM/UnknownMember:1.0";
}

void KOM::UnknownMember::_encode( CORBA::DataEncoder &_en ) const
{
  CORBA::Any _a;
  _a <<= *this;
  _a.marshal( _en );
}

CORBA::Exception *KOM::UnknownMember::_clone() const
{
  return new UnknownMember( *this );
}

KOM::UnknownMember *KOM::UnknownMember::_narrow( CORBA::Exception *_ex )
{
  if( _ex && !strcmp( _ex->_repoid(), "IDL:KOM/UnknownMember:1.0" ) )
    return (UnknownMember *) _ex;
  return NULL;
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_DuplicateMember; };
#else
CORBA::TypeCodeConst KOM::_tc_DuplicateMember;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::DuplicateMember::DuplicateMember()
{
}

KOM::DuplicateMember::DuplicateMember( const DuplicateMember& _s )
{
  name = ((DuplicateMember&)_s).name;
}

KOM::DuplicateMember::~DuplicateMember()
{
}

KOM::DuplicateMember&
KOM::DuplicateMember::operator=( const DuplicateMember& _s )
{
  name = ((DuplicateMember&)_s).name;
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::DuplicateMember &_e )
{
  _a.type( KOM::_tc_DuplicateMember );
  return (_a.except_put_begin( "IDL:KOM/DuplicateMember:1.0" ) &&
    (_a <<= ((KOM::DuplicateMember&)_e).name) &&
    _a.except_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::DuplicateMember &_e )
{
  CORBA::String_var _repoid;
  return (_a.except_get_begin( _repoid ) &&
    (_a >>= _e.name) &&
    _a.except_get_end() );
}

void KOM::DuplicateMember::_throwit() const
{
  #ifdef HAVE_EXCEPTIONS
  throw DuplicateMember_var( (KOM::DuplicateMember*)_clone() );
  #else
  CORBA::Exception::_throw_failed( _clone() );
  #endif
}

const char *KOM::DuplicateMember::_repoid() const
{
  return "IDL:KOM/DuplicateMember:1.0";
}

void KOM::DuplicateMember::_encode( CORBA::DataEncoder &_en ) const
{
  CORBA::Any _a;
  _a <<= *this;
  _a.marshal( _en );
}

CORBA::Exception *KOM::DuplicateMember::_clone() const
{
  return new DuplicateMember( *this );
}

KOM::DuplicateMember *KOM::DuplicateMember::_narrow( CORBA::Exception *_ex )
{
  if( _ex && !strcmp( _ex->_repoid(), "IDL:KOM/DuplicateMember:1.0" ) )
    return (DuplicateMember *) _ex;
  return NULL;
}


// Stub interface Container
KOM::Container::~Container()
{
}

KOM::Container_ptr KOM::Container::_duplicate( Container_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KOM::Container::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KOM/Container:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = Base::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KOM::Container::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KOM/Container:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KOM::Container_ptr KOM::Container::_narrow( CORBA::Object_ptr _obj )
{
  KOM::Container_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KOM/Container:1.0" )))
      return _duplicate( (KOM::Container_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KOM::Container_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KOM/Container:1.0" ) ) {
      _o = new KOM::Container_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KOM::Container_ptr KOM::Container::_nil()
{
  return NULL;
}

KOM::Container_stub::~Container_stub()
{
}

void KOM::Container_stub::addContainee( const KOM::Member& memb )
{
  CORBA::Request_var _req = this->_request( "addContainee" );
  _req->add_in_arg( "memb" ) <<= memb;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      if( !strcmp( _uuex->_except_repoid(), "IDL:KOM/DuplicateMember:1.0" ) ) {
        CORBA::Any &_a = _uuex->exception( ::KOM::_tc_DuplicateMember );
        ::KOM::DuplicateMember _user_ex;
        _a >>= _user_ex;
        mico_throw( _user_ex );
      }
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Container_stub::removeContainee( const char* name )
{
  CORBA::Request_var _req = this->_request( "removeContainee" );
  _req->add_in_arg( "name" ) <<= CORBA::Any::from_string( (char *) name, 0 );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      if( !strcmp( _uuex->_except_repoid(), "IDL:KOM/UnknownMember:1.0" ) ) {
        CORBA::Any &_a = _uuex->exception( ::KOM::_tc_UnknownMember );
        ::KOM::UnknownMember _user_ex;
        _a >>= _user_ex;
        mico_throw( _user_ex );
      }
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Container_stub::replaceContainee( const KOM::Member& member )
{
  CORBA::Request_var _req = this->_request( "replaceContainee" );
  _req->add_in_arg( "member" ) <<= member;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      if( !strcmp( _uuex->_except_repoid(), "IDL:KOM/UnknownMember:1.0" ) ) {
        CORBA::Any &_a = _uuex->exception( ::KOM::_tc_UnknownMember );
        ::KOM::UnknownMember _user_ex;
        _a >>= _user_ex;
        mico_throw( _user_ex );
      }
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Container_stub::clear()
{
  CORBA::Request_var _req = this->_request( "clear" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


KOM::MemberSeq* KOM::Container_stub::listContainees()
{
  CORBA::Request_var _req = this->_request( "listContainees" );
  _req->result()->value()->type( KOM::_tc_MemberSeq );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::MemberSeq* _res = new ::KOM::MemberSeq;
  *_req->result()->value() >>= *_res;
  return _res;
}


KOM::Base_ptr KOM::Container_stub::lookupContainee( const char* name )
{
  CORBA::Request_var _req = this->_request( "lookupContainee" );
  _req->add_in_arg( "name" ) <<= CORBA::Any::from_string( (char *) name, 0 );
  _req->result()->value()->type( KOM::_tc_Base );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::Base_ptr _res;
  *_req->result()->value() >>= (KOM::Base_ptr&) _res;
  return _res;
}


void KOM::Container_stub::containeeAdded( const KOM::Member& memb )
{
  CORBA::Request_var _req = this->_request( "containeeAdded" );
  _req->add_in_arg( "memb" ) <<= memb;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KOM::Container_stub::containeeRemoved( const KOM::Member& memb )
{
  CORBA::Request_var _req = this->_request( "containeeRemoved" );
  _req->add_in_arg( "memb" ) <<= memb;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


struct _global_init_KOM_Container {
  _global_init_KOM_Container()
  {
    if( ::KOM::Base::_narrow_helpers == NULL )
      ::KOM::Base::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::KOM::Base::_narrow_helpers->push_back( KOM::Container::_narrow_helper2 );
  }
} __global_init_KOM_Container;

#ifdef HAVE_NAMESPACE
namespace KOM { vector<CORBA::Narrow_proto> * Container::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KOM::Container::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_Container; };
#else
CORBA::TypeCodeConst KOM::_tc_Container;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KOM::Container_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "Container" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KOM::Container_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KOM::Container::_nil();
    return TRUE;
  }
  _obj = ::KOM::Container::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_InterfaceName; };
#else
CORBA::TypeCodeConst KOM::_tc_InterfaceName;
#endif

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_InterfaceSeq; };
#else
CORBA::TypeCodeConst KOM::_tc_InterfaceSeq;
#endif

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_InterfaceAlreadySupported; };
#else
CORBA::TypeCodeConst KOM::_tc_InterfaceAlreadySupported;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::InterfaceAlreadySupported::InterfaceAlreadySupported()
{
}

KOM::InterfaceAlreadySupported::InterfaceAlreadySupported( const InterfaceAlreadySupported& _s )
{
  iface = ((InterfaceAlreadySupported&)_s).iface;
}

KOM::InterfaceAlreadySupported::~InterfaceAlreadySupported()
{
}

KOM::InterfaceAlreadySupported&
KOM::InterfaceAlreadySupported::operator=( const InterfaceAlreadySupported& _s )
{
  iface = ((InterfaceAlreadySupported&)_s).iface;
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::InterfaceAlreadySupported &_e )
{
  _a.type( KOM::_tc_InterfaceAlreadySupported );
  return (_a.except_put_begin( "IDL:KOM/InterfaceAlreadySupported:1.0" ) &&
    (_a <<= ((KOM::InterfaceAlreadySupported&)_e).iface) &&
    _a.except_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::InterfaceAlreadySupported &_e )
{
  CORBA::String_var _repoid;
  return (_a.except_get_begin( _repoid ) &&
    (_a >>= _e.iface) &&
    _a.except_get_end() );
}

void KOM::InterfaceAlreadySupported::_throwit() const
{
  #ifdef HAVE_EXCEPTIONS
  throw InterfaceAlreadySupported_var( (KOM::InterfaceAlreadySupported*)_clone() );
  #else
  CORBA::Exception::_throw_failed( _clone() );
  #endif
}

const char *KOM::InterfaceAlreadySupported::_repoid() const
{
  return "IDL:KOM/InterfaceAlreadySupported:1.0";
}

void KOM::InterfaceAlreadySupported::_encode( CORBA::DataEncoder &_en ) const
{
  CORBA::Any _a;
  _a <<= *this;
  _a.marshal( _en );
}

CORBA::Exception *KOM::InterfaceAlreadySupported::_clone() const
{
  return new InterfaceAlreadySupported( *this );
}

KOM::InterfaceAlreadySupported *KOM::InterfaceAlreadySupported::_narrow( CORBA::Exception *_ex )
{
  if( _ex && !strcmp( _ex->_repoid(), "IDL:KOM/InterfaceAlreadySupported:1.0" ) )
    return (InterfaceAlreadySupported *) _ex;
  return NULL;
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_InterfaceNotFound; };
#else
CORBA::TypeCodeConst KOM::_tc_InterfaceNotFound;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::InterfaceNotFound::InterfaceNotFound()
{
}

KOM::InterfaceNotFound::InterfaceNotFound( const InterfaceNotFound& _s )
{
}

KOM::InterfaceNotFound::~InterfaceNotFound()
{
}

KOM::InterfaceNotFound&
KOM::InterfaceNotFound::operator=( const InterfaceNotFound& _s )
{
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::InterfaceNotFound &_e )
{
  _a.type( KOM::_tc_InterfaceNotFound );
  return (_a.except_put_begin( "IDL:KOM/InterfaceNotFound:1.0" ) &&
    _a.except_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::InterfaceNotFound &_e )
{
  CORBA::String_var _repoid;
  return (_a.except_get_begin( _repoid ) &&
    _a.except_get_end() );
}

void KOM::InterfaceNotFound::_throwit() const
{
  #ifdef HAVE_EXCEPTIONS
  throw InterfaceNotFound_var( (KOM::InterfaceNotFound*)_clone() );
  #else
  CORBA::Exception::_throw_failed( _clone() );
  #endif
}

const char *KOM::InterfaceNotFound::_repoid() const
{
  return "IDL:KOM/InterfaceNotFound:1.0";
}

void KOM::InterfaceNotFound::_encode( CORBA::DataEncoder &_en ) const
{
  CORBA::Any _a;
  _a <<= *this;
  _a.marshal( _en );
}

CORBA::Exception *KOM::InterfaceNotFound::_clone() const
{
  return new InterfaceNotFound( *this );
}

KOM::InterfaceNotFound *KOM::InterfaceNotFound::_narrow( CORBA::Exception *_ex )
{
  if( _ex && !strcmp( _ex->_repoid(), "IDL:KOM/InterfaceNotFound:1.0" ) )
    return (InterfaceNotFound *) _ex;
  return NULL;
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_ID; };
#else
CORBA::TypeCodeConst KOM::_tc_ID;
#endif

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_UnknownID; };
#else
CORBA::TypeCodeConst KOM::_tc_UnknownID;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::UnknownID::UnknownID()
{
}

KOM::UnknownID::UnknownID( const UnknownID& _s )
{
  id = ((UnknownID&)_s).id;
}

KOM::UnknownID::~UnknownID()
{
}

KOM::UnknownID&
KOM::UnknownID::operator=( const UnknownID& _s )
{
  id = ((UnknownID&)_s).id;
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::UnknownID &_e )
{
  _a.type( KOM::_tc_UnknownID );
  return (_a.except_put_begin( "IDL:KOM/UnknownID:1.0" ) &&
    (_a <<= ((KOM::UnknownID&)_e).id) &&
    _a.except_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::UnknownID &_e )
{
  CORBA::String_var _repoid;
  return (_a.except_get_begin( _repoid ) &&
    (_a >>= _e.id) &&
    _a.except_get_end() );
}

void KOM::UnknownID::_throwit() const
{
  #ifdef HAVE_EXCEPTIONS
  throw UnknownID_var( (KOM::UnknownID*)_clone() );
  #else
  CORBA::Exception::_throw_failed( _clone() );
  #endif
}

const char *KOM::UnknownID::_repoid() const
{
  return "IDL:KOM/UnknownID:1.0";
}

void KOM::UnknownID::_encode( CORBA::DataEncoder &_en ) const
{
  CORBA::Any _a;
  _a <<= *this;
  _a.marshal( _en );
}

CORBA::Exception *KOM::UnknownID::_clone() const
{
  return new UnknownID( *this );
}

KOM::UnknownID *KOM::UnknownID::_narrow( CORBA::Exception *_ex )
{
  if( _ex && !strcmp( _ex->_repoid(), "IDL:KOM/UnknownID:1.0" ) )
    return (UnknownID *) _ex;
  return NULL;
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst Component::_tc_PluginInfo; };
#else
CORBA::TypeCodeConst KOM::Component::_tc_PluginInfo;
#endif

#ifdef HAVE_EXPLICIT_STRUCT_OPS
KOM::Component::PluginInfo::PluginInfo()
{
}

KOM::Component::PluginInfo::PluginInfo( const PluginInfo& _s )
{
  interfaces = ((PluginInfo&)_s).interfaces;
  id = ((PluginInfo&)_s).id;
  composed = ((PluginInfo&)_s).composed;
}

KOM::Component::PluginInfo::~PluginInfo()
{
}

KOM::Component::PluginInfo&
KOM::Component::PluginInfo::operator=( const PluginInfo& _s )
{
  interfaces = ((PluginInfo&)_s).interfaces;
  id = ((PluginInfo&)_s).id;
  composed = ((PluginInfo&)_s).composed;
  return *this;
}
#endif

CORBA::Boolean operator<<=( CORBA::Any &_a, const KOM::Component::PluginInfo &_s )
{
  _a.type( KOM::Component::_tc_PluginInfo );
  return (_a.struct_put_begin() &&
    (_a <<= ((KOM::Component::PluginInfo&)_s).interfaces) &&
    (_a <<= ((KOM::Component::PluginInfo&)_s).id) &&
    (_a <<= CORBA::Any::from_boolean( ((KOM::Component::PluginInfo&)_s).composed )) &&
    _a.struct_put_end() );
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, KOM::Component::PluginInfo &_s )
{
  return (_a.struct_get_begin() &&
    (_a >>= _s.interfaces) &&
    (_a >>= _s.id) &&
    (_a >>= CORBA::Any::to_boolean( _s.composed )) &&
    _a.struct_get_end() );
}

#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst Component::_tc_PluginInfoSeq; };
#else
CORBA::TypeCodeConst KOM::Component::_tc_PluginInfoSeq;
#endif


// Stub interface Component
KOM::Component::~Component()
{
}

KOM::Component_ptr KOM::Component::_duplicate( Component_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KOM::Component::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KOM/Component:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = Base::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KOM::Component::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KOM/Component:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KOM::Component_ptr KOM::Component::_narrow( CORBA::Object_ptr _obj )
{
  KOM::Component_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KOM/Component:1.0" )))
      return _duplicate( (KOM::Component_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KOM::Component_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KOM/Component:1.0" ) ) {
      _o = new KOM::Component_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KOM::Component_ptr KOM::Component::_nil()
{
  return NULL;
}

KOM::Component_stub::~Component_stub()
{
}

CORBA::Object_ptr KOM::Component_stub::getInterface( const char* name )
{
  CORBA::Request_var _req = this->_request( "getInterface" );
  _req->add_in_arg( "name" ) <<= CORBA::Any::from_string( (char *) name, 0 );
  _req->result()->value()->type( CORBA::_tc_Object );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      if( !strcmp( _uuex->_except_repoid(), "IDL:KOM/InterfaceNotFound:1.0" ) ) {
        CORBA::Any &_a = _uuex->exception( ::KOM::_tc_InterfaceNotFound );
        ::KOM::InterfaceNotFound _user_ex;
        _a >>= _user_ex;
        mico_throw( _user_ex );
      }
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  CORBA::Object_ptr _res;
  *_req->result()->value() >>= CORBA::Any::to_object( _res );
  return _res;
}


KOM::InterfaceSeq* KOM::Component_stub::interfaces()
{
  CORBA::Request_var _req = this->_request( "interfaces" );
  _req->result()->value()->type( KOM::_tc_InterfaceSeq );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::InterfaceSeq* _res = new ::KOM::InterfaceSeq;
  *_req->result()->value() >>= *_res;
  return _res;
}


CORBA::Boolean KOM::Component_stub::supportsInterface( const char* name )
{
  CORBA::Request_var _req = this->_request( "supportsInterface" );
  _req->add_in_arg( "name" ) <<= CORBA::Any::from_string( (char *) name, 0 );
  _req->result()->value()->type( CORBA::_tc_boolean );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  CORBA::Boolean _res;
  *_req->result()->value() >>= CORBA::Any::to_boolean( _res );
  return _res;
}


KOM::ID KOM::Component_stub::addAggregate( KOM::AggregateFactory_ptr factory, const KOM::InterfaceSeq& required, const KOM::InterfaceSeq& provided, CORBA::Boolean activate )
{
  CORBA::Request_var _req = this->_request( "addAggregate" );
  _req->add_in_arg( "factory" ) <<= (KOM::AggregateFactory_ptr) factory;
  _req->add_in_arg( "required" ) <<= required;
  _req->add_in_arg( "provided" ) <<= provided;
  _req->add_in_arg( "activate" ) <<= CORBA::Any::from_boolean( activate );
  _req->result()->value()->type( KOM::_tc_ID );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      if( !strcmp( _uuex->_except_repoid(), "IDL:KOM/InterfaceAlreadySupported:1.0" ) ) {
        CORBA::Any &_a = _uuex->exception( ::KOM::_tc_InterfaceAlreadySupported );
        ::KOM::InterfaceAlreadySupported _user_ex;
        _a >>= _user_ex;
        mico_throw( _user_ex );
      }
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::ID _res;
  *_req->result()->value() >>= _res;
  return _res;
}


void KOM::Component_stub::removeAggregate( KOM::ID id )
{
  CORBA::Request_var _req = this->_request( "removeAggregate" );
  _req->add_in_arg( "id" ) <<= id;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      if( !strcmp( _uuex->_except_repoid(), "IDL:KOM/UnknownID:1.0" ) ) {
        CORBA::Any &_a = _uuex->exception( ::KOM::_tc_UnknownID );
        ::KOM::UnknownID _user_ex;
        _a >>= _user_ex;
        mico_throw( _user_ex );
      }
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


KOM::ID KOM::Component_stub::addPlugin( KOM::PluginFactory_ptr factory, const KOM::InterfaceSeq& required, const KOM::InterfaceSeq& required_plugins, const KOM::InterfaceSeq& provided, CORBA::Boolean activate )
{
  CORBA::Request_var _req = this->_request( "addPlugin" );
  _req->add_in_arg( "factory" ) <<= (KOM::PluginFactory_ptr) factory;
  _req->add_in_arg( "required" ) <<= required;
  _req->add_in_arg( "required_plugins" ) <<= required_plugins;
  _req->add_in_arg( "provided" ) <<= provided;
  _req->add_in_arg( "activate" ) <<= CORBA::Any::from_boolean( activate );
  _req->result()->value()->type( KOM::_tc_ID );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::ID _res;
  *_req->result()->value() >>= _res;
  return _res;
}


void KOM::Component_stub::removePlugin( KOM::ID id )
{
  CORBA::Request_var _req = this->_request( "removePlugin" );
  _req->add_in_arg( "id" ) <<= id;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      if( !strcmp( _uuex->_except_repoid(), "IDL:KOM/UnknownID:1.0" ) ) {
        CORBA::Any &_a = _uuex->exception( ::KOM::_tc_UnknownID );
        ::KOM::UnknownID _user_ex;
        _a >>= _user_ex;
        mico_throw( _user_ex );
      }
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


CORBA::Object_ptr KOM::Component_stub::getPluginInterface( const char* name )
{
  CORBA::Request_var _req = this->_request( "getPluginInterface" );
  _req->add_in_arg( "name" ) <<= CORBA::Any::from_string( (char *) name, 0 );
  _req->result()->value()->type( CORBA::_tc_Object );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      if( !strcmp( _uuex->_except_repoid(), "IDL:KOM/InterfaceNotFound:1.0" ) ) {
        CORBA::Any &_a = _uuex->exception( ::KOM::_tc_InterfaceNotFound );
        ::KOM::InterfaceNotFound _user_ex;
        _a >>= _user_ex;
        mico_throw( _user_ex );
      }
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  CORBA::Object_ptr _res;
  *_req->result()->value() >>= CORBA::Any::to_object( _res );
  return _res;
}


KOM::InterfaceSeq* KOM::Component_stub::pluginInterfaces()
{
  CORBA::Request_var _req = this->_request( "pluginInterfaces" );
  _req->result()->value()->type( KOM::_tc_InterfaceSeq );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::InterfaceSeq* _res = new ::KOM::InterfaceSeq;
  *_req->result()->value() >>= *_res;
  return _res;
}


CORBA::Boolean KOM::Component_stub::supportsPluginInterface( const char* name )
{
  CORBA::Request_var _req = this->_request( "supportsPluginInterface" );
  _req->add_in_arg( "name" ) <<= CORBA::Any::from_string( (char *) name, 0 );
  _req->result()->value()->type( CORBA::_tc_boolean );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  CORBA::Boolean _res;
  *_req->result()->value() >>= CORBA::Any::to_boolean( _res );
  return _res;
}


KOM::Component::PluginInfoSeq* KOM::Component_stub::describePlugins()
{
  CORBA::Request_var _req = this->_request( "describePlugins" );
  _req->result()->value()->type( KOM::Component::_tc_PluginInfoSeq );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::Component::PluginInfoSeq* _res = new ::KOM::Component::PluginInfoSeq;
  *_req->result()->value() >>= *_res;
  return _res;
}


KOM::Plugin_ptr KOM::Component_stub::getPlugin( KOM::ID id )
{
  CORBA::Request_var _req = this->_request( "getPlugin" );
  _req->add_in_arg( "id" ) <<= id;
  _req->result()->value()->type( KOM::_tc_Plugin );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      if( !strcmp( _uuex->_except_repoid(), "IDL:KOM/UnknownID:1.0" ) ) {
        CORBA::Any &_a = _uuex->exception( ::KOM::_tc_UnknownID );
        ::KOM::UnknownID _user_ex;
        _a >>= _user_ex;
        mico_throw( _user_ex );
      }
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::Plugin_ptr _res;
  *_req->result()->value() >>= (KOM::Plugin_ptr&) _res;
  return _res;
}


struct _global_init_KOM_Component {
  _global_init_KOM_Component()
  {
    if( ::KOM::Base::_narrow_helpers == NULL )
      ::KOM::Base::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::KOM::Base::_narrow_helpers->push_back( KOM::Component::_narrow_helper2 );
  }
} __global_init_KOM_Component;

#ifdef HAVE_NAMESPACE
namespace KOM { vector<CORBA::Narrow_proto> * Component::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KOM::Component::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_Component; };
#else
CORBA::TypeCodeConst KOM::_tc_Component;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KOM::Component_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "Component" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KOM::Component_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KOM::Component::_nil();
    return TRUE;
  }
  _obj = ::KOM::Component::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}


// Stub interface ComponentFactory
KOM::ComponentFactory::~ComponentFactory()
{
}

KOM::ComponentFactory_ptr KOM::ComponentFactory::_duplicate( ComponentFactory_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KOM::ComponentFactory::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KOM/ComponentFactory:1.0" ) == 0 )
    return (void *)this;
  return NULL;
}

bool KOM::ComponentFactory::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KOM/ComponentFactory:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KOM::ComponentFactory_ptr KOM::ComponentFactory::_narrow( CORBA::Object_ptr _obj )
{
  KOM::ComponentFactory_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KOM/ComponentFactory:1.0" )))
      return _duplicate( (KOM::ComponentFactory_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KOM::ComponentFactory_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KOM/ComponentFactory:1.0" ) ) {
      _o = new KOM::ComponentFactory_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KOM::ComponentFactory_ptr KOM::ComponentFactory::_nil()
{
  return NULL;
}

KOM::ComponentFactory_stub::~ComponentFactory_stub()
{
}

#ifdef HAVE_NAMESPACE
namespace KOM { vector<CORBA::Narrow_proto> * ComponentFactory::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KOM::ComponentFactory::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_ComponentFactory; };
#else
CORBA::TypeCodeConst KOM::_tc_ComponentFactory;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KOM::ComponentFactory_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "ComponentFactory" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KOM::ComponentFactory_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KOM::ComponentFactory::_nil();
    return TRUE;
  }
  _obj = ::KOM::ComponentFactory::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}


// Stub interface Application
KOM::Application::~Application()
{
}

KOM::Application_ptr KOM::Application::_duplicate( Application_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KOM::Application::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KOM/Application:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = Component::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KOM::Application::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KOM/Application:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KOM::Application_ptr KOM::Application::_narrow( CORBA::Object_ptr _obj )
{
  KOM::Application_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KOM/Application:1.0" )))
      return _duplicate( (KOM::Application_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KOM::Application_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KOM/Application:1.0" ) ) {
      _o = new KOM::Application_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KOM::Application_ptr KOM::Application::_nil()
{
  return NULL;
}

KOM::Application_stub::~Application_stub()
{
}

struct _global_init_KOM_Application {
  _global_init_KOM_Application()
  {
    if( ::KOM::Component::_narrow_helpers == NULL )
      ::KOM::Component::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::KOM::Component::_narrow_helpers->push_back( KOM::Application::_narrow_helper2 );
  }
} __global_init_KOM_Application;

#ifdef HAVE_NAMESPACE
namespace KOM { vector<CORBA::Narrow_proto> * Application::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KOM::Application::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_Application; };
#else
CORBA::TypeCodeConst KOM::_tc_Application;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KOM::Application_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "Application" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KOM::Application_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KOM::Application::_nil();
    return TRUE;
  }
  _obj = ::KOM::Application::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}


// Stub interface Aggregate
KOM::Aggregate::~Aggregate()
{
}

KOM::Aggregate_ptr KOM::Aggregate::_duplicate( Aggregate_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KOM::Aggregate::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KOM/Aggregate:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = Component::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KOM::Aggregate::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KOM/Aggregate:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KOM::Aggregate_ptr KOM::Aggregate::_narrow( CORBA::Object_ptr _obj )
{
  KOM::Aggregate_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KOM/Aggregate:1.0" )))
      return _duplicate( (KOM::Aggregate_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KOM::Aggregate_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KOM/Aggregate:1.0" ) ) {
      _o = new KOM::Aggregate_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KOM::Aggregate_ptr KOM::Aggregate::_nil()
{
  return NULL;
}

KOM::Aggregate_stub::~Aggregate_stub()
{
}

struct _global_init_KOM_Aggregate {
  _global_init_KOM_Aggregate()
  {
    if( ::KOM::Component::_narrow_helpers == NULL )
      ::KOM::Component::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::KOM::Component::_narrow_helpers->push_back( KOM::Aggregate::_narrow_helper2 );
  }
} __global_init_KOM_Aggregate;

#ifdef HAVE_NAMESPACE
namespace KOM { vector<CORBA::Narrow_proto> * Aggregate::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KOM::Aggregate::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_Aggregate; };
#else
CORBA::TypeCodeConst KOM::_tc_Aggregate;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KOM::Aggregate_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "Aggregate" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KOM::Aggregate_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KOM::Aggregate::_nil();
    return TRUE;
  }
  _obj = ::KOM::Aggregate::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}


// Stub interface AggregateFactory
KOM::AggregateFactory::~AggregateFactory()
{
}

KOM::AggregateFactory_ptr KOM::AggregateFactory::_duplicate( AggregateFactory_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KOM::AggregateFactory::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KOM/AggregateFactory:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = ComponentFactory::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KOM::AggregateFactory::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KOM/AggregateFactory:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KOM::AggregateFactory_ptr KOM::AggregateFactory::_narrow( CORBA::Object_ptr _obj )
{
  KOM::AggregateFactory_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KOM/AggregateFactory:1.0" )))
      return _duplicate( (KOM::AggregateFactory_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KOM::AggregateFactory_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KOM/AggregateFactory:1.0" ) ) {
      _o = new KOM::AggregateFactory_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KOM::AggregateFactory_ptr KOM::AggregateFactory::_nil()
{
  return NULL;
}

KOM::AggregateFactory_stub::~AggregateFactory_stub()
{
}

KOM::Aggregate_ptr KOM::AggregateFactory_stub::create( KOM::Component_ptr core )
{
  CORBA::Request_var _req = this->_request( "create" );
  _req->add_in_arg( "core" ) <<= (KOM::Component_ptr) core;
  _req->result()->value()->type( KOM::_tc_Aggregate );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::Aggregate_ptr _res;
  *_req->result()->value() >>= (KOM::Aggregate_ptr&) _res;
  return _res;
}


struct _global_init_KOM_AggregateFactory {
  _global_init_KOM_AggregateFactory()
  {
    if( ::KOM::ComponentFactory::_narrow_helpers == NULL )
      ::KOM::ComponentFactory::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::KOM::ComponentFactory::_narrow_helpers->push_back( KOM::AggregateFactory::_narrow_helper2 );
  }
} __global_init_KOM_AggregateFactory;

#ifdef HAVE_NAMESPACE
namespace KOM { vector<CORBA::Narrow_proto> * AggregateFactory::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KOM::AggregateFactory::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_AggregateFactory; };
#else
CORBA::TypeCodeConst KOM::_tc_AggregateFactory;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KOM::AggregateFactory_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "AggregateFactory" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KOM::AggregateFactory_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KOM::AggregateFactory::_nil();
    return TRUE;
  }
  _obj = ::KOM::AggregateFactory::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}


// Stub interface Plugin
KOM::Plugin::~Plugin()
{
}

KOM::Plugin_ptr KOM::Plugin::_duplicate( Plugin_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KOM::Plugin::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KOM/Plugin:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = Component::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KOM::Plugin::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KOM/Plugin:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KOM::Plugin_ptr KOM::Plugin::_narrow( CORBA::Object_ptr _obj )
{
  KOM::Plugin_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KOM/Plugin:1.0" )))
      return _duplicate( (KOM::Plugin_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KOM::Plugin_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KOM/Plugin:1.0" ) ) {
      _o = new KOM::Plugin_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KOM::Plugin_ptr KOM::Plugin::_nil()
{
  return NULL;
}

KOM::Plugin_stub::~Plugin_stub()
{
}

struct _global_init_KOM_Plugin {
  _global_init_KOM_Plugin()
  {
    if( ::KOM::Component::_narrow_helpers == NULL )
      ::KOM::Component::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::KOM::Component::_narrow_helpers->push_back( KOM::Plugin::_narrow_helper2 );
  }
} __global_init_KOM_Plugin;

#ifdef HAVE_NAMESPACE
namespace KOM { vector<CORBA::Narrow_proto> * Plugin::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KOM::Plugin::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_Plugin; };
#else
CORBA::TypeCodeConst KOM::_tc_Plugin;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KOM::Plugin_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "Plugin" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KOM::Plugin_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KOM::Plugin::_nil();
    return TRUE;
  }
  _obj = ::KOM::Plugin::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}


// Stub interface PluginFactory
KOM::PluginFactory::~PluginFactory()
{
}

KOM::PluginFactory_ptr KOM::PluginFactory::_duplicate( PluginFactory_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KOM::PluginFactory::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KOM/PluginFactory:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = ComponentFactory::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KOM::PluginFactory::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KOM/PluginFactory:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KOM::PluginFactory_ptr KOM::PluginFactory::_narrow( CORBA::Object_ptr _obj )
{
  KOM::PluginFactory_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KOM/PluginFactory:1.0" )))
      return _duplicate( (KOM::PluginFactory_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KOM::PluginFactory_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KOM/PluginFactory:1.0" ) ) {
      _o = new KOM::PluginFactory_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KOM::PluginFactory_ptr KOM::PluginFactory::_nil()
{
  return NULL;
}

KOM::PluginFactory_stub::~PluginFactory_stub()
{
}

KOM::Plugin_ptr KOM::PluginFactory_stub::create( KOM::Component_ptr core )
{
  CORBA::Request_var _req = this->_request( "create" );
  _req->add_in_arg( "core" ) <<= (KOM::Component_ptr) core;
  _req->result()->value()->type( KOM::_tc_Plugin );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
  KOM::Plugin_ptr _res;
  *_req->result()->value() >>= (KOM::Plugin_ptr&) _res;
  return _res;
}


struct _global_init_KOM_PluginFactory {
  _global_init_KOM_PluginFactory()
  {
    if( ::KOM::ComponentFactory::_narrow_helpers == NULL )
      ::KOM::ComponentFactory::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::KOM::ComponentFactory::_narrow_helpers->push_back( KOM::PluginFactory::_narrow_helper2 );
  }
} __global_init_KOM_PluginFactory;

#ifdef HAVE_NAMESPACE
namespace KOM { vector<CORBA::Narrow_proto> * PluginFactory::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KOM::PluginFactory::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KOM { CORBA::TypeCodeConst _tc_PluginFactory; };
#else
CORBA::TypeCodeConst KOM::_tc_PluginFactory;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KOM::PluginFactory_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "PluginFactory" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KOM::PluginFactory_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KOM::PluginFactory::_nil();
    return TRUE;
  }
  _obj = ::KOM::PluginFactory::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}

CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Base::Connection> &_s )
{
  static CORBA::TypeCodeConst _tc =
    "0100000013000000b0000000010000000f000000a0000000010000001c00"
    "000049444c3a4b4f4d2f426173652f436f6e6e656374696f6e3a312e3000"
    "0b000000436f6e6e656374696f6e00000300000004000000736967001200"
    "000000000000090000007265636569766572000000000e00000025000000"
    "010000001100000049444c3a4b4f4d2f426173653a312e30000000000500"
    "000042617365000000000900000066756e6374696f6e0000000012000000"
    "0000000000000000";
  _a.type( _tc );
  if( !_a.seq_put_begin( _s.length() ) )
    return FALSE;
  for( CORBA::ULong _i = 0; _i < _s.length(); _i++ )
    if( !(_a <<= ((SequenceTmpl<KOM::Base::Connection>&)_s)[ _i ]) )
      return FALSE;
  return _a.seq_put_end();
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Base::Connection> &_s )
{
  CORBA::ULong _len;

  if( !_a.seq_get_begin( _len ) )
    return FALSE;
  _s.length( _len );
  for( CORBA::ULong _i = 0; _i < _len; _i++ )
    if( !(_a >>= _s[ _i ]) )
      return FALSE;
  return _a.seq_get_end();
}


CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Base::EventFilter> &_s )
{
  static CORBA::TypeCodeConst _tc =
    "010000001300000050010000010000000f00000040010000010000001d00"
    "000049444c3a4b4f4d2f426173652f4576656e7446696c7465723a312e30"
    "000000000c0000004576656e7446696c7465720003000000090000007265"
    "636569766572000000000e00000025000000010000001100000049444c3a"
    "4b4f4d2f426173653a312e30000000000500000042617365000000000900"
    "000066756e6374696f6e000000001200000000000000070000006576656e"
    "747300001500000098000000010000001900000049444c3a4b4f4d2f4576"
    "656e74547970655365713a312e30000000000d0000004576656e74547970"
    "655365710000000013000000580000000100000015000000480000000100"
    "00001d00000049444c3a4b4f4d2f4576656e74547970655061747465726e"
    "3a312e3000000000110000004576656e74547970655061747465726e0000"
    "000012000000000000000000000000000000";
  _a.type( _tc );
  if( !_a.seq_put_begin( _s.length() ) )
    return FALSE;
  for( CORBA::ULong _i = 0; _i < _s.length(); _i++ )
    if( !(_a <<= ((SequenceTmpl<KOM::Base::EventFilter>&)_s)[ _i ]) )
      return FALSE;
  return _a.seq_put_end();
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Base::EventFilter> &_s )
{
  CORBA::ULong _len;

  if( !_a.seq_get_begin( _len ) )
    return FALSE;
  _s.length( _len );
  for( CORBA::ULong _i = 0; _i < _len; _i++ )
    if( !(_a >>= _s[ _i ]) )
      return FALSE;
  return _a.seq_get_end();
}


CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Base_var> &_s )
{
  static CORBA::TypeCodeConst _tc =
    "010000001300000038000000010000000e00000025000000010000001100"
    "000049444c3a4b4f4d2f426173653a312e30000000000500000042617365"
    "0000000000000000";
  _a.type( _tc );
  if( !_a.seq_put_begin( _s.length() ) )
    return FALSE;
  for( CORBA::ULong _i = 0; _i < _s.length(); _i++ )
    if( !(_a <<= (KOM::Base_ptr) ((SequenceTmpl<KOM::Base_var>&)_s)[ _i ]) )
      return FALSE;
  return _a.seq_put_end();
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Base_var> &_s )
{
  CORBA::ULong _len;

  if( !_a.seq_get_begin( _len ) )
    return FALSE;
  _s.length( _len );
  for( CORBA::ULong _i = 0; _i < _len; _i++ )
    if( !(_a >>= (KOM::Base_ptr&) _s[ _i ]) )
      return FALSE;
  return _a.seq_get_end();
}


CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Member> &_s )
{
  static CORBA::TypeCodeConst _tc =
    "010000001300000088000000010000000f00000078000000010000001300"
    "000049444c3a4b4f4d2f4d656d6265723a312e300000070000004d656d62"
    "6572000002000000040000006f626a000e00000025000000010000001100"
    "000049444c3a4b4f4d2f426173653a312e30000000000500000042617365"
    "00000000050000006e616d6500000000120000000000000000000000";
  _a.type( _tc );
  if( !_a.seq_put_begin( _s.length() ) )
    return FALSE;
  for( CORBA::ULong _i = 0; _i < _s.length(); _i++ )
    if( !(_a <<= ((SequenceTmpl<KOM::Member>&)_s)[ _i ]) )
      return FALSE;
  return _a.seq_put_end();
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Member> &_s )
{
  CORBA::ULong _len;

  if( !_a.seq_get_begin( _len ) )
    return FALSE;
  _s.length( _len );
  for( CORBA::ULong _i = 0; _i < _len; _i++ )
    if( !(_a >>= _s[ _i ]) )
      return FALSE;
  return _a.seq_get_end();
}


CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Component::PluginInfo> &_s )
{
  static CORBA::TypeCodeConst _tc =
    "010000001300000040010000010000000f00000030010000010000002100"
    "000049444c3a4b4f4d2f436f6d706f6e656e742f506c7567696e496e666f"
    "3a312e30000000000b000000506c7567696e496e666f0000030000000b00"
    "0000696e7465726661636573000015000000900000000100000019000000"
    "49444c3a4b4f4d2f496e746572666163655365713a312e30000000000d00"
    "0000496e7465726661636553657100000000130000005000000001000000"
    "1500000040000000010000001a00000049444c3a4b4f4d2f496e74657266"
    "6163654e616d653a312e300000000e000000496e746572666163654e616d"
    "650000001200000000000000000000000300000069640000150000002400"
    "0000010000000f00000049444c3a4b4f4d2f49443a312e30000003000000"
    "494400000300000009000000636f6d706f73656400000000080000000000"
    "0000";
  _a.type( _tc );
  if( !_a.seq_put_begin( _s.length() ) )
    return FALSE;
  for( CORBA::ULong _i = 0; _i < _s.length(); _i++ )
    if( !(_a <<= ((SequenceTmpl<KOM::Component::PluginInfo>&)_s)[ _i ]) )
      return FALSE;
  return _a.seq_put_end();
}

CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Component::PluginInfo> &_s )
{
  CORBA::ULong _len;

  if( !_a.seq_get_begin( _len ) )
    return FALSE;
  _s.length( _len );
  for( CORBA::ULong _i = 0; _i < _len; _i++ )
    if( !(_a >>= _s[ _i ]) )
      return FALSE;
  return _a.seq_get_end();
}


struct __tc_init_KOM {
  __tc_init_KOM()
  {
    KOM::_tc_EventType = "010000001500000038000000010000001600000049444c3a4b4f4d2f4576"
    "656e74547970653a312e300000000a0000004576656e7454797065000000"
    "1200000000000000";
    KOM::_tc_EventTypePattern = "010000001500000048000000010000001d00000049444c3a4b4f4d2f4576"
    "656e74547970655061747465726e3a312e3000000000110000004576656e"
    "74547970655061747465726e000000001200000000000000";
    KOM::_tc_EventTypeSeq = "010000001500000098000000010000001900000049444c3a4b4f4d2f4576"
    "656e74547970655365713a312e30000000000d0000004576656e74547970"
    "655365710000000013000000580000000100000015000000480000000100"
    "00001d00000049444c3a4b4f4d2f4576656e74547970655061747465726e"
    "3a312e3000000000110000004576656e74547970655061747465726e0000"
    "0000120000000000000000000000";
    KOM::Base::_tc_UnknownSignal = "010000001600000040000000010000001f00000049444c3a4b4f4d2f4261"
    "73652f556e6b6e6f776e5369676e616c3a312e3000000e000000556e6b6e"
    "6f776e5369676e616c00000000000000";
    KOM::Base::_tc_Connection = "010000000f000000a0000000010000001c00000049444c3a4b4f4d2f4261"
    "73652f436f6e6e656374696f6e3a312e30000b000000436f6e6e65637469"
    "6f6e00000300000004000000736967001200000000000000090000007265"
    "636569766572000000000e00000025000000010000001100000049444c3a"
    "4b4f4d2f426173653a312e30000000000500000042617365000000000900"
    "000066756e6374696f6e000000001200000000000000";
    KOM::Base::_tc_ConnectionSeq = "0100000015000000f4000000010000001f00000049444c3a4b4f4d2f4261"
    "73652f436f6e6e656374696f6e5365713a312e3000000e000000436f6e6e"
    "656374696f6e53657100000013000000b0000000010000000f000000a000"
    "0000010000001c00000049444c3a4b4f4d2f426173652f436f6e6e656374"
    "696f6e3a312e30000b000000436f6e6e656374696f6e0000030000000400"
    "000073696700120000000000000009000000726563656976657200000000"
    "0e00000025000000010000001100000049444c3a4b4f4d2f426173653a31"
    "2e30000000000500000042617365000000000900000066756e6374696f6e"
    "00000000120000000000000000000000";
    KOM::Base::_tc_EventFilter = "010000000f00000040010000010000001d00000049444c3a4b4f4d2f4261"
    "73652f4576656e7446696c7465723a312e30000000000c0000004576656e"
    "7446696c7465720003000000090000007265636569766572000000000e00"
    "000025000000010000001100000049444c3a4b4f4d2f426173653a312e30"
    "000000000500000042617365000000000900000066756e6374696f6e0000"
    "00001200000000000000070000006576656e747300001500000098000000"
    "010000001900000049444c3a4b4f4d2f4576656e74547970655365713a31"
    "2e30000000000d0000004576656e74547970655365710000000013000000"
    "58000000010000001500000048000000010000001d00000049444c3a4b4f"
    "4d2f4576656e74547970655061747465726e3a312e300000000011000000"
    "4576656e74547970655061747465726e0000000012000000000000000000"
    "0000";
    KOM::Base::_tc_EventFilterSeq = "010000001500000094010000010000002000000049444c3a4b4f4d2f4261"
    "73652f4576656e7446696c7465725365713a312e30000f0000004576656e"
    "7446696c74657253657100001300000050010000010000000f0000004001"
    "0000010000001d00000049444c3a4b4f4d2f426173652f4576656e744669"
    "6c7465723a312e30000000000c0000004576656e7446696c746572000300"
    "0000090000007265636569766572000000000e0000002500000001000000"
    "1100000049444c3a4b4f4d2f426173653a312e3000000000050000004261"
    "7365000000000900000066756e6374696f6e000000001200000000000000"
    "070000006576656e74730000150000009800000001000000190000004944"
    "4c3a4b4f4d2f4576656e74547970655365713a312e30000000000d000000"
    "4576656e7454797065536571000000001300000058000000010000001500"
    "000048000000010000001d00000049444c3a4b4f4d2f4576656e74547970"
    "655061747465726e3a312e3000000000110000004576656e745479706550"
    "61747465726e0000000012000000000000000000000000000000";
    KOM::Base::_tc_FilterMode = "010000001100000068000000010000001c00000049444c3a4b4f4d2f4261"
    "73652f46696c7465724d6f64653a312e30000b00000046696c7465724d6f"
    "646500000300000009000000464d5f5752495445000000000d000000464d"
    "5f494d504c454d454e540000000008000000464d5f5245414400";
    KOM::Base::_tc_RelativesSeq = "01000000150000007c000000010000001e00000049444c3a4b4f4d2f4261"
    "73652f52656c6174697665735365713a312e300000000d00000052656c61"
    "7469766573536571000000001300000038000000010000000e0000002500"
    "0000010000001100000049444c3a4b4f4d2f426173653a312e3000000000"
    "05000000426173650000000000000000";
    KOM::_tc_Base = "010000000e00000025000000010000001100000049444c3a4b4f4d2f4261"
    "73653a312e3000000000050000004261736500";
    KOM::_tc_Member = "010000000f00000078000000010000001300000049444c3a4b4f4d2f4d65"
    "6d6265723a312e300000070000004d656d62657200000200000004000000"
    "6f626a000e00000025000000010000001100000049444c3a4b4f4d2f4261"
    "73653a312e3000000000050000004261736500000000050000006e616d65"
    "000000001200000000000000";
    KOM::_tc_MemberSeq = "0100000015000000c0000000010000001600000049444c3a4b4f4d2f4d65"
    "6d6265725365713a312e300000000a0000004d656d626572536571000000"
    "1300000088000000010000000f0000007800000001000000130000004944"
    "4c3a4b4f4d2f4d656d6265723a312e300000070000004d656d6265720000"
    "02000000040000006f626a000e0000002500000001000000110000004944"
    "4c3a4b4f4d2f426173653a312e3000000000050000004261736500000000"
    "050000006e616d6500000000120000000000000000000000";
    KOM::_tc_UnknownMember = "010000001600000050000000010000001a00000049444c3a4b4f4d2f556e"
    "6b6e6f776e4d656d6265723a312e300000000e000000556e6b6e6f776e4d"
    "656d62657200000001000000050000006e616d6500000000120000000000"
    "0000";
    KOM::_tc_DuplicateMember = "010000001600000050000000010000001c00000049444c3a4b4f4d2f4475"
    "706c69636174654d656d6265723a312e3000100000004475706c69636174"
    "654d656d6265720001000000050000006e616d6500000000120000000000"
    "0000";
    KOM::_tc_Container = "010000000e0000002e000000010000001600000049444c3a4b4f4d2f436f"
    "6e7461696e65723a312e300000000a000000436f6e7461696e657200";
    KOM::_tc_InterfaceName = "010000001500000040000000010000001a00000049444c3a4b4f4d2f496e"
    "746572666163654e616d653a312e300000000e000000496e746572666163"
    "654e616d650000001200000000000000";
    KOM::_tc_InterfaceSeq = "010000001500000090000000010000001900000049444c3a4b4f4d2f496e"
    "746572666163655365713a312e30000000000d000000496e746572666163"
    "655365710000000013000000500000000100000015000000400000000100"
    "00001a00000049444c3a4b4f4d2f496e746572666163654e616d653a312e"
    "300000000e000000496e746572666163654e616d65000000120000000000"
    "000000000000";
    KOM::_tc_InterfaceAlreadySupported = "0100000016000000a8000000010000002600000049444c3a4b4f4d2f496e"
    "74657266616365416c7265616479537570706f727465643a312e30000000"
    "1a000000496e74657266616365416c7265616479537570706f7274656400"
    "000001000000060000006966616365000000150000004000000001000000"
    "1a00000049444c3a4b4f4d2f496e746572666163654e616d653a312e3000"
    "00000e000000496e746572666163654e616d650000001200000000000000"
    ;
    KOM::_tc_InterfaceNotFound = "010000001600000044000000010000001e00000049444c3a4b4f4d2f496e"
    "746572666163654e6f74466f756e643a312e3000000012000000496e7465"
    "72666163654e6f74466f756e6400000000000000";
    KOM::_tc_ID = "010000001500000024000000010000000f00000049444c3a4b4f4d2f4944"
    "3a312e300000030000004944000003000000";
    KOM::_tc_UnknownID = "010000001600000068000000010000001600000049444c3a4b4f4d2f556e"
    "6b6e6f776e49443a312e300000000a000000556e6b6e6f776e4944000000"
    "0100000003000000696400001500000024000000010000000f0000004944"
    "4c3a4b4f4d2f49443a312e300000030000004944000003000000";
    KOM::Component::_tc_PluginInfo = "010000000f00000030010000010000002100000049444c3a4b4f4d2f436f"
    "6d706f6e656e742f506c7567696e496e666f3a312e30000000000b000000"
    "506c7567696e496e666f0000030000000b000000696e7465726661636573"
    "00001500000090000000010000001900000049444c3a4b4f4d2f496e7465"
    "72666163655365713a312e30000000000d000000496e7465726661636553"
    "657100000000130000005000000001000000150000004000000001000000"
    "1a00000049444c3a4b4f4d2f496e746572666163654e616d653a312e3000"
    "00000e000000496e746572666163654e616d650000001200000000000000"
    "0000000003000000696400001500000024000000010000000f0000004944"
    "4c3a4b4f4d2f49443a312e30000003000000494400000300000009000000"
    "636f6d706f7365640000000008000000";
    KOM::Component::_tc_PluginInfoSeq = "010000001500000088010000010000002400000049444c3a4b4f4d2f436f"
    "6d706f6e656e742f506c7567696e496e666f5365713a312e30000e000000"
    "506c7567696e496e666f5365710000001300000040010000010000000f00"
    "000030010000010000002100000049444c3a4b4f4d2f436f6d706f6e656e"
    "742f506c7567696e496e666f3a312e30000000000b000000506c7567696e"
    "496e666f0000030000000b000000696e7465726661636573000015000000"
    "90000000010000001900000049444c3a4b4f4d2f496e7465726661636553"
    "65713a312e30000000000d000000496e7465726661636553657100000000"
    "1300000050000000010000001500000040000000010000001a0000004944"
    "4c3a4b4f4d2f496e746572666163654e616d653a312e300000000e000000"
    "496e746572666163654e616d650000001200000000000000000000000300"
    "0000696400001500000024000000010000000f00000049444c3a4b4f4d2f"
    "49443a312e30000003000000494400000300000009000000636f6d706f73"
    "6564000000000800000000000000";
    KOM::_tc_Component = "010000000e0000002e000000010000001600000049444c3a4b4f4d2f436f"
    "6d706f6e656e743a312e300000000a000000436f6d706f6e656e7400";
    KOM::_tc_ComponentFactory = "010000000e0000003d000000010000001d00000049444c3a4b4f4d2f436f"
    "6d706f6e656e74466163746f72793a312e300000000011000000436f6d70"
    "6f6e656e74466163746f727900";
    KOM::_tc_Application = "010000000e00000030000000010000001800000049444c3a4b4f4d2f4170"
    "706c69636174696f6e3a312e30000c0000004170706c69636174696f6e00"
    ;
    KOM::_tc_Aggregate = "010000000e0000002e000000010000001600000049444c3a4b4f4d2f4167"
    "677265676174653a312e300000000a00000041676772656761746500";
    KOM::_tc_AggregateFactory = "010000000e0000003d000000010000001d00000049444c3a4b4f4d2f4167"
    "67726567617465466163746f72793a312e30000000001100000041676772"
    "6567617465466163746f727900";
    KOM::_tc_Plugin = "010000000e00000027000000010000001300000049444c3a4b4f4d2f506c"
    "7567696e3a312e30000007000000506c7567696e00";
    KOM::_tc_PluginFactory = "010000000e00000036000000010000001a00000049444c3a4b4f4d2f506c"
    "7567696e466163746f72793a312e300000000e000000506c7567696e4661"
    "63746f727900";
  }
};

static __tc_init_KOM __init_KOM;

//--------------------------------------------------------
//  Implementation of skeletons
//--------------------------------------------------------

// Dynamic Implementation Routine for interface Base
KOM::Base_skel::Base_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Base:1.0", "Base" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KOM/Base:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<Base_skel>( this ) );
}

KOM::Base_skel::Base_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Base:1.0", "Base" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<Base_skel>( this ) );
}

KOM::Base_skel::~Base_skel()
{
}

bool KOM::Base_skel::dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment & /*_env*/ )
{
  if( strcmp( _req->op_name(), "connect" ) == 0 ) {
    CORBA::String_var sig;
    ::KOM::Base_var obj;
    CORBA::String_var function;

    CORBA::NVList_ptr _args = new CORBA::NVList (3);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( CORBA::_tc_string );
    _args->add( CORBA::ARG_IN );
    _args->item( 1 )->value()->type( KOM::_tc_Base );
    _args->add( CORBA::ARG_IN );
    _args->item( 2 )->value()->type( CORBA::_tc_string );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( sig, 0 );
    *_args->item( 1 )->value() >>= (::KOM::Base_ptr&) obj;
    *_args->item( 2 )->value() >>= CORBA::Any::to_string( function, 0 );
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      connect( sig, obj, function );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "disconnect" ) == 0 ) {
    CORBA::String_var sig;
    ::KOM::Base_var obj;
    CORBA::String_var function;

    CORBA::NVList_ptr _args = new CORBA::NVList (3);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( CORBA::_tc_string );
    _args->add( CORBA::ARG_IN );
    _args->item( 1 )->value()->type( KOM::_tc_Base );
    _args->add( CORBA::ARG_IN );
    _args->item( 2 )->value()->type( CORBA::_tc_string );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( sig, 0 );
    *_args->item( 1 )->value() >>= (::KOM::Base_ptr&) obj;
    *_args->item( 2 )->value() >>= CORBA::Any::to_string( function, 0 );
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      disconnect( sig, obj, function );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "disconnectSignalNotify" ) == 0 ) {
    ::KOM::Base_var obj;
    CORBA::String_var sig;
    CORBA::String_var function;

    CORBA::NVList_ptr _args = new CORBA::NVList (3);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );
    _args->add( CORBA::ARG_IN );
    _args->item( 1 )->value()->type( CORBA::_tc_string );
    _args->add( CORBA::ARG_IN );
    _args->item( 2 )->value()->type( CORBA::_tc_string );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    *_args->item( 1 )->value() >>= CORBA::Any::to_string( sig, 0 );
    *_args->item( 2 )->value() >>= CORBA::Any::to_string( function, 0 );
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      disconnectSignalNotify( obj, sig, function );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "describeConnections" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    ConnectionSeq* _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = describeConnections();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= *_res;
    delete _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "connectNotify" ) == 0 ) {
    ::KOM::Base_var obj;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      connectNotify( obj );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "disconnectNotify" ) == 0 ) {
    ::KOM::Base_var obj;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      disconnectNotify( obj );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "receiveASync" ) == 0 ) {
    EventType_var type;
    CORBA::Any value;

    CORBA::NVList_ptr _args = new CORBA::NVList (2);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_EventType );
    _args->add( CORBA::ARG_IN );
    _args->item( 1 )->value()->type( CORBA::_tc_any );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( type, 0 );
    *_args->item( 1 )->value() >>= value;
    receiveASync( type, value );
    return true;
  }
  if( strcmp( _req->op_name(), "receive" ) == 0 ) {
    EventType_var type;
    CORBA::Any value;

    CORBA::NVList_ptr _args = new CORBA::NVList (2);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_EventType );
    _args->add( CORBA::ARG_IN );
    _args->item( 1 )->value()->type( CORBA::_tc_any );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( type, 0 );
    *_args->item( 1 )->value() >>= value;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      receive( type, value );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "eventFilter" ) == 0 ) {
    ::KOM::Base_var obj;
    EventType_var type;
    CORBA::Any value;

    CORBA::NVList_ptr _args = new CORBA::NVList (3);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );
    _args->add( CORBA::ARG_IN );
    _args->item( 1 )->value()->type( KOM::_tc_EventType );
    _args->add( CORBA::ARG_IN );
    _args->item( 2 )->value()->type( CORBA::_tc_any );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    *_args->item( 1 )->value() >>= CORBA::Any::to_string( type, 0 );
    *_args->item( 2 )->value() >>= value;
    CORBA::Boolean _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = eventFilter( obj, type, value );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= CORBA::Any::from_boolean( _res );
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "installFilter" ) == 0 ) {
    ::KOM::Base_var obj;
    CORBA::String_var function;
    EventTypeSeq events;
    FilterMode mode;

    CORBA::NVList_ptr _args = new CORBA::NVList (4);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );
    _args->add( CORBA::ARG_IN );
    _args->item( 1 )->value()->type( CORBA::_tc_string );
    _args->add( CORBA::ARG_IN );
    _args->item( 2 )->value()->type( KOM::_tc_EventTypeSeq );
    _args->add( CORBA::ARG_IN );
    _args->item( 3 )->value()->type( KOM::Base::_tc_FilterMode );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    *_args->item( 1 )->value() >>= CORBA::Any::to_string( function, 0 );
    *_args->item( 2 )->value() >>= events;
    *_args->item( 3 )->value() >>= mode;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      installFilter( obj, function, events, mode );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "uninstallFilter" ) == 0 ) {
    ::KOM::Base_var obj;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      uninstallFilter( obj );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "disconnectFilterNotify" ) == 0 ) {
    ::KOM::Base_var obj;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      disconnectFilterNotify( obj );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "describeEventFilters" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    EventFilterSeq* _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = describeEventFilters();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= *_res;
    delete _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "adopt" ) == 0 ) {
    ::KOM::Base_var obj;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      adopt( obj );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "adoptNotify" ) == 0 ) {
    ::KOM::Base_var obj;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      adoptNotify( obj );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "leave" ) == 0 ) {
    ::KOM::Base_var obj;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      leave( obj );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "leaveNotify" ) == 0 ) {
    ::KOM::Base_var obj;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      leaveNotify( obj );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "describeRelatives" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    RelativesSeq* _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = describeRelatives();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= *_res;
    delete _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "incRef" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      incRef();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "decRef" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      decRef();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "refCount" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    CORBA::ULong _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = refCount();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "destroy" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      destroy();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "disconnectObject" ) == 0 ) {
    ::KOM::Base_var obj;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Base );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (::KOM::Base_ptr&) obj;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      disconnectObject( obj );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "disconnectAll" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      disconnectAll();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  return false;
}

KOM::Base_ptr KOM::Base_skel::_this()
{
  return KOM::Base::_duplicate( this );
}


// Dynamic Implementation Routine for interface Container
KOM::Container_skel::Container_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Container:1.0", "Container" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KOM/Container:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<Container_skel>( this ) );
}

KOM::Container_skel::Container_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Container:1.0", "Container" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<Container_skel>( this ) );
}

KOM::Container_skel::~Container_skel()
{
}

bool KOM::Container_skel::dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment & /*_env*/ )
{
  if( strcmp( _req->op_name(), "addContainee" ) == 0 ) {
    Member memb;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Member );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= memb;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      addContainee( memb );
    #ifdef HAVE_EXCEPTIONS
    } catch( ::KOM::DuplicateMember_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "removeContainee" ) == 0 ) {
    CORBA::String_var name;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( CORBA::_tc_string );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( name, 0 );
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      removeContainee( name );
    #ifdef HAVE_EXCEPTIONS
    } catch( ::KOM::UnknownMember_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "replaceContainee" ) == 0 ) {
    Member member;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Member );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= member;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      replaceContainee( member );
    #ifdef HAVE_EXCEPTIONS
    } catch( ::KOM::UnknownMember_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "clear" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      clear();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "listContainees" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    MemberSeq* _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = listContainees();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= *_res;
    delete _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "lookupContainee" ) == 0 ) {
    CORBA::String_var name;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( CORBA::_tc_string );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( name, 0 );
    Base_ptr _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = lookupContainee( name );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= (Base_ptr) _res;
    CORBA::release( _res );
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "containeeAdded" ) == 0 ) {
    Member memb;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Member );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= memb;
    containeeAdded( memb );
    return true;
  }
  if( strcmp( _req->op_name(), "containeeRemoved" ) == 0 ) {
    Member memb;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Member );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= memb;
    containeeRemoved( memb );
    return true;
  }
  return false;
}

KOM::Container_ptr KOM::Container_skel::_this()
{
  return KOM::Container::_duplicate( this );
}


// Dynamic Implementation Routine for interface Component
KOM::Component_skel::Component_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Component:1.0", "Component" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KOM/Component:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<Component_skel>( this ) );
}

KOM::Component_skel::Component_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Component:1.0", "Component" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<Component_skel>( this ) );
}

KOM::Component_skel::~Component_skel()
{
}

bool KOM::Component_skel::dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment & /*_env*/ )
{
  if( strcmp( _req->op_name(), "getInterface" ) == 0 ) {
    InterfaceName_var name;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_InterfaceName );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( name, 0 );
    CORBA::Object_ptr _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = getInterface( name );
    #ifdef HAVE_EXCEPTIONS
    } catch( ::KOM::InterfaceNotFound_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= CORBA::Any::from_object( _res, "Object" );
    CORBA::release( _res );
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "interfaces" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    InterfaceSeq* _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = interfaces();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= *_res;
    delete _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "supportsInterface" ) == 0 ) {
    InterfaceName_var name;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_InterfaceName );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( name, 0 );
    CORBA::Boolean _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = supportsInterface( name );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= CORBA::Any::from_boolean( _res );
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "addAggregate" ) == 0 ) {
    AggregateFactory_var factory;
    InterfaceSeq required;
    InterfaceSeq provided;
    CORBA::Boolean activate;

    CORBA::NVList_ptr _args = new CORBA::NVList (4);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_AggregateFactory );
    _args->add( CORBA::ARG_IN );
    _args->item( 1 )->value()->type( KOM::_tc_InterfaceSeq );
    _args->add( CORBA::ARG_IN );
    _args->item( 2 )->value()->type( KOM::_tc_InterfaceSeq );
    _args->add( CORBA::ARG_IN );
    _args->item( 3 )->value()->type( CORBA::_tc_boolean );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (AggregateFactory_ptr&) factory;
    *_args->item( 1 )->value() >>= required;
    *_args->item( 2 )->value() >>= provided;
    *_args->item( 3 )->value() >>= CORBA::Any::to_boolean( activate );
    ID _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = addAggregate( factory, required, provided, activate );
    #ifdef HAVE_EXCEPTIONS
    } catch( ::KOM::InterfaceAlreadySupported_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "removeAggregate" ) == 0 ) {
    ID id;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_ID );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= id;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      removeAggregate( id );
    #ifdef HAVE_EXCEPTIONS
    } catch( ::KOM::UnknownID_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "addPlugin" ) == 0 ) {
    PluginFactory_var factory;
    InterfaceSeq required;
    InterfaceSeq required_plugins;
    InterfaceSeq provided;
    CORBA::Boolean activate;

    CORBA::NVList_ptr _args = new CORBA::NVList (5);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_PluginFactory );
    _args->add( CORBA::ARG_IN );
    _args->item( 1 )->value()->type( KOM::_tc_InterfaceSeq );
    _args->add( CORBA::ARG_IN );
    _args->item( 2 )->value()->type( KOM::_tc_InterfaceSeq );
    _args->add( CORBA::ARG_IN );
    _args->item( 3 )->value()->type( KOM::_tc_InterfaceSeq );
    _args->add( CORBA::ARG_IN );
    _args->item( 4 )->value()->type( CORBA::_tc_boolean );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (PluginFactory_ptr&) factory;
    *_args->item( 1 )->value() >>= required;
    *_args->item( 2 )->value() >>= required_plugins;
    *_args->item( 3 )->value() >>= provided;
    *_args->item( 4 )->value() >>= CORBA::Any::to_boolean( activate );
    ID _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = addPlugin( factory, required, required_plugins, provided, activate );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "removePlugin" ) == 0 ) {
    ID id;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_ID );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= id;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      removePlugin( id );
    #ifdef HAVE_EXCEPTIONS
    } catch( ::KOM::UnknownID_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "getPluginInterface" ) == 0 ) {
    InterfaceName_var name;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_InterfaceName );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( name, 0 );
    CORBA::Object_ptr _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = getPluginInterface( name );
    #ifdef HAVE_EXCEPTIONS
    } catch( ::KOM::InterfaceNotFound_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= CORBA::Any::from_object( _res, "Object" );
    CORBA::release( _res );
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "pluginInterfaces" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    InterfaceSeq* _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = pluginInterfaces();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= *_res;
    delete _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "supportsPluginInterface" ) == 0 ) {
    InterfaceName_var name;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_InterfaceName );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( name, 0 );
    CORBA::Boolean _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = supportsPluginInterface( name );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= CORBA::Any::from_boolean( _res );
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "describePlugins" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    PluginInfoSeq* _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = describePlugins();
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= *_res;
    delete _res;
    _req->result( _any_res );
    return true;
  }
  if( strcmp( _req->op_name(), "getPlugin" ) == 0 ) {
    ID id;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_ID );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= id;
    Plugin_ptr _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = getPlugin( id );
    #ifdef HAVE_EXCEPTIONS
    } catch( ::KOM::UnknownID_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= (Plugin_ptr) _res;
    CORBA::release( _res );
    _req->result( _any_res );
    return true;
  }
  return false;
}

KOM::Component_ptr KOM::Component_skel::_this()
{
  return KOM::Component::_duplicate( this );
}


// Dynamic Implementation Routine for interface ComponentFactory
KOM::ComponentFactory_skel::ComponentFactory_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/ComponentFactory:1.0", "ComponentFactory" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KOM/ComponentFactory:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<ComponentFactory_skel>( this ) );
}

KOM::ComponentFactory_skel::ComponentFactory_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/ComponentFactory:1.0", "ComponentFactory" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<ComponentFactory_skel>( this ) );
}

KOM::ComponentFactory_skel::~ComponentFactory_skel()
{
}

bool KOM::ComponentFactory_skel::dispatch( CORBA::ServerRequest_ptr /*_req*/, CORBA::Environment & /*_env*/ )
{
  return false;
}

KOM::ComponentFactory_ptr KOM::ComponentFactory_skel::_this()
{
  return KOM::ComponentFactory::_duplicate( this );
}


// Dynamic Implementation Routine for interface Application
KOM::Application_skel::Application_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Application:1.0", "Application" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KOM/Application:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<Application_skel>( this ) );
}

KOM::Application_skel::Application_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Application:1.0", "Application" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<Application_skel>( this ) );
}

KOM::Application_skel::~Application_skel()
{
}

bool KOM::Application_skel::dispatch( CORBA::ServerRequest_ptr /*_req*/, CORBA::Environment & /*_env*/ )
{
  return false;
}

KOM::Application_ptr KOM::Application_skel::_this()
{
  return KOM::Application::_duplicate( this );
}


// Dynamic Implementation Routine for interface Aggregate
KOM::Aggregate_skel::Aggregate_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Aggregate:1.0", "Aggregate" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KOM/Aggregate:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<Aggregate_skel>( this ) );
}

KOM::Aggregate_skel::Aggregate_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Aggregate:1.0", "Aggregate" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<Aggregate_skel>( this ) );
}

KOM::Aggregate_skel::~Aggregate_skel()
{
}

bool KOM::Aggregate_skel::dispatch( CORBA::ServerRequest_ptr /*_req*/, CORBA::Environment & /*_env*/ )
{
  return false;
}

KOM::Aggregate_ptr KOM::Aggregate_skel::_this()
{
  return KOM::Aggregate::_duplicate( this );
}


// Dynamic Implementation Routine for interface AggregateFactory
KOM::AggregateFactory_skel::AggregateFactory_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/AggregateFactory:1.0", "AggregateFactory" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KOM/AggregateFactory:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<AggregateFactory_skel>( this ) );
}

KOM::AggregateFactory_skel::AggregateFactory_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/AggregateFactory:1.0", "AggregateFactory" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<AggregateFactory_skel>( this ) );
}

KOM::AggregateFactory_skel::~AggregateFactory_skel()
{
}

bool KOM::AggregateFactory_skel::dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment & /*_env*/ )
{
  if( strcmp( _req->op_name(), "create" ) == 0 ) {
    Component_var core;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Component );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (Component_ptr&) core;
    ::KOM::Aggregate_ptr _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = create( core );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= (::KOM::Aggregate_ptr) _res;
    CORBA::release( _res );
    _req->result( _any_res );
    return true;
  }
  return false;
}

KOM::AggregateFactory_ptr KOM::AggregateFactory_skel::_this()
{
  return KOM::AggregateFactory::_duplicate( this );
}


// Dynamic Implementation Routine for interface Plugin
KOM::Plugin_skel::Plugin_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Plugin:1.0", "Plugin" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KOM/Plugin:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<Plugin_skel>( this ) );
}

KOM::Plugin_skel::Plugin_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/Plugin:1.0", "Plugin" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<Plugin_skel>( this ) );
}

KOM::Plugin_skel::~Plugin_skel()
{
}

bool KOM::Plugin_skel::dispatch( CORBA::ServerRequest_ptr /*_req*/, CORBA::Environment & /*_env*/ )
{
  return false;
}

KOM::Plugin_ptr KOM::Plugin_skel::_this()
{
  return KOM::Plugin::_duplicate( this );
}


// Dynamic Implementation Routine for interface PluginFactory
KOM::PluginFactory_skel::PluginFactory_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/PluginFactory:1.0", "PluginFactory" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KOM/PluginFactory:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<PluginFactory_skel>( this ) );
}

KOM::PluginFactory_skel::PluginFactory_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KOM/PluginFactory:1.0", "PluginFactory" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<PluginFactory_skel>( this ) );
}

KOM::PluginFactory_skel::~PluginFactory_skel()
{
}

bool KOM::PluginFactory_skel::dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment & /*_env*/ )
{
  if( strcmp( _req->op_name(), "create" ) == 0 ) {
    Component_var core;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( KOM::_tc_Component );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= (Component_ptr&) core;
    ::KOM::Plugin_ptr _res;
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      _res = create( core );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    CORBA::Any *_any_res = new CORBA::Any;
    *_any_res <<= (::KOM::Plugin_ptr) _res;
    CORBA::release( _res );
    _req->result( _any_res );
    return true;
  }
  return false;
}

KOM::PluginFactory_ptr KOM::PluginFactory_skel::_this()
{
  return KOM::PluginFactory::_duplicate( this );
}

