#!/usr/local/bin/python

# Qt tutorial 3.

import sys
from kde import *

a = QApplication(sys.argv)

w = QWidget()
w.resize(200,120)

quit = QPushButton("Quit",w)
quit.move(62,40)
quit.resize(75,30)
quit.setFont(QFont("Times",18,QFontWeight.Bold))

connect(quit,SIGNAL("clicked()"),a,SLOT("quit()"))

a.setMainWidget(w)
w.show()
a.exec_loop()
