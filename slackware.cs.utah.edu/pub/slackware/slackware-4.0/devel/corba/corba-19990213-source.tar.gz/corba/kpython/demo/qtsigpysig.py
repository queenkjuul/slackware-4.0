#!/usr/local/bin/python

# A simple example using Qt signals connected to Python signals.

import sys
from kde import *


class proxy(QObject):
	def __init__(self,*args):
		apply(QObject.__init__,(self,) + args)


a = QApplication(sys.argv)
b = QPushButton("Press to Quit")
p = proxy()

connect(b,SIGNAL("clicked()"),p,PYSIGNAL("proxyClick"))
connect(p,PYSIGNAL("proxyClick"),a,SLOT("quit()"))

b.resize(100,30)
a.setMainWidget(b)
b.show()
a.exec_loop()
