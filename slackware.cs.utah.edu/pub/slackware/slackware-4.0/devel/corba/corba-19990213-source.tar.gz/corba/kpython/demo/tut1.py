#!/usr/local/bin/python

# Qt tutorial 1.

import sys
from kde import *


a = QApplication(sys.argv)

hello = QPushButton("Hello world!")
hello.resize(100,30)

a.setMainWidget(hello)
hello.show()
a.exec_loop()
