#!/usr/local/bin/python

# A simple example using Python signals connected to Python slots.

import sys
from kde import *


class proxy(QObject):
	def __init__(self,*args):
		apply(QObject.__init__,(self,) + args)

	def handleClick(self):
		print "Emitting proxy click"
		self.emit(PYSIGNAL("proxyClick"),())

	def echo(self):
		print "This is an echo"


a = QApplication(sys.argv)
b = QPushButton("Press to Quit")
p = proxy()

connect(b,SIGNAL("clicked()"),p.handleClick)
connect(p,PYSIGNAL("proxyClick"),a,SLOT("quit()"))
connect(p,PYSIGNAL("proxyClick"),p.echo)

b.resize(100,30)
a.setMainWidget(b)
b.show()
a.exec_loop()
