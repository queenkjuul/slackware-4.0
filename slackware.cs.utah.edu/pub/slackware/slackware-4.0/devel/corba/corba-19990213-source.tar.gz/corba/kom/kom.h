/*
 *  MICO --- a free CORBA implementation
 *  Copyright (C) 1997-98 Kay Roemer & Arno Puder
 *
 *  This file was automatically generated. DO NOT EDIT!
 */

#if !defined(__KOM_H__) || defined(MICO_NO_TOPLEVEL_MODULES)
#define __KOM_H__

#ifndef MICO_NO_TOPLEVEL_MODULES
#include <CORBA.h>
#include <mico/throw.h>
#endif

#ifndef MICO_NO_TOPLEVEL_MODULES
MICO_NAMESPACE_DECL KOM {
#endif

#if !defined(MICO_NO_TOPLEVEL_MODULES) || defined(MICO_MODULE_KOM)


typedef char* EventType;
typedef CORBA::String_var EventType_var;
typedef CORBA::String_out EventType_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_EventType;

typedef char* EventTypePattern;
typedef CORBA::String_var EventTypePattern_var;
typedef CORBA::String_out EventTypePattern_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_EventTypePattern;

typedef SequenceTmpl<EventTypePattern_var> EventTypeSeq;
#ifdef _WINDOWS
static EventTypeSeq _dummy_EventTypeSeq;
#endif
typedef TSeqVar<SequenceTmpl<EventTypePattern_var> > EventTypeSeq_var;
typedef EventTypeSeq_var EventTypeSeq_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_EventTypeSeq;

class Base;
typedef Base *Base_ptr;
typedef Base_ptr BaseRef;
typedef ObjVar<Base> Base_var;
typedef Base_var Base_out;


// Common definitions for interface Base
class Base : virtual public CORBA::Object
{
  public:
    virtual ~Base();
    static Base_ptr _duplicate( Base_ptr obj );
    static Base_ptr _narrow( CORBA::Object_ptr obj );
    static Base_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

    struct UnknownSignal : public CORBA::UserException {
      #ifdef HAVE_EXPLICIT_STRUCT_OPS
      UnknownSignal();
      ~UnknownSignal();
      UnknownSignal( const UnknownSignal& s );
      UnknownSignal& operator=( const UnknownSignal& s );
      #endif //HAVE_EXPLICIT_STRUCT_OPS
      void _throwit() const;
      const char *_repoid() const;
      void _encode( CORBA::DataEncoder &en ) const;
      CORBA::Exception *_clone() const;
      static UnknownSignal *_narrow( CORBA::Exception *ex );
    };

    typedef ExceptVar<UnknownSignal> UnknownSignal_var;
    typedef UnknownSignal_var UnknownSignal_out;

    static CORBA::TypeCodeConst _tc_UnknownSignal;

    struct Connection {
      #ifdef HAVE_EXPLICIT_STRUCT_OPS
      Connection();
      ~Connection();
      Connection( const Connection& s );
      Connection& operator=( const Connection& s );
      #endif //HAVE_EXPLICIT_STRUCT_OPS
      CORBA::String_var sig;
      ::KOM::Base_var receiver;
      CORBA::String_var function;
    };

    typedef TVarVar<Connection> Connection_var;
    typedef Connection_var Connection_out;

    static CORBA::TypeCodeConst _tc_Connection;

    typedef SequenceTmpl<Connection> ConnectionSeq;
    #ifdef _WINDOWS
    static ConnectionSeq _dummy_ConnectionSeq;
    #endif
    typedef TSeqVar<SequenceTmpl<Connection> > ConnectionSeq_var;
    typedef ConnectionSeq_var ConnectionSeq_out;

    static CORBA::TypeCodeConst _tc_ConnectionSeq;

    struct EventFilter {
      #ifdef HAVE_EXPLICIT_STRUCT_OPS
      EventFilter();
      ~EventFilter();
      EventFilter( const EventFilter& s );
      EventFilter& operator=( const EventFilter& s );
      #endif //HAVE_EXPLICIT_STRUCT_OPS
      ::KOM::Base_var receiver;
      CORBA::String_var function;
      EventTypeSeq events;
    };

    typedef TVarVar<EventFilter> EventFilter_var;
    typedef EventFilter_var EventFilter_out;

    static CORBA::TypeCodeConst _tc_EventFilter;

    typedef SequenceTmpl<EventFilter> EventFilterSeq;
    #ifdef _WINDOWS
    static EventFilterSeq _dummy_EventFilterSeq;
    #endif
    typedef TSeqVar<SequenceTmpl<EventFilter> > EventFilterSeq_var;
    typedef EventFilterSeq_var EventFilterSeq_out;

    static CORBA::TypeCodeConst _tc_EventFilterSeq;

    enum FilterMode {
      FM_WRITE = 0,
      FM_IMPLEMENT,
      FM_READ
    };

    typedef FilterMode& FilterMode_out;

    static CORBA::TypeCodeConst _tc_FilterMode;

    typedef SequenceTmpl<KOM::Base_var> RelativesSeq;
    #ifdef _WINDOWS
    static RelativesSeq _dummy_RelativesSeq;
    #endif
    typedef TSeqVar<SequenceTmpl<KOM::Base_var> > RelativesSeq_var;
    typedef RelativesSeq_var RelativesSeq_out;

    static CORBA::TypeCodeConst _tc_RelativesSeq;

    virtual void connect( const char* sig, ::KOM::Base_ptr obj, const char* function ) = 0;
    virtual void disconnect( const char* sig, ::KOM::Base_ptr obj, const char* function ) = 0;
    virtual void disconnectSignalNotify( ::KOM::Base_ptr obj, const char* sig, const char* function ) = 0;
    virtual ConnectionSeq* describeConnections() = 0;
    virtual void connectNotify( ::KOM::Base_ptr obj ) = 0;
    virtual void disconnectNotify( ::KOM::Base_ptr obj ) = 0;
    virtual void receiveASync( const char* type, const CORBA::Any& value ) = 0;
    virtual void receive( const char* type, const CORBA::Any& value ) = 0;
    virtual CORBA::Boolean eventFilter( ::KOM::Base_ptr obj, const char* type, const CORBA::Any& value ) = 0;
    virtual void installFilter( ::KOM::Base_ptr obj, const char* function, const EventTypeSeq& events, FilterMode mode ) = 0;
    virtual void uninstallFilter( ::KOM::Base_ptr obj ) = 0;
    virtual void disconnectFilterNotify( ::KOM::Base_ptr obj ) = 0;
    virtual EventFilterSeq* describeEventFilters() = 0;
    virtual void adopt( ::KOM::Base_ptr obj ) = 0;
    virtual void adoptNotify( ::KOM::Base_ptr obj ) = 0;
    virtual void leave( ::KOM::Base_ptr obj ) = 0;
    virtual void leaveNotify( ::KOM::Base_ptr obj ) = 0;
    virtual RelativesSeq* describeRelatives() = 0;
    virtual void incRef() = 0;
    virtual void decRef() = 0;
    virtual CORBA::ULong refCount() = 0;
    virtual void destroy() = 0;
    virtual void disconnectObject( ::KOM::Base_ptr obj ) = 0;
    virtual void disconnectAll() = 0;
  protected:
    Base() {};
  private:
    Base( const Base& );
    void operator=( const Base& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_Base;

// Stub for interface Base
class Base_stub : virtual public Base
{
  public:
    virtual ~Base_stub();
    void connect( const char* sig, ::KOM::Base_ptr obj, const char* function );
    void disconnect( const char* sig, ::KOM::Base_ptr obj, const char* function );
    void disconnectSignalNotify( ::KOM::Base_ptr obj, const char* sig, const char* function );
    ConnectionSeq* describeConnections();
    void connectNotify( ::KOM::Base_ptr obj );
    void disconnectNotify( ::KOM::Base_ptr obj );
    void receiveASync( const char* type, const CORBA::Any& value );
    void receive( const char* type, const CORBA::Any& value );
    CORBA::Boolean eventFilter( ::KOM::Base_ptr obj, const char* type, const CORBA::Any& value );
    void installFilter( ::KOM::Base_ptr obj, const char* function, const EventTypeSeq& events, FilterMode mode );
    void uninstallFilter( ::KOM::Base_ptr obj );
    void disconnectFilterNotify( ::KOM::Base_ptr obj );
    EventFilterSeq* describeEventFilters();
    void adopt( ::KOM::Base_ptr obj );
    void adoptNotify( ::KOM::Base_ptr obj );
    void leave( ::KOM::Base_ptr obj );
    void leaveNotify( ::KOM::Base_ptr obj );
    RelativesSeq* describeRelatives();
    void incRef();
    void decRef();
    CORBA::ULong refCount();
    void destroy();
    void disconnectObject( ::KOM::Base_ptr obj );
    void disconnectAll();
  private:
    void operator=( const Base_stub& );
};

class Base_skel :
  virtual public MethodDispatcher,
  virtual public Base
{
  public:
    Base_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~Base_skel();
    Base_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    Base_ptr _this();

};

struct Member {
  #ifdef HAVE_EXPLICIT_STRUCT_OPS
  Member();
  ~Member();
  Member( const Member& s );
  Member& operator=( const Member& s );
  #endif //HAVE_EXPLICIT_STRUCT_OPS
  Base_var obj;
  CORBA::String_var name;
};

typedef TVarVar<Member> Member_var;
typedef Member_var Member_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_Member;

typedef SequenceTmpl<Member> MemberSeq;
#ifdef _WINDOWS
static MemberSeq _dummy_MemberSeq;
#endif
typedef TSeqVar<SequenceTmpl<Member> > MemberSeq_var;
typedef MemberSeq_var MemberSeq_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_MemberSeq;

struct UnknownMember : public CORBA::UserException {
  #ifdef HAVE_EXPLICIT_STRUCT_OPS
  UnknownMember();
  ~UnknownMember();
  UnknownMember( const UnknownMember& s );
  UnknownMember& operator=( const UnknownMember& s );
  #endif //HAVE_EXPLICIT_STRUCT_OPS
  void _throwit() const;
  const char *_repoid() const;
  void _encode( CORBA::DataEncoder &en ) const;
  CORBA::Exception *_clone() const;
  static UnknownMember *_narrow( CORBA::Exception *ex );
  CORBA::String_var name;
};

typedef ExceptVar<UnknownMember> UnknownMember_var;
typedef UnknownMember_var UnknownMember_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_UnknownMember;

struct DuplicateMember : public CORBA::UserException {
  #ifdef HAVE_EXPLICIT_STRUCT_OPS
  DuplicateMember();
  ~DuplicateMember();
  DuplicateMember( const DuplicateMember& s );
  DuplicateMember& operator=( const DuplicateMember& s );
  #endif //HAVE_EXPLICIT_STRUCT_OPS
  void _throwit() const;
  const char *_repoid() const;
  void _encode( CORBA::DataEncoder &en ) const;
  CORBA::Exception *_clone() const;
  static DuplicateMember *_narrow( CORBA::Exception *ex );
  CORBA::String_var name;
};

typedef ExceptVar<DuplicateMember> DuplicateMember_var;
typedef DuplicateMember_var DuplicateMember_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_DuplicateMember;

class Container;
typedef Container *Container_ptr;
typedef Container_ptr ContainerRef;
typedef ObjVar<Container> Container_var;
typedef Container_var Container_out;


// Common definitions for interface Container
class Container : 
  virtual public ::KOM::Base
{
  public:
    virtual ~Container();
    static Container_ptr _duplicate( Container_ptr obj );
    static Container_ptr _narrow( CORBA::Object_ptr obj );
    static Container_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

    virtual void addContainee( const Member& memb ) = 0;
    virtual void removeContainee( const char* name ) = 0;
    virtual void replaceContainee( const Member& member ) = 0;
    virtual void clear() = 0;
    virtual MemberSeq* listContainees() = 0;
    virtual Base_ptr lookupContainee( const char* name ) = 0;
    virtual void containeeAdded( const Member& memb ) = 0;
    virtual void containeeRemoved( const Member& memb ) = 0;
  protected:
    Container() {};
  private:
    Container( const Container& );
    void operator=( const Container& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_Container;

// Stub for interface Container
class Container_stub : virtual public Container,
  virtual public ::KOM::Base_stub
{
  public:
    virtual ~Container_stub();
    void addContainee( const Member& memb );
    void removeContainee( const char* name );
    void replaceContainee( const Member& member );
    void clear();
    MemberSeq* listContainees();
    Base_ptr lookupContainee( const char* name );
    void containeeAdded( const Member& memb );
    void containeeRemoved( const Member& memb );
  private:
    void operator=( const Container_stub& );
};

class Container_skel :
  virtual public MethodDispatcher,
  virtual public Container
{
  public:
    Container_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~Container_skel();
    Container_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    Container_ptr _this();

};

typedef char* InterfaceName;
typedef CORBA::String_var InterfaceName_var;
typedef CORBA::String_out InterfaceName_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_InterfaceName;

typedef SequenceTmpl<InterfaceName_var> InterfaceSeq;
#ifdef _WINDOWS
static InterfaceSeq _dummy_InterfaceSeq;
#endif
typedef TSeqVar<SequenceTmpl<InterfaceName_var> > InterfaceSeq_var;
typedef InterfaceSeq_var InterfaceSeq_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_InterfaceSeq;

struct InterfaceAlreadySupported : public CORBA::UserException {
  #ifdef HAVE_EXPLICIT_STRUCT_OPS
  InterfaceAlreadySupported();
  ~InterfaceAlreadySupported();
  InterfaceAlreadySupported( const InterfaceAlreadySupported& s );
  InterfaceAlreadySupported& operator=( const InterfaceAlreadySupported& s );
  #endif //HAVE_EXPLICIT_STRUCT_OPS
  void _throwit() const;
  const char *_repoid() const;
  void _encode( CORBA::DataEncoder &en ) const;
  CORBA::Exception *_clone() const;
  static InterfaceAlreadySupported *_narrow( CORBA::Exception *ex );
  InterfaceName_var iface;
};

typedef ExceptVar<InterfaceAlreadySupported> InterfaceAlreadySupported_var;
typedef InterfaceAlreadySupported_var InterfaceAlreadySupported_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_InterfaceAlreadySupported;

struct InterfaceNotFound : public CORBA::UserException {
  #ifdef HAVE_EXPLICIT_STRUCT_OPS
  InterfaceNotFound();
  ~InterfaceNotFound();
  InterfaceNotFound( const InterfaceNotFound& s );
  InterfaceNotFound& operator=( const InterfaceNotFound& s );
  #endif //HAVE_EXPLICIT_STRUCT_OPS
  void _throwit() const;
  const char *_repoid() const;
  void _encode( CORBA::DataEncoder &en ) const;
  CORBA::Exception *_clone() const;
  static InterfaceNotFound *_narrow( CORBA::Exception *ex );
};

typedef ExceptVar<InterfaceNotFound> InterfaceNotFound_var;
typedef InterfaceNotFound_var InterfaceNotFound_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_InterfaceNotFound;

typedef CORBA::Long ID;
MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_ID;

struct UnknownID : public CORBA::UserException {
  #ifdef HAVE_EXPLICIT_STRUCT_OPS
  UnknownID();
  ~UnknownID();
  UnknownID( const UnknownID& s );
  UnknownID& operator=( const UnknownID& s );
  #endif //HAVE_EXPLICIT_STRUCT_OPS
  void _throwit() const;
  const char *_repoid() const;
  void _encode( CORBA::DataEncoder &en ) const;
  CORBA::Exception *_clone() const;
  static UnknownID *_narrow( CORBA::Exception *ex );
  ID id;
};

typedef ExceptVar<UnknownID> UnknownID_var;
typedef UnknownID_var UnknownID_out;

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_UnknownID;

class AggregateFactory;
typedef AggregateFactory *AggregateFactory_ptr;
typedef AggregateFactory_ptr AggregateFactoryRef;
typedef ObjVar<AggregateFactory> AggregateFactory_var;
typedef AggregateFactory_var AggregateFactory_out;

class PluginFactory;
typedef PluginFactory *PluginFactory_ptr;
typedef PluginFactory_ptr PluginFactoryRef;
typedef ObjVar<PluginFactory> PluginFactory_var;
typedef PluginFactory_var PluginFactory_out;

class Plugin;
typedef Plugin *Plugin_ptr;
typedef Plugin_ptr PluginRef;
typedef ObjVar<Plugin> Plugin_var;
typedef Plugin_var Plugin_out;

class Component;
typedef Component *Component_ptr;
typedef Component_ptr ComponentRef;
typedef ObjVar<Component> Component_var;
typedef Component_var Component_out;


// Common definitions for interface Component
class Component : 
  virtual public ::KOM::Base
{
  public:
    virtual ~Component();
    static Component_ptr _duplicate( Component_ptr obj );
    static Component_ptr _narrow( CORBA::Object_ptr obj );
    static Component_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

    struct PluginInfo {
      #ifdef HAVE_EXPLICIT_STRUCT_OPS
      PluginInfo();
      ~PluginInfo();
      PluginInfo( const PluginInfo& s );
      PluginInfo& operator=( const PluginInfo& s );
      #endif //HAVE_EXPLICIT_STRUCT_OPS
      InterfaceSeq interfaces;
      ID id;
      CORBA::Boolean composed;
    };

    typedef TVarVar<PluginInfo> PluginInfo_var;
    typedef PluginInfo_var PluginInfo_out;

    static CORBA::TypeCodeConst _tc_PluginInfo;

    typedef SequenceTmpl<PluginInfo> PluginInfoSeq;
    #ifdef _WINDOWS
    static PluginInfoSeq _dummy_PluginInfoSeq;
    #endif
    typedef TSeqVar<SequenceTmpl<PluginInfo> > PluginInfoSeq_var;
    typedef PluginInfoSeq_var PluginInfoSeq_out;

    static CORBA::TypeCodeConst _tc_PluginInfoSeq;

    virtual CORBA::Object_ptr getInterface( const char* name ) = 0;
    virtual InterfaceSeq* interfaces() = 0;
    virtual CORBA::Boolean supportsInterface( const char* name ) = 0;
    virtual ID addAggregate( AggregateFactory_ptr factory, const InterfaceSeq& required, const InterfaceSeq& provided, CORBA::Boolean activate ) = 0;
    virtual void removeAggregate( ID id ) = 0;
    virtual ID addPlugin( PluginFactory_ptr factory, const InterfaceSeq& required, const InterfaceSeq& required_plugins, const InterfaceSeq& provided, CORBA::Boolean activate ) = 0;
    virtual void removePlugin( ID id ) = 0;
    virtual CORBA::Object_ptr getPluginInterface( const char* name ) = 0;
    virtual InterfaceSeq* pluginInterfaces() = 0;
    virtual CORBA::Boolean supportsPluginInterface( const char* name ) = 0;
    virtual PluginInfoSeq* describePlugins() = 0;
    virtual Plugin_ptr getPlugin( ID id ) = 0;
  protected:
    Component() {};
  private:
    Component( const Component& );
    void operator=( const Component& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_Component;

// Stub for interface Component
class Component_stub : virtual public Component,
  virtual public ::KOM::Base_stub
{
  public:
    virtual ~Component_stub();
    CORBA::Object_ptr getInterface( const char* name );
    InterfaceSeq* interfaces();
    CORBA::Boolean supportsInterface( const char* name );
    ID addAggregate( AggregateFactory_ptr factory, const InterfaceSeq& required, const InterfaceSeq& provided, CORBA::Boolean activate );
    void removeAggregate( ID id );
    ID addPlugin( PluginFactory_ptr factory, const InterfaceSeq& required, const InterfaceSeq& required_plugins, const InterfaceSeq& provided, CORBA::Boolean activate );
    void removePlugin( ID id );
    CORBA::Object_ptr getPluginInterface( const char* name );
    InterfaceSeq* pluginInterfaces();
    CORBA::Boolean supportsPluginInterface( const char* name );
    PluginInfoSeq* describePlugins();
    Plugin_ptr getPlugin( ID id );
  private:
    void operator=( const Component_stub& );
};

class Component_skel :
  virtual public MethodDispatcher,
  virtual public Component
{
  public:
    Component_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~Component_skel();
    Component_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    Component_ptr _this();

};

class ComponentFactory;
typedef ComponentFactory *ComponentFactory_ptr;
typedef ComponentFactory_ptr ComponentFactoryRef;
typedef ObjVar<ComponentFactory> ComponentFactory_var;
typedef ComponentFactory_var ComponentFactory_out;


// Common definitions for interface ComponentFactory
class ComponentFactory : virtual public CORBA::Object
{
  public:
    virtual ~ComponentFactory();
    static ComponentFactory_ptr _duplicate( ComponentFactory_ptr obj );
    static ComponentFactory_ptr _narrow( CORBA::Object_ptr obj );
    static ComponentFactory_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

  protected:
    ComponentFactory() {};
  private:
    ComponentFactory( const ComponentFactory& );
    void operator=( const ComponentFactory& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_ComponentFactory;

// Stub for interface ComponentFactory
class ComponentFactory_stub : virtual public ComponentFactory
{
  public:
    virtual ~ComponentFactory_stub();
  private:
    void operator=( const ComponentFactory_stub& );
};

class ComponentFactory_skel :
  virtual public MethodDispatcher,
  virtual public ComponentFactory
{
  public:
    ComponentFactory_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~ComponentFactory_skel();
    ComponentFactory_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    ComponentFactory_ptr _this();

};

class Application;
typedef Application *Application_ptr;
typedef Application_ptr ApplicationRef;
typedef ObjVar<Application> Application_var;
typedef Application_var Application_out;


// Common definitions for interface Application
class Application : 
  virtual public ::KOM::Component
{
  public:
    virtual ~Application();
    static Application_ptr _duplicate( Application_ptr obj );
    static Application_ptr _narrow( CORBA::Object_ptr obj );
    static Application_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

  protected:
    Application() {};
  private:
    Application( const Application& );
    void operator=( const Application& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_Application;

// Stub for interface Application
class Application_stub : virtual public Application,
  virtual public ::KOM::Component_stub
{
  public:
    virtual ~Application_stub();
  private:
    void operator=( const Application_stub& );
};

class Application_skel :
  virtual public MethodDispatcher,
  virtual public Application
{
  public:
    Application_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~Application_skel();
    Application_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    Application_ptr _this();

};

class Aggregate;
typedef Aggregate *Aggregate_ptr;
typedef Aggregate_ptr AggregateRef;
typedef ObjVar<Aggregate> Aggregate_var;
typedef Aggregate_var Aggregate_out;


// Common definitions for interface Aggregate
class Aggregate : 
  virtual public ::KOM::Component
{
  public:
    virtual ~Aggregate();
    static Aggregate_ptr _duplicate( Aggregate_ptr obj );
    static Aggregate_ptr _narrow( CORBA::Object_ptr obj );
    static Aggregate_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

  protected:
    Aggregate() {};
  private:
    Aggregate( const Aggregate& );
    void operator=( const Aggregate& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_Aggregate;

// Stub for interface Aggregate
class Aggregate_stub : virtual public Aggregate,
  virtual public ::KOM::Component_stub
{
  public:
    virtual ~Aggregate_stub();
  private:
    void operator=( const Aggregate_stub& );
};

class Aggregate_skel :
  virtual public MethodDispatcher,
  virtual public Aggregate
{
  public:
    Aggregate_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~Aggregate_skel();
    Aggregate_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    Aggregate_ptr _this();

};


// Common definitions for interface AggregateFactory
class AggregateFactory : 
  virtual public ::KOM::ComponentFactory
{
  public:
    virtual ~AggregateFactory();
    static AggregateFactory_ptr _duplicate( AggregateFactory_ptr obj );
    static AggregateFactory_ptr _narrow( CORBA::Object_ptr obj );
    static AggregateFactory_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

    virtual ::KOM::Aggregate_ptr create( Component_ptr core ) = 0;
  protected:
    AggregateFactory() {};
  private:
    AggregateFactory( const AggregateFactory& );
    void operator=( const AggregateFactory& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_AggregateFactory;

// Stub for interface AggregateFactory
class AggregateFactory_stub : virtual public AggregateFactory,
  virtual public ::KOM::ComponentFactory_stub
{
  public:
    virtual ~AggregateFactory_stub();
    ::KOM::Aggregate_ptr create( Component_ptr core );
  private:
    void operator=( const AggregateFactory_stub& );
};

class AggregateFactory_skel :
  virtual public MethodDispatcher,
  virtual public AggregateFactory
{
  public:
    AggregateFactory_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~AggregateFactory_skel();
    AggregateFactory_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    AggregateFactory_ptr _this();

};


// Common definitions for interface Plugin
class Plugin : 
  virtual public ::KOM::Component
{
  public:
    virtual ~Plugin();
    static Plugin_ptr _duplicate( Plugin_ptr obj );
    static Plugin_ptr _narrow( CORBA::Object_ptr obj );
    static Plugin_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

  protected:
    Plugin() {};
  private:
    Plugin( const Plugin& );
    void operator=( const Plugin& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_Plugin;

// Stub for interface Plugin
class Plugin_stub : virtual public Plugin,
  virtual public ::KOM::Component_stub
{
  public:
    virtual ~Plugin_stub();
  private:
    void operator=( const Plugin_stub& );
};

class Plugin_skel :
  virtual public MethodDispatcher,
  virtual public Plugin
{
  public:
    Plugin_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~Plugin_skel();
    Plugin_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    Plugin_ptr _this();

};


// Common definitions for interface PluginFactory
class PluginFactory : 
  virtual public ::KOM::ComponentFactory
{
  public:
    virtual ~PluginFactory();
    static PluginFactory_ptr _duplicate( PluginFactory_ptr obj );
    static PluginFactory_ptr _narrow( CORBA::Object_ptr obj );
    static PluginFactory_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

    virtual ::KOM::Plugin_ptr create( Component_ptr core ) = 0;
  protected:
    PluginFactory() {};
  private:
    PluginFactory( const PluginFactory& );
    void operator=( const PluginFactory& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_PluginFactory;

// Stub for interface PluginFactory
class PluginFactory_stub : virtual public PluginFactory,
  virtual public ::KOM::ComponentFactory_stub
{
  public:
    virtual ~PluginFactory_stub();
    ::KOM::Plugin_ptr create( Component_ptr core );
  private:
    void operator=( const PluginFactory_stub& );
};

class PluginFactory_skel :
  virtual public MethodDispatcher,
  virtual public PluginFactory
{
  public:
    PluginFactory_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~PluginFactory_skel();
    PluginFactory_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    PluginFactory_ptr _this();

};

#endif // !defined(MICO_NO_TOPLEVEL_MODULES) || defined(MICO_MODULE_KOM)

#ifndef MICO_NO_TOPLEVEL_MODULES

};
#endif



#if !defined(MICO_NO_TOPLEVEL_MODULES) || defined(MICO_MODULE__GLOBAL)

CORBA::Boolean operator<<=( CORBA::Any &a, const ::KOM::Base::UnknownSignal &e );
CORBA::Boolean operator>>=( const CORBA::Any &a, ::KOM::Base::UnknownSignal &e );

CORBA::Boolean operator<<=( CORBA::Any &_a, const ::KOM::Base::Connection &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, ::KOM::Base::Connection &_s );

CORBA::Boolean operator<<=( CORBA::Any &_a, const ::KOM::Base::EventFilter &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, ::KOM::Base::EventFilter &_s );

CORBA::Boolean operator<<=( CORBA::Any &a, const ::KOM::Base::FilterMode &e );

CORBA::Boolean operator>>=( const CORBA::Any &a, ::KOM::Base::FilterMode &e );

CORBA::Boolean operator<<=( CORBA::Any &a, const KOM::Base_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KOM::Base_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &_a, const ::KOM::Member &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, ::KOM::Member &_s );

CORBA::Boolean operator<<=( CORBA::Any &a, const ::KOM::UnknownMember &e );
CORBA::Boolean operator>>=( const CORBA::Any &a, ::KOM::UnknownMember &e );

CORBA::Boolean operator<<=( CORBA::Any &a, const ::KOM::DuplicateMember &e );
CORBA::Boolean operator>>=( const CORBA::Any &a, ::KOM::DuplicateMember &e );

CORBA::Boolean operator<<=( CORBA::Any &a, const KOM::Container_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KOM::Container_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &a, const ::KOM::InterfaceAlreadySupported &e );
CORBA::Boolean operator>>=( const CORBA::Any &a, ::KOM::InterfaceAlreadySupported &e );

CORBA::Boolean operator<<=( CORBA::Any &a, const ::KOM::InterfaceNotFound &e );
CORBA::Boolean operator>>=( const CORBA::Any &a, ::KOM::InterfaceNotFound &e );

CORBA::Boolean operator<<=( CORBA::Any &a, const ::KOM::UnknownID &e );
CORBA::Boolean operator>>=( const CORBA::Any &a, ::KOM::UnknownID &e );

CORBA::Boolean operator<<=( CORBA::Any &_a, const ::KOM::Component::PluginInfo &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, ::KOM::Component::PluginInfo &_s );

CORBA::Boolean operator<<=( CORBA::Any &a, const KOM::Component_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KOM::Component_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &a, const KOM::ComponentFactory_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KOM::ComponentFactory_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &a, const KOM::Application_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KOM::Application_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &a, const KOM::Aggregate_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KOM::Aggregate_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &a, const KOM::AggregateFactory_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KOM::AggregateFactory_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &a, const KOM::Plugin_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KOM::Plugin_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &a, const KOM::PluginFactory_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KOM::PluginFactory_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::EventTypePattern_var> &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::EventTypePattern_var> &_s );

CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Base::Connection> &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Base::Connection> &_s );

CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Base::EventFilter> &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Base::EventFilter> &_s );

CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Base_var> &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Base_var> &_s );

CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Member> &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Member> &_s );

CORBA::Boolean operator<<=( CORBA::Any &_a, const SequenceTmpl<KOM::Component::PluginInfo> &_s );
CORBA::Boolean operator>>=( const CORBA::Any &_a, SequenceTmpl<KOM::Component::PluginInfo> &_s );

#endif // !defined(MICO_NO_TOPLEVEL_MODULES) || defined(MICO_MODULE__GLOBAL)


#if !defined(MICO_NO_TOPLEVEL_MODULES) && !defined(MICO_IN_GENERATED_CODE)
#include <mico/template_impl.h>
#endif

#endif
