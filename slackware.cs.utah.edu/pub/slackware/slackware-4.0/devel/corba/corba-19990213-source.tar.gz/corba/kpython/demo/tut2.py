#!/usr/local/bin/python

# Qt tutorial 2.

import sys
from kde import *


a = QApplication(sys.argv)

quit = QPushButton("Quit")
quit.resize(75,30)
quit.setFont(QFont("Times",18,QFontWeight.Bold))

connect(quit,SIGNAL("clicked()"),a,SLOT("quit()"))

a.setMainWidget(quit)
quit.show()
a.exec_loop()
