/*
  Author: Simon Hausmann <tronical@gmx.net>
*/

#ifndef __OPstatusbar_h__
#define __OPstatusbar_h__

#include <kstatusbar.h>

class OPStatusBarIf;

class OPStatusBar : public KStatusBar
{
  Q_OBJECT
public:
  OPStatusBar( QWidget *parent = 0L, const char *name = 0L );
  ~OPStatusBar();
  
  OPStatusBarIf* interface();

protected slots:
  void slotPressed( int ID );
  void slotReleased( int ID );

protected:
  OPStatusBarIf* m_pInterface;
};

#endif

