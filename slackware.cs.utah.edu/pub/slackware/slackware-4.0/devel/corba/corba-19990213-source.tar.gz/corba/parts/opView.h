#ifndef __op_view_if_h__
#define __op_view_if_h__

#include "openparts.h"
#include "opPart.h"

#include <komVar.h>

class OPDocumentIf;

class OPViewIf : virtual public OPPartIf,
		 virtual public OpenParts::View_skel
{
public:
  // C++
  OPViewIf( OPDocumentIf* _doc );
  ~OPViewIf();

  virtual void cleanUp();
  
  // IDL
  virtual OpenParts::Document_ptr document();
  
protected:
  OPDocumentIf* m_pDocument;
};

typedef KOMVar<OpenParts::View> OPView_ref;

#endif
