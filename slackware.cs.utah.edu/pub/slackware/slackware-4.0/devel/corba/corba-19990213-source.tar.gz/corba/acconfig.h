
#undef VERSION

#undef PACKAGE

#undef HAVE_BOOL

#undef ksize_t

#undef HAVE_MINI_STL

#undef ENABLE_NLS

/* defines if having libgif (always 1) */
#undef HAVE_LIBGIF

/* defines if having libjpeg (always 1) */
#undef HAVE_LIBJPEG

/* defines if having libtiff */
#undef HAVE_LIBTIFF              

/* defines if having libpng */
#undef HAVE_LIBPNG

#ifndef HAVE_BOOL
#define HAVE_BOOL
typedef int bool;
#ifdef __cplusplus
const bool false = 0;
const bool true = 1;
#else
#define false (bool)0;
#define true (bool)1;
#endif
#endif


