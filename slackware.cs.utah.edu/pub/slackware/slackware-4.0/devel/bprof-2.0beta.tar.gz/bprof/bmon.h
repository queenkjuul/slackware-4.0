/* Header file for information about the bmon.out file format */

struct bmonheader {
    unsigned int bmon_magic;
    unsigned int numofitems;
};

struct bmonitem {
    caddr_t pc;
    unsigned int count;
};

#define BMON_MAGIC 0xdeadbeef
