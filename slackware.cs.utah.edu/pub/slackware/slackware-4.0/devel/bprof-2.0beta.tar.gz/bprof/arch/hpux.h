/* Machine specific info for HPUX. */

/* How to get the low and high values of the program counter */

extern char __text_start, _etext;
#define BM_LOWPC (&__text_start)
#define BM_HIGHPC (&_etext)

/* How to get the current instruction address.  I've no idea what the
   type of the second argument to the signal handler is supposed to
   be, but int seems the right size.  */

#include <signal.h>
#define BM_SIGARGS int, int, sigcontext* sigcon
#define BM_EIP sigcon->sc_pcoq_head
