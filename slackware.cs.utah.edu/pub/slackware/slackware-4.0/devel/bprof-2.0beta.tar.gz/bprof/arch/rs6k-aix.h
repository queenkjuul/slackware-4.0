/* Machine specific info for AIX on RS6000 */

/* How to get the low and high values of the program counter */

extern char _text, _etext;
#define BM_LOWPC (&_text)
#define BM_HIGHPC (&_etext)

/* How to get the current instruction address */

#include <signal.h>
#define BM_SIGARGS int, int, sigcontext* sigcon
#define BM_EIP sigcon->sc_jmpbuf.jmp_context.iar

/* Functions not in header files */

extern "C" {
extern void *sbrk(int);
extern int setitimer(int, struct itimerval *, struct itimerval *);
}
