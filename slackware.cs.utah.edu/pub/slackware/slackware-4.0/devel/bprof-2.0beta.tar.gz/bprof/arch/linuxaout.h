/* Machine specific info for Linux using a.out */

/* How to get the low and high values of the program counter */

extern char __crt_dummy__, _etext;
#define BM_LOWPC (&__crt_dummy__)
#define BM_HIGHPC (&_etext)

/* How to get the current instruction address */

#include <asm/sigcontext.h>
#define BM_SIGARGS int, sigcontext_struct sigcon
#define BM_EIP sigcon.eip
