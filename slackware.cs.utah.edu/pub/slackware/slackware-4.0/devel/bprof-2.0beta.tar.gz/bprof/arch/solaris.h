/* Machine specific info for Solaris.  UNTESTED!  Probably needs
   editing.  */

/* How to get the low and high values of the program counter */

extern char _start, _etext;
#define BM_LOWPC (&_start)
#define BM_HIGHPC (&_etext)

/* How to get the current instruction address */

#include <sys/ucontext.h>
#define BM_SIGARGS int, siginfo_t*, ucontext_t* sigcon
#define BM_EIP sigcon->uc_mcontext.gregs[REG_PC]
