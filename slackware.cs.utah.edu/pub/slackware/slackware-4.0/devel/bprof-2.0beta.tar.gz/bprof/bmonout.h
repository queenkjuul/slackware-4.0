/* -*- c++ -*-
   Describes a file with bmon output */

#include "bmon.h"

#pragma interface

class bmonout {
    static void xread(int, void*, size_t);
    time_t _mtime;
    unsigned int numofitems;
    bmonitem* items;
  public:
    bmonout(const char*);
    ~bmonout();
    unsigned int countnum() { return numofitems; }
    bmonitem operator[](int num) { return items[num]; }
    time_t mtime() const { return _mtime; }
};
