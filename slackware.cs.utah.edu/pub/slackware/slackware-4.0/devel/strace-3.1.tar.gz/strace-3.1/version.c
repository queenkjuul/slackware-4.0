char version[] = "strace -- version 3.1";
