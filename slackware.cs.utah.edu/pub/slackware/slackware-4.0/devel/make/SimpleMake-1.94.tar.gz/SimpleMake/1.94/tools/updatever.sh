#!/bin/sh
#
# $1 - first version
# $2 - next version
#
if [ $# = 0 ]; then
  echo "usage: updatever.sh <from version> <to version>"
  exit
fi

for i in *
do
  A=`head -1 $i`
  if [ "$A" = "#!/bin/sh" ]; then
    sed -e s/$1/$2/ <$i >$i.1
    mv $i.1 $i
    chmod 755 $i
  fi
done
