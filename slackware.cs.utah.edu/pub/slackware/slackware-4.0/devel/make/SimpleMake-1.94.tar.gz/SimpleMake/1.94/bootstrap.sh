#!/bin/sh

PATH=".:$PATH";export PATH
LEX="lex"
CC="cc"
LL="-ll"

$CC -o makeExtension makeExtension.c
$LEX MakefileInit.lex
$CC -o MakefileInit lex.yy.c $LL
$LEX makeIncludes.lex
$CC -o makeIncludes lex.yy.c $LL
rm -f lex.yy.c 

make makefile
make clean


