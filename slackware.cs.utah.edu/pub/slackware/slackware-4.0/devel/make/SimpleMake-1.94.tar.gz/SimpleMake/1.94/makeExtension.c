#include <stdio.h>

/*
 This program gets the extension of a filename (last . to end of string).
 usage: echo $FILENAME | makeExtension
*/

int main()
{
char ext[1024];
char c;
int  i,dot;
   i=0;
   dot=(1==0);
   c=fgetc(stdin);
   while(!feof(stdin)) {
     if (c=='.') {
       i=0;
       dot=(1==1);
     }
     else {
       if (dot) {
         ext[i++]=c;
       }
     }
     c=fgetc(stdin);
   }
   ext[i]='\0';
   printf("%s",ext);
return 0;
}
