#!/bin/sh
######################################

echo "installing $INSTALLTYPE part."

if [ "$INSTALLTYPE" = "BIN" ]; then

  cp ./makef.ins/empty.def $INSTALLDIR/Makefile.def

  DIR=`pwd | sed -e s%.*/%%`
  VERSION=$DIR

  for i in $* 
  do
    if [ ! -d $i ]; then
      FL=`head -1 $i`
      if [ "$FL" = "#!/bin/sh" ]; then
        chmod 755 $INSTALLDIR/$i
      fi
    fi
  done

else 
  echo "Nothing to install"
fi

