/*
 *	cook - file construction tool
 *	Copyright (C) 1991, 1992, 1993, 1994, 1996, 1997, 1998 Peter Miller;
 *	All rights reserved.
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111, USA.
 *
 * MANIFEST: functions to access the builtin functions
 *
 * The builtin functions all append their results to the supplied
 * `result' word list.  The first word of the `args' word list
 * is the name of the function.
 *
 * all of the functions return 0 in success, or -1 on error.
 *
 * Only a limited set of functionality is candidate for builtin functions,
 * these are 
 *	- string manipulation [dirname, stringset, ect ]
 *	- environment manipulation [getenv(3), etc]
 *	- stat(3) related functions [exists, mtime, pathname, etc]
 *	- launching OS commands [execute, collect]
 * The above list is though to be exhaustive.
 *
 * Explicitly and forever excluded from being a builtin function
 * is anything which knows or understands the format of some secific 
 * class of files.
 *
 * Access to stdio(3) has been thought of, and explicitly avoided.
 * Mostly because a specialist program used through [collect]
 * will almost always be far faster.
 */

#include <builtin.h>
#include <builtin/addprefix.h>
#include <builtin/addsuffix.h>
#include <builtin/basename.h>
#include <builtin/boolean.h>
#include <builtin/collect.h>
#include <builtin/cook.h>
#include <builtin/defined.h>
#include <builtin/dos.h>
#include <builtin/execute.h>
#include <builtin/exists.h>
#include <builtin/expr.h>
#include <builtin/filter_out.h>
#include <builtin/find_command.h>
#include <builtin/findstring.h>
#include <builtin/getenv.h>
#include <builtin/glob.h>
#include <builtin/home.h>
#include <builtin/interi_files.h>
#include <builtin/join.h>
#include <builtin/match.h>
#include <builtin/opsys.h>
#include <builtin/options.h>
#include <builtin/pathname.h>
#include <builtin/positional.h>
#include <builtin/print.h>
#include <builtin/readlink.h>
#include <builtin/relati_dirna.h>
#include <builtin/split.h>
#include <builtin/stringset.h>
#include <builtin/strip.h>
#include <builtin/subst.h>
#include <builtin/substr.h>
#include <builtin/suffix.h>
#include <builtin/text.h>
#include <builtin/thread-id.h>
#include <builtin/unsplit.h>
#include <builtin/word.h>
#include <builtin/wordlist.h>
#include <id.h>
#include <id/builtin.h>


struct expr_position_ty; /* existence */


typedef struct func_ty func_ty;
struct func_ty
{
	char	*f_name;
	int	(*f_code)_((string_list_ty *, const string_list_ty *,
			const struct expr_position_ty *,
			const struct opcode_context_ty *));
};


/*
 * NAME
 *	func - table of built-in functions
 *
 * SYNOPSIS
 *	func_ty func[];
 *
 * DESCRIPTION
 *	Func is a table of function names and pointers
 *	for the built-in functions of cook.
 */

static func_ty func[] =
{
	{ "__FILE__",		builtin_FILE,		},
	{ "__LINE__",		builtin_LINE,		},
	{ "addprefix",		builtin_addprefix,	},
	{ "addsuffix",		builtin_addsuffix,	},
	{ "and",		builtin_and,		},
	{ "basename",		builtin_basename,	},
	{ "cando",		builtin_cando,		},
	{ "catenate",		builtin_catenate,	},
	{ "collect",		builtin_collect,	},
	{ "collect_lines",	builtin_collect,	},
	{ "cook",		builtin_cooked,		},
	{ "count",		builtin_count,		},
	{ "defined",		builtin_defined,	},
	{ "dir",		builtin_dir,		},
	{ "dirname",		builtin_dir,		},
	{ "dos-path",		builtin_dos_path,	},
	{ "dos-path-undo",	builtin_dos_path_undo,	},
	{ "downcase",		builtin_downcase,	},
	{ "entryname",		builtin_entryname,	},
	{ "execute",		builtin_execute,	},
	{ "exists",		builtin_exists,		},
	{ "exists-symlink",	builtin_exists_symlink,	},
	{ "expr",		builtin_expr,		},
	{ "filter",		builtin_match_mask,	},
	{ "filter-out",		builtin_filter_out,	},
	{ "filter_out",		builtin_filter_out,	},
	{ "find_command",	builtin_find_command,	},
	{ "findstring",		builtin_findstring,	},
	{ "firstword",		builtin_head,		},
	{ "fromto",		builtin_fromto,		},
	{ "getenv",		builtin_getenv,		},
	{ "glob",		builtin_glob,		},
	{ "head",		builtin_head,		},
	{ "home",		builtin_home,		},
	{ "if",			builtin_if,		},
	{ "in",			builtin_in,		},
	{ "interior_files",	builtin_interior_files,	},
	{ "join",		builtin_join,		},
	{ "leaf_files",		builtin_leaf_files,	},
	{ "match",		builtin_match,		},
	{ "match_mask",		builtin_match_mask,	},
	{ "matches",		builtin_match,		},
	{ "mtime",		builtin_mtime,		},
	{ "not",		builtin_not,		},
	{ "notdir",		builtin_entryname,	},
	{ "operating_system",	builtin_opsys,		},
	{ "options",		builtin_options,	},
	{ "or",			builtin_or,		},
	{ "os",			builtin_opsys,		},
	{ "pathname",		builtin_pathname,	},
	{ "patsubst",		builtin_fromto,		},
	{ "prepost",		builtin_prepost,	},
	{ "print",		builtin_print,	},
	{ "quote",		builtin_quote,		},
	{ "readlink",		builtin_readlink,	},
	{ "relative_dirname",	builtin_reldir,		},
	{ "reldir",		builtin_reldir,		},
	{ "resolve",		builtin_resolve,	},
	{ "shell",		builtin_collect,	},
	{ "sort",		builtin_sort,		},
	{ "sort_newest",	builtin_sort_newest,	},
	{ "split",		builtin_split,		},
	{ "stringset",		builtin_stringset,	},
	{ "strip",		builtin_strip,		},
	{ "subst",		builtin_subst,		},
	{ "substitute",		builtin_subst,		},
	{ "substr",		builtin_substr,		},
	{ "substring",		builtin_substr,		},
	{ "suffix",		builtin_suffix,		},
	{ "tail",		builtin_tail,		},
	{ "thread-id",		builtin_thread_id,	},
	{ "un-dos-path",	builtin_dos_path_undo,	},
	{ "unsplit",		builtin_unsplit,	},
	{ "upcase",		builtin_upcase,		},
	{ "uptodate",		builtin_uptodate,	},
	{ "wildcard",		builtin_glob,		},
	{ "word",		builtin_word,		},
	{ "wordlist",		builtin_wordlist,	},
	{ "words",		builtin_count,		},
};


/*
 * NAME
 *	builtin_initialize - start up builtins
 *
 * SYNOPSIS
 *	void builtin_initialize(void);
 *
 * DESCRIPTION
 *	The builtin_initialize function is used to initialize the symbol table
 *	with the names and pointers to the builtin functions.
 *
 * CAVEAT
 *	This function must be called after the id_initialize function.
 */

void
builtin_initialize()
{
	func_ty		*fp;
	string_ty	*s;

	for (fp = func; fp < ENDOF(func); ++fp)
	{
		s = str_from_c(fp->f_name);
		id_assign(s, id_builtin_new(fp->f_code));
		str_free(s);
	}
}
