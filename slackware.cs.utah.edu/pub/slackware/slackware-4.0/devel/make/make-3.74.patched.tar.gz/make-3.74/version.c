char *version_string = "3.74";

/*
  Local variables:
  version-control: never
  End:
 */
