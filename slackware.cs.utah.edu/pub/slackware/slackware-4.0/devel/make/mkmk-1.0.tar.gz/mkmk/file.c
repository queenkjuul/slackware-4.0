#include <string.h>
#include <stdio.h>

extern char DEFTARGET[255];
extern char DEFCC[255];
extern char DEFLIBS[255];
extern char DEFOBJECTS[255];
extern char DEFCFLAGS[255];
extern char DEFLIBDIR[255];
extern char DEFINCDIR[255];

void 
read_mgrc(FILE *mgrc)
{
  char string[255];
  char *p;
  int i;
  
  char *k[] = {"DEFCC","DEFLIBS","DEFCFLAGS","DEFLIBDIR",
		 "DEFINCDIR"};
  
  while(!feof(mgrc))
    {
      fgets(string,255,mgrc); 
      string[strlen(string)-1]=0;
      p=strtok(string,"= \t");
      for(i=0;i<5;++i)
	{
	  if((strcmp(k[i],string))==0)
	    {
	      p=strtok(NULL,"=");
		  switch(i)
		    {
		    case 0:
		      strcpy(DEFCC,p);
		      break;
		    case 1:
		      strcpy(DEFLIBS,p);
		      break;
		    case 2:
		      strcpy(DEFCFLAGS,p);
		      break;
		    case 3:
		      strcpy(DEFLIBDIR,p);
		      break;
		    case 4:
		      strcpy(DEFINCDIR,p);
		      break;
		    }
	    }
	}
    }
}

