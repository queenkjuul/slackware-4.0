#include <stdio.h>
void slib();
