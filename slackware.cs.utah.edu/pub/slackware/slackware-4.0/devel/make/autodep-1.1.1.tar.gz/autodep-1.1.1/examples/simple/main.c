/* autodep example for package without GNU Autoconf */
/* main.c */

#include "func.h"

int	main()
{
	printf("autodep test program\n");
	Func1();
	return 0;
}
