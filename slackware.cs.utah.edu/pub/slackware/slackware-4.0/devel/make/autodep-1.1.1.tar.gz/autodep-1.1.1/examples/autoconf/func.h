/* autodep example for package with GNU Autoconf */
/* func.h */

#include <stdio.h>

void	Func1();
