#include "slib.h"
int main()
{
	slib();
}
