#include "slib.h"
void slib()
{
	printf("OK\n");
}
