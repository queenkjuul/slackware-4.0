/* autodep example for package without GNU Autoconf */
/* func.h */

#include <stdio.h>

void	Func1();
