/* autodep example for package without GNU Autoconf */
/* func.c */

#include "func.h"

void	Func1()
{
	printf("Func1() called.\n");
}
