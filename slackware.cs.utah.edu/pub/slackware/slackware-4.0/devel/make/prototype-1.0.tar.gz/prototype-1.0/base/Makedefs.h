# This file contains the Project specific variables.
#
# The following variables can be used:
#

# Project "include" flags.
# The given directories will be relative to BASEDIR
#INCLUDEFLAGS+=-Ifoobar/include

# Project specific compiler flags
#CFLAGS+=-D__MYLIB__

# Project specific system <include> flags
#SYSTEMINCLUDEFLAGS+=-I/usr/local/obscurelib/include -Ifoobar/include

# Furthermore you can use this file to override any variable defined
# in $PROTODIR/Makedefs.h, if specifically needed for _this_ project.

# Project specific linker flags
#LDFLAGS+=-L${BASEDIR}/lib
