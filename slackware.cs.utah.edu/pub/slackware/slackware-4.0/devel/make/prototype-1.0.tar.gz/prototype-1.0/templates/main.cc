// $ Header$
//
// Author:
//
// 1024/624ACAD5 1997/01/26 Carlo Wood, Run on IRC <carlo@runaway.xs4all.nl>
// Key fingerprint = 32 EC A7 B6 AC DB 65 A6  F6 F6 55 DD 1C DC FF 61
// Get key from pgp-public-keys server or
// finger carlo@runaway.xs4all.nl for public key (dialin, try at 21-22h GMT).
//

#ifdef __GNUG__
#pragma implementation
#endif
#include "libr/sys.h"
#include <cstdio>
#include <getopt.h>
#include "libr/h.h"
#include "libr/debug.h"
#include "libr/libr_app.h"

RCSTAG_CC("$ Id$")

//=============================================================================
//
// show_version
//
// This function prints the version to cerr
//

void show_version(void)
{
  cerr << "xxxxxx_app, $ Revision$ -"
      " by Carlo Wood <carlo@runaway.xs4all.nl>" << endl;
}

//=============================================================================
//
// class xxxxxx_app_ct
//
// <Sort description>
//
// SYNOPSIS
//
// <Overview and remarks>
//

class xxxxxx_app_ct : public libr_app_tct<xxxxxx_app_ct> {
private:
  //---------------------------------------------------------------------------
  // Private attributes:
  //

public:
  //---------------------------------------------------------------------------
  // Public constructors and destructor:
  //

  xxxxxx_app_ct(void) { CTOR_LABEL("xxxxxx_app_ct"); }

public:
  //---------------------------------------------------------------------------
  // Public accessors:
  //

protected:
  //---------------------------------------------------------------------------
  // Protected accessors:
  //

  virtual const char *get_optstring(void) const
      { return "V"; }
    // Return the option string specific to this application.
    // See getopt(3). Example: "abd:o:"

  virtual const struct option *get_long_options(void) const
      { return user_long_options; }
    // Return the long options array.
    // See getopt_long(3) for details.

private:
  static int long_option;
  static struct option user_long_options[];

protected:
  //---------------------------------------------------------------------------
  // Events:
  //

  virtual void commandline_option(int code);
    // Called for every commandline option as defined in `get_optstring' that
    // this application was started with.

  virtual void long_commandline_option(struct option &long_option);
    // Called for every long commandline option as defined in `get_long_options'
    // this application was started with.

  virtual void options_done(int argc, char * const *argv);
    // Called when all commandline options have been processed (if any).

  virtual void start(void);
    // Called after decoding of the commandline options, before starting
    // the kernel.

  // /*HAS DEFAULT*/ virtual void received_signal(int sig);
    // This application received signal `sig'.
};

//=============================================================================
//
// user_long_options
//
// Array with with long options
//

int xxxxxx_app_ct::long_option;
struct option xxxxxx_app_ct::user_long_options[] = {
  { "version", 0, 0, 'V' },
  { 0, 0, 0, 0 }
};

//=============================================================================
//
// commandline_option
//
// A new commandline option is decoded.
// `optarg' points to an optional argument.
//

void xxxxxx_app_ct::commandline_option(int code)
{
  switch (code)
  {
    case '?':
      errflg = true;
      break;
    case 'V':
      show_version();
      libr_exit(0);
      break;
  }
}

//=============================================================================
//
// long_commandline_option
//
// A new long commandline option is decoded.
// `optarg' points to an optional argument.
//

void xxxxxx_app_ct::long_commandline_option(struct option &long_option_lp)
{
  cerr << "long commandline option: " << long_option_lp.name;
  if (optarg)
    cerr << " with argument " << optarg;
  cerr << endl;
}

//=============================================================================
//
// options_done
//
// All commandline options are decoded.
//
// `errflg' is set when an unknown option was given on the commandline.
// `argc' is the total number of arguments in the array `argv'.
// `argv' points to the start of an array of pointers to the commandline
// options. Note: these pointers are not in the same order as originally.
// argv[optind] gives the first commandline parameter (which is not already
// processed as option or option argument).  Following parameters are in
// argv[optind + 1], argv[optind + 2] ... argv[optind + argc - 1].
//

void xxxxxx_app_ct::options_done(int argc, char * const *argv)
{
  if (errflg)
  {
    show_version();
    cerr << "Options: " << argv[0];
    libr_usage(cerr, "\n  ");
    cerr << "\n   ... " << endl;
    libr_exit(2);
  }
  if (optind < argc) // Example code:
  {
    cerr << "Extra arguments:";
    for (; optind < argc; optind++)
      cerr << " " << argv[optind];
    cerr << endl;
  }
}

//=============================================================================
//
// start
//
// Application initialisation.
//

void xxxxxx_app_ct::start(void)
{
  // Print debug channels:
  Debug( levels );

  mainloop(); 	// Call fd_dct::terminate_when_done() to flush all buffers and
  		// return from this function.
}

//=============================================================================
//
// main
//
// Start application
//

int main(int argc, char **argv)
{
  return xxxxxx_app_ct::main(argc, argv);
}
