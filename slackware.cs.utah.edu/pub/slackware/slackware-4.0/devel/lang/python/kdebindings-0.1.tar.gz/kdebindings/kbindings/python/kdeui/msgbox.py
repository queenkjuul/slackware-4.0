import libkdeuipythonc
from qt.dialog import *


class KMsgBoxPtr(DialogPtr):

    INFORMATION = libkdeuipythonc.KMsgBox_INFORMATION
    EXCLAMATION = libkdeuipythonc.KMsgBox_EXCLAMATION
    STOP = libkdeuipythonc.KMsgBox_STOP
    QUESTION = libkdeuipythonc.KMsgBox_QUESTION

    DB_FIRST = libkdeuipythonc.KMsgBox_DB_FIRST
    DB_SECOND = libkdeuipythonc.KMsgBox_DB_SECOND
    DB_THIRD = libkdeuipythonc.KMsgBox_DB_THIRD
    DB_FOURTH = libkdeuipythonc.KMsgBox_DB_FOURTH

    def __init__(self,this,name=""):
        DialogPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete_KMsgBox(self.this)

    def __repr__(self):
        return "<KMsgBox instance at %s>" % self.this

class KMsgBox(KMsgBoxPtr):
    def __init__(self,parent="",caption="",message="",
                 flags=libkdeuipythonc.KMsgBox_INFORMATION,b1text="", 
                 b2text="",b3text="",b4text="",name="") :
	KMsgBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new_KMsgBox("NULL",caption,message,flags,b1text,b2text,b3text,b4text)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new_KMsgBox(parent.this,caption,message,flags,b1text,b2text,b3text,b4text)
	    self.thisown = 0	    



def KMsgBox_yesNo(*args):
    argl = map(None,args)
    try: argl[0] = argl[0].this
    except: pass
    args = tuple(argl)
    val = apply(libkdeuipythonc.KMsgBox_yesNo,()+args)
    return val

def KMsgBox_yesNoCancel(*args):
    argl = map(None,args)
    try: argl[0] = argl[0].this
    except: pass
    args = tuple(argl)
    val = apply(libkdeuipythonc.KMsgBox_yesNoCancel,()+args)
    return val

def KMsgBox_message(*args):
    argl = map(None,args)
    try: argl[0] = argl[0].this
    except: pass
    args = tuple(argl)
    val = apply(libkdeuipythonc.KMsgBox_message,()+args)
    return val
