#ifndef _KMENUBAR_H_
#define _KMENUBAR_H_

#include <Python.h>
#include <kmenubar.h>
#include <qintdict.h>
#include <qlist.h>
#include <qpopmenu.h>
#include "Baseobject.h"


class _MenuBar : public KMenuBar, BaseObject
{
    Q_OBJECT
public:

    _MenuBar(QWidget *parent=0, const char *name=0 );
   ~_MenuBar();

protected slots:

   void sigActivated(int id);
   void sigHighlighted(int id);
   void sigMoved(menuPosition);
   

/* ---- QMenuData ---- */


public:
   
    int	_insertItem( const char *text,PyObject *slot,int accel=0 );
 
    void _connectItem(int id, PyObject *slot);
    void _disconnectItem(int id, PyObject *slot);
    
private:

  QIntDict< QList<PyObject> > connections;

};

#endif
