import libqtpythonc
from dialog import *


class TabDialogPtr(DialogPtr):

    def __init__(self,this,name=""):
        DialogPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_TabDialog(self.this)

    def show(self):
        val = libqtpythonc.TabDialog_show(self.this)
        return val

    def setFont(self,arg0):
        val = libqtpythonc.TabDialog_setFont(self.this,arg0.this)
        return val

    def addTab(self,arg0,arg1):
        val = libqtpythonc.TabDialog_addTab(self.this,arg0.this,arg1)
        return val

    def isTabEnabled(self,arg0):
        val = libqtpythonc.TabDialog_isTabEnabled(self.this,arg0)
        return val

    def setTabEnabled(self,arg0,arg1):
        val = libqtpythonc.TabDialog_setTabEnabled(self.this,arg0,arg1)
        return val

    def showPage(self,arg0):
        val = libqtpythonc.TabDialog_showPage(self.this,arg0.this)
        return val

    def tabLabel(self,arg0):
        val = libqtpythonc.TabDialog_tabLabel(self.this,arg0.this)
        return val

    def setDefaultButton(self,*args):
        val = apply(libqtpythonc.TabDialog_setDefaultButton,(self.this,)+args)
        return val

    def hasDefaultButton(self):
        val = libqtpythonc.TabDialog_hasDefaultButton(self.this)
        return val

    def setCancelButton(self,*args):
        val = apply(libqtpythonc.TabDialog_setCancelButton,(self.this,)+args)
        return val

    def hasCancelButton(self):
        val = libqtpythonc.TabDialog_hasCancelButton(self.this)
        return val

    def setApplyButton(self,*args):
        val = apply(libqtpythonc.TabDialog_setApplyButton,(self.this,)+args)
        return val

    def hasApplyButton(self):
        val = libqtpythonc.TabDialog_hasApplyButton(self.this)
        return val

    def setOkButton(self,*args):
        val = apply(libqtpythonc.TabDialog_setOkButton,(self.this,)+args)
        return val

    def hasOkButton(self):
        val = libqtpythonc.TabDialog_hasOkButton(self.this)
        return val

    def __repr__(self):
        return "<TabDialog instance at %s>" % self.this

class TabDialog(TabDialogPtr):
    def __init__(self,parent="",name="",modal=0,flags=0):
	TabDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_TabDialog("NULL",name,modal,flags)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_TabDialog(parent.this,name,modal,flags)
	    self.thisown = 0	    
