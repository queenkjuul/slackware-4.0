import libkdeuipythonc
from qt.dialog import *
from qt.pushbutton import *


class KIconLoaderDialogPtr(DialogPtr):

    def __init__(self,this,name=""):
        DialogPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete_KIconLoaderDialog(self.this)

    def selectIcon(self,arg0,arg1):
        val = libkdeuipythonc.KIconLoaderDialog_selectIcon(self.this,arg0,arg1)
        val = QPixmapPtr(val)
        val.thisown = 1
        return val

    def setDir(self,arg0):
        val = libkdeuipythonc.KIconLoaderDialog_setDir(self.this,arg0)
        return val

    def execute(self,arg0):
        val = libkdeuipythonc.KIconLoaderDialog_exec(self.this,arg0)
        return val

    def __repr__(self):
        return "<KIconLoaderDialog instance at %s>" % self.this

class KIconLoaderDialog(KIconLoaderDialogPtr):
    def __init__(self,parent="",name=""):
	KIconLoaderDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new_KIconLoaderDialog("NULL",name)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new_KIconLoaderDialog(parent.this,name)
	    self.thisown = 0	    


def KIconLoaderDialogLoader(arg0,loader,parent="",name="") :
    KIconLoaderDialogPtr.__init__(self,"NULL",name)
    if not parent:
        self.this = libkdeuipythonc.new_KIconLoaderDialog(loader.this,"NULL",name)
        self.thisown = 1
    else:
        self.this = libkdeuipythonc.new_KIconLoaderDialog(loader.this, parent.this,name)
        self.thisown = 0	    



class KIconLoaderButtonPtr(PushButtonPtr) :

    def __init__(self,this,name=""):
        PushButtonPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__IconLoaderButton(self.this)

    def setIcon(self,arg0):
        val = libkdeuipythonc._IconLoaderButton_setIcon(self.this,arg0)
        return val

    def icon(self):
        val = libkdeuipythonc._IconLoaderButton_icon(self.this)
        return val

    def iconLoaderDialog(self):
        val = libkdeuipythonc._IconLoaderButton_iconLoaderDialog(self.this)
        val = KIconLoaderDialogPtr(val)
        return val

    def __repr__(self):
        return "<KIconLoaderButton instance at %s>" % self.this

class KIconLoaderButton(KIconLoaderButtonPtr):
    def __init__(self,arg0,name="") :
        KIconLoaderButtonPtr.__init__(self,"NULL",name)
        self.this = libkdeuipythonc.new__IconLoaderButton(arg0.this)
        self.thisown = 1



def KIconLoaderButtonLoader(arg0,arg1,name="") :
    val = _IconLoaderButtonPtr(libkdeuipythonc.new__IconLoaderButtonLoader(arg0.this,arg1.this),name)
    val.thisown = 1
    return val
