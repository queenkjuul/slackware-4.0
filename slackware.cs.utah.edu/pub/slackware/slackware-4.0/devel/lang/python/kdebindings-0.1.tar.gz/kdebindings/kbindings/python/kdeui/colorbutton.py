import libkdeuipythonc
from qt.color import *
from qt.pushbutton import *


class KColorButtonPtr(PushButtonPtr):

    def __init__(self,this,name=""):
        PushButtonPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__ColorButton(self.this)

    def color(self):
        val = libkdeuipythonc._ColorButton_color(self.this)
        val = ColorPtr(val)
        val.thisown = 1
        return val

    def setColor(self,arg0):
        val = libkdeuipythonc._ColorButton_setColor(self.this,arg0.this)
        return val

    def __repr__(self):
        return "<KColorButton instance at %s>" % self.this

class KColorButton(KColorButtonPtr):
    def __init__(self,color,parent="",name="") :
	KColorButtonPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__ColorButton(color,"NULL", name)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new__ColorButton(color,parent.this, name)
	    self.thisown = 0	    
