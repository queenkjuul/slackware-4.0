from qt.application import *
from qt.widget import *


# create an application

a = Application()


# methods

print App()


# add an widget

w = Widget()
w.show()
a.setMainWidget(w)


# methods

print a.argc(), a.argv()


# execute application

a.execute()


# delete application

del a