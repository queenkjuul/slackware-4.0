#include "KTabctl.h"
#include "KTabctl.moc"
