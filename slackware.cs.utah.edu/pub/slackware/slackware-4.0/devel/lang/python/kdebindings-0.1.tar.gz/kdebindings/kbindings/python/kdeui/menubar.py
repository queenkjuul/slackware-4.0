import libkdeuipythonc
from qt.frame import *


class KMenuBarPtr(FramePtr):

    Top = libkdeuipythonc._MenuBar_Top
    Bottom = libkdeuipythonc._MenuBar_Bottom
    Floating = libkdeuipythonc._MenuBar_Floating

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__MenuBar(self.this)

    def enableMoving(self,*args):
        val = apply(libkdeuipythonc._MenuBar_enableMoving,(self.this,)+args)
        return val

    def menuBarPos(self):
        val = libkdeuipythonc._MenuBar_menuBarPos(self.this)
        return val

    def enableFloating(self,*args):
        val = apply(libkdeuipythonc._MenuBar_enableFloating,(self.this,)+args)
        return val

    def setMenuBarPos(self,arg0):
        val = libkdeuipythonc._MenuBar_setMenuBarPos(self.this,arg0)
        return val

    def setTitle(self,arg0):
        val = libkdeuipythonc._MenuBar_setTitle(self.this,arg0)
        return val

    def count(self):
        val = libkdeuipythonc._MenuBar_count(self.this)
        return val

    def insertItem(self,arg0,arg1,*args):
        val = apply(libkdeuipythonc._MenuBar__insertItem,(self.this,arg0,arg1,)+args)
        return val

    def insertItemAt(self,arg0,*args):
        val = apply(libkdeuipythonc._MenuBar_insertItemAt,(self.this,arg0,)+args)
        return val

    def popupItemAt(self,arg0,arg1,*args):
        val = apply(libkdeuipythonc._MenuBar_popupItemAt,(self.this,arg0,arg1.this,)+args)
        return val

    def insertSeparator(self,*args):
        val = apply(libkdeuipythonc._MenuBar_insertSeparator,(self.this,)+args)
        return val

    def removeItem(self,arg0):
        val = libkdeuipythonc._MenuBar_removeItem(self.this,arg0)
        return val

    def removeItemAt(self,arg0):
        val = libkdeuipythonc._MenuBar_removeItemAt(self.this,arg0)
        return val

    def clear(self):
        val = libkdeuipythonc._MenuBar_clear(self.this)
        return val

    def accel(self,arg0):
        val = libkdeuipythonc._MenuBar_accel(self.this,arg0)
        return val

    def setAccel(self,arg0,arg1):
        val = libkdeuipythonc._MenuBar_setAccel(self.this,arg0,arg1)
        return val

    def text(self,arg0):
        val = libkdeuipythonc._MenuBar_text(self.this,arg0)
        return val

    def changeItem(self,arg0,arg1):
        val = libkdeuipythonc._MenuBar_changeItem(self.this,arg0,arg1)
        return val

    def setItemChecked(self,arg0,arg1):
        val = libkdeuipythonc._MenuBar_setItemChecked(self.this,arg0,arg1)
        return val

    def setItemEnabled(self,arg0,arg1):
        val = libkdeuipythonc._MenuBar_setItemEnabled(self.this,arg0,arg1)
        return val

    def heightForWidth(self,arg0):
        val = libkdeuipythonc._MenuBar_heightForWidth(self.this,arg0)
        return val

    def connectItem(self,arg0,arg1):
        val = libkdeuipythonc._MenuBar__connectItem(self.this,arg0,arg1)
        return val

    def disconnectItem(self,arg0,arg1):
        val = libkdeuipythonc._MenuBar__disconnectItem(self.this,arg0,arg1)
        return val

    def __repr__(self):
        return "<KMenuBar instance at %s>" % self.this

class KMenuBar(KMenuBarPtr):
    def __init__(self,parent="",name=""):
	KMenuBarPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__MenuBar("NULL", name)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__MenuBar(parent.this, name)
	    self.thisown = 0	    
