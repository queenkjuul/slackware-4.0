import libqtpythonc
from color import *
from baseobject import *


class QPalettePtr(BaseObjectPtr) :

    def __init__(self,this,name=""):
        BaseObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QPalette(self.this)

    def copy(self):
        val = libqtpythonc.QPalette_copy(self.this)
        val = QPalettePtr(val)
        val.thisown = 1
        return val

    def normal(self):
        val = libqtpythonc.QPalette_normal(self.this)
        val = QColorGroupPtr(val)
        return val

    def disabled(self):
        val = libqtpythonc.QPalette_disabled(self.this)
        val = QColorGroupPtr(val)
        return val

    def active(self):
        val = libqtpythonc.QPalette_active(self.this)
        val = QColorGroupPtr(val)
        return val

    def setNormal(self,arg0):
        val = libqtpythonc.QPalette_setNormal(self.this,arg0.this)
        return val

    def setDisabled(self,arg0):
        val = libqtpythonc.QPalette_setDisabled(self.this,arg0.this)
        return val

    def setActive(self,arg0):
        val = libqtpythonc.QPalette_setActive(self.this,arg0.this)
        return val

    def serialNumber(self):
        val = libqtpythonc.QPalette_serialNumber(self.this)
        return val

    def __repr__(self):
        return "<Palette instance at %s>" % self.this


class QPalette(QPalettePtr):
    def __init__(self,name="") :
        QPalettePtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_QPalette()
        self.thisown = 1



def QPaletteColor(arg0,name="") :
    val = QPalettePtr(libqtpythonc.new_QPaletteColor(arg0.this),name)
    val.thisown = 1
    return val

def QPaletteColorGroups(arg0,arg1,arg2,name="") :
    val = QPalettePtr(libqtpythonc.new_QPaletteColorGroups(arg0.this,arg1.this,arg2.this),name)
    val.thisown = 1
    return val

def QPaletteCopy(arg0,name="") :
    val = QPalettePtr(libqtpythonc.new_QPaletteCopy(arg0.this),name)
    val.thisown = 1
    return val

