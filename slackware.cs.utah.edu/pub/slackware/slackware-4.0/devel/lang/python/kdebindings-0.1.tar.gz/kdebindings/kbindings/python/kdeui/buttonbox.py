import libkdeuipythonc
from qt.widget import *

class KButtonBoxPtr(WidgetPtr):

    VERTICAL = libkdeuipythonc.KButtonBox_VERTICAL
    HORIZONTAL = libkdeuipythonc.KButtonBox_HORIZONTAL

    def __init__(self,this,name=""):
        WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete_KButtonBox(self.this)

    def addButton(self,arg0,*args):
        val = apply(libkdeuipythonc.KButtonBox_addButton,(self.this,arg0,)+args)
        return val

    def addStretch(self,*args):
        val = apply(libkdeuipythonc.KButtonBox_addStretch,(self.this,)+args)
        return val

    def layout(self):
        val = libkdeuipythonc.KButtonBox_layout(self.this)
        return val

    def __repr__(self):
        return "<KButtonBox instance at %s>" % self.this

class KButtonBox(KButtonBoxPtr):
    def __init__(self,parent,orientation=libkdeuipythonc.KButtonBox_HORIZONTAL,border=0,autoborder=6,name="") :
	KButtonBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new_KButtonBox("NULL",orientation,border,autoborder,name)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new_KButtonBox(parent.this,orientation,border,autoborder,name)
	    self.thisown = 0	    
