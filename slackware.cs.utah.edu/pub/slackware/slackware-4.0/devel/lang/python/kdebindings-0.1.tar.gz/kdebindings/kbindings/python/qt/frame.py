from widget import *
import libqtpythonc


class FramePtr(WidgetPtr):

    NoFrame = libqtpythonc.QFrame_NoFrame
    Box = libqtpythonc.QFrame_Box
    Panel = libqtpythonc.QFrame_Panel
    WinPanel = libqtpythonc.QFrame_WinPanel
    HLine = libqtpythonc.QFrame_HLine
    VLine = libqtpythonc.QFrame_VLine
    MShape = libqtpythonc.QFrame_MShape
    Plain = libqtpythonc.QFrame_Plain
    Raised = libqtpythonc.QFrame_Raised
    Sunken = libqtpythonc.QFrame_Sunken
    MShadow = libqtpythonc.QFrame_MShadow

    def __init__(self,this,name=""):
	WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QFrame(self.this)

    def frameStyle(self):
        return libqtpythonc.QFrame_frameStyle(self.this)

    def frameShape(self):
        return libqtpythonc.QFrame_frameShape(self.this)

    def frameShadow(self):
        return libqtpythonc.QFrame_frameShadow(self.this)

    def setFrameStyle(self,arg0):
        libqtpythonc.QFrame_setFrameStyle(self.this,arg0)

    def lineShapesOk(self):
        return libqtpythonc.QFrame_lineShapesOk(self.this)

    def lineWidth(self):
        return libqtpythonc.QFrame_lineWidth(self.this)

    def setLineWidth(self,arg0):
        libqtpythonc.QFrame_setLineWidth(self.this,arg0)

    def midLineWidth(self):
        return libqtpythonc.QFrame_midLineWidth(self.this)

    def setMidLineWidth(self,arg0):
        libqtpythonc.QFrame_setMidLineWidth(self.this,arg0)

    def frameWidth(self):
        return libqtpythonc.QFrame_frameWidth(self.this)

    def frameRect(self):
        return libqtpythonc.QFrame_frameRect(self.this)

    def contentsRect(self):
        return libqtpythonc.QFrame_contentsRect(self.this)

    def __repr__(self):
        return "<Frame instance at %s>" % self.this

class Frame(FramePtr):
    def __init__(self,parent="",name="", flags=0, allowLines=1):
	FramePtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_QFrame("NULL", name, flags, allowLines)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_QFrame(parent.this, name, flags, allowLines)
	    self.thisown = 0	    
