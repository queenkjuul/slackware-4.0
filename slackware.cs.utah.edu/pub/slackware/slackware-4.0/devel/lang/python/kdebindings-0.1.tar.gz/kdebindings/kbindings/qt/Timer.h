#ifndef _TIMER_H_
#define _TIMER_H_

#include <qtimer.h>
#include "Baseobject.h"


class Timer : public QTimer, public BaseObject
{
  Q_OBJECT

public:

  Timer(QObject *parent=0, const char *name=0) 
    : QTimer(parent,name), BaseObject() {
    connect(this, SIGNAL(timeout()), this, SLOT(sigTimeout()));
  };
  ~Timer() {};

protected slots:

  void sigTimeout() {
    _emit("timeout", 0);
  }    
  
};

#endif
