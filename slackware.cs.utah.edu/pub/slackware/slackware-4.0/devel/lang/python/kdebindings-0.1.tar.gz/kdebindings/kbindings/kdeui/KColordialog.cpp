#include "KColordialog.h"
#include "KColordialog.moc"
