import libkdecorepythonc
from qt.baseobject import *


class KURLPtr(BaseObjectPtr) :

    def __init__(self,this,name=""):
 	BaseObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete_KURL(self.this)

    def isMalformed(self):
        val = libkdecorepythonc.KURL_isMalformed(self.this)
        return val

    def url(self):
        val = libkdecorepythonc.KURL_url(self.this)
        return val

    def protocol(self):
        val = libkdecorepythonc.KURL_protocol(self.this)
        return val

    def host(self):
        val = libkdecorepythonc.KURL_host(self.this)
        return val

    def path(self):
        val = libkdecorepythonc.KURL_path(self.this)
        return val

    def hasPath(self):
        val = libkdecorepythonc.KURL_hasPath(self.this)
        return val

    def reference(self):
        val = libkdecorepythonc.KURL_reference(self.this)
        return val

    def user(self):
        val = libkdecorepythonc.KURL_user(self.this)
        return val

    def passwd(self):
        val = libkdecorepythonc.KURL_passwd(self.this)
        return val

    def port(self):
        val = libkdecorepythonc.KURL_port(self.this)
        return val

    def directory(self,*args):
        val = apply(libkdecorepythonc.KURL_directory,(self.this,)+args)
        return val

    def directoryURL(self,*args):
        val = apply(libkdecorepythonc.KURL_directoryURL,(self.this,)+args)
        return val

    def hasSubProtocol(self):
        val = libkdecorepythonc.KURL_hasSubProtocol(self.this)
        return val

    def parentURL(self):
        val = libkdecorepythonc.KURL_parentURL(self.this)
        return val

    def childURL(self):
        val = libkdecorepythonc.KURL_childURL(self.this)
        return val

    def nestedURL(self):
        val = libkdecorepythonc.KURL_nestedURL(self.this)
        return val

    def parse(self,arg0):
        val = libkdecorepythonc.KURL_parse(self.this,arg0)
        return val

    def setProtocol(self,arg0):
        val = libkdecorepythonc.KURL_setProtocol(self.this,arg0)
        return val

    def setPassword(self,arg0):
        val = libkdecorepythonc.KURL_setPassword(self.this,arg0)
        return val

    def setReference(self,arg0):
        val = libkdecorepythonc.KURL_setReference(self.this,arg0)
        return val

    def cd(self,arg0,*args):
        val = apply(libkdecorepythonc.KURL_cd,(self.this,arg0,)+args)
        return val

    def cdUp(self,*args):
        val = apply(libkdecorepythonc.KURL_cdUp,(self.this,)+args)
        return val

    def filename(self):
        val = libkdecorepythonc.KURL_filename(self.this)
        return val

    def isLocalFile(self):
        val = libkdecorepythonc.KURL_isLocalFile(self.this)
        return val

    def __repr__(self):
        return "<KURL instance at %s>" % self.this

class KURL(KURLPtr):
    def __init__(self,name="") :
	KURLPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new_KURL()
        self.thisown = 1

def KURLInit(arg0,name="") :
    val = KURLPtr(libkdecorepythonc.new_KURLInit(arg0),name)
    val.thisown = 1
    return val

def KURLProtocol(arg0,arg1,arg2,arg3,name="") :
    val = KURLPtr(libkdecorepythonc.new_KURLProtocol(arg0,arg1,arg2,arg3),name)
    val.thisown = 1
    return val

def KURLBase(arg0,arg1,name="") :
    val = KURLPtr(libkdecorepythonc.new_KURLBase(arg0.this,arg1),name)
    val.thisown = 1
    return val


KURL_encodeURL = libkdecorepythonc.KURL_encodeURL

KURL_decodeURL = libkdecorepythonc.KURL_decodeURL
