from widget import *
from rangecontrol import *
import libqtpythonc


class SliderPtr(WidgetPtr,RangeControlPtr):

    Horizontal = libqtpythonc.Slider_Horizontal
    Vertical = libqtpythonc.Slider_Vertical

    NoMarks = libqtpythonc.Slider_NoMarks
    Above = libqtpythonc.Slider_Above
    Left = libqtpythonc.Slider_Left
    Below = libqtpythonc.Slider_Below
    Right = libqtpythonc.Slider_Right
    Both = libqtpythonc.Slider_Both

    def __init__(self,this,name=""):
	WidgetPtr.__init__(self,this,name)
        RangeControlPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QSlider(self.this)

    def setOrientation(self,orientation):
        return libqtpythonc.Slider_setOrientation(self.this,orientation)

    def orientation(self):
        return libqtpythonc.Slider_orientation(self.this)

    def setTracking(self,tracking):
        libqtpythonc.Slider_setTracking(self.this,tracking)

    def tracking(self):
        return libqtpythonc.Slider_tracking(self.this)

    def sliderRect(self):
        return libqtpythonc.Slider_sliderRect(self.this)

    def setTickmarks(self,tickmarks):
        libqtpythonc.Slider_setTickmarks(self.this,tickmarks)

    def tickmarks(self):
        return libqtpythonc.Slider_tickmarks(self.this)

    def setTickInterval(self,interval):
        libqtpythonc.Slider_setTickInterval(self.this,interval)

    def tickInterval(self):
        return libqtpythonc.Slider_tickInterval(self.this)

    def setValue(self,value):
        libqtpythonc.Slider_setValue(self.this,arg0)

    def addStep(self):
        libqtpythonc.Slider_addStep(self.this)

    def subtractStep(self):
        libqtpythonc.Slider_subtractStep(self.this)

    def __repr__(self):
        return "<Slider instance at %s>" % self.this

class Slider(SliderPtr):
    def __init__(self,min=0,max=99,step=1,value=0,orientation=libqtpythonc.Slider_Horizontal,parent="",name=""):
	SliderPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_Slider(min,max,step,value,orientation,"NULL",name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_Slider(min,max,step,value,orientation,parent.this,name)
	    self.thisown = 0	    
