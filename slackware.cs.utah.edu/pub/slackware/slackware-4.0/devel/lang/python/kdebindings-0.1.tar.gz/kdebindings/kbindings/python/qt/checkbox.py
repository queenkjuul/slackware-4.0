from baseobject import *
from button import *
import libqtpythonc


class CheckBoxPtr(ButtonPtr):

    def __init__(self,this,name=""):
	ButtonPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_CheckBox(self.this)

    def isChecked(self):
        return libqtpythonc.CheckBox_isChecked(self.this)

    def setChecked(self,arg0):
        libqtpythonc.CheckBox_setChecked(self.this,arg0)

    def __repr__(self):
        return "<CheckBox instance at %s>" % self.this

class CheckBox(CheckBoxPtr):
    def __init__(self,text,parent="",name=""):
	CheckBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_CheckBox(text,"NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_CheckBox(text,parent.this, name)
	    self.thisown = 0	    

