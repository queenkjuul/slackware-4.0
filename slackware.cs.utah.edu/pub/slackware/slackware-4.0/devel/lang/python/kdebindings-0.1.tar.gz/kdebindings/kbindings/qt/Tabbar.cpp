#include "Tabbar.h"
#include "Tabbar.moc"


int TabBar::_addTab(const char *tabname)
{
  QTab *t = new QTab();
  t->label = tabname;
  addTab(t);
}

char *TabBar::_tab(int index)
{
  QTab *t = tab(index);
  return t->label.data();
}