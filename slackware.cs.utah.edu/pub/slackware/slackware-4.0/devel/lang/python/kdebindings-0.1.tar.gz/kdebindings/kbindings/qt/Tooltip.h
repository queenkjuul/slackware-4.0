#ifndef _TOOLTIP_H_
#define _TOOLTIP_H_

#include <qtooltip.h>
#include "Object.h"
#include "Baseobject.h"


class ToolTip : public QToolTip, BaseObject
{
public:

  ToolTip(QWidget *widget, QToolTipGroup *group=0) : QToolTip(widget,group) {};
  virtual ~ToolTip() {}; 

protected:
    
  void maybeTip(const QPoint &) {};
  
};


#endif