import libkdeuipythonc 
from qt.lineedit import *


class KRestrictedLinePtr(LineEditPtr):

    def __init__(self,this,name=""):
        LineEditPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__RestrictedLine(self.this)

    def setValidChars(self,arg0):
        val = libkdeuipythonc._RestrictedLine_setValidChars(self.this,arg0)
        return val

    def __repr__(self):
        return "<KRestrictedLine instance at %s>" % self.this

class KRestrictedLine(KRestrictedLinePtr):
    def __init__(self,parent="",name="",valid=""):
	KRestrictedLinePtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__RestrictedLine("NULL", name, valid)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new__RestrictedLine(parent.this, name, valid)
	    self.thisown = 0	    

