#include "KSlider.h"
#include "KSlider.moc"
