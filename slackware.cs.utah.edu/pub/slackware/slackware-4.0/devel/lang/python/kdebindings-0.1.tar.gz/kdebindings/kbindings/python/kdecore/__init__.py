from libqtpythonc import *

print "KDE-Library loaded!"