import libqtpythonc
from frame import *


class ListBoxPtr(FramePtr):

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_ListBox(self.this)

    def count(self):
        val = libqtpythonc.ListBox_count(self.this)
        return val

    def insertStrList(self,arg0,*args):
        val = apply(libqtpythonc.ListBox_insertStrList,(self.this,arg0,)+args)
        return val

    def insertItem(self,arg0,*args):
        val = apply(libqtpythonc.ListBox_insertItem,(self.this,arg0,)+args)
        return val

    def insertPixmap(self,arg0,*args):
        val = apply(libqtpythonc.ListBox_insertPixmap,(self.this,arg0.this,)+args)
        return val

    def inSort(self,arg0):
        val = libqtpythonc.ListBox_inSort(self.this,arg0)
        return val

    def removeItem(self,arg0):
        val = libqtpythonc.ListBox_removeItem(self.this,arg0)
        return val

    def clear(self):
        val = libqtpythonc.ListBox_clear(self.this)
        return val

    def text(self,arg0):
        val = libqtpythonc.ListBox_text(self.this,arg0)
        return val

    def pixmap(self,arg0):
        val = libqtpythonc.ListBox_pixmap(self.this,arg0)
        val = PixmapPtr(val)
        return val

    def changeItem(self,arg0,arg1):
        val = libqtpythonc.ListBox_changeItem(self.this,arg0,arg1)
        return val

    def changePixmap(self,arg0,arg1):
        val = libqtpythonc.ListBox_changePixmap(self.this,arg0.this,arg1)
        return val

    def autoUpdate(self):
        val = libqtpythonc.ListBox_autoUpdate(self.this)
        return val

    def setAutoUpdate(self,arg0):
        val = libqtpythonc.ListBox_setAutoUpdate(self.this,arg0)
        return val

    def numItemsVisible(self):
        val = libqtpythonc.ListBox_numItemsVisible(self.this)
        return val

    def currentItem(self):
        val = libqtpythonc.ListBox_currentItem(self.this)
        return val

    def setCurrentItem(self,arg0):
        val = libqtpythonc.ListBox_setCurrentItem(self.this,arg0)
        return val

    def centerCurrentItem(self):
        val = libqtpythonc.ListBox_centerCurrentItem(self.this)
        return val

    def topItem(self):
        val = libqtpythonc.ListBox_topItem(self.this)
        return val

    def setTopItem(self,arg0):
        val = libqtpythonc.ListBox_setTopItem(self.this,arg0)
        return val

    def dragSelect(self):
        val = libqtpythonc.ListBox_dragSelect(self.this)
        return val

    def setDragSelect(self,arg0):
        val = libqtpythonc.ListBox_setDragSelect(self.this,arg0)
        return val

    def autoScroll(self):
        val = libqtpythonc.ListBox_autoScroll(self.this)
        return val

    def setAutoScroll(self,arg0):
        val = libqtpythonc.ListBox_setAutoScroll(self.this,arg0)
        return val

    def autoScrollBar(self):
        val = libqtpythonc.ListBox_autoScrollBar(self.this)
        return val

    def setAutoScrollBar(self,arg0):
        val = libqtpythonc.ListBox_setAutoScrollBar(self.this,arg0)
        return val

    def scrollBar(self):
        val = libqtpythonc.ListBox_scrollBar(self.this)
        return val

    def setScrollBar(self,arg0):
        val = libqtpythonc.ListBox_setScrollBar(self.this,arg0)
        return val

    def autoBottomScrollBar(self):
        val = libqtpythonc.ListBox_autoBottomScrollBar(self.this)
        return val

    def setAutoBottomScrollBar(self,arg0):
        val = libqtpythonc.ListBox_setAutoBottomScrollBar(self.this,arg0)
        return val

    def bottomScrollBar(self):
        val = libqtpythonc.ListBox_bottomScrollBar(self.this)
        return val

    def setBottomScrollBar(self,arg0):
        val = libqtpythonc.ListBox_setBottomScrollBar(self.this,arg0)
        return val

    def smoothScrolling(self):
        val = libqtpythonc.ListBox_smoothScrolling(self.this)
        return val

    def setSmoothScrolling(self,arg0):
        val = libqtpythonc.ListBox_setSmoothScrolling(self.this,arg0)
        return val

    def itemHeight(self):
        val = libqtpythonc.ListBox_itemHeight(self.this)
        return val

    def itemHeightAt(self,arg0):
        val = libqtpythonc.ListBox_itemHeightAt(self.this,arg0)
        return val

    def maxItemWidth(self):
        val = libqtpythonc.ListBox_maxItemWidth(self.this)
        return val

    def isMultiSelection(self):
        val = libqtpythonc.ListBox_isMultiSelection(self.this)
        return val

    def setMultiSelection(self,arg0):
        val = libqtpythonc.ListBox_setMultiSelection(self.this,arg0)
        return val

    def setSelected(self,arg0,arg1):
        val = libqtpythonc.ListBox_setSelected(self.this,arg0,arg1)
        return val

    def isSelected(self,arg0):
        val = libqtpythonc.ListBox_isSelected(self.this,arg0)
        return val

    def clearSelection(self):
        val = libqtpythonc.ListBox_clearSelection(self.this)
        return val

    def __repr__(self):
        return "<ListBox instance at %s>" % self.this

class ListBox(ListBoxPtr):
    def __init__(self,parent="",name=""):
	ListBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_ListBox("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_ListBox(parent.this, name)
	    self.thisown = 0	    
