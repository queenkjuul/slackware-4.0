import libkdecorepythonc
from qt.baseobject import *


class KLocalePtr(BaseObjectPtr):

    def __init__(self,this,name=""):
        BaseObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete_KLocale(self.this)

    def translate(self,arg0):
        val = libkdecorepythonc.KLocale_translate(self.this,arg0)
        return val

    def aliasLocale(self,arg0,arg1):
        val = libkdecorepythonc.KLocale_aliasLocale(self.this,arg0,arg1)
        return val

    def getAlias(self,arg0):
        val = libkdecorepythonc.KLocale_getAlias(self.this,arg0)
        return val

    def language(self):
        val = libkdecorepythonc.KLocale_language(self.this)
        return val

    def charset(self):
        val = libkdecorepythonc.KLocale_charset(self.this)
        return val

    def directory(self):
        val = libkdecorepythonc.KLocale_directory(self.this)
        return val

    def __repr__(self):
        return "<KLocale instance at %s>" % self.this

class KLocale(KLocalePtr):
    def __init__(self,catalog="",name="") :
        KLocalePtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new_KLocale(catalog)
        self.thisown = 1
