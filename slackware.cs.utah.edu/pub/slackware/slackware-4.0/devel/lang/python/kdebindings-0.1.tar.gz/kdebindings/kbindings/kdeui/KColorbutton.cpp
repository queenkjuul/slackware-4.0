#include "KColorbutton.h"
#include "KColorbutton.moc"
