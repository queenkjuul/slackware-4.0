#ifndef _PROGRESSDIALOG_H_
#define _PROGRESSDIALOG_H_

#include "qprogdlg.h"
#include "Baseobject.h"


class ProgressDialog : public QProgressDialog, BaseObject
{
  Q_OBJECT	

public:

  ProgressDialog(const char *labelText, const char *cancelButtonText, int totalSteps,
                 QWidget *parent=0, const char *n=0, bool modal=FALSE, WFlags f=0)
    : QProgressDialog(labelText, cancelButtonText, totalSteps, parent, n, modal, f), BaseObject()  
  {
    connect(this, SIGNAL(cancelled()), this, SLOT(sigCancelled()));       
  };
  ~ProgressDialog() {}; 

 protected slots:

    void sigCancelled() {
      _emit("cancelled", 0);
    };

};

#endif
