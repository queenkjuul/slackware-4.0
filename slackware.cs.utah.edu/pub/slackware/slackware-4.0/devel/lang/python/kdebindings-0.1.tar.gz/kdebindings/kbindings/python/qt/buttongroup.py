from groupbox import *
import libqtpythonc

class ButtonGroupPtr(GroupBoxPtr):

    def __init__(self,this,name=""):
	GroupBoxPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QButtonGroup(self.this)

    def isExclusive(self):
        return libqtpythonc.QButtonGroup_isExclusive(self.this)

    def setExclusive(self,arg0):
        libqtpythonc.QButtonGroup_setExclusive(self.this,arg0)

    def insert(self,button,id=-1):
        return libqtpythonc.QButtonGroup_insert(self.this,button.this,id)

    def remove(self,button):
        libqtpythonc.QButtonGroup_remove(self.this,button.this)

    def find(self,id):
        val = ButtonPtr(libqtpythonc.QButtonGroup_find(self.this,id))
	self.thisown = 0
        return val

    def __repr__(self):
        return "<ButtonGroup instance at %s>" % self.this

class ButtonGroup(ButtonGroupPtr):
    def __init__(self,title,parent="",name=""):
	ButtonGroupPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_QButtonGroup(title, "NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_QButtonGroup(title, parent.this, name)
	    self.thisown = 0	    




