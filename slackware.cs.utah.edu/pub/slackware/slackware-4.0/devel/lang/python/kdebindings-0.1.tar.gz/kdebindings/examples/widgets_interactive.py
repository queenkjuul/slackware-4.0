from qt.application import *
from qt.widget import *
from qt.color import *
from qt.pushbutton import *
from qt.checkbox import *
from qt.radiobutton import *
from qt.frame import *
from qt.groupbox import *
from qt.buttongroup import *
from qt.combobox import *
from qt.lcdnumber import *
from qt.label import *
from qt.progressbar import *
from qt.lineedit import *
from qt.progressdialog import *
from qt.slider import *
from qt.scrollbar import *
from qt.multilineedit import *
from qt.pixmap import *
from qt.font import *
from qt.menubar import *
from qt.popupmenu import *
from qt.listbox import *
from qt.tabbar import *
from qt.colorgroup import *
from qt.cursor import *
from qt.fontinfo import *
from qt.fontmetrics import *
from qt.timer import *
from qt.painter import *
from qt.pen import *
from qt.region import *
from qt.paintdevicemetrics import *
from qt.brush import *
from qt.palette import *
from qt.image import *
from qt.clipboard import *
from qt.picture import *
from qt.printer import *
from qt.tooltip import *
from qt.tooltipgroup import *
from qt.wmatrix import *
from qt.layout import *
from qt.boxlayout import *
from qt.hboxlayout import *
from qt.vboxlayout import *


def b_pressed():
   if c.isChecked():
     a.quit()
   print "pressed"

def released():
   print "released"

def clicked():
   print "clicked"

def toggled(tog):
   print "toggled", tog

def checked():
   print "checked"

def radio():
   print "starting progress dialog"
   pd = ProgressDialog("This is progress", "&Cancel", 100, w)
   pd.show()

def activated(index):
   print "You selected item", index

def overflow():
   print "Overflow occured"

a = Application()

w = Widget()
w.setCaption("Hello World")
w.setBackgroundColor(w.colorGroup().midlight())
w.setCursor(CursorShape(WaitCursor))

def menu_act(id):
  print "menu activated", id
  
def menu_high(id):
  print "menu highlighted", id

def help():
  print "help!"
    
mn = MenuBar(w)
mn.insertItemAt("Test")
#mn.connect("activated", menu_act)
#mn.connect("highlighted", menu_high)
mn.insertSeparator()
id = mn.insertItem("&Help", help)
mn.disconnectItem(id, help)

b = PushButton("Press me",w)
ToolTip_add(b, "Press this button to quit!")

fn = Font("Courier", 18, Font.Bold)
print fn.key()

b.setFont(fn)

fi = FontInfo(fn)
print "FontInfo: ", fi.family(), fi.pointSize(), fi.styleHint()

fm = FontMetrics(fn)
print "FontMetrics: ", fm.boundingRect("TestString")

b.connect("pressed", a.quit)
b.connect("release", released)
b.connect("clicked", clicked)

b.setGeometry((16,16,100,32))

c = CheckBox("Check me",w)
c.connect("checked", checked)
c.connect("toggled", toggled)
c.setGeometry((16,50,100,32))

r = RadioButton("select me", w)
r.connect("pressed", radio)
r.setGeometry((16,84,100,32))

f = Frame(w)
f.setGeometry((16,150,100,100))
f.setFrameStyle(Frame.Panel + Frame.Raised)
f.setLineWidth(5)

g = GroupBox("This is a group", w)
g.setGeometry((120,16,200,200))

group = ButtonGroup("Buttons", w)
group.setGeometry((120,220,200,200))
group.setExclusive(1)

b1 = RadioButton("Button 1", group)
b1.move((16,16))
b2 = RadioButton("Button 2", group)
b2.move((16,48))
b3 = RadioButton("Button 3", group)
b3.move((16,80))

cb = ComboBox(w)
cb.insertStrList(["Eins","Zwei","Drei"])
cb.move((16,260))
cb.connect("activated", activated)

lcd = LCDNumber(w)
lcd.display(12345)
lcd.move((16,300))
lcd.connect("overflow", overflow)
lcd.display(12312313)

l = Label("Simple label", w)
l.move((16,330))


l2 = LabelBuddy(cb,"&Label->Combobox",w)
l2.setBuddy(cb)
l2.move((16,350))

pb = ProgressBar(100,w)
pb.setProgress(42)
pb.move((340,16,200,32))

def change(text):
    print "Text changed: ", text
  
ed = LineEdit(w)
ed.move((340,50,300,32))
ed.connect("textChanged", change)


def valueChanged(value):
  print "value changed:", value
  pb.setProgress(value)

sl = Slider(0,100,5,0,Slider.Horizontal,w)
sl.move((340,96,300,32))
sl.connect("valueChanged", valueChanged)

sb=ScrollBar(0,100,1,20,0,Slider.Horizontal,w)
sb.setGeometry((16,440,400,16))
sb.connect("valueChanged", valueChanged)

me = MultiLineEdit(w)
me.setGeometry((510,16,400,400))

pm = PixmapFile("test.gif")
print pm, pm.isNull()

pdm = PaintDeviceMetrics(pm)
print "Bitmap: ", pdm.widthMM(),"mm breit"

pen = PenColor(red,5)

painter = Painter()
painter.begin(pm)
painter.setPen(pen)
painter.drawEllipse((0,0,100,50))

print "Clipper:", painter.clipRegion()

painter.end()

w.setBackgroundPixmap(pm)

lb = ListBox(w)
lb.insertStrList(["Deutsch","Englisch","Spanisch","Niederl�ndisch"])
lb.setGeometry((340,200,100,80))

tb = TabBar(w)
tb.setShape(TabBar.TriangularBelow)
tb.addTab("Hallo")
tb.setTabEnabled(0,1)
tb.addTab("Welt")
tb.setTabEnabled(1,1)
tb.setGeometry((340,300,200,20))

w.show()
a.setMainWidget(w)


pop = PopupMenu()
pop.insertItemAt("Hallo")
pop.insertItemAt("Sowas")
pop.insertItem("Naja", help)
pop2 = PopupMenu()
pop2.insertItemAt("Hallo")
pop2.insertItemAt("Sowas")
pop2.insertItem("Naja", help)

pop.popupItemAt("next level", pop2)
mn.popupItemAt("Popup", pop)

def timeout():
  print "1 more second"
  
t = Timer()
t.connect("timeout", timeout)
t.start(1000)

a.execute()
del a
del fn