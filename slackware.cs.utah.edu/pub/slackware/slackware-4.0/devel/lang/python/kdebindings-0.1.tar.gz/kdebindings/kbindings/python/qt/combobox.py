import libqtpythonc
from baseobject import *
from object import *
from widget import *
from pixmap import *


class ComboBoxPtr(WidgetPtr):

    NoInsertion = libqtpythonc.ComboBox_NoInsertion
    AtTop = libqtpythonc.ComboBox_AtTop
    AtCurrent = libqtpythonc.ComboBox_AtCurrent
    AtBottom = libqtpythonc.ComboBox_AtBottom
    AfterCurrent = libqtpythonc.ComboBox_AfterCurrent
    BeforeCurrent = libqtpythonc.ComboBox_BeforeCurrent

    def __init__(self,this,name=""):
	WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_ComboBox(self.this)

    def count(self):
        return libqtpythonc.ComboBox_count(self.this)

    def insertStrList(self,strings,index=-1):
        libqtpythonc.ComboBox_insertStrList(self.this,strings,index)

    def insertItem(self,string,index=-1):
        libqtpythonc.ComboBox_insertItem(self.this,string,index)

    def insertPixmap(self,pixmap,index=-1):
        libqtpythonc.ComboBox_insertPixmap(self.this,pixmap.this,index)

    def removeItem(self,index):
        libqtpythonc.ComboBox_removeItem(self.this,index)

    def clear(self):
        libqtpythonc.ComboBox_clear(self.this)

    def currentText(self):
        return libqtpythonc.ComboBox_currentText(self.this)

    def text(self,index):
        return libqtpythonc.ComboBox_text(self.this,index)

    def pixmap(self,index):
        val = PixmapPtr(libqtpythonc.ComboBox_pixmap(self.this,index))
        val.thisown = 0
        return val

    def changeItem(self,string,index):
        libqtpythonc.ComboBox_changeItem(self.this,string,index)

    def changePixmap(self,pixmap,index):
        libqtpythonc.ComboBox_changePixmap(self.this,pixmap,index)

    def currentItem(self):
        return libqtpythonc.ComboBox_currentItem(self.this)

    def setCurrentItem(self,index):
        libqtpythonc.ComboBox_setCurrentItem(self.this,index)

    def autoResize(self):
        return libqtpythonc.ComboBox_autoResize(self.this)

    def setAutoResize(self,auto):
        libqtpythonc.ComboBox_setAutoResize(self.this,auto)

    def setSizeLimit(self,lines):
        libqtpythonc.ComboBox_setSizeLimit(self.this,lines)

    def sizeLimit(self):
        return libqtpythonc.ComboBox_sizeLimit(self.this)

    def setMaxCount(self,max):
        libqtpythonc.ComboBox_setMaxCount(self.this,max)

    def maxCount(self):
        return libqtpythonc.ComboBox_maxCount(self.this)

    def setInsertionPolicy(self,policy):
        libqtpythonc.ComboBox_setInsertionPolicy(self.this,policy)

    def insertionPolicy(self):
        return libqtpythonc.ComboBox_insertionPolicy(self.this)

    def setValidator(self,validator):
        libqtpythonc.ComboBox_setValidator(self.this,validator)

    def validator(self):
        return libqtpythonc.ComboBox_validator(self.this)

    def clearValidator(self):
        libqtpythonc.ComboBox_clearValidator(self.this)

    def __repr__(self):
        return "<ComboBox instance at %s>" % self.this

class ComboBox(ComboBoxPtr):
    def __init__(self,parent="",name=""):
	ComboBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_ComboBox("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_ComboBox(parent.this, name)
	    self.thisown = 0	    
