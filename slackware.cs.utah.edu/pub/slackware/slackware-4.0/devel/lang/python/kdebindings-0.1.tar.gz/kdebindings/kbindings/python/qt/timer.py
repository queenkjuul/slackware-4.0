import libqtpythonc
from object import *


class TimerPtr(ObjectPtr):

    def __init__(self,this,name=""):
        ObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_Timer(self.this)

    def isActive(self):
        val = libqtpythonc.Timer_isActive(self.this)
        return val

    def start(self,time,single=0):
        val = libqtpythonc.Timer_start(self.this,time,single)
        return val

    def changeInterval(self,arg0):
        val = libqtpythonc.Timer_changeInterval(self.this,arg0)
        return val

    def stop(self):
        val = libqtpythonc.Timer_stop(self.this)
        return val

    def __repr__(self):
        return "<Timer instance at %s>" % self.this

class Timer(TimerPtr):
    def __init__(self,parent="",name=""):
	TimerPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_Timer("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_Timer(parent.this, name)
	    self.thisown = 0	    
