from qt.object import *


# create some objects

o1 = Object()
o2 = Object(o1, "this is a object")

print o2.getName()


# methods

print o2.isA("Object")
print o1.isWidgetType()

o2.blockSignals(1)
print o2.signalsBlocked()

print o1.children()