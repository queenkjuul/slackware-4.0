from baseobject import *
from button import *
import libqtpythonc


class PushButtonPtr(ButtonPtr):

    def __init__(self,this,name=""):
	ButtonPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_PushButton(self.this)

    def setToggleButton(self,arg0):
        libqtpythonc.PushButton_setToggleButton(self.this,arg0)

    def autoDefault(self):
        return libqtpythonc.PushButton_autoDefault(self.this)

    def setAutoDefault(self,arg0):
        libqtpythonc.PushButton_setAutoDefault(self.this,arg0)

    def isDefault(self):
        return libqtpythonc.PushButton_isDefault(self.this)

    def setDefault(self,default):
        libqtpythonc.PushButton_setDefault(self.this,default)

    def setOn(self,on):
        libqtpythonc.PushButton_setOn(self.this,on)

    def toggle(self):
        libqtpythonc.PushButton_toggle(self.this)

    def __repr__(self):
        return "<PushButton instance at %s>" % self.this

class PushButton(PushButtonPtr):
    def __init__(self,text,parent="",name=""):
	PushButtonPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_PushButton(text,"NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_PushButton(text,parent.this, name)
	    self.thisown = 0	    

