import libkdecorepythonc
from qt.object import *
from qt.color import *
from qt.font import *


class KSimpleConfigPtr(ObjectPtr):

    def __init__(self,this,name=""):
	ObjectPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete_KSimpleConfig(self.this)

    def isReadOnly(self):
        val = libkdecorepythonc.KSimpleConfig_isReadOnly(self.this)
        return val

    def writeConfigFile(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeConfigFile,(self.this,arg0,)+args)
        return val

    def deleteEntry(self,arg0,arg1):
        val = libkdecorepythonc.KSimpleConfig_deleteEntry(self.this,arg0,arg1)
        return val

    def deleteGroup(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_deleteGroup,(self.this,arg0,)+args)
        return val

    def setGroup(self,arg0):
        val = libkdecorepythonc.KSimpleConfig_setGroup(self.this,arg0)
        return val

    def group(self):
        val = libkdecorepythonc.KSimpleConfig_group(self.this)
        return val

    def readEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readEntry,(self.this,arg0,)+args)
        return val

    def readListEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readListEntry,(self.this,arg0,arg1,)+args)
        return val

    def readNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readNumEntry,(self.this,arg0,)+args)
        return val

    def readUnsignedNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readUnsignedNumEntry,(self.this,arg0,)+args)
        return val

    def readLongNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readLongNumEntry,(self.this,arg0,)+args)
        return val

    def readUnsignedLongNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readUnsignedLongNumEntry,(self.this,arg0,)+args)
        return val

    def readDoubleNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readDoubleNumEntry,(self.this,arg0,)+args)
        return val

    def readFontEntry(self,arg0,*args):
        argl = map(None,args)
        try: argl[0] = argl[0].this
        except: pass
        args = tuple(argl)
        val = apply(libkdecorepythonc.KSimpleConfig_readFontEntry,(self.this,arg0,)+args)
        val = FontPtr(val)
        val.thisown = 1
        return val

    def readBoolEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readBoolEntry,(self.this,arg0,)+args)
        return val

    def readRectEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readRectEntry,(self.this,arg0,)+args)
        return val

    def readPointEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readPointEntry,(self.this,arg0,)+args)
        return val

    def readSizeEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_readSizeEntry,(self.this,arg0,)+args)
        return val

    def readColorEntry(self,arg0,*args):
        argl = map(None,args)
        try: argl[0] = argl[0].this
        except: pass
        args = tuple(argl)
        val = apply(libkdecorepythonc.KSimpleConfig_readColorEntry,(self.this,arg0,)+args)
        val = ColorPtr(val)
        val.thisown = 1
        return val

    def writeStringEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeStringEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeListEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeListEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeIntEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeIntEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeFloatEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeFloatEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeBoolEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeBoolEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeFontEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeFontEntry,(self.this,arg0,arg1.this,)+args)
        return val

    def writeColorEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeColorEntry,(self.this,arg0,arg1.this,)+args)
        return val

    def writeRectEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeRectEntry,(self.this,arg0,arg1,)+args)
        return val

    def writePointEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writePointEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeSizeEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_writeSizeEntry,(self.this,arg0,arg1,)+args)
        return val


    def rollback(self,*args):
        val = apply(libkdecorepythonc.KSimpleConfig_rollback,(self.this,)+args)
        return val

    def sync(self):
        val = libkdecorepythonc.KSimpleConfig_sync(self.this)
        return val

    def hasKey(self,arg0):
        val = libkdecorepythonc.KSimpleConfig_hasKey(self.this,arg0)
        return val

    def reparseConfiguration(self):
        val = libkdecorepythonc.KSimpleConfig_reparseConfiguration(self.this)
        return val

    def __repr__(self):
        return "<SimpleConfig instance at %s>" % self.this

class KSimpleConfig(KSimpleConfigPtr):
    def __init__(self,arg0,name="") :
        KSimpleConfigPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new_KSimpleConfig(arg0)
        self.thisown = 1



def KSimpleConfigReadOnly(arg0,arg1,name="") :
    val = KSimpleConfigPtr(libkdecorepythonc.new_KSimpleConfigReadOnly(arg0,arg1),name)
    val.thisown = 1
    return val
