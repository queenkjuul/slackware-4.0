import libqtpythonc
from baseobject import *


class ToolTipPtr(BaseObjectPtr):

    def __init__(self,this,name=""):
        BaseObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __repr__(self):
        return "<ToolTip instance at %s>" % self.this
        
class ToolTip(ToolTipPtr):

    def __init__(self,widget,group="NULL",name=""):
	ToolTipPtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_ToolTip(widget.this,group)
        self.thisown = 1


def ToolTip_font():
    val = libqtpythonc.ToolTip_font()
    val = QFontPtr(val)
    val.thisown = 1
    return val

def ToolTip_setFont(arg0):
    val = libqtpythonc.ToolTip_setFont(arg0.this)
    return val

def ToolTip_palette():
    val = libqtpythonc.ToolTip_palette()
    val = QPalettePtr(val)
    val.thisown = 1
    return val

def ToolTip_setPalette(arg0):
    val = libqtpythonc.ToolTip_setPalette(arg0.this)
    return val

def ToolTip_add(arg0,arg1):
    val = libqtpythonc.ToolTip_add(arg0.this,arg1)
    return val

def ToolTip_addGroup(arg0,arg1,arg2,arg3):
    val = libqtpythonc.ToolTip_addGroup(arg0.this,arg1,arg2.this,arg3)
    return val

def ToolTip_remove(arg0):
    val = libqtpythonc.ToolTip_remove(arg0.this)
    return val

def ToolTip_addRect(arg0,arg1,arg2):
    val = libqtpythonc.ToolTip_addRect(arg0.this,arg1,arg2)
    return val

def ToolTip_addGroupRect(arg0,arg1,arg2,arg3,arg4):
    val = libqtpythonc.ToolTip_addGroupRect(arg0.this,arg1,arg2,arg3.this,arg4)
    return val

def ToolTip_removeRect(arg0,arg1):
    val = libqtpythonc.ToolTip_removeRect(arg0.this,arg1)
    return val
