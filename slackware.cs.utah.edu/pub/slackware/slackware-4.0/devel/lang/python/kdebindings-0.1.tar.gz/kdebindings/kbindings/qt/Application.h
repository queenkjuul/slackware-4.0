#ifndef _APP_H_
#define _APP_H_

#include <Python.h>
#include <qapp.h>
#include "Baseobject.h"


class Application : public QApplication, public BaseObject
{
  Q_OBJECT	

  public:
  
    Application(int argc, char **argv) : QApplication(argc,argv), BaseObject() {
      connect(this, SIGNAL(lastWindowClosed()), this, SLOT(sigLastWindowClosed()));
    };

  protected slots:

    void sigLastWindowClosed() {
      _emit("lastWindowClosed", 0);
    };
};

#endif