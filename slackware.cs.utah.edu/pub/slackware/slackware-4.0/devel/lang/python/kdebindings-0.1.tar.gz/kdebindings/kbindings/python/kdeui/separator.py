import libkdeuipythonc
from qt.frame import *


class KSeparatorPtr(FramePtr):

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def orientation(self):
        val = libkdeuipythonc.KSeparator_orientation(self.this)
        return val

    def setOrientation(self,arg0):
        val = libkdeuipythonc.KSeparator_setOrientation(self.this,arg0)
        return val

    def __repr__(self):
        return "<KSeparator instance at %s>" % self.this

class KSeparator(KSeparatorPtr):
    def __init__(self,orient,parent="",name=""):
	KSeparatorPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new_KSeparator(orient,"NULL", name)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new_KSeparator(orient,parent.this, name)
	    self.thisown = 0	    
