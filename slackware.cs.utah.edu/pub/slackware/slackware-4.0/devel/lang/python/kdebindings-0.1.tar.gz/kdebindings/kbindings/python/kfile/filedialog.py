import libkfilepythonc
from qt.dialog import *


class KFileBaseDialogPtr(DialogPtr):
 
    def __init__(self,this,name=""):
	DialogPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkfilepythonc.delete__FileBaseDialog(self.this)

    def selectedFile(self):
        val = libkfilepythonc._FileBaseDialog_selectedFile(self.this)
        return val

    def dirPath(self):
        val = libkfilepythonc._FileBaseDialog_dirPath(self.this)
        return val

    def rereadDir(self):
        val = libkfilepythonc._FileBaseDialog_rereadDir(self.this)
        return val

    def back(self):
        val = libkfilepythonc._FileBaseDialog_back(self.this)
        return val

    def forward(self):
        val = libkfilepythonc._FileBaseDialog_forward(self.this)
        return val

    def home(self):
        val = libkfilepythonc._FileBaseDialog_home(self.this)
        return val

    def cdUp(self):
        val = libkfilepythonc._FileBaseDialog_cdUp(self.this)
        return val

    def dirIsLocal(self):
        val = libkfilepythonc._FileBaseDialog_dirIsLocal(self.this)
        return val

    def selectedFileURL(self):
        val = libkfilepythonc._FileBaseDialog_selectedFileURL(self.this)
        return val

    def selectedFileURLList(self):
        val = libkfilepythonc._FileBaseDialog_selectedFileURLList(self.this)
        return val

    def setMultiSelection(self,*args):
        val = apply(libkfilepythonc._FileBaseDialog_setMultiSelection,(self.this,)+args)
        return val

    def isMultiSelection(self):
        val = libkfilepythonc._FileBaseDialog_isMultiSelection(self.this)
        return val

    def getOpenFileURLList(self,*args):
        argl = map(None,args)
        try: argl[2] = argl[2].this
        except: pass
        args = tuple(argl)
        val = apply(libkfilepythonc._FileBaseDialog_getOpenFileURLList,(self.this,)+args)
        return val

    def getSaveFileURLList(self,*args):
        argl = map(None,args)
        try: argl[2] = argl[2].this
        except: pass
        args = tuple(argl)
        val = apply(libkfilepythonc._FileBaseDialog_getSaveFileURLList,(self.this,)+args)
        return val

    def setDir(self,name):
        val = libkfilepythonc._FileBaseDialog__setDir(self.this,name)
        return val

    def __repr__(self):
        return "<K FileBaseDialog instance at %s>" % self.this 

class KFileBaseDialog(KFileBaseDialogPtr):
    def __init__(self,dirName="",filter="",parent="",name="",modal=0, acceptURLs=1):
	KFileBaseDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkfilepythonc.new__FileBaseDialog(dirName,filter,"NULL", name,modal,acceptURLs)
            self.thisown = 1
        else:
            self.this = libkfilepythonc.new__FileBaseDialog(dirName,filter,parent.this, name,modal,acceptURLs)
	    self.thisown = 0	    


class KDirDialogPtr(KFileBaseDialogPtr):

    def __init__(self,this,name=""):
        KFileBaseDialogPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __repr__(self):
        return "<KDirDialog instance at %s>" % self.this

class KDirDialog(KDirDialogPtr):
    def __init__(self,dirName="",parent="",name=""):
	KDirDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkfilepythonc.new_KDirDialog(dirName,"NULL", name)
            self.thisown = 1
        else:
            self.this = libkfilepythonc.new_KDirDialog(dirName,parent.this, name)
	    self.thisown = 0	    




class KFileDialogPtr(KFileBaseDialogPtr):

    def __init__(self,this,name=""):
        KFileBaseDialogPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __repr__(self):
        return "<KFileDialog instance at %s>" % self.this

class KFileDialog(KFileDialogPtr):
    def __init__(self,dirName="",filter="",parent="",name="",modal=0, acceptURLs=1):
	KFileDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkfilepythonc.new__FileDialog(dirName,filter,"NULL", name,modal,acceptURLs)
            self.thisown = 1
        else:
            self.this = libkfilepythonc.new__FileDialog(dirName,filter,parent.this, name,modal,acceptURLs)
	    self.thisown = 0	    



#-------------- FUNCTION WRAPPERS ------------------

def KFileDialog_getDirectory(url,parent="",name=""):
    if not parent:
        return libkfilepythonc._FileBaseDialog_getDirectory(url,"NULL", name)
    else:
        return libkfilepythonc._FileBaseDialog_getDirectory(url,parent.this, name)

def KFileDialog_getOpenFileName(dir="",filter="",parent="",name=""):
    if not parent:
        return libkfilepythonc._FileDialog_getOpenFileName(dir,filter,"NULL", name)
    else:
        return libkfilepythonc._FileDialog_getOpenFileName(dir,filter,"NULL", name)

def KFileDialog_getSaveFileName(dir="",filter="",parent="",name=""):
    if not parent:
        return libkfilepythonc._FileDialog_getSaveFileName(dir,filter,"NULL", name)
    else:
        return libkfilepythonc._FileDialog_getSaveFileName(dir,filter,"NULL", name)

def KFileDialog_getOpenFileURL(url="",filter="",parent="",name=""):
    if not parent:
        return libkfilepythonc._FileDialog_getOpenFileURL(url,filter,"NULL", name)
    else:
        return libkfilepythonc._FileDialog_getOpenFileURL(url,filter,"NULL", name)

def KFileDialog_getSaveFileURL(url="",filter="",parent="",name=""):
    if not parent:
        return libkfilepythonc._FileDialog_getSaveFileName(url,filter,"NULL", name)
    else:
        return libkfilepythonc._FileDialog_getSaveFileName(url,filter,"NULL", name)


