import libkdeuipythonc
from qt.button import *
from qt.frame import *


class KToolBarButtonPtr(ButtonPtr):

    def __init__(self,this,name=""):
        ButtonPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__ToolBarButton(self.this)

    def setEnabled(self,arg0):
        val = libkdeuipythonc._ToolBarButton_setEnabled(self.this,arg0)
        return val

    def makeDisabledPixmap(self):
        val = libkdeuipythonc._ToolBarButton_makeDisabledPixmap(self.this)
        return val

    def setPixmap(self,arg0):
        val = libkdeuipythonc._ToolBarButton_setPixmap(self.this,arg0.this)
        return val

    def on(self,arg0):
        val = libkdeuipythonc._ToolBarButton_on(self.this,arg0)
        return val

    def toggle(self):
        val = libkdeuipythonc._ToolBarButton_toggle(self.this)
        return val

    def beToggle(self,arg0):
        val = libkdeuipythonc._ToolBarButton_beToggle(self.this,arg0)
        return val

    def ImASeparator(self):
        val = libkdeuipythonc._ToolBarButton_ImASeparator(self.this)
        return val

    def youreSeparator(self):
        val = libkdeuipythonc._ToolBarButton_youreSeparator(self.this)
        return val

    def __repr__(self):
        return "<KToolBarButton instance at %s>" %self.this

class KToolBarButton(KToolBarButtonPtr):
    def __init__(self,parent="",name=""):
	KToolBarButtonPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__ToolBarButton("NULL", name)
            self.thisown = 1
        else:
            self.this = libkdeuithonc.new__ToolBarButton(parent.this, name)
	    self.thisown = 0	    

def KToolBarButtonPixmap(pixmap,id,parent,name=0,item_size=26,txt="") :
    KToolBarButtonPtr.__init__(self,"NULL",name)
    self.this = libqtkdeuipythonc.new__ToolBarButton(pixmap.this,id,parent.this,name,item_size,txt)
    self.thisown = 0	    


class KToolBarPtr(FramePtr):

    Toggle = libkdeuipythonc._ToolBar_Toggle
    Show = libkdeuipythonc._ToolBar_Show
    Hide = libkdeuipythonc._ToolBar_Hide

    Top = libkdeuipythonc._ToolBar_Top
    Left = libkdeuipythonc._ToolBar_Left
    Bottom = libkdeuipythonc._ToolBar_Bottom
    Right = libkdeuipythonc._ToolBar_Right
    Floating = libkdeuipythonc._ToolBar_Floating

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0
	self.currentIndex = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__ToolBar(self.this)

    def insertButton(self,arg0,*args):
	self.currentIndex = self.currentIndex+1
        val = apply(libkdeuipythonc._ToolBar_insertButton,(self.this,arg0.this,self.currentIndex,)+args)
        return val

    def addButton(self,pixmap,signal,slot,enabled=1,tooltip="",index=-1):
	self.currentIndex = self.currentIndex+1
        val = libkdeuipythonc._ToolBar_addButton(self.this,pixmap.this,self.currentIndex,signal,slot,enabled,tooltip,index)
        return val

    def addLined(self,text,signal,slot,enabled=1,tooltip="",size=70,index=-1):
	self.currentIndex = self.currentIndex+1
        val = libkdeuipythonc._ToolBar_addLined(self.this,text,self.currentIndex,signal,slot,enabled,tooltip,size,index)
        return val

    def addComboList(self,list,writable,signal,slot,enabled=1,tooltip="",size=70,index=-1,policy=libqtpythonc.ComboBox_AtBottom):
	self.currentIndex = self.currentIndex+1
        val = libkdeuipythonc._ToolBar_addComboList(self.this,list,self.currentIndex,writable,signal,slot,enabled,tooltip,size,index)
        return val

    def addComboText(self,text,writable,signal,slot,enabled=1,tooltip="",size=70,index=-1,policy=libqtpythonc.ComboBox_AtBottom):
	self.currentIndex = self.currentIndex+1
        val = libkdeuipythonc._ToolBar_addComboText(self.this,text,self.currentIndex,writable,signal,slot,enabled,tooltip,size,index)
        return val

    def insertSeparator(self,*args):
        val = apply(libkdeuipythonc._ToolBar_insertSeparator,(self.this,)+args)
        return val

    def insertWidget(self,arg0,arg1,arg2,*args):
        val = apply(libkdeuipythonc._ToolBar_insertWidget,(self.this,arg0,arg1,arg2.this,)+args)
        return val

    def addConnection(self,arg0,arg1,arg2,arg3):
        val = libkdeuipythonc._ToolBar_addConnection(self.this,arg0,arg1,arg2,arg3)
        return val

    def setItemEnabled(self,arg0,arg1):
        val = libkdeuipythonc._ToolBar_setItemEnabled(self.this,arg0,arg1)
        return val

    def setButtonPixmap(self,arg0,arg1):
        val = libkdeuipythonc._ToolBar_setButtonPixmap(self.this,arg0,arg1.this)
        return val

    def setToggle(self,arg0,*args):
        val = apply(libkdeuipythonc._ToolBar_setToggle,(self.this,arg0,)+args)
        return val

    def toggleButton(self,arg0):
        val = libkdeuipythonc._ToolBar_toggleButton(self.this,arg0)
        return val

    def setButton(self,arg0,arg1):
        val = libkdeuipythonc._ToolBar_setButton(self.this,arg0,arg1)
        return val

    def isButtonOn(self,arg0):
        val = libkdeuipythonc._ToolBar_isButtonOn(self.this,arg0)
        return val

    def setLinedText(self,arg0,arg1):
        val = libkdeuipythonc._ToolBar_setLinedText(self.this,arg0,arg1)
        return val

    def getLinedText(self,arg0):
        val = libkdeuipythonc._ToolBar_getLinedText(self.this,arg0)
        return val

    def insertComboList(self,arg0,arg1,arg2):
        val = libkdeuipythonc._ToolBar_insertComboList(self.this,arg0,arg1,arg2)
        return val

    def removeComboItem(self,arg0,arg1):
        val = libkdeuipythonc._ToolBar_removeComboItem(self.this,arg0,arg1)
        return val

    def setCurrentComboItem(self,arg0,arg1):
        val = libkdeuipythonc._ToolBar_setCurrentComboItem(self.this,arg0,arg1)
        return val

    def changeComboItem(self,arg0,arg1,*args):
        val = apply(libkdeuipythonc._ToolBar_changeComboItem,(self.this,arg0,arg1,)+args)
        return val

    def clearCombo(self,arg0):
        val = libkdeuipythonc._ToolBar_clearCombo(self.this,arg0)
        return val

    def getComboItem(self,arg0,*args):
        val = apply(libkdeuipythonc._ToolBar_getComboItem,(self.this,arg0,)+args)
        return val

    def getCombo(self,arg0):
        val = libkdeuipythonc._ToolBar_getCombo(self.this,arg0)
        val = _ComboBoxPtr(val)
        return val

    def getLined(self,arg0):
        val = libkdeuipythonc._ToolBar_getLined(self.this,arg0)
        return val

    def getButton(self,arg0):
        val = libkdeuipythonc._ToolBar_getButton(self.this,arg0)
        val = _ToolBarButtonPtr(val)
        return val

    def alignItemRight(self,arg0,*args):
        val = apply(libkdeuipythonc._ToolBar_alignItemRight,(self.this,arg0,)+args)
        return val

    def getFrame(self,arg0):
        val = libkdeuipythonc._ToolBar_getFrame(self.this,arg0)
        val = QFramePtr(val)
        return val

    def getWidget(self,arg0):
        val = libkdeuipythonc._ToolBar_getWidget(self.this,arg0)
        val = QWidgetPtr(val)
        return val

    def setItemAutoSized(self,arg0,*args):
        val = apply(libkdeuipythonc._ToolBar_setItemAutoSized,(self.this,arg0,)+args)
        return val

    def removeItem(self,arg0):
        val = libkdeuipythonc._ToolBar_removeItem(self.this,arg0)
        return val

    def hideItem(self,arg0):
        val = libkdeuipythonc._ToolBar_hideItem(self.this,arg0)
        return val

    def showItem(self,arg0):
        val = libkdeuipythonc._ToolBar_showItem(self.this,arg0)
        return val

    def setFullWidth(self,*args):
        val = apply(libkdeuipythonc._ToolBar_setFullWidth,(self.this,)+args)
        return val

    def enableMoving(self,*args):
        val = apply(libkdeuipythonc._ToolBar_enableMoving,(self.this,)+args)
        return val

    def setBarPos(self,arg0):
        val = libkdeuipythonc._ToolBar_setBarPos(self.this,arg0)
        return val

    def barPos(self):
        val = libkdeuipythonc._ToolBar_barPos(self.this)
        return val

    def enable(self,arg0):
        val = libkdeuipythonc._ToolBar_enable(self.this,arg0)
        return val

    def setMaxHeight(self,arg0):
        val = libkdeuipythonc._ToolBar_setMaxHeight(self.this,arg0)
        return val

    def setMaxWidth(self,arg0):
        val = libkdeuipythonc._ToolBar_setMaxWidth(self.this,arg0)
        return val

    def setTitle(self,arg0):
        val = libkdeuipythonc._ToolBar_setTitle(self.this,arg0)
        return val

    def enableFloating(self,arg0):
        val = libkdeuipythonc._ToolBar_enableFloating(self.this,arg0)
        return val

    def updateRects(self,*args):
        val = apply(libkdeuipythonc._ToolBar_updateRects,(self.this,)+args)
        return val

    def __repr__(self):
        return "<KToolBar instance at %s>" % self.this

class KToolBar(KToolBarPtr):
    def __init__(self,parent="",name="",item_size=26):
	KToolBarPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__ToolBar("NULL", name, item_size)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__ToolBar(parent.this, name, item_size)
	    self.thisown = 0	    

ITEM_LINED = libkdeuipythonc.ITEM_LINED
ITEM_BUTTON = libkdeuipythonc.ITEM_BUTTON
ITEM_COMBO = libkdeuipythonc.ITEM_COMBO
ITEM_FRAME = libkdeuipythonc.ITEM_FRAME
ITEM_TOGGLE = libkdeuipythonc.ITEM_TOGGLE
ITEM_ANYWIDGET = libkdeuipythonc.ITEM_ANYWIDGET
