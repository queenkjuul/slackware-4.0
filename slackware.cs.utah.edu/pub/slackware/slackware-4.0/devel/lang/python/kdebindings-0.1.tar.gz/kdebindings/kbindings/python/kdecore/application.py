import libkdecorepythonc
from qt.application import *
from qt.color import *
from qt.popupmenu import *
from kde.iconloader import *
from qt.pixmap import *


class KApplicationPtr(ApplicationPtr):

    APPCONFIG_NONE = libkdecorepythonc._Application_APPCONFIG_NONE
    APPCONFIG_READONLY = libkdecorepythonc._Application_APPCONFIG_READONLY
    APPCONFIG_READWRITE = libkdecorepythonc._Application_APPCONFIG_READWRITE

    def __init__(self,this,name=""):
        ApplicationPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete__Application(self.this)

    def eventFilter(self,arg0,arg1):
        val = libkdecorepythonc._Application_eventFilter(self.this,arg0,arg1)
        return val

    def appName(self):
        val = libkdecorepythonc._Application_appName(self.this)
        return val

    def getConfig(self):
        val = libkdecorepythonc._Application_getConfig(self.this)
        return val

    def getSessionConfig(self):
        val = libkdecorepythonc._Application_getSessionConfig(self.this)
        return val

    def isRestored(self):
        val = libkdecorepythonc._Application_isRestored(self.this)
        return val

    def enableSessionManagement(self,*args):
        val = apply(libkdecorepythonc._Application_enableSessionManagement,(self.this,)+args)
        return val

    def setWmCommand(self,arg0):
        val = libkdecorepythonc._Application_setWmCommand(self.this,arg0)
        return val

    def getHelpMenu(self,arg0,arg1):
        val = libkdecorepythonc._Application_getHelpMenu(self.this,arg0,arg1)
        val = PopupMenuPtr(val)
        return val

    def getIconLoader(self):
        val = KIconLoaderPtr(libkdecorepythonc._Application_getIconLoader(self.this))
	val.thisown = 0
        return val

    def getLocale(self):
        val = libkdecorepythonc._Application_getLocale(self.this)
        return val

    def getCharsets(self):
        val = libkdecorepythonc._Application_getCharsets(self.this)
        return val

    def getIcon(self):
        val = libkdecorepythonc._Application_getIcon(self.this)
        val = PixmapPtr(val)
        val.thisown = 1
        return val

    def getMiniIcon(self):
        val = libkdecorepythonc._Application_getMiniIcon(self.this)
        val = PixmapPtr(val)
        val.thisown = 1
        return val

    def setTopWidget(self,arg0):
        val = libkdecorepythonc._Application_setTopWidget(self.this,arg0.this)
        return val

    def topWidget(self):
        val = libkdecorepythonc._Application_topWidget(self.this)
        val = QWidgetPtr(val)
        return val

    def registerTopWidget(self):
        val = libkdecorepythonc._Application_registerTopWidget(self.this)
        return val

    def unregisterTopWidget(self):
        val = libkdecorepythonc._Application_unregisterTopWidget(self.this)
        return val

    def getConfigState(self):
        val = libkdecorepythonc._Application_getConfigState(self.this)
        return val

    def invokeHTMLHelp(self,arg0,arg1):
        val = libkdecorepythonc._Application_invokeHTMLHelp(self.this,arg0,arg1)
        return val

    def getKDEFonts(self,arg0):
        val = libkdecorepythonc._Application_getKDEFonts(self.this,arg0)
        return val

    def getCaption(self):
        val = libkdecorepythonc._Application_getCaption(self.this)
        return val

    def tempSaveName(self,arg0):
        val = libkdecorepythonc._Application_tempSaveName(self.this,arg0)
        return val

    def checkRecoverFile(self,arg0,arg1):
        val = libkdecorepythonc._Application_checkRecoverFile(self.this,arg0,arg1)
        return val

    def localeConstructed(self):
        val = libkdecorepythonc._Application_localeConstructed(self.this)
        return val

    def getDndSelectionAtom(self):
        val = libkdecorepythonc._Application_getDndSelectionAtom(self.this)
        return val

    def getDndProtocolAtom(self):
        val = libkdecorepythonc._Application_getDndProtocolAtom(self.this)
        return val

    def getDndEnterProtocolAtom(self):
        val = libkdecorepythonc._Application_getDndEnterProtocolAtom(self.this)
        return val

    def getDndLeaveProtocolAtom(self):
        val = libkdecorepythonc._Application_getDndLeaveProtocolAtom(self.this)
        return val

    def getDndRootProtocolAtom(self):
        val = libkdecorepythonc._Application_getDndRootProtocolAtom(self.this)
        return val

    def getDisplay(self):
        val = libkdecorepythonc._Application_getDisplay(self.this)
        return val

    def addDropZone(self,arg0):
        val = libkdecorepythonc._Application_addDropZone(self.this,arg0)
        return val

    def removeDropZone(self,arg0):
        val = libkdecorepythonc._Application_removeDropZone(self.this,arg0)
        return val

    def setRootDropZone(self,arg0):
        val = libkdecorepythonc._Application_setRootDropZone(self.this,arg0)
        return val

    def __setattr__(self,name,value):
        if name == "inactiveTitleColor" :
            libkdecorepythonc._Application_inactiveTitleColor_set(self.this,value.this)
            return
        if name == "inactiveTextColor" :
            libkdecorepythonc._Application_inactiveTextColor_set(self.this,value.this)
            return
        if name == "activeTitleColor" :
            libkdecorepythonc._Application_activeTitleColor_set(self.this,value.this)
            return
        if name == "activeTextColor" :
            libkdecorepythonc._Application_activeTextColor_set(self.this,value.this)
            return
        if name == "backgroundColor" :
            libkdecorepythonc._Application_backgroundColor_set(self.this,value.this)
            return
        if name == "textColor" :
            libkdecorepythonc._Application_textColor_set(self.this,value.this)
            return
        if name == "selectColor" :
            libkdecorepythonc._Application_selectColor_set(self.this,value.this)
            return
        if name == "selectTextColor" :
            libkdecorepythonc._Application_selectTextColor_set(self.this,value.this)
            return
        if name == "windowColor" :
            libkdecorepythonc._Application_windowColor_set(self.this,value.this)
            return
        if name == "windowTextColor" :
            libkdecorepythonc._Application_windowTextColor_set(self.this,value.this)
            return
        if name == "contrast" :
            libkdecorepythonc._Application_contrast_set(self.this,value)
            return
        if name == "generalFont" :
            libkdecorepythonc._Application_generalFont_set(self.this,value.this)
            return
        if name == "fixedFont" :
            libkdecorepythonc._Application_fixedFont_set(self.this,value.this)
            return
        if name == "applicationStyle" :
            libkdecorepythonc._Application_applicationStyle_set(self.this,value)
            return
        self.__dict__[name] = value

    def __getattr__(self,name):
        if name == "inactiveTitleColor" : 
            return ColorPtr(libkdecorepythonc._Application_inactiveTitleColor_get(self.this))
        if name == "inactiveTextColor" : 
            return ColorPtr(libkdecorepythonc._Application_inactiveTextColor_get(self.this))
        if name == "activeTitleColor" : 
            return ColorPtr(libkdecorepythonc._Application_activeTitleColor_get(self.this))
        if name == "activeTextColor" : 
            return ColorPtr(libkdecorepythonc._Application_activeTextColor_get(self.this))
        if name == "backgroundColor" : 
            return ColorPtr(libkdecorepythonc._Application_backgroundColor_get(self.this))
        if name == "textColor" : 
            return ColorPtr(libkdecorepythonc._Application_textColor_get(self.this))
        if name == "selectColor" : 
            return ColorPtr(libkdecorepythonc._Application_selectColor_get(self.this))
        if name == "selectTextColor" : 
            return ColorPtr(libkdecorepythonc._Application_selectTextColor_get(self.this))
        if name == "windowColor" : 
            return ColorPtr(libkdecorepythonc._Application_windowColor_get(self.this))
        if name == "windowTextColor" : 
            return ColorPtr(libkdecorepythonc._Application_windowTextColor_get(self.this))
        if name == "contrast" : 
            return libkdecorepythonc._Application_contrast_get(self.this)
        if name == "generalFont" : 
            return QFontPtr(libkdecorepythonc._Application_generalFont_get(self.this))
        if name == "fixedFont" : 
            return QFontPtr(libkdecorepythonc._Application_fixedFont_get(self.this))
        if name == "applicationStyle" : 
            return libkdecorepythonc._Application_applicationStyle_get(self.this)
        raise AttributeError,name

    def __repr__(self):
        return "<KApplication instance at %s >" % self.this

class KApplication(KApplicationPtr):
    def __init__(self,name="") :
        KApplicationPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new__Application(len(argv),argv)
        self.thisown = 1



def KApplicationName(arg0,name="") :
    val = KApplicationPtr(libkdecorepythonc.new_KApplicationName(len(argv),argv,arg0),name)
    val.thisown = 1
    return val




#-------------- FUNCTION WRAPPERS ------------------

def KApplication_getKApplication():
    val = libkdecorepythonc._Application_getKApplication()
    val = KApplicationPtr(val)
    return val

def KApp():
    val = libkdecorepythonc._Application_getKApplication()
    val = KApplicationPtr(val)
    return val

KApplication_kde_htmldir = libkdecorepythonc._Application_kde_htmldir

KApplication_kde_appsdir = libkdecorepythonc._Application_kde_appsdir

KApplication_kde_icondir = libkdecorepythonc._Application_kde_icondir

KApplication_kde_datadir = libkdecorepythonc._Application_kde_datadir

KApplication_kde_localedir = libkdecorepythonc._Application_kde_localedir

KApplication_kde_cgidir = libkdecorepythonc._Application_kde_cgidir

KApplication_kde_sounddir = libkdecorepythonc._Application_kde_sounddir

KApplication_kde_toolbardir = libkdecorepythonc._Application_kde_toolbardir

KApplication_kde_wallpaperdir = libkdecorepythonc._Application_kde_wallpaperdir

KApplication_kde_bindir = libkdecorepythonc._Application_kde_bindir

KApplication_kde_partsdir = libkdecorepythonc._Application_kde_partsdir

KApplication_kde_configdir = libkdecorepythonc._Application_kde_configdir

KApplication_kde_mimedir = libkdecorepythonc._Application_kde_mimedir

KApplication_localkdedir = libkdecorepythonc._Application_localkdedir

KApplication_localconfigdir = libkdecorepythonc._Application_localconfigdir

KApplication_findFile = libkdecorepythonc._Application_findFile



#-------------- VARIABLE WRAPPERS ------------------

