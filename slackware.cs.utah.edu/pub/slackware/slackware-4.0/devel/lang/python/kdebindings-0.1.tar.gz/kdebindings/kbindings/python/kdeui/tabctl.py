import libkdeuipythonc
from qt.widget import *


class KTabCtlPtr(WidgetPtr):

    def __init__(self,this,name=""):
        WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__TabCtl(self.this)

    def addTab(self,arg0,arg1):
        val = libkdeuipythonc._TabCtl_addTab(self.this,arg0.this,arg1)
        return val

    def isTabEnabled(self,arg0):
        val = libkdeuipythonc._TabCtl_isTabEnabled(self.this,arg0)
        return val

    def setTabEnabled(self,arg0,arg1):
        val = libkdeuipythonc._TabCtl_setTabEnabled(self.this,arg0,arg1)
        return val

    def __repr__(self):
        return "<KTabCtl instance at %s>" % self.this

class KTabCtl(KTabCtlPtr):
    def __init__(self,parent="",name=""):
	KTabCtlPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__TabCtl("NULL", name)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__TabCtl(parent.this, name)
	    self.thisown = 0	    
