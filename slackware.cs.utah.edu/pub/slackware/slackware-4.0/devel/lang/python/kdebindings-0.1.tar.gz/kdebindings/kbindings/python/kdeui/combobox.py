import libkdeuipythonc
from qt.combobox import *


class KComboBoxPtr(ComboBoxPtr):

    def __init__(self,this,name=""):
        ComboBoxPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__ComboBox(self.this)

    def setLabelFlags(self,arg0):
        val = libkdeuipythonc._ComboBox_setLabelFlags(self.this,arg0)
        return val

    def labelFlags(self):
        val = libkdeuipythonc._ComboBox_labelFlags(self.this)
        return val

    def cursorAtEnd(self):
        val = libkdeuipythonc._ComboBox_cursorAtEnd(self.this)
        return val

    def setText(self,arg0):
        val = libkdeuipythonc._ComboBox_setText(self.this,arg0)
        return val

    def setCompletion(self,arg0):
        val = libkdeuipythonc._ComboBox_setCompletion(self.this,arg0)
        return val

    def __repr__(self):
        return "<KComboBox instance at %s>" % self.this

class KComboBox(KComboBoxPtr):
    def __init__(self,parent="",name="",flags=0):
	KComboBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__ComboBox("NULL",name,flags)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__ComboBox(parent.this,name,flags)
	    self.thisown = 0	    



def KComboReadWrite(read,parent="",name="",flags=0) :
	KComboBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__ComboBox(read,"NULL",name,flags)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__ComboBox(read,parent.this,name,flags)
	    self.thisown = 0	    
