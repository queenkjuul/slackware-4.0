#include "KRestrictedline.h"
#include "KRestrictedline.moc"
