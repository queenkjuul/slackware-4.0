#ifndef _KEDIT_H_
#define _KEDIT_H_

#include <Python.h>
#include <keditcl.h>
#include "Baseobject.h"
#include "../kdecore/KApplication.h"


class _Edit : public KEdit
{
  Q_OBJECT
public:

  _Edit(KApplication *a, QWidget *parent=0, const char *name=0, const char *filename=0) 
    : KEdit(a,parent,name,filename)
  {
      
  };
  ~_Edit() {};
};


#endif