#include "KFontdialog.h"
#include "KFontdialog.moc"
