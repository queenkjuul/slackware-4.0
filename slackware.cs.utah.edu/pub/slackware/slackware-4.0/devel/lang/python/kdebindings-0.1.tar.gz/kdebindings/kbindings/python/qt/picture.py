import libqtpythonc
from painter import *
from paintdevice import *



class PicturePtr(PaintDevicePtr):

    def __init__(self,this,name=""):
        PaintDevicePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QPicture(self.this)

    def isNull(self):
        val = libqtpythonc.QPicture_isNull(self.this)
        return val

    def size(self):
        val = libqtpythonc.QPicture_size(self.this)
        return val

    def data(self):
        val = libqtpythonc.QPicture_data(self.this)
        return val

    def setData(self,arg0,arg1):
        val = libqtpythonc.QPicture_setData(self.this,arg0,arg1)
        return val

    def play(self,arg0):
        val = libqtpythonc.QPicture_play(self.this,arg0.this)
        return val

    def load(self,arg0):
        val = libqtpythonc.QPicture_load(self.this,arg0)
        return val

    def save(self,arg0):
        val = libqtpythonc.QPicture_save(self.this,arg0)
        return val

    def __repr__(self):
        return "<Picture instance at %s>" % self.this

class Picture(PicturePtr):
    def __init__(self,name="") :
        PicturePtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_QPicture()
        self.thisown = 1
