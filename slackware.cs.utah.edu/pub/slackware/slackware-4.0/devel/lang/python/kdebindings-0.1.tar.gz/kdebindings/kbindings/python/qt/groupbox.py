from frame import *
import libqtpythonc


class GroupBoxPtr(FramePtr):

    def __init__(self,this,name=""):
	WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QGroupBox(self.this)

    def title(self):
        return libqtpythonc.QGroupBox_title(self.this)

    def setTitle(self,title):
        libqtpythonc.QGroupBox_setTitle(self.this,title)

    def alignment(self):
        return libqtpythonc.QGroupBox_alignment(self.this)

    def setAlignment(self,align):
        libqtpythonc.QGroupBox_setAlignment(self.this,align)

    def __repr__(self):
        return "<GroupBox instance at %s>" % self.this

class GroupBox(GroupBoxPtr):
    def __init__(self,title,parent="",name=""):
	GroupBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_QGroupBox(title, "NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_QGroupBox(title, parent.this, name)
	    self.thisown = 0	    
