import libkdecorepythonc
import libkdeuipythonc
from kde.application import *
from qt.multilineedit import *

class KEditPtr(MultiLineEditPtr):

    NONE = libkdeuipythonc._Edit_NONE
    FORWARD = libkdeuipythonc._Edit_FORWARD
    BACKWARD = libkdeuipythonc._Edit_BACKWARD

    KEDIT_OK = libkdeuipythonc._Edit_KEDIT_OK
    KEDIT_OS_ERROR = libkdeuipythonc._Edit_KEDIT_OS_ERROR
    KEDIT_USER_CANCEL = libkdeuipythonc._Edit_KEDIT_USER_CANCEL
    KEDIT_RETRY = libkdeuipythonc._Edit_KEDIT_RETRY
    KEDIT_NOPERMISSIONS = libkdeuipythonc._Edit_KEDIT_NOPERMISSIONS

    OPEN_READWRITE = libkdeuipythonc._Edit_OPEN_READWRITE
    OPEN_READONLY = libkdeuipythonc._Edit_OPEN_READONLY
    OPEN_INSERT = libkdeuipythonc._Edit_OPEN_INSERT

    def __init__(self,this,name=""):
        MultiLineEditPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__Edit(self.this)

    def newFile(self):
        val = libkdeuipythonc._Edit_newFile(self.this)
        return val

    def doSave(self):
        val = libkdeuipythonc._Edit_doSave(self.this)
        return val

    def doSaveAs(self,arg0):
        val = libkdeuipythonc._Edit_doSaveAs(self.this,arg0)
        return val

    def saveAs(self):
        val = libkdeuipythonc._Edit_saveAs(self.this)
        return val

    def openFile(self,arg0):
        val = libkdeuipythonc._Edit_openFile(self.this,arg0)
        return val

    def insertFile(self):
        val = libkdeuipythonc._Edit_insertFile(self.this)
        return val

    def loadFile(self,arg0,arg1):
        val = libkdeuipythonc._Edit_loadFile(self.this,arg0,arg1)
        return val

    def getName(self):
        val = libkdeuipythonc._Edit_getName(self.this)
        return val

    def setName(self,arg0):
        val = libkdeuipythonc._Edit_setName(self.this,arg0)
        return val

    def markedText(self):
        val = libkdeuipythonc._Edit_markedText(self.this)
        return val

    def selectFont(self):
        val = libkdeuipythonc._Edit_selectFont(self.this)
        return val

    def Search(self):
        val = libkdeuipythonc._Edit_Search(self.this)
        return val

    def repeatSearch(self):
        val = libkdeuipythonc._Edit_repeatSearch(self.this)
        return val

    def Replace(self):
        val = libkdeuipythonc._Edit_Replace(self.this)
        return val

    def doGotoLine(self):
        val = libkdeuipythonc._Edit_doGotoLine(self.this)
        return val

    def isModified(self):
        val = libkdeuipythonc._Edit_isModified(self.this)
        return val

    def toggleModified(self,arg0):
        val = libkdeuipythonc._Edit_toggleModified(self.this,arg0)
        return val

    def setAutoIndentMode(self,arg0):
        val = libkdeuipythonc._Edit_setAutoIndentMode(self.this,arg0)
        return val

    def AutoIndentMode(self):
        val = libkdeuipythonc._Edit_AutoIndentMode(self.this)
        return val

    def installRBPopup(self,arg0):
        val = libkdeuipythonc._Edit_installRBPopup(self.this,arg0)
        return val

    def currentLine(self):
        val = libkdeuipythonc._Edit_currentLine(self.this)
        return val

    def currentColumn(self):
        val = libkdeuipythonc._Edit_currentColumn(self.this)
        return val

    def WordWrap(self):
        val = libkdeuipythonc._Edit_WordWrap(self.this)
        return val

    def setWordWrap(self,arg0):
        val = libkdeuipythonc._Edit_setWordWrap(self.this,arg0)
        return val

    def FillColumnMode(self):
        val = libkdeuipythonc._Edit_FillColumnMode(self.this)
        return val

    def setFillColumnMode(self,arg0,arg1):
        val = libkdeuipythonc._Edit_setFillColumnMode(self.this,arg0,arg1)
        return val

    def saveBackupCopy(self,arg0):
        val = libkdeuipythonc._Edit_saveBackupCopy(self.this,arg0)
        return val

    def setFileName(self,arg0):
        val = libkdeuipythonc._Edit_setFileName(self.this,arg0)
        return val

    def setModified(self):
        val = libkdeuipythonc._Edit_setModified(self.this)
        return val

    def computePosition(self):
        val = libkdeuipythonc._Edit_computePosition(self.this)
        return val

    def __repr__(self):
        return "<KEdit instance at %s>" % self.this

class KEdit(KEditPtr):
    def __init__(self,app,parent="",name="",filename=""):
	KEditPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__Edit(app.this,"NULL", name,filename)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__Edit(app.this,parent.this, name,filename)
	    self.thisown = 0	    
