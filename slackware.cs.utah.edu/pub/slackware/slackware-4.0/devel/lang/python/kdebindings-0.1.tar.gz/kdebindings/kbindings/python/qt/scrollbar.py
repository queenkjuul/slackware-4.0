from widget import *
from rangecontrol import *
import libqtpythonc


class ScrollBarPtr(WidgetPtr,RangeControlPtr):

    Horizontal = libqtpythonc.ScrollBar_Horizontal
    Vertical = libqtpythonc.ScrollBar_Vertical

    def __init__(self,this,name=""):
	WidgetPtr.__init__(self,this,name)
        RangeControlPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QScrollBarr(self.this)

    def setOrientation(self,arg0):
        libqtpythonc.ScrollBar_setOrientation(self.this,arg0)

    def orientation(self):
        return libqtpythonc.ScrollBar_orientation(self.this)

    def setTracking(self,arg0):
        libqtpythonc.ScrollBar_setTracking(self.this,arg0)

    def tracking(self):
        return libqtpythonc.ScrollBar_tracking(self.this)

    def draggingSlider(self):
        return libqtpythonc.ScrollBar_draggingSlider(self.this)

    def __repr__(self):
        return "<ScrollBar instance at %s>" % self.this

class ScrollBar(ScrollBarPtr):
    def __init__(self,min=0,max=99,line=1,page=10,value=0,orientation=libqtpythonc.Slider_Horizontal,parent="",name=""):
	ScrollBarPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_ScrollBar(min,max,line,page,value,orientation,"NULL",name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_ScrollBar(min,max,line,page,value,orientation,parent.this,name)
	    self.thisown = 0	    
