#ifndef _FONTINFO_H_
#define _FONTINFO_H_

#include <qfontinf.h>

class FontInfo : public QFontInfo
{

public:

   FontInfo( const QFont &font) : QFontInfo(font) {};
   FontInfo( const QFontInfo &fontinfo) : QFontInfo(fontinfo) {};
  ~FontInfo() {};
  
};

#endif
