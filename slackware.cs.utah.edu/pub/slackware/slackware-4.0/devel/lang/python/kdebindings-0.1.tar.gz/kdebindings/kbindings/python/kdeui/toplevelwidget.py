import libkdeuipythonc
from qt.widget import *


class KTopLevelWidgetPtr(WidgetPtr):

    def __init__(self,this,name=""):
        WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete_KTopLevelWidget(self.this)

    def addToolBar(self,arg0,*args):
        val = apply(libkdeuipythonc.KTopLevelWidget_addToolBar,(self.this,arg0.this,)+args)
        return val

    def setView(self,arg0,*args):
        val = apply(libkdeuipythonc.KTopLevelWidget_setView,(self.this,arg0.this,)+args)
        return val

    def setMenu(self,menu):
        val = libkdeuipythonc.KTopLevelWidget_setMenu(self.this,menu.this)
        return val

    def setStatusBar(self,arg0):
        val = libkdeuipythonc.KTopLevelWidget_setStatusBar(self.this,arg0.this)
        return val

    def enableStatusBar(self,*args):
        val = apply(libkdeuipythonc.KTopLevelWidget_enableStatusBar,(self.this,)+args)
        return val

    def setFrameBorderWidth(self,arg0):
        val = libkdeuipythonc.KTopLevelWidget_setFrameBorderWidth(self.this,arg0)
        return val

    def menuBar(self):
        val = libkdeuipythonc.KTopLevelWidget_menuBar(self.this)
        return val

    def restore(self,arg0):
        val = libkdeuipythonc.KTopLevelWidget_restore(self.this,arg0)
        return val

    def setUnsavedData(self,arg0):
        val = libkdeuipythonc.KTopLevelWidget_setUnsavedData(self.this,arg0)
        return val

    def __repr__(self):
        return "<KTopLevelWidget instance at %s>" % self.this

class KTopLevelWidget(KTopLevelWidgetPtr):
    def __init__(self,name="") :
        KTopLevelWidgetPtr.__init__(self,"NULL",name)
        self.this = libkdeuipythonc.new_KTopLevelWidget(name)
        self.thisown = 1

KTopLevelWidget_canBeRestored = libkdeuipythonc.KTopLevelWidget_canBeRestored

KTopLevelWidget_classNameOfToplevel = libkdeuipythonc.KTopLevelWidget_classNameOfToplevel

