import libqtpythonc
from dialog import *


class FileDialogPtr(DialogPtr):

    def __init__(self,this,name=""):
        DialogPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_FileDialog(self.this)

    def selectedFile(self):
        val = libqtpythonc.FileDialog_selectedFile(self.this)
        return val

    def dirPath(self):
        val = libqtpythonc.FileDialog_dirPath(self.this)
        return val

    def setDir(self,arg0):
        val = libqtpythonc.FileDialog_setDir(self.this,arg0)
        return val

    def rereadDir(self):
        val = libqtpythonc.FileDialog_rereadDir(self.this)
        return val

    def __repr__(self):
        return "<FileDialog instance at %s>" % self.this

class FileDialog(FileDialogPtr):
    def __init__(self,parent="",name=""):
	FileDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_FileDialog("NULL",name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_FileDialog(parent.this,name)
	    self.thisown = 0	    

def FileDialogInit(caption,filter,parent="",name="",modal=0,flags=0) :
    def __init__(self,parent="",name=""):
	FileDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_FileDialogInit(caption,filter,"NULL",name,modal,flags)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_FileDialogInit(caption,filter,parent.this,name,modal,flags)
	    self.thisown = 0	    


def FileDialog_getOpenFileName(dir,filter,parent="",name="") :
    if not parent:
        return libqtpythonc.FileDialog_getOpenFileName(dir,filter,"NULL",name)
    else:
        return libqtpythonc.FileDialog_getOpenFileName(dir,filter,parent.this,name)


def FileDialog_getSaveFileName(dir,filter,parent="",name="") :
    if not parent:
        return libqtpythonc.FileDialog_getSaveFileName(dir,filter,"NULL",name)
    else:
        return libqtpythonc.FileDialog_getSaveFileName(dir,filter,parent.this,name)


