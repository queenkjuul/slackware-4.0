import libkdecorepythonc
from qt.object import *
from qt.color import *
from qt.font import *


class KConfigPtr(ObjectPtr):

    def __init__(self,this,name=""):
        ObjectPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete_KConfig(self.this)

    def setGroup(self,arg0):
        val = libkdecorepythonc.KConfig_setGroup(self.this,arg0)
        return val

    def group(self):
        val = libkdecorepythonc.KConfig_group(self.this)
        return val

    def readEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readEntry,(self.this,arg0,)+args)
        return val

    def readListEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_readListEntry,(self.this,arg0,arg1,)+args)
        return val

    def readNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readNumEntry,(self.this,arg0,)+args)
        return val

    def readUnsignedNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readUnsignedNumEntry,(self.this,arg0,)+args)
        return val

    def readLongNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readLongNumEntry,(self.this,arg0,)+args)
        return val

    def readUnsignedLongNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readUnsignedLongNumEntry,(self.this,arg0,)+args)
        return val

    def readDoubleNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readDoubleNumEntry,(self.this,arg0,)+args)
        return val

    def readFontEntry(self,arg0,*args):
        argl = map(None,args)
        try: argl[0] = argl[0].this
        except: pass
        args = tuple(argl)
        val = apply(libkdecorepythonc.KConfig_readFontEntry,(self.this,arg0,)+args)
        val = FontPtr(val)
        val.thisown = 1
        return val

    def readBoolEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readBoolEntry,(self.this,arg0,)+args)
        return val

    def readRectEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readRectEntry,(self.this,arg0,)+args)
        return val

    def readPointEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readPointEntry,(self.this,arg0,)+args)
        return val

    def readSizeEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KConfig_readSizeEntry,(self.this,arg0,)+args)
        return val

    def readColorEntry(self,arg0,*args):
        argl = map(None,args)
        try: argl[0] = argl[0].this
        except: pass
        args = tuple(argl)
        val = apply(libkdecorepythonc.KConfig_readColorEntry,(self.this,arg0,)+args)
        val = ColorPtr(val)
        val.thisown = 1
        return val

    def writeStringEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writeStringEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeListEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writeListEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeIntEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writeIntEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeFloatEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writeFloatEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeBoolEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writeBoolEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeFontEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writeFontEntry,(self.this,arg0,arg1.this,)+args)
        return val

    def writeColorEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writeColorEntry,(self.this,arg0,arg1.this,)+args)
        return val

    def writeRectEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writeRectEntry,(self.this,arg0,arg1,)+args)
        return val

    def writePointEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writePointEntry,(self.this,arg0,arg1,)+args)
        return val

    def writeSizeEntry(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KConfig_writeSizeEntry,(self.this,arg0,arg1,)+args)
        return val

    def rollback(self,*args):
        val = apply(libkdecorepythonc.KConfig_rollback,(self.this,)+args)
        return val

    def sync(self):
        val = libkdecorepythonc.KConfig_sync(self.this)
        return val

    def hasKey(self,arg0):
        val = libkdecorepythonc.KConfig_hasKey(self.this,arg0)
        return val

    def reparseConfiguration(self):
        val = libkdecorepythonc.KConfig_reparseConfiguration(self.this)
        return val

    def __repr__(self):
        return "<Config instance at %s>" % self.this

class KConfig(KConfigPtr):
    def __init__(self,globalfile="",localfile="",name="") :
        KConfigPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new_KConfig(globalfile,localfile)
        self.thisown = 1

