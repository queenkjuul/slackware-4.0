import libkdeuipythonc
from qt.baseobject import *
from qt.button import *


class KButtonPtr(ButtonPtr):

    def __init__(self,this,name=""):
        ButtonPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__Button(self.this)

    def __repr__(self):
        return "<KButton instance at %s>" % self.this

class KButton(KButtonPtr):
    def __init__(self,parent="",name=""):
	KButtonPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__Button("NULL", name)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__Button(parent.this, name)
	    self.thisown = 0	    
