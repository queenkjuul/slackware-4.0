import libkdecorepythonc
from qt.baseobject import *
from qt.colorgroup import *
from qt.color import *


class KColorGroupPtr(BaseObjectPtr) :

    def __init__(self,this,name=""):
        BaseObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete_KColorGroup(self.this)

    def foreground(self):
        val = libkdecorepythonc.KColorGroup_foreground(self.this)
        val = ColorPtr(val)
        return val

    def background(self):
        val = libkdecorepythonc.KColorGroup_background(self.this)
        val = ColorPtr(val)
        return val

    def light(self):
        val = libkdecorepythonc.KColorGroup_light(self.this)
        val = ColorPtr(val)
        return val

    def mid(self):
        val = libkdecorepythonc.KColorGroup_mid(self.this)
        val = ColorPtr(val)
        return val

    def dark(self):
        val = libkdecorepythonc.KColorGroup_dark(self.this)
        val = ColorPtr(val)
        return val

    def text(self):
        val = libkdecorepythonc.KColorGroup_text(self.this)
        val = ColorPtr(val)
        return val

    def base(self):
        val = libkdecorepythonc.KColorGroup_base(self.this)
        val = ColorPtr(val)
        return val

    def load(self,arg0,arg1):
        val = libkdecorepythonc.KColorGroup_load(self.this,arg0,arg1)
        return val

    def save(self,arg0,arg1):
        val = libkdecorepythonc.KColorGroup_save(self.this,arg0,arg1)
        return val

    def colorGroup(self):
        val = libkdecorepythonc.KColorGroup_colorGroup(self.this)
        val = ColorGroupPtr(val)
        return val

    def __repr__(self):
        return "<KColorGroup instance at %s>" % self.this

class KColorGroup(KColorGroupPtr):
    def __init__(self,name="") :
        KColorGroupPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new_KColorGroup()
        self.thisown = 1


def KColorGroupName(arg0,arg1,arg2,arg3,arg4,arg5,arg6,name="") :
    val = KColorGroupPtr(libkdecorepythonc.new_KColorGroupName(arg0.this,arg1.this,arg2.this,arg3.this,arg4.this,arg5.this,arg6.this),name)
    val.thisown = 1
    return val
