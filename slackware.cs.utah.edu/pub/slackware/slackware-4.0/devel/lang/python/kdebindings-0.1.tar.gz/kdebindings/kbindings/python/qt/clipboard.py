import libqtpythonc
from object import *


class QClipboardPtr(ObjectPtr):

    def __init__(self,this,name=""):
        ObjectPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def clear(self):
        val = libqtpythonc.QClipboard_clear(self.this)
        return val

    def data(self,arg0):
        val = libqtpythonc.QClipboard_data(self.this,arg0)
        return val

    def setData(self,arg0,arg1):
        val = libqtpythonc.QClipboard_setData(self.this,arg0,arg1)
        return val

    def text(self):
        val = libqtpythonc.QClipboard_text(self.this)
        return val

    def setText(self,arg0):
        val = libqtpythonc.QClipboard_setText(self.this,arg0)
        return val

    def pixmap(self):
        val = libqtpythonc.QClipboard_pixmap(self.this)
        val = QPixmapPtr(val)
        return val

    def setPixmap(self,arg0):
        val = libqtpythonc.QClipboard_setPixmap(self.this,arg0.this)
        return val

    def __repr__(self):
        return "<Clipboard instance at %s>" % self.this

class QClipboard(QClipboardPtr):
    def __init__(self,this,name=""):
        QClipboardPtr.__init__(self,"NULL",name)
        self.this = this


