import libqtpythonc
from object import *
from sys    import argv


class ApplicationPtr(ObjectPtr):

    NormalColor = libqtpythonc.Application_NormalColor
    CustomColor = libqtpythonc.Application_CustomColor
    PrivateColor = libqtpythonc.Application_PrivateColor
    ManyColor = libqtpythonc.Application_ManyColor
    TrueColor = libqtpythonc.Application_TrueColor

    _classname = "Application"

    def __init__(self,this,name=""):
        ObjectPtr.__init__(self,name)
    	self.this = this
     	self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_Application(self.this)

    def argc(self):
        return libqtpythonc.Application_argc(self.this)

    def argv(self):
        return libqtpythonc.Application_argv(self.this)

    def mainWidget(self):
        return libqtpythonc.Application_mainWidget(self.this)

    def setMainWidget(self,widget):
        libqtpythonc.Application_setMainWidget(self.this,widget.this)
	widget.thisown = 0

    def focusWidget(self):
        return libqtpythonc.Application_focusWidget(self.this)

    def execute(self):
        return  libqtpythonc.Application_execute(self.this)

    def processEvents(self):
        libqtpythonc.Application_processEvents(self.this)

    def processEventsTill(self,endtime):
        libqtpythonc.Application_processEventsTill(self.this,endtime)

    def processOneEvent(self):
        libqtpythonc.Application_processOneEvent(self.this)

    def enter_loop(self):
        return libqtpythonc.Application_enter_loop(self.this)

    def exit_loop(self):
        libqtpythonc.Application_exit_loop(self.this)

    def notify(self,arg0,arg1):
        return libqtpythonc.Application_notify(self.this,arg0,arg1)

    def quit(self):
        libqtpythonc.Application_quit(self.this)

    def __repr__(self):
        return "<Application instance at %s>" % self.this


class Application(ApplicationPtr):
    def __init__(self,name='') :
	ApplicationPtr.__init__(self,"NULL",name);
        self.this = libqtpythonc.new_Application(len(argv),argv)
        self.thisown = 1


def App():
   val = ApplicationPtr(libqtpythonc.cvar.qApp)
   val.thisown = 0
   return val



#-------------- FUNCTION WRAPPERS ------------------

Application_style = libqtpythonc.Application_style

Application_setStyle = libqtpythonc.Application_setStyle

Application_colorSpec = libqtpythonc.Application_colorSpec

Application_setColorSpec = libqtpythonc.Application_setColorSpec

Application_overrideCursor = libqtpythonc.Application_overrideCursor

Application_setOverrideCursor = libqtpythonc.Application_setOverrideCursor

Application_restoreOverrideCursor = libqtpythonc.Application_restoreOverrideCursor

Application_hasGlobalMouseTracking = libqtpythonc.Application_hasGlobalMouseTracking

Application_setGlobalMouseTracking = libqtpythonc.Application_setGlobalMouseTracking

Application_palette = libqtpythonc.Application_palette

Application_setPalette = libqtpythonc.Application_setPalette

Application_font = libqtpythonc.Application_font

Application_setFont = libqtpythonc.Application_setFont

Application_fontMetrics = libqtpythonc.Application_fontMetrics

Application_allWidgets = libqtpythonc.Application_allWidgets

Application_topLevelWidgets = libqtpythonc.Application_topLevelWidgets

Application_desktop = libqtpythonc.Application_desktop

Application_activePopupWidget = libqtpythonc.Application_activePopupWidget

Application_activeModalWidget = libqtpythonc.Application_activeModalWidget

Application_clipboard = libqtpythonc.Application_clipboard

Application_widgetAt = libqtpythonc.Application_widgetAt

Application_exit = libqtpythonc.Application_exit

Application_sendEvent = libqtpythonc.Application_sendEvent

Application_postEvent = libqtpythonc.Application_postEvent

Application_startingUp = libqtpythonc.Application_startingUp

Application_closingDown = libqtpythonc.Application_closingDown

Application_flushX = libqtpythonc.Application_flushX

Application_syncX = libqtpythonc.Application_syncX

Application_beep = libqtpythonc.Application_beep

Application_setWinStyleHighlightColor = libqtpythonc.Application_setWinStyleHighlightColor

Application_winStyleHighlightColor = libqtpythonc.Application_winStyleHighlightColor

Application_setDoubleClickInterval = libqtpythonc.Application_setDoubleClickInterval

Application_doubleClickInterval = libqtpythonc.Application_doubleClickInterval



#-------------- VARIABLE WRAPPERS ------------------

cvar = libqtpythonc.cvar
MacStyle = libqtpythonc.MacStyle
WindowsStyle = libqtpythonc.WindowsStyle
Win3Style = libqtpythonc.Win3Style
PMStyle = libqtpythonc.PMStyle
MotifStyle = libqtpythonc.MotifStyle

