from frame import *
import libqtpythonc


class MultiLineEditPtr(FramePtr):

    def __init__(self,this,name=""):
	FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_MultiLineEdit(self.this)

    def textLine(self,line):
        return libqtpythonc.MultiLineEdit_textLine(self.this,arg0)

    def text(self):
        return libqtpythonc.MultiLineEdit_text(self.this)

    def numLines(self):
        return libqtpythonc.MultiLineEdit_numLines(self.this)

    def isReadOnly(self):
        return libqtpythonc.MultiLineEdit_isReadOnly(self.this)

    def isOverwriteMode(self):
        val = libqtpythonc.MultiLineEdit_isOverwriteMode(self.this)
        return val

    def insertLine(self,text,line=-1):
        libqtpythonc.MultiLineEdit_insertLine(self.this,text,line)

    def insertAt(self,text,line,col):
        libqtpythonc.MultiLineEdit_insertAt(self.this,text,line,col)

    def removeLine(self,line):
        libqtpythonc.MultiLineEdit_removeLine(self.this,line)

    def cursorPosition(self):
        return libqtpythonc.MultiLineEdit_cursorPos(self.this)

    def setCursorPosition(self,line,col,mark=0):
        libqtpythonc.MultiLineEdit_setCursorPosition(self.this,line,col,mark)

    def atBeginning(self):
        return libqtpythonc.MultiLineEdit_atBeginning(self.this)

    def atEnd(self):
        return libqtpythonc.MultiLineEdit_atEnd(self.this)

    def autoUpdate(self):
        return libqtpythonc.MultiLineEdit_autoUpdate(self.this)

    def setAutoUpdate(self,auto):
        libqtpythonc.MultiLineEdit_setAutoUpdate(self.this,auto)

    def clear(self):
        libqtpythonc.MultiLineEdit_clear(self.this)

    def setText(self,text):
        libqtpythonc.MultiLineEdit_setText(self.this,arg0)

    def append(self,text):
        libqtpythonc.MultiLineEdit_append(self.this,text)

    def deselect(self):
        libqtpythonc.MultiLineEdit_deselect(self.this)

    def selectAll(self):
        libqtpythonc.MultiLineEdit_selectAll(self.this)

    def setReadOnly(self,readonly):
        libqtpythonc.MultiLineEdit_setReadOnly(self.this,readonly)

    def setOverwriteMode(self,overwrite):
        libqtpythonc.MultiLineEdit_setOverwriteMode(self.this,overwrite)

    def paste(self):
        return libqtpythonc.MultiLineEdit_paste(self.this)

    def copyText(self):
        return libqtpythonc.MultiLineEdit_copyText(self.this)

    def cut(self):
        return libqtpythonc.MultiLineEdit_cut(self.this)

    def __repr__(self):
        return "<MultiLineEdit instance at %s>" % self.this

class MultiLineEdit(MultiLineEditPtr):
    def __init__(self,parent="",name=""):
	MultiLineEditPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_MultiLineEdit("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_MultiLineEdit(parent.this, name)
	    self.thisown = 0	    
