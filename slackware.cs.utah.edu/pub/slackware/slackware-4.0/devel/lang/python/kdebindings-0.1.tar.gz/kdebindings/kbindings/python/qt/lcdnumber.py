from frame import *
import libqtpythonc


class LCDNumberPtr(FramePtr):

    HEX = libqtpythonc.LCDNumber_HEX
    DEC = libqtpythonc.LCDNumber_DEC
    OCT = libqtpythonc.LCDNumber_OCT
    BIN = libqtpythonc.LCDNumber_BIN

    Outline = libqtpythonc.LCDNumber_Outline
    Filled = libqtpythonc.LCDNumber_Filled
    Flat = libqtpythonc.LCDNumber_Flat

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_LCDNumber(self.this)

    def smallDecimalPoint(self):
        return libqtpythonc.LCDNumber_smallDecimalPoint(self.this)

    def numDigits(self):
        return libqtpythonc.LCDNumber_numDigits(self.this)

    def setNumDigits(self,digits):
        libqtpythonc.LCDNumber_setNumDigits(self.this,digits)

    def checkOverflow(self,number):
        return libqtpythonc.LCDNumber_checkOverflow(self.this,number)

    def checkOverflowFloat(self,number):
        return libqtpythonc.LCDNumber_checkOverflowFloat(self.this,number)

    def mode(self):
        return libqtpythonc.LCDNumber_mode(self.this)

    def setMode(self,mode):
        libqtpythonc.LCDNumber_setMode(self.this,mode)

    def segmentStyle(self):
        return libqtpythonc.LCDNumber_segmentStyle(self.this)

    def setSegmentStyle(self,style):
        libqtpythonc.LCDNumber_setSegmentStyle(self.this,style)

    def value(self):
        return libqtpythonc.LCDNumber_value(self.this)

    def intValue(self):
        return libqtpythonc.LCDNumber_intValue(self.this)

    def display(self,number):
        libqtpythonc.LCDNumber_display(self.this,number)

    def displayFloat(self,number):
        libqtpythonc.LCDNumber_displayFloat(self.this,number)

    def displayString(self,string):
        libqtpythonc.LCDNumber_displayString(self.this,string)

    def setHexMode(self):
        libqtpythonc.LCDNumber_setHexMode(self.this)

    def setDecMode(self):
        libqtpythonc.LCDNumber_setDecMode(self.this)

    def setOctMode(self):
        libqtpythonc.LCDNumber_setOctMode(self.this)

    def setBinMode(self):
        libqtpythonc.LCDNumber_setBinMode(self.this)

    def setSmallDecimalPoint(self,small):
        libqtpythonc.LCDNumber_setSmallDecimalPoint(self.this,small)

    def __repr__(self):
        return "<C LCDNumber instance>"

class LCDNumber(LCDNumberPtr):
    def __init__(self,parent="",name=""):
	LCDNumberPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_LCDNumber("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_LCDNumber(parent.this, name)
	    self.thisown = 0	    
