from widget import *
import libqtpythonc


class LineEditPtr(WidgetPtr):

    Normal = libqtpythonc.LineEdit_Normal
    NoEcho = libqtpythonc.LineEdit_NoEcho
    Password = libqtpythonc.LineEdit_Password

    def __init__(self,this,name=""):
        WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_LineEdit(self.this)

    def text(self):
        return libqtpythonc.LineEdit_text(self.this)

    def maxLength(self):
        return libqtpythonc.LineEdit_maxLength(self.this)

    def setMaxLength(self,length):
        libqtpythonc.LineEdit_setMaxLength(self.this,length)

    def setFrame(self,frame):
        libqtpythonc.LineEdit_setFrame(self.this,frame)

    def frame(self):
        return libqtpythonc.LineEdit_frame(self.this)

    def setEchoMode(self,echo):
        libqtpythonc.LineEdit_setEchoMode(self.this,echo)

    def echoMode(self):
        return libqtpythonc.LineEdit_echoMode(self.this)

    def setValidator(self,validator):
        libqtpythonc.LineEdit_setValidator(self.this,validator)

    def validator(self):
        return libqtpythonc.LineEdit_validator(self.this)

    def setText(self,text):
        libqtpythonc.LineEdit_setText(self.this,text)

    def selectAll(self):
        libqtpythonc.LineEdit_selectAll(self.this)

    def deselect(self):
        libqtpythonc.LineEdit_deselect(self.this)

    def clearValidator(self):
        libqtpythonc.LineEdit_clearValidator(self.this)

    def __repr__(self):
        return "<LineEdit instance at %s>" % self.this

class LineEdit(LineEditPtr):
    def __init__(self,parent="",name=""):
	WidgetPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_LineEdit("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_LineEdit(parent.this, name)
	    self.thisown = 0	    
