import libqtpythonc
from baseobject import *


class FontMetricsPtr(BaseObjectPtr):

    def __init__(self,this,name=""):
        BaseObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QFontMetrics(self.this)

    def ascent(self):
        val = libqtpythonc.QFontMetrics_ascent(self.this)
        return val

    def descent(self):
        val = libqtpythonc.QFontMetrics_descent(self.this)
        return val

    def height(self):
        val = libqtpythonc.QFontMetrics_height(self.this)
        return val

    def leading(self):
        val = libqtpythonc.QFontMetrics_leading(self.this)
        return val

    def lineSpacing(self):
        val = libqtpythonc.QFontMetrics_lineSpacing(self.this)
        return val

    def width(self,arg0,*args):
        val = apply(libqtpythonc.QFontMetrics_width,(self.this,arg0,)+args)
        return val

    def widthChar(self,arg0):
        val = libqtpythonc.QFontMetrics_widthChar(self.this,arg0)
        return val

    def boundingRect(self,arg0,*args):
        val = apply(libqtpythonc.QFontMetrics_boundingRect,(self.this,arg0,)+args)
        return val

    def boundingRectChar(self,arg0):
        val = libqtpythonc.QFontMetrics_boundingRectChar(self.this,arg0)
        return val

    def maxWidth(self):
        val = libqtpythonc.QFontMetrics_maxWidth(self.this)
        return val

    def underlinePos(self):
        val = libqtpythonc.QFontMetrics_underlinePos(self.this)
        return val

    def strikeOutPos(self):
        val = libqtpythonc.QFontMetrics_strikeOutPos(self.this)
        return val

    def lineWidth(self):
        val = libqtpythonc.QFontMetrics_lineWidth(self.this)
        return val

    def __repr__(self):
        return "<FontMetrics instance at %s>" % self.this

class FontMetrics(FontMetricsPtr):
    def __init__(self,arg0,name=""):
        FontMetricsPtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_QFontMetrics(arg0.this)
        self.thisown = 1



def FontMetricsCopy(arg0,name=""):
    val = FontMetricsPtr(libqtpythonc.new_QFontMetricsCopy(arg0.this),name)
    val.thisown = 1
    return val

