#ifndef _LCDNUMBER_H_
#define _LCDNUMBER_H_

#include "qlcdnum.h"
#include "Baseobject.h"

class LCDNumber : public QLCDNumber, BaseObject
{
  Q_OBJECT
  
public:

  LCDNumber(QWidget *parent=0, const char *name=0) : QLCDNumber(parent,name), BaseObject() {
    connect(this, SIGNAL(overflow()), this, SLOT(sigOverflow()));
  };
  ~LCDNumber() {};

protected slots:

  void sigOverflow() {
    _emit("overflow", 0);
  };
  
};


#endif
