from widget import *
import libqtpythonc
from pixmap import *


class ButtonPtr(WidgetPtr):

    def __init__(self,this,name=""):
	WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_Button(self.this)

    def text(self):
        return libqtpythonc.Button_text(self.this)

    def setText(self,arg0):
        libqtpythonc.Button_setText(self.this,arg0)

    def pixmap(self):
        val = PixmapPtr(libqtpythonc.Button_pixmap(self.this))
	val.thisown = 0
	return val

    def setPixmap(self,pixmap):
        libqtpythonc.Button_setPixmap(self.this,pixmap.size)

    def accel(self):
        return libqtpythonc.Button_accel(self.this)

    def setAccel(self,accel):
        libqtpythonc.Button_setAccel(self.this,accel)

    def isToggleButton(self):
        return libqtpythonc.Button_isToggleButton(self.this)

    def isDown(self):
        return libqtpythonc.Button_isDown(self.this)

    def isOn(self):
        return libqtpythonc.Button_isOn(self.this)

    def autoResize(self):
        return libqtpythonc.Button_autoResize(self.this)

    def setAutoResize(self,auto):
        libqtpythonc.Button_setAutoResize(self.this,auto)

    def autoRepeat(self):
        return libqtpythonc.Button_autoRepeat(self.this)

    def setAutoRepeat(self,auto):
        libqtpythonc.Button_setAutoRepeat(self.this,auto)

    def animateClick(self):
        libqtpythonc.Button_animateClick(self.this)

    def __repr__(self):
        return "<Button instance at %s>" % self.this

class Button(ButtonPtr):
    def __init__(self,parent="",name=""):
	ButtonPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_Button("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_Button(parent.this, name)
	    self.thisown = 0	    
