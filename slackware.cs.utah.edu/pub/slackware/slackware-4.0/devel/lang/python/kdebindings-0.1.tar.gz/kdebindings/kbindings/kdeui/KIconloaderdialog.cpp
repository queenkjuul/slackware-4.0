#include "KIconloaderdialog.h"
#include "KIconloaderdialog.moc"
