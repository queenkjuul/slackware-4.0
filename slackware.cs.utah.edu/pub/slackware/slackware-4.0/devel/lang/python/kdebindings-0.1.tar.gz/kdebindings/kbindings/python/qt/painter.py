import libqtpythonc
from baseobject import *
from region import *


class PainterPtr(BaseObjectPtr) :

    def __init__(self,this,name=""):
        BaseObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QPainter(self.this)

    def begin(self,arg0):
        val = libqtpythonc.QPainter_begin(self.this,arg0.this)
        return val

    def end(self):
        val = libqtpythonc.QPainter_end(self.this)
        return val

    def device(self):
        val = libqtpythonc.QPainter_device(self.this)
        val = PaintDevicePtr(val)
        return val

    def isActive(self):
        val = libqtpythonc.QPainter_isActive(self.this)
        return val

    def flush(self):
        val = libqtpythonc.QPainter_flush(self.this)
        return val

    def save(self):
        val = libqtpythonc.QPainter_save(self.this)
        return val

    def restore(self):
        val = libqtpythonc.QPainter_restore(self.this)
        return val

    def fontMetrics(self):
        val = libqtpythonc.QPainter_fontMetrics(self.this)
        val = FontMetricsPtr(val)
        val.thisown = 1
        return val

    def fontInfo(self):
        val = libqtpythonc.QPainter_fontInfo(self.this)
        val = FontInfoPtr(val)
        val.thisown = 1
        return val

    def font(self):
        val = libqtpythonc.QPainter_font(self.this)
        val = FontPtr(val)
        return val

    def setFont(self,arg0):
        val = libqtpythonc.QPainter_setFont(self.this,arg0.this)
        return val

    def pen(self):
        val = libqtpythonc.QPainter_pen(self.this)
        val = PenPtr(val)
        return val

    def setPen(self,arg0):
        val = libqtpythonc.QPainter_setPen(self.this,arg0.this)
        return val

    def setPenStyle(self,arg0):
        val = libqtpythonc.QPainter_setPenStyle(self.this,arg0)
        return val

    def setPenColor(self,arg0):
        val = libqtpythonc.QPainter_setPenColor(self.this,arg0.this)
        return val

    def brush(self):
        val = libqtpythonc.QPainter_brush(self.this)
        val = BrushPtr(val)
        return val

    def setBrush(self,arg0):
        val = libqtpythonc.QPainter_setBrush(self.this,arg0.this)
        return val

    def setBrushStyle(self,arg0):
        val = libqtpythonc.QPainter_setBrushStyle(self.this,arg0)
        return val

    def setBrushColor(self,arg0):
        val = libqtpythonc.QPainter_setBrushColor(self.this,arg0.this)
        return val

    def backgroundColor(self):
        val = libqtpythonc.QPainter_backgroundColor(self.this)
        val = ColorPtr(val)
        return val

    def setBackgroundColor(self,arg0):
        val = libqtpythonc.QPainter_setBackgroundColor(self.this,arg0.this)
        return val

    def backgroundMode(self):
        val = libqtpythonc.QPainter_backgroundMode(self.this)
        return val

    def setBackgroundMode(self,arg0):
        val = libqtpythonc.QPainter_setBackgroundMode(self.this,arg0)
        return val

    def rasterOp(self):
        val = libqtpythonc.QPainter_rasterOp(self.this)
        return val

    def setRasterOp(self,arg0):
        val = libqtpythonc.QPainter_setRasterOp(self.this,arg0)
        return val

    def brushOrigin(self):
        val = libqtpythonc.QPainter_brushOrigin(self.this)
        return val

    def setBrushOrigin(self,arg0):
        val = libqtpythonc.QPainter_setBrushOrigin(self.this,arg0)
        return val

    def setViewXForm(self,arg0):
        val = libqtpythonc.QPainter_setViewXForm(self.this,arg0)
        return val

    def hasViewXForm(self):
        val = libqtpythonc.QPainter_hasViewXForm(self.this)
        return val

    def window(self):
        val = libqtpythonc.QPainter_window(self.this)
        return val

    def setWindow(self,arg0):
        val = libqtpythonc.QPainter_setWindow(self.this,arg0)
        return val

    def viewport(self):
        val = libqtpythonc.QPainter_viewport(self.this)
        return val

    def setViewport(self,arg0):
        val = libqtpythonc.QPainter_setViewport(self.this,arg0)
        return val

    def setWorldXForm(self,arg0):
        val = libqtpythonc.QPainter_setWorldXForm(self.this,arg0)
        return val

    def hasWorldXForm(self):
        val = libqtpythonc.QPainter_hasWorldXForm(self.this)
        return val

    def worldMatrix(self):
        val = libqtpythonc.QPainter_worldMatrix(self.this)
        return val

    def setWorldMatrix(self,arg0,*args):
        val = apply(libqtpythonc.QPainter_setWorldMatrix,(self.this,arg0,)+args)
        return val

    def translate(self,arg0,arg1):
        val = libqtpythonc.QPainter_translate(self.this,arg0,arg1)
        return val

    def scale(self,arg0,arg1):
        val = libqtpythonc.QPainter_scale(self.this,arg0,arg1)
        return val

    def shear(self,arg0,arg1):
        val = libqtpythonc.QPainter_shear(self.this,arg0,arg1)
        return val

    def rotate(self,arg0):
        val = libqtpythonc.QPainter_rotate(self.this,arg0)
        return val

    def resetXForm(self):
        val = libqtpythonc.QPainter_resetXForm(self.this)
        return val

    def xForm(self,arg0):
        val = libqtpythonc.QPainter_xForm(self.this,arg0)
        return val

    def xFormRect(self,arg0):
        val = libqtpythonc.QPainter_xFormRect(self.this,arg0)
        return val

    def xFormPoints(self,arg0):
        val = libqtpythonc.QPainter_xFormPoints(self.this,arg0)
        return val

    def xFormDev(self,arg0):
        val = libqtpythonc.QPainter_xFormDev(self.this,arg0)
        return val

    def xFormDevRect(self,arg0):
        val = libqtpythonc.QPainter_xFormDevRect(self.this,arg0)
        return val

    def xFormDevPoints(self,arg0):
        val = libqtpythonc.QPainter_xFormDevPoints(self.this,arg0)
        return val

    def setClipping(self,arg0):
        val = libqtpythonc.QPainter_setClipping(self.this,arg0)
        return val

    def hasClipping(self):
        val = libqtpythonc.QPainter_hasClipping(self.this)
        return val

    def clipRegion(self):
        val = libqtpythonc.QPainter_clipRegion(self.this)
        val = RegionPtr(val)
        return val

    def setClipRect(self,arg0):
        val = libqtpythonc.QPainter_setClipRect(self.this,arg0)
        return val

    def setClipRegion(self,arg0):
        val = libqtpythonc.QPainter_setClipRegion(self.this,arg0.this)
        return val

    def drawPoint(self,arg0):
        val = libqtpythonc.QPainter_drawPoint(self.this,arg0)
        return val

    def drawPoints(self,arg0,*args):
        val = apply(libqtpythonc.QPainter_drawPoints,(self.this,arg0,)+args)
        return val

    def moveTo(self,arg0):
        val = libqtpythonc.QPainter_moveTo(self.this,arg0)
        return val

    def lineTo(self,arg0):
        val = libqtpythonc.QPainter_lineTo(self.this,arg0)
        return val

    def drawLine(self,arg0,arg1):
        val = libqtpythonc.QPainter_drawLine(self.this,arg0,arg1)
        return val

    def drawRect(self,arg0):
        val = libqtpythonc.QPainter_drawRect(self.this,arg0)
        return val

    def drawWinFocusRect(self,arg0):
        val = libqtpythonc.QPainter_drawWinFocusRect(self.this,arg0)
        return val

    def drawWinFocusRectColor(self,arg0,arg1):
        val = libqtpythonc.QPainter_drawWinFocusRectColor(self.this,arg0,arg1.this)
        return val

    def drawRoundRect(self,arg0,arg1,arg2):
        val = libqtpythonc.QPainter_drawRoundRect(self.this,arg0,arg1,arg2)
        return val

    def drawEllipse(self,arg0):
        val = libqtpythonc.QPainter_drawEllipse(self.this,arg0)
        return val

    def drawArc(self,arg0,arg1,arg2):
        val = libqtpythonc.QPainter_drawArc(self.this,arg0,arg1,arg2)
        return val

    def drawPie(self,arg0,arg1,arg2):
        val = libqtpythonc.QPainter_drawPie(self.this,arg0,arg1,arg2)
        return val

    def drawChord(self,arg0,arg1,arg2):
        val = libqtpythonc.QPainter_drawChord(self.this,arg0,arg1,arg2)
        return val

    def drawLineSegments(self,arg0,*args):
        val = apply(libqtpythonc.QPainter_drawLineSegments,(self.this,arg0,)+args)
        return val

    def drawPolyline(self,arg0,*args):
        val = apply(libqtpythonc.QPainter_drawPolyline,(self.this,arg0,)+args)
        return val

    def drawPolygon(self,arg0,*args):
        val = apply(libqtpythonc.QPainter_drawPolygon,(self.this,arg0,)+args)
        return val

    def drawQuadBezier(self,arg0,*args):
        val = apply(libqtpythonc.QPainter_drawQuadBezier,(self.this,arg0,)+args)
        return val

    def drawPixmapRect(self,arg0,arg1,arg2):
        val = libqtpythonc.QPainter_drawPixmapRect(self.this,arg0,arg1.this,arg2)
        return val

    def drawPixmap(self,arg0,arg1):
        val = libqtpythonc.QPainter_drawPixmap(self.this,arg0,arg1.this)
        return val

    def drawPicture(self,arg0):
        val = libqtpythonc.QPainter_drawPicture(self.this,arg0)
        return val

    def fillRect(self,arg0,arg1):
        val = libqtpythonc.QPainter_fillRect(self.this,arg0,arg1.this)
        return val

    def eraseRect(self,arg0):
        val = libqtpythonc.QPainter_eraseRect(self.this,arg0)
        return val

    def drawText(self,arg0,arg1,*args):
        val = apply(libqtpythonc.QPainter_drawText,(self.this,arg0,arg1,)+args)
        return val

    def drawTextRect(self,arg0,arg1,arg2,*args):
        val = apply(libqtpythonc.QPainter_drawTextRect,(self.this,arg0,arg1,arg2,)+args)
        return val

    def boundingRect(self,arg0,arg1,arg2,*args):
        val = apply(libqtpythonc.QPainter_boundingRect,(self.this,arg0,arg1,arg2,)+args)
        return val

    def tabStops(self):
        val = libqtpythonc.QPainter_tabStops(self.this)
        return val

    def setTabStops(self,arg0):
        val = libqtpythonc.QPainter_setTabStops(self.this,arg0)
        return val

    def tabArray(self):
        val = libqtpythonc.QPainter_tabArray(self.this)
        return val

    def setTabArray(self,arg0):
        val = libqtpythonc.QPainter_setTabArray(self.this,arg0)
        return val

    def __repr__(self):
        return "<Painter instance at %i>" % self.this

class Painter(PainterPtr):
    def __init__(self,name="") :
        PainterPtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_QPainter()
        self.thisown = 1



def PainterPaintDevice(arg0,name="") :
    val = PainterPtr(libqtpythonc.new_QPainterPaintDevice(arg0.this),name)
    val.thisown = 1
    return val
