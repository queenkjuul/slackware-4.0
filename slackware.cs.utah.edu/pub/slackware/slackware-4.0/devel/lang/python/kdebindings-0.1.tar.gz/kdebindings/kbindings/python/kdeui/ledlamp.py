import libkdeuipythonc
from qt.frame import *


class KLedLampPtr(FramePtr):

    On = libkdeuipythonc.KLedLamp_On
    Off = libkdeuipythonc.KLedLamp_Off

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def state(self):
        val = libkdeuipythonc.KLedLamp_state(self.this)
        return val

    def setState(self,arg0):
        val = libkdeuipythonc.KLedLamp_setState(self.this,arg0)
        return val

    def toggleState(self):
        val = libkdeuipythonc.KLedLamp_toggleState(self.this)
        return val

    def toggle(self):
        val = libkdeuipythonc.KLedLamp_toggle(self.this)
        return val

    def on(self):
        val = libkdeuipythonc.KLedLamp_on(self.this)
        return val

    def off(self):
        val = libkdeuipythonc.KLedLamp_off(self.this)
        return val

    def __repr__(self):
        return "<KLedLamp instance at %s>" % self.this

class KLedLamp(KLedLampPtr):
    def __init__(self,parent="",name=""):
	KLedLampPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new_KLedLamp("NULL")
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new_KLedLamp(parent.this)
	    self.thisown = 0	    
