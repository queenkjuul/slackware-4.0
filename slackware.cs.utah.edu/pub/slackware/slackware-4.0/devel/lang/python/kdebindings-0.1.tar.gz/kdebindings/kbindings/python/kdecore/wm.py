import libkdecorepythonc


KWM_getProperties = libkdecorepythonc.KWM_getProperties

KWM_setProperties = libkdecorepythonc.KWM_setProperties

KWM_enableSessionManagement = libkdecorepythonc.KWM_enableSessionManagement

KWM_setWmCommand = libkdecorepythonc.KWM_setWmCommand

KWM_setUnsavedDataHint = libkdecorepythonc.KWM_setUnsavedDataHint

def KWM_setMiniIcon(arg0,arg1):
    val = libkdecorepythonc.KWM_setMiniIcon(arg0,arg1.this)
    return val

def KWM_setIcon(arg0,arg1):
    val = libkdecorepythonc.KWM_setIcon(arg0,arg1.this)
    return val

KWM_setDockWindow = libkdecorepythonc.KWM_setDockWindow

KWM_setDecoration = libkdecorepythonc.KWM_setDecoration

KWM_logout = libkdecorepythonc.KWM_logout

KWM_refreshScreen = libkdecorepythonc.KWM_refreshScreen

KWM_darkenScreen = libkdecorepythonc.KWM_darkenScreen

KWM_configureWm = libkdecorepythonc.KWM_configureWm

KWM_currentDesktop = libkdecorepythonc.KWM_currentDesktop

KWM_raiseSoundEvent = libkdecorepythonc.KWM_raiseSoundEvent

KWM_registerSoundEvent = libkdecorepythonc.KWM_registerSoundEvent

KWM_unregisterSoundEvent = libkdecorepythonc.KWM_unregisterSoundEvent
