from baseobject import *
from button import *
import libqtpythonc


class RadioButtonPtr(ButtonPtr):

    def __init__(self,this,name=""):
	ButtonPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_RadioButton(self.this)

    def isChecked(self):
        return libqtpythonc.RadioButton_isChecked(self.this)

    def setChecked(self,arg0):
        libqtpythonc.RadioButton_setChecked(self.this,arg0)

    def __repr__(self):
        return "<RadioButton instance at %s>" % self.this

class RadioButton(RadioButtonPtr):
    def __init__(self,text,parent="",name=""):
	RadioButtonPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_RadioButton(text,"NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_RadioButton(text,parent.this, name)
	    self.thisown = 0	    

