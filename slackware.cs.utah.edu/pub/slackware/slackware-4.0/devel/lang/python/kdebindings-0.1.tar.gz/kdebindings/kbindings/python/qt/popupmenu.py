import libqtpythonc
from frame import *


class PopupMenuPtr(FramePtr):

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_PopupMenu(self.this)

    def popup(self,pos,indexAtPoint=0):
        return libqtpythonc.PopupMenu_popup(self.this,pos,indexAtPoint)

    def setCheckable(self,arg0):
        return libqtpythonc.PopupMenu_setCheckable(self.this,arg0)

    def isCheckable(self):
        val = libqtpythonc.PopupMenu_isCheckable(self.this)
        return val

    def execute(self):
        val = libqtpythonc.PopupMenu_execute(self.this)
        return val

    def setActiveItem(self,arg0):
        val = libqtpythonc.PopupMenu_setActiveItem(self.this,arg0)
        return val

    def count(self):
        val = libqtpythonc.PopupMenu_count(self.this)
        return val

    def insertItem(self,arg0,arg1,*args):
        val = apply(libqtpythonc.PopupMenu__insertItem,(self.this,arg0,arg1,)+args)
        return val

    def insertPixmap(self,arg0,arg1,*args):
        val = apply(libqtpythonc.PopupMenu_insertPixmap,(self.this,arg0.this,arg1,)+args)
        return val

    def insertItemPixmap(self,arg0,arg1,arg2,*args):
        val = apply(libqtpythonc.PopupMenu_insertItemPixmap,(self.this,arg0.this,arg1,arg2,)+args)
        return val

    def insertItemAt(self,arg0,*args):
        val = apply(libqtpythonc.PopupMenu_insertItemAt,(self.this,arg0,)+args)
        return val

    def popupItemAt(self,arg0,arg1,*args):
        val = apply(libqtpythonc.PopupMenu_popupItemAt,(self.this,arg0,arg1.this,)+args)
        return val

    def insertPixmapAt(self,arg0,*args):
        val = apply(libqtpythonc.PopupMenu_insertPixmapAt,(self.this,arg0.this,)+args)
        return val

    def popupPixampAt(self,arg0,arg1,*args):
        val = apply(libqtpythonc.PopupMenu_popupPixampAt,(self.this,arg0.this,arg1.this,)+args)
        return val

    def insertItemPixmapAt(self,arg0,arg1,*args):
        val = apply(libqtpythonc.PopupMenu_insertItemPixmapAt,(self.this,arg0.this,arg1,)+args)
        return val

    def popupItemPixmapAt(self,arg0,arg1,arg2,*args):
        val = apply(libqtpythonc.PopupMenu_popupItemPixmapAt,(self.this,arg0.this,arg1,arg2.this,)+args)
        return val

    def insertSeparator(self,*args):
        val = apply(libqtpythonc.PopupMenu_insertSeparator,(self.this,)+args)
        return val

    def removeItem(self,arg0):
        val = libqtpythonc.PopupMenu_removeItem(self.this,arg0)
        return val

    def removeItemAt(self,arg0):
        val = libqtpythonc.PopupMenu_removeItemAt(self.this,arg0)
        return val

    def clear(self):
        val = libqtpythonc.PopupMenu_clear(self.this)
        return val

    def accel(self,arg0):
        val = libqtpythonc.PopupMenu_accel(self.this,arg0)
        return val

    def setAccel(self,arg0,arg1):
        val = libqtpythonc.PopupMenu_setAccel(self.this,arg0,arg1)
        return val

    def text(self,arg0):
        val = libqtpythonc.PopupMenu_text(self.this,arg0)
        return val

    def pixmap(self,arg0):
        val = libqtpythonc.PopupMenu_pixmap(self.this,arg0)
        val = PixmapPtr(val)
        return val

    def changeItem(self,arg0,arg1):
        val = libqtpythonc.PopupMenu_changeItem(self.this,arg0,arg1)
        return val

    def changePixmap(self,arg0,arg1):
        val = libqtpythonc.PopupMenu_changePixmap(self.this,arg0.this,arg1)
        return val

    def changeItemPixmap(self,arg0,arg1,arg2):
        val = libqtpythonc.PopupMenu_changeItemPixmap(self.this,arg0.this,arg1,arg2)
        return val

    def isItemEnabled(self,arg0):
        val = libqtpythonc.PopupMenu_isItemEnabled(self.this,arg0)
        return val

    def setItemEnabled(self,arg0,arg1):
        val = libqtpythonc.PopupMenu_setItemEnabled(self.this,arg0,arg1)
        return val

    def isItemChecked(self,arg0):
        val = libqtpythonc.PopupMenu_isItemChecked(self.this,arg0)
        return val

    def setItemChecked(self,arg0,arg1):
        val = libqtpythonc.PopupMenu_setItemChecked(self.this,arg0,arg1)
        return val

    def indexOf(self,arg0):
        val = libqtpythonc.PopupMenu_indexOf(self.this,arg0)
        return val

    def idAt(self,arg0):
        val = libqtpythonc.PopupMenu_idAt(self.this,arg0)
        return val

    def setId(self,arg0,arg1):
        val = libqtpythonc.PopupMenu_setId(self.this,arg0,arg1)
        return val

    def connectItem(self,arg0,arg1):
        val = libqtpythonc.PopupMenu__connectItem(self.this,arg0,arg1)
        return val

    def disconnectItem(self,arg0,arg1):
        val = libqtpythonc.PopupMenu__disconnectItem(self.this,arg0,arg1)
        return val

    def __repr__(self):
        return "<PopupMenu instance at %s>" % self.this


class PopupMenu(PopupMenuPtr):
    def __init__(self,parent="",name=""):
	PopupMenuPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_PopupMenu("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_PopupMenu(parent.this, name)
	    self.thisown = 0	    
