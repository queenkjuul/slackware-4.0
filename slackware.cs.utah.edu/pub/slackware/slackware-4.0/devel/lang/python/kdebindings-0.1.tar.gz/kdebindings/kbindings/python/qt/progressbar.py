from frame import *
import libqtpythonc


class ProgressBarPtr(FramePtr):

    def __init__(self,this,name=""):
	FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QProgressBar(self.this)

    def totalSteps(self):
        return libqtpythonc.QProgressBar_totalSteps(self.this)

    def progress(self):
        return libqtpythonc.QProgressBar_progress(self.this)

    def reset(self):
        libqtpythonc.QProgressBar_reset(self.this)

    def setTotalSteps(self,steps):
        libqtpythonc.QProgressBar_setTotalSteps(self.this,steps)

    def setProgress(self,value):
        libqtpythonc.QProgressBar_setProgress(self.this,value)

    def __repr__(self):
        return "<ProgressBar instance at %s>" % self.this

class ProgressBar(ProgressBarPtr):
    def __init__(self,steps=100,parent="",name="", flags=0):
	ProgressBarPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_QProgressBar(steps,"NULL", name, flags)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_QProgressBar(steps,parent.this, name, flags)
	    self.thisown = 0	    
