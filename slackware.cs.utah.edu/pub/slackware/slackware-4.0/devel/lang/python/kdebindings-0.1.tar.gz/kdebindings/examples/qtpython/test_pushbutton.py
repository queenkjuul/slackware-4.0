from qt.application import *
from qt.widget import *
from qt.pushbutton import *


# creation

a = Application()
w = Widget()


# add button

def f():
    print "Button pressed!"

b = PushButton("Press me", w)
b.move((16,8))
b.adjustSize()
b.connect("pressed", f)


# run

w.show()
a.setMainWidget(w)
a.execute()
del a