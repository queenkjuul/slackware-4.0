import libkdeuipythonc
from qt.lineedit import *


class KLineEditPtr(LineEditPtr):

    def __init__(self,this,name=""):
        LineEditPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__LineEdit(self.this)

    def cursorAtEnd(self):
        val = libkdeuipythonc._LineEdit_cursorAtEnd(self.this)
        return val

    def __repr__(self):
        return "<KLineEdit instance at %s>" % self.this

class KLineEdit(KLineEditPtr):
    def __init__(self,arg0,name) :
        KLineEditPtr.__init__(self,"NULL",name)
        self.this = libkdeuipythonc.new__LineEdit(arg0.this,arg1)
        self.thisown = 1
