import libqtpythonc
from baseobject import *


class PaintDeviceMetricsPtr(BaseObjectPtr):

    def __init__(self,this,name=""):
        BaseObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def width(self):
        val = libqtpythonc.QPaintDeviceMetrics_width(self.this)
        return val

    def height(self):
        val = libqtpythonc.QPaintDeviceMetrics_height(self.this)
        return val

    def widthMM(self):
        val = libqtpythonc.QPaintDeviceMetrics_widthMM(self.this)
        return val

    def heightMM(self):
        val = libqtpythonc.QPaintDeviceMetrics_heightMM(self.this)
        return val

    def numColors(self):
        val = libqtpythonc.QPaintDeviceMetrics_numColors(self.this)
        return val

    def depth(self):
        val = libqtpythonc.QPaintDeviceMetrics_depth(self.this)
        return val

    def __repr__(self):
        return "<PaintDeviceMetrics instance at %s>" % self.this

class PaintDeviceMetrics(PaintDeviceMetricsPtr):
    def __init__(self,arg0,name="") :
        PaintDeviceMetricsPtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_QPaintDeviceMetrics(arg0.this)
        self.thisown = 1

