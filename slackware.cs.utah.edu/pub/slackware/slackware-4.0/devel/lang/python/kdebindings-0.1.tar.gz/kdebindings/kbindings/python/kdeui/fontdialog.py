import libkdeuipythonc
from qt.font import *
from qt.dialog import *


class KFontDialogPtr(DialogPtr):

    def __init__(self,this,name=""):
        QDialogPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def setFont(self,arg0):
        val = libkdeuipythonc._FontDialog_setFont(self.this,arg0.this)
        return val

    def font(self):
        val = libkdeuipythonc._FontDialog_font(self.this)
        val = FontPtr(val)
        val.thisown = 1
        return val

    def __repr__(self):
        return "<KFontDialog instance at %s>" % self.this

class KFontDialog(KFontDialogPtr):
    def __init__(self,parent="",name="",modal=0,fontlist=""):
	KFontDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__FontDialog("NULL",name,modal,fontlist)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__FontDialog(parent.this,name,modal,fontlist)
	    self.thisown = 0	    


def KFontDialog_getFont(arg0):
    val = libkdeuipythonc._FontDialog_getFont(arg0.this)
    return val

