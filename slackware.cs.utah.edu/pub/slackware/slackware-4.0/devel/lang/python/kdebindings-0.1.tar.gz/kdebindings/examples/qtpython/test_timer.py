from qt.application import *
from qt.timer import *


#create application

a = Application()


# create some timers

t = Timer(a)
s = Timer(a)


# connect some functions

def f():
    print "Timer elapsed!"

def g():
    a.quit()


t.connect("timeout", f)
s.connect("timeout", g)

print t.isActive()


# do some timing

t.start(1000)
s.start(5000,1)

t.changeInterval(500)

# execute

a.execute()


del a