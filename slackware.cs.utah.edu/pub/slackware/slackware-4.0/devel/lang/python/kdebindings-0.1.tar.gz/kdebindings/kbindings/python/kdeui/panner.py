import libkdeuipythonc
from qt.widget import *


class KPannerPtr(WidgetPtr):

    Vertical = libkdeuipythonc.KNewPanner_Vertical
    Horizontal = libkdeuipythonc.KNewPanner_Horizontal

    Percent = libkdeuipythonc.KNewPanner_Percent
    Absolute = libkdeuipythonc.KNewPanner_Absolute

    def __init__(self,this,name=""):
        WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete_KNewPanner(self.this)

    def activate(self,arg0,arg1):
        val = libkdeuipythonc.KNewPanner_activate(self.this,arg0.this,arg1.this)
        return val

    def deactivate(self):
        val = libkdeuipythonc.KNewPanner_deactivate(self.this)
        return val

    def setLabels(self,arg0,arg1):
        val = libkdeuipythonc.KNewPanner_setLabels(self.this,arg0,arg1)
        return val

    def showLabels(self,arg0):
        val = libkdeuipythonc.KNewPanner_showLabels(self.this,arg0)
        return val

    def separatorPos(self):
        val = libkdeuipythonc.KNewPanner_separatorPos(self.this)
        return val

    def setSeparatorPos(self,arg0):
        val = libkdeuipythonc.KNewPanner_setSeparatorPos(self.this,arg0)
        return val

    def absSeparatorPos(self):
        val = libkdeuipythonc.KNewPanner_absSeparatorPos(self.this)
        return val

    def setAbsSeparatorPos(self,arg0,*args):
        val = apply(libkdeuipythonc.KNewPanner_setAbsSeparatorPos,(self.this,arg0,)+args)
        return val

    def units(self):
        val = libkdeuipythonc.KNewPanner_units(self.this)
        return val

    def setUnits(self,arg0):
        val = libkdeuipythonc.KNewPanner_setUnits(self.this,arg0)
        return val

    def __repr__(self):
        return "<KNewPanner instance at %s>" % self.this

class KPanner(KPannerPtr):
    def __init__(self,parent="",name="",orient=libkdeuipythonc.KNewPanner_Vertical,units=libkdeuipythonc.KNewPanner_Percent,pos=50):
	KPannerPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new_KNewPanner("NULL",name,orient,units,pos)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new_KNewPanner(parent.this,name,orient,units,pos)
	    self.thisown = 0	    
