import libqtpythonc
from object import *
from layout import *
from boxlayout import *


class HBoxLayoutPtr(BoxLayoutPtr):

    def __init__(self,this,name=""):
        BoxLayoutPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QHBoxLayout(self.this)

    def __repr__(self):
        return "<HBoxLayout instance at %s>" % self.this

class HBoxLayout(HBoxLayoutPtr):
    def __init__(self,autoBorder=-1,name="") :
        HBoxLayoutPtr.__init__(self,"NULL",name) 
        self.this = libqtpythonc.new_QHBoxLayout(autoBorder,name)
        self.thisown = 1


def HBoxLayoutParent(parent,border=0,autoBorder=-1,name="") :
    val = HBoxLayoutPtr(libqtpythonc.new_QHBoxLayoutParent(parent.this,border,autoBorder,name),name)
    val.thisown = 1
    return val
