# This file was created automatically by SWIG.
import Qtlibraryc
