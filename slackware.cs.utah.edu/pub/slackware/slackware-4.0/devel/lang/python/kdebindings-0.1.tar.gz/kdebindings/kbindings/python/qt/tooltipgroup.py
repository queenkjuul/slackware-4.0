import libqtpythonc
from object import *


class ToolTipGroupPtr(ObjectPtr):

    def __init__(self,this,name=""):
        ObjectPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_ToolTipGroup(self.this)

    def __repr__(self):
        return "<ToolTipGroup instance at %s>" % self.this

class ToolTipGroup(ToolTipGroupPtr):
    def __init__(self,parent,name="") :
        ToolTipGroupPtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_ToolTipGroup(parent.this)
        self.thisown = 1


