import libkdecorepythonc
from qt.baseobject import *
from qt.object import *


class KSocketPtr(ObjectPtr):

    def __init__(self,this,name=""):
        ObjectPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete__Socket(self.this)

    def socket(self):
        val = libkdecorepythonc._Socket_socket(self.this)
        return val

    def enableRead(self,arg0):
        val = libkdecorepythonc._Socket_enableRead(self.this,arg0)
        return val

    def enableWrite(self,arg0):
        val = libkdecorepythonc._Socket_enableWrite(self.this,arg0)
        return val

    def getAddr(self):
        val = libkdecorepythonc._Socket_getAddr(self.this)
        return val

    def slotWrite(self,arg0):
        val = libkdecorepythonc._Socket_slotWrite(self.this,arg0)
        return val

    def slotRead(self,arg0):
        val = libkdecorepythonc._Socket_slotRead(self.this,arg0)
        return val

    def __repr__(self):
        return "<KSocket instance at %s>" % self.this

class KSocket(KSocketPtr):
    def __init__(self,arg0,name="") :
        KSocketPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new__Socket(arg0)
        self.thisown = 1

def KSocketInit(arg0,name="") :
    val = KSocketPtr(libkdecorepythonc.new__SocketInit(arg0),name)
    val.thisown = 1
    return val

def KSocketHost(arg0,arg1,name="") :
    val = KSocketPtr(libkdecorepythonc.new__SocketHost(arg0,arg1),name)
    val.thisown = 1
    return val


class KServerSocketPtr(ObjectPtr):

    def __init__(self,this,name=""):
	ObjectPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete__ServerSocket(self.this)

    def socket(self):
        val = libkdecorepythonc._ServerSocket_socket(self.this)
        return val

    def getPort(self):
        val = libkdecorepythonc._ServerSocket_getPort(self.this)
        return val

    def getAddr(self):
        val = libkdecorepythonc._ServerSocket_getAddr(self.this)
        return val

    def slotAccept(self,arg0):
        val = libkdecorepythonc._ServerSocket_slotAccept(self.this,arg0)
        return val

    def __repr__(self):
        return "<KServerSocket instance at %s>" % self.this

class KServerSocket(KServerSocketPtr):
    def __init__(self,arg0,name="") :
        KServerSocketPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new__ServerSocket(arg0)
        self.thisown = 1

def KServerSocketPort(arg0,name="") :
    val = KServerSocketPtr(libkdecorepythonc.new__ServerSocketPort(arg0),name)
    val.thisown = 1
    return val

