import libqtpythonc
from frame import *


class MenuBarPtr(FramePtr):

    Never = libqtpythonc.MenuBar_Never
    InWindowsStyle = libqtpythonc.MenuBar_InWindowsStyle

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_MenuBar(self.this)

    def heightForWidth(self,arg0):
        return libqtpythonc.MenuBar_heightForWidth(self.this,arg0)

    def separator(self):
        return libqtpythonc.MenuBar_separator(self.this)

    def setSeparator(self,arg0):
        libqtpythonc.MenuBar_setSeparator(self.this,arg0)

    def count(self):
        return libqtpythonc.MenuBar_count(self.this)

    def insertItem(self,text,slot,accel=0):
        return libqtpythonc.MenuBar__insertItem(self.this,text,slot,accel)

    def insertItemAt(self,text,id=-1,index=-1):
        return libqtpythonc.MenuBar_insertItemAt(self.this,text,id,index)

    def insertPixmapAt(self,pixmap,id=-1,index=-1):
        return libqtpythonc.MenuBar_insertPixmapAt(self.this,pixmap.this,id,index)

    def insertItemPixmapAt(self,pixmap,text,id=-1,index=-1):
        return libqtpythonc.MenuBar_insertItemPixmapAt(self.this,pixmap.this,text,id,index)

    def popupItemAt(self,text,popup,id=-1,index=-1):
        return libqtpythonc.MenuBar_popupItemAt(self.this,text,popup.this,id,index)

    def popupPixampAt(self,pixmap,popup,id=-1,index=-1):
        return libqtpythonc.MenuBar_popupPixampAt(self.this,pixmap.this,popup.this,id,index)

    def popupItemPixmapAt(self,pixmap,text,popup,id=-1,index=-1):
        return libqtpythonc.MenuBar_popupItemPixmapAt(self.this,pixmap.this,text,popup.this,id,index)

    def removeItem(self,arg0):
        libqtpythonc.MenuBar_removeItem(self.this,arg0)

    def removeItemAt(self,arg0):
        libqtpythonc.MenuBar_removeItemAt(self.this,arg0)

    def insertSeparator(self,index=-1):
        libqtpythonc.MenuBar_insertSeparator(self.this,index)

    def clear(self):
        libqtpythonc.MenuBar_clear(self.this)

    def accel(self,arg0):
        return libqtpythonc.MenuBar_accel(self.this,arg0)

    def setAccel(self,arg0,arg1):
        libqtpythonc.MenuBar_setAccel(self.this,arg0,arg1)

    def text(self,arg0):
        return libqtpythonc.MenuBar_text(self.this,arg0)

    def pixmap(self,arg0):
        val = PixmapPtr(libqtpythonc.MenuBar_pixmap(self.this,arg0))
        val.thisown = 0
        return val

    def changeItem(self,arg0,arg1):
        libqtpythonc.MenuBar_changeItem(self.this,arg0,arg1)

    def changePixmap(self,arg0,arg1):
        libqtpythonc.MenuBar_changePixmap(self.this,arg0.this,arg1)

    def changeItemPixmap(self,arg0,arg1,arg2):
        libqtpythonc.MenuBar_changeItemPixmap(self.this,arg0.this,arg1,arg2)

    def isItemEnabled(self,arg0):
        return libqtpythonc.MenuBar_isItemEnabled(self.this,arg0)

    def setItemEnabled(self,arg0,arg1):
        libqtpythonc.MenuBar_setItemEnabled(self.this,arg0,arg1)

    def isItemChecked(self,arg0):
        return libqtpythonc.MenuBar_isItemChecked(self.this,arg0)

    def setItemChecked(self,arg0,arg1):
        libqtpythonc.MenuBar_setItemChecked(self.this,arg0,arg1)

    def indexOf(self,arg0):
        return libqtpythonc.MenuBar_indexOf(self.this,arg0)

    def idAt(self,arg0):
        return libqtpythonc.MenuBar_idAt(self.this,arg0)

    def setId(self,arg0,arg1):
        libqtpythonc.MenuBar_setId(self.this,arg0,arg1)

    def connectItem(self,arg0,arg1):
        return libqtpythonc.MenuBar__connectItem(self.this,arg0,arg1)

    def disconnectItem(self,arg0,arg1):
        val = libqtpythonc.MenuBar__disconnectItem(self.this,arg0,arg1)
        return val

    def __repr__(self):
        return "<MenuBar instance at %s>" % self.this

class MenuBar(MenuBarPtr):
    def __init__(self,parent="",name=""):
	MenuBarPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_MenuBar("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_MenuBar(parent.this, name)
	    self.thisown = 0	    
