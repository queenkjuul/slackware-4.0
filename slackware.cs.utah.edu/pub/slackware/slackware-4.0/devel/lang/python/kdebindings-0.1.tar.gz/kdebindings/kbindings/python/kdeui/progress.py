import libkdeuipythonc
from qt.frame import *
from qt.rangecontrol import *


class KProgressPtr(FramePtr,RangeControlPtr):

    Horizontal = libkdeuipythonc._Progress_Horizontal
    Vertical = libkdeuipythonc._Progress_Vertical

    Solid = libkdeuipythonc._Progress_Solid
    Blocked = libkdeuipythonc._Progress_Blocked

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
      	RangeControlPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__Progress(self.this)

    def setBarStyle(self,arg0):
        val = libkdeuipythonc._Progress_setBarStyle(self.this,arg0)
        return val

    def setBarColor(self,arg0):
        val = libkdeuipythonc._Progress_setBarColor(self.this,arg0.this)
        return val

    def setBarPixmap(self,arg0):
        val = libkdeuipythonc._Progress_setBarPixmap(self.this,arg0.this)
        return val

    def setOrientation(self,arg0):
        val = libkdeuipythonc._Progress_setOrientation(self.this,arg0)
        return val

    def setTextEnabled(self,arg0):
        val = libkdeuipythonc._Progress_setTextEnabled(self.this,arg0)
        return val

    def barStyle(self):
        val = libkdeuipythonc._Progress_barStyle(self.this)
        return val

    def barColor(self):
        val = libkdeuipythonc._Progress_barColor(self.this)
        val = QColorPtr(val)
        return val

    def barPixmap(self):
        val = libkdeuipythonc._Progress_barPixmap(self.this)
        val = QPixmapPtr(val)
        return val

    def orientation(self):
        val = libkdeuipythonc._Progress_orientation(self.this)
        return val

    def textEnabled(self):
        val = libkdeuipythonc._Progress_textEnabled(self.this)
        return val

    def setValue(self,arg0):
        val = libkdeuipythonc._Progress_setValue(self.this,arg0)
        return val

    def advance(self,arg0):
        val = libkdeuipythonc._Progress_advance(self.this,arg0)
        return val

    def __repr__(self):
        return "<KProgress instance at %s>" % self.this

class KProgress(KProgressPtr):
    def __init__(self,orient,parent="",name=""):
	KProgressPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__Progress(orient,"NULL", name)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new__Progress(orient,parent.this, name)
	    self.thisown = 0	    


def KProgressValues(minValue,maxValue,value,orient,parent="",name="") :
    if not parent:
        val = KProgressPtr(libkdeuipythonc.new__ProgressValues(minValue,maxValue,value,orient,"NULL",name))
        val.thisown = 1
    else:
        val = KProgressPtr(libkdeuipythonc.new__ProgressValues(minValue,maxValue,value,orient,parent.this,name))
        val.thisown = 0
    return val
