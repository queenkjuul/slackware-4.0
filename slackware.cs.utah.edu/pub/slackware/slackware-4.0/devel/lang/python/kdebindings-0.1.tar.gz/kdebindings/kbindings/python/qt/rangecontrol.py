from object import *
import libqtpythonc


class RangeControlPtr(ObjectPtr) : 

    def __init__(self,this,name=""):
        ObjectPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QRangeControl(self.this)

    def value(self):
        return libqtpythonc.QRangeControl_value(self.this)

    def setValue(self,value):
        libqtpythonc.QRangeControl_setValue(self.this,value)

    def addPage(self):
        libqtpythonc.QRangeControl_addPage(self.this)

    def subtractPage(self):
        libqtpythonc.QRangeControl_subtractPage(self.this)

    def addLine(self):
        libqtpythonc.QRangeControl_addLine(self.this)

    def subtractLine(self):
        libqtpythonc.QRangeControl_subtractLine(self.this)

    def minValue(self):
        return libqtpythonc.QRangeControl_minValue(self.this)

    def maxValue(self):
        return libqtpythonc.QRangeControl_maxValue(self.this)

    def setRange(self,min,max):
        return libqtpythonc.QRangeControl_setRange(self.this,min,max)

    def lineStep(self):
        return libqtpythonc.QRangeControl_lineStep(self.this)

    def pageStep(self):
        return libqtpythonc.QRangeControl_pageStep(self.this)

    def setSteps(self,line,page):
        libqtpythonc.QRangeControl_setSteps(self.this,line,page)

    def __repr__(self):
        return "<RangeControl instance at %s>" % self.this

class RangeControl(RangeControlPtr):
    def __init__(self,min=0,max=99,line=1,page=10,value=0,name=""):
        RangeControlPtr.__init__(self,"NULL",name)  
        self.this = libqtpythonc.new_QRangeControl(min,max,line,page,value)
        self.thisown = 1

