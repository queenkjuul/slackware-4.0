import libkdeuipythonc
from qt.dialog import *
from qt.color import *


class KColorDialogPtr(DialogPtr):

    def __init__(self,this,name=""):
        DialogPtr.__init__(self,this,name="")
        self.this = this
        self.thisown = 0

    def setColor(self,arg0):
        val = libkdeuipythonc._ColorDialog_setColor(self.this,arg0.this)
        return val

    def color(self):
        val = libkdeuipythonc._ColorDialog_color(self.this)
        val = ColorPtr(val)
        val.thisown = 1
        return val

    def __repr__(self):
        return "<KColorDialog instance>"

class KColorDialog(KColorDialogPtr):
    def __init__(self,parent="",name="",modal=0):
	KColorDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__ColorDialog("NULL",name,modal)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__ColorDialog(parent.this,name,modal)
	    self.thisown = 0	    


def KColorDialog_getColor(arg0):
    val = libkdeuipythonc._ColorDialog_getColor(arg0.this)
    return val



