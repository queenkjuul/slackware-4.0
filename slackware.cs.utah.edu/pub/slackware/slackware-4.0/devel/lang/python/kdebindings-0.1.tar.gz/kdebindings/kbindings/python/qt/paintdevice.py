from object import *
import libqtpythonc


class PaintDevicePtr(ObjectPtr):

    def __init__(self,this,name=""):
        ObjectPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QPaintdevice(self.this)

    def devType(self):
        return libqtpythonc.PaintDevice_devType(self.this)

    def isExtDev(self):
        return libqtpythonc.PaintDevice_isExtDev(self.this)

    def paintingActive(self):
        return libqtpythonc.PaintDevice_paintingActive(self.this)

    def __repr__(self):
        return "<PaintDevice instance at %s>" % self.this

class PaintDevice(PaintDevicePtr):
    def __init__(self,this,name=""):
        PaintDevicePtr.__init__(self,"NULL",name)
        self.this = new_QPaintDevice()
        self.thisown = 1

