import libkdeuipythonc
from qt.slider import *


class KSliderPtr(SliderPtr):

    def __init__(self,this,name=""):
        SliderPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __repr__(self):
        return "<KSlider instance at %s>" % self.this

class KSlider(KSliderPtr):
    def __init__(self,orient,parent="",name=""):
	KSliderPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__Slider(orient,"NULL", name)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new__Slider(orient,parent.this, name)
	    self.thisown = 0	    



def KSliderValues(minValue,maxValue,step,value,orient,parent="",name="") :
    if not parent:
        val = KSliderPtr(libkdeuipythonc.new__SliderValues(minValue,maxValue,step,value,orient,"NULL",name))
        val.thisown = 1
    else:
        val = KSliderPtr(libkdeuipythonc.new__SliderValues(minValue,maxValue,step,value,orient,parent.this,name))
        val.thisown = 0
    return val
