from widget import * 
from frame import *
import libqtpythonc
from pixmap import *


class LabelPtr(FramePtr):

    def __init__(self,this,name=""):
	FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QLabel(self.this)

    def text(self):
        return libqtpythonc.QLabel_text(self.this)

    def pixmap(self):
        val = PixmapPtr(libqtpythonc.QLabel_pixmap(self.this))
	val.thisown = 0
	return val

    def movie(self):
        return libqtpythonc.QLabel_movie(self.this)

    def alignment(self):
        return libqtpythonc.QLabel_alignment(self.this)

    def setAlignment(self,align):
        libqtpythonc.QLabel_setAlignment(self.this,align)

    def margin(self):
        return libqtpythonc.QLabel_margin(self.this)

    def setMargin(self,margin):
        libqtpythonc.QLabel_setMargin(self.this,margin)

    def autoResize(self):
        return libqtpythonc.QLabel_autoResize(self.this)

    def setAutoResize(self,auto):
        libqtpythonc.QLabel_setAutoResize(self.this,auto)

    def setBuddy(self,buddy):
        libqtpythonc.QLabel_setBuddy(self.this,buddy.this)

    def buddy(self):
        val = WidgetPtr(libqtpythonc.QLabel_buddy(self.this))
	val.thisown = 0
        return val

    def setText(self,text):
        libqtpythonc.QLabel_setText(self.this,text)

    def setPixmap(self,pixmap):
        libqtpythonc.QLabel_setPixmap(self.this,pixmap.this)

    def setMovie(self,movie):
        libqtpythonc.QLabel_setMovie(self.this,movie)

    def setNum(self,number):
        libqtpythonc.QLabel_setNum(self.this,number)

    def setFloat(self,number):
        libqtpythonc.QLabel_setFloat(self.this,number)

    def __repr__(self):
        return "<Label instance at %s>" % self.this

class Label(LabelPtr):
    def __init__(self,text,parent="",name="", flags=0):
	LabelPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_QLabel(text, "NULL", name, flags)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_QLabel(text, parent.this, name, flags)
	    self.thisown = 0	    

def LabelBuddy(buddy,text,parent="",name="",flags=0) :
    if not parent:
       val = LabelPtr(libqtpythonc.new_QLabelBuddy(buddy.this,text,"NULL",name,flags),name)
       val.thisown = 1
    else:
       val = LabelPtr(libqtpythonc.new_QLabelBuddy(buddy.this,text,parent.this,name,flags),name)
       val.thisown = 0
    return val


