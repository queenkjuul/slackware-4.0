import libqtpythonc
from paintdevice import *


class PrinterPtr(PaintDevicePtr):

    Portrait = libqtpythonc.QPrinter_Portrait
    Landscape = libqtpythonc.QPrinter_Landscape
    A4 = libqtpythonc.QPrinter_A4
    B5 = libqtpythonc.QPrinter_B5
    Letter = libqtpythonc.QPrinter_Letter
    Legal = libqtpythonc.QPrinter_Legal
    Executive = libqtpythonc.QPrinter_Executive

    def __init__(self,this,name=""):
        PaintDevicePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QPrinter(self.this)

    def printerName(self):
        val = libqtpythonc.QPrinter_printerName(self.this)
        return val

    def setPrinterName(self,arg0):
        val = libqtpythonc.QPrinter_setPrinterName(self.this,arg0)
        return val

    def outputToFile(self):
        val = libqtpythonc.QPrinter_outputToFile(self.this)
        return val

    def setOutputToFile(self,arg0):
        val = libqtpythonc.QPrinter_setOutputToFile(self.this,arg0)
        return val

    def outputFileName(self):
        val = libqtpythonc.QPrinter_outputFileName(self.this)
        return val

    def setOutputFileName(self,arg0):
        val = libqtpythonc.QPrinter_setOutputFileName(self.this,arg0)
        return val

    def printProgram(self):
        val = libqtpythonc.QPrinter_printProgram(self.this)
        return val

    def setPrintProgram(self,arg0):
        val = libqtpythonc.QPrinter_setPrintProgram(self.this,arg0)
        return val

    def docName(self):
        val = libqtpythonc.QPrinter_docName(self.this)
        return val

    def setDocName(self,arg0):
        val = libqtpythonc.QPrinter_setDocName(self.this,arg0)
        return val

    def creator(self):
        val = libqtpythonc.QPrinter_creator(self.this)
        return val

    def setCreator(self,arg0):
        val = libqtpythonc.QPrinter_setCreator(self.this,arg0)
        return val

    def orientation(self):
        val = libqtpythonc.QPrinter_orientation(self.this)
        return val

    def setOrientation(self,arg0):
        val = libqtpythonc.QPrinter_setOrientation(self.this,arg0)
        return val

    def pageSize(self):
        val = libqtpythonc.QPrinter_pageSize(self.this)
        return val

    def setPageSize(self,arg0):
        val = libqtpythonc.QPrinter_setPageSize(self.this,arg0)
        return val

    def fromPage(self):
        val = libqtpythonc.QPrinter_fromPage(self.this)
        return val

    def toPage(self):
        val = libqtpythonc.QPrinter_toPage(self.this)
        return val

    def setFromTo(self,arg0,arg1):
        val = libqtpythonc.QPrinter_setFromTo(self.this,arg0,arg1)
        return val

    def minPage(self):
        val = libqtpythonc.QPrinter_minPage(self.this)
        return val

    def maxPage(self):
        val = libqtpythonc.QPrinter_maxPage(self.this)
        return val

    def setMinMax(self,arg0,arg1):
        val = libqtpythonc.QPrinter_setMinMax(self.this,arg0,arg1)
        return val

    def numCopies(self):
        val = libqtpythonc.QPrinter_numCopies(self.this)
        return val

    def setNumCopies(self,arg0):
        val = libqtpythonc.QPrinter_setNumCopies(self.this,arg0)
        return val

    def newPage(self):
        val = libqtpythonc.QPrinter_newPage(self.this)
        return val

    def abort(self):
        val = libqtpythonc.QPrinter_abort(self.this)
        return val

    def aborted(self):
        val = libqtpythonc.QPrinter_aborted(self.this)
        return val

    def setup(self,*args):
        argl = map(None,args)
        try: argl[0] = argl[0].this
        except: pass
        args = tuple(argl)
        val = apply(libqtpythonc.QPrinter_setup,(self.this,)+args)
        return val

    def __repr__(self):
        return "<Printer instance at %s>" % self.this

class Printer(PrinterPtr):
    def __init__(self,name="") :
        PrinterPtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_QPrinter()
        self.thisown = 1
