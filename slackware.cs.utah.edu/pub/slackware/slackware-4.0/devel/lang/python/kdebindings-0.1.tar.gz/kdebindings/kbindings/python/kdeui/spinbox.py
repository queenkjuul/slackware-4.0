import libkdeuipythonc
from qt.widget import *


class KSpinBoxPtr(WidgetPtr):

    def __init__(self,this,name=""):
        WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__SpinBox(self.this)

    def getValue(self):
        val = libkdeuipythonc._SpinBox_getValue(self.this)
        return val

    def setValue(self,arg0):
        val = libkdeuipythonc._SpinBox_setValue(self.this,arg0)
        return val

    def isEditable(self):
        val = libkdeuipythonc._SpinBox_isEditable(self.this)
        return val

    def setEditable(self,arg0):
        val = libkdeuipythonc._SpinBox_setEditable(self.this,arg0)
        return val

    def setAlign(self,arg0):
        val = libkdeuipythonc._SpinBox_setAlign(self.this,arg0)
        return val

    def getAlign(self):
        val = libkdeuipythonc._SpinBox_getAlign(self.this)
        return val

    def slotIncrease(self):
        val = libkdeuipythonc._SpinBox_slotIncrease(self.this)
        return val

    def slotDecrease(self):
        val = libkdeuipythonc._SpinBox_slotDecrease(self.this)
        return val

    def __repr__(self):
        return "<KSpinBox instance at %s>" % self.this

class KSpinBox(KSpinBoxPtr):
    def __init__(self,parent="",name="",align=0):
	KSpinBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__SpinBox("NULL", name, align)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new__SpinBox(parent.this, name, align)
	    self.thisown = 0	    


class KNumericSpinBoxPtr(KSpinBoxPtr):

    def __init__(self,this,name=""):
        KSpinBoxPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__NumericSpinBox(self.this)

    def getStep(self):
        val = libkdeuipythonc._NumericSpinBox_getStep(self.this)
        return val

    def setStep(self,arg0):
        val = libkdeuipythonc._NumericSpinBox_setStep(self.this,arg0)
        return val

    def getRange(self,arg0,arg1):
        val = libkdeuipythonc._NumericSpinBox_getRange(self.this,arg0,arg1)
        return val

    def setRange(self,arg0,arg1):
        val = libkdeuipythonc._NumericSpinBox_setRange(self.this,arg0,arg1)
        return val

    def __repr__(self):
        return "<KNumericSpinBox instance at %s>" % self.this

class KNumericSpinBox(KNumericSpinBoxPtr):
    def __init__(self,parent="",name="",align=0):
	KNumericSpinBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__NumericSpinBox("NULL", name, align)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new__NumericSpinBox(parent.this, name, align)
	    self.thisown = 0	    


class KListSpinBoxPtr(KSpinBoxPtr):

    def __init__(self,this,name=""):
        KSpinBoxPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__ListSpinBox(self.this)

    def setIndex(self,arg0):
        val = libkdeuipythonc._ListSpinBox_setIndex(self.this,arg0)
        return val

    def getIndex(self):
        val = libkdeuipythonc._ListSpinBox_getIndex(self.this)
        return val

    def __repr__(self):
        return "<KListSpinBox instance at %s>" % self.this 

class KListSpinBox(KListSpinBoxPtr):
    def __init__(self,list,parent="",name="",align=0):
	KListSpinBoxPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__ListSpinBox(list,"NULL", name, align)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new__ListSpinBox(list,parent.this, name, align)
	    self.thisown = 0	    

