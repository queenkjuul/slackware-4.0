import libqtpythonc
from object import *


class LayoutPtr(ObjectPtr):

    unlimited = libqtpythonc.QLayout_unlimited

    def __init__(self,this,name=""):
        ObjectPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QLayout(self.this)

    def defaultBorder(self):
        val = libqtpythonc.QLayout_defaultBorder(self.this)
        return val

    def activate(self):
        val = libqtpythonc.QLayout_activate(self.this)
        return val

    def freeze(self,arg0,arg1):
        val = libqtpythonc.QLayout_freeze(self.this,arg0,arg1)
        return val

    def freezeMin(self):
        val = libqtpythonc.QLayout_freezeMin(self.this)
        return val

    def setMenuBar(self,arg0):
        val = libqtpythonc.QLayout_setMenuBar(self.this,arg0)
        return val

    def mainWidget(self):
        val = libqtpythonc.QLayout_mainWidget(self.this)
        val = WidgetPtr(val)
        return val

    def __repr__(self):
        return "<Layout instance at %s>" % self.this

class Layout(LayoutPtr):
    def __init__(self,this,name=""):
        Layout.__init__(self,"NULL",name)            
        self.this = this

