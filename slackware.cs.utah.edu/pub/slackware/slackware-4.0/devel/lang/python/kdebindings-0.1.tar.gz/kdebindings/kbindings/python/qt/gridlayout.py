import libqtpythonc
from object import *
from layout import *


class GridLayoutPtr(LayoutPtr):

    def __init__(self,this,name=""):
        LayoutPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QGridLayout(self.this)

    def addWidget(self,arg0,arg1,arg2,*args):
        val = apply(libqtpythonc.QGridLayout_addWidget,(self.this,arg0.this,arg1,arg2,)+args)
        return val

    def addMultiCellWidget(self,arg0,arg1,arg2,arg3,arg4,*args):
        val = apply(libqtpythonc.QGridLayout_addMultiCellWidget,(self.this,arg0.this,arg1,arg2,arg3,arg4,)+args)
        return val

    def addLayout(self,arg0,arg1,arg2):
        val = libqtpythonc.QGridLayout_addLayout(self.this,arg0.this,arg1,arg2)
        return val

    def setRowStretch(self,arg0,arg1):
        val = libqtpythonc.QGridLayout_setRowStretch(self.this,arg0,arg1)
        return val

    def setColStretch(self,arg0,arg1):
        val = libqtpythonc.QGridLayout_setColStretch(self.this,arg0,arg1)
        return val

    def addRowSpacing(self,arg0,arg1):
        val = libqtpythonc.QGridLayout_addRowSpacing(self.this,arg0,arg1)
        return val

    def addColSpacing(self,arg0,arg1):
        val = libqtpythonc.QGridLayout_addColSpacing(self.this,arg0,arg1)
        return val

    def __repr__(self):
        return "<GridLayout instance at %s>" % self.this

class GridLayout(GridLayoutPtr):
    def __init__(self,rows,cells,autoBorder=-1,name="") :
        GridLayoutPtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_QGridLayout(rows,cells,autoBorder,name)
        self.thisown = 1



def GridLayoutParent(arg0,arg1,arg2,border=0,autoBorder=-1,name="") :
    val = GridLayoutPtr(libqtpythonc.new_QGridLayoutParent(arg0.this,arg1,arg2,border,autoBorder,name),name)
    val.thisown = 1
    return val

