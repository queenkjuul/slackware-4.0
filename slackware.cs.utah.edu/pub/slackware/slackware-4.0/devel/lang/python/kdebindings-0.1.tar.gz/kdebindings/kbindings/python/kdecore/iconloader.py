import libkdecorepythonc
from qt.object import *
from qt.pixmap import *


class KIconLoaderPtr(ObjectPtr) :

    def __init__(self,this,name=""):
	ObjectPtr.__init__(self, this, name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete_KIconLoader(self.this)

    def loadIcon(self,arg0,*args):
        val = apply(libkdecorepythonc.KIconLoader_loadIcon,(self.this,arg0,)+args)
        val = PixmapPtr(val)
        val.thisown = 1
        return val

    def loadMiniIcon(self,arg0,*args):
        val = apply(libkdecorepythonc.KIconLoader_loadMiniIcon,(self.this,arg0,)+args)
        val = PixmapPtr(val)
        val.thisown = 1
        return val

    def loadApplicationIcon(self,arg0,*args):
        val = apply(libkdecorepythonc.KIconLoader_loadApplicationIcon,(self.this,arg0,)+args)
        val = PixmapPtr(val)
        val.thisown = 1
        return val

    def loadApplicationMiniIcon(self,arg0,*args):
        val = apply(libkdecorepythonc.KIconLoader_loadApplicationMiniIcon,(self.this,arg0,)+args)
        val = PixmapPtr(val)
        val.thisown = 1
        return val

    def insertDirectory(self,arg0,arg1):
        val = libkdecorepythonc.KIconLoader_insertDirectory(self.this,arg0,arg1)
        return val

    def getDirList(self):
        val = libkdecorepythonc.KIconLoader_getDirList(self.this)
        return val

    def __repr__(self):
        return "<IconLoader instance at %s>" % self.this

class KIconLoader(KIconLoaderPtr):
    def __init__(self,name="") :
        KIconLoaderPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new_KIconLoader()
        self.thisown = 1



def KIconLoaderConfig(arg0,arg1,arg2,name="") :
    val = KIconLoaderPtr(libkdecorepythonc.new_KIconLoaderConfig(arg0.this,arg1,arg2),name)
    val.thisown = 1
    return val
