import libkdeuipythonc
from kde.restrictedline import *


class KIntegerLinePtr(KRestrictedLinePtr):

    def __init__(self,this,name=""):
        KRestrictedLinePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete_KIntegerLine(self.this)

    def getType(self):
        val = libkdeuipythonc.KIntegerLine_getType(self.this)
        return val

    def value(self):
        val = libkdeuipythonc.KIntegerLine_value(self.this)
        return val

    def setValue(self,arg0):
        val = libkdeuipythonc.KIntegerLine_setValue(self.this,arg0)
        return val

    def __repr__(self):
        return "<KIntegerLine instance at %s>" % self.this

class KIntegerLine(KIntegerLinePtr):
    def __init__(self,parent="",name="",type=libkdeuipythonc.KEditTypeDec):
	KIntegerLinePtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new_KIntegerLine("NULL", name, type)
            self.thisown = 1
        else:
            self.this = libqtkdeuithonc.new_KIntegerLine(parent.this, name, type)
	    self.thisown = 0	    


KEditTypeOct = libkdeuipythonc.KEditTypeOct
KEditTypeDec = libkdeuipythonc.KEditTypeDec
KEditTypeHex = libkdeuipythonc.KEditTypeHex
