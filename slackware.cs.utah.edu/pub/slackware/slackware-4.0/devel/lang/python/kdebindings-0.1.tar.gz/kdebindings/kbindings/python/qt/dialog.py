import libqtpythonc
from widget import *


class DialogPtr(WidgetPtr):

    Rejected = libqtpythonc.QDialog_Rejected
    Accepted = libqtpythonc.QDialog_Accepted

    def __init__(self,this,name=""):
        WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QDialog(self.this)

    def execute(self):
        val = libqtpythonc.QDialog_execute(self.this)
        return val

    def result(self):
        val = libqtpythonc.QDialog_result(self.this)
        return val

    def show(self):
        val = libqtpythonc.QDialog_show(self.this)
        return val

    def move(self,arg0):
        val = libqtpythonc.QDialog_move(self.this,arg0)
        return val

    def resize(self,arg0):
        val = libqtpythonc.QDialog_resize(self.this,arg0)
        return val

    def setGeometry(self,arg0):
        val = libqtpythonc.QDialog_setGeometry(self.this,arg0)
        return val

    def __repr__(self):
        return "<Dialog instance at %s>" % self.this


class Dialog(DialogPtr):
    def __init__(self,parent="",name="",modal=0,flags=0):
	DialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_Dialog("NULL",name,modal,flags)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_Dialog(parent.this,name,modal,flags)
	    self.thisown = 0	    





