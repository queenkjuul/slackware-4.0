import libqtpythonc
from baseobject import *


class FontInfoPtr(BaseObjectPtr):

    def __init__(self,this,name=""):
        BaseObjectPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_QFontInfo(self.this)

    def family(self):
        val = libqtpythonc.QFontInfo_family(self.this)
        return val

    def pointSize(self):
        val = libqtpythonc.QFontInfo_pointSize(self.this)
        return val

    def italic(self):
        val = libqtpythonc.QFontInfo_italic(self.this)
        return val

    def weight(self):
        val = libqtpythonc.QFontInfo_weight(self.this)
        return val

    def bold(self):
        val = libqtpythonc.QFontInfo_bold(self.this)
        return val

    def underline(self):
        val = libqtpythonc.QFontInfo_underline(self.this)
        return val

    def strikeOut(self):
        val = libqtpythonc.QFontInfo_strikeOut(self.this)
        return val

    def fixedPitch(self):
        val = libqtpythonc.QFontInfo_fixedPitch(self.this)
        return val

    def styleHint(self):
        val = libqtpythonc.QFontInfo_styleHint(self.this)
        return val

    def charSet(self):
        val = libqtpythonc.QFontInfo_charSet(self.this)
        return val

    def rawMode(self):
        val = libqtpythonc.QFontInfo_rawMode(self.this)
        return val

    def exactMatch(self):
        val = libqtpythonc.QFontInfo_exactMatch(self.this)
        return val

    def __repr__(self):
        return "<FontInfo instance at %s>" % self.this


class FontInfo(FontInfoPtr):
    def __init__(self,arg0,name="") :
        FontInfoPtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_QFontInfo(arg0.this)
        self.thisown = 1


def FontInfoCopy(arg0,name="") :
    val = FontInfoPtr(libqtpythonc.new_QFontInfoCopy(arg0.this),name)
    val.thisown = 1
    return val
