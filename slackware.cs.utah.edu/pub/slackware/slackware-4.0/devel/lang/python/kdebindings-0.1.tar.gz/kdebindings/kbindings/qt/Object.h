#ifndef _OBJECT_H_
#define _OBJECT_H_

#include <Python.h>
#include <qobject.h>
#include <qobjcoll.h>
#include "Baseobject.h"


class Object : public QObject, public BaseObject
{
  Q_OBJECT	

  public:

    Object(QObject *parent=0, const char *name=0) 
      : QObject(parent,name), BaseObject()
    {
	connect(this, SIGNAL(destroyed()), this, SLOT(sigDestroyed()));
    };
    ~Object() {};
    
  protected slots:

    void sigDestroyed() {
      _emit("destroyed", 0);
    };
};

#endif