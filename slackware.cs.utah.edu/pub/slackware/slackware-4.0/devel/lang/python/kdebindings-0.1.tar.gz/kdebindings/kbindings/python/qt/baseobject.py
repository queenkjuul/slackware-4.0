import libqtpythonc
import copy

#
# Definition of exeptions
#

#PropertyNotFoundError = 'property not found'
#PropertyReadOnlyError = 'property is read only'
#PropertyWriteOnlyError = 'property is write only'


#
# Definition of class BaseObject
#

class BaseObjectPtr:

    # static variables

    _classname = 'BaseObject'

    # housekeeping

    def __init__(self, this, n=""):
        self.this = this
        self.thisown = 0
	self._name = n

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_BaseObject(self.this)

    # access methods

    def getName(self):
	return self._name

    def setName(self, newName):
	self._name = newName

    def getClassname(self):
	return self._classname

    # signals / slots
  
    def connect(self,signal,slot):
        libqtpythonc.BaseObject__connect(self.this,signal,slot)

    def disconnect(self,slot,signal=""):
        libqtpythonc.BaseObject__disconnect(self.this,slot,signal)

    def emit(self,signal,args="NULL"):
        libqtpythonc.BaseObject__emit(self.this,signal,args)


    # property access methods

#    def __getattr__(self, attr):
#	try:
#	    method = self._properties[attr][0]
#	    if not method == 0:
#		return method(self)
#	    else:
#		raise PropertWriteOnlyError, attr
#	except KeyError:
#	    raise PropertyNotFoundError, attr

#    def __setattr__(self, attr, value):
#	try:
#	    method = self._properties[attr][1]
#	    if not method == 0:
#		return method(self, value)
#	    else:
#		raise PropertyReadOnlyError, attr
#	except PropertyReadOnlyError:	    
#	    raise PropertyReadOnlyError, attr
#	except:
#	    self.__dict__[attr] = value
	    
    # properties

#    def getPropertyList(self):
#	return self._properties.keys()

#    _properties = {'classname': (getClassname, 0, 'string'),
#	           'name'     : (getName, setName, 'string')
#                  }


    def __repr__(self):
        return "<BaseObject instance at %s>" % self.this


class BaseObject(BaseObjectPtr):
    def __init__(self,name=""):
	BaseObjectPtr.__init__(self,"NULL",name)
        self.this = libqtpythonc.new_BaseObject()
	self.thisown = 1


#
# end of BaseObject
