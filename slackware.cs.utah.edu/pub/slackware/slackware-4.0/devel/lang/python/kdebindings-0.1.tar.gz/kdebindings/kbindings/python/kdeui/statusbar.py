import libkdeuipythonc
from qt.frame import *


class KStatusBarPtr(FramePtr):

    Toggle = libkdeuipythonc._StatusBar_Toggle
    Show = libkdeuipythonc._StatusBar_Show
    Hide = libkdeuipythonc._StatusBar_Hide

    Top = libkdeuipythonc._StatusBar_Top
    Left = libkdeuipythonc._StatusBar_Left
    Bottom = libkdeuipythonc._StatusBar_Bottom
    Right = libkdeuipythonc._StatusBar_Right

    Floating = libkdeuipythonc._StatusBar_Floating
    LeftToRight = libkdeuipythonc._StatusBar_LeftToRight
    RightToLeft = libkdeuipythonc._StatusBar_RightToLeft

    def __init__(self,this,name=""):
        FramePtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdeuipythonc.delete__StatusBar(self.this)

    def insertItem(self,arg0,arg1):
        val = libkdeuipythonc._StatusBar_insertItem(self.this,arg0,arg1)
        return val

    def insertWidget(self,arg0,arg1,arg2):
        val = libkdeuipythonc._StatusBar_insertWidget(self.this,arg0.this,arg1,arg2)
        return val

    def removeItem(self,arg0):
        val = libkdeuipythonc._StatusBar_removeItem(self.this,arg0)
        return val

    def changeItem(self,arg0,arg1):
        val = libkdeuipythonc._StatusBar_changeItem(self.this,arg0,arg1)
        return val

    def setInsertOrder(self,arg0):
        val = libkdeuipythonc._StatusBar_setInsertOrder(self.this,arg0)
        return val

    def setAlignment(self,arg0,arg1):
        val = libkdeuipythonc._StatusBar_setAlignment(self.this,arg0,arg1)
        return val

    def setHeight(self,arg0):
        val = libkdeuipythonc._StatusBar_setHeight(self.this,arg0)
        return val

    def setBorderWidth(self,arg0):
        val = libkdeuipythonc._StatusBar_setBorderWidth(self.this,arg0)
        return val

    def enable(self,arg0):
        val = libkdeuipythonc._StatusBar_enable(self.this,arg0)
        return val

    def message(self,arg0,*args):
        val = apply(libkdeuipythonc._StatusBar_message,(self.this,arg0,)+args)
        return val

    def messageWidget(self,arg0,*args):
        val = apply(libkdeuipythonc._StatusBar_messageWidget,(self.this,arg0.this,)+args)
        return val

    def clear(self):
        val = libkdeuipythonc._StatusBar_clear(self.this)
        return val

    def __repr__(self):
        return "<KStatusBar instance at %s>" % self.this

class KStatusBar(KStatusBarPtr):
    def __init__(self,parent="",name=""):
	KStatusBarPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libkdeuipythonc.new__StatusBar("NULL", name)
            self.thisown = 1
        else:
            self.this = libkdeuipythonc.new__StatusBar(parent.this, name)
	    self.thisown = 0	    
