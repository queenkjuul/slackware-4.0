import libkdecorepythonc
from qt.pixmap import *


class KPixmapPtr(PixmapPtr):

    Auto = libkdecorepythonc.KPixmap_Auto
    Color = libkdecorepythonc.KPixmap_Color
    Mono = libkdecorepythonc.KPixmap_Mono
    LowColor = libkdecorepythonc.KPixmap_LowColor
    WebColor = libkdecorepythonc.KPixmap_WebColor

    def __init__(self,this,name=""):
       	PixmapPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete_KPixmap(self.this)

    def gradientFill(self,arg0,arg1,*args):
        val = apply(libkdecorepythonc.KPixmap_gradientFill,(self.this,arg0.this,arg1.this,)+args)
        return val

    def patternFill(self,arg0,arg1,arg2):
        val = libkdecorepythonc.KPixmap_patternFill(self.this,arg0.this,arg1.this,arg2)
        return val

    def convertFromImage(self,arg0,arg1):
        val = libkdecorepythonc.KPixmap_convertFromImage(self.this,arg0.this,arg1)
        return val

    def convertFromImageMode(self,arg0,*args):
        val = apply(libkdecorepythonc.KPixmap_convertFromImageMode,(self.this,arg0.this,)+args)
        return val

    def load(self,arg0,arg1,arg2):
        val = libkdecorepythonc.KPixmap_load(self.this,arg0,arg1,arg2)
        return val

    def loadMode(self,arg0,*args):
        val = apply(libkdecorepythonc.KPixmap_loadMode,(self.this,arg0,)+args)
        return val

    def checkColorTable(self,arg0):
        val = libkdecorepythonc.KPixmap_checkColorTable(self.this,arg0.this)
        return val

    def __repr__(self):
        return "<KPixmap instance at %s>" % self.this

class KPixmap(KPixmapPtr):
    def __init__(self,name="") :
	KPixmapPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new_KPixmap()
        self.thisown = 1

