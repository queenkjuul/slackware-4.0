import libkdecorepythonc
from qt.baseobject import *
from qt.color import *
from qt.font import *


class KRootPropPtr(BaseObjectPtr):

    def __init__(self,this,name=""):
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libkdecorepythonc.delete_KRootProp(self.this)

    def setProp(self,arg0=""):
        val = libkdecorepythonc.KRootProp_setProp(self.this,arg0)
        return val

    def readEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KRootProp_readEntry,(self.this,arg0,)+args)
        return val

    def readNumEntry(self,arg0,*args):
        val = apply(libkdecorepythonc.KRootProp_readNumEntry,(self.this,arg0,)+args)
        return val

    def readFontEntry(self,arg0,*args):
        argl = map(None,args)
        try: argl[0] = argl[0].this
        except: pass
        args = tuple(argl)
        val = apply(libkdecorepythonc.KRootProp_readFontEntry,(self.this,arg0,)+args)
        val = FontPtr(val)
        val.thisown = 1
        return val

    def readColorEntry(self,arg0,*args):
        argl = map(None,args)
        try: argl[0] = argl[0].this
        except: pass
        args = tuple(argl)
        val = apply(libkdecorepythonc.KRootProp_readColorEntry,(self.this,arg0,)+args)
        val = ColorPtr(val)
        val.thisown = 1
        return val

    def writeEntry(self,arg0,arg1):
        val = libkdecorepythonc.KRootProp_writeEntry(self.this,arg0,arg1)
        return val

    def writeIntEntry(self,arg0,arg1):
        val = libkdecorepythonc.KRootProp_writeIntEntry(self.this,arg0,arg1)
        return val

    def writeFontEntry(self,arg0,arg1):
        val = libkdecorepythonc.KRootProp_writeFontEntry(self.this,arg0,arg1.this)
        return val

    def writeColorEntry(self,arg0,arg1):
        val = libkdecorepythonc.KRootProp_writeColorEntry(self.this,arg0,arg1.this)
        return val

    def sync(self):
        val = libkdecorepythonc.KRootProp_sync(self.this)
        return val

    def __repr__(self):
        return "<KRootProp instance at %s>" % self.this

class KRootProp(KRootPropPtr):
    def __init__(self,name="") :
        KRootPropPtr.__init__(self,"NULL",name)
        self.this = libkdecorepythonc.new_KRootProp()
        self.thisown = 1
