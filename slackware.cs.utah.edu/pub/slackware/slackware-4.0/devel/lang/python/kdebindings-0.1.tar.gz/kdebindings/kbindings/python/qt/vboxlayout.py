import libqtpythonc
from object import *
from layout import *
from boxlayout import *


class VBoxLayoutPtr(BoxLayoutPtr):

    def __init__(self,this,name=""):
        BoxLayoutPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_VHBoxLayout(self.this)

    def __repr__(self):
        return "<VBoxLayout instance at %s>" % self.this

class VBoxLayout(VBoxLayoutPtr):
    def __init__(self,autoBorder=-1,name="") :
        VBoxLayoutPtr.__init__(self,"NULL",name) 
        self.this = libqtpythonc.new_VHBoxLayout(autoBorder,name)
        self.thisown = 1


def VBoxLayoutParent(parent,border=0,autoBorder=-1,name="") :
    val = VBoxLayoutPtr(libqtpythonc.new_VHBoxLayoutParent(parent.this,border,autoBorder,name),name)
    val.thisown = 1
    return val
