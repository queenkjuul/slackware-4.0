import libqtpythonc
from widget import *


class TabBarPtr(WidgetPtr):

    RoundedAbove = libqtpythonc.TabBar_RoundedAbove
    RoundedBelow = libqtpythonc.TabBar_RoundedBelow
    TriangularAbove = libqtpythonc.TabBar_TriangularAbove
    TriangularBelow = libqtpythonc.TabBar_TriangularBelow

    def __init__(self,this,name=""):
        WidgetPtr.__init__(self,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_TabBar(self.this)

    def shape(self):
        val = libqtpythonc.TabBar_shape(self.this)
        return val

    def setShape(self,arg0):
        val = libqtpythonc.TabBar_setShape(self.this,arg0)
        return val

    def addTab(self,arg0):
        val = libqtpythonc.TabBar__addTab(self.this,arg0)
        return val

    def setTabEnabled(self,arg0,arg1):
        val = libqtpythonc.TabBar_setTabEnabled(self.this,arg0,arg1)
        return val

    def isTabEnabled(self,arg0):
        val = libqtpythonc.TabBar_isTabEnabled(self.this,arg0)
        return val

    def currentTab(self):
        val = libqtpythonc.TabBar_currentTab(self.this)
        return val

    def keyboardFocusTab(self):
        val = libqtpythonc.TabBar_keyboardFocusTab(self.this)
        return val

    def tab(self,arg0):
        val = libqtpythonc.TabBar__tab(self.this,arg0)
        return val

    def setCurrentTab(self,arg0):
        val = libqtpythonc.TabBar_setCurrentTab(self.this,arg0)
        return val

    def __repr__(self):
        return "<TabBar instance at %s>" % self.this

class TabBar(TabBarPtr):
    def __init__(self,parent="",name=""):
	TabBarPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_TabBar("NULL", name)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_TabBar(parent.this, name)
	    self.thisown = 0	    
