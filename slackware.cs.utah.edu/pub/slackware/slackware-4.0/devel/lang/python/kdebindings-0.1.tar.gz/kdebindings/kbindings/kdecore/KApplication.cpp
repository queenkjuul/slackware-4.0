#include "KApplication.h"
#include "KApplication.moc"
