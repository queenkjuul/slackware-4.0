from widget import *
import libqtpythonc


class ProgressDialogPtr(WidgetPtr):

    def __init__(self,this,name=""):
	WidgetPtr.__init__(self,this,name)
        self.this = this
        self.thisown = 0

    def __del__(self):
        if self.thisown == 1 :
            libqtpythonc.delete_ProgressDialog(self.this)

    def setLabel(self,label):
        libqtpythonc.ProgressDialog_setLabel(self.this,label.this)
        label.thisown = 0

    def setCancelButton(self,button):
        libqtpythonc.ProgressDialog_setCancelButton(self.this,button.this)
 	button.thisown = 0

    def setBar(self,bar):
        libqtpythonc.ProgressDialog_setBar(self.this,bar.this)
        bar.thisown = 0

    def wasCancelled(self):
        return libqtpythonc.ProgressDialog_wasCancelled(self.this)

    def totalSteps(self):
        return libqtpythonc.ProgressDialog_totalSteps(self.this)

    def progress(self):
        return libqtpythonc.ProgressDialog_progress(self.this)

    def cancel(self):
        libqtpythonc.ProgressDialog_cancel(self.this)

    def reset(self):
        libqtpythonc.ProgressDialog_reset(self.this)

    def setTotalSteps(self,steps):
        libqtpythonc.ProgressDialog_setTotalSteps(self.this,steps)

    def setProgress(self,progress):
        libqtpythonc.ProgressDialog_setProgress(self.this,progress)

    def setLabelText(self,text):
        libqtpythonc.ProgressDialog_setLabelText(self.this,text)

    def setCancelButtonText(self,text):
        libqtpythonc.ProgressDialog_setCancelButtonText(self.this,text)

    def __repr__(self):
        return "<ProgressDialog instance at %s>" % self.this


class ProgressDialog(ProgressDialogPtr):
    def __init__(self,label,cancel,steps,parent="",name="",modal=0,flags=0):
	ProgressDialogPtr.__init__(self,"NULL",name)
	if not parent:
            self.this = libqtpythonc.new_ProgressDialog(label,cancel,steps,"NULL",name,modal,flags)
            self.thisown = 1
        else:
            self.this = libqtpythonc.new_ProgressDialog(label,cancel,steps,parent.this,name,modal,flags)
	    self.thisown = 0	    

