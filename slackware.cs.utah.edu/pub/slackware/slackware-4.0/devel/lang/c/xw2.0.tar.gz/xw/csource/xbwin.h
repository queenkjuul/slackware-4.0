

/* ================ XBWIN.H ============================================== */



#define XbWDMf_CommandOk 0
#define XbWDMf_CommandErr 1
#define XbWDMf_EXETaskStart 1
#define XbWDSy_StarteManager 1
#define XbWDSy_DoNotStartManager 0

#define XbWDDb_DbIPtr long              /* Offset relativ zum Projektbeginn       */
#define XbWDDb_DbITyp unsigned char     /* Typ eines Eintrages in der XbWDDb_Dbk */
#define XbWDDb_Handle XbWDDb_DbIPtr
#define XbWDDb_Get 0
#define XbWDDb_Put 1
#define XbWDDb_RecursiveAccess 1        /* Standard */
#define XbWDDb_DirectAccess    0        /* Nur fuer Sonderfaelle */

#define XbWDOb_DrawRedBox 3

#define XbWDGr_Write 0
#define XbWDGr_XOR   1
#define XbWDGr_OR    2
#define XbWDGr_AND   3


#define XbWDWd_MaxWdw 100

#define XbWDMf_NoPara 50
#define XbWDMf_StrToL 51

#define XbWDMf_MaxPar 100                /* Maximale Zahl Befehlsparameter */

#define XbWDMf_IntPar 0x10
#define XbWDMf_StrPar 0x20
#define XbWDMf_VPPar  0x30
#define XbWDMf_VIPar  0x40
#define XbWDMf_VLPar  0x50
#define XbWDMf_NULPar 0x60
#define XbWDMf_AnzPar 0x70
#define XbWDMf_DblPar 0x80

#define XbWDMf_MaxCmd 79

#define XbWDMf_BfStrL 100

#define XbWDTb_MxVwPrt 30

#define XbWDMx_OpnErr       10001
#define XbWDMx_EofGrp       10002
#define XbWDMx_RIntEg       10003
#define XbWDMx_RDblEg       10004
#define XbWDMx_RStrEg       10005
#define XbWDMx_RIFnoI       10006
#define XbWDMx_RDFnoD       10007
#define XbWDMx_RSFnoS       10008
#define XbWDMx_EndOfF       10009
#define XbWDMx_DGrpNF       10010
#define XbWDMx_MissRP       10011
#define XbWDMx_NoApnd       10012
#define XbWDMx_GrpNtF       10013

#define XbWDMx_RDok  0
#define XbWDMx_RFok  0
#define XbWDMx_WFok  0
#define XbWDMx_RGok  0

#define XbWDMx_ReadMF   0
#define XbWDMx_WriteMF  1
#define XbWDMx_AppendMF 2


typedef struct {
  XbWDDb_DbITyp tp;     /* Typ des items                    */
  } XbWDDb_DbIVar;


#define XbWDIf_InitXMS(task) short huge XbWDIf_StrtApp(short argc, char *argv[]){\
  _ovrbuffer = 0x1200;\
  _OvrInitExt(0,350000L);\
  return(task(argc,argv));\
  };\

#define XbWDIf_InitStd(task)\
  short huge XbWDIf_StrtApp(short argc, char *argv[]){\
  return( task(argc,argv));\
  };\

/* ======================================================================= */

typedef
  unsigned char boolean;

typedef
  unsigned char byte;

typedef struct {
  char  huge *nm;
  XbWDDb_DbIPtr *obj;                /* Zeiger auf das erste Objekt dieses Windows*/
  short huge *tp;             /* Typ                                       */
  short huge *layer;          /* Lage auf dem schirm, z- Ebene             */
  short huge *nx;
  short huge *ny;             /* Nullpunkt auf dem schirm                  */
  short huge *sx;
  short huge *sy;             /* Aktuelle Schirmgr"o"se einschl. Rand      */
  short huge *wov;            /* wenn von anderem Fenster "uberschrieben   */
  short huge *icn;            /* wenn als icon dargestellt                 */
  short huge *bkc;            /* Untergrundfarbe                           */
  short huge *txc;            /* Farbe des Textes                          */
  short huge *dfc;            /* helle Farbe des Rahmens                   */
  short huge *bfc;            /* dunkle Farbe des Rahmens                  */
  short huge *wfx;            /* Solange Window bearb.wird,nicht verlassen!*/
  short huge *wfe;            /* Wenn editiert, wird WaitForMenuExit 1  */
  short huge *bd;             /* Background Display                        */
  } XbWDDb_DbIWdw;

typedef struct {
  char  huge *onm;
  char  huge *odt;            /* Objekt-Display-Typ                        */
  char  huge *oet;            /* Objekt-Edit-Typ                           */
  short huge *XA;
  short huge *YA;
  short huge *XB;
  short huge *YB;             /* Lage auf dem Window                       */
  short huge *bkc;            /* Untergrundfarbe                           */
  short huge *txc;            /* Farbe des Textes                          */
  short huge *dfc;            /* helle Farbe des Rahmens                   */
  short huge *bfc;            /* dunkle Farbe des Rahmens                  */
  short huge *dst;            /* Display-Status                            */
  short huge *est;            /* Edit-Status                               */
  short huge *dwd;            /* Draw Window nach edit                     */
  char  huge *wdw;            /* Zugeordnetes Window                       */
  XbWDDb_DbIVar huge *chn;           /* Zeiger auf den Rest des Objektes          */
  XbWDDb_DbIPtr huge *nxt;           /* Inhalt des Zeigers auf n�chstes Objekt    */
  } XbWDDb_DbIObj;

typedef struct {char *typ; short anz;  void *data; char *name; } XbWDMx_GrpDscr;

typedef struct { short huge *Grp[40];} XbWDIf_GlobDsc;


/* ======================================================================= */

short huge XbWPSy_EXETaskStartHook(   char *TaskName, XbWDDb_DbIWdw huge *TW,XbWDDb_DbIObj huge *TO);
short huge XbWPSy_DisplayObjectHook(char *ObjectTyp,XbWDDb_DbIWdw huge *TW,XbWDDb_DbIObj huge *TO);
short huge XbWPSy_EditObjectHook(char *ObjectTyp,XbWDDb_DbIWdw huge *TW,
          XbWDDb_DbIObj huge *TO, short *todisp, short edit,
          short ObjMausXPos, short ObjMausYPos);
short huge XbWPSy_MetaCommandHook(   char *Command,  XbWDDb_DbIWdw huge *TW, void huge *(*para)[], short (*t)[]);
short huge XbWPSy_SystemManagerHook(XbWDDb_DbIWdw huge *TW);

/* ======================================================================= */

extern XbWDIf_GlobDsc      XbWVIf_GlbDsc;
extern char                XbWVSy_SysPath[60];
extern char                XbWVSy_AppPath[60];
extern char                XbWVSy_PrjPath[60];
extern short               XbWVWd_AClos;
extern short               XbWVWd_RedrawON;

extern XbWDDb_DbIWdw       XbWVWd_W;    /* Aktives Display-Window */

extern short               XbWVWd_OldMsg;
extern short               XbWVGr_Black;
extern short               XbWVGr_Blue ;
extern short               XbWVGr_Green;
extern short               XbWVGr_Cyan ;
extern short               XbWVGr_Red  ;
extern short               XbWVGr_Magenta   ;
extern short               XbWVGr_Brown     ;
extern short               XbWVGr_LGray ;
extern short               XbWVGr_DGray  ;
extern short               XbWVGr_LBlue ;
extern short               XbWVGr_LGreen;
extern short               XbWVGr_LCyan ;
extern short               XbWVGr_LRed  ;
extern short               XbWVGr_LMagenta;
extern short               XbWVGr_Yellow;
extern short               XbWVGr_White ;

extern  boolean            XbWVMs_Bewegt;
extern  boolean            XbWVMs_Button;
extern  boolean            XbWVMs_LButt;
extern  boolean            XbWVMs_RButt;
extern  boolean            XbWVMs_MButt;

extern  short              XbWVMs_XPos;
extern  short              XbWVMs_YPos;
extern  short              XbWVMs_CX;
extern  short              XbWVMs_CY;
extern  boolean            XbWVMs_CSet;

extern short               XbWVOb_MovOK;

extern short               XbWVMf_C;
extern char               *XbWVMf_com[XbWDMf_MaxCmd];

extern char               *XbWVWd_Name[XbWDWd_MaxWdw+1];
extern short               XbWVWd_MaxReg;
extern short               XbWVWd_RedrawON;
extern XbWDDb_DbIWdw       XbWVWd_W;           /* Aktives Display-Window */
extern short               XbWVWd_AClos;
extern short               XbWVIDEO_XA;
extern short               XbWVIDEO_XB;
extern short               XbWVIDEO_YA;
extern short               XbWVIDEO_YB;

short huge                 XbWDIf_StrtApp(short argc,char *argv[]);


short huge XbWFDb_CloseSys(void);
void huge  XbWFEd_GetOStr(XbWDDb_DbIWdw huge *WI,char *string,short MaxLen,
                          short XA,short YA,short XB,short YB,
                          char *defaultmsg,short cpo);
void huge  XbWFGr_CurOFF(void);
void huge  XbWFGr_CurON(void);
void huge  XbWFGr_MaxPort(void);
short huge XbWFGr_MaxX(void);
short huge XbWFGr_MaxY(void);
void huge  XbWFGr_MinPort(short xxa,short yya,short xxb,short yyb);
void huge  XbWFGr_PopPort(void);
void huge  XbWFGr_PushPort(void);
void huge  XbWFGr_RedPort(short xa,short ya,short xb,short yb);
void huge  XbWFGr_ResPort(void);
void huge  XbWFGr_SetPort(void);
short huge XbWFGr_THeight(void);
short huge XbWFGr_TWidth(char *sstr);
void huge  XbWFMf_ReadMakro(char *makro);
void huge  XbWFMf_ReadMF(char *filename);
short huge XbWFMf_StrtHookCmd(void huge*(*p)[]);
void huge  XbWFMx_DbgON(void);
void huge  XbWFMx_DpError(char *text);
void huge  XbWFMx_DpMessage(char *text);
unsigned short huge XbWFMx_DpPercent(double percent,double maximum,char *name,char *text);
void huge  XbWFMx_DpWarning(char *text);
void huge  XbWFMx_EndSet(void);
short huge XbWFMx_GetDbl(double *variable);
short huge XbWFMx_GetInt(short *variable);
short huge XbWFMx_GetStr(char *variable);
void huge  XbWFMx_PutDbl(double variable,char *com);
void huge  XbWFMx_PutInt(short variable,char *com);
void huge  XbWFMx_PutStr(char *variable,char *com);
short huge XbWFMx_RdSet(char *filename,char *datensatzname);
void huge  XbWFMx_ResGrMode(void);
short huge XbWFMx_RWGrp(char *rgr_nm,char* rgr_rwm,short rw_smode,short rw_snr,char *new_filnm);
short huge XbWFMx_WrSet(char *filename,char *datensatzname, short mode);
void huge  XbWFOb_dpO(XbWDDb_DbIWdw huge*WI,XbWDDb_DbIObj huge*NotDispObj);
short huge XbWFOb_EdDpObj(char *obn,short mode);
short huge XbWFOb_Edit(XbWDDb_DbIObj huge*MOB);
short huge XbWFOb_EditAndDisp(char *obn,short mode);
short huge XbWFOb_ebO(XbWDDb_DbIObj huge*MOB);
short huge XbWFOb_epO(char *name);
short huge XbWFOb_eqO(XbWDDb_DbIObj huge*MOB);
char huge *XbWFOb_GetPar(XbWDDb_DbIWdw huge*WI,XbWDDb_DbIObj huge*TO, char *sname,short mode);
void huge  XbWFOb_GiveInfo(XbWDDb_DbIWdw huge*WI,short mausxa,short mausya,short smode);
void huge  XbWFOb_MovToPos(XbWDDb_DbIWdw huge*WI,short mausxa,short mausya);
void huge  XbWFOb_SetViewPort(XbWDDb_DbIWdw huge*WI,XbWDDb_DbIObj huge*TO);
short huge XbWFOb_SubMovWdw(char *onm,char *wnm);
void huge  XbWFOj_DiEdContents(XbWDDb_DbIWdw huge*WI,XbWDDb_DbIObj huge*TOB,short edit);
void huge  XbWFOj_DpArrow(XbWDDb_DbIObj huge*TO,char *arrstr);
void huge XbWFOj_DpBit(XbWDDb_DbIObj huge*TO);
void huge XbWFOj_DpBool(XbWDDb_DbIObj huge*TO);
void huge XbWFOj_DpColButt(XbWDDb_DbIObj huge*TO, short stat);
void huge XbWFOj_DpEllipse(XbWDDb_DbIObj huge*TO);
short huge XbWFOj_DpInt(XbWDDb_DbIObj huge*TOB);
void huge XbWFOj_DpLight(XbWDDb_DbIObj huge*TO);
void huge XbWFOj_DpSlider(XbWDDb_DbIObj huge*TO, short w_mode);
void huge XbWFOj_DpSwt(XbWDDb_DbIObj huge*TO);
short huge XbWFOj_Dp_A(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_BKS(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_G(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_M(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_N(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_P(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_R(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_S(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_T(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_X(XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Dp_Z(XbWDDb_DbIObj huge*TOB);
void huge  XbWFOj_EdInt(XbWDDb_DbIObj huge*TO);
void huge  XbWFOj_EdSlider(XbWDDb_DbIObj huge*TO);
void huge  XbWFOj_EdStr(XbWDDb_DbIObj huge*TO);
void huge  XbWFOj_EdSwt(XbWDDb_DbIObj huge*TO);
short huge XbWFOj_Ed_A(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_B(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_C(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_F(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_G(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_HID(short edit, XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_L(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_M(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_N(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_R(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_S(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_T(XbWDDb_DbIWdw huge*WI,short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_U(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_V(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_X(short edit,XbWDDb_DbIObj huge*TOB);
short huge XbWFOj_Ed_Z(short edit,XbWDDb_DbIObj huge*TOB);
double huge XbWFOj_GetNum(XbWDDb_DbIObj huge*TO);
double huge XbWFOj_PutNum(XbWDDb_DbIObj huge*TO);
void huge  XbWFOj_SpawnTsk(XbWDDb_DbIWdw huge*TW,XbWDDb_DbIObj huge*TO,unsigned char styp,
	 unsigned char write_tbl,unsigned char ttyp,unsigned char no_params);
void huge XbWFSy_SysStop(void);
void huge XbWFTb_AClosOFF(void);
void huge XbWFTb_AClosON(void);
void huge XbWFTb_Click(void);
void huge XbWFTb_ClrScr(void);
short huge XbWFTb_CmpBox(short oxa,short oya,short oxb,short oyb,
                         short wxa,short wya,short wxb,short wyb);
short huge XbWFTb_CmpStr(char *stra, char *strb	);
short huge XbWFTb_ColCon(short dunkelfarbe);
void huge XbWFTb_CorrSiz(short *xa,short *ya,short *xb,short *yb,
                         short wxa,short wya,short wxb,short wyb);
void huge XbWFTb_DbgMta(void);
void huge XbWFTb_Error(char*msg);
void huge XbWFTb_HBeep(void);
boolean huge XbWFTb_InBox(short sxa,short sya,short xa,short ya,short xb,short yb);
void huge XbWFTb_LBeep(void);
void huge XbWFTb_Message(char *msg);
void huge XbWFTb_Outl(short xa, short *ya, char *txt, short col);
char huge *XbWFTb_PckTxt(char *str);
void huge XbWFTb_RedrawOFF(void);
void huge XbWFTb_RedrawON(void);
short huge XbWFTb_SubPopUpBox(char msg1[50],char msg2[50],
                              char text1[50],char text2[50],char text3[50]);
void huge XbWSOS_Delay(short len);
void huge XbWFTb_Wait(short zeit);
void huge  XbWFWd_BackGr(void);
void huge XbWFWd_ChkAct(void);
void huge XbWFWd_ChkDisp(void);
void huge XbWFWd_Draw(void);
void huge XbWFWd_DrawAll(void);
void huge XbWFWd_DrawP(void);
void huge XbWFWd_Erase(XbWDDb_DbIWdw huge*WI);
void huge XbWFWd_EraWdw(void);
short huge XbWFWd_Exists(char *refname);
short huge XbWFWd_GetList(void);
short huge XbWFWd_GetPara(short nr, XbWDDb_DbIWdw huge*TW);
short huge XbWFWd_Hide(XbWDDb_DbIWdw *wtest,XbWDDb_DbIWdw *wb);
void huge XbWFWd_IconAll(void);
void huge XbWFWd_Iconize(void);
short huge XbWFWd_InInner(void);
void huge XbWFWd_Make(XbWDDb_DbIWdw huge*WI);
short huge XbWFWd_NotInWdw(void);
void huge XbWFWd_OManager(short popup, char *wname);
short huge XbWFWd_OvrLap(XbWDDb_DbIWdw *wtest, XbWDDb_DbIWdw *wb);
void huge XbWFWd_Rebuild(void);
void huge XbWFWd_ReDisp(void);
void huge XbWFWd_Refresh(void);
void huge XbWFWd_RestImage(XbWDDb_DbIWdw huge*WI);
void huge XbWFWd_SaveImage(XbWDDb_DbIWdw huge*WI);
void huge XbWFWd_SaveRestore(XbWDDb_DbIWdw huge*WI, short read);
void huge XbWFWd_SlctOther(void);
void huge XbWFWd_SwitchTo(char *nm, short savescreen);
void huge XbWFWd_WManager(void);
void huge XbWSGr_BitBlit(void huge*dest,short x,short y,
                         void huge*source,short x1,short y1,short x2,short y2,short oper);
void huge XbWSGr_CCBox(short xa,short ya,short xb,short yb,char huge*msg,
                       short fillcol,short textcol,short framecol);
void huge  XbWSGr_Close(void);
void huge XbWSGr_DspIcon(XbWDDb_DbIObj huge*TO);
void huge XbWSGr_Ell(short xa,short ya,short stang,short endang,short ra,short rb,short farbe);
void huge XbWSGr_GetClip(void huge*theport);
void huge XbWSGr_GetImag(short a,short b,short c,short d,void huge*e);
void huge XbWSGr_GotoXY(short x, short y);
unsigned huge XbWSGr_GtImSiz(short a, short b, short c, short d);
short huge XbWSGr_GtPhysX(void);
short huge XbWSGr_GtPhysY(void);
void huge XbWSGr_HLin(short xa,short xb,short ya,byte color);
void huge XbWSGr_Line(short xa,short ya,short xb,short yb,byte color);
void huge XbWSGr_PutImag(short a, short b, void huge*c, short d);
void huge XbWSGr_RBBox(  short xa,short ya,  short xb,short yb,char huge*msg,
                         short fillcol,short textcol, short framecol);
void huge XbWSGr_ResImag(void huge*where,short x1,short y1,short x2,short y2,short oper);
void huge  XbWSGr_ResMode(void);
void huge *XbWSGr_SavImag(short x1,short y1,short x2,short y2);
void huge XbWSGr_SetClip(short xa,short ya,short xb,short yb);
short huge XbWSGr_SetFontLib(void);
void huge XbWSGr_TLBox(short xa,short ya,short xb,short yb,char huge*msg,
          short fillcol,short textcol,short framecol);
void huge XbWSGr_TxtDraw(short x,short y,char *txt,short tc,short bc);
void huge XbWSGr_VLin(short xa,short ya,short yb,byte color);
void huge XbWSMs_ChkMot(void);
void huge XbWSMs_DFramOFF(short xxa,short yya,short xxb,short yyb);
void huge XbWSMs_DFramON(short xa,short ya,short xb,short yb);
void huge XbWSMs_DrInit(void);
void huge XbWSMs_DrReset(void);
void huge XbWSMs_FramOFF(short xa,short ya,short xb,short yb);
void huge XbWSMs_FramON(short xxa,short yya,short xxb,short yyb);
void huge XbWSMs_GetKey(unsigned char huge*c1, unsigned char huge*c2);
void huge XbWSMs_Hd(void);
void huge XbWSMs_OFF(void);
boolean huge XbWSMs_Init(void);
boolean huge XbWSMs_IsAKey(int wait);
void huge XbWSMs_OFF(void);
void huge XbWSMs_ON(void);
void huge XbWSMs_ResPos(void);
void huge XbWSMs_SetSens(void);
void huge XbWSMs_SetSped(void);
void huge XbWSMs_Sh(void);
void huge XbWSMs_Stat(void);
void huge XbWSMs_Stop(void);
void huge XbWSMs_WaitKey(void);
void huge XbWSMs_Warp(short x,short y);
void huge XbWSMs_WButtDn(void);
void huge XbWSMs_WButtUp(void);
void huge XbWSOS_Delay(short len);
void huge XbWSOS_NoSound(void);
void huge XbWSOS_Sound(short freq);
void huge XbWSOS_SpwnShel(void);
void huge XbWSPu_Alarm(char *msg);
void huge XbWSPu_Error(char text[255]);
void huge *XbWSSy_AlocMem(unsigned long a,unsigned long b);
void huge XbWSSy_FatalEr(char text[255]);
void huge XbWSSy_FreeMem(void huge*a);
void huge    XbWSSy_SysHalt(void);
time_t huge  XbWSSy_TimeSec(void);
void huge    XbWSWd_Move(void);
short huge   XbWSSy_ResetWM(short argc,char *argv[]);
short huge   XbWApp_StartupApplication(short argc,char *argv[]);


/* =================================================================== */

short huge XbWFMx_ReadMFA(char *grpnm, char *name);
short huge XbWFMx_WriteMFA(char *grpnm, char *name);
short huge XbWFMx_AppendMFA(char *grpnm, char *name);
short huge XbWFMx_ReadMFD(char *grpnm);
short huge XbWFMx_WriteMFD(char *grpnm);
short huge XbWFMx_AppendMFD(char *grpnm);
short huge XbWFMx_ReadMFX(char *grpnm);
short huge XbWFMx_WriteMFX(char *grpnm);
short huge XbWFMx_AppendMFX(char *grpnm);

XbWDDb_Handle huge XbWFDb_GetHandle(
    char *lname, char *gname, char *ename, short recursive);

double huge XbWFDb_SetGetNumber(
    XbWDDb_Handle element, double value, short oper);

char huge *XbWFDb_SetGetString(
    XbWDDb_Handle element, char huge *qstr, short oper);


/* ================= Ende von XBWIN.H ================================ */


