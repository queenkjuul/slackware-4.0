#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#ifdef XbW_SYSDEF_X11_VERSION
#include <ctype.h>
#endif

 
char itoastr[12];
/*{{{  itoa(*/
char *itoa(int nr, char *target, int radix){
  sprintf(itoastr,"%d",(int)nr);
  if (target != NULL) {
    strcpy(target,itoastr);
    };
  return(itoastr);
  };
/*}}}  */

/*{{{  strupr(*/
char *strupr(char *sstr){
  int ii;
  ii = 0;
  while (sstr[ii] !=0){
    sstr[ii] &= toupper(sstr[ii]);
    ii++;
    };
  return(sstr);
  };
/*}}}  */
