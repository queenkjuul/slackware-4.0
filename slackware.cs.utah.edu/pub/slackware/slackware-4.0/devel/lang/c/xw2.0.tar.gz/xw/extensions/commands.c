 
/* HIER alle C-SOURCEN einbinden */
#include "/xw/extensions/anzeige.xwx"
#include "/xw/extensions/cursor.xwx"
#include "/xw/extensions/diagramm.xwx"
#include "/xw/extensions/zaehler.xwx"

FuncTable FunctionTable[]={
  /* Hier die selbstdefinierten Makrokommandos eintragen; alle beginnen mit "@" */
  /* NAME               AUFRUF */
  {"@Anzeige",          XbW_Extension_TestAusdruck},
  {"@CursorInit",       XbW_Extension_InitCursor},
  {"@DiagrammInit",     XbW_Extension_InitDiag},
  {"@ZaehlerInit",      XbW_Extension_ZaehlerInit},
  {"@ZaehlerAusdruck",  XbW_Extension_ZaehlerAusdruck},
 
  {"",              NULL}  /* ENDE DER LISTE */
  };
 
