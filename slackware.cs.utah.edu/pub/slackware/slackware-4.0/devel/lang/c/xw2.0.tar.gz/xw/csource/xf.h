/*{{{  XbWFDb_Add( [x4.c;0353]          ****/
void
        *XbWFDb_Add(
        long size
        );
/*}}}  */
/*{{{  XbWFDb_AppBg( [x4.c;1089]        ****/
int
        XbWFDb_AppBg(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppCSt( [x4.c;0491]       ****/
int
        XbWFDb_AppCSt(
        void
        *(*p)[],
         int (*t)[]
 
        );
/*}}}  */
/*{{{  XbWFDb_AppChn( [x4.c;0910]       ****/
int
        XbWFDb_AppChn(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppCmd( [x4.c;0423]       ****/
int
        XbWFDb_AppCmd(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppDbl( [x4.c;0532]       ****/
int
        XbWFDb_AppDbl(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppFPtr( [x4.c;0743]      ****/
int
        XbWFDb_AppFPtr(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppFloat( [x4.c;0979]     ****/
int
        XbWFDb_AppFloat(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppGPtr( [x4.c;0595]      ****/
int  XbWFDb_AppGPtr(
        void
        *(*p)[] ,
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppGrp( [x4.c;0720]       ****/
int
        XbWFDb_AppGrp(
        char *liste,
         char *name
        );
/*}}}  */
/*{{{  XbWFDb_AppIPtr( [x4.c;0572]         ****/
int
        XbWFDb_AppIPtr(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppInt( [x4.c;0515]       ****/
int
        XbWFDb_AppInt(
        void
        *(*p)[] ,
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppLight( [x4.c;1031]     ****/
int
        XbWFDb_AppLight(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppNPtr( [x4.c;0549]      ****/
int
        XbWFDb_AppNPtr(
        void
        *(*p)[],
         int (*t)[]
 
        );
/*}}}  */
/*{{{  XbWFDb_AppObj( [x4.c;0751]       ****/
int
        XbWFDb_AppObj(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_AppStr( [x4.c;0452]       ****/
int
        XbWFDb_AppStr(
        void
        *(*p)[],
         int (*t)[]
 
        );
/*}}}  */
/*{{{  XbWFDb_AppTsk( [x4.c;0955]       ****/
int
        XbWFDb_AppTsk(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_CDbIToPtr( [x3.c;1989]          ***    Macht aus einer Datenbank-Pos. einen Pointer*/
XbWDDb_DbIVar
        *XbWFDb_CDbIToPtr(
        XbWDDb_DbIPtr bb,
        void
        *AP
        );
/*}}}  */
/*{{{  XbWFDb_CPtrToStr( [x4.c;1133]        ****/
char
        *XbWFDb_CPtrToStr(
        XbWDDb_DbIVar
        *TV,
         XbWDDb_DbIVar
        *IP
        );
/*}}}  */
/*{{{  XbWFDb_CloseSys( [x4.c;1967]     ***    Datenbank loeschen*/
int  XbWFDb_CloseSys(void);
/*}}}  */
/*{{{  XbWFDb_CmpStr( [x4.c;0396]       ****/
int
        XbWFDb_CmpStr(
        XbWDDb_DbIVar
        *TS,
        char *snam
        );
/*}}}  */
/*{{{  XbWFDb_CreaSys( [x4.c;1983]      ***    Speicher reservieren fuer Datenbank*/
int
        XbWFDb_CreaSys(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFDb_DbIToStr( [x4.c;1181]     ****/
char
        *XbWFDb_DbIToStr(
        XbWDDb_DbIPtr it,
         XbWDDb_DbIVar
        *IP
        );
/*}}}  */
/*{{{  XbWFDb_DbgSys( [x4.c;1503]       ****/
int
        XbWFDb_DbgSys(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFDb_DbgVar( [x4.c;0028]       ***    Eine Datenbank-Variable debuggen*/
void
        XbWFDb_DbgVar(
        XbWDDb_DbIVar
        *TV,
        FILE *fp
        );
/*}}}  */
/*{{{  XbWFDb_FindGPtr( [x4.c;0641]     ****/
XbWDDb_DbIVar
        *XbWFDb_FindGPtr(
        XbWDDb_DbIVar
        *start,
         XbWDDb_DbIVar
        *IP
        );
/*}}}  */
/*{{{  XbWFDb_FindGrp( [x4.c;0656]      ****/
XbWDDb_DbIVar
        *XbWFDb_FindGrp(
        char *liste,
         char *name
        );
/*}}}  */
/*{{{  XbWFDb_FindNptr( [x4.c;0073]     ***    Unterroutinen zur Datenbank-Verwaltung*/
XbWDDb_DbIVar
        *XbWFDb_FindNptr(
        XbWDDb_DbIVar
        *start,
        char *name
        );
/*}}}  */
/*{{{  XbWFDb_ForWd( [x3.c;1995]        ***    Ein Datenbank-Element vorwaerts*/
void
        XbWFDb_ForWd(
        XbWDDb_DbIVar
        **AP,
        XbWDDb_DbIVar
        *IP
        );
/*}}}  */
/*{{{  XbWFDb_Fore( [x3.c;2006]         ***    Speziell; im Prinzip wie ForWd*/
void
        XbWFDb_Fore(
        XbWDDb_DbIVar
        **AP,
        XbWDDb_DbIVar
        *IP
        );
/*}}}  */
/*{{{  XbWFDb_GetDbI( [x4.c;1191]       ****/
char
        *XbWFDb_GetDbI(
        char *lname,
         char *gname,
         char *nname
        );
/*}}}  */
/*{{{  XbWFDb_GetHandle( [x5.c;1294]       ****/
XbWDDb_Handle
        XbWFDb_GetHandle(
 
    char *lname,
         char *gname,
         char *ename,
         int recursive);
/*}}}  */
/*{{{  XbWFDb_GetInf( [x4.c;1200]       ****/
int
            XbWFDb_GetInf(
        XbWDDb_DbIVar
        *start,
         int vnr,
 
                       char *vname,
         int *typ,
         char **inh,
         int *ale,
 
                       int recursiv);
/*}}}  */
/*{{{  XbWFDb_GetInh( [x4.c;0118]       ****/
char
        *XbWFDb_GetInh(
        XbWDDb_DbIVar
        *start,
         int tp
        );
/*}}}  */
/*{{{  XbWFDb_GetNam( [x4.c;0374]       ****/
char
        *XbWFDb_GetNam(
        XbWDDb_DbIVar
        *TV
        );
/*}}}  */
/*{{{  XbWFDb_GetNum( [x4.c;0209]       ****/
double
        XbWFDb_GetNum(
        XbWDDb_DbIVar
        *start,
         char *name,
         int recursiv
        );
/*}}}  */
/*{{{  XbWFDb_GetSiz( [x4.c;0360]       ****/
long
        XbWFDb_GetSiz(
        XbWDDb_DbIVar
        *TV
        );
/*}}}  */
/*{{{  XbWFDb_GetStr( [x4.c;0411]       ****/
char
        *XbWFDb_GetStr(
        XbWDDb_DbIStr
        *TS
        );
/*}}}  */
/*{{{  XbWFDb_GtEOT( [x4.c;0348]        ****/
void  *XbWFDb_GtEOT(void);
/*}}}  */
/*{{{  XbWFDb_GtPrj( [x4.c;0605]        ****/
XbWDDb_DbIVar
        *XbWFDb_GtPrj(
        char *name
        );
/*}}}  */
/*{{{  XbWFDb_LinkDbI( [x4.c;1253]      ****/
int
        XbWFDb_LinkDbI(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFDb_MarkPrj( [x4.c;1316]      ****/
int
        XbWFDb_MarkPrj(
        void
        *(*p)[],
        int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_MarlGrp( [x4.c;1440]      ****/
int
        XbWFDb_MarlGrp(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFDb_NewGrp( [x4.c;1014]       ****/
int
        XbWFDb_NewGrp(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_NextGrp( [x4.c;0096]      ****/
XbWDDb_DbIVar
        *XbWFDb_NextGrp(
        XbWDDb_DbIVar
        *start,
        char *name
        );
/*}}}  */
/*{{{  XbWFDb_OutLine( [x4.c;1498]      ****/
void
        XbWFDb_OutLine(
        FILE *fp
        ) ;
/*}}}  */
/*{{{  XbWFDb_PrDbl( [x3.c;2193]        ***    Double-Element debuggen*/
void
        XbWFDb_PrDbl(
        FILE *fp,
         char *name,
         long adresse,
         long groesse,
         XbWDDb_DbIVar
        *TV
        );
/*}}}  */
/*{{{  XbWFDb_PrInt( [x3.c;2017]        ***    Integer-Element debuggen*/
void
        XbWFDb_PrInt(
        FILE *fp,
         char *name,
         long adresse,
         long groesse,
         int inhalt
        );
/*}}}  */
/*{{{  XbWFDb_PrPtr( [x3.c;2246]        ***    Pointer-Element debuggen*/
void
        XbWFDb_PrPtr(
        FILE *fp,
         char *name,
         long adresse,
         long groesse,
         XbWDDb_DbIVar
        *TV
        );
/*}}}  */
/*{{{  XbWFDb_PrStr( [x3.c;2335]        ***    String-Element debuggen*/
void
        XbWFDb_PrStr(
        FILE *fp,
         char *name,
         long adresse,
         long groesse,
         XbWDDb_DbIVar
        *TV
        );
/*}}}  */
/*{{{  XbWFDb_PrjName( [x4.c;1288]      ****/
int
        XbWFDb_PrjName(
        void
        *(*p)[],
        int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_PutNum( [x4.c;0258]       ****/
char
        *XbWFDb_PutNum(
        XbWDDb_DbIVar
        *start,
         char *name,
         int recursiv,
         double zz
        );
/*}}}  */
/*{{{  XbWFDb_PutStr( [x4.c;0306]       ****/
int
        XbWFDb_PutStr(
        XbWDDb_DbIVar
        *start,
         char *name,
         int recursiv,
         char *sstr
        );
/*}}}  */
/*{{{  XbWFDb_RdTable( [x4.c;1822]      ***    Datenbank binaer lesen*/
int
        XbWFDb_RdTable(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_SetGetNumber( [x5.c;1325]       ****/
double
        XbWFDb_SetGetNumber(
 
    XbWDDb_Handle element,
         double value,
         int oper);
/*}}}  */
/*{{{  XbWFDb_SetGetString( [x5.c;1342]       ****/
char
        *XbWFDb_SetGetString(
 
    XbWDDb_Handle element,
         char
        *qstr,
         int oper);
/*}}}  */
/*{{{  XbWFDb_SetPrj( [x4.c;1351]      ****/
int
        XbWFDb_SetPrj(
        char *prj_name
        );
/*}}}  */
/*{{{  XbWFDb_SetProject( [x4.c;1376]      ****/
int
        XbWFDb_SetProject(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFDb_StorGrpn( [x5.c;0943]     ***   Name Aktuelle Gruppe in Element speichern*/
int
        XbWFDb_StorGrpn(
        void
        *(*p)[],
         int (*t)[]
        ) ;
/*}}}  */
/*{{{  XbWFDb_StrToDbI( [x4.c;1186]     ****/
XbWDDb_DbIPtr
        XbWFDb_StrToDbI(
        char *str,
         XbWDDb_DbIVar
        *IP
        );
/*}}}  */
/*{{{  XbWFDb_StrToPtr( [x4.c;1160]     ****/
XbWDDb_DbIVar
        *XbWFDb_StrToPtr(
        char *name
        );
/*}}}  */
/*{{{  XbWFDb_VarInh( [x4.c;0147]       ****/
char
        *XbWFDb_VarInh(
        XbWDDb_DbIVar
        *start,
         int tp,
         char *name,
         int recursiv
        );
/*}}}  */
/*{{{  XbWFDb_WrTable( [x4.c;1708]      ***    Datenbank binaer schreiben*/
int
        XbWFDb_WrTable(
        void
        *(*p)[],
        int (*t)[]
        );
/*}}}  */
/*{{{  XbWFEd_GetAStr( [x3.c;1306]      ***    Unterprogramm; ruft GetStr*/
void
        XbWFEd_GetAStr(
        void
        ) ;
/*}}}  */
/*{{{  XbWFEd_GetOStr( [x3.c;1367]      ***    String im Objekt einlesen (xa,ya,xb,yb...)*/
void
        XbWFEd_GetOStr(
        XbWDDb_DbIWdw
        *WI,
        char *string,
        int MaxLen,
 
    int XA,
         int YA,
         int XB,
         int YB,
        char *defaultmsg,
         int cpo);
/*}}}  */
/*{{{  XbWFEd_GetSStr( [x3.c;1318]      ***    String in Standard-Texteingabezeile einlesen*/
void
        XbWFEd_GetSStr(
        char *chdr,
         char *string,
        int MaxLen,
         int CurPos
        );
/*}}}  */
/*{{{  XbWFEd_GetStr( [x3.c;1212]       ***    Unterprogramm fuer Editor*/
void  XbWFEd_GetStr(void);
/*}}}  */
/*{{{  XbWFEd_MaxPort( [x3.c;1024]      ***    ViewPort-Routine fuer Texteditor*/
void  XbWFEd_MaxPort(void);
/*}}}  */
/*{{{  XbWFEd_MinPort( [x3.c;1034]      ***    dito*/
void  XbWFEd_MinPort(void);
/*}}}  */
/*{{{  XbWFEd_OutIns( [x3.c;1046]       ***    Zustand der Insert-Lampe*/
void  XbWFEd_OutIns(void);
/*}}}  */
/*{{{  XbWFEd_OutLine( [x3.c;1083]      ***    Textzeile ausgeben*/
void  XbWFEd_OutLine(void);
/*}}}  */
/*{{{  XbWFEd_OutStr( [x3.c;1201]       ***    Textstring ausgeben, ruft OutLine*/
void  XbWFEd_OutStr(void);
/*}}}  */
/*{{{  XbWFEd_TextXY( [x3.c;1062]       ***    TextXY fuer Texteditor*/
void
        XbWFEd_TextXY(
        int x,
        int y,
         int cur,
         char msg[255],
         unsigned char col
        );
/*}}}  */
/*{{{  XbWFGr_CurOFF( [x5.c;1281]       ***   ...Aus*/
void  XbWFGr_CurOFF(void);
/*}}}  */
/*{{{  XbWFGr_CurON( [x5.c;1270]        ***   GrafikCursor ein*/
void  XbWFGr_CurON(void);
/*}}}  */
/*{{{  XbWFGr_MaxPort( [x2.c;2478]      ****/
void  XbWFGr_MaxPort(void);
/*}}}  */
/*{{{  XbWFGr_MaxX( [x2.c;2394]         ***      VIDEO: Breite des nutzbaren Schirms*/
int  XbWFGr_MaxX(void);
/*}}}  */
/*{{{  XbWFGr_MaxY( [x2.c;2399]         ***      VIDEO: Hoehe...*/
int  XbWFGr_MaxY(void);
/*}}}  */
/*{{{  XbWFGr_MinPort( [x2.c;2483]      ****/
void
        XbWFGr_MinPort(
        int xxa,
        int yya,
        int xxb,
        int yyb
        );
/*}}}  */
/*{{{  XbWFGr_PopPort( [x2.c;2462]      ****/
void  XbWFGr_PopPort(void);
/*}}}  */
/*{{{  XbWFGr_PushPort( [x2.c;2454]     ***      Viewport-Verwaltung*/
void  XbWFGr_PushPort(void);
/*}}}  */
/*{{{  XbWFGr_RedPort( [x2.c;2495]      ****/
void
         XbWFGr_RedPort(
 
    int xa,
        int ya,
        int xb,
        int yb);
/*}}}  */
/*{{{  XbWFGr_ResPort( [x2.c;2522]      ****/
void   XbWFGr_ResPort(void);
/*}}}  */
/*{{{  XbWFGr_SetPort( [x2.c;2473]      ****/
void  XbWFGr_SetPort(void);
/*}}}  */
/*{{{  XbWFGr_THeight( [x2.c;2426]      ***      Pixelhoehe eines Zeichens ermitteln*/
int  XbWFGr_THeight(void);
/*}}}  */
/*{{{  XbWFGr_TWidth( [x2.c;2404]       ***      Pixelbreite eines Strings ermitteln*/
int
        XbWFGr_TWidth(
        char *sstr
        );
/*}}}  */
/*{{{  XbWFMf_CompileMF( [x4.c;3074]    ***    Metafile compilieren*/
void
        XbWFMf_CompileMF(
        char *filename
        );
/*}}}  */
/*{{{  XbWFMf_DebugON( [x4.c;2031]      ****/
void  XbWFMf_DebugON(void);
/*}}}  */
/*{{{  XbWFMf_EndOfMta( [x4.c;2060]     ****/
void  XbWFMf_EndOfMta(void);
/*}}}  */
/*{{{  XbWFMf_ExComand( [x5.c;0194]     ***   Haupt-Routine zum starten von Kommandos*/
int
        XbWFMf_ExComand(
        int no,
         int tfun
        );
/*}}}  */
/*{{{  XbWFMf_ExecCom( [x4.c;2016]      ***    Unterroutinen Metafile-Interpreter*/
void
        XbWFMf_ExecCom(
        char *com
        );
/*}}}  */
/*{{{  XbWFMf_GotoLabl( [x4.c;2064]     ****/
void
        XbWFMf_GotoLabl(
        void *p[1]
        );
/*}}}  */
/*{{{  XbWFMf_GtComNo( [x5.c;0287]      ***   Unterroutine zum Metafile-Interpreter*/
int
        XbWFMf_GtComNo(
        char *sstr
        );
/*}}}  */
/*{{{  XbWFMf_InterpretMF( [x4.c;2429]  ***    Haupt-Unterroutine fuer Interpreter*/
void
        XbWFMf_InterpretMF(
 
    FILE *MetaFile,
         char *rohzeile,
         int compile_target);
/*}}}  */
/*{{{  XbWFMf_PtrStr( [x4.c;2072]       ****/
void
        XbWFMf_PtrStr(
        char *zeile,
        char*rohzeile,
         int *r_a,
         int *r_l,
         FILE *MetaFile
        );
/*}}}  */
/*{{{  XbWFMf_RdCompMak( [x4.c;2358]    ****/
void
        XbWFMf_RdCompMak(
        XbWDDb_DbIVar
        *start
        );
/*}}}  */
/*{{{  XbWFMf_ReadMF( [x4.c;3005]       ***    Metafile interpretieren*/
void
        XbWFMf_ReadMF(
        char *filename
        );
/*}}}  */
/*{{{  XbWFMf_ReadMakro( [x4.c;3120]    ***    Makro interpretieren*/
void
        XbWFMf_ReadMakro(
        char *makro
        );
/*}}}  */
/*{{{  XbWFMf_SetNames( [x4.c;2036]     ****/
int
        XbWFMf_SetNames(
        char *lzeile
        );
/*}}}  */
/*{{{  XbWFMf_StrtHookCmd( [x5.c;0148]*/
int
        XbWFMf_StrtHookCmd(
        void
        *(*p)[],
         int(*t)[]
        );
/*}}}  */
/*{{{  XbWFMf_VPtr( [x4.c;2152]         ****/
void
        XbWFMf_VPtr(
        char *zeile,
        char*rohzeile,
         int *r_a,
         int *r_l,
         FILE *MetaFile,
         int *s_p
        );
/*}}}  */
/*{{{  XbWFMf_VPtr( [x4.c;2152]         ****/
void
        XbWFMf_VPtrKl(
        char *zeile,
        char*rohzeile,
         int *r_a,
         int *r_l,
         FILE *MetaFile,
         int *s_p
        );
/*}}}  */
/*{{{  XbWFMf_VPtrKl( [x4.c;2246]       ****/
void
        XbWFMf_VPtrKl(
        char *zeile,
        char*rohzeile,
         int *r_a,
         int *r_l,
         FILE *MetaFile,
         int *s_p
        );
/*}}}  */
/*{{{  XbWFMf_initMta( [x5.c;0306]      ***   Interpreter initialisieren*/
void  XbWFMf_initMta(void);
/*}}}  */
/*{{{  XbWFMx_Close( [xbcom.c;0344]        ****/
void  XbWFMx_Close(void);
/*}}}  */
/*{{{  XbWFMx_CrGrp( [x3.c;1579]        ***    Headerdatei fuer MFX-Gruppe erstellen*/
int
        XbWFMx_CrGrp(
        char *cgr_name
        );
/*}}}  */
/*{{{  XbWFMx_DbgON( [x4.c;3133]        ***    Debugging fuer MFX-Gruppen*/
void  XbWFMx_DbgON(void);
/*}}}  */
/*{{{  XbWFMx_DpError( [xbcom.c;0609]      ****/
void
        XbWFMx_DpError(
        char *text
        );
/*}}}  */
/*{{{  XbWFMx_DpMessage( [xbcom.c;0584]    ****/
void
        XbWFMx_DpMessage(
        char *text
        );
/*}}}  */
/*{{{  XbWFMx_DpPercent( [xbcom.c;0436]    ****/
unsigned int
        XbWFMx_DpPercent(
 
    double percent,
         double maximum,
         char *name,
         char *text);
/*}}}  */
/*{{{  XbWFMx_DpWarning( [xbcom.c;0642]    ****/
void
        XbWFMx_DpWarning(
        char *text
        );
/*}}}  */
/*{{{  XbWFMx_EndSet( [xbcom.c;0340]       ****/
void  XbWFMx_EndSet(void);
/*}}}  */
/*{{{  XbWFMx_GetDbl( [xbcom.c;0205]       ****/
int
        XbWFMx_GetDbl(
        double *variable
        );
/*}}}  */
/*{{{  XbWFMx_GetInt( [xbcom.c;0167]       ****/
int
        XbWFMx_GetInt(
        int *variable
        );
/*}}}  */
/*{{{  XbWFMx_GetStr( [xbcom.c;0246]       ****/
int
        XbWFMx_GetStr(
        char *variable
        );
/*}}}  */
/*{{{  XbWFMx_PutDbl( [xbcom.c;0326]       ****/
void
        XbWFMx_PutDbl(
        double variable,
         char *com
        );
/*}}}  */
/*{{{  XbWFMx_PutInt( [xbcom.c;0322]       ****/
void
        XbWFMx_PutInt(
        int variable,
         char *com
        );
/*}}}  */
/*{{{  XbWFMx_PutStr( [xbcom.c;0330]       ****/
void
        XbWFMx_PutStr(
        char *variable,
         char *com
        );
/*}}}  */
/*{{{  XbWFMx_RWGroup( [x3.c;1920]      ***    Hauptroutine, ruft CrGrp und RWGrp*/
int
        XbWFMx_RWGroup(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFMx_RWGrp( [x3.c;1416]        ***    Unterroutine zum MFX-Gruppe schreiben/lesen*/
int
        XbWFMx_RWGrp(
        char *rgr_nm,
         char* rgr_rwm,
 
                         int rw_smode,
         int rw_snr,
         char *new_filnm);
/*}}}  */
/*{{{  XbWFMx_RdSet( [xbcom.c;0105]        ****/
int
        XbWFMx_RdSet(
 
            char *filename,
 
            char *datensatzname);
/*}}}  */
/*{{{  XbWFMx_ResGrMode( [xbcom.c;0866]    ****/
void   XbWFMx_ResGrMode(void);
/*}}}  */
/*{{{  XbWFMx_WrSet( [xbcom.c;0289]        ****/
int
        XbWFMx_WrSet(
 
            char *filename,
 
            char *datensatzname,
 
            int mode);
/*}}}  */
/*{{{  XbWFOb_DispOnly( [x2.c;0847]     ***      Aufruf EditAndDisp als Disp*/
int
        XbWFOb_DispOnly(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFOb_EdDpObj( [x2.c;1103]      ***      Fuhrt edO aus*/
int
        XbWFOb_EdDpObj(
        char *obn,
        int mode
        );
/*}}}  */
/*{{{  XbWFOb_EdObjMausPos( [x2.c;0723] ***      Edit fur ein angeklicktes Objekt*/
void
        XbWFOb_EdObjMausPos(
 
    XbWDDb_DbIWdw
        *WI,
         int mausxa,
         int mausya);
/*}}}  */
/*{{{  XbWFOb_Edit( [x2.c;0344]         ***      Edit: raK,raT,raX,aW,edO,epO des Obj.*/
int
        XbWFOb_Edit(
        XbWDDb_DbIObj
        *MOB
        );
/*}}}  */
/*{{{  XbWFOb_Edit( [x2.c;0344]         ***      Edit: raK,raT,raX,aW,edO,epO des Obj.*/
int
        XbWFOb_EditAndDisp(
        char *obn,
        int mode
        );
/*}}}  */
/*{{{  XbWFOb_Edit( [x2.c;0344]         ***      Edit: raK,raT,raX,aW,edO,epO des Obj.*/
int
        XbWFOb_EditOnly(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFOb_EditAndDisp( [x2.c;0802]  ***      Editier-Hauptroutine*/
int
        XbWFOb_EditAndDisp(
        char *obn,
        int mode
        );
/*}}}  */
/*{{{  XbWFOb_EditOnly( [x2.c;0841]     ***      Aufruf EditAndDisp als Edit*/
int
        XbWFOb_EditOnly(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFOb_GetPar( [x2.c;0031]       ***      Parametersatz fur ein Obj. lesen*/
char
        *XbWFOb_GetPar(
 
    XbWDDb_DbIWdw
        *WI,
 
    XbWDDb_DbIObj
        *TO,
         char *sname,
         int mode);
/*}}}  */
/*{{{  XbWFOb_GiveInfo( [x5.c;0024]*/
void
        XbWFOb_GiveInfo(
 
    XbWDDb_DbIWdw
        *WI,
         int mausxa,
         int mausya,
         int smode);
/*}}}  */
/*{{{  XbWFOb_MovToPos( [x2.c;0853]     ***      Objektmove mit mittl. Maustaste*/
void
        XbWFOb_MovToPos(
 
    XbWDDb_DbIWdw
        *WI,
         int mausxa,
         int mausya);
/*}}}  */
/*{{{  XbWFOb_MovToWdw( [x2.c;0987]     ***      Obj. in and. Wdw verlegen; Listen-update*/
int
        XbWFOb_MovToWdw(
         void
        *(*p)[],
        int (*t)[]
        ) ;
/*}}}  */
/*{{{  XbWFOb_SetViewPort( [x2.c;2619]  ***      Viewport auf Objekt einstellen*/
void
        XbWFOb_SetViewPort(
        XbWDDb_DbIWdw
        *WI,
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOb_SubMovWdw( [x2.c;1022]    ***      Unterroutine dazu*/
int
        XbWFOb_SubMovWdw(
         char *onm,
         char *wnm
        );
/*}}}  */
/*{{{  XbWFOb_dpO( [x2.c;0501]          ***      dpO ausfuhren fur ein Objekt*/
void
        XbWFOb_dpO(
 
    XbWDDb_DbIWdw
        *WI,
         XbWDDb_DbIObj
        *NotDispObj);
/*}}}  */
/*{{{  XbWFOb_ebO( [x2.c;0287]          ***      Edit Before Object: bW,rbK,ebO,wbX,rbT*/
int
        XbWFOb_ebO(
        XbWDDb_DbIObj
        *MOB
        );
/*}}}  */
/*{{{  XbWFOb_epO( [x2.c;0252]          ***      Edit Previous Object: epO*/
int
        XbWFOb_epO(
        char *name
        );
/*}}}  */
/*{{{  XbWFOb_eqO( [x2.c;0427]          ***      Edit Queue: rqX,rqT,eqO,dqO des Objektes*/
int
        XbWFOb_eqO(
        XbWDDb_DbIObj
        *MOB
        );
/*}}}  */
/*{{{  XbWFOj_DiEdContents( [x2.c;1900] ***      Hauptroutine Disp&Edit nach Mausclick*/
void
        XbWFOj_DiEdContents(
        XbWDDb_DbIWdw
        *WI,
         XbWDDb_DbIObj
        *TOB,
         int edit
        );
/*}}}  */
/*{{{  XbWFOj_DpArrow( [x2.c;1229]      ***      Pfeil-Knopf darstellen*/
void
        XbWFOj_DpArrow(
        XbWDDb_DbIObj
        *TO,
         char *arrstr
        );
/*}}}  */
/*{{{  XbWFOj_DpBit( [x2.c;1307]        ***      Bit-Lampe darstellen*/
void
        XbWFOj_DpBit(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_DpBool( [x2.c;1294]       ***      Boolsche Lampe darstellen*/
void
        XbWFOj_DpBool(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_DpColButt( [x2.c;1120]    ***      Farbigen Knopf darstellen*/
void
        XbWFOj_DpColButt(
        XbWDDb_DbIObj
        *TO,
         int stat
        );
/*}}}  */
/*{{{  XbWFOj_DpEllipse( [x2.c;1329]    ***      Ellipse zeichnen*/
void
        XbWFOj_DpEllipse(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_DpInt( [x5.c;0619]        ***   Integer display*/
int
        XbWFOj_DpInt(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_DpLight( [x2.c;1173]      ***      Light-Objekt (Lampe) darstellen*/
void
        XbWFOj_DpLight(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_DpSlider( [x2.c;1343]     ***      Slider zeichnen*/
void
         XbWFOj_DpSlider(
        XbWDDb_DbIObj
        *TO,
         int w_mode
        );
/*}}}  */
/*{{{  XbWFOj_DpSwt( [x2.c;1322]        ***      Switch-Lampe darstellen*/
void
        XbWFOj_DpSwt(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_Dp_A( [x5.c;0436]         ***   Automatisch Elementinhalt belieb. Typs*/
int
        XbWFOj_Dp_A(
        XbWDDb_DbIObj
        *TOB,
         int this_obj
        );
/*}}}  */
/*{{{  XbWFOj_Dp_BKS( [x5.c;0626]       ***   Pfeil-Knopf zeigen*/
int
        XbWFOj_Dp_BKS(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Dp_G( [x5.c;0567]         ***   Gruppennamen zeigen*/
int
        XbWFOj_Dp_G(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Dp_M( [x5.c;0316]         ***   Display fuer MFX-Objekt*/
int
        XbWFOj_Dp_M(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Dp_N( [x5.c;0388]         ***   Elementnamen zeigen*/
int
        XbWFOj_Dp_N(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Dp_P( [x5.c;0633]         ***   Icon zeigen*/
int
        XbWFOj_Dp_P(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Dp_R( [x5.c;0337]         ***   Eine Zeile aus einer Textdatei zeigen*/
int
        XbWFOj_Dp_R(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Dp_S( [x5.c;0601]         ***   String display*/
int
        XbWFOj_Dp_S(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Dp_T( [x5.c;0610]         ***   Text display*/
int
        XbWFOj_Dp_T(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Dp_X( [x5.c;0640]         ***   XS-Slider,XL-Line,XE-Ellipse,XB-Box*/
int
        XbWFOj_Dp_X(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Dp_Z( [x5.c;0416]         ***   Projektnamen zeigen*/
int
        XbWFOj_Dp_Z(
        XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_EdCalc( [x2.c;0549]       ***      Edit CALC: Ausfuehren einer Berechnung*/
int
        XbWFOj_EdCalc(
        int edit,
         XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_EdInt( [x2.c;1744]        ***      Integer-Objekt editieren*/
void
        XbWFOj_EdInt(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_EdSlider( [x2.c;1798]     ***      Slider verschieben*/
void
        XbWFOj_EdSlider(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_EdStr( [x2.c;1635]        ***      String-Objekt editieren*/
void
        XbWFOj_EdStr(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_EdSwt( [x2.c;1609]        ***      Switch-Lampe editieren*/
void
        XbWFOj_EdSwt(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_Ed_A( [x2.c;2156]         ***,PRJ  Inhalt jeden Typs editieren*/
int
        XbWFOj_Ed_A(
        int edit,
         XbWDDb_DbIObj
        *TOB,
         int this_obj
        );
/*}}}  */
/*{{{  XbWFOj_Ed_B( [x2.c;2313]         ***      Boolesche Lampe editieren (invertieren)*/
int
        XbWFOj_Ed_B(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_C( [x2.c;2329]         ***      Switch-Objekt auswerten*/
int
        XbWFOj_Ed_C(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_F( [x2.c;2289]         ***      Fur Knopfe, die keine Ed-Variante haben*/
int
        XbWFOj_Ed_F(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_G( [x2.c;2022]         ***,PRJ  Gruppenname in Var-Inh. eintragen*/
int
        XbWFOj_Ed_G(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_HID( [x2.c;2305]       ***      HEX/Integer/Double editieren*/
int
        XbWFOj_Ed_HID(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_L( [x2.c;2321]         ***      Light-Objekt editieren (auswerten)*/
int
        XbWFOj_Ed_L(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_M( [x2.c;2337]         ***      MFX-Gruppe lesen/schreiben*/
int
        XbWFOj_Ed_M(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_N( [x2.c;1991]         ***,PRJ  Variablenname in Var-Inh. eintragen*/
int
        XbWFOj_Ed_N(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_R( [x2.c;2059]         ***,PRJ  Zeile aus Textdatei editieren*/
int
        XbWFOj_Ed_R(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_S( [x2.c;2297]         ***      String-Objekt editieren*/
int
        XbWFOj_Ed_S(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_T( [x2.c;2385]         ***      Taskstart ausfuhren*/
int
        XbWFOj_Ed_T(
        XbWDDb_DbIWdw
        *WI,
         int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_U( [x5.c;0322]         ***   Color-Button*/
int
        XbWFOj_Ed_U(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_V( [x5.c;0330]         ***   Color-Button*/
int
        XbWFOj_Ed_V(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_X( [x2.c;2368]         ***      XS=Slider, XB=Bit editieren*/
int
        XbWFOj_Ed_X(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_Ed_Z( [x2.c;1878]         ***      Projektname editieren*/
int
        XbWFOj_Ed_Z(
        int edit,
         XbWDDb_DbIObj
        *TOB
        );
/*}}}  */
/*{{{  XbWFOj_GetNum( [x2.c;1670]       ***      Unterfunktion zu EdInt*/
double
        XbWFOj_GetNum(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_PutNum( [x2.c;1721]*/
double
        XbWFOj_PutNum(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWFOj_SpawnTsk( [x2.c;1428]     ***      taskstart durchfuhren als Obj-Aktion*/
void
        XbWFOj_SpawnTsk(
        XbWDDb_DbIWdw
        *TW,
        XbWDDb_DbIObj
        *TO,
 
    unsigned char styp,
         unsigned char write_tbl,
         unsigned char ttyp,
 
    unsigned char no_params);
/*}}}  */
/*{{{  XbWFSy_ChDir( [x1.c;0287]                X11    Wechsle Verzeichnis*/
int
        XbWFSy_ChDir(
        void
        *(*p)[],
        int (*t)[]
        );
/*}}}  */
/*{{{  XbWFSy_SysStop( [x4.c;3139]      ***    XbW-System stoppen*/
void  XbWFSy_SysStop(void);
/*}}}  */
/*{{{  XbWFSy_doCreateWindow( [x1.c;3141]       X11    Hauptwindow generieren*/
void  XbWFSy_doCreateWindow(void);
/*}}}  */
/*{{{  XbWFSy_doDefineColor( [x1.c;3115]        X11    Farbe allozieren (X11 only)*/
unsigned long
        XbWFSy_doDefineColor(
        int n
        );
/*}}}  */
/*{{{  XbWFSy_doUnmapWindows( [x1.c;3215]       X11    Windowdarstellung ENDE*/
void  XbWFSy_doUnmapWindows(void);
/*}}}  */
/*{{{  XbWFTb_AClosOFF( [x5.c;1014]     ***   ...AUS; wirkt wenn Wdw teilweise ueberdeckt*/
void  XbWFTb_AClosOFF(void);
/*}}}  */
/*{{{  XbWFTb_AClosON( [x5.c;1009]      ***   Automatisches WindowClose EIN;*/
void  XbWFTb_AClosON(void);
/*}}}  */
/*{{{  XbWFTb_AnswerPopUpReq( [x5.c;0978]   ***   PopUpBox mit 3 Moeglichkeiten*/
int
        XbWFTb_AnswerPopUpReq(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_Case( [x5.c;0862]         ***   Case-Abfrage fuer Metafile-Interpreter*/
int
        XbWFTb_Case(
        void
        *(*p)[],
        int (*t)[]
        );
/*}}}  */
/*{{{  XbWFTb_CkRadFil( [x5.c;0710]     ***   RADAN-Filenamen pruefen (VW-Speziell)*/
int
        XbWFTb_CkRadFil(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_Click( [x5.c;1057]        ***   Klick-Geraeusch*/
void  XbWFTb_Click(void);
/*}}}  */
/*{{{  XbWFTb_ClrScr( [x5.c;1001]       ***   Schirm loeschen*/
void  XbWFTb_ClrScr(void);
/*}}}  */
/*{{{  XbWFTb_CmpBox( [x2.c;2590]       ***      Check ob Obj ganz au�erhalb e.Wdws ist*/
int
        XbWFTb_CmpBox(
        int oxa,
        int oya,
        int oxb,
        int oyb,
 
                int wxa,
        int wya,
        int wxb,
        int wyb);
/*}}}  */
/*{{{  XbWFTb_CmpStr( [x5.c;0825]       ***   Strings vergleichen*/
int
        XbWFTb_CmpStr(
        char *stra,
         char *strb
        );
/*}}}  */
/*{{{  XbWFTb_ColCon( [x5.c;0786]       ***   Farbkonvertierung fuer Textfarbe*/
int
        XbWFTb_ColCon(
        int dunkelfarbe
        );
/*}}}  */
/*{{{  XbWFTb_CorrSiz( [x5.c;1090]      ***   Windowkoordinaten anpassen*/
void
        XbWFTb_CorrSiz(
 
    int *xa,
        int *ya,
        int *xb,
        int *yb,
 
    int wxa,
         int wya,
         int wxb,
         int wyb);
/*}}}  */
/*{{{  XbWFTb_DbgMta( [x5.c;0996]       ***   Debugging fuer Metafiles einschalten*/
void  XbWFTb_DbgMta(void);
/*}}}  */
/*{{{  XbWFTb_DoSpecialCommand( [x5.c;0658] ***   Hauptroutine fuer alle Erweiterungen*/
int
        XbWFTb_DoSpecialCommand(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_Error( [x2.c;2582]        ***      Nachricht; warte auf Taste*/
void
        XbWFTb_Error(
        char*msg
        );
/*}}}  */
/*{{{  XbWFTb_HBeep( [x5.c;1068]        ***   Hoher Piepton*/
void  XbWFTb_HBeep(void);
/*}}}  */
/*{{{  XbWFTb_InBox( [x5.c;0775]        ***   Maus in Box ??*/
boolean
        XbWFTb_InBox(
 
    int sxa,
        int sya,
        int xa,
        int ya,
        int xb,
        int yb);
/*}}}  */
/*{{{  XbWFTb_LBeep( [x5.c;1079]        ***   Tiefer Piepton*/
void  XbWFTb_LBeep(void);
/*}}}  */
/*{{{  XbWFTb_Message( [x2.c;2546]      ***      Nachricht unten ausgeben*/
void
        XbWFTb_Message(
        char *msg
        );
/*}}}  */
/*{{{  XbWFTb_MkRadFil( [x5.c;0672]     ***   RADAN-Filenamen generieren (VW-Speziell)*/
int
        XbWFTb_MkRadFil(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_MouseWarp( [x5.c;0153]*/
int
        XbWFTb_MouseWarp(
        void
        *(*p)[],
         int(*t)[]
        );
/*}}}  */
/*{{{  XbWFTb_NumVal( [x4.c;3170]       ***    Wie C: a=b*/
int
        XbWFTb_NumVal(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFTb_Outl( [x5.c;1100]         ***   Textzeile fuer PopUpBoxen ausgeben*/
void
        XbWFTb_Outl(
        int xa,
         int *ya,
         char *txt,
         int col
        );
/*}}}  */
/*{{{  XbWFTb_PackStr( [x5.c;0921]      ***   String-Element Inhalt packen (PckText)*/
int
        XbWFTb_PackStr(
        void
        *(*p)[],
         int (*t)[]
        ) ;
/*}}}  */
/*{{{  XbWFTb_PckTxt( [x5.c;0751]       ***   Text von Spaces befreien*/
char
        *XbWFTb_PckTxt(
        char *str
        );
/*}}}  */
/*{{{  XbWFTb_PopUpBox( [x5.c;1253]     ***   PopUpBox ausgeben*/
void
        XbWFTb_PopUpBox(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_PutAlarm( [x5.c;0839]     ***   Nachreicht; warte auf Taste*/
void
        XbWFTb_PutAlarm(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_PutError( [x5.c;0846]     ***   Nachricht; Taste; PopUpBox ausgeben*/
void
        XbWFTb_PutError(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_PutMessage( [x5.c;0832]   ***   Nachricht unten ausgeben*/
void
        XbWFTb_PutMessage(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_RedrawOFF( [x5.c;1024]    ***   ...teilweise verdeckt ist*/
void  XbWFTb_RedrawOFF(void);
/*}}}  */
/*{{{  XbWFTb_RedrawON( [x5.c;1019]     ***   Window neuzeichnen, wenn angecklickt &*/
void  XbWFTb_RedrawON(void);
/*}}}  */
/*{{{  XbWFTb_ReplString( [x5.c;0738]   ***   String-Ersetzung*/
int
        XbWFTb_ReplString(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_SpwnTsk( [x5.c;1029]      ***   Task spawn*/
void  XbWFTb_SpwnTsk(void);
/*}}}  */
/*{{{  XbWFTb_SpwnTsk( [x5.c;1029]      ***   Task spawn*/
int
        XbWFTb_SpwnTskClrScr(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFTb_SpwnTsk( [x5.c;1029]      ***   Task spawn*/
int
        XbWFTb_SpwnTskTxtMod(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFTb_SpwnTskClrScr( [x5.c;1037]    ***   Task spawn mit anschliessendem ClrScr*/
int
        XbWFTb_SpwnTskClrScr(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFTb_SpwnTskTxtMod( [x5.c;1050]    ***   Task im Textmode spawnen; dann ClrScr*/
int
        XbWFTb_SpwnTskTxtMod(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWFTb_StrExpand( [x4.c;3147]    ***    Wie C: sprintf(..)*/
int
        XbWFTb_StrExpand(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_SubPopUpBox( [x5.c;1107]  ***   Unterroutine fuer PopUpBox*/
int
        XbWFTb_SubPopUpBox(
        char msg1[50],
        char msg2[50],
 
            char text1[50],
        char text2[50],
        char text3[50]);
/*}}}  */
/*{{{  XbWFTb_Unlink( [x5.c;0853]       ***   Datei loeschen*/
int
        XbWFTb_Unlink(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFTb_Wait( [x5.c;1265]         ***   Warten; Zeit in Millisekunden*/
void
        XbWSOS_Delay(
        int len
        );
/*}}}  */
/*{{{  XbWFTb_Wait( [x5.c;1265]         ***   Warten; Zeit in Millisekunden*/
void
        XbWFTb_Wait(
        int zeit
        );
/*}}}  */
/*{{{  XbWFTb_Warning( [x2.c;2566]      ***      Nachricht unten ausgeben*/
void
        XbWFTb_Warning(
        char *msg
        );
/*}}}  */
/*{{{  XbWFWd_BackGr( [x2.c;2528]       ***      Hintergrund des Schirms fuellen*/
void   XbWFWd_BackGr(void);
/*}}}  */
/*{{{  XbWFWd_ChkAct( [x3.c;0598]       ***    Check auf Hintergrund-Aktion von Objekten*/
void  XbWFWd_ChkAct(void);
/*}}}  */
/*{{{  XbWFWd_ChkDisp( [x3.c;0532]      ***    Check ob Hintergrund-Display von Wdws noetig*/
void  XbWFWd_ChkDisp(void);
/*}}}  */
/*{{{  XbWFWd_Draw( [x3.c;0361]         ***    Neuzeichnen (???)*/
void  XbWFWd_DrawAll(void);
/*}}}  */
/*{{{  XbWFWd_Draw( [x3.c;0361]         ***    Neuzeichnen (???)*/
void  XbWFWd_DrawP(void);
/*}}}  */
/*{{{  XbWFWd_Draw( [x3.c;0361]         ***    Neuzeichnen (???)*/
void  XbWFWd_Draw(void);
/*}}}  */
/*{{{  XbWFWd_DrawAll( [x3.c;0186]      ***    Alle Windows zeichnen*/
void  XbWFWd_DrawAll(void);
/*}}}  */
/*{{{  XbWFWd_DrawP( [x3.c;0355]        ***    Neuzeichnen*/
void  XbWFWd_DrawP(void);
/*}}}  */
/*{{{  XbWFWd_DrwASub( [x3.c;0155]         ***    Unterroutine zu DrawAll*/
void  XbWFWd_DrwASub(void);
/*}}}  */
/*{{{  XbWFWd_EraWdw( [x3.c;0218]       ***    Ein Window loeschen*/
void  XbWFWd_EraWdw(void);
/*}}}  */
/*{{{  XbWFWd_Erase( [x2.c;2536]        ***      Window loeschen*/
void
         XbWFWd_Erase(
        XbWDDb_DbIWdw
        *WI
        );
/*}}}  */
/*{{{  XbWFWd_Exists( [x3.c;0369]       ***    Ob Window existiert*/
int
        XbWFWd_Exists(
        char *refname
        );
/*}}}  */
/*{{{  XbWFWd_GetList( [x3.c;0025]      ***    Liste aller Windownamen lesen*/
int  XbWFWd_GetList(void);
/*}}}  */
/*{{{  XbWFWd_GetPara( [x3.c;0045]      ***    Parameter eines Windows laden*/
int
        XbWFWd_GetPara(
        int nr,
         XbWDDb_DbIWdw
        *TW
        );
/*}}}  */
/*{{{  XbWFWd_Hide( [x3.c;0112]         ***    Ckeck ob ein Window ein anderes ganz verdeckt*/
int
        XbWFWd_Hide(
        XbWDDb_DbIWdw *wtest,
         XbWDDb_DbIWdw *wb
        );
/*}}}  */
/*{{{  XbWFWd_IconAll( [x3.c;0255]      ***    Alle Ede iconizen*/
void  XbWFWd_IconAll(void);
/*}}}  */
/*{{{  XbWFWd_Iconize( [x3.c;0241]      ***    Window iconizen*/
void  XbWFWd_Iconize(void  *(*p)[]);
/*}}}  */
/*{{{  XbWFWd_InInner( [x3.c;0409]      ***    ...innerhalb*/
int  XbWFWd_InInner(void);
/*}}}  */
/*{{{  XbWFWd_LockEdit( [x3.c;0520]     ***    Schutz EIN wenn Objekt angeklickt*/
void  XbWFWd_LockEdit(void);
/*}}}  */
/*{{{  XbWFWd_LockOFF( [x3.c;0526]      ***    Schutz AUS*/
void  XbWFWd_LockOFF(void);
/*}}}  */
/*{{{  XbWFWd_LockON( [x3.c;0514]       ***    Schutz vor falschen Verlassen EIN*/
void  XbWFWd_LockON(void);
/*}}}  */
/*{{{  XbWFWd_Make( [x2.c;2606]         ***      Window zeichnen (Jetzt nur noch Box...)*/
void
         XbWFWd_Make(
        XbWDDb_DbIWdw
        *WI
        );
/*}}}  */
/*{{{  XbWFWd_NotInWdw( [x3.c;0396]     ***    Check ob Maus ausserhalb*/
int  XbWFWd_NotInWdw(void);
/*}}}  */
/*{{{  XbWFWd_OManager( [x3.c;0646]     ***    Hauptroutine bei PopUpWindow*/
void
        XbWFWd_OManager(
        int popup,
         char *wname
        );
/*}}}  */
/*{{{  XbWFWd_OvrLap( [x3.c;0091]       ***    Check ob sich zwei Wdws ueberlappen*/
int
        XbWFWd_OvrLap(
        XbWDDb_DbIWdw *wtest,
         XbWDDb_DbIWdw *wb
        );
/*}}}  */
/*{{{  XbWFWd_PopUp( [x3.c;0955]        ***    (PopUpWindow)*/
void
        XbWFWd_PopUp(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFWd_ReDisp( [x3.c;0132]       ***    Window Rahmen und Inhalt zeichnen*/
void  XbWFWd_ReDisp(void);
/*}}}  */
/*{{{  XbWFWd_Rebuild( [x3.c;0225]      ***    Alle Objekte eines Windows zeichnen*/
void  XbWFWd_Rebuild(void);
/*}}}  */
/*{{{  XbWFWd_Refresh( [x3.c;0137]      ***    Window Rahmen zeichnen*/
void  XbWFWd_Refresh(void);
/*}}}  */
/*{{{  XbWFWd_RestImage( [x3.c;1018]    ****/
void
        XbWFWd_RestImage(
        XbWDDb_DbIWdw
        *WI
        );
/*}}}  */
/*{{{  XbWFWd_SaveImage( [x3.c;1013]    ****/
void
        XbWFWd_SaveImage(
        XbWDDb_DbIWdw
        *WI
        );
/*}}}  */
/*{{{  XbWFWd_SaveRestore( [x3.c;0962]  ****/
void
        XbWFWd_SaveRestore(
        XbWDDb_DbIWdw
        *WI,
         int read
        );
/*}}}  */
/*{{{  XbWFWd_Select( [x3.c;0341]       ***    Ruft SwitchTo auf*/
int
        XbWFWd_Select(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFWd_SetPort( [x3.c;0384]      ***    Videoport auf Window einstellen*/
void
        XbWFWd_SetPort(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWFWd_SlctOther( [x3.c;0423]    ***    ...auf einem anderem Window*/
void  XbWFWd_SlctOther(void);
/*}}}  */
/*{{{  XbWFWd_SwitchTo( [x3.c;0282]     ***    Window anwaehlen*/
void
        XbWFWd_SwitchTo(
        char *nm,
         int savescreen
        );
/*}}}  */
/*{{{  XbWFWd_WManager( [x3.c;0949]     ***    Hauptroutine zur Fensterverwaltung*/
void  XbWFWd_WManager(void);
/*}}}  */
/*{{{  XbWSGr_BCBox( [x1.c;1657]        TC3,GNU,X11    Text-Box, unten zentriert*/
void
        XbWSGr_BCBox(
 
  int xa,
        int ya,
 
  int xb,
        int yb,
 
  char
        *msg,
 
  int fillcol,
         int textcol,
         int framecol);
/*}}}  */
/*{{{  XbWSGr_CCBox( [x1.c;1583]        TC3,GNU,X11    Text-Box, zentriert*/
void
        XbWSGr_CCBox(
 
  int xa,
        int ya,
 
  int xb,
        int yb,
 
  char
        *msg,
 
  int fillcol,
         int textcol,
         int framecol);
/*}}}  */
/*{{{  XbWSGr_Close( [x1.c;1982]        TC3,g--,x--    Grafik schlie�en*/
void   XbWSGr_Close(void);
/*}}}  */
/*{{{  XbWSGr_CopImag( [x1.c;1409]      TC3,GNU,x//    Blit Image aus Memory-Context*/
void
        XbWSGr_CopImag(
        void
        *where,
        int x1,
         int y1,
 
  int x2,
         int y2,
 
  int oper);
/*}}}  */
/*{{{  XbWSGr_DelImag( [x1.c;1399]      TC3,GNU,x//    Memory-Context loeschen*/
void
        XbWSGr_DelImag(
        void
        *where
        );
/*}}}  */
/*{{{  XbWSGr_DspIcon( [x1.c;2019]      TC3,g!!,x!!    Icon darstellen*/
void
        XbWSGr_DspIcon(
 
    XbWDDb_DbIObj
        *TO);
/*}}}  */
/*{{{  XbWSGr_Ell( [x1.c;1493]          TC3,!!!        Kreis bzw. Ellipse*/
void
        XbWSGr_Ell(
        int xa,
        int ya,
        int stang,
        int endang,
 
              int ra,
        int rb,
        int farbe);
/*}}}  */
/*{{{  XbWSGr_GetClip( [x1.c;2102]      TC3,GNU,X11    Clipping f�r Zeichenfunkt.*/
void
        XbWSGr_GetClip(
        void
        *theport
        );
/*}}}  */
/*{{{  XbWSGr_GetImag( [x1.c;2052]      TC3,g--,x--    Turbo C-Funktion*/
void
        XbWSGr_GetImag(
        int a,
         int b,
         int c,
         int d,
         void
        *e
        );
/*}}}  */
/*{{{  XbWSGr_GotoXY( [x1.c;1804]       ???,TC3*/
void
        XbWSGr_GotoXY(
        int x,
         int y
        );
/*}}}  */
/*{{{  XbWSGr_GtImSiz( [x1.c;2038]      TC3,g--,x--    Turbo C-Funktion*/
unsigned
        XbWSGr_GtImSiz(
        int a,
         int b,
         int c,
         int d
        );
/*}}}  */
/*{{{  XbWSGr_GtPhysX( [x1.c;1993]      TC3,GNU,X11    Grosste Schirmkoordinate X*/
int  XbWSGr_GtPhysX(void);
/*}}}  */
/*{{{  XbWSGr_GtPhysY( [x1.c;2006]      TC3,GNU,X11           -"-               Y*/
int  XbWSGr_GtPhysY(void);
/*}}}  */
/*{{{  XbWSGr_HLin( [x1.c;1467]         TC3,GNU        Horizontale Linie (schnell)*/
void
        XbWSGr_HLin(
        int xa,
        int xb,
        int ya,
        unsigned char color
        );
/*}}}  */
/*{{{  XbWSGr_Line( [x1.c;1434]         TC3,GNU        Linie zeichnen*/
void
        XbWSGr_Line(
        int xa,
        int ya,
        int xb,
        int yb,
        unsigned char color
        );
/*}}}  */
/*{{{  XbWSGr_PutImag( [x1.c;2045]      TC3,g--,x--    Turbo C-Funktion*/
void
        XbWSGr_PutImag(
        int a,
         int b,
         void
        *c,
         int d
        );
/*}}}  */
/*{{{  XbWSGr_RBBox( [x1.c;1732]        TC3,GNU,X11    Text-Box rechts unten aligned*/
void
        XbWSGr_RBBox(
 
  int xa,
        int ya,
 
  int xb,
        int yb,
 
  char
        *msg,
 
  int fillcol,
         int textcol,
         int framecol);
/*}}}  */
/*{{{  XbWSGr_ResImag( [x1.c;1373]      TC3,GNU,x//    Blit Image aus Memory-Context*/
void
        XbWSGr_ResImag(
        void
        *where,
        int x1,
         int y1,
 
  int x2,
         int y2,
 
  int oper);
/*}}}  */
/*{{{  XbWSGr_SavImag( [x1.c;1351]      TC3,GNU,x//    Blit Image in Memory-Context*/
void
        *XbWSGr_SavImag(
        int x1,
         int y1,
         int x2,
         int y2
        );
/*}}}  */
/*{{{  XbWSGr_SetClip( [x1.c;2059]      TC3,GNU,X11    Clipping f�r Zeichenfunkt.*/
void
        XbWSGr_SetClip(
 
    int xa,
         int ya,
         int xb,
         int yb);
/*}}}  */
/*{{{  XbWSGr_SetFontLib( [x1.c;2128]   TC3,g--,x--    Font Parameter aufsetzen*/
int  XbWSGr_SetFontLib(void);
/*}}}  */
/*{{{  XbWSGr_TLBox( [x1.c;1514]        TC3,GNU,X11    Text-Box, linksbundig, oben*/
void
        XbWSGr_TLBox(
 
  int xa,
        int ya,
 
  int xb,
        int yb,
 
  char
        *msg,
 
  int fillcol,
         int textcol,
         int framecol);
/*}}}  */
/*{{{  XbWSGr_VLin( [x1.c;1480]         TC3,GNU        Vertikale Linie (schnell)*/
void
        XbWSGr_VLin(
        int xa,
        int ya,
        int yb,
        unsigned char color
        );
/*}}}  */
/*{{{  XbWSMs_ButUp( [x1.c;1146]        TC3,GNU,X11    Ist Taste gedrueckt (Maus)*/
boolean
        XbWSMs_ButUp(
        int wait
        );
/*}}}  */
/*{{{  XbWSMs_ChkMot( [x1.c;0845]       TC3,GNU        Prufe, ob Maus bewegt wurde*/
void  XbWSMs_ChkMot(void);
/*}}}  */
/*{{{  XbWSMs_DFramOFF( [x1.c;1308]     TC3,g//,x??*/
void
         XbWSMs_DFramOFF(
        int xxa,
        int yya,
        int xxb,
        int yyb
        );
/*}}}  */
/*{{{  XbWSMs_DrReset( [x1.c;0537]      TC3,GNU        Maustreiber r�cksetzen*/
void  XbWSMs_DrReset(void);
/*}}}  */
/*{{{  XbWSMs_FramOFF( [x1.c;1287]      TC3,g//,x??*/
void
         XbWSMs_FramOFF(
        int xa,
        int ya,
        int xb,
        int yb
        );
/*}}}  */
/*{{{  XbWSMs_FramON( [x1.c;1263]       TC3,g//,x??*/
void
         XbWSMs_FramON(
        int xxa,
        int yya,
        int xxb,
        int yyb,
        int col
        );
/*}}}  */
/*{{{  XbWSMs_GetKey( [x1.c;0972]       TC3,GNU,X11    Aktuelle Taste holen*/
void
        XbWSMs_GetKey(
        unsigned char
        *c1,
         unsigned char
        *c2
        );
/*}}}  */
/*{{{  XbWSMs_Hd( [x1.c;0672]           TC3,GNU        Mauscursor verstecken*/
void  XbWSMs_Hd(void);
/*}}}  */
/*{{{  XbWSMs_Hd( [x1.c;0672]           TC3,GNU        Mauscursor verstecken*/
void  XbWSMs_OFF(void);
/*}}}  */
/*{{{  XbWSMs_Init( [x1.c;0557]         TC3,GNU        Maus initialisieren*/
boolean  XbWSMs_Init(void);
/*}}}  */
/*{{{  XbWSMs_IsAKey( [x1.c;1046]       TC3,GNU,X11    Ist Taste gedr�ckt (Keyboard)*/
boolean
        XbWSMs_IsAKey(
        int wait
        );
/*}}}  */
/*{{{  XbWSMs_OFF( [x1.c;0726]          TC3,GNU        Startet XbWSMs_Hd*/
void  XbWSMs_OFF(void);
/*}}}  */
/*{{{  XbWSMs_ON( [x1.c;0689]           TC3,GNU        Startet XbWSMs_Sh*/
void  XbWSMs_ON(void);
/*}}}  */
/*{{{  XbWSMs_ResPos( [x1.c;0782]       TC3,GNU        Mausposition rucksetzen*/
void  XbWSMs_ResPos(void);
/*}}}  */
/*{{{  XbWSMs_SetArrowCursor( [x1.c;0427]   GNU,X11    Maustreiber Pfeilcursor*/
void  *XbWSMs_SetArrowCursor(void);
/*}}}  */
/*{{{  XbWSMs_SetClockCursor( [x1.c;0391]   GNU,X11    Maustreiber Handcursor*/
void  *XbWSMs_SetClockCursor(void);
/*}}}  */
/*{{{  XbWSMs_SetHandCursor( [x1.c;0354]    GNU,X11    Maustreiber Handcursor*/
void  *XbWSMs_SetHandCursor(void);
/*}}}  */
/*{{{  XbWSMs_SetLastCursor( [x1.c;0463]    GNU X11    Maustreiber Pfeilcursor*/
void
        *XbWSMs_SetLastCursor(
        void
        *p
        );
/*}}}  */
/*{{{  XbWSMs_SetSens( [x1.c;0628]      TC3,GNU        Empfindlichkeit der Maus*/
void  XbWSMs_SetSens(void);
/*}}}  */
/*{{{  XbWSMs_SetSped( [x1.c;0640]      TC3,GNU        Geschwindigkeit der Maus*/
void  XbWSMs_SetSped(void);
/*}}}  */
/*{{{  XbWSMs_Sh( [x1.c;0651]           TC3,GNU        Mauscursor zeigen*/
void  XbWSMs_Sh(void);
/*}}}  */
/*{{{  XbWSMs_Sh( [x1.c;0651]           TC3,GNU        Mauscursor zeigen*/
void  XbWSMs_ON(void);
/*}}}  */
/*{{{  XbWSMs_Stat( [x1.c;0802]         TC3,GNU        Tasten und Position holen*/
void  XbWSMs_Stat(void);
/*}}}  */
/*{{{  XbWSMs_Stop( [x1.c;0616]         TC3,GNU        Ende; Interrupts freigeben*/
void  XbWSMs_Stop(void);
/*}}}  */
/*{{{  XbWSMs_WButtDn( [x1.c;0905]      TC3,GNU,X11    Warte auf Maustaste drucken*/
void  XbWSMs_WButtDn(void);
/*}}}  */
/*{{{  XbWSMs_WButtUp(*/
void  XbWSMs_WButtUp(void);
/*}}}  */
/*{{{  XbWSMs_WButtUpDn(*/
void  XbWSMs_WButtUpDn(void);
/*}}}  */
/*{{{  XbWSMs_WButtXX( [x1.c;0858]      TC3,GNU,X11    Maustreiber Buttons/Keyboard*/
void  XbWSMs_WButtUp(void);
/*}}}  */
/*{{{  XbWSMs_WaitKey( [x1.c;1224]      TC3,GNU,X11    Warte auf Taste (kbd)*/
void  XbWSMs_WaitKey(void);
/*}}}  */
/*{{{  XbWSMs_Warp( [x1.c;0745]         TC3,GNU        Mauscursor verschieben*/
void
        XbWSMs_Warp(
        int x,
        int y
        );
/*}}}  */
/*{{{  XbWSOS_Delay( [x1.c;2464]        TC3,GNU,x!!    XbWFTb_Wait in Millisekunden*/
void
        XbWSOS_Delay(
        int len
        );
/*}}}  */
/*{{{  XbWSOS_FilDir( [x1.c;2136]       TC3,g!!,x!!    String-Array mit Dateinamen*/
int
        XbWSOS_FilDir(
        void
        *(*p)[]
        );
/*}}}  */
/*{{{  XbWSOS_NoSound( [x1.c;2454]      TC3,GNU,x!!    Ton Aus*/
void  XbWSOS_NoSound(void);
/*}}}  */
/*{{{  XbWSOS_SpwnShel( [x1.c;2256]     TC3,g!!,x!!    OS-Shell spawn*/
void  XbWSOS_SpwnShel(void);
/*}}}  */
/*{{{  XbWSOS_SpwnStd( [x1.c;2276]      TC3,g!!,x!!    Standard-Task spawnen*/
int
        XbWSOS_SpwnStd(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWSPu_Alarm( [x1.c;2531]        TC3,GNU,X11    Unten am Schirm rote Box*/
void
        XbWSPu_Alarm(
        char *msg
        );
/*}}}  */
/*{{{  XbWSPu_Dir( [x1.c;2744]              ***        Directory-Box anzeigen*/
int
        XbWSPu_Dir(
        void
        *(*p)[],
        int (*t)[]
        );
/*}}}  */
/*{{{  XbWSPu_Dir( [x1.c;2744]              ***        Directory-Box anzeigen*/
int
        XbWSPu_DirEd(
        void
        *(*p)[],
        int (*t)[]
        );
/*}}}  */
/*{{{  XbWSPu_Dir( [x1.c;2744]              ***        Directory-Box anzeigen*/
void
        XbWSPu_DirCk(
        char *dummy,
         char *ziel_str,
        int ypos,
        int myp
        );
/*}}}  */
/*{{{  XbWSPu_Dir( [x1.c;2744]              ***        Directory-Box anzeigen*/
int
        XbWSPu_DirSb(
        void
        *(*p)[],
        int (*t)[],
         int dmode
        );
/*}}}  */
/*{{{  XbWSPu_DirCk( [x1.c;2754]        TC3,GNU,x!!    Unterroutine zur DirBox*/
void
        XbWSPu_DirCk(
        char *dummy,
         char *ziel_str,
        int ypos,
        int myp
        );
/*}}}  */
/*{{{  XbWSPu_DirEd( [x1.c;2749]            ***        Directory-Box auswerten*/
int
        XbWSPu_DirEd(
        void
        *(*p)[],
        int (*t)[]
        );
/*}}}  */
/*{{{  XbWSPu_DirSb( [x1.c;2770]        TC3,g??,x!!    Unterroutine zur DirBox*/
int
        XbWSPu_DirSb(
        void
        *(*p)[],
        int (*t)[],
         int dmode
        );
/*}}}  */
/*{{{  XbWSPu_Msg( [x1.c;2561]              ***        Nachricht in einem Window ausgeben*/
int
        XbWSPu_Msg(
        void
        *(*p)[],
        int (*t)[]
        );
/*}}}  */
/*{{{  XbWSSy_FatalEr( [x1.c;3099]      TC3,g??,x??    Fataler Fehler*/
void
         XbWSSy_FatalEr(
        char text[255]
        );
/*}}}  */
/*{{{  XbWSSy_FreeMem( [x1.c;3076]      TC3,GNU,X11    farfree bzw. free*/
void
        XbWSSy_FreeMem(
        void
        *a
        );
/*}}}  */
/*{{{  XbWSSy_GetDate( [x1.c;2493]      TC3,g??,x??    Systemdatum*/
void
         XbWSSy_GetDate(
        unsigned char *yy,
        unsigned char *mm,
 
                   unsigned char *dd);
/*}}}  */
/*{{{  XbWSSy_ObjDispIcon( [x1.c;0158]          X11    Icon (X11-Bitmap) darstellen*/
void
        XbWSSy_ObjDispIcon(
        XbWDDb_DbIObj
        *TO
        );
/*}}}  */
/*{{{  XbWSSy_ObjLoadIcon( [x1.c;0028]          X11*/
int
        XbWSSy_ObjLoadIcon(
        void
        *(*p)[],
         int (*t)[]
        );
/*}}}  */
/*{{{  XbWSSy_ResetWM( [x1.c;3227]      TC3,GNU,X11    HAUPTPROGRAMM DES XBW-SYSTEMS*/
int
        XbWSSy_ResetWM(
        int argc,
         char *argv[]
        );
/*}}}  */
/*{{{  XbWSSy_TimeSec( [x1.c;2505]      TC3,GNU,X11    Sekunden seit 1.1.1980*/
time_t   XbWSSy_TimeSec(void);
/*}}}  */
/*{{{  XbWSSy_chdirsub( [x1.c;0243]     TC3,GNU,X11    allgemeines chdir*/
int
        XbWSSy_chdirsub(
        char *name
        );
/*}}}  */
/*{{{  XbWSSy_fopen( [x1.c;0199]        TC3,GNU,X11    allgemeines open*/
FILE
        *XbWSSy_fopen(
        char *name,
         char *type
        );
/*}}}  */
/*{{{  XbWSWd_Move( [x1.c;1877]         TC3,GNU,X!!    Aktuelles Fenster bewegen*/
void  XbWSWd_Move(void);
/*}}}  */
/*{{{  main( [xbcom.c;0875]                ****/
int
        main(
        int argc,
        char *argv[]
        );
/*}}}  */

int XbWFDb_OpenSys(void  *(*p)[], int (*t)[]);
int XbWFMf_ParseMakro(char *macro);
int XbWSSy_RootWindow(void  *(*p)[],int (*t)[]);
int XbWFDb_AppWdw(void  *(*p)[], int (*t)[]);
int XbWSSy_LoadFont(char *fontname);
void  XbWFMf_StartMF(char *filename);
int  XbWSSy_SubWindow(int x, int y, int sx, int sy);
void XbWFSy_bf_printf(char *a, char *b);
int  XbWFDb_AppDblVal(void  *(*p)[], double val);


