 
struct symrec {
  char *name;
  int type;
  int malloc_used;
  union {
    XbWDDb_DbIVar *ptr;
    char *strp;
    double var;
    int ivar;
    int (*fnctptr)();
    } value;
  struct symrec *next;
  };
 
typedef struct symrec symrec;

extern symrec *sym_table;

symrec *putsum(char *sym_name, int sym_type);
symrec *getsym(char *sym_name);
 
int put_lval_end_command(void);
int put_lval_double(double dd);
int put_lval_string(char *str);
int put_lval_numvar(char *varname);
int put_lval_strvar(char *varname);
int put_lval_pointer(char type, char *str);
int put_lval_var(char *varname);
int put_lval_isvar(char *varname);
int put_lval_if(void);
int put_lval_then(void);
int put_lval_num_macropar(int num);
int put_lval_num_macropar(int num);
int put_lval_nullptr(void);

symrec *getsym(char *sym_name);

char *fltoa(double dd);

#define scratchmax 250
extern char scratch[scratchmax][200];
extern int scratchno;

extern int IFTHEN_val;

int begin_include(char *macro);
int begin_macro(char *macro);
int end_include(void);


