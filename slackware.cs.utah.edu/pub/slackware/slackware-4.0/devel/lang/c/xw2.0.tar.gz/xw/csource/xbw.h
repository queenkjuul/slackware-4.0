/* ================= XBW.H ============================================= */

/*#define XbW_SYSDEF_GNU_VERSION*/
/*#define XbW_SYSDEF_X11_VERSION*/

#ifndef XbW_SYSDEF_GNU_VERSION
#ifndef XbW_SYSDEF_X11_VERSION
#define XbW_SYSDEF_TC3_VERSION
#endif
#endif




#ifdef XbW_SYSDEF_TC3_VERSION
#define XbW_SYSDEF_USE_XBCOMFU
/* #define XbWDGr_IBM8514 1 */
#define XbW_SYSDEF_USE_LARGDBK
#define XbW_SYSDEF_USE_OSCFUNC
#endif


#ifdef XbWDGr_IBM8514
  #define XbWDMs_SoftMs 1
//  #define ALTER_MAUSTREIBER 1
#else
  #define HARDWARE_MAUS 1
#endif



#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#ifdef XbW_SYSDEF_GNU_VERSION
#include <unistd.h>
#include <gppconio.h>
#include <grx.h>
#include <mousex.h>
#include <pc.h>
#include <dos.h>
#include <dir.h>
#endif

#ifdef XbW_SYSDEF_TC3_VERSION
#include <math.h>
#include <conio.h>
#include <alloc.h>
#include <dos.h>
#include <dir.h>
#include <graphics.h>
#include <process.h>
#endif




#ifdef XbW_SYSDEF_GNU_VERSION

#define
#define far
#define USE_PC_SOUND
#endif

#ifdef XbW_SYSDEF_X11_VERSION

#define huge
#define far

#endif

#ifndef XbW_SYSDEF_TC3_VERSION
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <unistd.h>
#endif

#ifdef XbW_SYSDEF_TC3_VERSION
/* Alle defines, die man braucht, wenn turboc vorhanden */

#define USE_PC_SOUND
#define USE_8086_INTERRUPTS

#else

/* Alle defines, die man braucht, wenn turboc nicht vorhanden */
struct viewporttype{
   int left, top, right, bottom;
   int clip;
   };

struct REGPACK{
    unsigned int   r_ax, r_bx, r_cx, r_dx;
    unsigned int   r_bp, r_si, r_di, r_ds, r_es, r_flags;
    };

enum putimage_ops {     /* BitBlt operators for putimage */
    COPY_PUT,           /* MOV */
    XOR_PUT,            /* XOR */
    OR_PUT,             /* OR  */
    AND_PUT,            /* AND */
    NOT_PUT             /* NOT */
    };

#ifndef XbW_SYSDEF_X11_VERSION
typedef long    fpos_t;
#endif

#endif



#ifdef XbW_SYSDEF_X11_VERSION
/*#define XbWDSy_FontName "-bitstream-courier-medium-r-normal--11-0-0-0-m-0-iso8859-1"*/
/*#define XbWDSy_FontName   "-schumacher-*-*-semicondensed--11-*-*-*-c-*-iso8859-1"*/
#define XbWDSy_FontName "-schumacher-*-medium-*-*--11-*-*-*-c-*-iso8859-1"
#define XbWDSy_WindowName "XbW: X without \"bells and whistles\""
#endif





#define XbWDMf_CommandOk 0
#define XbWDMf_CommandErr 1
#define XbWDMf_EXETaskStart 1
#define XbWDMf_CommandErr 1
#define XbWDOb_DrawRedBox 3

#define XbWDDb_DbIPtr long              /* Offset relativ zum Projektbeginn       */
#define XbWDDb_DbITyp int               /* Typ eines Eintrages in der XbWDDb_Dbk */
#define XbWDDb_Handle XbWDDb_DbIPtr
#define XbWDDb_Get 0
#define XbWDDb_Put 1
#define XbWDDb_RecursiveAccess 1        /* Standard */
#define XbWDDb_DirectAccess    0        /* Nur fuer Sonderfaelle */

#define XbWDTb_PckTLen 250

#define XbWDGr_Write 0
#define XbWDGr_XOR   1
#define XbWDGr_OR    2
#define XbWDGr_AND   3

#define XbWDDb_NoVar    0x00  /* KEINE VARIABLE!! */
#define XbWDDb_Int      0x10
#define XbWDDb_Dbl      0x20
#define XbWDDb_IPtr     0x30
#define XbWDDb_Cll      0x40  /* enthaelt nummern von systembefehlen (??)      */
#define XbWDDb_Byt      0x50
#define XbWDDb_NPtr     0x60
#define XbWDDb_GPtr     0x70  /* Zeiger auf den Beginn einer Gruppe            */
#define XbWDDb_FPtr     0x80  /* Naechstes ITM (bei Verlaengerung einer Gruppe)*/
#define XbWDDb_Str      0x90

#define XbWDDb_Typ     0xF0
#define XbWDDb_NLen     0x0F


#define XbWDDb_Dbk   ((XbWDDb_Sys   *)XbWVDb_DbkStrt)
 

#define XbWDDb_DbISys (XbWDDb_DbIVar  *)(((XbWDDb_Sys  *)XbWVDb_DbkStrt)->T_ITM_SYS)
#define XbWDDb_DbIPrj (XbWDDb_DbIVar  *)(((XbWDDb_Sys  *)XbWVDb_DbkStrt)->T_ITM_PRJ)
#define XbWDDb_DbIGrp (XbWDDb_DbIStr  *)(((XbWDDb_Sys  *)XbWVDb_DbkStrt)->T_ITM_GRP)


#define XbWDWd_MaxWdw 300
#define XbWDWd_BordH   15


#ifdef XbWDGr_IBM8514
#define XbWDGr_AkDrivr IBM8514
#define XbWDGr_AkGrMod IBM8514HI
#define XbWDGr_BkColor XbWVGr_LGray
#define XbWDGr_HwBkGd XbWVGr_Black
#define XbWDGr_FontSiz 0
#define XbWDGr_AkFont SMALL_FONT
#else
#define XbWDGr_AkDrivr VGA
#define XbWDGr_AkGrMod VGAHI
#define XbWDGr_HwBkGd XbWVGr_Black
#define XbWDGr_BkColor XbWVGr_LGray
#define XbWDGr_FontSiz 1
#define XbWDGr_AkFont DEFAULT_FONT
#endif


#define XbWDGr_GrKreuz 1
#define XbWDGr_DiKreuz 2
#define XbWDGr_ScKreuz 4
#define XbWDGr_Kreis  8
#define XbWDGr_DashdBd 16
#define XbWDGr_RedBord 32
#define XbWDGr_RedBox 64
#define XbWDGr_Overbox 128
#define XbWDGr_Opentop 256

#define XbWDMs_Pix 13



#define XbWDOb_GtMinP  1
#define XbWDOb_GtDspP 2
#define XbWDOb_GtEdtP 4
#define XbWDOb_GtAllP  7
#define XbWDOb_GtFrsO   8
#define XbWDOb_GtNxtO   16
#define XbWDOb_GetAnO     32
#define XbWDOb_GtLstO   64
#define XbWDOb_GtAnfO 128

#define XbWDMf_NoPara 50
#define XbWDMf_StrToL 51


#define XbWDMf_MaxPar 100                /* Maximale Zahl Befehlsparameter */

#define  XbWDMf_IntPar 0x10
#define  XbWDMf_StrPar 0x20
#define   XbWDMf_VPPar 0x30
#define   XbWDMf_VIPar 0x40
#define   XbWDMf_VLPar 0x50
#define XbWDMf_NULPar 0x60
#define  XbWDMf_AnzPar 0x70
#define  XbWDMf_DblPar 0x80

#define XbWDMf_SP_R(no,sstr,func) case no:\
  if (tfun) {XbWVMf_com[no]=sstr;}\
  else {return(func(&XbWVMf_P));};\
  break;

#define XbWDMf_ST_R(no,sstr,func) case no:\
  if (tfun) {XbWVMf_com[no]=sstr;}\
  else {return(func(&XbWVMf_P,&XbWVMf_T));};\
  break;

#define XbWDMf_ST_E(no,sstr,func) case no:\
  if (tfun) {XbWVMf_com[no]=sstr;}\
  else {func(&XbWVMf_P,&XbWVMf_T);};\
  break;

#define XbWDMf_SP__(no,sstr,func) case no:\
  if (tfun) {XbWVMf_com[no]=sstr;}\
  else {func(&XbWVMf_P); return(0); };\
  break;

#define XbWDMf_S_ER(no,sstr,func) case no:\
  if (tfun) {XbWVMf_com[no]=sstr;}\
  else {return(func());};\
  break;

#define XbWDMf_S_E_(no,sstr,func) case no:\
  if (tfun) {XbWVMf_com[no]=sstr;}\
  else {func(); return(0); };\
  break;

#define XbWDMf_GtLine                         \
  if (r_akt == r_len) {                  \
    if (MetaFile != NULL){                       \
      r_len = fread(rohzeile,1,256,MetaFile);   r_akt = 0;\
      }                                  \
    else {                               \
      XbWVMf_eof = 1;              \
      r_akt = 0;                         \
      r_len = 0;                         \
      };                                 \
    };                                   \
  if (!r_len){                           \
    XbWVMf_eof = 1;                \
    };                                   \

#define XbWDMf_IgnLin                       \
  {                                      \
  int mm=0;                              \
  while(!mm)                             \
    {                                    \
    switch (rohzeile[r_akt])             \
      {                                  \
      case  0 : mm++; break;             \
      case 10 : mm++; break;             \
      case 13 : mm++; break;             \
      default : r_akt++; XbWDMf_GtLine; break;\
      };                                 \
    };                                   \
  }

#define XbWDMf_SekEOL                         \
  {                                      \
  int mm=0;                              \
  while(!mm)                             \
    {                                    \
    switch (rohzeile[r_akt])             \
      {                                  \
      case  0 : mm++; break;             \
      case 10 : mm++; break;             \
      case 13 : mm++; break;             \
      case ';': StarteProcedure = 1; r_akt++;XbWDMf_GtLine;break;\
      case '|': mm++; break;             \
      case ',': mm++; break;             \
      case ' ': mm++; break;             \
      case '\t': mm++; break;             \
      default : r_akt++; XbWDMf_GtLine; break;\
      };                                 \
    };                                   \
  r_akt++;XbWDMf_GtLine;                      \
  }

#define XbWDMf_CpyCom(zz)                 \
  {                                      \
  int ii=0;                              \
  int mm=0;                              \
  while(!mm)                             \
    {                                    \
    switch (rohzeile[r_akt])             \
      {                                  \
      case  0 : mm++; zz[ii]=0;break;    \
      case ';':                          \
        StarteProcedure = 1;             \
        mm++; zz[ii]=0; break;           \
      case '{': mm++; zz[ii]=0; break;   \
      default :                          \
        zz[ii] = rohzeile[r_akt];ii++;   \
        r_akt++; XbWDMf_GtLine; break;        \
      };                                 \
    };                                   \
  }

#define XbWDMf_CpyLab(zz)                   \
  {                                      \
  int ii=0;                              \
  int mm=0;                              \
  while(!mm)                             \
    {                                    \
    switch (rohzeile[r_akt])             \
      {                                  \
      case  0 : zz[ii]=0; mm++; break;   \
      case '!':                          \
        mm++; zz[ii]=0; break;           \
      default :                          \
        zz[ii] = rohzeile[r_akt];ii++;   \
        r_akt++; XbWDMf_GtLine; break;        \
      };                                 \
    };                                   \
  }


#define XbWDMf_MaxCmd 88

#define XbWDMf_BfStrL 100

#define XbWDEd_EndItm 0
#define XbWDEd_GoRigt 1
#define XbWDEd_GoDown 2

#define XbWDEd_UnLine 1
#define XbWDEd_VertLn 2

#define XbWDTb_MxVwPrt 30

#define XbWDMx_OpnErr         10001
#define XbWDMx_EofGrp 10002
#define XbWDMx_RIntEg        10003
#define XbWDMx_RDblEg        10004
#define XbWDMx_RStrEg        10005
#define XbWDMx_RIFnoI         10006
#define XbWDMx_RDFnoD         10007
#define XbWDMx_RSFnoS         10008
#define XbWDMx_EndOfF                   10009
#define XbWDMx_DGrpNF        10010
#define XbWDMx_MissRP     10011
#define XbWDMx_NoApnd    10012
#define XbWDMx_GrpNtF     10013

#define XbWDMx_RDok  0
#define XbWDMx_RFok  0
#define XbWDMx_WFok  0
#define XbWDMx_RGok 0


#define XbWDMx_ReadMF   0
#define XbWDMx_WriteMF  1
#define XbWDMx_AppendMF 2

#define XbWDIf_InitXMS(task) int  XbWDIf_StrtApp(int argc, char *argv[]){\
  _ovrbuffer = 0x1200;\
  _OvrInitExt(0,350000L);\
  return(task(argc,argv));\
  };\

#define XbWDIf_InitStd(task)\
  int  XbWDIf_StrtApp(int argc, char *argv[]){\
  return( task(argc,argv));\
  };\

#define XbWDTb_SetPara(anz,p1,p2,p3,p4,p5) \
  vp[0] = ((void *)anz);\
  vp[1] = (void*)(p1); \
  vp[2] = (void*)(p2); \
  vp[3] = (void*)(p3); \
  vp[4] = (void*)(p4); \
  vp[5] = (void*)(p5); \



#define XbWDDb_C_PtrToDbI(pp,AP) (XbWDDb_DbIPtr)( (char *)(pp)- (char *)(AP) )

/* ======================================================================= */

typedef
  int boolean;

typedef struct {
  int XA,YA,XB,YB;
#ifdef XbW_SYSDEF_GNU_VERSION
  GrTextOption top;
  MouseEvent kbd_mev;
#endif
#ifdef XbW_SYSDEF_X11_VERSION
  KeySym keysym;
  char key[257];
  Display *dpy;
  Window window;
  GC gc;
  Screen *screen;
  Font font;
  long black,
       blue,
       green,
       cyan,
       red,
       magenta,
       brown,
       lgray,
       dgray,
       lblue,
       lgreen,
       lred,
       lmagenta,
       lcyan,
       yellow,
       white;
#endif
  int is_a_key_waiting;
  } XbWDSy_XbWContxt;

#ifdef XbW_SYSDEF_USE_LARGDBK
typedef struct {
  XbWDDb_DbITyp tp;      /* string-typ                       */
  unsigned char len;
  char nmi[1];    /* Name UND INHALT des string       */
  } XbWDDb_DbIStr;
typedef struct {
  XbWDDb_DbITyp tp;      /* Typ des pointers                 */
  XbWDDb_DbIPtr inh;     /* Pointer auf ein Item (vorwaerts) */
  char nm[1];     /* Name des pointers (laenge im typ)*/
  } XbWDDb_DbINPtr;
typedef struct {
  XbWDDb_DbITyp tp;     /* Typ des doubles                  */
  double inh;
  char nm[1];    /* Name des double (laenge im typ) */
  } XbWDDb_DbIDbl;
typedef struct {
  XbWDDb_DbITyp tp;     /* Typ des integer                  */
  int inh;
  char nm[1];    /* Name des integer (laenge im typ) */
  } XbWDDb_DbIInt;
typedef struct {
  XbWDDb_DbITyp tp;      /* Typ des pointers                  */
  XbWDDb_DbIPtr inh;     /* Pointer auf ein Item (rueckwaerts)*/
  char nm[1];     /* Name (laenge im typ)              */
  } XbWDDb_DbIIPtr;
typedef struct {
  XbWDDb_DbITyp tp;      /* Typ des pointers                 */
  XbWDDb_DbIPtr inh;     /* Pointer auf ein Item (vorwaerts) */
  char nm[1];     /* Name des pointers (laenge im typ)*/
  } XbWDDb_DbIFPtr;
typedef struct {
  XbWDDb_DbITyp tp;      /* Typ des pointers                 */
  XbWDDb_DbIPtr inh;     /* Pointer auf den Gruppenanfang    */
  char nm[1];     /* Name des pointers (laenge im Typ)*/
  } XbWDDb_DbIGPtr;
typedef struct {
  XbWDDb_DbITyp tp;     /* Typ des items                    */
  } XbWDDb_DbIVar;
#else
typedef struct {
  XbWDDb_DbITyp tp;      /* string-typ                       */
  unsigned char len;
  char nmi[1];    /* Name UND INHALT des string       */
  } XbWDDb_DbIStr;
typedef struct {
  XbWDDb_DbITyp tp;      /* Typ des pointers                 */
  XbWDDb_DbIPtr inh;     /* Pointer auf ein Item (vorwaerts) */
  char nm[1];     /* Name des pointers (laenge im typ)*/
  } XbWDDb_DbINPtr;
typedef struct {
  XbWDDb_DbITyp tp;     /* Typ des doubles                  */
  double inh;
  char nm[1];    /* Name des double (laenge im typ) */
  } XbWDDb_DbIDbl;
typedef struct {
  XbWDDb_DbITyp tp;     /* Typ des integer                  */
  int inh;
  char nm[1];    /* Name des integer (laenge im typ) */
  } XbWDDb_DbIInt;
typedef struct {
  XbWDDb_DbITyp tp;      /* Typ des pointers                  */
  XbWDDb_DbIPtr inh;     /* Pointer auf ein Item (rueckwaerts)*/
  char nm[1];     /* Name (laenge im typ)              */
  } XbWDDb_DbIIPtr;
typedef struct {
  XbWDDb_DbITyp tp;      /* Typ des pointers                 */
  XbWDDb_DbIPtr inh;     /* Pointer auf ein Item (vorwaerts) */
  char nm[1];     /* Name des pointers (laenge im typ)*/
  } XbWDDb_DbIFPtr;
typedef struct {
  XbWDDb_DbITyp tp;      /* Typ des pointers                 */
  XbWDDb_DbIPtr inh;     /* Pointer auf den Gruppenanfang    */
  char nm[1];     /* Name des pointers (laenge im Typ)*/
  } XbWDDb_DbIGPtr;
typedef struct {
  XbWDDb_DbITyp tp;     /* Typ des items                    */
  } XbWDDb_DbIVar;
#endif


typedef struct {
  void  *anz;
  char  *nm;
  void  *inh;
  } XbWDDb_AppCStr;
typedef struct {
  void  *anz;
  char  *nm;
  void  *len;      /* LAENGE fuer Strings                       */
  void  *inh;
  } XbWDDb_AppStr;
typedef struct {
  void  *anz;         /* Integer: Anzahl Parameter                     */
  char  *nm;
  void  *inh;
  } XbWDDb_AppInt;
typedef struct {
  void  *anz;         /* Integer: Anzahl Parameter                     */
  char  *nm;
  char  *inh;
  } XbWDDb_AppDBl;
typedef struct {
  void  *anz;         /* Integer: Anzahl Parameter                     */
  char  *nm;
  char  *inh;
  } XbWDDb_AppIPtr;
typedef struct {
  void  *anz;         /* Integer: Anzahl Parameter                     */
  char  *nm;
  char  *inh;
  } XbWDDb_AppNPtr;
typedef struct {
  void  *anz;         /* Integer: Anzahl Parameter                     */
  char  *lnm; /* Liste */
  char  *gnm; /* Gruppe, an die angehaengt wird */
  } XbWDDb_AppFPtr;
typedef struct {
  void  *anz;         /* Integer: Anzahl Parameter                     */
  char  *typstr;
  char  *name;
  void  *laenge;      /* Fuer Strings                                  */
  void  *inhalt;
  } XbWDDb_AppVar;

typedef struct {
 void
  *T_ITM_END;                 /* Aktuelles Ende derselben                  */
 XbWDDb_DbIPtr
  ITM_MAX;                    /* Maximale Groesse derselben                */
 XbWDDb_DbIVar   *T_ITM_PRJ;
 XbWDDb_DbIStr   *T_ITM_GRP;     /* Zeiger auf den Namen der aktuellen Gruppe */
 XbWDDb_DbIStr   *T_ITM_SYS;     /* Zeiger auf den Namen des ersten Projektes */
 char    XbWinPath[60];
 char    XbAppPath[60];
 } XbWDDb_Sys;

typedef struct{
  char name[40];         /* Name des Projektes */
  char reserviert[200];
  long tab_size;
  char akt_wdw[40];
  XbWDDb_DbIPtr akt_projekt;
  XbWDDb_DbIPtr akt_sys;
  XbWDDb_DbIPtr akt_group;
  XbWDDb_DbIPtr akt_ende;
  XbWDDb_DbIPtr tab_start;
  } XbWDDb_Header;

typedef struct {
  char   *nm;
  XbWDDb_DbIPtr *obj;                /* Zeiger auf das erste Objekt dieses Windows*/
  int  *tp;             /* Typ                                       */
  int  *layer;          /* Lage auf dem schirm, z- Ebene             */
  int  *nx;
  int  *ny;             /* Nullpunkt auf dem schirm                  */
  int  *sx;
  int  *sy;             /* Aktuelle Schirmgr"o"se einschl. Rand      */
  int  *wov;            /* wenn von anderem Fenster "uberschrieben   */
  int  *icn;            /* wenn als icon dargestellt                 */
  int  *bkc;            /* Untergrundfarbe                           */
  int  *txc;            /* Farbe des Textes                          */
  int  *dfc;            /* helle Farbe des Rahmens                   */
  int  *bfc;            /* dunkle Farbe des Rahmens                  */
  int  *wfx;            /* Solange Window bearb.wird,nicht verlassen!*/
  int  *wfe;            /* Wenn editiert, wird WaitForMenuExit 1  */
  int  *bd;             /* Background Display                        */
  } XbWDDb_DbIWdw;

typedef struct {
  char   *onm;
  char   *odt;            /* Objekt-Display-Typ                        */
  char   *oet;            /* Objekt-Edit-Typ                           */
  int  *XA;
  int  *YA;
  int  *XB;
  int  *YB;             /* Lage auf dem Window                       */
  int  *bkc;            /* Untergrundfarbe                           */
  int  *txc;            /* Farbe des Textes                          */
  int  *dfc;            /* helle Farbe des Rahmens                   */
  int  *bfc;            /* dunkle Farbe des Rahmens                  */
  int  *dst;            /* Display-Status                            */
  int  *est;            /* Edit-Status                               */
  int  *dwd;            /* Draw Window nach edit                     */
  char   *wdw;            /* Zugeordnetes Window                       */
  XbWDDb_DbIVar  *chn;           /* Zeiger auf den Rest des Objektes          */
  XbWDDb_DbIPtr  *nxt;           /* Inhalt des Zeigers auf n�chstes Objekt    */
  } XbWDDb_DbIObj;

typedef
    enum {pfeil,kreuz,keine} XbWDMs_CurFrm;

typedef struct {
   void  *XbWVMf_P;
   int XbWVMf_T;
   char Str[XbWDMf_BfStrL];
   } XbWDMf_AktPar;


typedef enum{
  Vor,CursorUp,
  CursorDown,
  PageDown,PageUp,
  Weiter,EndInput,
  Egal
  } XbWDEd_NxtTyp;

typedef struct {
  int dy;
  char buf[65000l];
  } XbWDGr_VidFram;

typedef struct {char *typ; int anz;  void *data; char *name; } XbWDMx_GrpDscr;


typedef struct { int  *Grp[40];} XbWDIf_GlobDsc;



/* ======================================================================= */

int  XbWPSy_EXETaskStartHook(   char *TaskName, XbWDDb_DbIWdw  *TW,XbWDDb_DbIObj  *TO);
int  XbWPSy_DisplayObjectHook(char *ObjectTyp,XbWDDb_DbIWdw  *TW,XbWDDb_DbIObj  *TO);
int  XbWPSy_EditObjectHook(char *ObjectTyp,XbWDDb_DbIWdw  *TW,
          XbWDDb_DbIObj  *TO, int *todisp, int edit,
          int ObjMausXPos, int ObjMausYPos);
int  XbWPSy_MetaCommandHook(   char *Command,  XbWDDb_DbIWdw  *TW, void  *(*para)[], int (*t)[]);
int  XbWPSy_SystemManagerHook(XbWDDb_DbIWdw  *TW);

/* ======================================================================= */

extern XbWDIf_GlobDsc      XbWVIf_GlbDsc;
#ifndef VAX
extern unsigned            _ovrbuffer;
#endif
#ifdef XbW_SYSDEF_GNU_VERSION
extern long                XbWVSy_DlyLim;
#endif
extern XbWDSy_XbWContxt    XbWVSy_ConTxt;
extern char                XbWVSy_SysPath[60];
extern char                XbWVSy_AppPath[60];
extern char                XbWVSy_PrjPath[60];
extern int               XbWVWd_AClos;
extern int               XbWVWd_RedrawON;
extern char                XbWVTb_PTS[XbWDTb_PckTLen];
extern char                XbWVSy_DosCmd[265];
extern char                XbWVSy_MfName[265];
extern int               XbWVWd_OldMsg;
extern time_t              XbWVSy_Time;
extern XbWDDb_DbIVar  *XbWVDb_AkDbkEl;     /* Aktuelle Variable f�r XbWFDb_GetNum etc    */
extern XbWDDb_DbIVar  *XbWVDb_ActGrp1;     /* Akt. Var.; aber OHNE RECURSION         */
extern XbWDDb_DbIVar  *XbWVDb_ActGrp2;  /* Akt. Var. f�r XbWFDb_VarInh                */
extern int               XbWVDb_FndNum;
extern XbWDDb_Sys     *XbWVDb_DbkStrt;
extern XbWDDb_Sys     *XbWVDb_DbkStrtMem;
extern int               XbWVWd_Activ;
extern int               XbWVWd_Hgt;
extern int               XbWVWd_Wdt;
extern XbWDDb_DbIWdw       XbWVWd_W;    /* Aktives Display-Window */
extern XbWDDb_DbIObj       XbWVOb_O;    /* Aktives Objekt  */
extern int               XbWVWd_OldMsg;
extern int               XbWVGr_Black;
extern int               XbWVGr_Blue ;
extern int               XbWVGr_Green;
extern int               XbWVGr_Cyan ;
extern int               XbWVGr_Red  ;
extern int               XbWVGr_Magenta   ;
extern int               XbWVGr_Brown     ;
extern int               XbWVGr_LGray ;
extern int               XbWVGr_DGray  ;
extern int               XbWVGr_LBlue ;
extern int               XbWVGr_LGreen;
extern int               XbWVGr_LCyan ;
extern int               XbWVGr_LRed  ;
extern int               XbWVGr_LMagenta;
extern int               XbWVGr_Yellow;
extern int               XbWVGr_White ;
#ifndef XbW_SYSDEF_X11_VERSION
extern union REGS          XbWVMs_regs;
#endif
extern void far           *XbWVMs_bits ;
extern int               XbWVMs_axa;
extern int               XbWVMs_aya;
extern  boolean            XbWVMs_Rechts;
extern  boolean            XbWVMs_Links;
extern  boolean            XbWVMs_Rauf;
extern  boolean            XbWVMs_Runter;
extern  boolean            XbWVMs_Bewegt;
extern  boolean            XbWVMs_Button;
extern  boolean            XbWVMs_LButt;
extern  boolean            XbWVMs_RButt;
extern  boolean            XbWVMs_MButt;
extern  int              XbWVMs_XPos;
extern  int              XbWVMs_YPos;
extern  int              XbWVMs_cxa;
extern  int              XbWVMs_cya;
extern  int              XbWVMs_CX;
extern  int              XbWVMs_CY;
extern  XbWDMs_CurFrm      XbWVMs_CFrm;
extern  boolean            XbWVMs_CSet;
extern int               XbWVMs_XSense;
extern int               XbWVMs_YSense;
extern int               XbWVMs_Speed;
extern int               XbWVOb_MovOK;
extern XbWDDb_DbIVar  *XbWVOb_GOPlv;
extern XbWDDb_DbIVar  *XbWVOb_GOPao;
extern char               *XbWVOb_GOPnm;
extern char                XbWVOb_GTxt[60];
extern int               XbWVOb_X;
extern int               XbWVOb_Y;
extern int               XbWVOb_x;
extern int               XbWVOb_y;
extern int               XbWVOb_ox;
extern int               XbWVOb_oy;
extern int               XbWVOb_EdLvl;
extern fpos_t              XbWVOb_pos;
extern FILE               *XbWVOb_afil;
extern XbWDDb_DbIVar  *XbWVOb_mgr;
extern XbWDDb_DbIVar  *XbWVOb_mao;
extern char               *XbWVOb_agr;
extern char               *XbWVOb_aon;
extern int               XbWVMf_Cerr;
extern void           *XbWVMf_P[XbWDMf_MaxPar];
extern int               XbWVMf_C;
extern char                XbWVMf_gn[130];
extern char                XbWVMf_ln[130];
extern char                XbWVMf_nn[130];
extern char                XbWVMf_gn[130];
extern char                XbWVMf_ln[130];
extern char                XbWVMf_nn[130];
extern char                XbWVMf_jln[140];
extern int               XbWVMf_jtl;
extern int               XbWVMf_mlv;
extern int               XbWVIf_Debug;
extern char               *XbWVMf_com[XbWDMf_MaxCmd];
extern char               *XbWVMf_af;
extern int              *XbWVMf_az;
extern int               XbWVMf_dmf;
extern int               XbWVMf_prd;
extern int               XbWVMf_Cerr;
extern void           *XbWVMf_P[XbWDMf_MaxPar];
extern int               XbWVMf_T[XbWDMf_MaxPar];
extern char                XbWVMf_B[XbWDMf_MaxPar*XbWDMf_BfStrL];
extern char                XbWVMf_eof;
extern int               XbWVMf_C;
extern XbWDMf_AktPar ( *XbWVMf_aP)[];
extern int               XbWVMf_CErr;
extern XbWDEd_NxtTyp       XbWVEd_nxt;
extern int               XbWVEd_CrFrm;
extern int               XbWVEd_CrKey;
extern int               XbWVEd_CrFrm;
extern int               XbWVEd_CrKey;
extern XbWDEd_NxtTyp       XbWVEd_nxt;
extern boolean             XbWVEd_ins;
extern int               XbWVEd_xhp;
extern int               XbWVEd_yhp;            /* Position des Fragetextes               */
extern char                XbWVEd_hdr[35];               /* Fragetext                              */
extern int               XbWVEd_hcol;                   /* Farbe der Frage                        */
extern int               XbWVEd_xa;
extern int               XbWVEd_ya;        /* Linke obere Ecke des Editierfensters   */
extern int               XbWVEd_xb;
extern int               XbWVEd_yb;        /* Rechte Untere...                       */
extern char                XbWVEd_sst[257];              /* Zu gredierender String                 */
extern unsigned char       XbWVEd_scol;                /* Farbe desselben                        */
extern char                XbWVEd_zstr[255];             /* Der Puffer                             */
extern unsigned char       XbWVEd_zc;
extern unsigned char       XbWVEd_zf;    /* Ein Zeichen                            */
extern int               XbWVEd_c;
extern int               XbWVEd_send;
extern int               XbWVEd_crpos;
extern int               XbWVEd_cpos;                   /* Ein paar Zeiger                        */
extern int               XbWVEd_lcnt;                 /* Zeichenz"ahler                         */
extern int               XbWVEd_vpos;
extern int               XbWVEd_npos;     /* Noch mehr Zeiger                       */
extern int               XbWVEd_spos;
extern int               XbWVEd_mvport;
extern char                XbWVEd_coptxt[255];           /* Noch ein Puffer                        */
extern struct viewporttype XbWVTb_ViewPLst[XbWDTb_MxVwPrt];
extern int               XbWVTb_ViewPZ;
extern int               XbWVTb_VPX;
extern int               XbWVTb_VPY;
extern int               XbWVTb_VPx;
extern int               XbWVTb_VPy;
extern char               *XbWVWd_Name[XbWDWd_MaxWdw+1];
extern XbWDDb_DbIVar  *XbWVWd_Grp[XbWDWd_MaxWdw+1];
extern int               XbWVWd_MaxReg;
extern int               XbWVWd_FoundNo;
extern int               XbWVWd_DrawNr;
extern int               XbWVWd_RedrawON;
extern XbWDDb_DbIWdw       XbWVWd_LastDsp;
extern XbWDDb_DbIWdw       XbWVWd_W;           /* Aktives Display-Window */
extern int               XbWVWd_AClos;
extern time_t              XbWVWd_Time;
extern int           XbWVWd_ADspNr;
extern char                XbWVWd_CStr[100];
extern int               XbWVWd_CErr;
extern char               *XbWVMx_atxt;
extern char               *XbWVMx_btxt;
extern int               XbWVMx_cmd;
extern int               XbWVMx_p1;
extern int               XbWVMx_p2;
extern int               XbWVIDEO_XA;
extern int               XbWVIDEO_XB;
extern int               XbWVIDEO_YA;
extern int               XbWVIDEO_YB;
extern char                XbWVDb_AktNam[16];
extern long                XbWVDb_PrjSize;
extern XbWDDb_DbIVar  *XbWVDb_AktDObj;
extern XbWDDb_DbIVar  *XbWVDb_AktDKey;
extern int               XbWVDb_DbkStat;
extern int               XbWVDb_DbkFile;
extern int               XbWVDb_FndNum;
extern XbWDDb_Sys     *XbWVDb_DbkStrt;
extern XbWDDb_DbIVar  *XbWVDb_AkDbkEl;
extern XbWDDb_DbIVar  *XbWVDb_ActGrp1;
extern XbWDDb_DbIVar  *XbWVDb_ActGrp2;
extern char               *XbWVMf_com[];
extern char               *XbWVMf_LCmd;
extern time_t             XbWVSy_AltChkActTime;
extern char XbWVSy_ExecNameHook[60];
extern char XbWVMs_PtrHand[];
extern char XbWVMs_PtrArrow[];
extern char XbWVMs_PtrClock[];
extern char XbWVMs_PtrStop[];

#ifdef XbW_SYSDEF_GNU_VERSION
extern GrCursor *XbWVMs_PtrPtrClock;
extern GrCursor *XbWVMs_PtrPtrArrow;
extern GrCursor *XbWVMs_PtrPtrHand;
extern GrCursor *XbWVMs_PtrPtrStop;
extern GrCursor *XbWVMs_PtrActualPtr;
#endif
#ifdef XbW_SYSDEF_X11_VERSION
extern Cursor XbWVMs_PtrPtrClock;
extern Cursor XbWVMs_PtrPtrArrow;
extern Cursor XbWVMs_PtrPtrHand;
extern Cursor XbWVMs_PtrPtrStop;
extern Cursor XbWVMs_PtrActualPtr;
#endif
#ifdef XbW_SYSDEF_TC3_VERSION
extern void  *XbWVMs_PtrPtrClock;
extern void  *XbWVMs_PtrPtrArrow;
extern void  *XbWVMs_PtrPtrHand;
extern void  *XbWVMs_PtrPtrStop;
extern void  *XbWVMs_PtrActualPtr;
#endif

extern char *XbWVGr_ColorTexte[];
extern unsigned long int XbWVGr_ColorValues[64];

extern char XbWVSy_PrjName[];


#ifdef XbW_SYSDEF_X11_VERSION
extern int XbW_X11_ScreenWidth;
extern int  XbW_X11_ScreenHeight;
#endif



int    XbWApp_StartupApplication(int argc,char *argv[]);

extern char *XbWVSy_DebugLinePos;
extern char *XbWVSy_DebugLine;
extern char *XbWVSy_DebugCommand;



void  XbWSMs_DFramON(int xa,int ya,int xb,int yb,int col);
void  XbWSMs_FramON(int xa,int ya,int xb,int yb,int col);
void  XbWSGr_ResMode(void);
void  XbWSMs_DrInit(void);
void  *XbWSMs_SetStopCursor(void);
void  *XbWSSy_AlocMem(unsigned long a, unsigned long b);
void  XbWSWd_Resize(void  *(*p)[]);
void  XbWFSY_DoXFlush(void);
void  XbWSOS_Sound(int freq);
int  XbWFDb_CreateArray(void  *(*p)[], int (*t)[]);

char *strupr(char *sstr);
char *itoa(int nr, char *target, int radix);

 

#include "xf.h"

/*{{{F xf.h*/
/*:::F xf.h*/
/*}}}  */


/* ================= Ende von XBW.H ==================================== */


 
