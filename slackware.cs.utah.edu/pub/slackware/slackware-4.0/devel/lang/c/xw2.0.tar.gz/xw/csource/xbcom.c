
 
#include "xbw.h"


/* ================ Metafile-Interface ================================ */

char
  XbWVSy_SysPath[60];
int
  XbWVIDEO_XA,
  XbWVIDEO_XB,
  XbWVIDEO_YA,
  XbWVIDEO_YB;

/* ---------------- Interface ----------------------------------------- */


char *XbWFMx_MyStrUpr(char*sstr){
  /*{{{  */
  int ll;
  for (ll=0;sstr[ll]!=0;ll++){
    sstr[ll]&=0xDF;
    };
  return(sstr);
  };
  /*}}}  */
int XbWFMx_MyStrICmp(char *sstra,char*sstrb){
  /*{{{  */
  char sstr1[200],sstr2[200];
  strcpy(sstr1,sstra);
  strcpy(sstr2,sstrb);
  XbWFMx_MyStrUpr(sstr1);XbWFMx_MyStrUpr(sstr2);
  return(strcmp(sstr1,sstr2));
  };
  
  /*}}}  */

#define VarDataMaxNames 5

FILE
  *XbWFMx_MFXFile;
char
  XbWVMx_MFXFilName[80],
  XbWFMx_MFXFilezeile[255];
int
  XbWVMx_MFXFilZlNr,
  XbWVMx_AktName,
  XbWVMx_ReadErr = 0;
int
  XbWVIf_Debug = 0;

char
  XbWFMx_FStrNames[VarDataMaxNames][200];

char *XbWFMx_GetLine(void){
  XbWVMx_MFXFilZlNr++;
  return(fgets(XbWFMx_MFXFilezeile,253,XbWFMx_MFXFile));
  };

/*{{{  XbWFMx_RdSet(       ****/
int  XbWFMx_RdSet(
            char *filename,
            char *datensatzname){
  int ll;
  unsigned char ende;
  int gefund;
  char namestr[255];
  XbWVMx_MFXFilZlNr = 0;
  for (ll=0;ll<VarDataMaxNames;ll++){
    strcpy(XbWFMx_FStrNames[ll],"\0");
    };
  strcpy(XbWVMx_MFXFilName,filename);
  gefund = 0;
  XbWVMx_ReadErr = 0;
  if ((XbWFMx_MFXFile = XbWSSy_fopen(filename,"r")) == NULL) {
    return(XbWDMx_OpnErr);
    };
  ende = 0;
  while (!ende) {
    if (XbWFMx_GetLine() == NULL) {
      ende = 1;}
    else {
      if (strstr(XbWFMx_MFXFilezeile,"\\VarStructContents{") != NULL) {
        if (XbWFMx_GetLine() == NULL) {
          return(XbWDMx_EofGrp);
          }
        else {
          if (
                (strstr(XbWFMx_MFXFilezeile,"{") != NULL) &
                (strstr(XbWFMx_MFXFilezeile,"}") != NULL)
             ) {
            strncpy(namestr,strstr(XbWFMx_MFXFilezeile,"{")+1,250);
            strcpy(strstr(namestr,"}"),"\0");;
            if ((strcmp(namestr,datensatzname)==0)|(strcmp(datensatzname,"*")==0)) {
              ende = 1;
              gefund = 1;
              }
            else {
              if (XbWVMx_AktName < VarDataMaxNames) {
                strcpy(XbWFMx_FStrNames[XbWVMx_AktName],namestr);
                };
              XbWVMx_AktName++;
              };
            };
          };
        };
      };
    };
  if ((gefund == 0) & (XbWVIf_Debug == 1)) {
    printf("ERROR in VarDataGet...\n");
    printf("\nCannot find structure %s in file %s\n",datensatzname,filename);
    printf("the following structures could be found (the first five only):\n");
    for (ll=0;ll<5;ll++){
      printf("%s\n",XbWFMx_FStrNames[ll]);
      };
    printf("Sorry...\n");
    return(XbWDMx_DGrpNF);
    };
  return(XbWDMx_RGok);
  };
/*}}}  */
/*{{{  XbWFMx_GetInt(      ****/
int  XbWFMx_GetInt(int *variable){
  char sstr[255];
  XbWFMx_GetLine();
  while (*(char *)XbWFTb_PckTxt(XbWFMx_MFXFilezeile) == '%') {
    if (feof(XbWFMx_MFXFile)){ return(XbWDMx_EndOfF);};
    XbWFMx_GetLine();
    };
  if (*(char *)XbWFTb_PckTxt(XbWFMx_MFXFilezeile) != 'i') {
    if (strstr(XbWFMx_MFXFilezeile,"\\EndOfVarStructure;") != NULL) {
      if (XbWVIf_Debug == 1) {
        printf("ERROR in VarDataGet...\n");
        printf("Sorry, but I cannot find your integer because end of group\n");
        printf("actual File: %s\n",XbWVMx_MFXFilName);
        printf("actual line: %s\n",XbWFMx_MFXFilezeile);
        printf("    line no: %d\n",XbWVMx_MFXFilZlNr);
        };
      return(XbWDMx_RIntEg);
      }
    else {
      if (XbWVIf_Debug == 1) {
        printf("ERROR in VarDataGet...\n");
        printf("Sorry, but I cannot find your integer\n");
        printf("actual File: %s\n",XbWVMx_MFXFilName);
        printf("actual line: %s\n",XbWFMx_MFXFilezeile);
        printf("    line no: %d\n",XbWVMx_MFXFilZlNr);
        };
      return(XbWDMx_RIFnoI);
      };
    }
  else {
    strncpy(sstr,strstr(XbWFMx_MFXFilezeile,"i")+1,255);
    *(char *)strstr(sstr,",") = 0;
    *variable = atoi((char *)XbWFTb_PckTxt(sstr));
    return(XbWDMx_RDok);
    };
  };
/*}}}  */
/*{{{  XbWFMx_GetDbl(      ****/
int  XbWFMx_GetDbl(double *variable){
  char sstr[255];
  XbWFMx_GetLine();
  while (*(char *)XbWFTb_PckTxt(XbWFMx_MFXFilezeile) == '%') {
    if (feof(XbWFMx_MFXFile)){ return(XbWDMx_EndOfF);};
    XbWFMx_GetLine();
    };
  if (*((char *)XbWFTb_PckTxt(XbWFMx_MFXFilezeile)) != '{') {
    if (strstr(XbWFMx_MFXFilezeile,"\\EndOfVarStructure;") != NULL) {
      if (XbWVIf_Debug == 1) {
        printf("ERROR in VarDataGet...\n");
        printf("Sorry, but I cannot find your double because end of group\n");
        printf("actual File: %s\n",XbWVMx_MFXFilName);
        printf("actual line: %s\n",XbWFMx_MFXFilezeile);
        printf("    line no: %d\n",XbWVMx_MFXFilZlNr);
        };
      return(XbWDMx_RDblEg);
      }
    else {
      if (XbWVIf_Debug == 1) {
        printf("ERROR in VarDataGet...\n");
        printf("Sorry, but I cannot find your double\n");
        printf("actual File: %s\n",XbWVMx_MFXFilName);
        printf("actual line: %s\n",XbWFMx_MFXFilezeile);
        printf("    line no: %d\n",XbWVMx_MFXFilZlNr);
        };
      return(XbWDMx_RDFnoD);
      };
    }
  else {
    strncpy(sstr,strstr(XbWFMx_MFXFilezeile,"{")+1,255);
    if (strstr(sstr,"}") != NULL) {
      *(char *)strstr(sstr,"}") = 0;
      }
    else {return(XbWDMx_MissRP);};
    *variable = atof((char *)XbWFTb_PckTxt(sstr));
    return(XbWDMx_RDok);
    };
  };
/*}}}  */
/*{{{  XbWFMx_GetStr(      ****/
int  XbWFMx_GetStr(char *variable){
  char sstr[255];
  XbWFMx_GetLine();
  while (*(char *)XbWFTb_PckTxt(XbWFMx_MFXFilezeile) == '%') {
    if (feof(XbWFMx_MFXFile)){ return(XbWDMx_EndOfF);};
    XbWFMx_GetLine();
    };
  if (*((char *)XbWFTb_PckTxt(XbWFMx_MFXFilezeile)) != '{') {
    if (strstr(XbWFMx_MFXFilezeile,"\\EndOfVarStructure;") != NULL) {
      if (XbWVIf_Debug == 1) {
        printf("ERROR in VarDataGet...\n");
        printf("Sorry, but I cannot find your string because end of group\n");
        printf("actual File: %s\n",XbWVMx_MFXFilName);
        printf("actual line: %s\n",XbWFMx_MFXFilezeile);
        printf("    line no: %d\n",XbWVMx_MFXFilZlNr);
        };
      return(XbWDMx_RStrEg);
      }
    else {
      if (XbWVIf_Debug == 1) {
        printf("ERROR in VarDataGet...\n");
        printf("Sorry, but I cannot find your string\n");
        printf("actual File: %s\n",XbWVMx_MFXFilName);
        printf("actual line: %s\n",XbWFMx_MFXFilezeile);
        printf("    line no: %d\n",XbWVMx_MFXFilZlNr);
        };
      return(XbWDMx_RSFnoS);
      };
    }
  else {
    strncpy(sstr,strstr(XbWFMx_MFXFilezeile,"{")+1,253);
    sstr[253]=0;
    if (strstr(sstr,"}") != NULL) {
      *(char *)strstr(sstr,"}") = 0;
      }
    else {return(XbWDMx_MissRP);};
    strcpy(sstr,(char *)XbWFTb_PckTxt(sstr));
    strcpy(variable,sstr);
    return(XbWDMx_RDok);
    };
  };
/*}}}  */
/*{{{  XbWFMx_WrSet(       ****/
int  XbWFMx_WrSet(
  /*{{{  */
            char *filename,
            char *datensatzname,
            int mode){
  if (mode == 1) {
    XbWFMx_MFXFile = XbWSSy_fopen(filename,"at");
    if (XbWFMx_MFXFile == NULL) {
      printf("ERROR in XbWSSy_fopen(%s,%d)\n",filename,mode);
      return(XbWDMx_NoApnd);
      };
    }
  else {
  
    XbWFMx_MFXFile = XbWSSy_fopen(filename,"wt");
    if (XbWFMx_MFXFile == NULL) {
      printf("ERROR in XbWSSy_fopen(%s,%d)\n",filename,mode);
      return(XbWDMx_OpnErr);
      };
    };
  fputs("\\VarStructContents{\n",XbWFMx_MFXFile);
  fputs(" {",XbWFMx_MFXFile);
  fputs(datensatzname,XbWFMx_MFXFile);
  fputs("}};\n",XbWFMx_MFXFile);
  return(XbWDMx_WFok);
  };
  /*}}}  */
/*}}}  */
/*{{{  XbWFMx_PutInt(      ****/
void  XbWFMx_PutInt(int variable, char *com){
  fprintf(XbWFMx_MFXFile," i%d, %s\n",variable, com);};
/*}}}  */
/*{{{  XbWFMx_PutDbl(      ****/
void  XbWFMx_PutDbl(double variable, char *com){
  fprintf(XbWFMx_MFXFile," {%20.7f}, %s\n",variable, com);};
/*}}}  */
/*{{{  XbWFMx_PutStr(      ****/
void  XbWFMx_PutStr(char *variable, char *com){
  if (variable == NULL) {
    fprintf(XbWFMx_MFXFile," {(null)}, %s\n", com);
    }
  else {
    fprintf(XbWFMx_MFXFile," {%s}, %s\n",variable, com);
    };
  };
/*}}}  */
/*{{{  XbWFMx_EndSet(      ****/
void  XbWFMx_EndSet(void){
  fputs("\\EndOfVarStructure;\n",XbWFMx_MFXFile);};
/*}}}  */
/*{{{  XbWFMx_Close(       ****/
void  XbWFMx_Close(void){
  fclose(XbWFMx_MFXFile);};
/*}}}  */

