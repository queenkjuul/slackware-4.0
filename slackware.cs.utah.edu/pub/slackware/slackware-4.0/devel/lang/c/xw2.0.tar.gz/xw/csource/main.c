
int  main(int argc,char *argv[]){
 
  XbWSSy_ResetWM(argc,argv);
 
  return(0);
  };
