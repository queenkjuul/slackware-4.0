
/* ================= XBMFX.H ============================================= */
 
int XbWMFX_ReadSet(  char *filename, char *dataset);
int XbWMFX_GetInteger( int *variable);
int XbWMFX_GetShort( short *variable);
int XbWMFX_GetDouble( double *variable);
int XbWMFX_GetString( char *variable);
int XbWMFX_WriteSet(  char *filename, char *dataset, char *mode );
void XbWMFX_PutShort(short *variable,  char *commment);
void XbWMFX_PutInteger(int *variable,  char *commment);
void XbWMFX_PutDouble(double *variable,  char *comment);
void XbWMFX_PutString(char *variable, char *comment);
void XbWMFX_WriteEnd(void);
void XbWMFX_CloseSet( void);

/* ================= End of XBMFX.H ====================================== */



