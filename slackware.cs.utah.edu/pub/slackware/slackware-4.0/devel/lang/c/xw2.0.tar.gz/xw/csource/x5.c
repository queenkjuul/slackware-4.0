 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*                                                                           */
/*   Modul X5.C                                                              */
/*                                                                           */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



/* Header--------------------------------------------------------------------*/

#include "xbw.h"

/*  ---------------------Compiler-Modelle-----------------------------*/
                      /* ---............Nicht m�glich  */
                      /* !!!............Noch zu machen */
                      /* ???............unklar         */
                      /* TC3............Turbo-C Version*/
                      /*     GNU........32-Bit Version */
                      /*         X11....X-Window       */

/*{{{  XbWFOb_GiveInfo(*/
void  XbWFOb_GiveInfo(
    XbWDDb_DbIWdw  *WI, int mausxa, int mausya, int smode){
  int mxa,mya;
  XbWDDb_DbIObj MOB;
  int aToEdit,vToEdit,win_found;
  char *inf_name,*obj_name;char afname[32],vfname[32];
  int sr_mod = XbWDOb_GtMinP | XbWDOb_GtFrsO;

  mxa = mausxa- *WI->nx; mya = mausya- *WI->ny;
  MOB.onm = NULL;

  smode = 0;
  aToEdit = vToEdit = smode;


  win_found = 0;
  obj_name = NULL;
  while ((obj_name = (char*)XbWFOb_GetPar(
      &XbWVWd_W,&MOB,obj_name,sr_mod)) != NULL){
    sr_mod = XbWDOb_GtMinP | XbWDOb_GtNxtO;
    if (MOB.onm != NULL) {
      if (XbWFTb_CmpStr((char*)WI->nm,(char*)MOB.wdw) != 0) {
        if (win_found){goto weiter;};
        }
      else {
        win_found = 1;
        if ( (mxa>= *MOB.XA)&(mya>= *MOB.YA)&(mxa<= *MOB.XB)&(mya<= *MOB.YB)){
          strcpy(afname,(char*)MOB.onm);
          aToEdit = 1;
        };};
      };
    };
  weiter:;

  if (!(aToEdit+vToEdit)){ return;};

  obj_name = NULL;
  if (aToEdit){
    strcpy(vfname,afname);
    };



  {
    XbWDDb_DbIVar  *inf_var;
    if ((inf_var = XbWFDb_FindGrp("OBJ",vfname)) == NULL){ return; };
    if ((obj_name = (char*)XbWFDb_VarInh(inf_var,XbWDDb_Str,"i",1)) == NULL){
      strcpy(obj_name,"?");
      };
    if ((inf_var = XbWFDb_FindGrp("WDW",(char*)XbWVWd_W.nm)) == NULL){
      return;
      };

    if ((inf_name = (char*)XbWFDb_VarInh(inf_var,XbWDDb_Str,"inf",1)) == NULL){
      return;
      };
    };


  {
    FILE *ifp;
    char aln[200];
    char sstr[80];
    if ((ifp = XbWSSy_fopen(inf_name,"rt") ) != NULL) {
      aln[0] = 0;
      sprintf(sstr,"%s:%s",(char*)XbWVWd_W.nm,vfname);
      while ( (strstr(aln,sstr) == NULL) & (!feof(ifp)) ) { fgets(aln,199,ifp); };
      while ( (aln[0] != ':') & (!feof(ifp)) ) { fgets(aln,199,ifp); };
      if (!feof(ifp)) {
        switch (obj_name[0]) {
          case '?': case ' ': case  0 :
                    if (strchr(aln,'F') != NULL) { goto ganzes_fenster_ausgeben; };
                    goto nur_zeile_ausgeben;
          case 'L': nur_zeile_ausgeben:;
                    fgets(aln,199,ifp);
                    if (strchr(aln,13) != NULL) { strcpy(strchr(aln,13),"\0"); };
                    if (strchr(aln,10) != NULL) { strcpy(strchr(aln,10),"\0"); };
                    XbWFTb_Message(aln);
                    fclose(ifp);
                    return;

          case 'F': ganzes_fenster_ausgeben:;
                    fgets(aln,199,ifp);
                    XbWFTb_Message("Waiting. Press any key to continue...");
                    XbWFGr_PushPort(); XbWFGr_MaxPort();
                    XbWSGr_TLBox(30,30,610,450,NULL,XbWVGr_Cyan,0,XbWVGr_Cyan);
                    {
                      int ii;
                      for (ii=0; ii<50; ii++) {
                        fgets(aln,199,ifp);
                        if (strchr(aln,13) != NULL) { strcpy(strchr(aln,13),"\0"); };
                        if (strchr(aln,10) != NULL) { strcpy(strchr(aln,10),"\0"); };
                        if (aln[0] == ':') {
                          XbWFGr_PopPort(); XbWFGr_ResPort();
                          goto warte_auf_taste;
                          };
                        XbWSGr_TLBox(35,35+(ii)*(XbWFGr_THeight()+3),0,0,
                          aln,XbWVGr_Cyan,XbWVGr_White,XbWVGr_Cyan);
                        };
                      XbWFGr_PopPort(); XbWFGr_ResPort();
                      warte_auf_taste:;
                      fclose(ifp);
                      while (XbWSMs_IsAKey(0) == 0) {
                        if (XbWVMs_Button) {
                          XbWFWd_DrawAll();
                          return; };
                        };
                      XbWFWd_DrawAll();
                      return;
                      };
          };
        }
      else {
        XbWFTb_Message("Sorry, no object-info found.");
        };
      fclose(ifp);
      }
    else {
      XbWFTb_Message("Sorry, no info-file defined.");
      };
    };
  };
/*}}}  */
/*{{{  XbWFMf_StrtHookCmd(*/
int  XbWFMf_StrtHookCmd(void  *(*p)[], int(*t)[]){
  return(XbWPSy_MetaCommandHook(XbWVSy_ExecNameHook, &XbWVWd_W, p, t));
  };
/*}}}  */
/*{{{  XbWFTb_MouseWarp(*/
int  XbWFTb_MouseWarp(void  *(*p)[], int(*t)[]){
  int xa=0,ya=0;
  if ((int)(*p)[0] < 1 ) {
    XbWSMs_Warp(*XbWVWd_W.nx+(*XbWVWd_W.sx)/2,*XbWVWd_W.ny+(*XbWVWd_W.sy)/2);
    return(0);
    };
  if ((int)(*p)[0] > 2 ) {
    switch( (int)(*t)[1] ) {
      case XbWDMf_IntPar:
        xa = (int)(*p)[1];
        break;
      case XbWDMf_VLPar:
        {
          XbWDDb_DbIVar  *QQ;
          QQ = (XbWDDb_DbIVar  *)(*p)[1];
          if (QQ == NULL) { return(1); };
          xa = (int)XbWFDb_GetNum(QQ,NULL,1);
          };
        break;
      };
    switch( (int)(*t)[2] ) {
      case XbWDMf_IntPar:
        ya = (int)(*p)[2];
        break;
      case XbWDMf_VLPar:
        {
          XbWDDb_DbIVar  *QQ;
          QQ = (XbWDDb_DbIVar  *)(*p)[2];
          if (QQ == NULL) { return(1); };
          ya = (int)XbWFDb_GetNum(QQ,NULL,2);
          };
        break;
      };
    XbWSMs_Warp(xa,ya);
    return(0);
    };
  return(1);
  };
/*}}}  */

/*{{{  XbWFDb_LoadFont(               X11    Wechsle Verzeichnis*/
int  XbWFDb_LoadFont(void  *(*p)[],int (*t)[]){
  char fontname[200];
 
  strcpy(fontname,"");
  if ((int)(*p)[0] < 1 ) {return(XbWDMf_NoPara);};
  switch( (int)(*t)[1] ) {
    case XbWDMf_StrPar:
      strcpy(fontname,(char*)(XbWFTb_PckTxt((char*)(*p)[1])));
      break;
    case XbWDMf_VLPar:
      {
        XbWDDb_DbIVar  *QQ;
        char *fsp;
        QQ = (XbWDDb_DbIVar  *)(*p)[1];
        if (QQ == NULL) { return(1); };
        fsp = (char*)XbWFDb_VarInh(QQ,XbWDDb_Str,NULL,1);
        if (fsp != NULL) {
          strcpy(fontname,(char*)XbWFTb_PckTxt(fsp));
          };
        };
      break;
    };
 
  XbWSSy_LoadFont(fontname);
  return(0);
  };
/*}}}  */
 
/*{{{  XbWFMf_ExComand(    ***   Haupt-Routine zum starten von Kommandos*/
int  XbWFMf_ExComand(int no, int tfun){
  switch (no) {
    XbWDMf_ST_R( 0,"x",           XbWFMf_StrtHookCmd);
    XbWDMf_ST_R( 1,"s",           XbWFDb_AppStr);
    XbWDMf_ST_R( 2,"c",           XbWFDb_AppCSt);
    XbWDMf_ST_R( 3,"i",           XbWFDb_AppInt);
    XbWDMf_SP_R( 4,"d",           XbWFDb_AppDbl);
    XbWDMf_ST_R( 5,"pn",          XbWFDb_AppNPtr);
    XbWDMf_ST_R( 6,"eg",          XbWFDb_AppGPtr);
    XbWDMf_ST_R( 7,"o",           XbWFDb_AppObj);
    XbWDMf_ST_R( 8,"bg",          XbWFDb_AppBg);
    XbWDMf_ST_R( 9,"cn",          XbWFDb_AppChn);
    XbWDMf_ST_R(10,"tk",          XbWFDb_AppTsk);
    XbWDMf_ST_R(11,"ff",          XbWFDb_AppFloat);
    XbWDMf_ST_R(12,"lt",          XbWFDb_AppLight);
    XbWDMf_ST_R(13,"ng",          XbWFDb_NewGrp);
    XbWDMf_ST_R(14,"NewProject",  XbWFDb_MarkPrj);
    XbWDMf_SP_R(15,"NewGroup",    XbWFDb_MarlGrp);
    XbWDMf_SP_R(16,"AppGroup",    XbWFDb_AppFPtr);
    XbWDMf_S_E_(17,"End",         XbWFMf_EndOfMta);
    XbWDMf_S_E_(18,"SystemTask",  XbWSOS_SpwnShel);
    XbWDMf_S_E_(19,"HighBeep",    XbWFTb_HBeep);
    XbWDMf_S_E_(20,"LowBeep",     XbWFTb_LBeep);
    XbWDMf_S_E_(21,"MouseButton", XbWSMs_WButtUpDn);
    XbWDMf_SP_R(22,"ListSystem",  XbWFDb_DbgSys);
    XbWDMf_ST_R(23,"WriteFile",   XbWFDb_WrTable);
    XbWDMf_ST_R(24,"ReadFile",    XbWFDb_RdTable);
    XbWDMf_SP_R(25,"SystemUp",       XbWFDb_CreaSys);
    XbWDMf_S_ER(26,"SystemDn",       XbWFDb_CloseSys);
    XbWDMf_S_E_(27,"DrawAllWdw",  XbWFWd_DrawAll);
    XbWDMf_SP__(28,"IconizeWdw",  XbWFWd_Iconize);
    XbWDMf_S_E_(29,"IconAllWdw",  XbWFWd_IconAll);
    XbWDMf_SP_R(30,"SelectWdw",   XbWFWd_Select);
    XbWDMf_S_E_(31,"DrawWdw",     XbWFWd_DrawP);
    XbWDMf_SP__(32,"SetVirtPort", XbWFWd_SetPort);
    XbWDMf_S_E_(33,"SelOtherWin", XbWFWd_SlctOther);
    XbWDMf_S_E_(34,"MenuLockON",  XbWFWd_LockON);
    XbWDMf_S_E_(35,"MenuEditON",  XbWFWd_LockEdit);
    XbWDMf_S_E_(36,"MenuLockOFF", XbWFWd_LockOFF);
    XbWDMf_S_E_(37,"WdwManager",  XbWFWd_WManager); /* obsolete! */
    XbWDMf_S_E_(38,"SystemStop",  XbWFSy_SysStop);
    XbWDMf_SP_R(39,"*=",          XbWFDb_LinkDbI);
    XbWDMf_S_E_(40,"DebugON",     XbWFMf_DebugON);
    XbWDMf_SP_R(41,"sprintf",     XbWFTb_StrExpand);
    XbWDMf_ST_R(42,":=",          XbWFTb_NumVal);
    XbWDMf_ST_R(43,"MFXGroup",    XbWFMx_RWGroup);
    XbWDMf_SP__(44,"PopUpWdw",    XbWFWd_PopUp);
    XbWDMf_SP_R(45,"EditObj",     XbWFOb_EditOnly);
    XbWDMf_SP_R(46,"DispObj",     XbWFOb_DispOnly);
    XbWDMf_SP__(47,"PopUpBox",    XbWFTb_PopUpBox);
    XbWDMf_SP__(48,"Message",     XbWFTb_PutMessage);
    XbWDMf_SP__(49,"Alarm",       XbWFTb_PutAlarm);
    XbWDMf_SP_R(50,"FFileNames",  XbWSOS_FilDir);
    XbWDMf_SP_R(51,"Unlink",      XbWFTb_Unlink);
    XbWDMf_SP_R(52,"Special",     XbWFTb_DoSpecialCommand);
    XbWDMf_ST_R(53,"if",          XbWFTb_Case);
    XbWDMf_SP__(54,"Error",       XbWFTb_PutError);
    XbWDMf_SP_R(55,"AnswPReq",    XbWFTb_AnswerPopUpReq);
    XbWDMf_ST_R(56,"PopUpMSG",    XbWSPu_Msg);
    XbWDMf_ST_R(57,"PopUpDIR",    XbWSPu_Dir);
    XbWDMf_ST_R(58,"SpawnCTask",  XbWSOS_SpwnStd);
    XbWDMf_ST_R(59,"SpawnPTask",  XbWFTb_SpwnTskClrScr);
    XbWDMf_ST_R(60,"SpawnTTask",  XbWFTb_SpwnTskTxtMod);
    XbWDMf_ST_R(61,"GetWGrp",     XbWFDb_StorGrpn);
    XbWDMf_ST_R(62,"MoveObjToWdw",XbWFOb_MovToWdw);
    XbWDMf_S_E_(63,"DebugMFXON",  XbWFMx_DbgON);
    XbWDMf_SP__(64,"ResizeWdw",   XbWSWd_Resize);
    XbWDMf_S_E_(65,"MoveWdw",     XbWSWd_Move);
    XbWDMf_ST_R(66,"PopEditDIR",  XbWSPu_DirEd);
    XbWDMf_ST_R(67,"PackString",  XbWFTb_PackStr);
    XbWDMf_S_E_(68,"DebugMtaON",  XbWFTb_DbgMta);
    XbWDMf_S_E_(69,"AutoCloseON", XbWFTb_AClosON);
    XbWDMf_S_E_(70,"AutoCloseOFF",XbWFTb_AClosOFF);
    XbWDMf_S_E_(71,"RedrawON",    XbWFTb_RedrawON);
    XbWDMf_S_E_(72,"RedrawOFF",   XbWFTb_RedrawOFF);
    XbWDMf_S_E_(73,"ClrScr",      XbWFTb_ClrScr);
    XbWDMf_SP_R(74,"cmd",         XbWFDb_AppCmd);
    XbWDMf_ST_R(75,"MouseWarp",   XbWFTb_MouseWarp);
    XbWDMf_ST_R(76,"SelectPrj",   XbWFDb_SetProject);
    XbWDMf_S_E_(77,"XFlush",      XbWFSY_DoXFlush);
    XbWDMf_ST_R(78,"PrjName",     XbWFDb_PrjName);
    XbWDMf_ST_R(79,"ChDir",       XbWFSy_ChDir);
    XbWDMf_ST_R(80,"ObjLoadIcon", XbWSSy_ObjLoadIcon);
    XbWDMf_ST_R(81,"Array",       XbWFDb_CreateArray);
    XbWDMf_ST_R(82,"LoadFont",    XbWFDb_LoadFont);
    XbWDMf_ST_R(83,"RootWindow",  XbWSSy_RootWindow);
    XbWDMf_ST_R(84,"EditFile",    XbWFDb_OpenSys);
    XbWDMf_ST_R(85,"wdw",         XbWFDb_AppWdw);
 
    default:
      switch(tfun) {
        case 1: XbWVMf_com[no] = "\0"; break;
        case 0: return(0);
        };
    };
  return(0);
  };
/*}}}  */
/*{{{  XbWFMf_GtComNo(     ***   Unterroutine zum Metafile-Interpreter*/
int  XbWFMf_GtComNo(char *sstr){
  int ii;
  if (sstr[0] == '@'){
    strcpy(XbWVSy_ExecNameHook,sstr);
    return(0);
    };
  for (ii=1;ii < XbWDMf_MaxCmd;ii++){
    if ( *((short*)XbWVMf_com[ii]) == *((short*)sstr)) {
      if (strcmp(XbWVMf_com[ii],sstr) ==0){
        return(ii);
        };
      };
    };
  {
    char pstr[200];
    sprintf(pstr,"Command not found: %s",sstr);
    XbWSPu_Alarm(pstr);
    };
  return(-1);
  };
/*}}}  */
/*{{{  XbWFMf_initMta(     ***   Interpreter initialisieren*/
void  XbWFMf_initMta(void){
  int ii;
  XbWVMf_eof = 0;
  for (ii = 1; ii < XbWDMf_MaxCmd; ii++){
    XbWFMf_ExComand(ii,1);
    };
  };
/*}}}  */

/*{{{  XbWFOj_Dp_M(        ***   Display fuer MFX-Objekt*/
int  XbWFOj_Dp_M(XbWDDb_DbIObj  *TOB){
  XbWFOj_DpColButt(TOB,0);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_U(        ***   Color-Button*/
int  XbWFOj_Ed_U(int edit, XbWDDb_DbIObj  *TOB){
  if (edit == 3) {return(0); };
  XbWFOj_DpSwt(TOB);
  XbWFOj_DpColButt(TOB,0);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_V(        ***   Color-Button*/
int  XbWFOj_Ed_V(int edit, XbWDDb_DbIObj  *TOB){
  XbWFOj_DpColButt(TOB,2);
  if (edit == 3) {return(0); };
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Dp_R(        ***   Eine Zeile aus einer Textdatei zeigen*/
int  XbWFOj_Dp_R(XbWDDb_DbIObj  *TOB){
  /* enth�lt eine Zeile aus einer Textdatei (TFRL lang) */
  int dfl,off;
  char *fname;
  FILE *fp;
  char sstr[200];
  int ii;
  fname = (char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,"V",1);
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,*TOB->bfc);
  if (fname != NULL) {
    dfl = (int)XbWFDb_GetNum(TOB->chn,"v",1);
    off = (int)XbWFDb_GetNum(TOB->chn,"m",1);
    if ((fp = XbWSSy_fopen(fname,"rt")) == NULL) {
       return(0);
      };

    if (dfl == 0) {
      XbWVOb_pos = 0;
      ii=0;
      while (ii<off) {
        if (fgets(sstr,198,fp) == NULL){
          ii = 30000;
          off = 0;
          };
        ii++;
        };
      }
    else {
      fseek(fp,XbWVOb_pos,SEEK_SET);
      };
    if (fgets(sstr,198,fp) != NULL) {
      XbWVOb_pos=ftell(fp);
      if (strchr(sstr,13) != NULL) {
        *((char*)strchr(sstr,13)) = 0;
        };
      if (strchr(sstr,10) != NULL) {
        *((char*)strchr(sstr,10)) = 0;
        };
      XbWSGr_TLBox(XbWVOb_X+2,XbWVOb_Y+2,0,0,sstr,*TOB->bkc,*TOB->txc,0);
      }
    else {
      XbWVOb_pos=ftell(fp);
      };
    fclose(fp);
    };
  return(1);
  };


/*}}}  */
/*{{{  XbWFOj_Dp_N(        ***   Elementnamen zeigen*/
int  XbWFOj_Dp_N(XbWDDb_DbIObj  *TOB){
 /* Alle Namen */
  int anr,aof,atp,ale,ii;
  char aov[16], *ain;


  XbWDDb_DbIVar  *gr_st;

  aof = (int)  XbWFDb_GetNum(TOB->chn,"ao",1);
  anr = (int)  XbWFDb_GetNum(TOB->chn,"an",1);

  gr_st = (XbWDDb_DbIVar *)XbWDDb_DbIPrj;

  for (ii = 0; ii < aof+anr; ii++) {
    if ((gr_st->tp & XbWDDb_Typ) == XbWDDb_GPtr) {
       return(0);
      };
    XbWFDb_ForWd(&gr_st,XbWDDb_DbISys);
    };

  if (XbWFDb_GetInf(gr_st,0,aov,&atp,&ain,&ale,0)) {
    XbWFDb_PutStr(TOB->chn,"V",1,aov);
    XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,aov,*TOB->bkc,*TOB->txc,*TOB->bfc);
    };
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Dp_Z(        ***   Projektnamen zeigen*/
int  XbWFOj_Dp_Z(XbWDDb_DbIObj  *TOB){
  int atp,ale;
  char aov[16], *ain;
  XbWDDb_DbIVar  *gr_st;


  gr_st = (XbWDDb_DbIVar *)XbWDDb_DbIPrj;

  if (XbWFDb_GetInf(gr_st,0,aov,&atp,&ain,&ale,0)) {
    if (atp == XbWDDb_Str) {
      XbWFDb_PutStr(TOB->chn,"V",1,ain);
      XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,ain,*TOB->bkc,*TOB->txc,*TOB->bfc);
      };
    };
  return(1);
  };


/*}}}  */
/*{{{  XbWFDb_AddVARTypeDescription(char *zstr, char *vartype){*/
void XbWFDb_AddVARTypeDescription(char *zstr, char *vartype){
  char sstr[200];
  strcpy(sstr,zstr);
  sstr[100]=0;
  strcat(sstr,"                                                         ");
  sstr[49]=0;
  if (strcmp(vartype,"W")==0){     strcat(sstr,"Window name for object"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"X")==0){     strcat(sstr,"X left pixel of object"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"Y")==0){     strcat(sstr,"Y top pixel of object");  strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"x")==0){     strcat(sstr,"right pixel of object");  strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"y")==0){     strcat(sstr,"bottom pixel of object"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"b")==0){     strcat(sstr,"background col of obj");  strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"f")==0){     strcat(sstr,"bright color of object"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"F")==0){     strcat(sstr,"dark color of object");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"t")==0){     strcat(sstr,"text color of object");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"D")==0){     strcat(sstr,"DISPLAY TYPE of object"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"E")==0){     strcat(sstr,"EDIT TYPE of object");    strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"d")==0){     strcat(sstr,"disp status of object");  strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"e")==0){     strcat(sstr,"edit status of object");  strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"w")==0){     strcat(sstr,"draw window after edit"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"V")==0){     strcat(sstr,"OBJECT VAR PARAMETER");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"I")==0){     strcat(sstr,"info typ;L=line;F=screen"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"T")==0){     strcat(sstr,"additional displaytext"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"v")==0){     strcat(sstr,"object default value");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"m")==0){     strcat(sstr,"object minimum value");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"M")==0){     strcat(sstr,"object maximum value");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"1")==0){     strcat(sstr,"ON status: disp.text");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"0")==0){     strcat(sstr,"OFF status: disp.text");  strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"A")==0){     strcat(sstr,"operation for button");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"K")==0){     strcat(sstr,"func-key: exec macro");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"T")==0){     strcat(sstr,"func-key: read metafile"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"O")==0){     strcat(sstr,"func-key: edit object");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"W")==0){     strcat(sstr,"func-key: open window");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"tp")==0){    strcat(sstr,"window type;17=std");     strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"nx")==0){    strcat(sstr,"window x left pixel");    strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"ny")==0){    strcat(sstr,"window y top pixel");    strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"sx")==0){    strcat(sstr,"window x size pixel");    strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"sy")==0){    strcat(sstr,"window y size pixel");    strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"bd")==0){    strcat(sstr,"wdw auto backgnd draw");   strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"fmt")==0){   strcat(sstr,"float displyformat str"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"sca")==0){   strcat(sstr,"float scale factor");     strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"una")==0){   strcat(sstr,"float units factor");     strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"eha")==0){   strcat(sstr,"float disply units str"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"OBJ")==0){   strcat(sstr,"object group name");      strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"WDW")==0){   strcat(sstr,"window group name");      strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"MFX")==0){   strcat(sstr,"mfx I/O group name");     strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"OBX")==0){   strcat(sstr,"object editor groupname"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"SVR")==0){   strcat(sstr,"system var group name");  strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"USR")==0){   strcat(sstr,"user varia group name");  strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"KEY")==0){   strcat(sstr,"keyboard var group name"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"rbK",3)==0){   strcat(sstr,"exec cmd;then edit obj"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"raK",3)==0){   strcat(sstr,"edit obj;then exec cmd"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"rqK",3)==0){   strcat(sstr,"edit obj queue;then cmd"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"wbX",3)==0){   strcat(sstr,"writ.MFX;then edit obj"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"rbX",3)==0){   strcat(sstr,"read MFX;then edit obj"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"waX",3)==0){   strcat(sstr,"edit obj;then writ.MFX"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"raX",3)==0){   strcat(sstr,"edit obj;then read MFX"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"rbT",3)==0){   strcat(sstr,"exec macro;then edit o."); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"raT",3)==0){   strcat(sstr,"edit o;then exec macro"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"rqT",3)==0){   strcat(sstr,"edit obqueue;then macro"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"dpO",3)==0){   strcat(sstr,"edit;then disply object"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"edO",3)==0){   strcat(sstr,"edit obj on 'CURSOR UP'"); strcpy(zstr,sstr); return;};
  if (strncmp(vartype,"wov",3)==0){   strcat(sstr,"1=wdw was written over"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"icn")==0){   strcat(sstr,"1=wdw is iconized     "); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"bkc")==0){   strcat(sstr,"background col of wdw "); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"txc")==0){   strcat(sstr,"text color of window  "); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"bfc")==0){   strcat(sstr,"bright window color   "); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"dfc")==0){   strcat(sstr,"dark window color     "); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"wfx")==0){   strcat(sstr,"1=wdw locked;no exit  "); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"wfe")==0){   strcat(sstr,"1=lock wdw on objclick"); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"inf")==0){   strcat(sstr,"info file for window  "); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"obj")==0){   strcat(sstr,"pointer to 1st object "); strcpy(zstr,sstr); return;};
  if (strcmp(vartype,"layer")==0){   strcat(sstr,"(reserved value)"); strcpy(zstr,sstr); return;};
  };
/*}}}  */
/*{{{  XbWFOj_Dp_A(        ***   Automatisch Elementinhalt belieb. Typs*/
int  XbWFOj_Dp_A(XbWDDb_DbIObj  *TOB, int this_obj){
 /* AUTOMATIC;
     "aln" Name der Liste zum Editieren
     "agn" Name der Var-Gruppe zum editieren
     "an" ist startnummer der var. zum editieren
     "ao" ist listen-offset zu an; */

  int anr,aof,atp,ale;
  char aov[16], *ain;
  char *agr, *aon;
  int *iinh;
  double *dinh;
  XbWDDb_DbIPtr *linh;
  char sstr[200];

  XbWDDb_DbIVar  *gr_st;
  XbWDDb_DbIVar  *ao_st;

  anr = (int)  XbWFDb_GetNum(TOB->chn,"an",1);
  aof = (int)  XbWFDb_GetNum(TOB->chn,"ao",1);

  if (!this_obj){
    if (aof == 0) {
      static char aagr[100];
      static char aaon[100];
      gr_st = XbWFDb_FindGrp("OBX","act");

      if (gr_st == NULL) {
        XbWVOb_mgr  = NULL;
        XbWVOb_mao  = NULL;
        return(0);
        };

      agr = (char*)XbWFDb_VarInh(gr_st,XbWDDb_Str,"aln",1);
      aon = (char*)XbWFDb_VarInh(gr_st,XbWDDb_Str,"agn",1);
      strcpy(aagr,(char*)(XbWFTb_PckTxt(agr)));
      strcpy(aaon,(char*)(XbWFTb_PckTxt(aon)));
 
      if ((ao_st = XbWFDb_FindGrp(aagr,aaon)) == NULL) {
        XbWVOb_mgr  = NULL;
        XbWVOb_mao  = NULL;
        return(0);
        };
      XbWVOb_mgr  = gr_st;
      XbWVOb_agr = aagr;
      XbWVOb_aon = aaon;
      XbWVOb_mao  = ao_st;
      }
    else {
      if (XbWVOb_mgr == NULL){
        XbWVOb_mao  = NULL;
        return(0);
        };
      if (XbWVOb_mao == NULL){
        XbWVOb_mgr  = NULL;
        return(0);
        };
 
      gr_st = XbWVOb_mgr;
      agr   = XbWVOb_agr;
      aon   = XbWVOb_aon;
      ao_st = XbWVOb_mao;
      };
    }
  else {
    ao_st = TOB->chn;
    gr_st = XbWVOb_mgr;
    agr   = XbWVOb_agr;
    aon   = XbWVOb_aon;
    };

  strcpy(sstr,"");

  if (XbWFDb_GetInf(ao_st,anr+aof,aov,&atp,&ain,&ale,0)) {
    if (!this_obj){ sprintf(sstr,"[%s] UNKNOWN TYPE",aov); }
    else { sprintf(sstr,"???"); };
    switch (atp) {
      case XbWDDb_Int: iinh = (int*)ain;
                   if (!this_obj){
                     sprintf(sstr,"i(%s %d);",aov,*iinh);
                     }
                   else {
                     sprintf(sstr,"%d",*iinh);
                     };
                   XbWFDb_AddVARTypeDescription(sstr,aov);
                   break;
      case XbWDDb_Dbl: dinh = (double*)ain;
                   { char *ffmt; char sstr1[100];
                     if ((ffmt=(char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,"fmt",1)) ==NULL){
                       ffmt = "%9.5f";
                       };
                     sprintf(sstr1,(char*)XbWFTb_PckTxt(ffmt),*dinh);
                     if (!this_obj) {
                       sprintf(sstr,"d(%s %s);",aov,sstr1);
                       }
                     else {
                       sprintf(sstr,sstr1);
                       };
                     };
                   XbWFDb_AddVARTypeDescription(sstr,aov);
                   break;
      case XbWDDb_Str:
                   if (!this_obj){
                     sprintf(sstr,"s(%s %d (\"%s\"));",aov,ale,ain);
                     }
                   else { sprintf(sstr,"%s",ain); };
                   XbWFDb_AddVARTypeDescription(sstr,aov);
                   break;
      case XbWDDb_NPtr: {
                     char pstr[100];
                     linh = (XbWDDb_DbIPtr *)ain;
                     strcpy(pstr,(char*)XbWFDb_DbIToStr(*linh,XbWDDb_DbISys));
                     if (!this_obj){
                       sprintf(sstr,"pn(%s (ptr)%s);",aov,pstr);
                       }
                     else { sprintf(sstr,"%s",pstr); };
                     };
                   XbWFDb_AddVARTypeDescription(sstr,aov);
                   break;
      case XbWDDb_FPtr: {
                     char pstr[100];
                     linh = (XbWDDb_DbIPtr *)ain;
                     strcpy(pstr,(char*)XbWFDb_DbIToStr(*linh,XbWDDb_DbISys));
                     if (!this_obj){
                       sprintf(sstr," %s cont'd. at %s",aov,pstr);
                       }
                     else { sprintf(sstr,"%s",pstr); };
                     };
                   break;
      case XbWDDb_IPtr: {
                     char pstr[100];
                     linh = (XbWDDb_DbIPtr *)ain;
                     strcpy(pstr,(char*)XbWFDb_DbIToStr(*linh,XbWDDb_DbISys));
                     if (!this_obj){
                       sprintf(sstr,"pn(%s (ptr)%s);",aov,pstr);
                       }
                     else { sprintf(sstr,"%s",pstr); };
                     };
                   break;
      case XbWDDb_GPtr: {
                     char pstr[100];
                     linh = (XbWDDb_DbIPtr *)ain;
                     strcpy(pstr,(char*)XbWFDb_DbIToStr(*linh,XbWDDb_DbISys));
                     if (!this_obj){
                       sprintf(sstr,"eg(); %s End of group; Pointer to %s (start of group)",aov,pstr);
                       }
                     else { sprintf(sstr,"%s",pstr); };
                     };
                   break;
      };
    };
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,sstr,*TOB->bkc,*TOB->txc,*TOB->bfc);
  return(1);
  };



/*}}}  */
/*{{{  XbWFOj_Dp_G(        ***   Gruppennamen zeigen*/
int  XbWFOj_Dp_G(XbWDDb_DbIObj  *TOB){
 /* Gruppenname darstellen;
     "al" Name der Liste
     "an" ist startnummer der Gruppe zum Darstellen
     "ao" ist listen-offset zu an; */

  int anr,aof,atp,natp,ale,nale,ii;
  char aov[16], *ain, *nain;
  char *agr, *aon;

  XbWDDb_DbIVar  *gr_st;

  agr = (char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,"al",1);
  aon = (char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,"V",1);
  anr = (int)  XbWFDb_GetNum(TOB->chn,"an",1);
  aof = (int)  XbWFDb_GetNum(TOB->chn,"ao",1);

  gr_st = XbWFDb_FindGrp(agr,NULL);
  for (ii = 0; ii < aof+anr; ii++) {
    gr_st = XbWFDb_NextGrp(gr_st,NULL);
    if (gr_st == NULL){ return(0); };
    };

  if (XbWFDb_GetInf(gr_st,0,aov,&atp,&ain,&ale,0)) {
    switch (atp) {
      case XbWDDb_Str:
                   if (XbWFDb_GetInf(TOB->chn,-1,"V",&natp,&nain,&nale,0)) {
                     if (nale <= strlen(ain)){
                       printf("ERROR: String VAR-Element \"OBJ:%s.V\" is too small!\n",
                         TOB->onm);
                       return(1);
                       };
                     strcpy(aon,ain);
                     XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,aon,*TOB->bkc,*TOB->txc,*TOB->bfc);
                     };
                   break;
      };
    };
  return(1);
  };

/*}}}  */
/*{{{  XbWFOj_Dp_S(        ***   String display*/
int  XbWFOj_Dp_S(XbWDDb_DbIObj  *TOB){
  char *txtstr;
  txtstr = (char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,"V",1);
  if (txtstr == NULL) {return(0); };
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,txtstr,*TOB->bkc,*TOB->txc,*TOB->bfc);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Dp_T(        ***   Text display*/
int  XbWFOj_Dp_T(XbWDDb_DbIObj  *TOB){
  char *txtstr;
  txtstr = (char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,"V",1);
  if (txtstr == NULL) {return(0); };
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,txtstr,*TOB->bkc,*TOB->txc,*TOB->bkc);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_DpInt(       ***   Integer display*/
int  XbWFOj_DpInt(XbWDDb_DbIObj  *TOB){
  XbWFOj_GetNum(TOB);
  XbWSGr_RBBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,XbWVOb_GTxt,*TOB->bkc,*TOB->txc,*TOB->bfc);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Dp_BKS(      ***   Pfeil-Knopf zeigen*/
int  XbWFOj_Dp_BKS(XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,*TOB->bfc);
  XbWFOj_DpArrow(TOB,(char*)&(TOB->odt[1]));
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Dp_P(        ***   Icon zeigen*/
int  XbWFOj_Dp_P(XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,*TOB->bfc);
  XbWSGr_DspIcon(TOB);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Dp_X(        ***   XS-Slider,XL-Line,XE-Ellipse,XB-Box*/
int  XbWFOj_Dp_X(XbWDDb_DbIObj  *TOB){
  switch(TOB->odt[1]){
    case 'S':
              XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,*TOB->bfc);
              XbWFOj_DpSlider(TOB,0);
              break;
    case 'L': XbWSGr_Line(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,*TOB->dfc);
              break;
    case 'E': XbWFOj_DpEllipse(TOB);
              break;
    case 'B': XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,*TOB->bfc);
              break;
    };
  return(1);
  };
/*}}}  */

/*{{{  XbWFTb_DoSpecialCommand(***   Hauptroutine fuer alle Erweiterungen*/
int  XbWFTb_DoSpecialCommand(void  *(*p)[]){
  if (strcmp("RAD_BFN",(char*)(*p)[1]) == 0) {
    return( XbWFTb_MkRadFil(p));
    };
  if (strcmp("RAD_CFN",(char*)(*p)[1]) == 0) {
    return( XbWFTb_CkRadFil(p));
    };
  if (strcmp("EXC_STR",(char*)(*p)[1]) == 0) {
    return( XbWFTb_ReplString(p));
    };
  return(1);
  };
/*}}}  */
/*{{{  XbWFTb_MkRadFil(    ***   RADAN-Filenamen generieren (VW-Speziell)*/
int  XbWFTb_MkRadFil(void  *(*p)[]){
  char *fildir,*filnam;
  int band,versuch,step,rad;
  char *rotfix;
  char sstr[60];
  /* ============== ANZAHL PARAMETER PRUEFEN                            */
  if ( (int)(*p)[0] != 8) { return(1); };
  /* ============== Der ERSTE PARAMETER ist der FUNKTIONSNAME!!         */
  fildir =  (char*)(*p)[2];
  filnam =  (char*)(*p)[3];
  rotfix =  (char*)(*p)[4];
  band =      (int)(*p)[5];
  versuch =   (int)(*p)[6];
  step =      (int)(*p)[7];
  rad =       (int)(*p)[8];
  if (fildir == NULL) { return(1); };
  if (filnam == NULL) { return(1); };
  if (rotfix == NULL) { return(1); };
  sprintf(filnam,"00000000.000");
  filnam[0] = rotfix[0];
  sprintf(sstr,"%3d",band);
  if (sstr[0] != ' ') { filnam[1] = sstr[0]; };
  if (sstr[1] != ' ') { filnam[2] = sstr[1]; };
  if (sstr[2] != ' ') { filnam[3] = sstr[2]; };
  sprintf(sstr,"%4d",versuch);
  if (sstr[0] != ' ') { filnam[4] = sstr[0]; };
  if (sstr[1] != ' ') { filnam[5] = sstr[1]; };
  if (sstr[2] != ' ') { filnam[6] = sstr[2]; };
  if (sstr[3] != ' ') { filnam[7] = sstr[3]; };
  sprintf(sstr,"%2d",step);
  if (sstr[0] != ' ') { filnam[10] = sstr[0]; };
  if (sstr[1] != ' ') { filnam[11] = sstr[1]; };
  sprintf(sstr,"%1d",rad);
  if (sstr[0] != ' ') { filnam[9] = sstr[0]; };
  return(0);
  };
/*}}}  */
/*{{{  XbWFTb_CkRadFil(    ***   RADAN-Filenamen pruefen (VW-Speziell)*/
int  XbWFTb_CkRadFil(void  *(*p)[]){
  FILE *fp;
  char *fildir,*filnam;
  char sstr[60];
  int *status;
  /* ============== ANZAHL PARAMETER PR�FEN                             */
  if ( (int)(*p)[0] != 4) { return(1); };
  /* ============== Der ERSTE PARAMETER ist der FUNKTIONSNAME!!         */
  fildir =  (char*)(*p)[2];
  filnam =  (char*)(*p)[3];
  status =   (int*)(*p)[4];
  if (fildir == NULL) { return(1); };
  if (filnam == NULL) { return(1); };
  if (status == NULL) { return(1); };
  sprintf(sstr,"%s%s",fildir,filnam);
  if ((fp = XbWSSy_fopen(sstr,"rb")) != NULL){
    fclose(fp);
    *status = 1;
    }
  else {
    strcpy(filnam,"(null)");
    *status = 0;
    };
  return(0);
  };
/*}}}  */

/*{{{  XbWFTb_ReplString(  ***   String-Ersetzung*/
int  XbWFTb_ReplString(void  *(*p)[]){
  char *stra,*strb,*strc;
  if ((int)(*p)[0] != 4) { return(1);};
  stra = (char*)(*p)[2];
  strb = (char*)(*p)[3];
  strc = (char*)(*p)[4];
  if (strstr(stra,strb) != NULL) {
    strcpy(strstr(stra,strb),strc);
    };
  return(0);
  };
/*}}}  */
/*{{{  XbWFTb_PckTxt(      ***   Text von Spaces befreien*/
char  *XbWFTb_PckTxt(char *str){
  int cc,ll;
  cc = 0;
  while((str[cc] == ' ') & (strlen(str) > cc)) {
    cc++;
    };
  ll = 0;
  while((ll< strlen((char *)str))&(ll<XbWDTb_PckTLen)){
    XbWVTb_PTS[ll] = str[cc+ll];
    ll++;
    };
  if (strlen(str) >= XbWDTb_PckTLen) {
    XbWVTb_PTS[XbWDTb_PckTLen-1] = 0;
    }
  else {
    XbWVTb_PTS[strlen(str)] = 0;
    };
  while((XbWVTb_PTS[strlen(XbWVTb_PTS)-1] == ' ') & (strlen(XbWVTb_PTS) > 0)) {
    XbWVTb_PTS[strlen((char *)XbWVTb_PTS)-1] = 0;
    };
  return(XbWVTb_PTS);
  };
/*}}}  */
/*{{{  XbWFTb_InBox(       ***   Maus in Box ??*/
boolean  XbWFTb_InBox(
    int sxa,int sya,int xa,int ya,int xb,int yb){
  int mrk;
  if (xa > xb)   { mrk = xb; xb = xa; xa = mrk;};
  if (ya > yb)   { mrk = ya; ya = yb; yb = mrk;};
  if ((sxa >= xa) & (sxa <= xb) &
      (sya >= ya) & (sya <= yb))  {return(1);}
  else {return(0);};
  };
/*}}}  */
/*{{{  XbWFTb_ColCon(      ***   Farbkonvertierung fuer Textfarbe*/
int  XbWFTb_ColCon(int dunkelfarbe){
  int textcol=0;
  if (dunkelfarbe ==  XbWVGr_Black      )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_Blue       )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_Green      )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_Cyan       )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_Red        )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_Magenta    )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_Brown      )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_LGray  )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_DGray   )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_LBlue  )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_LGreen )
    {textcol = XbWVGr_DGray; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_LCyan  )
    {textcol = XbWVGr_DGray; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_LRed   )
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_LMagenta)
    {textcol = XbWVGr_White; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_Yellow     )
    {textcol = XbWVGr_DGray; goto weiter;};
  if (dunkelfarbe ==  XbWVGr_White      )
    {textcol = XbWVGr_DGray; goto weiter;};
  weiter:;
  return(textcol);
  };
/*}}}  */
/*{{{  XbWFTb_CmpStr(      ***   Strings vergleichen*/
int  XbWFTb_CmpStr(char *stra, char *strb){
  if (stra == NULL) { return(1); };
  if (strb == NULL) { return(1); };
  return(strcmp(stra,strb));
  };
/*}}}  */
/*{{{  XbWFTb_PutMessage(  ***   Nachricht unten ausgeben*/
void  XbWFTb_PutMessage(void  *(*p)[]){
  if ((int)(*p)[0] >0){
    XbWFTb_Message((char*)(*p)[1]);
    };
  };
/*}}}  */
/*{{{  XbWFTb_PutAlarm(    ***   Nachricht; warte auf Taste*/
void  XbWFTb_PutAlarm(void  *(*p)[]){
  if ((int)(*p)[0] >0){
    XbWSPu_Alarm((char*)(*p)[1]);
    };
  };
/*}}}  */
/*{{{  XbWFTb_PutError(    ***   Nachricht; Taste; PopUpBox ausgeben*/
void  XbWFTb_PutError(void  *(*p)[]){
  if ((int)(*p)[0] >0){
    XbWFTb_Error((char*)(*p)[1]);
    };
  };
/*}}}  */
/*{{{  XbWFTb_Case(        ***   Case-Abfrage fuer Metafile-Interpreter*/
int  XbWFTb_Case(void  *(*p)[],int (*t)[]){
  double v1,v2;
  char *s1,*s2;
  int is1string=0;
  int is2string=0;
  char *oper;
  if ((int)(*p)[0] != 4) {return(1);};
  switch ((int)(*t)[1]){
    case XbWDMf_VLPar:
      {
        XbWDDb_DbIVar  *MV;
        MV = (XbWDDb_DbIVar  *)(*p)[1];
        if (MV == NULL)  {return(1); };
        v1 = XbWFDb_GetNum(MV,NULL,1);
        };
      break;
    case XbWDMf_StrPar:
    case XbWDMf_VIPar:
       s1 = (char*)(*p)[1];
       is1string=1;
       break;
 
    case XbWDMf_VPPar:
    case XbWDMf_IntPar: v1 = (int)(*p)[1]; break;
    default:return(1);
    };
  switch ((int)(*t)[3]){
    case XbWDMf_VLPar:
      {
        XbWDDb_DbIVar  *MV;
        MV = (XbWDDb_DbIVar  *)(*p)[3];
        if (MV == NULL)  {return(1); };
        v2 = XbWFDb_GetNum(MV,NULL,1);
        };
      break;
    case XbWDMf_StrPar:
    case XbWDMf_VIPar:
       s2 = (char*)(*p)[3];
       is2string=1;
       break;
    case XbWDMf_VPPar:
    case XbWDMf_IntPar: v2 = (int)(*p)[3]; break;
    default:return(1);
    };
  oper = (char*)(*p)[2];
  if (is1string != is2string){
    puts("ERR: comparing string and non-string!");
    return(1);
    };
  switch(oper[0]){
    case '=' :
      if (is1string+is2string){
        if (!XbWFTb_CmpStr(s1,s2)) { XbWFMf_ReadMakro((char*)(*p)[4]); };
        }
      else {
        if (v1 == v2) { XbWFMf_ReadMakro((char*)(*p)[4]); };
        };
      break;
    case '>' :
      switch(oper[1]) {
        case '=' :
          if (is1string+is2string){
            if (XbWFTb_CmpStr(s1,s2)>=0) { XbWFMf_ReadMakro((char*)(*p)[4]); };
            }
          else {
            if (v1 >= v2) { XbWFMf_ReadMakro((char*)(*p)[4]); }; break;
            };
        default:
          if (is1string+is2string){
            if (!XbWFTb_CmpStr(s1,s2)) { XbWFMf_ReadMakro((char*)(*p)[4]); };
            }
          else {
            if (v1 > v2) { XbWFMf_ReadMakro((char*)(*p)[4]); }; break;
            };
        };
      break;
    case '<' :
      switch(oper[1]) {
        case '=' :
          if (is1string+is2string){
            if (XbWFTb_CmpStr(s1,s2)<=0) { XbWFMf_ReadMakro((char*)(*p)[4]); };
            }
          else {
            if (v1 <= v2) { XbWFMf_ReadMakro((char*)(*p)[4]); }; break;
            };
        default:
          if (is1string+is2string){
            if (XbWFTb_CmpStr(s1,s2)<=0) { XbWFMf_ReadMakro((char*)(*p)[4]); };
            }
          else {
            if (v1 < v2) { XbWFMf_ReadMakro((char*)(*p)[4]); }; break;
            };
        };
      break;
    case '!' :
      if (is1string+is2string){
        if (XbWFTb_CmpStr(s1,s2)!=0) { XbWFMf_ReadMakro((char*)(*p)[4]); };
        }
      else {
        if (v1 != v2) { XbWFMf_ReadMakro((char*)(*p)[4]); };
        };
      break;
    };
  return(0);
  };
/*}}}  */
/*{{{  XbWFTb_PackStr(     ***   String-Element Inhalt packen (PckText)*/
int  XbWFTb_PackStr(void  *(*p)[], int (*t)[]) {
  char *ziel;
  if ( (int)(*p)[0] < 1) {
    return(1);
    };
  switch ( (int)(*t)[1]) {
    case XbWDMf_StrPar: ziel = (char*)(*p)[1]; break;
    case XbWDMf_VLPar:  {
                          XbWDDb_DbIVar  *QQ;
                          QQ = (XbWDDb_DbIVar  *)(*p)[1];
                          if (QQ == NULL) { return(1); };
                          ziel = (char*)XbWFDb_VarInh(QQ,XbWDDb_Str,NULL,1);
                          break;
                          };
    default: return(1);;
    };
  if (ziel==NULL) { return(1); };
  strcpy(ziel,(char*)XbWFTb_PckTxt(ziel));
  return(0);
  };
/*}}}  */
/*{{{  XbWFDb_StorGrpn(    ***   Name Aktuelle Gruppe in Element speichern*/
int  XbWFDb_StorGrpn(void  *(*p)[], int (*t)[]) {
  char *win_name,*grp_name;
  if ( (int)(*p)[0] < 2) {
    return(1);
    };
  switch ( (int)(*t)[1]) {
    case XbWDMf_StrPar: grp_name = (char*)(*p)[1]; break;
    case XbWDMf_VLPar:  {
                          XbWDDb_DbIVar  *QQ;
                          QQ = (XbWDDb_DbIVar  *)(*p)[1];
                          if (QQ == NULL) { return(1); };
                          grp_name = (char*)XbWFDb_VarInh(QQ,XbWDDb_Str,NULL,1);
                          break;
                          };
    default: return(1);;
    };
  switch ( (int)(*t)[2]) {
    case XbWDMf_StrPar: win_name = (char*)(*p)[2]; break;
    case XbWDMf_VLPar:  {
                          XbWDDb_DbIVar  *QQ;
                          QQ = (XbWDDb_DbIVar  *)(*p)[2];
                          if (QQ == NULL) { return(1); };
                          win_name = (char*)XbWFDb_VarInh(QQ,XbWDDb_Str,NULL,1);
                          break;
                          };
    default: return(1);;
    };
  if ( XbWFDb_FindGrp("WDW",win_name) != NULL) {
    strcpy(grp_name,"WDW");
    return(0);
    };
  return(0);
  };
/*}}}  */
/*{{{  XbWFTb_AnswerPopUpReq(  ***   PopUpBox mit 3 Moeglichkeiten*/
int  XbWFTb_AnswerPopUpReq(void  *(*p)[]){
  int ii;
  if ((int)(*p)[0] != 8){return(1);};
  ii = XbWFTb_SubPopUpBox(
    (char*)(*p)[1],
    (char*)(*p)[2],
    (char*)(*p)[3],
    (char*)(*p)[4],
    (char*)(*p)[5]);
  switch(ii) {
    case 1:  XbWFMf_ReadMakro((char*)(*p)[6]); return(0);
    case 2:  XbWFMf_ReadMakro((char*)(*p)[7]); return(0);
    case 3:  XbWFMf_ReadMakro((char*)(*p)[8]); return(0);
    };
  return(1);
  };
/*}}}  */
/*{{{  XbWFTb_DbgMta(      ***   Debugging fuer Metafiles einschalten*/
void  XbWFTb_DbgMta(void){
  XbWVMf_dmf = 1;
  };
/*}}}  */
/*{{{  XbWFTb_ClrScr(      ***   Schirm loeschen*/
void  XbWFTb_ClrScr(void){
  int cs = XbWVMs_CSet;
  XbWFGr_CurOFF();
  XbWFWd_BackGr();
  if (cs) { XbWFGr_CurON(); };
  };
/*}}}  */
/*{{{  XbWFTb_AClosON(     ***   Automatisches WindowClose EIN;*/
void  XbWFTb_AClosON(void){
  XbWVWd_AClos = 1;
  };
/*}}}  */
/*{{{  XbWFTb_AClosOFF(    ***   ...AUS; wirkt wenn Wdw teilweise ueberdeckt*/
void  XbWFTb_AClosOFF(void){
  XbWVWd_AClos = 0;
  };
/*}}}  */
/*{{{  XbWFTb_RedrawON(    ***   Window neuzeichnen, wenn angecklickt &*/
void  XbWFTb_RedrawON(void){
  XbWVWd_RedrawON = 1;
  };
/*}}}  */
/*{{{  XbWFTb_RedrawOFF(   ***   ...teilweise verdeckt ist*/
void  XbWFTb_RedrawOFF(void){
  XbWVWd_RedrawON = 0;
  };
/*}}}  */
/*{{{  XbWFTb_SpwnTsk(     ***   Task spawn*/
void  XbWFTb_SpwnTsk(void){
  if (system(XbWVSy_DosCmd) != 0) {
    puts("Sorry, but I cannot start your task ");
    puts(XbWVSy_DosCmd);
    };
  };
/*}}}  */
/*{{{  XbWFTb_SpwnTskClrScr(   ***   Task spawn mit anschliessendem ClrScr*/
int  XbWFTb_SpwnTskClrScr(void  *(*p)[], int (*t)[]){
  if ((int)(*p)[0] < 1 ) {return(1);};
  if (!XbWSOS_SpwnStd(p,t)) {
    XbWSGr_ResMode();
    XbWSMs_DrInit();
    XbWFWd_BackGr();
    XbWFWd_DrawAll();
    return(0);
    };
  return(1);
  };
/*}}}  */
/*{{{  XbWFTb_SpwnTskTxtMod(   ***   Task im Textmode spawnen; dann ClrScr*/
int  XbWFTb_SpwnTskTxtMod(void  *(*p)[], int (*t)[]){
  if ((int)(*p)[0] < 1 ) {return(1);};
  XbWSGr_Close();
  return(XbWFTb_SpwnTskClrScr(p,t));
  };
/*}}}  */
/*{{{  XbWFTb_Click(       ***   Klick-Geraeusch*/
void  XbWFTb_Click(void){
  XbWDDb_DbIVar  *sv_gp;
  sv_gp = XbWFDb_FindGrp("SVR","genvars");
  if (sv_gp != NULL){
    if ((int)XbWFDb_GetNum(sv_gp,"Sound",1)) {
      XbWSOS_Sound(2000); XbWSOS_Delay(3); XbWSOS_NoSound();
      };
    };
  };
/*}}}  */
/*{{{  XbWFTb_HBeep(       ***   Hoher Piepton*/
void  XbWFTb_HBeep(void){
  XbWDDb_DbIVar  *sv_gp;
  sv_gp = XbWFDb_FindGrp("SVR","genvars");
  if (sv_gp != NULL){
    if ((int)XbWFDb_GetNum(sv_gp,"Sound",1)) {
      XbWSOS_Sound(1500);XbWSOS_Delay(50);XbWSOS_NoSound();
      };
    };
  };
/*}}}  */
/*{{{  XbWFTb_LBeep(       ***   Tiefer Piepton*/
void  XbWFTb_LBeep(void){
  XbWDDb_DbIVar  *sv_gp;
  sv_gp = XbWFDb_FindGrp("SVR","genvars");
  if (sv_gp != NULL){
    if ((int)XbWFDb_GetNum(sv_gp,"Sound",1)) {
      XbWSOS_Sound(1000);XbWSOS_Delay(50);XbWSOS_NoSound();
      };
    };
  };
/*}}}  */
/*{{{  XbWFTb_CorrSiz(     ***   Windowkoordinaten anpassen*/
void  XbWFTb_CorrSiz(
    int *xa,int *ya,int *xb,int *yb,
    int wxa, int wya, int wxb, int wyb){
  if (*xb-*xa > wxb-wxa) {/* Zu gross !! */ *xb = *xa + (wxb-wxa); };
  if (*yb-*ya > wyb-wya) {/* Zu gross !! */ *yb = *ya + (wyb-wya); };
  if (*xb > wxb) {/* Zu weit rechts !! */ *xa -= *xb -wxb; *xb = wxb; };
  if (*yb > wyb) {/* Zu weit unten !!  */ *ya -= *yb -wyb; *yb = wyb; };
  };
/*}}}  */
/*{{{  XbWFTb_Outl(        ***   Textzeile fuer PopUpBoxen ausgeben*/
void  XbWFTb_Outl(int xa, int *ya, char *txt, int col){
  XbWSGr_TLBox(xa,*ya,0,0,
    txt,col,col,col);
  *ya += (3+XbWFGr_THeight());
  };
/*}}}  */
/*{{{  XbWFTb_SubPopUpBox( ***   Unterroutine fuer PopUpBox*/
int  XbWFTb_SubPopUpBox(char msg1[50],char msg2[50],
            char text1[50],char text2[50],char text3[50]){
  int taste,mxp,myp;
 
  void  *oldcursor;
  int warn_state = 0;
 
  boolean Cursormerk;Cursormerk = XbWVMs_CSet;
#define XA1 3
#define YA1 26
#define XB1 XA1+118
#define YB1 YA1+14

#define XA2 XB1
#define YA2 YA1
#define XB2 XA2+118
#define YB2 YB1

#define XA3 XB2
#define YA3 YA1
#define XB3 XB2+118
#define YB3 YB1

#define XLO 5     /*   360      */
#define YLO 5     /*  5*11 = 55 */
#define XRU 370
#define YRU 60
  oldcursor = XbWSMs_SetClockCursor();
  { int rootx,rooty,winx,winy,mask;
    Window root, child;
    XQueryPointer(
      XbWVSy_ConTxt.dpy,
      XbWVSy_ConTxt.window,
      &root, &child,
      &rootx, &rooty,
      &winx, &winy,
      &mask
      );
    XbWSSy_SubWindow(rootx , rooty, XRU+5,YRU+5);
    };
  XbWFGr_CurOFF();
  XbWFGr_PushPort();
  XbWFGr_MaxPort();
  XbWSMs_SetArrowCursor();
neustart:
  XbWFGr_CurOFF();
  XbWFGr_MinPort(XLO,YLO,XRU,YRU);
  XbWFTb_HBeep(); XbWFTb_LBeep(); XbWFTb_HBeep(); XbWFTb_LBeep();
  XbWSGr_TLBox(0,0,(XRU-XLO),(YRU-YLO),
    NULL,XbWVGr_White,0,XbWVGr_LRed);

  XbWSGr_TLBox(XA1,YA1,XB1,YB1,text1,XbWVGr_Cyan,XbWVGr_White,XbWVGr_LCyan);
  XbWSGr_TLBox(XA2,YA2,XB2,YB2,text2,XbWVGr_Cyan,XbWVGr_White,XbWVGr_LCyan);
  XbWSGr_TLBox(XA3,YA3,XB3,YB3,text3,XbWVGr_Cyan,XbWVGr_White,XbWVGr_LCyan);
  XbWSGr_TLBox(14,3,0,0, msg1,XbWVGr_White,XbWVGr_Blue,0);
  XbWSGr_TLBox(14,13,0,0,msg2,XbWVGr_White,XbWVGr_Blue,0);
  XbWFGr_CurON();
 
  /*XbWSMs_Warp((XLO+XRU)/2,(YLO+YRU)/2);*/
  XbWSMs_IsAKey(0);
  XbWVMs_Button = 0;
  while (1){
    XEvent mev;
    if (!XbWFTb_InBox(XbWVMs_XPos,XbWVMs_YPos,XLO,YLO,XRU,YRU)) {
/*      XbWSMs_SetStopCursor(); */
      if (warn_state != 1){
        /*XbWFTb_Warning("Please quit the active pop-up box explicitly!");*/
        warn_state = 1;
        };
      }
    else  {
      XbWSMs_SetArrowCursor();
      if (warn_state != 2){
        /*XbWFTb_Message("You must quit this pop-up box explicitly.");*/
        warn_state = 2;
        };
      };
    XNextEvent(XbWVSy_ConTxt.dpy,&mev);
    switch (mev.type){
      case KeyPress:
            {
              KeySym keysym;
 
              int n;
              char string[257],cc;
              XKeyEvent *keyevent;
              keyevent = (XKeyEvent *)&mev;
              strcpy(string,"");
              n = XLookupString(keyevent, string, 256, &keysym, NULL);
              strncpy( XbWVSy_ConTxt.key,string,255);
              XbWVSy_ConTxt.key[255] = 0;
 
              cc = XbWVSy_ConTxt.key[0];
              cc |= 0x20;
              if (cc == (text1[0] | 0x20)) { taste = 1; goto ende_pop_up_box; };
              if (cc == (text2[0] | 0x20)) { taste = 2; goto ende_pop_up_box; };
              if (cc == (text3[0] | 0x20)) { taste = 3; goto ende_pop_up_box; };
              };
            break;
      case Expose:
      case EnterNotify:
             goto neustart;
      case ButtonPress:
             { int rootx,rooty,winx,winy,mask;
               Window root, child;
               if ( XQueryPointer(
                   XbWVSy_ConTxt.dpy,
                   XbWVSy_ConTxt.window,
                   &root, &child,
                   &rootx, &rooty,
                   &winx, &winy,
                   &mask
                   )
                   ){
                 XbWVMs_XPos = winx;
                 XbWVMs_YPos = winy;
                 if (mask & Button1Mask){
                   XbWVMs_LButt = 1;
                   taste = 0;
                   mxp = XbWVMs_XPos - XLO+ XbWVIDEO_XA;
                   myp = XbWVMs_YPos - YLO+ XbWVIDEO_YA;
                   if ( XbWFTb_InBox(mxp,myp,XA1,YA1,XB1,YB1) )   {
                       taste = 1;};
                   if ( XbWFTb_InBox(mxp,myp,XA2,YA2,XB2,YB2) )   {
                       taste = 2;};
                   if ( XbWFTb_InBox(mxp,myp,XA3,YA3,XB3,YB3) )   {
                       taste = 3;};
                   goto ende_pop_up_box;
                   };
                 };
               };
      };
 
    if ( XbWVMs_Bewegt )   {
      XbWFGr_CurOFF();
      XbWVMs_CX = XbWVMs_XPos;
      XbWVMs_CY = XbWVMs_XPos;
      XbWFGr_CurON();
      };
    };
  XbWFGr_CurOFF();
  ende_pop_up_box:;
  if ( (taste < 1) | (taste > 3) )   {
    goto neustart;};
  if (Cursormerk == 0)   {XbWFGr_CurOFF();};
  XbWSSy_SubWindow(0,0,0,0);
  XbWFGr_MaxPort();
  XbWFGr_PopPort(); XbWFGr_ResPort();

  XbWFWd_BackGr();
  XbWFWd_DrawAll();
 
  sleep(1);
  XbWSMs_SetClockCursor();
  XbWSMs_SetLastCursor(oldcursor);
  XbWFTb_Message("XbW - Multiwindow Dialogmanager.");
  return(taste);
  };

/*}}}  */
/*{{{  XbWFTb_PopUpBox(    ***   PopUpBox ausgeben*/
void  XbWFTb_PopUpBox(void  *(*p)[]){
  if ((int)(*p)[0] != 5){return;};
  XbWFTb_SubPopUpBox(
    (char*)(*p)[1],
    (char*)(*p)[2],
    (char*)(*p)[3],
    (char*)(*p)[4],
    (char*)(*p)[5]);
  };
/*}}}  */

/*{{{  XbWFTb_Wait(        ***   Warten; Zeit in Millisekunden*/
void  XbWFTb_Wait(int zeit){
  XbWSOS_Delay(zeit);
  };
/*}}}  */
/*{{{  XbWFGr_CurON(       ***   GrafikCursor ein*/
void  XbWFGr_CurON(void){
#ifdef XbWDGr_IBM8514
            XbWFGr_SetPort();
#endif
            XbWSMs_ON();
#ifdef XbWDGr_IBM8514
            XbWFGr_ResPort();
#endif
            };
/*}}}  */
/*{{{  XbWFGr_CurOFF(      ***   ...Aus*/
void  XbWFGr_CurOFF(void){
#ifdef XbWDGr_IBM8514
            XbWFGr_SetPort();
#endif
            XbWSMs_OFF();
#ifdef XbWDGr_IBM8514
            XbWFGr_ResPort();
#endif
            };

/*}}}  */

/*{{{  XbWFDb_GetHandle(      ****/
XbWDDb_Handle  XbWFDb_GetHandle(
    char *lname, char *gname, char *ename, int recursive){
  char  *target;
  char  *source;
  XbWDDb_DbIVar  *TV;
  if ((TV = XbWFDb_FindGrp(lname,gname) ) != NULL) {
    if (ename == NULL) { goto GetHandleEnde; };
    if (XbWFTb_CmpStr((char*)XbWFDb_GetNam(TV),ename) == 0) {
      goto GetHandleEnde;
      };
    while ((TV->tp & XbWDDb_Typ) != XbWDDb_GPtr) {
      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if (XbWFTb_CmpStr((char*)XbWFDb_GetNam(TV),ename) == 0) {
        GetHandleEnde:;
        if (recursive) {
          while ((TV->tp & XbWDDb_Typ) == XbWDDb_NPtr){
            if (((XbWDDb_DbINPtr  *)TV)->inh == 0) {return(0);};
            TV = XbWFDb_CDbIToPtr( ((XbWDDb_DbINPtr  *)TV)->inh,XbWDDb_DbISys);
            if (TV == NULL) {return(0);};
            };
          };
        target = (char  *)XbWDDb_DbISys;
        source = (char  *)TV;
        return((XbWDDb_Handle)(source-target));
        };
      };
    };
  return(0);
  };
/*}}}  */
/*{{{  XbWFDb_SetGetNumber(      ****/
double  XbWFDb_SetGetNumber(
    XbWDDb_Handle element, double value, int oper){
  XbWDDb_DbIVar  *TV;
  char  *target;
  target = (char  *)XbWDDb_DbISys;
  TV = (XbWDDb_DbIVar  *)(target+element);
  switch (oper){
    case XbWDDb_Get:
           return(XbWFDb_GetNum(TV,NULL,1));
    case XbWDDb_Put:
           XbWFDb_PutNum(TV,NULL,1,value);
           return(value);
    };
  return(0);
  };
/*}}}  */
/*{{{  XbWFDb_SetGetString(      ****/
char  *XbWFDb_SetGetString(
    XbWDDb_Handle element, char  *qstr, int oper){
  XbWDDb_DbIVar  *TV;
  char  *target;
  target = (char  *)XbWDDb_DbISys;
  TV = (XbWDDb_DbIVar  *)(target+element);
  switch (oper){
    case XbWDDb_Get:
           return(XbWFDb_GetStr((XbWDDb_DbIStr  *)TV));
    case XbWDDb_Put:
           XbWFDb_PutStr(TV,NULL,1,(char*)qstr);
           return(qstr);
    };
  return(NULL);
  };
/*}}}  */



