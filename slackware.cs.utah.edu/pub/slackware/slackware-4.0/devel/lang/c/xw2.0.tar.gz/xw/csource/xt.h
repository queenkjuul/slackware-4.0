
#ifdef XbW_SYSDEF_GNU_VERSION

#define huge
#define far
#define USE_PC_SOUND
#endif

#ifdef XbW_SYSDEF_X11_VERSION

#define huge
#define far

#endif


#ifdef XbW_SYSDEF_TC3_VERSION
/* Alle defines, die man braucht, wenn turboc vorhanden */

#define USE_PC_SOUND
#define USE_8086_INTERRUPTS

#else

/* Alle defines, die man braucht, wenn turboc nicht vorhanden */
typedef struct viewporttype {
   short left, top, right, bottom;
   short clip;
    };

typedef struct  REGPACK {
    unsigned short   r_ax, r_bx, r_cx, r_dx;
    unsigned short   r_bp, r_si, r_di, r_ds, r_es, r_flags;
    };

enum putimage_ops {     /* BitBlt operators for putimage */
    COPY_PUT,           /* MOV */
    XOR_PUT,            /* XOR */
    OR_PUT,             /* OR  */
    AND_PUT,            /* AND */
    NOT_PUT             /* NOT */
    };

typedef long    fpos_t;

#endif






