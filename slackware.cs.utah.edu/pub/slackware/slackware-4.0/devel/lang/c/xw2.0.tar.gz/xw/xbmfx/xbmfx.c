
#include "stdlib.h"
#include "stdio.h"
#include "string.h"

#include "xbmfx.h"

/*{{{  Pack Text String*/
#define XbWMFX_PckTLen 250
char XbWMFX_PTS[XbWMFX_PckTLen];
char *XbWMFX_PckTxt(char *str){
  int cc,ll;
  cc = 0;
  while((str[cc] == ' ') & (strlen(str) > cc)) {
    cc++;
    }
  ll = 0;
  while((ll< strlen((char *)str))&(ll<XbWMFX_PckTLen)){
    XbWMFX_PTS[ll] = str[cc+ll];
    ll++;
    }
  if (strlen(str) >= XbWMFX_PckTLen) {
    XbWMFX_PTS[XbWMFX_PckTLen-1] = 0;
    }
  else {
    XbWMFX_PTS[strlen(str)] = 0;
    }
  while((XbWMFX_PTS[strlen(XbWMFX_PTS)-1] == ' ') & (strlen(XbWMFX_PTS) > 0)) {
    XbWMFX_PTS[strlen((char *)XbWMFX_PTS)-1] = 0;
    }
  return(XbWMFX_PTS);
  }
/*}}}  */
/*{{{  char *XbWMFX_MyStrUpr(char*sstr){*/
char *XbWMFX_MyStrUpr(char*sstr){
  int ll;
  for (ll=0;sstr[ll]!=0;ll++){
    sstr[ll]&=0xDF;
    }
  return(sstr);
  }
/*}}}  */
/*{{{  int XbWMFX_MyStrICmp(char *sstra,char*sstrb){*/
int XbWMFX_MyStrICmp(char *sstra,char*sstrb){
  char sstr1[200],sstr2[200];
  strcpy(sstr1,sstra);
  strcpy(sstr2,sstrb);
  XbWMFX_MyStrUpr(sstr1);XbWMFX_MyStrUpr(sstr2);
  return(strcmp(sstr1,sstr2));
  }
/*}}}  */
/*{{{  #define XbWMFX_MaxNames 5*/
#define XbWMFX_MaxNames 5
FILE
  *XbWMFX_File;
char
  XbWMFX_FilName[80],
  XbWMFX_Filezeile[255];
int
  XbWMFX_FilZlNr,
  XbWMFX_AktName,
  XbWMFX_ReadErr = 0;
int
  XbWMFX_Debug = 0;
char
  XbWMFX_FStrNames[XbWMFX_MaxNames][200];
/*}}}  */
char *XbWMFX_GetLine(void){
  XbWMFX_FilZlNr++;
  return(fgets(XbWMFX_Filezeile,253,XbWMFX_File));
  }
int XbWMFX_ReadSet( char *filename, char *dataset){
  /*{{{  */
  int ll;
  unsigned char ende;
  int found;
  char namestr[255];
  XbWMFX_FilZlNr = 0;
  for (ll=0;ll<XbWMFX_MaxNames;ll++){
    strcpy(XbWMFX_FStrNames[ll],"\0");
    }
  strcpy(XbWMFX_FilName,filename);
  found = 0;
  XbWMFX_ReadErr = 0;
  if ((XbWMFX_File = fopen(filename,"r")) == NULL) {
    return(1);
    }
  ende = 0;
  while (!ende) {
    if (XbWMFX_GetLine() == NULL) {
      ende = 1;}
    else {
      if (strstr(XbWMFX_Filezeile,"\\VarStructContents{") != NULL) {
        if (XbWMFX_GetLine() == NULL) {
          return(1);
          }
        else {
          if (
                (strstr(XbWMFX_Filezeile,"{") != NULL) &
                (strstr(XbWMFX_Filezeile,"}") != NULL)
             ) {
            strncpy(namestr,strstr(XbWMFX_Filezeile,"{")+1,250);
            strcpy(strstr(namestr,"}"),"\0");;
            if ((strcmp(namestr,dataset)==0)|(strcmp(dataset,"*")==0)) {
              ende = 1;
              found = 1;
              }
            else {
              if (XbWMFX_AktName < XbWMFX_MaxNames) {
                strcpy(XbWMFX_FStrNames[XbWMFX_AktName],namestr);
                }
              XbWMFX_AktName++;
              }
            }
          }
        }
      }
    }
  if (!found){ return(1); }
  return(0);
  }
  /*}}}  */
int XbWMFX_GetInteger(int *variable){
  /*{{{  */
  char sstr[255];
  XbWMFX_GetLine();
  while (*(char *)XbWMFX_PckTxt(XbWMFX_Filezeile) == '%') {
    if (feof(XbWMFX_File)){ return(1);}
    XbWMFX_GetLine();
    }
  if (*(char *)XbWMFX_PckTxt(XbWMFX_Filezeile) != 'i') { return(1); }
  strncpy(sstr,strstr(XbWMFX_Filezeile,"i")+1,255);
  *(char *)strstr(sstr,",") = 0;
  *variable = atoi((char *)XbWMFX_PckTxt(sstr));
  return(0);
  }
  /*}}}  */
int XbWMFX_GetShort(short *variable){
  /*{{{  */
  char sstr[255];
  XbWMFX_GetLine();
  while (*(char *)XbWMFX_PckTxt(XbWMFX_Filezeile) == '%') {
    if (feof(XbWMFX_File)){ return(1);}
    XbWMFX_GetLine();
    }
  if (*(char *)XbWMFX_PckTxt(XbWMFX_Filezeile) != 'i') { return(1); }
  strncpy(sstr,strstr(XbWMFX_Filezeile,"i")+1,255);
  if (strstr(sstr,",") != NULL){
    *(char *)strstr(sstr,",") = 0;
    }
  *variable = (short)(atoi((char *)XbWMFX_PckTxt(sstr)));
  return(0);
  }
  /*}}}  */
int XbWMFX_GetDouble(double *variable){
  /*{{{  */
  char sstr[255];
  XbWMFX_GetLine();
  while (*(char *)XbWMFX_PckTxt(XbWMFX_Filezeile) == '%') {
    if (feof(XbWMFX_File)){ return(1);}
    XbWMFX_GetLine();
    }
  if (*((char *)XbWMFX_PckTxt(XbWMFX_Filezeile)) != '{') { return(1); }
  strncpy(sstr,strstr(XbWMFX_Filezeile,"{")+1,255);
  if (strstr(sstr,"}") != NULL) {
    *(char *)strstr(sstr,"}") = 0;
    }
  else {return(1);}
  *variable = atof((char *)XbWMFX_PckTxt(sstr));
  return(0);
  }
  /*}}}  */
int XbWMFX_GetString(char *variable){
  /*{{{  */
  char sstr[255];
  
  XbWMFX_GetLine();
  while (*(char *)XbWMFX_PckTxt(XbWMFX_Filezeile) == '%') {
    if (feof(XbWMFX_File)){ return(1);}
    XbWMFX_GetLine();
    }
  if (*((char *)XbWMFX_PckTxt(XbWMFX_Filezeile)) != '{') { return(1); }
  strncpy(sstr,strstr(XbWMFX_Filezeile,"{")+1,253);
  sstr[253]=0;
  if (strstr(sstr,"}") != NULL) {
    *(char *)strstr(sstr,"}") = 0;
    }
  else {return(1);}
  strcpy(sstr,(char *)XbWMFX_PckTxt(sstr));
  strcpy(variable,sstr);
  return(0);
  }
  /*}}}  */
int XbWMFX_WriteSet( char *filename, char *dataset, char *mode){
  /*{{{  */
  XbWMFX_File = fopen(filename,mode);
  if (XbWMFX_File == NULL) { return(1); }
  if (mode[0]=='a'){
    fseek(XbWMFX_File,0,SEEK_END);
    }
  fputs("\\VarStructContents{\n",XbWMFX_File);
  fputs(" {",XbWMFX_File);
  fputs(dataset,XbWMFX_File);
  fputs("}}\n",XbWMFX_File);
  return(0);
  }
  /*}}}  */
void XbWMFX_PutShort(short *variable,  char *comment){
  fprintf(XbWMFX_File," i%d, %s\n",(int)*variable, comment);}
void XbWMFX_PutInteger(int *variable,  char *comment){
  fprintf(XbWMFX_File," i%d, %s\n",*variable, comment);}
void XbWMFX_PutDouble(double *variable,  char *comment){
  fprintf(XbWMFX_File," {%25.12f}, %s\n",*variable, comment);}
void XbWMFX_PutString(char *variable, char *comment){
  if (variable == NULL) {
    fprintf(XbWMFX_File," {(null)}, %s\n", comment);
    }
  else {
    fprintf(XbWMFX_File," {%s}, %s\n",variable, comment);
    }
  }
void XbWMFX_WriteEnd(void){
  fputs("\\EndOfVarStructure;\n",XbWMFX_File);}
void XbWMFX_CloseSet(void){
  fclose(XbWMFX_File);}


