
#define ProgramName adder

typedef struct {
  char Cmd[20];    /* Command */
  int A;           /* Number A */
  int B;           /* Number B */
  int Sum;
  int Display;     /* Activates Object that has Sum */
  } MFI;

extern MFI mfi;

#ifdef MFI_INIT
MFI mfi = {
  "A",
  1,2,
  0,
  0
  };
#endif

