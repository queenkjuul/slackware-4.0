 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*                                                                           */
/*   Modul X2.C                                                              */
/*                                                                           */
/*   XbWFOs - Oszilloskop-Routinen                                           */
/*   XbWFTb - Toolbox-Routinen                                               */
/*   XbWFBV - Objektverwaltung                                               */
/*                                                                           */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


/* Header--------------------------------------------------------------------*/

#include "xbw.h"

/*  --------------------------Compiler-Modelle-------------------------------*/
                      /* ***................Unabh�ngig         */
                      /* ---................Nicht m�glich      */
                      /* !!!................Noch zu machen     */
                      /* ???................unklar             */
                      /* OSC................Wenn UseOsc def    */
                      /*     PRJ............Fuer Projekteditor */
                      /*     TC3............Turbo-C Version    */
                      /*         GNU........32-Bit Version     */
                      /*             X11....X-Window           */


/*{{{  XbWFOb_GetPar(      ***      Parametersatz fur ein Obj. lesen*/
char  *XbWFOb_GetPar(
    XbWDDb_DbIWdw  *WI,
    XbWDDb_DbIObj  *TO, char *sname, int mode){
  XbWDDb_DbIPtr *ip;

  if (mode&XbWDOb_GtFrsO){
    ip = (XbWDDb_DbIPtr*)WI->obj;
    XbWVOb_GOPao = XbWFDb_CDbIToPtr(*ip,XbWDDb_DbISys);
    XbWVOb_GOPao = (XbWDDb_DbIVar  *)XbWFDb_NextGrp(XbWVOb_GOPao,NULL);
    }
  else {
    if (mode&XbWDOb_GtNxtO) {
      XbWVOb_GOPao = (XbWDDb_DbIVar  *)XbWFDb_NextGrp(XbWVOb_GOPao,NULL);
      }
    else {
      if (mode&XbWDOb_GetAnO) {
        ip = (XbWDDb_DbIPtr*)WI->obj;
        XbWVOb_GOPao = (XbWDDb_DbIVar  *)XbWFDb_NextGrp(XbWFDb_CDbIToPtr(*ip,XbWDDb_DbISys),
          sname);
        }
      else {
        if (mode&XbWDOb_GtLstO) {
          XbWDDb_DbIVar  *GetObjPar_to = NULL;
          ip = (XbWDDb_DbIPtr*)WI->obj;
          XbWVOb_GOPao = XbWFDb_CDbIToPtr(*ip,XbWDDb_DbISys);
          while ((XbWVOb_GOPao = (XbWDDb_DbIVar  *)
              XbWFDb_NextGrp(XbWVOb_GOPao,NULL)) != NULL) {
            char *f_nm;
            XbWDDb_DbIVar  *TV = XbWVOb_GOPao;
            if ((TV->tp & XbWDDb_Typ) == XbWDDb_Str) {
              f_nm = (char*)&( ((XbWDDb_DbIStr *)TV)->nmi[TV->tp & XbWDDb_NLen]);
              }
            else {
              f_nm = (char*)XbWFDb_GetInh(TV,XbWDDb_Str);
              };
            if (XbWFTb_CmpStr((char*)WI->nm,f_nm) == 0) {
              GetObjPar_to = XbWVOb_GOPao;
              }
            else {
              goto gt_OBJ_weiter;
              };
            };
          gt_OBJ_weiter:;
          if (GetObjPar_to == NULL) {
            XbWVOb_GOPao = XbWFDb_CDbIToPtr(*ip,XbWDDb_DbISys);
            }
          else {
            XbWVOb_GOPao = GetObjPar_to;
            };
          }
        else {
          if (mode&XbWDOb_GtAnfO) {
            ip = (XbWDDb_DbIPtr*)WI->obj;
            XbWVOb_GOPao = XbWFDb_CDbIToPtr(*ip,XbWDDb_DbISys);
            };
          };
        };
      };
    };

  {
    XbWDDb_DbIVar  *TV = NULL;

    if (mode&XbWDOb_GtMinP) {

      TV = XbWVOb_GOPao;
      if (TV == NULL) { return(NULL); };
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Str) {
        TO->onm = (char*)&( ((XbWDDb_DbIStr *)TV)->nmi[TV->tp & XbWDDb_NLen]);
        }
      else {
        TO->onm = (char*)XbWFDb_GetInh(TV,XbWDDb_Str);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);

      if ((TV->tp & XbWDDb_Typ) == XbWDDb_NPtr) {
        TO->nxt = (XbWDDb_DbIPtr  *) &((XbWDDb_DbINPtr *)TV)->inh;
        }
      else {
        TO->nxt = NULL;
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);

      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Str) {
        TO->wdw = (char*)&( ((XbWDDb_DbIStr *)TV)->nmi[TV->tp & XbWDDb_NLen]);
        }
      else {
        TO->wdw = (char*)XbWFDb_GetInh(TV,XbWDDb_Str);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->XA = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->XA = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->YA = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->YA = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->XB = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->XB = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->YB = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->YB = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWVOb_GOPlv = TV;
      XbWVOb_GOPnm = (char *)TO->onm;

      };

    if (mode&(XbWDOb_GtDspP|XbWDOb_GtEdtP)) {
      if (TV != NULL) {
        XbWFDb_ForWd(&TV,XbWDDb_DbISys);
        }
      else {
        if ((char*)TO->onm == (char*)XbWVOb_GOPnm) {
          TV = XbWVOb_GOPlv;
          XbWFDb_ForWd(&TV,XbWDDb_DbISys);
          }
        else {
          return(NULL);
          };
        };

      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->bkc = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->bkc = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->bfc = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->bfc = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->dfc = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->dfc = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->txc = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->txc = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Str) {
        TO->odt = (char*)&( ((XbWDDb_DbIStr *)TV)->nmi[TV->tp & XbWDDb_NLen]);
        }
      else {
        TO->odt = (char*)XbWFDb_GetInh(TV,XbWDDb_Str);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->dst = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->dst = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->est = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->est = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Int) {
        TO->dwd = (int *) &((XbWDDb_DbIInt *)TV)->inh;
        }
      else {
        TO->dwd = (int *)XbWFDb_GetInh(TV,XbWDDb_Int);
        };

      XbWFDb_ForWd(&TV,XbWDDb_DbISys);
      if ((TV->tp & XbWDDb_Typ) == XbWDDb_Str) {
        TO->oet = (char*)&( ((XbWDDb_DbIStr *)TV)->nmi[TV->tp & XbWDDb_NLen]);
        }
      else {
        TO->oet = (char*)XbWFDb_GetInh(TV,XbWDDb_Str);
        };
      TO->chn = TV;
      };

    };
  return(TO->onm);
  };
/*}}}  */
/*{{{  XbWFOb_epO(         ***      Edit Previous Object: epO*/
int  XbWFOb_epO(char *name){
  int ii; char sstr[20]; char *mf_n;
  XbWDDb_DbIVar  *grst;

  for (ii=0;ii<100;ii++){
    sprintf(sstr,"epO%d",ii);
    {
      XbWDDb_DbIObj XbWVOb_O;
      XbWDDb_DbIVar  *gs;

      if ((gs = XbWFDb_CDbIToPtr(*XbWVWd_W.obj,XbWDDb_DbISys)) == NULL) { return(1);};

      if ((grst = XbWFDb_NextGrp(gs,name)) != NULL) {
        if ((mf_n = (char*)XbWFDb_VarInh(grst,XbWDDb_Str,sstr,1)) != NULL) {
          XbWVOb_O.onm = NULL;
          if (XbWFOb_GetPar(&XbWVWd_W,&XbWVOb_O,mf_n,XbWDOb_GtAllP|XbWDOb_GetAnO) != NULL){
            XbWVEd_nxt = Vor;
            XbWFOj_DiEdContents(&XbWVWd_W,&XbWVOb_O,1);
            if (XbWVEd_nxt == CursorUp) {
              XbWFOb_epO((char*)XbWVOb_O.onm);
              };
            XbWSMs_WButtUp();
            };
          };
        }
      else {
        ii = 110;
        };
      };
    };
  return(0);
  };

/*}}}  */
/*{{{  XbWFOb_ebO(         ***      Edit Before Object: bW,rbK,ebO,wbX,rbT*/
int  XbWFOb_ebO(XbWDDb_DbIObj  *MOB){
  int ii; char sstr[29]; char *mf_n;
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"bW%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFWd_SwitchTo(mf_n,16);
      }
    else {
      ii = 110;
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"rbK%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFMf_ReadMakro(mf_n);
      }
    else {
      ii = 110;
      };
    };
  if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_FPtr,"rbC",0)) != NULL) {
    XbWFMf_RdCompMak(XbWVDb_ActGrp2);
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"ebO%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFOb_EdDpObj(mf_n,4);
      }
    else {
      ii = 110;
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"wbX%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFMx_RWGrp(mf_n,"WRITE",0,0,NULL);
      }
    else {
      ii = 110;
      };
    };

  for (ii=0;ii<100;ii++){
    sprintf(sstr,"rbT%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFMf_ReadMF(mf_n);
      }
    else {
      ii = 110;
      };
    };

  return(0);
  };

/*}}}  */
/*{{{  XbWFOb_Edit(        ***      Edit: raK,raT,raX,aW des Obj.*/
int  XbWFOb_Edit(XbWDDb_DbIObj  *MOB){
  int ii; char sstr[20]; char *mf_n;
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"raX%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFMx_RWGrp(mf_n,"READ",0,0,NULL);
      }
    else {
      ii = 110;
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"raT%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFMf_ReadMF(mf_n);
      }
    else {
      ii = 110;
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"aW%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFWd_SwitchTo(mf_n,16);
      }
    else {
      ii = 110;
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"oW%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFWd_SwitchTo(mf_n,48);
      }
    else {
      ii = 110;
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"raK%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFMf_ReadMakro(mf_n);
      }
    else {
      ii = 110;
      };
    };
  if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_FPtr,"raC",0)) != NULL) {
    XbWFMf_RdCompMak(XbWVDb_ActGrp2);
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"dpO%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFOb_EdDpObj(mf_n,0);
      }
    else {
      ii = 110;
      };
    };
  return(0);
  };
/*}}}  */
/*{{{  XbWFOb_eqO(         ***      Edit Queue: rqX,rqT,eqO,dqO des Objektes*/
int  XbWFOb_eqO(XbWDDb_DbIObj  *MOB){
  int ii; char sstr[20]; char *mf_n;
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"rqX%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFMx_RWGrp(mf_n,"READ",0,0,NULL);
      }
    else {
      ii = 110;
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"rqT%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFMf_ReadMF(mf_n);
      }
    else {
      ii = 110;
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"qW%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFWd_SwitchTo(mf_n,16);
      }
    else {
      ii = 110;
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"rqK%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFMf_ReadMakro(mf_n);
      }
    else {
      ii = 110;
      };
    };
  if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_FPtr,"rqC",0)) != NULL) {
    XbWFMf_RdCompMak(XbWVDb_ActGrp2);
    };
  if (XbWVEd_nxt != CursorUp) {
    for (ii=0;ii<100;ii++){
      if (XbWVEd_nxt != EndInput) {
        sprintf(sstr,"eqO%d",ii);
        if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
          XbWVEd_nxt = Vor;
          XbWFOb_EdDpObj(mf_n,1);
          if (XbWVEd_nxt == CursorUp) {
            XbWFOb_epO(mf_n);
            };
          if (XbWVEd_nxt == EndInput) {
            ii = 110;
            };
          }
        else {
          ii = 110;
          };
        };
      };
    };
  for (ii=0;ii<100;ii++){
    sprintf(sstr,"dqO%d",ii);
    if ((mf_n = (char*)XbWFDb_VarInh(MOB->chn,XbWDDb_Str,sstr,1)) != NULL) {
      XbWFOb_EdDpObj(mf_n,0);
      }
    else {
      ii = 110;
      };
    };
  return(0);
  };
/*}}}  */
/*{{{  XbWFOb_dpO(         ***      dpO ausfuhren fur ein Objekt*/
void  XbWFOb_dpO(
    XbWDDb_DbIWdw  *WI, XbWDDb_DbIObj  *NotDispObj){
  int win_found;
  int sr_mod = XbWDOb_GtMinP | XbWDOb_GtFrsO;
  int cursormrk = XbWVMs_CSet;

  XbWDDb_DbIObj MOB; char *obj_name; MOB.onm = NULL;

  XbWFGr_CurOFF();
  obj_name = NULL;

  win_found=0;
  while ((obj_name = (char*)XbWFOb_GetPar(
         &XbWVWd_W,
         &MOB,obj_name,sr_mod)) != NULL){
    sr_mod = XbWDOb_GtMinP | XbWDOb_GtNxtO;
    if (MOB.onm != NULL) {
      if (NotDispObj != NULL) {
        if (XbWFTb_CmpStr((char*)NotDispObj->onm,(char*)MOB.onm) == 0) {
          goto weiter;
          };
        };
      if (XbWFTb_CmpStr((char*)WI->nm,(char*)MOB.wdw) != 0) {
        if (win_found){
          goto ende_dpalleobj;
          };
        }
      else {
        win_found = 1;
        if (XbWFTb_CmpBox(*MOB.XA,*MOB.YA,*MOB.XB,*MOB.YB,  0,0,
            *WI->sx,  *WI->sy) != 0){
          XbWFOb_GetPar(WI,&MOB,(char*)MOB.onm,XbWDOb_GtDspP);
          XbWFOj_DiEdContents(WI,&MOB,0);
          };
        };
      weiter:;
      };
    };

  ende_dpalleobj:
  if (cursormrk){
    XbWFGr_CurON();
    };

  };

/*}}}  */
/*{{{  XbWFOj_EdCalc(      ***      Edit CALC: Ausfuehren einer Berechnung*/
int  XbWFOj_EdCalc(int edit, XbWDDb_DbIObj  *TO){
  XbWDDb_DbIVar  *TV;
  char *sstr; int display; double value;
  int reg;
  double regs[10];

  if (edit == 3){ return(0); };
  display = XbWFDb_GetNum(TO->chn,"#D",1);
  value = XbWFDb_GetNum(TO->chn,"V",1);
  TV = (XbWDDb_DbIVar  *)TO->chn;
  while(1){
    if(((TV->tp)&XbWDDb_Typ) == XbWDDb_GPtr){
      XbWFDb_PutNum(TO->chn,"V",1,value);
      if (display){
        XbWFOj_GetNum(TO);
        XbWSGr_RBBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,XbWVOb_GTxt,*TO->bkc,*TO->txc,*TO->bfc);
        };
      return(0);
      };
    sstr = (char*)XbWFDb_GetNam((XbWDDb_DbIVar  *)TV);
    if (sstr[0] == '#'){
      switch(sstr[1]){
        case 'R':
          switch(sstr[2]){
            case 'M':
              reg = sstr[3] - '0';
              XbWFDb_PutNum(TV,NULL,1,regs[reg]);
              break;
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
            switch(sstr[3]){
              case '*':
                reg = sstr[2] - '0';
                regs[reg] = (double)regs[reg] * (double) XbWFDb_GetNum(TV,NULL,1);
                break;
              case '=':
                reg = sstr[2] - '0';
                regs[reg] = XbWFDb_GetNum(TV,NULL,1);
                break;
              case '+':
                reg = sstr[2] - '0';
                regs[reg] = (double)regs[reg] + (double) XbWFDb_GetNum(TV,NULL,1);
                break;
              case '-':
                reg = sstr[2] - '0';
                regs[reg] = (double)regs[reg] - (double) XbWFDb_GetNum(TV,NULL,1);
                break;
              case '/':
                reg = sstr[2] - '0';
                if (regs[reg] != 0){
                  regs[reg] = (double)regs[reg] / (double) XbWFDb_GetNum(TV,NULL,1);
                  };
                break;
              case 'C':
                reg = sstr[2] - '0';
                regs[reg] = 0;
                break;
              };
              break;
            case '=': regs[(int)XbWFDb_GetNum(TV,NULL,1)]  = value; break;
            case '-': regs[(int)XbWFDb_GetNum(TV,NULL,1)] = (double)regs[(int)XbWFDb_GetNum(TV,NULL,1)] - (double) value; break;
            case '+': regs[(int)XbWFDb_GetNum(TV,NULL,1)] = (double)regs[(int)XbWFDb_GetNum(TV,NULL,1)] + (double) value; break;
            case '*': regs[(int)XbWFDb_GetNum(TV,NULL,1)] = (double)regs[(int)XbWFDb_GetNum(TV,NULL,1)] * (double) value; break;
            case '/':
              if (value != 0){
                regs[(int)XbWFDb_GetNum(TV,NULL,1)] =(double)regs[(int)XbWFDb_GetNum(TV,NULL,1)] / (double) value;
                };
              break;
            };
          break;
        case 'r':
          switch(sstr[2]){
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
            switch(sstr[3]){
              case '=':
                reg = sstr[2] - '0';
                regs[reg] = regs[(int)XbWFDb_GetNum(TV,NULL,1)];
                break;
              case '+':
                reg = sstr[2] - '0';
                regs[reg] =(double)regs[reg] + (double)  regs[(int)XbWFDb_GetNum(TV,NULL,1)];
                break;
              case '-':
                reg = sstr[2] - '0';
                regs[reg] =(double)regs[reg] - (double)  regs[(int)XbWFDb_GetNum(TV,NULL,1)];
                break;
              case '*':
                reg = sstr[2] - '0';
                regs[reg] =(double)regs[reg] * (double)  regs[(int)XbWFDb_GetNum(TV,NULL,1)];
                break;
              case '/':
                reg = sstr[2] - '0';
                if (XbWFDb_GetNum(TV,NULL,1) != 0){
                  regs[reg] =(double)regs[reg] / (double)  regs[(int)XbWFDb_GetNum(TV,NULL,1)];
                  };
                break;
              case 'C':
                reg = sstr[2] - '0';
                regs[reg] = 0;
                break;
              };
              break;
            case '=': regs[(int)XbWFDb_GetNum(TV,NULL,1)]  = value; break;
            case '-': regs[(int)XbWFDb_GetNum(TV,NULL,1)]  =(double)regs[(int)XbWFDb_GetNum(TV,NULL,1)] - (double)  value; break;
            case '+': regs[(int)XbWFDb_GetNum(TV,NULL,1)]  =(double)regs[(int)XbWFDb_GetNum(TV,NULL,1)] + (double)  value; break;
            case '*': regs[(int)XbWFDb_GetNum(TV,NULL,1)]  =(double)regs[(int)XbWFDb_GetNum(TV,NULL,1)] * (double)  value; break;
            case '/':
              if (value != 0){
                regs[(int)XbWFDb_GetNum(TV,NULL,1)] = (double)regs[(int)XbWFDb_GetNum(TV,NULL,1)] / (double)  value;
                };
              break;
            };
          break;
        case '+':
          if (sstr[2] == 'R'){
            reg = XbWFDb_GetNum(TV,NULL,1);
            value = (double)value + (double) regs[reg]; }
          else { value += XbWFDb_GetNum(TV,NULL,1); };
          break;
        case '=':
          if (sstr[2] == 'R'){
            reg = XbWFDb_GetNum(TV,NULL,1);
            value = regs[reg]; }
          else { value  = XbWFDb_GetNum(TV,NULL,1); };
          break;
        case '-':
          if (sstr[2] == 'R'){
            reg = XbWFDb_GetNum(TV,NULL,1);
            value =(double)value - (double) regs[reg]; }
          else { value =(double)value - (double) XbWFDb_GetNum(TV,NULL,1); };
          break;
        case '*':
          if (sstr[2] == 'R'){
            reg = XbWFDb_GetNum(TV,NULL,1);
            value =(double)value * (double) regs[reg]; }
          else { value =(double)value * (double) XbWFDb_GetNum(TV,NULL,1); };
          break;
        case '/':
          if (sstr[2] == 'R'){
            reg = XbWFDb_GetNum(TV,NULL,1);
            if (regs[reg] != 0){
              value =(double)value / (double) regs[reg];
              };
            }
          else {
            if (XbWFDb_GetNum(TV,NULL,1) != 0){
              value =(double)value / (double) XbWFDb_GetNum(TV,NULL,1);
              };
            };
          break;
        };
      };
    XbWFDb_ForWd(&TV,XbWDDb_DbISys);
    };
  };
/*}}}  */
/*{{{  XbWFOb_EdObjMausPos(***      Edit fur ein angeklicktes Objekt*/
void  XbWFOb_EdObjMausPos(
    XbWDDb_DbIWdw  *WI, int mausxa, int mausya){
  int mxa,mya;
  XbWDDb_DbIObj MOB;
  int aToEdit,vToEdit,win_found;
  char *obj_name;char afname[32],vfname[32];
  int sr_mod = XbWDOb_GtMinP | XbWDOb_GtFrsO;

  mxa = mausxa- *WI->nx; mya = mausya- *WI->ny -1;
  MOB.onm = NULL;

  aToEdit = vToEdit = 0;

  win_found = 0;
  obj_name = NULL;
  while ((obj_name = (char*)XbWFOb_GetPar(
      &XbWVWd_W,&MOB,obj_name,sr_mod)) != NULL){
    sr_mod = XbWDOb_GtMinP | XbWDOb_GtNxtO;
    if (MOB.wdw != NULL) {
      if (XbWFTb_CmpStr((char*)WI->nm,(char*)MOB.wdw) != 0) {
        if (win_found){goto weiter;};
        }
      else {
        win_found = 1;
        if ( (mxa>= *MOB.XA)&(mya>= *MOB.YA)&(mxa<= *MOB.XB)&(mya<= *MOB.YB)){
          strcpy(afname,(char*)MOB.onm);
          aToEdit = 1;
        };};
      };
    };
  weiter:;

  if (!(aToEdit+vToEdit)){
    if (XbWVWd_RedrawON) {
      XbWFWd_Draw();
      XbWFWd_Rebuild();
      };
    XbWFGr_CurOFF();
    return;
    };

  obj_name = NULL;
  if (aToEdit){
    strcpy(vfname,afname);
    };
  if ((obj_name = (char*)XbWFOb_GetPar(
      WI,&MOB,vfname,XbWDOb_GtAllP|XbWDOb_GetAnO)) != NULL){
    XbWVOb_ox = mxa;
    XbWVOb_oy = mya;
    XbWVOb_EdLvl++;
    XbWFGr_CurOFF();
    XbWFOj_DiEdContents(WI,&MOB,3);
    XbWFOb_ebO(&MOB);
    XbWFOb_GetPar(WI,&MOB,vfname,XbWDOb_GtAllP|XbWDOb_GetAnO);
    XbWVEd_nxt = Vor;
    XbWFOj_DiEdContents(WI,&MOB,1);
    if (XbWVEd_nxt == CursorUp) {
      XbWFOb_epO((char*)MOB.onm);
      };

    {
      int ii;
      char *obn;
      char sstr[100];
      for (ii=0;ii<100;ii++){
        sprintf(sstr,"edO%d",ii);
        if ((obn = (char*)XbWFDb_VarInh(MOB.chn,XbWDDb_Str,sstr,1)) != NULL) {
          XbWVEd_nxt = Vor;
          XbWFOb_EdDpObj(obn,1);
          if (XbWVEd_nxt == CursorUp) {
            XbWFOb_epO(obn);
            };
          if (XbWVEd_nxt != Vor) {
            ii = 110;
            };
          }
        else {
          ii= 110;
          };
        };
      }
 
 
    XbWFOb_Edit(&MOB);

    XbWVOb_EdLvl--;
    if (!XbWVOb_EdLvl){
      XbWFOb_eqO(&MOB);
      };

    if (*MOB.dwd){
      if (XbWFTb_CmpStr((char*)XbWVWd_W.nm,(char*)MOB.onm) != 0){
        XbWFWd_Draw();
        };
      XbWFWd_Rebuild();
      };
    };
  };


/*}}}  */
/*{{{  XbWFOb_EditAndDisp( ***      Editier-Hauptroutine*/
int  XbWFOb_EditAndDisp(char *obn,int mode){
  XbWDDb_DbIObj MOB;
  MOB.onm = NULL;
  if (XbWFOb_GetPar(&XbWVWd_W,&MOB,obn,XbWDOb_GtAllP|XbWDOb_GetAnO) != NULL){
    XbWFWd_SwitchTo((char*)MOB.wdw,0x10);
    if (mode != 4){
      if (mode){
        XbWVOb_EdLvl++;
        XbWFGr_CurOFF();
        XbWFOj_DiEdContents(&XbWVWd_W,&MOB,3);
        XbWFOb_ebO(&MOB);
        XbWFOb_GetPar(&XbWVWd_W,&MOB,(char*)MOB.onm,XbWDOb_GtAllP|XbWDOb_GetAnO);
        XbWVEd_nxt = Vor;
        XbWFOj_DiEdContents(&XbWVWd_W,&MOB,1);
        if (XbWVEd_nxt == CursorUp) {
          XbWFOb_epO((char*)MOB.onm);
          };
        XbWFOb_Edit(&MOB);

        {
          int ii;
          char *obn;
          char sstr[100];
          for (ii=0;ii<100;ii++){
            sprintf(sstr,"edO%d",ii);
            if ((obn = (char*)XbWFDb_VarInh(MOB.chn,XbWDDb_Str,sstr,1)) != NULL) {
              XbWVEd_nxt = Vor;
              XbWFOb_EdDpObj(obn,1);
              if (XbWVEd_nxt == CursorUp) {
                XbWFOb_epO(obn);
                };
              if (XbWVEd_nxt != Vor) {
                ii = 110;
                };
              }
            else {
              ii= 110;
              };
            };
          }
 
        XbWVOb_EdLvl--;
        if (!XbWVOb_EdLvl){
          XbWFOb_eqO(&MOB);
          };
 
        if (*MOB.dwd){
          if (XbWFTb_CmpStr((char*)XbWVWd_W.nm,(char*)MOB.onm) != 0){
            XbWFWd_Draw();
            };
          XbWFWd_Rebuild();
          };
        };
      };
    return(0);
    };
  return(1);
  };

/*}}}  */
/*{{{  XbWFOb_EditOnly(    ***      Aufruf EditAndDisp als Edit*/
int  XbWFOb_EditOnly(void  *(*p)[]){
  if ((int)(*p)[0] != 1){return(1);};
  return(XbWFOb_EditAndDisp((char*)(*p)[1],1));
  };
/*}}}  */
/*{{{  XbWFOb_DispOnly(    ***      Aufruf EditAndDisp als Disp*/
int  XbWFOb_DispOnly(void  *(*p)[]){
  if ((int)(*p)[0] != 1){return(1);};
  return(XbWFOb_EdDpObj((char*)(*p)[1],0));
  };
/*}}}  */
/*{{{  XbWFOb_MovToPos(    ***      Objektmove mit mittl. Maustaste*/
void  XbWFOb_MovToPos(
    XbWDDb_DbIWdw  *WI, int mausxa, int mausya){
  int mxa,mya;
  XbWDDb_DbIObj MOB;
  int aToEdit,vToEdit,win_found,select_xbw_setup = 0;
  char *obj_name;char afname[32],vfname[32];
  int sr_mod = XbWDOb_GtMinP | XbWDOb_GtFrsO;
 
  mxa = mausxa- *WI->nx; mya = mausya- *WI->ny;
  MOB.onm = NULL;

  aToEdit = vToEdit = 0;

  win_found = 0;
  obj_name = NULL;
  while ((obj_name = (char*)XbWFOb_GetPar(
      &XbWVWd_W,&MOB,obj_name,sr_mod)) != NULL){
    sr_mod = XbWDOb_GtMinP | XbWDOb_GtNxtO;
    if (MOB.wdw != NULL) {
      if (XbWFTb_CmpStr((char*)WI->nm,(char*)MOB.wdw) != 0) {
        if (win_found){goto weiter;};
        }
      else {
        win_found = 1;
        XbWVOb_X = *MOB.XA;  XbWVOb_Y = *MOB.YA;
        XbWVOb_x = *MOB.XB;  XbWVOb_y = *MOB.YB;
        if ( (mxa>= *MOB.XA)&(mya>= *MOB.YA)&(mxa<= *MOB.XB)&(mya<= *MOB.YB)){
          strcpy(afname,(char*)MOB.onm);
          aToEdit = 1;
        };};
      };
    };
  weiter:;

  if (!(aToEdit+vToEdit)){ XbWFGr_CurOFF(); return;};

  obj_name = NULL;
  if (aToEdit){
    strcpy(vfname,afname);
    };
  if ((obj_name = (char*)XbWFOb_GetPar(
      WI,&MOB,vfname,XbWDOb_GtAllP|XbWDOb_GetAnO)) != NULL){


    XbWVOb_ox = mxa;
    XbWVOb_oy = mya;
    XbWVOb_EdLvl++;

    XbWSMs_WButtUp();

    XbWFGr_CurOFF();

    {
      int xa,ya;
      int oxa,oya;

      XbWVOb_X = *MOB.XA;  XbWVOb_Y = *MOB.YA;
      XbWVOb_x = *MOB.XB;  XbWVOb_y = *MOB.YB;
      mxa = XbWVMs_XPos; mya = XbWVMs_YPos;

      oxa = mxa; oya = mya;

      xa = oxa - (mxa - XbWVMs_XPos)/2;
      ya = oya - (mya - XbWVMs_YPos)/2;
      XbWSMs_Warp(xa,ya);

      XbWSMs_DFramON(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,14);

      XbWSMs_Stat();
      XbWSMs_ChkMot();

   /*   while ( XbWVMs_Button == 0) {
        XbWSMs_Stat();
        XbWSMs_ChkMot();
        };
   */
      {
        XbWDDb_DbIVar  *gr_st;

        gr_st = XbWFDb_FindGrp("OBX","act");
        if (gr_st != NULL) {
          XbWFDb_PutStr(gr_st,"aln",1,"OBJ");
          XbWFDb_PutStr(gr_st,"agn",1,(char*)MOB.onm);
          XbWFDb_PutStr(gr_st,"awn",1,(char*)MOB.wdw);
          XbWFDb_PutNum(gr_st,"anr",1,0);
          };
        };
 
 select_xbw_setup=1;
 goto move_ende; /* Abk�fi HHM M�rz 94*/


      while ( XbWVMs_Button == 1) {
        if (XbWVMs_LButt == 0) {
          select_xbw_setup = 1;
          goto move_ende;
          };
        XbWSMs_Stat();
        XbWSMs_ChkMot();
        while (XbWVMs_Bewegt==0) {
          XbWSMs_Stat();
          XbWSMs_ChkMot();
          if (XbWVMs_Button == 0) { goto move_ende;};
          };
        XbWSMs_FramOFF(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y);
        xa = oxa - (mxa - XbWVMs_XPos)/2;
        ya = oya - (mya - XbWVMs_YPos)/2;
        XbWSMs_Warp(xa,ya);
        XbWVOb_X += xa - oxa;  XbWVOb_x += xa - oxa;
        XbWVOb_Y += ya - oya;  XbWVOb_y += ya - oya;
        mxa = oxa = xa; mya = oya = ya;
        XbWSMs_DFramON(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,14);
        };
      };

    move_ende:;
    XbWSMs_FramOFF(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y);

    *MOB.XA = XbWVOb_X;  *MOB.YA = XbWVOb_Y;
    *MOB.XB = XbWVOb_x;  *MOB.YB = XbWVOb_y;

    XbWFWd_Draw();
    XbWFWd_Rebuild();
    if (select_xbw_setup) {
      XbWFWd_SwitchTo("XXWS",0);
      XbWFWd_Draw();
      XbWFWd_Rebuild();
      };

    XbWSMs_WButtUp();
    };
  };

/*}}}  */
/*{{{  XbWFOb_MovToWdw(    ***      Obj. in and. Wdw verlegen; Listen-update*/
int  XbWFOb_MovToWdw( void  *(*p)[],int (*t)[]) {
  char *onm, *wnm;
  if ( (int)(*p)[0] < 2) {
    return(1);
    };
  switch ( (int)(*t)[1]) {
    case XbWDMf_StrPar: onm = (char*)(*p)[1]; break;
    case XbWDMf_VLPar:  {
                          XbWDDb_DbIVar  *QQ;
                          QQ = (XbWDDb_DbIVar  *)(*p)[1];
                          if (QQ == NULL) { return(1); };
                          onm = (char*)XbWFDb_VarInh(QQ,XbWDDb_Str,NULL,1);
                          break;
                          };
    default: return(1);;
    };
  switch ( (int)(*t)[2]) {
    case XbWDMf_StrPar: wnm = (char*)(*p)[2]; break;
    case XbWDMf_VLPar:  {
                          XbWDDb_DbIVar  *QQ;
                          QQ = (XbWDDb_DbIVar  *)(*p)[2];
                          if (QQ == NULL) { return(2); };
                          wnm = (char*)XbWFDb_VarInh(QQ,XbWDDb_Str,NULL,1);
                          break;
                          };
    default: return(1);;
    };
  if (XbWFOb_SubMovWdw( onm, wnm)) {
    XbWFTb_HBeep();
    XbWFTb_HBeep();
    };
  return(0);
  };
/*}}}  */
/*{{{  XbWFOb_SubMovWdw(   ***      Unterroutine dazu*/
int  XbWFOb_SubMovWdw( char *onm, char *wnm){
    XbWDDb_DbIObj VOB,MOB,NOB;
    char *obj_name, *oldname, *wname;
    int sr_mod = XbWDOb_GtMinP|XbWDOb_GtFrsO;
    VOB.onm = NULL;
    MOB.onm = NULL;
    obj_name = NULL;
    oldname = NULL;
  while ((obj_name = (char*)XbWFOb_GetPar(
      &XbWVWd_W,&MOB,obj_name,sr_mod)) != NULL){
    sr_mod = XbWDOb_GtMinP | XbWDOb_GtNxtO;
    if (MOB.wdw != NULL) {
      if (XbWFTb_CmpStr((char*)XbWVWd_W.nm,(char*)MOB.wdw) != 0) {
        goto weiter_motw;
        };

      if (XbWFTb_CmpStr((char*)onm,(char*)MOB.onm) == 0) {
        if (oldname == NULL) {
          XbWFOb_GetPar(&XbWVWd_W,&VOB,NULL,XbWDOb_GtMinP|XbWDOb_GtAnfO);
          }
        else {
          XbWFOb_GetPar(&XbWVWd_W,&VOB,oldname,XbWDOb_GtMinP|XbWDOb_GetAnO);
          };
        goto weiter_motw;
        };
      };
    oldname = obj_name;
    };

  weiter_motw:;
  if (MOB.onm == NULL) { return(1); };
  if (VOB.onm == NULL) { return(1); };
  wname = (char*)XbWVWd_W.nm;
  XbWFWd_SwitchTo(wnm,0);
  sr_mod = XbWDOb_GtMinP|XbWDOb_GtLstO;
  if (XbWFOb_GetPar(&XbWVWd_W,&NOB,NULL,sr_mod) != NULL){
    XbWDDb_DbIPtr iV,iN,iM;

    iV = *VOB.nxt;
    iN = *NOB.nxt;
    iM = *MOB.nxt;

    *NOB.nxt = iV;        /* Objekt an die neue Queue anhaengen */
    *MOB.nxt = iN;

    *VOB.nxt = iM;        /* Objekt aus der alten Queue nehmen */

    {
      char *ms;
      int vtp;
      int SL;
      XbWDDb_DbIVar  *T_OB;

      T_OB = (XbWDDb_DbIVar  *)XbWFDb_FindGrp("OBJ",(char*)MOB.onm);
      XbWFDb_GetInf(T_OB, -1, "W", &vtp, &ms, &SL, 0);
      switch (vtp) {
        case XbWDDb_NPtr: {
            XbWDDb_DbINPtr  *TSRC;
            if ((TSRC = (XbWDDb_DbINPtr  *)
                XbWFDb_FindGrp("WDW",(char*)XbWVWd_W.nm) ) == NULL) {
              return(1);
              };
            *((XbWDDb_DbIPtr*)ms) = XbWDDb_C_PtrToDbI(TSRC,XbWDDb_DbISys);
            };
          break;

        case XbWDDb_Str:
          XbWFDb_PutStr(T_OB,"W",1,(char*)XbWVWd_W.nm);
          break;

        };
      };

    };
  XbWFWd_SwitchTo(wname,0);

  return(0);
  };

/*}}}  */
/*{{{  XbWFOb_EdDpObj(     ***      Fuhrt edO aus*/
int  XbWFOb_EdDpObj(char *obn,int mode){
  XbWFOb_EditAndDisp(obn,mode);
  return(0);
 
  /* XbWDDb_DbIObj MOB; */
  /* MOB.onm = NULL;  */
  /* if (XbWFOb_GetPar(&XbWVWd_W,&MOB,obn,XbWDOb_GtAllP|XbWDOb_GetAnO) != NULL){ */
  /* XbWFOj_DiEdContents(&XbWVWd_W,&MOB,mode); */
  /* if (mode != 4){  */
  /*   if (mode){     */
  /*     XbWFOb_Edit(&MOB);*/
  /*     };           */
  /*   };             */
  /*  return(0);      */
  /*  };              */
  /* return(1);       */
  };
/*}}}  */

/*{{{  XbWFOj_DpColButt(   ***      Farbigen Knopf darstellen*/
void  XbWFOj_DpColButt(XbWDDb_DbIObj  *TO, int stat){
  double thenum,thedef;
  int res;
  char *ontext,*offtext,*txtstr,*oprstr;

  thenum = XbWFDb_GetNum(TO->chn,"V",1);
  txtstr = (char*)XbWFDb_VarInh(XbWVDb_ActGrp1,XbWDDb_Str,"T",1);
  thedef = XbWFDb_GetNum(XbWVDb_ActGrp1,"v",1);
  ontext = (char*)XbWFDb_VarInh(XbWVDb_ActGrp1,XbWDDb_Str,"1",1);
  offtext = (char*)XbWFDb_VarInh(XbWVDb_ActGrp1,XbWDDb_Str,"0",1);
  oprstr = (char*)XbWFDb_VarInh(XbWVDb_ActGrp1,XbWDDb_Str,"A",1);
  if (ontext == NULL){  ontext = "ON";  };
  if (offtext == NULL){  offtext = "  ";  };
  if (oprstr == NULL){oprstr = "=";};

  switch(oprstr[0]){
    case '=': res = (thenum==thedef); break;
    case '>': switch(oprstr[1]) {
                case '=': res = (thenum>=thedef); break;
                default:  res = (thenum>thedef); break;
                };
              break;
    case '<': switch(oprstr[1]) {
                case '=': res = (thenum<=thedef); break;
                default:  res = (thenum<thedef); break;
                };
              break;
    case '!': switch(oprstr[1]) {
                case '=': res = (thenum!=thedef); break;
                default:  res = ((1&((int)thenum)) != (1 & ((int)thedef))); break;
                };
              break;
    case '&': res = ((int)thenum & (int)thedef);
              break;
    default: res = 0;
    };
  if (stat) { res = stat - 1; };
  if (res){
    XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x-2,XbWVOb_y, ontext, *TO->bkc,*TO->txc,XbWVGr_DGray);
    XbWSGr_HLin(   XbWVOb_X,XbWVOb_x-2,XbWVOb_y,XbWVGr_White);
    XbWSGr_VLin(   XbWVOb_x-2,XbWVOb_Y,XbWVOb_y,XbWVGr_White);
    }
  else {
    XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x-2,XbWVOb_y, offtext, *TO->bkc,*TO->txc,XbWVGr_White);
    XbWSGr_HLin(   XbWVOb_X,XbWVOb_x-2,XbWVOb_y,XbWVGr_DGray);
    XbWSGr_VLin(   XbWVOb_x-2,XbWVOb_Y,XbWVOb_y,XbWVGr_DGray);
    };
  if (txtstr != NULL){
    XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y+XbWFGr_THeight(),0,0,txtstr, *TO->bkc, *TO->txc, 0);
    };
  };
/*}}}  */
/*{{{  XbWFOj_DpLight(     ***      Light-Objekt (Lampe) darstellen*/
void  XbWFOj_DpLight(XbWDDb_DbIObj  *TO){
  double thenum,thedef;
  int res;
  char *ontext,*offtext,*txtstr,*oprstr;

  thenum = XbWFDb_GetNum(TO->chn,"V",1);
  txtstr = (char*)XbWFDb_VarInh(XbWVDb_ActGrp1,XbWDDb_Str,"T",1);
  thedef = XbWFDb_GetNum(XbWVDb_ActGrp1,"v",1);
  ontext = (char*)XbWFDb_VarInh(XbWVDb_ActGrp1,XbWDDb_Str,"1",1);
  offtext = (char*)XbWFDb_VarInh(XbWVDb_ActGrp1,XbWDDb_Str,"0",1);
  oprstr = (char*)XbWFDb_VarInh(XbWVDb_ActGrp1,XbWDDb_Str,"A",1);
  if (ontext == NULL){  ontext = "ON";  };
  if (offtext == NULL){  offtext = "  ";  };
  if (oprstr == NULL){oprstr = "=";};

  switch(oprstr[0]){
    case '=': res = (thenum==thedef); break;
    case '>': switch(oprstr[1]) {
                case '=': res = (thenum>=thedef); break;
                default:  res = (thenum>thedef); break;
                };
              break;
    case '<': switch(oprstr[1]) {
                case '=': res = (thenum<=thedef); break;
                default:  res = (thenum<thedef); break;
                };
              break;
    case '!': switch(oprstr[1]) {
                case '=': res = (thenum!=thedef); break;
                default:  res = ((1&((int)thenum)) != (1 & ((int)thedef))); break;
                };
              break;
    case '&': res = ((int)thenum & (int)thedef);
              break;
    default: res = 0;
    };
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TO->bkc,0,*TO->dfc);
  if (res){
    XbWSGr_TLBox(
      XbWVOb_x-XbWFGr_TWidth(ontext)-1,XbWVOb_Y,XbWVOb_x,XbWVOb_y,
      ontext,
      *TO->bfc,XbWFTb_ColCon(*TO->bfc),*TO->dfc);
    }
  else {
    XbWSGr_TLBox(
      XbWVOb_x-XbWFGr_TWidth(ontext)-1,XbWVOb_Y,XbWVOb_x,XbWVOb_y,
      offtext,
      *TO->bkc,XbWFTb_ColCon(*TO->bkc),*TO->dfc);
    };
  if (txtstr != NULL){
    XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,0,0,txtstr,*TO->bkc,*TO->txc,0);
    };
  XbWSGr_VLin(XbWVOb_X,XbWVOb_Y,XbWVOb_y,*TO->dfc);
  };
/*}}}  */
/*{{{  XbWFOj_DpArrow(     ***      Pfeil-Knopf darstellen*/
void  XbWFOj_DpArrow(XbWDDb_DbIObj  *TO, char *arrstr){
  if (arrstr == NULL){arrstr = "U";};
  {
    int mx,my,ax,ay,bx,by;
    mx = (XbWVOb_X+XbWVOb_x)/2;
    my = (XbWVOb_Y+XbWVOb_y)/2;
    ax = 4;
    ay = 3;
    bx = 3;
    by = 2;

    switch(arrstr[0]){
      case 'U': /* Up */
      case 'u':          XbWSGr_Line(mx,my-ay,mx,my+ay,(*TO->txc));
                         XbWSGr_Line(mx-bx,my,mx,my-ay,(*TO->txc));
                         XbWSGr_Line(mx+bx,my,mx,my-ay,(*TO->txc));
                         break;
      case 'D': /* Dn */
      case 'd':          XbWSGr_Line(mx,my-ay,mx,my+ay,(*TO->txc));
                         XbWSGr_Line(mx-bx,my,mx,my+ay,(*TO->txc));
                         XbWSGr_Line(mx+bx,my,mx,my+ay,(*TO->txc));

                         break;
      case 'R': /* Ri */
      case 'r':          XbWSGr_Line(mx-ax,my,mx+ax,my,(*TO->txc));
                         XbWSGr_Line(mx+ax,my,mx,my+by,(*TO->txc));
                         XbWSGr_Line(mx+ax,my,mx,my-by,(*TO->txc));

                         break;
      case 'L': /* Lf */
      case 'l':          XbWSGr_Line(mx-ax,my,mx+ax,my,(*TO->txc));
                         XbWSGr_Line(mx-ax,my,mx,my+by,(*TO->txc));
                         XbWSGr_Line(mx-ax,my,mx,my-by,(*TO->txc));
                         break;
      case 'T': /* Top */
      case 't':          XbWSGr_Line(mx-bx,my-ay,mx+bx,my-ay,(*TO->txc));
                         XbWSGr_Line(mx,my-ay,mx,my+ay,(*TO->txc));
                         XbWSGr_Line(mx-bx,my,mx,my-ay,(*TO->txc));
                         XbWSGr_Line(mx+bx,my,mx,my-ay,(*TO->txc));
                         break;
      case 'B': /* Bottom */
      case 'b':          XbWSGr_Line(mx-bx,my+ay,mx+bx,my+ay,(*TO->txc));
                         XbWSGr_Line(mx,my-ay,mx,my+ay,(*TO->txc));
                         XbWSGr_Line(mx-bx,my,mx,my+ay,(*TO->txc));
                         XbWSGr_Line(mx+bx,my,mx,my+ay,(*TO->txc));

                         break;
      case 'E': /* End */
      case 'e':          XbWSGr_Line(mx+ax,my-by,mx+ax,my+by,(*TO->txc));
                         XbWSGr_Line(mx-ax,my,mx+ax,my,(*TO->txc));
                         XbWSGr_Line(mx+ax,my,mx,my+by,(*TO->txc));
                         XbWSGr_Line(mx+ax,my,mx,my-by,(*TO->txc));

                         break;
      case 'S': /* Start */
      case 's':          XbWSGr_Line(mx-ax,my-by,mx-ax,my+by,(*TO->txc));
                         XbWSGr_Line(mx-ax,my,mx+ax,my,(*TO->txc));
                         XbWSGr_Line(mx-ax,my,mx,my+by,(*TO->txc));
                         XbWSGr_Line(mx-ax,my,mx,my-by,(*TO->txc));
                         break;
      };
    };
  };
/*}}}  */
/*{{{  XbWFOj_DpBool(      ***      Boolsche Lampe darstellen*/
void  XbWFOj_DpBool(XbWDDb_DbIObj  *TO){
  double thenum;
  thenum = XbWFDb_GetNum(TO->chn,"V",1);
  if (thenum > 0){
    thenum = 0.0;
    }
  else {
    thenum = 1.0;
    };
  XbWFDb_PutNum(TO->chn,"V",1,thenum);
  };
/*}}}  */
/*{{{  XbWFOj_DpBit(       ***      Bit-Lampe darstellen*/
void  XbWFOj_DpBit(XbWDDb_DbIObj  *TO){
  int thenum;
  int defnum;
  defnum = (int)XbWFDb_GetNum(TO->chn,"v",1);
  thenum = (int)XbWFDb_GetNum(TO->chn,"V",1);
  if ((thenum & defnum) > 0){
    thenum &= ~defnum;
    }
  else {
    thenum |= defnum;
    };
  XbWFDb_PutNum(TO->chn,"V",1,(double)thenum);
  };
/*}}}  */
/*{{{  XbWFOj_DpSwt(       ***      Switch-Lampe darstellen*/
void  XbWFOj_DpSwt(XbWDDb_DbIObj  *TO){
  double thenum;
  thenum = XbWFDb_GetNum(TO->chn,"v",1);
  XbWFDb_PutNum(TO->chn,"V",1,thenum);
  };
/*}}}  */
/*{{{  XbWFOj_DpEllipse(   ***      Ellipse zeichnen*/
void  XbWFOj_DpEllipse(XbWDDb_DbIObj  *TO){
  int stang,endang,ra,rb;
  stang = (int)XbWFDb_GetNum(TO->chn,"st_ang",1);
  endang = (int)XbWFDb_GetNum(XbWVDb_ActGrp1,"end_ang",1);
  if (!endang){
    endang = 360;
    };
  ra = (*TO->XB - *TO->XA)/2;
  rb = (*TO->YB - *TO->YA)/2;
  XbWSGr_Ell(*TO->XA+ra,*TO->YA+rb,stang,endang,ra,rb,*TO->dfc);
  };

/*}}}  */
/*{{{  XbWFOj_DpSlider(    ***      Slider zeichnen*/
void   XbWFOj_DpSlider(XbWDDb_DbIObj  *TO, int w_mode){
  double o_max, o_min, o_akt=0, o_sca, o_mag;
  double scale;
  int sl_len,sl_start,ii,tsl;

  ii = XbWFGr_TWidth("M")*2;
  tsl =  (TO->odt[2] == 'Y');

  o_sca = XbWFDb_GetNum(TO->chn,"sca",1);
  if (o_sca <= 0) {o_sca = 1.0;};
  o_min = XbWFDb_GetNum(TO->chn,"m",1);
  o_max = XbWFDb_GetNum(TO->chn,"M",1);
  o_mag = XbWFDb_GetNum(TO->chn,"mag",1);
  if (o_mag <= 0) {o_mag = 1.0;};
  if (o_max == 0) {o_max =  100;};

  if (!tsl) {
    scale = 1.0* (XbWVOb_x-XbWVOb_X-2.2*ii)/ (o_max-o_min);
    if (scale <= 0){return;};

    sl_len = 2.2*ii;

    if (w_mode){
      }
    else {
      o_akt = XbWFDb_GetNum(TO->chn,"V",1);
      };

    if (o_akt < o_min){o_akt = o_min;};


    sl_start = o_akt * scale;
    if (sl_start > XbWVOb_x-XbWVOb_X-sl_len){
      sl_start = XbWVOb_x-XbWVOb_X-sl_len;
      };

    XbWSGr_TLBox(XbWVOb_X, XbWVOb_Y, XbWVOb_x, XbWVOb_y, NULL, *TO->bkc, 0, *TO->dfc);
    XbWSGr_HLin(XbWVOb_X, XbWVOb_x, XbWVOb_Y+3, *TO->dfc);
    XbWSGr_HLin(XbWVOb_X, XbWVOb_x, XbWVOb_y-3, *TO->dfc);

    XbWSGr_TLBox(XbWVOb_X+sl_start,        XbWVOb_Y,
              XbWVOb_X+sl_start+sl_len, XbWVOb_y,
              NULL, *TO->bfc,0,*TO->dfc);
    XbWSGr_HLin(XbWVOb_X+sl_start+3,
           XbWVOb_X+sl_start+sl_len-3,
           (XbWVOb_Y+XbWVOb_y)/2,
      *TO->txc);
    }
  else {
    scale = 1.0* (XbWVOb_y-XbWVOb_Y-2.2*ii)/ (o_max-o_min);
    if (scale <= 0){return;};

    sl_len = 2.2*ii;

    if (w_mode){
      }
    else {
      o_akt = XbWFDb_GetNum(TO->chn,"V",1);
      };

    if (o_akt < o_min){o_akt = o_min;};


    sl_start = o_akt * scale;
    if (sl_start > XbWVOb_y-XbWVOb_Y-sl_len){
      sl_start = XbWVOb_y-XbWVOb_Y-sl_len;
      };

    XbWSGr_TLBox(XbWVOb_X, XbWVOb_Y, XbWVOb_x, XbWVOb_y, NULL, *TO->bkc,0,*TO->dfc);
    XbWSGr_VLin(XbWVOb_X+3, XbWVOb_Y, XbWVOb_y, *TO->dfc);
    XbWSGr_VLin(XbWVOb_x-3, XbWVOb_Y, XbWVOb_y, *TO->dfc);

    XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y+sl_start,
              XbWVOb_x,XbWVOb_Y+sl_start+sl_len,NULL, *TO->bfc,0,*TO->dfc);
    XbWSGr_VLin((XbWVOb_X+XbWVOb_x)/2,XbWVOb_Y+sl_start+3,
           XbWVOb_Y+sl_start+sl_len-3,
      *TO->txc);
    };

  XbWFDb_PutNum(TO->chn,"V",1,o_akt);

  };
/*}}}  */

/*{{{  XbWFOj_SpawnTsk(    ***      taskstart durchfuhren als Obj-Aktion*/
void  XbWFOj_SpawnTsk(XbWDDb_DbIWdw  *TW,XbWDDb_DbIObj  *TO,
    unsigned char styp, unsigned char write_tbl, unsigned char ttyp,
    unsigned char no_params){
  char sstr[200],*inh,*tsk_dir,*tsk_name;
  FILE *wtfp;
  int xa,ya,xb,yb;


  XbWFTb_Message("About to spawn task...");


  xa = *TW->nx;   ya = *TW->ny;
  xb = xa;        yb = ya;
 
  xa += XbWVIDEO_XA; ya += XbWVIDEO_YA;
  xb = xa;        yb = ya;

  xa += *TO->XA;  ya += *TO->YA;
  xb += *TO->XB;  yb += *TO->YB;

  xa++;           ya++;

  if (xb > XbWVIDEO_XB) {  xb = XbWVIDEO_XB;  };
  if (yb > XbWVIDEO_YB) {  yb = XbWVIDEO_YB;  };

  if ((tsk_dir = (char*)XbWFDb_VarInh(TO->chn,XbWDDb_Str,"td",1)) == NULL) {
    tsk_dir = "";
    };

  if ((inh = (char*)XbWFDb_VarInh(TO->chn,XbWDDb_Str,"tn",1)) != NULL) {

    {
      char ctsk_dir[60];
      int ii;
      tsk_name = inh;
      strcpy(ctsk_dir,(char*)XbWFTb_PckTxt(tsk_dir));
      ii = strlen(ctsk_dir);
#ifdef XbW_SYSDEF_TC3_VERSION
      if (ctsk_dir[ii-1] == '\\' ) {
        ctsk_dir[ii-1] = 0;
        };
      chdir(ctsk_dir);
#else
      if (ctsk_dir[ii-1] == '/' ) {
        ctsk_dir[ii-1] = 0;
        };
      { int kk;
        for(kk=0;kk<ii-1;kk++){
          if (ctsk_dir[kk] == '\\' ) {
            ctsk_dir[kk] = '/';
            };
          };
        };
#endif
      };
    switch (no_params) {
      case 'P':
        #ifdef XbW_SYSDEF_TC3_VERSION
          sprintf(sstr,"%s d%s\\ XA%d YA%d XB%d YB%d",inh,tsk_dir,xa,ya,xb,yb);
        #else
          sprintf(sstr,"%s d%s/ XA%d YA%d XB%d YB%d",inh,tsk_dir,xa,ya,xb,yb);
        #endif
 
        break;
      default :
        sprintf(sstr,"%s",inh);
        break;
      };
    XbWFGr_CurOFF();
    XbWFGr_PushPort();
    switch (styp) {
      case 'v':
      case 'V':
        if ((inh = (char*)XbWFDb_VarInh(TO->chn,XbWDDb_Str,"wtfil",1)) != NULL) {
          while ((wtfp = XbWSSy_fopen(inh,"rb")) == NULL){};
          fclose(wtfp);
          };
        break;
      default :
        switch (write_tbl) {
          case 's':
          case 'S': {
                    void  *ap[4] = {(void *)3,
                                        (void *)"actual",
                                        (void *)"\\xw\\x\\sys\\",
                                        (void *)0 };
                    int at[4] = { XbWDMf_IntPar,
                                  XbWDMf_StrPar,
                                  XbWDMf_StrPar,
                                  XbWDMf_IntPar };
                    char obn[40];
                    char win[40];
                    strcpy(obn,(char*)TO->onm);
                    strcpy(win,(char*)TW->nm);
                    XbWFDb_WrTable(&ap,&at);
                    XbWFDb_CloseSys();
                    switch(ttyp){
                      case 't':
                      case 'T':
                               XbWSGr_Close();
                               break;
                      };

                    if(XbWPSy_EXETaskStartHook(tsk_name,TW,TO)){
                      system(sstr);
                      };
                    switch(ttyp){
                      case 'c':
                      case 'C':
                               break;
                      case 'p':
                      case 'P':
                      case 't':
                      case 'T':
                               XbWSGr_ResMode();
                               XbWSMs_DrInit();
                               break;
                      };
                    XbWFDb_RdTable(&ap,&at);
                    switch(ttyp){
                      case 'c':
                      case 'C':
                               break;
                      case 'p':
                      case 'P':
                      case 't':
                      case 'T':
                               XbWFWd_BackGr();
                             /*  XbWFWd_DrawAll(); */
                               break;
                      };
                    XbWFWd_SwitchTo(win,0);
                    *TW = XbWVWd_W;
                    if (XbWFOb_GetPar(TW,TO,obn,XbWDOb_GtAllP|XbWDOb_GetAnO) == NULL){
                      XbWSPu_Alarm("Error in Database");
                      };

                    XbWVOb_X = *TO->XA;  XbWVOb_Y = *TO->YA;
                    XbWVOb_x = *TO->XB;  XbWVOb_y = *TO->YB;

                    };
                    break;

          default:  {
                    char obn[40];
                    strcpy(obn,(char*)TO->onm);
                    switch(ttyp){
                      case 't':
                      case 'T':
                               XbWSGr_Close();
                               break;
                      };
                    if(XbWPSy_EXETaskStartHook(tsk_name,TW,TO)){
                      system(sstr);
                      };
                    switch(ttyp){
                      case 'c':
                      case 'C':
                               break;
                      case 'p':
                      case 'P':
                      case 't':
                      case 'T':
                               XbWSGr_ResMode();
                               XbWSMs_DrInit();
                               XbWFWd_BackGr();
                               /* XbWFWd_DrawAll(); */
                               if (XbWFOb_GetPar(TW,TO,obn,XbWDOb_GtAllP|XbWDOb_GetAnO) == NULL){
                                 XbWSPu_Alarm("Error in Database");
                                 };
                               XbWVOb_X = *TO->XA;  XbWVOb_Y = *TO->YA;
                               XbWVOb_x = *TO->XB;  XbWVOb_y = *TO->YB;
                               break;
                      };
                    };
                    break;
          };
        break;
      };

    XbWFGr_SetPort();
    XbWSMs_Init();
    XbWSMs_ON();
    XbWSMs_OFF();
    XbWSMs_ResPos();
    XbWFGr_PopPort();
    XbWFGr_ResPort();
    XbWSGr_GotoXY(1,1);
#ifdef XbW_SYSDEF_TC3_VERSION
    chdir("\\xw\\code\\bin");
#endif
    };
  };

/*}}}  */

/*{{{  XbWFOj_EdCyc(       ***      Zyklisches Objekt editieren*/
void  XbWFOj_EdCyc(XbWDDb_DbIObj  *TO){
  char * text;
  int thedef;
  char *textstr;
  char sstr[30];
 
  text = XbWFDb_VarInh(TO->chn,XbWDDb_Str,"V",1);
  thedef = XbWFDb_GetNum(TO->chn,"v",1);
  thedef++;
  sprintf(sstr,"Text%d",thedef);
 
  textstr = (char*)XbWFDb_VarInh(TO->chn,XbWDDb_Str,sstr,1);
  if (textstr == NULL){
    textstr = XbWFDb_VarInh(TO->chn,XbWDDb_Str,"Text-1",1);
    if (textstr == NULL){
      textstr = "";
      };
    thedef = -1;
    };

  strcpy(text,textstr);
  XbWFDb_PutNum(TO->chn,"v",1,thedef);
  };

/*}}}  */
/*{{{  XbWFOj_DpCyc(       ***      Zyklisches Objekt darstellen*/
void  XbWFOj_DpCyc(XbWDDb_DbIObj  *TO){
  char * text;
  int thedef;
  char *textstr;
  char sstr[30];
 
  text = XbWFDb_VarInh(TO->chn,XbWDDb_Str,"V",1);
  thedef = XbWFDb_GetNum(TO->chn,"v",1);
/*   thedef++;  weglassen: der Unterschied zu EdCyc! */
  sprintf(sstr,"Text%d",thedef);
 
  textstr = (char*)XbWFDb_VarInh(TO->chn,XbWDDb_Str,sstr,1);
  if (textstr == NULL){
    textstr = XbWFDb_VarInh(TO->chn,XbWDDb_Str,"Text-1",1);
    if (textstr == NULL){
      textstr = "";
      };
    thedef = -1;
    };

  strcpy(text,textstr);
/*   XbWFDb_PutNum(TO->chn,"v",1,thedef); weglassen. s.o. */
  };

/*}}}  */
/*{{{  XbWFOj_Ed_Y(        ***      Ruft XbWOj_EdCyc*/
int  XbWFOj_Ed_Y(int edit, XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
  if (edit==3){ return(0);};
  XbWFOj_EdCyc(TOB);
  return(1);
  };

/*}}}  */
/*{{{  XbWFOj_Dp_Y(        ***      Ruft XbWOj_DpCyc*/
int  XbWFOj_Dp_Y(XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
  XbWFOj_DpCyc(TOB);
  XbWFOj_Dp_S(TOB);
  return(1);
  };

/*}}}  */
/*{{{  XbWFOj_EdSwt(       ***      Switch-Lampe editieren*/
void  XbWFOj_EdSwt(XbWDDb_DbIObj  *TO){
  double thenum,thedef;
  char *oprstr;

  thenum = XbWFDb_GetNum(TO->chn,"V",1);
  thedef = XbWFDb_GetNum(TO->chn,"v",1);

  oprstr = (char*)XbWFDb_VarInh(TO->chn,XbWDDb_Str,"A",1);
  if (oprstr == NULL){oprstr = "=";};

  switch(oprstr[0]){
    case '=': thenum=thedef; break;
    case '&': thenum = (int)thenum & ((int)thedef);
              break;
    case '|': thenum = (int)thenum | ((int)thedef);
              break;
    case '-': thenum -= thedef; break;
    case '+': thenum += thedef; break;
    case '/': thenum /= thedef; break;
    case '*': thenum *= thedef; break;
    };
  XbWFDb_PutNum(TO->chn,"V",1,thenum);
  };

/*}}}  */
/*{{{  XbWFOj_EdStr(       ***      String-Objekt editieren*/
void  XbWFOj_EdStr(XbWDDb_DbIObj  *TO){
  char merker[200], *ms;
  char sstr[20];
  int vtp;
  int SL,kk;
  strcpy(sstr,"V");
  XbWFDb_GetInf(TO->chn, -1, sstr, &vtp, &ms, &SL, 1);
  if (ms != NULL) {
    if (SL < 1) {
      SL = strlen(ms)+1;
      kk = SL-2;
      }
    else {
      kk = strlen(ms)-1;
      };
    if (strchr(ms,13) != NULL) {
      *((char*)strchr(ms,13)) = 0;
      };
    if (strchr(ms,10) != NULL) {
      *((char*)strchr(ms,10)) = 0;
      };
    while ((kk >= 0) & (ms[kk] == ' ')) {
      ms[kk]=0;
      kk--;
      };
    strcpy(merker,ms);
    XbWFEd_GetOStr(&XbWVWd_W,merker,190,0,0,XbWVOb_x-XbWVOb_X,XbWVOb_y-XbWVOb_Y, merker,
         ((XbWVMs_XPos - *XbWVWd_W.nx - *TO->XA) / XbWFGr_TWidth("M"))
     );
    strncpy(ms,merker,SL-1);
    ms[SL-1] = 0;
    };
  };
/*}}}  */
/*{{{  XbWFOj_GetNum(      ***      Unterfunktion zu EdInt*/
double  XbWFOj_GetNum(XbWDDb_DbIObj  *TO){
  double thenum;
  char tx[60],ttx[60];
  double off,sca,una;
  char *tfor,*teha;

/* ---------------- Zahl laden ------------------------------------------- */
  thenum = XbWFDb_GetNum(TO->chn,"V",1);

/* ---------------- Faktoren, Einheiten setzen --------------------------- */
  off = XbWFDb_GetNum(TO->chn,"off",1);  thenum += off;
  sca = XbWFDb_GetNum(TO->chn,"sca",1);  if (sca) {thenum *= sca;};
  una = XbWFDb_GetNum(TO->chn,"una",1);  if (una) {thenum *= una;};

  switch (*TO->odt){
    case 'i':
    case 'I':
             itoa((int)thenum,tx,10); break;
    case 'h':
    case 'H':
             itoa((int)thenum,tx,16); break;
    default:
             tfor = (char *)XbWFDb_VarInh(TO->chn,XbWDDb_Str,"fmt",1);
             if (tfor != NULL) {
               sprintf(tx,tfor,thenum);
               }
             else {
               sprintf(tx,"%40.12f",thenum);
               strcpy(tx,(char *)XbWFTb_PckTxt(tx));
               };
             break;
    };
  /* ---------- Einheit setzen ------------- */
  teha = (char *)XbWFDb_VarInh(TO->chn,XbWDDb_Str,"eha",1);
  if (teha != NULL) {
    if (strchr(teha,'%') != NULL) {
      /* -------- Wenn formatstring angegeben, SCALE einbeziehen (!) */
      sprintf(ttx,teha,sca);
      strcat(tx,ttx);
      }
    else {
      strcat(tx,teha);
      };
    };
  strcpy(XbWVOb_GTxt,tx);
  return(thenum);
  };


/*}}}  */
/*{{{  XbWFOj_PutNum(*/
double  XbWFOj_PutNum(XbWDDb_DbIObj  *TO){
  double thenum,off,una,sca;
  char tx[60];

  strcpy(tx,XbWVOb_GTxt);
  if (strchr(tx,'[') != NULL) {
    *((char*)strchr(tx,'[')) = 0;
    };

  thenum = atof(tx);

/* ---------------- Faktoren, Einheiten setzen --------------------------- */
  off = XbWFDb_GetNum(TO->chn,"off",1);
  sca = XbWFDb_GetNum(TO->chn,"sca",1);
  una = XbWFDb_GetNum(TO->chn,"una",1);

  if (una) {thenum /= una;};
  if (sca) {thenum /= sca;};
  if (off) {thenum -= off;};
  return(thenum);
  };
/*}}}  */
/*{{{  XbWFOj_EdInt(       ***      Integer-Objekt editieren*/
void  XbWFOj_EdInt(XbWDDb_DbIObj  *TO){
  double mrk,act,min,max,def;
  char helpline[180];
  char merker[100];
  int weg;

  mrk = XbWFOj_GetNum(TO);

  max = (double)XbWFDb_GetNum(TO->chn,"M",1);
  def = (double)XbWFDb_GetNum(TO->chn,"v",1);
  min = (double)XbWFDb_GetNum(TO->chn,"m",1);

  {
    int ii;
    ii = 0;
    while ( XbWVOb_GTxt[ii] == ' ') {
      ii++;
      };
    strcpy(merker,(char*)&XbWVOb_GTxt[ii]);
    };

  newinput:
  sprintf(helpline," min:%12.7f def:%12.7f max:%12.7f;",min,def,max);


  XbWFEd_GetOStr(&XbWVWd_W,(char *)&merker,98,
    0,0,XbWVOb_x-XbWVOb_X,XbWVOb_y-XbWVOb_Y,    helpline,0);

  strcpy(XbWVOb_GTxt,(char *)XbWFTb_PckTxt(merker));

  act = XbWFOj_PutNum(TO);

  if ( ((act > max) | (act < min)) & (max != min) ) {
    sprintf(helpline,"%12.7f ... %12.7f;",min,max);
    weg = XbWFTb_SubPopUpBox("Sorry, but your input exceeds range",
        helpline,
        " Use default"," New input"," Use oldval");
    XbWSMs_SetArrowCursor();
    switch (weg) {
      case (1):  act = def;     break;
      case (2):
        XbWFOb_SetViewPort(&XbWVWd_W,TO);
        goto newinput;
      case (3):  act = mrk;     break;
      };
    };

/* ---------------- Zahl speichern --------------------------------------- */
  XbWFDb_PutNum(TO->chn,"V",1,act);
  };

/*}}}  */
/*{{{  XbWFOj_EdSlider(    ***      Slider verschieben*/
void  XbWFOj_EdSlider(XbWDDb_DbIObj  *TO){
  int asl_start,Mausx,Mausy,tsl,AMausx,AMausy,BMausx,BMausy;
  double o_max, o_min, o_akt;
  double scale;
  int sl_len,sl_start,ii;
  void  *oldcursor;

  tsl =  (TO->odt[2] == 'Y');

  ii = XbWFGr_TWidth("M")*2;
  o_akt = XbWFDb_GetNum(TO->chn,"V",1);
  o_min = XbWFDb_GetNum(TO->chn,"m",1);
  o_max = XbWFDb_GetNum(TO->chn,"M",1);
  if (o_max == 0) {o_max =  100;};

  if (!tsl) {
    scale = 1.0* (XbWVOb_x-XbWVOb_X -2.2*ii) / (o_max-o_min);
    }
  else {
    scale = 1.0* (XbWVOb_y-XbWVOb_Y -2.2*ii) / (o_max-o_min);
    };
  if (scale <= 0){return;};

  sl_len = 2.2 * ii;
  if (o_akt < o_min){o_akt = o_min;};
  if (o_akt > o_max){o_akt = o_max;};
  sl_start = o_akt * scale;

  XbWVMs_XPos = *XbWVWd_W.nx+(*TO->XA+*TO->XA)/2;
  XbWVMs_YPos = *XbWVWd_W.ny+(*TO->YA+*TO->YA)/2;
  if (!tsl) {
    XbWVMs_XPos = *XbWVWd_W.nx+*TO->XA+sl_start;
    XbWVMs_YPos = *XbWVWd_W.ny+*TO->YB;
    }
  else {
    XbWVMs_XPos = *XbWVWd_W.nx+*TO->XB;
    XbWVMs_YPos = *XbWVWd_W.ny+*TO->YA+sl_start;
    };
  AMausx = XbWVMs_XPos;
  AMausy = XbWVMs_YPos;
  BMausx = -10;
  BMausy = -10;
  XbWSMs_Warp(XbWVMs_XPos,XbWVMs_YPos);

  oldcursor = XbWSMs_SetHandCursor();
  XbWSMs_IsAKey(0);
  XbWVMs_LButt = 1;
  asl_start = sl_start;
  while (XbWVMs_LButt){
    XbWSMs_ButUp(0);
    XbWFGr_CurON();
    Mausx = XbWVMs_XPos-AMausx;
    Mausy = XbWVMs_YPos-AMausy;

    if ((BMausx != Mausx)|(BMausy != Mausy)){
      BMausx = Mausx; BMausy = Mausy;
      if (!tsl) {
        sl_start = asl_start + Mausx;
        if (sl_start > XbWVOb_x-XbWVOb_X-sl_len){
          sl_start = XbWVOb_x-XbWVOb_X-sl_len;
          };
        }
      else {
        sl_start = asl_start + Mausy;
        if (sl_start > XbWVOb_y-XbWVOb_Y-sl_len){
          sl_start = XbWVOb_y-XbWVOb_Y-sl_len;
          };
        };
      o_akt = sl_start/scale;
      if (o_akt < o_min){o_akt = o_min;};
      if (o_akt > o_max){o_akt = o_max;};
      sl_start = o_akt * scale;
      XbWFDb_PutNum(TO->chn,"V",1,o_akt);
      XbWFOj_DpSlider(TO,0);
      };
    };
  XbWSMs_SetLastCursor(oldcursor);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_Z(        ***      Projektname editieren*/
int  XbWFOj_Ed_Z(int edit, XbWDDb_DbIObj  *TOB){
  int atp,ale;
  char aov[16], *ain;

  XbWDDb_DbIVar  *gr_st;

  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
  if (edit==3){ return(0);};

  gr_st = (XbWDDb_DbIVar *)XbWDDb_DbIPrj;

  if (XbWFDb_GetInf(gr_st,0,aov,&atp,&ain,&ale,0)) {
    if (atp == XbWDDb_Str) {
      XbWFDb_PutStr(TOB->chn,"V",1,ain);
      };
    };
  return(1);
  };

/*}}}  */

/*{{{  XbWFOj_DiEdContents(***      Hauptroutine Disp&Edit nach Mausclick*/
void  XbWFOj_DiEdContents(XbWDDb_DbIWdw  *WI, XbWDDb_DbIObj  *TOB, int edit){
  int todisp = 1;
  int m_stat = XbWVMs_CSet;
  if (!(*TOB->dst)) {return;};
  XbWFGr_CurOFF();
  if (edit != 0) {
    if (!(*TOB->est)){return;};

    if (*WI->wfe != 0) {
      *WI->wfx = 1;
      XbWFGr_CurOFF();
      XbWVMs_CFrm = kreuz;
      };
    };
  XbWFGr_PushPort();
  XbWFOb_SetViewPort(&XbWVWd_W,TOB);
  XbWVOb_X =   XbWVOb_Y = 0;
  XbWVOb_x = *TOB->XB-*TOB->XA;  XbWVOb_y = *TOB->YB-*TOB->YA;
 
  if (edit != 0) {
    if (TOB->oet != NULL){
      switch(TOB->oet[0]){
        case '@':
            XbWPSy_EditObjectHook(
              (char*)TOB->oet,
              WI,TOB,
              &todisp,edit,
              XbWVOb_ox-*TOB->XA,
              XbWVOb_oy-*TOB->YA);
          break;
        case '#': todisp = XbWFOj_EdCalc(edit,TOB); break;
        case 'A': todisp = XbWFOj_Ed_A(edit,TOB,0); break;
        case 'a': todisp = XbWFOj_Ed_A(edit,TOB,1); break;
        case 'B': todisp = XbWFOj_Ed_B(edit,TOB); break;
        case 'C': todisp = XbWFOj_Ed_C(edit,TOB); break;
        case 'D': todisp = XbWFOj_Ed_HID(edit,TOB); break;
        case 'F': todisp = XbWFOj_Ed_F(edit,TOB); break;
        case 'G': todisp = XbWFOj_Ed_G(edit,TOB); break;
        case 'H': todisp = XbWFOj_Ed_HID(edit,TOB); break;
        case 'I': todisp = XbWFOj_Ed_HID(edit,TOB); break;
        case 'L': todisp = XbWFOj_Ed_L(edit,TOB); break;
        case 'M': todisp = XbWFOj_Ed_M(edit,TOB); break;
        case 'N': todisp = XbWFOj_Ed_N(edit,TOB); break;
        case 'R': todisp = XbWFOj_Ed_R(edit,TOB); break;
        case 'S': todisp = XbWFOj_Ed_S(edit,TOB); break;
        case 'T': todisp = XbWFOj_Ed_T(&XbWVWd_W,edit,TOB); break;
        case 'U': todisp = XbWFOj_Ed_U(edit,TOB); break;
        case 'V': todisp = XbWFOj_Ed_V(edit,TOB); break;
        case 'X': todisp = XbWFOj_Ed_X(edit,TOB); break;
        case 'Y': todisp = XbWFOj_Ed_Y(edit,TOB); break;
        case 'Z': todisp = XbWFOj_Ed_Z(edit,TOB); break;
        case '.': todisp=1; break;
        };
      };

    };

  if ((todisp) && ( TOB->odt != NULL)){
    switch(TOB->odt[0]){
      case '@': XbWPSy_DisplayObjectHook((char *)TOB->odt,WI,TOB);
                break;
      case '#': XbWFOj_EdCalc(0,TOB); break;
      case 'R': XbWFOj_Dp_R(TOB); break;
      case 'N': XbWFOj_Dp_N(TOB); break;
      case 'A': XbWFOj_Dp_A(TOB,0); break;
      case 'C': XbWSSy_ObjDispIcon(TOB); break;
      case 'a': XbWFOj_Dp_A(TOB,1); break;
      case 'G': XbWFOj_Dp_G(TOB); break;
      case 'S': XbWFOj_Dp_S(TOB); break;
      case 'I':
      case 'D':
      case 'H': XbWFOj_DpInt(TOB); break;
      case 'B':
      case 'L': XbWFOj_DpLight(TOB); break;
      case 'M': XbWFOj_Dp_M(TOB); break;
      case '/': XbWFOj_Dp_BKS(TOB); break;
      case 'P': XbWFOj_Dp_P(TOB); break;
      case 'T': XbWFOj_Dp_T(TOB); break;
      case 'X': XbWFOj_Dp_X(TOB); break;
      case 'Y': XbWFOj_Dp_Y(TOB); break;
      case 'Z': XbWFOj_Dp_Z(TOB); break;
      case '.': break;
      };
    };

  XbWFGr_PopPort(); XbWFGr_ResPort();
  if (m_stat){
    XbWFGr_CurON();
    };
  };
/*}}}  */
/*{{{  XbWFOj_Ed_N(        ***,PRJ  Variablenname in Var-Inh. eintragen*/
int  XbWFOj_Ed_N(int edit, XbWDDb_DbIObj  *TOB){
  int anr,aof,atp,ale,ii;
  char aov[16], *ain;

  XbWDDb_DbIVar  *gr_st;

  if (edit==3){
    XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
    return(0);
    };

  aof = (int)  XbWFDb_GetNum(TOB->chn,"ao",1);
  anr = (int)  XbWFDb_GetNum(TOB->chn,"an",1);

  gr_st = (XbWDDb_DbIVar *)XbWDDb_DbIPrj;

  for (ii = 0; ii < aof+anr; ii++) {
    if ((gr_st->tp & XbWDDb_Typ) == XbWDDb_GPtr) {
      return(0);
      };
    XbWFDb_ForWd(&gr_st,XbWDDb_DbISys);
    };

  if (XbWFDb_GetInf(gr_st,0,aov,&atp,&ain,&ale,0)) {
    XbWFDb_PutStr(TOB->chn,"V",1,aov);
    XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,aov,*TOB->bkc,*TOB->txc,*TOB->bfc);
    };
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_G(        ***,PRJ  Gruppenname in Var-Inh. eintragen*/
int  XbWFOj_Ed_G(int edit, XbWDDb_DbIObj  *TOB){
/* Gruppenname darstellen;
     "al" Name der Liste
     "an" ist startnummer der Gruppe zum Darstellen
     "ao" ist listen-offset zu an; */

  int anr,aof,atp,ale,ii;
  char aov[16], *ain;
  char *agr, *aon;

  XbWDDb_DbIVar  *gr_st;

  if (edit ==3){
    XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
    return(0);
    };

  agr = (char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,"al",1);
  aon = (char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,"V",1);
  anr = (int)  XbWFDb_GetNum(TOB->chn,"an",1);
  aof = (int)  XbWFDb_GetNum(TOB->chn,"ao",1);

  gr_st = XbWFDb_FindGrp(agr,NULL);
  for (ii = 0; ii < aof+anr; ii++) {
    gr_st = XbWFDb_NextGrp(gr_st,NULL);
    };

  if (XbWFDb_GetInf(gr_st,0,aov,&atp,&ain,&ale,0)) {
    switch (atp) {
      case XbWDDb_Str: strcpy(aon,ain);
                   break;
      };
    };
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_R(        ***,PRJ  Zeile aus Textdatei editieren*/
int  XbWFOj_Ed_R(int edit, XbWDDb_DbIObj  *TOB){
  /* enth�lt eine Zeile aus einer Textdatei (TFRL lang) */
  int dfl,off,str_len;
  char *fname;
  FILE *fp,*cfp;
  char cstr[200],sstr[200];
  int ii;
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
  if (edit==3){ return(0);};
  fname = (char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,"V",1);
  if (fname != NULL) {
    dfl = (int)XbWFDb_GetNum(TOB->chn,"v",1);
    off = (int)XbWFDb_GetNum(TOB->chn,"m",1);
    if ((cfp = XbWSSy_fopen("xbe.xxx","wt")) != NULL) {
      if ((fp = XbWSSy_fopen(fname,"r+t")) != NULL) {
        ii=0;
        while (ii<off+dfl) {
          if (fgets(sstr,198,fp) == NULL){
            ii = 30000;
            off = 0;
            };
          ii++;
          };
        XbWVOb_pos=ftell(fp);
        fgets(sstr,198,fp);
        if (strchr(sstr,13) != NULL) {
          *((char*)strchr(sstr,13)) = 0;
          };
        if (strchr(sstr,10) != NULL) {
          *((char*)strchr(sstr,10)) = 0;
          };
        sstr[198] = 0;
        strcpy(cstr,sstr);
        str_len = strlen(sstr);
        {
          int kk;
          kk = strlen(sstr)-1;
          while ((kk >= 0) & (sstr[kk] == ' ')) {
            sstr[kk] = 0;
            kk--;
            };
          };
        XbWFEd_GetOStr(&XbWVWd_W,sstr,198,
          0,0,XbWVOb_x-XbWVOb_X,XbWVOb_y-XbWVOb_Y,sstr,
              ((XbWVMs_XPos - *XbWVWd_W.nx - *TOB->XA) / XbWFGr_TWidth("M"))
           );
        sstr[198] = 0;
        {
          int kk;
          kk = strlen(sstr)-1;
          while ((kk >= 0) & (sstr[kk] == ' ')) {
            sstr[kk] = 0;
            kk--;
            };
          };
        if (str_len >= strlen(sstr)) {
          fseek(fp,XbWVOb_pos,SEEK_SET);
          strncpy(cstr,sstr,strlen(sstr));
          {
            int kk;
            for (kk=strlen(sstr);kk<str_len;kk++){
              cstr[kk] = ' ';
              };
            };
          fwrite(cstr,str_len,1,fp);
          fclose(fp);
          fclose(cfp);
          }
        else{
          fseek(fp,0,SEEK_SET);
          ii = 0;
          while (!feof(fp)) {
            if (ii == (dfl+off)) {
              fgets(cstr,198,fp);
              fputs(sstr,cfp);
              fputs("\n",cfp);
              }
            else {
              if (fgets(cstr,198,fp) != NULL) {
                fputs(cstr,cfp);
                };
              };
            ii++;
            };
          fclose(fp);
          fclose(cfp);
          unlink(fname);
          rename("xbe.xxx",fname);
          };
        };
      fclose(cfp);
      };
    };
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_A(        ***,PRJ  Inhalt jeden Typs editieren*/
int  XbWFOj_Ed_A(int edit, XbWDDb_DbIObj  *TOB, int this_obj){
/* AUTOMATIC;
     "aln" Name der Liste zum Editieren
     "agn" Name der Var-Gruppe zum editieren
     "an" ist startnummer der var. zum editieren
     "ao" ist listen-offset zu anr; */
  int anr,aof,atp,ale;
  char aov[16], *ain;
  char *agr, *aon;
  char sstr[100];
  XbWDDb_DbIVar  *gr_st;
  XbWDDb_DbIVar  *ao_st;

  anr = (int)  XbWFDb_GetNum(TOB->chn,"an",1);
  aof = (int)  XbWFDb_GetNum(TOB->chn,"ao",1);

  if (!this_obj){
    gr_st = XbWFDb_FindGrp("OBX","act");
    if (gr_st == NULL) { return(0); };
    agr = (char*)XbWFDb_VarInh(gr_st,XbWDDb_Str,"aln",1);
    aon = (char*)XbWFDb_VarInh(gr_st,XbWDDb_Str,"agn",1);

    if ((ao_st = XbWFDb_FindGrp(agr,aon)) == NULL) { return(0); };

    }
  else { ao_st = TOB->chn; agr = "OBJ"; aon = (char*)TOB->onm; };

  anr = (int)  XbWFDb_GetNum(TOB->chn,"an",1);
  aof = (int)  XbWFDb_GetNum(TOB->chn,"ao",1);

  strcpy(sstr,"");
  if (XbWFDb_GetInf(ao_st,anr+aof,aov,&atp,&ain,&ale,0)) {
    sprintf(sstr,"%s:%s.%s",agr,aon,aov);
    {
      XbWDDb_DbIStr  *TSRC;
      XbWDDb_DbINPtr  *TTRG;
      if ((TTRG = (XbWDDb_DbINPtr  *)XbWFDb_VarInh(TOB->chn,0,"V",0)) != NULL){
        if ((TSRC = (XbWDDb_DbIStr  *)XbWFDb_GetDbI(
            agr,aon,aov)) != NULL){
          TTRG->inh = XbWDDb_C_PtrToDbI(TSRC,XbWDDb_DbISys);
          switch (atp) {
            case XbWDDb_Int:
            case XbWDDb_Dbl:
              XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
              if (edit==3){ return(0);};
              XbWFOj_EdInt(TOB);
              break;
            case XbWDDb_Str:
              XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
                if (edit==3){ return(0);};
              {
                char merker[200];
                int SL,kk;
                SL = ale;
                if (ain != NULL) {
                  if (SL < 1) { SL = strlen(ain)+1; kk = SL-2; }
                  else {        kk = strlen(ain)-1;            };
                  if (strchr(ain,13) != NULL){ *((char*)strchr(ain,13)) = 0;};
                  if (strchr(ain,10) != NULL){ *((char*)strchr(ain,10)) = 0;};
                  while ((kk >= 0) & (ain[kk] == ' ')) {ain[kk]=0; kk--;    };
                  strcpy(merker,ain);
                  XbWFEd_GetOStr(&XbWVWd_W,merker,190,
                    0,0,XbWVOb_x-XbWVOb_X,XbWVOb_y-XbWVOb_Y,
                    merker,
                    ((XbWVMs_XPos - *XbWVWd_W.nx - *TOB->XA) / XbWFGr_TWidth("M"))
                    );
                  strncpy(ain,merker,SL-1);
                  ain[SL-1] = 0;
                  };
                };
              break;
            case XbWDDb_NPtr:
            case XbWDDb_FPtr:
            case XbWDDb_IPtr:
            case XbWDDb_GPtr:
              XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
                if (edit==3){ return(0);};
              {
                XbWDDb_DbIPtr *ti;
                char merker[100];
                ti = (XbWDDb_DbIPtr*)ain;
                strcpy(merker,(char*)XbWFDb_DbIToStr(*ti,XbWDDb_DbISys));
                XbWFEd_GetOStr(&XbWVWd_W,merker,98,
                  0,0,XbWVOb_x-XbWVOb_X,XbWVOb_y-XbWVOb_Y,
                  merker,
                      ((XbWVMs_XPos - *XbWVWd_W.nx - *TOB->XA) / XbWFGr_TWidth("M"))
                  );
                strcpy(merker,(char*)XbWFTb_PckTxt(merker));
                *ti = (XbWDDb_DbIPtr)XbWFDb_StrToDbI(merker,XbWDDb_DbISys);
                {
                  char s_l[40],
                       s_g[40],
                       s_n[40];

                  int ii;

                  /*  Format : <LISTE>:<GRUPPE>.<Element> */

                  if (strchr(merker,':') == NULL) {goto kein_pointer;};
                  if (strchr(merker,'.') == NULL) {goto kein_pointer;};

                  strncpy(s_l,&merker[0],29);
                  s_l[29]=0; *((char*)(strchr(s_l,':')))=0;
                  strncpy(s_g,strchr(merker,':')+1,29);
                  s_g[29]= 0;
                  *((char*)(strchr(s_g,'.')))=0;
                  strncpy(s_n,strchr(merker,'.')+1,29); s_n[29]= 0;

                  for (ii=0;ii<29;ii++){
                    switch(s_n[ii]) {
                      case '0': s_n[ii]=0;ii=1000;break;
                      };
                    };
                  if ((TTRG = (XbWDDb_DbINPtr  *)XbWFDb_GetDbI(
                     agr,aon,aov )) != NULL){
                    if ((TSRC = (XbWDDb_DbIStr  *)XbWFDb_GetDbI(
                        s_l,s_g,s_n)) != NULL){
                      TTRG->inh = XbWDDb_C_PtrToDbI(TSRC,XbWDDb_DbISys);
                      };
                    };
                  kein_pointer:;
                  };
                };
              break;
            };
          };
        };
      };
    };
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_F(        ***      Fur Knopfe, die keine Ed-Variante haben*/
int  XbWFOj_Ed_F(int edit, XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWFTb_ColCon(*TOB->bkc),0,*TOB->bfc);
  if (edit != 3){ return(0); };
  XbWFTb_Wait(150);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_S(        ***      String-Objekt editieren*/
int  XbWFOj_Ed_S(int edit, XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,XbWVGr_LRed);
  if (edit==3){ return(0);};
  XbWFOj_EdStr(TOB);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_HID(      ***      HEX/Integer/Double editieren*/
int  XbWFOj_Ed_HID(int edit, XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,XbWVGr_LRed);
  if (edit==3){return(0);};
  XbWFOj_EdInt(TOB);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_B(        ***      Boolesche Lampe editieren (invertieren)*/
int  XbWFOj_Ed_B(int edit, XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,XbWVGr_LRed);
  if (edit==3){ return(0);};
  XbWFOj_DpBool(TOB);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_L(        ***      Light-Objekt editieren (auswerten)*/
int  XbWFOj_Ed_L(int edit, XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,XbWVGr_LRed);
  if (edit==3){ return(0);};
  XbWFOj_DpSwt(TOB);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_C(        ***      Switch-Objekt auswerten*/
int  XbWFOj_Ed_C(int edit, XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,XbWVGr_LRed);
  if (edit==3){ return(0);};
  XbWFOj_EdSwt(TOB);
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_M(        ***      MFX-Gruppe lesen/schreiben*/
int  XbWFOj_Ed_M(int edit, XbWDDb_DbIObj  *TOB){
  XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,*TOB->bkc,0,XbWVGr_LRed);
  if (edit==3){ return(0);};
  XbWFOj_DpSwt(TOB);

  {
    char *rgr_nm, *rgr_rwm;
    char nsstr[40];
    int rw_smode,rw_snr;
    int ii;

    for (ii=0;ii<100;ii++){
      sprintf(nsstr,"xG%d",ii);
      if ((rgr_nm = (char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,nsstr,1))
        == NULL) {  return(0); };
      sprintf(nsstr,"xM%d",ii);
      if ((rgr_rwm =(char*)XbWFDb_VarInh(TOB->chn,XbWDDb_Str,nsstr,1))
        == NULL) {  return(0); };
      sprintf(nsstr,"xS%d",ii);
      rw_smode = (int)XbWFDb_GetNum(TOB->chn,nsstr,1);
      sprintf(nsstr,"xN%d",ii);
      rw_snr = (int)XbWFDb_GetNum(TOB->chn,nsstr,1);

      XbWFMx_RWGrp(rgr_nm,rgr_rwm,rw_smode,rw_snr,NULL);
      };
    };
  return(1);
  };

/*}}}  */
/*{{{  XbWFOj_Ed_X(        ***      XS=Slider, XB=Bit editieren*/
int  XbWFOj_Ed_X(int edit, XbWDDb_DbIObj  *TOB){
  switch(TOB->oet[1]){
    case 'S':
              XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
              if (edit==3){ return(0);};
              XbWFOj_EdSlider(TOB);
              break;
    case 'B':
              XbWSGr_TLBox(XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,NULL,XbWVGr_White,0,XbWVGr_LRed);
              if (edit==3){ return(0);};
              XbWFOj_DpBit(TOB);
              break;
    };
  return(1);
  };
/*}}}  */
/*{{{  XbWFOj_Ed_T(        ***      Taskstart ausfuhren*/
int  XbWFOj_Ed_T(XbWDDb_DbIWdw  *WI, int edit, XbWDDb_DbIObj  *TOB){
  if (edit==3){ return(0);};
  XbWFOj_SpawnTsk(WI,TOB,'_','_','C','P');
  return(1);
  };
/*}}}  */

/*{{{  XbWFGr_MaxX(        ***      VIDEO: Breite des nutzbaren Schirms*/
int  XbWFGr_MaxX(void){
  return(XbWVIDEO_XB-XbWVIDEO_XA);
  };
/*}}}  */
/*{{{  XbWFGr_MaxY(        ***      VIDEO: Hoehe...*/
int  XbWFGr_MaxY(void){
  return(XbWVIDEO_YB-XbWVIDEO_YA);
  };
/*}}}  */
/*{{{  XbWFGr_TWidth(      ***      Pixelbreite eines Strings ermitteln*/
int  XbWFGr_TWidth(char *sstr){
  XbWDDb_DbIVar  *sv_gp;
  int cx=11;
  if (XbWVWd_Wdt == 0) {
    sv_gp = XbWFDb_FindGrp("SVR","video");
    if (sv_gp != NULL){
      cx = (int)XbWFDb_GetNum(sv_gp,"CharX",1);
      if (cx == 0){
        cx = 8;
        }
      else {
        XbWVWd_Wdt = cx;
        };
      };
    }
  else {
    cx = XbWVWd_Wdt;
    };
  return(cx*strlen(sstr));
  };
/*}}}  */
/*{{{  XbWFGr_THeight(     ***      Pixelhoehe eines Zeichens ermitteln*/
int  XbWFGr_THeight(void){
  XbWDDb_DbIVar  *sv_gp;
  int cy=8;
  if (XbWVWd_Hgt == 0){
    if (XbWVDb_DbkStrt != NULL){
      sv_gp = XbWFDb_FindGrp("SVR","video");
      if (sv_gp != NULL){
        cy = (int)XbWFDb_GetNum(sv_gp,"CharY",1);
        if (cy == 0){
          cy = 12;
          }
        else {
          XbWVWd_Hgt = cy;
          };
        };
      }
    else {
      cy = 12;
      };
    }
  else {
    cy = XbWVWd_Hgt;
    };
  return(cy);
  };
/*}}}  */

/*{{{  XbWFGr_PushPort(    ***      Viewport-Verwaltung*/
void  XbWFGr_PushPort(void){
  if (XbWVTb_ViewPZ >= XbWDTb_MxVwPrt) { XbWVTb_ViewPZ = 1; };
  if (XbWVTb_ViewPZ < 1) { XbWVTb_ViewPZ = XbWDTb_MxVwPrt;  };
  XbWSGr_GetClip(&XbWVTb_ViewPLst[XbWVTb_ViewPZ]);
  XbWVTb_ViewPZ++;
  };
/*}}}  */
/*{{{  XbWFGr_PopPort(     ****/
void  XbWFGr_PopPort(void){
  if (XbWVTb_ViewPZ >= XbWDTb_MxVwPrt) { XbWVTb_ViewPZ = 1; };
  if (XbWVTb_ViewPZ < 1) { XbWVTb_ViewPZ = XbWDTb_MxVwPrt;  };
  XbWVTb_ViewPZ--;
  XbWVTb_VPX = XbWVTb_ViewPLst[XbWVTb_ViewPZ].left;
  XbWVTb_VPY = XbWVTb_ViewPLst[XbWVTb_ViewPZ].top;
  XbWVTb_VPx = XbWVTb_ViewPLst[XbWVTb_ViewPZ].right;
  XbWVTb_VPy = XbWVTb_ViewPLst[XbWVTb_ViewPZ].bottom;
  };
/*}}}  */
/*{{{  XbWFGr_SetPort(     ****/
void  XbWFGr_SetPort(void){
  XbWSGr_SetClip(0,0,XbWSGr_GtPhysX(),XbWSGr_GtPhysY());
  };
/*}}}  */
/*{{{  XbWFGr_MaxPort(     ****/
void  XbWFGr_MaxPort(void){
  XbWSGr_SetClip(XbWVIDEO_XA,XbWVIDEO_YA,XbWVIDEO_XB,XbWVIDEO_YB);
  };
/*}}}  */
/*{{{  XbWFGr_MinPort(     ****/
void  XbWFGr_MinPort(int xxa,int yya,int xxb,int yyb){
  int xa,ya,xb,yb;
  xa=xxa+XbWVIDEO_XA;ya=yya+XbWVIDEO_YA;xb=xxb+XbWVIDEO_XA;yb=yyb+XbWVIDEO_YA;
  if (xa < XbWVIDEO_XA)   xa = XbWVIDEO_XA;
  if (ya < XbWVIDEO_YA)   ya = XbWVIDEO_YA;
  if (xb > XbWVIDEO_XB)   xb = XbWVIDEO_XB;
  if (yb > XbWVIDEO_YB)   yb = XbWVIDEO_YB;
  XbWVTb_VPX = xa; XbWVTb_VPY = ya; XbWVTb_VPx = xb; XbWVTb_VPy = yb;
  XbWSGr_SetClip(xa,ya,xb,yb);
  };
/*}}}  */
/*{{{  XbWFGr_RedPort(     ****/
void   XbWFGr_RedPort(
    int xa,int ya,int xb,int yb){
  xa+=XbWVIDEO_XA;ya+=XbWVIDEO_YA;xb+=XbWVIDEO_XA;yb+=XbWVIDEO_YA;
  if (xa < XbWVTb_VPX)   xa = XbWVTb_VPX;
  if (xa >= XbWVTb_VPx)   xa = XbWVTb_VPx-1;
  if (ya < XbWVTb_VPY)   ya = XbWVTb_VPY;
  if (ya >= XbWVTb_VPy)   ya = XbWVTb_VPy-1;
  if (xb <= XbWVTb_VPX)   xb = XbWVTb_VPX+1;
  if (xb > XbWVTb_VPx)   xb = XbWVTb_VPx;
  if (yb <= XbWVTb_VPY)   yb = XbWVTb_VPY+1;
  if (yb > XbWVTb_VPy)   yb = XbWVTb_VPy;
  if (xa < 5)   xa = 5;if (ya < 0)   ya = 0;
  if (xb > XbWFGr_MaxX())   xb = XbWFGr_MaxX();
  if (yb > XbWFGr_MaxY())   yb = XbWFGr_MaxY();
  if ((xb-xa > XbWFGr_MaxX()) |
     (yb-ya > XbWFGr_MaxY()))   {
    xa = 0; xb = 2; ya = 0; yb = 2;
    };
  if ((xb-xa < 3) |
     (yb-ya < 3))   {
    xa = 0; xb = 2; ya = 0; yb = 2;
    };
  XbWVTb_VPX = xa; XbWVTb_VPY = ya; XbWVTb_VPx = xb; XbWVTb_VPy = yb;
  XbWSGr_SetClip(xa,ya,xb,yb);
  };
/*}}}  */
/*{{{  XbWFGr_ResPort(     ****/
void   XbWFGr_ResPort(void){
  XbWSGr_SetClip(XbWVTb_VPX,XbWVTb_VPY,XbWVTb_VPx,XbWVTb_VPy);
  };
/*}}}  */

/*{{{  XbWFWd_BackGr(      ***      Hintergrund des Schirms fuellen*/
void   XbWFWd_BackGr(void){
  XbWFGr_SetPort();
  XbWSGr_TLBox(0,0,XbWSGr_GtPhysX()-1,XbWSGr_GtPhysY()-1,
    " ",XbWDGr_BkColor,0,XbWDGr_BkColor);
  XbWFGr_ResPort();
  };
/*}}}  */
/*{{{  XbWFWd_Erase(       ***      Window loeschen*/
void   XbWFWd_Erase(XbWDDb_DbIWdw  *WI){
  XbWFGr_MaxPort();
  XbWSGr_CCBox(
    *WI->nx-1,*WI->ny-1,
    *WI->nx+ *WI->sx+1, *WI->ny+ *WI->sy+1,
    NULL,XbWDGr_BkColor,0,XbWDGr_BkColor);
  };
/*}}}  */

/*{{{  XbWFTb_Message(     ***      Nachricht unten ausgeben*/
void  XbWFTb_Message(char *msg){
  int cset;
  cset = XbWVMs_CSet;
 
  XbWSMs_OFF();
  XbWFGr_PushPort();
  XbWFGr_SetPort();
  XbWSGr_TLBox(1,XbWSGr_GtPhysY()-XbWDWd_BordH,500,XbWSGr_GtPhysY()-1,
     msg,XbWVGr_Cyan,XbWVGr_White,XbWVGr_Green);
  XbWFGr_PopPort();
  XbWFGr_ResPort();
  if (cset) {
    XbWSMs_ON();
    };
#ifdef XbW_SYSDEF_X11_VERSION
  printf("\n%s",msg);
#endif
  };
/*}}}  */
/*{{{  XbWFTb_Warning(     ***      Nachricht unten ausgeben*/
void  XbWFTb_Warning(char *msg){
  int cset;
  cset = XbWVMs_CSet;
  XbWSMs_OFF();
  XbWFGr_PushPort();
  XbWFGr_SetPort();
  XbWSGr_TLBox(1,XbWSGr_GtPhysY()-XbWDWd_BordH,500,XbWSGr_GtPhysY()-1,
     msg,XbWVGr_Yellow,XbWVGr_DGray,XbWVGr_DGray);
  XbWFGr_PopPort();
  XbWFGr_ResPort();
  if (cset) {
    XbWSMs_ON();
    };
  };
/*}}}  */
/*{{{  XbWFTb_Error(       ***      Nachricht; warte auf Taste*/
void  XbWFTb_Error(char*msg){
  XbWSMs_OFF();
  printf("\n* * * A fatal error has occurred:\n%s\n",msg);
  printf("* * * Last command prepared: %s\nXbW command line buffer: %s\n\n",
    XbWVSy_DebugCommand,XbWVSy_DebugLine);
  if (XbWVMf_C >= 0){
    printf("Last command parameter prepared: no %d\n",XbWVMf_C);
    switch(XbWVMf_T[XbWVMf_C-1]) {
      case XbWDMf_StrPar:
        printf("* * * STRING PARAMETER \"%s\"\n",&(XbWVMf_B[(XbWVMf_C)*XbWDMf_BfStrL]));
        break;
      case XbWDMf_DblPar:
        printf("* * * DOUBLE PARAMETER \"%s\"\n",&(XbWVMf_B[(XbWVMf_C)*XbWDMf_BfStrL]));
        break;
      case XbWDMf_IntPar:
      case XbWDMf_VPPar:
        printf("* * * INT PARAMETER \"%d\"\n",(int)XbWVMf_P[XbWVMf_C]);
        break;
      case XbWDMf_VLPar:
        printf("* * * POINTER PARAMETER\n");
        break;
      case XbWDMf_VIPar:
        printf("* * * VI-INT PARAMETER \"%d\"\n",(int)XbWVMf_P[XbWVMf_C]);
        break;
      };
    };
 
  printf("\n* * * Actual interpreter scan position: >>>\"%s\"\n\n",XbWVSy_DebugLinePos);
 
  XbWSPu_Alarm(msg);
  XbWSMs_ON();
  XbWFMf_ReadMakro("@sys\\stop;");
  };
/*}}}  */
/*{{{  XbWFTb_CmpBox(      ***      Check ob Obj ganz au�erhalb e.Wdws ist*/
int  XbWFTb_CmpBox(int oxa,int oya,int oxb,int oyb,
                int wxa,int wya,int wxb,int wyb){
/*
Pr"uft ob Objekt oxa,oya..oxb,oyb im Window wxa,wya...wxb,wyb ist
*/
  int inwin;
  inwin = 1;
  if (oxa > wxb) {inwin = 0;};
  if (oxb < wxa) {inwin = 0;};
  if (oya > wyb) {inwin = 0;};
  if (oyb < wya) {inwin = 0;};
  return(inwin);
  };
/*}}}  */
 
/*{{{  XbWFWd_Make(        ***      Window zeichnen (Jetzt nur noch Box...)*/
void   XbWFWd_Make(XbWDDb_DbIWdw  *WI){
  XbWFGr_MaxPort();
  XbWSGr_TLBox(
    *WI->nx-1, *WI->ny-1,
    *WI->nx+ *WI->sx+1, *WI->ny+ *WI->sy+1,
    NULL,
    *WI->bkc, 0, *WI->dfc);
  XbWSGr_Line(
    *WI->nx,          *WI->ny,
    *WI->nx+ *WI->sx, *WI->ny, *WI->bfc);
  XbWSGr_Line(
    *WI->nx,          *WI->ny,
    *WI->nx,          *WI->ny+ *WI->sy, *WI->bfc);
  XbWSGr_Line(
    *WI->nx,          *WI->ny-1,
    *WI->nx+ *WI->sx, *WI->ny-1, *WI->bfc);
  XbWSGr_Line(
    *WI->nx-1,        *WI->ny,
    *WI->nx-1,        *WI->ny+ *WI->sy, *WI->bfc);
  XbWSGr_Line(
    *WI->nx+ *WI->sx, *WI->ny,
    *WI->nx+ *WI->sx, *WI->ny+ *WI->sy, *WI->dfc);
  XbWSGr_Line(
    *WI->nx,          *WI->ny+ *WI->sy,
    *WI->nx+ *WI->sx, *WI->ny+ *WI->sy, *WI->dfc);
 
 
  XbWFGr_MinPort(*WI->nx+1, *WI->ny+1,*WI->nx+ *WI->sx-1,
                      *WI->ny+ *WI->sy-1);
  };
/*}}}  */

/*{{{  XbWFOb_SetViewPort( ***      Viewport auf Objekt einstellen*/
void  XbWFOb_SetViewPort(XbWDDb_DbIWdw  *WI,XbWDDb_DbIObj  *TO){
  int xa,ya,xb,yb;
  xa = *TO->XA;       ya = *TO->YA;       xb = *TO->XB;       yb = *TO->YB;
  if (xa < 0) { xa=0; };
  if (ya < 0) { ya=0; };
  if (xb < 0) { xb=0; };
  if (yb < 0) { yb=0; };
  if (xa > *WI->sx){ xa = *WI->sx; };
  if (ya > *WI->sy){ ya = *WI->sy; };
  if (xb > *WI->sx){ xb = *WI->sx; };
  if (yb > *WI->sy){ yb = *WI->sy; };
  XbWFGr_MinPort(
    *WI->nx+xa,
    *WI->ny+ya+1,
    *WI->nx+xb,
    *WI->ny+yb+1);
  };
/*}}}  */
 
