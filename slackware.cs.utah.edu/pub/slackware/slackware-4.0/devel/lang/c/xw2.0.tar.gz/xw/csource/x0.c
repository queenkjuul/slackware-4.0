 
/*{{{  Include*/

#include "xbw.h"
 
/*}}}  */

/* --Variablen-------------------------- */

/*{{{  Bildschirmfarben*/

  int
    XbWVGr_Black    =0,
    XbWVGr_Blue         =1,
    XbWVGr_Green        =2,
    XbWVGr_Cyan         =3,
    XbWVGr_Red          =4,
    XbWVGr_Magenta      =5,
    XbWVGr_Brown        =6,
    XbWVGr_LGray    =7,
    XbWVGr_DGray     =8,
    XbWVGr_LBlue    =9,
    XbWVGr_LGreen   =10,
    XbWVGr_LCyan    =11,
    XbWVGr_LRed     =12,
    XbWVGr_LMagenta =13,
    XbWVGr_Yellow       =14,
    XbWVGr_White        =15;

/*}}}  */
/*{{{  Mauszeiger*/


  boolean
    XbWVMs_Rechts,XbWVMs_Links,XbWVMs_Rauf,XbWVMs_Runter,
    XbWVMs_Bewegt,XbWVMs_Button,XbWVMs_LButt,XbWVMs_RButt,XbWVMs_MButt;
  int
    XbWVMs_XPos,XbWVMs_YPos,
    XbWVMs_CX,XbWVMs_CY;
  XbWDMs_CurFrm
    XbWVMs_CFrm;
  boolean
    XbWVMs_CSet;
  int XbWVMs_XSense,XbWVMs_YSense,
    XbWVMs_Speed;
/*}}}  */
/*{{{  Fensterverwaltung*/

char        *XbWVWd_Name[XbWDWd_MaxWdw+1];
XbWDDb_DbIVar  *XbWVWd_Grp[XbWDWd_MaxWdw+1];
int         XbWVWd_MaxReg = 0;
/*}}}  */
/*{{{  Interpreter-Kommandos*/

char *XbWVMf_com[XbWDMf_MaxCmd];
/*}}}  */
/*{{{  Interpreter-Variablen*/

char *XbWVSy_DebugLine = "";
char *XbWVSy_DebugLinePos = "";
char *XbWVSy_DebugCommand = "";

char *XbWVMf_af;
int *XbWVMf_az;

int XbWVMf_dmf = 0;

int XbWVMf_prd=0;


int XbWVMf_Cerr;
void  *XbWVMf_P[XbWDMf_MaxPar];
int XbWVMf_T[XbWDMf_MaxPar];
char XbWVMf_B[XbWDMf_MaxPar*XbWDMf_BfStrL];
char XbWVMf_eof;
int  XbWVMf_C;

XbWDMf_AktPar ( *XbWVMf_aP)[] = NULL;


int XbWVMf_CErr=0;


char XbWVMf_gn[130],XbWVMf_ln[130],XbWVMf_nn[130];

char XbWVMf_jln[140]; int XbWVMf_jtl = 0;

int XbWVMf_mlv = 0;


/*}}}  */
/*{{{  Daten f�r Objektverwaltung*/


int XbWVOb_MovOK = 0;

int XbWVOb_X,XbWVOb_Y,XbWVOb_x,XbWVOb_y,XbWVOb_ox,XbWVOb_oy;

int XbWVOb_EdLvl = 0;

XbWDDb_DbIVar  *XbWVOb_GOPlv = NULL;
XbWDDb_DbIVar  *XbWVOb_GOPao = NULL;
char *XbWVOb_GOPnm = NULL;

char XbWVOb_GTxt[60];





/*}}}  */
/*{{{  Daten f�r Unterfunktionen Objektverwaltung*/



fpos_t XbWVOb_pos = 0;
FILE        *XbWVOb_afil = NULL;

XbWDDb_DbIVar  *XbWVOb_mgr;
XbWDDb_DbIVar  *XbWVOb_mao;
char *XbWVOb_agr, *XbWVOb_aon;

/*}}}  */


/*{{{  Maus Variablen*/
#ifndef XbW_SYSDEF_X11_VERSION
union REGS XbWVMs_regs;
#endif[5~

void far *XbWVMs_bits = NULL;

int XbWVMs_axa=-30000,XbWVMs_aya=-30000,
      XbWVMs_cxa=-1, XbWVMs_cya=-1;


/*}}}  */
/*{{{  Globale Windows-Variablen*/

char XbWVSy_HomeDir[60];
int XbWVSy_HomeDrv;
char XbWVSy_AppPath[60];
char XbWVSy_PrjPath[60];

int XbWVWd_AClos = 0;
int XbWVWd_RedrawON = 1;

int XbWVWd_Hgt=0;
int XbWVWd_Wdt=0;

int XbWVWd_OldMsg;

int XbWVWd_Activ = 1;

time_t XbWVSy_Time=0;


char XbWVSy_ExecNameHook[60];

/*}}}  */
/*{{{  Variablen f�r Tool-Funktionen*/

char XbWVTb_PTS[XbWDTb_PckTLen];
/*}}}  */
/*{{{  Variablen f�r DOSTASKS*/

char XbWVSy_DosCmd[265];
char XbWVSy_MfName[265];
/*}}}  */
/*{{{  Variablen GRAFIKpaket*/


struct viewporttype XbWVTb_ViewPLst[XbWDTb_MxVwPrt];

int XbWVTb_ViewPZ,XbWVTb_VPX,XbWVTb_VPY,XbWVTb_VPx,XbWVTb_VPy;




/*}}}  */

/*{{{  Variablen VARLISTE*/

char XbWVDb_AktNam[16];

long XbWVDb_PrjSize;

XbWDDb_DbIVar  *XbWVDb_AktDObj = NULL;
XbWDDb_DbIVar  *XbWVDb_AktDKey = NULL;

int XbWVDb_DbkStat = 0;
int XbWVDb_DbkFile = -1;

int XbWVDb_FndNum = 0;

XbWDDb_Sys  *XbWVDb_DbkStrt = NULL;
XbWDDb_Sys  *XbWVDb_DbkStrtMem = NULL;
XbWDDb_DbIVar  *XbWVDb_AkDbkEl = NULL;
XbWDDb_DbIVar  *XbWVDb_ActGrp1 = NULL;
XbWDDb_DbIVar  *XbWVDb_ActGrp2 = NULL;

extern char *XbWVMf_com[];
char *XbWVMf_LCmd = "<No Command>";

/*}}}  */

/*{{{  Variablen Windowverwaltung*/

int XbWVWd_FoundNo = 0;
int XbWVWd_DrawNr = 0;
extern int XbWVWd_RedrawON;

XbWDDb_DbIWdw XbWVWd_LastDsp;
XbWDDb_DbIWdw XbWVWd_W;           /* Aktives Display-Window */

extern int XbWVWd_AClos;
time_t XbWVWd_Time = 0;
int  XbWVWd_ADspNr = 0;
char XbWVWd_CStr[100] = "                                       ";
int XbWVWd_CErr = 0;


/*}}}  */
/*{{{  Variablen EDITOR*/

int
  XbWVEd_CrFrm = XbWDEd_UnLine,
  XbWVEd_CrKey = XbWDEd_EndItm;  /* :: mit CR wird Eingabe beendet         */
                                 /* Eine 0 bedeutet, da"s mit {\tt CR} zum */
                                 /* n"achsten Objekt gegangen wird.        */

XbWDEd_NxtTyp
  XbWVEd_nxt;

 boolean XbWVEd_ins= 0;        /* Status des Insert- Flags               */


 int XbWVEd_xhp,XbWVEd_yhp;        /* Position des Fragetextes               */
 char XbWVEd_hdr[35];               /* Fragetext                              */
 int XbWVEd_hcol;                   /* Farbe der Frage                        */
 int XbWVEd_xa,XbWVEd_ya;        /* Linke obere Ecke des Editierfensters   */
 int XbWVEd_xb,XbWVEd_yb;        /* Rechte Untere...                       */
 char XbWVEd_sst[257];              /* Zu gredierender String                 */
 unsigned char XbWVEd_scol;                /* Farbe desselben                        */


 char XbWVEd_zstr[255];             /* Der Puffer                             */
 unsigned char XbWVEd_zc,XbWVEd_zf;                    /* Ein Zeichen                            */
 int
   XbWVEd_c,XbWVEd_send,
   XbWVEd_crpos,
   XbWVEd_cpos;                   /* Ein paar Zeiger                        */
 int XbWVEd_lcnt;                 /* Zeichenz"ahler                         */
 int XbWVEd_vpos,XbWVEd_npos,     /* Noch mehr Zeiger                       */
     XbWVEd_spos,
     XbWVEd_mvport = 0;
 char XbWVEd_coptxt[255];           /* Noch ein Puffer                        */
/*}}}  */




time_t XbWVSy_AltChkActTime = 0;



#ifdef XbW_SYSDEF_GNU_VERSION
long XbWVSy_DlyLim = 800;
#include "xgnu.c"
#endif

XbWDSy_XbWContxt XbWVSy_ConTxt;

XbWDIf_GlobDsc XbWVIf_GlbDsc = {
  {NULL, NULL, NULL}
  };





char XbWVMs_PtrHand[] = {
    0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,1,0,0,0,0,0,
    0,0,0,0,1,1,2,1,1,0,0,0,
    0,0,0,1,2,1,1,1,2,1,0,0,
    0,0,0,1,1,1,2,1,1,1,1,0,
    0,0,0,1,2,1,2,1,2,1,2,1,
    0,1,1,1,2,1,2,1,2,1,1,1,
    1,1,2,1,2,1,2,1,2,1,2,1,
    1,1,2,1,2,1,2,1,2,1,2,1,
    1,2,2,1,2,2,2,2,2,2,2,1,
    1,2,2,1,2,2,2,2,2,2,2,1,
    0,1,2,2,2,2,2,2,2,2,2,1,
    0,0,1,2,2,2,2,2,2,2,2,1,
    0,0,0,1,2,2,2,2,2,2,2,1,
    0,0,0,1,2,2,2,2,2,2,1,0,
    0,0,0,1,2,2,2,2,2,2,1,0,
};

char XbWVMs_PtrArrow[] = {
    0,1,0,0,0,0,0,0,0,0,0,0,
    1,2,1,0,0,0,0,0,0,0,0,0,
    1,2,2,1,0,0,0,0,0,0,0,0,
    1,2,2,2,1,0,0,0,0,0,0,0,
    1,2,2,2,2,1,0,0,0,0,0,0,
    1,2,2,2,2,2,1,0,0,0,0,0,
    1,2,2,2,2,2,2,1,0,0,0,0,
    1,2,2,2,2,2,2,2,1,0,0,0,
    1,2,2,2,2,2,2,2,2,1,0,0,
    1,2,2,2,2,2,2,2,2,2,1,0,
    1,2,2,2,2,2,2,2,2,2,2,1,
    1,2,2,2,2,1,1,1,1,1,1,0,
    1,2,2,2,1,0,0,0,0,0,0,0,
    1,2,2,1,0,0,0,0,0,0,0,0,
    1,2,1,0,0,0,0,0,0,0,0,0,
    0,1,0,0,0,0,0,0,0,0,0,0,
};

char XbWVMs_PtrClock[] = {
    0,0,0,0,1,1,1,1,0,0,0,0,
    0,0,0,0,1,1,1,1,0,0,0,0,
    0,0,0,0,1,1,1,1,0,0,0,0,
    0,0,0,1,2,2,2,2,1,0,0,0,
    0,0,1,2,2,2,2,2,2,1,0,0,
    0,0,1,2,1,2,2,2,2,1,0,0,
    0,1,2,2,1,1,2,2,2,2,1,0,
    0,1,2,2,2,1,1,1,1,1,1,0,
    0,1,2,2,2,2,2,2,2,2,1,0,
    0,0,1,2,2,2,2,2,2,1,0,0,
    0,0,1,2,2,2,2,2,2,1,0,0,
    0,0,0,1,2,2,2,2,1,0,0,0,
    0,0,0,0,1,1,1,1,0,0,0,0,
    0,0,0,0,1,1,1,1,0,0,0,0,
    0,0,0,0,1,1,1,1,0,0,0,0,
    0,0,0,0,1,1,1,1,0,0,0,0
};

char XbWVMs_PtrStop[] = {
    0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,2,2,2,2,0,0,0,0,
    0,0,0,2,1,1,1,1,2,0,0,0,
    0,0,2,1,2,2,2,2,1,2,0,0,
    0,2,1,2,2,2,2,2,2,1,2,0,
    0,2,1,2,2,2,2,1,1,1,2,0,
    2,1,2,2,2,2,1,1,2,2,1,2,
    2,1,2,2,2,1,1,1,2,2,1,2,
    2,1,2,2,1,1,1,2,2,2,1,2,
    0,2,1,2,1,1,2,2,2,1,2,0,
    0,2,1,1,1,2,2,2,2,1,2,0,
    0,0,2,1,2,2,2,2,1,2,0,0,
    0,0,0,2,1,1,1,1,2,0,0,0,
    0,0,0,0,2,2,2,2,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0
};

#ifdef XbW_SYSDEF_GNU_VERSION
  GrCursor *XbWVMs_PtrPtrClock = NULL;
  GrCursor *XbWVMs_PtrPtrArrow = NULL;
  GrCursor *XbWVMs_PtrPtrHand  = NULL;
  GrCursor *XbWVMs_PtrPtrStop  = NULL;
  GrCursor *XbWVMs_PtrActualPtr = NULL;
#endif
#ifdef XbW_SYSDEF_X11_VERSION
  Cursor XbWVMs_PtrPtrClock = 0;
  Cursor XbWVMs_PtrPtrArrow = 0;
  Cursor XbWVMs_PtrPtrHand  = 0;
  Cursor XbWVMs_PtrPtrStop  = 0;
  Cursor XbWVMs_PtrActualPtr = 0;
#endif
#ifdef XbW_SYSDEF_TC3_VERSION
  void  *XbWVMs_PtrPtrClock = NULL;
  void  *XbWVMs_PtrPtrArrow = NULL;
  void  *XbWVMs_PtrPtrHand  = NULL;
  void  *XbWVMs_PtrPtrStop  = NULL;
  void  *XbWVMs_PtrActualPtr = NULL;
#endif

  char *XbWVGr_ColorTexte[] = {
    "black",
    "blue3",
    "green3",
    "cyan3",
    "red3",
    "magenta3",
    "sandybrown",
    "lightgray",
    "black",
    "lightblue1",
    "green1",
    "cyan1",
    "red1",
    "magenta1",
    "yellow",
    "white",
 
    "gold",
    "maroon",
    "tomato",
    "hotpink",
 
    "beige",
    "seagreen",
    "salmon",
    "purple",
 
    "dark khaki",
    "",
    "",
    "",
 
    "",
    "",
    "",
    "",
    };

  unsigned long int XbWVGr_ColorValues[64];

  char XbWVSy_PrjName[40];

#ifdef XbW_SYSDEF_X11_VERSION
int XbW_X11_ScreenWidth=800;
int  XbW_X11_ScreenHeight=600;
#endif

