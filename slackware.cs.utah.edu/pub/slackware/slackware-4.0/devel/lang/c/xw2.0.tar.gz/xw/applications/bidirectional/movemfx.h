
#define ProgramName move

typedef struct {
  int A;           /* Number A */
  int B;           /* Number B */
  } MFI;

extern MFI mfi;

#ifdef MFX_INIT
MFI mfi = {
  1,2
  };
#endif

typedef struct {
  int A;           /* Number A */
  int B;           /* Number B */
  } MFO;

extern MFO mfo;

#ifdef MFX_INIT
MFO mfo = {
  1,2
  };
#endif

