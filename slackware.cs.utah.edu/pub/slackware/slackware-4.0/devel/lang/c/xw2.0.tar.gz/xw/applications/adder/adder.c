
#include "stdlib.h"            /* Standard Includes                          */
#include "stdio.h"

#define MFI_INIT 1
#include "addermfx.h"          /* Get MFX Data Structure                     */
#include "xbmfx.c"             /* Get Lowlevel Routines for MFX Read/Write   */
#include "addermfx.c"          /* Ret Read and Write MFX Routines            */
 
main(){
  ReadMFXGroup_mfi(0,0);       /* Data Input Section                         */
  mfi.Display=1;               /* Data Processing:    activate object display*/
  switch(mfi.Cmd[0]){                              /* execute command        */
    case 'A' : mfi.Sum = mfi.A + mfi.B; break;     /* ADD                    */
    case 'S' : mfi.Sum = mfi.A - mfi.B; break;     /* SUB                    */
    default  : mfi.Display=0;                      /* object display OFF     */
    };
  WriteMFXGroup_mfi(0,0,0);    /* Data Output Section                        */
  };

 
 
