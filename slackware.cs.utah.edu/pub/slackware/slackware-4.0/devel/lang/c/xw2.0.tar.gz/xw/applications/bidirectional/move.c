 
#include "stdlib.h"
#include "stdio.h"

#define  MFX_INIT 1
#include "movemfx.h"
#include "xbmfx.c"
#include "movemfx.c"

main(){
  ReadMFXGroup_mfi(0,0);
  mfo.A = mfi.A;
  mfo.B = mfi.B;
  WriteMFXGroup_mfo(0,0,0);
  };
 
