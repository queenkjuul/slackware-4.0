/*  XbW MetaFile eXchange (Interface to Applications): XBMFX  */

#ifdef thestruct
#undef thestruct
#endif
#define thestruct tst

int WriteMFXGroup_tst(char*filename, char*dataset, char *mode){
  if (filename == NULL) { filename = "tst.mfx"; } 
  if (dataset == NULL) { dataset = "tst"; }
  if (mode == NULL) { mode = "w"; }
  if (XbWMFX_WriteSet(filename,dataset,mode)) {
    return(1);
    }
XbWMFX_PutInteger(&thestruct.einsa,"einsa");
XbWMFX_PutDouble(&thestruct.zweia,"zweia");
XbWMFX_PutInteger(&thestruct.dreia,"dreia");
XbWMFX_PutString(thestruct.viera,"viera");
XbWMFX_PutInteger(&thestruct.einsb[0],"einsb[0]");
XbWMFX_PutInteger(&thestruct.einsb[1],"einsb[1]");
XbWMFX_PutInteger(&thestruct.einsb[2],"einsb[2]");
XbWMFX_PutDouble(&thestruct.zweib[0],"zweib[0]");
XbWMFX_PutDouble(&thestruct.zweib[1],"zweib[1]");
XbWMFX_PutInteger(&thestruct.dreib[0],"dreib[0]");
XbWMFX_PutInteger(&thestruct.dreib[1],"dreib[1]");
XbWMFX_PutString(&thestruct.vierb[0][0],"vierb[0]");
XbWMFX_PutString(&thestruct.vierb[1][0],"vierb[1]");
XbWMFX_PutString(&thestruct.vierb[2][0],"vierb[2]");
XbWMFX_PutString(&thestruct.vierb[3][0],"vierb[3]");
XbWMFX_PutString(&thestruct.vierb[4][0],"vierb[4]");
XbWMFX_PutString(&thestruct.vierb[5][0],"vierb[5]");
XbWMFX_PutString(&thestruct.vierb[6][0],"vierb[6]");
XbWMFX_PutString(&thestruct.vierb[7][0],"vierb[7]");
XbWMFX_PutString(&thestruct.vierb[8][0],"vierb[8]");
XbWMFX_PutString(&thestruct.vierb[9][0],"vierb[9]");
XbWMFX_PutString(&thestruct.vierb[10][0],"vierb[10]");
XbWMFX_PutString(&thestruct.vierb[11][0],"vierb[11]");
XbWMFX_PutString(&thestruct.vierb[12][0],"vierb[12]");
XbWMFX_PutString(&thestruct.vierb[13][0],"vierb[13]");
XbWMFX_PutString(&thestruct.vierb[14][0],"vierb[14]");
XbWMFX_PutString(&thestruct.vierb[15][0],"vierb[15]");
XbWMFX_PutString(&thestruct.vierb[16][0],"vierb[16]");
XbWMFX_PutString(&thestruct.vierb[17][0],"vierb[17]");
XbWMFX_PutString(&thestruct.vierb[18][0],"vierb[18]");
XbWMFX_PutString(&thestruct.vierb[19][0],"vierb[19]");
XbWMFX_PutString(&thestruct.vierb[20][0],"vierb[20]");
XbWMFX_PutString(&thestruct.vierb[21][0],"vierb[21]");
XbWMFX_PutString(&thestruct.vierb[22][0],"vierb[22]");
XbWMFX_PutString(&thestruct.vierb[23][0],"vierb[23]");
XbWMFX_PutString(&thestruct.vierb[24][0],"vierb[24]");
XbWMFX_PutString(&thestruct.vierb[25][0],"vierb[25]");
XbWMFX_PutString(&thestruct.vierb[26][0],"vierb[26]");
XbWMFX_PutString(&thestruct.vierb[27][0],"vierb[27]");
XbWMFX_PutString(&thestruct.vierb[28][0],"vierb[28]");
XbWMFX_PutString(&thestruct.vierb[29][0],"vierb[29]");
XbWMFX_PutString(&thestruct.vierb[30][0],"vierb[30]");
XbWMFX_PutString(&thestruct.vierb[31][0],"vierb[31]");
XbWMFX_PutString(&thestruct.vierb[32][0],"vierb[32]");
XbWMFX_PutInteger(&thestruct.einsc[0][0],"einsc[0][0]");
XbWMFX_PutInteger(&thestruct.einsc[0][1],"einsc[0][1]");
XbWMFX_PutInteger(&thestruct.einsc[1][0],"einsc[1][0]");
XbWMFX_PutInteger(&thestruct.einsc[1][1],"einsc[1][1]");
XbWMFX_PutDouble(&thestruct.zweic[0][0],"zweic[0][0]");
XbWMFX_PutDouble(&thestruct.zweic[0][1],"zweic[0][1]");
XbWMFX_PutDouble(&thestruct.zweic[1][0],"zweic[1][0]");
XbWMFX_PutDouble(&thestruct.zweic[1][1],"zweic[1][1]");
XbWMFX_PutInteger(&thestruct.dreic[0][0],"dreic[0][0]");
XbWMFX_PutInteger(&thestruct.dreic[0][1],"dreic[0][1]");
XbWMFX_PutInteger(&thestruct.dreic[1][0],"dreic[1][0]");
XbWMFX_PutInteger(&thestruct.dreic[1][1],"dreic[1][1]");
XbWMFX_PutInteger(&thestruct.einsd[0][0][0],"einsd[0][0][0]");
XbWMFX_PutInteger(&thestruct.einsd[0][0][1],"einsd[0][0][1]");
XbWMFX_PutInteger(&thestruct.einsd[1][0][0],"einsd[1][0][0]");
XbWMFX_PutInteger(&thestruct.einsd[1][0][1],"einsd[1][0][1]");
XbWMFX_PutDouble(&thestruct.zweid[0][0][0],"zweid[0][0][0]");
XbWMFX_PutDouble(&thestruct.zweid[0][0][1],"zweid[0][0][1]");
XbWMFX_PutDouble(&thestruct.zweid[1][0][0],"zweid[1][0][0]");
XbWMFX_PutDouble(&thestruct.zweid[1][0][1],"zweid[1][0][1]");
XbWMFX_PutInteger(&thestruct.dreid[0][0][0],"dreid[0][0][0]");
XbWMFX_PutInteger(&thestruct.dreid[0][0][1],"dreid[0][0][1]");
XbWMFX_PutInteger(&thestruct.dreid[1][0][0],"dreid[1][0][0]");
XbWMFX_PutInteger(&thestruct.dreid[1][0][1],"dreid[1][0][1]");
  XbWMFX_WriteEnd();
  XbWMFX_CloseSet();
  return(0);
  }

int ReadMFXGroup_tst(char*filename, char*dataset){
  if (filename == NULL) { filename = "tst.mfx"; } 
  if (dataset == NULL) { dataset = "tst"; }
  if (XbWMFX_ReadSet(filename,dataset)) {
    puts("ERR on opening MFX file; I will now try to append");
    ropenerr:;
    printf("a working MFX Group %s to the end of file %s...\n",dataset,filename);
    if (!WriteMFXGroup_tst(filename,dataset,"a")){
      puts("...done. Exiting with error code.");
      printf("The end of file %s should now be readable. Please check its contents!\n",filename);
      printf("If %s did not exist until now, don't get crazy :)\n",filename);
      return(1);
      }
    else {
      puts("...did not work. Exiting with error code.");
      printf("I must now overwrite your file %s, sorry. Please check its contents!\n",filename);
      WriteMFXGroup_tst(filename,dataset,"w");
      printf("If %s did not exist until now, don't get crazy :)\n",filename);
      return(1);
      }
    }
if(XbWMFX_GetInteger(&thestruct.einsa)){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweia)){goto error;}
if(XbWMFX_GetShort(&thestruct.dreia)){goto error;}
if(XbWMFX_GetString(thestruct.viera)){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsb[0])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsb[1])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsb[2])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweib[0])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweib[1])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreib[0])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreib[1])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[0][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[1][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[2][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[3][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[4][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[5][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[6][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[7][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[8][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[9][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[10][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[11][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[12][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[13][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[14][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[15][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[16][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[17][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[18][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[19][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[20][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[21][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[22][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[23][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[24][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[25][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[26][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[27][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[28][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[29][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[30][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[31][0])){goto error;}
if(XbWMFX_GetString(&thestruct.vierb[32][0])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsc[0][0])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsc[0][1])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsc[1][0])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsc[1][1])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweic[0][0])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweic[0][1])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweic[1][0])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweic[1][1])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreic[0][0])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreic[0][1])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreic[1][0])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreic[1][1])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsd[0][0][0])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsd[0][0][1])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsd[1][0][0])){goto error;}
if(XbWMFX_GetInteger(&thestruct.einsd[1][0][1])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweid[0][0][0])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweid[0][0][1])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweid[1][0][0])){goto error;}
if(XbWMFX_GetDouble(&thestruct.zweid[1][0][1])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreid[0][0][0])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreid[0][0][1])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreid[1][0][0])){goto error;}
if(XbWMFX_GetShort(&thestruct.dreid[1][0][1])){goto error;}
  XbWMFX_CloseSet();
  return(0);
error:;
  printf("Error while reading MFX Group tst\n");  XbWMFX_CloseSet();
  puts("I will now try to append");
  goto ropenerr;
  }



#undef thestruct
