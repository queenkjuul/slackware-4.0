
#define MFX_INIT 1

#include "test.mfx.h"

