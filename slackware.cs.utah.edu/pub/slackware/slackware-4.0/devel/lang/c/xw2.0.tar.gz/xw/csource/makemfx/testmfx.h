
#define ProgramName  test

typedef struct {
  int einsa;
  double zweia;
  short dreia;
  char viera[33];
  int einsb[3];
  double zweib[2];
  short dreib[2];
  char vierb[33][2];
  int einsc[2][2];
  double zweic[2][2];
  short dreic[2][2];
  int einsd[2][1][2];
  double zweid[2][1][2];
  short dreid[2][1][2];
  } TTest;

extern TTest tst;

#ifdef MFX_INIT
TTest tst = {
  1, 2, 3, "4",
  {11,21,31},{21,22}, {31,32}, {"41","42"},
  {111,112,121,122},{211,212.1,221,222.2},{311,312,321,322},
  {1111,1112,1211,1212},{2111,2112,2211,2212},{3111,3112,3211,3212}
  };
#endif
 
