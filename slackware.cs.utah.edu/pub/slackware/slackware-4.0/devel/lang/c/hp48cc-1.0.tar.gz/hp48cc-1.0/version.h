#define HP48CC_VERSION "hp48cc 1.0"
