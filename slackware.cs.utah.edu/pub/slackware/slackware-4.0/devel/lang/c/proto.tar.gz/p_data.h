/********************************************************
 * p_data						*
 *    Prototype file data class				*
 * 							*
 *    This class is used to store a list of structures 	*
 *     containing:					*
 * 	<flags>						*
 * 	Full file name where the prototype is used	*
 * 	Relitive file name where the prototype is used	*
 * 							*
 *    These structures can be accessed through the 	*
 *    member functions or as a "datum" suitable for 	*
 *    storing in a database				*
 * 							*
 * The actual layout of the structure in memory is:	*
 * 							*
 * 	<int number of entries>				*
 * 	   <char>		-- Flags		*
 * 	   <char string>	-- Full file name	*
 * 	   <char string>	-- Relative file name	*
 * 	   ... Repeat last 3 as needed			*
 ********************************************************/

#define DATA_MAX (40 * 1024)	/* Biggest datum we can use */
#define ENTRY_MAX 1000		/* Max number of entries to use */

/* Pointers to the internal strings in a data item */
struct p_struct {
    char *flag_ptr;	/* Pointer to the flag */
    char *full_name_ptr;/* Pointer to the full name */
    char *rel_name_ptr;	/* Pointer to relative name */
};

struct p_data {
      int *n_data_ptr;			/* Number of data entries */
      struct p_struct data_ptrs[ENTRY_MAX];/* Pointers to the data */

      char raw_data[DATA_MAX];	/* Raw version of the data */
      int raw_data_size;	/* Size of the raw data */
};

extern
void append(struct p_data *data,
	    const char flags, 
	    const char func_name[],
	    const char full_name[],
	    const char rel_name[]);

extern
datum get_datum(struct p_data *data);

extern
void copy_p_data(struct p_data *new_entry, datum old_datum);

extern
char get_flags(struct p_data *new_entry, int i);

extern
const char *const get_full_name(struct p_data *the_data, const int index);

extern
const char *const get_rel_name(struct p_data *the_data, const int index);

extern
void init(struct p_data *the_data);
