const int F_QUOTE = (1 << 0);	/* Flag indicating to use "xxxx.h" */
				/* instead of <xxxx.h> */
