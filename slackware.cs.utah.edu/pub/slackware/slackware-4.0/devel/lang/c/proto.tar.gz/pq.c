/********************************************************
 * pq 							*
 *     Prototype database query				*
 * 							*
 * Usage:						*
 * 	pq [-db <database>] [-A] [-a] <symbol>		*
 *		Dump #include for  a single symbol	*
 *		-db | --database			*
 *			specify a database list to use	*
 *		-a | --all				*
 *			print all symbols in the 	*
 *			first db that contains an entry.*
 *		-A | --everyone 			*
 *			print all entries in all 	*
 *			databases			*
 * 							*
 * 	pq [-db <database>] -d|--dump			*
 *		Dumps all symbols			*
 *							*
 * 	pq [-db <database>] -m|--multiple		*
 *		Print all symbols with more than one	*
 *		prototype in a single database		*
 *							*
 * The database list defaults to:			*
 *	1) The database list from the command line	*
 *	2) Path from the PROTO_DB environment variable	*
 *	3) The database "proto_db"			*
 *							*
 * Author: Steve Oualline   9/21/96			*
 ********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/fcntl.h>
#include <string.h>
#include <gdbm.h>

#include "config.h"
#include "defs.h"
#include "p_data.h"
#include "option.h"

static GDBM_FILE proto_db;	/* Prototype database */
static char *proto_db_name;	/* Name of the database */
static char db_path[5000] = ""; /* Database path */
static int all = 0;		/* True if we report all entries */
static int all_db = 0;		/* Report all entries in all databases */

/********************************************************
 * open_db						*
 *    Assure that the database is open			*
 ********************************************************/
static
void
open_db(void)
{
    if (proto_db == NULL) {
	proto_db = gdbm_open(proto_db_name, 512, GDBM_READER, 
				0666, NULL);
	if (proto_db == NULL) {
	    fprintf(stderr, "Error: Could not open database %s\n",
	    		 proto_db_name);
	    exit (8);
	}
    }
}

/********************************************************
 * path_list						*
 *     Class to handle a path list			*
 * 							*
 *     Member functions:				*
 * 							*
 * 	next -- updates the global variable 		*
 *	      proto_db_name to				*
 * 	      point to the next database and opens the 	*
 * 	      database itself.				*
 ********************************************************/
struct path_list {
    char *cur_char;		/* Current character in the list */
};
/********************************************************
 * init_path_list -- Initialize a path list		*
 ********************************************************/
static void init_path_list(
    struct path_list *the_list	/* Path list to initialize */
)
{
    the_list->cur_char = db_path;
    if (db_path[0] == '\0') {
	if (getenv("PROTO_DB") != NULL)
	    strcpy(db_path, getenv("PROTO_DB"));
	else
	    strcpy(db_path, PROTO_DB);
    }
}
/********************************************************
 * list_next - get the next path in a list		*
 *							*
 * Returns:						*
 *	0 -- no more paths				*
 *	NZ -- more paths 				*
 ********************************************************/
int list_next(
    struct path_list *the_list	/* Path list to initialize */
) {
    char *next_db;		/* Pointer to the next database */

    if (the_list->cur_char == NULL)
	return (0);

    if (proto_db != NULL) {
	gdbm_close(proto_db);
	proto_db = NULL;
    }

    proto_db_name = the_list->cur_char;
    next_db = strchr(the_list->cur_char, ':');
    if (next_db != NULL) {
	*next_db = '\0';
	next_db++;
    }
    the_list->cur_char = next_db;
    open_db();
    return (1);
}

/********************************************************
 * dump_single						*
 *    Dump all entries in a database			*
 ********************************************************/
static
void
dump_single(
    int mul_def	/* If true dump multiple definitions only */
)
{
    datum key;	/* Current entry in the database */

    for (key = gdbm_firstkey(proto_db);
	 key.dptr != NULL; 
         key = gdbm_nextkey(proto_db, key)) {

	/* Get the value of the key */
	datum cur_value = gdbm_fetch(proto_db, key);

	struct p_data cur_entry;	/* Current entry */
	int i;				/* General purpose index */

	copy_p_data(&cur_entry, cur_value);

	if (mul_def && (*cur_entry.n_data_ptr <= 1)) 
	    continue;

	printf("Function %s Entries %d\n", key.dptr, *cur_entry.n_data_ptr);

	for (i = 0; i < *cur_entry.n_data_ptr; i++) {
	    printf("\t%d %s (%s)\n",
		(int)get_flags(&cur_entry, i),
		get_rel_name(&cur_entry, i),
		get_full_name(&cur_entry, i));
	}

	if (gdbm_errno != 0) {
	    fprintf(stderr, "Database error: %d\n", gdbm_errno);
	    fprintf(stderr, "Abort\n");
	    exit (8);
	}
    }
}
/********************************************************
 * dump_all						*
 *    Dump all entries in a database			*
 ********************************************************/
static
void
dump_all(
   int mul_def		/* If true dump multiple definitions */
)
{
    struct path_list db_list;	/* list of databases */
    init_path_list(&db_list);

    while (1) {
	if (list_next(&db_list) == 0)	/* Goto the next database */
	    break;

	printf("-------------------- %s\n", proto_db_name);

	dump_single(mul_def);
    }
}

/********************************************************
 * dump_one						*
 *    Write out the entry for a single name 		*
 *	(suitable for #include)				*
 * 							*
 * Returns 						*
 *    True -- something dumped				*
 *    False -- nothing found				*
 ********************************************************/
static
int
dump_one(
    const char name[]
)
{
    int did_name = 0;	/* True if we output the database name */
    datum func_data;	/* Function data */

    /* Data pointing to the file information */
    datum file_datum;

    open_db();

    func_data.dptr = (char *)name;
    func_data.dsize = strlen(name) + 1;

    /* Data pointing to the file information */
    file_datum = gdbm_fetch(proto_db, func_data);

    if (file_datum.dptr == NULL) {
	return (0);
    } else {
	/* current data in p_data format */
	struct p_data cur_entry;
	char quote1, quote2;	/* Quote characters at begin,end of name */

	copy_p_data(&cur_entry, file_datum);

	if ((get_flags(&cur_entry, 0) & F_QUOTE) != 0) {
	    quote1 = '"';
	    quote2 = '"';
	} else {
	    quote1 = '<';
	    quote2 = '>';
	}

	if (all_db && (did_name == 0)) {
	    printf("/*--- Database: %s -----*/\n", proto_db_name);
	    did_name = 1;
	}
	if (all) {
	    int i;	/* Index into entry list */

	    for (i = 0; i < *cur_entry.n_data_ptr; i++) {
		printf("\t#include %c%s%c\t/* (%s) */\n",
			quote1, get_rel_name(&cur_entry, i), quote2,
			get_full_name(&cur_entry, i));
	    }
	} else {
	    printf("#include %c%s%c\t/* (%s) */\n",
		    quote1, get_rel_name(&cur_entry, 0), quote2,
		    get_full_name(&cur_entry, 0));
	}
	return (1);
    }
}

/********************************************************
 * dump_include						*
 *    Dump the #include entries in a database		*
 ********************************************************/
static 
void
dump_include(
    const char name[]	/* Name of the function to print */
)
{
    struct path_list db_list;	/* list of databases */
    int seen_any = 0;		/* Seen any symbols? */

    init_path_list(&db_list);

    while (1) {
	int status;	/* Status of last symbol dump */

	if (list_next(&db_list) == 0)	/* Goto the next database */
	    break;

	status = dump_one(name);	/* Dump a symbol */

	if (status != 0)
	    seen_any = 1;
	if ((status != 0) && (all_db == 0))
	    break;
    }
    if (! seen_any) 
	printf("Error: Could not find %s\n", name);
}
       
int main(int argc, char *argv[])
{
    if (argc < 2) {
	fprintf(stderr, "Usage is:\n");
	fprintf(stderr, "	pq [options] function\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "Options\n");
	fprintf(stderr, "  -db        <db_list>\n");
	fprintf(stderr, "  --database <db_list>\n");
	fprintf(stderr, "	-- Specify list of databases to use\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "   -d\n");
	fprintf(stderr, "   --dump\n");
	fprintf(stderr, "	-- Dump all symbols (no function needed)\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "  -a\n");
	fprintf(stderr, "  -all\n");
	fprintf(stderr, "	-- Print all matches in the first database \n");
	fprintf(stderr, "	   containing a match\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "  -A\n");
	fprintf(stderr, "  --everyone\n");
	fprintf(stderr, "	-- Print all matches in all databases \n");
	fprintf(stderr, "	   containing a match\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "   -m\n");
	fprintf(stderr, "   --multiple\n");
	fprintf(stderr, "	-- Dump all prototypes with multiple entries\n");
	fprintf(stderr, "	   in a single database\n");
	exit (8);
    }

    while (argc > 1) {
	if (check_option(argv[1], "-db", "--database")) {
	    if (proto_db != NULL) {
		gdbm_close(proto_db);
		proto_db = NULL;
	    }
	    strcpy(db_path, argv[2]);
	    argv++;
	    argc--;
	} else if (check_option(argv[1], "-d", "--dump")) {
	    dump_all(0);
	} else if (check_option(argv[1], "-a", "--all")) {
	    all = 1;
	} else if (check_option(argv[1], "-A", "--everyone")) {
	    all = 1;
	    all_db = 1;
	} else if (check_option(argv[1], "-m", "--multiple")) {
	    dump_all(1);
	} else {
	    dump_include(argv[1]);
	}
	argv++;
	argc--;
    }
    if (proto_db != NULL) {
	gdbm_close(proto_db);
    }
    return (0);
}
