#!/bin/csh
set flags=
set g_cmd="g++ -x c++ -E -D__STDC__ -D__USE_FIXED_PROTOTYPES__"
set X=/usr/local/X11R6/include
set echo
#rm gnu_db
#proto -db gnu_db -a $flags\
#    -I /usr/local/lib/gcc-lib/m68k-sun-sunos4.1.1/2.6.3/include \
#    -I /usr/local/lib/g++-include
#rm x_db
#proto -db x_db $flags -a \
#    -x x_exclude	\
#    -c "$g_cmd -I$X/X11/extensions -I$X/X11/Fresco/Ox -I- -I$X -I$X/X11/fonts " \
#    -I /usr/local/X11R6/include
rm gnu_db
proto -db gnu_db $flags -a -I /usr/include
#echo run -db gnu_db $flags -a -I /usr/include >run.gdb
#xxgdb -display sabina:0.0 proto 

