/********************************************************
 * option -- return if a string is one of two options	*
 *							*
 * Parameters						*
 *	arg -- argement to test				*
 *	option1 -- Option to test against		*
 *	option2 -- Option to test against		*
 *							*
 * Returns						*
 *	1 -- Option matches				*
 *	0 -- Option does not match			*
 ********************************************************/
extern int check_option(const char arg[], const char option1[], const char option2[]);
