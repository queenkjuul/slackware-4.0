/********************************************************
 * gdbm_class -- class wrapper for the gnu database	*
 *							*
 * Member functions:					*
 *	gdbm_class(name, block_size = 512, 		*
 *		read_write = GDBM_READER,		*
 *		mode = 0666,				*
 *		fatal_func = NULL)			*
 *	-- initialize the class				*
 *	   and open the database			*
 *							*
 *	gdbm_class -- initialize the class		*
 *		and do not open the database		*
 *							*
 *	int open(name, block_size = 512, 		*
 *		read_write = GDBM_READER,		*
 *		mode = 0666,				*
 *		fatal_func = NULL)			*
 *	--  open the database				*
 *							*
 *	int bad() -- Returns status of last open	*
 *							*
 *	void close()	-- Close the database		*
 *							*
 *	int store(key, content, flag=GDBM_INSERT)	*
 *	-- Store an item in the database		*
 *							*
 *	datum fetch(key) -- Get data			*
 *							*
 *	int delete_entry(key) -- delete an entry	*
 *							*
 *	datum firstkey(void) -- Get the first key	*
 *							*
 *	datum nextkey(key) -- Get the next key		*
 *							*
 *	void reorganize() -- Reorganize the database	*
 *							*
 *	void sync() -- make sure database is on disk	*
 *							*
 *	int exist(key) -- does key exist?		*
 *							*
 *	char *strerror(errno) -- Turn error into string	*
 *							*
 *	int setop(option, value, size)			*
 *		-- Set database options			*
 ********************************************************/
#include <gdbm.h>	// Get the C version of the functions

#ifndef NULL
#define NULL 0
#endif /* NULL */

class gdbm_class {
    private:
	GDBM_FILE db_file;		// File for the database
	int error_code;			// Error code from last open
    public:
	int open(
	    const char name[],		// File name
	    int block_size = 512,	// I/O block size
	    int read_write = GDBM_READER,// How to access the file
	    int mode = 0666,		// Creation mode
	    void (*fatal_func)(...) = NULL	// Called with a fatal error
	) {
	    db_file = gdbm_open((char *)name, block_size, read_write, 
				   mode, fatal_func);
	    if (db_file != NULL) 
		error_code = 0;
	    else
		error_code = gdbm_errno;
	    return (error_code);	
	}
	gdbm_class(
	    const char name[],		// File name
	    int block_size = 512,	// I/O block size
	    int read_write = GDBM_READER,// How to access the file
	    int mode = 0666,		// Creation mode
	    void (*fatal_func)(...) = NULL	// Called with a fatal error
	) {
	    open(name, block_size, read_write, mode, fatal_func);
	}

	gdbm_class(void) {
	    error_code = -1;
	    db_file = NULL;
	}
    private:
	// No copy constructor
	gdbm_class(const gdbm_class &old);

	// No assignment operator
	gdbm_class operator = (const gdbm_class &old);
    
    public:
	void close(void) {
	    gdbm_close(db_file);
	    error_code = gdbm_errno;
	    db_file = NULL;
	}

	~gdbm_class(void) {
	    if (db_file != NULL) 
		close();
	}

	int bad(void) {
	    return (error_code);
	}

	int store(
	    const datum &key, 		// Key of the entry
	    const datum &content,	// Data for the entry
	    const int flag = GDBM_INSERT// How to put the data in
	) {
	    error_code = gdbm_store(db_file, key, content, flag);
	    return (error_code);
	}

	datum fetch(
	    const datum &key		// Key of the record to fetch
	) {
	    // Result of the fetch
	    datum result = gdbm_fetch(db_file, key);
	    error_code = gdbm_errno;
	    return (result);
	}

	int delete_entry(
	    const datum &key		// Entry to delete
	)
	{
	    error_code = gdbm_delete(db_file, key);
	}

	datum firstkey(void)
	{
	    // Result of the fetch
	    datum result = gdbm_firstkey(db_file);
	    error_code = gdbm_errno;
	    return (result);
	}

	datum nextkey(
 	    const datum &key		// Key we just got
        )
	{
	    // Result of the fetch
	    datum result = gdbm_nextkey(db_file, key);
	    error_code = gdbm_errno;
	    return (result);
	}

	int reorganize(void)
	{
	    int error_code = gdbm_reorganize(db_file);
	    return (error_code);
	}

	void sync(void) {
	    gdbm_sync(db_file);
	    error_code = gdbm_errno;
	}

	int exist(
	    const datum key		// Key to check for existance
	) {
	    int result = gdbm_exists(db_file, key);
	    error_code = gdbm_errno;

	    return (result);
	}

	static const char *strerror(
	    enum gdbm_error  errno	// Error to turn into a string
	) {
	    return (gdbm_strerror((enum gdbm_error) errno));
	}

	const char *error_str(void)
	{
	    return (gdbm_strerror((enum gdbm_error) error_code));
	}

	int setopt(
	    const int option,		// What to set
	    int *const value,		// Value of the option
	    const int size		// Number of bytes in options
	) {
	    int result = gdbm_setopt(db_file, option, value, size);
	    error_code = gdbm_errno;
	    return (result);
	}

	int is_open(void) {
	    return (db_file != NULL);
	}
};
