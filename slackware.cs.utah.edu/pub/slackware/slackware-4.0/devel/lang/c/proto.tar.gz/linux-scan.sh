#!/bin/csh
set time
set flags=-v
#set g_cmd="g++ -x c++ -E -D__STDC__ -D__USE_FIXED_PROTOTYPES__"
set g_cmd="g++ -x c++ -E "
set echo

rm proto.db
proto -db proto.db $flags -a \
    -x pc.exclude \
    -c "$g_cmd -I/usr/include -I/usr/include/X11 -I/usr/include/g++" \
    -I /usr/include 
