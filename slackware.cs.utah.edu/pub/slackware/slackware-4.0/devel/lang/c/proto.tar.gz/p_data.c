/********************************************************
 * p_data						*
 *   Routines to handle the prototype data		*
 ********************************************************/
#include <gdbm.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "p_data.h"

/********************************************************
 *build_pointers					*
 *    Build the data_ptrs from the raw data		*
 ********************************************************/
void
build_pointers(
   struct p_data *the_data	/* structure we are building */
)
{
    int i;	/* Index into the data ptrs array */

    /* Pointer to current item in the raw data */
    char *raw_ptr = the_data->raw_data + sizeof(int);

    for (i = 0; i < *the_data->n_data_ptr; i++) {
	the_data->data_ptrs[i].flag_ptr = raw_ptr;
	raw_ptr++;

	the_data->data_ptrs[i].full_name_ptr = raw_ptr;
	raw_ptr += strlen(raw_ptr) + 1;

	the_data->data_ptrs[i].rel_name_ptr = raw_ptr;
	raw_ptr += strlen(raw_ptr) + 1;
    }
}
/********************************************************
 * set_datum 						*
 *     Set the pointers in a p_data entry from a datum	*
 ********************************************************/
void set_datum(
   struct p_data *the_data,	/* Data to set teh dataum for */
   const datum db_data		/* Data to use for the raw data */
)
{
   if (db_data.dsize <= 0)  {
      fprintf(stderr, "Internal error, bad data size\n");
      abort();			/* Illegal data size */
   }
   memcpy(the_data->raw_data, db_data.dptr, db_data.dsize);
   the_data->raw_data_size = db_data.dsize;

   build_pointers(the_data);
}
/********************************************************
 * append						*
 *    Add a new entry onto the end of the raw data	*
 ********************************************************/
void append(
   struct p_data *the_data,	/* Data to use */
   const char flags, 		/* Flags for new item */
   const char func_name[],	/* Name of the function */
   const char full_name[],	/* Full file name for new item */
   const char rel_name[]	/* Relative name for new item */
)
{
    int data_size;		/* Size of the resulting data */
    char *raw_end;		/* Pointer to the end of raw data */

    if ((*the_data->n_data_ptr) >= (ENTRY_MAX-1)) {
	fprintf(stderr, "Too many entries for %s\n", func_name);
	return;
    }

    data_size = 1 +			/* Size of the flags */
		strlen(full_name) + 1 +	/* Name */
		strlen(rel_name)  + 1 +	/* Rel name */
		1;			/* Fudge */
    if ((the_data->raw_data_size + data_size) >= DATA_MAX) {
	fprintf(stderr, "Error: Attempt to put to much data in\n");
	return;
    }
    

    /* Get place to put the data */
    raw_end = &the_data->raw_data[the_data->raw_data_size];

    the_data->data_ptrs[*the_data->n_data_ptr].flag_ptr = raw_end;
    *raw_end = flags;
    raw_end++;

    the_data->data_ptrs[*the_data->n_data_ptr].full_name_ptr = raw_end;
    strcpy(raw_end, full_name);
    raw_end += strlen(full_name) + 1;

    the_data->data_ptrs[*the_data->n_data_ptr].rel_name_ptr = raw_end;
    strcpy(raw_end, rel_name);
    raw_end += strlen(rel_name) + 1;

    ++(*the_data->n_data_ptr);

    the_data->raw_data_size = raw_end - the_data->raw_data;
}
/********************************************************
delete_entry
    Remove an entry from the data
********************************************************/
void 
delete_entry(
   struct p_data *the_data,	/* Data to delete entry from */
   const int index		/* Index into the data */
)
{
    char *raw_end;		/* End of the raw data */
    /* Deleting the last entry? */
    if (index == ((*the_data->n_data_ptr)-1)) {
	--(*the_data->n_data_ptr);

	/* Pointer to the end of the data */
	raw_end = the_data->data_ptrs[(*the_data->n_data_ptr)-1].flag_ptr;
	the_data->raw_data_size = raw_end - the_data->raw_data;
    } else {
	/* Size of the entry we are deleting */
	int entry_size = (the_data->data_ptrs[index+1].flag_ptr - 
			    the_data->data_ptrs[index].flag_ptr);

	/* Size of the data to copy */
	int copy_size = the_data->raw_data_size - entry_size;

	memcpy(the_data->data_ptrs[index].flag_ptr, 
	       the_data->data_ptrs[index+1].flag_ptr,
	       copy_size);

	the_data->raw_data_size = the_data->raw_data_size - entry_size;
	--(*the_data->n_data_ptr);
	build_pointers(the_data);
    }
}

/********************************************************
 * get_datum -- Create a datum from the data		*
 *							*
 * Parameters						*
 *	the_data -- data structure to "cast"		*
 *							*
 * Returns						*
 *	the dataum version of the data			*
 ********************************************************/
datum get_datum(
    struct p_data *the_data
) {
    datum result;	/* Place to put return value */

    result.dptr = the_data->raw_data;
    result.dsize = the_data->raw_data_size;
    return (result);
}

/* Create data from a db data record */
void copy_p_data(
    struct p_data *the_data,
    const datum db_data
) {
    the_data->n_data_ptr = (int *)&the_data->raw_data[0];
    set_datum(the_data, db_data);
}

char get_flags(struct p_data *the_data, const int index) {
    return (*(the_data->data_ptrs[index].flag_ptr));
}

const char *const get_full_name(struct p_data *the_data, const int index) {
    return (the_data->data_ptrs[index].full_name_ptr);
}

const char *const get_rel_name(struct p_data *the_data, const int index) {
    return (the_data->data_ptrs[index].rel_name_ptr);
}

void init(struct p_data *the_data)
{
    the_data->raw_data_size = sizeof(int);
    the_data->n_data_ptr = (int *)&the_data->raw_data[0];
    *the_data->n_data_ptr = 0;
}
