#!/bin/csh
set lib=/usr/local/lib/db
pq -db $lib/proto.db $argv
