#undef USE_CC	/* Use Sun's CC compiler for pre processing */
#undef LOG_FILE /* Log commands */
#define TOKEN_DEBUG
/********************************************************
 * proto						*
 *      Find prototypes in header files.		*
 * 							*
 * Usage:						*
 * 	proto <options>					*
 * 							*
 * Options:						*
 *	-db <database>					*
 *	-database <database>	-- Specify database	*
 *			   (default = proto_db)		*
 *							*
 *	-I <dir>	-- Scan all files in the dir	*
 *							*
 *	-s+						*
 *	--scan-sub	-- Scan subdirectories as well	*
 *							*
 *	-s-						*
 *	--noscan-sub	-- Turn off subdirectory scan	*
 *			   (default=on)			*
 *							*
 *	--quote						*
 *	-q		-- Quote mode.  Store entry	*
 *			   as #include "file.h"		*
 *							*
 *	-a						*
 *	--angle		-- Angle bracket mode		*
 *			   Store entry as:		*
 *			   as #include <file.h>		*
 *							*
 *	-v						*
 *	--verbose	-- Turn on verbose mode		*
 *			   (List directories as they 	*
 *			    are scanned.)		*
 *							*
 *	-v-						*
 *	--noverbose	-- Turn off verbose mode	*
 *			   (default=off)		*
 *							*
 *	-V						*
 *	--very-verbose	-- Turn on very verbose mode	*
 *			   (Prints each entry added and	*
 *			   each header as it is		*
 *			   processed)			*
 *							*
 *	-V-						*
 *	--novery-verbose -- Turn off very verbose mode	*
 *			   (default=off)		*
 *							*
 *	<file>		-- Scan header file for 	*
 *			   prototypes.			*
 *							*
 *	-c "cmd"					*
 *	--cpp "cmd"	-- Command to run CPP		*
 *							*
 *	-x file						*
 *	--exclude file	-- Exclude file			*
 *			   File/dirs in this file are	*
 *			   not processed.		*
 *							*
 *	-bad <file>					*
 *	--bad <file>	-- Write out files that		*
 *			   could not be processed	*
 *			   into the "bad" list		*
 *							*
 * Arguments are processed in order.  Options may	*
 * be turned on and off many times. 			*
 *							*
 * Author: Steve Oualline   9/21/96			*
 ********************************************************/
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/fcntl.h>
#include <sys/param.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

#include <gdbm.h>	

#include "defs.h"
#include "p_data.h"
#include "option.h"
#include "config.h"

const int BLOCK_SIZE = 1024;		/* Block size for disk I/O */

static GDBM_FILE proto_db;		/* Prototype database */
static char *proto_db_name = PROTO_DB;	/* Name of the database */
static int scan_sub = 1;		/* Option to scan sub-dirs */

/* Include style */
enum INC_TYPE {
   I_QUOTE, 				/* #include "xxxx.h" */
   I_ANGLE				/* #include <xxxx.h> */
};

static enum INC_TYPE inc_type = I_QUOTE;	/* Quote type */

static int verbose = 0;			/* Chatter */
static int very_verbose = 0;		/* Chatter a lot */

#define MAX_NAME 100	/* Longest id */

#ifdef USE_CC
static char *cpp_cmd = "CC -E ";
#else /* USE_CC */
static char *cpp_cmd = "g++ -x c++ -E -D__STDC__ -D__USE_FIXED_PROTOTYPES__";
#endif /* USE_CC */

#ifdef LOG_FILE
FILE *log_file = NULL;
#endif /* LOG_FILE */

static FILE *bad_file = NULL;	/* File for bad names */

/*
 * in_file_struct -- structure that holds the data from an input
 * (.c) file.
 */
struct in_file_struct {
    int cur_char;	/* Current character in the input */
    int last_char;	/* Previous character */
    FILE *in_file;	/* File we are reading */
};

/********************************************************
 * open_in_file						*
 *	Open an input file and initialize the structure	*
 ********************************************************/
static void open_in_file(
    struct in_file_struct *the_file,	/* The file to initialize */
    const char in_dir[],		/* The directory containing a the file */
    const char file_name[]		/* The name of the file */
)
{
    char cmd[MAXPATHLEN+100];	/* Command for the cpp cmd. */
    if (in_dir[0] == '\0')
	in_dir = ".";

    the_file->cur_char = '\n';
    sprintf(cmd, "cd %s;%s %s\n", in_dir, cpp_cmd, file_name);
    the_file->in_file = popen(cmd, "r");
#ifdef LOG_FILE
    fprintf(log_file, "%s\n", cmd);
    fflush(log_file);
#endif /* LOG_FILE */
}
/********************************************************
 * close_in_file					*
 *	Close the input file.				*
 ********************************************************/
static int close_in_file(
    struct in_file_struct *the_file	/* The file to initialize */
) {
    if (the_file->in_file != NULL)  {
	int status = pclose(the_file->in_file);
	the_file->in_file = NULL;
	return (status);
    }
    return (0);
}

/********************************************************
 * next_char						*
 * 	Get the next character from the input file	*
 ********************************************************/
void next_char(
    struct in_file_struct *the_file	/* The file to initialize */
) {
    the_file->last_char = the_file->cur_char;
    the_file->cur_char = fgetc(the_file->in_file);
}

enum token_type {
    T_NAME,		/* An id */
    T_L_CURLY,		/* The curly bracket { */
    T_R_CURLY,		/* The curly bracket } */
    T_L_PAREN,		/* Parenthesis ( */
    T_R_PAREN,		/* Parenthesis ) */
    T_STAR,		/* Star "*" */
    T_STRING,		/* String "xxx" */
    T_FILE,		/* # nn "/usr/include/file" directive */
    T_OTHER,		/* Anything else */
    T_EOF		/* End of file */
};

struct token {
    enum token_type kind;	/* What type of token we have */
    char name[MAX_NAME];	/* The name of the token */
			    	/* (If type=name) */
};


struct exclude_struct {
    char *data;	/* Pointer to the raw data */
};

static struct exclude_struct exclude = {NULL};	/* File to exclude */
/********************************************************
 * file_size -- return the size in bytes of a file	*
 ********************************************************/
int file_size(
    const int fd	/* Fd of the file to look at */
)
{
    struct stat buf;	/* Status buffer */

    fstat(fd, &buf);	/* Get status */

    return (buf.st_size);	/* Return size */
}
/********************************************************
 * setup						*
 * 	Open a exclude database and read in the files	*
 *							*
 * Generates an error if it can't read the file		*
 ********************************************************/
void setup(
    struct exclude_struct *exclude,	/* Exclude information */
    const char name[]			/* Name of the file */
)
{
    int fd;	/* Fd of the file to read */
    int size;	/* Size of the file */

    if (exclude->data != NULL) {
	free(exclude->data);		/* Remove old data */
	exclude->data = NULL;
    }

    fd = open(name, O_RDONLY);
    if (fd < 0) {
	fprintf(stderr, "Error: Could not open exclude file %s\n", name);
	return;
    }

    size = file_size(fd);	/* Get the size of the file */
    exclude->data = (char *)malloc(size+1);
    exclude->data[size] = '\0';
    read(fd, exclude->data, size);
    close(fd);
}

/********************************************************
 * is_in -- returns true if the string			*
 *		is in the exclude list			*
 ********************************************************/
int
is_in(
    struct exclude_struct *exclude,	/* Exclude information */
    const char file_name[]		/* Name of the file to look for */
)
{
    char *cur_file;	/* Current character we are looking for the file */
    char *cur_data;	/* Current data character */

    if (exclude->data == NULL)	/* Check for no exclude information */
	return (0);

    cur_data = exclude->data;	/* Start at the beginning */

    cur_file = (char *)file_name;
    while (1) {
	switch (*cur_data) {
	    case '\n':
		if (*cur_file == '\0')
		    return (1);	/* Found it */

		/* Didn't find it, try next variable */
		cur_file = (char *)file_name;
		cur_data++;	/* Skip past the newline */
		break;
	    case '\0':
		return (0);	/* Didn't find it */
	    default:
		if (*cur_data != *cur_file) {
		   /* It's not this file */
		   /* Skip to the end of the line */
		   while ((*cur_data != '\0') &&
			  (*cur_data != '\n'))
		       cur_data++;
		   cur_file = (char *)file_name;
		} else {
		    /* They're equal, continue */
		    cur_data++;
		    cur_file++;
		}
		break;
	}
    }
}


/********************************************************
 * check_db						*
 *    Check to make sure the database is open		*
 ********************************************************/
static 
void 
check_db(void)
{
    if (proto_db == NULL) {
	proto_db = gdbm_open(proto_db_name, BLOCK_SIZE, 
				GDBM_WRCREAT, 0666, NULL);

	if (proto_db == NULL) {
	    fprintf(stderr, "Error: Could not open database %s\n", 
		proto_db_name);
	    exit (8);
	}
    }
}
/********************************************************
 * read_cpp -- Read the pre-processor directives	*
 ********************************************************/
void
read_cpp(
    struct token *token,		/* Token we are getting */
    struct in_file_struct *in_file	/* File to read */
)
{
    if (in_file->last_char == '\n') {
	next_char(in_file);

	/* We have a # directive */
	/* Check for line number (<nn>) */
	while ((in_file->cur_char != EOF) && 
	       (isspace(in_file->cur_char)))
	    next_char(in_file);

	if (isdigit(in_file->cur_char)) {
	    /* Read past the digits of */
	    /*	# 999 "/usr/include/sys/stat.h" */
	    while ((in_file->cur_char != EOF) && 
		   (isdigit(in_file->cur_char)))
		next_char(in_file);

	    /* Read past whitespace after the digits */
	    /*	# 999 "/usr/include/sys/stat.h" */
	    while ((in_file->cur_char != EOF) && 
		   (isspace(in_file->cur_char))) {
		if (in_file->cur_char == '\n') {
		    token->kind = T_OTHER;
		    return;
		}
		next_char(in_file);
	    }

	    if (in_file->cur_char == '"') {
		int name_index = 0;	/* Index into the name */

		next_char(in_file);

		while ((in_file->cur_char != EOF) &&
		       (in_file->cur_char != '"')) {

		    if (name_index < MAX_NAME) {
			token->name[name_index] = in_file->cur_char;
			name_index++;
		    }
		    next_char(in_file);
		}
		next_char(in_file);	/* Get past " */

		token->name[name_index] = '\0';
		token->kind = T_FILE;

		/* ### make_subr ### */
		while (in_file->cur_char != EOF) {
		    if ((in_file->cur_char == '\n') &&
			(in_file->last_char != '\\'))
			break;

		    next_char(in_file);
		}

		return;
	    }
	}
		

	while (in_file->cur_char != EOF) {
	    if ((in_file->cur_char == '\n') &&
		(in_file->last_char != '\\'))
		break;

	    next_char(in_file);
	}
    }
    next_char(in_file);
    token->kind = T_OTHER;
}
/********************************************************
 * get_token_from_input					*
 *	Read the next token from the input file		*
 ********************************************************/
void
get_token_from_input(
    struct token *the_token,		/* Token we are getting */
    struct in_file_struct *in_file	/* The file to read */
)
{
    while ((in_file->cur_char != EOF) && (isspace(in_file->cur_char)))
	next_char(in_file);

    if (isalpha(in_file->cur_char) || in_file->cur_char == '_') {
	int name_index = 0;	/* Index into the name */

	while (isalnum(in_file->cur_char) || in_file->cur_char == '_') {
	    if (name_index < MAX_NAME) {
		the_token->name[name_index] = in_file->cur_char;
		++name_index;
	    }
	    next_char(in_file);
	}
	the_token->name[name_index] = '\0';
	the_token->kind = T_NAME;
	return;
    }

    switch (in_file->cur_char) {
	case '{':
	    the_token->kind = T_L_CURLY;
	    next_char(in_file);
	    return;
	case '}':
	    the_token->kind = T_R_CURLY;
	    next_char(in_file);
	    return;
	case '(':
	    the_token->kind = T_L_PAREN;
	    next_char(in_file);
	    return;
	case ')':
	    the_token->kind = T_R_PAREN;
	    next_char(in_file);
	    return;
	case '*':
	    the_token->kind = T_STAR;
	    next_char(in_file);
	    return;
	case '/':
	    next_char(in_file);
	    switch (in_file->cur_char) {
		case '*':
		    next_char(in_file);
		    while (1) {
			while ((in_file->cur_char != EOF) && 
			       (in_file->cur_char != '*')) {
			    next_char(in_file);
			}

			if (in_file->cur_char == EOF)
			    break;
			next_char(in_file);
			if ((in_file->cur_char == EOF) || 
			    (in_file->cur_char == '/'))
			    break;
		    }
		    next_char(in_file);
		    the_token->kind = T_OTHER;
		    return;
		case '/':
		    while ((in_file->cur_char != '\n') && 
		           (in_file->cur_char != EOF))
			next_char(in_file);
		    next_char(in_file);
		    the_token->kind = T_OTHER;
		    return;
		default:
		    the_token->kind = T_OTHER;
		    return;
	    }
	    break;
	case '"':
	    next_char(in_file);
	    {
		int name_index = 0;	/* Index into the name */

		while ((in_file->cur_char != '"') && 
		       (in_file->cur_char != EOF)) {
		    if (name_index < MAX_NAME) {
			the_token->name[name_index] = in_file->cur_char;
			++name_index;
		    }
		    next_char(in_file);
		    if (in_file->cur_char == '\\')
			next_char(in_file);
		}
		the_token->name[name_index] = '\0';
	    }

	    next_char(in_file);
	    the_token->kind = T_STRING;
	    return;
	case '\'':
	    /* Handle character */
	    next_char(in_file);
	    while ((in_file->cur_char != '\'') && 
		   (in_file->cur_char != EOF)) {
		next_char(in_file);
		if (in_file->cur_char == '\\')
		    next_char(in_file);
	    }

	    next_char(in_file);
	    the_token->kind = T_OTHER;
	    return;
	case '#':
	    read_cpp(the_token, in_file);
	    return;
	case EOF:
	    next_char(in_file);
	    the_token->kind = T_EOF;
	    return;
	default:
	    next_char(in_file);
	    the_token->kind = T_OTHER;
	    return;
    }
    /* NOT REACHED */
}

/* 
 * A token stack for lookahead
 */

/* Largest number of tokens to skip */
#define MAX_STACK 10		

static struct token token_cache[MAX_STACK];	/* Tokens we are looking at */
static int cache_count = 0;		/* Number of tokens on stack */
/********************************************************
 * get_token -- get next token from the input		*
 ********************************************************/
static struct token *
get_token(
    struct in_file_struct *in_file,	/* The file to read */
    int peek				/* Number of tokens to peek ahead */
)
{
    if (peek) {
        while (peek > cache_count) {
	    ++cache_count;
	    get_token_from_input(&token_cache[cache_count], in_file);
   	}
	return (&token_cache[peek]);
    }
    if (cache_count > 0) {
	int i;		/* General purpose index */

	for (i = 0; i < cache_count; ++i) {
	    token_cache[i] = token_cache[i+1];
	}
	--cache_count;
    } else
       	get_token_from_input(&token_cache[0], in_file);
    
    return (&token_cache[0]);
}

/********************************************************
 * get_local_name					*
 *	Returns the "local" version of a file name	*
 *	given the rest.					*
 ********************************************************/
const char *
const get_local_name(
    const char local_path[],	/* Prefix to use for the file */
    const char file_name[]	/* Name of the file */
)
{
    static char local_name[MAXPATHLEN];	/* Local version of the file */

    if (strncmp(local_path, file_name, strlen(local_path)) == 0) 
	strcpy(local_name, &file_name[strlen(local_path)+1]);
    else
	strcpy(local_name, file_name);
    return (local_name);
}
/********************************************************
 * add_entry						*
 *   Add/update an entry in the database		*
 ********************************************************/
static
void 
add_entry(
    const char func_name[],	/* Name of the function to add */
    const char local_path[],	/* Prefix to use for the file */
    const char file_name[]	/* Name of the file */
)
{
    datum func_datum;		/* Function name in datum format */
    const char *local_name;	/* name for the database */
    char flags = 0;		/* Flags we are storing */
    datum old_datum; 		/* Datum of existing entry */

    if (very_verbose) {
	printf("add_entry(%s, %s, %s)\n",
		func_name, local_path, file_name);
	fflush(stdout);
    }

    local_name = get_local_name(local_path, file_name);

    func_datum.dptr = (char *)func_name;
    func_datum.dsize = strlen(func_name) + 1;

    if (inc_type == I_QUOTE) 
	flags |= F_QUOTE;	/* Set the quote flag */

    /* Datum of existing entry */
    old_datum = gdbm_fetch(proto_db, func_datum);

    if (old_datum.dptr == NULL) {
	/* Adding new entry to the database */
	struct p_data new_entry;	/* Entry we are adding */

	init(&new_entry);
	append(&new_entry, flags, func_name, file_name, local_name);
	if (gdbm_store(proto_db, func_datum, 
	                   get_datum(&new_entry), GDBM_INSERT) != 0) {
	    fprintf(stderr, "Error: Could not insert information for %s\n",
		    func_name);
	    fprintf(stderr, "Error number %d\n", gdbm_errno);
	    fprintf(stderr, "Error: %s\n", gdbm_strerror(gdbm_errno));
	}
    } else {
	/* Replace existing item */
	struct p_data new_entry;
	int i;	/* Index into the data array */

	copy_p_data(&new_entry, old_datum);

	for (i = 0; i < *new_entry.n_data_ptr; i++) {
	    if (strcmp(new_entry.data_ptrs[i].full_name_ptr, file_name) == 0) 
	    return;
	}
	append(&new_entry, flags, func_name, file_name, local_name);
	if (gdbm_store(proto_db, func_datum, 
		           get_datum(&new_entry), GDBM_REPLACE) != 0) {
	    fprintf(stderr, "Error: Could not replace information for %s\n",
		    func_name);
	}
    }
}

/********************************************************
 * log_bad -- log an entry to the "bad" file		*
 ********************************************************/
void 
log_bad(
    const char file_name[]	/* Name of the file to read */
) 
{
   if (bad_file == NULL)
       return;

   fputs(file_name,  bad_file);
   fflush(bad_file);
}
   
/********************************************************
 * do_file						*
 *     Process a single file through the prototyper	*
 ********************************************************/
void 
do_file(
    const char file_name[],	/* Name of the file to read */
    const char path[]		/* Path that begins the file */
)
{
    char cur_file_name[MAXPATHLEN];	/* Current file name */
    struct in_file_struct in_file;	/* File to read */
    int paren_count = 0;		/* Nesting level of () */
    int brace_count = 0;		/* Nesting level of {} */
    int skip_count = 0;			/* Should we skip a get token? */
    int brace_max = 0;			/* Max nesting of braces we allow */
					/* for a function */

    strcpy(cur_file_name, file_name);
					/* to use for storage */
    if (verbose) {
	printf("do_file(%s, %s)\n", file_name, path);
	fflush(stdout);
    }

    if (is_in(&exclude, file_name))
	return;

    check_db();			/* Make sure DB is open */

    open_in_file(&in_file, path, file_name);
    if (in_file.in_file == NULL) {
	fprintf(stderr, "Error: Unable to open %s\n", file_name);
	log_bad(file_name);
	return;
    }

    paren_count = 0;		/* Nesting level of () */
    brace_count = 0;		/* Nesting level of {} */
    skip_count = 0;		/* Should we skip a get token? */
    brace_max = 0;		/* Max nesting of braces we allow */
				/* for a function */
    next_char(&in_file);	/* Prime the token getter */

    while (1) {
	struct token *cur_token;	/* Pointer to our current token */
	struct token *next_token;	/* Pointer to a future token */

        cur_token= get_token(&in_file, 0);

	switch (cur_token->kind) {
	    case T_L_PAREN:
		paren_count++;
		break;
	    case T_R_PAREN:
		paren_count--;
		break;
	    case T_L_CURLY:
		brace_count++;
		break;
	    case T_R_CURLY:
		brace_count--;
		if (brace_count < brace_max)
		    brace_max = brace_count;
		break;
	    case T_NAME:
		/* Check for    extern "C" */
		if (strcmp(cur_token->name, "extern") == 0) {
		    cur_token = get_token(&in_file, 1);

		    if (cur_token->kind == T_STRING) {
			if (strcmp(cur_token->name, "C") == 0) {
			    cur_token = get_token(&in_file, 2);
			    if (cur_token->kind == T_L_CURLY)
				brace_max = 1;
			}
		    } 
		    /* Always ignore extern clause if not extern "C" */
		    break;
		}

		/* Check for    xxxx(.......) */
		if ((paren_count != 0) || (brace_count > brace_max))
		    break;

		next_token = get_token(&in_file, 1);

		if (next_token->kind == T_L_PAREN) {
		    next_token = get_token(&in_file, 2);
		    if (next_token->kind != T_STAR) 
			add_entry(cur_token->name, path, cur_file_name);
		}
		break;
	    case T_FILE:
		strcpy(cur_file_name, cur_token->name);
		break;
	    case T_EOF:
		if (close_in_file(&in_file) != 0) {
		    fprintf(stderr, "Warning: Errors detected for file %s\n",
			    file_name);
		    log_bad(file_name);
		}
		return;
	    default:
		/* Do nothing */
		break;
	}
    }
    /* NOT REACHED */
}

/********************************************************
 * good_file						*
 *    Returns true if this is a header file.		*
 * 							*
 *    TODO:  Make this take a list of suffixes		*
 ********************************************************/
static
int
good_file(
    const char file_name[]	/* Name of the file to check */
)
{
    /* Pointer to the dot in the file name */
    char *dot_ptr = strrchr(file_name, '.');

    if (dot_ptr == NULL)
	return (0);

    if (strcmp(dot_ptr, ".h") == 0)
	return (1);
    return (0);
}

/********************************************************
 * scan_dir						*
 *    Scan a directory looking for header files		*
 ********************************************************/
static
void 
scan_dir(
    const char dir_name[],	/* Name of the directory to use */
    const char local_path[]	/* Local path (dir) for the file */
)
{
    DIR *cur_dir; /* Name of the directory we are reading */

    if (verbose) {
	printf("scan_dir(%s, %s)\n", dir_name, local_path);
	fflush(stdout);
    }

    if (is_in(&exclude, dir_name))
	return;

    cur_dir = opendir(dir_name);	

    if (cur_dir == NULL) {
	fprintf(stderr, "Error: Could not open dir %s\n", dir_name);
	return;
    }
    while (1) {
	char full_name[MAXPATHLEN];	/* Complete name of our file */

	/* Current directory entry */
	struct dirent *cur_ent = readdir(cur_dir);

	/* Status of the file, used to tell is this a dir */
	struct stat stat_info;

	if (cur_ent == NULL) 
	    break;

	if (strcmp(cur_ent->d_name, ".") == 0) 
	    continue;

	if (strcmp(cur_ent->d_name, "..") == 0) 
	    continue;

	if (strcmp(cur_ent->d_name, "SCCS") == 0) 
	    continue;

	if (strcmp(cur_ent->d_name, "RCS") == 0) 
	    continue;

	strcpy(full_name, dir_name);
	strcat(full_name, "/");
	strcat(full_name, cur_ent->d_name);

	if (stat(full_name, &stat_info) != 0) {
	    fprintf(stderr, "Error: Could not stat %s\n", full_name);
	    log_bad(full_name);
	} else {
	    if (S_ISDIR(stat_info.st_mode)) {
		if (scan_sub) {
		    scan_dir(full_name, local_path);
		}
	    } else {
		if (good_file(full_name))
		    do_file(full_name, local_path);
	    }
	}
    }
    closedir(cur_dir);
}
/********************************************************
 * init_bad -- initialize the "bad" file		*
 ********************************************************/
static
void
init_bad(
   const char name[]	/* File name */
)
{
   if (bad_file != NULL) {
      fclose(bad_file);
      bad_file = NULL;
   }

   bad_file = fopen(name, "r");
   if (bad_file == NULL) {
       fprintf(stderr, "Error: Could not open %s for output\n", name);
       return;
   }
}


/********************************************************
 * main							*
 ********************************************************/
int main(int argc, char *argv[])
{
    if (argc < 2) {
	fprintf(stderr, " Usage:\n");
	fprintf(stderr, " 	proto <options>\n");
	fprintf(stderr, " \n");
	fprintf(stderr, " Options:\n");
	fprintf(stderr, "	-db <database>\n");
	fprintf(stderr, "	-db <database>	-- Specify database\n");
	fprintf(stderr, "			   (default = proto_db)\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-I <dir>	-- Scan all files in the dir\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-s+\n");
	fprintf(stderr, "	--scan-sub	-- Scan subdirectories as well\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-s-\n");
	fprintf(stderr, "	--noscan-sub	-- Turn off subdirectory scan\n");
	fprintf(stderr, "			   (default=on)\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-q\n");
	fprintf(stderr, "	--quote		-- Quote mode.  Store entry\n");
	fprintf(stderr, "			   as #include \"file.h\"\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-a\n");
	fprintf(stderr, "	--angle		-- Angle bracket mode\n");
	fprintf(stderr, "			   Store entry as:\n");
	fprintf(stderr, "			   as #include <file.h>\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-v\n");
	fprintf(stderr, "	--verbose	-- Turn on verbose mode\n");
	fprintf(stderr, "			   (List directories as they \n");
	fprintf(stderr, "			    are scanned.)\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-v-\n");
	fprintf(stderr, "	-noverbose	-- Turn off verbose mode\n");
	fprintf(stderr, "			   (default=off)\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-V\n");
	fprintf(stderr, "	--very-verbose	-- Turn on very verbose mode\n");
	fprintf(stderr, "			   (Prints each entry added and\n");
	fprintf(stderr, "			   each header as it is\n");
	fprintf(stderr, "			   processed)\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-V-\n");
	fprintf(stderr, "	--novery-verbose -- Turn off very verbose mode\n");
	fprintf(stderr, "			   (default=off)\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	<file>		-- Scan header file for \n");
	fprintf(stderr, "			   prototypes.\n");
	fprintf(stderr, "\n");
        fprintf(stderr, "	-c \"cmd\"\n");
        fprintf(stderr, "	--cpp \"cmd\"	-- Command to run CPP\n");
	fprintf(stderr, "\n");
 	fprintf(stderr, "	-bad <file>\n");
 	fprintf(stderr, "	--bad <file>	-- Write out files that	\n");
 	fprintf(stderr, "			   into the \"bad\" list\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "	-x <file>\n");
	fprintf(stderr, "	--exclude <file> -- Specify exclude file\n");
 	fprintf(stderr, "			   could not be processed\n");
	fprintf(stderr, "\n");
	fprintf(stderr, " Arguments are processed in order.  Options may\n");
	fprintf(stderr, " be turned on and off many times. \n");
	exit (8);
    }

#ifdef LOG_FILE
    log_file = fopen("proto.log", "w");
#endif /* LOG_FILE */

    while (argc > 1) {
	if (check_option(argv[1], "-db", "--database")) {
	    if (proto_db != NULL) {
		gdbm_close(proto_db);
		proto_db = NULL;
	    }
	    proto_db_name = argv[2];
	    proto_db = gdbm_open(proto_db_name, BLOCK_SIZE, GDBM_WRCREAT,
	    			0666, NULL);
	    if (proto_db == NULL) {
		fprintf(stderr, "Error: Could not open database %s\n",
			proto_db_name);
		exit (8);
	    }
	    argv++;
	    argc--;
	} else if (strcmp(argv[1], "-I") == 0) {
	    scan_dir(argv[2], argv[2]);
	    argc--;
	    argv++;
	} else if (check_option(argv[1], "-q", "--quote")) {
	    inc_type = I_QUOTE;
	} else if (check_option(argv[1], "-a", "--angle")) {
	    inc_type = I_ANGLE;
	} else if (check_option(argv[1], "-v", "--verbose")) {
	    verbose = 1;
	} else if (check_option(argv[1], "-v-", "--noverbose")) {
	    verbose = 0;
	} else if (check_option(argv[1], "-V", "--very-verbose")) {
	    very_verbose = 1;
	} else if (check_option(argv[1], "-V-", "--novery-verbose")) {
	    very_verbose = 0;
	} else if (check_option(argv[1], "-c", "--cpp")) {
	    cpp_cmd = argv[2];
	    argc--;
	    argv++;
	} else if (check_option(argv[1], "-x", "--exclude")) {
	    setup(&exclude, argv[2]);
	    argc--;
	    argv++;
	} else if (check_option(argv[1], "-bad", "--bad")) {
	    init_bad(argv[2]);
	    argc--;
	    argv++;
	} else if (check_option(argv[1], "-s+", "--scan-sub")) {
	    scan_sub = 1;
	} else if (check_option(argv[1], "-s-", "--noscan-sub")) {
	    scan_sub = 0;
	} else {
	    do_file(argv[1], "");
	}

	argc--;
	argv++;
    }
    return (0);
}

