/********************************************************
 * option -- Option compairsion routine			*
 ********************************************************/
#include <string.h>
#include <stdio.h>
/********************************************************
 * option -- return if a string is one of two options	*
 *							*
 * Parameters						*
 *	arg -- argement to test				*
 *	option1 -- Option to test against		*
 *	option2 -- Option to test against		*
 *							*
 * Returns						*
 *	1 -- Option matches				*
 *	0 -- Option does not match			*
 ********************************************************/
int check_option(const char arg[], const char option1[], const char option2[])
{
    if (strcmp(arg, option1) == 0)
	return (1);
    if (strcmp(arg, option2) == 0)
	return (1);
    return (0);
}
