#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#undef ulong
#define ulong unsigned long

static ulong lowpc, highpc;

/*
 * Number of words between saved pc and saved fp.
 * All stack frames seen by bt() must conform to
 * the same value of SLOP.
 */
#ifndef SLOP
#define SLOP 0
#endif

extern int etext();

#define entrypc(pc)	((pc >= lowpc && pc <= highpc) || pc >= (ulong)&etext)
#define getfp(ap)	(ap-2-SLOP)
#define getpc(fp)	(fp[1+SLOP])

void
mprbt(FILE *filep)
{
	ulong pc, *fp = getfp((ulong *)&filep);

	while (fp && *fp && (pc = getpc(fp)) && !entrypc(pc)) {
		fprintf(filep, "%lu:", pc);
		fp = (ulong *)*fp;
	}
}

int
mprbtinit(void)
{
	char *entry = getenv("MPRPC");

	if (!entry) {
		fprintf(stderr, "mprbtinit: MPRPC unset\n");
		return -2;
	}

	if (!strchr(entry, ':')) {
		fprintf(stderr, "mprbtinit: MPRPC=%s invalid\n", entry);
		return -3;
	}

	lowpc = atoi(entry);
	highpc = atoi(1 + strchr(entry, ':'));

	if (lowpc >= highpc) {
		fprintf(stderr, "mprbtinit: MPRPC=%s invalid\n", entry);
		return -4;
	}

	return 0;
}
