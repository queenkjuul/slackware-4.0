#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#undef malloc
#undef free
#undef calloc
#undef realloc
#include <malloc.h>

#undef ulong
#define ulong unsigned long

extern void	mprbt(FILE *);
extern int	mprbtinit(void);

static void	*(*old_malloc_hook)(size_t);
static void	(*old_free_hook)(void *);
static void	*(*old_realloc_hook)(void *, size_t);
static void	hook(void), unhook(void);

static FILE	*mprfi;		/* filter */
static char	mprbuf[BUFSIZ];	/* its buffer */

static void *
malloc_hook(size_t sz)
{
	void *ptr;

	unhook();
	{
		ptr = malloc(sz);
		fprintf(mprfi, "m:");
		mprbt(mprfi);
		fprintf(mprfi, "%lu:%lu\n", (ulong)sz, (ulong)ptr);
	}
	hook();

	return ptr;
}

static void
free_hook(void *ptr)
{
	unhook();
	{
		fprintf(mprfi, "f:");
		mprbt(mprfi);
		fprintf(mprfi, "%lu\n", (ulong)ptr);
		free(ptr);
	}
	hook();
}

static void *
realloc_hook(void *ptr, size_t sz)
{
	void *ptr2;

	unhook();
	{
		ptr2 = realloc(ptr, sz);
		fprintf(mprfi, "r:");
		mprbt(mprfi);
		fprintf(mprfi, "%lu:%lu:%lu\n", (ulong)sz, (ulong)ptr, (ulong)ptr2);
	}
	hook();

	return ptr2;
}

static void
hook(void)
{
	old_malloc_hook = __dans_malloc_hook;
	old_free_hook = __dans_free_hook;
	old_realloc_hook = __dans_realloc_hook;
	__dans_malloc_hook = malloc_hook;
	__dans_free_hook = free_hook;
	__dans_realloc_hook = realloc_hook;
}

static void
unhook(void)
{
	__dans_malloc_hook = old_malloc_hook;
	__dans_free_hook = old_free_hook;
	__dans_realloc_hook = old_realloc_hook;
}

void
mprsigpipe(int sig)
{
	fprintf(stderr, "mprsigpipe: caught SIGPIPE\n");
	exit(1);
}

int
mpr(void)
{
	static int mprinit=0;
	char *filter;

	if (mprinit)
		return 0;
	else
		mprinit=1;

	filter = getenv("MPRFI");
	if (!filter || !*filter)	/* disabled */
		return 0;

	if (mprbtinit() < 0)
		return -1;

	mprfi = popen(filter, "w");
	if (!mprfi) {
		fprintf(stderr, "mpr: popen() failed\n");
		return -2;
	}
#ifdef MPRSIGPIPE
	signal(SIGPIPE, mprsigpipe);
#endif

	setbuf(mprfi, mprbuf);		/* mprfi must avoid malloc */
	hook();

	return 0;
}
