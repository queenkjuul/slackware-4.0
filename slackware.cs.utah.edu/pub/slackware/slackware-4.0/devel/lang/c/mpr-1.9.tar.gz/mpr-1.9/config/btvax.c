#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <frame.h>

static u_int lowpc, highpc;

#define entrypc(pc)	(pc >= lowpc && pc <= highpc)
#define getpc(fp)	(fp->fr_savpc)

static struct frame *
getfp(void)
{
	asm("movl 12(fp), r0");
}

void
mprbt(FILE *filep)
{
	struct frame *fp = getfp();
	u_int pc = getpc(fp);

	while (!entrypc(pc)) {
		fprintf(filep, "%lu:", pc);
		fp = (struct frame *)fp->fr_savfp;
		pc = getpc(fp);
	}
}

int
mprbtinit(void)
{
	char *entry = getenv("MPRPC");

	if (!entry) {
		fprintf(stderr, "mprbtinit: MPRPC unset\n");
		return -2;
	}

	if (!strchr(entry, ':')) {
		fprintf(stderr, "mprbtinit: MPRPC=%s invalid\n", entry);
		return -3;
	}

	lowpc = atoi(entry);
	highpc = atoi(1 + strchr(entry, ':'));

	if (lowpc >= highpc) {
		fprintf(stderr, "mprbtinit: MPRPC=%s invalid\n", entry);
		return -4;
	}

	return 0;
}
