#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern void bar(), baz();

#define heads() (rand() & 1)

void *
xrealloc(void *ptr, size_t sz)
{
	void *p = realloc(ptr, sz);
	if (!p && sz)
		abort();
	return p;
}

void *
xmalloc(size_t sz)
{
	void *p = malloc(sz);
	if (!p && sz)
		abort();
	return p;
}

static void
foo()
{
	int i;
	char *cp;

	for (i=0; i<200; i++) {
		cp = xmalloc(64);
		if (heads())
			free(cp);
	}
}

int
main()
{
	int i;
	char *cp;

	for (i=0; i<200; i++) {
		cp = xmalloc(16);
		if (heads())
			free(cp);
		else
			if (heads()) {
				cp = xrealloc(cp, 32);
				if (heads())
					free(cp);
			}
	}

	foo();
	bar();
	baz();

	return 0;
}
