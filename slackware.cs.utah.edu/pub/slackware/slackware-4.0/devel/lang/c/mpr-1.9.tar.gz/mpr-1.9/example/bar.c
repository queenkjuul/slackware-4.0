#include <stdlib.h>

extern void *xmalloc(size_t);

#define heads() (rand() & 1)

static void
foo()
{
	int i;
	char *cp;

	for (i=0; i<200; i++) {
		cp = xmalloc(10);
		if (heads())
			free(cp);
	}
	for (i=0; i<200; i++) {
		cp = xmalloc(20);
		if (heads())
			free(cp);
	}
}

void
bar()
{
	foo();
}
