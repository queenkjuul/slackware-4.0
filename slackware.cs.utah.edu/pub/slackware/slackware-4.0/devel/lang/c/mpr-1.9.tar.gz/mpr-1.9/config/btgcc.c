/*
 * This file contains generic C code to print call chains, assuming
 * you have GCC >= 2. It is neither pretty nor (space and time)
 * efficient. On some architectures it could be terribly inefficient,
 * e.g. on a sparc, each expansion of __builtin_return_address()
 * might flush the register windows.
 *
 * It is therefore preferable to have an architecture specific version
 * of mprbt(). For a hint on how to do this, you could examine the
 * assembly source listing produced for function mprbt().
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if __GNUC__ < 2
#error you need gcc >= 2 to use this abomination
#endif

#undef ulong
#define ulong unsigned long

static ulong lowpc, highpc;
extern int etext();

#define entrypc(pc) ((pc >= lowpc && pc <= highpc) || pc >= (ulong)&etext)

#define printpc(n)							\
	if ((pc = (ulong)__builtin_return_address(n)) && !entrypc(pc))	\
		fprintf(fp, "%lu:", pc);				\
	else								\
		return;

void
mprbt(FILE *fp)
{
	ulong pc;

	printpc( 0); printpc( 1); printpc( 2); printpc( 3); printpc( 4);
	printpc( 5); printpc( 6); printpc( 7); printpc( 8); printpc( 9);
	printpc(10); printpc(11); printpc(12); printpc(13); printpc(14);
	printpc(15); printpc(16); printpc(17); printpc(18); printpc(19);
	printpc(20); printpc(21); printpc(22); printpc(23); printpc(24);
	printpc(25); printpc(26); printpc(27); printpc(28); printpc(29);
}

int
mprbtinit(void)
{
	char *entry = getenv("MPRPC");

	if (!entry) {
		fprintf(stderr, "mprbtinit: MPRPC unset\n");
		return -2;
	}

	if (!strchr(entry, ':')) {
		fprintf(stderr, "mprbtinit: MPRPC=%s invalid\n", entry);
		return -3;
	}

	lowpc = atoi(entry);
	highpc = atoi(1 + strchr(entry, ':'));

	if (lowpc >= highpc) {
		fprintf(stderr, "mprbtinit: MPRPC=%s invalid\n", entry);
		return -4;
	}

	return 0;
}
