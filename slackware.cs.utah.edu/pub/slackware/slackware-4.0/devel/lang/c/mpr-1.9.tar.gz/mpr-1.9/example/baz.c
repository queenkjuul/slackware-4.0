#include <stdlib.h>

#define heads() (rand() & 1)

static void *
xmalloc(size_t sz)
{
	void *p = malloc(sz);
	if (!p && sz)
		abort();
	return p;
}

static void
foo()
{
	int i;
	char *cp;

	for (i=0; i<200; i++) {
		cp = xmalloc(256);
		if (heads())
			free(cp);
	}
}

void baz()
{
	foo();
}
