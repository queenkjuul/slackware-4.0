char *s1 = { "hullo" } ;
char *s2 = "hullo";
char *s3 = { 'h', 'u', 'l', 'l', 'o' };
char *s4 = { "hullo", "g'bye" } ;
