typedef int tint;

const tint volatile x;
