char *text (int i);

int main (void)
{
  printf ("%s", text[i]);
}
