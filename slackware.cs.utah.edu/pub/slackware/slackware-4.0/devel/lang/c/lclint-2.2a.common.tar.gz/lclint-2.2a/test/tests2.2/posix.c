/* 
** Should include sys/types is a posix library is not used.
*/

# include <sys/types.h>

dev_t x = 3;
