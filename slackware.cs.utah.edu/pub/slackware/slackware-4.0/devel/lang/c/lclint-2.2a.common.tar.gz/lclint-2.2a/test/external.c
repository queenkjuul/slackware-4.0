int func (int x, int y);
int Func (int x, int y);

int small1 (void);
int small2 (void);

int longfunction1 (void);
int longfunction2 (void);

static /*@unused@*/ int slongfunction1 (void);
static /*@unused@*/ int slongfunction2 (void);
