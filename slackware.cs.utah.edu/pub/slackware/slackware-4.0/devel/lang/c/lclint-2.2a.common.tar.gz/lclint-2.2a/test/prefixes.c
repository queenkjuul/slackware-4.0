typedef int Tin_ty;
typedef int QINT;
typedef int tint;

/*@-varuse@*/
static int FSint;
static int TYint;
static int V3int;
static int sint;
static int Xqmxt;
static int XqmXt;
/*@=varuse@*/

extern int Gint;
extern int aGb_Xint;

/*@external@*/ int f (void);
extern int g (void);

# define mf() \
  do { int m_x; { int y; }} while (FALSE)



