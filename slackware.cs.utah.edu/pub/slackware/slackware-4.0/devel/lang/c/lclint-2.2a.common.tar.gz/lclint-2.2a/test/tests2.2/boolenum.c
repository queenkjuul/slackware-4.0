typedef enum {
        FALSE = 0,
        TRUE = 1
} BOOLEAN;

int
main ()
{
   BOOLEAN a = TRUE;

   if (a == TRUE) {
       return 1; 
   } else {
       return 0;
   }
}




