#!/bin/bash
# $Id: install-dcethreads.sh,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $
############################################################################
#    
#  COPYRIGHT NOTICE
#    
#  Copyright (C) 1995, 1996 Michael T. Peterson
#  This file is part of the PCthreads (tm) multithreading library
#  package.
#    
#  The source files and libraries constituting the PCthreads (tm) package
#  are free software; you can redistribute them and/or modify them under
#  the terms of the GNU Library General Public License as published by the Free
#  Software Foundation; either version 2 of the License, or (at your
#  option) any later version.
#    
#  The PCthreads (tm) package is distributed in the hope that it will
#  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Library General Public License for more details.
#    
#  You should have received a copy of the GNU Library General Public
#  License along with this library (see the file COPYING.LIB); if not,
#  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
#  MA 02139, USA.
#    
#  To report bugs, bug fixes, or provide feedback you may contact the
#  author, Michael T. Peterson, at either of the two email addresses listed
#  below:
#    
#                 mtp@big.aa.net (Preferred)
#                 mtp@zso.dec.com
#    
#    
#  Michael T. Peterson
#  Issaquah, WA
#  29 June, 1996
############################################################################
# $Log: install-dcethreads.sh,v $
# Revision 1.1.1.1  1996/06/30 15:50:53  mtp
# DCE threads for Linux V1.0
#
############################################################################
WHOAMI=root
VERSION=1.0.0
LIBDIR=/usr/lib
INCDIR=/usr/include
DCEDIR=/usr/include/dce

INCSRC=../include
LIBSRC=../lib

if [ `whoami` != "$WHOAMI" ]
then
   echo ""
   echo "  Sorry, you must have root privileges to execute this script"
   echo ""
   exit 1
fi

echo "+ Installing header files..."

if [ ! -d $DCEDIR ]
then
    echo    "  Creating "$DCEDIR""
    mkdir $DCEDIR
fi

cp -f $INCSRC/pthread_dce.h $DCEDIR
cp -f $INCSRC/exc_handling.h $DCEDIR
cp -f $INCSRC/pthread_exc.h $DCEDIR
ln -s -f $DCEDIR/pthread_dce.h $INCDIR/pthread_dce.h

#
# Make copies of any files about to be overwritten.  This is just in case
# the user already has header files of the same name.
#
cp -b $INCSRC/errorlog.h $INCDIR
cp -b $INCSRC/errormsg.h $INCDIR
cp -b $INCSRC/locks.h $INCDIR
cp -b $INCSRC/utils.h $INCDIR

cp -f $LIBSRC/*.a $LIBDIR
cp -f $LIBSRC/*.so.$VERSION $LIBDIR

ln -s -f $LIBDIR/libc_r.so.1.0.0 $LIBDIR/libc.so.1
ln -s -f $LIBDIR/liblocks.so.1.0.0 $LIBDIR/liblocks.so.1
ln -s -f $LIBDIR/libpthread-ext.so.1.0.0 $LIBDIR/libpthread-ext.so.1
ln -s -f $LIBDIR/libpthread_dce.so.1.0.0 $LIBDIR/libpthread_dce.so.1
ln -s -f $LIBDIR/libsock_r.so.1.0.0 $LIBDIR/libsock_r.so.1

/sbin/ldconfig $LIBDIR

exit 0
