/*
 * $Id: utils.h,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: utils.h,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#ifndef _utils_
#define _utils_
#include <pthread.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>
#include <stdio.h>

#if __STDC__
# include <stdarg.h>
#else
# include <varargs.h>       /* It's a BSD system */
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern int
fprintf_r( FILE *stream, const char *format, ... );

extern int
printf_r( const char *format, ... );

extern void *
malloc_r( size_t bytes );

extern void
free_r( void *ptr );

extern struct dirent *
readdir_r( DIR *dir );

extern DIR *
opendir_r( const char *name );

extern int
closedir_r( DIR *dp );

extern void
print_system_counters( void );

extern int
create_joinable( pthread_t *th, thread_proc_t proc, void *arg );

extern char *
strchr_r( const char *s, int c );

extern char *
strrchr_r( const char *s, int c );

extern char *
strcpy_r( char *dest, const char *src );

extern char *
strncpy_r( char *dest, const char *src, size_t n );

extern size_t
strlen_r( const char *s );

extern int
strcmp_r( const char *s1, const char *s2 );

extern int
strncmp_r( const char *s1, const char *s2, size_t p );

extern long
strtol_r( const char *nptr, char **endptr, int base );

extern char *
strerror_r( int errno );

extern char *
strcat_r( char *dest, const char *src );

extern char *
strncat_r( char *dest, const char *src, size_t n );

extern int
stat_r( const char *file_name, struct stat *buf );

extern int
fstat_r( int filedes, struct stat *buf );

extern int
lstat_r( const char *file_name, struct stat *buf );

#define THREAD_SUCCESS ((void *)SUCCESS)
#define THREAD_FAILURE ((void *)FAILURE)

#define CHECK(status,msg) \
{ \
    if( status != SUCCESS ) \
    { \
        fprintf_r(stderr, "%s at line %d in %s:", msg, __LINE__, __FILE__ ); \
        fprintf_r(stderr, "%s!\n", sys_errlist[status] ); \
        pthread_exit( THREAD_FAILURE ); \
    } \
}

/*
 * If you are not using a thread-safe standard library, you can compile your
 * program using the _THREAD_SAFE_ definition.  This will redefine a few of the
 * more common standard library routines to the thread-safe counter parts
 * defined in this module.
 */
#ifdef _THREAD_SAFE_

#define fprintf     fprintf_r
#define printf      printf_r
#define malloc      malloc_r
#define free        free_r
#define readdir     readdir_r
#define opendir     opendir_r
#define closedir    closedir_r
#define strchr      strchr_r
#define strrcjr     strrchr_r
#define strcpy      strcpy_r
#define strncpy     strncpy_r
#define strlen      strlen_r
#define strcmp      strcmp_r
#define strncmp     strncmp_r
#define strtol      strtol_r
#define strerror    strerror_r
#define strcat      strcat_r
#define strncat     strncat_r
#define stat        stat_r
#define fstat       fstat_r
#define lstat       lstat_r

#endif /* _THREAD_SAFE_ */


#ifdef __cplusplus
}
#endif
#endif
