#ifndef lint
static const char rcsid[] = "$Id: test8.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: test8.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <utils.h>

static void 
proc( int *iterations )
{
   int i, st;
   struct timespec tmo;

   for(i = 0; i < *iterations; i++)
   {
       tmo.tv_sec = rand() % 10;
       tmo.tv_nsec = 0;
       st = pthread_delay_np( &tmo );
       CHECK(st, "pthread_delay_np()");
   }

   pthread_exit( (void *) SUCCESS );
}

static pthread_t  *th;

int 
main( int argc, char *argv[] )
{
   int iterations, i, st, exit_status, num_threads = 1;

   if( argc == 2 )
        num_threads = atoi( argv[1] );

   th = malloc( num_threads * sizeof( pthread_t ));
   
   iterations = 10;
   for(i = 0; i < num_threads; i++ )
   {
       st = create_joinable( &th[i], (thread_proc_t) proc, &iterations );
       CHECK(st, "create_joinable()");
   }

   for(i = 0; i < num_threads; i++ )
   {
       st = pthread_join( th[i], (void **) &exit_status );
       CHECK(st, "pthread_join()");

       if( exit_status != SUCCESS )
           fprintf(stderr, "Failed to join with thread[%d]!\n", i + 2 );
   }

   free( th );

   return( EXIT_SUCCESS );
}
