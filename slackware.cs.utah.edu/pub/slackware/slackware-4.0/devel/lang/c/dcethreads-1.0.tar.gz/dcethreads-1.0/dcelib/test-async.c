#ifndef lint
static const char rcsid[] = "$Id: test-async.c,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: test-async.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:53  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <utils.h>

#define ITERATIONS ((long) 100000)
static pthread_t  compute_th, cancel_th;

static void 
proc( void )
{
    long i;
    double sum;

    pthread_setasynccancel( CANCEL_ON );
    for(i = 0; i < ITERATIONS; i++ )
        sum += i;


    for(i = ITERATIONS; i >= 0; i-- )
    {
        sum /= i;
        sum *= ITERATIONS;
        sum -= 1;
    }

    pthread_exit( (void *) EXIT_SUCCESS );
}

static void
cancel_thread( void  )
{
    pthread_cancel( compute_th );
    pthread_exit( (void *) EXIT_SUCCESS );
}

int 
main( int argc, char *argv[] )
{
    int exit_status = 0, st;

    st = create_joinable( &compute_th, (thread_proc_t) proc, NULL );
    TH_CHECK(st, "create_joinable()");

    /*
     * Allow the compute thread to get started.
     */
    pthread_yield();

    st = pthread_create( &cancel_th,
                         pthread_attr_default,
                         (thread_proc_t) cancel_thread,
                         NULL );
    TH_CHECK(st, "pthread_create()");

   st = pthread_join( compute_th, (void **) &exit_status );
   TH_CHECK(st, "pthread_join()");

   if( exit_status == PTHREAD_CANCELED )
        printf("compute_th asynchronously cancelled\n");
   else
        printf("compute_th not cancelled asynchronously\n");

   st = pthread_join( cancel_th, NULL );
   TH_CHECK(st, "pthread_join()");

   return( EXIT_SUCCESS );
}
