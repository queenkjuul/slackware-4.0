#ifndef lint
static const char rcsid[] = "$Id: test2.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: test2.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include "utils.h"

#define THREADS 3

void
locker( void )
{
   /*
    * Recursively lock the global mutex.
    */
   pthread_lock_global_np();
   pthread_lock_global_np();
   pthread_lock_global_np();

   pthread_unlock_global_np();
   pthread_unlock_global_np();
   pthread_unlock_global_np();

   pthread_exit( (void *) SUCCESS );
}

static pthread_t th[THREADS];

int 
main( int argc, char *argv[] )
{
   int i, status, exit_status;

   for(i = 0; i < THREADS; i++ )
   {
       status = create_joinable( &th[i], (thread_proc_t) locker, NULL );
       CHECK(status, "create_joinable()");
   }

   for(i = 0; i < THREADS; i++ )
   {
       status = pthread_join( th[i], (void **) &exit_status );
       CHECK(status, "pthread_join()");
   }

   return( EXIT_SUCCESS );
}
