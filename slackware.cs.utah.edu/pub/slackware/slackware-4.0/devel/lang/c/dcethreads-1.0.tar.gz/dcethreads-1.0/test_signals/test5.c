#ifndef lint
static const char rcsid[] = "$Id: test5.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: test5.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 * COMMENT:
 *
 *      Create 4 sigwaiters each of which will wait for the SIGINT, SIGTERM, 
 *      SIGHUP, and SIGQUIT signals.
 */
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <utils.h>

#define THREADS ((int) 4)
extern int getpid( void );

void
waiter( void )
{
	sigset_t sigset;
	int caught = FAILURE;

   sigemptyset( &sigset );
   sigaddset( &sigset, SIGINT );
   sigaddset( &sigset, SIGTERM );
   sigaddset( &sigset, SIGHUP );
   sigaddset( &sigset, SIGQUIT );

   pthread_sigmask( SIG_SETMASK, &sigset, NULL );

	switch((caught = sigwait( sigset )))
	{
	  case SIGINT:
		printf("Caught SIGINT");
		break;
	  case SIGTERM:
		printf("Caught SIGTERM");
		break;
	  case SIGHUP:
		printf("Caught SIGHUP");
		break;
	  case SIGQUIT:
		printf("Caught SIGQUIT");
		break;
	  default:
                printf("Error: %d\n", caught );
		break;

	}

	pthread_exit( (void *) caught );
}

static pthread_t th[THREADS];

int 
main( int argc, char *argv[] )
{
   int exit_status, st, i;
   pthread_attr_t attr;

   printf("pid %d: Blocked %d %d %d %d\n", 
		   getpid(), SIGINT, SIGQUIT, SIGHUP, SIGTERM );

   /*
    * Create some joinable threads each of which will inherit the
	* main threads mask of blocked signals.
    */
   st = pthread_attr_init( &attr );
   CHECK( st, "pthread_attr_init()");

   st = pthread_attr_setdetachstate( &attr, PTHREAD_CREATE_JOINABLE );
   CHECK( st, "pthread_attr_setdetachstate()");
   for(i = 0; i < THREADS; i++ )
   {
	   st = pthread_create( &th[i], &attr, (thread_proc_t) waiter, NULL ); 
	   CHECK(st, "pthread_create()");
   }

   for(i = 0; i < THREADS; i++ )
   {
       st = pthread_join( th[i], (void **) &exit_status );
       CHECK( st, "pthread_join()");
   }

   st = pthread_attr_destroy( &attr );
   CHECK( st, "pthread_attr_destroy()");

   return( EXIT_SUCCESS );
}





