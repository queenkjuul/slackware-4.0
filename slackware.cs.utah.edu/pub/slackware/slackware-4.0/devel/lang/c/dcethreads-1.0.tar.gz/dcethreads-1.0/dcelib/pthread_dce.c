#ifndef lint
static const char rcsid[] = "$Id: pthread_dce.c,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: pthread_dce.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:53  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <errno.h>
#include <pthread.h>
#include "pthread_dce.h"

pthread_attr_t         pthread_attr_default;
pthread_mutexattr_t    pthread_mutexattr_default;
pthread_condattr_t     pthread_condattr_default;

static pthread_once_t defaults_initialized = PTHREAD_ONCE_INIT;
static void d4_init( void );

void
pthd4_yield( void )
{
   (void) pthread_once( &defaults_initialized, d4_init );
   pthread_yield( NULL );
}

int
pthd4_attr_create( pthread_attr_t *attr )
{
	int istat;

	if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
		return( -1 );

	if( pthread_attr_init( attr ) != SUCCESS )
		return( FAILURE );

	/*
	 * Draft 4/DCE threads are created as joinable threads.  POSIX threads
	 * are not.
	 */
	istat = pthread_attr_setdetachstate( attr, PTHREAD_CREATE_JOINABLE );
	if( istat != SUCCESS )
		return( FAILURE );

	return( SUCCESS );
}

int 
pthd4_attr_delete( pthread_attr_t *attr)
{
	if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
		return( -1 );

    if( pthread_attr_destroy( attr ) != SUCCESS )
		return( FAILURE );

    return( SUCCESS );
}

int 
pthd4_attr_setstacksize( pthread_attr_t *attr, long stacksize )
{
    int istat = 0;

	if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
		return( -1 );

    istat = pthread_attr_setstacksize( attr, (size_t)stacksize );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

long
pthd4_attr_getstacksize( pthread_attr_t attr)
{
	size_t stacksize;

	if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
		return( -1 );

    if( pthread_attr_getstacksize( &attr, &stacksize ) != SUCCESS )
		return( FAILURE );

    return( (long) stacksize );
}

int
pthd4_create( pthread_t *th_h,
              pthread_attr_t attr,
              pthread_startroutine_t proc,
              pthread_addr_t arg )
{
    int istat = 0;

	if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
		return( -1 );

	if( attr == NULL )
	{
		pthread_seterrno_np( EINVAL );
		pthread_lock_global_np();
		errno = EINVAL;
		pthread_unlock_global_np();
		return( -1 );
	}

	istat = pthread_create( th_h, &attr, (thread_proc_t) proc,  arg );
	if( istat != SUCCESS )
		return( FAILURE );

    return( istat );
}

int 
pthd4_detach( pthread_t *thread )
{
    int istat = 0;

	if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
		return( -1 );

    istat = pthread_detach( *thread );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

void
pthd4_exit( pthread_addr_t status )
{
   (void) pthread_once( &defaults_initialized, d4_init );
    pthread_exit( (void *) status );
}

int 
pthd4_join( pthread_t thread, pthread_addr_t *status )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_join( thread, (void **) status );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int
pthd4_mutexattr_create( pthread_mutexattr_t *attr )
{
	int istat;

	istat = pthread_mutexattr_init( attr );
	if( istat != SUCCESS )
		return( FAILURE );

	return( SUCCESS );
}

int 
pthd4_mutexattr_delete ( pthread_mutexattr_t *attr)
{
	if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
		return( -1 );

    if( pthread_mutexattr_destroy( attr ) != SUCCESS )
		return( FAILURE );

    return( SUCCESS );
}

int 
pthd4_mutex_init( pthread_mutex_t *mutex, pthread_mutexattr_t attr )
{
   int istat = 0;

   if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
       return( -1 );

   if( attr == NULL || attr == pthread_mutexattr_default )
      istat = pthread_mutex_init( mutex, NULL );
   else
      istat = pthread_mutex_init( mutex, &attr );

   if ( istat > 0 )
       istat = -1;

   return( istat );
}

int 
pthd4_mutex_destroy( pthread_mutex_t *mutex )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_mutex_destroy( mutex );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int
pthd4_mutex_lock( pthread_mutex_t *mutex )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_mutex_lock( mutex );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_mutex_trylock( pthread_mutex_t *mutex )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_mutex_trylock( mutex );  

    if ( istat == EBUSY )      /* The mutex was locked */
       istat = 0;

   else if( istat == 0 )       /* The mutex is now locked and owned by */
       istat = 1;              /* the calling thread.                  */

   else
       istat = -1;             /* Bad news */

    return( istat );
}

int 
pthd4_mutex_unlock( pthread_mutex_t *mutex )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_mutex_unlock( mutex );  
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int
pthd4_condattr_create( pthread_condattr_t *attr )
{
	int istat;

	istat = pthread_condattr_init( attr );
	if( istat != SUCCESS )
		return( FAILURE );

	return( SUCCESS );
}

int 
pthd4_condattr_delete ( pthread_condattr_t *attr)
{
	if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
		return( -1 );

    if( pthread_condattr_destroy( attr ) != SUCCESS )
		return( FAILURE );

    return( SUCCESS );
}


int 
pthd4_cond_init( pthread_cond_t *cond, pthread_condattr_t attr )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    if( attr == NULL || attr == pthread_condattr_default )
       istat = pthread_cond_init( cond, NULL );
    else
       istat = pthread_cond_init( cond, &attr );                     

    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_cond_destroy( pthread_cond_t *cond )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_cond_destroy( cond );  
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_cond_broadcast( pthread_cond_t *cond )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_cond_broadcast( cond );  
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_cond_signal( pthread_cond_t *cond )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_cond_signal( cond );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_cond_wait( pthread_cond_t *cond, pthread_mutex_t *mutex )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_cond_wait( cond, mutex );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_cond_timedwait( pthread_cond_t *cond,
                      pthread_mutex_t *mutex,
                      struct timespec *abstime )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_cond_timedwait( cond, mutex, abstime );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_once( pthread_once_t *once_block, void (*init_routine)(void) )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_once( once_block, init_routine );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_keycreate( pthread_key_t *key, pthread_destructor_t destructor )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_key_create( key, destructor );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_setspecific( pthread_key_t key, pthread_addr_t value )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_setspecific( key, value );  
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_getspecific( pthread_key_t key, pthread_addr_t *value )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_getspecific( key, value );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

/*
 * Post a cancel to a thread.  This does not directly cancel the thread.
 * Once posted, the target thread will cancel itself when both of the
 * following conditions are true:
 *
 *  1)  The target thread reaches a cancellation point or calls
 *      pthread_testcancel()
 *
 *  and
 *
 *  2) The value of the target thread's cancel state is CANCEL_ON.
 */
int 
pthd4_cancel( pthread_t thread )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_cancel( thread );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

/*
 * Enables (CANCEL_ON) or disables (CANCEL_OFF) asynchronous cancellation.
 * For a thread to be asynchronously canceled, asynchronous cancellation must
 * be enabled *AND* the thread must have been requested to cancel, i.e., its
 * cancel pending flag must be TRUE.
 */
int 
pthd4_setasynccancel( int state )
{
    int istat = 0;
    int old_type = 0;
    int new_type = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    if ( state == CANCEL_OFF )
        new_type = PTHREAD_CANCEL_DEFERRED;

    else if( state == CANCEL_ON )
        new_type = PTHREAD_CANCEL_ASYNCHRONOUS;

    else
        return( EINVAL );

    istat = pthread_setcanceltype( new_type, &old_type );
    if ( istat > 0 )
        return( -1 );

    return( old_type );
}

int 
pthd4_setcancel( int state )
{
    int istat = 0;
    int prev_state = 0;
    int new_state = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    if ( state == CANCEL_OFF )
        new_state = PTHREAD_CANCEL_DISABLE;
    else
        new_state = PTHREAD_CANCEL_ENABLE;

    istat = pthread_setcancelstate( new_state, &prev_state );
    if ( istat > 0 )
        prev_state = -1;

    return( prev_state );
}

int 
pthd4_get_expiration_np( struct timespec *delta, struct timespec *abstime )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_getexpiration_np( delta, abstime );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

int 
pthd4_delay_np( struct timespec *interval )
{
    int istat = 0;

    if( pthread_once( &defaults_initialized, d4_init ) != SUCCESS )
        return( -1 );

    istat = pthread_delay_np( interval );
    if ( istat > 0 )
        istat = -1;

    return( istat );
}

static void 
d4_init( void )
{
   pthd4_attr_create( &pthread_attr_default );
   pthd4_mutexattr_create( &pthread_mutexattr_default );
   pthd4_condattr_create( &pthread_condattr_default );
}
