#ifndef lint
static const char rcsid[] = "$Id: c_r.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: c_r.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "utils.h"

static pthread_attr_t attr;
static pthread_once_t once_init = PTHREAD_ONCE_INIT;

static void
init_attr( void )
{
	pthread_attr_init( &attr );
	(void) pthread_attr_setdetachstate( &attr, PTHREAD_CREATE_JOINABLE );
}

char *h1 = "  Timer          Preemptions     Elapsed Time";
char *h2 = "Interrupts    Async       Sync    Secs:Usec";
char *h3 = "----------    ----------------  --------------";

/*
 * Conditionalize print_system_counters() so that the "printf" functions
 * DO NOT get interpreted as "printf_r".  Since we're going to call printf
 * 6 times in a row, we can take out a single global lock and protect all
 * six calls.  Otherwise, we would take out the global lock everytime a
 * call to printf_r is made.
 */
#ifdef _THREAD_SAFE_
#undef _THREAD_SAFE_
#endif

void
print_system_counters( void )
{
   unsigned long cpu_intr_count, cpu_ctxsw_count, cpu_elapsed_usec,
                 cpu_async_count, seconds, usec;

   (void) system_get_state( &cpu_intr_count, 
                            &cpu_ctxsw_count, 
                            &cpu_async_count,
                            &cpu_elapsed_usec, 
                            NULL );

   seconds = cpu_elapsed_usec / 1000000;
   usec = cpu_elapsed_usec % 1000000;

   pthread_lock_global_np();
   
   printf("\n");
   printf("\t  *** PTHREADS RUNTIME STATS ***\n\n");
   printf("%s\n", h1 );
   printf("%s\n", h2 );
   printf("%s\n", h3 );
   printf("%5ld   %10ld  %8ld %7ld:%ld\n", cpu_intr_count, 
                                           cpu_async_count,
                                           cpu_ctxsw_count, 
                                           seconds, usec );
   printf("\n");

   pthread_unlock_global_np();
}

#define _THREAD_SAFE_ 1

int 
stat_r(const char *file_name, struct stat *buf)
{
   int st;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   st = stat( file_name, buf );
   pthread_unlock_global_np();

   return( st );
}

int
fstat_r(int filedes, struct stat *buf)
{
   int st;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   st = fstat( filedes, buf );
   pthread_unlock_global_np();

   return( st );
}

int 
lstat_r(const char *file_name, struct stat *buf)
{
   int st;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   st = lstat( file_name, buf );
   pthread_unlock_global_np();

   return( st );
}

void
error_msg( const char *msg )
{
   int err;

	(void) pthread_once( &once_init, init_attr );

   (void) pthread_geterrno_np( NULL, &err );
   pthread_lock_global_np();
   fprintf( stderr, ">> %s failed: %s\n", msg, sys_errlist[err] );
   pthread_unlock_global_np();
}   

int
create_joinable( pthread_t *th, thread_proc_t proc, void *arg )
{
	int status;

	(void) pthread_once( &once_init, init_attr );
	status = pthread_create( th, &attr, proc, arg );
	return( status );
}

void *
malloc_r( size_t nbytes )
{
	void *ptr;

	(void) pthread_once( &once_init, init_attr );

	pthread_lock_global_np();
	ptr = malloc( nbytes );
	pthread_unlock_global_np();

	return( ptr );
}

void
free_r( void *ptr )
{
	(void) pthread_once( &once_init, init_attr );

	pthread_lock_global_np();
	free( ptr );
	pthread_unlock_global_np();
}


int
output_r( FILE *stream, const char *string )
{
	int nchars;

	(void) pthread_once( &once_init, init_attr );

	pthread_lock_global_np();
	nchars = fprintf( stream, "%s\n", string );
	pthread_unlock_global_np();

	return( nchars );
}

int
fprintf_r( FILE *fp, const char *fmt, ...)
{
   int ret;
   va_list ap;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();

   va_start(ap, fmt);
   ret = vfprintf(fp, fmt, ap);
   va_end(ap);

   pthread_unlock_global_np();
   return (ret);
}

int
printf_r( const char *fmt, ...)
{
   int ret;
   va_list ap;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();

   va_start(ap, fmt);
   ret = vfprintf(stdout, fmt, ap);
   va_end(ap);

   pthread_unlock_global_np();
   return (ret);
}

struct dirent *
readdir_r( DIR *dir )
{
   struct dirent *dent;

   (void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   dent = readdir( dir );
   pthread_unlock_global_np();

   return( dent );
}

DIR *
opendir_r( const char *name )
{
   DIR *dp;

   (void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   dp = opendir( name );
   pthread_unlock_global_np();

   return( dp );
}

int
closedir_r( DIR *dir )
{
   int st;

   (void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   st = closedir( dir );
   pthread_unlock_global_np();

   return( st );
}
   
char *
strchr_r( const char *s, int c )
{
   char *ch;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   ch = strchr(s,c);
   pthread_unlock_global_np();

   return( ch );
}

char *
strrchr_r( const char *s, int c )
{
   char *ch;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   ch = strrchr(s,c);
   pthread_unlock_global_np();

   return( ch );
}

char *
strcpy_r( char *dest, const char *src )
{
	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   strcpy( dest, src );
   pthread_unlock_global_np();

   return( dest );
}

char *
strncpy_r( char *dest, const char *src, size_t n )
{
	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   strncpy( dest, src, n );
   pthread_unlock_global_np();

   return( dest );
}

size_t
strlen_r( const char *s )
{
   size_t len;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   len = strlen( s );
   pthread_unlock_global_np();

   return( len );
}

int
strcmp_r( const char *s1, const char *s2 )
{
   int n;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   n = strcmp( s1, s2 );
   pthread_unlock_global_np();

   return( n );
}

int
strncmp_r( const char *s1, const char *s2, size_t p )
{
   int n;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   n = strncmp( s1, s2, p );
   pthread_unlock_global_np();

   return( n );
}

long
strtol_r( const char *nptr, char **endptr, int base )
{
   long n;

	(void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   n = strtol( nptr, endptr, base );
   pthread_unlock_global_np();

   return( n );
}

char *
strerror_r( int errno )
{
   char *err;

   (void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   err = strerror( errno );
   pthread_unlock_global_np();

   return( err );
}

char *
strcat_r( char *dest, const char *src )
{
   (void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   strcat( dest, src );
   pthread_unlock_global_np();

   return( dest );
}

char *
strncat_r( char *dest, const char *src, size_t n )
{
   (void) pthread_once( &once_init, init_attr );

   pthread_lock_global_np();
   strncat( dest, src, n );
   pthread_unlock_global_np();

   return( dest );
}
