#ifndef lint
static const char rcsid[] = "$Id: test-join.c,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: test-join.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:53  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <utils.h>

static void 
proc( int *id )
{
    pthread_exit( (void *) *id );
}

static pthread_t  *th;
static int *arg;

int 
main( int argc, char *argv[] )
{
   int exit_status = 0, i, st, num_threads = 1;


   if( argc == 2 )
       num_threads = atoi( argv[1] );

   th = malloc( num_threads * sizeof( pthread_t ));
   arg = malloc( num_threads * sizeof( int ));

   for(i = 0; i < num_threads; i++ )
   {
        arg[i] = i;
        st = create_joinable( &th[i], (thread_proc_t) proc, &arg[i] );
        TH_CHECK(st, "create_joinable()");
   }

    for(i = 0; i < num_threads; i++ )
    {
        st = pthread_join( th[i], (void **) &exit_status );
        TH_CHECK(st, "pthread_join()");

        printf("th[%d] exit status %d\n", i, exit_status );
    }

   free( th );
   free( arg );
   return( EXIT_SUCCESS );
}
