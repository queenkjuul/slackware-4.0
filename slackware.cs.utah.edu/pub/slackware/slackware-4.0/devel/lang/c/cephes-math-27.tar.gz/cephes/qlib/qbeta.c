/*  qbeta.c  */

#include "qhead.h"

int qgamma();

int qbeta( a, b, y )
QELT a[], b[], y[];
{
QELT r[NQ], s[NQ];

qadd( a, b, r );
qgamma( r, s );

qgamma( a, r );
qdiv( s, r, s );

qgamma( b, r );
qmul( s, r, y );
return 0;
}
