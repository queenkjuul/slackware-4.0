/*	qexp2.c	*/

#include "qhead.h"
extern QELT qlog2[];

int qexp2( x, y )
QELT x[], y[];
{
QELT a[NQ];

qmul( x, qlog2, a );
qexp( a, y );
return 0;
}

int qlogtwo( x, y )
QELT x[], y[];
{

qlog( x, y );
qdiv( qlog2, y, y );
return 0;
}
