#include "qhead.h"
#define BIG  1.44115188075855872E+17
extern double MAXNUM;
extern QELT qone[];
int qgamma();

int qincgs( a, x, y )
QELT a[], x[], y[];
{
QELT q[NQ], r[NQ], s[NQ], t[NQ], sum[NQ];


qmov( qone, r );	/*	r = 1.0	*/
qmov( qone, sum );	/*	sum = 1.0	*/
qmov( a, q );		/*	q = a	*/

do
	{
	qadd( qone, q, q );	/*	q += 1.0	*/
	qdiv( q, x, s );	/*	r *= x/q	*/
	qmul( r, s, r );
	qadd( sum, r, sum );	/*	sum += r	*/
	}
while( ((int) sum[1] - (int) r[1]) < (NBITS/2) );

qadd( a, qone, s );
qgamma( s, t );	/*	sum /= gamma(a+1.0)	*/
qdiv( t, sum, sum );
qmov( x, q );	/*	sum *= exp( -x )	*/
q[0] = ~q[0];
qexp( q, q );
qmul( q, sum, y );
return 0;
}
