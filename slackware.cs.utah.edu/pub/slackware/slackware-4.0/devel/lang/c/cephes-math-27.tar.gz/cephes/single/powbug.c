#include "powf.c"
#include <stdio.h>

int
main()
{
	float	Ans, Arg = 5.54836711396205172073E12, Arg2 = Arg*Arg;
//	printf("Arg2 = %.9e\n", Arg2);
//	Ans = powf(Arg2, 1.5F);
	printf("powf(3.078437846E+025, 1.500000000E+000)\n");
	Ans = powf(3.078437846E+025F, 1.500000000E+000F);
	printf("Ans = %.10e\n", Ans);
exit(0);
}
