# ifndef LLGRAMMAR2_H
# define LLGRAMMAR2_H

# include "llgrammar_gen2.h"

# else
# error "Multiple includes"
# endif
