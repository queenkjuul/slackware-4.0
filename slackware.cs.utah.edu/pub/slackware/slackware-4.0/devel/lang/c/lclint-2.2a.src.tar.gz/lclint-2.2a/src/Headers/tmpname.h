extern cstring makeTempName (cstring dir, cstring pfx, cstring sfx);
