/* herald.h - created automatically by gmake homeversion */
/*@constant observer char *LCL_VERSION;@*/
# define LCL_VERSION "LCLint 2.2a+ --- Tue Sep 3 19:02:06 EDT 1996"
/*@constant observer char *LCL_PARSE_VERSION;@*/
# define LCL_PARSE_VERSION "LCLint 2.2a+"
/*@constant observer char *LCL_COMPILE;@*/
# define LCL_COMPILE "Compiled using cc -O5 -D_INTRINSICS -D_INLINE_INTRINSICS -D_FASTMATH -migrate -float_const -fp_reorder -readonly_strings -assume noaccuracy_sensitive -compress -tune host -ansi_alias -inline speed -feedback lclint.feedback  on OSF1 okemo.lcs.mit.edu V3.2 148 alpha by evs"
