/*
** Copyright (c) Massachusetts Institute of Technology 1994, 1995, 1996.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. This code may not be re-distributed or modified
**        without permission from MIT (contact 
**        lclint-request@larch.lcs.mit.edu.)  
**
**        Modification and re-distribution are encouraged,
**        but we want to keep track of changes and
**        distribution sites.
*/

typedef struct _fcnNode {
  ltoken name;
  /*@null@*/ lclTypeSpecNode typespec;
  declaratorNode declarator;
  globalList globals;
  varDeclarationNodeList inits;
  letDeclNodeList lets;
  /*@null@*/ lclPredicateNode checks;
  /*@null@*/ lclPredicateNode require;
  /*@null@*/ modifyNode modify;
  /*@null@*/ lclPredicateNode ensures;
  /*@null@*/ lclPredicateNode claim;
  qual special;
} *fcnNode;

extern void fcnNode_free (/*@null@*/ /*@only@*/ fcnNode p_f);
extern /*@only@*/ cstring fcnNode_unparse (/*@null@*/ fcnNode p_f);
