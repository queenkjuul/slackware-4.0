/*
** Copyright (c) Massachusetts Institute of Technology 1994, 1995, 1996.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. This code may not be re-distributed or modified
**        without permission from MIT (contact 
**        lclint-request@larch.lcs.mit.edu.)  
**
**        Modification and re-distribution are encouraged,
**        but we want to keep track of changes and
**        distribution sites.
*/
/*
** imports.c
**
** module for importing LCL specs.
**
**  AUTHOR:
**	Yang Meng Tan, Massachusetts Institute of Technology
*/

# include "lclintMacros.nf"
# include "llbasic.h" 
# include "osd.h"
# include "llgrammar.h" /* need simpleOp, MULOP and logicalOp in makeInfixTermNode */
# include "lclscan.h"
# include "checking.h"
# include "imports.h"
# include "lslparse.h"
# include "lh.h"
# include "herald.h"

void
outputLCSFile (char *path, char *msg, char *specname)
{
  static bool haserror = FALSE;
  char *sfile = mstring_concat (specname, ".lcs");
  char *outfile = mstring_concat (path, sfile);
  char *s;
  FILE *outfptr = fopen (outfile, "w");

  sfree (sfile);
  
  /* check write permission */
  
  if (outfptr == 0)
    {				/* fopen fails */
      if (!haserror)
	{
	  lclplainerror (message ("Cannot write to output file: %s", 
				  cstring_fromChars (outfile)));
	  haserror = TRUE;
	}
      sfree (outfile);
      return;
    }

  fprintf (outfptr, msg);
  fprintf (outfptr, "%s\n", LCL_PARSE_VERSION);
  
  /* output line %LCLimports foo bar ... */
  fprintf (outfptr, "%%LCLimports ");

  lsymbolSet_elements (currentImports, sym)
    {
      s = lsymbol_toChars (sym);

      if (s != NULL && !mstring_equal (s, specname))
	{
	  fprintf (outfptr, "%s ", s);
	}
    } end_lsymbolSet_elements;
  
  fprintf (outfptr, "\n");
  
  sort_dump (outfptr, TRUE);
  symtable_dump (symtab, outfptr, TRUE);

  check (fclose (outfptr) == 0);  
  sfree (outfile);  
}

void
importCTrait (void)
{
  char **infile = (char **) dmalloc (sizeof (*infile));
  filestatus status = osd_getLarchPath (CTRAITSYMSNAME, infile);

  switch (status)
    {
    case OSD_FILEFOUND:
      (void) parseSignatures (cstring_fromChars (*infile));
      break;
    case OSD_FILENOTFOUND:
      /* try spec name */
      status = osd_getLarchPath (CTRAITSPECNAME, infile);

      if (status == OSD_FILEFOUND)
	{
	  callLSL (CTRAITSPECNAME,
		   cstring_toCharsSafe
		   (message ("includes %s (%s for String)",
			     cstring_fromChars (CTRAITFILENAMEN), 
			     cstring_fromChars (sort_getName (sort_cstring)))));
	  break;
	}
      else
	{
	  llmsg 
	    (message ("Unable to find %s or %s.  Check LARCH_PATH environment variable.",
		      cstring_fromChars (CTRAITSYMSNAME), 
		      cstring_fromChars (CTRAITSPECNAME)));
	  llexit (LLFAILURE);
	}
    case OSD_PATHTOOLONG:
      lclbug (message ("importCTrait: the concatenated directory and file "
		       "name are too long: %s: "
		       "continuing without it", 
		       cstring_fromChars (CTRAITSPECNAME)));
      break;
    }

  sfree (*infile);
  sfree (infile);
}

/*
** processImport --- load imports from file
**
**    impkind: IMPPLAIN  file on SPEC_PATH
**                       # include "./file.h" if it exists,
**			 # include "<directory where spec was found>/file.h" if not.
**			   (warn if neither exists)
**            IMPBRACKET file in default LCL imports directory
**                       # include <file.h>
**            IMPQUOTE   file directly
**                       # include "file.h"
*/

void
processImport (lsymbol importSymbol, ltoken tok, impkind kind)
{
  bool readableP, oldexporting;
  bool oldFormat = FALSE;
  tsource *imported, *imported2, *lclsource;
  char *bufptr, *tmpbufptr, *cptr;
  char *name;
  lsymbol sym;
  char importName[MAX_NAME_LENGTH + 1], *importFileName, *realfname;
  char *path;
  char *fpath, *fpath2;
  mapping *map;
  filestatus ret;

  importFileName = lsymbol_toCharsSafe (importSymbol);
  name = mstring_concat (importFileName, IO_SUFFIX);
  realfname = name;

  /*
  ** find .lcs file
  */
  
  switch (kind)
    {
    case IMPPLAIN:
      path = cstring_toCharsSafe 
	(message ("%s:%s", cstring_fromChars (localSpecPath), getLarchPath ()));
      
      break;
    case IMPBRACKET:
      path = mstring_copy (osd_getEnvironment (LCLIMPORTDIR, DEFAULT_LCLIMPORTDIR));
      break;
    case IMPQUOTE:
      path = mstring_copy (localSpecPath);
      break;
    default:
      path = mstring_createEmpty (); /* suppress gcc error message */
      llbuglit ("bad imports case\n");
    }

  DPRINTF (("processImport: %s\nrealfname: %s", path, realfname)); 
  
  if ((ret = osd_getPath (path, realfname, &fpath)) != OSD_FILEFOUND)
    {
      char *fname2;
      
      if (ret == OSD_PATHTOOLONG)
	{
	  llfatalerrorLoc (cstring_makeLiteral ("Path too long"));
	}
      
      imported2 = tsource_create (importFileName, LCL_SUFFIX, FALSE);
      fname2 = tsource_fileName (imported2);
      
      

      if (osd_getPath (path, fname2, &fpath2) == OSD_FILEFOUND)
	{
	  llfatalerrorLoc
	    (message ("Specs must be processed before it can be imported: %s", 
		      cstring_fromChars (fpath2)));
	}
      else
	{
	  if (kind == IMPPLAIN || kind == IMPQUOTE)
	    llfatalerrorLoc (message ("Cannot find file to import: %s", 
				       cstring_fromChars (realfname)));
	  else
	    llfatalerrorLoc (message ("Cannot find standard import file: %s",
				       cstring_fromChars (realfname)));
	}
    }

  
  imported = tsource_create (fpath, IO_SUFFIX, FALSE);
  DPRINTF (("imported: %s", tsource_fileName (imported)));

  
  readableP = tsource_open (imported);
  
  

  if (!readableP)
    {			/* can't read ? */
      llfatalerrorLoc (message ("Cannot open import file for reading: %s",
				 cstring_fromChars (tsource_fileName (imported))));
    }

  bufptr = tsource_nextLine (imported);

  if (bufptr == 0)
    {
      llerror (FLG_SYNTAX, message ("Import file is empty: %s", 
				    cstring_fromChars (tsource_fileName (imported))));
      sfree (name);
      (void) tsource_close (imported);
      sfree (path);
      return;
    }

  /* was it processed successfully ? */
  if (firstWord (bufptr, "%FAILED"))
    {
      llfatalerrorLoc
	(message ("Imported file was not checked successfully: %s.", 
		  cstring_fromChars (name)));
    }
  
  /** is it generated by the right version of the checker? 
   **
   ** old .lcs files start with %PASSED
   ** new (compressed) files start with %LCS 
   */
  
  if (firstWord (bufptr, "%PASSED"))
    {
      /* %PASSED Output from LCP Version 2.* and 3.* */
      /*                     1234567890123*/
      /*                                 +*/

      cptr = strstr (bufptr, "LCP Version");
      
      if (cptr != NULL)
	{
	  cptr += 12;
	  if (*cptr != '2' && *cptr != '3')
	    {
	      llfatalerrorLoc (message ("Imported file is obsolete: %s.",
					 cstring_fromChars (bufptr)));
	    }
	}
      oldFormat = TRUE;
    }
  else 
    {
      if (!firstWord (bufptr, "%LCS"))
	{
	  llfatalerrorLoc (message ("Imported file is not in correct format: %s.",
				    cstring_fromChars (bufptr)));
	}
    }
  
  /* push the imported LCL spec onto currentImports */
  
  

  context_enterImport ();
  
  bufptr = tsource_nextLine (imported);
  llassert (bufptr != NULL);

  tmpbufptr = bufptr;

  /* expect %LCLimports foo bar ... */
  if (firstWord (bufptr, "%LCLimports "))
    {
      bufptr = bufptr + strlen ("%LCLimports ");
      while (sscanf (bufptr, "%s", importName) == 1)
	{
	  bufptr = bufptr + strlen (importName) + 1;	/* 1 for space */
	  sym = lsymbol_fromChars (importName);
	  if (sym == importSymbol || 
	      lsymbolSet_member (currentImports, sym))
	    {
	      /* ensure that the import list does not contain itself: an
		 invariant useful for checking imports cycles. */
	      lclsource = LCLScanSource ();
	      lclfatalerror (tok, 
			     message ("Imports cycle: %s.lcl imports %s",
				      cstring_fromChars (importFileName),
				      cstring_fromChars (importName)));
	    }	  
	  /* push them onto currentImports */
	  /* evs - 94 Apr 3:  I don't think it should do this! */
	  /* (void) lsymbolSet_insert (currentImports, sym); */
	}
    }
  else
    {
      lclsource = LCLScanSource ();
      lclfatalerror (tok, message ("Unexpected line in imported file %s: %s", 
				   cstring_fromChars (name), 
				   cstring_fromChars (bufptr)));
    }
	  
  /* read in the imported info */
  oldexporting = sort_setExporting (TRUE);

  map = mapping_create ();

  /* tok for error line numbering */

  if (oldFormat)
    {
      DPRINTF (("sort import: %s", tsource_fileName (imported)));
      sort_import (imported, tok, map);	
    }
  
  (void) sort_setExporting (oldexporting);

  /* sort_import updates a mapping of old anonymous sorts to new
     anonymous sort that is needed in symtable_import */
  /* mapping_print (map); */
  
  if (oldFormat)
    {
      symtable_import (imported, tok, map);
    }
  else
    {
      /* symtable_loadImport (imported, tok, map); */
    }
  
  (void) tsource_close (imported);

  sfree (map);
  sfree (name);
  sfree (path);

  context_leaveImport ();  
}



