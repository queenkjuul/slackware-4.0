char *f (void)
{
  return MYSTERY;
}
