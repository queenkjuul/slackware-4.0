# include "decl2.h"

int *glob2;
int glob2[];

char glob3;

int glob;
int glob;
