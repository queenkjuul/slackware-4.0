# ifndef LLGRAMMAR_H
# define LLGRAMMAR_H

# include "llgrammar_gen.h"

/*@-redecl@*/
extern bool inTypeDef;
extern void ylerror (char *p_s);
/*@=redecl@*/

# else
# error "Multiple includes"
# endif
