# ifndef CTOKENS
# define CTOKENS

# include "cgramtoks.h"

# else
# error "Multiple include"
# endif CTOKENS
