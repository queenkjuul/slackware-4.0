extern /*@owned@*/ char *gname;

void setName (/*@temp@*/ char *pname)
{
  gname = pname;
}
