/*
** Copyright (c) Massachusetts Institute of Technology 1994, 1995, 1996.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. This code may not be re-distributed or modified
**        without permission from MIT (contact 
**        lclint-request@larch.lcs.mit.edu.)  
**
**        Modification and re-distribution are encouraged,
**        but we want to keep track of changes and
**        distribution sites.
*/
/*
** lsymbolSet.c
**
** based on set_template.c
**
** where T has T_equal (or change this) and T_unparse
*/

# include "lclintMacros.nf"
# include "llbasic.h"
 
lsymbolSet lsymbolSet_new ()
{
  lsymbolSet s = (lsymbolSet) dmalloc (sizeof (*s));

  s->entries = 0;
  s->nspace = lsymbolSetBASESIZE;
  s->elements = (lsymbol *) dmalloc (sizeof (*s->elements) * lsymbolSetBASESIZE);

  return (s);
}

static void
lsymbolSet_grow (lsymbolSet s)
{
  int i;
  lsymbol *newelements; 

  llassert (lsymbolSet_isDefined (s));

  s->nspace = lsymbolSetBASESIZE;
  newelements = (lsymbol *) dmalloc (sizeof (*newelements) 
				       * (s->entries + lsymbolSetBASESIZE));

  if (newelements == (lsymbol *) 0)
    {
      llfatalerror (cstring_makeLiteral ("lsymbolSet_grow: out of memory!"));
    }

  for (i = 0; i < s->entries; i++)
    {
      newelements[i] = s->elements[i]; 
    }

  sfree (s->elements); 
  s->elements = newelements;
}

/*
** Ensures: if *e \in *s
**          then unchanged (*s) & result = false
**          else *s' = insert (*s, *e) & result = true
** Modifies: *s
*/

bool
lsymbolSet_insert (lsymbolSet s, lsymbol el)
{
  llassert (lsymbolSet_isDefined (s));

  if (lsymbolSet_member (s, el))
    {
      return FALSE;
    }
  else
    {
      if (s->nspace <= 0)
	lsymbolSet_grow (s);
      s->nspace--;
      s->elements[s->entries] = el;
      s->entries++;
      return TRUE;
    }
}

bool
lsymbolSet_member (lsymbolSet s, lsymbol el)
{
  if (lsymbolSet_isDefined (s))
    {
      int i;
      
      for (i = 0; i < s->entries; i++)
	{
	  /* was: &el == &s->elements[i] ! */

	  if (lsymbol_equal (el, s->elements[i]))
	    {
	      return TRUE;
	    }
	}
    }

  return FALSE;
}

/*@only@*/ cstring
lsymbolSet_unparse (lsymbolSet s)
{
  if (lsymbolSet_isDefined (s))
    {
      int i;
      cstring st = cstring_makeLiteral ("{");
      
      for (i = 0; i < s->entries; i++)
	{
	  if (i == 0)
	    {
	      st = message ("%q %s", st, 
			    cstring_fromChars (lsymbol_toChars (s->elements[i])));
	    }
	  else
	    st = message ("%q, %s", st, 
			  cstring_fromChars (lsymbol_toChars (s->elements[i])));
	}
      
      st = message ("%q }", st);
      return st;
    }
  else
    {
      return (cstring_makeLiteral ("{ }"));
    }
}

void
lsymbolSet_free (/*@null@*/ lsymbolSet s)
{
  if (lsymbolSet_isDefined (s))
    {
      sfree (s->elements); 
      sfree (s);
    }
}
