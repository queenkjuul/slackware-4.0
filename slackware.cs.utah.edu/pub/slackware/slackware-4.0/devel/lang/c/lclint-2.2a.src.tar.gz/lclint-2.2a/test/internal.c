/*@-varuse@*/
  /*1234567890123456789012345678901XXXXXXXX*/
int iwonderhowmanycharactersaresignificant1 (void);
int iwonderhowmanycharactersaresignificant2 (void);
int manycharactersaresignificant1 (void);
int manycharactersaresignificant2 (void);

extern int fl;

void f1 (void)
{
  int e1;
  char *el; 
  int alphabet;
  int *Alphabet;
  int alphabet1soup;
  int *alphabetlsoup;
  int lcase;

  {
    int e1;
    int a1phabet;
    char *lcAse;
    int s52;
    int sS2;
    int s5Z;
    int numO;
    int num0;
  }
}
  
