# ifndef FORWARDTYPES_H
# define FORWARDTYPES_H

abst_typedef /*@dependent@*/ /*@null@*/ struct _sRef *sRef;
abst_typedef /*@null@*/ struct _uentry *uentry;
immut_typedef int typeIdSet;
typedef struct _typeExpr *typeExpr;
typedef struct _termNode *termNode;
typedef /*@only@*/ uentry o_uentry;
typedef /*@null@*/ struct _lclTypeSpecNode *lclTypeSpecNode;
abst_typedef /*@null@*/ struct _idDecl *idDecl;
abst_typedef /*@null@*/ struct _usymtab  *usymtab;
abst_typedef /*@null@*/ struct _exprNode *exprNode;
abst_typedef /*@null@*/ struct _guardSet *guardSet;
abst_typedef struct _termNodeList *termNodeList;
abst_typedef /*@null@*/ struct _sRefSet *sRefSet;
abst_typedef /*@null@*/ struct _aliasTable *aliasTable;
abst_typedef /*@null@*/ struct _ltoken *ltoken;
abst_typedef /*@null@*/ struct __fileloc *fileloc;
typedef unsigned int ltokenCode;
typedef unsigned int sort;

/*@-cppnames@*/
typedef int bool;
/*@=cppnames@*/

immut_typedef int ctype;
typedef long unsigned lsymbol;

/* sRef -> bool */
typedef bool (*sRefTest) (sRef);

/* sRef, fileloc -> void, modifies sRef */
typedef void (*sRefMod) (sRef, fileloc);

/* sRef -> void */
typedef void (*sRefShower) (sRef);

# endif
