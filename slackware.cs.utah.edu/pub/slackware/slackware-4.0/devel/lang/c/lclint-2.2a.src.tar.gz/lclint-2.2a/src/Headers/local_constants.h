/*@constant observer char *DEFAULT_CPPCMD; @*/
# define DEFAULT_CPPCMD    "/lib/cpp "  

/*@constant observer char *SYSTEM_LIBDIR; @*/
# define SYSTEM_LIBDIR     "/usr/include"

/*@constant observer char *DEFAULT_LARCHPATH; @*/
# define DEFAULT_LARCHPATH ".:/u/evs/lclint/lib"

/*@constant observer char *DEFAULT_LCLIMPORTDIR; @*/
# define DEFAULT_LCLIMPORTDIR   "/u/evs/lclint/imports"

