#include <stdio.h>
#include <string.h>

#include "c-bat.h"
#include "clients.h"

int Pid;

/* This function should override the library function. Used to
   fake a client using the same pid even if this program is called
   more than once
 */

int getpid(void)
{
  return( Pid );
 }


main( int argc, char *argv[])
{ int  pid;
  int  server = MASTER_ID, 
       ret_id;
   
  char arg1[STRINGSIZE],
       arg2[STRINGSIZE],
       arg3[STRINGSIZE],
       arg4[ 2 * STRINGSIZE],
       arg5[2 * STRINGSIZE];
  short  ret,
         i,
         cmd,
         flag,
         code,
         static_flag;
  long   line,
         m_id;
   
   
   if( argv[1][1] == '?'  )
     { fprintf(stderr, "brs_sendcmd [-s<serverid>]\nSend a command to a server. \n");
       fprintf(stderr, "The result can be read in using the debug_msg command\n");
       exit(1);
      }
   
   
   for( i = 1; i < argc; i++ )
     { if( argv[i][0] != '-' )
         { fprintf( stderr, "Unknown option \"%s\" ! Aborting !\n", argv[i] );
           exit(1);
          }
       switch( argv[i][1] )
         { case 's': server = atoi( argv[i] + 2);
                     break;
           default : fprintf( stderr, "Unknown option \"%s\" ! Aborting !\n", argv[i] );
                     exit(1);
          }
      }

   printf("\nCommand (int): ");
   arg1[0] = 0;
   gets( arg1 );
   cmd = atoi( arg1 );
   printf("\nPID          : ");   
   arg1[0] = 0;
   gets( arg1 );
   Pid = (arg1[0]) ? atoi( arg1 ) : 1000;
   printf("\nflags        : ");   
   arg1[0] = 0;
   gets( arg1 );
   flag = (arg1[0]) ? atoi( arg1 ) : 0;
   
   arg1[0] = 0;
   arg2[0] = 0;
   printf("\nArgument1    : ");   
   gets( arg1 );
   printf("\nArgument2    : ");   
   gets( arg2 );

   printf("Issuing command %hd to server %d\n", cmd, server );
   printf("Flag: %hd , Pid: %d\n", flag, getpid() );
   printf("Argument1: \"%s\"\n", arg1 );
   printf("Argument2: \"%s\"\n", arg2 );
   
   send_brs_cmd( server, cmd, flag, arg1, arg2 );
   
 }
      

       
