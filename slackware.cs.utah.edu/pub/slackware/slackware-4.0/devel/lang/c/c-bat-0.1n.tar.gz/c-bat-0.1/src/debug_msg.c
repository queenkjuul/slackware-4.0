#include <stdio.h>
#include <string.h>

#include "c-bat.h"
#include "clients.h"


main( int argc, char *argv[])
{ int  pid;
  int  server, ret_id;
  char arg1[STRINGSIZE],
       arg2[STRINGSIZE],
       arg3[STRINGSIZE],
       arg4[ 2 * STRINGSIZE],
       arg5[2 * STRINGSIZE];
  short  ret,
         i,
         cmd,
         flag,
         code,
         static_flag;
  long   line,
         m_id;
   
   
   if( argv[1][1] == '?'  )
     { fprintf(stderr, "debug_msg \nRead all messages in queue\n");
       exit(1);
      }
   
   
   /* for( i = CMD_CALLS; i <= CMD_TYPEDEFS; ) */
   while( 1 )
     { *arg1 = 0;
       *arg2 = 0;
       *arg3 = 0;
       *arg4 = 0;
      
       ret =  brs_get_msg_debug( 0, &server, &pid, &cmd ,&ret_id, &flag, arg1, arg2, arg3, arg4);
      
       if( ret == RET_TIMEOUT )
         { /* i++;           continue; */
           break;
          }
      
       /* print message and then again with the same i */
      
       switch( ret )
         { case RET_FILE:              printf("RET_FILE: "); break;
           case RET_FUNCT:             printf("RET_FUNCT: "); break;
           case RET_VAR:               printf("RET_VAR: "); break;
           case RET_L_VAR:             printf("RET_L_VAR: "); break;
           case RET_POS:               printf("RET_POS: "); break;
           case RET_END:               printf("RET_END: "); break;
           case RET_ERROR:             printf("RET_ERROR: "); break;
           case RET_OK:                printf("RET_OK: "); break;
           case RET_STRUCT:            printf("RET_STRUCT: "); break;
           case RET_UNION:             printf("RET_UNION: "); break;
           case RET_ENUM:              printf("RET_ENUM: "); break;
           case RET_E_CONST:           printf("RET_E_CONST: "); break;
           case RET_S_COMP:            printf("RET_S_COMP: "); break;
           case RET_U_COMP:            printf("RET_U_COMP: "); break;
           case RET_TYPEDEF:           printf("RET_TYPEDEF: "); break;
           case RET_REFERENCE:         printf("RET_REFERENCE: "); break;
           case RET_FPOS:              printf("RET_FPOS: "); break;
           case RET_DIR:               printf("RET_DIR: "); break;
           case RET_COMP:              printf("RET_COMP: "); break;
           case RET_ENUM_C:            printf("RET_ENUM_C: "); break;
           case RET_MACRO:             printf("RET_MACRO: "); break;
           case RET_CONNECT:           printf("RET_CONNECT: "); break;
           case RET_REFUSED:           printf("RET_REFUSED: "); break;
           case RET_CMD_UNKNOWN:       printf("RET_CMD_UNKNOWN: "); break;
           case RET_TIMEOUT:           printf("RET_TIMEOUT: "); break;
           case RET_ABORT:             printf("RET_ABORT: "); break;
           case RET_PLEASE_WAIT:       printf("RET_PLEASE_WAIT: "); break;
           case CMD_CONNECT:           printf("CMD_CONNECT: "); break;
           case CMD_RELEASE:           printf("CMD_RELEASE: "); break;
           case CMD_TERMINATE:         printf("CMD_TERMINATE: "); break;
           case CMD_SERVER:            printf("CMD_SERVER: "); break;
           case CMD_SERVERKILL:        printf("CMD_SERVERKILL: "); break;
           case CMD_SERVER_ID:         printf("CMD_SERVER_ID: "); break;
           case CMD_SERVERTABLE:       printf("CMD_SERVERTABLE: "); break;
           case CMD_S_TABLE_END:       printf("CMD_S_TABLE_END: "); break;
           case CMD_NEW_FILE:          printf("CMD_NEW_FILE: "); break;
           case CMD_TABLE:             printf("CMD_TABLE: "); break;
           default:                    printf("??%3d ??: ", ret); break;
          }
      
        printf(" server: %d,  client-pid %d, command sent: %hd, msg-id: %d, flag %02hx \n",
                     server, pid, cmd, ret_id, flag );
        if( arg1[0] ) 
           printf("arg1 : \"%s\"\n", arg1 );
        if( arg2[0] ) 
           printf("arg2 : \"%s\"\n", arg2 );
        if( arg3[0] ) 
           printf("arg3 : \"%s\"\n", arg3 );
        if( arg4[0] ) 
           printf("arg4 : \"%s\"\n", arg4 );
      }
   
 }
      

       
