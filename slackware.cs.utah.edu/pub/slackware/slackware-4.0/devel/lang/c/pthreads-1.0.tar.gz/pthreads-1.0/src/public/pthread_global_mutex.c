#ifndef lint
static const char rcsid[] = "$Id: pthread_global_mutex.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pthread_global_mutex.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:14  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:55  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:45  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include "pthread.h"
#include "public.h"
#include "thread.h"
#include "mutex.h"
#include "nub.h"
#include "error.h"

static int
unlock_global_mutex_struct( struct PTHREAD_HANDLE *th );

static struct PTHREAD_MUTEX_HANDLE *global_mu;
static pthread_mutex_t             x_global_mu;
static pthread_once_t              global_mu_initialized = PTHREAD_ONCE_INIT;

static void
init_global_mu( void )
{
   pthread_mutex_init( &x_global_mu, NULL );
   global_mu = x_global_mu;
}

static int
unlock_global_mutex_struct( struct PTHREAD_HANDLE *th )
{
   struct PTHREAD_HANDLE *unblocked_th;
   int st;

   /*
    * If this is the last "unlock", then remove the mutex from the pool
    * of mutexes belonging to the calling thread.
    */
   if( global_mu->obj.ref_count == 1 )
   {
       st = remove_mutex_from_pool( &th->obj.locked_mutexes, global_mu->id );
       if( st == FAILURE )
       {
           set_thread_errno( ESRCH );
           return( ESRCH );
       }

       global_mu->obj.active_th = NULL;
       global_mu->obj.ref_count = 0;
   }

   if( global_mu->obj.ref_count == 0 )
   {
       /*
        *  --  Select the highest priority blocked thread, remove it from the
        *      queue of threads blocked at the mutex, and insert it onto the 
        *      ready queue.  
        */
       unblocked_th = dequeue_thread( &global_mu->obj.blocked_threads );
       if( unblocked_th )
       {
           global_mu->obj.active_th = unblocked_th;
           global_mu->obj.accum_lock_count += 1;
           global_mu->obj.ref_count += 1;

           unblocked_th->obj.thread_state = THREAD_READY_C;
           enqueue_thread( &thread_rq, unblocked_th );
           LOG(unblocked_th,"blocked->ready");
       }
       else
       {
           /*
            * No threads were blocked at the global mutex.  Clear all state and
            * return.
            */
           global_mu->obj.active_th = NULL;
           sys_reset( &global_mu->obj.lock );
      }
   }
   else
       global_mu->obj.ref_count -= 1;

   return( SUCCESS );
}

int
pthread_lock_global_np( void )
{
   struct PTHREAD_HANDLE *active_th;
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   (void) pthread_once( &global_mu_initialized, init_global_mu );

   sys_disable_ctxsw( flag );
   active_th = nub_get_active_thread();

   /*
    * For a normal mutex, if the semaphore is set, the calling thread
    * is blocked.  For a recursive mutex, the calling thread is allowed
    * to proceed iff it already holds the lock.  In this case, we bump
    * a reference count.
    */
   if( sys_test_and_set( &global_mu->obj.lock ) == SEMAPHORE_C_SET &&
       global_mu->obj.active_th != active_th )
   {
       /*
        *  --  Enqueue the active thread, change its state to BLOCKED and
        *      context switch to another ready thread.
        */
       enqueue_thread( &global_mu->obj.blocked_threads, active_th );
       active_th->obj.thread_state = THREAD_BLOCKED_C;
       active_th->obj.mu_blocked_at = &x_global_mu;
       nub_reschedule( active_th );
   }
   else
   {
       /*
        *  --  Lock the mutex, add it to the pool of locked mutexes already
        *      held by this thread, and register the thread's handle with the
        *      mutex.  This way we can find the mutex if we have the thread or
        *      can find the thread if we have the mutex.
        */
       if( global_mu->obj.active_th == NULL )
       {
           insert_mutex_into_pool( &active_th->obj.locked_mutexes, global_mu );
           global_mu->obj.active_th = active_th;
       }

       global_mu->obj.accum_lock_count += 1;
       global_mu->obj.ref_count += 1;
   }

   RETURN( SUCCESS );
}

int  
pthread_unlock_global_np( void )
{
   struct PTHREAD_HANDLE *active_th;
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   (void) pthread_once( &global_mu_initialized, init_global_mu );

   sys_disable_ctxsw( flag );

   /*
    *  --  If the mutex semaphore isn't set, then the mutex is not locked.
    *      Return with an appropriate error code.
    */
   if( global_mu->obj.lock == SEMAPHORE_C_CLEAR )
   {
       set_thread_errno( ENOLCK );
       RETURN( ENOLCK );
   }

   /*
    *  --  Make sure that the mutex is held by the calling thread.
    */
   if( global_mu->obj.active_th != (active_th = nub_get_active_thread()))
   {
       set_thread_errno( ENOLCK );
       RETURN( ENOLCK );
   }

   if( (st = unlock_global_mutex_struct( active_th )) != SUCCESS )
       RETURN( st );       

   /*
    *  --  Reschedule if necessary.
    */
   if( active_th->obj.sched_param.sched_priority < get_highest_prio( &thread_rq ) )
   {
       active_th->obj.thread_state = THREAD_READY_C;
       nub_reschedule( active_th );
   }

   RETURN( SUCCESS );
}
