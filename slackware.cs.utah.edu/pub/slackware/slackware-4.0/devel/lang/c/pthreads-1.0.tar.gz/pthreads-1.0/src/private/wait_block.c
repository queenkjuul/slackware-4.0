#ifndef lint
static const char rcsid[] = "$Id: wait_block.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: wait_block.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:08  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:47  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:36  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <dbgmem.h>
#include "wait_block.h"

static int
wb_matches( sigwait_block_t *wb, int sig )
{
   int valid = FALSE;

   if( sigismember( &wb->wb_sigset, sig ) )
   {
       if( waitblock_get_waiter_count( wb ) > 0 )
           valid = TRUE;
   }

   return( valid );
}

/*
 * --  Initialize and Destroy sigwait blocks
 */
sigwait_block_t *
init_sigwait_block( void )
{
   sigwait_block_t *wb;

   pthread_lock_global_np();
   wb = MALLOC( sizeof( sigwait_block_t ));
   pthread_unlock_global_np();

   wb->next = NULL;
   wb->signal_pending = 0;
   pthread_mutex_init( &wb->wb_lock, NULL );
   pthread_cond_init( &wb->wb_cond, NULL );
   sigemptyset( &wb->wb_sigset );

   return( wb );
}

void
destroy_sigwait_block( sigwait_block_t *wb )
{
   pthread_mutex_destroy( &wb->wb_lock );
   pthread_cond_destroy( &wb->wb_cond );
   wb->next = NULL;
   sigemptyset( &wb->wb_sigset );

   pthread_lock_global_np();
   FREE( wb );
   pthread_unlock_global_np();

   wb = NULL;
}

int
waitblock_get_waiter_count( sigwait_block_t *wb )
{
   int waiters;

   pthread_cond_getwaiters_np( wb->wb_cond, &waiters );
   return( waiters );
}

sigwait_block_t *
waitblock_get_matching( sigwait_block_list_t *list, sigset_t set )
{
   sigwait_block_t *curr = NULL;

   pthread_mutex_lock( &list->lock );
   if( list->elements == 0 )
   {
       pthread_mutex_unlock( &list->lock );
       return( curr );
   }

   curr = list->first;
   while( curr->wb_sigset != set && curr->next != NULL )
       curr = curr->next;

   if( curr->wb_sigset != set )
       curr = NULL;

   pthread_mutex_unlock( &list->lock );
   return( curr );
}
/*xxxxxxxxxxxxxxxxxxxxxxxxxxx */

void
insert_waitblock( sigwait_block_list_t *wbl, sigwait_block_t *wb )
{
   pthread_mutex_lock( &wbl->lock );

   wb->next = wbl->first;
   wbl->first = wb;
   wbl->elements += 1;

   pthread_mutex_unlock( &wbl->lock );
}

void
remove_waitblock( sigwait_block_list_t *wbl, sigwait_block_t *wb )
{
   sigwait_block_t *curr = NULL, *prev = NULL;

   pthread_mutex_lock( &wbl->lock );

   if( wbl->elements == 0 )
   {
       pthread_mutex_lock( &wbl->lock );
       return;
   }

   prev = curr = wbl->first;
   while( curr != wb && curr->next != NULL )
   {
       prev = curr;
       curr = curr->next;
   }

   if( curr == wb )
   {
       if( curr == wbl->first )
           wbl->first = curr->next;
       else
           prev->next = curr->next;

       wbl->elements -= 1;
   }

   pthread_mutex_unlock( &wbl->lock );
}

sigwait_block_t *
get_waitblock( sigwait_block_list_t *wbl, int sig )
{
   sigwait_block_t *wb = NULL;

   pthread_mutex_lock( &wbl->lock );
   if( wbl->elements == 0 )
   {
       pthread_mutex_unlock( &wbl->lock );
       return( wb );
   }

   wb = wbl->first;
   while( !wb_matches(wb, sig) && wb->next != NULL )
       wb = wb->next;

   if( !wb_matches(wb, sig))
       wb = NULL;

   pthread_mutex_unlock( &wbl->lock );
   return( wb );
}
