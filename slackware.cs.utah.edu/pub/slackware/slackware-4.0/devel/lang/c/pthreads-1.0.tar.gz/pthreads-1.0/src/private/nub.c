#ifndef lint
static const char rcsid[] = "$Id: nub.c,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: nub.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:03  mtp
 * + Release 2.0
 *
 * Revision 1.5  1996/01/14 20:22:44  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.4  1996/01/14 18:32:31  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.3  1996/01/14 17:58:41  mtp
 * + Removed nub_flush_morgue() from nub_reschedule().
 *
 * Revision 1.2  1995/12/31 06:16:02  mtp
 * + Added logic to test and remove asynchronously cancelled threads.
 *
 * Revision 1.1.1.1  1995/12/16 21:41:59  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <setjmp.h>
#include <string.h>
#include "nub.h"
#include "machdep.h"
#include "stack.h"
#include "thread.h"
#include "priority_q.h"
#include "delay.h"
#include "sigwait.h"

#undef gettimeofday

extern void
sig_common_handler( int sig );

extern void
execute_sigaction( int sig, struct PTHREAD_HANDLE *active_th );

extern int
allowed( int sig );

int critical;

#define SAVE_SIGCONTEXT    ((int)1)
#define CALLER_RETURNED    ((int)0)
#define RESTORE_CONTEXT    ((int)1)

typedef struct CONTROL_BLOCK
{
   struct PTHREAD_HANDLE   *active_th;
   int                     active_prio;
   counter_t               ctxsw_count;
   counter_t               async_preemptions;
   counter_t               total_intr;
   counter_t               idle_intr;
   counter_t               user_intr;
   struct timezone         time_zone;
   struct timeval          start_time;
   struct timeval          system_time;
   struct sigaction        action[NSIG];

} control_block_t;

priority_queue_t       thread_rq;
static control_block_t control_block;
   
/*
 * --  Where we keep completed threads that have not been detached.
 */
static thread_pool_t   completed_threads;

/*
 * --  Where we keep completed threads that have been detached.
 */
static thread_pool_t   morgue;

/*
 * --  This service is called when detaching a completed thread.  If the
 *     thread is not found in the morgue, set the active thread's errno
 *     and return a failure indication.
 *
 *     This thread also removes and reclaims all threads on the morgue.
 */
int
nub_reclaim_thread( struct PTHREAD_HANDLE *th )
{
   if( remove_thread_from_pool( &completed_threads, th->id ) == FAILURE )
   {
       control_block.active_th->obj.errno = EINVAL;
       return( FAILURE );
   }              
   
   destroy_th_obj( &th->obj );
   free_handle( (void *) th );

   /*
    *  --  Now, take the opportunity to flush all threads from the
    *      morgue.
    */
   nub_flush_morgue();
   th = NULL;

   return( SUCCESS );
}

void
nub_flush_morgue( void )
{
   struct PTHREAD_HANDLE *th;

   while( (th = remove_first_thread_from_pool( &morgue )) != NULL )
   {
       destroy_th_obj( &th->obj );
       free_handle( th );
   }
}

/*
 * --  This function saves the caller's context and signal state on its
 *     local stack, switches to a new thread stack restoring the new thread's
 *     context and signal state.
 */
static void
nub_switch_thread_stacks( struct PTHREAD_HANDLE *new_th, 
                          struct PTHREAD_HANDLE *curr_th )
{
   stack_t *curr, *new;

   sys_save_fpu_context( &curr_th->obj );
   
   new = new_th->obj.stack;
   curr = curr_th->obj.stack;

   if( setjmp( curr_th->obj.saved_context ) == CALLER_RETURNED )
   {
       if( new_th->obj.new_thread )
       {
           new_th->obj.new_thread = FALSE;
           sys_reset( &critical );
       }

       /*
        *  --  If the thread about to be blocked is executing on the timer
        *      interrupt stack, we'll have to reset the interval timer so that
        *      the operating system can continue to deliver SIGVTALRM signals.
        */
       if( curr_th->obj.valid_context == CTX_C_TIMER )
       {
           curr_th->obj.valid_context = CTX_C_STACK;
           reset_interval_timer();
       }

       sys_switch_thread_stacks( new, curr );
       longjmp( curr_th->obj.saved_context, RESTORE_CONTEXT );
   }

   sys_restore_fpu_context( &new_th->obj );
}

struct PTHREAD_HANDLE *
nub_get_active_thread( void )
{
   struct PTHREAD_HANDLE *active_th;

   active_th = control_block.active_th;
   return( active_th );
}

int
nub_get_active_prio( void )
{
   int prio;

   prio = control_block.active_prio;
   return( prio );
}

void
nub_set_active_prio( int prio )
{
   control_block.active_prio = prio;
}

void
nub_init_control_block( struct PTHREAD_HANDLE *active_th )
{
	int i;

	memset( &control_block, 0, sizeof( control_block_t ));

	gettimeofday( &control_block.start_time, &control_block.time_zone );
	memcpy(&control_block.system_time,
		   &control_block.start_time,
		   sizeof( struct timeval ) );

	control_block.active_th = active_th;
	control_block.active_prio = active_th->obj.sched_param.sched_priority;

	/*
	 * Set the nub's version of the process-wide sigaction vector.
	 */
	for(i = 1; i < NSIG; i++ )
	{
		sigaction( SIG_SETMASK, 
				   NULL, 
				   &control_block.action[i] );
	}
}

/*
 * --  Threads arrive here because a context switch is necessary.  This
 *     function *ALWAYS* context switches from the calling thread ("active_th)
 *     to the highest priority thread on the ready queue.  
 *
 *     The design of the rescheduler assumes that the calling thread has set 
 *     its state correctly because the disposition of the calling thread 
 *     depends on its state.  For example, if the calling thread has 
 *     completed, its state will be THREAD_COMPLETE_C and the case block (see
 *     below) will insert the thread into a pool of completed threads or the
 *     morgue (a pool of completed threads that have been detached).
 */
void
nub_reschedule( struct PTHREAD_HANDLE *active_th )
{
   struct PTHREAD_HANDLE *new_th;
   int i;

   /*
    *  --  Dequeue the highest priority thread on the ready queue.  We
    *      call this before inserting the current thread.  Otherwise, a
    *      possibility exists that we just enqueue/dequeue the same thread.
    */
   new_th = dequeue_thread( &thread_rq );
   if( new_th == NULL )
       i = 0;

   switch( active_th->obj.thread_state )
   {
       case THREAD_COMPLETE_C:
           if( active_th->obj.detached_state == PTHREAD_DETACHED_C )
           {
               LOG(active_th, "active->morgue");
               insert_thread_into_pool( &morgue, active_th );
           }
           else
           {
               LOG(active_th, "active->completed");
               insert_thread_into_pool( &completed_threads, active_th );
           }
       break;
       case THREAD_DELAYED_C:
           LOG(active_th, "active->delayed");
       break;
       case THREAD_BLOCKED_C:
           LOG(active_th, "active->blocked");
       break;
       case THREAD_WAITING_C:
           LOG(active_th, "active->waiting");
       break;
       case THREAD_READY_C:
           LOG(active_th, "active->ready");
           enqueue_thread( &thread_rq, active_th );
       break;
       case THREAD_ACTIVE_C:
           LOG(active_th, "?????");
       break;
       default:
           LOG(active_th, "internal error: Unknown state!");
           _exit(1);
       break;
   }
   control_block.active_th = new_th;
   control_block.active_prio = new_th->obj.sched_param.sched_priority;
   control_block.ctxsw_count += 1;
   new_th->obj.thread_state = THREAD_ACTIVE_C;
   new_th->obj.total_ctxsw_count += 1;

   LOG(new_th, "ready->active");
   nub_switch_thread_stacks( new_th, active_th );

   /*
    * Implement asynchronous cancellation.
    */
   if( active_th->obj.cancel_pending == TRUE &&
       active_th->obj.cancel_state == PTHREAD_CANCEL_ENABLE &&
       active_th->obj.cancel_type == PTHREAD_CANCEL_ASYNCHRONOUS )
   {
        sys_reset( &critical );
        pthread_exit( (void *) PTHREAD_CANCELED );
   }

   /*
    * Check the thread's mask of pending signals.  Deliver the
    * the first signal that is NOT blocked and is pending.
    */
   for( i = 1; i < NSIG; i++ )
   {
        if( !sigismember( &new_th->obj.current_sigs, i ) &&
	   sigismember( &new_th->obj.pending_sigs, i ) )
        {
            sigdelset( &new_th->obj.pending_sigs, i );
            if( allowed(i) == FALSE )
                execute_sigaction( i, new_th );
            else
                sig_common_handler( i );

            break;
        }
    }
}

void
nub_set_sigaction( int sig, const struct sigaction *act )
{
	memcpy( &control_block.action[sig], act, sizeof( struct sigaction ));
}

void
nub_get_sigaction( int sig, struct sigaction *act )
{
	memcpy( act, &control_block.action[sig], sizeof( struct sigaction ));
}

counter_t
nub_get_intr_count( void )
{
   return( control_block.total_intr );
}

counter_t
nub_get_ctxsw_count( void )
{
   return( control_block.ctxsw_count );
}

counter_t
nub_get_async_preemptions( void )
{
   return( control_block.async_preemptions );
}

#define CURR_USEC (control_block.system_time.tv_sec * 1000000 + \
                   control_block.system_time.tv_usec)

#define START_USEC (control_block.start_time.tv_sec * 1000000 + \
                    control_block.start_time.tv_usec)

counter_t
nub_get_elapsed_usecs( void )
{
   counter_t elapsed_usecs;

   elapsed_usecs = CURR_USEC - START_USEC;
   return( elapsed_usecs );
}

counter_t
nub_get_system_usecs( void )
{
   return( CURR_USEC );
}

int
nub_get_timeofday( struct timeval *tv, struct timezone *tz )
{
   if( tz )
       memcpy( tz, &control_block.time_zone, sizeof( struct timezone ));

   if( tv )
       memcpy( tv, &control_block.system_time, sizeof( struct timeval ));

   return( 0 );
}

counter_t
nub_update_timer( void )
{
   gettimeofday( &control_block.system_time, NULL );   
   return( CURR_USEC - START_USEC );
}

void
nub_set_idle_intr( counter_t count )
{
   control_block.idle_intr += count;
   control_block.total_intr += count;
}

void
nub_timer_intr( int sig )
{
   struct PTHREAD_HANDLE *active_th;
   int flag, quantum, prio, ctxsw_required = FALSE;
   sched_policy_t policy;

   /*
    * If the interrupt occurred while executing in the thread
    * library, don't process the interrupt, just return.
    */
   control_block.total_intr += 1;
   if( (flag = sys_test_and_set( &critical )) )
       return;

   /*
    *  --  Update the control block counters and unwait any threads whose
    *      timers have expired.
    */
   control_block.user_intr += 1;
   gettimeofday( &control_block.system_time, NULL );
   thread_unwait( CURR_USEC - START_USEC );
   active_th = control_block.active_th;

   /*
    * If this is the idle thread, just return.
    */
   if( active_th->id == PTHREAD_IDLE_ID_C )
       return;

   policy = active_th->obj.sched_param.sched_policy;
   prio = control_block.active_prio;   

   /*
    *  --  Decrement the active thread's quantum count and check whether
    *      the thread should be rescheduled.  The conditions under which
    *      a thread may be rescheduled are two:
    *          1) A higher priority thread is waiting on the ready queue.
    *          2) The active thread's quantum has reached 0 and the thread's
    *             scheduling policy (FCFS, FIFO, OTHER) and ready queue state
    *             dictate a reschedule.
    */
   switch( policy )
   {
       case SCHED_FCFS_C:
           /*
            *  --  Under this policy, a thread is preempted only when a
            *      thread of a higher priority is on the ready queue.  The
            *      thread's quantum is irrelevant.  In otherwords, a thread
            *      will execute to completion unless it is preempted by a
            *      higher priority thread or unless it blocks, waits, or
            *      delays.
            */
           if( prio < get_highest_prio( &thread_rq ) )
               ctxsw_required = TRUE;

       break;

       case SCHED_ROUND_ROBIN_C:
           /*
            *  --  Under this policy, a thread is preempted under two
            *      conditions:  If a higher priority thread is on the
            *      ready_queue or, if the thread's quantum has expired
            *      and a thread of equal priority exists on the ready
            *      queue.  In either case, the active thread's quantum
            *      is replenished and a context switch to the new
            *      thread is executed.
            *
            *      NOTE: Once a thread's quantum decays to zero, it stays
            *      at zero until preempted.  Only when preempted is its 
            *      quantum replenished.
            */
           quantum = active_th->obj.sched_param.sched_quantum -= 1;
           if( quantum <= 0 )
           {
               active_th->obj.sched_param.sched_quantum = 0;
               if( prio <= get_highest_prio( &thread_rq ) )
               {
                   active_th->obj.sched_param.sched_quantum = PTHREAD_DEFAULT_QUANTUM_C;
                   ctxsw_required = TRUE;
               }
           }
           else
           {
               /*
                *  --  Even tho' the quantum hasn't expired, if a higher
                *      priority thread is ready to run, replenish the
                *      quantums and schedule the higher priority thread to
                *      run.
                */
               if( prio < get_highest_prio( &thread_rq ))
               {
                   active_th->obj.sched_param.sched_quantum = PTHREAD_DEFAULT_QUANTUM_C;
                   ctxsw_required = TRUE;
               }
           }

       break;

       case SCHED_PRIORITY_DECAY_C:
           /*
            *  --  Under this policy, if a thread's quantum expires and
            *      a thread of higher or equal priority isn't ready to
            *      run, the active thread's priority is decremented and
            *      and its quantum replenished.  It will continue to execute
            *      at a lower and lower priority until it encounters a thread
            *      of equal or higher priority.
            */
           quantum = active_th->obj.sched_param.sched_quantum -= 1;
           if( quantum == 0 )
           {
               active_th->obj.sched_param.sched_quantum = 0;
               if( prio <= get_highest_prio( &thread_rq ))
               {
                   /*
                    *  --  Don't let the priority fall below the minimum.
                    */
                   prio = active_th->obj.sched_param.sched_priority -= 1;
                   if( prio == 0 )
                       active_th->obj.sched_param.sched_priority = 1;
               }
           }
           else
           {
               if( prio < get_highest_prio( &thread_rq ))
               {
                   active_th->obj.sched_param.sched_quantum = PTHREAD_DEFAULT_QUANTUM_C;
                   ctxsw_required = TRUE;
               }
           }
       break;

       default:
           fprintf( stderr, "Unknown sched policy!\n");
           _exit(1);
       break;
   }

   if( ctxsw_required )
   {
       control_block.async_preemptions += 1;
       active_th->obj.async_preemptions += 1;
       active_th->obj.thread_state = THREAD_READY_C;
       active_th->obj.valid_context = CTX_C_TIMER;
       nub_reschedule( active_th );
   }

   sys_reset( &critical );
}
