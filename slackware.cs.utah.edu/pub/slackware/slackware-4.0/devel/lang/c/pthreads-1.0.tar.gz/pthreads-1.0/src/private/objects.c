#ifndef lint
static const char rcsid[] = "$Id: objects.c,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: objects.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:04  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:44  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:32  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:41:59  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <string.h>
#include "private.h"
#include "thread.h"
#include "mutex.h"
#include "condv.h"
#include "nub.h"
#include "cleanup.h"

extern void
thread_exit_proc( void *exit_arg );

/*---------------------------------------------------------------------------*/
/*                 PRIVATE DATA AND FUNCTIONS                                */
/*---------------------------------------------------------------------------*/
static counter_t x_thread_id_seq;
static counter_t x_mutex_id_seq;
static counter_t x_condv_id_seq;
static counter_t x_get_thread_id( void );
static counter_t x_get_mutex_id( void );
static counter_t x_get_condv_id( void );

static counter_t
x_get_thread_id()
{
   return( x_thread_id_seq++ );
}

static counter_t
x_get_mutex_id()
{
   return( ++x_mutex_id_seq );
}

static counter_t
x_get_condv_id()
{
   return( ++x_condv_id_seq );
}

/*---------------------------------------------------------------------------*/
/*          INITIALIZE AND DESTROY THREAD, MUTEX, AND CONDV OBJECTS          */
/*---------------------------------------------------------------------------*/
counter_t
init_th_obj( thread_obj_t *th, 
             thread_attr_obj_t *th_attr_obj,
             void * (*th_proc)(void *),
             void *th_arg )
{
   size_t st_size;
   int i;

   memcpy( &th->attr_obj, 
            th_attr_obj, 
            sizeof(thread_attr_obj_t));

   memcpy( &th->sched_param, 
           &th_attr_obj->sched_param, 
           sizeof( struct sched_param));

   sigemptyset( &th->current_sigs );
   sigemptyset( &th->pending_sigs );

   th->guard1 = 0xdeadbabe;
   th->guard2 = 0xdeadbabe;
   memset( &th->fpu_context, 0, sizeof( fpu_context_t ));

   th->new_thread = TRUE;
   th->saved_prio = th_attr_obj->sched_param.sched_priority;
   th->thread_state = THREAD_READY_C;
   th->detached_state = th_attr_obj->detached_state;
   th->cancel_state = THREAD_CANCEL_ENABLED_C;
   th->cancel_type = THREAD_CANCEL_DEFERRED_C;
   th->cancel_pending = FALSE;
   th->async_preemptions = 0;
   th->total_ctxsw_count = 0;
   th->mu_blocked_at = NULL;
   th->cv_waiting_at = NULL;
   th->errno = 0;
   th->start_time = nub_get_elapsed_usecs();
   th->cleanup_stack.first = NULL;
   th->cleanup_stack.elements = 0;
   th->exit_value = NULL;
   th->locked_mutexes.first_mutex = NULL;
   th->locked_mutexes.mutex_count = 0;
   th->join_count = 0;

   st_size = th_attr_obj->stack_size;
   th->stack = init_thread_stack( th_proc, th_arg, thread_exit_proc, st_size );
   if( th->stack == NULL )
       return( 0 );

   /*
    *  --  Initialize the thread object's list of private data objects.
    */
   for(i = 0; i < PTHREAD_C_MAX_DATAKEYS; i++ )
       th->key[i] = NULL;

   if( pthread_mutex_init( &th->join_mutex, NULL ) != SUCCESS )
   {
       destroy_thread_stack( th->stack );
       return( 0 );
   }

   if( pthread_cond_init( &th->join_condv, NULL ) != SUCCESS )
   {
       destroy_thread_stack( th->stack );
       pthread_mutex_destroy( &th->join_mutex );
       return( 0 );
   }

   return( x_get_thread_id() );
}

void
destroy_th_obj( thread_obj_t *obj )
{
   destroy_thread_stack( obj->stack );
   (void) pthread_mutex_destroy( &obj->join_mutex );
   (void) pthread_cond_destroy( &obj->join_condv );
}

counter_t
init_mu_obj( mutex_obj_t *mu, mutex_attr_obj_t *mu_attr_obj )
{
   memcpy( &mu->attr_obj, mu_attr_obj, sizeof(mutex_attr_obj_t) );

   mu->lock = SEMAPHORE_C_CLEAR;
   mu->active_th = NULL;
   mu->ref_count = 0;
   init_prio_queue( &mu->blocked_threads );

   return( x_get_mutex_id() );
}

void
destroy_mu_obj( mutex_obj_t *obj )
{
   return;
}

counter_t
init_cv_obj( condv_obj_t *cv, condv_attr_obj_t *cv_attr_obj )
{
   memcpy( &cv->attr_obj, cv_attr_obj, sizeof(condv_attr_obj_t) );
   cv->lock = SEMAPHORE_C_CLEAR;
   init_prio_queue( &cv->waiting_threads );
   cv->accum_wait_count = 0;

   return( x_get_condv_id() );
}

void
destroy_cv_obj( condv_obj_t *obj )
{
   return;
}

/*---------------------------------------------------------------------------*/
/*                        ATTRIBUTE OBJECT SERVICES                          */
/*---------------------------------------------------------------------------*/
thread_attr_obj_t *
init_th_attr_obj( sched_policy_t   sched_policy,
                  int              sched_priority,
                  int              sched_quantum,
                  int              inherit_sched,
                  size_t           stack_size,
                  detached_state_t detached_state )
{
   thread_attr_obj_t *th_attr = NULL;

   th_attr = MALLOC( sizeof( thread_attr_obj_t ));
   if( th_attr )
   {   
       th_attr->sched_param.sched_policy = sched_policy;
       th_attr->sched_param.sched_priority = sched_priority;
       th_attr->sched_param.sched_quantum = sched_quantum;

       th_attr->inherit_sched = inherit_sched;
       th_attr->stack_size = stack_size;
       th_attr->detached_state = detached_state;
   }

   return( th_attr );
}

void
destroy_th_attr_obj( thread_attr_obj_t *obj )
{
   FREE( obj );
   obj = NULL;
}

mutex_attr_obj_t *
init_mu_attr_obj( pthread_protocol_t mu_sched_protocol )
{
   mutex_attr_obj_t *mu_attr = NULL;

   mu_attr = (mutex_attr_obj_t *)MALLOC( sizeof( mutex_attr_obj_t ));
   if( mu_attr )
       mu_attr->mu_sched_protocol = mu_sched_protocol;

   return( mu_attr );
}

void
destroy_mu_attr_obj( mutex_attr_obj_t *obj )
{
   FREE( obj );
   obj = NULL;
}

condv_attr_obj_t *
init_cv_attr_obj( int fcfs )
{
   condv_attr_obj_t *cv_attr = NULL;

   cv_attr = (condv_attr_obj_t *)MALLOC( sizeof( condv_attr_obj_t ));
   if( cv_attr )
       cv_attr->fcfs = fcfs;

   return( cv_attr );
}

void
destroy_cv_attr_obj( condv_attr_obj_t *obj )
{
   FREE( obj );
   obj = NULL;
}
