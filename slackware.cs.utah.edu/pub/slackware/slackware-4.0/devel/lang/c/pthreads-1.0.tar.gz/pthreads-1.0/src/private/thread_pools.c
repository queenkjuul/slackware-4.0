#ifndef lint
static const char rcsid[] = "$Id: thread_pools.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: thread_pools.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:08  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:47  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:36  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include "private.h"
#include "pools.h"
#include "thread.h"
#include "machdep.h"

struct PTHREAD_HANDLE *
remove_first_thread_from_pool( thread_pool_t *pool )
{
   struct PTHREAD_HANDLE *th = NULL;

   if( pool->thread_count == 0 )
       return( th );

   th = pool->first_thread;
   pool->first_thread = th->next_in_pool;
   pool->thread_count -= 1;
   return( th );
}

void
insert_thread_into_pool( thread_pool_t *pool, struct PTHREAD_HANDLE *h )
{
   h->next_in_pool = pool->first_thread;
   pool->first_thread = h;
   pool->thread_count += 1;
}

struct PTHREAD_HANDLE *
return_thread_from_pool( thread_pool_t *pool, counter_t thread_id )
{
   struct PTHREAD_HANDLE *curr;

   if( pool->thread_count == 0 )
       return( NULL );

   curr = pool->first_thread;
   while( curr->id != thread_id && curr->next_in_pool != NULL )
       curr = curr->next_in_pool;

   if( curr->id != thread_id )
       return( NULL );

   return( curr );
}

int
remove_thread_from_pool( thread_pool_t *pool, counter_t thread_id )
{
   int status = FAILURE;
   struct PTHREAD_HANDLE *curr, *prev;

   if( pool->thread_count == 0 )
       return( status );

   prev = curr = pool->first_thread;
   while( curr->id != thread_id && curr->next_in_pool != NULL )
   {
       prev = curr;
       curr = curr->next_in_pool;
   }

   if( curr->id == thread_id )
   {
       /*  --  The first thread must be treated as a special case */
       if( curr != pool->first_thread )
           prev->next_in_pool = curr->next_in_pool;
       else
           pool->first_thread = curr->next_in_pool;           

       pool->thread_count -= 1;
       status = SUCCESS;
   }

   return( status );
}
