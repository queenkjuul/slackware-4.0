#ifndef lint
static const char rcsid[] = "$Id: stack.c,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: stack.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:06  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:46  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:34  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:41:59  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include "private.h"
#include "stack.h"
#include "machdep.h"
#include "stack_cache.h"

const unsigned int STACK_GUARD_VALUE = 0xdeadbabe;
const unsigned int INIT_STACK_VALUE = 0xdeadbeef;

/*
 * Create and initialize a new thread stack.
 */
stack_t *
init_thread_stack( void *  (*th_proc)(void *),
                   void *  th_proc_arg,
                   void    (*th_exit_proc)(void *exit_arg),
                   size_t  bytes_requested )
{
   stack_t *stack;
   unsigned int i;
   unsigned int elements;
   unsigned int start;

   elements = (bytes_requested / 4);

   stack = allocate_stack( elements );
   if( stack == NULL )
       return( NULL );

   stack->overrun_flag = STACK_GUARD_VALUE;
   for(i = 0; i < elements - 1; i++ )
       stack->word[i] = INIT_STACK_VALUE;

   stack->word[elements] = STACK_GUARD_VALUE;

   start = stack->stack_hdr.elements - 1;
   stack->stack_hdr.saved_stack_ptr = &stack->word[start - 3];
   stack->stack_hdr.start_address = &stack->word[start];

   /*
    *  --  Initialize the thread's stack.
    */
   stack->word[start - 2] = (unsigned int) th_proc;
   stack->word[start - 1] = (unsigned int) th_exit_proc;
   stack->word[start - 0] = (unsigned int) th_proc_arg;

   return( stack );
}

void
destroy_thread_stack( stack_t *st )
{
   size_t bytes;

   if( check_thread_stack( st, &bytes ) != STACK_C_OK )
       fprintf( stderr, "stack corrupt!\n");       

   deallocate_stack( st );
}

int
check_thread_stack( stack_t *st, size_t *bytes_never_used )
{
   unsigned int i, status = STACK_C_OK;
   
   *bytes_never_used = 0;

   if( st->overrun_flag != STACK_GUARD_VALUE )
       return( STACK_C_CORRUPT );

   for(i = 0; i < st->stack_hdr.elements - 1; i++ )
   {
       if( st->word[i] == INIT_STACK_VALUE )
           *bytes_never_used += 4;
       else
           break;
   }

   return( status );
}
