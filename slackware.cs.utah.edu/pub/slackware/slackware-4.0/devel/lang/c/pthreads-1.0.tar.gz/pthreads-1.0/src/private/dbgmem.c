#ifndef lint
static const char rcsid[] = "$Id: dbgmem.c,v 1.1.1.1 1996/06/29 01:20:51 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: dbgmem.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:51  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:00  mtp
 * + Release 2.0
 *
 * Revision 1.4  1996/01/14 20:22:41  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.3  1996/01/14 18:32:28  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.2  1996/01/14 17:59:34  mtp
 * + Changed the comment before the mem_block_t declaration.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <string.h>
#include "dbgmem.h"

static char *dbgmem_code[] = { "DBGMEM:prefix corrupted",
                               "DBGMEM:suffix corrupted",
                               "DBGMEM:attempted to free a NULL ptr",
                               "DBGMEM:ptr previously deallocated" 
                             };

#define MAX_C_STRLEN ((int) 64)

/*
 * --  Memory block structure prepended to each allocation.
 */
typedef struct MEMORY_BLOCK
{
    struct MEMORY_BLOCK *blink;     /* Pointer to previous header in chain */
    struct MEMORY_BLOCK *flink;     /* Pointer to next header in chain */    
    char dh_file[MAX_C_STRLEN + 1]; /* File where allocated */
    int dh_line;                    /* Line where allocated */
    size_t dh_size;                 /* Requested size */
    short dh_magic;                 /* Magic number */

} mem_block_t;

/*
 * --  List head for chain of allocated memory
 */
typedef struct LIST_HEAD
{
   mem_block_t    *flink;          /* Ptr to first block in chain */
   mem_block_t    *llink;          /* Ptr to last block in chain */
   long            allocated_mem;
   long            accumulated_mem;
   long            blocks;
   long            threshold;

} chain_t;

static chain_t chain = { NULL, NULL, 0, 0, 0, 0 };

static void
insert_block( mem_block_t *new_block )
{
   mem_block_t *current_last_block = NULL;

   /*
    *  --  Add the memory block to the end of the chain.
    */
   if( chain.blocks == 0 )             /* It's the first block */
   {
       chain.flink = new_block;
       chain.llink = new_block;
       new_block->blink = NULL;
       new_block->flink = NULL;
   }
   else
   {
       current_last_block = chain.llink;
       current_last_block->flink = new_block;
       new_block->blink = current_last_block;
       new_block->flink = NULL;
       chain.llink = new_block;              
   }

   /*
    *  --  Update the counters
    */   
   chain.allocated_mem += new_block->dh_size;
   chain.accumulated_mem += new_block->dh_size;
   chain.blocks += 1;
}

static void
remove_block( mem_block_t *old_block )
{
   mem_block_t *next_block = NULL;
   mem_block_t *prev_block = NULL;

   next_block = old_block->flink;
   prev_block = old_block->blink;

   if( chain.flink == old_block )  /* It's the first in the chain */
       chain.flink = old_block->flink;

   else if( next_block == NULL ) /* It's the last in the chain */
   {
       prev_block->flink = NULL;   
       chain.llink = prev_block;
   }

   else
   {
       prev_block->flink = next_block;
       next_block->blink = prev_block;   
   }

   /*
    *  --  Update the counters
    */   
   chain.allocated_mem -= old_block->dh_size;
   chain.blocks -= 1;
}

static const short _dead = (short) 0xDEAD;               /* Prefix */
static const short _babe = (short) 0xBABE;               /* Suffix */
static const short _beef = (short) 0XBEEF;               /* Test if free'd twice */
static const size_t SIZEOF_MBLOCK = sizeof( mem_block_t );

void *
dbg_malloc(size_t size, char *file, int line)
{
   mem_block_t *memblock;
   void *ptr;

   if( chain.threshold )
   {
       if( chain.threshold < chain.blocks )
           return( NULL );
   }

   /*
    *  --  Allocate memory from the heap for the caller's request plus our
    *      overhead.
    */
   memblock = (mem_block_t *) malloc( SIZEOF_MBLOCK + size + sizeof(_babe) );
   if (memblock == NULL) 
       return(NULL);

   /*
    *  --  Setup the header and trailer, and initialize the block to
    *      some non-zero value.
    */
   ptr = (void *) (memblock + 1);
   memcpy(((char *) ptr) + size, &_babe, sizeof(_babe));

   memblock->dh_size = size;
   memblock->dh_magic = _dead;
   memblock->dh_line = line;
   strcpy( memblock->dh_file, file );

   /*
    *  --  Return the requested block.
    */
   insert_block( memblock );
   return( ptr );
}

dbgmem_status_t
dbg_free( void *ptr, dbgmem_error_t *error )
{ 
	mem_block_t *memblock;
	size_t size;
      
	/*
	 *  --  Check for attempts to free NULL pointers.  Actually
	 *      ANSI allows NULL pointers to be passed to free() with
	 *      no ill-effects so that failing this call is just being
	 *      anal.
	 */
	if (ptr == NULL) 
	{
		*error = DBGMEM_E_NULL_PTR;
		return( DBGMEM_S_FAILURE );
	}

	/*
	 * --  Get pointer to our header and check the magic number.
	 */
	memblock = ((mem_block_t *) ptr) - 1;
	if (memblock->dh_magic != _dead) 
	{
		*error = DBGMEM_E_PREFIX_CORRUPT;
		return( DBGMEM_S_FAILURE );
	}

	/*
     * --  Check the trailer magic number.
     */
    size = memblock->dh_size;
    if (memcmp(((char *) ptr) + size, &_babe, sizeof(_babe))) 
    {
       *error = DBGMEM_E_SUFFIX_CORRUPT;
       return( DBGMEM_S_FAILURE );
    }

   /*
	* --  Return the block to the heap.
	*/
   remove_block( memblock );

   free( memblock );
   return( DBGMEM_S_SUCCESS );
}

void *
dbg_calloc( size_t array_elements, 
            size_t element_size,
            char *file,
            int line )
{
   size_t size;
   void *ptr;

   size = array_elements * element_size;
   ptr = dbg_malloc( size, file, line );
   if( ptr != NULL )
       memset( ptr, 0, size );   

   return( ptr );
}

char *
dbg_error_str( dbgmem_error_t error )
{
   return( dbgmem_code[error] );
}

void
dbg_memstats()
{
   if( chain.allocated_mem <= 0 )
       return;

   printf("Remaining memory: %ld bytes: %ld requests!\n", chain.allocated_mem,
                                                          chain.blocks );
}

long
dbg_allo_mem()
{
   return( chain.allocated_mem );
}

long
dbg_accum_mem()
{
   return( chain.accumulated_mem );
}

long
dbg_requests()
{
   return( chain.blocks );
}

void
dbg_set_threshold( long new_threshold )
{
   chain.threshold = new_threshold;
}

long
dbg_get_threshold()
{
   return( chain.threshold );
}

void
dbg_cancel_threshold()
{
   chain.threshold = 0;
}

void
dbg_dump_chain()
{
   void *ptr = NULL;
   mem_block_t *memblock;

   memblock = chain.flink;
   if( memblock != NULL )
       fprintf(stdout, "\n");

   while( memblock != NULL )
   {
       ptr = (void *) (memblock + 1);
       fprintf( stdout, "%s:%d -- %d bytes remain allocated\n", 
                                     memblock->dh_file,
                                     memblock->dh_line,
                                     memblock->dh_size );
       memblock = memblock->flink;
   }
}
