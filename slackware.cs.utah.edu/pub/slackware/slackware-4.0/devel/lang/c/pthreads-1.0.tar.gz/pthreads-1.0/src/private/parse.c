#ifndef lint
static const char rcsid[] = "$Id: parse.c,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: parse.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:04  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:44  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:32  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <ctype.h>
#include <string.h>
#include "config.h"

#define TIMER_INTERVAL "Timer interval"
#define IDLE_INTERVAL "Idle interval"
#define SCHED_QUANTUM "Sched quantum"
#define SCHED_POLICY "Sched policy"
#define THREAD_PRIORITY "Thread priority"
#define STACK_SIZE "Stack size"

static char *strip_blanks( const char *buf );

static char *
strip_blanks( const char *buf )
{
   int n = 0, i = 0;
   char *str;

   str = malloc( strlen(buf) + 1 );
   
   while( buf[i] != '\n' )
   {
       if( isspace( buf[i] ) )
       {
           i++;
           continue;
       }

       str[n] = buf[i];
       n++;
       i++;
   }

   return( str );
}


static int
skip_line( char *buf )
{
   int blank_line = 1, i = 0, skip = 1;
   char ch;

   ch = buf[i];
   while( ch != '\n' )
   {
       if( !isspace(ch) )
       {
           blank_line = 0;
           break;
       }

       ch = buf[++i];
   }

   if( blank_line )
       return( skip );


   skip = i = 0;
   ch = buf[i];
   while( isspace( buf[i] ) )
       i++;

   if( buf[i] == '#' )
       skip = 1;

   return( skip );
}


static void
condition_line( char *dest, const char *src )
{
   int i = 0;
   char ch;

   ch = src[i];

   while( isspace( src[i] ) )
       i++;

   strcpy( dest, &src[i] );
}

static void
set_timer_interval( config_t *cf, char *token_val )
{
   cf->timer_interval = atol( token_val );
}

static void
set_idle_interval(  config_t *cf, char *token_val )
{
   cf->timer_idle_interval = atol( token_val );
}

static void
set_sched_quantum(  config_t *cf, char *token_val )
{
   cf->default_quantum = atoi( token_val );
}

static void
set_sched_policy(  config_t *cf, char *token_val )
{
   char *str;

   str = strip_blanks( token_val );

   if( strcmp( str, "SCHED_FCFS_C" ) == 0 )
       cf->default_sched_policy = SCHED_FCFS_C;

   else if( strcmp( str, "SCHED_ROUND_ROBIN_C" ) == 0 )
       cf->default_sched_policy = SCHED_ROUND_ROBIN_C;

   else if( strcmp( str, "SCHED_PRIORITY_DECAY_C" ) == 0 )
       cf->default_sched_policy = SCHED_PRIORITY_DECAY_C;

   else
       cf->default_sched_policy = PTHREAD_DEFAULT_SCHED_POLICY_C;

   free( str );
}

static void
set_thread_priority(  config_t *cf, char *token_val )
{
   cf->default_thread_prio = atol( token_val );
}

static void
set_stack_size(  config_t *cf, char *token_val )
{
   cf->default_stack_size = atol( token_val );
}

void
parse_config( FILE *fd, config_t *cf )
{
   char linebuf[128 + 1];
   char newline[128 + 1];
   char *token_str, *token_value;

   while( fgets( linebuf, 128, fd ) != NULL )
   {
       /*
        * Skip the line if it's a comment.
        */
       if( skip_line( linebuf ))
           continue;

       condition_line( newline, linebuf );

       token_str = strtok( newline, ":" );
       token_value = strtok( NULL, ":" );

       if( strcmp( token_str, TIMER_INTERVAL ) == 0 )
           set_timer_interval( cf, token_value );

       else if( strcmp( token_str, IDLE_INTERVAL ) == 0 )
           set_idle_interval( cf, token_value );

       else if( strcmp( token_str, SCHED_QUANTUM ) == 0 )
           set_sched_quantum( cf, token_value );

       else if( strcmp( token_str, SCHED_POLICY ) == 0 )
           set_sched_policy( cf, token_value );

       else if( strcmp( token_str, THREAD_PRIORITY ) == 0 )
           set_thread_priority( cf, token_value );

       else if( strcmp( token_str, STACK_SIZE ) == 0 )
           set_stack_size( cf, token_value );

       else
           continue;
   }
}
