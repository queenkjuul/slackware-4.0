/*
 * $Id: timer_q.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: timer_q.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "timer_q.h"

typedef struct TIMER_EVENT_QUEUE
{
    timer_event_t *first;
    timer_event_t *last;
    unsigned long elements;

} timer_queue_t;

/*
 * Linux defines a time_t to be a long.  Hence, the max time value
 * we can represent is LONG_MAX (see limits.h).
 */
static timer_event_t event = { NULL, NULL, NULL, LONG_MAX };
static timer_queue_t tq = { &event, &event, 1 };


/*
 * Search thru the timer queue for the first event containing the
 * handle of the target thread.  Unlink the event and returns its
 * pointer to the caller.
 */
timer_event_t *
yank_timer_event( const void *handle )
{
    timer_event_t *curr = NULL;

    curr = tq.first;
    while( curr->handle != handle && curr->next != NULL )
        curr = curr->next;
    
    if( curr->handle == handle )
    {
        if( curr == tq.first )
        {
            tq.first = curr->next;
            tq.first->prev = NULL;
            curr->next = NULL;
        }
        else
        {            
            curr->prev->next = curr->next;
            curr->next->prev = curr->prev;
            curr->next = curr->prev = NULL;
        }

        tq.elements -= 1;
    }

    return( curr );
}

static void
insert_b4_curr( timer_event_t *new, timer_event_t *curr )
{
    new->next = curr;
    new->prev = curr->prev;
    curr->prev->next = new;
    curr->prev = new;
    tq.elements += 1;
}

static void
insert_first_ev( timer_event_t *new )
{
    new->next = tq.first;
    tq.first->prev = new;
    tq.first = new;
    tq.elements += 1;
}

int 
insert_timer_event( timer_event_t *new )
{
    int status = 0;
    timer_event_t *curr = NULL;

    if( new->time < tq.first->time )
    {
        insert_first_ev( new );
        return(0);
    }

    curr = tq.first;
    while( new->time >= curr->time && curr->next != NULL )
        curr = curr->next;

    insert_b4_curr( new, curr );

    return( status );
}

timer_event_t *
remove_timer_event( void )
{
    timer_event_t *tev = NULL;

    if( tq.elements == 1 )
        return( tev );

    tev = tq.first;
    tq.first = tev->next;
    tq.first->prev = NULL;
    tev->next = NULL;

    tq.elements -= 1;

    return( tev );
}

time_t
check_expiration_time( void )
{
    return( tq.first->time );
}

#ifdef _TEST_MAIN_

void
dump_tq_list( void )
{
    timer_event_t *curr;

    curr = tq.first;

    while( curr->next != NULL )
    {
        printf("%ld ", curr->time ); fflush( NULL );
        curr = curr->next;
    }

    printf("%ld\n", curr->time );
}

timer_event_t *
init_tev( time_t time )
{
    timer_event_t *tev;

    tev = malloc( sizeof( timer_event_t ));
    tev->next = NULL;
    tev->prev = NULL;
    tev->handle = malloc( sizeof( void * ));
    tev->time = time;

    return( tev );
}

void
clear_tev( timer_event_t *tev )
{
    free( tev->handle );
    free( tev );
}

#define EVENTS (58)
static timer_event_t *ev[EVENTS];
    
int
main(int argc, char *argv[] )
{
    int i;
    timer_event_t *tev = NULL;
    time_t curr_time, tmp_time;

    /*
     * Initialize a bunch of events and insert them into the
     * timer queue.
     */
    for(i = 0; i < EVENTS; i++ )
    {
        ev[i] = init_tev( rand() % 99 );        
        insert_timer_event( ev[i] );
    }

    /*
     * Randomly yank the events from the timer queue until the events
     * are exhausted.
     */
    while( tq.elements > 1 )
    {
        i = rand() % EVENTS;
        (void) yank_timer_event( ev[i]->handle );
    }

    /*
     * Reinsert the events back into the timer queue.
     */
    for(i = 0; i < EVENTS; i++ )
        insert_timer_event( ev[i] );



    while( tq.elements > 1 )
    {
        curr_time = rand() % 99;
        if( curr_time <= (tmp_time = check_expiration_time()) )
        {
            tev = remove_timer_event();
            printf("%ld ", tev->time ); fflush(NULL);
        }
    }

    printf("\n");                

    return(0);
}

#endif
