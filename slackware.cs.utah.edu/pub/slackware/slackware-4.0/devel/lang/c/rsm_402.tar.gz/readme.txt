Resource Standard Metrics
Version 4.02
-----------------------------------------------------------------

New features for Version 4.0
-----------------------------

- HTML reports with file hyperlinks
- Expanded Function Complexity metrics
- Added Function interface complexity
- Expanded Class metrics
- Estimation Analysis for project estimation
- Enhance metrics differentials between baselines
- Added the file rsm.cfg for configurable parameters
- Added the file rsm.lic as a license file
- Reports re-formatted for ease of reading

Special Notation for RSM_NT
---------------------------

The exectuable RSM_NT requires that you use UNIX type
paths.  For example: rsm_nt -fc c:/src/*.c

Play special attention to the upper and lower case
of each source file.  RSM is case sensitive and
Windows 95 and Windows NT are not.

The following files appear in all distributions.
------------------------------------------------

  readme.txt    - This file you are reading.

  rsm.lic       - RSM license file

  rsm.cfg       - RSM configuration file

  rsm.txt       - Online documentation.
                  For more complete documentation see out web site.
                  http://www.tqnet.com/m2tech

  rsmfaq.txt    - RSM Frequently Asked Questions.

  rsmorder.txt  - Order form for RSM purchases.

  rsmtest.c     - Test file for trying RSM.

  license.txt   - Your software license agreement.

  The following executable files are available based on the 
  operating system.

  DOS/Windows95  rsm_95.exe    "RSM 32 bit Executable"
                 cwsdpmi.exe   "32 bit extender for DOS"

  Windows NT     rsm_nt.exe    "RSM Windows Shell Executable"
                 cygwinb19.dll "Gnu-Win32 Shared Library"

  UNIX w/src     rsm.lnx       "Binary for Linux 2.0+"
                 rsm.sol       "Binary for Solaris 2.5+"
                 rsm.hp        "Binary for HPUX 10.10+"
                 rsm.aix       "Binary for IBM AIX 2.6+"
                 rsm.c         "Non-editable source code"
                 compile.txt   "Recompilation instructions"
                 

Installation Short Cut
----------------------

1) Make a directory rsm
2) Copy the files from the floppy to the rsm directory
3) place the rsm directory in your path.

DOS/Windows/NT

  1) mkdir c:\rsm
  2) copy a:\*.* c:\rsm
  3) edit autoexec.bat and add c:\rsm to the path
     
Unix

  1)  mkdir /usr/rsm
  2)  tar -xvf /dev/fd0 /usr/rsm
  3)  add /usr/rsm to the path


Contact Information
-------------------

  Email   - m2tech@tqnet.com
  Web     - http://www.tqnet.com/m2tech
  Ph/Fax  - 1-407-880-2627
  Address - 2128 Hidden Pine Lane
            Apopka, FL 32712 USA

            M Squared Technologies
            (C) 1986-1998
