#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#ifndef MAXPATHLEN
#define MAXPATHLEN 255
#endif
#define VERSION "1.0"
FILE * InPutFile = NULL;
FILE * OutPutFile = NULL;
void
ShowSyntax ( char * program )
{
printf (
"\nRSM DOS to Unix Source\n"
"Version %s\n"
"(C) 1997 M Squared Technologies\n\n"
"Syntax: %s <Source File> <Output File>\n\n",
VERSION, program );
}
int
main ( int argc , char ** argv ) 
{
int i = 0;
char filein  [MAXPATHLEN];
char fileout [MAXPATHLEN];
char linein  [MAXPATHLEN];
if ( argc < 2 )
{
ShowSyntax( argv[0] );
return(1);
}
if ( argc >= 2 )
{
strcpy ( filein, argv[1] );
}
if ( argc > 2 )
{
strcpy ( fileout, argv[2] );
}
else
{
strcpy ( fileout, "tmp.tmp" );
}
if ( !strcmp ( fileout, filein ) )
{
printf ( "Error: Input File Cannot = Ouput File\n" );
return(1);
}
InPutFile = fopen ( filein, "r" );
if ( !InPutFile )
{
fprintf ( stderr, "Cannot open the specified file: %s\n", filein );
return (-1);
}
OutPutFile = fopen ( fileout, "w" );
if ( !OutPutFile )
{
fprintf ( stderr, "Cannot open the specified file: %s\n", fileout );
return (-1);
}
for (;;)
{
fgets (linein, sizeof(linein), InPutFile);
if ( feof( InPutFile ) )
{
break;
}
for ( i=0; i<strlen(linein); i++ )
{
if ( linein[i] != (char)13 )
{
fputc ( linein[i], OutPutFile );
}
}
}
fclose ( InPutFile );
fclose ( OutPutFile );
return (1);
}












