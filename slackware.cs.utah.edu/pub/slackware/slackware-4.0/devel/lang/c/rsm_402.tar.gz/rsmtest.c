/* functions using pointers to functions */

#include <stdlib.h> /*standard includes*/
#include <stdio.h>  // more includes

typedef int (*functionType)(int);

typedef struct{intx;inty;}fooType;

struct mystruct{floatx;char name[21];};

void prototypedec(void);

void prototypedec2(void)  ;  

/* See if we are supposed to check a neighbor */
#define IFNBR(nvl,msk,wnb) ((nvl)&(msk)&nbr_##wnb)

/* Expression for OR neighborhood check */
#define OR_CHECK(nbr, msk) \
  if (ISNBR(*in2,center,not_center) && \
      ((IFNBR(nbr,msk,LEFT) && ISNBR(in2[-1],neighbor,not_nbr)) || \
       (IFNBR(nbr,msk,RIGHT) && ISNBR(in2[+1],neighbor,not_nbr)) || \
       (IFNBR(nbr,msk,UPCENTER) && ISNBR(in1[0],neighbor,not_nbr)) || \
       (IFNBR(nbr,msk,DNCENTER) && ISNBR(in3[0],neighbor,not_nbr)) || \
       (IFNBR(nbr,msk,UPLEFT) && ISNBR(in1[-1],neighbor,not_nbr)) || \
       (IFNBR(nbr,msk,UPRIGHT) && ISNBR(in1[+1],neighbor,not_nbr)) || \
       (IFNBR(nbr,msk,DNLEFT) && ISNBR(in3[-1],neighbor,not_nbr)) || \
       (IFNBR(nbr,msk,DNRIGHT) && ISNBR(in3[+1],neighbor,not_nbr)) \
       )) *dst++ = new_value; else *dst++ = *in2;

/* functions that do stuff */
int funcA 
( 
  int input 
)
{
  printf ( "funcA: %d\n", input );
  return (1);
}

int funcB ( int input )
{
  printf ( "funcB: %d\n", input );
  return (1);
}

int funcC ( int input )
{
  printf ( "funcC: %d\n", input );
  return (1);
}

/* functions receiving pts to functions */
int
func_pass_func1 ( functionType F, int input )
{
  /* call the pass function */
  return F(input);
}

int 
func_pass_func2 (  int(*F)(int), int input )
{
  /* call the pass function */
  return F(input);
}


/* functions returning funtions */
/* method 1 */
functionType
which_func1 ( char input )
{
  switch ( input )
  {
    case 'A':
    case 'a':
    {
      return ( funcA );
    }
    break;     
    case 'B':
    case 'b':
    {
      return ( funcB );
    }
    break;     
    case 'C':
    case 'c':
    {
      return ( funcC );
    }
    break;
  }
  return ( funcA );
}               

/* method 2 */
int (*which_func2( char input ))(int)
{
  switch ( input )
  {
    case 'A':
    case 'a':
    {
      return ( funcA );
    }
    break;     
    case 'B':
    case 'b':
    {
      return ( funcB );
    }
    break;     
    case 'C':
    case 'c':
    {
      return ( funcC );
    }
    break;

    default:
    {
      printf ( "Unsupported func%c\n"
               "Executing funcB\n", input );
    }
    break;
  }
  return ( funcB );
}                 

/* this yields a problem for the nonansi prototype */
void notansi(x)int x;{
x=7;
if(x=10){return;}
while(x=100){x=++x;x=--x;}
}

/* this yields a problem for the nonansi prototype */
void notansi2(x)
int x;{
x=7;
if(x==10){return;}
while(x==100){x=x++;x=x--;realloc(x);goto fred;}
}

int varfunc(...);

int varfuncwithreallylongnameexceeding32(...){
char name[10;
name[0]='\0');
return;}

class foo
{
  int x;
  void show();
  public:
    foo();
};

class foo2{
friend foo;
};

class foo3:foo2{};

/* really long line ...............................................................*/

int
test_keyword_scope ()
{
  for ( int i=0; i<10; i++ ){ }

  for ( int i=0; i<10; i++ ){
  }

  for ( int i=0; i<10; i++ )
    printf ( "Hello\n" );
  
  for ( int i=0; i<10; i++ )
  { 

  }

  for(i=1; i<10; 1++)x=10;

  if ( i < 10 ) printf ( "Hello\n" );

  if(ewtk;ewktkew
;wekt;wlet;kewt
w;ekt;wet;kwet
weltkwtk;wket) i++;

  if(  )
    if(  )
      for ( )
        while()
           i++;

  if(x<10)
  /* test for the next line
   and nextline */
  {
    ;;
  }

  do
  {
    ;;
  } while ( i<10 )  ;


}


int
main ( void )
{
  func_pass_func1 ( funcA, 99 );
  func_pass_func2 ( funcB, 11 );
  (which_func1('B'))( 44 );
  (which_func2('C'))( 133 );
  (which_func1('F'))( -1 );

  y=(char*)malloc(sizeof(int));

  if(y=(void*)test(x)
    && y<10 )
    /* test foo */
  { printf "test\n" };

  return (1);
}

class foo4{class foo5{};};

class foo5
{
  class foo6{
  };
}

class Circle : public Baseobj
{
  private:
    double radius;
  public:
    Circle();
    Circle(char name[], double xor, double yor, double rad);
    virtual void show( void ){ cout << "hello\n"; }
    virtual void draw( void );
    virtual void edit( void );
    virtual ~Circle();
};

Circle::Circle() : Baseobj("Circle","   ",0,0)
{
  radius = 1.00;
  edit();
}

//////////////////////////////////////////////////////////
Circle::Circle(char name[], double xor, double yor,
        double rad) : Baseobj("Circle", name, xor, yor)
{
  radius = rad;
}

/* example output

funcA: 99
funcB: 11
funcB: 44
funcC: 133
Unsupported funcF
Executing funcA
funcA: -1

*/

int Recursive_Function ( int x )
{
  int y = x;
  Recursive_Function(y);
  Recursive_Function1();
  myRecursive_Function();
  return (y);
}
