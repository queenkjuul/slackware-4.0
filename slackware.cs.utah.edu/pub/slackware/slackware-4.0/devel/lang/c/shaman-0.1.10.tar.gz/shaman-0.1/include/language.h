/* $Id$ */
#ifndef _LANGUAGE_H_
#define _LANGUAGE_H_

/*
 * This should be an interface that would connect Shaman to
 * an arbitrary language interpreter.
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdarg.h>

#include "alib.h"
#include "misc.h"

/* A loaded program.
 * Every implementation will have its own handle type.
 */
typedef any_t prog_t;

/* A function inside a loaded program.
 * Again, every implementation will convert this type to whatever it needs
 */
typedef any_t fun_t;

#define LANG_NO_FUN ((fun_t)0)

/*
 * An interpreter object.
 * Every interpreter defines its own type.
 */
typedef any_t ldata_t;

/* Functions that constitute a language driver */

/* Loads a  program text into an internal representation 
 * of the interpreter.
 * The program text is in a file, referenced by name.
 * After the program is loaded, the file is no longer needed.
 */
typedef prog_t  (*l_load_file_fun_t) (const char *fname);

/* Loads a  program text into an internal representation 
 * of the interpreter.
 * The program text is in a memory area.
 * After the program is loaded, the text is no longer needed.
 */
typedef prog_t  (*l_load_mem_fun_t) (const void* addr, uslong len);

/* Declares program unnecessary. Whether to free the space immediately
 * is left for the interpreter to decide
 */
typedef void (*l_discard_fun_t) (prog_t prog);

/* Finds a function inside the program given in the internal representation.
 * Returns LANG_NO_FUN if not found.
 */
typedef fun_t (*l_get_fun_fun_t) (prog_t prog, const char * fun_name);

/* Releases the function handle
 */
typedef void (*l_release_fun_fun_t) (fun_t fun);


/* Executes a function inside the program given in the internal representation 
 * Rest is the result type, Argt - 0 terminated array of argument types
 */
typedef any_t (*l_eval_fun_t) ( fun_t fun,
				sh_type rest, 
				sh_type argt[], va_list argv);

/* Checks if a text is a program in the language 
 * The text is in a memory area.
 */
typedef bool (*l_recog_fun_t) (const void *text, uslong len);

/* !!! in fact we should have a description that would allow us to 
 * analyze the expression structure.
 *      -- Goga
 */
typedef void * expr_t; 

/* Converts the interpreter-specific form of an expression to something
 * language independent.
 * (mostly for the query analyzer's sake)
 */
typedef expr_t (*l_make_expr_fun_t) (void* arg);

/* Converts a C object to an internal object of the interpreter */
typedef ldata_t (*l_transl_to_fun_t) (any_t cobj, enum sh_type tp);

/* Converts an interpreter object into a C object,
 * tp == 0 means the interpreter should guess itself.
 */
typedef any_t (*l_transl_from_fun_t) (ldata_t lobj, enum sh_type tp);

/* Declares that the interpreter object is locked
 * by the controlling program.
 */
typedef void (*l_lock_fun_t) (ldata_t lobj);

/* Declares that the interpreter object is no longer locked
 * by the controlling program.
 */
typedef void (*l_unlock_fun_t) (ldata_t lobj);

#define LANG_MAGIC 0x13000000

typedef struct _lang
{
  char * name; /* Interpreter name */
  l_load_file_fun_t load_file;
  l_load_mem_fun_t load_mem;
  l_recog_fun_t recog;
  l_discard_fun_t discard;
  l_get_fun_fun_t get_fun;
  l_release_fun_fun_t release_fun;
  l_eval_fun_t eval;
  l_make_expr_fun_t make_expr;
  l_transl_to_fun_t t_to;
  l_transl_from_fun_t t_from;
  l_lock_fun_t lock;
  l_unlock_fun_t unlock;
  uslong magic; /* For testing */
} Lang;

/* These are real functions: may check which of the parallel functions exists */
prog_t lang_load_file (Lang *ll, const char *fname);
prog_t lang_load_mem  (Lang *ll, const void *mem, uslong len);

/* Shortcuts */
#define lang_name(ll)			((ll)->name)
#define lang_get_fun(ll, prog, fun_name) ((ll)->get_fun (prog, fun_name))
#define lang_release_fun(ll, fun) ((ll)->release_fun (fun))
#define lang_evalv(ll, fun, rest, argt, argv) \
                   ((ll)->eval) (fun, rest, argt, argv)
#define lang_discard(ll, prog) 		((ll)->discard) (prog)
#define lang_recog(ll, text, len) 	((ll)->recog) (text, len)
#define lang_make_expr(ll, arg) 	((ll)->make_expr) (arg)
#define lang_to(ll, cobj, tp) 		((ll)->t_to) (cobj, tp)
#define lang_from(ll, lobj, tp)		((ll)->t_from) (lobj, tp)
#define lang_lock(ll, lobj)		((ll)->lock) (lobj)
#define lang_unlock(ll, lobj)		((ll)->unlock) (lobj)

/* Call a function by name */
any_t lang_evalv_by_name (Lang *lang, prog_t prog, const char *fun_name,
			  sh_type rest, sh_type *argt, va_list arg);

/* Register an interpreter with the system 
 * Throws an error if it fails.
 */
void lang_register (Lang *ll);

/* The number of interpreters registered */
extern unsigned lang_num_regd;

/* I-th registered interpreter (no internal checks) */
Lang *lang_regd (int i);

/* Get the interpreter by name (NULL if not found) */
Lang *lang_get_interpreter_by_name (const char *name);

/* Convert the next argument in Arg into language reresentation */
ldata_t lang_to_va_list (Lang * ll, sh_type type, va_list *arg);

/* What language is the file written in? */
Lang *lang_examine_file (const char *fname);

/* What language is the memory area written in? */
Lang *lang_examine_mem (const void *mem, uslong len);

/* Initialize the package; registers inerpreter Native */
void lang_init ( void );

/***********************************************************************/
/* From now on come purely informational functions that are
 * used primarily in Nana checks.
 * They are not needed for normal programming. Some are stubs, intended
 * to be read by a human, not even by a checking tool.
 *        -- Goga.
 */

/* Is a Language structure initialized properly? */
#define lang_inited(ll) ((ll)->magic == LANG_MAGIC)

/* Is a Prog_t handle alright? */
#define prog_t_alright(pp) TRUE


#endif /*already included */
