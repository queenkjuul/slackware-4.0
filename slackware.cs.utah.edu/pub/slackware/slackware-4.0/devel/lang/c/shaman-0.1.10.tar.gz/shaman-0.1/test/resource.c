/* $Id$ */
/* This file is to test the Resource package */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "alib.h"
#include "uls.h"
#include "message.h"
#include "resource.h"
#include "printfn.h"

#define TH_TEST 101


/* Debugging output for rs_h creation/deletion */
static uslong
say_on ( void )
{
  static uslong c = 1;
  message (TH_TEST, 0, "Rs_on called %ld-th time", c++);
  return c-1;
}

static void
say_off (uslong c)
{
  message (TH_TEST, 0, "Rs_off called for %ld-th rs_h", c);
}

/* Set up all the used packages properly */
static void
initialize ( void )
{
  alib_init ();
  uls_init (getenv ("SHAMAN_MESSAGES"));
  message_init (printfn, NULL);

  /* It is possible to do this before resource_init ! */
  r_attach (say_on, say_off);
  resource_init ();
}

/* A test resource type */

typedef struct _rr
{
  Resource r;
  int val;
} Rr;

static void rr_done (Rr *rr);

static void
rr_init (Rr *rr, int val, Rs_h *rsh)
{
  r_register (& rr->r, rsh, (rs_dt_fun_t) rr_done);
  rr->val = val;
  message (TH_TEST, 0, "Rr registered with value %d", rr->val);
}

static void
rr_done (Rr *rr)
{
  message (TH_TEST, 0, "Rr unregistered with value %d", rr->val);
  r_unregister (&rr->r);
}


/* A routine that will fail several times */
static void
fun ( void )
{
  static int cou = 50;
  char * p;
  Rr rr;
  Jump_h jh;

  message (TH_TEST, 0, "Entered Fun");
  jh_init_set_c (&jh);
  jh_allow (&jh, TH_TEST, FALSE);

  p = rxmalloc_c (100);
  rr_init (&rr, 5, rsh_current ());

  p = rxrealloc (p, 200);
  memset( p, 0, 200 );

  if (--cou)
    error (TH_TEST, "Calling Error from Fun; %d times left", cou);

  rr_done (&rr);
  jh_done (&jh);
  message (TH_TEST, 0, "Successful exit from Fun");
}

#if 0
static void
dump( char * name, void * p, int len )
{ int fh = file_create( name );
 file_write( fh, p, len );
 file_close( fh );
}
#endif

int
main ( void )
{
  Jump_h jh;
  Rr *rrp;
  initialize ();
  message (TH_TEST, 0, "The test program started");

  jh_init_set_c (&jh);

  message (TH_TEST, 0, "Registered the main Jump_h, going to make an Rr");

  rrp = rxmalloc_c (sizeof (Rr));
  rr_init (rrp, 10, rsh_current ());
  message (TH_TEST, 0, "Rr made, calling Fun");

  /* Will fail several times */
  fun ();

  message (TH_TEST, 0, "Fun returned successfully, killing Rr");

  rr_done (rrp);
  rfree (rrp);

  jh_done (&jh);

  message (TH_TEST, 0, "Main Jump_h deleted, test program finishing");
  return 0;
}
