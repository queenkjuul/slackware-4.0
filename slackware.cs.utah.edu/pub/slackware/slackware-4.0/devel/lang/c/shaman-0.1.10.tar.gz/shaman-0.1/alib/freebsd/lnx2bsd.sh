#
# This script was used to initiate work on FreeBSD port
# I think, it's a model of hwo to generate *platform* from *generic*
#
# *generic* should be special directory wich contain well-comented templates
# of *foot*. script port2 <platform> will create platform subdirecory
# with appropriate changes in files

SED=/usr/bin/sed
EDIT="$SED -e s/linux/freebsd/g -e s/Linux/FreeBSD/g"
# create Makefile
cat makefile.lnx | $EDIT > Makefile.freebsd
# create copies of files
cp -r ./linux ./freebsd
# edit files
for f in ./freebsd/*
do
    cp $f tmp_file
    cat tmp_file | $EDIT > $f
    rm tmp_file
done

