/* $Id: iter.h 1.3 Sat, 12 Jul 1997 17:05:06 +0400 goga $ */

#ifndef _ITER_H_
#define _ITER_H_

/* General iterators protocol.
 * Abstract type specification -- but all the real iterator types are
 * going to be different
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdarg.h>

#include "alib.h"

/* Movement direction */
typedef enum dir {DIR_FORW = 1, DIR_BACK = -1} e_dir;

typedef struct iter_op* Iter;

/* Iterator operations */
/* !!! Every iterator implementation should contain iter_op
 * in the beginning of the iterator structure !!!
 */
typedef struct iter_op
{
/* Makes an iterator step, in direction D, possibly with parameters */
  any_t (*step) (Iter *it, e_dir d, va_list arg);

/* Retrieves the current iterator position */
  any_t (*get_pos) (Iter* it);

/* Restores the iterator position. Pos should have been obtained by
 * Get_pos. The way it is coded does not matter for the user.
 */
  void  (*set_pos) (Iter* it, any_t pos);

/* Destroys an iterator. Does not issue Free to its structure */
  void (*destroy) (Iter *it);
} iter_op;

/* Easy interface to iterators */
any_t it_step (Iter *it, e_dir d, ...);
any_t it_get_pos (Iter *it);
void  it_set_pos (Iter *it, uslong pos);
void  it_destroy (Iter *it);



#define it_destroy_free (it) (it_destroy (it), free (it))

#endif /* already included */
