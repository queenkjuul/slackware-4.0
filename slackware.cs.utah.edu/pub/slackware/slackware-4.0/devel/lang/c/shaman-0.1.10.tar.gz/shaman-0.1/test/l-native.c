/* $Id$ */

/* A simple test for native language subpackage */
/* Written by Goga 20.05.97 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "resource.h"
#include "dl_h.h"
#include "language.h"
#include "printfn.h"

#define TH_TEST 101

/* Set up all the used packages properly */
static void
initialize ( void )
{
  alib_init ();
  uls_init (getenv ("SHAMAN_MESSAGES"));
  message_init (printfn, NULL);

  resource_init ();
  dl_h_init ();
  lang_init ();
}

/* This is used to call a function in the interpereter */
sh_type atarr[] = {SHT_STRING, 0};

static int
call_function (Lang *ll, prog_t lh, ...)
{
  va_list arg;
  int res;

  va_start (arg, lh);
  res = (int) lang_evalv_by_name (ll, lh, "test", SHT_INT, atarr, arg);
  va_end (arg);

  return res;
}

int
main ( void )
{
  Jump_h jh;
  Lang *native;
  char *fnames[] = {"f-native.dll", "f-native.c", NULL};
  char **ff;

  initialize ();
  jh_init_set_c (&jh);
  if (jh_theme (&jh))
    {
      message (TH_TEST, 0, "Error caught");
      jh_done( & jh );
      exit (1);
    }

  message (TH_TEST, 0, "Started");

  native = lang_get_interpreter_by_name ("Native");

  message (TH_TEST, 0, "Got interpreter: %s", native->name);

  for (ff = fnames; *ff; ff++)
    {
      int fh;
      char *mem;
      uslong len;
      bool rec;

      message (TH_TEST, 0, "Trying to recognize %s", *ff);

      fh = file_open (*ff, AL_READ);
      len = file_size_by_handle (fh);
      mem = file_map (fh, NULL);
      rec = lang_recog (native, mem, len);
      file_unmap (mem);
      file_close (fh);

      message (TH_TEST, 0, "Recognize function returned %d", rec);

      if (rec) /* Recognized successfully */
	{
	  prog_t lh;
	  int res;

	  message (TH_TEST, 0, "Trying to load by filename");

	  lh = lang_load_file (native, *ff);

	  message (TH_TEST, 0, "Lang_load_file returned");

	  res = call_function (native, lh, "Test");

	  message (TH_TEST, 0, "Test function returned %d", res);

	  lang_discard (native, lh);

	  message (TH_TEST, 0, "Discarded the program");

	  message (TH_TEST, 0, "Trying to load by memory address");

	  fh = file_open (*ff, AL_READ);
	  len = file_size_by_handle (fh);
	  mem = file_map (fh, NULL);

	  if (!mem)
	    error (TH_TEST, "Cannot open file mapping for %s", *ff);

	  message (TH_TEST, 0, "File mapping opened");

	  lh = lang_load_mem (native, mem, len);

	  message (TH_TEST, 0, "Lang_load_mem returned");

	  res = call_function (native, lh, "Test");

	  message (TH_TEST, 0, "Test function returned %d", res);

	  lang_discard (native, lh);

	  message (TH_TEST, 0, "Discarded the program");

	}
    }

  jh_done (&jh);

  message (TH_TEST, 0, "Exiting");

  return 0;
}
