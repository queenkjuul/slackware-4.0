#include <stdlib.h>

#include "amsg.h"

void
verror( char * fmt, va_list args )
{
 tvmessage( AL_ERROR, fmt, args );
 exit( 0 );
}

void
error( char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 verror( fmt, args );
 va_end( args );
}
