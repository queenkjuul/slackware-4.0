/* $Id$ */
/*
 * A test for Cache package.
 * Started by Goga 17.07.97 23:40
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "alib.h"
#include "resource.h"
#include "cache.h"
#include "printfn.h"

#define TH_TEST 101

/* Set up all the used packages properly */
static void
initialize ( void )
{
  alib_init ();
  uls_init (getenv ("SHAMAN_MESSAGES"));
  message_init (printfn, NULL);

  resource_init ();
}

/* Test cache  functions */
typedef struct _tc_entry
{
  Cache_entry ce;
  int t;
} Tc_entry;

static Cache_entry *
tc_form (any_t key)
{
  Tc_entry *tc;

  message (TH_TEST, 0, "Creating an entry with key %d", (int)key);
  tc = xmalloc (sizeof (Tc_entry));
  tc->t = (int) key;

  return (Cache_entry*) tc;
}

static void
tc_delete (Cache_entry *ce)
{
  Tc_entry *tc = (Tc_entry *)ce;

  message (TH_TEST, 0, "Deleting an entry with key %d", tc->t);
  xfree (tc);
}

static bool
tc_match (Cache_entry *ce, any_t key)
{
  Tc_entry *tc = (Tc_entry *)ce;
  int t = (int) key;

  return tc->t == t;
}

static unsigned
tc_hash (any_t key, unsigned hash_size)
{
  return (unsigned)key % hash_size;
}

struct _cache_procs tc_procs =
{
  tc_form,
  tc_delete,
  tc_match,
  tc_hash
};



int
main ( void )
{
  Jump_h jh;
  Cache cache;
  int i;
  int arr [] = { 1,  2,  3,  4,  5,
                 6,  7,  8,  9, 10,
		11, 12, 13, 14, 15,
		16, 17, 18, 19, 20,
		 3,  7, 12, 15, 19,
		21, 22, 23, 24, 25,
		 1,  3,  8, 12, 18,
		 0
               };


  initialize ();
  jh_init_set_c (&jh);
  if (jh_theme (&jh))
    {
      message (TH_TEST, 0, "Error caught");
      jh_done( & jh );
      exit (1);
    }

  message (TH_TEST, 0, "Started");

  cache_init (&cache, &tc_procs, 20, 20);

  for (i = 0; arr[i] != 0; i++)
    {
      Tc_entry *tc;

      message (TH_TEST, 0, "Going to get a cache entry with key %d", arr[i]);
      tc = (Tc_entry *) cache_lookup (&cache, arr[i]);
      message (TH_TEST, 0, "Got entry with key %d", tc->t);
      cache_entry_unlock (&cache, (Cache_entry*) tc);
    }

  message (TH_TEST, 0, "Finished");

  jh_done (&jh);

  message (TH_TEST, 0, "Exiting");

  return 0;
}
