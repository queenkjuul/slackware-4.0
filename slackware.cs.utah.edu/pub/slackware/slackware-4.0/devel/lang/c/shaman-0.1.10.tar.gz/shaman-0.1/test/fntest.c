#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include "alib.h"

static void
error( char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 vfprintf( stderr, fmt, args );
 va_end( args );
 exit( 0 );
}

static char path[ AL_MAXFULL + 1 ], 
            name[ AL_MAXNAME + 1 ], 
            ext[ AL_MAXEXT + 1 ],
            newext[ AL_MAXFULL + 1 ],
            full[ AL_MAXFULL + 1 ],
            suffix[] = ".new";

int
main( int argc, char * argv[] )
{ char * p;
 if( argc != 2 )
  error( "Usage : fntest <fname>\n" );
 alib_init();
 printf( "Testing '%s'\n", argv[ 1 ] );
 fn_split( argv[ 1 ], path, name, ext );
 printf( "Path '%s'\nName '%s'\nSuffix '%s'\n", path, name, ext );
 printf( "Basedir '%s'\n", fn_basedir( NULL, argv[ 1 ] ) );
 printf( "Basename '%s'\n", fn_basename( NULL, argv[ 1 ] ) );
 printf( "Name only '%s'\n", fn_getname( NULL, argv[ 1 ] ) );
 printf( "Suffix only '%s'\n", fn_getext( NULL, argv[ 1 ] ) );
 printf( "Changing suffix to '%s' : '%s'\n", suffix, 
         fn_chext( newext, argv[ 1 ], suffix ) );
 p = getenv( "PATH" );
 printf( "Applying PATH (%s): '%s'\n", p, fn_apply_path( argv[ 1 ], p ) ); 
 printf( "Full name '%s'\n", fn_fullname( full, argv[ 1 ] ) );
 return 0;
}
