#include <string.h>
#include <windows.h>
#include "___file.h"

#define AF_MAXMAP 1024

typedef struct
{
 void * base;
 int len;
 int fh;
 HANDLE mh;
} mtab_t;

static mtab_t mtab[ AF_MAXMAP ];

#define AF_MAXFILE 1024
#define AF_CLOSED 0
#define AF_READ   1
#define AF_RDWR   2

typedef struct
{
 HANDLE fh;
 int open_flags;
} htab_t;

static htab_t htab[ AF_MAXFILE ];

static void
init_handle( int fh, DWORD name, int flags )
{ HANDLE h = GetStdHandle( name );
 /* We must prevent standard handles from being used as ordinary files
    even if we do not have standard streams */
 htab[ fh ].open_flags = flags;

 if( h == INVALID_HANDLE_VALUE )
  return;
 htab[ fh ].fh = h;
}

void
___file_init( void )
{
 init_handle( 0, STD_INPUT_HANDLE, AL_READ );
 init_handle( 1, STD_OUTPUT_HANDLE, AL_RDWR );
 init_handle( 2, STD_ERROR_HANDLE, AL_RDWR );
}

static int
find_free_handle( void )
{ register int i;
 for( i = 0; i < AF_MAXFILE; i++ )
  if( htab[ i ].open_flags == AF_CLOSED )
   return i;
 return -1;
}

static int
fill_handle( int ix, HANDLE fh, int open_flags )
{
 if( fh == INVALID_HANDLE_VALUE )
  return -1;
 htab[ ix ].fh = fh;
 htab[ ix ].open_flags = open_flags;
 return ix;
}

int
file_open( const char * name, int rdwr )
{ int res;
 HANDLE fh;
 mutex_lock( ___file_mutex );
 if( ( res = find_free_handle() ) == -1 )
  goto FOUT;
 fh = CreateFile( name, ( rdwr == AL_RDWR ? (GENERIC_READ|GENERIC_WRITE)
                                          : GENERIC_READ ),
                  FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING,
                  FILE_ATTRIBUTE_NORMAL, NULL );
 res = fill_handle( res, fh, rdwr == AL_RDWR ? AF_RDWR : AF_READ );
FOUT :
 mutex_unlock( ___file_mutex );
 return res;
}

static int
time_is_null( FILETIME * ft )
{
 return ft->dwHighDateTime == 0 && ft->dwLowDateTime == 0;
}

int
file_create( const char * name )
{ int res;
 HANDLE fh;
 mutex_lock( ___file_mutex );
 if( ( res = find_free_handle() ) == -1 )
  goto FOUT;
 fh = CreateFile( name, GENERIC_READ | GENERIC_WRITE,
                  FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
                  CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
 res = fill_handle( res, fh, AF_RDWR );
FOUT :
 mutex_unlock( ___file_mutex );
 return res;
}

int
file_close( int fh )
{ int res;
 mutex_lock( ___file_mutex );
 if( htab[ fh ].open_flags == AF_CLOSED )
  goto FOUT;
 htab[ fh ].open_flags = AF_CLOSED;
 res = CloseHandle( htab[ fh ].fh ) ? 0 : -1;
FOUT :
 mutex_unlock( ___file_mutex );
 return res;
}

int
file_read( int fh, void * to, int len )
{
 DWORD bytes_read;
 return ReadFile( htab[ fh ].fh, to, len, & bytes_read, NULL )
        ? bytes_read : -1;
}

int
file_write( int fh, const void * from, int len )
{
 DWORD bytes_written;
 return WriteFile( htab[ fh ].fh, from, len, & bytes_written, NULL )
        ? bytes_written : -1;
}

long
file_seek( int fh, long offset, int mode )
{
 return SetFilePointer( htab[ fh ].fh, offset, NULL,
                        mode == AL_BEGIN ? FILE_BEGIN
                        : mode == AL_CUR ? FILE_CURRENT
                        : FILE_END );
}

int
file_chsize( int fh, long len )
{
 if( SetFilePointer( htab[ fh ].fh, len, NULL, FILE_BEGIN ) == ( DWORD )-1
     || ! SetEndOfFile( htab[ fh ].fh ) )
  return -1;
 return 0;
}

int
file_delete( const char * name )
{
 return DeleteFile( name ) ? 0 : -1;
}

int
file_rename( const char * from, const char * to )
{
 return MoveFile( from, to ) ? 0 : -1;
}

static packtime_t
get_date_and_time( FILETIME * dt )
{ FILETIME local;
 SYSTEMTIME sys;
 atime_t time;
 packtime_t res = AL_NEVER;
 int otz = time_gettimezone();
 if( time_is_null( dt )
     || ! FileTimeToLocalFileTime( dt, & local )
     || ! FileTimeToSystemTime( & local, & sys ) )
  return res;
 time_settimezone( AL_LOCAL_TZ );
 time.year = sys.wYear;
 time.month = sys.wMonth;
 time.day = sys.wDay;
 time.hour = sys.wHour;
 time.min = sys.wMinute;
 time.sec = sys.wSecond;
 time.msec = sys.wMilliseconds;
 if( time_valid( & time ) )  
  res = time_pack( & time );
 time_settimezone( otz );
 return res;
}

int
file_stat_by_handle( int fh, stat_t * st )
{ int res = -1;
 BY_HANDLE_FILE_INFORMATION info;
 mutex_lock( ___file_mutex );
 if( htab[ fh ].open_flags == AF_CLOSED
     || GetFileInformationByHandle( htab[ fh ].fh, & info ) == 0 )
  goto FOUT;
 st->size = info.nFileSizeLow;
 if( ( info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) != 0 )
  st->type = AL_DIR;
 else
  st->type = AL_REG;
 st->c_time = get_date_and_time( & info.ftCreationTime );
 st->m_time = get_date_and_time( & info.ftLastWriteTime );
 st->a_time = get_date_and_time( & info.ftLastAccessTime );
 res = 0;
FOUT :
 mutex_unlock( ___file_mutex );
 return res;
}

void *
file_map( int fh, void * addr )
{ register int i;
 int len;
 mtab_t * m;
 void * map;
 HANDLE mh;
 void * res = NULL;
 mutex_lock( ___file_mutex );
 for( i = 0; i < AF_MAXMAP; i++ )
  if( mtab[ i ].base == NULL )
   break;
 if( i >= AF_MAXMAP )
  goto FOUT;
 len = file_size_by_handle( fh );
 m = mtab + i;
 if( htab[ fh ].open_flags == AF_CLOSED )
  goto FOUT;
 mh = CreateFileMapping( htab[ fh ].fh, NULL,
                         htab[ fh ].open_flags == AF_RDWR
                                   ? PAGE_READWRITE : PAGE_READONLY,
                         0, len, NULL );
 if( mh == NULL )
  goto FOUT;
 map = MapViewOfFileEx( mh, htab[ fh ].open_flags == AF_RDWR
                            ? FILE_MAP_WRITE : FILE_MAP_READ,
                        0, 0, len, addr );
 if( map == NULL )
  {
   CloseHandle( mh );
   goto FOUT;
  }
 m->mh = mh;
 m->base = map;
 m->len = len;
 m->fh = fh;
 res = m->base;
FOUT :
 mutex_unlock( ___file_mutex );
 return res;
}

int
file_unmap( void * map )
{ register int i, res = -1;
 mutex_lock( ___file_mutex );
 for( i = 0; i < AF_MAXMAP; i++ )
  if( mtab[ i ].base == map )
   {
    UnmapViewOfFile( mtab[ i ].base );
    CloseHandle( mtab[ i ].mh );
    mtab[ i ].base = NULL;
    res = 0;
   }
 mutex_unlock( ___file_mutex );
 return res;
}

void *
file_remap( void * base, unsigned long len )
{ register int i, fh;
 void * res = NULL;
 mutex_lock( ___file_mutex );
 for( i = 0; i < AF_MAXMAP; i++ )
  if( mtab[ i ].base == base )
   {
    fh = mtab[ i ].fh;
    if( file_unmap( base ) == -1
        || file_chsize( fh, len ) == -1 )
     goto FOUT;
    res = file_map( fh, NULL );
    break;
   }
FOUT :
 mutex_unlock( ___file_mutex );
 return res;
}

/* Stupid Win95 can lock files only exclusively and
   the Documentation says nothing about waiting
   I hope it will die someday, so I do not change the specification */
int
file_lock( int fh, int flag )
{ HANDLE h = htab[ fh ].fh;
 OVERLAPPED ov;
 int flags = 0;
 uslong length = file_size_by_handle( fh );
 if( ( flag & ~AL_NOWAIT ) == AL_RDWR ) flags |= LOCKFILE_EXCLUSIVE_LOCK;
 if( flag & AL_NOWAIT ) flags |= LOCKFILE_FAIL_IMMEDIATELY;
 memset( & ov, 0, sizeof( OVERLAPPED ) );
 ov.Offset = 0;
 if( LockFileEx( h, flags, 0, length, 0, & ov ) )
  return 0;
 if( GetLastError() != 120 ) /* LockFileEx implemented and really failed */
  return -1;
 return LockFile( h, 0, 0, length, 0 ) ? 0 : -1;
}

int
file_unlock( int fh )
{ HANDLE h = htab[ fh ].fh;
 uslong length = file_size_by_handle( fh );
 return UnlockFile( h, 0, 0, length, 0 ) ? 0 : -1;
}
