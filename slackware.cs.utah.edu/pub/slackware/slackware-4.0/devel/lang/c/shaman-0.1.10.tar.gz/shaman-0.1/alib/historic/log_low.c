#include <stdio.h>
#include <stdarg.h>
#include "uls.h"
#include "amsg.h"

void
log_lowlevel( char * name, char * msg, va_list args )
{ FILE * fp;
 char * fmt;
 if( ( fp = fopen( name, "at" ) ) != NULL )
  {
   if( ( fmt = uls_get( msg ) ) == NULL )
    fmt = msg;
   vfprintf( fp, fmt, args );
   fclose( fp );
  }
}
