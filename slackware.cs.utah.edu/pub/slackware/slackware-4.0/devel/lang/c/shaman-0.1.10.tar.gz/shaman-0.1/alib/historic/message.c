#include "amsg.h"

void
vmessage( char * fmt, va_list args )
{
 tvmessage( AL_INFO, fmt, args );
}

void
message( char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 vmessage( fmt, args );
 va_end( args );
}
