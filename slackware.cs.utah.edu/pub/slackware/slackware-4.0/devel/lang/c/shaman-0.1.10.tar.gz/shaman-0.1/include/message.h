/* $Id$ */
#ifndef _MESSAGE_H_
#define _MESSAGE_H_

/*
 * Messages package.
 * Depends on Strings.
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

# include <stdarg.h>

/* Outputs a message so the user can see it 
 * Does not output it if the interest level on this theme
 * is lower than Level.
 * Still outputs the message if Theme is 0.
 */
extern void message      (int theme, int level, char * format, ...);
extern void vmessage     (int theme, int level, char * format, va_list arg);

/* The same, but Format, instead of being given directly, is obtained
   by applying Uls_get to Str
 */
extern void ulmessage     (int theme, int level, char * str, ...);
extern void vulmessage    (int theme, int level, char * str, va_list  arg);

/* Sets the output level on the theme */
extern void set_interest (int  theme, int  level);

/* Sets the logging level on the theme */
extern void set_log_interest (int  theme, int  level);

typedef void (*message_fun_t) (char *format, va_list arg);

/* Initializes the package. Sets the functions used to output and
 * log messages.
 */
extern void message_init (message_fun_t  mfun, message_fun_t lfun);

#endif /* Already included */
