#include <string.h>
#include "alib.h"
#include "printfn.h"

/* This function is particularly reliable -- it works even
   when Win32 `static' DLL is being unloaded by the system.
   printf() does not work there */
/* Used to print out messages */
void
printfn (char * format, va_list arg)
{ char str[ 1025 ];
  int l;
  vsprintf (str, format, arg);
  str[ l = strlen( str ) ] = '\n';
  file_write( 1, str, ++l );
}
