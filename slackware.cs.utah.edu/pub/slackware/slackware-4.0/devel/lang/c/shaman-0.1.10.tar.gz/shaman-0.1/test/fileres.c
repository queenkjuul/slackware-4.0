/* $Id$ */

/* A simple test for file resource package */
/* Written by Goga 6.03.97 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "fr_h.h"
#include "printfn.h"

#define TH_TEST 101

/* Set up all the used packages properly */
static void
initialize ( void )
{
  alib_init ();
  uls_init (getenv ("SHAMAN_MESSAGES"));
  message_init (printfn, NULL);

  resource_init ();
  /* Fileres package requires no initialization */
}

int
main ( void )
{
  Fr_h frh;
  Jump_h jh;
  char arr[7];

  initialize ();
  jh_init_set_c (&jh);
  if (jh_theme (&jh))
    {
      message (TH_TEST, 0, "Error caught");
      jh_done( & jh );
      exit (1);
    }

  message (TH_TEST, 0, "Started");

  frh_init (&frh, "fileres.c", AL_READ, & jh.rsh);

  message (TH_TEST, 0, "Opened");

  frh_read (&frh, arr, 6);
  arr[6] = '\0';

  message (TH_TEST, 0, "Read passed" );

  if (strcmp (arr, "/* $Id") != 0)
    error (TH_TEST, "Bad read results");

  message (TH_TEST, 0, "Checked the results" );

  jh_done (&jh); /* should close the file */

  message (TH_TEST, 0, "Exiting");

  return 0;
}
