/* $Id$ */
/*
 * Language type "shell" - shell commands executed in a separate process.
 * The result of a command is what it prints.
 *
 * As far as I can see, this will only work under UN*X.
 *			-- Goga
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#define _POSIX_SOURCE /* Some POSIX, not pure ANSI functions are used here */

/**//* #define USE_NANA */

#include "shnana.h"

#include <string.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "alib.h"
#include "resource.h"
#include "language.h"
#include "r_thread.h"
#include "misc.h"

/* Some testing stuff for Nana */

/* Magic number for sh_interp_t */
#define SH_INTERP_MAGIC 0x13100001

#define sh_interp_alright(si)  ((si)->magic == SH_INTERP_MAGIC)

/* Magic number for sh_fun_t */
#define SH_FUN_MAGIC    0x13100002

#define sh_fun_alright(sf) ((sf)->magic == SH_FUN_MAGIC && sh_interp_alright((sf)->interp))

/* The structure that describes a running interpreter */
typedef struct _sh_interp_t
{
  uslong magic;
  int pid;
  FILE *in_f;
  FILE *out_f;

  /* Functions table */
  int n_fun;      /* how many functions are exported */
  char **funnames;  /* the names themselves */

  mutex_t mutex;
} sh_interp_t;

typedef struct _sh_fun_t
{
  uslong magic;
  char * funname;
  sh_interp_t *interp;
} sh_fun_t;

/* Maximum length for a shell string */
#define SHSTR_LEN 128

/* Maximum length for a string representing an integer */
#define ISTR_LEN 10
/* ... a float */
#define FSTR_LEN 15

/* Have to declare it forward */
static ldata_t shell_to   (any_t   cobj, enum sh_type tp);
static any_t   shell_from (ldata_t lobj, enum sh_type tp);
extern Lang lang_shell;

/* Aux function.
 * Like strcmp, but makes an extra level of indirection
 */
static int
strcmp_indirect (const void *a, const void *b)
{
  const char **as = (const char **)a;
  const char **bs = (const char **)b;

  return strcmp (*as, *bs);
}


/* Loads a  program text into an internal representation
 * of the interpreter.
 * The program text is in a file, referenced by name.
 * After the program is loaded, the file is no longer needed.
 */
static prog_t
shell_load_mem (const void *mem, uslong size)
{
  sh_interp_t *interp;
  int pin [2], pout[2];
  Rs_h rsh;

  /*--- Nana preconditions */
  I (mem != NULL && size != 0);
  /*---*/

  /* Rsh is used to clear up if anything goes wrong */
  rsh_init_set_c (&rsh);

  interp = rxmalloc_c (sizeof (sh_interp_t));
  interp->magic = 0; /* Not initialized yet */
  pipe (pin); pipe (pout);

  if ((interp->pid = fork ()) != 0)
    { /* We're in the father process */
      close (pin[0]); close (pout[1]);		 	/* Not needed on this side */
      interp->in_f = fdopen (pin[1], "w"); 		/* We shall write here */
      interp->out_f = fdopen (pout[0], "r"); 		/* And read from here */
      interp->mutex = mutex_create ();
      if (interp->mutex == AL_NOMUTEX)
	ulerror (TH_LANGUAGE, "Lang_shell_cannot_create_mutex");
      if (!interp->in_f || !interp->out_f)
	ulerror (TH_LANGUAGE, "Lang_shell_cannot_open_files");
      fwrite (mem, (size_t) size, 1, interp->in_f);
      fflush (interp->in_f);

      /* Wait for it to swallow the text and print out "\n.\n" */
      /* No need to use the mutex yet */
      {
	char buff [SHSTR_LEN+1];
	int cursize;

	*buff = '\0';
	interp->n_fun = 0;
	cursize = 4; /* I think less is ineffective - but that's to be tested yet -- Goga */
	interp->funnames = rxmalloc_c (sizeof (char*) * cursize);

	/* Read in exported function names */
	for (;;)
	  {
	    int blen;
	    fgets (buff, SHSTR_LEN, interp->out_f);
	    if (strcmp (buff, ".\n") == 0)
	      break;

	    /* Forget the last symbol ('\n') */
	    blen = strlen (buff) - 1;
	    buff [blen] = '\0';

	    /* Allocate a bigger buffer if necessary */
	    if (interp->n_fun == cursize)
	      {
		cursize *= 2;
		interp->funnames = rxrealloc (interp->funnames,
					      cursize * sizeof (char*));
	      }
	    interp->funnames [interp->n_fun] = rxmalloc_c (blen + 1);
	    strcpy (interp->funnames[interp->n_fun], buff);
	    interp->n_fun ++;
	  }

	/* Sort the function names */
	qsort (interp->funnames, interp->n_fun, sizeof (char*), strcmp_indirect);

	/* Mark the interpreter initialized */
	interp->magic = SH_INTERP_MAGIC;
      }
    }
  else
    { /* We're in the child process */
      char shname [SHSTR_LEN+1] = "/bin/sh";
      char *shnptr;
      char *cmem = (char*) mem;

      if (*cmem == '#' && cmem[1] == '!')
	{
	  char * nl;
	  shnptr = cmem + 2;
	  nl = strchr (shnptr, '\n');
	  if (!nl)
	    ulerror (TH_LANGUAGE, "Lang_shell_no_program_body");
	  if (*(--nl) == '\r')
	    --nl;
	  if (nl - shnptr > SHSTR_LEN)
	    ulerror (TH_LANGUAGE, "Lang_shell_interpreter_name_too_long");
	  /**/ /*!!!!!?????*/
	  astr_ncpy (shname, shnptr, nl - shnptr+1);
	}
      close (pin[1]); close (pout[0]);  	/* Not needed on this side */
      close (0); close (1); 
      dup2 (pin[0], 0); dup2 (pout[1],1);
      close (pin[0]); close(pout[1]); 
      execl (shname, shname, NULL);
    }

  /* We have allocated everything successfully, now call r_forget,
   * so that Rsh_done won't free it all
   */
  r_forget (interp);
  r_forget (interp->funnames);
  {
    int i;
    for (i = 0; i < interp->n_fun; i++)
      r_forget (interp->funnames[i]);
  }
  rsh_done (&rsh);

  /*--- Nana postconditions */
  I (sh_interp_alright (interp));
  /*---*/

  return (prog_t) interp;
}

/* Declares program unnecessary. */
static  void
shell_discard (prog_t prog)
{
  sh_interp_t *interp = (sh_interp_t*) prog;
  int status;

  /*--- Nana preconditions */
  I (sh_interp_alright (interp));
  /*---*/

  /* We could write "exit" into interp->in_f and wait for it to finish,
   * but that would be interpreter dependent (having the "exit" command),
   * and I want the code to be as generic as possible
   *		-- Goga
   */
  mutex_lock (interp->mutex);
  {
    fclose (interp->in_f);
    fclose (interp->out_f);
    kill (interp->pid, SIGTERM);
  }
  mutex_unlock (interp->mutex);

  waitpid (interp->pid, &status, 0);

  /* Free the interpreter's memory structures */
  {
    int i;
    for (i = 0; i < interp->n_fun; i++)
      rxfree (interp->funnames[i]);
  }
  rxfree (interp->funnames);
  rxfree (interp);

  /*--- Nana postconditions */
  /* Interp is freed, no mutexes are locked */
  /*---*/
}

/* Checks if a text is a program in the language 
 * The text is in a memory area.
 */
static bool 
shell_recog (const void *text, uslong len)
{
  int res;
  const char *ss = text;

  /*--- Nana preconditions */
  I (text != NULL && len != 0);
  /*---*/

  /* We assume that any program text should start with a line containing "#! ...sh".
   *		-- Goga
   */

  if (ss[0] != '#' || ss[1] != '!')
    res = FALSE;
  else
    {
      char * nl;
      nl = strchr (ss, '\n');
      if (!nl)
	res = FALSE;
      else
	{
	  if (*(--nl) == '\r')
	    --nl; /* The line may finish with "\r\n" */
	  if (nl[-1] == 's' && nl[0] == 'h')
	    res = TRUE;
	  else
	    res = FALSE;
	}
    }

  /*--- Nana postconditions */
  /*---*/

  return res;
}

static fun_t
shell_get_fun (prog_t prog, const char *fun_name)
{
  sh_fun_t *res;
  sh_interp_t *interp = (sh_interp_t*) prog;
  char ** pfname;

  /*--- Nana preconditions */
  I (sh_interp_alright (interp) && fun_name != NULL);
  /*---*/

  res = xmalloc (sizeof (sh_fun_t));
  res->magic  = 0; /* Not initialized yet */
  res->interp = interp;
  pfname = bsearch (&fun_name, interp->funnames, interp->n_fun,
			  sizeof (char*), strcmp_indirect);

  if (pfname != NULL)
    {
      res->funname = *pfname;
      res->magic = SH_FUN_MAGIC;
    }
  else
    {
      xfree (res);
      res = NULL;
    }

  /*--- Nana postconditions */
  I (res == NULL || sh_fun_alright (res));
  /*---*/

  return (fun_t) res;
}

static void
shell_release_fun (fun_t fun)
{
  sh_fun_t *shfun = (sh_fun_t *)fun;

  /*--- Nana preconditions */
  I (sh_fun_alright (shfun));
  /*---*/

  xfree (shfun);

  /*--- Nana postconditions */
  /* Shfun freed */
  /*---*/
}

/* Executes a function inside the program given in the internal representation 
 * Rest is the result type, Argt - 0 terminated array of argument types
 */
static any_t
shell_eval (fun_t fun,
	     sh_type rest, 
	     sh_type argt[], va_list argv)
{
  any_t res;
  sh_fun_t *shfun = (sh_fun_t*) fun;
  R_lock rl;
  sh_interp_t *interp = shfun->interp;

  /*--- Nana preconditions */
  I (sh_fun_alright (shfun));
  /*---*/

  /* The function is a critical section for the interpreter */
  r_lock_init_c (&rl, interp->mutex);
  {

    /* First, feed the interpreter with the command line */
    fprintf (interp->in_f, "%s ", shfun->funname);

    /* The Rs_h is used to free the memory allocated for each argument */
    if (argt)
      for (;*argt != SHT_NONE; argt++)
	{
	  Rs_h rsh;
	  rsh_init_set_c (&rsh); /* Shell_to may allocate memory */
	  
	  fprintf (interp->in_f, "\'%s\'", (char*) lang_to_va_list (&lang_shell, *argt, &argv));
	
	  rsh_done (&rsh);
	}

    fputc ('\n', interp->in_f);
    fflush (interp->in_f);
    
    /* Now collect the interpreter output */
    /* We don't count on long strings in output */
    {
      char * result;
      char buff [SHSTR_LEN+1];
      unsigned curlen;  /* result strlen */
      unsigned cursize; /* result buffer size */
      
      cursize = SHSTR_LEN + 1;
      result = rxmalloc_c (cursize);
      *result = '\0';
      curlen = 0;
      *buff = '\0';
      
      while (strcmp (buff, ".\n") != 0)
	{
	  fgets (buff, SHSTR_LEN, interp->out_f);
	  if (curlen + strlen (buff) + 1 > cursize)
	    result = rxrealloc (result, cursize *= 2);
	  if (*buff == '\\')
	    { /* Use \ at the start of the line as an escape character */
	      strcat (result, buff+1);
	      curlen += strlen (buff) - 1;
	    }
	  else
	    { /* The normal case */
	      strcat (result, buff);
	      curlen += strlen (buff);
	    }
	}

      if (curlen != 2)
	result [curlen - 3] = '\0';	/* Chop off the trailing "\n.\n" */
      else
	*result = '\0';			/* Empty output */
      
      res = shell_from ((ldata_t)result, rest);
      rxfree (result);
    }
  }
  r_lock_done (&rl);

  /*--- Nana postconditions */
  /* No mutexes are locked; resources are consistent */
  /*---*/
  return res;
}
  
/* Converts the interpreter-specific form of an expression to something
 * language independent.
 * (mostly for the query analyzer's sake)
 * !!!!! Expr_ is not yet defined -- Goga.
 */
static expr_t 
shell_make_expr (void* arg)
{
  return NULL;
}

/* Converts a C object to an internal object of the interpreter */
static ldata_t
shell_to (any_t cobj, enum sh_type tp)
{
  char * res = NULL;

  /*--- Nana preconditions */
  /*---*/

  switch (tp)
    {
    case SHT_INTERNAL:
      res = (char*) cobj;
      break;
    case SHT_BOOL:
      res = rxmalloc_c (2);
      if ((bool)cobj)
	strcpy (res, "1");
      else
	strcpy (res, "0");
      break;
    case SHT_CHAR:
      if ((char)cobj == '\'')
	{
	  res = rxmalloc_c (5);
	  strcpy (res, "\'\\\'\'");
	}
      else
	{
	  res = rxmalloc_c (2);
	  res[0] = (char)cobj;
	  res[1] = '\0';
	}
      break;
      /*???? Is itoa nonstandard? */
    case SHT_INT:
      res = rxmalloc_c (ISTR_LEN+1);
      sprintf (res, "%ld", (long)cobj);
      break;
    case SHT_FLOAT:
      res = rxmalloc_c (FSTR_LEN+1);
      sprintf (res, "%f", *(double*) cobj);
      break;
    case SHT_STRING:
      {
	/* Single quote escapes everything except for itself */
	int qcount;
	char *ib;
	char *ob;

	/* Counting single quotes */
	for (qcount = 0, ib = strchr ((char*)cobj, '\''); ib; ib = strchr (ib, '\''))
	  {qcount++; ib++;}
	/* Each single quote is represented by 4 characters: '\'' */
	res = rxmalloc_c (strlen ((char*)cobj) + 3 * qcount+ 1);
	for (ib = (char*)cobj, ob = res; *ib; ib++)
	  if (*ib == '\'')
	    {
	      strcpy (ob, "\'\\\'\'");
	      ob += 4;
	    }
	  else
	    *(ob++) = *ib;
	*ob = '\0';
      }
      break;
    case SHT_LIST:
      ulerror (TH_LANGUAGE, "Lang_shell_lists_not_handled");
      break;
    default:
      ulerror (TH_LANGUAGE, "Lang_shell_cannot_convert_type_%d", (int)tp);
      break;
    }
  
  /*--- Nana postconditions */
  I (rm_alright (res));
  /*---*/

  return (ldata_t)res;
}

/* Converts an interpreter object into a C object,
 * tp == 0 means the interpreter should guess itself.
 */
static any_t
shell_from (ldata_t lobj, enum sh_type tp)
{
  any_t res;

  /*--- Nana preconditions */
  I (tp == SHT_NONE || rm_alright ((char*)lobj));
  /*---*/

  switch (tp)
    {
    case SHT_NONE:
      res = (any_t)0;
      break;
    case SHT_INTERNAL:
      res = (any_t) lobj;
      break;
    case SHT_BOOL:
      sscanf ((char*)lobj, "%ld", (long*)(bool*)&res);
      break;
    case SHT_CHAR:
      if (strlen((char*)lobj) != 1) /* Should we set such strict requirements? */
	ulerror (TH_LANGUAGE, "Lang_shell_types_dont_match_%s_%s", "CHAR", (char*)lobj);
      res = (any_t) *(char*)lobj;
      break;
    case SHT_INT:
      res = (any_t)atol((char*)lobj);
      break;
    case SHT_FLOAT:
      {
	double *pres;
	pres = rxmalloc_c (sizeof (double));
	*pres = atof((char*)lobj);
	res = (any_t) pres;
      }
      break;
    case SHT_STRING:
      {
	char * cres;
	cres = rxmalloc_c (strlen ((char*)lobj) + 1);
	strcpy (cres, (char*)lobj);
	res = (any_t) cres;
	break;
      }
    case SHT_LIST:
      ulerror (TH_LANGUAGE, "Lang_shell_lists_not_handled");
      break;
    default:
      ulerror (TH_LANGUAGE, "Lang_shell_cannot_convert_type_%d", (int)tp);
      break;
    }
  
  /*--- Nana postconditions */
  /*---*/

  return res;
}

/* Declares that the interpreter object is locked
 * by the controlling program.
 */
static void
shell_lock (ldata_t lobj)
{
  /* In our case, Lobj should be made independent of any Rs_h's */

  /*--- Nana preconditions */
  I (rm_alright ((char*)lobj));
  /*---*/

  r_forget ((void*)lobj);

  /*--- Nana postconditions */
  I (rm_forgotten ((void*)lobj));
  /* Resources are consistent */
  /*---*/
}

/* Declares that the interpreter object is no longer locked
 * by the controlling program.
 */
static void
shell_unlock (ldata_t lobj)
{
  /*--- Nana preconditions */
  I (rm_alright ((char*)lobj));
  /*---*/

  /* In our case, this means we can simply free the object */
  rfree ((void*)lobj);

  /*--- Nana postconditions */
  /* Lobj is freed */
  /* Resources are consistent */
  /*---*/
}

/* The structure describing the language. */
Lang lang_shell =
{
  "Shell",
  NULL,			/* load_file */
  shell_load_mem,	/* load_mem  */
  shell_recog,		/* recog */
  shell_discard,	/* discard */
  shell_get_fun,	/* get_fun */
  shell_release_fun,	/* release_fun */
  shell_eval,		/* eval */
  shell_make_expr,	/* make_expr */
  shell_to,		/* t_to */
  shell_from,		/* t_from */
  shell_lock,		/* lock */
  shell_unlock,		/* unlock */
  0			/* a place to put LANG_MAGIC in */
};

