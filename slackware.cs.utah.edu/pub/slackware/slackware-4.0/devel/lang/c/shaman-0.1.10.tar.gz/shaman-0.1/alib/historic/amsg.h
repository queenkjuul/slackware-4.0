#ifndef AMSG_H
#define AMSG_H

#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
   All these functions must first search their string arguments
   in the messages (ULS) database, and only if this fails should they
   use them immediately
 */

/*
   Common idea :
     Two common modes to talk to user :
        1) `messages', i.e. different-looking, but always appearing
           things
        2) logs, i.e. something going to file, looking always
           similarly, but having levels, i.e. appearing only if needed

     The only exclusion is ask() -- it has no levels nor themes,
     but it looks for format argument in ULS database
 */

/* predefined themes */
#define AL_ERROR 0 /* fatal error, typically exit() with error message */
#define AL_ALERT 1 /* warning, typically wants user reaction (hit-any-key)
                      and has dangerous appearance (all red:)
                      for example, error() can call it and then call exit() */
#define AL_INFO  2 /* information, just something like "All work done" */


/*
   Actions   : yield message for given theme
   Arguments : theme  -- theme
               fmt    -- format expression (to be searched in ULS base)
               args   -- arguments
   Value     : none
 */
void tvmessage( int theme, char * fmt, va_list args );

/*
   Actions   : tvmessage( theme, fmt, va_start( ..., fmt ) )
   Arguments : theme  -- theme
               fmt    -- format
   Value     : none
 */
void tmessage( int theme, char * fmt, ... );


/*
   Actions   : tvmessage( MT_ERROR, fmt, args )
   Arguments : fmt  -- format
               args -- arguments
   Value     : none
 */
void verror( char * fmt, va_list args );

/*
   Actions   : verror( fmt, va_start( ..., fmt ) )
   Arguments : fmt -- format
   Value     : none
 */
void error( char * fmt, ... );

/*
   Actions   : tvmessage( MT_INFO, fmt, args )
   Arguments : fmt   -- format
               args  -- arguments
   Value     : none
 */
void vmessage( char * fmt, va_list args );

/*
   Actions   : vmessage( fmt, va_start( ..., fmt ) )
   Arguments : fmt -- format
   Value     : none
 */
void message( char * fmt, ... );

/*
   Actions   : tvmessage( MF_ALERT, fmt, args )
   Arguments : fmt   -- format
               args  -- arguments
   Value     : none
 */
void valert( char * fmt, va_list args );

/*
   Actions   : valert( fmt, va_start( ..., fmt ) )
   Arguments : fmt -- format
   Value     : none
 */
void alert( char * fmt, ... );


/*
   Actions   : ask a question with several possible answers,
               make the user to choose the answer
   Arguments : question -- question
               the question is followed by the list of answers,
               terminated by NULL
   Value     : number of the choosen answer (0-based), -1 if the user
               rejected to answer
   Comments  : this function also can be re-implemented by user
               it must accept ULS message identifiers
 */
int ask( char * question, ... );


/*
   Logs are objects which are created and managed by main
   application and used by bith the main application and all
   toolkits and libraries linked to it.
   Main application should create all needed logs and set their
   verbosity levels, toolkits and libraries should only obtain
   log handles they need and use them (not changing anything).
   This policy allows us to have teh only log system, which
   can be, first, manageable by means of themes and verbosity levels,
   and, second, fully ovverridable by each application without even
   recompiling the libraries that it uses.
 */

/* maximum logs number */
#define AL_LOG_NHANDLE 64

/* maximum log name length */
#define AL_LOG_MAXNAME 64


/**************** These functions is only for main modules **********/
/*
   Actions   : create new log object with given name
               (which will identify the source of the information),
               set its verbosity level to 1 (almost silent)
   Arguments : name -- log name
   Value     : log handle to be used to write to this log, -1 on error
   Comments  : There is one pre-determined log -- number 0 (stdlog? :)
               It is used for messages that go from unknown sources
 */
int log_create( char * name );

/*
   Actions   : destroy the log
   Arguments : log -- log handle
   Value     : none
 */
void log_destroy( int log );

/*
   Actions   : none
   Arguments : log -- log handle
   Value     : current verbosity level for given theme
 */
int log_get_level( int log );

/*
   Actions   : set verbosity level for given theme
   Arguments : log   -- log handle
               level -- level (0 -- be silent)
   Value     : none
 */
void log_set_level( int log, int level );

/************** The rest is for toolkits too **********************/

/*
   Actions   : log the message to the specified log only if
               the level of the log is greater than its level
   Arguments : log   -- log handle
               level -- level
               fmt   -- format
               args  -- arguments
   Value     : none
 */
void log_vlog( int log, int level, char * fmt, va_list args );

/*
   Actions   : log_vlog( log, level, fmt, va_start( ..., fmt ) )
   Arguments : log   -- log handle
               level -- level
               fmt   -- format
   Value     : none
 */
void log_log( int log, int level, char * fmt, ... );


/*
   Actions   : search given log among existing ones
   Arguments : name -- log name
   Value     : log handle
   Comment   : This function is for toolkits, which don't want
               (and must not!) create logs and change their levels.
               the caller should not take care about the result
               of this function, since the result is always valid.
 */
int log_number( char * name );

/************ This function performs the actual logging **************/
/*
   Actions   : actually log the specified message under the specified
               log name.
   Arguments : name -- name of the log
               fmt  -- format
               args -- arguments
   Value     : none
   Comments  : this function actually determines log behaviour,
               it should be placed to a separate file and
               may be re-implemented by every particular application
 */
void log_lowlevel( char * name, char * fmt, va_list args );


#ifdef __cplusplus
}
#endif

#endif

