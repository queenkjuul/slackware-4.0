#include <string.h>

#include "___file.h"
#include "astr.h"

int
fs_mkdirhier( const char * dir )
{ char s[ AL_MAXFULL + 1 ];
 char * p;
 char tocreat[ AL_MAXFULL + 1 ];
 fn_fullname( s, dir );
 p = ___fn_getdrv( tocreat, s );
 for( p = strtok( p, ___fn_slash_str() ); p != NULL;
      p = strtok( NULL, ___fn_slash_str() ) )
  {
   astr_ncat( tocreat, ___fn_slash_str(), AL_MAXFULL );
   astr_ncat( tocreat, p, AL_MAXFULL );
   if( ! fs_dir_exists( tocreat )
       && fs_mkdir( tocreat ) == -1 )
    return -1;
  }
 return fs_dir_exists( dir ) ? 0 : -1;
}

int
fs_dir_exists( const char * dir )
{ char old[ AL_MAXFULL + 1 ];
 fs_curdir( old );
 if( fs_chdir( dir ) == -1 )
  return 0;
 fs_chdir( old );
 return 1;
}
