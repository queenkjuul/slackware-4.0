#include <string.h>
#include "astr.h"
#include "amsg.h"

typedef struct
{
 char name[ AL_LOG_MAXNAME + 1 ];
 int opened;
 int level;
} log_t;


static log_t logs[ AL_LOG_NHANDLE ] =
{
 { "Default", 1, 1 }
};

int
log_create( char * name )
{ register int i;
 for( i = 0; i < AL_LOG_NHANDLE; i++ )
  if( ! logs[ i ].opened )
   {
    str_ncpy( logs[ i ].name, name, AL_LOG_MAXNAME );
    logs[ i ].opened = 1;
    logs[ i ].level = 1;
    return i;
   }
 return -1;
}

void
log_destroy( int lh )
{
 if( lh > 0 && lh < AL_LOG_NHANDLE ) /* stdlog cannot be destroyed */
  memset( logs + lh, 0, sizeof( log_t ) );
}

int
log_get_level( int lh )
{
 return logs[ lh ].level;
}

void
log_set_level( int lh, int level )
{
 if( level >= 0 )
  logs[ lh ].level = level;
}

void
log_vlog( int log, int level, char * fmt, va_list args )
{
 if( log < 0 || log >= AL_LOG_NHANDLE || ! logs[ log ].opened )
  log = 0;
 if( logs[ log ].level > level )
  log_lowlevel( logs[ log ].name, fmt, args );
}

void
log_log( int log, int level, char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 log_vlog( log, level, fmt, args );
 va_end( args );
}

int
log_number( char * name )
{ register int i;
 for( i = 0; i < AL_LOG_NHANDLE; i++ )
  if( logs[ i ].opened
   && strncmp( logs[ i ].name, name, AL_LOG_MAXNAME ) == 0 )
  return i;
 return 0;
}
