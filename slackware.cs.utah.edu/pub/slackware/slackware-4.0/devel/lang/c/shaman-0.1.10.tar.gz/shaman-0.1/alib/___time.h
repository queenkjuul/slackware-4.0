#ifndef ___TIME_H
#define ___TIME_H

#ifdef __cplusplus
extern "C" {
#endif

int ___sys_tz( void );

#ifdef __cplusplus
}
#endif

#endif
