/* $Id$ */
/*
 * Cache package.
 * Started by Goga 9.07.97 0:30
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "shnana.h"
#include "alib.h"
#include "resource.h"
#include "r_thread.h"
#include "cache.h"
#include "misc.h"

/* Lower level functions
 * It is supposed that the mutex is already locked.
 */

/* Get the Cache_entry* given the address of its timelist */
/** Is it portable enough? Is there a way to express the same in a
 ** more readable form?
 **	-- Goga
 **/
#define time_unoffset(tl) ((Cache_entry*) ((char*)(tl) - \
					   (int)(char*) & (((Cache_entry*)NULL)->timelist)))

/* Mark Entry as latest in Cache */
static void
move_to_top (Cache *cache, Cache_entry *entry)
{
  /*--- Nana preconditions */
  I (cache_alright (cache) && cache_entry_alright (entry) && entry_in_cache (entry,cache));
  /*---*/

  dl_excl (& entry->timelist);
  dl_insert (& entry->timelist, & cache->latest);

  /*--- Nana postconditions */
  I (cache_alright (cache) && cache_entry_alright (entry) && entry_in_cache (entry,cache));
  I (cache->latest.next == & entry->timelist);
  /*---*/
}

/* Remove the oldest untouched element from the cache.
 * Cache is assumed to be nonempty.
 */
static void
delete_oldest (Cache *cache)
{
  Dl_list *tl;

  /*--- Nana preconditions */
  ID (int _num = cache->num_current);
  I (cache_alright (cache));
  I (cache->num_current > 0);
  /*---*/

  for ( tl = cache->latest.prev;
	tl != &cache->latest && time_unoffset(tl)->lock != 0;
	tl = tl->prev )
    ;
  if (tl == &cache->latest)
    ulerror (TH_CACHE, "Cache_terrible_race%p", cache);
  cache_entry_delete (cache, time_unoffset(tl));

  /*--- Nana postconditions */
  I (cache_alright (cache) && cache->num_current == _num - 1);
  /*---*/
}

/* Public functions */

/* Initialize a cache */
void
cache_init (Cache *cache, struct _cache_procs *procs,
	    unsigned hash_size, unsigned num_max)
{
  unsigned i;

  /*--- Nana preconditions */
  I (cache != NULL && cache_uninited (cache));
  /*---*/

  cache->procs = procs;
  cache->hash_size = hash_size;
  cache->num_max = num_max;

  cache->htable = xmalloc (hash_size * sizeof (Dl_list));
  for (i = 0; i < hash_size; i++)
    dl_init (& cache->htable[i]);

  dl_init (& cache->latest);
  cache->num_current = 0;

  cache->mutex = mutex_create ();
  if (cache->mutex == AL_NOMUTEX)
    {
      ulerror (TH_CACHE, "Cache_mutex_creation_fail");
    }

  /*--- Nana postconditions */
  I (cache_alright (cache) && cache->num_current == 0);
  /*---*/
}

/* Destroy a cache and all of its members */
void
cache_destroy (Cache *cache)
{
  R_lock lock;
  Cache_entry *ce, *next;

  r_lock_init_c (& lock, cache->mutex);

  /*--- Nana preconditions */
  I (cache_alright (cache));
  /*---*/

  for (ce = cache_iter_start (cache);
       ce != NULL;
       ce = next)
    {
      next = cache_iter_next (cache, ce);
      cache_entry_delete (cache, ce);
    }

  free (cache->htable);

  r_lock_done (& lock);
  mutex_destroy (cache->mutex);

  /*--- Nana postconditions */
  I (cache_uninited (cache));
  /*---*/
}

/* Lookup for an entry in the cache;
 * if not found, creates a new entry via Cache->procs->form()
 */
Cache_entry *
cache_lookup (Cache *cache, any_t key)
{
  Cache_entry *res;
  int hashnum;
  R_lock lock;

  r_lock_init_c (& lock, cache->mutex);

  /*--- Nana preconditions */
  I (cache_alright (cache));
  /*---*/

  hashnum = cache->procs->hash (key, cache->hash_size);

  {
    Dl_list *dl;
    Cache_entry *ce = NULL;

    for (dl = cache->htable[hashnum].next;
	 dl != & cache->htable[hashnum];
	 dl = dl->next)
      {
	ce = (Cache_entry*)dl;
	if (cache->procs->match (ce, key))
	  break;
	else
	  ce = NULL;
      }

    res = ce;
  }

  if (res == NULL) /* Need to generate a new entry */
    {
      if (cache->num_current == cache->num_max) /* Overfull cache */
	delete_oldest (cache);

      res = cache->procs->form (key);
      dl_init (& res->hashlist);
      dl_init (& res->timelist);
      res->lock = 0;

      /* Insert it into the cache */
      dl_insert (& res->hashlist, & cache->htable[hashnum]);
      dl_insert (& res->timelist, & cache->latest);
      cache->num_current ++;
    }
#if 0 /* Cannot do that because iterators might get spoiled -- Goga */
  else /* found, move it to the beginning of the hashlist */
    {
      dl_excl (& res->hashlist);
      dl_insert (& res->hashlist, &cache->htable[hashnum]);
    }
#endif

  move_to_top (cache, res);
  res->lock ++;

  /*--- Nana postconditions */
  I (cache_alright (cache));
  I (res != NULL && cache_entry_alright (res) && entry_in_cache (res, cache));
  I (cache->procs->match (res, key));
  /*---*/

  r_lock_done (& lock);

  return res;
}

/* Unlock an entry, allowing its deletion if it becomes old */
void
cache_entry_unlock (Cache *cache, Cache_entry *entry)
{
  R_lock lock;
  /*--- Nana */
  ID (int _lcknum);
  /*---*/

  r_lock_init_c (&lock, cache->mutex);

  /*--- Nana preconditions */
  I (cache_alright (cache) && cache_entry_alright (entry) && entry_in_cache(entry,cache));
  IS (_lcknum = entry->lock);
  /*---*/

  if (entry->lock == 0)
    ulerror (TH_CACHE, "Cache_entry_too_many_unlocks%p%p", cache, entry);
  entry->lock --;

  /*--- Nana postconditions */
  I (cache_alright(cache) && cache_entry_alright (entry) && entry_in_cache(entry,cache));
  I (entry->lock == _lcknum - 1);
  /*---*/

  r_lock_done (&lock);
}

/* Force deletion of a cache entry */
void
cache_entry_delete (Cache *cache, Cache_entry *entry)
{
  R_lock lock;

  /*--- Nana */
  ID (int _num);
  /*---*/

  r_lock_init_c (& lock, cache->mutex);

  /*--- Nana preconditions */
  I (cache_alright(cache) && cache_entry_alright (entry) && entry_in_cache(entry,cache));
  IS (_num = cache->num_current);
  /*---*/

  if (entry->lock)
    ulerror (TH_CACHE, "Cache_entry_locked%p%p", cache, entry);

  dl_excl (& entry->hashlist);
  dl_excl (& entry->timelist);
  cache->procs->delete (entry);

  cache->num_current --;

  /*--- Nana postconditions */
  I (cache_alright (cache) && cache->num_current == _num - 1);
  /* The following line is a way to express that Entry is not in Cache without
   * touching the freed memory
   */
  I (C (Dl_list *tl = cache->latest.next,
	tl != &cache->latest,
	tl = tl->next,
	time_unoffset (tl) == entry)
       == 0);
  /*---*/

  r_lock_done (& lock);
}

/* !!! Using Cache_iter_start / Cache_iter_next
 * needs locking cache->mutex
 */

/* Start listing all the cache entries.
 * NULL if no entries in the cache.
 */
Cache_entry *
cache_iter_start (Cache *cache)
{
  Cache_entry *res;
  unsigned i;
  R_lock lock;

  r_lock_init_c (&lock, cache->mutex);

  /*--- Nana preconditions */
  I(cache_alright (cache));
  /*---*/

  /* We are using Hashlists, not Timelists,
   * because the order of entries is fixed in them */
  res = NULL;
  for (i = 0; i < cache->hash_size; i++)
    if (cache->htable[i].next != &cache->htable[i])
      {
	res = (Cache_entry*) cache->htable[i].next;
	res->lock ++;
	break;
      }

  /*--- Nana postconditions */
  I (cache_alright (cache));
  I (cache->num_current == 0
      ? res == NULL 
      : res != NULL && entry_in_cache (res, cache));
  /*---*/

  r_lock_done (&lock);

  return res;
}

/* Get the next entry in the list,
 * NULL if all are listed.
 */
Cache_entry *
cache_iter_next (Cache *cache, Cache_entry *prev)
{
  Cache_entry *res;
  Dl_list *tl;
  R_lock lock;

  r_lock_init_c (&lock, cache->mutex);

  /*--- Nana preconditions */
  I (cache_alright (cache) && cache_entry_alright (prev) && entry_in_cache (prev,cache));
  /*---*/
  prev->lock --;

  res = NULL;
  tl = prev->hashlist.next;
  if (tl >= cache->htable && tl < cache->htable + cache->hash_size)
    /* We are inside the hash table itself */
    for (tl++; tl < cache->htable + cache->hash_size; tl++)
      {
	if (tl->next != tl)
	  {
	    res = (Cache_entry*) tl->next;
	    break;
	  }
      }
  else
    res = (Cache_entry*) tl;

  if (res)
    res->lock ++;

  /*--- Nana postconditions */
  I (cache_alright (cache));
  I (res == NULL || entry_in_cache (res, cache));
  /*---*/
  
  r_lock_done (&lock);

  return res;
}
