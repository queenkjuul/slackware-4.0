/* $Id$ */
#ifndef _R_THREAD_H_
#define _R_THREAD_H_

/*
 * Simple resource support for threads.
 * Started by Goga 31.05.97
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "resource.h"

/* A resource type representing a mutex lock */
struct _r_lock
{
  Resource r;
  mutex_t mutex;
};
typedef struct _r_lock R_lock;

/* Initialize the R_lock (and make a lock) */
void r_lock_init (R_lock *lock, mutex_t mutex, Rs_h *rsh);

/* Release the lock */
void r_lock_done (R_lock *lock);

/* Do it with the current Rs_h */
#define r_lock_init_c(lock, mx) r_lock_init (lock, mx, rsh_current ())

#endif
