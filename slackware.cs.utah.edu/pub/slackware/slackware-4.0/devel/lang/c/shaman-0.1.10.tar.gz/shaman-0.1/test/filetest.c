#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#include "alib.h"

static void
error( char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 vfprintf( stderr, fmt, args );
 va_end( fmt );
 exit( 0 );
}

#define BLEN 1024
#define NEWSIZE (BLEN * 2)
#define SECSIZE (BLEN * 3)

#ifdef __WIN32__
#define ADDR (( void * )0x90000000)
#endif
#ifdef __linux__
#define ADDR (( void * )0x00010000)
#endif
#ifdef __freebsd__
#define ADDR (( void * )0xA0000000)
#endif

static char tmpname[] = "file.tmp";
static char newname[] = "renamed.tmp";
static char buf[ BLEN ], buf2[ BLEN ], buf3[ NEWSIZE - BLEN ];

static char simpledir[] = "first";
#ifdef __WIN32__
static char complexdir[] = "first\\second\\third\\fourth";

static char * dirs[] =
{
 complexdir,
 "first\\second\\third",
 "first\\second",
 simpledir,
 NULL
};
#endif
#ifdef __linux__
static char complexdir[] = "first/second/third/fourth";

static char * dirs[] =
{
 complexdir,
 "first/second/third",
 "first/second",
 simpledir,
 NULL
};
#endif
#ifdef __freebsd__
static char complexdir[] = "first/second/third/fourth";

static char * dirs[] =
{
 complexdir,
 "first/second/third",
 "first/second",
 simpledir,
 NULL
};
#endif

static char volume[] = ".";

static void
dump_time( char * header, packtime_t t )
{ atime_t at;
 time_unpack( & at, t );
 printf( "%s : %d.%d.%d %d:%d:%d.%d\n", header, at.day, at.month,
         at.year, at.hour, at.min, at.sec, at.msec );
}

static void
dump_stat( stat_t * st )
{
 printf( "Size : %d\n", st->size );
 dump_time( "Creation time", st->c_time );
 dump_time( "Access time", st->a_time );
 dump_time( "Modification time", st->m_time );
}

int
main( void )
{ int i, fh;
 stat_t st;
 char * p;
 char cwd[ AL_MAXFULL + 1 ];
 alib_init();
 memset( buf, 0x55, BLEN );
 memset( buf3, 0xAA, NEWSIZE - BLEN );
 printf( "Creating file '%s'...\n", tmpname );
 if( ( fh = file_create( tmpname ) ) == -1 )
  error( "Cannot create file '%s'\n", tmpname );
 printf( "Writing %d bytes to '%s'...\n", BLEN, tmpname );
 if( file_write( fh, buf, BLEN ) != BLEN )
  error( "Cannot write to file '%s'\n", tmpname );
 printf( "Current position is '%ld', seeking to the beginning...\n",
          file_tell( fh ) );
 printf( "Re-opening the file..\n" );
 if( file_close( fh ) == -1 || ( fh = file_open( tmpname, AL_RDWR ) ) == -1 )
  error( "Failed re-opening the file\n" );
 if( file_seek( fh, 0, AL_BEGIN ) != 0 )
  error( "Cannot seek '%s'\n", tmpname );
 printf( "Reading the file back and comparing to the original data...\n" );
 if( file_read( fh, buf2, BLEN ) != BLEN )
  error( "Cannot read %d bytes from '%s'\n", BLEN, tmpname );
 if( memcmp( buf, buf2, BLEN ) != 0 )
  error( "Miscompared data\n" );
 printf( "Closing '%s'...\n", tmpname );
 if( file_close( fh ) != 0 )
  error( "Error closing the file\n" );
 printf( "Obtaining file information...\n" );
 if( file_stat( tmpname, & st ) == -1 )
  error( "Cannot obtain file information\n" );
 dump_stat( & st );
 printf( "Opening '%s'...\n", tmpname );
 if( ( fh = file_open( tmpname, AL_RDWR ) ) == -1 )
  error( "Cannot open file '%s'\n", tmpname );
 printf( "Obtaining file information by handle...\n" );
 if( file_stat_by_handle( fh, & st ) == -1 )
  error( "Cannot obtain file information by handle\n" );
 dump_stat( & st );
 printf( "Mapping the file...\n" );
 if( ( p = file_map( fh, NULL ) ) == NULL )
  error( "Cannot map file '%s'\n", tmpname );
 printf( "Mapped to %08lX\n", ( unsigned long )p );
 if( memcmp( buf, p, BLEN ) != 0 )
  error( "Miscompared data\n" );
 printf( "Unmapping the file...\n" );
 if( file_unmap( p ) == -1 )
  error( "Cannot unmap file '%s'\n", tmpname );
 printf( "Changing file size to %d...\n", NEWSIZE );
 if( file_chsize( fh, NEWSIZE ) == -1 )
  error( "Cannot change file size\n" );
 printf( "File size changed to %ld\n", file_size_by_handle( fh ) );
 printf( "Mapping the file to fixed address %08lX...\n",
         ( unsigned long )ADDR );
 if( ( p = file_map( fh, ADDR ) ) == NULL )
  error( "Cannot map file '%s'\n", tmpname );
 printf( "Writing to the mapped region at %08X...\n", ( unsigned )p );
 memcpy( p + BLEN, buf3, NEWSIZE - BLEN );
 if( file_unmap( p ) == -1 )
  error( "Cannot unmap file\n" );
 if( ( p = file_map( fh, NULL ) ) == NULL )
  error( "Cannot map file\n" );
 if( memcmp( p, buf, BLEN ) != 0
     || memcmp( p + BLEN, buf3, NEWSIZE - BLEN ) != 0 )
  error( "Miscompared data\n" );
 printf( "Remapping the file to new size (%d)\n", SECSIZE );
 if( ( p = file_remap( p, SECSIZE ) ) == NULL )
  error( "file_remap( %08lX, %d ) failed\n", ( uslong )p, SECSIZE );
 printf( "Attempting to write to the new-mapped region...\n" );
 memset( p + BLEN * 2, 'N', BLEN );
 printf( "Closing the file...\n" );
 if( file_unmap( p ) == -1 )
  error( "Cannot unmap file\n" );
 printf( "Locking the file exclusively...\n" );
 if( file_lock( fh, AL_RDWR ) == -1 )
  error( "Failed to lock the file\n" );
 printf( "Unlocking the file...\n" );
 if( file_unlock( fh ) == -1 )
  error( "Failed to unlock the file\n" );
 printf( "Locking the file in shared mode...\n" );
 if( file_lock( fh, AL_READ ) == -1 )
  error( "Failed to lock the file\n" );
 printf( "Unlocking the file...\n" );
 if( file_unlock( fh ) == -1 )
  error( "Failed to unlock the file\n" );
 if( file_close( fh ) == -1 )
  error( "Error closing the file\n" );
 printf( "File size is %ld\n", file_size( tmpname ) );
 printf( "Renaming the file to '%s'...\n", newname );
 if( file_rename( tmpname, newname ) == -1 )
  error( "Failed to rename the file\n" );
 if( ! file_exists( newname ) )
  error( "Strange: renamed file does not exist\n" );
 printf( "Deleting the file '%s'...\n", newname );
 if( file_delete( newname ) == -1 )
  error( "Error deleting the file\n" );

 printf( "Making directory '%s'...\n", simpledir );
 if( fs_mkdir( simpledir ) == -1 )
  error( "Cannot make directory '%s'\n", simpledir );
 printf( "Changing directory to '%s'...\n", simpledir );
 if( fs_chdir( simpledir ) == -1 )
  error( "Failed changing directory to '%s'\n", simpledir );
 if( fs_curdir( cwd ) == NULL )
  error( "Cannot get current directory\n" );
 printf( "Current directory is '%s', changing back to the source directory\n",
          cwd );
 if( fs_chdir( ".." ) == -1 )
  error( "Cannot change back to the source directory\n" );
 printf( "Creating directory hierarchy '%s'...\n", complexdir );
 if( fs_mkdirhier( complexdir ) == -1 )
  error( "Cannot create '%s'\n", complexdir );
 if( ! fs_dir_exists( complexdir ) )
  error( "Strange : created directory does not exist\n" );
 printf( "Removing created directories...\n" );
 for( i = 0; dirs[ i ] != NULL; i++ )
  if( fs_rmdir( dirs[ i ] ) == -1 )
   error( "Cannot remove '%s'\n", dirs[ i ] );
  else
   printf( "Removed : '%s'\n", dirs[ i ] );

 printf( "Obtaining total and free space on '%s'...\n", volume );
 printf( "Total %d KB, free %d KB\n", fs_disktotal( volume ),
          fs_diskfree( volume ) );

 printf( "ALL TESTS PASSED\n" );
 return 0;
}
