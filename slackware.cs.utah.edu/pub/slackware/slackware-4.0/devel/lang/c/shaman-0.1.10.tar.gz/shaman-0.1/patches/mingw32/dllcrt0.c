/*
 * dllcrt0.c
 *
 * Initialization code for DLLs.
 *
 * This code was written to interface with CRTDLL.DLL as supplied with
 * Windows NT and Windows 95, although it could, conceivably, be useful
 * under other circumstances.
 *
 * Contributors:
 *  Created by Colin Peters <colin@bird.fu.is.saga-u.ac.jp>
 *  Pedro A. Aranda gave me a clue about how to get the standard file
 *    handles, which he in turn was told by Jacob Navia.
 *  DLL support adapted from Gunther Ebert <gunther.ebert@ixos-leipzig.de>
 *
 *
 *  THIS SOFTWARE IS NOT COPYRIGHTED
 *
 *  This source code is offered for use in the public domain. You may
 *  use, modify or distribute it freely.
 *
 *  This code is distributed in the hope that it will be useful but
 *  WITHOUT ANY WARRANTY. ALL WARRENTIES, EXPRESS OR IMPLIED ARE HEREBY
 *  DISCLAMED. This includes but is not limited to warrenties of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <process.h>
#include <windows.h>

/* NOTE: The code for initializing, as well as referencing, the standard
 * file handles and the __argv, __argc, and _environ variables has been
 * moved to a separate .c file which is included in both crt0.c and
 * dllcrt0.c. This means changes in the code doesn't have to be manually
 * synchronized, but it does lead to this not-generally-a-good-idea use
 * of include. */
#include "init.c"

/* Unlike normal crt0, I don't initialize the FPU, because the process
 * should have done that already. */


extern BOOL WINAPI DllMain(HANDLE, DWORD, LPVOID);

/****************************************************************
 The following piece of code implements per-module atexit-list,
 separate from the main executable's list, which is inside CRTDLL.
 If we leave things as they are, GCC static constructors/destructors
 will use the main list, and leave there pointers to destructors
 located inside DLL's image. When DLL is unloaded by FreeLibrary(),
 these pointers will become invalid, and the program will crash
 when trying to evaluate the main atexit-list. So atexit() calls
 from inside DLL will never be excecuted correctly.

 The solution is to have a separate atexit-list for each DLL.
 This list will be executed when the DLL is unloaded (either by
 FreeLibrary() or by the system). Since our atexit() is located
 in the startup code, it will be pulled in, thus preventing
 the usage of atexit() from CRTDLL.DLL.

 I worry about two questions:
    - Will it work when one DLL is attached to several processes?
      (I.e. does Win32 DLL have its own data segment?)
    - Will it work under Win32s?
      (Win32s DLLs seem to have the only data segment for all
       attached processes, but I'm not sure and I don't have Win32s :()
 ****************************************************************/

typedef void ( * void_of_void )( void );

static void_of_void * atlist;
static int atnum, atlen;

static int
atexit_init( void )
{
 atlen = 32;
 atlist = malloc( atlen * sizeof( void_of_void ) );
 if( atlist == NULL )
  return -1;
 atnum = 0;
}

static void
atexit_do( void )
{ register int i;
 for( i = atnum - 1; i >= 0; i-- )
  atlist[ i ]();
 free( atlist );
}

int
atexit( void_of_void fun )
{ void_of_void * atnew;
 if( atnum >= atlen )
  {
   /* I'm not sure about realloc():
      will `atlist' be valid pointer if realloc() fails?
      This sutuation is very unlikely, but should be considered.
    */
   atnew = realloc( atlist, ( atlen + 32 ) * sizeof( void_of_void ) );
   if( atnew == NULL )
    return -1;
   atlist = atnew;
   atlen += 32;
  }
 atlist[ atnum++ ] = fun;
 return 0;
}


BOOL WINAPI
DllMainCRTStartup (HANDLE hDll, DWORD dwReason, LPVOID lpReserved)
{
	BOOL bRet;
 
	if (dwReason == DLL_PROCESS_ATTACH)
	{
        	_mingw32_init_stdhandles();
        	_mingw32_init_mainargs();
		/* Create empty atexit-list */
		if( atexit_init() == -1 )
			return 0;
		/* From libgcc.a, calls global class constructors. */
		__main();
	}

	/*
	 * Call the user-supplied DllMain subroutine
	 * NOTE: DllMain is optional, so libmingw32.a includes a stub
	 *       which will be used if the user does not supply one.
	 */
	bRet = DllMain(hDll, dwReason, lpReserved);

	if (dwReason == DLL_PROCESS_DETACH)
	{
		/* From libgcc.a, calls global class destructors. */
		__do_global_dtors();
		/* Evaluate atexit-list */
		atexit_do();
	}

	return bRet;
}

#ifdef	__GNUC__
/*
 * This section terminates the list of imports under GCC. If you do not
 * include this then you will have problems when linking with DLLs.
 */
asm (".section .idata$3\n" ".long 0,0,0,0,0,0,0,0");
#endif
