#include <stdlib.h>
#include <windows.h>

#include "___glob.h"

int
fn_find( char * pattern, char *** res )
{ int nf = 0;
 char ** p;
 HANDLE fh;
 WIN32_FIND_DATA fd;
 int file_found;
 if( ( p = ( char ** )malloc( 1 ) ) == NULL )
  goto OUTERR;
 fh = FindFirstFile( pattern, & fd );

 for( file_found = ( fh != INVALID_HANDLE_VALUE );
      file_found;
      file_found = FindNextFile( fh, & fd ) )
  if( ___add_one_name( & p, & nf, pattern, fd.cFileName ) == -1 )
   break;
 FindClose( fh );
 ___add_one_name( & p, & nf, "", NULL );
 nf--;
OUTERR :
 * res = p;
 return nf;
}

