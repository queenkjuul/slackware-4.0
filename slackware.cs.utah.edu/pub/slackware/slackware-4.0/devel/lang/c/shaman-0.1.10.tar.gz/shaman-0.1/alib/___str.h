#ifndef ___STR_H
#define ___STR_H

#include "astr.h"

int ___acs_init( void );
void ___acs_term( void );

#endif
