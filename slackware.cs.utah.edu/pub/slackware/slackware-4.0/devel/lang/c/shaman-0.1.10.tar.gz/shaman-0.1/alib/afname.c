#include <string.h>
#include <stdlib.h>

#include "astr.h"
#include "___file.h"

char *
fn_fullname( char * to, const char * from )
{ char p[ AL_MAXPATH + 1 ], n[ AL_MAXNAME + 1 ], e[ AL_MAXEXT + 1 ];
 char d[ AL_MAXFULL + 1 ];
 ___file_key_t * b = ( ___file_key_t * )th_getspecific( ___file_key );
 if( to == NULL ) to = b->pp;
 * to = '\0';
 fn_split( from, p, n, e );
 if( * ___fn_getdrv( d, from ) != ___fn_slash() )
  { /* relative path or no path -- add the current directory */
   astr_ncat( to, fs_curdir( d ), AL_MAXFULL );
   astr_ncat( to, ___fn_slash_str(), AL_MAXFULL );
  }
 astr_ncat( to, p, AL_MAXFULL );
 astr_ncat( to, n, AL_MAXFULL );
 astr_ncat( to, e, AL_MAXFULL );
 return to;
}

void
fn_split( const char * fn, char * p, char * n, char * e )
{ register const char * p1, * p2;
 ___file_key_t * b = ( ___file_key_t * )th_getspecific( ___file_key );
 if( p == NULL ) p = b->pp;
 if( n == NULL ) n = b->nn;
 if( e == NULL ) e = b->ee;
 p1 = fn;
 * p = '\0';
 if( ( p2 = strrchr( p1, ___fn_slash() ) ) != NULL )  /* path present */
  {
   astr_ncpy( p, p1, min( p2 - p1 + 1, AL_MAXPATH ) );
   p1 = p2 + 1;
  }
 /* p1 points to the start of the name */
 if( ( p2 = strrchr( p1, '.' ) ) != NULL )   /* extension present */
  {
   astr_ncpy( n, p1, min( p2 - p1, AL_MAXNAME ) );
   astr_ncpy( e, p2, AL_MAXEXT );
  }
 else
  {
   astr_ncpy( n, p1, AL_MAXNAME );
   e[ 0 ] = '\0';
  }
}

char *
fn_basedir( char * to, const char * fname )
{
 ___file_key_t * b = ( ___file_key_t * )th_getspecific( ___file_key );
 if( to == NULL ) to = b->pp;
 fn_split( fname, to, NULL, NULL );
 return to;
}

char *
fn_basename( char * to, const char * fname )
{ char e[ AL_MAXEXT + 1 ];
 ___file_key_t * b = ( ___file_key_t * )th_getspecific( ___file_key );
 if( to == NULL ) to = b->nn;
 fn_split( fname, NULL, to, e );
 astr_ncat( to, e, AL_MAXNAME + AL_MAXEXT );
 return to;
}

char *
fn_getname( char * to, const char * fname )
{
 ___file_key_t * b = ( ___file_key_t * )th_getspecific( ___file_key );
 if( to == NULL ) to = b->nn;
 fn_split( fname, NULL, to, NULL );
 return to;
}

char *
fn_getext( char * to, const char * from )
{
 ___file_key_t * b = ( ___file_key_t * )th_getspecific( ___file_key );
 if( to == NULL ) to = b->ee;
 fn_split( from, NULL, NULL, to );
 return to;
}


char *
fn_chext( char * to, const char * from, const char * ext )
{ register char * p;
 ___file_key_t * b = ( ___file_key_t * )th_getspecific( ___file_key );
 if( to == NULL ) to = b->pp;
 astr_ncpy( to, from, AL_MAXFULL );
 if( ( p = strrchr( to, '.' ) ) != NULL )
  * p = '\0';
 return astr_ncat( to, ext, AL_MAXFULL );
}


char *
fn_apply_path( char * fname, const char * path )
{ register char * p;
 char s[ AL_MAXFULL + 1 ];
 ___file_key_t * b = ( ___file_key_t * )th_getspecific( ___file_key );

 if( file_exists( fname ) )
  return fn_fullname( b->pp, fname );

 astr_ncpy( s, path, AL_MAXFULL );
 for( p = strtok( s, ___fn_colon_str() ); p != NULL;
      p = strtok( NULL, ___fn_colon_str() ) )
  {
   astr_ncpy( b->pp, p, AL_MAXFULL );
   if( b->pp[ strlen( b->pp ) - 1 ] != ___fn_slash() )
    astr_ncat( b->pp, ___fn_slash_str(), AL_MAXFULL );
   astr_ncat( b->pp, fname, AL_MAXFULL );
   if( file_exists( b->pp ) )
    return b->pp;
  }

 return NULL;
}
