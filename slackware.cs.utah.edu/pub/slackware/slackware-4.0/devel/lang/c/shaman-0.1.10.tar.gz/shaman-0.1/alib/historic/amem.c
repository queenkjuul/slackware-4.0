#include <stdlib.h>
#include "amem.h"
#include "amsg.h"

/*#define SAFE_MEM*/
/*#define COUNT_MEMORY*/

static char oumem[] = "MSG_OUT_OF_MEMORY";


#ifndef SAFE_MEM

void *
mem_alloc( int s )
{ void * p = malloc( s );
 if( p == NULL )
  error( oumem );
 return p;
}

void *
mem_realloc( void * p, int n, int s )
{
 if( ( p = realloc( p, n * s ) ) == NULL )
  error( oumem );
 return p;
}

void
mem_free( void * p )
{
 free( p );
}

void
mem_test( void )
{
}

int
mem_allocated( void )
{
 return 0;
}

int
mem_can_alloc( int size )
{ void * p = malloc( size );
 if( p == NULL )
  return 0;
 free( p );
 return 1;
}

#else

static char corrp[] = "MSG_HEAP_CORRUPTED";

#ifdef COUNT_MEMORY
static int allocated = 0;
#endif

struct hd
{
 hd * prev, * next;
#ifdef COUNT_MEMORY
 int size;
#endif
};

static hd hdr = { & hdr, & hdr };

static void
incl( hd * prev, hd * p )
{
 p->prev = prev;
 p->next = prev->next;
 prev->next = p;
 p->next->prev = p;
}

static void
excl( hd * p )
{
 p->prev->next = p->next;
 p->next->prev = p->prev;
}


static void
consist( hd * p )
{
 if( p->prev->next != p || p->next->prev != p )
  error( corrp, p );
}

void *
mem_alloc( int size )
{
 hd * p;

 consist( & hdr );
  /* Allocate memory */
 if( ( p = ( hd * )malloc( size + sizeof( hd ) ) ) == NULL )
  error( oumem );

 incl( & hdr, p );
#ifdef COUNT_MEMORY
 p->size = size;
 allocated += p->size + sizeof( hd );
#endif
 return  ( char * )p + sizeof( hd );
}

void
mem_free( void * pp )
{ hd * p = ( hd * )(( char * )pp - sizeof( hd ));
 consist( p );
 excl( p );
 free( p );
#ifdef COUNT_MEMORY
 allocated -= p->size + sizeof( hd );
#endif
}

void *
mem_realloc( void * addr, int n, int esize )
{ hd * ph, * prev;
 int size = n * esize, osize;
 ph = ( hd * )( ( char * )addr - sizeof( hd ) );
 osize = ph->size;
 consist( ph );
 prev = ph->prev;
 excl( ph );
 if( ( ph = ( hd * )realloc( ph, size + sizeof( hd ) ) ) == NULL )
  error( oumem );
 else          /* alright, include new item */
  incl( prev, ph );
#ifdef COUNT_MEMORY
 ph->size = size;
 allocated += size;
 allocated -= osize;
#endif
 return ( char * )ph + sizeof( hd );
}

void
mem_test( void )
{ hd * p;
 for( p = hdr.next; p != & hdr; p = p->next )
  consist( p );
}

int
mem_allocated( void )
{
#ifdef COUNT_MEMORY
 return allocated;
#else
 return 0;
#endif
}

int
mem_can_alloc( int size )
{ void * p = malloc( size + sizeof( hd ) );
 if( p == NULL )
  return 0;
 free( p );
 return 1;
}

#endif


