#ifndef __linux__
#error "This file is to be compiled under Linux, but __linux__ is undefined"
#endif

#include "___file.h"

char
___fn_slash( void )
{
 return '/';
}

char *
___fn_slash_str( void )
{
 return "/";
}

char *
___fn_colon_str( void )
{
 return ":";
}

char *
___fn_getdrv( char * to, const char * from )
{
 * to = '\0';
 return ( char * )from;
}

