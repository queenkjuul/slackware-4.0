#include <stdio.h>
#include <stdlib.h>

#include "uls.h"
#include "alib.h"

static char ulsfile[] = "test.uls";

static char * ids[] =
{
 "MSG_OUT_OF_MEMORY",
 "MSG_HEAP_CORRUPTED",
 "MSG_LIFE_IS_HARD",
 "MSG_CANNOT_INVENT_ANYMORE",
 "MSG_QUOTE_TEST",
 "MSG_QUOTED_QUOTES",
 NULL
};

int
main( void )
{ register int i;
 alib_init();
 if( uls_init( ulsfile ) == -1 )
  {
   fprintf( stderr, "Cannot open ULS database '%s'\n", ulsfile );
   exit( 0 );
  }
 for( i = 0; ids[ i ] != NULL; i++ )
  printf( "'%s' -> '%s'\n", ids[ i ], uls_get( ids[ i ] ) );
 uls_term();
 return 0;
}
