#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "astr.h"
#include "amsg.h"

#define MAXQ   1024
#define MAXA   1024
#define MAXLEN 1024


int
ask( char * question, ... )
{ register int i;
 register char * p;
 char qq[ MAXLEN + 1 ];
 char * q[ MAXQ ];
 char * a[ MAXA ];
 char answer[ MAXLEN ];
 int nq, na;
 va_list args;

 /* split question into lines delimited by '\n' */
 str_ncpy( qq, question, MAXLEN );
 for( nq = 0, p = strtok( qq, "\n" ); p != NULL && nq < MAXQ;
      nq++, p = strtok( NULL, "\n" ) )
  q[ nq ] = p;

 /* extract and count the answers */
 va_start( args, question );
 for( na = 0; na < MAXA; na++ )
  if( ( a[ na ] = va_arg( args, char * ) ) == NULL )
   break;
 va_end( args );

 /* user interaction */
 for( i = 0; i < nq; i++ )
  printf( "%s\n", q[ i ] );

 for( i = 0; i < na; i++ )
  printf( "%d: %s\n", i + 1, a[ i ] );

 printf( "> " );
 gets( answer );
 return atoi( answer ) - 1; /* very stupid behavior -- treat ununderstood
                               answer as a negation */
}
