#ifndef ULS_H
#define ULS_H

#ifdef __cplusplus
extern "C" {
#endif

/*     USER LANGUAGE SUPPORT     */
/* DEPENDS ON : astr */

/*
   Let's store language-dependent strings in file and identify
   them by string names. These functions will retrieve
   the messages from this file. To change the language of the program
   we can just change the messages file even without recompiling
   anything
 */

 /*
                        FILE FORMAT

                         1. Syntax

   File consists of lines, each line is parsed independently.
   Everything after # is treated as comment, blank lines are ignored.

   A line consists of tokens. Tokens are delimited by any
   blank space (spaces, TABs). To include blank space into
   token, one should enclose it in double quotes (").
   Inside the token, both quoted and not, there may be escaped
   characters :
     \n       LF
     \r       CR
     \t       TAB
     \f       FF
     \b       backspace
     \"       double quote
     \\       backslash
     \#       hash-mark

                        2.Semantics

   A line can be either statement or message description.
   Statement consists of keyword followed by its value(s).
   Now there is the only keyword:

        @charset cp866 | koi8r | cp1251 | iso8859-5

   It may appear several times. All message descriptions
   following @charset statement till the next @charset or
   end of file are treated as being in the specified charset.
   @charset statement may be omitted, the default charset
   is cp866.

   All lines beginning with non-keyword are treated as
   message descarations. A message declaration consists of
   two tokens, the first being message identifier, the second
   being message body. Message identifier is asummed to not
   contain charset-specific characters. Message body is
   automatically translated into the current charset
   (i.e. set by str_set_charset()).

                        3. Example

   @charset cp866

   # This is a Comment. I love comments.
   MSG_OUT_OF_MEMORY   "������ ���稫���"
   MSG_HEAP_CORRUPTED  "��� �ᯮ�祭�" # this line is commented
   MSG_QUOTED_TEST     "\r\n\f\b\t\#\\"
   MSG_QUOTED_QUOTES   "five quoues: \" \" \" \" \" "

  */

/*
   Actions   : parse messages file, create the database
   Arguments : file -- file name
   Value     : 0 if success, -1 if error
 */
int uls_init( const char * file );

/*
   Actions   : destroy messages database
   Arguments : none
   Value     : none
 */
void uls_term( void );

/*
  Actions   : none
  Arguments : none
  Value     : 1 if the database is initialized, 0 otherwise
  ���祭��  : 1 �᫨ ���� ᮮ�饭�� ���樠����஢���, ���� 0
 */
int uls_inited( void );

/*
   Actions   : obtain the message by its identifier
   Arguments : msg -- message identifier
   Value     : pointer to message if the message is found, NULL otherwise
   Comments  : this function must work (return NULL) even if the database
               is not initialized
 */
char * uls_get( const char * msg );

#ifdef __cplusplus
}
#endif

#endif
