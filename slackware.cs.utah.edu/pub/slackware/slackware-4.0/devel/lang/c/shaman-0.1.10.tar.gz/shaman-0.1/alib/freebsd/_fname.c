#ifndef __freebsd__
#error "This file is to be compiled under FreeBSD, but __freebsd__ is undefined"
#endif

#include "afile.h"
#include "___fn.h"

char
___fn_slash( void )
{
 return '/';
}

char *
___fn_slash_str( void )
{
 return "/";
}

char *
___fn_colon_str( void )
{
 return ":";
}

char *
___fn_getdrv( char * to, char * from )
{
 * to = '\0';
 return from;
}

