#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

#include "alib.h"


static void
error( char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 vprintf( fmt, args );
 va_end( args );
 exit( 0 );
}

#include "afile.h"
#include "asys.h"

static char dllfile[] = "dll.dll";
static char dllsym[] = "action";

typedef void ( * void_of_void )( void );

int
main( void )
{ int ok, fh;
 dl_t dh;
 void * p;
 void_of_void sym;
 alib_init();
 printf( "Page size is %d\n", sys_pagesize() );
 if( ( fh = file_open( dllfile, AL_READ ) ) == -1 )
  error( "File %s: cannot open\n", dllfile );
 if( ( p = file_map( fh, NULL ) ) == NULL )
  error( "File %s: cannot map\n", dllfile );
 ok = dl_recog( p, file_size_by_handle( fh ) );
 printf( "File %s: %s\n", dllfile, ok ? "dynamic library" : "unknown" );
 file_unmap( p );
 file_close( fh );
 if( ok )
  {
   if( ( dh = dl_open( dllfile ) ) == AL_DLERROR )
    error( "Cannot load '%s'\n", dllfile );
   printf( "Loaded successfully\n" );
   sym = ( void_of_void )dl_sym( dh, dllsym );
   printf( "Symbol '%s' is at 0x%08lX\n", dllsym, ( uslong )sym );
   if( sym != NULL )
    sym();
   dl_close( dh );
 }
 return 0;
}
