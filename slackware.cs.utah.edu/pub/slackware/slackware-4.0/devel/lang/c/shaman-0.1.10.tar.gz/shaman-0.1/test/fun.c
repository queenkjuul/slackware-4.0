#include "alib.h"
#include "message.h"

#define TH_TEST 101

void
dll_init( void )
{
 message(TH_TEST, 0, "DLL inited");
}

void
dll_finish( void )
{
 message (TH_TEST, 0, "DLL finished");
}

void fun( void ); /* make compiler happy */

void
fun( void )
{
 message (TH_TEST, 0, "Hello, Dl!");
}
