/* $Id$ */
#ifndef _FR_H_H_
#define _FR_H_H_

/* A package making a resource out of a file handle.
 * Started by Goga 5.03.97
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "alib.h"
#include "resource.h"

/* Wrappers around Lib functions that throw Errors on failure */
int  xfile_open  (const char *name, int rdwr);
int  xfile_create (const char *name); /* Mode is always by default */
void xfile_close (int fh);
int  xfile_read  (int fh, void *to, int len);
int  xfile_write (int fh, const void *from, int len);
long xfile_seek (int fh, long offset, int mode);
void xfile_delete (const char *name);
void xfile_rename (const char *from, const char *to);
void xfile_chsize (int fh, long len);
long xfile_tell  (int fh);
long xfile_size (const char *name);
long xfile_size_by_handle (int fh);
void xfile_stat  (char *name, stat_t *st);
void xfile_stat_by_handle (int fh, stat_t *st);
void *xfile_map (int fh, void *addr);
void *xfile_remap (void *addr, int size);
void xfile_unmap (void *map);
void xfs_mkdir (char *dir); /* Mode is default */
void xfs_rmdir (char *dir);
void xfs_chdir (char *dir);
char *xfs_curdir (char *to);
void xfs_mkdirhier (char *dir);
int  xfs_disktotal (char *path);
int  xfs_diskfree  (char *path);

/* Resource corresponding to an open file */

typedef struct _fr_h
{
  Resource r;
  int fd;	/* File handle */
  void *maddr;	/* Mapping address */
} Fr_h;

/* Opening a resource */
void frh_init  (Fr_h *frh, const char *name, int mode, Rs_h *rsh);
void frh_create (Fr_h *frh, const char *name, Rs_h *rsh); /* Mode is not needed */

/* Closing a resource */
void frh_done (Fr_h *frh);

/* Fr_h will only allow a file to be mapped once */
void *frh_map (Fr_h *frh, void *addr);

void *frh_remap (Fr_h *frh, int size);

/* Unmap a file */
void frh_unmap (Fr_h *frh);

/* Traditional sequential input/output
 *  - nothing special is done here.
 */

#define frh_read(frh,to,len) xfile_read ((frh)->fd, to, len)
#define frh_write(frh,from,len) xfile_write((frh)->fd, from, len)
#define frh_lseek(frh,offset,mode) xfile_seek((frh)->fd, offset, mode)
#define frh_truncate(frh,len) xfile_chsize((frh)->fd, len)
#define frh_tell(frh) xfile_tell((frh)->fd)
#define frh_size(frh) xfile_size_by_handle((frh)->fd)
#define frh_stat(frh) xfile_stat((frh)->fd)
#define frh_maddr(frh) ((frh)->maddr)

#endif /* already included*/
