#ifndef ATIME_H
#define ATIME_H

#ifdef __cplusplus
extern "C" {
#endif

/* Date and time operations */
/* DEPEND ON : NOTHING */

/* how many `ticks' correspond to one second */
#define AL_TICKS_PER_SECOND 1000

/* this defines the local timezone, independently of where we are */
#define AL_LOCAL_TZ 0x1000

/*
   Actions   : Initialize internal structures
   Arguments : None
   Value     : 0 on success, -1 on error
 */
int time_init( void );

/*
   Actions   : Free internal structures
   Arguments : None
   Value     : None
 */
void time_term( void );

/*
   Actions   : set current timezone
   Arguments : tz -- timezone (if TIME_TZ_LOCAL, then obtain local timezone
                     from the system)
   Value     : none
   Comments  : this function sets not the system timezone, but the `current'
               timezone in which all the following operations occur
 */
void time_settimezone( int tz );

/*
   Actions   : none
   Arguments : none
   Value     : current timezone
   Comments  : it is NOT the same as system local timezone
 */
int time_gettimezone( void );

/*
  General idea : to have two types for time representation,
                 one being just a number that is easy to store and
                 operate on, another being a structure that can be easily
                 given to user and cheked for correctness.

  32-bit are not enough to represent historical events, so we have to
  use something larger. Since we have not 64-bit machines, let's use
  double for ANSI-compatibility (it seems to have 52 bits per mantisse),
  or `long long' if we do not need strict ANSI.

  Unpacked time is LOCAL
  Packed time is GMT
 */

typedef struct /* comprehensive */
{
 char day;    /* 1-31 */
 char month;  /* 1-12 */
 short year;  /* 1900 -> */
 char hour;   /* 0-23 */
 char min;    /* 0-59 */
 char sec;    /* 0-59 */
 short msec;  /* 0-999 */
} atime_t;

/* convenient to operate on */
typedef double packtime_t;

/* an empty value for packed time */
#define AL_NEVER -1

/*
   Actions   : convert packed time to unpacked form (and GMT to local)
   Arguments : time -- resulting local time
               t    -- number of ticks from the time beginning
   Value     : none
   Comments  : time will always be computed, since any value of
               `ticks' is physically valid. But you must not pass
               anything negative as packed time -- it will yield garbage.
 */
void time_unpack( atime_t * time, packtime_t t );

/*
   Actions   : convert time to packed form (and local to GMT)
   Arguments : time -- local time
   Value     : number of `ticks' from the time beginning
 */
packtime_t time_pack( atime_t * time );

/*
   Actions   : check time for correctness
   Arguments : time -- time to check
   Value     : true if the time is valid, false if invalid
 */
int time_valid( atime_t * time );

/*
   Actions   : discover day of week corresponding to the date
   Arguments : t  -- time
   Value     : day of week (0 - sunday)
 */
int time_dayofweek( packtime_t t );

/*
   Actions   : none
   Arguments : none
   Value     : time in `ticks' from the time beginning
 */
packtime_t time_now( void );


/*
   Actions   : sleep for a given number of milliseconds
   Arsuments : msec -- number of muilliseconds to sleep
   Value     : none
 */
void time_msleep( int msec );

#ifdef __cplusplus
}
#endif

#endif
