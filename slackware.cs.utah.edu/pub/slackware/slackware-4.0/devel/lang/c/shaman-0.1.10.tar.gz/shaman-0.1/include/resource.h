/* $Id$ */
#ifndef _RESOURCE_H_
#define _RESOURCE_H_

/* The resource package */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <setjmp.h>
#include <stdlib.h>
#include <string.h>

#include  "shnana.h"

# include "alib.h"
# include "message.h"

struct _dl_list
{
  struct _dl_list *prev, *next;
};
typedef struct _dl_list Dl_list;

/* Doubly linked list: initialization, inclusion, exclusion */
#define dl_init(dl)  ((dl)->prev = (dl)->next = (dl))
#define dl_insert(elem, dl)					\
          ((elem)->prev = (dl), (elem)->next = (dl)->next,	\
	   (dl)->next->prev = (elem),				\
	   (dl)->next = (elem))
#define dl_excl(elem)				\
          ((elem)->prev->next = (elem)->next,	\
	   (elem)->next->prev = (elem)->prev,	\
	   (elem)->next = (elem)->prev = (elem))

/* For statement header scanning a Dl_list */
#define for_dl_list(var,dl) for (var = (dl)->next;	\
				 var != &(dl);		\
				 var = var->next)

struct _resource;

/* Destructor function type */
typedef void (*rs_dt_fun_t)( struct _resource *);

/* Mutex guarding rs_global */
extern mutex_t rs_mutex;

typedef struct _resource
{
  Dl_list dl;
  rs_dt_fun_t dt_fun;

  u_4 magic;
} Resource;

/* The magic value for resource occupies the elder byte */
#define R_MAGIC_MASK 0xff000000
#define R_MAGIC      0x12000000

struct _rs_h
{
  Resource r;
  struct _rs_h *father;
  Dl_list clients;
  Dl_list mem;

  int n_onoff;
  uslong *vals;
};
typedef struct _rs_h Rs_h;

/* Rs_h magic value is two bytes long */
#define RSH_MAGIC_MASK 0xffff0000
#define RSH_MAGIC      (R_MAGIC | 0x00340000)


/* Initialize a resource holder, register it in Father */
void rsh_init( Rs_h* arg, Rs_h* father );

/* Initialize and register it in rsh_current() */
#define rsh_init_c(a) rsh_init (a, rsh_current())
/* Initialize and register it in rsh_thread() */
#define rsh_init_t(a) rsh_init (a, rsh_thread())

/* Initialize and register it in rsh_global() */
#define rsh_init_g(a) rsh_init (a, rsh_global())

/* Set it as rs_current() -- thread-specific */
void rsh_set( Rs_h* arg );

/* Various combinations */
#define rsh_init_set (a, father) (rsh_init (a, father), rsh_set (a))
#define rsh_init_set_c(a) (rsh_init (a, rsh_current()), rsh_set (a))
#define rsh_init_set_t(a) (rsh_init (a, rsh_thread()), rsh_set (a))
#define rsh_init_set_g(a) (rsh_init (a, rsh_global()), rsh_set (a))

/* Finish the work of Rs_h, destroy all the attached resources */
void rsh_done( Rs_h* arg );

/* Register R in Rsh, Dfun is the destructor function */
void r_register (Resource* r, Rs_h* rsh, rs_dt_fun_t dfun);

/* Unregister R (Dfun is NOT called, so that this function can itself be
   called from inside Dfun).
 */
void r_unregister (Resource* r);

/* Sets the destructor function (useful for derived types) */
void r_set_dfun (Resource *r, rs_dt_fun_t dfun);

/* Current Rs_h, (!!! thread-specific !!!) */
Rs_h *rsh_current( void );

/* Thread-wide Rs_h, Rsh_done at thread exit */
Rs_h *rsh_thread( void );

/* Program-wide Rs_h, it is Rsh_done at exit from the program */
Rs_h *rsh_global( void );

/* Like Malloc, but may call Error */
void* xmalloc( size_t size );

/* Like Malloc, but registers the memory in an Rs_h */
void* rmalloc( size_t size, Rs_h* rsh );

/* Xmalloc/Rmalloc combination */
void* rxmalloc( size_t size, Rs_h* rsh );

/* Meaning should be obvious */
#define rmalloc_c(size) rmalloc (size, rsh_current())
#define rxmalloc_c(size) rxmalloc (size, rsh_current())
#define rmalloc_t(size) rmalloc (size, rsh_thread())
#define rxmalloc_t(size) rxmalloc (size, rsh_thread())
#define rmalloc_g(size) rmalloc (size, rsh_global())
#define rxmalloc_g(size) rxmalloc (size, rsh_global())

void* xrealloc (void* arg, size_t size);
void* rrealloc (void* arg, size_t size);
void* rxrealloc (void* arg, size_t size);

void rfree( void* arg );

/* Put the chunk of memory out of control from the Resource system;
 * later, you should still dispose of it using rfree (not usual free)
 */
void r_forget (void *arg);

/* Free never fails */
#define xfree free
#define rxfree rfree

/* State-saving function */
typedef uslong (*on_fun_t)( void );

/* State-restoring function */
typedef void (*off_fun_t) (uslong arg);

/* Declares On a state saving function  and Off the corresponding
   state restoring function.
 */
void r_attach( on_fun_t on, off_fun_t off );

/* During each Rsh_set initialization
   1. Memory and resource lists are set to empty
   2. All the state saving functions are called,
      their results are saved

   During each Rsh_done Rs_h deletion
   1. The resource lists are scanned, the destructor functions are called.
   2. The memory allocated by r[x]malloc, is freed
   3. The state restoring functions are called with the
   argument returned by the corresponding saving function during
   initialization
 */

/* Error handling subpackage */

struct _jump_h
{
  Rs_h rsh;
  struct _jump_h *father;
  jmp_buf jbuf;
  int theme;

  /* An array of themes that are treated in a different way
     from what is said in Catch
     */
  int n_themes;
  int *themes;

  /* Catch an error that does not belong to Themes? */
  bool catch;
};

typedef struct _jump_h Jump_h;

/* Jump_h magic is three bytes long */
#define JH_MAGIC_MASK 0xffffff00
#define JH_MAGIC      (RSH_MAGIC | 0x00005600)

/* Initializes Jh, namely
   1. Initializes it as Rs_h
   2. Saves (through Setjmp) the state of the program where the
   initialization is called. Sets Jh to catch all errors.
 */
/*!!! Jump_h initialization has to be a macro: includes setjmp. */
#define jh_init(jh, rs_father, jh_father)			\
	do{ /* A trick to allow ';' after the macro call */	\
          (jh)->father = (jh_father);				\
	  (jh)->catch = 1;					\
	  (jh)->n_themes = 0;					\
	  (jh)->themes = NULL;					\
	  rsh_init (& (jh)->rsh, (rs_father));			\
	  r_set_dfun ((Resource*)jh, (rs_dt_fun_t) jh_done);	\
								\
	  if (((jh)->theme = setjmp((jh)->jbuf)) != 0)		\
	    {							\
	      rsh_init (& (jh)->rsh, (rs_father));		\
	    }							\
	  (jh)->rsh.r.magic = JH_MAGIC;				\
	}while (0)

/* The same, with Jh_current and Rsh_current as fathers */
#define jh_init_c(jh) jh_init(jh, rsh_current(), jh_current())

/* The theme of the last error (initially 0) */
#define jh_theme(jh) ((jh)->theme)

/* Sets Jh as the current one, and Rsh_current at the same time
   -- thread-specific!
   */
void jh_set( Jump_h* jh );

/* Combines the two functions
 */
#define jh_init_set(jh, rs_father, jh_father)	\
	do{					\
	  jh_init(jh, rs_father, jh_father);	\
	  jh_set (jh);				\
	}while (0)

/* The same, with current Jump_h and Rs_h */
#define jh_init_set_c(jh) jh_init_set(jh, rsh_current(), jh_current())

/* I don't want to add more shortcut macros, there are too many
   variants. I think there is enough, if not too much, flexibility.
 */

/* Deletes the Jh label, frees resources (through rsh_done) */
void jh_done( Jump_h* jh );

/* Longjumps to the place where Jh_set was issued, makes
   rsh_done ((Rs_h*)jh)
 */
void jh_throw( Jump_h* jh, int val );

/* Allows (Flag==true) or forbids (Flag==false) Jh to catch errors
   with Theme; if Theme == 0, then any theme.
   It is impossible to forbid a Jump_h to catch theme 0
 */
void jh_allow( Jump_h* jh, int theme, bool flag );

/* Tells if Jh catches Theme */
bool jh_catches (Jump_h *jh, int theme);

/* Current Jump_h (!!! thread-specific, and may be NULL !!!)*/
Jump_h *jh_current( void );

/* Prints (using Message) format and the arguments with Theme and
   interest level 0, then jumps to the closest (in the inheritance
   hierarchy) Jump_h able to catch Theme
 */
void error (int theme, char *format, ...);
void verror (int theme, char *format, va_list args);

/* The same, but obtains Format through Str_get */
void ulerror (int theme, char *str, ...);
void vulerror (int theme, char *str, va_list args);

/* Package initialization */
void resource_init ( void );

/* Should be called at the start of every thread */
void resource_thread_init ( void );

/* Called at exit from a thread */
void resource_thread_term ( void );

/***********************************************************************/
/* From now on come purely informational functions that are
 * used primarily in Nana checks.
 * They are not needed for normal programming. Some are stubs, intended
 * to be read by a human, not even by a checking tool.
 *        -- Goga.
 */

/* Does a Dl_list look like one? */
#define dl_alright(dl) ((dl)->next->prev == (dl) 	\
			&& (dl)->prev->next == (dl))

/* Is a Dl_list empty? */
#define dl_empty(dl) ((dl)->next == (dl) && \
		      (dl)->prev == (dl))

/* Is the resource uninitialized ? - we can not test it, therefore
 * always yes.
 */
#define r_uninited(r) TRUE

/* Is the resource initialized ? - test it by checking
 * the magic field
 */
#define r_inited(r) (((r)->magic & R_MAGIC_MASK) == R_MAGIC)

/* Is the resource alright ? - means it is inited and in the list */
#define r_alright(r) (r_inited (r) && dl_alright (& (r)->dl))

/* Is Rs_h initalized? */
#define rsh_inited(rsh) (((rsh)->r.magic & RSH_MAGIC_MASK) == RSH_MAGIC)

/* Is Rs_h alright (a full check)? */
#define rsh_alright(rsh) (rsh_inited(rsh) && r_alright (&(rsh)->r)					\
			  && A(Dl_list *ml = (rsh)->mem.next, ml != & (rsh)->mem, ml = ml->next,	\
			       dl_alright (ml))								\
			  && A(Resource *rl = (Resource*) (rsh)->clients.next,				\
			       rl != (Resource*) &(rsh)->clients, rl = (Resource*) rl->dl.next,		\
			       r_alright (rl)))

/* Number of memory regions in posession of an Rs_h */
#define rsh_nmem(rsh) C(Dl_list *ml = (rsh)->mem.next, ml != & (rsh)->mem, ml = ml->next, TRUE)

/* Number of resource clients in posession of an Rs_h */
#define rsh_nclients(rsh) C(Dl_list *rl = (rsh)->clients.next, rl != & (rsh)->clients, rl = rl->next, TRUE)

/* Is Jump_h initalized? */
#define jh_inited(jh) (((jh)->rsh.r.magic & JH_MAGIC_MASK) == JH_MAGIC)

/* I can see no easy way to check Jump_h sanity */
#define jh_alright(jh) rsh_alright(&(jh)->rsh)

/* A piece of memory is allocated via r(x)malloc */
#define rm_alright(x) ((void*)(x) != NULL && dl_alright((Dl_list*)(x) - 1))

/* The Resource subsystem has forgot about the piece of memory */
#define rm_forgotten(x) ((void*)(x) != NULL && dl_empty((Dl_list*)(x) - 1))

#endif /* already included */
