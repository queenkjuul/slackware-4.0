#ifndef LIB_H
#define LIB_H

#ifdef __cplusplus
extern "C" {
#endif

#include "adefs.h"

#include "ath.h"
#include "astr.h"
#include "asys.h"
#include "atime.h"
#include "afile.h"
#include "uls.h"
#include "aopt.h"


/*
   Actions   : Initialize internal structures
   Arguments : None
   Value     : 0 on success, -1 on error
   Comments  : One must not call alib_thread_init() nor alib_thread_term()
               for the main thread, since alib_init() already calls it.
 */
int alib_init( void );

/*
   Actions   : Initialize thread-specific internal structures
   Arguments : None
   Value     : 0 on success, -1 on error
 */
int alib_thread_init( void );

/*
   Actions   : Free thread-specific internal structures
   Arguments : None
   Value     : None
 */
void alib_thread_term( void );

#ifdef __cplusplus
}
#endif

#endif
