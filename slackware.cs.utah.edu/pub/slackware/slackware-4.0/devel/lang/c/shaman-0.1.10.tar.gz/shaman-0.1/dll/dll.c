#include <stdio.h>
#include <windows.h>

static void
msg( char * fmt )
{
 MessageBox( NULL, fmt, "", MB_OK );
}

void
dll_init( void )
{
 msg( "inited\n" );
}

void action( void ); /* make compiler happy */

void
action( void )
{
 msg( "action\n" );
}

void
dll_finish( void )
{
 msg( "finished\n" );
}


BOOL WINAPI
DllMain( HINSTANCE hinst, DWORD reason, LPVOID reserved )
{
 write( 1, "CALLED with %d\n", 10 );
 switch( reason )
  {
   case DLL_PROCESS_ATTACH :
   case DLL_THREAD_ATTACH  : dll_init();
                             break;
   case DLL_PROCESS_DETACH :
   case DLL_THREAD_DETACH  : dll_finish();
                             break;
  }
 return 1;
}

