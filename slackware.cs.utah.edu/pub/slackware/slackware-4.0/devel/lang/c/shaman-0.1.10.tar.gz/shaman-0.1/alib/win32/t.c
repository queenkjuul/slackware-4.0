#include <windows.h>
#include <stdio.h>

static char *
prot( unsigned p )
{ static char res[ 256 ];
 char * s, * g, * n;
 switch( p & ~( PAGE_GUARD | PAGE_NOCACHE ) )
  {
   case PAGE_READONLY          : s = "R--";
                                 break;
   case PAGE_READWRITE         : s = "RW-";
                                 break;
   case PAGE_WRITECOPY         : s = "WC-";
                                 break;
   case PAGE_EXECUTE           : s = "--X";
                                 break;
   case PAGE_EXECUTE_READ      : s = "R-X";
                                 break;
   case PAGE_EXECUTE_READWRITE : s = "RWX";
                                 break;
   case PAGE_EXECUTE_WRITECOPY : s = "WCX";
                                 break;
   case PAGE_NOACCESS          : s = "---";
                                 break;
   default                     : s = "***";
                                 break;
  }
 g = ( p & PAGE_GUARD ) ? "G" : "-";
 n = ( p & PAGE_NOCACHE ) ? "N" : "-";
 sprintf( res, "%s%s%s(%08X)", s, g, n, p );
 return res;
}

static char *
state( unsigned s )
{
 switch( s )
  {
   case MEM_COMMIT  : return "C";
   case MEM_FREE    : return "F";
   case MEM_RESERVE : return "R";
   default          : return "*";
  }
}

static char *
type( unsigned t )
{
 switch( t )
  {
   case MEM_IMAGE   : return "I";
   case MEM_MAPPED  : return "M";
   case MEM_PRIVATE : return "P";
   default          : return "*";
  }
}

int
main( void )
{ SYSTEM_INFO si;
 MEMORY_BASIC_INFORMATION mi;
 unsigned p, np;
 GetSystemInfo( & si );
 printf( "Min %08X Max %08X page %d granularity %d\n",
         ( unsigned )si.lpMinimumApplicationAddress,
         ( unsigned )si.lpMaximumApplicationAddress,
         si.dwPageSize, si.dwAllocationGranularity );
 printf( "Address  Base     AllocBase    AllocProt       Size    State     Protect     Type\n" );
 for( p = 0; p <= 0xFFFFFFFF; p = np )
  {
   VirtualQuery( ( void * )p, & mi, sizeof( MEMORY_BASIC_INFORMATION ) );
   np = ( unsigned )mi.BaseAddress + mi.RegionSize;
   if( np <= p )
    break;
   printf( "%08X %08X  %08X %s %10u   %s   %s  %s\n", p,
           mi.BaseAddress, mi.AllocationBase,
           prot( mi.AllocationProtect ), mi.RegionSize, state( mi.State),
           prot( mi.Protect ), type( mi.Type ) );
  }
 return 0;
}
