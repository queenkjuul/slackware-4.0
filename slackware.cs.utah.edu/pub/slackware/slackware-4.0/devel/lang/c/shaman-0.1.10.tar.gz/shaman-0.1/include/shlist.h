/* $Id$ */
#ifndef _SHLIST_H_
#define _SHLIST_H_

/* The shlist package */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "misc.h"
#include "resource.h"

struct _shlist
{
  struct _shlist *cdr;
  enum sh_type type;
  any_t car;
};

typedef struct _shlist *Shlist;

/* Create a list */
Shlist shl_cons (enum sh_type type, any_t car, Shlist cdr);

/* Append one list to another (the first list changes, 
 * the elements of the second are shared!)
 */
Shlist shl_append (Shlist shl1, Shlist shl2);

/* Copies a list */
Shlist shl_copy (Shlist shl);

/* Construct a list out of elements.
 * The extra arguments should take the form of type/argument pairs,
 * like the first ones.
 * This list should terminate with a zero.
 */
Shlist shl_list (enum sh_type type1, any_t e1, ...);

/* Destroy a list (The elements are not deleted!) */
void shl_destroy (Shlist shl);

/* An iterator. */
#define for_shlist(ev, shl) for (ev = shl; ev != NULL; ev = ev->cdr)

/* A resource holding Shlist */
typedef struct _r_shlist
{
  Resource r;
  Shlist shl;
} R_shlist;

/* Initialize R_shlist */
void r_shlist_init (R_shlist *rl, Shlist shl, Rs_h *rsh);

/* Destroy R_shlist */
void r_shlist_done (R_shlist *rl);

/* Convention macros */
#define r_shlist_init_c(rl, shl) r_shlist_init (rl, shl, rsh_current ())
#define rshl_get(rl)		((rl)->shl)
#define rshl_set(rl, ll)	((rl)->shl = (ll))

#endif /* Already included */
