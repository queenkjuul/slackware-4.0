/* $Id$ */
/* Implementation of the Resource package */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <string.h>
#include <stdlib.h>

#include "shnana.h" /* Must be included before Nana.h */
#include "misc.h"
#include "resource.h"

/* Max number of On/Off functions */
#define RES_MAX_ONOFF 20

/* State savers/restorers */
static int n_onoff = 0;

static Rs_h global;

static on_fun_t on_fun [RES_MAX_ONOFF];
static off_fun_t off_fun [RES_MAX_ONOFF];

/* A key for thread specific data */
thread_key_t res_thread_key;

/* Mutex guarding rs_global */
mutex_t rs_mutex;

/* Thread specific data */
struct _res_thrspec
{
  Rs_h   *rsh_current;
  Rs_h   *rsh_thread;
  Jump_h *jh_current;
};

void
rsh_init (Rs_h *arg, Rs_h *father)
{
  int i;

  /*--- Nana preconditions */
  ID (int _rc);
  I (r_uninited (arg));
  I (!father || rsh_alright (father));
  IS (_rc = father ? rsh_nclients (father) : 0);
  /*---*/

  arg->father = father;
  dl_init (&arg->clients);
  dl_init (&arg->mem);
  if (father)
    r_register (&(arg->r), father, (rs_dt_fun_t) rsh_done);
  else
    {
      dl_init (& arg->r.dl);
      arg->r.dt_fun = (rs_dt_fun_t) rsh_done;
    }

  arg->n_onoff = 0; /* Careful! - xmalloc may throw an error */
  arg->vals  = (n_onoff != 0) ? xmalloc(sizeof (uslong) * n_onoff) : NULL;
  arg->n_onoff = n_onoff;

  /* Call the state saving functions */
  for (i=0; i<n_onoff; i++)
    arg->vals[i] = on_fun[i] ();

  arg->r.magic = RSH_MAGIC;

  /*--- Nana postconditions */
  I (rsh_alright (arg) && arg->father == father);
  I (rsh_nmem  (arg) == 0 && rsh_nclients (arg) == 0);
  I (!father || (rsh_alright (father) && rsh_nclients (father) == _rc+1));
  /*---*/
}

/* Destroy an Rs_h */
void
rsh_done (Rs_h *arg)
{
  Dl_list * cdl;
  Dl_list * tcdl;
  int i;

  /*--- Nana preconditions */
  I (rsh_alright (arg));
  /*---*/

  /* Call the destructor functions */
  for (cdl = arg->clients.next; cdl != &arg->clients; cdl = tcdl)
    {
      Resource * cr = (Resource*) cdl;
      tcdl = cdl->next;
      cr->dt_fun (cr);
    }

  /* Free the memory */
  for (cdl = arg->mem.next; cdl != &arg->mem; cdl = tcdl)
    {
      tcdl = cdl->next;
      dl_excl (cdl);
      free (cdl);
    }

  /* Call the state restoring functions */
  for (i = 0; i < arg->n_onoff; i++)
    off_fun[i] (arg->vals[i]);

  free (arg->vals);

  if (arg == rsh_current())
    rsh_set (arg->father);

  r_unregister (&arg->r);
  arg->r.magic = 0;

  /*--- Nana postconditions */
  I (r_uninited (&arg->r));
  I (rsh_current () != arg);
  /*---*/
}

void
r_register  (Resource *r, Rs_h *rsh, rs_dt_fun_t dfun)
{
  /*--- Nana preconditions */
  ID (int _rc);
  I (r_uninited (r));
  I (!rsh || rsh_alright (rsh));
  IS (_rc = rsh ? rsh_nclients(rsh) : 0);
  /*---*/

  r->dt_fun = dfun;
  dl_insert (& r->dl, & rsh->clients);
  r->magic = R_MAGIC;

  /*--- Nana postconditions */
  I (r_alright (r) && r->dt_fun == dfun);
  I (!rsh || rsh_alright (rsh));
  I (!rsh || rsh_nclients (rsh) == _rc + 1);
  I (!rsh || E1 (Dl_list * dp = rsh->clients.next, dp != & rsh->clients, dp = dp->next,
		 dp == (Dl_list*) r));
  /*---*/
}

void
r_set_dfun (Resource *r, rs_dt_fun_t dfun)
{
  /*--- Nana preconditions */
  I (r_alright (r));
  /*---*/

  r->dt_fun = dfun;

  /*--- Nana postconditions */
  I (r_alright (r) && r->dt_fun == dfun);
  /*---*/
}

void
r_unregister (Resource *r)
{
  /*--- Nana preconditions */
  I (r_alright (r));
  /*---*/

  dl_excl (& r->dl);
  r->magic = 0;

  /*--- Nana postconditions */
  I (r_uninited (r));
  /*---*/
}

/* Set the current Rs_h */
void
rsh_set (Rs_h *rsh)
{
  struct _res_thrspec * rts;

  /*--- Nana preconditions */
  I (!rsh || rsh_alright (rsh));
  /*---*/

  rts = (struct _res_thrspec*) th_getspecific (res_thread_key);
  rts->rsh_current = rsh;

  /*--- Nana postconditions */
  I ((!rsh || rsh_alright (rsh)) && rsh_current () == rsh);
  /*---*/
}

/* Return the current Rs_h */
Rs_h *
rsh_current ( void )
{
  struct _res_thrspec * rts = (struct _res_thrspec*) th_getspecific (res_thread_key);
  return rts->rsh_current;
}

/* The thread-wide Rs_h */
Rs_h *
rsh_thread ( void )
{
  struct _res_thrspec * rts = (struct _res_thrspec*) th_getspecific (res_thread_key);
  return rts->rsh_thread;
}

/* The global Rs_h */
Rs_h *
rsh_global ( void )
{
  return &global;
}

/* Resource-registering malloc */
typedef void *(*rmalloc_fun_t) (size_t, Rs_h*);

void *
rmalloc (size_t size, Rs_h *rsh)
{
  void * res;
  void * ret;

  /*--- Nana preconditions */
  ID (int _mc);
  I (!rsh || rsh_alright (rsh));
  IS (_mc = rsh ? rsh_nmem (rsh) : 0);
  /*---*/

  if ((res = malloc (size + sizeof(Dl_list))) != NULL)
    {
      if (rsh)
	dl_insert ((Dl_list*)res, &(rsh->mem));
      else
	dl_init ((Dl_list*) res);

      ret = (void*)( ((Dl_list*)res) + 1 );
    }
  else
    ret = res;

  /*--- Nana postconditions */
  I (!rsh || rsh_alright (rsh));
  I (!rsh || !res || rsh_nmem (rsh) == _mc + 1);
  I (!rsh || !res || E1 (Dl_list *ml = rsh->mem.next, ml != & rsh->mem, ml = ml->next,
			 ml == (Dl_list*)ret - 1));
  /* If Res != NULL, then Res is of size Size */
  /*---*/

  return ret;
}

/* Error-reporting malloc, the generalized version receives
   the function that actually gets memory as an argument.
 */
static void *
_xmalloc (size_t size, Rs_h *rsh, rmalloc_fun_t fun)
{
  void *res;

  /*--- Nana preconditions */
  I (!rsh || rsh_alright (rsh));
  /*---*/

  if ((res = fun (size, rsh)) == NULL)
    ulerror (TH_RESOURCE, "RS_no_memory");

  /*--- Nana postconditions */
  I (res != NULL);
  /* Res is of size Size */
  /*---*/

  return res;
}

/* A dummy function to serve as an argument to _xmalloc */
static void *
_malloc (size_t size, Rs_h* qz)
{
  return malloc (size);
}

/* Error-reporting malloc, published version */
void *
xmalloc (size_t size)
{
  return _xmalloc (size, NULL, _malloc);
}

/* Rmalloc and xmalloc combination */
void *
rxmalloc (size_t size, Rs_h* rsh)
{
  return _xmalloc (size, rsh, rmalloc);
}

/* The same focuses with realloc */
void *
rrealloc (void* arg, size_t size)
{
  void * res;

  /*--- Nana preconditions */
  ID (Dl_list *_dl);
  I (!arg || dl_alright (_dl = (Dl_list*)arg - 1));
  /*---*/

  /* Be careful about special argument values */
  if (size == 0)
    {
      rfree (arg);
      res = NULL;
    }
  else if (arg == NULL)
    res = rmalloc (size, rsh_current ()); /* !! Attention !! We have no other holder to use */
  else
    /* Now the processing itself */
    {
      Dl_list * dlp = ((Dl_list*)arg) - 1;
      Dl_list * list = dlp->prev;
      void * nptr;
      Dl_list * ndlp;
      dl_excl (dlp);

      if ((nptr = realloc (dlp, size + sizeof (Dl_list))) == NULL)
	res = NULL;
      else
	{
	  ndlp = (Dl_list*) nptr;
	  if (dlp == list) /* Dlp didn't belong to any list - ndlp won't either */
	    dl_init (ndlp);
	  else
	    dl_insert (ndlp, list);
	  res = (void*) (ndlp + 1);
	}
    }

  /*--- Nana postconditions */
  I (!res || dl_alright ((Dl_list*)res - 1));
  /* If Res != NULL then Res is of size Size */
  /*---*/

  return res;
}

static void *
_xrealloc (void * arg, size_t size, void * (*fun) (void*, size_t))
{
  void * res;

  /*--- Nana preconditions */
  /*---*/

  if ((res = fun (arg, size)) == NULL)
    ulerror (TH_RESOURCE, "RS_no_memory");

  /*--- Nana postconditions */
  I (res != NULL);
  /* Res is of size Size */
  /*---*/

  return res;
}

void *
xrealloc (void *arg, size_t size)
{
  return _xrealloc (arg, size, realloc);
}

void *
rxrealloc (void *arg, size_t size)
{
  return _xrealloc (arg, size, rrealloc);
}

/* Finally (the end of malloc functions) rfree... */
void
rfree (void * arg)
{
  Dl_list *dlp;

  /*--- Nana preconditions */
  I (rm_alright (arg));
  /*---*/

  if (arg == NULL)
    return;

  dlp = (Dl_list*)arg - 1;
  dl_excl (dlp);
  free (dlp);

  /*--- Nana postconditions */
  /* Arg is a freed memory */
  /*---*/
}

/* Forget about a chunk of memory */
void
r_forget (void *arg)
{
  Dl_list *dlp;

  /*--- Nana preconditions */
  I (rm_alright (arg));
  /*---*/

  if (arg == NULL)
    return;

  dlp = (Dl_list*)arg - 1;
  dl_excl (dlp);

  /*--- Nana postconditions */
  I (rm_forgotten (arg));
  /*---*/
}

/* Attaching state saving/restoring functions */
void
r_attach (on_fun_t on, off_fun_t off)
{
  /*--- Nana preconditions */
  ID (int _n_onoff);
  IS (_n_onoff = n_onoff);
  /*---*/

  if (n_onoff == RES_MAX_ONOFF)
    ulerror (TH_RESOURCE, "RS_too_many_on_off");

  on_fun  [n_onoff] = on;
  off_fun [n_onoff] = off;
  n_onoff++;

  /*--- Nana postconditions */
  I (n_onoff == _n_onoff + 1);
  /*---*/
}

/* Now here comes the error catching part */

/** Jh_init is a macro **/

/* Set the current Jump_h -- thread specific */
void
jh_set (Jump_h *jh)
{
  struct _res_thrspec * rts;
  /*--- Nana preconditions */
  I (!jh || jh_alright (jh));
  /*---*/

  rts = (struct _res_thrspec*) th_getspecific (res_thread_key);
  rsh_set(& jh->rsh);
  rts->jh_current = jh;

  /*--- Nana postconditions */
  I (!jh || jh_alright (jh));
  I (jh_current () == jh);
  I (!jh || rsh_current () == & jh->rsh);
  /*---*/
}

/* Return the current Jump_h -- thread specific */
Jump_h *
jh_current ( void )
{
  struct _res_thrspec * rts = (struct _res_thrspec*) th_getspecific (res_thread_key);
  return rts->jh_current;
}

/* Finish the work of Jump_h */
void
jh_done (Jump_h *jh)
{
  /*--- Nana preconditions */
  I (jh_alright (jh));
  /*---*/

  free (jh->themes);
  rsh_done (& jh->rsh);

  if (jh == jh_current())
    {
      Rs_h * cc;
      /* Jh_set sets also rsh_current, and it is already correctly reset */
      cc = rsh_current ();
      jh_set (jh->father);
      rsh_set (cc);
    }

  /*--- Nana postconditions */
  I (r_uninited (& jh->rsh.r));
  I (jh_current () != jh);
  /*---*/
}

/* Throw control to the place where Jh_init was issued */
void
jh_throw(Jump_h *jh, int val)
{
  /*--- Nana preconditions */
  I (jh_alright (jh));
  I (val != 0);
  /*---*/
  jh_done (jh);
  longjmp (jh->jbuf, val);

  /*--- Nana postconditions */
  I (FALSE); /* never reached */
  /*---*/
}

/* Allow/forbid catching a particular theme.
   Theme = 0 means all themes.
   */
/*** No special care for effectiveness; the operation seems to me
     quite exotic.
         -- Goga
 */
void
jh_allow (Jump_h *jh, int theme, bool flag)
{
  /*--- Nana preconditions */
  I (jh_alright (jh));
  /*---*/

  if (theme == 0)
    {
      /* The special case */
      free (jh->themes);
      jh->themes = NULL;
      jh->n_themes = 0;
      jh->catch = flag;
    }
  else
    {
      if (jh->catch == flag)
	{
	  /* Maybe we have to exclude the theme from the list */
	  int ix;
	  for (ix=0; ix<jh->n_themes; ix++)
	    if (jh->themes[ix] == theme)
	      break;
	  if (ix != jh->n_themes) /* found something */
	    {
	      jh->n_themes--;
	      if (jh->n_themes == 0)
		{
		  free (jh->themes);
		  jh->themes = NULL;
		}
	      else
		{
		  int * nthe; /* the new value for jh->themes */
		  nthe = xmalloc (jh->n_themes * sizeof (int));
		  memcpy (nthe, jh->themes, ix * sizeof(int));
		  memcpy (& nthe[ix], & jh->themes[ix+1], (jh->n_themes - ix) * sizeof (int));
		  free (jh->themes);
		  jh->themes = nthe;
		}
	    }
	}
      else /* jh->catch != flag */
	{
	  /* Maybe we need to add a theme to the list */
	  int ix;
	  for (ix = 0; ix < jh->n_themes; ix++)
	    if (jh->themes[ix] == theme)
	      break;
	  if (ix == jh->n_themes) /* not found */
	    {
	      int * nthe; /* The new value for jh->themes */
	      nthe = xmalloc ((jh->n_themes + 1) * sizeof(int));
	      memcpy (nthe, jh->themes, jh->n_themes * sizeof(int));
	      nthe [jh->n_themes] = theme;
	      jh->n_themes ++;
	      free (jh->themes);
	      jh->themes = nthe;
	    }
	}
    }

  /*--- Nana postconditions */
  I (jh_alright (jh));
  I (theme || jh_catches (jh, theme) == flag);
  /*---*/
}

/* Tell if Jh catches errors of Theme */
bool
jh_catches (Jump_h *jh, int theme)
{
  bool found; /* Is Theme in list? */
  bool res;
  int i;

  /*--- Nana preconditions */
  I (jh_alright (jh));
  /*---*/

  if ( theme == 0)
    res = TRUE;
  else
    {
      found = FALSE;
      for (i=0; i < jh->n_themes; i++)
	if (jh->themes[i] == theme)
	  {
	    found = TRUE;
	    break;
	  }
      res = (bool)(jh->catch ^ found);
    }

  /*--- Nana postconditions */
  /*---*/

  return res;
}

/* Error function - a reporting function as an additional argument */
typedef void (*vmess_fun_t) (int theme, int level, char *str, va_list arg);

static void
_error (int theme, char *str, va_list arg, vmess_fun_t vmess)
{
  Jump_h *jh;

  /*--- Nana preconditions */
  /*---*/

  vmess (theme, 0, str, arg);

  for ( jh = jh_current(); jh != NULL; jh = jh->father)
    if (jh_catches (jh, theme))
      jh_throw (jh, theme);

  /* Nowhere to jump */
  ulmessage (TH_RESOURCE, 0, "RS_nowhere_to_jump", theme);
  exit (EXIT_FAILURE);

  /*--- Nana postconditions */
  I (FALSE); /* never reached */
  /*---*/
}

/* Error functions - one sifts the format through Str_get, the other does not */
void
error (int theme, char *format, ...)
{
  va_list arg;
  /*--- Nana preconditions */
  /*---*/
  va_start (arg, format);
  _error (theme, format, arg, vmessage);

  /*--- Nana postconditions */
  I (FALSE); /* never reached */
  /*---*/
}

void
verror (int theme, char *format, va_list args)
{
  /*--- Nana preconditions */
  /*---*/
  _error (theme, format, args, vmessage);
  /*--- Nana postconditions */
  I (FALSE); /* never reached */
  /*---*/
}

void
ulerror (int theme, char *str, ...)
{
  va_list arg;

  /*--- Nana preconditions */
  /*---*/
  va_start (arg, str);
  _error (theme, str, arg, vulmessage);

  /*--- Nana postconditions */
  I (FALSE); /* never reached */
  /*---*/
}

void
vulerror (int theme, char *str, va_list args)
{
  /*--- Nana preconditions */
  /*---*/
  _error (theme, str, args, vulmessage);
  /*--- Nana postconditions */
  I (FALSE); /* never reached */
  /*---*/
}

/* Routine called at exit from the program */
static void
res_exit_program ( void )
{
  /*--- Nana preconditions */
  I (rsh_alright (rsh_global ()));
  /*---*/
  resource_thread_term ();
  rsh_done (rsh_global());
  mutex_destroy (rs_mutex);
}

/* Called at exit from a thread */
void
resource_thread_term ( void )
{
  struct _res_thrspec *ths;

  /*--- Nana preconditions */
  I (rsh_alright (rsh_thread ()));
  /*---*/

  mutex_lock (rs_mutex);
  ths = (struct _res_thrspec*) th_getspecific (res_thread_key);
  rsh_done (ths->rsh_thread);
  free (ths->rsh_thread);
  free (ths);
  mutex_unlock (rs_mutex);
}

/* Need to define the type to bypass strict ANSI C typing */
typedef void (*ptkc_arg) (void*);

/* Resource package initialization routine */
void
resource_init ( void )
{
  /*--- Nana preconditions */
  /*---*/

  /* Here, we are extremely careful: resources don't work yet and we test
     every function.
     */

  rs_mutex = mutex_create ();
  if (rs_mutex == AL_NOMUTEX)
    {
      ulmessage (TH_RESOURCE, 0, "RS_thread_mutex_creation_fail");
      exit (EXIT_FAILURE);
    }

  /* Ensure cleanup at the end of the program */
  atexit (res_exit_program);


  res_thread_key = th_key_create ();
  if (res_thread_key == AL_NOKEY)
    {
      ulmessage (TH_RESOURCE, 0, "RS_thread_key_creation_fail");
      exit (EXIT_FAILURE);
    }

  /* Make rsh_global */
  rsh_init (&global, NULL);

  /* Initialize the main thread */
  /* I don't believe anything will go wrong here */
  resource_thread_init ();
}

/* Thread initialization */
void
resource_thread_init ( void )
{
  struct _res_thrspec *tspt;
  Rs_h *thrsh;

  /*--- Nana preconditions */
  /*---*/

  /* Set the thread specific data */
  tspt = xmalloc(sizeof (struct _res_thrspec));
  memset (tspt, 0, sizeof (struct _res_thrspec));
  th_setspecific (res_thread_key, (any_t)tspt);

  /* Now initialize rs_thread and set it as rs_current */
  thrsh = (Rs_h*) xmalloc (sizeof(Rs_h));
  tspt->rsh_thread = thrsh;
  mutex_lock (rs_mutex);
  rsh_init_set_g (thrsh);
  mutex_unlock (rs_mutex);

  /* No current Jump_h at the start of a thread */
  tspt->jh_current = NULL;
}
