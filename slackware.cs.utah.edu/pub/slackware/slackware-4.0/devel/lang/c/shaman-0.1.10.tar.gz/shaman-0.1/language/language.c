/* $Id$ */
/*
 * This should be an interface that would connect Shaman to
 * an arbitrary language interpreter.
 *
 * The basic Language system.
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
/**/ /* #define USE_NANA */

#include <string.h>

#include "shnana.h"
#include "alib.h"
#include "resource.h"
#include "fr_h.h"
#include "r_thread.h"
#include "language.h"
#include "shlist.h"
#include "misc.h"

/* Interpreters are stored in a table. The table is allocated in
 * chunks this size long.
 */
#define LANG_CHUNK 16

/* An array that keeps all the interpreter defining structures */
static Lang ** lang_arr = NULL;

/* How many interpreters do we have? */
unsigned lang_num_regd = 0;

/* Interpreter registration is protected by this mutex */
static mutex_t lang_mutex;

/* Register a new interpreter in the system */
void
lang_register  (Lang *ll)
{
  R_lock rl;
  /*--- Nana preconditions */
  ID (int _nl);
  IS (_nl = lang_num_regd);
  /*---*/

  r_lock_init_c (&rl, lang_mutex);
  {
    Lang ** newarr;
    if (lang_num_regd % LANG_CHUNK == 0)
      {
	if ((newarr = malloc ((lang_num_regd + LANG_CHUNK) * sizeof (Lang*)))
	    == NULL)
	  {
	    mutex_unlock (lang_mutex); /* Be very careful about mutexi! */
	    ulerror (TH_RESOURCE, "RS_no_memory");
	  }
	memcpy (newarr, lang_arr, lang_num_regd * sizeof (Lang*));
	free (lang_arr);
	lang_arr = newarr;
      }

    lang_arr [lang_num_regd++] = ll;
    ll->magic = LANG_MAGIC;
  }
  r_lock_done (&rl);

  /*--- Nana postconditions */
  I (lang_num_regd == _nl + 1);
  I (lang_arr != NULL);
  /* No mutexi are left locked */
  /*---*/
}

/* I-th registered interpreter (no internal checks) */
Lang *
lang_regd (int i)
{
  Lang * res;

  /*--- Nana preconditions */
  I (i >= 0 && i < lang_num_regd);
  /*---*/

  /* Tired of all this safe programming! -- Goga */

  mutex_lock (lang_mutex);
  res = lang_arr [i];
  mutex_unlock (lang_mutex);

  /*--- Nana postconditions */
  I (res == lang_arr [i]);
  /* No mutexes are left locked */
  /*---*/

  return res;
}

/* Get the interpreter by name (NULL if not found) */
Lang *
lang_get_interpreter_by_name (const char *name)
{
  Lang *res = NULL;
  unsigned i;

  /*--- Nana preconditions */
  I (name != NULL);
  /*---*/

  mutex_lock (lang_mutex);
  for (i = 0; i < lang_num_regd; i++)
    if (strcmp (lang_arr[i]->name, name) == 0)
      {
	res = lang_arr[i];
	break;
      }
  mutex_unlock (lang_mutex);

  /*--- Nana postconditions */
  I (res == NULL || strcmp (res->name, name) == 0);
  /*---*/

  return res;
}

/* Loads a  program text into an internal representation
 * of the interpreter.
 * The program text is in a file, referenced by name.
 * After the program is loaded, the file is no longer needed.
 */
prog_t
lang_load_file (Lang *ll, const char *fname)
{
  prog_t res = 0;

  /*--- Nana preconditions */
  I (lang_inited (ll) && fname != NULL);
  /*---*/

  if (ll->load_file != NULL)
    res = ll->load_file (fname);
  else if (ll->load_mem != NULL)
    {
      void *mem;
      int fh;

      if ((fh = file_open (fname, AL_READ)) == -1)
	ulerror (TH_LANGUAGE, "Lang_cannot_open%s", fname);
      if ((mem = file_map (fh, NULL)) == NULL)
	ulerror (TH_LANGUAGE, "Lang_cannot_map%s", fname);
      res = ll->load_mem (mem, file_size_by_handle (fh));
      file_unmap (mem);
      file_close (fh);
    }
  else
    ulerror (TH_LANGUAGE, "Lang_no_load_method_for_file_%s_%s", ll->name, fname);

  /*--- Nana postconditions */
  I (prog_t_alright (res));
  /*---*/

  return res;
}

/* Loads a  program text into an internal representation
 * of the interpreter.
 * The program text is in a memory area.
 * After the program is loaded, the text is no longer needed.
 */
prog_t
lang_load_mem  (Lang *ll, const void *mem, uslong len)
{
  prog_t res = 0;
  char fname[ AL_MAXFULL + 1 ];
  /*--- Nana preconditions */
  I (lang_inited (ll));
  /*---*/

  if (ll->load_mem != NULL)
    res = ll->load_mem (mem, len);
  else if (ll->load_file != NULL)
    {
      int fh;

      /*!!!! This is not reliable - what if somebody opens the file
       * with the same name at the same time?
       *		-- Goga
       */
      tmpnam(fname);
      astr_ncat( fname, ".tmp", AL_MAXFULL );
      if ((fh = file_create (fname)) == -1)
	ulerror (TH_LANGUAGE, "Lang_cannot_open_file_%s", fname);
      file_write (fh, mem, len);
      file_close (fh);

      res = ll->load_file (fname);
      file_delete (fname);
    }
  else
    ulerror (TH_LANGUAGE, "Lang_no_load_method_for_memory_%s", ll->name);

  /*--- Nana postconditions */
  I (prog_t_alright (res));
  /*---*/

  return res;
}

/* Call a function by name */
any_t
lang_evalv_by_name (Lang *lang, prog_t prog, const char *fun_name,
		    sh_type rest, sh_type *argt, va_list arg)
{
  fun_t fun;
  uslong res;

  /*--- Nana preconditions */
  I (lang_inited (lang) && prog_t_alright (prog) && fun_name != NULL);
  /*---*/

  if ((fun = lang_get_fun (lang, prog, fun_name)) == LANG_NO_FUN)
    ulerror (TH_LANGUAGE, "Lang_no_function_%s_%x_%s", lang->name, prog, fun_name);
  res = lang_evalv (lang, fun, rest, argt, arg);
  lang_release_fun (lang, fun);

  /*--- Nana postconditions */
  /*---*/

  return res;
}

/* Convert the next argument in Arg into language reresentation */
ldata_t
lang_to_va_list (Lang * ll, sh_type type, va_list *arg)
{
  ldata_t res = 0;

  /*--- Nana preconditions */
  I (lang_inited (ll) && (type <= SHT_NONE || type >= SHT_STRING));
  /*---*/

  switch (type)
    {
    case SHT_INTERNAL:
      res = lang_to (ll, (any_t) va_arg (*arg, any_t), type);
      break;
    case SHT_BOOL:
      res = lang_to (ll, (any_t) va_arg (*arg, bool), type);
      break;
    case SHT_CHAR:
      res = lang_to (ll, (any_t) va_arg (*arg, char), type);
      break;
    case SHT_INT:
      res = lang_to (ll, (any_t) va_arg (*arg, int), type);
      break;
    case SHT_FLOAT:
      {
	double t;
	t = va_arg (*arg, double);
	res = lang_to (ll, (any_t)&t, type);
      }
      break;
    case SHT_STRING:
      res = lang_to (ll, (any_t) va_arg (*arg, char*), type);
      break;
    case SHT_LIST:
      res = lang_to (ll, (any_t) va_arg (*arg, Shlist), type);
      break;
    case SHT_NONE:
      ulerror (TH_LANGUAGE, "Lang_bad_argument_lang_to_va_list");
    }

  /*--- Nana postconditions */
  /*---*/

  return res;
}

/* What language is the file written in? */
Lang *
lang_examine_file (const char *fname)
{
  Fr_h frh;
  void *mem;
  uslong len;
  Lang *res;

  /*--- Nana preconditions */
  I (fname != NULL);
  /*---*/

  frh_init (&frh, fname, AL_READ, rsh_current());
  len = frh_size (&frh);
  mem = frh_map (&frh, NULL);

  res = lang_examine_mem (mem, len);

  /*--- Nana postconditions */
  /* Have to put it here, while mem/len exist */
  I(res == NULL || lang_recog(res, mem, len));
  /*---*/

  frh_unmap (&frh);
  frh_done (&frh);

  /*--- Nana postconditions */
  /* File is properly unmapped and closed */
  /*---*/

  return res;
}

/* What language is the memory area written in? */
Lang *lang_examine_mem (const void *mem, uslong len)
{
  Lang *res;
  unsigned i;

  /*--- Nana preconditions */
  I (mem != NULL && len > 0);
  /*---*/

  res = NULL;
  for (i = 0; i < lang_num_regd; i++)
    if (lang_recog (lang_arr[i], mem, len))
      {
	res = lang_arr [i];
	break;
      }

  /*--- Nana postconditions */
  I(res == NULL || lang_recog(res, mem, len));
  /*---*/

  return res;
}


extern Lang lang_native;

/* Initialize the package (actually registers the "native" interpreter type */
void lang_init ( void )
{
  /*--- Nana preconditions */
  I (lang_num_regd == 0);
  /*---*/

  lang_mutex = mutex_create ();
  if (lang_mutex == AL_NOMUTEX)
    ulerror (TH_LANGUAGE, "Lang_cannot_create_mutex");

  lang_register (&lang_native);

  /*--- Nana postconditions */
  I (lang_num_regd == 1 && lang_inited (&lang_native));
  /*---*/
}
