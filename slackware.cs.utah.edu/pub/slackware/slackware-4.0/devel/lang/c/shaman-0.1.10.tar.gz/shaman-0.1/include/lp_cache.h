/* $Id$ */
/*
 * Language programs cache.
 */
#ifndef _LP_CACHE_H_
#define _LP_CACHE_H_

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "cache.h"
#include "language.h"

#define LPC_SIZE_DEFAULT 20

enum lpc_type {LPC_FILE, LPC_MEM};

typedef struct _lpc_key
{
  enum lpc_type tp;
  union _lpc_union
  {
    const char *fname;
    struct _mem
    {
      const void *addr;
      uslong len;
    } m;
  } u;
} Lpc_key;

typedef struct _lpc_info
{
  Lang *lang;
  prog_t prog;
} Lpc_info;

typedef struct _lpc_entry
{
  Cache_entry ce;
  Lpc_key key;	/* Store a copy of the key here, reallocating Fname */
  Lpc_info info;
} Lpc_entry;

/* The language program cache itself.
 * Normally, explicit reference to it is not needed
 * but if you still want it to do something unusual,
 * here it is.
 */
extern Cache lp_cache;

/* Get Lpc_info corresponding to fname / mem+len */
Lpc_info *lpc_lookup_file (const char *fname);
Lpc_info *lpc_lookup_mem  (const void *mem, uslong len);

/* Unlock the entry */
void lpc_unlock (Lpc_info *e);

/* The highest level Language call functions */
any_t lpc_eval_file  (const char *fname, const char *fun,
		      sh_type rest, sh_type *argt, ...);
any_t lpc_evalv_file (const char *fname, const char *fun,
		      sh_type rest, sh_type *argt,
		      va_list argv);
any_t lpc_eval_mem   (const void *mem, uslong len, const char *fun,
		      sh_type rest, sh_type *argt, ...);
any_t lpc_evalv_mem  (const void *mem, uslong len, const char *fun,
		      sh_type rest, sh_type *argt,
		      va_list argv);

/* Initialize the package */
void lpc_init (int size);

/***********************************************************************/
/* From now on come purely informational functions that are
 * used primarily in Nana checks.
 * They are not needed for normal programming. Some are stubs, intended
 * to be read by a human, not even by a checking tool.
 *        -- Goga.
 */

#define lpkey_alright(lpk) ((lpk)->tp == LPC_FILE 				\
			      ? (lpk)->u.fname != NULL				\
			    : (lpk)->tp == LPC_MEM 				\
			      ? (lpk)->u.m.addr !=NULL && (lpk)->u.m.len > 0	\
			      : FALSE)

#define lpinfo_alright(lpi) ((lpi)->lang != NULL && (lpi)->prog != 0)

/* Cache_entry testing not included */
#define lpentry_alright(lpe) (lpkey_alright (&(lpe)->key)	\
			      && lpinfo_alright (&(lpe)->info))

#endif /* already included */
