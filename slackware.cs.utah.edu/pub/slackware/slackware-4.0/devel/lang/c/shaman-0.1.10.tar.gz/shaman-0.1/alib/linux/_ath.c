#ifndef __linux__
#error "This file is to be compiled under Linux, but __linux__ is not defined"
#endif

#define _POSIX_SOURCE 1

#include <time.h>
#include <pthread.h>
#include <stdlib.h>

#include "ath.h"

typedef void * ( * pvoid_of_pvoid )( void * );

thread_t 
th_create( thread_start_t start, any_t arg )
{ pthread_t res;
 if( pthread_create( & res, NULL, ( pvoid_of_pvoid )start, ( void * )arg ) 
     != 0 )
  return AL_NOTHREAD;
 return ( thread_t )res;
}

void
th_exit( any_t retval )
{
 pthread_exit( ( void * )retval );
}

int
th_join( pthread_t th, any_t * res )
{
 return pthread_join( ( pthread_t )th, ( void ** )res ) != 0 ? -1 : 0;
}

int
th_equal( thread_t th1, thread_t th2 )
{
 return pthread_equal( ( pthread_t )th1, ( pthread_t )th2 );
}

thread_t
th_self( void )
{
 return ( thread_t )pthread_self();
}

thread_key_t
th_key_create( void )
{ pthread_key_t res;
 if( pthread_key_create( & res, NULL ) != 0 )
  return AL_NOKEY;
 return ( thread_key_t )res;
}

int
th_key_delete( thread_key_t key )
{
 return pthread_key_delete( ( pthread_key_t )key ) != 0 ? -1 : 0;
}

int
th_setspecific( thread_key_t key, any_t val )
{
 return pthread_setspecific( ( pthread_key_t )key, ( void * )val ) != 0
        ? -1 : 0;
}

any_t
th_getspecific( thread_key_t key )
{
 return ( any_t )pthread_getspecific( ( pthread_key_t )key );
}

static pthread_mutex_t mutex_pat = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;

mutex_t
mutex_create( void )
{ pthread_mutex_t * m;
 if( ( m = ( pthread_mutex_t * )malloc( sizeof( pthread_mutex_t ) ) ) == NULL )
  return AL_NOMUTEX;
 memcpy( m, & mutex_pat, sizeof( pthread_mutex_t ) );
 return ( mutex_t )m;
}

int
mutex_destroy( mutex_t m )
{ int res;
 res = pthread_mutex_destroy( ( pthread_mutex_t * )m ) != 0 ? -1 : 0;
 free( ( pthread_mutex_t * )m );
 return res;
}

int
mutex_lock( mutex_t m )
{
 return pthread_mutex_lock( ( pthread_mutex_t * )m ) != 0 ? -1 : 0;
}

int
mutex_trylock( mutex_t m )
{ 
 return pthread_mutex_trylock( ( pthread_mutex_t * )m ) != 0 ? -1 : 0;
}

int
mutex_unlock( mutex_t m )
{
 return pthread_mutex_unlock( ( pthread_mutex_t * )m ) != 0 ? -1 : 0;
}

condition_t
cond_create( void )
{ condition_t res = AL_NOCOND;
 pthread_cond_t * c;
 if( ( c = ( pthread_cond_t * )malloc( sizeof( pthread_cond_t ) ) ) == NULL )
  return res;
 if( pthread_cond_init( c, NULL ) != 0 )
  free( c );
 else
  res = ( condition_t )c;
 return res;
}

int
cond_destroy( condition_t c )
{ int res; 
 res = pthread_cond_destroy( ( pthread_cond_t * )c ) != 0 ? -1 : 0;
 free( ( pthread_cond_t * )c );
 return res;
}

int
cond_signal( condition_t c )
{
 return pthread_cond_signal( ( pthread_cond_t * )c ) != 0 ? -1 : 0;
}

int
cond_wait( condition_t c, mutex_t m )
{
 return pthread_cond_wait( ( pthread_cond_t * )c, ( pthread_mutex_t * )m ) != 0
        ? -1 : 0;
}

int
cond_timedwait( condition_t c, mutex_t m, int ms )
{ struct timeval cur; 
 struct timespec end;
 gettimeofday( & cur, NULL );
 end.tv_sec = cur.tv_sec + ms / 1000;
 end.tv_nsec = ms % 1000 * 1000000;
 return pthread_cond_timedwait( ( pthread_cond_t * )c, ( pthread_mutex_t * )m,
                                & end ) != 0 ? -1 : 0;
}








