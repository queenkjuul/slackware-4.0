#include <string.h>

#include "astr.h"
#include "___file.h"

char
___fn_slash( void )
{
 return '\\';
}

char *
___fn_slash_str( void )
{
 return "\\";
}

char *
___fn_colon_str( void )
{
 return ";";
}

char *
___fn_getdrv( char * to, const char * from )
{ char l = to_upper( * from );
 if( from[ 1 ] == ':' && l >= 'A' && l <= 'Z' ) /* drive present */
  {
   to[ 0 ] = l;
   to[ 1 ] = ':';
   to[ 2 ] = '\0';
   from += 2;
  }
 else
  to[ 0 ] = '\0';
 return ( char * )from;
}







