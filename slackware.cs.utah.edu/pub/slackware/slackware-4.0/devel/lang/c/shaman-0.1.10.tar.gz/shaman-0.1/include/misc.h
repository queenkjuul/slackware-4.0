/* $Id$ */

#ifndef _MISC_H_
#define _MISC_H_

/* Various stuff that wouldn't fit anywhere else */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* Types enumeration */
typedef enum sh_type { SHT_NONE, SHT_INTERNAL,
		       SHT_BOOL, SHT_CHAR, SHT_INT, SHT_FLOAT, SHT_STRING,
		       SHT_LIST }
	sh_type;

/* maybe much more ... */

/* Themes for Message for various packages */
#define TH_RESOURCE	1
#define TH_DL_H		2
#define TH_FILE		3
#define TH_LANGUAGE	4
#define TH_CACHE	5

#endif /* already included */
