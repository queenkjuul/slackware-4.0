#include <windows.h>

#include "___file.h"

int
fs_mkdir( const char * dir )
{
 SECURITY_ATTRIBUTES sa;
 sa.nLength = sizeof( SECURITY_ATTRIBUTES );
 sa.lpSecurityDescriptor = NULL;
 sa.bInheritHandle = 0;
 return CreateDirectory( dir, & sa ) ? 0 : -1;
}

int
fs_rmdir( const char * dir )
{
 return RemoveDirectory( dir ) ? 0 : -1;
}

int
fs_chdir( const char * dir )
{
 return SetCurrentDirectory( dir ) ? 0 : -1;
}

char *
fs_curdir( char * to )
{ ___file_key_t * p = ( ___file_key_t * )th_getspecific( ___file_key );
 if( to == NULL ) to = p->pp;
 return GetCurrentDirectory( AL_MAXFULL, to ) > 0 ? to : NULL;
}

int
fs_disktotal( const char * path )
{
 char s[ AL_MAXFULL + 1 ];
 DWORD bps, spc, total, free;
 fn_fullname( s, path );
 s[ 3 ] = '\0';
 if( ! GetDiskFreeSpace( s, & spc, & bps, & free, & total ) )
  return -1;
 return total * spc / 1024 * bps;
}

int
fs_diskfree( const char * path )
{
 char s[ AL_MAXFULL + 1 ];
 DWORD bps, spc, total, free;
 fn_fullname( s, path );
 s[ 3 ] = '\0';
 if( ! GetDiskFreeSpace( s, & spc, & bps, & free, & total ) )
  return -1;
 return free * spc / 1024 * bps;
}
