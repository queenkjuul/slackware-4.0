#include <stdlib.h>
#include "alib.h"

static int inited = 0;

static void
alib_term( void )
{
 if( ! inited )
  return;
 file_term();
 time_term();
 astr_term();
 inited = 0;
}

int
alib_init( void )
{
 if( astr_init() == -1 || time_init() == -1 || file_init() == -1 )
  return -1;
 atexit( alib_term );
 inited = 1;
 return 0;
}

int
alib_thread_init( void )
{
 return file_thread_init();
}

void
alib_thread_term( void )
{
 file_thread_term();
}
