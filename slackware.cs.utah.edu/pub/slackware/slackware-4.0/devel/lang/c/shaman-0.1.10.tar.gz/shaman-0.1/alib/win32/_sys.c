#include <windows.h>

#include "asys.h"

int
sys_pagesize( void )
{ SYSTEM_INFO si;
 GetSystemInfo( & si );
 return si.dwPageSize;
}

dl_t
dl_open( const char * file )
{ HINSTANCE res = LoadLibrary( file );
 return res == NULL ? AL_DLERROR : ( dl_t )res;
}

void *
dl_sym( dl_t dl, const char * sym )
{
 return ( void * )GetProcAddress( ( HMODULE )dl, sym );
}

int
dl_close( dl_t dl )
{
 return FreeLibrary( ( HINSTANCE )dl ) ? 0 : -1;
}

int
dl_recog( const void * p, int len )
{ u_4 off;
 if( len < 0x3D ) return 0;
 if( memcmp( p, "MZ", 2 ) != 0 ) return 0;
 off = * ( u_4 * )(( u_1 * )p + 0x3C) + 0x16;
 if( len < off + 2 ) return 0; 
 return ( * ( u_2 * )( ( u_1 * )p + off ) & 0x2000 ) != 0;
}
