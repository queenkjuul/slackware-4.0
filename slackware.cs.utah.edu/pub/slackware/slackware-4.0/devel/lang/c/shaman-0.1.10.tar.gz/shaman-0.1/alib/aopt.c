#include <stdlib.h>
#include <string.h>

#include "astr.h"
#include "aopt.h"

static int argc;
static char ** argv;
static option_t * opts;
static int cur;

void
opt_start( int _argc, char * _argv[], option_t * _opts )
{
 argc = _argc;
 argv = _argv;
 opts = _opts;
 cur = 1;
}

int
opt_get( any_t * res )
{ register int i;
 /* no more options */
 if( cur >= argc )
  return AL_OPT_NOMORE;

 for( i = 0; opts[ i ].name != NULL; i++ )
  if( strcmp( opts[ i ].name, argv[ cur ] ) == 0 )
   {
    /* missing option value */
    if( opts[ i ].type != AL_OPT_SIMPLE && ++cur >= argc )
     return AL_OPT_ERROR;

    switch( opts[ i ].type )
     {
      case AL_OPT_ENUM   : * res = astr_get_value( ( strtab_t * )opts[ i ].data,
                                                   argv[ cur ] );
                           if( * res == -1 )
                            return AL_OPT_ERROR;
                           goto FOUND;
      case AL_OPT_STR    : * ( char ** )res = argv[ cur ];
                           goto FOUND;
      case AL_OPT_INT    : * res = atoi( argv[ cur ] );
                           goto FOUND;
      case AL_OPT_SIMPLE : * res = 0;
                           goto FOUND;
      default            : return AL_OPT_ERROR;
     }
   }
 /* not an option -- treat as filename */
 * ( char ** )res = argv[ cur++ ];
 return AL_OPT_FILE;
FOUND :
 cur++;
 return opts[ i ].id;
}

