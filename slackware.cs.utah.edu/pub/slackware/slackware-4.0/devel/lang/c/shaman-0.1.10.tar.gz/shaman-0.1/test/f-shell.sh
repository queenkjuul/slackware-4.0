#!/bin/sh
# A test file for language shell subpackage
# Written by Goga 26.05.97

function test () {
	echo Argument $1 passed to shell-file:test
	echo .
}

echo test # Declare the function
echo .

