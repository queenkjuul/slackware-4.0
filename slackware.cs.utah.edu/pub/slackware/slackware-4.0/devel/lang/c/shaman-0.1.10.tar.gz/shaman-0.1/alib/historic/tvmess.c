#include <stdio.h>

#include "uls.h"
#include "amsg.h"



/* this function is just an example */
void
tvmessage( int theme, char * msg, va_list args )
{ char * fmt;
 /* process message identifiers */
 if( ( fmt = uls_get( msg ) ) == NULL )
  fmt = msg;
 vprintf( fmt, args );
 fflush( stdout );
}

void
tmessage( int theme, char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 tvmessage( theme, fmt, args );
}
