/* $Id$ */

/* The shlist package */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "shnana.h"

#include "shlist.h"

/* Create a list */
Shlist
shl_cons (enum sh_type type, any_t car, Shlist cdr)
{
  Shlist res;

  /*--- Nana preconditions */
  /*---*/

  res = (Shlist) xmalloc (sizeof (struct _shlist));
  res->type = type;
  res->car = car;
  res->cdr = cdr;

  /*--- Nana postconditions */
  I (res != NULL);
  I (res->type == type && res->car == car && res->cdr == cdr);
  /*---*/

  return res;
}

/* Append one list to another (the first list changes,
 * the elements of the second are shared!)
 */
Shlist
shl_append (Shlist shl1, Shlist shl2)
{
  Shlist tt, res;

  /*--- Nana preconditions */
  ID (Shlist _l;);
  /*---*/

  if (shl1 == NULL)
    res = shl2;
  else
    {
      for (tt = shl1; tt->cdr != NULL; tt = tt->cdr)
	;
      tt->cdr = shl2;
      res = shl1;
    }

  /*--- Nana postconditions */
  I ((shl1 == NULL && res = shl2)
     || ((res == shl1)
	 && E1 (_t = res, _t != NULL, _t = _t->cdr,
		_t == shl2)));
  /*---*/

  return res;
}

/* Copies a list */
Shlist
shl_copy (Shlist shl)
{
  R_shlist rl;
  Shlist *cptr;

  /* We use R_shlist to be careful about the memory */
  r_shlist_init_c (&rl, NULL);
  for (cptr = & rl.shl; shl != NULL; shl = shl->cdr )
    {
      *cptr = shl_cons (shl->type, shl->car, NULL);
      cptr = & (*cptr)->cdr;
    }

  /* Now forget about Rl -- do not destroy the list */
  r_unregister (& rl.r);
  return rl.shl;
}

/* Construct a list out of elements.
 * The extra arguments should take the form of type/argument pairs,
 * like the first ones.
 * This list should terminate with a zero.
 */
Shlist
shl_list (enum sh_type type1, any_t e1, ...)
{
  Shlist res, last;
  enum sh_type tp;
  any_t e;
  R_shlist rl; /* Checks for memory errors */
  va_list arg;

  va_start (arg, e1);

  res = last = shl_cons (type1, e1, NULL);
  r_shlist_init_c (&rl, res);
  for (tp = va_arg (arg, enum sh_type); tp != SHT_NONE;
       tp = va_arg (arg, enum sh_type))
    {
      /* Be careful about memory errors */
      Shlist nelem;

      e = va_arg (arg, any_t);
      nelem = shl_cons (tp, e, NULL);
      last->cdr = nelem;
      last = nelem;
    }

  /* Now forget about Rl -- do not destroy the list */
  r_unregister (& rl.r);
  return res;
}

/* Destroy a list (The elements are not deleted!) */
void
shl_destroy (Shlist shl)
{
  Shlist next;
  for (; shl != NULL; shl = next)
    {
      next = shl->cdr;
      xfree (shl);
    }
}

/* Initialize R_shlist */
void
r_shlist_init (R_shlist *rl, Shlist shl, Rs_h *rsh)
{
  rl->shl = shl;
  r_register (& rl->r, rsh, (rs_dt_fun_t)r_shlist_done);
}

/* Destroy R_shlist */
void r_shlist_done (R_shlist *rl)
{
  shl_destroy (rl->shl);
  r_unregister (& rl->r);
}
