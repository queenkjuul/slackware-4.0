/* $Id$ */

/* Shaman in C. Dl_h package.
 * Started 4.03.97 by Goga.
 * Just a wraparound for dl_.
 * Thread-safe.
 */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <string.h>
#include <stdlib.h>

#include "alib.h"
#include "dl_h.h"
#include "message.h"
#include "misc.h"

/* Function versions that throw errors */

dl_t
xdl_open (const char *fname)
{
  dl_t res;

  res = dl_open (fname);

  if (res == AL_DLERROR)
    ulerror (TH_DL_H, "DL_H_bad_dlopen_%s", fname);
  return res;
}

void *
xdl_sym (dl_t handle, const char *symbol)
{
  void *res;

  res = dl_sym (handle, symbol);

  if (res == NULL)
    ulerror (TH_DL_H, "DL_H_no_symbol_%s", symbol);
  return res;
}

/* Resource based versions */

void
rxdl_init (Dl_h *dlh, const char *fname, Rs_h *rsh)
{
  /* First do the job, then register */
  dlh->h = xdl_open (fname);
  r_register (& dlh->r, rsh, (rs_dt_fun_t) rxdl_done);
}

void *
rdl_sym (Dl_h *dlh, const char *symbol)
{
  return dl_sym (dlh->h, symbol);
}


void *
rxdl_sym (Dl_h *dlh, const char *symbol)
{
  return xdl_sym (dlh->h, symbol);
}

void
rxdl_done (Dl_h *dlh)
{
  xdl_close (dlh->h);
  r_unregister (&dlh->r);
}

void
dl_h_init ( void )
{
}
