#ifndef __linux__
#error "This file is to be compiled under Linux, but __linux__ is undefined"
#endif

#define _BSD_SOURCE 1 /* this must be before any #include's */

#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>

#include "___file.h"

#define AF_MAXMAP 1024

typedef struct
{
 void * base;
 int len;
 int fh;
} mtab_t;

static mtab_t mtab[ AF_MAXMAP ];

void
___file_init( void )
{
}

int
file_open( const char * name, int rdwr )
{
 return open( name, rdwr == AL_RDWR ? O_RDWR : O_RDONLY );
}

int
file_create( const char * name )
{ int fh;
 if( ( fh = creat( name, 0644 ) ) == -1 )
  return -1;
 close( fh );
 if( ( fh = open( name, O_RDWR ) ) == -1 )
  return -1;
 return fh;
}

int
file_close( int fh )
{
 return close( fh );
}

int
file_read( int fh, void * to, int len )
{
 return read( fh, to, len );
}

int
file_write( int fh, const void * from, int len )
{
 return write( fh, from, len );
}

long
file_seek( int fh, long offset, int mode )
{
 return lseek( fh, offset,
               mode == AL_BEGIN ? SEEK_SET
               : mode == AL_END ? SEEK_END : SEEK_CUR );
}

int
file_chsize( int fh, long len )
{
 return ftruncate( fh, len );
}

int
file_delete( const char * name )
{
 return unlink( name );
}

int
file_rename( const char * from, const char * to )
{
 return rename( from, to );
}

static packtime_t
get_date_and_time( time_t t )
{ struct tm * tt = localtime( & t );
 atime_t at;
 packtime_t res = AL_NEVER;
 int otz = time_gettimezone();
 time_settimezone( AL_LOCAL_TZ );
 at.day = tt->tm_mday;
 at.month = tt->tm_mon + 1;
 at.year = tt->tm_year + 1900;
 at.hour = tt->tm_hour;
 at.min = tt->tm_min;
 at.sec = tt->tm_sec;
 at.msec = 0;
 if( time_valid( & at ) )
  res = time_pack( & at );
 time_settimezone( otz );
 return res;
}

int
file_stat_by_handle( int fh, stat_t * st )
{
 struct stat s;
 if( fstat( fh, & s ) == -1 )
  return -1;
 st->size = s.st_size;
 switch( s.st_mode & S_IFMT )
  {
   case S_IFSOCK : st->type = AL_SOCK;
                   break;
   case S_IFREG  : st->type = AL_REG;
                   break;
   case S_IFBLK  : st->type = AL_BLK;
                   break;
   case S_IFDIR  : st->type = AL_DIR;
                   break;
   case S_IFCHR  : st->type = AL_CHAR;
                   break;
   case S_IFIFO  : st->type = AL_FIFO;
                   break;
  }
 st->c_time = get_date_and_time( s.st_ctime );
 st->m_time = get_date_and_time( s.st_mtime );
 st->a_time = get_date_and_time( s.st_atime );
 return 0;
}

void *
file_map( int fh, void * addr )
{ register int i;
 int len;
 mtab_t * m;
 void * map;
 int prot, flags;
 void * res = NULL;
 mutex_lock( ___file_mutex );
 for( i = 0; i < AF_MAXMAP; i++ )
  if( mtab[ i ].base == NULL )
   break;
 if( i >= AF_MAXMAP )
  goto OUT;
 len = file_size_by_handle( fh );
 m = mtab + i;
 prot = ( fcntl( fh, F_GETFL ) & O_RDWR ) == O_RDWR
        ? ( PROT_READ | PROT_WRITE ) : PROT_READ;
 flags = ( MAP_SHARED | MAP_FILE );
 if( addr != NULL ) flags |= MAP_FIXED;
 if( ( long )( map = mmap( addr, len, prot, flags, fh, 0 ) ) == -1 )
  goto OUT;
 m->base = map;
 m->len = len;
 m->fh = fh;
 res = m->base;
OUT :
 mutex_unlock( ___file_mutex );
 return res;
}

int
file_unmap( void * map )
{ register int i;
 int res = -1;
 mutex_lock( ___file_mutex );
 for( i = 0; i < AF_MAXMAP; i++ )
  if( mtab[ i ].base == map )
   {
    munmap( mtab[ i ].base, mtab[ i ].len );
    mtab[ i ].base = NULL;
    res = 0;
    goto OUT;
   }
OUT : 
 mutex_unlock( ___file_mutex );
 return res;
}

void *
file_remap( void * base, unsigned long len )
{ register int i, fh = -1;
 mutex_lock( ___file_mutex );
 for( i = 0; i < AF_MAXMAP; i++ )
  if( mtab[ i ].base == base )
   {
    fh = mtab[ i ].fh;
    break;
   }
 if( fh == -1 )
  return NULL;
 mutex_unlock( ___file_mutex );
 if( file_unmap( base ) == -1
     || file_chsize( fh, len ) == -1 )
  return NULL;
 return file_map( fh, NULL );
}

int
file_lock( int fh, int flags )
{ struct flock l;
 l.l_type = ( flags & ~AL_NOWAIT ) == AL_READ ? F_RDLCK : F_WRLCK;
 l.l_whence = SEEK_SET;
 l.l_start = 0;
 l.l_len = file_size_by_handle( fh );
 l.l_pid = -1;
 return fcntl( fh, ( flags & AL_NOWAIT ) ? F_SETLK : F_SETLKW, & l ) 
        == -1 ? -1 : 0;
}

int
file_unlock( int fh )
{ struct flock l;
 l.l_type = F_UNLCK;
 l.l_whence = SEEK_SET;
 l.l_start = 0;
 l.l_len = file_size_by_handle( fh );
 l.l_pid = -1;
 return fcntl( fh, F_SETLK, & l ) == -1 ? -1 : 0;
}




