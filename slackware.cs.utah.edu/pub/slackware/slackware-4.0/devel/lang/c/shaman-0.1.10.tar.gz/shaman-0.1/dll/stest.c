typedef void ( * void_of_void )( void );

void action( void );

int
main( int argc, char * argv[] )
{ 
 action();
 return 0;
}
