#ifndef PRINTFN_H
#define PRINTFN_H

#include <stdarg.h>

void printfn( char * fmt, va_list args );

#endif
