#ifndef ___GLOB_H
#define ___GLOB_H

#ifdef __cplusplus
extern "C" {
#endif

int ___add_one_name( char *** p, int * nf, const char * dir, 
                     const char * name );

#ifdef __cplusplus
}
#endif

#endif
