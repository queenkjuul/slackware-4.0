#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

#include "alib.h"

static void
error( char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 vfprintf( stderr, fmt, args );
 va_end( args );
 exit( 0 );
}

int
main( int argc, char * argv[] )
{ register int i, n;
 char ** p;
 if( argc != 2 )
  error( "Usage: globtest <wildcard>\n" );
 alib_init();
 if( ( n = fn_find( argv[ 1 ], & p ) ) <= 0 )
  error( "No matches found\n" );
 printf( "Found %d matches :\n", n );
 for( i = 0; i < n; i++ )
  printf( "'%s'\n", p[ i ] );
 fn_find_free( p );
 return 0;
}
