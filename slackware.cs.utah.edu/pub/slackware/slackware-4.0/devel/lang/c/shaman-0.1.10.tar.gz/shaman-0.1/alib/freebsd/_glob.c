#ifndef __freebsd__
#error "This file is to be compiled under FreeBSD, but __freebsd__ is undefined"
#endif

#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <fnmatch.h>

#include "afname.h"
#include "afile.h"
#include "___glob.h"

int
fn_find( char * pattern, char *** res )
{ char fullpat[ FN_MAXFULL + 1 ];
 char dir[ FN_MAXFULL + 1 ];
 char pat[ FN_MAXFULL + 1 ];
 DIR * dp;
 struct dirent * de;
 int nf = 0;
 char ** p = NULL;

 fn_fullname( fullpat, pattern );
 fn_basedir( dir, fullpat );
 fn_basename( pat, fullpat );

 if( ( dp = opendir( dir ) ) == NULL
     || ( p = ( char ** )malloc( 1 ) ) == NULL )
  goto OUTERR;

 while( ( de = readdir( dp ) ) != NULL )
  if( fnmatch( pat, de->d_name, FNM_NOESCAPE | FNM_PERIOD ) == 0
      && ___add_one_name( & p, & nf, pattern, de->d_name ) == -1 )
   break;

 closedir( dp );
 ___add_one_name( & p, & nf, "", NULL );
 nf--;
OUTERR :
 * res = p;
 return nf;
}



