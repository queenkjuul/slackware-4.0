#include <stdio.h>
#include <string.h>

#include "alib.h"

static char lower[] = "��������������������������������";
static char upper[ sizeof( lower ) ];
static char back[ sizeof( lower ) ];
static char all[ sizeof( lower ) * 2 ];

static strtab_t cstab[] =
{
 { "KOI8-R",    AL_KOI8_R },
 { "CP1251",    AL_CP1251 },
 { "ISO8859-5", AL_ISO8859_5 },
 { "CP866",     AL_CP866 },
 { NULL, -1 }
};

static void
encode( int charset, char * str )
{ char recoded[ 1025 ];
 astr_encode( charset, recoded, str );
 printf( "Encoding '%s' to charset %s\n", str,
         astr_get_str( cstab, charset ) );
 printf( "Got '%s'\n", recoded );
}

static char tstr[ 1025 ];
static char fstr[] = "Noone wants die";
static char pat[] = "Noone wants";
static char val[] = "Everyone must";

int
main( void )
{
 alib_init();
 strcpy( all, lower );
 strcat( all, upper );
 printf( "String is '%s'\n", lower );
 astr_upper( upper, lower );
 printf( "Uppered is '%s'\n", upper );
 astr_lower( back, upper );
 printf( "Lowered back is '%s'\n", back );
 printf( "Comparing lower and upper ignoring case : %s\n",
         astr_icmp( upper, lower ) == 0 ? "OK" : "ERROR" );
 strcpy( all, lower );
 strcat( all, upper );
 encode( AL_CP1251, all );
 encode( AL_KOI8_R, all );
 astr_trans( tstr, fstr, pat, val, 1024, 1 );
 printf( "Translation : '%s' * (%s->%s) => '%s'\n", fstr, pat, val, tstr );
 return 0;
}
