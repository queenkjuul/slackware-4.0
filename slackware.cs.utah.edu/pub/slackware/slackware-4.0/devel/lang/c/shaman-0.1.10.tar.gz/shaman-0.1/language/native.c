/* $Id$ */
/*
 * Language type "native" - the operating system's binary format.
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/**/ /* #define USE_NANA */

#include "shnana.h"
#include "alib.h"
#include "resource.h"
#include "language.h"
#include "dl_h.h"


/* Loads a  program text into an internal representation
 * of the interpreter.
 * The program text is in a file, referenced by name.
 * After the program is loaded, the file is no longer needed.
 */
static prog_t
native_load_file (const char *fname)
{
  /*--- Nana preconditions */
  I (fname != NULL);
  /*---*/

  return (prog_t) xdl_open (fname);
}

/* Declares program unnecessary. */
static  void
native_discard (prog_t prog)
{
  /*--- Nana preconditions */
  /*---*/

  xdl_close ((dl_t) prog);

  /*--- Nana preconditions */
  /*---*/
}

/* Checks if a text is a program in the language
 * The text is in a memory area.
 */
static bool
native_recog (const void *text, uslong len)
{
  /*--- Nana preconditions */
  I (text != NULL && len != 0);
  /*---*/

  return dl_recog (text, len);
}

static fun_t
native_get_fun (prog_t prog, const char *fun_name)
{
  /*--- Nana preconditions */
  I (fun_name != NULL && (dl_t) prog != 0);
  /*---*/

  return (fun_t) dl_sym ((dl_t)prog, fun_name);
}

static void
native_release_fun (fun_t fun)
{}

/* Executes a function inside the program given in the internal representation
 * Rest is the result type, Argt - 0 terminated array of argument types
 */
static any_t
native_eval (fun_t fun,
	     sh_type rest,
	     sh_type argt[], va_list argv)
{
  typedef any_t (*native_fun_t) (va_list);

  /*--- Nana preconditions */
  I ((native_fun_t)fun != NULL);
  /*---*/

  return ((native_fun_t)fun) (argv);
}

/* Converts the interpreter-specific form of an expression to something
 * language independent.
 * (mostly for the query analyzer's sake)
 * !!!!! Expr_ is not yet defined -- Goga.
 */
static expr_t
native_make_expr (void* arg)
{
  return NULL;
}

/* Converts a C object to an internal object of the interpreter */
static ldata_t
native_to ( any_t cobj, enum sh_type tp)
{
  return (ldata_t) cobj;
}

/* Converts an interpreter object into a C object,
 * tp == 0 means the interpreter should guess itself.
 */
static any_t
native_from (ldata_t lobj, enum sh_type tp)
{
  return (any_t) lobj;
}

/* Declares that the interpreter object is locked
 * by the controlling program.
 */
static void
native_lock (ldata_t lobj)
{}

/* Declares that the interpreter object is no longer locked
 * by the controlling program.
 */
static void
native_unlock (ldata_t lobj)
{}

/* The structure describing the language. */
Lang lang_native =
{
  "Native",
  native_load_file,	/* load_file */
  NULL, 		/* load_mem  */
  native_recog,		/* recog */
  native_discard,	/* discard */
  native_get_fun,	/* get_fun */
  native_release_fun,	/* release_fun */
  native_eval,		/* eval */
  native_make_expr,	/* make_expr */
  native_to,		/* t_to */
  native_from,		/* t_from */
  native_lock,		/* lock */
  native_unlock,	/* unlock */
  0			/* A place to put LANG_MAGIC in */
};
