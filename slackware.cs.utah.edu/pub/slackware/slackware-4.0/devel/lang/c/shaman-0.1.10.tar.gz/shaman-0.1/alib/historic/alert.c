#include "amsg.h"

void
valert( char * fmt, va_list args )
{
 tvmessage( AL_ALERT, fmt, args );
}

void
alert( char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 valert( fmt, args );
 va_end( args );
}
