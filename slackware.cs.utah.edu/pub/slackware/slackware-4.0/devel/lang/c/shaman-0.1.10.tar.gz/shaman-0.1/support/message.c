/* $Id$
 * Message package implementation.
 */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdlib.h>
#include <stdarg.h>

#include "alib.h"
#include "message.h"
#include "uls.h"

#define MAX_THEMES 32

/* The function used  for message output */
static message_fun_t  _output_fun = NULL;

/* The function used  for message logging */
static message_fun_t  _log_fun = NULL;

typedef struct
{
  int theme;
  int o_level;
  int l_level;
} interest_t;

static interest_t i_tab[ MAX_THEMES ];
static int n_themes = 0;

/* Outputs a message so the user can see it 
 * Does not output it if the interest level on this theme
 * is lower than Level.
 * Still outputs the message if Theme is 0.
 */
void
vmessage( int theme, int level, char* format, va_list arg )
{
  int i;
  bool needed, logged;

  if (theme == 0)
    needed = logged = TRUE;
  else
    {
      needed = logged = TRUE;
      for (i = 0; i < n_themes; i++)
	if (i_tab[ i ].theme == theme)
	  {
	    needed = (i_tab[ i ].o_level >= level);
	    logged = (i_tab[ i ].l_level >= level);
	    break;
	  }
    }
  if (needed && _output_fun)
    _output_fun (format, arg);
  if (logged && _log_fun)
    _log_fun (format, arg);
}

void message( int theme, int level, char* format, ... )
{
  va_list arg;
  va_start( arg, format );
  vmessage( theme, level, format, arg );
  va_end( arg );
}

/* Now the variants that pass Str through uls_get */

void
vulmessage (int theme, int level, char *str, va_list arg)
{
  char *format;
  format = uls_get (str);
  if (!format) 
    format = str;
  vmessage (theme, level, format, arg);
}

void 
ulmessage (int theme, int level, char* str, ...)
{
  va_list arg;
  va_start( arg, str );
  vulmessage( theme, level, str, arg );
  va_end( arg );
}

/* Sets the output level on the theme */
void set_interest( int theme, int level )
{
  int i;
  for (i = 0; i < n_themes; i++)
    if (i_tab[ i ].theme == theme)
      {
	i_tab[ i ].o_level = level;
	break;
      }
  if (n_themes == MAX_THEMES)
    abort();  /* If Messages fail, what can we do then? */
  i_tab[ n_themes ].theme = theme;
  i_tab[ n_themes ].o_level = level;
  i_tab[ n_themes ].l_level = 0;
  n_themes++;
}

/* Sets the output level on the theme */
void set_log_interest( int theme, int level )
{
  int i;
  for (i = 0; i < n_themes; i++)
    if (i_tab[ i ].theme == theme)
      {
	i_tab[ i ].l_level = level;
	break;
      }
  if (n_themes == MAX_THEMES)
    abort();  /* If Messages fail, what can we do then? */
  i_tab[ n_themes ].theme = theme;
  i_tab[ n_themes ].l_level = level;
  i_tab[ n_themes ].o_level = 0;
  n_themes++;
}

/* Initializes the package. Sets the function used to output messages. */
void
message_init ( message_fun_t mfun, message_fun_t lfun )
{
  _output_fun = mfun;
  _log_fun = lfun;
}

