#include <stdlib.h>
#include <string.h>

#include "astr.h"
#include "afile.h"
#include "___glob.h"

int
___add_one_name( char *** p, int * nf, const char * dir, const char * name )
{ register char * pp;
 char pathname[ AL_MAXFULL + 1 ], fullname[ AL_MAXFULL + 1 ];
 if( ( * p = realloc( * p, ( * nf + 1 ) * sizeof( char * ) ) ) == NULL )
  goto ERR_OUT;
 if( name != NULL )
  {
   fn_basedir( pathname, dir );
   astr_ncat( pathname, name, AL_MAXFULL );
   fn_fullname( fullname, pathname );
   if( ( pp = malloc( strlen( fullname ) + 1 ) ) == NULL )
    {
     free( * p );
     goto ERR_OUT;
    }
   else
    strcpy( pp, fullname );
  }
 else
  pp = NULL;
 ( * p )[ ( * nf )++ ] = pp;
 return 0;
ERR_OUT :
 * p = NULL;
 * nf = 0;
 return -1;
}

void
fn_find_free( char ** g )
{ register int i;
 if( g == NULL )
  return;
 for( i = 0; g[ i ] != NULL; i++ )
  free( g[ i ] );
 free( g );
}
