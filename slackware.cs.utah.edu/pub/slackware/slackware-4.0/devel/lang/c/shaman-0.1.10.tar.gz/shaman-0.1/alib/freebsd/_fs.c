#ifndef __freebsd__
#error "This file is to be compiled under FreeBSD, but __freebsd__ is undefined"
#endif

#include <unistd.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <sys/mount.h>

#include "afname.h"
#include "afile.h"

static char pp[ FN_MAXFULL + 1 ];

int
fs_mkdir( char * dir )
{
 return mkdir( dir, 0755 );
}

int
fs_rmdir( char * dir )
{
 return rmdir( dir );
}

int
fs_chdir( char * dir )
{
 return chdir( dir );
}

char *
fs_curdir( char * to )
{
 if( to == NULL ) to = pp;
 return getcwd( to, FN_MAXFULL );
}

int
fs_disktotal( char * path )
{
 struct statfs s;
 if( statfs( path, & s ) == -1 )
  return -1;
 return ( double )s.f_bsize * s.f_blocks / 1024;
}

int
fs_diskfree( char * path )
{
 struct statfs s;
 if( statfs( path, & s ) == -1 )
  return -1;
 return ( double )s.f_bsize * s.f_bavail / 1024;
}
