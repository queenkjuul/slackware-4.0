#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <windows.h>

static void
error( char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 vprintf( fmt, args );
 va_end( args );
 exit( 0 );
}

static char dllfile[] = "dll.dll";
static char dllsym[] = "action";

typedef void ( * void_of_void )( void );

int
main( int argc, char * argv[] )
{ HANDLE dh;
 void_of_void sym;
 if( ( dh = LoadLibrary( dllfile ) ) == NULL )
  error( "Cannot load '%s': %d\n", dllfile, GetLastError() );
 printf( "Loaded successfully\n" );
 sym = ( void_of_void )GetProcAddress( dh, dllsym );
 printf( "Symbol '%s' is at 0x%08lX\n", dllsym, ( unsigned long )sym );
 if( sym != NULL )
  sym();
 FreeLibrary( dh );
 return 0;
}
