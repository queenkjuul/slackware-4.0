/* $Id$ */

/* A simple test for the Dl_h package */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "alib.h"
#include "dl_h.h"
#include "printfn.h"

#define TH_TEST 101


/* Set up all the used packages properly */
static void
initialize ( void )
{
  alib_init ();
  uls_init (getenv ("SHAMAN_MESSAGES"));
  message_init (printfn, NULL);

  resource_init ();
  dl_h_init ();
}

int
main ( void )
{
  Dl_h dl;
  Jump_h jh;
  void (*fun)( void );

  initialize ();
  jh_init_set_c (&jh);
   if (jh_theme (&jh))
    {
      message (TH_TEST, 0, "Error caught");
      jh_done( & jh );
      exit (1);
    }

  message (TH_TEST, 0, "Load test program started");

  rxdl_init (&dl, "fun.dll", & jh.rsh);

  message (TH_TEST, 0, "Opened the Dl_handler");

  fun = (void (*)( void )) rxdl_sym( &dl, "fun" );

  /* Commented this out because the address may change and no diff
   *  will pass -- Goga
     message (TH_TEST, 0, "fun = %x", fun );
   */

  (*fun)();

  message (TH_TEST, 0, "Called");

  jh_done (&jh);

  message (TH_TEST, 0, "Exiting");

  return 0;
}
