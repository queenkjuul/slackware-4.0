/* $Id$ */

/* A package making a resource out of a file handle.
 * Started by Goga 5.03.97
 */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <string.h>
#include <errno.h>
#include "misc.h"
#include "fr_h.h"

/* Opening a resource */
void
frh_init  (Fr_h *frh, const char *name, int mode, Rs_h *rsh)
{
  /* First make the resource then register it */
  frh->fd = xfile_open (name, mode);
  frh->maddr = NULL;
  r_register (& frh->r, rsh, (rs_dt_fun_t)frh_done);
}

void frh_create (Fr_h *frh, const char *name, Rs_h *rsh) /* Mode is not needed */
{
  /* First make the resource, then register it */
  frh->fd = xfile_create (name);
  frh->maddr = NULL;
  r_register (& frh->r, rsh, (rs_dt_fun_t)frh_done);
}

/* Closing a resource */
void frh_done (Fr_h *frh)
{
  frh_unmap (frh);
  file_close (frh->fd); /* Don't use xclose, I don't want to throw any unsignificant errors here -- Goga */
  r_unregister (& frh->r);
}

/* Fr_h will only allow a file to be mapped once */
void *
frh_map (Fr_h *frh, void *addr)
{
  if (frh->maddr != NULL)
    ulerror (TH_FILE, "file_already_mapped%d%p", frh->fd, frh->maddr);

  frh->maddr = xfile_map (frh->fd, addr);

  return frh->maddr;
}

void *
frh_remap ( Fr_h *frh, int size)
{
 if( frh->maddr == NULL )
   ulerror (TH_FILE, "file_is_not_mapped_yet%d\n", frh->fd );

 frh->maddr = xfile_remap(frh->maddr, size);

 return frh->maddr;
}

/* Unmap a file */
void frh_unmap (Fr_h *frh)
{
  if (frh->maddr != NULL)
    {
      xfile_unmap (frh->maddr);
      frh->maddr = NULL;
    }
}

/* Wrappers around Lib functions that throw Errors on failure */
/* I don't use ulerror here, the function names should be explicative enough
 * for anyone who can understand anything at all -- Goga.
 */
/* --- An extremely dull piece of code to write and to read -- Goga */
int
xfile_open  (const char *name, int rdwr)
{
  int res;
  if ((res = file_open (name, rdwr)) == -1)
    error (TH_FILE, "file_open(%s, 0x%x): %s", name, rdwr, strerror (errno));
  return res;
}

int
xfile_create (const char *name) /* Mode is always by default */
{
  int res;
  if ((res = file_create (name)) == -1)
    error (TH_FILE, "file_create(%s): %s", name, strerror (errno));
  return res;
}

void
xfile_close (int fh)
{
  if (file_close(fh) == -1)
    error (TH_FILE, "file_close(%d): %s", fh, strerror (errno));
}

int
xfile_read  (int fh, void *to, int len)
{
  int res;
  if ((res = file_read (fh, to, len)) == -1)
    error (TH_FILE, "file_read(%d, %p, %d): %s", fh, to, len, strerror (errno));
  return res;
}

int
xfile_write (int fh, const void *from, int len)
{
  int res;
  if ((res = file_write (fh, from, len)) == -1)
    error (TH_FILE, "file_write(%d, %p, %d): %s", fh, from, len, strerror (errno));
  return res;
}

long
xfile_seek (int fh, long offset, int mode)
{
  long res;
  if ((res = file_seek (fh, offset, mode)) == -1)
    error (TH_FILE, "file_seek(%d, %ld, %d): %s", fh, offset, mode, strerror (errno));
  return res;
}

void
xfile_delete (const char *name)
{
  if (file_delete(name) == -1)
    error (TH_FILE, "file_delete(%s): %s", name, strerror (errno));
}

void
xfile_rename (const char *from, const char *to)
{
  if (file_rename (from, to) == -1)
    error (TH_FILE, "rename(%s, %s): %s", from, to, strerror (errno));
}

void
xfile_chsize (int fh, long len)
{
  if (file_chsize (fh, len) == -1)
    error (TH_FILE, "file_chsize(%d, %ld): %s", fh, len, strerror (errno));
}

long
xfile_tell  (int fh)
{
  long res;
  if ((res = file_tell (fh)) == -1)
    error (TH_FILE, "file_tell(%d): %s", fh, strerror (errno));
  return res;
}

long
xfile_size (const char *name)
{
  long res;
  if ((res = file_size (name)) == -1)
    error (TH_FILE, "file_size(%s): %s", name, strerror (errno));
  return res;
}

long
xfile_size_by_handle (int fh)
{
  long res;
  if ((res = file_size_by_handle (fh)) == -1)
    error (TH_FILE, "file_size_by_handle(%d): %s", fh, strerror (errno));
  return res;
}

void
xfile_stat  (char *name, stat_t *st)
{
  if (file_stat (name, st) == -1)
    error (TH_FILE, "file_stat(%s, %p): %s", name, st, strerror (errno));
}

void
xfile_stat_by_handle (int fh, stat_t *st)
{
  if (file_stat_by_handle (fh, st) == -1)
    error (TH_FILE, "file_stat_by_handle(%d, %p): %s", fh, st, strerror (errno));
}

void *xfile_map (int fh, void *addr)
{
  void *res;
  if ((res = file_map (fh, addr)) == NULL)
    error (TH_FILE, "file_map(%d, %p): %s", fh, addr, strerror (errno));
  return res;
}

void *xfile_remap (void *addr, int size)
{
  void *res;
  if ((res = file_remap (addr, size)) == NULL)
    error (TH_FILE, "file_remap(%p, %d): %s", addr, size, strerror (errno));
  return res;
}

void
xfile_unmap (void *map)
{
  if (file_unmap (map) == -1)
    error (TH_FILE, "file_unmap(%p): %s", map, strerror (errno));
}

void
xfs_mkdir (char *dir)  /* Mode is default */
{
  if (fs_mkdir(dir) == -1)
    error (TH_FILE, "fs_mkdir(%s): %s", dir, strerror (errno));
}

void
xfs_rmdir (char *dir)
{
  if (fs_rmdir (dir) == -1)
    error (TH_FILE, "xfs_rmdir(%s): %s", dir, strerror (errno));
}

void
xfs_chdir (char *dir)
{
  if (fs_chdir (dir) == -1)
    error (TH_FILE, "xfs_chdir (%s): %s", dir, strerror (errno));
}

char *
xfs_curdir (char *to)
{
  char *res;
  if ((res = fs_curdir (to)) == NULL)
    error (TH_FILE, "fs_curdir (%p): %s", to, strerror (errno));
  return res;
}

void
xfs_mkdirhier (char *dir)
{
  if (fs_mkdirhier (dir) == -1)
    error (TH_FILE, "fs_mkdirhier (%s): %s", dir, strerror (errno));
}

int
xfs_disktotal (char *path)
{
  int res;
  if ((res = fs_disktotal (path)) == -1)
    error (TH_FILE, "fs_disktotal (%s): %s", path, strerror (errno));
  return res;
}

int
xfs_diskfree  (char *path)
{
  int res;
  if ((res = fs_diskfree (path)) == -1)
    error (TH_FILE, "fs_diskfree (%s): %s", path, strerror (errno));
  return res;
}


