#include <string.h>
#include <stdlib.h>

#include "ath.h"
#include "___str.h"

static thread_key_t ___astr_key;

int
astr_init( void )
{
 if( ( ___astr_key = th_key_create() ) == AL_NOKEY )
  return -1;
 return ___acs_init();
}

void
astr_term( void )
{
 ___acs_term();
 th_key_delete( ___astr_key );
}

char *
astr_dequote( char * d, const char * s, int maxlen, quotetab_t * qtab )
{ register int id, is, j;
 for( id = is = 0; id < maxlen && s[ is ] != '\0'; is++, id++ )
  if( s[ is ] == '\\' )
   {
    for( j = 0; qtab[ j ].quoted != '\0'; j++ )
     if( qtab[ j ].quoted == s[ is + 1 ] )
      {
       is++;
       d[ id ] = qtab[ j ].orig;
       break;
      }
    if( qtab[ j ].quoted == '\0' ) /* unknown escape */
     d[ id ] = s[ is ];
   }
  else
   d[ id ] = s[ is ];
 d[ id ] = '\0';
 return d;
}

static const quotetab_t qtab_template[] =
{
 { '\"', '\"' },
 { 0 }
};


/* this function assumes that strchr( something, '\0' ) always succeeds */
char *
astr_tok( char * str, const char * del, char quote )
{ int was_escape;
 quotetab_t qtab[ sizeof( qtab_template ) / sizeof( quotetab_t ) ];
 char * s, * e, * next_token = ( char * )th_getspecific( ___astr_key );
 memcpy( qtab, qtab_template, sizeof( qtab_template ) );
 s = str == NULL ? next_token : str;
 /* skip leading blanks */
 for( ;; s++ )
  if( strchr( del, * s ) == NULL )
   break;
  else if( * s == '\0' )
   return NULL;
 /* s points to the beginning of the token */
 if( quote == '\0' || * s != quote )
  {
   /* no quotes -- just to the first blank */
   for( e = s; strchr( del, * e ) == NULL; e++ )
    ;
   /* e points to delimiter past the token or to '\0' */
  }
 else /* search until the end of quoted string */
  {
   s++; /* skip the open-quote */
   for( e = s, was_escape = 0;
        ( was_escape || * e != quote ) && * e != '\0';
        was_escape = ( * e == '\\' ), e++ )
    ; /* search for the close-quote */
   /* e points to the close-quote or to '\0' */
  }
 if( * e != '\0' )
  * ( e++ ) = '\0';
 next_token = e;
 /* s points to the beginning of the token, e points to the first
    character past the token ( delimiter, close-quote or '\0' ),
    s is null-terminated */
 if( quote != '\0' )
  {
   qtab[ 0 ].quoted = qtab[ 0 ].orig = quote;
   astr_dequote( s, s, strlen( s ), qtab ); /* parse \" into " */
  }
 th_setspecific( ___astr_key, ( any_t )next_token );
 return s;
}

void
astr_trans( char * d, const char * s, const char * from, const char * to,
           int max, int all )
{ register int l;
 register char * p;
 int tl = strlen( to ), fl = strlen( from );

 for( ;; )
  {
   if( ( p = strstr( s, from ) ) == NULL )
    break;
   if( ( l = p - s ) > max )
    l = max;
   if( l > 0 )
    {
     memcpy( d, s, l );
     max -= l;
     d += l;
     s += l;
    }
   if( ( l = tl ) > max )
    l = max;
   if( l > 0 )
    {
     memcpy( d, to, l );
     d += l;
     max -= l;
    }
   s += fl;
   if( ! all )
    break;
  }

 if( ( l = strlen( s ) ) > max )
  l = max;
 if( l > 0 )
  memcpy( d, s, l );
 d += l;
 * d = '\0';
}

char *
astr_ncpy( char * d, const char * s, size_t n )
{
 d[ n ] = '\0';
 return strncpy( d, s, n );
}

char *
astr_ncat( char * d, const char * s, size_t n )
{
 d[ n ] = '\0';
 return strncat( d, s, n );
}

static const char digits[] = "0123456789ABCDEF";
#define NDIG (sizeof( int ) * 32)    /* maximum number of digits */

char *
astr_itoa( int x, char * to, int radix )
{ register int i;
 unsigned n;
 char buf[ NDIG ], * res = to;
 if( x == 0 )
  {
   strcpy( to, "0" );
   return to;
  }
 if( radix == 10 && x < 0 )
  {
   x = -x;
   *( to++ ) = '-';
  }
 n = x;
 for( i = NDIG - 1; n != 0; n /= radix, i-- )
  buf[ i ] = digits[ n % radix ];
 for( i++; i < NDIG; i++ )
  *( to++ ) = buf[ i ];
 * to = '\0';
 return res;
}

int
astr_get_value( strtab_t * t, const char * str )
{ register int i;
 for( i = 0; t[ i ].str != NULL; i++ )
  if( strcmp( t[ i ].str, str ) == 0 )
   break;
 return t[ i ].val;
}

char *
astr_get_str( strtab_t * t, int val )
{ register int i;
 for( i = 0; t[ i ].str != NULL; i++ )
  if( t[ i ].val == val )
   break;
 return t[ i ].str;
}
