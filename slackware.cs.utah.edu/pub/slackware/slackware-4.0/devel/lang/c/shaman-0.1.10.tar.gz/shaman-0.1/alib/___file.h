#ifndef _FILE_H
#define _FILE_H

#include "afile.h"
#include "ath.h"

typedef struct
{
 char pp[ AL_MAXFULL + 1 ];
 char nn[ AL_MAXNAME + 1 ];
 char ee[ AL_MAXEXT + 1 ];
} ___file_key_t;

extern mutex_t ___file_mutex;
extern thread_key_t ___file_key;

void ___file_init( void );

/* slash character : '\\' for Win32, '/' for U*ix */
char ___fn_slash( void );
/* string consistng of slash character */
char * ___fn_slash_str( void );

char * ___fn_colon_str( void );

/*
  If `from' contains drive, copy it to `to' and return
  pointer into `from' past the drive.
  If `from' does not contain drive, copy default drive to `to'
  and return `from'
 */
char * ___fn_getdrv( char * to, const char * from );

#endif
