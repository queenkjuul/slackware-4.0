/* $Id$ */

/* A test for language program cache package */
/* Written by Goga 11.07.97 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "fr_h.h"
#include "dl_h.h"
#include "lp_cache.h"
#include "misc.h"
#include "printfn.h"

#define TH_TEST 101

/* Set up all the used packages properly */
static void
initialize ( void )
{
  extern Lang lang_shell;

  alib_init ();
  uls_init (getenv ("SHAMAN_MESSAGES"));
  message_init (printfn, NULL);

  resource_init ();
  dl_h_init ();
  lang_init ();
#ifndef __WIN32__
  lang_register (&lang_shell);
#endif
  lpc_init (20);
}

/* This is used to call a function in the interpereter */
sh_type atarr[] = {SHT_STRING, 0};

int
main ( void )
{
  Jump_h jh;
  int ires;
  char *sres;
  Fr_h frh;
  void * mem;
  uslong len;

  initialize ();
  jh_init_set_c (&jh);
  if (jh_theme (&jh))
    {
      message (TH_TEST, 0, "Error caught");
      jh_done( & jh );
      exit (1);
    }

  /* Log cache inserting/deletion */
  set_interest (TH_LANGUAGE, 20);

  message (TH_TEST, 0, "Started");

  /* This will load the file into cache */
  ires = (int) lpc_eval_file ("f-native.dll", "test", SHT_INT, atarr, "Test");

  message (TH_TEST, 0, "F-native.dll:test returned %d", ires);

#ifndef __WIN32__
  /* This, also */
  sres = (char *) lpc_eval_file ("f-shell.sh", "test", SHT_STRING, atarr, "Test");

  message (TH_TEST, 0, "F-shell.sh:test returned '%s'", sres);
#endif

  /* And this should find the program in the cache */
  ires = (int) lpc_eval_file ("f-native.dll", "test", SHT_INT, atarr, "Test");

  message (TH_TEST, 0, "F-native.dll:test returned %d", ires);

  frh_init (&frh, "f-native.dll", AL_READ, rsh_current ());
  len = frh_size (&frh);
  mem = frh_map (&frh, NULL);

  /* In this guise the file will pass as new and will be loaded into the cache again */
  ires = (int) lpc_eval_mem (mem, len, "test", SHT_INT, atarr, "Test");

  message (TH_TEST, 0, "(Memory):test returned %d", ires);
#ifndef __WIN32__
  /* Another call for the cache */
  sres = (char *) lpc_eval_file ("f-shell.sh", "test", SHT_STRING, atarr, "Test");

  message (TH_TEST, 0, "F-shell.sh:test returned '%s'", sres);
#endif
  jh_done (&jh);

  message (TH_TEST, 0, "Exiting");

  return 0;

  /* Atexit should cleanup the cache */
}
