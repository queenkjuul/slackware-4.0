#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

#include "alib.h"

static void
error( char * fmt, ... )
{ va_list args;
 va_start( args, fmt );
 vprintf( fmt, args );
 va_end( args );
 exit( -1 );
}

static char * days[] =
{
 "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
};

int
main( void )
{ packtime_t pt, pt1; 
 atime_t t;
 int dow;
 alib_init();
 time_unpack( & t, 0 );
 pt1 = time_pack( & t );
 printf( "Epoch is %d.%d.%d %d:%d:%d.%d\n", t.day, t.month, t.year,
         t.hour, t.min, t.sec, t.msec );
 printf( "Packed is %13.11e\n", ( double )pt1 );
 if( pt1 != 0 )
  error( "ERROR: times don't match\n" );
 pt = time_now();
 time_unpack( & t, pt );
 dow = time_dayofweek( pt );
 printf( "Current time is %13.11e -- %d.%d.%d %d:%d:%d.%d (%s)\n",
         ( double )pt, t.day, t.month, t.year, t.hour, t.min, t.sec, t.msec,
         days[ dow ] );
 pt1 = time_pack( & t );
 printf( "Packed back is %13.11e\n", ( double )pt1 );
 if( pt1 != pt )
  printf( "ERROR: packed back differs from the original\n" );
 return 0;
}

