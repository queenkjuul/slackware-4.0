/* $Id$ */
/*
 * A test module for Native language subpackage
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdarg.h>
#include <string.h>
#include "message.h"
#include "alib.h"

#define TH_TEST 101

void
dll_init( void )
{
}

void
dll_finish( void )
{
}

int test( va_list arg ); /* make compiler happy */
int 
test (va_list arg)
{
  const char * str;
  str = va_arg (arg, const char*);
  message (TH_TEST, 0, "String %s passed into native_file:test", str);
  return  strlen (str);
}


