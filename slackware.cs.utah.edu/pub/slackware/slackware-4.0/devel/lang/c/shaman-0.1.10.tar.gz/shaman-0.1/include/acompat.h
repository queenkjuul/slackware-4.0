#ifndef LIB_H
#define LIB_H

#ifdef __cplusplus
extern "C" {
#endif

/*
   This file is to provide compatibility between Alib and traditional
   UNIX functions and #define's
 */

#include "alib.h"


/************** afile.h ****************************************/

#if defined( O_RDONLY )
#error "fcntl.h defines in Shlib source, try avoiding fcntl.h"
#else
#define O_RDONLY AL_READ
#define O_RDWR   AL_RDWR
#endif

#if ! defined( SEEK_SET )
/* this will be pulled in if I use my own (`pure') defines for FS_??? */
#define SEEK_SET AL_BEGIN
#define SEEK_CUR AL_CUR
#define SEEK_END AL_END

#else
/* this is compiled if I define FS_??? as SEEK_??? (`impure') */
#if SEEK_SET != AL_SET || SEEK_CUR != AL_CUR || SEEK_END != AL_END 
#error "SEEK_??? inconsistency, check if headers match the library"
#endif
#endif

typedef unsigned long off_t;

#define creat( f, m )           file_create( f )
#define open( f, m )            file_open( (f), (m) )
#define close( fh )             file_close( fh )
#define read( fh, b, l )        file_read( (fh), (b), (l) )
#define write( fh, b, l )       file_write( (fh), (b), (l) )
#define lseek( fh, off, org )   file_seek( (fh), (off), (org) )
#define tell( fh )              file_tell( fh )
#define chsize( fh, len )       file_chsize( (fh), (len) )
#define filesize( f )           file_size( f )
#define filelength( fh )        file_size_by_handle( fh )
#define remove( f )             file_delete( f )
#define rename( f, t )          file_rename( (f), (t) )

#define mkdir( d, m )           fs_mkdir( d )
#define rmdir( d )              fs_rmdir( d )
#define chdir( d )              fs_chdir( d )
/* this is unsafe : buffer length is not checked,
   buffer _must_ be of AL_MAXFULL+1 bytes */
#define getcwd( d, l )          fs_curdir( d )

/* asys.h */
#define getpagesize             sys_pagesize

#ifdef __cplusplus
}
#endif

#endif
