/*
 * dllcrt1.c
 *
 * Initialization code for DLLs.
 *
 * This file is part of the Mingw32 package.
 *
 * Contributors:
 *  Created by Colin Peters <colin@bird.fu.is.saga-u.ac.jp>
 *  DLL support adapted from Gunther Ebert <gunther.ebert@ixos-leipzig.de>
 *
 *
 *  THIS SOFTWARE IS NOT COPYRIGHTED
 *
 *  This source code is offered for use in the public domain. You may
 *  use, modify or distribute it freely.
 *
 *  This code is distributed in the hope that it will be useful but
 *  WITHOUT ANY WARRANTY. ALL WARRENTIES, EXPRESS OR IMPLIED ARE HEREBY
 *  DISCLAMED. This includes but is not limited to warrenties of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * $Revision: 1.5 $
 * $Author: colin $
 * $Date: 1997/12/30 04:04:04 $
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <process.h>
#include <windows.h>

/* See note in crt0.c */
#include "init.c"

/* Unlike normal crt0, I don't initialize the FPU, because the process
 * should have done that already. I also don't set the file handle modes,
 * because that would be rude. */


extern BOOL WINAPI DllMain(HANDLE, DWORD, LPVOID);

/****************************************************************
 The following piece of code implements per-module atexit-list,
 separate from the main executable's list, which is inside CRTDLL.
 If we leave things as they are, GCC static constructors/destructors
 will use the main list, and leave there pointers to destructors
 located inside DLL's image. When DLL is unloaded by FreeLibrary(),
 these pointers will become invalid, and the program will crash
 when trying to evaluate the main atexit-list. So atexit() calls
 from inside DLL will never be excecuted correctly.

 The solution is to have a separate atexit-list for each DLL.
 This list will be executed when the DLL is unloaded (either by
 FreeLibrary() or by the system). Since our atexit() is located
 in the startup code, it will be pulled in, thus preventing
 the usage of atexit() from CRTDLL.DLL.

 I worry about the following:
    - Will it work under Win32s?
      (Win32s DLLs seem to have the only data segment for all
       attached processes, but I'm not sure and I don't have Win32s :()
 ****************************************************************/

typedef void ( * void_of_void )( void );

static void_of_void * atlist;
static int atnum, atlen;

static int
atexit_init( void )
{
 atlen = 32;
 atlist = malloc( atlen * sizeof( void_of_void ) );
 if( atlist == NULL )
  return -1;
 atnum = 0;
}

static void
atexit_do( void )
{ register int i;
 for( i = atnum - 1; i >= 0; i-- )
  atlist[ i ]();
 free( atlist );
}

int
atexit( void_of_void fun )
{ void_of_void * atnew;
 if( atnum >= atlen )
  {
   /* I'm not sure about realloc():
      will `atlist' be a valid pointer if realloc() fails?
      This sutuation is very unlikely, but should be considered.
    */
   atnew = realloc( atlist, ( atlen + 32 ) * sizeof( void_of_void ) );
   if( atnew == NULL )
    return -1;
   atlist = atnew;
   atlen += 32;
  }
 atlist[ atnum++ ] = fun;
 return 0;
}

BOOL WINAPI
DllMainCRTStartup (HANDLE hDll, DWORD dwReason, LPVOID lpReserved)
{
	BOOL bRet;
 
	if (dwReason == DLL_PROCESS_ATTACH)
	{
        	_mingw32_init_mainargs();

		/* Create empty atexit-list */
		if( atexit_init() == -1 )
			return 0;
#ifdef	__GNUC__
		/* From libgcc.a, calls global class constructors. */
		__main();
#endif
	}

	/*
	 * Call the user-supplied DllMain subroutine
	 * NOTE: DllMain is optional, so libmingw32.a includes a stub
	 *       which will be used if the user does not supply one.
	 */
	bRet = DllMain(hDll, dwReason, lpReserved);

#ifdef	__GNUC__
	if (dwReason == DLL_PROCESS_DETACH)
	{
		/* From libgcc.a, calls global class destructors. */
		__do_global_dtors();
		/* Evaluate atexit-list */
		atexit_do();
	}
#endif

	return bRet;
}

/* With the EGCS snapshot from Mumit Khan (or b19 from Cygnus I hear) this
 * is no longer necessary. */
#if 0
#ifdef	__GNUC__
/*
 * This section terminates the list of imports under GCC. If you do not
 * include this then you will have problems when linking with DLLs.
 */
asm (".section .idata$3\n" ".long 0,0,0,0,0,0,0,0");
#endif
#endif
