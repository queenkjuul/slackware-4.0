#ifndef ASYS_H
#define ASYS_H

#ifdef __cplusplus
extern "C" {
#endif

#include "adefs.h"

/* Small functions not falling into any module */
/* DEPENDS ON : NOTHING */

/*
   Actions   : none
   Arguments : none
   Value     : system page size
 */
int sys_pagesize( void );

typedef any_t dl_t;

#define AL_DLERROR ((dl_t)-1)

/*
   Actions   : Load the specified shared library
   Arguments : file -- file name
   Value     : Handle of the library, AL_DLERROR on error
 */
dl_t dl_open( const char * file );

/*
   Actions   : Retrieve a symbol from shared library
   Arguments : dl  -- handle of the library
               sym -- name of the symbol
   Value     : Required symbol, NULL on error
 */
void * dl_sym( dl_t dl, const char * sym );

/*
  Actions    : Close and unload shared library
  Arguments  : dl -- handle of the library
  Value      : 0 on success, -1 on error
 */
int dl_close( dl_t dl );

/*
   Actions   : none
   Arguments : p   -- a buffer of memory
               len -- length of the buffer
   Value     : 1 if the buffer contains DLL image, 0 otherwise
 */
int dl_recog( const void * p, int len );

/*
  The following two functions should be provided by DLL developer.
  This allows to develop system-independent DLLs just
  by roviding these functions and explicitly linking a module
  called `dll_main', which contains system-specific entry points
  from which these functions are called
 */

/*
  Actions    : Initialize DLL internals. This function is called
               every time when the system attaches a DLL to process
               or thread. Unfortunately, different platforms
               have significantly different conventions for this case,
               the developer should use them with special care.
  Arguments  : None.
  Value      : None.
 */
void dll_init( void );

/*
  Actions    : De-initialize DLL internals.
  Arguments  : None.
  Value      : None.
 */
void dll_finish( void );

#ifdef __cplusplus
}
#endif

#endif
