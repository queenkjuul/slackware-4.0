#ifndef ATYPES_H
#define ATYPES_H

#ifdef __cplusplus
extern "C" {
#endif

/*
  Generally useful types
 */

/* A number of types of given size, useful to port data between platforms */
typedef long i_4;
#define I_4_MAX ((i_4)0x7FFFFFFFL)
typedef unsigned long u_4;
#define U_4_MAX 0xFFFFFFFFL

typedef short i_2;
#define I_2_MAX ((i_2)0x7FFF)
typedef unsigned short u_2;
#define U_2_MAX 0xFFFF

typedef signed char i_1;
#define I_1_MAX ((i_1)0x7F)
typedef unsigned char u_1;
#define U_1_MAX ((u_1)0xFF)

/* Common shortcuts */
typedef unsigned char  uschar;
typedef unsigned short usshort;
typedef unsigned int   usint;
typedef unsigned long  uslong;

typedef int bool;
typedef unsigned long any_t;

#define TRUE  1
#define FALSE 0

#undef min
#undef max

#define min( a, b ) ((a) < (b) ? (a) : (b))
#define max( a, b ) ((a) > (b) ? (a) : (b))

/* Several macros dealng with color representation.
   They probably should go to window system library,
   but this library does not exist yet
   */
typedef u_4 rgb_t;

#define rgb( r, g, b ) (((r)&0xFF)|(((g)&0xFF)<<8)|(((b)&0xFF)<<16))
#define red( c )       ((c)&0xFF)
#define green( c )     (((c)>>8)&0xFF)
#define blue( c )      (((c)>>16)&0xFF)

#ifdef __cplusplus
}
#endif

#endif














