#ifndef AMEM_H
#define AMEM_H

#ifdef __cplusplus
extern "C" {
#endif

/*
   Actions   : Allocate memory from heap, call error() if failed,
   Arguments : size -- requested size
   Value     : allocated memory
 */
void * mem_alloc( int size );

/*
   Actions   : free memory obtained from mem_alloc*() ��� mem_realloc*()
   Arguments : p -- memory obtained from mem_alloc*() ��� mem_realloc*()
   Value     : none
 */
void mem_free( void * p );

/*
   Actions   : reallocate memory with different size, call error() if failed
   Arguments : p        -- memory to grow/shrink
               nelem    -- requested number of items
               elemsize -- one item size
   Value     : reallocated memory of requested size
   Comments  : new size is `nelem * elemsize'
 */
void * mem_realloc( void * p, int nelem, int elemsize );

/*
   Actions   : test heap integrity, call error() if failed
   Arguments : none
   Value     : none
 */
void mem_test( void ); /* cause error if something is wrong */

/*
   Actions   : none
   Arguments : none
   Value     : how many mamory is allocated in the heap
   Comments  : this function is primarily for debugging
               the memory subsystem can be build in two flavors :
               one is for debugging, with integrity checks and memory
               consumption counters, the other is for real purposes,
               it has no additions but is fasater and smaller
 */
int mem_allocated( void );

/* Actions   : check whether the heap can yield the requested memory block
   Arguments : size -- requested size
   Value     : boolean
   Comments  : mem_alloc() should be used almost everywhere, since
               failure to allocate memory is a rare thing and typically 
               causes enough difficulties to prefer abort program.
               Nevertheless there are cases when we should not crach
               but react more intellectually. this function is for such
               situations.
 */
int mem_can_alloc( int size );

#ifdef __cplusplus
}
#endif

/* this stuff is for C++. I hope that it will be unneeded :)) */
#ifdef __cplusplus
void * operator new( size_t size ); /* or size_t?? */
void operator delete( void * p );
#endif

#endif
