#include <stdlib.h>
#include "___file.h"

mutex_t ___file_mutex;
thread_key_t ___file_key;

int
file_thread_init( void )
{ void * p;
 if( ( p = malloc( sizeof( ___file_key_t ) ) ) == NULL )
  return -1;
 th_setspecific( ___file_key, ( any_t )p );
 return 0;
}

void
file_thread_term( void )
{
 free( ( void * )th_getspecific( ___file_key ) );
}

int
file_init( void )
{
 if( ( ___file_mutex = mutex_create() ) == AL_NOMUTEX )
  return -1;
 if( ( ___file_key = th_key_create() ) == AL_NOKEY )
  goto OUT1;
 if( file_thread_init() == -1 )
  goto OUT2;
 ___file_init();
 return 0;
OUT2 :
 th_key_delete( ___file_key );
OUT1 :
 mutex_destroy( ___file_mutex );
 return -1;
}

void
file_term( void )
{
 file_thread_term();
 th_key_delete( ___file_key );
 mutex_destroy( ___file_mutex );
}

long
file_size( const char * name )
{ int fh;
 int res;
 if( ( fh = file_open( ( char * )name, AL_READ ) ) == -1 )
  return -1;
 res = file_size_by_handle( fh );
 file_close( fh );
 return res;
}

long
file_size_by_handle( int fh )
{ int cur = file_tell( fh );
 int res = file_seek( fh, 0, AL_END );
 file_seek( fh, cur, AL_BEGIN );
 return res;
}


int
file_stat( const char * fname, stat_t * st )
{ int fh;
 int res;
 if( ( fh = file_open( fname, AL_READ ) ) == -1 )
  return -1;
 res = file_stat_by_handle( fh, st );
 file_close( fh );
 return res;
}

int
file_exists( const char * name )
{ int fh;
 if( ( fh = file_open( name, AL_READ ) ) == -1 )
  return 0;
 file_close( fh );
 return 1;
}
