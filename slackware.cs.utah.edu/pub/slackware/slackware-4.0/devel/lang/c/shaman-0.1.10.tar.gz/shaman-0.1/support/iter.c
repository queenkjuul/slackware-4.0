/* $Id: iter.c 1.1 Sat, 22 Mar 1997 23:51:25 +0400 goga $
 * Iterator base protocol implementation
 */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "iter.h"

/* An iterator step */
uslong 
it_step (Iter* it, e_dir d, ...)
{
  va_list arg;
  uslong res;

  va_start (arg, d);
  res = ((struct iter_op*)it) -> step (it, d, arg);
  va_end (arg);
  return res;
}

uslong
it_get_pos  (Iter *it)
{
  return ((struct iter_op*)it) -> get_pos (it);
}

void
it_set_pos  (Iter *it, uslong pos)
{
  ((struct iter_op*)it) -> set_pos (it, pos);
}

/* Destroys an iterator */
void
it_destroy (Iter* it)
{
  ((struct iter_op*)it) -> destroy (it);
}
