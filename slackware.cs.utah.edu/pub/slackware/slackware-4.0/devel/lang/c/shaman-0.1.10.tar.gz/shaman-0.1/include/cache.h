/* $Id$ */
/*
 * Cache package.
 */
#ifndef _CACHE_H_
#define _CACHE_H_

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "resource.h"

typedef struct _cache_entry 
{
  Dl_list  hashlist;
  Dl_list  timelist;
  unsigned lock;
} Cache_entry;

typedef struct _cache Cache;

/* Function types for _cache_procs */

/* From a new Cache_entry using Key */
typedef Cache_entry* (*cache_form_fun_t)(any_t key);

/* Delete Entry */
typedef void (*cache_delete_fun_t)(Cache_entry *entry);

/* Does Entry match Key? */
typedef bool (*cache_match_fun_t)(Cache_entry *entry, any_t key);

/* Hash function */
typedef unsigned (*cache_hash_fun_t)(any_t key, unsigned hash_size);

/* The _cache_procs structure */
struct _cache_procs
{
  cache_form_fun_t form;
  cache_delete_fun_t delete;
  cache_match_fun_t match;
  cache_hash_fun_t hash;
};

/* The Cache type itself */
struct _cache
{
  mutex_t mutex;
  struct _cache_procs *procs;	/* procedures */
  unsigned hash_size;		/* hashtable size */
  unsigned num_max;		/* max number of entries in the cache */
  unsigned num_current;		/* current number of entries */
  Dl_list *htable;		/* hash table */
  Dl_list latest;		/* entries linked by ages */
};

#define cache_mutex(c) (& (c)->mutex)

/* Initialize a cache */
void cache_init (Cache *cache, struct _cache_procs *procs,
		 unsigned hash_size, unsigned num_max);

/* Destroy a cache and all of its members */
void cache_destroy (Cache *cache);

/* Lookup for an entry in the cache;
 * if not found, creates a new entry via Cache->procs->form().
 * The returned entry is locked.
 */
Cache_entry *cache_lookup (Cache *cache, any_t key);

/* Unlock an entry, allowing its deletion if it becomes old */
void cache_entry_unlock (Cache *cache, Cache_entry *entry);

/* Force deletion of a cache entry */
void cache_entry_delete (Cache *cache, Cache_entry *entry);

/* Start listing all the cache entries.
 * NULL if no entries in the cache.
 *
 * !!! cache_iter loops must be protected by locking cache_mutex.
 */
Cache_entry * cache_iter_start (Cache *cache);

/* Get the next entry in the list,
 * NULL if all are listed.
 */
Cache_entry * cache_iter_next (Cache *cache, Cache_entry *prev);

/***********************************************************************/
/* From now on come purely informational functions that are
 * used primarily in Nana checks.
 * They are not needed for normal programming. Some are stubs, intended
 * to be read by a human, not even by a checking tool.
 *        -- Goga.
 */

#define cache_uninited(c) TRUE

#define cache_alright(c) ((c) != NULL && cache_procs_alright ((c)->procs)	\
			  && (c)->hash_size > 0 && (c)->num_max > 0		\
			  && (c)->num_current <= (c)->num_max			\
			  && A(int i = 0, i < (c)->hash_size, i++,		\
			       dl_alright (&(c)->htable[i]))			\
			  && dl_alright (&(c)->latest)				\
			  && C (Dl_list *tl = (c)->latest.next,			\
				tl != & (c)->latest,				\
				tl = tl->next, TRUE)				\
			       == (c)->num_current				\
			  && S (int i = 0, i < (c)->hash_size, i++,		\
				C (Dl_list *tl = (c)->htable[i].next,		\
				   tl != & (c)->htable[i],			\
				   tl = tl->next, TRUE))			\
			       == (c)->num_current)

#define cache_procs_alright(cp) ((cp) != NULL 					\
				 && (cp)->form != NULL && (cp)->delete != NULL	\
				 && (cp)->match != NULL && (cp)->hash != NULL)

#define cache_entry_alright(ce) ((ce) != NULL				\
				 && dl_alright (& (ce)->hashlist)	\
				 && dl_alright (& (ce)->timelist))

#define entry_in_cache(ce,c) ((ce) != NULL && (c) != NULL			\
			      && E1 (Dl_list *tl = (ce)->timelist.next,		\
				     tl != &(ce)->timelist,			\
				     tl = tl->next,				\
				     tl == & (c)->latest)			\
			      && E1 (Dl_list *tl = (ce)->hashlist.next,		\
				     tl != &(ce)->hashlist,			\
				     tl = tl->next,				\
				     tl >= (c)->htable				\
				      && tl < (c)->htable + (c)->hash_size))
#endif /* already included */
