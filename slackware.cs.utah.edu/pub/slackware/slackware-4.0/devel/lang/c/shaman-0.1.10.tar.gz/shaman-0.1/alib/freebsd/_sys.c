#ifndef __freebsd__
#error "This file is to be compiled under FreeBSD, but __freebsd__ is undefined"
#endif

#include "atypes.h"
#include "asys.h"


#define _BSD_SOURCE 1
#include <unistd.h>

int
sys_pagesize( void )
{
 return getpagesize();
}

int
dlrecog( const void * p, int len )
{
 return memcmp( p, "\xCC\x00\x86", 3 ) == 0 
        && ((( u_1 * )p)[ 3 ] & 0x80) != 0
        && * ( u_4 * )(( u_1 * )p + 20) < 4096;  
}

