#ifndef ASTR_H
#define ASTR_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>

/* String operations */
/* DEPENDS ON : NOTHING */

/*
   Actions   : Initialize internal structures
   Arguments : None
   Value     : 0 on success, -1 on error
 */
int astr_init( void );

/*
   Actions   : Free internal structures
   Arguments : None
   Value     : None
 */
void astr_term( void );

/*
   Actions   : split string into tokens delimited by characters from given
               string. Do not split tokens quoted by viven quotation mark.
               Similar to ANSI strtok().
   Arguments : str        -- string to split
               delimeters -- string consisting of delimiters.
               quote      -- quotation mark (typically '\"' or '\''),
                             if '\0', then no quotation is made.
   Value     : a token if the string contains token, NULL if no tokens left.
 */
char * astr_tok( char * str, const char * delimeters, char quote );

/* quotation table, the last memmer must be guard with quoted == '\0' */
typedef struct
{
 char quoted; /* quoted character, i.e. which is after '\\' */
 char orig;   /* its original value, for example '\n' if quoted == 'n' */
} quotetab_t;

/*
   Actions   : copy one string into another, dequoting characters
               quoted by '\\'
   Arguments : d      -- destination
               s      -- source
               maxlen -- maximum length of destination string
                         (buffer must be [maxlen + 1])
               qtab   -- quotation table
   Value     : d
 */
char * astr_dequote( char * d, const char * s, int maxlen, quotetab_t * qtab );

/*
   Actions   : Relace every occurance of a string by another string
   Arguments : d    -- where to place the result
               s    -- source string
               from -- substring to replace
               to   -- what replace by
               max  -- maximum length of the result
               all  -- 1 -- replace every occurance, 0 -- only the first one
   Value     : None
 */
void astr_trans( char * d, const char * s, const char * from, const char * to, int max, int all );


/*
   Actions   : copy at most the given number of characters from one
               string to another, write the trailing null.
   Arguments : d -- destination string
               s -- source string
               n -- maximum length of the resulting string.
   Value     : resulting string
   Comments  : this function is similar to ANSI strncpy(), but _always_
               write '\0' to d[ n ].
 */
char * astr_ncpy( char * d, const char * s, size_t n );

/*
   Actions   : concatenate one string to another, so that the resulting
               string wouldn't exceed the given length.
   Arguments : d -- destination string
               s -- source string
               n -- maximum length of the resulting string
   Value     : resulting string
   Comments  : this function is similar to ANSI strncat(), but _always_
               writes '\0' to d[ n ].
 */
char * astr_ncat( char * d, const char * s, size_t n );

/* A set of functions to maintain primitive token tables. They can be used
   in primitive lexical analyzers */

/* the table should consist of the following structures, the last item
   must be guard with str == NULL */
typedef struct
{
 char * str; /* token */
 int val;    /* identifier */
} strtab_t;

/*
   Actions   : search the token table for given token.
   Arguments : tab -- token table
               str -- token to search
   Value     : if the token is found, its integer identifier is returned,
               otherwise the identifier of the guard is returned
               (typically it will be either -1 or some default value).
 */
int astr_get_value( strtab_t * tab, const char * str );

/*
   Actions   : search the token table for given token identifier
   Arguments : tab -- token table
               val -- identifier to search
   Value     : if the identifier is found, the corresponding string token
               is returned, otherwise NULL is returned
   Comments  : failure of this function should be a bug, since input value
               is always a token invented by the programmer and thus
               containing in the table.
 */
char * astr_get_str( strtab_t * tab, int val );   /* NULL if not found */

/*
   Actions   : convert an integer into string
   Arguments : n     -- number
               to    -- resulting string
               radix -- radix
   Value     : to
   Comments  : unfortunately, itoa() is not ANSI, so this can be needed
 */
char * astr_itoa( int n, char * to, int radix );

/***********************************************************
                 Charsets
 ***********************************************************/

/* predefined charsets */
#define AL_CP866      0
#define AL_KOI8_R     1
#define AL_CP1251     2
#define AL_ISO8859_5  3

typedef struct
{
 unsigned short charcode;  /* Unicode number of a glyph */
 unsigned short uppercode; /* Unicode number of its capital (or itself,
                              if the glyph is not a small letter */
} char_t;

/*
   Actions   : add new charset to the charsets database (i.e., reveal
               capital and small letters, build recoding tables etc.)
   Arguments : charset  -- an array of 256 character descriptions
   Value     : charset identifier on success, -1 on failure.
 */
int astr_add_charset( char_t * charset );

/*
   Actions   : none
   Arguments : none
   Value     : current charset identifier
 */
int astr_get_charset( void );

/*
   Actions   : set current charset
   Arguments : charset -- charset identifier
   Value     : none
 */
void astr_set_charset( int charset );

/*
   Actions   : recode the string from the current charset to another one
   Arguments : charset -- destination charset
               to      -- where to put the result
               from    -- string to encode
   Value     : to
 */
char * astr_encode( int charset, char * to, const char * from );

/*
   Actions   : recode the string from another charset to the current one
   Arguments : charset -- source charset
               to      -- where to put the result
               from    -- string to decode
   Value     : to
 */
char * astr_decode( int charset, char * to, const char * from );

/*
   Actions   : recode the string from one charset to another one
   Arguments : cs_to   -- destination charset
               cs_from -- source charset
               to      -- destination string
               from    -- source string
   Value     : to
 */
char * astr_recode( int cs_to, int cs_from, char * to, const char * from );

/*
   Actions   : recode the given number of bytes from the current
               charset to another one
   Arguments : charset -- destination charset
               to      -- where to put the result
               from    -- bytes to encode
               n       -- the number of bytes to encode
   Value     : to
 */
char * astr_nencode( int charset, char * to, const char * from, int n );

/*
   Actions   : recode the given number of bytes to the current charset
               from another one
   Arguments : charset -- source charset
               to      -- where to put the result
               from    -- bytes to decode
               n       -- the number of bytes to decode
   Value     : to
 */
char * astr_ndecode( int charset, char * to, char * from, int n );

/*
   Actions   : recode the given number of bytes from one charset to
               another one
   Arguments : cs_to   -- destination charset
               cs_from -- source charset
               to      -- destination buffer
               from    -- source data
               n       -- nu,mber of bytes to recode
   Value     : to
 */
char * astr_nrecode( int cs_to, int cs_from, char * to, const char * from, int n );

/*
   Actions   : none
   Arguments : c -- a character
   Value     : true if the argument is capital, false otherwise
 */
int is_upper( char c );

/*
   Actions   : none
   Arguments : c -- a character
   Value     : true if the argument is a small letter, false otherwise
 */
int is_lower( char c );

/*
   Actions   : none
   Arguments : c -- a character
   Value     : capital letter corresponding to the argument
 */
char to_upper( char c );

/*
   Actions   : none
   Arguments : c -- a character
   Value     : small letter corresponding to the argument
 */
char to_lower( char c );

/*
   Actions   : upper-case the string
   Arguments : to   -- destination string
               from -- source string
   Value     : to
 */
char * astr_upper( char * to, const char * from );

/*
   Actions   : lower-case the string
   Arguments : to   -- destination string
               from -- source string
   Value     : to
 */
char * astr_lower( char * to, const char * from );

/*
   The following functions _must_ have the same specifications as
   their ANSI equivalents, since pointers to them can be used
   along with ANSI functions.
 */

/*
   Actions   : search a substring in the string, ignoring case
   Arguments : where -- where to search
               what  -- what to search
   Value     : found string, or NULL if the string is not found
   Comments  : function uses temporary buffers, unfortunately dynamic
 */
char * astr_istr( const char * where, const char * what );

/*
   Actions   : compare two strings, ignoring case
   Arguments : s1 -- first string
               s2 -- second string
   Value     : a negative number if s1 < s2, a positive number if s1 > s2,
               0 if the strings are equal
 */
int astr_icmp( const char * s1, const char * s2 );




#ifdef __cplusplus
}
#endif

#endif
