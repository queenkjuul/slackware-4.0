#include "___time.h"
#include "atime.h"

#define START_YEAR  1918
#define START_DOW   2

#define MSEC_PER_SEC  ((packtime_t)1000)
#define MSEC_PER_MIN  (60 * MSEC_PER_SEC)
#define MSEC_PER_HOUR (60 * MSEC_PER_MIN)
#define MSEC_PER_DAY  (24 * MSEC_PER_HOUR)

static int tz;

int
time_init( void )
{
 tz = ___sys_tz();
 return 0;
}

void
time_term( void )
{
  /* nothing to do yet */
}

int
time_gettimezone( void )
{
 return tz;
}

void
time_settimezone( int _tz )
{
 /* although we modify global variable here,
    I think that the only integer assignment is not race condition */
 if( _tz == AL_LOCAL_TZ ) _tz = ___sys_tz();
 tz = _tz;
}


static int
isleap( int y )
{
 return y % 4 == 0 && y % 1000 != 0;
}

static const char cal[ 2 ][ 13 ] =
{
 { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
 { 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
};

static const packtime_t ylens[] = { 365 * MSEC_PER_DAY, 366 * MSEC_PER_DAY };

static packtime_t
mlen( int y, int m )
{
 return cal[ isleap( y ) ][ m ] * MSEC_PER_DAY;
}

static packtime_t
ylen( int y )
{
 return ylens[ isleap( y ) ];
}

int
time_valid( atime_t * t )
{
 return t->year >= START_YEAR && t->month >= 1 && t->month <= 12
        && t->day >= 1 && t->day <= mlen( t->year, t->month )
        && t->hour >= 0 && t->hour < 24 && t->min >= 0 && t->min < 60
        && t->sec >= 0 && t->sec < 60 && t->msec >= 0 && t->msec < 1000;
}

void
time_unpack( atime_t * time, packtime_t t )
{ packtime_t y;
 long rest;
 t += time_gettimezone() * MSEC_PER_HOUR;

 for( time->year = START_YEAR; t >= ( y = ylen( time->year ) );
      time->year++, t -= y )
  ;
 for( time->month = 1; t >= ( y = mlen( time->year, time->month ) );
      time->month++, t -= y )
  ;
 time->day = 1 + t / MSEC_PER_DAY; /* 1..31 */
 rest = t - ( time->day - 1 ) * MSEC_PER_DAY;
 time->hour = rest / MSEC_PER_HOUR;
 rest %= ( long )MSEC_PER_HOUR;
 time->min = rest / MSEC_PER_MIN;
 rest %= ( long )MSEC_PER_MIN;
 time->sec = rest / MSEC_PER_SEC;
 rest %= ( long )MSEC_PER_SEC;
 time->msec = ( short )rest;
}


static packtime_t /* millisecond number from year start */
ymsec( atime_t * t )
{ packtime_t res;
 int m;
 res = ( t->day - 1 ) * MSEC_PER_DAY + t->hour * MSEC_PER_HOUR
     + t->min * MSEC_PER_MIN + t->sec * MSEC_PER_SEC + t->msec;
 for( m = 1; m < t->month; res += mlen( t->year, m ), m++ )
  ;
 return res;
}

packtime_t
time_pack( atime_t * time )
{ packtime_t t;
 int year;
 if( ! time_valid( time ) )
  return AL_NEVER;
 for( t = ymsec( time ), year = START_YEAR;
      year < time->year; t += ylen( year ), year++ )
  ;
 return t - time_gettimezone() * MSEC_PER_HOUR;
}

int
time_dayofweek( packtime_t t )
{
 return ( START_DOW + ( long )( t / MSEC_PER_DAY ) ) % 7;
}
