#include <windows.h>
#include "asys.h"

BOOL WINAPI
DllMain( HINSTANCE hinst, DWORD reason, LPVOID reserved )
{
 switch( reason )
  {
   case DLL_PROCESS_ATTACH :
   case DLL_THREAD_ATTACH  : dll_init();
                             break;
   case DLL_PROCESS_DETACH :
   case DLL_THREAD_DETACH  : dll_finish();
                             break;
  }
 return 1;
}

