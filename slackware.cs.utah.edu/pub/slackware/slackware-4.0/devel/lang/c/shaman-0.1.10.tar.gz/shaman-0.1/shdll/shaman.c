#include "alib.h"

void
dll_init( void )
{
}

void
dll_finish( void )
{
}

