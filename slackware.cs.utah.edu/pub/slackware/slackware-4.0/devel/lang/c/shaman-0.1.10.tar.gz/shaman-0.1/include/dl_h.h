/* $Id$ */

#ifndef _DL_H_H_
#define _DL_H_H_

/* Shaman in C. Specifications for Load package.
 * Started 6.09.96 by Goga.
 * This is actually mostly a copy of Sun dl_ specs,
 * which is likely to become a standard (or has it already?).
 * Thread-safe.
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "alib.h"
#include "resource.h"

/* Error throwing versions */
dl_t xdl_open (const char *fname);
void *xdl_sym(dl_t handle, const char *symbol);

/* As dlclose never returns an error, xdlclose has nothing special in it */
# define xdl_close dl_close

/* Versions of dlopen/dlclose/dlsym working with a special Resource object
   (Throwing errors).
   !!!  If Rsh is rsh_global(), the functions stop being thread safe
        (both r?dlopen and r?dlclose). 
 */
typedef struct
{
  Resource r;
  dl_t h;
} Dl_h;

void rxdl_init  (Dl_h *dlh, const char *fname, Rs_h *rsh);
void *rxdl_sym (Dl_h *dlh, const char *symbol);
void rxdl_done (Dl_h *dlh);

/* This one does not throw anything, may return NULL */
void *rdl_sym  (Dl_h *dlh, const char *symbol);

/* Initialize the package */
void dl_h_init ( void );

#endif
