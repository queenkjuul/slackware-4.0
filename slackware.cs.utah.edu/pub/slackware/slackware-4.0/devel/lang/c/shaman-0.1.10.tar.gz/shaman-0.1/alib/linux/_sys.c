#ifndef __linux__
#error "This file is to be compiled under Linux, but __linux__ is undefined"
#endif

#define _BSD_SOURCE 1

#include "asys.h"
#include "afile.h"

#include <unistd.h>
#include <dlfcn.h>

int
sys_pagesize( void )
{
 return getpagesize();
}

typedef void ( * void_of_void )( void );

dl_t
dl_open( const char * fname )
{ void * res;
 char file[ AL_MAXFULL + 1 ];
 void_of_void fun;
 fn_fullname( file, fname );
 res = dlopen( file, RTLD_NOW );
 if( res == NULL )
  res = dlopen( fname, RTLD_NOW );
 if( res == NULL )
  return AL_DLERROR;
 if( ( fun = ( void_of_void )dlsym( res, "dll_init" ) ) != NULL )
  fun();
 return ( dl_t )res;
}

void *
dl_sym( dl_t dl, const char * sym )
{
 return dlsym( ( void * )dl, sym );
}

int
dl_close( dl_t dl )
{
 void_of_void fun;
 if( ( fun = ( void_of_void )dlsym( ( void * )dl, "dll_finish" ) ) != NULL )
  fun();
 return dlclose( ( void * )dl ) == -1 ? -1 : 0;
}

static struct
{
 int offset;
 int len;
 char * p;
} pattab[] =
{
 {  0, 6, "\177ELF\x01\x01" },
 { 16, 4, "\x03\x00\x03\x00" },
 {  0, 0, NULL }
};

int
dl_recog( const void * p, int len )
{ register int i, off, l;
 for( i = 0; pattab[ i ].p != NULL; i++ )
  {
   off = pattab[ i ].offset;
   l = pattab[ i ].len;
   if( off + l > len 
       || memcmp( ( char * )p + off, pattab[ i ].p, l ) != 0 )
   return 0;
  }
 return 1;
}
