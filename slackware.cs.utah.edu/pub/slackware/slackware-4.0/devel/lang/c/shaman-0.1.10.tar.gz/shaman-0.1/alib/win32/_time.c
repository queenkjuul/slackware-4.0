#include <windows.h>

#include "atime.h"
#include "___time.h"

int
___sys_tz( void )
{
 TIME_ZONE_INFORMATION ti;
 DWORD dl = GetTimeZoneInformation( & ti );
 int bias = ti.Bias;
 if( dl == TIME_ZONE_ID_DAYLIGHT )
  bias += ti.DaylightBias;
 return - bias / 60;
}

packtime_t
time_now( void )
{
 atime_t dt;
 SYSTEMTIME st;
 GetLocalTime( & st );
 dt.day = st.wDay;
 dt.month = st.wMonth;
 dt.year = st.wYear;
 dt.hour = st.wHour;
 dt.min = st.wMinute;
 dt.sec = st.wSecond;
 dt.msec = st.wMilliseconds;
 return time_pack( & dt );
}

void
time_msleep( int msec )
{
 Sleep( msec );
}

