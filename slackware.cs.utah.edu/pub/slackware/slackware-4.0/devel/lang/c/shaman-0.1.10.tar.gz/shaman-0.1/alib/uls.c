#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "ath.h"
#include "astr.h"
#include "uls.h"

#define HASHLEN 253
#define MAXSTR  1024

static int
hash( const char * id )
{ register int i;
 register unsigned res;
 for( res = i = 0; id[ i ] != '\0'; i++ )
  {
   res <<= 1;
   res ^= ( unsigned char )id[ i ];
  }
 return res % HASHLEN;
}

typedef struct hashtab
{
 struct hashtab * next;
 char * id;
 char * msg;
} hash_t;

static mutex_t uls_mutex;

static hash_t * hashtab[ HASHLEN ];
static int inited = 0;

int
uls_inited( void )
{
 return inited;
}

char *
uls_get( const char * id )
{ register hash_t * p;
 int ix;
 char * res = NULL;
 if( ! inited )
  return NULL;
 mutex_lock( uls_mutex );
 ix = hash( id );
 for( p = hashtab[ ix ]; p != NULL; p = p->next )
  if( strcmp( p->id, id ) == 0 )
   {
    res = p->msg;
    break;
   }
 mutex_unlock( uls_mutex );
 return res;
}

static int
uls_add( char * id, char * msg )
{ hash_t * p;
 int ix;
 ix = hash( id );
 if( ( p = ( hash_t * )malloc( sizeof( hash_t ) ) ) == NULL )
  return -1;
 if( ( p->id = malloc( strlen( id ) + 1 ) ) == NULL )
  {
   free( p );
   return -1;
  }
 if( ( p->msg = malloc( strlen( msg ) + 1 ) ) == NULL )
  {
   free( p );
   free( p->id );
   return -1;
  }
 strcpy( p->id, id );
 strcpy( p->msg, msg );
 p->next = hashtab[ ix ];
 hashtab[ ix ] = p;
 return 0;
}

void
uls_term( void )
{ register int i;
 register hash_t * p, * n;
 if( ! inited )
  return;
 for( i = 0; i < HASHLEN; i++ )
  {
   for( p = hashtab[ i ]; p != NULL; p = n )
    {
     n = p->next;
     free( p->id );
     free( p->msg );
     free( p );
    }
   hashtab[ i ] = NULL;
  }
 inited = 0;
 mutex_destroy( uls_mutex );
}

static char blanks[] = " \t\r\n\f";

#define KW_CHARSET 2

static strtab_t kwtab[] =
{
 { "@charset", KW_CHARSET },
 { NULL, -1 }
};

static strtab_t cstab[] =
{
 { "cp866",  AL_CP866 },
 { "koi8",   AL_KOI8_R },
 { "cp1251", AL_CP1251 },
 { NULL, -1 }
};

static quotetab_t qtab[] =
{
 { '\\', '\\' },
 { 'n',  '\n' },
 { 'r',  '\r' },
 { 'f',  '\f' },
 { 't',  '\t' },
 { 'b',  '\b' },
 { '#',  '#'  },
 { 0 }
};


static int
parse_line( char * line, char * id, char * msg )
{ int r;
 register char * p;
 if( ( p = astr_tok( line, blanks, '\"' ) ) == NULL
     || * p == '#' )
  return 0;
 astr_dequote( id, p, MAXSTR, qtab );
 if( ( p = astr_tok( NULL, blanks, '\"' ) ) == NULL
     || * p == '#' )
  return -1;
 astr_dequote( msg, p, MAXSTR, qtab );
 if( ( r = astr_get_value( kwtab, id ) ) != -1 )
  return r;
 return 1;
}

int
uls_init( const char * file )
{ FILE * fp;
 char buf[ MAXSTR + 1 ], id[ MAXSTR + 1 ], msg[ MAXSTR + 1 ];
 int cs = AL_CP866;
 int res = 0;
 if( ( fp = fopen( file, "rt" ) ) == NULL )
  return -1;

 uls_term();
 while( fgets( buf, MAXSTR, fp ) != NULL )
  {
   switch( parse_line( buf, id, msg ) )
    {
     default         : /* syntax error */
                       return -1;
     case 0          : /* blank line or comment */
                       break;
     case 1          : /* message description */
                       astr_decode( cs, msg, msg );
                       if( id != NULL && msg != NULL )
                        res |= uls_add( id, msg );
                       break;
     case KW_CHARSET : /* charset switch */
                       if( ( cs = astr_get_value( cstab, msg ) ) == -1 )
                        return -1;
                       break;
    }
  }

 fclose( fp );
 inited = 1;
 uls_mutex = mutex_create();
 return res;
}
