#include <stdio.h>

#include "asys.h"

void
dll_init( void )
{
 printf( "inited\n" );
}

void action( void ); /* make compiler happy */

void
action( void )
{
 printf( "action\n" );
}

void
dll_finish( void )
{
 printf( "finished\n" );
}
