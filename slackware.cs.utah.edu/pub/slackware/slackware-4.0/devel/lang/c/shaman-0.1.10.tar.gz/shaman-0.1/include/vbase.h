/* $Id$ */
#ifndef _VBASE_H_
#define _VBASE_H_

/* Semantic net databse package */
/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 * 
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 * 
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdarg.h>

#include "sh_style.h"
#include "language.h"
#include "iter.h"

/* A record handle for the base */
typedef uslong Vrec;

/* Link directions */
enum dir {VD_FROM, VD_TO};

typedef struct _vspace * Vspace;

/* Operations for Vspace */
struct vs_ops
{
  /* Tell which record will be executed on the base opening.
     Vr == VR_NO_RECORD means no opening script.
   */
  void (*vs_set_open_action) (Vspace *vs, Vrec vr);

  /* Create a record of size 0 */
  Vrec (*vs_rec_create) (Vspace *vs);

  /* Change the record's size */
  void (*vs_rec_chsize) (Vspace *vs, Vrec vr, uslong size);

  /* Retrieves it */
  void (*vs_rec_size) (Vspace *vs, Vrec vr);

  /* Maps the record or part of it into the address space of the process
   * (Write tells if we can change the contents). If Disp == Size == 0, 
   * the whole record is mapped.
   * Mapping causes lock creation. The lock attaches to the current Rs_h.
   */
  void (*vs_rec_addr) (Vspace *vs, Vrec vr, uslong disp, uslong size,
		       bool write);

  /* Tells the program the mapping is no longer needed */
  void (*vs_rec_release) (Vspace *vs, Vrec vr);

  /* Destroys a record */
  void (*vs_rec_destroy) (Vspace *vs, Vrec vr);

  /* Creates a link */
  void (*vs_link_create) (Vspace *vs, Vrec from, Vrec to, Vrec tp);

  /* Destroys one link; if Type is 0, destroys a link without looking
   * at its type
   */
  void (*vs_link_destroy) (Vspace *vs, Vrec from, Vrec to, Vrec tp);

  /* Starts an iterator to scan the links of a record */
  Iter* (*vs_liter_start) (Vspace *vs,
			   Vrec rec, enum dir d, Vrec tp,
			   int recurse);
  
  /* If the iterator is a linkiter, returns the type of the link it
   * last returned
   */
  Vrec (*vs_curtype) (Vspace *vs, Iter *li);

  /* Returns an index corresponding to a daemon name.
     If no index exists (the name is new), returns a new value and registers
     it in the Vspace name table
   */
  int vs_dae_number (Vspace *vs, char *name);
  
  /* Registers a daemon dispatcher for a scheme. The dispathcer is a record
     whose body is written in some regognizeable (in the sense of l_recog_fun)
     language. 
     Argt is a zero-terminated array that  describes the first several arguments
     of the daemon call that are passed to the dispathcher to identify the call.
     The dispather will return an array of records that contain daemon bodies.
   */
  void (*vs_daedisp_register) (Vspace *vs, int scheme, Vrec disp,
			       lang_type *argt);
  
  /* Registers call scheme and the argument types for a daemon.
   * The argument types list is 0-terminated.
   */
  void (*vs_dae_register) (Vspace *vs, int dae, int scheme, lang_type *argt);

  /* Calls a daemon */
  uslong (*vs_dae_call) (Vspace *vs, Vrec vr, int dae, va_list args);

  /* Closes the Vspace */
  void (*vs_close) (Vspace *vs);
};

/* Create a database */
Vspace *vb_create (char *filename, int mode);

/* Open an existing database */
Vspace *vb_open (char *filename, int flags);

/* Start a transaction over Vb, keeping it in Fname (may be NULL), and according
 * to Flags.
 */
/**/ /* !!! Define the appropriate values for Flags !!! */
Vspace * tr_start (Vspace *vb, char *filename, int flags);

/* Obvious */
/**/ /* !!! But should Commit/Abort destroy the transaction object? !!! */
void tr_commit (Vspace *tr);
void tr_checkpoint (Vspace *tr);
void tr_abort (Vspace *tr);

/* Shortcuts to vs_ops operations */
void vs_set_open_action (Vspace *vs, Vrec vr);
Vrec vs_rec_create (Vspace *vs);
void vs_rec_chsize (Vspace *vs, Vrec vr, uslong size);
uslong vs_rec_size (Vspace *vs, Vrec vr);
void *vs_rec_addr  (Vspace *vs, Vrec vr, uslong disp, uslong size, bool write);
void vs_rec_release (Vspace *vs, Vrec vr);
void vs_rec_destroy (Vspace *vs, Vrec vr);
void vs_link_create (Vspace *vs, Vrec from, Vrec to, Vrec tp);
int vs_link_destroy (Vspace *vs, Vrec from, Vrec to, Vrec tp);
Iter *vs_liter_start (Vspace *vs, Vrec rec, enum dir d, Vrec tp, int recurse);
Vrec vs_curtype (Vspace *vs, Iter *li);
int vs_dae_number (Vspace *vs, char *name);
void vs_daedisp_register (Vspace *vs, int scheme, Vrec disp, lang_type *argt);
void vs_dae_register (Vspace *vs, int dae, int scheme, lang_type *argt);
uslong vs_dae_call (Vspace *vs, Vrec vr, int dae, va_list args); 
void vs_close (Vspace *vs);

#endif /* Vbase.h */
