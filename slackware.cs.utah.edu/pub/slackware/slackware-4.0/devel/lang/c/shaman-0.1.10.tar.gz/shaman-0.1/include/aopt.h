#ifndef AOPT_H
#define AOPT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "adefs.h"

/*
   Trivial option-processing functions
 */

#define AL_OPT_SIMPLE 0
#define AL_OPT_STR    1
#define AL_OPT_INT    2
#define AL_OPT_ENUM   3

typedef struct
{
 char * name;       /* including '-' or '--' */
 int id;            /* identifier easy to return and use, 
                       don't use 0 here! */
 int type;          /* OPT_SIMPLE, OPT_INT, OPT_STR, OPT_ENUM */
 any_t data;        /* something pertaining to the option value recognition,
                       particular content depends on type :
                       OPT_ENUM : table of possible values (valtab_t*)
                     */
} option_t;

/*
   Action     : start parsing command line arguments, fill internal
                structures
   Value      : none
   Parameters : argc -- argument count
                argv -- arguments array
                opts -- option descriptions,
                        the last item has NULL in name field
 */
void 
opt_start( int argc, char * argv[], option_t * opts );

/* Values of opt_get() */
#define AL_OPT_NOMORE  0
#define AL_OPT_ERROR  -1
#define AL_OPT_FILE   -2

/*
   Action     : parse next option, modify internal state
   Value      : option identifier (option_t.id), 
                OPT_NOMORE if no more options,
                OPT_ERROR if error, OPT_FILE if filename
   Parameters : arg -- pointer in which the pointer to option value will 
                       be returned
 */
int
opt_get( any_t * arg );

#ifdef __cplusplus
}
#endif
              

#endif





