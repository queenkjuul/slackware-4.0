#ifndef __freebsd__
#error "This file is to be compiled under FreeBSD, but __freebsd__ is undefined"
#endif

#define _BSD_SOURCE 1
#include <sys/time.h>
#include <unistd.h>

#include "atime.h"
#include "___time.h"

#define MSEC_PER_SEC  (packtime_t)1000
#define MSEC_PER_HOUR (MSEC_PER_SEC * 3600)

/* seconds elapsed since start moment to Jan 1 1918 00:00:00.000 GMT 
   till Jan 1 1970 00:00:00.000 GMT */
#define DELTA (packtime_t)1.6409988e+12

int
___sys_tz( void )
{
 struct timeval tv;
 struct timezone tz;
 gettimeofday( & tv, & tz );
 return - tz.tz_minuteswest / 60;
}

packtime_t
time_now( void )
{
 struct timeval tv;
 gettimeofday( & tv, NULL );
 return DELTA + tv.tv_sec * MSEC_PER_SEC + tv.tv_usec / 1000;
}

void
time_msleep( int msec )
{
 usleep( msec * 1000 );
}










