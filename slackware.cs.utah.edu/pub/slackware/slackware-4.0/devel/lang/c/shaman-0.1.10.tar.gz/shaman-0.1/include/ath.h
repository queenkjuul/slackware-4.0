#ifndef ATH_H
#define ATH_H


#ifdef __cplusplus
extern "C" {
#endif

#include "adefs.h"

/* thread identifier */
typedef any_t thread_t;
/* thread start routine */
typedef any_t ( * thread_start_t )( any_t );
/* thread-specific data key */
typedef any_t thread_key_t;
/* mutex */
typedef any_t mutex_t;
/* condition */
typedef any_t condition_t;

/* Thread functions */

#define AL_NOTHREAD ((thread_t)-1) /* impossible thread identifier */

/*
   Actions   : Create new thread, starting from specified function
   Arguments : start_routine -- function to start with
               arg           -- argument to pass to `start-routine'
   Value     : Identifier of the new thread
 */
thread_t th_create( thread_start_t start_routine, any_t arg );

/*
   Actions   : Exit current thread
   Arguments : retval -- return value of the thread
   Value     : None, this function does not return
 */
void th_exit( any_t retval );

/*
   Actions   : Join specified thread, i.e. wait for its termination
               and get its return value
   Arguments : th            -- thread identifier
               thread_return -- pointer to store thread return value
   Value     : 0 on success, -1 on error
 */
int th_join( thread_t th, any_t * thread_return );

/* do not know how to obtain thread identifiers by handles in Win32 */
/*
   Actions   : Discover whether the specified identifiers refer
               to the same thread
   Arguments : thread1 -- first thread
               thread2 -- second thread
   Value     : 1 if identifiers refer to the same thread, 0 otherwise
 */
int th_equal( thread_t thread1, thread_t thread2 );

/*
   Actions   : None
   Arguments : None
   Value     : Identifier of the current thread
 */
thread_t th_self( void );

/* Thread-specific data */

#define AL_NOKEY ((thread_key_t)-1) /* impossible key identifier */

/*
   Actions   : Create thread-specific data key
   Arguments : None
   Value     : New key
 */
thread_key_t th_key_create( void );

/*
   Actions   : Destroy thread-specific key
   Arguments : key -- key to destroy
   Value     : 0 on success, -1 on error
 */
int th_key_delete( thread_key_t key );

/*
   Actions   : Assign data to thread-specific key
   Arguments : key -- key to assign to
               val -- data
   Value     : 0 on success, -1 on error
 */
int th_setspecific( thread_key_t key, any_t val );

/*
   Actions   : None
   Arguments : key -- thread-specific key
   Value     : Data assigned to thread-specific key
 */
any_t th_getspecific( thread_key_t key );

/* Mutex functions */
/* ALL mutexes are recursive (FBSD????????????) */

#define AL_NOMUTEX ((mutex_t)-1) /* impossible mutex */

/*
   Actions   : Create a mutex
   Arguments : None
   Value     : New mutex
 */
mutex_t mutex_create( void );

/*
   Actions   : Lock a mutex (thread blocks until mutex is available)
   Arguments : mutex -- mutex identifier
   Value     : 0 on success, -1 on error
 */
int mutex_lock( mutex_t mutex );

/*
   Actions   : Try locking the mutex
   Arguments : mutex -- mutex to lock
   Value     : 0 if mutex is locked successfully, -1 if mutex is busy
 */
int mutex_trylock( mutex_t mutex );

/*
   Actions   : Unlock the mutex
   Arguments : mutex -- mutex to unlock
   Value     : 0 on success, -1 on error
 */
int mutex_unlock( mutex_t mutex );

/*
   Actions   : Destroy the mutex
   Arguments : mutex -- mutex to destroy
   Value     : 0 on success, -1 on error
 */
int mutex_destroy( mutex_t mutex );

/* Conditions */

#define AL_NOCOND ((condition_t)-1)

/*
   Actions   : Create condition
   Arguments : None
   Value     : New condition
 */
condition_t cond_create( void );

/*
   Actions   : Signal condition, unblocking exactly one thread waiting
               for it. If no threads are waiting, nothing happend
   Arguments : cond -- condition
   Value     : 0 on success, -1 on error
 */
int cond_signal( condition_t cond );

/*
   Actions   : Wait for a condition (thread blocks until condition
               is signaled).
   Arguments : cond  -- condition
               mutex -- mutex used to avoid race condition. It is locked
                        by the thread before calling this function.
                        The function first starts waiting and unlocks
                        the mutex (the two actions are atomic),
                        and locks the mutex back when condition is signaled.
   Value     : 0 on success, -1 on error
 */
int cond_wait( condition_t cond, mutex_t mutex );

/*
   Actions   : Wait for a condition during the specified time
   Arguments : cond  -- condition
               mutex -- race-avoiding mutex
               msec  -- timeout in milliseconds
   Value     : 0 if condition is signaled, -1 if timed out or error occured
 */
int cond_timedwait( condition_t cond, mutex_t mutex, int msec );

/*
   Actions   : Destroy the condition
   Arguments : cond -- condition to destroy
   Value     : 0 on success, -1 on error
 */
int cond_destroy( condition_t cond );

#ifdef __cplusplus
}
#endif

#endif
