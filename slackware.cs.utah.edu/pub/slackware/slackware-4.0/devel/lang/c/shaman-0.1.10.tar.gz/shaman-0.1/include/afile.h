#ifndef AFILE_H
#define AFILE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "adefs.h"
#include "atime.h"

/* Basic file operations */
/* DEPENDS ON : atime astr */

/* The main problem is access control. It differs esencially between
   Unix and Win32, although Unix model can be expressed in ACL terms.
   While I'm thinking, let's ignore this problem: both file_create() and
   fs_mkdir() will create objects with reasonable default permissions,
   later we may invent some kind of chmod() and chown().
 */

/*
   file names components limits -- at present arbitrary numbers
   *** I should look at real values for each system
   */
#define AL_MAXPATH 1024
#define AL_MAXNAME 64
#define AL_MAXEXT  20
#define AL_MAXFULL (AL_MAXPATH+AL_MAXNAME+AL_MAXEXT)

/*
   Actions   : Initialize internal structures of the module
   Arguments : None
   Value     : 0 on success, -1 on error
 */
int file_init( void );

/*
   Actions   : Free internal resources of the module
   Arguments : None
   Value     : None
 */
void file_term( void );

/*
   Actions   : Initialize thread-specific internal structures
   Arguments : None
   Value     : 0 on success, -1 on error
 */
int file_thread_init( void );

/*
   Actions   : Free thread-specific internal resources
   Arguments : None
   Value     : None
 */
void file_thread_term( void );


/* `rdwr' values -- we do not need WRONLY */
#define AL_READ 0
#define AL_RDWR 1

/*
   Actions   : open a file in binary mode (no more `text' modes!)
   Arguments : name -- filename
               rdwr -- AL_RDWR or AL_READ
   Value     : opened file handle or -1 if error
 */
int file_open( const char * name, int rdwr );

/*
   Actions   : create new file of null length
   Arguments : name -- filename
   Value     : new file, opened for writing and having null length,
               -1 if error
 */
int file_create( const char * name );

/*
   Actions   : close file
   Arguments : fh -- opened file
   Value     : 0 on success, -1 on error
 */
int file_close( int fh );

/****************************************************************/
/* Traditional sequencial/random access                         */

/*
   Actions   : read given number of bytes from current position
               to given memory location, shift the file pointer
               forward by yhe number of bytes read
   Arguments : fh  -- file handle
               to  -- target location
               len -- number of bytes to read
   Value     : number of successfully read bytes, -1 on error
 */
int file_read( int fh, void * to, int len );

/*
   Actions   : write given number of bytes from memory to current
               file position, shift the file pointer
               forward by yhe number of bytes written
   Arguments : fh  -- file handle
               to  -- source location
               len -- number of bytes to write
   Value     : number of successfully written bytes, -1 on error
 */
int file_write( int fh, const void * from, int len );

/* `mode' values */
#if 0
#define AL_BEGIN 0
#define AL_END   1
#define AL_CUR   2
#else
#include <stdio.h>
#define AL_BEGIN SEEK_SET
#define AL_CUR   SEEK_CUR
#define AL_END   SEEK_END
#endif

/*
   Actions   : set file pointer to requested position
   Arguments : fh     -- file handle
               offset -- offset (from current position, begin or end)
               mode   -- AL_BEGIN (from file beginning), AL_END
                         (from end of file), AL_CUR (from current position)
   Value     : current position on success, -1 on error
 */
long file_seek( int fh, long offset, int mode );

/*
   Actions   : none
   Arguments : fh -- file
   Value     : current file pointer position
 */
#define file_tell( fh ) (file_seek( fh, 0, AL_CUR ))

/****************************************************************/
/* Memory mapping                                               */


/*
   Actions   : map a file into memory. Desired memory address can be given,
               in this case the function maps only to this address or fails
               if the address is unavailable.
   Arguments : fh   -- file handle
               addr -- desired address, if NULL, then map to arbitrary address
   Value     : mapped region on success, NULL on error
   Comments  : Very restrticted but easy version. All the file is mapped,
               read/write access to mapped region is the same as of the file
               itself (read/write if the file opened with AL_RDWR, otherwise
               read-only).
 */
void * file_map( int fh, void * addr );

/*
   Actions   : change the size of file and map it back into memory
   Arguments : addr -- base address of already mapped region
               size -- desirable size of file mapping
   Value     : mapped region of desired size, NULL if error
   Comments  : presently it is just to make GNU mmalloc work with
               minimum changes, so it is quite unreliable and ineffective
               and always tries to map file back to the same
	       location. If error occurs, the old region is destroyed :(.
	       When mmalloc will be gone, this will be rewritten.
 */
void * file_remap( void * addr, unsigned long size );

/*
   Actions   : unmap mapped file
   Arguments : map -- address of mapped region
   Value     : 0 on success, -1 on error
   Comments  : all the region is unmapped
 */
int file_unmap( void * map );

/*
   Actions   : change file length
   Arguments : fh  -- file handle
               len -- desired length
   Value     : 0 on success, -1 on error
   Comments  : if the file is enlarged, the content of the added part
               is undefined.
 */
int file_chsize( int fh, long len );

/***************************************************************/
/* Miscellaneous operations                                    */

/* file types */
#define AL_REG  0
#define AL_DIR  1
#define AL_CHAR 2
#define AL_BLK  3
#define AL_FIFO 4
#define AL_SOCK 5

typedef struct
{
 int size;
 int type;          /* regular, directory, device, etc. */
 packtime_t c_time; /* creation time */
 packtime_t m_time; /* modification time */
 packtime_t a_time; /* access time */
} stat_t;

/*
   Actions   : none
   Arguments : name -- file name
               st   -- returned info
   Value     : 0 on success, -1 on error
 */
int file_stat( const char * name, stat_t * st );

/*
   Actions   : none
   Arguments : fh -- file handle
               st -- returned info
   Value     : 0 on success, -1 on error
 */
int file_stat_by_handle( int fh, stat_t * st );

/*
   Actions   : none
   Arguments : name - file name
   Value     : file length
 */
long file_size( const char * name );

/*
   Actions   : none
   Arguments : fh -- file handle
   Value     : file length
 */
long file_size_by_handle( int fh );

/*
   Actions   : remove file
   Arguments : name -- file name
   Value     : 0 on success, -1 on error
 */
int file_delete( const char * name );

/*
   Actions   : rename file
   Arguments : from -- old name
               to   -- new name
   Value     : 0 on success, -1 on error
 */
int file_rename( const char * from, const char * to );


/*
   Actions   : none
   Arguments : name -- file name
   Value     : true if file exists, false if not
 */
int file_exists( const char * name );

/***************************************************************/
/* File locking                                                */

#define AL_NOWAIT 2 /* it must be or'able with AL_READ and AL_RDWR */

/*
   Actions   : Lock the specified file
   Arguments : fh     -- file to lock
               flags  -- one of lock types : AL_READ or AL_RDWR,
	                 possibly or'ed with AL_NOWAIT, if the function
			 must not block on busy lock.
   Value     : 0 on success, -1 on error
 */
int file_lock( int fh, int flags );

/*
   Actions   : Unlock the specified file
   Arguments : fh     -- file to lock
   Value     : 0 on success, -1 on error
 */
int file_unlock( int fh );


/***************************************************************/
/* Directory operations                                        */

/*
   Actions   : create directory
   Arguments : dir  -- directory name
   Value     : 0 on success, -1 on error
 */
int fs_mkdir( const char * dir );

/*
   Actions   : remove directory
   Arguments : dir -- directory name
   Value     : 0 on sucess, -1 on error
 */
int fs_rmdir( const char * dir );

/*
   Actions   : create directory and all his parent directories
   Arguments : dir -- directory name
   Value     : 0 on success, -1 on error
 */
int fs_mkdirhier( const char * dir );

/*
   Actions   : none
   Arguments : dir -- directory name
   Value     : true if directory exists, false if not
 */
int fs_dir_exists( const char * dir );


/*
   Actions   : change current directory
   Arguments : dir -- directory name
   Value     : 0 on success, -1 on error
 */
int fs_chdir( const char * dir );

/*
   Actions   : put current directory name into given buffer
   Arguments : to     -- target buffer, may be NULL
   Value     : to
 */
char * fs_curdir( char * to );


/*
   Actions   : none
   Arguments : path -- any existing path or file name
   Value     : size of the filesystem in which the given path resides
               in kilobytes
 */
int fs_disktotal( const char * path );

/*
   Actions   : none
   Arguments : path -- the same as in fs_disktotal()
   Value     : size of free space on given filesystem in kilobytes
 */
int fs_diskfree( const char * path );

/***************************************************************/
/* File names operations                                       */

/*
   The common idea is to not introduce the notion of `drive'
   So we have no `current drive', only `current directory'
 */

/*
   Actions   : split filename into components and store them
               into separate buffers
   Arguments : fname -- (full) filename
               path  -- resulting path
               name  -- resulting name
               ext   -- resulting suffix (only the last one)
   Value     : none
   Comments  : `path', `name' and `ext' can be NULL, in which case
               static buffer is returned.
               The resulting path have trailing '/',
               suffix starts with '.' (the results may be just
               concatenated to obtain the correct full name)
 */
void fn_split( const char * fname, char * path, char * name, char * ext );

/*
   Actions   : extract path from given filename into given buffer
   Arguments : to    -- where to put the result (may be NULL)
               fname -- filename
   Value     : `to' if to != NULL, otherwise static buffer
 */
char * fn_basedir( char * to, const char * fname );

/*
   Actions   : extract filename with extension into given buffer
   Arguments : to    -- where to put the result (may be NULL)
               fname -- filname
   Value     : `to' if to != NULL, otherwise static buffer
 */
char * fn_basename( char * to, const char * fname );

/*
   Actions   : extract filename without path and last suffix into given buffer
   Arguments : to    -- where to put the result (may be NULL)
               fname -- filename
   Value     : `to' if to != NULL, otherwise static buffer
 */
char * fn_getname( char * to, const char * fname );

/*
   Actions   : extract last suffix into given buffer
   Arguments : to    -- where to put the result (may be NULL)
               fname -- filename
   Value     : `to' if to != NULL, otherwise static buffer
 */
char * fn_getext( char * to, const char * from );

/*
   Actions   : replace the last suffix with the given one and put
               the resulting name into given buffer
   Arguments : to   -- where to put the result (may be NULL)
               from -- filename
               ext  -- new suffix
   Value     : `to' if to != NULL, otherwise static buffer
 */
char * fn_chext( char * to, const char * from, const char * ext );

/*
   Actions   : search the given filename in given path,
               put the found filename into static buffer
   Arguments : fname -- filename to search
               path  -- path delimited by ';' in Win32 and ':' in U*ix
   Value     : static buffer with the found name, NULL if not found
   Comments  : It is not good idea to request from user different
               path delimiters for different systems, since
               it makes user-written code system dependent.
 */
char * fn_apply_path( char * fname, const char * path );

/*
   Actions   : make full name from given, put the result into given buffer
   Arguments : to   -- where to put the result (may be NULL)
               from -- filename
   Value     : `to' if to != NULL, otherwise static buffer
 */
char * fn_fullname( char * to, const char * from );


/*
   Actions   : find files with names satisfying given wildcard pattern
   Arguments : pattern -- pattern with '?' and '*'
               res     -- result (array of char* pointers)
   Value     : number of files found
 */
int  fn_find( const char * pattern, char *** res );

/*
   Actions   : free the array obtained from fn_find()
   Arguments : g -- result, returned by fn_find()
   Value     : none
 */
void fn_find_free( char ** g );

#ifdef __cplusplus
}
#endif

#endif
