#include <windows.h>
#include "ath.h"

thread_t
th_create( thread_start_t start_routine, any_t arg )
{ DWORD dummy;
 thread_t res;
 res = ( thread_t )CreateThread( NULL, 0,
                                 ( LPTHREAD_START_ROUTINE )start_routine,
                                 ( void * )arg, 0, & dummy );
 return ( HANDLE )res == NULL ? AL_NOTHREAD : res;
}

void
th_exit( any_t retval )
{
 ExitThread( ( DWORD )retval );
}

thread_t
th_self( void )
{
 return ( thread_t )GetCurrentThread();
}

/* It is likely to be incorrect, since thread identifiers must be
   used instead of thread handles. But Win32 seems to not contain
   function to return thread identifier by thread handle
 */
int
th_equal( thread_t thread1, thread_t thread2 )
{
 return thread1 == thread2;
}

int
th_join( thread_t th, any_t * thread_return )
{
 if( WaitForSingleObject( ( HANDLE )th, INFINITE ) == WAIT_FAILED )
  return -1;
 return GetExitCodeThread( ( HANDLE )th, ( LPDWORD )thread_return ) ? 0 : -1;
}

thread_key_t
th_key_create( void )
{ thread_key_t res = TlsAlloc();
 return res == 0xFFFFFFFF ? AL_NOKEY : res;
}

int
th_key_delete( thread_key_t key )
{
 return TlsFree( key ) ? 0 : -1;
}

int
th_setspecific( thread_key_t key, any_t val )
{
 return TlsSetValue( key, ( void * )val ) ? 0 : -1;
}

any_t
th_getspecific( thread_key_t key )
{
 return ( any_t )TlsGetValue( key );
}

/* all mutexes in Win32 are recursive, mutexattr must be ignored */
mutex_t
mutex_create( void )
{ mutex_t res = ( mutex_t )CreateMutex( NULL, 0, NULL );
 return ( HANDLE )res == NULL ? AL_NOMUTEX : res;
}

int
mutex_lock( mutex_t mutex )
{
 return WaitForSingleObject( ( HANDLE )mutex, INFINITE ) == WAIT_FAILED
        ? -1 : 0;
}

int
mutex_trylock( mutex_t mutex )
{
 return WaitForSingleObject( ( HANDLE )mutex, 1 ) == WAIT_OBJECT_0 ? 0 : -1;
}

int
mutex_unlock( mutex_t mutex )
{
 return ReleaseMutex( ( HANDLE )mutex ) ? 0 : -1;
}

int
mutex_destroy( mutex_t mutex )
{
 return CloseHandle( ( HANDLE )mutex ) ? 0 : -1;
}

condition_t
cond_create( void )
{ condition_t res = ( condition_t )CreateEvent( NULL, 0, 0, NULL );
 return ( HANDLE )res == NULL ? AL_NOCOND : res;
}

int
cond_signal( condition_t cond )
{
 return PulseEvent( ( HANDLE )cond ) ? 0 : -1;
}

int
cond_wait( condition_t cond, mutex_t mutex )
{ int res;
 mutex_unlock( mutex );
 /* <----------------- RACE CONDITION, DON'T KNOW WHAT TO DO */
 res = WaitForSingleObject( ( HANDLE )cond, INFINITE ) == WAIT_FAILED
       ? -1 : 0;
 mutex_lock( mutex );
 return res;
}

int
cond_timedwait( condition_t cond, mutex_t mutex, int msec )
{ int res;
 mutex_unlock( mutex );
 /* <----------------- RACE CONDITION, DON'T KNOW WHAT TO DO */
 res = WaitForSingleObject( ( HANDLE )cond, msec ) == WAIT_OBJECT_0 ? -1 : 0;
 mutex_lock( mutex );
 return res;
}

int
cond_destroy( condition_t cond )
{
 return CloseHandle( ( HANDLE )cond ) ? 0 : -1;
}

