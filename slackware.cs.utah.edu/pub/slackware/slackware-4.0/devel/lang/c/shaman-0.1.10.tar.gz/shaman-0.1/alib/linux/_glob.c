#ifndef __linux__
#error "This file is to be compiled under Linux, but __linux__ is undefined"
#endif

#include <stdlib.h>
#include <dirent.h>
#include <fnmatch.h>

#include "afile.h"
#include "___glob.h"

int
fn_find( const char * pattern, char *** res )
{ char fullpat[ AL_MAXFULL + 1 ];
 char dir[ AL_MAXFULL + 1 ];
 char pat[ AL_MAXFULL + 1 ];
 DIR * dp;
 struct dirent * de;
 int nf = 0;
 char ** p = NULL;

 fn_fullname( fullpat, pattern );
 fn_basedir( dir, fullpat );
 fn_basename( pat, fullpat );

 if( ( dp = opendir( dir ) ) == NULL
     || ( p = ( char ** )malloc( 1 ) ) == NULL )
  goto OUTERR;

 while( ( de = readdir( dp ) ) != NULL )
  if( fnmatch( pat, de->d_name, FNM_NOESCAPE | FNM_PERIOD ) == 0
      && ___add_one_name( & p, & nf, pattern, de->d_name ) == -1 )
   break;

 closedir( dp );
 ___add_one_name( & p, & nf, "", NULL );
 nf--;
OUTERR :
 * res = p;
 return nf;
}

