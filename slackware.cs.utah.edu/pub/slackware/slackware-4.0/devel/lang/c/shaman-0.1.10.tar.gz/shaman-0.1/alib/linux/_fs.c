#ifndef __linux__
#error "This file is to be compiled under Linux, but __linux__ is undefined"
#endif

#include <unistd.h>
#include <sys/stat.h>
#include <sys/vfs.h>

#include "___file.h"

int
fs_mkdir( const char * dir )
{
 return mkdir( dir, 0755 );
}

int
fs_rmdir( const char * dir )
{
 return rmdir( dir );
}

int
fs_chdir( const char * dir )
{
 return chdir( dir );
}

char *
fs_curdir( char * to )
{ 
 ___file_key_t * b = ( ___file_key_t * )th_getspecific( ___file_key );
 if( to == NULL ) to = b->pp;
 return getcwd( to, AL_MAXFULL );
}

int
fs_disktotal( const char * path )
{
 struct statfs s;
 if( statfs( path, & s ) == -1 )
  return -1;
 return ( double )s.f_bsize * s.f_blocks / 1024;
}

int
fs_diskfree( const char * path )
{
 struct statfs s;
 if( statfs( path, & s ) == -1 )
  return -1;
 return ( double )s.f_bsize * s.f_bavail / 1024;
}
