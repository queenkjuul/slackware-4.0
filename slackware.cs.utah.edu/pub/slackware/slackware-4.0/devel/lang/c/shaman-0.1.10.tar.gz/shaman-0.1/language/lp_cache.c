/* $Id$ */
/*
 * Language programs cache.
 */

/*
 *    Copyright (C) 1997  George Bronnikov (goga@goga.mainet.msk.su),
 *                        Andrey Smirnov   (admie@iasis.msk.su),
 *			  Yury Filimonov   (yura@yura.mainet.msk.su)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <string.h>
#include <stdarg.h>
#include "shnana.h"

#include "alib.h"
#include "lp_cache.h"
#include "misc.h"

/* Low level functions for the language programs cache */

/* Convert Lpc_key* to its master Lpc_entry* */
#define lpc_info_unoffset(li) ((Lpc_entry*) ((char*)(li) - \
					     (int)(char*) & (((Lpc_entry*)NULL)->info)))

static bool lp_cache_match (Cache_entry *entry, any_t key);

/* Allocate a new cache entry */
static Cache_entry *
lp_cache_form (any_t key)
{
  Lpc_key *lkey = (Lpc_key *)key;
  Lpc_entry *res;

  /*--- Nana preconditions */
  I (lpkey_alright (lkey));
  /*---*/

  res = (Lpc_entry *)xmalloc (sizeof (Lpc_entry));
  memcpy (& res->key, lkey, sizeof(Lpc_key));
  if (lkey->tp == LPC_FILE)
    {
      char *fname; /* Reallocate filename buffer */

      fname = xmalloc (strlen (lkey->u.fname) + 1);
      strcpy (fname, lkey->u.fname);
      res->key.u.fname = fname;
    }

  if (lkey->tp == LPC_FILE)
    {
      ulmessage (TH_LANGUAGE, 10, "Lp_cache_loading_file_%s", lkey->u.fname);

      if ((res->info.lang = lang_examine_file (lkey->u.fname)) == NULL)
	ulerror (TH_LANGUAGE, "Language_unknown_program_file_%s", lkey->u.fname);
      res->info.prog = lang_load_file (res->info.lang, lkey->u.fname);
    }
  else
    {
      I (lkey->tp == LPC_MEM);

      ulmessage (TH_LANGUAGE, 10, "Lp_cache_loading_mem");

      if ((res->info.lang = lang_examine_mem (lkey->u.m.addr, lkey->u.m.len))
	    == NULL)
	ulerror (TH_LANGUAGE, "Language_unknown_program_mem_%p_%ld",
		              lkey->u.m.addr, lkey->u.m.len);
      res->info.prog = lang_load_mem (res->info.lang,
				      lkey->u.m.addr, lkey->u.m.len);
    }

  /*--- Nana postconditions */
  I (res != NULL && lpentry_alright (res));
  I (lp_cache_match ((Cache_entry*)res, (any_t)lkey));
  /*---*/

  return (Cache_entry*) res;
}

/* Destroy a cache entry */
static void
lp_cache_delete (Cache_entry *entry)
{
  Lpc_entry *lpce = (Lpc_entry *)entry;

  /*--- Nana preconditions */
  I (lpentry_alright (lpce));
  /*---*/

  if (lpce->key.tp == LPC_FILE)
    ulmessage (TH_LANGUAGE, 10, "Lp_cache_destroying_file_%s", lpce->key.u.fname);
  else
    ulmessage (TH_LANGUAGE, 10, "Lp_cache_destroying_mem");

  lang_discard (lpce->info.lang, lpce->info.prog);
  if (lpce->key.tp == LPC_FILE)
    xfree ((char*) lpce->key.u.fname);
  xfree (entry);

  /*--- Nana postconditions */
  /* Entry deleted, memory freed */
  /*---*/
}

/* Check if a key matches the entry */
static bool
lp_cache_match (Cache_entry *entry, any_t key)
{
  Lpc_entry *lpce = (Lpc_entry *)entry;
  Lpc_key *lk = (Lpc_key *)key;

  /*--- Nana preconditions */
  I (lpentry_alright (lpce) && lpkey_alright (lk));
  /*---*/

  if (lpce->key.tp != lk->tp)
    return FALSE;
  else if (lpce->key.tp == LPC_FILE)
    return (strcmp (lpce->key.u.fname, lk->u.fname) == 0);
  else
    {
      I (lpce->key.tp == LPC_MEM);
      return lpce->key.u.m.addr == lk->u.m.addr;
    }

  /*--- Nana postconditions */
  /*---*/
}

/* A hash function */
static unsigned
lp_cache_hash (any_t key, unsigned hash_size)
{
  Lpc_key *lk = (Lpc_key *)key;
  unsigned res;

  /*--- Nana preconditions */
  I (lpkey_alright (lk) && hash_size != 0);
  /*---*/

  if (lk->tp == LPC_FILE)
    {
      const char *t;

      res = 0;
      for (t = lk->u.fname; *t; t++)
	res = (res << 1) + (unsigned)*t;

      res %= hash_size;
    }
  else
    /* Length is more "random" than addr */
    res = lk->u.m.len % hash_size;

  /*--- Nana postconditions */
  I (res < hash_size);
  /*---*/

  return res;
}

static struct _cache_procs lp_cache_procs =
{
  lp_cache_form,
  lp_cache_delete,
  lp_cache_match,
  lp_cache_hash
};

/* The Cache itself */
Cache lp_cache;

/* Atexit function */
static void
lp_cache_atexit ( void )
{
  cache_destroy (&lp_cache);
}

/* Public functions */
void
lpc_init (int size)
{
  if (size == 0)
    size = LPC_SIZE_DEFAULT;

  /* Assume num_max == hash_size is OK ? */
  cache_init (&lp_cache, &lp_cache_procs, size, size);
  atexit (lp_cache_atexit);

  /*--- Nana postconditions */
  I (cache_alright (&lp_cache));
  /*---*/
}

/* Get Lpc_info corresponding to fname */
Lpc_info *
lpc_lookup_file (const char *fname)
{
  Lpc_key lk;
  Lpc_entry * res;

  /*--- Nana preconditions */
  I (cache_alright (&lp_cache) && fname != NULL);
  /*---*/

  lk.tp = LPC_FILE;
  lk.u.fname = fname;

  res = (Lpc_entry *) cache_lookup (&lp_cache, (any_t)&lk);

  /*--- Nana postconditions */
  I (cache_alright (&lp_cache) && strcmp (res->key.u.fname,fname) == 0);
  /*---*/

  return & res->info;
}

/* Get Lpc_info corresponding to mem+len */
Lpc_info *
lpc_lookup_mem  (const void *mem, uslong len)
{
  Lpc_key lk;
  Lpc_entry * res;

  /*--- Nana preconditions */
  I (cache_alright (&lp_cache) && mem != NULL && len != 0);
  /*---*/

  lk.tp = LPC_MEM;
  lk.u.m.addr = mem;
  lk.u.m.len = len;

  res = (Lpc_entry *) cache_lookup (&lp_cache, (any_t)&lk);

  /*--- Nana postconditions */
  I (cache_alright (&lp_cache));
  I (res->key.u.m.addr == mem && res->key.u.m.len == len);
  /*---*/

  return & res->info;
}

/* Unlock the entry */
void
lpc_unlock (Lpc_info *e)
{
  Lpc_entry *le;

  le = lpc_info_unoffset (e);
  cache_entry_unlock (&lp_cache, & le->ce);
}

/* The highest level Language call functions */
any_t
lpc_eval_file  (const char *fname, const char *fun,
		sh_type rest, sh_type *argt, ...)
{
  any_t res;
  va_list argv;

  /*--- Nana preconditions */
  I (fname != NULL && fun != NULL && argt != NULL);
  /*---*/

  va_start (argv, argt);
  res = lpc_evalv_file (fname, fun, rest, argt, argv);
  va_end (argv);

  /*--- Nana postconditions */
  /*---*/

  return res;
}

any_t
lpc_evalv_file (const char *fname, const char *fun,
		sh_type rest, sh_type *argt,
		va_list argv)
{
  Lpc_info *li;
  any_t res;

  /*--- Nana preconditions */
  I (fname != NULL && fun != NULL && argt != NULL);
  /*---*/

  li = lpc_lookup_file (fname);
  res = lang_evalv_by_name (li->lang, li->prog, fun,
			    rest, argt, argv);
  lpc_unlock (li);

  /*--- Nana postconditions */
  /*---*/

  return res;
}


any_t 
lpc_eval_mem   (const void *mem, uslong len, const char *fun,
		sh_type rest, sh_type *argt, ...)
{
  any_t res;
  va_list argv;

  /*--- Nana preconditions */
  I (mem != NULL && len != 0 && fun != NULL && argt != NULL);
  /*---*/

  va_start (argv, argt);
  res = lpc_evalv_mem (mem, len, fun, rest, argt, argv);
  va_end (argv);

  /*--- Nana postconditions */
  /*---*/

  return res;
}

any_t 
lpc_evalv_mem  (const void *mem, uslong len, const char *fun,
		sh_type rest, sh_type *argt,
		va_list argv)
{
  Lpc_info *li;
  any_t res;

  /*--- Nana preconditions */
  I (mem != NULL && len != 0 && fun != NULL && argt != NULL);
  /*---*/

  li = lpc_lookup_mem (mem, len);
  res = lang_evalv_by_name (li->lang, li->prog, fun,
			    rest, argt, argv);
  lpc_unlock (li);

  /*--- Nana postconditions */
  /*---*/

  return res;
}
