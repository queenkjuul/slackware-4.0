#include <stdlib.h>
#include <string.h>

#include "ath.h"
#include "___str.h"

static mutex_t cs_mutex;

#define CS_MAX 16
#define UNI_SPACE 0x0020

typedef struct
{
 short code;
 unsigned char upper;
 unsigned char lower;
} cs_t;

typedef struct
{
 cs_t s[ 256 ];
} charset_t;

typedef struct
{
 unsigned char table[ 256 ];
} rtab_t;

static int cur_set = 0;
static charset_t * sets[ CS_MAX ];
static rtab_t * rtabs[ CS_MAX ][ CS_MAX ];

static char_t cp866[] =
{
  { 0x0000, 0x0000 }, /* 0x00          NULL*/
  { 0x0001, 0x0001 }, /* 0x01          START OF HEADING*/
  { 0x0002, 0x0002 }, /* 0x02          START OF TEXT*/
  { 0x0003, 0x0003 }, /* 0x03          END OF TEXT*/
  { 0x0004, 0x0004 }, /* 0x04          END OF TRANSMISSION*/
  { 0x0005, 0x0005 }, /* 0x05          ENQUIRY*/
  { 0x0006, 0x0006 }, /* 0x06          ACKNOWLEDGE*/
  { 0x0007, 0x0007 }, /* 0x07          BELL*/
  { 0x0008, 0x0008 }, /* 0x08          BACKSPACE*/
  { 0x0009, 0x0009 }, /* 0x09          HORIZONTAL TABULATION*/
  { 0x000A, 0x000A }, /* 0x0A          LINE FEED*/
  { 0x000B, 0x000B }, /* 0x0B          VERTICAL TABULATION*/
  { 0x000C, 0x000C }, /* 0x0C          FORM FEED*/
  { 0x000D, 0x000D }, /* 0x0D          CARRIAGE RETURN*/
  { 0x000E, 0x000E }, /* 0x0E          SHIFT OUT*/
  { 0x000F, 0x000F }, /* 0x0F          SHIFT IN*/
  { 0x0010, 0x0010 }, /* 0x10          DATA LINK ESCAPE*/
  { 0x0011, 0x0011 }, /* 0x11          DEVICE CONTROL ONE*/
  { 0x0012, 0x0012 }, /* 0x12          DEVICE CONTROL TWO*/
  { 0x0013, 0x0013 }, /* 0x13          DEVICE CONTROL THREE*/
  { 0x0014, 0x0014 }, /* 0x14          DEVICE CONTROL FOUR*/
  { 0x0015, 0x0015 }, /* 0x15          NEGATIVE ACKNOWLEDGE*/
  { 0x0016, 0x0016 }, /* 0x16          SYNCHRONOUS IDLE*/
  { 0x0017, 0x0017 }, /* 0x17          END OF TRANSMISSION BLOCK*/
  { 0x0018, 0x0018 }, /* 0x18          CANCEL*/
  { 0x0019, 0x0019 }, /* 0x19          END OF MEDIUM*/
  { 0x001A, 0x001A }, /* 0x1A          SUBSTITUTE*/
  { 0x001B, 0x001B }, /* 0x1B          ESCAPE*/
  { 0x001C, 0x001C }, /* 0x1C          FILE SEPARATOR*/
  { 0x001D, 0x001D }, /* 0x1D          GROUP SEPARATOR*/
  { 0x001E, 0x001E }, /* 0x1E          RECORD SEPARATOR*/
  { 0x001F, 0x001F }, /* 0x1F          UNIT SEPARATOR*/
  { 0x0020, 0x0020 }, /* 0x20          SPACE*/
  { 0x0021, 0x0021 }, /* 0x21          EXCLAMATION MARK*/
  { 0x0022, 0x0022 }, /* 0x22          QUOTATION MARK*/
  { 0x0023, 0x0023 }, /* 0x23          NUMBER SIGN*/
  { 0x0024, 0x0024 }, /* 0x24          DOLLAR SIGN*/
  { 0x0025, 0x0025 }, /* 0x25          PERCENT SIGN*/
  { 0x0026, 0x0026 }, /* 0x26          AMPERSAND*/
  { 0x0027, 0x0027 }, /* 0x27          APOSTROPHE*/
  { 0x0028, 0x0028 }, /* 0x28          LEFT PARENTHESIS*/
  { 0x0029, 0x0029 }, /* 0x29          RIGHT PARENTHESIS*/
  { 0x002A, 0x002A }, /* 0x2A          ASTERISK*/
  { 0x002B, 0x002B }, /* 0x2B          PLUS SIGN*/
  { 0x002C, 0x002C }, /* 0x2C          COMMA*/
  { 0x002D, 0x002D }, /* 0x2D          HYPHEN-MINUS*/
  { 0x002E, 0x002E }, /* 0x2E          FULL STOP*/
  { 0x002F, 0x002F }, /* 0x2F          SOLIDUS*/
  { 0x0030, 0x0030 }, /* 0x30          DIGIT ZERO*/
  { 0x0031, 0x0031 }, /* 0x31          DIGIT ONE*/
  { 0x0032, 0x0032 }, /* 0x32          DIGIT TWO*/
  { 0x0033, 0x0033 }, /* 0x33          DIGIT THREE*/
  { 0x0034, 0x0034 }, /* 0x34          DIGIT FOUR*/
  { 0x0035, 0x0035 }, /* 0x35          DIGIT FIVE*/
  { 0x0036, 0x0036 }, /* 0x36          DIGIT SIX*/
  { 0x0037, 0x0037 }, /* 0x37          DIGIT SEVEN*/
  { 0x0038, 0x0038 }, /* 0x38          DIGIT EIGHT*/
  { 0x0039, 0x0039 }, /* 0x39          DIGIT NINE*/
  { 0x003A, 0x003A }, /* 0x3A          COLON*/
  { 0x003B, 0x003B }, /* 0x3B          SEMICOLON*/
  { 0x003C, 0x003C }, /* 0x3C          LESS-THAN SIGN*/
  { 0x003D, 0x003D }, /* 0x3D          EQUALS SIGN*/
  { 0x003E, 0x003E }, /* 0x3E          GREATER-THAN SIGN*/
  { 0x003F, 0x003F }, /* 0x3F          QUESTION MARK*/
  { 0x0040, 0x0040 }, /* 0x40          COMMERCIAL AT*/
  { 0x0041, 0x0041 }, /* 0x41          LATIN CAPITAL LETTER A*/
  { 0x0042, 0x0042 }, /* 0x42          LATIN CAPITAL LETTER B*/
  { 0x0043, 0x0043 }, /* 0x43          LATIN CAPITAL LETTER C*/
  { 0x0044, 0x0044 }, /* 0x44          LATIN CAPITAL LETTER D*/
  { 0x0045, 0x0045 }, /* 0x45          LATIN CAPITAL LETTER E*/
  { 0x0046, 0x0046 }, /* 0x46          LATIN CAPITAL LETTER F*/
  { 0x0047, 0x0047 }, /* 0x47          LATIN CAPITAL LETTER G*/
  { 0x0048, 0x0048 }, /* 0x48          LATIN CAPITAL LETTER H*/
  { 0x0049, 0x0049 }, /* 0x49          LATIN CAPITAL LETTER I*/
  { 0x004A, 0x004A }, /* 0x4A          LATIN CAPITAL LETTER J*/
  { 0x004B, 0x004B }, /* 0x4B          LATIN CAPITAL LETTER K*/
  { 0x004C, 0x004C }, /* 0x4C          LATIN CAPITAL LETTER L*/
  { 0x004D, 0x004D }, /* 0x4D          LATIN CAPITAL LETTER M*/
  { 0x004E, 0x004E }, /* 0x4E          LATIN CAPITAL LETTER N*/
  { 0x004F, 0x004F }, /* 0x4F          LATIN CAPITAL LETTER O*/
  { 0x0050, 0x0050 }, /* 0x50          LATIN CAPITAL LETTER P*/
  { 0x0051, 0x0051 }, /* 0x51          LATIN CAPITAL LETTER Q*/
  { 0x0052, 0x0052 }, /* 0x52          LATIN CAPITAL LETTER R*/
  { 0x0053, 0x0053 }, /* 0x53          LATIN CAPITAL LETTER S*/
  { 0x0054, 0x0054 }, /* 0x54          LATIN CAPITAL LETTER T*/
  { 0x0055, 0x0055 }, /* 0x55          LATIN CAPITAL LETTER U*/
  { 0x0056, 0x0056 }, /* 0x56          LATIN CAPITAL LETTER V*/
  { 0x0057, 0x0057 }, /* 0x57          LATIN CAPITAL LETTER W*/
  { 0x0058, 0x0058 }, /* 0x58          LATIN CAPITAL LETTER X*/
  { 0x0059, 0x0059 }, /* 0x59          LATIN CAPITAL LETTER Y*/
  { 0x005A, 0x005A }, /* 0x5A          LATIN CAPITAL LETTER Z*/
  { 0x005B, 0x005B }, /* 0x5B          LEFT SQUARE BRACKET*/
  { 0x005C, 0x005C }, /* 0x5C          REVERSE SOLIDUS*/
  { 0x005D, 0x005D }, /* 0x5D          RIGHT SQUARE BRACKET*/
  { 0x005E, 0x005E }, /* 0x5E          CIRCUMFLEX ACCENT*/
  { 0x005F, 0x005F }, /* 0x5F          LOW LINE*/
  { 0x0060, 0x0060 }, /* 0x60          GRAVE ACCENT*/
  { 0x0061, 0x0041 }, /* 0x61          LATIN SMALL LETTER A*/
  { 0x0062, 0x0042 }, /* 0x62          LATIN SMALL LETTER B*/
  { 0x0063, 0x0043 }, /* 0x63          LATIN SMALL LETTER C*/
  { 0x0064, 0x0044 }, /* 0x64          LATIN SMALL LETTER D*/
  { 0x0065, 0x0045 }, /* 0x65          LATIN SMALL LETTER E*/
  { 0x0066, 0x0046 }, /* 0x66          LATIN SMALL LETTER F*/
  { 0x0067, 0x0047 }, /* 0x67          LATIN SMALL LETTER G*/
  { 0x0068, 0x0048 }, /* 0x68          LATIN SMALL LETTER H*/
  { 0x0069, 0x0049 }, /* 0x69          LATIN SMALL LETTER I*/
  { 0x006A, 0x004A }, /* 0x6A          LATIN SMALL LETTER J*/
  { 0x006B, 0x004B }, /* 0x6B          LATIN SMALL LETTER K*/
  { 0x006C, 0x004C }, /* 0x6C          LATIN SMALL LETTER L*/
  { 0x006D, 0x004D }, /* 0x6D          LATIN SMALL LETTER M*/
  { 0x006E, 0x004E }, /* 0x6E          LATIN SMALL LETTER N*/
  { 0x006F, 0x004F }, /* 0x6F          LATIN SMALL LETTER O*/
  { 0x0070, 0x0050 }, /* 0x70          LATIN SMALL LETTER P*/
  { 0x0071, 0x0051 }, /* 0x71          LATIN SMALL LETTER Q*/
  { 0x0072, 0x0052 }, /* 0x72          LATIN SMALL LETTER R*/
  { 0x0073, 0x0053 }, /* 0x73          LATIN SMALL LETTER S*/
  { 0x0074, 0x0054 }, /* 0x74          LATIN SMALL LETTER T*/
  { 0x0075, 0x0055 }, /* 0x75          LATIN SMALL LETTER U*/
  { 0x0076, 0x0056 }, /* 0x76          LATIN SMALL LETTER V*/
  { 0x0077, 0x0057 }, /* 0x77          LATIN SMALL LETTER W*/
  { 0x0078, 0x0058 }, /* 0x78          LATIN SMALL LETTER X*/
  { 0x0079, 0x0059 }, /* 0x79          LATIN SMALL LETTER Y*/
  { 0x007A, 0x005A }, /* 0x7A          LATIN SMALL LETTER Z*/
  { 0x007B, 0x007B }, /* 0x7B          LEFT CURLY BRACKET*/
  { 0x007C, 0x007C }, /* 0x7C          VERTICAL LINE*/
  { 0x007D, 0x007D }, /* 0x7D          RIGHT CURLY BRACKET*/
  { 0x007E, 0x007E }, /* 0x7E          TILDE*/
  { 0x007F, 0x007F }, /* 0x7F          DELETE*/
  { 0x0410, 0x0410 }, /* 0x80          CYRILLIC CAPITAL LETTER A*/
  { 0x0411, 0x0411 }, /* 0x81          CYRILLIC CAPITAL LETTER BE*/
  { 0x0412, 0x0412 }, /* 0x82          CYRILLIC CAPITAL LETTER VE*/
  { 0x0413, 0x0413 }, /* 0x83          CYRILLIC CAPITAL LETTER GHE*/
  { 0x0414, 0x0414 }, /* 0x84          CYRILLIC CAPITAL LETTER DE*/
  { 0x0415, 0x0415 }, /* 0x85          CYRILLIC CAPITAL LETTER IE*/
  { 0x0416, 0x0416 }, /* 0x86          CYRILLIC CAPITAL LETTER ZHE*/
  { 0x0417, 0x0417 }, /* 0x87          CYRILLIC CAPITAL LETTER ZE*/
  { 0x0418, 0x0418 }, /* 0x88          CYRILLIC CAPITAL LETTER I*/
  { 0x0419, 0x0419 }, /* 0x89          CYRILLIC CAPITAL LETTER SHORT I*/
  { 0x041A, 0x041A }, /* 0x8A          CYRILLIC CAPITAL LETTER KA*/
  { 0x041B, 0x041B }, /* 0x8B          CYRILLIC CAPITAL LETTER EL*/
  { 0x041C, 0x041C }, /* 0x8C          CYRILLIC CAPITAL LETTER EM*/
  { 0x041D, 0x041D }, /* 0x8D          CYRILLIC CAPITAL LETTER EN*/
  { 0x041E, 0x041E }, /* 0x8E          CYRILLIC CAPITAL LETTER O*/
  { 0x041F, 0x041F }, /* 0x8F          CYRILLIC CAPITAL LETTER PE*/
  { 0x0420, 0x0420 }, /* 0x90          CYRILLIC CAPITAL LETTER ER*/
  { 0x0421, 0x0421 }, /* 0x91          CYRILLIC CAPITAL LETTER ES*/
  { 0x0422, 0x0422 }, /* 0x92          CYRILLIC CAPITAL LETTER TE*/
  { 0x0423, 0x0423 }, /* 0x93          CYRILLIC CAPITAL LETTER U*/
  { 0x0424, 0x0424 }, /* 0x94          CYRILLIC CAPITAL LETTER EF*/
  { 0x0425, 0x0425 }, /* 0x95          CYRILLIC CAPITAL LETTER HA*/
  { 0x0426, 0x0426 }, /* 0x96          CYRILLIC CAPITAL LETTER TSE*/
  { 0x0427, 0x0427 }, /* 0x97          CYRILLIC CAPITAL LETTER CHE*/
  { 0x0428, 0x0428 }, /* 0x98          CYRILLIC CAPITAL LETTER SHA*/
  { 0x0429, 0x0429 }, /* 0x99          CYRILLIC CAPITAL LETTER SHCHA*/
  { 0x042A, 0x042A }, /* 0x9A          CYRILLIC CAPITAL LETTER HARD SIGN*/
  { 0x042B, 0x042B }, /* 0x9B          CYRILLIC CAPITAL LETTER YERU*/
  { 0x042C, 0x042C }, /* 0x9C          CYRILLIC CAPITAL LETTER SOFT SIGN*/
  { 0x042D, 0x042D }, /* 0x9D          CYRILLIC CAPITAL LETTER E*/
  { 0x042E, 0x042E }, /* 0x9E          CYRILLIC CAPITAL LETTER YU*/
  { 0x042F, 0x042F }, /* 0x9F          CYRILLIC CAPITAL LETTER YA*/
  { 0x0430, 0x0410 }, /* 0xA0          CYRILLIC SMALL LETTER A*/
  { 0x0431, 0x0411 }, /* 0xA1          CYRILLIC SMALL LETTER BE*/
  { 0x0432, 0x0412 }, /* 0xA2          CYRILLIC SMALL LETTER VE*/
  { 0x0433, 0x0413 }, /* 0xA3          CYRILLIC SMALL LETTER GHE*/
  { 0x0434, 0x0414 }, /* 0xA4          CYRILLIC SMALL LETTER DE*/
  { 0x0435, 0x0415 }, /* 0xA5          CYRILLIC SMALL LETTER IE*/
  { 0x0436, 0x0416 }, /* 0xA6          CYRILLIC SMALL LETTER ZHE*/
  { 0x0437, 0x0417 }, /* 0xA7          CYRILLIC SMALL LETTER ZE*/
  { 0x0438, 0x0418 }, /* 0xA8          CYRILLIC SMALL LETTER I*/
  { 0x0439, 0x0419 }, /* 0xA9          CYRILLIC SMALL LETTER SHORT I*/
  { 0x043A, 0x041A }, /* 0xAA          CYRILLIC SMALL LETTER KA*/
  { 0x043B, 0x041B }, /* 0xAB          CYRILLIC SMALL LETTER EL*/
  { 0x043C, 0x041C }, /* 0xAC          CYRILLIC SMALL LETTER EM*/
  { 0x043D, 0x041D }, /* 0xAD          CYRILLIC SMALL LETTER EN*/
  { 0x043E, 0x041E }, /* 0xAE          CYRILLIC SMALL LETTER O*/
  { 0x043F, 0x041F }, /* 0xAF          CYRILLIC SMALL LETTER PE*/
  { 0x2591, 0x2591 }, /* 0xB0          LIGHT SHADE*/
  { 0x2592, 0x2592 }, /* 0xB1          MEDIUM SHADE*/
  { 0x2593, 0x2593 }, /* 0xB2          DARK SHADE*/
  { 0x2502, 0x2502 }, /* 0xB3          BOX DRAWINGS LIGHT VERTICAL*/
  { 0x2524, 0x2524 }, /* 0xB4          BOX DRAWINGS LIGHT VERTICAL AND LEFT*/
  { 0x2561, 0x2561 }, /* 0xB5          BOX DRAWINGS VERTICAL SINGLE AND LEFT DOUBLE*/
  { 0x2562, 0x2562 }, /* 0xB6          BOX DRAWINGS VERTICAL DOUBLE AND LEFT SINGLE*/
  { 0x2556, 0x2556 }, /* 0xB7          BOX DRAWINGS DOWN DOUBLE AND LEFT SINGLE*/
  { 0x2555, 0x2555 }, /* 0xB8          BOX DRAWINGS DOWN SINGLE AND LEFT DOUBLE*/
  { 0x2563, 0x2563 }, /* 0xB9          BOX DRAWINGS DOUBLE VERTICAL AND LEFT*/
  { 0x2551, 0x2551 }, /* 0xBA          BOX DRAWINGS DOUBLE VERTICAL*/
  { 0x2557, 0x2557 }, /* 0xBB          BOX DRAWINGS DOUBLE DOWN AND LEFT*/
  { 0x255D, 0x255D }, /* 0xBC          BOX DRAWINGS DOUBLE UP AND LEFT*/
  { 0x255C, 0x255C }, /* 0xBD          BOX DRAWINGS UP DOUBLE AND LEFT SINGLE*/
  { 0x255B, 0x255B }, /* 0xBE          BOX DRAWINGS UP SINGLE AND LEFT DOUBLE*/
  { 0x2510, 0x2510 }, /* 0xBF          BOX DRAWINGS LIGHT DOWN AND LEFT*/
  { 0x2514, 0x2514 }, /* 0xC0          BOX DRAWINGS LIGHT UP AND RIGHT*/
  { 0x2534, 0x2534 }, /* 0xC1          BOX DRAWINGS LIGHT UP AND HORIZONTAL*/
  { 0x252C, 0x252C }, /* 0xC2          BOX DRAWINGS LIGHT DOWN AND HORIZONTAL*/
  { 0x251C, 0x251C }, /* 0xC3          BOX DRAWINGS LIGHT VERTICAL AND RIGHT*/
  { 0x2500, 0x2500 }, /* 0xC4          BOX DRAWINGS LIGHT HORIZONTAL*/
  { 0x253C, 0x253C }, /* 0xC5          BOX DRAWINGS LIGHT VERTICAL AND HORIZONTAL*/
  { 0x255E, 0x255E }, /* 0xC6          BOX DRAWINGS VERTICAL SINGLE AND RIGHT DOUBLE*/
  { 0x255F, 0x255F }, /* 0xC7          BOX DRAWINGS VERTICAL DOUBLE AND RIGHT SINGLE*/
  { 0x255A, 0x255A }, /* 0xC8          BOX DRAWINGS DOUBLE UP AND RIGHT*/
  { 0x2554, 0x2554 }, /* 0xC9          BOX DRAWINGS DOUBLE DOWN AND RIGHT*/
  { 0x2569, 0x2569 }, /* 0xCA          BOX DRAWINGS DOUBLE UP AND HORIZONTAL*/
  { 0x2566, 0x2566 }, /* 0xCB          BOX DRAWINGS DOUBLE DOWN AND HORIZONTAL*/
  { 0x2560, 0x2560 }, /* 0xCC          BOX DRAWINGS DOUBLE VERTICAL AND RIGHT*/
  { 0x2550, 0x2550 }, /* 0xCD          BOX DRAWINGS DOUBLE HORIZONTAL*/
  { 0x256C, 0x256C }, /* 0xCE          BOX DRAWINGS DOUBLE VERTICAL AND HORIZONTAL*/
  { 0x2567, 0x2567 }, /* 0xCF          BOX DRAWINGS UP SINGLE AND HORIZONTAL DOUBLE*/
  { 0x2568, 0x2568 }, /* 0xD0          BOX DRAWINGS UP DOUBLE AND HORIZONTAL SINGLE*/
  { 0x2564, 0x2564 }, /* 0xD1          BOX DRAWINGS DOWN SINGLE AND HORIZONTAL DOUBLE*/
  { 0x2565, 0x2565 }, /* 0xD2          BOX DRAWINGS DOWN DOUBLE AND HORIZONTAL SINGLE*/
  { 0x2559, 0x2559 }, /* 0xD3          BOX DRAWINGS UP DOUBLE AND RIGHT SINGLE*/
  { 0x2558, 0x2558 }, /* 0xD4          BOX DRAWINGS UP SINGLE AND RIGHT DOUBLE*/
  { 0x2552, 0x2552 }, /* 0xD5          BOX DRAWINGS DOWN SINGLE AND RIGHT DOUBLE*/
  { 0x2553, 0x2553 }, /* 0xD6          BOX DRAWINGS DOWN DOUBLE AND RIGHT SINGLE*/
  { 0x256B, 0x256B }, /* 0xD7          BOX DRAWINGS VERTICAL DOUBLE AND HORIZONTAL SINGLE*/
  { 0x256A, 0x256A }, /* 0xD8          BOX DRAWINGS VERTICAL SINGLE AND HORIZONTAL DOUBLE*/
  { 0x2518, 0x2518 }, /* 0xD9          BOX DRAWINGS LIGHT UP AND LEFT*/
  { 0x250C, 0x250C }, /* 0xDA          BOX DRAWINGS LIGHT DOWN AND RIGHT*/
  { 0x2588, 0x2588 }, /* 0xDB          FULL BLOCK*/
  { 0x2584, 0x2584 }, /* 0xDC          LOWER HALF BLOCK*/
  { 0x258C, 0x258C }, /* 0xDD          LEFT HALF BLOCK*/
  { 0x2590, 0x2590 }, /* 0xDE          RIGHT HALF BLOCK*/
  { 0x2580, 0x2580 }, /* 0xDF          UPPER HALF BLOCK*/
  { 0x0440, 0x0420 }, /* 0xE0          CYRILLIC SMALL LETTER ER*/
  { 0x0441, 0x0421 }, /* 0xE1          CYRILLIC SMALL LETTER ES*/
  { 0x0442, 0x0422 }, /* 0xE2          CYRILLIC SMALL LETTER TE*/
  { 0x0443, 0x0423 }, /* 0xE3          CYRILLIC SMALL LETTER U*/
  { 0x0444, 0x0424 }, /* 0xE4          CYRILLIC SMALL LETTER EF*/
  { 0x0445, 0x0425 }, /* 0xE5          CYRILLIC SMALL LETTER HA*/
  { 0x0446, 0x0426 }, /* 0xE6          CYRILLIC SMALL LETTER TSE*/
  { 0x0447, 0x0427 }, /* 0xE7          CYRILLIC SMALL LETTER CHE*/
  { 0x0448, 0x0428 }, /* 0xE8          CYRILLIC SMALL LETTER SHA*/
  { 0x0449, 0x0429 }, /* 0xE9          CYRILLIC SMALL LETTER SHCHA*/
  { 0x044A, 0x042A }, /* 0xEA          CYRILLIC SMALL LETTER HARD SIGN*/
  { 0x044B, 0x042B }, /* 0xEB          CYRILLIC SMALL LETTER YERU*/
  { 0x044C, 0x042C }, /* 0xEC          CYRILLIC SMALL LETTER SOFT SIGN*/
  { 0x044D, 0x042D }, /* 0xED          CYRILLIC SMALL LETTER E*/
  { 0x044E, 0x042E }, /* 0xEE          CYRILLIC SMALL LETTER YU*/
  { 0x044F, 0x042F }, /* 0xEF          CYRILLIC SMALL LETTER YA*/
  { 0x0401, 0x0401 }, /* 0xF0          CYRILLIC CAPITAL LETTER IO*/
  { 0x0451, 0x0401 }, /* 0xF1          CYRILLIC SMALL LETTER IO*/
  { 0x0404, 0x0404 }, /* 0xF2          CYRILLIC CAPITAL LETTER UKRAINIAN IE*/
  { 0x0454, 0x0404 }, /* 0xF3          CYRILLIC SMALL LETTER UKRAINIAN IE*/
  { 0x0407, 0x0407 }, /* 0xF4          CYRILLIC CAPITAL LETTER YI*/
  { 0x0457, 0x0407 }, /* 0xF5          CYRILLIC SMALL LETTER YI*/
  { 0x040E, 0x040E }, /* 0xF6          CYRILLIC CAPITAL LETTER SHORT U*/
  { 0x045E, 0x040E }, /* 0xF7          CYRILLIC SMALL LETTER SHORT U*/
  { 0x00B0, 0x00B0 }, /* 0xF8          DEGREE SIGN*/
  { 0x2219, 0x2219 }, /* 0xF9          BULLET OPERATOR*/
  { 0x00B7, 0x00B7 }, /* 0xFA          MIDDLE DOT*/
  { 0x221A, 0x221A }, /* 0xFB          SQUARE ROOT*/
  { 0x2116, 0x2116 }, /* 0xFC          NUMERO SIGN*/
  { 0x00A4, 0x00A4 }, /* 0xFD          CURRENCY SIGN*/
  { 0x25A0, 0x25A0 }, /* 0xFE          BLACK SQUARE*/
  { 0x00A0, 0x00A0 }  /* 0xFF          NO-BREAK SPACE*/
};

static char_t koi8_r[] =
{
  { 0x0000, 0x0000 }, /* 0x00          NULL*/
  { 0x0001, 0x0001 }, /* 0x01          START OF HEADING*/
  { 0x0002, 0x0002 }, /* 0x02          START OF TEXT*/
  { 0x0003, 0x0003 }, /* 0x03          END OF TEXT*/
  { 0x0004, 0x0004 }, /* 0x04          END OF TRANSMISSION*/
  { 0x0005, 0x0005 }, /* 0x05          ENQUIRY*/
  { 0x0006, 0x0006 }, /* 0x06          ACKNOWLEDGE*/
  { 0x0007, 0x0007 }, /* 0x07          BELL*/
  { 0x0008, 0x0008 }, /* 0x08          BACKSPACE*/
  { 0x0009, 0x0009 }, /* 0x09          HORIZONTAL TABULATION*/
  { 0x000A, 0x000A }, /* 0x0A          LINE FEED*/
  { 0x000B, 0x000B }, /* 0x0B          VERTICAL TABULATION*/
  { 0x000C, 0x000C }, /* 0x0C          FORM FEED*/
  { 0x000D, 0x000D }, /* 0x0D          CARRIAGE RETURN*/
  { 0x000E, 0x000E }, /* 0x0E          SHIFT OUT*/
  { 0x000F, 0x000F }, /* 0x0F          SHIFT IN*/
  { 0x0010, 0x0010 }, /* 0x10          DATA LINK ESCAPE*/
  { 0x0011, 0x0011 }, /* 0x11          DEVICE CONTROL ONE*/
  { 0x0012, 0x0012 }, /* 0x12          DEVICE CONTROL TWO*/
  { 0x0013, 0x0013 }, /* 0x13          DEVICE CONTROL THREE*/
  { 0x0014, 0x0014 }, /* 0x14          DEVICE CONTROL FOUR*/
  { 0x0015, 0x0015 }, /* 0x15          NEGATIVE ACKNOWLEDGE*/
  { 0x0016, 0x0016 }, /* 0x16          SYNCHRONOUS IDLE*/
  { 0x0017, 0x0017 }, /* 0x17          END OF TRANSMISSION BLOCK*/
  { 0x0018, 0x0018 }, /* 0x18          CANCEL*/
  { 0x0019, 0x0019 }, /* 0x19          END OF MEDIUM*/
  { 0x001A, 0x001A }, /* 0x1A          SUBSTITUTE*/
  { 0x001B, 0x001B }, /* 0x1B          ESCAPE*/
  { 0x001C, 0x001C }, /* 0x1C          FILE SEPARATOR*/
  { 0x001D, 0x001D }, /* 0x1D          GROUP SEPARATOR*/
  { 0x001E, 0x001E }, /* 0x1E          RECORD SEPARATOR*/
  { 0x001F, 0x001F }, /* 0x1F          UNIT SEPARATOR*/
  { 0x0020, 0x0020 }, /* 0x20          SPACE*/
  { 0x0021, 0x0021 }, /* 0x21          EXCLAMATION MARK*/
  { 0x0022, 0x0022 }, /* 0x22          QUOTATION MARK*/
  { 0x0023, 0x0023 }, /* 0x23          NUMBER SIGN*/
  { 0x0024, 0x0024 }, /* 0x24          DOLLAR SIGN*/
  { 0x0025, 0x0025 }, /* 0x25          PERCENT SIGN*/
  { 0x0026, 0x0026 }, /* 0x26          AMPERSAND*/
  { 0x0027, 0x0027 }, /* 0x27          APOSTROPHE*/
  { 0x0028, 0x0028 }, /* 0x28          LEFT PARENTHESIS*/
  { 0x0029, 0x0029 }, /* 0x29          RIGHT PARENTHESIS*/
  { 0x002A, 0x002A }, /* 0x2A          ASTERISK*/
  { 0x002B, 0x002B }, /* 0x2B          PLUS SIGN*/
  { 0x002C, 0x002C }, /* 0x2C          COMMA*/
  { 0x002D, 0x002D }, /* 0x2D          HYPHEN-MINUS*/
  { 0x002E, 0x002E }, /* 0x2E          FULL STOP*/
  { 0x002F, 0x002F }, /* 0x2F          SOLIDUS*/
  { 0x0030, 0x0030 }, /* 0x30          DIGIT ZERO*/
  { 0x0031, 0x0031 }, /* 0x31          DIGIT ONE*/
  { 0x0032, 0x0032 }, /* 0x32          DIGIT TWO*/
  { 0x0033, 0x0033 }, /* 0x33          DIGIT THREE*/
  { 0x0034, 0x0034 }, /* 0x34          DIGIT FOUR*/
  { 0x0035, 0x0035 }, /* 0x35          DIGIT FIVE*/
  { 0x0036, 0x0036 }, /* 0x36          DIGIT SIX*/
  { 0x0037, 0x0037 }, /* 0x37          DIGIT SEVEN*/
  { 0x0038, 0x0038 }, /* 0x38          DIGIT EIGHT*/
  { 0x0039, 0x0039 }, /* 0x39          DIGIT NINE*/
  { 0x003A, 0x003A }, /* 0x3A          COLON*/
  { 0x003B, 0x003B }, /* 0x3B          SEMICOLON*/
  { 0x003C, 0x003C }, /* 0x3C          LESS-THAN SIGN*/
  { 0x003D, 0x003D }, /* 0x3D          EQUALS SIGN*/
  { 0x003E, 0x003E }, /* 0x3E          GREATER-THAN SIGN*/
  { 0x003F, 0x003F }, /* 0x3F          QUESTION MARK*/
  { 0x0040, 0x0040 }, /* 0x40          COMMERCIAL AT*/
  { 0x0041, 0x0041 }, /* 0x41          LATIN CAPITAL LETTER A*/
  { 0x0042, 0x0042 }, /* 0x42          LATIN CAPITAL LETTER B*/
  { 0x0043, 0x0043 }, /* 0x43          LATIN CAPITAL LETTER C*/
  { 0x0044, 0x0044 }, /* 0x44          LATIN CAPITAL LETTER D*/
  { 0x0045, 0x0045 }, /* 0x45          LATIN CAPITAL LETTER E*/
  { 0x0046, 0x0046 }, /* 0x46          LATIN CAPITAL LETTER F*/
  { 0x0047, 0x0047 }, /* 0x47          LATIN CAPITAL LETTER G*/
  { 0x0048, 0x0048 }, /* 0x48          LATIN CAPITAL LETTER H*/
  { 0x0049, 0x0049 }, /* 0x49          LATIN CAPITAL LETTER I*/
  { 0x004A, 0x004A }, /* 0x4A          LATIN CAPITAL LETTER J*/
  { 0x004B, 0x004B }, /* 0x4B          LATIN CAPITAL LETTER K*/
  { 0x004C, 0x004C }, /* 0x4C          LATIN CAPITAL LETTER L*/
  { 0x004D, 0x004D }, /* 0x4D          LATIN CAPITAL LETTER M*/
  { 0x004E, 0x004E }, /* 0x4E          LATIN CAPITAL LETTER N*/
  { 0x004F, 0x004F }, /* 0x4F          LATIN CAPITAL LETTER O*/
  { 0x0050, 0x0050 }, /* 0x50          LATIN CAPITAL LETTER P*/
  { 0x0051, 0x0051 }, /* 0x51          LATIN CAPITAL LETTER Q*/
  { 0x0052, 0x0052 }, /* 0x52          LATIN CAPITAL LETTER R*/
  { 0x0053, 0x0053 }, /* 0x53          LATIN CAPITAL LETTER S*/
  { 0x0054, 0x0054 }, /* 0x54          LATIN CAPITAL LETTER T*/
  { 0x0055, 0x0055 }, /* 0x55          LATIN CAPITAL LETTER U*/
  { 0x0056, 0x0056 }, /* 0x56          LATIN CAPITAL LETTER V*/
  { 0x0057, 0x0057 }, /* 0x57          LATIN CAPITAL LETTER W*/
  { 0x0058, 0x0058 }, /* 0x58          LATIN CAPITAL LETTER X*/
  { 0x0059, 0x0059 }, /* 0x59          LATIN CAPITAL LETTER Y*/
  { 0x005A, 0x005A }, /* 0x5A          LATIN CAPITAL LETTER Z*/
  { 0x005B, 0x005B }, /* 0x5B          LEFT SQUARE BRACKET*/
  { 0x005C, 0x005C }, /* 0x5C          REVERSE SOLIDUS*/
  { 0x005D, 0x005D }, /* 0x5D          RIGHT SQUARE BRACKET*/
  { 0x005E, 0x005E }, /* 0x5E          CIRCUMFLEX ACCENT*/
  { 0x005F, 0x005F }, /* 0x5F          LOW LINE*/
  { 0x0060, 0x0060 }, /* 0x60          GRAVE ACCENT*/
  { 0x0061, 0x0041 }, /* 0x61          LATIN SMALL LETTER A*/
  { 0x0062, 0x0042 }, /* 0x62          LATIN SMALL LETTER B*/
  { 0x0063, 0x0043 }, /* 0x63          LATIN SMALL LETTER C*/
  { 0x0064, 0x0044 }, /* 0x64          LATIN SMALL LETTER D*/
  { 0x0065, 0x0045 }, /* 0x65          LATIN SMALL LETTER E*/
  { 0x0066, 0x0046 }, /* 0x66          LATIN SMALL LETTER F*/
  { 0x0067, 0x0047 }, /* 0x67          LATIN SMALL LETTER G*/
  { 0x0068, 0x0048 }, /* 0x68          LATIN SMALL LETTER H*/
  { 0x0069, 0x0049 }, /* 0x69          LATIN SMALL LETTER I*/
  { 0x006A, 0x004A }, /* 0x6A          LATIN SMALL LETTER J*/
  { 0x006B, 0x004B }, /* 0x6B          LATIN SMALL LETTER K*/
  { 0x006C, 0x004C }, /* 0x6C          LATIN SMALL LETTER L*/
  { 0x006D, 0x004D }, /* 0x6D          LATIN SMALL LETTER M*/
  { 0x006E, 0x004E }, /* 0x6E          LATIN SMALL LETTER N*/
  { 0x006F, 0x004F }, /* 0x6F          LATIN SMALL LETTER O*/
  { 0x0070, 0x0050 }, /* 0x70          LATIN SMALL LETTER P*/
  { 0x0071, 0x0051 }, /* 0x71          LATIN SMALL LETTER Q*/
  { 0x0072, 0x0052 }, /* 0x72          LATIN SMALL LETTER R*/
  { 0x0073, 0x0053 }, /* 0x73          LATIN SMALL LETTER S*/
  { 0x0074, 0x0054 }, /* 0x74          LATIN SMALL LETTER T*/
  { 0x0075, 0x0055 }, /* 0x75          LATIN SMALL LETTER U*/
  { 0x0076, 0x0056 }, /* 0x76          LATIN SMALL LETTER V*/
  { 0x0077, 0x0057 }, /* 0x77          LATIN SMALL LETTER W*/
  { 0x0078, 0x0058 }, /* 0x78          LATIN SMALL LETTER X*/
  { 0x0079, 0x0059 }, /* 0x79          LATIN SMALL LETTER Y*/
  { 0x007A, 0x005A }, /* 0x7A          LATIN SMALL LETTER Z*/
  { 0x007B, 0x007B }, /* 0x7B          LEFT CURLY BRACKET*/
  { 0x007C, 0x007C }, /* 0x7C          VERTICAL LINE*/
  { 0x007D, 0x007D }, /* 0x7D          RIGHT CURLY BRACKET*/
  { 0x007E, 0x007E }, /* 0x7E          TILDE*/
  { 0x007F, 0x007F }, /* 0x7F          DELETE*/
  { 0x2500, 0x2500 }, /* 0x80          FORMS LIGHT HORIZONTAL */
  { 0x2502, 0x2502 }, /* 0x81          FORMS LIGHT VERTICAL */
  { 0x250C, 0x250C }, /* 0x82          FORMS LIGHT DOWN AND RIGHT */
  { 0x2510, 0x2510 }, /* 0x83          FORMS LIGHT DOWN AND LEFT */
  { 0x2514, 0x2514 }, /* 0x84          FORMS LIGHT UP AND RIGHT */
  { 0x2518, 0x2518 }, /* 0x85          FORMS LIGHT UP AND LEFT */
  { 0x251C, 0x251C }, /* 0x86          FORMS LIGHT VERTICAL AND RIGHT */
  { 0x2524, 0x2524 }, /* 0x87          FORMS LIGHT VERTICAL AND LEFT */
  { 0x252C, 0x252C }, /* 0x88          FORMS LIGHT DOWN AND HORIZONTAL */
  { 0x2534, 0x2534 }, /* 0x89          FORMS LIGHT UP AND HORIZONTAL */
  { 0x253C, 0x253C }, /* 0x8A          FORMS LIGHT VERTICAL AND HORIZONTAL */
  { 0x2580, 0x2580 }, /* 0x8B          UPPER HALF BLOCK */
  { 0x2584, 0x2584 }, /* 0x8C          LOWER HALF BLOCK */
  { 0x2588, 0x2588 }, /* 0x8D          FULL BLOCK */
  { 0x258C, 0x258C }, /* 0x8E          LEFT HALF BLOCK */
  { 0x2590, 0x2590 }, /* 0x8F          RIGHT HALF BLOCK */
  { 0x2591, 0x2591 }, /* 0x90          LIGHT SHADE */
  { 0x2592, 0x2592 }, /* 0x91          MEDIUM SHADE */
  { 0x2593, 0x2593 }, /* 0x92          DARK SHADE */
  { 0x2320, 0x2320 }, /* 0x93          TOP HALF INTEGRAL */
  { 0x25A0, 0x25A0 }, /* 0x94          BLACK SMALL SQUARE */
  { 0x2219, 0x2219 }, /* 0x95          BULLET OPERATOR */
  { 0x221A, 0x221A }, /* 0x96          SQUARE ROOT */
  { 0x2248, 0x2248 }, /* 0x97          ALMOST EQUAL TO */
  { 0x2264, 0x2264 }, /* 0x98          LESS THAN OR EQUAL TO */
  { 0x2265, 0x2265 }, /* 0x99          GREATER THAN OR EQUAL TO */
  { 0x00A0, 0x00A0 }, /* 0x9A          NON-BREAKING SPACE */
  { 0x2321, 0x2321 }, /* 0x9B          BOTTOM HALF INTEGRAL */
  { 0x00B0, 0x00B0 }, /* 0x9C          DEGREE SIGN */
  { 0x00B2, 0x00B2 }, /* 0x9D          SUPERSCRIPT DIGIT TWO */
  { 0x00B7, 0x00B7 }, /* 0x9E          MIDDLE DOT */
  { 0x00F7, 0x00F7 }, /* 0x9F          DIVISION SIGN */
  { 0x2550, 0x2550 }, /* 0xA0          FORMS DOUBLE HORIZONTAL */
  { 0x2551, 0x2551 }, /* 0xA1          FORMS DOUBLE VERTICAL */
  { 0x2552, 0x2552 }, /* 0xA2          FORMS DOWN SINGLE AND RIGHT DOUBLE */
  { 0x0451, 0x0401 }, /* 0xA3          CYRILLIC SMALL LETTER IO */
  { 0x2553, 0x2553 }, /* 0xA4          FORMS DOWN DOUBLE AND RIGHT SINGLE */
  { 0x2554, 0x2554 }, /* 0xA5          FORMS DOUBLE DOWN AND RIGHT */
  { 0x2555, 0x2555 }, /* 0xA6          FORMS DOWN SINGLE AND LEFT DOUBLE */
  { 0x2556, 0x2556 }, /* 0xA7          FORMS DOWN DOUBLE AND LEFT SINGLE */
  { 0x2557, 0x2557 }, /* 0xA8          FORMS DOUBLE DOWN AND LEFT */
  { 0x2558, 0x2558 }, /* 0xA9          FORMS UP SINGLE AND RIGHT DOUBLE */
  { 0x2559, 0x2559 }, /* 0xAA          FORMS UP DOUBLE AND RIGHT SINGLE */
  { 0x255A, 0x255A }, /* 0xAB          FORMS DOUBLE UP AND RIGHT */
  { 0x255B, 0x255B }, /* 0xAC          FORMS UP SINGLE AND LEFT DOUBLE */
  { 0x255C, 0x255C }, /* 0xAD          FORMS UP DOUBLE AND LEFT SINGLE */
  { 0x255D, 0x255D }, /* 0xAE          FORMS DOUBLE UP AND LEFT */
  { 0x255E, 0x255E }, /* 0xAF          FORMS VERTICAL SINGLE AND RIGHT DOUBLE */
  { 0x255F, 0x255F }, /* 0xB0          FORMS VERTICAL DOUBLE AND RIGHT SINGLE */
  { 0x2560, 0x2560 }, /* 0xB1          FORMS DOUBLE VERTICAL AND RIGHT */
  { 0x2561, 0x2561 }, /* 0xB2          FORMS VERTICAL SINGLE AND LEFT DOUBLE */
  { 0x0401, 0x0401 }, /* 0xB3          CYRILLIC CAPITAL LETTER IO */
  { 0x2562, 0x2562 }, /* 0xB4          FORMS VERTICAL DOUBLE AND LEFT SINGLE */
  { 0x2563, 0x2563 }, /* 0xB5          FORMS DOUBLE VERTICAL AND LEFT */
  { 0x2564, 0x2564 }, /* 0xB6          FORMS DOWN SINGLE AND HORIZONTAL DOUBLE */
  { 0x2565, 0x2565 }, /* 0xB7          FORMS DOWN DOUBLE AND HORIZONTAL SINGLE */
  { 0x2566, 0x2566 }, /* 0xB8          FORMS DOUBLE DOWN AND HORIZONTAL */
  { 0x2567, 0x2567 }, /* 0xB9          FORMS UP SINGLE AND HORIZONTAL DOUBLE */
  { 0x2568, 0x2568 }, /* 0xBA          FORMS UP DOUBLE AND HORIZONTAL SINGLE */
  { 0x2569, 0x2569 }, /* 0xBB          FORMS DOUBLE UP AND HORIZONTAL */
  { 0x256A, 0x256A }, /* 0xBC          FORMS VERTICAL SINGLE AND HORIZONTAL DOUBLE */
  { 0x256B, 0x256B }, /* 0xBD          FORMS VERTICAL DOUBLE AND HORIZONTAL SINGLE */
  { 0x256C, 0x256C }, /* 0xBE          FORMS DOUBLE VERTICAL AND HORIZONTAL */
  { 0x00A9, 0x00A9 }, /* 0xBF          COPYRIGHT SIGN */
  { 0x044E, 0x042E }, /* 0xC0          CYRILLIC SMALL LETTER IU */
  { 0x0430, 0x0410 }, /* 0xC1          CYRILLIC SMALL LETTER A */
  { 0x0431, 0x0411 }, /* 0xC2          CYRILLIC SMALL LETTER BE */
  { 0x0446, 0x0426 }, /* 0xC3          CYRILLIC SMALL LETTER TSE */
  { 0x0434, 0x0414 }, /* 0xC4          CYRILLIC SMALL LETTER DE */
  { 0x0435, 0x0415 }, /* 0xC5          CYRILLIC SMALL LETTER IE */
  { 0x0444, 0x0424 }, /* 0xC6          CYRILLIC SMALL LETTER EF */
  { 0x0433, 0x0413 }, /* 0xC7          CYRILLIC SMALL LETTER GE */
  { 0x0445, 0x0425 }, /* 0xC8          CYRILLIC SMALL LETTER KHA */
  { 0x0438, 0x0418 }, /* 0xC9          CYRILLIC SMALL LETTER II */
  { 0x0439, 0x0419 }, /* 0xCA          CYRILLIC SMALL LETTER SHORT II */
  { 0x043A, 0x041A }, /* 0xCB          CYRILLIC SMALL LETTER KA */
  { 0x043B, 0x041B }, /* 0xCC          CYRILLIC SMALL LETTER EL */
  { 0x043C, 0x041C }, /* 0xCD          CYRILLIC SMALL LETTER EM */
  { 0x043D, 0x041D }, /* 0xCE          CYRILLIC SMALL LETTER EN */
  { 0x043E, 0x041E }, /* 0xCF          CYRILLIC SMALL LETTER O */
  { 0x043F, 0x041F }, /* 0xD0          CYRILLIC SMALL LETTER PE */
  { 0x044F, 0x042F }, /* 0xD1          CYRILLIC SMALL LETTER IA */
  { 0x0440, 0x0420 }, /* 0xD2          CYRILLIC SMALL LETTER ER */
  { 0x0441, 0x0421 }, /* 0xD3          CYRILLIC SMALL LETTER ES */
  { 0x0442, 0x0422 }, /* 0xD4          CYRILLIC SMALL LETTER TE */
  { 0x0443, 0x0423 }, /* 0xD5          CYRILLIC SMALL LETTER U */
  { 0x0436, 0x0416 }, /* 0xD6          CYRILLIC SMALL LETTER ZHE */
  { 0x0432, 0x0412 }, /* 0xD7          CYRILLIC SMALL LETTER VE */
  { 0x044C, 0x042C }, /* 0xD8          CYRILLIC SMALL LETTER SOFT SIGN */
  { 0x044B, 0x042B }, /* 0xD9          CYRILLIC SMALL LETTER YERI */
  { 0x0437, 0x0417 }, /* 0xDA          CYRILLIC SMALL LETTER ZE */
  { 0x0448, 0x0428 }, /* 0xDB          CYRILLIC SMALL LETTER SHA */
  { 0x044D, 0x042D }, /* 0xDC          CYRILLIC SMALL LETTER REVERSED E */
  { 0x0449, 0x0429 }, /* 0xDD          CYRILLIC SMALL LETTER SHCHA */
  { 0x0447, 0x0427 }, /* 0xDE          CYRILLIC SMALL LETTER CHE */
  { 0x044A, 0x042A }, /* 0xDF          CYRILLIC SMALL LETTER HARD SIGN */
  { 0x042E, 0x042E }, /* 0xE0          CYRILLIC CAPITAL LETTER IU */
  { 0x0410, 0x0410 }, /* 0xE1          CYRILLIC CAPITAL LETTER A */
  { 0x0411, 0x0411 }, /* 0xE2          CYRILLIC CAPITAL LETTER BE */
  { 0x0426, 0x0426 }, /* 0xE3          CYRILLIC CAPITAL LETTER TSE */
  { 0x0414, 0x0414 }, /* 0xE4          CYRILLIC CAPITAL LETTER DE */
  { 0x0415, 0x0415 }, /* 0xE5          CYRILLIC CAPITAL LETTER IE */
  { 0x0424, 0x0424 }, /* 0xE6          CYRILLIC CAPITAL LETTER EF */
  { 0x0413, 0x0413 }, /* 0xE7          CYRILLIC CAPITAL LETTER GE */
  { 0x0425, 0x0425 }, /* 0xE8          CYRILLIC CAPITAL LETTER KHA */
  { 0x0418, 0x0418 }, /* 0xE9          CYRILLIC CAPITAL LETTER II */
  { 0x0419, 0x0419 }, /* 0xEA          CYRILLIC CAPITAL LETTER SHORT II */
  { 0x041A, 0x041A }, /* 0xEB          CYRILLIC CAPITAL LETTER KA */
  { 0x041B, 0x041B }, /* 0xEC          CYRILLIC CAPITAL LETTER EL */
  { 0x041C, 0x041C }, /* 0xED          CYRILLIC CAPITAL LETTER EM */
  { 0x041D, 0x041D }, /* 0xEE          CYRILLIC CAPITAL LETTER EN */
  { 0x041E, 0x041E }, /* 0xEF          CYRILLIC CAPITAL LETTER O */
  { 0x041F, 0x041F }, /* 0xF0          CYRILLIC CAPITAL LETTER PE */
  { 0x042F, 0x042F }, /* 0xF1          CYRILLIC CAPITAL LETTER IA */
  { 0x0420, 0x0420 }, /* 0xF2          CYRILLIC CAPITAL LETTER ER */
  { 0x0421, 0x0421 }, /* 0xF3          CYRILLIC CAPITAL LETTER ES */
  { 0x0422, 0x0422 }, /* 0xF4          CYRILLIC CAPITAL LETTER TE */
  { 0x0423, 0x0423 }, /* 0xF5          CYRILLIC CAPITAL LETTER U */
  { 0x0416, 0x0416 }, /* 0xF6          CYRILLIC CAPITAL LETTER ZHE */
  { 0x0412, 0x0412 }, /* 0xF7          CYRILLIC CAPITAL LETTER VE */
  { 0x042C, 0x042C }, /* 0xF8          CYRILLIC CAPITAL LETTER SOFT SIGN */
  { 0x042B, 0x042B }, /* 0xF9          CYRILLIC CAPITAL LETTER YERI */
  { 0x0417, 0x0417 }, /* 0xFA          CYRILLIC CAPITAL LETTER ZE */
  { 0x0428, 0x0428 }, /* 0xFB          CYRILLIC CAPITAL LETTER SHA */
  { 0x042D, 0x042D }, /* 0xFC          CYRILLIC CAPITAL LETTER REVERSED E */
  { 0x0429, 0x0429 }, /* 0xFD          CYRILLIC CAPITAL LETTER SHCHA */
  { 0x0427, 0x0427 }, /* 0xFE          CYRILLIC CAPITAL LETTER CHE */
  { 0x042A, 0x042A }  /* 0xFF          CYRILLIC CAPITAL LETTER HARD SIGN */
};

static char_t cp1251[] =
{
  { 0x0000, 0x0000 }, /* 0x00          NULL*/
  { 0x0001, 0x0001 }, /* 0x01          START OF HEADING*/
  { 0x0002, 0x0002 }, /* 0x02          START OF TEXT*/
  { 0x0003, 0x0003 }, /* 0x03          END OF TEXT*/
  { 0x0004, 0x0004 }, /* 0x04          END OF TRANSMISSION*/
  { 0x0005, 0x0005 }, /* 0x05          ENQUIRY*/
  { 0x0006, 0x0006 }, /* 0x06          ACKNOWLEDGE*/
  { 0x0007, 0x0007 }, /* 0x07          BELL*/
  { 0x0008, 0x0008 }, /* 0x08          BACKSPACE*/
  { 0x0009, 0x0009 }, /* 0x09          HORIZONTAL TABULATION*/
  { 0x000A, 0x000A }, /* 0x0A          LINE FEED*/
  { 0x000B, 0x000B }, /* 0x0B          VERTICAL TABULATION*/
  { 0x000C, 0x000C }, /* 0x0C          FORM FEED*/
  { 0x000D, 0x000D }, /* 0x0D          CARRIAGE RETURN*/
  { 0x000E, 0x000E }, /* 0x0E          SHIFT OUT*/
  { 0x000F, 0x000F }, /* 0x0F          SHIFT IN*/
  { 0x0010, 0x0010 }, /* 0x10          DATA LINK ESCAPE*/
  { 0x0011, 0x0011 }, /* 0x11          DEVICE CONTROL ONE*/
  { 0x0012, 0x0012 }, /* 0x12          DEVICE CONTROL TWO*/
  { 0x0013, 0x0013 }, /* 0x13          DEVICE CONTROL THREE*/
  { 0x0014, 0x0014 }, /* 0x14          DEVICE CONTROL FOUR*/
  { 0x0015, 0x0015 }, /* 0x15          NEGATIVE ACKNOWLEDGE*/
  { 0x0016, 0x0016 }, /* 0x16          SYNCHRONOUS IDLE*/
  { 0x0017, 0x0017 }, /* 0x17          END OF TRANSMISSION BLOCK*/
  { 0x0018, 0x0018 }, /* 0x18          CANCEL*/
  { 0x0019, 0x0019 }, /* 0x19          END OF MEDIUM*/
  { 0x001A, 0x001A }, /* 0x1A          SUBSTITUTE*/
  { 0x001B, 0x001B }, /* 0x1B          ESCAPE*/
  { 0x001C, 0x001C }, /* 0x1C          FILE SEPARATOR*/
  { 0x001D, 0x001D }, /* 0x1D          GROUP SEPARATOR*/
  { 0x001E, 0x001E }, /* 0x1E          RECORD SEPARATOR*/
  { 0x001F, 0x001F }, /* 0x1F          UNIT SEPARATOR*/
  { 0x0020, 0x0020 }, /* 0x20          SPACE*/
  { 0x0021, 0x0021 }, /* 0x21          EXCLAMATION MARK*/
  { 0x0022, 0x0022 }, /* 0x22          QUOTATION MARK*/
  { 0x0023, 0x0023 }, /* 0x23          NUMBER SIGN*/
  { 0x0024, 0x0024 }, /* 0x24          DOLLAR SIGN*/
  { 0x0025, 0x0025 }, /* 0x25          PERCENT SIGN*/
  { 0x0026, 0x0026 }, /* 0x26          AMPERSAND*/
  { 0x0027, 0x0027 }, /* 0x27          APOSTROPHE*/
  { 0x0028, 0x0028 }, /* 0x28          LEFT PARENTHESIS*/
  { 0x0029, 0x0029 }, /* 0x29          RIGHT PARENTHESIS*/
  { 0x002A, 0x002A }, /* 0x2A          ASTERISK*/
  { 0x002B, 0x002B }, /* 0x2B          PLUS SIGN*/
  { 0x002C, 0x002C }, /* 0x2C          COMMA*/
  { 0x002D, 0x002D }, /* 0x2D          HYPHEN-MINUS*/
  { 0x002E, 0x002E }, /* 0x2E          FULL STOP*/
  { 0x002F, 0x002F }, /* 0x2F          SOLIDUS*/
  { 0x0030, 0x0030 }, /* 0x30          DIGIT ZERO*/
  { 0x0031, 0x0031 }, /* 0x31          DIGIT ONE*/
  { 0x0032, 0x0032 }, /* 0x32          DIGIT TWO*/
  { 0x0033, 0x0033 }, /* 0x33          DIGIT THREE*/
  { 0x0034, 0x0034 }, /* 0x34          DIGIT FOUR*/
  { 0x0035, 0x0035 }, /* 0x35          DIGIT FIVE*/
  { 0x0036, 0x0036 }, /* 0x36          DIGIT SIX*/
  { 0x0037, 0x0037 }, /* 0x37          DIGIT SEVEN*/
  { 0x0038, 0x0038 }, /* 0x38          DIGIT EIGHT*/
  { 0x0039, 0x0039 }, /* 0x39          DIGIT NINE*/
  { 0x003A, 0x003A }, /* 0x3A          COLON*/
  { 0x003B, 0x003B }, /* 0x3B          SEMICOLON*/
  { 0x003C, 0x003C }, /* 0x3C          LESS-THAN SIGN*/
  { 0x003D, 0x003D }, /* 0x3D          EQUALS SIGN*/
  { 0x003E, 0x003E }, /* 0x3E          GREATER-THAN SIGN*/
  { 0x003F, 0x003F }, /* 0x3F          QUESTION MARK*/
  { 0x0040, 0x0040 }, /* 0x40          COMMERCIAL AT*/
  { 0x0041, 0x0041 }, /* 0x41          LATIN CAPITAL LETTER A*/
  { 0x0042, 0x0042 }, /* 0x42          LATIN CAPITAL LETTER B*/
  { 0x0043, 0x0043 }, /* 0x43          LATIN CAPITAL LETTER C*/
  { 0x0044, 0x0044 }, /* 0x44          LATIN CAPITAL LETTER D*/
  { 0x0045, 0x0045 }, /* 0x45          LATIN CAPITAL LETTER E*/
  { 0x0046, 0x0046 }, /* 0x46          LATIN CAPITAL LETTER F*/
  { 0x0047, 0x0047 }, /* 0x47          LATIN CAPITAL LETTER G*/
  { 0x0048, 0x0048 }, /* 0x48          LATIN CAPITAL LETTER H*/
  { 0x0049, 0x0049 }, /* 0x49          LATIN CAPITAL LETTER I*/
  { 0x004A, 0x004A }, /* 0x4A          LATIN CAPITAL LETTER J*/
  { 0x004B, 0x004B }, /* 0x4B          LATIN CAPITAL LETTER K*/
  { 0x004C, 0x004C }, /* 0x4C          LATIN CAPITAL LETTER L*/
  { 0x004D, 0x004D }, /* 0x4D          LATIN CAPITAL LETTER M*/
  { 0x004E, 0x004E }, /* 0x4E          LATIN CAPITAL LETTER N*/
  { 0x004F, 0x004F }, /* 0x4F          LATIN CAPITAL LETTER O*/
  { 0x0050, 0x0050 }, /* 0x50          LATIN CAPITAL LETTER P*/
  { 0x0051, 0x0051 }, /* 0x51          LATIN CAPITAL LETTER Q*/
  { 0x0052, 0x0052 }, /* 0x52          LATIN CAPITAL LETTER R*/
  { 0x0053, 0x0053 }, /* 0x53          LATIN CAPITAL LETTER S*/
  { 0x0054, 0x0054 }, /* 0x54          LATIN CAPITAL LETTER T*/
  { 0x0055, 0x0055 }, /* 0x55          LATIN CAPITAL LETTER U*/
  { 0x0056, 0x0056 }, /* 0x56          LATIN CAPITAL LETTER V*/
  { 0x0057, 0x0057 }, /* 0x57          LATIN CAPITAL LETTER W*/
  { 0x0058, 0x0058 }, /* 0x58          LATIN CAPITAL LETTER X*/
  { 0x0059, 0x0059 }, /* 0x59          LATIN CAPITAL LETTER Y*/
  { 0x005A, 0x005A }, /* 0x5A          LATIN CAPITAL LETTER Z*/
  { 0x005B, 0x005B }, /* 0x5B          LEFT SQUARE BRACKET*/
  { 0x005C, 0x005C }, /* 0x5C          REVERSE SOLIDUS*/
  { 0x005D, 0x005D }, /* 0x5D          RIGHT SQUARE BRACKET*/
  { 0x005E, 0x005E }, /* 0x5E          CIRCUMFLEX ACCENT*/
  { 0x005F, 0x005F }, /* 0x5F          LOW LINE*/
  { 0x0060, 0x0060 }, /* 0x60          GRAVE ACCENT*/
  { 0x0061, 0x0041 }, /* 0x61          LATIN SMALL LETTER A*/
  { 0x0062, 0x0042 }, /* 0x62          LATIN SMALL LETTER B*/
  { 0x0063, 0x0043 }, /* 0x63          LATIN SMALL LETTER C*/
  { 0x0064, 0x0044 }, /* 0x64          LATIN SMALL LETTER D*/
  { 0x0065, 0x0045 }, /* 0x65          LATIN SMALL LETTER E*/
  { 0x0066, 0x0046 }, /* 0x66          LATIN SMALL LETTER F*/
  { 0x0067, 0x0047 }, /* 0x67          LATIN SMALL LETTER G*/
  { 0x0068, 0x0048 }, /* 0x68          LATIN SMALL LETTER H*/
  { 0x0069, 0x0049 }, /* 0x69          LATIN SMALL LETTER I*/
  { 0x006A, 0x004A }, /* 0x6A          LATIN SMALL LETTER J*/
  { 0x006B, 0x004B }, /* 0x6B          LATIN SMALL LETTER K*/
  { 0x006C, 0x004C }, /* 0x6C          LATIN SMALL LETTER L*/
  { 0x006D, 0x004D }, /* 0x6D          LATIN SMALL LETTER M*/
  { 0x006E, 0x004E }, /* 0x6E          LATIN SMALL LETTER N*/
  { 0x006F, 0x004F }, /* 0x6F          LATIN SMALL LETTER O*/
  { 0x0070, 0x0050 }, /* 0x70          LATIN SMALL LETTER P*/
  { 0x0071, 0x0051 }, /* 0x71          LATIN SMALL LETTER Q*/
  { 0x0072, 0x0052 }, /* 0x72          LATIN SMALL LETTER R*/
  { 0x0073, 0x0053 }, /* 0x73          LATIN SMALL LETTER S*/
  { 0x0074, 0x0054 }, /* 0x74          LATIN SMALL LETTER T*/
  { 0x0075, 0x0055 }, /* 0x75          LATIN SMALL LETTER U*/
  { 0x0076, 0x0056 }, /* 0x76          LATIN SMALL LETTER V*/
  { 0x0077, 0x0057 }, /* 0x77          LATIN SMALL LETTER W*/
  { 0x0078, 0x0058 }, /* 0x78          LATIN SMALL LETTER X*/
  { 0x0079, 0x0059 }, /* 0x79          LATIN SMALL LETTER Y*/
  { 0x007A, 0x005A }, /* 0x7A          LATIN SMALL LETTER Z*/
  { 0x007B, 0x007B }, /* 0x7B          LEFT CURLY BRACKET*/
  { 0x007C, 0x007C }, /* 0x7C          VERTICAL LINE*/
  { 0x007D, 0x007D }, /* 0x7D          RIGHT CURLY BRACKET*/
  { 0x007E, 0x007E }, /* 0x7E          TILDE*/
  { 0x007F, 0x007F }, /* 0x7F          DELETE*/
  { 0x0402, 0x0402 }, /* 0x80          CYRILLIC CAPITAL LETTER DJE */
  { 0x0403, 0x0403 }, /* 0x81          CYRILLIC CAPITAL LETTER GJE */
  { 0x201A, 0x201A }, /* 0x82          SINGLE LOW-9 QUOTATION MARK */
  { 0x0453, 0x0403 }, /* 0x83          CYRILLIC SMALL LETTER GJE */
  { 0x201E, 0x201E }, /* 0x84          DOUBLE LOW-9 QUOTATION MARK */
  { 0x2026, 0x2026 }, /* 0x85          HORIZONTAL ELLIPSIS */
  { 0x2020, 0x2020 }, /* 0x86          DAGGER */
  { 0x2021, 0x2021 }, /* 0x87          DOUBLE DAGGER */
  { 0x0020, 0x0020 }, /* 0x88          UNDEFINED */
  { 0x2030, 0x2030 }, /* 0x89          PER MILLE SIGN */
  { 0x0409, 0x0409 }, /* 0x8A          CYRILLIC CAPITAL LETTER LJE */
  { 0x2039, 0x2039 }, /* 0x8B          SINGLE LEFT-POINTING ANGLE QUOTATION MARK */
  { 0x040A, 0x040A }, /* 0x8C          CYRILLIC CAPITAL LETTER NJE */
  { 0x040C, 0x040C }, /* 0x8D          CYRILLIC CAPITAL LETTER KJE */
  { 0x040B, 0x040B }, /* 0x8E          CYRILLIC CAPITAL LETTER TSHE */
  { 0x040F, 0x040F }, /* 0x8F          CYRILLIC CAPITAL LETTER DZHE */
  { 0x0452, 0x0402 }, /* 0x90          CYRILLIC SMALL LETTER DJE */
  { 0x2018, 0x2018 }, /* 0x91          LEFT SINGLE QUOTATION MARK */
  { 0x2019, 0x2019 }, /* 0x92          RIGHT SINGLE QUOTATION MARK */
  { 0x201C, 0x201C }, /* 0x93          LEFT DOUBLE QUOTATION MARK */
  { 0x201D, 0x201D }, /* 0x94          RIGHT DOUBLE QUOTATION MARK */
  { 0x2022, 0x2022 }, /* 0x95          BULLET */
  { 0x2013, 0x2013 }, /* 0x96          EN DASH */
  { 0x2014, 0x2014 }, /* 0x97          EM DASH */
  { 0x0020, 0x0020 }, /* 0x98          UNDEFINED */
  { 0x2122, 0x2122 }, /* 0x99          TRADE MARK SIGN */
  { 0x0459, 0x0409 }, /* 0x9A          CYRILLIC SMALL LETTER LJE */
  { 0x203A, 0x203A }, /* 0x9B          SINGLE RIGHT-POINTING ANGLE QUOTATION MARK */
  { 0x045A, 0x040A }, /* 0x9C          CYRILLIC SMALL LETTER NJE */
  { 0x045C, 0x040C }, /* 0x9D          CYRILLIC SMALL LETTER KJE */
  { 0x045B, 0x040B }, /* 0x9E          CYRILLIC SMALL LETTER TSHE */
  { 0x045F, 0x040F }, /* 0x9F          CYRILLIC SMALL LETTER DZHE */
  { 0x00A0, 0x00A0 }, /* 0xA0          NO-BREAK SPACE */
  { 0x040E, 0x040E }, /* 0xA1          CYRILLIC CAPITAL LETTER SHORT U */
  { 0x045E, 0x040E }, /* 0xA2          CYRILLIC SMALL LETTER SHORT U */
  { 0x0408, 0x0408 }, /* 0xA3          CYRILLIC CAPITAL LETTER JE */
  { 0x00A4, 0x00A4 }, /* 0xA4          CURRENCY SIGN */
  { 0x0490, 0x0490 }, /* 0xA5          CYRILLIC CAPITAL LETTER GHE WITH UPTURN */
  { 0x00A6, 0x00A6 }, /* 0xA6          BROKEN BAR */
  { 0x00A7, 0x00A7 }, /* 0xA7          SECTION SIGN */
  { 0x0401, 0x0401 }, /* 0xA8          CYRILLIC CAPITAL LETTER IO */
  { 0x00A9, 0x00A9 }, /* 0xA9          COPYRIGHT SIGN */
  { 0x0404, 0x0404 }, /* 0xAA          CYRILLIC CAPITAL LETTER UKRAINIAN IE */
  { 0x00AB, 0x00AB }, /* 0xAB          LEFT-POINTING DOUBLE ANGLE QUOTATION MARK */
  { 0x00AC, 0x00AC }, /* 0xAC          NOT SIGN */
  { 0x00AD, 0x00AD }, /* 0xAD          SOFT HYPHEN */
  { 0x00AE, 0x00AE }, /* 0xAE          REGISTERED SIGN */
  { 0x0407, 0x0407 }, /* 0xAF          CYRILLIC CAPITAL LETTER YI */
  { 0x00B0, 0x00B0 }, /* 0xB0          DEGREE SIGN */
  { 0x00B1, 0x00B1 }, /* 0xB1          PLUS-MINUS SIGN */
  { 0x0406, 0x0406 }, /* 0xB2          CYRILLIC CAPITAL LETTER BYELORUSSIAN-UKRAINIAN I */
  { 0x0456, 0x0406 }, /* 0xB3          CYRILLIC SMALL LETTER BYELORUSSIAN-UKRAINIAN I */
  { 0x0491, 0x0490 }, /* 0xB4          CYRILLIC SMALL LETTER GHE WITH UPTURN */
  { 0x00B5, 0x00B5 }, /* 0xB5          MICRO SIGN */
  { 0x00B6, 0x00B6 }, /* 0xB6          PILCROW SIGN */
  { 0x00B7, 0x00B7 }, /* 0xB7          MIDDLE DOT */
  { 0x0451, 0x0401 }, /* 0xB8          CYRILLIC SMALL LETTER IO */
  { 0x2116, 0x2116 }, /* 0xB9          NUMERO SIGN */
  { 0x0454, 0x0404 }, /* 0xBA          CYRILLIC SMALL LETTER UKRAINIAN IE */
  { 0x00BB, 0x00BB }, /* 0xBB          RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK */
  { 0x0458, 0x0408 }, /* 0xBC          CYRILLIC SMALL LETTER JE */
  { 0x0405, 0x0405 }, /* 0xBD          CYRILLIC CAPITAL LETTER DZE */
  { 0x0455, 0x0405 }, /* 0xBE          CYRILLIC SMALL LETTER DZE */
  { 0x0457, 0x0407 }, /* 0xBF          CYRILLIC SMALL LETTER YI */
  { 0x0410, 0x0410 }, /* 0xC0          CYRILLIC CAPITAL LETTER A */
  { 0x0411, 0x0411 }, /* 0xC1          CYRILLIC CAPITAL LETTER BE */
  { 0x0412, 0x0412 }, /* 0xC2          CYRILLIC CAPITAL LETTER VE */
  { 0x0413, 0x0413 }, /* 0xC3          CYRILLIC CAPITAL LETTER GHE */
  { 0x0414, 0x0414 }, /* 0xC4          CYRILLIC CAPITAL LETTER DE */
  { 0x0415, 0x0415 }, /* 0xC5          CYRILLIC CAPITAL LETTER IE */
  { 0x0416, 0x0416 }, /* 0xC6          CYRILLIC CAPITAL LETTER ZHE */
  { 0x0417, 0x0417 }, /* 0xC7          CYRILLIC CAPITAL LETTER ZE */
  { 0x0418, 0x0418 }, /* 0xC8          CYRILLIC CAPITAL LETTER I */
  { 0x0419, 0x0419 }, /* 0xC9          CYRILLIC CAPITAL LETTER SHORT I */
  { 0x041A, 0x041A }, /* 0xCA          CYRILLIC CAPITAL LETTER KA */
  { 0x041B, 0x041B }, /* 0xCB          CYRILLIC CAPITAL LETTER EL */
  { 0x041C, 0x041C }, /* 0xCC          CYRILLIC CAPITAL LETTER EM */
  { 0x041D, 0x041D }, /* 0xCD          CYRILLIC CAPITAL LETTER EN */
  { 0x041E, 0x041E }, /* 0xCE          CYRILLIC CAPITAL LETTER O */
  { 0x041F, 0x041F }, /* 0xCF          CYRILLIC CAPITAL LETTER PE */
  { 0x0420, 0x0420 }, /* 0xD0          CYRILLIC CAPITAL LETTER ER */
  { 0x0421, 0x0421 }, /* 0xD1          CYRILLIC CAPITAL LETTER ES */
  { 0x0422, 0x0422 }, /* 0xD2          CYRILLIC CAPITAL LETTER TE */
  { 0x0423, 0x0423 }, /* 0xD3          CYRILLIC CAPITAL LETTER U */
  { 0x0424, 0x0424 }, /* 0xD4          CYRILLIC CAPITAL LETTER EF */
  { 0x0425, 0x0425 }, /* 0xD5          CYRILLIC CAPITAL LETTER HA */
  { 0x0426, 0x0426 }, /* 0xD6          CYRILLIC CAPITAL LETTER TSE */
  { 0x0427, 0x0427 }, /* 0xD7          CYRILLIC CAPITAL LETTER CHE */
  { 0x0428, 0x0428 }, /* 0xD8          CYRILLIC CAPITAL LETTER SHA */
  { 0x0429, 0x0429 }, /* 0xD9          CYRILLIC CAPITAL LETTER SHCHA */
  { 0x042A, 0x042A }, /* 0xDA          CYRILLIC CAPITAL LETTER HARD SIGN */
  { 0x042B, 0x042B }, /* 0xDB          CYRILLIC CAPITAL LETTER YERU */
  { 0x042C, 0x042C }, /* 0xDC          CYRILLIC CAPITAL LETTER SOFT SIGN */
  { 0x042D, 0x042D }, /* 0xDD          CYRILLIC CAPITAL LETTER E */
  { 0x042E, 0x042E }, /* 0xDE          CYRILLIC CAPITAL LETTER YU */
  { 0x042F, 0x042F }, /* 0xDF          CYRILLIC CAPITAL LETTER YA */
  { 0x0430, 0x0410 }, /* 0xE0          CYRILLIC SMALL LETTER A */
  { 0x0431, 0x0411 }, /* 0xE1          CYRILLIC SMALL LETTER BE */
  { 0x0432, 0x0412 }, /* 0xE2          CYRILLIC SMALL LETTER VE */
  { 0x0433, 0x0413 }, /* 0xE3          CYRILLIC SMALL LETTER GHE */
  { 0x0434, 0x0414 }, /* 0xE4          CYRILLIC SMALL LETTER DE */
  { 0x0435, 0x0415 }, /* 0xE5          CYRILLIC SMALL LETTER IE */
  { 0x0436, 0x0416 }, /* 0xE6          CYRILLIC SMALL LETTER ZHE */
  { 0x0437, 0x0417 }, /* 0xE7          CYRILLIC SMALL LETTER ZE */
  { 0x0438, 0x0418 }, /* 0xE8          CYRILLIC SMALL LETTER I */
  { 0x0439, 0x0419 }, /* 0xE9          CYRILLIC SMALL LETTER SHORT I */
  { 0x043A, 0x041A }, /* 0xEA          CYRILLIC SMALL LETTER KA */
  { 0x043B, 0x041B }, /* 0xEB          CYRILLIC SMALL LETTER EL */
  { 0x043C, 0x041C }, /* 0xEC          CYRILLIC SMALL LETTER EM */
  { 0x043D, 0x041D }, /* 0xED          CYRILLIC SMALL LETTER EN */
  { 0x043E, 0x041E }, /* 0xEE          CYRILLIC SMALL LETTER O */
  { 0x043F, 0x041F }, /* 0xEF          CYRILLIC SMALL LETTER PE */
  { 0x0440, 0x0420 }, /* 0xF0          CYRILLIC SMALL LETTER ER */
  { 0x0441, 0x0421 }, /* 0xF1          CYRILLIC SMALL LETTER ES */
  { 0x0442, 0x0422 }, /* 0xF2          CYRILLIC SMALL LETTER TE */
  { 0x0443, 0x0423 }, /* 0xF3          CYRILLIC SMALL LETTER U */
  { 0x0444, 0x0424 }, /* 0xF4          CYRILLIC SMALL LETTER EF */
  { 0x0445, 0x0425 }, /* 0xF5          CYRILLIC SMALL LETTER HA */
  { 0x0446, 0x0426 }, /* 0xF6          CYRILLIC SMALL LETTER TSE */
  { 0x0447, 0x0427 }, /* 0xF7          CYRILLIC SMALL LETTER CHE */
  { 0x0448, 0x0428 }, /* 0xF8          CYRILLIC SMALL LETTER SHA */
  { 0x0449, 0x0429 }, /* 0xF9          CYRILLIC SMALL LETTER SHCHA */
  { 0x044A, 0x042A }, /* 0xFA          CYRILLIC SMALL LETTER HARD SIGN */
  { 0x044B, 0x042B }, /* 0xFB          CYRILLIC SMALL LETTER YERU */
  { 0x044C, 0x042C }, /* 0xFC          CYRILLIC SMALL LETTER SOFT SIGN */
  { 0x044D, 0x042D }, /* 0xFD          CYRILLIC SMALL LETTER E */
  { 0x044E, 0x042E }, /* 0xFE          CYRILLIC SMALL LETTER YU */
  { 0x044F, 0x042F }  /* 0xFF          CYRILLIC SMALL LETTER YA */
};

static char_t iso_8859_5[] =
{
  { 0x0000, 0x0000 }, /* 0x00          NULL*/
  { 0x0001, 0x0001 }, /* 0x01          START OF HEADING*/
  { 0x0002, 0x0002 }, /* 0x02          START OF TEXT*/
  { 0x0003, 0x0003 }, /* 0x03          END OF TEXT*/
  { 0x0004, 0x0004 }, /* 0x04          END OF TRANSMISSION*/
  { 0x0005, 0x0005 }, /* 0x05          ENQUIRY*/
  { 0x0006, 0x0006 }, /* 0x06          ACKNOWLEDGE*/
  { 0x0007, 0x0007 }, /* 0x07          BELL*/
  { 0x0008, 0x0008 }, /* 0x08          BACKSPACE*/
  { 0x0009, 0x0009 }, /* 0x09          HORIZONTAL TABULATION*/
  { 0x000A, 0x000A }, /* 0x0A          LINE FEED*/
  { 0x000B, 0x000B }, /* 0x0B          VERTICAL TABULATION*/
  { 0x000C, 0x000C }, /* 0x0C          FORM FEED*/
  { 0x000D, 0x000D }, /* 0x0D          CARRIAGE RETURN*/
  { 0x000E, 0x000E }, /* 0x0E          SHIFT OUT*/
  { 0x000F, 0x000F }, /* 0x0F          SHIFT IN*/
  { 0x0010, 0x0010 }, /* 0x10          DATA LINK ESCAPE*/
  { 0x0011, 0x0011 }, /* 0x11          DEVICE CONTROL ONE*/
  { 0x0012, 0x0012 }, /* 0x12          DEVICE CONTROL TWO*/
  { 0x0013, 0x0013 }, /* 0x13          DEVICE CONTROL THREE*/
  { 0x0014, 0x0014 }, /* 0x14          DEVICE CONTROL FOUR*/
  { 0x0015, 0x0015 }, /* 0x15          NEGATIVE ACKNOWLEDGE*/
  { 0x0016, 0x0016 }, /* 0x16          SYNCHRONOUS IDLE*/
  { 0x0017, 0x0017 }, /* 0x17          END OF TRANSMISSION BLOCK*/
  { 0x0018, 0x0018 }, /* 0x18          CANCEL*/
  { 0x0019, 0x0019 }, /* 0x19          END OF MEDIUM*/
  { 0x001A, 0x001A }, /* 0x1A          SUBSTITUTE*/
  { 0x001B, 0x001B }, /* 0x1B          ESCAPE*/
  { 0x001C, 0x001C }, /* 0x1C          FILE SEPARATOR*/
  { 0x001D, 0x001D }, /* 0x1D          GROUP SEPARATOR*/
  { 0x001E, 0x001E }, /* 0x1E          RECORD SEPARATOR*/
  { 0x001F, 0x001F }, /* 0x1F          UNIT SEPARATOR*/
  { 0x0020, 0x0020 }, /* 0x20          SPACE*/
  { 0x0021, 0x0021 }, /* 0x21          EXCLAMATION MARK*/
  { 0x0022, 0x0022 }, /* 0x22          QUOTATION MARK*/
  { 0x0023, 0x0023 }, /* 0x23          NUMBER SIGN*/
  { 0x0024, 0x0024 }, /* 0x24          DOLLAR SIGN*/
  { 0x0025, 0x0025 }, /* 0x25          PERCENT SIGN*/
  { 0x0026, 0x0026 }, /* 0x26          AMPERSAND*/
  { 0x0027, 0x0027 }, /* 0x27          APOSTROPHE*/
  { 0x0028, 0x0028 }, /* 0x28          LEFT PARENTHESIS*/
  { 0x0029, 0x0029 }, /* 0x29          RIGHT PARENTHESIS*/
  { 0x002A, 0x002A }, /* 0x2A          ASTERISK*/
  { 0x002B, 0x002B }, /* 0x2B          PLUS SIGN*/
  { 0x002C, 0x002C }, /* 0x2C          COMMA*/
  { 0x002D, 0x002D }, /* 0x2D          HYPHEN-MINUS*/
  { 0x002E, 0x002E }, /* 0x2E          FULL STOP*/
  { 0x002F, 0x002F }, /* 0x2F          SOLIDUS*/
  { 0x0030, 0x0030 }, /* 0x30          DIGIT ZERO*/
  { 0x0031, 0x0031 }, /* 0x31          DIGIT ONE*/
  { 0x0032, 0x0032 }, /* 0x32          DIGIT TWO*/
  { 0x0033, 0x0033 }, /* 0x33          DIGIT THREE*/
  { 0x0034, 0x0034 }, /* 0x34          DIGIT FOUR*/
  { 0x0035, 0x0035 }, /* 0x35          DIGIT FIVE*/
  { 0x0036, 0x0036 }, /* 0x36          DIGIT SIX*/
  { 0x0037, 0x0037 }, /* 0x37          DIGIT SEVEN*/
  { 0x0038, 0x0038 }, /* 0x38          DIGIT EIGHT*/
  { 0x0039, 0x0039 }, /* 0x39          DIGIT NINE*/
  { 0x003A, 0x003A }, /* 0x3A          COLON*/
  { 0x003B, 0x003B }, /* 0x3B          SEMICOLON*/
  { 0x003C, 0x003C }, /* 0x3C          LESS-THAN SIGN*/
  { 0x003D, 0x003D }, /* 0x3D          EQUALS SIGN*/
  { 0x003E, 0x003E }, /* 0x3E          GREATER-THAN SIGN*/
  { 0x003F, 0x003F }, /* 0x3F          QUESTION MARK*/
  { 0x0040, 0x0040 }, /* 0x40          COMMERCIAL AT*/
  { 0x0041, 0x0041 }, /* 0x41          LATIN CAPITAL LETTER A*/
  { 0x0042, 0x0042 }, /* 0x42          LATIN CAPITAL LETTER B*/
  { 0x0043, 0x0043 }, /* 0x43          LATIN CAPITAL LETTER C*/
  { 0x0044, 0x0044 }, /* 0x44          LATIN CAPITAL LETTER D*/
  { 0x0045, 0x0045 }, /* 0x45          LATIN CAPITAL LETTER E*/
  { 0x0046, 0x0046 }, /* 0x46          LATIN CAPITAL LETTER F*/
  { 0x0047, 0x0047 }, /* 0x47          LATIN CAPITAL LETTER G*/
  { 0x0048, 0x0048 }, /* 0x48          LATIN CAPITAL LETTER H*/
  { 0x0049, 0x0049 }, /* 0x49          LATIN CAPITAL LETTER I*/
  { 0x004A, 0x004A }, /* 0x4A          LATIN CAPITAL LETTER J*/
  { 0x004B, 0x004B }, /* 0x4B          LATIN CAPITAL LETTER K*/
  { 0x004C, 0x004C }, /* 0x4C          LATIN CAPITAL LETTER L*/
  { 0x004D, 0x004D }, /* 0x4D          LATIN CAPITAL LETTER M*/
  { 0x004E, 0x004E }, /* 0x4E          LATIN CAPITAL LETTER N*/
  { 0x004F, 0x004F }, /* 0x4F          LATIN CAPITAL LETTER O*/
  { 0x0050, 0x0050 }, /* 0x50          LATIN CAPITAL LETTER P*/
  { 0x0051, 0x0051 }, /* 0x51          LATIN CAPITAL LETTER Q*/
  { 0x0052, 0x0052 }, /* 0x52          LATIN CAPITAL LETTER R*/
  { 0x0053, 0x0053 }, /* 0x53          LATIN CAPITAL LETTER S*/
  { 0x0054, 0x0054 }, /* 0x54          LATIN CAPITAL LETTER T*/
  { 0x0055, 0x0055 }, /* 0x55          LATIN CAPITAL LETTER U*/
  { 0x0056, 0x0056 }, /* 0x56          LATIN CAPITAL LETTER V*/
  { 0x0057, 0x0057 }, /* 0x57          LATIN CAPITAL LETTER W*/
  { 0x0058, 0x0058 }, /* 0x58          LATIN CAPITAL LETTER X*/
  { 0x0059, 0x0059 }, /* 0x59          LATIN CAPITAL LETTER Y*/
  { 0x005A, 0x005A }, /* 0x5A          LATIN CAPITAL LETTER Z*/
  { 0x005B, 0x005B }, /* 0x5B          LEFT SQUARE BRACKET*/
  { 0x005C, 0x005C }, /* 0x5C          REVERSE SOLIDUS*/
  { 0x005D, 0x005D }, /* 0x5D          RIGHT SQUARE BRACKET*/
  { 0x005E, 0x005E }, /* 0x5E          CIRCUMFLEX ACCENT*/
  { 0x005F, 0x005F }, /* 0x5F          LOW LINE*/
  { 0x0060, 0x0060 }, /* 0x60          GRAVE ACCENT*/
  { 0x0061, 0x0041 }, /* 0x61          LATIN SMALL LETTER A*/
  { 0x0062, 0x0042 }, /* 0x62          LATIN SMALL LETTER B*/
  { 0x0063, 0x0043 }, /* 0x63          LATIN SMALL LETTER C*/
  { 0x0064, 0x0044 }, /* 0x64          LATIN SMALL LETTER D*/
  { 0x0065, 0x0045 }, /* 0x65          LATIN SMALL LETTER E*/
  { 0x0066, 0x0046 }, /* 0x66          LATIN SMALL LETTER F*/
  { 0x0067, 0x0047 }, /* 0x67          LATIN SMALL LETTER G*/
  { 0x0068, 0x0048 }, /* 0x68          LATIN SMALL LETTER H*/
  { 0x0069, 0x0049 }, /* 0x69          LATIN SMALL LETTER I*/
  { 0x006A, 0x004A }, /* 0x6A          LATIN SMALL LETTER J*/
  { 0x006B, 0x004B }, /* 0x6B          LATIN SMALL LETTER K*/
  { 0x006C, 0x004C }, /* 0x6C          LATIN SMALL LETTER L*/
  { 0x006D, 0x004D }, /* 0x6D          LATIN SMALL LETTER M*/
  { 0x006E, 0x004E }, /* 0x6E          LATIN SMALL LETTER N*/
  { 0x006F, 0x004F }, /* 0x6F          LATIN SMALL LETTER O*/
  { 0x0070, 0x0050 }, /* 0x70          LATIN SMALL LETTER P*/
  { 0x0071, 0x0051 }, /* 0x71          LATIN SMALL LETTER Q*/
  { 0x0072, 0x0052 }, /* 0x72          LATIN SMALL LETTER R*/
  { 0x0073, 0x0053 }, /* 0x73          LATIN SMALL LETTER S*/
  { 0x0074, 0x0054 }, /* 0x74          LATIN SMALL LETTER T*/
  { 0x0075, 0x0055 }, /* 0x75          LATIN SMALL LETTER U*/
  { 0x0076, 0x0056 }, /* 0x76          LATIN SMALL LETTER V*/
  { 0x0077, 0x0057 }, /* 0x77          LATIN SMALL LETTER W*/
  { 0x0078, 0x0058 }, /* 0x78          LATIN SMALL LETTER X*/
  { 0x0079, 0x0059 }, /* 0x79          LATIN SMALL LETTER Y*/
  { 0x007A, 0x005A }, /* 0x7A          LATIN SMALL LETTER Z*/
  { 0x007B, 0x007B }, /* 0x7B          LEFT CURLY BRACKET*/
  { 0x007C, 0x007C }, /* 0x7C          VERTICAL LINE*/
  { 0x007D, 0x007D }, /* 0x7D          RIGHT CURLY BRACKET*/
  { 0x007E, 0x007E }, /* 0x7E          TILDE*/
  { 0x007F, 0x007F }, /* 0x7F          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x80          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x81          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x82          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x83          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x84          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x85          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x86          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x87          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x88          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x89          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x8A          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x8B          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x8C          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x8D          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x8E          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x8F          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x90          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x91          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x92          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x93          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x94          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x95          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x96          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x97          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x98          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x99          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x9A          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x9B          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x9C          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x9D          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x9E          UNDEFINED */
  { 0x0020, 0x0020 }, /* 0x9F          UNDEFINED */
  { 0x00A0, 0x00A0 }, /* 0xA0          NO-BREAK SPACE  */
  { 0x0401, 0x0401 }, /* 0xA1          CYRILLIC CAPITAL LETTER IO */
  { 0x0402, 0x0402 }, /* 0xA2          CYRILLIC CAPITAL LETTER DJE */
  { 0x0403, 0x0403 }, /* 0xA3          CYRILLIC CAPITAL LETTER GJE */
  { 0x0404, 0x0404 }, /* 0xA4          CYRILLIC CAPITAL LETTER UKRAINIAN IE */
  { 0x0405, 0x0405 }, /* 0xA5          CYRILLIC CAPITAL LETTER DZE */
  { 0x0406, 0x0406 }, /* 0xA6          CYRILLIC CAPITAL LETTER BYELORUSSIAN-UKRAINIAN I */
  { 0x0407, 0x0407 }, /* 0xA7          CYRILLIC CAPITAL LETTER YI */
  { 0x0408, 0x0408 }, /* 0xA8          CYRILLIC CAPITAL LETTER JE */
  { 0x0409, 0x0409 }, /* 0xA9          CYRILLIC CAPITAL LETTER LJE */
  { 0x040A, 0x040A }, /* 0xAA          CYRILLIC CAPITAL LETTER NJE */
  { 0x040B, 0x040B }, /* 0xAB          CYRILLIC CAPITAL LETTER TSHE */
  { 0x040C, 0x040C }, /* 0xAC          CYRILLIC CAPITAL LETTER KJE */
  { 0x00AD, 0x00AD }, /* 0xAD          SOFT HYPHEN */
  { 0x040E, 0x040E }, /* 0xAE          CYRILLIC CAPITAL LETTER SHORT U */
  { 0x040F, 0x040F }, /* 0xAF          CYRILLIC CAPITAL LETTER DZHE */
  { 0x0410, 0x0410 }, /* 0xB0          CYRILLIC CAPITAL LETTER A */
  { 0x0411, 0x0411 }, /* 0xB1          CYRILLIC CAPITAL LETTER BE */
  { 0x0412, 0x0412 }, /* 0xB2          CYRILLIC CAPITAL LETTER VE */
  { 0x0413, 0x0413 }, /* 0xB3          CYRILLIC CAPITAL LETTER GHE */
  { 0x0414, 0x0414 }, /* 0xB4          CYRILLIC CAPITAL LETTER DE */
  { 0x0415, 0x0415 }, /* 0xB5          CYRILLIC CAPITAL LETTER IE */
  { 0x0416, 0x0416 }, /* 0xB6          CYRILLIC CAPITAL LETTER ZHE */
  { 0x0417, 0x0417 }, /* 0xB7          CYRILLIC CAPITAL LETTER ZE */
  { 0x0418, 0x0418 }, /* 0xB8          CYRILLIC CAPITAL LETTER I */
  { 0x0419, 0x0419 }, /* 0xB9          CYRILLIC CAPITAL LETTER SHORT I */
  { 0x041A, 0x041A }, /* 0xBA          CYRILLIC CAPITAL LETTER KA */
  { 0x041B, 0x041B }, /* 0xBB          CYRILLIC CAPITAL LETTER EL */
  { 0x041C, 0x041C }, /* 0xBC          CYRILLIC CAPITAL LETTER EM */
  { 0x041D, 0x041D }, /* 0xBD          CYRILLIC CAPITAL LETTER EN */
  { 0x041E, 0x041E }, /* 0xBE          CYRILLIC CAPITAL LETTER O */
  { 0x041F, 0x041F }, /* 0xBF          CYRILLIC CAPITAL LETTER PE */
  { 0x0420, 0x0420 }, /* 0xC0          CYRILLIC CAPITAL LETTER ER */
  { 0x0421, 0x0421 }, /* 0xC1          CYRILLIC CAPITAL LETTER ES */
  { 0x0422, 0x0422 }, /* 0xC2          CYRILLIC CAPITAL LETTER TE */
  { 0x0423, 0x0423 }, /* 0xC3          CYRILLIC CAPITAL LETTER U */
  { 0x0424, 0x0424 }, /* 0xC4          CYRILLIC CAPITAL LETTER EF */
  { 0x0425, 0x0425 }, /* 0xC5          CYRILLIC CAPITAL LETTER HA */
  { 0x0426, 0x0426 }, /* 0xC6          CYRILLIC CAPITAL LETTER TSE */
  { 0x0427, 0x0427 }, /* 0xC7          CYRILLIC CAPITAL LETTER CHE */
  { 0x0428, 0x0428 }, /* 0xC8          CYRILLIC CAPITAL LETTER SHA */
  { 0x0429, 0x0429 }, /* 0xC9          CYRILLIC CAPITAL LETTER SHCHA */
  { 0x042A, 0x042A }, /* 0xCA          CYRILLIC CAPITAL LETTER HARD SIGN */
  { 0x042B, 0x042B }, /* 0xCB          CYRILLIC CAPITAL LETTER YERU */
  { 0x042C, 0x042C }, /* 0xCC          CYRILLIC CAPITAL LETTER SOFT SIGN */
  { 0x042D, 0x042D }, /* 0xCD          CYRILLIC CAPITAL LETTER E */
  { 0x042E, 0x042E }, /* 0xCE          CYRILLIC CAPITAL LETTER YU */
  { 0x042F, 0x042F }, /* 0xCF          CYRILLIC CAPITAL LETTER YA */
  { 0x0430, 0x0410 }, /* 0xD0          CYRILLIC SMALL LETTER A */
  { 0x0431, 0x0411 }, /* 0xD1          CYRILLIC SMALL LETTER BE */
  { 0x0432, 0x0412 }, /* 0xD2          CYRILLIC SMALL LETTER VE */
  { 0x0433, 0x0413 }, /* 0xD3          CYRILLIC SMALL LETTER GHE */
  { 0x0434, 0x0414 }, /* 0xD4          CYRILLIC SMALL LETTER DE */
  { 0x0435, 0x0415 }, /* 0xD5          CYRILLIC SMALL LETTER IE */
  { 0x0436, 0x0416 }, /* 0xD6          CYRILLIC SMALL LETTER ZHE */
  { 0x0437, 0x0417 }, /* 0xD7          CYRILLIC SMALL LETTER ZE */
  { 0x0438, 0x0418 }, /* 0xD8          CYRILLIC SMALL LETTER I */
  { 0x0439, 0x0419 }, /* 0xD9          CYRILLIC SMALL LETTER SHORT I */
  { 0x043A, 0x041A }, /* 0xDA          CYRILLIC SMALL LETTER KA */
  { 0x043B, 0x041B }, /* 0xDB          CYRILLIC SMALL LETTER EL */
  { 0x043C, 0x041C }, /* 0xDC          CYRILLIC SMALL LETTER EM */
  { 0x043D, 0x041D }, /* 0xDD          CYRILLIC SMALL LETTER EN */
  { 0x043E, 0x041E }, /* 0xDE          CYRILLIC SMALL LETTER O */
  { 0x043F, 0x041F }, /* 0xDF          CYRILLIC SMALL LETTER PE */
  { 0x0440, 0x0420 }, /* 0xE0          CYRILLIC SMALL LETTER ER */
  { 0x0441, 0x0421 }, /* 0xE1          CYRILLIC SMALL LETTER ES */
  { 0x0442, 0x0422 }, /* 0xE2          CYRILLIC SMALL LETTER TE */
  { 0x0443, 0x0423 }, /* 0xE3          CYRILLIC SMALL LETTER U */
  { 0x0444, 0x0424 }, /* 0xE4          CYRILLIC SMALL LETTER EF */
  { 0x0445, 0x0425 }, /* 0xE5          CYRILLIC SMALL LETTER HA */
  { 0x0446, 0x0426 }, /* 0xE6          CYRILLIC SMALL LETTER TSE */
  { 0x0447, 0x0427 }, /* 0xE7          CYRILLIC SMALL LETTER CHE */
  { 0x0448, 0x0428 }, /* 0xE8          CYRILLIC SMALL LETTER SHA */
  { 0x0449, 0x0429 }, /* 0xE9          CYRILLIC SMALL LETTER SHCHA */
  { 0x044A, 0x042A }, /* 0xEA          CYRILLIC SMALL LETTER HARD SIGN */
  { 0x044B, 0x042B }, /* 0xEB          CYRILLIC SMALL LETTER YERU */
  { 0x044C, 0x042C }, /* 0xEC          CYRILLIC SMALL LETTER SOFT SIGN */
  { 0x044D, 0x042D }, /* 0xED          CYRILLIC SMALL LETTER E */
  { 0x044E, 0x042E }, /* 0xEE          CYRILLIC SMALL LETTER YU */
  { 0x044F, 0x042F }, /* 0xEF          CYRILLIC SMALL LETTER YA */
  { 0x2116, 0x2116 }, /* 0xF0          NUMERO SIGN */
  { 0x0451, 0x0401 }, /* 0xF1          CYRILLIC SMALL LETTER IO */
  { 0x0452, 0x0402 }, /* 0xF2          CYRILLIC SMALL LETTER DJE */
  { 0x0453, 0x0403 }, /* 0xF3          CYRILLIC SMALL LETTER GJE */
  { 0x0454, 0x0404 }, /* 0xF4          CYRILLIC SMALL LETTER UKRAINIAN IE */
  { 0x0455, 0x0405 }, /* 0xF5          CYRILLIC SMALL LETTER DZE */
  { 0x0456, 0x0406 }, /* 0xF6          CYRILLIC SMALL LETTER BYELORUSSIAN-UKRAINIAN I */
  { 0x0457, 0x0407 }, /* 0xF7          CYRILLIC SMALL LETTER YI */
  { 0x0458, 0x0408 }, /* 0xF8          CYRILLIC SMALL LETTER JE */
  { 0x0459, 0x0409 }, /* 0xF9          CYRILLIC SMALL LETTER LJE */
  { 0x045A, 0x040A }, /* 0xFA          CYRILLIC SMALL LETTER NJE */
  { 0x045B, 0x040B }, /* 0xFB          CYRILLIC SMALL LETTER TSHE */
  { 0x045C, 0x040C }, /* 0xFC          CYRILLIC SMALL LETTER KJE */
  { 0x00A7, 0x00A7 }, /* 0xFD          SECTION SIGN */
  { 0x045E, 0x040E }, /* 0xFE          CYRILLIC SMALL LETTER SHORT U */
  { 0x045F, 0x040F }  /* 0xFF          CYRILLIC SMALL LETTER DZHE */
};

static rtab_t trivial =
{
 {
    0,   1,   2,   3,   4,   5,   6,   7,
    8,   9,  10,  11,  12,  13,  14,  15,
   16,  17,  18,  19,  20,  21,  22,  23,
   24,  25,  26,  27,  28,  29,  30,  31,
   32,  33,  34,  35,  36,  37,  38,  39,
   40,  41,  42,  43,  44,  45,  46,  47,
   48,  49,  50,  51,  52,  53,  54,  55,
   56,  57,  58,  59,  60,  61,  62,  63,
   64,  65,  66,  67,  68,  69,  70,  71,
   72,  73,  74,  75,  76,  77,  78,  79,
   80,  81,  82,  83,  84,  85,  86,  87,
   88,  89,  90,  91,  92,  93,  94,  95,
   96,  97,  98,  99, 100, 101, 102, 103,
  104, 105, 106, 107, 108, 109, 110, 111,
  112, 113, 114, 115, 116, 117, 118, 119,
  120, 121, 122, 123, 124, 125, 126, 127,
  128, 129, 130, 131, 132, 133, 134, 135,
  136, 137, 138, 139, 140, 141, 142, 143,
  144, 145, 146, 147, 148, 149, 150, 151,
  152, 153, 154, 155, 156, 157, 158, 159,
  160, 161, 162, 163, 164, 165, 166, 167,
  168, 169, 170, 171, 172, 173, 174, 175,
  176, 177, 178, 179, 180, 181, 182, 183,
  184, 185, 186, 187, 188, 189, 190, 191,
  192, 193, 194, 195, 196, 197, 198, 199,
  200, 201, 202, 203, 204, 205, 206, 207,
  208, 209, 210, 211, 212, 213, 214, 215,
  216, 217, 218, 219, 220, 221, 222, 223,
  224, 225, 226, 227, 228, 229, 230, 231,
  232, 233, 234, 235, 236, 237, 238, 239,
  240, 241, 242, 243, 244, 245, 246, 247,
  248, 249, 250, 251, 252, 253, 254, 255
 }
};

int
___acs_init( void )
{
 if( ( cs_mutex = mutex_create() ) == AL_NOMUTEX )
  return -1;
 cur_set = 0;
 memset( rtabs, 0, sizeof( rtabs ) );
 memset( sets, 0, sizeof( sets ) );
 astr_add_charset( cp866 );
 astr_add_charset( koi8_r );
 astr_add_charset( cp1251 );
 astr_add_charset( iso_8859_5 );
 return 0;
}

static void
destroy_tab( int i1, int i2 )
{
 if( rtabs[ i1 ][ i2 ] != NULL )
  free( rtabs[ i1 ][ i2 ] );
 rtabs[ i1 ][ i2 ] = NULL;
}

static void
destroy_all_tables( int id )
{ register int i;
 for( i = 0; i < CS_MAX; i++ )
  if( id != i )
   {
    destroy_tab( i, id );
    destroy_tab( id, i );
   }
}

void
___acs_term( void )
{ register int i;
 for( i = 0; i < CS_MAX; i++ )
  {
   destroy_all_tables( i );
   if( sets[ i ] != NULL )
    free( sets[ i ] );
  }
 mutex_destroy( cs_mutex );
}



static rtab_t *
make_table( charset_t * s1, charset_t * s2 )
{ register short i, j, u;
 rtab_t * t = malloc( sizeof( rtab_t ) );
 if( t == NULL )
  return NULL;
 /* search for space in the destination charset */
 for( i = 0, u = 0x20; i < 256; i++ )
  if( s2->s[ i ].code == UNI_SPACE )
   {
    u = i;
    break;
   }
 /* characters absent in the destination charset are translated into spaces */
 for( i = 0; i < 256; i++ )
  t->table[ i ] = u;
 /* make the table */
 for( i = 0; i < 256; i++ )
  for( j = 0; j < 256; j++ )
   if( s1->s[ i ].code == s2->s[ j ].code )
    {
     t->table[ i ] = j;
     break;
    }
 return t;
}

int
astr_add_charset( char_t * set )
{ register short i, j, id;
 charset_t * cs;
 int res = -1;
 mutex_lock( cs_mutex );
 for( id = 0; id < CS_MAX; id++ )
  if( sets[ id ] == NULL )
   break;
 if( id >= CS_MAX )
  goto OUT;
 /* make charset description */
 if( ( cs = malloc( sizeof( charset_t ) ) ) == NULL )
  goto OUT;
 for( i = 0; i < 256; i++ )
  {
   cs->s[ i ].upper = cs->s[ i ].lower = i;
   cs->s[ i ].code = set[ i ].charcode;
  }
 for( i = 0; i < 256; i++ )
  for( j = 0; j < 256; j++ )
   if( set[ i ].uppercode == set[ j ].charcode )
    {
     cs->s[ i ].upper = j;
     cs->s[ j ].lower = i;
     break;
    }
 /* make translation tables */
 rtabs[ id ][ id ] = & trivial;
 for( i = 0; i < CS_MAX; i++ )
  if( i != id && sets[ i ] != NULL
      && ( ( rtabs[ i ][ id ] = make_table( sets[ i ], cs ) ) == NULL
           || ( rtabs[ id ][ i ] = make_table( cs, sets[ i ] ) ) == NULL ) )
   {
    destroy_all_tables( id );
    free( cs );
    goto OUT;
   }
 sets[ id ] = cs;
 res = 0;
OUT :
 mutex_unlock( cs_mutex );
 return res;
}

int
astr_get_charset( void )
{
 return cur_set;
}

void
astr_set_charset( int set )
{
 cur_set = set;
}

char *
astr_nrecode( int tset, int fset, char * to, const char * from, int n )
{ register int i;
 mutex_lock( cs_mutex );
 for( i = 0; i < n; i++ )
  to[ i ] = rtabs[ fset ][ tset ]->table[ from[ i ] & 0xFF ];
 mutex_unlock( cs_mutex );
 return to;
}

char *
astr_nencode( int set, char * to, const char * from, int n )
{
 return astr_nrecode( set, cur_set, to, from, n );
}

char *
astr_ndecode( int set, char * to, char * from, int n )
{
 return astr_nrecode( cur_set, set, to, from, n );
}

char *
astr_recode( int tset, int fset, char * to, const char * from )
{
 return astr_nrecode( tset, fset, to, from, strlen( from ) );
}

char *
astr_encode( int set, char * to, const char * from )
{
 return astr_recode( set, cur_set, to, from );
}

char *
astr_decode( int set, char * to, const char * from )
{
 return astr_recode( cur_set, set, to, from );
}

int
is_upper( char c )
{ int res;
 mutex_lock( cs_mutex );
 res = sets[ cur_set ]->s[ ( unsigned char )c ].lower != ( unsigned char )c;
 mutex_unlock( cs_mutex );
 return res;
}

int
is_lower( char c )
{ int res;
 mutex_lock( cs_mutex );
 res = sets[ cur_set ]->s[ ( unsigned char )c ].upper != ( unsigned char )c;
 mutex_unlock( cs_mutex );
 return res;
}

char
to_upper( char c )
{ char res;
 mutex_lock( cs_mutex );
 res = sets[ cur_set ]->s[ ( unsigned char )c ].upper;
 mutex_unlock( cs_mutex );
 return res;
}

char
to_lower( char c )
{ char res;
 mutex_lock( cs_mutex );
 res = sets[ cur_set ]->s[ ( unsigned char )c ].lower;
 mutex_unlock( cs_mutex );
 return res;
}

char *
astr_upper( char * to, const char * from )
{ register int i;
 mutex_lock( cs_mutex );
 for( i = 0; from[ i ] != '\0'; i++ )
  to[ i ] = sets[ cur_set ]->s[ ( unsigned char )from[ i ] ].upper;
 mutex_unlock( cs_mutex );
 return to;
}

char *
astr_lower( char * to, const char * from )
{ register int i;
 mutex_lock( cs_mutex );
 for( i = 0; from[ i ] != '\0'; i++ )
  to[ i ] = sets[ cur_set ]->s[ ( unsigned char )from[ i ] ].lower;
 mutex_unlock( cs_mutex );
 return to;
}

int
astr_icmp( const char * s1, const char * s2 )
{ register int i;
 for( i = 0; s1[ i ] != '\0' && to_upper( s1[ i ] ) == to_upper( s2[ i ] );
      i++ )
  ;
 return to_upper( s1[ i ] ) - to_upper( s2[ i ] );
}

char *
astr_istr( const char * text, const char * pattern )
{ char * txt, * pat;
 register char * p;
 if( ( txt = malloc( strlen( text ) + 1 ) ) == NULL )
  return NULL;
 if( ( pat = malloc( strlen( pattern ) + 1 ) ) == NULL )
  {
   free( txt );
   return NULL;
  }
 astr_upper( txt, text );
 astr_upper( pat, pattern );
 if( ( p = strstr( txt, pat ) ) != NULL )
  p = ( char * )text + ( p - txt );
 free( txt );
 free( pat );
 return p;
}
