#include <stdlib.h>

void oops() { (void) malloc(4711); }
