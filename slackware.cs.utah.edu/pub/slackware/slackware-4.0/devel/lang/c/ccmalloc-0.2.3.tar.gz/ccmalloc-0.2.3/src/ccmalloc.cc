/*----------------------------------------------------------------------------
 * (C) 1997 - 1998 Armin Biere 
 *
 *     $Id: ccmalloc.cc,v 1.2 98/05/20 14:41:31 armin Exp $
 *----------------------------------------------------------------------------
 */

extern "C" {
#include "assert.c"
#include "hash.c"
#include "callchain.c"
#include "wrapper.c"
};

#include "CtorDtor.cc"
