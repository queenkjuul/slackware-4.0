/*----------------------------------------------------------------------------
 * (C) 1997-1998 Armin Biere 
 *
 *     $Id: assert.c,v 1.2 98/05/20 14:41:29 armin Exp $
 *----------------------------------------------------------------------------
 */

#include "config.h"

/* ------------------------------------------------------------------------ */

#include <unistd.h>
#include <signal.h>
#include <stdio.h>

/* ------------------------------------------------------------------------ */

void _failed_assertion(char * file, int lineno)
{
  fprintf(stderr, "*** %s:%d: assertion failed!\n", file, lineno);
  fflush(stderr); 
  kill(getpid(),SIGSEGV);
}
