int
getFloatOpt(int argc, char **argv, int i, float *value, int force)
{
  char *end;

  if( ++i>=argc ) goto nothingFound;

  *value = (float)strtod(argv[i], &end);

  /***** check for conversion error */
  if( end==argv[i] ) goto nothingFound;

  /***** check for surplus non-whitespace */
  while( isspace(*end) ) end+=1;
  if( *end ) goto nothingFound;

  return i;

nothingFound:
  if( !force ) return i-1;

  fprintf(stderr,
	  "%s: missing or malformed float value after option `%s'\n",
	  Program, argv[i-1]);
  exit(EXIT_FAILURE);
 
}
/**********************************************************************/
