int
getStringOpt(int argc, char **argv, int i, char **value, int force)
{
  if( ++i>=argc ) {
    fprintf(stderr, "%s: missing string after option `%s'\n",
            Program, argv[i-1]);
    exit(EXIT_FAILURE);
  }
  
  if( !force && argv[i+1][0] == '-' ) return i-1;
  *value = argv[i];
  return i;
}
/**********************************************************************/
