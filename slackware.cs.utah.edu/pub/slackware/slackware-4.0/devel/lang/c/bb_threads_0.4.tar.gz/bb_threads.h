#include <linux/types.h>


#ifndef _BB_THREADS_
#define _BB_THREADS_

void bb_threads_id_fcn(FILE *outputfile);
void bb_threads_stacksize(size_t n);
pid_t bb_threads_newthread(void (*fcn)(void *, size_t), void *arg);
void bb_threads_shared_sighandlers(int shared);
int bb_threads_cleanup(pid_t tnum);
int bb_threads_mutexcreate(int n);
__inline__ int bb_threads_lock(int n);
__inline__ int bb_threads_sleepy_lock(int n, int usecs);
__inline__ int bb_threads_unlock(int n);

#endif  /* !_BB_THREADS_ */
