#line 1 "ordcltn.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_ordcltn(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor ordcltn_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 31 "ordcltn.h"
typedef struct objcol
{
int count;
int capacity;
id*ptr;
}*
objcol_t;
#line 28 "set.h"
typedef struct objset
{
int count;
int capacity;
id*ptr;
}*
objset_t;
#line 32 "ocstring.h"
typedef struct objstr
{
int count;
int capacity;
char*ptr;
}*
objstr_t;
#line 38 "../../include/objcrt/Block.h"
extern id newBlock(int n,IMP fn,void*data,IMP dtor);
#line 38 "ordcltn.m"
typedef struct{
#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 41 "ordcltn.h"
struct objcol value;
#line 38 "ordcltn.m"
}TFOrdCltn;
#line 39 "ordcltn.h"
struct OrdCltn_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 41 "ordcltn.h"
struct objcol value;};

#line 39 "ordcltn.h"
extern id  OrdCltn;

#line 39 "ordcltn.h"
extern struct _SHARED _OrdCltn;
extern struct _SHARED __OrdCltn;


#line 48 "ordcltn.m"
static void ptrinit(id*p,id q,int c)
{
while(c--) *p++=q;
}

static void init(objcol_t self,int n,int c)
{
assert(0<=n&&n<=c);
self->count=n;
self->capacity=c;
self->ptr=(id*)OC_Calloc(c*sizeof(id));
}

static id c_OrdCltn_new(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT0;

#line 63 "ordcltn.m"
int n=(16);
id newObject=(objcT0=__OrdCltn.clsSuper,(*_impSuper(objcT0,selTransTbl[0]))((id)self,selTransTbl[0]));
#line 70 "ordcltn.m"
init( &(((TFOrdCltn*)newObject)->value),0,n);

return newObject;
}

static id c_OrdCltn_new_(struct OrdCltn_PRIVATE *self,SEL _cmd,unsigned n)
{
id objcT1,objcT2;

#line 77 "ordcltn.m"
id newObject=(objcT1=__OrdCltn.clsSuper,(*_impSuper(objcT1,selTransTbl[0]))((id)self,selTransTbl[0]));
init((objcT2=newObject,(*(objcol_t(*)(id,SEL))_imp(objcT2,selTransTbl[1]))(objcT2,selTransTbl[1])),0,n);
return newObject;
}

#line 88 "ordcltn.m"
static id c_OrdCltn_with_(struct OrdCltn_PRIVATE *self,SEL _cmd,int nArgs,...)
{
id objcT3;

#line 90 "ordcltn.m"
id newObject;


va_list vp;

newObject=(objcT3=(id)self,(*_imp(objcT3,selTransTbl[0]))(objcT3,selTransTbl[0]));
#line 110 "ordcltn.m"
va_start(vp,nArgs);
while(nArgs-->0){
id objcT4;

#line 112 "ordcltn.m"
id anObject=va_arg(vp,id);
(objcT4=newObject,(*_imp(objcT4,selTransTbl[2]))(objcT4,selTransTbl[2],anObject));
}
va_end(vp);


return newObject;
}

static id c_OrdCltn_with_with_(struct OrdCltn_PRIVATE *self,SEL _cmd,id firstObject,id nextObject)
{
id objcT5,objcT6,objcT7;

#line 123 "ordcltn.m"
return(objcT5=(objcT6=(objcT7=(id)self,(*_imp(objcT7,selTransTbl[0]))(objcT7,selTransTbl[0])),(*_imp(objcT6,selTransTbl[2]))(objcT6,selTransTbl[2],firstObject)),(*_imp(objcT5,selTransTbl[2]))(objcT5,selTransTbl[2],nextObject));
}

static id c_OrdCltn_add_(struct OrdCltn_PRIVATE *self,SEL _cmd,id firstObject)
{
id objcT8,objcT9;

#line 128 "ordcltn.m"
return(objcT8=(objcT9=(id)self,(*_imp(objcT9,selTransTbl[0]))(objcT9,selTransTbl[0])),(*_imp(objcT8,selTransTbl[2]))(objcT8,selTransTbl[2],firstObject));
}

static void ptrcopy(id*p,id*q,int c)
{
while(c--){ *
p++= *q++;
}
}

static void copy(objcol_t dst,objcol_t src)
{
init(dst,src->count,src->count);
ptrcopy(dst->ptr,src->ptr,src->count);
}

static id i_OrdCltn_copy(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT10,objcT11;

#line 146 "ordcltn.m"
id aCopy=(objcT10=_OrdCltn.clsSuper,(*_impSuper(objcT10,selTransTbl[3]))((id)self,selTransTbl[3]));
copy((objcT11=aCopy,(*(objcol_t(*)(id,SEL))_imp(objcT11,selTransTbl[1]))(objcT11,selTransTbl[1])),( &self->value));
return aCopy;
}

static void ptrdeepcopy(id*p,id*q,int c)
{
while(c--){
id objcT12;

#line 153 "ordcltn.m"
id obj= *q++; *p++=(obj)?(objcT12=obj,(*_imp(objcT12,selTransTbl[4]))(objcT12,selTransTbl[4])):(id)0;}
}

static void deepcopy(objcol_t dst,objcol_t src)
{
init(dst,src->count,src->count);
ptrdeepcopy(dst->ptr,src->ptr,src->count);
}

static id i_OrdCltn_deepCopy(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT13,objcT14;


id aCopy=(objcT13=_OrdCltn.clsSuper,(*_impSuper(objcT13,selTransTbl[3]))((id)self,selTransTbl[3]));
deepcopy((objcT14=aCopy,(*(objcol_t(*)(id,SEL))_imp(objcT14,selTransTbl[1]))(objcT14,selTransTbl[1])),( &self->value));
return aCopy;
}

static void empty(objcol_t self)
{
ptrinit(self->ptr,(id)0,self->count);
self->count=0;
}

static id i_OrdCltn_emptyYourself(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
empty(( &self->value));return(id)self;
}

static void ptrclear(id*p,int c)
{
while(c--){
id objcT15;

#line 185 "ordcltn.m"
id obj= *p; *p++=(obj)?(objcT15=obj,(*_imp(objcT15,selTransTbl[5]))(objcT15,selTransTbl[5])):(id)0;}
}

static void freecontents(objcol_t self)
{
ptrclear(self->ptr,self->count);self->count=0;
}

static id i_OrdCltn_freeContents(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
freecontents(( &self->value));return(id)self;
}

static void ptrclearall(id*p,int c)
{
while(c--){
id objcT16;

#line 200 "ordcltn.m"
id obj= *p; *p++=(obj)?(objcT16=obj,(*_imp(objcT16,selTransTbl[6]))(objcT16,selTransTbl[6])):(id)0;}
}

static void freeall(objcol_t self)
{
ptrclearall(self->ptr,self->count);self->count=0;
}

static id i_OrdCltn_freeAll(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
freeall(( &self->value));return(id)self;
}

static void clear(objcol_t self)
{
self->count=0;self->capacity=0;OC_Free(self->ptr);self->ptr=NULL;
}

static id i_OrdCltn_free(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT17;

#line 220 "ordcltn.m"
clear(( &self->value));return(objcT17=_OrdCltn.clsSuper,(*_impSuper(objcT17,selTransTbl[5]))((id)self,selTransTbl[5]));
}

static id i_OrdCltn_release(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT18;

#line 225 "ordcltn.m"
empty(( &self->value));clear(( &self->value));return(objcT18=_OrdCltn.clsSuper,(*_impSuper(objcT18,selTransTbl[7]))((id)self,selTransTbl[7]));
}

#line 234 "ordcltn.m"
static objcol_t i_OrdCltn_objcolvalue(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
return &self->value;
}

static unsigned i_OrdCltn_size(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
return(unsigned)(( &self->value)->count);
}

static BOOL i_OrdCltn_isEmpty(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
return( &self->value)->count==0;
}

static unsigned i_OrdCltn_lastOffset(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
return( &self->value)->count-1;
}

#line 32 "cltnseq.h"
extern id  CollectionSequence;

#line 35 "sequence.h"
extern id  Sequence;

#line 254 "ordcltn.m"
static id i_OrdCltn_eachElement(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT19,objcT20;

#line 256 "ordcltn.m"
id aCarrier=(objcT19=CollectionSequence,(*_imp(objcT19,selTransTbl[8]))(objcT19,selTransTbl[8],(id)self));
return(objcT20=Sequence,(*_imp(objcT20,selTransTbl[8]))(objcT20,selTransTbl[8],aCarrier));
}

static id ptrfirst(id*p,int n)
{
return(n)?p[0]:(id)0;
}

static id first(objcol_t self)
{
return ptrfirst(self->ptr,self->count);
}

static id i_OrdCltn_firstElement(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
return first(( &self->value));
}

static id ptrlast(id*p,int n)
{
return(n)?p[n-1]:(id)0;
}

static id last(objcol_t self)
{
return ptrlast(self->ptr,self->count);
}

static id i_OrdCltn_lastElement(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
return last(( &self->value));
}

#line 296 "ordcltn.m"
static unsigned ptrhash(id*p,int n)
{
unsigned code=n;
while(n--){
id objcT21;

#line 300 "ordcltn.m"
code^=(objcT21= *p++,(*(unsigned(*)(id,SEL))_imp(objcT21,selTransTbl[9]))(objcT21,selTransTbl[9]));
}
return code;
}

static unsigned hashcontents(objcol_t a)
{
return ptrhash(a->ptr,a->count);
}

static unsigned i_OrdCltn_hash(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
return hashcontents( &self->value);
}

static BOOL ptreq(id*p,id*q,int n)
{
while(n--){
id objcT22;

#line 318 "ordcltn.m"
if( !(objcT22= *p++,(*(BOOL(*)(id,SEL,id))_imp(objcT22,selTransTbl[10]))(objcT22,selTransTbl[10], *q++))){
return(BOOL)0;
}
}
return(BOOL)1;
}

static BOOL eq(objcol_t a,objcol_t b)
{
if(a->count==b->count){
return ptreq(a->ptr,b->ptr,a->count);
}else{
return(BOOL)0;
}
}

static BOOL i_OrdCltn_isEqual_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
id objcT23;

#line 336 "ordcltn.m"
return((id)self==aCltn)?(BOOL)1:eq(( &self->value),(objcT23=aCltn,(*(objcol_t(*)(id,SEL))_imp(objcT23,selTransTbl[1]))(objcT23,selTransTbl[1])));
}

#line 345 "ordcltn.m"
static BOOL needsexpand(objcol_t self)
{
assert(self->count<=self->capacity);return self->count==self->capacity;
}

static void expand(objcol_t self)
{
self->capacity=1+2*self->capacity;
self->ptr=(id*)OC_Realloc(self->ptr,sizeof(id)*self->capacity);
memset(self->ptr+self->count,0,sizeof(id)*(self->capacity-self->count));
}

static int ptraddlast(id*p,id obj,int n)
{
p[n]=obj;return n+1;
}

static void addlast(objcol_t self,id obj)
{
if(needsexpand(self)){
expand(self);
}
self->count=ptraddlast(self->ptr,obj,self->count);
}

static id i_OrdCltn_add_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
if(anObject){
addlast(( &self->value),anObject);
return(id)self;
}else{
return(id)self;
}
}

static id i_OrdCltn_addYourself(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT24,objcT25,objcT26;

#line 382 "ordcltn.m"
int i,n=(objcT24=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT24,selTransTbl[11]))(objcT24,selTransTbl[11]));
for(i=0;i<n;i++)(objcT25=(id)self,(*_imp(objcT25,selTransTbl[2]))(objcT25,selTransTbl[2],(objcT26=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT26,selTransTbl[12]))(objcT26,selTransTbl[12],i))));
return(id)self;
}

static int ptraddfirst(id*p,id obj,int n)
{
int m=n;
p+=n;while(m--){id*q=p-1; *p= *q;p=q;} *
p=obj;return n+1;
}

static void addfirst(objcol_t self,id obj)
{
if(needsexpand(self)){
expand(self);
}
self->count=ptraddfirst(self->ptr,obj,self->count);
}

static id i_OrdCltn_addFirst_(struct OrdCltn_PRIVATE *self,SEL _cmd,id newObject)
{
if(newObject){
addfirst(( &self->value),newObject);
return(id)self;
}else{
return(id)self;
}
}

static id i_OrdCltn_addLast_(struct OrdCltn_PRIVATE *self,SEL _cmd,id newObject)
{
id objcT27;

#line 414 "ordcltn.m"
return(objcT27=(id)self,(*_imp(objcT27,selTransTbl[2]))(objcT27,selTransTbl[2],newObject));
}

static id i_OrdCltn_addIfAbsent_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT28;

#line 419 "ordcltn.m"
if((objcT28=(id)self,(*_imp(objcT28,selTransTbl[13]))(objcT28,selTransTbl[13],anObject))==(id)0){
id objcT29;

#line 420 "ordcltn.m"
(objcT29=(id)self,(*_imp(objcT29,selTransTbl[2]))(objcT29,selTransTbl[2],anObject));
}
return(id)self;
}

static id i_OrdCltn_addIfAbsentMatching_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT30;

#line 427 "ordcltn.m"
if((objcT30=(id)self,(*_imp(objcT30,selTransTbl[14]))(objcT30,selTransTbl[14],anObject))==(id)0){
id objcT31;

#line 428 "ordcltn.m"
(objcT31=(id)self,(*_imp(objcT31,selTransTbl[2]))(objcT31,selTransTbl[2],anObject));
}
return(id)self;
}

#line 439 "ordcltn.m"
static int ptrinsert(id*p,id obj,int i,int n)
{
if(i==n){
return ptraddlast(p,obj,n);
}else{
return i+ptraddfirst(p+i,obj,n-i);
}
}

static void insert(objcol_t self,id obj,int i)
{
if(needsexpand(self)){
expand(self);
}

self->count=ptrinsert(self->ptr,obj,i,self->count);
}

static id i_OrdCltn_boundserror(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT32;

#line 459 "ordcltn.m"
return(objcT32=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT32,selTransTbl[15]))(objcT32,selTransTbl[15],"Offset out of bounds."));
}

static id i_OrdCltn_at_insert_(struct OrdCltn_PRIVATE *self,SEL _cmd,unsigned anOffset,id anObject)
{
if(anObject){
id objcT33;

#line 465 "ordcltn.m"
if(anOffset>(objcT33=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT33,selTransTbl[11]))(objcT33,selTransTbl[11]))){
id objcT34;

#line 466 "ordcltn.m"
(objcT34=(id)self,(*_imp(objcT34,selTransTbl[16]))(objcT34,selTransTbl[16]));
}else{
insert(( &self->value),anObject,(int)anOffset);
}
return(id)self;
}else{
return(id)self;
}
}

static id i_OrdCltn_couldntfind(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT35;

#line 478 "ordcltn.m"
return(objcT35=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT35,selTransTbl[15]))(objcT35,selTransTbl[15],"Could not find object."));
}

static id i_OrdCltn_insert_after_(struct OrdCltn_PRIVATE *self,SEL _cmd,id newObject,id oldObject)
{
if(newObject){
id objcT36;

#line 484 "ordcltn.m"
unsigned offset=(objcT36=(id)self,(*(unsigned(*)(id,SEL,id))_imp(objcT36,selTransTbl[17]))(objcT36,selTransTbl[17],oldObject));
if(offset==(unsigned) -1){
id objcT37;

#line 486 "ordcltn.m"
return(objcT37=(id)self,(*_imp(objcT37,selTransTbl[18]))(objcT37,selTransTbl[18]));
}else{
id objcT38;

#line 488 "ordcltn.m"
return(objcT38=(id)self,(*(id(*)(id,SEL,unsigned,id))_imp(objcT38,selTransTbl[19]))(objcT38,selTransTbl[19],offset+1,newObject));
}
}else{
return(id)self;
}
}

static id i_OrdCltn_insert_before_(struct OrdCltn_PRIVATE *self,SEL _cmd,id newObject,id oldObject)
{
if(newObject){
id objcT39;

#line 498 "ordcltn.m"
unsigned offset=(objcT39=(id)self,(*(unsigned(*)(id,SEL,id))_imp(objcT39,selTransTbl[17]))(objcT39,selTransTbl[17],oldObject));
if(offset==(unsigned) -1){
id objcT40;

#line 500 "ordcltn.m"
return(objcT40=(id)self,(*_imp(objcT40,selTransTbl[18]))(objcT40,selTransTbl[18]));
}else{
id objcT41;

#line 502 "ordcltn.m"
return(objcT41=(id)self,(*(id(*)(id,SEL,unsigned,id))_imp(objcT41,selTransTbl[19]))(objcT41,selTransTbl[19],offset-1,newObject));
}
}else{
return(id)self;
}
}

#line 515 "ordcltn.m"
static id i_OrdCltn_after_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT42;

#line 517 "ordcltn.m"
unsigned offset=(objcT42=(id)self,(*(unsigned(*)(id,SEL,id))_imp(objcT42,selTransTbl[17]))(objcT42,selTransTbl[17],anObject));
if(offset==(unsigned) -1){
id objcT43;

#line 519 "ordcltn.m"
return(objcT43=(id)self,(*_imp(objcT43,selTransTbl[18]))(objcT43,selTransTbl[18]));
}else{
id objcT44,objcT45;

#line 521 "ordcltn.m"
return(offset==(objcT44=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT44,selTransTbl[20]))(objcT44,selTransTbl[20])))?(id)0:(objcT45=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT45,selTransTbl[12]))(objcT45,selTransTbl[12],offset+1));
}
}

static id i_OrdCltn_before_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT46;

#line 527 "ordcltn.m"
unsigned offset=(objcT46=(id)self,(*(unsigned(*)(id,SEL,id))_imp(objcT46,selTransTbl[17]))(objcT46,selTransTbl[17],anObject));
if(offset==(unsigned) -1){
id objcT47;

#line 529 "ordcltn.m"
return(objcT47=(id)self,(*_imp(objcT47,selTransTbl[18]))(objcT47,selTransTbl[18]));
}else{
id objcT48;

#line 531 "ordcltn.m"
return(offset==0)?(id)0:(objcT48=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT48,selTransTbl[12]))(objcT48,selTransTbl[12],offset-1));
}
}

static id at(objcol_t self,int i)
{
assert(0<=i&&i<self->count);return(self->ptr)[i];
}

static id i_OrdCltn_at_(struct OrdCltn_PRIVATE *self,SEL _cmd,unsigned anOffset)
{
id objcT49;

#line 542 "ordcltn.m"
if(anOffset>=(objcT49=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT49,selTransTbl[11]))(objcT49,selTransTbl[11]))){
id objcT50;

#line 543 "ordcltn.m"
return(objcT50=(id)self,(*_imp(objcT50,selTransTbl[16]))(objcT50,selTransTbl[16]));
}else{
return at(( &self->value),anOffset);
}
}

static id atput(objcol_t self,int i,id obj)
{
id tmp;assert(0<=i&&i<self->count);
tmp=(self->ptr)[i];(self->ptr)[i]=obj;return tmp;
}

static id i_OrdCltn_at_put_(struct OrdCltn_PRIVATE *self,SEL _cmd,unsigned anOffset,id anObject)
{
id objcT51;

#line 557 "ordcltn.m"
if(anOffset>=(objcT51=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT51,selTransTbl[11]))(objcT51,selTransTbl[11]))){
id objcT52;

#line 558 "ordcltn.m"
return(objcT52=(id)self,(*_imp(objcT52,selTransTbl[16]))(objcT52,selTransTbl[16]));
}else{
return atput(( &self->value),anOffset,anObject);
}
}

#line 570 "ordcltn.m"
static id ptrremovefirst(id*p,int n)
{
id obj= *p;
n--;while(n--){id*q=p+1; *p= *q;p=q;} *
p=(id)0;
return obj;
}

static id removefirst(objcol_t self)
{
if(self->count){
id obj=ptrremovefirst(self->ptr,self->count);
self->count--;return obj;
}else{
return(id)0;
}
}

static id i_OrdCltn_removeFirst(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
return removefirst(( &self->value));
}

static id ptrremove(id*p)
{
id obj= *p; *p=(id)0;return obj;
}

static id removelast(objcol_t self)
{
if(self->count){
id obj=ptrremove(self->ptr+self->count-1);
self->count--;return obj;
}else{
return(id)0;
}
}

static id i_OrdCltn_removeLast(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
return removelast(( &self->value));
}

static id ptrremoveat(id*p,int i,int n)
{
if(i==n-1){
return ptrremove(p+n-1);
}else{
return ptrremovefirst(p+i,n-i);
}
}

static id removeat(objcol_t self,int i)
{
if(self->count){
id obj=ptrremoveat(self->ptr,i,self->count);
self->count--;return obj;
}else{
return(id)0;
}
}

static id i_OrdCltn_removeAt_(struct OrdCltn_PRIVATE *self,SEL _cmd,unsigned anOffset)
{
id objcT53;

#line 634 "ordcltn.m"
if(anOffset>=(objcT53=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT53,selTransTbl[11]))(objcT53,selTransTbl[11]))){
id objcT54;

#line 635 "ordcltn.m"
return(objcT54=(id)self,(*_imp(objcT54,selTransTbl[16]))(objcT54,selTransTbl[16]));
}else{
return removeat(( &self->value),anOffset);
}
}

static id i_OrdCltn_removeAtIndex_(struct OrdCltn_PRIVATE *self,SEL _cmd,unsigned anOffset)
{
id objcT55;

#line 643 "ordcltn.m"
return(objcT55=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT55,selTransTbl[21]))(objcT55,selTransTbl[21],anOffset));
}

static id i_OrdCltn_remove_(struct OrdCltn_PRIVATE *self,SEL _cmd,id oldObject)
{
id objcT56;

#line 648 "ordcltn.m"
unsigned offset=(objcT56=(id)self,(*(unsigned(*)(id,SEL,id))_imp(objcT56,selTransTbl[17]))(objcT56,selTransTbl[17],oldObject));
if(offset==(unsigned) -1){
return(id)0;
}else{
id objcT57;

#line 652 "ordcltn.m"
return(objcT57=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT57,selTransTbl[21]))(objcT57,selTransTbl[21],offset));
}
}


static id i_OrdCltn_remove_ifAbsent_(struct OrdCltn_PRIVATE *self,SEL _cmd,id oldObject,id exceptionBlock)
{
id objcT58,objcT59;

#line 659 "ordcltn.m"
id anObject=(objcT58=(id)self,(*_imp(objcT58,selTransTbl[22]))(objcT58,selTransTbl[22],oldObject));
return(anObject)?anObject:(objcT59=exceptionBlock,(*_imp(objcT59,selTransTbl[23]))(objcT59,selTransTbl[23]));
}

#line 670 "ordcltn.m"
static BOOL i_OrdCltn_includesAllOf_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
if((id)self==aCltn){
return(BOOL)1;
}else{
id objcT60,objcT61,objcT63;

#line 675 "ordcltn.m"
BOOL res=(BOOL)1;
id e,seq=(objcT60=aCltn,(*_imp(objcT60,selTransTbl[24]))(objcT60,selTransTbl[24]));
while((e=(objcT61=seq,(*_imp(objcT61,selTransTbl[25]))(objcT61,selTransTbl[25])))){
id objcT62;

#line 678 "ordcltn.m"
if( !(objcT62=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT62,selTransTbl[26]))(objcT62,selTransTbl[26],e))){
res=(BOOL)0;goto done;
}
}
done:

(objcT63=seq,(*_imp(objcT63,selTransTbl[5]))(objcT63,selTransTbl[5]));

return res;
}
}

static BOOL i_OrdCltn_includesAnyOf_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
if((id)self==aCltn){
return(BOOL)1;
}else{
id objcT64,objcT65,objcT67;

#line 695 "ordcltn.m"
BOOL res=(BOOL)0;
id e,seq=(objcT64=aCltn,(*_imp(objcT64,selTransTbl[24]))(objcT64,selTransTbl[24]));
while((e=(objcT65=seq,(*_imp(objcT65,selTransTbl[25]))(objcT65,selTransTbl[25])))){
id objcT66;

#line 698 "ordcltn.m"
if((objcT66=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT66,selTransTbl[26]))(objcT66,selTransTbl[26],e))){
res=(BOOL)1;goto done;
}
}
done:

(objcT67=seq,(*_imp(objcT67,selTransTbl[5]))(objcT67,selTransTbl[5]));

return res;
}
}

#line 716 "ordcltn.m"
static id i_OrdCltn_addAll_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
if((id)self==aCltn){
id objcT68;

#line 719 "ordcltn.m"
(objcT68=(id)self,(*_imp(objcT68,selTransTbl[27]))(objcT68,selTransTbl[27]));
}else{
id objcT69,objcT70,objcT72;

#line 721 "ordcltn.m"
id e,seq;

seq=(objcT69=aCltn,(*_imp(objcT69,selTransTbl[24]))(objcT69,selTransTbl[24]));
while((e=(objcT70=seq,(*_imp(objcT70,selTransTbl[25]))(objcT70,selTransTbl[25])))){
id objcT71;

#line 725 "ordcltn.m"
(objcT71=(id)self,(*_imp(objcT71,selTransTbl[2]))(objcT71,selTransTbl[2],e));
}

seq=(objcT72=seq,(*_imp(objcT72,selTransTbl[5]))(objcT72,selTransTbl[5]));

}

return(id)self;
}

static id i_OrdCltn_addContentsOf_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
id objcT73;

#line 737 "ordcltn.m"
return(objcT73=(id)self,(*_imp(objcT73,selTransTbl[28]))(objcT73,selTransTbl[28],aCltn));
}

static id i_OrdCltn_addContentsTo_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
id objcT74;

#line 742 "ordcltn.m"
return(objcT74=aCltn,(*_imp(objcT74,selTransTbl[28]))(objcT74,selTransTbl[28],(id)self));
}

static id i_OrdCltn_removeAll_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
if((id)self==aCltn){
id objcT75;

#line 748 "ordcltn.m"
(objcT75=(id)self,(*_imp(objcT75,selTransTbl[29]))(objcT75,selTransTbl[29]));
}else{
id objcT76,objcT77,objcT79;

#line 750 "ordcltn.m"
id e,seq;

seq=(objcT76=aCltn,(*_imp(objcT76,selTransTbl[24]))(objcT76,selTransTbl[24]));
while((e=(objcT77=seq,(*_imp(objcT77,selTransTbl[25]))(objcT77,selTransTbl[25])))){
id objcT78;

#line 754 "ordcltn.m"
(objcT78=(id)self,(*_imp(objcT78,selTransTbl[22]))(objcT78,selTransTbl[22],e));
}

seq=(objcT79=seq,(*_imp(objcT79,selTransTbl[5]))(objcT79,selTransTbl[5]));

}

return(id)self;
}

static id i_OrdCltn_removeContentsFrom_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
id objcT80;

#line 766 "ordcltn.m"
return(objcT80=aCltn,(*_imp(objcT80,selTransTbl[30]))(objcT80,selTransTbl[30],(id)self));
}

static id i_OrdCltn_removeContentsOf_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
id objcT81;

#line 771 "ordcltn.m"
return(objcT81=(id)self,(*_imp(objcT81,selTransTbl[30]))(objcT81,selTransTbl[30],aCltn));
}

#line 780 "ordcltn.m"
static id i_OrdCltn_intersection_(struct OrdCltn_PRIVATE *self,SEL _cmd,id bag)
{
if((id)self==bag){
id objcT82;

#line 783 "ordcltn.m"
return(objcT82=(id)self,(*_imp(objcT82,selTransTbl[3]))(objcT82,selTransTbl[3]));
}else{
id objcT83,objcT84,objcT85,objcT88;

#line 785 "ordcltn.m"
id anElement,elements;
id intersection=(objcT83=self->isa,(*_imp(objcT83,selTransTbl[0]))(objcT83,selTransTbl[0]));

elements=(objcT84=(id)self,(*_imp(objcT84,selTransTbl[24]))(objcT84,selTransTbl[24]));
while((anElement=(objcT85=elements,(*_imp(objcT85,selTransTbl[25]))(objcT85,selTransTbl[25])))){
id objcT86,objcT87;

#line 790 "ordcltn.m"
if((objcT86=bag,(*_imp(objcT86,selTransTbl[13]))(objcT86,selTransTbl[13],anElement)))(objcT87=intersection,(*_imp(objcT87,selTransTbl[2]))(objcT87,selTransTbl[2],anElement));
}

elements=(objcT88=elements,(*_imp(objcT88,selTransTbl[5]))(objcT88,selTransTbl[5]));


return intersection;
}
}

static id i_OrdCltn_union_(struct OrdCltn_PRIVATE *self,SEL _cmd,id bag)
{
if((id)self==bag){
id objcT89;

#line 803 "ordcltn.m"
return(objcT89=(id)self,(*_imp(objcT89,selTransTbl[3]))(objcT89,selTransTbl[3]));
}else{
id objcT90,objcT91;

#line 805 "ordcltn.m"
return(objcT90=(objcT91=(id)self,(*_imp(objcT91,selTransTbl[3]))(objcT91,selTransTbl[3])),(*_imp(objcT90,selTransTbl[28]))(objcT90,selTransTbl[28],bag));
}
}

static id i_OrdCltn_difference_(struct OrdCltn_PRIVATE *self,SEL _cmd,id bag)
{
if((id)self==bag){
id objcT92;

#line 812 "ordcltn.m"
return(objcT92=self->isa,(*_imp(objcT92,selTransTbl[0]))(objcT92,selTransTbl[0]));
}else{
id objcT93,objcT94;

#line 814 "ordcltn.m"
return(objcT93=(objcT94=(id)self,(*_imp(objcT94,selTransTbl[3]))(objcT94,selTransTbl[3])),(*_imp(objcT93,selTransTbl[30]))(objcT93,selTransTbl[30],bag));
}
}

#line 36 "set.h"
extern id  Set;

#line 824 "ordcltn.m"
static id i_OrdCltn_asSet(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT95,objcT96;
if((objcT95=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT95,selTransTbl[31]))(objcT95,selTransTbl[31],(id)(objcT96=Set,(*_imp(objcT96,selTransTbl[32]))(objcT96,selTransTbl[32]))))){
return(id)self;
}else{
id objcT97,objcT98;

#line 830 "ordcltn.m"
return(objcT97=(objcT98=Set,(*_imp(objcT98,selTransTbl[0]))(objcT98,selTransTbl[0])),(*_imp(objcT97,selTransTbl[28]))(objcT97,selTransTbl[28],(id)self));
}
}

static id i_OrdCltn_asOrdCltn(struct OrdCltn_PRIVATE *self,SEL _cmd)
{
id objcT99,objcT100;
if((objcT99=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT99,selTransTbl[31]))(objcT99,selTransTbl[31],(id)(objcT100=OrdCltn,(*_imp(objcT100,selTransTbl[32]))(objcT100,selTransTbl[32]))))){
return(id)self;
}else{
id objcT101,objcT102;

#line 840 "ordcltn.m"
return(objcT101=(objcT102=OrdCltn,(*_imp(objcT102,selTransTbl[0]))(objcT102,selTransTbl[0])),(*_imp(objcT101,selTransTbl[28]))(objcT101,selTransTbl[28],(id)self));
}
}

#line 851 "ordcltn.m"
static id i_OrdCltn_detect_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aBlock)
{
id objcT103,objcT104,objcT107;

#line 853 "ordcltn.m"
id e,seq;

seq=(objcT103=(id)self,(*_imp(objcT103,selTransTbl[24]))(objcT103,selTransTbl[24]));

while((e=(objcT104=seq,(*_imp(objcT104,selTransTbl[25]))(objcT104,selTransTbl[25])))){
id objcT105;

#line 858 "ordcltn.m"
if(((objcT105=aBlock,(*_imp(objcT105,selTransTbl[33]))(objcT105,selTransTbl[33],e)))){
id objcT106;
seq=(objcT106=seq,(*_imp(objcT106,selTransTbl[5]))(objcT106,selTransTbl[5]));

return e;
}
}


seq=(objcT107=seq,(*_imp(objcT107,selTransTbl[5]))(objcT107,selTransTbl[5]));

return(id)0;
}

static id i_OrdCltn_detect_ifNone_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aBlock,id noneBlock)
{
id objcT108,objcT109,objcT112,objcT113;

#line 874 "ordcltn.m"
id e,seq;

seq=(objcT108=(id)self,(*_imp(objcT108,selTransTbl[24]))(objcT108,selTransTbl[24]));

while((e=(objcT109=seq,(*_imp(objcT109,selTransTbl[25]))(objcT109,selTransTbl[25])))){
id objcT110;

#line 879 "ordcltn.m"
if(((objcT110=aBlock,(*_imp(objcT110,selTransTbl[33]))(objcT110,selTransTbl[33],e)))){
id objcT111;
seq=(objcT111=seq,(*_imp(objcT111,selTransTbl[5]))(objcT111,selTransTbl[5]));

return e;
}
}


seq=(objcT112=seq,(*_imp(objcT112,selTransTbl[5]))(objcT112,selTransTbl[5]));

return(objcT113=noneBlock,(*_imp(objcT113,selTransTbl[23]))(objcT113,selTransTbl[23]));
}

static id i_OrdCltn_select_(struct OrdCltn_PRIVATE *self,SEL _cmd,id testBlock)
{
id objcT114,objcT115,objcT116,objcT119;

#line 895 "ordcltn.m"
id e,seq;
id newObject=(objcT114=self->isa,(*_imp(objcT114,selTransTbl[0]))(objcT114,selTransTbl[0]));

seq=(objcT115=(id)self,(*_imp(objcT115,selTransTbl[24]))(objcT115,selTransTbl[24]));

while((e=(objcT116=seq,(*_imp(objcT116,selTransTbl[25]))(objcT116,selTransTbl[25])))){
id objcT117;

#line 901 "ordcltn.m"
if(((objcT117=testBlock,(*_imp(objcT117,selTransTbl[33]))(objcT117,selTransTbl[33],e)))){
id objcT118;

#line 902 "ordcltn.m"
(objcT118=newObject,(*_imp(objcT118,selTransTbl[2]))(objcT118,selTransTbl[2],e));
}
}


seq=(objcT119=seq,(*_imp(objcT119,selTransTbl[5]))(objcT119,selTransTbl[5]));

return newObject;
}

static id i_OrdCltn_reject_(struct OrdCltn_PRIVATE *self,SEL _cmd,id testBlock)
{
id objcT120,objcT121,objcT122,objcT125;

#line 914 "ordcltn.m"
id e,seq;
id newObject=(objcT120=self->isa,(*_imp(objcT120,selTransTbl[0]))(objcT120,selTransTbl[0]));

seq=(objcT121=(id)self,(*_imp(objcT121,selTransTbl[24]))(objcT121,selTransTbl[24]));

while((e=(objcT122=seq,(*_imp(objcT122,selTransTbl[25]))(objcT122,selTransTbl[25])))){
id objcT123;

#line 920 "ordcltn.m"
if( !((objcT123=testBlock,(*_imp(objcT123,selTransTbl[33]))(objcT123,selTransTbl[33],e)))){
id objcT124;

#line 921 "ordcltn.m"
(objcT124=newObject,(*_imp(objcT124,selTransTbl[2]))(objcT124,selTransTbl[2],e));
}
}


seq=(objcT125=seq,(*_imp(objcT125,selTransTbl[5]))(objcT125,selTransTbl[5]));

return newObject;
}

static id i_OrdCltn_collect_(struct OrdCltn_PRIVATE *self,SEL _cmd,id transformBlock)
{
id objcT126,objcT127,objcT128,objcT131;

#line 933 "ordcltn.m"
id e,seq;
id newObject=(objcT126=self->isa,(*_imp(objcT126,selTransTbl[0]))(objcT126,selTransTbl[0]));

seq=(objcT127=(id)self,(*_imp(objcT127,selTransTbl[24]))(objcT127,selTransTbl[24]));

while((e=(objcT128=seq,(*_imp(objcT128,selTransTbl[25]))(objcT128,selTransTbl[25])))){
id objcT129;

#line 939 "ordcltn.m"
id anImage=(objcT129=transformBlock,(*_imp(objcT129,selTransTbl[33]))(objcT129,selTransTbl[33],e));
if(anImage){
id objcT130;

#line 941 "ordcltn.m"
(objcT130=newObject,(*_imp(objcT130,selTransTbl[2]))(objcT130,selTransTbl[2],anImage));
}
}


seq=(objcT131=seq,(*_imp(objcT131,selTransTbl[5]))(objcT131,selTransTbl[5]));

return newObject;
}

static unsigned i_OrdCltn_count_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aBlock)
{
id objcT132,objcT133,objcT135;

#line 953 "ordcltn.m"
id e,seq;
unsigned c=0;

seq=(objcT132=(id)self,(*_imp(objcT132,selTransTbl[24]))(objcT132,selTransTbl[24]));
while((e=(objcT133=seq,(*_imp(objcT133,selTransTbl[25]))(objcT133,selTransTbl[25])))){
id objcT134;

#line 958 "ordcltn.m"
if((objcT134=aBlock,(*_imp(objcT134,selTransTbl[33]))(objcT134,selTransTbl[33],e))){
c++;
}
}

seq=(objcT135=seq,(*_imp(objcT135,selTransTbl[5]))(objcT135,selTransTbl[5]));


return c;
}

#line 977 "ordcltn.m"
static id i_OrdCltn_elementsPerform_(struct OrdCltn_PRIVATE *self,SEL _cmd,SEL aSelector)
{
id objcT136,objcT137,objcT139;

#line 979 "ordcltn.m"
id e,seq;

seq=(objcT136=(id)self,(*_imp(objcT136,selTransTbl[24]))(objcT136,selTransTbl[24]));
while((e=(objcT137=seq,(*_imp(objcT137,selTransTbl[25]))(objcT137,selTransTbl[25])))){
id objcT138;

#line 983 "ordcltn.m"
(objcT138=e,(*(id(*)(id,SEL,SEL))_imp(objcT138,selTransTbl[34]))(objcT138,selTransTbl[34],aSelector));
}

seq=(objcT139=seq,(*_imp(objcT139,selTransTbl[5]))(objcT139,selTransTbl[5]));


return(id)self;
}

static id i_OrdCltn_elementsPerform_with_(struct OrdCltn_PRIVATE *self,SEL _cmd,SEL aSelector,id anObject)
{
id objcT140,objcT141,objcT143;

#line 994 "ordcltn.m"
id e,seq;

seq=(objcT140=(id)self,(*_imp(objcT140,selTransTbl[24]))(objcT140,selTransTbl[24]));
while((e=(objcT141=seq,(*_imp(objcT141,selTransTbl[25]))(objcT141,selTransTbl[25])))){
id objcT142;

#line 998 "ordcltn.m"
(objcT142=e,(*(id(*)(id,SEL,SEL,id))_imp(objcT142,selTransTbl[35]))(objcT142,selTransTbl[35],aSelector,anObject));
}

seq=(objcT143=seq,(*_imp(objcT143,selTransTbl[5]))(objcT143,selTransTbl[5]));


return(id)self;
}

static id i_OrdCltn_elementsPerform_with_with_(struct OrdCltn_PRIVATE *self,SEL _cmd,SEL aSelector,id anObject,id otherObject)
{
id objcT144,objcT145,objcT147;

#line 1009 "ordcltn.m"
id e,seq;

seq=(objcT144=(id)self,(*_imp(objcT144,selTransTbl[24]))(objcT144,selTransTbl[24]));
while((e=(objcT145=seq,(*_imp(objcT145,selTransTbl[25]))(objcT145,selTransTbl[25])))){
id objcT146;

#line 1013 "ordcltn.m"
(objcT146=e,(*(id(*)(id,SEL,SEL,id,id))_imp(objcT146,selTransTbl[36]))(objcT146,selTransTbl[36],aSelector,anObject,otherObject));
}

seq=(objcT147=seq,(*_imp(objcT147,selTransTbl[5]))(objcT147,selTransTbl[5]));


return(id)self;
}

static id i_OrdCltn_elementsPerform_with_with_with_(struct OrdCltn_PRIVATE *self,SEL _cmd,SEL aSelector,id anObject,id otherObject,id thirdObj)
{
id objcT148,objcT149,objcT151;

#line 1024 "ordcltn.m"
id e,seq;

seq=(objcT148=(id)self,(*_imp(objcT148,selTransTbl[24]))(objcT148,selTransTbl[24]));
while((e=(objcT149=seq,(*_imp(objcT149,selTransTbl[25]))(objcT149,selTransTbl[25])))){
id objcT150;

#line 1028 "ordcltn.m"
(objcT150=e,(*(id(*)(id,SEL,SEL,id,id,id))_imp(objcT150,selTransTbl[37]))(objcT150,selTransTbl[37],aSelector,anObject,otherObject,thirdObj));
}

seq=(objcT151=seq,(*_imp(objcT151,selTransTbl[5]))(objcT151,selTransTbl[5]));


return(id)self;
}

#line 1043 "ordcltn.m"
static id i_OrdCltn_do_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aBlock)
{
id objcT152;

#line 1045 "ordcltn.m"
int i=0;
int n=(objcT152=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT152,selTransTbl[11]))(objcT152,selTransTbl[11]));
for(i=0;i<n;i++){
id objcT153,objcT154;

#line 1047 "ordcltn.m"
(objcT153=aBlock,(*_imp(objcT153,selTransTbl[33]))(objcT153,selTransTbl[33],(objcT154=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT154,selTransTbl[12]))(objcT154,selTransTbl[12],i))));}
return(id)self;
}

static id i_OrdCltn_do_until_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aBlock,BOOL*flag)
{
id objcT155;

#line 1053 "ordcltn.m"
int i=0;
int n=(objcT155=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT155,selTransTbl[11]))(objcT155,selTransTbl[11]));
for(i=0;i<n;i++){
id objcT156,objcT157;

#line 1055 "ordcltn.m"
(objcT156=aBlock,(*_imp(objcT156,selTransTbl[33]))(objcT156,selTransTbl[33],(objcT157=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT157,selTransTbl[12]))(objcT157,selTransTbl[12],i))));if( *flag)break;}
return(id)self;
}

static id i_OrdCltn_reverseDo_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aBlock)
{
id objcT158;

#line 1061 "ordcltn.m"
unsigned n=(objcT158=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT158,selTransTbl[11]))(objcT158,selTransTbl[11]));
while(n--){
id objcT159,objcT160;

#line 1063 "ordcltn.m"
(objcT159=aBlock,(*_imp(objcT159,selTransTbl[33]))(objcT159,selTransTbl[33],(objcT160=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT160,selTransTbl[12]))(objcT160,selTransTbl[12],n))));
}
return(id)self;
}

#line 1075 "ordcltn.m"
static id ptrfind(id*p,id obj,int n)
{
int i;
for(i=0;i<n;i++){
if(p[i]==obj){
return p[i];
}
}
return(id)0;
}

static id find(objcol_t self,id obj)
{
return ptrfind(self->ptr,obj,self->count);
}

static id i_OrdCltn_find_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
return find(( &self->value),anObject);
}

static id ptrfindmatch(id*p,id obj,int n)
{
int i;
for(i=0;i<n;i++){
id objcT161;

#line 1100 "ordcltn.m"
if(p[i]==obj||(objcT161=p[i],(*(BOOL(*)(id,SEL,id))_imp(objcT161,selTransTbl[10]))(objcT161,selTransTbl[10],obj))){
return p[i];
}
}
return(id)0;
}

static id findmatch(objcol_t self,id obj)
{
return ptrfindmatch(self->ptr,obj,self->count);
}

static id i_OrdCltn_findMatching_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
return findmatch(( &self->value),anObject);
}

static BOOL i_OrdCltn_includes_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT162;

#line 1119 "ordcltn.m"
return(objcT162=(id)self,(*_imp(objcT162,selTransTbl[14]))(objcT162,selTransTbl[14],anObject))==(id)0;
}

static id ptrfindstr(id*p,STR s,int n)
{
int i;
for(i=0;i<n;i++){
id objcT163;

#line 1126 "ordcltn.m"
if((objcT163= *p++,(*(BOOL(*)(id,SEL,STR))_imp(objcT163,selTransTbl[38]))(objcT163,selTransTbl[38],s))){
return *p;
}
}
return(id)0;
}

static id findstr(objcol_t self,STR s)
{
return ptrfindstr(self->ptr,s,self->count);
}

static id i_OrdCltn_findSTR_(struct OrdCltn_PRIVATE *self,SEL _cmd,STR aString)
{
return findstr(( &self->value),aString);
}

static BOOL i_OrdCltn_contains_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT164;

#line 1145 "ordcltn.m"
return(objcT164=(id)self,(*_imp(objcT164,selTransTbl[13]))(objcT164,selTransTbl[13],anObject))!=(id)0;
}

static int ptroffset(id*p,id obj,int n)
{
int i;
for(i=0;i<n;i++){
if( *p++==obj){
return i;
}
}
return -1;
}

static int offset(objcol_t self,id obj)
{
return ptroffset(self->ptr,obj,self->count);
}

static unsigned i_OrdCltn_offsetOf_(struct OrdCltn_PRIVATE *self,SEL _cmd,id anObject)
{
return(unsigned)offset(( &self->value),anObject);
}

#line 1175 "ordcltn.m"
static id i_OrdCltn_printOn_(struct OrdCltn_PRIVATE *self,SEL _cmd,IOD aFile)
{
id objcT165;

#line 1177 "ordcltn.m"
int i,n=(objcT165=(id)self,(*(unsigned(*)(id,SEL))_imp(objcT165,selTransTbl[11]))(objcT165,selTransTbl[11]));
for(i=0;i<n;i++){
id objcT166,objcT167;

#line 1179 "ordcltn.m"
id s=(objcT166=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT166,selTransTbl[12]))(objcT166,selTransTbl[12],i));
(objcT167=s,(*(id(*)(id,SEL,IOD))_imp(objcT167,selTransTbl[39]))(objcT167,selTransTbl[39],aFile));
fprintf(aFile,"\n");
}
return(id)self;
}

#line 1193 "ordcltn.m"
static void ptrfileout(id aFiler,id*a,int n)
{
while(n--){
id objcT168;

#line 1196 "ordcltn.m"
(objcT168=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT168,selTransTbl[40]))(objcT168,selTransTbl[40],a++,'@'));
}
}

static void ptrfilein(id aFiler,id*a,int n)
{
while(n--){
id objcT169;

#line 1203 "ordcltn.m"
(objcT169=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT169,selTransTbl[41]))(objcT169,selTransTbl[41],a++,'@'));
}
}

static void fileout(id aFiler,objcol_t self)
{
id objcT170,objcT171;

#line 1209 "ordcltn.m"
(objcT170=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT170,selTransTbl[40]))(objcT170,selTransTbl[40], &self->count,'i'));
(objcT171=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT171,selTransTbl[40]))(objcT171,selTransTbl[40], &self->capacity,'i'));
ptrfileout(aFiler,self->ptr,self->count);
}

static void filein(id aFiler,objcol_t self)
{
id objcT172,objcT173;

#line 1216 "ordcltn.m"
int n,c;
(objcT172=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT172,selTransTbl[41]))(objcT172,selTransTbl[41], &n,'i'));
(objcT173=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT173,selTransTbl[41]))(objcT173,selTransTbl[41], &c,'i'));
init(self,n,c);
ptrfilein(aFiler,self->ptr,n);
}

static id i_OrdCltn_fileOutOn_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT174;

#line 1225 "ordcltn.m"
(objcT174=_OrdCltn.clsSuper,(*_impSuper(objcT174,selTransTbl[42]))((id)self,selTransTbl[42],aFiler));fileout(aFiler, &self->value);return(id)self;
}

static id i_OrdCltn_fileInFrom_(struct OrdCltn_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT175;

#line 1230 "ordcltn.m"
(objcT175=_OrdCltn.clsSuper,(*_impSuper(objcT175,selTransTbl[43]))((id)self,selTransTbl[43],aFiler));filein(aFiler, &self->value);return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Cltn;
extern struct _SHARED _Cltn;
extern struct _SHARED __Cltn;
static struct _SLT _OrdCltn_clsDispatchTbl[] ={
{"new",(id (*)())c_OrdCltn_new},
{"new:",(id (*)())c_OrdCltn_new_},
{"with:",(id (*)())c_OrdCltn_with_},
{"with:with:",(id (*)())c_OrdCltn_with_with_},
{"add:",(id (*)())c_OrdCltn_add_},
{(char*)0,(id (*)())0}
};
static struct _SLT _OrdCltn_nstDispatchTbl[] ={
{"copy",(id (*)())i_OrdCltn_copy},
{"deepCopy",(id (*)())i_OrdCltn_deepCopy},
{"emptyYourself",(id (*)())i_OrdCltn_emptyYourself},
{"freeContents",(id (*)())i_OrdCltn_freeContents},
{"freeAll",(id (*)())i_OrdCltn_freeAll},
{"free",(id (*)())i_OrdCltn_free},
{"release",(id (*)())i_OrdCltn_release},
{"objcolvalue",(id (*)())i_OrdCltn_objcolvalue},
{"size",(id (*)())i_OrdCltn_size},
{"isEmpty",(id (*)())i_OrdCltn_isEmpty},
{"lastOffset",(id (*)())i_OrdCltn_lastOffset},
{"eachElement",(id (*)())i_OrdCltn_eachElement},
{"firstElement",(id (*)())i_OrdCltn_firstElement},
{"lastElement",(id (*)())i_OrdCltn_lastElement},
{"hash",(id (*)())i_OrdCltn_hash},
{"isEqual:",(id (*)())i_OrdCltn_isEqual_},
{"add:",(id (*)())i_OrdCltn_add_},
{"addYourself",(id (*)())i_OrdCltn_addYourself},
{"addFirst:",(id (*)())i_OrdCltn_addFirst_},
{"addLast:",(id (*)())i_OrdCltn_addLast_},
{"addIfAbsent:",(id (*)())i_OrdCltn_addIfAbsent_},
{"addIfAbsentMatching:",(id (*)())i_OrdCltn_addIfAbsentMatching_},
{"boundserror",(id (*)())i_OrdCltn_boundserror},
{"at:insert:",(id (*)())i_OrdCltn_at_insert_},
{"couldntfind",(id (*)())i_OrdCltn_couldntfind},
{"insert:after:",(id (*)())i_OrdCltn_insert_after_},
{"insert:before:",(id (*)())i_OrdCltn_insert_before_},
{"after:",(id (*)())i_OrdCltn_after_},
{"before:",(id (*)())i_OrdCltn_before_},
{"at:",(id (*)())i_OrdCltn_at_},
{"at:put:",(id (*)())i_OrdCltn_at_put_},
{"removeFirst",(id (*)())i_OrdCltn_removeFirst},
{"removeLast",(id (*)())i_OrdCltn_removeLast},
{"removeAt:",(id (*)())i_OrdCltn_removeAt_},
{"removeAtIndex:",(id (*)())i_OrdCltn_removeAtIndex_},
{"remove:",(id (*)())i_OrdCltn_remove_},
{"remove:ifAbsent:",(id (*)())i_OrdCltn_remove_ifAbsent_},
{"includesAllOf:",(id (*)())i_OrdCltn_includesAllOf_},
{"includesAnyOf:",(id (*)())i_OrdCltn_includesAnyOf_},
{"addAll:",(id (*)())i_OrdCltn_addAll_},
{"addContentsOf:",(id (*)())i_OrdCltn_addContentsOf_},
{"addContentsTo:",(id (*)())i_OrdCltn_addContentsTo_},
{"removeAll:",(id (*)())i_OrdCltn_removeAll_},
{"removeContentsFrom:",(id (*)())i_OrdCltn_removeContentsFrom_},
{"removeContentsOf:",(id (*)())i_OrdCltn_removeContentsOf_},
{"intersection:",(id (*)())i_OrdCltn_intersection_},
{"union:",(id (*)())i_OrdCltn_union_},
{"difference:",(id (*)())i_OrdCltn_difference_},
{"asSet",(id (*)())i_OrdCltn_asSet},
{"asOrdCltn",(id (*)())i_OrdCltn_asOrdCltn},
{"detect:",(id (*)())i_OrdCltn_detect_},
{"detect:ifNone:",(id (*)())i_OrdCltn_detect_ifNone_},
{"select:",(id (*)())i_OrdCltn_select_},
{"reject:",(id (*)())i_OrdCltn_reject_},
{"collect:",(id (*)())i_OrdCltn_collect_},
{"count:",(id (*)())i_OrdCltn_count_},
{"elementsPerform:",(id (*)())i_OrdCltn_elementsPerform_},
{"elementsPerform:with:",(id (*)())i_OrdCltn_elementsPerform_with_},
{"elementsPerform:with:with:",(id (*)())i_OrdCltn_elementsPerform_with_with_},
{"elementsPerform:with:with:with:",(id (*)())i_OrdCltn_elementsPerform_with_with_with_},
{"do:",(id (*)())i_OrdCltn_do_},
{"do:until:",(id (*)())i_OrdCltn_do_until_},
{"reverseDo:",(id (*)())i_OrdCltn_reverseDo_},
{"find:",(id (*)())i_OrdCltn_find_},
{"findMatching:",(id (*)())i_OrdCltn_findMatching_},
{"includes:",(id (*)())i_OrdCltn_includes_},
{"findSTR:",(id (*)())i_OrdCltn_findSTR_},
{"contains:",(id (*)())i_OrdCltn_contains_},
{"offsetOf:",(id (*)())i_OrdCltn_offsetOf_},
{"printOn:",(id (*)())i_OrdCltn_printOn_},
{"fileOutOn:",(id (*)())i_OrdCltn_fileOutOn_},
{"fileInFrom:",(id (*)())i_OrdCltn_fileInFrom_},
{(char*)0,(id (*)())0}
};
id OrdCltn = (id)&_OrdCltn;
id  *OBJCCLASS_OrdCltn(void) { return &OrdCltn; }
struct _SHARED  _OrdCltn = {
  (id)&__OrdCltn,
  (id)&_Cltn,
  "OrdCltn",
  0,
  sizeof(struct OrdCltn_PRIVATE),
  72,
  _OrdCltn_nstDispatchTbl,
  41,
  &ordcltn_modDesc,
  0,
  (id)0,
  &OrdCltn,
};
id  OBJCCFUNC_OrdCltn(void) { return (id)&_OrdCltn; }
id  OBJCCSUPER_OrdCltn(void) { return _OrdCltn.clsSuper; }
struct _SHARED __OrdCltn = {
  (id)&__Object,
  (id)&__Cltn,
  "OrdCltn",
  0,
  sizeof(struct _SHARED),
  5,
  _OrdCltn_clsDispatchTbl,
  34,
  &ordcltn_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_OrdCltn(void) { return (id)&__OrdCltn; }
id  OBJCMSUPER_OrdCltn(void) { return __OrdCltn.clsSuper; }
static char *_selTransTbl[] ={
"new",
"objcolvalue",
"add:",
"copy",
"deepCopy",
"free",
"freeAll",
"release",
"over:",
"hash",
"isEqual:",
"size",
"at:",
"find:",
"findMatching:",
"error:",
"boundserror",
"offsetOf:",
"couldntfind",
"at:insert:",
"lastOffset",
"removeAt:",
"remove:",
"value",
"eachElement",
"next",
"includes:",
"addYourself",
"addAll:",
"emptyYourself",
"removeAll:",
"isKindOf:",
"class",
"value:",
"perform:",
"perform:with:",
"perform:with:with:",
"perform:with:with:with:",
"isEqualSTR:",
"printOn:",
"fileOut:type:",
"fileIn:type:",
"fileOutOn:",
"fileInFrom:",
0
};
struct modDescriptor ordcltn_modDesc = {
  "ordcltn",
  "objc2.3.1",
  0L,
  0,
  0,
  &OrdCltn,
  44,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_ordcltn(void)
{
  selTransTbl = _selTransTbl;
  return &ordcltn_modDesc;
}
int _OBJCPOSTLINK_ordcltn = 1;


