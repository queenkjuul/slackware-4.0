#line 1 "Block.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_Block(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor Block_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 72 "objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 81 "objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 141 "objcrt.h"
struct objcrt_private
{
id isa;
#line 147 "objcrt.h"
unsigned short attr;
unsigned short objID;

};

struct objcrt_shared
{
id isa;
#line 158 "objcrt.h"
id clsSuper;
char*clsName;
char*clsTypes;
short clsSizInstance;
short clsSizDict;
struct objcrt_slt*clsDispTable;
long clsStatus;
struct objcrt_modDescriptor*clsMod;
unsigned clsVersion;
id clsCats;
id*clsGlbl;
};

typedef struct objcrt_shared*Cls_t;
#line 203 "objcrt.h"
struct objcrt_slt
{
SEL _cmd;
IMP _imp;
};
#line 213 "objcrt.h"
struct objcrt_useDescriptor
{
int processed;
struct objcrt_useDescriptor*next;
struct objcrt_useDescriptor***uses;
struct objcrt_modDescriptor*(*bind)();
};
#line 225 "objcrt.h"
typedef struct hashedSelector
{
struct hashedSelector*next;
STR key;
}
HASH,*PHASH;
#line 237 "objcrt.h"
typedef struct objcrt_modDescriptor MOD,*PMOD;
typedef struct objcrt_methodDescriptor METH,*PMETH;

struct objcrt_modDescriptor
{
STR modName;
STR modVersion;
long modStatus;
SEL modMinSel;
SEL modMaxSel;
id*modClsLst;
short modSelRef;
SEL*modSelTbl;
PMETH modMapTbl;
};

struct objcrt_modEntry
{
PMOD(*modLink)();
PMOD modInfo;
};

typedef struct objcrt_modEntry*Mentry_t;

struct objcrt_methodDescriptor
{
id*cls;
SEL*sel;
IMP imp;
};
#line 280 "objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 293 "objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 311 "objcrt.h"
IMP _imp(id,SEL);
IMP _impSuper(id,SEL);
#line 316 "objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);
#line 345 "objcrt.h"
extern id(*oc_alloc)(id,unsigned int);
extern id(*oc_dealloc)(id);
extern id(*oc_copy)(id,unsigned int);
extern id(*oc_error)(id,STR,va_list);

extern id(*oc_cvtToId)(STR);
extern SEL(*oc_cvtToSel)(STR);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);

void addSubclassesTo(id c,STR name);

id newsubclass(STR name,id superClass,int ivars,int cvars);

void addMethods(id src,id dst);

void poseAs(id posing,id target);
id swapclass(id self,id target);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 42 "Block.h"
extern id newBlock(int n,IMP fn,void*data,IMP dtor);
#line 1 "../../util/setjmp.h"
#include <setjmp.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 44 "Block.h"
struct Block_PRIVATE {

#line 42 "Object.h"
id isa;
#line 46 "Object.h"
unsigned short attr;
unsigned short objID;
#line 46 "Block.h"
IMP fn;
IMP dtor;
int nVars;
void**data;};

#line 44 "Block.h"
extern id  Block;

#line 44 "Block.h"
extern struct _SHARED _Block;
extern struct _SHARED __Block;


#line 52 "Block.m"
id newBlock(int n,IMP f,void*d,IMP c)
{
id objcT0;

#line 54 "Block.m"
return(objcT0=Block,(*(id(*)(id,SEL,int,IMP,void**,IMP))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0],n,f,(void**)d,c));
}

#line 64 "Block.m"
static id err_fun(id thisBlock,void**data,id msg,id rcv)
{
id objcT1,objcT2;
prnstack(stderr);

if(rcv)fprintf(stderr,"%s: ",(objcT1=rcv,(*(STR(*)(id,SEL))_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1])));
if(msg)(objcT2=msg,(*(id(*)(id,SEL,IOD))_imp(objcT2,selTransTbl[2]))(objcT2,selTransTbl[2],stderr));else fprintf(stderr,"(null message)");
if(rcv!=(id)0||msg!=(id)0)fprintf(stderr,"\n");
abort();return(id)0;
}

static id i_Block_blkc_blkfn_blkv_blkdtor_(struct Block_PRIVATE *self,SEL _cmd,int n,IMP f,void**d,IMP c)
{self->
nVars=n;self->fn=f;self->data=d;self->dtor=c;return(id)self;
}

static id c_Block_new(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT3;

#line 82 "Block.m"
return(objcT3=(id)self,(*_imp(objcT3,selTransTbl[3]))(objcT3,selTransTbl[3]));
}

static id i_Block_copy(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT4;

#line 87 "Block.m"
return(objcT4=(id)self,(*_imp(objcT4,selTransTbl[3]))(objcT4,selTransTbl[3]));
}

static id i_Block_deepCopy(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT5;

#line 92 "Block.m"
return(objcT5=(id)self,(*_imp(objcT5,selTransTbl[3]))(objcT5,selTransTbl[3]));
}

static id c_Block_blkc_blkfn_blkv_blkdtor_(struct Block_PRIVATE *self,SEL _cmd,int n,IMP f,void**d,IMP c)
{
id objcT6,objcT7;

#line 97 "Block.m"
return(objcT6=(objcT7=__Block.clsSuper,(*_impSuper(objcT7,selTransTbl[4]))((id)self,selTransTbl[4])),(*(id(*)(id,SEL,int,IMP,void**,IMP))_imp(objcT6,selTransTbl[0]))(objcT6,selTransTbl[0],n,f,d,c));
}

static id i_Block_free(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT8;

#line 102 "Block.m"
if(self->data)( *((void(*)(void**))self->dtor))(self->data);
return(objcT8=_Block.clsSuper,(*_impSuper(objcT8,selTransTbl[5]))((id)self,selTransTbl[5]));
}

static id i_Block_release(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT9;

#line 108 "Block.m"
if(self->data)( *((void(*)(void**))self->dtor))(self->data);
return(objcT9=_Block.clsSuper,(*_impSuper(objcT9,selTransTbl[6]))((id)self,selTransTbl[6]));
}
#line 119 "Block.m"
static id defaultHandler;
static int jmpCount=0;
static id jmpHandlers[32];

static id c_Block_pop(struct Block_PRIVATE *self,SEL _cmd)
{
return(jmpCount)?jmpHandlers[ --jmpCount]:(id)0;
}

static id c_Block_push_(struct Block_PRIVATE *self,SEL _cmd,id aHandler)
{
id objcT10,objcT11;

#line 130 "Block.m"
jmpHandlers[jmpCount]=(objcT10=aHandler,(*_imp(objcT10,selTransTbl[7]))(objcT10,selTransTbl[7]));
if(( ++jmpCount)==32)return(objcT11=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT11,selTransTbl[8]))(objcT11,selTransTbl[8],"Increase MAX_JMP."));
return(id)self;
}

static id c_Block_errorHandler(struct Block_PRIVATE *self,SEL _cmd)
{
if( !defaultHandler)defaultHandler=newBlock(2,(IMP)err_fun,NULL,NULL);
return defaultHandler;
}

static id c_Block_errorHandler_(struct Block_PRIVATE *self,SEL _cmd,id aHandler)
{
id objcT12;

#line 143 "Block.m"
id ret=defaultHandler;
defaultHandler=(objcT12=aHandler,(*_imp(objcT12,selTransTbl[7]))(objcT12,selTransTbl[7]));
return ret;
}


static id i_Block_ifError_(struct Block_PRIVATE *self,SEL _cmd,id aHandler)
{
id objcT13,objcT14,objcT15;

#line 151 "Block.m"
id returnValue;
(objcT13=Block,(*_imp(objcT13,selTransTbl[9]))(objcT13,selTransTbl[9],aHandler));returnValue=(objcT14=(id)self,(*_imp(objcT14,selTransTbl[10]))(objcT14,selTransTbl[10]));(objcT15=Block,(*_imp(objcT15,selTransTbl[11]))(objcT15,selTransTbl[11]));
return returnValue;
}

static id i_Block_value_ifError_(struct Block_PRIVATE *self,SEL _cmd,id anObject,id aHandler)
{
id objcT16,objcT17,objcT18;

#line 158 "Block.m"
id returnValue;
(objcT16=Block,(*_imp(objcT16,selTransTbl[9]))(objcT16,selTransTbl[9],aHandler));returnValue=(objcT17=(id)self,(*_imp(objcT17,selTransTbl[12]))(objcT17,selTransTbl[12],anObject));(objcT18=Block,(*_imp(objcT18,selTransTbl[11]))(objcT18,selTransTbl[11]));
return returnValue;
}

#line 170 "Block.m"
static id i_Block_errorNumArgs(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT19;

#line 172 "Block.m"
return(objcT19=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT19,selTransTbl[8]))(objcT19,selTransTbl[8],"Block has wrong number of arguments."));
}

static id i_Block_errorGoodHandler(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT20;

#line 177 "Block.m"
return(self->nVars==2)?(id)self:(objcT20=(id)self,(*_imp(objcT20,selTransTbl[13]))(objcT20,selTransTbl[13]));
}

static id i_Block_value(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT21;

#line 182 "Block.m"
return(self->nVars==0)?(id)( *self->fn)((id)self,self->data):(objcT21=(id)self,(*_imp(objcT21,selTransTbl[13]))(objcT21,selTransTbl[13]));
}

static int i_Block_intvalue(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT22;

#line 187 "Block.m"
if(self->nVars!=0)(objcT22=(id)self,(*_imp(objcT22,selTransTbl[13]))(objcT22,selTransTbl[13]));
return( *((int(*)(id,void*))self->fn))((id)self,self->data);
}

#line 201 "Block.m"
static id i_Block_atExit(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT23;

return(objcT23=(id)self,(*_imp(objcT23,selTransTbl[14]))(objcT23,selTransTbl[14]));
#line 215 "Block.m"
}

static id i_Block_value_(struct Block_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT24;

#line 219 "Block.m"
return(self->nVars==1)?(id)( *self->fn)((id)self,self->data,anObject):(objcT24=(id)self,(*_imp(objcT24,selTransTbl[13]))(objcT24,selTransTbl[13]));
}

static int i_Block_intvalue_(struct Block_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT25;

#line 224 "Block.m"
if(self->nVars!=1)(objcT25=(id)self,(*_imp(objcT25,selTransTbl[13]))(objcT25,selTransTbl[13]));
return( *((int(*)(id,void*,id))self->fn))((id)self,self->data,anObject);
}

static id i_Block_value_value_(struct Block_PRIVATE *self,SEL _cmd,id firstObject,id secondObject)
{
if(self->nVars==2){
return(id)( *self->fn)((id)self,self->data,firstObject,secondObject);
}else{
id objcT26;

#line 233 "Block.m"
return(objcT26=(id)self,(*_imp(objcT26,selTransTbl[13]))(objcT26,selTransTbl[13]));
}
return(id)0;
}

static int i_Block_intvalue_value_(struct Block_PRIVATE *self,SEL _cmd,id firstObject,id secondObject)
{
id objcT27;

#line 240 "Block.m"
if(self->nVars!=2)(objcT27=(id)self,(*_imp(objcT27,selTransTbl[13]))(objcT27,selTransTbl[13]));
return( *((int(*)(id,void*,id,id))self->fn))((id)self,self->data,firstObject,secondObject);
}

#line 251 "Block.m"
static id i_Block_repeatTimes_(struct Block_PRIVATE *self,SEL _cmd,int n)
{
id objcT28;

#line 253 "Block.m"
int i;
for(i=0;i<n;i++)(objcT28=(id)self,(*_imp(objcT28,selTransTbl[10]))(objcT28,selTransTbl[10]));
return(id)self;
}

static id i_Block_shouldNotImplement(struct Block_PRIVATE *self,SEL _cmd)
{
id objcT29;

(objcT29=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT29,selTransTbl[8]))(objcT29,selTransTbl[8],"Message is not approriate for this class."));
return(id)self;
}

static id i_Block_printOn_(struct Block_PRIVATE *self,SEL _cmd,IOD anIod)
{
id objcT30;

return(objcT30=(id)self,(*_imp(objcT30,selTransTbl[3]))(objcT30,selTransTbl[3]));
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
static struct _SLT _Block_clsDispatchTbl[] ={
{"new",(id (*)())c_Block_new},
{"blkc:blkfn:blkv:blkdtor:",(id (*)())c_Block_blkc_blkfn_blkv_blkdtor_},
{"pop",(id (*)())c_Block_pop},
{"push:",(id (*)())c_Block_push_},
{"errorHandler",(id (*)())c_Block_errorHandler},
{"errorHandler:",(id (*)())c_Block_errorHandler_},
{(char*)0,(id (*)())0}
};
static struct _SLT _Block_nstDispatchTbl[] ={
{"blkc:blkfn:blkv:blkdtor:",(id (*)())i_Block_blkc_blkfn_blkv_blkdtor_},
{"copy",(id (*)())i_Block_copy},
{"deepCopy",(id (*)())i_Block_deepCopy},
{"free",(id (*)())i_Block_free},
{"release",(id (*)())i_Block_release},
{"ifError:",(id (*)())i_Block_ifError_},
{"value:ifError:",(id (*)())i_Block_value_ifError_},
{"errorNumArgs",(id (*)())i_Block_errorNumArgs},
{"errorGoodHandler",(id (*)())i_Block_errorGoodHandler},
{"value",(id (*)())i_Block_value},
{"intvalue",(id (*)())i_Block_intvalue},
{"atExit",(id (*)())i_Block_atExit},
{"value:",(id (*)())i_Block_value_},
{"intvalue:",(id (*)())i_Block_intvalue_},
{"value:value:",(id (*)())i_Block_value_value_},
{"intvalue:value:",(id (*)())i_Block_intvalue_value_},
{"repeatTimes:",(id (*)())i_Block_repeatTimes_},
{"shouldNotImplement",(id (*)())i_Block_shouldNotImplement},
{"printOn:",(id (*)())i_Block_printOn_},
{(char*)0,(id (*)())0}
};
id Block = (id)&_Block;
id  *OBJCCLASS_Block(void) { return &Block; }
struct _SHARED  _Block = {
  (id)&__Block,
  (id)&_Object,
  "Block",
  0,
  sizeof(struct Block_PRIVATE),
  19,
  _Block_nstDispatchTbl,
  41,
  &Block_modDesc,
  0,
  (id)0,
  &Block,
};
id  OBJCCFUNC_Block(void) { return (id)&_Block; }
id  OBJCCSUPER_Block(void) { return _Block.clsSuper; }
struct _SHARED __Block = {
  (id)&__Object,
  (id)&__Object,
  "Block",
  0,
  sizeof(struct _SHARED),
  6,
  _Block_clsDispatchTbl,
  34,
  &Block_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_Block(void) { return (id)&__Block; }
id  OBJCMSUPER_Block(void) { return __Block.clsSuper; }
static char *_selTransTbl[] ={
"blkc:blkfn:blkv:blkdtor:",
"name",
"printOn:",
"shouldNotImplement",
"new",
"free",
"release",
"errorGoodHandler",
"error:",
"push:",
"value",
"pop",
"value:",
"errorNumArgs",
"notImplemented",
0
};
struct modDescriptor Block_modDesc = {
  "Block",
  "objc2.3.1",
  0L,
  0,
  0,
  &Block,
  15,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_Block(void)
{
  selTransTbl = _selTransTbl;
  return &Block_modDesc;
}
int _OBJCPOSTLINK_Block = 1;


