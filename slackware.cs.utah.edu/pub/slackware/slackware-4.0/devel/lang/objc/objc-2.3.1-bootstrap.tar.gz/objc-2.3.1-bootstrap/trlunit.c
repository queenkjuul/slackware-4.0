#line 1 "trlunit.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_trlunit(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor trlunit_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/ctype.h"
#include <ctype.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 28 "../../include/objpak/set.h"
typedef struct objset{
int count;
int capacity;
id*ptr;
}*objset_t;
#line 31 "../../include/objpak/ordcltn.h"
typedef struct objcol{
int count;
int capacity;
id*ptr;
}*objcol_t;
#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "expr.h"
extern id e_nil;
extern id e_self;
extern id e_cmd;
extern id e_super;
extern id e_aFiler;
extern id e_ft_id;
#line 22 "trlunit.h"
extern id trlunit;
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 22 "classdef.h"
extern id curclassdef;
extern id curstruct;
#line 43 "trlunit.m"
id trlunit;
#line 24 "trlunit.h"
struct TranslationUnit_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 26 "trlunit.h"
int msgcount;
int icachecount;
int blockcount;
int heapvarcount;
int retlabelcount;
id types,typedic;
id globals,globaldic;
id builtinfuns,builtintypes;
id clsimpl;
id clsimpls;
id seldic,selcltn;
id msgdic,fwdcltn;
char*modname;
char*modversion;
char*bindfunname;
char*moddescname;
id usesentries;
id definesentries;
id methods;
id classdefs;
id structdefs;
id gentypes;
id enumtors;
BOOL usingblocks;
BOOL usingselfassign;};

#line 24 "trlunit.h"
extern id  TranslationUnit;

#line 24 "trlunit.h"
extern struct _SHARED _TranslationUnit;
extern struct _SHARED __TranslationUnit;


#line 58 "symbol.h"
extern id  Symbol;

#line 33 "type.h"
extern id  Type;

#line 29 "expr.h"
extern id  Expr;

#line 47 "trlunit.m"
static id c_TranslationUnit_new(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT0,objcT1,objcT2,objcT3;

#line 49 "trlunit.m"
(objcT0=Symbol,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
(objcT1=Type,(*_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1]));
(objcT2=Expr,(*_imp(objcT2,selTransTbl[2]))(objcT2,selTransTbl[2]));
return trlunit=(objcT3=__TranslationUnit.clsSuper,(*_impSuper(objcT3,selTransTbl[3]))((id)self,selTransTbl[3]));
}

static int i_TranslationUnit_msgcount(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
return self->msgcount++;
}

#line 38 "../../include/objpak/ocstring.h"
extern id  String;

#line 60 "trlunit.m"
static id i_TranslationUnit_gettmpvar(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT4,objcT5;

#line 62 "trlunit.m"
return(objcT4=String,(*(id(*)(id,SEL,STR,...))_imp(objcT4,selTransTbl[4]))(objcT4,selTransTbl[4],"objcT%i",(objcT5=trlunit,(*(int(*)(id,SEL))_imp(objcT5,selTransTbl[5]))(objcT5,selTransTbl[5]))));
}

static int i_TranslationUnit_icachecount(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
return self->icachecount++;
}

static int i_TranslationUnit_blockcount(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
return self->blockcount++;
}

static int i_TranslationUnit_heapvarcount(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
return self->heapvarcount++;
}

static id i_TranslationUnit_returnlabel(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT6;

#line 82 "trlunit.m"
return(objcT6=String,(*(id(*)(id,SEL,STR,...))_imp(objcT6,selTransTbl[4]))(objcT6,selTransTbl[4],"_cleanup%i",self->retlabelcount++));
}

static BOOL i_TranslationUnit_usingselfassign(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
return self->usingselfassign;
}

static id i_TranslationUnit_usingselfassign_(struct TranslationUnit_PRIVATE *self,SEL _cmd,BOOL x)
{self->
usingselfassign=x;
return(id)self;
}

static BOOL i_TranslationUnit_usingblocks(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
return self->usingblocks;
}

static id i_TranslationUnit_usingblocks_(struct TranslationUnit_PRIVATE *self,SEL _cmd,BOOL x)
{self->
usingblocks=x;
return(id)self;
}

static id i_TranslationUnit_inlinecacheprologue(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{

if(o_cplus){
gs("struct objcrt_inlineCache {id cls;id (*imp)(...);};\n");
}else{
gs("struct objcrt_inlineCache {id cls;id (*imp)();};\n");
}
#line 118 "trlunit.m"
if(o_cplus){
gextc();
gf("id %s _nilHandler(...);\n",o_bind);
}else{
gf("id %s _nilHandler(id,char*);\n",o_bind);
}

return(id)self;
}

static id i_TranslationUnit_setmodversion_(struct TranslationUnit_PRIVATE *self,SEL _cmd,char*v)
{self->
modversion=v;
return(id)self;
}

static char*
mystrrchr(const char*s,int c)
{
char*t=(char*)s;

while( *t){
t++;
}

while(t!=s){
if( *t==c)
return t;
else
t--;
}

return( *t==c)?t:NULL;
}

static id i_TranslationUnit_setmodname_(struct TranslationUnit_PRIVATE *self,SEL _cmd,char*filename)
{
id objcT7,objcT8,objcT9,objcT10,objcT11;
id objcT12;

#line 155 "trlunit.m"
id s;
char*p;
char*cp;

p=mystrrchr(filename,o_pathsep[0]);
s=(objcT7=String,(*(id(*)(id,SEL,STR))_imp(objcT7,selTransTbl[6]))(objcT7,selTransTbl[6],(p)?p+1:(char*)filename));
p=(objcT8=s,(*(STR(*)(id,SEL))_imp(objcT8,selTransTbl[7]))(objcT8,selTransTbl[7]));
if((cp=mystrrchr(p,'.'))!=NULL) *
cp='\0';
for(cp=p; *cp!='\0';cp++){
if( !isalnum( *cp)) *
cp='_';
}self->


modname=p;


s=(objcT9=String,(*(id(*)(id,SEL,STR,...))_imp(objcT9,selTransTbl[4]))(objcT9,selTransTbl[4],"_OBJCBIND_%s",p));self->
bindfunname=(objcT10=s,(*(STR(*)(id,SEL))_imp(objcT10,selTransTbl[7]))(objcT10,selTransTbl[7]));
#line 178 "trlunit.m"
s=(objcT11=String,(*(id(*)(id,SEL,STR,...))_imp(objcT11,selTransTbl[4]))(objcT11,selTransTbl[4],"%s_modDesc",p));self->
moddescname=(objcT12=s,(*(STR(*)(id,SEL))_imp(objcT12,selTransTbl[7]))(objcT12,selTransTbl[7]));
#line 184 "trlunit.m"
return(id)self;
}

static char*i_TranslationUnit_moddescname(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
assert(self->moddescname!=NULL);
return self->moddescname;
}

static id i_TranslationUnit_checkbindprologue(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
gs("\nextern char *objcrt_bindError(char *);\n");
return(id)self;
}

#line 25 "classdef.h"
extern id  ClassDef;

#line 199 "trlunit.m"
static id i_TranslationUnit_prologue(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT13,objcT14,objcT15,objcT16;

#line 201 "trlunit.m"
assert(self->modname!=NULL);

if(o_comments)
gs("/* objc prologue */\n");

if(o_otb){
gs("struct _PRIVATE {\n");
gs("  struct OTB *isa;\n");
gs("};\n");
gs("struct OTB {\n");
gs("  struct _PRIVATE *ptr;\n");
g_otbvars();
gs("};\n");
gs("typedef struct OTB *id;\n");
}else{
if( !o_refcnt){
gs("struct _PRIVATE { struct _PRIVATE *isa; };\n");
}else{
gs("struct _PRIVATE { struct _PRIVATE *isa;unsigned int _refcnt; };\n");
}
gs("typedef struct _PRIVATE *id;\n");
}

(objcT13=(objcT14=ClassDef,(*_imp(objcT14,selTransTbl[3]))(objcT14,selTransTbl[3])),(*_imp(objcT13,selTransTbl[8]))(objcT13,selTransTbl[8]));

if( !o_fwd){
if(o_cplus){
gextc();
gf("id %s (* _imp(id,char*))(...);\n",o_bind);
gextc();
gf("id %s (* _impSuper(id,char*))(...);\n",o_bind);
}else{
gf("extern id %s (* _imp(id,char*))();\n",o_bind);
gf("extern id %s (* _impSuper(id,char*))();\n",o_bind);
}
}
if(o_inlinecache)
(objcT15=(id)self,(*_imp(objcT15,selTransTbl[9]))(objcT15,selTransTbl[9]));

gf("extern struct modDescriptor %s *%s(void);\n",o_bind,self->bindfunname);

if(o_refbind){

gf("static char **selTransTbl = (char **)%s;\n",self->bindfunname);
}else{

gs("static char **selTransTbl;\n");
}

if(o_fwd){
if(o_cplus){
gs("static id (**fwdTransTbl)(...);\n");
}else{
gs("static id (**fwdTransTbl)();\n");
}
}

if(o_cplus){
gs("struct _SLT {char *_cmd;id (*_imp)(...);};\n");
}else{
gs("struct _SLT {char *_cmd;id (*_imp)();};\n");
}


gs("struct modDescriptor {\n");

gs("  char *modName;\n");
gs("  char *modVersion;\n");
gs("  long modStatus;\n");
gs("  char *modMinSel;\n");
gs("  char *modMaxSel;\n");
gs("  id *modClsLst;\n");
gs("  short modSelRef;\n");
gs("  char **modSelTbl;\n");
gs("  struct methodDescriptor *modMapTbl;\n");

gs("};\n");

gf("extern struct modDescriptor %s;\n",self->moddescname);
if(o_checkbind)
(objcT16=(id)self,(*_imp(objcT16,selTransTbl[10]))(objcT16,selTransTbl[10]));
if(o_comments)
gs("/* end of objc prologue */\n");
return(id)self;
}

#line 37 "../../include/objpak/ordcltn.h"
extern id  OrdCltn;

#line 287 "trlunit.m"
static id i_TranslationUnit_allclsimpls(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT17,objcT18;

#line 289 "trlunit.m"
if(self->clsimpls)
return self->clsimpls;
if(self->clsimpl)
return(objcT17=(objcT18=OrdCltn,(*_imp(objcT18,selTransTbl[3]))(objcT18,selTransTbl[3])),(*_imp(objcT17,selTransTbl[11]))(objcT17,selTransTbl[11],self->clsimpl));
return(id)0;
}

static id i_TranslationUnit_addclsimpl_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id c)
{

if(self->clsimpls){
id objcT19,objcT20;

#line 300 "trlunit.m"
assert(self->clsimpl==(id)0&&(objcT19=self->clsimpls,(*(unsigned(*)(id,SEL))_imp(objcT19,selTransTbl[12]))(objcT19,selTransTbl[12]))>=2);
(objcT20=self->clsimpls,(*_imp(objcT20,selTransTbl[11]))(objcT20,selTransTbl[11],c));
}else{
if(self->clsimpl){
if(o_oneperfile){
fatal("only one implementation per file allowed");
}else{
id objcT21,objcT22,objcT23;
self->
#line 307 "trlunit.m"
clsimpls=(objcT21=OrdCltn,(*_imp(objcT21,selTransTbl[3]))(objcT21,selTransTbl[3]));
(objcT22=self->clsimpls,(*_imp(objcT22,selTransTbl[11]))(objcT22,selTransTbl[11],self->clsimpl));
(objcT23=self->clsimpls,(*_imp(objcT23,selTransTbl[11]))(objcT23,selTransTbl[11],c));self->
clsimpl=(id)0;
}
}else{self->
clsimpl=c;
}
}
return(id)self;
}

#line 32 "../../include/objpak/dictnary.h"
extern id  Dictionary;

#line 319 "trlunit.m"
static int i_TranslationUnit_seloffset_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id selname)
{
id objcT26,objcT27;

#line 321 "trlunit.m"
int n;
id val;

if( !self->selcltn){
id objcT24,objcT25;
self->
#line 325 "trlunit.m"
selcltn=(objcT24=OrdCltn,(*_imp(objcT24,selTransTbl[3]))(objcT24,selTransTbl[3]));self->
seldic=(objcT25=Dictionary,(*_imp(objcT25,selTransTbl[3]))(objcT25,selTransTbl[3]));
}
n=(objcT26=self->selcltn,(*(unsigned(*)(id,SEL))_imp(objcT26,selTransTbl[12]))(objcT26,selTransTbl[12]));
if((val=(objcT27=self->seldic,(*_imp(objcT27,selTransTbl[13]))(objcT27,selTransTbl[13],selname)))){
id objcT28;

#line 330 "trlunit.m"
return(objcT28=val,(*(int(*)(id,SEL))_imp(objcT28,selTransTbl[14]))(objcT28,selTransTbl[14]));
}else{
id objcT29,objcT30,objcT31;

#line 332 "trlunit.m"
(objcT29=self->selcltn,(*_imp(objcT29,selTransTbl[11]))(objcT29,selTransTbl[11],selname));
(objcT30=self->seldic,(*_imp(objcT30,selTransTbl[15]))(objcT30,selTransTbl[15],selname,(objcT31=String,(*(id(*)(id,SEL,STR,...))_imp(objcT31,selTransTbl[4]))(objcT31,selTransTbl[4],"%i",n))));
}
return n;
}

static int i_TranslationUnit_fwdoffset_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id msg)
{
id objcT34,objcT35;

#line 340 "trlunit.m"
int n;
id val;

if( !self->fwdcltn){
id objcT32,objcT33;
self->
#line 344 "trlunit.m"
fwdcltn=(objcT32=OrdCltn,(*_imp(objcT32,selTransTbl[3]))(objcT32,selTransTbl[3]));self->
msgdic=(objcT33=Dictionary,(*_imp(objcT33,selTransTbl[3]))(objcT33,selTransTbl[3]));
}
n=(objcT34=self->fwdcltn,(*(unsigned(*)(id,SEL))_imp(objcT34,selTransTbl[12]))(objcT34,selTransTbl[12]));
#line 351 "trlunit.m"
if((val=(objcT35=self->msgdic,(*_imp(objcT35,selTransTbl[13]))(objcT35,selTransTbl[13],msg)))){
id objcT42;

#line 352 "trlunit.m"
if(o_debuginfo){
id objcT36,objcT37,objcT38,objcT39,objcT40;
id objcT41;

#line 353 "trlunit.m"
id x=(objcT36=msg,(*_imp(objcT36,selTransTbl[16]))(objcT36,selTransTbl[16]));
id y=(objcT37=(objcT38=self->fwdcltn,(*(id(*)(id,SEL,unsigned))_imp(objcT38,selTransTbl[17]))(objcT38,selTransTbl[17],(objcT39=val,(*(int(*)(id,SEL))_imp(objcT39,selTransTbl[14]))(objcT39,selTransTbl[14])))),(*_imp(objcT37,selTransTbl[16]))(objcT37,selTransTbl[16]));

fprintf(stderr,"using '%s' dispatch fun for '%s'\n",(objcT40=y,(*(STR(*)(id,SEL))_imp(objcT40,selTransTbl[18]))(objcT40,selTransTbl[18])),(objcT41=x,(*(STR(*)(id,SEL))_imp(objcT41,selTransTbl[18]))(objcT41,selTransTbl[18])));
}
return(objcT42=val,(*(int(*)(id,SEL))_imp(objcT42,selTransTbl[14]))(objcT42,selTransTbl[14]));
}else{
id objcT43,objcT44,objcT45;

#line 360 "trlunit.m"
(objcT43=self->fwdcltn,(*_imp(objcT43,selTransTbl[11]))(objcT43,selTransTbl[11],msg));
(objcT44=self->msgdic,(*_imp(objcT44,selTransTbl[15]))(objcT44,selTransTbl[15],msg,(objcT45=String,(*(id(*)(id,SEL,STR,...))_imp(objcT45,selTransTbl[4]))(objcT45,selTransTbl[4],"%i",n))));
}
return n;
}

static id i_TranslationUnit_genmodclslst(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT46;

#line 368 "trlunit.m"
int i,n;

assert(self->clsimpls&& !o_oneperfile);
gs("static id _modClsLst[] ={\n");
for(i=0,n=(objcT46=self->clsimpls,(*(unsigned(*)(id,SEL))_imp(objcT46,selTransTbl[12]))(objcT46,selTransTbl[12]));i<n;i++){
id objcT47,objcT48;

#line 373 "trlunit.m"
STR s=(objcT47=(objcT48=self->clsimpls,(*(id(*)(id,SEL,unsigned))_imp(objcT48,selTransTbl[17]))(objcT48,selTransTbl[17],i)),(*(char*(*)(id,SEL))_imp(objcT47,selTransTbl[19]))(objcT47,selTransTbl[19]));


gf("(id)&_%s,\n",s);
}

gs("(id)0};\n");
return(id)self;
}

static id i_TranslationUnit_genseltranstbl(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT49;

#line 385 "trlunit.m"
int i,n=(self->selcltn)?(objcT49=self->selcltn,(*(unsigned(*)(id,SEL))_imp(objcT49,selTransTbl[12]))(objcT49,selTransTbl[12])):0;

gs("static char *_selTransTbl[] ={\n");
for(i=0;i<n;i++){
id objcT50,objcT51;

#line 389 "trlunit.m"
STR s=(objcT50=(objcT51=self->selcltn,(*(id(*)(id,SEL,unsigned))_imp(objcT51,selTransTbl[17]))(objcT51,selTransTbl[17],i)),(*(STR(*)(id,SEL))_imp(objcT50,selTransTbl[18]))(objcT50,selTransTbl[18]));

gf("\"%s\",\n",s);
}

gs("0\n};\n");
return(id)self;
}

static id i_TranslationUnit_genfwdstubs(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT52;

#line 400 "trlunit.m"
int i,n;
#line 405 "trlunit.m"
n=(self->fwdcltn)?(objcT52=self->fwdcltn,(*(unsigned(*)(id,SEL))_imp(objcT52,selTransTbl[12]))(objcT52,selTransTbl[12])):0;
for(i=0;i<n;i++){
id objcT53,objcT54,objcT55,objcT56;

#line 407 "trlunit.m"
id msg=(objcT53=self->fwdcltn,(*(id(*)(id,SEL,unsigned))_imp(objcT53,selTransTbl[17]))(objcT53,selTransTbl[17],i));

(objcT54=msg,(*_imp(objcT54,selTransTbl[20]))(objcT54,selTransTbl[20]));
(objcT55=msg,(*_imp(objcT55,selTransTbl[21]))(objcT55,selTransTbl[21]));
(objcT56=msg,(*_imp(objcT56,selTransTbl[22]))(objcT56,selTransTbl[22]));
}
return(id)self;
}

static id i_TranslationUnit_genfwdtranstbl(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT57;

#line 418 "trlunit.m"
int i,n;

n=(self->fwdcltn)?(objcT57=self->fwdcltn,(*(unsigned(*)(id,SEL))_imp(objcT57,selTransTbl[12]))(objcT57,selTransTbl[12])):0;

if(o_cplus){
gs("static id (*(_fwdTransTbl[]))(...) ={\n");
}else{
gs("static id (*(_fwdTransTbl[]))() ={\n");
}

for(i=0;i<n;i++){
id objcT58,objcT59;

#line 429 "trlunit.m"
char*s=(objcT58=(objcT59=self->fwdcltn,(*(id(*)(id,SEL,unsigned))_imp(objcT59,selTransTbl[17]))(objcT59,selTransTbl[17],i)),(*(char*(*)(id,SEL))_imp(objcT58,selTransTbl[23]))(objcT58,selTransTbl[23]));

if(o_cplus){
gf("(id(*)(...))%s,\n",s);
}else{
gf("(id(*)())%s,\n",s);
}
}


if(o_cplus){
gs("(id(*)(...))0\n};\n");
}else{
gs("(id(*)())0\n};\n");
}

return(id)self;
}

#line 454 "trlunit.m"
static id i_TranslationUnit_genmoddesc(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT60;

#line 456 "trlunit.m"
int selsize=(self->selcltn)?(objcT60=self->selcltn,(*(unsigned(*)(id,SEL))_imp(objcT60,selTransTbl[12]))(objcT60,selTransTbl[12])):0;
long modstatus=(self->clsimpls)?0x4L:0;
#line 462 "trlunit.m"
gf("struct modDescriptor %s = {\n",self->moddescname);
gf("  \"%s\",\n",self->modname);
gf("  \"%s\",\n",self->modversion);
gf("  %iL,\n",modstatus);

gs("  0,\n");
gs("  0,\n");
if(self->clsimpl){
id objcT61;
char*cname=(objcT61=self->clsimpl,(*(char*(*)(id,SEL))_imp(objcT61,selTransTbl[19]))(objcT61,selTransTbl[19]));

gf("  &%s,\n",cname);
}else{
if(self->clsimpls){
id objcT62;
assert((objcT62=self->clsimpls,(*(unsigned(*)(id,SEL))_imp(objcT62,selTransTbl[12]))(objcT62,selTransTbl[12]))>=2);
gs("  _modClsLst,\n");
}else{
gs("  0,\n");
}
}
if(selsize){
gf("  %i,\n",selsize);
gs("  _selTransTbl,\n");
}else{
gs("  0,\n");
gs("  0,\n");
}


gs("  0\n};\n");
return(id)self;
}

static id i_TranslationUnit_genglobfuncall(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT63,objcT64;

#line 498 "trlunit.m"
id all=(objcT63=(id)self,(*_imp(objcT63,selTransTbl[24]))(objcT63,selTransTbl[24]));

if(all)
(objcT64=all,(*(id(*)(id,SEL,SEL))_imp(objcT64,selTransTbl[25]))(objcT64,selTransTbl[25],selTransTbl[26]));
return(id)self;
}

static id i_TranslationUnit_genbindfun(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT65;
gf("struct modDescriptor %s*%s(void)\n{\n",o_bind,self->bindfunname);
gs("  selTransTbl = _selTransTbl;\n");
if(o_fwd){
gs("  fwdTransTbl = _fwdTransTbl;\n");
}

if( !o_shareddata)
(objcT65=(id)self,(*_imp(objcT65,selTransTbl[26]))(objcT65,selTransTbl[26]));
gf("  return &%s;\n}\n",self->moddescname);
return(id)self;
}

#line 34 "../../include/objpak/set.h"
extern id  Set;

#line 520 "trlunit.m"
static id i_TranslationUnit_usesentry_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id name)
{
id objcT66,objcT67;

#line 522 "trlunit.m"
if( !self->usesentries)self->
usesentries=(objcT66=Set,(*_imp(objcT66,selTransTbl[3]))(objcT66,selTransTbl[3]));
#line 528 "trlunit.m"
(objcT67=self->usesentries,(*_imp(objcT67,selTransTbl[11]))(objcT67,selTransTbl[11],name));
return(id)self;
}

static id i_TranslationUnit_definesentry_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id name)
{
id objcT68,objcT69;

#line 534 "trlunit.m"
if( !self->definesentries)self->
definesentries=(objcT68=Set,(*_imp(objcT68,selTransTbl[3]))(objcT68,selTransTbl[3]));
#line 540 "trlunit.m"
(objcT69=self->definesentries,(*_imp(objcT69,selTransTbl[11]))(objcT69,selTransTbl[11],name));
return(id)self;
}

static BOOL i_TranslationUnit_definesmain(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT70;

#line 546 "trlunit.m"
return(objcT70=self->definesentries,(*(BOOL(*)(id,SEL,id))_imp(objcT70,selTransTbl[27]))(objcT70,selTransTbl[27],s_main));
}

static id i_TranslationUnit_genusesentries(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT71,objcT72;

#line 551 "trlunit.m"
id seq,entry;

if(o_comments){
gs("/* Objective C Use (OCU) entries */\n");
}
seq=(objcT71=self->usesentries,(*_imp(objcT71,selTransTbl[28]))(objcT71,selTransTbl[28]));
while((entry=(objcT72=seq,(*_imp(objcT72,selTransTbl[29]))(objcT72,selTransTbl[29])))){
id objcT73;

#line 558 "trlunit.m"
char*s=(objcT73=entry,(*(STR(*)(id,SEL))_imp(objcT73,selTransTbl[18]))(objcT73,selTransTbl[18]));
#line 562 "trlunit.m"
gf("struct useDescriptor *OCU_%s;\n",s);
}
return(id)self;
}

static id i_TranslationUnit_genusecontrol(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT74,objcT75;

#line 569 "trlunit.m"
id seq,entry;

gs("static struct useDescriptor **_useControl[] = {\n");

seq=(objcT74=self->usesentries,(*_imp(objcT74,selTransTbl[28]))(objcT74,selTransTbl[28]));
while((entry=(objcT75=seq,(*_imp(objcT75,selTransTbl[29]))(objcT75,selTransTbl[29])))){
id objcT76;

#line 575 "trlunit.m"
char*s=(objcT76=entry,(*(STR(*)(id,SEL))_imp(objcT76,selTransTbl[18]))(objcT76,selTransTbl[18]));

gf("  &OCU_%s,\n",s);
}
gs("0};\n");
gs("static struct useDescriptor _useDesc = {\n");
gs("  0,\n");
gs("  0,\n");
gs("  _useControl,\n");
gf("  %s",self->bindfunname);
gs("\n};\n");

return(id)self;
}

static id i_TranslationUnit_gendefinesentries(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT77,objcT78,objcT80;

#line 592 "trlunit.m"
id seq,entry;

if(o_comments)
gs("/* Objective C Use (OCU) defines */\n");

seq=(objcT77=self->definesentries,(*_imp(objcT77,selTransTbl[28]))(objcT77,selTransTbl[28]));
while((entry=(objcT78=seq,(*_imp(objcT78,selTransTbl[29]))(objcT78,selTransTbl[29])))){
id objcT79;

#line 599 "trlunit.m"
char*s=(objcT79=entry,(*(STR(*)(id,SEL))_imp(objcT79,selTransTbl[18]))(objcT79,selTransTbl[18]));

gf("struct useDescriptor *OCU_%s = &_useDesc;\n",s);
}
#line 606 "trlunit.m"
if((objcT80=(id)self,(*(BOOL(*)(id,SEL))_imp(objcT80,selTransTbl[30]))(objcT80,selTransTbl[30]))&&(strcmp(o_mainfun,"main"))){
gf("\nstruct useDescriptor *OCU_main=&_useDesc;\n");
}
return(id)self;
}

static id i_TranslationUnit_genocu(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT81,objcT82,objcT83,objcT84;

#line 614 "trlunit.m"
gs("struct useDescriptor {\n");
gs("  int processed;\n");
gs("  struct useDescriptor *next;\n");
gs("  struct useDescriptor ***uses;\n");
gs("  struct modDescriptor *(*bind)();\n");
gs("};\n");

(objcT81=(id)self,(*_imp(objcT81,selTransTbl[31]))(objcT81,selTransTbl[31]));
(objcT82=(id)self,(*_imp(objcT82,selTransTbl[32]))(objcT82,selTransTbl[32]));
(objcT83=(id)self,(*_imp(objcT83,selTransTbl[33]))(objcT83,selTransTbl[33]));
#line 629 "trlunit.m"
if((objcT84=(id)self,(*(BOOL(*)(id,SEL))_imp(objcT84,selTransTbl[30]))(objcT84,selTransTbl[30]))){
gs("struct modEntry *_objcModules = 0;\n");
}
return(id)self;
}

static id i_TranslationUnit_postlinkmark(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT85;

#line 644 "trlunit.m"
gf("int _OBJCPOSTLINK_%s = 1;\n",self->modname);
if((objcT85=(id)self,(*(BOOL(*)(id,SEL))_imp(objcT85,selTransTbl[30]))(objcT85,selTransTbl[30]))){
gs("struct useDescriptor *OCU_main = 0;\n");
}
return(id)self;
}

static id i_TranslationUnit_otbmark(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
gf("int _OBJCOTB_%s = 1;\n",self->modname);
return(id)self;
}

static id i_TranslationUnit_epilogue(struct TranslationUnit_PRIVATE *self,SEL _cmd)
{
id objcT87,objcT94,objcT95;

#line 659 "trlunit.m"
id e;

o_nolinetags++;

if(curclassdef){
id objcT86;

#line 664 "trlunit.m"
(objcT86=curclassdef,(*_imp(objcT86,selTransTbl[34]))(objcT86,selTransTbl[34]));
}
if(o_comments){
gs("\n/* objc epilogue */\n");
}else{
gc('\n');
}

if((e=(objcT87=(id)self,(*_imp(objcT87,selTransTbl[24]))(objcT87,selTransTbl[24])))){
id objcT88;

#line 673 "trlunit.m"
(objcT88=e,(*(id(*)(id,SEL,SEL))_imp(objcT88,selTransTbl[25]))(objcT88,selTransTbl[25],selTransTbl[35]));
}
if(o_fwd){
id objcT89,objcT90,objcT91;

#line 676 "trlunit.m"
(objcT89=(id)self,(*_imp(objcT89,selTransTbl[36]))(objcT89,selTransTbl[36]));
(objcT90=(id)self,(*_imp(objcT90,selTransTbl[37]))(objcT90,selTransTbl[37]));
(objcT91=(id)self,(*_imp(objcT91,selTransTbl[38]))(objcT91,selTransTbl[38]));
}else{
id objcT92;

#line 680 "trlunit.m"
(objcT92=(id)self,(*_imp(objcT92,selTransTbl[37]))(objcT92,selTransTbl[37]));
}

if(self->clsimpls){
id objcT93;

#line 684 "trlunit.m"
(objcT93=(id)self,(*_imp(objcT93,selTransTbl[39]))(objcT93,selTransTbl[39]));
}
(objcT94=(id)self,(*_imp(objcT94,selTransTbl[40]))(objcT94,selTransTbl[40]));
(objcT95=(id)self,(*_imp(objcT95,selTransTbl[41]))(objcT95,selTransTbl[41]));

if(o_postlink){
id objcT96;

#line 690 "trlunit.m"
(objcT96=(id)self,(*_imp(objcT96,selTransTbl[42]))(objcT96,selTransTbl[42]));
}else{
id objcT97;

#line 692 "trlunit.m"
(objcT97=(id)self,(*_imp(objcT97,selTransTbl[43]))(objcT97,selTransTbl[43]));
}

if(o_otb){
id objcT98;

#line 696 "trlunit.m"
(objcT98=(id)self,(*_imp(objcT98,selTransTbl[44]))(objcT98,selTransTbl[44]));
}
gc('\n');
gc('\n');
o_nolinetags--;
return(id)self;
}

static BOOL i_TranslationUnit_istypeword_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id node)
{
id objcT99,objcT100;

#line 706 "trlunit.m"
if(self->builtintypes!=(id)0&&(objcT99=self->builtintypes,(*_imp(objcT99,selTransTbl[45]))(objcT99,selTransTbl[45],node))!=(id)0)
return(BOOL)1;
if(self->types!=(id)0&&(objcT100=self->types,(*(BOOL(*)(id,SEL,id))_imp(objcT100,selTransTbl[46]))(objcT100,selTransTbl[46],node)))
return(BOOL)1;
return(BOOL)0;
}

static BOOL i_TranslationUnit_isbuiltinfun_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id node)
{
id objcT101;

#line 715 "trlunit.m"
return self->builtinfuns!=(id)0&&(objcT101=self->builtinfuns,(*_imp(objcT101,selTransTbl[45]))(objcT101,selTransTbl[45],node))!=(id)0;
}

static id i_TranslationUnit_defbuiltinfun_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id node)
{
id objcT102,objcT103;

#line 720 "trlunit.m"
if( !self->builtinfuns)self->
builtinfuns=(objcT102=Set,(*_imp(objcT102,selTransTbl[3]))(objcT102,selTransTbl[3]));
(objcT103=self->builtinfuns,(*_imp(objcT103,selTransTbl[11]))(objcT103,selTransTbl[11],node));
return(id)self;
}

static id i_TranslationUnit_defbuiltintype_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id node)
{
id objcT104,objcT105;

#line 728 "trlunit.m"
if( !self->builtintypes)self->
builtintypes=(objcT104=Set,(*_imp(objcT104,selTransTbl[3]))(objcT104,selTransTbl[3]));
(objcT105=self->builtintypes,(*_imp(objcT105,selTransTbl[11]))(objcT105,selTransTbl[11],node));
return(id)self;
}

static id i_TranslationUnit_def_astype_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id node,id aType)
{
id objcT110,objcT111,objcT112,objcT113;

#line 736 "trlunit.m"
if( !self->typedic){
id objcT106,objcT107;
self->
#line 737 "trlunit.m"
typedic=(objcT106=Dictionary,(*_imp(objcT106,selTransTbl[3]))(objcT106,selTransTbl[3]));self->
types=(objcT107=Set,(*_imp(objcT107,selTransTbl[3]))(objcT107,selTransTbl[3]));
}
if(o_debuginfo){
id objcT108,objcT109;

#line 741 "trlunit.m"
fprintf(stderr,"typedef %s as '",(objcT108=node,(*(STR(*)(id,SEL))_imp(objcT108,selTransTbl[18]))(objcT108,selTransTbl[18])));
gstderr();
(objcT109=aType,(*_imp(objcT109,selTransTbl[47]))(objcT109,selTransTbl[47]));
gnormal();
fprintf(stderr,"'\n");
}
(objcT110=self->types,(*_imp(objcT110,selTransTbl[11]))(objcT110,selTransTbl[11],node));
assert((objcT111=aType,(*(BOOL(*)(id,SEL,id))_imp(objcT111,selTransTbl[48]))(objcT111,selTransTbl[48],(id)(objcT112=Type,(*_imp(objcT112,selTransTbl[49]))(objcT112,selTransTbl[49])))));
(objcT113=self->typedic,(*_imp(objcT113,selTransTbl[15]))(objcT113,selTransTbl[15],node,aType));
return(id)self;
}

static id i_TranslationUnit_defenumtor_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id e)
{
id objcT114,objcT115;

#line 755 "trlunit.m"
if( !self->enumtors)self->
enumtors=(objcT114=Set,(*_imp(objcT114,selTransTbl[3]))(objcT114,selTransTbl[3]));
(objcT115=self->enumtors,(*_imp(objcT115,selTransTbl[11]))(objcT115,selTransTbl[11],e));
return(id)self;
}

static id i_TranslationUnit_lookupenumtor_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id sym)
{
id objcT116;

#line 763 "trlunit.m"
return(self->enumtors)?(objcT116=self->enumtors,(*_imp(objcT116,selTransTbl[45]))(objcT116,selTransTbl[45],sym)):(id)0;
}

static id i_TranslationUnit_defstruct_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id e)
{
id objcT117,objcT118;

#line 768 "trlunit.m"
if( !self->structdefs)self->
structdefs=(objcT117=Set,(*_imp(objcT117,selTransTbl[3]))(objcT117,selTransTbl[3]));
(objcT118=self->structdefs,(*_imp(objcT118,selTransTbl[11]))(objcT118,selTransTbl[11],e));
return(id)self;
}

static id i_TranslationUnit_lookupstruct_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id e)
{
id objcT119;

#line 776 "trlunit.m"
return(self->structdefs)?(objcT119=self->structdefs,(*_imp(objcT119,selTransTbl[45]))(objcT119,selTransTbl[45],e)):(id)0;
}

static id i_TranslationUnit_lookuptype_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id sym)
{
id objcT120;

#line 781 "trlunit.m"
return(self->typedic)?(objcT120=self->typedic,(*_imp(objcT120,selTransTbl[13]))(objcT120,selTransTbl[13],sym)):(id)0;
}

static id i_TranslationUnit_lookupglobal_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id sym)
{
id objcT121;

#line 786 "trlunit.m"
return(self->globaldic)?(objcT121=self->globaldic,(*_imp(objcT121,selTransTbl[13]))(objcT121,selTransTbl[13],sym)):(id)0;
}

static id i_TranslationUnit_defdata_astype_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id node,id aType)
{
id objcT124,objcT125,objcT126,objcT127;

#line 791 "trlunit.m"
if( !self->globaldic){
id objcT122,objcT123;
self->
#line 792 "trlunit.m"
globaldic=(objcT122=Dictionary,(*_imp(objcT122,selTransTbl[3]))(objcT122,selTransTbl[3]));self->
globals=(objcT123=Set,(*_imp(objcT123,selTransTbl[3]))(objcT123,selTransTbl[3]));
}
(objcT124=self->globals,(*_imp(objcT124,selTransTbl[11]))(objcT124,selTransTbl[11],node));
assert((objcT125=aType,(*(BOOL(*)(id,SEL,id))_imp(objcT125,selTransTbl[48]))(objcT125,selTransTbl[48],(id)(objcT126=Type,(*_imp(objcT126,selTransTbl[49]))(objcT126,selTransTbl[49])))));
(objcT127=self->globaldic,(*_imp(objcT127,selTransTbl[15]))(objcT127,selTransTbl[15],node,aType));
return(id)self;
}

static id i_TranslationUnit_def_asclass_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id sym,id classdef)
{
id objcT128,objcT129;

#line 803 "trlunit.m"
if( !self->classdefs)self->
classdefs=(objcT128=Dictionary,(*_imp(objcT128,selTransTbl[3]))(objcT128,selTransTbl[3]));
(objcT129=self->classdefs,(*_imp(objcT129,selTransTbl[15]))(objcT129,selTransTbl[15],sym,classdef));
return(id)self;
}

static id i_TranslationUnit_lookupclass_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id sym)
{
id objcT130;

#line 811 "trlunit.m"
return(objcT130=self->classdefs,(*_imp(objcT130,selTransTbl[13]))(objcT130,selTransTbl[13],sym));
}

static id i_TranslationUnit_lookupmethod_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id sel)
{
id objcT131;

#line 816 "trlunit.m"
return(objcT131=self->methods,(*_imp(objcT131,selTransTbl[13]))(objcT131,selTransTbl[13],sel));
}

static id i_TranslationUnit_def_asmethod_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id sel,id method)
{
id objcT132,objcT133;

#line 821 "trlunit.m"
if( !self->methods)self->
methods=(objcT132=Dictionary,(*_imp(objcT132,selTransTbl[3]))(objcT132,selTransTbl[3]));
(objcT133=self->methods,(*_imp(objcT133,selTransTbl[15]))(objcT133,selTransTbl[15],sel,method));
return(id)self;
}

static id i_TranslationUnit_addgentype_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id s)
{
id objcT134,objcT135;

#line 829 "trlunit.m"
if( !self->gentypes)self->
gentypes=(objcT134=Set,(*_imp(objcT134,selTransTbl[3]))(objcT134,selTransTbl[3]));
(objcT135=self->gentypes,(*_imp(objcT135,selTransTbl[11]))(objcT135,selTransTbl[11],s));
return(id)self;
}

static BOOL i_TranslationUnit_isgentype_(struct TranslationUnit_PRIVATE *self,SEL _cmd,id s)
{
id objcT136;

#line 837 "trlunit.m"
return(objcT136=self->gentypes,(*(BOOL(*)(id,SEL,id))_imp(objcT136,selTransTbl[46]))(objcT136,selTransTbl[46],s));
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Node;
extern struct _SHARED _Node;
extern struct _SHARED __Node;
static struct _SLT _TranslationUnit_clsDispatchTbl[] ={
{"new",(id (*)())c_TranslationUnit_new},
{(char*)0,(id (*)())0}
};
static struct _SLT _TranslationUnit_nstDispatchTbl[] ={
{"msgcount",(id (*)())i_TranslationUnit_msgcount},
{"gettmpvar",(id (*)())i_TranslationUnit_gettmpvar},
{"icachecount",(id (*)())i_TranslationUnit_icachecount},
{"blockcount",(id (*)())i_TranslationUnit_blockcount},
{"heapvarcount",(id (*)())i_TranslationUnit_heapvarcount},
{"returnlabel",(id (*)())i_TranslationUnit_returnlabel},
{"usingselfassign",(id (*)())i_TranslationUnit_usingselfassign},
{"usingselfassign:",(id (*)())i_TranslationUnit_usingselfassign_},
{"usingblocks",(id (*)())i_TranslationUnit_usingblocks},
{"usingblocks:",(id (*)())i_TranslationUnit_usingblocks_},
{"inlinecacheprologue",(id (*)())i_TranslationUnit_inlinecacheprologue},
{"setmodversion:",(id (*)())i_TranslationUnit_setmodversion_},
{"setmodname:",(id (*)())i_TranslationUnit_setmodname_},
{"moddescname",(id (*)())i_TranslationUnit_moddescname},
{"checkbindprologue",(id (*)())i_TranslationUnit_checkbindprologue},
{"prologue",(id (*)())i_TranslationUnit_prologue},
{"allclsimpls",(id (*)())i_TranslationUnit_allclsimpls},
{"addclsimpl:",(id (*)())i_TranslationUnit_addclsimpl_},
{"seloffset:",(id (*)())i_TranslationUnit_seloffset_},
{"fwdoffset:",(id (*)())i_TranslationUnit_fwdoffset_},
{"genmodclslst",(id (*)())i_TranslationUnit_genmodclslst},
{"genseltranstbl",(id (*)())i_TranslationUnit_genseltranstbl},
{"genfwdstubs",(id (*)())i_TranslationUnit_genfwdstubs},
{"genfwdtranstbl",(id (*)())i_TranslationUnit_genfwdtranstbl},
{"genmoddesc",(id (*)())i_TranslationUnit_genmoddesc},
{"genglobfuncall",(id (*)())i_TranslationUnit_genglobfuncall},
{"genbindfun",(id (*)())i_TranslationUnit_genbindfun},
{"usesentry:",(id (*)())i_TranslationUnit_usesentry_},
{"definesentry:",(id (*)())i_TranslationUnit_definesentry_},
{"definesmain",(id (*)())i_TranslationUnit_definesmain},
{"genusesentries",(id (*)())i_TranslationUnit_genusesentries},
{"genusecontrol",(id (*)())i_TranslationUnit_genusecontrol},
{"gendefinesentries",(id (*)())i_TranslationUnit_gendefinesentries},
{"genocu",(id (*)())i_TranslationUnit_genocu},
{"postlinkmark",(id (*)())i_TranslationUnit_postlinkmark},
{"otbmark",(id (*)())i_TranslationUnit_otbmark},
{"epilogue",(id (*)())i_TranslationUnit_epilogue},
{"istypeword:",(id (*)())i_TranslationUnit_istypeword_},
{"isbuiltinfun:",(id (*)())i_TranslationUnit_isbuiltinfun_},
{"defbuiltinfun:",(id (*)())i_TranslationUnit_defbuiltinfun_},
{"defbuiltintype:",(id (*)())i_TranslationUnit_defbuiltintype_},
{"def:astype:",(id (*)())i_TranslationUnit_def_astype_},
{"defenumtor:",(id (*)())i_TranslationUnit_defenumtor_},
{"lookupenumtor:",(id (*)())i_TranslationUnit_lookupenumtor_},
{"defstruct:",(id (*)())i_TranslationUnit_defstruct_},
{"lookupstruct:",(id (*)())i_TranslationUnit_lookupstruct_},
{"lookuptype:",(id (*)())i_TranslationUnit_lookuptype_},
{"lookupglobal:",(id (*)())i_TranslationUnit_lookupglobal_},
{"defdata:astype:",(id (*)())i_TranslationUnit_defdata_astype_},
{"def:asclass:",(id (*)())i_TranslationUnit_def_asclass_},
{"lookupclass:",(id (*)())i_TranslationUnit_lookupclass_},
{"lookupmethod:",(id (*)())i_TranslationUnit_lookupmethod_},
{"def:asmethod:",(id (*)())i_TranslationUnit_def_asmethod_},
{"addgentype:",(id (*)())i_TranslationUnit_addgentype_},
{"isgentype:",(id (*)())i_TranslationUnit_isgentype_},
{(char*)0,(id (*)())0}
};
id TranslationUnit = (id)&_TranslationUnit;
id  *OBJCCLASS_TranslationUnit(void) { return &TranslationUnit; }
struct _SHARED  _TranslationUnit = {
  (id)&__TranslationUnit,
  (id)&_Node,
  "TranslationUnit",
  0,
  sizeof(struct TranslationUnit_PRIVATE),
  55,
  _TranslationUnit_nstDispatchTbl,
  41,
  &trlunit_modDesc,
  0,
  (id)0,
  &TranslationUnit,
};
id  OBJCCFUNC_TranslationUnit(void) { return (id)&_TranslationUnit; }
id  OBJCCSUPER_TranslationUnit(void) { return _TranslationUnit.clsSuper; }
struct _SHARED __TranslationUnit = {
  (id)&__Object,
  (id)&__Node,
  "TranslationUnit",
  0,
  sizeof(struct _SHARED),
  1,
  _TranslationUnit_clsDispatchTbl,
  34,
  &trlunit_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_TranslationUnit(void) { return (id)&__TranslationUnit; }
id  OBJCMSUPER_TranslationUnit(void) { return __TranslationUnit.clsSuper; }
static char *_selTransTbl[] ={
"commonsymbols",
"commontypes",
"commonexprs",
"new",
"sprintf:",
"msgcount",
"str:",
"strCopy",
"genshartype",
"inlinecacheprologue",
"checkbindprologue",
"add:",
"size",
"atKey:",
"asInt",
"atKey:put:",
"selector",
"at:",
"str",
"classname",
"genargstruct",
"gendispfun",
"genfwdstub",
"fwdname",
"allclsimpls",
"elementsPerform:",
"genglobfuncall",
"contains:",
"eachElement",
"next",
"definesmain",
"genusesentries",
"genusecontrol",
"gendefinesentries",
"warnpending",
"genimpl",
"genfwdstubs",
"genseltranstbl",
"genfwdtranstbl",
"genmodclslst",
"genmoddesc",
"genbindfun",
"postlinkmark",
"genocu",
"otbmark",
"find:",
"includes:",
"gen",
"isKindOf:",
"class",
0
};
struct modDescriptor trlunit_modDesc = {
  "trlunit",
  "objc2.3.1",
  0L,
  0,
  0,
  &TranslationUnit,
  50,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_trlunit(void)
{
  selTransTbl = _selTransTbl;
  return &trlunit_modDesc;
}
int _OBJCPOSTLINK_trlunit = 1;


