#line 1 "sortcltn.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_sortcltn(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor sortcltn_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 31 "sortcltn.h"
typedef struct objbbt
{
struct objbbt*ulink;
struct objbbt*rlink;
struct objbbt*llink;
int balance;
id key;
}*
objbbt_t;
#line 28 "set.h"
typedef struct objset
{
int count;
int capacity;
id*ptr;
}*
objset_t;
#line 31 "ordcltn.h"
typedef struct objcol
{
int count;
int capacity;
id*ptr;
}*
objcol_t;
#line 32 "ocstring.h"
typedef struct objstr
{
int count;
int capacity;
char*ptr;
}*
objstr_t;
#line 38 "../../include/objcrt/Block.h"
extern id newBlock(int n,IMP fn,void*data,IMP dtor);
#line 41 "sortcltn.h"
struct SortCltn_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 43 "sortcltn.h"
struct objbbt value;
SEL cmpSel;
id cmpBlk;};

#line 41 "sortcltn.h"
extern id  SortCltn;

#line 41 "sortcltn.h"
extern struct _SHARED _SortCltn;
extern struct _SHARED __SortCltn;


#line 48 "sortcltn.m"
static objbbt_t alloc()
{
return(objbbt_t)OC_Malloc(sizeof(struct objbbt));
}

static objbbt_t init(objbbt_t self,id key)
{
self->ulink=NULL;
self->llink=NULL;
self->rlink=NULL;
self->key=key;
self->balance=0;
return self;
}

static objbbt_t create(id key)
{
return init(alloc(),key);
}

static int signum(objbbt_t ulink,objbbt_t self)
{
assert(ulink->llink==self||ulink->rlink==self);
return(ulink->llink==self)? -1: +1;
}

static objbbt_t slink(objbbt_t self,int sign)
{
assert(sign== +1||sign== -1);return(sign>0)?self->rlink:self->llink;
}

static void setllink(objbbt_t self,objbbt_t node)
{
self->llink=node;if(node)node->ulink=self;
}

static void setrlink(objbbt_t self,objbbt_t node)
{
self->rlink=node;if(node)node->ulink=self;
}

static void setslink(objbbt_t self,objbbt_t node,int sign)
{
if(sign>0)setrlink(self,node);else setllink(self,node);
}

static void freeobjects(objbbt_t self)
{
id objcT0;

#line 96 "sortcltn.m"
if(self->llink)freeobjects(self->llink);
if(self->rlink)freeobjects(self->rlink);
self->key=(objcT0=self->key,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
}

static objbbt_t destroy(objbbt_t self)
{
if(self->llink)self->llink=destroy(self->llink);
if(self->rlink)self->rlink=destroy(self->rlink);
self->key=(id)0;
OC_Free(self);return NULL;
}

static id c_SortCltn_new(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT1;

#line 111 "sortcltn.m"
return(objcT1=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1],selTransTbl[2]));
}

static id c_SortCltn_new_(struct SortCltn_PRIVATE *self,SEL _cmd,unsigned n)
{
id objcT2;

#line 116 "sortcltn.m"
return(objcT2=(id)self,(*_imp(objcT2,selTransTbl[3]))(objcT2,selTransTbl[3]));
}

static id c_SortCltn_newDictCompare(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT3;

#line 121 "sortcltn.m"
return(objcT3=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT3,selTransTbl[1]))(objcT3,selTransTbl[1],selTransTbl[4]));
}

static id i_SortCltn_setupcmpblock_(struct SortCltn_PRIVATE *self,SEL _cmd,id sortBlock)
{self->
cmpBlk=sortBlock;
init( &self->value,(id)0xdeadbeaf);
return(id)self;
}

#line 138 "sortcltn.m"
static id c_SortCltn_sortBy_(struct SortCltn_PRIVATE *self,SEL _cmd,id sortBlock)
{
id objcT4,objcT5;
id newObj=(objcT4=__SortCltn.clsSuper,(*_impSuper(objcT4,selTransTbl[3]))((id)self,selTransTbl[3]));(objcT5=newObj,(*_imp(objcT5,selTransTbl[5]))(objcT5,selTransTbl[5],sortBlock));return newObj;
#line 145 "sortcltn.m"
}

static id c_SortCltn_sortBlock_(struct SortCltn_PRIVATE *self,SEL _cmd,id sortBlock)
{
id objcT6;

#line 149 "sortcltn.m"
return(objcT6=(id)self,(*_imp(objcT6,selTransTbl[6]))(objcT6,selTransTbl[6],sortBlock));
}

static id i_SortCltn_setupcmpsel_(struct SortCltn_PRIVATE *self,SEL _cmd,SEL aSel)
{self->
cmpSel=aSel;
init( &self->value,(id)0);
return(id)self;
}

static id c_SortCltn_newCmpSel_(struct SortCltn_PRIVATE *self,SEL _cmd,SEL aSel)
{
id objcT7,objcT8;

#line 161 "sortcltn.m"
id newObj=(objcT7=__SortCltn.clsSuper,(*_impSuper(objcT7,selTransTbl[3]))((id)self,selTransTbl[3]));(objcT8=newObj,(*(id(*)(id,SEL,SEL))_imp(objcT8,selTransTbl[7]))(objcT8,selTransTbl[7],aSel));return newObj;
}

#line 170 "sortcltn.m"
static id c_SortCltn_with_(struct SortCltn_PRIVATE *self,SEL _cmd,int nArgs,...)
{
id objcT9;

#line 172 "sortcltn.m"
id newObject;


va_list vp;

newObject=(objcT9=(id)self,(*_imp(objcT9,selTransTbl[3]))(objcT9,selTransTbl[3]));
#line 192 "sortcltn.m"
va_start(vp,nArgs);
while(nArgs-->0){
id objcT10;

#line 194 "sortcltn.m"
id anObject=va_arg(vp,id);
(objcT10=newObject,(*_imp(objcT10,selTransTbl[8]))(objcT10,selTransTbl[8],anObject));
}
va_end(vp);


return newObject;
}

static id c_SortCltn_with_with_(struct SortCltn_PRIVATE *self,SEL _cmd,id firstObject,id nextObject)
{
id objcT11,objcT12,objcT13;

#line 205 "sortcltn.m"
return(objcT11=(objcT12=(objcT13=(id)self,(*_imp(objcT13,selTransTbl[3]))(objcT13,selTransTbl[3])),(*_imp(objcT12,selTransTbl[8]))(objcT12,selTransTbl[8],firstObject)),(*_imp(objcT11,selTransTbl[8]))(objcT11,selTransTbl[8],nextObject));
}

static id c_SortCltn_add_(struct SortCltn_PRIVATE *self,SEL _cmd,id firstObject)
{
id objcT14,objcT15;

#line 210 "sortcltn.m"
return(objcT14=(objcT15=(id)self,(*_imp(objcT15,selTransTbl[3]))(objcT15,selTransTbl[3])),(*_imp(objcT14,selTransTbl[8]))(objcT14,selTransTbl[8],firstObject));
}

static id i_SortCltn_copy(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT16,objcT17;

#line 215 "sortcltn.m"
return(objcT16=(objcT17=self->isa,(*_imp(objcT17,selTransTbl[3]))(objcT17,selTransTbl[3])),(*_imp(objcT16,selTransTbl[9]))(objcT16,selTransTbl[9],(id)self));
}

static id i_SortCltn_deepCopy(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT18,objcT19,objcT20,objcT21,objcT22;
id objcT23;

#line 220 "sortcltn.m"
id aSeq,elt;
id aCopy=(objcT18=self->isa,(*_imp(objcT18,selTransTbl[3]))(objcT18,selTransTbl[3]));

aSeq=(objcT19=(id)self,(*_imp(objcT19,selTransTbl[10]))(objcT19,selTransTbl[10]));
while((elt=(objcT20=aSeq,(*_imp(objcT20,selTransTbl[11]))(objcT20,selTransTbl[11]))))(objcT21=aCopy,(*_imp(objcT21,selTransTbl[8]))(objcT21,selTransTbl[8],(objcT22=elt,(*_imp(objcT22,selTransTbl[12]))(objcT22,selTransTbl[12]))));
aSeq=(objcT23=aSeq,(*_imp(objcT23,selTransTbl[0]))(objcT23,selTransTbl[0]));

return aCopy;
}

static id i_SortCltn_emptyYourself(struct SortCltn_PRIVATE *self,SEL _cmd)
{
if(self->value.llink)self->value.llink=destroy(self->value.llink);
return(id)self;
}

static id i_SortCltn_freeContents(struct SortCltn_PRIVATE *self,SEL _cmd)
{
if(self->value.llink){
freeobjects(self->value.llink);self->
value.llink=destroy(self->value.llink);
}
return(id)self;
}

static id i_SortCltn_free(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT24;

#line 247 "sortcltn.m"
if(self->value.llink)self->value.llink=destroy(self->value.llink);
return(objcT24=_SortCltn.clsSuper,(*_impSuper(objcT24,selTransTbl[0]))((id)self,selTransTbl[0]));
}

static id i_SortCltn_release(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT25,objcT26;

#line 253 "sortcltn.m"
(objcT25=(id)self,(*_imp(objcT25,selTransTbl[13]))(objcT25,selTransTbl[13]));
return(objcT26=_SortCltn.clsSuper,(*_impSuper(objcT26,selTransTbl[14]))((id)self,selTransTbl[14]));
}

#line 263 "sortcltn.m"
static objbbt_t i_SortCltn_objbbtTop(struct SortCltn_PRIVATE *self,SEL _cmd)
{
return self->value.llink;
}

static SEL i_SortCltn_comparisonSelector(struct SortCltn_PRIVATE *self,SEL _cmd)
{
return self->cmpSel;
}

static int size(objbbt_t self)
{
int n=1;
if(self->llink)n+=size(self->llink);
if(self->rlink)n+=size(self->rlink);
return n;
}

static unsigned i_SortCltn_size(struct SortCltn_PRIVATE *self,SEL _cmd)
{
return(self->value.llink)?size(self->value.llink):0;
}

static BOOL i_SortCltn_isEmpty(struct SortCltn_PRIVATE *self,SEL _cmd)
{
return self->value.llink==NULL;
}

#line 28 "treeseq.h"
extern id  TreeSequence;

#line 35 "sequence.h"
extern id  Sequence;

#line 291 "sortcltn.m"
static id i_SortCltn_eachElement(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT27,objcT28;

#line 293 "sortcltn.m"
id aCarrier=(objcT27=TreeSequence,(*_imp(objcT27,selTransTbl[15]))(objcT27,selTransTbl[15],(id)self));
return(objcT28=Sequence,(*_imp(objcT28,selTransTbl[15]))(objcT28,selTransTbl[15],aCarrier));
}

#line 303 "sortcltn.m"
static unsigned i_SortCltn_hash(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT29;

#line 305 "sortcltn.m"
(objcT29=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT29,selTransTbl[16]))(objcT29,selTransTbl[16],_cmd));return 0;
}

static BOOL i_SortCltn_isEqual_(struct SortCltn_PRIVATE *self,SEL _cmd,id aSort)
{
id objcT30;

#line 310 "sortcltn.m"
(objcT30=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT30,selTransTbl[16]))(objcT30,selTransTbl[16],_cmd));return(BOOL)0;
}

#line 319 "sortcltn.m"
static int cmp(objbbt_t self,id key,SEL cmpSel,id cmpBlk,objbbt_t*offset)
{
int c=0;
objbbt_t link;
id bkey=self->key;

if(cmpBlk){

if(key==bkey){
c=0;
}else{
id objcT31;

#line 330 "sortcltn.m"
c=(objcT31=cmpBlk,(*(int(*)(id,SEL,id,id))_imp(objcT31,selTransTbl[17]))(objcT31,selTransTbl[17],key,bkey));
}

}else{
if(key==bkey){
c=0;
}else{
id objcT32;

#line 337 "sortcltn.m"
c=((int(*)(id,SEL,id))(objcT32=key,(*(IMP(*)(id,SEL,SEL))_imp(objcT32,selTransTbl[18]))(objcT32,selTransTbl[18],cmpSel)))(key,cmpSel,bkey);
}
}

if(c==0){ *offset=self;return c;}
link=(c<0)?self->llink:self->rlink;

return(link)?cmp(link,key,cmpSel,cmpBlk,offset):( *offset=self,c);
}

static int cmpne(objbbt_t self,id key,SEL cmpSel,id cmpBlk,objbbt_t*offset)
{
int c=0;
objbbt_t link;
id bkey=self->key;

if(cmpBlk){

if(key==bkey){
c=0;
}else{
id objcT33;

#line 358 "sortcltn.m"
c=(objcT33=cmpBlk,(*(int(*)(id,SEL,id,id))_imp(objcT33,selTransTbl[17]))(objcT33,selTransTbl[17],key,bkey));
}

}else{
if(key==bkey){
c=0;
}else{
id objcT34;

#line 365 "sortcltn.m"
c=((int(*)(id,SEL,id))(objcT34=key,(*(IMP(*)(id,SEL,SEL))_imp(objcT34,selTransTbl[18]))(objcT34,selTransTbl[18],cmpSel)))(key,cmpSel,bkey);
}
}

if(c==0){c= +1;}
link=(c<0)?self->llink:self->rlink;

return(link)?cmpne(link,key,cmpSel,cmpBlk,offset):( *offset=self,c);
}

static int height(objbbt_t self)
{
if(self){
int a,b;
a=height(self->llink);
b=height(self->rlink);
assert(self->balance==(b-a));
return 1+((a>b)?a:b);
}else{
return 0;
}
}

static objbbt_t bnode(objbbt_t top,objbbt_t newp)
{
while(newp!=top&&newp->balance==0)newp=newp->ulink;
assert(newp->balance!=0||newp==top);
return newp;
}

static int adjust(objbbt_t b,objbbt_t newp)
{
int sign=0;
objbbt_t ulink;

while(1){
ulink=newp->ulink;
sign=signum(ulink,newp);
if(ulink==b)break;
assert(ulink->balance==0);ulink->balance=sign;newp=ulink;
}

return sign;
}

#line 420 "sortcltn.m"
static void sglrot(objbbt_t A,objbbt_t B,int sign)
{
objbbt_t U=A->ulink;
setslink(A,slink(B, -sign),sign);
setslink(B,A, -sign);
A->balance=0;B->balance=0;
setslink(U,B,signum(U,A));
}

#line 440 "sortcltn.m"
static void dblrot(objbbt_t A,objbbt_t B,int sign)
{
objbbt_t U=A->ulink;
objbbt_t X=slink(B, -sign);

setslink(B,slink(X,sign), -sign);
setslink(X,B, +sign);
setslink(A,slink(X, -sign),sign);
setslink(X,A, -sign);

if(X->balance== +sign){A->balance= -sign;B->balance=0;}
if(X->balance==0){A->balance=0;B->balance=0;}
if(X->balance== -sign){A->balance=0;B->balance= +sign;}

X->balance=0;setslink(U,X,signum(U,A));
}

static void rot(objbbt_t A,int sign)
{
objbbt_t B=slink(A,sign);
assert(sign==A->balance&&sign!=0&&B->balance!=0);

if(sign== +B->balance){sglrot(A,B,sign);return;}
if(sign== -B->balance){dblrot(A,B,sign);return;}
}

static void rebalance(objbbt_t top,objbbt_t newp)
{
int sign;
objbbt_t b;

b=bnode(top,newp);
sign=adjust(b,newp);

if(b->balance==0){b->balance=sign;return;}
if(b->balance== -sign){b->balance=0;return;}
if(b->balance== +sign){rot(b,sign);return;}
}

static void addfirst(objbbt_t self,id key)
{
setllink(self,create(key));
}

static void addat(objbbt_t top,id key,int c,objbbt_t offset)
{
objbbt_t newp=create(key);

assert(c<0||c>0);
if(c<0)setllink(offset,newp);
if(c>0)setrlink(offset,newp);

rebalance(top,newp);
#line 497 "sortcltn.m"
}

static void add(objbbt_t top,id key,SEL selCmp,id cmpBlk)
{
objbbt_t offset=NULL;
int c=cmpne(top,key,selCmp,cmpBlk, &offset);
addat(top,key,c,offset);
}

static id i_SortCltn_add_(struct SortCltn_PRIVATE *self,SEL _cmd,id anObject)
{
if(anObject){
if(self->value.llink){
add(self->value.llink,anObject,self->cmpSel,self->cmpBlk);
return(id)self;
}else{
addfirst( &self->value,anObject);
return(id)self;
}
}else{
return(id)0;
}
}

static id addnfind(objbbt_t top,id key,SEL selCmp,id cmpBlk)
{
objbbt_t offset=NULL;
int c=cmpne(top,key,selCmp,cmpBlk, &offset);
if(c==0){
return offset->key;
}else{
addat(top,key,c,offset);
return key;
}
}

static id i_SortCltn_addNTest_(struct SortCltn_PRIVATE *self,SEL _cmd,id anObject)
{
if(anObject){
if(self->value.llink){
id res=addnfind(self->value.llink,anObject,self->cmpSel,self->cmpBlk);
return(res==anObject)?anObject:(id)0;
}else{
addfirst( &self->value,anObject);
return anObject;
}
}else{
return(id)0;
}
}

static id i_SortCltn_filter_(struct SortCltn_PRIVATE *self,SEL _cmd,id anObject)
{
if(anObject){
if(self->value.llink){
id objcT35;

#line 552 "sortcltn.m"
id res=addnfind(self->value.llink,anObject,self->cmpSel,self->cmpBlk);
return(res==anObject)?anObject:((objcT35=anObject,(*_imp(objcT35,selTransTbl[0]))(objcT35,selTransTbl[0])),res);
}else{
addfirst( &self->value,anObject);
return anObject;
}
}else{
return(id)0;
}
}

static id replace(objbbt_t top,id key,SEL selCmp,id cmpBlk)
{
objbbt_t offset=NULL;
int c=cmpne(top,key,selCmp,cmpBlk, &offset);
if(c==0){
id tmp=offset->key;offset->key=key;return tmp;
}else{
addat(top,key,c,offset);
return(id)0;
}
}

static id i_SortCltn_replace_(struct SortCltn_PRIVATE *self,SEL _cmd,id anObject)
{
if(anObject){
if(self->value.llink){
return replace(self->value.llink,anObject,self->cmpSel,self->cmpBlk);
}else{
addfirst( &self->value,anObject);
return(id)0;
}
}else{
return(id)0;
}
}

#line 595 "sortcltn.m"
static id i_SortCltn_remove_(struct SortCltn_PRIVATE *self,SEL _cmd,id oldObject)
{
if(oldObject){
id objcT36;

#line 598 "sortcltn.m"
return(objcT36=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT36,selTransTbl[16]))(objcT36,selTransTbl[16],_cmd));
}else{
return(id)0;
}
}

#line 610 "sortcltn.m"
static BOOL i_SortCltn_includesAllOf_(struct SortCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
if((id)self==aCltn){
return(BOOL)1;
}else{
id objcT37,objcT38,objcT40;

#line 615 "sortcltn.m"
BOOL res=(BOOL)1;
id e,seq=(objcT37=aCltn,(*_imp(objcT37,selTransTbl[10]))(objcT37,selTransTbl[10]));
while((e=(objcT38=seq,(*_imp(objcT38,selTransTbl[11]))(objcT38,selTransTbl[11])))){
id objcT39;

#line 618 "sortcltn.m"
if( !(objcT39=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT39,selTransTbl[19]))(objcT39,selTransTbl[19],e))){
res=(BOOL)0;goto done;
}
}
done:

(objcT40=seq,(*_imp(objcT40,selTransTbl[0]))(objcT40,selTransTbl[0]));

return res;
}
}

static BOOL i_SortCltn_includesAnyOf_(struct SortCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
if((id)self==aCltn){
return(BOOL)1;
}else{
id objcT41,objcT42,objcT44;

#line 635 "sortcltn.m"
BOOL res=(BOOL)0;
id e,seq=(objcT41=aCltn,(*_imp(objcT41,selTransTbl[10]))(objcT41,selTransTbl[10]));
while((e=(objcT42=seq,(*_imp(objcT42,selTransTbl[11]))(objcT42,selTransTbl[11])))){
id objcT43;

#line 638 "sortcltn.m"
if((objcT43=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT43,selTransTbl[19]))(objcT43,selTransTbl[19],e))){
res=(BOOL)1;goto done;
}
}
done:

(objcT44=seq,(*_imp(objcT44,selTransTbl[0]))(objcT44,selTransTbl[0]));

return res;
}
}

#line 656 "sortcltn.m"
static id i_SortCltn_addAll_(struct SortCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
if((id)self==aCltn){
id objcT45;

#line 659 "sortcltn.m"
(objcT45=(id)self,(*_imp(objcT45,selTransTbl[20]))(objcT45,selTransTbl[20]));
}else{
id objcT46,objcT47,objcT49;

#line 661 "sortcltn.m"
id e,seq;

seq=(objcT46=aCltn,(*_imp(objcT46,selTransTbl[10]))(objcT46,selTransTbl[10]));
while((e=(objcT47=seq,(*_imp(objcT47,selTransTbl[11]))(objcT47,selTransTbl[11])))){
id objcT48;

#line 665 "sortcltn.m"
(objcT48=(id)self,(*_imp(objcT48,selTransTbl[8]))(objcT48,selTransTbl[8],e));
}

seq=(objcT49=seq,(*_imp(objcT49,selTransTbl[0]))(objcT49,selTransTbl[0]));

}

return(id)self;
}

static id i_SortCltn_addContentsOf_(struct SortCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
id objcT50;

#line 677 "sortcltn.m"
return(objcT50=(id)self,(*_imp(objcT50,selTransTbl[9]))(objcT50,selTransTbl[9],aCltn));
}

static id i_SortCltn_addContentsTo_(struct SortCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
id objcT51;

#line 682 "sortcltn.m"
return(objcT51=aCltn,(*_imp(objcT51,selTransTbl[9]))(objcT51,selTransTbl[9],(id)self));
}

static id i_SortCltn_removeAll_(struct SortCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
if((id)self==aCltn){
id objcT52;

#line 688 "sortcltn.m"
(objcT52=(id)self,(*_imp(objcT52,selTransTbl[13]))(objcT52,selTransTbl[13]));
}else{
id objcT53,objcT54,objcT56;

#line 690 "sortcltn.m"
id e,seq;

seq=(objcT53=aCltn,(*_imp(objcT53,selTransTbl[10]))(objcT53,selTransTbl[10]));
while((e=(objcT54=seq,(*_imp(objcT54,selTransTbl[11]))(objcT54,selTransTbl[11])))){
id objcT55;

#line 694 "sortcltn.m"
(objcT55=(id)self,(*_imp(objcT55,selTransTbl[21]))(objcT55,selTransTbl[21],e));
}

seq=(objcT56=seq,(*_imp(objcT56,selTransTbl[0]))(objcT56,selTransTbl[0]));

}

return(id)self;
}

static id i_SortCltn_removeContentsFrom_(struct SortCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
id objcT57;

#line 706 "sortcltn.m"
return(objcT57=aCltn,(*_imp(objcT57,selTransTbl[22]))(objcT57,selTransTbl[22],(id)self));
}

static id i_SortCltn_removeContentsOf_(struct SortCltn_PRIVATE *self,SEL _cmd,id aCltn)
{
id objcT58;

#line 711 "sortcltn.m"
return(objcT58=(id)self,(*_imp(objcT58,selTransTbl[22]))(objcT58,selTransTbl[22],aCltn));
}

#line 720 "sortcltn.m"
static id i_SortCltn_intersection_(struct SortCltn_PRIVATE *self,SEL _cmd,id bag)
{
if((id)self==bag){
id objcT59;

#line 723 "sortcltn.m"
return(objcT59=(id)self,(*_imp(objcT59,selTransTbl[23]))(objcT59,selTransTbl[23]));
}else{
id objcT60,objcT61,objcT62,objcT65;

#line 725 "sortcltn.m"
id anElement,elements;
id intersection=(objcT60=self->isa,(*_imp(objcT60,selTransTbl[3]))(objcT60,selTransTbl[3]));

elements=(objcT61=(id)self,(*_imp(objcT61,selTransTbl[10]))(objcT61,selTransTbl[10]));
while((anElement=(objcT62=elements,(*_imp(objcT62,selTransTbl[11]))(objcT62,selTransTbl[11])))){
id objcT63,objcT64;

#line 730 "sortcltn.m"
if((objcT63=bag,(*_imp(objcT63,selTransTbl[24]))(objcT63,selTransTbl[24],anElement)))(objcT64=intersection,(*_imp(objcT64,selTransTbl[8]))(objcT64,selTransTbl[8],anElement));
}

elements=(objcT65=elements,(*_imp(objcT65,selTransTbl[0]))(objcT65,selTransTbl[0]));


return intersection;
}
}

static id i_SortCltn_union_(struct SortCltn_PRIVATE *self,SEL _cmd,id bag)
{
if((id)self==bag){
id objcT66;

#line 743 "sortcltn.m"
return(objcT66=(id)self,(*_imp(objcT66,selTransTbl[23]))(objcT66,selTransTbl[23]));
}else{
id objcT67,objcT68;

#line 745 "sortcltn.m"
return(objcT67=(objcT68=(id)self,(*_imp(objcT68,selTransTbl[23]))(objcT68,selTransTbl[23])),(*_imp(objcT67,selTransTbl[9]))(objcT67,selTransTbl[9],bag));
}
}

static id i_SortCltn_difference_(struct SortCltn_PRIVATE *self,SEL _cmd,id bag)
{
if((id)self==bag){
id objcT69;

#line 752 "sortcltn.m"
return(objcT69=self->isa,(*_imp(objcT69,selTransTbl[3]))(objcT69,selTransTbl[3]));
}else{
id objcT70,objcT71;

#line 754 "sortcltn.m"
return(objcT70=(objcT71=(id)self,(*_imp(objcT71,selTransTbl[23]))(objcT71,selTransTbl[23])),(*_imp(objcT70,selTransTbl[22]))(objcT70,selTransTbl[22],bag));
}
}

#line 36 "set.h"
extern id  Set;

#line 764 "sortcltn.m"
static id i_SortCltn_asSet(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT72,objcT73;
if((objcT72=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT72,selTransTbl[25]))(objcT72,selTransTbl[25],(id)(objcT73=Set,(*_imp(objcT73,selTransTbl[26]))(objcT73,selTransTbl[26]))))){
return(id)self;
}else{
id objcT74,objcT75;

#line 770 "sortcltn.m"
return(objcT74=(objcT75=Set,(*_imp(objcT75,selTransTbl[3]))(objcT75,selTransTbl[3])),(*_imp(objcT74,selTransTbl[9]))(objcT74,selTransTbl[9],(id)self));
}
}

#line 39 "ordcltn.h"
extern id  OrdCltn;

#line 774 "sortcltn.m"
static id i_SortCltn_asOrdCltn(struct SortCltn_PRIVATE *self,SEL _cmd)
{
id objcT76,objcT77;
if((objcT76=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT76,selTransTbl[25]))(objcT76,selTransTbl[25],(id)(objcT77=OrdCltn,(*_imp(objcT77,selTransTbl[26]))(objcT77,selTransTbl[26]))))){
return(id)self;
}else{
id objcT78,objcT79;

#line 780 "sortcltn.m"
return(objcT78=(objcT79=OrdCltn,(*_imp(objcT79,selTransTbl[3]))(objcT79,selTransTbl[3])),(*_imp(objcT78,selTransTbl[9]))(objcT78,selTransTbl[9],(id)self));
}
}

#line 791 "sortcltn.m"
static id i_SortCltn_detect_(struct SortCltn_PRIVATE *self,SEL _cmd,id aBlock)
{
id objcT80,objcT81,objcT84;

#line 793 "sortcltn.m"
id e,seq;

seq=(objcT80=(id)self,(*_imp(objcT80,selTransTbl[10]))(objcT80,selTransTbl[10]));

while((e=(objcT81=seq,(*_imp(objcT81,selTransTbl[11]))(objcT81,selTransTbl[11])))){
id objcT82;

#line 798 "sortcltn.m"
if(((objcT82=aBlock,(*_imp(objcT82,selTransTbl[27]))(objcT82,selTransTbl[27],e)))){
id objcT83;
seq=(objcT83=seq,(*_imp(objcT83,selTransTbl[0]))(objcT83,selTransTbl[0]));

return e;
}
}


seq=(objcT84=seq,(*_imp(objcT84,selTransTbl[0]))(objcT84,selTransTbl[0]));

return(id)0;
}

static id i_SortCltn_detect_ifNone_(struct SortCltn_PRIVATE *self,SEL _cmd,id aBlock,id noneBlock)
{
id objcT85,objcT86,objcT89,objcT90;

#line 814 "sortcltn.m"
id e,seq;

seq=(objcT85=(id)self,(*_imp(objcT85,selTransTbl[10]))(objcT85,selTransTbl[10]));

while((e=(objcT86=seq,(*_imp(objcT86,selTransTbl[11]))(objcT86,selTransTbl[11])))){
id objcT87;

#line 819 "sortcltn.m"
if(((objcT87=aBlock,(*_imp(objcT87,selTransTbl[27]))(objcT87,selTransTbl[27],e)))){
id objcT88;
seq=(objcT88=seq,(*_imp(objcT88,selTransTbl[0]))(objcT88,selTransTbl[0]));

return e;
}
}


seq=(objcT89=seq,(*_imp(objcT89,selTransTbl[0]))(objcT89,selTransTbl[0]));

return(objcT90=noneBlock,(*_imp(objcT90,selTransTbl[28]))(objcT90,selTransTbl[28]));
}

static id i_SortCltn_select_(struct SortCltn_PRIVATE *self,SEL _cmd,id testBlock)
{
id objcT91,objcT92,objcT93,objcT96;

#line 835 "sortcltn.m"
id e,seq;
id newObject=(objcT91=self->isa,(*_imp(objcT91,selTransTbl[3]))(objcT91,selTransTbl[3]));

seq=(objcT92=(id)self,(*_imp(objcT92,selTransTbl[10]))(objcT92,selTransTbl[10]));

while((e=(objcT93=seq,(*_imp(objcT93,selTransTbl[11]))(objcT93,selTransTbl[11])))){
id objcT94;

#line 841 "sortcltn.m"
if(((objcT94=testBlock,(*_imp(objcT94,selTransTbl[27]))(objcT94,selTransTbl[27],e)))){
id objcT95;

#line 842 "sortcltn.m"
(objcT95=newObject,(*_imp(objcT95,selTransTbl[8]))(objcT95,selTransTbl[8],e));
}
}


seq=(objcT96=seq,(*_imp(objcT96,selTransTbl[0]))(objcT96,selTransTbl[0]));

return newObject;
}

static id i_SortCltn_reject_(struct SortCltn_PRIVATE *self,SEL _cmd,id testBlock)
{
id objcT97,objcT98,objcT99,objcT102;

#line 854 "sortcltn.m"
id e,seq;
id newObject=(objcT97=self->isa,(*_imp(objcT97,selTransTbl[3]))(objcT97,selTransTbl[3]));

seq=(objcT98=(id)self,(*_imp(objcT98,selTransTbl[10]))(objcT98,selTransTbl[10]));

while((e=(objcT99=seq,(*_imp(objcT99,selTransTbl[11]))(objcT99,selTransTbl[11])))){
id objcT100;

#line 860 "sortcltn.m"
if( !((objcT100=testBlock,(*_imp(objcT100,selTransTbl[27]))(objcT100,selTransTbl[27],e)))){
id objcT101;

#line 861 "sortcltn.m"
(objcT101=newObject,(*_imp(objcT101,selTransTbl[8]))(objcT101,selTransTbl[8],e));
}
}


seq=(objcT102=seq,(*_imp(objcT102,selTransTbl[0]))(objcT102,selTransTbl[0]));

return newObject;
}

static id i_SortCltn_collect_(struct SortCltn_PRIVATE *self,SEL _cmd,id transformBlock)
{
id objcT103,objcT104,objcT105,objcT108;

#line 873 "sortcltn.m"
id e,seq;
id newObject=(objcT103=self->isa,(*_imp(objcT103,selTransTbl[3]))(objcT103,selTransTbl[3]));

seq=(objcT104=(id)self,(*_imp(objcT104,selTransTbl[10]))(objcT104,selTransTbl[10]));

while((e=(objcT105=seq,(*_imp(objcT105,selTransTbl[11]))(objcT105,selTransTbl[11])))){
id objcT106;

#line 879 "sortcltn.m"
id anImage=(objcT106=transformBlock,(*_imp(objcT106,selTransTbl[27]))(objcT106,selTransTbl[27],e));
if(anImage){
id objcT107;

#line 881 "sortcltn.m"
(objcT107=newObject,(*_imp(objcT107,selTransTbl[8]))(objcT107,selTransTbl[8],anImage));
}
}


seq=(objcT108=seq,(*_imp(objcT108,selTransTbl[0]))(objcT108,selTransTbl[0]));

return newObject;
}

static unsigned i_SortCltn_count_(struct SortCltn_PRIVATE *self,SEL _cmd,id aBlock)
{
id objcT109,objcT110,objcT112;

#line 893 "sortcltn.m"
id e,seq;
unsigned c=0;

seq=(objcT109=(id)self,(*_imp(objcT109,selTransTbl[10]))(objcT109,selTransTbl[10]));
while((e=(objcT110=seq,(*_imp(objcT110,selTransTbl[11]))(objcT110,selTransTbl[11])))){
id objcT111;

#line 898 "sortcltn.m"
if((objcT111=aBlock,(*_imp(objcT111,selTransTbl[27]))(objcT111,selTransTbl[27],e))){
c++;
}
}

seq=(objcT112=seq,(*_imp(objcT112,selTransTbl[0]))(objcT112,selTransTbl[0]));


return c;
}

#line 917 "sortcltn.m"
static id i_SortCltn_elementsPerform_(struct SortCltn_PRIVATE *self,SEL _cmd,SEL aSelector)
{
id objcT113,objcT114,objcT116;

#line 919 "sortcltn.m"
id e,seq;

seq=(objcT113=(id)self,(*_imp(objcT113,selTransTbl[10]))(objcT113,selTransTbl[10]));
while((e=(objcT114=seq,(*_imp(objcT114,selTransTbl[11]))(objcT114,selTransTbl[11])))){
id objcT115;

#line 923 "sortcltn.m"
(objcT115=e,(*(id(*)(id,SEL,SEL))_imp(objcT115,selTransTbl[29]))(objcT115,selTransTbl[29],aSelector));
}

seq=(objcT116=seq,(*_imp(objcT116,selTransTbl[0]))(objcT116,selTransTbl[0]));


return(id)self;
}

static id i_SortCltn_elementsPerform_with_(struct SortCltn_PRIVATE *self,SEL _cmd,SEL aSelector,id anObject)
{
id objcT117,objcT118,objcT120;

#line 934 "sortcltn.m"
id e,seq;

seq=(objcT117=(id)self,(*_imp(objcT117,selTransTbl[10]))(objcT117,selTransTbl[10]));
while((e=(objcT118=seq,(*_imp(objcT118,selTransTbl[11]))(objcT118,selTransTbl[11])))){
id objcT119;

#line 938 "sortcltn.m"
(objcT119=e,(*(id(*)(id,SEL,SEL,id))_imp(objcT119,selTransTbl[30]))(objcT119,selTransTbl[30],aSelector,anObject));
}

seq=(objcT120=seq,(*_imp(objcT120,selTransTbl[0]))(objcT120,selTransTbl[0]));


return(id)self;
}

static id i_SortCltn_elementsPerform_with_with_(struct SortCltn_PRIVATE *self,SEL _cmd,SEL aSelector,id anObject,id otherObject)
{
id objcT121,objcT122,objcT124;

#line 949 "sortcltn.m"
id e,seq;

seq=(objcT121=(id)self,(*_imp(objcT121,selTransTbl[10]))(objcT121,selTransTbl[10]));
while((e=(objcT122=seq,(*_imp(objcT122,selTransTbl[11]))(objcT122,selTransTbl[11])))){
id objcT123;

#line 953 "sortcltn.m"
(objcT123=e,(*(id(*)(id,SEL,SEL,id,id))_imp(objcT123,selTransTbl[31]))(objcT123,selTransTbl[31],aSelector,anObject,otherObject));
}

seq=(objcT124=seq,(*_imp(objcT124,selTransTbl[0]))(objcT124,selTransTbl[0]));


return(id)self;
}

static id i_SortCltn_elementsPerform_with_with_with_(struct SortCltn_PRIVATE *self,SEL _cmd,SEL aSelector,id anObject,id otherObject,id thirdObj)
{
id objcT125,objcT126,objcT128;

#line 964 "sortcltn.m"
id e,seq;

seq=(objcT125=(id)self,(*_imp(objcT125,selTransTbl[10]))(objcT125,selTransTbl[10]));
while((e=(objcT126=seq,(*_imp(objcT126,selTransTbl[11]))(objcT126,selTransTbl[11])))){
id objcT127;

#line 968 "sortcltn.m"
(objcT127=e,(*(id(*)(id,SEL,SEL,id,id,id))_imp(objcT127,selTransTbl[32]))(objcT127,selTransTbl[32],aSelector,anObject,otherObject,thirdObj));
}

seq=(objcT128=seq,(*_imp(objcT128,selTransTbl[0]))(objcT128,selTransTbl[0]));


return(id)self;
}

#line 983 "sortcltn.m"
static id i_SortCltn_do_(struct SortCltn_PRIVATE *self,SEL _cmd,id aBlock)
{
id objcT129,objcT130,objcT132;

#line 985 "sortcltn.m"
id e,seq;

seq=(objcT129=(id)self,(*_imp(objcT129,selTransTbl[10]))(objcT129,selTransTbl[10]));

while((e=(objcT130=seq,(*_imp(objcT130,selTransTbl[11]))(objcT130,selTransTbl[11])))){
id objcT131;

#line 990 "sortcltn.m"
(objcT131=aBlock,(*_imp(objcT131,selTransTbl[27]))(objcT131,selTransTbl[27],e));
}


seq=(objcT132=seq,(*_imp(objcT132,selTransTbl[0]))(objcT132,selTransTbl[0]));

return(id)self;
}
static id i_SortCltn_do_until_(struct SortCltn_PRIVATE *self,SEL _cmd,id aBlock,BOOL*flag)
{
id objcT133,objcT134,objcT136;

#line 1000 "sortcltn.m"
id e,seq;

seq=(objcT133=(id)self,(*_imp(objcT133,selTransTbl[10]))(objcT133,selTransTbl[10]));

while((e=(objcT134=seq,(*_imp(objcT134,selTransTbl[11]))(objcT134,selTransTbl[11])))){
id objcT135;

#line 1005 "sortcltn.m"
(objcT135=aBlock,(*_imp(objcT135,selTransTbl[27]))(objcT135,selTransTbl[27],e));
if( *flag)break;
}


seq=(objcT136=seq,(*_imp(objcT136,selTransTbl[0]))(objcT136,selTransTbl[0]));

return(id)self;
}

#line 1022 "sortcltn.m"
static id find(objbbt_t self,id key,SEL cmpSel,id cmpBlk)
{
int c;
objbbt_t offset=NULL;

if((c=cmp(self,key,cmpSel,cmpBlk, &offset))){
return(id)0;
}else{
id objcT137;

#line 1030 "sortcltn.m"
assert((objcT137=key,(*(BOOL(*)(id,SEL,id))_imp(objcT137,selTransTbl[33]))(objcT137,selTransTbl[33],offset->key)));return offset->key;
}
}

static id i_SortCltn_find_(struct SortCltn_PRIVATE *self,SEL _cmd,id anObject)
{
if(anObject){
return(self->value.llink)?find(self->value.llink,anObject,self->cmpSel,self->cmpBlk):(id)0;
}else{
return(id)0;
}
}

static BOOL i_SortCltn_contains_(struct SortCltn_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT138;

#line 1045 "sortcltn.m"
return(BOOL)((objcT138=(id)self,(*_imp(objcT138,selTransTbl[24]))(objcT138,selTransTbl[24],anObject))?(BOOL)1:(BOOL)0);
}

#line 1054 "sortcltn.m"
static id i_SortCltn_printOn_(struct SortCltn_PRIVATE *self,SEL _cmd,IOD aFile)
{
id objcT139,objcT140,objcT141;

#line 1056 "sortcltn.m"
id s=(objcT139=(id)self,(*_imp(objcT139,selTransTbl[10]))(objcT139,selTransTbl[10]));(objcT140=s,(*(id(*)(id,SEL,IOD))_imp(objcT140,selTransTbl[34]))(objcT140,selTransTbl[34],aFile));

(objcT141=s,(*_imp(objcT141,selTransTbl[0]))(objcT141,selTransTbl[0]));

return(id)self;
}

#line 1069 "sortcltn.m"
static id i_SortCltn_fileOutOn_(struct SortCltn_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT142;

#line 1071 "sortcltn.m"
return(objcT142=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT142,selTransTbl[16]))(objcT142,selTransTbl[16],_cmd));
}

static id i_SortCltn_fileInFrom_(struct SortCltn_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT143;

#line 1076 "sortcltn.m"
return(objcT143=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT143,selTransTbl[16]))(objcT143,selTransTbl[16],_cmd));
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Cltn;
extern struct _SHARED _Cltn;
extern struct _SHARED __Cltn;
static struct _SLT _SortCltn_clsDispatchTbl[] ={
{"new",(id (*)())c_SortCltn_new},
{"new:",(id (*)())c_SortCltn_new_},
{"newDictCompare",(id (*)())c_SortCltn_newDictCompare},
{"sortBy:",(id (*)())c_SortCltn_sortBy_},
{"sortBlock:",(id (*)())c_SortCltn_sortBlock_},
{"newCmpSel:",(id (*)())c_SortCltn_newCmpSel_},
{"with:",(id (*)())c_SortCltn_with_},
{"with:with:",(id (*)())c_SortCltn_with_with_},
{"add:",(id (*)())c_SortCltn_add_},
{(char*)0,(id (*)())0}
};
static struct _SLT _SortCltn_nstDispatchTbl[] ={
{"setupcmpblock:",(id (*)())i_SortCltn_setupcmpblock_},
{"setupcmpsel:",(id (*)())i_SortCltn_setupcmpsel_},
{"copy",(id (*)())i_SortCltn_copy},
{"deepCopy",(id (*)())i_SortCltn_deepCopy},
{"emptyYourself",(id (*)())i_SortCltn_emptyYourself},
{"freeContents",(id (*)())i_SortCltn_freeContents},
{"free",(id (*)())i_SortCltn_free},
{"release",(id (*)())i_SortCltn_release},
{"objbbtTop",(id (*)())i_SortCltn_objbbtTop},
{"comparisonSelector",(id (*)())i_SortCltn_comparisonSelector},
{"size",(id (*)())i_SortCltn_size},
{"isEmpty",(id (*)())i_SortCltn_isEmpty},
{"eachElement",(id (*)())i_SortCltn_eachElement},
{"hash",(id (*)())i_SortCltn_hash},
{"isEqual:",(id (*)())i_SortCltn_isEqual_},
{"add:",(id (*)())i_SortCltn_add_},
{"addNTest:",(id (*)())i_SortCltn_addNTest_},
{"filter:",(id (*)())i_SortCltn_filter_},
{"replace:",(id (*)())i_SortCltn_replace_},
{"remove:",(id (*)())i_SortCltn_remove_},
{"includesAllOf:",(id (*)())i_SortCltn_includesAllOf_},
{"includesAnyOf:",(id (*)())i_SortCltn_includesAnyOf_},
{"addAll:",(id (*)())i_SortCltn_addAll_},
{"addContentsOf:",(id (*)())i_SortCltn_addContentsOf_},
{"addContentsTo:",(id (*)())i_SortCltn_addContentsTo_},
{"removeAll:",(id (*)())i_SortCltn_removeAll_},
{"removeContentsFrom:",(id (*)())i_SortCltn_removeContentsFrom_},
{"removeContentsOf:",(id (*)())i_SortCltn_removeContentsOf_},
{"intersection:",(id (*)())i_SortCltn_intersection_},
{"union:",(id (*)())i_SortCltn_union_},
{"difference:",(id (*)())i_SortCltn_difference_},
{"asSet",(id (*)())i_SortCltn_asSet},
{"asOrdCltn",(id (*)())i_SortCltn_asOrdCltn},
{"detect:",(id (*)())i_SortCltn_detect_},
{"detect:ifNone:",(id (*)())i_SortCltn_detect_ifNone_},
{"select:",(id (*)())i_SortCltn_select_},
{"reject:",(id (*)())i_SortCltn_reject_},
{"collect:",(id (*)())i_SortCltn_collect_},
{"count:",(id (*)())i_SortCltn_count_},
{"elementsPerform:",(id (*)())i_SortCltn_elementsPerform_},
{"elementsPerform:with:",(id (*)())i_SortCltn_elementsPerform_with_},
{"elementsPerform:with:with:",(id (*)())i_SortCltn_elementsPerform_with_with_},
{"elementsPerform:with:with:with:",(id (*)())i_SortCltn_elementsPerform_with_with_with_},
{"do:",(id (*)())i_SortCltn_do_},
{"do:until:",(id (*)())i_SortCltn_do_until_},
{"find:",(id (*)())i_SortCltn_find_},
{"contains:",(id (*)())i_SortCltn_contains_},
{"printOn:",(id (*)())i_SortCltn_printOn_},
{"fileOutOn:",(id (*)())i_SortCltn_fileOutOn_},
{"fileInFrom:",(id (*)())i_SortCltn_fileInFrom_},
{(char*)0,(id (*)())0}
};
id SortCltn = (id)&_SortCltn;
id  *OBJCCLASS_SortCltn(void) { return &SortCltn; }
struct _SHARED  _SortCltn = {
  (id)&__SortCltn,
  (id)&_Cltn,
  "SortCltn",
  0,
  sizeof(struct SortCltn_PRIVATE),
  50,
  _SortCltn_nstDispatchTbl,
  41,
  &sortcltn_modDesc,
  0,
  (id)0,
  &SortCltn,
};
id  OBJCCFUNC_SortCltn(void) { return (id)&_SortCltn; }
id  OBJCCSUPER_SortCltn(void) { return _SortCltn.clsSuper; }
struct _SHARED __SortCltn = {
  (id)&__Object,
  (id)&__Cltn,
  "SortCltn",
  0,
  sizeof(struct _SHARED),
  9,
  _SortCltn_clsDispatchTbl,
  34,
  &sortcltn_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_SortCltn(void) { return (id)&__SortCltn; }
id  OBJCMSUPER_SortCltn(void) { return __SortCltn.clsSuper; }
static char *_selTransTbl[] ={
"free",
"newCmpSel:",
"compare:",
"new",
"dictCompare:",
"setupcmpblock:",
"sortBy:",
"setupcmpsel:",
"add:",
"addAll:",
"eachElement",
"next",
"deepCopy",
"emptyYourself",
"release",
"over:",
"notImplemented:",
"intvalue:value:",
"methodFor:",
"includes:",
"addYourself",
"remove:",
"removeAll:",
"copy",
"find:",
"isKindOf:",
"class",
"value:",
"value",
"perform:",
"perform:with:",
"perform:with:with:",
"perform:with:with:with:",
"isEqual:",
"printOn:",
0
};
struct modDescriptor sortcltn_modDesc = {
  "sortcltn",
  "objc2.3.1",
  0L,
  0,
  0,
  &SortCltn,
  35,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_sortcltn(void)
{
  selTransTbl = _selTransTbl;
  return &sortcltn_modDesc;
}
int _OBJCPOSTLINK_sortcltn = 1;


