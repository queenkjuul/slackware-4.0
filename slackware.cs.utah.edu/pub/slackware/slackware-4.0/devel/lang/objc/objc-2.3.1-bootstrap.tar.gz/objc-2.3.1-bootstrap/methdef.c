#line 1 "methdef.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_methdef(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor methdef_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "def.h"
extern id curdef;
#line 22 "compstmt.h"
extern id curcompound;
extern id curloopcompound;
#line 22 "classdef.h"
extern id curclassdef;
extern id curstruct;
#line 22 "trlunit.h"
extern id trlunit;
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "expr.h"
extern id e_nil;
extern id e_self;
extern id e_cmd;
extern id e_super;
extern id e_aFiler;
extern id e_ft_id;
#line 22 "methdef.h"
struct MethodDef_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 26 "def.h"
id parmdic;
id heapvars;
id parmnames;
id classreferences;
id blockreferences;
id heapvarblocks;
#line 24 "methdef.h"
BOOL factory;
id method;
id body;
char*impname;
char*selname;
id classdef;};

#line 22 "methdef.h"
extern id  MethodDef;

#line 22 "methdef.h"
extern struct _SHARED _MethodDef;
extern struct _SHARED __MethodDef;


#line 43 "methdef.m"
static BOOL i_MethodDef_factory(struct MethodDef_PRIVATE *self,SEL _cmd)
{
return self->factory;
}

static id i_MethodDef_restype(struct MethodDef_PRIVATE *self,SEL _cmd)
{
id objcT0;

#line 50 "methdef.m"
id r=(objcT0=self->method,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));

return(r)?r:t_id;
}

static BOOL i_MethodDef_ismethdef(struct MethodDef_PRIVATE *self,SEL _cmd)
{
return(BOOL)1;
}

static id i_MethodDef_factory_(struct MethodDef_PRIVATE *self,SEL _cmd,BOOL flag)
{self->
factory=flag;
return(id)self;
}

static char*i_MethodDef_selname(struct MethodDef_PRIVATE *self,SEL _cmd)
{
assert(self->selname!=NULL);
return self->selname;
}

static char*i_MethodDef_impname(struct MethodDef_PRIVATE *self,SEL _cmd)
{
assert(self->impname!=NULL);
return self->impname;
}

static id i_MethodDef_method(struct MethodDef_PRIVATE *self,SEL _cmd)
{
return self->method;
}

static id i_MethodDef_selector(struct MethodDef_PRIVATE *self,SEL _cmd)
{
id objcT1;

#line 85 "methdef.m"
return(objcT1=self->method,(*_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1]));
}

static id i_MethodDef_method_(struct MethodDef_PRIVATE *self,SEL _cmd,id aDecl)
{self->
method=aDecl;
return(id)self;
}

static id i_MethodDef_compound(struct MethodDef_PRIVATE *self,SEL _cmd)
{
return self->body;
}

static id i_MethodDef_body_(struct MethodDef_PRIVATE *self,SEL _cmd,id aBody)
{self->
body=aBody;
return(id)self;
}

static id i_MethodDef_classdef_(struct MethodDef_PRIVATE *self,SEL _cmd,id aClass)
{self->
classdef=aClass;
return(id)self;
}

static id i_MethodDef_prototype(struct MethodDef_PRIVATE *self,SEL _cmd)
{
if( !curclassdef){
fatal("method prototype outside interface");
}else{
id objcT2,objcT3;

#line 116 "methdef.m"
id m,s=(objcT2=(id)self,(*_imp(objcT2,selTransTbl[1]))(objcT2,selTransTbl[1]));

if(o_warntypeconflict&&(m=(objcT3=trlunit,(*_imp(objcT3,selTransTbl[2]))(objcT3,selTransTbl[2],s)))){
id objcT4;
if((objcT4=m,(*(BOOL(*)(id,SEL,id))_imp(objcT4,selTransTbl[3]))(objcT4,selTransTbl[3],self->method))){
id objcT5,objcT6;

#line 121 "methdef.m"
assert((objcT5=m,(*(unsigned(*)(id,SEL))_imp(objcT5,selTransTbl[4]))(objcT5,selTransTbl[4]))==(objcT6=self->method,(*(unsigned(*)(id,SEL))_imp(objcT6,selTransTbl[4]))(objcT6,selTransTbl[4])));
}else{
id objcT7,objcT8,objcT9,objcT10;

#line 123 "methdef.m"
int no=(objcT7=m,(*(int(*)(id,SEL))_imp(objcT7,selTransTbl[5]))(objcT7,selTransTbl[5]));
char*fn=(objcT8=(objcT9=m,(*_imp(objcT9,selTransTbl[6]))(objcT9,selTransTbl[6])),(*(STR(*)(id,SEL))_imp(objcT8,selTransTbl[7]))(objcT8,selTransTbl[7]));

warn("selector '%s' previously declared at %s:%d",(objcT10=s,(*(STR(*)(id,SEL))_imp(objcT10,selTransTbl[7]))(objcT10,selTransTbl[7])),fn,no);
}
}else{
id objcT11;

#line 129 "methdef.m"
(objcT11=trlunit,(*_imp(objcT11,selTransTbl[8]))(objcT11,selTransTbl[8],s,self->method));
if(self->factory){
id objcT12;

#line 131 "methdef.m"
(objcT12=curclassdef,(*_imp(objcT12,selTransTbl[9]))(objcT12,selTransTbl[9],s));
}else{
id objcT13;

#line 133 "methdef.m"
(objcT13=curclassdef,(*_imp(objcT13,selTransTbl[10]))(objcT13,selTransTbl[10],s));
}
}
}
return(id)self;
}

#line 58 "symbol.h"
extern id  Symbol;

#line 140 "methdef.m"
static id i_MethodDef_synth(struct MethodDef_PRIVATE *self,SEL _cmd)
{
if( !curclassdef){
fatal("method definition outside implementation");
}else{
id objcT14,objcT15,objcT16,objcT17,objcT18;
id objcT19,objcT20,objcT21,objcT22,objcT23;
id objcT24,objcT25,objcT26,objcT27,objcT28;
id objcT29,objcT30,objcT31,objcT32,objcT33;
id objcT34,objcT35,objcT38,objcT39;

#line 145 "methdef.m"
id t;
id x;
char*fmt;

(objcT14=(id)self,(*_imp(objcT14,selTransTbl[11]))(objcT14,selTransTbl[11],curclassdef));
curdef=(id)self;
curcompound=(id)0;
x=(objcT15=s_self,(*_imp(objcT15,selTransTbl[12]))(objcT15,selTransTbl[12]));
(objcT16=x,(*(id(*)(id,SEL,int))_imp(objcT16,selTransTbl[13]))(objcT16,selTransTbl[13],(objcT17=self->method,(*(int(*)(id,SEL))_imp(objcT17,selTransTbl[5]))(objcT17,selTransTbl[5]))));
(objcT18=x,(*_imp(objcT18,selTransTbl[14]))(objcT18,selTransTbl[14],(objcT19=self->method,(*_imp(objcT19,selTransTbl[6]))(objcT19,selTransTbl[6]))));
(objcT20=(id)self,(*_imp(objcT20,selTransTbl[15]))(objcT20,selTransTbl[15],x,(objcT21=self->classdef,(*_imp(objcT21,selTransTbl[16]))(objcT21,selTransTbl[16]))));
x=(objcT22=s_cmd,(*_imp(objcT22,selTransTbl[12]))(objcT22,selTransTbl[12]));
(objcT23=x,(*(id(*)(id,SEL,int))_imp(objcT23,selTransTbl[13]))(objcT23,selTransTbl[13],(objcT24=self->method,(*(int(*)(id,SEL))_imp(objcT24,selTransTbl[5]))(objcT24,selTransTbl[5]))));
(objcT25=x,(*_imp(objcT25,selTransTbl[14]))(objcT25,selTransTbl[14],(objcT26=self->method,(*_imp(objcT26,selTransTbl[6]))(objcT26,selTransTbl[6]))));
(objcT27=(id)self,(*_imp(objcT27,selTransTbl[15]))(objcT27,selTransTbl[15],x,t_sel));
(objcT28=self->method,(*_imp(objcT28,selTransTbl[17]))(objcT28,selTransTbl[17]));
(objcT29=curclassdef,(*_imp(objcT29,selTransTbl[18]))(objcT29,selTransTbl[18]));self->
selname=(objcT30=(objcT31=self->method,(*_imp(objcT31,selTransTbl[1]))(objcT31,selTransTbl[1])),(*(STR(*)(id,SEL))_imp(objcT30,selTransTbl[7]))(objcT30,selTransTbl[7]));
fmt=(self->factory)?"c_%s_%s":"i_%s_%s";
t=(objcT32=(objcT33=Symbol,(*(id(*)(id,SEL,STR,...))_imp(objcT33,selTransTbl[19]))(objcT33,selTransTbl[19],fmt,(objcT34=curclassdef,(*(char*(*)(id,SEL))_imp(objcT34,selTransTbl[20]))(objcT34,selTransTbl[20])),self->selname)),(*_imp(objcT32,selTransTbl[21]))(objcT32,selTransTbl[21]));self->
impname=(objcT35=t,(*(STR(*)(id,SEL))_imp(objcT35,selTransTbl[22]))(objcT35,selTransTbl[22]));
if(self->factory){
id objcT36;

#line 167 "methdef.m"
(objcT36=curclassdef,(*_imp(objcT36,selTransTbl[23]))(objcT36,selTransTbl[23],(id)self));
}else{
id objcT37;

#line 169 "methdef.m"
(objcT37=curclassdef,(*_imp(objcT37,selTransTbl[24]))(objcT37,selTransTbl[24],(id)self));
}
(objcT38=trlunit,(*(id(*)(id,SEL,BOOL))_imp(objcT38,selTransTbl[25]))(objcT38,selTransTbl[25],(BOOL)0));
(objcT39=self->body,(*_imp(objcT39,selTransTbl[17]))(objcT39,selTransTbl[17]));
curdef=(id)0;
}
return(id)self;
}

static id i_MethodDef_gen(struct MethodDef_PRIVATE *self,SEL _cmd)
{
id objcT40,objcT41,objcT42,objcT43,objcT44;
id objcT45,objcT46,objcT47,objcT48,objcT49;

#line 180 "methdef.m"
id f,c;

(objcT40=self->classdef,(*_imp(objcT40,selTransTbl[26]))(objcT40,selTransTbl[26]));
(objcT41=_MethodDef.clsSuper,(*_impSuper(objcT41,selTransTbl[26]))((id)self,selTransTbl[26]));
if((f=(objcT42=self->method,(*_imp(objcT42,selTransTbl[6]))(objcT42,selTransTbl[6]))))
gl((objcT43=self->method,(*(int(*)(id,SEL))_imp(objcT43,selTransTbl[5]))(objcT43,selTransTbl[5])),(objcT44=f,(*(STR(*)(id,SEL))_imp(objcT44,selTransTbl[7]))(objcT44,selTransTbl[7])));
gs("static");
(objcT45=self->method,(*_imp(objcT45,selTransTbl[27]))(objcT45,selTransTbl[27]));
gs(self->impname);
gc('(');
c=self->classdef;
assert(self->classdef);
gf("struct %s *self,SEL _cmd",(o_otb)?(objcT46=c,(*(char*(*)(id,SEL))_imp(objcT46,selTransTbl[28]))(objcT46,selTransTbl[28])):(objcT47=c,(*(char*(*)(id,SEL))_imp(objcT47,selTransTbl[29]))(objcT47,selTransTbl[29])));
(objcT48=self->method,(*_imp(objcT48,selTransTbl[30]))(objcT48,selTransTbl[30]));
gc(')');
(objcT49=self->body,(*_imp(objcT49,selTransTbl[26]))(objcT49,selTransTbl[26]));
return(id)self;
}

static id i_MethodDef_st80(struct MethodDef_PRIVATE *self,SEL _cmd)
{
id objcT50,objcT51,objcT52,objcT53,objcT54;
id objcT55,objcT56,objcT57,objcT58;

#line 201 "methdef.m"
int no;
char*fn,*sl;

(objcT50=self->classdef,(*_imp(objcT50,selTransTbl[31]))(objcT50,selTransTbl[31]));
gf("!%s methodsFor:'POC Generated' stamp: 'POC'!",(objcT51=self->classdef,(*(char*(*)(id,SEL))_imp(objcT51,selTransTbl[20]))(objcT51,selTransTbl[20])));
gc('\n');
(objcT52=self->method,(*_imp(objcT52,selTransTbl[31]))(objcT52,selTransTbl[31]));
gc('\n');
no=(objcT53=self->method,(*(int(*)(id,SEL))_imp(objcT53,selTransTbl[5]))(objcT53,selTransTbl[5]));
fn=(objcT54=(objcT55=self->method,(*_imp(objcT55,selTransTbl[6]))(objcT55,selTransTbl[6])),(*(STR(*)(id,SEL))_imp(objcT54,selTransTbl[7]))(objcT54,selTransTbl[7]));
sl=(objcT56=(objcT57=self->method,(*_imp(objcT57,selTransTbl[1]))(objcT57,selTransTbl[1])),(*(STR(*)(id,SEL))_imp(objcT56,selTransTbl[7]))(objcT56,selTransTbl[7]));
gf("\t\"Generated from '%c%s' at %s:%d\"",(self->factory)?'+':'-',sl,fn,no);
gc('\n');
(objcT58=self->body,(*_imp(objcT58,selTransTbl[31]))(objcT58,selTransTbl[31]));
gs("! !\n");
gc('\n');
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Def;
extern struct _SHARED _Def;
extern struct _SHARED __Def;
static struct _SLT _MethodDef_clsDispatchTbl[] ={
{(char*)0,(id (*)())0}
};
static struct _SLT _MethodDef_nstDispatchTbl[] ={
{"factory",(id (*)())i_MethodDef_factory},
{"restype",(id (*)())i_MethodDef_restype},
{"ismethdef",(id (*)())i_MethodDef_ismethdef},
{"factory:",(id (*)())i_MethodDef_factory_},
{"selname",(id (*)())i_MethodDef_selname},
{"impname",(id (*)())i_MethodDef_impname},
{"method",(id (*)())i_MethodDef_method},
{"selector",(id (*)())i_MethodDef_selector},
{"method:",(id (*)())i_MethodDef_method_},
{"compound",(id (*)())i_MethodDef_compound},
{"body:",(id (*)())i_MethodDef_body_},
{"classdef:",(id (*)())i_MethodDef_classdef_},
{"prototype",(id (*)())i_MethodDef_prototype},
{"synth",(id (*)())i_MethodDef_synth},
{"gen",(id (*)())i_MethodDef_gen},
{"st80",(id (*)())i_MethodDef_st80},
{(char*)0,(id (*)())0}
};
id MethodDef = (id)&_MethodDef;
id  *OBJCCLASS_MethodDef(void) { return &MethodDef; }
struct _SHARED  _MethodDef = {
  (id)&__MethodDef,
  (id)&_Def,
  "MethodDef",
  0,
  sizeof(struct MethodDef_PRIVATE),
  16,
  _MethodDef_nstDispatchTbl,
  41,
  &methdef_modDesc,
  0,
  (id)0,
  &MethodDef,
};
id  OBJCCFUNC_MethodDef(void) { return (id)&_MethodDef; }
id  OBJCCSUPER_MethodDef(void) { return _MethodDef.clsSuper; }
struct _SHARED __MethodDef = {
  (id)&__Object,
  (id)&__Def,
  "MethodDef",
  0,
  sizeof(struct _SHARED),
  0,
  _MethodDef_clsDispatchTbl,
  34,
  &methdef_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_MethodDef(void) { return (id)&__MethodDef; }
id  OBJCMSUPER_MethodDef(void) { return __MethodDef.clsSuper; }
static char *_selTransTbl[] ={
"restype",
"selector",
"lookupmethod:",
"typeEqual:",
"typehash",
"lineno",
"filename",
"str",
"def:asmethod:",
"addclssel:",
"addnstsel:",
"classdef:",
"copy",
"lineno:",
"filename:",
"defparm:astype:",
"selftype",
"synth",
"forceimpl",
"sprintf:",
"classname",
"toscores",
"strCopy",
"addclsdisp:",
"addnstdisp:",
"usingselfassign:",
"gen",
"genrestype",
"otbtypename",
"privtypename",
"genparmlist",
"st80",
0
};
struct modDescriptor methdef_modDesc = {
  "methdef",
  "objc2.3.1",
  0L,
  0,
  0,
  &MethodDef,
  32,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_methdef(void)
{
  selTransTbl = _selTransTbl;
  return &methdef_modDesc;
}
int _OBJCPOSTLINK_methdef = 1;


