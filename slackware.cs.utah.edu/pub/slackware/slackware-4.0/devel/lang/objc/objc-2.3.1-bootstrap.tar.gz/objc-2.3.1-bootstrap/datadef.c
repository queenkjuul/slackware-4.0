#line 1 "datadef.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_datadef(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor datadef_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 31 "../../include/objpak/ordcltn.h"
typedef struct objcol{
int count;
int capacity;
id*ptr;
}*objcol_t;
#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "def.h"
extern id curdef;
#line 22 "expr.h"
extern id e_nil;
extern id e_self;
extern id e_cmd;
extern id e_super;
extern id e_aFiler;
extern id e_ft_id;
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 22 "trlunit.h"
extern id trlunit;
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 22 "compstmt.h"
extern id curcompound;
extern id curloopcompound;
#line 23 "util.h"
extern FILE*yyin;
extern int yyparse();

FILE*openfile(STR name,STR modfs);
FILE*reopenfile(STR name,STR modfs,FILE*of);

extern int okblock;

id mkcppdirect(char*s);
id mkexprstmt(id expr);
id mklabeledstmt(id label,id stmt);
id mkcasestmt(id keyw,id expr,id stmt);
id mkdefaultstmt(id keyw,id stmt);
id mkifstmt(id keyw,id expr,id stmt);
id mkifelsestmt(id keyw,id expr,id stmt,id ekeyw,id estmt);
id mkswitchstmt(id keyw,id expr,id stmt);
id mkwhilestmt(id keyw,id expr,id stmt);
id mkdostmt(id keyw,id stmt,id wkeyw,id expr);
id mkforstmt(id keyw,id a,id b,id c,id stmt);
id mkgotostmt(id keyw,id label);
id mkcontinuestmt(id keyw);
id mkbreakstmt(id keyw);
id mkreturnstmt(id keyw,id expr);
id mkcastexpr(id a,id b);
id mkcondexpr(id a,id b,id c);
id mkunaryexpr(STR op,id a);
id mksizeof(id a);
id mkaddressof(id a);
id mkdereference(id a);
id mkbinexpr(id a,STR op,id b);
id mkcommaexpr(id a,id b);
id mkrelexpr(id a,STR op,id b);
id mkassignexpr(id a,STR op,id b);
id mkfuncall(id funname,id args);
id mkbuiltincall(id funname,id args);
id mkfunbody(id datadefs,id compound);
void declarefun(id specs,id decl);
void declaremeth(BOOL factory,id decl);
id mkfundef(id specs,id decl,id body);
id mkmethdef(BOOL factory,id decl,id body);
id mkmesgexpr(id receiver,id args);
id mkdecl(id ident);
id mkprecdecl(id tquals,id decl);
id mkarraydecl(id lhs,id ix);
id mkfundecl(id lhs,id args);
id mkprefixdecl(id lhs,id rhs);
id mkpostfixdecl(id lhs,id rhs);
id mkpointer(id specs,id pointer);
id mkbitfielddecl(id decl,id expr);
id mkstardecl(id pointer,id decl);
id mkasmop(id string,id expr);
id mkasmstmt(id keyw,id tqual,id expr,id asmop1,id asmop2,id clobbers);
id mkcompstmt(id lb,id datadefs,id stmtlist,id rb);
id mklist(id c,id s);
id mklist2(id c,id s,id t);
id atdefsaddall(id c,id n);
id mkblockexpr(id lb,id parms,id datadefs,id stmts,id expr,id rb);
id mkclassdef(id keyw,id name,id sname,id ivars,id cvars);
id mkdatadef(id datadef,id specs,id decl,id initializer);
id mkencodeexpr(id name);
id mkenumspec(id keyw,id name,id lb,id list,id rb);
id mkenumerator(id name,id value);
id mkgnuattrib(id anyword,id exprlist);
id mkgnuattribdecl(id keyw,id list);
id mklistexpr(id lb,id x,id rb);
id mktypename(id specs,id decl);
id mkcomponentdef(id cdef,id specs,id decl);
id mkstructspec(id keyw,id name,id lb,id defs,id rb);
id mkkeywarg(id sel,id arg);
id mkkeywdecl(id sel,id cast,id arg);
id mkmethproto(id cast,id usel,id ksel,BOOL varargs);
id mkidentexpr(id name);
id mkconstexpr(id name,id schain);
id mkprecexpr(id expr);
id mkarrowexpr(id array,id ix);
id mkdotexpr(id array,id ix);
id mkindexexpr(id array,id ix);
id mkpostfixexpr(id expr,id pf);
id mkparmdef(id parmdef,id specs,id decl);
id mkparmdeflist(id idents,id parmdefs,BOOL varargs);
id mkselarg(id selarg,id usel,int ncols);
id mkselectorexpr(id expr);

void procextdef(id def);
void finclassdef(void);
void datadefokblock(id datadef,id specs,id decl);

id mkfileinmeth(id classdef,id ivarnames,id ivartypes);
id mkfileoutmeth(id classdef,id ivarnames,id ivartypes);

id mkincrefsmeth(id classdef,id ivarnames,id ivartypes);
id mkdecrefsmeth(id classdef,id ivarnames,id ivartypes);
#line 22 "datadef.h"
struct DataDef_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 24 "datadef.h"
id specs;
id decllist;
BOOL istypedef;
BOOL isstatic;
BOOL isinline;
BOOL isextern;};

#line 22 "datadef.h"
extern id  DataDef;

#line 22 "datadef.h"
extern struct _SHARED _DataDef;
extern struct _SHARED __DataDef;


#line 45 "datadef.m"
static id i_DataDef_specs(struct DataDef_PRIVATE *self,SEL _cmd)
{
return self->specs;
}

static id i_DataDef_decllist(struct DataDef_PRIVATE *self,SEL _cmd)
{
return self->decllist;
}

static id i_DataDef_specs_(struct DataDef_PRIVATE *self,SEL _cmd,id aSpec)
{self->
specs=aSpec;
return(id)self;
}

#line 37 "../../include/objpak/ordcltn.h"
extern id  OrdCltn;

#line 61 "datadef.m"
static id i_DataDef_add_(struct DataDef_PRIVATE *self,SEL _cmd,id aDecl)
{
id objcT1;

#line 63 "datadef.m"
if( !self->decllist){
id objcT0;
self->
#line 64 "datadef.m"
decllist=(objcT0=OrdCltn,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
}
(objcT1=self->decllist,(*_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1],aDecl));
return(id)self;
}

static id i_DataDef_synthattrs(struct DataDef_PRIVATE *self,SEL _cmd)
{
id objcT2;

#line 72 "datadef.m"
int i,n;

for(i=0,n=(objcT2=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT2,selTransTbl[2]))(objcT2,selTransTbl[2]));i<n;i++){
id objcT3,objcT4;

#line 75 "datadef.m"
id s=(objcT3=self->specs,(*(id(*)(id,SEL,unsigned))_imp(objcT3,selTransTbl[3]))(objcT3,selTransTbl[3],i));

if((objcT4=s,(*(BOOL(*)(id,SEL))_imp(objcT4,selTransTbl[4]))(objcT4,selTransTbl[4]))){
id objcT5,objcT6,objcT7,objcT8;

#line 78 "datadef.m"
if((objcT5=s,(*(BOOL(*)(id,SEL))_imp(objcT5,selTransTbl[5]))(objcT5,selTransTbl[5])))self->
istypedef++;
else if((objcT6=s,(*(BOOL(*)(id,SEL))_imp(objcT6,selTransTbl[6]))(objcT6,selTransTbl[6])))self->
isstatic++;
else if((objcT7=s,(*(BOOL(*)(id,SEL))_imp(objcT7,selTransTbl[7]))(objcT7,selTransTbl[7])))self->
isinline++;
else if((objcT8=s,(*(BOOL(*)(id,SEL))_imp(objcT8,selTransTbl[8]))(objcT8,selTransTbl[8])))self->
isextern++;
}
}
return(id)self;
}

static BOOL i_DataDef_istypedef(struct DataDef_PRIVATE *self,SEL _cmd)
{
return self->istypedef;
}

static BOOL i_DataDef_isstatic(struct DataDef_PRIVATE *self,SEL _cmd)
{
return self->isstatic;
}

static BOOL i_DataDef_isinline(struct DataDef_PRIVATE *self,SEL _cmd)
{
return self->isinline;
}

static BOOL i_DataDef_definesocu(struct DataDef_PRIVATE *self,SEL _cmd)
{

return !self->isstatic&& !self->isextern&& !self->isinline;
}

#line 33 "type.h"
extern id  Type;

#line 22 "initdecl.h"
extern id  InitDecl;

#line 112 "datadef.m"
static id i_DataDef_synth(struct DataDef_PRIVATE *self,SEL _cmd)
{
id objcT9,objcT10,objcT11;

#line 114 "datadef.m"
int i,n;

if(self->specs)
(objcT9=self->specs,(*(id(*)(id,SEL,SEL))_imp(objcT9,selTransTbl[9]))(objcT9,selTransTbl[9],_cmd));
(objcT10=(id)self,(*_imp(objcT10,selTransTbl[10]))(objcT10,selTransTbl[10]));

for(i=0,n=(objcT11=self->decllist,(*(unsigned(*)(id,SEL))_imp(objcT11,selTransTbl[2]))(objcT11,selTransTbl[2]));i<n;i++){
id objcT12,objcT13;

#line 121 "datadef.m"
id var=(objcT12=(objcT13=self->decllist,(*(id(*)(id,SEL,unsigned))_imp(objcT13,selTransTbl[3]))(objcT13,selTransTbl[3],i)),(*_imp(objcT12,selTransTbl[11]))(objcT12,selTransTbl[11]));

if(var){
id objcT14,objcT15,objcT20,objcT21,objcT22;
id objcT23;

#line 124 "datadef.m"
id t=(objcT14=Type,(*_imp(objcT14,selTransTbl[0]))(objcT14,selTransTbl[0]));
id d=(objcT15=self->decllist,(*(id(*)(id,SEL,unsigned))_imp(objcT15,selTransTbl[3]))(objcT15,selTransTbl[3],i));

if(self->specs){
id objcT16,objcT17;

#line 128 "datadef.m"
(objcT16=t,(*_imp(objcT16,selTransTbl[12]))(objcT16,selTransTbl[12],self->specs));
(objcT17=t,(*_imp(objcT17,selTransTbl[13]))(objcT17,selTransTbl[13],d));
}else{
id objcT18,objcT19;

#line 131 "datadef.m"
(objcT18=t,(*_imp(objcT18,selTransTbl[14]))(objcT18,selTransTbl[14],s_int));
(objcT19=t,(*_imp(objcT19,selTransTbl[13]))(objcT19,selTransTbl[13],d));
}
(objcT20=t,(*(id(*)(id,SEL,BOOL))_imp(objcT20,selTransTbl[15]))(objcT20,selTransTbl[15],self->isstatic));
(objcT21=t,(*(id(*)(id,SEL,BOOL))_imp(objcT21,selTransTbl[16]))(objcT21,selTransTbl[16],self->isextern));
if((objcT22=d,(*(BOOL(*)(id,SEL))_imp(objcT22,selTransTbl[17]))(objcT22,selTransTbl[17])))
(objcT23=t,(*(id(*)(id,SEL,BOOL))_imp(objcT23,selTransTbl[18]))(objcT23,selTransTbl[18],(BOOL)1));
if(self->istypedef){
if(curdef){
warn("typedef not allowed inside function or method definition");
}else{
id objcT24;

#line 142 "datadef.m"
(objcT24=trlunit,(*_imp(objcT24,selTransTbl[19]))(objcT24,selTransTbl[19],var,t));
}
}else{
id objcT31,objcT32;

#line 145 "datadef.m"
if(curdef){
if(curcompound){
id objcT25;

#line 147 "datadef.m"
(objcT25=curcompound,(*_imp(objcT25,selTransTbl[20]))(objcT25,selTransTbl[20],var,t));
}else{
id objcT26;

#line 149 "datadef.m"
(objcT26=curdef,(*_imp(objcT26,selTransTbl[21]))(objcT26,selTransTbl[21],var,t));
}
}else{
id objcT27,objcT28,objcT29;

#line 152 "datadef.m"
(objcT27=trlunit,(*_imp(objcT27,selTransTbl[22]))(objcT27,selTransTbl[22],var,t));
if( !o_postlink&&(objcT28=(id)self,(*(BOOL(*)(id,SEL))_imp(objcT28,selTransTbl[23]))(objcT28,selTransTbl[23]))&& !(objcT29=d,(*(BOOL(*)(id,SEL))_imp(objcT29,selTransTbl[24]))(objcT29,selTransTbl[24]))){
id objcT30;

#line 154 "datadef.m"
(objcT30=trlunit,(*_imp(objcT30,selTransTbl[25]))(objcT30,selTransTbl[25],var));
}
}


(objcT31=d,(*_imp(objcT31,selTransTbl[26]))(objcT31,selTransTbl[26]));


if(o_refcnt&&(objcT32=t,(*(BOOL(*)(id,SEL))_imp(objcT32,selTransTbl[27]))(objcT32,selTransTbl[27]))){
id objcT33;

#line 163 "datadef.m"
if((objcT33=d,(*(BOOL(*)(id,SEL))_imp(objcT33,selTransTbl[28]))(objcT33,selTransTbl[28]))){
id objcT34;

#line 164 "datadef.m"
(objcT34=d,(*_imp(objcT34,selTransTbl[29]))(objcT34,selTransTbl[29]));
}else{
if( !self->isextern){
id objcT35,objcT36,objcT37,objcT38;

#line 167 "datadef.m"
d=(objcT35=(objcT36=(objcT37=InitDecl,(*_imp(objcT37,selTransTbl[0]))(objcT37,selTransTbl[0])),(*_imp(objcT36,selTransTbl[13]))(objcT36,selTransTbl[13],d)),(*_imp(objcT35,selTransTbl[30]))(objcT35,selTransTbl[30]));
(objcT38=self->decllist,(*(id(*)(id,SEL,unsigned,id))_imp(objcT38,selTransTbl[31]))(objcT38,selTransTbl[31],i,d));
}
}
}
}
}else{
fatal("missing name in data definition");
}
}

return(id)self;
}

static id i_DataDef_removevars_initializers_(struct DataDef_PRIVATE *self,SEL _cmd,id set,id cltn)
{
id objcT39,objcT53;

#line 183 "datadef.m"
int n=(objcT39=self->decllist,(*(unsigned(*)(id,SEL))_imp(objcT39,selTransTbl[2]))(objcT39,selTransTbl[2]));

while(n--){
id objcT40,objcT41,objcT42,objcT43;

#line 186 "datadef.m"
id d,v;
BOOL isheapvar;

d=(objcT40=self->decllist,(*(id(*)(id,SEL,unsigned))_imp(objcT40,selTransTbl[3]))(objcT40,selTransTbl[3],n));
v=(objcT41=d,(*_imp(objcT41,selTransTbl[11]))(objcT41,selTransTbl[11]));
isheapvar=(objcT42=set,(*(BOOL(*)(id,SEL,id))_imp(objcT42,selTransTbl[32]))(objcT42,selTransTbl[32],v));
if((objcT43=d,(*(BOOL(*)(id,SEL))_imp(objcT43,selTransTbl[28]))(objcT43,selTransTbl[28]))){
id objcT44;

#line 193 "datadef.m"
if((objcT44=d,(*(BOOL(*)(id,SEL))_imp(objcT44,selTransTbl[17]))(objcT44,selTransTbl[17]))){
id objcT45,objcT46;

#line 194 "datadef.m"
if(isheapvar|| !(objcT45=(objcT46=d,(*_imp(objcT46,selTransTbl[33]))(objcT46,selTransTbl[33])),(*(BOOL(*)(id,SEL))_imp(objcT45,selTransTbl[34]))(objcT45,selTransTbl[34]))){
char*m="list initializers not yet allowed in function with Blocks";

fatalat(v,m);
}
}else{
id objcT47,objcT48,objcT49,objcT50,objcT51;

#line 200 "datadef.m"
id x=(objcT47=mkidentexpr(v),(*_imp(objcT47,selTransTbl[35]))(objcT47,selTransTbl[35]));

(objcT48=cltn,(*_imp(objcT48,selTransTbl[1]))(objcT48,selTransTbl[1],mkexprstmt(mkassignexpr(x,"=",(objcT49=d,(*_imp(objcT49,selTransTbl[33]))(objcT49,selTransTbl[33]))))));
(objcT50=self->decllist,(*(id(*)(id,SEL,unsigned,id))_imp(objcT50,selTransTbl[31]))(objcT50,selTransTbl[31],n,(objcT51=d,(*_imp(objcT51,selTransTbl[36]))(objcT51,selTransTbl[36]))));
}
}
if(isheapvar){
id objcT52;

#line 207 "datadef.m"
(objcT52=self->decllist,(*(id(*)(id,SEL,unsigned))_imp(objcT52,selTransTbl[37]))(objcT52,selTransTbl[37],n));
}
}
if( !(objcT53=self->decllist,(*(unsigned(*)(id,SEL))_imp(objcT53,selTransTbl[2]))(objcT53,selTransTbl[2])))self->
decllist=(id)0;
return(id)self;
}

static id i_DataDef_gen(struct DataDef_PRIVATE *self,SEL _cmd)
{
id objcT54;

#line 217 "datadef.m"
if(self->specs)
(objcT54=self->specs,(*(id(*)(id,SEL,SEL))_imp(objcT54,selTransTbl[9]))(objcT54,selTransTbl[9],selTransTbl[38]));
if(self->decllist)
gcommalist(self->decllist);
gc(';');
return(id)self;
}

static id i_DataDef_st80(struct DataDef_PRIVATE *self,SEL _cmd)
{
id objcT55;

#line 227 "datadef.m"
if(self->decllist)
(objcT55=self->decllist,(*(id(*)(id,SEL,SEL))_imp(objcT55,selTransTbl[9]))(objcT55,selTransTbl[9],_cmd));
return(id)self;
}

static id i_DataDef_st80inits(struct DataDef_PRIVATE *self,SEL _cmd)
{
id objcT56;

#line 234 "datadef.m"
if(self->decllist)
(objcT56=self->decllist,(*(id(*)(id,SEL,SEL))_imp(objcT56,selTransTbl[9]))(objcT56,selTransTbl[9],_cmd));
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Node;
extern struct _SHARED _Node;
extern struct _SHARED __Node;
static struct _SLT _DataDef_clsDispatchTbl[] ={
{(char*)0,(id (*)())0}
};
static struct _SLT _DataDef_nstDispatchTbl[] ={
{"specs",(id (*)())i_DataDef_specs},
{"decllist",(id (*)())i_DataDef_decllist},
{"specs:",(id (*)())i_DataDef_specs_},
{"add:",(id (*)())i_DataDef_add_},
{"synthattrs",(id (*)())i_DataDef_synthattrs},
{"istypedef",(id (*)())i_DataDef_istypedef},
{"isstatic",(id (*)())i_DataDef_isstatic},
{"isinline",(id (*)())i_DataDef_isinline},
{"definesocu",(id (*)())i_DataDef_definesocu},
{"synth",(id (*)())i_DataDef_synth},
{"removevars:initializers:",(id (*)())i_DataDef_removevars_initializers_},
{"gen",(id (*)())i_DataDef_gen},
{"st80",(id (*)())i_DataDef_st80},
{"st80inits",(id (*)())i_DataDef_st80inits},
{(char*)0,(id (*)())0}
};
id DataDef = (id)&_DataDef;
id  *OBJCCLASS_DataDef(void) { return &DataDef; }
struct _SHARED  _DataDef = {
  (id)&__DataDef,
  (id)&_Node,
  "DataDef",
  0,
  sizeof(struct DataDef_PRIVATE),
  14,
  _DataDef_nstDispatchTbl,
  41,
  &datadef_modDesc,
  0,
  (id)0,
  &DataDef,
};
id  OBJCCFUNC_DataDef(void) { return (id)&_DataDef; }
id  OBJCCSUPER_DataDef(void) { return _DataDef.clsSuper; }
struct _SHARED __DataDef = {
  (id)&__Object,
  (id)&__Node,
  "DataDef",
  0,
  sizeof(struct _SHARED),
  0,
  _DataDef_clsDispatchTbl,
  34,
  &datadef_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_DataDef(void) { return (id)&__DataDef; }
id  OBJCMSUPER_DataDef(void) { return __DataDef.clsSuper; }
static char *_selTransTbl[] ={
"new",
"add:",
"size",
"at:",
"isstorageclass",
"istypedef",
"isstatic",
"isinline",
"isextern",
"elementsPerform:",
"synthattrs",
"identifier",
"specs:",
"decl:",
"addspec:",
"isstatic:",
"isextern:",
"islistinit",
"haslistinit:",
"def:astype:",
"deflocal:astype:",
"defparm:astype:",
"defdata:astype:",
"definesocu",
"isfunproto",
"definesentry:",
"synthinits",
"isid",
"isinit",
"incref",
"initnil",
"at:put:",
"contains:",
"initializer",
"isconstexpr",
"synth",
"decl",
"removeAt:",
"gen",
0
};
struct modDescriptor datadef_modDesc = {
  "datadef",
  "objc2.3.1",
  0L,
  0,
  0,
  &DataDef,
  39,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_datadef(void)
{
  selTransTbl = _selTransTbl;
  return &datadef_modDesc;
}
int _OBJCPOSTLINK_datadef = 1;


