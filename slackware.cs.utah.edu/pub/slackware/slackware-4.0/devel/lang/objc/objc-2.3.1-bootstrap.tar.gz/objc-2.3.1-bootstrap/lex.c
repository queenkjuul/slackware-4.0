#line 1 "lex.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_lex(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor lex_modDesc;

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 99 "lex.m"
typedef struct yy_buffer_state*YY_BUFFER_STATE;

extern int yyleng;
extern FILE*yyin,*yyout;
#line 141 "lex.m"
typedef unsigned int yy_size_t;


struct yy_buffer_state
{
FILE*yy_input_file;

char*yy_ch_buf;
char*yy_buf_pos;
#line 154 "lex.m"
yy_size_t yy_buf_size;
#line 159 "lex.m"
int yy_n_chars;
#line 165 "lex.m"
int yy_is_our_buffer;
#line 172 "lex.m"
int yy_is_interactive;
#line 178 "lex.m"
int yy_at_bol;
#line 183 "lex.m"
int yy_fill_buffer;

int yy_buffer_status;
#line 199 "lex.m"
};

static YY_BUFFER_STATE yy_current_buffer=0;
#line 211 "lex.m"
static char yy_hold_char;

static int yy_n_chars;


int yyleng;


static char*yy_c_buf_p=(char*)0;
static int yy_init=1;
static int yy_start=0;
#line 226 "lex.m"
static int yy_did_buffer_switch_on_eof;

void yyrestart(FILE*input_file);

void yy_switch_to_buffer(YY_BUFFER_STATE new_buffer);
void yy_load_buffer_state(void);
YY_BUFFER_STATE yy_create_buffer(FILE*file,int size);
void yy_delete_buffer(YY_BUFFER_STATE b);
void yy_init_buffer(YY_BUFFER_STATE b,FILE*file);
void yy_flush_buffer(YY_BUFFER_STATE b);


YY_BUFFER_STATE yy_scan_buffer(char*base,yy_size_t size);
YY_BUFFER_STATE yy_scan_string(const char*yy_str);
YY_BUFFER_STATE yy_scan_bytes(const char*bytes,int len);

static void*yy_flex_alloc(yy_size_t);
static void*yy_flex_realloc(void*,yy_size_t);
static void yy_flex_free(void*);
#line 264 "lex.m"
typedef unsigned char YY_CHAR;
FILE*yyin=(FILE*)0,*yyout=(FILE*)0;
typedef int yy_state_type;
extern char*yytext;


static yy_state_type yy_get_previous_state(void);
static yy_state_type yy_try_NUL_trans(yy_state_type current_state);
static int yy_get_next_buffer(void);
static void yy_fatal_error(const char msg[]);
#line 287 "lex.m"
static const short int yy_accept[624]=
{0,
0,0,162,160,147,148,148,106,160,160,
158,112,123,160,100,101,110,113,141,114,
105,111,154,154,129,142,117,130,119,128,
160,102,103,124,158,158,158,158,158,158,
158,158,158,158,158,158,158,158,158,158,
158,143,125,144,107,147,122,0,150,0,
0,149,158,135,126,136,0,151,0,133,
108,131,109,132,104,0,157,159,134,155,
152,154,0,154,154,0,115,118,146,121,
120,116,0,0,0,0,0,0,138,158,

158,158,158,158,158,158,158,158,158,158,
158,158,158,158,158,158,7,158,158,158,
158,158,158,158,44,17,158,158,158,158,
158,158,158,158,158,158,158,158,158,137,
127,0,0,0,0,0,0,145,0,157,
157,159,155,0,155,155,152,152,0,156,
154,153,139,140,0,0,0,0,0,0,
0,0,158,158,158,158,158,158,158,158,
158,158,158,158,158,158,158,158,158,158,
158,158,158,158,158,158,50,158,158,158,

158,158,158,158,158,158,158,158,68,158,
15,158,158,18,158,158,158,158,158,158,
158,158,158,158,158,158,158,158,158,158,
158,0,0,0,0,0,0,0,157,157,
0,155,155,0,155,155,152,156,156,153,
153,0,0,42,0,0,0,0,0,0,
0,158,158,158,158,158,158,158,158,158,
158,158,158,158,158,158,158,158,158,158,
158,158,158,158,158,158,158,158,158,67,
158,158,158,1,32,158,3,4,158,158,

158,158,9,10,158,158,16,158,19,158,
158,158,158,158,158,158,158,158,158,158,
158,30,158,158,158,0,0,0,0,0,
0,0,155,155,156,153,38,0,0,0,
0,0,0,0,0,158,158,158,158,158,
60,158,158,158,158,158,158,158,158,66,
158,158,158,158,158,158,158,158,158,158,
158,158,158,158,158,158,158,158,70,158,
158,2,35,158,158,158,158,14,158,158,
158,158,22,158,158,158,158,158,158,28,

158,158,158,31,0,0,0,0,0,0,
0,0,0,0,158,158,158,93,158,158,
158,158,158,158,158,158,158,158,158,158,
158,82,158,158,158,158,158,69,158,158,
158,158,85,158,158,158,158,158,158,158,
158,158,158,8,13,49,71,158,21,36,
23,24,25,26,158,158,158,158,43,0,
0,0,0,46,0,0,158,158,86,99,
61,158,77,65,54,158,158,158,158,92,
158,158,158,81,158,158,158,158,158,158,

158,158,158,158,158,158,158,72,158,158,
6,0,158,27,158,158,33,0,0,48,
0,0,0,98,97,158,0,158,158,158,
75,158,158,158,63,158,89,158,158,158,
158,158,55,158,158,158,158,158,73,5,
0,20,29,37,0,0,0,45,39,158,
0,94,51,76,158,158,158,87,158,158,
158,0,158,83,84,158,74,91,158,158,
34,0,0,40,47,158,78,158,79,62,
158,158,0,95,90,56,57,52,11,0,

0,158,0,158,88,80,158,158,0,0,
158,0,96,158,58,53,12,0,59,64,
0,41,0
};

static const int yy_ec[256]=
{0,
1,1,1,1,1,1,1,1,2,3,
1,1,4,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,5,6,7,8,9,10,11,12,13,
14,15,16,17,18,19,20,21,22,23,
23,24,23,25,23,26,26,27,28,29,
30,31,32,33,34,35,36,34,37,38,
9,9,9,9,9,39,9,9,40,41,
9,9,42,9,43,9,9,44,9,9,
45,46,47,48,49,1,50,51,52,53,

54,55,56,57,58,9,59,60,61,62,
63,64,65,66,67,68,69,70,71,72,
73,74,75,76,77,78,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,

1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1
};

static const int yy_meta[79]=
{0,
1,1,2,2,1,1,3,1,4,1,
1,3,1,1,1,1,1,1,1,1,
5,5,5,5,5,6,1,1,1,1,
1,3,1,6,6,6,6,6,4,4,
4,4,4,7,1,3,1,1,4,5,
5,6,6,6,5,4,4,4,4,4,
4,7,4,4,4,7,4,7,4,7,
4,7,4,4,1,1,1,1
};

static const short int yy_base[637]=
{0,
0,0,1025,1026,77,1026,1026,994,73,80,
0,993,70,74,1026,1026,992,69,1026,71,
69,67,102,156,1026,1026,74,78,76,1026,
76,1026,1026,991,156,29,46,81,59,75,
98,957,97,956,968,963,96,943,953,951,
58,1026,81,1026,1026,112,1026,109,1026,162,
129,1026,0,1026,1026,1026,124,1026,205,1026,
1026,1026,1026,1026,1026,994,257,0,1026,297,
164,0,219,112,129,0,982,1026,1026,1026,
1026,981,956,947,104,94,954,953,1026,937,

941,954,115,308,953,948,951,932,938,930,
934,942,928,944,931,937,922,923,920,920,
921,923,919,916,0,0,132,921,915,134,
918,120,151,922,915,146,154,921,919,1026,
1026,241,246,0,281,318,0,1026,234,212,
215,0,277,364,237,247,249,250,323,370,
1026,358,1026,1026,921,169,911,906,266,922,
907,911,912,901,916,911,899,164,915,237,
910,891,211,893,899,897,905,892,348,895,
893,903,888,903,885,898,0,887,889,898,

893,880,171,895,893,889,881,887,0,890,
0,876,880,0,881,884,877,865,867,870,
877,862,860,860,873,863,867,871,873,872,
861,410,450,485,416,529,564,389,422,1026,
508,294,311,428,570,1026,1026,316,344,345,
360,853,856,1026,858,863,846,847,854,844,
858,851,850,850,886,839,845,837,837,849,
840,841,848,151,180,833,842,231,276,847,
846,825,313,838,840,825,824,830,832,0,
822,835,834,0,0,826,0,0,816,825,

813,821,0,0,814,811,0,816,0,827,
809,809,806,819,809,813,818,817,815,805,
810,0,797,798,809,321,0,610,412,0,
645,442,617,1026,1026,1026,1026,809,807,794,
809,804,799,798,803,786,795,798,826,796,
800,782,793,794,778,775,783,779,787,818,
771,770,783,778,349,782,778,767,776,777,
361,775,767,776,775,768,775,774,0,773,
772,0,0,759,760,765,756,0,763,756,
747,752,0,760,757,759,742,752,754,0,

745,748,756,0,435,424,750,742,747,733,
748,747,732,729,738,733,741,0,732,743,
733,737,729,720,720,719,719,722,758,730,
715,0,718,755,712,724,727,0,714,708,
719,722,0,717,720,687,678,664,663,667,
660,633,626,0,688,0,0,638,0,0,
0,0,0,0,636,636,629,620,1026,633,
636,631,616,1026,624,613,613,615,0,0,
0,622,646,0,609,593,590,585,585,0,
601,600,595,0,571,562,568,577,572,562,

562,569,561,560,551,554,562,0,550,553,
0,599,539,0,551,549,0,535,526,1026,
523,509,508,0,0,504,558,522,510,515,
0,510,502,499,511,490,0,495,544,500,
481,494,498,486,485,490,483,474,0,0,
492,0,0,0,459,471,465,1026,1026,449,
502,1026,0,0,463,451,453,0,463,435,
436,483,428,0,0,445,0,0,440,438,
0,462,441,1026,1026,436,476,421,0,0,
412,423,445,1026,0,0,406,380,1026,410,

351,358,386,332,0,0,307,259,291,226,
224,195,1026,124,0,0,1026,86,0,0,
56,1026,1026,700,707,711,718,723,728,735,
738,740,742,748,755,762
};

static const short int yy_def[637]=
{0,
623,1,623,623,623,623,623,623,624,625,
626,623,623,627,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,623,623,623,623,623,623,624,623,628,
625,623,626,623,623,623,627,623,629,623,
623,623,623,623,623,623,623,630,623,623,
23,24,623,623,623,631,623,623,623,623,
623,623,623,623,623,623,623,623,623,626,

626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,623,
623,624,624,632,627,627,633,623,623,623,
623,630,80,623,623,623,623,623,623,623,
623,631,623,623,623,623,623,623,623,623,
623,623,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,

626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,624,624,233,627,627,236,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,

626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,624,234,234,627,237,
237,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,

626,626,626,626,624,627,623,623,623,623,
623,623,623,623,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,623,623,
623,623,623,623,623,623,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,

626,626,626,626,626,626,626,626,626,626,
626,623,626,626,626,626,626,623,623,623,
623,623,623,626,626,626,634,626,626,626,
626,626,626,626,626,626,626,626,626,626,
626,626,626,626,626,626,626,626,626,626,
623,626,626,626,623,623,623,623,623,626,
634,623,626,626,626,626,626,626,626,626,
626,635,626,626,626,626,626,626,626,626,
626,623,623,623,623,626,626,626,626,626,
626,626,635,623,626,626,626,626,623,623,

623,626,636,626,626,626,626,626,623,623,
626,636,623,626,626,626,623,623,626,626,
623,623,0,623,623,623,623,623,623,623,
623,623,623,623,623,623
};

static const short int yy_nxt[1105]=
{0,
4,5,6,7,5,8,9,10,11,12,
13,14,15,16,17,18,19,20,21,22,
23,24,24,24,24,24,25,26,27,28,
29,30,31,11,11,11,11,11,11,11,
11,11,11,11,32,4,33,34,35,36,
37,38,39,40,41,42,11,43,11,44,
11,11,11,45,11,46,47,48,49,50,
51,11,11,11,52,53,54,55,56,59,
65,56,62,62,71,68,78,76,73,77,
77,77,77,77,77,109,79,110,72,66,

74,75,87,88,89,91,92,90,111,138,
140,112,116,56,139,59,56,622,60,69,
80,117,81,81,81,81,81,82,93,94,
113,62,62,95,118,68,119,114,83,96,
84,97,98,115,85,86,120,121,621,125,
161,126,131,132,60,83,141,122,127,169,
123,84,170,133,167,168,134,84,176,69,
85,161,620,86,80,220,82,82,82,82,
82,82,142,143,143,143,143,177,84,217,
100,213,83,221,84,101,102,103,85,214,

222,218,157,226,104,144,158,623,613,83,
105,228,227,229,358,84,223,106,359,107,
253,254,108,157,85,145,146,146,146,146,
267,268,158,144,159,623,159,299,300,160,
160,160,160,160,160,360,361,59,147,238,
151,238,59,240,239,239,239,239,239,239,
275,232,232,232,232,232,232,232,232,232,
232,151,619,276,240,156,147,77,77,77,
77,77,77,618,233,246,60,247,157,270,
364,60,68,149,150,151,156,617,365,271,

272,235,235,235,235,235,246,616,247,157,
149,150,233,241,242,243,151,153,153,153,
153,153,153,257,236,366,69,59,258,68,
241,242,243,154,155,156,243,367,235,235,
235,235,235,160,160,160,160,160,160,334,
154,155,236,243,249,615,156,178,179,180,
181,182,183,69,184,185,60,186,371,187,
334,188,372,434,189,249,190,191,192,244,
614,244,335,336,245,245,245,245,245,245,
160,160,160,160,160,160,250,282,250,613,

251,283,435,335,336,284,611,248,249,239,
239,239,239,239,239,285,59,250,610,250,
286,441,442,68,248,609,251,68,608,249,
326,326,326,326,326,68,329,329,329,329,
329,59,239,239,239,239,239,239,245,245,
245,245,245,245,607,60,59,69,594,150,
151,69,333,333,333,333,333,333,599,69,
327,327,327,327,327,327,150,600,606,605,
60,151,604,327,327,327,327,327,603,602,
601,598,597,596,595,60,594,592,591,327,

327,327,327,327,327,328,328,328,328,328,
328,590,589,588,587,562,586,585,328,328,
328,328,328,332,584,332,583,582,333,333,
333,333,333,333,328,328,328,328,328,328,
68,581,580,579,578,577,576,575,574,330,
330,330,330,330,330,573,572,571,570,569,
568,567,330,330,330,330,330,566,565,564,
563,562,560,559,69,558,557,556,330,330,
330,330,330,330,331,331,331,331,331,331,
245,245,245,245,245,245,555,331,331,331,

331,331,554,553,552,551,550,155,156,549,
548,547,546,331,331,331,331,331,331,545,
544,543,542,541,155,540,539,538,537,156,
405,405,405,405,405,405,536,333,333,333,
333,333,333,405,405,405,405,405,535,534,
533,532,531,530,242,243,529,528,527,405,
405,405,405,405,405,406,406,406,406,406,
406,242,526,525,524,523,243,522,406,406,
406,406,406,521,520,519,518,517,516,515,
514,513,512,511,406,406,406,406,406,406,

58,510,58,58,58,58,58,61,61,61,
61,61,61,61,63,63,63,63,67,509,
67,67,67,67,67,58,508,58,507,58,
67,506,67,505,67,152,504,152,152,152,
152,152,162,162,234,234,237,237,561,561,
561,561,561,561,561,593,593,593,593,593,
593,593,612,612,612,612,612,612,612,503,
502,501,500,499,498,497,496,495,494,493,
492,491,490,489,488,487,486,485,484,483,
482,481,480,479,478,477,476,475,474,473,

472,471,470,469,468,467,466,465,464,463,
462,461,460,459,458,457,456,455,454,453,
452,451,450,449,448,447,446,445,444,443,
440,439,438,437,436,433,432,431,430,429,
428,427,426,425,424,423,422,421,420,419,
418,417,416,415,414,413,412,411,410,409,
408,407,404,403,402,401,400,399,398,397,
396,395,394,393,392,391,390,389,388,387,
386,385,384,383,382,381,380,379,378,377,
376,375,374,373,370,369,368,363,362,357,

356,355,354,353,352,351,350,349,348,347,
346,345,344,343,342,341,340,339,338,337,
325,324,323,322,321,320,319,318,317,316,
315,314,313,312,311,310,309,308,307,306,
305,304,303,302,301,298,297,296,295,294,
293,292,291,290,289,288,287,281,280,279,
278,277,274,273,269,266,265,264,263,262,
261,260,259,256,255,252,231,230,225,224,
219,216,215,212,211,210,209,208,207,206,
205,204,203,202,201,200,199,198,197,196,

195,194,193,175,174,173,172,171,166,165,
164,163,148,137,136,135,130,129,128,124,
99,70,64,57,623,3,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,

623,623,623,623
};

static const short int yy_chk[1105]=
{0,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,5,9,
13,5,10,10,18,14,22,21,20,21,
21,21,21,21,21,36,22,36,18,13,

20,20,27,27,28,29,29,28,37,51,
53,37,39,56,51,58,56,621,9,14,
23,39,23,23,23,23,23,23,31,31,
38,61,61,31,40,67,40,38,23,31,
23,31,31,38,23,23,40,41,618,43,
84,43,47,47,58,23,53,41,43,96,
41,23,96,47,95,95,47,85,103,67,
23,84,614,23,24,132,24,24,24,24,
24,24,60,60,60,60,60,103,85,130,
35,127,24,132,24,35,35,35,24,127,

133,130,81,136,35,60,81,81,612,24,
35,137,136,137,274,24,133,35,274,35,
166,166,35,81,24,69,69,69,69,69,
178,178,81,60,83,81,83,203,203,83,
83,83,83,83,83,275,275,142,69,149,
150,149,143,151,149,149,149,149,149,149,
183,142,142,142,142,142,143,143,143,143,
143,150,611,183,151,155,69,77,77,77,
77,77,77,610,142,156,142,157,158,180,
278,143,145,77,77,77,155,609,278,180,

180,145,145,145,145,145,156,608,157,158,
77,77,142,153,153,153,77,80,80,80,
80,80,80,169,145,279,145,326,169,146,
153,153,242,80,80,80,153,279,146,146,
146,146,146,159,159,159,159,159,159,243,
80,80,145,242,248,607,80,104,104,104,
104,104,104,146,104,104,326,104,283,104,
243,104,283,365,104,248,104,104,104,154,
604,154,249,250,154,154,154,154,154,154,
160,160,160,160,160,160,162,189,251,603,

162,189,365,249,250,189,602,160,160,238,
238,238,238,238,238,189,232,162,601,251,
189,371,371,329,160,600,162,235,598,160,
232,232,232,232,232,406,235,235,235,235,
235,405,239,239,239,239,239,239,244,244,
244,244,244,244,597,232,233,329,593,239,
239,235,332,332,332,332,332,332,582,406,
233,233,233,233,233,233,239,582,592,591,
405,239,588,233,233,233,233,233,587,586,
583,580,579,576,573,233,572,571,570,233,

233,233,233,233,233,234,234,234,234,234,
234,569,567,566,565,561,560,557,234,234,
234,234,234,241,556,241,555,551,241,241,
241,241,241,241,234,234,234,234,234,234,
236,548,547,546,545,544,543,542,541,236,
236,236,236,236,236,540,539,538,536,535,
534,533,236,236,236,236,236,532,530,529,
528,527,526,523,236,522,521,519,236,236,
236,236,236,236,237,237,237,237,237,237,
245,245,245,245,245,245,518,237,237,237,

237,237,516,515,513,512,510,245,245,509,
507,506,505,237,237,237,237,237,237,504,
503,502,501,500,245,499,498,497,496,245,
328,328,328,328,328,328,495,333,333,333,
333,333,333,328,328,328,328,328,493,492,
491,489,488,487,333,333,486,485,483,328,
328,328,328,328,328,331,331,331,331,331,
331,333,482,478,477,476,333,475,331,331,
331,331,331,473,472,471,470,468,467,466,
465,458,455,453,331,331,331,331,331,331,

624,452,624,624,624,624,624,625,625,625,
625,625,625,625,626,626,626,626,627,451,
627,627,627,627,627,628,450,628,449,628,
629,448,629,447,629,630,446,630,630,630,
630,630,631,631,632,632,633,633,634,634,
634,634,634,634,634,635,635,635,635,635,
635,635,636,636,636,636,636,636,636,445,
444,442,441,440,439,437,436,435,434,433,
431,430,429,428,427,426,425,424,423,422,
421,420,419,417,416,415,414,413,412,411,

410,409,408,407,403,402,401,399,398,397,
396,395,394,392,391,390,389,387,386,385,
384,381,380,378,377,376,375,374,373,372,
370,369,368,367,366,364,363,362,361,360,
359,358,357,356,355,354,353,352,351,350,
349,348,347,346,345,344,343,342,341,340,
339,338,325,324,323,321,320,319,318,317,
316,315,314,313,312,311,310,308,306,305,
302,301,300,299,296,293,292,291,289,288,
287,286,285,284,282,281,280,277,276,273,

272,271,270,269,268,267,266,265,264,263,
262,261,260,259,258,257,256,255,253,252,
231,230,229,228,227,226,225,224,223,222,
221,220,219,218,217,216,215,213,212,210,
208,207,206,205,204,202,201,200,199,198,
196,195,194,193,192,191,190,188,187,186,
185,184,182,181,179,177,176,175,174,173,
172,171,170,168,167,165,139,138,135,134,
131,129,128,124,123,122,121,120,119,118,
117,116,115,114,113,112,111,110,109,108,

107,106,105,102,101,100,98,97,94,93,
92,87,76,50,49,48,46,45,44,42,
34,17,12,8,3,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,
623,623,623,623,623,623,623,623,623,623,

623,623,623,623
};

static yy_state_type yy_last_accepting_state;
static char*yy_last_accepting_cpos;
#line 814 "lex.m"
char*yytext;
#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 22 "../oclib/symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 22 "../oclib/node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 23 "../oclib/util.h"
extern FILE*yyin;
extern int yyparse();

FILE*openfile(STR name,STR modfs);
FILE*reopenfile(STR name,STR modfs,FILE*of);

extern int okblock;

id mkcppdirect(char*s);
id mkexprstmt(id expr);
id mklabeledstmt(id label,id stmt);
id mkcasestmt(id keyw,id expr,id stmt);
id mkdefaultstmt(id keyw,id stmt);
id mkifstmt(id keyw,id expr,id stmt);
id mkifelsestmt(id keyw,id expr,id stmt,id ekeyw,id estmt);
id mkswitchstmt(id keyw,id expr,id stmt);
id mkwhilestmt(id keyw,id expr,id stmt);
id mkdostmt(id keyw,id stmt,id wkeyw,id expr);
id mkforstmt(id keyw,id a,id b,id c,id stmt);
id mkgotostmt(id keyw,id label);
id mkcontinuestmt(id keyw);
id mkbreakstmt(id keyw);
id mkreturnstmt(id keyw,id expr);
id mkcastexpr(id a,id b);
id mkcondexpr(id a,id b,id c);
id mkunaryexpr(STR op,id a);
id mksizeof(id a);
id mkaddressof(id a);
id mkdereference(id a);
id mkbinexpr(id a,STR op,id b);
id mkcommaexpr(id a,id b);
id mkrelexpr(id a,STR op,id b);
id mkassignexpr(id a,STR op,id b);
id mkfuncall(id funname,id args);
id mkbuiltincall(id funname,id args);
id mkfunbody(id datadefs,id compound);
void declarefun(id specs,id decl);
void declaremeth(BOOL factory,id decl);
id mkfundef(id specs,id decl,id body);
id mkmethdef(BOOL factory,id decl,id body);
id mkmesgexpr(id receiver,id args);
id mkdecl(id ident);
id mkprecdecl(id tquals,id decl);
id mkarraydecl(id lhs,id ix);
id mkfundecl(id lhs,id args);
id mkprefixdecl(id lhs,id rhs);
id mkpostfixdecl(id lhs,id rhs);
id mkpointer(id specs,id pointer);
id mkbitfielddecl(id decl,id expr);
id mkstardecl(id pointer,id decl);
id mkasmop(id string,id expr);
id mkasmstmt(id keyw,id tqual,id expr,id asmop1,id asmop2,id clobbers);
id mkcompstmt(id lb,id datadefs,id stmtlist,id rb);
id mklist(id c,id s);
id mklist2(id c,id s,id t);
id atdefsaddall(id c,id n);
id mkblockexpr(id lb,id parms,id datadefs,id stmts,id expr,id rb);
id mkclassdef(id keyw,id name,id sname,id ivars,id cvars);
id mkdatadef(id datadef,id specs,id decl,id initializer);
id mkencodeexpr(id name);
id mkenumspec(id keyw,id name,id lb,id list,id rb);
id mkenumerator(id name,id value);
id mkgnuattrib(id anyword,id exprlist);
id mkgnuattribdecl(id keyw,id list);
id mklistexpr(id lb,id x,id rb);
id mktypename(id specs,id decl);
id mkcomponentdef(id cdef,id specs,id decl);
id mkstructspec(id keyw,id name,id lb,id defs,id rb);
id mkkeywarg(id sel,id arg);
id mkkeywdecl(id sel,id cast,id arg);
id mkmethproto(id cast,id usel,id ksel,BOOL varargs);
id mkidentexpr(id name);
id mkconstexpr(id name,id schain);
id mkprecexpr(id expr);
id mkarrowexpr(id array,id ix);
id mkdotexpr(id array,id ix);
id mkindexexpr(id array,id ix);
id mkpostfixexpr(id expr,id pf);
id mkparmdef(id parmdef,id specs,id decl);
id mkparmdeflist(id idents,id parmdefs,BOOL varargs);
id mkselarg(id selarg,id usel,int ncols);
id mkselectorexpr(id expr);

void procextdef(id def);
void finclassdef(void);
void datadefokblock(id datadef,id specs,id decl);

id mkfileinmeth(id classdef,id ivarnames,id ivartypes);
id mkfileoutmeth(id classdef,id ivarnames,id ivartypes);

id mkincrefsmeth(id classdef,id ivarnames,id ivartypes);
id mkdecrefsmeth(id classdef,id ivarnames,id ivartypes);
#line 22 "../oclib/type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "../oclib/options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 37 "lex.lm"
extern id yylval;

int identif(void);
int keyw(int x);
int tkeyw(int x,id t);
int gnukeyw(int x);
int msdoskeyw(int x);
int watcomkeyw(int x);
int ibmvackeyw(int x);


int okblock;
#line 880 "lex.yy.c"
extern int yywrap(void);
#line 885 "lex.yy.c"
static void yyunput(int c,char*buf_ptr);
#line 900 "lex.yy.c"
static int input(void);
#line 1 "../../util/stdlib.h"
#include <stdlib.h>


#line 1015 "lex.yy.c"
int yylex(void)
{
register yy_state_type yy_current_state;
register char*yy_cp,*yy_bp;
register int yy_act;
#line 1026 "lex.yy.c"
if(yy_init)
{
yy_init=0;
#line 1034 "lex.yy.c"
if( !yy_start)
yy_start=1;

if( !yyin)
yyin=stdin;

if( !yyout)
yyout=stdout;

if( !yy_current_buffer)
yy_current_buffer=
yy_create_buffer(yyin,16384);

yy_load_buffer_state();
}

while(1)
{
yy_cp=yy_c_buf_p; *


yy_cp=yy_hold_char;
#line 1060 "lex.yy.c"
yy_bp=yy_cp;

yy_current_state=yy_start;
yy_match:
do
{
register YY_CHAR yy_c=yy_ec[((unsigned int)(unsigned char) *yy_cp)];
if(yy_accept[yy_current_state])
{
yy_last_accepting_state=yy_current_state;
yy_last_accepting_cpos=yy_cp;
}
while(yy_chk[yy_base[yy_current_state]+yy_c]!=yy_current_state)
{
yy_current_state=(int)yy_def[yy_current_state];
if(yy_current_state>=624)
yy_c=yy_meta[(unsigned int)yy_c];
}
yy_current_state=yy_nxt[yy_base[yy_current_state]+(unsigned int)yy_c]; ++
yy_cp;
}
while(yy_base[yy_current_state]!=1026);

yy_find_action:
yy_act=yy_accept[yy_current_state];
if(yy_act==0)
{
yy_cp=yy_last_accepting_cpos;
yy_current_state=yy_last_accepting_state;
yy_act=yy_accept[yy_current_state];
}

yytext=yy_bp;yyleng=(int)(yy_cp-yy_bp);yy_hold_char= *yy_cp; *yy_cp='\0';yy_c_buf_p=yy_cp;;


do_action:


switch(yy_act)
{
case 0: *

yy_cp=yy_hold_char;
yy_cp=yy_last_accepting_cpos;
yy_current_state=yy_last_accepting_state;
goto yy_find_action;

case 1:
#line 75 "lex.lm"
{return keyw(262);}
break;
case 2:
#line 76 "lex.lm"
{return keyw(276);}
break;
case 3:
#line 77 "lex.lm"
{return keyw(274);}
break;
case 4:
#line 78 "lex.lm"
{return keyw(261);}
break;
case 5:
#line 79 "lex.lm"
{return keyw(277);}
break;
case 6:
#line 80 "lex.lm"
{return keyw(275);}
break;
case 7:
#line 81 "lex.lm"
{return keyw(271);}
break;
case 8:
#line 82 "lex.lm"
{return keyw(261);}
break;
case 9:
#line 83 "lex.lm"
{return keyw(269);}
break;
case 10:
#line 84 "lex.lm"
{return keyw(266);}
break;
case 11:
#line 85 "lex.lm"
{if(o_cplus)return keyw(264);}
break;
case 12:
#line 86 "lex.lm"
{if(o_cplus)return keyw(264);}
break;
case 13:
#line 87 "lex.lm"
{return keyw(262);}
break;
case 14:
#line 88 "lex.lm"
{return keyw(261);}
break;
case 15:
#line 89 "lex.lm"
{return keyw(272);}
break;
case 16:
#line 90 "lex.lm"
{return keyw(279);}
break;
case 17:
#line 91 "lex.lm"
{return keyw(268);}
break;
case 18:
#line 92 "lex.lm"
{return keyw(261);}
break;
case 19:
#line 93 "lex.lm"
{return keyw(261);}
break;
case 20:
#line 94 "lex.lm"
{return keyw(262);}
break;
case 21:
#line 95 "lex.lm"
{return keyw(278);}
break;
case 22:
#line 96 "lex.lm"
{return keyw(261);}
break;
case 23:
#line 97 "lex.lm"
{return keyw(281);}
break;
case 24:
#line 98 "lex.lm"
{return keyw(262);}
break;
case 25:
#line 99 "lex.lm"
{return keyw(267);}
break;
case 26:
#line 100 "lex.lm"
{return keyw(273);}
break;
case 27:
#line 101 "lex.lm"
{return keyw(262);}
break;
case 28:
#line 102 "lex.lm"
{return keyw(267);}
break;
case 29:
#line 103 "lex.lm"
{return keyw(261);}
break;
case 30:
#line 104 "lex.lm"
{return keyw(261);}
break;
case 31:
#line 105 "lex.lm"
{return keyw(270);}
break;
case 32:
#line 107 "lex.lm"
{return(o_cplus)?keyw(261):identif();}
break;
case 33:
#line 108 "lex.lm"
{return(o_cplus)?keyw(261):identif();}
break;
case 34:
#line 109 "lex.lm"
{return(o_cplus)?keyw(261):identif();}
break;
case 35:
#line 111 "lex.lm"
{return keyw(263);}
break;
case 36:
#line 112 "lex.lm"
{return keyw(261);}
break;
case 37:
#line 113 "lex.lm"
{return keyw(263);}
break;
case 38:
#line 115 "lex.lm"
{return keyw(291);}
break;
case 39:
#line 116 "lex.lm"
{return keyw(292);}
break;
case 40:
#line 117 "lex.lm"
{return keyw(293);}
break;
case 41:
#line 118 "lex.lm"
{return keyw(293);}
break;
case 42:
#line 119 "lex.lm"
{return keyw(294);}
break;
case 43:
#line 120 "lex.lm"
{return keyw(295);}
break;
case 44:
#line 121 "lex.lm"
{return keyw(261);}
break;
case 45:
#line 122 "lex.lm"
{return keyw(296);}
break;
case 46:
#line 123 "lex.lm"
{warn("ignoring @public.");}
break;
case 47:
#line 124 "lex.lm"
{warn("ignoring @protected.");}
break;
case 48:
#line 125 "lex.lm"
{warn("ignoring @private.");}
break;
case 49:
#line 127 "lex.lm"
{return keyw(262);}
break;
case 50:
#line 129 "lex.lm"
{return(o_enableasm)?keyw(280):identif();}
break;
case 51:
#line 131 "lex.lm"
{return gnukeyw(263);}
break;
case 52:
#line 132 "lex.lm"
{return gnukeyw(263);}
break;
case 53:
#line 133 "lex.lm"
{return gnukeyw(263);}
break;
case 54:
#line 134 "lex.lm"
{return gnukeyw(263);}
break;
case 55:
#line 135 "lex.lm"
{return gnukeyw(261);}
break;
case 56:
#line 136 "lex.lm"
{return gnukeyw(261);}
break;
case 57:
#line 137 "lex.lm"
{return gnukeyw(261);}
break;
case 58:
#line 138 "lex.lm"
{return gnukeyw(261);}
break;
case 59:
#line 139 "lex.lm"
{return gnukeyw(299);}
break;
case 60:
#line 140 "lex.lm"
{return keyw(280);}
break;
case 61:
#line 141 "lex.lm"
{return keyw(280);}
break;
case 62:
#line 142 "lex.lm"
{return keyw(262);}
break;
case 63:
#line 143 "lex.lm"
{return keyw(262);}
break;
case 64:
#line 144 "lex.lm"
{return gnukeyw(298);}
break;
case 65:
#line 146 "lex.lm"
{return msdoskeyw(263);}
break;
case 66:
#line 147 "lex.lm"
{return msdoskeyw(263);}
break;
case 67:
#line 148 "lex.lm"
{return msdoskeyw(263);}
break;
case 68:
#line 149 "lex.lm"
{return msdoskeyw(263);}
break;
case 69:
#line 150 "lex.lm"
{return msdoskeyw(263);}
break;
case 70:
#line 151 "lex.lm"
{return msdoskeyw(263);}
break;
case 71:
#line 152 "lex.lm"
{return msdoskeyw(263);}
break;
case 72:
#line 153 "lex.lm"
{return msdoskeyw(263);}
break;
case 73:
#line 154 "lex.lm"
{return msdoskeyw(263);}
break;
case 74:
#line 155 "lex.lm"
{return msdoskeyw(263);}
break;
case 75:
#line 156 "lex.lm"
{return msdoskeyw(263);}
break;
case 76:
#line 157 "lex.lm"
{return msdoskeyw(263);}
break;
case 77:
#line 158 "lex.lm"
{return msdoskeyw(263);}
break;
case 78:
#line 159 "lex.lm"
{return msdoskeyw(263);}
break;
case 79:
#line 160 "lex.lm"
{return msdoskeyw(263);}
break;
case 80:
#line 162 "lex.lm"
{

return(o_llkeyw)?keyw(261):identif();
}
break;
case 81:
#line 167 "lex.lm"
{

return watcomkeyw(261);
}
break;
case 82:
#line 171 "lex.lm"
{return watcomkeyw(263);}
break;
case 83:
#line 172 "lex.lm"
{return watcomkeyw(263);}
break;
case 84:
#line 173 "lex.lm"
{return watcomkeyw(263);}
break;
case 85:
#line 174 "lex.lm"
{return watcomkeyw(263);}
break;
case 86:
#line 175 "lex.lm"
{return watcomkeyw(263);}
break;
case 87:
#line 176 "lex.lm"
{return watcomkeyw(263);}
break;
case 88:
#line 177 "lex.lm"
{return watcomkeyw(263);}
break;
case 89:
#line 178 "lex.lm"
{return watcomkeyw(263);}
break;
case 90:
#line 179 "lex.lm"
{return watcomkeyw(263);}
break;
case 91:
#line 180 "lex.lm"
{return watcomkeyw(263);}
break;
case 92:
#line 181 "lex.lm"
{return watcomkeyw(263);}
break;
case 93:
#line 182 "lex.lm"
{return watcomkeyw(263);}
break;
case 94:
#line 183 "lex.lm"
{return watcomkeyw(263);}
break;
case 95:
#line 184 "lex.lm"
{return watcomkeyw(263);}
break;
case 96:
#line 185 "lex.lm"
{return watcomkeyw(263);}
break;
case 97:
#line 187 "lex.lm"
{return ibmvackeyw(263);}
break;
case 98:
#line 188 "lex.lm"
{return ibmvackeyw(263);}
break;
case 99:
#line 189 "lex.lm"
{return ibmvackeyw(263);}
break;
case 100:
#line 191 "lex.lm"
{
okblock=0;
return'(';
}
break;
case 101:
#line 195 "lex.lm"
{return')';}
break;
case 102:
#line 196 "lex.lm"
{return'[';}
break;
case 103:
#line 197 "lex.lm"
{return']';}
break;
case 104:
#line 198 "lex.lm"
{return keyw(290);}
break;
case 105:
#line 199 "lex.lm"
{return'.';}
break;
case 106:
#line 200 "lex.lm"
{return'!';}
break;
case 107:
#line 201 "lex.lm"
{return'~';}
break;
case 108:
#line 202 "lex.lm"
{return keyw(287);}
break;
case 109:
#line 203 "lex.lm"
{return keyw(287);}
break;
case 110:
#line 204 "lex.lm"
{return'*';}
break;
case 111:
#line 205 "lex.lm"
{return'/';}
break;
case 112:
#line 206 "lex.lm"
{return'%';}
break;
case 113:
#line 207 "lex.lm"
{return'+';}
break;
case 114:
#line 208 "lex.lm"
{return'-';}
break;
case 115:
#line 209 "lex.lm"
{return keyw(286);}
break;
case 116:
#line 210 "lex.lm"
{return keyw(286);}
break;
case 117:
#line 211 "lex.lm"
{return keyw(285);}
break;
case 118:
#line 212 "lex.lm"
{return keyw(285);}
break;
case 119:
#line 213 "lex.lm"
{return keyw(285);}
break;
case 120:
#line 214 "lex.lm"
{return keyw(285);}
break;
case 121:
#line 215 "lex.lm"
{return keyw(284);}
break;
case 122:
#line 216 "lex.lm"
{return keyw(285);}
break;
case 123:
#line 217 "lex.lm"
{return'&';}
break;
case 124:
#line 218 "lex.lm"
{return'^';}
break;
case 125:
#line 219 "lex.lm"
{return'|';}
break;
case 126:
#line 220 "lex.lm"
{return 288;}
break;
case 127:
#line 221 "lex.lm"
{return 289;}
break;
case 128:
#line 222 "lex.lm"
{return'?';}
break;
case 129:
#line 223 "lex.lm"
{return':';}
break;
case 130:
#line 224 "lex.lm"
{return'=';}
break;
case 131:
#line 225 "lex.lm"
{return keyw(283);}
break;
case 132:
#line 226 "lex.lm"
{return keyw(283);}
break;
case 133:
#line 227 "lex.lm"
{return keyw(283);}
break;
case 134:
#line 228 "lex.lm"
{return keyw(283);}
break;
case 135:
#line 229 "lex.lm"
{return keyw(283);}
break;
case 136:
#line 230 "lex.lm"
{return keyw(283);}
break;
case 137:
#line 231 "lex.lm"
{return keyw(283);}
break;
case 138:
#line 232 "lex.lm"
{return keyw(283);}
break;
case 139:
#line 233 "lex.lm"
{return keyw(283);}
break;
case 140:
#line 234 "lex.lm"
{return keyw(283);}
break;
case 141:
#line 235 "lex.lm"
{return',';}
break;
case 142:
#line 236 "lex.lm"
{return';';}
break;
case 143:
#line 237 "lex.lm"
{return keyw((okblock)?(okblock=0,297):('{'));}
break;
case 144:
#line 238 "lex.lm"
{return keyw('}');}
break;
case 145:
#line 240 "lex.lm"
{return keyw(282);}
break;
case 146:
#line 242 "lex.lm"
{return keyw(294);}
break;
case 147:
#line 244 "lex.lm"
{;}
break;
case 148:
#line 246 "lex.lm"
{inlineno++;}
break;
case 149:
#line 248 "lex.lm"
{

yylval=mkcppdirect(yytext);
if(yylval){inlineno++;return 265;}
}
break;
case 150:
#line 254 "lex.lm"
{
return tkeyw(259,t_str);
}
break;
case 151:
#line 258 "lex.lm"
{


return tkeyw(258,t_char);
}
break;
case 152:
#line 264 "lex.lm"
{
return tkeyw(258,t_int);
}
break;
case 153:
#line 268 "lex.lm"
{
return tkeyw(258,t_int);
}
break;
case 154:
#line 272 "lex.lm"
{
return tkeyw(258,t_int);
}
break;
case 155:
#line 276 "lex.lm"
{
return tkeyw(258,t_double);
}
break;
case 156:
#line 280 "lex.lm"
{
return tkeyw(258,t_double);
}
break;
case 157:
#line 284 "lex.lm"
{
return tkeyw(258,t_double);
}
break;
case 158:
#line 288 "lex.lm"
{
return identif();
}
break;
case 159:
#line 292 "lex.lm"
{;

}
break;
case 160:
#line 296 "lex.lm"
{
if(o_warnlex){
char c=(yytext)[0];
warn("lex ignoring '0x%x' (%c)",(int)c,c);
}
}
break;
case 161:(
#line 303 "lex.lm"
void)fwrite(yytext,yyleng,1,yyout);
break;
#line 1953 "lex.yy.c"
case(162+0+1):
return 0;

case 162:
{

int yy_amount_of_matched_text=(int)(yy_cp-yytext)-1; *


yy_cp=yy_hold_char;


if(yy_current_buffer->yy_buffer_status==0)
{
#line 1976 "lex.yy.c"
yy_n_chars=yy_current_buffer->yy_n_chars;
yy_current_buffer->yy_input_file=yyin;
yy_current_buffer->yy_buffer_status=1;
}
#line 1988 "lex.yy.c"
if(yy_c_buf_p<= &yy_current_buffer->yy_ch_buf[yy_n_chars])
{
yy_state_type yy_next_state;

yy_c_buf_p=yytext+yy_amount_of_matched_text;

yy_current_state=yy_get_previous_state();
#line 2005 "lex.yy.c"
yy_next_state=yy_try_NUL_trans(yy_current_state);

yy_bp=yytext+0;

if(yy_next_state)
{

yy_cp= ++yy_c_buf_p;
yy_current_state=yy_next_state;
goto yy_match;
}

else
{
yy_cp=yy_c_buf_p;
goto yy_find_action;
}
}

else switch(yy_get_next_buffer())
{
case 1:
{
yy_did_buffer_switch_on_eof=0;

if(yywrap())
{
#line 2041 "lex.yy.c"
yy_c_buf_p=yytext+0;

yy_act=(162+((yy_start-1)/2)+1);
goto do_action;
}

else
{
if( !yy_did_buffer_switch_on_eof)
yyrestart(yyin);
}
break;
}

case 0:
yy_c_buf_p=
yytext+yy_amount_of_matched_text;

yy_current_state=yy_get_previous_state();

yy_cp=yy_c_buf_p;
yy_bp=yytext+0;
goto yy_match;

case 2:
yy_c_buf_p= &
yy_current_buffer->yy_ch_buf[yy_n_chars];

yy_current_state=yy_get_previous_state();

yy_cp=yy_c_buf_p;
yy_bp=yytext+0;
goto yy_find_action;
}
break;
}

default:
yy_fatal_error(
"fatal flex scanner internal error--no action found");
}
}
}

#line 2094 "lex.yy.c"
static int yy_get_next_buffer()
{
register char*dest=yy_current_buffer->yy_ch_buf;
register char*source=yytext;
register int number_to_move,i;
int ret_val;

if(yy_c_buf_p> &yy_current_buffer->yy_ch_buf[yy_n_chars+1])
yy_fatal_error(
"fatal flex scanner internal error--end of buffer missed");

if(yy_current_buffer->yy_fill_buffer==0)
{
if(yy_c_buf_p-yytext-0==1)
{
#line 2112 "lex.yy.c"
return 1;
}

else
{
#line 2120 "lex.yy.c"
return 2;
}
}
#line 2127 "lex.yy.c"
number_to_move=(int)(yy_c_buf_p-yytext)-1;

for(i=0;i<number_to_move; ++i) *(
dest++)= *(source++);

if(yy_current_buffer->yy_buffer_status==2)
#line 2136 "lex.yy.c"
yy_current_buffer->yy_n_chars=yy_n_chars=0;

else
{
int num_to_read=
yy_current_buffer->yy_buf_size-number_to_move-1;

while(num_to_read<=0)
{
#line 2151 "lex.yy.c"
YY_BUFFER_STATE b=yy_current_buffer;

int yy_c_buf_p_offset=(
int)(yy_c_buf_p-b->yy_ch_buf);

if(b->yy_is_our_buffer)
{
int new_size=b->yy_buf_size*2;

if(new_size<=0)
b->yy_buf_size+=b->yy_buf_size/8;
else
b->yy_buf_size*=2;

b->yy_ch_buf=(char*)

yy_flex_realloc((void*)b->yy_ch_buf,
b->yy_buf_size+2);
}
else

b->yy_ch_buf=0;

if( !b->yy_ch_buf)
yy_fatal_error(
"fatal error - scanner input buffer overflow");

yy_c_buf_p= &b->yy_ch_buf[yy_c_buf_p_offset];

num_to_read=yy_current_buffer->yy_buf_size-
number_to_move-1;

}

if(num_to_read>8192)
num_to_read=8192;


if(yy_current_buffer->yy_is_interactive){int c='*',n;for(n=0;n<num_to_read&&(c=getc(yyin))!=EOF&&c!='\n'; ++n)( &yy_current_buffer->yy_ch_buf[number_to_move])[n]=(char)c;if(c=='\n')( &yy_current_buffer->yy_ch_buf[number_to_move])[n++]=(char)c;if(c==EOF&&ferror(yyin))yy_fatal_error("input in flex scanner failed");
yy_n_chars=n;}else if(((yy_n_chars=fread(( &yy_current_buffer->yy_ch_buf[number_to_move]),1,num_to_read,yyin))==0)&&ferror(yyin))yy_fatal_error("input in flex scanner failed");;

yy_current_buffer->yy_n_chars=yy_n_chars;
}

if(yy_n_chars==0)
{
if(number_to_move==0)
{
ret_val=1;
yyrestart(yyin);
}

else
{
ret_val=2;
yy_current_buffer->yy_buffer_status=
2;
}
}

else
ret_val=0;

yy_n_chars+=number_to_move;
yy_current_buffer->yy_ch_buf[yy_n_chars]=0;
yy_current_buffer->yy_ch_buf[yy_n_chars+1]=0;

yytext= &yy_current_buffer->yy_ch_buf[0];

return ret_val;
}

#line 2226 "lex.yy.c"
static yy_state_type yy_get_previous_state()
{
register yy_state_type yy_current_state;
register char*yy_cp;

yy_current_state=yy_start;

for(yy_cp=yytext+0;yy_cp<yy_c_buf_p; ++yy_cp)
{
register YY_CHAR yy_c=( *yy_cp?yy_ec[((unsigned int)(unsigned char) *yy_cp)]:1);
if(yy_accept[yy_current_state])
{
yy_last_accepting_state=yy_current_state;
yy_last_accepting_cpos=yy_cp;
}
while(yy_chk[yy_base[yy_current_state]+yy_c]!=yy_current_state)
{
yy_current_state=(int)yy_def[yy_current_state];
if(yy_current_state>=624)
yy_c=yy_meta[(unsigned int)yy_c];
}
yy_current_state=yy_nxt[yy_base[yy_current_state]+(unsigned int)yy_c];
}

return yy_current_state;
}

#line 2261 "lex.yy.c"
static yy_state_type yy_try_NUL_trans(yy_state_type yy_current_state)
#line 2266 "lex.yy.c"
{
register int yy_is_jam;
register char*yy_cp=yy_c_buf_p;

register YY_CHAR yy_c=1;
if(yy_accept[yy_current_state])
{
yy_last_accepting_state=yy_current_state;
yy_last_accepting_cpos=yy_cp;
}
while(yy_chk[yy_base[yy_current_state]+yy_c]!=yy_current_state)
{
yy_current_state=(int)yy_def[yy_current_state];
if(yy_current_state>=624)
yy_c=yy_meta[(unsigned int)yy_c];
}
yy_current_state=yy_nxt[yy_base[yy_current_state]+(unsigned int)yy_c];
yy_is_jam=(yy_current_state==623);

return yy_is_jam?0:yy_current_state;
}

#line 2291 "lex.yy.c"
static void yyunput(int c,char*yy_bp)
#line 2297 "lex.yy.c"
{
register char*yy_cp=yy_c_buf_p; *


yy_cp=yy_hold_char;

if(yy_cp<yy_current_buffer->yy_ch_buf+2)
{

register int number_to_move=yy_n_chars+2;
register char*dest= &yy_current_buffer->yy_ch_buf[
yy_current_buffer->yy_buf_size+2];
register char*source= &
yy_current_buffer->yy_ch_buf[number_to_move];

while(source>yy_current_buffer->yy_ch_buf) * --
dest= * --source;

yy_cp+=(int)(dest-source);
yy_bp+=(int)(dest-source);
yy_current_buffer->yy_n_chars=
yy_n_chars=yy_current_buffer->yy_buf_size;

if(yy_cp<yy_current_buffer->yy_ch_buf+2)
yy_fatal_error("flex scanner push-back overflow");
} * --

yy_cp=(char)c;


yytext=yy_bp;
yy_hold_char= *yy_cp;
yy_c_buf_p=yy_cp;
}

#line 2337 "lex.yy.c"
static int input()

{
int c; *

yy_c_buf_p=yy_hold_char;

if( *yy_c_buf_p==0)
{
#line 2350 "lex.yy.c"
if(yy_c_buf_p< &yy_current_buffer->yy_ch_buf[yy_n_chars]) *

yy_c_buf_p='\0';

else
{
int offset=yy_c_buf_p-yytext; ++
yy_c_buf_p;

switch(yy_get_next_buffer())
{
case 2:
#line 2373 "lex.yy.c"
yyrestart(yyin);
#line 2377 "lex.yy.c"
case 1:
{
if(yywrap())
return EOF;

if( !yy_did_buffer_switch_on_eof)
yyrestart(yyin);
#line 2387 "lex.yy.c"
return input();

}

case 0:
yy_c_buf_p=yytext+offset;
break;
}
}
}

c= *(unsigned char*)yy_c_buf_p; *
yy_c_buf_p='\0';
yy_hold_char= * ++yy_c_buf_p;


return c;
}



void yyrestart(FILE*input_file)
#line 2413 "lex.yy.c"
{
if( !yy_current_buffer)
yy_current_buffer=yy_create_buffer(yyin,16384);

yy_init_buffer(yy_current_buffer,input_file);
yy_load_buffer_state();
}



void yy_switch_to_buffer(YY_BUFFER_STATE new_buffer)
#line 2428 "lex.yy.c"
{
if(yy_current_buffer==new_buffer)
return;

if(yy_current_buffer)
{ *

yy_c_buf_p=yy_hold_char;
yy_current_buffer->yy_buf_pos=yy_c_buf_p;
yy_current_buffer->yy_n_chars=yy_n_chars;
}

yy_current_buffer=new_buffer;
yy_load_buffer_state();
#line 2448 "lex.yy.c"
yy_did_buffer_switch_on_eof=1;
}



void yy_load_buffer_state(void)
#line 2457 "lex.yy.c"
{
yy_n_chars=yy_current_buffer->yy_n_chars;
yytext=yy_c_buf_p=yy_current_buffer->yy_buf_pos;
yyin=yy_current_buffer->yy_input_file;
yy_hold_char= *yy_c_buf_p;
}



YY_BUFFER_STATE yy_create_buffer(FILE*file,int size)
#line 2472 "lex.yy.c"
{
YY_BUFFER_STATE b;

b=(YY_BUFFER_STATE)yy_flex_alloc(sizeof(struct yy_buffer_state));
if( !b)
yy_fatal_error("out of dynamic memory in yy_create_buffer()");

b->yy_buf_size=size;
#line 2484 "lex.yy.c"
b->yy_ch_buf=(char*)yy_flex_alloc(b->yy_buf_size+2);
if( !b->yy_ch_buf)
yy_fatal_error("out of dynamic memory in yy_create_buffer()");

b->yy_is_our_buffer=1;

yy_init_buffer(b,file);

return b;
}



void yy_delete_buffer(YY_BUFFER_STATE b)
#line 2502 "lex.yy.c"
{
if( !b)
return;

if(b==yy_current_buffer)
yy_current_buffer=(YY_BUFFER_STATE)0;

if(b->yy_is_our_buffer)
yy_flex_free((void*)b->yy_ch_buf);

yy_flex_free((void*)b);
}

#line 2523 "lex.yy.c"
void yy_init_buffer(YY_BUFFER_STATE b,FILE*file)
#line 2531 "lex.yy.c"
{
yy_flush_buffer(b);

b->yy_input_file=file;
b->yy_fill_buffer=1;
#line 2541 "lex.yy.c"
b->yy_is_interactive=0;
#line 2546 "lex.yy.c"
}



void yy_flush_buffer(YY_BUFFER_STATE b)
#line 2556 "lex.yy.c"
{
if( !b)
return;

b->yy_n_chars=0;
#line 2566 "lex.yy.c"
b->yy_ch_buf[0]=0;
b->yy_ch_buf[1]=0;

b->yy_buf_pos= &b->yy_ch_buf[0];

b->yy_at_bol=1;
b->yy_buffer_status=0;

if(b==yy_current_buffer)
yy_load_buffer_state();
}

#line 2581 "lex.yy.c"
YY_BUFFER_STATE yy_scan_buffer(char*base,yy_size_t size)
#line 2587 "lex.yy.c"
{
YY_BUFFER_STATE b;

if(size<2||
base[size-2]!=0||
base[size-1]!=0)

return 0;

b=(YY_BUFFER_STATE)yy_flex_alloc(sizeof(struct yy_buffer_state));
if( !b)
yy_fatal_error("out of dynamic memory in yy_scan_buffer()");

b->yy_buf_size=size-2;
b->yy_buf_pos=b->yy_ch_buf=base;
b->yy_is_our_buffer=0;
b->yy_input_file=0;
b->yy_n_chars=b->yy_buf_size;
b->yy_is_interactive=0;
b->yy_at_bol=1;
b->yy_fill_buffer=0;
b->yy_buffer_status=0;

yy_switch_to_buffer(b);

return b;
}

#line 2619 "lex.yy.c"
YY_BUFFER_STATE yy_scan_string(const char*yy_str)
#line 2624 "lex.yy.c"
{
int len;
for(len=0;yy_str[len]; ++len);


return yy_scan_bytes(yy_str,len);
}

#line 2636 "lex.yy.c"
YY_BUFFER_STATE yy_scan_bytes(const char*bytes,int len)
#line 2642 "lex.yy.c"
{
YY_BUFFER_STATE b;
char*buf;
yy_size_t n;
int i;


n=len+2;
buf=(char*)yy_flex_alloc(n);
if( !buf)
yy_fatal_error("out of dynamic memory in yy_scan_bytes()");

for(i=0;i<len; ++i)
buf[i]=bytes[i];

buf[len]=buf[len+1]=0;

b=yy_scan_buffer(buf,n);
if( !b)
yy_fatal_error("bad buffer in yy_scan_bytes()");
#line 2666 "lex.yy.c"
b->yy_is_our_buffer=1;

return b;
}

#line 2730 "lex.yy.c"
static void yy_fatal_error(const char msg[])
#line 2735 "lex.yy.c"
{(
void)fprintf(stderr,"%s\n",msg);
exit(2);
}

#line 2794 "lex.yy.c"
static void*yy_flex_alloc(yy_size_t size)
#line 2799 "lex.yy.c"
{
return(void*)malloc(size);
}


static void*yy_flex_realloc(void*ptr,yy_size_t size)
#line 2810 "lex.yy.c"
{
#line 2818 "lex.yy.c"
return(void*)realloc((char*)ptr,size);
}


static void yy_flex_free(void*ptr)
#line 2827 "lex.yy.c"
{
free(ptr);
}

#line 310 "lex.lm"
void yyerror(char*str)
{
fatal("%s \"%s\"",str,yytext);
}

#line 318 "lex.lm"
int yywrap(){return 1;}

#line 58 "../oclib/symbol.h"
extern id  Symbol;

#line 321 "lex.lm"
int identif(void)
{
id objcT0;

#line 323 "lex.lm"
yylval=(objcT0=Symbol,(*(id(*)(id,SEL,char*,int,id))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0],yytext,inlineno,infilename));
if(isbuiltinfun(yylval))return 260;
if(istypeword(yylval))return 261;
return 257;
}

#line 22 "../oclib/stclass.h"
extern id  Storageclass;

#line 329 "lex.lm"
int keyw(int x)
{
if(x==262||x==264){
id objcT1;

#line 332 "lex.lm"
yylval=(objcT1=Storageclass,(*(id(*)(id,SEL,char*,int,id))_imp(objcT1,selTransTbl[0]))(objcT1,selTransTbl[0],yytext,inlineno,infilename));
}else{
id objcT2;

#line 334 "lex.lm"
yylval=(objcT2=Symbol,(*(id(*)(id,SEL,char*,int,id))_imp(objcT2,selTransTbl[0]))(objcT2,selTransTbl[0],yytext,inlineno,infilename));
}
return x;
}

int tkeyw(int x,id t)
{
id objcT3,objcT4;

#line 341 "lex.lm"
yylval=(objcT3=Symbol,(*(id(*)(id,SEL,char*,int,id))_imp(objcT3,selTransTbl[0]))(objcT3,selTransTbl[0],yytext,inlineno,infilename));
(objcT4=yylval,(*_imp(objcT4,selTransTbl[1]))(objcT4,selTransTbl[1],t));
return x;
}

int gnukeyw(int x)
{
return(o_gnu)?keyw(x):identif();
}

int msdoskeyw(int x)
{
return(o_msdos)?keyw(x):identif();
}

int watcomkeyw(int x)
{
return(o_watcom)?keyw(x):identif();
}

int ibmvackeyw(int x)
{
return(o_ibmvac)?keyw(x):identif();
}
static char *_selTransTbl[] ={
"str:lineno:filename:",
"type:",
0
};
struct modDescriptor lex_modDesc = {
  "lex",
  "objc2.3.1",
  0L,
  0,
  0,
  0,
  2,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_lex(void)
{
  selTransTbl = _selTransTbl;
  return &lex_modDesc;
}
int _OBJCPOSTLINK_lex = 1;


