#line 1 "blockxpr.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_blockxpr(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor blockxpr_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 31 "../../include/objpak/ordcltn.h"
typedef struct objcol{
int count;
int capacity;
id*ptr;
}*objcol_t;
#line 28 "../../include/objpak/set.h"
typedef struct objset{
int count;
int capacity;
id*ptr;
}*objset_t;
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "expr.h"
extern id e_nil;
extern id e_self;
extern id e_cmd;
extern id e_super;
extern id e_aFiler;
extern id e_ft_id;
#line 22 "blockxpr.h"
extern id curcompound;
#line 22 "compstmt.h"
extern id curcompound;
extern id curloopcompound;
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 22 "def.h"
extern id curdef;
#line 22 "classdef.h"
extern id curclassdef;
extern id curstruct;
#line 22 "trlunit.h"
extern id trlunit;
#line 23 "util.h"
extern FILE*yyin;
extern int yyparse();

FILE*openfile(STR name,STR modfs);
FILE*reopenfile(STR name,STR modfs,FILE*of);

extern int okblock;

id mkcppdirect(char*s);
id mkexprstmt(id expr);
id mklabeledstmt(id label,id stmt);
id mkcasestmt(id keyw,id expr,id stmt);
id mkdefaultstmt(id keyw,id stmt);
id mkifstmt(id keyw,id expr,id stmt);
id mkifelsestmt(id keyw,id expr,id stmt,id ekeyw,id estmt);
id mkswitchstmt(id keyw,id expr,id stmt);
id mkwhilestmt(id keyw,id expr,id stmt);
id mkdostmt(id keyw,id stmt,id wkeyw,id expr);
id mkforstmt(id keyw,id a,id b,id c,id stmt);
id mkgotostmt(id keyw,id label);
id mkcontinuestmt(id keyw);
id mkbreakstmt(id keyw);
id mkreturnstmt(id keyw,id expr);
id mkcastexpr(id a,id b);
id mkcondexpr(id a,id b,id c);
id mkunaryexpr(STR op,id a);
id mksizeof(id a);
id mkaddressof(id a);
id mkdereference(id a);
id mkbinexpr(id a,STR op,id b);
id mkcommaexpr(id a,id b);
id mkrelexpr(id a,STR op,id b);
id mkassignexpr(id a,STR op,id b);
id mkfuncall(id funname,id args);
id mkbuiltincall(id funname,id args);
id mkfunbody(id datadefs,id compound);
void declarefun(id specs,id decl);
void declaremeth(BOOL factory,id decl);
id mkfundef(id specs,id decl,id body);
id mkmethdef(BOOL factory,id decl,id body);
id mkmesgexpr(id receiver,id args);
id mkdecl(id ident);
id mkprecdecl(id tquals,id decl);
id mkarraydecl(id lhs,id ix);
id mkfundecl(id lhs,id args);
id mkprefixdecl(id lhs,id rhs);
id mkpostfixdecl(id lhs,id rhs);
id mkpointer(id specs,id pointer);
id mkbitfielddecl(id decl,id expr);
id mkstardecl(id pointer,id decl);
id mkasmop(id string,id expr);
id mkasmstmt(id keyw,id tqual,id expr,id asmop1,id asmop2,id clobbers);
id mkcompstmt(id lb,id datadefs,id stmtlist,id rb);
id mklist(id c,id s);
id mklist2(id c,id s,id t);
id atdefsaddall(id c,id n);
id mkblockexpr(id lb,id parms,id datadefs,id stmts,id expr,id rb);
id mkclassdef(id keyw,id name,id sname,id ivars,id cvars);
id mkdatadef(id datadef,id specs,id decl,id initializer);
id mkencodeexpr(id name);
id mkenumspec(id keyw,id name,id lb,id list,id rb);
id mkenumerator(id name,id value);
id mkgnuattrib(id anyword,id exprlist);
id mkgnuattribdecl(id keyw,id list);
id mklistexpr(id lb,id x,id rb);
id mktypename(id specs,id decl);
id mkcomponentdef(id cdef,id specs,id decl);
id mkstructspec(id keyw,id name,id lb,id defs,id rb);
id mkkeywarg(id sel,id arg);
id mkkeywdecl(id sel,id cast,id arg);
id mkmethproto(id cast,id usel,id ksel,BOOL varargs);
id mkidentexpr(id name);
id mkconstexpr(id name,id schain);
id mkprecexpr(id expr);
id mkarrowexpr(id array,id ix);
id mkdotexpr(id array,id ix);
id mkindexexpr(id array,id ix);
id mkpostfixexpr(id expr,id pf);
id mkparmdef(id parmdef,id specs,id decl);
id mkparmdeflist(id idents,id parmdefs,BOOL varargs);
id mkselarg(id selarg,id usel,int ncols);
id mkselectorexpr(id expr);

void procextdef(id def);
void finclassdef(void);
void datadefokblock(id datadef,id specs,id decl);

id mkfileinmeth(id classdef,id ivarnames,id ivartypes);
id mkfileoutmeth(id classdef,id ivarnames,id ivartypes);

id mkincrefsmeth(id classdef,id ivarnames,id ivartypes);
id mkdecrefsmeth(id classdef,id ivarnames,id ivartypes);
#line 24 "blockxpr.h"
struct BlockExpr_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 31 "expr.h"
id type;
#line 26 "blockxpr.h"
id lbrace,rbrace;
id parms,datadefs,stmts,expr;
id initializers;
id parmnames,parmtypes;
id enclosing;
id enclosingdef;
id tmpvars;
id icaches;
id locals;
id localdic;
id alllocals;
id heapvars,heapnames,heaptypes;
id heapparms;
char*heapvarptrname;
char*heapvartypename;
id localexprs;
int numparms;
int numheapvarblocks;
id heapvarblocks;
int blockcount;
char*blkconsname;
char*blkdtorname;
char*blkfunname;
char*blkdataname;
char*blktypename;
id restype;
id returnlabel;
id refvar;
id increfs,decrefs;};

#line 24 "blockxpr.h"
extern id  BlockExpr;

#line 24 "blockxpr.h"
extern struct _SHARED _BlockExpr;
extern struct _SHARED __BlockExpr;


#line 50 "blockxpr.m"
static id i_BlockExpr_blockcount_(struct BlockExpr_PRIVATE *self,SEL _cmd,int x)
{self->
blockcount=x;
return(id)self;
}

static id c_BlockExpr_new(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT0,objcT1,objcT2,objcT3;

#line 58 "blockxpr.m"
(objcT0=trlunit,(*(id(*)(id,SEL,BOOL))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0],(BOOL)1));
return(objcT1=(objcT2=__BlockExpr.clsSuper,(*_impSuper(objcT2,selTransTbl[1]))((id)self,selTransTbl[1])),(*(id(*)(id,SEL,int))_imp(objcT1,selTransTbl[2]))(objcT1,selTransTbl[2],(objcT3=trlunit,(*(int(*)(id,SEL))_imp(objcT3,selTransTbl[3]))(objcT3,selTransTbl[3]))));
}

static BOOL i_BlockExpr_isblockexpr(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
return(BOOL)1;
}

static id i_BlockExpr_lbrace_(struct BlockExpr_PRIVATE *self,SEL _cmd,id lb)
{self->
lbrace=lb;
return(id)self;
}

static id i_BlockExpr_rbrace_(struct BlockExpr_PRIVATE *self,SEL _cmd,id rb)
{self->
rbrace=rb;
return(id)self;
}

#line 37 "../../include/objpak/ordcltn.h"
extern id  OrdCltn;

#line 79 "blockxpr.m"
static id i_BlockExpr_defparm_astype_(struct BlockExpr_PRIVATE *self,SEL _cmd,id sym,id t)
{
id objcT5,objcT6;

#line 81 "blockxpr.m"
if( !self->parmnames){
id objcT4;
self->
#line 82 "blockxpr.m"
parmnames=(objcT4=OrdCltn,(*_imp(objcT4,selTransTbl[1]))(objcT4,selTransTbl[1]));
}
(objcT5=self->parmnames,(*_imp(objcT5,selTransTbl[4]))(objcT5,selTransTbl[4],sym));
assert((objcT6=t,(*(BOOL(*)(id,SEL))_imp(objcT6,selTransTbl[5]))(objcT6,selTransTbl[5])));
return(id)self;
}

#line 22 "keywdecl.h"
extern id  KeywDecl;

#line 89 "blockxpr.m"
static id i_BlockExpr_parms_(struct BlockExpr_PRIVATE *self,SEL _cmd,id aList)
{
id objcT7,objcT8;
int i,n;self->

parms=(objcT7=OrdCltn,(*_imp(objcT7,selTransTbl[1]))(objcT7,selTransTbl[1]));
for(i=0,n=(objcT8=aList,(*(unsigned(*)(id,SEL))_imp(objcT8,selTransTbl[6]))(objcT8,selTransTbl[6]));i<n;i++){
id objcT9,objcT10,objcT11,objcT12;

#line 96 "blockxpr.m"
(objcT9=self->parms,(*_imp(objcT9,selTransTbl[4]))(objcT9,selTransTbl[4],(objcT10=(objcT11=KeywDecl,(*_imp(objcT11,selTransTbl[1]))(objcT11,selTransTbl[1])),(*_imp(objcT10,selTransTbl[7]))(objcT10,selTransTbl[7],(objcT12=aList,(*(id(*)(id,SEL,unsigned))_imp(objcT12,selTransTbl[8]))(objcT12,selTransTbl[8],i))))));
}self->
parmnames=aList;
#line 102 "blockxpr.m"
return(id)self;
}

static id i_BlockExpr_datadefs_(struct BlockExpr_PRIVATE *self,SEL _cmd,id aList)
{self->
datadefs=aList;
return(id)self;
}

static id i_BlockExpr_stmts_(struct BlockExpr_PRIVATE *self,SEL _cmd,id aList)
{self->
stmts=aList;
return(id)self;
}

static id i_BlockExpr_expr_(struct BlockExpr_PRIVATE *self,SEL _cmd,id anExpr)
{self->
expr=anExpr;
return(id)self;
}

static id i_BlockExpr_lookupparm_(struct BlockExpr_PRIVATE *self,SEL _cmd,id sym)
{
id objcT13;

#line 125 "blockxpr.m"
if(self->parmnames&&(objcT13=self->parmnames,(*_imp(objcT13,selTransTbl[9]))(objcT13,selTransTbl[9],sym)))
return t_id;
return(id)0;
}

static id i_BlockExpr_returnlabel(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
return self->returnlabel;
}

static int i_BlockExpr_lineno(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT14;

#line 137 "blockxpr.m"
return(objcT14=self->lbrace,(*(int(*)(id,SEL))_imp(objcT14,selTransTbl[10]))(objcT14,selTransTbl[10]));
}

static id i_BlockExpr_filename(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT15;

#line 142 "blockxpr.m"
return(objcT15=self->lbrace,(*_imp(objcT15,selTransTbl[11]))(objcT15,selTransTbl[11]));
}

#line 38 "../../include/objpak/ocstring.h"
extern id  String;

#line 145 "blockxpr.m"
static id i_BlockExpr_synth(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT16,objcT18,objcT19,objcT20,objcT21;
id objcT22,objcT23,objcT24,objcT25,objcT26;
id objcT27,objcT28,objcT29,objcT30,objcT31;
id objcT32,objcT33;

#line 147 "blockxpr.m"
if(o_refcnt)self->
returnlabel=(objcT16=trlunit,(*_imp(objcT16,selTransTbl[12]))(objcT16,selTransTbl[12]));

if( !o_blocks){
fatalat(self->lbrace,"blocks not allowed with -noBlocks");
return(id)self;
}
if(curdef){
id objcT17;

#line 155 "blockxpr.m"
(objcT17=curdef,(*_imp(objcT17,selTransTbl[13]))(objcT17,selTransTbl[13],(id)self));
}else{
fatalat(self->lbrace,"block expression outside method or function definition");
}self->
enclosing=curcompound;
curcompound=(id)self;
#line 168 "blockxpr.m"
if(self->datadefs)
(objcT18=self->datadefs,(*(id(*)(id,SEL,SEL))_imp(objcT18,selTransTbl[14]))(objcT18,selTransTbl[14],_cmd));
if(self->stmts)
(objcT19=self->stmts,(*(id(*)(id,SEL,SEL))_imp(objcT19,selTransTbl[14]))(objcT19,selTransTbl[14],_cmd));
if(self->expr)
(objcT20=self->expr,(*_imp(objcT20,selTransTbl[15]))(objcT20,selTransTbl[15]));self->
numparms=(self->parms)?(objcT21=self->parms,(*(unsigned(*)(id,SEL))_imp(objcT21,selTransTbl[6]))(objcT21,selTransTbl[6])):0;self->
blkconsname=(objcT22=(objcT23=String,(*(id(*)(id,SEL,STR,...))_imp(objcT23,selTransTbl[16]))(objcT23,selTransTbl[16],"newblk%i",self->blockcount)),(*(STR(*)(id,SEL))_imp(objcT22,selTransTbl[17]))(objcT22,selTransTbl[17]));self->
blkdtorname=(objcT24=(objcT25=String,(*(id(*)(id,SEL,STR,...))_imp(objcT25,selTransTbl[16]))(objcT25,selTransTbl[16],"clearblk%i",self->blockcount)),(*(STR(*)(id,SEL))_imp(objcT24,selTransTbl[17]))(objcT24,selTransTbl[17]));self->
blkfunname=(objcT26=(objcT27=String,(*(id(*)(id,SEL,STR,...))_imp(objcT27,selTransTbl[16]))(objcT27,selTransTbl[16],"blkfun%i",self->blockcount)),(*(STR(*)(id,SEL))_imp(objcT26,selTransTbl[17]))(objcT26,selTransTbl[17]));self->
blkdataname=(objcT28=(objcT29=String,(*(id(*)(id,SEL,STR,...))_imp(objcT29,selTransTbl[16]))(objcT29,selTransTbl[16],"blkdata%i",self->blockcount)),(*(STR(*)(id,SEL))_imp(objcT28,selTransTbl[17]))(objcT28,selTransTbl[17]));self->
blktypename=(objcT30=(objcT31=String,(*(id(*)(id,SEL,STR,...))_imp(objcT31,selTransTbl[16]))(objcT31,selTransTbl[16],"struct blktype%i",self->blockcount)),(*(STR(*)(id,SEL))_imp(objcT30,selTransTbl[17]))(objcT30,selTransTbl[17]));self->
restype=(self->expr)?(objcT32=self->expr,(*_imp(objcT32,selTransTbl[18]))(objcT32,selTransTbl[18])):t_id;
if(self->heapvars)
(objcT33=(id)self,(*_imp(objcT33,selTransTbl[19]))(objcT33,selTransTbl[19]));
curcompound=self->enclosing;

if(o_refcnt){
id objcT34,objcT35,objcT36,objcT37,objcT43;

#line 186 "blockxpr.m"
int i,n;self->

refvar=(objcT34=trlunit,(*_imp(objcT34,selTransTbl[20]))(objcT34,selTransTbl[20]));
(objcT35=curcompound,(*_imp(objcT35,selTransTbl[21]))(objcT35,selTransTbl[21],self->refvar));
(objcT36=curcompound,(*_imp(objcT36,selTransTbl[22]))(objcT36,selTransTbl[22],self->refvar));
for(i=0,n=(objcT37=self->parmnames,(*(unsigned(*)(id,SEL))_imp(objcT37,selTransTbl[6]))(objcT37,selTransTbl[6]));i<n;i++){
id objcT38,objcT39,objcT40;

#line 192 "blockxpr.m"
id x=(objcT38=self->parmnames,(*(id(*)(id,SEL,unsigned))_imp(objcT38,selTransTbl[8]))(objcT38,selTransTbl[8],i));

if((objcT39=(objcT40=(id)self,(*_imp(objcT40,selTransTbl[23]))(objcT40,selTransTbl[23],x)),(*(BOOL(*)(id,SEL))_imp(objcT39,selTransTbl[5]))(objcT39,selTransTbl[5]))){
id objcT41,objcT42;

#line 195 "blockxpr.m"
(objcT41=(id)self,(*_imp(objcT41,selTransTbl[24]))(objcT41,selTransTbl[24],x));
(objcT42=(id)self,(*_imp(objcT42,selTransTbl[22]))(objcT42,selTransTbl[22],x));
}
}
for(i=0,n=(objcT43=self->locals,(*(unsigned(*)(id,SEL))_imp(objcT43,selTransTbl[6]))(objcT43,selTransTbl[6]));i<n;i++){
id objcT44,objcT45,objcT46,objcT47;

#line 200 "blockxpr.m"
id x=(objcT44=self->locals,(*(id(*)(id,SEL,unsigned))_imp(objcT44,selTransTbl[8]))(objcT44,selTransTbl[8],i));

if((objcT45=(objcT46=(id)self,(*_imp(objcT46,selTransTbl[25]))(objcT46,selTransTbl[25],x)),(*(BOOL(*)(id,SEL))_imp(objcT45,selTransTbl[5]))(objcT45,selTransTbl[5]))&& !(objcT47=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT47,selTransTbl[26]))(objcT47,selTransTbl[26],x))){
id objcT48;

#line 203 "blockxpr.m"
(objcT48=(id)self,(*_imp(objcT48,selTransTbl[22]))(objcT48,selTransTbl[22],x));
}
}
}
return(id)self;
}

static id i_BlockExpr_typesynth(struct BlockExpr_PRIVATE *self,SEL _cmd)
{self->
type=t_id;
return(id)self;
}

static id i_BlockExpr_genblocktype(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
if(self->numheapvarblocks){
int i;

gf("%s {\n",self->blktypename);
for(i=0;i<self->numheapvarblocks;i++){
id objcT49,objcT50,objcT51;

#line 223 "blockxpr.m"
id c=(objcT49=self->heapvarblocks,(*(id(*)(id,SEL,unsigned))_imp(objcT49,selTransTbl[8]))(objcT49,selTransTbl[8],i));
char*hvt=(objcT50=c,(*(char*(*)(id,SEL))_imp(objcT50,selTransTbl[27]))(objcT50,selTransTbl[27]));
char*hvp=(objcT51=c,(*(char*(*)(id,SEL))_imp(objcT51,selTransTbl[28]))(objcT51,selTransTbl[28]));

gf("%s *%s;\n",hvt,hvp);
}
gs("};\n");
}
return(id)self;
}

static id i_BlockExpr_packblockdata(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
int i;

for(i=0;i<self->numheapvarblocks;i++){
id objcT52,objcT53;

#line 239 "blockxpr.m"
id c=(objcT52=self->heapvarblocks,(*(id(*)(id,SEL,unsigned))_imp(objcT52,selTransTbl[8]))(objcT52,selTransTbl[8],i));
char*hvp=(objcT53=c,(*(char*(*)(id,SEL))_imp(objcT53,selTransTbl[28]))(objcT53,selTransTbl[28]));

gf("%s->%s=%s;\n",self->blkdataname,hvp,hvp);
gf("%s->heaprefcnt++;\n",hvp);
}
return(id)self;
}

static id i_BlockExpr_unpackblockdata(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
int i;

for(i=0;i<self->numheapvarblocks;i++){
id objcT54,objcT55,objcT56;

#line 253 "blockxpr.m"
id c=(objcT54=self->heapvarblocks,(*(id(*)(id,SEL,unsigned))_imp(objcT54,selTransTbl[8]))(objcT54,selTransTbl[8],i));
char*hvt=(objcT55=c,(*(char*(*)(id,SEL))_imp(objcT55,selTransTbl[27]))(objcT55,selTransTbl[27]));
char*hvp=(objcT56=c,(*(char*(*)(id,SEL))_imp(objcT56,selTransTbl[28]))(objcT56,selTransTbl[28]));

gf("%s *%s=%s->%s;\n",hvt,hvp,self->blkdataname,hvp);
}
return(id)self;
}

static id i_BlockExpr_genconstructor(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT60;

#line 264 "blockxpr.m"
assert(self->blkconsname);
gf("static id %s(",self->blkconsname);
if( !self->numheapvarblocks){
gs("void");
}else{
int i;
int comma=0;

for(i=0;i<self->numheapvarblocks;i++){
id objcT57,objcT58,objcT59;

#line 273 "blockxpr.m"
id c=(objcT57=self->heapvarblocks,(*(id(*)(id,SEL,unsigned))_imp(objcT57,selTransTbl[8]))(objcT57,selTransTbl[8],i));
char*hvt=(objcT58=c,(*(char*(*)(id,SEL))_imp(objcT58,selTransTbl[27]))(objcT58,selTransTbl[27]));
char*hvp=(objcT59=c,(*(char*(*)(id,SEL))_imp(objcT59,selTransTbl[28]))(objcT59,selTransTbl[28]));

if(comma)
gc(',');
else
comma++;
gf("%s *%s",hvt,hvp);
}
}
gs(")\n");
gs("{\n");
if(self->numheapvarblocks){

gf("%s *%s=OC_Malloc(sizeof(%s));\n",self->blktypename,self->blkdataname,self->blktypename);
}
if(self->numheapvarblocks)
(objcT60=(id)self,(*_imp(objcT60,selTransTbl[29]))(objcT60,selTransTbl[29]));
gf("return newBlock(%i,(IMP)%s,",self->numparms,self->blkfunname);
if( !o_postlink){
id objcT61;

#line 294 "blockxpr.m"
(objcT61=trlunit,(*_imp(objcT61,selTransTbl[30]))(objcT61,selTransTbl[30],s_newblock));
}
if(self->numheapvarblocks){
gf("%s,(IMP)%s);\n",self->blkdataname,self->blkdtorname);
}else{
gs("(void*)0,(void*)0);\n");
}
gs("}\n");
return(id)self;
}

static id i_BlockExpr_gendestructor(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT62;

#line 307 "blockxpr.m"
int i;
assert(self->blkdtorname!=NULL&&self->numheapvarblocks>0);
gc('\n');
gf("static void %s(%s *%s)\n",self->blkdtorname,self->blktypename,self->blkdataname);
gs("{\n");
(objcT62=(id)self,(*_imp(objcT62,selTransTbl[31]))(objcT62,selTransTbl[31]));
for(i=0;i<self->numheapvarblocks;i++){
id objcT63,objcT64,objcT65;

#line 314 "blockxpr.m"
id c=(objcT63=self->heapvarblocks,(*(id(*)(id,SEL,unsigned))_imp(objcT63,selTransTbl[8]))(objcT63,selTransTbl[8],i));
char*hvp=(objcT64=c,(*(char*(*)(id,SEL))_imp(objcT64,selTransTbl[28]))(objcT64,selTransTbl[28]));
gf("if (--%s->heaprefcnt == 0) {\n",hvp);
if(o_refcnt)(objcT65=c,(*_imp(objcT65,selTransTbl[32]))(objcT65,selTransTbl[32]));
gf("OC_Free(%s);\n",hvp);
gs("}\n");
}
gf("OC_Free(%s);\n",self->blkdataname);
gs("}\n");
return(id)self;
}

static id i_BlockExpr_genblockfun(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT66,objcT67,objcT68,objcT71,objcT72;
id objcT73,objcT74,objcT75,objcT76,objcT84;
id objcT85;

#line 328 "blockxpr.m"
(objcT66=(id)self,(*_imp(objcT66,selTransTbl[33]))(objcT66,selTransTbl[33]));
gs("static");
(objcT67=self->restype,(*_imp(objcT67,selTransTbl[34]))(objcT67,selTransTbl[34],(id)0));
gs(self->blkfunname);
gs("(id thisBlock,");
if(self->numheapvarblocks){
gf("%s *%s",self->blktypename,self->blkdataname);
}else{
gf("void *%s",self->blkdataname);
}
if(self->parms)
(objcT68=self->parms,(*(id(*)(id,SEL,SEL))_imp(objcT68,selTransTbl[14]))(objcT68,selTransTbl[14],selTransTbl[35]));
gs(")\n{\n");
if(self->returnlabel){
id objcT69;

#line 342 "blockxpr.m"
gs("int _returnflag = 0;\n");
if( !(objcT69=self->restype,(*(BOOL(*)(id,SEL))_imp(objcT69,selTransTbl[36]))(objcT69,selTransTbl[36]))){
id objcT70;

#line 344 "blockxpr.m"
(objcT70=self->restype,(*_imp(objcT70,selTransTbl[34]))(objcT70,selTransTbl[34],s_returnval));
gs(";\n");
}
}
if(self->heapvars)
(objcT71=(id)self,(*_imp(objcT71,selTransTbl[37]))(objcT71,selTransTbl[37]));
if(self->numheapvarblocks)
(objcT72=(id)self,(*_imp(objcT72,selTransTbl[31]))(objcT72,selTransTbl[31]));
if(self->tmpvars)
gvarlist(self->tmpvars,"id",(o_refcnt)?"=(id)0":"");
if(self->icaches)
gvarlist(self->icaches,"static struct objcrt_inlineCache","");
if(self->datadefs)
(objcT73=self->datadefs,(*(id(*)(id,SEL,SEL))_imp(objcT73,selTransTbl[14]))(objcT73,selTransTbl[14],selTransTbl[38]));
if(self->increfs)
(objcT74=(id)self,(*_imp(objcT74,selTransTbl[39]))(objcT74,selTransTbl[39]));
if(self->initializers)
(objcT75=self->initializers,(*(id(*)(id,SEL,SEL))_imp(objcT75,selTransTbl[14]))(objcT75,selTransTbl[14],selTransTbl[38]));
if(self->stmts)
(objcT76=self->stmts,(*(id(*)(id,SEL,SEL))_imp(objcT76,selTransTbl[14]))(objcT76,selTransTbl[14],selTransTbl[38]));
if(self->returnlabel){
id objcT77,objcT78,objcT81;

#line 365 "blockxpr.m"
gc('\n');
gs("_returnflag++;\n");
gs((objcT77=self->returnlabel,(*(STR(*)(id,SEL))_imp(objcT77,selTransTbl[40]))(objcT77,selTransTbl[40])));
gs(":\n");
if(self->expr&& !(objcT78=self->restype,(*(BOOL(*)(id,SEL))_imp(objcT78,selTransTbl[36]))(objcT78,selTransTbl[36]))){
id objcT79,objcT80;

#line 370 "blockxpr.m"
gs("_returnval=");
(objcT79=self->expr,(*_imp(objcT79,selTransTbl[38]))(objcT79,selTransTbl[38]));
gs(";\n");
if((objcT80=self->restype,(*(BOOL(*)(id,SEL))_imp(objcT80,selTransTbl[5]))(objcT80,selTransTbl[5])))
gs("idincref(_returnval);");
}
if(self->decrefs)
(objcT81=(id)self,(*_imp(objcT81,selTransTbl[41]))(objcT81,selTransTbl[41]));
}
if(self->expr){
id objcT82;

#line 380 "blockxpr.m"
if(self->returnlabel&& !(objcT82=self->restype,(*(BOOL(*)(id,SEL))_imp(objcT82,selTransTbl[36]))(objcT82,selTransTbl[36]))){

gs("if (_returnflag) return _returnval;\n");
gs("return _returnval;\n");
}else{
id objcT83;

#line 385 "blockxpr.m"
gs("return ");
(objcT83=self->expr,(*_imp(objcT83,selTransTbl[38]))(objcT83,selTransTbl[38]));
gs(";\n");
}
}else{
if(o_refcnt){
gs("return idincref(thisBlock);\n");
}else{
gs("return thisBlock;\n");
}
}
gs("}\n");

if(self->numheapvarblocks)(objcT84=(id)self,(*_imp(objcT84,selTransTbl[42]))(objcT84,selTransTbl[42]));
(objcT85=(id)self,(*_imp(objcT85,selTransTbl[43]))(objcT85,selTransTbl[43]));

return(id)self;
}

static id i_BlockExpr_addheapvarblock_(struct BlockExpr_PRIVATE *self,SEL _cmd,id c)
{
if(c==(id)self){
return(id)self;
}else{
id objcT86,objcT87,objcT88,objcT89;

#line 409 "blockxpr.m"
if( !self->heapvarblocks)self->
heapvarblocks=(objcT86=OrdCltn,(*_imp(objcT86,selTransTbl[1]))(objcT86,selTransTbl[1]));
(objcT87=self->heapvarblocks,(*_imp(objcT87,selTransTbl[44]))(objcT87,selTransTbl[44],c));self->
numheapvarblocks=(objcT88=self->heapvarblocks,(*(unsigned(*)(id,SEL))_imp(objcT88,selTransTbl[6]))(objcT88,selTransTbl[6]));
if(self->enclosing)
(objcT89=self->enclosing,(*_imp(objcT89,selTransTbl[45]))(objcT89,selTransTbl[45],c));
return(id)self;
}
}

static id i_BlockExpr_gen(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT90,objcT91,objcT92;

#line 421 "blockxpr.m"
int i;
int comma=0;

gl((objcT90=(id)self,(*(int(*)(id,SEL))_imp(objcT90,selTransTbl[10]))(objcT90,selTransTbl[10])),(objcT91=(objcT92=(id)self,(*_imp(objcT92,selTransTbl[11]))(objcT92,selTransTbl[11])),(*(STR(*)(id,SEL))_imp(objcT91,selTransTbl[40]))(objcT91,selTransTbl[40])));
if(self->refvar){
id objcT93;

#line 426 "blockxpr.m"
gc('(');
gs((objcT93=self->refvar,(*(STR(*)(id,SEL))_imp(objcT93,selTransTbl[40]))(objcT93,selTransTbl[40])));
gc('=');
}
gf("%s(",self->blkconsname);
for(i=0;i<self->numheapvarblocks;i++){
id objcT94,objcT95;

#line 432 "blockxpr.m"
if(comma)
gc(',');
else
comma++;
gs((objcT94=(objcT95=self->heapvarblocks,(*(id(*)(id,SEL,unsigned))_imp(objcT95,selTransTbl[8]))(objcT95,selTransTbl[8],i)),(*(char*(*)(id,SEL))_imp(objcT94,selTransTbl[28]))(objcT94,selTransTbl[28])));
}
gc(')');
if(self->refvar)gc(')');
return(id)self;
}

#line 24 "shared.m"
static id i_BlockExpr_enclosing(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
return self->enclosing;
}

static id i_BlockExpr_addtmpvar_(struct BlockExpr_PRIVATE *self,SEL _cmd,id tvar)
{
id objcT96,objcT97;

#line 31 "shared.m"
if( !self->tmpvars)self->
tmpvars=(objcT96=OrdCltn,(*_imp(objcT96,selTransTbl[1]))(objcT96,selTransTbl[1]));
(objcT97=self->tmpvars,(*_imp(objcT97,selTransTbl[4]))(objcT97,selTransTbl[4],tvar));
return(id)self;
}

static id i_BlockExpr_addicache_(struct BlockExpr_PRIVATE *self,SEL _cmd,id tvar)
{
id objcT98,objcT99;

#line 39 "shared.m"
if( !self->icaches)self->
icaches=(objcT98=OrdCltn,(*_imp(objcT98,selTransTbl[1]))(objcT98,selTransTbl[1]));
(objcT99=self->icaches,(*_imp(objcT99,selTransTbl[4]))(objcT99,selTransTbl[4],tvar));
return(id)self;
}

static id i_BlockExpr_addincref_(struct BlockExpr_PRIVATE *self,SEL _cmd,id v)
{
id objcT100,objcT101;

#line 47 "shared.m"
if( !self->increfs)self->
increfs=(objcT100=OrdCltn,(*_imp(objcT100,selTransTbl[1]))(objcT100,selTransTbl[1]));
(objcT101=self->increfs,(*_imp(objcT101,selTransTbl[4]))(objcT101,selTransTbl[4],v));
return(id)self;
}

static id i_BlockExpr_genincrefs(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT102;

#line 55 "shared.m"
int i,n=(objcT102=self->increfs,(*(unsigned(*)(id,SEL))_imp(objcT102,selTransTbl[6]))(objcT102,selTransTbl[6]));

for(i=0;i<n;i++){
id objcT103,objcT104,objcT105,objcT106,objcT107;

#line 58 "shared.m"
if(self->lbrace)gl((objcT103=self->lbrace,(*(int(*)(id,SEL))_imp(objcT103,selTransTbl[10]))(objcT103,selTransTbl[10])),(objcT104=(objcT105=self->lbrace,(*_imp(objcT105,selTransTbl[11]))(objcT105,selTransTbl[11])),(*(STR(*)(id,SEL))_imp(objcT104,selTransTbl[40]))(objcT104,selTransTbl[40])));
gf("idincref(%s);\n",(objcT106=(objcT107=self->increfs,(*(id(*)(id,SEL,unsigned))_imp(objcT107,selTransTbl[8]))(objcT107,selTransTbl[8],i)),(*(STR(*)(id,SEL))_imp(objcT106,selTransTbl[40]))(objcT106,selTransTbl[40])));
}
gc('\n');
return(id)self;
}

static id i_BlockExpr_adddecref_(struct BlockExpr_PRIVATE *self,SEL _cmd,id v)
{
id objcT108,objcT109,objcT110;

#line 67 "shared.m"
if( !self->decrefs)self->
decrefs=(objcT108=OrdCltn,(*_imp(objcT108,selTransTbl[1]))(objcT108,selTransTbl[1]));
(objcT109=self->decrefs,(*_imp(objcT109,selTransTbl[4]))(objcT109,selTransTbl[4],v));

if(curloopcompound&&(id)self!=curloopcompound)
(objcT110=curloopcompound,(*_imp(objcT110,selTransTbl[22]))(objcT110,selTransTbl[22],v));
return(id)self;
}

static id i_BlockExpr_gendecrefs(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT111;

#line 78 "shared.m"
int i,n=(objcT111=self->decrefs,(*(unsigned(*)(id,SEL))_imp(objcT111,selTransTbl[6]))(objcT111,selTransTbl[6]));

for(i=0;i<n;i++){
id objcT112,objcT113,objcT114,objcT115,objcT116;

#line 81 "shared.m"
char*s=(objcT112=(objcT113=self->decrefs,(*(id(*)(id,SEL,unsigned))_imp(objcT113,selTransTbl[8]))(objcT113,selTransTbl[8],i)),(*(STR(*)(id,SEL))_imp(objcT112,selTransTbl[40]))(objcT112,selTransTbl[40]));

if(self->rbrace)gl((objcT114=self->rbrace,(*(int(*)(id,SEL))_imp(objcT114,selTransTbl[10]))(objcT114,selTransTbl[10])),(objcT115=(objcT116=self->rbrace,(*_imp(objcT116,selTransTbl[11]))(objcT116,selTransTbl[11])),(*(STR(*)(id,SEL))_imp(objcT115,selTransTbl[40]))(objcT115,selTransTbl[40])));
gf("%s=iddecref(%s);\n",s,s);
}
gc('\n');
return(id)self;
}

static id i_BlockExpr_lookuplocal_(struct BlockExpr_PRIVATE *self,SEL _cmd,id sym)
{
id objcT117;

#line 92 "shared.m"
return(self->localdic)?(objcT117=self->localdic,(*_imp(objcT117,selTransTbl[46]))(objcT117,selTransTbl[46],sym)):(id)0;
}

#line 32 "../../include/objpak/dictnary.h"
extern id  Dictionary;

#line 95 "shared.m"
static id i_BlockExpr_deflocal_astype_(struct BlockExpr_PRIVATE *self,SEL _cmd,id sym,id t)
{
id objcT120,objcT121,objcT122;

#line 97 "shared.m"
if( !self->localdic){
id objcT118,objcT119;
self->
#line 98 "shared.m"
localdic=(objcT118=Dictionary,(*_imp(objcT118,selTransTbl[1]))(objcT118,selTransTbl[1]));self->
locals=(objcT119=OrdCltn,(*_imp(objcT119,selTransTbl[1]))(objcT119,selTransTbl[1]));
}
(objcT120=self->localdic,(*_imp(objcT120,selTransTbl[47]))(objcT120,selTransTbl[47],sym,t));
(objcT121=self->locals,(*_imp(objcT121,selTransTbl[4]))(objcT121,selTransTbl[4],sym));
if(curdef&&((objcT122=curdef,(*(BOOL(*)(id,SEL))_imp(objcT122,selTransTbl[48]))(objcT122,selTransTbl[48])))){
id objcT123,objcT125;

#line 104 "shared.m"
assert(curclassdef);
if((objcT123=curclassdef,(*(BOOL(*)(id,SEL,id))_imp(objcT123,selTransTbl[49]))(objcT123,selTransTbl[49],sym))){
id objcT124;

#line 106 "shared.m"
warnat(sym,"definition of local '%s' hides instance variable",(objcT124=sym,(*(STR(*)(id,SEL))_imp(objcT124,selTransTbl[40]))(objcT124,selTransTbl[40])));
}
if((objcT125=curclassdef,(*(BOOL(*)(id,SEL,id))_imp(objcT125,selTransTbl[50]))(objcT125,selTransTbl[50],sym))){
id objcT126;

#line 109 "shared.m"
warnat(sym,"definition of local '%s' hides class variable",(objcT126=sym,(*(STR(*)(id,SEL))_imp(objcT126,selTransTbl[40]))(objcT126,selTransTbl[40])));
}
}
return(id)self;
}

static id i_BlockExpr_genheapvarptr(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
char*p=self->heapvarptrname;
char*t=self->heapvartypename;

assert(self->heapnames);

gf("%s *%s=(%s *)OC_Calloc(sizeof(%s));\n",t,p,t,t);
return(id)self;
}

static id i_BlockExpr_gendecrefsheapvars(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT127;

#line 128 "shared.m"
int i,n=(objcT127=self->heapnames,(*(unsigned(*)(id,SEL))_imp(objcT127,selTransTbl[6]))(objcT127,selTransTbl[6]));
char*hvp=self->heapvarptrname;

for(i=0;i<n;i++){
id objcT128,objcT129,objcT130;

#line 132 "shared.m"
id x=(objcT128=self->heapnames,(*(id(*)(id,SEL,unsigned))_imp(objcT128,selTransTbl[8]))(objcT128,selTransTbl[8],i));
id t=(objcT129=self->heaptypes,(*(id(*)(id,SEL,unsigned))_imp(objcT129,selTransTbl[8]))(objcT129,selTransTbl[8],i));

assert(t!=(id)0);
if((objcT130=t,(*(BOOL(*)(id,SEL))_imp(objcT130,selTransTbl[5]))(objcT130,selTransTbl[5]))){
id objcT131;

#line 137 "shared.m"
char*s=(objcT131=x,(*(STR(*)(id,SEL))_imp(objcT131,selTransTbl[40]))(objcT131,selTransTbl[40]));
gf("%s->%s=iddecref(%s->%s);\n",hvp,s,hvp,s);
}
}
return(id)self;
}

static id i_BlockExpr_genheapvartype(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT132;

#line 146 "shared.m"
int i,n=(objcT132=self->heapnames,(*(unsigned(*)(id,SEL))_imp(objcT132,selTransTbl[6]))(objcT132,selTransTbl[6]));

if( !n)
return(id)self;
gf("%s {\n",self->heapvartypename);
gs("int heaprefcnt;\n");
for(i=0;i<n;i++){
id objcT133,objcT134,objcT135;

#line 153 "shared.m"
id x=(objcT133=self->heapnames,(*(id(*)(id,SEL,unsigned))_imp(objcT133,selTransTbl[8]))(objcT133,selTransTbl[8],i));
id t=(objcT134=self->heaptypes,(*(id(*)(id,SEL,unsigned))_imp(objcT134,selTransTbl[8]))(objcT134,selTransTbl[8],i));

assert(t!=(id)0);
(objcT135=t,(*_imp(objcT135,selTransTbl[34]))(objcT135,selTransTbl[34],x));
gs(";\n");
}
gs("};\n");
return(id)self;
}

static id i_BlockExpr_heapvars(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
return(id)0;
}

static BOOL i_BlockExpr_isheapvar_(struct BlockExpr_PRIVATE *self,SEL _cmd,id x)
{
id objcT136;

#line 171 "shared.m"
return(self->heapvars)?(objcT136=self->heapvars,(*(BOOL(*)(id,SEL,id))_imp(objcT136,selTransTbl[51]))(objcT136,selTransTbl[51],x)):(BOOL)0;
}

#line 34 "../../include/objpak/set.h"
extern id  Set;

#line 174 "shared.m"
static id i_BlockExpr_defheapvar_type_(struct BlockExpr_PRIVATE *self,SEL _cmd,id x,id t)
{
id objcT145;

#line 176 "shared.m"
int i;

if( !self->heapvars){
id objcT137,objcT138,objcT139,objcT140,objcT141;
id objcT142,objcT143,objcT144;
self->
#line 179 "shared.m"
heapvars=(objcT137=Set,(*_imp(objcT137,selTransTbl[1]))(objcT137,selTransTbl[1]));self->
heapnames=(objcT138=OrdCltn,(*_imp(objcT138,selTransTbl[1]))(objcT138,selTransTbl[1]));self->
heaptypes=(objcT139=OrdCltn,(*_imp(objcT139,selTransTbl[1]))(objcT139,selTransTbl[1]));
i=(objcT140=trlunit,(*(int(*)(id,SEL))_imp(objcT140,selTransTbl[52]))(objcT140,selTransTbl[52]));self->
heapvarptrname=(objcT141=(objcT142=String,(*(id(*)(id,SEL,STR,...))_imp(objcT142,selTransTbl[16]))(objcT142,selTransTbl[16],"heapvars%i",i)),(*(STR(*)(id,SEL))_imp(objcT141,selTransTbl[17]))(objcT141,selTransTbl[17]));self->
heapvartypename=(objcT143=(objcT144=String,(*(id(*)(id,SEL,STR,...))_imp(objcT144,selTransTbl[16]))(objcT144,selTransTbl[16],"struct heaptype%i",i)),(*(STR(*)(id,SEL))_imp(objcT143,selTransTbl[17]))(objcT143,selTransTbl[17]));
}
if((objcT145=t,(*(BOOL(*)(id,SEL))_imp(objcT145,selTransTbl[53]))(objcT145,selTransTbl[53]))){
id objcT146;

#line 187 "shared.m"
char*msg="can't use static local variables (%s) from within block";

fatalat(x,msg,(objcT146=x,(*(STR(*)(id,SEL))_imp(objcT146,selTransTbl[40]))(objcT146,selTransTbl[40])));
}else{
id objcT147;

#line 191 "shared.m"
if((objcT147=self->heapvars,(*_imp(objcT147,selTransTbl[54]))(objcT147,selTransTbl[54],x))!=(id)0){
id objcT148,objcT149;

#line 192 "shared.m"
(objcT148=self->heapnames,(*_imp(objcT148,selTransTbl[4]))(objcT148,selTransTbl[4],x));
(objcT149=self->heaptypes,(*_imp(objcT149,selTransTbl[4]))(objcT149,selTransTbl[4],t));
}
}
return(id)self;
}

static char*i_BlockExpr_heapvarptrname(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
assert(self->heapvarptrname);
return self->heapvarptrname;
}

static char*i_BlockExpr_heapvartypename(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
assert(self->heapvartypename);
return self->heapvartypename;
}

static id i_BlockExpr_removeheapvarsfromdatadefs(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT150,objcT162;

#line 213 "shared.m"
int n;

assert(self->heapvars);self->
initializers=(objcT150=OrdCltn,(*_imp(objcT150,selTransTbl[1]))(objcT150,selTransTbl[1]));

if(self->parmnames){
id objcT151;

#line 219 "shared.m"
n=(objcT151=self->parmnames,(*(unsigned(*)(id,SEL))_imp(objcT151,selTransTbl[6]))(objcT151,selTransTbl[6]));
while(n--){
id objcT152,objcT153;

#line 221 "shared.m"
id p=(objcT152=self->parmnames,(*(id(*)(id,SEL,unsigned))_imp(objcT152,selTransTbl[8]))(objcT152,selTransTbl[8],n));

if((objcT153=self->heapvars,(*(BOOL(*)(id,SEL,id))_imp(objcT153,selTransTbl[51]))(objcT153,selTransTbl[51],p))){
id objcT154,objcT155,objcT156;

#line 224 "shared.m"
id x=(objcT154=(objcT155=mkidentexpr(p),(*(id(*)(id,SEL,BOOL))_imp(objcT155,selTransTbl[55]))(objcT155,selTransTbl[55],(BOOL)1)),(*_imp(objcT154,selTransTbl[15]))(objcT154,selTransTbl[15]));
id y=mkidentexpr(p);

(objcT156=self->initializers,(*_imp(objcT156,selTransTbl[4]))(objcT156,selTransTbl[4],mkexprstmt(mkassignexpr(x,"=",y))));
}
}
}
if(self->datadefs){
id objcT157;

#line 232 "shared.m"
n=(objcT157=self->datadefs,(*(unsigned(*)(id,SEL))_imp(objcT157,selTransTbl[6]))(objcT157,selTransTbl[6]));
while(n--){
id objcT158,objcT159,objcT160,objcT161;

#line 234 "shared.m"
id def=(objcT158=self->datadefs,(*(id(*)(id,SEL,unsigned))_imp(objcT158,selTransTbl[8]))(objcT158,selTransTbl[8],n));

(objcT159=def,(*_imp(objcT159,selTransTbl[56]))(objcT159,selTransTbl[56],self->heapvars,self->initializers));
if((objcT160=def,(*_imp(objcT160,selTransTbl[57]))(objcT160,selTransTbl[57]))==(id)0)
(objcT161=self->datadefs,(*(id(*)(id,SEL,unsigned))_imp(objcT161,selTransTbl[58]))(objcT161,selTransTbl[58],n));
}
}
if((objcT162=self->datadefs,(*(unsigned(*)(id,SEL))_imp(objcT162,selTransTbl[6]))(objcT162,selTransTbl[6]))==0)self->
datadefs=(id)0;
return(id)self;
}

#line 445 "blockxpr.m"
static id i_BlockExpr_st80(struct BlockExpr_PRIVATE *self,SEL _cmd)
{
id objcT164,objcT165,objcT166,objcT167;

#line 447 "blockxpr.m"
gc('[');
if(self->parms){
id objcT163;

#line 449 "blockxpr.m"
(objcT163=self->parms,(*(id(*)(id,SEL,SEL))_imp(objcT163,selTransTbl[14]))(objcT163,selTransTbl[14],_cmd));
gc('|');
}
gc('\n');
gc('|');
if(self->datadefs)
(objcT164=self->datadefs,(*(id(*)(id,SEL,SEL))_imp(objcT164,selTransTbl[14]))(objcT164,selTransTbl[14],_cmd));
gc('|');
gc('\n');
if(self->datadefs)
(objcT165=self->datadefs,(*(id(*)(id,SEL,SEL))_imp(objcT165,selTransTbl[14]))(objcT165,selTransTbl[14],selTransTbl[59]));
if(self->stmts)
(objcT166=self->stmts,(*(id(*)(id,SEL,SEL))_imp(objcT166,selTransTbl[14]))(objcT166,selTransTbl[14],_cmd));
if(self->expr)
(objcT167=self->expr,(*_imp(objcT167,selTransTbl[60]))(objcT167,selTransTbl[60]));
gc(']');
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Expr;
extern struct _SHARED _Expr;
extern struct _SHARED __Expr;
static struct _SLT _BlockExpr_clsDispatchTbl[] ={
{"new",(id (*)())c_BlockExpr_new},
{(char*)0,(id (*)())0}
};
static struct _SLT _BlockExpr_nstDispatchTbl[] ={
{"blockcount:",(id (*)())i_BlockExpr_blockcount_},
{"isblockexpr",(id (*)())i_BlockExpr_isblockexpr},
{"lbrace:",(id (*)())i_BlockExpr_lbrace_},
{"rbrace:",(id (*)())i_BlockExpr_rbrace_},
{"defparm:astype:",(id (*)())i_BlockExpr_defparm_astype_},
{"parms:",(id (*)())i_BlockExpr_parms_},
{"datadefs:",(id (*)())i_BlockExpr_datadefs_},
{"stmts:",(id (*)())i_BlockExpr_stmts_},
{"expr:",(id (*)())i_BlockExpr_expr_},
{"lookupparm:",(id (*)())i_BlockExpr_lookupparm_},
{"returnlabel",(id (*)())i_BlockExpr_returnlabel},
{"lineno",(id (*)())i_BlockExpr_lineno},
{"filename",(id (*)())i_BlockExpr_filename},
{"synth",(id (*)())i_BlockExpr_synth},
{"typesynth",(id (*)())i_BlockExpr_typesynth},
{"genblocktype",(id (*)())i_BlockExpr_genblocktype},
{"packblockdata",(id (*)())i_BlockExpr_packblockdata},
{"unpackblockdata",(id (*)())i_BlockExpr_unpackblockdata},
{"genconstructor",(id (*)())i_BlockExpr_genconstructor},
{"gendestructor",(id (*)())i_BlockExpr_gendestructor},
{"genblockfun",(id (*)())i_BlockExpr_genblockfun},
{"addheapvarblock:",(id (*)())i_BlockExpr_addheapvarblock_},
{"gen",(id (*)())i_BlockExpr_gen},
{"enclosing",(id (*)())i_BlockExpr_enclosing},
{"addtmpvar:",(id (*)())i_BlockExpr_addtmpvar_},
{"addicache:",(id (*)())i_BlockExpr_addicache_},
{"addincref:",(id (*)())i_BlockExpr_addincref_},
{"genincrefs",(id (*)())i_BlockExpr_genincrefs},
{"adddecref:",(id (*)())i_BlockExpr_adddecref_},
{"gendecrefs",(id (*)())i_BlockExpr_gendecrefs},
{"lookuplocal:",(id (*)())i_BlockExpr_lookuplocal_},
{"deflocal:astype:",(id (*)())i_BlockExpr_deflocal_astype_},
{"genheapvarptr",(id (*)())i_BlockExpr_genheapvarptr},
{"gendecrefsheapvars",(id (*)())i_BlockExpr_gendecrefsheapvars},
{"genheapvartype",(id (*)())i_BlockExpr_genheapvartype},
{"heapvars",(id (*)())i_BlockExpr_heapvars},
{"isheapvar:",(id (*)())i_BlockExpr_isheapvar_},
{"defheapvar:type:",(id (*)())i_BlockExpr_defheapvar_type_},
{"heapvarptrname",(id (*)())i_BlockExpr_heapvarptrname},
{"heapvartypename",(id (*)())i_BlockExpr_heapvartypename},
{"removeheapvarsfromdatadefs",(id (*)())i_BlockExpr_removeheapvarsfromdatadefs},
{"st80",(id (*)())i_BlockExpr_st80},
{(char*)0,(id (*)())0}
};
id BlockExpr = (id)&_BlockExpr;
id  *OBJCCLASS_BlockExpr(void) { return &BlockExpr; }
struct _SHARED  _BlockExpr = {
  (id)&__BlockExpr,
  (id)&_Expr,
  "BlockExpr",
  0,
  sizeof(struct BlockExpr_PRIVATE),
  42,
  _BlockExpr_nstDispatchTbl,
  41,
  &blockxpr_modDesc,
  0,
  (id)0,
  &BlockExpr,
};
id  OBJCCFUNC_BlockExpr(void) { return (id)&_BlockExpr; }
id  OBJCCSUPER_BlockExpr(void) { return _BlockExpr.clsSuper; }
struct _SHARED __BlockExpr = {
  (id)&__Object,
  (id)&__Expr,
  "BlockExpr",
  0,
  sizeof(struct _SHARED),
  1,
  _BlockExpr_clsDispatchTbl,
  34,
  &blockxpr_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_BlockExpr(void) { return (id)&__BlockExpr; }
id  OBJCMSUPER_BlockExpr(void) { return __BlockExpr.clsSuper; }
static char *_selTransTbl[] ={
"usingblocks:",
"new",
"blockcount:",
"blockcount",
"add:",
"isid",
"size",
"arg:",
"at:",
"findMatching:",
"lineno",
"filename",
"returnlabel",
"addblockreference:",
"elementsPerform:",
"synth",
"sprintf:",
"strCopy",
"type",
"removeheapvarsfromdatadefs",
"gettmpvar",
"addtmpvar:",
"adddecref:",
"lookupparm:",
"addincref:",
"lookuplocal:",
"isheapvar:",
"heapvartypename",
"heapvarptrname",
"packblockdata",
"usesentry:",
"unpackblockdata",
"gendecrefsheapvars",
"genblocktype",
"gendef:",
"gencommaparm",
"isvoid",
"genheapvarptr",
"gen",
"genincrefs",
"str",
"gendecrefs",
"gendestructor",
"genconstructor",
"addIfAbsent:",
"addheapvarblock:",
"atKey:",
"atKey:put:",
"ismethdef",
"isivar:",
"iscvar:",
"contains:",
"heapvarcount",
"isstatic",
"addNTest:",
"lhsself:",
"removevars:initializers:",
"decllist",
"removeAt:",
"st80inits",
"st80",
0
};
struct modDescriptor blockxpr_modDesc = {
  "blockxpr",
  "objc2.3.1",
  0L,
  0,
  0,
  &BlockExpr,
  61,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_blockxpr(void)
{
  selTransTbl = _selTransTbl;
  return &blockxpr_modDesc;
}
int _OBJCPOSTLINK_blockxpr = 1;


