#line 1 "structsp.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_structsp(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor structsp_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 31 "../../include/objpak/ordcltn.h"
typedef struct objcol{
int count;
int capacity;
id*ptr;
}*objcol_t;
#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "structsp.h"
extern id curstruct;
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "trlunit.h"
extern id trlunit;
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 38 "structsp.m"
id curstruct;
#line 24 "structsp.h"
struct StructSpec_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 26 "structsp.h"
id keyw,name;
id lbrace;
id defs;
id rbrace;
id compdic,compnames,comptypes;};

#line 24 "structsp.h"
extern id  StructSpec;

#line 24 "structsp.h"
extern struct _SHARED _StructSpec;
extern struct _SHARED __StructSpec;


#line 42 "structsp.m"
static id i_StructSpec_keyw_(struct StructSpec_PRIVATE *self,SEL _cmd,id akeyw)
{self->
keyw=akeyw;
return(id)self;
}

static id i_StructSpec_name_(struct StructSpec_PRIVATE *self,SEL _cmd,id akeyw)
{self->
name=akeyw;
return(id)self;
}

static id i_StructSpec_defs_(struct StructSpec_PRIVATE *self,SEL _cmd,id akeyw)
{self->
defs=akeyw;
return(id)self;
}

static id i_StructSpec_lbrace_(struct StructSpec_PRIVATE *self,SEL _cmd,id lb)
{self->
lbrace=lb;
return(id)self;
}

static id i_StructSpec_rbrace_(struct StructSpec_PRIVATE *self,SEL _cmd,id rb)
{self->
rbrace=rb;
return(id)self;
}

static unsigned i_StructSpec_hash(struct StructSpec_PRIVATE *self,SEL _cmd)
{
id objcT0;

#line 74 "structsp.m"
return(objcT0=self->name,(*(unsigned(*)(id,SEL))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
}

static STR i_StructSpec_str(struct StructSpec_PRIVATE *self,SEL _cmd)
{
id objcT1;

#line 79 "structsp.m"
return(objcT1=self->name,(*(STR(*)(id,SEL))_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1]));
}

static BOOL i_StructSpec_isEqual_(struct StructSpec_PRIVATE *self,SEL _cmd,id x)
{
id objcT2,objcT3;

#line 84 "structsp.m"
if( !self->name)
return(id)self==x;

return((id)self==x)?(BOOL)1:strcmp((objcT2=self->name,(*(STR(*)(id,SEL))_imp(objcT2,selTransTbl[1]))(objcT2,selTransTbl[1])),(objcT3=x,(*(STR(*)(id,SEL))_imp(objcT3,selTransTbl[1]))(objcT3,selTransTbl[1])))==0;
}

static id i_StructSpec_synth(struct StructSpec_PRIVATE *self,SEL _cmd)
{
curstruct=(id)self;
if(self->defs){
id objcT4,objcT5;

#line 94 "structsp.m"
(objcT4=self->defs,(*(id(*)(id,SEL,SEL))_imp(objcT4,selTransTbl[2]))(objcT4,selTransTbl[2],_cmd));
if(self->name)
(objcT5=trlunit,(*_imp(objcT5,selTransTbl[3]))(objcT5,selTransTbl[3],(id)self));
}
curstruct=(id)0;
return(id)self;
}

static id i_StructSpec_gen(struct StructSpec_PRIVATE *self,SEL _cmd)
{
id objcT6,objcT7;

#line 104 "structsp.m"
(objcT6=self->keyw,(*_imp(objcT6,selTransTbl[4]))(objcT6,selTransTbl[4]));
if(self->name)
(objcT7=self->name,(*_imp(objcT7,selTransTbl[4]))(objcT7,selTransTbl[4]));
if(self->defs){
id objcT8,objcT9,objcT10;

#line 108 "structsp.m"
if(self->lbrace)
(objcT8=self->lbrace,(*_imp(objcT8,selTransTbl[4]))(objcT8,selTransTbl[4]));
else
gc('{');
(objcT9=self->defs,(*(id(*)(id,SEL,SEL))_imp(objcT9,selTransTbl[2]))(objcT9,selTransTbl[2],_cmd));
if(self->rbrace)
(objcT10=self->rbrace,(*_imp(objcT10,selTransTbl[4]))(objcT10,selTransTbl[4]));
else
gc('}');
}
return(id)self;
}

static BOOL i_StructSpec_canforward(struct StructSpec_PRIVATE *self,SEL _cmd)
{

return o_structassign;
}

static BOOL i_StructSpec_isselptr(struct StructSpec_PRIVATE *self,SEL _cmd)
{
return(BOOL)0;
}

static id i_StructSpec_lookupcomp_(struct StructSpec_PRIVATE *self,SEL _cmd,id c)
{
id objcT11;

#line 134 "structsp.m"
return(self->compdic)?(objcT11=self->compdic,(*_imp(objcT11,selTransTbl[5]))(objcT11,selTransTbl[5],c)):(id)0;
}

#line 32 "../../include/objpak/dictnary.h"
extern id  Dictionary;

#line 37 "../../include/objpak/ordcltn.h"
extern id  OrdCltn;

#line 137 "structsp.m"
static id i_StructSpec_defcomp_astype_(struct StructSpec_PRIVATE *self,SEL _cmd,id sym,id t)
{
id objcT15,objcT16,objcT17;

#line 139 "structsp.m"
if( !self->compdic){
id objcT12,objcT13,objcT14;
self->
#line 140 "structsp.m"
compdic=(objcT12=Dictionary,(*_imp(objcT12,selTransTbl[6]))(objcT12,selTransTbl[6]));self->
compnames=(objcT13=OrdCltn,(*_imp(objcT13,selTransTbl[6]))(objcT13,selTransTbl[6]));self->
comptypes=(objcT14=OrdCltn,(*_imp(objcT14,selTransTbl[6]))(objcT14,selTransTbl[6]));
}
(objcT15=self->compdic,(*_imp(objcT15,selTransTbl[7]))(objcT15,selTransTbl[7],sym,t));
(objcT16=self->compnames,(*_imp(objcT16,selTransTbl[8]))(objcT16,selTransTbl[8],sym));
(objcT17=self->comptypes,(*_imp(objcT17,selTransTbl[8]))(objcT17,selTransTbl[8],t));
return(id)self;
}

static id i_StructSpec_dot_(struct StructSpec_PRIVATE *self,SEL _cmd,id sym)
{
if(self->compdic){
id objcT18;

#line 153 "structsp.m"
return(objcT18=self->compdic,(*_imp(objcT18,selTransTbl[5]))(objcT18,selTransTbl[5],sym));
}else{
if(self->name){
id objcT19;

#line 156 "structsp.m"
id s=(objcT19=trlunit,(*_imp(objcT19,selTransTbl[9]))(objcT19,selTransTbl[9],(id)self));

if( !s){
id objcT20;

#line 159 "structsp.m"
warnat(sym,"incomplete definition of struct '%s'",(objcT20=self->name,(*(STR(*)(id,SEL))_imp(objcT20,selTransTbl[1]))(objcT20,selTransTbl[1])));
return(id)0;
}else{
id objcT21;

#line 162 "structsp.m"
return(objcT21=s,(*_imp(objcT21,selTransTbl[10]))(objcT21,selTransTbl[10],sym));
}
}else{
return(id)0;
}
}
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Node;
extern struct _SHARED _Node;
extern struct _SHARED __Node;
static struct _SLT _StructSpec_clsDispatchTbl[] ={
{(char*)0,(id (*)())0}
};
static struct _SLT _StructSpec_nstDispatchTbl[] ={
{"keyw:",(id (*)())i_StructSpec_keyw_},
{"name:",(id (*)())i_StructSpec_name_},
{"defs:",(id (*)())i_StructSpec_defs_},
{"lbrace:",(id (*)())i_StructSpec_lbrace_},
{"rbrace:",(id (*)())i_StructSpec_rbrace_},
{"hash",(id (*)())i_StructSpec_hash},
{"str",(id (*)())i_StructSpec_str},
{"isEqual:",(id (*)())i_StructSpec_isEqual_},
{"synth",(id (*)())i_StructSpec_synth},
{"gen",(id (*)())i_StructSpec_gen},
{"canforward",(id (*)())i_StructSpec_canforward},
{"isselptr",(id (*)())i_StructSpec_isselptr},
{"lookupcomp:",(id (*)())i_StructSpec_lookupcomp_},
{"defcomp:astype:",(id (*)())i_StructSpec_defcomp_astype_},
{"dot:",(id (*)())i_StructSpec_dot_},
{(char*)0,(id (*)())0}
};
id StructSpec = (id)&_StructSpec;
id  *OBJCCLASS_StructSpec(void) { return &StructSpec; }
struct _SHARED  _StructSpec = {
  (id)&__StructSpec,
  (id)&_Node,
  "StructSpec",
  0,
  sizeof(struct StructSpec_PRIVATE),
  15,
  _StructSpec_nstDispatchTbl,
  41,
  &structsp_modDesc,
  0,
  (id)0,
  &StructSpec,
};
id  OBJCCFUNC_StructSpec(void) { return (id)&_StructSpec; }
id  OBJCCSUPER_StructSpec(void) { return _StructSpec.clsSuper; }
struct _SHARED __StructSpec = {
  (id)&__Object,
  (id)&__Node,
  "StructSpec",
  0,
  sizeof(struct _SHARED),
  0,
  _StructSpec_clsDispatchTbl,
  34,
  &structsp_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_StructSpec(void) { return (id)&__StructSpec; }
id  OBJCMSUPER_StructSpec(void) { return __StructSpec.clsSuper; }
static char *_selTransTbl[] ={
"hash",
"str",
"elementsPerform:",
"defstruct:",
"gen",
"atKey:",
"new",
"atKey:put:",
"add:",
"lookupstruct:",
"dot:",
0
};
struct modDescriptor structsp_modDesc = {
  "structsp",
  "objc2.3.1",
  0L,
  0,
  0,
  &StructSpec,
  11,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_structsp(void)
{
  selTransTbl = _selTransTbl;
  return &structsp_modDesc;
}
int _OBJCPOSTLINK_structsp = 1;


