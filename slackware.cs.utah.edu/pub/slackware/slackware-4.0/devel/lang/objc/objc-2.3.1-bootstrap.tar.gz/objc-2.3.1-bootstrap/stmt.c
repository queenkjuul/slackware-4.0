#line 1 "stmt.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_stmt(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor stmt_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "stmt.h"
struct Stmt_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;};

#line 22 "stmt.h"
extern id  Stmt;

#line 22 "stmt.h"
extern struct _SHARED _Stmt;
extern struct _SHARED __Stmt;


#line 31 "stmt.m"
static BOOL i_Stmt_isblockexpr(struct Stmt_PRIVATE *self,SEL _cmd)
{
return(BOOL)0;
}

static BOOL i_Stmt_iscompstmt(struct Stmt_PRIVATE *self,SEL _cmd)
{
return(BOOL)0;
}

static id i_Stmt_gen(struct Stmt_PRIVATE *self,SEL _cmd)
{
id objcT0;

#line 43 "stmt.m"
return(objcT0=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0],_cmd));
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Node;
extern struct _SHARED _Node;
extern struct _SHARED __Node;
static struct _SLT _Stmt_clsDispatchTbl[] ={
{(char*)0,(id (*)())0}
};
static struct _SLT _Stmt_nstDispatchTbl[] ={
{"isblockexpr",(id (*)())i_Stmt_isblockexpr},
{"iscompstmt",(id (*)())i_Stmt_iscompstmt},
{"gen",(id (*)())i_Stmt_gen},
{(char*)0,(id (*)())0}
};
id Stmt = (id)&_Stmt;
id  *OBJCCLASS_Stmt(void) { return &Stmt; }
struct _SHARED  _Stmt = {
  (id)&__Stmt,
  (id)&_Node,
  "Stmt",
  0,
  sizeof(struct Stmt_PRIVATE),
  3,
  _Stmt_nstDispatchTbl,
  41,
  &stmt_modDesc,
  0,
  (id)0,
  &Stmt,
};
id  OBJCCFUNC_Stmt(void) { return (id)&_Stmt; }
id  OBJCCSUPER_Stmt(void) { return _Stmt.clsSuper; }
struct _SHARED __Stmt = {
  (id)&__Object,
  (id)&__Node,
  "Stmt",
  0,
  sizeof(struct _SHARED),
  0,
  _Stmt_clsDispatchTbl,
  34,
  &stmt_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_Stmt(void) { return (id)&__Stmt; }
id  OBJCMSUPER_Stmt(void) { return __Stmt.clsSuper; }
static char *_selTransTbl[] ={
"subclassResponsibility:",
0
};
struct modDescriptor stmt_modDesc = {
  "stmt",
  "objc2.3.1",
  0L,
  0,
  0,
  &Stmt,
  1,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_stmt(void)
{
  selTransTbl = _selTransTbl;
  return &stmt_modDesc;
}
int _OBJCPOSTLINK_stmt = 1;


