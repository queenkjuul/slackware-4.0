#line 1 "indexxpr.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_indexxpr(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor indexxpr_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "expr.h"
extern id e_nil;
extern id e_self;
extern id e_cmd;
extern id e_super;
extern id e_aFiler;
extern id e_ft_id;
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "indexxpr.h"
struct IndexExpr_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 31 "expr.h"
id type;
#line 24 "indexxpr.h"
id lhs,rhs;};

#line 22 "indexxpr.h"
extern id  IndexExpr;

#line 22 "indexxpr.h"
extern struct _SHARED _IndexExpr;
extern struct _SHARED __IndexExpr;


#line 33 "indexxpr.m"
static id i_IndexExpr_lhs_(struct IndexExpr_PRIVATE *self,SEL _cmd,id e){self->
lhs=e;
return(id)self;
}
static id i_IndexExpr_rhs_(struct IndexExpr_PRIVATE *self,SEL _cmd,id e){self->
rhs=e;
return(id)self;
}

static int i_IndexExpr_lineno(struct IndexExpr_PRIVATE *self,SEL _cmd)
{
id objcT0;

#line 44 "indexxpr.m"
return(objcT0=self->lhs,(*(int(*)(id,SEL))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
}

static id i_IndexExpr_filename(struct IndexExpr_PRIVATE *self,SEL _cmd)
{
id objcT1;

#line 49 "indexxpr.m"
return(objcT1=self->lhs,(*_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1]));
}

static id i_IndexExpr_synth(struct IndexExpr_PRIVATE *self,SEL _cmd)
{
id objcT2,objcT3;

#line 54 "indexxpr.m"
(objcT2=self->lhs,(*_imp(objcT2,selTransTbl[2]))(objcT2,selTransTbl[2]));
(objcT3=self->rhs,(*_imp(objcT3,selTransTbl[2]))(objcT3,selTransTbl[2]));
return(id)self;
}

static id i_IndexExpr_typesynth(struct IndexExpr_PRIVATE *self,SEL _cmd)
{
id objcT4,objcT5;
self->
#line 61 "indexxpr.m"
type=(objcT4=(objcT5=self->lhs,(*_imp(objcT5,selTransTbl[3]))(objcT5,selTransTbl[3])),(*_imp(objcT4,selTransTbl[4]))(objcT4,selTransTbl[4]));
return(id)self;
}

static id i_IndexExpr_gen(struct IndexExpr_PRIVATE *self,SEL _cmd)
{
id objcT6,objcT7;

#line 67 "indexxpr.m"
(objcT6=self->lhs,(*_imp(objcT6,selTransTbl[5]))(objcT6,selTransTbl[5]));
gc('[');
(objcT7=self->rhs,(*_imp(objcT7,selTransTbl[5]))(objcT7,selTransTbl[5]));
gc(']');
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Expr;
extern struct _SHARED _Expr;
extern struct _SHARED __Expr;
static struct _SLT _IndexExpr_clsDispatchTbl[] ={
{(char*)0,(id (*)())0}
};
static struct _SLT _IndexExpr_nstDispatchTbl[] ={
{"lhs:",(id (*)())i_IndexExpr_lhs_},
{"rhs:",(id (*)())i_IndexExpr_rhs_},
{"lineno",(id (*)())i_IndexExpr_lineno},
{"filename",(id (*)())i_IndexExpr_filename},
{"synth",(id (*)())i_IndexExpr_synth},
{"typesynth",(id (*)())i_IndexExpr_typesynth},
{"gen",(id (*)())i_IndexExpr_gen},
{(char*)0,(id (*)())0}
};
id IndexExpr = (id)&_IndexExpr;
id  *OBJCCLASS_IndexExpr(void) { return &IndexExpr; }
struct _SHARED  _IndexExpr = {
  (id)&__IndexExpr,
  (id)&_Expr,
  "IndexExpr",
  0,
  sizeof(struct IndexExpr_PRIVATE),
  7,
  _IndexExpr_nstDispatchTbl,
  41,
  &indexxpr_modDesc,
  0,
  (id)0,
  &IndexExpr,
};
id  OBJCCFUNC_IndexExpr(void) { return (id)&_IndexExpr; }
id  OBJCCSUPER_IndexExpr(void) { return _IndexExpr.clsSuper; }
struct _SHARED __IndexExpr = {
  (id)&__Object,
  (id)&__Expr,
  "IndexExpr",
  0,
  sizeof(struct _SHARED),
  0,
  _IndexExpr_clsDispatchTbl,
  34,
  &indexxpr_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_IndexExpr(void) { return (id)&__IndexExpr; }
id  OBJCMSUPER_IndexExpr(void) { return __IndexExpr.clsSuper; }
static char *_selTransTbl[] ={
"lineno",
"filename",
"synth",
"type",
"star",
"gen",
0
};
struct modDescriptor indexxpr_modDesc = {
  "indexxpr",
  "objc2.3.1",
  0L,
  0,
  0,
  &IndexExpr,
  6,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_indexxpr(void)
{
  selTransTbl = _selTransTbl;
  return &indexxpr_modDesc;
}
int _OBJCPOSTLINK_indexxpr = 1;


