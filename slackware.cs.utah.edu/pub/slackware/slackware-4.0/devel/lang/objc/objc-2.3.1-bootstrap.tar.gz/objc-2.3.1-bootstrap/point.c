#line 1 "point.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_point(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor point_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 32 "point.h"
struct Point_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 34 "point.h"
int xLoc;
int yLoc;};

#line 32 "point.h"
extern id  Point;

#line 32 "point.h"
extern struct _SHARED _Point;
extern struct _SHARED __Point;


#line 36 "point.m"
static id c_Point_new(struct Point_PRIVATE *self,SEL _cmd)
{
id objcT0;

#line 38 "point.m"
return(objcT0=(id)self,(*(id(*)(id,SEL,int,int))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0],0,0));
}

static id c_Point_x_y_(struct Point_PRIVATE *self,SEL _cmd,int x,int y)
{
id objcT1,objcT2;

#line 43 "point.m"
return(objcT1=(objcT2=__Point.clsSuper,(*_impSuper(objcT2,selTransTbl[1]))((id)self,selTransTbl[1])),(*(id(*)(id,SEL,int,int))_imp(objcT1,selTransTbl[0]))(objcT1,selTransTbl[0],x,y));
}

#line 53 "point.m"
static id i_Point_x_y_(struct Point_PRIVATE *self,SEL _cmd,int x,int y)
{self->
xLoc=x;self->yLoc=y;return(id)self;
}

static id i_Point_x_(struct Point_PRIVATE *self,SEL _cmd,int x)
{self->
xLoc=x;return(id)self;
}

static id i_Point_y_(struct Point_PRIVATE *self,SEL _cmd,int y)
{self->
yLoc=y;return(id)self;
}

static int i_Point_x(struct Point_PRIVATE *self,SEL _cmd)
{
return self->xLoc;
}

static int i_Point_y(struct Point_PRIVATE *self,SEL _cmd)
{
return self->yLoc;
}

#line 85 "point.m"
static unsigned i_Point_hash(struct Point_PRIVATE *self,SEL _cmd)
{
return self->xLoc^self->yLoc;
}

static BOOL i_Point_isEqual_(struct Point_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT3,objcT4,objcT5;
return(objcT3=aPoint,(*(BOOL(*)(id,SEL,id))_imp(objcT3,selTransTbl[2]))(objcT3,selTransTbl[2],(id)self->isa))&&
(objcT4=aPoint,(*(int(*)(id,SEL))_imp(objcT4,selTransTbl[3]))(objcT4,selTransTbl[3]))==self->xLoc&&(objcT5=aPoint,(*(int(*)(id,SEL))_imp(objcT5,selTransTbl[4]))(objcT5,selTransTbl[4]))==self->yLoc;
}

static BOOL i_Point_isBelow_(struct Point_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT6;

#line 99 "point.m"
return self->yLoc>(objcT6=aPoint,(*(int(*)(id,SEL))_imp(objcT6,selTransTbl[4]))(objcT6,selTransTbl[4]));
}

static BOOL i_Point_isAbove_(struct Point_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT7;

#line 104 "point.m"
return self->yLoc<(objcT7=aPoint,(*(int(*)(id,SEL))_imp(objcT7,selTransTbl[4]))(objcT7,selTransTbl[4]));
}

static BOOL i_Point_isLeft_(struct Point_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT8;

#line 109 "point.m"
return self->xLoc<(objcT8=aPoint,(*(int(*)(id,SEL))_imp(objcT8,selTransTbl[3]))(objcT8,selTransTbl[3]));
}

static BOOL i_Point_isRight_(struct Point_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT9;

#line 114 "point.m"
return self->xLoc>(objcT9=aPoint,(*(int(*)(id,SEL))_imp(objcT9,selTransTbl[3]))(objcT9,selTransTbl[3]));
}

#line 124 "point.m"
static id i_Point_moveBy_(struct Point_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT10,objcT11;
self->
#line 126 "point.m"
xLoc+=(objcT10=aPoint,(*(int(*)(id,SEL))_imp(objcT10,selTransTbl[3]))(objcT10,selTransTbl[3]));self->
yLoc+=(objcT11=aPoint,(*(int(*)(id,SEL))_imp(objcT11,selTransTbl[4]))(objcT11,selTransTbl[4]));
return(id)self;
}

static id i_Point_moveBy__(struct Point_PRIVATE *self,SEL _cmd,int x,int y)
{self->
xLoc+=x;self->
yLoc+=y;
return(id)self;
}

static id i_Point_moveTo_(struct Point_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT12,objcT13;
self->
#line 140 "point.m"
xLoc=(objcT12=aPoint,(*(int(*)(id,SEL))_imp(objcT12,selTransTbl[3]))(objcT12,selTransTbl[3]));self->
yLoc=(objcT13=aPoint,(*(int(*)(id,SEL))_imp(objcT13,selTransTbl[4]))(objcT13,selTransTbl[4]));
return(id)self;
}

static id i_Point_plus_(struct Point_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT14,objcT15;

#line 147 "point.m"
return(objcT14=(objcT15=(id)self,(*_imp(objcT15,selTransTbl[5]))(objcT15,selTransTbl[5])),(*_imp(objcT14,selTransTbl[6]))(objcT14,selTransTbl[6],aPoint));
}

#line 156 "point.m"
static id i_Point_printOn_(struct Point_PRIVATE *self,SEL _cmd,IOD aFile)
{
printf("(%i,%i)",self->xLoc,self->yLoc);
return(id)self;
}


static id i_Point_fileOutOn_(struct Point_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT16,objcT17,objcT18;

#line 165 "point.m"
(objcT16=_Point.clsSuper,(*_impSuper(objcT16,selTransTbl[7]))((id)self,selTransTbl[7],aFiler));
(objcT17=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT17,selTransTbl[8]))(objcT17,selTransTbl[8], &self->xLoc,'i'));
(objcT18=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT18,selTransTbl[8]))(objcT18,selTransTbl[8], &self->yLoc,'i'));
return(id)self;
}

static id i_Point_fileInFrom_(struct Point_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT19,objcT20,objcT21;

#line 173 "point.m"
(objcT19=_Point.clsSuper,(*_impSuper(objcT19,selTransTbl[9]))((id)self,selTransTbl[9],aFiler));
(objcT20=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT20,selTransTbl[10]))(objcT20,selTransTbl[10], &self->xLoc,'i'));
(objcT21=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT21,selTransTbl[10]))(objcT21,selTransTbl[10], &self->yLoc,'i'));
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
static struct _SLT _Point_clsDispatchTbl[] ={
{"new",(id (*)())c_Point_new},
{"x:y:",(id (*)())c_Point_x_y_},
{(char*)0,(id (*)())0}
};
static struct _SLT _Point_nstDispatchTbl[] ={
{"x:y:",(id (*)())i_Point_x_y_},
{"x:",(id (*)())i_Point_x_},
{"y:",(id (*)())i_Point_y_},
{"x",(id (*)())i_Point_x},
{"y",(id (*)())i_Point_y},
{"hash",(id (*)())i_Point_hash},
{"isEqual:",(id (*)())i_Point_isEqual_},
{"isBelow:",(id (*)())i_Point_isBelow_},
{"isAbove:",(id (*)())i_Point_isAbove_},
{"isLeft:",(id (*)())i_Point_isLeft_},
{"isRight:",(id (*)())i_Point_isRight_},
{"moveBy:",(id (*)())i_Point_moveBy_},
{"moveBy::",(id (*)())i_Point_moveBy__},
{"moveTo:",(id (*)())i_Point_moveTo_},
{"plus:",(id (*)())i_Point_plus_},
{"printOn:",(id (*)())i_Point_printOn_},
{"fileOutOn:",(id (*)())i_Point_fileOutOn_},
{"fileInFrom:",(id (*)())i_Point_fileInFrom_},
{(char*)0,(id (*)())0}
};
id Point = (id)&_Point;
id  *OBJCCLASS_Point(void) { return &Point; }
struct _SHARED  _Point = {
  (id)&__Point,
  (id)&_Object,
  "Point",
  0,
  sizeof(struct Point_PRIVATE),
  18,
  _Point_nstDispatchTbl,
  41,
  &point_modDesc,
  0,
  (id)0,
  &Point,
};
id  OBJCCFUNC_Point(void) { return (id)&_Point; }
id  OBJCCSUPER_Point(void) { return _Point.clsSuper; }
struct _SHARED __Point = {
  (id)&__Object,
  (id)&__Object,
  "Point",
  0,
  sizeof(struct _SHARED),
  2,
  _Point_clsDispatchTbl,
  34,
  &point_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_Point(void) { return (id)&__Point; }
id  OBJCMSUPER_Point(void) { return __Point.clsSuper; }
static char *_selTransTbl[] ={
"x:y:",
"new",
"isKindOf:",
"x",
"y",
"copy",
"moveBy:",
"fileOutOn:",
"fileOut:type:",
"fileInFrom:",
"fileIn:type:",
0
};
struct modDescriptor point_modDesc = {
  "point",
  "objc2.3.1",
  0L,
  0,
  0,
  &Point,
  11,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_point(void)
{
  selTransTbl = _selTransTbl;
  return &point_modDesc;
}
int _OBJCPOSTLINK_point = 1;


