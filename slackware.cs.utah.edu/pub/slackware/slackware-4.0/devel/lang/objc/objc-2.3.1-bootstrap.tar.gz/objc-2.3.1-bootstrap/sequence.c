#line 1 "sequence.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_sequence(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor sequence_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 38 "../../include/objcrt/Block.h"
extern id newBlock(int n,IMP fn,void*data,IMP dtor);
#line 35 "sequence.h"
struct Sequence_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 37 "sequence.h"
id carrier;};

#line 35 "sequence.h"
extern id  Sequence;

#line 35 "sequence.h"
extern struct _SHARED _Sequence;
extern struct _SHARED __Sequence;


#line 36 "sequence.m"
static id i_Sequence_setUpCarrier_(struct Sequence_PRIVATE *self,SEL _cmd,id aCarrier)
{self->
carrier=aCarrier;return(id)self;
}

static id c_Sequence_over_(struct Sequence_PRIVATE *self,SEL _cmd,id aCarrier)
{
id objcT0,objcT1;

#line 43 "sequence.m"
id newObj=(objcT0=__Sequence.clsSuper,(*_impSuper(objcT0,selTransTbl[0]))((id)self,selTransTbl[0]));(objcT1=newObj,(*_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1],aCarrier));return newObj;
}

static id i_Sequence_over_(struct Sequence_PRIVATE *self,SEL _cmd,id aCarrier)
{
id objcT2;

#line 48 "sequence.m"
return(objcT2=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT2,selTransTbl[2]))(objcT2,selTransTbl[2],_cmd));
}

static id i_Sequence_copy(struct Sequence_PRIVATE *self,SEL _cmd)
{
id objcT3,objcT4;

#line 53 "sequence.m"
return(objcT3=self->isa,(*_imp(objcT3,selTransTbl[3]))(objcT3,selTransTbl[3],(objcT4=self->carrier,(*_imp(objcT4,selTransTbl[4]))(objcT4,selTransTbl[4]))));
}

static id i_Sequence_free(struct Sequence_PRIVATE *self,SEL _cmd)
{
id objcT5,objcT6;
self->
#line 58 "sequence.m"
carrier=(objcT5=self->carrier,(*_imp(objcT5,selTransTbl[5]))(objcT5,selTransTbl[5]));return(objcT6=_Sequence.clsSuper,(*_impSuper(objcT6,selTransTbl[5]))((id)self,selTransTbl[5]));
}

static id i_Sequence_release(struct Sequence_PRIVATE *self,SEL _cmd)
{
id objcT7;
self->
#line 63 "sequence.m"
carrier=(id)0;return(objcT7=_Sequence.clsSuper,(*_impSuper(objcT7,selTransTbl[6]))((id)self,selTransTbl[6]));
}

#line 72 "sequence.m"
static unsigned i_Sequence_size(struct Sequence_PRIVATE *self,SEL _cmd)
{
id objcT8;

#line 74 "sequence.m"
return(objcT8=self->carrier,(*(unsigned(*)(id,SEL))_imp(objcT8,selTransTbl[7]))(objcT8,selTransTbl[7]));
}

#line 83 "sequence.m"
static id i_Sequence_next(struct Sequence_PRIVATE *self,SEL _cmd)
{
id objcT9;

#line 85 "sequence.m"
return(objcT9=self->carrier,(*_imp(objcT9,selTransTbl[8]))(objcT9,selTransTbl[8]));
}

static id i_Sequence_peek(struct Sequence_PRIVATE *self,SEL _cmd)
{
id objcT10;

#line 90 "sequence.m"
return(objcT10=self->carrier,(*_imp(objcT10,selTransTbl[9]))(objcT10,selTransTbl[9]));
}

static id i_Sequence_previous(struct Sequence_PRIVATE *self,SEL _cmd)
{
id objcT11;

#line 95 "sequence.m"
return(objcT11=self->carrier,(*_imp(objcT11,selTransTbl[10]))(objcT11,selTransTbl[10]));
}

static id i_Sequence_first(struct Sequence_PRIVATE *self,SEL _cmd)
{
id objcT12;

#line 100 "sequence.m"
return(objcT12=self->carrier,(*_imp(objcT12,selTransTbl[11]))(objcT12,selTransTbl[11]));
}

static id i_Sequence_last(struct Sequence_PRIVATE *self,SEL _cmd)
{
id objcT13;

#line 105 "sequence.m"
return(objcT13=self->carrier,(*_imp(objcT13,selTransTbl[12]))(objcT13,selTransTbl[12]));
}

#line 114 "sequence.m"
static id i_Sequence_printOn_(struct Sequence_PRIVATE *self,SEL _cmd,IOD aFile)
{
id objcT14;

#line 116 "sequence.m"
id aMember;
while((aMember=(objcT14=(id)self,(*_imp(objcT14,selTransTbl[8]))(objcT14,selTransTbl[8])))){
id objcT15;

#line 118 "sequence.m"
(objcT15=aMember,(*(id(*)(id,SEL,IOD))_imp(objcT15,selTransTbl[13]))(objcT15,selTransTbl[13],aFile));fprintf(aFile,"\n");
}
return(id)self;
}

#line 130 "sequence.m"
static id i_Sequence_do_(struct Sequence_PRIVATE *self,SEL _cmd,id aBlock)
{
id objcT16,objcT17;

#line 132 "sequence.m"
id aMember;
while((aMember=(objcT16=(id)self,(*_imp(objcT16,selTransTbl[8]))(objcT16,selTransTbl[8]))))(objcT17=aBlock,(*_imp(objcT17,selTransTbl[14]))(objcT17,selTransTbl[14],aMember));
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
static struct _SLT _Sequence_clsDispatchTbl[] ={
{"over:",(id (*)())c_Sequence_over_},
{(char*)0,(id (*)())0}
};
static struct _SLT _Sequence_nstDispatchTbl[] ={
{"setUpCarrier:",(id (*)())i_Sequence_setUpCarrier_},
{"over:",(id (*)())i_Sequence_over_},
{"copy",(id (*)())i_Sequence_copy},
{"free",(id (*)())i_Sequence_free},
{"release",(id (*)())i_Sequence_release},
{"size",(id (*)())i_Sequence_size},
{"next",(id (*)())i_Sequence_next},
{"peek",(id (*)())i_Sequence_peek},
{"previous",(id (*)())i_Sequence_previous},
{"first",(id (*)())i_Sequence_first},
{"last",(id (*)())i_Sequence_last},
{"printOn:",(id (*)())i_Sequence_printOn_},
{"do:",(id (*)())i_Sequence_do_},
{(char*)0,(id (*)())0}
};
id Sequence = (id)&_Sequence;
id  *OBJCCLASS_Sequence(void) { return &Sequence; }
struct _SHARED  _Sequence = {
  (id)&__Sequence,
  (id)&_Object,
  "Sequence",
  0,
  sizeof(struct Sequence_PRIVATE),
  13,
  _Sequence_nstDispatchTbl,
  41,
  &sequence_modDesc,
  0,
  (id)0,
  &Sequence,
};
id  OBJCCFUNC_Sequence(void) { return (id)&_Sequence; }
id  OBJCCSUPER_Sequence(void) { return _Sequence.clsSuper; }
struct _SHARED __Sequence = {
  (id)&__Object,
  (id)&__Object,
  "Sequence",
  0,
  sizeof(struct _SHARED),
  1,
  _Sequence_clsDispatchTbl,
  34,
  &sequence_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_Sequence(void) { return (id)&__Sequence; }
id  OBJCMSUPER_Sequence(void) { return __Sequence.clsSuper; }
static char *_selTransTbl[] ={
"new",
"setUpCarrier:",
"notImplemented:",
"over:",
"copy",
"free",
"release",
"size",
"next",
"peek",
"previous",
"first",
"last",
"printOn:",
"value:",
0
};
struct modDescriptor sequence_modDesc = {
  "sequence",
  "objc2.3.1",
  0L,
  0,
  0,
  &Sequence,
  15,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_sequence(void)
{
  selTransTbl = _selTransTbl;
  return &sequence_modDesc;
}
int _OBJCPOSTLINK_sequence = 1;


