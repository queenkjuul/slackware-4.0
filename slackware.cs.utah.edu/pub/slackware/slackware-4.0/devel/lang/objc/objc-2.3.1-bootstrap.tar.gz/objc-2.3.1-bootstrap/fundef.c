#line 1 "fundef.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_fundef(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor fundef_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 31 "../../include/objpak/ordcltn.h"
typedef struct objcol{
int count;
int capacity;
id*ptr;
}*objcol_t;
#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "def.h"
extern id curdef;
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 22 "compstmt.h"
extern id curcompound;
extern id curloopcompound;
#line 22 "trlunit.h"
extern id trlunit;
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 22 "fundef.h"
struct FunctionDef_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 26 "def.h"
id parmdic;
id heapvars;
id parmnames;
id classreferences;
id blockreferences;
id heapvarblocks;
#line 24 "fundef.h"
id datadefspecs,decl,body;
BOOL isinline,isstatic,isextern,istypedef;};

#line 22 "fundef.h"
extern id  FunctionDef;

#line 22 "fundef.h"
extern struct _SHARED _FunctionDef;
extern struct _SHARED __FunctionDef;


#line 42 "fundef.m"
static id i_FunctionDef_compound(struct FunctionDef_PRIVATE *self,SEL _cmd)
{
id objcT0;

#line 44 "fundef.m"
return(objcT0=self->body,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
}

static BOOL i_FunctionDef_isfundef(struct FunctionDef_PRIVATE *self,SEL _cmd)
{
return(BOOL)1;
}

static id i_FunctionDef_datadefspecs_(struct FunctionDef_PRIVATE *self,SEL _cmd,id s)
{self->
datadefspecs=s;
return(id)self;
}

static id i_FunctionDef_decl_(struct FunctionDef_PRIVATE *self,SEL _cmd,id d)
{self->
decl=d;
return(id)self;
}

static id i_FunctionDef_body_(struct FunctionDef_PRIVATE *self,SEL _cmd,id b)
{self->
body=b;
return(id)self;
}

static id i_FunctionDef_synthattrs(struct FunctionDef_PRIVATE *self,SEL _cmd)
{
id objcT1;

#line 72 "fundef.m"
int i,n;

for(i=0,n=(objcT1=self->datadefspecs,(*(unsigned(*)(id,SEL))_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1]));i<n;i++){
id objcT2,objcT3;

#line 75 "fundef.m"
id s=(objcT2=self->datadefspecs,(*(id(*)(id,SEL,unsigned))_imp(objcT2,selTransTbl[2]))(objcT2,selTransTbl[2],i));

if((objcT3=s,(*(BOOL(*)(id,SEL))_imp(objcT3,selTransTbl[3]))(objcT3,selTransTbl[3]))){
id objcT4,objcT5,objcT6,objcT7;

#line 78 "fundef.m"
if((objcT4=s,(*(BOOL(*)(id,SEL))_imp(objcT4,selTransTbl[4]))(objcT4,selTransTbl[4])))self->
istypedef++;
else if((objcT5=s,(*(BOOL(*)(id,SEL))_imp(objcT5,selTransTbl[5]))(objcT5,selTransTbl[5])))self->
isstatic++;
else if((objcT6=s,(*(BOOL(*)(id,SEL))_imp(objcT6,selTransTbl[6]))(objcT6,selTransTbl[6])))self->
isinline++;
else if((objcT7=s,(*(BOOL(*)(id,SEL))_imp(objcT7,selTransTbl[7]))(objcT7,selTransTbl[7])))self->
isextern++;
}
}
return(id)self;
}

static BOOL i_FunctionDef_definesocu(struct FunctionDef_PRIVATE *self,SEL _cmd)
{
return !self->isstatic&& !self->isinline;
}

#line 33 "type.h"
extern id  Type;

#line 96 "fundef.m"
static id i_FunctionDef_restype(struct FunctionDef_PRIVATE *self,SEL _cmd)
{
id objcT8,objcT9,objcT10,objcT11,objcT12;

#line 98 "fundef.m"
id x,v=(objcT8=self->decl,(*_imp(objcT8,selTransTbl[8]))(objcT8,selTransTbl[8]));

x=(objcT9=trlunit,(*_imp(objcT9,selTransTbl[9]))(objcT9,selTransTbl[9],v));
assert((objcT10=x,(*(BOOL(*)(id,SEL,id))_imp(objcT10,selTransTbl[10]))(objcT10,selTransTbl[10],(id)(objcT11=Type,(*_imp(objcT11,selTransTbl[11]))(objcT11,selTransTbl[11])))));
return(objcT12=x,(*_imp(objcT12,selTransTbl[12]))(objcT12,selTransTbl[12]));
}

static id i_FunctionDef_synth(struct FunctionDef_PRIVATE *self,SEL _cmd)
{
id objcT13,objcT14,objcT15,objcT16,objcT17;
id objcT18,objcT19;

#line 107 "fundef.m"
id v;

curdef=(id)self;
curcompound=(id)0;


(objcT13=self->decl,(*_imp(objcT13,selTransTbl[13]))(objcT13,selTransTbl[13]));
(objcT14=(id)self,(*_imp(objcT14,selTransTbl[14]))(objcT14,selTransTbl[14]));
v=(objcT15=self->decl,(*_imp(objcT15,selTransTbl[8]))(objcT15,selTransTbl[8]));
if(self->istypedef)
fatal("illegal storage class for %s",(objcT16=v,(*(STR(*)(id,SEL))_imp(objcT16,selTransTbl[15]))(objcT16,selTransTbl[15])));
if( !o_postlink&&(objcT17=(id)self,(*(BOOL(*)(id,SEL))_imp(objcT17,selTransTbl[16]))(objcT17,selTransTbl[16])))
(objcT18=trlunit,(*_imp(objcT18,selTransTbl[17]))(objcT18,selTransTbl[17],v));
(objcT19=self->body,(*_imp(objcT19,selTransTbl[13]))(objcT19,selTransTbl[13]));
curdef=(id)0;
return(id)self;
}

#line 58 "symbol.h"
extern id  Symbol;

#line 125 "fundef.m"
static id i_FunctionDef_genmain(struct FunctionDef_PRIVATE *self,SEL _cmd)
{
id objcT24,objcT25,objcT26,objcT27,objcT28;
id objcT29,objcT30;

#line 127 "fundef.m"
if(o_initcall){
char*fmt;

gc('\n');
if( !o_shareddata){
gs("extern struct useDescriptor *OCU_main;\n");
gs("extern struct modEntry *_objcModules;\n");
if(o_cplus){
fmt="extern \"C\" int %s(void *mods,void *desc);\n";
}else{
fmt="extern int %s(void *mods,void *desc);\n";
}
}else{
if(o_cplus){
fmt="extern \"C\" int %s(int debug,int traceInit);\n";
}else{
fmt="extern int %s(int debug,int traceInit);\n";
}
}
gf(fmt,o_initcall);
}else{
fatal("no initialization call defined (use -init)");
}

if(o_filer){
id objcT20,objcT21,objcT22,objcT23;

#line 152 "fundef.m"
gs((o_cplus)?"extern \"C\"":"extern");
gs(" void *_OBJCBIND_ascfiler(void);\n");
gs((o_cplus)?"extern \"C\"":"extern");
gs(" void *_OBJCBIND_ocstring(void);\n");
if( !o_postlink)
(objcT20=trlunit,(*_imp(objcT20,selTransTbl[18]))(objcT20,selTransTbl[18],(objcT21=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT21,selTransTbl[19]))(objcT21,selTransTbl[19],"AsciiFiler"))));
if( !o_postlink)
(objcT22=trlunit,(*_imp(objcT22,selTransTbl[18]))(objcT22,selTransTbl[18],(objcT23=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT23,selTransTbl[19]))(objcT23,selTransTbl[19],"String"))));
}
if(self->datadefspecs)
(objcT24=self->datadefspecs,(*(id(*)(id,SEL,SEL))_imp(objcT24,selTransTbl[20]))(objcT24,selTransTbl[20],selTransTbl[21]));
(objcT25=self->decl,(*_imp(objcT25,selTransTbl[21]))(objcT25,selTransTbl[21]));
gs("{\n");

if(o_filer){
gs("_OBJCBIND_ascfiler();\n");
gs("_OBJCBIND_ocstring();\n");
}
if( !o_cache){
gs("noCacheFlag=1;\n");
}
if( !o_nilrcvr){
gs("noNilRcvr=1;\n");
}
if( !o_shareddata){
gf("%s(_objcModules,OCU_main);\n",o_initcall);
}else{
gf("%s(0,0);\n",o_initcall);
}

if( !o_postlink)
(objcT26=trlunit,(*_imp(objcT26,selTransTbl[18]))(objcT26,selTransTbl[18],(objcT27=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT27,selTransTbl[19]))(objcT27,selTransTbl[19],o_initcall))));

if(self->datadefspecs==(id)0|| !(objcT28=(objcT29=self->datadefspecs,(*(id(*)(id,SEL,unsigned))_imp(objcT29,selTransTbl[2]))(objcT29,selTransTbl[2],0)),(*(BOOL(*)(id,SEL))_imp(objcT28,selTransTbl[22]))(objcT28,selTransTbl[22])))
gs("return");
gs((objcT30=s_objcmain,(*(STR(*)(id,SEL))_imp(objcT30,selTransTbl[15]))(objcT30,selTransTbl[15])));
gc('(');
o_nolinetags++;
if(self->parmnames)
gcommalist(self->parmnames);
o_nolinetags--;
gs(");\n");

gs("}\n");
return(id)self;
}

static id i_FunctionDef_gen(struct FunctionDef_PRIVATE *self,SEL _cmd)
{
id objcT31,objcT32,objcT33,objcT34,objcT38;
id objcT39;

#line 201 "fundef.m"
BOOL ismain;

assert(self->decl!=(id)0&&self->body!=(id)0);
ismain= !strcmp((objcT31=(objcT32=self->decl,(*_imp(objcT32,selTransTbl[8]))(objcT32,selTransTbl[8])),(*(STR(*)(id,SEL))_imp(objcT31,selTransTbl[15]))(objcT31,selTransTbl[15])),o_mainfun);
(objcT33=_FunctionDef.clsSuper,(*_impSuper(objcT33,selTransTbl[21]))((id)self,selTransTbl[21]));
if(self->datadefspecs)
(objcT34=self->datadefspecs,(*(id(*)(id,SEL,SEL))_imp(objcT34,selTransTbl[20]))(objcT34,selTransTbl[20],selTransTbl[21]));
if(ismain){
id objcT35,objcT36;

#line 209 "fundef.m"
o_nolinetags++;
(objcT35=self->decl,(*_imp(objcT35,selTransTbl[23]))(objcT35,selTransTbl[23],s_objcmain));
o_nolinetags--;
(objcT36=trlunit,(*_imp(objcT36,selTransTbl[17]))(objcT36,selTransTbl[17],s_main));
}else{
id objcT37;

#line 214 "fundef.m"
(objcT37=self->decl,(*_imp(objcT37,selTransTbl[21]))(objcT37,selTransTbl[21]));
}
(objcT38=self->body,(*_imp(objcT38,selTransTbl[21]))(objcT38,selTransTbl[21]));
if(ismain)
(objcT39=(id)self,(*_imp(objcT39,selTransTbl[24]))(objcT39,selTransTbl[24]));
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Def;
extern struct _SHARED _Def;
extern struct _SHARED __Def;
static struct _SLT _FunctionDef_clsDispatchTbl[] ={
{(char*)0,(id (*)())0}
};
static struct _SLT _FunctionDef_nstDispatchTbl[] ={
{"compound",(id (*)())i_FunctionDef_compound},
{"isfundef",(id (*)())i_FunctionDef_isfundef},
{"datadefspecs:",(id (*)())i_FunctionDef_datadefspecs_},
{"decl:",(id (*)())i_FunctionDef_decl_},
{"body:",(id (*)())i_FunctionDef_body_},
{"synthattrs",(id (*)())i_FunctionDef_synthattrs},
{"definesocu",(id (*)())i_FunctionDef_definesocu},
{"restype",(id (*)())i_FunctionDef_restype},
{"synth",(id (*)())i_FunctionDef_synth},
{"genmain",(id (*)())i_FunctionDef_genmain},
{"gen",(id (*)())i_FunctionDef_gen},
{(char*)0,(id (*)())0}
};
id FunctionDef = (id)&_FunctionDef;
id  *OBJCCLASS_FunctionDef(void) { return &FunctionDef; }
struct _SHARED  _FunctionDef = {
  (id)&__FunctionDef,
  (id)&_Def,
  "FunctionDef",
  0,
  sizeof(struct FunctionDef_PRIVATE),
  11,
  _FunctionDef_nstDispatchTbl,
  41,
  &fundef_modDesc,
  0,
  (id)0,
  &FunctionDef,
};
id  OBJCCFUNC_FunctionDef(void) { return (id)&_FunctionDef; }
id  OBJCCSUPER_FunctionDef(void) { return _FunctionDef.clsSuper; }
struct _SHARED __FunctionDef = {
  (id)&__Object,
  (id)&__Def,
  "FunctionDef",
  0,
  sizeof(struct _SHARED),
  0,
  _FunctionDef_clsDispatchTbl,
  34,
  &fundef_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_FunctionDef(void) { return (id)&__FunctionDef; }
id  OBJCMSUPER_FunctionDef(void) { return __FunctionDef.clsSuper; }
static char *_selTransTbl[] ={
"compound",
"size",
"at:",
"isstorageclass",
"istypedef",
"isstatic",
"isinline",
"isextern",
"identifier",
"lookupglobal:",
"isKindOf:",
"class",
"funcall",
"synth",
"synthattrs",
"str",
"definesocu",
"definesentry:",
"usesentry:",
"str:",
"elementsPerform:",
"gen",
"isvoid",
"gendef:",
"genmain",
0
};
struct modDescriptor fundef_modDesc = {
  "fundef",
  "objc2.3.1",
  0L,
  0,
  0,
  &FunctionDef,
  25,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_fundef(void)
{
  selTransTbl = _selTransTbl;
  return &fundef_modDesc;
}
int _OBJCPOSTLINK_fundef = 1;


