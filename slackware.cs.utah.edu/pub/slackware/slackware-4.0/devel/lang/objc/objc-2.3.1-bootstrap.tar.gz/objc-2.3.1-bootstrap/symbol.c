#line 1 "symbol.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_symbol(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor symbol_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 22 "trlunit.h"
extern id trlunit;
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;

#line 35 "symbol.m"
BOOL
istypeword(id sym)
{
id objcT0;

#line 38 "symbol.m"
return(objcT0=trlunit,(*(BOOL(*)(id,SEL,id))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0],sym));
}

BOOL
isbuiltinfun(id sym)
{
id objcT1;

#line 44 "symbol.m"
return(objcT1=trlunit,(*(BOOL(*)(id,SEL,id))_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1],sym));
}

#line 58 "symbol.h"
extern id  Symbol;

#line 47 "symbol.m"
void
definebuiltinfun(char*s)
{
id objcT2,objcT3,objcT4,objcT5;

#line 50 "symbol.m"
id x=(objcT2=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT2,selTransTbl[2]))(objcT2,selTransTbl[2],s));

x=(objcT3=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT3,selTransTbl[2]))(objcT3,selTransTbl[2],strtok((objcT4=x,(*(STR(*)(id,SEL))_imp(objcT4,selTransTbl[3]))(objcT4,selTransTbl[3]))," \t\n\r/")));
(objcT5=trlunit,(*_imp(objcT5,selTransTbl[4]))(objcT5,selTransTbl[4],x));
}

int
pragmatoggle(char*s)
{
id objcT6,objcT7;

#line 59 "symbol.m"
id x=(objcT6=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT6,selTransTbl[2]))(objcT6,selTransTbl[2],s));
#line 63 "symbol.m"
return atoi(strtok((objcT7=x,(*(STR(*)(id,SEL))_imp(objcT7,selTransTbl[3]))(objcT7,selTransTbl[3]))," \t\n\r/"));
}

void
definebuiltinvar(char*s)
{
id objcT8,objcT9,objcT10,objcT11;

#line 69 "symbol.m"
id x=(objcT8=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT8,selTransTbl[2]))(objcT8,selTransTbl[2],s));

x=(objcT9=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT9,selTransTbl[2]))(objcT9,selTransTbl[2],strtok((objcT10=x,(*(STR(*)(id,SEL))_imp(objcT10,selTransTbl[3]))(objcT10,selTransTbl[3]))," \t\n\r/")));
(objcT11=trlunit,(*_imp(objcT11,selTransTbl[5]))(objcT11,selTransTbl[5],x,t_int));
}

void
definebuiltintype(char*s)
{
id objcT12,objcT13,objcT14,objcT15;

#line 78 "symbol.m"
id x=(objcT12=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT12,selTransTbl[2]))(objcT12,selTransTbl[2],s));

x=(objcT13=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT13,selTransTbl[2]))(objcT13,selTransTbl[2],strtok((objcT14=x,(*(STR(*)(id,SEL))_imp(objcT14,selTransTbl[3]))(objcT14,selTransTbl[3]))," \t\n\r/")));
(objcT15=trlunit,(*_imp(objcT15,selTransTbl[6]))(objcT15,selTransTbl[6],x));
}
#line 58 "symbol.h"
struct Symbol_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 34 "../../include/objpak/array.h"
unsigned capacity;
#line 40 "../../include/objpak/ocstring.h"
struct objstr value;
#line 60 "symbol.h"
int lineno;
id filename;
id type;};

#line 58 "symbol.h"
extern struct _SHARED _Symbol;
extern struct _SHARED __Symbol;

#line 86 "symbol.m"
id s_void;
id s_char;
id s_bool;
id s_int;
id s_long;
id s_double;
id s_str;
id s_sel;
id s_id;
id s_nil;
id s_self;
id s_cmd;
id s_super;
id s_newblock;
id s_main;
id s_objcmain;
id s_aFiler;
id s_type;
id s_fileIn;
id s_fileOut;
id s_fileInIdsFrom;
id s_fileOutIdsFor;
id s_returnval;
id s_returnflag;
id s_increfs;
id s_decrefs;
id s_idincref;
id s_iddecref;

static id c_Symbol_commonsymbols(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT16,objcT17,objcT18,objcT19,objcT20;
id objcT21,objcT22,objcT23,objcT24,objcT25;
id objcT26,objcT27,objcT28,objcT29,objcT30;
id objcT31,objcT32,objcT33,objcT34,objcT35;
id objcT36,objcT37,objcT38,objcT39,objcT40;
id objcT41,objcT42,objcT43;

#line 117 "symbol.m"
s_newblock=(objcT16=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT16,selTransTbl[2]))(objcT16,selTransTbl[2],"newBlock"));
assert(o_mainfun!=NULL);
s_main=(objcT17=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT17,selTransTbl[2]))(objcT17,selTransTbl[2],o_mainfun));
s_objcmain=(objcT18=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT18,selTransTbl[2]))(objcT18,selTransTbl[2],"objcmain"));
s_void=(objcT19=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT19,selTransTbl[2]))(objcT19,selTransTbl[2],"void"));
s_char=(objcT20=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT20,selTransTbl[2]))(objcT20,selTransTbl[2],"char"));
s_bool=(objcT21=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT21,selTransTbl[2]))(objcT21,selTransTbl[2],"BOOL"));
s_int=(objcT22=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT22,selTransTbl[2]))(objcT22,selTransTbl[2],"int"));
s_long=(objcT23=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT23,selTransTbl[2]))(objcT23,selTransTbl[2],"long"));
s_double=(objcT24=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT24,selTransTbl[2]))(objcT24,selTransTbl[2],"double"));
s_str=(objcT25=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT25,selTransTbl[2]))(objcT25,selTransTbl[2],"STR"));
s_sel=(objcT26=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT26,selTransTbl[2]))(objcT26,selTransTbl[2],"SEL"));
s_id=(objcT27=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT27,selTransTbl[2]))(objcT27,selTransTbl[2],"id"));
s_nil=(objcT28=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT28,selTransTbl[2]))(objcT28,selTransTbl[2],"(id)0"));
s_self=(objcT29=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT29,selTransTbl[2]))(objcT29,selTransTbl[2],"self"));
s_cmd=(objcT30=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT30,selTransTbl[2]))(objcT30,selTransTbl[2],"_cmd"));
s_super=(objcT31=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT31,selTransTbl[2]))(objcT31,selTransTbl[2],"super"));
s_type=(objcT32=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT32,selTransTbl[2]))(objcT32,selTransTbl[2],"type"));
s_aFiler=(objcT33=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT33,selTransTbl[2]))(objcT33,selTransTbl[2],"aFiler"));
s_fileIn=(objcT34=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT34,selTransTbl[2]))(objcT34,selTransTbl[2],"fileIn"));
s_fileOut=(objcT35=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT35,selTransTbl[2]))(objcT35,selTransTbl[2],"fileOut"));
s_fileInIdsFrom=(objcT36=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT36,selTransTbl[2]))(objcT36,selTransTbl[2],"fileInIdsFrom"));
s_fileOutIdsFor=(objcT37=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT37,selTransTbl[2]))(objcT37,selTransTbl[2],"fileOutIdsFor"));
s_returnflag=(objcT38=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT38,selTransTbl[2]))(objcT38,selTransTbl[2],"_returnflag"));
s_returnval=(objcT39=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT39,selTransTbl[2]))(objcT39,selTransTbl[2],"_returnval"));
s_increfs=(objcT40=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT40,selTransTbl[2]))(objcT40,selTransTbl[2],"increfs"));
s_decrefs=(objcT41=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT41,selTransTbl[2]))(objcT41,selTransTbl[2],"decrefs"));
s_idincref=(objcT42=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT42,selTransTbl[2]))(objcT42,selTransTbl[2],"idincref"));
s_iddecref=(objcT43=Symbol,(*(id(*)(id,SEL,STR))_imp(objcT43,selTransTbl[2]))(objcT43,selTransTbl[2],"iddecref"));

return(id)self;
}

static id c_Symbol_str_lineno_filename_(struct Symbol_PRIVATE *self,SEL _cmd,char*s,int no,id fn)
{
id objcT44,objcT45;

#line 152 "symbol.m"
return(objcT44=(objcT45=__Symbol.clsSuper,(*(id(*)(id,SEL,STR))_impSuper(objcT45,selTransTbl[2]))((id)self,selTransTbl[2],s)),(*(id(*)(id,SEL,int,id))_imp(objcT44,selTransTbl[7]))(objcT44,selTransTbl[7],no,fn));
}

static id i_Symbol_type(struct Symbol_PRIVATE *self,SEL _cmd)
{
return self->type;
}

static id i_Symbol_filename(struct Symbol_PRIVATE *self,SEL _cmd)
{
return self->filename;
}

static int i_Symbol_lineno(struct Symbol_PRIVATE *self,SEL _cmd)
{
return self->lineno;
}

static id i_Symbol_type_(struct Symbol_PRIVATE *self,SEL _cmd,id fn)
{self->
type=fn;
return(id)self;
}

static id i_Symbol_filename_(struct Symbol_PRIVATE *self,SEL _cmd,id fn)
{self->
filename=fn;
return(id)self;
}

static id i_Symbol_lineno_(struct Symbol_PRIVATE *self,SEL _cmd,int no)
{self->
lineno=no;
return(id)self;
}

static id i_Symbol_lineno_filename_(struct Symbol_PRIVATE *self,SEL _cmd,int no,id fn)
{self->
lineno=no;self->
filename=fn;
return(id)self;
}

static id i_Symbol_synth(struct Symbol_PRIVATE *self,SEL _cmd)
{
return(id)self;
}

static id i_Symbol_gen(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT46,objcT47;

#line 202 "symbol.m"
gl(self->lineno,(objcT46=self->filename,(*(STR(*)(id,SEL))_imp(objcT46,selTransTbl[3]))(objcT46,selTransTbl[3])));
gs((objcT47=(id)self,(*(STR(*)(id,SEL))_imp(objcT47,selTransTbl[3]))(objcT47,selTransTbl[3])));
return(id)self;
}

static BOOL i_Symbol_canforward(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT48,objcT49,objcT50;

#line 209 "symbol.m"
id d;


if((objcT48=(id)self,(*(BOOL(*)(id,SEL))_imp(objcT48,selTransTbl[8]))(objcT48,selTransTbl[8])))
return(BOOL)0;
d=(objcT49=trlunit,(*_imp(objcT49,selTransTbl[9]))(objcT49,selTransTbl[9],(id)self));
return(d)?(objcT50=d,(*(BOOL(*)(id,SEL))_imp(objcT50,selTransTbl[10]))(objcT50,selTransTbl[10])):(BOOL)1;
}

static id i_Symbol_dot_(struct Symbol_PRIVATE *self,SEL _cmd,id sym)
{
id objcT51,objcT52;

#line 220 "symbol.m"
id d=(objcT51=trlunit,(*_imp(objcT51,selTransTbl[9]))(objcT51,selTransTbl[9],(id)self));

return(d)?(objcT52=d,(*_imp(objcT52,selTransTbl[11]))(objcT52,selTransTbl[11],sym)):(id)0;
}

static id i_Symbol_star(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT53,objcT54;

#line 227 "symbol.m"
id d=(objcT53=trlunit,(*_imp(objcT53,selTransTbl[9]))(objcT53,selTransTbl[9],(id)self));

return(d)?(objcT54=d,(*_imp(objcT54,selTransTbl[12]))(objcT54,selTransTbl[12])):(id)0;
}

static id i_Symbol_funcall(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT55,objcT56;

#line 234 "symbol.m"
id d=(objcT55=trlunit,(*_imp(objcT55,selTransTbl[9]))(objcT55,selTransTbl[9],(id)self));

return(d)?(objcT56=d,(*_imp(objcT56,selTransTbl[13]))(objcT56,selTransTbl[13])):(id)0;
}

static BOOL i_Symbol_isselptr(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT57,objcT58,objcT59;

#line 241 "symbol.m"
id d=(objcT57=trlunit,(*_imp(objcT57,selTransTbl[9]))(objcT57,selTransTbl[9],(id)self));

if((objcT58=(id)self,(*(BOOL(*)(id,SEL))_imp(objcT58,selTransTbl[14]))(objcT58,selTransTbl[14])))
return(BOOL)1;
return(d)?(objcT59=d,(*(BOOL(*)(id,SEL))_imp(objcT59,selTransTbl[15]))(objcT59,selTransTbl[15])):(BOOL)0;
}

static BOOL i_Symbol_isid(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT60;

#line 250 "symbol.m"
return((id)self==s_id)?(BOOL)1:(strcmp((objcT60=(id)self,(*(STR(*)(id,SEL))_imp(objcT60,selTransTbl[3]))(objcT60,selTransTbl[3])),"id")==0);
}

static BOOL i_Symbol_isvoid(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT61;

#line 255 "symbol.m"
return((id)self==s_void)?(BOOL)1:(strcmp((objcT61=(id)self,(*(STR(*)(id,SEL))_imp(objcT61,selTransTbl[3]))(objcT61,selTransTbl[3])),"void")==0);
}

static BOOL i_Symbol_isstorageclass(struct Symbol_PRIVATE *self,SEL _cmd)
{
return(BOOL)0;
}

static BOOL i_Symbol_isenumtor(struct Symbol_PRIVATE *self,SEL _cmd)
{
return(BOOL)0;
}

static BOOL i_Symbol_istypedef(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT62;

#line 270 "symbol.m"
return strcmp((objcT62=(id)self,(*(STR(*)(id,SEL))_imp(objcT62,selTransTbl[3]))(objcT62,selTransTbl[3])),"typedef")==0;
}

static BOOL i_Symbol_isstatic(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT63;

#line 275 "symbol.m"
return strcmp((objcT63=(id)self,(*(STR(*)(id,SEL))_imp(objcT63,selTransTbl[3]))(objcT63,selTransTbl[3])),"static")==0;
}

static BOOL i_Symbol_isextern(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT64,objcT65;
return(strcmp((objcT64=(id)self,(*(STR(*)(id,SEL))_imp(objcT64,selTransTbl[3]))(objcT64,selTransTbl[3])),"extern")==0)||(strstr((objcT65=(id)self,(*(STR(*)(id,SEL))_imp(objcT65,selTransTbl[3]))(objcT65,selTransTbl[3])),"extern")!=NULL);
}

static BOOL i_Symbol_isinline(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT66;

#line 286 "symbol.m"
char*token=(objcT66=(id)self,(*(STR(*)(id,SEL))_imp(objcT66,selTransTbl[3]))(objcT66,selTransTbl[3]));

return(strcmp(token,"inline")==0)||(strcmp(token,"__inline")==0)||(strcmp(token,"__inline__")==0);
}

static id i_Symbol_toscores(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT67;

#line 293 "symbol.m"
int c;
char*s=(objcT67=(id)self,(*(STR(*)(id,SEL))_imp(objcT67,selTransTbl[3]))(objcT67,selTransTbl[3]));

while((c=( *s))){
if(c==':') *
s='_';
s++;
}
return(id)self;
}

static id i_Symbol_st80(struct Symbol_PRIVATE *self,SEL _cmd)
{
id objcT68;

#line 306 "symbol.m"
gs((objcT68=(id)self,(*(STR(*)(id,SEL))_imp(objcT68,selTransTbl[3]))(objcT68,selTransTbl[3])));
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  String;
extern struct _SHARED _String;
extern struct _SHARED __String;
static struct _SLT _Symbol_clsDispatchTbl[] ={
{"commonsymbols",(id (*)())c_Symbol_commonsymbols},
{"str:lineno:filename:",(id (*)())c_Symbol_str_lineno_filename_},
{(char*)0,(id (*)())0}
};
static struct _SLT _Symbol_nstDispatchTbl[] ={
{"type",(id (*)())i_Symbol_type},
{"filename",(id (*)())i_Symbol_filename},
{"lineno",(id (*)())i_Symbol_lineno},
{"type:",(id (*)())i_Symbol_type_},
{"filename:",(id (*)())i_Symbol_filename_},
{"lineno:",(id (*)())i_Symbol_lineno_},
{"lineno:filename:",(id (*)())i_Symbol_lineno_filename_},
{"synth",(id (*)())i_Symbol_synth},
{"gen",(id (*)())i_Symbol_gen},
{"canforward",(id (*)())i_Symbol_canforward},
{"dot:",(id (*)())i_Symbol_dot_},
{"star",(id (*)())i_Symbol_star},
{"funcall",(id (*)())i_Symbol_funcall},
{"isselptr",(id (*)())i_Symbol_isselptr},
{"isid",(id (*)())i_Symbol_isid},
{"isvoid",(id (*)())i_Symbol_isvoid},
{"isstorageclass",(id (*)())i_Symbol_isstorageclass},
{"isenumtor",(id (*)())i_Symbol_isenumtor},
{"istypedef",(id (*)())i_Symbol_istypedef},
{"isstatic",(id (*)())i_Symbol_isstatic},
{"isextern",(id (*)())i_Symbol_isextern},
{"isinline",(id (*)())i_Symbol_isinline},
{"toscores",(id (*)())i_Symbol_toscores},
{"st80",(id (*)())i_Symbol_st80},
{(char*)0,(id (*)())0}
};
id Symbol = (id)&_Symbol;
id  *OBJCCLASS_Symbol(void) { return &Symbol; }
struct _SHARED  _Symbol = {
  (id)&__Symbol,
  (id)&_String,
  "Symbol",
  0,
  sizeof(struct Symbol_PRIVATE),
  24,
  _Symbol_nstDispatchTbl,
  41,
  &symbol_modDesc,
  0,
  (id)0,
  &Symbol,
};
id  OBJCCFUNC_Symbol(void) { return (id)&_Symbol; }
id  OBJCCSUPER_Symbol(void) { return _Symbol.clsSuper; }
struct _SHARED __Symbol = {
  (id)&__Object,
  (id)&__String,
  "Symbol",
  0,
  sizeof(struct _SHARED),
  2,
  _Symbol_clsDispatchTbl,
  34,
  &symbol_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_Symbol(void) { return (id)&__Symbol; }
id  OBJCMSUPER_Symbol(void) { return __Symbol.clsSuper; }
static char *_selTransTbl[] ={
"istypeword:",
"isbuiltinfun:",
"str:",
"str",
"defbuiltinfun:",
"defdata:astype:",
"defbuiltintype:",
"lineno:filename:",
"isvoid",
"lookuptype:",
"canforward",
"dot:",
"star",
"funcall",
"isid",
"isselptr",
0
};
struct modDescriptor symbol_modDesc = {
  "symbol",
  "objc2.3.1",
  0L,
  0,
  0,
  &Symbol,
  16,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_symbol(void)
{
  selTransTbl = _selTransTbl;
  return &symbol_modDesc;
}
int _OBJCPOSTLINK_symbol = 1;


