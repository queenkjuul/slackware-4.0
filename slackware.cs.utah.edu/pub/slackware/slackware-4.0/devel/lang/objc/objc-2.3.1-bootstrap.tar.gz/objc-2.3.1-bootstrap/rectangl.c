#line 1 "rectangl.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_rectangl(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor rectangl_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 32 "rectangl.h"
struct Rectangle_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 34 "rectangl.h"
id origin;
id corner;};

#line 32 "rectangl.h"
extern id  Rectangle;

#line 32 "rectangl.h"
extern struct _SHARED _Rectangle;
extern struct _SHARED __Rectangle;


#line 32 "point.h"
extern id  Point;

#line 36 "rectangl.m"
static id c_Rectangle_new(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT0,objcT1,objcT2;

#line 38 "rectangl.m"
return(objcT0=(id)self,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0],(objcT1=Point,(*_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1])),(objcT2=Point,(*_imp(objcT2,selTransTbl[1]))(objcT2,selTransTbl[1]))));
}

static id c_Rectangle_origin_corner_(struct Rectangle_PRIVATE *self,SEL _cmd,id p,id q)
{
id objcT3,objcT4;

#line 43 "rectangl.m"
return(objcT3=(objcT4=__Rectangle.clsSuper,(*_impSuper(objcT4,selTransTbl[1]))((id)self,selTransTbl[1])),(*_imp(objcT3,selTransTbl[0]))(objcT3,selTransTbl[0],p,q));
}

static id c_Rectangle_origin_extent_(struct Rectangle_PRIVATE *self,SEL _cmd,id p,id q)
{
id objcT5,objcT6;

#line 48 "rectangl.m"
return(objcT5=(objcT6=__Rectangle.clsSuper,(*_impSuper(objcT6,selTransTbl[1]))((id)self,selTransTbl[1])),(*_imp(objcT5,selTransTbl[2]))(objcT5,selTransTbl[2],p,q));
}

static id c_Rectangle_origin__corner__(struct Rectangle_PRIVATE *self,SEL _cmd,int x1,int y1,int x2,int y2)
{
id objcT7,objcT8,objcT9;

#line 53 "rectangl.m"
return(objcT7=(objcT8=(objcT9=__Rectangle.clsSuper,(*_impSuper(objcT9,selTransTbl[1]))((id)self,selTransTbl[1])),(*(id(*)(id,SEL,int,int))_imp(objcT8,selTransTbl[3]))(objcT8,selTransTbl[3],x1,y1)),(*(id(*)(id,SEL,int,int))_imp(objcT7,selTransTbl[4]))(objcT7,selTransTbl[4],x2,y2));
}

static id c_Rectangle_origin__extent__(struct Rectangle_PRIVATE *self,SEL _cmd,int x,int y,int w,int h)
{
id objcT10,objcT11,objcT12;

#line 58 "rectangl.m"
return(objcT10=(objcT11=(objcT12=__Rectangle.clsSuper,(*_impSuper(objcT12,selTransTbl[1]))((id)self,selTransTbl[1])),(*(id(*)(id,SEL,int,int))_imp(objcT11,selTransTbl[3]))(objcT11,selTransTbl[3],x,y)),(*(id(*)(id,SEL,int,int))_imp(objcT10,selTransTbl[5]))(objcT10,selTransTbl[5],w,h));
}

static id i_Rectangle_copy(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT13,objcT14,objcT15,objcT16;

#line 63 "rectangl.m"
return(objcT13=(objcT14=_Rectangle.clsSuper,(*_impSuper(objcT14,selTransTbl[6]))((id)self,selTransTbl[6])),(*_imp(objcT13,selTransTbl[0]))(objcT13,selTransTbl[0],(objcT15=self->origin,(*_imp(objcT15,selTransTbl[6]))(objcT15,selTransTbl[6])),(objcT16=self->corner,(*_imp(objcT16,selTransTbl[6]))(objcT16,selTransTbl[6]))));
}

static id i_Rectangle_deepCopy(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT17,objcT18,objcT19,objcT20;

#line 68 "rectangl.m"
return(objcT17=(objcT18=_Rectangle.clsSuper,(*_impSuper(objcT18,selTransTbl[6]))((id)self,selTransTbl[6])),(*_imp(objcT17,selTransTbl[0]))(objcT17,selTransTbl[0],(objcT19=self->origin,(*_imp(objcT19,selTransTbl[7]))(objcT19,selTransTbl[7])),(objcT20=self->corner,(*_imp(objcT20,selTransTbl[7]))(objcT20,selTransTbl[7]))));
}

static id i_Rectangle_free(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT21,objcT22,objcT23;
self->
#line 73 "rectangl.m"
corner=(objcT21=self->corner,(*_imp(objcT21,selTransTbl[8]))(objcT21,selTransTbl[8]));self->origin=(objcT22=self->origin,(*_imp(objcT22,selTransTbl[8]))(objcT22,selTransTbl[8]));return(objcT23=_Rectangle.clsSuper,(*_impSuper(objcT23,selTransTbl[8]))((id)self,selTransTbl[8]));
}

#line 83 "rectangl.m"
static id i_Rectangle_origin_(struct Rectangle_PRIVATE *self,SEL _cmd,id p)
{self->
origin=p;
return(id)self;
}

static id i_Rectangle_corner_(struct Rectangle_PRIVATE *self,SEL _cmd,id q)
{self->
corner=q;
return(id)self;
}

static id i_Rectangle_origin_corner_(struct Rectangle_PRIVATE *self,SEL _cmd,id p,id q)
{
id objcT24,objcT25;

#line 97 "rectangl.m"
(objcT24=(id)self,(*_imp(objcT24,selTransTbl[9]))(objcT24,selTransTbl[9],p));
(objcT25=(id)self,(*_imp(objcT25,selTransTbl[10]))(objcT25,selTransTbl[10],q));
return(id)self;
}

static id i_Rectangle_extent__(struct Rectangle_PRIVATE *self,SEL _cmd,int w,int h)
{
id objcT26,objcT27,objcT28,objcT29;

#line 104 "rectangl.m"
(objcT26=(id)self,(*_imp(objcT26,selTransTbl[10]))(objcT26,selTransTbl[10],(objcT27=Point,(*(id(*)(id,SEL,int,int))_imp(objcT27,selTransTbl[11]))(objcT27,selTransTbl[11],(objcT28=self->origin,(*(int(*)(id,SEL))_imp(objcT28,selTransTbl[12]))(objcT28,selTransTbl[12]))+w,(objcT29=self->origin,(*(int(*)(id,SEL))_imp(objcT29,selTransTbl[13]))(objcT29,selTransTbl[13]))+h))));
return(id)self;
}

static id i_Rectangle_extent_(struct Rectangle_PRIVATE *self,SEL _cmd,id q)
{
id objcT30,objcT31,objcT32;

#line 110 "rectangl.m"
(objcT30=(id)self,(*(id(*)(id,SEL,int,int))_imp(objcT30,selTransTbl[5]))(objcT30,selTransTbl[5],(objcT31=q,(*(int(*)(id,SEL))_imp(objcT31,selTransTbl[12]))(objcT31,selTransTbl[12])),(objcT32=q,(*(int(*)(id,SEL))_imp(objcT32,selTransTbl[13]))(objcT32,selTransTbl[13]))));
return(id)self;
}

static id i_Rectangle_origin__(struct Rectangle_PRIVATE *self,SEL _cmd,int x1,int y1)
{
id objcT33,objcT34;

#line 116 "rectangl.m"
return(objcT33=(id)self,(*_imp(objcT33,selTransTbl[9]))(objcT33,selTransTbl[9],(objcT34=Point,(*(id(*)(id,SEL,int,int))_imp(objcT34,selTransTbl[11]))(objcT34,selTransTbl[11],x1,y1))));
}

static id i_Rectangle_corner__(struct Rectangle_PRIVATE *self,SEL _cmd,int x1,int y1)
{
id objcT35,objcT36;

#line 121 "rectangl.m"
return(objcT35=(id)self,(*_imp(objcT35,selTransTbl[10]))(objcT35,selTransTbl[10],(objcT36=Point,(*(id(*)(id,SEL,int,int))_imp(objcT36,selTransTbl[11]))(objcT36,selTransTbl[11],x1,y1))));
}

#line 131 "rectangl.m"
static BOOL i_Rectangle_contains_(struct Rectangle_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT37,objcT38,objcT39,objcT40,objcT41;
id objcT42;

#line 133 "rectangl.m"
int xLoc=(objcT37=aPoint,(*(int(*)(id,SEL))_imp(objcT37,selTransTbl[12]))(objcT37,selTransTbl[12]));
int yLoc=(objcT38=aPoint,(*(int(*)(id,SEL))_imp(objcT38,selTransTbl[13]))(objcT38,selTransTbl[13]));
return((objcT39=self->origin,(*(int(*)(id,SEL))_imp(objcT39,selTransTbl[12]))(objcT39,selTransTbl[12]))<=xLoc&&xLoc<=(objcT40=self->corner,(*(int(*)(id,SEL))_imp(objcT40,selTransTbl[12]))(objcT40,selTransTbl[12])))&&(
(objcT41=self->origin,(*(int(*)(id,SEL))_imp(objcT41,selTransTbl[13]))(objcT41,selTransTbl[13]))<=yLoc&&yLoc<=(objcT42=self->corner,(*(int(*)(id,SEL))_imp(objcT42,selTransTbl[13]))(objcT42,selTransTbl[13])));
}

static unsigned i_Rectangle_hash(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT43,objcT44;

#line 141 "rectangl.m"
return(objcT43=self->origin,(*(unsigned(*)(id,SEL))_imp(objcT43,selTransTbl[14]))(objcT43,selTransTbl[14]))^(objcT44=self->corner,(*(unsigned(*)(id,SEL))_imp(objcT44,selTransTbl[14]))(objcT44,selTransTbl[14]));
}

static BOOL i_Rectangle_isEqual_(struct Rectangle_PRIVATE *self,SEL _cmd,id aRectangle)
{
id objcT45,objcT46,objcT47,objcT48,objcT49;
return(objcT45=aRectangle,(*(BOOL(*)(id,SEL,id))_imp(objcT45,selTransTbl[15]))(objcT45,selTransTbl[15],(id)self->isa))&&
(objcT46=self->origin,(*(BOOL(*)(id,SEL,id))_imp(objcT46,selTransTbl[16]))(objcT46,selTransTbl[16],(objcT47=aRectangle,(*_imp(objcT47,selTransTbl[17]))(objcT47,selTransTbl[17]))))&&
(objcT48=self->corner,(*(BOOL(*)(id,SEL,id))_imp(objcT48,selTransTbl[16]))(objcT48,selTransTbl[16],(objcT49=aRectangle,(*_imp(objcT49,selTransTbl[18]))(objcT49,selTransTbl[18]))));
}

#line 159 "rectangl.m"
static int i_Rectangle_left(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT50;

#line 161 "rectangl.m"
return(objcT50=self->origin,(*(int(*)(id,SEL))_imp(objcT50,selTransTbl[12]))(objcT50,selTransTbl[12]));
}

static int i_Rectangle_right(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT51;

#line 166 "rectangl.m"
return(objcT51=self->corner,(*(int(*)(id,SEL))_imp(objcT51,selTransTbl[12]))(objcT51,selTransTbl[12]));
}

static int i_Rectangle_top(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT52;

#line 171 "rectangl.m"
return(objcT52=self->origin,(*(int(*)(id,SEL))_imp(objcT52,selTransTbl[13]))(objcT52,selTransTbl[13]));
}

static int i_Rectangle_bottom(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT53;

#line 176 "rectangl.m"
return(objcT53=self->corner,(*(int(*)(id,SEL))_imp(objcT53,selTransTbl[13]))(objcT53,selTransTbl[13]));
}

static int i_Rectangle_width(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT54,objcT55;

#line 181 "rectangl.m"
return(objcT54=self->corner,(*(int(*)(id,SEL))_imp(objcT54,selTransTbl[12]))(objcT54,selTransTbl[12]))-(objcT55=self->origin,(*(int(*)(id,SEL))_imp(objcT55,selTransTbl[12]))(objcT55,selTransTbl[12]));
}

static int i_Rectangle_height(struct Rectangle_PRIVATE *self,SEL _cmd)
{
id objcT56,objcT57;

#line 186 "rectangl.m"
return(objcT56=self->corner,(*(int(*)(id,SEL))_imp(objcT56,selTransTbl[13]))(objcT56,selTransTbl[13]))-(objcT57=self->origin,(*(int(*)(id,SEL))_imp(objcT57,selTransTbl[13]))(objcT57,selTransTbl[13]));
}

static id i_Rectangle_origin(struct Rectangle_PRIVATE *self,SEL _cmd)
{
return self->origin;
}

static id i_Rectangle_corner(struct Rectangle_PRIVATE *self,SEL _cmd)
{
return self->corner;
}

#line 206 "rectangl.m"
static id i_Rectangle_moveBy_(struct Rectangle_PRIVATE *self,SEL _cmd,id aPoint)
{
id objcT58,objcT59;

#line 208 "rectangl.m"
(objcT58=self->origin,(*_imp(objcT58,selTransTbl[19]))(objcT58,selTransTbl[19],aPoint));
(objcT59=self->corner,(*_imp(objcT59,selTransTbl[19]))(objcT59,selTransTbl[19],aPoint));
return(id)self;
}

#line 219 "rectangl.m"
static id i_Rectangle_printOn_(struct Rectangle_PRIVATE *self,SEL _cmd,IOD aFile)
{
id objcT60,objcT61;

#line 221 "rectangl.m"
fprintf(aFile,"(");
(objcT60=self->origin,(*(id(*)(id,SEL,IOD))_imp(objcT60,selTransTbl[20]))(objcT60,selTransTbl[20],aFile));
fprintf(aFile,",");
(objcT61=self->corner,(*(id(*)(id,SEL,IOD))_imp(objcT61,selTransTbl[20]))(objcT61,selTransTbl[20],aFile));
fprintf(aFile,")");
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
static struct _SLT _Rectangle_clsDispatchTbl[] ={
{"new",(id (*)())c_Rectangle_new},
{"origin:corner:",(id (*)())c_Rectangle_origin_corner_},
{"origin:extent:",(id (*)())c_Rectangle_origin_extent_},
{"origin::corner::",(id (*)())c_Rectangle_origin__corner__},
{"origin::extent::",(id (*)())c_Rectangle_origin__extent__},
{(char*)0,(id (*)())0}
};
static struct _SLT _Rectangle_nstDispatchTbl[] ={
{"copy",(id (*)())i_Rectangle_copy},
{"deepCopy",(id (*)())i_Rectangle_deepCopy},
{"free",(id (*)())i_Rectangle_free},
{"origin:",(id (*)())i_Rectangle_origin_},
{"corner:",(id (*)())i_Rectangle_corner_},
{"origin:corner:",(id (*)())i_Rectangle_origin_corner_},
{"extent::",(id (*)())i_Rectangle_extent__},
{"extent:",(id (*)())i_Rectangle_extent_},
{"origin::",(id (*)())i_Rectangle_origin__},
{"corner::",(id (*)())i_Rectangle_corner__},
{"contains:",(id (*)())i_Rectangle_contains_},
{"hash",(id (*)())i_Rectangle_hash},
{"isEqual:",(id (*)())i_Rectangle_isEqual_},
{"left",(id (*)())i_Rectangle_left},
{"right",(id (*)())i_Rectangle_right},
{"top",(id (*)())i_Rectangle_top},
{"bottom",(id (*)())i_Rectangle_bottom},
{"width",(id (*)())i_Rectangle_width},
{"height",(id (*)())i_Rectangle_height},
{"origin",(id (*)())i_Rectangle_origin},
{"corner",(id (*)())i_Rectangle_corner},
{"moveBy:",(id (*)())i_Rectangle_moveBy_},
{"printOn:",(id (*)())i_Rectangle_printOn_},
{(char*)0,(id (*)())0}
};
id Rectangle = (id)&_Rectangle;
id  *OBJCCLASS_Rectangle(void) { return &Rectangle; }
struct _SHARED  _Rectangle = {
  (id)&__Rectangle,
  (id)&_Object,
  "Rectangle",
  0,
  sizeof(struct Rectangle_PRIVATE),
  23,
  _Rectangle_nstDispatchTbl,
  41,
  &rectangl_modDesc,
  0,
  (id)0,
  &Rectangle,
};
id  OBJCCFUNC_Rectangle(void) { return (id)&_Rectangle; }
id  OBJCCSUPER_Rectangle(void) { return _Rectangle.clsSuper; }
struct _SHARED __Rectangle = {
  (id)&__Object,
  (id)&__Object,
  "Rectangle",
  0,
  sizeof(struct _SHARED),
  5,
  _Rectangle_clsDispatchTbl,
  34,
  &rectangl_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_Rectangle(void) { return (id)&__Rectangle; }
id  OBJCMSUPER_Rectangle(void) { return __Rectangle.clsSuper; }
static char *_selTransTbl[] ={
"origin:corner:",
"new",
"origin:extent:",
"origin::",
"corner::",
"extent::",
"copy",
"deepCopy",
"free",
"origin:",
"corner:",
"x:y:",
"x",
"y",
"hash",
"isKindOf:",
"isEqual:",
"origin",
"corner",
"moveBy:",
"printOn:",
0
};
struct modDescriptor rectangl_modDesc = {
  "rectangl",
  "objc2.3.1",
  0L,
  0,
  0,
  &Rectangle,
  21,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_rectangl(void)
{
  selTransTbl = _selTransTbl;
  return &rectangl_modDesc;
}
int _OBJCPOSTLINK_rectangl = 1;


