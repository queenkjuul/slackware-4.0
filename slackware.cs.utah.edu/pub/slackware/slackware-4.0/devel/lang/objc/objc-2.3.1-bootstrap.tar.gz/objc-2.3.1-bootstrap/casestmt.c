#line 1 "casestmt.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_casestmt(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor casestmt_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "casestmt.h"
struct CaseStmt_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 24 "casestmt.h"
id keyw,expr,stmt;};

#line 22 "casestmt.h"
extern id  CaseStmt;

#line 22 "casestmt.h"
extern struct _SHARED _CaseStmt;
extern struct _SHARED __CaseStmt;


#line 32 "casestmt.m"
static id i_CaseStmt_keyw_(struct CaseStmt_PRIVATE *self,SEL _cmd,id aLabel)
{self->
keyw=aLabel;
return(id)self;
}

static id i_CaseStmt_expr_(struct CaseStmt_PRIVATE *self,SEL _cmd,id aLabel)
{self->
expr=aLabel;
return(id)self;
}

static id i_CaseStmt_stmt_(struct CaseStmt_PRIVATE *self,SEL _cmd,id aStmt)
{self->
stmt=aStmt;
return(id)self;
}

static id i_CaseStmt_synth(struct CaseStmt_PRIVATE *self,SEL _cmd)
{
id objcT0,objcT1;

#line 52 "casestmt.m"
(objcT0=self->expr,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
(objcT1=self->stmt,(*_imp(objcT1,selTransTbl[0]))(objcT1,selTransTbl[0]));
return(id)self;
}

static id i_CaseStmt_gen(struct CaseStmt_PRIVATE *self,SEL _cmd)
{
id objcT2,objcT3,objcT4;

#line 59 "casestmt.m"
(objcT2=self->keyw,(*_imp(objcT2,selTransTbl[1]))(objcT2,selTransTbl[1]));
(objcT3=self->expr,(*_imp(objcT3,selTransTbl[1]))(objcT3,selTransTbl[1]));
gc(':');
(objcT4=self->stmt,(*_imp(objcT4,selTransTbl[1]))(objcT4,selTransTbl[1]));
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Stmt;
extern struct _SHARED _Stmt;
extern struct _SHARED __Stmt;
static struct _SLT _CaseStmt_clsDispatchTbl[] ={
{(char*)0,(id (*)())0}
};
static struct _SLT _CaseStmt_nstDispatchTbl[] ={
{"keyw:",(id (*)())i_CaseStmt_keyw_},
{"expr:",(id (*)())i_CaseStmt_expr_},
{"stmt:",(id (*)())i_CaseStmt_stmt_},
{"synth",(id (*)())i_CaseStmt_synth},
{"gen",(id (*)())i_CaseStmt_gen},
{(char*)0,(id (*)())0}
};
id CaseStmt = (id)&_CaseStmt;
id  *OBJCCLASS_CaseStmt(void) { return &CaseStmt; }
struct _SHARED  _CaseStmt = {
  (id)&__CaseStmt,
  (id)&_Stmt,
  "CaseStmt",
  0,
  sizeof(struct CaseStmt_PRIVATE),
  5,
  _CaseStmt_nstDispatchTbl,
  41,
  &casestmt_modDesc,
  0,
  (id)0,
  &CaseStmt,
};
id  OBJCCFUNC_CaseStmt(void) { return (id)&_CaseStmt; }
id  OBJCCSUPER_CaseStmt(void) { return _CaseStmt.clsSuper; }
struct _SHARED __CaseStmt = {
  (id)&__Object,
  (id)&__Stmt,
  "CaseStmt",
  0,
  sizeof(struct _SHARED),
  0,
  _CaseStmt_clsDispatchTbl,
  34,
  &casestmt_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_CaseStmt(void) { return (id)&__CaseStmt; }
id  OBJCMSUPER_CaseStmt(void) { return __CaseStmt.clsSuper; }
static char *_selTransTbl[] ={
"synth",
"gen",
0
};
struct modDescriptor casestmt_modDesc = {
  "casestmt",
  "objc2.3.1",
  0L,
  0,
  0,
  &CaseStmt,
  2,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_casestmt(void)
{
  selTransTbl = _selTransTbl;
  return &casestmt_modDesc;
}
int _OBJCPOSTLINK_casestmt = 1;


