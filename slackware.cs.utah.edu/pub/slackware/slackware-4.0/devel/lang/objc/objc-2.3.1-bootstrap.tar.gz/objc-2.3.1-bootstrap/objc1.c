#line 1 "objc1.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_objc1(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor objc1_modDesc;

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 31 "../../include/objpak/ordcltn.h"
typedef struct objcol{
int count;
int capacity;
id*ptr;
}*objcol_t;
#line 22 "../oclib/node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "../oclib/trlunit.h"
extern id trlunit;
#line 22 "../oclib/options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 23 "../oclib/util.h"
extern FILE*yyin;
extern int yyparse();

FILE*openfile(STR name,STR modfs);
FILE*reopenfile(STR name,STR modfs,FILE*of);

extern int okblock;

id mkcppdirect(char*s);
id mkexprstmt(id expr);
id mklabeledstmt(id label,id stmt);
id mkcasestmt(id keyw,id expr,id stmt);
id mkdefaultstmt(id keyw,id stmt);
id mkifstmt(id keyw,id expr,id stmt);
id mkifelsestmt(id keyw,id expr,id stmt,id ekeyw,id estmt);
id mkswitchstmt(id keyw,id expr,id stmt);
id mkwhilestmt(id keyw,id expr,id stmt);
id mkdostmt(id keyw,id stmt,id wkeyw,id expr);
id mkforstmt(id keyw,id a,id b,id c,id stmt);
id mkgotostmt(id keyw,id label);
id mkcontinuestmt(id keyw);
id mkbreakstmt(id keyw);
id mkreturnstmt(id keyw,id expr);
id mkcastexpr(id a,id b);
id mkcondexpr(id a,id b,id c);
id mkunaryexpr(STR op,id a);
id mksizeof(id a);
id mkaddressof(id a);
id mkdereference(id a);
id mkbinexpr(id a,STR op,id b);
id mkcommaexpr(id a,id b);
id mkrelexpr(id a,STR op,id b);
id mkassignexpr(id a,STR op,id b);
id mkfuncall(id funname,id args);
id mkbuiltincall(id funname,id args);
id mkfunbody(id datadefs,id compound);
void declarefun(id specs,id decl);
void declaremeth(BOOL factory,id decl);
id mkfundef(id specs,id decl,id body);
id mkmethdef(BOOL factory,id decl,id body);
id mkmesgexpr(id receiver,id args);
id mkdecl(id ident);
id mkprecdecl(id tquals,id decl);
id mkarraydecl(id lhs,id ix);
id mkfundecl(id lhs,id args);
id mkprefixdecl(id lhs,id rhs);
id mkpostfixdecl(id lhs,id rhs);
id mkpointer(id specs,id pointer);
id mkbitfielddecl(id decl,id expr);
id mkstardecl(id pointer,id decl);
id mkasmop(id string,id expr);
id mkasmstmt(id keyw,id tqual,id expr,id asmop1,id asmop2,id clobbers);
id mkcompstmt(id lb,id datadefs,id stmtlist,id rb);
id mklist(id c,id s);
id mklist2(id c,id s,id t);
id atdefsaddall(id c,id n);
id mkblockexpr(id lb,id parms,id datadefs,id stmts,id expr,id rb);
id mkclassdef(id keyw,id name,id sname,id ivars,id cvars);
id mkdatadef(id datadef,id specs,id decl,id initializer);
id mkencodeexpr(id name);
id mkenumspec(id keyw,id name,id lb,id list,id rb);
id mkenumerator(id name,id value);
id mkgnuattrib(id anyword,id exprlist);
id mkgnuattribdecl(id keyw,id list);
id mklistexpr(id lb,id x,id rb);
id mktypename(id specs,id decl);
id mkcomponentdef(id cdef,id specs,id decl);
id mkstructspec(id keyw,id name,id lb,id defs,id rb);
id mkkeywarg(id sel,id arg);
id mkkeywdecl(id sel,id cast,id arg);
id mkmethproto(id cast,id usel,id ksel,BOOL varargs);
id mkidentexpr(id name);
id mkconstexpr(id name,id schain);
id mkprecexpr(id expr);
id mkarrowexpr(id array,id ix);
id mkdotexpr(id array,id ix);
id mkindexexpr(id array,id ix);
id mkpostfixexpr(id expr,id pf);
id mkparmdef(id parmdef,id specs,id decl);
id mkparmdeflist(id idents,id parmdefs,BOOL varargs);
id mkselarg(id selarg,id usel,int ncols);
id mkselectorexpr(id expr);

void procextdef(id def);
void finclassdef(void);
void datadefokblock(id datadef,id specs,id decl);

id mkfileinmeth(id classdef,id ivarnames,id ivartypes);
id mkfileoutmeth(id classdef,id ivarnames,id ivartypes);

id mkincrefsmeth(id classdef,id ivarnames,id ivartypes);
id mkdecrefsmeth(id classdef,id ivarnames,id ivartypes);
#line 22 "../oclib/symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);

#line 36 "objc1.m"
void printversion(void)
{
printf("%s\n","2.3.1");
exit(0);
}

void printcopyright(void)
{
printf("Portable Object Compiler %s (c) 1997, 98, 99.\n","2.3.1");
printf("Distributed under the terms of the GNU LGPL.\n");
}

void unknownoption(char*arg)
{
STR msg="%s: unknown option %s\n";
STR name=(o_cplus)?"objcpls1":"objc1";
fprintf(stderr,msg,name,arg);
exit(1);
}

void badarg(id option,id arg)
{
id objcT0,objcT1;

#line 58 "objc1.m"
STR msg="%s: illegal argument %s for %s\n";
STR name=(o_cplus)?"objcpls1":"objc1";
fprintf(stderr,msg,name,(objcT0=arg,(*(STR(*)(id,SEL))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0])),(objcT1=option,(*(STR(*)(id,SEL))_imp(objcT1,selTransTbl[0]))(objcT1,selTransTbl[0])));
exit(1);
}

BOOL isoption(char*s)
{
return s!=NULL&&s[0]=='-';
}

#line 38 "../../include/objpak/ocstring.h"
extern id  String;

#line 69 "objc1.m"
id optionstok(id aCltn,char*s)
{
id objcT2,objcT3;

#line 71 "objc1.m"
char*p;
char*delims=" \t\n\r";
id buffer=(objcT2=String,(*(id(*)(id,SEL,STR))_imp(objcT2,selTransTbl[1]))(objcT2,selTransTbl[1],s));

p=strtok((objcT3=buffer,(*(STR(*)(id,SEL))_imp(objcT3,selTransTbl[0]))(objcT3,selTransTbl[0])),delims);

while(p!=NULL){
id objcT4,objcT5;

#line 78 "objc1.m"
(objcT4=aCltn,(*_imp(objcT4,selTransTbl[2]))(objcT4,selTransTbl[2],(objcT5=String,(*(id(*)(id,SEL,STR))_imp(objcT5,selTransTbl[1]))(objcT5,selTransTbl[1],p))));
p=strtok(NULL,delims);
}

return aCltn;
}

id optsfromfile(id aCltn,FILE*f)
{
char buf[BUFSIZ+1];

while( !feof(f)){
if(fgets(buf,BUFSIZ,f)){

optionstok(aCltn,buf);
}
}

return aCltn;
}



id optsnamed(id aCltn,STR s)
{
STR t;
FILE*f;


if((t=getenv(s)))
return optionstok(aCltn,t);


if((f=fopen(s,"r"))){
aCltn=optsfromfile(aCltn,f);
fclose(f);
return aCltn;
}

return(id)0;
}

#line 37 "../../include/objpak/ordcltn.h"
extern id  OrdCltn;

#line 120 "objc1.m"
id cmdlineopts(int argc,char*argv[])
{
id objcT6;

#line 122 "objc1.m"
int i;
id aCltn=(objcT6=OrdCltn,(*_imp(objcT6,selTransTbl[3]))(objcT6,selTransTbl[3]));

for(i=1;i<argc;i++){
id objcT7,objcT8;

#line 126 "objc1.m"
(objcT7=aCltn,(*_imp(objcT7,selTransTbl[2]))(objcT7,selTransTbl[2],(objcT8=String,(*(id(*)(id,SEL,STR))_imp(objcT8,selTransTbl[1]))(objcT8,selTransTbl[1],argv[i]))));
}

return aCltn;
}

#line 137 "objc1.m"
int setfilename(id option,id args)
{
id objcT9,objcT10;

#line 139 "objc1.m"
id arg=(objcT9=args,(*_imp(objcT9,selTransTbl[4]))(objcT9,selTransTbl[4]));
char*t=(objcT10=arg,(*(STR(*)(id,SEL))_imp(objcT10,selTransTbl[0]))(objcT10,selTransTbl[0]));

if(isoption(t))badarg(option,arg);
o_srcfilename=t;

return 0;
}

int setinitcall(id option,id args)
{
id objcT11,objcT12;

#line 150 "objc1.m"
id arg=(objcT11=args,(*_imp(objcT11,selTransTbl[4]))(objcT11,selTransTbl[4]));
char*t=(objcT12=arg,(*(STR(*)(id,SEL))_imp(objcT12,selTransTbl[0]))(objcT12,selTransTbl[0]));

if(isoption(t))badarg(option,arg);
o_initcall=t;

return 0;
}

int setmainfun(id option,id args)
{
id objcT13,objcT14,objcT15;

#line 161 "objc1.m"
id arg=(objcT13=args,(*_imp(objcT13,selTransTbl[4]))(objcT13,selTransTbl[4]));
if(isoption((objcT14=arg,(*(STR(*)(id,SEL))_imp(objcT14,selTransTbl[0]))(objcT14,selTransTbl[0]))))badarg(option,arg);
o_mainfun=(objcT15=arg,(*(STR(*)(id,SEL))_imp(objcT15,selTransTbl[0]))(objcT15,selTransTbl[0]));
return 0;
}

int setbind(id option,id args)
{
id objcT16,objcT17,objcT18;

#line 169 "objc1.m"
id arg=(objcT16=args,(*_imp(objcT16,selTransTbl[4]))(objcT16,selTransTbl[4]));
if(isoption((objcT17=arg,(*(STR(*)(id,SEL))_imp(objcT17,selTransTbl[0]))(objcT17,selTransTbl[0]))))badarg(option,arg);
o_bind=(objcT18=arg,(*(STR(*)(id,SEL))_imp(objcT18,selTransTbl[0]))(objcT18,selTransTbl[0]));
return 0;
}

#line 179 "objc1.m"
int setlinemax(id option,id args)
{
id objcT19,objcT20,objcT21;

#line 181 "objc1.m"
id arg=(objcT19=args,(*_imp(objcT19,selTransTbl[4]))(objcT19,selTransTbl[4]));
if(isoption((objcT20=arg,(*(STR(*)(id,SEL))_imp(objcT20,selTransTbl[0]))(objcT20,selTransTbl[0]))))badarg(option,arg);
o_linemax=(objcT21=arg,(*(int(*)(id,SEL))_imp(objcT21,selTransTbl[5]))(objcT21,selTransTbl[5]));
return 0;
}
#line 192 "objc1.m"
void setoptions(id aCltn);

int setoptsfromfile(id option,id args)
{
id objcT22,objcT23,objcT24,objcT25;

#line 196 "objc1.m"
id arg=(objcT22=args,(*_imp(objcT22,selTransTbl[4]))(objcT22,selTransTbl[4]));

if(isoption((objcT23=arg,(*(STR(*)(id,SEL))_imp(objcT23,selTransTbl[0]))(objcT23,selTransTbl[0]))))badarg(option,arg);
setoptions(optsnamed((objcT24=OrdCltn,(*_imp(objcT24,selTransTbl[3]))(objcT24,selTransTbl[3])),(objcT25=arg,(*(STR(*)(id,SEL))_imp(objcT25,selTransTbl[0]))(objcT25,selTransTbl[0]))));
return 0;
}

#line 207 "objc1.m"
int addbuiltintype(id option,id args)
{
id objcT26,objcT27,objcT28;

#line 209 "objc1.m"
id arg=(objcT26=args,(*_imp(objcT26,selTransTbl[4]))(objcT26,selTransTbl[4]));
if(isoption((objcT27=arg,(*(STR(*)(id,SEL))_imp(objcT27,selTransTbl[0]))(objcT27,selTransTbl[0]))))badarg(option,arg);
definebuiltintype((objcT28=arg,(*(STR(*)(id,SEL))_imp(objcT28,selTransTbl[0]))(objcT28,selTransTbl[0])));
return 0;
}

int addbuiltinfun(id option,id args)
{
id objcT29,objcT30,objcT31;

#line 217 "objc1.m"
id arg=(objcT29=args,(*_imp(objcT29,selTransTbl[4]))(objcT29,selTransTbl[4]));
if(isoption((objcT30=arg,(*(STR(*)(id,SEL))_imp(objcT30,selTransTbl[0]))(objcT30,selTransTbl[0]))))badarg(option,arg);
definebuiltinfun((objcT31=arg,(*(STR(*)(id,SEL))_imp(objcT31,selTransTbl[0]))(objcT31,selTransTbl[0])));
return 0;
}

void setoptions(id aCltn)
{
id objcT32,objcT33;

#line 225 "objc1.m"
id args,s;
int filecount=0;
BOOL checkoption=(BOOL)1;

args=(objcT32=aCltn,(*_imp(objcT32,selTransTbl[6]))(objcT32,selTransTbl[6]));

while((s=(objcT33=args,(*_imp(objcT33,selTransTbl[4]))(objcT33,selTransTbl[4])))){
id objcT34;

#line 232 "objc1.m"
char*t=(objcT34=s,(*(STR(*)(id,SEL))_imp(objcT34,selTransTbl[0]))(objcT34,selTransTbl[0]));
if( !strcmp(t,"-quiet")){ ++
o_quiet;
}else if( !strcmp(t,"-z")){ ++
o_outputcode;
}else if( !strcmp(t,"@")){
setoptsfromfile(s,args);
}else if( !strcmp(t,"-u")){
o_buffered=0;
}else if( !strcmp(t,"-version")){
o_version++;
}else if( !strcmp(t,"-otb")){
o_otb++;
o_shareddata=0;
}else if( !strcmp(t,"-gnu")){
o_gnu++;
}else if( !strcmp(t,"-refcnt")){
o_refcnt++;
}else if( !strcmp(t,"-noasm")){
o_enableasm=0;
}else if( !strcmp(t,"-nolonglong")){
o_llkeyw=0;
}else if( !strcmp(t,"-msdos")){
o_msdos++;
}else if( !strcmp(t,"-watcom")){
o_watcom++;
}else if( !strcmp(t,"-comments")){
o_comments++;
}else if( !strcmp(t,"-ibmvac")){
o_ibmvac++;
}else if( !strcmp(t,"-noSelTbl")){
o_seltranslation=0;
}else if( !strcmp(t,"-noCategories")){
o_categories=0;
}else if( !strcmp(t,"-noBlocks")){
o_blocks=0;
}else if( !strcmp(t,"-st80")){
o_st80++;
o_nolinetags++;
o_outputcode=0;
}else if( !strcmp(t,"-fwd")){
o_fwd++;
}else if( !strcmp(t,"-noSelPtr")){
o_selptr=0;
}else if( !strcmp(t,"-noFwd")){
o_fwd=0;
}else if( !strcmp(t,"-noCache")){
o_cache=0;
}else if( !strcmp(t,"-noFiler")){
o_filer=0;
}else if( !strcmp(t,"-noSelfAssign")){
o_selfassign=0;
}else if( !strcmp(t,"-noNilRcvr")){
o_nilrcvr=0;
}else if( !strcmp(t,"-objc")){
o_gencode=0;
}else if( !strcmp(t,"-cplus")){
o_cplus++;
}else if( !strcmp(t,"-inlinecache")){
o_inlinecache++;
}else if( !strcmp(t,"-refBind")){
o_refbind++;
}else if( !strcmp(t,"-export")){
setbind(s,args);
}else if( !strcmp(t,"-dllexport")){
o_bind="__declspec(dllexport)";
}else if( !strcmp(t,"-traditional")){
}else if( !strcmp(t,"-filename")){
setfilename(s,args);
}else if( !strcmp(t,"-longlinetag")){
}else if( !strcmp(t,"-shortTags")){
o_tagformat="# %d \"%s\"\n";
}else if( !strcmp(t,"-init")){
setinitcall(s,args);
}else if( !strcmp(t,"-noShared")){
o_shareddata=0;
}else if( !strcmp(t,"-main")){
setmainfun(s,args);
}else if( !strcmp(t,"-linemax")){
setlinemax(s,args);
}else if( !strcmp(t,"-builtinfunction")){
addbuiltinfun(s,args);
}else if( !strcmp(t,"-builtintype")){
addbuiltintype(s,args);
}else if( !strcmp(t,"-nolinetags")){
o_nolinetags++;
}else if( !strcmp(t,"-oneperfile")){
o_oneperfile++;
}else if( !strcmp(t,"-w")){
o_warnlex=0;
o_warnfwd=0;
o_warnsuggest=0;
o_warnintvar=0;
o_warnclasstype=0;
o_warntypeconflict=0;
o_warnlocalnst=0;
o_warnundefined=0;
o_warnnotfound=0;
o_warnmissingmethods=0;
}else if( !strcmp(t,"-wClassUsedAsType")){
o_warnclasstype=0;
}else if( !strcmp(t,"-wMissing")){
o_warnmissingmethods=0;
}else if( !strcmp(t,"-wTypeConflict")){
o_warntypeconflict=0;
}else if( !strcmp(t,"-wLocalInstance")){
o_warnlocalnst=0;
}else if( !strcmp(t,"-wUndefinedMethod")){
o_warnundefined=0;
}else if( !strcmp(t,"-wInterfaceNotFound")){
o_warnnotfound=0;
}else if( !strcmp(t,"-WLex")){
o_warnlex++;
}else if( !strcmp(t,"-WFwd")){
o_warnfwd++;
}else if( !strcmp(t,"-postlink")){
o_postlink++;
}else if( !strcmp(t,"-checkbindfunction")){
o_checkbind++;
}else if( !strcmp(t,"-debugInfo")){
o_debuginfo++;
}else if( !strcmp(t,"-ppi")){
o_ppi++;
}else if( !strcmp(t,"-")){
checkoption=0;
}else if(checkoption&&isoption(t)){
unknownoption(t);
}else if(filecount==0){
o_infile=t;
filecount++;
}else if(filecount==1){
o_outfile=t;
filecount++;
}else{
unknownoption(t);
}
}
}

#line 376 "objc1.m"
void openinfile(void)
{
if(o_infile){
yyin=openfile(o_infile,"r");
}else{

}
}

void setfirstlinetag(void)
{
id objcT39,objcT40,objcT41;

inlineno=1;
if(o_srcfilename){
id objcT35;

#line 391 "objc1.m"
infilename=(objcT35=String,(*(id(*)(id,SEL,STR))_imp(objcT35,selTransTbl[1]))(objcT35,selTransTbl[1],o_srcfilename));
}else{
if(o_infile){
id objcT36;

#line 394 "objc1.m"
infilename=(objcT36=String,(*(id(*)(id,SEL,STR))_imp(objcT36,selTransTbl[1]))(objcT36,selTransTbl[1],o_infile));
}else{
id objcT37;

#line 396 "objc1.m"
infilename=(objcT37=String,(*(id(*)(id,SEL,STR))_imp(objcT37,selTransTbl[1]))(objcT37,selTransTbl[1],"-=stdin=-"));
}
}

if( !o_nolinetags){
id objcT38;

#line 401 "objc1.m"
gl(inlineno,(objcT38=infilename,(*(STR(*)(id,SEL))_imp(objcT38,selTransTbl[0]))(objcT38,selTransTbl[0])));
}

assert(trlunit!=(id)0);
(objcT39=trlunit,(*(id(*)(id,SEL,char*))_imp(objcT39,selTransTbl[7]))(objcT39,selTransTbl[7],"objc2.3.1"));
(objcT40=trlunit,(*(id(*)(id,SEL,char*))_imp(objcT40,selTransTbl[8]))(objcT40,selTransTbl[8],(objcT41=infilename,(*(STR(*)(id,SEL))_imp(objcT41,selTransTbl[0]))(objcT41,selTransTbl[0]))));
}

void closeinfile(void)
{
if(o_infile){
fclose(yyin);
}else{

}
}

void openoutfile(void)
{
if(o_outfile){
gfile=openfile(o_outfile,"w");
}else{
gfile=stdout;
}


if( !o_buffered)setbuf(gfile,NULL);
}

void closeoutfile(void)
{
if(o_outfile)fclose(gfile);
}

#line 24 "../oclib/trlunit.h"
extern id  TranslationUnit;

#line 435 "objc1.m"
int objcmain(int argc,char*argv[])
{
id objcT42,objcT43,objcT44;

#line 437 "objc1.m"
defoptions();
setoptions(cmdlineopts(argc,argv));

if(o_version)printversion();
if( !o_quiet)printcopyright();

openinfile();
openoutfile();
trlunit=(objcT42=TranslationUnit,(*_imp(objcT42,selTransTbl[3]))(objcT42,selTransTbl[3]));

setfirstlinetag();

if(o_outputcode)(objcT43=trlunit,(*_imp(objcT43,selTransTbl[9]))(objcT43,selTransTbl[9]));
if(yyparse())exit(1);
if(o_outputcode)(objcT44=trlunit,(*_imp(objcT44,selTransTbl[10]))(objcT44,selTransTbl[10]));

closeinfile();
closeoutfile();

exit(exitstatus);
return 0;
}
extern int oc_objcInit(int debug,int traceInit);

#line 435 "objc1.m"
int main(int argc,char*argv[]){
oc_objcInit(0,0);
return objcmain(argc,argv);
}

static char *_selTransTbl[] ={
"str",
"str:",
"add:",
"new",
"next",
"asInt",
"eachElement",
"setmodversion:",
"setmodname:",
"prologue",
"epilogue",
0
};
struct modDescriptor objc1_modDesc = {
  "objc1",
  "objc2.3.1",
  0L,
  0,
  0,
  0,
  11,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_objc1(void)
{
  selTransTbl = _selTransTbl;
  return &objc1_modDesc;
}
int _OBJCPOSTLINK_objc1 = 1;
struct useDescriptor *OCU_main = 0;


