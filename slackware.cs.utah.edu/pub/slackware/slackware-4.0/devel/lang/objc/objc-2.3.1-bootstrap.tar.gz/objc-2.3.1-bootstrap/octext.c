#line 1 "octext.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_octext(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor octext_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/ctype.h"
#include <ctype.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "ocstring.h"
typedef struct objstr
{
int count;
int capacity;
char*ptr;
}*
objstr_t;
#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 29 "octext.h"
struct Text_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 31 "octext.h"
id string;
id runs;};

#line 29 "octext.h"
extern id  Text;

#line 29 "octext.h"
extern struct _SHARED _Text;
extern struct _SHARED __Text;


#line 37 "octext.m"
static id i_Text_check(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT0,objcT1,objcT2;

#line 39 "octext.m"
(objcT0=self->runs,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
assert((objcT1=self->string,(*(unsigned(*)(id,SEL))_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1]))==(objcT2=self->runs,(*(unsigned(*)(id,SEL))_imp(objcT2,selTransTbl[1]))(objcT2,selTransTbl[1])));
return(id)self;
}

#line 40 "ocstring.h"
extern id  String;

#line 44 "octext.m"
static id c_Text_new(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT3,objcT4;

#line 46 "octext.m"
return(objcT3=(id)self,(*_imp(objcT3,selTransTbl[2]))(objcT3,selTransTbl[2],(objcT4=String,(*_imp(objcT4,selTransTbl[3]))(objcT4,selTransTbl[3]))));
}

static id c_Text_new_(struct Text_PRIVATE *self,SEL _cmd,unsigned nChars)
{
id objcT5,objcT6;

#line 51 "octext.m"
return(objcT5=(id)self,(*_imp(objcT5,selTransTbl[2]))(objcT5,selTransTbl[2],(objcT6=String,(*(id(*)(id,SEL,unsigned))_imp(objcT6,selTransTbl[4]))(objcT6,selTransTbl[4],nChars))));
}

static id c_Text_vsprintf__(struct Text_PRIVATE *self,SEL _cmd,STR format,va_list*ap)
{
id objcT7;

#line 56 "octext.m"
char aBuffer[(2048)];
#line 63 "octext.m"
vsprintf(aBuffer,format, *ap);


return(objcT7=(id)self,(*(id(*)(id,SEL,STR))_imp(objcT7,selTransTbl[5]))(objcT7,selTransTbl[5],aBuffer));
}

static id c_Text_str_(struct Text_PRIVATE *self,SEL _cmd,STR aString)
{
id objcT8,objcT9;

#line 71 "octext.m"
return(objcT8=(id)self,(*_imp(objcT8,selTransTbl[2]))(objcT8,selTransTbl[2],(objcT9=String,(*(id(*)(id,SEL,STR))_imp(objcT9,selTransTbl[5]))(objcT9,selTransTbl[5],aString))));;
}

static id c_Text_sprintf_(struct Text_PRIVATE *self,SEL _cmd,STR format,...)
{
id objcT10;

#line 76 "octext.m"
id newtext;


va_list ap;
va_start(ap,format);
newtext=(objcT10=(id)self,(*(id(*)(id,SEL,STR,va_list*))_imp(objcT10,selTransTbl[6]))(objcT10,selTransTbl[6],format, &ap));
va_end(ap);
return newtext;
}

#line 28 "runarray.h"
extern id  RunArray;

#line 86 "octext.m"
static id c_Text_fromString_(struct Text_PRIVATE *self,SEL _cmd,id aString)
{
id objcT11,objcT12,objcT13;

#line 88 "octext.m"
return(objcT11=(objcT12=__Text.clsSuper,(*_impSuper(objcT12,selTransTbl[3]))((id)self,selTransTbl[3])),(*_imp(objcT11,selTransTbl[7]))(objcT11,selTransTbl[7],aString,(objcT13=RunArray,(*_imp(objcT13,selTransTbl[3]))(objcT13,selTransTbl[3]))));
}

static id c_Text_string_attribute_(struct Text_PRIVATE *self,SEL _cmd,id aString,id attrib)
{
id objcT14,objcT15;

#line 93 "octext.m"
return(objcT14=(objcT15=(id)self,(*_imp(objcT15,selTransTbl[2]))(objcT15,selTransTbl[2],aString)),(*_imp(objcT14,selTransTbl[8]))(objcT14,selTransTbl[8],attrib));
}

static id i_Text_string_runs_(struct Text_PRIVATE *self,SEL _cmd,id aString,id anArray)
{self->
string=aString;self->
runs=anArray;
return(id)self;
}

static id i_Text_copy(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT16,objcT17,objcT18;

#line 105 "octext.m"
return(objcT16=self->isa,(*_imp(objcT16,selTransTbl[7]))(objcT16,selTransTbl[7],(objcT17=self->string,(*_imp(objcT17,selTransTbl[9]))(objcT17,selTransTbl[9])),(objcT18=self->runs,(*_imp(objcT18,selTransTbl[9]))(objcT18,selTransTbl[9]))));
}

static id i_Text_free(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT19,objcT20,objcT21;
self->
#line 110 "octext.m"
string=(objcT19=self->string,(*_imp(objcT19,selTransTbl[10]))(objcT19,selTransTbl[10]));self->
runs=(objcT20=self->runs,(*_imp(objcT20,selTransTbl[10]))(objcT20,selTransTbl[10]));
return(objcT21=_Text.clsSuper,(*_impSuper(objcT21,selTransTbl[10]))((id)self,selTransTbl[10]));
}


static unsigned i_Text_hash(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT22;

#line 118 "octext.m"
return(objcT22=self->string,(*(unsigned(*)(id,SEL))_imp(objcT22,selTransTbl[11]))(objcT22,selTransTbl[11]));
}

static BOOL i_Text_isEqual_(struct Text_PRIVATE *self,SEL _cmd,id aStr)
{
id objcT23,objcT24;

#line 123 "octext.m"
(objcT23=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT23,selTransTbl[12]))(objcT23,selTransTbl[12],(objcT24=self->string,(*(unsigned(*)(id,SEL))_imp(objcT24,selTransTbl[1]))(objcT24,selTransTbl[1]))));
if((id)self==aStr){
return(BOOL)1;
}else{
id objcT25,objcT26,objcT27,objcT28;

#line 127 "octext.m"
return(objcT25=self->string,(*(BOOL(*)(id,SEL,id))_imp(objcT25,selTransTbl[13]))(objcT25,selTransTbl[13],(objcT26=aStr,(*_imp(objcT26,selTransTbl[14]))(objcT26,selTransTbl[14]))))&&(objcT27=self->runs,(*(BOOL(*)(id,SEL,id))_imp(objcT27,selTransTbl[13]))(objcT27,selTransTbl[13],(objcT28=aStr,(*_imp(objcT28,selTransTbl[15]))(objcT28,selTransTbl[15]))));
}
}


static id i_Text_string(struct Text_PRIVATE *self,SEL _cmd)
{
return self->string;
}

static id i_Text_runs(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT29,objcT30;

#line 139 "octext.m"
(objcT29=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT29,selTransTbl[12]))(objcT29,selTransTbl[12],(objcT30=self->string,(*(unsigned(*)(id,SEL))_imp(objcT30,selTransTbl[1]))(objcT30,selTransTbl[1]))));
return self->runs;
}

static STR i_Text_str(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT31;

#line 145 "octext.m"
return(objcT31=self->string,(*(STR(*)(id,SEL))_imp(objcT31,selTransTbl[16]))(objcT31,selTransTbl[16]));
}

static unsigned i_Text_size(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT32;

#line 150 "octext.m"
return(objcT32=self->string,(*(unsigned(*)(id,SEL))_imp(objcT32,selTransTbl[1]))(objcT32,selTransTbl[1]));
}

static char i_Text_charAt_(struct Text_PRIVATE *self,SEL _cmd,unsigned anOffset)
{
id objcT33;

#line 155 "octext.m"
return(objcT33=self->string,(*(char(*)(id,SEL,unsigned))_imp(objcT33,selTransTbl[17]))(objcT33,selTransTbl[17],anOffset));
}

static char i_Text_charAt_put_(struct Text_PRIVATE *self,SEL _cmd,unsigned anOffset,char aChar)
{
id objcT34;

#line 160 "octext.m"
return(objcT34=self->string,(*(char(*)(id,SEL,unsigned,char))_imp(objcT34,selTransTbl[18]))(objcT34,selTransTbl[18],anOffset,aChar));
}

static id i_Text_at_insert_(struct Text_PRIVATE *self,SEL _cmd,unsigned anOffset,id aString)
{
id objcT35,objcT36,objcT37;

#line 165 "octext.m"
return(objcT35=(id)self,(*(id(*)(id,SEL,unsigned,char*,int))_imp(objcT35,selTransTbl[19]))(objcT35,selTransTbl[19],anOffset,(objcT36=aString,(*(STR(*)(id,SEL))_imp(objcT36,selTransTbl[16]))(objcT36,selTransTbl[16])),(objcT37=aString,(*(unsigned(*)(id,SEL))_imp(objcT37,selTransTbl[1]))(objcT37,selTransTbl[1]))));
}

static id i_Text_at_insert_count_(struct Text_PRIVATE *self,SEL _cmd,unsigned anOffset,char*aString,int size)
{
id objcT38,objcT39;

#line 170 "octext.m"
(objcT38=self->string,(*(id(*)(id,SEL,unsigned,char*,int))_imp(objcT38,selTransTbl[19]))(objcT38,selTransTbl[19],anOffset,aString,size));
(objcT39=self->runs,(*(id(*)(id,SEL,unsigned,char*,int))_imp(objcT39,selTransTbl[19]))(objcT39,selTransTbl[19],anOffset,aString,size));
return(id)self;
}

static id i_Text_deleteFrom_to_(struct Text_PRIVATE *self,SEL _cmd,unsigned p,unsigned q)
{
id objcT40,objcT41;

#line 177 "octext.m"
(objcT40=self->string,(*(id(*)(id,SEL,unsigned,unsigned))_imp(objcT40,selTransTbl[20]))(objcT40,selTransTbl[20],p,q));
(objcT41=self->runs,(*(id(*)(id,SEL,unsigned,unsigned))_imp(objcT41,selTransTbl[20]))(objcT41,selTransTbl[20],p,q));
return(id)self;
}

static id i_Text_concat_(struct Text_PRIVATE *self,SEL _cmd,id b)
{
id objcT42,objcT43,objcT44,objcT45;

#line 184 "octext.m"
(objcT42=self->string,(*_imp(objcT42,selTransTbl[21]))(objcT42,selTransTbl[21],(objcT43=b,(*_imp(objcT43,selTransTbl[14]))(objcT43,selTransTbl[14]))));
(objcT44=self->runs,(*_imp(objcT44,selTransTbl[21]))(objcT44,selTransTbl[21],(objcT45=b,(*_imp(objcT45,selTransTbl[15]))(objcT45,selTransTbl[15]))));
return(id)self;
}

static id i_Text_concatSTR_(struct Text_PRIVATE *self,SEL _cmd,STR b)
{
id objcT46,objcT47,objcT48;

#line 191 "octext.m"
(objcT46=self->string,(*(id(*)(id,SEL,STR))_imp(objcT46,selTransTbl[22]))(objcT46,selTransTbl[22],b));
(objcT47=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT47,selTransTbl[12]))(objcT47,selTransTbl[12],(objcT48=self->string,(*(unsigned(*)(id,SEL))_imp(objcT48,selTransTbl[1]))(objcT48,selTransTbl[1]))));
return(id)self;
}

#line 29 "txtattr.h"
extern id  TextAttribute;

#line 197 "octext.m"
static id i_Text_allBold(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT49,objcT50;

#line 199 "octext.m"
(objcT49=(id)self,(*_imp(objcT49,selTransTbl[8]))(objcT49,selTransTbl[8],(objcT50=TextAttribute,(*_imp(objcT50,selTransTbl[23]))(objcT50,selTransTbl[23]))));
return(id)self;
}

static id i_Text_makeBoldFrom_to_(struct Text_PRIVATE *self,SEL _cmd,unsigned p,unsigned q)
{
id objcT51,objcT52;

#line 205 "octext.m"
(objcT51=(id)self,(*(id(*)(id,SEL,id,unsigned,unsigned))_imp(objcT51,selTransTbl[24]))(objcT51,selTransTbl[24],(objcT52=TextAttribute,(*_imp(objcT52,selTransTbl[23]))(objcT52,selTransTbl[23])),p,q));
return(id)self;
}

static id i_Text_addAttribute_(struct Text_PRIVATE *self,SEL _cmd,id attribute)
{
id objcT53,objcT54;

#line 211 "octext.m"
unsigned n=(objcT53=self->string,(*(unsigned(*)(id,SEL))_imp(objcT53,selTransTbl[1]))(objcT53,selTransTbl[1]));
(objcT54=self->runs,(*(id(*)(id,SEL,id,unsigned,unsigned))_imp(objcT54,selTransTbl[25]))(objcT54,selTransTbl[25],attribute,0,n));
return(id)self;
}

static id i_Text_addAttribute_from_to_(struct Text_PRIVATE *self,SEL _cmd,id attribute,unsigned p,unsigned q)
{
id objcT55,objcT56,objcT57,objcT58;

#line 218 "octext.m"
unsigned n=(objcT55=self->string,(*(unsigned(*)(id,SEL))_imp(objcT55,selTransTbl[1]))(objcT55,selTransTbl[1]));
if(p>q||q>=n)(objcT56=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT56,selTransTbl[26]))(objcT56,selTransTbl[26],"Index out of range."));
(objcT57=self->runs,(*(id(*)(id,SEL,id,unsigned,unsigned))_imp(objcT57,selTransTbl[25]))(objcT57,selTransTbl[25],attribute,p,q-p+1));
assert((objcT58=(id)self,(*_imp(objcT58,selTransTbl[0]))(objcT58,selTransTbl[0])));
return(id)self;
}

static id i_Text_attributesAt_(struct Text_PRIVATE *self,SEL _cmd,unsigned i)
{
id objcT59,objcT60,objcT61;

#line 227 "octext.m"
(objcT59=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT59,selTransTbl[12]))(objcT59,selTransTbl[12],(objcT60=self->string,(*(unsigned(*)(id,SEL))_imp(objcT60,selTransTbl[1]))(objcT60,selTransTbl[1]))));
return(objcT61=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT61,selTransTbl[27]))(objcT61,selTransTbl[27],i));
}

static unsigned i_Text_runLengthFor_(struct Text_PRIVATE *self,SEL _cmd,unsigned i)
{
id objcT62,objcT63,objcT64;

#line 233 "octext.m"
(objcT62=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT62,selTransTbl[12]))(objcT62,selTransTbl[12],(objcT63=self->string,(*(unsigned(*)(id,SEL))_imp(objcT63,selTransTbl[1]))(objcT63,selTransTbl[1]))));
return(objcT64=self->runs,(*(unsigned(*)(id,SEL,unsigned))_imp(objcT64,selTransTbl[28]))(objcT64,selTransTbl[28],i));
}

static unsigned i_Text_fontNumberAt_(struct Text_PRIVATE *self,SEL _cmd,unsigned i)
{
id objcT65,objcT66,objcT67;

#line 239 "octext.m"
(objcT65=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT65,selTransTbl[12]))(objcT65,selTransTbl[12],(objcT66=self->string,(*(unsigned(*)(id,SEL))_imp(objcT66,selTransTbl[1]))(objcT66,selTransTbl[1]))));
return(objcT67=self->runs,(*(unsigned(*)(id,SEL,unsigned))_imp(objcT67,selTransTbl[29]))(objcT67,selTransTbl[29],i));
}

static id i_Text_fontAt_withStyle_(struct Text_PRIVATE *self,SEL _cmd,unsigned i,id textStyle)
{
id objcT68,objcT69,objcT70;

#line 245 "octext.m"
(objcT68=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT68,selTransTbl[12]))(objcT68,selTransTbl[12],(objcT69=self->string,(*(unsigned(*)(id,SEL))_imp(objcT69,selTransTbl[1]))(objcT69,selTransTbl[1]))));
return(objcT70=self->runs,(*(id(*)(id,SEL,unsigned,id))_imp(objcT70,selTransTbl[30]))(objcT70,selTransTbl[30],i,textStyle));
}


static id i_Text_asString(struct Text_PRIVATE *self,SEL _cmd)
{
return self->string;
}

static id i_Text_asText(struct Text_PRIVATE *self,SEL _cmd)
{
return(id)self;
}

#line 29 "paragrph.h"
extern id  Paragraph;

#line 260 "octext.m"
static id i_Text_asParagraph(struct Text_PRIVATE *self,SEL _cmd)
{
id objcT71;

#line 262 "octext.m"
return(objcT71=Paragraph,(*_imp(objcT71,selTransTbl[31]))(objcT71,selTransTbl[31],(id)self));
}


static id i_Text_printOn_(struct Text_PRIVATE *self,SEL _cmd,IOD aFile)
{
id objcT72;

#line 268 "octext.m"
fprintf(aFile,"Text for ");
(objcT72=self->string,(*(id(*)(id,SEL,IOD))_imp(objcT72,selTransTbl[32]))(objcT72,selTransTbl[32],aFile));
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
static struct _SLT _Text_clsDispatchTbl[] ={
{"new",(id (*)())c_Text_new},
{"new:",(id (*)())c_Text_new_},
{"vsprintf::",(id (*)())c_Text_vsprintf__},
{"str:",(id (*)())c_Text_str_},
{"sprintf:",(id (*)())c_Text_sprintf_},
{"fromString:",(id (*)())c_Text_fromString_},
{"string:attribute:",(id (*)())c_Text_string_attribute_},
{(char*)0,(id (*)())0}
};
static struct _SLT _Text_nstDispatchTbl[] ={
{"check",(id (*)())i_Text_check},
{"string:runs:",(id (*)())i_Text_string_runs_},
{"copy",(id (*)())i_Text_copy},
{"free",(id (*)())i_Text_free},
{"hash",(id (*)())i_Text_hash},
{"isEqual:",(id (*)())i_Text_isEqual_},
{"string",(id (*)())i_Text_string},
{"runs",(id (*)())i_Text_runs},
{"str",(id (*)())i_Text_str},
{"size",(id (*)())i_Text_size},
{"charAt:",(id (*)())i_Text_charAt_},
{"charAt:put:",(id (*)())i_Text_charAt_put_},
{"at:insert:",(id (*)())i_Text_at_insert_},
{"at:insert:count:",(id (*)())i_Text_at_insert_count_},
{"deleteFrom:to:",(id (*)())i_Text_deleteFrom_to_},
{"concat:",(id (*)())i_Text_concat_},
{"concatSTR:",(id (*)())i_Text_concatSTR_},
{"allBold",(id (*)())i_Text_allBold},
{"makeBoldFrom:to:",(id (*)())i_Text_makeBoldFrom_to_},
{"addAttribute:",(id (*)())i_Text_addAttribute_},
{"addAttribute:from:to:",(id (*)())i_Text_addAttribute_from_to_},
{"attributesAt:",(id (*)())i_Text_attributesAt_},
{"runLengthFor:",(id (*)())i_Text_runLengthFor_},
{"fontNumberAt:",(id (*)())i_Text_fontNumberAt_},
{"fontAt:withStyle:",(id (*)())i_Text_fontAt_withStyle_},
{"asString",(id (*)())i_Text_asString},
{"asText",(id (*)())i_Text_asText},
{"asParagraph",(id (*)())i_Text_asParagraph},
{"printOn:",(id (*)())i_Text_printOn_},
{(char*)0,(id (*)())0}
};
id Text = (id)&_Text;
id  *OBJCCLASS_Text(void) { return &Text; }
struct _SHARED  _Text = {
  (id)&__Text,
  (id)&_Object,
  "Text",
  0,
  sizeof(struct Text_PRIVATE),
  29,
  _Text_nstDispatchTbl,
  41,
  &octext_modDesc,
  0,
  (id)0,
  &Text,
};
id  OBJCCFUNC_Text(void) { return (id)&_Text; }
id  OBJCCSUPER_Text(void) { return _Text.clsSuper; }
struct _SHARED __Text = {
  (id)&__Object,
  (id)&__Object,
  "Text",
  0,
  sizeof(struct _SHARED),
  7,
  _Text_clsDispatchTbl,
  34,
  &octext_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_Text(void) { return (id)&__Text; }
id  OBJCMSUPER_Text(void) { return __Text.clsSuper; }
static char *_selTransTbl[] ={
"check",
"size",
"fromString:",
"new",
"new:",
"str:",
"vsprintf::",
"string:runs:",
"addAttribute:",
"copy",
"free",
"hash",
"setsize:",
"isEqual:",
"string",
"runs",
"str",
"charAt:",
"charAt:put:",
"at:insert:count:",
"deleteFrom:to:",
"concat:",
"concatSTR:",
"bold",
"addAttribute:from:to:",
"addAttribute:from:size:",
"error:",
"at:",
"runLengthAt:",
"fontNumberAt:",
"fontAt:withStyle:",
"withText:",
"printOn:",
0
};
struct modDescriptor octext_modDesc = {
  "octext",
  "objc2.3.1",
  0L,
  0,
  0,
  &Text,
  33,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_octext(void)
{
  selTransTbl = _selTransTbl;
  return &octext_modDesc;
}
int _OBJCPOSTLINK_octext = 1;


