#line 1 "util.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_util(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor util_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/ctype.h"
#include <ctype.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 31 "../../include/objpak/ordcltn.h"
typedef struct objcol{
int count;
int capacity;
id*ptr;
}*objcol_t;
#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 23 "util.h"
extern FILE*yyin;
extern int yyparse();

FILE*openfile(STR name,STR modfs);
FILE*reopenfile(STR name,STR modfs,FILE*of);

extern int okblock;

id mkcppdirect(char*s);
id mkexprstmt(id expr);
id mklabeledstmt(id label,id stmt);
id mkcasestmt(id keyw,id expr,id stmt);
id mkdefaultstmt(id keyw,id stmt);
id mkifstmt(id keyw,id expr,id stmt);
id mkifelsestmt(id keyw,id expr,id stmt,id ekeyw,id estmt);
id mkswitchstmt(id keyw,id expr,id stmt);
id mkwhilestmt(id keyw,id expr,id stmt);
id mkdostmt(id keyw,id stmt,id wkeyw,id expr);
id mkforstmt(id keyw,id a,id b,id c,id stmt);
id mkgotostmt(id keyw,id label);
id mkcontinuestmt(id keyw);
id mkbreakstmt(id keyw);
id mkreturnstmt(id keyw,id expr);
id mkcastexpr(id a,id b);
id mkcondexpr(id a,id b,id c);
id mkunaryexpr(STR op,id a);
id mksizeof(id a);
id mkaddressof(id a);
id mkdereference(id a);
id mkbinexpr(id a,STR op,id b);
id mkcommaexpr(id a,id b);
id mkrelexpr(id a,STR op,id b);
id mkassignexpr(id a,STR op,id b);
id mkfuncall(id funname,id args);
id mkbuiltincall(id funname,id args);
id mkfunbody(id datadefs,id compound);
void declarefun(id specs,id decl);
void declaremeth(BOOL factory,id decl);
id mkfundef(id specs,id decl,id body);
id mkmethdef(BOOL factory,id decl,id body);
id mkmesgexpr(id receiver,id args);
id mkdecl(id ident);
id mkprecdecl(id tquals,id decl);
id mkarraydecl(id lhs,id ix);
id mkfundecl(id lhs,id args);
id mkprefixdecl(id lhs,id rhs);
id mkpostfixdecl(id lhs,id rhs);
id mkpointer(id specs,id pointer);
id mkbitfielddecl(id decl,id expr);
id mkstardecl(id pointer,id decl);
id mkasmop(id string,id expr);
id mkasmstmt(id keyw,id tqual,id expr,id asmop1,id asmop2,id clobbers);
id mkcompstmt(id lb,id datadefs,id stmtlist,id rb);
id mklist(id c,id s);
id mklist2(id c,id s,id t);
id atdefsaddall(id c,id n);
id mkblockexpr(id lb,id parms,id datadefs,id stmts,id expr,id rb);
id mkclassdef(id keyw,id name,id sname,id ivars,id cvars);
id mkdatadef(id datadef,id specs,id decl,id initializer);
id mkencodeexpr(id name);
id mkenumspec(id keyw,id name,id lb,id list,id rb);
id mkenumerator(id name,id value);
id mkgnuattrib(id anyword,id exprlist);
id mkgnuattribdecl(id keyw,id list);
id mklistexpr(id lb,id x,id rb);
id mktypename(id specs,id decl);
id mkcomponentdef(id cdef,id specs,id decl);
id mkstructspec(id keyw,id name,id lb,id defs,id rb);
id mkkeywarg(id sel,id arg);
id mkkeywdecl(id sel,id cast,id arg);
id mkmethproto(id cast,id usel,id ksel,BOOL varargs);
id mkidentexpr(id name);
id mkconstexpr(id name,id schain);
id mkprecexpr(id expr);
id mkarrowexpr(id array,id ix);
id mkdotexpr(id array,id ix);
id mkindexexpr(id array,id ix);
id mkpostfixexpr(id expr,id pf);
id mkparmdef(id parmdef,id specs,id decl);
id mkparmdeflist(id idents,id parmdefs,BOOL varargs);
id mkselarg(id selarg,id usel,int ncols);
id mkselectorexpr(id expr);

void procextdef(id def);
void finclassdef(void);
void datadefokblock(id datadef,id specs,id decl);

id mkfileinmeth(id classdef,id ivarnames,id ivartypes);
id mkfileoutmeth(id classdef,id ivarnames,id ivartypes);

id mkincrefsmeth(id classdef,id ivarnames,id ivartypes);
id mkdecrefsmeth(id classdef,id ivarnames,id ivartypes);
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 22 "compstmt.h"
extern id curcompound;
extern id curloopcompound;
#line 22 "expr.h"
extern id e_nil;
extern id e_self;
extern id e_cmd;
extern id e_super;
extern id e_aFiler;
extern id e_ft_id;
#line 22 "blockxpr.h"
extern id curcompound;
#line 22 "structsp.h"
extern id curstruct;
#line 22 "def.h"
extern id curdef;
#line 22 "classdef.h"
extern id curclassdef;
extern id curstruct;
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "trlunit.h"
extern id trlunit;

#line 106 "util.m"
void
procextdef(id def)
{
id objcT0,objcT1,objcT2;

#line 109 "util.m"
(objcT0=def,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
if(o_outputcode)
(objcT1=def,(*_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1]));
if(o_st80)
(objcT2=def,(*_imp(objcT2,selTransTbl[2]))(objcT2,selTransTbl[2]));
}

void
finclassdef(void)
{
if(curclassdef){
id objcT3,objcT6;

#line 120 "util.m"
if((objcT3=curclassdef,(*(int(*)(id,SEL))_imp(objcT3,selTransTbl[3]))(objcT3,selTransTbl[3]))){
if(o_filer){
id objcT4;

#line 122 "util.m"
(objcT4=curclassdef,(*_imp(objcT4,selTransTbl[4]))(objcT4,selTransTbl[4]));
}
if(o_refcnt){
id objcT5;

#line 125 "util.m"
(objcT5=curclassdef,(*_imp(objcT5,selTransTbl[5]))(objcT5,selTransTbl[5]));
}
}
if(o_warnmissingmethods&&(objcT6=curclassdef,(*(BOOL(*)(id,SEL))_imp(objcT6,selTransTbl[6]))(objcT6,selTransTbl[6]))){
id objcT7;

#line 129 "util.m"
(objcT7=curclassdef,(*_imp(objcT7,selTransTbl[7]))(objcT7,selTransTbl[7]));
}
curclassdef=(id)0;
}else{
fatal("illegal end of class definition.");
}
}

FILE*
openfile(STR name,STR modfs)
{
FILE*f;

if((f=fopen(name,modfs))==NULL){
fprintf(stderr,"objc1: Unable to open %s\n",name);
exit(1);
}
return f;
}

FILE*
reopenfile(STR name,STR modfs,FILE*of)
{
FILE*f;

if((f=freopen(name,modfs,of))==NULL){
fprintf(stderr,"objc1: Unable to open %s\n",name);
exit(1);
}
return f;
}

static char*
setinlineno(char*s)
{
char*p=s;
int c,n=0;

while((c= *p++)&&'0'<=c&&c<='9'){
n=n*10+(c-'0');
}

inlineno=n;
return p-1;
}

#line 38 "../../include/objpak/ocstring.h"
extern id  String;

#line 175 "util.m"
static BOOL
setinfilename(char*s)
{
char*p=s;
int c,n=0;

while((c= *p++)&&c!='"')
n++;


if(c=='"'){
id objcT8;

#line 186 "util.m"
infilename=(objcT8=String,(*(id(*)(id,SEL,STR,int))_imp(objcT8,selTransTbl[8]))(objcT8,selTransTbl[8],s,n));
return(BOOL)1;
}else{
return(BOOL)0;
}
}

static BOOL
isline(char*s)
{
int c;
char*p=s;


c= *p++;
if(c=='#'){
c= *p++;
}else{
return(BOOL)0;
}


while(c&&(c==' '||c=='\t'))
c= *p++;


if(c=='l'){
char*key="ine";

if(strncmp(p,key,strlen(key))==0){
p+=strlen(key);
c= *p++;
}else{
return(BOOL)0;
}
}

while(c&&(c==' '||c=='\t'))
c= *p++;


if(c&&'0'<=c&&c<='9'){
p=setinlineno(p-1);
c= *p++;
}else{
return(BOOL)0;
}


while(c&&(c==' '||c=='\t'))
c= *p++;


if(c&&c=='"'){
return setinfilename(p);

}else{


return(BOOL)1;
}
}

#line 252 "util.m"
static BOOL
ispragma(char*s)
{
id objcT9,objcT10;

#line 255 "util.m"
char*t;
id x=(objcT9=String,(*(id(*)(id,SEL,STR))_imp(objcT9,selTransTbl[9]))(objcT9,selTransTbl[9],s));
char*sep=" #/\t\n\r";

t=strtok((objcT10=x,(*(STR(*)(id,SEL))_imp(objcT10,selTransTbl[10]))(objcT10,selTransTbl[10])),sep);
if(strcmp(t,"pragma")!=0)return(BOOL)0;
t=strtok(NULL,sep);

if(strcmp(t,"OCbuiltInFctn")==0){
definebuiltinfun(strtok(NULL,sep));
return(BOOL)1;
}
if(strcmp(t,"OCbuiltInVar")==0){
definebuiltinvar(strtok(NULL,sep));
return(BOOL)1;
}
if(strcmp(t,"OCbuiltInType")==0){
definebuiltintype(strtok(NULL,sep));
return(BOOL)1;
}
if(strcmp(t,"OCRefCnt")==0){
o_refcnt=pragmatoggle(strtok(NULL,sep));
return(BOOL)1;
}
if(strcmp(t,"OCInlineCache")==0){
o_inlinecache=pragmatoggle(strtok(NULL,sep));
return(BOOL)1;
}
return(BOOL)0;
}

#line 22 "cppdirec.h"
extern id  CppDirective;

#line 286 "util.m"
id
mkcppdirect(char*s)
{
id objcT11;

#line 289 "util.m"
id r;
int n;
char*t;

if(isline(s))
return(id)0;
if(ispragma(s))
return(id)0;


t="#printLine ";
n=strlen(t);
if(strncmp(s,t,n)==0)
s+=n;
t="#pragma printLine ";
n=strlen(t);
if(strncmp(s,t,n)==0)
s+=n;

r=(objcT11=CppDirective,(*(id(*)(id,SEL,char*,int,id))_imp(objcT11,selTransTbl[11]))(objcT11,selTransTbl[11],s,inlineno,infilename));
return r;
}

#line 22 "exprstmt.h"
extern id  ExprStmt;

#line 312 "util.m"
id
mkexprstmt(id expr)
{
id objcT12,objcT13;

#line 315 "util.m"
id r=(objcT12=ExprStmt,(*_imp(objcT12,selTransTbl[12]))(objcT12,selTransTbl[12]));
(objcT13=r,(*_imp(objcT13,selTransTbl[13]))(objcT13,selTransTbl[13],expr));
return r;
}

id
mkexprstmtx(id expr)
{
id objcT14,objcT15,objcT16;

#line 323 "util.m"
id r=(objcT14=ExprStmt,(*_imp(objcT14,selTransTbl[12]))(objcT14,selTransTbl[12]));
(objcT15=r,(*_imp(objcT15,selTransTbl[13]))(objcT15,selTransTbl[13],expr));
(objcT16=r,(*(id(*)(id,SEL,BOOL))_imp(objcT16,selTransTbl[14]))(objcT16,selTransTbl[14],(BOOL)1));
return r;
}

#line 22 "lblstmt.h"
extern id  LabeledStmt;

#line 329 "util.m"
id
mklabeledstmt(id label,id stmt)
{
id objcT17,objcT18,objcT19;

#line 332 "util.m"
id r=(objcT17=LabeledStmt,(*_imp(objcT17,selTransTbl[12]))(objcT17,selTransTbl[12]));

(objcT18=r,(*_imp(objcT18,selTransTbl[15]))(objcT18,selTransTbl[15],label));
(objcT19=r,(*_imp(objcT19,selTransTbl[16]))(objcT19,selTransTbl[16],stmt));
return r;
}

#line 22 "casestmt.h"
extern id  CaseStmt;

#line 339 "util.m"
id
mkcasestmt(id keyw,id expr,id stmt)
{
id objcT20,objcT21,objcT22,objcT23;

#line 342 "util.m"
id r=(objcT20=CaseStmt,(*_imp(objcT20,selTransTbl[12]))(objcT20,selTransTbl[12]));

(objcT21=r,(*_imp(objcT21,selTransTbl[17]))(objcT21,selTransTbl[17],keyw));
(objcT22=r,(*_imp(objcT22,selTransTbl[13]))(objcT22,selTransTbl[13],expr));
(objcT23=r,(*_imp(objcT23,selTransTbl[16]))(objcT23,selTransTbl[16],stmt));
return r;
}

#line 22 "dfltstmt.h"
extern id  DefaultStmt;

#line 350 "util.m"
id
mkdefaultstmt(id keyw,id stmt)
{
id objcT24,objcT25,objcT26;

#line 353 "util.m"
id r=(objcT24=DefaultStmt,(*_imp(objcT24,selTransTbl[12]))(objcT24,selTransTbl[12]));

(objcT25=r,(*_imp(objcT25,selTransTbl[17]))(objcT25,selTransTbl[17],keyw));
(objcT26=r,(*_imp(objcT26,selTransTbl[16]))(objcT26,selTransTbl[16],stmt));
return r;
}

#line 22 "ifstmt.h"
extern id  IfStmt;

#line 360 "util.m"
id
mkifstmt(id keyw,id expr,id stmt)
{
id objcT27,objcT28,objcT29,objcT30;

#line 363 "util.m"
id r=(objcT27=IfStmt,(*_imp(objcT27,selTransTbl[12]))(objcT27,selTransTbl[12]));

(objcT28=r,(*_imp(objcT28,selTransTbl[17]))(objcT28,selTransTbl[17],keyw));
(objcT29=r,(*_imp(objcT29,selTransTbl[13]))(objcT29,selTransTbl[13],expr));
(objcT30=r,(*_imp(objcT30,selTransTbl[16]))(objcT30,selTransTbl[16],stmt));
return r;
}

id
mkifelsestmt(id keyw,id expr,id stmt,id ekeyw,id estmt)
{
id objcT31,objcT32,objcT33,objcT34,objcT35;
id objcT36;

#line 374 "util.m"
id r=(objcT31=IfStmt,(*_imp(objcT31,selTransTbl[12]))(objcT31,selTransTbl[12]));

(objcT32=r,(*_imp(objcT32,selTransTbl[17]))(objcT32,selTransTbl[17],keyw));
(objcT33=r,(*_imp(objcT33,selTransTbl[13]))(objcT33,selTransTbl[13],expr));
(objcT34=r,(*_imp(objcT34,selTransTbl[16]))(objcT34,selTransTbl[16],stmt));
(objcT35=r,(*_imp(objcT35,selTransTbl[18]))(objcT35,selTransTbl[18],ekeyw));
(objcT36=r,(*_imp(objcT36,selTransTbl[19]))(objcT36,selTransTbl[19],estmt));
return r;
}

#line 22 "switstmt.h"
extern id  SwitchStmt;

#line 384 "util.m"
id
mkswitchstmt(id keyw,id expr,id stmt)
{
id objcT37,objcT38,objcT39,objcT40;

#line 387 "util.m"
id r=(objcT37=SwitchStmt,(*_imp(objcT37,selTransTbl[12]))(objcT37,selTransTbl[12]));

(objcT38=r,(*_imp(objcT38,selTransTbl[17]))(objcT38,selTransTbl[17],keyw));
(objcT39=r,(*_imp(objcT39,selTransTbl[13]))(objcT39,selTransTbl[13],expr));
(objcT40=r,(*_imp(objcT40,selTransTbl[16]))(objcT40,selTransTbl[16],stmt));
return r;
}

#line 22 "whilstmt.h"
extern id  WhileStmt;

#line 395 "util.m"
id
mkwhilestmt(id keyw,id expr,id stmt)
{
id objcT41,objcT42,objcT43,objcT44;

#line 398 "util.m"
id r=(objcT41=WhileStmt,(*_imp(objcT41,selTransTbl[12]))(objcT41,selTransTbl[12]));

(objcT42=r,(*_imp(objcT42,selTransTbl[17]))(objcT42,selTransTbl[17],keyw));
(objcT43=r,(*_imp(objcT43,selTransTbl[13]))(objcT43,selTransTbl[13],expr));
(objcT44=r,(*_imp(objcT44,selTransTbl[16]))(objcT44,selTransTbl[16],stmt));
return r;
}

#line 22 "dostmt.h"
extern id  DoStmt;

#line 406 "util.m"
id
mkdostmt(id keyw,id stmt,id wkeyw,id expr)
{
id objcT45,objcT46,objcT47,objcT48,objcT49;

#line 409 "util.m"
id r=(objcT45=DoStmt,(*_imp(objcT45,selTransTbl[12]))(objcT45,selTransTbl[12]));

(objcT46=r,(*_imp(objcT46,selTransTbl[17]))(objcT46,selTransTbl[17],keyw));
(objcT47=r,(*_imp(objcT47,selTransTbl[16]))(objcT47,selTransTbl[16],stmt));
(objcT48=r,(*_imp(objcT48,selTransTbl[20]))(objcT48,selTransTbl[20],wkeyw));
(objcT49=r,(*_imp(objcT49,selTransTbl[13]))(objcT49,selTransTbl[13],expr));
return r;
}

#line 22 "forstmt.h"
extern id  ForStmt;

#line 418 "util.m"
id
mkforstmt(id keyw,id a,id b,id c,id stmt)
{
id objcT50,objcT51,objcT52,objcT53;

#line 421 "util.m"
id r=(objcT50=ForStmt,(*_imp(objcT50,selTransTbl[12]))(objcT50,selTransTbl[12]));

(objcT51=r,(*_imp(objcT51,selTransTbl[17]))(objcT51,selTransTbl[17],keyw));
(objcT52=r,(*_imp(objcT52,selTransTbl[21]))(objcT52,selTransTbl[21],a,b,c));
(objcT53=r,(*_imp(objcT53,selTransTbl[16]))(objcT53,selTransTbl[16],stmt));
return r;
}

#line 22 "gotostmt.h"
extern id  GotoStmt;

#line 429 "util.m"
id
mkgotostmt(id keyw,id label)
{
id objcT54,objcT55,objcT56;

#line 432 "util.m"
id r=(objcT54=GotoStmt,(*_imp(objcT54,selTransTbl[12]))(objcT54,selTransTbl[12]));

(objcT55=r,(*_imp(objcT55,selTransTbl[17]))(objcT55,selTransTbl[17],keyw));
(objcT56=r,(*_imp(objcT56,selTransTbl[15]))(objcT56,selTransTbl[15],label));
return r;
}

#line 22 "contstmt.h"
extern id  ContinueStmt;

#line 439 "util.m"
id
mkcontinuestmt(id keyw)
{
id objcT57,objcT58;

#line 442 "util.m"
id r=(objcT57=ContinueStmt,(*_imp(objcT57,selTransTbl[12]))(objcT57,selTransTbl[12]));

(objcT58=r,(*_imp(objcT58,selTransTbl[17]))(objcT58,selTransTbl[17],keyw));
return r;
}

id
mkbreakstmt(id keyw)
{
return mkcontinuestmt(keyw);
}

#line 22 "rtrnstmt.h"
extern id  ReturnStmt;

#line 454 "util.m"
id
mkreturnstmt(id keyw,id expr)
{
id objcT59,objcT60,objcT61;

#line 457 "util.m"
id r=(objcT59=ReturnStmt,(*_imp(objcT59,selTransTbl[12]))(objcT59,selTransTbl[12]));

(objcT60=r,(*_imp(objcT60,selTransTbl[17]))(objcT60,selTransTbl[17],keyw));
(objcT61=r,(*_imp(objcT61,selTransTbl[13]))(objcT61,selTransTbl[13],expr));
return r;
}

id
mkreturnx(id x)
{
id objcT62,objcT63;

#line 467 "util.m"
return(objcT62=(objcT63=ReturnStmt,(*_imp(objcT63,selTransTbl[12]))(objcT63,selTransTbl[12])),(*_imp(objcT62,selTransTbl[13]))(objcT62,selTransTbl[13],x));
}

#line 22 "castxpr.h"
extern id  CastExpr;

#line 470 "util.m"
id
mkcastexpr(id a,id b)
{
id objcT64,objcT65,objcT66;

#line 473 "util.m"
id r=(objcT64=CastExpr,(*_imp(objcT64,selTransTbl[12]))(objcT64,selTransTbl[12]));

(objcT65=r,(*_imp(objcT65,selTransTbl[22]))(objcT65,selTransTbl[22],a));
(objcT66=r,(*_imp(objcT66,selTransTbl[13]))(objcT66,selTransTbl[13],b));
return r;
}

#line 22 "condxpr.h"
extern id  CondExpr;

#line 480 "util.m"
id
mkcondexpr(id a,id b,id c)
{
id objcT67,objcT68,objcT69,objcT70;

#line 483 "util.m"
id r=(objcT67=CondExpr,(*_imp(objcT67,selTransTbl[12]))(objcT67,selTransTbl[12]));

(objcT68=r,(*_imp(objcT68,selTransTbl[13]))(objcT68,selTransTbl[13],a));
(objcT69=r,(*_imp(objcT69,selTransTbl[23]))(objcT69,selTransTbl[23],b));
(objcT70=r,(*_imp(objcT70,selTransTbl[24]))(objcT70,selTransTbl[24],c));
return r;
}

#line 22 "unyxpr.h"
extern id  UnaryExpr;

#line 491 "util.m"
id
mkunaryexpr(STR op,id a)
{
id objcT71,objcT72,objcT73;

#line 494 "util.m"
id r=(objcT71=UnaryExpr,(*_imp(objcT71,selTransTbl[12]))(objcT71,selTransTbl[12]));

(objcT72=r,(*(id(*)(id,SEL,STR))_imp(objcT72,selTransTbl[25]))(objcT72,selTransTbl[25],op));
(objcT73=r,(*_imp(objcT73,selTransTbl[13]))(objcT73,selTransTbl[13],a));
return r;
}

#line 22 "deref.h"
extern id  Dereference;

#line 501 "util.m"
id
mkdereference(id a)
{
id objcT74,objcT75;

#line 504 "util.m"
id r=(objcT74=Dereference,(*_imp(objcT74,selTransTbl[12]))(objcT74,selTransTbl[12]));

(objcT75=r,(*_imp(objcT75,selTransTbl[13]))(objcT75,selTransTbl[13],a));
return r;
}

#line 22 "sizeof.h"
extern id  SizeOf;

#line 510 "util.m"
id
mksizeof(id a)
{
id objcT76,objcT77;

#line 513 "util.m"
id r=(objcT76=SizeOf,(*_imp(objcT76,selTransTbl[12]))(objcT76,selTransTbl[12]));

(objcT77=r,(*_imp(objcT77,selTransTbl[13]))(objcT77,selTransTbl[13],a));
return r;
}

#line 22 "addrof.h"
extern id  AddressOf;

#line 519 "util.m"
id
mkaddressof(id a)
{
id objcT78,objcT79;

#line 522 "util.m"
id r=(objcT78=AddressOf,(*_imp(objcT78,selTransTbl[12]))(objcT78,selTransTbl[12]));

(objcT79=r,(*_imp(objcT79,selTransTbl[13]))(objcT79,selTransTbl[13],a));
return r;
}

#line 22 "binxpr.h"
extern id  BinaryExpr;

#line 528 "util.m"
id
mkbinexpr(id a,STR op,id b)
{
id objcT80,objcT81,objcT82,objcT83;

#line 531 "util.m"
id r=(objcT80=BinaryExpr,(*_imp(objcT80,selTransTbl[12]))(objcT80,selTransTbl[12]));

(objcT81=r,(*_imp(objcT81,selTransTbl[23]))(objcT81,selTransTbl[23],a));
(objcT82=r,(*_imp(objcT82,selTransTbl[24]))(objcT82,selTransTbl[24],b));
(objcT83=r,(*(id(*)(id,SEL,STR))_imp(objcT83,selTransTbl[25]))(objcT83,selTransTbl[25],op));
return r;
}

#line 22 "commaxpr.h"
extern id  CommaExpr;

#line 539 "util.m"
id
mkcommaexpr(id a,id b)
{
id objcT84,objcT85,objcT86;

#line 542 "util.m"
id r=(objcT84=CommaExpr,(*_imp(objcT84,selTransTbl[12]))(objcT84,selTransTbl[12]));

(objcT85=r,(*_imp(objcT85,selTransTbl[23]))(objcT85,selTransTbl[23],a));
(objcT86=r,(*_imp(objcT86,selTransTbl[24]))(objcT86,selTransTbl[24],b));
return r;
}

#line 22 "assign.h"
extern id  Assignment;

#line 549 "util.m"
id
mkassignexpr(id a,STR op,id b)
{
id objcT87,objcT88,objcT89,objcT90;

#line 552 "util.m"
id r=(objcT87=Assignment,(*_imp(objcT87,selTransTbl[12]))(objcT87,selTransTbl[12]));

(objcT88=r,(*_imp(objcT88,selTransTbl[23]))(objcT88,selTransTbl[23],a));
(objcT89=r,(*_imp(objcT89,selTransTbl[24]))(objcT89,selTransTbl[24],b));
(objcT90=r,(*(id(*)(id,SEL,STR))_imp(objcT90,selTransTbl[25]))(objcT90,selTransTbl[25],op));
return r;
}

#line 22 "relxpr.h"
extern id  RelationExpr;

#line 560 "util.m"
id
mkrelexpr(id a,STR op,id b)
{
id objcT91,objcT92,objcT93,objcT94;

#line 563 "util.m"
id r=(objcT91=RelationExpr,(*_imp(objcT91,selTransTbl[12]))(objcT91,selTransTbl[12]));

(objcT92=r,(*_imp(objcT92,selTransTbl[23]))(objcT92,selTransTbl[23],a));
(objcT93=r,(*_imp(objcT93,selTransTbl[24]))(objcT93,selTransTbl[24],b));
(objcT94=r,(*(id(*)(id,SEL,STR))_imp(objcT94,selTransTbl[25]))(objcT94,selTransTbl[25],op));
return r;
}

#line 22 "btincall.h"
extern id  BuiltinCall;

#line 571 "util.m"
id
mkbuiltincall(id funname,id args)
{
id objcT95,objcT96,objcT97;

#line 574 "util.m"
id r=(objcT95=BuiltinCall,(*_imp(objcT95,selTransTbl[12]))(objcT95,selTransTbl[12]));

(objcT96=r,(*_imp(objcT96,selTransTbl[26]))(objcT96,selTransTbl[26],funname));
(objcT97=r,(*_imp(objcT97,selTransTbl[27]))(objcT97,selTransTbl[27],args));
return r;
}

#line 22 "funcall.h"
extern id  FunctionCall;

#line 581 "util.m"
id
mkfuncall(id funname,id args)
{
id objcT98,objcT99,objcT100;

#line 584 "util.m"
id r=(objcT98=FunctionCall,(*_imp(objcT98,selTransTbl[12]))(objcT98,selTransTbl[12]));

(objcT99=r,(*_imp(objcT99,selTransTbl[26]))(objcT99,selTransTbl[26],funname));
(objcT100=r,(*_imp(objcT100,selTransTbl[27]))(objcT100,selTransTbl[27],args));
return r;
}

#line 22 "funbody.h"
extern id  FunctionBody;

#line 591 "util.m"
id
mkfunbody(id datadefs,id compound)
{
id objcT101,objcT102,objcT103;

#line 594 "util.m"
id r=(objcT101=FunctionBody,(*_imp(objcT101,selTransTbl[12]))(objcT101,selTransTbl[12]));

(objcT102=r,(*_imp(objcT102,selTransTbl[28]))(objcT102,selTransTbl[28],datadefs));
(objcT103=r,(*_imp(objcT103,selTransTbl[29]))(objcT103,selTransTbl[29],compound));
return r;
}

#line 22 "datadef.h"
extern id  DataDef;

#line 601 "util.m"
void
declarefun(id specs,id decl)
{
id objcT104,objcT105,objcT106,objcT107;

#line 604 "util.m"
id d=(objcT104=DataDef,(*_imp(objcT104,selTransTbl[12]))(objcT104,selTransTbl[12]));

if(specs)
(objcT105=d,(*_imp(objcT105,selTransTbl[30]))(objcT105,selTransTbl[30],specs));
(objcT106=d,(*_imp(objcT106,selTransTbl[31]))(objcT106,selTransTbl[31],decl));
(objcT107=d,(*_imp(objcT107,selTransTbl[0]))(objcT107,selTransTbl[0]));
}

#line 22 "methdef.h"
extern id  MethodDef;

#line 612 "util.m"
void
declaremeth(BOOL factory,id decl)
{
id objcT108,objcT109,objcT110,objcT111;

#line 615 "util.m"
id r=(objcT108=MethodDef,(*_imp(objcT108,selTransTbl[12]))(objcT108,selTransTbl[12]));

(objcT109=r,(*(id(*)(id,SEL,BOOL))_imp(objcT109,selTransTbl[32]))(objcT109,selTransTbl[32],factory));
(objcT110=r,(*_imp(objcT110,selTransTbl[33]))(objcT110,selTransTbl[33],decl));
(objcT111=r,(*_imp(objcT111,selTransTbl[34]))(objcT111,selTransTbl[34]));
}

#line 22 "fundef.h"
extern id  FunctionDef;

#line 622 "util.m"
id
mkfundef(id specs,id decl,id body)
{
id objcT112,objcT113,objcT114,objcT115;

#line 625 "util.m"
id r=(objcT112=FunctionDef,(*_imp(objcT112,selTransTbl[12]))(objcT112,selTransTbl[12]));

(objcT113=r,(*_imp(objcT113,selTransTbl[35]))(objcT113,selTransTbl[35],specs));
(objcT114=r,(*_imp(objcT114,selTransTbl[36]))(objcT114,selTransTbl[36],decl));
(objcT115=r,(*_imp(objcT115,selTransTbl[37]))(objcT115,selTransTbl[37],body));
return r;
}

id
mkmethdef(BOOL factory,id decl,id body)
{
id objcT116,objcT117,objcT118,objcT119;

#line 636 "util.m"
id r=(objcT116=MethodDef,(*_imp(objcT116,selTransTbl[12]))(objcT116,selTransTbl[12]));

(objcT117=r,(*(id(*)(id,SEL,BOOL))_imp(objcT117,selTransTbl[32]))(objcT117,selTransTbl[32],factory));
(objcT118=r,(*_imp(objcT118,selTransTbl[33]))(objcT118,selTransTbl[33],decl));
(objcT119=r,(*_imp(objcT119,selTransTbl[37]))(objcT119,selTransTbl[37],body));
return r;
}

#line 22 "msgxpr.h"
extern id  MesgExpr;

#line 644 "util.m"
id
mkmesgexpr(id receiver,id args)
{
id objcT120,objcT121,objcT122;

#line 647 "util.m"
id r=(objcT120=MesgExpr,(*_imp(objcT120,selTransTbl[12]))(objcT120,selTransTbl[12]));

(objcT121=r,(*_imp(objcT121,selTransTbl[38]))(objcT121,selTransTbl[38],receiver));
(objcT122=r,(*_imp(objcT122,selTransTbl[39]))(objcT122,selTransTbl[39],args));
return r;
}

#line 22 "namedecl.h"
extern id  NameDecl;

#line 654 "util.m"
id
mkdecl(id ident)
{
id objcT123,objcT124;

#line 657 "util.m"
id r=(objcT123=NameDecl,(*_imp(objcT123,selTransTbl[12]))(objcT123,selTransTbl[12]));

(objcT124=r,(*_imp(objcT124,selTransTbl[40]))(objcT124,selTransTbl[40],ident));
return r;
}

#line 22 "precdecl.h"
extern id  PrecDecl;

#line 663 "util.m"
id
mkprecdecl(id typequals,id decl)
{
id objcT125,objcT126,objcT127;

#line 666 "util.m"
id r=(objcT125=PrecDecl,(*_imp(objcT125,selTransTbl[12]))(objcT125,selTransTbl[12]));

if(typequals)
(objcT126=r,(*_imp(objcT126,selTransTbl[41]))(objcT126,selTransTbl[41],typequals));
if(decl)
(objcT127=r,(*_imp(objcT127,selTransTbl[36]))(objcT127,selTransTbl[36],decl));
return r;
}

#line 22 "arydecl.h"
extern id  ArrayDecl;

#line 675 "util.m"
id
mkarraydecl(id lhs,id ix)
{
id objcT128,objcT129,objcT130;

#line 678 "util.m"
id r=(objcT128=ArrayDecl,(*_imp(objcT128,selTransTbl[12]))(objcT128,selTransTbl[12]));

(objcT129=r,(*_imp(objcT129,selTransTbl[36]))(objcT129,selTransTbl[36],lhs));
(objcT130=r,(*_imp(objcT130,selTransTbl[13]))(objcT130,selTransTbl[13],ix));
return r;
}

#line 22 "fundecl.h"
extern id  FunctionDecl;

#line 685 "util.m"
id
mkfundecl(id lhs,id args)
{
id objcT131,objcT132,objcT133;

#line 688 "util.m"
id r=(objcT131=FunctionDecl,(*_imp(objcT131,selTransTbl[12]))(objcT131,selTransTbl[12]));

(objcT132=r,(*_imp(objcT132,selTransTbl[36]))(objcT132,selTransTbl[36],lhs));
(objcT133=r,(*_imp(objcT133,selTransTbl[42]))(objcT133,selTransTbl[42],args));
return r;
}

#line 22 "pfixdecl.h"
extern id  PostfixDecl;

#line 695 "util.m"
id
mkprefixdecl(id lhs,id rhs)
{
id objcT134,objcT135,objcT136;

#line 698 "util.m"
id r=(objcT134=PostfixDecl,(*_imp(objcT134,selTransTbl[12]))(objcT134,selTransTbl[12]));

(objcT135=r,(*_imp(objcT135,selTransTbl[43]))(objcT135,selTransTbl[43],lhs));
(objcT136=r,(*_imp(objcT136,selTransTbl[36]))(objcT136,selTransTbl[36],rhs));
return r;
}

id
mkpostfixdecl(id lhs,id rhs)
{
id objcT137,objcT138,objcT139;

#line 708 "util.m"
id r=(objcT137=PostfixDecl,(*_imp(objcT137,selTransTbl[12]))(objcT137,selTransTbl[12]));

(objcT138=r,(*_imp(objcT138,selTransTbl[36]))(objcT138,selTransTbl[36],lhs));
(objcT139=r,(*_imp(objcT139,selTransTbl[44]))(objcT139,selTransTbl[44],rhs));
return r;
}

#line 22 "pointer.h"
extern id  Pointer;

#line 715 "util.m"
id
mkpointer(id specs,id pointer)
{
id objcT140,objcT141,objcT142;

#line 718 "util.m"
id r=(objcT140=Pointer,(*_imp(objcT140,selTransTbl[12]))(objcT140,selTransTbl[12]));

if(specs)
(objcT141=r,(*_imp(objcT141,selTransTbl[30]))(objcT141,selTransTbl[30],specs));
if(pointer)
(objcT142=r,(*_imp(objcT142,selTransTbl[45]))(objcT142,selTransTbl[45],pointer));
return r;
}

#line 22 "bflddecl.h"
extern id  BitfieldDecl;

#line 727 "util.m"
id
mkbitfielddecl(id decl,id expr)
{
id objcT143,objcT144,objcT145;

#line 730 "util.m"
id r=(objcT143=BitfieldDecl,(*_imp(objcT143,selTransTbl[12]))(objcT143,selTransTbl[12]));

(objcT144=r,(*_imp(objcT144,selTransTbl[36]))(objcT144,selTransTbl[36],decl));
(objcT145=r,(*_imp(objcT145,selTransTbl[13]))(objcT145,selTransTbl[13],expr));
return r;
}

#line 22 "stardecl.h"
extern id  StarDecl;

#line 737 "util.m"
id
mkstardecl(id pointer,id decl)
{
id objcT146,objcT147,objcT148;

#line 740 "util.m"
id r=(objcT146=StarDecl,(*_imp(objcT146,selTransTbl[12]))(objcT146,selTransTbl[12]));

(objcT147=r,(*_imp(objcT147,selTransTbl[45]))(objcT147,selTransTbl[45],pointer));
(objcT148=r,(*_imp(objcT148,selTransTbl[36]))(objcT148,selTransTbl[36],decl));
return r;
}

#line 22 "gasmop.h"
extern id  GnuAsmOp;

#line 747 "util.m"
id
mkasmop(id aList,id expr)
{
id objcT149,objcT150,objcT151;

#line 750 "util.m"
id r=(objcT149=GnuAsmOp,(*_imp(objcT149,selTransTbl[12]))(objcT149,selTransTbl[12]));

(objcT150=r,(*_imp(objcT150,selTransTbl[46]))(objcT150,selTransTbl[46],aList));
(objcT151=r,(*_imp(objcT151,selTransTbl[13]))(objcT151,selTransTbl[13],expr));
return r;
}

#line 22 "gasmstmt.h"
extern id  GnuAsmStmt;

#line 757 "util.m"
id
mkasmstmt(id keyw,id typequal,id expr,id asmop1,id asmop2,id clobbers)
{
id objcT152,objcT153,objcT154,objcT155,objcT156;
id objcT157,objcT158;

#line 760 "util.m"
id r=(objcT152=GnuAsmStmt,(*_imp(objcT152,selTransTbl[12]))(objcT152,selTransTbl[12]));

(objcT153=r,(*_imp(objcT153,selTransTbl[17]))(objcT153,selTransTbl[17],keyw));
(objcT154=r,(*_imp(objcT154,selTransTbl[47]))(objcT154,selTransTbl[47],typequal));
(objcT155=r,(*_imp(objcT155,selTransTbl[13]))(objcT155,selTransTbl[13],expr));
(objcT156=r,(*_imp(objcT156,selTransTbl[48]))(objcT156,selTransTbl[48],asmop1));
(objcT157=r,(*_imp(objcT157,selTransTbl[49]))(objcT157,selTransTbl[49],asmop2));
(objcT158=r,(*_imp(objcT158,selTransTbl[50]))(objcT158,selTransTbl[50],clobbers));
return r;
}

#line 25 "compstmt.h"
extern id  CompoundStmt;

#line 771 "util.m"
id
mkcompstmt(id lbrace,id datadefs,id stmtlist,id rbrace)
{
id objcT159,objcT160,objcT161,objcT162,objcT163;

#line 774 "util.m"
id r=(objcT159=CompoundStmt,(*_imp(objcT159,selTransTbl[12]))(objcT159,selTransTbl[12]));

(objcT160=r,(*_imp(objcT160,selTransTbl[51]))(objcT160,selTransTbl[51],lbrace));
(objcT161=r,(*_imp(objcT161,selTransTbl[28]))(objcT161,selTransTbl[28],datadefs));
(objcT162=r,(*_imp(objcT162,selTransTbl[52]))(objcT162,selTransTbl[52],stmtlist));
(objcT163=r,(*_imp(objcT163,selTransTbl[53]))(objcT163,selTransTbl[53],rbrace));
return r;
}

#line 37 "../../include/objpak/ordcltn.h"
extern id  OrdCltn;

#line 783 "util.m"
id
mklist(id c,id s)
{
id objcT164,objcT165;

#line 786 "util.m"
if(c==(id)0)
c=(objcT164=OrdCltn,(*_imp(objcT164,selTransTbl[12]))(objcT164,selTransTbl[12]));
assert(s!=(id)0);
(objcT165=c,(*_imp(objcT165,selTransTbl[31]))(objcT165,selTransTbl[31],s));
return c;
}

id
mklist2(id c,id s,id t)
{
id objcT166,objcT167,objcT168;

#line 796 "util.m"
if(c==(id)0)
c=(objcT166=OrdCltn,(*_imp(objcT166,selTransTbl[12]))(objcT166,selTransTbl[12]));
assert(s!=(id)0);
(objcT167=c,(*_imp(objcT167,selTransTbl[31]))(objcT167,selTransTbl[31],s));
(objcT168=c,(*_imp(objcT168,selTransTbl[31]))(objcT168,selTransTbl[31],t));
return c;
}

id
atdefsadd(id c,id cls)
{
id objcT169,objcT170,objcT171;

#line 807 "util.m"
id scls=(objcT169=cls,(*_imp(objcT169,selTransTbl[54]))(objcT169,selTransTbl[54]));

if(scls)
atdefsadd(c,scls);
(objcT170=c,(*_imp(objcT170,selTransTbl[55]))(objcT170,selTransTbl[55],(objcT171=cls,(*_imp(objcT171,selTransTbl[56]))(objcT171,selTransTbl[56]))));
return c;
}

id
atdefsaddall(id c,id n)
{
id objcT172,objcT173;

#line 818 "util.m"
id cls;

if(c==(id)0)
c=(objcT172=OrdCltn,(*_imp(objcT172,selTransTbl[12]))(objcT172,selTransTbl[12]));
assert(n!=(id)0);
if((cls=(objcT173=trlunit,(*_imp(objcT173,selTransTbl[57]))(objcT173,selTransTbl[57],n)))){
atdefsadd(c,cls);
}else{
id objcT174;

#line 826 "util.m"
fatal("cannot find @defs of '%s'",(objcT174=n,(*(STR(*)(id,SEL))_imp(objcT174,selTransTbl[10]))(objcT174,selTransTbl[10])));
}
return c;
}

#line 24 "blockxpr.h"
extern id  BlockExpr;

#line 831 "util.m"
id
mkblockexpr(id lb,id parms,id datadefs,id stmts,id expr,id rb)
{
id objcT175,objcT176,objcT177,objcT178,objcT179;
id objcT180,objcT181;

#line 834 "util.m"
id r=(objcT175=BlockExpr,(*_imp(objcT175,selTransTbl[12]))(objcT175,selTransTbl[12]));

(objcT176=r,(*_imp(objcT176,selTransTbl[51]))(objcT176,selTransTbl[51],lb));
(objcT177=r,(*_imp(objcT177,selTransTbl[58]))(objcT177,selTransTbl[58],parms));
(objcT178=r,(*_imp(objcT178,selTransTbl[28]))(objcT178,selTransTbl[28],datadefs));
(objcT179=r,(*_imp(objcT179,selTransTbl[52]))(objcT179,selTransTbl[52],stmts));
(objcT180=r,(*_imp(objcT180,selTransTbl[13]))(objcT180,selTransTbl[13],expr));
(objcT181=r,(*_imp(objcT181,selTransTbl[53]))(objcT181,selTransTbl[53],rb));
return r;
}

#line 25 "classdef.h"
extern id  ClassDef;

#line 845 "util.m"
id
mkclassdef(id keyw,id name,id sname,id ivars,id cvars)
{
id objcT182,objcT183,objcT184,objcT194;

#line 848 "util.m"
id r;
BOOL intfkeyw=(keyw!=(id)0&&strstr((objcT182=keyw,(*(STR(*)(id,SEL))_imp(objcT182,selTransTbl[10]))(objcT182,selTransTbl[10])),"interface")!=NULL);
BOOL implkeyw=(keyw!=(id)0&&strstr((objcT183=keyw,(*(STR(*)(id,SEL))_imp(objcT183,selTransTbl[10]))(objcT183,selTransTbl[10])),"implementation")!=NULL);


if((r=(objcT184=trlunit,(*_imp(objcT184,selTransTbl[57]))(objcT184,selTransTbl[57],name)))){
if(intfkeyw){
id objcT185;

#line 855 "util.m"
fatal("multiple interfaces for class %s.",(objcT185=r,(*(char*(*)(id,SEL))_imp(objcT185,selTransTbl[59]))(objcT185,selTransTbl[59])));
}else{
id objcT186,objcT187,objcT188;

#line 857 "util.m"
if(sname)
(objcT186=r,(*_imp(objcT186,selTransTbl[60]))(objcT186,selTransTbl[60],sname));
if(ivars)
(objcT187=r,(*_imp(objcT187,selTransTbl[61]))(objcT187,selTransTbl[61],ivars));
if(cvars)
(objcT188=r,(*_imp(objcT188,selTransTbl[62]))(objcT188,selTransTbl[62],cvars));
}
}else{
id objcT189,objcT190,objcT191,objcT192,objcT193;

#line 865 "util.m"
r=(objcT189=ClassDef,(*_imp(objcT189,selTransTbl[12]))(objcT189,selTransTbl[12]));
(objcT190=r,(*_imp(objcT190,selTransTbl[63]))(objcT190,selTransTbl[63],name));
(objcT191=r,(*_imp(objcT191,selTransTbl[64]))(objcT191,selTransTbl[64],sname));
(objcT192=r,(*_imp(objcT192,selTransTbl[65]))(objcT192,selTransTbl[65],ivars));
(objcT193=r,(*_imp(objcT193,selTransTbl[66]))(objcT193,selTransTbl[66],cvars));
}

if(implkeyw)
(objcT194=r,(*_imp(objcT194,selTransTbl[67]))(objcT194,selTransTbl[67]));

if(curclassdef){
id objcT195;

#line 876 "util.m"
warn("definition of %s not properly ended.",(objcT195=curclassdef,(*(char*(*)(id,SEL))_imp(objcT195,selTransTbl[59]))(objcT195,selTransTbl[59])));
curclassdef=r;
}else{
curclassdef=r;
}

return r;
}

BOOL
lhsisid(id specs,id decl)
{
id objcT196,objcT197,objcT198,objcT199,objcT200;

#line 888 "util.m"
return(objcT196=specs,(*(unsigned(*)(id,SEL))_imp(objcT196,selTransTbl[68]))(objcT196,selTransTbl[68]))==1&&(objcT197=(objcT198=specs,(*(id(*)(id,SEL,unsigned))_imp(objcT198,selTransTbl[69]))(objcT198,selTransTbl[69],0)),(*(BOOL(*)(id,SEL))_imp(objcT197,selTransTbl[70]))(objcT197,selTransTbl[70]))&&(objcT199=decl,(*(BOOL(*)(id,SEL,id))_imp(objcT199,selTransTbl[71]))(objcT199,selTransTbl[71],(id)(objcT200=NameDecl,(*_imp(objcT200,selTransTbl[72]))(objcT200,selTransTbl[72]))));
}

void
datadefokblock(id datadef,id specs,id decl)
{
#line 897 "util.m"
if(specs){
okblock=lhsisid(specs,decl);
}else{
id objcT201;

#line 900 "util.m"
okblock=lhsisid((objcT201=datadef,(*_imp(objcT201,selTransTbl[73]))(objcT201,selTransTbl[73])),decl);
}
}

#line 22 "initdecl.h"
extern id  InitDecl;

#line 904 "util.m"
id
mkdatadef(id datadef,id specs,id decl,id initializer)
{
id objcT202,objcT203,objcT207;

#line 907 "util.m"
if(datadef==(id)0)
datadef=(objcT202=DataDef,(*_imp(objcT202,selTransTbl[12]))(objcT202,selTransTbl[12]));
if(specs)
(objcT203=datadef,(*_imp(objcT203,selTransTbl[30]))(objcT203,selTransTbl[30],specs));
if(initializer){
id objcT204,objcT205,objcT206;

#line 912 "util.m"
decl=(objcT204=(objcT205=(objcT206=InitDecl,(*_imp(objcT206,selTransTbl[12]))(objcT206,selTransTbl[12])),(*_imp(objcT205,selTransTbl[36]))(objcT205,selTransTbl[36],decl)),(*_imp(objcT204,selTransTbl[74]))(objcT204,selTransTbl[74],initializer));
}
(objcT207=datadef,(*_imp(objcT207,selTransTbl[31]))(objcT207,selTransTbl[31],decl));
return datadef;
}

id
mkencodeexpr(id name)
{
return(id)0;
}

#line 22 "enumsp.h"
extern id  EnumSpec;

#line 924 "util.m"
id
mkenumspec(id keyw,id name,id lb,id list,id rb)
{
id objcT208,objcT209,objcT210,objcT211,objcT212;
id objcT213;

#line 927 "util.m"
id r=(objcT208=EnumSpec,(*_imp(objcT208,selTransTbl[12]))(objcT208,selTransTbl[12]));

(objcT209=r,(*_imp(objcT209,selTransTbl[17]))(objcT209,selTransTbl[17],keyw));
(objcT210=r,(*_imp(objcT210,selTransTbl[75]))(objcT210,selTransTbl[75],name));
(objcT211=r,(*_imp(objcT211,selTransTbl[51]))(objcT211,selTransTbl[51],lb));
if(list)
(objcT212=r,(*_imp(objcT212,selTransTbl[76]))(objcT212,selTransTbl[76],list));
(objcT213=r,(*_imp(objcT213,selTransTbl[53]))(objcT213,selTransTbl[53],rb));
return r;
}

#line 22 "enumtor.h"
extern id  Enumerator;

#line 938 "util.m"
id
mkenumerator(id name,id value)
{
id objcT214,objcT215,objcT216;

#line 941 "util.m"
id r=(objcT214=Enumerator,(*_imp(objcT214,selTransTbl[12]))(objcT214,selTransTbl[12]));

(objcT215=r,(*_imp(objcT215,selTransTbl[75]))(objcT215,selTransTbl[75],name));
if(value)(objcT216=r,(*_imp(objcT216,selTransTbl[77]))(objcT216,selTransTbl[77],value));
return r;
}

#line 22 "gattrib.h"
extern id  GnuAttrib;

#line 948 "util.m"
id
mkgnuattrib(id anyword,id exprlist)
{
id objcT217,objcT218,objcT219;

#line 951 "util.m"
id r=(objcT217=GnuAttrib,(*_imp(objcT217,selTransTbl[12]))(objcT217,selTransTbl[12]));

(objcT218=r,(*_imp(objcT218,selTransTbl[78]))(objcT218,selTransTbl[78],anyword));
(objcT219=r,(*_imp(objcT219,selTransTbl[79]))(objcT219,selTransTbl[79],exprlist));
return r;
}

#line 22 "gatrdecl.h"
extern id  GnuAttribDecl;

#line 958 "util.m"
id
mkgnuattribdecl(id keyw,id list)
{
id objcT220,objcT221,objcT222;

#line 961 "util.m"
id r=(objcT220=GnuAttribDecl,(*_imp(objcT220,selTransTbl[12]))(objcT220,selTransTbl[12]));

(objcT221=r,(*_imp(objcT221,selTransTbl[17]))(objcT221,selTransTbl[17],keyw));
(objcT222=r,(*_imp(objcT222,selTransTbl[80]))(objcT222,selTransTbl[80],list));
return r;
}

#line 22 "listxpr.h"
extern id  ListExpr;

#line 968 "util.m"
id
mklistexpr(id lb,id x,id rb)
{
id objcT223,objcT224,objcT225,objcT226;

#line 971 "util.m"
id r=(objcT223=ListExpr,(*_imp(objcT223,selTransTbl[12]))(objcT223,selTransTbl[12]));

(objcT224=r,(*_imp(objcT224,selTransTbl[51]))(objcT224,selTransTbl[51],lb));
(objcT225=r,(*_imp(objcT225,selTransTbl[81]))(objcT225,selTransTbl[81],x));
(objcT226=r,(*_imp(objcT226,selTransTbl[53]))(objcT226,selTransTbl[53],rb));
return r;
}

#line 33 "type.h"
extern id  Type;

#line 979 "util.m"
id
mktypename(id specs,id decl)
{
id objcT227,objcT228,objcT229;

#line 982 "util.m"
id r=(objcT227=Type,(*_imp(objcT227,selTransTbl[12]))(objcT227,selTransTbl[12]));

(objcT228=r,(*_imp(objcT228,selTransTbl[30]))(objcT228,selTransTbl[30],specs));
(objcT229=r,(*_imp(objcT229,selTransTbl[36]))(objcT229,selTransTbl[36],decl));
return r;
}

#line 22 "compdef.h"
extern id  ComponentDef;

#line 989 "util.m"
id
mkcomponentdef(id cdef,id specs,id decl)
{
id objcT230,objcT231,objcT232;

#line 992 "util.m"
if(cdef==(id)0)
cdef=(objcT230=ComponentDef,(*_imp(objcT230,selTransTbl[12]))(objcT230,selTransTbl[12]));
if(specs)
(objcT231=cdef,(*_imp(objcT231,selTransTbl[30]))(objcT231,selTransTbl[30],specs));
(objcT232=cdef,(*_imp(objcT232,selTransTbl[31]))(objcT232,selTransTbl[31],decl));
return cdef;
}

#line 24 "structsp.h"
extern id  StructSpec;

#line 1000 "util.m"
id
mkstructspec(id keyw,id name,id lb,id defs,id rb)
{
id objcT233,objcT234,objcT235,objcT236,objcT237;
id objcT238;

#line 1003 "util.m"
id r=(objcT233=StructSpec,(*_imp(objcT233,selTransTbl[12]))(objcT233,selTransTbl[12]));

(objcT234=r,(*_imp(objcT234,selTransTbl[17]))(objcT234,selTransTbl[17],keyw));
(objcT235=r,(*_imp(objcT235,selTransTbl[75]))(objcT235,selTransTbl[75],name));
(objcT236=r,(*_imp(objcT236,selTransTbl[51]))(objcT236,selTransTbl[51],lb));
if(defs)
(objcT237=r,(*_imp(objcT237,selTransTbl[82]))(objcT237,selTransTbl[82],defs));
(objcT238=r,(*_imp(objcT238,selTransTbl[53]))(objcT238,selTransTbl[53],rb));
return r;
}

#line 22 "keywxpr.h"
extern id  KeywExpr;

#line 1014 "util.m"
id
mkkeywarg(id sel,id arg)
{
id objcT239,objcT240,objcT241;

#line 1017 "util.m"
id r=(objcT239=KeywExpr,(*_imp(objcT239,selTransTbl[12]))(objcT239,selTransTbl[12]));

(objcT240=r,(*_imp(objcT240,selTransTbl[17]))(objcT240,selTransTbl[17],sel));
(objcT241=r,(*_imp(objcT241,selTransTbl[83]))(objcT241,selTransTbl[83],arg));
return r;
}

#line 22 "keywdecl.h"
extern id  KeywDecl;

#line 1024 "util.m"
id
mkkeywdecl(id sel,id cast,id arg)
{
id objcT242,objcT243,objcT244,objcT245;

#line 1027 "util.m"
id r=(objcT242=KeywDecl,(*_imp(objcT242,selTransTbl[12]))(objcT242,selTransTbl[12]));

(objcT243=r,(*_imp(objcT243,selTransTbl[17]))(objcT243,selTransTbl[17],sel));
(objcT244=r,(*_imp(objcT244,selTransTbl[22]))(objcT244,selTransTbl[22],cast));
(objcT245=r,(*_imp(objcT245,selTransTbl[83]))(objcT245,selTransTbl[83],arg));
return r;
}

#line 22 "method.h"
extern id  Method;

#line 1035 "util.m"
id
mkmethproto(id cast,id usel,id ksel,BOOL varargs)
{
id objcT246,objcT247,objcT248,objcT249,objcT250;

#line 1038 "util.m"
id r=(objcT246=Method,(*_imp(objcT246,selTransTbl[12]))(objcT246,selTransTbl[12]));

(objcT247=r,(*_imp(objcT247,selTransTbl[84]))(objcT247,selTransTbl[84],cast));
(objcT248=r,(*_imp(objcT248,selTransTbl[85]))(objcT248,selTransTbl[85],usel));
(objcT249=r,(*_imp(objcT249,selTransTbl[86]))(objcT249,selTransTbl[86],ksel));
(objcT250=r,(*(id(*)(id,SEL,BOOL))_imp(objcT250,selTransTbl[87]))(objcT250,selTransTbl[87],varargs));
return r;
}

#line 22 "identxpr.h"
extern id  IdentifierExpr;

#line 1047 "util.m"
id
mkidentexpr(id name)
{
id objcT251,objcT252;

#line 1050 "util.m"
id r=(objcT251=IdentifierExpr,(*_imp(objcT251,selTransTbl[12]))(objcT251,selTransTbl[12]));

(objcT252=r,(*_imp(objcT252,selTransTbl[40]))(objcT252,selTransTbl[40],name));
return r;
}

#line 22 "constxpr.h"
extern id  ConstantExpr;

#line 1056 "util.m"
id
mkconstexpr(id name,id schain)
{
id objcT253,objcT254,objcT255;

#line 1059 "util.m"
id r=(objcT253=ConstantExpr,(*_imp(objcT253,selTransTbl[12]))(objcT253,selTransTbl[12]));

if(name)
(objcT254=r,(*_imp(objcT254,selTransTbl[40]))(objcT254,selTransTbl[40],name));
if(schain)
(objcT255=r,(*_imp(objcT255,selTransTbl[46]))(objcT255,selTransTbl[46],schain));
return r;
}

#line 22 "precxpr.h"
extern id  PrecExpr;

#line 1068 "util.m"
id
mkprecexpr(id expr)
{
id objcT256,objcT257;

#line 1071 "util.m"
id r=(objcT256=PrecExpr,(*_imp(objcT256,selTransTbl[12]))(objcT256,selTransTbl[12]));

(objcT257=r,(*_imp(objcT257,selTransTbl[13]))(objcT257,selTransTbl[13],expr));
return r;
}

#line 22 "arrowxpr.h"
extern id  ArrowExpr;

#line 1077 "util.m"
id
mkarrowexpr(id array,id ix)
{
id objcT258,objcT259,objcT260;

#line 1080 "util.m"
id r=(objcT258=ArrowExpr,(*_imp(objcT258,selTransTbl[12]))(objcT258,selTransTbl[12]));

(objcT259=r,(*_imp(objcT259,selTransTbl[23]))(objcT259,selTransTbl[23],array));
(objcT260=r,(*_imp(objcT260,selTransTbl[24]))(objcT260,selTransTbl[24],ix));
return r;
}

#line 22 "dotxpr.h"
extern id  DotExpr;

#line 1087 "util.m"
id
mkdotexpr(id array,id ix)
{
id objcT261,objcT262,objcT263;

#line 1090 "util.m"
id r=(objcT261=DotExpr,(*_imp(objcT261,selTransTbl[12]))(objcT261,selTransTbl[12]));

(objcT262=r,(*_imp(objcT262,selTransTbl[23]))(objcT262,selTransTbl[23],array));
(objcT263=r,(*_imp(objcT263,selTransTbl[24]))(objcT263,selTransTbl[24],ix));
return r;
}

#line 22 "indexxpr.h"
extern id  IndexExpr;

#line 1097 "util.m"
id
mkindexexpr(id array,id ix)
{
id objcT264,objcT265,objcT266;

#line 1100 "util.m"
id r=(objcT264=IndexExpr,(*_imp(objcT264,selTransTbl[12]))(objcT264,selTransTbl[12]));

(objcT265=r,(*_imp(objcT265,selTransTbl[23]))(objcT265,selTransTbl[23],array));
(objcT266=r,(*_imp(objcT266,selTransTbl[24]))(objcT266,selTransTbl[24],ix));
return r;
}

#line 22 "pfixxpr.h"
extern id  PostfixExpr;

#line 1107 "util.m"
id
mkpostfixexpr(id expr,id pf)
{
id objcT267,objcT268,objcT269,objcT270;

#line 1110 "util.m"
id r=(objcT267=PostfixExpr,(*_imp(objcT267,selTransTbl[12]))(objcT267,selTransTbl[12]));

(objcT268=r,(*_imp(objcT268,selTransTbl[13]))(objcT268,selTransTbl[13],expr));
(objcT269=r,(*(id(*)(id,SEL,STR))_imp(objcT269,selTransTbl[25]))(objcT269,selTransTbl[25],(objcT270=pf,(*(STR(*)(id,SEL))_imp(objcT270,selTransTbl[88]))(objcT270,selTransTbl[88]))));
return r;
}

#line 22 "parmdef.h"
extern id  ParameterDef;

#line 1117 "util.m"
id
mkparmdef(id parmdef,id specs,id decl)
{
id objcT271,objcT272,objcT273;

#line 1120 "util.m"
id r=(objcT271=ParameterDef,(*_imp(objcT271,selTransTbl[12]))(objcT271,selTransTbl[12]));

if(specs)
(objcT272=r,(*_imp(objcT272,selTransTbl[30]))(objcT272,selTransTbl[30],specs));
(objcT273=r,(*_imp(objcT273,selTransTbl[36]))(objcT273,selTransTbl[36],decl));
return r;
}

#line 22 "parmlist.h"
extern id  ParameterList;

#line 1128 "util.m"
id
mkparmdeflist(id idents,id parmdefs,BOOL varargs)
{
id objcT274,objcT275,objcT276,objcT277;

#line 1131 "util.m"
id r=(objcT274=ParameterList,(*_imp(objcT274,selTransTbl[12]))(objcT274,selTransTbl[12]));

if(idents)
(objcT275=r,(*_imp(objcT275,selTransTbl[89]))(objcT275,selTransTbl[89],idents));
if(parmdefs)
(objcT276=r,(*_imp(objcT276,selTransTbl[90]))(objcT276,selTransTbl[90],parmdefs));
(objcT277=r,(*(id(*)(id,SEL,BOOL))_imp(objcT277,selTransTbl[87]))(objcT277,selTransTbl[87],varargs));
return r;
}

#line 22 "selector.h"
extern id  Selector;

#line 1141 "util.m"
id
mkselarg(id sel,id usel,int ncols)
{
if(sel==(id)0){
id objcT278,objcT279;

#line 1145 "util.m"
assert(ncols==0&&usel!=(id)0);
sel=(objcT278=Selector,(*(id(*)(id,SEL,STR))_imp(objcT278,selTransTbl[9]))(objcT278,selTransTbl[9],(objcT279=usel,(*(STR(*)(id,SEL))_imp(objcT279,selTransTbl[88]))(objcT279,selTransTbl[88]))));
}else{
id objcT280,objcT281;

#line 1148 "util.m"
if(usel)
(objcT280=sel,(*_imp(objcT280,selTransTbl[31]))(objcT280,selTransTbl[31],usel));
while(ncols--)
(objcT281=sel,(*_imp(objcT281,selTransTbl[91]))(objcT281,selTransTbl[91]));
}
return sel;
}

#line 22 "selxpr.h"
extern id  SelectorExpr;

#line 1156 "util.m"
id
mkselectorexpr(id expr)
{
id objcT282,objcT283;

#line 1159 "util.m"
id r=(objcT282=SelectorExpr,(*_imp(objcT282,selTransTbl[12]))(objcT282,selTransTbl[12]));

(objcT283=r,(*_imp(objcT283,selTransTbl[92]))(objcT283,selTransTbl[92],expr));
return r;
}

id
mkfilesupermsg(id sel,id arg)
{
id objcT284,objcT285,objcT286,objcT287;

#line 1168 "util.m"
id ksel,m;

m=(objcT284=MesgExpr,(*_imp(objcT284,selTransTbl[12]))(objcT284,selTransTbl[12]));
(objcT285=m,(*_imp(objcT285,selTransTbl[38]))(objcT285,selTransTbl[38],e_super));
ksel=(objcT286=OrdCltn,(*_imp(objcT286,selTransTbl[31]))(objcT286,selTransTbl[31],mkkeywarg(sel,arg)));
(objcT287=m,(*_imp(objcT287,selTransTbl[39]))(objcT287,selTransTbl[39],mkmethproto((id)0,(id)0,ksel,(BOOL)0)));
return mkexprstmtx(m);
}

id
mkfilemsg(id sel,id name)
{
id objcT288,objcT289,objcT290,objcT291,objcT292;

#line 1180 "util.m"
id ksel,m;

m=(objcT288=MesgExpr,(*_imp(objcT288,selTransTbl[12]))(objcT288,selTransTbl[12]));
(objcT289=m,(*_imp(objcT289,selTransTbl[38]))(objcT289,selTransTbl[38],e_aFiler));
ksel=(objcT290=OrdCltn,(*_imp(objcT290,selTransTbl[31]))(objcT290,selTransTbl[31],mkkeywarg(sel,mkaddressof(mkidentexpr(name)))));
(objcT291=ksel,(*_imp(objcT291,selTransTbl[31]))(objcT291,selTransTbl[31],mkkeywarg(s_type,e_ft_id)));
(objcT292=m,(*_imp(objcT292,selTransTbl[39]))(objcT292,selTransTbl[39],mkmethproto((id)0,(id)0,ksel,(BOOL)0)));
return mkexprstmtx(m);
}

id
mkfileinoutmeth(id ssel,id fsel,id ivarnames,id ivartypes)
{
id objcT293,objcT294,objcT299,objcT300;

#line 1193 "util.m"
id d,b,r;

r=(objcT293=MethodDef,(*_imp(objcT293,selTransTbl[12]))(objcT293,selTransTbl[12]));
if((d=(objcT294=Method,(*_imp(objcT294,selTransTbl[12]))(objcT294,selTransTbl[12])))){
id objcT295,objcT296,objcT297,objcT298;

#line 1197 "util.m"
id ksel=(objcT295=OrdCltn,(*_imp(objcT295,selTransTbl[31]))(objcT295,selTransTbl[31],mkkeywdecl(ssel,(id)0,s_aFiler)));

(objcT296=d,(*_imp(objcT296,selTransTbl[86]))(objcT296,selTransTbl[86],ksel));
(objcT297=d,(*(id(*)(id,SEL,BOOL))_imp(objcT297,selTransTbl[93]))(objcT297,selTransTbl[93],(BOOL)0));
(objcT298=r,(*_imp(objcT298,selTransTbl[33]))(objcT298,selTransTbl[33],d));
}
(objcT299=r,(*_imp(objcT299,selTransTbl[34]))(objcT299,selTransTbl[34]));
if((b=(objcT300=CompoundStmt,(*_imp(objcT300,selTransTbl[12]))(objcT300,selTransTbl[12])))){
id objcT301,objcT302,objcT303,objcT308,objcT309;
id objcT310,objcT311;

#line 1205 "util.m"
int i,n;
id s=(objcT301=OrdCltn,(*_imp(objcT301,selTransTbl[12]))(objcT301,selTransTbl[12]));

(objcT302=s,(*_imp(objcT302,selTransTbl[31]))(objcT302,selTransTbl[31],mkfilesupermsg(ssel,e_aFiler)));
for(i=0,n=(objcT303=ivartypes,(*(unsigned(*)(id,SEL))_imp(objcT303,selTransTbl[68]))(objcT303,selTransTbl[68]));i<n;i++){
id objcT304,objcT305;

#line 1210 "util.m"
if((objcT304=(objcT305=ivartypes,(*(id(*)(id,SEL,unsigned))_imp(objcT305,selTransTbl[69]))(objcT305,selTransTbl[69],i)),(*(BOOL(*)(id,SEL))_imp(objcT304,selTransTbl[70]))(objcT304,selTransTbl[70]))){
id objcT306,objcT307;

#line 1211 "util.m"
(objcT306=s,(*_imp(objcT306,selTransTbl[31]))(objcT306,selTransTbl[31],mkfilemsg(fsel,(objcT307=ivarnames,(*(id(*)(id,SEL,unsigned))_imp(objcT307,selTransTbl[69]))(objcT307,selTransTbl[69],i)))));
}
}
(objcT308=s,(*_imp(objcT308,selTransTbl[31]))(objcT308,selTransTbl[31],mkreturnx((objcT309=e_self,(*_imp(objcT309,selTransTbl[94]))(objcT309,selTransTbl[94])))));
(objcT310=b,(*_imp(objcT310,selTransTbl[52]))(objcT310,selTransTbl[52],s));
(objcT311=r,(*_imp(objcT311,selTransTbl[37]))(objcT311,selTransTbl[37],b));
}
return r;
}

id
mkfileinmeth(id classdef,id ivarnames,id ivartypes)
{
return mkfileinoutmeth(s_fileInIdsFrom,s_fileIn,ivarnames,ivartypes);
}

id
mkfileoutmeth(id classdef,id ivarnames,id ivartypes)
{
return mkfileinoutmeth(s_fileOutIdsFor,s_fileOut,ivarnames,ivartypes);
}

id
mkrefsupermsg(id sel)
{
id objcT312,objcT313,objcT314;

#line 1236 "util.m"
id usel,m;

m=(objcT312=MesgExpr,(*_imp(objcT312,selTransTbl[12]))(objcT312,selTransTbl[12]));
(objcT313=m,(*_imp(objcT313,selTransTbl[38]))(objcT313,selTransTbl[38],e_super));
usel=sel;
(objcT314=m,(*_imp(objcT314,selTransTbl[39]))(objcT314,selTransTbl[39],mkmethproto((id)0,usel,(id)0,(BOOL)0)));
return mkexprstmtx(m);
}

id
mkrefmeth(id classdef,id ivarnames,id ivartypes,id ssel,id sfun)
{
id objcT315,objcT316,objcT317,objcT318,objcT322;
id objcT323;

#line 1248 "util.m"
id d,b,r;
id usel=(objcT315=Selector,(*(id(*)(id,SEL,STR))_imp(objcT315,selTransTbl[9]))(objcT315,selTransTbl[9],(objcT316=ssel,(*(STR(*)(id,SEL))_imp(objcT316,selTransTbl[88]))(objcT316,selTransTbl[88]))));

r=(objcT317=MethodDef,(*_imp(objcT317,selTransTbl[12]))(objcT317,selTransTbl[12]));
if((d=(objcT318=Method,(*_imp(objcT318,selTransTbl[12]))(objcT318,selTransTbl[12])))){
id objcT319,objcT320,objcT321;

#line 1253 "util.m"
(objcT319=d,(*_imp(objcT319,selTransTbl[85]))(objcT319,selTransTbl[85],usel));
(objcT320=d,(*(id(*)(id,SEL,BOOL))_imp(objcT320,selTransTbl[93]))(objcT320,selTransTbl[93],(BOOL)0));
(objcT321=r,(*_imp(objcT321,selTransTbl[33]))(objcT321,selTransTbl[33],d));
}
(objcT322=r,(*_imp(objcT322,selTransTbl[34]))(objcT322,selTransTbl[34]));
if((b=(objcT323=CompoundStmt,(*_imp(objcT323,selTransTbl[12]))(objcT323,selTransTbl[12])))){
id objcT324,objcT325,objcT326,objcT331,objcT332;
id objcT333,objcT334;

#line 1259 "util.m"
int i,n;
id s=(objcT324=OrdCltn,(*_imp(objcT324,selTransTbl[12]))(objcT324,selTransTbl[12]));
id f=mkidentexpr(sfun);

(objcT325=s,(*_imp(objcT325,selTransTbl[31]))(objcT325,selTransTbl[31],mkrefsupermsg(usel)));
for(i=0,n=(objcT326=ivartypes,(*(unsigned(*)(id,SEL))_imp(objcT326,selTransTbl[68]))(objcT326,selTransTbl[68]));i<n;i++){
id objcT327,objcT328;

#line 1265 "util.m"
if((objcT327=(objcT328=ivartypes,(*(id(*)(id,SEL,unsigned))_imp(objcT328,selTransTbl[69]))(objcT328,selTransTbl[69],i)),(*(BOOL(*)(id,SEL))_imp(objcT327,selTransTbl[70]))(objcT327,selTransTbl[70]))){
id objcT329,objcT330;

#line 1266 "util.m"
id e=mkidentexpr((objcT329=ivarnames,(*(id(*)(id,SEL,unsigned))_imp(objcT329,selTransTbl[69]))(objcT329,selTransTbl[69],i)));

(objcT330=s,(*_imp(objcT330,selTransTbl[31]))(objcT330,selTransTbl[31],mkexprstmtx(mkassignexpr(e,"=",mkfuncall(f,mklist((id)0,e))))));
}
}
(objcT331=s,(*_imp(objcT331,selTransTbl[31]))(objcT331,selTransTbl[31],mkreturnx((objcT332=e_nil,(*_imp(objcT332,selTransTbl[94]))(objcT332,selTransTbl[94])))));
(objcT333=b,(*_imp(objcT333,selTransTbl[52]))(objcT333,selTransTbl[52],s));
(objcT334=r,(*_imp(objcT334,selTransTbl[37]))(objcT334,selTransTbl[37],b));
}
return r;
}

id
mkincrefsmeth(id classdef,id ivarnames,id ivartypes)
{
return mkrefmeth(classdef,ivarnames,ivartypes,s_increfs,s_idincref);
}

id
mkdecrefsmeth(id classdef,id ivarnames,id ivartypes)
{
return mkrefmeth(classdef,ivarnames,ivartypes,s_decrefs,s_iddecref);
}
static char *_selTransTbl[] ={
"synth",
"gen",
"st80",
"numidivars",
"synthfilermethods",
"synthrefcntmethods",
"isimpl",
"warnimplnotfound",
"chars:count:",
"str:",
"str",
"str:lineno:filename:",
"new",
"expr:",
"forcenewline:",
"label:",
"stmt:",
"keyw:",
"ekeyw:",
"estmt:",
"wkeyw:",
"begin:cond:step:",
"cast:",
"lhs:",
"rhs:",
"op:",
"funname:",
"funargs:",
"datadefs:",
"compound:",
"specs:",
"add:",
"factory:",
"method:",
"prototype",
"datadefspecs:",
"decl:",
"body:",
"receiver:",
"msg:",
"identifier:",
"typequals:",
"args:",
"prefix:",
"postfix:",
"pointer:",
"stringchain:",
"typequal:",
"asmop1:",
"asmop2:",
"clobbers:",
"lbrace:",
"stmts:",
"rbrace:",
"superclassdef",
"addAll:",
"ivars",
"lookupclass:",
"parms:",
"classname",
"checksupername:",
"checkivars:",
"checkcvars:",
"classname:",
"supername:",
"ivars:",
"cvars:",
"forceimpl",
"size",
"at:",
"isid",
"isKindOf:",
"class",
"specs",
"initializer:",
"name:",
"enumtors:",
"value:",
"anyword:",
"exprlist:",
"attribs:",
"exprs:",
"defs:",
"arg:",
"restype:",
"unarysel:",
"keywsel:",
"varargs:",
"strCopy",
"idents:",
"parmdefs:",
"addcol",
"selector:",
"canforward:",
"copy",
0
};
struct modDescriptor util_modDesc = {
  "util",
  "objc2.3.1",
  0L,
  0,
  0,
  0,
  95,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_util(void)
{
  selTransTbl = _selTransTbl;
  return &util_modDesc;
}
int _OBJCPOSTLINK_util = 1;


