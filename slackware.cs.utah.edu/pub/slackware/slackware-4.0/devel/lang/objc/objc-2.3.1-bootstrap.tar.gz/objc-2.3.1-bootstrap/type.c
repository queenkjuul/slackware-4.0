#line 1 "type.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_type(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor type_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 31 "../../include/objpak/ordcltn.h"
typedef struct objcol{
int count;
int capacity;
id*ptr;
}*objcol_t;
#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 22 "structsp.h"
extern id curstruct;
#line 39 "type.m"
id t_unknown;
id t_void;
id t_char;
id t_bool;
id t_int;
id t_long;
id t_double;
id t_str;
id t_sel;
id t_id;
#line 33 "type.h"
struct Type_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 35 "type.h"
id specs,decl;
BOOL isstatic;
BOOL isextern;
BOOL haslistinit;};

#line 33 "type.h"
extern id  Type;

#line 33 "type.h"
extern struct _SHARED _Type;
extern struct _SHARED __Type;


#line 52 "type.m"
static id c_Type_commontypes(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT0,objcT1,objcT2,objcT3,objcT4;
id objcT5,objcT6,objcT7,objcT8,objcT9;
id objcT10,objcT11,objcT12,objcT13,objcT14;
id objcT15,objcT16,objcT17,objcT18;

#line 54 "type.m"
t_unknown=(objcT0=Type,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
t_void=(objcT1=(objcT2=Type,(*_imp(objcT2,selTransTbl[0]))(objcT2,selTransTbl[0])),(*_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1],s_void));
t_char=(objcT3=(objcT4=Type,(*_imp(objcT4,selTransTbl[0]))(objcT4,selTransTbl[0])),(*_imp(objcT3,selTransTbl[1]))(objcT3,selTransTbl[1],s_char));
t_bool=(objcT5=(objcT6=Type,(*_imp(objcT6,selTransTbl[0]))(objcT6,selTransTbl[0])),(*_imp(objcT5,selTransTbl[1]))(objcT5,selTransTbl[1],s_bool));
t_int=(objcT7=(objcT8=Type,(*_imp(objcT8,selTransTbl[0]))(objcT8,selTransTbl[0])),(*_imp(objcT7,selTransTbl[1]))(objcT7,selTransTbl[1],s_int));
t_long=(objcT9=(objcT10=Type,(*_imp(objcT10,selTransTbl[0]))(objcT10,selTransTbl[0])),(*_imp(objcT9,selTransTbl[1]))(objcT9,selTransTbl[1],s_long));
t_double=(objcT11=(objcT12=Type,(*_imp(objcT12,selTransTbl[0]))(objcT12,selTransTbl[0])),(*_imp(objcT11,selTransTbl[1]))(objcT11,selTransTbl[1],s_double));
t_str=(objcT13=(objcT14=Type,(*_imp(objcT14,selTransTbl[0]))(objcT14,selTransTbl[0])),(*_imp(objcT13,selTransTbl[1]))(objcT13,selTransTbl[1],s_str));
t_sel=(objcT15=(objcT16=Type,(*_imp(objcT16,selTransTbl[0]))(objcT16,selTransTbl[0])),(*_imp(objcT15,selTransTbl[1]))(objcT15,selTransTbl[1],s_sel));
t_id=(objcT17=(objcT18=Type,(*_imp(objcT18,selTransTbl[0]))(objcT18,selTransTbl[0])),(*_imp(objcT17,selTransTbl[1]))(objcT17,selTransTbl[1],s_id));
return(id)self;
}

static id i_Type_specs(struct Type_PRIVATE *self,SEL _cmd)
{
return self->specs;
}

static id i_Type_decl(struct Type_PRIVATE *self,SEL _cmd)
{
return self->decl;
}

#line 37 "../../include/objpak/ordcltn.h"
extern id  OrdCltn;

#line 77 "type.m"
static id i_Type_abstrspecs_(struct Type_PRIVATE *self,SEL _cmd,id aList)
{
if(aList){self->
specs=aList;
}else{
id objcT19,objcT20;
self->
#line 82 "type.m"
specs=(objcT19=OrdCltn,(*_imp(objcT19,selTransTbl[0]))(objcT19,selTransTbl[0]));
(objcT20=self->specs,(*_imp(objcT20,selTransTbl[2]))(objcT20,selTransTbl[2],s_int));
}
return(id)self;
}

#line 58 "symbol.h"
extern id  Symbol;

#line 24 "structsp.h"
extern id  StructSpec;

#line 22 "enumsp.h"
extern id  EnumSpec;

#line 88 "type.m"
static id i_Type_checkspec_(struct Type_PRIVATE *self,SEL _cmd,id s)
{
id objcT21,objcT22,objcT23,objcT24,objcT25;
id objcT26,objcT27;

#line 90 "type.m"
if((objcT21=s,(*(BOOL(*)(id,SEL,id))_imp(objcT21,selTransTbl[3]))(objcT21,selTransTbl[3],(id)(objcT22=Symbol,(*_imp(objcT22,selTransTbl[4]))(objcT22,selTransTbl[4])))))
return(id)self;
if((objcT23=s,(*(BOOL(*)(id,SEL,id))_imp(objcT23,selTransTbl[3]))(objcT23,selTransTbl[3],(id)(objcT24=StructSpec,(*_imp(objcT24,selTransTbl[4]))(objcT24,selTransTbl[4])))))
return(id)self;
if((objcT25=s,(*(BOOL(*)(id,SEL,id))_imp(objcT25,selTransTbl[3]))(objcT25,selTransTbl[3],(id)(objcT26=EnumSpec,(*_imp(objcT26,selTransTbl[4]))(objcT26,selTransTbl[4])))))
return(id)self;
fprintf(stderr,"%s\n",(objcT27=s,(*(STR(*)(id,SEL))_imp(objcT27,selTransTbl[5]))(objcT27,selTransTbl[5])));
return(id)0;
}

static id i_Type_specs_(struct Type_PRIVATE *self,SEL _cmd,id aList)
{
if(aList){
id objcT28,objcT29,objcT34;

#line 103 "type.m"
int i,n;
id typespecs=(objcT28=OrdCltn,(*_imp(objcT28,selTransTbl[0]))(objcT28,selTransTbl[0]));

for(i=0,n=(objcT29=aList,(*(unsigned(*)(id,SEL))_imp(objcT29,selTransTbl[6]))(objcT29,selTransTbl[6]));i<n;i++){
id objcT30,objcT31,objcT32,objcT33;

#line 107 "type.m"
id s=(objcT30=aList,(*(id(*)(id,SEL,unsigned))_imp(objcT30,selTransTbl[7]))(objcT30,selTransTbl[7],i));

assert((objcT31=(id)self,(*_imp(objcT31,selTransTbl[8]))(objcT31,selTransTbl[8],s)));

if( !(objcT32=s,(*(BOOL(*)(id,SEL))_imp(objcT32,selTransTbl[9]))(objcT32,selTransTbl[9])))
(objcT33=typespecs,(*_imp(objcT33,selTransTbl[2]))(objcT33,selTransTbl[2],s));
}
return(objcT34=(id)self,(*_imp(objcT34,selTransTbl[10]))(objcT34,selTransTbl[10],typespecs));
}else{
id objcT35;

#line 116 "type.m"
return(objcT35=(id)self,(*_imp(objcT35,selTransTbl[1]))(objcT35,selTransTbl[1],s_int));
}
}

static id i_Type_addspec_(struct Type_PRIVATE *self,SEL _cmd,id aSpec)
{
id objcT36;

#line 122 "type.m"
if( !self->specs)self->
specs=(objcT36=OrdCltn,(*_imp(objcT36,selTransTbl[0]))(objcT36,selTransTbl[0]));
if(aSpec){
id objcT37,objcT38,objcT39;

#line 125 "type.m"
assert((objcT37=(id)self,(*_imp(objcT37,selTransTbl[8]))(objcT37,selTransTbl[8],aSpec)));
assert( !(objcT38=aSpec,(*(BOOL(*)(id,SEL))_imp(objcT38,selTransTbl[9]))(objcT38,selTransTbl[9])));
(objcT39=self->specs,(*_imp(objcT39,selTransTbl[2]))(objcT39,selTransTbl[2],aSpec));
}
return(id)self;
}

static id i_Type_abstrdecl_(struct Type_PRIVATE *self,SEL _cmd,id aDecl)
{self->
decl=aDecl;
return(id)self;
}

static id i_Type_decl_(struct Type_PRIVATE *self,SEL _cmd,id aDecl)
{
id objcT40,objcT41;

#line 140 "type.m"
return(objcT40=(id)self,(*_imp(objcT40,selTransTbl[11]))(objcT40,selTransTbl[11],(aDecl)?(objcT41=aDecl,(*_imp(objcT41,selTransTbl[12]))(objcT41,selTransTbl[12])):(id)0));
}

static BOOL i_Type_haslistinit(struct Type_PRIVATE *self,SEL _cmd)
{
return self->haslistinit;
}

static BOOL i_Type_isstatic(struct Type_PRIVATE *self,SEL _cmd)
{
return self->isstatic;
}

static BOOL i_Type_isextern(struct Type_PRIVATE *self,SEL _cmd)
{
return self->isextern;
}

static BOOL i_Type_definesocu(struct Type_PRIVATE *self,SEL _cmd)
{
return !self->isstatic;
}

static id i_Type_isstatic_(struct Type_PRIVATE *self,SEL _cmd,BOOL flag)
{self->
isstatic=flag;
return(id)self;
}

static id i_Type_isextern_(struct Type_PRIVATE *self,SEL _cmd,BOOL flag)
{self->
isextern=flag;
return(id)self;
}

static id i_Type_haslistinit_(struct Type_PRIVATE *self,SEL _cmd,BOOL flag)
{self->
haslistinit=flag;
return(id)self;
}

static id i_Type_max_(struct Type_PRIVATE *self,SEL _cmd,id aType)
{
if((id)self==t_unknown||aType==t_unknown)
return t_unknown;
return(id)self;
}

static unsigned i_Type_hash(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT45;

#line 190 "type.m"
unsigned h=0;

if(self->specs){
id objcT42,objcT43,objcT44;

#line 193 "type.m"
int i,n;

h=(n=(objcT42=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT42,selTransTbl[6]))(objcT42,selTransTbl[6])));
for(i=0;i<n;i++)
h=(h<<1)^((objcT43=(objcT44=self->specs,(*(id(*)(id,SEL,unsigned))_imp(objcT44,selTransTbl[7]))(objcT44,selTransTbl[7],i)),(*(unsigned(*)(id,SEL))_imp(objcT43,selTransTbl[13]))(objcT43,selTransTbl[13])));
}
if(self->decl)
h^=(objcT45=self->decl,(*(unsigned(*)(id,SEL))_imp(objcT45,selTransTbl[13]))(objcT45,selTransTbl[13]));
return h;
}

static BOOL i_Type_isEqual_(struct Type_PRIVATE *self,SEL _cmd,id x)
{
if((id)self==x){
return(BOOL)1;
}else{
id objcT46,objcT47,objcT48,objcT49;

#line 209 "type.m"
id y,z;

y=(objcT46=x,(*_imp(objcT46,selTransTbl[14]))(objcT46,selTransTbl[14]));
if(self->specs&&y&& !(objcT47=self->specs,(*(BOOL(*)(id,SEL,id))_imp(objcT47,selTransTbl[15]))(objcT47,selTransTbl[15],y)))
return(BOOL)0;
if(( !self->specs|| !y)&&self->specs!=y)
return(BOOL)0;
z=(objcT48=x,(*_imp(objcT48,selTransTbl[16]))(objcT48,selTransTbl[16]));
if(self->decl&&z&& !(objcT49=self->decl,(*(BOOL(*)(id,SEL,id))_imp(objcT49,selTransTbl[15]))(objcT49,selTransTbl[15],z)))
return(BOOL)0;
if(( !self->decl|| !z)&&self->decl!=z)
return(BOOL)0;
return(BOOL)1;
}
}

static BOOL i_Type_isvoid(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT50,objcT51,objcT52;

#line 227 "type.m"
if((id)self==t_void)
return(BOOL)1;
return self->decl==(id)0&&(objcT50=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT50,selTransTbl[6]))(objcT50,selTransTbl[6]))==1&&(objcT51=(objcT52=self->specs,(*(id(*)(id,SEL,unsigned))_imp(objcT52,selTransTbl[7]))(objcT52,selTransTbl[7],0)),(*(BOOL(*)(id,SEL))_imp(objcT51,selTransTbl[17]))(objcT51,selTransTbl[17]));
}

static BOOL i_Type_isid(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT53,objcT54,objcT55;

#line 234 "type.m"
if((id)self==t_id)
return(BOOL)1;
return self->decl==(id)0&&(objcT53=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT53,selTransTbl[6]))(objcT53,selTransTbl[6]))==1&&(objcT54=(objcT55=self->specs,(*(id(*)(id,SEL,unsigned))_imp(objcT55,selTransTbl[7]))(objcT55,selTransTbl[7],0)),(*(BOOL(*)(id,SEL))_imp(objcT54,selTransTbl[18]))(objcT54,selTransTbl[18]));
}

static BOOL i_Type_canforward(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT56;

#line 241 "type.m"
if((objcT56=self->decl,(*(BOOL(*)(id,SEL))_imp(objcT56,selTransTbl[19]))(objcT56,selTransTbl[19]))){
return(BOOL)1;
}else{
id objcT57;

#line 244 "type.m"
if(self->decl==(id)0||(objcT57=self->decl,(*(BOOL(*)(id,SEL))_imp(objcT57,selTransTbl[20]))(objcT57,selTransTbl[20]))){
id objcT58;

#line 245 "type.m"
int i,n;


for(i=0,n=(objcT58=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT58,selTransTbl[6]))(objcT58,selTransTbl[6]));i<n;i++){
id objcT59,objcT60,objcT61;

#line 249 "type.m"
id sp=(objcT59=self->specs,(*(id(*)(id,SEL,unsigned))_imp(objcT59,selTransTbl[7]))(objcT59,selTransTbl[7],i));

if((objcT60=sp,(*(BOOL(*)(id,SEL))_imp(objcT60,selTransTbl[9]))(objcT60,selTransTbl[9])))
continue;
if( !(objcT61=sp,(*(BOOL(*)(id,SEL))_imp(objcT61,selTransTbl[20]))(objcT61,selTransTbl[20])))
return(BOOL)0;
}
return(BOOL)1;
}else{
return(BOOL)0;
}
}
}

static BOOL i_Type_isselptr(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT62;

#line 265 "type.m"
if((objcT62=self->decl,(*(BOOL(*)(id,SEL))_imp(objcT62,selTransTbl[19]))(objcT62,selTransTbl[19]))){
return(BOOL)1;
}else{
if(self->decl==(id)0){
id objcT63;

#line 269 "type.m"
int i,n;


for(i=0,n=(objcT63=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT63,selTransTbl[6]))(objcT63,selTransTbl[6]));i<n;i++){
id objcT64,objcT65,objcT66;

#line 273 "type.m"
id sp=(objcT64=self->specs,(*(id(*)(id,SEL,unsigned))_imp(objcT64,selTransTbl[7]))(objcT64,selTransTbl[7],i));

if((objcT65=sp,(*(BOOL(*)(id,SEL))_imp(objcT65,selTransTbl[9]))(objcT65,selTransTbl[9])))
continue;
if( !(objcT66=sp,(*(BOOL(*)(id,SEL))_imp(objcT66,selTransTbl[21]))(objcT66,selTransTbl[21])))
return(BOOL)0;
}
return(BOOL)1;
}else{
return(BOOL)0;
}
}
}

static id i_Type_synth(struct Type_PRIVATE *self,SEL _cmd)
{
return(id)self;
}

static id i_Type_gen(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT67,objcT68;

#line 294 "type.m"
if(self->specs)
(objcT67=self->specs,(*(id(*)(id,SEL,SEL))_imp(objcT67,selTransTbl[22]))(objcT67,selTransTbl[22],selTransTbl[23]));
if(self->decl)
(objcT68=self->decl,(*_imp(objcT68,selTransTbl[23]))(objcT68,selTransTbl[23]));
return(id)self;
}

static id i_Type_genabstrtype(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT69;

#line 303 "type.m"
return(objcT69=(id)self,(*_imp(objcT69,selTransTbl[24]))(objcT69,selTransTbl[24],(id)0));
}

static id i_Type_gendef_(struct Type_PRIVATE *self,SEL _cmd,id sym)
{
id objcT70;

#line 308 "type.m"
o_nolinetags++;
if(self->specs)
(objcT70=self->specs,(*(id(*)(id,SEL,SEL))_imp(objcT70,selTransTbl[22]))(objcT70,selTransTbl[22],selTransTbl[23]));
if(self->decl){
id objcT71;

#line 312 "type.m"
(objcT71=self->decl,(*_imp(objcT71,selTransTbl[24]))(objcT71,selTransTbl[24],sym));
}else{
id objcT72;

#line 314 "type.m"
if(sym)
(objcT72=sym,(*_imp(objcT72,selTransTbl[23]))(objcT72,selTransTbl[23]));
}
o_nolinetags--;
return(id)self;
}

static id i_Type_dot_(struct Type_PRIVATE *self,SEL _cmd,id sym)
{
id objcT73,objcT74,objcT75;

#line 323 "type.m"
if(self->decl)
return(id)0;
if((objcT73=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT73,selTransTbl[6]))(objcT73,selTransTbl[6]))!=1)
return(id)0;
return(objcT74=(objcT75=self->specs,(*(id(*)(id,SEL,unsigned))_imp(objcT75,selTransTbl[7]))(objcT75,selTransTbl[7],0)),(*_imp(objcT74,selTransTbl[25]))(objcT74,selTransTbl[25],sym));
}

static id i_Type_star(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT76,objcT77,objcT78,objcT79,objcT80;
id objcT81,objcT82;

#line 332 "type.m"
if(self->decl==(id)0&&(objcT76=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT76,selTransTbl[6]))(objcT76,selTransTbl[6]))==1)
return(objcT77=(objcT78=self->specs,(*(id(*)(id,SEL,unsigned))_imp(objcT78,selTransTbl[7]))(objcT78,selTransTbl[7],0)),(*_imp(objcT77,selTransTbl[26]))(objcT77,selTransTbl[26]));
if(self->decl==(id)0&&(objcT79=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT79,selTransTbl[6]))(objcT79,selTransTbl[6]))!=1)
return(id)0;
return(objcT80=(objcT81=(id)self,(*_imp(objcT81,selTransTbl[27]))(objcT81,selTransTbl[27])),(*_imp(objcT80,selTransTbl[11]))(objcT80,selTransTbl[11],(objcT82=self->decl,(*_imp(objcT82,selTransTbl[26]))(objcT82,selTransTbl[26]))));
}

#line 22 "pointer.h"
extern id  Pointer;

#line 22 "stardecl.h"
extern id  StarDecl;

#line 339 "type.m"
static id i_Type_ampersand(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT83,objcT84,objcT85,objcT86,objcT87;
id objcT88;

#line 341 "type.m"
id s,p;

p=(objcT83=Pointer,(*_imp(objcT83,selTransTbl[0]))(objcT83,selTransTbl[0]));
s=(objcT84=(objcT85=(objcT86=StarDecl,(*_imp(objcT86,selTransTbl[0]))(objcT86,selTransTbl[0])),(*_imp(objcT85,selTransTbl[28]))(objcT85,selTransTbl[28],p)),(*_imp(objcT84,selTransTbl[29]))(objcT84,selTransTbl[29],self->decl));
return(objcT87=(objcT88=(id)self,(*_imp(objcT88,selTransTbl[27]))(objcT88,selTransTbl[27])),(*_imp(objcT87,selTransTbl[11]))(objcT87,selTransTbl[11],s));
}

static id i_Type_funcall(struct Type_PRIVATE *self,SEL _cmd)
{
id objcT89,objcT90,objcT91,objcT92,objcT93;
id objcT94,objcT95;

#line 350 "type.m"
if(self->decl==(id)0&&(objcT89=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT89,selTransTbl[6]))(objcT89,selTransTbl[6]))==1)
return(objcT90=(objcT91=self->specs,(*(id(*)(id,SEL,unsigned))_imp(objcT91,selTransTbl[7]))(objcT91,selTransTbl[7],0)),(*_imp(objcT90,selTransTbl[30]))(objcT90,selTransTbl[30]));
if(self->decl==(id)0&&(objcT92=self->specs,(*(unsigned(*)(id,SEL))_imp(objcT92,selTransTbl[6]))(objcT92,selTransTbl[6]))!=1)
return(id)0;
return(objcT93=(objcT94=(id)self,(*_imp(objcT94,selTransTbl[27]))(objcT94,selTransTbl[27])),(*_imp(objcT93,selTransTbl[11]))(objcT93,selTransTbl[11],(objcT95=self->decl,(*_imp(objcT95,selTransTbl[30]))(objcT95,selTransTbl[30]))));
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Node;
extern struct _SHARED _Node;
extern struct _SHARED __Node;
static struct _SLT _Type_clsDispatchTbl[] ={
{"commontypes",(id (*)())c_Type_commontypes},
{(char*)0,(id (*)())0}
};
static struct _SLT _Type_nstDispatchTbl[] ={
{"specs",(id (*)())i_Type_specs},
{"decl",(id (*)())i_Type_decl},
{"abstrspecs:",(id (*)())i_Type_abstrspecs_},
{"checkspec:",(id (*)())i_Type_checkspec_},
{"specs:",(id (*)())i_Type_specs_},
{"addspec:",(id (*)())i_Type_addspec_},
{"abstrdecl:",(id (*)())i_Type_abstrdecl_},
{"decl:",(id (*)())i_Type_decl_},
{"haslistinit",(id (*)())i_Type_haslistinit},
{"isstatic",(id (*)())i_Type_isstatic},
{"isextern",(id (*)())i_Type_isextern},
{"definesocu",(id (*)())i_Type_definesocu},
{"isstatic:",(id (*)())i_Type_isstatic_},
{"isextern:",(id (*)())i_Type_isextern_},
{"haslistinit:",(id (*)())i_Type_haslistinit_},
{"max:",(id (*)())i_Type_max_},
{"hash",(id (*)())i_Type_hash},
{"isEqual:",(id (*)())i_Type_isEqual_},
{"isvoid",(id (*)())i_Type_isvoid},
{"isid",(id (*)())i_Type_isid},
{"canforward",(id (*)())i_Type_canforward},
{"isselptr",(id (*)())i_Type_isselptr},
{"synth",(id (*)())i_Type_synth},
{"gen",(id (*)())i_Type_gen},
{"genabstrtype",(id (*)())i_Type_genabstrtype},
{"gendef:",(id (*)())i_Type_gendef_},
{"dot:",(id (*)())i_Type_dot_},
{"star",(id (*)())i_Type_star},
{"ampersand",(id (*)())i_Type_ampersand},
{"funcall",(id (*)())i_Type_funcall},
{(char*)0,(id (*)())0}
};
id Type = (id)&_Type;
id  *OBJCCLASS_Type(void) { return &Type; }
struct _SHARED  _Type = {
  (id)&__Type,
  (id)&_Node,
  "Type",
  0,
  sizeof(struct Type_PRIVATE),
  30,
  _Type_nstDispatchTbl,
  41,
  &type_modDesc,
  0,
  (id)0,
  &Type,
};
id  OBJCCFUNC_Type(void) { return (id)&_Type; }
id  OBJCCSUPER_Type(void) { return _Type.clsSuper; }
struct _SHARED __Type = {
  (id)&__Object,
  (id)&__Node,
  "Type",
  0,
  sizeof(struct _SHARED),
  1,
  _Type_clsDispatchTbl,
  34,
  &type_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_Type(void) { return (id)&__Type; }
id  OBJCMSUPER_Type(void) { return __Type.clsSuper; }
static char *_selTransTbl[] ={
"new",
"addspec:",
"add:",
"isKindOf:",
"class",
"name",
"size",
"at:",
"checkspec:",
"isstorageclass",
"abstrspecs:",
"abstrdecl:",
"abstrdecl",
"hash",
"specs",
"isEqual:",
"decl",
"isvoid",
"isid",
"ispointer",
"canforward",
"isselptr",
"elementsPerform:",
"gen",
"gendef:",
"dot:",
"star",
"copy",
"pointer:",
"decl:",
"funcall",
0
};
struct modDescriptor type_modDesc = {
  "type",
  "objc2.3.1",
  0L,
  0,
  0,
  &Type,
  31,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_type(void)
{
  selTransTbl = _selTransTbl;
  return &type_modDesc;
}
int _OBJCPOSTLINK_type = 1;


