#line 1 "runarray.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_runarray(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor runarray_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/ctype.h"
#include <ctype.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 31 "ordcltn.h"
typedef struct objcol
{
int count;
int capacity;
id*ptr;
}*
objcol_t;
#line 28 "intarray.h"
typedef struct intary
{
int capacity;
int*ptr;
}*
intary_t;
#line 28 "runarray.h"
struct RunArray_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 30 "runarray.h"
id runs;
id values;
unsigned size;
int laststart;
int lastend;
int lastsegment;};

#line 28 "runarray.h"
extern id  RunArray;

#line 28 "runarray.h"
extern struct _SHARED _RunArray;
extern struct _SHARED __RunArray;


#line 34 "runarray.m"
static id i_RunArray_reset(struct RunArray_PRIVATE *self,SEL _cmd)
{self->
laststart= -1;
return(id)self;
}

#line 39 "ordcltn.h"
extern id  OrdCltn;

#line 40 "runarray.m"
static id i_RunArray_check(struct RunArray_PRIVATE *self,SEL _cmd)
{
id objcT0,objcT1,objcT2;

#line 42 "runarray.m"
int i,n;
id attrs;
unsigned s;
unsigned totalsize=0;

assert((objcT0=self->runs,(*(unsigned(*)(id,SEL))_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]))>=(objcT1=self->values,(*(unsigned(*)(id,SEL))_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1])));

for(i=0,n=(objcT2=self->values,(*(unsigned(*)(id,SEL))_imp(objcT2,selTransTbl[1]))(objcT2,selTransTbl[1]));i<n;i++){
id objcT3,objcT4,objcT5,objcT6;

#line 50 "runarray.m"
attrs=(objcT3=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT3,selTransTbl[2]))(objcT3,selTransTbl[2],i));
assert((objcT4=attrs,(*(BOOL(*)(id,SEL,id))_imp(objcT4,selTransTbl[3]))(objcT4,selTransTbl[3],(id)(objcT5=OrdCltn,(*_imp(objcT5,selTransTbl[4]))(objcT5,selTransTbl[4])))));
s=(objcT6=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT6,selTransTbl[5]))(objcT6,selTransTbl[5],i));
assert(s>0);
totalsize+=s;
}

assert(totalsize==self->size);
return(id)self;
}

#line 35 "intarray.h"
extern id  IntArray;

#line 61 "runarray.m"
static id c_RunArray_new(struct RunArray_PRIVATE *self,SEL _cmd)
{
id objcT7,objcT8,objcT9,objcT10;

#line 63 "runarray.m"
return(objcT7=(objcT8=__RunArray.clsSuper,(*_impSuper(objcT8,selTransTbl[6]))((id)self,selTransTbl[6])),(*_imp(objcT7,selTransTbl[7]))(objcT7,selTransTbl[7],(objcT9=IntArray,(*_imp(objcT9,selTransTbl[6]))(objcT9,selTransTbl[6])),(objcT10=OrdCltn,(*_imp(objcT10,selTransTbl[6]))(objcT10,selTransTbl[6]))));
}

static id i_RunArray_free(struct RunArray_PRIVATE *self,SEL _cmd)
{
id objcT11,objcT12,objcT13,objcT14,objcT15;

#line 68 "runarray.m"
(objcT11=self->values,(*(id(*)(id,SEL,SEL))_imp(objcT11,selTransTbl[8]))(objcT11,selTransTbl[8],selTransTbl[9]));
(objcT12=(objcT13=self->values,(*_imp(objcT13,selTransTbl[9]))(objcT13,selTransTbl[9])),(*_imp(objcT12,selTransTbl[10]))(objcT12,selTransTbl[10]));
(objcT14=self->runs,(*_imp(objcT14,selTransTbl[10]))(objcT14,selTransTbl[10]));
return(objcT15=_RunArray.clsSuper,(*_impSuper(objcT15,selTransTbl[10]))((id)self,selTransTbl[10]));
}


static id i_RunArray_values(struct RunArray_PRIVATE *self,SEL _cmd)
{
return self->values;
}

static id i_RunArray_runs(struct RunArray_PRIVATE *self,SEL _cmd)
{
return self->runs;
}

static id i_RunArray_runs_values_(struct RunArray_PRIVATE *self,SEL _cmd,id r,id v)
{
id objcT16;
self->
#line 87 "runarray.m"
runs=r;self->
values=v;
(objcT16=(id)self,(*_imp(objcT16,selTransTbl[11]))(objcT16,selTransTbl[11]));
return(id)self;
}

static id i_RunArray_at_(struct RunArray_PRIVATE *self,SEL _cmd,unsigned i)
{
id objcT17,objcT21,objcT24;

#line 95 "runarray.m"
int j,n;
unsigned p;

if(i>=self->size)(objcT17=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT17,selTransTbl[12]))(objcT17,selTransTbl[12],"Bounds error."));
#line 102 "runarray.m"
if(self->laststart!= -1){
id objcT18;

#line 103 "runarray.m"
if(self->laststart<=i&&i<self->lastend)return(objcT18=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT18,selTransTbl[2]))(objcT18,selTransTbl[2],self->lastsegment));
if(i==self->lastend){
id objcT19,objcT20;
self->
#line 105 "runarray.m"
lastsegment++;self->
laststart=self->lastend;self->
lastend=self->laststart+(objcT19=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT19,selTransTbl[5]))(objcT19,selTransTbl[5],self->lastsegment));
return(objcT20=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT20,selTransTbl[2]))(objcT20,selTransTbl[2],self->lastsegment));
}
}
#line 114 "runarray.m"
for(j=0,p=0,n=(objcT21=self->values,(*(unsigned(*)(id,SEL))_imp(objcT21,selTransTbl[1]))(objcT21,selTransTbl[1]));j<n;j++){
id objcT22;

#line 115 "runarray.m"
unsigned q=p+(objcT22=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT22,selTransTbl[5]))(objcT22,selTransTbl[5],j));
if(p<=i&&i<q){
id objcT23;
self->
#line 117 "runarray.m"
laststart=p;self->
lastend=q;self->
lastsegment=j;
return(objcT23=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT23,selTransTbl[2]))(objcT23,selTransTbl[2],j));
}
p=q;
}

return(objcT24=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT24,selTransTbl[12]))(objcT24,selTransTbl[12],"No segment found."));
}

static unsigned i_RunArray_runLengthAt_(struct RunArray_PRIVATE *self,SEL _cmd,unsigned i)
{
id objcT25,objcT27,objcT29;

#line 130 "runarray.m"
int j,n;
unsigned p;

if(i>=self->size)(objcT25=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT25,selTransTbl[12]))(objcT25,selTransTbl[12],"Bounds error."));
#line 137 "runarray.m"
if(self->laststart!= -1){
if(self->laststart<=i&&i<self->lastend)return self->lastend-i;
if(i==self->lastend){
id objcT26;
self->
#line 140 "runarray.m"
lastsegment++;self->
laststart=self->lastend;self->
lastend=self->laststart+(objcT26=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT26,selTransTbl[5]))(objcT26,selTransTbl[5],self->lastsegment));
return self->lastend-i;
}
}
#line 149 "runarray.m"
for(j=0,p=0,n=(objcT27=self->values,(*(unsigned(*)(id,SEL))_imp(objcT27,selTransTbl[1]))(objcT27,selTransTbl[1]));j<n;j++){
id objcT28;

#line 150 "runarray.m"
unsigned q=p+(objcT28=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT28,selTransTbl[5]))(objcT28,selTransTbl[5],j));
if(p<=i&&i<q){self->
laststart=p;self->
lastend=q;self->
lastsegment=j;
return self->lastend-i;
}
p=q;
}

(objcT29=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT29,selTransTbl[12]))(objcT29,selTransTbl[12],"No segment found."));
return 0;
}


static unsigned i_RunArray_size(struct RunArray_PRIVATE *self,SEL _cmd)
{
return self->size;
}

static id i_RunArray_calcsize(struct RunArray_PRIVATE *self,SEL _cmd)
{
id objcT30,objcT31,objcT32;

#line 172 "runarray.m"
int i,n;
int totalsize=0;

assert((objcT30=self->runs,(*(unsigned(*)(id,SEL))_imp(objcT30,selTransTbl[0]))(objcT30,selTransTbl[0]))>=(objcT31=self->values,(*(unsigned(*)(id,SEL))_imp(objcT31,selTransTbl[1]))(objcT31,selTransTbl[1])));

for(i=0,n=(objcT32=self->values,(*(unsigned(*)(id,SEL))_imp(objcT32,selTransTbl[1]))(objcT32,selTransTbl[1]));i<n;i++){
id objcT33;

#line 178 "runarray.m"
int s=(objcT33=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT33,selTransTbl[5]))(objcT33,selTransTbl[5],i));

totalsize+=s;
}self->

size=totalsize;
return(id)self;
}

static id i_RunArray_setsize_(struct RunArray_PRIVATE *self,SEL _cmd,unsigned newsize)
{
id objcT41;

#line 189 "runarray.m"
if(self->size==newsize)return(id)self;

if(self->size<newsize){
id objcT34,objcT35,objcT36,objcT37,objcT38;
id objcT39;

#line 192 "runarray.m"
int n=(objcT34=self->values,(*(unsigned(*)(id,SEL))_imp(objcT34,selTransTbl[1]))(objcT34,selTransTbl[1]));
int m=(objcT35=self->runs,(*(unsigned(*)(id,SEL))_imp(objcT35,selTransTbl[0]))(objcT35,selTransTbl[0]));
if(m<(n+1))(objcT36=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT36,selTransTbl[13]))(objcT36,selTransTbl[13],(2*m+1)));
(objcT37=self->values,(*_imp(objcT37,selTransTbl[14]))(objcT37,selTransTbl[14],(objcT38=OrdCltn,(*_imp(objcT38,selTransTbl[6]))(objcT38,selTransTbl[6]))));
(objcT39=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT39,selTransTbl[15]))(objcT39,selTransTbl[15],n,(newsize-self->size)));self->
size=newsize;
}else{
id objcT40;

#line 199 "runarray.m"
(objcT40=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT40,selTransTbl[16]))(objcT40,selTransTbl[16],_cmd));
}

assert((objcT41=(id)self,(*_imp(objcT41,selTransTbl[17]))(objcT41,selTransTbl[17])));
return(id)self;
}

static id i_RunArray_addAttribute_to_(struct RunArray_PRIVATE *self,SEL _cmd,id attrib,id v)
{
id objcT42,objcT43,objcT48;

#line 208 "runarray.m"
int n=(objcT42=v,(*(unsigned(*)(id,SEL))_imp(objcT42,selTransTbl[1]))(objcT42,selTransTbl[1]));

(objcT43=attrib,(*_imp(objcT43,selTransTbl[11]))(objcT43,selTransTbl[11]));
while(n--){
id objcT44,objcT45;

#line 212 "runarray.m"
if((objcT44=attrib,(*(BOOL(*)(id,SEL,id))_imp(objcT44,selTransTbl[18]))(objcT44,selTransTbl[18],(objcT45=v,(*(id(*)(id,SEL,unsigned))_imp(objcT45,selTransTbl[2]))(objcT45,selTransTbl[2],n))))){
id objcT46,objcT47;

#line 213 "runarray.m"
id atb=(objcT46=v,(*(id(*)(id,SEL,unsigned))_imp(objcT46,selTransTbl[19]))(objcT46,selTransTbl[19],n));

(objcT47=atb,(*_imp(objcT47,selTransTbl[10]))(objcT47,selTransTbl[10]));

}
}
if((objcT48=attrib,(*(BOOL(*)(id,SEL))_imp(objcT48,selTransTbl[20]))(objcT48,selTransTbl[20]))){
id objcT49;

#line 220 "runarray.m"
(objcT49=v,(*_imp(objcT49,selTransTbl[14]))(objcT49,selTransTbl[14],attrib));

}else{
id objcT50;

#line 223 "runarray.m"
(objcT50=attrib,(*_imp(objcT50,selTransTbl[10]))(objcT50,selTransTbl[10]));

}
return(id)self;
}

static id i_RunArray_breakat_(struct RunArray_PRIVATE *self,SEL _cmd,int i)
{
id objcT51,objcT62;

#line 231 "runarray.m"
int j,k,p,n;

for(j=0,p=0,n=(objcT51=self->values,(*(unsigned(*)(id,SEL))_imp(objcT51,selTransTbl[1]))(objcT51,selTransTbl[1]));j<n;j++){
id objcT52;

#line 234 "runarray.m"
unsigned q=p+(objcT52=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT52,selTransTbl[5]))(objcT52,selTransTbl[5],j));

if(p==i||q==i)
return(id)self;
if(p<i&&q>i){
id objcT53,objcT54,objcT55,objcT56,objcT57;
id objcT58,objcT59,objcT60,objcT61;

#line 239 "runarray.m"
int m=(objcT53=self->runs,(*(unsigned(*)(id,SEL))_imp(objcT53,selTransTbl[0]))(objcT53,selTransTbl[0]));
id v=(objcT54=(objcT55=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT55,selTransTbl[2]))(objcT55,selTransTbl[2],j)),(*_imp(objcT54,selTransTbl[21]))(objcT54,selTransTbl[21]));

if(m<(n+1))
(objcT56=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT56,selTransTbl[13]))(objcT56,selTransTbl[13],(2*m+1)));
(objcT57=self->values,(*(id(*)(id,SEL,unsigned,id))_imp(objcT57,selTransTbl[22]))(objcT57,selTransTbl[22],j,v));
k=n;
while( --k>=j)
(objcT58=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT58,selTransTbl[15]))(objcT58,selTransTbl[15],k+1,(objcT59=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT59,selTransTbl[5]))(objcT59,selTransTbl[5],k))));
(objcT60=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT60,selTransTbl[15]))(objcT60,selTransTbl[15],j,i-p));
(objcT61=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT61,selTransTbl[15]))(objcT61,selTransTbl[15],j+1,q-i));
return(id)self;
}
p=q;
}
return(objcT62=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT62,selTransTbl[12]))(objcT62,selTransTbl[12],"Error in run computation"));
}

static id i_RunArray_addAttribute_from_size_(struct RunArray_PRIVATE *self,SEL _cmd,id attrib,unsigned p,unsigned s)
{
id objcT69,objcT70,objcT77,objcT78,objcT83;

#line 259 "runarray.m"
int i;

if(s==0)return(id)self;
#line 265 "runarray.m"
if(p>=self->size){
id objcT63,objcT64,objcT65,objcT66,objcT67;
id objcT68;

#line 266 "runarray.m"
if(p>self->size)(objcT63=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT63,selTransTbl[23]))(objcT63,selTransTbl[23],p));
(objcT64=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT64,selTransTbl[23]))(objcT64,selTransTbl[23],p+s));
i=(objcT65=self->values,(*(unsigned(*)(id,SEL))_imp(objcT65,selTransTbl[1]))(objcT65,selTransTbl[1]));
assert((objcT66=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT66,selTransTbl[5]))(objcT66,selTransTbl[5],i-1))==s);
return(objcT67=(id)self,(*_imp(objcT67,selTransTbl[24]))(objcT67,selTransTbl[24],attrib,(objcT68=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT68,selTransTbl[2]))(objcT68,selTransTbl[2],i-1))));
}
#line 275 "runarray.m"
i=(objcT69=self->values,(*(unsigned(*)(id,SEL))_imp(objcT69,selTransTbl[1]))(objcT69,selTransTbl[1]));
if((i!=0)&&(p+s==self->size)&&(s==(objcT70=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT70,selTransTbl[5]))(objcT70,selTransTbl[5],i-1)))){
id objcT71,objcT72;

#line 277 "runarray.m"
return(objcT71=(id)self,(*_imp(objcT71,selTransTbl[24]))(objcT71,selTransTbl[24],attrib,(objcT72=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT72,selTransTbl[2]))(objcT72,selTransTbl[2],i-1))));
}
#line 283 "runarray.m"
if(p+s>self->size){
id objcT73,objcT74;

#line 284 "runarray.m"
(objcT73=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT73,selTransTbl[23]))(objcT73,selTransTbl[23],p+s));
(objcT74=(id)self,(*(id(*)(id,SEL,int))_imp(objcT74,selTransTbl[25]))(objcT74,selTransTbl[25],p));
}else{
id objcT75,objcT76;

#line 287 "runarray.m"
(objcT75=(id)self,(*(id(*)(id,SEL,int))_imp(objcT75,selTransTbl[25]))(objcT75,selTransTbl[25],p));
(objcT76=(id)self,(*(id(*)(id,SEL,int))_imp(objcT76,selTransTbl[25]))(objcT76,selTransTbl[25],p+s));
}

(objcT77=(id)self,(*_imp(objcT77,selTransTbl[11]))(objcT77,selTransTbl[11]));

for(i=0;i<self->size;i+=(objcT78=(id)self,(*(unsigned(*)(id,SEL,unsigned))_imp(objcT78,selTransTbl[26]))(objcT78,selTransTbl[26],i))){
id objcT79,objcT80,objcT81,objcT82;

#line 294 "runarray.m"
if(i==p+s)
break;
if(i>p+s)
(objcT79=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT79,selTransTbl[12]))(objcT79,selTransTbl[12],"Error in run computation."));
if(i>=p)
(objcT80=(id)self,(*_imp(objcT80,selTransTbl[24]))(objcT80,selTransTbl[24],(objcT81=attrib,(*_imp(objcT81,selTransTbl[27]))(objcT81,selTransTbl[27])),(objcT82=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT82,selTransTbl[2]))(objcT82,selTransTbl[2],i))));
}


(objcT83=attrib,(*_imp(objcT83,selTransTbl[10]))(objcT83,selTransTbl[10]));

return(id)self;
}

static id i_RunArray_at_insert_count_(struct RunArray_PRIVATE *self,SEL _cmd,unsigned anOffset,char*aString,int n)
{
id objcT84,objcT85,objcT86,objcT87,objcT88;

#line 310 "runarray.m"
(objcT84=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT84,selTransTbl[2]))(objcT84,selTransTbl[2],anOffset));
(objcT85=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT85,selTransTbl[15]))(objcT85,selTransTbl[15],self->lastsegment,(objcT86=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT86,selTransTbl[5]))(objcT86,selTransTbl[5],self->lastsegment))+n));self->
size+=n;
(objcT87=(id)self,(*_imp(objcT87,selTransTbl[11]))(objcT87,selTransTbl[11]));
assert((objcT88=(id)self,(*_imp(objcT88,selTransTbl[17]))(objcT88,selTransTbl[17])));
return(id)self;
}

static id i_RunArray_deleteFrom_to_(struct RunArray_PRIVATE *self,SEL _cmd,unsigned p,unsigned q)
{
id objcT89,objcT90,objcT91,objcT92,objcT93;
id objcT113,objcT114;

#line 320 "runarray.m"
int i,is,j,je,n;

if(p>q)
(objcT89=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT89,selTransTbl[12]))(objcT89,selTransTbl[12],"Bounds error"));

assert((objcT90=(id)self,(*_imp(objcT90,selTransTbl[17]))(objcT90,selTransTbl[17])));

n=q-p+1;
(objcT91=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT91,selTransTbl[2]))(objcT91,selTransTbl[2],p));
i=self->lastsegment;
is=self->laststart;
(objcT92=(id)self,(*(id(*)(id,SEL,unsigned))_imp(objcT92,selTransTbl[2]))(objcT92,selTransTbl[2],q));
j=self->lastsegment;
je=self->lastend;
(objcT93=(id)self,(*_imp(objcT93,selTransTbl[11]))(objcT93,selTransTbl[11]));

if(i==j){
id objcT94,objcT95;

#line 337 "runarray.m"
int m=(objcT94=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT94,selTransTbl[5]))(objcT94,selTransTbl[5],i));

assert(m>=n);
(objcT95=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT95,selTransTbl[15]))(objcT95,selTransTbl[15],i,m-n));
if(m==n){
id objcT96,objcT97,objcT98;

#line 342 "runarray.m"
id atb=(objcT96=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT96,selTransTbl[19]))(objcT96,selTransTbl[19],i));

(objcT97=(objcT98=atb,(*_imp(objcT98,selTransTbl[9]))(objcT98,selTransTbl[9])),(*_imp(objcT97,selTransTbl[10]))(objcT97,selTransTbl[10]));

}
}else{
id objcT99,objcT100,objcT101,objcT102,objcT103;

#line 348 "runarray.m"
int m,k,r;

m=(objcT99=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT99,selTransTbl[5]))(objcT99,selTransTbl[5],i));
assert(p>=is);
(objcT100=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT100,selTransTbl[15]))(objcT100,selTransTbl[15],i,p-is));
for(k=i+1;k<j;k++)
(objcT101=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT101,selTransTbl[15]))(objcT101,selTransTbl[15],k,0));
m=(objcT102=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT102,selTransTbl[5]))(objcT102,selTransTbl[5],j));
assert(q<je);
(objcT103=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT103,selTransTbl[15]))(objcT103,selTransTbl[15],j,je-q-1));

r=i;
if(is==p){
id objcT104,objcT105,objcT106;

#line 361 "runarray.m"
id atb=(objcT104=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT104,selTransTbl[19]))(objcT104,selTransTbl[19],r));

(objcT105=(objcT106=atb,(*_imp(objcT106,selTransTbl[9]))(objcT106,selTransTbl[9])),(*_imp(objcT105,selTransTbl[10]))(objcT105,selTransTbl[10]));

}else{
r++;
}
for(k=i+1;k<j;k++){
id objcT107,objcT108,objcT109;

#line 369 "runarray.m"
id atb=(objcT107=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT107,selTransTbl[19]))(objcT107,selTransTbl[19],r));

(objcT108=(objcT109=atb,(*_imp(objcT109,selTransTbl[9]))(objcT109,selTransTbl[9])),(*_imp(objcT108,selTransTbl[10]))(objcT108,selTransTbl[10]));

}
if(je==q+1){
id objcT110,objcT111,objcT112;

#line 375 "runarray.m"
id atb=(objcT110=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT110,selTransTbl[19]))(objcT110,selTransTbl[19],r));

(objcT111=(objcT112=atb,(*_imp(objcT112,selTransTbl[9]))(objcT112,selTransTbl[9])),(*_imp(objcT111,selTransTbl[10]))(objcT111,selTransTbl[10]));

}
}self->

size-=n;
(objcT113=self->runs,(*_imp(objcT113,selTransTbl[28]))(objcT113,selTransTbl[28]));

assert((objcT114=(id)self,(*_imp(objcT114,selTransTbl[17]))(objcT114,selTransTbl[17])));
return(id)self;
}

static id i_RunArray_concat_(struct RunArray_PRIVATE *self,SEL _cmd,id b)
{
id objcT115,objcT116,objcT117,objcT118,objcT119;
id objcT120,objcT121,objcT122,objcT123,objcT124;
id objcT125,objcT126,objcT127,objcT128;

#line 391 "runarray.m"
int i,m,n,k;
id v,r=(objcT115=b,(*_imp(objcT115,selTransTbl[29]))(objcT115,selTransTbl[29]));

k=(objcT116=self->values,(*(unsigned(*)(id,SEL))_imp(objcT116,selTransTbl[1]))(objcT116,selTransTbl[1]));
n=(objcT117=(objcT118=b,(*_imp(objcT118,selTransTbl[30]))(objcT118,selTransTbl[30])),(*(unsigned(*)(id,SEL))_imp(objcT117,selTransTbl[1]))(objcT117,selTransTbl[1]));
for(i=0;i<n;i++)
(objcT119=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT119,selTransTbl[15]))(objcT119,selTransTbl[15],k+i,(objcT120=r,(*(int(*)(id,SEL,unsigned))_imp(objcT120,selTransTbl[5]))(objcT120,selTransTbl[5],i))));

v=(objcT121=(objcT122=b,(*_imp(objcT122,selTransTbl[30]))(objcT122,selTransTbl[30])),(*_imp(objcT121,selTransTbl[21]))(objcT121,selTransTbl[21]));
(objcT123=self->values,(*_imp(objcT123,selTransTbl[31]))(objcT123,selTransTbl[31],v));

(objcT124=v,(*_imp(objcT124,selTransTbl[10]))(objcT124,selTransTbl[10]));

m=(objcT125=self->runs,(*(unsigned(*)(id,SEL))_imp(objcT125,selTransTbl[0]))(objcT125,selTransTbl[0]));
if(m<k+n)
(objcT126=self->runs,(*(id(*)(id,SEL,unsigned))_imp(objcT126,selTransTbl[13]))(objcT126,selTransTbl[13],(k+n+4)));self->

size+=(objcT127=b,(*(unsigned(*)(id,SEL))_imp(objcT127,selTransTbl[1]))(objcT127,selTransTbl[1]));
assert((objcT128=(id)self,(*_imp(objcT128,selTransTbl[17]))(objcT128,selTransTbl[17])));
return(id)self;
}

static id i_RunArray_coalesce(struct RunArray_PRIVATE *self,SEL _cmd)
{
id objcT129;

#line 415 "runarray.m"
int n=(objcT129=self->values,(*(unsigned(*)(id,SEL))_imp(objcT129,selTransTbl[1]))(objcT129,selTransTbl[1]));

while(n--){
id objcT130,objcT131,objcT132;

#line 418 "runarray.m"
id v,w;
if(n==0)break;
v=(objcT130=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT130,selTransTbl[2]))(objcT130,selTransTbl[2],n));
w=(objcT131=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT131,selTransTbl[2]))(objcT131,selTransTbl[2],n-1));
if((objcT132=v,(*(BOOL(*)(id,SEL,id))_imp(objcT132,selTransTbl[32]))(objcT132,selTransTbl[32],w))){
id objcT133,objcT134,objcT135,objcT136,objcT137;
id objcT138,objcT139,objcT140;

#line 423 "runarray.m"
id atb;
unsigned p=(objcT133=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT133,selTransTbl[5]))(objcT133,selTransTbl[5],n));
unsigned q=(objcT134=self->runs,(*(int(*)(id,SEL,unsigned))_imp(objcT134,selTransTbl[5]))(objcT134,selTransTbl[5],n-1));
(objcT135=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT135,selTransTbl[15]))(objcT135,selTransTbl[15],n-1,p+q));
(objcT136=self->runs,(*(int(*)(id,SEL,unsigned,int))_imp(objcT136,selTransTbl[15]))(objcT136,selTransTbl[15],n,0));
atb=(objcT137=self->values,(*(id(*)(id,SEL,unsigned))_imp(objcT137,selTransTbl[19]))(objcT137,selTransTbl[19],n));

(objcT138=(objcT139=atb,(*_imp(objcT139,selTransTbl[9]))(objcT139,selTransTbl[9])),(*_imp(objcT138,selTransTbl[10]))(objcT138,selTransTbl[10]));

(objcT140=self->runs,(*_imp(objcT140,selTransTbl[28]))(objcT140,selTransTbl[28]));
}
}

return(id)self;
}


static id i_RunArray_printOn_(struct RunArray_PRIVATE *self,SEL _cmd,IOD aFile)
{
id objcT141,objcT142;

#line 442 "runarray.m"
fprintf(aFile,"RunArray runs ");
(objcT141=self->runs,(*(id(*)(id,SEL,IOD))_imp(objcT141,selTransTbl[33]))(objcT141,selTransTbl[33],aFile));
(objcT142=self->values,(*(id(*)(id,SEL,IOD))_imp(objcT142,selTransTbl[33]))(objcT142,selTransTbl[33],aFile));
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Cltn;
extern struct _SHARED _Cltn;
extern struct _SHARED __Cltn;
static struct _SLT _RunArray_clsDispatchTbl[] ={
{"new",(id (*)())c_RunArray_new},
{(char*)0,(id (*)())0}
};
static struct _SLT _RunArray_nstDispatchTbl[] ={
{"reset",(id (*)())i_RunArray_reset},
{"check",(id (*)())i_RunArray_check},
{"free",(id (*)())i_RunArray_free},
{"values",(id (*)())i_RunArray_values},
{"runs",(id (*)())i_RunArray_runs},
{"runs:values:",(id (*)())i_RunArray_runs_values_},
{"at:",(id (*)())i_RunArray_at_},
{"runLengthAt:",(id (*)())i_RunArray_runLengthAt_},
{"size",(id (*)())i_RunArray_size},
{"calcsize",(id (*)())i_RunArray_calcsize},
{"setsize:",(id (*)())i_RunArray_setsize_},
{"addAttribute:to:",(id (*)())i_RunArray_addAttribute_to_},
{"breakat:",(id (*)())i_RunArray_breakat_},
{"addAttribute:from:size:",(id (*)())i_RunArray_addAttribute_from_size_},
{"at:insert:count:",(id (*)())i_RunArray_at_insert_count_},
{"deleteFrom:to:",(id (*)())i_RunArray_deleteFrom_to_},
{"concat:",(id (*)())i_RunArray_concat_},
{"coalesce",(id (*)())i_RunArray_coalesce},
{"printOn:",(id (*)())i_RunArray_printOn_},
{(char*)0,(id (*)())0}
};
id RunArray = (id)&_RunArray;
id  *OBJCCLASS_RunArray(void) { return &RunArray; }
struct _SHARED  _RunArray = {
  (id)&__RunArray,
  (id)&_Cltn,
  "RunArray",
  0,
  sizeof(struct RunArray_PRIVATE),
  19,
  _RunArray_nstDispatchTbl,
  41,
  &runarray_modDesc,
  0,
  (id)0,
  &RunArray,
};
id  OBJCCFUNC_RunArray(void) { return (id)&_RunArray; }
id  OBJCCSUPER_RunArray(void) { return _RunArray.clsSuper; }
struct _SHARED __RunArray = {
  (id)&__Object,
  (id)&__Cltn,
  "RunArray",
  0,
  sizeof(struct _SHARED),
  1,
  _RunArray_clsDispatchTbl,
  34,
  &runarray_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_RunArray(void) { return (id)&__RunArray; }
id  OBJCMSUPER_RunArray(void) { return __RunArray.clsSuper; }
static char *_selTransTbl[] ={
"capacity",
"size",
"at:",
"isKindOf:",
"class",
"intAt:",
"new",
"runs:values:",
"elementsPerform:",
"freeContents",
"free",
"reset",
"error:",
"capacity:",
"add:",
"intAt:put:",
"notImplemented:",
"check",
"dominates:",
"removeAt:",
"set",
"deepCopy",
"at:insert:",
"setsize:",
"addAttribute:to:",
"breakat:",
"runLengthAt:",
"copy",
"packContents",
"runs",
"values",
"addAll:",
"isEqual:",
"printOn:",
0
};
struct modDescriptor runarray_modDesc = {
  "runarray",
  "objc2.3.1",
  0L,
  0,
  0,
  &RunArray,
  34,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_runarray(void)
{
  selTransTbl = _selTransTbl;
  return &runarray_modDesc;
}
int _OBJCPOSTLINK_runarray = 1;


