#line 1 "Object.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_Object(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor Object_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 72 "objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 81 "objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 141 "objcrt.h"
struct objcrt_private
{
id isa;
#line 147 "objcrt.h"
unsigned short attr;
unsigned short objID;

};

struct objcrt_shared
{
id isa;
#line 158 "objcrt.h"
id clsSuper;
char*clsName;
char*clsTypes;
short clsSizInstance;
short clsSizDict;
struct objcrt_slt*clsDispTable;
long clsStatus;
struct objcrt_modDescriptor*clsMod;
unsigned clsVersion;
id clsCats;
id*clsGlbl;
};

typedef struct objcrt_shared*Cls_t;
#line 203 "objcrt.h"
struct objcrt_slt
{
SEL _cmd;
IMP _imp;
};
#line 213 "objcrt.h"
struct objcrt_useDescriptor
{
int processed;
struct objcrt_useDescriptor*next;
struct objcrt_useDescriptor***uses;
struct objcrt_modDescriptor*(*bind)();
};
#line 225 "objcrt.h"
typedef struct hashedSelector
{
struct hashedSelector*next;
STR key;
}
HASH,*PHASH;
#line 237 "objcrt.h"
typedef struct objcrt_modDescriptor MOD,*PMOD;
typedef struct objcrt_methodDescriptor METH,*PMETH;

struct objcrt_modDescriptor
{
STR modName;
STR modVersion;
long modStatus;
SEL modMinSel;
SEL modMaxSel;
id*modClsLst;
short modSelRef;
SEL*modSelTbl;
PMETH modMapTbl;
};

struct objcrt_modEntry
{
PMOD(*modLink)();
PMOD modInfo;
};

typedef struct objcrt_modEntry*Mentry_t;

struct objcrt_methodDescriptor
{
id*cls;
SEL*sel;
IMP imp;
};
#line 280 "objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 293 "objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 311 "objcrt.h"
IMP _imp(id,SEL);
IMP _impSuper(id,SEL);
#line 316 "objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);
#line 345 "objcrt.h"
extern id(*oc_alloc)(id,unsigned int);
extern id(*oc_dealloc)(id);
extern id(*oc_copy)(id,unsigned int);
extern id(*oc_error)(id,STR,va_list);

extern id(*oc_cvtToId)(STR);
extern SEL(*oc_cvtToSel)(STR);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);

void addSubclassesTo(id c,STR name);

id newsubclass(STR name,id superClass,int ivars,int cvars);

void addMethods(id src,id dst);

void poseAs(id posing,id target);
id swapclass(id self,id target);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 42 "Block.h"
extern id newBlock(int n,IMP fn,void*data,IMP dtor);
#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 40 "Object.h"
struct Object_PRIVATE {

id isa;
#line 46 "Object.h"
unsigned short attr;
unsigned short objID;};

#line 40 "Object.h"
extern id  Object;

#line 40 "Object.h"
extern struct _SHARED _Object;
extern struct _SHARED __Object;


#line 41 "Object.m"
static id c_Object_initialize(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)self;
}

static id i_Object_initialize(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)self;
}

#line 58 "Object.m"
static id i_Object_str_(struct Object_PRIVATE *self,SEL _cmd,STR s)
{
id objcT0;

#line 60 "Object.m"
return(objcT0=(id)self,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
}

static id c_Object_new(struct Object_PRIVATE *self,SEL _cmd)
{
id newObject=( *oc_alloc)((id)self,0);return newObject;
}

static id i_Object_new(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT1;

#line 70 "Object.m"
return(objcT1=(id)self,(*_imp(objcT1,selTransTbl[0]))(objcT1,selTransTbl[0]));
}

static id i_Object_increfs(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)0;
}

static id i_Object_copy(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT2;

#line 80 "Object.m"
id newObject=( *oc_copy)((id)self,0);(objcT2=newObject,(*_imp(objcT2,selTransTbl[1]))(objcT2,selTransTbl[1]));return newObject;
}

static id i_Object_deepCopy(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT3;

#line 85 "Object.m"
id newObject=( *oc_copy)((id)self,0);(objcT3=newObject,(*_imp(objcT3,selTransTbl[1]))(objcT3,selTransTbl[1]));return newObject;
}

static id i_Object_free(struct Object_PRIVATE *self,SEL _cmd)
{self->
#line 93 "Object.m"
isa=(id)0;return(oc_dealloc)?( *oc_dealloc)((id)self):(id)0;

}

static id i_Object_decrefs(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)0;
}

static id i_Object_release(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT4;
return(objcT4=(id)self,(*_imp(objcT4,selTransTbl[0]))(objcT4,selTransTbl[0]));
#line 110 "Object.m"
}

static id c_Object_free(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)0;
}

static id c_Object_release(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)0;
}

#line 129 "Object.m"
static id i_Object_self(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)self;
}

static id i_Object_yourself(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)self;
}

static id i_Object_class(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT5;

#line 141 "Object.m"
return(objcT5=self->isa,(*_imp(objcT5,selTransTbl[2]))(objcT5,selTransTbl[2]));
}
static id i_Object_superclass(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT6;

#line 145 "Object.m"
return(objcT6=self->isa,(*_imp(objcT6,selTransTbl[3]))(objcT6,selTransTbl[3]));
}
static id i_Object_superClass(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT7;

#line 149 "Object.m"
return(objcT7=self->isa,(*_imp(objcT7,selTransTbl[4]))(objcT7,selTransTbl[4]));
}

static id c_Object_class(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)self;
}

static id c_Object_superclass(struct Object_PRIVATE *self,SEL _cmd)
{
return((Cls_t)((id)self))->clsSuper;
}

static id c_Object_superClass(struct Object_PRIVATE *self,SEL _cmd)
{
return((Cls_t)((id)self))->clsSuper;
}

static id i_Object_add_(struct Object_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT8;

#line 169 "Object.m"
return(objcT8=(id)self,(*_imp(objcT8,selTransTbl[0]))(objcT8,selTransTbl[0]));
}

static STR i_Object_name(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT9;

#line 174 "Object.m"
return(objcT9=self->isa,(*(STR(*)(id,SEL))_imp(objcT9,selTransTbl[5]))(objcT9,selTransTbl[5]));
}

static STR c_Object_name(struct Object_PRIVATE *self,SEL _cmd)
{
return((Cls_t)((id)self))->clsName;
}

static id i_Object_findClass_(struct Object_PRIVATE *self,SEL _cmd,STR name)
{
return( *oc_cvtToId)(name);
}

static SEL i_Object_findSel_(struct Object_PRIVATE *self,SEL _cmd,STR name)
{

return( *oc_cvtToSel)(name);
}

static SEL i_Object_selOfSTR_(struct Object_PRIVATE *self,SEL _cmd,STR name)
{
id objcT10;

#line 195 "Object.m"
SEL aSel=(objcT10=(id)self,(*(SEL(*)(id,SEL,STR))_imp(objcT10,selTransTbl[6]))(objcT10,selTransTbl[6],name));
if(aSel){
return aSel;
}else{
id objcT11;

#line 199 "Object.m"
(objcT11=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT11,selTransTbl[7]))(objcT11,selTransTbl[7],"Selector not found in selector table."));
return NULL;
}
}

static id i_Object_idOfSTR_(struct Object_PRIVATE *self,SEL _cmd,STR aClassName)
{
id objcT12;

#line 206 "Object.m"
id aClass=(objcT12=(id)self,(*(id(*)(id,SEL,STR))_imp(objcT12,selTransTbl[8]))(objcT12,selTransTbl[8],aClassName));
if(aClass){
return aClass;
}else{
id objcT13;

#line 210 "Object.m"
return(objcT13=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT13,selTransTbl[7]))(objcT13,selTransTbl[7],"Class not linked in application."));
}
}

#line 221 "Object.m"
static unsigned i_Object_hash(struct Object_PRIVATE *self,SEL _cmd)
{
#line 227 "Object.m"
return(unsigned)((id)self-(id)0);
}

static BOOL i_Object_isEqual_(struct Object_PRIVATE *self,SEL _cmd,id anObject)
{
return(BOOL)(anObject==(id)self);
}

static STR i_Object_str(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT14;

#line 237 "Object.m"
return(objcT14=self->isa,(*(STR(*)(id,SEL))_imp(objcT14,selTransTbl[5]))(objcT14,selTransTbl[5]));
}

static unsigned i_Object_size(struct Object_PRIVATE *self,SEL _cmd)
{
return 0;
}

static BOOL c_Object_isEqual_(struct Object_PRIVATE *self,SEL _cmd,id anObject)
{
return(BOOL)((id)self==anObject);
}

static BOOL i_Object_isSame_(struct Object_PRIVATE *self,SEL _cmd,id anObject)
{
return(BOOL)((id)self==anObject);
}

static BOOL i_Object_notEqual_(struct Object_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT15;

#line 257 "Object.m"
return(objcT15=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT15,selTransTbl[9]))(objcT15,selTransTbl[9],anObject))==(BOOL)0;
}

static BOOL i_Object_notSame_(struct Object_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT16;

#line 262 "Object.m"
return(BOOL) !(objcT16=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT16,selTransTbl[10]))(objcT16,selTransTbl[10],anObject));
}

static int i_Object_compare_(struct Object_PRIVATE *self,SEL _cmd,id anObject)
{
id objcT17;

#line 267 "Object.m"
(objcT17=(id)self,(*_imp(objcT17,selTransTbl[11]))(objcT17,selTransTbl[11]));return 0;
}

#line 277 "Object.m"
static BOOL i_Object_respondsTo_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector)
{
Cls_t cls;
unsigned n;
id ncls=self->isa;
struct objcrt_slt*smt;

do{
cls=((Cls_t)(ncls));
for(smt=cls->clsDispTable,n=cls->clsSizDict;n--;smt++){

if(smt->_cmd==aSelector)return(BOOL)1;
}
}while((ncls=cls->clsSuper));

return(BOOL)0;
}

static BOOL i_Object_isMemberOf_(struct Object_PRIVATE *self,SEL _cmd,id aClass)
{
return(BOOL)(self->isa==aClass);
}

static BOOL i_Object_isKindOf_(struct Object_PRIVATE *self,SEL _cmd,id aClass)
{
id ncls=self->isa;
Cls_t cls=((Cls_t)(self->isa));

for(;ncls;(ncls=cls->clsSuper)){
cls=((Cls_t)(ncls));
if(ncls==aClass)return(BOOL)1;
}

return(BOOL)0;
}

#line 318 "Object.m"
static id c_Object_someInstance(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT18;


return(objcT18=(id)self,(*_imp(objcT18,selTransTbl[0]))(objcT18,selTransTbl[0]));

}

static id i_Object_nextInstance(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT19;


return(objcT19=(id)self,(*_imp(objcT19,selTransTbl[0]))(objcT19,selTransTbl[0]));

}

static id i_Object_become_(struct Object_PRIVATE *self,SEL _cmd,id other)
{
id objcT20;

#line 345 "Object.m"
return(objcT20=(id)self,(*_imp(objcT20,selTransTbl[0]))(objcT20,selTransTbl[0]));

}

static id c_Object_become_(struct Object_PRIVATE *self,SEL _cmd,id other)
{
id objcT21;


return(objcT21=(id)self,(*_imp(objcT21,selTransTbl[0]))(objcT21,selTransTbl[0]));

}

#line 364 "Object.m"
static id c_Object_subclasses(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT22,objcT23,objcT24;

#line 366 "Object.m"
id c=(objcT22=(objcT23=Object,(*(id(*)(id,SEL,STR))_imp(objcT23,selTransTbl[12]))(objcT23,selTransTbl[12],"OrdCltn")),(*_imp(objcT22,selTransTbl[13]))(objcT22,selTransTbl[13]));
addSubclassesTo(c,(objcT24=(id)self,(*(STR(*)(id,SEL))_imp(objcT24,selTransTbl[5]))(objcT24,selTransTbl[5])));
return c;
}
static id c_Object_poseAs_(struct Object_PRIVATE *self,SEL _cmd,id superClass)
{
poseAs(((id)self),(superClass));
return(id)self;
}

static id c_Object_addMethodsTo_(struct Object_PRIVATE *self,SEL _cmd,id superClass)
{
addMethods((id)self,superClass);
return(id)self;
}

static id c_Object_subclass_(struct Object_PRIVATE *self,SEL _cmd,STR name)
{
return newsubclass(name,(id)self,0,0);
}

static BOOL inherits(Cls_t aCls,STR name)
{
id ncls=aCls->clsSuper;

while(ncls){
Cls_t cls=((Cls_t)(ncls));
if(strcmp(cls->clsName,name)==0)return(BOOL)1;
ncls=cls->clsSuper;
}

return(BOOL)0;
}

static BOOL c_Object_inheritsFrom_(struct Object_PRIVATE *self,SEL _cmd,id aClass)
{
id objcT25;

#line 402 "Object.m"
return inherits(((Cls_t)((id)self)),(STR)(objcT25=aClass,(*(STR(*)(id,SEL))_imp(objcT25,selTransTbl[5]))(objcT25,selTransTbl[5])));
}

#line 412 "Object.m"
static id i_Object_subclassResponsibility(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT26;

#line 414 "Object.m"
return(objcT26=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT26,selTransTbl[7]))(objcT26,selTransTbl[7],"Subclass should have implemented one of my methods."));
}

static id i_Object_subclassResponsibility_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector)
{
id objcT27;

#line 419 "Object.m"
return(objcT27=(id)self,(*_imp(objcT27,selTransTbl[14]))(objcT27,selTransTbl[14]));
}

static id i_Object_notImplemented(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT28;

#line 424 "Object.m"
return(objcT28=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT28,selTransTbl[7]))(objcT28,selTransTbl[7],"Does not implement this message."));
}


static id i_Object_notImplemented_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector)
{
id objcT29;

#line 430 "Object.m"
return(objcT29=(id)self,(*_imp(objcT29,selTransTbl[11]))(objcT29,selTransTbl[11]));
}

static id i_Object_shouldNotImplement(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT30;

#line 435 "Object.m"
return(objcT30=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT30,selTransTbl[7]))(objcT30,selTransTbl[7],"Message is not appropriate for this class."));
}

static id i_Object_shouldNotImplement_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector)
{
id objcT31;

#line 440 "Object.m"
return(objcT31=(id)self,(*_imp(objcT31,selTransTbl[0]))(objcT31,selTransTbl[0]));
}

static id i_Object_shouldNotImplement_from_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector,id superClass)
{
id objcT32;

#line 445 "Object.m"
return(objcT32=(id)self,(*_imp(objcT32,selTransTbl[0]))(objcT32,selTransTbl[0]));
}

static id i_Object_vsprintf__(struct Object_PRIVATE *self,SEL _cmd,STR format,va_list*ap)
{
id objcT33;

#line 450 "Object.m"
return(objcT33=(id)self,(*_imp(objcT33,selTransTbl[0]))(objcT33,selTransTbl[0]));
}

static id i_Object_error_(struct Object_PRIVATE *self,SEL _cmd,STR format,...)
{
id objcT34;

#line 455 "Object.m"
va_list ap;
static id MsgClass;
if( !MsgClass)MsgClass=(objcT34=(id)self,(*(id(*)(id,SEL,STR))_imp(objcT34,selTransTbl[8]))(objcT34,selTransTbl[8],"String"));
#line 461 "Object.m"
va_start(ap,format);
if(MsgClass){
id objcT35,objcT36;

#line 463 "Object.m"
(objcT35=(id)self,(*_imp(objcT35,selTransTbl[15]))(objcT35,selTransTbl[15],(objcT36=MsgClass,(*(id(*)(id,SEL,STR,va_list*))_imp(objcT36,selTransTbl[16]))(objcT36,selTransTbl[16],format, &ap))));
}else{( *
oc_error)((id)self,format,ap);
}
va_end(ap);

return(id)self;
}

#line 44 "Block.h"
extern id  Block;

#line 472 "Object.m"
static id i_Object_halt_(struct Object_PRIVATE *self,SEL _cmd,id message)
{
id objcT37;

#line 474 "Object.m"
id handler=(objcT37=Block,(*_imp(objcT37,selTransTbl[17]))(objcT37,selTransTbl[17]));

if(handler){
id objcT38,objcT39;

#line 477 "Object.m"
(objcT38=handler,(*_imp(objcT38,selTransTbl[18]))(objcT38,selTransTbl[18],message,(id)self));
(objcT39=Block,(*_imp(objcT39,selTransTbl[19]))(objcT39,selTransTbl[19],handler));
}else{
id objcT40,objcT41;

#line 480 "Object.m"
handler=(objcT40=Block,(*_imp(objcT40,selTransTbl[20]))(objcT40,selTransTbl[20]));
(objcT41=handler,(*_imp(objcT41,selTransTbl[18]))(objcT41,selTransTbl[18],message,(id)self));
}

return(id)self;
}

#line 495 "Object.m"
static id i_Object_doesNotRecognize_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector)
{
id objcT42;

#line 497 "Object.m"
return(objcT42=(id)self,(*(id(*)(id,SEL,STR,...))_imp(objcT42,selTransTbl[7]))(objcT42,selTransTbl[7],"Message not recognized by this class."));
}
static id i_Object_doesNotUnderstand_(struct Object_PRIVATE *self,SEL _cmd,id aMessage)
{
id objcT43,objcT44;

#line 501 "Object.m"
return(objcT43=(id)self,(*(id(*)(id,SEL,SEL))_imp(objcT43,selTransTbl[21]))(objcT43,selTransTbl[21],(objcT44=aMessage,(*(SEL(*)(id,SEL))_imp(objcT44,selTransTbl[22]))(objcT44,selTransTbl[22]))));
}

#line 511 "Object.m"
static IMP i_Object_methodFor_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector)
{
return _imp((id)self,aSelector);
}

static IMP c_Object_instanceMethodFor_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector)
{
return _impSuper((id)self,aSelector);
}

#line 528 "Object.m"
static id i_Object_perform_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector)
{
return( *fwdimp((id)self,aSelector,selptrfwd))((id)self,aSelector);
}

static id i_Object_perform_with_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector,id anObject)
{

return( *fwdimp((id)self,aSelector,selptrfwd))((id)self,aSelector,anObject);
}

static id i_Object_perform_with_with_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector,id anObject,id otherObject)
{

return( *fwdimp((id)self,aSelector,selptrfwd))((id)self,aSelector,anObject,otherObject);
}

static id i_Object_perform_with_with_with_(struct Object_PRIVATE *self,SEL _cmd,SEL aSelector,id anObject,id otherObject,id thirdObj)
{

return( *fwdimp((id)self,aSelector,selptrfwd))((id)self,aSelector,anObject,otherObject,thirdObj);
}

#line 556 "Object.m"
static id i_Object_print(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT45;

#line 558 "Object.m"
return(objcT45=(id)self,(*(id(*)(id,SEL,IOD))_imp(objcT45,selTransTbl[23]))(objcT45,selTransTbl[23],stdout));
}

static id c_Object_print(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT46;

#line 563 "Object.m"
printf((objcT46=(id)self,(*(STR(*)(id,SEL))_imp(objcT46,selTransTbl[5]))(objcT46,selTransTbl[5])));
return(id)self;
}


static id i_Object_printLine(struct Object_PRIVATE *self,SEL _cmd)
{
id objcT47;

#line 570 "Object.m"
(objcT47=(id)self,(*_imp(objcT47,selTransTbl[24]))(objcT47,selTransTbl[24]));
printf("\n");
return(id)self;
}

static id i_Object_show(struct Object_PRIVATE *self,SEL _cmd)
{
return( *_showOn)((id)self,0);
}

static id i_Object_printToFile_(struct Object_PRIVATE *self,SEL _cmd,FILE*aFile)
{
id objcT48;

#line 591 "Object.m"
return(objcT48=(id)self,(*(id(*)(id,SEL,IOD))_imp(objcT48,selTransTbl[23]))(objcT48,selTransTbl[23],aFile));
}

static id i_Object_printOn_(struct Object_PRIVATE *self,SEL _cmd,IOD anIOD)
{
return(id)self;
}

#line 605 "Object.m"
static STR c_Object_objcrtRevision(struct Object_PRIVATE *self,SEL _cmd)
{
return"2.3.1";
}

#line 616 "Object.m"
static id c_Object_readFrom_(struct Object_PRIVATE *self,SEL _cmd,STR aFileName)
{
return( *_readFrom)(aFileName);
}
static BOOL i_Object_storeOn_(struct Object_PRIVATE *self,SEL _cmd,STR aFileName)
{
return( *_storeOn)(aFileName,(id)self);
}

#line 630 "Object.m"
static id i_Object_fileOutOn_(struct Object_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT49,objcT50;

#line 632 "Object.m"
(objcT49=aFiler,(*(id(*)(id,SEL,void*,char))_imp(objcT49,selTransTbl[25]))(objcT49,selTransTbl[25], &self->isa,'#'));
return(objcT50=(id)self,(*_imp(objcT50,selTransTbl[26]))(objcT50,selTransTbl[26],aFiler));
}
static id c_Object_fileInFrom_(struct Object_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT51;

#line 637 "Object.m"
id newObject=( *oc_alloc)((id)self,0);
return(objcT51=newObject,(*_imp(objcT51,selTransTbl[27]))(objcT51,selTransTbl[27],aFiler));
}

static id i_Object_fileInFrom_(struct Object_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT52;

#line 643 "Object.m"
return(objcT52=(id)self,(*_imp(objcT52,selTransTbl[28]))(objcT52,selTransTbl[28],aFiler));
}
static id i_Object_fileOut_type_(struct Object_PRIVATE *self,SEL _cmd,void*value,char typeDesc)
{
id objcT53;

#line 647 "Object.m"
return(objcT53=(id)self,(*_imp(objcT53,selTransTbl[14]))(objcT53,selTransTbl[14]));
}

static id i_Object_fileIn_type_(struct Object_PRIVATE *self,SEL _cmd,void*value,char typeDesc)
{
id objcT54;

#line 652 "Object.m"
return(objcT54=(id)self,(*_imp(objcT54,selTransTbl[14]))(objcT54,selTransTbl[14]));
}

static id i_Object_awake(struct Object_PRIVATE *self,SEL _cmd)
{
return(id)self;
}

static id i_Object_awakeFrom_(struct Object_PRIVATE *self,SEL _cmd,id aFiler)
{
id objcT55;

#line 662 "Object.m"
return(objcT55=(id)self,(*_imp(objcT55,selTransTbl[29]))(objcT55,selTransTbl[29]));
}
static struct _SLT _Object_clsDispatchTbl[] ={
{"initialize",(id (*)())c_Object_initialize},
{"new",(id (*)())c_Object_new},
{"free",(id (*)())c_Object_free},
{"release",(id (*)())c_Object_release},
{"class",(id (*)())c_Object_class},
{"superclass",(id (*)())c_Object_superclass},
{"superClass",(id (*)())c_Object_superClass},
{"name",(id (*)())c_Object_name},
{"isEqual:",(id (*)())c_Object_isEqual_},
{"someInstance",(id (*)())c_Object_someInstance},
{"become:",(id (*)())c_Object_become_},
{"subclasses",(id (*)())c_Object_subclasses},
{"poseAs:",(id (*)())c_Object_poseAs_},
{"addMethodsTo:",(id (*)())c_Object_addMethodsTo_},
{"subclass:",(id (*)())c_Object_subclass_},
{"inheritsFrom:",(id (*)())c_Object_inheritsFrom_},
{"instanceMethodFor:",(id (*)())c_Object_instanceMethodFor_},
{"print",(id (*)())c_Object_print},
{"objcrtRevision",(id (*)())c_Object_objcrtRevision},
{"readFrom:",(id (*)())c_Object_readFrom_},
{"fileInFrom:",(id (*)())c_Object_fileInFrom_},
{(char*)0,(id (*)())0}
};
static struct _SLT _Object_nstDispatchTbl[] ={
{"initialize",(id (*)())i_Object_initialize},
{"str:",(id (*)())i_Object_str_},
{"new",(id (*)())i_Object_new},
{"increfs",(id (*)())i_Object_increfs},
{"copy",(id (*)())i_Object_copy},
{"deepCopy",(id (*)())i_Object_deepCopy},
{"free",(id (*)())i_Object_free},
{"decrefs",(id (*)())i_Object_decrefs},
{"release",(id (*)())i_Object_release},
{"self",(id (*)())i_Object_self},
{"yourself",(id (*)())i_Object_yourself},
{"class",(id (*)())i_Object_class},
{"superclass",(id (*)())i_Object_superclass},
{"superClass",(id (*)())i_Object_superClass},
{"add:",(id (*)())i_Object_add_},
{"name",(id (*)())i_Object_name},
{"findClass:",(id (*)())i_Object_findClass_},
{"findSel:",(id (*)())i_Object_findSel_},
{"selOfSTR:",(id (*)())i_Object_selOfSTR_},
{"idOfSTR:",(id (*)())i_Object_idOfSTR_},
{"hash",(id (*)())i_Object_hash},
{"isEqual:",(id (*)())i_Object_isEqual_},
{"str",(id (*)())i_Object_str},
{"size",(id (*)())i_Object_size},
{"isSame:",(id (*)())i_Object_isSame_},
{"notEqual:",(id (*)())i_Object_notEqual_},
{"notSame:",(id (*)())i_Object_notSame_},
{"compare:",(id (*)())i_Object_compare_},
{"respondsTo:",(id (*)())i_Object_respondsTo_},
{"isMemberOf:",(id (*)())i_Object_isMemberOf_},
{"isKindOf:",(id (*)())i_Object_isKindOf_},
{"nextInstance",(id (*)())i_Object_nextInstance},
{"become:",(id (*)())i_Object_become_},
{"subclassResponsibility",(id (*)())i_Object_subclassResponsibility},
{"subclassResponsibility:",(id (*)())i_Object_subclassResponsibility_},
{"notImplemented",(id (*)())i_Object_notImplemented},
{"notImplemented:",(id (*)())i_Object_notImplemented_},
{"shouldNotImplement",(id (*)())i_Object_shouldNotImplement},
{"shouldNotImplement:",(id (*)())i_Object_shouldNotImplement_},
{"shouldNotImplement:from:",(id (*)())i_Object_shouldNotImplement_from_},
{"vsprintf::",(id (*)())i_Object_vsprintf__},
{"error:",(id (*)())i_Object_error_},
{"halt:",(id (*)())i_Object_halt_},
{"doesNotRecognize:",(id (*)())i_Object_doesNotRecognize_},
{"doesNotUnderstand:",(id (*)())i_Object_doesNotUnderstand_},
{"methodFor:",(id (*)())i_Object_methodFor_},
{"perform:",(id (*)())i_Object_perform_},
{"perform:with:",(id (*)())i_Object_perform_with_},
{"perform:with:with:",(id (*)())i_Object_perform_with_with_},
{"perform:with:with:with:",(id (*)())i_Object_perform_with_with_with_},
{"print",(id (*)())i_Object_print},
{"printLine",(id (*)())i_Object_printLine},
{"show",(id (*)())i_Object_show},
{"printToFile:",(id (*)())i_Object_printToFile_},
{"printOn:",(id (*)())i_Object_printOn_},
{"storeOn:",(id (*)())i_Object_storeOn_},
{"fileOutOn:",(id (*)())i_Object_fileOutOn_},
{"fileInFrom:",(id (*)())i_Object_fileInFrom_},
{"fileOut:type:",(id (*)())i_Object_fileOut_type_},
{"fileIn:type:",(id (*)())i_Object_fileIn_type_},
{"awake",(id (*)())i_Object_awake},
{"awakeFrom:",(id (*)())i_Object_awakeFrom_},
{(char*)0,(id (*)())0}
};
id Object = (id)&_Object;
id  *OBJCCLASS_Object(void) { return &Object; }
struct _SHARED  _Object = {
  (id)&__Object,
  0,
  "Object",
  0,
  sizeof(struct Object_PRIVATE),
  62,
  _Object_nstDispatchTbl,
  41,
  &Object_modDesc,
  0,
  (id)0,
  &Object,
};
id  OBJCCFUNC_Object(void) { return (id)&_Object; }
id  OBJCCSUPER_Object(void) { return _Object.clsSuper; }
struct _SHARED __Object = {
  (id)&__Object,
  (id)&_Object,
  "Object",
  0,
  sizeof(struct _SHARED),
  21,
  _Object_clsDispatchTbl,
  34,
  &Object_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_Object(void) { return (id)&__Object; }
id  OBJCMSUPER_Object(void) { return __Object.clsSuper; }
static char *_selTransTbl[] ={
"shouldNotImplement",
"increfs",
"class",
"superclass",
"superClass",
"name",
"findSel:",
"error:",
"findClass:",
"isEqual:",
"isSame:",
"notImplemented",
"idOfSTR:",
"new",
"subclassResponsibility",
"halt:",
"vsprintf::",
"pop",
"value:value:",
"push:",
"errorHandler",
"doesNotRecognize:",
"selector",
"printOn:",
"print",
"fileOut:type:",
"fileOutIdsFor:",
"fileInFrom:",
"fileInIdsFrom:",
"awake",
0
};
struct modDescriptor Object_modDesc = {
  "Object",
  "objc2.3.1",
  0L,
  0,
  0,
  &Object,
  30,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_Object(void)
{
  selTransTbl = _selTransTbl;
  return &Object_modDesc;
}
int _OBJCPOSTLINK_Object = 1;


