#line 1 "compstmt.m"
struct _PRIVATE { struct _PRIVATE *isa; };
typedef struct _PRIVATE *id;
struct _SHARED {
  id isa;
  id clsSuper;
  char *clsName;
  char *clsTypes;
  short clsSizInstance;
  short clsSizDict;
  struct _SLT *clsDispTable;
  long clsStatus;
  struct modDescriptor *clsMod;
  unsigned clsVersion;
  id clsCats;
  id *clsGlbl;
};
extern id  (* _imp(id,char*))();
extern id  (* _impSuper(id,char*))();
extern struct modDescriptor  *_OBJCBIND_compstmt(void);
static char **selTransTbl;
struct _SLT {char *_cmd;id (*_imp)();};
struct modDescriptor {
  char *modName;
  char *modVersion;
  long modStatus;
  char *modMinSel;
  char *modMaxSel;
  id *modClsLst;
  short modSelRef;
  char **modSelTbl;
  struct methodDescriptor *modMapTbl;
};
extern struct modDescriptor compstmt_modDesc;

#line 1 "../../util/stdarg.h"
#include <stdarg.h>

#line 1 "../../util/stdlib.h"
#include <stdlib.h>

#line 1 "../../util/assert.h"
#include <assert.h>

#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 1 "../../util/stddef.h"
#include <stddef.h>

#line 70 "../../include/objcrt/objcrt.h"
typedef char*SEL;
typedef char*STR;
typedef char BOOL;
typedef FILE*IOD;
typedef id SHR;
#line 79 "../../include/objcrt/objcrt.h"
typedef id(*IMP)();


typedef void(*ARGIMP)(id,SEL,void*);
#line 102 "../../include/objcrt/objcrt.h"
extern BOOL msgFlag;
extern FILE*msgIOD;
extern FILE*dbgIOD;
extern BOOL allocFlag;
extern BOOL dbgFlag;
extern BOOL noCacheFlag;
extern BOOL noNilRcvr;
#line 115 "../../include/objcrt/objcrt.h"
SEL selUid(STR);
STR selName(SEL);
void dbg(char*fmt,...);
void prnstack(FILE*file);
void loadobjc(void*modPtr);
void unloadobjc(void*modPtr);
#line 124 "../../include/objcrt/objcrt.h"
IMP fwdimp(id,SEL,IMP);
IMP fwdimpSuper(id,SEL,IMP);
void fwdmsg(id,SEL,void*,ARGIMP);
id selptrfwd(id,SEL,id,id,id,id);


id idincref(id obj);
id idassign(id*lhs,id rhs);
id iddecref(id obj);

extern id(*_fileIn)(FILE*);
extern BOOL(*_fileOut)(FILE*,id);
extern BOOL(*_storeOn)(STR,id);
extern id(*_readFrom)(STR);
void setfilein(id(*f)(FILE*));
void setfileout(BOOL(*f)(FILE*,id));

extern id(*_showOn)(id,unsigned);

void*OC_Malloc(size_t);
void*OC_MallocAtomic(size_t);
void*OC_Calloc(size_t);
void*OC_Realloc(void*,size_t);
void*OC_Free(void*data);
#line 1 "../../util/string.h"
#include <string.h>

#line 1 "../../util/stdio.h"
#include <stdio.h>

#line 32 "../../include/objpak/ocstring.h"
typedef struct objstr{
int count;
int capacity;
char*ptr;
}*objstr_t;
#line 31 "../../include/objpak/ordcltn.h"
typedef struct objcol{
int count;
int capacity;
id*ptr;
}*objcol_t;
#line 28 "../../include/objpak/set.h"
typedef struct objset{
int count;
int capacity;
id*ptr;
}*objset_t;
#line 22 "node.h"
extern FILE*gfile;
extern int inlineno;
extern id infilename;
extern int outlineno;
extern char*outfilename;
extern int exitstatus;

void gc(char c);
void gextc(void);
void gcom(char*cm);
void gvarlist(id c,char*sp,char*iz);
void gcommalist(id c);
void gs(char*str);
void gf(char*fmt,...);
void gl(int no,char*fn);
void g_otbvars(void);
void gstderr(void);
void gnormal(void);

void warn(char*fmt,...);
void warnat(id sym,char*fmt,...);
void fatal(char*fmt,...);
void fatalat(id sym,char*fmt,...);
#line 22 "symbol.h"
extern id s_void;
extern id s_char;
extern id s_bool;
extern id s_int;
extern id s_long;
extern id s_double;
extern id s_str;
extern id s_sel;
extern id s_newblock;
extern id s_main;
extern id s_objcmain;
extern id s_id;
extern id s_nil;
extern id s_self;
extern id s_cmd;
extern id s_super;
extern id s_type;
extern id s_aFiler;
extern id s_fileIn;
extern id s_fileOut;
extern id s_fileInIdsFrom;
extern id s_fileOutIdsFor;
extern id s_returnval;
extern id s_returnflag;
extern id s_increfs;
extern id s_decrefs;
extern id s_idincref;
extern id s_iddecref;

BOOL istypeword(id sym);
BOOL isbuiltinfun(id sym);
int pragmatoggle(char*s);
void definebuiltintype(char*s);
void definebuiltinfun(char*s);
void definebuiltinvar(char*s);
#line 22 "expr.h"
extern id e_nil;
extern id e_self;
extern id e_cmd;
extern id e_super;
extern id e_aFiler;
extern id e_ft_id;
#line 22 "compstmt.h"
extern id curcompound;
extern id curloopcompound;
#line 22 "def.h"
extern id curdef;
#line 22 "classdef.h"
extern id curclassdef;
extern id curstruct;
#line 22 "trlunit.h"
extern id trlunit;
#line 22 "type.h"
extern id t_unknown;
extern id t_void;
extern id t_char;
extern id t_bool;
extern id t_int;
extern id t_long;
extern id t_double;
extern id t_str;
extern id t_sel;
extern id t_id;
#line 23 "util.h"
extern FILE*yyin;
extern int yyparse();

FILE*openfile(STR name,STR modfs);
FILE*reopenfile(STR name,STR modfs,FILE*of);

extern int okblock;

id mkcppdirect(char*s);
id mkexprstmt(id expr);
id mklabeledstmt(id label,id stmt);
id mkcasestmt(id keyw,id expr,id stmt);
id mkdefaultstmt(id keyw,id stmt);
id mkifstmt(id keyw,id expr,id stmt);
id mkifelsestmt(id keyw,id expr,id stmt,id ekeyw,id estmt);
id mkswitchstmt(id keyw,id expr,id stmt);
id mkwhilestmt(id keyw,id expr,id stmt);
id mkdostmt(id keyw,id stmt,id wkeyw,id expr);
id mkforstmt(id keyw,id a,id b,id c,id stmt);
id mkgotostmt(id keyw,id label);
id mkcontinuestmt(id keyw);
id mkbreakstmt(id keyw);
id mkreturnstmt(id keyw,id expr);
id mkcastexpr(id a,id b);
id mkcondexpr(id a,id b,id c);
id mkunaryexpr(STR op,id a);
id mksizeof(id a);
id mkaddressof(id a);
id mkdereference(id a);
id mkbinexpr(id a,STR op,id b);
id mkcommaexpr(id a,id b);
id mkrelexpr(id a,STR op,id b);
id mkassignexpr(id a,STR op,id b);
id mkfuncall(id funname,id args);
id mkbuiltincall(id funname,id args);
id mkfunbody(id datadefs,id compound);
void declarefun(id specs,id decl);
void declaremeth(BOOL factory,id decl);
id mkfundef(id specs,id decl,id body);
id mkmethdef(BOOL factory,id decl,id body);
id mkmesgexpr(id receiver,id args);
id mkdecl(id ident);
id mkprecdecl(id tquals,id decl);
id mkarraydecl(id lhs,id ix);
id mkfundecl(id lhs,id args);
id mkprefixdecl(id lhs,id rhs);
id mkpostfixdecl(id lhs,id rhs);
id mkpointer(id specs,id pointer);
id mkbitfielddecl(id decl,id expr);
id mkstardecl(id pointer,id decl);
id mkasmop(id string,id expr);
id mkasmstmt(id keyw,id tqual,id expr,id asmop1,id asmop2,id clobbers);
id mkcompstmt(id lb,id datadefs,id stmtlist,id rb);
id mklist(id c,id s);
id mklist2(id c,id s,id t);
id atdefsaddall(id c,id n);
id mkblockexpr(id lb,id parms,id datadefs,id stmts,id expr,id rb);
id mkclassdef(id keyw,id name,id sname,id ivars,id cvars);
id mkdatadef(id datadef,id specs,id decl,id initializer);
id mkencodeexpr(id name);
id mkenumspec(id keyw,id name,id lb,id list,id rb);
id mkenumerator(id name,id value);
id mkgnuattrib(id anyword,id exprlist);
id mkgnuattribdecl(id keyw,id list);
id mklistexpr(id lb,id x,id rb);
id mktypename(id specs,id decl);
id mkcomponentdef(id cdef,id specs,id decl);
id mkstructspec(id keyw,id name,id lb,id defs,id rb);
id mkkeywarg(id sel,id arg);
id mkkeywdecl(id sel,id cast,id arg);
id mkmethproto(id cast,id usel,id ksel,BOOL varargs);
id mkidentexpr(id name);
id mkconstexpr(id name,id schain);
id mkprecexpr(id expr);
id mkarrowexpr(id array,id ix);
id mkdotexpr(id array,id ix);
id mkindexexpr(id array,id ix);
id mkpostfixexpr(id expr,id pf);
id mkparmdef(id parmdef,id specs,id decl);
id mkparmdeflist(id idents,id parmdefs,BOOL varargs);
id mkselarg(id selarg,id usel,int ncols);
id mkselectorexpr(id expr);

void procextdef(id def);
void finclassdef(void);
void datadefokblock(id datadef,id specs,id decl);

id mkfileinmeth(id classdef,id ivarnames,id ivartypes);
id mkfileoutmeth(id classdef,id ivarnames,id ivartypes);

id mkincrefsmeth(id classdef,id ivarnames,id ivartypes);
id mkdecrefsmeth(id classdef,id ivarnames,id ivartypes);
#line 22 "options.h"
void defoptions(void);

extern int o_gnu;
extern int o_refcnt;
extern int o_ppi;
extern int o_watcom;
extern int o_ibmvac;
extern int o_msdos;
extern int o_enableasm;
extern int o_nolinetags;
extern int o_buffered;
extern int o_quiet;
extern int o_outputcode;
extern int o_version;
extern int o_otb;
extern int o_llkeyw;
extern int o_comments;
extern int o_seltranslation;
extern int o_categories;
extern int o_blocks;
extern int o_fwd;
extern int o_selptr;
extern int o_cache;
extern int o_filer;
extern int o_selfassign;
extern char*o_bind;
extern int o_refbind;
extern int o_inlinecache;
extern int o_cplus;
extern int o_gencode;
extern int o_st80;
extern int o_selfassign;
extern int o_nilrcvr;
extern int o_shareddata;
extern int o_oneperfile;
extern int o_cvars;
extern int o_warnlex;
extern int o_warnfwd;
extern int o_warnsuggest;
extern int o_warnintvar;
extern int o_warnclasstype;
extern int o_warntypeconflict;
extern int o_warnundefined;
extern int o_warnlocalnst;
extern int o_warnnotfound;
extern int o_warnmissingmethods;
extern int o_postlink;
extern char*o_infile;
extern char*o_outfile;
extern char*o_srcfilename;
extern char*o_initcall;
extern char*o_tagformat;
extern char*o_mainfun;
extern char*o_pathsep;
extern int o_debuginfo;
extern int o_checkbind;
extern int o_linemax;
extern int o_structassign;
#line 46 "compstmt.m"
id curcompound;
id curloopcompound;
#line 25 "compstmt.h"
struct CompoundStmt_PRIVATE {

#line 42 "../../include/objcrt/Object.h"
id isa;
#line 46 "../../include/objcrt/Object.h"
unsigned short attr;
unsigned short objID;
#line 27 "compstmt.h"
id lbrace;
id datadefs;
id initializers;
id stmts;
id rbrace;
id enclosing;
id returnlabel;
id parmnames;
id tmpvars;
id icaches;
id localdic;
id locals;
id alllocals;
id heapvars,heapnames,heaptypes;
id heapparms;
char*heapvarptrname;
char*heapvartypename;
id localexprs;
id heapvarblocks;
id restype;
id increfs,decrefs;};

#line 25 "compstmt.h"
extern id  CompoundStmt;

#line 25 "compstmt.h"
extern struct _SHARED _CompoundStmt;
extern struct _SHARED __CompoundStmt;


#line 51 "compstmt.m"
static BOOL i_CompoundStmt_iscompstmt(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
return(BOOL)1;
}

static id i_CompoundStmt_lbrace_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id lb)
{self->
lbrace=lb;
return(id)self;
}

static id i_CompoundStmt_rbrace_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id rb)
{self->
rbrace=rb;
return(id)self;
}

static id i_CompoundStmt_datadefs_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id defs)
{self->
datadefs=defs;
return(id)self;
}

static id i_CompoundStmt_stmts_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id stmtlist)
{self->
stmts=stmtlist;
return(id)self;
}

static id i_CompoundStmt_returnlabel(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
return self->returnlabel;
}

static id i_CompoundStmt_lookupparm_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id sym)
{
return(id)0;
}

static id i_CompoundStmt_synth(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
id objcT0,objcT9,objcT10,objcT11,objcT12;

#line 92 "compstmt.m"
int i,n;self->

enclosing=curcompound;
curcompound=(id)self;
if(o_refcnt)self->
returnlabel=(objcT0=trlunit,(*_imp(objcT0,selTransTbl[0]))(objcT0,selTransTbl[0]));
if( !self->enclosing){
id objcT1,objcT2,objcT3;
self->
#line 99 "compstmt.m"
restype=(objcT1=curdef,(*_imp(objcT1,selTransTbl[1]))(objcT1,selTransTbl[1]));self->
parmnames=(objcT2=curdef,(*_imp(objcT2,selTransTbl[2]))(objcT2,selTransTbl[2]));
if(o_refcnt)
for(i=0,n=(objcT3=self->parmnames,(*(unsigned(*)(id,SEL))_imp(objcT3,selTransTbl[3]))(objcT3,selTransTbl[3]));i<n;i++){
id objcT4,objcT5,objcT6;

#line 103 "compstmt.m"
id x=(objcT4=self->parmnames,(*(id(*)(id,SEL,unsigned))_imp(objcT4,selTransTbl[4]))(objcT4,selTransTbl[4],i));

if((objcT5=(objcT6=curdef,(*_imp(objcT6,selTransTbl[5]))(objcT6,selTransTbl[5],x)),(*(BOOL(*)(id,SEL))_imp(objcT5,selTransTbl[6]))(objcT5,selTransTbl[6]))){
id objcT7,objcT8;

#line 106 "compstmt.m"
(objcT7=(id)self,(*_imp(objcT7,selTransTbl[7]))(objcT7,selTransTbl[7],x));
(objcT8=(id)self,(*_imp(objcT8,selTransTbl[8]))(objcT8,selTransTbl[8],x));
}
}
}
if(self->datadefs)
(objcT9=self->datadefs,(*(id(*)(id,SEL,SEL))_imp(objcT9,selTransTbl[9]))(objcT9,selTransTbl[9],_cmd));
if(self->stmts)
(objcT10=self->stmts,(*(id(*)(id,SEL,SEL))_imp(objcT10,selTransTbl[9]))(objcT10,selTransTbl[9],_cmd));
if(self->heapvars)
(objcT11=(id)self,(*_imp(objcT11,selTransTbl[10]))(objcT11,selTransTbl[10]));
if(o_refcnt)
for(i=0,n=(objcT12=self->locals,(*(unsigned(*)(id,SEL))_imp(objcT12,selTransTbl[3]))(objcT12,selTransTbl[3]));i<n;i++){
id objcT13,objcT14,objcT15,objcT16;

#line 119 "compstmt.m"
id x=(objcT13=self->locals,(*(id(*)(id,SEL,unsigned))_imp(objcT13,selTransTbl[4]))(objcT13,selTransTbl[4],i));

if((objcT14=(objcT15=(id)self,(*_imp(objcT15,selTransTbl[11]))(objcT15,selTransTbl[11],x)),(*(BOOL(*)(id,SEL))_imp(objcT14,selTransTbl[6]))(objcT14,selTransTbl[6]))&& !(objcT16=(id)self,(*(BOOL(*)(id,SEL,id))_imp(objcT16,selTransTbl[12]))(objcT16,selTransTbl[12],x))){
id objcT17;

#line 122 "compstmt.m"
(objcT17=(id)self,(*_imp(objcT17,selTransTbl[8]))(objcT17,selTransTbl[8],x));
}
}
curcompound=self->enclosing;
return(id)self;
}

static id i_CompoundStmt_gen(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
id objcT18,objcT21,objcT22,objcT23,objcT24;
id objcT25,objcT32;

#line 131 "compstmt.m"
if(self->lbrace)
(objcT18=self->lbrace,(*_imp(objcT18,selTransTbl[13]))(objcT18,selTransTbl[13]));
else
gc('{');
if(self->heapvars||self->tmpvars||self->icaches||(self->returnlabel&&self->enclosing==(id)0))
gc('\n');
if(self->returnlabel&&self->enclosing==(id)0){
id objcT19;

#line 138 "compstmt.m"
gs("int _returnflag = 0;\n");
if( !(objcT19=self->restype,(*(BOOL(*)(id,SEL))_imp(objcT19,selTransTbl[14]))(objcT19,selTransTbl[14]))){
id objcT20;

#line 140 "compstmt.m"
(objcT20=self->restype,(*_imp(objcT20,selTransTbl[15]))(objcT20,selTransTbl[15],s_returnval));
gs(";\n");
}
}
if(self->heapvars)
(objcT21=(id)self,(*_imp(objcT21,selTransTbl[16]))(objcT21,selTransTbl[16]));
if(self->tmpvars)
gvarlist(self->tmpvars,"id",(o_refcnt)?"=(id)0":"");
if(self->icaches)
gvarlist(self->icaches,"static struct objcrt_inlineCache","");
if(self->datadefs)
(objcT22=self->datadefs,(*(id(*)(id,SEL,SEL))_imp(objcT22,selTransTbl[9]))(objcT22,selTransTbl[9],_cmd));
if(self->increfs)
(objcT23=(id)self,(*_imp(objcT23,selTransTbl[17]))(objcT23,selTransTbl[17]));
if(self->initializers)
(objcT24=self->initializers,(*(id(*)(id,SEL,SEL))_imp(objcT24,selTransTbl[9]))(objcT24,selTransTbl[9],_cmd));
if(self->stmts)
(objcT25=self->stmts,(*(id(*)(id,SEL,SEL))_imp(objcT25,selTransTbl[9]))(objcT25,selTransTbl[9],_cmd));
if(self->returnlabel){
id objcT26,objcT27;

#line 159 "compstmt.m"
gc('\n');
gs((objcT26=self->returnlabel,(*(STR(*)(id,SEL))_imp(objcT26,selTransTbl[18]))(objcT26,selTransTbl[18])));
gs(":\n");
if(self->decrefs)
(objcT27=(id)self,(*_imp(objcT27,selTransTbl[19]))(objcT27,selTransTbl[19]));
if(self->enclosing){
id objcT28,objcT29;

#line 165 "compstmt.m"
gf("if (_returnflag) goto %s;\n",(objcT28=(objcT29=self->enclosing,(*_imp(objcT29,selTransTbl[0]))(objcT29,selTransTbl[0])),(*(STR(*)(id,SEL))_imp(objcT28,selTransTbl[18]))(objcT28,selTransTbl[18])));
}else{
id objcT30,objcT31;
if((objcT30=self->restype,(*(BOOL(*)(id,SEL))_imp(objcT30,selTransTbl[14]))(objcT30,selTransTbl[14])))
gs("if (_returnflag) return;\n");
else
gs("if (_returnflag) return _returnval;\n");
if((objcT31=self->restype,(*(BOOL(*)(id,SEL))_imp(objcT31,selTransTbl[14]))(objcT31,selTransTbl[14])))
gs("return;\n");
else
gs("return _returnval;");
}
}
if(self->rbrace)
(objcT32=self->rbrace,(*_imp(objcT32,selTransTbl[13]))(objcT32,selTransTbl[13]));
else
gc('}');
return(id)self;
}

#line 24 "shared.m"
static id i_CompoundStmt_enclosing(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
return self->enclosing;
}

#line 37 "../../include/objpak/ordcltn.h"
extern id  OrdCltn;

#line 29 "shared.m"
static id i_CompoundStmt_addtmpvar_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id tvar)
{
id objcT33,objcT34;

#line 31 "shared.m"
if( !self->tmpvars)self->
tmpvars=(objcT33=OrdCltn,(*_imp(objcT33,selTransTbl[20]))(objcT33,selTransTbl[20]));
(objcT34=self->tmpvars,(*_imp(objcT34,selTransTbl[21]))(objcT34,selTransTbl[21],tvar));
return(id)self;
}

static id i_CompoundStmt_addicache_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id tvar)
{
id objcT35,objcT36;

#line 39 "shared.m"
if( !self->icaches)self->
icaches=(objcT35=OrdCltn,(*_imp(objcT35,selTransTbl[20]))(objcT35,selTransTbl[20]));
(objcT36=self->icaches,(*_imp(objcT36,selTransTbl[21]))(objcT36,selTransTbl[21],tvar));
return(id)self;
}

static id i_CompoundStmt_addincref_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id v)
{
id objcT37,objcT38;

#line 47 "shared.m"
if( !self->increfs)self->
increfs=(objcT37=OrdCltn,(*_imp(objcT37,selTransTbl[20]))(objcT37,selTransTbl[20]));
(objcT38=self->increfs,(*_imp(objcT38,selTransTbl[21]))(objcT38,selTransTbl[21],v));
return(id)self;
}

static id i_CompoundStmt_genincrefs(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
id objcT39;

#line 55 "shared.m"
int i,n=(objcT39=self->increfs,(*(unsigned(*)(id,SEL))_imp(objcT39,selTransTbl[3]))(objcT39,selTransTbl[3]));

for(i=0;i<n;i++){
id objcT40,objcT41,objcT42,objcT43,objcT44;

#line 58 "shared.m"
if(self->lbrace)gl((objcT40=self->lbrace,(*(int(*)(id,SEL))_imp(objcT40,selTransTbl[22]))(objcT40,selTransTbl[22])),(objcT41=(objcT42=self->lbrace,(*_imp(objcT42,selTransTbl[23]))(objcT42,selTransTbl[23])),(*(STR(*)(id,SEL))_imp(objcT41,selTransTbl[18]))(objcT41,selTransTbl[18])));
gf("idincref(%s);\n",(objcT43=(objcT44=self->increfs,(*(id(*)(id,SEL,unsigned))_imp(objcT44,selTransTbl[4]))(objcT44,selTransTbl[4],i)),(*(STR(*)(id,SEL))_imp(objcT43,selTransTbl[18]))(objcT43,selTransTbl[18])));
}
gc('\n');
return(id)self;
}

static id i_CompoundStmt_adddecref_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id v)
{
id objcT45,objcT46,objcT47;

#line 67 "shared.m"
if( !self->decrefs)self->
decrefs=(objcT45=OrdCltn,(*_imp(objcT45,selTransTbl[20]))(objcT45,selTransTbl[20]));
(objcT46=self->decrefs,(*_imp(objcT46,selTransTbl[21]))(objcT46,selTransTbl[21],v));

if(curloopcompound&&(id)self!=curloopcompound)
(objcT47=curloopcompound,(*_imp(objcT47,selTransTbl[8]))(objcT47,selTransTbl[8],v));
return(id)self;
}

static id i_CompoundStmt_gendecrefs(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
id objcT48;

#line 78 "shared.m"
int i,n=(objcT48=self->decrefs,(*(unsigned(*)(id,SEL))_imp(objcT48,selTransTbl[3]))(objcT48,selTransTbl[3]));

for(i=0;i<n;i++){
id objcT49,objcT50,objcT51,objcT52,objcT53;

#line 81 "shared.m"
char*s=(objcT49=(objcT50=self->decrefs,(*(id(*)(id,SEL,unsigned))_imp(objcT50,selTransTbl[4]))(objcT50,selTransTbl[4],i)),(*(STR(*)(id,SEL))_imp(objcT49,selTransTbl[18]))(objcT49,selTransTbl[18]));

if(self->rbrace)gl((objcT51=self->rbrace,(*(int(*)(id,SEL))_imp(objcT51,selTransTbl[22]))(objcT51,selTransTbl[22])),(objcT52=(objcT53=self->rbrace,(*_imp(objcT53,selTransTbl[23]))(objcT53,selTransTbl[23])),(*(STR(*)(id,SEL))_imp(objcT52,selTransTbl[18]))(objcT52,selTransTbl[18])));
gf("%s=iddecref(%s);\n",s,s);
}
gc('\n');
return(id)self;
}

static id i_CompoundStmt_lookuplocal_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id sym)
{
id objcT54;

#line 92 "shared.m"
return(self->localdic)?(objcT54=self->localdic,(*_imp(objcT54,selTransTbl[24]))(objcT54,selTransTbl[24],sym)):(id)0;
}

#line 32 "../../include/objpak/dictnary.h"
extern id  Dictionary;

#line 95 "shared.m"
static id i_CompoundStmt_deflocal_astype_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id sym,id t)
{
id objcT57,objcT58,objcT59;

#line 97 "shared.m"
if( !self->localdic){
id objcT55,objcT56;
self->
#line 98 "shared.m"
localdic=(objcT55=Dictionary,(*_imp(objcT55,selTransTbl[20]))(objcT55,selTransTbl[20]));self->
locals=(objcT56=OrdCltn,(*_imp(objcT56,selTransTbl[20]))(objcT56,selTransTbl[20]));
}
(objcT57=self->localdic,(*_imp(objcT57,selTransTbl[25]))(objcT57,selTransTbl[25],sym,t));
(objcT58=self->locals,(*_imp(objcT58,selTransTbl[21]))(objcT58,selTransTbl[21],sym));
if(curdef&&((objcT59=curdef,(*(BOOL(*)(id,SEL))_imp(objcT59,selTransTbl[26]))(objcT59,selTransTbl[26])))){
id objcT60,objcT62;

#line 104 "shared.m"
assert(curclassdef);
if((objcT60=curclassdef,(*(BOOL(*)(id,SEL,id))_imp(objcT60,selTransTbl[27]))(objcT60,selTransTbl[27],sym))){
id objcT61;

#line 106 "shared.m"
warnat(sym,"definition of local '%s' hides instance variable",(objcT61=sym,(*(STR(*)(id,SEL))_imp(objcT61,selTransTbl[18]))(objcT61,selTransTbl[18])));
}
if((objcT62=curclassdef,(*(BOOL(*)(id,SEL,id))_imp(objcT62,selTransTbl[28]))(objcT62,selTransTbl[28],sym))){
id objcT63;

#line 109 "shared.m"
warnat(sym,"definition of local '%s' hides class variable",(objcT63=sym,(*(STR(*)(id,SEL))_imp(objcT63,selTransTbl[18]))(objcT63,selTransTbl[18])));
}
}
return(id)self;
}

static id i_CompoundStmt_genheapvarptr(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
char*p=self->heapvarptrname;
char*t=self->heapvartypename;

assert(self->heapnames);

gf("%s *%s=(%s *)OC_Calloc(sizeof(%s));\n",t,p,t,t);
return(id)self;
}

static id i_CompoundStmt_gendecrefsheapvars(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
id objcT64;

#line 128 "shared.m"
int i,n=(objcT64=self->heapnames,(*(unsigned(*)(id,SEL))_imp(objcT64,selTransTbl[3]))(objcT64,selTransTbl[3]));
char*hvp=self->heapvarptrname;

for(i=0;i<n;i++){
id objcT65,objcT66,objcT67;

#line 132 "shared.m"
id x=(objcT65=self->heapnames,(*(id(*)(id,SEL,unsigned))_imp(objcT65,selTransTbl[4]))(objcT65,selTransTbl[4],i));
id t=(objcT66=self->heaptypes,(*(id(*)(id,SEL,unsigned))_imp(objcT66,selTransTbl[4]))(objcT66,selTransTbl[4],i));

assert(t!=(id)0);
if((objcT67=t,(*(BOOL(*)(id,SEL))_imp(objcT67,selTransTbl[6]))(objcT67,selTransTbl[6]))){
id objcT68;

#line 137 "shared.m"
char*s=(objcT68=x,(*(STR(*)(id,SEL))_imp(objcT68,selTransTbl[18]))(objcT68,selTransTbl[18]));
gf("%s->%s=iddecref(%s->%s);\n",hvp,s,hvp,s);
}
}
return(id)self;
}

static id i_CompoundStmt_genheapvartype(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
id objcT69;

#line 146 "shared.m"
int i,n=(objcT69=self->heapnames,(*(unsigned(*)(id,SEL))_imp(objcT69,selTransTbl[3]))(objcT69,selTransTbl[3]));

if( !n)
return(id)self;
gf("%s {\n",self->heapvartypename);
gs("int heaprefcnt;\n");
for(i=0;i<n;i++){
id objcT70,objcT71,objcT72;

#line 153 "shared.m"
id x=(objcT70=self->heapnames,(*(id(*)(id,SEL,unsigned))_imp(objcT70,selTransTbl[4]))(objcT70,selTransTbl[4],i));
id t=(objcT71=self->heaptypes,(*(id(*)(id,SEL,unsigned))_imp(objcT71,selTransTbl[4]))(objcT71,selTransTbl[4],i));

assert(t!=(id)0);
(objcT72=t,(*_imp(objcT72,selTransTbl[15]))(objcT72,selTransTbl[15],x));
gs(";\n");
}
gs("};\n");
return(id)self;
}

static id i_CompoundStmt_heapvars(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
return(id)0;
}

static BOOL i_CompoundStmt_isheapvar_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id x)
{
id objcT73;

#line 171 "shared.m"
return(self->heapvars)?(objcT73=self->heapvars,(*(BOOL(*)(id,SEL,id))_imp(objcT73,selTransTbl[29]))(objcT73,selTransTbl[29],x)):(BOOL)0;
}

#line 34 "../../include/objpak/set.h"
extern id  Set;

#line 38 "../../include/objpak/ocstring.h"
extern id  String;

#line 174 "shared.m"
static id i_CompoundStmt_defheapvar_type_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id x,id t)
{
id objcT82;

#line 176 "shared.m"
int i;

if( !self->heapvars){
id objcT74,objcT75,objcT76,objcT77,objcT78;
id objcT79,objcT80,objcT81;
self->
#line 179 "shared.m"
heapvars=(objcT74=Set,(*_imp(objcT74,selTransTbl[20]))(objcT74,selTransTbl[20]));self->
heapnames=(objcT75=OrdCltn,(*_imp(objcT75,selTransTbl[20]))(objcT75,selTransTbl[20]));self->
heaptypes=(objcT76=OrdCltn,(*_imp(objcT76,selTransTbl[20]))(objcT76,selTransTbl[20]));
i=(objcT77=trlunit,(*(int(*)(id,SEL))_imp(objcT77,selTransTbl[30]))(objcT77,selTransTbl[30]));self->
heapvarptrname=(objcT78=(objcT79=String,(*(id(*)(id,SEL,STR,...))_imp(objcT79,selTransTbl[31]))(objcT79,selTransTbl[31],"heapvars%i",i)),(*(STR(*)(id,SEL))_imp(objcT78,selTransTbl[32]))(objcT78,selTransTbl[32]));self->
heapvartypename=(objcT80=(objcT81=String,(*(id(*)(id,SEL,STR,...))_imp(objcT81,selTransTbl[31]))(objcT81,selTransTbl[31],"struct heaptype%i",i)),(*(STR(*)(id,SEL))_imp(objcT80,selTransTbl[32]))(objcT80,selTransTbl[32]));
}
if((objcT82=t,(*(BOOL(*)(id,SEL))_imp(objcT82,selTransTbl[33]))(objcT82,selTransTbl[33]))){
id objcT83;

#line 187 "shared.m"
char*msg="can't use static local variables (%s) from within block";

fatalat(x,msg,(objcT83=x,(*(STR(*)(id,SEL))_imp(objcT83,selTransTbl[18]))(objcT83,selTransTbl[18])));
}else{
id objcT84;

#line 191 "shared.m"
if((objcT84=self->heapvars,(*_imp(objcT84,selTransTbl[34]))(objcT84,selTransTbl[34],x))!=(id)0){
id objcT85,objcT86;

#line 192 "shared.m"
(objcT85=self->heapnames,(*_imp(objcT85,selTransTbl[21]))(objcT85,selTransTbl[21],x));
(objcT86=self->heaptypes,(*_imp(objcT86,selTransTbl[21]))(objcT86,selTransTbl[21],t));
}
}
return(id)self;
}

static char*i_CompoundStmt_heapvarptrname(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
assert(self->heapvarptrname);
return self->heapvarptrname;
}

static char*i_CompoundStmt_heapvartypename(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
assert(self->heapvartypename);
return self->heapvartypename;
}

static id i_CompoundStmt_removeheapvarsfromdatadefs(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
id objcT87,objcT99;

#line 213 "shared.m"
int n;

assert(self->heapvars);self->
initializers=(objcT87=OrdCltn,(*_imp(objcT87,selTransTbl[20]))(objcT87,selTransTbl[20]));

if(self->parmnames){
id objcT88;

#line 219 "shared.m"
n=(objcT88=self->parmnames,(*(unsigned(*)(id,SEL))_imp(objcT88,selTransTbl[3]))(objcT88,selTransTbl[3]));
while(n--){
id objcT89,objcT90;

#line 221 "shared.m"
id p=(objcT89=self->parmnames,(*(id(*)(id,SEL,unsigned))_imp(objcT89,selTransTbl[4]))(objcT89,selTransTbl[4],n));

if((objcT90=self->heapvars,(*(BOOL(*)(id,SEL,id))_imp(objcT90,selTransTbl[29]))(objcT90,selTransTbl[29],p))){
id objcT91,objcT92,objcT93;

#line 224 "shared.m"
id x=(objcT91=(objcT92=mkidentexpr(p),(*(id(*)(id,SEL,BOOL))_imp(objcT92,selTransTbl[35]))(objcT92,selTransTbl[35],(BOOL)1)),(*_imp(objcT91,selTransTbl[36]))(objcT91,selTransTbl[36]));
id y=mkidentexpr(p);

(objcT93=self->initializers,(*_imp(objcT93,selTransTbl[21]))(objcT93,selTransTbl[21],mkexprstmt(mkassignexpr(x,"=",y))));
}
}
}
if(self->datadefs){
id objcT94;

#line 232 "shared.m"
n=(objcT94=self->datadefs,(*(unsigned(*)(id,SEL))_imp(objcT94,selTransTbl[3]))(objcT94,selTransTbl[3]));
while(n--){
id objcT95,objcT96,objcT97,objcT98;

#line 234 "shared.m"
id def=(objcT95=self->datadefs,(*(id(*)(id,SEL,unsigned))_imp(objcT95,selTransTbl[4]))(objcT95,selTransTbl[4],n));

(objcT96=def,(*_imp(objcT96,selTransTbl[37]))(objcT96,selTransTbl[37],self->heapvars,self->initializers));
if((objcT97=def,(*_imp(objcT97,selTransTbl[38]))(objcT97,selTransTbl[38]))==(id)0)
(objcT98=self->datadefs,(*(id(*)(id,SEL,unsigned))_imp(objcT98,selTransTbl[39]))(objcT98,selTransTbl[39],n));
}
}
if((objcT99=self->datadefs,(*(unsigned(*)(id,SEL))_imp(objcT99,selTransTbl[3]))(objcT99,selTransTbl[3]))==0)self->
datadefs=(id)0;
return(id)self;
}

#line 187 "compstmt.m"
static id i_CompoundStmt_addheapvarblock_(struct CompoundStmt_PRIVATE *self,SEL _cmd,id c)
{
if(c==(id)self){
return(id)self;
}else{
id objcT100;

#line 192 "compstmt.m"
if(self->enclosing)
(objcT100=self->enclosing,(*_imp(objcT100,selTransTbl[40]))(objcT100,selTransTbl[40],c));
return(id)self;
}
}

static id i_CompoundStmt_st80(struct CompoundStmt_PRIVATE *self,SEL _cmd)
{
id objcT101,objcT102,objcT103;

#line 200 "compstmt.m"
gc('|');
if(self->datadefs)
(objcT101=self->datadefs,(*(id(*)(id,SEL,SEL))_imp(objcT101,selTransTbl[9]))(objcT101,selTransTbl[9],_cmd));
gc('|');
gc('\n');
if(self->datadefs)
(objcT102=self->datadefs,(*(id(*)(id,SEL,SEL))_imp(objcT102,selTransTbl[9]))(objcT102,selTransTbl[9],selTransTbl[41]));
(objcT103=self->stmts,(*(id(*)(id,SEL,SEL))_imp(objcT103,selTransTbl[9]))(objcT103,selTransTbl[9],_cmd));
return(id)self;
}
extern id  Object;
extern struct _SHARED _Object;
extern struct _SHARED __Object;
extern id  Stmt;
extern struct _SHARED _Stmt;
extern struct _SHARED __Stmt;
static struct _SLT _CompoundStmt_clsDispatchTbl[] ={
{(char*)0,(id (*)())0}
};
static struct _SLT _CompoundStmt_nstDispatchTbl[] ={
{"iscompstmt",(id (*)())i_CompoundStmt_iscompstmt},
{"lbrace:",(id (*)())i_CompoundStmt_lbrace_},
{"rbrace:",(id (*)())i_CompoundStmt_rbrace_},
{"datadefs:",(id (*)())i_CompoundStmt_datadefs_},
{"stmts:",(id (*)())i_CompoundStmt_stmts_},
{"returnlabel",(id (*)())i_CompoundStmt_returnlabel},
{"lookupparm:",(id (*)())i_CompoundStmt_lookupparm_},
{"synth",(id (*)())i_CompoundStmt_synth},
{"gen",(id (*)())i_CompoundStmt_gen},
{"enclosing",(id (*)())i_CompoundStmt_enclosing},
{"addtmpvar:",(id (*)())i_CompoundStmt_addtmpvar_},
{"addicache:",(id (*)())i_CompoundStmt_addicache_},
{"addincref:",(id (*)())i_CompoundStmt_addincref_},
{"genincrefs",(id (*)())i_CompoundStmt_genincrefs},
{"adddecref:",(id (*)())i_CompoundStmt_adddecref_},
{"gendecrefs",(id (*)())i_CompoundStmt_gendecrefs},
{"lookuplocal:",(id (*)())i_CompoundStmt_lookuplocal_},
{"deflocal:astype:",(id (*)())i_CompoundStmt_deflocal_astype_},
{"genheapvarptr",(id (*)())i_CompoundStmt_genheapvarptr},
{"gendecrefsheapvars",(id (*)())i_CompoundStmt_gendecrefsheapvars},
{"genheapvartype",(id (*)())i_CompoundStmt_genheapvartype},
{"heapvars",(id (*)())i_CompoundStmt_heapvars},
{"isheapvar:",(id (*)())i_CompoundStmt_isheapvar_},
{"defheapvar:type:",(id (*)())i_CompoundStmt_defheapvar_type_},
{"heapvarptrname",(id (*)())i_CompoundStmt_heapvarptrname},
{"heapvartypename",(id (*)())i_CompoundStmt_heapvartypename},
{"removeheapvarsfromdatadefs",(id (*)())i_CompoundStmt_removeheapvarsfromdatadefs},
{"addheapvarblock:",(id (*)())i_CompoundStmt_addheapvarblock_},
{"st80",(id (*)())i_CompoundStmt_st80},
{(char*)0,(id (*)())0}
};
id CompoundStmt = (id)&_CompoundStmt;
id  *OBJCCLASS_CompoundStmt(void) { return &CompoundStmt; }
struct _SHARED  _CompoundStmt = {
  (id)&__CompoundStmt,
  (id)&_Stmt,
  "CompoundStmt",
  0,
  sizeof(struct CompoundStmt_PRIVATE),
  29,
  _CompoundStmt_nstDispatchTbl,
  41,
  &compstmt_modDesc,
  0,
  (id)0,
  &CompoundStmt,
};
id  OBJCCFUNC_CompoundStmt(void) { return (id)&_CompoundStmt; }
id  OBJCCSUPER_CompoundStmt(void) { return _CompoundStmt.clsSuper; }
struct _SHARED __CompoundStmt = {
  (id)&__Object,
  (id)&__Stmt,
  "CompoundStmt",
  0,
  sizeof(struct _SHARED),
  0,
  _CompoundStmt_clsDispatchTbl,
  34,
  &compstmt_modDesc,
  0,
  (id)0,
  0,
};
id  OBJCMFUNC_CompoundStmt(void) { return (id)&__CompoundStmt; }
id  OBJCMSUPER_CompoundStmt(void) { return __CompoundStmt.clsSuper; }
static char *_selTransTbl[] ={
"returnlabel",
"restype",
"parmnames",
"size",
"at:",
"lookupparm:",
"isid",
"addincref:",
"adddecref:",
"elementsPerform:",
"removeheapvarsfromdatadefs",
"lookuplocal:",
"isheapvar:",
"gen",
"isvoid",
"gendef:",
"genheapvarptr",
"genincrefs",
"str",
"gendecrefs",
"new",
"add:",
"lineno",
"filename",
"atKey:",
"atKey:put:",
"ismethdef",
"isivar:",
"iscvar:",
"contains:",
"heapvarcount",
"sprintf:",
"strCopy",
"isstatic",
"addNTest:",
"lhsself:",
"synth",
"removevars:initializers:",
"decllist",
"removeAt:",
"addheapvarblock:",
"st80inits",
0
};
struct modDescriptor compstmt_modDesc = {
  "compstmt",
  "objc2.3.1",
  0L,
  0,
  0,
  &CompoundStmt,
  42,
  _selTransTbl,
  0
};
struct modDescriptor *_OBJCBIND_compstmt(void)
{
  selTransTbl = _selTransTbl;
  return &compstmt_modDesc;
}
int _OBJCPOSTLINK_compstmt = 1;


