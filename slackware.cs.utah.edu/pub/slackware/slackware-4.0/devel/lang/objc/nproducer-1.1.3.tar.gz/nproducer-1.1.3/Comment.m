/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include "Node.h"
#include "Comment.h"

	static id head = nil, tail = nil;
	BOOL stripCommentsFlag = YES;

@implementation Comment:Node { STR text; }

+ str:(STR)aString { 
	if (!aString) return nil;
	self = [super new]; text = (STR)strCopy(aString);
	if (head == nil) head = self; else [tail successor: self];
	return tail = self;
}
+ gen { genReset(); [head gen];
	[head free]; head = tail = nil;
	return self; 
}
+ free 
	{ if (head) [head free]; head = tail = nil; return self; }
- (STR)str 
	{ return text; }
- free 
	{ free(text); return [super free]; }
- gen { 
	if (!stripCommentsFlag) { gf("/* %s */", text); [successor gen]; }
	return self; 
}

@end

