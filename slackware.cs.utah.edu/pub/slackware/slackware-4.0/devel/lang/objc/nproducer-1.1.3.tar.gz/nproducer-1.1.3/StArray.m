/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include <ordcltn.h>
#include <sequence.h>
#include "StArray.h"

@implementation StArray:OrdCltn
	{ id type; }

- gen { id s, m;
	gs("={"); 
	for (s = [self eachElement]; m = [s next]; )
		{ [m gen]; gs(", "); }
	[s free]; gc('}'); return self; 
}
- type { id s, m;
	if (type) return type;
	if ([self isEmpty]) return types.ID;
	type = [[self firstElement] type];
	for (s = [self eachElement]; m = [s next]; )
		if ([m type] != type) wer("this array holds diverse types");
	[s free];
	return type;
}
@end

