/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include <ordcltn.h>
#include "MsgNamePattern.h"

/* Each message may have several translations depending on the type of */
/*  the receiver and the message's arguments. MsgNamePattern holds the */
/*  name of the message (concatenated selector in selectorByteArray) */
/*  and an ordered collection of MsgArgPatterns. These are IdArrays */
/*  holding the type of the receiver followed by the types of the arguments. */
/*  Each MsgArgPattern also holds the translation for the messages that */
/*  match in name and argument type. */

@implementation MsgNamePattern : OrdCltn
	{ id selectorByteArray; }

+ name:aByteArray
	{ self = [super new]; selectorByteArray = aByteArray; return self; }
- (unsigned)hash
	{ return [selectorByteArray hash]; }
- (BOOL)isEqual:aMsgNamePattern
	{ return [selectorByteArray isEqual:aMsgNamePattern]; }
- (STR)str
	{ return [selectorByteArray str]; }

@end

