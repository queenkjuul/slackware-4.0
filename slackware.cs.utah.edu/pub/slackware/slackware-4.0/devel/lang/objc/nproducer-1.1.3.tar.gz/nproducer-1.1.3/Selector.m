/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include <idarray.h>
#include <ocstring.h>
#include "ByteArray.h"
#include "Node.h"
#include "Selector.h"

#define MAXSELECTOR 512
	STR strCopy(), xlate();

@implementation Selector:Node 
	{ id name,argument; }

+ name:aString argument:anArgument 
	{ return [[self name:aString] argument:anArgument]; }
+ name:aString 
	{ return [self str:[aString str]]; }
+ str:(STR)aString { 
	self = [super new];
	name = [String str:aString];
	if ([name size] < 1) return [self error:"nil selector"];
	return self; 
}
- deepCopy {
	id t = [[isa str:[name str]] argument:argument]; 
	[t successor:[successor deepCopy]];
	return t;
}
- (BOOL)isUnary
	{ return argument == nil; }
- asByteArray { char strBuf[MAXSELECTOR]; strBuf[0] = 0;
	do { strcat(strBuf, [name str]); } while (self = successor);
	return [ByteArray str:strBuf];
}
- asTypeArray { id typeArray;
	if ([self isUnary]) typeArray = [IdArray new:0];
	else { 
		typeArray = [IdArray new:[self size]];
		do { [typeArray add:[argument type]]; } while (self = successor);
	}
	return typeArray;
}
- asTypedByteArray { char strBuf[MAXSELECTOR]; strBuf[0] = 0;
	do { strcat(strBuf, [name str]);
		if (argument)
			sprintf(strBuf+strlen(strBuf), "(%s) ", [[argument type] str]);;
	} while (self = successor);
	return [ByteArray str:strBuf];
}

- (STR)str 
	{ return [name str]; }
- (unsigned)hash 
	{ return [name hash]; }
- (BOOL)isEqual:anObject 
	{ return self == anObject || strcmp([name str], [anObject str]) == 0; }
- (BOOL)isEqualSTR:(STR)aStr 
	{ return strcmp([name str], aStr) == 0; }
- type {
	if (successor) [successor type];
	return [argument type];
}
- type:aType
	{ return [self type:aType rule:"force"]; }
- type:aType rule:(STR)aString 
	{ [argument type:aType rule:aString]; return self; }
- argument:anArgument 
	{ argument = anArgument; return self; }
- argument 
	{ return argument; }
- argumentType
	{ return [argument type]; }
- free 
	{ [name free]; [argument free]; return [super free]; }
- gen {
	gs(xlate([name str])); [argument gen]; 
	if (successor) { gc(' '); [successor gen]; }
	return self; 
}
- genDeclaration {
	gs(xlate([name str]));
	if (argument && [argument type] != types.ID) 
		{ gc('('); gs([[argument type] str]); gc(')'); }
	[argument gen];
	if (successor) { gc(' '); [successor genDeclaration]; }
	return self; 
}
@end

/* Translate Smalltalk binary selectors to Objective-C keyword */

STR xlate(s) STR s; {
	static STR binarySelectorTbl= /* parallel arrays! */
			"+-/\\*~<>=@%&?!,|",
		objcSelectorStrings[]= { "plus", "minus", "slash", "backslash",
			"times", "tilde", "lesser", "greater", "equals", "point", "percent",
			"ampersand", "question", "bang", "comma", "or", "/*@*/", 0};
	STR i; static char buf[MAXSELECTOR];
	*buf = 0;
	if (i = strchr(binarySelectorTbl, s[0])) {
		strcat(buf, objcSelectorStrings[i-binarySelectorTbl]);
		if (s[1]) {
			if (i = strchr(binarySelectorTbl, s[1]))
				strcat(buf, objcSelectorStrings[i-binarySelectorTbl]);
			else wer("bad char in binary selector <%c>", s[1]);
			if (s[2]) wer("binary selector more than 2 chars long <%s>", s);
		}
		strcat(buf, ":");
		return buf;
	}
	return s;
}

