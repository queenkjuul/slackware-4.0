/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include "Node.h"

@implementation Node:Object { id successor; }

- successor { return successor; }
- successor:aLink { id me = successor; successor = aLink; return me; }

- lastElement { while(successor) self = successor; return self; }
- predecessorOf:aLink {
	do { if (successor == aLink) return self; } while (self = successor);
	return nil;
}
- at:(unsigned)anInt { register unsigned i = anInt; register id obj = self;
	while (i-- && obj) obj = [obj successor];
	return obj ? obj : [self error:"range error: %d", anInt];
}
- add:aLink { id me = self; while (successor) self = successor;
	successor = aLink; return me;
}
- freeContents { register id next;
	do { next = successor; [super free]; } while (self = next);
}
- remove:aLink { self =[self predecessorOf:aLink];
	 if (self == nil) return nil;
	 successor= [ aLink successor];
	 return aLink;
}
- insert:aLink 
	{ [ aLink successor:successor]; successor= aLink; return self; }

- gen 
	{ [self show]; [successor show]; return self; }
- free 
	{ [successor free]; return [super free]; }

#ifdef OBSOLETE
- (unsigned)size 
	{ register unsigned n = 1; while(self = successor) n++; return n; }
#endif
- (unsigned)size 
	{ unsigned i; for (i=1; self = successor; i++); return i; }

#ifndef COXLIB
- elementsPerform:(SEL)aSelector {
	do { [self perform:aSelector]; } while (self = successor);
	return self;
}
- elementsPerform:(SEL)aSelector with:arg1 {
	do { [self perform:aSelector with:arg1]; } while (self = successor);
	return self;
}
- elementsPerform:(SEL)aSelector with:arg1 with:arg2 {
	do { [self perform:aSelector with:arg1 with:arg2]; } while (self = successor);
	return self;
}
#else
- eachElementPerform:(SEL)aSelector {
	do { [self perform:aSelector]; } while (self = successor);
	return self;
}
- eachElementPerform:(SEL)aSelector with:arg1 {
	do { [self perform:aSelector with:arg1]; } while (self = successor);
	return self;
}
- eachElementPerform:(SEL)aSelector with:arg1 with:arg2 {
	do { [self perform:aSelector with:arg1 with:arg2]; } while (self = successor);
	return self;
}
#endif

@end

