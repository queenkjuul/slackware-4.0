/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef PRODUCER_H

#	include "Substrate.h"
#	undef CATEGORIES
#	define ARYSIZ(x) (sizeof(x)/sizeof(*x))
#	define strEq(a, b) (strcmp(a, b) == 0)
#       define strHas(s, c) (strchr(s, c) != NULL)
#
	typedef struct _TYPES {
		id DEFAULT, ID, CHAR, SHORT, INT, LONG, FLOAT, DOUBLE;
		id CSTRING, POINT, RECTANGLE;
		id BLOCK, STMT;
		id SELECTOR, SHARED;
		id UNKNOWN, ANY;
	} TYPE;
	IMPORT TYPE types;

#	define AbstractTranslation prAbstractTranslation
#	define ArgumentList prArgumentList
#	define Blk prBlk
#	define CharConstant prCharConstant
#	define Class prClass
#	define Comment prComment
#	define Constant prConstant
#	define Expr prExpr
#	define FunctionTranslation prFunctionTranslation
#	define Identifier prIdentifier
#	define IdentifierTranslation prIdentifierTranslation
#	define List prList
#	define Method prMethod
#	define Msg prMsg
#	define MsgArgPattern prMsgArgPattern
#	define MsgNamePattern prMsgNamePattern
#	define MsgTranslation prMsgTranslation
#	define MsgTranslator prMsgTranslator
#	define Node prNode
#	define NumberConstant prNumberConstant
#	define Return prReturn
#	define Scope prScope
#	define Selector prSelector
#	define SelectorConstant prSelectorConstant
#	define StArray prStArray
#	define Stmt prStmt
#	define StringConstant prStringConstant
#	define StringTranslation prStringTranslation
#	define Template prTemplate
#	define Type prType

#define PRODUCER_H
#endif

