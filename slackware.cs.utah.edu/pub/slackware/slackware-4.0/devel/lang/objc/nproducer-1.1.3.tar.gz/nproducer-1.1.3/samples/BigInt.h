
#include "st80.h"

@interface BigInt:Object
{
	unknown value;
}

- compare:b;

- (unsigned)hash;

- (BOOL)isEqual:b;

- characteristic;

- isEven;

- isOdd;

- (int)sign;

- asModp:(unknown)p;

- digitAt:(unknown)i;

- digitValue;

- digitValue:(unknown)d;

- insertDigit:(unknown)d;

- isDigit;

- lastDigit;

- leadingDigit;

- numDigits;

- removeDigit;

- add:b;

- addDigit:d;

- double;

- isOpposite:b;

- isZero;

- negate;

- subtract:b;

- subtractDigit:d;

- zero;

- inverse;

- isMinusOne;

- isOne;

- minusOne;

- multiply:b;

- multiplyDigit:d;

- one;

- square;

- divide:b;

- divideDigit:d;

- modulo:b;

- quotient:b;

- quotientDigit:d;

- quotientDigit:d remainder:r;

- remainder:b;

- remainder:b quotient:q;

- remainderDigit:d;

- gcd:b;

- printOn:(IOD)stream;

- printsLeadingSign;

- clone:v;

- value;

- value:(unknown)v;

+ factorial:d;

+ fibonacci:(unknown)n;

+ new;

+ str:aString;

@end

