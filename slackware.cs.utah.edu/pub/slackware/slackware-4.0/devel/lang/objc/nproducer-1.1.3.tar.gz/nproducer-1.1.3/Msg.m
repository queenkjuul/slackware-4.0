/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include "Msg.h"
#include <ordcltn.h>
#include <idarray.h>
#include "AbstractTranslation.h"
#include "MsgTranslation.h"
#include "MsgArgPattern.h"
#include "Node.h"
#include "Selector.h"

@implementation Msg:Object {
	id receiver;
	id selector;
	id translation;
}
	IMPORT id msgTranslator;
+ receiver:anObject 
	{ return [[self new] receiver:anObject]; }
+ receiver:anObject selector:aSelector
	{ return [[[self new] receiver:anObject] selector:aSelector]; }
+ selector:aSelector
	{ return [[self new] selector:aSelector]; }
- receiver 
	{ return receiver; }
- receiverType
	{ return [receiver type]; }
- receiver:anObject 
	{ receiver = anObject; return self; }
- selector 
	{ return selector; }
- selector:aSelector { 
	selector = aSelector;
	return self; 
}
- free {
	[receiver free];
	[selector free];
	return [super free]; 
}

- (STR)str 
	{ return [selector str]; }
- (unsigned)hash 
	{ return [selector hash]; }
- (BOOL)isEqual:aStr	
	{ return strcmp([self str], [aStr str]) == 0; }
- (BOOL)isEqualSTR:(STR)aStr 
	{ return strcmp([self str], aStr) == 0; }
- type { id type;
	if (!translation) { unsigned i, n; STR failReason = 0;
		id s, key = [selector asByteArray];
		id msgTranslation, receiverType = [receiver type];
		id sourceStr = [selector asTypedByteArray];
		dbg("translating message [(%s) %s]\n",
			[[receiver type] str], [sourceStr str]);
		if (![selector isUnary]) {
			for (s = selector; s; s = [s successor]) {
				id st = [s argumentType];
				if (st == types.UNKNOWN) [s type:types.ID rule:"msg arg"];
			}
		}
		if (msgTranslation = [msgTranslator find:key]) {
			for (n = [msgTranslation size], i = 0; i < n; i++) {
				unsigned offset = 0; id s, targetStr;
				id targetPattern = [msgTranslation at:i];
				id patternReceiverType = [targetPattern at:offset++];
				dbg("	actualReceiverType=%s patternReceiver=%s\n",
				[receiverType str], [patternReceiverType str]);
				failReason = "receiver types didn't match";
				if (patternReceiverType == types.ANY 
					|| patternReceiverType == receiverType) {
					if (![selector isUnary]) { 
						failReason = "argument types didn't match";
						for (s = selector; s; s = [s successor]) {
							id rt = [s type], pt = [targetPattern at:offset++];
							dbg("	actualArgType=%s patternArgType=%s\n",
								[rt str], [pt str]);
							if ((pt != types.ANY) && (rt != pt))
								goto fail;	
						}
					}
					translation = [targetPattern translation];
					targetStr = [translation asTypedByteArray];
					info("message [(%s)%s] translated to (%s)%s (type match)\n",
						[receiverType str], [sourceStr str],
						[[translation type] str], [targetStr str]);
					[targetStr free];
					goto succeed;
				}
fail:;
			}
		} else failReason = "name not found";
		info("message [(%s)%s] translated literally (%s)\n", 
			[receiverType str], [sourceStr str], failReason);
succeed:
		[key free]; [sourceStr free]; 
		if ([receiver type] == types.UNKNOWN)
			[receiver type:types.ID rule:"message receiver"];
	}
	type = translation ? [translation type] : types.ID;
	return type == types.UNKNOWN ? types.ID : type;
}
- gen {
	if (translation) [translation genReceiver:receiver selector:selector];
	else { 
		gc('['); [receiver gen]; gc(' '); [selector gen]; gc(']'); }
	return self; 
}
@end

