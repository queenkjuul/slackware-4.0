
#include "st80.h"

@interface BounceInBoxNode:MovingNode
{
}

- displayOn:destForm at:(PT)aDisplayPoint clippingBox:clipRectangle rule:(int)ruleInteger mask:aForm;

@end

