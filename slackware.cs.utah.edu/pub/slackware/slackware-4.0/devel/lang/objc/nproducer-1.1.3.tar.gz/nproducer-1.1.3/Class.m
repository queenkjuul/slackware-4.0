/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include "Class.h"
#include <ocstring.h>
#include <ordcltn.h>
#include "ByteArray.h"
#include "Identifier.h"

	BOOL autoFileFlag;
	BOOL interfaceflag;
	IMPORT id symbolScope;
	IMPORT id findSymbol();

@implementation Class:Object {
	id name, superclass, instanceVariables, classVariables, pdn, category;
	id instanceVariableScope, classVariableScope;
}
+ name:aClass { self = [super new]; name = aClass; 
	if (interfaceflag) { char buf[80];
		sprintf(buf,"%s.h", [name str]);
		genOpen(buf);
		sethdr();
	}
	if (autoFileFlag) { char buf[80];
		sprintf(buf, "%s.m", [name str]);
		genOpen(buf);
	}
	return self; 
}
- superclass:aClass { superclass = aClass; return self; }
- instanceVariableNames:aString { STR s = [aString str], end;
	if (!instanceVariables) instanceVariables = [OrderedCollection new];
	if (*s == '\'') s++;
	while(end = strchr(s, ' ')) { 
		while(*end == ' ') *end++ = 0;
		[instanceVariables add:findSymbol([Identifier str:s])];
		s = end;
	}
	if (end = strchr(s, '\'')) { *end = 0;
		[instanceVariables add:findSymbol([Identifier str:s])];
	}
	[symbolScope add:instanceVariableScope=[instanceVariables asSet]];
	return self; 
}
- classVariableNames:aString { STR s = [aString str], end;
	if (!classVariables) classVariables = [OrderedCollection new];
	if (*s == '\'') s++;
	while(end = strchr(s, ' ')) { 
		while(*end == ' ') *end++ = 0;
		[classVariables add:findSymbol([Identifier str:s])];
		s = end;
	}
	if (end = strchr(s, '\'')) { *end = 0;
		[instanceVariables add:findSymbol([Identifier str:s])];
	}
	[symbolScope add:classVariableScope=[classVariables asSet]];
	return self; 
}
- poolDictionaries:aString { pdn = aString; return self; }
- category:aString { category = aString; return self; }
- genwhat:(STR)what { STR start, end; 
	gn();
	gs("#include \"st80.h\"\n");
	gn();
	gs(what);[name gen]; gc(':'); [superclass gen];
	gn();
	gc('{'/*}*/);
#ifndef COXLIB
	[instanceVariables elementsPerform:@selector(genDeclaration)];
	gc(/*{*/'}');
	if (classVariables && [classVariables size]) {
	        gc(':'); gc('{');
		[classVariables elementsPerform:@selector(genDeclaration)];
		gn(); gc('}');
	}
#else
	[instanceVariables eachElementPerform:@selector(genDeclaration)];
	gc(/*{*/'}');
	if (classVariables && [classVariables size]) {
	        gc(':'); gc('{');
		[classVariables eachElementPerform:@selector(genDeclaration)];
		gn(); gc('}');
	}
#endif
	return self;
}
- gen {
  if (interfaceflag) { sethdr();[self genwhat:"@interface "];sethdr(); }
  [self genwhat:"@implementation "];
  return self;
}
- genEnd {
	gn();
	gs("@end\n");
	gn();
	return self;
}
- end {
        if (interfaceflag) { sethdr();[self genEnd];sethdr(); }
  	[self genEnd];
	[symbolScope remove:instanceVariableScope];
	[symbolScope remove:classVariableScope];
	return self;
}
 
- free {
	[classVariables freeContents]; [instanceVariables freeContents];
	[classVariables free]; [instanceVariables free];
	[name free];
	[superclass free];
	[pdn free];
	[category free];
	return [super free];
}
@end

