/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "stdio.h"
#include <set.h>
#include "Producer.h"
#include "MsgTranslator.h"

	LOCAL BOOL showMsgTranslationFlag, showIdTranslationFlag;
	IMPORT id msgTranslator, identifierTranslator;

STR *parseArguments(argc, argv) STR *argv; { unsigned i;
	IMPORT BOOL dbgFlag, msgFlag, allocFlag, printFlag, lexFlag, infoFlag,
		autoFileFlag, stripCommentsFlag, infoFlag, interfaceflag;
	
	for (i = 1; i < argc; i++) { STR arg = argv[i];
		static char usage[]="usage: %s [-(dmaplgsciMI)] files ..\n";
		if (*arg == '-') 
			switch (*++arg) {
			case 'd': dbgFlag = YES; break;
			case 'm': msgFlag = YES; break;
			case 'a': allocFlag = YES; break;
			case 'p': printFlag = YES; break;
			case 'l': lexFlag = YES; break;
			case 'g': autoFileFlag = YES; break;
			case 'h': interfaceflag = YES; break;
			case 's': stripCommentsFlag = YES; break;
			case 'c': stripCommentsFlag = NO; break;
			case 'i': infoFlag = YES; break;
			case 'M': showMsgTranslationFlag = YES; break;
			case 'I': showIdTranslationFlag = YES; break;
			default: fprintf(stderr, usage, argv[0]); bye(-2);
			}
		else return &argv[i];
	}
	return 0;
}
main(argc, argv) STR *argv; { 
	IMPORT unsigned errorCount;
	STR *file = parseArguments(argc, argv);

	msgTranslator = [MsgTranslator new];
	if (file) for (; *file; file++) {
			if (yyopen(*file, "r", stdin)) yyparse();
			else wer("cannot open %s\n", *file);
		}
	else yyparse(); 
	bye(errorCount != 0);
}

bye(n) { static BOOL beenHere = 0; 
	if (beenHere++) exit(n);
	if (showMsgTranslationFlag) {
	fprintf(stderr,"msgTranslator============================\n");
	[msgTranslator show];
	}
	if (showIdTranslationFlag) {
	fprintf(stderr,"identifierTranslator============================\n");
	[identifierTranslator show];
	}
	exit(n); 
}

