/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef SUBSTRATE_H

#	include "Object.h"

#	include "assert.h"
#	include "string.h"

/*{ ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Stylistic Conventions
	The IMPORT/EXPORT convention (EXPORT int foo=aValue to export foo,
	IMPORT int foo to import it) is used instead of of the usual C 
	conventions (int foo=aValue to export foo and extern int foo to 
	import it) to provides a distinctive marker on each global declaration
	that string search tools key off of to find all global declarations 
	reliably. The convention also provides a convenient way to overcome
	deficiencies in some C compilers; notably VMS C.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ }*/

#	define LOCAL static
#ifdef VMS
#	define IMPORT globalref
#	define EXPORT globaldef
#else
#	define IMPORT extern
#	define EXPORT /*export*/
#endif

/*{ ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Bit banging macros
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ }*/
#	define RBIT(bits, mask)	(bits &= ~mask)
#	define SBIT(bits, mask)	(bits |=  mask)
#	define TBIT(bits, mask) (bits &   mask)

	typedef int *WORD;		/* Amorphous typed machine word */
	typedef unsigned int WRD;	/* amorphous type; `word' */
	typedef char BYTE;

#define SUBSTRATE_H
#endif

