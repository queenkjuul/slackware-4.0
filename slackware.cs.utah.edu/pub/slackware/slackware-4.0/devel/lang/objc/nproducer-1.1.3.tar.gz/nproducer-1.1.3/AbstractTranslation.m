/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include "Node.h"
#include "Selector.h"
#include "AbstractTranslation.h"

@implementation AbstractTranslation : Object 
	{ id type; }
+ type:aType 
	{ return [[self new] type:aType]; }
- type 
	{ return type; }
- type:aType
	{ type = aType; return self; }
- (STR)str
	{ return (STR)[self subclassResponsibility]; }
- asTypedByteArray
	{ return (id)[self subclassResponsibility]; }
- assignTypesTo:aSelector {
	id s = [aSelector asByteArray];
	info("%s ignoring type assignment of %s\n", NAMEOF(self), [s str]);
	[s free]; return self;
}

@end

