/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include "AbstractTranslation.h"
#include "MsgTranslation.h"
#include <ordcltn.h>
#include "Node.h"
#include "Selector.h"

@implementation MsgTranslation : AbstractTranslation 
	{ id receiverType, selector; }

+ receiverType:aType selector:aSelector {
	self = [super type:types.ID];
	receiverType = aType ? aType : types.ANY;
	selector = aSelector;
	return self;
}
- selector
	{ return selector; }
- receiverType
	{ return receiverType; }
- (STR)str
	{ return [selector str]; }
- genReceiver:aReceiver selector:aSelector {
	unsigned argNumber = 0; id sel;
	gc('['); [aReceiver gen]; 
	for (sel = selector; sel; sel = [sel successor], argNumber++) {
		STR name = [sel str]; gc(' ');
		if (*name == '%') {
			unsigned i = atoi(&name[1]);
			if (i == 0)
				wer("%%0 not allowed in MsgPattern rules");
			else if (i >= [aSelector size]) {
				wer("argument offset %d out of range", i);
			} else {
				gs([[selector at:i-1] str]);
				[[[aSelector at:i-1] argument] gen];
			}
		} else { 
			gs([[selector at:argNumber] str]); 
			[[[aSelector at:argNumber] argument] gen];
		}
	}
	gc(']'); return self;
}
- asTypedByteArray 
	{ return [selector asTypedByteArray]; }
- free
	{ return nil; }
- assignTypesTo:aSelector {
	id s = aSelector, p = [self selector];
	while(s && p) { [s type:[p type]];
		s = [s successor]; p = [p successor];
	}
	return self;
}

@end

