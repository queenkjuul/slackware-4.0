
#include "objc.h"

#define unknown id

