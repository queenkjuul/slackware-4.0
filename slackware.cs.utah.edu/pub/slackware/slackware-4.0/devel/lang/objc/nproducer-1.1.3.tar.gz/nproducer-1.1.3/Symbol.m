/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*{ ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Symbol
	My instances in only a single copy, allowing them to be tested for
	equality via == instead of isEqual:

bjc: A prototype; not tested under load. The hash and isEqual: methods
	have broken since I was here last (library incompatibilities?)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ }*/

#include "Producer.h"
#include <ocstring.h>
#include "ByteArray.h"
#include "Symbol.h"
#include <set.h>

@implementation Symbol:ByteArray 
	LOCAL id symbolTable;

+ initialize
	{ if (!symbolTable) symbolTable = [Set new]; }
+ symbolTable
	{ return symbolTable; }
+ str:(STR)aStr 
	{ return [symbolTable filter:[super str:aStr]]; }
+ name:aByteArray 
	{ return [self str:[aByteArray str]]; }
- free 
	{ return nil; }
- str:(STR)aStr 
	{ return [self cannotModifyError]; }
- (char)charAt:(unsigned)anOffset put:(char)aChar 
	{ [self cannotModifyError];return 0; }
- sort 
	{ return [self cannotModifyError]; }
- concat:aStr 
	{ return [self cannotModifyError]; }
- concatSTR:(STR)aCString
	{ return [self cannotModifyError]; }
- concatenateAndFreeReceiver:aByteArray 
	{ return [self cannotModifyError]; }
- concatenateSTRAndFreeReceiver:(STR)aString 
	{ return [self cannotModifyError]; }
- concatenateSTR:(STR)aString 
	{ return [self cannotModifyError]; }
- concatenate:aByteArray
	{ return [self cannotModifyError]; }
- cannotModifyError
	{ return [self error:"the bytes in a %s are invarient", [self name]]; }
#ifdef NOTWORKING
- (unsigned)hash 
	{ return (unsigned)self; }
- (BOOL)isEqual:anObject
	{ return self == anObject; }
#endif

@end

