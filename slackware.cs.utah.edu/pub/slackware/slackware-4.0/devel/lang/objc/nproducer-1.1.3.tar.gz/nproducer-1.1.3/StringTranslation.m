/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include "AbstractTranslation.h"
#include "StringTranslation.h"
#include "Node.h"
#include "Selector.h"
#include "ctype.h"
#include <ordcltn.h>

@implementation StringTranslation:AbstractTranslation
	{ id translation; }
+ type:aType translation:aByteArray 
	{ return [[self type:aType] translation:aByteArray]; }
- translation:aByteArray
	{ translation = aByteArray; return self; }
- (STR)str
	{ return [translation str]; }
- genReceiver:aReceiver selector:aSelector {
	STR q, p;
	p = [translation str];
	for (; *p; p++) {
		if (*p == '\\') {
			gc(*p++); gc(*p); continue;
		} else if (*p == '%') {
			unsigned i = atoi(++p);
			if (i == 0) [aReceiver gen];
			else if (--i >= [aSelector size])
				wer("bad rule", i+1);
			else [[[aSelector at:i] argument] gen];
			while (isdigit(*p)) p++; p--;
		} else if (*p == '\n') {
			while(isspace(*p)) p++; p--;
		} else gc(*p);
	}
	return self;
}
- asTypedByteArray 
	{ return [translation asByteArray]; }
@end

static verifyArgCount(targetString, sourcePattern)
	STR targetString; id sourcePattern; 
{
	STR p;
	for (p = targetString; *p; p++) {
		if (*p == '\\') {
			*p++; continue;
		} else if (*p == '%') {
			unsigned i = atoi(++p);
			if (i != 0 && --i >= [sourcePattern size])
				wer("no such argument");
			while (isdigit(*p)) p++; p--;
		}
	}
}

