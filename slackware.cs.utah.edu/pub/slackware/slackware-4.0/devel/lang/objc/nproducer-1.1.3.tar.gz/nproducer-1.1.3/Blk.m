/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include "Node.h"
#include "Blk.h"
#include <set.h>
#include "Selector.h"
#include "Stmt.h"

IMPORT id symbolScope;

@implementation Blk:Node { id blockVariables, statements; }

+ statements:aStatementList 
	{ return [[self new] statements:aStatementList]; }
- variables:aVarList { 
	if (!aVarList || [aVarList isEmpty]) return self;
	[aVarList addContentsTo:blockVariables = [Set new]];
	[symbolScope add:blockVariables];
	return self; 
}
- statements:aStatementList 
	{ statements = aStatementList; return self; }

- gen { BOOL needsCompound = blockVariables || [statements size] > 1;
	if (needsCompound) gc('{'/*}*/);
#ifndef COXLIB
	[blockVariables elementsPerform:@selector(genDeclaration)];
#else
	[blockVariables eachElementPerform:@selector(genDeclaration)];
#endif
	[statements genExpr];
	if (needsCompound) gc(/*{*/'}');
	return self; 
}
- free { 
	[symbolScope remove:blockVariables];
	[blockVariables freeContents]; [blockVariables free];
	[statements free];
	return [super free];
}
- type 
	{ [statements type]; return types.BLOCK; }
@end

