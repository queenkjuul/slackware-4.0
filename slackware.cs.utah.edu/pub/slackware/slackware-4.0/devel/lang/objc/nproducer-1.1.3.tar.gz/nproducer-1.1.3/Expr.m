/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include "Node.h"
#include "Expr.h"
#include "Msg.h"
#include <ordcltn.h>
#include <sequence.h>
#include <ocstring.h>
#include "List.h"
#include "ByteArray.h"
#include "Identifier.h"


/* Expressions: a source (a message or primary) for a value and a list of */
/*	targets (variables) to assign values to. Cascaded message expressions*/ 
/*	are handled by linking expressions through their successor fields. */
/* */
/* Rewrites cascaded expressions like */
/*		Foo new bar gag extent:hack; bletch. */
/*	as */
/*		cascadeReceiver = [[[Foo new] bar] gag]. */
/*		[cascadeReceiver extent:hack]; */
/*		[cascadeReceiver ... */

	IMPORT id temporaryVariablePool;

@implementation Expr:Node {
	id assignmentList;
	id value;
}
+ assign:anAssignmentList value:aValue 
	{ return [[[super new] assign:anAssignmentList] value:aValue]; }
- assign:aList
	{ assignmentList = aList; return self; }
- value:aValue
	{ if (value) info("value of %s reassigned\n", NAMEOF(self));
	value = aValue; return self; }
- value
	{ return value; }
- gen { 
	if (assignmentList) { id s, v;
		for (s = [assignmentList eachElement]; v = [s next]; ) 
			{ [v gen]; gs(" = "); }
		[s free];
	}
	[value gen]; 
	if (successor) { gc(';'); [successor gen]; }
	return self; 
}
- type { id type = [value type]; 
	if (successor) [successor type];
#ifndef COXLIB
	if (assignmentList)
		[assignmentList elementsPerform:@selector(type:rule:)
			with:type with:(id)"value assignment"];
#else
	if (assignmentList)
		[assignmentList eachElementPerform:@selector(type:rule:)
			with:type with:(id)"value assignment"];
#endif
	return type;
}
- cascade:anExpr { 
	id newReceiver = [Identifier uniqueIdentifier:"tmp"];
	if ([value isKindOf:Msg]) { 
		id nval = [Msg receiver:newReceiver selector:[value selector]];
		id nxpr = [Expr assign:assignmentList value:nval];
		value = [value receiver];
		assignmentList = [List with:1, newReceiver];
		[self successor:nxpr]; [nxpr successor:anExpr];
		do { id msg = [nxpr value];
			if ([msg isKindOf:Msg]) [msg receiver:newReceiver]; 
		} while (nxpr = [nxpr successor]);
	} else {
		if (!assignmentList) assignmentList = [List new];
		[assignmentList add:newReceiver];
		[self successor:anExpr];
	}
	[temporaryVariablePool add:newReceiver];
	return self;
}
- free { [assignmentList free]; [value free]; return [super free]; }

@end

