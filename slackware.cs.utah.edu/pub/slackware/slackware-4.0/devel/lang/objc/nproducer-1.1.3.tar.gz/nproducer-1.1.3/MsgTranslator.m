/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* MsgTranslator: a set of MsgNamePatterns. These hold a string (the */
/*  concatenated selector characters) and a collection of MsgArgPatterns */
/*  describing one of the types (for receiver and arguments) for which */
/*  a translation is known */

#include "Producer.h"
#include <set.h>
#include <ordcltn.h>
#include <idarray.h>
#include "Msg.h"
#include "MsgNamePattern.h"
#include "MsgArgPattern.h"
#include "MsgTranslator.h"
#include "Node.h"
#include "Selector.h"

	EXPORT id msgTranslator = nil;

@implementation MsgTranslator : Set

- install:aTemplate translation:aTranslation {
	id name = [[aTemplate selector] asByteArray];
	id msgNamePattern = [self find:name];
	if (msgNamePattern) [name free];
	else [self add:msgNamePattern=[MsgNamePattern name:name]];
	[msgNamePattern add:[MsgArgPattern
		template:aTemplate translation:aTranslation]];
	return self;
}

@end

