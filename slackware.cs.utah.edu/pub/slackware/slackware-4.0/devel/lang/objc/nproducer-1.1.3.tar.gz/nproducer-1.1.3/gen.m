/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Producer.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

	LOCAL unsigned indent = 0;
	LOCAL BOOL bol = YES;
	LOCAL IOD genFD = stdout;
	LOCAL IOD hdrFD = stdout;
	LOCAL STR yyfilename = "<stdin>";

EXPORT void po(o) id o; 
	{ [o show]; }
EXPORT void dbgo(o) id o; 
	{ IMPORT BOOL dbgFlag; if (dbgFlag) [o show]; }
EXPORT int yywrap() 
	{ IMPORT unsigned yylineno; yylineno = 1; return 1; }

/* stockpile the last n tokens for printing in error messages */
#define SIZ 30
	LOCAL char minPt[SIZ+10] = "";	
	LOCAL STR inPt = &minPt[SIZ-1], maxPt = &minPt[SIZ-1];
EXPORT void stockToken(s) STR s; {
	if (!s) return;
	if (isalnum(*inPt) && isalnum(*s)) {
		if (inPt >= maxPt) inPt = minPt;
		*inPt++ = ' ';
	}
	while(*s) {
		if (inPt >= maxPt) inPt = minPt;
		*inPt++ = *s++;
	}
}
LOCAL printToken(iod) IOD iod; { STR outPt, stopPt;
	if (inPt >= maxPt)	{ outPt = minPt; stopPt = maxPt-1; }
	else 				{ outPt = inPt; stopPt = inPt-1; }
	for(;;) {
		if (outPt >= maxPt) outPt = minPt;
		putc(*outPt ? *outPt : ' ', iod);
		if (outPt++ == stopPt) break;
	}
}
EXPORT IOD yyopen(file, mode, iod) STR file, mode; IOD iod; {
	IMPORT IOD yyin; IMPORT unsigned yylineno;
	yylineno = 1; return freopen(yyfilename = file, mode, yyin=stdin);
}
	EXPORT int errorCount = 0;
EXPORT void wer(STR fmt, ...) { IMPORT unsigned yylineno; 
	va_list ap;
	va_start(ap,fmt);
	fflush(stdout); fflush(genFD); fflush(stderr);
	fprintf(stderr, "error: ");
	vfprintf(stderr,fmt,ap);fprintf(stderr, "\n");
	fflush(stdout); fflush(genFD); fflush(stderr);
	errorCount++;
	va_end(ap);
}
EXPORT void yyerror(STR fmt, ...) { IMPORT unsigned yylineno; 
	va_list ap;
	va_start(ap,fmt);
	fflush(stdout); fflush(genFD); fflush(stderr);
	fprintf(stderr, "error %3d:%s: ", yylineno, yyfilename);
	printToken(stderr); fprintf(stderr, " : ");
	vfprintf(stderr,fmt,ap); fprintf(stderr, "\n");
	fflush(stdout); fflush(genFD); fflush(stderr);
	errorCount++;
	va_end(ap);
}
	EXPORT BOOL infoFlag = NO;
EXPORT void info(STR fmt,...) { IMPORT unsigned yylineno; 
	va_list ap;
	va_start(ap,fmt);
	if (!infoFlag) return;
	fflush(stdout); fflush(genFD); fflush(stderr);
	fprintf(stderr, "fyi   %3d:%s: ", yylineno, yyfilename);
	vfprintf(stderr,fmt,ap);
	fflush(stderr);
	va_end(ap);
}
EXPORT STR strCopy(s) STR s;
	{ return (STR)strcpy((STR)malloc(strlen(s)+1), s); }

EXPORT void genOpen(className) STR className; {
	if (genFD != stdout) fclose(genFD);
	genFD = fopen(className, "w");
	indent = 0; bol = YES;
	if (!genFD) { fprintf(stderr, "cannot open %s for writing ", className);
		perror("");
		exit(-1);
	}
}
EXPORT void sethdr() {
  IOD t = genFD;genFD = hdrFD;hdrFD = t;
}
EXPORT void genReset() { indent = 0; bol = YES; }

LOCAL idn() { unsigned i;
	for (i = indent; i-- != 0; ) putc('\t', genFD);
	bol = NO;
}
LOCAL newline() {
	if (!bol) putc('\n', genFD);
	bol = YES;
}

EXPORT void gc(c) { BOOL eol = NO, discardSemi = NO;
	switch(c) { 
	case '\n': case '\r': case '\f': newline(); return;
	case '{': eol = YES; discardSemi = NO; break;
	case '}': indent--; eol = YES; discardSemi = YES; newline(); break;
	case '(': indent++; discardSemi = NO; break;
	case ')': indent--; discardSemi = NO; break;
	case ';': if (discardSemi) return; eol = YES; discardSemi = YES; break;
	default: discardSemi = NO; break;
	}
	if (bol) idn();
	putc(c, genFD); 
	if (eol) newline();
	if (c == '{'/*}*/) indent++;
}
EXPORT void gf(STR s, ...) {
	va_list ap;
	va_start(ap,s);
	vfprintf(genFD,s,ap);
	va_end(ap);
}
EXPORT void gs(s) STR s; { while(*s) gc(*s++); }
EXPORT void gn() { bol = NO; newline(); }

