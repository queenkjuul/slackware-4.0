
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
	TYP { id O; char B; char *S; } YYSTYPE;
extern YYSTYPE yylval;
# define IDENTIFIER 257
# define DIGITS 258
# define KEYWORD 259
# define STRING 260
# define CHARCON 261
# define DOUBLESPECIAL 262
# define MARK 263
# define VariableIdentifier 264
