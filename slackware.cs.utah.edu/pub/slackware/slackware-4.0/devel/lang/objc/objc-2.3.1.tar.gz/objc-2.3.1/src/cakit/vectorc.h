
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: vectorc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __vectorc_header__
#define __vectorc_header__

#include "cobject.h"

@interface vectorc : CAObject
{
}


- (float) floatValueAt:(int)i;
- (int) intValueAt:(int)i;

- (BOOL) isZero;
- negate;
- double;
- add:b;
- subtract:b;

- multiplyScalar:t;
- divideScalar:t;

- dotSquare;
- dotMultiply:aVector;
@end

#endif				/* __vectorc_header__ */

