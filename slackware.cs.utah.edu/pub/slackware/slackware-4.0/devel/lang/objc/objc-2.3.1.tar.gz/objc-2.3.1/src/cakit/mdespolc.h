
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: mdespolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __modp_vardnsexpdegsps_polynomial_header__
#define __modp_vardnsexpdegsps_polynomial_header__

#include "despolc.h"

typedef struct modp_vardnsexpdegspsterm {
  struct modp_vardnsexpdegspsterm *nlink;
  struct modp_vardnsexpdegspsterm *plink;
  /* stes - mar31, 1997 - for DEC alpha alignment, put scalar in front */
  modp_c scal;			/* can't be variable sized */
  vardnsmonom_c data;		/* variable sized */
} *modp_vardnsexpdegspsterm_t;

typedef struct {
  modp_args sargs;
  vardnsmonom_args margs;
} modp_vardnsexpdegspsterm_args;

typedef struct modp_vardnsexpdegspsterm *modp_vardnsexpdegspspol_t;
typedef struct modp_vardnsexpdegspsterm modp_vardnsexpdegspspol_c;
typedef modp_vardnsexpdegspsterm_args modp_vardnsexpdegspspol_args;

typedef struct modp_vardnsexpdegspspol_ix {
  modp_vardnsexpdegspsterm_t ix;
  modp_vardnsexpdegspsterm_t head;
} *modp_vardnsexpdegspspol_ixt;

#define modp_vardnsexpdegspspol_isvalue	0
#define modp_vardnsexpdegspspol_pervalue	0

@interface modp_vardnsexpdegsps_polynomial : vardnsexpdegsps_polynomial
{
  id scalarZero;
  id termZero;
  id monomialZero;
  id symbols;
  modp_vardnsexpdegspspol_c value;
}

- (modp_vardnsexpdegspspol_t)modp_vardnsexpdegspspol_value;
- modp_vardnsexpdegspspol_value:(modp_vardnsexpdegspspol_t)aValue;
- (modp_vardnsexpdegspspol_t)modp_vardnsexpdegspspol_reference;
- modp_vardnsexpdegspspol_reference:(modp_vardnsexpdegspspol_c *)aReference;

- copy;
- deepCopy;
- (BOOL) isEmpty;
- (BOOL) isOne;
- (BOOL) isMinusOne;
- (unsigned) hash;
- (BOOL) isEqual:b;
- (BOOL) notEqual:b;
- (BOOL) isZero;
- (BOOL) notZero;
- (BOOL) isOpposite:b;
- (BOOL) notOpposite:b;
- negate;
- negateSelf;
- _double:(int)v;
- _doubleSelf:(int)v;
- double;
- doubleSelf;
- _add:(int)v:b:(int)w;
- _addSelf:(int)v:b:(int)w;
- add:b;
- addSelf:b;
- subtract:b;
- subtractSelf:b;
- (int) leadingDegree;
- (int) lastDegree;
- (int) maxDegree;
- (int) minDegree;
- asScalar;
- asSymbol;
- check;
- _setUpScalarZero:aScalar symbols:aCltn;
+ scalarZero:aScalar symbols:aCltn;
- clear;
- clone;
- empty;
- (int) numMonomials;
- eachMonomial;
- elt_modp_vardnsexpdegspspol_ix:(modp_vardnsexpdegspspol_ixt)ix;
- removeMonomial;
- insertMonomial:aMonomial;
- multiplyScalar:s;
- multiplySelfScalar:s;
- divideScalar:s;
- divideSelfScalar:s;
- _add:(int)v:B multiplyScalar:b:(int)w;
- _addSelf:(int)v:B multiplyScalar:b:(int)w;
- _multiplyScalar:a:(int)v add:B:(int)w;
- _multiplySelfScalar:a:(int)v add:B:(int)w;
- _multiplyScalar:a:(int)v add:B multiplyScalar:b:(int)w;
- _multiplySelfScalar:a:(int)v add:B multiplyScalar:b:(int)w;
- multiplyMonomial:aMonomial;
- multiplySelfMonomial:aMonomial;
- _multiplyMonomial:aMonomial:(int)v;
- _multiplySelfMonomial:aMonomial:(int)v;
- divideMonomial:aMonomial;
- divideSelfMonomial:aMonomial;
- _add:(int)v:B multiplyMonomial:b:(int)w;
- _addSelf:(int)v:B multiplyMonomial:b:(int)w;
- _multiplyScalar:a:(int)v add:B multiplyMonomial:b:(int)w;
- _multiplySelfScalar:a:(int)v add:B multiplyMonomial:b:(int)w;

- fileOutOn:aFiler;
- fileInFrom:aFiler;
@end

#endif				/* __modp_vardnsexpdegsps_polynomial_header__ */

