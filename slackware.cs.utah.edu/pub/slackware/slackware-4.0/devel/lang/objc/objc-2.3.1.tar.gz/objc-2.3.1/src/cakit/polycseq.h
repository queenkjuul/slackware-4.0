
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: polycseq.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CAPOLYNOMIALRECCOEFSEQ_HEADER__
#define __CAPOLYNOMIALRECCOEFSEQ_HEADER__

#include "cseqc.h"

@interface recpolcoef_sequence : sequencec
{
  id content;
  id eachTerm;
}

- _setUpContent:aPolynomial;
+ content:aPolynomial;
- clear;
- toFirst;
- toLast;
- (unsigned) size;
- (BOOL) isEmpty;
- toElementAt:(int)i;
- next;
- previous;
@end

#endif				/* __CAPOLYNOMIALRECCOEFSEQ_HEADER__ */

