
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: matsqsq.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CAMATRIXSEQSEQ_HEADER__
#define __CAMATRIXSEQSEQ_HEADER__

#include "cseqc.h"

@interface CAMatrixSequenceSequences : sequencec
{
  id content;
  int index;
  int numRows;
  id currentMember;
}

- _setUpContent:aMatrix;
+ content:aMatrix;
- clear;
- (unsigned) size;
- (BOOL) isEmpty;
- toFirst;
- toLast;
- toElementAt:(int)i;
- currentMember;
- next;
- previous;
@end

#endif				/* __CAMATRIXSEQSEQ_HEADER__ */

