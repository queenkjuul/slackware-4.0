
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: polyeseq.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CAPOLYNOMIALEXPSCALSEQ_HEADER__
#define __CAPOLYNOMIALEXPSCALSEQ_HEADER__

#include "cseqc.h"

@interface exppolscalar_sequence : sequencec
{
  id content;
  id eachMonomial;
}

- _setUpContent:aPolynomial;
+ content:aPolynomial;
- clear;
- toFirst;
- toLast;
- (unsigned) size;
- (BOOL) isEmpty;
- toElementAt:(int)i;
- next;
- previous;
@end

#endif				/* __CAPOLYNOMIALEXPSCALSEQ_HEADER__ */

