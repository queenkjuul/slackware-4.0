
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: ovectorc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __obj_vector_header__
#define __obj_vector_header__

#include "vectorc.h"

typedef struct objvec {
  int n;
  int c;
  objseq_t ptr;
} *objvec_t;

typedef struct objvec objvec_c;
typedef struct {
  obj_args sargs;
} objvec_args;

#define objvec_isvalue	0
#define objvec_pervalue	0

typedef struct objvec_ix {
  int i;
  int n;
} *objvec_ixt;

@interface obj_vector : vectorc
{
  id scalarZero;
  struct objvec value;
}

- check;

- _setUpScalarZero:aScalarZero numScalars:(int)numScalars;
+ scalarZero:aScalarZero numScalars:(int)numScalars;
- copy;
- deepCopy;
- clear;
- (objvec_t)objvec_value;
- objvec_value:(objvec_t)aValue;
- (objvec_t)objvec_reference;
- objvec_reference:(objvec_c *)aReference;

- clone;
- capacity:(int)aCapacity;
- numScalars:(int)numScalars;

- scalarZero;
- (int) numScalars;

- insertScalar:aScalar;
- insertScalar:aScalar at:(int)i;

- removeScalar;
- removeScalarAt:(int)i;

- placeScalar:aScalar at:(int)i;
- replaceScalarAt:(int)i with:aScalar;

- eachScalar;
- elt_objvec_ix:(objvec_ixt)ix;

- dotMultiply:b;
- dotSquare;

- fileOutOn:aFiler;
- fileInFrom:aFiler;
- (unsigned) hash;
- (BOOL) isEqual:b;
- (BOOL) notEqual:b;
- (BOOL) isZero;
- (BOOL) notZero;
- (BOOL) isOpposite:b;
- (BOOL) notOpposite:b;
- negate;
- negateSelf;
- _double:(int)v;
- _doubleSelf:(int)v;
- double;
- doubleSelf;
- _add:(int)v:b:(int)w;
- _addSelf:(int)v:b:(int)w;
- add:b;
- addSelf:b;
- subtract:b;
- subtractSelf:b;
- multiplyScalar:s;
- multiplySelfScalar:s;
- divideScalar:s;
- divideSelfScalar:s;
- _add:(int)v:B multiplyScalar:b:(int)w;
- _addSelf:(int)v:B multiplyScalar:b:(int)w;
- _multiplyScalar:a:(int)v add:B:(int)w;
- _multiplySelfScalar:a:(int)v add:B:(int)w;
- _multiplyScalar:a:(int)v add:B multiplyScalar:b:(int)w;
- _multiplySelfScalar:a:(int)v add:B multiplyScalar:b:(int)w;
@end

#endif				/* __obj_vector_header__ */

