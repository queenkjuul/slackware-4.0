
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: matsq.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CAMATRIXSEQSCAL_HEADER__
#define __CAMATRIXSEQSCAL_HEADER__

#include "cseqc.h"

@interface CAMatrixSequenceScalars : sequencec
{
  id content;
  id eachSequence;
  id currentSequence;
}

- _setUpContent:aMatrix;
+ content:aMatrix;
- clear;
- toFirst;
- toLast;
- (BOOL) isEmpty;
- (unsigned) size;
- toElementAt:(int)i;
- next;
- previous;
@end

#endif				/* __CAMATRIXSEQSCAL_HEADER__ */

