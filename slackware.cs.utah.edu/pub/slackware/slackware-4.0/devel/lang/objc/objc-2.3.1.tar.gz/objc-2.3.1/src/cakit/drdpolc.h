
/*
 * Computer Algebra Kit (c) 1998 by David Stes.  All Rights Reserved.
 * $Id: drdpolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __vardnsrecdegdns_polynomial_header__
#define __vardnsrecdegdns_polynomial_header__

#include "polc.h"

@interface vardnsrecdegdns_polynomial : polynomialc
{
}

+ scalarZero:aScalar;
+ scalarZero:aScalar coefficientZero:aCoef symbols:aCltn;
+ scalarZero:aScalar symbols:aCltn;
- scalarZero;
- symbols;
- (BOOL) sameClass:b;
- emptyScalarZero:aZero;
- emptyVariableDense:aCltn;
- emptyVariableSparse;
- emptyExpanded;
- emptyRecursive;
- emptyDegreeSparse;
- emptyDegreeDense;
@end

#endif				/* __vardnsrecdegdns_polynomial_header__ */

