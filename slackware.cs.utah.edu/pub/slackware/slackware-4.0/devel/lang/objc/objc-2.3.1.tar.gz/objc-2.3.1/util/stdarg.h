#printLine #include <stdarg.h>
#pragma OCbuiltInType va_list
#pragma OCbuiltInFctn va_start
#pragma OCbuiltInFctn va_arg
#pragma OCbuiltInFctn va_end

