
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: polc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __polynomialc_header__
#define __polynomialc_header__

#include "cobject.h"

@interface polynomialc : CAObject
{
}

- empty;
- (BOOL) isEmpty;
- (int) leadingDegree;
- (int) lastDegree;
- (int) maxDegree;
- (int) minDegree;
- eachElement;
- (unsigned) size;
- insertMember:aMember;
- (BOOL) isOpposite:b;
- negate;
- double;
- add:b;
- subtract:b;
- multiplyScalar:aScalar;
- multiplyCoefficient:aCoefficient;
- multiplyMonomial:aMonomial;
- vardnsMultiplyTerm:aTerm;
- multiplyTerm:aTerm;
- divideScalar:aScalar;
- divideCoefficient:aCoefficient;
- divideMonomial:aMonomial;
- vardnsDivideTerm:aTerm;
- divideTerm:aTerm;
- over:aCarrier;
- liftTerm:aTerm;
- varspsMultiplyTerm:aTerm;
- varspsDivideTerm:aTerm;
@end

#endif				/* __polynomialc_header__ */

