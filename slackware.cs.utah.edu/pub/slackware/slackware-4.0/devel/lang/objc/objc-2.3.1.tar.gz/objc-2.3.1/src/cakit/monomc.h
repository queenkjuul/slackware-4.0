
/*
 * Computer Algebra Kit (c) 1998 by David Stes.  All Rights Reserved.
 * $Id: monomc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __monomialc_header__
#define __monomialc_header__

#include "cobject.h"

@interface monomialc : CAObject
{
}

- square;
- multiply:b;
- divide:b;
@end

#endif				/* __monomialc_header__ */

