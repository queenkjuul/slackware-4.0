
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: drspolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __vardnsrecdegsps_polynomial_header__
#define __vardnsrecdegsps_polynomial_header__

#include "polc.h"

@interface vardnsrecdegsps_polynomial : polynomialc
{
}

+ scalarZero:aScalar;
+ scalarZero:aScalar coefficientZero:aCoef symbols:aCltn;
- scalarZero:aScalar coefficientZero:aCoef symbols:aCltn;
+ scalarZero:aScalar symbols:aCltn;
- scalarZero;
- symbols;
- (BOOL) sameClass:b;
- emptyScalarZero:aZero;
- emptyVariableDense:aCltn;
- emptyVariableSparse;
- emptyExpanded;
- emptyRecursive;
- emptyDegreeSparse;
- emptyDegreeDense;
@end

#endif				/* __vardnsrecdegsps_polynomial_header__ */

