
/*
 * Computer Algebra Kit (c) 1998 by David Stes.  All Rights Reserved.
 * $Id: dmonomc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __vardns_monomial_header__
#define __vardns_monomial_header__

#include "monomc.h"

typedef int *vardnsmonom_t;
typedef int vardnsmonom_c;	/* kind of fishy */

typedef struct {
  int nvars;
  /* could add 'order' etc in the future */
} vardnsmonom_args;

#define vardnsmonom_isvalue	0
#define vardnsmonom_pervalue 0

typedef vardnsmonom_t vardns_t;
typedef vardnsmonom_t vardns_c;
typedef vardnsmonom_args vardns_args;

#define vardns_isvalue	0
#define vardns_pervalue	1

typedef struct vardns_ix {
  int i;
  int n;
} *vardns_ixt;

@interface vardns_monomial : monomialc
{
  id termOne;
  id symbols;
  vardns_c value;
}

- check;
- _setUpScalarOne:aOne symbols:aCltn;
+ scalarOne:aOne symbols:aCltn;
- copy;
- deepCopy;
- clear;
- clone;
- empty;
- (vardns_t) vardns_value;
- vardns_value:(vardns_t)aValue;
- (vardns_c *) vardns_reference;
- vardns_reference:(vardns_c *)aReference;
- (vardnsmonom_t) vardnsmonom_value;
- vardnsmonom_value:(vardnsmonom_t)aValue;
- (vardnsmonom_c *) vardnsmonom_reference;
- vardnsmonom_reference:(vardnsmonom_c *)aReference;
- (BOOL) sameClass:b;
- (int) numTerms;
- (BOOL) isEmpty;
- (BOOL) isOne;
- (int) compare:b;
- (BOOL) isEqual:b;
- (unsigned) hash;
- eachTerm;
- elt_vardns_ix:(vardns_ixt)ix;
- removeTerm;
- insertTerm:aTerm;

- fileOutOn:aFiler;
- fileInFrom:aFiler;
@end

#endif				/* __vardns_monomial_header__ */

