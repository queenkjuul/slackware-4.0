
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: srspolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __varspsrecdegsps_polynomial_header__
#define __varspsrecdegsps_polynomial_header__

#include "polc.h"

@interface varspsrecdegsps_polynomial : polynomialc
{
}

+ scalarZero:aScalar;
+ scalar:aScalar;
@end

#endif				/* __varspsrecdegsps_polynomial_header__ */

