
/*
 * Computer Algebra Kit (c) 1993,96 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: cseq.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CASEQUENCE_HEADER__
#define __CASEQUENCE_HEADER__

#include "cobject.h"

@interface CASequence : CAObject
{
  id carrier;
}

- _setUpCarrier:aSequence;
+ over:aSequence;
- clear;

- next;
- previous;

- (unsigned) size;
- (BOOL) isEmpty;
- (BOOL) isKindOfSequence;

- toFirst;
- toLast;
- toElementAt:(int)i;

- lastElement;
- firstElement;
- at:(unsigned)i;
- commonDenominator;
- content;

- printOn:(IOD)aFile;
@end

#endif				/* __CASEQUENCE_HEADER__ */

