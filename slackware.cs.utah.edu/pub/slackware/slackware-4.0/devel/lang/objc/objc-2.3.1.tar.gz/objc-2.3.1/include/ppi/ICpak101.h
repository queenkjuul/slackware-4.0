
/*
 * Portable Object Compiler (c) 1997 by Stes & Lerman.
 * All Rights Reserved.
 *
 * Header file for compatibility.
 * Enabled by -ppi option of objc.
 */

#include "objpak.h"

