
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: sespolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __varspsexpdegsps_polynomial_header__
#define __varspsexpdegsps_polynomial_header__

#include "polc.h"

@interface varspsexpdegsps_polynomial : polynomialc
{
}

@end

#endif				/* __varspsexpdegsps_polynomial_header__ */

