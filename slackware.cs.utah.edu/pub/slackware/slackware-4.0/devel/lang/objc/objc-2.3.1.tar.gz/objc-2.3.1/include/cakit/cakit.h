
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: cakit.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __cakit__
#define __cakit__

#define __cakit_revision__ "1.4.1"

#include "cobject.h"

#include "cseq.h"
#include "ccltn.h"

#include "cfloat.h"
#include "ccomplex.h"
#include "integer.h"
#include "fraction.h"
#include "intmodp.h"

#include "matrix.h"
#include "vector.h"

#include "term.h"
#include "symbol.h"
#include "monomial.h"
#include "polynom.h"

#endif				/* __cakit__ */

