
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: srspolc.m,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#include "cakit.h"

@implementation varspsrecdegsps_polynomial
+ scalarZero:aScalar
{
  return [self subclassResponsibility:_cmd];
}

+ scalar:aScalar
{
  if ([aScalar isZero]) {
    return [self scalarZero:aScalar];
  } else {
    id term;

    self = [self scalarZero:[aScalar zero]];
    term = [[self termZero] coefficient:aScalar symbol:nil exponent:0];
    return [self insertTerm:term];
  }
}

- (BOOL)isVariableDense		 {
  return NO;
}
- (BOOL)isVariableSparse	 {
  return YES;
}
- (BOOL)isRecursive		 {
  return YES;
}
- (BOOL)isExpanded		 {
  return NO;
}
- (BOOL)isDegreeDense		 {
  return NO;
}
- (BOOL)isDegreeSparse		 {
  return YES;
}

@end

