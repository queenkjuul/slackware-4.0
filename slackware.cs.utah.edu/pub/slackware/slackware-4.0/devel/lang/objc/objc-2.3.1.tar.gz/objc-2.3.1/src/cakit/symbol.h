
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: symbol.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CASYMBOL_HEADER__
#define __CASYMBOL_HEADER__

#include "cobject.h"

@interface Symbol : CAObject
{
  STR value;
}

+ str:(STR)aString;
- _setUpChars:(char *)aBuffer count:(int)numChars;
- chars:(char *)aBuffer count:(int)numChars;
+ chars:(char *)aBuffer count:(int)numChars;
- copy;
- deepCopy;
- clear;

- (STR) str;
- str:(STR)aString;
- (unsigned) hash;
- (BOOL) isEqual:b;
- (int) compare:b;
- (BOOL) isLetter;

- printOn:(IOD)aFile;

- fileOutOn:aFiler;
- fileInFrom:aFiler;
@end

#endif				/* __CASYMBOL_HEADER__ */

