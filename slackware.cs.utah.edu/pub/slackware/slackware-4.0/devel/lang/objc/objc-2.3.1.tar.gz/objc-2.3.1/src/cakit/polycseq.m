
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: polycseq.m,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#include "cakit.h"

@implementation recpolcoef_sequence
- _setUpContent:aPolynomial
{
  assert([aPolynomial isRecursive] && [aPolynomial isVariableDense]);
  content = aPolynomial;
  eachTerm = [aPolynomial eachTerm];
  return self;
}

+ content:aPolynomial
{
  return [[super new] _setUpContent:aPolynomial];
}

- clear
{
  content = [content free];
  eachTerm = [eachTerm free];
  return [super clear];
}

- toFirst
{
  [eachTerm toFirst];
  return self;
}

- toLast
{
  [eachTerm toLast];
  return self;
}

- (unsigned) size
{
  return [eachTerm size];
}

- (BOOL) isEmpty
{
  return [eachTerm isEmpty];
}

- toElementAt:(int)i
{
  [eachTerm toElementAt:i];
  return self;
}

- next
{
  id next = [eachTerm next];

  return (next) ? [next coefficient] : nil;
}
- previous
{
  id previous = [eachTerm previous];

  return (previous) ? [previous coefficient] : nil;
}

@end

