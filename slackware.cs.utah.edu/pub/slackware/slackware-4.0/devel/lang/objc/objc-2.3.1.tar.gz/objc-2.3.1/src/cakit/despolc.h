
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: despolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __vardnsexpdegsps_polynomial_header__
#define __vardnsexpdegsps_polynomial_header__

#include "polc.h"

@interface vardnsexpdegsps_polynomial : polynomialc
{
}

+ scalarZero:aScalar;
- scalarZero;
- symbols;
- (BOOL) sameClass:b;
- emptyScalarZero:aZero;
- emptyVariableDense:aCltn;
- emptyVariableSparse;
- emptyExpanded;
- emptyRecursive;
- emptyDegreeSparse;
- emptyDegreeDense;
@end

#endif				/* __vardnsexpdegsps_polynomial_header__ */

