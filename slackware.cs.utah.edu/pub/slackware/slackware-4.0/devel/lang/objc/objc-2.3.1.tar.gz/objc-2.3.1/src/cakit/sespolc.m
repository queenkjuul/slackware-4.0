
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: sespolc.m,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#include "cakit.h"

@implementation varspsexpdegsps_polynomial
- (BOOL)isVariableDense		 {
  return NO;
}
- (BOOL)isVariableSparse	 {
  return YES;
}
- (BOOL)isRecursive		 {
  return NO;
}
- (BOOL)isExpanded		 {
  return YES;
}
- (BOOL)isDegreeDense		 {
  return NO;
}
- (BOOL)isDegreeSparse		 {
  return YES;
}

@end

