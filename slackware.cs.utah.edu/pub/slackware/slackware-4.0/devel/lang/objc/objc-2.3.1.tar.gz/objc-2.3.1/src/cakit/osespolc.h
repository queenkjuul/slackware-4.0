
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: osespolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __obj_varspsexpdegsps_polynomial_header__
#define __obj_varspsexpdegsps_polynomial_header__

#include "sespolc.h"

@interface obj_varspsexpdegsps_polynomial : varspsexpdegsps_polynomial
{
  id scalarZero;
  id termZero;
  id monomialZero;
  id monomials;
}

- check;
+ new;
- _setUpScalarZero:aScalar;
+ scalarZero:aScalar;
- copy;
- deepCopy;
- clear;
- clone;
- _monomials:cltn;
- empty;
- emptyScalarZero:aZero;
- emptyVariableDense:aCltn;
- emptyVariableSparse;
- emptyExpanded;
- emptyRecursive;
- emptyDegreeSparse;
- emptyDegreeDense;
- (BOOL) isEmpty;
- (BOOL) isZero;
- (BOOL) isOne;
- (BOOL) isMinusOne;
- (BOOL) sameClass:b;
- (BOOL) isEqual:b;
- asScalar;
- asSymbol;
- (int) numMonomials;
- eachMonomial;
- removeMonomial;
- insertMonomial:aMonomial;
@end

#endif				/* __obj_varspsexpdegsps_polynomial_header__ */

