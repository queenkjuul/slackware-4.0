
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: vector.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CAVECTOR_HEADER__
#define __CAVECTOR_HEADER__

#include "cobject.h"

@interface Vector : CAObject
{
  id carrier;
  id scalarZero;
}

+ collection:aCltn;
+ scalarZero:aScalarZero numScalars:(int)numScalars;
- copy;
- deepCopy;
- clear;

- scalarZero;
- (int) numScalars;
- (unsigned) hash;
- (BOOL) isEqual:b;

- insertScalar:aScalar;
- insertScalar:aScalar at:(int)i;

- removeScalar;
- removeScalarAt:(int)i;
- freeScalarAt:(int)i;

- placeScalar:aScalar at:(int)i;
- replaceScalarAt:(int)i with:aScalar;
- asCollection;
- asNumerical;
- asModp:(unsigned short)p;
- onCommonDenominator:(id *)denominator;

- eachScalar;
- (float) floatValueAt:(int)i;
- (int) intValueAt:(int)i;

- zero;
- (BOOL) isZero;
- (BOOL) isOpposite:b;
- negate;
- double;
- add:b;
- subtract:b;
- addScalar:s at:(int)i;
- subtractScalar:s at:(int)i;

- multiplyScalar:s;
- divideScalar:s;

- dotSquare;
- dotMultiply:aVector;
- multiplyLeftMatrix:aMatrix;

- printOn:(IOD)aFile;
@end

#endif				/* __CAVECTOR_HEADER__ */

