
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: cseqc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CASEQ_HEADER__
#define __CASEQ_HEADER__

#include "cobject.h"

@interface sequencec : CAObject
{
}

@end

#endif				/* __CASEQ_HEADER__ */

