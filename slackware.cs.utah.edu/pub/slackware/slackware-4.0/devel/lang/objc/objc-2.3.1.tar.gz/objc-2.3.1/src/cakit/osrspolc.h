
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: osrspolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __obj_varspsrecdegsps_polynomial_header__
#define __obj_varspsrecdegsps_polynomial_header__

#include "srspolc.h"

@interface obj_varspsrecdegsps_polynomial : varspsrecdegsps_polynomial
{
  id scalarZero;
  id termZero;
  id monomialZero;
  id terms;
}

- check;
+ new;
- _setUpScalarZero:aScalar;
+ scalarZero:aScalar;
- copy;
- deepCopy;
- clear;
- clone;
- _terms:cltn;
- empty;
- scalarZero:aScalar;
- scalarZero:aScalar symbols:aCltn;
- emptyScalarZero:aZero;
- emptyVariableDense:aCltn;
- emptyVariableSparse;
- emptyExpanded;
- emptyRecursive;
- emptyDegreeSparse;
- emptyDegreeDense;
- (BOOL) isEmpty;
- (BOOL) isZero;
- (BOOL) isOne;
- (BOOL) isMinusOne;
- (BOOL) sameClass:b;
- (BOOL) isEqual:b;
- asScalar;
- asSymbol;
- (int) numTerms;
- eachTerm;
- removeTerm;
- insertTerm:aTerm;
@end

#endif				/* __obj_varspsrecdegsps_polynomial_header__ */

