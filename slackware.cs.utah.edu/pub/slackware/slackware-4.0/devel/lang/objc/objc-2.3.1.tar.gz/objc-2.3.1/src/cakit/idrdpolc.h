
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: idrdpolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __bigintobj_vardnsrecdegdns_polynomial_header__
#define __bigintobj_vardnsrecdegdns_polynomial_header__

#include "drdpolc.h"

typedef bigintobjseq_t bigintobj_vardnsrecdegdnspolseq_t;

typedef struct bigintobj_vardnsrecdegdnspol {
  int n;
  int c;
  bigintobj_vardnsrecdegdnspolseq_t ptr;
} *bigintobj_vardnsrecdegdnspol_t;

typedef struct bigintobj_vardnsrecdegdnspol bigintobj_vardnsrecdegdnspol_c;
typedef struct {
  bigintobj_args sargs;
} bigintobj_vardnsrecdegdnspol_args;

typedef struct bigintobj_vardnsrecdegdnspol_ix {
  int i;
  int n;
} *bigintobj_vardnsrecdegdnspol_ixt;

#define bigintobj_vardnsrecdegdnspol_isvalue	0
#define bigintobj_vardnsrecdegdnspol_pervalue	0

@interface bigintobj_vardnsrecdegdns_polynomial : vardnsrecdegdns_polynomial
{
  id scalarZero;
  id termZero;
  id monomialZero;
  id symbols;
  bigintobj_vardnsrecdegdnspol_c value;
}

- _setUpScalarZero:aScalar coefficientZero:aCoef symbols:aCltn;
+ scalarZero:aScalar coefficientZero:aCoef symbols:aCltn;
- empty;
- (int) numTerms;
- (bigintobj_vardnsrecdegdnspol_t)bigintobj_vardnsrecdegdnspol_value;
- bigintobj_vardnsrecdegdnspol_value:(bigintobj_vardnsrecdegdnspol_t)aValue;
- (bigintobj_vardnsrecdegdnspol_t)bigintobj_vardnsrecdegdnspol_reference;
- bigintobj_vardnsrecdegdnspol_reference:(bigintobj_vardnsrecdegdnspol_c *)aReference;

- copy;
- deepCopy;
- (BOOL) isEmpty;
- (BOOL) isOne;
- (BOOL) isMinusOne;
- (unsigned) hash;
- (BOOL) isEqual:b;
- (BOOL) notEqual:b;
- (BOOL) isZero;
- (BOOL) notZero;
- (BOOL) isOpposite:b;
- (BOOL) notOpposite:b;
- negate;
- negateSelf;
- _double:(int)v;
- _doubleSelf:(int)v;
- double;
- doubleSelf;
- _add:(int)v:b:(int)w;
- _addSelf:(int)v:b:(int)w;
- add:b;
- addSelf:b;
- subtract:b;
- subtractSelf:b;
- (int) leadingDegree;
- (int) lastDegree;
- (int) maxDegree;
- (int) minDegree;
- asScalar;
- asSymbol;
- check;
- clear;
- clone;
- eachTerm;
- elt_bigintobj_vardnsrecdegdnspol_ix:(bigintobj_vardnsrecdegdnspol_ixt)ix;
- removeTerm;
- insertTerm:aTerm;
- multiplyCoefficient:s;
- multiplySelfCoefficient:s;
- divideCoefficient:s;
- divideSelfCoefficient:s;
- _add:(int)v:B multiplyCoefficient:b:(int)w;
- _addSelf:(int)v:B multiplyCoefficient:b:(int)w;
- _multiplyCoefficient:a:(int)v add:B:(int)w;
- _multiplySelfCoefficient:a:(int)v add:B:(int)w;
- _multiplyCoefficient:a:(int)v add:B multiplyCoefficient:b:(int)w;
- _multiplySelfCoefficient:a:(int)v add:B multiplyCoefficient:b:(int)w;
- multiplyTerm:aTerm;
- multiplySelfTerm:aTerm;
- _multiplyTerm:aTerm:(int)v;
- _multiplySelfTerm:aTerm:(int)v;
- divideTerm:aTerm;
- divideSelfTerm:aTerm;
- _add:(int)v:B multiplyTerm:b:(int)w;
- _addSelf:(int)v:B multiplyTerm:b:(int)w;
- _multiplyCoefficient:a:(int)v add:B multiplyTerm:b:(int)w;
- _multiplySelfCoefficient:a:(int)v add:B multiplyTerm:b:(int)w;

- fileOutOn:aFiler;
- fileInFrom:aFiler;
@end

#endif				/* __bigintobjscal_vardnsrecdegdns_polynomial_header__ */

