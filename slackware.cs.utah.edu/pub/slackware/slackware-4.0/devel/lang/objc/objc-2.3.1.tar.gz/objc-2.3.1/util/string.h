#printLine #include <string.h>
#pragma OCbuiltInFctn strlen
#pragma OCbuiltInFctn strcmp
#pragma OCbuiltInFctn strcpy
#pragma OCbuiltInFctn strtok

