
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: odrdpolc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __obj_vardnsrecdegdns_polynomial_header__
#define __obj_vardnsrecdegdns_polynomial_header__

#include "drdpolc.h"

typedef objseq_t obj_vardnsrecdegdnspolseq_t;

typedef struct obj_vardnsrecdegdnspol {
  int n;
  int c;
  obj_vardnsrecdegdnspolseq_t ptr;
} *obj_vardnsrecdegdnspol_t;

typedef struct obj_vardnsrecdegdnspol obj_vardnsrecdegdnspol_c;
typedef struct {
  obj_args sargs;
} obj_vardnsrecdegdnspol_args;

typedef struct obj_vardnsrecdegdnspol_ix {
  int i;
  int n;
} *obj_vardnsrecdegdnspol_ixt;

#define obj_vardnsrecdegdnspol_isvalue	0
#define obj_vardnsrecdegdnspol_pervalue	0

@interface obj_vardnsrecdegdns_polynomial : vardnsrecdegdns_polynomial
{
  id scalarZero;
  id termZero;
  id monomialZero;
  id symbols;
  obj_vardnsrecdegdnspol_c value;
}

- _setUpScalarZero:aScalar coefficientZero:aCoef symbols:aCltn;
+ scalarZero:aScalar coefficientZero:aCoef symbols:aCltn;
- empty;
- (int) numTerms;
- (obj_vardnsrecdegdnspol_t)obj_vardnsrecdegdnspol_value;
- obj_vardnsrecdegdnspol_value:(obj_vardnsrecdegdnspol_t)aValue;
- (obj_vardnsrecdegdnspol_t)obj_vardnsrecdegdnspol_reference;
- obj_vardnsrecdegdnspol_reference:(obj_vardnsrecdegdnspol_c *)aReference;

- copy;
- deepCopy;
- (BOOL) isEmpty;
- (BOOL) isOne;
- (BOOL) isMinusOne;
- (unsigned) hash;
- (BOOL) isEqual:b;
- (BOOL) notEqual:b;
- (BOOL) isZero;
- (BOOL) notZero;
- (BOOL) isOpposite:b;
- (BOOL) notOpposite:b;
- negate;
- negateSelf;
- _double:(int)v;
- _doubleSelf:(int)v;
- double;
- doubleSelf;
- _add:(int)v:b:(int)w;
- _addSelf:(int)v:b:(int)w;
- add:b;
- addSelf:b;
- subtract:b;
- subtractSelf:b;
- (int) leadingDegree;
- (int) lastDegree;
- (int) maxDegree;
- (int) minDegree;
- asScalar;
- asSymbol;
- check;
- clear;
- clone;
- eachTerm;
- elt_obj_vardnsrecdegdnspol_ix:(obj_vardnsrecdegdnspol_ixt)ix;
- removeTerm;
- insertTerm:aTerm;
- multiplyCoefficient:s;
- multiplySelfCoefficient:s;
- divideCoefficient:s;
- divideSelfCoefficient:s;
- _add:(int)v:B multiplyCoefficient:b:(int)w;
- _addSelf:(int)v:B multiplyCoefficient:b:(int)w;
- _multiplyCoefficient:a:(int)v add:B:(int)w;
- _multiplySelfCoefficient:a:(int)v add:B:(int)w;
- _multiplyCoefficient:a:(int)v add:B multiplyCoefficient:b:(int)w;
- _multiplySelfCoefficient:a:(int)v add:B multiplyCoefficient:b:(int)w;
- multiplyTerm:aTerm;
- multiplySelfTerm:aTerm;
- _multiplyTerm:aTerm:(int)v;
- _multiplySelfTerm:aTerm:(int)v;
- divideTerm:aTerm;
- divideSelfTerm:aTerm;
- _add:(int)v:B multiplyTerm:b:(int)w;
- _addSelf:(int)v:B multiplyTerm:b:(int)w;
- _multiplyCoefficient:a:(int)v add:B multiplyTerm:b:(int)w;
- _multiplySelfCoefficient:a:(int)v add:B multiplyTerm:b:(int)w;

- fileOutOn:aFiler;
- fileInFrom:aFiler;
@end

#endif				/* __objscal_vardnsrecdegdns_polynomial_header__ */

