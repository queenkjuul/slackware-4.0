
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: polyrseq.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CAPOLYNOMIALRECSCALSEQ_HEADER__
#define __CAPOLYNOMIALRECSCALSEQ_HEADER__

#include "cseqc.h"

@interface recpolscalar_sequence : sequencec
{
  id content;
  id eachTerm;
  id eachScalar;
}

- _setUpContent:aPolynomial;
+ content:aPolynomial;
- clear;
- toFirst;
- toLast;
- (BOOL) isEmpty;
- (unsigned) size;
- toElementAt:(int)i;
- next;
- previous;
@end

#endif				/* __CAPOLYNOMIALRECSCALSEQ_HEADER__ */

