
/*
 * Computer Algebra Kit (c) 1998 by David Stes.  All Rights Reserved.
 * $Id: drdpolc.m,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#include "cakit.h"

@implementation vardnsrecdegdns_polynomial
+ scalarZero:aScalar
{
  return [self error:"Can't create variable dense polynomial without cltn of symbols"];
}

+ scalarZero:aScalar coefficientZero:aCoef symbols:aCltn
{
  return [self subclassResponsibility:_cmd];
}

+ scalarZero:aScalar symbols:aCltn
{
  id aCoef, aClass;
  int n = [aCltn size];

  assert([aScalar isZero] && n >= 1);

  if (n == 1) {
    aCoef = [aScalar cheapCopy];
  } else {
    id cltn = [aCltn copy];

    [[cltn removeLast] free];
    aCoef = [self scalarZero:[aScalar cheapCopy] symbols:cltn];
    aCoef = [Polynomial over:aCoef];
  }

  aClass = [aCoef class_vardnsrecdegdns_polynomial];
  return [aClass scalarZero:aScalar coefficientZero:aCoef symbols:aCltn];
}

- scalarZero
{
  return [self subclassResponsibility:_cmd];
}

- symbols
{
  return [self subclassResponsibility:_cmd];
}

- (BOOL) sameClass:b
{
  id aScalar = [self scalarZero];
  id aSymbols = [self symbols];
  id bScalar = [b scalarZero];
  id bSymbols = [b symbols];

  if ([super sameClass:b] == NO)
    return NO;
  if (aScalar != bScalar && [aScalar notEqual:bScalar])
    return NO;
  if (aSymbols != bSymbols && [aSymbols notEqual:bSymbols])
    return NO;

  return YES;
}

- (BOOL)isVariableDense		 {
  return YES;
}
- (BOOL)isVariableSparse	 {
  return NO;
}
- (BOOL)isRecursive		 {
  return YES;
}
- (BOOL)isExpanded		 {
  return NO;
}
- (BOOL)isDegreeDense		 {
  return YES;
}
- (BOOL)isDegreeSparse		 {
  return NO;
}

- emptyScalarZero:aZero
{
  id classCarrier;
  id symbols = [[self symbols] cheapCopy];

  classCarrier = [aZero class_vardnsrecdegdns_polynomial];
  return [classCarrier scalarZero:aZero symbols:symbols];
}

- emptyVariableDense:aCltn
{
  id classCarrier;
  id scalarZero = [[self scalarZero] cheapCopy];

  classCarrier = [scalarZero class_vardnsrecdegdns_polynomial];
  assert(classCarrier == isa || classCarrier != isa);
  assert([aCltn size] == [[self symbols] size]);
  return [classCarrier scalarZero:scalarZero symbols:aCltn];
}

- emptyVariableSparse
{
  id classCarrier;
  id scalarZero = [[self scalarZero] cheapCopy];

  classCarrier = [scalarZero class_varspsrecdegdns_polynomial];
  return [classCarrier scalarZero:scalarZero];
}

- emptyExpanded
{
  id classCarrier;
  id scalarZero = [[self scalarZero] cheapCopy];
  id symbols = [[self symbols] cheapCopy];

  classCarrier = [scalarZero class_vardnsexpdegdns_polynomial];
  return [classCarrier scalarZero:scalarZero symbols:symbols];
}

- emptyRecursive
{
  return [self empty];
}

- emptyDegreeSparse
{
  id classCarrier;
  id scalarZero = [[self scalarZero] cheapCopy];
  id symbols = [[self symbols] cheapCopy];

  classCarrier = [scalarZero class_vardnsrecdegsps_polynomial];
  return [classCarrier scalarZero:scalarZero symbols:symbols];
}

- emptyDegreeDense
{
  return [self empty];
}

@end

