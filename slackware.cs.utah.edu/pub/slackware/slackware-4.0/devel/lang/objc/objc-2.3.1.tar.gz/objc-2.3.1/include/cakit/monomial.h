
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: monomial.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CAMONOMIAL_HEADER__
#define __CAMONOMIAL_HEADER__

#include "cobject.h"

@interface Monomial : CAObject
{
  id scalar;
  id termOne;
  id terms;
  id _symbols;
  id _leadingTerm;
}

+ scalar:aScalar;
+ scalar:aScalar symbols:aCltn;
- empty;
- copy;
- deepCopy;
- clear;

- (int) intValue;
- intValue:(int)aValue;
- (float) floatValue;
- floatValue:(float)aValue;
- asScalar;
- asSymbol;

- scalar;
- termOne;
- (BOOL) isMonic;
- (BOOL) isVariableSparse;
- (BOOL) isVariableDense;
- (int) degree;
- (int) numTerms;
- (BOOL) isTerm;
- (BOOL) isEqual:aMonomial;
- (unsigned) hash;

- symbols;
- (BOOL) isOrderDegreeCompatible;
- (BOOL) isOrderReverseDegreeCompatible;
- (int) compareTerms:aMonomial;

- removeTerm;
- insertTerm:aTerm;

- eachTerm;
- leadingTerm;

- zero;
- (BOOL) isZero;
- negate;
- double;
- add:b;
- subtract:b;

- one;
- (BOOL) isOne;
- (BOOL) isMinusOne;
- square;
- multiply:b;
- multiplyScalar:s;
- divideScalar:s;
- divide:aMonomial;
- divideTerms:aMonomial;

- gcd:aMonomial;
- lcm:aMonomial;

- frobenius;
- frobeniusInverse;

- (BOOL) printsLeadingSign;
- (BOOL) printsSum;
- (BOOL) printsProduct;
- printOn:(IOD)aFile;
@end

#endif				/* __CAMONOMIAL_HEADER__ */

