
/*
 * Portable Object Compiler (c) 1997,98.  All Rights Reserved.
 * $Id: objc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __objch__
#define __objch__

#include "objcrt.h"
#ifndef __OBJECT_INCLUDED__
#define __OBJECT_INCLUDED__
#include "Object.h" /* Stepstone Object.h assumes #import */
#endif
#include "Block.h"
#include "Message.h"

#endif /* __objch__ */

