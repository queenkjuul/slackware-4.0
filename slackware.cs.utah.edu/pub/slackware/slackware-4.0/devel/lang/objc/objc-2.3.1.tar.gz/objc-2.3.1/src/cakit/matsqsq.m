
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: matsqsq.m,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#include "cakit.h"

@implementation CAMatrixSequenceSequences
- _setUpContent:aMatrix
{
  content = aMatrix;
  numRows = [content numRows];
  return self;
}

+ content:aMatrix
{
  return [[super new] _setUpContent:aMatrix];
}

- clear
{
  content = [content free];
  if (currentMember)
    currentMember = [currentMember free];
  return [super clear];
}

- (unsigned) size
{
  return numRows;
}

- (BOOL) isEmpty
{
  return numRows == 0;
}

- toFirst
{
  index = -1;
  return self;
}

- toLast
{
  index = numRows;
  return self;
}

- toElementAt:(int)i
{
  index = i - 1;
  return self;
}

- currentMember
{
  if (currentMember)
    currentMember = [currentMember free];
  if (0 <= index && index < numRows)
    currentMember = [[content rowAt:index] eachScalar];
  return currentMember;
}

- next
{
  index = (index <= numRows) ? index + 1 : numRows;
  return [self currentMember];
}

- previous
{
  index = (index >= 0) ? index - 1 : -1;
  return [self currentMember];
}

@end

