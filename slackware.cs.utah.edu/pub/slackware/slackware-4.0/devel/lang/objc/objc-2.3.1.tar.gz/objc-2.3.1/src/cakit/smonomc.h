
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: smonomc.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __varsps_monomial_header__
#define __varsps_monomial_header__

#include "monomc.h"

@interface varsps_monomial : monomialc
{
  id termOne;
  id terms;
}

- check;
- _setUpScalarOne:aOne;
+ scalarOne:aOne;
- copy;
- deepCopy;
- clear;
- clone;
- _terms;
- _terms:cltn;
- empty;
- (BOOL) isEmpty;
- (BOOL) isOne;
- (int) compare:b;
- (BOOL) isEqual:b;
- (unsigned) hash;
- asSymbol;
- symbol:aSymbol;
- (int) numTerms;
- eachTerm;
- removeTerm;
- insertTerm:aTerm;
@end

#endif				/* __varsps_monomial_header__ */

