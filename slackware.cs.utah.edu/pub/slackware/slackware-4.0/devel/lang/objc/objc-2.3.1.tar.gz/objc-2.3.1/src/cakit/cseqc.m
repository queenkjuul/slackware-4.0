
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: cseqc.m,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#include "cakit.h"

@implementation sequencec
@end

