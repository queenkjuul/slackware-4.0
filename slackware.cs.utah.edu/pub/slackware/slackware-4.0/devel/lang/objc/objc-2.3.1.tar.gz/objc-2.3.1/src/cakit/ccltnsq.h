
/*
 * Computer Algebra Kit (c) 1993,98 by Comp.Alg.Objects.  All Rights Reserved.
 * $Id: ccltnsq.h,v 1.1.1.1 1999/03/22 21:48:43 stes Exp $
 */

#ifndef __CACOLLECTIONSEQ_HEADER__
#define __CACOLLECTIONSEQ_HEADER__

#include "cseqc.h"

@interface CACollectionSequence : sequencec
{
  id content;
  int index;
  int size;
}

- _setUpContent:aCollection;
+ content:aCollection;
- copy;
- clear;
- (unsigned) size;
- (BOOL) isEmpty;
- toFirst;
- toLast;
- toElementAt:(int)i;
- next;
- previous;
@end

#endif				/* __CACOLLECTIONSEQ_HEADER__ */

