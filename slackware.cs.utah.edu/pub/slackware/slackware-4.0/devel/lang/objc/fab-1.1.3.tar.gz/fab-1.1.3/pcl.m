
/*
 * Copyright (C) 1998 David Stes.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "fab.h"
#include <runarray.h> 
#include <assert.h> 

static void pchar(char c)
{
  putchar(c);
}

static void pesc(char *s)
{
  printf("\033%s",s);
}

static void fontsize(int n)
{
  printf("\033(s%dV",n);
}

static void defaultfont(void)
{
  pesc("(s0S");
  pesc("(s4101T");
}

static void courierfont(void)
{
  pesc("(s4099T");
}

static void swissfont(void)
{
  pesc("(s16602T");
}

static void opencode(id a)
{
  switch([a emphasiscode]) {
    case ROMAN   : defaultfont();break;
    case BOLD    : pesc("(s3B");break;
    case COURIER : courierfont();break;
    case ITALIC  : pesc("(s1S");break;
    case SWISS   : swissfont();break;
    default      : break;
  }
}

static void closecode(id a)
{
  switch([a emphasiscode]) {
    case ROMAN   : break;
    case BOLD    : pesc("(s3b");break;
    case COURIER :
    case ITALIC  :
    case SWISS   : defaultfont();break;
    default : break;
  }
}

static void ppcl(id t)
{
  unsigned p = 0;
  char *chars = [t str];
  unsigned size = [t size];
  id runArray = [t runs];

  while (p < size) {
    int i,n;
    id attrs;
    unsigned q;
    attrs = [runArray at:p];
    n = [attrs size];
    q = p + [runArray runLengthAt:p];
    assert(q != p && q <= size);
    for(i=0;i<n;i++) opencode([attrs at:i]);
    for(;p<q;p++) pchar(chars[p]);
    while (n--) closecode([attrs at:n]);
  }
}

static void pcopyright(id t)
{
  int n = 7;
  defaultfont();
  fontsize(10);
  ppcl(t);
  fontsize(6);
  while (n--) pchar('\n');
}

static void ptitle(id t)
{
  int n = 6;
  swissfont();fontsize(18);
  ppcl(t);
  defaultfont();fontsize(6);
  while (n--) pchar('\n');
}

static void pdoc(id t)
{
  int n = 2;
  defaultfont();fontsize(12);
  ppcl(t);
  fontsize(6);
  while (n--) pchar('\n');
}

static void psubtitle(id t)
{ 
  int n = 2;
  defaultfont();fontsize(6);
  n=2;while (n--) pchar('\n');
  swissfont();fontsize(14);
  ppcl(t);
  defaultfont();fontsize(6);
  n=2;while (n--) pchar('\n');
}

static void pdotbegin(id t)
{
  defaultfont();fontsize(12);
}

static void psubsubtitle(id t)
{
  pdotbegin(t);
  ppcl(t);
  pchar('\n');
}

static void pdot(id t)
{
  /* uses tab set before */
  printf("\t- ");ppcl(t);pchar('\n');
}

static void pdotend(id t)
{
  defaultfont();fontsize(6);
  pchar('\n');pchar('\n');
}

static void pmethodname(id t)
{
  defaultfont();fontsize(6);
  pchar('\n');pchar('\n');
  swissfont();fontsize(12);
  ppcl(t);
  pchar('\n');
}

static void pmethodproto(id t)
{
  defaultfont();fontsize(12);
  ppcl(t);
  defaultfont();fontsize(6);
  pchar('\n');pchar('\n');
}

static void pexample(id t)
{
  courierfont();fontsize(10);
  ppcl(t);
  defaultfont();fontsize(6);
  pchar('\n');pchar('\n');
}

static void pnote(id t)
{
  defaultfont();fontsize(12);
  ppcl(t);
  defaultfont();fontsize(6);
  pchar('\n');
}

void writepcl(id paragraphs)
{
  int i,n = [paragraphs size];

  pesc("(s1P"); /* proportional */

  for(i=0;i<n;i++) {
    id p = [paragraphs at:i];
    char *style = [[p textStyle] name];
    id t = [p text];
    assert(style != NULL && style != NULL);
    if (!strcmp(style,"Title")) ptitle(t);
    else if (!strcmp(style,"Subtitle")) psubtitle(t);
    else if (!strcmp(style,"Subsubtitle")) psubsubtitle(t);
    else if (!strcmp(style,"Copyright")) pcopyright(t);
    else if (!strcmp(style,"Dotbegin")) pdotbegin(t); 
    else if (!strcmp(style,"Summarybegin")) pdotbegin(t); 
    else if (!strcmp(style,"Dotitem")) pdot(t);
    else if (!strcmp(style,"Summaryitem")) pdot(t);
    else if (!strcmp(style,"Dotend")) pdotend(t); 
    else if (!strcmp(style,"Summaryend")) pdotend(t); 
    else if (!strcmp(style,"Methodname")) pmethodname(t);
    else if (!strcmp(style,"Methodproto")) pmethodproto(t);
    else if (!strcmp(style,"Example")) pexample(t);
    else if (!strcmp(style,"Methodname")) psubsubtitle(t);
    else if (!strcmp(style,"Methodproto")) pmethodproto(t);
    else if (!strcmp(style,"Example")) pexample(t);
    else if (!strcmp(style,"Note")) pnote(t);
    else if (!strcmp(style,"Seealso")) pnote(t);
    else if (!strcmp(style,"Doc")) pdoc(t);
    else { ppcl(t); }
  }
}

