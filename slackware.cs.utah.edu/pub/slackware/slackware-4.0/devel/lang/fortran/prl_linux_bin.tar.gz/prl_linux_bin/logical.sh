#!/bin/sh
# Bourne_Shell_Script logical.sh
#
#       Programmer's Reusable Library, Version 0.7 (TM)
#
#            Copyright (C) 1995 Object Access (SM)
#                     All rights reserved.
#
#     Object Access Incorporated provides this software
#     "as is" without express or implied warranty.
#
#     PURPOSE: PRL Version 0.7 Logical Variable Declarations
#
#     INPUT SHELL VARIABLES:
#       PRLLOCAL = installation mode flag
#                  'local' - set binary file path to parent of current
#                         directory for library file build
#                  '' (null) - query for file path to system directory
#                         for library system-wide installation
#                  'xx' - assume PRLDIR and PRLBIN variables have been
#                         set on login, so do not set here (normal post-
#                         installation operation)
#       XFLAG    = X11 enable flag
#                  "XWIN"   - X11 graphics output device driver enabled
#                  "NOXWIN" - X11 graphics output device driver disabled
#                  null     - X11 enable flag not set
#
#     NOTES:
#       This script must be run in a Bourne shell.
#
################################################################################
#
#                       PRL Binary File Path Names
#
#                       Logical variables for library build
if [ "$PRLLOCAL" = "local" ]
then
  PRLDIR='..'; export PRLDIR
  PRLBIN='..'; export PRLBIN
#
#                       Logical variables for library install
elif [ "$PRLLOCAL" = "" ]
then
  echo "Enter installation path for PRL .a files [/usr/local/lib] "
  read PRLDIR
  if [ "$PRLDIR" = "" ] ; then
    PRLDIR='/usr/local/lib'
  fi
  echo "Enter installation path for PRL executable files [/usr/local/bin] "
  read PRLBIN
  if [ "$PRLBIN" = "" ] ; then
    PRLBIN='/usr/local/bin'
  fi
  export PRLDIR
  export PRLBIN
fi
#
################################################################################
#
#                       X11 Library Path Names
#
#                       Check if X driver is to be supported
if [ "$XFLAG" = "" ] ; then
  echo "Support X Driver ( [Y] or N ) "
  read answer
#                       X driver not supported
  if [ "$answer" = "n" ] || [ "$answer" = "N" ] ; then
     XFLAG=NOXWIN ; export XFLAG
     XINCL=""; export XINCL
#
#                       X driver is supported
  else
     XFLAG=XWIN ; export XFLAG
#
#                       Logical variable for system X11 include file
     if [ -r "/usr/include/X11/Xlib.h" ]
     then
       XINCL=/usr/include
     else
       echo "Enter the path name for X include file X11/Xlib.h [/usr/include] "
       read XINCL
       if [ "$XINCL" = "" ] ; then
          XINCL=/usr/include
       fi
     fi
#                       Logical variable for system X11 library file
     if [ -r "/usr/lib/libX11.a" ]
     then
       XLIB=/usr/lib
     else
       echo "Enter the path name for X library file libX11.a [/usr/lib] "
       read XLIB
       if [ "$XLIB" = "" ] ; then
          XLIB=/usr/lib
       fi
     fi
     export XINCL
     export XLIB
  fi
fi
#     
################################################################################
#
#                       PRL Link/Loader Logical Variables
#
#                       Logical variable for PRL-POSIX archive library
POSIX=$PRLDIR/libposix.a; export POSIX
#
#                       Logical variable for PRL-X11R5 archive library
X11R5=$PRLDIR/libx11r5.a; export X11R5
#
#                       Logical variable for PRL-PROGRLANG archive library
PROGRLANG=$PRLDIR/libprogrlang.a\ $POSIX; export PROGRLANG
#
#                       Logical variable for PRL-DEVICE archive library
if [ "$XFLAG" = "NOXWIN" ] ; then
  DEVICE=$PRLDIR/libdevice.a\ $PROGRLANG\ $X11R5; export DEVICE
else
  DEVICE=$PRLDIR/libdevice.a\ $PROGRLANG\ $X11R5\ $XLIB/libX11.a; export DEVICE
fi
#                       Logical variable for PRL-GRAPHICS archive library
GRAPHICS=$PRLDIR/libgraphics.a\ $DEVICE; export GRAPHICS
#
#                       Logical variable for PRL-PLOT archive library
PLOT=$PRLDIR/libplot.a\ $GRAPHICS; export PLOT
#
#                       Logical variable for PRL-SURFACE archive library
SURFACE=$PRLDIR/libsurface.a\ $PLOT; export SURFACE
#
#                       Logical variable for PRL-MAP archive library
MAP=$PRLDIR/libmap.a\ $PLOT; export MAP
#
################################################################################
#
#                       PRL Data File Logical Variables
#
#                       Logical variable for PRL font file
PRLFONT=$PRLDIR/PRLFNTS; export PRLFONT
#
#                       Logical variable for PRL film recorder
#                       user database file
PRLFRDB=$PRLDIR/PRLUSER; export PRLFRDB
#
#                       Logical variable for PRL printer queues file
PRLQUE=$PRLDIR/PRLQUES; export PRLQUE
#
#                       Logical variable for PRL low resolution worldmap file
#                       (Coastline, Island, Lake)
PRLMAPL=$PRLDIR/WORLDCIL; export PRLMAPL
#
#                       Logical variable for PRL high resolution world map file
PRLMAPH=$PRLDIR/WORLDMAP; export PRLMAPH
#
#                       End of logical variable declarations
