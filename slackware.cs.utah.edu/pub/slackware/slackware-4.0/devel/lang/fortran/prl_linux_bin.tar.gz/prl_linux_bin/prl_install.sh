#!/bin/sh
# Bourne_Shell_Script prl_install.sh
#
#       Programmer's Reusable Library (TM), Version 0.7
#
#            Copyright (C) 1995 Object Access (SM)
#                     All rights reserved.
#
#     Object Access Incorporated provides this software
#     "as is" without express or implied warranty.
#
#     PURPOSE: PRL Version 0.7 Master Installation Script
#
#     LOCAL VARIABLES:
#
#
#     NOTES:
#       This script must be run in a Bourne shell.
#       Use the /bin/sh command to invoke a Bourne shell, if necessary,
#       before running this script.
#
################################################################################
#
#                       Clear Screen Procedure
#
(tput) 1>/dev/null 2>&1
if [ $? = 1 ]; then
  CLEAR="clear"; export CLEAR
else
  CLEAR="tput clear"; export CLEAR
fi
#
################################################################################
#
#                       Script Introduction Query
#
$CLEAR
echo "

  Installation of PRL Version 0.7 Files
  =====================================

  Object Access
  2023 Leisure Lane
  League City, TX  77573
  e-mail:   oa@iah.com
  homepage: http://www.iah.com/~oa
  phone:    713-332-7281, 713-554-7617

  This Procedure will move Programmer's Reusable
  Library (PRL) files to your system directories.

  You should be logged in as the superuser to run
  this Procedure.

  Do you wish to proceed?
       ( Y or [N] ) "
read answer
if [ "$answer" = "y" ] || [ "$answer" = "Y" ] ; then
#
################################################################################
#
#                       System Logicals Definition
#
#                       Execute system logicals script if present
if [ -x "./logical.sh" ]
then
  PRLLOCAL=''; export PRLLOCAL
  . ./logical.sh
#                       Print message for successful completion
  echo "
  System Logicals Definition Completed.
  <CR> to Continue "
  read answer
#
#-------------------------------------------------------------------------------
#
#                       Print message if system logicals script not present
else
  $CLEAR
  echo " 
  ### Error: logical.sh system logicals script script not present. "
  exit
fi
#
################################################################################
#
#                       PRL-POSIX Install
#
$CLEAR
#                       Change to distribution directory if present
if [ -d "./prl-posix" ]
then
  cd ./prl-posix
#                       Copy archive to system directory if exists
  if [ -f "../libposix.a" ]
  then
    cp ../libposix.a $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/libposix.a
      chmod 0644 $PRLDIR/libposix.a
      rm ../libposix.a
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-POSIX object archive libposix.a to " $PRLDIR
  fi
#                       Return to main working directory
  cd ..
fi
#
################################################################################
#
#                       PRL-PROGRLANG Install
#
#                       Change to distribution directory if present
if [ -d "./prl-progrlang" ]
then
  cd ./prl-progrlang
#                       Copy archive to system directory if exists
  if [ -f "../libprogrlang.a" ]
  then
    cp ../libprogrlang.a $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/libprogrlang.a
      chmod 0644 $PRLDIR/libprogrlang.a
      rm ../libprogrlang.a
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-PROGRLANG object archive libprogrlang.a to " $PRLDIR
  fi
#                       Return to main working directory
  cd ..
fi
#
################################################################################
#
#                       PRL-DEVICE Install
#
#                       Change to distribution directory if present
if [ -d "./prl-device" ]
then
  cd ./prl-device
#                       Copy archive to system directory if exists
  if [ -f "../libdevice.a" ]
  then
    cp ../libdevice.a $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/libdevice.a
      chmod 0644 $PRLDIR/libdevice.a
      rm ../libdevice.a
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-DEVICE object archive libdevice.a to " $PRLDIR
  fi
#
#-------------------------------------------------------------------------------
#
#                       Copy utility program to system directory if exists
  if [ -f "../vecsave_replot.x" ]
  then
    cp ../vecsave_replot.x  $PRLBIN
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLBIN/vecsave_replot.x
      chmod 0755 $PRLBIN/vecsave_replot.x
      rm ../vecsave_replot.x
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-DEVICE utility program vecsave_replot.x to " $PRLBIN
  fi
#                       Return to main working directory
  cd ..
fi
#
################################################################################
#
#                       PRL-X11R5 Install
#
#                       Change to distribution directory if present
if [ -d "./prl-x11r5" ]
then
  cd ./prl-x11r5
#                       Copy archive to system directory if exists
  if [ -f "../libx11r5.a" ]
  then
    cp ../libx11r5.a $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/libx11r5.a
      chmod 0644 $PRLDIR/libx11r5.a
      rm ../libx11r5.a
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-X11R5 object archive libx11r5.a to " $PRLDIR
  fi
#                       Return to main working directory
  cd ..
fi
#
################################################################################
#
#                       PRL-GRAPHICS Install
#
#                       Change to distribution directory if present
if [ -d "./prl-graphics" ]
then
  cd ./prl-graphics
#                       Copy archive to system directory if exists
  if [ -f "../libgraphics.a" ]
  then
    cp ../libgraphics.a $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/libgraphics.a
      chmod 0644 $PRLDIR/libgraphics.a
      rm ../libgraphics.a
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-GRAPHICS object archive libgraphics.a to " $PRLDIR
  fi
#
#-------------------------------------------------------------------------------
#
#                       Copy font file to system directory if exists
  if [ -f "../PRLFNTS" ]
  then
    cp ../PRLFNTS $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/PRLFNTS
      chmod 0644 $PRLDIR/PRLFNTS
      rm ../PRLFNTS
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-GRAPHICS font file PRLFNTS to " $PRLDIR
  fi
#                       Return to main working directory
  cd ..
fi
#
################################################################################
#
#                       PRL-PLOT Install
#
#                       Change to distribution directory if present
if [ -d "./prl-plot" ]
then
  cd ./prl-plot
#                       Copy archive to system directory if exists
  if [ -f "../libplot.a" ]
  then
    cp ../libplot.a $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/libplot.a
      chmod 0644 $PRLDIR/libplot.a
      rm ../libplot.a
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-PLOT object archive libplot.a to " $PRLDIR
  fi
#                       Return to main working directory
  cd ..
fi
#
################################################################################
#
#                       PRL-SURFACE Install
#
#                       Change to distribution directory if present
if [ -d "./prl-surface" ]
then
  cd ./prl-surface
#                       Copy archive to system directory if exists
  if [ -f "../libsurface.a" ]
  then
    cp ../libsurface.a $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/libsurface.a
      chmod 0644 $PRLDIR/libsurface.a
      rm ../libsurface.a
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-SURFACE object archive libsurface.a to " $PRLDIR
  fi
#                       Return to main working directory
  cd ..
fi
#
################################################################################
#
#                       PRL-MAP Install
#
#                       Change to distribution directory if present
if [ -d "./prl-map" ]
then
  cd ./prl-map
#                       Copy archive to system directory if exists
  if [ -f "../libmap.a" ]
  then
    cp ../libmap.a $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/libmap.a
      chmod 0644 $PRLDIR/libmap.a
      rm ../libmap.a
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-MAP object archive libmap.a to " $PRLDIR
  fi
#
#-------------------------------------------------------------------------------
#
#                       Copy low-res map file to system directory if exists
  if [ -f "../WORLDCIL" ]
  then
    cp ../WORLDCIL $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/WORLDCIL
      chmod 0644 $PRLDIR/WORLDCIL
      rm ../WORLDCIL
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-MAP low-res map file WORLDCIL to " $PRLDIR
  fi
#
#-------------------------------------------------------------------------------
#
#                       Copy hi-res map file to system directory if exists
  if [ -f "../WORLDMAP" ]
  then
    cp ../WORLDMAP $PRLDIR
#                       Delete local file if copy successful
    if [ "$?" = 0 ]
    then
      chown root. $PRLDIR/WORLDMAP
      chmod 0644 $PRLDIR/WORLDMAP
      rm ../WORLDMAP
    fi
#                       Print message for successful copy
    echo "
  Copied PRL-MAP hi-res map file WORLDMAP to " $PRLDIR
  fi
#                       Return to main working directory
  cd ..
fi
echo "
  <CR> to Continue "
read answer
#
################################################################################
#
#                        Termination Message
#
$CLEAR
echo "

  PRL Installation Procedure Completed.

  If errors were encountered in this Procedure,
  and you desire more information or help:
 
  (1) Refer to the PRL Installation Instructions, or
  (2) See your Support Contract customer point of contact
 
  Object Access
  2023 Leisure Lane
  League City, TX  77573
  e-mail:   oa@iah.com
  homepage: http://www.iah.com/~oa
  phone:    713-554-7617 or 713-332-7281

  1 year Support Contract included with each Library
  purchased (Contract extensions available).

  Support Contracts available at reasonable cost
  for PRL Libraries obtained free under Linux. 
  "
fi
#
################################################################################
