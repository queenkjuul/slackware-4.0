#!/bin/sh
# Bourne_Shell_Script prl_build.sh
#
#       Programmer's Reusable Library (TM), Version 0.7
#
#            Copyright (C) 1995 Object Access (SM)
#                     All rights reserved.
#
#     Object Access Incorporated provides this software
#     "as is" without express or implied warranty.
#
#     PURPOSE: PRL Version 0.7 Master Build Script
#
#     LOCAL VARIABLES:
#
#
#     NOTES:
#       This script must be run in a Bourne shell.
#       Use the /bin/sh command to invoke a Bourne shell, if necessary,
#       before running this script.
#
################################################################################
#
#                       Clear Screen Procedure
#
(tput) 1>/dev/null 2>&1
if [ $? = 1 ]; then
  CLEAR="clear"; export CLEAR
else
  CLEAR="tput clear"; export CLEAR
fi
#
################################################################################
#
#                       Script Introduction Query
#
$CLEAR
echo "

  PRL Version 0.7 Build Procedure
  ===============================

  Object Access
  2023 Leisure Lane
  League City, TX  77573
  e-mail:   oa@iah.com
  homepage: http://www.iah.com/oa
  phone:    713-332-7281, 713-554-7617

  This Procedure will create all Programmer's Reusable
  Library (PRL) files in working storage.

  Do you wish to proceed?
       ( Y or [N] ) "
read answer
if [ "$answer" = "y" ] || [ "$answer" = "Y" ] ; then
#
################################################################################
#
#                       System Logicals Definition
#
#                       Execute system logicals script if present
if [ -x "./logical.sh" ]
then
  PRLLOCAL='local'; export PRLLOCAL
  . ./logical.sh
#                       Print message for successful completion
  echo "
  System Logicals Definition Completed.
  <CR> to Continue "
  read answer
#
#-------------------------------------------------------------------------------
#
#                       Print message if system logicals script not present
else
  $CLEAR
  echo " 
  ### Error: logical.sh system logicals script script not present."
    echo "<CR> to Continue " 
    read answer
  exit
fi
#
################################################################################
#
#                       PRL-POSIX Build
#
#                       Change to distribution directory if present
if [ -d "./prl-posix" ]
then
  cd ./prl-posix
#                       Print message if library archive exists
  if [ -f "../libposix.a" ]
  then
    $CLEAR
    echo " 
  --- Info: PRL-POSIX archive libposix.a already present. "
    echo "<CR> to Continue " 
    read answer
#
#                       Build library files if archive does not exist
  else
#                       Compile library source and create object archive file
    . ./posix_gen
    mv ./libposix.a ..
    echo "<CR> to Continue " 
    read answer
  fi
#                       Query user if demos have been installed before
  if [ -f "./run_demo" ]
  then
    echo "Re-build demo programs? ([Y] or N)" 
    read blddemo
    if [ "$blddemo" != "N" ] && [ "$blddemo" != "n" ]
    then
#                       Create and interactively run library demos
    . ./posix_demo
    fi
  else
   . ./posix_demo
  fi
#                       Print message for successful completion
    echo "
  PRL-POSIX Build Completed.
  <CR> to Continue "
    read answer
#                       Return to main working directory
  cd ..
#
#-------------------------------------------------------------------------------
#
#                       Print message if distribution directory not present
else
  $CLEAR
  echo " 
  ### Error: prl-posix distribution directory not present."
    echo "<CR> to Continue " 
    read answer
  exit
fi
#
################################################################################
#
#                       PRL-PROGRLANG Build
#
#                       Change to distribution directory if present
if [ -d "./prl-progrlang" ]
then
  cd ./prl-progrlang
#                       Print message if library archive exists
  if [ -f "../libprogrlang.a" ]
  then
    $CLEAR
    echo " 
  --- Info: PRL-PROGRLANG archive libprogrlang.a already present. "
    echo "<CR> to Continue " 
    read answer
#
#                       Build library files if archive does not exist
  else
#                       Compile library source and create object archive file
    . ./progrlang_gen
    mv ./libprogrlang.a ..
    echo "<CR> to Continue " 
    read answer
  fi
#                       Query user if demos have been installed before
  if [ -f "./run_demo" ]
  then
    echo "Re-build demo programs? ([Y] or N)" 
    read blddemo
    if [ "$blddemo" != "N" ] && [ "$blddemo" != "n" ]
    then
#                       Create and interactively run library demos
      . ./progrlang_demo
    fi
  else
    . ./progrlang_demo
  fi
#                       Print message for successful completion
    echo "
  PRL-PROGRLANG Build Completed.
  <CR> to Continue "
    read answer
#                       Return to main working directory
  cd ..
#
#-------------------------------------------------------------------------------
#
#                       Print message if distribution directory not present
else
  $CLEAR
  echo " 
  --- Info: prl-progrlang distribution directory not present."
    echo "<CR> to Continue " 
    read answer
  exit
fi
#
################################################################################
#
#                       PRL-X11R5 Build
#
#                       Change to distribution directory if present
if [ -d "./prl-x11r5" ]
then
  cd ./prl-x11r5
#                       Print message if library archive exists
  if [ -f "../libx11r5.a" ]
  then
    $CLEAR
    echo " 
  --- Info: PRL-X11R5 archive libx11r5.a already present. "
    echo "<CR> to Continue " 
    read answer
#
#                       Build library files if archive does not exist
  else
#                       Compile library source and create object archive file
    . ./x11r5_gen
    mv ./libx11r5.a ..
#                       Print message for successful completion
    echo "
  PRL-X11R5 Build Completed.
  <CR> to Continue "
    read answer
  fi
#                       Return to main working directory
  cd ..
#
#-------------------------------------------------------------------------------
#
#                       Print message if distribution directory not present
else
  if [ -d "./prl-device" ]
  then
    $CLEAR
    echo " 
  ### Error: prl-x11r5 distribution directory not present."
    echo "<CR> to Continue " 
    read answer
    exit
  else
    $CLEAR
    echo " 
  --- Info: prl-x11r5 distribution directory not present."
    echo "<CR> to Continue " 
    read answer
  fi
fi
#
################################################################################
#
#                       PRL-DEVICE Build
#
#                       Change to distribution directory if present
if [ -d "./prl-device" ]
then
  cd ./prl-device
#                       Print message if library archive exists
  if [ -f "../libdevice.a" ]
  then
    $CLEAR
    echo " 
  --- Info: PRL-DEVICE archive libdevice.a already present. "
    echo "<CR> to Continue " 
    read answer
#
#                       Build library files if archive does not exist
  else
#                       Compile library source and create object archive file
    . ./device_gen
    mv ./libdevice.a ..
    echo "<CR> to Continue " 
    read answer
  fi
#                       Query user if demos have been installed before
  if [ -f "./run_demo" ]
  then
    echo "Re-build demo programs? ([Y] or N)" 
    read blddemo
    if [ "$blddemo" != "N" ] && [ "$blddemo" != "n" ]
    then
#                       Create and interactively run library demos
      . ./device_demo
    fi
  else
    . ./device_demo
  fi
#                       Create library utility programs
#                       (Build PRL-DEVICE utility with PRL-GRAPHICS
#                       because it requires libgraphics.a)
#
#                       Print message for successful completion
    echo "
  PRL-DEVICE Build Completed.
  <CR> to Continue "
    read answer
#                       Return to main working directory
  cd ..
#
#-------------------------------------------------------------------------------
#
#                       Print message if distribution directory not present
else
  $CLEAR
  echo " 
  --- Info: prl-device distribution directory not present."
    echo "<CR> to Continue " 
    read answer
  exit
fi
#
################################################################################
#
#                       PRL-GRAPHICS Build
#
#                       Change to distribution directory if present
if [ -d "./prl-graphics" ]
then
  cd ./prl-graphics
#                       Print message if library archive exists
  if [ -f "../libgraphics.a" ]
  then
    $CLEAR
    echo " 
  --- Info: PRL-GRAPHICS archive libgraphics.a already present. "
    echo "<CR> to Continue " 
    read answer
#
#                       Build library files if archive does not exist
  else
#                       Compile library source and create object archive file
    . ./graphics_gen
    mv ./libgraphics.a ..
    echo "<CR> to Continue " 
    read answer
  fi
#                       Create graphics font file
  if [ -f "../PRLFNTS" ]
  then
    $CLEAR
    echo "
  --- Info: PRL-GRAPHICS font file PRLFNTS already present. "
    echo "<CR> to Continue " 
    read answer
  else
    . ./font_gen
    mv ./PRLFNTS ..
    echo "<CR> to Continue " 
    read answer
  fi
#                       Query user if demos have been installed before
  if [ -f "./run_demo" ]
  then
    echo "Re-build demo programs? ([Y] or N)" 
    read blddemo
    if [ "$blddemo" != "N" ] && [ "$blddemo" != "n" ]
    then
#                       Create and interactively run library demos
      . ./graphics_demo
      echo "<CR> to Continue " 
      read answer
    fi
  else
    . ./graphics_demo
    echo "<CR> to Continue " 
    read answer
  fi
#                       Create library utility programs
#                       (Build PRL-DEVICE utility here because it
#                       requires libgraphics.a)
  cd ../prl-device
  if [ -f "../vecsave_replot.x" ]
  then
    $CLEAR
    echo "
  --- Info: PRL-DEVICE utility vecsave_replot.x already present. "
    echo "<CR> to Continue " 
    read answer
  else
    . ./device_util
    mv ./vecsave_replot.x ..
  fi
#                       Print message for successful completion
    echo "
  PRL-GRAPHICS Build Completed.
  <CR> to Continue "
    read answer
#                       Return to main working directory
  cd ..
#
#-------------------------------------------------------------------------------
#
#                       Print message if distribution directory not present
else
  $CLEAR
  echo " 
  ### Error: prl-graphics distribution directory not present."
    echo "<CR> to Continue " 
    read answer
  exit
fi
#
################################################################################
#
#                       PRL-PLOT Build
#
#                       Change to distribution directory if present
if [ -d "./prl-plot" ]
then
  cd ./prl-plot
#                       Print message if library archive exists
  if [ -f "../libplot.a" ]
  then
    $CLEAR
    echo " 
  --- Info: PRL-PLOT archive libplot.a already present. "
    echo "<CR> to Continue " 
    read answer
#
#                       Build library files if archive does not exist
  else
#                       Compile library source and create object archive file
    . ./plot_gen
    mv ./libplot.a ..
    echo "<CR> to Continue " 
    read answer
  fi
#                       Query user if demos have been installed before
  if [ -f "./run_demo" ]
  then
    echo "Re-build demo programs? ([Y] or N)" 
    read blddemo
    if [ "$blddemo" != "N" ] && [ "$blddemo" != "n" ]
    then
#                       Create and interactively run library demos
#                       Create and interactively run library demos
      . ./plot_demo
    fi
  else
    . ./plot_demo
  fi
#                       Print message for successful completion
    echo "
  PRL-PLOT Build Completed.
  <CR> to Continue "
    read answer
#                       Return to main working directory
  cd ..
#
#-------------------------------------------------------------------------------
#
#                       Print message if distribution directory not present
else
  $CLEAR
  echo " 
  --- Info: prl-plot distribution directory not present."
    echo "<CR> to Continue " 
    read answer
  exit
fi
#
################################################################################
#
#                       PRL-SURFACE Build
#
#                       Change to distribution directory if present
if [ -d "./prl-surface" ]
then
  cd ./prl-surface
#                       Print message if library archive exists
  if [ -f "../libsurface.a" ]
  then
    $CLEAR
    echo " 
  --- Info: PRL-SURFACE archive libsurface.a already present. "
    echo "<CR> to Continue " 
    read answer
#
#                       Build library files if archive does not exist
  else
#                       Compile library source and create object archive file
    . ./surface_gen
    mv ./libsurface.a ..
    echo "<CR> to Continue " 
    read answer
  fi
#                       Query user if demos have been installed before
  if [ -f "./run_demo" ]
  then
    echo "Re-build demo programs? ([Y] or N)" 
    read blddemo
    if [ "$blddemo" != "N" ] && [ "$blddemo" != "n" ]
    then
#                       Create and interactively run library demos
      . ./surface_demo
    fi
  else
    . ./surface_demo
  fi
#                       Print message for successful completion
    echo "
  PRL-SURFACE Build Completed.
  <CR> to Continue "
    read answer
#                       Return to main working directory
  cd ..
#
#-------------------------------------------------------------------------------
#
#                       Print message if distribution directory not present
else
  $CLEAR
  echo " 
  --- Info: prl-surface distribution directory not present."
    echo "<CR> to Continue " 
    read answer
fi
#
################################################################################
#
#                       PRL-MAP Build
#
#                       Change to distribution directory if present
if [ -d "./prl-map" ]
then
  cd ./prl-map
#                       Print message if library archive exists
  if [ -f "../libmap.a" ]
  then
    $CLEAR
    echo " 
  --- Info: PRL-MAP archive libmap.a already present. "
    echo "<CR> to Continue " 
    read answer
#
#                       Build library files if archive does not exist
  else
#                       Compile library source and create object archive file
    . ./map_gen
    mv ./libmap.a ..
    echo "<CR> to Continue " 
    read answer
  fi
#                       Print message if map files exist
  if [ -f "../WORLDCIL" ] && [ -f "../WORLDMAP" ]
  then
    $CLEAR
    echo " 
  --- Info: PRL-MAP map files WORLDCIL and WORLDMAP already present."
    echo "<CR> to Continue " 
    read answer
  else
#                       Query if map files should be generated
    $CLEAR
    echo "

  Map File Build Option
  =====================

  The world map data files, especially the high-resolution map file,
  take a while to create.  If they have already been installed on
  your system, there is no need to re-create them now (unless they
  have been corrupted or deleted).


  Build world map data files? (Y or [N]) "
    read mapgen
    if [ "$mapgen" = "y" ] || [ "$mapgen" = "Y" ]
    then
#                       Generate new world map files
      . ./mapdata_gen
      if [ -f "./WORLDCIL" ] 
      then
        mv ./WORLDCIL ../WORLDCIL
      fi
      if [ -f "./WORLDMAP" ] 
      then
        mv ./WORLDMAP ../WORLDMAP
      fi
      echo "  <CR> to Continue "
      read answer
    fi
  fi
#                       Query user if demos have been installed before
  if [ -f "./run_demo" ]
  then
    echo "Re-build demo programs? ([Y] or N)" 
    read blddemo
    if [ "$blddemo" != "N" ] && [ "$blddemo" != "n" ]
    then
#                       Create and interactively run library demos
      . ./map_demo
    fi
  else
    . ./map_demo
  fi
#                       Print message for successful completion
    echo "
  PRL-MAP Build Completed.
  <CR> to Continue "
    read answer
#                       Return to main working directory
  cd ..
#
#-------------------------------------------------------------------------------
#
#                       Print message if distribution directory not present
else
  $CLEAR
  echo " 
  --- Info: prl-map distribution directory not present."
    echo "<CR> to Continue " 
    read answer
fi
#
################################################################################
#
#                       Build Termination Message
#
$CLEAR
echo "

  PRL Build Procedure Completed.

  If no errors were encountered in this Procedure,
  the PRL files just created may be moved to your system
  directories by running the script ""prl_install.sh""

  If errors were encountered in this Procedure,
  and you desire more information or help:
 
  (1) Refer to the PRL Installation Instructions, or
  (2) See your Support Contract customer point of contact
 
  Object Access
  2023 Leisure Lane
  League City, TX  77573
  e-mail:   oa@iah.com
  homepage: http://www.iah.com/oa
  phone:    713-554-7617 or 713-332-7281

  1 year Support Contract included with each Library
  purchased (Contract extensions available).

  Support Contracts available at reasonable cost
  for PRL Libraries obtained free under Linux. 
  "
fi
#
################################################################################
