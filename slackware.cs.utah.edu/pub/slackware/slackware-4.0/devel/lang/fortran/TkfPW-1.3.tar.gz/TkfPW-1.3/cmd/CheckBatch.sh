#!/bin/sh

# TkfPW Shell command
# See if $1 is 'at correct'

Check_at_fct() {
at $1 <<eof
 echo " Checking at $1 : OK " >/dev/null
eof
}

if Check_at_fct "$1" 2>/dev/null ;then
#	echo "Date $1 is Ok"
#	echo "Press Enter ..."
#	read line
	exit 0
else
#	echo "Wrong date : $1"
#	echo "Press Enter ..."
#	read line
	exit 1
fi
