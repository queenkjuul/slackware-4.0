#!/bin/sh

# TkfPW Shell command
# executes command $1 at a specified time $2

Submit_at_fct() {
at $2 <<eof
 sh $1
eof
}

if Submit_at_fct "$1" "$2" ;then
	echo "Submit Done, Press Enter ..."
	read line
	exit 0
else
	echo "Submit Cancelled, Press Enter ..."
	read line
	exit 1
fi

