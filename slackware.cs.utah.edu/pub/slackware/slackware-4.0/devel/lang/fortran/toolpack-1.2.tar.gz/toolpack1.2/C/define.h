/*-------------------------------*/
/*   TOOLPACK/1   Release: 1.1   */
/*-------------------------------*/
/* HOST DEPENDENT MACROS */
 
#define BPI        32      /* bits per integer */
#define BPC         8      /* bits per charcater */
#define CPI         4      /* characters per integer */
#define NCHARS    128      /* size of host character set */
#define BLOCKSIZE 512      /* size of disk block for block i/o */
 
 
/* file pointers */
 
#define FIRSTFD     4      /* first FD value for user files */
#define DEVFD       3      /* highest FD number reserved for device files */
                           /* stdin(0),stdout(1),stderr(2),stdlst(3)      */
#define MPRECON     2      /* file descriptor of highest preconnected file*/
#define PRECONN    -1
 
#define RJUST      -1      /* do we need this ?? */
 
/* these are the same as defined in ZDFLIB */
 
#define OK         -2
#define YES        -2
#define NO         -3
#define MINUS      45
#define PLUS       43
#define GREATER    62
#define LESS       60
#define EQUALS     61
#define NEWLINE    10
#define NEWLINECH '\n'
#define LETTER      1
#define DIGIT       2
#define DEVICE    -12
#define HOST      -11
#define VFS       -13
#define DIRECTORY 100   /* letd */
 
#define STDIN       0
#define STDOUT      1   /* these are preconnected units */
#define STDERR      2
#define STDLST      3
 
#define NOERR       -2 /* tim used 0 but bob says -2 */
#define ERR         -1
#define ERROR       -1
 
#define MAXBUFF     134
#define MAXLINE    132
#define MAXNAME     13
#define MAXPATH     81
#define MAXPRAM     10
 
#define UNUSED      -1
#define BLANK       32
#define BLANKCH    ' '
#define EOS        129
#define EOSCH     '\0'
#define EOF       -100
#define PERIODCH   '.'
#define SLASHCH    '/'
#define TAB          9
#define TABCH  '	'
#define NULLST         0
#define PREUNIT    100
#define PLAIN      112
#define FILES        1
 
/* HOST DEPENDENT */
 
#define CENAME      "istce"
#define HOSTFILE_IDCH '#'
#define IPCFILE     "#IST.CMD"
#define LPRPATH     "/usr/ucb/lpr"
#define LPR         "lpr"
#define MKDIRPTH    "/bin/mkdir"  /* path to system routine mkdir */
#define RMDIRPTH    "/bin/rmdir"  /* path to system routine rmdir */
#define MVPATH      "/bin/mv"
#define SPFLNAME    "spooler"
#define TOOLPRX     "/usr/nag/kvam/toolpack1.2/exec"
#define ROOTDIR     "_.TOOLPACK"
#define LOCALDIR    " "
#define LPRFLAGS    " "
#define VER4.2       1
#define SHELL_SCRIPTS 1           /* shell scripts are user interface */
#define DEBUG 	     0
 
/* file access types */
 
#define READ         0
#define WRITE        1
#define READWRITE    2
 
/* file opening types */
 
#define UNKNOWN      0
#define KILL     -1000
#define FATAL    -1001
#define WARNING  -1002
#define NOTOPEN     -1
#define PRECON      -1
#define NOTINRANGE   0
#define SEQUENTIAL  -1
#define UNDEFINED   -1
#define DIRECT       1
 
#define TERMFLAG_0  -2000
#define TERMFLAG_1  -2001
#define TERMFLAG_2  -2002

/* file permissions */
 
#define RWMODE    0666
#define RWXMODE    0777
#define CCMASK    0377
 
/* host immune ? */
 
#define MAXFILE     16
#define MAXFD  MAXFILE-1
 
