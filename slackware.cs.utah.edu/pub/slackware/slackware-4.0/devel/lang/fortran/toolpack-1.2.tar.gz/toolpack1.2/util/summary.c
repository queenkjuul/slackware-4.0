#include <stdio.h>

main(argc, argv)

int argc;
char *argv[];

{
printf("\
In the Toolpack script summaries below, the section numbers refer to the\
\n");
printf("\
Unix environment Users' Guide where more detailed information can be found.\
\n");
printf("\
To obtain on-line information about a script's usage, type its name\
\n");
printf("\
without any arguments.\
\n\n");
printf("\
Fortran Analysis Facilities\
\n\n");
printf("\
  getlst  Produce a listing showing statement and token numbers. Report\
\n");
printf("\
          lexical scanning warnings and errors. (3.1.1)\
\n\n");
printf("\
  syn     Report errors and warnings detected by lexical scanning, parsing,\
\n");
printf("\
          and examining a set of symbol attributes. (3.1.2)\
\n\n");
printf("\
  sem     Report errors and warnings detected by lexical scanning, parsing,\
\n");
printf("\
          and examining an extended set of symbol attributes. (3.1.3)\
\n\n");
printf("\
  pfort   Report errors and warnings detected by lexical scanning, parsing,\
\n");
printf("\
          examining an extended set of symbol attributes, checking for unsafe\
\n");
printf("\
          references, and checking conformance to a portable subset of\
\n");
printf("\
          Fortran. (3.1.4)\
\n\n");
printf("\
  statdoc In a user-supplied report template, place information derived from\
\n");
printf("\
          static analysis to assist in documenting the program.  Examples of\
\n");
printf("\
          information the user may request are COMMON block usage, symbol\
\n");
printf("\
          attributes, and a graph of subprogram calls. (3.1.5)\
\n\n");
printf("\
  inst    Instrument a Fortran program so that the instrumented program, when\
\n");
printf("\
          executed, produces information about program execution. (3.2.1)\
\n\n");
printf("\
  rundoc  Execute a program instrumented by inst and, in a user-supplied\
\n");
printf("\
          report template, place information derived from dynamic analysis\
\n");
printf("\
          to assist in documenting the program.  For example, the user may\
\n");
printf("\
          determine the frequency of execution of program segments. (3.2.2)\
\n\n");
printf("\
Fortran Transformation Facilities\
\n\n");
printf("\
  pol     Format a Fortran program under control of user-supplied options\
\n");
printf("\
          in a Polish option file. (4.1.1)\
\n\n");
printf("\
  polx    Construct a Polish option file via a menu-driven editor. (4.1.2)\
\n\n");
printf("\
  decs    Rebuild the declarative part of a Fortran program. (4.2.1)\
\n\n");
printf("\
  apt     Transform a single-precision version of a Fortran program to\
\n");
printf("\
          double precision or vice versa. (4.3.1)\
\n\n");
printf("\
  dapt    Convert precision and rebuild the declarations, combining the\
\n");
printf("\
          functions of apt and decs. (4.3.2)\
\n\n");
printf("\
  cname   Change the names in a Fortran program that satisfy conditions\
\n");
printf("\
          derived from information in either the lexical token stream or\
\n");
printf("\
          the symbol table or both. (4.4.1)\
\n\n");
printf("\
  lname   Transform a Fortran program containing long names to a program\
\n");
printf("\
          with standard names. (4.4.2)\
\n\n");
printf("\
  stf     Rebuild the flow of control in a Fortran program to standardized\
\n");
printf("\
          form. (4.5.1)\
\n\n");
printf("\
  ucs     Transform nests of DO loops matching certain paradigms so that\
\n");
printf("\
          the transformed code executes more efficiently on vector machines.\
\n");
printf("\
          (4.6.1)\
\n\n");
printf("\
Miscellaneous Facilities\
\n\n");
printf("\
  fdiff   Compare two Fortran programs at the lexical token level. (5.1.1)\
\n\n");
printf("\
  dac     Compare two data files, neglecting certain formatting differences\
\n");
printf("\
          and numerical differences smaller than a given tolerance. (5.1.2)\
\n\n");
printf("\
  vcon    Create, edit, and retrieve versions of a file contained in a\
\n");
printf("\
          version file. (5.2.1)\
\n\n");
printf("\
  discard Remove unneeded files created by the above scripts. (5.3.1)\
\n\n");
printf("\
  scripts Print this summary of the scripts. (5.4.1)\
\n\n");
}
