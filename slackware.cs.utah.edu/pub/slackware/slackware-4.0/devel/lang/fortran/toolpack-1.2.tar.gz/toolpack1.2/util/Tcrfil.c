#include <stdio.h>

main(argc, argv)


int argc;
char *argv[];

{
int nrfils,count;
char c1,c2;

count = 0;
nrfils = argc - 1;

while (nrfils > 0)
	{
	c1 = *argv[nrfils];
	c2 = *++argv[nrfils];
	if(c1 == '_' && c2 == '.') count = count + 1;
	nrfils = nrfils - 1;
	}

printf("%d",count);
}
