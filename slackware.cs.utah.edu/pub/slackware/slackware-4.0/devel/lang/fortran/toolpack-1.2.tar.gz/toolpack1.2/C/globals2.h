/*-------------------------------*/
/*   TOOLPACK/1   Release: 1.1   */
/*-------------------------------*/
 
 
	/* define structure of type FDINFO */
struct fdinfo {
	char *bufp;	/* pointer to current buffer position */
 
	int chrleft;  /* number of characters positions free in buffer */
 
	int ftype;    	/* file type : sequential, direct or unknown
			   unless file has been specifically opened during
			   execution this will always be unknown */
 
	int access;	/* access allowed read, write or readwrite */
 
	int caccess;	/* current mode of access - may change
				   if readwrite enabled */
 
	char filenam[MAXPATH];	/* C string version of filename */
 
	char buffer[BLOCKSIZE]; 	/* buffer for buffered i/o */
 
	int count;	/* number of spaces left to getch from embedded
			   space block */
	};
 
struct filinfo {
	int ftype1;
	int subtype;
	int exists;
};
 
struct fdinfo files[MAXFILE];
char root[MAXPATH], lcldir[MAXPATH];
char *inparam[MAXPRAM+3], *outparm[MAXPRAM+3];
char nxttool[MAXPATH];
int statswd;
int ipcexst, ipcfile[MAXPATH];
 
/* opnrec0 allows zbopen and zbcret to access record zero of a direct
   access file (opnrec0 = 1) at all other times (opnrec0 = 0) this
   record is locked out */
 
int opnrec0 ;
