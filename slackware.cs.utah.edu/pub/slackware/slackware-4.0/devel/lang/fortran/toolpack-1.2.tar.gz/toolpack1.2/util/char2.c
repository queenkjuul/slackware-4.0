#include <stdio.h>

main(argc, argv)

/* Compiles into char2  */
/* Prints the second character of the first command line argument */
/* on standard output.  Used in scripts to get a "key" from an "option" */
/* that is indicated by first character '-' . */

int argc;
char *argv[];

{
char c;

c = (*++argv)[1];
if (c == '\n' || c == '\0')
	printf("Fewer than two characters in string.\n");
else
	printf("%c", c);
}
