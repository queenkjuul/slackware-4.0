#include <stdio.h>

main(argc, argv)

/* The executable for this program is called mkipf. */
/* mkipf creates the interprocess file IST.CMD used by TIE-conforming */
/* Toolpack tools and fills the tool argument slots in IST.CMD with the */
/* arguments on the script command line.  */
/* Invocation: */
 
/*             mkipf <toolarg1> <toolarg2> ... <toolargn> */

/* TIE permits up to 10 toolargs. */

int argc;
char *argv[];

{
	FILE *fp, *fopen();
	int blanks = 10;

	fp = fopen("IST.CMD", "w");

	fprintf(fp, "    -2\n");
	fprintf(fp, "dummy\n");
	fprintf(fp, "_.TOOLPACK\n");
	fprintf(fp, "dummy\n");

	while(--argc > 0)
		{
		blanks = blanks-1;
  		fprintf(fp, "%s\n", *++argv);
		}

	while(blanks-- > 0)
  		fprintf(fp, "%c\n", ' ');

}
