#include <stdio.h>

main(argc, argv)

/* The executable for this program is called echoerr. */
/* echoerr echos a string to standard error rather than standard output */

int argc;
char *argv[];

{
	while (--argc > 0 )
		fprintf(stderr, "%s%c", *++argv, (argc > 1) ? ' ' : '\n');
}
