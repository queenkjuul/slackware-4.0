/* letter.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    real height;
} vghgt_;

#define vghgt_1 vghgt_

struct {
    real sx[50], sy[50], sa[50], sh[50];
    integer sc[50], so[50], sm[50], ntex;
} vgtx1_;

#define vgtx1_1 vgtx1_

struct {
    char st[3500];
} vgtx2_;

#define vgtx2_1 vgtx2_

struct {
    real bleft1[7], brit1[7], bbot1[7], btop1[7], bxmin[7], bxmax[7], bymin[
	    14]	/* was [7][2] */, bymax[14]	/* was [7][2] */;
    integer ninlx[7], naxlx[7], ninly[14]	/* was [7][2] */, naxly[14]	
	    /* was [7][2] */, msx[7], msy[14]	/* was [7][2] */;
} vglim_;

#define vglim_1 vglim_

struct {
    integer ig;
} vgcntr_;

#define vgcntr_1 vgcntr_

struct {
    real abot[7], atop[7], aleft[7], arit[7];
    integer jsdx[7], jsdy1[7], jsdy2[7], kldg1[7], axcol;
} vglttr_;

#define vglttr_1 vglttr_

struct {
    real smin[21]	/* was [7][3] */, smax[21]	/* was [7][3] */;
    integer limflg[21]	/* was [7][3] */;
    real tmin[21]	/* was [7][3] */, tmax[21]	/* was [7][3] */;
} vgsbnd_;

#define vgsbnd_1 vgsbnd_

struct {
    logical yestic[21]	/* was [7][3] */;
    integer ntikh[7], ntikv1[7], ntikv2[7];
} vgtic1_;

#define vgtic1_1 vgtic1_

struct {
    char ticstr[5880]	/* was [7][3][14] */;
} vgtic2_;

#define vgtic2_1 vgtic2_

struct {
    integer labels[28]	/* was [7][4] */;
} vglab_;

#define vglab_1 vglab_

struct {
    real subsz, suprsz;
} vgssiz_;

#define vgssiz_1 vgssiz_

/* Table of constant values */

static integer c__8 = 8;
static integer c__7 = 7;
static integer c__2 = 2;
static integer c__6 = 6;
static integer c__5 = 5;
static integer c__4 = 4;
static integer c__3 = 3;
static integer c__1 = 1;
static real c_b25 = 0.f;
static integer c__0 = 0;
static real c_b56 = 10.f;

integer vgincg_(integer *ntick, real *dist, real *size, integer *logflg, 
	integer *vtflg)
{
    /* Initialized data */

    static integer intrvl[84]	/* was [7][12] */ = { 1,2,5,0,0,0,0,1,2,3,6,0,
	    0,0,1,2,3,7,0,0,0,1,2,4,8,0,0,0,1,3,9,0,0,0,0,1,2,5,10,0,0,0,1,2,
	    3,11,0,0,0,1,2,3,4,12,0,0,1,2,3,4,13,0,0,1,2,3,7,14,0,0,1,3,4,5,
	    15,0,0,1,2,4,8,16,0,0 };

    /* System generated locals */
    integer ret_val;
    real r__1, r__2;

    /* Local variables */
    static real comp;
    static integer i__;

/*       NEW VERSION 11 OCT 1988 (DKK-GTC) */
/*  RETURNS VGINCG SUCH THAT A NUMBER SHOULD BE PUT AT EVERY */
/*  VGINCG-TH TICK. */
/*  VTFLG (INPUT): 1 FOR A VERTICAL AXIS, 0 FOR HORIZONTAL.  (THE */
/*  VERTICAL NUMBERS GET A DIFFERENT SPACING THAN HORIZONTAL */
/*  NUMBERS.) */

/*  EACH LINE OF DATA BELOW IS ONE COLUMN OF INTRVL, AND REPRESENTS */
/*  THE SEQUENCE OF TICK SPACINGS THAT WILL BE TRIED FOR ONE NTICK */
/*  VALUE.  ADDED LINES FOR 5 AND 6 TICS (DRA 1 AUG 89) */

    if (*vtflg == 1) {
	comp = *size * 1.8f;
    } else {
/*        COMP=1.5*SIZE */
/* Computing MIN */
	r__1 = *size + vghgt_1.height * 2, r__2 = *size * 1.5f;
	comp = dmin(r__1,r__2);
    }
    if (*logflg == 1) {
	if (*dist > comp) {
	    ret_val = 1;
	} else {
	    ret_val = *ntick;
	}
    } else {
	for (i__ = 1; i__ <= 7; ++i__) {
	    ret_val = intrvl[i__ + *ntick * 7 - 36];
	    if (ret_val == *ntick || *dist * ret_val > comp) {
		return ret_val;
	    }
/* L100: */
	}
    }
    return ret_val;
} /* vgincg_ */

/* Subroutine */ int vgletr_(integer *kg, logical *nodraw)
{
    /* System generated locals */
    integer i__1, i__2;
    real r__1;

    /* Builtin functions */
    integer pow_ii(integer *, integer *);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer incr, isdx;
    static real xmin, xmax;
    extern /* Subroutine */ int vgnp_(integer *);
    static real bbot0, brit0, btop0;
    static integer isdy1, isdy2;
    static real ymin1, ymin2, ymax1, ymax2;
    static integer i__;
    static real x, y;
    static integer iside;
    extern /* Subroutine */ int vgali_(char *, integer *, real *, integer *, 
	    real *, integer *, integer *, ftnlen);
    static real hdist;
    static integer right;
    static real blsiz;
    static integer nlast, numbx;
    static real llsiz;
    extern /* Subroutine */ int vgnum_(real *, real *, integer *, integer *, 
	    integer *, real *, char *, integer *, real *, real *, integer *, 
	    integer *, ftnlen);
    static real vdist, start, rlsiz, tlsiz, bleft0;
    static integer numby1, numby2, lablef, nh;
    static real biglef;
    static integer jhcode;
    static real hafhgt;
    static integer labbot, lenlef[21];
    static real bigbot, hgtlef[21], widlef[21];
    extern integer vgincg_(integer *, real *, real *, integer *, integer *);
    static integer kludge;
    static real bigrit;
    static integer labtop, labrit, lenbot[21];
    static real bigtop;
    static char lefnum[20*20];
    static real hgtbot[21], widbot[21];
    static integer jvcode;
    static real tmplef, hafsub;
    static integer lenrit[21];
    static real ovrlef;
    extern /* Subroutine */ int vgmsra_(integer *, char *, integer *, real *, 
	    real *, ftnlen);
    static real hgtrit[21], widrit[21];
    static char botnum[20*20];
    static real tmpbot, subhgt, ginlef, ginrit, gintop, ginbot;
    extern /* Subroutine */ int vgcmnt_(char *, ftnlen), vgsmbl_(real *, real 
	    *, real *, char *, real *, integer *, ftnlen);
    extern integer vgistr_(char *, ftnlen);
    static char ritnum[20*20];
    static real tmprit;
    extern /* Subroutine */ int vglcmp_(real *, real *, real *, real *, real *
	    , real *, real *, real *, integer *);
    static integer nfirst;
    static real tmptop;
    static integer nv1, nv2;
    static real ovrrit;
    extern /* Subroutine */ int vgfxtx_(real *, real *, real *, real *, real *
	    , real *, real *, real *, integer *);
    static integer len;

/*  ORIGINAL NAME XYL.  DRAWS NUMBERS AND LABELS ON A GRAPH'S AXES. */
/*  AS A SIDE EFFECT, IT CHANGES THE COORDINATES OF THE GRAPH'S INNER */
/*  FRAME, SO IT NEEDS TO BE CALLED BEFORE OTHER ROUTINES THAT NEED THAT 
*/
/*  DATA (VGADR NOTABLY). */
    widrit[0] = 0.f;
    widbot[1] = 0.f;
    bigrit = 0.f;
    biglef = 0.f;
    bigtop = 0.f;
    bigbot = 0.f;
    tlsiz = 0.f;
    blsiz = 0.f;
    llsiz = 0.f;
    rlsiz = 0.f;
    right = 0;
/*  EXTRACT CURRENT GRAPH'S DATA FROM ARRAYS */
    nh = vgtic1_1.ntikh[*kg - 1];
    nv1 = vgtic1_1.ntikv1[*kg - 1];
    nv2 = vgtic1_1.ntikv2[*kg - 1];
    bbot0 = vglttr_1.abot[*kg - 1];
    btop0 = vglttr_1.atop[*kg - 1];
    bleft0 = vglttr_1.aleft[*kg - 1];
    brit0 = vglttr_1.arit[*kg - 1];
    isdx = vglttr_1.jsdx[*kg - 1];
    isdy1 = vglttr_1.jsdy1[*kg - 1];
    isdy2 = vglttr_1.jsdy2[*kg - 1];
    kludge = vglttr_1.kldg1[*kg - 1];
    xmin = vgsbnd_1.tmin[*kg - 1];
    ymin1 = vgsbnd_1.tmin[*kg + 6];
    ymin2 = vgsbnd_1.tmin[*kg + 13];
    xmax = vgsbnd_1.tmax[*kg - 1];
    ymax1 = vgsbnd_1.tmax[*kg + 6];
    ymax2 = vgsbnd_1.tmax[*kg + 13];
    labtop = vglab_1.labels[*kg + 20];
    labbot = vglab_1.labels[*kg - 1];
    lablef = vglab_1.labels[*kg + 6];
    labrit = vglab_1.labels[*kg + 13];
/*  UNPACK DATA IN KLUDGE */
    jhcode = (kludge / pow_ii(&c__2, &c__8) % 2 << 1) + kludge / pow_ii(&c__2,
	     &c__7) % 2;
    jvcode = (kludge / pow_ii(&c__2, &c__6) % 2 << 1) + kludge / pow_ii(&c__2,
	     &c__5) % 2;
    numbx = kludge / pow_ii(&c__2, &c__4) % 2;
    numby1 = kludge / pow_ii(&c__2, &c__3) % 2;
    numby2 = kludge / pow_ii(&c__2, &c__2) % 2;
/*  SAVE CURRENT INNER FRAME */
    tmptop = vglim_1.btop1[*kg - 1];
    tmpbot = vglim_1.bbot1[*kg - 1];
    tmplef = vglim_1.bleft1[*kg - 1];
    tmprit = vglim_1.brit1[*kg - 1];
    hafhgt = vghgt_1.height * .5f;
    if (numbx == 0) {
/*  USER DESIRES NUMBERED X-AXIS */
	if (vgtic1_1.yestic[*kg - 1]) {
/*  USER HAS PROVIDED TEXT FOR X-AXIS TIC MARKS */
	    i__1 = nh + 1;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		s_copy(botnum + (i__ - 1) * 20, vgtic2_1.ticstr + (*kg + (i__ 
			* 3 + 1) * 7 - 29) * 20, 20L, 20L);
/* L1: */
	    }
	    vgmsra_(&nh, botnum, lenbot, hgtbot, widbot, 20L);
	} else {
	    vgnum_(&xmin, &xmax, &vglim_1.ninlx[*kg - 1], &vglim_1.naxlx[*kg 
		    - 1], &nh, &vghgt_1.height, botnum, lenbot, hgtbot, 
		    widbot, &vglim_1.msx[*kg - 1], &isdx, 20L);
	}
	bigbot = hgtbot[0] + hafhgt;
	if (jhcode == 1) {
	    bigtop = hgtbot[0] + hafhgt;
	}
    } else {
	widbot[nh + 1] = 0.f;
    }
    if (numby1 == 0) {
/*  USER DESIRES NUMBERED LEFT Y-AXIS */
	if (vgtic1_1.yestic[*kg + 6]) {
/*  USER HAS PROVIDED TEXT FOR LEFT Y-AXIS TIC MARKS */
	    i__1 = nv1 + 1;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		s_copy(lefnum + (i__ - 1) * 20, vgtic2_1.ticstr + (*kg + (i__ 
			* 3 + 2) * 7 - 29) * 20, 20L, 20L);
/* L2: */
	    }
	    vgmsra_(&nv1, lefnum, lenlef, hgtlef, widlef, 20L);
	} else {
	    vgnum_(&ymin1, &ymax1, &vglim_1.ninly[*kg - 1], &vglim_1.naxly[*
		    kg - 1], &nv1, &vghgt_1.height, lefnum, lenlef, hgtlef, 
		    widlef, &vglim_1.msy[*kg - 1], &isdy1, 20L);
/* wea added arguments to vgali to take care of log axis */
	    vgali_(lefnum, lenlef, widlef, &nv1, &vghgt_1.height, &right, &
		    vglim_1.msy[*kg - 1], 20L);
	}
	ovrlef = widbot[1] * .5f;
/* Computing MAX */
	r__1 = widlef[0] + hafhgt;
	biglef = dmax(r__1,ovrlef);
    }
    if (numby2 == 0 && (jvcode == 1 || jvcode == 3)) {
/*  USER DESIRES NUMBERED RIGHT Y-AXIS */
	if (vgtic1_1.yestic[*kg + 13]) {
/*  USER HAS PROVIDED TEXT FOR RIGHT Y-AXIS TIC MARKS */
	    i__1 = nv2 + 1;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		s_copy(ritnum + (i__ - 1) * 20, vgtic2_1.ticstr + (*kg + (i__ 
			* 3 + 3) * 7 - 29) * 20, 20L, 20L);
/* L3: */
	    }
	    vgmsra_(&nv2, ritnum, lenrit, hgtrit, widrit, 20L);
	} else {
	    right = 1;
	    if (jvcode == 1) {
		nv2 = nv1;
		vgnum_(&ymin1, &ymax1, &vglim_1.ninly[*kg - 1], &
			vglim_1.naxly[*kg - 1], &nv2, &vghgt_1.height, ritnum,
			 lenrit, hgtrit, widrit, &vglim_1.msy[*kg - 1], &
			isdy1, 20L);
/* wea added arguments to vgali to take care of log axis */
		vgali_(ritnum, lenrit, widrit, &nv2, &vghgt_1.height, &right, 
			&vglim_1.msy[*kg - 1], 20L);
	    } else {
		vgnum_(&ymin2, &ymax2, &vglim_1.ninly[*kg + 6], &
			vglim_1.naxly[*kg + 6], &nv2, &vghgt_1.height, ritnum,
			 lenrit, hgtrit, widrit, &vglim_1.msy[*kg + 6], &
			isdy2, 20L);
/* wea added arguments to vgali to take care of log axis */
		vgali_(ritnum, lenrit, widrit, &nv2, &vghgt_1.height, &right, 
			&vglim_1.msy[*kg + 6], 20L);
	    }
	}
    }
    ovrrit = widbot[nh + 1] * .5f;
/* Computing MAX */
    r__1 = widrit[0] + hafhgt;
    bigrit = dmax(r__1,ovrrit);
/*  INSET GRAPH EDGES TO ACCOMMODATE LABELS */
    hafsub = vgssiz_1.subsz * .5f;
    subhgt = hafsub + 1.f;
    if (labtop != 0) {
	tlsiz = vgtx1_1.sh[labtop - 1] * subhgt + hafhgt;
    }
    if (labbot != 0) {
	blsiz = vgtx1_1.sh[labbot - 1] * subhgt + hafhgt;
    }
    if (labrit != 0) {
	rlsiz = vgtx1_1.sh[labrit - 1] * subhgt + hafhgt;
    }
    if (lablef != 0) {
	llsiz = vgtx1_1.sh[lablef - 1] * subhgt + hafhgt;
    }
/*  INSET GRAPH EDGES TO ACCOMMODATE NUMBERS */
    ginlef = biglef + vghgt_1.height;
    ginrit = bigrit + vghgt_1.height;
    gintop = bigtop + vghgt_1.height;
    ginbot = bigbot + vghgt_1.height;
/*  ADJUST GRAPH EDGES */
    vglim_1.bleft1[*kg - 1] = bleft0 + ginlef + llsiz;
    vglim_1.brit1[*kg - 1] = brit0 - ginrit - rlsiz;
    vglim_1.btop1[*kg - 1] = btop0 - gintop - tlsiz;
    vglim_1.bbot1[*kg - 1] = bbot0 + ginbot + blsiz;
/*  ADJUST TEXT TO REFLECT NEW INNER FRAME */
    vgfxtx_(&tmptop, &tmpbot, &tmplef, &tmprit, &vglim_1.btop1[*kg - 1], &
	    vglim_1.bbot1[*kg - 1], &vglim_1.bleft1[*kg - 1], &vglim_1.brit1[*
	    kg - 1], kg);
/*  ADJUST LABELS */
    if (labtop != 0) {
	vgtx1_1.sy[labtop - 1] = vglim_1.btop1[*kg - 1] + gintop + vgtx1_1.sh[
		labtop - 1] * hafsub;
    }
    if (labbot != 0) {
	vgtx1_1.sy[labbot - 1] = vglim_1.bbot1[*kg - 1] - ginbot - vgtx1_1.sh[
		labbot - 1] * (hafsub + 1);
    }
    if (lablef != 0) {
	vgtx1_1.sx[lablef - 1] = vglim_1.bleft1[*kg - 1] - ginlef - 
		vgtx1_1.sh[lablef - 1] * hafsub;
    }
    if (labrit != 0) {
	vgtx1_1.sx[labrit - 1] = vglim_1.brit1[*kg - 1] + ginrit + vgtx1_1.sh[
		labrit - 1] * hafsub;
    }
    if (! (*nodraw)) {
/*  DRAW TEXT ON THE GRAPH */
	vgcmnt_("Drawing...", 10L);
	i__1 = vgtx1_1.ntex;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if (vgtx1_1.so[i__ - 1] == *kg) {
		len = vgistr_(vgtx2_1.st + (i__ - 1) * 70, 70L);
		vgnp_(&vgtx1_1.sc[i__ - 1]);
		vgsmbl_(&vgtx1_1.sx[i__ - 1], &vgtx1_1.sy[i__ - 1], &
			vgtx1_1.sh[i__ - 1], vgtx2_1.st + (i__ - 1) * 70, &
			vgtx1_1.sa[i__ - 1], &len, 70L);
	    }
/* L50: */
	}
/*  NUMBER AXES */
	vgnp_(&vglttr_1.axcol);
	if (numby1 == 0) {
	    vglcmp_(&vdist, &start, &vglim_1.bbot1[*kg - 1], &vglim_1.btop1[*
		    kg - 1], &vglim_1.bymin[*kg - 1], &vglim_1.bymax[*kg - 1],
		     &vgsbnd_1.tmin[*kg + 6], &vgsbnd_1.tmax[*kg + 6], &nv1);
	    if (vgsbnd_1.tmin[*kg + 6] < vglim_1.bymin[*kg - 1]) {
		nfirst = 1;
	    } else {
		nfirst = 0;
	    }
	    if (vgsbnd_1.tmax[*kg + 6] > vglim_1.bymax[*kg - 1]) {
		nlast = nv1 - 1;
	    } else {
		nlast = nv1;
	    }
	    if (vgtic1_1.yestic[*kg + 6]) {
		incr = 1;
	    } else {
		incr = vgincg_(&nv1, &vdist, hgtlef, &vglim_1.msy[*kg - 1], &
			c__1);
	    }
	    i__1 = nlast;
	    i__2 = incr;
	    for (i__ = nfirst; i__2 < 0 ? i__ >= i__1 : i__ <= i__1; i__ += 
		    i__2) {
		y = start + i__ * vdist;
		if (y >= vglim_1.bbot1[*kg - 1] && y <= vglim_1.btop1[*kg - 1]
			 + .01f) {
		    y -= hgtlef[i__ + 1] * .5f;
		    x = vglim_1.bleft1[*kg - 1] - (hafhgt + widlef[i__ + 1]);
		    vgsmbl_(&x, &y, &vghgt_1.height, lefnum + i__ * 20, &
			    c_b25, &lenlef[i__ + 1], 20L);
		}
/* L100: */
	    }
	}
	if (numby2 == 0) {
	    if (jvcode == 1 || jvcode == 3) {
		if (jvcode == 1) {
		    iside = 1;
		} else {
		    iside = 2;
		}
		vglcmp_(&vdist, &start, &vglim_1.bbot1[*kg - 1], &
			vglim_1.btop1[*kg - 1], &vglim_1.bymin[*kg + iside * 
			7 - 8], &vglim_1.bymax[*kg + iside * 7 - 8], &
			vgsbnd_1.tmin[*kg + (iside + 1) * 7 - 8], &
			vgsbnd_1.tmax[*kg + (iside + 1) * 7 - 8], &nv2);
		if (vgsbnd_1.tmin[*kg + 13] < vglim_1.bymin[*kg + 6]) {
		    nfirst = 1;
		} else {
		    nfirst = 0;
		}
		if (vgsbnd_1.tmax[*kg + 13] > vglim_1.bymax[*kg + 6]) {
		    nlast = nv2 - 1;
		} else {
		    nlast = nv2;
		}
		if (vgtic1_1.yestic[*kg + 13]) {
		    incr = 1;
		} else {
		    incr = vgincg_(&nv2, &vdist, hgtrit, &vglim_1.msy[*kg + 6]
			    , &c__1);
		}
		x = vglim_1.brit1[*kg - 1] + hafhgt;
		i__2 = nlast;
		i__1 = incr;
		for (i__ = nfirst; i__1 < 0 ? i__ >= i__2 : i__ <= i__2; i__ 
			+= i__1) {
		    y = start + i__ * vdist;
		    if (y >= vglim_1.bbot1[*kg - 1] && y <= vglim_1.btop1[*kg 
			    - 1] + .01f) {
			y -= hgtrit[i__ + 1] * .5f;
			vgsmbl_(&x, &y, &vghgt_1.height, ritnum + i__ * 20, &
				c_b25, &lenrit[i__ + 1], 20L);
		    }
/* L200: */
		}
	    }
	}
	if (numbx == 0) {
	    vglcmp_(&hdist, &start, &vglim_1.bleft1[*kg - 1], &vglim_1.brit1[*
		    kg - 1], &vglim_1.bxmin[*kg - 1], &vglim_1.bxmax[*kg - 1],
		     &vgsbnd_1.tmin[*kg - 1], &vgsbnd_1.tmax[*kg - 1], &nh);
	    if (vgsbnd_1.tmin[*kg - 1] < vglim_1.bxmin[*kg - 1]) {
		nfirst = 1;
	    } else {
		nfirst = 0;
	    }
	    if (vgsbnd_1.tmax[*kg - 1] > vglim_1.bxmax[*kg - 1]) {
		nlast = nh - 1;
	    } else {
		nlast = nh;
	    }
	    if (vgtic1_1.yestic[*kg - 1]) {
		incr = 1;
	    } else {
		i__1 = nlast - nfirst;
		incr = vgincg_(&i__1, &hdist, widbot, &vglim_1.msx[*kg - 1], &
			c__0);
	    }
	    y = vglim_1.bbot1[*kg - 1] - hgtbot[0] - vghgt_1.height;
	    i__1 = nlast;
	    i__2 = incr;
	    for (i__ = nfirst; i__2 < 0 ? i__ >= i__1 : i__ <= i__1; i__ += 
		    i__2) {
		x = start + i__ * hdist;
		x -= widbot[i__ + 1] * .5f;
		vgsmbl_(&x, &y, &vghgt_1.height, botnum + i__ * 20, &c_b25, &
			lenbot[i__ + 1], 20L);
/* L300: */
	    }
	    if (jhcode == 1) {
		y = vglim_1.btop1[*kg - 1] + (hafhgt + hgtbot[0]);
		i__2 = nh;
		i__1 = incr;
		for (i__ = 0; i__1 < 0 ? i__ >= i__2 : i__ <= i__2; i__ += 
			i__1) {
		    x = start + i__ * hdist;
		    if (x >= vglim_1.bleft1[*kg - 1] - .01f && x <= 
			    vglim_1.brit1[*kg - 1] + .01f) {
			x -= widbot[i__ + 1] * .5f;
			vgsmbl_(&x, &y, &vghgt_1.height, botnum + i__ * 20, &
				c_b25, &lenbot[i__ + 1], 20L);
		    }
/* L400: */
		}
	    }
	}
	vgcmnt_("Drawing...", 10L);
    }
    return 0;
} /* vgletr_ */

/* Subroutine */ int vgali_(char *num, integer *len, real *wid, integer *nnum,
	 real *size, integer *right, integer *logflg, ftnlen num_len)
{
    /* Initialized data */

    static char space[8] = "        ";

    /* System generated locals */
    address a__1[2];
    integer i__1, i__2, i__3, i__4[2];
    real r__1, r__2;

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen), s_cat(char *,
	     char **, integer *, integer *, ftnlen);

    /* Local variables */
    static char temp[20];
    static integer i__, j, locatn[20], maxloc, lenmax;
    static real widmax;
    static integer numspc;

/* wea added arguments to vgali to take care of log axis */
/*              ORIGINAL NAME ALIGN */
/*        ALIGNS INPUT NUMBERS IN ARRAY NUM ON THE RIGHT BY */
/*         PADDING THE LEFT EDGE OF EACH, IF NECESSARY. */
/*        ASSUMES THAT THE STRINGS IN NUM HAVE EITHER THE SAME */
/*         NUMBER OF DIGITS TO THE RIGHT OF THE DECIMAL POINT, */
/*         OR NO DECIMAL POINT. */
/*        ASSUMES AT MOST 20 NUMBERS (NNUM) TO BE ALIGNED. */

    /* Parameter adjustments */
    num -= 20;

    /* Function Body */
    maxloc = -1;
    i__1 = *nnum + 1;
    for (i__ = 1; i__ <= i__1; ++i__) {
	s_copy(temp, num + i__ * 20, 20L, 20L);
	i__2 = len[i__];
	for (j = 1; j <= i__2; ++j) {
/*            LOOK FOR POSITION OF DECIMAL POINT IN NUM(I) */
	    if (*(unsigned char *)&temp[j - 1] == '.') {
		locatn[i__ - 1] = j;
		goto L11;
	    }
/* L10: */
	}
/*         NO DECIMAL, SET LOCATN(I) TO LEN(I)+1 */
	locatn[i__ - 1] = j;
L11:
/*         FIND MAXIMUM NUMBER OF DIGITS TO LEFT OF DECIMAL POINT */
/* Computing MAX */
	i__2 = maxloc, i__3 = locatn[i__ - 1];
	maxloc = max(i__2,i__3);
/* L20: */
    }
/*  PAD NUMBERS WITH SPACES ON THE LEFT, AND FIND MAXIMUM SIZE OF STRINGS 
*/
    lenmax = len[0];
    widmax = wid[0];
/* do not align right-hand log axis */
    if (*right != 1 || *right == 1 && *logflg == 0) {
	i__1 = *nnum + 1;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    numspc = maxloc - locatn[i__ - 1];
	    len[i__] += numspc;
	    wid[i__] += numspc * *size;
	    if (numspc == 0) {
		s_copy(temp, num + i__ * 20, 20L, 20L);
	    } else {
/* Writing concatenation */
		i__4[0] = numspc, a__1[0] = space;
		i__4[1] = 20, a__1[1] = num + i__ * 20;
		s_cat(temp, a__1, i__4, &c__2, 20L);
	    }
	    s_copy(num + i__ * 20, temp, 20L, 20L);
/* Computing MAX */
	    i__2 = lenmax, i__3 = len[i__];
	    lenmax = max(i__2,i__3);
/* Computing MAX */
	    r__1 = widmax, r__2 = wid[i__];
	    widmax = dmax(r__1,r__2);
/* L30: */
	}
    }
    len[0] = lenmax;
    wid[0] = widmax;
    return 0;
} /* vgali_ */

/* Subroutine */ int vgunp_(char *astrng, ftnlen astrng_len)
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static char temp[80];
    static integer i__;
    extern integer vgistr_(char *, ftnlen);
    static integer len;

/*   ORIGINAL NAME UNPAD.  REMOVES LEADING AND TRAILING SPACES */
/*   FROM A STRING. */
    len = vgistr_(astrng, astrng_len);
    i__1 = len;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (*(unsigned char *)&astrng[i__ - 1] != ' ') {
	    goto L20;
	}
/* L10: */
    }
L20:
    s_copy(temp, astrng + (i__ - 1), 80L, len - (i__ - 1));
    s_copy(astrng, temp, astrng_len, 80L);
    return 0;
} /* vgunp_ */

/* Subroutine */ int vgnum_(real *amin, real *amax, integer *logmin, integer *
	logmax, integer *nticks, real *size, char *num, integer *len, real *
	hgt, real *wid, integer *logflg, integer *isd, ftnlen num_len)
{
    /* System generated locals */
    address a__1[2], a__2[3];
    integer i__1, i__2, i__3[2], i__4, i__5[3];
    real r__1, r__2, r__3;

    /* Builtin functions */
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen),
	     s_copy(char *, char *, ftnlen, ftnlen);
    double pow_ri(real *, integer *), r_sign(real *, real *);
    integer s_cmp(char *, char *, ftnlen, ftnlen), i_indx(char *, char *, 
	    ftnlen, ftnlen);

    /* Local variables */
    static integer mdec;
    static real dist;
    static char temp[20], temp2[20];
    static integer i__, j, k, ndrit;
    extern /* Subroutine */ int vgunp_(char *, ftnlen);
    static integer i10, mindec;
    extern integer vgidec_(real *);
    static integer maxdec, ndleft;
    static real ticval;
    static integer lenmax;
    extern integer vglgin_(integer *, integer *), vgisig_(real *);
    static real widmax, hgtmax;
    static integer incrmt;
    static char lognum[4];
    static logical eq0;
    extern integer vgistr_(char *, ftnlen);
    static integer lng;

    /* Fortran I/O blocks */
    static icilist io___91 = { 0, lognum, 0, "(I3)", 4, 1 };
    static icilist io___103 = { 0, temp, 0, "(F16.8)", 20, 1 };
    static icilist io___106 = { 0, temp, 0, "(1PE13.5)", 20, 1 };


/*  ORIGINAL NAME NUMBER.  PRODUCES NUMBERS (AS STRINGS) TO BE */
/*  PLACED ALONG A GRAPH'S AXES. */
    /* Parameter adjustments */
    num -= 20;

    /* Function Body */
    if (*logflg == 1) {
/*  CREATE LOG NUMBERS */
	incrmt = vglgin_(logmin, logmax);
	i__1 = *nticks + 1;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    i10 = *logmin + (i__ - 1) * incrmt;
	    s_wsfi(&io___91);
	    do_fio(&c__1, (char *)&i10, (ftnlen)sizeof(integer));
	    e_wsfi();
	    vgunp_(lognum, 4L);
	    lng = vgistr_(lognum, 4L);
	    i__2 = lng;
	    for (j = 1; j <= i__2; ++j) {
/* Writing concatenation */
		i__3[0] = 1, a__1[0] = "^";
		i__3[1] = 1, a__1[1] = lognum + (j - 1);
		s_cat(temp, a__1, i__3, &c__2, 20L);
		i__4 = j - 1 << 1;
		s_copy(temp2 + i__4, temp, (j << 1) - i__4, 2L);
/* L10: */
	    }
/* Writing concatenation */
	    i__3[0] = 2, a__1[0] = "10";
	    i__3[1] = lng << 1, a__1[1] = temp2;
	    s_cat(num + i__ * 20, a__1, i__3, &c__2, 20L);
	    len[i__] = (lng << 1) + 2;
	    wid[i__] = *size * (lng * .7f + 2);
	    hgt[i__] = *size * 1.2f;
/* L20: */
	}
    } else {
/*  CREATE LINEAR NUMBERS */
	dist = (*amax - *amin) / *nticks;
	if (vgisig_(amin) - 6 <= vgidec_(amin) && vgidec_(amin) <= 6 && 
		vgisig_(amax) - 6 <= vgidec_(amax) && vgidec_(amax) <= 6) {
/*  NON-EXPONENTIAL NOTATION LINEAR NUMBERS: */
	    mindec = vgidec_(amin);
	    maxdec = vgidec_(amax);
	    mdec = max(mindec,maxdec);
	    if (*amin >= 0.f) {
		ndleft = max(1,mdec);
	    } else {
		if (mdec <= 1) {
		    ndleft = 2;
		} else if (mindec >= maxdec) {
		    ndleft = mdec + 1;
		} else {
		    ndleft = mdec;
		}
	    }
	    ndrit = -1;
	    if (*isd <= 0) {
		ndrit = 1 - *isd;
	    }
	    i__1 = *nticks + 1;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		ticval = *amin + dist * (i__ - 1);
		if (ndrit > 0) {
		    i__2 = -ndrit - 1;
		    r__1 = (real)pow_ri(&c_b56, &i__2);
		    ticval += (real)r_sign(&r__1, &ticval);
		}
		s_wsfi(&io___103);
		do_fio(&c__1, (char *)&ticval, (ftnlen)sizeof(real));
		e_wsfi();
		if (s_cmp(temp, "-.", 2L, 2L) == 0) {
/* Writing concatenation */
		    i__3[0] = 3, a__1[0] = "-0.";
		    i__3[1] = 18, a__1[1] = temp + 2;
		    s_cat(temp2, a__1, i__3, &c__2, 20L);
		    s_copy(temp, temp2, 20L, 20L);
		}
		lng = vgistr_(temp, 20L);
		i__2 = lng;
		for (j = 1; j <= i__2; ++j) {
		    if (*(unsigned char *)&temp[j - 1] == '.') {
			goto L40;
		    }
/* L30: */
		}
L40:
		i__2 = j - ndleft - 1;
		s_copy(temp2, temp + i__2, 20L, j + ndrit - i__2);
		s_copy(temp, temp2, 20L, 20L);
		if (dabs(ticval) <= 1e-6f) {
		    s_copy(temp2, "0.000000", 20L, 8L);
		    s_copy(temp, temp2, 20L, ndrit + 2);
		}
/*  NEXT FEW LINES PREVENT WRITING '-0.0' RATHER THAN 0.0 (DRA
 29 JUNE 89) */
		if (*(unsigned char *)temp == '-') {
		    eq0 = TRUE_;
		    lng = vgistr_(temp, 20L);
		    i__2 = lng;
		    for (j = 2; j <= i__2; ++j) {
			if (i_indx("0.", temp + (j - 1), 2L, 1L) <= 0) {
			    eq0 = FALSE_;
			}
/* L45: */
		    }
		} else {
		    eq0 = FALSE_;
		}
		if (eq0) {
		    s_copy(temp2, "0.000000", 20L, 8L);
		    s_copy(temp, temp2, 20L, ndrit + 2);
		}
/*  END OF '-0.0' FIX */
		vgunp_(temp, 20L);
		s_copy(num + i__ * 20, temp, 20L, 20L);
		len[i__] = vgistr_(temp, 20L);
		wid[i__] = len[i__] * *size;
		hgt[i__] = *size;
/* L50: */
	    }
	} else {
/*  CREATE LINEAR NUMBERS IN EXPONENTIAL FORM */
/* Computing MAX */
	    r__2 = dabs(*amin), r__3 = dabs(*amax);
	    r__1 = dmax(r__2,r__3);
	    k = vgidec_(&r__1) - *isd + 1;
	    k = min(k,6);
	    i__1 = *nticks + 1;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		ticval = *amin + (i__ - 1) * dist;
/*           WRITE(TEMP,'(1PE13.6)')TICVAL */
		s_wsfi(&io___106);
		do_fio(&c__1, (char *)&ticval, (ftnlen)sizeof(real));
		e_wsfi();
		if (ticval >= 0.f) {
/*             TEMP2=TEMP(2:3+K)//TEMP(10:13) */
/* Writing concatenation */
		    i__5[0] = k + 1, a__2[0] = temp + 1;
		    i__5[1] = 1, a__2[1] = "0";
		    i__5[2] = 4, a__2[2] = temp + 9;
		    s_cat(temp2, a__2, i__5, &c__3, 20L);
		    s_copy(temp, temp2, 20L, 20L);
		} else {
/* Writing concatenation */
		    i__5[0] = k + 2, a__2[0] = temp;
		    i__5[1] = 1, a__2[1] = "0";
		    i__5[2] = 4, a__2[2] = temp + 9;
		    s_cat(temp2, a__2, i__5, &c__3, 20L);
		    s_copy(temp, temp2, 20L, 20L);
		}
		if ((r__1 = ticval / (*amax - *amin), dabs(r__1)) <= 1e-7f) {
		    s_copy(temp2, "0.000000", 20L, 8L);
		    s_copy(temp, temp2, 20L, k + 2);
		}
		s_copy(num + i__ * 20, temp, 20L, 20L);
		len[i__] = vgistr_(temp, 20L);
		wid[i__] = len[i__] * *size;
		hgt[i__] = *size;
/* L350: */
	    }
	}
    }
    lenmax = 0;
    widmax = 0.f;
    hgtmax = 0.f;
    i__1 = *nticks + 1;
    for (i__ = 1; i__ <= i__1; ++i__) {
/* Computing MAX */
	i__2 = lenmax, i__4 = len[i__];
	lenmax = max(i__2,i__4);
/* Computing MAX */
	r__1 = widmax, r__2 = wid[i__];
	widmax = dmax(r__1,r__2);
/* Computing MAX */
	r__1 = hgtmax, r__2 = hgt[i__];
	hgtmax = dmax(r__1,r__2);
/* L400: */
    }
    len[0] = lenmax;
    wid[0] = widmax;
    hgt[0] = hgtmax;
    return 0;
} /* vgnum_ */

/* Subroutine */ int vglcmp_(real *dist, real *start, real *pmin, real *pmax, 
	real *bmin, real *bmax, real *tmin, real *tmax, integer *ntics)
{
/*  COMPUTES STARTING LOCATION AND INCREMENT DISTANCE FOR */
/*  NUMBERING AXES. */
    *dist = (*pmax - *pmin) * (*tmax - *tmin) / (*ntics * (*bmax - *bmin));
    *start = *pmin + (*tmin - *bmin) * (*pmax - *pmin) / (*bmax - *bmin);
    return 0;
} /* vglcmp_ */

/* Subroutine */ int vgmsra_(integer *ntics, char *num, integer *lng, real *
	hgt, real *wid, ftnlen num_len)
{
    /* System generated locals */
    integer i__1, i__2, i__3;
    real r__1, r__2;

    /* Local variables */
    static integer i__;
    extern /* Subroutine */ int vgmeas_(char *, integer *, real *, real *, 
	    real *, ftnlen);
    static integer lenmax;
    static real hgtmax, widmax;

/*  MEASURES ALL THE STRINGS IN AN ARRAY */
    /* Parameter adjustments */
    num -= 20;

    /* Function Body */
    lenmax = 0;
    widmax = 0.f;
    hgtmax = 0.f;
    i__1 = *ntics + 1;
    for (i__ = 1; i__ <= i__1; ++i__) {
	vgmeas_(num + i__ * 20, &lng[i__], &hgt[i__], &wid[i__], &
		vghgt_1.height, 20L);
/* Computing MAX */
	i__2 = lenmax, i__3 = lng[i__];
	lenmax = max(i__2,i__3);
/* Computing MAX */
	r__1 = widmax, r__2 = wid[i__];
	widmax = dmax(r__1,r__2);
/* Computing MAX */
	r__1 = hgtmax, r__2 = hgt[i__];
	hgtmax = dmax(r__1,r__2);
/* L10: */
    }
    lng[0] = lenmax;
    wid[0] = widmax;
    hgt[0] = hgtmax;
    return 0;
} /* vgmsra_ */

