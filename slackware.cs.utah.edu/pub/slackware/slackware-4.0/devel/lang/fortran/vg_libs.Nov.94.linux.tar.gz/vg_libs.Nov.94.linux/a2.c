/* a2.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"
#include "agraf.h"

/* Common Block Declarations */

struct {
    real bleft1[7], brit1[7], bbot1[7], btop1[7], bxmin[7], bxmax[7], bymin[
	    14]	/* was [7][2] */, bymax[14]	/* was [7][2] */;
    integer ninlx[7], naxlx[7], ninly[14]	/* was [7][2] */, naxly[14]	
	    /* was [7][2] */, msx[7], msy[14]	/* was [7][2] */;
} vglim_;

#define vglim_1 vglim_

struct {
    integer ig;
} vgcntr_;

#define vgcntr_1 vgcntr_

struct {
    real smin[21]	/* was [7][3] */, smax[21]	/* was [7][3] */;
    integer limflg[21]	/* was [7][3] */;
    real tmin[21]	/* was [7][3] */, tmax[21]	/* was [7][3] */;
} vgsbnd_;

#define vgsbnd_1 vgsbnd_

struct {
    real tikx1[7], tikx2[7], tiky1[7], tiky2[7];
} vgtick_;

#define vgtick_1 vgtick_

struct {
    integer idum[252]	/* was [14][18] */, nlines[6];
    real hh[6], vv[6], xleg[7], yleg[7];
    integer isleg[7], legset[7], legvis[6];
} vgleg1_;

#define vgleg1_1 vgleg1_

struct {
    real sht, swd;
    integer ncols, nrows;
} vgscrn_;

#define vgscrn_1 vgscrn_

/* Table of constant values */

static integer c__0 = 0;
static integer c__1 = 1;
static integer c__7 = 7;
static integer c__2 = 2;
static real c_b26 = .1f;
static real c_b28 = 1.f;
static real c_b30 = 0.f;
static real c_b34 = .35f;
static integer c__3 = 3;
static doublereal c_b66 = 10.;
static real c_b68 = 10.f;

/* Subroutine */ int vga2_(integer *ifid, integer *iz, integer *ihcode, 
	integer *ivcode, integer *nh, integer *nv1, integer *nv2, integer *
	axcol, logical *axes)
{
    /* Initialized data */

    static integer lenx = 0;
    static integer leny1 = 0;
    static integer leny2 = 0;
    static real xmin0 = 0.f;
    static real xmax0 = 0.f;
    static real y1min0 = 0.f;
    static real y1max0 = 0.f;
    static real y2min0 = 0.f;
    static real y2max0 = 0.f;

    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    double r_sign(real *, real *);

    /* Local variables */
    extern /* Subroutine */ int vgpl_(real *, real *, integer *), vgsr_(real *
	    , integer *, real *, real *, integer *, integer *, real *, real *,
	     integer *, real *, real *, integer *);
    static integer i__;
    static real xaxis[100];
    extern /* Subroutine */ int vgdrw_(real *, real *, integer *, integer *, 
	    integer *, integer *, real *, integer *, integer *);
    static real y1axis[100], y2axis[100];

/*  ORIGINAL NAME A2.  DRAWS GRAPH'S FRAME, FIDICIAL POINTS, AND AXES, */
/*  IF DESIRED. */
    /* Parameter adjustments */
    --axes;

    /* Function Body */
    vgsr_(xaxis, &vglim_1.msx[vgcntr_1.ig - 1], &vgsbnd_1.tmin[vgcntr_1.ig - 
	    1], &vgsbnd_1.tmax[vgcntr_1.ig - 1], &vglim_1.ninlx[vgcntr_1.ig - 
	    1], &vglim_1.naxlx[vgcntr_1.ig - 1], &vglim_1.bxmin[vgcntr_1.ig - 
	    1], &vglim_1.bxmax[vgcntr_1.ig - 1], nh, &xmin0, &xmax0, &lenx);
    vgsr_(y1axis, &vglim_1.msy[vgcntr_1.ig - 1], &vgsbnd_1.tmin[vgcntr_1.ig + 
	    6], &vgsbnd_1.tmax[vgcntr_1.ig + 6], &vglim_1.ninly[vgcntr_1.ig - 
	    1], &vglim_1.naxly[vgcntr_1.ig - 1], &vglim_1.bymin[vgcntr_1.ig - 
	    1], &vglim_1.bymax[vgcntr_1.ig - 1], nv1, &y1min0, &y1max0, &
	    leny1);
    if (*ivcode == 3) {
	vgsr_(y2axis, &vglim_1.msy[vgcntr_1.ig + 6], &vgsbnd_1.tmin[
		vgcntr_1.ig + 13], &vgsbnd_1.tmax[vgcntr_1.ig + 13], &
		vglim_1.ninly[vgcntr_1.ig + 6], &vglim_1.naxly[vgcntr_1.ig + 
		6], &vglim_1.bymin[vgcntr_1.ig + 6], &vglim_1.bymax[
		vgcntr_1.ig + 6], nv2, &y2min0, &y2max0, &leny2);
    }
/* PLOT GRAPH BOUNDARIES IN ORDER BOTTOM, TOP, LEFT, RIGHT */
/* WEA 12/31/89 MODIFIED CODE BELOW TO PERMIT ADJUSTABLE SIZE TICK MARKS 
*/
/*     PARTICULARLY USEFUL FOR HISTOGRAM PLOTS(I.E. ZERO-LENGTH */
/*     TIC MARKS) */
    if (axes[1]) {
/*         CALL VGDRW(Y1MIN0,XAXIS,0,1,7,AXCOL,0.35,LENX,1) */
	vgdrw_(&y1min0, xaxis, &c__0, &c__1, &c__7, axcol, &vgtick_1.tikx1[
		vgcntr_1.ig - 1], &lenx, &c__1);
	if (*ihcode != 2) {
/*           CALL VGDRW(Y1MAX0,XAXIS,0,1,7,AXCOL,0.35,LENX,1) */
	    vgdrw_(&y1max0, xaxis, &c__0, &c__1, &c__7, axcol, &
		    vgtick_1.tikx2[vgcntr_1.ig - 1], &lenx, &c__1);
	}
    }
    if (axes[2]) {
/*         CALL VGDRW(XMIN0,Y1AXIS,1,1,7,AXCOL,0.35,LENY1,1) */
	vgdrw_(&xmin0, y1axis, &c__1, &c__1, &c__7, axcol, &vgtick_1.tiky1[
		vgcntr_1.ig - 1], &leny1, &c__1);
	if (*ivcode == 1 || *ivcode == 0) {
/*           CALL VGDRW(XMAX0,Y1AXIS,1,1,7,AXCOL,0.35,LENY1,1) */
	    vgdrw_(&xmax0, y1axis, &c__1, &c__1, &c__7, axcol, &
		    vgtick_1.tiky2[vgcntr_1.ig - 1], &leny1, &c__1);
	} else if (*ivcode == 3) {
/*           CALL VGDRW(XMAX0,Y2AXIS,1,1,7,AXCOL,0.35,LENY2,2) */
	    vgdrw_(&xmax0, y2axis, &c__1, &c__1, &c__7, axcol, &
		    vgtick_1.tiky2[vgcntr_1.ig - 1], &leny2, &c__2);
	}
    }
/* PLOT FIDUCIAL POINTS, IF DESIRED */
    if (*ifid == 1) {
	i__1 = leny1;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    vgdrw_(&y1axis[i__ - 1], xaxis, &c__0, &c__0, &c__7, axcol, &
		    c_b26, &lenx, &c__1);
/* L10: */
	}
    }
/* PLOT AXES, IF DESIRED */
/*          ADDED BLOCK BELOW 15 sEPT 1988 (DKK) */
    if (*iz == 1) {
	if ((real)r_sign(&c_b28, &xmin0) != (real)r_sign(&c_b28, &xmax0)) {
	    vgdrw_(&c_b30, y1axis, &c__1, &c__1, &c__7, axcol, &c_b34, &leny1,
		     &c__1);
	}
	if ((real)r_sign(&c_b28, &y1min0) != (real)r_sign(&c_b28, &y1max0)) {
	    vgdrw_(&c_b30, xaxis, &c__0, &c__1, &c__7, axcol, &c_b34, &lenx, &
		    c__1);
	}
    } else if (*iz == 2 && (real)r_sign(&c_b28, &xmin0) != (real)r_sign(&
	    c_b28, &xmax0) && (real)r_sign(&c_b28, &y1min0) != (real)r_sign(&
	    c_b28, &y1max0)) {
	vgdrw_(&c_b30, xaxis, &c__0, &c__1, &c__7, axcol, &c_b34, &lenx, &
		c__1);
	vgdrw_(&c_b30, y1axis, &c__1, &c__1, &c__7, axcol, &c_b34, &leny1, &
		c__1);
    }
/*          ADDED BLOCK ABOVE 15 sEPT 1988 (DKK) */

/*          FLUSH PLOT: 5 FEB 1989 (DKK) */
    vgpl_(&c_b30, &c_b30, &c__3);
    return 0;
} /* vga2_ */

/* Subroutine */ int vgsr_(real *axis, integer *isc, real *amin, real *amax, 
	integer *minl, integer *maxl, real *bmin, real *bmax, integer *nticks,
	 real *amin0, real *amax0, integer *len)
{
    /* System generated locals */
    integer i__1, i__2;
    doublereal d__1;

    /* Builtin functions */
    double pow_dd(doublereal *, doublereal *), pow_ri(real *, integer *);

    /* Local variables */
    static real step, ten2i;
    static integer i__, j, maxdec, icount, inc;

/*  ORIGINAL NAME SETROW.  CREATES A VECTOR CONTAINING THE POSITION OF */
/*  EACH TICK MARK IN THE GRAPH'S COORDINATES. */
    /* Parameter adjustments */
    --axis;

    /* Function Body */
    if (*isc == 0) {
	step = (*amax - *amin) / *nticks;
	i__1 = *nticks + 1;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    axis[i__] = *amin + (i__ - 1) * step;
/* L10: */
	}
	*len = *nticks + 1;
	*amin0 = *amin;
	*amax0 = *amax;
	*amin0 = dmax(*amin0,*bmin);
	*amax0 = dmin(*amax0,*bmax);
    } else {
	icount = 0;
	i__1 = *maxl - 1;
	for (i__ = *minl; i__ <= i__1; ++i__) {
/*              (MAXL-MINL)+1 ARE POSSIBLE TICKS */
	    maxdec = *maxl - *minl;
	    d__1 = (doublereal) ((real) i__);
	    ten2i = (real)pow_dd(&c_b66, &d__1);
	    if (maxdec <= 11) {
		inc = 1;
	    } else if (maxdec <= 20) {
		inc = 2;
	    } else if (maxdec <= 33) {
		inc = 3;
	    } else {
		inc = 9;
	    }
	    i__2 = inc;
	    for (j = 1; i__2 < 0 ? j >= 9 : j <= 9; j += i__2) {
		++icount;
		axis[icount] = ten2i * (real) j;
/* L100: */
	    }
/* L20: */
	}
	axis[icount + 1] = ten2i * 10.f;
	*len = icount + 1;
	*amin0 = (real)pow_ri(&c_b68, minl);
	*amax0 = (real)pow_ri(&c_b68, maxl);
    }
    return 0;
} /* vgsr_ */

/* Subroutine */ int vgdrw_(real *point, real *vec, integer *ihvflg, integer *
	iline, integer *isymb, integer *icol, real *siz, integer *len, 
	integer *jside)
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    static integer icov, i__;
    static real x[100], y[100];
    extern /* Subroutine */ int vgadr_(real *, real *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, real *, real *, real *
	    , real *, integer *, real *);
    static real covlef, covbot, covrit, covtop;

/*  ORIGINAL NAME DRWROW.  DRAWS A ROW OF POINTS; USED WITH VGSR TO */
/*  DRAW TICK MARKS AND FIDICIAL POINTS. */
    /* Parameter adjustments */
    --vec;

    /* Function Body */
    if (*ihvflg == 0) {
	i__1 = *len;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    x[i__ - 1] = vec[i__];
	    y[i__ - 1] = *point;
/* L10: */
	}
    } else {
	i__1 = *len;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    x[i__ - 1] = *point;
	    y[i__ - 1] = vec[i__];
/* L20: */
	}
    }
    icov = 0;
    if (vgleg1_1.isleg[vgcntr_1.ig - 1] == 1 && vgleg1_1.legvis[vgcntr_1.ig - 
	    1] == 1) {
	covlef = vgleg1_1.xleg[vgcntr_1.ig - 1] - vgleg1_1.hh[vgcntr_1.ig - 1]
		 * .5f;
	covrit = vgleg1_1.xleg[vgcntr_1.ig - 1] + vgleg1_1.hh[vgcntr_1.ig - 1]
		 * .5f;
	covbot = vgleg1_1.yleg[vgcntr_1.ig - 1] - vgleg1_1.vv[vgcntr_1.ig - 1]
		 * .5f;
	covtop = vgleg1_1.yleg[vgcntr_1.ig - 1] + vgleg1_1.vv[vgcntr_1.ig - 1]
		 * .5f;
	icov = 1;
    }
    vgadr_(x, y, len, iline, icol, isymb, jside, &icov, &covlef, &covrit, &
	    covbot, &covtop, &c__1, siz);
    return 0;
} /* vgdrw_ */

/* Subroutine */ int vgarr_(real *btop, real *bbot, real *blef, real *brit, 
	integer *kg, integer *ng, real *btop1, real *bbot1, real *bleft1, 
	real *brit1, integer *iesc)
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    static integer imov, i__, kflag;
    extern /* Subroutine */ int sleep_(integer *), vgcor_(real *, real *, 
	    real *, real *);
    static integer kcurr;
    static char ch[1];
    static real am;
    extern logical agrafa_(integer *, integer *, integer *, integer *);
    static real dellef, oldlef[6];
    static integer idelay;
    static real delbot, widlef[6];
    static integer iwhich[6], isides;
    static real oldbot[6], delrit;
    extern /* Subroutine */ int vgcorf_(integer *, real *, real *, integer *, 
	    integer *, real *, real *, real *, real *, real *, real *, real *,
	     real *);
    extern integer vgiaro_(integer *);
    static real widbot[6], deltop, oldrit[6];
    extern /* Subroutine */ int vgcmnt_(char *, ftnlen);
    static real oldtop[6], widrit[6], widtop[6];
    extern /* Subroutine */ int vgfxtx_(real *, real *, real *, real *, real *
	    , real *, real *, real *, integer *);
    static real wid;

/*          ORIGINAL NAME ARRANG */
/*  FOR REARRANGING GRAPHS FROM THE KEYBOARD. */
    /* Parameter adjustments */
    --brit1;
    --bleft1;
    --bbot1;
    --btop1;
    --brit;
    --blef;
    --bbot;
    --btop;

    /* Function Body */
    wid = 6.f;
    am = vgscrn_1.sht * .05f;
    isides = 0;
    idelay = 1;
    vgcmnt_("Arrange Mode", 12L);
/*  SAVE TEXT FRAME WIDTH AND INNER FRAME */
    i__1 = *ng;
    for (i__ = 1; i__ <= i__1; ++i__) {
	oldtop[i__ - 1] = btop1[i__];
	oldbot[i__ - 1] = bbot1[i__];
	oldlef[i__ - 1] = bleft1[i__];
	oldrit[i__ - 1] = brit1[i__];
	widtop[i__ - 1] = btop1[i__] - btop[i__];
	widbot[i__ - 1] = bbot1[i__] - bbot[i__];
	widlef[i__ - 1] = bleft1[i__] - blef[i__];
	widrit[i__ - 1] = brit1[i__] - brit[i__];
	iwhich[i__ - 1] = 0;
/* L10: */
    }
L20:
    vgcor_(&blef[*kg], &brit[*kg], &btop[*kg], &bbot[*kg]);
    if (idelay == 1) {
	sleep_(&c__2);
	vgcor_(&blef[*kg], &brit[*kg], &btop[*kg], &bbot[*kg]);
    }
L100:
    if (! agrafa_(&c__0, &c__1, &kcurr, &kflag)) {
	goto L100;
    }
    *(unsigned char *)ch = (char) kcurr;
    if (kcurr == 27) {
/*  EXIT, RESTORING OLD POSITIONS */
	vgcmnt_(" ", 1L);
	for (i__ = 1; i__ <= 6; ++i__) {
	    if (iwhich[i__ - 1] == 1) {
		vgcor_(&blef[i__], &brit[i__], &btop[i__], &bbot[i__]);
		btop[i__] = oldtop[i__ - 1] - widtop[i__ - 1];
		bbot[i__] = oldbot[i__ - 1] - widbot[i__ - 1];
		blef[i__] = oldlef[i__ - 1] - widlef[i__ - 1];
		brit[i__] = oldrit[i__ - 1] - widrit[i__ - 1];
	    }
/* L110: */
	}
	*iesc = 1;
	return 0;
    }
    if (*(unsigned char *)ch == 'D' || *(unsigned char *)ch == 'd') {
/*  EXIT, UPDATING AND REDRAWING GRAPHS */
	imov = 0;
	for (i__ = 1; i__ <= 6; ++i__) {
	    if (iwhich[i__ - 1] == 1) {
		imov = 1;
	    }
/* L120: */
	}
	if (imov == 0) {
	    *iesc = 1;
	} else {
	    *iesc = 0;
	}
/*  RESTORE TEXT FRAME WIDTH AND ADJUST TEXT */
	i__1 = *ng;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    btop1[i__] = widtop[i__ - 1] + btop[i__];
	    bbot1[i__] = widbot[i__ - 1] + bbot[i__];
	    bleft1[i__] = widlef[i__ - 1] + blef[i__];
	    brit1[i__] = widrit[i__ - 1] + brit[i__];
	    deltop = btop1[i__] - oldtop[i__ - 1];
	    delbot = bbot1[i__] - oldbot[i__ - 1];
	    dellef = bleft1[i__] - oldlef[i__ - 1];
	    delrit = brit1[i__] - oldrit[i__ - 1];
	    if (delbot != 0.f || deltop != 0.f || dellef != 0.f || delrit != 
		    0.f) {
/*  AT LEAST ONE SIDE OF THE GRAPH HAS BEEN MOVED; NEED TO ADJ
UST TEXT */
		vgfxtx_(&oldtop[i__ - 1], &oldbot[i__ - 1], &oldlef[i__ - 1], 
			&oldrit[i__ - 1], &btop1[i__], &bbot1[i__], &bleft1[
			i__], &brit1[i__], &i__);
	    }
/* L130: */
	}
	vgcmnt_(" ", 1L);
	return 0;
    }
    if (*(unsigned char *)ch == 'U' || *(unsigned char *)ch == 'u') {
	am = vgscrn_1.sht * .001f;
	goto L100;
    } else if (*(unsigned char *)ch == 'F' || *(unsigned char *)ch == 'f') {
	am = vgscrn_1.sht * .005f;
	goto L100;
    } else if (*(unsigned char *)ch == 'C' || *(unsigned char *)ch == 'c') {
	am = vgscrn_1.sht * .05f;
	goto L100;
    } else if (*(unsigned char *)ch == 'S' || *(unsigned char *)ch == 's') {
	isides = 1;
	goto L100;
    } else if (*(unsigned char *)ch == 'W' || *(unsigned char *)ch == 'w') {
	isides = 0;
	goto L100;
    }
    if (kcurr == 32 && *ng > 1) {
	++(*kg);
	if (*kg > *ng) {
	    *kg = 1;
	}
	idelay = 1;
	goto L20;
    }
    if (kcurr == 8 && *ng > 1) {
	--(*kg);
	if (*kg == 0) {
	    *kg = *ng;
	}
	idelay = 1;
	goto L20;
    }
    if (vgiaro_(&kcurr) == 0) {
	goto L100;
    }
    if (iwhich[*kg - 1] == 0) {
	iwhich[*kg - 1] = 1;
    } else {
	vgcor_(&blef[*kg], &brit[*kg], &btop[*kg], &bbot[*kg]);
    }
    vgcorf_(&isides, &am, &wid, &kcurr, &kflag, &c_b30, &vgscrn_1.swd, &c_b30,
	     &vgscrn_1.sht, &blef[*kg], &brit[*kg], &bbot[*kg], &btop[*kg]);
    idelay = 0;
    goto L20;
} /* vgarr_ */

