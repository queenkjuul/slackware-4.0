/**********************************************************
	  AGRAF_X11.C  - Plotting service routines for AGRAF		     							
	  This file contains the following C functions: 	 	     
	    agraf0   - Sets screen mode to graphics or text.	   
	    agraf4   - Print screen (nonoperable)		
	    agraff   - Draw lines and text on X11 display.
            agrafg   - Set screen dimensions
            agrafi   - Erase screen
									     
*********************************************/

/********************************************
 #define							
*********************************************/
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/termio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

#include "agraf.h"

#include "vg_icon"

#define HEIGHT 600
#define WIDTH 600
#define BORDER 2
#define MAXLINE 80
#define MAX_POINTS 1000
#define TRUE 1
/*******************************************************
* global data (common to several functions, or large vectors for which we    *
*	       would rather reserve data space than stack space).	     *
********************************************************/
    Display *display;
    GC gc;
    Window window, root;
    XEvent event;
    XSizeHints size;
    XWMHints wm_hints;
    XGCValues gc_val;
    XClassHint xch;
    XSetWindowAttributes  window_attributes;
    XWindowAttributes  attributes;
    int colors[16];
    int colorflag,graf_flag,text_flag;
    int screen;
    int repeat_char,row,col,row_length,column_length;
    static int argc = 0;
    static char *argv[]={(char *)NULL};
    char x11_display[MAXLINE];
    unsigned long foregnd, backgnd, value_mask,gc_mask;
    unsigned int scr_depth,width,height;
    XFontStruct *font_info;
/***************************************************************
agraf0(imode) - Set display to graphics or text mode. 		     
****************************************************************/

void
agraf0_(ier,imode)
integer *ier,*imode;
{
	static int ret_flag=0;
        Pixmap icon_pixmap;
	void load_colors(void);
	void load_font(void);
	void get_GC(void);
	
	
	*ier=0;
        if(ret_flag == -1)
        {
            *ier = -1;
            return;
        }
  	if (*imode == 0 || *imode == 1)	/* Valid mode	    */
        {
             if (*imode == 0 )  
              		 /* Set screen to graphics or text  */
             	if(graf_flag==1)
                 {
                	XClearWindow(display,window);
                 }
              	else
                {
                        size.flags = PMinSize | PMaxSize | PPosition | PSize;
                        size.x = 0;
                        size.y = 0;
                        size.max_width = 1000;
                        size.min_height = 200;
                        size.width = WIDTH;
                        size.max_height = 1000;
                        size.min_height = 200;
                        size.height= HEIGHT;
                        strcpy(x11_display,"");
                        if ((display = XOpenDisplay(x11_display)) == NULL)
                        {
                           fprintf(stderr,"VG: cannot connect to X server \
                            %s\n", XDisplayName(x11_display));
                           ret_flag = -1;
                           exit(-1) ;
                        }
                        screen = DefaultScreen(display) ;
                        root = RootWindow(display, screen) ;
                        foregnd = WhitePixel(display, screen) ;
                        backgnd = BlackPixel(display, screen) ;
                        scr_depth = DefaultDepth(display, screen) ;
                        window = XCreateSimpleWindow(display,root,
                                  size.x,size.y,size.width,size.height,
                                  BORDER,foregnd,backgnd);
                        window_attributes.bit_gravity = NorthWestGravity;
                        value_mask = CWBitGravity;
                        XChangeWindowAttributes(display, window, value_mask,
                             &window_attributes);
                        if ((icon_pixmap = XCreateBitmapFromData(display,window,
                             vg_icon_bits,vg_icon_width,vg_icon_height))==0)
                        {
                            fprintf(stderr,"icon_pixmap not created\n");
                        }
                        wm_hints.icon_x = 0;
                        wm_hints.icon_y = 0;
                        wm_hints.icon_pixmap = icon_pixmap;
                        wm_hints.input = True;
                        wm_hints.initial_state = NormalState;
                        wm_hints.flags = InputHint | StateHint | IconPixmapHint; 
                        XSetStandardProperties(display,window,"VG",NULL,
                             icon_pixmap, argv, argc, &size);
                        XSetWMHints(display, window, &wm_hints);
                        XSetClassHint(display, window, &xch);
                        load_colors();
                        load_font();
                        XSelectInput(display, window, StructureNotifyMask |                                  ExposureMask );
                        XMapWindow(display,window);
                        XGetWindowAttributes(display,window,&attributes);
                        width=attributes.width;
                        height=attributes.height;
                        do
                        {
                            XNextEvent(display, &event);
                        }
                        while (event.type != MapNotify || event.xmap.window 
                          != window);
                        while(XCheckTypedWindowEvent(display,window,Expose,
                             &event));
                        XFlush(display);
                        get_GC();
			graf_flag=1;
     		 }
             else  
             {
               	 if (graf_flag ==1)
               	 {	
            XClearWindow(display,window);
            /*  	        XFreeGC(display,gc);
             		XDestroyWindow(display,window);
             		XCloseDisplay(display); */
                 }
             }
       }
	else
	  {                         /* Invalid mode     */
	    *ier = 17;
	    return;
	  }
	*ier = 0;
	return;			/* Pass back return code*/
}

void
load_font()
{
    char *fontname = "8x13";

    if((font_info=XLoadQueryFont(display,fontname))==NULL)
    {
        fprintf(stderr, "VG: Cannont open 9x15 font\n");
        exit(-1);
    }
}

void
get_GC()
{

      gc_mask = GCForeground | GCBackground;
      gc_val.foreground = foregnd;
      gc_val.background = backgnd;
      gc = XCreateGC(display,root,gc_mask,&gc_val);
      XSetFont(display,gc,font_info->fid);
      XSetLineAttributes(display,gc,0,LineSolid,CapButt,JoinMiter);
}

void
load_colors()
{
        int i, numcolors;
        static char *name[]={"white","SkyBlue","green","cyan","red","magenta","tan","white","gray","blue","LimeGreen","turquoise","pink","orchid","yellow","white"};
        XColor exact_def;
/*
	if (DisplayCells(display, screen) > 2)
        {
            numcolors = 0 ;
            colors[0].red = 0;
            colors[0].green = 0;
            colors[0].blue = 0;
            colors[1].red = 65535;
            colors[1].green = 65535;
            colors[1].blue = 65535;
            colors[2].red = 1542;
            colors[2].green = 48316;
            colors[2].blue = 65535;
            colors[3].red = 1542;
            colors[3].green = 56283;
            colors[3].blue = 1542;
            colors[4].red = 3825;
            colors[4].green = 49470;
            colors[4].blue = 48960;
            colors[5].red = 65535;
            colors[5].green = 28784;
            colors[5].blue = 28784;
            colors[6].red = 51914;
            colors[6].green = 32629;
            colors[6].blue = 51914;
            colors[7].red = 45232;
            colors[7].green = 38293;
            colors[7].blue = 39835;
            colors[8].red = 65535;
            colors[8].green = 65535;
            colors[8].blue = 65535;
            colors[9].red = 52942;
            colors[9].green = 52942;
            colors[9].blue = 52942;
            colors[10].red = 27242;
            colors[10].green = 240;
            colors[10].blue = 65535;
            colors[11].red = 11822;
            colors[11].green = 65535;
            colors[11].blue = 13364;
            colors[12].red = 3855;
            colors[12].green = 63993;
            colors[12].blue = 63479;
            colors[13].red = 65535;
            colors[13].green = 43690;
            colors[13].blue = 47545;
            colors[14].red = 65535;
            colors[14].green = 32639;
            colors[14].blue = 65535;
            colors[15].red = 65021;
            colors[15].green = 63479;
            colors[15].blue = 34438; */
	if (DisplayCells(display, screen) > 2)
        {
            numcolors=0;
            for (i = 0; i < 16; i++)
            {
               if(!XParseColor(display,DefaultColormap(display,screen),
                                 name[i],&exact_def))
               {
                    fprintf(stderr,"VG: cannot allocate color %s\n",name[i]);
                    XParseColor(display,DefaultColormap(display,screen),
                                 name[i],&exact_def);
               }
               
                if (XAllocColor(display, DefaultColormap(display, screen),
                     &exact_def) == True)
                     numcolors++;
                else
                     fprintf(stderr,"all color cells allocated\n"); 
                colors[i]=exact_def.pixel;
             }   

            /*{
                if (XAllocColor(display, DefaultColormap(display, screen),
                     &colors[i]) == True)
                     numcolors++;
            }*/
            if (numcolors < 2)
            {
                 fprintf(stderr, "VG: cannot allocate colors.\n");
                 colorflag=1;
                 exit(1) ;
            }
       }
       else
           colorflag=1;
}

/**********************************************
 agraf4() - Print the graphics screen. 				     
***********************************************/
short agraf4_(ier)
integer *ier;
{
     return 0;
} 
/*********************************************
agraff(iretcd,iptype,n,ix,iy) 
**********************************************/
void
agraff_(iretcd,iptype,n,ix,iy)
integer *iretcd,*iptype,*n,*ix,*iy;
{
     int i, char_type, color, bit_op, line_typ, number,string_width, xstrg;
     /*     char c,string[2]; */
     char string[2];
     extern int colorflag;
     unsigned long gc_mask;
     XPoint points[MAX_POINTS];
     
     if (graf_flag == 1)
     {
        text_flag=0;
        char_type = *iptype/256;
        color = (*iptype - (256*char_type))/16;
        bit_op = (*iptype - (256*char_type)-(16*color))/8;
        line_typ = (*iptype - (256*char_type)-(16*color) -(8*bit_op));
        line_typ %= 6;
        color %= 15;
        if (bit_op == 0)
            XSetFunction(display,gc,GXcopy);
        if (bit_op == 1)
            XSetFunction(display,gc,GXxor);
        if (colorflag ==0)
        {
            if(bit_op == 1 )
               XSetForeground(display,gc,colors[color]^backgnd); 
            else
               XSetForeground(display,gc,colors[color]);
            gc_mask = GCLineWidth;
            gc_val.line_width=0;
            XChangeGC(display,gc,gc_mask,&gc_val);
        }
        else
        {
            if(bit_op == 1 )
               XSetForeground(display,gc,foregnd^backgnd); 
            else
               XSetForeground(display,gc,foregnd); 
	    gc_val.line_width = color;
	    gc_val.line_width %= 8;
            gc_mask = GCLineWidth;
            XChangeGC(display,gc,gc_mask,&gc_val);
         }
         for(i=0;i< *n;i++)
         {
            points[i].x = ix[i];
            points[i].y = iy[i];
         }        
         if(*n > 1 && line_typ> 0)
            XDrawLines(display,window,gc,points,*n,CoordModeOrigin);
         else if(char_type==0)
         {
             XDrawPoint(display,window,gc,ix[0],iy[0]);
             fprintf(stderr,"Support to plot dots not yet added\n");
         }
         else if (char_type==191||
		  char_type==192||
		  char_type==217||
		  (char_type== 218 && line_typ==0))
         {
             /*if(colorflag==1 && bit_op ==1)
                 XSetForeground(display,gc,backgnd);*/ 
	     number = 3;
	     points[1].x = ix[0];
	     points[1].y = iy[0];
             if (char_type == 191)
	     {
	         points[0].x = ix[0] - .02*width;
	         points[0].y = points[1].y;
	         points[2].x = ix[0];
	         points[2].y = points[1].y + .02*height;
	     }
	     if (char_type == 192)
	     {
	         points[0].x = ix[0];
	         points[0].y = points[1].y - .02*height;
	         points[2].x = ix[0] + 0.02*width;
	         points[2].y = points[1].y;
	     }
	     if (char_type == 217)
	     {
	         points[0].x = ix[0] - .02*width;
	         points[0].y = points[1].y;
	         points[2].x = ix[0];
	         points[2].y = points[1].y - 0.02*height;
	     }
	     if (char_type == 218)
	     {
	         points[0].x = ix[0];
	         points[0].y = points[1].y + .02*height;
	         points[2].x = ix[0] + .02*width;
	         points[2].y = points[1].y;
	     }
             XDrawLines(display,window,gc,points,number,CoordModeOrigin);
          }
          else
          {
/*             if(colorflag==1 && bit_op ==1)
                 XSetForeground(display,gc,backgnd);  */
             string[0]=char_type;
             string[1]='\0';
             string_width = XTextWidth(font_info, string, 1);
             xstrg=ix[0]-string_width;
             xstrg*=1.15;
             XDrawString(display,window,gc,xstrg,iy[0],string,1);
          }
     }
     return;
} 
/*********************************************
agrafg(iretcd,idmode,igcol,igrow,itcol,itrow,idpage,idmaxp)
*********************************************/
void
agrafg_(iretcd,idmode,igcol,igrow,itcol,itrow,idpage,idmaxp)
integer *iretcd,*idmode,*igcol,*igrow,*itcol,*itrow,*idpage,*idmaxp;
{
        extern int graf_flag;

	*idmode=1-graf_flag;
        *itcol = 80;
        *itrow = 20;
        *idpage = 1;
        *idmaxp = 1;
        if (graf_flag == 1)
        {
           XGetWindowAttributes(display,window,&attributes);
           width=attributes.width;
           height=attributes.height;
           *igcol=.94*width;
           *igrow=.94*height;
        }
        else
        {
           *igcol = 80;
           *igrow = 20;
        }
}
/**************************************************
agrafi(iretcd,istore,768,ix1,iy1,iw,ih,array)
***************************************************/ 
int
agrafi_(iretcd,istore,iwtype,ix1,iy1,iw,ih,array)
integer *iretcd,*istore,*iwtype,*ix1,*iy1,*iw,*ih;
char *array;
{

     if(graf_flag == 1)
     {
        if(*iwtype==768)
        {
            XClearWindow(display,window);
        }
     }
     return(0);
}
/* ieee_retrospective_()
{
	char *out;
	int k, ieee_flags();

	k = ieee_flags("get","exception","overflow",&out);
        if(k & 1)
		fprintf(stderr,"Warning: a floating point inexact exception has occurred\n");
        if(k & 2)
		fprintf(stderr,"Warning: a floating point division exception has occurred\n");
        if(k & 4)
		fprintf(stderr,"Warning: a floating point underflow exception has occurred\n");
        if(k & 8)
		fprintf(stderr,"Warning: a floating point overflow exception has occurred\n");
        if(k & 16)
		fprintf(stderr,"Warning: a floating point invalid exception has occurred\n");
	ieee_flags("clearall","exception","all",&out);
} */
/* The keyboard characteristics must be modified for VG.  The
   termio facilities are used for this. */

/******************************************************
 agrafa(iktype,keep,kcurr,kflag) - Get keyboard status.		     
*******************************************************/
logical
agrafa_(iktype,keep,kcurr,kflag)
integer *iktype,*keep,*kcurr,*kflag;
{
  /*        struct termio buf; */
        char c,text[1];
        KeySym key;
        XEvent event;
        static char keepchar=0;
        int /* d,count, */i,done;
        /* static int first_time=1; */
	/*	unsigned char buf_min,buf_time; */
        
         
        if(text_flag==0)
        {
            text_flag=1;
            XFlush(display);
        }

/* The following code just keeps track of whether the key should
   be kept or thrown away  --- it is presumably very portable */

        *kflag=0;
        if (keepchar)       /* if previous call did not dispose */
        {                   /* of character */
                *kcurr=c=keepchar;
                if (*kcurr < 33)
                        *kflag = 4;
                else if (*kcurr >64 && *kcurr < 91)
                        *kflag = 1;
                if(*keep==1)
                        keepchar=0;
                else if (*keep ==2)
                  {
                        if(*iktype==0)
                             keepchar=0;
                        else if(*iktype==c)
                             keepchar=0;
                  }
                else if (*keep ==3 && *iktype!=c)
                        keepchar=0;
                if(*iktype==0)
                        return(TRUE);
                else                     
                        return(c==*iktype);
       }
        c=0;

/* Get the pointer to the termio structure */
/*        ioctl(0,TCGETA,&buf); */
/* Change the flag to turn off canonical mode processing;
   that is, input characters are not assembled into lines. 
   In this non-canonical mode erase and kill processing
   does not occur. */
/*        buf.c_lflag ^= (ICANON); */ 
/* Change the flag to turn off keyboard echoing */
/*        buf.c_lflag ^= (ECHO);   */
/* Change the non-canonical mode so that the intracharacter
   timing plays no role */
/*  	buf_time = buf.c_cc[VTIME];
	buf.c_cc[VTIME]=0;*/
/* Change the non-canonical mode so that the read will be 
   satisfied after one character is entered */
/*  	buf_min = buf.c_cc[VMIN]; 
	buf.c_cc[VMIN]=1;*/
/* Set the new modes */
/*        ioctl(0,TCSETA,&buf);
        if(fcntl(0,F_SETFL,O_RDONLY)==-1)
        {
                fprintf(stderr,"unable to set non-blocking read\n");
                return(-1);
        }
        d = read(0,&c,1);*/
/* Return the termio structure to its previous state */
/*        buf.c_lflag |= (ICANON); 
        buf.c_lflag |= (ECHO);
  	buf.c_cc[VTIME] = buf_time;
	buf.c_cc[VMIN] = buf_min;*/
/* Set the restored modes */
/*        ioctl(0,TCSETA,&buf); */

        XSelectInput(display,window,KeyPressMask | ExposureMask );
        done=0;
        while (done ==0)
        {
           XNextEvent(display,&event);
           switch (event.type)
           {
           case KeyPress:
              i=XLookupString(&event.xkey,text,1,&key,(XComposeStatus *) NULL);
              if(IsModifierKey(key)||IsPFKey(key)||IsFunctionKey(key))
                break;
              c=text[0];
              done=1;
              break;
           case Expose:
              c='x';
              done=1;
              break;
           }
        }
        *kcurr=c;
        if (*kcurr < 33)
               *kflag = 4;
        else if (*kcurr >64 && *kcurr < 91)
               *kflag = 1;
        if(*keep==0)
               keepchar=c;
        else if (*keep ==2)
               if(*iktype!=0 && *iktype != c)
                   keepchar=c;
        else if (*keep ==3 && *iktype==c)
               keepchar=c;
        if(*iktype==0)
               return(TRUE);
        else                     
               return(c==*iktype);
}
