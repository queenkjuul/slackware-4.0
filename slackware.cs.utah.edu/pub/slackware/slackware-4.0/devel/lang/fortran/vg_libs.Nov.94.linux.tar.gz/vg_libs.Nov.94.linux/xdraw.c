/* xdraw.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"
#include "agraf.h"

/* Common Block Declarations */

struct {
    char commnt[80];
} vgusrc_;

#define vgusrc_1 vgusrc_

struct {
    real sht, swd;
    integer ncols, nrows;
} vgscrn_;

#define vgscrn_1 vgscrn_

struct {
    integer iwid, ihgt;
} vgtxt_;

#define vgtxt_1 vgtxt_

struct {
    logical baton;
} vgbt_;

#define vgbt_1 vgbt_

/* Table of constant values */

static integer c__0 = 0;
static integer c__1 = 1;
static integer c__2 = 2;
static integer c__10760 = 10760;
static integer c__49160 = 49160;
static integer c__55816 = 55816;
static integer c__48904 = 48904;
static integer c__55560 = 55560;

/* Subroutine */ int vgucom_(void)
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    extern /* Subroutine */ int vgxstr_(char *, integer *, integer *, ftnlen);

/*  DRAWS A USER COMMENT LINE AT THE BOTTOM OF THE SCREEN */
    i__1 = vgscrn_1.nrows / vgtxt_1.ihgt - 1;
    vgxstr_(vgusrc_1.commnt, &c__0, &i__1, 80L);
    return 0;
} /* vgucom_ */

/* Subroutine */ int vgcmnt_(char *commnt, ftnlen commnt_len)
{
    /* Initialized data */

    static char currnt[80] = "                                              "
	    "                                  ";

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    extern /* Subroutine */ int vgxstr_(char *, integer *, integer *, ftnlen);

/*  DRAWS TEXT IN THE UPPER LEFT CORNER OF THE SCREEN */
    vgxstr_(currnt, &c__0, &c__0, 80L);
    s_copy(currnt, commnt, 80L, commnt_len);
    vgxstr_(currnt, &c__0, &c__0, 80L);
    return 0;
} /* vgcmnt_ */

/* Subroutine */ int vgxstr_(char *strng, integer *ix, integer *iy, ftnlen 
	strng_len)
{
    /* System generated locals */
    integer i__1, i__2, i__3, i__4;

    /* Local variables */
    static integer i__, ie;
    extern integer vgistr_(char *, ftnlen);
    static integer len;

/*  DRAWS TEXT IN XOR MODE AT IX-TH ROW, IY-TH COLUMN OF SCREEN */
    len = vgistr_(strng, strng_len);
    if (! vgbt_1.baton) {
	i__1 = len;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    i__2 = (*(unsigned char *)&strng[i__ - 1] << 8) + 8;
	    i__3 = vgtxt_1.iwid * (i__ + *ix);
	    i__4 = vgtxt_1.ihgt * *iy + vgtxt_1.ihgt / 2;
	    agraff_(&ie, &i__2, &c__1, &i__3, &i__4);
/* L10: */
	}
    }
    return 0;
} /* vgxstr_ */

/* Subroutine */ int vggl_(integer *len0, char *prompt, char *instrg, integer 
	*mxstg, ftnlen prompt_len, ftnlen instrg_len)
{
    /* System generated locals */
    address a__1[2];
    integer i__1, i__2, i__3, i__4[2];

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen), s_cat(char *,
	     char **, integer *, integer *, ftnlen);

    /* Local variables */
    static integer ichr;
    static char temp[80];
    static integer kc, ie;
    static integer kf;
    static char ch2[1];
    extern /* Subroutine */ int vgcmnt_(char *, ftnlen);
    extern integer vgistr_(char *, ftnlen);
    extern /* Subroutine */ int vgxstr_(char *, integer *, integer *, ftnlen);
    static integer len;

/*          ORIGINAL NAME GETLIN */
/*          WRITES PROMPT ON SCREEN AND THEN READS USER'S INPUT INTO */
/*          INSTRG OF MAXIMUM INPUT LENGTH MXSTG. RETURNS LENGTH OF */
/*          USER'S INPUT. */
/*           WRITE PROMPT (ASSUMED NONEMPTY) ONTO SCREEN */
    vgcmnt_(prompt, 12L);
    len = vgistr_(prompt, 12L);
    ichr = 0;
/*           LOOK FOR KEYSTROKE */
L206:
    if (! agrafa_(&c__0, &c__1, &kc, &kf)) {
	goto L206;
    }
    *(unsigned char *)ch2 = (char) kc;
/*           CARRIAGE RETURN MEANS THAT'S ALL */
    if (kc == 13 || kc == 10) {
	goto L207;
    }
/*           BACKSPACE, ERASE LAST CHARACTER IF THERE WAS ONE */
    if (kc == 8) {
	if (ichr >= 1) {
	    i__1 = (*(unsigned char *)&instrg[ichr - 1] << 8) + 8;
	    i__2 = vgtxt_1.iwid * (len + ichr);
	    i__3 = vgtxt_1.ihgt / 2;
	    agraff_(&ie, &i__1, &c__1, &i__2, &i__3);
	    --ichr;
	}
	goto L206;
    }
    if (ichr == *mxstg) {
	goto L206;
    }
    ++ichr;
/*          WRITE NEW CHARACTER ONTO SCREEN */
    i__1 = (kc << 8) + 8;
    i__2 = vgtxt_1.iwid * (len + ichr);
    i__3 = vgtxt_1.ihgt / 2;
    agraff_(&ie, &i__1, &c__1, &i__2, &i__3);
/*          CONCATENATE NEW CHARACTER TO RETURNED STRING AND GET ANOTHER 
*/
    if (ichr == 1) {
	s_copy(instrg, ch2, instrg_len, 1L);
    } else {
	s_copy(temp, instrg, 80L, instrg_len);
/* Writing concatenation */
	i__4[0] = ichr - 1, a__1[0] = temp;
	i__4[1] = 1, a__1[1] = ch2;
	s_cat(instrg, a__1, i__4, &c__2, instrg_len);
    }
    goto L206;
L207:
/*          ERASE STRING FROM SCREEN AND RETURN */
    vgcmnt_(" ", 1L);
    if (ichr == 0) {
	s_copy(instrg, " ", instrg_len, 1L);
    } else {
	s_copy(temp, " ", 80L, 1L);
	s_copy(temp, instrg, 80L, ichr);
	s_copy(instrg, " ", instrg_len, 1L);
	s_copy(instrg, temp, ichr, 80L);
	vgxstr_(instrg, &len, &c__0, instrg_len);
    }
    *len0 = ichr;
    return 0;
} /* vggl_ */

/* Subroutine */ int vgxcur_(real *x, real *y)
{
    static integer ix, iy, iretcd;

/*  DRAWS A STAR (USED AS A GRAPHICS CURSOR) */
    ix = (integer) (*x / vgscrn_1.swd * (vgscrn_1.ncols - 1.f) + .5f);
    iy = (integer) ((1.f - *y / vgscrn_1.sht) * (vgscrn_1.nrows - 1.f) + .5f);
    agraff_(&iretcd, &c__10760, &c__1, &ix, &iy);
    return 0;
} /* vgxcur_ */

/* Subroutine */ int vgms_(real *aleft, real *arit, real *abot, real *atop)
{
    static real x, y;
    static integer ix, iy, iretcd;
    extern void sleep_(integer *);


/*         ORIGINAL NAME MSTAR */
/*  CAUSES A STAR TO FLASH ONCE AT THE SPECIFIED LOCATION. */
    x = (*aleft + *arit) * .5f;
    y = (*abot + *atop) * .5f;
    ix = (integer) (x / vgscrn_1.swd * (vgscrn_1.ncols - 1.f) + .5f);
    iy = (integer) ((1.f - y / vgscrn_1.sht) * (vgscrn_1.nrows - 1.f) + .5f);
    agraff_(&iretcd, &c__10760, &c__1, &ix, &iy);
    sleep_(&c__1);
    agraff_(&iretcd, &c__10760, &c__1, &ix, &iy);
    return 0;
} /* vgms_ */

/* Subroutine */ int vgcor_(real *al, real *ar, real *at, real *ab)
{
    static integer ibot, irit, itop, ileft;
    static integer iretcd;

/*          ORIGINAL NAME CORNER */
/*  DRAWS EXCLUSIVE-OR CORNERS. */
    ileft = (integer) (*al / vgscrn_1.swd * (vgscrn_1.ncols - 1.f) + .5f);
    irit = (integer) (*ar / vgscrn_1.swd * (vgscrn_1.ncols - 1.f) + .5f);
    itop = (integer) ((1.f - *at / vgscrn_1.sht) * (vgscrn_1.nrows - 1.f) + 
	    .5f);
    ibot = (integer) ((1.f - *ab / vgscrn_1.sht) * (vgscrn_1.nrows - 1.f) + 
	    .5f);
    agraff_(&iretcd, &c__49160, &c__1, &ileft, &ibot);
    agraff_(&iretcd, &c__55816, &c__1, &ileft, &itop);
    agraff_(&iretcd, &c__48904, &c__1, &irit, &itop);
    agraff_(&iretcd, &c__55560, &c__1, &irit, &ibot);
    return 0;
} /* vgcor_ */

/* Subroutine */ int vgcorf_(integer *isides, real *am, real *wid, integer *
	kcurr, integer *kflag, real *aleft, real *arit, real *abot, real *
	atop, real *zleft, real *zrit, real *zbot, real *ztop)
{
    extern /* Subroutine */ int vgcord_(integer *, real *, real *, real *, 
	    real *, real *, integer *);
    static integer ishift;
    extern /* Subroutine */ int vgcori_(integer *, real *, real *, real *, 
	    real *, real *, integer *);

/*         ORIGINAL NAME CORDIF */
/*  COMPUTES CORNER MOVEMENT ORDERED FROM KEYBOARD. */
    if (*kflag % 4 == 0) {
	ishift = 0;
    } else {
	ishift = 1;
    }
    if (*kcurr == 18432 || *kcurr == 56 || *kcurr == 73 || *kcurr == 105) {
	vgcori_(isides, am, wid, atop, zbot, ztop, &ishift);
    } else if (*kcurr == 20480 || *kcurr == 50 || *kcurr == 77 || *kcurr == 
	    109) {
	vgcord_(isides, am, wid, abot, zbot, ztop, &ishift);
    } else if (*kcurr == 19712 || *kcurr == 54 || *kcurr == 75 || *kcurr == 
	    107) {
	vgcori_(isides, am, wid, arit, zleft, zrit, &ishift);
    } else if (*kcurr == 19200 || *kcurr == 52 || *kcurr == 74 || *kcurr == 
	    106) {
	vgcord_(isides, am, wid, aleft, zleft, zrit, &ishift);
    }
    return 0;
} /* vgcorf_ */

/* Subroutine */ int vgcori_(integer *isides, real *am, real *wid, real *
	ahigh, real *zlow, real *zhigh, integer *ishift)
{
    /* System generated locals */
    real r__1;

/*         ORIGINAL NAME CORINC */
/*  A CORNER MOVEMENT ROUTINE CALLED BY VGCORF. */
    if (*isides == 0) {
	if (*zhigh + *am < *ahigh) {
	    *zhigh += *am;
	    *zlow += *am;
	} else {
	    *zlow = *zlow + *ahigh - *zhigh;
	    *zhigh = *ahigh;
	}
    } else {
	if (*ishift == 0) {
/* Computing MIN */
	    r__1 = *zhigh + *am;
	    *zhigh = dmin(r__1,*ahigh);
	} else if (*zhigh - *am > *zlow + *wid) {
	    *zhigh -= *am;
	}
    }
    return 0;
} /* vgcori_ */

/* Subroutine */ int vgcord_(integer *isides, real *am, real *wid, real *alow,
	 real *zlow, real *zhigh, integer *ishift)
{
    /* System generated locals */
    real r__1;

/*            ORIGINAL NAME CORDEC */
/*  A CORNER MOVEMENT ROUTINE CALLED BY VGCORF. */
    if (*isides == 0) {
	if (*zlow - *am > *alow) {
	    *zlow -= *am;
	    *zhigh -= *am;
	} else {
	    *zhigh = *zhigh - *zlow + *alow;
	    *zlow = *alow;
	}
    } else {
	if (*ishift == 0) {
/* Computing MAX */
	    r__1 = *zlow - *am;
	    *zlow = dmax(r__1,*alow);
	} else if (*zlow + *am < *zhigh - *wid) {
	    *zlow += *am;
	}
    }
    return 0;
} /* vgcord_ */

