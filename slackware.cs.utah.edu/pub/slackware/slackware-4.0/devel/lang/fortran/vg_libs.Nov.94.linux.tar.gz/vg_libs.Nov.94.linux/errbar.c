/* errbar.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    real bleft1[7], brit1[7], bbot1[7], btop1[7], bxmin[7], bxmax[7], bymin[
	    14]	/* was [7][2] */, bymax[14]	/* was [7][2] */;
    integer ninlx[7], naxlx[7], ninly[14]	/* was [7][2] */, naxly[14]	
	    /* was [7][2] */, msx[7], msy[14]	/* was [7][2] */;
} vglim_;

#define vglim_1 vglim_

struct {
    integer ig;
} vgcntr_;

#define vgcntr_1 vgcntr_

struct {
    integer idmark;
} vgcrv1_;

#define vgcrv1_1 vgcrv1_

/* Table of constant values */

static integer c__0 = 0;
static integer c__1 = 1;
static integer c__2 = 2;

/* Subroutine */ int errbar_(integer *n, real *x, real *y, real *xerr, real *
	yerr, integer *ix, integer *iy)
{
    /* System generated locals */
    integer i__1;
    real r__1, r__2;

    /* Local variables */
    extern /* Subroutine */ int curv_(integer *, real *, real *);
    static integer i__;
    static real deltx1, deltx2, delty1, delty2, ex[2], ey[2], deltax, deltay;
    extern /* Subroutine */ int howplt_(integer *, integer *, integer *);

/*  DRAWS A CURVE WITH ERROR BARS */
    /* Parameter adjustments */
    --yerr;
    --xerr;
    --y;
    --x;

    /* Function Body */
    curv_(n, &x[1], &y[1]);
/*     CALL HOWPLT(7,1,1) */
/*     CALL HOWPLT(0,1,1) */
    howplt_(&c__0, &c__1, &c__0);
    if (*ix == 1 || *iy == 1) {
	deltx1 = x[1];
	deltx2 = x[1];
	delty1 = y[1];
	delty2 = y[1];
	i__1 = *n;
	for (i__ = 1; i__ <= i__1; ++i__) {
/* Computing MAX */
	    r__1 = deltx2, r__2 = x[i__];
	    deltx2 = dmax(r__1,r__2);
/* Computing MIN */
	    r__1 = deltx1, r__2 = x[i__];
	    deltx1 = dmin(r__1,r__2);
/* Computing MAX */
	    r__1 = delty2, r__2 = y[i__];
	    delty2 = dmax(r__1,r__2);
/* Computing MIN */
	    r__1 = delty1, r__2 = y[i__];
	    delty1 = dmin(r__1,r__2);
/* L10: */
	}
	deltax = (deltx2 - deltx1) / 200.f;
	deltay = (delty2 - delty1) / 150.f;
    }
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (*ix > 0) {
	    ex[0] = x[i__] - xerr[i__];
	    ex[1] = x[i__] + xerr[i__];
	    ey[0] = y[i__];
	    ey[1] = y[i__];
	    curv_(&c__2, ex, ey);
	    vgcrv1_1.idmark = 1;
	    if (*ix != 2) {
		if (*ix == 1) {
		    ex[0] = x[i__] - xerr[i__];
		    ex[1] = x[i__] - xerr[i__];
		    ey[0] = y[i__] - deltay;
		    ey[1] = y[i__] + deltay;
		} else {
		    ex[0] = x[i__] - xerr[i__];
		    ex[1] = x[i__] - xerr[i__];
		    ey[0] = y[i__] - yerr[i__] / 3.f;
		    ey[1] = y[i__] + yerr[i__] / 3.f;
		}
		curv_(&c__2, ex, ey);
		vgcrv1_1.idmark = 1;
		if (*ix == 1) {
		    ex[0] = x[i__] + xerr[i__];
		    ex[1] = x[i__] + xerr[i__];
		    ey[0] = y[i__] - deltay;
		    ey[1] = y[i__] + deltay;
		} else {
		    ex[0] = x[i__] + xerr[i__];
		    ex[1] = x[i__] + xerr[i__];
		    ey[0] = y[i__] - yerr[i__] / 3.f;
		    ey[1] = y[i__] + yerr[i__] / 3.f;
		}
		curv_(&c__2, ex, ey);
		vgcrv1_1.idmark = 1;
	    }
	}
	if (*iy > 0) {
	    ex[0] = x[i__];
	    ex[1] = x[i__];
	    ey[0] = y[i__] - yerr[i__];
	    ey[1] = y[i__] + yerr[i__];
	    curv_(&c__2, ex, ey);
	    vgcrv1_1.idmark = 1;
	    if (*iy != 2) {
		if (*iy == 1) {
		    ex[0] = x[i__] - deltax;
		    ex[1] = x[i__] + deltax;
		    ey[0] = y[i__] - yerr[i__];
		    ey[1] = y[i__] - yerr[i__];
		} else {
		    ex[0] = x[i__] - xerr[i__] / 3.f;
		    ex[1] = x[i__] + xerr[i__] / 3.f;
		    ey[0] = y[i__] - yerr[i__];
		    ey[1] = y[i__] - yerr[i__];
		}
		curv_(&c__2, ex, ey);
		vgcrv1_1.idmark = 1;
		if (*iy == 1) {
		    ex[0] = x[i__] - deltax;
		    ex[1] = x[i__] + deltax;
		    ey[0] = y[i__] + yerr[i__];
		    ey[1] = y[i__] + yerr[i__];
		} else {
		    ex[0] = x[i__] - xerr[i__] / 3.f;
		    ex[1] = x[i__] + xerr[i__] / 3.f;
		    ey[0] = y[i__] + yerr[i__];
		    ey[1] = y[i__] + yerr[i__];
		}
		curv_(&c__2, ex, ey);
		vgcrv1_1.idmark = 1;
	    }
	}
/* L20: */
    }
    vgcrv1_1.idmark = 0;
    return 0;
} /* errbar_ */

