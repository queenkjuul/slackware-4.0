/* The keyboard characteristics must be modified for VG.  The
   termio facilities are used for this. */

#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/termio.h>
#include <sys/types.h>
#include <unistd.h>
#include "agraf.h"


#define TRUE	1
/******************************************************
 agrafa(iktype,keep,kcurr,kflag) - Get keyboard status.		     
*******************************************************/
logical
agrafa_(iktype,keep,kcurr,kflag)
integer *iktype,*keep,*kcurr,*kflag;
{
        struct termio buf;
        char c;
        static char keepchar=0;
        int d /* ,count */;
	unsigned char buf_min,buf_time;
        
         
/* The following code just keeps track of whether the key should
   be kept or thrown away  --- it is presumably very portable */

        *kflag=0;
        if (keepchar)       /* if previous call did not dispose */
        {                   /* of character */
                *kcurr=c=keepchar;
                if (*kcurr < 33)
                        *kflag = 4;
                else if (*kcurr >64 && *kcurr < 91)
                        *kflag = 1;
                if(*keep==1)
                        keepchar=0;
                else if (*keep ==2)
                  {
                        if(*iktype==0)
                             keepchar=0;
                        else if(*iktype==c)
                             keepchar=0;
                  }
                else if (*keep ==3 && *iktype!=c)
                        keepchar=0;
                if(*iktype==0)
                        return(TRUE);
                else                     
                        return(c==*iktype);
       }
        c=0;

/* Get the pointer to the termio structure */
        ioctl(0,TCGETA,&buf); 
/* Change the flag to turn off canonical mode processing;
   that is, input characters are not assembled into lines. 
   In this non-canonical mode erase and kill processing
   does not occur. */
        buf.c_lflag ^= (ICANON);  
/* Change the flag to turn off keyboard echoing */
        buf.c_lflag ^= (ECHO);   
/* Change the non-canonical mode so that the intracharacter
   timing plays no role */
  	buf_time = buf.c_cc[VTIME];
	buf.c_cc[VTIME]=0;
/* Change the non-canonical mode so that the read will be 
   satisfied after one character is entered */
  	buf_min = buf.c_cc[VMIN]; 
	buf.c_cc[VMIN]=1;
/* Set the new modes */
        ioctl(0,TCSETA,&buf);
        if(fcntl(0,F_SETFL,O_RDONLY)==-1)
        {
                fprintf(stderr,"unable to set non-blocking read\n");
                return(-1);
        }
        d = read(0,&c,1);
/* Return the termio structure to its previous state */
        buf.c_lflag |= (ICANON); 
        buf.c_lflag |= (ECHO);
  	buf.c_cc[VTIME] = buf_time;
	buf.c_cc[VMIN] = buf_min;
/* Set the restored modes */
        ioctl(0,TCSETA,&buf); 

        *kcurr=c;
        if (*kcurr < 33)
               *kflag = 4;
        else if (*kcurr >64 && *kcurr < 91)
               *kflag = 1;
        if(*keep==0)
               keepchar=c;
        else if (*keep ==2)
               if(*iktype!=0 && *iktype != c)
                   keepchar=c;
        else if (*keep ==3 && *iktype==c)
               keepchar=c;
        if(*iktype==0)
               return(TRUE);
        else                     
               return(c==*iktype);
}
