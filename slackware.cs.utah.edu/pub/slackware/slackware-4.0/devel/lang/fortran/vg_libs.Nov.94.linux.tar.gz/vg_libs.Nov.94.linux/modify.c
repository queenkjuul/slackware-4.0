/* modify.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"
#include "agraf.h"

/* Common Block Declarations */

struct {
    real sx[50], sy[50], sa[50], sh[50];
    integer sc[50], so[50], sm[50], ntex;
} vgtx1_;

#define vgtx1_1 vgtx1_

struct {
    real smin[21]	/* was [7][3] */, smax[21]	/* was [7][3] */;
    integer ibndf[21]	/* was [7][3] */;
    real tmin[21]	/* was [7][3] */, tmax[21]	/* was [7][3] */;
} vgsbnd_;

#define vgsbnd_1 vgsbnd_

/* Table of constant values */

static integer c__9 = 9;
static integer c__2 = 2;
static integer c__6 = 6;
static integer c__5 = 5;
static integer c__4 = 4;
static integer c__3 = 3;
static integer c__1 = 1;
static integer c__0 = 0;
static integer c__8 = 8;
static integer c__10 = 10;
static integer c__12 = 12;
static integer c__14 = 14;
static integer c__16 = 16;
static integer c__18 = 18;
static integer c__34 = 34;
static integer c__56 = 56;
static integer c__15 = 15;
static integer c__22 = 22;
static real c_b72 = 1.f;
static real c_b73 = 0.f;
static real c_b76 = 3.f;
static real c_b77 = -8.f;
static real c_b78 = -1.f;
static integer c__20 = 20;

/* Subroutine */ int vgmodg_(integer *kg, real *xmin, real *xmax, real *ymin1,
	 real *ymax1, real *ymin2, real *ymax2, integer *ninlx, integer *
	naxlx, integer *ninly1, integer *naxly1, integer *ninly2, integer *
	naxly2, integer *logfx, integer *logfy1, integer *logfy2, integer *
	kludge, real *btop, real *bbot, real *blef, real *brit)
{
    /* Initialized data */

    static integer ix = 1;
    static integer iy = 1;

    /* System generated locals */
    integer i__1, i__2;
    real r__1;

    /* Builtin functions */
    integer pow_ii(integer *, integer *);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static char text[25*3*8];
    extern doublereal vgg2s_(real *, real *, real *, real *, real *, integer *
	    , integer *, integer *), vgs2g_(real *, real *, real *, real *, 
	    real *, integer *, integer *, integer *);
    static integer i__, j, kflag;
    static real x, y;
    extern /* Subroutine */ int vgmed_(char *, integer *, integer *, ftnlen);
    static integer kcurr, numbx;
    static real txmin, tymin, txmax, tymax;
    static char ch[1];
    static integer numby1, numby2;
    static integer ie, jvcode;
    extern /* Subroutine */ int vgcorf_(integer *, real *, real *, integer *, 
	    integer *, real *, real *, real *, real *, real *, real *, real *,
	     real *);
    static integer iscont, logfxt, logfyt;
    extern /* Subroutine */ int vgrarr_(char *, integer *, real *, real *, 
	    integer *, integer *, integer *, logical *, ftnlen), vgwarr_(char 
	    *, integer *, real *, real *, integer *, integer *, real *, real *
	    , integer *, integer *, integer *, ftnlen);
    static logical ok1, ok2, ok3;
    static integer ninlxt, naxlxt, ninlyt, naxlyt;
    extern /* Subroutine */ int vgxstr_(char *, integer *, integer *, ftnlen);
    static real dum1, dum2;

/*  ROUTINE TO ALLOW USER TO INTERACTIVELY MODIFY GRAPH'S ATTRIBUTES */
/*  STORE CURRENT VALUES NEEDED TO ADJUST TEXT IN 'STICK TO POINT' MODE */
    txmin = *xmin;
    txmax = *xmax;
    tymin = *ymin1;
    tymax = *ymax1;
    ninlxt = *ninlx;
    naxlxt = *naxlx;
    ninlyt = *ninly1;
    naxlyt = *naxly1;
    logfxt = *logfx;
    logfyt = *logfy1;
/*  UNPACK DATA IN KLUDGE */
    iscont = *kludge / pow_ii(&c__2, &c__9) % 2;
    jvcode = (*kludge / pow_ii(&c__2, &c__6) % 2 << 1) + *kludge / pow_ii(&
	    c__2, &c__5) % 2;
    numbx = *kludge / pow_ii(&c__2, &c__4) % 2;
    numby1 = *kludge / pow_ii(&c__2, &c__3) % 2;
    numby2 = *kludge / pow_ii(&c__2, &c__2) % 2;
/*  FILL TEXT ARRAY */
    vgwarr_(text, &c__1, xmin, xmax, ninlx, naxlx, &vgsbnd_1.smin[*kg - 1], &
	    vgsbnd_1.smax[*kg - 1], &vgsbnd_1.ibndf[*kg - 1], logfx, &numbx, 
	    25L);
    vgwarr_(text, &c__2, ymin1, ymax1, ninly1, naxly1, &vgsbnd_1.smin[*kg + 6]
	    , &vgsbnd_1.smax[*kg + 6], &vgsbnd_1.ibndf[*kg + 6], logfy1, &
	    numby1, 25L);
    if ((jvcode == 0 || jvcode == 2) && iscont == 0) {
	for (i__ = 1; i__ <= 8; ++i__) {
	    s_copy(text + (i__ * 3 - 1) * 25, "*", 25L, 1L);
/* L10: */
	}
	s_copy(text + 275, "Unused", 25L, 6L);
    } else if (jvcode == 1 && iscont == 0) {
	for (i__ = 1; i__ <= 8; ++i__) {
	    s_copy(text + (i__ * 3 - 1) * 25, "*", 25L, 1L);
/* L20: */
	}
	s_copy(text + 275, "Same as left y-axis", 25L, 19L);
    } else {
	vgwarr_(text, &c__3, ymin2, ymax2, ninly2, naxly2, &vgsbnd_1.smin[*kg 
		+ 13], &vgsbnd_1.smax[*kg + 13], &vgsbnd_1.ibndf[*kg + 13], 
		logfy2, &numby2, 25L);
    }
/*  DRAW TEXT ARRAY */
    agraf0_(&ie, &c__0);
    vgxstr_("LINEAR/LOG", &c__0, &c__4, 10L);
    vgxstr_("MIN", &c__0, &c__6, 3L);
    vgxstr_("DEFAULT", &c__0, &c__8, 7L);
    vgxstr_("MIN SET BY", &c__0, &c__10, 10L);
    vgxstr_("MAX", &c__0, &c__12, 3L);
    vgxstr_("DEFAULT", &c__0, &c__14, 7L);
    vgxstr_("MAX SET BY", &c__0, &c__16, 10L);
    vgxstr_("NUMBERED?", &c__0, &c__18, 9L);
    vgxstr_("X-AXIS", &c__12, &c__2, 6L);
    vgxstr_("LEFT Y-AXIS", &c__34, &c__2, 11L);
    if (iscont == 0) {
	vgxstr_("RIGHT Y-AXIS", &c__56, &c__2, 12L);
    } else {
	vgxstr_("Z-AXIS", &c__56, &c__2, 6L);
    }
    vgxstr_("<Esc>: exit   C: change value   U: update and exit", &c__15, &
	    c__22, 50L);
    for (i__ = 1; i__ <= 3; ++i__) {
	for (j = 1; j <= 8; ++j) {
	    i__1 = i__ * 22 - 10;
	    i__2 = (j << 1) + 2;
	    vgxstr_(text + (i__ + j * 3 - 4) * 25, &i__1, &i__2, 25L);
/* L30: */
	}
/* L40: */
    }
    i__1 = ix * 22 - 11;
    i__2 = (iy << 1) + 2;
    vgxstr_(">", &i__1, &i__2, 1L);
/*  LET USER CHANGE DATA */
L50:
L60:
    if (! agrafa_(&c__0, &c__1, &kcurr, &kflag)) {
	goto L60;
    }
    *(unsigned char *)ch = (char) kcurr;
    i__1 = ix * 22 - 11;
    i__2 = (iy << 1) + 2;
    vgxstr_(">", &i__1, &i__2, 1L);
    x = (real) ix;
    y = -((real) iy);
    dum1 = x;
    dum2 = y;
    vgcorf_(&c__0, &c_b72, &c_b73, &kcurr, &c__0, &c_b72, &c_b76, &c_b77, &
	    c_b78, &x, &dum1, &y, &dum2);
    ix = (integer) x;
    iy = -((integer) y);
    i__1 = ix * 22 - 11;
    i__2 = (iy << 1) + 2;
    vgxstr_(">", &i__1, &i__2, 1L);
/*  KCURR=27 IS ESC:  EXIT WITHOUT CHANGING ATTRIBUTES */
    if (kcurr == 27) {
	return 0;
    }
    if (*(unsigned char *)ch == 'C' || *(unsigned char *)ch == 'c') {
/*  CHANGE DATA */
	if (ix != 3 || jvcode == 3 || iscont == 1) {
	    vgmed_(text, &ix, &iy, 25L);
	}
    } else if (*(unsigned char *)ch == 'U' || *(unsigned char *)ch == 'u') {
/*  UPDATE ATTRIBUTES AND EXIT */
	vgrarr_(text, &c__1, xmin, xmax, logfx, &numbx, &vgsbnd_1.ibndf[*kg - 
		1], &ok1, 25L);
	vgrarr_(text, &c__2, ymin1, ymax1, logfy1, &numby1, &vgsbnd_1.ibndf[*
		kg + 6], &ok2, 25L);
	if (jvcode == 1 || jvcode == 3 || iscont == 1) {
	    vgrarr_(text, &c__3, ymin2, ymax2, logfy2, &numby2, &
		    vgsbnd_1.ibndf[*kg + 13], &ok3, 25L);
	} else {
	    ok3 = TRUE_;
	}
	if (ok1 && ok2 && ok3) {
/*  SETTING BOUNDARIES NEEDED FOR ADJUSTING TEXT */
	    if (vgsbnd_1.ibndf[*kg - 1] / pow_ii(&c__2, &c__0) % 2 == 0) {
		*xmin = vgsbnd_1.smin[*kg - 1];
	    }
	    if (vgsbnd_1.ibndf[*kg - 1] / pow_ii(&c__2, &c__1) % 2 == 0) {
		*xmax = vgsbnd_1.smax[*kg - 1];
	    }
	    if (vgsbnd_1.ibndf[*kg + 6] / pow_ii(&c__2, &c__0) % 2 == 0) {
		*ymin1 = vgsbnd_1.smin[*kg + 6];
	    }
	    if (vgsbnd_1.ibndf[*kg + 6] / pow_ii(&c__2, &c__1) % 2 == 0) {
		*ymax1 = vgsbnd_1.smax[*kg + 6];
	    }
	    if (vgsbnd_1.ibndf[*kg + 13] / pow_ii(&c__2, &c__0) % 2 == 0) {
		*ymin2 = vgsbnd_1.smin[*kg + 13];
	    }
	    if (vgsbnd_1.ibndf[*kg + 13] / pow_ii(&c__2, &c__1) % 2 == 0) {
		*ymax2 = vgsbnd_1.smax[*kg + 13];
	    }
	    *kludge = *kludge - (*kludge / pow_ii(&c__2, &c__4) % 2 << 4) - (*
		    kludge / pow_ii(&c__2, &c__3) % 2 << 3) - (*kludge / 
		    pow_ii(&c__2, &c__2) % 2 << 2);
	    *kludge = *kludge + (numbx << 4) + (numby1 << 3) + (numby2 << 2);
	    i__1 = vgtx1_1.ntex;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		if (vgtx1_1.so[i__ - 1] == *kg && vgtx1_1.sm[i__ - 1] == 2) {
		    r__1 = (real)vgs2g_(&vgtx1_1.sx[i__ - 1], blef, brit, &
			    txmin, &txmax, &ninlxt, &naxlxt, &logfxt);
		    vgtx1_1.sx[i__ - 1] = (real)vgg2s_(&r__1, blef, brit, 
			    xmin, xmax, ninlx, naxlx, logfx);
		    r__1 = (real)vgs2g_(&vgtx1_1.sy[i__ - 1], bbot, btop, &
			    tymin, &tymax, &ninlyt, &naxlyt, &logfyt);
		    vgtx1_1.sy[i__ - 1] = (real)vgg2s_(&r__1, bbot, btop, 
			    ymin1, ymax1, ninly1, naxly1, logfy1);
		}
/* L70: */
	    }
	}
	return 0;
    }
    goto L50;
} /* vgmodg_ */

/* Subroutine */ int vgwarr_(char *text, integer *n, real *amin, real *amax, 
	integer *logmin, integer *logmax, real *smin, real *smax, integer *
	ibndf, integer *logflg, integer *numf, ftnlen text_len)
{
    /* System generated locals */
    address a__1[5];
    integer i__1[5];

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen);
    integer pow_ii(integer *, integer *);

    /* Local variables */
    static char temp[25], temp2[25];
    extern /* Subroutine */ int vgunp_(char *, ftnlen);
    extern integer vgistr_(char *, ftnlen);
    static integer len, len2;

    /* Fortran I/O blocks */
    static icilist io___33 = { 0, temp, 0, "(G14.6)", 25, 1 };
    static icilist io___34 = { 0, temp, 0, "(G14.6)", 25, 1 };
    static icilist io___37 = { 0, temp2, 0, "(I4)", 25, 1 };
    static icilist io___39 = { 0, temp, 0, "(G14.6)", 25, 1 };
    static icilist io___40 = { 0, temp, 0, "(G14.6)", 25, 1 };
    static icilist io___41 = { 0, temp2, 0, "(I4)", 25, 1 };


/*  WRITES INITIAL VALUES INTO TEXT ARRAY */
    /* Parameter adjustments */
    text -= 100;

    /* Function Body */
    if (*logflg == 0) {
	s_copy(text + (*n + 3) * 25, "LINEAR", 25L, 6L);
    } else {
	s_copy(text + (*n + 3) * 25, "LOG", 25L, 3L);
    }
    s_wsfi(&io___33);
    do_fio(&c__1, (char *)&(*amin), (ftnlen)sizeof(real));
    e_wsfi();
    vgunp_(temp, 25L);
    s_copy(text + (*n + 6) * 25, temp, 25L, 25L);
    s_wsfi(&io___34);
    do_fio(&c__1, (char *)&(*smin), (ftnlen)sizeof(real));
    e_wsfi();
    vgunp_(temp, 25L);
    len = vgistr_(temp, 25L);
    s_wsfi(&io___37);
    do_fio(&c__1, (char *)&(*logmin), (ftnlen)sizeof(integer));
    e_wsfi();
    vgunp_(temp2, 25L);
    len2 = vgistr_(temp2, 25L);
/* Writing concatenation */
    i__1[0] = 1, a__1[0] = "(";
    i__1[1] = len, a__1[1] = temp;
    i__1[2] = 6, a__1[2] = "  10**";
    i__1[3] = len2, a__1[3] = temp2;
    i__1[4] = 1, a__1[4] = ")";
    s_cat(text + (*n + 9) * 25, a__1, i__1, &c__5, 25L);
    if (*ibndf / pow_ii(&c__2, &c__0) % 2 == 0) {
	s_copy(text + (*n + 12) * 25, "VG", 25L, 2L);
    } else {
	s_copy(text + (*n + 12) * 25, "USER", 25L, 4L);
    }
    s_wsfi(&io___39);
    do_fio(&c__1, (char *)&(*amax), (ftnlen)sizeof(real));
    e_wsfi();
    vgunp_(temp, 25L);
    s_copy(text + (*n + 15) * 25, temp, 25L, 25L);
    s_wsfi(&io___40);
    do_fio(&c__1, (char *)&(*smax), (ftnlen)sizeof(real));
    e_wsfi();
    vgunp_(temp, 25L);
    len = vgistr_(temp, 25L);
    s_wsfi(&io___41);
    do_fio(&c__1, (char *)&(*logmax), (ftnlen)sizeof(integer));
    e_wsfi();
    vgunp_(temp2, 25L);
    len2 = vgistr_(temp2, 25L);
/* Writing concatenation */
    i__1[0] = 1, a__1[0] = "(";
    i__1[1] = len, a__1[1] = temp;
    i__1[2] = 6, a__1[2] = "  10**";
    i__1[3] = len2, a__1[3] = temp2;
    i__1[4] = 1, a__1[4] = ")";
    s_cat(text + (*n + 18) * 25, a__1, i__1, &c__5, 25L);
    if (*ibndf / pow_ii(&c__2, &c__1) % 2 == 0) {
	s_copy(text + (*n + 21) * 25, "VG", 25L, 2L);
    } else {
	s_copy(text + (*n + 21) * 25, "USER", 25L, 4L);
    }
    if (*numf == 0) {
	s_copy(text + (*n + 24) * 25, "YES", 25L, 3L);
    } else {
	s_copy(text + (*n + 24) * 25, "NO", 25L, 2L);
    }
    return 0;
} /* vgwarr_ */

/* Subroutine */ int vgmed_(char *text, integer *ix, integer *iy, ftnlen 
	text_len)
{
    /* System generated locals */
    address a__1[2], a__2[3];
    integer i__1[2], i__2[3], i__3;

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer i_indx(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen);

    /* Local variables */
    static integer inde, indp;
    extern /* Subroutine */ int vggl_(integer *, char *, char *, integer *, 
	    ftnlen, ftnlen);
    static char temp[25], temp2[25], ch[1];
    static integer jx, jy;
    extern integer vgistr_(char *, ftnlen);
    extern /* Subroutine */ int vgxstr_(char *, integer *, integer *, ftnlen);
    static integer len;
    static char new__[25];
    static integer len2;

/*  EDIT ONE ITEM IN TEXT ARRAY.  IF LIMITS ARE CHANGED, ALSO CHANGE */
/*  LIMIT STATUS TO 'SET BY USER'. */
    /* Parameter adjustments */
    text -= 100;

    /* Function Body */
    s_copy(temp, text + (*ix + *iy * 3) * 25, 25L, 25L);
    jx = *ix * 22 - 10;
    jy = (*iy << 1) + 2;
    if (*iy == 1) {
	vgxstr_(temp, &jx, &jy, 25L);
	*(unsigned char *)ch = *(unsigned char *)&temp[1];
	if (*(unsigned char *)ch == 'O') {
	    s_copy(text + (*ix + *iy * 3) * 25, "LINEAR", 25L, 6L);
	    vgxstr_("LINEAR", &jx, &jy, 6L);
	} else {
	    s_copy(text + (*ix + *iy * 3) * 25, "LOG", 25L, 3L);
	    vgxstr_("LOG", &jx, &jy, 3L);
	}
    } else if (*iy == 2 || *iy == 5) {
/*  CHANGING AXIS BOUNDARIES */
	vggl_(&len, "NEW VALUE:  ", new__, &c__20, 12L, 25L);
	vgxstr_(temp, &jx, &jy, 25L);
/*  PAD NUMBER WITH ZEROES (NEEDED FOR CORRECT READING OF STRING TO RE
AL */
/*  IN VGRARR) */
	s_copy(temp, ".000000", 25L, 7L);
	len2 = vgistr_(new__, 25L);
	indp = i_indx(new__, ".", 25L, 1L);
	inde = i_indx(new__, "E", 25L, 1L);
	if (inde == 0) {
	    inde = i_indx(new__, "e", 25L, 1L);
	}
	if (indp == 0) {
	    if (inde == 0) {
/* Writing concatenation */
		i__1[0] = len2, a__1[0] = new__;
		i__1[1] = 25, a__1[1] = temp;
		s_cat(temp2, a__1, i__1, &c__2, 25L);
	    } else {
/* Writing concatenation */
		i__2[0] = inde - 1, a__2[0] = new__;
		i__2[1] = 7, a__2[1] = temp;
		i__2[2] = len2 - (inde - 1), a__2[2] = new__ + (inde - 1);
		s_cat(temp2, a__2, i__2, &c__3, 25L);
	    }
	} else {
	    if (inde == 0) {
/* Writing concatenation */
		i__1[0] = len2, a__1[0] = new__;
		i__1[1] = indp + 7 - len2 - 1, a__1[1] = temp + 1;
		s_cat(temp2, a__1, i__1, &c__2, 25L);
	    } else {
/* Writing concatenation */
		i__2[0] = inde - 1, a__2[0] = new__;
		i__2[1] = indp + 7 - inde - 1, a__2[1] = temp + 1;
		i__2[2] = len2 - (inde - 1), a__2[2] = new__ + (inde - 1);
		s_cat(temp2, a__2, i__2, &c__3, 25L);
	    }
	}
	vgxstr_(temp2, &jx, &jy, 25L);
	s_copy(text + (*ix + *iy * 3) * 25, temp2, 25L, 25L);
	i__3 = jy + 4;
	vgxstr_(text + (*ix + (*iy + 2) * 3) * 25, &jx, &i__3, 25L);
	s_copy(text + (*ix + (*iy + 2) * 3) * 25, "USER", 25L, 4L);
	i__3 = jy + 4;
	vgxstr_("USER", &jx, &i__3, 4L);
    } else if (*iy == 4 || *iy == 7) {
/*  CHANGING BOUNDARY TYPES */
	*(unsigned char *)ch = *(unsigned char *)temp;
	if (*(unsigned char *)ch == 'V') {
/*  CHANGING VG LIMIT TO USER LIMIT */
	    vgxstr_(temp, &jx, &jy, 25L);
	    vgxstr_("USER", &jx, &jy, 4L);
	    s_copy(text + (*ix + *iy * 3) * 25, "USER", 25L, 4L);
	} else {
/*  CHANGING USER LIMIT TO VG LIMIT */
	    vgxstr_(temp, &jx, &jy, 25L);
	    vgxstr_("VG", &jx, &jy, 2L);
	    s_copy(text + (*ix + *iy * 3) * 25, "VG", 25L, 2L);
	}
    } else if (*iy == 8) {
/*  CHANGING NUMBERING FLAG */
	vgxstr_(temp, &jx, &jy, 25L);
	*(unsigned char *)ch = *(unsigned char *)temp;
	if (*(unsigned char *)ch == 'Y') {
	    s_copy(text + (*ix + *iy * 3) * 25, "NO", 25L, 2L);
	} else {
	    s_copy(text + (*ix + *iy * 3) * 25, "YES", 25L, 3L);
	}
	vgxstr_(text + (*ix + *iy * 3) * 25, &jx, &jy, 25L);
    }
    return 0;
} /* vgmed_ */

/* Subroutine */ int vgrarr_(char *text, integer *n, real *amin, real *amax, 
	integer *logflg, integer *numf, integer *ibndf, logical *ok, ftnlen 
	text_len)
{
    /* System generated locals */
    icilist ici__1;

    /* Builtin functions */
    integer s_rsfi(icilist *), do_fio(integer *, char *, ftnlen), e_rsfi(void)
	    , s_cmp(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    extern /* Subroutine */ int sleep_(integer *);
    static integer jx;
    extern logical vgisno_(char *, ftnlen);
    extern /* Subroutine */ int vgxstr_(char *, integer *, integer *, ftnlen);

/*  READS TEXT ARRAY AND CHECKS DATA */
    /* Parameter adjustments */
    text -= 100;

    /* Function Body */
    jx = *n * 22 - 10;
/*  CHECK NUMBERS USER MAY HAVE CHANGED, MAKE NO CHANGES IF THEY'RE */
/*  NOT VALID. */
    if (vgisno_(text + (*n + 6) * 25, 25L)) {
	ici__1.icierr = 0;
	ici__1.iciend = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 25;
	ici__1.iciunit = text + (*n + 6) * 25;
	ici__1.icifmt = "(G14.6)";
	s_rsfi(&ici__1);
	do_fio(&c__1, (char *)&(*amin), (ftnlen)sizeof(real));
	e_rsfi();
    } else {
	vgxstr_(text + (*n + 6) * 25, &jx, &c__6, 25L);
	sleep_(&c__1);
	vgxstr_(text + (*n + 6) * 25, &jx, &c__6, 25L);
	*ok = FALSE_;
	return 0;
    }
    if (vgisno_(text + (*n + 15) * 25, 25L)) {
	ici__1.icierr = 0;
	ici__1.iciend = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 25;
	ici__1.iciunit = text + (*n + 15) * 25;
	ici__1.icifmt = "(G14.6)";
	s_rsfi(&ici__1);
	do_fio(&c__1, (char *)&(*amax), (ftnlen)sizeof(real));
	e_rsfi();
    } else {
	*ok = FALSE_;
	vgxstr_(text + (*n + 15) * 25, &jx, &c__12, 25L);
	sleep_(&c__1);
	vgxstr_(text + (*n + 15) * 25, &jx, &c__12, 25L);
	return 0;
    }
    if (s_cmp(text + (*n + 3) * 25, "LOG", 25L, 3L) == 0) {
	*logflg = 1;
    } else {
	*logflg = 0;
    }
    if (s_cmp(text + (*n + 12) * 25, "USER", 25L, 4L) == 0) {
	*ibndf = 1;
    } else {
	*ibndf = 0;
    }
    if (s_cmp(text + (*n + 21) * 25, "USER", 25L, 4L) == 0) {
	*ibndf += 2;
    }
    if (s_cmp(text + (*n + 24) * 25, "YES", 25L, 3L) == 0) {
	*numf = 0;
    } else {
	*numf = 1;
    }
    *ok = TRUE_;
    return 0;
} /* vgrarr_ */

logical vgisno_(char *string, ftnlen string_len)
{
    /* System generated locals */
    integer i__1;
    logical ret_val;
    icilist ici__1;

    /* Builtin functions */
    integer s_rsfi(icilist *), do_fio(integer *, char *, ftnlen), e_rsfi(void)
	    ;

    /* Local variables */
    static real x;

/*  DETERMINES IF A STRING IS A REAL */
    ici__1.icierr = 1;
    ici__1.iciend = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = string_len;
    ici__1.iciunit = string;
    ici__1.icifmt = "(G14.6)";
    i__1 = s_rsfi(&ici__1);
    if (i__1 != 0) {
	goto L1;
    }
    i__1 = do_fio(&c__1, (char *)&x, (ftnlen)sizeof(real));
    if (i__1 != 0) {
	goto L1;
    }
    i__1 = e_rsfi();
    if (i__1 != 0) {
	goto L1;
    }
    ret_val = TRUE_;
    return ret_val;
L1:
    ret_val = FALSE_;
    return ret_val;
} /* vgisno_ */

