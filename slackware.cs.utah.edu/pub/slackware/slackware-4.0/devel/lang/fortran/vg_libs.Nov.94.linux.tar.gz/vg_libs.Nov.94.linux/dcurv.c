/* dcurv.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    integer idmark;
} vgcrv1_;

#define vgcrv1_1 vgcrv1_

/* Subroutine */ int dcurv_(integer *n, doublereal *dx, doublereal *dy)
{
    /* Initialized data */

    static doublereal rmin = 1e-37;
    static doublereal rmax = 1e37;

    /* System generated locals */
    integer i__1, i__2;

    /* Builtin functions */
    double d_sign(doublereal *, doublereal *);

    /* Local variables */
    extern /* Subroutine */ int curv_(integer *, real *, real *);
    static integer i__, j;
    static real x[100], y[100];
    static integer loops;
    static doublereal dx1, dy1;
    static integer num;

/*  IMPORTS DOUBLE PRECISION DATA, CONVERTING IT TO REAL */
    /* Parameter adjustments */
    --dy;
    --dx;

    /* Function Body */
/* CHANGED NUM'S MAX VALUE FROM 101 TO 100 */
/* SO ARRAYS WITH MULTIPLES OF 100 PTS WOULD */
/* NOT HAVE LAST PT AS 0 0 - wea 3/92 */
    loops = *n / 100 + 1;
    i__1 = loops;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (i__ == loops) {
	    num = *n % 100;
	} else {
	    num = 100;
	}
	i__2 = num;
	for (j = 1; j <= i__2; ++j) {
	    dx1 = dx[(i__ - 1) * 100 + j];
	    dy1 = dy[(i__ - 1) * 100 + j];
	    if (abs(dx1) > rmax) {
		x[j - 1] = (real) d_sign(&rmax, &dx1);
	    } else if (abs(dx1) < rmin) {
		x[j - 1] = 0.f;
	    } else {
		x[j - 1] = (real) dx1;
	    }
	    if (abs(dy1) > rmax) {
		y[j - 1] = (real) d_sign(&rmax, &dy1);
	    } else if (abs(dy1) < rmin) {
		y[j - 1] = 0.f;
	    } else {
		y[j - 1] = (real) dy1;
	    }
/* L10: */
	}
	if (num != 0) {
	    curv_(&num, x, y);
	}
	vgcrv1_1.idmark = 1;
/* L20: */
    }
    vgcrv1_1.idmark = 0;
    return 0;
} /* dcurv_ */

