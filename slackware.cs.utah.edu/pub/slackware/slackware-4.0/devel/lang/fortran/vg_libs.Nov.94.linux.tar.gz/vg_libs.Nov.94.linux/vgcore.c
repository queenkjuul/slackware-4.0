/* vgcore.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct vglttr_1_ {
    real bbot0[7], btop0[7], bleft0[7], brit0[7];
    integer isdx[7], isdy1[7], isdy2[7], kludge[7], axcol;
};

#define vglttr_1 (*(struct vglttr_1_ *) &vglttr_)

struct vgleg1_1_ {
    integer lsyms[84]	/* was [14][6] */, lcolrs[84]	/* was [14][6] */, 
	    lstys[84]	/* was [14][6] */, nlines[6];
    real hh[6], vv[6], xleg[7], yleg[7];
    integer isleg[7], legset[7], legvis[6];
};

#define vgleg1_1 (*(struct vgleg1_1_ *) &vgleg1_)

struct vgleg3_1_ {
    logical lbox;
    integer leglin;
};

#define vgleg3_1 (*(struct vgleg3_1_ *) &vgleg3_)

struct vgtx1_1_ {
    real sx[50], sy[50], sa[50], sh[50];
    integer sc[50], so[50], sm[50], ntex;
};

#define vgtx1_1 (*(struct vgtx1_1_ *) &vgtx1_)

struct vgloop_1_ {
    logical pass1;
    integer jexit, mdevic, istat;
    logical pass2;
};
struct vgloop_2_ {
    logical pass1;
    integer je, md, is;
    logical pass2;
};

#define vgloop_1 (*(struct vgloop_1_ *) &vgloop_)
#define vgloop_2 (*(struct vgloop_2_ *) &vgloop_)

struct vgscrn_1_ {
    real sht, swd;
    integer ncols, nrows;
};

#define vgscrn_1 (*(struct vgscrn_1_ *) &vgscrn_)

struct vgfil1_1_ {
    char filnam[6], exten[3];
};

#define vgfil1_1 (*(struct vgfil1_1_ *) &vgfil1_)

struct vgfil2_1_ {
    integer numpag;
};

#define vgfil2_1 (*(struct vgfil2_1_ *) &vgfil2_)

struct vgcntr_1_ {
    integer ig;
};

#define vgcntr_1 (*(struct vgcntr_1_ *) &vgcntr_)

struct vgsbnd_1_ {
    real smin[21]	/* was [7][3] */, smax[21]	/* was [7][3] */;
    integer limflg[21]	/* was [7][3] */;
    real tmin[21]	/* was [7][3] */, tmax[21]	/* was [7][3] */;
};

#define vgsbnd_1 (*(struct vgsbnd_1_ *) &vgsbnd_)

struct vgssiz_1_ {
    real subsz, suprsz;
};

#define vgssiz_1 (*(struct vgssiz_1_ *) &vgssiz_)

struct vgcrv1_1_ {
    integer idmark;
};

#define vgcrv1_1 (*(struct vgcrv1_1_ *) &vgcrv1_)

struct vghgt_1_ {
    real height;
};

#define vghgt_1 (*(struct vghgt_1_ *) &vghgt_)

struct vglab_1_ {
    integer labels[28];
};

#define vglab_1 (*(struct vglab_1_ *) &vglab_)

struct vgprnt_1_ {
    logical pb4xit;
};

#define vgprnt_1 (*(struct vgprnt_1_ *) &vgprnt_)

struct vgusrc_1_ {
    char commnt[80];
};

#define vgusrc_1 (*(struct vgusrc_1_ *) &vgusrc_)

struct vglim_1_ {
    real bleft1[7], brit1[7], bbot1[7], btop1[7], bxmin[7], bxmax[7], bymin[
	    14]	/* was [7][2] */, bymax[14]	/* was [7][2] */;
    integer ninlx[7], naxlx[7], ninly[14]	/* was [7][2] */, naxly[14]	
	    /* was [7][2] */, msx[7], msy[14]	/* was [7][2] */;
};
struct vglim_2_ {
    real dummy[28], bxmin[7], bxmax[7], bymin[14]	/* was [7][2] */, 
	    bymax[14]	/* was [7][2] */;
    integer idum[63];
};

#define vglim_1 (*(struct vglim_1_ *) &vglim_)
#define vglim_2 (*(struct vglim_2_ *) &vglim_)

struct vgtick_1_ {
    real tikx1[7], tikx2[7], tiky1[7], tiky2[7];
};

#define vgtick_1 (*(struct vgtick_1_ *) &vgtick_)

struct vgzoom_1_ {
    integer ipoint[6];
};

#define vgzoom_1 (*(struct vgzoom_1_ *) &vgzoom_)

struct vgfnt_1_ {
    char f1[100], f2[100], f3[100], f4[100], f5[100], f6[100], f7[100], f8[
	    100], f9[100], f10[100], f11[100], f12[100], f13[100], f14[100], 
	    f15[100], f16[100], f17[100], f18[100], f19[100], f20[100], f21[
	    100], f22[100], f23[100], f24[100], f25[100], f26[100], f27[100], 
	    f28[100], f29[100], f30[100], f31[100], f32[100], f33[100], f34[
	    100], f35[100], f36[100], f37[100], f38[100], f39[100], f40[100], 
	    f41[100], f42[100], f43[100], f44[100], f45[100], f46[100], f47[
	    100], f48[100], f49[100], f50[100], f51[100], f52[100], f53[100], 
	    f54[100], f55[100], f56[100], f57[24];
};

#define vgfnt_1 (*(struct vgfnt_1_ *) &vgfnt_)

struct vgfpt_1_ {
    integer ifptr[256];
};

#define vgfpt_1 (*(struct vgfpt_1_ *) &vgfpt_)

struct {
    integer idevic, idst, npen;
} vgpnf_;

#define vgpnf_1 vgpnf_

struct {
    char clegs[3360]	/* was [14][6] */;
} vgleg2_;

#define vgleg2_1 vgleg2_

struct {
    real offstl[7];
} vgleg4_;

#define vgleg4_1 vgleg4_

struct {
    logical baton;
} vgbt_;

#define vgbt_1 vgbt_

struct {
    logical yestic[21]	/* was [7][3] */;
    integer nh[7], nv1[7], nv2[7];
} vgtic1_;

#define vgtic1_1 vgtic1_

struct {
    char st[3500];
} vgtx2_;

#define vgtx2_1 vgtx2_

struct {
    char ticstr[5880]	/* was [7][3][14] */;
} vgtic2_;

#define vgtic2_1 vgtic2_

/* Initialized data */

struct {
    real e_1[28];
    integer e_2[29];
    } vglttr_ = { 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 18.75f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 25.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

struct {
    real e_1[42];
    integer e_2[21];
    real e_3[42];
    } vgsbnd_ = { 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f };

struct {
    real e_1[2];
    } vgssiz_ = { .7f, .7f };

struct {
    integer e_1;
    } vgcrv1_ = { 0 };

struct {
    real e_1;
    } vghgt_ = { .35f };

struct {
    integer e_1[28];
    } vglab_ = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0 };

struct {
    logical e_1;
    } vgprnt_ = { FALSE_ };

struct {
    char e_1[80];
    } vgusrc_ = { "                                                         "
	    "                       " };

struct {
    real e_1[70];
    integer e_2[63];
    } vglim_ = { 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0 };

struct {
    real e_1[28];
    } vgtick_ = { .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, 
	    .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, 
	    .35f, .35f, .35f, .35f, .35f, .35f, .35f };

struct {
    integer e_1[6];
    } vgzoom_ = { 0, 0, 0, 0, 0, 0 };

struct {
    integer e_1[258];
    real e_2[26];
    integer e_3[20];
    } vgleg1_ = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0, 0, 0, 0,
	     0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1 };

struct {
    char e_1[5624];
    } vgfnt_ = { "9G?G<F:D9A9?:<<:?9A9D:F<G?GAFDDFAG?G~~:F:F::F:FF:F~~9G@H9<"
	    "G<@H~~9G@89DGD@8~~:F@J:@@6F@@J~~8H@I>C8C=?;9@=E9C?HCBC@I~~9G@G@9"
	    "~>9@G@~~;E;EE;~>EE;;~~;E@F@:~>;CE=~>EC;=~~:F>F>B:B:>>>>:B:B>F>FB"
	    "BBBF>F~~9G@H9<G<@H~>@8GD9D@8~~<D?D=C<A<?==?<A<C=D?DACCAD?D~>=A=?"
	    "~>>B>>~>?C?=~~<D<D<<D<DD<D~>=C==~>>C>=~>?C?=~~;E@E;@@;E@@E~><@D@"
	    "~>@D@<~~:C:@C;CE:@~>=@B=~>=@BC~>@@B?~>@@BA~~=FF@=E=;F@~>C@>C~>C@"
	    ">=~>@@>A~>@@>?~~<D?D=C<A<?==?<A<C=D?DACCAD?D~>=A=?~>>B>>~>?C?=~>"
	    "@C@=~>ACA=~>BBB>~>CAC?~~<D<D<<D<DD<D~>=C==~>>C>=~>?C?=~>@C@=~>AC"
	    "A=~>BCB=~>CCC=~~;E@F;=E=@F~>@C=>~>@CC>~>@@?>~>@@A>~~;E@:EC;C@:~>"
	    "@=CB~>@==B~>@@AB~>@@?B~~;E@E;@@;E@@E~><?AD~>=>BC~>>=CB~>?<DA~~:F"
	    "@F<;FB:BD;@F~>@@@F~>@@:B~>@@<;~>@@D;~>@@FB~~5K>K;J8H6E5B5>6;88;6"
	    ">5B5E6H8J;K>KBJEHHEJBK>K~>;E:D;C<D;E~>EEDDECFDEE~>:<<:?9A9D:F<~~"
	    "8H~~;E@L@>~>@9?8@7A8@9~~8H<L<E~>DLDE~~6KAL:0~>GL@0~>:AHA~>9;G;~~"
	    "6J>P>3~>BPB3~>GIEKBL>L;K9I9G:E;D=CCAE@F?G=G:E8B7>7;89:~~4LIL77~>"
	    "<L>J>H=F;E9E7G7I8K:L<L>KAJDJGKIL~>E>C=B;B9D7F7H8I:I<G>E>~~3MJCJD"
	    "IEHEGDFBD=B:@8>7:788796;6=7?8@?D@EAGAI@K>L<K;I;G<D>AC:E8G7I7J8J9"
	    "~~<DAL?E~~9GDPBN@K>G=B=>>9@5B2D0~~9G<P>N@KBGCBC>B9@5>2<0~~8H@F@:"
	    "~>;CE=~>EC;=~~3M@I@7~>7@I@~~;EA8@7?8@9A8A6@4?3~~3M7@I@~~;E@9?8@7"
	    "A8@9~~5KIP70~~6J?L<K:H9C9@:;<8?7A7D8F;G@GCFHDKAL?L~~6J<H>IALA7~~"
	    "6J:G:H;J<K>LBLDKEJFHFFEDCA97G7~~6J;LFL@DCDECFBG?G=F:D8A7>7;8:99;"
	    "~~6JCL9>H>~>CLC7~~6JEL;L:C;D>EAEDDFBG?G=F:D8A7>7;8:99;~~6JFIEKBL"
	    "@L=K;H:C:>;:=8@7A7D8F:G=G>FADCAD@D=C;A:>~~6JGL=7~>9LGL~~6J>L;K:I"
	    ":G;E=DACDBF@G>G;F9E8B7>7;8:99;9>:@<B?CCDEEFGFIEKBL>L~~6JFEEBC@@?"
	    "??<@:B9E9F:I<K?L@LCKEIFEF@E;C8@7>7;8::~~;E@E?D@CAD@E~>@9?8@7A8@9"
	    "~~;E@E?D@CAD@E~>A8@7?8@9A8A6@4?3~~4LHI8@H7~~3M7CIC~>7=I=~~4L8IH@"
	    "87~~7I:G:H;J<K>LBLDKEJFHFFEDDC@A@>~>@9?8@7A8@9~~3NEDDFBG?G=F<E;B"
	    ";?<=><A<C=D?~>EGD?D=F<H<J>KAKCJFIHGJEKBL?L<K:J8H7F6C6@7=8;:9<8?7"
	    "B7E8G9~~7I@L87~>@LH7~>;>E>~~5J9L97~>9LBLEKFJGHGFFDECBB~>9BBBEAF@"
	    "G>G;F9E8B797~~6KHGGIEKCL?L=K;I:G9D9?:<;:=8?7C7E8G:H<~~5J9L97~>9L"
	    "@LCKEIFGGDG?F<E:C8@797~~6I:L:7~>:LGL~>:BBB~>:7G7~~6H:L:7~>:LGL~>"
	    ":BBB~~6KHGGIEKCL?L=K;I:G9D9?:<;:=8?7C7E8G:H<H?~>C?H?~~5K9L97~>GL"
	    "G7~>9BGB~~<D@L@7~~8HDLD<C9B8@7>7<8;9:<:>~~5J9L97~>GL9>~>>CG7~~6G"
	    ":L:7~>:7F7~~4L8L87~>8L@7~>HL@7~>HLH7~~5K9L97~>9LG7~>GLG7~~5K>L<K"
	    ":I9G8D8?9<::<8>7B7D8F:G<H?HDGGFIDKBL>L~~5J9L97~>9LBLEKFJGHGEFCEB"
	    "BA9A~~5K>L<K:I9G8D8?9<::<8>7B7D8F:G<H?HDGGFIDKBL>L~>A;G5~~5J9L97"
	    "~>9LBLEKFJGHGFFDECBB9B~>@BG7~~6JGIEKBL>L;K9I9G:E;D=CCAE@F?G=G:E8"
	    "B7>7;89:~~8H@L@7~>9LGL~~5K9L9=::<8?7A7D8F:G=GL~~7I8L@7~>HL@7~~4L"
	    "6L;7~>@L;7~>@LE7~>JLE7~~6J9LG7~>GL97~~7I8L@B@7~>HL@B~~6JGL97~>9L"
	    "GL~>97G7~~9GDP=P=0D0~~5K7PI0~~9G<PCPC0<0~~8H@N8@~>@NH@~~4L44L4~~"
	    "<D?LAE~~7JFEF7~>FBDDBE?E=D;B:?:=;:=8?7B7D8F:~~6I:L:7~>:B<D>EAECD"
	    "EBF?F=E:C8A7>7<8::~~7IFBDDBE?E=D;B:?:=;:=8?7B7D8F:~~7JFLF7~>FBDD"
	    "BE?E=D;B:?:=;:=8?7B7D8F:~~7I:?F?FAECDDBE?E=D;B:?:=;:=8?7B7D8F:~~"
	    ";GELCLAK@H@7~>=EDE~~7JFEF5E2D1B0?0=1~>FBDDBE?E=D;B:?:=;:=8?7B7D8"
	    "F:~~7J;L;7~>;A>D@ECEEDFAF7~~<D?L@KAL@M?L~>@E@7~~;E@LAKBLAM@L~>AE"
	    "A4@1>0<0~~7H;L;7~>EE;;~>??F7~~<D@L@7~~3M7E77~>7A9D;E=E?D@A@7~>@A"
	    "BDDEFEHDIAI7~~7J;E;7~>;A>D@ECEEDFAF7~~7J?E=D;B:?:=;:=8?7B7D8F:G="
	    "G?FBDDBE?E~~6I:E:0~>:B<D>EAECDEBF?F=E:C8A7>7<8::~~7JFEF0~>FBDDBE"
	    "?E=D;B:?:=;:=8?7B7D8F:~~9F=E=7~>=?>B@DBEEE~~8IFBEDBE?E<D;B<@>?C>"
	    "E=F;F:E8B7?7<8;:~~;G@L@;A8C7E7~>=EDE~~7J;E;;<8>7A7C8F;~>FEF7~~8H"
	    ":E@7~>FE@7~~5K8E<7~>@E<7~>@ED7~>HED7~~8I;EF7~>FE;7~~8H:E@7~>FE@7"
	    ">3<1:090~~8IFE;7~>;EFE~>;7F7~~9GBP@O?N>L>J?H@GAEAC?A=@??A=A;@9?8"
	    ">6>4?2@1B0~~<D@P@0~~9G>P@OANBLBJAH@G?E?CAAC@A??=?;@9A8B6B4A2@1>0"
	    "~~4L7@8B:C<C>BB?D>F>H?IA~~3MGI97~>7CIC~>7=I=~~7JGJFLDLCKBIAD@??<"
	    ">:<8:787787:8;:;<:?8B7D7G8I:~><ADA~~3M@I?H@GAH@I~>7@I@~>@9?8@7A8"
	    "@9~~9G?L=K<I<G=E?DADCEDGDICKAL?L~~3M=E7@=;~>7@I@~~3MCEI@C;~>7@I@"
	    "~~4MJ?I=G<E<C=B>?B>C<D:D8C7A7?8=:<<<>=?>BBCCEDGDICJAJ?~~4L@H@7~>"
	    "8@H@~>87H7~~4L;N:M;L<M;N~>ENDMELFMEN~~/P2E7E@7PX~~3M7CICCH~>I=7="
	    "=8~~4L7C8E:F<F>EBBDAFAHBID~>7=I=~~4LII7CI=~>7;I;~~3M7EIE~>7@I@~>"
	    "7;I;~~4L7IIC7=~>7;I;~~8HDICKAL?L=K<I<G=EBBD@E>E<D:B8~>>D<B;@;><<"
	    ">:C7D5D3C1A0?0=1<3~~7I@L87~>@LH7~>;>E>~~5J9L97~>9LBLEKFJGHGFFDEC"
	    "BB~>9BBBEAF@G>G;F9E8B797~~5K9L97~>GLG7~>9BGB~~7I@L87~>@LH7~>87H7"
	    "~~6I:L:7~>:LGL~>:BBB~>:7G7~~6J@L@7~>>G;F:E9C9@:>;=><B<E=F>G@GCFE"
	    "EFBG>G~~6G:L:7~>:LFL~~6J9LG7~>97GL~~<D@L@7~~4LJNJOIPGPEOCMBKAH>8"
	    "=4<2;190706162~~5J9L97~>GL9>~>>CG7~~7I@L87~>@LH7~~4L8L87~>8L@7~>"
	    "HL@7~>HLH7~~5K9L97~>9LG7~>GLG7~~5K>L<K:I9G8D8?9<::<8>7B7D8F:G<H?"
	    "HDGGFIDKBL>L~~5K9L97~>GLG7~>9LGL~~5K>L<K:I9G8D8?9<::<8>7B7D8F:G<"
	    "H?HDGGFIDKBL>L~>=BCB~~5J9L97~>9LBLEKFJGHGEFCEBBA9A~~7I9L@B97~>9L"
	    "GL~>97G7~~8H@L@7~>9LGL~~7I9G9I:K;L=L>K?I@E@7~>GGGIFKELCLBKAI@E~~"
	    "7I87@JH7~>;>E>~>AICKCLAN?N=L=K?IAI~~6J97=7:>9B9F:I<K?LALDKFIGFGB"
	    "F>C7G7~~7I9LGL~>=BCB~>97G7~~5K@L@7~>7F8F9E:A;?<>?=A=D>E?FAGEHFIF"
	    "~~6JGL97~>9LGL~>97G7~~4L7NIN~~6K?E=D;B:@9=9::8<7>7@8C;E>GBHE~>?E"
	    "AEBDCBE:F8G7H7~~7JCLAK?I=E<B;>:890~>CLELGJGGFEEDCC@C~>@CBBD@E>E;"
	    "D9C8A7?7=8<9;<~~6J7A8C:E<E=D=B<>:7~><>>B@DBEDEFCF@E;B0~~7IBE?E=D"
	    ";B:?:<;9<8>7@7B8D:E=E@DCBE@G?I?K@LBLDKFI~~8HECDDBE?E=D=B>@A?~>A?"
	    "=>;<;:<8>7A7C8E:~~5K=D;C9A8>8;99:8<7?7B8E:G=H@HCFEDEBC@?>:;0~~7J"
	    "8B:D<E=E?D@CA@A<@7~>HEGBF@@7>3=0~~7I9E;E=CC2E0G0~>HEGCE@;59280~~"
	    ":E@E>>=:=8>7@7B9C;~~7IE=E@DCCDAE?E=D;B:?:<;9<8>7@7B8D:E=FBFGEJDK"
	    "BL@L>K<I~~7I=E97~>GDFEEECD?@=?<?~><?>>?=A8B7C7D8~~8H9L;L=K>JF7~>"
	    "@E:7~~6K=E70~><A;<;9=7?7A8C:E>~>GEE>D:D8E7G7I9J;~~7I:E=E<?;::7~>"
	    "GEFBE@C=@:=8:7~~8I@E>D<B;?;<<9=8?7A7C8E:F=F@ECDDBE@E~~5K>E:7~>CE"
	    "D?E:F7~>7B9D<EIE~~5J6A7C9E;E<D<B;=;:<8=7?7A8C;D=E@FEFHEKCLAL@J@H"
	    "AECBE@H>~~7I;?;<<9=8?7A7C8E:F=F@ECDDBE@E>D<B;?70~~7KIE?E=D;B:?:<"
	    ";9<8>7@7B8D:E=E@DCCDAE~~6JAE>7~>8B:D=EHE~~6J7A8C:E<E=D=B;<;9=7?7"
	    "B8D:F>GBGE~~6J979H:J;K>LBLEKFIFGEECD?CACDBF@G>G;F9E8B7>7;9~~4K<E"
	    ":D8A7>7;8897;7=8?;~>@??;@8A7C7E8G;H>HAGDFE~~8HBL@K?J?I@HCGFG~>CG"
	    "@F>E=C=A??B>D>~>B>>=<<;:;8=6A4B3B1@0>0~~4KDL<0~>5A6C8E:E;D;B:=::"
	    ";8=7?7B8D:F=HBIE~~8GBL@K?J?I@HCGFG~>FGBE?C<@;=;;<9>7A5B3B1A0?0>2"
	    "~~4L7C8E:F<F>EBBDAFAHBID~>7=8?:@<@>?B<D;F;H<I>~~>C@A@@A@AA@A~~" };

struct {
    integer e_1[256];
    } vgfpt_ = { 1, 39, 53, 65, 77, 91, 117, 131, 145, 165, 195, 217, 265, 
	    297, 323, 359, 395, 467, 523, 559, 595, 633, 5611, 0, 0, 0, 0, 0, 
	    0, 0, 0, 679, 763, 767, 787, 801, 827, 883, 949, 1021, 1029, 1053,
	     1077, 1097, 1111, 1131, 1139, 1153, 1161, 1199, 1211, 1243, 1277,
	     1293, 1331, 1381, 1395, 1457, 1507, 1533, 1565, 1575, 1589, 1599,
	     1643, 1731, 1751, 1801, 1841, 1875, 1901, 1921, 1969, 1989, 1997,
	     2021, 2041, 2055, 2081, 2101, 2147, 2177, 2229, 2265, 2309, 2323,
	     2347, 2361, 2387, 2401, 2417, 2437, 2449, 2457, 2469, 2483, 2491,
	     2499, 2537, 2575, 2607, 2645, 2683, 2703, 2751, 2775, 2795, 2821,
	     2841, 2849, 2889, 2913, 2951, 2989, 3027, 3047, 3085, 3105, 3129,
	     3143, 3169, 3183, 3205, 3225, 3271, 3279, 3325, 0, 1, 39, 53, 65,
	     77, 91, 117, 131, 145, 165, 195, 217, 265, 297, 323, 359, 395, 
	    467, 523, 559, 595, 633, 5611, 0, 0, 0, 0, 0, 0, 0, 0, 679, 0, 0, 
	    0, 3349, 3369, 3423, 0, 3455, 3485, 3501, 3517, 3571, 0, 0, 3591, 
	    3617, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3629, 3647, 3677, 3693, 3713, 
	    1599, 3729, 3791, 3811, 3861, 3881, 3901, 3927, 3971, 3985, 3999, 
	    4007, 4043, 4063, 4077, 4103, 4123, 4169, 4189, 4241, 4271, 4293, 
	    4307, 4347, 4383, 4419, 4439, 4477, 0, 2449, 0, 0, 4497, 2491, 
	    4505, 4555, 4619, 4659, 4709, 4749, 4793, 4829, 4859, 4879, 4933, 
	    4973, 4993, 5037, 5067, 5105, 5133, 5189, 5229, 5267, 5285, 5319, 
	    5367, 5415, 5475, 5517, 0, 3271, 0, 5565, 0 };

struct {
    logical e_1;
    integer e_2;
    } vgleg3_ = { TRUE_, 0 };

struct {
    real e_1[200];
    integer e_2[151];
    } vgtx1_ = { 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 1.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, .35f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 
	    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0 };

struct {
    logical e_1;
    integer e_2[3];
    logical e_3;
    } vgloop_ = { TRUE_, -1, 22, 0, FALSE_ };

struct {
    real e_1[2];
    integer e_2[2];
    } vgscrn_ = { 18.75f, 25.f, 0, 0 };

struct {
    char e_1[9];
    } vgfil1_ = { "VG    POS" };

struct {
    integer e_1;
    } vgfil2_ = { 1 };

struct {
    integer e_1;
    } vgcntr_ = { 1 };


/* Table of constant values */

static integer c__1 = 1;
static integer c__2 = 2;
static integer c__3 = 3;
static real c_b13 = 0.f;
static integer c__0 = 0;
static integer c__9 = 9;
static integer c__4 = 4;
static real c_b55 = 1.5f;
static integer c__5 = 5;
static real c_b60 = 1.f;
static real c_b64 = 90.f;
static real c_b69 = -90.f;
static integer c__6 = 6;
static real c_b100 = 1e-6f;
static integer c_n7 = -7;

/* INITIALIZES THE COMMON BLOCKS USED BY VG */
/*      DATA BLEFT0(1),BRIT0(1),BBOT0(1),BTOP0(1)/0.,25.,0.,18.75/ */
/*      DATA BBOT0(1),BTOP0(1),BLEFT0(1),BRIT0(1)/0.,18.75,0.,25./ */
/*      DATA SX(1),SY(1),SA(1),SH(1),SC(1),SO(1)/0.0,1.0,0.0,0.35,1,1/ */
/*      DATA SM(1)/1/ */

/*       Force exit character to be nonzero unless set by user. */
/*       DKK (28 Feb 1989) */

/* ***********************************************************************
 */
/*     INITIALIZE CHARACTER FONT FROM THE HERSHEY FONTS */
/*     URSULA KATTNER, NBS, 6 OCTOBER 1987  -  VERSION 1.0 */
/*     MODIFIED BY G. CANDELA & D. KAHANER */
/* ***********************************************************************
 */







/* Subroutine */ int newpag_0_(int n__, integer *n, real *x, real *y, integer 
	*ixlog, integer *iylog, integer *ihcode, integer *ivcode, integer *
	ixcol, char *text, real *atx, real *aty, real *angle, real *h__, 
	integer *ncolr, integer *mode, integer *isym, integer *idsty, integer 
	*idcol, integer *ixtk1, integer *ixtk2, integer *iytk1, integer *
	iytk2, char *clegst, real *xpos, real *ypos, integer *isx, integer *
	isy1, integer *isy2, integer *nx, integer *ny1, integer *ny2, real *
	atop, real *abot, real *alef, real *arit, real *scale, char *dname, 
	integer *ifid, integer *iz, integer *jncsym, integer *iaxis, integer *
	itype, real *amin, real *amax, integer *ixch, char *tstr, integer *
	itclr, char *bstr, integer *ibclr, char *lstr, integer *ilclr, char *
	rstr, integer *irclr, ftnlen text_len, ftnlen clegst_len, ftnlen 
	dname_len, ftnlen tstr_len, ftnlen bstr_len, ftnlen lstr_len, ftnlen 
	rstr_len)
{
    /* Initialized data */

    static integer new__[2] = { 1,1 };
    static integer jfid = 0;
    static integer jz = 0;
    static logical yesax[2] = { TRUE_,TRUE_ };
    static integer jside = 1;
    static real widmax = 0.f;
    static real bashgt = .35f;
    static integer incsym = 1;
    static integer jsym = 1;
    static integer jdcol = 1;
    static integer jdsty = 1;
    static integer jhcode = 0;
    static integer jvcode = 0;

    /* System generated locals */
    integer i__1;
    real r__1, r__2;

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer pow_ii(integer *, integer *), s_cmp(char *, char *, ftnlen, 
	    ftnlen);

    /* Local variables */
    static integer llen, icov;
    extern /* Subroutine */ int vgpl_(real *, real *, integer *);
    extern doublereal vgg2s_(real *, real *, real *, real *, real *, integer *
	    , integer *, integer *);
    static integer i__, j, imode;
    extern /* Subroutine */ int vgbnd_(integer *, integer *, real *, real *, 
	    real *, integer *, integer *, integer *), vgadr_(real *, real *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    real *, real *, real *, real *, integer *, real *), vgtic_(
	    integer *, integer *, real *, real *, integer *, integer *, 
	    integer *, integer *, logical *), vgldr_(integer *, char *, 
	    integer *, integer *, integer *, real *, real *, real *, real *, 
	    real *, real *, ftnlen);
    static real covlef, covbot;
    extern /* Subroutine */ int vgcmnt_(char *, ftnlen), vgletr_(integer *, 
	    logical *);
    static integer numlin;
    static real covrit, tx, ty;
    extern /* Subroutine */ int vgadtx_(char *, real *, real *, real *, real *
	    , integer *, integer *, integer *, ftnlen);
    static real covtop;
    extern /* Subroutine */ int vgcent_(char *, real *, real *, real *, real *
	    , real *, real *, real *, real *, integer *, integer *, ftnlen);
    extern integer vgistr_(char *, ftnlen);
    extern /* Subroutine */ int vgmeas_(char *, integer *, real *, real *, 
	    real *, ftnlen);
    static real hgtlgd, widlgd, offset;
    extern /* Subroutine */ int vga2_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, logical *);

/*            INITIALIZE NEXT PAGE, PART OF VG */
/*      EXTERNAL FINIT,VGLOAD */
    /* Parameter adjustments */
    if (x) {
	--x;
	}
    if (y) {
	--y;
	}

    /* Function Body */
    switch(n__) {
	case 1: goto L_vg;
	case 2: goto L_curv;
	case 3: goto L_vgaxlg;
	case 4: goto L_axcode;
	case 5: goto L_gtex;
	case 6: goto L_howplt;
	case 7: goto L_ticsiz;
	case 8: goto L_htex;
	case 9: goto L_legnd;
	case 10: goto L_legpos;
	case 11: goto L_linlog;
	case 12: goto L_noaxes;
	case 13: goto L_noaxex;
	case 14: goto L_noaxey;
	case 15: goto L_nolbox;
	case 16: goto L_nonum;
	case 17: goto L_plac;
	case 18: goto L_right;
	case 19: goto L_scalup;
	case 20: goto L_setdv;
	case 21: goto L_setfil;
	case 22: goto L_setgrd;
	case 23: goto L_setinc;
	case 24: goto L_setlim;
	case 25: goto L_setxit;
	case 26: goto L_sidtex;
	}


    vgbt_1.baton = FALSE_;
    vgloop_1.pass1 = TRUE_;
    vgloop_1.istat = 0;
    for (i__ = 1; i__ <= 6; ++i__) {
	vglim_1.msx[i__ - 1] = 0;
	vglim_1.msy[i__ - 1] = 0;
	vglim_1.msy[i__ + 6] = 0;
	vgleg1_1.isleg[i__ - 1] = 0;
	vgleg1_1.legset[i__ - 1] = 0;
	vgleg1_1.nlines[i__ - 1] = 0;
	vgtic1_1.nh[i__ - 1] = 0;
	vgtic1_1.nv1[i__ - 1] = 0;
	vgtic1_1.nv2[i__ - 1] = 0;
	vglttr_1.kludge[i__ - 1] = 0;
	vgzoom_1.ipoint[i__ - 1] = 0;
	vgtick_1.tikx1[i__ - 1] = .35f;
	vgtick_1.tikx2[i__ - 1] = .35f;
	vgtick_1.tiky1[i__ - 1] = .35f;
	vgtick_1.tiky2[i__ - 1] = .35f;
	for (j = 1; j <= 3; ++j) {
	    vgsbnd_1.limflg[i__ + j * 7 - 8] = 0;
	    vgtic1_1.yestic[i__ + j * 7 - 8] = FALSE_;
/* L300: */
	}
/* L325: */
    }
    for (i__ = 1; i__ <= 4; ++i__) {
	for (j = 1; j <= 7; ++j) {
	    vglab_1.labels[j + i__ * 7 - 8] = 0;
/* L340: */
	}
/* L330: */
    }
    vgtx1_1.ntex = 0;
    vgtx1_1.sx[0] = 0.f;
    vgtx1_1.sy[0] = 1.f;
    vgtx1_1.sa[0] = 0.f;
    vgtx1_1.sh[0] = .35f;
    vgtx1_1.sm[0] = 1;
    vgtx1_1.so[0] = 0;
    vghgt_1.height = bashgt;
    vgcntr_1.ig = 0;
/*  999 IS THE BEGINNING OF NEWGRF */
    goto L999;

L_vg:
/*  A GRAPHING ROUTINE. GENERAL ENTRY POINT FOR FINAL CALL */
    if (vgcntr_1.ig > 6) {
	return 0;
    }
/*  CALCULATE NUMBER OF TICK MARKS ON EACH AXIS */
/*  X-AXIS */
    vgtic_(&vglim_1.msx[vgcntr_1.ig - 1], &vgtic1_1.nh[vgcntr_1.ig - 1], &
	    vglim_1.bxmin[vgcntr_1.ig - 1], &vglim_1.bxmax[vgcntr_1.ig - 1], &
	    vglim_1.ninlx[vgcntr_1.ig - 1], &vglim_1.naxlx[vgcntr_1.ig - 1], &
	    c__1, &vglttr_1.isdx[vgcntr_1.ig - 1], &vgloop_1.pass1);
/*  LEFT Y-AXIS */
    vgtic_(&vglim_1.msy[vgcntr_1.ig - 1], &vgtic1_1.nv1[vgcntr_1.ig - 1], &
	    vglim_1.bymin[vgcntr_1.ig - 1], &vglim_1.bymax[vgcntr_1.ig - 1], &
	    vglim_1.ninly[vgcntr_1.ig - 1], &vglim_1.naxly[vgcntr_1.ig - 1], &
	    c__2, &vglttr_1.isdy1[vgcntr_1.ig - 1], &vgloop_1.pass1);
/*  RIGHT Y-AXIS */
    if (jvcode == 3) {
	vgtic_(&vglim_1.msy[vgcntr_1.ig + 6], &vgtic1_1.nv2[vgcntr_1.ig - 1], 
		&vglim_1.bymin[vgcntr_1.ig + 6], &vglim_1.bymax[vgcntr_1.ig + 
		6], &vglim_1.ninly[vgcntr_1.ig + 6], &vglim_1.naxly[
		vgcntr_1.ig + 6], &c__3, &vglttr_1.isdy2[vgcntr_1.ig - 1], &
		vgloop_1.pass1);
    }
/*  DRAW NUMBERS AND AXIS LABELS: */
    vgletr_(&vgcntr_1.ig, &vgloop_1.pass1);
    if (vgloop_1.pass1) {
	if (vgleg1_1.isleg[vgcntr_1.ig - 1] == 1 && vgleg1_1.legset[
		vgcntr_1.ig - 1] == 0) {
	    vgleg1_1.xleg[vgcntr_1.ig - 1] = (vglttr_1.bleft0[vgcntr_1.ig - 1]
		     + vglttr_1.brit0[vgcntr_1.ig - 1]) * .5f;
	    vgleg1_1.yleg[vgcntr_1.ig - 1] = (vglttr_1.bbot0[vgcntr_1.ig - 1] 
		    + vglttr_1.btop0[vgcntr_1.ig - 1]) * .5f;
	}
    } else {
/*  ELSE AT LEAST ONE PASS HAS BEEN MADE */
	vgcmnt_("Drawing...", 10L);
/*  DRAW AXES, TICKS, FIDUCIAL MARKS: */
	vga2_(&jfid, &jz, &jhcode, &jvcode, &vgtic1_1.nh[vgcntr_1.ig - 1], &
		vgtic1_1.nv1[vgcntr_1.ig - 1], &vgtic1_1.nv2[vgcntr_1.ig - 1],
		 &vglttr_1.axcol, yesax);
	if (vgleg1_1.isleg[vgcntr_1.ig - 1] == 1 && vgleg1_1.legvis[
		vgcntr_1.ig - 1] == 1) {
/*  DRAW LEGEND: */
	    vgldr_(&vgleg1_1.nlines[vgcntr_1.ig - 1], vgleg2_1.clegs + (
		    vgcntr_1.ig * 14 - 14) * 40, &vgleg1_1.lsyms[vgcntr_1.ig *
		     14 - 14], &vgleg1_1.lcolrs[vgcntr_1.ig * 14 - 14], &
		    vgleg1_1.lstys[vgcntr_1.ig * 14 - 14], &vgleg1_1.xleg[
		    vgcntr_1.ig - 1], &vgleg1_1.yleg[vgcntr_1.ig - 1], &
		    vgleg1_1.hh[vgcntr_1.ig - 1], &vgleg1_1.vv[vgcntr_1.ig - 
		    1], &vgleg4_1.offstl[vgcntr_1.ig - 1], &vghgt_1.height, 
		    40L);
	}
	vgcmnt_(" ", 1L);
    }
/*  999 IS AT THE BEGINNING OF NEWGRF */
    goto L999;

L_curv:
/*  SUBROUTINE TO ANALYSE AND PLOT DATA. PART OF VG */
    if (vgcntr_1.ig > 6) {
	return 0;
    }
    if (vgloop_1.pass1) {
	vgbnd_(&vgsbnd_1.limflg[vgcntr_1.ig - 1], &new__[jside - 1], &x[1], &
		vglim_1.bxmin[vgcntr_1.ig - 1], &vglim_1.bxmax[vgcntr_1.ig - 
		1], &vglim_1.ninlx[vgcntr_1.ig - 1], &vglim_1.naxlx[
		vgcntr_1.ig - 1], n);
	vgbnd_(&vgsbnd_1.limflg[vgcntr_1.ig + (jside + 1) * 7 - 8], &new__[
		jside - 1], &y[1], &vglim_1.bymin[vgcntr_1.ig + jside * 7 - 8]
		, &vglim_1.bymax[vgcntr_1.ig + jside * 7 - 8], &vglim_1.ninly[
		vgcntr_1.ig + jside * 7 - 8], &vglim_1.naxly[vgcntr_1.ig + 
		jside * 7 - 8], n);
	if (new__[jside - 1] == 1) {
	    new__[jside - 1] = 0;
	}
	if (vgleg3_1.leglin >= 1) {
	    numlin = vgleg1_1.nlines[vgcntr_1.ig - 1];
	    vgleg1_1.lsyms[numlin + 1 - vgleg3_1.leglin + vgcntr_1.ig * 14 - 
		    15] = jsym;
	    vgleg1_1.lcolrs[numlin + 1 - vgleg3_1.leglin + vgcntr_1.ig * 14 - 
		    15] = jdcol;
	    vgleg1_1.lstys[numlin + 1 - vgleg3_1.leglin + vgcntr_1.ig * 14 - 
		    15] = jdsty;
	    i__1 = vgleg3_1.leglin - 1;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		vgleg1_1.lsyms[numlin + 1 - i__ + vgcntr_1.ig * 14 - 15] = 0;
		vgleg1_1.lcolrs[numlin + 1 - i__ + vgcntr_1.ig * 14 - 15] = 
			jdcol;
		vgleg1_1.lstys[numlin + 1 - i__ + vgcntr_1.ig * 14 - 15] = 0;
/* L5: */
	    }
	    vgleg3_1.leglin = 0;
	}
    } else {
/*        CALL VGCMNT('Drawing...') */
/*  DRAW THE DATA POINTS AND CONNECTING LINES: */
	icov = 0;
	if (vgleg1_1.isleg[vgcntr_1.ig - 1] == 1 && vgleg1_1.legvis[
		vgcntr_1.ig - 1] == 1) {
	    covlef = vgleg1_1.xleg[vgcntr_1.ig - 1] - vgleg1_1.hh[vgcntr_1.ig 
		    - 1] * .5f;
	    covrit = vgleg1_1.xleg[vgcntr_1.ig - 1] + vgleg1_1.hh[vgcntr_1.ig 
		    - 1] * .5f;
	    covbot = vgleg1_1.yleg[vgcntr_1.ig - 1] - vgleg1_1.vv[vgcntr_1.ig 
		    - 1] * .5f;
	    covtop = vgleg1_1.yleg[vgcntr_1.ig - 1] + vgleg1_1.vv[vgcntr_1.ig 
		    - 1] * .5f;
	    icov = 1;
	}
	vgadr_(&x[1], &y[1], n, &jdsty, &jdcol, &jsym, &jside, &icov, &covlef,
		 &covrit, &covbot, &covtop, &incsym, &vghgt_1.height);
	vgpl_(&c_b13, &c_b13, &c__3);
/*        CALL VGCMNT('Drawing...') */
    }
    if (vgcrv1_1.idmark == 0) {
/*  USER DIDN'T SPECIFY HOW TO PLOT LINE */
	++jsym;
	++jdsty;
	if (jsym > 23) {
	    jsym = 1;
	}
	if (jdsty > 11) {
	    jdsty = 1;
	    ++jdcol;
	    if (jdcol > 16) {
		jdcol = 1;
	    }
	}
    }
    vgcrv1_1.idmark = 0;
    jside = 1;
    return 0;
/*       PASSES BACK INFORMATION ON WHETHER AXES ARE LINEAR OR LOG */

L_vgaxlg:
/*              ORIGINAL NAME AXLG */
    *ixlog = vglim_1.msx[vgcntr_1.ig - 1];
    *iylog = vglim_1.msy[vgcntr_1.ig + jside * 7 - 8];
    return 0;
/*       -       -       -       -       -       -       -       - */

L_axcode:
/*  SET AXIS-DRAWING OPTIONS. */
    if (*ihcode < 0 || *ihcode > 2 || *ivcode < 0 || *ivcode > 3 || *ixcol < 
	    0 || *ixcol > 16) {
	return 0;
    }
    jhcode = *ihcode;
    jvcode = *ivcode;
    vglttr_1.axcol = *ixcol;
    if (vgloop_1.pass1) {
	vglttr_1.kludge[vgcntr_1.ig - 1] = vglttr_1.kludge[vgcntr_1.ig - 1] + 
		(*ihcode << 7) + (*ivcode << 5);
    }
    return 0;

L_gtex:
/*  ADD A TEXT STRING TO A GRAPH */
    if (vgloop_1.pass2) {
	if (*mode == 2) {
/*  COORDINATES ARE IN GRAPH COORDS */
	    tx = (real)vgg2s_(atx, &vglim_1.bleft1[vgcntr_1.ig - 1], &
		    vglim_1.brit1[vgcntr_1.ig - 1], &vglim_1.bxmin[
		    vgcntr_1.ig - 1], &vglim_1.bxmax[vgcntr_1.ig - 1], &
		    vglim_1.ninlx[vgcntr_1.ig - 1], &vglim_1.naxlx[
		    vgcntr_1.ig - 1], &vglim_1.msx[vgcntr_1.ig - 1]);
	    ty = (real)vgg2s_(aty, &vglim_1.bbot1[vgcntr_1.ig - 1], &
		    vglim_1.btop1[vgcntr_1.ig - 1], &vglim_1.bymin[
		    vgcntr_1.ig + jside * 7 - 8], &vglim_1.bymax[vgcntr_1.ig 
		    + jside * 7 - 8], &vglim_1.ninly[vgcntr_1.ig + jside * 7 
		    - 8], &vglim_1.naxly[vgcntr_1.ig + jside * 7 - 8], &
		    vglim_1.msy[vgcntr_1.ig + jside * 7 - 8]);
/*       ELSE */
/*         TX=ATX*SWD+BLEFT1(IG) */
/*         TY=ATY*SHT+BBOT1(IG) */
/*       ENDIF */
/* WEA 11/89 ADDED THE FOLLOWING SO ALL GTEX MODES WORK */
	} else if (*mode == 3) {
	    tx = *atx * vgscrn_1.swd + vglim_1.bleft1[vgcntr_1.ig - 1];
	    ty = *aty * vgscrn_1.sht + vglim_1.bbot1[vgcntr_1.ig - 1];
	} else if (*mode == 4) {
	    tx = *atx * vgscrn_1.swd + vglim_1.bleft1[vgcntr_1.ig - 1];
	    ty = *aty * vgscrn_1.sht + vglim_1.bbot1[vgcntr_1.ig - 1];
	} else if (*mode == 5) {
	    tx = *atx * vgscrn_1.swd + vglim_1.bleft1[vgcntr_1.ig - 1];
	    ty = *aty * vgscrn_1.sht + vglim_1.btop1[vgcntr_1.ig - 1];
	} else if (*mode == 6) {
	    tx = *atx * vgscrn_1.swd + vglim_1.brit1[vgcntr_1.ig - 1];
	    ty = *aty * vgscrn_1.sht + vglim_1.btop1[vgcntr_1.ig - 1];
	} else {
	    tx = *atx * vgscrn_1.swd + vglim_1.bleft1[vgcntr_1.ig - 1];
	    ty = *aty * vgscrn_1.sht + vglim_1.bbot1[vgcntr_1.ig - 1];
	}
	vgadtx_(text, &tx, &ty, angle, h__, ncolr, mode, &vgcntr_1.ig, 
		text_len);
    }
    return 0;

L_howplt:
/*  SPECIFY PLOTTING SYMBOL, DASH STYLE, AND COLOR (THICKNESS). */
    if (*isym < 0 || *isym > 23 || *idsty < 0 || *idsty > 11 || *idcol > 16) {
	return 0;
    }
/*    *.OR.IDCOL.LT.1.OR.IDCOL.GT.16)RETURN */
    vgcrv1_1.idmark = 1;
    jsym = *isym;
    jdsty = *idsty;
    if (*idcol > 0) {
	jdcol = *idcol;
    }
    return 0;

L_ticsiz:
/* WEA 12/31/89 ADDED CODE TO GIVE USER CONTROL OVER TICK SIZE */
    if ((real) (*ixtk1) < 0.f || (real) (*ixtk1) > 100.f) {
	*ixtk1 = 10;
    }
    if ((real) (*ixtk2) < 0.f || (real) (*ixtk2) > 100.f) {
	*ixtk2 = 10;
    }
    if ((real) (*iytk1) < 0.f || (real) (*iytk1) > 100.f) {
	*iytk1 = 10;
    }
    if ((real) (*iytk2) < 0.f || (real) (*iytk2) > 100.f) {
	*iytk2 = 10;
    }
    vgtick_1.tikx1[vgcntr_1.ig - 1] = *ixtk1 * .035f;
    vgtick_1.tikx2[vgcntr_1.ig - 1] = *ixtk2 * .035f;
    vgtick_1.tiky1[vgcntr_1.ig - 1] = *iytk1 * .035f;
    vgtick_1.tiky2[vgcntr_1.ig - 1] = *iytk2 * .035f;
    return 0;

L_htex:
/*  ENTER A MOVABLE TEXT STRING (H IS LETTER SCALE). */
    if (vgloop_1.pass1) {
	tx = *atx * vgscrn_1.swd;
	ty = *aty * vgscrn_1.sht;
	imode = 1;
/*  TRAP THE ERROR OF NEGATIVE COORDS BY CENTERING THE TEXT */
	if (*atx < 0.f) {
	    r__1 = vghgt_1.height * *h__;
	    vgcent_(text, &tx, &ty, angle, &r__1, &c_b13, &c_b13, &c_b13, &
		    vgscrn_1.swd, &c__1, &c__0, text_len);
	    imode = 3;
	}
	if (*aty < 0.f) {
	    r__1 = vghgt_1.height * *h__;
	    vgcent_(text, &tx, &ty, angle, &r__1, &vgscrn_1.sht, &c_b13, &
		    c_b13, &c_b13, &c__0, &c__1, text_len);
	    if (imode == 3) {
		imode = 1;
	    } else {
		imode = 4;
	    }
	}
	vgadtx_(text, &tx, &ty, angle, h__, ncolr, &imode, &c__0, text_len);
    }
    return 0;

L_legnd:
/*      SAVE WIDMAX */
/*  ENTER A TEXT LINE FOR A LEGEND (I.E. DESCRIPTION OF A DATA CURVE). */
    if (! vgloop_1.pass1 || vgcntr_1.ig > 6 || vgleg1_1.nlines[vgcntr_1.ig - 
	    1] > 14) {
	return 0;
    }
    ++vgleg3_1.leglin;
    ++vgleg1_1.nlines[vgcntr_1.ig - 1];
    s_copy(vgleg2_1.clegs + (vgleg1_1.nlines[vgcntr_1.ig - 1] + vgcntr_1.ig * 
	    14 - 15) * 40, clegst, 40L, clegst_len);
    vgmeas_(clegst, &llen, &hgtlgd, &widlgd, &vghgt_1.height, clegst_len);
    widmax = dmax(widmax,widlgd);
    if (jdsty == 0) {
	offset = 3.f;
    } else {
	offset = 9.f;
    }
    if (vglttr_1.kludge[vgcntr_1.ig - 1] / pow_ii(&c__2, &c__9) % 2 == 1) {
	offset = 1.f;
	vgleg1_1.hh[vgcntr_1.ig - 1] -= (vgleg4_1.offstl[vgcntr_1.ig - 1] - 
		1.f) * vghgt_1.height;
	vgleg4_1.offstl[vgcntr_1.ig - 1] = 1.f;
    }
    if (vgleg1_1.isleg[vgcntr_1.ig - 1] == 0) {
	vgleg1_1.hh[vgcntr_1.ig - 1] = widmax + offset * vghgt_1.height;
	vgleg1_1.vv[vgcntr_1.ig - 1] = vghgt_1.height * 2;
	vgleg4_1.offstl[vgcntr_1.ig - 1] = offset;
    } else {
/* Moved this line to correct problem with howplt(ix,0,iy) */
/* Computing MAX */
	r__1 = vgleg4_1.offstl[vgcntr_1.ig - 1];
	vgleg4_1.offstl[vgcntr_1.ig - 1] = dmax(r__1,offset);
/* Computing MAX */
	r__1 = vgleg1_1.hh[vgcntr_1.ig - 1], r__2 = widmax + vgleg4_1.offstl[
		vgcntr_1.ig - 1] * vghgt_1.height;
	vgleg1_1.hh[vgcntr_1.ig - 1] = dmax(r__1,r__2);
	vgleg1_1.vv[vgcntr_1.ig - 1] += vghgt_1.height * 1.5f;
/*       OFFSTL(IG)=MAX(OFFSTL(IG),OFFSET) */
    }
    vgleg1_1.isleg[vgcntr_1.ig - 1] = 1;
    return 0;

L_legpos:
/*  SET LOCATION FOR A LEGEND */
    if (! vgloop_1.pass1) {
	return 0;
    }
    if (*xpos < 0.f || *xpos > 1.f || *ypos < 0.f || *ypos > 1.f) {
	return 0;
    }
    vgleg1_1.legset[vgcntr_1.ig - 1] = 1;
    vgleg1_1.xleg[vgcntr_1.ig - 1] = *xpos * vgscrn_1.swd;
    vgleg1_1.yleg[vgcntr_1.ig - 1] = *ypos * vgscrn_1.sht;
    return 0;

L_linlog:
/*  SET LINEAR OR LOG AXES. */
    if (vgloop_1.pass1) {
	if (*isx == 0 || *isx == 1) {
	    vglim_1.msx[vgcntr_1.ig - 1] = *isx;
	}
	if (*isy1 == 0 || *isy1 == 1) {
	    vglim_1.msy[vgcntr_1.ig - 1] = *isy1;
	}
	if (*isy2 == 0 || *isy2 == 1) {
	    vglim_1.msy[vgcntr_1.ig + 6] = *isy2;
	}
    }
    return 0;

L_noaxes:
/*  FOR NO AXES ALONG GRAPH SIDES. */
    yesax[0] = FALSE_;
    yesax[1] = FALSE_;
    return 0;

L_noaxex:
/*  FOR NO AXIS ALONG GRAPH'S X AXIS */
    yesax[0] = FALSE_;
    return 0;

L_noaxey:
/*  FOR NO AXIS ALONG GRAPH'S Y AXIS */
    yesax[1] = FALSE_;
    return 0;

L_nolbox:
/* TURNS OFF BOX (FRAME) AROUND LEGEND */
    vgleg3_1.lbox = FALSE_;
    return 0;

L_nonum:
/*  FOR NO NUMBERS ALONG GRAPH EDGES. */
    if (vgloop_1.pass1) {
	if (vglttr_1.kludge[vgcntr_1.ig - 1] / pow_ii(&c__2, &c__4) % 2 == 0) 
		{
	    vglttr_1.kludge[vgcntr_1.ig - 1] += *nx << 4;
	}
	if (vglttr_1.kludge[vgcntr_1.ig - 1] / pow_ii(&c__2, &c__3) % 2 == 0) 
		{
	    vglttr_1.kludge[vgcntr_1.ig - 1] += *ny1 << 3;
	}
	if (vglttr_1.kludge[vgcntr_1.ig - 1] / pow_ii(&c__2, &c__2) % 2 == 0) 
		{
	    vglttr_1.kludge[vgcntr_1.ig - 1] += *ny2 << 2;
	}
    }
    return 0;

L_plac:
/*  ENTER POSITON OF GRAPH ON SCREEN. */
    if (vgloop_1.pass1) {
	if (*abot < 0.f || *abot >= *atop || *atop > 1.f || *alef < 0.f || *
		alef >= *arit || *arit > 1.f) {
	    return 0;
	}
	vglttr_1.bleft0[vgcntr_1.ig - 1] = *alef * vgscrn_1.swd;
	vglttr_1.brit0[vgcntr_1.ig - 1] = *arit * vgscrn_1.swd;
	vglttr_1.bbot0[vgcntr_1.ig - 1] = *abot * vgscrn_1.sht;
	vglttr_1.btop0[vgcntr_1.ig - 1] = *atop * vgscrn_1.sht;
    }
    return 0;

L_right:
/*  THE NEXT DATA SET IS TO BE PLOTTED AGAINS THE RIGHT VERTICAL AXIS. */
    jside = 2;
    return 0;

L_scalup:
    vghgt_1.height = bashgt * *scale;
    return 0;

L_setdv:
/*  SET HIGHER QUALITY SYNTAX OTHER THAN POSTSCRIPT. */
    if (vgloop_1.pass1) {
	s_copy(vgfil1_1.exten, "   ", 3L, 3L);
	if (s_cmp(dname, "tek", 3L, 3L) == 0 || s_cmp(dname, "TEK", 3L, 3L) ==
		 0) {
	    vgloop_1.mdevic = 0;
	} else if (s_cmp(dname, "hpg", 3L, 3L) == 0 || s_cmp(dname, "HPG", 3L,
		 3L) == 0) {
	    vgloop_1.mdevic = 20;
	} else if (s_cmp(dname, "qms", 3L, 3L) == 0 || s_cmp(dname, "QMS", 3L,
		 3L) == 0) {
	    vgloop_1.mdevic = 21;
	} else if (s_cmp(dname, "pos", 3L, 3L) == 0 || s_cmp(dname, "POS", 3L,
		 3L) == 0) {
	    vgloop_1.mdevic = 22;
	} else if (s_cmp(dname, "ljt", 3L, 3L) == 0 || s_cmp(dname, "LJT", 3L,
		 3L) == 0) {
	    vgloop_1.mdevic = 23;
	} else if (s_cmp(dname, "psq", 3L, 3L) == 0 || s_cmp(dname, "PSQ", 3L,
		 3L) == 0) {
	    vgloop_1.mdevic = 24;
	}
	s_copy(vgfil1_1.exten, dname, 3L, 3L);
    }
    return 0;

L_setfil:
/*  SET FILE NAME FOR BATCH OUTPUT FILE */
    if (vgloop_1.pass1 && vgistr_(dname, dname_len) > 0) {
	s_copy(vgfil1_1.filnam, dname, 6L, dname_len);
    }
    return 0;

L_setgrd:
/*  CHOOSE GRID POINT AND ZERO AXIS OPTIONS */
    if (! vgloop_1.pass1) {
	if (*ifid == 0 || *ifid == 1) {
	    jfid = *ifid;
	}
/*(15 SEPT 1988 (DKK) REMOVED AND ADDED LINE BELOW)  IF(IZ.EQ.0.OR.IZ.
EQ.1)JZ=IZ*/
	if (*iz == 0 || *iz == 1 || *iz == 2) {
	    jz = *iz;
	}
    }
    return 0;

L_setinc:
/*  SET INCREMENT BETWEEN GRAPHING SYMBOLS (IF IT IS NOT 1). */
    if (! vgloop_1.pass1) {
	incsym = *jncsym;
    }
    return 0;

L_setlim:
/*  SET AXIS LIMITS */
    if (vgloop_1.pass1) {
	vgsbnd_1.limflg[vgcntr_1.ig + *iaxis * 7 - 8] = *itype;
	if (*itype / pow_ii(&c__2, &c__0) % 2 == 1) {
	    if (*iaxis == 1) {
		vglim_1.bxmin[vgcntr_1.ig - 1] = *amin;
	    } else if (*iaxis == 2) {
		vglim_1.bymin[vgcntr_1.ig - 1] = *amin;
	    } else if (*iaxis == 3) {
		vglim_1.bymin[vgcntr_1.ig + 6] = *amin;
	    }
	}
	if (*itype / pow_ii(&c__2, &c__1) % 2 == 1) {
	    if (*iaxis == 1) {
		vglim_1.bxmax[vgcntr_1.ig - 1] = *amax;
	    } else if (*iaxis == 2) {
		vglim_1.bymax[vgcntr_1.ig - 1] = *amax;
	    } else if (*iaxis == 3) {
		vglim_1.bymax[vgcntr_1.ig + 6] = *amax;
	    }
	}
    }
    return 0;

L_setxit:
/*  DEFINE ADDITIONAL CHARACTER THAT WILL END ILOOP */
    vgloop_1.jexit = *ixch;
    return 0;

L_sidtex:
/*  ENTER TEXT TO BE CENTERED ALONG GRAPH EDGES. */
    if (vgloop_1.pass1) {
	if (vgistr_(tstr, tstr_len) > 0) {
	    vgadtx_(tstr, &c_b13, &c_b13, &c_b13, &c_b55, itclr, &c__5, &
		    vgcntr_1.ig, tstr_len);
	    vglab_1.labels[vgcntr_1.ig + 20] = vgtx1_1.ntex;
	}
	if (vgistr_(bstr, bstr_len) > 0) {
	    vgadtx_(bstr, &c_b13, &c_b13, &c_b13, &c_b60, ibclr, &c__3, &
		    vgcntr_1.ig, bstr_len);
	    vglab_1.labels[vgcntr_1.ig - 1] = vgtx1_1.ntex;
	}
	if (vgistr_(lstr, lstr_len) > 0) {
	    vgadtx_(lstr, &c_b13, &c_b13, &c_b64, &c_b60, ilclr, &c__4, &
		    vgcntr_1.ig, lstr_len);
	    vglab_1.labels[vgcntr_1.ig + 6] = vgtx1_1.ntex;
	}
	if (vgistr_(rstr, rstr_len) > 0) {
	    vgadtx_(rstr, &c_b13, &c_b13, &c_b69, &c_b60, irclr, &c__6, &
		    vgcntr_1.ig, rstr_len);
	    vglab_1.labels[vgcntr_1.ig + 13] = vgtx1_1.ntex;
	}
    }
    return 0;
/* CCC      ENTRY NEWGRF */
/* CCC        ADDED LABEL 999 HERE (dkk) sept 22 1988 */
L999:
    if (vgcntr_1.ig < 7) {
	++vgcntr_1.ig;
    }
    if (vgloop_1.pass1) {
	offset = (real) (vgcntr_1.ig - 1);
	vglttr_1.bleft0[vgcntr_1.ig - 1] = offset;
	vglttr_1.brit0[vgcntr_1.ig - 1] = 25.f - offset;
	vglttr_1.bbot0[vgcntr_1.ig - 1] = offset;
	vglttr_1.btop0[vgcntr_1.ig - 1] = 18.75f - offset;
    }
    jhcode = 0;
    jvcode = 0;
    jfid = 0;
    jz = 0;
    yesax[0] = TRUE_;
    yesax[1] = TRUE_;
    vgleg3_1.lbox = TRUE_;
    incsym = 1;
    new__[0] = 1;
    new__[1] = 1;
    jsym = 1;
    jdsty = 1;
    jdcol = 1;
    vglttr_1.axcol = 1;
    return 0;
} /* newpag_ */

/* Subroutine */ int newpag_(void)
{
    return newpag_0_(0, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int vg_(void)
{
    return newpag_0_(1, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int curv_(integer *n, real *x, real *y)
{
    return newpag_0_(2, n, x, y, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (char *)0, (real *)0, (real *)0, (real 
	    *)0, (real *)0, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (char *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (real *)0, (real *)0, (real *)0, (real *)0, (real *)0, (char *)
	    0, (integer *)0, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (real *)0, (real *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)
	    0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int vgaxlg_(integer *ixlog, integer *iylog)
{
    return newpag_0_(3, (integer *)0, (real *)0, (real *)0, ixlog, iylog, (
	    integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0, (
	    real *)0, (real *)0, (real *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (char *)0, (real *)0, (real *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (real *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (char *)0, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (ftnint)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int axcode_(integer *ihcode, integer *ivcode, integer *ixcol)
{
    return newpag_0_(4, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, ihcode, ivcode, ixcol, (char *)0, (real *)0, (real *)
	    0, (real *)0, (real *)0, (integer *)0, (integer *)0, (integer *)0,
	     (integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer 
	    *)0, (integer *)0, (char *)0, (real *)0, (real *)0, (integer *)0, 
	    (integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *
	    )0, (real *)0, (real *)0, (real *)0, (real *)0, (real *)0, (char *
	    )0, (integer *)0, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (real *)0, (real *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)
	    0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int gtex_(char *text, real *atx, real *aty, real *angle, 
	real *h__, integer *ncolr, integer *mode, ftnlen text_len)
{
    return newpag_0_(5, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, text, atx, 
	    aty, angle, h__, ncolr, mode, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (char *)0, (real *)0, (real *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (real *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (char *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (integer *)0, (real *
	    )0, (real *)0, (integer *)0, (char *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, 
	    text_len, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (
	    ftnint)0);
    }

/* Subroutine */ int howplt_(integer *isym, integer *idsty, integer *idcol)
{
    return newpag_0_(6, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, isym, idsty, idcol, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (char *)0, (real *)0, (real *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (real *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (char *)0, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (ftnint)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int ticsiz_(integer *ixtk1, integer *ixtk2, integer *iytk1, 
	integer *iytk2)
{
    return newpag_0_(7, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, ixtk1, 
	    ixtk2, iytk1, iytk2, (char *)0, (real *)0, (real *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (real *)0, (real *)0, (real *)0, (real *)0, (real *)
	    0, (char *)0, (integer *)0, (integer *)0, (integer *)0, (integer *
	    )0, (integer *)0, (real *)0, (real *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)
	    0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int htex_(char *text, real *atx, real *aty, real *angle, 
	real *h__, integer *ncolr, ftnlen text_len)
{
    return newpag_0_(8, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, text, atx, 
	    aty, angle, h__, ncolr, (integer *)0, (integer *)0, (integer *)0, 
	    (integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *
	    )0, (char *)0, (real *)0, (real *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (real *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (char *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (integer *)0, (real *
	    )0, (real *)0, (integer *)0, (char *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, 
	    text_len, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (
	    ftnint)0);
    }

/* Subroutine */ int legnd_(char *clegst, ftnlen clegst_len)
{
    return newpag_0_(9, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, clegst, (real *)0, (
	    real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)0, 
	    (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (ftnint)0, 
	    clegst_len, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0)
	    ;
    }

/* Subroutine */ int legpos_(real *xpos, real *ypos)
{
    return newpag_0_(10, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, xpos, 
	    ypos, (integer *)0, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (real 
	    *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (integer *)0,
	     (char *)0, (integer *)0, (char *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (ftnint)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int linlog_(integer *isx, integer *isy1, integer *isy2)
{
    return newpag_0_(11, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, isx, isy1, isy2, (integer *)0, (integer *)0, (integer 
	    *)0, (real *)0, (real *)0, (real *)0, (real *)0, (real *)0, (char 
	    *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (real *)0, (real *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)
	    0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int noaxes_(void)
{
    return newpag_0_(12, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int noaxex_(void)
{
    return newpag_0_(13, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int noaxey_(void)
{
    return newpag_0_(14, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int nolbox_(void)
{
    return newpag_0_(15, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int nonum_(integer *nx, integer *ny1, integer *ny2)
{
    return newpag_0_(16, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, nx, ny1, 
	    ny2, (real *)0, (real *)0, (real *)0, (real *)0, (real *)0, (char 
	    *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)0, (
	    integer *)0, (real *)0, (real *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)
	    0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int plac_(real *atop, real *abot, real *alef, real *arit)
{
    return newpag_0_(17, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, atop, abot, alef, arit, (real *)0, 
	    (char *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)0,
	     (integer *)0, (real *)0, (real *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)
	    0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int right_(void)
{
    return newpag_0_(18, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int scalup_(real *scale)
{
    return newpag_0_(19, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, scale, (char *)0, (integer *)0, (integer *)0, (integer *
	    )0, (integer *)0, (integer *)0, (real *)0, (real *)0, (integer *)
	    0, (char *)0, (integer *)0, (char *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (ftnint)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int setdv_(char *dname, ftnlen dname_len)
{
    return newpag_0_(20, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, dname, (integer *)0, (integer *)0, (integer *
	    )0, (integer *)0, (integer *)0, (real *)0, (real *)0, (integer *)
	    0, (char *)0, (integer *)0, (char *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (ftnint)0, (ftnint)0, 
	    dname_len, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int setfil_(char *dname, ftnlen dname_len)
{
    return newpag_0_(21, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, dname, (integer *)0, (integer *)0, (integer *
	    )0, (integer *)0, (integer *)0, (real *)0, (real *)0, (integer *)
	    0, (char *)0, (integer *)0, (char *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (ftnint)0, (ftnint)0, 
	    dname_len, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int setgrd_(integer *ifid, integer *iz)
{
    return newpag_0_(22, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, ifid, iz, (integer *)0, (integer *
	    )0, (integer *)0, (real *)0, (real *)0, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)
	    0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int setinc_(integer *jncsym)
{
    return newpag_0_(23, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, 
	    jncsym, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (char *)0, (integer *)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int setlim_(integer *iaxis, integer *itype, real *amin, real 
	*amax)
{
    return newpag_0_(24, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, iaxis, itype, amin, amax, (integer *)0, (char *)0, (
	    integer *)0, (char *)0, (integer *)0, (char *)0, (integer *)0, (
	    char *)0, (integer *)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)
	    0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int setxit_(integer *ixch)
{
    return newpag_0_(25, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, 
	    ixch, (char *)0, (integer *)0, (char *)0, (integer *)0, (char *)0,
	     (integer *)0, (char *)0, (integer *)0, (ftnint)0, (ftnint)0, (
	    ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0, (ftnint)0);
    }

/* Subroutine */ int sidtex_(char *tstr, integer *itclr, char *bstr, integer *
	ibclr, char *lstr, integer *ilclr, char *rstr, integer *irclr, ftnlen 
	tstr_len, ftnlen bstr_len, ftnlen lstr_len, ftnlen rstr_len)
{
    return newpag_0_(26, (integer *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (char *)0, 
	    (real *)0, (real *)0, (real *)0, (real *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (integer *)0, (char *)0, (real *)0,
	     (real *)0, (integer *)0, (integer *)0, (integer *)0, (integer *)
	    0, (integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0, (
	    real *)0, (real *)0, (char *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (integer *)0, (real *)0, (real *)0, (
	    integer *)0, tstr, itclr, bstr, ibclr, lstr, ilclr, rstr, irclr, (
	    ftnint)0, (ftnint)0, (ftnint)0, tstr_len, bstr_len, lstr_len, 
	    rstr_len);
    }

/*       -       -       -       -       -       -       -       - */
/* Subroutine */ int vgbnd_(integer *itype, integer *inu, real *a, real *bmin,
	 real *bmax, integer *ninl, integer *naxl, integer *m)
{
    /* System generated locals */
    integer i__1;
    real r__1, r__2;

    /* Builtin functions */
    integer pow_ii(integer *, integer *);

    /* Local variables */
    static integer i__;
    extern integer vgihi_(real *), vgkdec_(real *);

/*           ORIGINAL NAME  BOUNDS */
/*   CALCULATES AXIS LIMITS */
    /* Parameter adjustments */
    --a;

    /* Function Body */
    if (*itype / pow_ii(&c__2, &c__0) % 2 == 0) {
/*   DETERMINES AXIS LIMITS ONLY IF USER HAS NOT SPECIFIED THEM */
	if (*inu == 1) {
	    *bmin = a[1];
	}
	i__1 = *m;
	for (i__ = 1; i__ <= i__1; ++i__) {
/* Computing MIN */
	    r__1 = *bmin, r__2 = a[i__];
	    *bmin = dmin(r__1,r__2);
/* L10: */
	}
    }
    if (! (*itype / pow_ii(&c__2, &c__0) % 2 == 1 && *inu == 0)) {
	*ninl = vgkdec_(bmin) - 1;
    }
    if (*itype / pow_ii(&c__2, &c__1) % 2 == 0) {
	if (*inu == 1) {
	    *bmax = a[1];
	}
	i__1 = *m;
	for (i__ = 1; i__ <= i__1; ++i__) {
/* Computing MAX */
	    r__1 = *bmax, r__2 = a[i__];
	    *bmax = dmax(r__1,r__2);
/* L20: */
	}
    }
    if (! (*itype / pow_ii(&c__2, &c__1) % 2 == 1 && *inu == 0)) {
	*naxl = vgihi_(bmax) - 1;
    }
    return 0;
} /* vgbnd_ */

/* Subroutine */ int vgtic_(integer *ms, integer *ntic, real *bmin, real *
	bmax, integer *ninl, integer *naxl, integer *iaxis, integer *isd, 
	logical *scalc)
{
    /* Builtin functions */
    integer pow_ii(integer *, integer *);

    /* Local variables */
    extern /* Subroutine */ int vgbet_(real *, real *, integer *, integer *);
    static integer itype;
    extern integer vglgin_(integer *, integer *);
    static integer incrmt, ntictm;
    static real tmpmin, tmpmax;

/*            ORIGINAL NAME  BOUND2 */
/*  CALCULATES NUMBER OF TICK MARKS ON EACH AXIS.  ROUNDS AXIS LIMITS TO 
*/
/*  "NICE" NUMBERS, IF DESIRED.  IT ALSO ADJUSTS THE LIMITS TO PREVENT */
/*  A DIVIDE BY 0 ERROR FROM A STRAIGHT HORIZONTAL LINE. */
/*  MS INDICATES IF LOG AXES ARE TO BE USED. */
    if (*naxl == *ninl) {
	++(*naxl);
    }
    if (*bmin >= *bmax) {
	*bmax = *bmin + .1f;
    }
    tmpmin = *bmin;
    tmpmax = *bmax;
/* WEA 11/89 ADDED "LOG" TEST SO VGBET WOULD NOT PERTURB LOG AXIS LIMITS 
*/
    if (*ms == 0) {
	vgbet_(&tmpmin, &tmpmax, &ntictm, isd);
    }
    itype = vgsbnd_1.limflg[vgcntr_1.ig + *iaxis * 7 - 8];
    if (*scalc) {
/*  CALCULATE SUGGESTED BOUNDARIES */
	vgsbnd_1.smin[vgcntr_1.ig + *iaxis * 7 - 8] = tmpmin;
	vgsbnd_1.smax[vgcntr_1.ig + *iaxis * 7 - 8] = tmpmax;
    }
    if (itype / pow_ii(&c__2, &c__0) % 2 == 0) {
	*bmin = vgsbnd_1.smin[vgcntr_1.ig + *iaxis * 7 - 8];
/*      ELSE */
/*        NINL=VGKDEC(BMIN)-1 */
    }
    if (itype / pow_ii(&c__2, &c__1) % 2 == 0) {
	*bmax = vgsbnd_1.smax[vgcntr_1.ig + *iaxis * 7 - 8];
/*      ELSE */
/*        NAXL=VGIHI(BMAX)-1 */
    }
    if (*ninl >= *naxl) {
	*naxl = *ninl + 1;
    }
    if (vgtic1_1.yestic[vgcntr_1.ig + *iaxis * 7 - 8]) {
/* USER HAS PROVIDED NUMBER OF TICS, SET TIC BOUNDARIES TO GRAPH BOUND
ARIES*/
	vgsbnd_1.tmin[vgcntr_1.ig + *iaxis * 7 - 8] = *bmin;
	vgsbnd_1.tmax[vgcntr_1.ig + *iaxis * 7 - 8] = *bmax;
    } else {
/*  ELSE VG CALCULATES TICS, SET TIC BOUNDARIES TO "NICE" NUMBERS */
	vgsbnd_1.tmin[vgcntr_1.ig + *iaxis * 7 - 8] = tmpmin;
	vgsbnd_1.tmax[vgcntr_1.ig + *iaxis * 7 - 8] = tmpmax;
/*  CALCULATE NUMBER OF TIC MARKS */
	if (*ms == 1) {
	    incrmt = vglgin_(ninl, naxl);
	    *ntic = (*naxl - *ninl) / incrmt;
	} else {
	    *ntic = ntictm;
	}
    }
    return 0;
} /* vgtic_ */

/* Subroutine */ int vgbet_(real *rmin, real *rmax, integer *nticks, integer *
	isd)
{
    /* Format strings */
    static char fmt_100[] = "(f2.1)";
    static char fmt_200[] = "(i3)";
    static char fmt_210[] = "(e6.1)";

    /* System generated locals */
    address a__1[3];
    integer i__1[3];
    real r__1;

    /* Builtin functions */
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen);
    integer s_rsfi(icilist *), e_rsfi(void);
    double r_sign(real *, real *);

    /* Local variables */
    static char cisd[3];
    static real step, rmin1, rmax1, range;
    static char cstep[6];
    extern doublereal vgamt_(real *);
    static integer itemp;
    static real rm, sm;
    extern integer vgidec_(real *);
    static integer ird;
    static char csm[2];

    /* Fortran I/O blocks */
    static icilist io___40 = { 0, csm, 0, fmt_100, 2, 1 };
    static icilist io___42 = { 0, cisd, 0, fmt_200, 3, 1 };
    static icilist io___44 = { 0, cstep, 0, fmt_210, 6, 1 };


/*           ORIGINAL NAME BETTER */
/*  THIS AXIS-LIMIT ROUNDING ROUTINE IS BASED ON A PROGRAM BY */
/*  DAVID REDMILES (NBS). */

    range = *rmax - *rmin;
    rm = (real)vgamt_(&range);
    ird = vgidec_(&range);
    if (rm <= .15f) {
	sm = .1f;
	*isd = ird - 1;
    }
    if (rm > .15f && rm <= .3f) {
	sm = .2f;
	*isd = ird - 1;
    }
    if (rm > .3f && rm <= .75f) {
	sm = .5f;
	*isd = ird - 1;
    }
    if (rm > .75f) {
	sm = .1f;
	*isd = ird;
    }
    s_wsfi(&io___40);
    do_fio(&c__1, (char *)&sm, (ftnlen)sizeof(real));
    e_wsfi();
    s_wsfi(&io___42);
    do_fio(&c__1, (char *)&(*isd), (ftnlen)sizeof(integer));
    e_wsfi();
/* Writing concatenation */
    i__1[0] = 2, a__1[0] = csm;
    i__1[1] = 1, a__1[1] = "e";
    i__1[2] = 3, a__1[2] = cisd;
    s_cat(cstep, a__1, i__1, &c__3, 6L);
    s_rsfi(&io___44);
    do_fio(&c__1, (char *)&step, (ftnlen)sizeof(real));
    e_rsfi();
/*  ITEMP IS A PATCH TO GET BY ROUNDING ERROR (DRA, 9 SEPT 89) */
    itemp = (integer) (*rmin / step + (real)r_sign(&c_b100, rmin));
/*     IF(RMIN/STEP.NE.ITEMP)THEN */
/* WEA 12/89 REPLACED ABOVE LINE WITH BELOW FOR BETTER FP TEST */
    if ((r__1 = *rmin / step - itemp, dabs(r__1)) > 1e-6f) {
	if (*rmin >= 0.f) {
	    rmin1 = step * itemp;
	} else {
	    rmin1 = step * (itemp - 1);
	}
    } else {
	rmin1 = *rmin;
    }
/*  ITEMP PATCH AS ABOVE */
    itemp = (integer) (*rmax / step + (real)r_sign(&c_b100, rmax));
/*     IF(RMAX/STEP.NE.ITEMP)THEN */
/* WEA 12/89 REPLACED ABOVE LINE WITH BELOW FOR BETTER FP TEST */
    if ((r__1 = *rmax / step - itemp, dabs(r__1)) > 1e-6f) {
	if (*rmax >= 0.f) {
	    rmax1 = step * (itemp + 1);
	} else {
	    rmax1 = step * itemp;
	}
    } else {
	rmax1 = *rmax;
    }
    *rmin = rmin1;
    *rmax = rmax1;
    *nticks = (integer) ((*rmax - *rmin) / step + .5f);
    return 0;
} /* vgbet_ */

/* Subroutine */ int vgadtx_(char *text, real *x, real *y, real *angle, real *
	size, integer *color, integer *mode, integer *owner, ftnlen text_len)
{
    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

/*  ADDS A LINE OF TEXT */
    if (vgtx1_1.ntex >= 50) {
	return 0;
    }
    ++vgtx1_1.ntex;
    vgtx1_1.sx[vgtx1_1.ntex - 1] = *x;
    vgtx1_1.sy[vgtx1_1.ntex - 1] = *y;
    s_copy(vgtx2_1.st + (vgtx1_1.ntex - 1) * 70, text, 70L, text_len);
    vgtx1_1.sa[vgtx1_1.ntex - 1] = *angle;
    vgtx1_1.sh[vgtx1_1.ntex - 1] = *size * vghgt_1.height;
/* COLOR SHOULD BE BETWEEN 1 AND 15 - WEA 1/17/90 */
    if (*color < 1) {
	vgtx1_1.sc[vgtx1_1.ntex - 1] = 1;
    } else if (*color > 15) {
	vgtx1_1.sc[vgtx1_1.ntex - 1] = 15;
    } else {
	vgtx1_1.sc[vgtx1_1.ntex - 1] = *color;
    }
    vgtx1_1.so[vgtx1_1.ntex - 1] = *owner;
    vgtx1_1.sm[vgtx1_1.ntex - 1] = *mode;
    return 0;
} /* vgadtx_ */

/* Subroutine */ int settic_(integer *iaxis, integer *ntics, char *strarr, 
	ftnlen strarr_len)
{
    /* System generated locals */
    address a__1[2];
    integer i__1, i__2[2];
    icilist ici__1;

    /* Builtin functions */
    integer s_rsfi(icilist *), do_fio(integer *, char *, ftnlen), e_rsfi(void)
	    , i_indx(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen), s_cat(char *,
	     char **, integer *, integer *, ftnlen);

    /* Local variables */
    static real amin, amax;
    static char tail[20], temp[20];
    static integer i__, itics;
    extern /* Subroutine */ int vgnum_(real *, real *, integer *, integer *, 
	    integer *, real *, char *, integer *, real *, real *, integer *, 
	    integer *, ftnlen);
    static integer locdec, numdec, lendum[21];
    static real hgtdum[21], widdum[21];
    static integer locexp;
    static char strnum[20*20];

/*  SET NUMBER OF TIC MARKS AND TIC TEXT */
    /* Parameter adjustments */
    strarr -= strarr_len;

    /* Function Body */
    if (abs(*ntics) > 1) {
	if (*ntics < 0) {
/* Computing MIN */
	    i__1 = -(*ntics);
	    itics = min(i__1,14);
	    if (*iaxis == 1) {
		amin = vglim_2.bxmin[vgcntr_1.ig - 1];
		amax = vglim_2.bxmax[vgcntr_1.ig - 1];
	    } else {
		amin = vglim_2.bymin[vgcntr_1.ig + (*iaxis - 1) * 7 - 8];
		amax = vglim_2.bymax[vgcntr_1.ig + (*iaxis - 1) * 7 - 8];
	    }
	    i__1 = itics - 1;
	    vgnum_(&amin, &amax, &c__0, &c__0, &i__1, &c_b60, strnum, lendum, 
		    hgtdum, widdum, &c__0, &c_n7, 20L);
	    ici__1.icierr = 1;
	    ici__1.iciend = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = strarr_len;
	    ici__1.iciunit = strarr + strarr_len;
	    ici__1.icifmt = "(I2)";
	    i__1 = s_rsfi(&ici__1);
	    if (i__1 != 0) {
		goto L20;
	    }
	    i__1 = do_fio(&c__1, (char *)&numdec, (ftnlen)sizeof(integer));
	    if (i__1 != 0) {
		goto L20;
	    }
	    i__1 = e_rsfi();
	    if (i__1 != 0) {
		goto L20;
	    }
	    if (numdec < 0) {
		return 0;
	    }
	    i__1 = itics;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		locdec = i_indx(strnum + (i__ - 1) * 20, ".", 20L, 1L);
		locexp = i_indx(strnum + (i__ - 1) * 20, "E", 20L, 1L);
		s_copy(temp, strnum + (i__ - 1) * 20, 20L, 20L);
		if (locexp > 0) {
		    s_copy(tail, temp + (locexp - 1), 20L, 20 - (locexp - 1));
		} else {
		    s_copy(tail, " ", 20L, 1L);
		}
/* Writing concatenation */
		i__2[0] = locdec + numdec, a__1[0] = temp;
		i__2[1] = 20, a__1[1] = tail;
		s_cat(vgtic2_1.ticstr + (vgcntr_1.ig + (*iaxis + i__ * 3) * 7 
			- 29) * 20, a__1, i__2, &c__2, 20L);
/* L5: */
	    }
	} else if (*ntics > 0 && vgloop_2.pass1) {
	    itics = min(*ntics,14);
	    i__1 = itics;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		s_copy(vgtic2_1.ticstr + (vgcntr_1.ig + (*iaxis + i__ * 3) * 
			7 - 29) * 20, strarr + i__ * strarr_len, 20L, 
			strarr_len);
/* L10: */
	    }
	}
	if (! (*ntics < 0 || vgloop_2.pass1)) {
	    return 0;
	}
	vgtic1_1.yestic[vgcntr_1.ig + *iaxis * 7 - 8] = TRUE_;
	if (*iaxis == 1) {
	    vgtic1_1.nh[vgcntr_1.ig - 1] = itics - 1;
	} else if (*iaxis == 2) {
	    vgtic1_1.nv1[vgcntr_1.ig - 1] = itics - 1;
	} else if (*iaxis == 3) {
	    vgtic1_1.nv2[vgcntr_1.ig - 1] = itics - 1;
	}
    }
L20:
    return 0;
} /* settic_ */

/* Subroutine */ int bbox_(real *boxtop, real *boxbot, real *boxlef, real *
	boxrit, integer *ingflg)
{
    extern doublereal vgg2s_(real *, real *, real *, real *, real *, integer *
	    , integer *, integer *);
    static real bxlef, bxbot, bxtop, bxrit;

/*  CREATE A BLANK LEGEND BOX */
    if (! vgloop_1.pass2 || *boxtop <= *boxbot || *boxrit <= *boxlef) {
	return 0;
    }
    vgleg1_1.isleg[vgcntr_1.ig - 1] = 1;
    vgleg1_1.legvis[vgcntr_1.ig - 1] = 1;
    vgleg1_1.legset[vgcntr_1.ig - 1] = 1;
    if (*ingflg == 1) {
/*  SIDES GIVEN IN GRAPH'S COORDINATES */
	bxtop = (real)vgg2s_(boxtop, &vglim_1.bbot1[vgcntr_1.ig - 1], &
		vglim_1.btop1[vgcntr_1.ig - 1], &vglim_1.bymin[vgcntr_1.ig - 
		1], &vglim_1.bymax[vgcntr_1.ig - 1], &vglim_1.ninly[
		vgcntr_1.ig - 1], &vglim_1.naxly[vgcntr_1.ig - 1], &
		vglim_1.msy[vgcntr_1.ig - 1]);
	bxbot = (real)vgg2s_(boxbot, &vglim_1.bbot1[vgcntr_1.ig - 1], &
		vglim_1.btop1[vgcntr_1.ig - 1], &vglim_1.bymin[vgcntr_1.ig - 
		1], &vglim_1.bymax[vgcntr_1.ig - 1], &vglim_1.ninly[
		vgcntr_1.ig - 1], &vglim_1.naxly[vgcntr_1.ig - 1], &
		vglim_1.msy[vgcntr_1.ig - 1]);
	bxlef = (real)vgg2s_(boxlef, &vglim_1.bleft1[vgcntr_1.ig - 1], &
		vglim_1.brit1[vgcntr_1.ig - 1], &vglim_1.bxmin[vgcntr_1.ig - 
		1], &vglim_1.bxmax[vgcntr_1.ig - 1], &vglim_1.ninlx[
		vgcntr_1.ig - 1], &vglim_1.naxlx[vgcntr_1.ig - 1], &
		vglim_1.msx[vgcntr_1.ig - 1]);
	bxrit = (real)vgg2s_(boxrit, &vglim_1.bleft1[vgcntr_1.ig - 1], &
		vglim_1.brit1[vgcntr_1.ig - 1], &vglim_1.bxmin[vgcntr_1.ig - 
		1], &vglim_1.bxmax[vgcntr_1.ig - 1], &vglim_1.ninlx[
		vgcntr_1.ig - 1], &vglim_1.naxlx[vgcntr_1.ig - 1], &
		vglim_1.msx[vgcntr_1.ig - 1]);
    } else {
/*  SIDES GIVEN IN UNIT COORDINATES */
	bxtop = *boxtop * vgscrn_1.sht;
	bxbot = *boxbot * vgscrn_1.sht;
	bxlef = *boxlef * vgscrn_1.swd;
	bxrit = *boxrit * vgscrn_1.swd;
    }
    vgleg1_1.xleg[vgcntr_1.ig - 1] = (bxlef + bxrit) / 2;
    vgleg1_1.yleg[vgcntr_1.ig - 1] = (bxtop + bxbot) / 2;
    vgleg1_1.hh[vgcntr_1.ig - 1] = bxrit - bxlef;
    vgleg1_1.vv[vgcntr_1.ig - 1] = bxtop - bxbot;
    return 0;
} /* bbox_ */

/* Subroutine */ int xitprn_(logical *print)
{
/*  TURN INTERACTIVE LOOP PRINTING ON OR OFF */
    vgprnt_1.pb4xit = *print;
    return 0;
} /* xitprn_ */

/* Subroutine */ int commen_(char *cmmnt, ftnlen cmmnt_len)
{
    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

/*  PROVIDE A COMMENT LINE */
    s_copy(vgusrc_1.commnt, cmmnt, 80L, cmmnt_len);
    return 0;
} /* commen_ */

