/* tmov.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"
#include "agraf.h"

/* Common Block Declarations */

struct {
    real sx[50], sy[50], sa[50], sh[50];
    integer sc[50], so[50], sm[50], ntex;
} vgtx1_;

#define vgtx1_1 vgtx1_

struct {
    char st[3500];
} vgtx2_;

#define vgtx2_1 vgtx2_

struct {
    real size;
} vghgt_;

#define vghgt_1 vghgt_

struct {
    integer labels[28]	/* was [7][4] */;
} vglab_;

#define vglab_1 vglab_

/* Table of constant values */

static integer c__1 = 1;
static integer c__5 = 5;
static integer c__2 = 2;
static integer c__0 = 0;
static logical c_true = TRUE_;
static real c_b69 = 0.f;
static integer c__70 = 70;

/* Subroutine */ int vgtmv_(real *btop1, real *bbot1, real *bleft1, real *
	brit1, integer *kg, integer *ng, integer *iesc)
{
    /* Initialized data */

    static real sht = 18.75f;
    static real ttop[8] = { 18.65f };
    static real tbot[8] = { .1f };
    static real tleft[8] = { .1f };
    static real trit[8] = { 24.9f };
    static char modst[8*6] = "DISTANCE" "POINT   " "H CENTER" "V CENTER" 
	    "T CENTER" "R CENTER";

    /* System generated locals */
    address a__1[5], a__2[2];
    integer i__1[5], i__2[2], i__3;
    real r__1, r__2, r__3, r__4;
    char ch__1[43];

    /* Builtin functions */
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen),
	     s_copy(char *, char *, ftnlen, ftnlen);
    integer i_indx(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static char temp[70];
    extern /* Subroutine */ int vgnp_(integer *), vgms_(real *, real *, real *
	    , real *);
    static logical show;
    static integer i__, j, k, kflag, which;
    extern /* Subroutine */ int vgedt_(integer *, integer *, integer *, real *
	    , real *, real *, char *, real *, integer *, integer *, integer *,
	     ftnlen), vgcor_(real *, real *, real *, real *);
    static integer kcurr;
    static char ch[1];
    static real am;
    static real delhgt;
    extern /* Subroutine */ int vgcent_(char *, real *, real *, real *, real *
	    , real *, real *, real *, real *, integer *, integer *, ftnlen);
    static real rotmag;
    extern /* Subroutine */ int vgsmbl_(real *, real *, real *, char *, real *
	    , integer *, ftnlen), vgcmnt_(char *, ftnlen), vgletr_(integer *, 
	    logical *);
    static char colstr[2];
    extern integer vgistr_(char *, ftnlen);
    static char ownstr[1];
    static integer len;

    /* Fortran I/O blocks */
    static icilist io___13 = { 0, colstr, 0, "(I2)", 2, 1 };
    static icilist io___15 = { 0, ownstr, 0, "(I1)", 1, 1 };
    static icilist io___24 = { 0, colstr, 0, "(I2)", 2, 1 };
    static icilist io___25 = { 0, ownstr, 0, "(I1)", 1, 1 };


/*          ORIGINAL NAME TMOV */
/*  FOR MANIPULATING TEXT STRINGS FROM THE KEYBOARD. */
    /* Parameter adjustments */
    --brit1;
    --bleft1;
    --bbot1;
    --btop1;

    /* Function Body */
/*  COPY GRAPH DATA INTO LOCAL ARRAY TO AVOID HAVING TO */
/*  MAKE CENTERING NON-BOUND TEXT A SPECIAL CASE. */
    for (i__ = 1; i__ <= 7; ++i__) {
	ttop[i__] = btop1[i__];
	tbot[i__] = bbot1[i__];
	tleft[i__] = bleft1[i__];
	trit[i__] = brit1[i__];
/* L40: */
    }
    k = 1;
    show = FALSE_;
    am = sht * .05f;
    rotmag = 15.f;
    vgcmnt_("Text Mode", 9L);
    if (vgtx1_1.ntex == 0) {
	vgcmnt_("Text Mode (No Text)", 19L);
    }
    r__1 = tleft[*kg] - .1f;
    r__2 = trit[*kg] + .1f;
    r__3 = ttop[*kg] + .1f;
    r__4 = tbot[*kg] - .1f;
    vgcor_(&r__1, &r__2, &r__3, &r__4);
L50:
    vgms_(&vgtx1_1.sx[k - 1], &vgtx1_1.sx[k - 1], &vgtx1_1.sy[k - 1], &
	    vgtx1_1.sy[k - 1]);
    if (show) {
	s_wsfi(&io___13);
	do_fio(&c__1, (char *)&vgtx1_1.sc[k - 1], (ftnlen)sizeof(integer));
	e_wsfi();
	s_wsfi(&io___15);
	do_fio(&c__1, (char *)&vgtx1_1.so[k - 1], (ftnlen)sizeof(integer));
	e_wsfi();
/* Writing concatenation */
	i__1[0] = 21, a__1[0] = "Text Status:  Color: ";
	i__1[1] = 2, a__1[1] = colstr;
	i__1[2] = 9, a__1[2] = "  Owner: ";
	i__1[3] = 1, a__1[3] = ownstr;
	i__1[4] = 2, a__1[4] = "  ";
	s_cat(temp, a__1, i__1, &c__5, 70L);
/* Writing concatenation */
	i__2[0] = 35, a__2[0] = temp;
	i__2[1] = 8, a__2[1] = modst + (vgtx1_1.sm[k - 1] - 1 << 3);
	s_cat(ch__1, a__2, i__2, &c__2, 43L);
	vgcmnt_(ch__1, 43L);
    }
L200:
    if (! agrafa_(&c__0, &c__1, &kcurr, &kflag)) {
	goto L200;
    }
    *(unsigned char *)ch = (char) kcurr;
    if (kcurr == 27) {
	vgcmnt_(" ", 1L);
	*iesc = 1;
	r__1 = tleft[*kg] - .1f;
	r__2 = trit[*kg] + .1f;
	r__3 = ttop[*kg] + .1f;
	r__4 = tbot[*kg] - .1f;
	vgcor_(&r__1, &r__2, &r__3, &r__4);
	if (*kg == 0) {
	    *kg = 1;
	}
/*  ADJUST LETTERING IN CASE AN AXIS LABEL WAS CHANGED */
	i__3 = *ng;
	for (i__ = 1; i__ <= i__3; ++i__) {
	    vgletr_(&i__, &c_true);
/* L205: */
	}
	return 0;
    }
    if (kcurr == 32 && vgtx1_1.ntex > 1) {
/*  MOVE TO NEXT TEXT LINE */
	++k;
	if (k > vgtx1_1.ntex) {
	    k = 1;
	}
	goto L50;
    }
    if (kcurr == 8 && vgtx1_1.ntex > 1) {
/*  MOVE TO PREVIOUS TEXT LINE */
	--k;
	if (k < 1) {
	    k = vgtx1_1.ntex;
	}
	goto L50;
    }
    if (*(unsigned char *)ch == '!') {
/*  DELETE CURRENT LINE */
	if (vgtx1_1.ntex == 1) {
	    s_copy(vgtx2_1.st, " ", 70L, 1L);
	}
	if (vgtx1_1.ntex > 1) {
	    for (i__ = 1; i__ <= 7; ++i__) {
		for (j = 1; j <= 4; ++j) {
		    if (vglab_1.labels[i__ + j * 7 - 8] == k) {
			vglab_1.labels[i__ + j * 7 - 8] = 0;
		    } else if (vglab_1.labels[i__ + j * 7 - 8] > k) {
			--vglab_1.labels[i__ + j * 7 - 8];
		    }
/* L210: */
		}
/* L220: */
	    }
	    if (k == vgtx1_1.ntex) {
		k = vgtx1_1.ntex - 1;
	    } else {
		i__3 = vgtx1_1.ntex;
		for (i__ = k + 1; i__ <= i__3; ++i__) {
		    vgtx1_1.sx[i__ - 2] = vgtx1_1.sx[i__ - 1];
		    vgtx1_1.sy[i__ - 2] = vgtx1_1.sy[i__ - 1];
		    vgtx1_1.sa[i__ - 2] = vgtx1_1.sa[i__ - 1];
		    vgtx1_1.sh[i__ - 2] = vgtx1_1.sh[i__ - 1];
		    vgtx1_1.sc[i__ - 2] = vgtx1_1.sc[i__ - 1];
		    vgtx1_1.so[i__ - 2] = vgtx1_1.so[i__ - 1];
		    vgtx1_1.sm[i__ - 2] = vgtx1_1.sm[i__ - 1];
		    s_copy(vgtx2_1.st + (i__ - 2) * 70, vgtx2_1.st + (i__ - 1)
			     * 70, 70L, 70L);
/* L250: */
		}
	    }
	    --vgtx1_1.ntex;
	    goto L50;
	}
    }
    if (*(unsigned char *)ch == 'C' || *(unsigned char *)ch == 'c') {
/*  CHANGE TO COARSE MOVEMENT */
	am = sht * .05f;
	rotmag = 15.f;
	goto L300;
    } else if (*(unsigned char *)ch == 'F' || *(unsigned char *)ch == 'f') {
/*  CHANGE TO FINE MOVEMENT */
	am = sht * .01f;
	rotmag = 5.f;
	goto L300;
    } else if (*(unsigned char *)ch == 'S' || *(unsigned char *)ch == 's') {
/*  TOGGLE STATUS LINE DISPLAY */
	show = ! show;
	if (! show) {
	    if (vgtx1_1.ntex == 0) {
		vgcmnt_("Text Mode (No Text)", 19L);
	    } else {
		vgcmnt_("Text Mode", 9L);
	    }
	}
	goto L300;
    } else if (*(unsigned char *)ch == 'U' || *(unsigned char *)ch == 'u') {
/*  CHANGE TO ULTRAFINE MOVEMENT */
	am = sht * .001f;
	rotmag = 1.f;
	goto L300;
    } else if (*(unsigned char *)ch == ']') {
/*  MOVE TO NEXT GRAPH */
	r__1 = tleft[*kg] - .1f;
	r__2 = trit[*kg] + .1f;
	r__3 = ttop[*kg] + .1f;
	r__4 = tbot[*kg] - .1f;
	vgcor_(&r__1, &r__2, &r__3, &r__4);
	++(*kg);
	if (*kg > *ng) {
	    *kg = 0;
	}
	r__1 = tleft[*kg] - .1f;
	r__2 = trit[*kg] + .1f;
	r__3 = ttop[*kg] + .1f;
	r__4 = tbot[*kg] - .1f;
	vgcor_(&r__1, &r__2, &r__3, &r__4);
	goto L300;
    } else if (*(unsigned char *)ch == '[') {
/*  MOVE TO PREVIOUS GRAPH */
	r__1 = tleft[*kg] - .1f;
	r__2 = trit[*kg] + .1f;
	r__3 = ttop[*kg] + .1f;
	r__4 = tbot[*kg] - .1f;
	vgcor_(&r__1, &r__2, &r__3, &r__4);
	--(*kg);
	if (*kg == -1) {
	    *kg = *ng;
	}
	r__1 = tleft[*kg] - .1f;
	r__2 = trit[*kg] + .1f;
	r__3 = ttop[*kg] + .1f;
	r__4 = tbot[*kg] - .1f;
	vgcor_(&r__1, &r__2, &r__3, &r__4);
	goto L300;
    } else if (*(unsigned char *)ch == 'O' || *(unsigned char *)ch == 'o') {
/*  CHANGE CURRENT LINE'S OWNER TO CURRENT GRAPH */
	vgtx1_1.so[k - 1] = *kg;
	goto L300;
    } else if (*(unsigned char *)ch == 'P' || *(unsigned char *)ch == 'p') {
/*  CHANGE CURRENT LINE'S MODE TO 'STICK TO POINT' */
	vgtx1_1.sm[k - 1] = 2;
	goto L300;
    } else if (*(unsigned char *)ch == 'D' || *(unsigned char *)ch == 'd') {
/*  CHANGE CURRENT LINE'S MODE TO 'KEEP DISTANCE FROM ORIGIN' */
	vgtx1_1.sm[k - 1] = 1;
	goto L300;
    } else if (*(unsigned char *)ch == 'A' || *(unsigned char *)ch == 'a') {
/*  MAKE CURRENT LINE INTO AN AXIS LABEL */
	if (vgtx1_1.sm[k - 1] > 2) {
	    if (vgtx1_1.sm[k - 1] > 4) {
		vglab_1.labels[vgtx1_1.so[k - 1] + (9 - vgtx1_1.sm[k - 1]) * 
			7 - 8] = k;
	    } else {
		vglab_1.labels[vgtx1_1.so[k - 1] + (vgtx1_1.sm[k - 1] - 2) * 
			7 - 8] = k;
	    }
	}
    }
    delhgt = rotmag * .05f * vghgt_1.size;
    if (kcurr == 18432 || kcurr == 56 || kcurr == 20480 || kcurr == 50 || 
	    kcurr == 19712 || kcurr == 54 || kcurr == 19200 || kcurr == 52 || 
	    i_indx("RrLlIiJjKkMmHhVv-+<>@", ch, 21L, 1L) > 0) {
	if (kcurr == 18432 || kcurr == 56 || *(unsigned char *)ch == 'i' || *(
		unsigned char *)ch == 'I') {
/*  MOVE CURRENT LINE UP */
	    vgtx1_1.sy[k - 1] += am;
	    if (vgtx1_1.sm[k - 1] == 4 || vgtx1_1.sm[k - 1] == 6) {
		vgtx1_1.sm[k - 1] = 1;
	    }
	} else if (kcurr == 20480 || kcurr == 50 || *(unsigned char *)ch == 
		'm' || *(unsigned char *)ch == 'M') {
/*  MOVE CURRENT LINE DOWN */
	    vgtx1_1.sy[k - 1] -= am;
	    if (vgtx1_1.sm[k - 1] == 4 || vgtx1_1.sm[k - 1] == 6) {
		vgtx1_1.sm[k - 1] = 1;
	    }
	} else if (kcurr == 19712 || kcurr == 54 || *(unsigned char *)ch == 
		'k' || *(unsigned char *)ch == 'K') {
/*  MOVE CURRENT LINE RIGHT */
	    vgtx1_1.sx[k - 1] += am;
	    if (vgtx1_1.sm[k - 1] == 3 || vgtx1_1.sm[k - 1] == 5) {
		vgtx1_1.sm[k - 1] = 1;
	    }
	} else if (kcurr == 19200 || kcurr == 52 || *(unsigned char *)ch == 
		'j' || *(unsigned char *)ch == 'J') {
/*  MOVE CURRENT LINE LEFT */
	    vgtx1_1.sx[k - 1] -= am;
	    if (vgtx1_1.sm[k - 1] == 3 || vgtx1_1.sm[k - 1] == 5) {
		vgtx1_1.sm[k - 1] = 1;
	    }
	} else if (*(unsigned char *)ch == 'R' || *(unsigned char *)ch == 'r')
		 {
/*  ROTATE CURRENT LINE RIGHT */
	    vgtx1_1.sa[k - 1] -= rotmag;
	} else if (*(unsigned char *)ch == 'L' || *(unsigned char *)ch == 'l')
		 {
/*  ROTATE CURRENT LINE LEFT */
	    vgtx1_1.sa[k - 1] += rotmag;
	} else if (*(unsigned char *)ch == '-') {
/*  MAKE CURRENT LINE LARGER */
	    vgtx1_1.sh[k - 1] -= delhgt;
	} else if (*(unsigned char *)ch == '+') {
/*  MAKE CURRENT LINE SMALLER */
	    vgtx1_1.sh[k - 1] += delhgt;
	} else if (*(unsigned char *)ch == 'H' || *(unsigned char *)ch == 'h')
		 {
/*  CENTER CURRENT LINE (BOTTOM CENTER) */
	    vgtx1_1.sm[k - 1] = 3;
	} else if (*(unsigned char *)ch == 'V' || *(unsigned char *)ch == 'v')
		 {
/*  CENTER CURRENT LINE (LEFT CENTER) */
	    vgtx1_1.sm[k - 1] = 4;
	} else if (*(unsigned char *)ch == '@') {
/*  TOGGLE CURRENT LINE CENTERING MODE */
	    if (vgtx1_1.sm[k - 1] == 3 || vgtx1_1.sm[k - 1] == 4) {
		vgtx1_1.sm[k - 1] += 2;
	    } else if (vgtx1_1.sm[k - 1] == 5 || vgtx1_1.sm[k - 1] == 6) {
		vgtx1_1.sm[k - 1] += -2;
	    }
	} else if (*(unsigned char *)ch == '<') {
/*  DECREASE CURRENT LINE COLOR CODE */
	    --vgtx1_1.sc[k - 1];
	    if (vgtx1_1.sc[k - 1] < 1) {
		vgtx1_1.sc[k - 1] = 15;
	    }
	} else if (*(unsigned char *)ch == '>') {
/*  INCREASE CURRENT LINE COLOR CODE */
	    ++vgtx1_1.sc[k - 1];
	    if (vgtx1_1.sc[k - 1] > 15) {
		vgtx1_1.sc[k - 1] = 1;
	    }
	}
	if (vgtx1_1.sm[k - 1] == 3 || vgtx1_1.sm[k - 1] == 5) {
	    vgcent_(vgtx2_1.st + (k - 1) * 70, &vgtx1_1.sx[k - 1], &
		    vgtx1_1.sy[k - 1], &vgtx1_1.sa[k - 1], &vgtx1_1.sh[k - 1],
		     &c_b69, &c_b69, &tleft[vgtx1_1.so[k - 1]], &trit[
		    vgtx1_1.so[k - 1]], &c__1, &c__0, 70L);
	} else if (vgtx1_1.sm[k - 1] == 4 || vgtx1_1.sm[k - 1] == 6) {
	    vgcent_(vgtx2_1.st + (k - 1) * 70, &vgtx1_1.sx[k - 1], &
		    vgtx1_1.sy[k - 1], &vgtx1_1.sa[k - 1], &vgtx1_1.sh[k - 1],
		     &ttop[vgtx1_1.so[k - 1]], &tbot[vgtx1_1.so[k - 1]], &
		    c_b69, &c_b69, &c__0, &c__1, 70L);
	}
	len = vgistr_(vgtx2_1.st + (k - 1) * 70, 70L);
	vgnp_(&vgtx1_1.sc[k - 1]);
	vgsmbl_(&vgtx1_1.sx[k - 1], &vgtx1_1.sy[k - 1], &vgtx1_1.sh[k - 1], 
		vgtx2_1.st + (k - 1) * 70, &vgtx1_1.sa[k - 1], &len, 70L);
    }
    if (*(unsigned char *)ch == 'X' || *(unsigned char *)ch == 'x') {
/*  EXIT, REDRAWING SCREEN */
	vgcmnt_(" ", 1L);
	*iesc = 0;
	i__3 = *ng;
	for (i__ = 1; i__ <= i__3; ++i__) {
	    vgletr_(&i__, &c_true);
/* L280: */
	}
	return 0;
    }
    if (i_indx("NnEe", ch, 4L, 1L) > 0) {
/*  EDIT LINE */
	if (*(unsigned char *)ch == 'N' || *(unsigned char *)ch == 'n' || 
		vgtx1_1.ntex == 0) {
	    which = vgtx1_1.ntex + 1;
	} else {
	    which = k;
	}
	vgedt_(&vgtx1_1.ntex, &which, &k, vgtx1_1.sx, vgtx1_1.sy, vgtx1_1.sh, 
		vgtx2_1.st, vgtx1_1.sa, vgtx1_1.sc, vgtx1_1.so, vgtx1_1.sm, 
		70L);
	if (vgtx1_1.ntex == 0) {
	    vgcmnt_("Text Mode (No Text)", 19L);
	} else {
	    vgcmnt_("Text Mode", 9L);
	}
    }
L300:
    if (show) {
	s_wsfi(&io___24);
	do_fio(&c__1, (char *)&vgtx1_1.sc[k - 1], (ftnlen)sizeof(integer));
	e_wsfi();
	s_wsfi(&io___25);
	do_fio(&c__1, (char *)&vgtx1_1.so[k - 1], (ftnlen)sizeof(integer));
	e_wsfi();
/* Writing concatenation */
	i__1[0] = 21, a__1[0] = "Text Status:  Color: ";
	i__1[1] = 2, a__1[1] = colstr;
	i__1[2] = 9, a__1[2] = "  Owner: ";
	i__1[3] = 1, a__1[3] = ownstr;
	i__1[4] = 2, a__1[4] = "  ";
	s_cat(temp, a__1, i__1, &c__5, 70L);
/* Writing concatenation */
	i__2[0] = 35, a__2[0] = temp;
	i__2[1] = 8, a__2[1] = modst + (vgtx1_1.sm[k - 1] - 1 << 3);
	s_cat(ch__1, a__2, i__2, &c__2, 43L);
	vgcmnt_(ch__1, 43L);
    }
    goto L200;
} /* vgtmv_ */

/* Subroutine */ int vgedt_(integer *ntex, integer *which, integer *last, 
	real *sx, real *sy, real *sh, char *st, real *sa, integer *sc, 
	integer *so, integer *sm, ftnlen st_len)
{
    /* Initialized data */

    static real deg2rad = .0174533f;

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    double sin(doublereal), cos(doublereal);

    /* Local variables */
    static integer mode;
    extern /* Subroutine */ int vggl_(integer *, char *, char *, integer *, 
	    ftnlen, ftnlen);
    static char temp[70];
    static real size;
    extern /* Subroutine */ int vgnp_(integer *);
    static real angle;
    extern /* Subroutine */ int vgsmbl_(real *, real *, real *, char *, real *
	    , integer *, ftnlen);
    static integer len;

/*  ORIGINAL NAME NEWTEX.  ALLOWS USER TO EDIT TEXT */
/*  FROM THE KEYBOARD. PREVIOUSLY CALLED VGNWT. */
    /* Parameter adjustments */
    --sm;
    --so;
    --sc;
    --sa;
    st -= 70;
    --sh;
    --sy;
    --sx;

    /* Function Body */
    if (*which < 51) {
	vggl_(&len, "New Text:   ", temp, &c__70, 12L, 70L);
	if (len > 0) {
	    if (*which > *ntex) {
		++(*ntex);
	    }
	    s_copy(st + *which * 70, temp, 70L, 70L);
	    size = sh[*last];
	    angle = sa[*last];
	    if (sm[*last] < 3) {
		mode = sm[*last];
	    } else {
		mode = 1;
	    }
	    if (*which != *last) {
		sx[*which] = sx[*last] + size * (real)sin(angle * deg2rad) * 
			1.5f;
		sy[*which] = sy[*last] - size * (real)cos(angle * deg2rad) * 
			1.5f;
		sh[*which] = size;
		sa[*which] = angle;
		sc[*which] = sc[*last];
		so[*which] = so[*last];
		sm[*which] = mode;
	    }
	    vgnp_(&sc[*which]);
	    vgsmbl_(&sx[*which], &sy[*which], &size, st + *which * 70, &angle,
		     &len, 70L);
	    *last = *which;
	}
    }
    return 0;
} /* vgedt_ */

