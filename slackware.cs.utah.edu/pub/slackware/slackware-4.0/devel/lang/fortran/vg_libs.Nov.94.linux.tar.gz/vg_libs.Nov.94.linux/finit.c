/* finit.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct vgfnt_1_ {
    char f1[100], f2[100], f3[100], f4[100], f5[100], f6[100], f7[100], f8[
	    100], f9[100], f10[100], f11[100], f12[100], f13[100], f14[100], 
	    f15[100], f16[100], f17[100], f18[100], f19[100], f20[100], f21[
	    100], f22[100], f23[100], f24[100], f25[100], f26[100], f27[100], 
	    f28[100], f29[100], f30[100], f31[100], f32[100], f33[100], f34[
	    100], f35[100], f36[100], f37[100], f38[100], f39[100], f40[100], 
	    f41[100], f42[100], f43[100], f44[100], f45[100], f46[100], f47[
	    100], f48[100], f49[100], f50[100], f51[100], f52[100], f53[100], 
	    f54[100], f55[100], f56[100], f57[24];
};

#define vgfnt_1 (*(struct vgfnt_1_ *) &vgfnt_)

struct vgfpt_1_ {
    integer ifptr[256];
};

#define vgfpt_1 (*(struct vgfpt_1_ *) &vgfpt_)

/* Initialized data */

struct {
    char e_1[5624];
    } vgfnt_ = { "9G?G<F:D9A9?:<<:?9A9D:F<G?GAFDDFAG?G~~:F:F::F:FF:F~~9G@H9<"
	    "G<@H~~9G@89DGD@8~~:F@J:@@6F@@J~~8H@I>C8C=?;9@=E9C?HCBC@I~~9G@G@9"
	    "~>9@G@~~;E;EE;~>EE;;~~;E@F@:~>;CE=~>EC;=~~:F>F>B:B:>>>>:B:B>F>FB"
	    "BBBF>F~~9G@H9<G<@H~>@8GD9D@8~~<D?D=C<A<?==?<A<C=D?DACCAD?D~>=A=?"
	    "~>>B>>~>?C?=~~<D<D<<D<DD<D~>=C==~>>C>=~>?C?=~~;E@E;@@;E@@E~><@D@"
	    "~>@D@<~~:C:@C;CE:@~>=@B=~>=@BC~>@@B?~>@@BA~~=FF@=E=;F@~>C@>C~>C@"
	    ">=~>@@>A~>@@>?~~<D?D=C<A<?==?<A<C=D?DACCAD?D~>=A=?~>>B>>~>?C?=~>"
	    "@C@=~>ACA=~>BBB>~>CAC?~~<D<D<<D<DD<D~>=C==~>>C>=~>?C?=~>@C@=~>AC"
	    "A=~>BCB=~>CCC=~~;E@F;=E=@F~>@C=>~>@CC>~>@@?>~>@@A>~~;E@:EC;C@:~>"
	    "@=CB~>@==B~>@@AB~>@@?B~~;E@E;@@;E@@E~><?AD~>=>BC~>>=CB~>?<DA~~:F"
	    "@F<;FB:BD;@F~>@@@F~>@@:B~>@@<;~>@@D;~>@@FB~~5K>K;J8H6E5B5>6;88;6"
	    ">5B5E6H8J;K>KBJEHHEJBK>K~>;E:D;C<D;E~>EEDDECFDEE~>:<<:?9A9D:F<~~"
	    "8H~~;E@L@>~>@9?8@7A8@9~~8H<L<E~>DLDE~~6KAL:0~>GL@0~>:AHA~>9;G;~~"
	    "6J>P>3~>BPB3~>GIEKBL>L;K9I9G:E;D=CCAE@F?G=G:E8B7>7;89:~~4LIL77~>"
	    "<L>J>H=F;E9E7G7I8K:L<L>KAJDJGKIL~>E>C=B;B9D7F7H8I:I<G>E>~~3MJCJD"
	    "IEHEGDFBD=B:@8>7:788796;6=7?8@?D@EAGAI@K>L<K;I;G<D>AC:E8G7I7J8J9"
	    "~~<DAL?E~~9GDPBN@K>G=B=>>9@5B2D0~~9G<P>N@KBGCBC>B9@5>2<0~~8H@F@:"
	    "~>;CE=~>EC;=~~3M@I@7~>7@I@~~;EA8@7?8@9A8A6@4?3~~3M7@I@~~;E@9?8@7"
	    "A8@9~~5KIP70~~6J?L<K:H9C9@:;<8?7A7D8F;G@GCFHDKAL?L~~6J<H>IALA7~~"
	    "6J:G:H;J<K>LBLDKEJFHFFEDCA97G7~~6J;LFL@DCDECFBG?G=F:D8A7>7;8:99;"
	    "~~6JCL9>H>~>CLC7~~6JEL;L:C;D>EAEDDFBG?G=F:D8A7>7;8:99;~~6JFIEKBL"
	    "@L=K;H:C:>;:=8@7A7D8F:G=G>FADCAD@D=C;A:>~~6JGL=7~>9LGL~~6J>L;K:I"
	    ":G;E=DACDBF@G>G;F9E8B7>7;8:99;9>:@<B?CCDEEFGFIEKBL>L~~6JFEEBC@@?"
	    "??<@:B9E9F:I<K?L@LCKEIFEF@E;C8@7>7;8::~~;E@E?D@CAD@E~>@9?8@7A8@9"
	    "~~;E@E?D@CAD@E~>A8@7?8@9A8A6@4?3~~4LHI8@H7~~3M7CIC~>7=I=~~4L8IH@"
	    "87~~7I:G:H;J<K>LBLDKEJFHFFEDDC@A@>~>@9?8@7A8@9~~3NEDDFBG?G=F<E;B"
	    ";?<=><A<C=D?~>EGD?D=F<H<J>KAKCJFIHGJEKBL?L<K:J8H7F6C6@7=8;:9<8?7"
	    "B7E8G9~~7I@L87~>@LH7~>;>E>~~5J9L97~>9LBLEKFJGHGFFDECBB~>9BBBEAF@"
	    "G>G;F9E8B797~~6KHGGIEKCL?L=K;I:G9D9?:<;:=8?7C7E8G:H<~~5J9L97~>9L"
	    "@LCKEIFGGDG?F<E:C8@797~~6I:L:7~>:LGL~>:BBB~>:7G7~~6H:L:7~>:LGL~>"
	    ":BBB~~6KHGGIEKCL?L=K;I:G9D9?:<;:=8?7C7E8G:H<H?~>C?H?~~5K9L97~>GL"
	    "G7~>9BGB~~<D@L@7~~8HDLD<C9B8@7>7<8;9:<:>~~5J9L97~>GL9>~>>CG7~~6G"
	    ":L:7~>:7F7~~4L8L87~>8L@7~>HL@7~>HLH7~~5K9L97~>9LG7~>GLG7~~5K>L<K"
	    ":I9G8D8?9<::<8>7B7D8F:G<H?HDGGFIDKBL>L~~5J9L97~>9LBLEKFJGHGEFCEB"
	    "BA9A~~5K>L<K:I9G8D8?9<::<8>7B7D8F:G<H?HDGGFIDKBL>L~>A;G5~~5J9L97"
	    "~>9LBLEKFJGHGFFDECBB9B~>@BG7~~6JGIEKBL>L;K9I9G:E;D=CCAE@F?G=G:E8"
	    "B7>7;89:~~8H@L@7~>9LGL~~5K9L9=::<8?7A7D8F:G=GL~~7I8L@7~>HL@7~~4L"
	    "6L;7~>@L;7~>@LE7~>JLE7~~6J9LG7~>GL97~~7I8L@B@7~>HL@B~~6JGL97~>9L"
	    "GL~>97G7~~9GDP=P=0D0~~5K7PI0~~9G<PCPC0<0~~8H@N8@~>@NH@~~4L44L4~~"
	    "<D?LAE~~7JFEF7~>FBDDBE?E=D;B:?:=;:=8?7B7D8F:~~6I:L:7~>:B<D>EAECD"
	    "EBF?F=E:C8A7>7<8::~~7IFBDDBE?E=D;B:?:=;:=8?7B7D8F:~~7JFLF7~>FBDD"
	    "BE?E=D;B:?:=;:=8?7B7D8F:~~7I:?F?FAECDDBE?E=D;B:?:=;:=8?7B7D8F:~~"
	    ";GELCLAK@H@7~>=EDE~~7JFEF5E2D1B0?0=1~>FBDDBE?E=D;B:?:=;:=8?7B7D8"
	    "F:~~7J;L;7~>;A>D@ECEEDFAF7~~<D?L@KAL@M?L~>@E@7~~;E@LAKBLAM@L~>AE"
	    "A4@1>0<0~~7H;L;7~>EE;;~>??F7~~<D@L@7~~3M7E77~>7A9D;E=E?D@A@7~>@A"
	    "BDDEFEHDIAI7~~7J;E;7~>;A>D@ECEEDFAF7~~7J?E=D;B:?:=;:=8?7B7D8F:G="
	    "G?FBDDBE?E~~6I:E:0~>:B<D>EAECDEBF?F=E:C8A7>7<8::~~7JFEF0~>FBDDBE"
	    "?E=D;B:?:=;:=8?7B7D8F:~~9F=E=7~>=?>B@DBEEE~~8IFBEDBE?E<D;B<@>?C>"
	    "E=F;F:E8B7?7<8;:~~;G@L@;A8C7E7~>=EDE~~7J;E;;<8>7A7C8F;~>FEF7~~8H"
	    ":E@7~>FE@7~~5K8E<7~>@E<7~>@ED7~>HED7~~8I;EF7~>FE;7~~8H:E@7~>FE@7"
	    ">3<1:090~~8IFE;7~>;EFE~>;7F7~~9GBP@O?N>L>J?H@GAEAC?A=@??A=A;@9?8"
	    ">6>4?2@1B0~~<D@P@0~~9G>P@OANBLBJAH@G?E?CAAC@A??=?;@9A8B6B4A2@1>0"
	    "~~4L7@8B:C<C>BB?D>F>H?IA~~3MGI97~>7CIC~>7=I=~~7JGJFLDLCKBIAD@??<"
	    ">:<8:787787:8;:;<:?8B7D7G8I:~><ADA~~3M@I?H@GAH@I~>7@I@~>@9?8@7A8"
	    "@9~~9G?L=K<I<G=E?DADCEDGDICKAL?L~~3M=E7@=;~>7@I@~~3MCEI@C;~>7@I@"
	    "~~4MJ?I=G<E<C=B>?B>C<D:D8C7A7?8=:<<<>=?>BBCCEDGDICJAJ?~~4L@H@7~>"
	    "8@H@~>87H7~~4L;N:M;L<M;N~>ENDMELFMEN~~/P2E7E@7PX~~3M7CICCH~>I=7="
	    "=8~~4L7C8E:F<F>EBBDAFAHBID~>7=I=~~4LII7CI=~>7;I;~~3M7EIE~>7@I@~>"
	    "7;I;~~4L7IIC7=~>7;I;~~8HDICKAL?L=K<I<G=EBBD@E>E<D:B8~>>D<B;@;><<"
	    ">:C7D5D3C1A0?0=1<3~~7I@L87~>@LH7~>;>E>~~5J9L97~>9LBLEKFJGHGFFDEC"
	    "BB~>9BBBEAF@G>G;F9E8B797~~5K9L97~>GLG7~>9BGB~~7I@L87~>@LH7~>87H7"
	    "~~6I:L:7~>:LGL~>:BBB~>:7G7~~6J@L@7~>>G;F:E9C9@:>;=><B<E=F>G@GCFE"
	    "EFBG>G~~6G:L:7~>:LFL~~6J9LG7~>97GL~~<D@L@7~~4LJNJOIPGPEOCMBKAH>8"
	    "=4<2;190706162~~5J9L97~>GL9>~>>CG7~~7I@L87~>@LH7~~4L8L87~>8L@7~>"
	    "HL@7~>HLH7~~5K9L97~>9LG7~>GLG7~~5K>L<K:I9G8D8?9<::<8>7B7D8F:G<H?"
	    "HDGGFIDKBL>L~~5K9L97~>GLG7~>9LGL~~5K>L<K:I9G8D8?9<::<8>7B7D8F:G<"
	    "H?HDGGFIDKBL>L~>=BCB~~5J9L97~>9LBLEKFJGHGEFCEBBA9A~~7I9L@B97~>9L"
	    "GL~>97G7~~8H@L@7~>9LGL~~7I9G9I:K;L=L>K?I@E@7~>GGGIFKELCLBKAI@E~~"
	    "7I87@JH7~>;>E>~>AICKCLAN?N=L=K?IAI~~6J97=7:>9B9F:I<K?LALDKFIGFGB"
	    "F>C7G7~~7I9LGL~>=BCB~>97G7~~5K@L@7~>7F8F9E:A;?<>?=A=D>E?FAGEHFIF"
	    "~~6JGL97~>9LGL~>97G7~~4L7NIN~~6K?E=D;B:@9=9::8<7>7@8C;E>GBHE~>?E"
	    "AEBDCBE:F8G7H7~~7JCLAK?I=E<B;>:890~>CLELGJGGFEEDCC@C~>@CBBD@E>E;"
	    "D9C8A7?7=8<9;<~~6J7A8C:E<E=D=B<>:7~><>>B@DBEDEFCF@E;B0~~7IBE?E=D"
	    ";B:?:<;9<8>7@7B8D:E=E@DCBE@G?I?K@LBLDKFI~~8HECDDBE?E=D=B>@A?~>A?"
	    "=>;<;:<8>7A7C8E:~~5K=D;C9A8>8;99:8<7?7B8E:G=H@HCFEDEBC@?>:;0~~7J"
	    "8B:D<E=E?D@CA@A<@7~>HEGBF@@7>3=0~~7I9E;E=CC2E0G0~>HEGCE@;59280~~"
	    ":E@E>>=:=8>7@7B9C;~~7IE=E@DCCDAE?E=D;B:?:<;9<8>7@7B8D:E=FBFGEJDK"
	    "BL@L>K<I~~7I=E97~>GDFEEECD?@=?<?~><?>>?=A8B7C7D8~~8H9L;L=K>JF7~>"
	    "@E:7~~6K=E70~><A;<;9=7?7A8C:E>~>GEE>D:D8E7G7I9J;~~7I:E=E<?;::7~>"
	    "GEFBE@C=@:=8:7~~8I@E>D<B;?;<<9=8?7A7C8E:F=F@ECDDBE@E~~5K>E:7~>CE"
	    "D?E:F7~>7B9D<EIE~~5J6A7C9E;E<D<B;=;:<8=7?7A8C;D=E@FEFHEKCLAL@J@H"
	    "AECBE@H>~~7I;?;<<9=8?7A7C8E:F=F@ECDDBE@E>D<B;?70~~7KIE?E=D;B:?:<"
	    ";9<8>7@7B8D:E=E@DCCDAE~~6JAE>7~>8B:D=EHE~~6J7A8C:E<E=D=B;<;9=7?7"
	    "B8D:F>GBGE~~6J979H:J;K>LBLEKFIFGEECD?CACDBF@G>G;F9E8B7>7;9~~4K<E"
	    ":D8A7>7;8897;7=8?;~>@??;@8A7C7E8G;H>HAGDFE~~8HBL@K?J?I@HCGFG~>CG"
	    "@F>E=C=A??B>D>~>B>>=<<;:;8=6A4B3B1@0>0~~4KDL<0~>5A6C8E:E;D;B:=::"
	    ";8=7?7B8D:F=HBIE~~8GBL@K?J?I@HCGFG~>FGBE?C<@;=;;<9>7A5B3B1A0?0>2"
	    "~~4L7C8E:F<F>EBBDAFAHBID~>7=8?:@<@>?B<D;F;H<I>~~>C@A@@A@AA@A~~" };

struct {
    integer e_1[256];
    } vgfpt_ = { 1, 39, 53, 65, 77, 91, 117, 131, 145, 165, 195, 217, 265, 
	    297, 323, 359, 395, 467, 523, 559, 595, 633, 5611, 0, 0, 0, 0, 0, 
	    0, 0, 0, 679, 763, 767, 787, 801, 827, 883, 949, 1021, 1029, 1053,
	     1077, 1097, 1111, 1131, 1139, 1153, 1161, 1199, 1211, 1243, 1277,
	     1293, 1331, 1381, 1395, 1457, 1507, 1533, 1565, 1575, 1589, 1599,
	     1643, 1731, 1751, 1801, 1841, 1875, 1901, 1921, 1969, 1989, 1997,
	     2021, 2041, 2055, 2081, 2101, 2147, 2177, 2229, 2265, 2309, 2323,
	     2347, 2361, 2387, 2401, 2417, 2437, 2449, 2457, 2469, 2483, 2491,
	     2499, 2537, 2575, 2607, 2645, 2683, 2703, 2751, 2775, 2795, 2821,
	     2841, 2849, 2889, 2913, 2951, 2989, 3027, 3047, 3085, 3105, 3129,
	     3143, 3169, 3183, 3205, 3225, 3271, 3279, 3325, 0, 1, 39, 53, 65,
	     77, 91, 117, 131, 145, 165, 195, 217, 265, 297, 323, 359, 395, 
	    467, 523, 559, 595, 633, 5611, 0, 0, 0, 0, 0, 0, 0, 0, 679, 0, 0, 
	    0, 3349, 3369, 3423, 0, 3455, 3485, 3501, 3517, 3571, 0, 0, 3591, 
	    3617, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3629, 3647, 3677, 3693, 3713, 
	    1599, 3729, 3791, 3811, 3861, 3881, 3901, 3927, 3971, 3985, 3999, 
	    4007, 4043, 4063, 4077, 4103, 4123, 4169, 4189, 4241, 4271, 4293, 
	    4307, 4347, 4383, 4419, 4439, 4477, 0, 2449, 0, 0, 4497, 2491, 
	    4505, 4555, 4619, 4659, 4709, 4749, 4793, 4829, 4859, 4879, 4933, 
	    4973, 4993, 5037, 5067, 5105, 5133, 5189, 5229, 5267, 5285, 5319, 
	    5367, 5415, 5475, 5517, 0, 3271, 0, 5565, 0 };


/* ***********************************************************************
 */
/*     INITIALIZE CHARACTER FONT FROM THE HERSHEY FONTS */
/*     URSULA KATTNER, NBS, 6 OCTOBER 1987  -  VERSION 1.0 */
/*     MODIFIED BY G. CANDELA & D. KAHANER */
/* ***********************************************************************
 */







