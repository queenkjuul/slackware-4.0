/* legnd.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"
#include "agraf.h"

/* Common Block Declarations */

struct {
    logical lbox;
    integer leglin;
} vgleg3_;

#define vgleg3_1 vgleg3_

struct {
    integer lsyms[84]	/* was [14][6] */, lcolrs[84]	/* was [14][6] */, 
	    lstys[84]	/* was [14][6] */, nlines[6];
    real hh[6], vv[6], xleg[7], yleg[7];
    integer isleg[7], legset[7], legvis[6];
} vgleg1_;

#define vgleg1_1 vgleg1_

struct {
    char clegs[3360]	/* was [14][6] */;
} vgleg2_;

#define vgleg2_1 vgleg2_

struct {
    real offstl[7];
} vgleg4_;

#define vgleg4_1 vgleg4_

struct {
    real size;
} vghgt_;

#define vghgt_1 vghgt_

/* Table of constant values */

static integer c__1 = 1;
static integer c__3 = 3;
static integer c__2 = 2;
static real c_b10 = 0.f;
static integer c_n1 = -1;
static real c_b45 = 25.f;
static real c_b47 = 18.75f;

/* Subroutine */ int vgldr_(integer *nlines, char *clegs, integer *lsyms, 
	integer *lcolrs, integer *lstys, real *xleg, real *yleg, real *hh, 
	real *vv, real *offset, real *size, ftnlen clegs_len)
{
    /* System generated locals */
    integer i__1;
    real r__1, r__2;

    /* Local variables */
    static integer ipen;
    extern /* Subroutine */ int vgpl_(real *, real *, integer *), vgnp_(
	    integer *);
    static integer i__, idash;
    static real y;
    extern /* Subroutine */ int vgsbl_(real *, real *, real *, integer *, 
	    real *, integer *), vgsmb_(real *, real *, real *, char *, real *,
	     integer *, ftnlen);
    static integer inteq;
    static real x1, y1, dstart;
    extern /* Subroutine */ int vgapts_(real *, real *, real *, real *, 
	    integer *, real *, integer *, integer *, integer *);

/*           ORIGINAL NAME LDRAW */
/*  DRAWS A LEGEND. */
    /* Parameter adjustments */
    --lstys;
    --lcolrs;
    --lsyms;
    clegs -= 40;

    /* Function Body */
    x1 = *xleg - *hh * .5f;
    y1 = *yleg - *vv * .5f;
    vgnp_(&c__1);
/*  DRAW FRAME AROUND LEGEND IF DESIRED. */
    if (vgleg3_1.lbox) {
	vgpl_(&x1, &y1, &c__3);
	r__1 = x1 + *hh;
	vgpl_(&r__1, &y1, &c__2);
	r__1 = x1 + *hh;
	r__2 = y1 + *vv;
	vgpl_(&r__1, &r__2, &c__2);
	r__1 = y1 + *vv;
	vgpl_(&x1, &r__1, &c__2);
	vgpl_(&x1, &y1, &c__2);
    }
    i__1 = *nlines;
    for (i__ = 1; i__ <= i__1; ++i__) {
	idash = 1;
	ipen = 2;
	vgnp_(&lcolrs[i__]);
	y = y1 + *vv - i__ * *size - (i__ - 1.f) * .5f * *size;
	if (lstys[i__] > 0) {
/*             SET VARIABLE DSTART TO 0.0 HERE. WAS THE CONSTANT 0
. IN */
/*               CALL TO VGAPTS AND WAS BEING CHANGED. DKK 2/2/89 
*/
	    dstart = 0.f;
	    r__1 = x1 + *size;
	    r__2 = x1 + *size * 7.f;
	    vgapts_(&r__1, &y, &r__2, &y, &lstys[i__], &dstart, &idash, &ipen,
		     &c__2);
	}
	if (lsyms[i__] > 0) {
	    inteq = lsyms[i__] - 1;
	    r__1 = x1 + *size;
	    vgsbl_(&r__1, &y, size, &inteq, &c_b10, &c_n1);
	    if (lstys[i__] > 0) {
		r__1 = x1 + *size * 4.f;
		vgsbl_(&r__1, &y, size, &inteq, &c_b10, &c_n1);
		r__1 = x1 + *size * 7.f;
		vgsbl_(&r__1, &y, size, &inteq, &c_b10, &c_n1);
	    }
	}
	r__1 = x1 + *offset * *size;
	vgsmb_(&r__1, &y, size, clegs + i__ * 40, &c_b10, &lcolrs[i__], 40L);
/* L100: */
    }
    vgpl_(&c_b10, &c_b10, &c__3);
    return 0;
} /* vgldr_ */

/* Subroutine */ int vglmv_(integer *ng, integer *kg)
{
    /* Initialized data */

    static integer zero = 0;
    static integer kor[6] = { 0,0,0,0,0,0 };

    /* System generated locals */
    integer i__1;
    real r__1, r__2;

    /* Local variables */
    extern /* Subroutine */ int vgpl_(real *, real *, integer *), vgnp_(
	    integer *);
    static real zbot, zrit, wtop, ztop;
    static integer i__, kflag;
    static real x, y;
    extern /* Subroutine */ int sleep_(integer *), vgldr_(integer *, char *, 
	    integer *, integer *, integer *, real *, real *, real *, real *, 
	    real *, real *, ftnlen), vgcor_(real *, real *, real *, real *);
    static real wleft, zleft;
    static integer kcurr;
    static char ch[1];
    static real am;
    extern logical agrafa_(integer *, integer *, integer *, integer *);
    static integer isides;
    extern /* Subroutine */ int vgcorf_(integer *, real *, real *, integer *, 
	    integer *, real *, real *, real *, real *, real *, real *, real *,
	     real *);
    extern integer vgiaro_(integer *);
    static real hgt, wid;

/*  FOR MOVING LEGENDS FROM THE KEYBOARD. */
    i__1 = *ng;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (vgleg1_1.isleg[i__ - 1] == 1) {
	    goto L20;
	}
/* L10: */
    }
    return 0;
L20:
    *kg = i__;
    am = .9375f;
    isides = 0;
L90:
    zleft = vgleg1_1.xleg[*kg - 1] - vgleg1_1.hh[*kg - 1] * .5f;
    zrit = vgleg1_1.xleg[*kg - 1] + vgleg1_1.hh[*kg - 1] * .5f;
    ztop = vgleg1_1.yleg[*kg - 1] + vgleg1_1.vv[*kg - 1] * .5f;
    zbot = vgleg1_1.yleg[*kg - 1] - vgleg1_1.vv[*kg - 1] * .5f;
    vgcor_(&zleft, &zrit, &ztop, &zbot);
    sleep_(&c__2);
    vgcor_(&zleft, &zrit, &ztop, &zbot);
L100:
    if (! agrafa_(&zero, &c__1, &kcurr, &kflag)) {
	goto L100;
    }
    *(unsigned char *)ch = (char) kcurr;
    if (kcurr == 32) {
L110:
	++(*kg);
	if (*kg > *ng) {
	    *kg = 1;
	}
	if (vgleg1_1.isleg[*kg - 1] == 0) {
	    goto L110;
	}
	goto L90;
    }
    if (kcurr == 8) {
L120:
	--(*kg);
	if (*kg < 1) {
	    *kg = *ng;
	}
	if (vgleg1_1.isleg[*kg - 1] == 0) {
	    goto L120;
	}
	goto L90;
    }
    if (*(unsigned char *)ch == 'F' || *(unsigned char *)ch == 'f') {
	am = .09375f;
	goto L100;
    } else if (*(unsigned char *)ch == 'C' || *(unsigned char *)ch == 'c') {
	am = .9375f;
	goto L100;
    } else if (*(unsigned char *)ch == 'V' || *(unsigned char *)ch == 'v') {
	if (vgleg1_1.legvis[*kg - 1] == 1) {
	    wid = vgleg1_1.hh[*kg - 1];
	    hgt = vgleg1_1.vv[*kg - 1];
	    x = vgleg1_1.xleg[*kg - 1] - wid * .5f;
	    y = vgleg1_1.yleg[*kg - 1] - hgt * .5f;
/*  DRAW AN 'X' THROUGH THE LEGEND TO DENOTE THAT IT'S INVISIBLE. 
*/
	    vgnp_(&c__1);
	    vgpl_(&x, &y, &c__3);
	    r__1 = x + wid;
	    r__2 = y + hgt;
	    vgpl_(&r__1, &r__2, &c__2);
	    r__1 = y + hgt;
	    vgpl_(&x, &r__1, &c__3);
	    r__1 = x + wid;
	    vgpl_(&r__1, &y, &c__2);
	    vgpl_(&c_b10, &c_b10, &c__3);
	    vgleg1_1.legvis[*kg - 1] = 0;
	} else {
	    vgldr_(&vgleg1_1.nlines[*kg - 1], vgleg2_1.clegs + (*kg * 14 - 14)
		     * 40, &vgleg1_1.lsyms[*kg * 14 - 14], &vgleg1_1.lcolrs[*
		    kg * 14 - 14], &vgleg1_1.lstys[*kg * 14 - 14], &
		    vgleg1_1.xleg[*kg - 1], &vgleg1_1.yleg[*kg - 1], &
		    vgleg1_1.hh[*kg - 1], &vgleg1_1.vv[*kg - 1], &
		    vgleg4_1.offstl[*kg - 1], &vghgt_1.size, 40L);
	    vgleg1_1.legvis[*kg - 1] = 1;
	}
    }
    if (vgiaro_(&kcurr) == 1) {
	if (kor[*kg - 1] == 0) {
	    vgcor_(&zleft, &zrit, &ztop, &zbot);
	    kor[*kg - 1] = 1;
	}
	vgcor_(&zleft, &zrit, &ztop, &zbot);
	wleft = zleft;
	wtop = ztop;
	vgcorf_(&isides, &am, &c_b10, &kcurr, &kflag, &c_b10, &c_b45, &c_b10, 
		&c_b47, &zleft, &zrit, &zbot, &ztop);
	vgleg1_1.xleg[*kg - 1] = vgleg1_1.xleg[*kg - 1] + zleft - wleft;
	vgleg1_1.yleg[*kg - 1] = vgleg1_1.yleg[*kg - 1] + ztop - wtop;
	vgcor_(&zleft, &zrit, &ztop, &zbot);
	goto L100;
    }
    if (*(unsigned char *)ch == 'D' || *(unsigned char *)ch == 'd') {
	i__1 = *ng;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if (vgleg1_1.isleg[i__ - 1] == 1 && kor[i__ - 1] == 1 && 
		    vgleg1_1.legvis[i__ - 1] == 1) {
		zleft = vgleg1_1.xleg[i__ - 1] - vgleg1_1.hh[i__ - 1] * .5f;
		zrit = vgleg1_1.xleg[i__ - 1] + vgleg1_1.hh[i__ - 1] * .5f;
		ztop = vgleg1_1.yleg[i__ - 1] + vgleg1_1.vv[i__ - 1] * .5f;
		zbot = vgleg1_1.yleg[i__ - 1] - vgleg1_1.vv[i__ - 1] * .5f;
		vgcor_(&zleft, &zrit, &ztop, &zbot);
		vgldr_(&vgleg1_1.nlines[i__ - 1], vgleg2_1.clegs + (i__ * 14 
			- 14) * 40, &vgleg1_1.lsyms[i__ * 14 - 14], &
			vgleg1_1.lcolrs[i__ * 14 - 14], &vgleg1_1.lstys[i__ * 
			14 - 14], &vgleg1_1.xleg[i__ - 1], &vgleg1_1.yleg[i__ 
			- 1], &vgleg1_1.hh[i__ - 1], &vgleg1_1.vv[i__ - 1], &
			vgleg4_1.offstl[i__ - 1], &vghgt_1.size, 40L);
		kor[i__ - 1] = 0;
	    }
/* L200: */
	}
	return 0;
    }
    goto L100;
} /* vglmv_ */

