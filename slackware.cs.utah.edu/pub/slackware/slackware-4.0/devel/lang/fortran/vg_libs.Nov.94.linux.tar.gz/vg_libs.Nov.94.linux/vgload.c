/* vgload.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct vglttr_1_ {
    real bbot0[7], btop0[7], bleft0[7], brit0[7];
    integer isdx[7], isdy1[7], isdy2[7], kludge[7], axcol;
};

#define vglttr_1 (*(struct vglttr_1_ *) &vglttr_)

struct vgleg1_1_ {
    integer lsyms[84]	/* was [14][6] */, lcolrs[84]	/* was [14][6] */, 
	    lstys[84]	/* was [14][6] */, nlines[6];
    real hh[6], vv[6], xleg[7], yleg[7];
    integer isleg[7], legset[7], legvis[6];
};

#define vgleg1_1 (*(struct vgleg1_1_ *) &vgleg1_)

struct vgleg3_1_ {
    logical lbox;
    integer leglin;
};

#define vgleg3_1 (*(struct vgleg3_1_ *) &vgleg3_)

struct vgtx1_1_ {
    real sx[50], sy[50], sa[50], sh[50];
    integer sc[50], so[50], sm[50], ntex;
};

#define vgtx1_1 (*(struct vgtx1_1_ *) &vgtx1_)

struct vgloop_1_ {
    logical pass1;
    integer jexit, mdevic, istat;
    logical pass2;
};

#define vgloop_1 (*(struct vgloop_1_ *) &vgloop_)

struct vgscrn_1_ {
    real sht, swd;
    integer ncols, nrows;
};

#define vgscrn_1 (*(struct vgscrn_1_ *) &vgscrn_)

struct vgfil1_1_ {
    char filnam[6], exten[3];
};

#define vgfil1_1 (*(struct vgfil1_1_ *) &vgfil1_)

struct vgfil2_1_ {
    integer numpag;
};

#define vgfil2_1 (*(struct vgfil2_1_ *) &vgfil2_)

struct vgcntr_1_ {
    integer ig;
};

#define vgcntr_1 (*(struct vgcntr_1_ *) &vgcntr_)

struct vgsbnd_1_ {
    real smin[21]	/* was [7][3] */, smax[21]	/* was [7][3] */;
    integer limflg[21]	/* was [7][3] */;
    real tmin[21]	/* was [7][3] */, tmax[21]	/* was [7][3] */;
};

#define vgsbnd_1 (*(struct vgsbnd_1_ *) &vgsbnd_)

struct vgssiz_1_ {
    real subsz, suprsz;
};

#define vgssiz_1 (*(struct vgssiz_1_ *) &vgssiz_)

struct vgcrv1_1_ {
    integer idmark;
};

#define vgcrv1_1 (*(struct vgcrv1_1_ *) &vgcrv1_)

struct vghgt_1_ {
    real height;
};

#define vghgt_1 (*(struct vghgt_1_ *) &vghgt_)

struct vglab_1_ {
    integer labels[28];
};

#define vglab_1 (*(struct vglab_1_ *) &vglab_)

struct vgprnt_1_ {
    logical pb4xit;
};

#define vgprnt_1 (*(struct vgprnt_1_ *) &vgprnt_)

struct vgusrc_1_ {
    char commnt[80];
};

#define vgusrc_1 (*(struct vgusrc_1_ *) &vgusrc_)

struct vglim_1_ {
    real bleft1[7], brit1[7], bbot1[7], btop1[7], bxmin[7], bxmax[7], bymin[
	    14]	/* was [7][2] */, bymax[14]	/* was [7][2] */;
    integer ninlx[7], naxlx[7], ninly[14]	/* was [7][2] */, naxly[14]	
	    /* was [7][2] */, msx[7], msy[14]	/* was [7][2] */;
};

#define vglim_1 (*(struct vglim_1_ *) &vglim_)

struct vgtick_1_ {
    real tikx1[7], tikx2[7], tiky1[7], tiky2[7];
};

#define vgtick_1 (*(struct vgtick_1_ *) &vgtick_)

struct vgzoom_1_ {
    integer ipoint[6];
};

#define vgzoom_1 (*(struct vgzoom_1_ *) &vgzoom_)

/* Initialized data */

struct {
    real e_1;
    integer fill_2[6];
    real e_3;
    integer fill_4[6];
    real e_5;
    integer fill_6[6];
    real e_7;
    integer fill_8[27];
    integer e_9[8];
    } vglttr_ = { 0.f, {0}, 18.75f, {0}, 0.f, {0}, 25.f, {0}, 0, 0, 0, 0, 0, 
	    0, 0, 1 };

struct {
    integer fill_1[42];
    integer e_2[21];
    integer fill_3[42];
    } vgsbnd_ = { {0}, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0 };

struct {
    real e_1[2];
    } vgssiz_ = { .7f, .7f };

struct {
    integer e_1;
    } vgcrv1_ = { 0 };

struct {
    real e_1;
    } vghgt_ = { .35f };

struct {
    integer e_1[28];
    } vglab_ = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	    0, 0, 0, 0, 0, 0, 0, 0 };

struct {
    logical e_1;
    } vgprnt_ = { FALSE_ };

struct {
    char e_1[80];
    } vgusrc_ = { "                                                         "
	    "                       " };

struct {
    integer fill_1[112];
    integer e_2[21];
    } vglim_ = { {0}, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	     0, 0 };

struct {
    real e_1[28];
    } vgtick_ = { .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, 
	    .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, .35f, 
	    .35f, .35f, .35f, .35f, .35f, .35f, .35f };

struct {
    integer e_1[6];
    } vgzoom_ = { 0, 0, 0, 0, 0, 0 };

struct {
    integer fill_1[252];
    integer e_2[6];
    integer fill_3[26];
    integer e_4[20];
    } vgleg1_ = { {0}, 0, 0, 0, 0, 0, 0, {0}, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	     0, 0, 0, 1, 1, 1, 1, 1, 1 };

struct {
    logical e_1;
    integer e_2;
    } vgleg3_ = { TRUE_, 0 };

struct {
    real e_1;
    integer fill_2[49];
    real e_3;
    integer fill_4[49];
    real e_5;
    integer fill_6[49];
    real e_7;
    integer fill_8[49];
    integer e_9;
    integer fill_10[49];
    integer e_11;
    integer fill_12[49];
    integer e_13;
    integer fill_14[49];
    integer e_15;
    } vgtx1_ = { 0.f, {0}, 1.f, {0}, 0.f, {0}, .35f, {0}, 1, {0}, 1, {0}, 1, {
	    0}, 0 };

struct {
    logical e_1;
    integer e_2[3];
    logical e_3;
    } vgloop_ = { TRUE_, -1, 22, 0, FALSE_ };

struct {
    real e_1[2];
    integer fill_2[2];
    } vgscrn_ = { 18.75f, 25.f };

struct {
    char e_1[9];
    } vgfil1_ = { "VG    POS" };

struct {
    integer e_1;
    } vgfil2_ = { 1 };

struct {
    integer e_1;
    } vgcntr_ = { 1 };


/* INITIALIZES THE COMMON BLOCKS USED BY VG */

/*       Force exit character to be nonzero unless set by user. */
/*       DKK (28 Feb 1989) */

