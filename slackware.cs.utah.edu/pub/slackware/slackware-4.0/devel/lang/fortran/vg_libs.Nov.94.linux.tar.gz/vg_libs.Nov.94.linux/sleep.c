/* sleep in tenth of seconds */

#include <unistd.h>
#include <f2c.h>

void
sleep_(tenths)
integer *tenths;
{
	unsigned long musecs;

	musecs = 100000UL * (*tenths);
	usleep(musecs);
}
