/* cursor.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Subroutine */ int vgcurs_(real *x, real *y)
{
/*  DUMMY SUBROUTINE TO BE REPLACED BY USER'S CURSOR DATA LOGGING */
/*  ROUTINE. */
    return 0;
} /* vgcurs_ */

