/* plot.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"
#include "agraf.h"

/* Common Block Declarations */

struct {
    integer idevic, idst, npen;
} vgpnf_;

#define vgpnf_1 vgpnf_

struct {
    logical baton;
} vgbt_;

#define vgbt_1 vgbt_

struct {
    real subsz, suprsz;
} vgssiz_;

#define vgssiz_1 vgssiz_

struct {
    char font[5624];
} vgfnt_;

#define vgfnt_1 vgfnt_

struct {
    integer ifptr[256];
} vgfpt_;

#define vgfpt_1 vgfpt_

/* Table of constant values */

static integer c__1 = 1;
static integer c__2 = 2;
static integer c__6 = 6;
static integer c__4 = 4;
static integer c__3 = 3;
static real c_b203 = 360.f;
static integer c_n16 = -16;
static integer c__0 = 0;
static integer c_n1 = -1;


/* Subroutine */ int vgpl_0_(int n__, real *xpage, real *ypage, integer *ipen,
	 integer *idcol0, integer *idrow0, integer *inp, real *rxpage, real *
	rypage, real *rfact)
{
    /* Initialized data */

    static char pc[1*2] = "D" "U";

    /* Format strings */
    static char fmt_20[] = "(2(\002,\002,i5))";
    static char fmt_30[] = "(\002^\002,a1,i5.5,\002:\002,i5.5)";
    static char fmt_40[] = "(2i5,a2)";
    static char fmt_100[] = "(a)";
    static char fmt_410[] = "(2a1)";
    static char fmt_420[] = "(\002SP\002,i2,\002;\002)";
    static char fmt_430[] = "(\002^PW\002,i2.2)";
    static char fmt_440[] = "(i2,\002 setlinewidth\002)";

    /* System generated locals */
    address a__1[2], a__2[6], a__3[4];
    integer i__1[2], i__2[6], i__3, i__4[4];
    real r__1;
    char ch__1[133], ch__2[4], ch__3[6], ch__4[2], ch__5[1];
    icilist ici__1;
    olist o__1;
    cllist cl__1;

    /* Builtin functions */
    integer i_nint(real *), s_wsfe(cilist *), do_fio(integer *, char *, 
	    ftnlen), e_wsfe(void);
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen),
	     s_copy(char *, char *, ftnlen, ftnlen);
    integer s_wsfi(icilist *), e_wsfi(void), f_clos(cllist *), f_open(olist *)
	    , s_rsfe(cilist *), e_rsfe(void), s_cmp(char *, char *, ftnlen, 
	    ftnlen);

    /* Local variables */
    static char temp[132], term[3];
    static logical outb0;
    static integer l, ipath;
    static logical lnpen, outbl;
    static integer jdcol0, jdrow0;
    static char ff[1];
    static integer ii;
    static real fl;
    static integer ip;
    static char gs[1];
    static integer ix[51], iy[51];
    static real xl, yl, px, py, rx, ry;
    static char string[132];
    static integer ip0, ix0, iy0, nx0, ny0;
    static real px0, py0;
    static char esc[1], lsb[1];
    static integer ipl;
    static char hix[1], hiy[1];
    static integer ixl, iyl;
    static char lox[1], loy[1];
    static integer nxm, nym;

    /* Fortran I/O blocks */
    static cilist io___19 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___24 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___25 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___26 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___27 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___28 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___34 = { 0, 60, 0, fmt_100, 0 };
    static icilist io___41 = { 0, string+2, 0, fmt_20, 12, 1 };
    static cilist io___42 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___43 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___45 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___46 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___47 = { 0, 60, 0, fmt_100, 0 };
    static icilist io___48 = { 0, string+2, 0, fmt_20, 12, 1 };
    static cilist io___49 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___50 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___52 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___53 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___54 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___55 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___56 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___57 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___58 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___59 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___60 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___61 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___64 = { 0, 50, 0, fmt_100, 0 };
    static cilist io___65 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___66 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___67 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___68 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___69 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___70 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___71 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___72 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___77 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___78 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___79 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___80 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___81 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___82 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___83 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___84 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___85 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___86 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___87 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___88 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___89 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___90 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___91 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___92 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___93 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___94 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___95 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___96 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___97 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___98 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___99 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___100 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___101 = { 0, 60, 0, fmt_100, 0 };
    static cilist io___103 = { 0, 60, 0, fmt_410, 0 };
    static cilist io___104 = { 0, 60, 0, fmt_420, 0 };
    static cilist io___105 = { 0, 60, 0, fmt_430, 0 };
    static cilist io___106 = { 0, 60, 0, fmt_440, 0 };
    static cilist io___107 = { 0, 60, 0, fmt_420, 0 };


/*           ORIGINALLY CALLED PLOT */
/*           U. KATTNER [MODIFICATIONS: W. ANDERSON, D. KAHANER] (NIST) */
/* .....VARIABLES USED IN PLOTS */
/*      INTEGER IBUF(*),NLOC,LDEV */
/* .....VARIABLES USED IN VGNP */
/* .....VARIABLES USED IN VGWR */



    switch(n__) {
	case 1: goto L_vgplts;
	case 2: goto L_vgsiz;
	case 3: goto L_vgnp;
	case 4: goto L_vgwr;
	}



/* L20: */
/* L30: */
/* L40: */
/* L100: */

/* -----------------------------------------------------------------------
 */
/*     |IPEN| = 2   : "PEN DOWN" DURING MOVEMENT */
/*            = 3   : "PEN UP"   DURING MOVEMENT */
/*      IPEN  < 0   : DEFINE NEW ORIGIN */
/*      IPEN  = 999 : FINISH PLOTTING AND EXIT GRAPHIC MODE */
/* -----------------------------------------------------------------------
 */

    lnpen = FALSE_;
    ip0 = *ipen;

L1000:
    xl = *xpage;
    yl = *ypage;

L1010:
    if (ip0 == 999) {
	ip = 3;
    } else {
	ip = abs(ip0);
    }
    ipl = ip;
    r__1 = xl * px;
    ix0 = nx0 + i_nint(&r__1);
    r__1 = yl * py;
    iy0 = ny0 + i_nint(&r__1);
    outb0 = ix0 < 0 || ix0 > nxm || iy0 < 0 || iy0 > nym;
    if (ip == 2 && outb0 && outbl) {
	goto L1900;
    }
    if (ip == 2 && outbl && ! outb0) {
	ip = 3;
    }

/* .... IF NEW LINE PLOT BUFFER CONTENT */

    if (ip == 3 && l > 0) {
	if (vgpnf_1.idevic < 10) {
	    if (l > 6) {
		s_wsfe(&io___19);
		do_fio(&c__1, string, l);
		e_wsfe();
	    }
	} else if (vgpnf_1.idevic < 20) {
	    if (l > 1 && ! vgbt_1.baton) {
		agraff_(&ii, &vgpnf_1.idst, &l, ix, iy);
	    }
	} else if (vgpnf_1.idevic == 20) {
	    if (*(unsigned char *)&string[1] == 'D' || l > 16) {
		s_wsfe(&io___24);
/* Writing concatenation */
		i__1[0] = l, a__1[0] = string;
		i__1[1] = 1, a__1[1] = ";";
		s_cat(ch__1, a__1, i__1, &c__2, 133L);
		do_fio(&c__1, ch__1, l + 1);
		e_wsfe();
	    }
	} else if (vgpnf_1.idevic == 21) {
	    if (*(unsigned char *)&string[1] == 'D' || l > 13) {
		s_wsfe(&io___25);
		do_fio(&c__1, string, l);
		e_wsfe();
	    }
	} else if (vgpnf_1.idevic == 22 || vgpnf_1.idevic == 24) {
	    if (*(unsigned char *)&string[11] == 'D' || l > 12) {
		s_wsfe(&io___26);
		do_fio(&c__1, string, l);
		e_wsfe();
		s_wsfe(&io___27);
		do_fio(&c__1, "stroke", 6L);
		e_wsfe();
	    }
	} else if (vgpnf_1.idevic == 23) {
	    if (*(unsigned char *)&string[1] == 'D' || l > 16) {
		s_wsfe(&io___28);
/* Writing concatenation */
		i__1[0] = l, a__1[0] = string;
		i__1[1] = 1, a__1[1] = ";";
		s_cat(ch__1, a__1, i__1, &c__2, 133L);
		do_fio(&c__1, ch__1, l + 1);
		e_wsfe();
	    }
	}
	l = 0;
    }
    if (lnpen) {
	goto L4000;
    }
    if (ip0 == 999) {
	goto L1999;
    }
    if (ip == 2 && ! outb0 && ! outbl) {
	goto L1100;
    }
    if (ipl == 3 && ! outb0) {
	goto L1100;
    }
    if (ipl == 3 && outb0) {
	goto L1900;
    }

/* .... CLIP CURVE IF IT LEAVES THE PLOT AREA */

    if (ix0 == ixl) {
	rx = 0.f;
    } else {
	rx = (real) (iyl - iy0) / (real) (ixl - ix0);
    }
    if (iy0 == iyl) {
	ry = 0.f;
    } else {
	ry = (real) (ixl - ix0) / (real) (iyl - iy0);
    }
    if (ix0 < 0 || ixl < 0) {
	r__1 = (real) (-ix0) * rx;
	iy0 += i_nint(&r__1);
	ix0 = 0;
    } else if (ix0 > nxm || ixl > nxm) {
	r__1 = (real) (nxm - ix0) * rx;
	iy0 += i_nint(&r__1);
	ix0 = nxm;
    }
    if (iy0 < 0 || iyl < 0) {
	r__1 = (real) (-iy0) * ry;
	ix0 += i_nint(&r__1);
	iy0 = 0;
    } else if (iy0 > nym || iyl > nym) {
	r__1 = (real) (nym - iy0) * ry;
	ix0 += i_nint(&r__1);
	iy0 = nym;
    }

/* .... PLOT THE POINT */

L1100:
    if (vgpnf_1.idevic < 10) {
/* .... Encode X,Y for Tektronix and store in string */
	if (ip == 3) {
	    s_copy(string, gs, 132L, 1L);
	    l = 1;
	} else {
	    if (l > 75) {
		s_wsfe(&io___34);
		do_fio(&c__1, string, l);
		e_wsfe();
/* Writing concatenation */
		i__1[0] = 1, a__1[0] = gs;
		i__1[1] = 1, a__1[1] = string + (l - 1);
		s_cat(temp, a__1, i__1, &c__2, 132L);
		s_copy(string, temp, 132L, 132L);
		l = 2;
	    }
	}
	*(unsigned char *)hiy = (char) (iy0 / 128 % 32 + 32);
	*(unsigned char *)lsb = (char) (ix0 % 4 + 96 + (iy0 % 4 << 2));
	*(unsigned char *)loy = (char) (iy0 / 4 % 32 + 96);
	*(unsigned char *)hix = (char) (ix0 / 128 % 32 + 32);
	*(unsigned char *)lox = (char) (ix0 / 4 % 32 + 64);
/* Writing concatenation */
	i__2[0] = l, a__2[0] = string;
	i__2[1] = 1, a__2[1] = hiy;
	i__2[2] = 1, a__2[2] = lsb;
	i__2[3] = 1, a__2[3] = loy;
	i__2[4] = 1, a__2[4] = hix;
	i__2[5] = 1, a__2[5] = lox;
	s_cat(temp, a__2, i__2, &c__6, 132L);
	s_copy(string, temp, 132L, 132L);
	l += 5;
    } else if (vgpnf_1.idevic < 20) {
/* .....STORE X AND Y IN IX AND IY, CALL AGRAFF FOR IBM-PC */
	if (l == 51) {
	    agraff_(&ii, &vgpnf_1.idst, &l, ix, iy);
	    ix[0] = ix[50];
	    iy[0] = iy[50];
	    l = 1;
	}
	++l;
	ix[l - 1] = ix0;
	iy[l - 1] = iy0;
    } else if (vgpnf_1.idevic == 20) {
/* .....STORE X AND Y IN STRING WITH HPGL SYNTAX */
	if (ip == 3) {
	    s_copy(string, "PU", 132L, 2L);
	    s_wsfi(&io___41);
	    do_fio(&c__1, (char *)&ix0, (ftnlen)sizeof(integer));
	    do_fio(&c__1, (char *)&iy0, (ftnlen)sizeof(integer));
	    e_wsfi();
/* Writing concatenation */
	    i__1[0] = 14, a__1[0] = string;
	    i__1[1] = 2, a__1[1] = "PD";
	    s_cat(temp, a__1, i__1, &c__2, 132L);
	    s_copy(string, temp, 132L, 132L);
	    l = 16;
	} else {
	    if (l > 119) {
		s_wsfe(&io___42);
/* Writing concatenation */
		i__1[0] = l, a__1[0] = string;
		i__1[1] = 1, a__1[1] = ";";
		s_cat(ch__1, a__1, i__1, &c__2, 133L);
		do_fio(&c__1, ch__1, l + 1);
		e_wsfe();
		s_copy(string, "PD", 132L, 2L);
		l = 2;
	    }
	    l += 12;
	    i__3 = l - 12;
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = l - i__3;
	    ici__1.iciunit = string + i__3;
	    ici__1.icifmt = fmt_20;
	    s_wsfi(&ici__1);
	    do_fio(&c__1, (char *)&ix0, (ftnlen)sizeof(integer));
	    do_fio(&c__1, (char *)&iy0, (ftnlen)sizeof(integer));
	    e_wsfi();
	}
    } else if (vgpnf_1.idevic == 21) {
/* .....STORE X AND Y IN STRING WITH QMS SYNTAX */
	if (l > 119) {
	    s_wsfe(&io___43);
	    do_fio(&c__1, string, l);
	    e_wsfe();
	    l = 0;
	}
	l += 13;
	i__3 = l - 13;
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = l - i__3;
	ici__1.iciunit = string + i__3;
	ici__1.icifmt = fmt_30;
	s_wsfi(&ici__1);
	do_fio(&c__1, pc + (ip - 2), 1L);
	do_fio(&c__1, (char *)&ix0, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&iy0, (ftnlen)sizeof(integer));
	e_wsfi();
    } else if (vgpnf_1.idevic == 22 || vgpnf_1.idevic == 24) {
/* .....STORE X AND Y IN STRING WITH POSTSCRIPT SYNTAX */
	if (l > 120) {
/*           IN CASE THERE ARE TOO MANY POINTS, PUT OUT FIRST PART
 */
	    if (ipath > 1000) {
		s_wsfe(&io___45);
		do_fio(&c__1, string, l);
		e_wsfe();
		s_wsfe(&io___46);
		do_fio(&c__1, "stroke", 6L);
		e_wsfe();
		i__3 = l - 12;
/* Writing concatenation */
		i__1[0] = l - 2 - i__3, a__1[0] = string + i__3;
		i__1[1] = 2, a__1[1] = " U";
		s_cat(string, a__1, i__1, &c__2, 12L);
		l = 12;
		ipath = 0;
	    } else {
		s_wsfe(&io___47);
		do_fio(&c__1, string, l);
		e_wsfe();
		l = 0;
	    }
	}
	l += 12;
	if (ip == 2) {
	    ipath += 2;
	} else {
	    ipath = 0;
	}
	i__3 = l - 12;
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = l - i__3;
	ici__1.iciunit = string + i__3;
	ici__1.icifmt = fmt_40;
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&ix0, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&iy0, (ftnlen)sizeof(integer));
	do_fio(&c__1, pc + (ip - 2), 1L);
	e_wsfi();
    } else if (vgpnf_1.idevic == 23) {
/* .....STORE X AND Y IN STRING WITH HPGL SYNTAX */
	if (ip == 3) {
	    s_copy(string, "PU", 132L, 2L);
	    s_wsfi(&io___48);
	    do_fio(&c__1, (char *)&ix0, (ftnlen)sizeof(integer));
	    do_fio(&c__1, (char *)&iy0, (ftnlen)sizeof(integer));
	    e_wsfi();
/* Writing concatenation */
	    i__1[0] = 14, a__1[0] = string;
	    i__1[1] = 2, a__1[1] = "PD";
	    s_cat(temp, a__1, i__1, &c__2, 132L);
	    s_copy(string, temp, 132L, 132L);
	    l = 16;
	} else {
	    if (l > 119) {
		s_wsfe(&io___49);
/* Writing concatenation */
		i__1[0] = l, a__1[0] = string;
		i__1[1] = 1, a__1[1] = ";";
		s_cat(ch__1, a__1, i__1, &c__2, 133L);
		do_fio(&c__1, ch__1, l + 1);
		e_wsfe();
		s_copy(string, "PD", 132L, 2L);
		l = 2;
	    }
	    l += 12;
	    i__3 = l - 12;
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = l - i__3;
	    ici__1.iciunit = string + i__3;
	    ici__1.icifmt = fmt_20;
	    s_wsfi(&ici__1);
	    do_fio(&c__1, (char *)&ix0, (ftnlen)sizeof(integer));
	    do_fio(&c__1, (char *)&iy0, (ftnlen)sizeof(integer));
	    e_wsfi();
	}
    }
    if (ipl != ip) {
	outbl = FALSE_;
	goto L1000;
    }

/* .....SAVE VALUES AND STATUS */

L1900:
    ixl = ix0;
    iyl = iy0;
    outbl = outb0;

/* .....New origin */

    if (ip0 > 0) {
	return 0;
    }
    nx0 = ix0;
    ny0 = iy0;
    return 0;

/* .....FINISH PLOTTING */

L1999:
    if (vgpnf_1.idevic < 10) {
	if (vgpnf_1.idevic == 2) {
	    s_wsfe(&io___50);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = esc;
	    i__1[1] = 3, a__1[1] = "%!2";
	    s_cat(ch__2, a__1, i__1, &c__2, 4L);
	    do_fio(&c__1, ch__2, 4L);
	    e_wsfe();
	} else if (vgpnf_1.idevic == 3) {
	    s_wsfe(&io___52);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = esc;
	    i__1[1] = 5, a__1[1] = "[?38l";
	    s_cat(ch__3, a__1, i__1, &c__2, 6L);
	    do_fio(&c__1, ch__3, 6L);
	    e_wsfe();
	    s_wsfe(&io___53);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = esc;
	    i__1[1] = 5, a__1[1] = "[61\"p";
	    s_cat(ch__3, a__1, i__1, &c__2, 6L);
	    do_fio(&c__1, ch__3, 6L);
	    e_wsfe();
	}
    } else if (vgpnf_1.idevic < 20) {
	agraf0_(&ii, &c__1);
    } else if (vgpnf_1.idevic == 20) {
	s_wsfe(&io___54);
	do_fio(&c__1, "SP;", 3L);
	e_wsfe();
    } else if (vgpnf_1.idevic == 21) {
	s_wsfe(&io___55);
	do_fio(&c__1, "^IGE^O", 6L);
	e_wsfe();
	s_wsfe(&io___56);
	do_fio(&c__1, "^IMH0025010000^IMV0050008250", 28L);
	e_wsfe();
	s_wsfe(&io___57);
	do_fio(&c__1, "^,", 2L);
	e_wsfe();
	s_wsfe(&io___58);
	do_fio(&c__1, "^-^PN^-", 7L);
	e_wsfe();
    } else if (vgpnf_1.idevic == 22 || vgpnf_1.idevic == 24) {
	s_wsfe(&io___59);
	do_fio(&c__1, "stroke showpage", 15L);
	e_wsfe();
    } else if (vgpnf_1.idevic == 23) {
	s_wsfe(&io___60);
	do_fio(&c__1, "SP;", 3L);
	e_wsfe();
	s_wsfe(&io___61);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = esc;
	i__1[1] = 1, a__1[1] = "E";
	s_cat(ch__4, a__1, i__1, &c__2, 2L);
	do_fio(&c__1, ch__4, 2L);
	e_wsfe();
    }
    cl__1.cerr = 0;
    cl__1.cunit = 60;
    cl__1.csta = 0;
    f_clos(&cl__1);
    return 0;
/* ***********************************************************************
 */
/* *     GET PARAMETERS FOR DEVICE */
/* ***********************************************************************
 */

L_vgplts:
/*        ORIGINAL NAME PLOTS */
/*                  (IBUF,NLOC,LDEV) */

    *(unsigned char *)ff = '\f';
    *(unsigned char *)esc = '\33';
    *(unsigned char *)gs = '\35';

    if (vgpnf_1.idevic == 99) {
	return 0;
    }
    vgpnf_1.npen = 1;
    l = 0;
/* -----------------------------------------------------------------------
 */
/*      0 <= IDEVIC < 10 : TEKTRONIX */
/*     10  = IDEVIC      : IBM-PC, USING LIBRARY LGRAF */
/*     20 <= IDEVIC      : HARDCOPY DEVICES */
/* -----------------------------------------------------------------------
 */
/*     TEKTRONIX */
/* -----------------------------------------------------------------------
 */
    if (vgpnf_1.idevic == 0) {
/* ...................................................................
.... */
/*     READ FILE WITH TERMINAL DEFINITION, */
/*     OTHERWISE ASSUME TEKTRONIX 4014 */
/* ...................................................................
.... */
	s_copy(term, "TK0", 3L, 3L);
	o__1.oerr = 1;
	o__1.ounit = 50;
	o__1.ofnm = 0;
	o__1.orl = 0;
	o__1.osta = "OLD";
	o__1.oacc = 0;
	o__1.ofm = 0;
	o__1.oblnk = 0;
	i__3 = f_open(&o__1);
	if (i__3 != 0) {
	    goto L2000;
	}
	s_rsfe(&io___64);
	do_fio(&c__1, term, 3L);
	e_rsfe();
	cl__1.cerr = 0;
	cl__1.cunit = 50;
	cl__1.csta = 0;
	f_clos(&cl__1);
L2000:
/* .......TEKTRONIX 41XX */
	if (s_cmp(term, "TK1", 3L, 3L) == 0 || s_cmp(term, "TKB", 3L, 3L) == 
		0) {
	    vgpnf_1.idevic = 1;
	    s_wsfe(&io___65);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = esc;
	    i__1[1] = 1, a__1[1] = ff;
	    s_cat(ch__4, a__1, i__1, &c__2, 2L);
	    do_fio(&c__1, ch__4, 2L);
	    e_wsfe();
	    s_wsfe(&io___66);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = esc;
	    i__1[1] = 3, a__1[1] = "KA0";
	    s_cat(ch__2, a__1, i__1, &c__2, 4L);
	    do_fio(&c__1, ch__2, 4L);
	    e_wsfe();
/* .......TEKTRONIX 410X, EMULATING A VT100 */
	} else if (s_cmp(term, "VT1", 3L, 3L) == 0) {
	    vgpnf_1.idevic = 2;
	    s_wsfe(&io___67);
/* Writing concatenation */
	    i__4[0] = 1, a__3[0] = esc;
	    i__4[1] = 2, a__3[1] = "[H";
	    i__4[2] = 1, a__3[2] = esc;
	    i__4[3] = 2, a__3[3] = "[J";
	    s_cat(ch__3, a__3, i__4, &c__4, 6L);
	    do_fio(&c__1, ch__3, 6L);
	    e_wsfe();
	    s_wsfe(&io___68);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = esc;
	    i__1[1] = 3, a__1[1] = "%!0";
	    s_cat(ch__2, a__1, i__1, &c__2, 4L);
	    do_fio(&c__1, ch__2, 4L);
	    e_wsfe();
	    s_wsfe(&io___69);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = esc;
	    i__1[1] = 3, a__1[1] = "KA0";
	    s_cat(ch__2, a__1, i__1, &c__2, 4L);
	    do_fio(&c__1, ch__2, 4L);
	    e_wsfe();
/* .......VT200 */
	} else if (s_cmp(term, "VT2", 3L, 3L) == 0) {
	    vgpnf_1.idevic = 3;
	    s_wsfe(&io___70);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = esc;
	    i__1[1] = 5, a__1[1] = "[?38h";
	    s_cat(ch__3, a__1, i__1, &c__2, 6L);
	    do_fio(&c__1, ch__3, 6L);
	    e_wsfe();
	}
/* .......TEKTRONIX 4014 */
	s_wsfe(&io___71);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = esc;
	i__1[1] = 1, a__1[1] = ff;
	s_cat(ch__4, a__1, i__1, &c__2, 2L);
	do_fio(&c__1, ch__4, 2L);
	e_wsfe();
	s_wsfe(&io___72);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = esc;
	i__1[1] = 1, a__1[1] = "9";
	s_cat(ch__4, a__1, i__1, &c__2, 2L);
	do_fio(&c__1, ch__4, 2L);
	e_wsfe();
	nx0 = 0;
	ny0 = 0;
	nxm = 4095;
	nym = 4095;
	px0 = 163.84f;
	py0 = px0;
	vgpnf_1.idst = 96;
/* ------------------------------------------------------------------
----- */
/*     IBM-PC, USING LGRAF */
/* ------------------------------------------------------------------
----- */
    } else if (vgpnf_1.idevic == 10) {
	nxm = jdcol0;
	nym = jdrow0;
	px0 = (real) nxm / 25.f;
	py0 = -((real) nym) / 18.75f;
	--nxm;
	--nym;
	nx0 = 0;
	ny0 = nym;
	vgpnf_1.idst = 1;
/* ------------------------------------------------------------------
----- */
/*     HARDCOPY DEVICES */
/* ------------------------------------------------------------------
----- */
/* .....HPGL-PLOTTER */
    } else if (vgpnf_1.idevic == 20) {
	s_wsfe(&io___77);
	do_fio(&c__1, "IN;", 3L);
	e_wsfe();
	s_wsfe(&io___78);
	do_fio(&c__1, "SI0.33,0.5;", 11L);
	e_wsfe();
	s_wsfe(&io___79);
	do_fio(&c__1, "SP1;", 4L);
	e_wsfe();
	nx0 = 0;
	ny0 = 0;
	nxm = 99999;
	nym = 40000;
	px0 = 400.f;
	py0 = px0;
	vgpnf_1.idst = 32;
/* .....QMS-LASERGRAFIX */
    } else if (vgpnf_1.idevic == 21) {
	s_wsfe(&io___80);
	do_fio(&c__1, "^PY^-", 5L);
	e_wsfe();
	s_wsfe(&io___81);
	do_fio(&c__1, "^IOL^IMH0038010620^IMV0035008150^-", 34L);
	e_wsfe();
	s_wsfe(&io___82);
	do_fio(&c__1, "^F^IGV^PW03", 11L);
	e_wsfe();
	nx0 = 0;
	ny0 = 7800;
	nxm = 10240;
	nym = ny0;
	px0 = 393.70078740157481f;
	py0 = -px0;
	vgpnf_1.idst = 48;
/* .....POSTSCRIPT */
    } else if (vgpnf_1.idevic == 22 || vgpnf_1.idevic == 24) {
	s_wsfe(&io___83);
	do_fio(&c__1, "%!PS IDENTIFIES START OF A POSTSCRIPT PROGRAM", 45L);
	e_wsfe();
	s_wsfe(&io___84);
	do_fio(&c__1, "540 0 translate 90 rotate", 25L);
	e_wsfe();
	s_wsfe(&io___85);
	do_fio(&c__1, "0 -72 translate", 15L);
	e_wsfe();
	if (vgpnf_1.idevic == 22) {
	    s_wsfe(&io___86);
	    do_fio(&c__1, "0.24 0.24 scale", 15L);
	    e_wsfe();
	    s_wsfe(&io___87);
	    do_fio(&c__1, "114 105 translate", 17L);
	    e_wsfe();
	} else {
	    s_wsfe(&io___88);
	    do_fio(&c__1, "0.1843 0.24 scale", 17L);
	    e_wsfe();
	    s_wsfe(&io___89);
	    do_fio(&c__1, "580 105 translate", 17L);
	    e_wsfe();
	}
	s_wsfe(&io___90);
	do_fio(&c__1, "/U {moveto }def", 15L);
	e_wsfe();
	s_wsfe(&io___91);
	do_fio(&c__1, "/D {lineto }def", 15L);
	e_wsfe();
	s_wsfe(&io___92);
	do_fio(&c__1, "newpath", 7L);
	e_wsfe();
	s_wsfe(&io___93);
	do_fio(&c__1, "1 setlinecap", 12L);
	e_wsfe();
	s_wsfe(&io___94);
	do_fio(&c__1, "1 setlinewidth", 14L);
	e_wsfe();
	s_wsfe(&io___95);
	do_fio(&c__1, "0 0 U", 5L);
	e_wsfe();
	nx0 = 0;
	ny0 = 0;
	nxm = 3072;
	nym = 2340;
	px0 = 118.11023622047244f;
	py0 = px0;
	vgpnf_1.idst = 0;
/* .....HPGL/2 LaserJet III(ljt) */
    } else if (vgpnf_1.idevic == 23) {
	s_wsfe(&io___96);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = esc;
	i__1[1] = 1, a__1[1] = "E";
	s_cat(ch__4, a__1, i__1, &c__2, 2L);
	do_fio(&c__1, ch__4, 2L);
	e_wsfe();
	s_wsfe(&io___97);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = esc;
	i__1[1] = 3, a__1[1] = "%0B";
	s_cat(ch__2, a__1, i__1, &c__2, 4L);
	do_fio(&c__1, ch__2, 4L);
	e_wsfe();
	s_wsfe(&io___98);
	do_fio(&c__1, "IN;", 3L);
	e_wsfe();
	s_wsfe(&io___99);
	do_fio(&c__1, "RO90", 4L);
	e_wsfe();
	s_wsfe(&io___100);
	do_fio(&c__1, "SI0.33,0.5;", 11L);
	e_wsfe();
	s_wsfe(&io___101);
	do_fio(&c__1, "SP1;", 4L);
	e_wsfe();
	nx0 = 0;
	ny0 = 0;
	nxm = 99999;
	nym = 40000;
	px0 = 400.f;
	py0 = px0;
	vgpnf_1.idst = 32;
    }
/* -----------------------------------------------------------------------
 */
/* .....FOR ALL DEVICES */
    px = px0;
    py = py0;
    xl = 0.f;
    yl = 0.f;
    fl = 1.f;
    ixl = nx0;
    iyl = ny0;
    outbl = FALSE_;
    return 0;

L_vgsiz:
/*         ORIGINAL NAME SETSIZ */
    jdcol0 = *idcol0;
    jdrow0 = *idrow0;
    return 0;
/* ***********************************************************************
 */
/*     CAlCOMP ROUTINE NEWPEN */
/* ***********************************************************************
 */

L_vgnp:
/*         ORIGINAL NAME NEWPEN */

/* L410: */
/* L420: */
/* L430: */
/* L440: */

    if (vgpnf_1.npen == *inp) {
	return 0;
    }

    lnpen = TRUE_;
    ip0 = 3;
    goto L1010;

L4000:
    vgpnf_1.npen = *inp;
    if (vgpnf_1.idevic < 10) {
	if (vgpnf_1.npen / 2 << 1 == vgpnf_1.npen) {
	    if (vgpnf_1.idst < 102) {
		vgpnf_1.idst += 8;
	    }
	} else {
	    if (vgpnf_1.idst > 102) {
		vgpnf_1.idst += -8;
	    }
	}
	s_wsfe(&io___103);
	do_fio(&c__1, esc, 1L);
	*(unsigned char *)&ch__5[0] = (char) vgpnf_1.idst;
	do_fio(&c__1, ch__5, 1L);
	e_wsfe();
    } else if (vgpnf_1.idevic == 10) {
	vgpnf_1.idst = vgpnf_1.idst % 16 + ((vgpnf_1.npen - 1) % 16 << 4);
    } else if (vgpnf_1.idevic == 20) {
	s_wsfe(&io___104);
	do_fio(&c__1, (char *)&vgpnf_1.npen, (ftnlen)sizeof(integer));
	e_wsfe();
    } else if (vgpnf_1.idevic == 21) {
	s_wsfe(&io___105);
	i__3 = ((vgpnf_1.npen - 1) % 8 << 1) + 3;
	do_fio(&c__1, (char *)&i__3, (ftnlen)sizeof(integer));
	e_wsfe();
    } else if (vgpnf_1.idevic == 22 || vgpnf_1.idevic == 24) {
/*       WRITE(60,440) MOD(NPEN-1,8)*2+1 */
/*       WRITE(60,440) MOD(NPEN-1,16)+1 */
	s_wsfe(&io___106);
	i__3 = (vgpnf_1.npen - 1) % 8 + 1;
	do_fio(&c__1, (char *)&i__3, (ftnlen)sizeof(integer));
	e_wsfe();
    } else if (vgpnf_1.idevic == 23) {
	s_wsfe(&io___107);
	do_fio(&c__1, (char *)&vgpnf_1.npen, (ftnlen)sizeof(integer));
	e_wsfe();
    }
    lnpen = FALSE_;
    goto L1010;
/* ***********************************************************************
 */
/*     CAlCOMP ROUTINE WHERE */
/* ***********************************************************************
 */

L_vgwr:
/*         ORIGINAL NAME WHERE */

    *rxpage = xl;
    *rypage = yl;
    *rfact = fl;
    return 0;
} /* vgpl_ */

/* Subroutine */ int vgpl_(real *xpage, real *ypage, integer *ipen)
{
    return vgpl_0_(0, xpage, ypage, ipen, (integer *)0, (integer *)0, (
	    integer *)0, (real *)0, (real *)0, (real *)0);
    }

/* Subroutine */ int vgplts_(void)
{
    return vgpl_0_(1, (real *)0, (real *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, (real *)0, (real *)0, (real *)0);
    }

/* Subroutine */ int vgsiz_(integer *idcol0, integer *idrow0)
{
    return vgpl_0_(2, (real *)0, (real *)0, (integer *)0, idcol0, idrow0, (
	    integer *)0, (real *)0, (real *)0, (real *)0);
    }

/* Subroutine */ int vgnp_(integer *inp)
{
    return vgpl_0_(3, (real *)0, (real *)0, (integer *)0, (integer *)0, (
	    integer *)0, inp, (real *)0, (real *)0, (real *)0);
    }

/* Subroutine */ int vgwr_(real *rxpage, real *rypage, real *rfact)
{
    return vgpl_0_(4, (real *)0, (real *)0, (integer *)0, (integer *)0, (
	    integer *)0, (integer *)0, rxpage, rypage, rfact);
    }

/* Subroutine */ int vgspl_(real *x1, real *y1, real *x2, real *y2, integer *
	kstat)
{
    extern /* Subroutine */ int vgpl_(real *, real *, integer *);
    static real x2old, y2old;

/*  DRAWS A LINE SEGMENT WHILE MINIMIZING PEN LIFTING. */
/*           ORIGINAL NAME SPLOT */
    if (*x1 != x2old || *y1 != y2old || *kstat == 0) {
	vgpl_(x1, y1, &c__3);
	*kstat = 1;
    }
    x2old = *x2;
    y2old = *y2;
    vgpl_(x2, y2, &c__2);
    return 0;
} /* vgspl_ */

/* Subroutine */ int vgsmb_(real *x, real *y, real *height, char *string, 
	real *angle, integer *icolor, ftnlen string_len)
{
    /* Builtin functions */
    double cos(doublereal), sin(doublereal);

    /* Local variables */
    static real rang;
    extern /* Subroutine */ int vgnp_(integer *);
    static real a;
    static integer nchar;
    static real xpage, ypage;
    extern /* Subroutine */ int vgsmbl_(real *, real *, real *, char *, real *
	    , integer *, ftnlen);
    extern integer vgplen_(char *, ftnlen);

/*         ORIGINAL NAME SYMBS */
/*  TRANSFORMS (X,Y), COORDINATES OF CENTER OF FIRST LETTER OF STRING, */
/*  TO (XPAGE,YPAGE), COORDINATES OF LOWER LEFT CORNER OF FIRST LETTER. */
    nchar = vgplen_(string, string_len);
    vgnp_(icolor);
    rang = *angle * .0174533f;
    a = *height * .707107f;
    xpage = *x - a * (real)cos(rang + .785398f);
    ypage = *y - a * (real)sin(rang + .785398f);
    vgsmbl_(&xpage, &ypage, height, string, angle, &nchar, string_len);
    return 0;
} /* vgsmb_ */

/* Subroutine */ int vgsmbl_(real *xpage, real *ypage, real *height, char *
	ibcd, real *angle, integer *nchar, ftnlen ibcd_len)
{
    /* Format strings */
    static char fmt_200[] = "(i3)";

    /* System generated locals */
    integer i__1, i__2;
    icilist ici__1;

    /* Builtin functions */
    double r_mod(real *, real *), cos(doublereal), sin(doublereal);
    integer i_nint(real *), s_rsfi(icilist *), do_fio(integer *, char *, 
	    ftnlen), e_rsfi(void);

    /* Local variables */
    static integer ichr;
    static real cosa, sina, hcos;
    static integer icnt;
    static real hsin;
    static integer i__, j;
    static real alpha, x, y;
    extern /* Subroutine */ int vgdsh_(real *, integer *), vgsbl_(real *, 
	    real *, real *, integer *, real *, integer *);
    static real array[17], dummy[1], x0, y0, ch;
    static integer il;

/*          ORIGINAL NAME SYMBLS */
/* ***********************************************************************
 */
/* *     SUBROUTINE VGSMBL */
/* *     TO EMULATE CAlCOMP ROUTINE SYMBOL, STANDARD CALL */
/* *         U. KATTNER NBS, 1 SEPTEMBER 1987  -  VERSION 1.0 */
/* *         MODIFIED 4/12/89  D. KAHANER */
/* *         COMMON VGSSIZ ADDED 5 JULY 89 (DRA) */
/* ***********************************************************************
 */


/* L200: */
    if (*xpage != 999.f && *ypage != 999.f) {
	x0 = *xpage;
	y0 = *ypage;
    }

    alpha = (real)r_mod(angle, &c_b203) * 6.283185f / 360.f;
    if (alpha < 0.f) {
	alpha += 6.283185f;
    }
    cosa = (real)cos(alpha);
    sina = (real)sin(alpha);
    hcos = 0.f;
    hsin = 0.f;

/* CC      IL = LEN(IBCD) */
/* CC   IF (IL.GT.NCHAR) IL = NCHAR */
    il = *nchar;
    if (il == 0) {
	return 0;
    }

    vgdsh_(array, &c_n16);
    icnt = i_nint(&array[16]);
    if (icnt != 0) {
	vgdsh_(dummy, &c__0);
    }

    j = 0;
    i__1 = il;
    for (i__ = 1; i__ <= i__1; ++i__) {
	ch = *height;
	x = x0;
	y = y0;
L1000:
	++j;
	ichr = *(unsigned char *)&ibcd[j - 1];
	if (ichr == 95) {
/* ....._ : NEXT CHARACTER IS A SUBSCRIPT */
	    ch = vgssiz_1.subsz * ch;
	    x += ch * .5f * sina;
	    y -= ch * .5f * cosa;
	    goto L1000;
/* CC                DKK CHANGED FROM 63 (?) TO 92 (\) */
	} else if (ichr == 92) {
/* .....\ : NEXT 3 CHARACTERS ARE THE CODE NUMBER OF A CHARACTER 
*/
	    ++j;
	    ici__1.icierr = 1;
	    ici__1.iciend = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = ibcd_len - (j - 1);
	    ici__1.iciunit = ibcd + (j - 1);
	    ici__1.icifmt = fmt_200;
	    i__2 = s_rsfi(&ici__1);
	    if (i__2 != 0) {
		goto L9000;
	    }
	    i__2 = do_fio(&c__1, (char *)&ichr, (ftnlen)sizeof(integer));
	    if (i__2 != 0) {
		goto L9000;
	    }
	    i__2 = e_rsfi();
	    if (i__2 != 0) {
		goto L9000;
	    }
	    j += 2;
	} else if (ichr == 94) {
/* .....^ : NEXT CHARACTER IS A SUPERSCRIPT */
	    ch = vgssiz_1.suprsz * ch;
	    x -= ch * .9f * sina;
	    y += ch * .9f * cosa;
	    goto L1000;
	} else if (ichr == 124) {
/* .....| : NEXT CHARACTER IS FROM THE EXTENDED CHARACTER SET */
/*            UNLESS IT IS _,^ THEN PRINT ITSELF. */
	    ++j;
	    ichr = *(unsigned char *)&ibcd[j - 1];
	    if (ichr == 95) {
/*           DRAW _ A BIT SMALLER (MAGIC NUMBER DKK 4/12/89) 
*/
		ch *= .5f;
	    } else if (ichr == 94) {
/*          DRAW ^ A BIT SMALLER & RAISE IT SOME (MAGIC NUMBER
 DKK 4/12/89)*/
		ch *= .6f;
		x -= ch * .6f * sina;
		y += ch * .6f * cosa;
	    } else {
/*           USE EXTENDED CHARACTER */
		ichr += 128;
	    }
	}
	if (ichr == 127 || ichr == 160) {
/* CCC.....BACKSPACE */
	    x0 -= hcos;
	    y0 -= hsin;
	    goto L2000;
	}

	vgsbl_(&x, &y, &ch, &ichr, angle, &c_n1);
	hcos = ch * cosa;
	hsin = ch * sina;
	x0 += hcos;
	y0 += hsin;
L2000:
	;
    }

L9000:
    if (icnt != 0) {
	vgdsh_(array, &icnt);
    }
    return 0;
} /* vgsmbl_ */

/* Subroutine */ int vgsbl_(real *xpage, real *ypage, real *height, integer *
	inteq, real *angle, integer *icode)
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer i_nint(real *);
    double r_mod(real *, real *), cos(doublereal), sin(doublereal);

    /* Local variables */
    static real cosa, sina;
    static integer ipen;
    static real hcos;
    static integer icnt;
    static real hsin;
    extern /* Subroutine */ int vgpl_(real *, real *, integer *);
    static real hcos4, hsin4, alpha, x, y;
    extern /* Subroutine */ int vgdsh_(real *, integer *);
    static real dummy[1], x0, y0;
    static integer ip;
    static real cx, cy;
    static integer ix, iy, nx, ny;
    static real rarray[17];

/* ***********************************************************************
 */
/* *       ORIGINAL NAME SYMBOL */
/* *     TO EMULATE CAlCOMP ROUTINE SYMBOL, SPECIAL CALL */
/* *     URSULA KATTNER, NBS, 26 SEPTEMBER 1987  -  VERSION 1.0 */
/* *     DAVID KAHANER,  NBS, 25 MAY 1988 */
/* *     CHARACTER FONT IS STORED IN AN ARRAY OF CHARACTER*1 FONT(SIZE) */
/* ********************************************************************** 
*/



    if (*xpage != 999.f && *ypage != 999.f) {
	x0 = *xpage;
	y0 = *ypage;
    }

/* .....ICODE = -1 : "PEN UP"; ICODE = -2 : "PEN DOWN" */

    if (*icode == -2) {
	i__1 = *icode + 4;
	vgpl_(&x0, &y0, &i__1);
    }

    if (vgfpt_1.ifptr[*inteq] == 0) {
	return 0;
    }

    vgdsh_(rarray, &c_n16);
    icnt = i_nint(&rarray[16]);
    if (icnt != 0) {
	vgdsh_(dummy, &c__0);
    }

    alpha = (real)r_mod(angle, &c_b203) * 6.283185f / 360.f;
    if (alpha < 0.f) {
	alpha += 6.283185f;
    }
    cosa = (real)cos(alpha);
    sina = (real)sin(alpha);
    hcos = *height * cosa;
    hsin = *height * sina;
    hcos4 = hcos * .043f;
    hsin4 = hsin * .043f;

    if (*inteq == 127 || *inteq == 174 || *inteq == 223) {
	x0 -= hcos;
	y0 -= hsin;
    }

    if (*inteq < 32) {
	nx = 64;
	ny = 64;
    } else {
	nx = 53;
	ny = 55;
    }

    ip = vgfpt_1.ifptr[*inteq];
L1000:
    ipen = 3;
L1010:
    ip += 2;
    ix = *(unsigned char *)&vgfnt_1.font[ip - 1];
    iy = *(unsigned char *)&vgfnt_1.font[ip];
    if (ix == 126) {
	goto L1100;
    }
    cx = (real) (ix - nx);
    cy = (real) (iy - ny);
    x = cx * hcos4 - cy * hsin4 + x0;
    y = cy * hcos4 + cx * hsin4 + y0;
    vgpl_(&x, &y, &ipen);
    ipen = 2;
    goto L1010;
L1100:
    if (iy != 126) {
	goto L1000;
    }

    if (*inteq < 32 || *inteq == 127) {
	goto L2000;
    }
    x0 += hcos;
    y0 += hsin;
L2000:
    vgpl_(&x0, &y0, &c__3);

    if (icnt != 0) {
	vgdsh_(rarray, &icnt);
    }
    return 0;
} /* vgsbl_ */

/* Subroutine */ int vgdsh_(real *array, integer *icnt)
{
    /* Initialized data */

    static integer jtek[5] = { 96,97,99,98,100 };
    static integer jpc[9] = { 1,2,6,3,4,5,7,8,9 };
    static char jhp[1*7] = " " "1" "2" "4" "3" "5" "6";
    static char jqms[1*16] = "0" "3" "6" "8" "1" "2" "4" "5" "7" "9" "A" 
	    "B" "C" "D" "E" "F";
    static char jpsc[13*5] = "[]           " "[12 12]      " "[60 12]      " 
	    "[60 12 12 12]" "[36 24]      ";

    /* Format strings */
    static char fmt_10[] = "(2a1)";
    static char fmt_20[] = "(\002LT\002,a1,\002,\002,a1,\002;\002)";
    static char fmt_30[] = "(\002^V\002,a1)";
    static char fmt_40[] = "(a14,\002 0 setdash\002)";

    /* System generated locals */
    char ch__1[1];

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    extern /* Subroutine */ int vgpl_(real *, real *, integer *), vgwr_(real *
	    , real *, real *);
    static real f;
    static integer i__;
    static real x, y;

    /* Fortran I/O blocks */
    static cilist io___163 = { 0, 60, 0, fmt_10, 0 };
    static cilist io___164 = { 0, 60, 0, fmt_20, 0 };
    static cilist io___165 = { 0, 60, 0, fmt_30, 0 };
    static cilist io___166 = { 0, 60, 0, fmt_40, 0 };
    static cilist io___167 = { 0, 60, 0, fmt_20, 0 };


/* ***********************************************************************
 */
/* *     ORIGINAL NAME DASHS */
/* *     TO EMULATE CAlCOMP ROUTINE DASHS */
/* *       U. KATTNER NBS, 1 SEPTEMBER 1987  -  VERSION 1.0 */
/* ***********************************************************************
 */


    /* Parameter adjustments */
    --array;

    /* Function Body */

/* L10: */
/* L20: */
/* L30: */
/* L40: */

/* -----------------------------------------------------------------------
 */
/*     DEFAULT DASH STYLES OF THE DEVICES ARE USED. */
/*     STANDARD:  0 = SOLID */
/*                1 = DOTTED */
/*                2 = DASHED */
/*                3 = CHAIN-DOTTED */
/*     FOR HIGHER NUMBERS, THE DASH STYLE DEPENDS ON THE DEVICE. */
/* -----------------------------------------------------------------------
 */

    if (*icnt < 0) {
	array[1 - *icnt] = (real) i__;
	return 0;
    }

    if (*icnt == i__) {
	return 0;
    }

    vgwr_(&x, &y, &f);
    vgpl_(&x, &y, &c__3);
    if (vgpnf_1.idevic < 10) {
	i__ = *icnt % 5;
	vgpnf_1.idst = jtek[i__];
	if (vgpnf_1.npen / 2 << 1 == vgpnf_1.npen) {
	    vgpnf_1.idst += 8;
	}
	s_wsfe(&io___163);
	do_fio(&c__1, "\033", 1L);
	*(unsigned char *)&ch__1[0] = (char) vgpnf_1.idst;
	do_fio(&c__1, ch__1, 1L);
	e_wsfe();
    } else if (vgpnf_1.idevic < 20) {
	i__ = *icnt % 9;
	vgpnf_1.idst = jpc[i__] + (vgpnf_1.idst / 16 << 4);
    } else if (vgpnf_1.idevic == 20) {
	i__ = *icnt % 7;
	s_wsfe(&io___164);
	do_fio(&c__1, jhp + i__, 1L);
	do_fio(&c__1, jhp + i__, 1L);
	e_wsfe();
    } else if (vgpnf_1.idevic == 21) {
	i__ = *icnt % 16;
	s_wsfe(&io___165);
	do_fio(&c__1, jqms + i__, 1L);
	e_wsfe();
    } else if (vgpnf_1.idevic == 22 || vgpnf_1.idevic == 24) {
	i__ = *icnt % 5;
	s_wsfe(&io___166);
	do_fio(&c__1, jpsc + i__ * 13, 13L);
	e_wsfe();
    } else if (vgpnf_1.idevic == 23) {
	i__ = *icnt % 7;
	s_wsfe(&io___167);
	do_fio(&c__1, jhp + i__, 1L);
	do_fio(&c__1, jhp + i__, 1L);
	e_wsfe();
    }
    vgpl_(&x, &y, &c__3);

    return 0;
} /* vgdsh_ */

