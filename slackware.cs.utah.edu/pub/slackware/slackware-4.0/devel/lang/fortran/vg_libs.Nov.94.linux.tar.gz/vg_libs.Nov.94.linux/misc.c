/* misc.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    real subsz, suprsz;
} vgssiz_;

#define vgssiz_1 vgssiz_

struct {
    real sx[50], sy[50], sa[50], sh[50];
    integer sc[50], so[50], sm[50], ntex;
} vgtx1_;

#define vgtx1_1 vgtx1_

struct {
    char st[3500];
} vgtx2_;

#define vgtx2_1 vgtx2_

/* Table of constant values */

static integer c__1 = 1;
static doublereal c_b43 = 10.;
static real c_b54 = 0.f;
static integer c__0 = 0;

doublereal vgamt_(real *x)
{
    /* Format strings */
    static char fmt_100[] = "(e13.6)";
    static char fmt_200[] = "(f9.6)";

    /* System generated locals */
    real ret_val;

    /* Builtin functions */
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_rsfi(icilist *), e_rsfi(void);

    /* Local variables */
    static char cx[13], camant[9];

    /* Fortran I/O blocks */
    static icilist io___2 = { 0, cx, 0, fmt_100, 13, 1 };
    static icilist io___4 = { 0, camant, 0, fmt_200, 9, 1 };


/*  FINDS THE MANTISSA OF X. */
    s_wsfi(&io___2);
    do_fio(&c__1, (char *)&(*x), (ftnlen)sizeof(real));
    e_wsfi();
    s_copy(camant, cx, 9L, 9L);
    s_rsfi(&io___4);
    do_fio(&c__1, (char *)&ret_val, (ftnlen)sizeof(real));
    e_rsfi();
    return ret_val;
} /* vgamt_ */

integer vgidec_(real *x)
{
    /* Format strings */
    static char fmt_100[] = "(e13.6)";
    static char fmt_110[] = "(i3)";

    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_rsfi(icilist *), e_rsfi(void);

    /* Local variables */
    static char cn[13], cx[13];

    /* Fortran I/O blocks */
    static icilist io___6 = { 0, cx, 0, fmt_100, 13, 1 };
    static icilist io___8 = { 0, cn, 0, fmt_110, 13, 1 };


/*   FINDS THE "POWER OF TEN" WITHIN WHICH X LIES. */
    s_wsfi(&io___6);
    do_fio(&c__1, (char *)&(*x), (ftnlen)sizeof(real));
    e_wsfi();
    s_copy(cn, cx + 10, 13L, 3L);
    s_rsfi(&io___8);
    do_fio(&c__1, (char *)&ret_val, (ftnlen)sizeof(integer));
    e_rsfi();
    return ret_val;
} /* vgidec_ */

integer vgistr_(char *c__, ftnlen c_len)
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    integer i_len(char *, ftnlen);

    /* Local variables */
    static integer i__;

/*   COMPUTES THE POSITION OF THE LAST NONBLANK CHARACTER OF A STRING. */
    for (i__ = i_len(c__, c_len); i__ >= 1; --i__) {
	if (*(unsigned char *)&c__[i__ - 1] != ' ') {
	    goto L200;
	}
/* L100: */
    }
    ret_val = 0;
    return ret_val;
L200:
    ret_val = i__;
    return ret_val;
} /* vgistr_ */

integer vgisig_(real *x)
{
    /* Format strings */
    static char fmt_100[] = "(e13.6)";

    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;

    /* Local variables */
    static integer i__;
    static char cx[13];

    /* Fortran I/O blocks */
    static icilist io___11 = { 0, cx, 0, fmt_100, 13, 1 };


/*  RETURNS THE NO. OF SIGNIFICANT FIGURES OF X. */
    s_wsfi(&io___11);
    do_fio(&c__1, (char *)&(*x), (ftnlen)sizeof(real));
    e_wsfi();
    for (i__ = 9; i__ >= 4; --i__) {
	if (*(unsigned char *)&cx[i__ - 1] != '0') {
	    goto L60;
	}
/* L50: */
    }
    ret_val = 0;
    return ret_val;
L60:
    ret_val = i__ - 3;
    return ret_val;
} /* vgisig_ */

integer vgihi_(real *x)
{
    /* System generated locals */
    integer ret_val;

    /* Local variables */
    extern doublereal vgamt_(real *);
    extern integer vgkdec_(real *);

/* RETURNS LEAST INTEGER N SUCH THAT 10.**(N-1) IS AT LEAST VERY */
/* LITTLE SMALLER THAN X. */
    ret_val = vgkdec_(x) + 1;
    if ((real)vgamt_(x) >= .999999f || (real)vgamt_(x) <= .100001f) {
	--ret_val;
    }
    return ret_val;
} /* vgihi_ */

integer vgkdec_(real *x)
{
    /* System generated locals */
    integer ret_val;

    /* Local variables */
    extern doublereal vgamt_(real *);
    extern integer vgidec_(real *);

/*  DECADE-FINDER THAT ROUNDS UP IF X IS JUST BELOW A DECADE BOUNDARY. */
    ret_val = vgidec_(x);
    if ((real)vgamt_(x) >= .999999f) {
	++ret_val;
    }
    return ret_val;
} /* vgkdec_ */

integer vgiaro_(integer *kcurr)
{
    /* System generated locals */
    integer ret_val;

/*  TESTS WHETHER KCURR IS THE CODE NUMBER FOR AN ARROW KEY. */
/*  OR FOR i j k OR m OR THEIR SHIFTED COUNTERPARTS */
    if (*kcurr == 18432 || *kcurr == 56 || *kcurr == 20480 || *kcurr == 50 || 
	    *kcurr == 19712 || *kcurr == 54 || *kcurr == 19200 || *kcurr == 
	    52 || *kcurr == 73 || *kcurr == 74 || *kcurr == 75 || *kcurr == 
	    77 || *kcurr == 105 || *kcurr == 106 || *kcurr == 107 || *kcurr ==
	     109) {
	ret_val = 1;
    } else {
	ret_val = 0;
    }
    return ret_val;
} /* vgiaro_ */

integer vgplen_(char *string, ftnlen string_len)
{
    /* System generated locals */
    integer ret_val, i__1, i__2;

    /* Builtin functions */
    integer s_cmp(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer i__;
    static char ch[1];
    extern integer vgistr_(char *, ftnlen);
    static integer len1;

/*  COMPUTES STRING PRINTING LENGTH, IE, LENGTH AFTER THROWING OUT */
/*  TRAILING BLANKS AND CONTROL CHARACTERS */
    len1 = vgistr_(string, string_len);
    ret_val = len1;
    i__1 = len1;
    for (i__ = 1; i__ <= i__1; ++i__) {
	*(unsigned char *)ch = *(unsigned char *)&string[i__ - 1];
	if (*(unsigned char *)ch == '_' || *(unsigned char *)ch == '^' || *(
		unsigned char *)ch == '|' || *(unsigned char *)ch == '\\') {
	    --ret_val;
/*                REDUCE COUNT BY TWO MORE IF CHARACTER CODE FOLLO
WS */
	    if (*(unsigned char *)ch == '\\') {
		ret_val += -2;
	    }
/*            DON'T COUNT SPECIAL CHARACTERS |, _, ^, UNLESS PRECE
DED BY |,*/
/*                  THEN THEY ARE TO BE PRINTED. */
	    i__2 = i__ - 2;
	    if (i__ > 1 && s_cmp(string + i__2, "|", i__ - 1 - i__2, 1L) == 0)
		     {
		++ret_val;
/*                  '||' AND SPECIAL CHARACTER */
		i__2 = i__ - 3;
		if (i__ > 2 && s_cmp(string + i__2, "|", i__ - 2 - i__2, 1L) 
			== 0) {
		    --ret_val;
		}
	    }
	}
/* L10: */
    }
    return ret_val;
} /* vgplen_ */

integer vggi_(real *x)
{
    /* System generated locals */
    integer ret_val;

/*         ORIGINAL NAME IGREAT */
/*  COMPUTES GREATES INTEGER FUNCTION. */
    if (*x >= 0.f) {
	ret_val = (integer) (*x);
    } else {
	if (*x == (real) ((integer) (*x))) {
	    ret_val = *x;
	} else {
	    ret_val = (integer) (*x) - 1;
	}
    }
    return ret_val;
} /* vggi_ */

integer vglgin_(integer *logmin, integer *logmax)
{
    /* System generated locals */
    integer ret_val;

    /* Local variables */
    static integer logrng;

/* COMPUTES INCREMENT BETWEEN TICK MARKS FOR LOG PLOTS. */
/* THIS IS NEEDED TO ACCOMODATE THE ARRAYS IN VGXYL WHICH */
/* ARE ONLY 17 ELEMENTS LONG. */
    logrng = *logmax - *logmin;
    if (logrng <= 17) {
	ret_val = 1;
    } else if (logrng <= 34) {
	ret_val = 2;
    } else if (logrng <= 68) {
	ret_val = 4;
    } else {
	ret_val = 5;
    }
    return ret_val;
} /* vglgin_ */

/* Subroutine */ int vgcent_(char *text, real *x, real *y, real *rot, real *
	size, real *top, real *bot, real *left, real *rit, integer *horiz, 
	integer *vert, ftnlen text_len)
{
    /* Initialized data */

    static real deg2rad = .0144533f;

    /* Builtin functions */
    double cos(doublereal), sin(doublereal);

    /* Local variables */
    extern /* Subroutine */ int vgmeas_(char *, integer *, real *, real *, 
	    real *, ftnlen);
    static integer len;
    static real hgt, wid;

/*   CENTERS A LINE OF TEXT */
    vgmeas_(text, &len, &hgt, &wid, size, text_len);
    if (*horiz == 1) {
	*x = (*rit + *left - wid * (real)cos(*rot * deg2rad)) / 2;
    }
    if (*vert == 1) {
	*y = (*top + *bot - wid * (real)sin(*rot * deg2rad)) / 2;
    }
    return 0;
} /* vgcent_ */

doublereal vgg2s_(real *gcoord, real *smin, real *smax, real *gmin, real *
	gmax, integer *logmin, integer *logmax, integer *logflg)
{
    /* System generated locals */
    real ret_val;

    /* Local variables */
    extern doublereal slog10_(real *);
    static real sdist;

/*  TRANSFORMS A GRAPH'S COORDINATE INTO A SCREEN COORDINATE */
    sdist = *smax - *smin;
    if (*logflg == 0) {
/*  LINEAR AXIS */
	ret_val = (*gcoord - *gmin) * sdist / (*gmax - *gmin) + *smin;
    } else {
/* LOG AXIS */
	ret_val = ((real)slog10_(gcoord) - *logmin) * sdist / (*logmax - *
		logmin) + *smin;
    }
    return ret_val;
} /* vgg2s_ */

doublereal vgs2g_(real *scoord, real *smin, real *smax, real *gmin, real *
	gmax, integer *logmin, integer *logmax, integer *logflg)
{
    /* System generated locals */
    real ret_val;
    doublereal d__1;

    /* Builtin functions */
    double pow_dd(doublereal *, doublereal *);

    /* Local variables */
    static real sdist;

/*  TRANSFORMS A SCREEN COORDINATE TO A GRAPH'S COORDINATE */
    sdist = *smax - *smin;
    if (*logflg == 0) {
/*  LINEAR AXES */
	ret_val = (*scoord - *smin) * (*gmax - *gmin) / sdist + *gmin;
    } else {
/*  LOG AXES */
	d__1 = (doublereal) ((*scoord - *smin) * (*logmax - *logmin) / sdist 
		+ *logmin);
	ret_val = (real)pow_dd(&c_b43, &d__1);
    }
    return ret_val;
} /* vgs2g_ */

/* Subroutine */ int vgmeas_(char *string, integer *len, real *hgt, real *wid,
	 real *height, ftnlen string_len)
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_cmp(char *, char *, ftnlen, ftnlen);
    double pow_ri(real *, integer *);

    /* Local variables */
    static real subs;
    static integer i__, j;
    extern integer vgplen_(char *, ftnlen);
    static integer maxsub, numsub, maxspr, ln1;
    extern integer vgistr_(char *, ftnlen);
    static real supers, tempsz;
    static integer numspr;

/*  MEASURES A STRING, GIVING ITS NUMBER OF PRINTING CHARACTERS (LEN), */
/*  AND ITS HEIGHT (HGT) AND WIDTH (WID) IN INCHES WHEN DRAWN. */
    subs = 0.f;
    supers = 0.f;
    numsub = 0;
    numspr = 0;
    maxsub = 0;
    maxspr = 0;
    ln1 = vgistr_(string, string_len);
    *len = vgplen_(string, string_len);
    i__ = 1;
L10:
    j = 1;
    if (*(unsigned char *)&string[i__ - 1] == '^') {
	++numspr;
	tempsz = vgssiz_1.suprsz;
	maxspr = max(1,maxspr);
L20:
	i__1 = i__ + j - 1;
	if (s_cmp(string + i__1, "^", i__ + j - i__1, 1L) == 0) {
	    tempsz *= vgssiz_1.suprsz;
	    ++j;
	    maxspr = max(j,maxspr);
	    goto L20;
	}
	supers += tempsz;
    } else if (*(unsigned char *)&string[i__ - 1] == '_') {
	++numsub;
	tempsz = vgssiz_1.subsz;
	maxsub = max(1,maxsub);
L30:
	i__1 = i__ + j - 1;
	if (s_cmp(string + i__1, "_", i__ + j - i__1, 1L) == 0) {
	    tempsz *= vgssiz_1.subsz;
	    ++j;
	    maxsub = max(j,maxsub);
	    goto L30;
	}
	subs += tempsz;
    }
    i__ += j;
    if (i__ <= ln1) {
	goto L10;
    }
    *wid = *height * (*len - numsub - numspr + supers + subs);
    *hgt = *height;
    if (maxspr > 0) {
	*hgt += *height * (real)pow_ri(&vgssiz_1.suprsz, &maxspr);
    }
    if (maxsub > 0) {
	*hgt += *height * (real)pow_ri(&vgssiz_1.subsz, &maxsub);
    }
    return 0;
} /* vgmeas_ */

/* Subroutine */ int vgfxtx_(real *oldtop, real *oldbot, real *oldlef, real *
	oldrit, real *newtop, real *newbot, real *newlef, real *newrit, 
	integer *i__)
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    extern doublereal vgs2s_(real *, real *, real *, real *, real *);
    static integer j;
    static real dellef, delbot, delrit;
    extern /* Subroutine */ int vgcent_(char *, real *, real *, real *, real *
	    , real *, real *, real *, real *, integer *, integer *, ftnlen);
    static real deltop;

/*  FIXES A GRAPH'S TEXT AFTER ITS SCREEN POSITION HAS BEEN CHANGED */
    dellef = *newlef - *oldlef;
    delrit = *newrit - *oldrit;
    deltop = *newtop - *oldtop;
    delbot = *newbot - *oldbot;
    i__1 = vgtx1_1.ntex;
    for (j = 1; j <= i__1; ++j) {
	if (vgtx1_1.so[j - 1] == *i__) {
	    if (vgtx1_1.sm[j - 1] == 1) {
/*  'KEEP DISTANCE' MODE */
		vgtx1_1.sx[j - 1] += dellef;
		vgtx1_1.sy[j - 1] += delbot;
	    } else if (vgtx1_1.sm[j - 1] == 2) {
/*  'STUCK TO POINT' MODE */
		vgtx1_1.sx[j - 1] = (real)vgs2s_(&vgtx1_1.sx[j - 1], oldlef, 
			oldrit, newlef, newrit);
		vgtx1_1.sy[j - 1] = (real)vgs2s_(&vgtx1_1.sy[j - 1], oldbot, 
			oldtop, newbot, newtop);
	    } else if (vgtx1_1.sm[j - 1] == 3) {
/*  BOTTOM CENTERING MODE */
		vgcent_(vgtx2_1.st + (j - 1) * 70, &vgtx1_1.sx[j - 1], &
			vgtx1_1.sy[j - 1], &vgtx1_1.sa[j - 1], &vgtx1_1.sh[j 
			- 1], &c_b54, &c_b54, newlef, newrit, &c__1, &c__0, 
			70L);
		vgtx1_1.sy[j - 1] += delbot;
	    } else if (vgtx1_1.sm[j - 1] == 4) {
/*  LEFT CENTERING MODE */
		vgtx1_1.sx[j - 1] += dellef;
		vgcent_(vgtx2_1.st + (j - 1) * 70, &vgtx1_1.sx[j - 1], &
			vgtx1_1.sy[j - 1], &vgtx1_1.sa[j - 1], &vgtx1_1.sh[j 
			- 1], newbot, newtop, &c_b54, &c_b54, &c__0, &c__1, 
			70L);
	    } else if (vgtx1_1.sm[j - 1] == 5) {
/*  TOP CENTERING MODE */
		vgtx1_1.sy[j - 1] += deltop;
		vgcent_(vgtx2_1.st + (j - 1) * 70, &vgtx1_1.sx[j - 1], &
			vgtx1_1.sy[j - 1], &vgtx1_1.sa[j - 1], &vgtx1_1.sh[j 
			- 1], &c_b54, &c_b54, newlef, newrit, &c__1, &c__0, 
			70L);
	    } else if (vgtx1_1.sm[j - 1] == 6) {
/*  RIGHT CENTERING MODE */
		vgtx1_1.sx[j - 1] += delrit;
		vgcent_(vgtx2_1.st + (j - 1) * 70, &vgtx1_1.sx[j - 1], &
			vgtx1_1.sy[j - 1], &vgtx1_1.sa[j - 1], &vgtx1_1.sh[j 
			- 1], newbot, newtop, &c_b54, &c_b54, &c__0, &c__1, 
			70L);
	    }
	}
/* L100: */
    }
    return 0;
} /* vgfxtx_ */

doublereal vgs2s_(real *x, real *oldmin, real *oldmax, real *newmin, real *
	newmax)
{
    /* System generated locals */
    real ret_val;

/*  TRANSFORMS A SCREEN COORDINATE INTO A NEW SCREEN COORDINATE */
/*  WHEN THE GRAPH'S POSITION (BUT NOT BOUNDARIES) HAVE CHANGED */
    ret_val = (*x - *oldmin) * (*newmax - *newmin) / (*oldmax - *oldmin) + *
	    newmin;
    return ret_val;
} /* vgs2s_ */

