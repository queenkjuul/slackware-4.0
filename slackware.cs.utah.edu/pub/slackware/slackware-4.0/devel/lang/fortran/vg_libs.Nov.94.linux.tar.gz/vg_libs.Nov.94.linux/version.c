/* version.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Table of constant values */

static integer c__9 = 9;
static integer c__1 = 1;

/* Subroutine */ int vgver_(void)
{
    /* Builtin functions */
    integer s_wsle(cilist *), do_lio(integer *, integer *, char *, ftnlen), 
	    e_wsle(void);

    /* Fortran I/O blocks */
    static cilist io___1 = { 0, 6, 0, 0, 0 };


/*            ORIGINAL NAME VERSION */
/*  THIS MERELY PROVIDES A WAY OF PROVIDING THE CURRENT */
/*  VERSION OF THE LIBRARY. */
    s_wsle(&io___1);
    do_lio(&c__9, &c__1, "VG VERSION 3.19 -- 14 November 1994", 35L);
    e_wsle();
    return 0;
} /* vgver_ */

