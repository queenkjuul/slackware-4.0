/* inter.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"
#include "agraf.h"

/* Common Block Declarations */

struct {
    integer idevic, idst, npen;
} vgpnf_;

#define vgpnf_1 vgpnf_

struct {
    logical baton;
} vgbt_;

#define vgbt_1 vgbt_

struct {
    real bleft1[7], brit1[7], bbot1[7], btop1[7], bxmin[7], bxmax[7], bymin[
	    14]	/* was [7][2] */, bymax[14]	/* was [7][2] */;
    integer ninlx[7], naxlx[7], ninly[14]	/* was [7][2] */, naxly[14]	
	    /* was [7][2] */, msx[7], msy[14]	/* was [7][2] */;
} vglim_;

#define vglim_1 vglim_

struct {
    integer ig;
} vgcntr_;

#define vgcntr_1 vgcntr_

struct {
    real bbot0[7], btop0[7], bleft0[7], brit0[7];
    integer isdx[7], isdy1[7], isdy2[7], kludge[7], axcol;
} vglttr_;

#define vglttr_1 vglttr_

struct {
    real sx[50], sy[50], sa[50], sh[50];
    integer sc[50], so[50], sm[50], ntex;
} vgtx1_;

#define vgtx1_1 vgtx1_

struct {
    char st[3500];
} vgtx2_;

#define vgtx2_1 vgtx2_

struct {
    logical pass1;
    integer jexit, mdevic, istat;
    logical pass2;
} vgloop_;

#define vgloop_1 vgloop_

struct {
    char filnam[6], exten[3];
} vgfil1_;

#define vgfil1_1 vgfil1_

struct {
    integer numpag;
} vgfil2_;

#define vgfil2_1 vgfil2_

struct {
    logical yestic[21]	/* was [7][3] */;
    integer nh[7], nv1[7], nv2[7];
} vgtic1_;

#define vgtic1_1 vgtic1_

struct {
    real height;
} vghgt_;

#define vghgt_1 vghgt_

struct {
    logical pb4xit;
} vgprnt_;

#define vgprnt_1 vgprnt_

struct {
    integer jpw, jph;
} vgtxt_;

#define vgtxt_1 vgtxt_

struct {
    real sht, swd;
    integer ncols, nrows;
} vgscrn_;

#define vgscrn_1 vgscrn_

/* Table of constant values */

static integer c__0 = 0;
static integer c__9 = 9;
static integer c__1 = 1;
static real c_b9 = 0.f;
static integer c__999 = 999;
static integer c__4 = 4;
static integer c__2 = 2;
static integer c__8 = 8;
static integer c__7 = 7;
static integer c__3 = 3;
static integer c__6 = 6;
static integer c__50 = 50;
static logical c_true = TRUE_;

/* Subroutine */ int vgint_(logical *contin)
{
    /* Initialized data */

    static integer iq = 0;
    static logical go = FALSE_;
    static integer kg = 1;

    /* System generated locals */
    address a__1[4], a__2[2];
    integer i__1, i__2[4], i__3[2];
    char ch__1[103], ch__2[29];
    olist o__1;
    cllist cl__1;

    /* Builtin functions */
    integer s_wsle(cilist *), do_lio(integer *, integer *, char *, ftnlen), 
	    e_wsle(void), f_clos(cllist *), s_wsfi(icilist *), do_fio(integer 
	    *, char *, ftnlen), e_wsfi(void);
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen);
    integer f_open(olist *), i_indx(char *, char *, ftnlen, ftnlen), pow_ii(
	    integer *, integer *), s_cmp(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static logical calc;
    static integer iend;
    static char name__[80];
    static integer iesc;
    extern /* Subroutine */ int vggl_(integer *, char *, char *, integer *, 
	    ftnlen, ftnlen), vgpl_(real *, real *, integer *), vgnp_(integer *
	    ), vgzm_(integer *, integer *, integer *);
    static integer i__, kflag;
    extern /* Subroutine */ int vgbat_(logical *), vgfnd_(void);
    extern integer vgihi_(real *);
    extern /* Subroutine */ int vgtic_(integer *, integer *, real *, real *, 
	    integer *, integer *, integer *, integer *, logical *), vgcor_(
	    real *, real *, real *, real *), vgarr_(real *, real *, real *, 
	    real *, integer *, integer *, real *, real *, real *, real *, 
	    integer *);
    static integer kcurr;
    extern /* Subroutine */ int vglmv_(integer *, integer *),
      vgtmv_(real *, real *, real *, real *, integer *, 
	     integer *, integer *);
    static real xcurs, ycurs;
    extern /* Subroutine */ short agraf4_(integer *);
    static char ch[1];
    static integer ie;
    extern logical agrafa_(integer *, integer *, integer *, integer *);
    static integer ng;
    static integer idpage, idmode;
    extern integer vgkdec_(real *);
    static char gofile[6], devnam[3];
    static integer jvcode, idmaxp;
    extern /* Subroutine */ int vgmodg_(integer *, real *, real *, real *, 
	    real *, real *, real *, integer *, integer *, integer *, integer *
	    , integer *, integer *, integer *, integer *, integer *, integer *
	    , real *, real *, real *, real *), vgsmbl_(real *, real *, real *,
	     char *, real *, integer *, ftnlen), vgcmnt_(char *, ftnlen);
    static logical docurs;
    static char pagstr[2];
    extern /* Subroutine */ int vgucom_(void);
    static integer iscont;
    extern /* Subroutine */ int vgletr_(integer *, logical *), vgrest_(
	    integer *, integer *), vgvcur_(char *, integer *, integer *, real 
	    *, real *, ftnlen);
    extern integer vgistr_(char *, ftnlen);
    extern /* Subroutine */ int vgplts_(void), vgxcur_(real *, real *);
    static integer idc, idr, itc, len, itr;

    /* Fortran I/O blocks */
    static cilist io___13 = { 0, 6, 0, 0, 0 };
    static icilist io___23 = { 0, pagstr, 0, "(I2.2)", 2, 1 };
    static cilist io___25 = { 0, 6, 0, 0, 0 };
    static icilist io___32 = { 0, pagstr, 0, "(I2.2)", 2, 1 };
    static cilist io___33 = { 0, 6, 0, 0, 0 };
    static cilist io___35 = { 0, 6, 0, 0, 0 };
    static cilist io___36 = { 0, 6, 0, 0, 0 };


/*         ORIGINAL NAME INTER */
/* ENTERING THE INTERACTIVE PART OF THE PROGRAM (THIS IS CALLED BY ILOOP()
).*/
    if (go) {
	vgbat_(contin);
	return 0;
    }
    *contin = TRUE_;
    vgloop_1.pass2 = FALSE_;
    ng = vgcntr_1.ig - 1;
    vgcntr_1.ig = 1;
/*     KG=1 Moved this to data statement so active graph will */
/*     not reset to 1 each time - wea */
    if (vgloop_1.pass1) {
	agrafg_(&ie, &idmode, &idc, &idr, &itc, &itr, &idpage, &idmaxp);
	if (idmode == 1) {
	    agraf0_(&ie, &c__0);
	}
	if (ie == -1) {
	    s_wsle(&io___13);
	    do_lio(&c__9, &c__1, "No Graphics...", 14L);
	    e_wsle();
	    vgbat_(contin);
	    return 0;
	}
	if (vgloop_1.istat == 0) {
	    vgfnd_();
	    vgpnf_1.idevic = 10;
	    vgplts_();
	}
	vgloop_1.pass1 = FALSE_;
	vgloop_1.pass2 = TRUE_;
	xcurs = 12.5f;
	ycurs = 9.45f;
	docurs = FALSE_;
	return 0;
    }
/*  DRAW ALL NON-BOUND TEXT */
    if (vgtx1_1.ntex > 0) {
	vgcmnt_("Drawing...", 10L);
	i__1 = vgtx1_1.ntex;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if (vgtx1_1.so[i__ - 1] == 0) {
		len = vgistr_(vgtx2_1.st + (i__ - 1) * 70, 70L);
		vgnp_(&vgtx1_1.sc[i__ - 1]);
		vgsmbl_(&vgtx1_1.sx[i__ - 1], &vgtx1_1.sy[i__ - 1], &
			vgtx1_1.sh[i__ - 1], vgtx2_1.st + (i__ - 1) * 70, &
			vgtx1_1.sa[i__ - 1], &len, 70L);
	    }
/* L10: */
	}
	vgcmnt_(" ", 1L);
    }
    if (iq == 1) {
/*  CLOSE HIGHER QUALITY OUTPUT FILE */
	iq = 0;
	vgpl_(&c_b9, &c_b9, &c__999);
	cl__1.cerr = 0;
	cl__1.cunit = 60;
	cl__1.csta = 0;
	f_clos(&cl__1);
	vgpnf_1.idevic = 10;
	vgplts_();
	vgcmnt_(" ", 1L);
    }
    vgcor_(&vglttr_1.bleft0[kg - 1], &vglttr_1.brit0[kg - 1], &vglttr_1.btop0[
	    kg - 1], &vglttr_1.bbot0[kg - 1]);
    vgucom_();
L200:
/*  WAIT FOR USER'S KEYSTROKE AND THEN INTERPRET IT, UNLESS USER HAS */
/*         SET EXIT CHARACTER TO 0, THEN IMMEDIATELY CONTINUE. */
/*             (DKK) 24 FEB 1989 */
    if (vgloop_1.jexit != 0) {
L201:
	if (! agrafa_(&c__0, &c__1, &kcurr, &kflag)) {
	    goto L201;
	}
    } else {
	kcurr = 0;
    }
    *(unsigned char *)ch = (char) kcurr;
/*  IF THE CURSOR IS ACTIVE, UPDATE IT */
    if (docurs) {
	vgvcur_(ch, &kcurr, &kg, &xcurs, &ycurs, 1L);
    }
    if (kcurr == 32 && ng > 1) {
/*  MOVE TO NEXT GRAPH. */
	vgcor_(&vglttr_1.bleft0[kg - 1], &vglttr_1.brit0[kg - 1], &
		vglttr_1.btop0[kg - 1], &vglttr_1.bbot0[kg - 1]);
	++kg;
	if (kg > ng) {
	    kg = 1;
	}
	vgcor_(&vglttr_1.bleft0[kg - 1], &vglttr_1.brit0[kg - 1], &
		vglttr_1.btop0[kg - 1], &vglttr_1.bbot0[kg - 1]);
	goto L200;
    }
    if (kcurr == 8 && ng > 1) {
/*  MOVE TO PREVIOUS GRAPH. */
	vgcor_(&vglttr_1.bleft0[kg - 1], &vglttr_1.brit0[kg - 1], &
		vglttr_1.btop0[kg - 1], &vglttr_1.bbot0[kg - 1]);
	--kg;
	if (kg == 0) {
	    kg = ng;
	}
	vgcor_(&vglttr_1.bleft0[kg - 1], &vglttr_1.brit0[kg - 1], &
		vglttr_1.btop0[kg - 1], &vglttr_1.bbot0[kg - 1]);
	goto L200;
    }
    if (kcurr == 13 || kcurr == vgloop_1.jexit || kcurr == 10) {
/*  CLEAR SCREEN AND RETURN TO USER'S MAIN IN TEXT MODE: */
	vgcmnt_(" ", 1L);
	agraf0_(&ie, &c__1);
	if (vgprnt_1.pb4xit) {
/*  MAKE PRINTING FILE BEFORE EXITTING */
	    s_wsfi(&io___23);
	    do_fio(&c__1, (char *)&vgfil2_1.numpag, (ftnlen)sizeof(integer));
	    e_wsfi();
	    len = vgistr_(vgfil1_1.filnam, 6L);
/* Writing concatenation */
	    i__2[0] = len, a__1[0] = vgfil1_1.filnam;
	    i__2[1] = 2, a__1[1] = pagstr;
	    i__2[2] = 1, a__1[2] = ".";
	    i__2[3] = 3, a__1[3] = vgfil1_1.exten;
	    s_cat(name__, a__1, i__2, &c__4, 80L);
	    s_wsle(&io___25);
/* Writing concatenation */
	    i__3[0] = 23, a__2[0] = "SENDING OUTPUT TO FILE ";
	    i__3[1] = 80, a__2[1] = name__;
	    s_cat(ch__1, a__2, i__3, &c__2, 103L);
	    do_lio(&c__9, &c__1, ch__1, 103L);
	    e_wsle();
	    o__1.oerr = 1;
	    o__1.ounit = 60;
	    o__1.ofnmlen = 80;
	    o__1.ofnm = name__;
	    o__1.orl = 0;
	    o__1.osta = "UNKNOWN";
	    o__1.oacc = 0;
	    o__1.ofm = 0;
	    o__1.oblnk = 0;
	    i__1 = f_open(&o__1);
	    if (i__1 != 0) {
		goto L350;
	    }
	    ++vgfil2_1.numpag;
	    vgpnf_1.idevic = vgloop_1.mdevic;
	    vgplts_();
	    *contin = TRUE_;
	    vgbt_1.baton = TRUE_;
	} else {
	    *contin = FALSE_;
	}
	return 0;
    }
    if (i_indx("AaDdEeLlPpTtZz", ch, 14L, 1L) > 0) {
	vgcor_(&vglttr_1.bleft0[kg - 1], &vglttr_1.brit0[kg - 1], &
		vglttr_1.btop0[kg - 1], &vglttr_1.bbot0[kg - 1]);
	vgucom_();
    }
    if (*(unsigned char *)ch == 'A' || *(unsigned char *)ch == 'a') {
/*  REARRANGE THE GRAPHS ON THE SCREEN */
	vgarr_(vglttr_1.btop0, vglttr_1.bbot0, vglttr_1.bleft0, 
		vglttr_1.brit0, &kg, &ng, vglim_1.btop1, vglim_1.bbot1, 
		vglim_1.bleft1, vglim_1.brit1, &iesc);
	if (iesc == 1) {
	    goto L300;
	}
	*contin = TRUE_;
	agraf0_(&ie, &c__0);
	docurs = FALSE_;
	return 0;
    }
    if (*(unsigned char *)ch == 'D' || *(unsigned char *)ch == 'd') {
/*  DUMP SCREEN ON EPSON-TYPE PRINTER. */
	agraf4_(&ie);
	goto L300;
    }
    if (*(unsigned char *)ch == 'E' || *(unsigned char *)ch == 'e') {
/*  EDIT GRAPH DATA */
	vgcmnt_(" ", 1L);
	vgmodg_(&kg, &vglim_1.bxmin[kg - 1], &vglim_1.bxmax[kg - 1], &
		vglim_1.bymin[kg - 1], &vglim_1.bymax[kg - 1], &vglim_1.bymin[
		kg + 6], &vglim_1.bymax[kg + 6], &vglim_1.ninlx[kg - 1], &
		vglim_1.naxlx[kg - 1], &vglim_1.ninly[kg - 1], &vglim_1.naxly[
		kg - 1], &vglim_1.ninly[kg + 6], &vglim_1.naxly[kg + 6], &
		vglim_1.msx[kg - 1], &vglim_1.msy[kg - 1], &vglim_1.msy[kg + 
		6], &vglttr_1.kludge[kg - 1], &vglim_1.btop1[kg - 1], &
		vglim_1.bbot1[kg - 1], &vglim_1.bleft1[kg - 1], &
		vglim_1.brit1[kg - 1]);
	calc = FALSE_;
	if (vglim_1.msx[kg - 1] == 1) {
	    vglim_1.ninlx[kg - 1] = vgkdec_(&vglim_1.bxmin[kg - 1]) - 1;
	    vglim_1.naxlx[kg - 1] = vgihi_(&vglim_1.bxmax[kg - 1]) - 1;
	}
	if (vglim_1.msy[kg - 1] == 1) {
	    vglim_1.ninly[kg - 1] = vgkdec_(&vglim_1.bymin[kg - 1]) - 1;
	    vglim_1.naxly[kg - 1] = vgihi_(&vglim_1.bymax[kg - 1]) - 1;
	}
	if (vglim_1.msy[kg + 6] == 1) {
	    vglim_1.ninly[kg + 6] = vgkdec_(&vglim_1.bymin[kg + 6]) - 1;
	    vglim_1.naxly[kg + 6] = vgihi_(&vglim_1.bymax[kg + 6]) - 1;
	}
	jvcode = (vglttr_1.kludge[kg - 1] / pow_ii(&c__2, &c__8) % 2 << 1) + 
		vglttr_1.kludge[kg - 1] / pow_ii(&c__2, &c__7) % 2;
	iscont = vglttr_1.kludge[kg - 1] / pow_ii(&c__2, &c__9) % 2;
	goto L250;
    }
    if (*(unsigned char *)ch == 'H' || *(unsigned char *)ch == 'h') {
/*  SET NEW HIGHER QUALITY GRAPHICS DEVICE */
	vggl_(&ie, "Device Name:", devnam, &c__3, 12L, 3L);
	if (s_cmp(devnam, "tek", 3L, 3L) == 0 || s_cmp(devnam, "TEK", 3L, 3L) 
		== 0) {
	    vgloop_1.mdevic = 0;
	    s_copy(vgfil1_1.exten, devnam, 3L, 3L);
	} else if (s_cmp(devnam, "hpg", 3L, 3L) == 0 || s_cmp(devnam, "HPG", 
		3L, 3L) == 0) {
	    vgloop_1.mdevic = 20;
	    s_copy(vgfil1_1.exten, devnam, 3L, 3L);
	} else if (s_cmp(devnam, "qms", 3L, 3L) == 0 || s_cmp(devnam, "QMS", 
		3L, 3L) == 0) {
	    vgloop_1.mdevic = 21;
	    s_copy(vgfil1_1.exten, devnam, 3L, 3L);
	} else if (s_cmp(devnam, "pos", 3L, 3L) == 0 || s_cmp(devnam, "POS", 
		3L, 3L) == 0) {
	    vgloop_1.mdevic = 22;
	    s_copy(vgfil1_1.exten, devnam, 3L, 3L);
	} else if (s_cmp(devnam, "ljt", 3L, 3L) == 0 || s_cmp(devnam, "LJT", 
		3L, 3L) == 0) {
	    vgloop_1.mdevic = 23;
	    s_copy(vgfil1_1.exten, devnam, 3L, 3L);
	} else if (s_cmp(devnam, "psq", 3L, 3L) == 0 || s_cmp(devnam, "PSQ", 
		3L, 3L) == 0) {
	    vgloop_1.mdevic = 24;
	    s_copy(vgfil1_1.exten, devnam, 3L, 3L);
	}
/*           Added this jump 3/1/89 (DKK) */
	goto L200;
    }
    if (*(unsigned char *)ch == 'G' || *(unsigned char *)ch == 'g') {
	vggl_(&ie, "File name:  ", gofile, &c__6, 12L, 6L);
	s_wsfi(&io___32);
	do_fio(&c__1, (char *)&vgfil2_1.numpag, (ftnlen)sizeof(integer));
	e_wsfi();
	len = vgistr_(gofile, 6L);
	if (len == 0) {
	    goto L200;
	}
/* Writing concatenation */
	i__2[0] = len, a__1[0] = gofile;
	i__2[1] = 2, a__1[1] = pagstr;
	i__2[2] = 1, a__1[2] = ".";
	i__2[3] = 3, a__1[3] = vgfil1_1.exten;
	s_cat(name__, a__1, i__2, &c__4, 80L);
	agraf0_(&ie, &c__1);
	s_wsle(&io___33);
/* Writing concatenation */
	i__3[0] = 23, a__2[0] = "SENDING OUTPUT TO FILE ";
	i__3[1] = 80, a__2[1] = name__;
	s_cat(ch__1, a__2, i__3, &c__2, 103L);
	do_lio(&c__9, &c__1, ch__1, 103L);
	e_wsle();
	o__1.oerr = 1;
	o__1.ounit = 60;
	o__1.ofnmlen = 80;
	o__1.ofnm = name__;
	o__1.orl = 0;
	o__1.osta = "UNKNOWN";
	o__1.oacc = 0;
	o__1.ofm = 0;
	o__1.oblnk = 0;
	i__1 = f_open(&o__1);
	if (i__1 != 0) {
	    goto L350;
	}
	++vgfil2_1.numpag;
	vgpnf_1.idevic = vgloop_1.mdevic;
	vgplts_();
	vgbt_1.baton = TRUE_;
	go = TRUE_;
	*contin = TRUE_;
	docurs = FALSE_;
/* ADDED FOLLOWING LINE TO CHANGE PLOT FILENAME FOR REMAINDER */
/* OF PLOTS  1/90 (WEA) */
	s_copy(vgfil1_1.filnam, gofile, 6L, len);
	return 0;
    }
    if (*(unsigned char *)ch == 'L' || *(unsigned char *)ch == 'l') {
/*  ENTER LEGEND-MOVING MODE. */
	vgcmnt_("Legend Mode", 11L);
	vglmv_(&ng, &kg);
	vgcmnt_(" ", 1L);
	goto L300;
    }
    if (*(unsigned char *)ch == 'O' || *(unsigned char *)ch == 'o') {
/*  RETURN TO USER'S PROGRAM, OVERRIDING AUTOMATIC PRINTING */
	vgcmnt_(" ", 1L);
	agraf0_(&ie, &c__1);
	*contin = FALSE_;
	return 0;
    }
    if (*(unsigned char *)ch == 'P' || *(unsigned char *)ch == 'p') {
/*  SEND HIGHER QUALITY GRAPHICS TO FILE OR PORT. */
	vggl_(&len, "File name:  ", name__, &c__50, 12L, 80L);
	if (len > 0) {
	    o__1.oerr = 1;
	    o__1.ounit = 60;
	    o__1.ofnmlen = 80;
	    o__1.ofnm = name__;
	    o__1.orl = 0;
	    o__1.osta = "UNKNOWN";
	    o__1.oacc = 0;
	    o__1.ofm = 0;
	    o__1.oblnk = 0;
	    i__1 = f_open(&o__1);
	    if (i__1 != 0) {
		goto L200;
	    }
	    iq = 1;
	    vgpnf_1.idevic = vgloop_1.mdevic;
	    vgcmnt_("Writing File...", 15L);
	    vgplts_();
	    *contin = TRUE_;
	    return 0;
	}
	goto L300;
    }
    if (*(unsigned char *)ch == 'R' || *(unsigned char *)ch == 'r') {
/*  RESTORE TO STATE BEFORE LAST ZOOM. */
	vgrest_(&kg, &iend);
	if (iend == 1) {
	    goto L200;
	}
	calc = TRUE_;
	goto L250;
    }
    if (*(unsigned char *)ch == 'S' || *(unsigned char *)ch == 's') {
/*  TOGGLE CURSOR DISPLAY */
	docurs = ! docurs;
	vgxcur_(&xcurs, &ycurs);
	if (! docurs) {
	    vgcmnt_(" ", 1L);
	}
    }
    if (*(unsigned char *)ch == 'T' || *(unsigned char *)ch == 't') {
/*  TRANSLATE AND ROTATE TEXT STRINGS. */
	vgtmv_(vglim_1.btop1, vglim_1.bbot1, vglim_1.bleft1, vglim_1.brit1, &
		kg, &ng, &iesc);
	if (iesc == 1) {
	    goto L300;
	}
	agraf0_(&ie, &c__0);
	*contin = TRUE_;
	docurs = FALSE_;
	return 0;
    }
    if (*(unsigned char *)ch == 'X' || *(unsigned char *)ch == 'x') {
/*  REDRAW THE SCREEN (CLEARS UP JUNK OR SMEARED TEXT STRINGS.) */
	agraf0_(&ie, &c__0);
	*contin = TRUE_;
	docurs = FALSE_;
	return 0;
    }
    if (*(unsigned char *)ch == 'Z' || *(unsigned char *)ch == 'z') {
/*  ENTER ZOOM MODE. */
/*       JVCODE=4*VGIBIT(8,KLUDGE(KG))+2*VGIBIT(7,KLUDGE(KG))+ */
/*    1         vgibit(6,kludge(kg)) */
	jvcode = vglttr_1.kludge[kg - 1] % 128 / 32;
	vgcmnt_("Zoom Mode", 9L);
	vgzm_(&kg, &iesc, &jvcode);
	vgcmnt_(" ", 1L);
	if (iesc == 1) {
	    goto L300;
	}
/*  ISCONT SET TO 0 EVEN IF THE KG-TH GRAPH IS A CONTOR PLOT */
/*  AS THERE IS NO NEED TO RECALCULATE THE Z-AXIS DATA AFTER A ZOOM. 
*/
	iscont = 0;
	calc = TRUE_;
/*  CHANGE STRINGS WITH 'STICK TO POINT' MODE TO 'KEEP DISTANCE' MODE 
*/
	i__1 = vgtx1_1.ntex;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if (vgtx1_1.so[i__ - 1] == kg && vgtx1_1.sm[i__ - 1] == 2) {
		vgtx1_1.sm[i__ - 1] = 1;
	    }
/* L240: */
	}
	goto L250;
    }
/*  IF KEY PRESSED WASN'T A COMMAND, GET ANOTHER */
    goto L200;
L250:
    agraf0_(&ie, &c__0);
/*  CALCULATE NUMBER OF TICK MARKS ON EACH AXIS */
/*  SETTING IG=KG HERE NEEDED FOR VGTIC:  VGTIC USES */
/*  COMMON VGCNTR TO INDEX PROPER GRAPH. */
    vgcntr_1.ig = kg;
    vgtic_(&vglim_1.msx[kg - 1], &vgtic1_1.nh[kg - 1], &vglim_1.bxmin[kg - 1],
	     &vglim_1.bxmax[kg - 1], &vglim_1.ninlx[kg - 1], &vglim_1.naxlx[
	    kg - 1], &c__1, &vglttr_1.isdx[kg - 1], &calc);
    vgtic_(&vglim_1.msy[kg - 1], &vgtic1_1.nv1[kg - 1], &vglim_1.bymin[kg - 1]
	    , &vglim_1.bymax[kg - 1], &vglim_1.ninly[kg - 1], &vglim_1.naxly[
	    kg - 1], &c__2, &vglttr_1.isdy1[kg - 1], &calc);
    if (jvcode == 3 || iscont == 1) {
	vgtic_(&vglim_1.msy[kg + 6], &vgtic1_1.nv2[kg - 1], &vglim_1.bymin[kg 
		+ 6], &vglim_1.bymax[kg + 6], &vglim_1.ninly[kg + 6], &
		vglim_1.naxly[kg + 6], &c__3, &vglttr_1.isdy2[kg - 1], &calc);
    }
    vgcntr_1.ig = 1;
/*  DRAW NUMBERS AND AXIS LABELS: */
    vgletr_(&kg, &c_true);
    *contin = TRUE_;
    docurs = FALSE_;
    return 0;
L300:
    vgcor_(&vglttr_1.bleft0[kg - 1], &vglttr_1.brit0[kg - 1], &vglttr_1.btop0[
	    kg - 1], &vglttr_1.bbot0[kg - 1]);
    vgucom_();
    goto L200;
L350:
    s_wsle(&io___35);
/* Writing concatenation */
    i__3[0] = 15, a__2[0] = "UNABLE TO OPEN ";
    i__3[1] = 14, a__2[1] = name__;
    s_cat(ch__2, a__2, i__3, &c__2, 29L);
    do_lio(&c__9, &c__1, ch__2, 29L);
    e_wsle();
    s_wsle(&io___36);
    do_lio(&c__9, &c__1, "HIT A KEY.", 10L);
    e_wsle();
L360:
    if (! agrafa_(&c__0, &c__1, &kcurr, &kflag)) {
	goto L360;
    }
    agraf0_(&ie, &c__0);
    *contin = TRUE_;
    return 0;
} /* vgint_ */

/*       -       -       -       -       -       -       -       - */
integer loopin_(void)
{
    /* System generated locals */
    integer ret_val;

    /* Local variables */
    extern /* Subroutine */ int vgbat_(logical *), vgint_(logical *);
    static logical contin;

/*  ENTERS THE INTERACTIVE PART OF VG. */
/*  BATON WILL BE TRUE HERE IF THE USER ATTEMPTED TO RUN AN INTERACTIVE */
/*  PROGRAM ON A TERMINAL WITH NO GRAPHICS CAPABILITY. */
    if (vgbt_1.baton) {
	vgbat_(&contin);
    } else {
	vgint_(&contin);
    }
    if (contin) {
	ret_val = 1;
    } else {
	ret_val = 0;
    }
    return ret_val;
} /* loopin_ */

/* Subroutine */ int vgfnd_(void)
{
    /* Initialized data */

    static integer ntxcol = 80;
    static integer ntxrow = 25;

    extern /* Subroutine */ int vgsiz_(integer *, integer *);
    static integer ie;
    static integer idpage, idmode, idmaxp;

/*         ORIGINAL NAME FIND */
/*  FINDS THE SCREEN DIMENSIONS (IN PIXELS). */
/*           DATA LOAD NTXCOL AND NTXROW (DKK) 22 SEPT 1988 */
    if (! vgbt_1.baton) {
	agrafg_(&ie, &idmode, &vgscrn_1.ncols, &vgscrn_1.nrows, &ntxcol, &
		ntxrow, &idpage, &idmaxp);
    } else {
	vgscrn_1.ncols = 80;
	vgscrn_1.nrows = 30;
	ntxcol = 80;
	ntxrow = 30;
    }
    vgsiz_(&vgscrn_1.ncols, &vgscrn_1.nrows);
    vgtxt_1.jpw = vgscrn_1.ncols / ntxcol;
    vgtxt_1.jph = vgscrn_1.nrows / ntxrow;
    vgloop_1.istat = 1;
    return 0;
} /* vgfnd_ */

/* Subroutine */ int vgvcur_(char *ch, integer *kcurr, integer *kg, real *
	xcurs, real *ycurs, ftnlen ch_len)
{
    /* Initialized data */

    static real sht = 18.75f;
    static real swid = 25.f;
    static real am = .095f;

    /* System generated locals */
    address a__1[2], a__2[4];
    integer i__1[2], i__2[4];

    /* Builtin functions */
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen),
	     s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer lent1, lent2;
    static char temp1[70], temp2[70], temp3[70];
    extern doublereal vgs2g_(real *, real *, real *, real *, real *, integer *
	    , integer *, integer *);
    extern /* Subroutine */ int sleep_(integer *), vgunp_(char *, ftnlen);
    static real xcurr, ycurr, gx, gy;
    extern /* Subroutine */ int vgcorf_(integer *, real *, real *, integer *, 
	    integer *, real *, real *, real *, real *, real *, real *, real *,
	     real *), vgcmnt_(char *, ftnlen), vgcurs_(real *, real *);
    extern integer vgistr_(char *, ftnlen);
    extern /* Subroutine */ int vgxcur_(real *, real *);
    static char curstx[70];
    static real dum1, dum2;

    /* Fortran I/O blocks */
    static icilist io___54 = { 0, temp1, 0, "(F14.6)", 70, 1 };
    static icilist io___56 = { 0, temp2, 0, "(F14.6)", 70, 1 };


/*  MOVES THE CURSOR AND DRAWS ITS COORDS. */
    vgxcur_(xcurs, ycurs);
    dum1 = *xcurs;
    dum2 = *ycurs;
/* WEA 10/89 SWID & SHT WERE INTERCHANGED PREVENTING PROPER CURSOR */
/*     MOVEMENT */
    vgcorf_(&c__0, &am, &c_b9, kcurr, &c__0, &c_b9, &swid, &c_b9, &sht, xcurs,
	     &dum1, ycurs, &dum2);
    if (*(unsigned char *)ch == '*') {
	vgxcur_(&xcurr, &ycurr);
	sleep_(&c__1);
	vgxcur_(&xcurr, &ycurr);
/*  CALL USER'S CURSOR DATA LOGGING ROUTINE */
	gx = (real)vgs2g_(xcurs, &vglim_1.bleft1[*kg - 1], &vglim_1.brit1[*kg 
		- 1], &vglim_1.bxmin[*kg - 1], &vglim_1.bxmax[*kg - 1], &
		vglim_1.ninlx[*kg - 1], &vglim_1.naxlx[*kg - 1], &vglim_1.msx[
		*kg - 1]);
	gy = (real)vgs2g_(ycurs, &vglim_1.bbot1[*kg - 1], &vglim_1.btop1[*kg 
		- 1], &vglim_1.bymin[*kg - 1], &vglim_1.bymax[*kg - 1], &
		vglim_1.ninly[*kg - 1], &vglim_1.naxly[*kg - 1], &vglim_1.msy[
		*kg - 1]);
	vgcurs_(&gx, &gy);
    }
    if (*(unsigned char *)ch == 'C' || *(unsigned char *)ch == 'c') {
	am = sht * .05f;
    }
    if (*(unsigned char *)ch == 'F' || *(unsigned char *)ch == 'f') {
	am = sht * .005f;
    }
    if (*(unsigned char *)ch == 'W' || *(unsigned char *)ch == 'w') {
/*  'WHERE' COMMAND: DISPLAY CURRENT CURSOR LOCATION */
	gx = (real)vgs2g_(xcurs, &vglim_1.bleft1[*kg - 1], &vglim_1.brit1[*kg 
		- 1], &vglim_1.bxmin[*kg - 1], &vglim_1.bxmax[*kg - 1], &
		vglim_1.ninlx[*kg - 1], &vglim_1.naxlx[*kg - 1], &vglim_1.msx[
		*kg - 1]);
	gy = (real)vgs2g_(ycurs, &vglim_1.bbot1[*kg - 1], &vglim_1.btop1[*kg 
		- 1], &vglim_1.bymin[*kg - 1], &vglim_1.bymax[*kg - 1], &
		vglim_1.ninly[*kg - 1], &vglim_1.naxly[*kg - 1], &vglim_1.msy[
		*kg - 1]);
	s_wsfi(&io___54);
	do_fio(&c__1, (char *)&gx, (ftnlen)sizeof(real));
	e_wsfi();
	s_wsfi(&io___56);
	do_fio(&c__1, (char *)&gy, (ftnlen)sizeof(real));
	e_wsfi();
	vgunp_(temp1, 70L);
	vgunp_(temp2, 70L);
	lent1 = vgistr_(temp1, 70L);
	lent2 = vgistr_(temp2, 70L);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = "(";
	i__1[1] = lent1, a__1[1] = temp1;
	s_cat(curstx, a__1, i__1, &c__2, 70L);
/* Writing concatenation */
	i__2[0] = lent1 + 1, a__2[0] = curstx;
	i__2[1] = 1, a__2[1] = ",";
	i__2[2] = lent2, a__2[2] = temp2;
	i__2[3] = 1, a__2[3] = ")";
	s_cat(temp3, a__2, i__2, &c__4, 70L);
	s_copy(curstx, temp3, 70L, 70L);
	vgcmnt_(curstx, 70L);
    }
    vgxcur_(xcurs, ycurs);
    return 0;
} /* vgvcur_ */

