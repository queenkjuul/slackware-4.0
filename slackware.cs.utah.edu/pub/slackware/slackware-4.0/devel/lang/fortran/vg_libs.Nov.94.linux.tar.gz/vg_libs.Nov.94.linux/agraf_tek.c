/* agraf_tek.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    real grafflg;
} gflag_;

#define gflag_1 gflag_

/* Table of constant values */

static integer c__9 = 9;
static integer c__1 = 1;

/*  AGRAF.F  - Plotting service routines for AGRAF */
/*  This file contains the following FORTRAN functions: */
/*    agraf0   - Sets screen mode to graphics or text. */
/*    agraf4   - Print screen (nonoperable) */
/*    agraff   - Plot lines, characters. */
/*    agrafg   - Set screen dimensions */
/*    agrafi   - Erase screen */

/* Subroutine */ void agraf0_(integer *ierr, integer *imode)
{
    /* Builtin functions */
    integer s_wsle(cilist *), do_lio(integer *, integer *, char *, ftnlen), 
	    e_wsle(void);

    /* Local variables */
    static char string[5];

    /* Fortran I/O blocks */
    static cilist io___2 = { 0, 6, 0, 0, 0 };
    static cilist io___3 = { 0, 6, 0, 0, 0 };


    if (*imode == 0) {
	*(unsigned char *)string = '\r';
	*(unsigned char *)&string[1] = '\33';
	*(unsigned char *)&string[2] = '\f';
	*(unsigned char *)&string[3] = '\35';
/*       write(*,100)string(1:4) */
	s_wsle(&io___2);
	do_lio(&c__9, &c__1, string, 4L);
	e_wsle();
	gflag_1.grafflg = 1.f;
    } else if (*imode == 1) {
	*(unsigned char *)string = '\r';
	*(unsigned char *)&string[1] = '\33';
	*(unsigned char *)&string[2] = '\f';
/*       string(4:4)= char(31) */
/*       string(4:4)= char(27) */
/*       string(5:5)= char(12) */
/*       write(*,100)string(1:4) */
	s_wsle(&io___3);
	do_lio(&c__9, &c__1, string, 3L);
	e_wsle();
	gflag_1.grafflg = 0.f;
    }
/*     read *, j */
/*     print *,"entered agraf0, imode = ",imode */
    /*    return 0; */
/* L100: */
} /* agraf0_ */

/* Subroutine */ short agraf4_(integer *ier)
{
/*    ier = hdcopy() */
/*    ier = system("/usr/local/qplot") */
/*    return */
    return 0;
} /* agraf4_ */

/* Subroutine */ void agraff_(integer *iretcd, integer *iptype, integer *n, 
	integer *ix, integer *iy)
{
    /* Initialized data */

    static integer clrflg = 0;

    /* Format strings */
    static char fmt_100[] = "(1x,a)";

    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__, j, y, bitop, color, y1, bracln, charty;
    static char string[255];
    static integer lintyp;

    /* Fortran I/O blocks */
    static cilist io___13 = { 0, 6, 0, fmt_100, 0 };
    static cilist io___15 = { 0, 6, 0, fmt_100, 0 };
    static cilist io___17 = { 0, 6, 0, fmt_100, 0 };
    static cilist io___18 = { 0, 6, 0, fmt_100, 0 };
    static cilist io___19 = { 0, 6, 0, fmt_100, 0 };
    static cilist io___20 = { 0, 6, 0, fmt_100, 0 };
    static cilist io___21 = { 0, 6, 0, fmt_100, 0 };


    /* Parameter adjustments */
    --iy;
    --ix;

    /* Function Body */
    charty = *iptype / 256;
    color = (*iptype - (charty << 8)) / 16;
    bitop = (*iptype - (charty << 8) - (color << 4)) / 8;
    lintyp = *iptype - (charty << 8) - (color << 4) - (bitop << 3);
    lintyp %= 6;
    color %= 15;
    if (*n > 1 && lintyp > 0) {
	*(unsigned char *)string = '\35';
	y = 750 - iy[1];
	*(unsigned char *)&string[1] = (char) (y / 32 % 32 + 32);
	*(unsigned char *)&string[2] = (char) (y % 32 + 96);
	*(unsigned char *)&string[3] = (char) (ix[1] / 32 % 32 + 32);
	*(unsigned char *)&string[4] = (char) (ix[1] % 32 + 64);
	j = 5;
	i__1 = *n - 1;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    y = 750 - iy[i__ + 1];
	    ++j;
	    if (j >= 74) {
		*(unsigned char *)&string[j - 1] = '\37';
		s_wsfe(&io___13);
		do_fio(&c__1, string, j);
		e_wsfe();
		*(unsigned char *)string = '\35';
		y1 = 750 - iy[i__];
		*(unsigned char *)&string[1] = (char) (y1 / 32 % 32 + 32);
		*(unsigned char *)&string[2] = (char) (y1 % 32 + 96);
		*(unsigned char *)&string[3] = (char) (ix[i__] / 32 % 32 + 32)
			;
		*(unsigned char *)&string[4] = (char) (ix[i__] % 32 + 64);
		j = 6;
	    }
	    *(unsigned char *)&string[j - 1] = (char) (y / 32 % 32 + 32);
	    ++j;
	    *(unsigned char *)&string[j - 1] = (char) (y % 32 + 96);
	    ++j;
	    *(unsigned char *)&string[j - 1] = (char) (ix[i__ + 1] / 32 % 32 
		    + 32);
	    ++j;
	    *(unsigned char *)&string[j - 1] = (char) (ix[i__ + 1] % 32 + 64);
/* L10: */
	}
	++j;
	*(unsigned char *)&string[j - 1] = '\37';
	s_wsfe(&io___15);
	do_fio(&c__1, string, j);
	e_wsfe();
    } else if (charty == 191 || charty == 192 || charty == 217 || charty == 
	    218) {
	bracln = 20.f;
	if (charty == 191) {
	    *(unsigned char *)string = '\35';
	    y = 750 - iy[1];
	    *(unsigned char *)&string[1] = (char) (y / 32 % 32 + 32);
	    *(unsigned char *)&string[2] = (char) (y % 32 + 96);
	    *(unsigned char *)&string[3] = (char) ((ix[1] - bracln) / 32 % 32 
		    + 32);
	    *(unsigned char *)&string[4] = (char) ((ix[1] - bracln) % 32 + 64)
		    ;
	    *(unsigned char *)&string[5] = (char) (y / 32 % 32 + 32);
	    *(unsigned char *)&string[6] = (char) (y % 32 + 96);
	    *(unsigned char *)&string[7] = (char) (ix[1] / 32 % 32 + 32);
	    *(unsigned char *)&string[8] = (char) (ix[1] % 32 + 64);
	    *(unsigned char *)&string[9] = (char) ((y - bracln) / 32 % 32 + 
		    32);
	    *(unsigned char *)&string[10] = (char) ((y - bracln) % 32 + 96);
	    *(unsigned char *)&string[11] = (char) (ix[1] / 32 % 32 + 32);
	    *(unsigned char *)&string[12] = (char) (ix[1] % 32 + 64);
	    *(unsigned char *)&string[13] = '\37';
	    s_wsfe(&io___17);
	    do_fio(&c__1, string, 14L);
	    e_wsfe();
	}
	if (charty == 192) {
	    *(unsigned char *)string = '\35';
	    y = 750 - iy[1];
	    *(unsigned char *)&string[1] = (char) ((y + bracln) / 32 % 32 + 
		    32);
	    *(unsigned char *)&string[2] = (char) ((y + bracln) % 32 + 96);
	    *(unsigned char *)&string[3] = (char) (ix[1] / 32 % 32 + 32);
	    *(unsigned char *)&string[4] = (char) (ix[1] % 32 + 64);
	    *(unsigned char *)&string[5] = (char) (y / 32 % 32 + 32);
	    *(unsigned char *)&string[6] = (char) (y % 32 + 96);
	    *(unsigned char *)&string[7] = (char) (ix[1] / 32 % 32 + 32);
	    *(unsigned char *)&string[8] = (char) (ix[1] % 32 + 64);
	    *(unsigned char *)&string[9] = (char) (y / 32 % 32 + 32);
	    *(unsigned char *)&string[10] = (char) (y % 32 + 96);
	    *(unsigned char *)&string[11] = (char) ((ix[1] + bracln) / 32 % 
		    32 + 32);
	    *(unsigned char *)&string[12] = (char) ((ix[1] + bracln) % 32 + 
		    64);
	    *(unsigned char *)&string[13] = '\37';
	    s_wsfe(&io___18);
	    do_fio(&c__1, string, 14L);
	    e_wsfe();
	}
	if (charty == 217) {
	    *(unsigned char *)string = '\35';
	    y = 750 - iy[1];
	    *(unsigned char *)&string[1] = (char) (y / 32 % 32 + 32);
	    *(unsigned char *)&string[2] = (char) (y % 32 + 96);
	    *(unsigned char *)&string[3] = (char) ((ix[1] - bracln) / 32 % 32 
		    + 32);
	    *(unsigned char *)&string[4] = (char) ((ix[1] - bracln) % 32 + 64)
		    ;
	    *(unsigned char *)&string[5] = (char) (y / 32 % 32 + 32);
	    *(unsigned char *)&string[6] = (char) (y % 32 + 96);
	    *(unsigned char *)&string[7] = (char) (ix[1] / 32 % 32 + 32);
	    *(unsigned char *)&string[8] = (char) (ix[1] % 32 + 64);
	    *(unsigned char *)&string[9] = (char) ((y + bracln) / 32 % 32 + 
		    32);
	    *(unsigned char *)&string[10] = (char) ((y + bracln) % 32 + 96);
	    *(unsigned char *)&string[11] = (char) (ix[1] / 32 % 32 + 32);
	    *(unsigned char *)&string[12] = (char) (ix[1] % 32 + 64);
	    *(unsigned char *)&string[13] = '\37';
	    s_wsfe(&io___19);
	    do_fio(&c__1, string, 14L);
	    e_wsfe();
	}
	if (charty == 218) {
	    *(unsigned char *)string = '\35';
	    y = 750 - iy[1];
	    *(unsigned char *)&string[1] = (char) ((y - bracln) / 32 % 32 + 
		    32);
	    *(unsigned char *)&string[2] = (char) ((y - bracln) % 32 + 96);
	    *(unsigned char *)&string[3] = (char) (ix[1] / 32 % 32 + 32);
	    *(unsigned char *)&string[4] = (char) (ix[1] % 32 + 64);
	    *(unsigned char *)&string[5] = (char) (y / 32 % 32 + 32);
	    *(unsigned char *)&string[6] = (char) (y % 32 + 96);
	    *(unsigned char *)&string[7] = (char) (ix[1] / 32 % 32 + 32);
	    *(unsigned char *)&string[8] = (char) (ix[1] % 32 + 64);
	    *(unsigned char *)&string[9] = (char) (y / 32 % 32 + 32);
	    *(unsigned char *)&string[10] = (char) (y % 32 + 96);
	    *(unsigned char *)&string[11] = (char) ((ix[1] + bracln) / 32 % 
		    32 + 32);
	    *(unsigned char *)&string[12] = (char) ((ix[1] + bracln) % 32 + 
		    64);
	    *(unsigned char *)&string[13] = '\37';
	    s_wsfe(&io___20);
	    do_fio(&c__1, string, 14L);
	    e_wsfe();
	}
    } else {
	if (charty == 68 && iy[1] == 12 && ix[1] == 12) {
	    clrflg = 1;
	}
	if (charty != 68 && iy[1] == 12 && ix[1] == 12) {
	    clrflg = 0;
	}
	if (iy[1] != 12) {
	    clrflg = 0;
	}
	if (clrflg == 0) {
	    *(unsigned char *)string = '\35';
	    y = 750 - iy[1];
	    *(unsigned char *)&string[1] = (char) (y / 32 % 32 + 32);
	    *(unsigned char *)&string[2] = (char) (y % 32 + 96);
	    *(unsigned char *)&string[3] = (char) (ix[1] / 32 % 32 + 32);
	    *(unsigned char *)&string[4] = (char) (ix[1] % 32 + 64);
	    *(unsigned char *)&string[5] = '\37';
	    *(unsigned char *)&string[6] = (char) charty;
	    *(unsigned char *)&string[7] = '\n';
	    s_wsfe(&io___21);
	    do_fio(&c__1, string, 8L);
	    e_wsfe();
	}
    }
    /*    return 0; */
} /* agraff_ */

/* Subroutine */ void agrafg_(integer *iretcd, integer *idmode, integer *igcol,
	 integer *igrow, integer *itcol, integer *itrow, integer *idpage, 
	integer *idmaxp)
{
    *idmode = 1 - gflag_1.grafflg;
    *itcol = 80;
    *itrow = 30;
    *idpage = 1;
    *idmaxp = 1;
    if (gflag_1.grafflg == 1.f) {
	*igcol = 1000;
	*igrow = 750;
    } else {
	*igcol = 80;
	*igrow = 30;
    }
    /*    return 0; */
} /* agrafg_ */

/* Subroutine */ int agrafi_(integer *iretcd, integer *istore, integer *
	iwtype, integer *ix1, integer *iy1, integer *iw, integer *ih, char *
	array)
{
    /* Parameter adjustments */
    --array;

    /* Function Body */
    if (*iwtype == 768) {
    }
/*     print *,"entered agrafi" */
    return 0;
} /* agrafi_ */

