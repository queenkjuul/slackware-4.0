/* sleep in tenth of seconds */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <unistd.h>
#include <f2c.h>

extern     Display *display;

void
sleep_(tenths)
integer *tenths;
{
	unsigned long musecs;

        XFlush(display);
	musecs = 100000UL * (*tenths);
	usleep(musecs);
}
