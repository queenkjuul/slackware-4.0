/* batch.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    logical baton;
} vgbt_;

#define vgbt_1 vgbt_

struct {
    integer idevic, idst, npen;
} vgpnf_;

#define vgpnf_1 vgpnf_

struct {
    char filnam[6], exten[3];
} vgfil1_;

#define vgfil1_1 vgfil1_

struct {
    integer numpag;
} vgfil2_;

#define vgfil2_1 vgfil2_

struct {
    real sx[50], sy[50], sa[50], sh[50];
    integer sc[50], so[50], sm[50], ntex;
} vgtx1_;

#define vgtx1_1 vgtx1_

struct {
    char st[3500];
} vgtx2_;

#define vgtx2_1 vgtx2_

struct {
    logical pass1;
    integer jexit, mdevic, istat;
    logical pass2;
} vgloop_;

#define vgloop_1 vgloop_

struct {
    integer ig;
} vgcntr_;

#define vgcntr_1 vgcntr_

/* Table of constant values */

static integer c__1 = 1;
static integer c__4 = 4;
static integer c__9 = 9;
static real c_b13 = 0.f;
static integer c__999 = 999;

/* Subroutine */ int vgbat_(logical *contin)
{
    /* System generated locals */
    address a__1[4];
    integer i__1[4], i__2;
    olist o__1;
    cllist cl__1;

    /* Builtin functions */
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen);
    integer s_wsle(cilist *), do_lio(integer *, integer *, char *, ftnlen), 
	    e_wsle(void), f_open(olist *), f_clos(cllist *);

    /* Local variables */
    static char name__[12];
    extern /* Subroutine */ int vgpl_(real *, real *, integer *), vgnp_(
	    integer *);
    static integer i__;
    extern /* Subroutine */ int vgsmbl_(real *, real *, real *, char *, real *
	    , integer *, ftnlen);
    static char pagstr[2];
    extern integer vgistr_(char *, ftnlen);
    extern /* Subroutine */ int vgplts_(void);
    static integer len;

    /* Fortran I/O blocks */
    static icilist io___2 = { 0, pagstr, 0, "(I2.2)", 2, 1 };
    static cilist io___5 = { 0, 6, 0, 0, 0 };


/*  BATCH LOOP (THIS IS CALLED BY LOOPBT()). */
    vgcntr_1.ig = 1;
    vgbt_1.baton = TRUE_;
    vgloop_1.pass2 = FALSE_;
    if (vgloop_1.pass1) {
	vgloop_1.pass1 = FALSE_;
	vgloop_1.pass2 = TRUE_;
/*  SEND HIGHER QUALITY GRAPHICS TO FILE */
	vgpnf_1.idevic = vgloop_1.mdevic;
	s_wsfi(&io___2);
	do_fio(&c__1, (char *)&vgfil2_1.numpag, (ftnlen)sizeof(integer));
	e_wsfi();
	len = vgistr_(vgfil1_1.filnam, 6L);
/* Writing concatenation */
	i__1[0] = len, a__1[0] = vgfil1_1.filnam;
	i__1[1] = 2, a__1[1] = pagstr;
	i__1[2] = 1, a__1[2] = ".";
	i__1[3] = 3, a__1[3] = vgfil1_1.exten;
	s_cat(name__, a__1, i__1, &c__4, 12L);
	s_wsle(&io___5);
	do_lio(&c__9, &c__1, "SENDING OUTPUT TO FILE ", 23L);
	do_lio(&c__9, &c__1, name__, 12L);
	e_wsle();
	o__1.oerr = 0;
	o__1.ounit = 60;
	o__1.ofnmlen = 12;
	o__1.ofnm = name__;
	o__1.orl = 0;
	o__1.osta = "UNKNOWN";
	o__1.oacc = 0;
	o__1.ofm = 0;
	o__1.oblnk = 0;
	f_open(&o__1);
	++vgfil2_1.numpag;
	vgplts_();
	*contin = TRUE_;
    } else {
/*  ELSE SECOND PASS */
/*  DRAW ALL NON-BOUND TEXT */
	if (vgtx1_1.ntex > 0) {
	    i__2 = vgtx1_1.ntex;
	    for (i__ = 1; i__ <= i__2; ++i__) {
		len = vgistr_(vgtx2_1.st + (i__ - 1) * 70, 70L);
		vgnp_(&vgtx1_1.sc[i__ - 1]);
		vgsmbl_(&vgtx1_1.sx[i__ - 1], &vgtx1_1.sy[i__ - 1], &
			vgtx1_1.sh[i__ - 1], vgtx2_1.st + (i__ - 1) * 70, &
			vgtx1_1.sa[i__ - 1], &len, 70L);
/* L310: */
	    }
	}
/*  CLOSE HIGHER QUALITY OUTPUT FILE */
	vgpl_(&c_b13, &c_b13, &c__999);
	cl__1.cerr = 0;
	cl__1.cunit = 60;
	cl__1.csta = 0;
	f_clos(&cl__1);
	vgpnf_1.idevic = 10;
	vgplts_();
	*contin = FALSE_;
    }
    return 0;
} /* vgbat_ */

integer loopbt_(void)
{
    /* System generated locals */
    integer ret_val;

    /* Local variables */
    extern /* Subroutine */ int vgbat_(logical *);
    static logical contin;

/*  CALLS THE BATCH LOOP IN VG. */
    vgbat_(&contin);
    if (contin) {
	ret_val = 1;
    } else {
	ret_val = 0;
    }
    return ret_val;
} /* loopbt_ */

