/* adraw.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    real bleft[7], brit[7], bbot[7], btop[7], bxmin[7], bxmax[7], bymin[14]	
	    /* was [7][2] */, bymax[14]	/* was [7][2] */;
    integer logmnx[7], logmxx[7], logmny[14]	/* was [7][2] */, logmxy[14]	
	    /* was [7][2] */, logflx[7], logfly[14]	/* was [7][2] */;
} vglim_;

#define vglim_1 vglim_

struct {
    integer ig;
} vgcntr_;

#define vgcntr_1 vgcntr_

struct {
    char font[5624];
} vgfnt_;

#define vgfnt_1 vgfnt_

struct {
    integer ifptr[256];
} vgfpt_;

#define vgfpt_1 vgfpt_

/* Table of constant values */

static real c_b3 = 0.f;
static integer c_n1 = -1;
static integer c__3 = 3;
static integer c__2 = 2;
static integer c_n16 = -16;
static integer c__0 = 0;
static real c_b27 = 360.f;

/* Subroutine */ int vgadr_(real *x, real *y, integer *n, integer *jdsty, 
	integer *jdcol, integer *jsym, integer *jside, integer *icov, real *
	covlef, real *covrit, real *covbot, real *covtop, integer *incsym, 
	real *symht)
{
    /* System generated locals */
    integer i__1, i__2;
    real r__1, r__2;

    /* Local variables */
    static real amar, abot;
    static integer ipen;
    static real arit, atop;
    extern /* Subroutine */ int vgnp_(integer *);
    static real xmin, ymin, xmax, ymax, a, b;
    static integer i__, idash;
    static real aleft;
    extern doublereal slog10_(real *);
    static integer inteq;
    extern /* Subroutine */ int vgsbl_(real *, real *, real *, integer *, 
	    real *, integer *);
    static integer istat, jstat;
    static real x1, x2, y2, y1;
    extern /* Subroutine */ int vgsmb2_(real *, real *, real *, integer *, 
	    real *, integer *, real *, real *, real *, real *, integer *, 
	    real *, real *, real *, real *);
    extern logical in_(real *, real *, real *, real *, real *, real *);
    static real xs, ys;
    extern /* Subroutine */ int vgaclp_(real *, real *, real *, real *, real *
	    , real *, real *, real *, real *, real *, real *, real *, integer 
	    *), vgacov_(real *, real *, real *, real *, real *, real *, real *
	    , real *, real *, real *, real *, real *, integer *);
    static real dstart;
    static integer minlox, maxlox, minloy, maxloy;
    extern /* Subroutine */ int vgapts_(real *, real *, real *, real *, 
	    integer *, real *, integer *, integer *, integer *);
    static real x1d, y1d, x2d, y2d, x1e, y1e, x2e, y2e, x1f, y1f, x2f, y2f, 
	    amb, bmb, cmb, dmb, aml, bml, cml, dml, amr, bmr, amt, bmt, cmr, 
	    dmr, cmt, dmt;
    static integer isx, isy;

/*  ORIGINAL NAME ADRAW.  DRAWS THE DATA POINTS AND CONNECTING LINES. */
/*  EXTRACT GRAPH'S DATA FROM ARRAYS. */
    /* Parameter adjustments */
    --y;
    --x;

    /* Function Body */
    xmin = vglim_1.bxmin[vgcntr_1.ig - 1];
    xmax = vglim_1.bxmax[vgcntr_1.ig - 1];
    ymin = vglim_1.bymin[vgcntr_1.ig + *jside * 7 - 8];
    ymax = vglim_1.bymax[vgcntr_1.ig + *jside * 7 - 8];
    isx = vglim_1.logflx[vgcntr_1.ig - 1];
    isy = vglim_1.logfly[vgcntr_1.ig + *jside * 7 - 8];
    minlox = vglim_1.logmnx[vgcntr_1.ig - 1];
    maxlox = vglim_1.logmxx[vgcntr_1.ig - 1];
    minloy = vglim_1.logmny[vgcntr_1.ig + *jside * 7 - 8];
    maxloy = vglim_1.logmxy[vgcntr_1.ig + *jside * 7 - 8];
    aleft = vglim_1.bleft[vgcntr_1.ig - 1];
    arit = vglim_1.brit[vgcntr_1.ig - 1];
    abot = vglim_1.bbot[vgcntr_1.ig - 1];
    atop = vglim_1.btop[vgcntr_1.ig - 1];
    amar = *symht * .5f;
    aml = aleft + amar;
    bml = aleft - amar;
    amr = arit - amar;
    bmr = arit + amar;
    amb = abot + amar;
    bmb = abot - amar;
    amt = atop - amar;
    bmt = atop + amar;
    if (*icov == 1) {
	cml = *covlef - amar;
	dml = *covlef + amar;
	cmr = *covrit + amar;
	dmr = *covrit - amar;
	cmb = *covbot - amar;
	dmb = *covbot + amar;
	cmt = *covtop + amar;
	dmt = *covtop - amar;
    }
    vgnp_(jdcol);
/*     X(1),Y(1) IN USER UNITS, X2,Y2 IN SCREEN UNITS    3/23/89 */
    if (isx == 0) {
	a = (arit - aleft) / (xmax - xmin);
	x2 = aleft + (x[1] - xmin) * a;
    } else {
	a = (arit - aleft) / (maxlox - minlox);
	x2 = aleft + ((real)slog10_(&x[1]) - minlox) * a;
    }
    if (isy == 0) {
	b = (atop - abot) / (ymax - ymin);
	y2 = abot + (y[1] - ymin) * b;
    } else {
	b = (atop - abot) / (maxloy - minloy);
	y2 = abot + ((real)slog10_(&y[1]) - minloy) * b;
    }
    if (*jsym > 0) {
	inteq = *jsym - 1;
	i__1 = *n;
	i__2 = *incsym;
	for (i__ = 1; i__2 < 0 ? i__ >= i__1 : i__ <= i__1; i__ += i__2) {
	    if (isx == 0) {
		xs = aleft + (x[i__] - xmin) * a;
	    } else {
		xs = aleft + ((real)slog10_(&x[i__]) - minlox) * a;
	    }
	    if (isy == 0) {
		ys = abot + (y[i__] - ymin) * b;
	    } else {
		ys = abot + ((real)slog10_(&y[i__]) - minloy) * b;
	    }
	    if (in_(&xs, &ys, &bml, &bmr, &bmb, &bmt) && (*icov == 0 || ! in_(
		    &xs, &ys, &dml, &dmr, &dmb, &dmt))) {
		if (in_(&xs, &ys, &aml, &amr, &amb, &amt) && (*icov == 0 || ! 
			in_(&xs, &ys, &cml, &cmr, &cmb, &cmt))) {
		    vgsbl_(&xs, &ys, symht, &inteq, &c_b3, &c_n1);
		} else {
		    vgsmb2_(&xs, &ys, symht, &inteq, &c_b3, &c_n1, &aleft, &
			    arit, &abot, &atop, icov, covlef, covrit, covbot, 
			    covtop);
		}
	    }
/* L400: */
	}
    }
    if (*jdsty != 0) {
	dstart = 0.f;
	ipen = 2;
	idash = 1;
	i__2 = *n;
	for (i__ = 2; i__ <= i__2; ++i__) {
	    x1 = x2;
	    y1 = y2;
	    if (isx == 0) {
		x2 = aleft + (x[i__] - xmin) * a;
	    } else {
		x2 = aleft + ((real)slog10_(&x[i__]) - minlox) * a;
	    }
	    if (isy == 0) {
		y2 = abot + (y[i__] - ymin) * b;
	    } else {
		y2 = abot + ((real)slog10_(&y[i__]) - minloy) * b;
	    }
/*  THE .01 IS A PATCH TO GET BY A ROUNDING ERROR WHEN DRAWING */
/*  THE TOP AND RIGHT EDGES OF A GRAPH  (22 JUN 89 DRA) */
	    r__1 = arit + .01f;
	    r__2 = atop + .01f;
	    vgaclp_(&x1, &y1, &x2, &y2, &x1d, &y1d, &x2d, &y2d, &aleft, &r__1,
		     &abot, &r__2, &istat);
	    if (istat == 0) {
		goto L500;
	    }
	    if (*icov == 0) {
		vgapts_(&x1d, &y1d, &x2d, &y2d, jdsty, &dstart, &idash, &ipen,
			 &i__);
		goto L500;
	    }
	    vgacov_(&x1d, &y1d, &x2d, &y2d, &x1e, &y1e, &x2e, &y2e, covlef, 
		    covrit, covbot, covtop, &jstat);
	    if (jstat == 0) {
		goto L500;
	    }
	    if (jstat == 1) {
		x1f = x1d;
		y1f = y1d;
		x2f = x2d;
		y2f = y2d;
	    } else if (jstat == 2) {
		x1f = x2d;
		y1f = y2d;
		x2f = x2e;
		y2f = y2e;
	    } else {
		x1f = x1d;
		y1f = y1d;
		x2f = x1e;
		y2f = y1e;
	    }
	    vgapts_(&x1f, &y1f, &x2f, &y2f, jdsty, &dstart, &idash, &ipen, &
		    i__);
	    if (jstat == 4) {
		vgapts_(&x2d, &y2d, &x2e, &y2e, jdsty, &dstart, &idash, &ipen,
			 &i__);
	    }
L500:
	    ;
	}
    }
    return 0;
} /* vgadr_ */

/* Subroutine */ int vgacov_(real *x1, real *y1, real *x2, real *y2, real *
	x1d, real *y1d, real *x2d, real *y2d, real *covlef, real *covrit, 
	real *covbot, real *covtop, integer *jstat)
{
    extern logical in_(real *, real *, real *, real *, real *, real *);
    static real xx, yy;
    static logical in1, in2;

/*          ORIGINAL NAME ACOVER */
/*  COVERING ALGORITHM (FOR EXCLUDING LINES FROM LEGEND BOX). */
    in1 = in_(x1, y1, covlef, covrit, covbot, covtop);
    in2 = in_(x2, y2, covlef, covrit, covbot, covtop);
    if (in1 && in2) {
	*jstat = 0;
	return 0;
    }
    if (*x1 < *covlef && *x2 < *covlef || *x1 > *covrit && *x2 > *covrit || *
	    y1 < *covbot && *y2 < *covbot || *y1 > *covtop && *y2 > *covtop) {
	*jstat = 1;
	return 0;
    }
    *x1d = *x1;
    *y1d = *y1;
    *x2d = *x2;
    *y2d = *y2;
    if (*x1 < *covlef) {
	xx = *covlef;
    } else if (*x1 > *covrit) {
	xx = *covrit;
    } else {
	goto L100;
    }
    *y1d = *y1 + (xx - *x1) / (*x2 - *x1) * (*y2 - *y1);
    *x1d = xx;
L100:
    if (*y1d < *covbot) {
	yy = *covbot;
    } else if (*y1d > *covtop) {
	yy = *covtop;
    } else {
	goto L200;
    }
    if (*y2d == *y1d) {
	*jstat = 1;
	return 0;
    }
    *x1d += (yy - *y1d) / (*y2d - *y1d) * (*x2d - *x1d);
    *y1d = yy;
L200:
    if (*x2 < *covlef) {
	xx = *covlef;
    } else if (*x2 > *covrit) {
	xx = *covrit;
    } else {
	goto L300;
    }
    if (*x1d == *x2d) {
	*jstat = 1;
	return 0;
    }
    *y2d += (xx - *x2d) / (*x1d - *x2d) * (*y1d - *y2d);
    *x2d = xx;
L300:
    if (*y2d < *covbot) {
	yy = *covbot;
    } else if (*y2d > *covtop) {
	yy = *covtop;
    } else {
	goto L400;
    }
    if (*y1d == *y2d) {
	*jstat = 1;
	return 0;
    }
    *x2d += (yy - *y2d) / (*y1d - *y2d) * (*x1d - *x2d);
    *y2d = yy;
L400:
    if (in1) {
	*jstat = 2;
	return 0;
    }
    if (in2) {
	*jstat = 3;
	return 0;
    }
    if (! in_(x1d, y1d, covlef, covrit, covbot, covtop)) {
	*jstat = 1;
    } else {
	*jstat = 4;
    }
    return 0;
} /* vgacov_ */

logical in_(real *x, real *y, real *aleft, real *arit, real *abot, real *atop)
{
    /* System generated locals */
    logical ret_val;

/*  TESTS WHETHER A POINT IS INSIDE A PARTICULAR BOX. */
    if (*x >= *aleft && *x <= *arit && *y >= *abot && *y <= *atop) {
	ret_val = TRUE_;
    } else {
	ret_val = FALSE_;
    }
    return ret_val;
} /* in_ */

/* Subroutine */ int vgaclp_(real *x1, real *y1, real *x2, real *y2, real *
	x1d, real *y1d, real *x2d, real *y2d, real *aleft, real *arit, real *
	abot, real *atop, integer *istat)
{
    static real xx, yy;

/*          ORIGINAL NAME ACLIP */
/*  CLIPPING ALGORITHM. */
    if (*x1 < *aleft && *x2 < *aleft || *x1 > *arit && *x2 > *arit || *y1 < *
	    abot && *y2 < *abot || *y1 > *atop && *y2 > *atop) {
	*istat = 0;
	return 0;
    }
    *x1d = *x1;
    *y1d = *y1;
    *x2d = *x2;
    *y2d = *y2;
    if (*x1d < *aleft) {
	xx = *aleft;
    } else if (*x1d > *arit) {
	xx = *arit;
    } else {
	goto L100;
    }
    *y1d += (xx - *x1d) / (*x2d - *x1d) * (*y2d - *y1d);
    *x1d = xx;
L100:
    if (*y1d < *abot) {
	yy = *abot;
    } else if (*y1d > *atop) {
	yy = *atop;
    } else {
	goto L200;
    }
    if (*y2d == *y1d) {
	*istat = 0;
	return 0;
    }
    *x1d += (yy - *y1d) / (*y2d - *y1d) * (*x2d - *x1d);
    *y1d = yy;
L200:
    if (*x2d < *aleft) {
	xx = *aleft;
    } else if (*x2d > *arit) {
	xx = *arit;
    } else {
	goto L300;
    }
    if (*x1d == *x2d) {
	*istat = 0;
	return 0;
    }
    *y2d += (xx - *x2d) / (*x1d - *x2d) * (*y1d - *y2d);
    *x2d = xx;
L300:
    if (*y2d < *abot) {
	yy = *abot;
    } else if (*y2d > *atop) {
	yy = *atop;
    } else {
	goto L400;
    }
    if (*y1d == *y2d) {
	*istat = 0;
	return 0;
    }
    *x2d += (yy - *y2d) / (*y1d - *y2d) * (*x1d - *x2d);
    *y2d = yy;
L400:
    if (*x1d < *aleft || *x1d > *arit || *y1d < *abot || *y1d > *atop) {
	*istat = 0;
    } else {
	*istat = 1;
    }
    return 0;
} /* vgaclp_ */

/* Subroutine */ int vgapts_(real *x1, real *y1, real *x2, real *y2, integer *
	idsty, real *dstart, integer *idash, integer *ipen, integer *i__)
{
    /* Initialized data */

    static real da[52]	/* was [13][4] */ = { 0.f,0.0,0.0,.2f,.4f,.2f,.1f,.4f,
	    .3f,.3f,.6f,.6f,.1f,.12f,0.0,0.0,.2f,.4f,.2f,.1f,.1f,.3f,.2f,.2f,
	    .1f,.5f,20.f,0.0,0.0,.2f,.4f,.4f,.1f,.1f,.3f,.1f,.4f,.1f,.1f,0.f,
	    0.0,0.0,.2f,.4f,.2f,.1f,.1f,.3f,.2f,.2f,.1f,.5f };

    /* Builtin functions */
    double sqrt(doublereal);

    /* Local variables */
    static real dseg;
    extern /* Subroutine */ int vgpl_(real *, real *, integer *);
    static real x2old, y2old, a, bdinv, bd, xp, yp, deltax, deltay;

/*         ORIGINAL NAME APTS */
/*  DRAWS A SOLID OR DASHED LINE. */
/* MODIFIED LAST LINE STYLE BECAUSE IT WAS DIFFICULT TO */
/* RESOLVE  1/90 (WEA) */
/*     DATA (DA(11,J),J=1,4)/.2,.05,.05,.05/ */

    if (*x1 != x2old || *y1 != y2old || *i__ == 2) {
	vgpl_(x1, y1, &c__3);
    }
    x2old = *x2;
    y2old = *y2;
    if (*idsty == 1) {
	vgpl_(x2, y2, &c__2);
	return 0;
    }
    deltax = *x2 - *x1;
    deltay = *y2 - *y1;
    bd = (real)sqrt(deltax * deltax + deltay * deltay);
    if (bd != 0.f) {
	bdinv = 1.f / bd;
    } else {
	bdinv = 0.f;
    }
    dseg = -(*dstart);
L20:
    dseg += da[*idsty + *idash * 13 - 12];
    if (dseg > bd) {
	goto L100;
    }
    a = dseg * bdinv;
    xp = *x1 + a * deltax;
    yp = *y1 + a * deltay;
    vgpl_(&xp, &yp, ipen);
    *ipen = 5 - *ipen;
    *idash = *idash % 4 + 1;
    goto L20;
L100:
    *dstart = bd - dseg + da[*idsty + *idash * 13 - 12];
    vgpl_(x2, y2, ipen);
    return 0;
} /* vgapts_ */

/* Subroutine */ int vgsmb2_(real *xpage, real *ypage, real *height, integer *
	inteq, real *angle, integer *icode, real *aleft, real *arit, real *
	abot, real *atop, integer *icov, real *covlef, real *covrit, real *
	covbot, real *covtop)
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer i_nint(real *);
    double r_mod(real *, real *), cos(doublereal), sin(doublereal);

    /* Local variables */
    static real cosa, sina, hcos;
    static integer icnt;
    static real hsin;
    extern /* Subroutine */ int vgpl_(real *, real *, integer *);
    static real hcos4, hsin4, alpha;
    extern /* Subroutine */ int vgdsh_(real *, integer *);
    static real array[17];
    static integer istat, kstat, jstat;
    static real dummy[1];
    extern /* Subroutine */ int vgspl_(real *, real *, real *, real *, 
	    integer *);
    static real x0, y0, x2, y2, x1, y1;
    static integer ip;
    static real cx, cy;
    static integer ix, iy, nx, ny;
    extern /* Subroutine */ int vgaclp_(real *, real *, real *, real *, real *
	    , real *, real *, real *, real *, real *, real *, real *, integer 
	    *), vgacov_(real *, real *, real *, real *, real *, real *, real *
	    , real *, real *, real *, real *, real *, integer *);
    static real x1d, y1d, x2d, y2d, x1e, y1e, x2e, y2e, x1f, y1f, x2f, y2f;

/*          ORIGINAL NAME SYMB2 */
/*  DRAWS A CLIPPED AND COVERED SYMBOL (MODIFICATION OF A PROGRAM BY */
/*  U. KATTNER (NBS).) */



    if (*xpage != 999.f && *ypage != 999.f) {
	x0 = *xpage;
	y0 = *ypage;
    }

/* .....ICODE = -1 : "PEN UP"; ICODE = -2 : "PEN DOWN" */

    if (*icode == -2) {
	i__1 = *icode + 4;
	vgpl_(&x0, &y0, &i__1);
    }

    if (vgfpt_1.ifptr[*inteq] == 0) {
	return 0;
    }

    vgdsh_(array, &c_n16);
    icnt = i_nint(&array[16]);
    if (icnt != 0) {
	vgdsh_(dummy, &c__0);
    }

    alpha = (real)r_mod(angle, &c_b27) * 6.283185f / 360.f;
    if (alpha < 0.f) {
	alpha += 6.283185f;
    }
    cosa = (real)cos(alpha);
    sina = (real)sin(alpha);
    hcos = *height * cosa;
    hsin = *height * sina;
    hcos4 = hcos * .043f;
    hsin4 = hsin * .043f;

    if (*inteq == 127 || *inteq == 174 || *inteq == 223) {
	x0 -= hcos;
	y0 -= hsin;
    }

    if (*inteq < 32) {
	nx = 64;
	ny = 64;
    } else {
	nx = 53;
	ny = 55;
    }

    ip = vgfpt_1.ifptr[*inteq];
    kstat = 0;
L1008:
    ip += 2;
    ix = *(unsigned char *)&vgfnt_1.font[ip - 1];
    iy = *(unsigned char *)&vgfnt_1.font[ip];
    cx = (real) (ix - nx);
    cy = (real) (iy - ny);
    x2 = cx * hcos4 - cy * hsin4 + x0;
    y2 = cy * hcos4 + cx * hsin4 + y0;
L1010:
    ip += 2;
    x1 = x2;
    y1 = y2;
    ix = *(unsigned char *)&vgfnt_1.font[ip - 1];
    iy = *(unsigned char *)&vgfnt_1.font[ip];
    if (ix == 126) {
	if (iy == 126) {
	    goto L1100;
	}
	goto L1008;
    }
    cx = (real) (ix - nx);
    cy = (real) (iy - ny);
    x2 = cx * hcos4 - cy * hsin4 + x0;
    y2 = cy * hcos4 + cx * hsin4 + y0;
    vgaclp_(&x1, &y1, &x2, &y2, &x1d, &y1d, &x2d, &y2d, aleft, arit, abot, 
	    atop, &istat);
    if (istat == 0) {
	goto L1010;
    }
    if (*icov == 0) {
	vgspl_(&x1d, &y1d, &x2d, &y2d, &kstat);
	goto L1010;
    }
    vgacov_(&x1d, &y1d, &x2d, &y2d, &x1e, &y1e, &x2e, &y2e, covlef, covrit, 
	    covbot, covtop, &jstat);
    if (jstat == 0) {
	goto L1010;
    }
    if (jstat == 1) {
	x1f = x1d;
	y1f = y1d;
	x2f = x2d;
	y2f = y2d;
    } else if ((real) jstat == 2.f) {
	x1f = x2d;
	y1f = y2d;
	x2f = x2e;
	y2f = y2e;
    } else {
	x1f = x1d;
	y1f = y1d;
	x2f = x1e;
	y2f = y1e;
    }
    vgspl_(&x1f, &y1f, &x2f, &y2f, &kstat);
    if (jstat == 4) {
	vgspl_(&x2d, &y2d, &x2e, &y2e, &kstat);
    }
    goto L1010;
L1100:
    if (*inteq < 32 || *inteq == 127) {
	goto L2000;
    }
    x0 += hcos;
    y0 += hsin;
L2000:
    vgpl_(&x0, &y0, &c__3);

    if (icnt != 0) {
	vgdsh_(array, &icnt);
    }
    return 0;
} /* vgsmb2_ */

doublereal slog10_(real *x)
{
    /* System generated locals */
    real ret_val;

    /* Builtin functions */
    double r_lg10(real *);

/*  "SAFE" LOG FUNCTION, IE. WON'T CRASH FOR X<=0 */
    if (*x > 0.f) {
	ret_val = (real)r_lg10(x);
    } else {
	ret_val = -100.f;
    }
    return ret_val;
} /* slog10_ */

