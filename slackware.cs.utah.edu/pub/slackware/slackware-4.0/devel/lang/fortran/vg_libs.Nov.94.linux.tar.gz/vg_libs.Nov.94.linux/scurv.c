/* scurv.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Table of constant values */

static integer c__2 = 2;
static doublereal c_b9 = 10.;

/* Subroutine */ int scurv_(integer *n, real *x, real *y)
{
    /* Initialized data */

    static real w = .07f;

    /* System generated locals */
    integer i__1, i__2, i__3;
    doublereal d__1;

    /* Builtin functions */
    integer pow_ii(integer *, integer *);
    double pow_dd(doublereal *, doublereal *);

    /* Local variables */
    static integer incr;
    extern /* Subroutine */ int curv_(integer *, real *, real *);
    static real a, b;
    static integer i__, j, k, m;
    static real u[1701], v[1701];
    extern doublereal slog10_(real *);
    static integer ixlog, iylog;
    static real d0, d1, d2;
    static integer n1, n2;
    static real dd;
    static integer jb;
    static real dn;
    static integer js, ns;
    extern /* Subroutine */ int setinc_(integer *), vgaxlg_(integer *, 
	    integer *);
    static real dm1, dnm1, dnm2, dnp1;

/*  DRAWS A SMOOTHLY INTERPOLATED GRAPH LINE.  (NOT A CUBIC SPLINE.) */
/*  REVISED FOR VG VERSION 1.01 IN SEPT. 1988 (DRA) */
/*        IXLOG=0 OR 1 AS X DATA IS TO BE PLOTTED AS LINEAR/LOG */
/*        IYLOG=0 OR 1 AS Y DATA IS TO BE PLOTTED AS LINEAR/LOG */
    /* Parameter adjustments */
    --y;
    --x;

    /* Function Body */
    vgaxlg_(&ixlog, &iylog);
    a = w + .5f;
    b = -w;
    if (*n + 3 << 1 > 1700 || *n < 3) {
	curv_(n, &x[1], &y[1]);
	return 0;
    }
    k = 2;
    ns = *n + 3 << 2;
L10:
    if (ns > 1700) {
	goto L20;
    }
    ++k;
    ns <<= 1;
    goto L10;
L20:
    --k;
    js = pow_ii(&c__2, &k);
    setinc_(&js);
    n1 = js << 1;
    n2 = (*n + 1) * js;
    j = 0;
    i__1 = n2;
    i__2 = js;
    for (i__ = n1; i__2 < 0 ? i__ >= i__1 : i__ <= i__1; i__ += i__2) {
	++j;
	if (ixlog > 0) {
	    u[i__] = (real)slog10_(&x[j]);
	} else {
	    u[i__] = x[j];
	}
	if (iylog > 0) {
	    v[i__] = (real)slog10_(&y[j]);
	} else {
	    v[i__] = y[j];
	}
/* L40: */
    }
    if (ixlog > 0) {
	d1 = (real)slog10_(&x[2]) - (real)slog10_(&x[1]);
	d2 = (real)slog10_(&x[3]) - (real)slog10_(&x[2]);
    } else {
	d1 = x[2] - x[1];
	d2 = x[3] - x[2];
    }
    dd = d2 - d1;
    d0 = d1 - dd;
    if (ixlog > 0) {
	u[n1 - js] = (real)slog10_(&x[1]) - d0;
    } else {
	u[n1 - js] = x[1] - d0;
    }
    dm1 = d0 - dd;
    u[0] = u[n1 - js] - dm1;
    if (iylog > 0) {
	d1 = (real)slog10_(&y[2]) - (real)slog10_(&y[1]);
	d2 = (real)slog10_(&y[3]) - (real)slog10_(&y[2]);
    } else {
	d1 = y[2] - y[1];
	d2 = y[3] - y[2];
    }
    dd = d2 - d1;
    d0 = d1 - dd;
    if (iylog > 0) {
	v[n1 - js] = (real)slog10_(&y[1]) - d0;
    } else {
	v[n1 - js] = y[1] - d0;
    }
    dm1 = d0 - dd;
    v[0] = v[n1 - js] - dm1;
    if (ixlog > 0) {
	dnm2 = (real)slog10_(&x[*n - 1]) - (real)slog10_(&x[*n - 2]);
	dnm1 = (real)slog10_(&x[*n]) - (real)slog10_(&x[*n - 1]);
    } else {
	dnm2 = x[*n - 1] - x[*n - 2];
	dnm1 = x[*n] - x[*n - 1];
    }
    dd = dnm1 - dnm2;
    dn = dnm1 + dd;
    if (ixlog > 0) {
	u[n2 + js] = (real)slog10_(&x[*n]) + dn;
    } else {
	u[n2 + js] = x[*n] + dn;
    }
    dnp1 = dn + dd;
    u[n2 + (js << 1)] = u[n2 + js] + dnp1;
    if (iylog > 0) {
	dnm2 = (real)slog10_(&y[*n - 1]) - (real)slog10_(&y[*n - 2]);
	dnm1 = (real)slog10_(&y[*n]) - (real)slog10_(&y[*n - 1]);
    } else {
	dnm2 = y[*n - 1] - y[*n - 2];
	dnm1 = y[*n] - y[*n - 1];
    }
    dd = dnm1 - dnm2;
    dn = dnm1 + dd;
    if (iylog > 0) {
	v[n2 + js] = (real)slog10_(&y[*n]) + dn;
    } else {
	v[n2 + js] = y[*n] + dn;
    }
    dnp1 = dn + dd;
    v[n2 + (js << 1)] = v[n2 + js] + dnp1;
    i__2 = k;
    for (i__ = 1; i__ <= i__2; ++i__) {
	incr = js;
	js /= 2;
	jb = incr + js;
	i__1 = n2 + js;
	i__3 = incr;
	for (m = n1 - js; i__3 < 0 ? m >= i__1 : m <= i__1; m += i__3) {
	    u[m] = a * (u[m - js] + u[m + js]) + b * (u[m - jb] + u[m + jb]);
	    v[m] = a * (v[m - js] + v[m + js]) + b * (v[m - jb] + v[m + jb]);
/* L100: */
	}
/* L200: */
    }
    i__2 = n2;
    for (i__ = n1; i__ <= i__2; ++i__) {
	if (ixlog > 0) {
	    d__1 = (doublereal) u[i__];
	    u[i__] = (real)pow_dd(&c_b9, &d__1);
	}
	if (iylog > 0) {
	    d__1 = (doublereal) v[i__];
	    v[i__] = (real)pow_dd(&c_b9, &d__1);
	}
/* L300: */
    }
    i__2 = n2 - n1 + 1;
    curv_(&i__2, &u[n1], &v[n1]);
    return 0;
} /* scurv_ */

