/* hist.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    integer idmark;
} vgcrv1_;

#define vgcrv1_1 vgcrv1_

/* Table of constant values */

static integer c__4 = 4;

/* Subroutine */ int hist_(integer *n, real *x, real *y, real *barwid)
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    static real xbar[4], ybar[4];
    extern /* Subroutine */ int curv_(integer *, real *, real *);
    static integer i__;
    static real hafwid;

/*  DRAWS A HISTOGRAM. */
    /* Parameter adjustments */
    --y;
    --x;

    /* Function Body */
    hafwid = *barwid / 2;
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	xbar[0] = x[i__] - hafwid;
	ybar[0] = 0.f;
	xbar[1] = x[i__] - hafwid;
	ybar[1] = y[i__];
	xbar[2] = x[i__] + hafwid;
	ybar[2] = y[i__];
	xbar[3] = x[i__] + hafwid;
	ybar[3] = 0.f;
	curv_(&c__4, xbar, ybar);
	vgcrv1_1.idmark = 1;
/* L20: */
    }
    vgcrv1_1.idmark = 0;
    return 0;
} /* hist_ */

