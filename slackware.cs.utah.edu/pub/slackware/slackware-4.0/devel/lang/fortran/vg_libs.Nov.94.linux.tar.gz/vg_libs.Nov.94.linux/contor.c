/* contor.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    real bleft1[7], brit1[7], bbot1[7], btop1[7], bxmin[7], bxmax[7], bymin[
	    14]	/* was [7][2] */, bymax[14]	/* was [7][2] */;
    integer ninlx[7], naxlx[7], ninly[14]	/* was [7][2] */, naxly[14]	
	    /* was [7][2] */, msx[7], msy[14]	/* was [7][2] */;
} vglim_;

#define vglim_1 vglim_

struct {
    integer ig;
} vgcntr_;

#define vgcntr_1 vgcntr_

struct {
    integer lsyms[84]	/* was [14][6] */, lcolrs[84]	/* was [14][6] */, 
	    lstys[84]	/* was [14][6] */, nlines[6];
    real hh[6], vv[6], xleg[7], yleg[7];
    integer isleg[7], legset[7], legvis[6];
} vgleg1_;

#define vgleg1_1 vgleg1_

struct {
    logical lbox;
    integer leglin;
} vgleg3_;

#define vgleg3_1 vgleg3_

struct {
    logical pass1;
    integer jexit, mdevic, istat;
    logical pass2;
} vgloop_;

#define vgloop_1 vgloop_

struct {
    real smin[21]	/* was [7][3] */, smax[21]	/* was [7][3] */;
    integer limflg[21]	/* was [7][3] */;
    real tmin[21]	/* was [7][3] */, tmax[21]	/* was [7][3] */;
} vgsbnd_;

#define vgsbnd_1 vgsbnd_

struct {
    logical yestic[21]	/* was [7][3] */;
    integer nh[7], nv1[7], nv2[7];
} vgtic1_;

#define vgtic1_1 vgtic1_

struct {
    real height;
} vghgt_;

#define vghgt_1 vghgt_

struct {
    real dummy[28]	/* was [7][4] */;
    integer idummy[21]	/* was [7][3] */, kludge[7], axcol;
} vglttr_;

#define vglttr_1 vglttr_

/* Table of constant values */

static integer c__2 = 2;
static integer c__1 = 1;
static integer c__3 = 3;
static logical c_true = TRUE_;
static logical c_false = FALSE_;
static real c_b18 = .1f;
static real c_b19 = 0.f;

/* Subroutine */ int contor_(integer *n, integer *m, real *x, real *y, real *
	z__)
{
    /* System generated locals */
    integer z_dim1, z_offset, i__1, i__2, i__3, i__4, i__5;

    /* Builtin functions */
    integer pow_ii(integer *, integer *);

    /* Local variables */
    static integer zdec, incr, icov;
    static logical hits[4];
    static integer lenz;
    extern /* Subroutine */ int vgpl_(real *, real *, integer *);
    static real zmin, zmax;
    extern /* Subroutine */ int vgsr_(real *, integer *, real *, real *, 
	    integer *, integer *, real *, real *, integer *, real *, real *, 
	    integer *);
    static integer lsym, npts, lsty;
    static real xout[5], yout[5];
    static integer i__, j, k, l, jside;
    extern /* Subroutine */ int vgbnd_(integer *, integer *, real *, real *, 
	    real *, integer *, integer *, integer *), vgadr_(real *, real *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    real *, real *, real *, real *, integer *, real *);
    static integer index, lcolr;
    extern /* Subroutine */ int vgtic_(integer *, integer *, real *, real *, 
	    integer *, integer *, integer *, integer *, logical *), vghit_(
	    logical *, real *, real *, real *, real *, real *, real *, real *,
	     real *, real *);
    static integer numbz, j1, k1;
    static real covlef;
    extern /* Subroutine */ int vgconl_(real *, real *, integer *, integer *, 
	    integer *, integer *);
    static real covbot;
    extern /* Subroutine */ int vgcmnt_(char *, ftnlen);
    static real zlevel;
    static integer numlin, nzsave[7];
    static real covrit;
    static integer lastpt;
    static real covtop;
    static integer nstyle;
    static real zconts[100], xpoints[4], ypoints[4];

/*  DRAWS A CONTOUR PLOT. */
    /* Parameter adjustments */
    z_dim1 = *n;
    z_offset = z_dim1 + 1;
    z__ -= z_offset;
    --x;
    --y;

    /* Function Body */
    if (vgcntr_1.ig > 6) {
	return 0;
    }
    lsym = 0;
    lcolr = 1;
    lsty = 2;
    jside = 1;
    numbz = vglttr_1.kludge[vgcntr_1.ig - 1] / pow_ii(&c__2, &c__2) % 2;
    if (vgloop_1.pass1) {
	vglttr_1.kludge[vgcntr_1.ig - 1] += 512;
	vgbnd_(&vgsbnd_1.limflg[vgcntr_1.ig - 1], &c__1, &x[1], &
		vglim_1.bxmin[vgcntr_1.ig - 1], &vglim_1.bxmax[vgcntr_1.ig - 
		1], &vglim_1.ninlx[vgcntr_1.ig - 1], &vglim_1.naxlx[
		vgcntr_1.ig - 1], n);
	vgbnd_(&vgsbnd_1.limflg[vgcntr_1.ig + 6], &c__1, &y[1], &
		vglim_1.bymin[vgcntr_1.ig - 1], &vglim_1.bymax[vgcntr_1.ig - 
		1], &vglim_1.ninly[vgcntr_1.ig - 1], &vglim_1.naxly[
		vgcntr_1.ig - 1], m);
	i__1 = *n * *m;
	vgbnd_(&vgsbnd_1.limflg[vgcntr_1.ig + 13], &c__1, &z__[z_offset], &
		vglim_1.bymin[vgcntr_1.ig + 6], &vglim_1.bymax[vgcntr_1.ig + 
		6], &vglim_1.ninly[vgcntr_1.ig + 6], &vglim_1.naxly[
		vgcntr_1.ig + 6], &i__1);
	vgtic_(&vglim_1.msy[vgcntr_1.ig + 6], &vgtic1_1.nv2[vgcntr_1.ig - 1], 
		&vglim_1.bymin[vgcntr_1.ig + 6], &vglim_1.bymax[vgcntr_1.ig + 
		6], &vglim_1.ninly[vgcntr_1.ig + 6], &vglim_1.naxly[
		vgcntr_1.ig + 6], &c__3, &zdec, &c_true);
	if (numbz == 0) {
/*  USER WANTS CONTOR'S LEGEND DATA */
	    vgconl_(&vglim_1.bymin[vgcntr_1.ig + 6], &vglim_1.bymax[
		    vgcntr_1.ig + 6], &vglim_1.ninly[vgcntr_1.ig + 6], &
		    vglim_1.naxly[vgcntr_1.ig + 6], &vgtic1_1.nv2[vgcntr_1.ig 
		    - 1], &vglim_1.msy[vgcntr_1.ig + 6]);
	}
	numlin = vgleg1_1.nlines[vgcntr_1.ig - 1];
	vgleg1_1.lsyms[numlin + 1 - vgleg3_1.leglin + vgcntr_1.ig * 14 - 15] =
		 0;
	vgleg1_1.lcolrs[numlin + 1 - vgleg3_1.leglin + vgcntr_1.ig * 14 - 15] 
		= lcolr;
	vgleg1_1.lstys[numlin + 1 - vgleg3_1.leglin + vgcntr_1.ig * 14 - 15] =
		 0;
	i__1 = vgleg3_1.leglin - 1;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    vgleg1_1.lsyms[numlin + 1 - i__ + vgcntr_1.ig * 14 - 15] = 0;
	    vgleg1_1.lcolrs[numlin + 1 - i__ + vgcntr_1.ig * 14 - 15] = lcolr;
	    vgleg1_1.lstys[numlin + 1 - i__ + vgcntr_1.ig * 14 - 15] = 0;
/* L5: */
	}
	vgleg3_1.leglin = 0;
	nzsave[vgcntr_1.ig - 1] = numbz;
    } else {
/*  ELSE NOT FIRST PASS */
	vgtic_(&vglim_1.msy[vgcntr_1.ig + 6], &vgtic1_1.nv2[vgcntr_1.ig - 1], 
		&vglim_1.bymin[vgcntr_1.ig + 6], &vglim_1.bymax[vgcntr_1.ig + 
		6], &vglim_1.ninly[vgcntr_1.ig + 6], &vglim_1.naxly[
		vgcntr_1.ig + 6], &c__3, &zdec, &c_false);
/*  KLUDGE TO ALLOW CHANGING LEGEND TO REFLECT NEW BOUNDARIES */
	if (vgleg1_1.legvis[vgcntr_1.ig - 1] == 1) {
	    if (nzsave[vgcntr_1.ig - 1] == 0) {
/*  HAD CONTOR'S LEGEND LINES LAST PASS, ERASE THEM IN ANTICPA
TION OF */
/*  A CHANGE (EITHER IN LINE CONTENT OR NUMBZ) */
		vgleg1_1.nlines[vgcntr_1.ig - 1] += -3;
		vgleg1_1.vv[vgcntr_1.ig - 1] -= vghgt_1.height * 4.5f;
		if (vgleg1_1.nlines[vgcntr_1.ig - 1] == 0) {
		    vgleg1_1.isleg[vgcntr_1.ig - 1] = 0;
		}
	    }
	    if (numbz == 0) {
/*  USER WANTS CONTOR'S LEGEND LINES THIS PASS */
		vgloop_1.pass1 = TRUE_;
		vgconl_(&vglim_1.bymin[vgcntr_1.ig + 6], &vglim_1.bymax[
			vgcntr_1.ig + 6], &vglim_1.ninly[vgcntr_1.ig + 6], &
			vglim_1.naxly[vgcntr_1.ig + 6], &vgtic1_1.nv2[
			vgcntr_1.ig - 1], &vglim_1.msy[vgcntr_1.ig + 6]);
		vgloop_1.pass1 = FALSE_;
	    }
	    nzsave[vgcntr_1.ig - 1] = numbz;
	}
	vgcmnt_("Drawing...", 10L);
/*  DRAW THE CONTOURS: */
	icov = 0;
	if (vgleg1_1.isleg[vgcntr_1.ig - 1] == 1 && vgleg1_1.legvis[
		vgcntr_1.ig - 1] == 1) {
	    covlef = vgleg1_1.xleg[vgcntr_1.ig - 1] - vgleg1_1.hh[vgcntr_1.ig 
		    - 1] * .5f;
	    covrit = vgleg1_1.xleg[vgcntr_1.ig - 1] + vgleg1_1.hh[vgcntr_1.ig 
		    - 1] * .5f;
	    covbot = vgleg1_1.yleg[vgcntr_1.ig - 1] - vgleg1_1.vv[vgcntr_1.ig 
		    - 1] * .5f;
	    covtop = vgleg1_1.yleg[vgcntr_1.ig - 1] + vgleg1_1.vv[vgcntr_1.ig 
		    - 1] * .5f;
	    icov = 1;
	}
	vgsr_(zconts, &vglim_1.msy[vgcntr_1.ig + 6], &vgsbnd_1.tmin[
		vgcntr_1.ig + 13], &vgsbnd_1.tmax[vgcntr_1.ig + 13], &
		vglim_1.ninly[vgcntr_1.ig + 6], &vglim_1.naxly[vgcntr_1.ig + 
		6], &vglim_1.bymin[vgcntr_1.ig + 6], &vglim_1.bymax[
		vgcntr_1.ig + 6], &vgtic1_1.nv2[vgcntr_1.ig - 1], &zmin, &
		zmax, &lenz);
	if (vglim_1.msy[vgcntr_1.ig + 6] == 1) {
/*  PREVENT LARGE NUMBER OF LOG LEVELS, WHICH YIELDS HARD-TO-READ 
PLOT. */
	    incr = lenz / 20 + 1;
	} else {
	    incr = 1;
	}
	nstyle = (vgtic1_1.nv2[vgcntr_1.ig - 1] - 1) / (incr * 7) + 1;
	i__1 = lenz - 1;
	i__2 = incr;
	for (i__ = 1; i__2 < 0 ? i__ >= i__1 : i__ <= i__1; i__ += i__2) {
	    zlevel = zconts[i__];
	    lsty = (i__ - 1) % nstyle + 1;
	    lcolr = (i__ - 1) / nstyle + 1;
	    i__3 = *n - 1;
	    for (j = 1; j <= i__3; ++j) {
		i__4 = *m - 1;
		for (k = 1; k <= i__4; ++k) {
		    lastpt = 0;
		    j1 = j + 1;
		    k1 = k + 1;
		    vghit_(&hits[1], &xpoints[1], &ypoints[1], &x[j1], &x[j1],
			     &y[k], &y[k1], &z__[j1 + k * z_dim1], &z__[j1 + 
			    k1 * z_dim1], &zlevel);
		    if (hits[1]) {
			lastpt = 2;
		    }
		    vghit_(&hits[2], &xpoints[2], &ypoints[2], &x[j1], &x[j], 
			    &y[k1], &y[k1], &z__[j1 + k1 * z_dim1], &z__[j + 
			    k1 * z_dim1], &zlevel);
		    if (hits[2]) {
			lastpt = 3;
		    }
		    vghit_(&hits[3], &xpoints[3], &ypoints[3], &x[j], &x[j], &
			    y[k1], &y[k], &z__[j + k1 * z_dim1], &z__[j + k * 
			    z_dim1], &zlevel);
		    if (hits[3]) {
			lastpt = 4;
		    }
		    vghit_(hits, xpoints, ypoints, &x[j], &x[j1], &y[k], &y[k]
			    , &z__[j + k * z_dim1], &z__[j1 + k * z_dim1], &
			    zlevel);
		    if (hits[0] && hits[3]) {
			lastpt = 5;
		    }
		    if (lastpt > 0) {
			npts = 0;
			i__5 = lastpt;
			for (l = 1; l <= i__5; ++l) {
			    if (l == 5) {
				index = 1;
			    } else {
				index = l;
			    }
			    if (hits[index - 1]) {
				++npts;
				xout[npts - 1] = xpoints[index - 1];
				yout[npts - 1] = ypoints[index - 1];
			    }
			    if (npts == 5) {
/*  DENOTE SPECIAL CASE */
				xout[2] = xpoints[1];
				yout[2] = ypoints[1];
				xout[1] = xpoints[2];
				yout[1] = ypoints[2];
			    }
/* L100: */
			}
			vgadr_(xout, yout, &npts, &lsty, &lcolr, &lsym, &
				jside, &icov, &covlef, &covrit, &covbot, &
				covtop, &c__1, &c_b18);
			vgpl_(&c_b19, &c_b19, &c__3);
		    }
/* L200: */
		}
/* L300: */
	    }
/* L400: */
	}
	vgcmnt_(" ", 1L);
    }
    jside = 1;
    return 0;
} /* contor_ */

/* Subroutine */ int vghit_(logical *hit, real *xp, real *yp, real *x1, real *
	x2, real *y1, real *y2, real *z1, real *z2, real *zlevel)
{
    static real delx, dely, delz, delz2, fract;

/*  DETERMINES IF A CONTOUR LEVEL LIES BETWEEN (X1,Y2,Z1) AND */
/*  (X2,Y2,Z2).  IF ONE DOES, INTERPOLATES INTERSECTION (XP,YP). */
    if (*z1 < *zlevel && *z2 < *zlevel || *z1 >= *zlevel && *z2 >= *zlevel) {
	*hit = FALSE_;
    } else {
	*hit = TRUE_;
	delx = *x2 - *x1;
	dely = *y2 - *y1;
	delz = *z2 - *z1;
	delz2 = *zlevel - *z1;
	fract = delz2 / delz;
	*xp = *x1 + fract * delx;
	*yp = *y1 + fract * dely;
    }
    return 0;
} /* vghit_ */

/* Subroutine */ int vgconl_(real *zmin, real *zmax, integer *ninlz, integer *
	naxlz, integer *ntics, integer *logflg)
{
    /* System generated locals */
    address a__1[2];
    integer i__1[2];
    real r__1;
    char ch__1[30];

    /* Builtin functions */
    integer s_wsfi(icilist *), do_fio(integer *, char *, ftnlen), e_wsfi(void)
	    ;
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen),
	     s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static char temp[10];
    static real step;
    extern /* Subroutine */ int legnd_(char *, ftnlen), vgunp_(char *, ftnlen)
	    ;
    static char incstr[20], minstr[20], maxstr[20];

    /* Fortran I/O blocks */
    static icilist io___42 = { 0, minstr, 0, "(G14.4)", 20, 1 };
    static icilist io___44 = { 0, maxstr, 0, "(G14.4)", 20, 1 };
    static icilist io___46 = { 0, incstr, 0, "(G14.4)", 20, 1 };
    static icilist io___48 = { 0, temp, 0, "(I3)", 10, 1 };
    static icilist io___49 = { 0, temp, 0, "(I3)", 10, 1 };


/*  PRODUCES LEGENDS FOR CONTOR PLOTS */
    step = (*zmax - *zmin) / *ntics;
    if (*logflg == 0) {
	s_wsfi(&io___42);
	r__1 = *zmin + step;
	do_fio(&c__1, (char *)&r__1, (ftnlen)sizeof(real));
	e_wsfi();
	s_wsfi(&io___44);
	do_fio(&c__1, (char *)&(*zmax), (ftnlen)sizeof(real));
	e_wsfi();
	s_wsfi(&io___46);
	do_fio(&c__1, (char *)&step, (ftnlen)sizeof(real));
	e_wsfi();
    } else {
	s_wsfi(&io___48);
	do_fio(&c__1, (char *)&(*ninlz), (ftnlen)sizeof(integer));
	e_wsfi();
/* Writing concatenation */
	i__1[0] = 4, a__1[0] = "10**";
	i__1[1] = 10, a__1[1] = temp;
	s_cat(minstr, a__1, i__1, &c__2, 20L);
	s_wsfi(&io___49);
	do_fio(&c__1, (char *)&(*naxlz), (ftnlen)sizeof(integer));
	e_wsfi();
/* Writing concatenation */
	i__1[0] = 4, a__1[0] = "10**";
	i__1[1] = 10, a__1[1] = temp;
	s_cat(maxstr, a__1, i__1, &c__2, 20L);
	s_copy(incstr, "LOG", 20L, 3L);
    }
    vgunp_(minstr, 20L);
    vgunp_(maxstr, 20L);
    vgunp_(incstr, 20L);
/* Writing concatenation */
    i__1[0] = 10, a__1[0] = "Minimum:  ";
    i__1[1] = 20, a__1[1] = minstr;
    s_cat(ch__1, a__1, i__1, &c__2, 30L);
    legnd_(ch__1, 30L);
/* Writing concatenation */
    i__1[0] = 10, a__1[0] = "Maximum:  ";
    i__1[1] = 20, a__1[1] = maxstr;
    s_cat(ch__1, a__1, i__1, &c__2, 30L);
    legnd_(ch__1, 30L);
/* Writing concatenation */
    i__1[0] = 10, a__1[0] = "Contours: ";
    i__1[1] = 20, a__1[1] = incstr;
    s_cat(ch__1, a__1, i__1, &c__2, 30L);
    legnd_(ch__1, 30L);
    return 0;
} /* vgconl_ */

