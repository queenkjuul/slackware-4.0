/* zoom.f -- translated by f2c (version 19951025).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    real sht, swd;
    integer ncols, nrows;
} vgscrn_;

#define vgscrn_1 vgscrn_

struct {
    real bleft1[7], brit1[7], bbot1[7], btop1[7], bxmin[7], bxmax[7], bymin[
	    14]	/* was [7][2] */, bymax[14]	/* was [7][2] */;
    integer ninlx[7], naxlx[7], ninly[14]	/* was [7][2] */, naxly[14]	
	    /* was [7][2] */, msx[7], msy[14]	/* was [7][2] */;
} vglim_;

#define vglim_1 vglim_

struct {
    integer ipoint[6];
} vgzoom_;

#define vgzoom_1 vgzoom_

/* Table of constant values */

static integer c__0 = 0;
static integer c__1 = 1;
static real c_b14 = 0.f;
static doublereal c_b18 = 10.;

/* Subroutine */ int vgzm_0_(int n__, integer *kg, integer *iesc, integer *
	jvcode, integer *iend)
{
    static real zbot, zrit, ztop;
    static integer kflag;
    extern /* Subroutine */ int vgcor_(real *, real *, real *, real *);
    static real zleft;
    static integer kinlx[30]	/* was [6][5] */, kcurr, kaxlx[30]	/* 
	    was [6][5] */;
    static real oxmin[30]	/* was [6][5] */, oxmax[30]	/* was [6][5] 
	    */;
    extern /* Subroutine */ int vgzmp_(integer *, real *, real *, integer *, 
	    integer *, real *, real *, real *, real *);
    static integer kinly1[30]	/* was [6][5] */, kinly2[30]	/* was [6][5] 
	    */, kaxly1[30]	/* was [6][5] */, kaxly2[30]	/* was [6][5] 
	    */;
    static char ch[1];
    static real oymin1[30]	/* was [6][5] */, oymin2[30]	/* was [6][5] 
	    */, oymax1[30]	/* was [6][5] */, oymax2[30]	/* was [6][5] 
	    */, am;
    extern logical agrafa_(integer *, integer *, integer *, integer *);
    static integer isides;
    extern /* Subroutine */ int vgcorf_(integer *, real *, real *, integer *, 
	    integer *, real *, real *, real *, real *, real *, real *, real *,
	     real *);
    extern integer vgiaro_(integer *);
    static integer ksx[30]	/* was [6][5] */, ksy1[30]	/* was [6][5] 
	    */, ksy2[30]	/* was [6][5] */;

/*          ORIGINAL NAME ZOOM */
/*  ZOOMS. */
    switch(n__) {
	case 1: goto L_vgrest;
	}

    am = vgscrn_1.sht * .05f;
    isides = 0;
    *iesc = 0;
    zleft = vglim_1.bleft1[*kg - 1] + (vglim_1.brit1[*kg - 1] - 
	    vglim_1.bleft1[*kg - 1]) * .4f;
    zrit = vglim_1.bleft1[*kg - 1] + (vglim_1.brit1[*kg - 1] - vglim_1.bleft1[
	    *kg - 1]) * .6f;
    ztop = vglim_1.btop1[*kg - 1] - (vglim_1.btop1[*kg - 1] - vglim_1.bbot1[*
	    kg - 1]) * .4f;
    zbot = vglim_1.btop1[*kg - 1] - (vglim_1.btop1[*kg - 1] - vglim_1.bbot1[*
	    kg - 1]) * .6f;
L90:
    vgcor_(&zleft, &zrit, &ztop, &zbot);
L100:
    if (! agrafa_(&c__0, &c__1, &kcurr, &kflag)) {
	goto L100;
    }
    *(unsigned char *)ch = (char) kcurr;
    if (*(unsigned char *)ch == 'F' || *(unsigned char *)ch == 'f') {
	am = vgscrn_1.sht * .005f;
	goto L100;
    } else if (*(unsigned char *)ch == 'C' || *(unsigned char *)ch == 'c') {
	am = vgscrn_1.sht * .05f;
	goto L100;
    } else if (*(unsigned char *)ch == 'S' || *(unsigned char *)ch == 's') {
	isides = 1;
	goto L100;
    } else if (*(unsigned char *)ch == 'W' || *(unsigned char *)ch == 'w') {
	isides = 0;
	goto L100;
    }
    vgcor_(&zleft, &zrit, &ztop, &zbot);
    if (kcurr == 27) {
	*iesc = 1;
	return 0;
    }
    if (vgiaro_(&kcurr) == 1) {
	vgcorf_(&isides, &am, &c_b14, &kcurr, &kflag, &vglim_1.bleft1[*kg - 1]
		, &vglim_1.brit1[*kg - 1], &vglim_1.bbot1[*kg - 1], &
		vglim_1.btop1[*kg - 1], &zleft, &zrit, &zbot, &ztop);
	goto L90;
    }
    if (*(unsigned char *)ch == 'Z' || *(unsigned char *)ch == 'z') {
	++vgzoom_1.ipoint[*kg - 1];
	if (vgzoom_1.ipoint[*kg - 1] > 5) {
	    vgzoom_1.ipoint[*kg - 1] = 5;
	}
	if (vglim_1.msx[*kg - 1] == 0) {
	    ksx[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = 0;
	    oxmin[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.bxmin[*kg 
		    - 1];
	    oxmax[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.bxmax[*kg 
		    - 1];
	} else {
	    ksx[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = 1;
	    kinlx[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.ninlx[*kg 
		    - 1];
	    kaxlx[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.naxlx[*kg 
		    - 1];
	}
	if (vglim_1.msy[*kg - 1] == 0) {
	    ksy1[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = 0;
	    oymin1[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.bymin[*
		    kg - 1];
	    oymax1[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.bymax[*
		    kg - 1];
	} else {
	    ksy1[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = 1;
	    kinly1[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.ninly[*
		    kg - 1];
	    kaxly1[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.naxly[*
		    kg - 1];
	}
	if (vglim_1.msy[*kg + 6] == 0) {
	    ksy2[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = 0;
	    oymin2[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.bymin[*
		    kg + 6];
	    oymax2[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.bymax[*
		    kg + 6];
	} else {
	    ksy2[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = 1;
	    kinly2[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.ninly[*
		    kg + 6];
	    kaxly2[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7] = vglim_1.naxly[*
		    kg + 6];
	}
	vgzmp_(&vglim_1.msx[*kg - 1], &vglim_1.bxmin[*kg - 1], &vglim_1.bxmax[
		*kg - 1], &vglim_1.ninlx[*kg - 1], &vglim_1.naxlx[*kg - 1], &
		zleft, &zrit, &vglim_1.bleft1[*kg - 1], &vglim_1.brit1[*kg - 
		1]);
	vgzmp_(&vglim_1.msy[*kg - 1], &vglim_1.bymin[*kg - 1], &vglim_1.bymax[
		*kg - 1], &vglim_1.ninly[*kg - 1], &vglim_1.naxly[*kg - 1], &
		zbot, &ztop, &vglim_1.bbot1[*kg - 1], &vglim_1.btop1[*kg - 1])
		;
	if (*jvcode == 3) {
	    vgzmp_(&vglim_1.msy[*kg + 6], &vglim_1.bymin[*kg + 6], &
		    vglim_1.bymax[*kg + 6], &vglim_1.ninly[*kg + 6], &
		    vglim_1.naxly[*kg + 6], &zbot, &ztop, &vglim_1.bbot1[*kg 
		    - 1], &vglim_1.btop1[*kg - 1]);
	}
	return 0;
    }
    goto L90;

L_vgrest:
/*          ORIGINAL NAME RESTOR */
/*  RESTORES GRAPH TO CONDITION BEFORE LAST ZOOM. */
    if (vgzoom_1.ipoint[*kg - 1] == 0) {
	*iend = 1;
    } else {
	*iend = 0;
	vglim_1.msx[*kg - 1] = ksx[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7];
	if (vglim_1.msx[*kg - 1] == 0) {
	    vglim_1.bxmin[*kg - 1] = oxmin[*kg + vgzoom_1.ipoint[*kg - 1] * 6 
		    - 7];
	    vglim_1.bxmax[*kg - 1] = oxmax[*kg + vgzoom_1.ipoint[*kg - 1] * 6 
		    - 7];
	} else {
	    vglim_1.ninlx[*kg - 1] = kinlx[*kg + vgzoom_1.ipoint[*kg - 1] * 6 
		    - 7];
	    vglim_1.naxlx[*kg - 1] = kaxlx[*kg + vgzoom_1.ipoint[*kg - 1] * 6 
		    - 7];
	}
	vglim_1.msy[*kg - 1] = ksy1[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7];
	if (vglim_1.msy[*kg - 1] == 0) {
	    vglim_1.bymin[*kg - 1] = oymin1[*kg + vgzoom_1.ipoint[*kg - 1] * 
		    6 - 7];
	    vglim_1.bymax[*kg - 1] = oymax1[*kg + vgzoom_1.ipoint[*kg - 1] * 
		    6 - 7];
	} else {
	    vglim_1.ninly[*kg - 1] = kinly1[*kg + vgzoom_1.ipoint[*kg - 1] * 
		    6 - 7];
	    vglim_1.naxly[*kg - 1] = kaxly1[*kg + vgzoom_1.ipoint[*kg - 1] * 
		    6 - 7];
	}
	vglim_1.msy[*kg + 6] = ksy2[*kg + vgzoom_1.ipoint[*kg - 1] * 6 - 7];
	if (vglim_1.msy[*kg + 6] == 0) {
	    vglim_1.bymin[*kg + 6] = oymin2[*kg + vgzoom_1.ipoint[*kg - 1] * 
		    6 - 7];
	    vglim_1.bymax[*kg + 6] = oymax2[*kg + vgzoom_1.ipoint[*kg - 1] * 
		    6 - 7];
	} else {
	    vglim_1.ninly[*kg + 6] = kinly2[*kg + vgzoom_1.ipoint[*kg - 1] * 
		    6 - 7];
	    vglim_1.naxly[*kg + 6] = kaxly2[*kg + vgzoom_1.ipoint[*kg - 1] * 
		    6 - 7];
	}
	--vgzoom_1.ipoint[*kg - 1];
    }
    return 0;
} /* vgzm_ */

/* Subroutine */ int vgzm_(integer *kg, integer *iesc, integer *jvcode)
{
    return vgzm_0_(0, kg, iesc, jvcode, (integer *)0);
    }

/* Subroutine */ int vgrest_(integer *kg, integer *iend)
{
    return vgzm_0_(1, kg, (integer *)0, (integer *)0, iend);
    }

/* Subroutine */ int vgzmp_(integer *js, real *rmin, real *rmax, integer *
	minlog, integer *maxlog, real *zmin, real *zmax, real *amin, real *
	amax)
{
    /* System generated locals */
    real r__1;
    doublereal d__1;

    /* Builtin functions */
    double pow_dd(doublereal *, doublereal *);

    /* Local variables */
    extern integer vggi_(real *);
    static real tmin, a, d__;
    static integer nin, nax;

/*          ORIGINAL NAME ZCOMP */
/*  PERFORMS COMPUTATIONS FOR THE ZOOM. */
    if (*js == 0) {
	a = (*rmax - *rmin) / (*amax - *amin);
	tmin = *rmin + (*zmin - *amin) * a;
	*rmax = *rmin + (*zmax - *amin) * a;
	*rmin = tmin;
    } else {
	d__ = (*maxlog - *minlog) / (*amax - *amin);
	r__1 = *minlog + (*zmin - *amin) * d__;
	nin = vggi_(&r__1);
	r__1 = -(*minlog + (*zmax - *amin) * d__);
	nax = -vggi_(&r__1);
	if (*maxlog - *minlog > 1) {
	    *minlog = nin;
	    *maxlog = nax;
	    return 0;
	} else {
	    *js = 0;
	    d__1 = (doublereal) (*minlog + (*zmin - *amin) * d__);
	    *rmin = (real)pow_dd(&c_b18, &d__1);
	    d__1 = (doublereal) (*minlog + (*zmax - *amin) * d__);
	    *rmax = (real)pow_dd(&c_b18, &d__1);
	}
    }
    return 0;
} /* vgzmp_ */

