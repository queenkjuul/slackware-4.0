#include <f2c.h>

extern void agraf0_(integer *ierr, integer *imode);
extern short agraf4_(integer *ier);
extern void agraff_(integer *iretcd, integer *iptype, integer *n,
		   integer *ix, integer *iy);
extern void agrafg_(integer *iretcd, integer *idmode, integer *igcol,
		   integer *igrow, integer *itcol, integer *itrow,
		   integer *idpage, integer *idmaxp);
extern int agrafi_(integer *iretcd, integer *istore, integer *iwtype,
		   integer *ix1, integer *iy1, integer *iw, integer *ih,
		   char *array);

extern logical agrafa_(integer *, integer *, integer *, integer *);
