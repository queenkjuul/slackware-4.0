/*
  (c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef PRIVATE_INCLUDE_general
#include "general.h"
#define PRIVATE_INCLUDE_general
#endif
#ifndef PRIVATE_INCLUDE_errorlib
#include "errorlib.h"
#define PRIVATE_INCLUDE_errorlib
#endif
#ifndef PRIVATE_INCLUDE_stringlib
#include "stringlib.h"
#define PRIVATE_INCLUDE_stringlib
#endif
#ifndef PRIVATE_INCLUDE_mylib
#include "mylib.h"
#define PRIVATE_INCLUDE_mylib
#endif

#ifndef INCLUDE_stdarg
#include <stdarg.h>
#define INCLUDE_stdarg
#endif
#ifndef INCLUDE_time
#include <time.h>
#include <sys/time.h>
#define INCLUDE_time
#endif

#define PARSE_REPEATE 1
#define PARSE_NOFATAL 2

long tonumber(char*);
double todouble(char*);
int tonumber(long&,char*,int=0);
int todouble(double&,char*,int=0);

int parse_seps(char*,size_t,FILE*,char*);
int parse_string(string&,FILE*,char*,int=0);
int parse_number(long&,FILE*,char*,int=0);
int parse_double(double&,FILE*,char*,int=0);

int parse_seps(char*,size_t,char**,char*);
int parse_string(string&,char**,char*,int=0);
int parse_number(long&,char**,char*,int=0);
int parse_double(double&,char**,char*,int=0);

int parse_sepc(char*,size_t,FILE*,char*);
int parse_stringc(string&,FILE*,char*,int=0);
int parse_numberc(long&,FILE*,char*,int=0);
int parse_doublec(double&,FILE*,char*,int=0);

int parse_sepc(char*,size_t,char**,char*);
int parse_stringc(string&,char**,char*,int=0);
int parse_numberc(long&,char**,char*,int=0);
int parse_doublec(double&,char**,char*,int=0);

int parse_test_month(tm*,char*,int);
int parse_test_month(tm*,int,int);
int parse_test_day(tm*,int,int);
int parse_test_hour(tm*,int,int);
int parse_test_minute(tm*,int,int);
int parse_test_second(tm*,int,int);
int parse_test_year(tm*,int,int);

int parse_date1(time_t&,char**,int=0);
int parse_date2(time_t&,char**,int=0);
int parse_date_syslog(time_t&,char**,int=0);
int parse_date_brick(time_t&,char**,int=0);

int parse_scanf(FILE*,char*,int,char*,...);
int parse_scanf(char**,char*,int,char*,...);
int parse_scanfc(FILE*,char*,int,char*,...);
int parse_scanfc(char**,char*,int,char*,...);
