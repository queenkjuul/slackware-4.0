/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"

int args_fileatime[]= { TYPE_VALUE_STRING,
                        0 };

flowctrl func_fileatime(type_block* aktblock,opt* options,
                        joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  struct stat stats;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","fileatime: string not defined");
      return back;
    };

  if (stat((*args)[0].stringval,&stats)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","func_fileatime: stat() failed");
      return back;
    };

  back.returnval.val.ulongval=(unsigned long) stats.st_atime;
  return back;
}

int args_filemtime[]= { TYPE_VALUE_STRING,
                        0 };

flowctrl func_filemtime(type_block* aktblock,opt* options,
                        joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  struct stat stats;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","filemtime: string not defined");
      return back;
    };

  if (stat((*args)[0].stringval,&stats)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","func_filemtime: stat() failed");
      return back;
    };

  back.returnval.val.ulongval=(unsigned long) stats.st_mtime;
  return back;
}

int args_unlink[]= { TYPE_VALUE_STRING,
                     0 };

flowctrl func_unlink(type_block* aktblock,opt* options,
                     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","unlink: string not defined");
      return back;
    };

  if (unlink((*args)[0].stringval)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","unlink: unlink() failed");
      return back;
    };

  back.returnval.val.ulongval=1;
  return back;
}

int args_tmpnam[]= { 0 };

flowctrl func_tmpnam(type_block* aktblock,opt* options,
                     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  back.returnval.stringval=tmpnam(NULL);
  if (!defined(back.returnval.stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","tmpnam: tmpnam() failed");
      return back;
    };

  return back;
}

int args_opendir[] = { TYPE_VALUE_STRING,
                       0 };

flowctrl func_opendir(type_block* aktblock,opt* options,
                      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","opendir: string not defined");
      return back;
    };

  DIR* handle=opendir((*args)[0].stringval);
  if (!handle)
    {
      setvarulong("error",1);
      setvarstring("perror","opendir: opendir() failed");
      return back;
    };

  back.returnval.val.longval=options->ptr_h->dirs.insert(handle);
  return back;
}

int args_readdir[] = { TYPE_VALUE_LONG,
                       0 };

flowctrl func_readdir(type_block* aktblock,opt* options,
                      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  if (!options->ptr_h->dirs.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","readdir: illegal handle");
      return back;
    };
  
  DIR* handle=options->ptr_h->dirs.gethandle((*args)[0].val.longval);
  dirent* entry=readdir(handle);
  if (entry)
    {
      back.returnval.stringval=entry->d_name;
    };
  
  return back;
}

int args_closedir[] = { TYPE_VALUE_LONG,
                        0 };

flowctrl func_closedir(type_block* aktblock,opt* options,
                       joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  if (!options->ptr_h->dirs.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","closedir: illegal handle");
      return back;
    };

  DIR* handle=options->ptr_h->dirs.gethandle((*args)[0].val.longval);
  if (closedir(handle)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","closedir: closedir() failed");
      return back;
    };

  options->ptr_h->dirs.del((*args)[0].val.longval);
  back.returnval.val.ulongval=1;
  return back;
}

int args_mkdir[] = { TYPE_VALUE_STRING,
                     0 };

flowctrl func_mkdir(type_block* aktblock,opt* options,
                    joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","mkdir: string not defined");
      return back;
    };

  if (mkdir((*args)[0].stringval,S_IRWXU|S_IXGRP|S_IRGRP|S_IROTH|S_IXOTH)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","mkdir: mkdir() failed");
      return back;
    };

  back.returnval.val.ulongval=1;
  return back;
}

int args_rmdir[] = { TYPE_VALUE_STRING,
                     0 };

flowctrl func_rmdir(type_block* aktblock,opt* options,
                    joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","rmdir: string not defined");
      return back;
    };

  if (rmdir((*args)[0].stringval)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","rmdir: rmdir() failed");
      return back;
    };

  back.returnval.val.ulongval=1;
  return back;
}

int args_rename[] = { TYPE_VALUE_STRING,
                      TYPE_VALUE_STRING,
                      0 };

flowctrl func_rename(type_block* aktblock,opt* options,
                     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  if (!defined((*args)[0].stringval) ||
      !defined((*args)[1].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","rename: string not defined");
      return back;
    };

  if (rename((*args)[0].stringval,(*args)[1].stringval)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","rename: rename() failed");
      return back;
    };
  
  back.returnval.val.ulongval=1;
  return back;
}

