/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"

string strtok_string;
char* strtok_ptr=0;

int args_defined[]= { TYPE_VALUE_STRING,
                      0 };

flowctrl func_defined(type_block* aktblock,opt* options,
                      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=defined((*args)[0].stringval);
  return back;
}

int args_strstr[]= { TYPE_VALUE_STRING,
                     TYPE_VALUE_STRING,
                     0 };

flowctrl func_strstr(type_block* aktblock,opt* options,
                     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  if (!defined((*args)[0].stringval) || !defined((*args)[1].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","strstr: string not defined");
      return back;
    };

  back.returnval.stringval=strstr((*args)[0].stringval,(*args)[1].stringval);

  return back;
}

int args_strtok[]= { TYPE_VALUE_STRING,
                     TYPE_VALUE_STRING,
                     0 };

flowctrl func_strtok(type_block* aktblock,opt* options,
                     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  if (!defined((*args)[0].stringval) || !defined((*args)[1].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","strtok: string not defined");
      return back;
    };

  strtok_string=(*args)[0].stringval;
  strtok_ptr=strtok_string;
  
  unsigned long i=0;

  if (!strtok_ptr[i])
    {
      setvarulong("error",1);
      setvarstring("perror","strtok: end of string");
      return back;
    };

  while (strtok_ptr[i])
    {
      if (strchr((*args)[1].stringval,strtok_ptr[i]))
        {
          strtok_ptr[i++]=0;
          break;
        };
      i++;
    };
  back.returnval.stringval=strtok_ptr;
  strtok_ptr+=i;
  return back;
}

int args_token[]= { TYPE_VALUE_STRING,
                    0 };

flowctrl func_token(type_block* aktblock,opt* options,
                    joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","strtok: string not defined");
      return back;
    };

  unsigned long i=0;

  if (!strtok_ptr[i])
    {
      setvarulong("error",1);
      setvarstring("perror","token: end of string");
      return back;
    };

  while (strtok_ptr[i])
    {
      if (strchr((*args)[0].stringval,strtok_ptr[i]))
        {
          strtok_ptr[i++]=0;
          break;
        };
      i++;
    };
  back.returnval.stringval=strtok_ptr;
  strtok_ptr+=i;
  return back;
}

int args_strtok_esc[]= { TYPE_VALUE_STRING,
                         TYPE_VALUE_STRING,
                         0 };

flowctrl func_strtok_esc(type_block* aktblock,opt* options,
                         joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  if (!defined((*args)[0].stringval) || !defined((*args)[1].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","strtok_esc: string not defined");
      return back;
    };

  strtok_string=(*args)[0].stringval;
  strtok_ptr=strtok_string;
  
  unsigned long i=0;

  if (!strtok_ptr[i])
    {
      setvarulong("error",1);
      setvarstring("perror","strtok_esc: end of string");
      return back;
    };

  while (strtok_ptr[i])
    {
      if (strtok_ptr[i]=='\\')
        { 
          i++;
          if (!strtok_ptr[i])
            {
              setvarulong("error",1);
              setvarstring("perror","strtok: EOF after escape");
              return back;
            };
        }
      else if (strchr((*args)[1].stringval,strtok_ptr[i]))
        {
          strtok_ptr[i++]=0;
          break;
        };
      i++;
    };
  back.returnval.stringval=strtok_ptr;
  strtok_ptr+=i;
  return back;
}

int args_token_esc[]= { TYPE_VALUE_STRING,
                        0 };

flowctrl func_token_esc(type_block* aktblock,opt* options,
                        joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","token_esc: string not defined");
      return back;
    };

  unsigned long i=0;

  if (!strtok_ptr[i])
    {
      setvarulong("error",1);
      setvarstring("perror","token_esc: end of string");
      return back;
    };

  while (strtok_ptr[i])
    {
      if (strtok_ptr[i]=='\\')
        {
          i++;
          if (!strtok_ptr[i])
            {
              setvarulong("error",1);
              setvarstring("perror","token_esc: EOF after escape");
              return back;
            };
        }
      else if (strchr((*args)[0].stringval,strtok_ptr[i]))
        {
          strtok_ptr[i++]=0;
          break;
        };
      i++;
    };
  back.returnval.stringval=strtok_ptr;
  strtok_ptr+=i;
  return back;
}

int args_strtolower[]= { TYPE_VALUE_STRING,
                         0 };

flowctrl func_strtolower(type_block* aktblock,opt* options,
                         joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","strtolower: string not defined");
      return back;
    };

  back.returnval.stringval=(*args)[0].stringval;
  str_lwr(back.returnval.stringval);

  return back;
}

int args_strtoupper[]= { TYPE_VALUE_STRING,
                         0 };

flowctrl func_strtoupper(type_block* aktblock,opt* options,
                         joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","strtoupper: string not defined");
      return back;
    };

  back.returnval.stringval=(*args)[0].stringval;
  str_upr(back.returnval.stringval);

  return back;
}

int args_substr[]= { TYPE_VALUE_STRING,
                     TYPE_VALUE_ULONG,
                     TYPE_VALUE_ULONG,
                     0 };

flowctrl func_substr(type_block* aktblock,opt* options,
                     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","substr: string not defined");
      return back;
    };

  if ((*args)[1].val.ulongval > strlen((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","substr: position to high");
      return back;
    };

  back.returnval.stringval=((*args)[0].stringval.zgr)+(*args)[1].val.ulongval;

  if ((*args)[2].val.ulongval)
    {
      if ((*args)[2].val.ulongval > strlen(back.returnval.stringval))
        {
          setvarulong("error",1);
          setvarstring("perror","substr: length to high");
          return back;
        };
      
      back.returnval.stringval.zgr[(*args)[2].val.ulongval]=0;
      back.returnval.stringval.len=strlen(back.returnval.stringval);
    };

  return back;
}

int args_strlen[]= { TYPE_VALUE_STRING,
                     0 };

flowctrl func_strlen(type_block* aktblock,opt* options,
                     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","strlen: string not defined");
      return back;
    };

  back.returnval.val.ulongval=strlen((*args)[0].stringval);

  return back;
}

int args_escape[]= { TYPE_VALUE_STRING,
                     TYPE_VALUE_STRING,
                     0 };

flowctrl func_escape(type_block* aktblock,opt* options,
                     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  char buf[2];
  buf[1]=0;

  if (!defined((*args)[0].stringval) || !defined((*args)[1].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","escape: string not defined");
      return back;
    };

  back.returnval.stringval="";
  unsigned long len=strlen((*args)[0].stringval);
  unsigned long len1=strlen((*args)[1].stringval);
  for (unsigned long i=0;i!=len;i++)
    {
      buf[0]=(*args)[0].stringval[i];
      if (buf[0]=='\\')
        {
          back.returnval.stringval+="\\";
        }
      else
        {
          for (unsigned long u=0;u!=len1;u++)
            {
              if (buf[0]==(*args)[1].stringval[u])
                {
                  back.returnval.stringval+="\\";
                  break;
                };
            };
        };
      back.returnval.stringval+=buf;
    };

  return back;
}

int args_unescape[]= { TYPE_VALUE_STRING,
                       0 };

flowctrl func_unescape(type_block* aktblock,opt* options,
                       joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  char buf[2];
  buf[1]=0;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","unescape: string not defined");
      return back;
    };

  back.returnval.stringval="";
  unsigned long len=strlen((*args)[0].stringval);
  for (unsigned long i=0;i!=len;i++)
    {
      buf[0]=(*args)[0].stringval[i];
      if (buf[0]!='\\')
        {
          back.returnval.stringval+=buf;
        }
      else if (i+1 < len && (*args)[0].stringval[i+1]=='\\')
        {
          back.returnval.stringval+="\\";
	  i++;
        };
    };

  return back;
}

int args_escape1[]= { TYPE_VALUE_STRING,
                      0 };

flowctrl func_escape1(type_block* aktblock,opt* options,
                      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  char buf[2];
  buf[1]=0;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","escape1: string not defined");
      return back;
    };

  back.returnval.stringval="";
  unsigned long len=strlen((*args)[0].stringval);
  for (unsigned long i=0;i!=len;i++)
    {
      buf[0]=(*args)[0].stringval[i];
      if (buf[0]=='\\') { back.returnval.stringval+="\\"; }
      else if (buf[0]=='\n')
        { buf[0]='n'; back.returnval.stringval+="\\"; }
      else if (buf[0]=='\r')
        { buf[0]='n'; back.returnval.stringval+="\\"; }
      else if (buf[0]=='\v')
        { buf[0]='v'; back.returnval.stringval+="\\"; }
      else if (buf[0]=='\f')
        { buf[0]='f'; back.returnval.stringval+="\\"; };
            back.returnval.stringval+=buf;
    };

  return back;
}

int args_unescape1[]= { TYPE_VALUE_STRING,
                        0 };

flowctrl func_unescape1(type_block* aktblock,opt* options,
                        joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  char buf[2];
  buf[1]=0;
  
  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","unescape: string not defined");
      return back;
    };

  back.returnval.stringval="";
  unsigned long len=strlen((*args)[0].stringval);
  for (unsigned long i=0;i<len;i++)

    {
      buf[0]=(*args)[0].stringval[i];
      if (buf[0]!='\\')
        {
          back.returnval.stringval+=buf;
        }
      else if (i+1 < len)
        {
          if ((*args)[0].stringval[i+1]=='\\')
            {
              back.returnval.stringval+="\\";
              i++;
            }
          else if ((*args)[0].stringval[i+1]=='n')
            {
              back.returnval.stringval+="\n";
              i++;
            }
          else if ((*args)[0].stringval[i+1]=='r')
            {
              back.returnval.stringval+="\r";
              i++;
            }
          else if ((*args)[0].stringval[i+1]=='v')
            {
              back.returnval.stringval+="\v";
              i++;
            }
          else if ((*args)[0].stringval[i+1]=='f')
            {
              back.returnval.stringval+="\f";
              i++;
            };
        };
    };

  return back;
}

int args_textfile[]= { TYPE_VALUE_STRING,
                       0 };

flowctrl func_textfile(type_block* aktblock,opt* options,
                       joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  char buf[65536];
  buf[65535]=0;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","textfile: string not defined");
      return back;
    };

  int handle=open((*args)[0].stringval,O_RDONLY);
  if (handle==-1)
    { 
      setvarulong("error",1);
      setvarstring("perror","textfile: cannot open "+(*args)[0].stringval);
      return back;
    };

  back.returnval.stringval="";
  unsigned long size;
  while ((size=read(handle,buf,65535))==65535)
    {
      buf[size]=0;
      if (strlen(buf)!=65535) { break; };
      back.returnval.stringval+=buf;
    };
  buf[size]=0;
  back.returnval.stringval+=buf;
  close(handle);

  return back;
}

int args_getchar[]= { TYPE_VALUE_STRING,
                      TYPE_VALUE_ULONG,
                      0 };

flowctrl func_getchar(type_block* aktblock,opt* options,
                      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","getchar: string not defined");
      return back;
    };

  if ((*args)[1].val.ulongval>=strlen((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","getchar: index too big");
      return back;
    };

  unsigned char ccc=(*args)[0].stringval[(*args)[1].val.ulongval];
  back.returnval.val.ulongval=(unsigned long) ccc;
  return back;
}

int args_sql_escape[]= { TYPE_VALUE_STRING,
                         0 };

flowctrl func_sql_escape(type_block* aktblock,opt* options,
                         joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  char buf[2];
  buf[1]=0;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","sql_escape: string not defined");
      return back;
    };

  back.returnval.stringval="";
  unsigned long len=strlen((*args)[0].stringval);
  for (unsigned long i=0;i!=len;i++)
    {
      buf[0]=(*args)[0].stringval[i];
      if (buf[0]=='\'' || buf[0]=='"' || buf[0]=='\\')
        {
          back.returnval.stringval+="\\";
        };
      back.returnval.stringval+=buf;
    };

  return back;
}
