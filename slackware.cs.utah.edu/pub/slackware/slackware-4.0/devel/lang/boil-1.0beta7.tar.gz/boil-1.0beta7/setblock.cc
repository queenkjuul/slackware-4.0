/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"
#ifdef WITH_RPC
#include "rpc.h"
#endif

void type_reference::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_reference");
#endif
  block=newblock;

  if (type==TYPE_REFERENCE_COMPLEX)
    {
      expr->setblock(newblock);
      if (counter) { counter->setblock(newblock); };
    };
}

void type_function_call::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_function_call");
#endif
  block=newblock;

  reference->setblock(newblock);
  for (unsigned long i=0;i!=expr_list->exprs.length();i++)
    {
      expr_list->exprs[i].setblock(newblock);
    };
}

void type_expr::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_expr");
#endif

  block=newblock;

  switch (type)
    {
    case TYPE_EXPR_CONST:
      {
        break;
      };
    case TYPE_EXPR_REFERENCE:
      {
        uptr.reference->setblock(newblock);
        break;
      };
    case TYPE_EXPR_CAST:
      {
        expr1->setblock(newblock);
        break;
      };
    case TYPE_EXPR_FUNCTION_CALL:
      {
        uptr.function_call->setblock(newblock);
        break;
      };
    case TYPE_EXPR_ASSIGNMENT:
      {
        uptr.reference->setblock(newblock);
        expr1->setblock(newblock);
        break;
      };
    case TYPE_EXPR_POSTINKREMENT:
      {
        uptr.reference->setblock(newblock);
        break;
      };
    case TYPE_EXPR_POSTDEKREMENT:
      {
        uptr.reference->setblock(newblock);
        break;
      };
    case TYPE_EXPR_PREINCREMENT:
      {
        uptr.reference->setblock(newblock);
        break;
      };
    case TYPE_EXPR_PREDECREMENT:
      {
        uptr.reference->setblock(newblock);
        break;
      };
    case TYPE_EXPR_EXPR:
      {
        expr1->setblock(newblock);
        break;
      };
    case TYPE_EXPR_OPERATOR_ONE:
      {
        expr1->setblock(newblock);
        break;
      };
    case TYPE_EXPR_OPERATOR_TWO:
      {
        expr1->setblock(newblock);
        expr2->setblock(newblock);
        break;
      };
    default:
      {
        /* not reached (hopefully) */
      };
    };

  return;
}

void type_function_dekl::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_function_dekl");
#endif

  reference->setblock(newblock);

  if (opt_expr) { opt_expr->setblock(newblock); };

  if (type==TYPE_FUNC_DEKL_NORMAL)
    {
      myblock->setblock(NULL);
    }
  else if (type==TYPE_FUNC_DEKL_EVAL)
    {
      eval_stmt->setblock(newblock);
    }
  else if (type==TYPE_FUNC_DEKL_EXTERNAL)
    {
      external_stmt->setblock(newblock);
    }
  else
    {
      /* not reached */
    };
}

void type_dekl_list_entry::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_dekl_list_entry");
#endif

  reference->setblock(newblock);
  if (type==TYPE_DEKL_LIST_ENTRY_REFINIT)
    {
      expr->setblock(newblock);
    };
}

void type_variable_dekl::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_variable_dekl");
#endif

  for (unsigned long i=0;i!=dekl_list->entrys.length();i++)
    {
      dekl_list->entrys[i].setblock(newblock);
    };
}

void type_expr_stmt::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_expr_stmt");
#endif

  if (type==TYPE_EXPR_STMT_DEFINED)
    {
      expr->setblock(newblock);
    };
}

void type_choice_stmt::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_choice_stmt");
#endif

  expr->setblock(newblock);
  stmt1->setblock(newblock);
  if (type==TYPE_CHOICE_STMT_ELSE) { stmt2->setblock(newblock); };
}

void type_loop_stmt::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_loop_stmt");
#endif

  if (expr) { expr->setblock(newblock); };
  if (expr_for) { expr_for->setblock(newblock); };
  stmt->setblock(newblock);
  if (stmt_for) { stmt_for->setblock(newblock); };
}

void type_jump_stmt::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_jump_stmt");
#endif

  if (type==TYPE_JUMP_STMT_RETURNVAL)
    {
      expr->setblock(newblock);
    };
}

void type_eval_stmt::setblock(type_block* newblock)
{
#ifdef DEBUGGING
 log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_eval_stmt");
#endif

 expr_code->setblock(newblock);
}

void type_external_stmt::setblock(type_block* newblock)
{
#ifdef DEBUGGING
 log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_external_stmt");
#endif

 expr_handle->setblock(newblock);
 expr_function->setblock(newblock);
 expr_pw->setblock(newblock);
}

void type_stmt::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_stmt");
#endif

  switch (type)
    {
    case TYPE_STMT_VARIABLE_DEKL:
      {
        uptr.variable_dekl->setblock(newblock);
        break;
      };
    case TYPE_STMT_FUNCTION_DEKL:
      {
        uptr.function_dekl->setblock(newblock);
        break;
      };
    case TYPE_STMT_EXPR_STMT:
      {
        uptr.expr_stmt->setblock(newblock);
        break;
      };
    case TYPE_STMT_BLOCK:
      {
        uptr.block->setblock(newblock);
        break;
      };
    case TYPE_STMT_CHOICE_STMT:
      {
        uptr.choice_stmt->setblock(newblock);
        break;
      };
    case TYPE_STMT_LOOP_STMT:
      {
        uptr.loop_stmt->setblock(newblock);
        break;
      };
    case TYPE_STMT_JUMP_STMT:
      {
        uptr.jump_stmt->setblock(newblock);
        break;
      };
    case TYPE_STMT_PRINT_STMT:
      {
        break;
      };
    default:
      {

        /* not reached (hopefully) */
      };
    };
}

void type_block::setblock(type_block* newblock)
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"setblock(): type_block");
#endif

  block=newblock;

  for (unsigned long i=0;i!=stmt_list->stmts.length();i++)
    {
      stmt_list->stmts[i].setblock(this);
    };
}

