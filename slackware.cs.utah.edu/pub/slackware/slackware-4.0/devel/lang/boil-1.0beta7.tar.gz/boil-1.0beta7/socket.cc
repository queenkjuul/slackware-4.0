/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"
 
int args_makesock[]= { TYPE_VALUE_STRING,
                       TYPE_VALUE_ULONG,
                       TYPE_VALUE_LONG,
                       TYPE_VALUE_LONG,
                       0 };

flowctrl func_makesock(type_block* aktblock,opt* options,
                       joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;

  int sock;
  struct sockaddr_in my_addr;
  struct in_addr tmp;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","makesock: string not defined");
      return back;
    };

  if ((*args)[0].stringval=="")
    {
      tmp.s_addr=htonl(INADDR_ANY);
    }
  else
    {
      if (!inet_aton((*args)[0].stringval,&tmp))
        {
          setvarulong("error",1);
          setvarstring("perror","makesock: syntax error in ip-address");
          return back;
        };
    };
      
  memset((void*)& my_addr,0,sizeof(my_addr));
  my_addr.sin_port=htons((unsigned short int) (*args)[1].val.ulongval);
  my_addr.sin_family=AF_INET;
  my_addr.sin_addr=tmp;

  sock=socket(AF_INET,(int) (*args)[2].val.longval,
              (int) (*args)[3].val.longval);
  if (sock==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","makesock: socket() failed");
      return back;
    };
  if (bind(sock,(struct sockaddr*)&my_addr,sizeof(my_addr))==-1)
    {
      close(sock);
      setvarulong("error",1);
      setvarstring("perror","makesock: bind() failed");
      return back;
    };

  back.returnval.val.longval=options->ptr_h->sockets.insert(sock);
  return back;
}

int args_closesock[] = { TYPE_VALUE_LONG,
                         0 };

flowctrl func_closesock(type_block* aktblock,opt* options,
                        joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  int sock;

  if (!options->ptr_h->sockets.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","closesock: illegal handle");
      return back;
    };
  
  sock=options->ptr_h->sockets.gethandle((*args)[0].val.longval);
  
  if (!close(sock)) { back.returnval.val.ulongval=1; };
  options->ptr_h->sockets.del((*args)[0].val.longval);
  return back;
}

