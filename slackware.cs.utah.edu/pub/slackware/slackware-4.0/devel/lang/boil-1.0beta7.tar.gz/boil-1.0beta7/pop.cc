/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"
#ifdef WITH_RPC
#include "rpc.h"
#endif

void type_choice_stmt::pop()
{
  stmt1->pop();
  if (type==TYPE_CHOICE_STMT_ELSE) { stmt2->pop(); };
}

void type_loop_stmt::pop()
{
  stmt->pop();
  if (stmt_for) { stmt_for->pop(); };
}

void type_stmt::pop()
{
  switch (type)
    {
    case TYPE_STMT_BLOCK:
      {
        uptr.block->pop();
        break;
      };
    case TYPE_STMT_CHOICE_STMT:
      {
        uptr.choice_stmt->pop();
        break;
      };
    case TYPE_STMT_LOOP_STMT:
      {
        uptr.loop_stmt->pop();
        break;
      };
    };
}

void type_block::pop()
{
  stack.remove_listelem(0);

  for (unsigned long i=0;i!=stmt_list->stmts.length();i++)
    {
      stmt_list->stmts[i].pop();
    };
}
