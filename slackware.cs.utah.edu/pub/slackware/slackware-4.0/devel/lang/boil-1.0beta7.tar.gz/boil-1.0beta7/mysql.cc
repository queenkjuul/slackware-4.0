/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"

#ifdef WITH_MYSQL

int args_mysql_close[]= { TYPE_VALUE_LONG,
			  0 };

flowctrl func_mysql_close(type_block* aktblock,opt* options,
			  joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  MYSQL* conn;

  if (!options->ptr_h->mysql_connections.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_close: illegal mysql connection number");
      return back;
    };
  conn=options->ptr_h->mysql_connections.gethandle((*args)[0].val.longval);

  mysql_close(conn);
  options->ptr_h->mysql_connections.del((*args)[0].val.longval);
  back.returnval.val.ulongval=1;
  return back;
}

int args_mysql_connect[]= { TYPE_VALUE_STRING,
			    TYPE_VALUE_STRING,
			    TYPE_VALUE_STRING,
			    0 };

flowctrl func_mysql_connect(type_block* aktblock,opt* options,
			    joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back,call;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;
  MYSQL* conn;

  if (!defined((*args)[0].stringval) ||
      !defined((*args)[1].stringval) ||
      !defined((*args)[2].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_connect: string not defined");
      return back;
    };

  conn=mysql_connect(0,
		     (*args)[0].stringval,
		     (*args)[1].stringval,
		     (*args)[2].stringval);
  if (!conn)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_connect: cannot connect");
      return back;
    };
  
  back.returnval.val.longval=options->ptr_h->mysql_connections.insert(conn);
  return back;
}

int args_mysql_selectdb[]= { TYPE_VALUE_LONG,
			     TYPE_VALUE_STRING,
			     0 };

flowctrl func_mysql_selectdb(type_block* aktblock,opt* options,
			     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back,call;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  MYSQL* conn;

  if (!defined((*args)[1].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_selectdb: string not defined");
      return back;
    };

  if (!options->ptr_h->mysql_connections.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_selectdb: illegal mysql connection number");
      return back;
    };
  conn=options->ptr_h->mysql_connections.gethandle((*args)[0].val.longval);

  if (mysql_select_db(conn,(*args)[1].stringval)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_selectdb: mysql_select_db() failed");
      return back;
    };
  back.returnval.val.ulongval=1;
  return back;
}  

int args_mysql_exec[]= { TYPE_VALUE_LONG,
			 TYPE_VALUE_STRING,
			 0 };

flowctrl func_mysql_exec(type_block* aktblock,opt* options,
			 joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back,call;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;
  MYSQL* conn;
  MYSQL_RES* result;
  string errormessage;

  if (!defined((*args)[1].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_exec: string not defined");
      return back;
    };

  if (!options->ptr_h->mysql_connections.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_exec: illegal mysql connection number");
      return back;
    };
  conn=options->ptr_h->mysql_connections.gethandle((*args)[0].val.longval);

  if (mysql_query(conn,(*args)[1].stringval)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_exec: query failed :"+(*args)[1].stringval);
      return back;
    };
  result=mysql_store_result(conn);
  back.returnval.val.longval=options->ptr_h->mysql_querys.insert(result);
  return back;
}  

int args_mysql_freeresult[]= { TYPE_VALUE_LONG,
			       0 };

flowctrl func_mysql_freeresult(type_block* aktblock,opt* options,
			       joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  MYSQL_RES* result;

  if (!options->ptr_h->mysql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_freeresult: illegal mysql result number");
      return back;
    };
  result=options->ptr_h->mysql_querys.gethandle((*args)[0].val.longval);

  if (result)
    {
      mysql_free_result(result);
    };
  options->ptr_h->mysql_querys.del((*args)[0].val.longval);
  back.returnval.val.ulongval=1;
  return back;
}

int args_mysql_numfields[]= { TYPE_VALUE_LONG,
			      0 };

flowctrl func_mysql_numfields(type_block* aktblock,opt* options,
			      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  MYSQL_RES* result;

  if (!options->ptr_h->mysql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_numfields: illegal mysql result number");
      return back;
    };
  result=options->ptr_h->mysql_querys.gethandle((*args)[0].val.longval);

  if (result)
    {
      back.returnval.val.ulongval=(unsigned long) mysql_num_fields(result);
    };
  return back;
}

int args_mysql_numrows[]= { TYPE_VALUE_LONG,
			    0 };

flowctrl func_mysql_numrows(type_block* aktblock,opt* options,
			    joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  MYSQL_RES* result;

  if (!options->ptr_h->mysql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_numrows: illegal mysql result number");
      return back;
    };
  result=options->ptr_h->mysql_querys.gethandle((*args)[0].val.longval);

  if (result)
    {
      back.returnval.val.ulongval=(unsigned long) mysql_num_rows(result);
    };
  return back;
}

int args_mysql_result[]= { TYPE_VALUE_LONG,
			   TYPE_VALUE_ULONG,
			   TYPE_VALUE_ULONG,
			   0 };

flowctrl func_mysql_result(type_block* aktblock,opt* options,
			   joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  MYSQL_RES* result;

  if (!options->ptr_h->mysql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_result: illegal mysql result number");
      return back;
    };
  result=options->ptr_h->mysql_querys.gethandle((*args)[0].val.longval);

  if (!result)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_result: no result");
      return back;
    };

  mysql_data_seek(result,(int) (*args)[1].val.ulongval);
  MYSQL_ROW row=mysql_fetch_row(result);
  if (!row)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_result: no result");
      return back;
    };
  if (mysql_num_fields(result)<=(unsigned int) (*args)[2].val.ulongval)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_result: field index to high");
      return back;
    };
  back.returnval.stringval=row[(*args)[2].val.ulongval];
  return back;
}

int args_mysql_fieldtype[]= { TYPE_VALUE_LONG,
			      TYPE_VALUE_ULONG,
			      0 };

flowctrl func_mysql_fieldtype(type_block* aktblock,opt* options,
                              joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;
  MYSQL_RES* result;

  if (!options->ptr_h->mysql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_numrows: illegal mysql result number");
      return back;
    };
  result=options->ptr_h->mysql_querys.gethandle((*args)[0].val.longval);

  if (!result)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_fieldtype: no result");
      return back;
    };

  mysql_field_seek(result,(int) (*args)[1].val.ulongval);
  MYSQL_FIELD* field=mysql_fetch_field(result);
  if (!field)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_fieldtype: no result");
      return back;
    };

  back.returnval.val.longval=(long) field->type;
  return back;
}

int args_mysql_fieldname[]= { TYPE_VALUE_LONG,
			      TYPE_VALUE_ULONG,
			      0 };

flowctrl func_mysql_fieldname(type_block* aktblock,opt* options,
			      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  MYSQL_RES* result;

  if (!options->ptr_h->mysql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_numrows: illegal mysql result number");
      return back;
    };
  result=options->ptr_h->mysql_querys.gethandle((*args)[0].val.longval);

  if (!result)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_fieldname: no result");
      return back;
    };

  mysql_field_seek(result,(int) (*args)[1].val.ulongval);
  MYSQL_FIELD* field=mysql_fetch_field(result);
  if (!field)
    {
      setvarulong("error",1);
      setvarstring("perror","mysql_fieldname: no result");
      return back;
    };

  back.returnval.stringval=field->name;
  return back;
}

#endif
