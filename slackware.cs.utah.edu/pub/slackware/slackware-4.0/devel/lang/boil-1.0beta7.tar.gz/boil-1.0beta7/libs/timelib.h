/*
  (c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef PRIVATE_INCLUDE_general
#include "general.h"
#define PRIVATE_INCLUDE_general
#endif

#ifndef INCLUDE_time
#include <time.h>
#include <sys/time.h>
#define INCLUDE_time
#endif

struct mytimer
{
  timeval tv;

  /* aktuelle zeit setzen */
  void gettime();

  /* konstruktor */
  mytimer();

  /* konversionen */
  mytimer(unsigned long);
  operator unsigned long();
  operator char*();
  operator bool();

  /* addition und subtraktion */
  mytimer& operator+=(mytimer);
  mytimer& operator-=(mytimer);
};

/* + - < > <= >= == ! ueberladen */
mytimer operator+(mytimer,mytimer);
mytimer operator-(mytimer,mytimer);
int operator<(mytimer,mytimer);
int operator>(mytimer,mytimer);
int operator==(mytimer,mytimer);
int operator<=(mytimer,mytimer);
int operator>=(mytimer,mytimer);


