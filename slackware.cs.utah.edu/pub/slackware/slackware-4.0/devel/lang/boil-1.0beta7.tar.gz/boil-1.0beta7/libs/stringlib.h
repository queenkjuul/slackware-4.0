/*
  (c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef PRIVATE_INCLUDE_general
#include "general.h"
#define PRIVATE_INCLUDE_general
#endif
#ifndef PRIVATE_INCLUDE_errorlib
#include "errorlib.h"
#define PRIVATE_INCLUDE_errorlib
#endif

#ifndef INCLUDE_iostream
#include <iostream.h>
#define INCLUDE_iostream
#endif
#ifndef INCLUDE_iomanip
#include <iomanip.h>
#define INCLUDE_iomanip
#endif
#ifndef INCLUDE_fstream
#include <fstream.h>
#define INCLUDE_fstream
#endif

class string
{
public:
  char* zgr;
  unsigned long len;

  /* konstruktor */
  string();

  /* destruktor */
  ~string();

  /* copy-konstruktor */
  string(string&);

  /* = ueberladen */
  string& operator=(string);

  /* += ueberladen */
  string& operator+=(string);

  /* [] ueberladen */
  char& operator[](unsigned long);

  /* konversion von char* nach string */
  string(char*);

  /* konversion von string nach char* */
  operator char*();

  /* sonstiges */
  string word(unsigned int);
  unsigned int words();

};

/* ausgabe in streams */
ostream& operator<<(ostream&, string&);

/* +, ==, !=, += ueberladen */
string operator+(string,string);
int operator==(string,string);
int operator!=(string,string);
bool defined(string&);
extern unsigned long string_mem;
unsigned long hash(string&);
