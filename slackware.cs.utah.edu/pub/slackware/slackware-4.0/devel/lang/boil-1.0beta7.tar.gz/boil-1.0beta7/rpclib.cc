/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"

#ifdef WITH_RPC

#include "rpc.h"
 
int args_clnt_create[]= { TYPE_VALUE_STRING,
                          TYPE_VALUE_ULONG,
                          TYPE_VALUE_ULONG,
                          TYPE_VALUE_STRING,
                          0 };

flowctrl func_clnt_create(type_block* aktblock,opt* options,
                          joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;

  if (!defined((*args)[0].stringval) ||
      !defined((*args)[3].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","clnt_create: string not defined");
      return back;
    };

  CLIENT* clnt=clnt_create((*args)[0].stringval,
                           (*args)[1].val.ulongval,
                           (*args)[2].val.ulongval,
                           (*args)[3].stringval);

  if (!clnt)
    {
      setvarulong("error",1);
      setvarstring("perror","clnt_create: clnt_create() failed");
      return back;
    };

  /* insert client and return its handle */
  back.returnval.val.longval=options->ptr_h->rpc_clients.insert(clnt);
  return back;
}

int args_clnt_timeout[]= { TYPE_VALUE_LONG,
                           TYPE_VALUE_ULONG,
                           0 };

flowctrl func_clnt_timeout(type_block* aktblock,opt* options,
                           joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  CLIENT* clnt;

  /* get client */
  if (!options->ptr_h->rpc_clients.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","clnt_timeout: illegal client handle");
      return back;
    };
  clnt=options->ptr_h->rpc_clients.gethandle((*args)[0].val.longval);

  struct timeval t;
  t.tv_sec=(*args)[1].val.ulongval;
  t.tv_usec=0;

  if (!clnt_control(clnt,CLSET_TIMEOUT,&t))
    {
      setvarulong("error",1);
      setvarstring("perror","clnt_timeout: clnt_control failed");
      return back;
    };

  back.returnval.val.ulongval=1;
  return back;
}

int args_clnt_udp_retry[]= { TYPE_VALUE_LONG,
                             TYPE_VALUE_ULONG,
                             0 };

flowctrl func_clnt_udp_retry(type_block* aktblock,opt* options,
                             joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  CLIENT* clnt;

  /* get client */
  if (!options->ptr_h->rpc_clients.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","clnt_timeout: illegal client handle");
      return back;
    };
  clnt=options->ptr_h->rpc_clients.gethandle((*args)[0].val.longval);

  struct timeval t;
  t.tv_sec=(*args)[1].val.ulongval;
  t.tv_usec=0;

  /* retry timeout for UDP */
  if (!clnt_control(clnt,CLSET_RETRY_TIMEOUT,&t))
    {
      setvarulong("error",1);
      setvarstring("perror","clnt_udp_retry: clnt_control failed");
      return back;
    };
  
  back.returnval.val.ulongval=1;
  return back;
}

int args_clnt_destroy[]= { TYPE_VALUE_LONG,
                           0 };

flowctrl func_clnt_destroy(type_block* aktblock,opt* options,
                           joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  CLIENT* clnt;

  /* get client */
  if (!options->ptr_h->rpc_clients.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","clnt_destroy: illegal client handle");
      return back;
    };
  clnt=options->ptr_h->rpc_clients.gethandle((*args)[0].val.longval);

  clnt_destroy(clnt);
  options->ptr_h->rpc_clients.del((*args)[0].val.longval);
  back.returnval.val.ulongval=1;
  return back;
}

int args_svc_register[]= { TYPE_VALUE_ULONG,
                           TYPE_VALUE_ULONG,
                           TYPE_VALUE_ULONG,
                           TYPE_VALUE_ULONG,
                           TYPE_VALUE_LONG,
                           0 };

flowctrl func_svc_register(type_block* aktblock,opt* options,
                           joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;
  int status;

  int sock;

  if ((*args)[4].val.longval==-1)
    {
      sock=RPC_ANYSOCK;
    }
  else
    {
      if (!options->ptr_h->sockets.ishandle((*args)[4].val.longval))
        {
          setvarulong("error",1);
          setvarstring("perror","closesock: illegal handle");
          return back;
        };
      sock=options->ptr_h->sockets.gethandle((*args)[4].val.longval);
    };

  rpc_transport tp;

  /* create transport */
  if ((*args)[2].val.ulongval==IPPROTO_TCP)
    {
      tp.transport=svctcp_create(sock,0,0);
      if (!tp.transport)
        {
          setvarulong("error",1);
          setvarstring("perror","svc_register: svctcp_create() failed");
          return back;
        };
    }
  else if ((*args)[2].val.ulongval==IPPROTO_UDP)
    {
      tp.transport=svcudp_create(sock);
      if (!tp.transport)
        {
          setvarulong("error",1);
          setvarstring("perror","svc_register: svctcp_create() failed");
          return back;
        };
    }
  else
    {
      setvarulong("error",1);
      setvarstring("perror","svc_register: unknown protocol");
      return back;
    };

  /* register transport with program and version numbers */
  tp.program=(*args)[0].val.ulongval;
  tp.version=(*args)[1].val.ulongval;

  if ((*args)[3].val.ulongval)
    {
      status=svc_register(tp.transport,
                          tp.program,
                          tp.version,
                          (void (*)(svc_req *, SVCXPRT *)) boilrpc_1_fork,
                          (*args)[2].val.ulongval);
    }
  else
    {
      status=svc_register(tp.transport,
                          tp.program,
                          tp.version,
                          (void (*)(svc_req *, SVCXPRT *)) boilrpc_1,
                          (*args)[2].val.ulongval);
    };
  
  if (!status)
    {
      svc_destroy(tp.transport);
      setvarulong("error",1);
      setvarstring("perror","svc_register: svc_register() failed");
      return back;
    };

  back.returnval.val.longval=options->ptr_h->rpc_transports.insert(tp);
  return back;
}

int args_svc_run[]= { TYPE_VALUE_ULONG,
                      TYPE_VALUE_ULONG,
                      0 };

flowctrl func_svc_run(type_block* aktblock,opt* options,
                      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;

  fd_set readfdset=svc_fdset;
  int tsize=getdtablesize();
  timeval timeout;
  timeout.tv_sec=(*args)[0].val.ulongval;
  timeout.tv_usec=(*args)[1].val.ulongval;
  
  /* the server procedure must have this info */
  svc_run_block=aktblock;
  svc_run_options=options;

  /* wait for data */
  switch(select(tsize,
                &readfdset,
                (fd_set*) NULL,
                (fd_set*) NULL,
                &timeout))
    {
    case -1:
      {
        setvarulong("error",1);
        setvarstring("perror","svc_run: select() failed");
        break;
      };
    case 0:
      {
        back.returnval.val.longval=0;
        break;
      };
    default:
      {
        svc_getreqset(&readfdset);
        back.returnval.val.longval=1;
        break;
      };
    };
  
  return back;
}

int args_svc_unregister[]= { TYPE_VALUE_LONG,
                             0 };

flowctrl func_svc_unregister(type_block* aktblock,opt* options,
                             joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  rpc_transport tp;
  
  /* get transport */
  if (!options->ptr_h->rpc_transports.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","svc_delete: illegal transport handle");
      return back;
    };
  tp=options->ptr_h->rpc_transports.gethandle((*args)[0].val.longval);

  svc_unregister(tp.program,tp.version);
  svc_destroy(tp.transport);
  options->ptr_h->rpc_transports.del((*args)[0].val.longval);
  back.returnval.val.ulongval=1;
  return back;
}

#endif

