typedef union {

string* t0;
int t1; /* type */
type_value* t2; /* const */
type_reference* t3;
type_expr_list* t4;
type_function_call* t5;
type_expr* t6;
type_arg_list* t7;
type_function_dekl* t8;
type_dekl_list_entry* t9;
type_dekl_list* t10;
type_variable_dekl* t11;
type_expr_stmt* t12;
type_choice_stmt* t13;
type_loop_stmt* t14;
type_jump_stmt* t15;
type_stmt* t16;
type_stmt_list* t17;
type_block* t18;
type_arg_list_entry* t19;
type_eval_stmt* t20;
type_external_stmt* t21;
} YYSTYPE;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#define	LONG	258
#define	DOUBLE	259
#define	STRING	260
#define	VOID	261
#define	IF	262
#define	ELSE	263
#define	FOR	264
#define	WHILE	265
#define	DO	266
#define	BREAK	267
#define	CONTINUE	268
#define	RETURN	269
#define	UNSIGNED	270
#define	EVAL	271
#define	EXTERNAL	272
#define	OR	273
#define	AND	274
#define	EQUAL	275
#define	NOTEQUAL	276
#define	LE	277
#define	GE	278
#define	SHIFTLEFT	279
#define	SHIFTRIGHT	280
#define	PLUSPLUS	281
#define	MINUSMINUS	282
#define	NEG	283
#define	CAST	284
#define	FUNC	285
#define	CONST	286
#define	NAME	287
#define	PRINT	288


extern YYSTYPE yylval;
extern YYSTYPE yyval;
