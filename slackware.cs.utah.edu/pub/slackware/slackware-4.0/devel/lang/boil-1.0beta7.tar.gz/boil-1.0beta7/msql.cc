/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"

#ifdef WITH_MSQL

int args_msql_close[]= { TYPE_VALUE_LONG,
			 0 };

flowctrl func_msql_close(type_block* aktblock,opt* options,
			 joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  int conn;

  if (!options->ptr_h->msql_connections.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_close: illegal msql connection number");
      return back;
    };
  conn=options->ptr_h->msql_connections.gethandle((*args)[0].val.longval);

  msqlClose(conn);
  options->ptr_h->msql_connections.del((*args)[0].val.longval);
  back.returnval.val.ulongval=1;
  return back;
}

int args_msql_connect[]= { TYPE_VALUE_STRING,
			   0 };

flowctrl func_msql_connect(type_block* aktblock,opt* options,
			   joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back,call;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;
  int conn;

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_connect: string not defined");
      return back;
    };

  conn=msqlConnect((*args)[0].stringval);
  if (conn==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_connect: cannot connect");
      return back;
    };
  back.returnval.val.longval=options->ptr_h->msql_connections.insert(conn);
  return back;
}

int args_msql_selectdb[]= { TYPE_VALUE_LONG,
			    TYPE_VALUE_STRING,
			    0 };

flowctrl func_msql_selectdb(type_block* aktblock,opt* options,
			    joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back,call;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  int conn;

  if (!defined((*args)[1].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_selectdb: string not defined");
      return back;
    };

  if (!options->ptr_h->msql_connections.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_selectdb: illegal msql connection number");
      return back;
    };
  conn=options->ptr_h->msql_connections.gethandle((*args)[0].val.longval);

  if (msqlSelectDB(conn,(*args)[1].stringval)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_selectdb: msql_selectdb() failed");
      return back;
    };
  back.returnval.val.ulongval=1;
  return back;
}  


int args_msql_exec[]= { TYPE_VALUE_LONG,
			TYPE_VALUE_STRING,
			0 };

flowctrl func_msql_exec(type_block* aktblock,opt* options,
			joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back,call;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;
  int conn;
  m_result* result;

  if (!defined((*args)[1].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_exec: string not defined");
      return back;
    };

  if (!options->ptr_h->msql_connections.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_exec: illegal postgres connection number");
      return back;
    };
  conn=options->ptr_h->msql_connections.gethandle((*args)[0].val.longval);

  if (msqlQuery(conn,(*args)[1].stringval)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_exec: query failed :"+(*args)[1].stringval);
      return back;
    };
  result=msqlStoreResult();
  back.returnval.val.longval=options->ptr_h->msql_querys.insert(result);
  return back;
}  

int args_msql_freeresult[]= { TYPE_VALUE_LONG,
			      0 };

flowctrl func_msql_freeresult(type_block* aktblock,opt* options,
			      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  m_result* result;

  if (!options->ptr_h->msql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_freeresult: illegal msql result number");
      return back;
    };
  result=options->ptr_h->msql_querys.gethandle((*args)[0].val.longval);

  if (result)
    {
      msqlFreeResult(result);
    };
  options->ptr_h->msql_querys.del((*args)[0].val.longval);
  back.returnval.val.ulongval=1;
  return back;
}

int args_msql_numfields[]= { TYPE_VALUE_LONG,
			     0 };

flowctrl func_msql_numfields(type_block* aktblock,opt* options,
			     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  m_result* result;

  if (!options->ptr_h->msql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_numfields: illegal msql result number");
      return back;
    };
  result=options->ptr_h->msql_querys.gethandle((*args)[0].val.longval);

  if (result)
    {
      back.returnval.val.ulongval=(unsigned long) msqlNumFields(result);
    };
  return back;
}

int args_msql_numrows[]= { TYPE_VALUE_LONG,
			   0 };

flowctrl func_msql_numrows(type_block* aktblock,opt* options,
			   joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;
  m_result* result;

  if (!options->ptr_h->msql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_numrows: illegal msql result number");
      return back;
    };
  result=options->ptr_h->msql_querys.gethandle((*args)[0].val.longval);

  if (result)
    {
      back.returnval.val.ulongval=(unsigned long) msqlNumRows(result);
    };
  return back;
}

int args_msql_result[]= { TYPE_VALUE_LONG,
			  TYPE_VALUE_ULONG,
			  TYPE_VALUE_ULONG,
			  0 };

flowctrl func_msql_result(type_block* aktblock,opt* options,
			  joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  m_result* result;

  if (!options->ptr_h->msql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_result: illegal msql result number");
      return back;
    };
  result=options->ptr_h->msql_querys.gethandle((*args)[0].val.longval);

  if (!result)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_result: no result");
      return back;
    };

  msqlDataSeek(result,(int) (*args)[1].val.ulongval);
  m_row row=msqlFetchRow(result);
  if (!row)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_result: no result");
      return back;
    };
  if (msqlNumFields(result)<=(int) (*args)[2].val.ulongval)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_result: field index to high");
      return back;
    };
  back.returnval.stringval=row[(*args)[2].val.ulongval];
  return back;
}

int args_msql_fieldtype[]= { TYPE_VALUE_LONG,
			     TYPE_VALUE_ULONG,
			     0 };

flowctrl func_msql_fieldtype(type_block* aktblock,opt* options,
			     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=-1;
  m_result* result;

  if (!options->ptr_h->msql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_numrows: illegal msql result number");
      return back;
    };
  result=options->ptr_h->msql_querys.gethandle((*args)[0].val.longval);

  if (!result)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_fieldtype: no result");
      return back;
    };

  msqlFieldSeek(result,(int) (*args)[1].val.ulongval);
  m_field* field=msqlFetchField(result);
  if (!field)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_fieldtype: no result");
      return back;
    };

  back.returnval.val.longval=(long) field->type;
  return back;
}

int args_msql_fieldname[]= { TYPE_VALUE_LONG,
                             TYPE_VALUE_ULONG,
                             0 };

flowctrl func_msql_fieldname(type_block* aktblock,opt* options,
                             joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  m_result* result;

  if (!options->ptr_h->msql_querys.ishandle((*args)[0].val.longval))
    {
      setvarulong("error",1);
      setvarstring("perror","msql_numrows: illegal msql result number");
      return back;
    };
  result=options->ptr_h->msql_querys.gethandle((*args)[0].val.longval);

  if (!result)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_fieldname: no result");
      return back;
    };

  msqlFieldSeek(result,(int) (*args)[1].val.ulongval);
  m_field* field=msqlFetchField(result);
  if (!field)
    {
      setvarulong("error",1);
      setvarstring("perror","msql_fieldname: no result");
      return back;
    };

  back.returnval.stringval=field->name;
  return back;
}

#endif
