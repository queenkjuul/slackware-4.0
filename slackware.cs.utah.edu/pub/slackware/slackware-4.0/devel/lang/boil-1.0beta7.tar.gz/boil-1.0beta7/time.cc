/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"
 
int args_time[]= { 0 };

flowctrl func_time(type_block* aktblock,opt* options,
                   joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;

  back.returnval.val.ulongval=(unsigned long) time(NULL);
  return back;
};

int args_mktime[] = { TYPE_VALUE_ULONG,
                      TYPE_VALUE_ULONG,
                      TYPE_VALUE_ULONG,
                      TYPE_VALUE_ULONG,
                      TYPE_VALUE_ULONG,
                      TYPE_VALUE_ULONG,
                      0 };

flowctrl func_mktime(type_block* aktblock,opt* options,
                     joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_ULONG;
  back.returnval.val.ulongval=0;

  tm t;
  time_t rueck;
  int flags=PARSE_NOFATAL;

  if (parse_test_year(&t,(int) (*args)[0].val.ulongval,flags)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","mktime: year not valid");
      return back;
    };
  if (parse_test_month(&t,(int) (*args)[1].val.ulongval,flags)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","mktime: month not valid");
      return back;
     };
  if (parse_test_day(&t,(int) (*args)[2].val.ulongval,flags)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","mktime: day not valid");
      return back;
    };
  if (parse_test_hour(&t,(int) (*args)[3].val.ulongval,flags)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","mktime: hour not valid");
      return back;
    };
  if (parse_test_minute(&t,(int) (*args)[4].val.ulongval,flags)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","mktime: minute not valid");
      return back;
    };
  if (parse_test_second(&t,(int) (*args)[5].val.ulongval,flags)==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","mktime: second not valid");
      return back;
    };

  t.tm_isdst=-1;
  rueck=mktime(&t);
  if (rueck == -1)
    {
      setvarulong("error",1);
      setvarstring("perror","mktime: mktime() failed");
      return back;
    };
  back.returnval.val.ulongval=(unsigned long) rueck;
  return back;
}

int args_strftime[]= { TYPE_VALUE_STRING,
                       TYPE_VALUE_ULONG,
                       0 };

flowctrl func_strftime(type_block* aktblock,opt* options,
                       joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_STRING;
  char buf[65535];

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","strftime: string not defined");
      return back;
    };

  time_t secs=(time_t) (*args)[1].val.ulongval;
  struct tm* tim;
  tim=localtime(&secs);
  if (!tim)
    {
      setvarulong("error",1);
      setvarstring("perror","strftime: localtime() failed (huh ?)");
      return back;
    };

  if (strftime(buf,65535,(*args)[0].stringval,tim)==65535)
    {
      setvarulong("error",1);
      setvarstring("perror","strftime: return-string too big");
      return back;
    };

  back.returnval.stringval=buf;
  return back;
}

