/*
  (c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef PRIVATE_INCLUDE_general
#include "general.h"
#define PRIVATE_INCLUDE_general
#endif
#ifndef PRIVATE_INCLUDE_errorlib
#include "errorlib.h"
#define PRIVATE_INCLUDE_errorlib
#endif

void strip_sql_escape(char*);
char* str_lwr(char*);
char* str_upr(char*);
int str_cmpi(char*,char*);
int str_ncmpi(char*,char*,size_t);
char* str_ers(char*,char*,char*);
char* str_ersa(char*,char*,char*);
int str_num(char*);
int str_nnum(char*,size_t);
char* str_remret(char*);
char* str_lfret(char*);
char* tostring(int);
void streamcpy(FILE*,FILE*);
FILE* myexec(char*,char**);
int myexec1(char*,char**,FILE*&,FILE*&);
