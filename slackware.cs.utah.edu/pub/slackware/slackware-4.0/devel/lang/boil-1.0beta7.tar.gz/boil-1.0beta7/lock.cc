/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"

int args_do_lock[]= { TYPE_VALUE_STRING,
                      0 };

flowctrl func_do_lock(type_block* aktblock,opt* options,
                      joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=(-1);

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","do_lock: string not defined");
      return back;
    };

  back.returnval.val.longval=do_lock((*args)[0].stringval+".lck",LOCK_NOFATAL);
  if (back.returnval.val.longval==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","error with do_lock");
    };
  return back;
}

int args_do_unlock[]= { TYPE_VALUE_STRING,
                        0 };

flowctrl func_do_unlock(type_block* aktblock,opt* options,
                        joined_list<type_value>* args)
{
  aktblock=aktblock;options=options;args=args; /* to prevent warnings */
  flowctrl back;
  back.ctrl=FLOW_RETURN;
  back.returnval.type=TYPE_VALUE_LONG;
  back.returnval.val.longval=(-1);

  if (!defined((*args)[0].stringval))
    {
      setvarulong("error",1);
      setvarstring("perror","do_unlock: string not defined");
      return back;
    };

  back.returnval.val.longval=do_unlock((*args)[0].stringval+".lck",
                                       LOCK_NOFATAL);
  if (back.returnval.val.longval==-1)
    {
      setvarulong("error",1);
      setvarstring("perror","error with do_unlock");
    };
  return back;
}

