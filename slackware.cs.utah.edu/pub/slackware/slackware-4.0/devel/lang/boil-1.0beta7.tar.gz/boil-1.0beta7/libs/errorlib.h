/*
  (c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef PRIVATE_INCLUDE_general
#include "general.h"
#define PRIVATE_INCLUDE_general
#endif

#ifndef INCLUDE_sys_types
#include <sys/types.h>
#define INCLUDE_sys_types
#endif
#ifndef INCLUDE_sys_stat
#include <sys/stat.h>
#define INCLUDE_sys_stat
#endif
#ifndef INCLUDE_fcntl
#include <fcntl.h>
#define INCLUDE_fcntl
#endif
#ifndef INCLUDE_unistd
#include <unistd.h>
#define INCLUDE_unistd
#endif
#ifndef INCLUDE_sys_wait
#include <sys/wait.h>
#define INCLUDE_sys_wait
#endif
#ifndef INCLUDE_stdarg
#include <stdarg.h>
#define INCLUDE_stdarg
#endif
#ifndef INCLUDE_time
#include <time.h>
#include <sys/time.h>
#define INCLUDE_time
#endif
#ifndef INCLUDE_errno
#include <errno.h>
#define INCLUDE_errno
#endif


#define LOG_NOTICE 0
#define LOG_DEBUG 1
#define LOG_WARN 2
#define LOG_ERROR 3
#define LOG_FATAL 4

#define ERROR_NONE 0
#define ERROR_UNSPECIFIED 1
#define ERROR_OUT_OF_MEM 2
#define ERROR_VALUE_OUT_OF_RANGE 3
#define ERROR_WRONG_ARGUMENT 4
#define ERROR_SYNTAX_ERROR 5

#define LOG_FLAG_STDLOG 1
#define LOG_FLAG_ERRLOG 2
#define LOG_FLAG_STDERR 4
#define LOG_FLAG_STDOUT 8
#define LOG_FLAG_MAIL 16

#define LOG_FLAG_PRINT_NAME 32
#define LOG_FLAG_PRINT_POSITION 64
#define LOG_FLAG_PRINT_TIME 128
#define LOG_FLAG_PRINT_ERR 256

char* myperror();
void log(int,char*,int,int,char*,...);

extern unsigned long MAX_LOG_SIZE;
extern unsigned long LOG_FLAGS_NOTICE;
extern unsigned long LOG_FLAGS_DEBUG;
extern unsigned long LOG_FLAGS_WARN;
extern unsigned long LOG_FLAGS_ERROR;
extern unsigned long LOG_FLAGS_FATAL;
extern char* LOG_STDLOG_PATH;
extern char* LOG_ERRLOG_PATH;
extern char* LOG_MAIL_ADDRESS;
extern char* MYNAME;
extern char* SENDMAIL;
extern int debug;
extern void panic();

