/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef PRIVATE_INCLUDE_errorlib
#include "errorlib.h"
#define PRIVATE_INCLUDE_errorlib
#endif
#ifndef PRIVATE_INCLUDE_stringlib
#include "stringlib.h"
#define PRIVATE_INCLUDE_stringlib
#endif
#ifndef PRIVATE_INCLUDE_timelib
#include "timelib.h"
#define PRIVATE_INCLUDE_timelib
#endif
#ifndef PRIVATE_INCLUDE_wwwlib
#include "wwwlib.h"
#define PRIVATE_INCLUDE_wwwlib
#endif
#ifndef PRIVATE_INCLUDE_mylib
#include "mylib.h"
#define PRIVATE_INCLUDE_mylib
#endif
#ifndef PRIVATE_INCLUDE_locklib
#include "locklib.h"
#define PRIVATE_INCLUDE_locklib
#endif
#ifndef PRIVATE_INCLUDE_joined_list
#include "joined_list.cc"
#define PRIVATE_INCLUDE_joined_list
#endif
#ifndef PRIVATE_INCLUDE_dirlib
#include "dirlib.cc"
#define PRIVATE_INCLUDE_dirlib
#endif
#ifndef PRIVATE_INCLUDE_parselib
#include "parselib.h"
#define PRIVATE_INCLUDE_parselib
#endif

#ifndef INCLUDE_rpc
#ifdef WITH_RPC
#include <rpc.h>
#endif
#define INCLUDE_rpc
#endif
#ifndef INCLUDE_signal
#include <signal.h>
#define INCLUDE_signal
#endif

#ifndef INCLUDE_sys_socket
#include <sys/socket.h>
#define INCLUDE_sys_socket
#endif
#ifndef INCLUDE_netinet_in
#include <netinet/in.h>
#define INCLUDE_netinet_in
#endif
#ifndef INCLUDE_arpa_inet
#include <arpa/inet.h>
#define INCLUDE_arpa_inet
#endif
#ifndef INCLUDE_dirent
#include <dirent.h>
#define INCLUDE_dirent
#endif

#ifndef INCLUDE_libpq_fe
#ifdef WITH_POSTGRES
#include <libpq-fe.h>
#endif
#define INCLUDE_libpq_fe
#endif

#ifndef INCLUDE_msql
#ifdef WITH_MSQL
#include <msql.h>
#endif
#define INCLUDE_msql
#endif

#ifndef INCLUDE_mysql
#ifdef WITH_MYSQL
#undef IS_NOT_NULL
#include <mysql.h>
#endif
#define INCLUDE_mysql
#endif

/* some general defines */

#ifndef UNDEF
#define UNDEF 0
#endif

#ifndef NULL
#define NULL 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define MAX_LINE_SIZE 6000
#define MAX_OPTIONS 256
#define ACCOUNTING_ANZ 4
#define MAX_RPC_ARGS 100

extern int debug;
void fork_handler(pid_t);
