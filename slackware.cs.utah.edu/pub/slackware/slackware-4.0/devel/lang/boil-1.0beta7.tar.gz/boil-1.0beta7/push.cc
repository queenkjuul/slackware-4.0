#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"
#ifdef WITH_RPC
#include "rpc.h"
#endif

void type_choice_stmt::push()
{
  stmt1->push();
  if (type==TYPE_CHOICE_STMT_ELSE) { stmt2->push(); };
}

void type_loop_stmt::push()
{
  stmt->push();
  if (stmt_for) { stmt_for->push(); };
}

void type_stmt::push()
{
  switch (type)
    {
    case TYPE_STMT_BLOCK:
      {
        uptr.block->push();
        break;
      };
    case TYPE_STMT_CHOICE_STMT:
      {
        uptr.choice_stmt->push();
        break;
      };
    case TYPE_STMT_LOOP_STMT:
      {
        uptr.loop_stmt->push();
        break;
      };
    };
}

void type_block::push()
{
  type_stack_entry stke;
  stack.insert_listelem(stke);

  for (unsigned long i=0;i!=stmt_list->stmts.length();i++)
    {
      stmt_list->stmts[i].push();
    };
}
