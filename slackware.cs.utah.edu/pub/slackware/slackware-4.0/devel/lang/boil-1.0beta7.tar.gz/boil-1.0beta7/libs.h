/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

extern int args_printf[];
extern int args_sleep[];
extern int args_getenv[];
extern int args_setenv[];
extern int args_srandom[];
extern int args_random[];
extern int args_crypt[];
extern int args_waitpid[];
extern int args_sigcld[];
extern int args_getpid[];
extern int args_system[];
extern int args_time[];
extern int args_mktime[];
extern int args_strftime[];
extern int args_fileatime[];
extern int args_filemtime[];
extern int args_unlink[];
extern int args_tmpnam[];
extern int args_opendir[];
extern int args_readdir[];
extern int args_closedir[];
extern int args_mkdir[];
extern int args_rmdir[]; 
extern int args_rename[];
extern int args_cgiwrap[];
extern int args_getpost[];
extern int args_postdata[];
extern int args_file_upload[];
extern int args_htmlenc[];
extern int args_phtmlenc[];
extern int args_fullhtmlenc[];
extern int args_exit[];
extern int args_isset[];
extern int args_isfunc[];
extern int args_deletefunc[];
extern int args_deletevar[];
extern int args_parse[];
extern int args_do_lock[];
extern int args_do_unlock[];
extern int args_defined[];
extern int args_strstr[];
extern int args_strtok[];
extern int args_token[];
extern int args_strtok_esc[];
extern int args_token_esc[];
extern int args_strtolower[];
extern int args_strtoupper[];
extern int args_substr[];
extern int args_strlen[];
extern int args_escape[];
extern int args_unescape[];
extern int args_escape1[];
extern int args_unescape1[];
extern int args_textfile[];
extern int args_getchar[];
extern int args_sql_escape[];
extern int args_fopen[];
extern int args_popen[];
extern int args_exec[];
extern int args_feof[];
extern int args_fgets[];
extern int args_fputs[];
extern int args_fclose[];
extern int args_pclose[];
extern int args_fflush[];
extern int args_setoutstream[];

#ifdef WITH_POSTGRES
extern int args_pg_close[];
extern int args_pg_connect[];
extern int args_pg_exec[];
extern int args_pg_freeresult[];
extern int args_pg_numfields[];
extern int args_pg_numrows[];
extern int args_pg_fieldname[];
extern int args_pg_fieldtype[];
extern int args_pg_result[];
#endif

#ifdef WITH_MSQL
extern int args_msql_close[];
extern int args_msql_connect[];
extern int args_msql_selectdb[];
extern int args_msql_exec[];
extern int args_msql_freeresult[];
extern int args_msql_numfields[];
extern int args_msql_numrows[];
extern int args_msql_result[];
extern int args_msql_fieldtype[];
extern int args_msql_fieldname[];
#endif

#ifdef WITH_MYSQL
extern int args_mysql_close[];
extern int args_mysql_connect[];
extern int args_mysql_selectdb[];
extern int args_mysql_exec[];
extern int args_mysql_freeresult[];
extern int args_mysql_numfields[];
extern int args_mysql_numrows[];
extern int args_mysql_result[];
extern int args_mysql_fieldtype[];
extern int args_mysql_fieldname[];
#endif

extern int args_makesock[];
extern int args_closesock[];
extern int args_clnt_create[];
extern int args_clnt_timeout[];
extern int args_clnt_udp_retry[];
extern int args_clnt_destroy[];
extern int args_svc_register[];
extern int args_svc_run[];
extern int args_svc_unregister[];
extern int args_tcache_get[];
extern int args_tcache_set[];
extern int args_tcache_del[];
extern int args_tcache_setsize[];
extern int args_tcache_getsize[];

extern flowctrl func_printf(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_sleep(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_getenv(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_setenv(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_srandom(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_random(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_crypt(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_waitpid(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_sigcld(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_getpid(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_system(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_time(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_mktime(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_strftime(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_fileatime(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_filemtime(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_unlink(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_tmpnam(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_opendir(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_readdir(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_closedir(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_mkdir(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_rmdir(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_rename(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_cgiwrap(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_getpost(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_postdata(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_file_upload(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_htmlenc(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_phtmlenc(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_fullhtmlenc(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_exit(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_isset(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_isfunc(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_deletefunc(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_deletevar(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_parse(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_do_lock(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_do_unlock(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_defined(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_strstr(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_strtok(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_token(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_strtok_esc(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_token_esc(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_strtolower(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_strtoupper(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_substr(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_strlen(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_escape(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_unescape(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_escape1(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_unescape1(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_textfile(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_getchar(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_fopen(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_popen(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_exec(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_feof(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_fgets(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_fputs(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_fclose(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_pclose(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_fflush(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_setoutstream(type_block*,opt*,joined_list<type_value>*);

extern flowctrl func_pg_close(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_pg_connect(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_pg_exec(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_pg_freeresult(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_pg_numfields(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_pg_numrows(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_pg_fieldname(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_pg_fieldtype(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_pg_result(type_block*,opt*,joined_list<type_value>*);

extern flowctrl func_msql_close(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_msql_connect(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_msql_selectdb(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_msql_exec(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_msql_freeresult(type_block*,opt*,
                                     joined_list<type_value>*);
extern flowctrl func_msql_fieldtype(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_msql_fieldname(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_msql_numfields(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_msql_numrows(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_msql_result(type_block*,opt*,joined_list<type_value>*);

extern flowctrl func_mysql_close(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_mysql_connect(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_mysql_selectdb(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_mysql_exec(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_mysql_freeresult(type_block*,opt*,
                                     joined_list<type_value>*);
extern flowctrl func_mysql_fieldtype(type_block*,opt*,
				     joined_list<type_value>*);
extern flowctrl func_mysql_fieldname(type_block*,opt*,
				     joined_list<type_value>*);
extern flowctrl func_mysql_numfields(type_block*,opt*,
				     joined_list<type_value>*);
extern flowctrl func_mysql_numrows(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_mysql_result(type_block*,opt*,joined_list<type_value>*);

extern flowctrl func_sql_escape(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_makesock(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_closesock(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_clnt_create(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_clnt_timeout(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_clnt_udp_retry(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_clnt_destroy(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_svc_register(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_svc_run(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_svc_unregister(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_tcache_get(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_tcache_set(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_tcache_del(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_tcache_setsize(type_block*,opt*,joined_list<type_value>*);
extern flowctrl func_tcache_getsize(type_block*,opt*,joined_list<type_value>*);

struct libfunc
{
  string name;
  int returntype;
  flowctrl (*ptr)(type_block*,opt*,joined_list<type_value>*);
  int* argtypes;

  libfunc(string,
	  int,
	  flowctrl (*)(type_block*,opt*,joined_list<type_value>*),
	  int*);
};

extern libfunc functions[];
void instlibfunc();
void handle_cleanup(opt_h* options);




