/*
  (c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "timelib.h"

mytimer::mytimer()
{
  tv.tv_sec=0;
  tv.tv_usec=0;
}

void mytimer::gettime()
{
  struct timezone tz;

  gettimeofday(&tv,&tz);
  return;
}

mytimer::mytimer(unsigned long sec)
{
  tv.tv_sec=sec;
  tv.tv_usec=0;
  return;
}

mytimer::operator unsigned long()
{
  return (unsigned long) tv.tv_sec+(tv.tv_usec?1:0);
}

mytimer::operator bool()
{
  return (bool) tv.tv_sec || (bool) tv.tv_usec;
}

mytimer::operator char*()
{
  char buf[MAX_LINE_SIZE];
  double tim=tv.tv_sec+(((double) tv.tv_usec)/1000000);
  snprintf(buf,MAX_LINE_SIZE,"%lf",tim);
  return buf;
}

mytimer operator+(mytimer src1,mytimer src2)
{
  mytimer rueck;

  rueck.tv.tv_sec=src1.tv.tv_sec+src2.tv.tv_sec;
  rueck.tv.tv_usec=src1.tv.tv_usec+src2.tv.tv_usec;
  if (rueck.tv.tv_usec>=1000000)
    {
      rueck.tv.tv_sec++;
      rueck.tv.tv_usec-=1000000;
    };

  return rueck;
}

mytimer operator-(mytimer src1,mytimer src2)
{
  mytimer rueck;

  rueck.tv.tv_sec=src1.tv.tv_sec-src2.tv.tv_sec;
  rueck.tv.tv_usec=src1.tv.tv_usec-src2.tv.tv_usec;
  if (rueck.tv.tv_usec<0)
    {
      rueck.tv.tv_sec--;
      rueck.tv.tv_usec+=1000000;
    };

  return rueck;
}

int operator<(mytimer src1,mytimer src2)
{
  if (src1.tv.tv_sec < src2.tv.tv_sec) { return 1; };
  if (src1.tv.tv_sec==src2.tv.tv_sec)
    { return src1.tv.tv_usec < src2.tv.tv_usec; };
  return 0;
}

int operator>(mytimer src1,mytimer src2)
{
  if (src1.tv.tv_sec > src2.tv.tv_sec) { return 1; };
  if (src1.tv.tv_sec==src2.tv.tv_sec)
    { return src1.tv.tv_usec > src2.tv.tv_usec; };
  return 0;
}

int operator==(mytimer src1,mytimer src2)
{
  if (src1.tv.tv_sec==src2.tv.tv_sec)
    { return src1.tv.tv_usec==src2.tv.tv_usec; };
  return 0;
};

int operator>=(mytimer src1,mytimer src2)
{
  return src1>src2 || src1==src2;
}

int operator<=(mytimer src1,mytimer src2)
{
  return src1<=src2 || src1==src2;
}

mytimer& mytimer::operator+=(mytimer src)
{
  return *this=*this+src;
}

mytimer& mytimer::operator-=(mytimer src)
{
  return *this=*this-src;
}

