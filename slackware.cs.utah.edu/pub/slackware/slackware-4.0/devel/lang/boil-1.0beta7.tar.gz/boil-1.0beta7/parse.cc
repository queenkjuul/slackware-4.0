/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"
#ifdef WITH_RPC
#include "rpc.h"
#endif

void reset_parser()
{
  max_parse_recursions=0;
  embed=0;
  first_line=1;
  line=1;
  prg=0;
  file="";
  prgstr="";
  w="";
  w1="";
  first=1;
  last=0;
  lastchar=0;
  wtype=T_UNDEF;
}

int pgetchar()
{
  int c;

  do
    {
      if (prg) { c=fgetc(prg); } else { c=prgstr[0]; prgstr++; };
    } while (c==13); /* !(&($=)/(! */

#ifdef LINETRACK
  if (c=='\n')
    {
      line++;
#ifdef DEBUGGING
      log(LOG_DEBUG,__FILE__,__LINE__,0,"line=%lu",line);
#endif
    };
#endif

  return c;
};

void freetoken(int type,void* ptr)
{

  switch (type)
    {
    case TYPE_BLOCK:
      {
        ((type_block*) ptr)->destroy();
        delete (type_block*) ptr;
        return;
      };
    case TYPE_REFERENCE:
      {
        ((type_reference*) ptr)->destroy();
        delete (type_reference*) ptr;
        return;
      };
    case TYPE_EXPR_LIST:
      {
        ((type_expr_list*) ptr)->destroy();
        delete (type_expr_list*) ptr;
        return;
      };
    case TYPE_FUNCTION_CALL:
      {
        ((type_function_call*) ptr)->destroy();
        delete (type_expr_list*) ptr;
        return;
      };
    case TYPE_EXPR:
      {
        ((type_expr*) ptr)->destroy();
        delete (type_expr*) ptr;
        return;
      };
    case TYPE_ARG_LIST_ENTRY:
      {
        ((type_arg_list_entry*) ptr)->destroy();
        delete (type_arg_list_entry*) ptr;
        return;
      };
    case TYPE_ARG_LIST:
      {
        ((type_arg_list*) ptr)->destroy();
        delete (type_arg_list*) ptr;
        return;
      };
    case TYPE_FUNCTION_DEKL:
      {
        ((type_function_dekl*) ptr)->destroy();
        delete (type_function_dekl*) ptr;
        return;
      };
    case TYPE_DEKL_LIST_ENTRY:
      {
        ((type_dekl_list_entry*) ptr)->destroy();
        delete (type_dekl_list_entry*) ptr;
        return;
      };
    case TYPE_DEKL_LIST:
      {
        ((type_dekl_list*) ptr)->destroy();
        delete (type_dekl_list*) ptr;
        return;
      };
    case TYPE_VARIABLE_DEKL:
      {
        ((type_variable_dekl*) ptr)->destroy();
        delete (type_variable_dekl*) ptr;
        return;
      };
    case TYPE_EXPR_STMT:
      {
        ((type_expr_stmt*) ptr)->destroy();
        delete (type_expr_stmt*) ptr;
        return;
      };
    case TYPE_CHOICE_STMT:
      {
        ((type_choice_stmt*) ptr)->destroy();
        delete (type_choice_stmt*) ptr;
        return;
      };
    case TYPE_LOOP_STMT:
      {
        ((type_loop_stmt*) ptr)->destroy();
        delete (type_loop_stmt*) ptr;
        return;
      };
    case TYPE_JUMP_STMT:
      {
        ((type_jump_stmt*) ptr)->destroy();
        delete (type_jump_stmt*) ptr;
        return;
      };
    case TYPE_STMT:
      {
        ((type_stmt*) ptr)->destroy();
        delete (type_stmt*) ptr;
        return;
      };
    case TYPE_STMT_LIST:
      {
        ((type_stmt_list*) ptr)->destroy();
        delete (type_stmt_list*) ptr;
        return;
      };
    case TYPE_EVAL_STMT:
      {
        ((type_eval_stmt*) ptr)->destroy();
        delete (type_eval_stmt*) ptr;
        return;
      };
    case TYPE_EXTERNAL_STMT:
      {
        ((type_external_stmt*) ptr)->destroy();
        delete (type_external_stmt*) ptr;
        return;
      };
    default:
      {
        log(LOG_FATAL,__FILE__,__LINE__,ERROR_UNSPECIFIED,
            "freetoken: unknown type");
      };
    };

  return;
}

void freetokenstack()
{
  for (unsigned long i=0;i!=tokenstack.length();i++)
    {
      freetoken(tokenstack[i].type,tokenstack[i].ptr);
    };
  return;
}

void emptystack()
{
  while (tokenstack.length())
    {
      tokenstack.remove_listelem(0);
    };

  return;
}

void deltoken(void* ptr)
{
  for (unsigned long i=0;i!=tokenstack.length();i++)
    {
      if (tokenstack[i].ptr==ptr)
        {
          tokenstack.remove_listelem(i);
          return;
        };
    };

  log(LOG_FATAL,__FILE__,__LINE__,ERROR_UNSPECIFIED,
      "deltoken: token not found");
  return;
}

void instoken(int type,void* ptr)
{
  token t;
  t.type=type;
  t.ptr=ptr;
  tokenstack.insert_listelem(t);
  return;
}
