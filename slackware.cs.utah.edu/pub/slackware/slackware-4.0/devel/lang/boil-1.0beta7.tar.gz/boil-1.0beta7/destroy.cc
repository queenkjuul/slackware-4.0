/*
BOIL (Brunni's Own Interpreter Language)
(c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "general.h"
#include "handles.cc"
#include "boil.h"
#include "boil.tab.h"
#include "libs.h"
#ifdef WITH_RPC
#include "rpc.h"
#endif

void type_reference::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_reference");
#endif
  if (type==TYPE_REFERENCE_COMPLEX)
    {
      expr->destroy();
      delete expr;
      if (counter) { counter->destroy(); delete counter; };
    };
}

void type_function_call::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_function_call");
#endif
  reference->destroy();
  delete reference;
  expr_list->destroy();
  delete expr_list;
}

void type_expr::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_expr");
#endif

  switch (type)
    {
    case TYPE_EXPR_CONST:
      {
        delete uptr.constant;
        break;
      };
    case TYPE_EXPR_REFERENCE:
      {
        uptr.reference->destroy();
        delete uptr.reference;
        break;
      };
    case TYPE_EXPR_CAST:
      {
        expr1->destroy();
        delete expr1;
        break;
      };
    case TYPE_EXPR_FUNCTION_CALL:
      {
        uptr.function_call->destroy();
        delete uptr.function_call;
        break;
      };
    case TYPE_EXPR_ASSIGNMENT:
      {
        uptr.reference->destroy();
        delete uptr.reference;
        expr1->destroy();
        delete expr1;
        break;
      };
    case TYPE_EXPR_POSTINKREMENT:
      {
        uptr.reference->destroy();
        delete uptr.reference;
        break;
      };
    case TYPE_EXPR_POSTDEKREMENT:
      {
        uptr.reference->destroy();
        delete uptr.reference;
        break;
      };
    case TYPE_EXPR_PREINCREMENT:
      {
        uptr.reference->destroy();
        delete uptr.reference;
        break;
      };
    case TYPE_EXPR_PREDECREMENT:
      {
        uptr.reference->destroy();
        delete uptr.reference;
        break;
      };
    case TYPE_EXPR_EXPR:
      {
        expr1->destroy();
        delete expr1;
        break;
      };
    case TYPE_EXPR_OPERATOR_ONE:
      {
        expr1->destroy();
        delete expr1;
        break;
      };
    case TYPE_EXPR_OPERATOR_TWO:
      {
        expr1->destroy();
        delete expr1;
        expr2->destroy();
        delete expr2;
        break;
      };
    default:
      {
        /* not reached (hopefully) */
      };
    };

  return;

}

void type_arg_list_entry::destroy()
{
  
}

void type_function_dekl::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_function_dekl");
#endif

  reference->destroy();
  delete reference;

  if (opt_expr)
    {
      opt_expr->destroy();
      delete opt_expr;
    };

  args->destroy();
  delete args;

  if (type==TYPE_FUNC_DEKL_NORMAL)
    {
      myblock->destroy();
      delete myblock;
    }
  else if (type==TYPE_FUNC_DEKL_EVAL)
    {
      eval_stmt->destroy();
      delete eval_stmt;
    }
  else if (type==TYPE_FUNC_DEKL_EXTERNAL)
    {
      external_stmt->destroy();
      delete external_stmt;
    }
  else
    {
      /* not reached */
    };

}

void type_dekl_list_entry::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_dekl_list_entry");
#endif

  reference->destroy();
  delete reference;
  if (type==TYPE_DEKL_LIST_ENTRY_REFINIT)
    {
      expr->destroy();
      delete expr;
    };
}

void type_variable_dekl::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_variable_dekl");
#endif
  dekl_list->destroy();
  delete dekl_list;
}

void type_expr_stmt::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_expr_stmt");
#endif

  if (type==TYPE_EXPR_STMT_DEFINED)
    {
      expr->destroy();
      delete expr;
    };
}

void type_choice_stmt::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_choice_stmt");
#endif

  expr->destroy();
  delete expr;
  stmt1->destroy();
  delete stmt1;
  if (type==TYPE_CHOICE_STMT_ELSE)
    {
      stmt2->destroy();
      delete stmt2;
    };
}

void type_loop_stmt::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_loop_stmt");
#endif

  if (expr) { expr->destroy(); delete expr; };
  if (expr_for) { expr_for->destroy(); delete expr_for; };
  stmt->destroy();
  delete stmt;
  if (stmt_for) { stmt_for->destroy(); delete stmt_for; };
}

void type_jump_stmt::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_jump_stmt");
#endif

  if (type==TYPE_JUMP_STMT_RETURNVAL)
    {
      expr->destroy();
      delete expr;
    };
}

void type_eval_stmt::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_eval_stmt");
#endif
  
  expr_code->destroy();
  delete expr_code;
}

void type_external_stmt::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_external_stmt");
#endif

  expr_handle->destroy();
  delete expr_handle;
  expr_function->destroy();
  delete expr_function;
  expr_pw->destroy();
  delete expr_pw;
}

void type_stmt::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_stmt");
#endif

  switch (type)
    {
    case TYPE_STMT_VARIABLE_DEKL:
      {
        uptr.variable_dekl->destroy();
        delete uptr.variable_dekl;
        break;
      };
    case TYPE_STMT_FUNCTION_DEKL:
      {
        uptr.function_dekl->destroy();
        delete uptr.function_dekl;
        break;
      };
    case TYPE_STMT_EXPR_STMT:
      {
        uptr.expr_stmt->destroy();
        delete uptr.expr_stmt;
        break;
      };
    case TYPE_STMT_BLOCK:
      {
        uptr.block->destroy();
        delete uptr.block;
        break;
      };
    case TYPE_STMT_CHOICE_STMT:
      {
        uptr.choice_stmt->destroy();
        delete uptr.choice_stmt;
        break;
      };
    case TYPE_STMT_LOOP_STMT:
      {
        uptr.loop_stmt->destroy();
        delete uptr.loop_stmt;
        break;
      };
    case TYPE_STMT_JUMP_STMT:
      {
        uptr.jump_stmt->destroy();
        delete uptr.jump_stmt;
        break;
      };
    case TYPE_STMT_PRINT_STMT:
      {
        break;
      };
    default:
      {

        /* not reached (hopefully) */
      };
    };
}

void type_block::destroy()
{
#ifdef DEBUGGING
  log(LOG_DEBUG,__FILE__,__LINE__,0,"delete: type_block");
#endif

  stmt_list->destroy();
  delete stmt_list;

  freeopts(&new_options);
}

void type_arg_list::destroy()
{

}

void type_dekl_list::destroy()
{
  for (unsigned long i=0;i!=entrys.length();i++) { entrys[i].destroy(); };
}

void type_stmt_list::destroy()
{
  for (unsigned long i=0;i!=stmts.length();i++) { stmts[i].destroy(); };
}

void type_expr_list::destroy()
{
  for (unsigned long i=0;i!=exprs.length();i++) { exprs[i].destroy(); };
}

