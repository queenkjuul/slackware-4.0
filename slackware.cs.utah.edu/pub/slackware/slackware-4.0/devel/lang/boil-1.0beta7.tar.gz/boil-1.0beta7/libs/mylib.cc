/*
  (c) 1998 netEstate (http://www.netestate.de/, info@netestate.de),
Michael Brunnbauer & Markus Hendel, Gesellschaft fuer Netzwerkkommunikation bR
Am Bluetenanger 8, 80995 Muenchen, Germany

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mylib.h"

void strip_sql_escape(char* query)
{
  unsigned long i;

  for (i=0;i!=strlen(query);i++)
    {
      if (query[i]=='\'' || query[i]=='"' || query[i]=='\\')
        {
          query[i]=' ';
        };
    };
  return;
}

char* str_lwr(char* bla)
{
  size_t a=0;
  while (bla[a])
    {
      if (bla[a] > 64 && bla[a] < 91) { bla[a]=bla[a]+32 ;};
      a++;
    };
  return bla;
}

char* str_upr(char* bla)
{
  size_t a=0;
  while (bla[a])
    {
      if (bla[a] > 96 && bla[a] < 123) { bla[a]=bla[a]-32; };
      a++;
    };
  return bla;
}

int str_cmpi(char* a,char* b)
{
  char* c;
  char* d;
  int ret;

  c=strdup(a);
  d=strdup(b);
  if (!c || !d) { log(LOG_FATAL,__FILE__,__LINE__,ERROR_OUT_OF_MEM,NULL); };
  ret=strcmp(str_lwr(c),str_lwr(d));
  free(c);free(d);
  return ret;
}

int str_ncmpi(char* a,char* b,size_t n)
{
  char* c;
  char* d;
  int ret;

  c=strdup(a);
  d=strdup(b);
  if (!c || !d) { log(LOG_FATAL,__FILE__,__LINE__,ERROR_OUT_OF_MEM,NULL); };
  ret=strncmp(str_lwr(c),str_lwr(d),n);
  free(c);free(d);
  return ret;
}

char* str_ers(char* src,char* a,char* b)
{
  char* spei=(char*) malloc(strlen(src)+strlen(b)+1);
  char* pos=strstr(src,a);
  char* rueck;

  if (!spei) { log(LOG_FATAL,__FILE__,__LINE__,ERROR_OUT_OF_MEM,NULL); };
  spei[0]=0;
  strncat(spei,src,pos-src);
  strcat(spei,b);
  strcat(spei,pos+strlen(a));
  rueck=strdup(spei);
  if (!rueck) { log(LOG_FATAL,__FILE__,__LINE__,ERROR_OUT_OF_MEM,NULL); };
  free(spei);
  return rueck;
}

char* str_ersa(char* src,char* a,char* b)
{
  char* spei=(char*) malloc(strlen(src)+strlen(b)*strlen(src)+1);
  char* pos;
  char* rueck;

  if (!spei) { log(LOG_FATAL,__FILE__,__LINE__,ERROR_OUT_OF_MEM,NULL); };
  spei[0]=0;

  while ((pos=strstr(src,a)))
    {
      strncat(spei,src,pos-src);
      strcat(spei,b);
      src=pos+strlen(a);
    };
  strcat(spei,src);
  rueck=strdup(spei);
  if (!rueck) { log(LOG_FATAL,__FILE__,__LINE__,ERROR_OUT_OF_MEM,NULL); };
  free(spei);
  return rueck;
}

int str_num(char* src)
{
  size_t i=0;
  while (src[i])
    {
      if (src[i]<48 || src[i]>57) { return 0;};
      i++;
    };
  return 1;
}

int str_nnum(char* src,size_t n)
{
  size_t i=0;
  while (i!=n)
    {
      if (!src[i] || src[i]<48 || src[i]>57) { return 0; };
      i++;
    };
  return 1;
}

char* str_remret(char *a)
{
  size_t i=0;
  while (a[i])
    {
      if (a[i]=='\n') { a[i]=0; return a;};
      i++;
    }
  return a;
}

char* str_lfret(char *a)
{
  size_t i=0;
  while (a[i])
    { 
      if (a[i]=='\r') { a[i]=0; return a;};
      i++;
    }
  return a;
}

char* tostring(int num)
{
  char buf[MAX_LINE_SIZE];

  if (snprintf(buf,MAX_LINE_SIZE,"%i",num)==-1)
    {
      log(LOG_FATAL,__FILE__,__LINE__,ERROR_VALUE_OUT_OF_RANGE,
	  "snprintf returned -1 with number %i",num);
    };

  return buf;
}

void streamcpy(FILE* fh1,FILE* fh2)
{
  char buf[MAX_LINE_SIZE];
  while (fgets(buf,MAX_LINE_SIZE,fh1)) { fputs(buf,fh2); };
  return;
}

/* 
programm ausfuehren, rueckgabewert = stdin des programms oder 0 bei fehler
*/
FILE* myexec(char* file,char** argv)
{
  FILE* rueck;
  int fildes[2];

  /* wir oeffnen die pipe */
  if (pipe(fildes)==-1)
    {
      log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
	  "return-code -1 bei pipe()");
      return 0;
    };
  
  /* und forken */
  switch (fork())
    {
      /* was macht das kind ? */
    case 0:
      {
        if (close(STDIN_FILENO))
          {
	    log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
		"(child) return-code von close(STDIN_FILENO) != 0");
	    exit(1);
          };
        if (dup(fildes[0]) != STDIN_FILENO)
          {
	    log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
		"(child) dup(fildes[0]) != STDIN_FILENO");
	    exit(1);
          };
        if (close(fildes[0]))
          {
	    log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
		"(child) return-code von close(fildes[0]) != 0");
	    exit(1);
          };
        if (close(fildes[1]))
          {
	    log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
		"(child) return-code von close(fildes[1]) != 0");
	    exit(1);
          };
        
        /* es verwandelt sich */
	execvp(file,argv);
	log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
	    "(child) execlp ging schief, perror=%s",myperror());
	exit(1);
      };
    
    case -1:
      {
	log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
	    "fork() ging schief");
	return 0;
      };
    };
  
  /* wir oeffnen den stream */
  rueck=fdopen(fildes[1],"w");
  if (!rueck)
    {
      log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
	  "(parent) fdopen(fildes[1],\"w\") ging schief");
      return 0;
    };
  if (close(fildes[0]))
    {
      log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
	  "(parent) return-code von close(fildes[0]) != 0");
      return 0;
    };

  return rueck;
};

int myexec1(char* file,char** argv,FILE*& in,FILE*& out)
{
  int fildes1[2];
  int fildes2[2];

  if (pipe(fildes1) != 0)
    { 
      log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
          "return-code !=0 bei pipe()");
      return 0;
    };
  if (pipe(fildes2) != 0)
    { 
      log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
          "return-code !=0 bei pipe()");
      return 0;
    };

  switch(fork())
    {
    case -1:
      {
        log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
            "fork() ging schief");
        return 0;
      };
    case 0:
      {
	if(close(STDIN_FILENO) != 0)
	  {
            log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
                "(child) return-code von close(STDIN_FILENO) != 0");
            exit(1);
	  };
	if (dup(fildes1[0]) != STDIN_FILENO)
	  {
            log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
                "(child) dup(fildes[0]) != STDIN_FILENO");
            exit(1);
	  };
	if (close(fildes1[0]) != 0)
	  {
           log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
                "(child) return-code von close(fildes1[0]) != 0");
            exit(1);
	  };
	if (close(fildes1[1]) != 0)
	  {
           log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
                "(child) return-code von close(fildes1[1]) != 0");
            exit(1);
	  };
	
	if(close(STDOUT_FILENO) != 0)
	  {
            log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
                "(child) return-code von close(STDOUT_FILENO) != 0");
            exit(1);
	  };
	if (dup(fildes2[1]) != STDOUT_FILENO)
	  {
	    log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
		"(child) dup(fildes2[1]) != STDOUT_FILENO");
            exit(1);
	  };
	if (close(fildes2[1]) != 0)
	  {
	    log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
	       "(child) return-code von close(fildes2[1]) != 0");
            exit(1);
	  };
	if (close(fildes2[0]) != 0)
	  {
	    log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
		"(child) return-code von close(fildes2[0]) != 0");
            exit(1);
	  };
	
        execvp(file,argv);
        log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
            "(child) execlp ging schief");
        exit(1);
      };
    };
  
  in=fdopen(fildes1[1],"w");
  if (!in)
    {
      log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
          "(parent) fdopen(fildes[1],\"w\") ging schief");
      return 0;
    };
  if (close(fildes1[0]) != 0)
    {
      log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
          "(parent) return-code von close(fildes[0]) != 0");
      return 0;
    };
  
  out=fdopen(fildes2[0],"r");
  if (!out)
    {
      log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
          "(parent) fdopen(fildes2[0],\"r\") ging schief");
      return 0;
    };
  if (close(fildes2[1]) != 0)
    {
      log(LOG_ERROR,__FILE__,__LINE__,ERROR_UNSPECIFIED,
          "(parent) return-code von close(fildes2[1]) != 0");
      return 0;
    };

  return 1;
}
