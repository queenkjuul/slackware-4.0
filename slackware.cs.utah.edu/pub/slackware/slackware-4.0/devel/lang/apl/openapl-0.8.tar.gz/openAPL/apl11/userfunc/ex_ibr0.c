/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */

#include "apl.h"
#include "char.h"

/*
 * immediate niladic branch -- reset SI
 */

ex_ibr0()
{
   struct si *s;
   int *p;

   if(gsip == 0) error(ERR_implicit,"no suspended fn");
   if(gsip->suspended == 0) error(ERR_botch,"no suspended functions");
   gsip->suspended = 0;
   while((s = gsip) && s->suspended == 0){
      if(s->oldsp == 0 || sp < s->oldsp)
         error(ERR_botch,"stack pointer problem");
      while(sp > s->oldsp) pop();
      pop();                     /* pop off possibly bad previous result */
      ex_nilret();               /* and stick on some dummy datum */
      p = (int *)s->np->itemp;
      execute(p[*p + 1]);
      gsip = s->sip;
   }
   if(gsip == 0) {
      while(sp > stack) pop();
      longjmp(reset_env, 0);
   }
}

