/* Copyright U S WEST Advanced Technologies, Inc. (AT&T)
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */

#include <values.h>

#define MAXEXP	88	/* the largest value such that exp(MAXEXP) is OK */
#define MINdata	MINDOUBLE
#define MAXdata	MAXDOUBLE

//double	floor();
//double	fabs();
//double	ceil();
//double	log();
//double	sin();
//double	cos();
//double	atan();
//double	atan2();
//double	sqrt();
//double	exp();
//double	gamma();
