/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */

#include "apl.h"

int prolgerr;      /* Flag -- set if bad fetch in prologue 
                    * this variable is global so that fetch()
                    * is able to set it */

ex_fun()
{
   struct nlist *np;
   int *p, s;
   struct si si;

   pcp += copy(IN, pcp, &np, 1);
   if(np->itemp == 0) funcomp(np);
   p = (int *)np->itemp;
   si.sip = gsip;            /* setup new state indicator */
   gsip = &si;
   si.np = np;
   si.oldsp = 0;            /* we can add a more complicated version, later */
   si.oldpcp = pcp;
   si.funlc = 0;
   si.suspended = 0;
   prolgerr = 0;            /* Reset error flag */
   s = p[0];
   checksp();
   if(funtrace) printf("\ntrace: fn %s entered: ", np->namep);
   if (setjmp(si.env)) goto reenter;
   while(1){
      si.funlc++;
      if(funtrace) printf("\ntrace: fn %s[%d]: ", np->namep, si.funlc-1);
      execute(p[si.funlc]);
      if(si.funlc == 1){
         si.oldsp = sp;
         if (prolgerr) error(ERR_botch,"prolog problem");
      }
      if(intflg) error(ERR_interupt,"");

   reenter:
      if(si.funlc <= 0 || si.funlc >= s) {
         si.funlc = 1;      /* for pretty traceback */
         if(funtrace) printf("\ntrace: fn %s exits ", np->namep);
         execute(p[s+1]);
         gsip = si.sip;      /* restore state indicator to previous state */
         pcp = si.oldpcp;
         return;
      }
      pop();
   }
}

