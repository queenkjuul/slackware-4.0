/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */

#include "apl.h"

sichk(n)
struct nlist *n;
{
   struct si *p;

   p = gsip;
   while(p){
      if(n == p->np) error(ERR,"si damage -- type ')sic'");
      p = p->sip;
   }
}

