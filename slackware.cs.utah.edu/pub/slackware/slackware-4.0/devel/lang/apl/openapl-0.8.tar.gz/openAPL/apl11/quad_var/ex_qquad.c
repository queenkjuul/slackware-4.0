/* openAPL, Copyright (C) Branko Bratkovic 1998
 * This file is free software and is covered by the GNU General
 * Public License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * For more details see the GNU General Public License (GPL) in
 * the docs directory.
 */

#include <stdio.h>
#include "apl.h"
#include "char.h"

struct item * ex_qquad(int io)
{
int i;
struct item *p;
char *iline;

   switch ( io ) { 
   case QV_source :
      iline=(char *)alloc(LINEMAX);
      printf(S_QUOTEQUAD ":\t");
      if ( fgets(iline,LINEMAX,stdin) == NULL ) \
         error(ERR,"user input was null");
      for(i=0; iline[i] != '\n'; i++) ;
      p = newdat(CH, 1, i);
      copy(CH, iline, p->datap, i);
      aplfree(iline);
      return(p);
      break;

   case QV_sink :
      pop();
      print();
      return(0);
   }
}
