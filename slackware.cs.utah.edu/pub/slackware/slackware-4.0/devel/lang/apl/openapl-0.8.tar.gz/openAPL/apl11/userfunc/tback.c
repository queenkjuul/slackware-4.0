/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */

#include "apl.h"

/*
 * produce trace back info
 */

char *atfrom[] = {"at\t", "from\t", "", ""};

tback(flag)
{
   struct si *p;
   int i;

   p = gsip;
   i = 0;
   if(flag) i = 2;
   while(p){
      if(flag==0 && p->suspended) return;
      if (p->funlc != 1 || i){   /* skip if at line 0 */
         printf("%s%s[%d]%s\n",
            atfrom[i],
            p->np->namep,
            p->funlc - 1,
            (p->suspended ? "   *" : "")
         );
         i |= 1;
      }
      p = p->sip;
   }
}

