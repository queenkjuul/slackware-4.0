/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */

#include "apl.h"
#include "char.h"

/*
 * monadic immediate branch -- resume fn at specific line
 */

ex_ibr()
{
   struct si *s;
   if((s = gsip) == 0) error(ERR_implicit,"no suspended fn");
   ex_br();
   if(s->oldsp == 0 || sp < s->oldsp) error(ERR_botch,"stack pointer problem");
   while(sp > s->oldsp) pop();
   pop();                  /* pop off possibly bad previous result */
   ex_nilret();            /* and stick on some dummy datum */
   longjmp(s->env, 0);         /* warp out */
}

