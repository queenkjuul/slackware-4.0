/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */
#include "apl.h"
#include "opt_codes.h"

execute(s)
char *s;
{
   int i, j;
   data *dp, d;
   struct item *p, *p1;
   data (*f)();
   extern char *opname[];

   if(code_trace) code_dump(s,0);

loop:
   if(stack_trace) stack_dump();
   i = *s++;
   if(i != EOF) i &= 0377;
   lastop = i;
   if(code_trace && i >= 0) printf("   exec %s\n", opname[i]);
   switch(i) {

   default:
      error(ERR_botch,"execute - unknown operand");

   case EOF:
      return;

   case EOL:
      pop();
      goto loop;

   case COMNT:
      *sp++ = newdat(DA, 1, 0);
      goto loop;

   case ADD:
   case SUB:
   case MUL:
   case DIV:
   case MOD:
   case MIN:
   case MAX:
   case PWR:
   case LOG:
   case CIR:
   case COMB:
   case AND:
   case OR:
   case NAND:
   case NOR:
      f = exop[i];
      p = fetch2();
      p1 = sp[-2];
      ex_dscal(0, f, p, p1);
      goto loop;


   case LT:
   case LE:
   case EQ:
   case GE:
   case GT:
   case NE:
      f = exop[i];
      p = fetch2();
      p1 = sp[-2];
      ex_dscal(1, f, p, p1);
      goto loop;


   case PLUS:
   case MINUS:
   case SGN:
   case RECIP:
   case ABS:
   case FLOOR:
   case CEIL:
   case EXP:
   case LOGE:
   case PI:
   case RAND:
   case FAC:
   case NOT:
      f = exop[i];
      p = fetch1();
      if(p->type != DA) error(ERR_domain,"type not supported by function");
      dp = p->datap;
      for(i=0; i<p->size; i++) {
         *dp = (*f)(*dp);
         dp++;
      }
      goto loop;

   case MEPS:      /*   execute         */
   case MENC:      /*   monadic encode  */
   case DRHO:
   case DIOT:
   case EPS:
   case REP:
   case BASE:
   case DEAL:
   case DTRN:
   case CAT:
   case CATK:
   case TAKE:
   case DROP:
   case DDOM:
   case MDOM:
   case GDU:
   case GDUK:
   case GDD:
   case GDDK:
   case COM:
   case COM0:
   case COMK:
   case EXD:
   case EXD0:
   case EXDK:
   case ROT:
   case ROT0:
   case ROTK:
   case MRHO:
   case MTRN:
   case RAV:
   case RAVK:
   case RED:
   case RED0:
   case REDK:
   case SCAN:
   case SCANK:
   case SCAN0:
   case REV:
   case REV0:
   case REVK:
   case ASGN:
   case INDEX:
   case ELID:
   case IPROD:
   case OPROD:
   case IMMED:
   case HPRINT:
   case PRINT:
   case MIOT:
   case MIBM:
   case DIBM:
   case BRAN0:
   case BRAN:
   case FUN:
   case ARG1:
   case ARG2:
   case AUTO:
   case REST:
   case QRUN:
   case QEXEC:
   case FDEF:
   case QFORK:
   case QEXIT:
   case QWAIT:
   case QREAD:
   case QWRITE:
   case QUNLNK:
   case QRD:
   case QDUP:
   case QAP:
   case QKILL:
   case QSEEK:
   case QOPEN:
   case QCREAT:
   case QCLOSE:
   case QCHDIR:
   case QPIPE:
   case QCRP:
   case MFMT:
   case DFMT:
   case QNC:
   case NILRET:
   case LABEL:
   case SICLR:
   case SICLR0:
   case QSIGNL:
   case QFLOAT:
   case QNL:
      pcp = s;
      (*exop[i])();
      s = pcp;
      goto loop;

   case RVAL:      /* de-referenced LVAL */
      s += copy(IN, s, &p1, 1);
      if(((struct nlist *)p1)->use != DA) ex_nilret();      /* no fn rslt */
      else {
         *sp = fetch(p1);
         sp++;
      }
      goto loop;

   case NAME:
      s += copy(IN, s, sp, 1);
      sp++;
      goto loop;

   case QUOT:
      j = CH;
      goto con;

   case CONST:
      j = DA;

   con:
      i = *s++;
      p = newdat(j, i==1?0:1, i);
      s += copy(j, s, p->datap, i);
      *sp++ = p;
      goto loop;

   case QUAD:
   case QQUAD:
   case QLX:
   case QAV:
   case QTS:
   case QPP:
   case QPW:
   case QCT:
   case QIO:
      p = newdat(QV, 0, 0);
      p->index = i; /* index is used to hold opcode which 
                     * is the case variable i at this point */
      *sp++ = p;
      goto loop;

   }
}
