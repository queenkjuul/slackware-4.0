/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */
#include "apl.h"

ex_dscal(m, f, p1, p2)
int (*f)();
struct item *p1, *p2;
{
   if(p1->type != p2->type) error(ERR_domain,"dscal - types do not match");
   if(p1->type == CH ) {
      if(m) ex_cdyad(f, p1, p2);
      else error(ERR,"dscal - type panic");
   }
   else ex_ddyad(f, p1, p2);
}

