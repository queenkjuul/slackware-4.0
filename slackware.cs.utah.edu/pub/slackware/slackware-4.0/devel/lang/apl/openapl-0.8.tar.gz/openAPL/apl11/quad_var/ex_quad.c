/* openAPL, Copyright (C) Branko Bratkovic 1998
 * This file is free software and is covered by the GNU General
 * Public License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * For more details see the GNU General Public License (GPL) in
 * the docs directory.
 */

#include <stdio.h>
#include "apl.h"
#include "char.h"

struct item * ex_quad(io)
int io; /* 0 = source, 1 = sink */
{
char *i,*c,*iline;
struct item *p;

   if ( io == 0 ) { 
      do {
         printf(S_QUAD ":\t");
         iline=(char *)alloc(LINEMAX);
         if ( fgets(iline,LINEMAX,stdin) == NULL ) error(ERR,"no user input");
         c = compile(iline, 1);
         aplfree(iline);
      } while ( c == 0 ); /* do it at least once */
      i = pcp;
      execute(c);
      pcp = i;
      aplfree(c);
      p = *--sp;
      return(p);
   } else {
      pop();
      ex_print();
      return(0);
   };
}
