#! /bin/sh
# Site specific configuration file for openAPL
# This file should be sourced by apl11, apl2gs and apl2epson
# examine these to discover the available options.
# DO NOT include statements in this file that would write to stdout
# because it would appear in the output from the print filters 
# apl2gs and apl2epson !


