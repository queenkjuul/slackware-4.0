/* Use GNU readline routine to get a line of user input */
/* Read a string, and return a pointer to it.  Returns NULL on EOF. */
#include <stdio.h>

/* A static variable for holding a line of user input */
static char *line_read = (char *)NULL;

int
rl_gets(user_input,maxLength)
     char *user_input;
     int maxLength;
{
  int Length;
  char *readline();
  /* If the buffer has already been allocated, return the memory
     to the free pool. */
  if (line_read)
    {
      free (line_read);
      line_read = (char *)NULL;
    }
  
  /* Get a line from the user. */
  line_read = readline ("\t");
  
  if (line_read == NULL) return(0); /* EOF */

  add_history (line_read);

  Length=strlen(line_read);
  /* printf("Length=%d : %s\n",Length,line_read); */
  if (Length>maxLength-2) {
    printf("input truncated to %d characters\n",maxLength-2);
    Length=maxLength-2;
  }
  strncpy(user_input,line_read,Length);
  user_input[Length]='\n';
  user_input[Length+1]='\0';

  /* printf("Length=%d : %s",Length,user_input); */

  return(Length+1);
}
