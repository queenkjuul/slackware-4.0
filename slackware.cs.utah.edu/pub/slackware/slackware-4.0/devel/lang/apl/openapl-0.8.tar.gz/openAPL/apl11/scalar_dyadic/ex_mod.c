/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */
 
#include "apl.h"
#include <math.h>

data
ex_mod(d1, d2)
data d1, d2;
{
   double f;

   /* x mod 0 is defined to be x */
   if (d1 == zero) return(d2);
   if(d1 < zero) d1 = -d1;
   f = d2;
   d2 = d2 - d1 * floor(f/d1);
   return(d2);
}

