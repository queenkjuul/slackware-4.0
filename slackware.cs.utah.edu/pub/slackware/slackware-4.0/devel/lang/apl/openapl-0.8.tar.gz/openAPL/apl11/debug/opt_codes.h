/* Interpreter Op Codes */

#define ADD	1
#define PLUS	2
#define SUB	3
#define MINUS	4
#define MUL	5
#define SGN	6
#define DIV	7
#define RECIP	8
#define MOD	9
#define ABS	10
#define MIN	11
#define FLOOR	12
#define MAX	13
#define CEIL	14
#define PWR	15
#define EXP	16
#define LOG	17
#define LOGE	18
#define CIR	19
#define PI	20
#define COMB	21
#define FAC	22

#define DEAL	23
#define RAND	24
#define DRHO	25
#define MRHO	26
#define DIOT	27
#define MIOT	28
#define ROT0	29
#define REV0	30
#define DTRN	31
#define MTRN	32
#define DIBM	33
#define MIBM	34

#define GDU	35
#define GDUK	36
#define GDD	37
#define GDDK	38
#define EXD	39
#define SCAN	40
#define EXDK	41
#define SCANK	42
#define IPROD	43
#define OPROD	44
#define QUAD	45
#define QQUAD	46
#define BRAN0	47
#define BRAN	48
#define DDOM	49
#define MDOM	50

#define COM	51
#define RED	52
#define COMK	53
#define REDK	54
#define ROT	55
#define REV	56
#define ROTK	57
#define REVK	58
#define CAT	59
#define RAV	60
#define CATK	61
#define RAVK	62

#define PRINT	63
#define QUOT	64
#define ELID	65
#define CQUAD	66
#define COMNT	67
#define INDEX	68
#define HPRINT	69

#define LT	71
#define LE	72
#define GT	73
#define GE	74
#define EQ	75
#define NE	76
#define AND	77
#define OR	78
#define NAND	79
#define NOR	80
#define NOT	81
#define EPS	82
#define MEPS	83
#define REP	84
#define TAKE	85
#define DROP	86
#define ASGN	88
#define IMMED	89

#define NAME	90
#define CONST	91
#define FUN	92
#define ARG1	93
#define ARG2	94
#define AUTO	95
#define REST	96

#define COM0	97
#define RED0	98
#define EXD0	99
#define SCAN0	100
#define BASE	101
#define MENC	102	/* monadic encode */
#define LABEL	103	/* statement label */

#define	QLX	105	/* Quad Latent eXpression */
#define	QAV	106	/* Quad Atomic Vector */
#define	QTS	107	/* Quad Time Stamp */
#define	QPP	108	/* Quad Print Precision */
#define	QPW	109	/* Quad Print Width */
#define	QCT	110	/* Quad Comparison Tolerance */
#define QIO	111	/* Quad Index Origin */

#define QRUN	112
#define QFORK	113
#define QWAIT	114
#define QEXEC	115
#define FDEF	116
#define QEXIT	117
#define QPIPE	118
#define QCHDIR	119
#define QOPEN	120
#define QCLOSE	121
#define QREAD	122
#define QWRITE	123
#define QCREAT	124
#define QSEEK	125
#define QUNLNK	126
#define QRD	127
#define QDUP	128
#define QAP	129
#define QKILL	130
#define QCRP	131
#define DFMT	132
#define MFMT	133
#define QNC	134
#define NILRET	135

#define SICLR   137
#define SICLR0  138
#define RVAL	139
#define QSIGNL  140
#define QFLOAT  141	/* Float character string to data */
#define QNL     142	/* Produce namelist */

/* System Command op-codes */
#define	CLEAR	1

#define EDIT	3
#define ERASE	4
#define FNS	5

#define READ	7

#define VARS	9

#define DEBUG	11
#define OFF	12
#define LOAD	13
#define SAVE	14
#define COPY	15
#define CONTIN	16
#define LIB	17
#define DROPC	18

#define SCRIPT	20
#define DELL	21	/* not a system command at all
			 * but the immediate token for
			 * function editing */
#define TRACE	22
#define UNTRACE	23
#define WRITE	24
#define SICLEAR	25
#define SICOM	26
#define CODE	27

#define SHELL	29
#define LIST	30
#define PRWS	31
#define MEMORY	32

