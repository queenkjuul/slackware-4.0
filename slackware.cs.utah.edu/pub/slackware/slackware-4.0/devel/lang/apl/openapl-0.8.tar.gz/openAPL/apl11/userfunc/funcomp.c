/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */

#include <stdio.h>
#include "apl.h"
#include "opt_codes.h"

/*
 * funcomp - compile functions
 * during run time, a user defined function is invoked and
 * compiled before being executed.
 *
 * It uses a mix of buffered and nonbuf IO.
 *
 */

data lnumb;
char *labcpp,*labcpe;

funcomp(np)
struct nlist *np;
{
   char *a, *c, labp[MAXLAB*20], labe[MAXLAB*4];
   int  *p, i, err, size;
   char	*iline, *status;
   FILE *infile;

   infile = fdopen(wfile,"r");
   err=fseek(infile, (long)np->label, 0);
   if ( err != 0 ) error(ERR_implicit,"Could not find function in workspace");
   size = 0;
   err = 0;
   lineNumber = 0;
   labgen = 0;

pass1:
/* printf("pass 1 \n"); */
   iline=alloc(LINEMAX);
   status=fgets(iline,LINEMAX,infile);
   lineNumber++;
   if ( 0 == strcmp(iline,(char *)&"") ) { 
      if (status == NULL ) goto out;
      p = (int *)alloc((size+2)*SINT);
      p[0] = size;
      size = 0;
      fseek(infile, (long)np->label, 0);
      lineNumber = 0;
      err++;
      labcpp = labp;
      labcpe = labe;
      labgen = 1;
      goto pass2;
   }
   c = compile(iline, size==0? 3: 5);
   size++;
   aplfree(iline);
   if(c == 0) {
      err++;
      goto pass1;
   }
   aplfree(c);
   goto pass1;

pass2:
/* printf("pass 2 \n"); */
   iline=alloc(LINEMAX);
   status=fgets(iline,LINEMAX,infile);
   lineNumber++;
   if ( 0 == strcmp(iline,(char *)&"") ) goto pass3;
   lnumb = size;
   c = compile(iline, size==0? 3: 5);
   size++;
   aplfree(iline);
   if(c == 0) goto out;
   p[size] = c;
   goto pass2;

pass3:
/* printf("pass 3 \n"); */
   labgen = 0;
   fseek(infile, (long)np->label, 0);
   lineNumber = 0;
   iline=alloc(LINEMAX);
   status=fgets(iline,LINEMAX,infile);
   lineNumber++;
   if ( 0 == strcmp(iline,(char *)&"") ) {
      err++;
      goto out;
   }
   c = compile(iline, 4);
   aplfree(iline);
   if(c == 0) goto out;
   if(labcpp != labp){
      reverse(labe);
      p[size+1] = catcode(labe, c);
      aplfree(c);

      /*      *** KLUDGE ***
      /*
      /* due to the "line-at-a-time" nature of the parser,
      /* we have to screw around with the compiled strings.
      /*
      /* At this point, we have:
      /*
      /* fn-prologue (p[1]):      <AUTOs and ARGs>, ELID, EOF
      /* label-prologue (labp):   <AUTOs and LABELs>, EOF
      /* 
      /* and we want to produce:
      /* 
      /* fn-prologue (p[1]):   <AUTOs and ARGs>,<AUTOs and LABELs>,  ELID, EOF.
       */
      a = csize(p[1]) - 1;
      c = csize(labp) - 1;
      /*
       * if there is an ELID at the end of the fn-prologue,
       * move it to  the end of the label-prologue.
       */

      if (((struct chrstrct *)p[1])->c[(int)a-1] == ELID) {
         ((struct chrstrct *)p[1])->c[(int)a-1] = EOF;
         labp[(int)c] = ELID;
         labp[(int)c+1] = EOF;
      }
      else error(ERR_botch,"elid");
      /* *** END KLUDGE *** */

      a = p[1];
      p[1] = catcode(a,labp);
      aplfree(a);
   }
   else p[size+1] = c;
   if(code_trace) {
      code_dump(p[1], 1);
      code_dump(p[size+1], 1);
   }
   np->itemp = (struct item *)p;
   err = 0;

out:
   close(infile);
   if (err) {
      if (np->namep) printf("in function %s\n", np->namep);
      error(ERR_implicit,"");
   }
}

