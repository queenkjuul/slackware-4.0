/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */

#include "apl.h"

ex_meps()
/* monadic epsilon */
{
    struct item *p;
    int i, j, dim0, dim1;
    char *a, *b,*c, *xpcp;

   p = fetch1();
   if ( p->rank > 2 ) error(ERR_rank,"");
   if ( p->type != CH ) error(ERR_domain,"not a literal value");
   /*get out if nothing to do, apr 2-23-77 */
   if (p->size == 0) return;
   b = (char *)p->datap;
   dim0 = p->rank < 2 ? 1       : p->dim[0];
   dim1 = p->rank < 2 ? p->size : p->dim[1];
   a = alloc ( dim1+1 );
   xpcp = pcp;
   for ( i=0; i<dim0 ; i++) {
      copy(CH, b, a, dim1);
      a[dim1] = '\n';
      c = compile(a,1);
      if(c != 0){
         execute(c);
         aplfree(c);
      }
      else {
         aplfree(a);
         error(ERR_implicit,"");
      }
      b += dim1;
      if(i < dim0-1) pop();
   }
   aplfree(a);
   pcp = xpcp;
   p = *--sp;
   pop();
   *sp++ = p;
}
