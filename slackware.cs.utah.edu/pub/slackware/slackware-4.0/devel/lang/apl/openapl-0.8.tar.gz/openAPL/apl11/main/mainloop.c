/* Copyright U S WEST Advanced Technologies, Inc.
 * You may use, copy, modify and sublicense this Software
 * subject to the conditions expressed in the file "License".
 */
#include <signal.h>
#include <stdio.h>
#include "apl.h"

mainloop()
{
   char *iline, *comp;
   int lineLength;

   comp = 0;
/*   iline=malloc(LINEMAX); */
/* hidden, converting to global variable user_input */

   setexit();
   while(1){
      if (comp) {
         aplfree(comp);
         comp = 0;
      }
      lineNumber = -1;
      if(echoflg) echoflg = 1;   /* enabled echo echo suppress off */
      checksp();
      if(intflg) error(ERR_interupt,"");

      /* prompt for next line of input */
      putchar('\t');
      
      /*  get a line of input */
      lineLength=fgets(&user_input,LINEMAX,stdin);

      /* fgets will return NULL at eof but only if input is not
       * from the keyboard.  The following will cause an exit
       * when input is from a file or a pipe
       */
      if (lineLength == NULL ) Exit(0);

      if (echoflg)  printf(&user_input);

      /* compile the input */
      sandbox=sandboxflg;
      comp = compile(&user_input, 0);
      if(comp == 0) continue;

      /* execute the compiled pseudo code */
      column=0;	/* prepare to print the results */
      execute(comp);

      /* note that if the execute errors out, then
       * the allocated space pointed to by comp is never
       * freed.  This is hard to fix.
       */
   }
}

