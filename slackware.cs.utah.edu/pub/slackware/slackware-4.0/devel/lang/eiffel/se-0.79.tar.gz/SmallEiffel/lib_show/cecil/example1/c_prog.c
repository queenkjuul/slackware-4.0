#include <stdio.h>
#include "eiffel.h"

c_prog (void* eiffel_string) {
  STRING_extend(eiffel_string,'H');
  STRING_extend(eiffel_string,'i');
  STRING_extend(eiffel_string,'\n');
}
