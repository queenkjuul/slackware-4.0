#include <stdio.h>
#include "eiffel.h"

int c_prog (int i1, int i2) {
  return integer_plus(i1,i2);
}


