#include <stdio.h>
#include "eiffel.h"

c_prog (void *root_object) {
  Eiffel_show_values(root_object);
}


