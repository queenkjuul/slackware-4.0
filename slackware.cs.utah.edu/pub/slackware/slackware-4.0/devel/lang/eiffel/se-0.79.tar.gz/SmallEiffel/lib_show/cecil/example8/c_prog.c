#include <stdio.h>
#include "eiffel.h"

void* c_prog (void*c_factory) {
  return string_make(c_factory,3);
}
