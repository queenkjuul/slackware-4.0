#define M_EXIT       101
#define M_COPY       201
#define M_PASTE      202
#define M_STATUS     301
#define M_ABOUT      900
#define M_COPYRIGHT  901
