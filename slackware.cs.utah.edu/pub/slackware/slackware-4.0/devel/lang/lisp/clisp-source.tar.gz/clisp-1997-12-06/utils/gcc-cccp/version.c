char *version_string = "1.42";
