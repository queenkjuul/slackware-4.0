#include <exec/types.h>

/* This should really be kept this way for everything but CLISP */

BOOL _CLISP_glue = FALSE;
