/* Tiny GCC Library
 * Bruno Haible 12.4.1997
 */

#include <stdlib.h>

/*
 * Believe it or not - this *is* an ANSI C compliant implementation of malloc().
 */

void* malloc (size_t n)
{
  return (void*)0;
}

void free (void* ptr)
{
}

