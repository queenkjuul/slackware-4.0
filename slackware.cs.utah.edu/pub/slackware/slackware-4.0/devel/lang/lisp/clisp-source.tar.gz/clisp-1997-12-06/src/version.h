/* Generated automatically from src/VERSION. */
#define VERSION "1997-12-06"
#define VERSION_YYYY 1997
#define VERSION_YYYY_STRING "1997"
#define VERSION_MM 12
#define VERSION_DD 6
