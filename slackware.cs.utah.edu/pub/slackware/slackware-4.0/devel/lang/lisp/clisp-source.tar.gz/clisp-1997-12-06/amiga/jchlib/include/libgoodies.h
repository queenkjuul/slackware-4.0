/* Tiny GCC Library
 * libgoodies.h
 * J�rg H�hle, 19-Sept-94
 */
LONG BPTRfprintf(BPTR, char *, ...);
LONG setmode(BPTR, long);	/* SetMode() for 2.0 and below */
