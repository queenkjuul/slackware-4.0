#import <appkit/appkit.h>

@interface LispPreferencesPanel:Panel
{
    id  coordinator;
}

- changeFont:sender;

@end
