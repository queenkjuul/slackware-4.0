/* Tiny GCC Library
 * string.h
 * J�rg H�hle, 13-Jul-94
 */

#ifndef _STRING_H_
#define _STRING_H_

int strlen (const char *);

#endif /* ! _STRING_H_ */
