"This is CLISP, a Common Lisp implementation." CRLFstring
"" CRLFstring
"Authors: Bruno Haible, Michael Stoll." CRLFstring
"Features: Interpreter, compiler, CLOS." CRLFstring
"" CRLFstring
"Language Reference:" CRLFstring
"  Guy L. Steele Jr.:" CRLFstring
"  Common Lisp - The Language." CRLFstring
"  Digital Press." CRLFstring
"  CLtL1 : 1. edition 1984, 465 pages." CRLFstring
"  CLtL2 : 2. edition 1990, 1032 pages." CRLFstring
"also available in HTML form from" CRLFstring
"  ftp ftp.cs.cmu.edu:" CRLFstring
"      /user/ai/lang/lisp/doc/cltl/cltl_ht.tgz" CRLFstring
"  ftp ma2s2.mathematik.uni-karlsruhe.de:" CRLFstring
"      /pub/lisp/CLtL2/cltl_ht.tgz" CRLFstring
"" CRLFstring
"CLISP implements CLtL1 and parts of CLtL2." CRLFstring
"" CRLFstring
"The newest versions will always be available" CRLFstring
"via anonymous ftp from" CRLFstring
"ma2s2.mathematik.uni-karlsruhe.de [129.13.115.2]," CRLFstring
"directory /pub/lisp/clisp/." CRLFstring
"Another ftp site carrying CLISP is" CRLFstring
"ftp.cs.cmu.edu [128.2.206.173]," CRLFstring
"directory user/ai/lang/lisp/impl/clisp/." CRLFstring
"" CRLFstring
"There is a mailing list for users of CLISP. It is" CRLFstring
"the proper forum for questions about CLISP, installation" CRLFstring
"problems, bug reports, application packages etc." CRLFstring
"For information about the list and how to subscribe" CRLFstring
"it, send mail to listserv@ma2s2.mathematik.uni-karlsruhe.de," CRLFstring
"with the two lines" CRLFstring
"          help" CRLFstring
"          information clisp-list" CRLFstring
"in the message body." CRLFstring
