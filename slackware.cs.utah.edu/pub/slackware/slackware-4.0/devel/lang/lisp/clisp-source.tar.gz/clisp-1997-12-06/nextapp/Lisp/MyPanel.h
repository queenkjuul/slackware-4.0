#import <appkit/appkit.h>

@interface MyPanel:Panel
{
}

@end
