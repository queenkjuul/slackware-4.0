#include <exec/types.h>

#ifdef SUPPORT_1_3
UBYTE _WDefName13[] = "CON:0/11/640/186/Program-console";
#endif
UBYTE _WDefName[] =  "CON:0/11//186/Program-console/CLOSE/AUTO/WAIT";
