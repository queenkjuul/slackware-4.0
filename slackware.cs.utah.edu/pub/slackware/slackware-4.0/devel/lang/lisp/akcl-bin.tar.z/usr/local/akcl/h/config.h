#define MP386
#include "att.h"
#include "386.h"

#undef exec
#undef a_text
#undef a_data
#undef a_bss

#undef MAXPAGE
#define MAXPAGE 7000
#define	IEEEFLOAT
  
#define I386

#define ADDITIONAL_FEATURES \
		     ADD_FEATURE("I386"); ADD_FEATURE("SYSTEM-V")
  
#undef SET_REAL_MAXPAGE  
#define SET_REAL_MAXPAGE \
	real_maxpage= ulimit(3)/PAGESIZE; \
	if (real_maxpage > MAXPAGE) \
		real_maxpage = MAXPAGE;

/* include some low level routines for maxima */
/*#define CMAC*/

#undef NEED_GETWD
/*  FIONREAD not supported */
#undef  LISTEN_FOR_INPUT
#undef HAVE_AOUT
#define HAVE_AOUT <a.out.h>
#undef MEM_SAVE_LOCALS
#define MEM_SAVE_LOCALS	\
  struct exec header;\
  int stsize

#undef READ_HEADER
#define READ_HEADER 	fread(&header, sizeof(header), 1, original); \
	data_begin=(char *)N_DATADDR(header);\
	data_end = core_end; \
	original_data = header.a_data; \
	header.a_data = data_end - data_begin; \
	header.a_bss = 0; \
	fwrite(&header, sizeof(header), 1, save);

#undef FILECPY_HEADER
#define FILECPY_HEADER \
	filecpy(save, original, header.a_text - sizeof(header));

#undef COPY_TO_SAVE
#define  COPY_TO_SAVE \
  filecpy(save, original, header.a_syms+header.a_trsize+header.a_drsize); \
  fread(&stsize, sizeof(stsize), 1, original); \
  fwrite(&stsize, sizeof(stsize), 1, save); \
filecpy(save, original, stsize - sizeof(stsize))


#undef SET_REAL_MAXPAGE
#define SET_REAL_MAXPAGE real_maxpage = MAXPAGE ;\
     	getrlimit(RLIMIT_DATA, &data_rlimit); \
	real_maxpage = ((unsigned int)&etext + data_rlimit.rlim_cur)/PAGESIZE; \
	if (real_maxpage > MAXPAGE) \
		real_maxpage = MAXPAGE
     
#undef ROUND_UP_SBRK
#define ROUND_UP_SBRK(x)  \
       do {int i; \
	     if (i = ((int)x & (PAGESIZE - 1))) \
	       x=sbrk(PAGESIZE - i); } while(0);

#undef FIX_RANDOM_SBRK
#define FIX_RANDOM_SBRK \
do {char *x=sbrk(0); \
  if (core_end != x) \
   { ROUND_UP_SBRK(x); x=sbrk(0);\
     while (core_end < x) \
       { type_map[page(core_end)]= t_other; \
	 core_end = core_end + PAGESIZE;} \
     if (core_end !=x) error("Someone allocated my memory");}} while (0)
 

#undef INIT_ALLOC     
#define INIT_ALLOC \
     	heap_end = sbrk(0); ROUND_UP_SBRK(heap_end);\
	heap_end = core_end = sbrk(0);

#undef IF_ALLOCATE_ERR
#define IF_ALLOCATE_ERR \
        FIX_RANDOM_SBRK; \
	if (core_end != sbrk(PAGESIZE*(n - m)))

#undef SYM_EXTERNAL_P
#define SYM_EXTERNAL_P(sym) ((sym)->n_type & N_EXT)
     

#undef LD_COMMAND
#define LD_COMMAND(command,main,start,input,ldarg,output) \
  sprintf(command, "ld -d -N -x -A %s -T %x %s %s -o %s", \
            main,start,input,ldarg,output)

#undef SYM_UNDEF_P
#define SYM_UNDEF_P(sym) ((N_SECTION(sym)) == N_UNDEF)
#undef NUM_AUX
#define NUM_AUX(sym) 0

       /* the section like N_ABS,N_TEXT,.. */


/* Begin for cmpinclude */


/* End for cmpinclude */
#define UNIXSAVE "unexec.c"
#define NO_REMAP
#define RELOC_FILE "rel_sun3.c"
#define CMAC
