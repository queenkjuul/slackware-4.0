
static L1();
static L2();
static L3();
static L4();
static L5();
#define VC1
#define VM1 4
static char * VVi[5]={
#define Cdata VV[4]
(char *)(&L1),
(char *)(&L2),
(char *)(&L3),
(char *)(&L4),
(char *)(&L5)
};
#define VV ((object *)VVi)
static  LnkT2() ;
static  (*Lnk2)() = LnkT2;
static  LnkT1() ;
static  (*Lnk1)() = LnkT1;
static  LnkT0() ;
static  (*Lnk0)() = LnkT0;
