/*---------------------------------------------------------------------*/
/*   A pratical implementation for the Scheme programming language     */
/*                                                                     */
/*                                    ,--^,                            */
/*                              _ ___/ /|/                             */
/*                          ,;'( )__, ) '                              */
/*                         ;;  //   L__.                               */
/*                         '   \\   /  '                               */
/*                              ^   ^                                  */
/*                                                                     */
/*   Copyright (c) 1992-1999 Manuel Serrano                            */
/*                                                                     */
/*     Bug descriptions, use reports, comments or suggestions are      */
/*     welcome. Send them to                                           */
/*       bigloo-request@kaolin.unice.fr                                */
/*       http://kaolin.unice.fr/bigloo                                 */
/*                                                                     */
/*   This program is free software; you can redistribute it            */
/*   and/or modify it under the terms of the GNU General Public        */
/*   License as published by the Free Software Foundation; either      */
/*   version 2 of the License, or (at your option) any later version.  */
/*                                                                     */
/*   This program is distributed in the hope that it will be useful,   */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of    */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     */
/*   GNU General Public License for more details.                      */
/*                                                                     */
/*   You should have received a copy of the GNU General Public         */
/*   License along with this program; if not, write to the Free        */
/*   Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,   */
/*   MA 02111-1307, USA.                                               */
/*---------------------------------------------------------------------*/
/*=====================================================================*/
/*    serrano/prgm/project/bigloo/runtime/Clib/cunicode.c              */
/*    -------------------------------------------------------------    */
/*    Author      :  Manuel Serrano                                    */
/*    Creation    :  Mon May 19 17:47:11 1997                          */
/*    Last change :  Sun Oct  4 13:57:44 1998 (serrano)                */
/*    -------------------------------------------------------------    */
/*    Unicode strings handling                                         */
/*=====================================================================*/
#include <string.h>
#include <bigloo2.0a.h>

/*---------------------------------------------------------------------*/
/*    Importations                                                     */
/*---------------------------------------------------------------------*/
extern bool_t ucs2_lower( ucs2_t );
extern char *integer_to_string();
extern char *real_to_string();
extern obj_t make_string();

/*---------------------------------------------------------------------*/
/*    ucs2_string_t                                                    */
/*    make_ucs2_string ...                                             */
/*---------------------------------------------------------------------*/
obj_t
make_ucs2_string( long len, ucs2_t c )
{
   obj_t   string;
   ucs2_t *cstring;

   if( len < 0 )
      FAILURE( string_to_bstring( "make-ucs2-string" ),
	       string_to_bstring( "Illegal string size" ),
	       BINT( len ) );
   {
      long i;
      
      string  = GC_MALLOC_ATOMIC( UCS2_STRING_SIZE + len );
      cstring = (&(string->ucs2_string_t.char0));

      string->ucs2_string_t.header = MAKE_HEADER( UCS2_STRING_TYPE, 0 );
      string->ucs2_string_t.length = len;

      for( i = 0; i < len; i++ )
	cstring[ i ] = c;
      cstring[ i ] = (ucs2_t)0;
		
      return BUCS2STRING( string );
   }
}

/*---------------------------------------------------------------------*/
/*    void                                                             */
/*    ucs2cpy ...                                                      */
/*---------------------------------------------------------------------*/
void
ucs2cpy( ucs2_t *u1, ucs2_t *u2, long len )
{
   for( len--; len >= 0; len-- )
      u1[ len ] = u2[ len ];
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_append ...                                           */
/*---------------------------------------------------------------------*/
obj_t
ucs2_string_append( obj_t s1, obj_t s2 )
{
   long    l1, l2;
   obj_t   ucs2_string;
   
   l1 = UCS2_STRING( s1 ).length;
   l2 = UCS2_STRING( s2 ).length;
	
   ucs2_string = GC_MALLOC_ATOMIC( UCS2_STRING_SIZE + l1 + l2 );

   ucs2_string->ucs2_string_t.header = MAKE_HEADER( UCS2_STRING_TYPE, 0 );
   ucs2_string->ucs2_string_t.length = l1 + l2;

   ucs2cpy( &(ucs2_string->ucs2_string_t.char0),
	    &UCS2_STRING_REF( s1, 0 ),
	    l1 );
   ucs2cpy( &((ucs2_t *)(&(ucs2_string->ucs2_string_t.char0)))[ l1 ],
	    &UCS2_STRING_REF( s2, 0 ),
	    l2 );
   ((ucs2_t *)(&(ucs2_string->ucs2_string_t.char0)))[ l1 + l2 ] = (ucs2_t)0;
	
   return BUCS2STRING( ucs2_string );
}
 
/*---------------------------------------------------------------------*/
/*    c_subucs2_string ...                                             */
/*---------------------------------------------------------------------*/
obj_t
c_subucs2_string( src_ucs2_string, min, max )
obj_t src_ucs2_string;
long  min, max;
{
   long  len;
   obj_t dst_ucs2_string;
   
   len = max - min;

   dst_ucs2_string = GC_MALLOC_ATOMIC( UCS2_STRING_SIZE + len );

   dst_ucs2_string->ucs2_string_t.header = MAKE_HEADER( UCS2_STRING_TYPE, 0 );
   dst_ucs2_string->ucs2_string_t.length = len;

   ucs2cpy( &(dst_ucs2_string->ucs2_string_t.char0),
	    &UCS2_STRING_REF( src_ucs2_string, min ),
            len );
   (&(dst_ucs2_string->ucs2_string_t.char0))[ len ] = (ucs2_t)0;

   return BUCS2STRING( dst_ucs2_string );
}

/*---------------------------------------------------------------------*/
/*    obj_t                                                            */
/*    c_ucs2_string_copy ...                                           */
/*---------------------------------------------------------------------*/
obj_t
c_ucs2_string_copy( obj_t src )
{
   long    len = UCS2_STRING_LENGTH( src );
   obj_t   string;
   ucs2_t *cstring, *cstr;
   long    i;

   string  = GC_MALLOC_ATOMIC( UCS2_STRING_SIZE + len );
   cstring = (&(string->ucs2_string_t.char0));
   cstr    = &UCS2_STRING_REF( src, 0 );

   string->ucs2_string_t.header = MAKE_HEADER( UCS2_STRING_TYPE, 0 );
   string->ucs2_string_t.length = len;
   
   for( i = 0; i < len; i++ )
      cstring[ i ] = cstr[ i ];
   cstring[ i ] = (ucs2_t)0;
		
   return BUCS2STRING( string );
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_t                                                    */
/*    string_to_ucs2_string ...                                        */
/*---------------------------------------------------------------------*/
obj_t
string_to_ucs2_string( char *c )
{
   long    len = strlen( c );
   obj_t   string;
   ucs2_t *cstring;
   long    i;

   string  = GC_MALLOC_ATOMIC( UCS2_STRING_SIZE + len );
   cstring = (&(string->ucs2_string_t.char0));

   string->ucs2_string_t.header = MAKE_HEADER( UCS2_STRING_TYPE, 0 );
   string->ucs2_string_t.length = len;
   
   for( i = 0; i < len; i++ )
      cstring[ i ] = (ucs2_t)(c[ i ]);
   cstring[ i ] = (ucs2_t)0;
		
   return BUCS2STRING( string );
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_t                                                    */
/*    bstring_to_ucs2_string ...                                       */
/*---------------------------------------------------------------------*/
obj_t
bstring_to_ucs2_string( obj_t src )
{
   long    len = STRING_LENGTH( src );
   obj_t   string;
   ucs2_t *cstring;
   long    i;
   char   *c = (&(src->string_t.char0));

   string  = GC_MALLOC_ATOMIC( UCS2_STRING_SIZE + len );
   cstring = (&(string->ucs2_string_t.char0));

   string->ucs2_string_t.header = MAKE_HEADER( UCS2_STRING_TYPE, 0 );
   string->ucs2_string_t.length = len;
   
   for( i = 0; i < len; i++ )
      cstring[ i ] = (ucs2_t)(c[ i ]);
   cstring[ i ] = (ucs2_t)0;
		
   return BUCS2STRING( string );
}

/*---------------------------------------------------------------------*/
/*    integer_to_ucs2_string ...                                       */
/*---------------------------------------------------------------------*/
obj_t
integer_to_ucs2_string( x, radix )
long x, radix;
{
   return string_to_ucs2_string( integer_to_string( x, radix ) );
}

/*---------------------------------------------------------------------*/
/*    real_to_ucs2_string ...                                          */
/*---------------------------------------------------------------------*/
obj_t
real_to_ucs2_string( x )
double x;
{
   return string_to_ucs2_string( real_to_string( x ) );
}

/*---------------------------------------------------------------------*/
/*    bool_t                                                           */
/*    ucs2_strcmp ...                                                  */
/*---------------------------------------------------------------------*/
bool_t
ucs2_strcmp( o1, o2 )
obj_t o1, o2;
{
   long l1, l2;
   
   l1 = UCS2_STRING_LENGTH( o1 );
   l2 = UCS2_STRING_LENGTH( o2 );

   if( l1 == l2 )
   {
      ucs2_t *c1, *c2;
   
      c1 = BUCS2_STRING_TO_UCS2_STRING( o1 );
      c2 = BUCS2_STRING_TO_UCS2_STRING( o2 );
      
      for( l1--; l1 >= 0; l1-- )
	 if( c1[ l1 ] != c2[ l1 ] )
	    return 0;

      return 1;
   }
   else
      return 0;
}

/*---------------------------------------------------------------------*/
/*    ucs2_strcicmp ...                                                */
/*---------------------------------------------------------------------*/
bool_t        
ucs2_strcicmp( bst1, bst2 )
obj_t bst1, bst2;
{
   long l1, l2;

   l1 = UCS2_STRING_LENGTH( bst1 );
   l2 = UCS2_STRING_LENGTH( bst2 );

   if( l1 == l2 )
   {
      ucs2_t *st1 = BUCS2_STRING_TO_UCS2_STRING( bst1 );
      ucs2_t *st2 = BUCS2_STRING_TO_UCS2_STRING( bst2 );
      long i;
   
      for( i = 0;
	   ucs2_tolower( *st1 ) == ucs2_tolower( *st2 );
	   i++, st1++, st2++ )
         if( i == l1 )
	    return 1;
   }

   return 0;
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_lt ...                                               */
/*---------------------------------------------------------------------*/
bool_t       
ucs2_string_lt( bst1, bst2 )
obj_t bst1, bst2;
{
   ucs2_t *st1 = BUCS2_STRING_TO_UCS2_STRING( bst1 );
   ucs2_t *st2 = BUCS2_STRING_TO_UCS2_STRING( bst2 );
   long l1, l2;
   long i, min;

   l1 = UCS2_STRING_LENGTH( bst1 );
   l2 = UCS2_STRING_LENGTH( bst2 );

   min = (l1 < l2) ? l1 : l2;

   for( i = 0; (*st1 == *st2) && (i < min); i++, st1++, st2++ );

   if( i < min )
      return *st1 < *st2;
   else
      return l1 < l2;
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_le ...                                               */
/*---------------------------------------------------------------------*/
bool_t        
ucs2_string_le( bst1, bst2 )
obj_t bst1, bst2;
{
   ucs2_t *st1 = BUCS2_STRING_TO_UCS2_STRING( bst1 );
   ucs2_t *st2 = BUCS2_STRING_TO_UCS2_STRING( bst2 );
   long l1, l2;
   long i, min;

   l1 = UCS2_STRING_LENGTH( bst1 );
   l2 = UCS2_STRING_LENGTH( bst2 );

   min = (l1 < l2) ? l1 : l2;

   for( i = 0; (*st1 == *st2) && (i < min); i++, st1++, st2++ );

   if( i < min )
      return *st1 <= *st2;
   else
      return l1 <= l2;
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_gt ...                                               */
/*---------------------------------------------------------------------*/
bool_t       
ucs2_string_gt( bst1, bst2 )
obj_t bst1, bst2;
{
   ucs2_t *st1 = BUCS2_STRING_TO_UCS2_STRING( bst1 );
   ucs2_t *st2 = BUCS2_STRING_TO_UCS2_STRING( bst2 );
   long l1, l2;
   long i, min;

   l1 = UCS2_STRING_LENGTH( bst1 );
   l2 = UCS2_STRING_LENGTH( bst2 );

   min = (l1 < l2) ? l1 : l2;

   for( i = 0; (*st1 == *st2) && (i < min); i++, st1++, st2++ );

   if( i < min )
      return *st1 > *st2;
   else
      return l1 > l2;
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_ge ...                                               */
/*---------------------------------------------------------------------*/
bool_t        
ucs2_string_ge( bst1, bst2 )
obj_t bst1, bst2;
{
   ucs2_t *st1 = BUCS2_STRING_TO_UCS2_STRING( bst1 );
   ucs2_t *st2 = BUCS2_STRING_TO_UCS2_STRING( bst2 );
   long l1, l2;
   long i, min;

   l1 = UCS2_STRING_LENGTH( bst1 );
   l2 = UCS2_STRING_LENGTH( bst2 );

   min = (l1 < l2) ? l1 : l2;

   for( i = 0; (*st1 == *st2) && (i < min); i++, st1++, st2++ );

   if( i < min )
      return *st1 >= *st2;
   else
      return l1 >= l2;
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_cilt ...                                             */
/*---------------------------------------------------------------------*/
bool_t       
ucs2_string_cilt( bst1, bst2 )
obj_t bst1, bst2;
{
   ucs2_t *st1 = BUCS2_STRING_TO_UCS2_STRING( bst1 );
   ucs2_t *st2 = BUCS2_STRING_TO_UCS2_STRING( bst2 );
   long l1, l2;
   long i, min;

   l1 = UCS2_STRING_LENGTH( bst1 );
   l2 = UCS2_STRING_LENGTH( bst2 );

   min = (l1 < l2) ? l1 : l2;

   for( i = 0;
	(ucs2_tolower( *st1 ) == ucs2_tolower( *st2 )) && (i < min);
	i++, st1++, st2++ );

   if( i < min )
      return ucs2_tolower( *st1 ) < ucs2_tolower( *st2 );
   else
      return l1 < l2;
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_cile ...                                             */
/*---------------------------------------------------------------------*/
bool_t        
ucs2_string_cile( bst1, bst2 )
obj_t bst1, bst2;
{
   ucs2_t *st1 = BUCS2_STRING_TO_UCS2_STRING( bst1 );
   ucs2_t *st2 = BUCS2_STRING_TO_UCS2_STRING( bst2 );
   long l1, l2;
   long i, min;

   l1 = UCS2_STRING_LENGTH( bst1 );
   l2 = UCS2_STRING_LENGTH( bst2 );

   min = (l1 < l2) ? l1 : l2;

   for( i = 0;
        (ucs2_tolower( *st1 ) == ucs2_tolower( *st2 )) && (i < min);
        i++, st1++, st2++ );

   if( i < min )
      return ucs2_tolower( *st1 ) <= ucs2_tolower( *st2 );
   else
      return l1 <= l2;
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_cigt ...                                             */
/*---------------------------------------------------------------------*/
bool_t       
ucs2_string_cigt( bst1, bst2 )
obj_t bst1, bst2;
{
   ucs2_t *st1 = BUCS2_STRING_TO_UCS2_STRING( bst1 );
   ucs2_t *st2 = BUCS2_STRING_TO_UCS2_STRING( bst2 );
   long l1, l2;
   long i, min;

   l1 = UCS2_STRING_LENGTH( bst1 );
   l2 = UCS2_STRING_LENGTH( bst2 );

   min = (l1 < l2) ? l1 : l2;

   for( i = 0;
        (ucs2_tolower( *st1 ) == ucs2_tolower( *st2 )) && (i < min);
        i++, st1++, st2++ );

   if( i < min )
      return ucs2_tolower( *st1 ) > ucs2_tolower( *st2 );
   else
      return l1 > l2;
}

/*---------------------------------------------------------------------*/
/*    ucs2_string_cige ...                                             */
/*---------------------------------------------------------------------*/
bool_t        
ucs2_string_cige( bst1, bst2 )
obj_t bst1, bst2;
{
   ucs2_t *st1 = BUCS2_STRING_TO_UCS2_STRING( bst1 );
   ucs2_t *st2 = BUCS2_STRING_TO_UCS2_STRING( bst2 );
   long l1, l2;
   long i, min;

   l1 = UCS2_STRING_LENGTH( bst1 );
   l2 = UCS2_STRING_LENGTH( bst2 );

   min = (l1 < l2) ? l1 : l2;

   for( i = 0;
        (ucs2_tolower( *st1 ) == ucs2_tolower( *st2 )) && (i < min);
        i++, st1++, st2++ );

   if( i < min )
      return ucs2_tolower( *st1 ) >= ucs2_tolower( *st2 );
   else
      return l1 >= l2;
}

/*---------------------------------------------------------------------*/
/*    obj_t                                                            */
/*    display_ucs2string ...                                           */
/*---------------------------------------------------------------------*/
obj_t
display_ucs2string( obj_t obj, obj_t port )
{
   long    len  = UCS2_STRING_LENGTH( obj );
   ucs2_t *ucs2 = BUCS2_STRING_TO_UCS2_STRING( obj );
   long    i;
   
   if( OUTPUT_STRING_PORTP( port ) )
   {
      for( i = 0; i < len; i++ )
      {
	 ucs2_t ch = ucs2[ i ];
	 
#if( UCS2_DISPLAYABLE )
#else
	 if( UCS2_ISOLATIN1P( ch ) )
	    strputc( ch, port );
#endif
      }
   }
   else
   {
      FILE *fout = OUTPUT_PORT( port ).file;
      
      for( i = 0; i < len; i++ )
      {
	 ucs2_t ch = ucs2[ i ];
	 
#if( UCS2_DISPLAYABLE )
#else
	 if( UCS2_ISOLATIN1P( ch ) )
	    fputc( ch, fout );
#endif
      }
   }
   return obj;
}

/*---------------------------------------------------------------------*/
/*    obj_t                                                            */
/*    write_utf8string ...                                             */
/*---------------------------------------------------------------------*/
obj_t
write_utf8string( obj_t string, obj_t port )
{
   char *aux = BSTRING_TO_STRING( string );
   long  len = STRING_LENGTH( string );
   
   if( OUTPUT_STRING_PORTP( port ) )
   {
      strputs( "#u\"", port );
      lstrputs( aux, port, len );
      strputc( '"', port );
   }
   else
   {
      FILE *fout = OUTPUT_PORT( port ).file;

      fprintf( fout, "#u\"" );
      fwrite( aux, 1, len, fout );
      fputc( '"', fout );
      return string;
   }

   return string;
}

/*---------------------------------------------------------------------*/
/*    static int                                                       */
/*    utf8_size ...                                                    */
/*---------------------------------------------------------------------*/
static int
utf8_size( ucs2_t ucs2 )
{
   if( ucs2 <= 0x7f )
      return 1;
   if( ucs2 <= 0x7ff )
      return 2;
   if( ucs2 <= 0xd7ff )
      return 3;
   if( ucs2 <= 0xdfff )
      /* df is 11011111 */
      C_FAILURE( "utf8_size", "Illegal ucs2 character", BUCS2( ucs2 ) );
   if( ucs2 <= 0xfffd )
      return 3;
   
   C_FAILURE( "utf8_size", "Illegal ucs2 character", BUCS2( ucs2 ) );
}

/*---------------------------------------------------------------------*/
/*    obj_t                                                            */
/*    ucs2_string_to_utf8_string ...                                   */
/*---------------------------------------------------------------------*/
obj_t
ucs2_string_to_utf8_string( obj_t bucs2 )
{
   long           len      = UCS2_STRING_LENGTH( bucs2 );
   long           utf8_len = 0;
   ucs2_t        *cucs2    = BUCS2_STRING_TO_UCS2_STRING( bucs2 );
   long           read, write;
   obj_t          result;
   unsigned char *cresult;
   
   /* First, we compute the size of the futur utf8 string */
   for( read = 0, utf8_len = 0; read < len; read++ )
      utf8_len += utf8_size( cucs2[ read ] );

   /* now, we allocate the new string */
   result  = make_string( utf8_len, '0' );
   cresult = (unsigned char *)BSTRING_TO_STRING( result );
   
   /* and we fill it */
   for( read = 0, write = 0; read < len; read++ )
   {
      ucs2_t ucs2 = cucs2[ read ];
      int    len  = utf8_size( ucs2 );

      if( len == 1 )
	 cresult[ write++ ] = (unsigned char)ucs2;
      else
      {
	 if( len == 3 )
	 {
	    cresult[ write + 2 ] = (unsigned char)(0x80 + (ucs2 & 0x3f));
	    ucs2 >>= 6;
	 }

	 
	 cresult[ write + 1 ] = (unsigned char)(0x80 + (ucs2 & 0x3f));
	 ucs2 >>= 6;
	 cresult[ write ] = (unsigned char)(0xff - (0xff >> len) + ucs2);
	 write += len;
      }
   }

   return result;
}

/*---------------------------------------------------------------------*/
/*    obj_t                                                            */
/*    utf8_string_to_ucs2_string ...                                   */
/*---------------------------------------------------------------------*/
obj_t
utf8_string_to_ucs2_string( obj_t butf8 )
{
   long           len = STRING_LENGTH( butf8 );
   ucs2_t        *aux = (ucs2_t *)alloca( len * sizeof( ucs2_t ) );
   unsigned char *cutf8 = (unsigned char *)BSTRING_TO_STRING( butf8 );
   long           read, write;
   obj_t          string;
   ucs2_t        *cstring;
   
   for( read = 0, write = 0; read < len; write++ )
   {
      unsigned char byte = cutf8[ read++ ];

      if( byte <= 0x7f )
	 aux[ write ] = (ucs2_t)byte;
      else
      {
	 if( (byte <= 0xbf) || (byte >= 0xfd) )
	    C_FAILURE( "utf8-string->ucs2-string",
		       "Illegal first byte",
		       BCHAR( byte ) );
	 else
	 {
	    ucs2_t ucs2;
	    int    bits;
	    
	    ucs2 = (ucs2_t)byte;
	    bits = 6;

	    while( byte & 0x40 )
	    {
	       unsigned char next = cutf8[ read++ ];
	       
	       if( (next <= 0x7f) || (next > 0xbf) )
		  C_FAILURE( "utf8-string->ucs2-string",
			     "Illegal following byte",
			     BCHAR( next ) );
	       
	       ucs2 = (ucs2 << 6) + (next & 0x3f);
	       byte <<= 1;
	       bits += 5;
	    }
	    ucs2 &= ((ucs2_t)1<<bits) - 1;

	    if( (ucs2 > 0xd7ff && ucs2 <= 0xdfff) ||
		(ucs2 > 0xfffd && ucs2 <= 0xffff) ||
		!(ucs2 & (~(unsigned long)0<<(bits - 5))) )
	       C_FAILURE( "utf8-string->ucs2-string",
			  "Illegal utf8 character encoding",
			  BINT( ucs2 ) );
	    
	    aux[ write ] = ucs2;
	 }
      }
   }
	 
   string  = GC_MALLOC_ATOMIC( UCS2_STRING_SIZE + len );
   cstring = (&(string->ucs2_string_t.char0));

   string->ucs2_string_t.header = MAKE_HEADER( UCS2_STRING_TYPE, 0 );
   string->ucs2_string_t.length = write;
   ucs2cpy( cstring, aux, write );
		
   return BUCS2STRING( string );
}
   
