/*===========================================================================*/
/*   (Expand/initial.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_expand_install();
static obj_t _expand_lambda2747_244_expand_lambda(obj_t, obj_t, obj_t);
static obj_t _expand_struct2762_74_expand_struct(obj_t, obj_t, obj_t);
static obj_t _expand_instantiate2869_82_expand_object(obj_t, obj_t, obj_t);
static obj_t _expand_define2750_79_expand_define(obj_t, obj_t, obj_t);
static obj_t _expand_case_152_expand_case(obj_t, obj_t, obj_t);
static obj_t _expand_i_2825_8_expand_iarithmetique(obj_t, obj_t, obj_t);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
static obj_t _expand_i_2813_157_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_i_2810_165_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_g_2795_146_expand_garithmetique(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
static obj_t _expand_g_2789_184_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _expand__fx2834_63_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_i__2828_152_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_method2759_177_expand_define(obj_t, obj_t, obj_t);
extern obj_t _genericity__47_engine_param;
extern obj_t module_initialization_70_expand_install(long, char *);
extern obj_t module_initialization_70_expand_if(long, char *);
extern obj_t module_initialization_70_expand_lambda(long, char *);
extern obj_t module_initialization_70_expand_define(long, char *);
extern obj_t module_initialization_70_expand_expander(long, char *);
extern obj_t module_initialization_70_expand_exit(long, char *);
extern obj_t module_initialization_70_expand_garithmetique(long, char *);
extern obj_t module_initialization_70_expand_iarithmetique(long, char *);
extern obj_t module_initialization_70_expand_farithmetique(long, char *);
extern obj_t module_initialization_70_expand_let(long, char *);
extern obj_t module_initialization_70_expand_case(long, char *);
extern obj_t module_initialization_70_expand_struct(long, char *);
extern obj_t module_initialization_70_expand_map(long, char *);
extern obj_t module_initialization_70_expand_assert(long, char *);
extern obj_t module_initialization_70_expand_object(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___macro(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static obj_t _expand_let_2849_66_expand_let(obj_t, obj_t, obj_t);
static obj_t _expand_duplicate2872_0_expand_object(obj_t, obj_t, obj_t);
static obj_t _expand_inline2753_43_expand_define(obj_t, obj_t, obj_t);
static obj_t _expand_jump_exit_199_expand_exit(obj_t, obj_t, obj_t);
static obj_t _expand_if2741_106_expand_if(obj_t, obj_t, obj_t);
static obj_t _expand_i_2822_182_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_i_2816_53_expand_iarithmetique(obj_t, obj_t, obj_t);
extern long list_length(obj_t);
static obj_t _expand_i__2831_102_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_let2852_15_expand_let(obj_t, obj_t, obj_t);
static obj_t _expand_set_exit_140_expand_exit(obj_t, obj_t, obj_t);
static obj_t _expand_g_2780_244_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_unwind_protect_22_expand_exit(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_expand_install();
extern obj_t initialize_oenv__233_expand_expander();
static obj_t _expand_labels2858_200_expand_let(obj_t, obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _expand_fmin2843_90_expand_farithmetique(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_expand_install();
static obj_t _expand_for_each_126_expand_map(obj_t, obj_t, obj_t);
static obj_t _expand_i_2807_217_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_g_2792_61_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _install_initial_expander_202_expand_install(obj_t);
static obj_t arg2328_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_letrec2855_203_expand_let(obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t arg1901_expand_install(obj_t, obj_t, obj_t);
extern obj_t install_compiler_expander_48___macro(obj_t, obj_t);
static obj_t arg1857_expand_install(obj_t, obj_t, obj_t);
static obj_t arg1829_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_fatan2846_33_expand_farithmetique(obj_t, obj_t, obj_t);
static obj_t arg1789_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_shrink_2878_38_expand_object(obj_t, obj_t, obj_t);
static obj_t arg1761_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_generic2756_240_expand_define(obj_t, obj_t, obj_t);
static obj_t _expand_set_2765_29_expand_define(obj_t, obj_t, obj_t);
static obj_t arg1722_expand_install(obj_t, obj_t, obj_t);
static obj_t arg1693_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand__fx2837_105_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t arg1667_expand_install(obj_t, obj_t, obj_t);
static obj_t arg1634_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_g__2801_186_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_i_2819_126_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t arg1584_expand_install(obj_t, obj_t, obj_t);
static obj_t arg1527_expand_install(obj_t, obj_t, obj_t);
static obj_t arg1502_expand_install(obj_t, obj_t, obj_t);
extern obj_t install_initial_expander_168_expand_install();
static obj_t arg1456_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_not2744_123_expand_if(obj_t, obj_t, obj_t);
static obj_t arg1410_expand_install(obj_t, obj_t, obj_t);
static obj_t arg1384_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_bind_exit_56_expand_exit(obj_t, obj_t, obj_t);
static obj_t arg1308_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_with_access2866_128_expand_object(obj_t, obj_t, obj_t);
static obj_t arg1282_expand_install(obj_t, obj_t, obj_t);
static obj_t arg1263_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_widen_2875_195_expand_object(obj_t, obj_t, obj_t);
static obj_t arg1219_expand_install(obj_t, obj_t, obj_t);
static obj_t arg1142_expand_install(obj_t, obj_t, obj_t);
static obj_t _expand_fmax2840_224_expand_farithmetique(obj_t, obj_t, obj_t);
extern obj_t _unsafe_range__218_engine_param;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _expand_g__2804_106_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_assert2863_181_expand_assert(obj_t, obj_t, obj_t);
static obj_t _expand_map_144_expand_map(obj_t, obj_t, obj_t);
extern obj_t install_o_comptime_expander_57_expand_expander(obj_t, obj_t);
static obj_t require_initialization_114_expand_install = BUNSPEC;
static obj_t _expand_g_2798_55_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_g_2786_83_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t cnst_init_137_expand_install();
static obj_t _expand_g_2783_171_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t __cnst[94];

extern obj_t expand_g__env_203_expand_garithmetique;
extern obj_t expand_g__env_199_expand_garithmetique;
extern obj_t expand_set__env_74_expand_define;
extern obj_t expand_bind_exit_env_198_expand_exit;
DEFINE_STATIC_PROCEDURE(proc2899_expand_install, arg2328_expand_install2923, arg2328_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2898_expand_install, arg1901_expand_install2924, arg1901_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2897_expand_install, arg1857_expand_install2925, arg1857_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2896_expand_install, arg1829_expand_install2926, arg1829_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2895_expand_install, arg1789_expand_install2927, arg1789_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2894_expand_install, arg1761_expand_install2928, arg1761_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2893_expand_install, arg1722_expand_install2929, arg1722_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2892_expand_install, arg1693_expand_install2930, arg1693_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2891_expand_install, arg1667_expand_install2931, arg1667_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2889_expand_install, arg1584_expand_install2932, arg1584_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2890_expand_install, arg1634_expand_install2933, arg1634_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2888_expand_install, arg1527_expand_install2934, arg1527_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2887_expand_install, arg1502_expand_install2935, arg1502_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2886_expand_install, arg1456_expand_install2936, arg1456_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2885_expand_install, arg1410_expand_install2937, arg1410_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2884_expand_install, arg1384_expand_install2938, arg1384_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2883_expand_install, arg1308_expand_install2939, arg1308_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2882_expand_install, arg1282_expand_install2940, arg1282_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2881_expand_install, arg1263_expand_install2941, arg1263_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2879_expand_install, arg1142_expand_install2942, arg1142_expand_install, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2880_expand_install, arg1219_expand_install2943, arg1219_expand_install, 0L, 2);
extern obj_t expand_labels_env_80_expand_let;
extern obj_t expand_duplicate_env_116_expand_object;
extern obj_t expand_instantiate_env_9_expand_object;
extern obj_t expand_i__env_215_expand_iarithmetique;
extern obj_t expand_i___env_190_expand_iarithmetique;
extern obj_t expand_let_env_1_expand_let;
extern obj_t expand_i__env_160_expand_iarithmetique;
extern obj_t expand_g__env_2_expand_garithmetique;
extern obj_t expand_i__env_3_expand_iarithmetique;
extern obj_t expand_fmax_env_69_expand_farithmetique;
extern obj_t expand_g__env_117_expand_garithmetique;
extern obj_t expand_letrec_env_215_expand_let;
extern obj_t expand_case_env_215_expand_case;
extern obj_t expand_jump_exit_env_87_expand_exit;
extern obj_t expand_if_env_52_expand_if;
DEFINE_EXPORT_PROCEDURE(install_initial_expander_env_132_expand_install, _install_initial_expander_202_expand_install2944, _install_initial_expander_202_expand_install, 0L, 0);
extern obj_t expand_i__env_125_expand_iarithmetique;
extern obj_t expand_fatan_env_212_expand_farithmetique;
extern obj_t expand_set_exit_env_141_expand_exit;
extern obj_t expand_i__env_129_expand_iarithmetique;
extern obj_t expand_g__env_166_expand_garithmetique;
extern obj_t expand_widen__env_255_expand_object;
extern obj_t expand_unwind_protect_env_54_expand_exit;
extern obj_t expand__fx_env_131_expand_iarithmetique;
extern obj_t expand_g___env_169_expand_garithmetique;
extern obj_t expand_map_env_203_expand_map;
extern obj_t expand_not_env_116_expand_if;
extern obj_t expand_assert_env_90_expand_assert;
extern obj_t expand_g__env_26_expand_garithmetique;
extern obj_t expand_i__env_112_expand_iarithmetique;
extern obj_t expand_lambda_env_152_expand_lambda;
DEFINE_STRING(string2917_expand_install, string2917_expand_install2945, "APPEND-2 C-STRING-APPEND EQ? QUOTE SQRTFL-UR ATAN-2FL-UR CURRENT-INPUT-PORT C-CREATE-VECTOR V (UNSPECIFIED) C-MAKE-VECTOR VECTOR-SET-UR! VECTOR-REF-UR SUBSTRING-UR STRING-SET-UR! STRING-REF-UR BLIT-STRING-UR! INTEGER->CHAR-UR CONS* (SET! (@ *RES-NUMBER* __R5_CONTROL_FEATURES_6_4) 0) LIST VAL_ VAL3_ VAL2_ VAL1_ *RES-NUMBER* VAL0_ *RES3* *RES2* __R5_CONTROL_FEATURES_6_4 *RES1* @ BEGIN SHRINK! WIDEN! DUPLICATE INSTANTIATE WITH-ACCESS ASSERT CALL-WITH-VALUES VALUES APPLY INTEGER->CHAR BLIT-STRING! STRING-REF STRING-SET! SUBSTRING VECTOR-REF VECTOR-SET! MAKE-VECTOR VECTOR READ/RP READ CASE LABELS LETREC LET LET* ATAN-2FL SQRTFL ATANFL MINFL MAXFL -FX +FX >= <= > < = - / * + EQUAL? FOR-EACH MAP CONS STRING-LENGTH STRING-APPEND APPEND UNWIND-PROTECT BIND-EXIT JUMP-EXIT SET-EXIT SET! DEFINE-STRUCT DEFINE-METHOD DEFINE-GENERIC DEFINE-INLINE DEFINE LAMBDA NOT IF ", 865);
DEFINE_STRING(string2916_expand_install, string2916_expand_install2946, "Illegal `append' form", 21);
DEFINE_STRING(string2915_expand_install, string2915_expand_install2947, "Illegal 'string-append' form", 28);
DEFINE_STRING(string2914_expand_install, string2914_expand_install2948, "Illegal 'string-length' form", 28);
DEFINE_STRING(string2913_expand_install, string2913_expand_install2949, "Illegal `cons' form", 19);
DEFINE_STRING(string2912_expand_install, string2912_expand_install2950, "Illegal `equal?' form", 21);
DEFINE_STRING(string2911_expand_install, string2911_expand_install2951, "Illegal `sqrtfl' call", 21);
DEFINE_STRING(string2909_expand_install, string2909_expand_install2952, "Illegal `read' form", 19);
DEFINE_STRING(string2910_expand_install, string2910_expand_install2953, "Illegal `atan-2fl' call", 23);
DEFINE_STRING(string2908_expand_install, string2908_expand_install2954, "Illegal `read/rp' form", 22);
DEFINE_STRING(string2907_expand_install, string2907_expand_install2955, "Illegal `vector-set!' form", 26);
DEFINE_STRING(string2906_expand_install, string2906_expand_install2956, "Illegal `vector-ref' form", 25);
DEFINE_STRING(string2905_expand_install, string2905_expand_install2957, "Illegal `substring' form", 24);
DEFINE_STRING(string2904_expand_install, string2904_expand_install2958, "Illegal `string-set!' form", 26);
DEFINE_STRING(string2903_expand_install, string2903_expand_install2959, "Illegal `string-ref' form", 25);
DEFINE_STRING(string2902_expand_install, string2902_expand_install2960, "Illegal `blit-string!' form", 27);
DEFINE_STRING(string2901_expand_install, string2901_expand_install2961, "Illegal `integer->char' call", 28);
DEFINE_STRING(string2900_expand_install, string2900_expand_install2962, "Illegal `apply' form", 20);
extern obj_t expand_let__env_145_expand_let;
extern obj_t expand_g___env_34_expand_garithmetique;
extern obj_t expand_struct_env_88_expand_struct;
extern obj_t expand_define_env_128_expand_define;
extern obj_t expand_generic_env_218_expand_define;
extern obj_t expand_shrink__env_80_expand_object;
extern obj_t expand_i__env_212_expand_iarithmetique;
extern obj_t expand_for_each_env_168_expand_map;
extern obj_t expand_with_access_env_4_expand_object;
extern obj_t expand_method_env_222_expand_define;
extern obj_t expand_fmin_env_157_expand_farithmetique;
extern obj_t expand_inline_env_1_expand_define;
extern obj_t expand__fx_env_33_expand_iarithmetique;
extern obj_t expand_g__env_116_expand_garithmetique;
extern obj_t expand_i___env_234_expand_iarithmetique;


/* module-initialization */ obj_t 
module_initialization_70_expand_install(long checksum_2583, char *from_2584)
{
   if (CBOOL(require_initialization_114_expand_install))
     {
	require_initialization_114_expand_install = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_install();
	cnst_init_137_expand_install();
	imported_modules_init_94_expand_install();
	method_init_76_expand_install();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_install()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "EXPAND_INSTALL");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_INSTALL");
   module_initialization_70___macro(((long) 0), "EXPAND_INSTALL");
   module_initialization_70___reader(((long) 0), "EXPAND_INSTALL");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_install()
{
   {
      obj_t cnst_port_138_2575;
      cnst_port_138_2575 = open_input_string(string2917_expand_install);
      {
	 long i_2576;
	 i_2576 = ((long) 93);
       loop_2577:
	 {
	    bool_t test2918_2578;
	    test2918_2578 = (i_2576 == ((long) -1));
	    if (test2918_2578)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2919_2579;
		    {
		       obj_t list2920_2580;
		       {
			  obj_t arg2921_2581;
			  arg2921_2581 = BNIL;
			  list2920_2580 = MAKE_PAIR(cnst_port_138_2575, arg2921_2581);
		       }
		       arg2919_2579 = read___reader(list2920_2580);
		    }
		    CNST_TABLE_SET(i_2576, arg2919_2579);
		 }
		 {
		    int aux_2582;
		    {
		       long aux_2602;
		       aux_2602 = (i_2576 - ((long) 1));
		       aux_2582 = (int) (aux_2602);
		    }
		    {
		       long i_2605;
		       i_2605 = (long) (aux_2582);
		       i_2576 = i_2605;
		       goto loop_2577;
		    }
		 }
	      }
	 }
      }
   }
}


/* install-initial-expander */ obj_t 
install_initial_expander_168_expand_install()
{
   initialize_oenv__233_expand_expander();
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 0)), expand_if_env_52_expand_if);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 1)), expand_not_env_116_expand_if);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 2)), expand_lambda_env_152_expand_lambda);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 3)), expand_define_env_128_expand_define);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 4)), expand_inline_env_1_expand_define);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 5)), expand_generic_env_218_expand_define);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 6)), expand_method_env_222_expand_define);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 7)), expand_struct_env_88_expand_struct);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 8)), expand_set__env_74_expand_define);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 9)), expand_set_exit_env_141_expand_exit);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 10)), expand_jump_exit_env_87_expand_exit);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 11)), expand_bind_exit_env_198_expand_exit);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 12)), expand_unwind_protect_env_54_expand_exit);
   {
      obj_t arg1137_61;
      arg1137_61 = CNST_TABLE_REF(((long) 13));
      {
	 obj_t arg1142_2363;
	 arg1142_2363 = proc2879_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1137_61, arg1142_2363);
      }
   }
   {
      obj_t arg1216_117;
      arg1216_117 = CNST_TABLE_REF(((long) 14));
      {
	 obj_t arg1219_2362;
	 arg1219_2362 = proc2880_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1216_117, arg1219_2362);
      }
   }
   {
      obj_t arg1262_173;
      arg1262_173 = CNST_TABLE_REF(((long) 15));
      {
	 obj_t arg1263_2361;
	 arg1263_2361 = proc2881_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1262_173, arg1263_2361);
      }
   }
   {
      obj_t arg1281_197;
      arg1281_197 = CNST_TABLE_REF(((long) 16));
      {
	 obj_t arg1282_2360;
	 arg1282_2360 = proc2882_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1281_197, arg1282_2360);
      }
   }
   install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 17)), expand_map_env_203_expand_map);
   install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 18)), expand_for_each_env_168_expand_map);
   {
      obj_t arg1307_230;
      arg1307_230 = CNST_TABLE_REF(((long) 19));
      {
	 obj_t arg1308_2359;
	 arg1308_2359 = proc2883_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1307_230, arg1308_2359);
      }
   }
   if (CBOOL(_genericity__47_engine_param))
     {
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 20)), expand_g__env_166_expand_garithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 21)), expand_g__env_199_expand_garithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 22)), expand_g__env_203_expand_garithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 23)), expand_g__env_117_expand_garithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 24)), expand_g__env_26_expand_garithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 25)), expand_g__env_2_expand_garithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 26)), expand_g__env_116_expand_garithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 27)), expand_g___env_169_expand_garithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 28)), expand_g___env_34_expand_garithmetique);
     }
   else
     {
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 20)), expand_i__env_112_expand_iarithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 21)), expand_i__env_3_expand_iarithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 22)), expand_i__env_160_expand_iarithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 23)), expand_i__env_129_expand_iarithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 24)), expand_i__env_212_expand_iarithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 25)), expand_i__env_125_expand_iarithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 26)), expand_i__env_215_expand_iarithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 27)), expand_i___env_234_expand_iarithmetique);
	install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 28)), expand_i___env_190_expand_iarithmetique);
     }
   install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 29)), expand__fx_env_33_expand_iarithmetique);
   install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 30)), expand__fx_env_131_expand_iarithmetique);
   install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 31)), expand_fmax_env_69_expand_farithmetique);
   install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 32)), expand_fmin_env_157_expand_farithmetique);
   install_o_comptime_expander_57_expand_expander(CNST_TABLE_REF(((long) 33)), expand_fatan_env_212_expand_farithmetique);
   {
      obj_t arg1383_296;
      arg1383_296 = CNST_TABLE_REF(((long) 34));
      {
	 obj_t arg1384_2358;
	 arg1384_2358 = proc2884_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1383_296, arg1384_2358);
      }
   }
   {
      obj_t arg1408_325;
      arg1408_325 = CNST_TABLE_REF(((long) 35));
      {
	 obj_t arg1410_2357;
	 arg1410_2357 = proc2885_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1408_325, arg1410_2357);
      }
   }
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 36)), expand_let__env_145_expand_let);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 37)), expand_let_env_1_expand_let);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 38)), expand_letrec_env_215_expand_let);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 39)), expand_labels_env_80_expand_let);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 40)), expand_case_env_215_expand_case);
   {
      obj_t arg1455_367;
      arg1455_367 = CNST_TABLE_REF(((long) 41));
      {
	 obj_t arg1456_2356;
	 arg1456_2356 = proc2886_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1455_367, arg1456_2356);
      }
   }
   {
      obj_t arg1501_423;
      arg1501_423 = CNST_TABLE_REF(((long) 42));
      {
	 obj_t arg1502_2355;
	 arg1502_2355 = proc2887_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1501_423, arg1502_2355);
      }
   }
   {
      obj_t arg1526_452;
      arg1526_452 = CNST_TABLE_REF(((long) 43));
      {
	 obj_t arg1527_2354;
	 arg1527_2354 = proc2888_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1526_452, arg1527_2354);
      }
   }
   {
      obj_t arg1583_508;
      arg1583_508 = CNST_TABLE_REF(((long) 44));
      {
	 obj_t arg1584_2353;
	 arg1584_2353 = proc2889_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1583_508, arg1584_2353);
      }
   }
   {
      obj_t arg1633_567;
      arg1633_567 = CNST_TABLE_REF(((long) 45));
      {
	 obj_t arg1634_2352;
	 arg1634_2352 = proc2890_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1633_567, arg1634_2352);
      }
   }
   {
      obj_t arg1666_609;
      arg1666_609 = CNST_TABLE_REF(((long) 46));
      {
	 obj_t arg1667_2351;
	 arg1667_2351 = proc2891_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1666_609, arg1667_2351);
      }
   }
   {
      obj_t arg1692_644;
      arg1692_644 = CNST_TABLE_REF(((long) 47));
      {
	 obj_t arg1693_2350;
	 arg1693_2350 = proc2892_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1692_644, arg1693_2350);
      }
   }
   {
      obj_t arg1721_686;
      arg1721_686 = CNST_TABLE_REF(((long) 48));
      {
	 obj_t arg1722_2349;
	 arg1722_2349 = proc2893_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1721_686, arg1722_2349);
      }
   }
   {
      obj_t arg1760_728;
      arg1760_728 = CNST_TABLE_REF(((long) 49));
      {
	 obj_t arg1761_2348;
	 arg1761_2348 = proc2894_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1760_728, arg1761_2348);
      }
   }
   {
      obj_t arg1788_763;
      arg1788_763 = CNST_TABLE_REF(((long) 50));
      {
	 obj_t arg1789_2347;
	 arg1789_2347 = proc2895_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1788_763, arg1789_2347);
      }
   }
   {
      obj_t arg1827_819;
      arg1827_819 = CNST_TABLE_REF(((long) 51));
      {
	 obj_t arg1829_2346;
	 arg1829_2346 = proc2896_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1827_819, arg1829_2346);
      }
   }
   {
      obj_t arg1856_848;
      arg1856_848 = CNST_TABLE_REF(((long) 52));
      {
	 obj_t arg1857_2345;
	 arg1857_2345 = proc2897_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1856_848, arg1857_2345);
      }
   }
   {
      obj_t arg1900_902;
      arg1900_902 = CNST_TABLE_REF(((long) 53));
      {
	 obj_t arg1901_2344;
	 arg1901_2344 = proc2898_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg1900_902, arg1901_2344);
      }
   }
   {
      obj_t arg2327_1334;
      arg2327_1334 = CNST_TABLE_REF(((long) 54));
      {
	 obj_t arg2328_2343;
	 arg2328_2343 = proc2899_expand_install;
	 install_o_comptime_expander_57_expand_expander(arg2327_1334, arg2328_2343);
      }
   }
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 55)), expand_assert_env_90_expand_assert);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 56)), expand_with_access_env_4_expand_object);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 57)), expand_instantiate_env_9_expand_object);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 58)), expand_duplicate_env_116_expand_object);
   install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 59)), expand_widen__env_255_expand_object);
   return install_compiler_expander_48___macro(CNST_TABLE_REF(((long) 60)), expand_shrink__env_80_expand_object);
}


/* _install-initial-expander */ obj_t 
_install_initial_expander_202_expand_install(obj_t env_2364)
{
   return install_initial_expander_168_expand_install();
}


/* arg2328 */ obj_t 
arg2328_expand_install(obj_t env_2365, obj_t x_2366, obj_t e_2367)
{
   {
      obj_t x_1336;
      obj_t e_1337;
      x_1336 = x_2366;
      e_1337 = e_2367;
      {
	 obj_t arg2330_1339;
	 {
	    obj_t producer_1358;
	    obj_t v0_1359;
	    obj_t v1_1360;
	    obj_t v2_1361;
	    obj_t v3_1362;
	    obj_t body_1363;
	    obj_t producer_1352;
	    obj_t v0_1353;
	    obj_t v1_1354;
	    obj_t v2_1355;
	    obj_t body_1356;
	    obj_t producer_1347;
	    obj_t v0_1348;
	    obj_t v1_1349;
	    obj_t body_1350;
	    obj_t producer_1343;
	    obj_t v0_1344;
	    obj_t body_1345;
	    obj_t producer_1340;
	    obj_t body_1341;
	    if (PAIRP(x_1336))
	      {
		 obj_t cdr_790_30_1368;
		 cdr_790_30_1368 = CDR(x_1336);
		 if (PAIRP(cdr_790_30_1368))
		   {
		      obj_t cdr_794_188_1370;
		      cdr_794_188_1370 = CDR(cdr_790_30_1368);
		      if (PAIRP(cdr_794_188_1370))
			{
			   obj_t car_797_35_1372;
			   car_797_35_1372 = CAR(cdr_794_188_1370);
			   if (PAIRP(car_797_35_1372))
			     {
				obj_t cdr_801_45_1374;
				cdr_801_45_1374 = CDR(car_797_35_1372);
				{
				   bool_t test_2763;
				   {
				      obj_t aux_2766;
				      obj_t aux_2764;
				      aux_2766 = CNST_TABLE_REF(((long) 2));
				      aux_2764 = CAR(car_797_35_1372);
				      test_2763 = (aux_2764 == aux_2766);
				   }
				   if (test_2763)
				     {
					if (PAIRP(cdr_801_45_1374))
					  {
					     bool_t test_2771;
					     {
						obj_t aux_2772;
						aux_2772 = CAR(cdr_801_45_1374);
						test_2771 = (aux_2772 == BNIL);
					     }
					     if (test_2771)
					       {
						  bool_t test_2775;
						  {
						     obj_t aux_2776;
						     aux_2776 = CDR(cdr_794_188_1370);
						     test_2775 = (aux_2776 == BNIL);
						  }
						  if (test_2775)
						    {
						       producer_1340 = CAR(cdr_790_30_1368);
						       body_1341 = CDR(cdr_801_45_1374);
						       {
							  obj_t arg2404_1459;
							  obj_t arg2405_1460;
							  obj_t arg2406_1461;
							  arg2404_1459 = CNST_TABLE_REF(((long) 61));
							  {
							     obj_t prod_1465;
							     if (PAIRP(producer_1340))
							       {
								  obj_t cdr_1556_26_1470;
								  cdr_1556_26_1470 = CDR(producer_1340);
								  {
								     bool_t test_2783;
								     {
									obj_t aux_2786;
									obj_t aux_2784;
									aux_2786 = CNST_TABLE_REF(((long) 2));
									aux_2784 = CAR(producer_1340);
									test_2783 = (aux_2784 == aux_2786);
								     }
								     if (test_2783)
								       {
									  if (PAIRP(cdr_1556_26_1470))
									    {
									       bool_t test_2791;
									       {
										  obj_t aux_2792;
										  aux_2792 = CAR(cdr_1556_26_1470);
										  test_2791 = (aux_2792 == BNIL);
									       }
									       if (test_2791)
										 {
										    prod_1465 = CDR(cdr_1556_26_1470);
										    {
										       obj_t arg2419_1479;
										       obj_t arg2420_1480;
										       arg2419_1479 = CNST_TABLE_REF(((long) 61));
										       {
											  obj_t arg2423_1483;
											  arg2423_1483 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
											  arg2420_1480 = append_2_18___r4_pairs_and_lists_6_3(prod_1465, arg2423_1483);
										       }
										       {
											  obj_t list2421_1481;
											  list2421_1481 = MAKE_PAIR(arg2420_1480, BNIL);
											  arg2405_1460 = cons__138___r4_pairs_and_lists_6_3(arg2419_1479, list2421_1481);
										       }
										    }
										 }
									       else
										 {
										  tag_1551_13_1467:
										    {
										       obj_t list2427_1487;
										       list2427_1487 = MAKE_PAIR(BNIL, BNIL);
										       arg2405_1460 = cons__138___r4_pairs_and_lists_6_3(producer_1340, list2427_1487);
										    }
										 }
									    }
									  else
									    {
									       goto tag_1551_13_1467;
									    }
								       }
								     else
								       {
									  goto tag_1551_13_1467;
								       }
								  }
							       }
							     else
							       {
								  goto tag_1551_13_1467;
							       }
							  }
							  {
							     obj_t arg2429_1489;
							     arg2429_1489 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							     arg2406_1461 = append_2_18___r4_pairs_and_lists_6_3(body_1341, arg2429_1489);
							  }
							  {
							     obj_t list2407_1462;
							     {
								obj_t arg2408_1463;
								arg2408_1463 = MAKE_PAIR(arg2406_1461, BNIL);
								list2407_1462 = MAKE_PAIR(arg2405_1460, arg2408_1463);
							     }
							     arg2330_1339 = cons__138___r4_pairs_and_lists_6_3(arg2404_1459, list2407_1462);
							  }
						       }
						    }
						  else
						    {
						     tag_779_252_1365:
						       {
							  obj_t arg2713_1780;
							  obj_t arg2714_1781;
							  {
							     obj_t arg2717_1784;
							     obj_t arg2718_1785;
							     obj_t arg2720_1786;
							     arg2717_1784 = CNST_TABLE_REF(((long) 62));
							     arg2718_1785 = CNST_TABLE_REF(((long) 54));
							     arg2720_1786 = CNST_TABLE_REF(((long) 64));
							     {
								obj_t list2722_1788;
								{
								   obj_t arg2724_1789;
								   {
								      obj_t arg2725_1790;
								      arg2725_1790 = MAKE_PAIR(BNIL, BNIL);
								      arg2724_1789 = MAKE_PAIR(arg2720_1786, arg2725_1790);
								   }
								   list2722_1788 = MAKE_PAIR(arg2718_1785, arg2724_1789);
								}
								arg2713_1780 = cons__138___r4_pairs_and_lists_6_3(arg2717_1784, list2722_1788);
							     }
							  }
							  {
							     obj_t arg2727_1792;
							     obj_t arg2728_1793;
							     arg2727_1792 = CDR(x_1336);
							     arg2728_1793 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							     arg2714_1781 = append_2_18___r4_pairs_and_lists_6_3(arg2727_1792, arg2728_1793);
							  }
							  {
							     obj_t list2715_1782;
							     list2715_1782 = MAKE_PAIR(arg2714_1781, BNIL);
							     arg2330_1339 = cons__138___r4_pairs_and_lists_6_3(arg2713_1780, list2715_1782);
							  }
						       }
						    }
					       }
					     else
					       {
						  obj_t cdr_873_117_1384;
						  cdr_873_117_1384 = CDR(cdr_790_30_1368);
						  {
						     obj_t cdr_883_189_1385;
						     {
							obj_t aux_2823;
							aux_2823 = CAR(cdr_873_117_1384);
							cdr_883_189_1385 = CDR(aux_2823);
						     }
						     {
							obj_t car_886_113_1386;
							car_886_113_1386 = CAR(cdr_883_189_1385);
							if (PAIRP(car_886_113_1386))
							  {
							     bool_t test_2829;
							     {
								obj_t aux_2830;
								aux_2830 = CDR(car_886_113_1386);
								test_2829 = (aux_2830 == BNIL);
							     }
							     if (test_2829)
							       {
								  bool_t test_2833;
								  {
								     obj_t aux_2834;
								     aux_2834 = CDR(cdr_873_117_1384);
								     test_2833 = (aux_2834 == BNIL);
								  }
								  if (test_2833)
								    {
								       producer_1343 = CAR(cdr_790_30_1368);
								       v0_1344 = CAR(car_886_113_1386);
								       body_1345 = CDR(cdr_883_189_1385);
								       {
									  obj_t arg2432_1492;
									  obj_t arg2433_1493;
									  obj_t arg2434_1494;
									  arg2432_1492 = CNST_TABLE_REF(((long) 37));
									  {
									     obj_t arg2438_1498;
									     {
										obj_t arg2442_1502;
										{
										   obj_t prod_1507;
										   if (PAIRP(producer_1343))
										     {
											obj_t cdr_1567_213_1512;
											cdr_1567_213_1512 = CDR(producer_1343);
											{
											   bool_t test_2841;
											   {
											      obj_t aux_2844;
											      obj_t aux_2842;
											      aux_2844 = CNST_TABLE_REF(((long) 2));
											      aux_2842 = CAR(producer_1343);
											      test_2841 = (aux_2842 == aux_2844);
											   }
											   if (test_2841)
											     {
												if (PAIRP(cdr_1567_213_1512))
												  {
												     bool_t test_2849;
												     {
													obj_t aux_2850;
													aux_2850 = CAR(cdr_1567_213_1512);
													test_2849 = (aux_2850 == BNIL);
												     }
												     if (test_2849)
												       {
													  prod_1507 = CDR(cdr_1567_213_1512);
													  {
													     obj_t arg2456_1521;
													     obj_t arg2457_1522;
													     arg2456_1521 = CNST_TABLE_REF(((long) 61));
													     {
														obj_t arg2460_1525;
														arg2460_1525 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
														arg2457_1522 = append_2_18___r4_pairs_and_lists_6_3(prod_1507, arg2460_1525);
													     }
													     {
														obj_t list2458_1523;
														list2458_1523 = MAKE_PAIR(arg2457_1522, BNIL);
														arg2442_1502 = cons__138___r4_pairs_and_lists_6_3(arg2456_1521, list2458_1523);
													     }
													  }
												       }
												     else
												       {
													tag_1562_132_1509:
													  {
													     obj_t list2464_1529;
													     list2464_1529 = MAKE_PAIR(BNIL, BNIL);
													     arg2442_1502 = cons__138___r4_pairs_and_lists_6_3(producer_1343, list2464_1529);
													  }
												       }
												  }
												else
												  {
												     goto tag_1562_132_1509;
												  }
											     }
											   else
											     {
												goto tag_1562_132_1509;
											     }
											}
										     }
										   else
										     {
											goto tag_1562_132_1509;
										     }
										}
										{
										   obj_t list2444_1504;
										   {
										      obj_t arg2445_1505;
										      arg2445_1505 = MAKE_PAIR(BNIL, BNIL);
										      list2444_1504 = MAKE_PAIR(arg2442_1502, arg2445_1505);
										   }
										   arg2438_1498 = cons__138___r4_pairs_and_lists_6_3(v0_1344, list2444_1504);
										}
									     }
									     {
										obj_t list2440_1500;
										list2440_1500 = MAKE_PAIR(BNIL, BNIL);
										arg2433_1493 = cons__138___r4_pairs_and_lists_6_3(arg2438_1498, list2440_1500);
									     }
									  }
									  {
									     obj_t arg2466_1531;
									     arg2466_1531 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
									     arg2434_1494 = append_2_18___r4_pairs_and_lists_6_3(body_1345, arg2466_1531);
									  }
									  {
									     obj_t list2435_1495;
									     {
										obj_t arg2436_1496;
										arg2436_1496 = MAKE_PAIR(arg2434_1494, BNIL);
										list2435_1495 = MAKE_PAIR(arg2433_1493, arg2436_1496);
									     }
									     arg2330_1339 = cons__138___r4_pairs_and_lists_6_3(arg2432_1492, list2435_1495);
									  }
								       }
								    }
								  else
								    {
								       goto tag_779_252_1365;
								    }
							       }
							     else
							       {
								  obj_t cdr_956_90_1396;
								  cdr_956_90_1396 = CDR(cdr_790_30_1368);
								  {
								     obj_t cdr_970_133_1397;
								     {
									obj_t aux_2875;
									aux_2875 = CAR(cdr_956_90_1396);
									cdr_970_133_1397 = CDR(aux_2875);
								     }
								     {
									obj_t car_975_209_1398;
									car_975_209_1398 = CAR(cdr_970_133_1397);
									{
									   obj_t cdr_981_42_1399;
									   cdr_981_42_1399 = CDR(car_975_209_1398);
									   if (PAIRP(cdr_981_42_1399))
									     {
										bool_t test_2882;
										{
										   obj_t aux_2883;
										   aux_2883 = CDR(cdr_981_42_1399);
										   test_2882 = (aux_2883 == BNIL);
										}
										if (test_2882)
										  {
										     bool_t test_2886;
										     {
											obj_t aux_2887;
											aux_2887 = CDR(cdr_956_90_1396);
											test_2886 = (aux_2887 == BNIL);
										     }
										     if (test_2886)
										       {
											  producer_1347 = CAR(cdr_790_30_1368);
											  v0_1348 = CAR(car_975_209_1398);
											  v1_1349 = CAR(cdr_981_42_1399);
											  body_1350 = CDR(cdr_970_133_1397);
											  {
											     obj_t arg2469_1534;
											     obj_t arg2470_1535;
											     obj_t arg2471_1536;
											     arg2469_1534 = CNST_TABLE_REF(((long) 37));
											     {
												obj_t arg2477_1542;
												{
												   obj_t arg2481_1546;
												   {
												      obj_t prod_1551;
												      if (PAIRP(producer_1347))
													{
													   obj_t cdr_1578_110_1556;
													   cdr_1578_110_1556 = CDR(producer_1347);
													   {
													      bool_t test_2894;
													      {
														 obj_t aux_2897;
														 obj_t aux_2895;
														 aux_2897 = CNST_TABLE_REF(((long) 2));
														 aux_2895 = CAR(producer_1347);
														 test_2894 = (aux_2895 == aux_2897);
													      }
													      if (test_2894)
														{
														   if (PAIRP(cdr_1578_110_1556))
														     {
															bool_t test_2902;
															{
															   obj_t aux_2903;
															   aux_2903 = CAR(cdr_1578_110_1556);
															   test_2902 = (aux_2903 == BNIL);
															}
															if (test_2902)
															  {
															     prod_1551 = CDR(cdr_1578_110_1556);
															     {
																obj_t arg2496_1565;
																obj_t arg2497_1566;
																arg2496_1565 = CNST_TABLE_REF(((long) 61));
																{
																   obj_t arg2500_1569;
																   arg2500_1569 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
																   arg2497_1566 = append_2_18___r4_pairs_and_lists_6_3(prod_1551, arg2500_1569);
																}
																{
																   obj_t list2498_1567;
																   list2498_1567 = MAKE_PAIR(arg2497_1566, BNIL);
																   arg2481_1546 = cons__138___r4_pairs_and_lists_6_3(arg2496_1565, list2498_1567);
																}
															     }
															  }
															else
															  {
															   tag_1573_69_1553:
															     {
																obj_t list2504_1573;
																list2504_1573 = MAKE_PAIR(BNIL, BNIL);
																arg2481_1546 = cons__138___r4_pairs_and_lists_6_3(producer_1347, list2504_1573);
															     }
															  }
														     }
														   else
														     {
															goto tag_1573_69_1553;
														     }
														}
													      else
														{
														   goto tag_1573_69_1553;
														}
													   }
													}
												      else
													{
													   goto tag_1573_69_1553;
													}
												   }
												   {
												      obj_t list2483_1548;
												      {
													 obj_t arg2484_1549;
													 arg2484_1549 = MAKE_PAIR(BNIL, BNIL);
													 list2483_1548 = MAKE_PAIR(arg2481_1546, arg2484_1549);
												      }
												      arg2477_1542 = cons__138___r4_pairs_and_lists_6_3(v0_1348, list2483_1548);
												   }
												}
												{
												   obj_t list2479_1544;
												   list2479_1544 = MAKE_PAIR(BNIL, BNIL);
												   arg2470_1535 = cons__138___r4_pairs_and_lists_6_3(arg2477_1542, list2479_1544);
												}
											     }
											     {
												obj_t arg2507_1575;
												obj_t arg2508_1576;
												obj_t arg2509_1577;
												arg2507_1575 = CNST_TABLE_REF(((long) 37));
												{
												   obj_t arg2514_1581;
												   {
												      obj_t arg2518_1585;
												      {
													 obj_t arg2524_1590;
													 obj_t arg2525_1591;
													 obj_t arg2526_1592;
													 arg2524_1590 = CNST_TABLE_REF(((long) 62));
													 arg2525_1591 = CNST_TABLE_REF(((long) 63));
													 arg2526_1592 = CNST_TABLE_REF(((long) 64));
													 {
													    obj_t list2528_1594;
													    {
													       obj_t arg2529_1595;
													       {
														  obj_t arg2530_1596;
														  arg2530_1596 = MAKE_PAIR(BNIL, BNIL);
														  arg2529_1595 = MAKE_PAIR(arg2526_1592, arg2530_1596);
													       }
													       list2528_1594 = MAKE_PAIR(arg2525_1591, arg2529_1595);
													    }
													    arg2518_1585 = cons__138___r4_pairs_and_lists_6_3(arg2524_1590, list2528_1594);
													 }
												      }
												      {
													 obj_t list2520_1587;
													 {
													    obj_t arg2522_1588;
													    arg2522_1588 = MAKE_PAIR(BNIL, BNIL);
													    list2520_1587 = MAKE_PAIR(arg2518_1585, arg2522_1588);
													 }
													 arg2514_1581 = cons__138___r4_pairs_and_lists_6_3(v1_1349, list2520_1587);
												      }
												   }
												   {
												      obj_t list2516_1583;
												      list2516_1583 = MAKE_PAIR(BNIL, BNIL);
												      arg2508_1576 = cons__138___r4_pairs_and_lists_6_3(arg2514_1581, list2516_1583);
												   }
												}
												{
												   obj_t arg2532_1598;
												   arg2532_1598 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
												   arg2509_1577 = append_2_18___r4_pairs_and_lists_6_3(body_1350, arg2532_1598);
												}
												{
												   obj_t list2510_1578;
												   {
												      obj_t arg2511_1579;
												      arg2511_1579 = MAKE_PAIR(arg2509_1577, BNIL);
												      list2510_1578 = MAKE_PAIR(arg2508_1576, arg2511_1579);
												   }
												   arg2471_1536 = cons__138___r4_pairs_and_lists_6_3(arg2507_1575, list2510_1578);
												}
											     }
											     {
												obj_t list2473_1538;
												{
												   obj_t arg2474_1539;
												   {
												      obj_t arg2475_1540;
												      arg2475_1540 = MAKE_PAIR(BNIL, BNIL);
												      arg2474_1539 = MAKE_PAIR(arg2471_1536, arg2475_1540);
												   }
												   list2473_1538 = MAKE_PAIR(arg2470_1535, arg2474_1539);
												}
												arg2330_1339 = cons__138___r4_pairs_and_lists_6_3(arg2469_1534, list2473_1538);
											     }
											  }
										       }
										     else
										       {
											  goto tag_779_252_1365;
										       }
										  }
										else
										  {
										     obj_t cdr_1045_117_1410;
										     cdr_1045_117_1410 = CDR(cdr_790_30_1368);
										     {
											obj_t cdr_1063_199_1411;
											{
											   obj_t aux_2946;
											   aux_2946 = CAR(cdr_1045_117_1410);
											   cdr_1063_199_1411 = CDR(aux_2946);
											}
											{
											   obj_t car_1070_81_1412;
											   car_1070_81_1412 = CAR(cdr_1063_199_1411);
											   {
											      obj_t cdr_1078_183_1413;
											      cdr_1078_183_1413 = CDR(car_1070_81_1412);
											      {
												 obj_t cdr_1085_87_1414;
												 cdr_1085_87_1414 = CDR(cdr_1078_183_1413);
												 if (PAIRP(cdr_1085_87_1414))
												   {
												      bool_t test_2954;
												      {
													 obj_t aux_2955;
													 aux_2955 = CDR(cdr_1085_87_1414);
													 test_2954 = (aux_2955 == BNIL);
												      }
												      if (test_2954)
													{
													   bool_t test_2958;
													   {
													      obj_t aux_2959;
													      aux_2959 = CDR(cdr_1045_117_1410);
													      test_2958 = (aux_2959 == BNIL);
													   }
													   if (test_2958)
													     {
														producer_1352 = CAR(cdr_790_30_1368);
														v0_1353 = CAR(car_1070_81_1412);
														v1_1354 = CAR(cdr_1078_183_1413);
														v2_1355 = CAR(cdr_1085_87_1414);
														body_1356 = CDR(cdr_1063_199_1411);
														{
														   obj_t arg2535_1601;
														   obj_t arg2536_1602;
														   obj_t arg2537_1603;
														   arg2535_1601 = CNST_TABLE_REF(((long) 37));
														   {
														      obj_t arg2543_1609;
														      {
															 obj_t arg2547_1613;
															 {
															    obj_t prod_1618;
															    if (PAIRP(producer_1352))
															      {
																 obj_t cdr_1589_114_1623;
																 cdr_1589_114_1623 = CDR(producer_1352);
																 {
																    bool_t test_2966;
																    {
																       obj_t aux_2969;
																       obj_t aux_2967;
																       aux_2969 = CNST_TABLE_REF(((long) 2));
																       aux_2967 = CAR(producer_1352);
																       test_2966 = (aux_2967 == aux_2969);
																    }
																    if (test_2966)
																      {
																	 if (PAIRP(cdr_1589_114_1623))
																	   {
																	      bool_t test_2974;
																	      {
																		 obj_t aux_2975;
																		 aux_2975 = CAR(cdr_1589_114_1623);
																		 test_2974 = (aux_2975 == BNIL);
																	      }
																	      if (test_2974)
																		{
																		   prod_1618 = CDR(cdr_1589_114_1623);
																		   {
																		      obj_t arg2561_1632;
																		      obj_t arg2562_1633;
																		      arg2561_1632 = CNST_TABLE_REF(((long) 61));
																		      {
																			 obj_t arg2567_1636;
																			 arg2567_1636 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
																			 arg2562_1633 = append_2_18___r4_pairs_and_lists_6_3(prod_1618, arg2567_1636);
																		      }
																		      {
																			 obj_t list2563_1634;
																			 list2563_1634 = MAKE_PAIR(arg2562_1633, BNIL);
																			 arg2547_1613 = cons__138___r4_pairs_and_lists_6_3(arg2561_1632, list2563_1634);
																		      }
																		   }
																		}
																	      else
																		{
																		 tag_1584_190_1620:
																		   {
																		      obj_t list2571_1640;
																		      list2571_1640 = MAKE_PAIR(BNIL, BNIL);
																		      arg2547_1613 = cons__138___r4_pairs_and_lists_6_3(producer_1352, list2571_1640);
																		   }
																		}
																	   }
																	 else
																	   {
																	      goto tag_1584_190_1620;
																	   }
																      }
																    else
																      {
																	 goto tag_1584_190_1620;
																      }
																 }
															      }
															    else
															      {
																 goto tag_1584_190_1620;
															      }
															 }
															 {
															    obj_t list2549_1615;
															    {
															       obj_t arg2550_1616;
															       arg2550_1616 = MAKE_PAIR(BNIL, BNIL);
															       list2549_1615 = MAKE_PAIR(arg2547_1613, arg2550_1616);
															    }
															    arg2543_1609 = cons__138___r4_pairs_and_lists_6_3(v0_1353, list2549_1615);
															 }
														      }
														      {
															 obj_t list2545_1611;
															 list2545_1611 = MAKE_PAIR(BNIL, BNIL);
															 arg2536_1602 = cons__138___r4_pairs_and_lists_6_3(arg2543_1609, list2545_1611);
														      }
														   }
														   {
														      obj_t arg2574_1642;
														      obj_t arg2575_1643;
														      obj_t arg2576_1644;
														      arg2574_1642 = CNST_TABLE_REF(((long) 37));
														      {
															 obj_t arg2580_1648;
															 obj_t arg2582_1649;
															 {
															    obj_t arg2587_1654;
															    {
															       obj_t arg2592_1659;
															       obj_t arg2593_1660;
															       obj_t arg2594_1661;
															       arg2592_1659 = CNST_TABLE_REF(((long) 62));
															       arg2593_1660 = CNST_TABLE_REF(((long) 63));
															       arg2594_1661 = CNST_TABLE_REF(((long) 64));
															       {
																  obj_t list2596_1663;
																  {
																     obj_t arg2597_1664;
																     {
																	obj_t arg2598_1665;
																	arg2598_1665 = MAKE_PAIR(BNIL, BNIL);
																	arg2597_1664 = MAKE_PAIR(arg2594_1661, arg2598_1665);
																     }
																     list2596_1663 = MAKE_PAIR(arg2593_1660, arg2597_1664);
																  }
																  arg2587_1654 = cons__138___r4_pairs_and_lists_6_3(arg2592_1659, list2596_1663);
															       }
															    }
															    {
															       obj_t list2589_1656;
															       {
																  obj_t arg2590_1657;
																  arg2590_1657 = MAKE_PAIR(BNIL, BNIL);
																  list2589_1656 = MAKE_PAIR(arg2587_1654, arg2590_1657);
															       }
															       arg2580_1648 = cons__138___r4_pairs_and_lists_6_3(v1_1354, list2589_1656);
															    }
															 }
															 {
															    obj_t arg2600_1667;
															    {
															       obj_t arg2606_1672;
															       obj_t arg2607_1673;
															       obj_t arg2608_1674;
															       arg2606_1672 = CNST_TABLE_REF(((long) 62));
															       arg2607_1673 = CNST_TABLE_REF(((long) 65));
															       arg2608_1674 = CNST_TABLE_REF(((long) 64));
															       {
																  obj_t list2610_1676;
																  {
																     obj_t arg2611_1677;
																     {
																	obj_t arg2612_1678;
																	arg2612_1678 = MAKE_PAIR(BNIL, BNIL);
																	arg2611_1677 = MAKE_PAIR(arg2608_1674, arg2612_1678);
																     }
																     list2610_1676 = MAKE_PAIR(arg2607_1673, arg2611_1677);
																  }
																  arg2600_1667 = cons__138___r4_pairs_and_lists_6_3(arg2606_1672, list2610_1676);
															       }
															    }
															    {
															       obj_t list2602_1669;
															       {
																  obj_t arg2603_1670;
																  arg2603_1670 = MAKE_PAIR(BNIL, BNIL);
																  list2602_1669 = MAKE_PAIR(arg2600_1667, arg2603_1670);
															       }
															       arg2582_1649 = cons__138___r4_pairs_and_lists_6_3(v2_1355, list2602_1669);
															    }
															 }
															 {
															    obj_t list2584_1651;
															    {
															       obj_t arg2585_1652;
															       arg2585_1652 = MAKE_PAIR(BNIL, BNIL);
															       list2584_1651 = MAKE_PAIR(arg2582_1649, arg2585_1652);
															    }
															    arg2575_1643 = cons__138___r4_pairs_and_lists_6_3(arg2580_1648, list2584_1651);
															 }
														      }
														      {
															 obj_t arg2614_1680;
															 arg2614_1680 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
															 arg2576_1644 = append_2_18___r4_pairs_and_lists_6_3(body_1356, arg2614_1680);
														      }
														      {
															 obj_t list2577_1645;
															 {
															    obj_t arg2578_1646;
															    arg2578_1646 = MAKE_PAIR(arg2576_1644, BNIL);
															    list2577_1645 = MAKE_PAIR(arg2575_1643, arg2578_1646);
															 }
															 arg2537_1603 = cons__138___r4_pairs_and_lists_6_3(arg2574_1642, list2577_1645);
														      }
														   }
														   {
														      obj_t list2539_1605;
														      {
															 obj_t arg2540_1606;
															 {
															    obj_t arg2541_1607;
															    arg2541_1607 = MAKE_PAIR(BNIL, BNIL);
															    arg2540_1606 = MAKE_PAIR(arg2537_1603, arg2541_1607);
															 }
															 list2539_1605 = MAKE_PAIR(arg2536_1602, arg2540_1606);
														      }
														      arg2330_1339 = cons__138___r4_pairs_and_lists_6_3(arg2535_1601, list2539_1605);
														   }
														}
													     }
													   else
													     {
														goto tag_779_252_1365;
													     }
													}
												      else
													{
													   obj_t cdr_1139_211_1426;
													   cdr_1139_211_1426 = CDR(cdr_790_30_1368);
													   {
													      obj_t cdr_1161_172_1427;
													      {
														 obj_t aux_3030;
														 aux_3030 = CAR(cdr_1139_211_1426);
														 cdr_1161_172_1427 = CDR(aux_3030);
													      }
													      {
														 obj_t car_1170_4_1428;
														 car_1170_4_1428 = CAR(cdr_1161_172_1427);
														 {
														    obj_t cdr_1180_170_1429;
														    cdr_1180_170_1429 = CDR(car_1170_4_1428);
														    {
														       obj_t cdr_1189_1_1430;
														       cdr_1189_1_1430 = CDR(cdr_1180_170_1429);
														       {
															  obj_t cdr_1196_0_1431;
															  cdr_1196_0_1431 = CDR(cdr_1189_1_1430);
															  if (PAIRP(cdr_1196_0_1431))
															    {
															       bool_t test_3039;
															       {
																  obj_t aux_3040;
																  aux_3040 = CDR(cdr_1196_0_1431);
																  test_3039 = (aux_3040 == BNIL);
															       }
															       if (test_3039)
																 {
																    bool_t test_3043;
																    {
																       obj_t aux_3044;
																       aux_3044 = CDR(cdr_1139_211_1426);
																       test_3043 = (aux_3044 == BNIL);
																    }
																    if (test_3043)
																      {
																	 producer_1358 = CAR(cdr_790_30_1368);
																	 v0_1359 = CAR(car_1170_4_1428);
																	 v1_1360 = CAR(cdr_1180_170_1429);
																	 v2_1361 = CAR(cdr_1189_1_1430);
																	 v3_1362 = CAR(cdr_1196_0_1431);
																	 body_1363 = CDR(cdr_1161_172_1427);
																	 {
																	    obj_t arg2617_1683;
																	    obj_t arg2618_1684;
																	    obj_t arg2619_1685;
																	    arg2617_1683 = CNST_TABLE_REF(((long) 37));
																	    {
																	       obj_t arg2625_1691;
																	       {
																		  obj_t arg2629_1695;
																		  {
																		     obj_t prod_1700;
																		     if (PAIRP(producer_1358))
																		       {
																			  obj_t cdr_1600_181_1705;
																			  cdr_1600_181_1705 = CDR(producer_1358);
																			  {
																			     bool_t test_3051;
																			     {
																				obj_t aux_3054;
																				obj_t aux_3052;
																				aux_3054 = CNST_TABLE_REF(((long) 2));
																				aux_3052 = CAR(producer_1358);
																				test_3051 = (aux_3052 == aux_3054);
																			     }
																			     if (test_3051)
																			       {
																				  if (PAIRP(cdr_1600_181_1705))
																				    {
																				       bool_t test_3059;
																				       {
																					  obj_t aux_3060;
																					  aux_3060 = CAR(cdr_1600_181_1705);
																					  test_3059 = (aux_3060 == BNIL);
																				       }
																				       if (test_3059)
																					 {
																					    prod_1700 = CDR(cdr_1600_181_1705);
																					    {
																					       obj_t arg2644_1714;
																					       obj_t arg2645_1715;
																					       arg2644_1714 = CNST_TABLE_REF(((long) 61));
																					       {
																						  obj_t arg2648_1718;
																						  arg2648_1718 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
																						  arg2645_1715 = append_2_18___r4_pairs_and_lists_6_3(prod_1700, arg2648_1718);
																					       }
																					       {
																						  obj_t list2646_1716;
																						  list2646_1716 = MAKE_PAIR(arg2645_1715, BNIL);
																						  arg2629_1695 = cons__138___r4_pairs_and_lists_6_3(arg2644_1714, list2646_1716);
																					       }
																					    }
																					 }
																				       else
																					 {
																					  tag_1595_125_1702:
																					    {
																					       obj_t list2652_1722;
																					       list2652_1722 = MAKE_PAIR(BNIL, BNIL);
																					       arg2629_1695 = cons__138___r4_pairs_and_lists_6_3(producer_1358, list2652_1722);
																					    }
																					 }
																				    }
																				  else
																				    {
																				       goto tag_1595_125_1702;
																				    }
																			       }
																			     else
																			       {
																				  goto tag_1595_125_1702;
																			       }
																			  }
																		       }
																		     else
																		       {
																			  goto tag_1595_125_1702;
																		       }
																		  }
																		  {
																		     obj_t list2631_1697;
																		     {
																			obj_t arg2632_1698;
																			arg2632_1698 = MAKE_PAIR(BNIL, BNIL);
																			list2631_1697 = MAKE_PAIR(arg2629_1695, arg2632_1698);
																		     }
																		     arg2625_1691 = cons__138___r4_pairs_and_lists_6_3(v0_1359, list2631_1697);
																		  }
																	       }
																	       {
																		  obj_t list2627_1693;
																		  list2627_1693 = MAKE_PAIR(BNIL, BNIL);
																		  arg2618_1684 = cons__138___r4_pairs_and_lists_6_3(arg2625_1691, list2627_1693);
																	       }
																	    }
																	    {
																	       obj_t arg2654_1724;
																	       obj_t arg2655_1725;
																	       obj_t arg2656_1726;
																	       arg2654_1724 = CNST_TABLE_REF(((long) 37));
																	       {
																		  obj_t arg2660_1730;
																		  obj_t arg2661_1731;
																		  obj_t arg2662_1732;
																		  {
																		     obj_t arg2668_1738;
																		     {
																			obj_t arg2673_1743;
																			obj_t arg2675_1744;
																			obj_t arg2676_1745;
																			arg2673_1743 = CNST_TABLE_REF(((long) 62));
																			arg2675_1744 = CNST_TABLE_REF(((long) 63));
																			arg2676_1745 = CNST_TABLE_REF(((long) 64));
																			{
																			   obj_t list2678_1747;
																			   {
																			      obj_t arg2679_1748;
																			      {
																				 obj_t arg2680_1749;
																				 arg2680_1749 = MAKE_PAIR(BNIL, BNIL);
																				 arg2679_1748 = MAKE_PAIR(arg2676_1745, arg2680_1749);
																			      }
																			      list2678_1747 = MAKE_PAIR(arg2675_1744, arg2679_1748);
																			   }
																			   arg2668_1738 = cons__138___r4_pairs_and_lists_6_3(arg2673_1743, list2678_1747);
																			}
																		     }
																		     {
																			obj_t list2670_1740;
																			{
																			   obj_t arg2671_1741;
																			   arg2671_1741 = MAKE_PAIR(BNIL, BNIL);
																			   list2670_1740 = MAKE_PAIR(arg2668_1738, arg2671_1741);
																			}
																			arg2660_1730 = cons__138___r4_pairs_and_lists_6_3(v1_1360, list2670_1740);
																		     }
																		  }
																		  {
																		     obj_t arg2683_1751;
																		     {
																			obj_t arg2689_1756;
																			obj_t arg2690_1757;
																			obj_t arg2691_1758;
																			arg2689_1756 = CNST_TABLE_REF(((long) 62));
																			arg2690_1757 = CNST_TABLE_REF(((long) 65));
																			arg2691_1758 = CNST_TABLE_REF(((long) 64));
																			{
																			   obj_t list2693_1760;
																			   {
																			      obj_t arg2694_1761;
																			      {
																				 obj_t arg2695_1762;
																				 arg2695_1762 = MAKE_PAIR(BNIL, BNIL);
																				 arg2694_1761 = MAKE_PAIR(arg2691_1758, arg2695_1762);
																			      }
																			      list2693_1760 = MAKE_PAIR(arg2690_1757, arg2694_1761);
																			   }
																			   arg2683_1751 = cons__138___r4_pairs_and_lists_6_3(arg2689_1756, list2693_1760);
																			}
																		     }
																		     {
																			obj_t list2685_1753;
																			{
																			   obj_t arg2687_1754;
																			   arg2687_1754 = MAKE_PAIR(BNIL, BNIL);
																			   list2685_1753 = MAKE_PAIR(arg2683_1751, arg2687_1754);
																			}
																			arg2661_1731 = cons__138___r4_pairs_and_lists_6_3(v2_1361, list2685_1753);
																		     }
																		  }
																		  {
																		     obj_t arg2697_1764;
																		     {
																			obj_t arg2702_1769;
																			obj_t arg2703_1770;
																			obj_t arg2704_1771;
																			arg2702_1769 = CNST_TABLE_REF(((long) 62));
																			arg2703_1770 = CNST_TABLE_REF(((long) 66));
																			arg2704_1771 = CNST_TABLE_REF(((long) 64));
																			{
																			   obj_t list2706_1773;
																			   {
																			      obj_t arg2707_1774;
																			      {
																				 obj_t arg2708_1775;
																				 arg2708_1775 = MAKE_PAIR(BNIL, BNIL);
																				 arg2707_1774 = MAKE_PAIR(arg2704_1771, arg2708_1775);
																			      }
																			      list2706_1773 = MAKE_PAIR(arg2703_1770, arg2707_1774);
																			   }
																			   arg2697_1764 = cons__138___r4_pairs_and_lists_6_3(arg2702_1769, list2706_1773);
																			}
																		     }
																		     {
																			obj_t list2699_1766;
																			{
																			   obj_t arg2700_1767;
																			   arg2700_1767 = MAKE_PAIR(BNIL, BNIL);
																			   list2699_1766 = MAKE_PAIR(arg2697_1764, arg2700_1767);
																			}
																			arg2662_1732 = cons__138___r4_pairs_and_lists_6_3(v3_1362, list2699_1766);
																		     }
																		  }
																		  {
																		     obj_t list2664_1734;
																		     {
																			obj_t arg2665_1735;
																			{
																			   obj_t arg2666_1736;
																			   arg2666_1736 = MAKE_PAIR(BNIL, BNIL);
																			   arg2665_1735 = MAKE_PAIR(arg2662_1732, arg2666_1736);
																			}
																			list2664_1734 = MAKE_PAIR(arg2661_1731, arg2665_1735);
																		     }
																		     arg2655_1725 = cons__138___r4_pairs_and_lists_6_3(arg2660_1730, list2664_1734);
																		  }
																	       }
																	       {
																		  obj_t arg2710_1777;
																		  arg2710_1777 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
																		  arg2656_1726 = append_2_18___r4_pairs_and_lists_6_3(body_1363, arg2710_1777);
																	       }
																	       {
																		  obj_t list2657_1727;
																		  {
																		     obj_t arg2658_1728;
																		     arg2658_1728 = MAKE_PAIR(arg2656_1726, BNIL);
																		     list2657_1727 = MAKE_PAIR(arg2655_1725, arg2658_1728);
																		  }
																		  arg2619_1685 = cons__138___r4_pairs_and_lists_6_3(arg2654_1724, list2657_1727);
																	       }
																	    }
																	    {
																	       obj_t list2621_1687;
																	       {
																		  obj_t arg2622_1688;
																		  {
																		     obj_t arg2623_1689;
																		     arg2623_1689 = MAKE_PAIR(BNIL, BNIL);
																		     arg2622_1688 = MAKE_PAIR(arg2619_1685, arg2623_1689);
																		  }
																		  list2621_1687 = MAKE_PAIR(arg2618_1684, arg2622_1688);
																	       }
																	       arg2330_1339 = cons__138___r4_pairs_and_lists_6_3(arg2617_1683, list2621_1687);
																	    }
																	 }
																      }
																    else
																      {
																	 goto tag_779_252_1365;
																      }
																 }
															       else
																 {
																    goto tag_779_252_1365;
																 }
															    }
															  else
															    {
															       goto tag_779_252_1365;
															    }
														       }
														    }
														 }
													      }
													   }
													}
												   }
												 else
												   {
												      goto tag_779_252_1365;
												   }
											      }
											   }
											}
										     }
										  }
									     }
									   else
									     {
										goto tag_779_252_1365;
									     }
									}
								     }
								  }
							       }
							  }
							else
							  {
							     goto tag_779_252_1365;
							  }
						     }
						  }
					       }
					  }
					else
					  {
					     goto tag_779_252_1365;
					  }
				     }
				   else
				     {
					goto tag_779_252_1365;
				     }
				}
			     }
			   else
			     {
				goto tag_779_252_1365;
			     }
			}
		      else
			{
			   goto tag_779_252_1365;
			}
		   }
		 else
		   {
		      goto tag_779_252_1365;
		   }
	      }
	    else
	      {
		 goto tag_779_252_1365;
	      }
	 }
	 return PROCEDURE_ENTRY(e_1337) (e_1337, arg2330_1339, e_1337, BEOA);
      }
   }
}


/* arg1901 */ obj_t 
arg1901_expand_install(obj_t env_2368, obj_t x_2369, obj_t e_2370)
{
   {
      obj_t x_904;
      obj_t e_905;
      x_904 = x_2369;
      e_905 = e_2370;
      {
	 obj_t val0_917;
	 obj_t val1_918;
	 obj_t val2_919;
	 obj_t val3_920;
	 obj_t val0_913;
	 obj_t val1_914;
	 obj_t val2_915;
	 obj_t val0_910;
	 obj_t val1_911;
	 obj_t val0_908;
	 if (PAIRP(x_904))
	   {
	      bool_t test_3130;
	      {
		 obj_t aux_3131;
		 aux_3131 = CDR(x_904);
		 test_3130 = (aux_3131 == BNIL);
	      }
	      if (test_3130)
		{
		   return CNST_TABLE_REF(((long) 74));
		}
	      else
		{
		   obj_t cdr_600_102_926;
		   cdr_600_102_926 = CDR(x_904);
		   if (PAIRP(cdr_600_102_926))
		     {
			bool_t test_3138;
			{
			   obj_t aux_3139;
			   aux_3139 = CDR(cdr_600_102_926);
			   test_3138 = (aux_3139 == BNIL);
			}
			if (test_3138)
			  {
			     val0_908 = CAR(cdr_600_102_926);
			     {
				obj_t g0_964;
				{
				   obj_t arg1972_999;
				   arg1972_999 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 67)), BEOA);
				   g0_964 = mark_symbol_non_user__17_ast_ident(arg1972_999);
				}
				{
				   obj_t arg1935_965;
				   obj_t arg1936_966;
				   obj_t arg1937_967;
				   arg1935_965 = CNST_TABLE_REF(((long) 37));
				   {
				      obj_t arg1944_974;
				      {
					 obj_t arg1948_978;
					 arg1948_978 = PROCEDURE_ENTRY(e_905) (e_905, val0_908, e_905, BEOA);
					 {
					    obj_t list1950_980;
					    {
					       obj_t arg1951_981;
					       arg1951_981 = MAKE_PAIR(BNIL, BNIL);
					       list1950_980 = MAKE_PAIR(arg1948_978, arg1951_981);
					    }
					    arg1944_974 = cons__138___r4_pairs_and_lists_6_3(g0_964, list1950_980);
					 }
				      }
				      {
					 obj_t list1946_976;
					 list1946_976 = MAKE_PAIR(BNIL, BNIL);
					 arg1936_966 = cons__138___r4_pairs_and_lists_6_3(arg1944_974, list1946_976);
				      }
				   }
				   {
				      obj_t arg1953_983;
				      obj_t arg1954_984;
				      arg1953_983 = CNST_TABLE_REF(((long) 8));
				      {
					 obj_t arg1962_991;
					 obj_t arg1963_992;
					 obj_t arg1964_993;
					 arg1962_991 = CNST_TABLE_REF(((long) 62));
					 arg1963_992 = CNST_TABLE_REF(((long) 68));
					 arg1964_993 = CNST_TABLE_REF(((long) 64));
					 {
					    obj_t list1966_995;
					    {
					       obj_t arg1967_996;
					       {
						  obj_t arg1970_997;
						  arg1970_997 = MAKE_PAIR(BNIL, BNIL);
						  arg1967_996 = MAKE_PAIR(arg1964_993, arg1970_997);
					       }
					       list1966_995 = MAKE_PAIR(arg1963_992, arg1967_996);
					    }
					    arg1954_984 = cons__138___r4_pairs_and_lists_6_3(arg1962_991, list1966_995);
					 }
				      }
				      {
					 obj_t list1958_987;
					 {
					    obj_t arg1959_988;
					    {
					       obj_t arg1960_989;
					       arg1960_989 = MAKE_PAIR(BNIL, BNIL);
					       {
						  obj_t aux_3163;
						  aux_3163 = BINT(((long) 1));
						  arg1959_988 = MAKE_PAIR(aux_3163, arg1960_989);
					       }
					    }
					    list1958_987 = MAKE_PAIR(arg1954_984, arg1959_988);
					 }
					 arg1937_967 = cons__138___r4_pairs_and_lists_6_3(arg1953_983, list1958_987);
				      }
				   }
				   {
				      obj_t list1939_969;
				      {
					 obj_t arg1940_970;
					 {
					    obj_t arg1941_971;
					    {
					       obj_t arg1942_972;
					       arg1942_972 = MAKE_PAIR(BNIL, BNIL);
					       arg1941_971 = MAKE_PAIR(g0_964, arg1942_972);
					    }
					    arg1940_970 = MAKE_PAIR(arg1937_967, arg1941_971);
					 }
					 list1939_969 = MAKE_PAIR(arg1936_966, arg1940_970);
				      }
				      return cons__138___r4_pairs_and_lists_6_3(arg1935_965, list1939_969);
				   }
				}
			     }
			  }
			else
			  {
			     obj_t cdr_618_232_931;
			     cdr_618_232_931 = CDR(cdr_600_102_926);
			     if (PAIRP(cdr_618_232_931))
			       {
				  bool_t test_3177;
				  {
				     obj_t aux_3178;
				     aux_3178 = CDR(cdr_618_232_931);
				     test_3177 = (aux_3178 == BNIL);
				  }
				  if (test_3177)
				    {
				       val0_910 = CAR(cdr_600_102_926);
				       val1_911 = CAR(cdr_618_232_931);
				       {
					  obj_t g0_1001;
					  obj_t g1_1002;
					  {
					     obj_t arg2042_1061;
					     arg2042_1061 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 67)), BEOA);
					     g0_1001 = mark_symbol_non_user__17_ast_ident(arg2042_1061);
					  }
					  {
					     obj_t arg2044_1063;
					     arg2044_1063 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 69)), BEOA);
					     g1_1002 = mark_symbol_non_user__17_ast_ident(arg2044_1063);
					  }
					  {
					     obj_t arg1974_1003;
					     obj_t arg1975_1004;
					     obj_t arg1977_1005;
					     obj_t arg1978_1006;
					     arg1974_1003 = CNST_TABLE_REF(((long) 37));
					     {
						obj_t arg1986_1014;
						obj_t arg1987_1015;
						{
						   obj_t arg1992_1020;
						   arg1992_1020 = PROCEDURE_ENTRY(e_905) (e_905, val0_910, e_905, BEOA);
						   {
						      obj_t list1994_1022;
						      {
							 obj_t arg1995_1023;
							 arg1995_1023 = MAKE_PAIR(BNIL, BNIL);
							 list1994_1022 = MAKE_PAIR(arg1992_1020, arg1995_1023);
						      }
						      arg1986_1014 = cons__138___r4_pairs_and_lists_6_3(g0_1001, list1994_1022);
						   }
						}
						{
						   obj_t arg2000_1025;
						   arg2000_1025 = PROCEDURE_ENTRY(e_905) (e_905, val1_911, e_905, BEOA);
						   {
						      obj_t list2002_1027;
						      {
							 obj_t arg2003_1028;
							 arg2003_1028 = MAKE_PAIR(BNIL, BNIL);
							 list2002_1027 = MAKE_PAIR(arg2000_1025, arg2003_1028);
						      }
						      arg1987_1015 = cons__138___r4_pairs_and_lists_6_3(g1_1002, list2002_1027);
						   }
						}
						{
						   obj_t list1989_1017;
						   {
						      obj_t arg1990_1018;
						      arg1990_1018 = MAKE_PAIR(BNIL, BNIL);
						      list1989_1017 = MAKE_PAIR(arg1987_1015, arg1990_1018);
						   }
						   arg1975_1004 = cons__138___r4_pairs_and_lists_6_3(arg1986_1014, list1989_1017);
						}
					     }
					     {
						obj_t arg2006_1030;
						obj_t arg2008_1031;
						arg2006_1030 = CNST_TABLE_REF(((long) 8));
						{
						   obj_t arg2016_1038;
						   obj_t arg2017_1039;
						   obj_t arg2018_1040;
						   arg2016_1038 = CNST_TABLE_REF(((long) 62));
						   arg2017_1039 = CNST_TABLE_REF(((long) 68));
						   arg2018_1040 = CNST_TABLE_REF(((long) 64));
						   {
						      obj_t list2020_1042;
						      {
							 obj_t arg2021_1043;
							 {
							    obj_t arg2022_1044;
							    arg2022_1044 = MAKE_PAIR(BNIL, BNIL);
							    arg2021_1043 = MAKE_PAIR(arg2018_1040, arg2022_1044);
							 }
							 list2020_1042 = MAKE_PAIR(arg2017_1039, arg2021_1043);
						      }
						      arg2008_1031 = cons__138___r4_pairs_and_lists_6_3(arg2016_1038, list2020_1042);
						   }
						}
						{
						   obj_t list2012_1034;
						   {
						      obj_t arg2013_1035;
						      {
							 obj_t arg2014_1036;
							 arg2014_1036 = MAKE_PAIR(BNIL, BNIL);
							 {
							    obj_t aux_3212;
							    aux_3212 = BINT(((long) 2));
							    arg2013_1035 = MAKE_PAIR(aux_3212, arg2014_1036);
							 }
						      }
						      list2012_1034 = MAKE_PAIR(arg2008_1031, arg2013_1035);
						   }
						   arg1977_1005 = cons__138___r4_pairs_and_lists_6_3(arg2006_1030, list2012_1034);
						}
					     }
					     {
						obj_t arg2024_1046;
						obj_t arg2026_1047;
						arg2024_1046 = CNST_TABLE_REF(((long) 8));
						{
						   obj_t arg2032_1053;
						   obj_t arg2033_1054;
						   obj_t arg2035_1055;
						   arg2032_1053 = CNST_TABLE_REF(((long) 62));
						   arg2033_1054 = CNST_TABLE_REF(((long) 63));
						   arg2035_1055 = CNST_TABLE_REF(((long) 64));
						   {
						      obj_t list2038_1057;
						      {
							 obj_t arg2039_1058;
							 {
							    obj_t arg2040_1059;
							    arg2040_1059 = MAKE_PAIR(BNIL, BNIL);
							    arg2039_1058 = MAKE_PAIR(arg2035_1055, arg2040_1059);
							 }
							 list2038_1057 = MAKE_PAIR(arg2033_1054, arg2039_1058);
						      }
						      arg2026_1047 = cons__138___r4_pairs_and_lists_6_3(arg2032_1053, list2038_1057);
						   }
						}
						{
						   obj_t list2028_1049;
						   {
						      obj_t arg2029_1050;
						      {
							 obj_t arg2030_1051;
							 arg2030_1051 = MAKE_PAIR(BNIL, BNIL);
							 arg2029_1050 = MAKE_PAIR(g1_1002, arg2030_1051);
						      }
						      list2028_1049 = MAKE_PAIR(arg2026_1047, arg2029_1050);
						   }
						   arg1978_1006 = cons__138___r4_pairs_and_lists_6_3(arg2024_1046, list2028_1049);
						}
					     }
					     {
						obj_t list1980_1008;
						{
						   obj_t arg1981_1009;
						   {
						      obj_t arg1982_1010;
						      {
							 obj_t arg1983_1011;
							 {
							    obj_t arg1984_1012;
							    arg1984_1012 = MAKE_PAIR(BNIL, BNIL);
							    arg1983_1011 = MAKE_PAIR(g0_1001, arg1984_1012);
							 }
							 arg1982_1010 = MAKE_PAIR(arg1978_1006, arg1983_1011);
						      }
						      arg1981_1009 = MAKE_PAIR(arg1977_1005, arg1982_1010);
						   }
						   list1980_1008 = MAKE_PAIR(arg1975_1004, arg1981_1009);
						}
						return cons__138___r4_pairs_and_lists_6_3(arg1974_1003, list1980_1008);
					     }
					  }
				       }
				    }
				  else
				    {
				       obj_t cdr_642_200_937;
				       cdr_642_200_937 = CDR(cdr_600_102_926);
				       {
					  obj_t cdr_649_123_938;
					  cdr_649_123_938 = CDR(cdr_642_200_937);
					  if (PAIRP(cdr_649_123_938))
					    {
					       bool_t test_3241;
					       {
						  obj_t aux_3242;
						  aux_3242 = CDR(cdr_649_123_938);
						  test_3241 = (aux_3242 == BNIL);
					       }
					       if (test_3241)
						 {
						    val0_913 = CAR(cdr_600_102_926);
						    val1_914 = CAR(cdr_642_200_937);
						    val2_915 = CAR(cdr_649_123_938);
						    {
						       obj_t g0_1065;
						       obj_t g1_1066;
						       obj_t g2_1067;
						       {
							  obj_t arg2136_1150;
							  arg2136_1150 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 67)), BEOA);
							  g0_1065 = mark_symbol_non_user__17_ast_ident(arg2136_1150);
						       }
						       {
							  obj_t arg2138_1152;
							  arg2138_1152 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 69)), BEOA);
							  g1_1066 = mark_symbol_non_user__17_ast_ident(arg2138_1152);
						       }
						       {
							  obj_t arg2140_1154;
							  arg2140_1154 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 70)), BEOA);
							  g2_1067 = mark_symbol_non_user__17_ast_ident(arg2140_1154);
						       }
						       {
							  obj_t arg2046_1068;
							  obj_t arg2047_1069;
							  obj_t arg2048_1070;
							  obj_t arg2049_1071;
							  obj_t arg2050_1072;
							  arg2046_1068 = CNST_TABLE_REF(((long) 37));
							  {
							     obj_t arg2059_1081;
							     obj_t arg2060_1082;
							     obj_t arg2061_1083;
							     {
								obj_t arg2068_1089;
								arg2068_1089 = PROCEDURE_ENTRY(e_905) (e_905, val0_913, e_905, BEOA);
								{
								   obj_t list2070_1091;
								   {
								      obj_t arg2071_1092;
								      arg2071_1092 = MAKE_PAIR(BNIL, BNIL);
								      list2070_1091 = MAKE_PAIR(arg2068_1089, arg2071_1092);
								   }
								   arg2059_1081 = cons__138___r4_pairs_and_lists_6_3(g0_1065, list2070_1091);
								}
							     }
							     {
								obj_t arg2073_1094;
								arg2073_1094 = PROCEDURE_ENTRY(e_905) (e_905, val1_914, e_905, BEOA);
								{
								   obj_t list2075_1096;
								   {
								      obj_t arg2076_1097;
								      arg2076_1097 = MAKE_PAIR(BNIL, BNIL);
								      list2075_1096 = MAKE_PAIR(arg2073_1094, arg2076_1097);
								   }
								   arg2060_1082 = cons__138___r4_pairs_and_lists_6_3(g1_1066, list2075_1096);
								}
							     }
							     {
								obj_t arg2078_1099;
								arg2078_1099 = PROCEDURE_ENTRY(e_905) (e_905, val2_915, e_905, BEOA);
								{
								   obj_t list2080_1101;
								   {
								      obj_t arg2081_1102;
								      arg2081_1102 = MAKE_PAIR(BNIL, BNIL);
								      list2080_1101 = MAKE_PAIR(arg2078_1099, arg2081_1102);
								   }
								   arg2061_1083 = cons__138___r4_pairs_and_lists_6_3(g2_1067, list2080_1101);
								}
							     }
							     {
								obj_t list2063_1085;
								{
								   obj_t arg2064_1086;
								   {
								      obj_t arg2065_1087;
								      arg2065_1087 = MAKE_PAIR(BNIL, BNIL);
								      arg2064_1086 = MAKE_PAIR(arg2061_1083, arg2065_1087);
								   }
								   list2063_1085 = MAKE_PAIR(arg2060_1082, arg2064_1086);
								}
								arg2047_1069 = cons__138___r4_pairs_and_lists_6_3(arg2059_1081, list2063_1085);
							     }
							  }
							  {
							     obj_t arg2083_1104;
							     obj_t arg2084_1105;
							     arg2083_1104 = CNST_TABLE_REF(((long) 8));
							     {
								obj_t arg2091_1112;
								obj_t arg2092_1113;
								obj_t arg2093_1114;
								arg2091_1112 = CNST_TABLE_REF(((long) 62));
								arg2092_1113 = CNST_TABLE_REF(((long) 68));
								arg2093_1114 = CNST_TABLE_REF(((long) 64));
								{
								   obj_t list2095_1116;
								   {
								      obj_t arg2096_1117;
								      {
									 obj_t arg2097_1118;
									 arg2097_1118 = MAKE_PAIR(BNIL, BNIL);
									 arg2096_1117 = MAKE_PAIR(arg2093_1114, arg2097_1118);
								      }
								      list2095_1116 = MAKE_PAIR(arg2092_1113, arg2096_1117);
								   }
								   arg2084_1105 = cons__138___r4_pairs_and_lists_6_3(arg2091_1112, list2095_1116);
								}
							     }
							     {
								obj_t list2087_1108;
								{
								   obj_t arg2088_1109;
								   {
								      obj_t arg2089_1110;
								      arg2089_1110 = MAKE_PAIR(BNIL, BNIL);
								      {
									 obj_t aux_3286;
									 aux_3286 = BINT(((long) 3));
									 arg2088_1109 = MAKE_PAIR(aux_3286, arg2089_1110);
								      }
								   }
								   list2087_1108 = MAKE_PAIR(arg2084_1105, arg2088_1109);
								}
								arg2048_1070 = cons__138___r4_pairs_and_lists_6_3(arg2083_1104, list2087_1108);
							     }
							  }
							  {
							     obj_t arg2099_1120;
							     obj_t arg2100_1121;
							     arg2099_1120 = CNST_TABLE_REF(((long) 8));
							     {
								obj_t arg2107_1127;
								obj_t arg2108_1128;
								obj_t arg2109_1129;
								arg2107_1127 = CNST_TABLE_REF(((long) 62));
								arg2108_1128 = CNST_TABLE_REF(((long) 63));
								arg2109_1129 = CNST_TABLE_REF(((long) 64));
								{
								   obj_t list2112_1131;
								   {
								      obj_t arg2113_1132;
								      {
									 obj_t arg2114_1133;
									 arg2114_1133 = MAKE_PAIR(BNIL, BNIL);
									 arg2113_1132 = MAKE_PAIR(arg2109_1129, arg2114_1133);
								      }
								      list2112_1131 = MAKE_PAIR(arg2108_1128, arg2113_1132);
								   }
								   arg2100_1121 = cons__138___r4_pairs_and_lists_6_3(arg2107_1127, list2112_1131);
								}
							     }
							     {
								obj_t list2102_1123;
								{
								   obj_t arg2103_1124;
								   {
								      obj_t arg2105_1125;
								      arg2105_1125 = MAKE_PAIR(BNIL, BNIL);
								      arg2103_1124 = MAKE_PAIR(g1_1066, arg2105_1125);
								   }
								   list2102_1123 = MAKE_PAIR(arg2100_1121, arg2103_1124);
								}
								arg2049_1071 = cons__138___r4_pairs_and_lists_6_3(arg2099_1120, list2102_1123);
							     }
							  }
							  {
							     obj_t arg2116_1135;
							     obj_t arg2117_1136;
							     arg2116_1135 = CNST_TABLE_REF(((long) 8));
							     {
								obj_t arg2125_1142;
								obj_t arg2127_1143;
								obj_t arg2129_1144;
								arg2125_1142 = CNST_TABLE_REF(((long) 62));
								arg2127_1143 = CNST_TABLE_REF(((long) 65));
								arg2129_1144 = CNST_TABLE_REF(((long) 64));
								{
								   obj_t list2132_1146;
								   {
								      obj_t arg2133_1147;
								      {
									 obj_t arg2134_1148;
									 arg2134_1148 = MAKE_PAIR(BNIL, BNIL);
									 arg2133_1147 = MAKE_PAIR(arg2129_1144, arg2134_1148);
								      }
								      list2132_1146 = MAKE_PAIR(arg2127_1143, arg2133_1147);
								   }
								   arg2117_1136 = cons__138___r4_pairs_and_lists_6_3(arg2125_1142, list2132_1146);
								}
							     }
							     {
								obj_t list2121_1138;
								{
								   obj_t arg2122_1139;
								   {
								      obj_t arg2123_1140;
								      arg2123_1140 = MAKE_PAIR(BNIL, BNIL);
								      arg2122_1139 = MAKE_PAIR(g2_1067, arg2123_1140);
								   }
								   list2121_1138 = MAKE_PAIR(arg2117_1136, arg2122_1139);
								}
								arg2050_1072 = cons__138___r4_pairs_and_lists_6_3(arg2116_1135, list2121_1138);
							     }
							  }
							  {
							     obj_t list2052_1074;
							     {
								obj_t arg2053_1075;
								{
								   obj_t arg2054_1076;
								   {
								      obj_t arg2055_1077;
								      {
									 obj_t arg2056_1078;
									 {
									    obj_t arg2057_1079;
									    arg2057_1079 = MAKE_PAIR(BNIL, BNIL);
									    arg2056_1078 = MAKE_PAIR(g0_1065, arg2057_1079);
									 }
									 arg2055_1077 = MAKE_PAIR(arg2050_1072, arg2056_1078);
								      }
								      arg2054_1076 = MAKE_PAIR(arg2049_1071, arg2055_1077);
								   }
								   arg2053_1075 = MAKE_PAIR(arg2048_1070, arg2054_1076);
								}
								list2052_1074 = MAKE_PAIR(arg2047_1069, arg2053_1075);
							     }
							     return cons__138___r4_pairs_and_lists_6_3(arg2046_1068, list2052_1074);
							  }
						       }
						    }
						 }
					       else
						 {
						    obj_t cdr_677_237_945;
						    cdr_677_237_945 = CDR(cdr_600_102_926);
						    {
						       obj_t cdr_686_6_946;
						       cdr_686_6_946 = CDR(cdr_677_237_945);
						       {
							  obj_t cdr_693_115_947;
							  cdr_693_115_947 = CDR(cdr_686_6_946);
							  if (PAIRP(cdr_693_115_947))
							    {
							       bool_t test_3330;
							       {
								  obj_t aux_3331;
								  aux_3331 = CDR(cdr_693_115_947);
								  test_3330 = (aux_3331 == BNIL);
							       }
							       if (test_3330)
								 {
								    val0_917 = CAR(cdr_600_102_926);
								    val1_918 = CAR(cdr_677_237_945);
								    val2_919 = CAR(cdr_686_6_946);
								    val3_920 = CAR(cdr_693_115_947);
								    {
								       obj_t g0_1156;
								       obj_t g1_1157;
								       obj_t g2_1158;
								       obj_t g3_1159;
								       {
									  obj_t arg2258_1266;
									  arg2258_1266 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 67)), BEOA);
									  g0_1156 = mark_symbol_non_user__17_ast_ident(arg2258_1266);
								       }
								       {
									  obj_t arg2260_1268;
									  arg2260_1268 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 69)), BEOA);
									  g1_1157 = mark_symbol_non_user__17_ast_ident(arg2260_1268);
								       }
								       {
									  obj_t arg2263_1270;
									  arg2263_1270 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 70)), BEOA);
									  g2_1158 = mark_symbol_non_user__17_ast_ident(arg2263_1270);
								       }
								       {
									  obj_t arg2265_1272;
									  arg2265_1272 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 71)), BEOA);
									  g3_1159 = mark_symbol_non_user__17_ast_ident(arg2265_1272);
								       }
								       {
									  obj_t arg2143_1160;
									  obj_t arg2144_1161;
									  obj_t arg2145_1162;
									  obj_t arg2146_1163;
									  obj_t arg2147_1164;
									  obj_t arg2148_1165;
									  arg2143_1160 = CNST_TABLE_REF(((long) 37));
									  {
									     obj_t arg2158_1175;
									     obj_t arg2159_1176;
									     obj_t arg2160_1177;
									     obj_t arg2161_1178;
									     {
										obj_t arg2169_1185;
										arg2169_1185 = PROCEDURE_ENTRY(e_905) (e_905, val0_917, e_905, BEOA);
										{
										   obj_t list2171_1187;
										   {
										      obj_t arg2172_1188;
										      arg2172_1188 = MAKE_PAIR(BNIL, BNIL);
										      list2171_1187 = MAKE_PAIR(arg2169_1185, arg2172_1188);
										   }
										   arg2158_1175 = cons__138___r4_pairs_and_lists_6_3(g0_1156, list2171_1187);
										}
									     }
									     {
										obj_t arg2174_1190;
										arg2174_1190 = PROCEDURE_ENTRY(e_905) (e_905, val1_918, e_905, BEOA);
										{
										   obj_t list2176_1192;
										   {
										      obj_t arg2178_1193;
										      arg2178_1193 = MAKE_PAIR(BNIL, BNIL);
										      list2176_1192 = MAKE_PAIR(arg2174_1190, arg2178_1193);
										   }
										   arg2159_1176 = cons__138___r4_pairs_and_lists_6_3(g1_1157, list2176_1192);
										}
									     }
									     {
										obj_t arg2180_1195;
										arg2180_1195 = PROCEDURE_ENTRY(e_905) (e_905, val2_919, e_905, BEOA);
										{
										   obj_t list2182_1197;
										   {
										      obj_t arg2183_1198;
										      arg2183_1198 = MAKE_PAIR(BNIL, BNIL);
										      list2182_1197 = MAKE_PAIR(arg2180_1195, arg2183_1198);
										   }
										   arg2160_1177 = cons__138___r4_pairs_and_lists_6_3(g2_1158, list2182_1197);
										}
									     }
									     {
										obj_t arg2185_1200;
										arg2185_1200 = PROCEDURE_ENTRY(e_905) (e_905, val3_920, e_905, BEOA);
										{
										   obj_t list2187_1202;
										   {
										      obj_t arg2188_1203;
										      arg2188_1203 = MAKE_PAIR(BNIL, BNIL);
										      list2187_1202 = MAKE_PAIR(arg2185_1200, arg2188_1203);
										   }
										   arg2161_1178 = cons__138___r4_pairs_and_lists_6_3(g3_1159, list2187_1202);
										}
									     }
									     {
										obj_t list2163_1180;
										{
										   obj_t arg2164_1181;
										   {
										      obj_t arg2165_1182;
										      {
											 obj_t arg2166_1183;
											 arg2166_1183 = MAKE_PAIR(BNIL, BNIL);
											 arg2165_1182 = MAKE_PAIR(arg2161_1178, arg2166_1183);
										      }
										      arg2164_1181 = MAKE_PAIR(arg2160_1177, arg2165_1182);
										   }
										   list2163_1180 = MAKE_PAIR(arg2159_1176, arg2164_1181);
										}
										arg2144_1161 = cons__138___r4_pairs_and_lists_6_3(arg2158_1175, list2163_1180);
									     }
									  }
									  {
									     obj_t arg2190_1205;
									     obj_t arg2191_1206;
									     arg2190_1205 = CNST_TABLE_REF(((long) 8));
									     {
										obj_t arg2199_1213;
										obj_t arg2200_1214;
										obj_t arg2201_1215;
										arg2199_1213 = CNST_TABLE_REF(((long) 62));
										arg2200_1214 = CNST_TABLE_REF(((long) 68));
										arg2201_1215 = CNST_TABLE_REF(((long) 64));
										{
										   obj_t list2203_1217;
										   {
										      obj_t arg2204_1218;
										      {
											 obj_t arg2205_1219;
											 arg2205_1219 = MAKE_PAIR(BNIL, BNIL);
											 arg2204_1218 = MAKE_PAIR(arg2201_1215, arg2205_1219);
										      }
										      list2203_1217 = MAKE_PAIR(arg2200_1214, arg2204_1218);
										   }
										   arg2191_1206 = cons__138___r4_pairs_and_lists_6_3(arg2199_1213, list2203_1217);
										}
									     }
									     {
										obj_t list2194_1209;
										{
										   obj_t arg2196_1210;
										   {
										      obj_t arg2197_1211;
										      arg2197_1211 = MAKE_PAIR(BNIL, BNIL);
										      {
											 obj_t aux_3385;
											 aux_3385 = BINT(((long) 4));
											 arg2196_1210 = MAKE_PAIR(aux_3385, arg2197_1211);
										      }
										   }
										   list2194_1209 = MAKE_PAIR(arg2191_1206, arg2196_1210);
										}
										arg2145_1162 = cons__138___r4_pairs_and_lists_6_3(arg2190_1205, list2194_1209);
									     }
									  }
									  {
									     obj_t arg2207_1221;
									     obj_t arg2208_1222;
									     arg2207_1221 = CNST_TABLE_REF(((long) 8));
									     {
										obj_t arg2215_1228;
										obj_t arg2216_1229;
										obj_t arg2217_1230;
										arg2215_1228 = CNST_TABLE_REF(((long) 62));
										arg2216_1229 = CNST_TABLE_REF(((long) 63));
										arg2217_1230 = CNST_TABLE_REF(((long) 64));
										{
										   obj_t list2220_1232;
										   {
										      obj_t arg2221_1233;
										      {
											 obj_t arg2222_1234;
											 arg2222_1234 = MAKE_PAIR(BNIL, BNIL);
											 arg2221_1233 = MAKE_PAIR(arg2217_1230, arg2222_1234);
										      }
										      list2220_1232 = MAKE_PAIR(arg2216_1229, arg2221_1233);
										   }
										   arg2208_1222 = cons__138___r4_pairs_and_lists_6_3(arg2215_1228, list2220_1232);
										}
									     }
									     {
										obj_t list2210_1224;
										{
										   obj_t arg2211_1225;
										   {
										      obj_t arg2213_1226;
										      arg2213_1226 = MAKE_PAIR(BNIL, BNIL);
										      arg2211_1225 = MAKE_PAIR(g1_1157, arg2213_1226);
										   }
										   list2210_1224 = MAKE_PAIR(arg2208_1222, arg2211_1225);
										}
										arg2146_1163 = cons__138___r4_pairs_and_lists_6_3(arg2207_1221, list2210_1224);
									     }
									  }
									  {
									     obj_t arg2224_1236;
									     obj_t arg2225_1237;
									     arg2224_1236 = CNST_TABLE_REF(((long) 8));
									     {
										obj_t arg2231_1243;
										obj_t arg2232_1244;
										obj_t arg2233_1245;
										arg2231_1243 = CNST_TABLE_REF(((long) 62));
										arg2232_1244 = CNST_TABLE_REF(((long) 65));
										arg2233_1245 = CNST_TABLE_REF(((long) 64));
										{
										   obj_t list2235_1247;
										   {
										      obj_t arg2236_1248;
										      {
											 obj_t arg2237_1249;
											 arg2237_1249 = MAKE_PAIR(BNIL, BNIL);
											 arg2236_1248 = MAKE_PAIR(arg2233_1245, arg2237_1249);
										      }
										      list2235_1247 = MAKE_PAIR(arg2232_1244, arg2236_1248);
										   }
										   arg2225_1237 = cons__138___r4_pairs_and_lists_6_3(arg2231_1243, list2235_1247);
										}
									     }
									     {
										obj_t list2227_1239;
										{
										   obj_t arg2228_1240;
										   {
										      obj_t arg2229_1241;
										      arg2229_1241 = MAKE_PAIR(BNIL, BNIL);
										      arg2228_1240 = MAKE_PAIR(g2_1158, arg2229_1241);
										   }
										   list2227_1239 = MAKE_PAIR(arg2225_1237, arg2228_1240);
										}
										arg2147_1164 = cons__138___r4_pairs_and_lists_6_3(arg2224_1236, list2227_1239);
									     }
									  }
									  {
									     obj_t arg2239_1251;
									     obj_t arg2240_1252;
									     arg2239_1251 = CNST_TABLE_REF(((long) 8));
									     {
										obj_t arg2247_1258;
										obj_t arg2248_1259;
										obj_t arg2250_1260;
										arg2247_1258 = CNST_TABLE_REF(((long) 62));
										arg2248_1259 = CNST_TABLE_REF(((long) 66));
										arg2250_1260 = CNST_TABLE_REF(((long) 64));
										{
										   obj_t list2253_1262;
										   {
										      obj_t arg2254_1263;
										      {
											 obj_t arg2256_1264;
											 arg2256_1264 = MAKE_PAIR(BNIL, BNIL);
											 arg2254_1263 = MAKE_PAIR(arg2250_1260, arg2256_1264);
										      }
										      list2253_1262 = MAKE_PAIR(arg2248_1259, arg2254_1263);
										   }
										   arg2240_1252 = cons__138___r4_pairs_and_lists_6_3(arg2247_1258, list2253_1262);
										}
									     }
									     {
										obj_t list2242_1254;
										{
										   obj_t arg2243_1255;
										   {
										      obj_t arg2244_1256;
										      arg2244_1256 = MAKE_PAIR(BNIL, BNIL);
										      arg2243_1255 = MAKE_PAIR(g3_1159, arg2244_1256);
										   }
										   list2242_1254 = MAKE_PAIR(arg2240_1252, arg2243_1255);
										}
										arg2148_1165 = cons__138___r4_pairs_and_lists_6_3(arg2239_1251, list2242_1254);
									     }
									  }
									  {
									     obj_t list2150_1167;
									     {
										obj_t arg2151_1168;
										{
										   obj_t arg2152_1169;
										   {
										      obj_t arg2153_1170;
										      {
											 obj_t arg2154_1171;
											 {
											    obj_t arg2155_1172;
											    {
											       obj_t arg2156_1173;
											       arg2156_1173 = MAKE_PAIR(BNIL, BNIL);
											       arg2155_1172 = MAKE_PAIR(g0_1156, arg2156_1173);
											    }
											    arg2154_1171 = MAKE_PAIR(arg2148_1165, arg2155_1172);
											 }
											 arg2153_1170 = MAKE_PAIR(arg2147_1164, arg2154_1171);
										      }
										      arg2152_1169 = MAKE_PAIR(arg2146_1163, arg2153_1170);
										   }
										   arg2151_1168 = MAKE_PAIR(arg2145_1162, arg2152_1169);
										}
										list2150_1167 = MAKE_PAIR(arg2144_1161, arg2151_1168);
									     }
									     return cons__138___r4_pairs_and_lists_6_3(arg2143_1160, list2150_1167);
									  }
								       }
								    }
								 }
							       else
								 {
								  tag_586_134_922:
								    {
								       obj_t g0_1274;
								       {
									  obj_t arg2325_1331;
									  arg2325_1331 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 72)), BEOA);
									  g0_1274 = mark_symbol_non_user__17_ast_ident(arg2325_1331);
								       }
								       {
									  obj_t arg2267_1275;
									  obj_t arg2268_1276;
									  obj_t arg2269_1277;
									  arg2267_1275 = CNST_TABLE_REF(((long) 37));
									  {
									     obj_t arg2276_1284;
									     {
										obj_t arg2280_1288;
										{
										   obj_t arg2286_1293;
										   obj_t arg2287_1294;
										   arg2286_1293 = CNST_TABLE_REF(((long) 73));
										   {
										      obj_t arg2291_1297;
										      obj_t arg2292_1298;
										      {
											 obj_t l1045_1299;
											 l1045_1299 = CDR(x_904);
											 if (NULLP(l1045_1299))
											   {
											      arg2291_1297 = BNIL;
											   }
											 else
											   {
											      obj_t head1047_1301;
											      head1047_1301 = MAKE_PAIR(BNIL, BNIL);
											      {
												 obj_t l1045_1302;
												 obj_t tail1048_1303;
												 l1045_1302 = l1045_1299;
												 tail1048_1303 = head1047_1301;
											       lname1046_1304:
												 if (NULLP(l1045_1302))
												   {
												      arg2291_1297 = CDR(head1047_1301);
												   }
												 else
												   {
												      obj_t newtail1049_1306;
												      {
													 obj_t arg2297_1308;
													 arg2297_1308 = PROCEDURE_ENTRY(e_905) (e_905, CAR(l1045_1302), e_905, BEOA);
													 newtail1049_1306 = MAKE_PAIR(arg2297_1308, BNIL);
												      }
												      SET_CDR(tail1048_1303, newtail1049_1306);
												      {
													 obj_t tail1048_3458;
													 obj_t l1045_3456;
													 l1045_3456 = CDR(l1045_1302);
													 tail1048_3458 = newtail1049_1306;
													 tail1048_1303 = tail1048_3458;
													 l1045_1302 = l1045_3456;
													 goto lname1046_1304;
												      }
												   }
											      }
											   }
										      }
										      arg2292_1298 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
										      arg2287_1294 = append_2_18___r4_pairs_and_lists_6_3(arg2291_1297, arg2292_1298);
										   }
										   {
										      obj_t list2288_1295;
										      list2288_1295 = MAKE_PAIR(arg2287_1294, BNIL);
										      arg2280_1288 = cons__138___r4_pairs_and_lists_6_3(arg2286_1293, list2288_1295);
										   }
										}
										{
										   obj_t list2282_1290;
										   {
										      obj_t arg2283_1291;
										      arg2283_1291 = MAKE_PAIR(BNIL, BNIL);
										      list2282_1290 = MAKE_PAIR(arg2280_1288, arg2283_1291);
										   }
										   arg2276_1284 = cons__138___r4_pairs_and_lists_6_3(g0_1274, list2282_1290);
										}
									     }
									     {
										obj_t list2278_1286;
										list2278_1286 = MAKE_PAIR(BNIL, BNIL);
										arg2268_1276 = cons__138___r4_pairs_and_lists_6_3(arg2276_1284, list2278_1286);
									     }
									  }
									  {
									     obj_t arg2303_1315;
									     obj_t arg2304_1316;
									     arg2303_1315 = CNST_TABLE_REF(((long) 8));
									     {
										obj_t arg2311_1323;
										obj_t arg2312_1324;
										obj_t arg2316_1325;
										arg2311_1323 = CNST_TABLE_REF(((long) 62));
										arg2312_1324 = CNST_TABLE_REF(((long) 68));
										arg2316_1325 = CNST_TABLE_REF(((long) 64));
										{
										   obj_t list2320_1327;
										   {
										      obj_t arg2322_1328;
										      {
											 obj_t arg2323_1329;
											 arg2323_1329 = MAKE_PAIR(BNIL, BNIL);
											 arg2322_1328 = MAKE_PAIR(arg2316_1325, arg2323_1329);
										      }
										      list2320_1327 = MAKE_PAIR(arg2312_1324, arg2322_1328);
										   }
										   arg2304_1316 = cons__138___r4_pairs_and_lists_6_3(arg2311_1323, list2320_1327);
										}
									     }
									     {
										obj_t list2307_1319;
										{
										   obj_t arg2308_1320;
										   {
										      obj_t arg2309_1321;
										      arg2309_1321 = MAKE_PAIR(BNIL, BNIL);
										      {
											 obj_t aux_3477;
											 aux_3477 = BINT(((long) -1));
											 arg2308_1320 = MAKE_PAIR(aux_3477, arg2309_1321);
										      }
										   }
										   list2307_1319 = MAKE_PAIR(arg2304_1316, arg2308_1320);
										}
										arg2269_1277 = cons__138___r4_pairs_and_lists_6_3(arg2303_1315, list2307_1319);
									     }
									  }
									  {
									     obj_t list2271_1279;
									     {
										obj_t arg2272_1280;
										{
										   obj_t arg2273_1281;
										   {
										      obj_t arg2274_1282;
										      arg2274_1282 = MAKE_PAIR(BNIL, BNIL);
										      arg2273_1281 = MAKE_PAIR(g0_1274, arg2274_1282);
										   }
										   arg2272_1280 = MAKE_PAIR(arg2269_1277, arg2273_1281);
										}
										list2271_1279 = MAKE_PAIR(arg2268_1276, arg2272_1280);
									     }
									     return cons__138___r4_pairs_and_lists_6_3(arg2267_1275, list2271_1279);
									  }
								       }
								    }
								 }
							    }
							  else
							    {
							       goto tag_586_134_922;
							    }
						       }
						    }
						 }
					    }
					  else
					    {
					       goto tag_586_134_922;
					    }
				       }
				    }
			       }
			     else
			       {
				  goto tag_586_134_922;
			       }
			  }
		     }
		   else
		     {
			goto tag_586_134_922;
		     }
		}
	   }
	 else
	   {
	      goto tag_586_134_922;
	   }
      }
   }
}


/* arg1857 */ obj_t 
arg1857_expand_install(obj_t env_2371, obj_t x_2372, obj_t e_2373)
{
   {
      obj_t x_850;
      obj_t e_851;
      x_850 = x_2372;
      e_851 = e_2373;
      {
	 obj_t function_856;
	 obj_t args_857;
	 obj_t function_853;
	 obj_t one_arg_36_854;
	 if (PAIRP(x_850))
	   {
	      obj_t cdr_533_200_862;
	      cdr_533_200_862 = CDR(x_850);
	      if (PAIRP(cdr_533_200_862))
		{
		   obj_t cdr_537_243_864;
		   cdr_537_243_864 = CDR(cdr_533_200_862);
		   if (PAIRP(cdr_537_243_864))
		     {
			bool_t test_3495;
			{
			   obj_t aux_3496;
			   aux_3496 = CDR(cdr_537_243_864);
			   test_3495 = (aux_3496 == BNIL);
			}
			if (test_3495)
			  {
			     function_853 = CAR(cdr_533_200_862);
			     one_arg_36_854 = CAR(cdr_537_243_864);
			     {
				obj_t arg1871_877;
				obj_t arg1874_878;
				obj_t arg1875_879;
				arg1871_877 = CNST_TABLE_REF(((long) 52));
				arg1874_878 = PROCEDURE_ENTRY(e_851) (e_851, function_853, e_851, BEOA);
				arg1875_879 = PROCEDURE_ENTRY(e_851) (e_851, one_arg_36_854, e_851, BEOA);
				{
				   obj_t list1877_881;
				   {
				      obj_t arg1878_882;
				      {
					 obj_t arg1879_883;
					 arg1879_883 = MAKE_PAIR(BNIL, BNIL);
					 arg1878_882 = MAKE_PAIR(arg1875_879, arg1879_883);
				      }
				      list1877_881 = MAKE_PAIR(arg1874_878, arg1878_882);
				   }
				   return cons__138___r4_pairs_and_lists_6_3(arg1871_877, list1877_881);
				}
			     }
			  }
			else
			  {
			     function_856 = CAR(cdr_533_200_862);
			     args_857 = CDR(cdr_533_200_862);
			   tag_524_10_858:
			     {
				obj_t arg1881_885;
				obj_t arg1883_886;
				obj_t arg1884_887;
				arg1881_885 = CNST_TABLE_REF(((long) 52));
				arg1883_886 = PROCEDURE_ENTRY(e_851) (e_851, function_856, e_851, BEOA);
				{
				   obj_t arg1892_893;
				   {
				      obj_t arg1893_894;
				      obj_t arg1894_895;
				      arg1893_894 = CNST_TABLE_REF(((long) 75));
				      {
					 obj_t arg1897_898;
					 arg1897_898 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					 arg1894_895 = append_2_18___r4_pairs_and_lists_6_3(args_857, arg1897_898);
				      }
				      {
					 obj_t list1895_896;
					 list1895_896 = MAKE_PAIR(arg1894_895, BNIL);
					 arg1892_893 = cons__138___r4_pairs_and_lists_6_3(arg1893_894, list1895_896);
				      }
				   }
				   arg1884_887 = PROCEDURE_ENTRY(e_851) (e_851, arg1892_893, e_851, BEOA);
				}
				{
				   obj_t list1886_889;
				   {
				      obj_t arg1887_890;
				      {
					 obj_t arg1888_891;
					 arg1888_891 = MAKE_PAIR(BNIL, BNIL);
					 arg1887_890 = MAKE_PAIR(arg1884_887, arg1888_891);
				      }
				      list1886_889 = MAKE_PAIR(arg1883_886, arg1887_890);
				   }
				   return cons__138___r4_pairs_and_lists_6_3(arg1881_885, list1886_889);
				}
			     }
			  }
		     }
		   else
		     {
			obj_t args_3528;
			obj_t function_3526;
			function_3526 = CAR(cdr_533_200_862);
			args_3528 = CDR(cdr_533_200_862);
			args_857 = args_3528;
			function_856 = function_3526;
			goto tag_524_10_858;
		     }
		}
	      else
		{
		 tag_525_219_859:
		   FAILURE(BFALSE, string2900_expand_install, x_850);
		}
	   }
	 else
	   {
	      goto tag_525_219_859;
	   }
      }
   }
}


/* arg1829 */ obj_t 
arg1829_expand_install(obj_t env_2374, obj_t x_2375, obj_t e_2376)
{
   {
      obj_t x_821;
      obj_t e_822;
      x_821 = x_2375;
      e_822 = e_2376;
      {
	 obj_t n_824;
	 if (PAIRP(x_821))
	   {
	      obj_t cdr_518_108_829;
	      cdr_518_108_829 = CDR(x_821);
	      if (PAIRP(cdr_518_108_829))
		{
		   bool_t test_3536;
		   {
		      obj_t aux_3537;
		      aux_3537 = CDR(cdr_518_108_829);
		      test_3536 = (aux_3537 == BNIL);
		   }
		   if (test_3536)
		     {
			n_824 = CAR(cdr_518_108_829);
			if (CBOOL(_unsafe_range__218_engine_param))
			  {
			     obj_t arg1837_835;
			     obj_t arg1838_836;
			     arg1837_835 = CNST_TABLE_REF(((long) 76));
			     arg1838_836 = PROCEDURE_ENTRY(e_822) (e_822, n_824, e_822, BEOA);
			     {
				obj_t list1840_838;
				{
				   obj_t arg1842_839;
				   arg1842_839 = MAKE_PAIR(BNIL, BNIL);
				   list1840_838 = MAKE_PAIR(arg1838_836, arg1842_839);
				}
				return cons__138___r4_pairs_and_lists_6_3(arg1837_835, list1840_838);
			     }
			  }
			else
			  {
			     obj_t arg1847_841;
			     obj_t arg1848_842;
			     arg1847_841 = CNST_TABLE_REF(((long) 51));
			     arg1848_842 = PROCEDURE_ENTRY(e_822) (e_822, n_824, e_822, BEOA);
			     {
				obj_t list1851_844;
				{
				   obj_t arg1852_845;
				   arg1852_845 = MAKE_PAIR(BNIL, BNIL);
				   list1851_844 = MAKE_PAIR(arg1848_842, arg1852_845);
				}
				return cons__138___r4_pairs_and_lists_6_3(arg1847_841, list1851_844);
			     }
			  }
		     }
		   else
		     {
		      tag_513_88_826:
			FAILURE(BFALSE, string2901_expand_install, x_821);
		     }
		}
	      else
		{
		   goto tag_513_88_826;
		}
	   }
	 else
	   {
	      goto tag_513_88_826;
	   }
      }
   }
}


/* arg1789 */ obj_t 
arg1789_expand_install(obj_t env_2377, obj_t x_2378, obj_t e_2379)
{
   {
      obj_t x_765;
      obj_t e_766;
      x_765 = x_2378;
      e_766 = e_2379;
      {
	 obj_t s1_768;
	 obj_t o1_769;
	 obj_t s2_770;
	 obj_t o2_771;
	 obj_t l_772;
	 if (PAIRP(x_765))
	   {
	      obj_t cdr_481_158_777;
	      cdr_481_158_777 = CDR(x_765);
	      if (PAIRP(cdr_481_158_777))
		{
		   obj_t cdr_488_93_779;
		   cdr_488_93_779 = CDR(cdr_481_158_777);
		   if (PAIRP(cdr_488_93_779))
		     {
			obj_t cdr_495_163_781;
			cdr_495_163_781 = CDR(cdr_488_93_779);
			if (PAIRP(cdr_495_163_781))
			  {
			     obj_t cdr_501_67_783;
			     cdr_501_67_783 = CDR(cdr_495_163_781);
			     if (PAIRP(cdr_501_67_783))
			       {
				  obj_t cdr_506_2_785;
				  cdr_506_2_785 = CDR(cdr_501_67_783);
				  if (PAIRP(cdr_506_2_785))
				    {
				       bool_t test_3573;
				       {
					  obj_t aux_3574;
					  aux_3574 = CDR(cdr_506_2_785);
					  test_3573 = (aux_3574 == BNIL);
				       }
				       if (test_3573)
					 {
					    s1_768 = CAR(cdr_481_158_777);
					    o1_769 = CAR(cdr_488_93_779);
					    s2_770 = CAR(cdr_495_163_781);
					    o2_771 = CAR(cdr_501_67_783);
					    l_772 = CAR(cdr_506_2_785);
					    {
					       obj_t s1_795;
					       obj_t o1_796;
					       obj_t s2_797;
					       obj_t o2_798;
					       obj_t l_799;
					       s1_795 = PROCEDURE_ENTRY(e_766) (e_766, s1_768, e_766, BEOA);
					       o1_796 = PROCEDURE_ENTRY(e_766) (e_766, o1_769, e_766, BEOA);
					       s2_797 = PROCEDURE_ENTRY(e_766) (e_766, s2_770, e_766, BEOA);
					       o2_798 = PROCEDURE_ENTRY(e_766) (e_766, o2_771, e_766, BEOA);
					       l_799 = PROCEDURE_ENTRY(e_766) (e_766, l_772, e_766, BEOA);
					       if (CBOOL(_unsafe_range__218_engine_param))
						 {
						    obj_t arg1807_800;
						    arg1807_800 = CNST_TABLE_REF(((long) 77));
						    {
						       obj_t list1809_802;
						       {
							  obj_t arg1810_803;
							  {
							     obj_t arg1811_804;
							     {
								obj_t arg1812_805;
								{
								   obj_t arg1813_806;
								   {
								      obj_t arg1814_807;
								      arg1814_807 = MAKE_PAIR(BNIL, BNIL);
								      arg1813_806 = MAKE_PAIR(l_799, arg1814_807);
								   }
								   arg1812_805 = MAKE_PAIR(o2_798, arg1813_806);
								}
								arg1811_804 = MAKE_PAIR(s2_797, arg1812_805);
							     }
							     arg1810_803 = MAKE_PAIR(o1_796, arg1811_804);
							  }
							  list1809_802 = MAKE_PAIR(s1_795, arg1810_803);
						       }
						       return cons__138___r4_pairs_and_lists_6_3(arg1807_800, list1809_802);
						    }
						 }
					       else
						 {
						    obj_t arg1816_809;
						    arg1816_809 = CNST_TABLE_REF(((long) 50));
						    {
						       obj_t list1818_811;
						       {
							  obj_t arg1820_812;
							  {
							     obj_t arg1821_813;
							     {
								obj_t arg1822_814;
								{
								   obj_t arg1823_815;
								   {
								      obj_t arg1824_816;
								      arg1824_816 = MAKE_PAIR(BNIL, BNIL);
								      arg1823_815 = MAKE_PAIR(l_799, arg1824_816);
								   }
								   arg1822_814 = MAKE_PAIR(o2_798, arg1823_815);
								}
								arg1821_813 = MAKE_PAIR(s2_797, arg1822_814);
							     }
							     arg1820_812 = MAKE_PAIR(o1_796, arg1821_813);
							  }
							  list1818_811 = MAKE_PAIR(s1_795, arg1820_812);
						       }
						       return cons__138___r4_pairs_and_lists_6_3(arg1816_809, list1818_811);
						    }
						 }
					    }
					 }
				       else
					 {
					  tag_468_13_774:
					    FAILURE(BFALSE, string2902_expand_install, x_765);
					 }
				    }
				  else
				    {
				       goto tag_468_13_774;
				    }
			       }
			     else
			       {
				  goto tag_468_13_774;
			       }
			  }
			else
			  {
			     goto tag_468_13_774;
			  }
		     }
		   else
		     {
			goto tag_468_13_774;
		     }
		}
	      else
		{
		   goto tag_468_13_774;
		}
	   }
	 else
	   {
	      goto tag_468_13_774;
	   }
      }
   }
}


/* arg1761 */ obj_t 
arg1761_expand_install(obj_t env_2380, obj_t x_2381, obj_t e_2382)
{
   {
      obj_t x_730;
      obj_t e_731;
      x_730 = x_2381;
      e_731 = e_2382;
      {
	 obj_t vec_733;
	 obj_t k_734;
	 if (PAIRP(x_730))
	   {
	      obj_t cdr_457_65_739;
	      cdr_457_65_739 = CDR(x_730);
	      if (PAIRP(cdr_457_65_739))
		{
		   obj_t cdr_461_169_741;
		   cdr_461_169_741 = CDR(cdr_457_65_739);
		   if (PAIRP(cdr_461_169_741))
		     {
			bool_t test_3619;
			{
			   obj_t aux_3620;
			   aux_3620 = CDR(cdr_461_169_741);
			   test_3619 = (aux_3620 == BNIL);
			}
			if (test_3619)
			  {
			     vec_733 = CAR(cdr_457_65_739);
			     k_734 = CAR(cdr_461_169_741);
			     {
				obj_t evec_748;
				obj_t ek_749;
				evec_748 = PROCEDURE_ENTRY(e_731) (e_731, vec_733, e_731, BEOA);
				ek_749 = PROCEDURE_ENTRY(e_731) (e_731, k_734, e_731, BEOA);
				if (CBOOL(_unsafe_range__218_engine_param))
				  {
				     obj_t arg1771_750;
				     arg1771_750 = CNST_TABLE_REF(((long) 78));
				     {
					obj_t list1773_752;
					{
					   obj_t arg1774_753;
					   {
					      obj_t arg1776_754;
					      arg1776_754 = MAKE_PAIR(BNIL, BNIL);
					      arg1774_753 = MAKE_PAIR(ek_749, arg1776_754);
					   }
					   list1773_752 = MAKE_PAIR(evec_748, arg1774_753);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1771_750, list1773_752);
				     }
				  }
				else
				  {
				     obj_t arg1778_756;
				     arg1778_756 = CNST_TABLE_REF(((long) 49));
				     {
					obj_t list1780_758;
					{
					   obj_t arg1781_759;
					   {
					      obj_t arg1783_760;
					      arg1783_760 = MAKE_PAIR(BNIL, BNIL);
					      arg1781_759 = MAKE_PAIR(ek_749, arg1783_760);
					   }
					   list1780_758 = MAKE_PAIR(evec_748, arg1781_759);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1778_756, list1780_758);
				     }
				  }
			     }
			  }
			else
			  {
			   tag_450_178_736:
			     FAILURE(BFALSE, string2903_expand_install, x_730);
			  }
		     }
		   else
		     {
			goto tag_450_178_736;
		     }
		}
	      else
		{
		   goto tag_450_178_736;
		}
	   }
	 else
	   {
	      goto tag_450_178_736;
	   }
      }
   }
}


/* arg1722 */ obj_t 
arg1722_expand_install(obj_t env_2383, obj_t x_2384, obj_t e_2385)
{
   {
      obj_t x_688;
      obj_t e_689;
      x_688 = x_2384;
      e_689 = e_2385;
      {
	 obj_t vec_691;
	 obj_t k_692;
	 obj_t obj_693;
	 if (PAIRP(x_688))
	   {
	      obj_t cdr_433_16_698;
	      cdr_433_16_698 = CDR(x_688);
	      if (PAIRP(cdr_433_16_698))
		{
		   obj_t cdr_438_80_700;
		   cdr_438_80_700 = CDR(cdr_433_16_698);
		   if (PAIRP(cdr_438_80_700))
		     {
			obj_t cdr_443_194_702;
			cdr_443_194_702 = CDR(cdr_438_80_700);
			if (PAIRP(cdr_443_194_702))
			  {
			     bool_t test_3653;
			     {
				obj_t aux_3654;
				aux_3654 = CDR(cdr_443_194_702);
				test_3653 = (aux_3654 == BNIL);
			     }
			     if (test_3653)
			       {
				  vec_691 = CAR(cdr_433_16_698);
				  k_692 = CAR(cdr_438_80_700);
				  obj_693 = CAR(cdr_443_194_702);
				  {
				     obj_t evec_710;
				     obj_t ek_711;
				     obj_t eobj_712;
				     evec_710 = PROCEDURE_ENTRY(e_689) (e_689, vec_691, e_689, BEOA);
				     ek_711 = PROCEDURE_ENTRY(e_689) (e_689, k_692, e_689, BEOA);
				     eobj_712 = PROCEDURE_ENTRY(e_689) (e_689, obj_693, e_689, BEOA);
				     if (CBOOL(_unsafe_range__218_engine_param))
				       {
					  obj_t arg1738_713;
					  arg1738_713 = CNST_TABLE_REF(((long) 79));
					  {
					     obj_t list1740_715;
					     {
						obj_t arg1743_716;
						{
						   obj_t arg1744_717;
						   {
						      obj_t arg1745_718;
						      arg1745_718 = MAKE_PAIR(BNIL, BNIL);
						      arg1744_717 = MAKE_PAIR(eobj_712, arg1745_718);
						   }
						   arg1743_716 = MAKE_PAIR(ek_711, arg1744_717);
						}
						list1740_715 = MAKE_PAIR(evec_710, arg1743_716);
					     }
					     return cons__138___r4_pairs_and_lists_6_3(arg1738_713, list1740_715);
					  }
				       }
				     else
				       {
					  obj_t arg1747_720;
					  arg1747_720 = CNST_TABLE_REF(((long) 48));
					  {
					     obj_t list1749_722;
					     {
						obj_t arg1753_723;
						{
						   obj_t arg1755_724;
						   {
						      obj_t arg1758_725;
						      arg1758_725 = MAKE_PAIR(BNIL, BNIL);
						      arg1755_724 = MAKE_PAIR(eobj_712, arg1758_725);
						   }
						   arg1753_723 = MAKE_PAIR(ek_711, arg1755_724);
						}
						list1749_722 = MAKE_PAIR(evec_710, arg1753_723);
					     }
					     return cons__138___r4_pairs_and_lists_6_3(arg1747_720, list1749_722);
					  }
				       }
				  }
			       }
			     else
			       {
				tag_424_122_695:
				  FAILURE(BFALSE, string2904_expand_install, x_688);
			       }
			  }
			else
			  {
			     goto tag_424_122_695;
			  }
		     }
		   else
		     {
			goto tag_424_122_695;
		     }
		}
	      else
		{
		   goto tag_424_122_695;
		}
	   }
	 else
	   {
	      goto tag_424_122_695;
	   }
      }
   }
}


/* arg1693 */ obj_t 
arg1693_expand_install(obj_t env_2386, obj_t x_2387, obj_t e_2388)
{
   {
      obj_t x_646;
      obj_t e_647;
      x_646 = x_2387;
      e_647 = e_2388;
      {
	 obj_t s_649;
	 obj_t min_650;
	 obj_t max_651;
	 if (PAIRP(x_646))
	   {
	      obj_t cdr_407_115_656;
	      cdr_407_115_656 = CDR(x_646);
	      if (PAIRP(cdr_407_115_656))
		{
		   obj_t cdr_412_58_658;
		   cdr_412_58_658 = CDR(cdr_407_115_656);
		   if (PAIRP(cdr_412_58_658))
		     {
			obj_t cdr_417_12_660;
			cdr_417_12_660 = CDR(cdr_412_58_658);
			if (PAIRP(cdr_417_12_660))
			  {
			     bool_t test_3692;
			     {
				obj_t aux_3693;
				aux_3693 = CDR(cdr_417_12_660);
				test_3692 = (aux_3693 == BNIL);
			     }
			     if (test_3692)
			       {
				  s_649 = CAR(cdr_407_115_656);
				  min_650 = CAR(cdr_412_58_658);
				  max_651 = CAR(cdr_417_12_660);
				  {
				     obj_t s_668;
				     obj_t min_669;
				     obj_t max_670;
				     s_668 = PROCEDURE_ENTRY(e_647) (e_647, s_649, e_647, BEOA);
				     min_669 = PROCEDURE_ENTRY(e_647) (e_647, min_650, e_647, BEOA);
				     max_670 = PROCEDURE_ENTRY(e_647) (e_647, max_651, e_647, BEOA);
				     if (CBOOL(_unsafe_range__218_engine_param))
				       {
					  obj_t arg1705_671;
					  arg1705_671 = CNST_TABLE_REF(((long) 80));
					  {
					     obj_t list1707_673;
					     {
						obj_t arg1708_674;
						{
						   obj_t arg1709_675;
						   {
						      obj_t arg1710_676;
						      arg1710_676 = MAKE_PAIR(BNIL, BNIL);
						      arg1709_675 = MAKE_PAIR(max_670, arg1710_676);
						   }
						   arg1708_674 = MAKE_PAIR(min_669, arg1709_675);
						}
						list1707_673 = MAKE_PAIR(s_668, arg1708_674);
					     }
					     return cons__138___r4_pairs_and_lists_6_3(arg1705_671, list1707_673);
					  }
				       }
				     else
				       {
					  obj_t arg1712_678;
					  arg1712_678 = CNST_TABLE_REF(((long) 47));
					  {
					     obj_t list1714_680;
					     {
						obj_t arg1716_681;
						{
						   obj_t arg1717_682;
						   {
						      obj_t arg1718_683;
						      arg1718_683 = MAKE_PAIR(BNIL, BNIL);
						      arg1717_682 = MAKE_PAIR(max_670, arg1718_683);
						   }
						   arg1716_681 = MAKE_PAIR(min_669, arg1717_682);
						}
						list1714_680 = MAKE_PAIR(s_668, arg1716_681);
					     }
					     return cons__138___r4_pairs_and_lists_6_3(arg1712_678, list1714_680);
					  }
				       }
				  }
			       }
			     else
			       {
				tag_398_129_653:
				  FAILURE(BFALSE, string2905_expand_install, x_646);
			       }
			  }
			else
			  {
			     goto tag_398_129_653;
			  }
		     }
		   else
		     {
			goto tag_398_129_653;
		     }
		}
	      else
		{
		   goto tag_398_129_653;
		}
	   }
	 else
	   {
	      goto tag_398_129_653;
	   }
      }
   }
}


/* arg1667 */ obj_t 
arg1667_expand_install(obj_t env_2389, obj_t x_2390, obj_t e_2391)
{
   {
      obj_t x_611;
      obj_t e_612;
      x_611 = x_2390;
      e_612 = e_2391;
      {
	 obj_t vec_614;
	 obj_t k_615;
	 if (PAIRP(x_611))
	   {
	      obj_t cdr_387_108_620;
	      cdr_387_108_620 = CDR(x_611);
	      if (PAIRP(cdr_387_108_620))
		{
		   obj_t cdr_391_22_622;
		   cdr_391_22_622 = CDR(cdr_387_108_620);
		   if (PAIRP(cdr_391_22_622))
		     {
			bool_t test_3728;
			{
			   obj_t aux_3729;
			   aux_3729 = CDR(cdr_391_22_622);
			   test_3728 = (aux_3729 == BNIL);
			}
			if (test_3728)
			  {
			     vec_614 = CAR(cdr_387_108_620);
			     k_615 = CAR(cdr_391_22_622);
			     {
				obj_t evec_629;
				obj_t ek_630;
				evec_629 = PROCEDURE_ENTRY(e_612) (e_612, vec_614, e_612, BEOA);
				ek_630 = PROCEDURE_ENTRY(e_612) (e_612, k_615, e_612, BEOA);
				if (CBOOL(_unsafe_range__218_engine_param))
				  {
				     obj_t arg1678_631;
				     arg1678_631 = CNST_TABLE_REF(((long) 81));
				     {
					obj_t list1680_633;
					{
					   obj_t arg1681_634;
					   {
					      obj_t arg1682_635;
					      arg1682_635 = MAKE_PAIR(BNIL, BNIL);
					      arg1681_634 = MAKE_PAIR(ek_630, arg1682_635);
					   }
					   list1680_633 = MAKE_PAIR(evec_629, arg1681_634);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1678_631, list1680_633);
				     }
				  }
				else
				  {
				     obj_t arg1684_637;
				     arg1684_637 = CNST_TABLE_REF(((long) 46));
				     {
					obj_t list1686_639;
					{
					   obj_t arg1688_640;
					   {
					      obj_t arg1689_641;
					      arg1689_641 = MAKE_PAIR(BNIL, BNIL);
					      arg1688_640 = MAKE_PAIR(ek_630, arg1689_641);
					   }
					   list1686_639 = MAKE_PAIR(evec_629, arg1688_640);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1684_637, list1686_639);
				     }
				  }
			     }
			  }
			else
			  {
			   tag_380_71_617:
			     FAILURE(BFALSE, string2906_expand_install, x_611);
			  }
		     }
		   else
		     {
			goto tag_380_71_617;
		     }
		}
	      else
		{
		   goto tag_380_71_617;
		}
	   }
	 else
	   {
	      goto tag_380_71_617;
	   }
      }
   }
}


/* arg1634 */ obj_t 
arg1634_expand_install(obj_t env_2392, obj_t x_2393, obj_t e_2394)
{
   {
      obj_t x_569;
      obj_t e_570;
      x_569 = x_2393;
      e_570 = e_2394;
      {
	 obj_t vec_572;
	 obj_t k_573;
	 obj_t obj_574;
	 if (PAIRP(x_569))
	   {
	      obj_t cdr_363_114_579;
	      cdr_363_114_579 = CDR(x_569);
	      if (PAIRP(cdr_363_114_579))
		{
		   obj_t cdr_368_205_581;
		   cdr_368_205_581 = CDR(cdr_363_114_579);
		   if (PAIRP(cdr_368_205_581))
		     {
			obj_t cdr_373_224_583;
			cdr_373_224_583 = CDR(cdr_368_205_581);
			if (PAIRP(cdr_373_224_583))
			  {
			     bool_t test_3762;
			     {
				obj_t aux_3763;
				aux_3763 = CDR(cdr_373_224_583);
				test_3762 = (aux_3763 == BNIL);
			     }
			     if (test_3762)
			       {
				  vec_572 = CAR(cdr_363_114_579);
				  k_573 = CAR(cdr_368_205_581);
				  obj_574 = CAR(cdr_373_224_583);
				  {
				     obj_t evec_591;
				     obj_t ek_592;
				     obj_t eobj_593;
				     evec_591 = PROCEDURE_ENTRY(e_570) (e_570, vec_572, e_570, BEOA);
				     ek_592 = PROCEDURE_ENTRY(e_570) (e_570, k_573, e_570, BEOA);
				     eobj_593 = PROCEDURE_ENTRY(e_570) (e_570, obj_574, e_570, BEOA);
				     if (CBOOL(_unsafe_range__218_engine_param))
				       {
					  obj_t arg1649_594;
					  arg1649_594 = CNST_TABLE_REF(((long) 82));
					  {
					     obj_t list1651_596;
					     {
						obj_t arg1652_597;
						{
						   obj_t arg1653_598;
						   {
						      obj_t arg1654_599;
						      arg1654_599 = MAKE_PAIR(BNIL, BNIL);
						      arg1653_598 = MAKE_PAIR(eobj_593, arg1654_599);
						   }
						   arg1652_597 = MAKE_PAIR(ek_592, arg1653_598);
						}
						list1651_596 = MAKE_PAIR(evec_591, arg1652_597);
					     }
					     return cons__138___r4_pairs_and_lists_6_3(arg1649_594, list1651_596);
					  }
				       }
				     else
				       {
					  obj_t arg1656_601;
					  arg1656_601 = CNST_TABLE_REF(((long) 45));
					  {
					     obj_t list1658_603;
					     {
						obj_t arg1659_604;
						{
						   obj_t arg1661_605;
						   {
						      obj_t arg1663_606;
						      arg1663_606 = MAKE_PAIR(BNIL, BNIL);
						      arg1661_605 = MAKE_PAIR(eobj_593, arg1663_606);
						   }
						   arg1659_604 = MAKE_PAIR(ek_592, arg1661_605);
						}
						list1658_603 = MAKE_PAIR(evec_591, arg1659_604);
					     }
					     return cons__138___r4_pairs_and_lists_6_3(arg1656_601, list1658_603);
					  }
				       }
				  }
			       }
			     else
			       {
				tag_354_3_576:
				  FAILURE(BFALSE, string2907_expand_install, x_569);
			       }
			  }
			else
			  {
			     goto tag_354_3_576;
			  }
		     }
		   else
		     {
			goto tag_354_3_576;
		     }
		}
	      else
		{
		   goto tag_354_3_576;
		}
	   }
	 else
	   {
	      goto tag_354_3_576;
	   }
      }
   }
}


/* arg1584 */ obj_t 
arg1584_expand_install(obj_t env_2395, obj_t x_2396, obj_t e_2397)
{
   {
      obj_t x_510;
      obj_t e_511;
      x_510 = x_2396;
      e_511 = e_2397;
      {
	 obj_t n_515;
	 obj_t init_516;
	 obj_t n_513;
	 if (PAIRP(x_510))
	   {
	      obj_t cdr_322_220_521;
	      cdr_322_220_521 = CDR(x_510);
	      if (PAIRP(cdr_322_220_521))
		{
		   bool_t test_3795;
		   {
		      obj_t aux_3796;
		      aux_3796 = CDR(cdr_322_220_521);
		      test_3795 = (aux_3796 == BNIL);
		   }
		   if (test_3795)
		     {
			n_513 = CAR(cdr_322_220_521);
			{
			   obj_t arg1602_535;
			   obj_t arg1603_536;
			   obj_t arg1605_537;
			   arg1602_535 = CNST_TABLE_REF(((long) 83));
			   arg1603_536 = PROCEDURE_ENTRY(e_511) (e_511, n_513, e_511, BEOA);
			   arg1605_537 = PROCEDURE_ENTRY(e_511) (e_511, CNST_TABLE_REF(((long) 84)), e_511, BEOA);
			   {
			      obj_t list1607_539;
			      {
				 obj_t arg1608_540;
				 {
				    obj_t arg1609_541;
				    arg1609_541 = MAKE_PAIR(BNIL, BNIL);
				    arg1608_540 = MAKE_PAIR(arg1605_537, arg1609_541);
				 }
				 list1607_539 = MAKE_PAIR(arg1603_536, arg1608_540);
			      }
			      return cons__138___r4_pairs_and_lists_6_3(arg1602_535, list1607_539);
			   }
			}
		     }
		   else
		     {
			obj_t cdr_338_230_526;
			cdr_338_230_526 = CDR(cdr_322_220_521);
			if (PAIRP(cdr_338_230_526))
			  {
			     bool_t test_3813;
			     {
				obj_t aux_3814;
				aux_3814 = CDR(cdr_338_230_526);
				test_3813 = (aux_3814 == BNIL);
			     }
			     if (test_3813)
			       {
				  n_515 = CAR(cdr_322_220_521);
				  init_516 = CAR(cdr_338_230_526);
				  {
				     obj_t arg1613_544;
				     obj_t arg1615_545;
				     obj_t arg1617_546;
				     arg1613_544 = CNST_TABLE_REF(((long) 83));
				     arg1615_545 = PROCEDURE_ENTRY(e_511) (e_511, n_515, e_511, BEOA);
				     arg1617_546 = PROCEDURE_ENTRY(e_511) (e_511, init_516, e_511, BEOA);
				     {
					obj_t list1619_548;
					{
					   obj_t arg1620_549;
					   {
					      obj_t arg1621_550;
					      arg1621_550 = MAKE_PAIR(BNIL, BNIL);
					      arg1620_549 = MAKE_PAIR(arg1617_546, arg1621_550);
					   }
					   list1619_548 = MAKE_PAIR(arg1615_545, arg1620_549);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1613_544, list1619_548);
				     }
				  }
			       }
			     else
			       {
				tag_316_144_518:
				  if (NULLP(x_510))
				    {
				       return BNIL;
				    }
				  else
				    {
				       obj_t head1042_554;
				       head1042_554 = MAKE_PAIR(BNIL, BNIL);
				       {
					  obj_t l1040_555;
					  obj_t tail1043_556;
					  l1040_555 = x_510;
					  tail1043_556 = head1042_554;
					lname1041_557:
					  if (NULLP(l1040_555))
					    {
					       return CDR(head1042_554);
					    }
					  else
					    {
					       obj_t newtail1044_559;
					       {
						  obj_t arg1627_561;
						  arg1627_561 = PROCEDURE_ENTRY(e_511) (e_511, CAR(l1040_555), e_511, BEOA);
						  newtail1044_559 = MAKE_PAIR(arg1627_561, BNIL);
					       }
					       SET_CDR(tail1043_556, newtail1044_559);
					       {
						  obj_t tail1043_3841;
						  obj_t l1040_3839;
						  l1040_3839 = CDR(l1040_555);
						  tail1043_3841 = newtail1044_559;
						  tail1043_556 = tail1043_3841;
						  l1040_555 = l1040_3839;
						  goto lname1041_557;
					       }
					    }
				       }
				    }
			       }
			  }
			else
			  {
			     goto tag_316_144_518;
			  }
		     }
		}
	      else
		{
		   goto tag_316_144_518;
		}
	   }
	 else
	   {
	      goto tag_316_144_518;
	   }
      }
   }
}


/* arg1527 */ obj_t 
arg1527_expand_install(obj_t env_2398, obj_t x_2399, obj_t e_2400)
{
   {
      obj_t x_454;
      obj_t e_455;
      x_454 = x_2399;
      e_455 = e_2400;
      {
	 obj_t args_457;
	 obj_t v_458;
	 args_457 = CDR(x_454);
	 {
	    obj_t arg1581_505;
	    arg1581_505 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 85)), BEOA);
	    v_458 = mark_symbol_non_user__17_ast_ident(arg1581_505);
	 }
	 {
	    obj_t arg1529_459;
	    {
	       obj_t arg1530_460;
	       obj_t arg1531_461;
	       obj_t arg1532_462;
	       arg1530_460 = CNST_TABLE_REF(((long) 37));
	       {
		  obj_t arg1536_466;
		  {
		     obj_t arg1540_470;
		     {
			obj_t arg1549_475;
			long arg1550_476;
			arg1549_475 = CNST_TABLE_REF(((long) 86));
			arg1550_476 = list_length(args_457);
			{
			   obj_t list1553_478;
			   {
			      obj_t arg1554_479;
			      arg1554_479 = MAKE_PAIR(BNIL, BNIL);
			      {
				 obj_t aux_3851;
				 aux_3851 = BINT(arg1550_476);
				 list1553_478 = MAKE_PAIR(aux_3851, arg1554_479);
			      }
			   }
			   arg1540_470 = cons__138___r4_pairs_and_lists_6_3(arg1549_475, list1553_478);
			}
		     }
		     {
			obj_t list1543_472;
			{
			   obj_t arg1545_473;
			   arg1545_473 = MAKE_PAIR(BNIL, BNIL);
			   list1543_472 = MAKE_PAIR(arg1540_470, arg1545_473);
			}
			arg1536_466 = cons__138___r4_pairs_and_lists_6_3(v_458, list1543_472);
		     }
		  }
		  {
		     obj_t list1538_468;
		     list1538_468 = MAKE_PAIR(BNIL, BNIL);
		     arg1531_461 = cons__138___r4_pairs_and_lists_6_3(arg1536_466, list1538_468);
		  }
	       }
	       {
		  obj_t arg1556_481;
		  obj_t arg1557_482;
		  {
		     long i_483;
		     obj_t args_484;
		     obj_t res_485;
		     i_483 = ((long) 0);
		     args_484 = args_457;
		     res_485 = BNIL;
		   loop_486:
		     if (NULLP(args_484))
		       {
			  arg1556_481 = res_485;
		       }
		     else
		       {
			  long arg1561_490;
			  obj_t arg1562_491;
			  obj_t arg1563_492;
			  arg1561_490 = (i_483 + ((long) 1));
			  arg1562_491 = CDR(args_484);
			  {
			     obj_t arg1564_493;
			     {
				obj_t arg1565_494;
				obj_t arg1566_495;
				arg1565_494 = CNST_TABLE_REF(((long) 82));
				arg1566_495 = CAR(args_484);
				{
				   obj_t list1569_497;
				   {
				      obj_t arg1570_498;
				      {
					 obj_t arg1572_499;
					 {
					    obj_t arg1573_500;
					    arg1573_500 = MAKE_PAIR(BNIL, BNIL);
					    arg1572_499 = MAKE_PAIR(arg1566_495, arg1573_500);
					 }
					 {
					    obj_t aux_3868;
					    aux_3868 = BINT(i_483);
					    arg1570_498 = MAKE_PAIR(aux_3868, arg1572_499);
					 }
				      }
				      list1569_497 = MAKE_PAIR(v_458, arg1570_498);
				   }
				   arg1564_493 = cons__138___r4_pairs_and_lists_6_3(arg1565_494, list1569_497);
				}
			     }
			     arg1563_492 = MAKE_PAIR(arg1564_493, res_485);
			  }
			  {
			     obj_t res_3876;
			     obj_t args_3875;
			     long i_3874;
			     i_3874 = arg1561_490;
			     args_3875 = arg1562_491;
			     res_3876 = arg1563_492;
			     res_485 = res_3876;
			     args_484 = args_3875;
			     i_483 = i_3874;
			     goto loop_486;
			  }
		       }
		  }
		  {
		     obj_t list1579_503;
		     list1579_503 = MAKE_PAIR(BNIL, BNIL);
		     arg1557_482 = cons__138___r4_pairs_and_lists_6_3(v_458, list1579_503);
		  }
		  arg1532_462 = append_2_18___r4_pairs_and_lists_6_3(arg1556_481, arg1557_482);
	       }
	       {
		  obj_t list1533_463;
		  {
		     obj_t arg1534_464;
		     arg1534_464 = MAKE_PAIR(arg1532_462, BNIL);
		     list1533_463 = MAKE_PAIR(arg1531_461, arg1534_464);
		  }
		  arg1529_459 = cons__138___r4_pairs_and_lists_6_3(arg1530_460, list1533_463);
	       }
	    }
	    return PROCEDURE_ENTRY(e_455) (e_455, arg1529_459, e_455, BEOA);
	 }
      }
   }
}


/* arg1502 */ obj_t 
arg1502_expand_install(obj_t env_2401, obj_t x_2402, obj_t e_2403)
{
   {
      obj_t x_425;
      obj_t e_426;
      x_425 = x_2402;
      e_426 = e_2403;
      {
	 obj_t grammar_428;
	 obj_t port_429;
	 if (PAIRP(x_425))
	   {
	      obj_t cdr_304_134_434;
	      cdr_304_134_434 = CDR(x_425);
	      if (PAIRP(cdr_304_134_434))
		{
		   obj_t cdr_308_122_436;
		   cdr_308_122_436 = CDR(cdr_304_134_434);
		   if (PAIRP(cdr_308_122_436))
		     {
			bool_t test_3893;
			{
			   obj_t aux_3894;
			   aux_3894 = CDR(cdr_308_122_436);
			   test_3893 = (aux_3894 == BNIL);
			}
			if (test_3893)
			  {
			     grammar_428 = CAR(cdr_304_134_434);
			     port_429 = CAR(cdr_308_122_436);
			     {
				obj_t arg1515_443;
				obj_t arg1516_444;
				obj_t arg1517_445;
				arg1515_443 = CNST_TABLE_REF(((long) 42));
				arg1516_444 = PROCEDURE_ENTRY(e_426) (e_426, grammar_428, e_426, BEOA);
				arg1517_445 = PROCEDURE_ENTRY(e_426) (e_426, port_429, e_426, BEOA);
				{
				   obj_t list1519_447;
				   {
				      obj_t arg1522_448;
				      {
					 obj_t arg1524_449;
					 arg1524_449 = MAKE_PAIR(BNIL, BNIL);
					 arg1522_448 = MAKE_PAIR(arg1517_445, arg1524_449);
				      }
				      list1519_447 = MAKE_PAIR(arg1516_444, arg1522_448);
				   }
				   return cons__138___r4_pairs_and_lists_6_3(arg1515_443, list1519_447);
				}
			     }
			  }
			else
			  {
			   tag_297_3_431:
			     FAILURE(BFALSE, string2908_expand_install, x_425);
			  }
		     }
		   else
		     {
			goto tag_297_3_431;
		     }
		}
	      else
		{
		   goto tag_297_3_431;
		}
	   }
	 else
	   {
	      goto tag_297_3_431;
	   }
      }
   }
}


/* arg1456 */ obj_t 
arg1456_expand_install(obj_t env_2404, obj_t x_2405, obj_t e_2406)
{
   {
      obj_t x_369;
      obj_t e_370;
      x_369 = x_2405;
      e_370 = e_2406;
      {
	 obj_t port_374;
	 obj_t value_375;
	 obj_t port_372;
	 if (PAIRP(x_369))
	   {
	      obj_t cdr_263_185_381;
	      cdr_263_185_381 = CDR(x_369);
	      if (PAIRP(cdr_263_185_381))
		{
		   bool_t test_3914;
		   {
		      obj_t aux_3915;
		      aux_3915 = CDR(cdr_263_185_381);
		      test_3914 = (aux_3915 == BNIL);
		   }
		   if (test_3914)
		     {
			port_372 = CAR(cdr_263_185_381);
			{
			   obj_t arg1474_398;
			   obj_t arg1475_399;
			   arg1474_398 = CNST_TABLE_REF(((long) 41));
			   arg1475_399 = PROCEDURE_ENTRY(e_370) (e_370, port_372, e_370, BEOA);
			   {
			      obj_t list1477_401;
			      {
				 obj_t arg1478_402;
				 arg1478_402 = MAKE_PAIR(BNIL, BNIL);
				 list1477_401 = MAKE_PAIR(arg1475_399, arg1478_402);
			      }
			      return cons__138___r4_pairs_and_lists_6_3(arg1474_398, list1477_401);
			   }
			}
		     }
		   else
		     {
			obj_t cdr_279_181_386;
			cdr_279_181_386 = CDR(cdr_263_185_381);
			if (PAIRP(cdr_279_181_386))
			  {
			     bool_t test_3928;
			     {
				obj_t aux_3929;
				aux_3929 = CDR(cdr_279_181_386);
				test_3928 = (aux_3929 == BNIL);
			     }
			     if (test_3928)
			       {
				  port_374 = CAR(cdr_263_185_381);
				  value_375 = CAR(cdr_279_181_386);
				  {
				     obj_t arg1480_404;
				     obj_t arg1481_405;
				     obj_t arg1483_406;
				     arg1480_404 = CNST_TABLE_REF(((long) 41));
				     arg1481_405 = PROCEDURE_ENTRY(e_370) (e_370, port_374, e_370, BEOA);
				     arg1483_406 = PROCEDURE_ENTRY(e_370) (e_370, value_375, e_370, BEOA);
				     {
					obj_t list1485_408;
					{
					   obj_t arg1486_409;
					   {
					      obj_t arg1487_410;
					      arg1487_410 = MAKE_PAIR(BNIL, BNIL);
					      arg1486_409 = MAKE_PAIR(arg1483_406, arg1487_410);
					   }
					   list1485_408 = MAKE_PAIR(arg1481_405, arg1486_409);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1480_404, list1485_408);
				     }
				  }
			       }
			     else
			       {
				tag_257_163_378:
				  FAILURE(BFALSE, string2909_expand_install, x_369);
			       }
			  }
			else
			  {
			     goto tag_257_163_378;
			  }
		     }
		}
	      else
		{
		   if ((cdr_263_185_381 == BNIL))
		     {
			{
			   obj_t arg1489_412;
			   obj_t arg1490_413;
			   arg1489_412 = CNST_TABLE_REF(((long) 41));
			   {
			      obj_t arg1497_418;
			      arg1497_418 = CNST_TABLE_REF(((long) 87));
			      {
				 obj_t list1499_420;
				 list1499_420 = MAKE_PAIR(BNIL, BNIL);
				 arg1490_413 = cons__138___r4_pairs_and_lists_6_3(arg1497_418, list1499_420);
			      }
			   }
			   {
			      obj_t list1492_415;
			      {
				 obj_t arg1494_416;
				 arg1494_416 = MAKE_PAIR(BNIL, BNIL);
				 list1492_415 = MAKE_PAIR(arg1490_413, arg1494_416);
			      }
			      return cons__138___r4_pairs_and_lists_6_3(arg1489_412, list1492_415);
			   }
			}
		     }
		   else
		     {
			goto tag_257_163_378;
		     }
		}
	   }
	 else
	   {
	      goto tag_257_163_378;
	   }
      }
   }
}


/* arg1410 */ obj_t 
arg1410_expand_install(obj_t env_2407, obj_t x_2408, obj_t e_2409)
{
   {
      obj_t x_327;
      obj_t e_328;
      x_327 = x_2408;
      e_328 = e_2409;
      {
	 obj_t n_330;
	 obj_t m_331;
	 if (PAIRP(x_327))
	   {
	      obj_t cdr_244_169_336;
	      cdr_244_169_336 = CDR(x_327);
	      if (PAIRP(cdr_244_169_336))
		{
		   obj_t cdr_248_7_338;
		   cdr_248_7_338 = CDR(cdr_244_169_336);
		   if (PAIRP(cdr_248_7_338))
		     {
			bool_t test_3961;
			{
			   obj_t aux_3962;
			   aux_3962 = CDR(cdr_248_7_338);
			   test_3961 = (aux_3962 == BNIL);
			}
			if (test_3961)
			  {
			     n_330 = CAR(cdr_244_169_336);
			     m_331 = CAR(cdr_248_7_338);
			     if (CBOOL(_unsafe_range__218_engine_param))
			       {
				  obj_t arg1421_345;
				  obj_t arg1423_346;
				  obj_t arg1426_347;
				  arg1421_345 = CNST_TABLE_REF(((long) 88));
				  arg1423_346 = PROCEDURE_ENTRY(e_328) (e_328, n_330, e_328, BEOA);
				  arg1426_347 = PROCEDURE_ENTRY(e_328) (e_328, m_331, e_328, BEOA);
				  {
				     obj_t list1428_349;
				     {
					obj_t arg1431_350;
					{
					   obj_t arg1432_351;
					   arg1432_351 = MAKE_PAIR(BNIL, BNIL);
					   arg1431_350 = MAKE_PAIR(arg1426_347, arg1432_351);
					}
					list1428_349 = MAKE_PAIR(arg1423_346, arg1431_350);
				     }
				     return cons__138___r4_pairs_and_lists_6_3(arg1421_345, list1428_349);
				  }
			       }
			     else
			       {
				  obj_t arg1436_353;
				  obj_t arg1437_354;
				  obj_t arg1438_355;
				  arg1436_353 = CNST_TABLE_REF(((long) 35));
				  arg1437_354 = PROCEDURE_ENTRY(e_328) (e_328, n_330, e_328, BEOA);
				  arg1438_355 = PROCEDURE_ENTRY(e_328) (e_328, m_331, e_328, BEOA);
				  {
				     obj_t list1441_357;
				     {
					obj_t arg1443_358;
					{
					   obj_t arg1444_359;
					   arg1444_359 = MAKE_PAIR(BNIL, BNIL);
					   arg1443_358 = MAKE_PAIR(arg1438_355, arg1444_359);
					}
					list1441_357 = MAKE_PAIR(arg1437_354, arg1443_358);
				     }
				     return cons__138___r4_pairs_and_lists_6_3(arg1436_353, list1441_357);
				  }
			       }
			  }
			else
			  {
			   tag_237_211_333:
			     FAILURE(BFALSE, string2910_expand_install, x_327);
			  }
		     }
		   else
		     {
			goto tag_237_211_333;
		     }
		}
	      else
		{
		   goto tag_237_211_333;
		}
	   }
	 else
	   {
	      goto tag_237_211_333;
	   }
      }
   }
}


/* arg1384 */ obj_t 
arg1384_expand_install(obj_t env_2410, obj_t x_2411, obj_t e_2412)
{
   {
      obj_t x_298;
      obj_t e_299;
      x_298 = x_2411;
      e_299 = e_2412;
      {
	 obj_t n_301;
	 if (PAIRP(x_298))
	   {
	      obj_t cdr_231_213_306;
	      cdr_231_213_306 = CDR(x_298);
	      if (PAIRP(cdr_231_213_306))
		{
		   bool_t test_3993;
		   {
		      obj_t aux_3994;
		      aux_3994 = CDR(cdr_231_213_306);
		      test_3993 = (aux_3994 == BNIL);
		   }
		   if (test_3993)
		     {
			n_301 = CAR(cdr_231_213_306);
			if (CBOOL(_unsafe_range__218_engine_param))
			  {
			     obj_t arg1392_312;
			     obj_t arg1393_313;
			     arg1392_312 = CNST_TABLE_REF(((long) 89));
			     arg1393_313 = PROCEDURE_ENTRY(e_299) (e_299, n_301, e_299, BEOA);
			     {
				obj_t list1396_315;
				{
				   obj_t arg1397_316;
				   arg1397_316 = MAKE_PAIR(BNIL, BNIL);
				   list1396_315 = MAKE_PAIR(arg1393_313, arg1397_316);
				}
				return cons__138___r4_pairs_and_lists_6_3(arg1392_312, list1396_315);
			     }
			  }
			else
			  {
			     obj_t arg1399_318;
			     obj_t arg1401_319;
			     arg1399_318 = CNST_TABLE_REF(((long) 34));
			     arg1401_319 = PROCEDURE_ENTRY(e_299) (e_299, n_301, e_299, BEOA);
			     {
				obj_t list1403_321;
				{
				   obj_t arg1405_322;
				   arg1405_322 = MAKE_PAIR(BNIL, BNIL);
				   list1403_321 = MAKE_PAIR(arg1401_319, arg1405_322);
				}
				return cons__138___r4_pairs_and_lists_6_3(arg1399_318, list1403_321);
			     }
			  }
		     }
		   else
		     {
		      tag_226_44_303:
			FAILURE(BFALSE, string2911_expand_install, x_298);
		     }
		}
	      else
		{
		   goto tag_226_44_303;
		}
	   }
	 else
	   {
	      goto tag_226_44_303;
	   }
      }
   }
}


/* arg1308 */ obj_t 
arg1308_expand_install(obj_t env_2413, obj_t x_2414, obj_t e_2415)
{
   {
      obj_t x_232;
      obj_t e_233;
      x_232 = x_2414;
      e_233 = e_2415;
      {
	 obj_t a1_235;
	 obj_t a2_236;
	 if (PAIRP(x_232))
	   {
	      obj_t cdr_215_28_241;
	      cdr_215_28_241 = CDR(x_232);
	      if (PAIRP(cdr_215_28_241))
		{
		   obj_t cdr_219_190_243;
		   cdr_219_190_243 = CDR(cdr_215_28_241);
		   if (PAIRP(cdr_219_190_243))
		     {
			bool_t test_4021;
			{
			   obj_t aux_4022;
			   aux_4022 = CDR(cdr_219_190_243);
			   test_4021 = (aux_4022 == BNIL);
			}
			if (test_4021)
			  {
			     a1_235 = CAR(cdr_215_28_241);
			     a2_236 = CAR(cdr_219_190_243);
			     {
				obj_t arg1322_250;
				obj_t arg1323_251;
				obj_t arg1324_252;
				{
				   bool_t test_4025;
				   if (INTEGERP(a1_235))
				     {
					test_4025 = ((bool_t) 1);
				     }
				   else
				     {
					if (INTEGERP(a2_236))
					  {
					     test_4025 = ((bool_t) 1);
					  }
					else
					  {
					     bool_t test_4030;
					     if (PAIRP(a1_235))
					       {
						  bool_t test_4033;
						  {
						     obj_t aux_4036;
						     obj_t aux_4034;
						     aux_4036 = CNST_TABLE_REF(((long) 90));
						     aux_4034 = CAR(a1_235);
						     test_4033 = (aux_4034 == aux_4036);
						  }
						  if (test_4033)
						    {
						       obj_t aux_4039;
						       {
							  obj_t aux_4040;
							  aux_4040 = CDR(a1_235);
							  aux_4039 = CAR(aux_4040);
						       }
						       test_4030 = SYMBOLP(aux_4039);
						    }
						  else
						    {
						       test_4030 = ((bool_t) 0);
						    }
					       }
					     else
					       {
						  test_4030 = ((bool_t) 0);
					       }
					     if (test_4030)
					       {
						  test_4025 = ((bool_t) 1);
					       }
					     else
					       {
						  if (PAIRP(a2_236))
						    {
						       bool_t test_4046;
						       {
							  obj_t aux_4049;
							  obj_t aux_4047;
							  aux_4049 = CNST_TABLE_REF(((long) 90));
							  aux_4047 = CAR(a2_236);
							  test_4046 = (aux_4047 == aux_4049);
						       }
						       if (test_4046)
							 {
							    obj_t aux_4052;
							    {
							       obj_t aux_4053;
							       aux_4053 = CDR(a2_236);
							       aux_4052 = CAR(aux_4053);
							    }
							    test_4025 = SYMBOLP(aux_4052);
							 }
						       else
							 {
							    test_4025 = ((bool_t) 0);
							 }
						    }
						  else
						    {
						       test_4025 = ((bool_t) 0);
						    }
					       }
					  }
				     }
				   if (test_4025)
				     {
					arg1322_250 = CNST_TABLE_REF(((long) 91));
				     }
				   else
				     {
					arg1322_250 = CNST_TABLE_REF(((long) 19));
				     }
				}
				arg1323_251 = PROCEDURE_ENTRY(e_233) (e_233, a1_235, e_233, BEOA);
				arg1324_252 = PROCEDURE_ENTRY(e_233) (e_233, a2_236, e_233, BEOA);
				{
				   obj_t list1326_254;
				   {
				      obj_t arg1328_255;
				      {
					 obj_t arg1330_256;
					 arg1330_256 = MAKE_PAIR(BNIL, BNIL);
					 arg1328_255 = MAKE_PAIR(arg1324_252, arg1330_256);
				      }
				      list1326_254 = MAKE_PAIR(arg1323_251, arg1328_255);
				   }
				   return cons__138___r4_pairs_and_lists_6_3(arg1322_250, list1326_254);
				}
			     }
			  }
			else
			  {
			   tag_208_160_238:
			     FAILURE(BFALSE, string2912_expand_install, x_232);
			  }
		     }
		   else
		     {
			goto tag_208_160_238;
		     }
		}
	      else
		{
		   goto tag_208_160_238;
		}
	   }
	 else
	   {
	      goto tag_208_160_238;
	   }
      }
   }
}


/* arg1282 */ obj_t 
arg1282_expand_install(obj_t env_2416, obj_t x_2417, obj_t e_2418)
{
   {
      obj_t x_199;
      obj_t e_200;
      x_199 = x_2417;
      e_200 = e_2418;
      {
	 obj_t fun_202;
	 obj_t a_203;
	 obj_t d_204;
	 if (PAIRP(x_199))
	   {
	      obj_t cdr_196_23_209;
	      cdr_196_23_209 = CDR(x_199);
	      if (PAIRP(cdr_196_23_209))
		{
		   obj_t cdr_201_92_211;
		   cdr_201_92_211 = CDR(cdr_196_23_209);
		   if (PAIRP(cdr_201_92_211))
		     {
			bool_t test_4078;
			{
			   obj_t aux_4079;
			   aux_4079 = CDR(cdr_201_92_211);
			   test_4078 = (aux_4079 == BNIL);
			}
			if (test_4078)
			  {
			     fun_202 = CAR(x_199);
			     a_203 = CAR(cdr_196_23_209);
			     d_204 = CAR(cdr_201_92_211);
			     {
				obj_t arg1295_219;
				obj_t arg1296_220;
				obj_t arg1297_221;
				arg1295_219 = CNST_TABLE_REF(((long) 16));
				arg1296_220 = PROCEDURE_ENTRY(e_200) (e_200, a_203, e_200, BEOA);
				arg1297_221 = PROCEDURE_ENTRY(e_200) (e_200, d_204, e_200, BEOA);
				{
				   obj_t list1299_223;
				   {
				      obj_t arg1300_224;
				      {
					 obj_t arg1301_225;
					 arg1301_225 = MAKE_PAIR(BNIL, BNIL);
					 arg1300_224 = MAKE_PAIR(arg1297_221, arg1301_225);
				      }
				      list1299_223 = MAKE_PAIR(arg1296_220, arg1300_224);
				   }
				   return cons__138___r4_pairs_and_lists_6_3(arg1295_219, list1299_223);
				}
			     }
			  }
			else
			  {
			   tag_187_23_206:
			     FAILURE(BFALSE, string2913_expand_install, x_199);
			  }
		     }
		   else
		     {
			goto tag_187_23_206;
		     }
		}
	      else
		{
		   goto tag_187_23_206;
		}
	   }
	 else
	   {
	      goto tag_187_23_206;
	   }
      }
   }
}


/* arg1263 */ obj_t 
arg1263_expand_install(obj_t env_2419, obj_t x_2420, obj_t e_2421)
{
   {
      obj_t x_175;
      obj_t e_176;
      x_175 = x_2420;
      e_176 = e_2421;
      {
	 obj_t s_178;
	 if (PAIRP(x_175))
	   {
	      obj_t cdr_181_17_183;
	      cdr_181_17_183 = CDR(x_175);
	      if (PAIRP(cdr_181_17_183))
		{
		   bool_t test_4100;
		   {
		      obj_t aux_4101;
		      aux_4101 = CDR(cdr_181_17_183);
		      test_4100 = (aux_4101 == BNIL);
		   }
		   if (test_4100)
		     {
			s_178 = CAR(cdr_181_17_183);
			if (STRINGP(s_178))
			  {
			     long aux_4106;
			     aux_4106 = STRING_LENGTH(s_178);
			     return BINT(aux_4106);
			  }
			else
			  {
			     obj_t arg1272_190;
			     obj_t arg1273_191;
			     arg1272_190 = CNST_TABLE_REF(((long) 15));
			     arg1273_191 = PROCEDURE_ENTRY(e_176) (e_176, s_178, e_176, BEOA);
			     {
				obj_t list1275_193;
				{
				   obj_t arg1277_194;
				   arg1277_194 = MAKE_PAIR(BNIL, BNIL);
				   list1275_193 = MAKE_PAIR(arg1273_191, arg1277_194);
				}
				return cons__138___r4_pairs_and_lists_6_3(arg1272_190, list1275_193);
			     }
			  }
		     }
		   else
		     {
		      tag_176_16_180:
			FAILURE(BFALSE, string2914_expand_install, x_175);
		     }
		}
	      else
		{
		   goto tag_176_16_180;
		}
	   }
	 else
	   {
	      goto tag_176_16_180;
	   }
      }
   }
}


/* arg1219 */ obj_t 
arg1219_expand_install(obj_t env_2422, obj_t x_2423, obj_t e_2424)
{
   {
      obj_t x_119;
      obj_t e_120;
      x_119 = x_2423;
      e_120 = e_2424;
      {
	 obj_t lists_125;
	 obj_t s1_122;
	 obj_t s2_123;
	 if (PAIRP(x_119))
	   {
	      obj_t cdr_148_78_130;
	      cdr_148_78_130 = CDR(x_119);
	      if (PAIRP(cdr_148_78_130))
		{
		   obj_t cdr_152_12_132;
		   cdr_152_12_132 = CDR(cdr_148_78_130);
		   if (PAIRP(cdr_152_12_132))
		     {
			bool_t test_4125;
			{
			   obj_t aux_4126;
			   aux_4126 = CDR(cdr_152_12_132);
			   test_4125 = (aux_4126 == BNIL);
			}
			if (test_4125)
			  {
			     s1_122 = CAR(cdr_148_78_130);
			     s2_123 = CAR(cdr_152_12_132);
			     {
				obj_t arg1235_142;
				obj_t arg1236_143;
				obj_t arg1238_144;
				arg1235_142 = CNST_TABLE_REF(((long) 92));
				arg1236_143 = PROCEDURE_ENTRY(e_120) (e_120, s1_122, e_120, BEOA);
				arg1238_144 = PROCEDURE_ENTRY(e_120) (e_120, s2_123, e_120, BEOA);
				{
				   obj_t list1241_146;
				   {
				      obj_t arg1243_147;
				      {
					 obj_t arg1244_148;
					 arg1244_148 = MAKE_PAIR(BNIL, BNIL);
					 arg1243_147 = MAKE_PAIR(arg1238_144, arg1244_148);
				      }
				      list1241_146 = MAKE_PAIR(arg1236_143, arg1243_147);
				   }
				   return cons__138___r4_pairs_and_lists_6_3(arg1235_142, list1241_146);
				}
			     }
			  }
			else
			  {
			     lists_125 = cdr_148_78_130;
			   tag_139_224_126:
			     {
				obj_t arg1247_150;
				obj_t arg1248_151;
				arg1247_150 = CNST_TABLE_REF(((long) 14));
				{
				   obj_t arg1251_154;
				   obj_t arg1252_155;
				   if (NULLP(lists_125))
				     {
					arg1251_154 = BNIL;
				     }
				   else
				     {
					obj_t head1035_158;
					head1035_158 = MAKE_PAIR(BNIL, BNIL);
					{
					   obj_t l1033_159;
					   obj_t tail1036_160;
					   l1033_159 = lists_125;
					   tail1036_160 = head1035_158;
					 lname1034_161:
					   if (NULLP(l1033_159))
					     {
						arg1251_154 = CDR(head1035_158);
					     }
					   else
					     {
						obj_t newtail1037_163;
						{
						   obj_t arg1256_165;
						   arg1256_165 = PROCEDURE_ENTRY(e_120) (e_120, CAR(l1033_159), e_120, BEOA);
						   newtail1037_163 = MAKE_PAIR(arg1256_165, BNIL);
						}
						SET_CDR(tail1036_160, newtail1037_163);
						{
						   obj_t tail1036_4154;
						   obj_t l1033_4152;
						   l1033_4152 = CDR(l1033_159);
						   tail1036_4154 = newtail1037_163;
						   tail1036_160 = tail1036_4154;
						   l1033_159 = l1033_4152;
						   goto lname1034_161;
						}
					     }
					}
				     }
				   arg1252_155 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				   arg1248_151 = append_2_18___r4_pairs_and_lists_6_3(arg1251_154, arg1252_155);
				}
				{
				   obj_t list1249_152;
				   list1249_152 = MAKE_PAIR(arg1248_151, BNIL);
				   return cons__138___r4_pairs_and_lists_6_3(arg1247_150, list1249_152);
				}
			     }
			  }
		     }
		   else
		     {
			obj_t lists_4159;
			lists_4159 = cdr_148_78_130;
			lists_125 = lists_4159;
			goto tag_139_224_126;
		     }
		}
	      else
		{
		   obj_t lists_4160;
		   lists_4160 = cdr_148_78_130;
		   lists_125 = lists_4160;
		   goto tag_139_224_126;
		}
	   }
	 else
	   {
	      FAILURE(BFALSE, string2915_expand_install, x_119);
	   }
      }
   }
}


/* arg1142 */ obj_t 
arg1142_expand_install(obj_t env_2425, obj_t x_2426, obj_t e_2427)
{
   {
      obj_t x_63;
      obj_t e_64;
      x_63 = x_2426;
      e_64 = e_2427;
      {
	 obj_t lists_69;
	 obj_t l1_66;
	 obj_t l2_67;
	 if (PAIRP(x_63))
	   {
	      obj_t cdr_111_186_74;
	      cdr_111_186_74 = CDR(x_63);
	      if (PAIRP(cdr_111_186_74))
		{
		   obj_t cdr_115_115_76;
		   cdr_115_115_76 = CDR(cdr_111_186_74);
		   if (PAIRP(cdr_115_115_76))
		     {
			bool_t test_4170;
			{
			   obj_t aux_4171;
			   aux_4171 = CDR(cdr_115_115_76);
			   test_4170 = (aux_4171 == BNIL);
			}
			if (test_4170)
			  {
			     l1_66 = CAR(cdr_111_186_74);
			     l2_67 = CAR(cdr_115_115_76);
			     {
				obj_t arg1190_86;
				obj_t arg1191_87;
				obj_t arg1192_88;
				arg1190_86 = CNST_TABLE_REF(((long) 93));
				arg1191_87 = PROCEDURE_ENTRY(e_64) (e_64, l1_66, e_64, BEOA);
				arg1192_88 = PROCEDURE_ENTRY(e_64) (e_64, l2_67, e_64, BEOA);
				{
				   obj_t list1194_90;
				   {
				      obj_t arg1195_91;
				      {
					 obj_t arg1196_92;
					 arg1196_92 = MAKE_PAIR(BNIL, BNIL);
					 arg1195_91 = MAKE_PAIR(arg1192_88, arg1196_92);
				      }
				      list1194_90 = MAKE_PAIR(arg1191_87, arg1195_91);
				   }
				   return cons__138___r4_pairs_and_lists_6_3(arg1190_86, list1194_90);
				}
			     }
			  }
			else
			  {
			     lists_69 = cdr_111_186_74;
			   tag_102_241_70:
			     {
				obj_t arg1199_94;
				obj_t arg1200_95;
				arg1199_94 = CNST_TABLE_REF(((long) 13));
				{
				   obj_t arg1203_98;
				   obj_t arg1204_99;
				   if (NULLP(lists_69))
				     {
					arg1203_98 = BNIL;
				     }
				   else
				     {
					obj_t head1030_102;
					head1030_102 = MAKE_PAIR(BNIL, BNIL);
					{
					   obj_t l1028_103;
					   obj_t tail1031_104;
					   l1028_103 = lists_69;
					   tail1031_104 = head1030_102;
					 lname1029_105:
					   if (NULLP(l1028_103))
					     {
						arg1203_98 = CDR(head1030_102);
					     }
					   else
					     {
						obj_t newtail1032_107;
						{
						   obj_t arg1209_109;
						   arg1209_109 = PROCEDURE_ENTRY(e_64) (e_64, CAR(l1028_103), e_64, BEOA);
						   newtail1032_107 = MAKE_PAIR(arg1209_109, BNIL);
						}
						SET_CDR(tail1031_104, newtail1032_107);
						{
						   obj_t tail1031_4199;
						   obj_t l1028_4197;
						   l1028_4197 = CDR(l1028_103);
						   tail1031_4199 = newtail1032_107;
						   tail1031_104 = tail1031_4199;
						   l1028_103 = l1028_4197;
						   goto lname1029_105;
						}
					     }
					}
				     }
				   arg1204_99 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				   arg1200_95 = append_2_18___r4_pairs_and_lists_6_3(arg1203_98, arg1204_99);
				}
				{
				   obj_t list1201_96;
				   list1201_96 = MAKE_PAIR(arg1200_95, BNIL);
				   return cons__138___r4_pairs_and_lists_6_3(arg1199_94, list1201_96);
				}
			     }
			  }
		     }
		   else
		     {
			obj_t lists_4204;
			lists_4204 = cdr_111_186_74;
			lists_69 = lists_4204;
			goto tag_102_241_70;
		     }
		}
	      else
		{
		   obj_t lists_4205;
		   lists_4205 = cdr_111_186_74;
		   lists_69 = lists_4205;
		   goto tag_102_241_70;
		}
	   }
	 else
	   {
	      FAILURE(BFALSE, string2916_expand_install, x_63);
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_expand_install()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_install()
{
   module_initialization_70_expand_if(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_lambda(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_define(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_expander(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_exit(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_garithmetique(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_iarithmetique(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_farithmetique(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_let(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_case(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_struct(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_map(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_assert(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_expand_object(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_tools_progn(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_engine_param(((long) 0), "EXPAND_INSTALL");
   module_initialization_70_type_type(((long) 0), "EXPAND_INSTALL");
   return module_initialization_70_ast_ident(((long) 0), "EXPAND_INSTALL");
}
