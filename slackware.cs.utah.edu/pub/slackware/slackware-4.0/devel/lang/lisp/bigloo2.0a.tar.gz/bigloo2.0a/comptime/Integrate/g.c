/*===========================================================================*/
/*   (Integrate/g.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t method_init_76_integrate_g();
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_g(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70_integrate_a(long, char *);
extern obj_t module_initialization_70___object(long, char *);
static bool_t integrate_remaining_local_functions__137_integrate_g();
static obj_t imported_modules_init_94_integrate_g();
static obj_t library_modules_init_112_integrate_g();
extern obj_t variable_ast_var;
extern obj_t local_ast_var;
extern obj_t g__63_integrate_g(obj_t);
extern obj_t _phi__105_integrate_a;
static obj_t require_initialization_114_integrate_g = BUNSPEC;
static obj_t _g__236_integrate_g(obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(g__env_111_integrate_g, _g__236_integrate_g1693, _g__236_integrate_g, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_integrate_g(long checksum_1469, char *from_1470)
{
   if (CBOOL(require_initialization_114_integrate_g))
     {
	require_initialization_114_integrate_g = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_g();
	imported_modules_init_94_integrate_g();
	method_init_76_integrate_g();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_g()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_G");
   return BUNSPEC;
}


/* g! */ obj_t 
g__63_integrate_g(obj_t g_cn_224_1)
{
   {
      bool_t stop__17_879;
      long stamp_880;
      obj_t gs_881;
      stop__17_879 = ((bool_t) 0);
      stamp_880 = ((long) 0);
      gs_881 = g_cn_224_1;
    loop_882:
      if (stop__17_879)
	{
	   {
	      obj_t l1517_883;
	      l1517_883 = _phi__105_integrate_a;
	    lname1518_884:
	      if (PAIRP(l1517_883))
		{
		   {
		      obj_t f_886;
		      f_886 = CAR(l1517_883);
		      {
			 bool_t test1524_887;
			 test1524_887 = is_a__118___object(f_886, local_ast_var);
			 if (test1524_887)
			   {
			      sfun_iinfo_105_t obj_1333;
			      obj_t val1513_1334;
			      {
				 value_t aux_1484;
				 {
				    local_t obj_1332;
				    obj_1332 = (local_t) (f_886);
				    aux_1484 = (((local_t) CREF(obj_1332))->value);
				 }
				 obj_1333 = (sfun_iinfo_105_t) (aux_1484);
			      }
			      val1513_1334 = BINT(((long) -1));
			      {
				 obj_t aux_1489;
				 {
				    object_t aux_1490;
				    aux_1490 = (object_t) (obj_1333);
				    aux_1489 = OBJECT_WIDENING(aux_1490);
				 }
				 ((((sfun_iinfo_105_t) CREF(aux_1489))->istamp) = ((obj_t) val1513_1334), BUNSPEC);
			      }
			   }
			 else
			   {
			      BUNSPEC;
			   }
		      }
		   }
		   {
		      obj_t l1517_1494;
		      l1517_1494 = CDR(l1517_883);
		      l1517_883 = l1517_1494;
		      goto lname1518_884;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   integrate_remaining_local_functions__137_integrate_g();
	   return gs_881;
	}
      else
	{
	   obj_t phi_891;
	   bool_t stop__17_892;
	   obj_t gs_893;
	   phi_891 = _phi__105_integrate_a;
	   stop__17_892 = ((bool_t) 1);
	   gs_893 = gs_881;
	 liip_894:
	   if (NULLP(phi_891))
	     {
		obj_t gs_1502;
		long stamp_1500;
		bool_t stop__17_1499;
		stop__17_1499 = stop__17_892;
		stamp_1500 = (stamp_880 + ((long) 1));
		gs_1502 = gs_893;
		gs_881 = gs_1502;
		stamp_880 = stamp_1500;
		stop__17_879 = stop__17_1499;
		goto loop_882;
	     }
	   else
	     {
		obj_t f_897;
		f_897 = CAR(phi_891);
		{
		   value_t fif_898;
		   {
		      variable_t obj_1340;
		      obj_1340 = (variable_t) (f_897);
		      fif_898 = (((variable_t) CREF(obj_1340))->value);
		   }
		   {
		      {
			 obj_t ct_899;
			 bool_t stop__17_900;
			 obj_t gs_901;
			 {
			    sfun_iinfo_105_t obj_1341;
			    obj_1341 = (sfun_iinfo_105_t) (fif_898);
			    {
			       obj_t aux_1692;
			       {
				  object_t aux_1693;
				  aux_1693 = (object_t) (obj_1341);
				  aux_1692 = OBJECT_WIDENING(aux_1693);
			       }
			       ct_899 = (((sfun_iinfo_105_t) CREF(aux_1692))->ct);
			    }
			 }
			 stop__17_900 = stop__17_892;
			 gs_901 = gs_893;
		       laap_902:
			 if (NULLP(ct_899))
			   {
			      obj_t gs_1511;
			      bool_t stop__17_1510;
			      obj_t phi_1508;
			      phi_1508 = CDR(phi_891);
			      stop__17_1510 = stop__17_900;
			      gs_1511 = gs_901;
			      gs_893 = gs_1511;
			      stop__17_892 = stop__17_1510;
			      phi_891 = phi_1508;
			      goto liip_894;
			   }
			 else
			   {
			      obj_t g_906;
			      g_906 = CAR(ct_899);
			      {
				 value_t gif_907;
				 {
				    local_t obj_1345;
				    obj_1345 = (local_t) (g_906);
				    gif_907 = (((local_t) CREF(obj_1345))->value);
				 }
				 {
				    if ((f_897 == g_906))
				      {
					 {
					    obj_t ct_1517;
					    ct_1517 = CDR(ct_899);
					    ct_899 = ct_1517;
					    goto laap_902;
					 }
				      }
				    else
				      {
					 bool_t test_1519;
					 {
					    sfun_iinfo_105_t obj_1349;
					    obj_1349 = (sfun_iinfo_105_t) (gif_907);
					    {
					       obj_t aux_1521;
					       {
						  object_t aux_1522;
						  aux_1522 = (object_t) (obj_1349);
						  aux_1521 = OBJECT_WIDENING(aux_1522);
					       }
					       test_1519 = (((sfun_iinfo_105_t) CREF(aux_1521))->g__219);
					    }
					 }
					 if (test_1519)
					   {
					      {
						 obj_t ct_1526;
						 ct_1526 = CDR(ct_899);
						 ct_899 = ct_1526;
						 goto laap_902;
					      }
					   }
					 else
					   {
					      bool_t test_1528;
					      {
						 sfun_iinfo_105_t obj_1351;
						 obj_1351 = (sfun_iinfo_105_t) (fif_898);
						 {
						    obj_t aux_1530;
						    {
						       object_t aux_1531;
						       aux_1531 = (object_t) (obj_1351);
						       aux_1530 = OBJECT_WIDENING(aux_1531);
						    }
						    test_1528 = (((sfun_iinfo_105_t) CREF(aux_1530))->g__219);
						 }
					      }
					      if (test_1528)
						{
						   {
						      bool_t test1538_913;
						      {
							 obj_t aux_1535;
							 {
							    sfun_iinfo_105_t obj_1352;
							    obj_1352 = (sfun_iinfo_105_t) (gif_907);
							    {
							       obj_t aux_1537;
							       {
								  object_t aux_1538;
								  aux_1538 = (object_t) (obj_1352);
								  aux_1537 = OBJECT_WIDENING(aux_1538);
							       }
							       aux_1535 = (((sfun_iinfo_105_t) CREF(aux_1537))->l);
							    }
							 }
							 test1538_913 = is_a__118___object(aux_1535, variable_ast_var);
						      }
						      if (test1538_913)
							{
							   bool_t test_1544;
							   {
							      obj_t aux_1545;
							      {
								 sfun_iinfo_105_t obj_1354;
								 obj_1354 = (sfun_iinfo_105_t) (gif_907);
								 {
								    obj_t aux_1547;
								    {
								       object_t aux_1548;
								       aux_1548 = (object_t) (obj_1354);
								       aux_1547 = OBJECT_WIDENING(aux_1548);
								    }
								    aux_1545 = (((sfun_iinfo_105_t) CREF(aux_1547))->l);
								 }
							      }
							      test_1544 = (aux_1545 == f_897);
							   }
							   if (test_1544)
							     {
								{
								   obj_t ct_1553;
								   ct_1553 = CDR(ct_899);
								   ct_899 = ct_1553;
								   goto laap_902;
								}
							     }
							   else
							     {
								{
								   sfun_iinfo_105_t obj_1358;
								   obj_1358 = (sfun_iinfo_105_t) (gif_907);
								   {
								      obj_t aux_1556;
								      {
									 object_t aux_1557;
									 aux_1557 = (object_t) (obj_1358);
									 aux_1556 = OBJECT_WIDENING(aux_1557);
								      }
								      ((((sfun_iinfo_105_t) CREF(aux_1556))->g__219) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								   }
								}
								{
								   obj_t arg1542_916;
								   obj_t arg1545_917;
								   arg1542_916 = CDR(ct_899);
								   arg1545_917 = MAKE_PAIR(g_906, gs_901);
								   {
								      obj_t gs_1565;
								      bool_t stop__17_1564;
								      obj_t ct_1563;
								      ct_1563 = arg1542_916;
								      stop__17_1564 = ((bool_t) 0);
								      gs_1565 = arg1545_917;
								      gs_901 = gs_1565;
								      stop__17_900 = stop__17_1564;
								      ct_899 = ct_1563;
								      goto laap_902;
								   }
								}
							     }
							}
						      else
							{
							   {
							      sfun_iinfo_105_t obj_1363;
							      obj_1363 = (sfun_iinfo_105_t) (gif_907);
							      {
								 obj_t aux_1567;
								 {
								    object_t aux_1568;
								    aux_1568 = (object_t) (obj_1363);
								    aux_1567 = OBJECT_WIDENING(aux_1568);
								 }
								 ((((sfun_iinfo_105_t) CREF(aux_1567))->l) = ((obj_t) f_897), BUNSPEC);
							      }
							   }
							   {
							      bool_t stop__17_1574;
							      obj_t ct_1572;
							      ct_1572 = CDR(ct_899);
							      stop__17_1574 = ((bool_t) 0);
							      stop__17_900 = stop__17_1574;
							      ct_899 = ct_1572;
							      goto laap_902;
							   }
							}
						   }
						}
					      else
						{
						   bool_t test1551_921;
						   {
						      obj_t aux_1575;
						      {
							 sfun_iinfo_105_t obj_1366;
							 obj_1366 = (sfun_iinfo_105_t) (gif_907);
							 {
							    obj_t aux_1577;
							    {
							       object_t aux_1578;
							       aux_1578 = (object_t) (obj_1366);
							       aux_1577 = OBJECT_WIDENING(aux_1578);
							    }
							    aux_1575 = (((sfun_iinfo_105_t) CREF(aux_1577))->l);
							 }
						      }
						      test1551_921 = is_a__118___object(aux_1575, variable_ast_var);
						   }
						   if (test1551_921)
						     {
							bool_t test1552_922;
							{
							   obj_t aux_1584;
							   {
							      sfun_iinfo_105_t obj_1368;
							      obj_1368 = (sfun_iinfo_105_t) (fif_898);
							      {
								 obj_t aux_1586;
								 {
								    object_t aux_1587;
								    aux_1587 = (object_t) (obj_1368);
								    aux_1586 = OBJECT_WIDENING(aux_1587);
								 }
								 aux_1584 = (((sfun_iinfo_105_t) CREF(aux_1586))->l);
							      }
							   }
							   test1552_922 = is_a__118___object(aux_1584, variable_ast_var);
							}
							if (test1552_922)
							  {
							     bool_t test_1593;
							     {
								obj_t aux_1601;
								obj_t aux_1594;
								{
								   sfun_iinfo_105_t obj_1371;
								   obj_1371 = (sfun_iinfo_105_t) (gif_907);
								   {
								      obj_t aux_1603;
								      {
									 object_t aux_1604;
									 aux_1604 = (object_t) (obj_1371);
									 aux_1603 = OBJECT_WIDENING(aux_1604);
								      }
								      aux_1601 = (((sfun_iinfo_105_t) CREF(aux_1603))->l);
								   }
								}
								{
								   sfun_iinfo_105_t obj_1370;
								   obj_1370 = (sfun_iinfo_105_t) (fif_898);
								   {
								      obj_t aux_1596;
								      {
									 object_t aux_1597;
									 aux_1597 = (object_t) (obj_1370);
									 aux_1596 = OBJECT_WIDENING(aux_1597);
								      }
								      aux_1594 = (((sfun_iinfo_105_t) CREF(aux_1596))->l);
								   }
								}
								test_1593 = (aux_1594 == aux_1601);
							     }
							     if (test_1593)
							       {
								  {
								     obj_t ct_1609;
								     ct_1609 = CDR(ct_899);
								     ct_899 = ct_1609;
								     goto laap_902;
								  }
							       }
							     else
							       {
								  {
								     sfun_iinfo_105_t obj_1375;
								     obj_1375 = (sfun_iinfo_105_t) (gif_907);
								     {
									obj_t aux_1612;
									{
									   object_t aux_1613;
									   aux_1613 = (object_t) (obj_1375);
									   aux_1612 = OBJECT_WIDENING(aux_1613);
									}
									((((sfun_iinfo_105_t) CREF(aux_1612))->g__219) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								     }
								  }
								  {
								     obj_t arg1555_925;
								     obj_t arg1556_926;
								     arg1555_925 = CDR(ct_899);
								     arg1556_926 = MAKE_PAIR(g_906, gs_901);
								     {
									obj_t gs_1621;
									bool_t stop__17_1620;
									obj_t ct_1619;
									ct_1619 = arg1555_925;
									stop__17_1620 = ((bool_t) 0);
									gs_1621 = arg1556_926;
									gs_901 = gs_1621;
									stop__17_900 = stop__17_1620;
									ct_899 = ct_1619;
									goto laap_902;
								     }
								  }
							       }
							  }
							else
							  {
							     {
								obj_t arg1559_929;
								{
								   sfun_iinfo_105_t obj_1380;
								   obj_1380 = (sfun_iinfo_105_t) (gif_907);
								   {
								      obj_t aux_1623;
								      {
									 object_t aux_1624;
									 aux_1624 = (object_t) (obj_1380);
									 aux_1623 = OBJECT_WIDENING(aux_1624);
								      }
								      arg1559_929 = (((sfun_iinfo_105_t) CREF(aux_1623))->l);
								   }
								}
								{
								   sfun_iinfo_105_t obj_1381;
								   obj_1381 = (sfun_iinfo_105_t) (fif_898);
								   {
								      obj_t aux_1629;
								      {
									 object_t aux_1630;
									 aux_1630 = (object_t) (obj_1381);
									 aux_1629 = OBJECT_WIDENING(aux_1630);
								      }
								      ((((sfun_iinfo_105_t) CREF(aux_1629))->l) = ((obj_t) arg1559_929), BUNSPEC);
								   }
								}
							     }
							     {
								bool_t stop__17_1636;
								obj_t ct_1634;
								ct_1634 = CDR(ct_899);
								stop__17_1636 = ((bool_t) 0);
								stop__17_900 = stop__17_1636;
								ct_899 = ct_1634;
								goto laap_902;
							     }
							  }
						     }
						   else
						     {
							{
							   bool_t test1562_932;
							   {
							      obj_t aux_1637;
							      {
								 sfun_iinfo_105_t obj_1384;
								 obj_1384 = (sfun_iinfo_105_t) (fif_898);
								 {
								    obj_t aux_1639;
								    {
								       object_t aux_1640;
								       aux_1640 = (object_t) (obj_1384);
								       aux_1639 = OBJECT_WIDENING(aux_1640);
								    }
								    aux_1637 = (((sfun_iinfo_105_t) CREF(aux_1639))->l);
								 }
							      }
							      test1562_932 = is_a__118___object(aux_1637, variable_ast_var);
							   }
							   if (test1562_932)
							     {
								{
								   obj_t arg1563_933;
								   {
								      sfun_iinfo_105_t obj_1386;
								      obj_1386 = (sfun_iinfo_105_t) (fif_898);
								      {
									 obj_t aux_1647;
									 {
									    object_t aux_1648;
									    aux_1648 = (object_t) (obj_1386);
									    aux_1647 = OBJECT_WIDENING(aux_1648);
									 }
									 arg1563_933 = (((sfun_iinfo_105_t) CREF(aux_1647))->l);
								      }
								   }
								   {
								      sfun_iinfo_105_t obj_1387;
								      obj_1387 = (sfun_iinfo_105_t) (gif_907);
								      {
									 obj_t aux_1653;
									 {
									    object_t aux_1654;
									    aux_1654 = (object_t) (obj_1387);
									    aux_1653 = OBJECT_WIDENING(aux_1654);
									 }
									 ((((sfun_iinfo_105_t) CREF(aux_1653))->l) = ((obj_t) arg1563_933), BUNSPEC);
								      }
								   }
								}
								{
								   bool_t stop__17_1660;
								   obj_t ct_1658;
								   ct_1658 = CDR(ct_899);
								   stop__17_1660 = ((bool_t) 0);
								   stop__17_900 = stop__17_1660;
								   ct_899 = ct_1658;
								   goto laap_902;
								}
							     }
							   else
							     {
								{
								   bool_t stop__17_935;
								   if (stop__17_900)
								     {
									bool_t test_1662;
									{
									   obj_t aux_1663;
									   {
									      sfun_iinfo_105_t obj_1390;
									      obj_1390 = (sfun_iinfo_105_t) (fif_898);
									      {
										 obj_t aux_1665;
										 {
										    object_t aux_1666;
										    aux_1666 = (object_t) (obj_1390);
										    aux_1665 = OBJECT_WIDENING(aux_1666);
										 }
										 aux_1663 = (((sfun_iinfo_105_t) CREF(aux_1665))->istamp);
									      }
									   }
									   test_1662 = INTEGERP(aux_1663);
									}
									if (test_1662)
									  {
									     long aux_1671;
									     {
										obj_t aux_1672;
										{
										   sfun_iinfo_105_t obj_1392;
										   obj_1392 = (sfun_iinfo_105_t) (fif_898);
										   {
										      obj_t aux_1674;
										      {
											 object_t aux_1675;
											 aux_1675 = (object_t) (obj_1392);
											 aux_1674 = OBJECT_WIDENING(aux_1675);
										      }
										      aux_1672 = (((sfun_iinfo_105_t) CREF(aux_1674))->istamp);
										   }
										}
										aux_1671 = (long) CINT(aux_1672);
									     }
									     stop__17_935 = (aux_1671 <= stamp_880);
									  }
									else
									  {
									     stop__17_935 = ((bool_t) 0);
									  }
								     }
								   else
								     {
									stop__17_935 = ((bool_t) 0);
								     }
								   {
								      sfun_iinfo_105_t obj_1395;
								      obj_t val1513_1396;
								      obj_1395 = (sfun_iinfo_105_t) (fif_898);
								      val1513_1396 = BINT(stamp_880);
								      {
									 obj_t aux_1683;
									 {
									    object_t aux_1684;
									    aux_1684 = (object_t) (obj_1395);
									    aux_1683 = OBJECT_WIDENING(aux_1684);
									 }
									 ((((sfun_iinfo_105_t) CREF(aux_1683))->istamp) = ((obj_t) val1513_1396), BUNSPEC);
								      }
								   }
								   {
								      bool_t stop__17_1690;
								      obj_t ct_1688;
								      ct_1688 = CDR(ct_899);
								      stop__17_1690 = stop__17_935;
								      stop__17_900 = stop__17_1690;
								      ct_899 = ct_1688;
								      goto laap_902;
								   }
								}
							     }
							}
						     }
						}
					   }
				      }
				 }
			      }
			   }
		      }
		   }
		}
	     }
	}
   }
}


/* _g! */ obj_t 
_g__236_integrate_g(obj_t env_1467, obj_t g_cn_224_1468)
{
   return g__63_integrate_g(g_cn_224_1468);
}


/* integrate-remaining-local-functions! */ bool_t 
integrate_remaining_local_functions__137_integrate_g()
{
   {
      obj_t l1521_943;
      l1521_943 = _phi__105_integrate_a;
    lname1522_944:
      if (PAIRP(l1521_943))
	{
	   {
	      obj_t f_946;
	      f_946 = CAR(l1521_943);
	      {
		 bool_t test1572_947;
		 {
		    bool_t test1579_951;
		    test1579_951 = is_a__118___object(f_946, local_ast_var);
		    if (test1579_951)
		      {
			 bool_t test_1703;
			 {
			    sfun_iinfo_105_t obj_1402;
			    {
			       value_t aux_1704;
			       {
				  local_t obj_1401;
				  obj_1401 = (local_t) (f_946);
				  aux_1704 = (((local_t) CREF(obj_1401))->value);
			       }
			       obj_1402 = (sfun_iinfo_105_t) (aux_1704);
			    }
			    {
			       obj_t aux_1708;
			       {
				  object_t aux_1709;
				  aux_1709 = (object_t) (obj_1402);
				  aux_1708 = OBJECT_WIDENING(aux_1709);
			       }
			       test_1703 = (((sfun_iinfo_105_t) CREF(aux_1708))->g__219);
			    }
			 }
			 if (test_1703)
			   {
			      test1572_947 = ((bool_t) 0);
			   }
			 else
			   {
			      bool_t test1581_953;
			      {
				 obj_t aux_1713;
				 {
				    sfun_iinfo_105_t obj_1404;
				    {
				       value_t aux_1714;
				       {
					  local_t obj_1403;
					  obj_1403 = (local_t) (f_946);
					  aux_1714 = (((local_t) CREF(obj_1403))->value);
				       }
				       obj_1404 = (sfun_iinfo_105_t) (aux_1714);
				    }
				    {
				       obj_t aux_1718;
				       {
					  object_t aux_1719;
					  aux_1719 = (object_t) (obj_1404);
					  aux_1718 = OBJECT_WIDENING(aux_1719);
				       }
				       aux_1713 = (((sfun_iinfo_105_t) CREF(aux_1718))->l);
				    }
				 }
				 test1581_953 = is_a__118___object(aux_1713, variable_ast_var);
			      }
			      if (test1581_953)
				{
				   test1572_947 = ((bool_t) 0);
				}
			      else
				{
				   test1572_947 = ((bool_t) 1);
				}
			   }
		      }
		    else
		      {
			 test1572_947 = ((bool_t) 0);
		      }
		 }
		 if (test1572_947)
		   {
		      {
			 obj_t arg1575_949;
			 {
			    sfun_iinfo_105_t obj_1408;
			    {
			       value_t aux_1726;
			       {
				  local_t obj_1407;
				  obj_1407 = (local_t) (f_946);
				  aux_1726 = (((local_t) CREF(obj_1407))->value);
			       }
			       obj_1408 = (sfun_iinfo_105_t) (aux_1726);
			    }
			    {
			       obj_t aux_1730;
			       {
				  object_t aux_1731;
				  aux_1731 = (object_t) (obj_1408);
				  aux_1730 = OBJECT_WIDENING(aux_1731);
			       }
			       arg1575_949 = (((sfun_iinfo_105_t) CREF(aux_1730))->owner);
			    }
			 }
			 {
			    sfun_iinfo_105_t obj_1409;
			    {
			       value_t aux_1735;
			       {
				  local_t obj_1406;
				  obj_1406 = (local_t) (f_946);
				  aux_1735 = (((local_t) CREF(obj_1406))->value);
			       }
			       obj_1409 = (sfun_iinfo_105_t) (aux_1735);
			    }
			    {
			       obj_t aux_1739;
			       {
				  object_t aux_1740;
				  aux_1740 = (object_t) (obj_1409);
				  aux_1739 = OBJECT_WIDENING(aux_1740);
			       }
			       ((((sfun_iinfo_105_t) CREF(aux_1739))->l) = ((obj_t) arg1575_949), BUNSPEC);
			    }
			 }
		      }
		   }
		 else
		   {
		      BUNSPEC;
		   }
	      }
	   }
	   {
	      obj_t l1521_1744;
	      l1521_1744 = CDR(l1521_943);
	      l1521_943 = l1521_1744;
	      goto lname1522_944;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* method-init */ obj_t 
method_init_76_integrate_g()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_g()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_G");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_G");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_G");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_G");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_G");
   module_initialization_70_integrate_info(((long) 0), "INTEGRATE_G");
   return module_initialization_70_integrate_a(((long) 0), "INTEGRATE_G");
}
