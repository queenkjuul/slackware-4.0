/*===========================================================================*/
/*   (Cfa/stack.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;

typedef struct isfun
  {
     struct node *original_body_40;
     obj_t recursive_calls_44;
  }
     *isfun_t;


static obj_t method_init_76_cfa_stack();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t global_ast_var;
static bool_t verb_stat_110_cfa_stack();
extern obj_t pragma_ast_node;
static obj_t _statistics__64_cfa_stack = BUNSPEC;
extern obj_t set_ex_it_116_ast_node;
extern bool_t stack_optimization__133_cfa_stack();
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_cfa_stack(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_inline_inline(long, char *);
extern obj_t module_initialization_70_inline_walk(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static node_t stack__default2129_89_cfa_stack(node_t);
static obj_t _stack___237_cfa_stack(obj_t, obj_t);
extern long class_num_218___object(obj_t);
extern obj_t cfa_iterate__222_cfa_iterate(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_cfa_stack();
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
extern obj_t stack___129_cfa_stack(obj_t);
static obj_t _node_heap__stack_2561_33_cfa_stack(obj_t, obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t heap__stack__166_cfa_stack(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t stack_stat_fail_33_cfa_stack(obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_cfa_stack();
extern node_t inline_node_218_inline_inline(node_t, long, obj_t);
extern obj_t _optim_stack___57_engine_param;
extern node_t node_heap__stack__239_cfa_stack(app_t, bool_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_cfa_stack();
extern obj_t _inlining___224_engine_param;
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t set_looser__198_cfa_loose(obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static obj_t stack_stat_succeed_138_cfa_stack(obj_t);
static obj_t _heap__stack__192_cfa_stack(obj_t, obj_t, obj_t);
static obj_t _stack_2562_230_cfa_stack(obj_t, obj_t);
extern node_t stack__132_cfa_stack(node_t);
static obj_t _stack__default2129_204_cfa_stack(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern obj_t inline_setup__219_inline_walk(obj_t);
static obj_t require_initialization_114_cfa_stack = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t _stack_optimization__209_cfa_stack(obj_t);
static obj_t cnst_init_137_cfa_stack();
static obj_t __cnst[4];

DEFINE_STATIC_PROCEDURE(stack__default2129_env_133_cfa_stack, _stack__default2129_204_cfa_stack2575, _stack__default2129_204_cfa_stack, 0L, 1);
DEFINE_EXPORT_PROCEDURE(node_heap__stack__env_251_cfa_stack, _node_heap__stack_2561_33_cfa_stack2576, _node_heap__stack_2561_33_cfa_stack, 0L, 2);
DEFINE_EXPORT_PROCEDURE(stack_optimization__env_248_cfa_stack, _stack_optimization__209_cfa_stack2577, _stack_optimization__209_cfa_stack, 0L, 0);
DEFINE_EXPORT_PROCEDURE(heap__stack__env_242_cfa_stack, _heap__stack__192_cfa_stack2578, _heap__stack__192_cfa_stack, 0L, 2);
DEFINE_STRING(string2568_cfa_stack, string2568_cfa_stack2579, "STACK!-DEFAULT2129 DONE ALL STACK ", 34);
DEFINE_STRING(string2567_cfa_stack, string2567_cfa_stack2580, "No method for this object", 25);
DEFINE_STRING(string2566_cfa_stack, string2566_cfa_stack2581, "       ", 7);
DEFINE_STRING(string2565_cfa_stack, string2565_cfa_stack2582, ": ", 2);
DEFINE_STRING(string2564_cfa_stack, string2564_cfa_stack2583, " (of ", 5);
DEFINE_STRING(string2563_cfa_stack, string2563_cfa_stack2584, "   . Heap -> Stack", 18);
DEFINE_EXPORT_PROCEDURE(stack___env_10_cfa_stack, _stack___237_cfa_stack2585, _stack___237_cfa_stack, 0L, 1);
DEFINE_EXPORT_GENERIC(stack__env_104_cfa_stack, _stack_2562_230_cfa_stack2586, _stack_2562_230_cfa_stack, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_cfa_stack(long checksum_3745, char *from_3746)
{
   if (CBOOL(require_initialization_114_cfa_stack))
     {
	require_initialization_114_cfa_stack = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_stack();
	cnst_init_137_cfa_stack();
	imported_modules_init_94_cfa_stack();
	method_init_76_cfa_stack();
	toplevel_init_63_cfa_stack();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_stack()
{
   module_initialization_70___object(((long) 0), "CFA_STACK");
   module_initialization_70___r4_strings_6_7(((long) 0), "CFA_STACK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_STACK");
   module_initialization_70___reader(((long) 0), "CFA_STACK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_stack()
{
   {
      obj_t cnst_port_138_3737;
      cnst_port_138_3737 = open_input_string(string2568_cfa_stack);
      {
	 long i_3738;
	 i_3738 = ((long) 3);
       loop_3739:
	 {
	    bool_t test2569_3740;
	    test2569_3740 = (i_3738 == ((long) -1));
	    if (test2569_3740)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2570_3741;
		    {
		       obj_t list2571_3742;
		       {
			  obj_t arg2573_3743;
			  arg2573_3743 = BNIL;
			  list2571_3742 = MAKE_PAIR(cnst_port_138_3737, arg2573_3743);
		       }
		       arg2570_3741 = read___reader(list2571_3742);
		    }
		    CNST_TABLE_SET(i_3738, arg2570_3741);
		 }
		 {
		    int aux_3744;
		    {
		       long aux_3765;
		       aux_3765 = (i_3738 - ((long) 1));
		       aux_3744 = (int) (aux_3765);
		    }
		    {
		       long i_3768;
		       i_3768 = (long) (aux_3744);
		       i_3738 = i_3768;
		       goto loop_3739;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_stack()
{
   _statistics__64_cfa_stack = BNIL;
   return BUNSPEC;
}


/* stack-optimization? */ bool_t 
stack_optimization__133_cfa_stack()
{
   {
      obj_t _andtest_2097_2179;
      _andtest_2097_2179 = _optim_stack___57_engine_param;
      if (CBOOL(_andtest_2097_2179))
	{
	   return CBOOL(_inlining___224_engine_param);
	}
      else
	{
	   return ((bool_t) 0);
	}
   }
}


/* _stack-optimization? */ obj_t 
_stack_optimization__209_cfa_stack(obj_t env_3724)
{
   {
      bool_t aux_3773;
      aux_3773 = stack_optimization__133_cfa_stack();
      return BBOOL(aux_3773);
   }
}


/* heap->stack! */ obj_t 
heap__stack__166_cfa_stack(obj_t roots_1, obj_t globals_2)
{
   if (stack_optimization__133_cfa_stack())
     {
	{
	   obj_t list2152_2181;
	   {
	      obj_t arg2154_2183;
	      {
		 obj_t aux_3778;
		 aux_3778 = BCHAR(((unsigned char) '\n'));
		 arg2154_2183 = MAKE_PAIR(aux_3778, BNIL);
	      }
	      list2152_2181 = MAKE_PAIR(string2563_cfa_stack, arg2154_2183);
	   }
	   verbose_tools_speek(BINT(((long) 1)), list2152_2181);
	}
	set_looser__198_cfa_loose(CNST_TABLE_REF(((long) 0)));
	cfa_iterate__222_cfa_iterate(roots_1);
	inline_setup__219_inline_walk(CNST_TABLE_REF(((long) 1)));
	{
	   obj_t l2098_2187;
	   l2098_2187 = globals_2;
	 lname2099_2188:
	   if (PAIRP(l2098_2187))
	     {
		{
		   value_t fun_2191;
		   {
		      global_t obj_3156;
		      {
			 obj_t aux_3791;
			 aux_3791 = CAR(l2098_2187);
			 obj_3156 = (global_t) (aux_3791);
		      }
		      fun_2191 = (((global_t) CREF(obj_3156))->value);
		   }
		   {
		      node_t arg2159_2192;
		      {
			 node_t aux_3795;
			 {
			    obj_t aux_3796;
			    {
			       sfun_t obj_3157;
			       obj_3157 = (sfun_t) (fun_2191);
			       aux_3796 = (((sfun_t) CREF(obj_3157))->body);
			    }
			    aux_3795 = (node_t) (aux_3796);
			 }
			 arg2159_2192 = stack__132_cfa_stack(aux_3795);
		      }
		      {
			 sfun_t obj_3158;
			 obj_t val1185_3159;
			 obj_3158 = (sfun_t) (fun_2191);
			 val1185_3159 = (obj_t) (arg2159_2192);
			 ((((sfun_t) CREF(obj_3158))->body) = ((obj_t) val1185_3159), BUNSPEC);
		      }
		   }
		}
		{
		   obj_t l2098_3804;
		   l2098_3804 = CDR(l2098_2187);
		   l2098_2187 = l2098_3804;
		   goto lname2099_2188;
		}
	     }
	   else
	     {
		((bool_t) 1);
	     }
	}
	verb_stat_110_cfa_stack();
	return globals_2;
     }
   else
     {
	return BUNSPEC;
     }
}


/* _heap->stack! */ obj_t 
_heap__stack__192_cfa_stack(obj_t env_3725, obj_t roots_3726, obj_t globals_3727)
{
   return heap__stack__166_cfa_stack(roots_3726, globals_3727);
}


/* node-heap->stack! */ node_t 
node_heap__stack__239_cfa_stack(app_t node_3, bool_t stackable__42_4)
{
   {
      variable_t v_2196;
      {
	 var_t arg2174_2210;
	 arg2174_2210 = (((app_t) CREF(node_3))->fun);
	 v_2196 = (((var_t) CREF(arg2174_2210))->variable);
      }
      {
	 value_t f_2197;
	 f_2197 = (((variable_t) CREF(v_2196))->value);
	 {
	    {
	       bool_t test2162_2198;
	       {
		  obj_t aux_3811;
		  {
		     fun_t obj_3164;
		     obj_3164 = (fun_t) (f_2197);
		     aux_3811 = (((fun_t) CREF(obj_3164))->stack_allocator_172);
		  }
		  test2162_2198 = is_a__118___object(aux_3811, global_ast_var);
	       }
	       if (test2162_2198)
		 {
		    if (stackable__42_4)
		      {
			 stack_stat_succeed_138_cfa_stack((((variable_t) CREF(v_2196))->id));
			 {
			    var_t arg2164_2200;
			    {
			       var_t duplicated2101_2201;
			       duplicated2101_2201 = (((app_t) CREF(node_3))->fun);
			       {
				  var_t new2102_2202;
				  {
				     obj_t arg2165_2203;
				     type_t arg2166_2204;
				     arg2165_2203 = (((var_t) CREF(duplicated2101_2201))->loc);
				     arg2166_2204 = (((var_t) CREF(duplicated2101_2201))->type);
				     {
					var_t res2559_3181;
					{
					   variable_t variable_3173;
					   {
					      obj_t aux_3822;
					      {
						 fun_t obj_3170;
						 obj_3170 = (fun_t) (f_2197);
						 aux_3822 = (((fun_t) CREF(obj_3170))->stack_allocator_172);
					      }
					      variable_3173 = (variable_t) (aux_3822);
					   }
					   {
					      var_t new1256_3174;
					      new1256_3174 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
					      {
						 long arg2437_3175;
						 arg2437_3175 = class_num_218___object(var_ast_node);
						 {
						    obj_t obj_3179;
						    obj_3179 = (obj_t) (new1256_3174);
						    (((obj_t) CREF(obj_3179))->header = MAKE_HEADER(arg2437_3175, 0), BUNSPEC);
						 }
					      }
					      {
						 object_t aux_3830;
						 aux_3830 = (object_t) (new1256_3174);
						 OBJECT_WIDENING_SET(aux_3830, BFALSE);
					      }
					      ((((var_t) CREF(new1256_3174))->loc) = ((obj_t) arg2165_2203), BUNSPEC);
					      ((((var_t) CREF(new1256_3174))->type) = ((type_t) arg2166_2204), BUNSPEC);
					      ((((var_t) CREF(new1256_3174))->variable) = ((variable_t) variable_3173), BUNSPEC);
					      res2559_3181 = new1256_3174;
					   }
					}
					new2102_2202 = res2559_3181;
				     }
				  }
				  {
				     arg2164_2200 = new2102_2202;
				  }
			       }
			    }
			    ((((app_t) CREF(node_3))->fun) = ((var_t) arg2164_2200), BUNSPEC);
			 }
			 return inline_node_218_inline_inline((node_t) (node_3), ((long) 1), BNIL);
		      }
		    else
		      {
			 stack_stat_fail_33_cfa_stack((((variable_t) CREF(v_2196))->id));
			 return (node_t) (node_3);
		      }
		 }
	       else
		 {
		    return (node_t) (node_3);
		 }
	    }
	 }
      }
   }
}


/* _node-heap->stack!2561 */ obj_t 
_node_heap__stack_2561_33_cfa_stack(obj_t env_3728, obj_t node_3729, obj_t stackable__42_3730)
{
   {
      node_t aux_3843;
      aux_3843 = node_heap__stack__239_cfa_stack((app_t) (node_3729), CBOOL(stackable__42_3730));
      return (obj_t) (aux_3843);
   }
}


/* stack-stat-succeed */ obj_t 
stack_stat_succeed_138_cfa_stack(obj_t kind_5)
{
   {
      obj_t cell_2211;
      cell_2211 = assq___r4_pairs_and_lists_6_3(kind_5, _statistics__64_cfa_stack);
      if (PAIRP(cell_2211))
	{
	   obj_t aux_3853;
	   obj_t aux_3851;
	   {
	      long aux_3854;
	      {
		 long aux_3855;
		 {
		    obj_t aux_3856;
		    {
		       obj_t aux_3857;
		       aux_3857 = CDR(cell_2211);
		       aux_3856 = CAR(aux_3857);
		    }
		    aux_3855 = (long) CINT(aux_3856);
		 }
		 aux_3854 = (((long) 1) + aux_3855);
	      }
	      aux_3853 = BINT(aux_3854);
	   }
	   aux_3851 = CDR(cell_2211);
	   return SET_CAR(aux_3851, aux_3853);
	}
      else
	{
	   obj_t arg2181_2217;
	   {
	      obj_t arg2182_2218;
	      {
		 obj_t aux_3866;
		 obj_t aux_3864;
		 aux_3866 = BINT(((long) 0));
		 aux_3864 = BINT(((long) 1));
		 arg2182_2218 = MAKE_PAIR(aux_3864, aux_3866);
	      }
	      arg2181_2217 = MAKE_PAIR(kind_5, arg2182_2218);
	   }
	   {
	      obj_t obj2_3200;
	      obj2_3200 = _statistics__64_cfa_stack;
	      return (_statistics__64_cfa_stack = MAKE_PAIR(arg2181_2217, obj2_3200),
		 BUNSPEC);
	   }
	}
   }
}


/* stack-stat-fail */ obj_t 
stack_stat_fail_33_cfa_stack(obj_t kind_6)
{
   {
      obj_t cell_2219;
      cell_2219 = assq___r4_pairs_and_lists_6_3(kind_6, _statistics__64_cfa_stack);
      if (PAIRP(cell_2219))
	{
	   obj_t aux_3876;
	   obj_t aux_3874;
	   {
	      long aux_3877;
	      {
		 long aux_3878;
		 {
		    obj_t aux_3879;
		    {
		       obj_t aux_3880;
		       aux_3880 = CDR(cell_2219);
		       aux_3879 = CDR(aux_3880);
		    }
		    aux_3878 = (long) CINT(aux_3879);
		 }
		 aux_3877 = (((long) 1) + aux_3878);
	      }
	      aux_3876 = BINT(aux_3877);
	   }
	   aux_3874 = CDR(cell_2219);
	   return SET_CDR(aux_3874, aux_3876);
	}
      else
	{
	   obj_t arg2188_2225;
	   {
	      obj_t arg2189_2226;
	      {
		 obj_t aux_3889;
		 obj_t aux_3887;
		 aux_3889 = BINT(((long) 1));
		 aux_3887 = BINT(((long) 0));
		 arg2189_2226 = MAKE_PAIR(aux_3887, aux_3889);
	      }
	      arg2188_2225 = MAKE_PAIR(kind_6, arg2189_2226);
	   }
	   {
	      obj_t obj2_3216;
	      obj2_3216 = _statistics__64_cfa_stack;
	      return (_statistics__64_cfa_stack = MAKE_PAIR(arg2188_2225, obj2_3216),
		 BUNSPEC);
	   }
	}
   }
}


/* verb-stat */ bool_t 
verb_stat_110_cfa_stack()
{
   {
      obj_t l2103_2227;
      l2103_2227 = _statistics__64_cfa_stack;
    lname2104_2228:
      if (PAIRP(l2103_2227))
	{
	   {
	      obj_t stat_2230;
	      stat_2230 = CAR(l2103_2227);
	      {
		 obj_t arg2193_2233;
		 obj_t arg2196_2235;
		 long arg2198_2237;
		 {
		    obj_t arg2209_2247;
		    {
		       obj_t aux_3897;
		       aux_3897 = CAR(stat_2230);
		       arg2209_2247 = SYMBOL_TO_STRING(aux_3897);
		    }
		    arg2193_2233 = string_downcase_77___r4_strings_6_7(arg2209_2247);
		 }
		 {
		    obj_t aux_3901;
		    aux_3901 = CDR(stat_2230);
		    arg2196_2235 = CAR(aux_3901);
		 }
		 {
		    long aux_3910;
		    long aux_3904;
		    {
		       obj_t aux_3911;
		       {
			  obj_t aux_3912;
			  aux_3912 = CDR(stat_2230);
			  aux_3911 = CDR(aux_3912);
		       }
		       aux_3910 = (long) CINT(aux_3911);
		    }
		    {
		       obj_t aux_3905;
		       {
			  obj_t aux_3906;
			  aux_3906 = CDR(stat_2230);
			  aux_3905 = CAR(aux_3906);
		       }
		       aux_3904 = (long) CINT(aux_3905);
		    }
		    arg2198_2237 = (aux_3904 + aux_3910);
		 }
		 {
		    obj_t list2199_2238;
		    {
		       obj_t arg2200_2239;
		       {
			  obj_t arg2201_2240;
			  {
			     obj_t arg2202_2241;
			     {
				obj_t arg2204_2242;
				{
				   obj_t arg2205_2243;
				   {
				      obj_t arg2206_2244;
				      {
					 obj_t arg2207_2245;
					 {
					    obj_t aux_3917;
					    aux_3917 = BCHAR(((unsigned char) '\n'));
					    arg2207_2245 = MAKE_PAIR(aux_3917, BNIL);
					 }
					 {
					    obj_t aux_3920;
					    aux_3920 = BCHAR(((unsigned char) ')'));
					    arg2206_2244 = MAKE_PAIR(aux_3920, arg2207_2245);
					 }
				      }
				      {
					 obj_t aux_3923;
					 aux_3923 = BINT(arg2198_2237);
					 arg2205_2243 = MAKE_PAIR(aux_3923, arg2206_2244);
				      }
				   }
				   arg2204_2242 = MAKE_PAIR(string2564_cfa_stack, arg2205_2243);
				}
				arg2202_2241 = MAKE_PAIR(arg2196_2235, arg2204_2242);
			     }
			     arg2201_2240 = MAKE_PAIR(string2565_cfa_stack, arg2202_2241);
			  }
			  arg2200_2239 = MAKE_PAIR(arg2193_2233, arg2201_2240);
		       }
		       list2199_2238 = MAKE_PAIR(string2566_cfa_stack, arg2200_2239);
		    }
		    verbose_tools_speek(BINT(((long) 2)), list2199_2238);
		 }
	      }
	   }
	   {
	      obj_t l2103_3933;
	      l2103_3933 = CDR(l2103_2227);
	      l2103_2227 = l2103_3933;
	      goto lname2104_2228;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* stack*! */ obj_t 
stack___129_cfa_stack(obj_t node__221_30)
{
   {
      obj_t node__221_2252;
      node__221_2252 = node__221_30;
    loop_2253:
      if (NULLP(node__221_2252))
	{
	   return CNST_TABLE_REF(((long) 2));
	}
      else
	{
	   {
	      node_t arg2216_2255;
	      {
		 node_t aux_3938;
		 {
		    obj_t aux_3939;
		    aux_3939 = CAR(node__221_2252);
		    aux_3938 = (node_t) (aux_3939);
		 }
		 arg2216_2255 = stack__132_cfa_stack(aux_3938);
	      }
	      {
		 obj_t aux_3943;
		 aux_3943 = (obj_t) (arg2216_2255);
		 SET_CAR(node__221_2252, aux_3943);
	      }
	   }
	   {
	      obj_t node__221_3946;
	      node__221_3946 = CDR(node__221_2252);
	      node__221_2252 = node__221_3946;
	      goto loop_2253;
	   }
	}
   }
}


/* _stack*! */ obj_t 
_stack___237_cfa_stack(obj_t env_3731, obj_t node__221_3732)
{
   return stack___129_cfa_stack(node__221_3732);
}


/* method-init */ obj_t 
method_init_76_cfa_stack()
{
   add_generic__110___object(stack__env_104_cfa_stack, stack__default2129_env_133_cfa_stack);
   add_inlined_method__244___object(stack__env_104_cfa_stack, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(stack__env_104_cfa_stack, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(stack__env_104_cfa_stack, var_ast_node, ((long) 2));
   add_inlined_method__244___object(stack__env_104_cfa_stack, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(stack__env_104_cfa_stack, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(stack__env_104_cfa_stack, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(stack__env_104_cfa_stack, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(stack__env_104_cfa_stack, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(stack__env_104_cfa_stack, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(stack__env_104_cfa_stack, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(stack__env_104_cfa_stack, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(stack__env_104_cfa_stack, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(stack__env_104_cfa_stack, select_ast_node, ((long) 12));
   add_inlined_method__244___object(stack__env_104_cfa_stack, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(stack__env_104_cfa_stack, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(stack__env_104_cfa_stack, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(stack__env_104_cfa_stack, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(stack__env_104_cfa_stack, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(stack__env_104_cfa_stack, box_set__221_ast_node, ((long) 18));
   add_inlined_method__244___object(stack__env_104_cfa_stack, box_ref_242_ast_node, ((long) 19));
   {
      long aux_3970;
      aux_3970 = add_inlined_method__244___object(stack__env_104_cfa_stack, app_ast_node, ((long) 20));
      return BINT(aux_3970);
   }
}


/* stack! */ node_t 
stack__132_cfa_stack(node_t node_7)
{
   {
      obj_t method2472_3026;
      obj_t class2477_3027;
      {
	 obj_t arg2480_3024;
	 obj_t arg2481_3025;
	 {
	    object_t obj_3598;
	    obj_3598 = (object_t) (node_7);
	    {
	       obj_t pre_method_105_3599;
	       pre_method_105_3599 = PROCEDURE_REF(stack__env_104_cfa_stack, ((long) 2));
	       if (INTEGERP(pre_method_105_3599))
		 {
		    PROCEDURE_SET(stack__env_104_cfa_stack, ((long) 2), BUNSPEC);
		    arg2480_3024 = pre_method_105_3599;
		 }
	       else
		 {
		    long obj_class_num_177_3604;
		    obj_class_num_177_3604 = TYPE(obj_3598);
		    {
		       obj_t arg1177_3605;
		       arg1177_3605 = PROCEDURE_REF(stack__env_104_cfa_stack, ((long) 1));
		       {
			  long arg1178_3609;
			  {
			     long arg1179_3610;
			     arg1179_3610 = OBJECT_TYPE;
			     arg1178_3609 = (obj_class_num_177_3604 - arg1179_3610);
			  }
			  arg2480_3024 = VECTOR_REF(arg1177_3605, arg1178_3609);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3615;
	    object_3615 = (object_t) (node_7);
	    {
	       long arg1180_3616;
	       {
		  long arg1181_3617;
		  long arg1182_3618;
		  arg1181_3617 = TYPE(object_3615);
		  arg1182_3618 = OBJECT_TYPE;
		  arg1180_3616 = (arg1181_3617 - arg1182_3618);
	       }
	       {
		  obj_t vector_3622;
		  vector_3622 = _classes__134___object;
		  arg2481_3025 = VECTOR_REF(vector_3622, arg1180_3616);
	       }
	    }
	 }
	 {
	    obj_t aux_3988;
	    method2472_3026 = arg2480_3024;
	    class2477_3027 = arg2481_3025;
	    {
	       if (INTEGERP(method2472_3026))
		 {
		    switch ((long) CINT(method2472_3026))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_3991;
			    aux_3991 = (atom_t) (node_7);
			    aux_3988 = (obj_t) (aux_3991);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_3994;
			    aux_3994 = (kwote_t) (node_7);
			    aux_3988 = (obj_t) (aux_3994);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t aux_3997;
			    aux_3997 = (var_t) (node_7);
			    aux_3988 = (obj_t) (aux_3997);
			 }
			 break;
		      case ((long) 3):
			 {
			    closure_t aux_4000;
			    aux_4000 = (closure_t) (node_7);
			    aux_3988 = (obj_t) (aux_4000);
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_3037;
			    node_3037 = (sequence_t) (node_7);
			    stack___129_cfa_stack((((sequence_t) CREF(node_3037))->nodes));
			    aux_3988 = (obj_t) (node_3037);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_3040;
			    node_3040 = (app_ly_162_t) (node_7);
			    {
			       node_t arg2485_3042;
			       arg2485_3042 = stack__132_cfa_stack((((app_ly_162_t) CREF(node_3040))->fun));
			       ((((app_ly_162_t) CREF(node_3040))->fun) = ((node_t) arg2485_3042), BUNSPEC);
			    }
			    {
			       node_t arg2487_3044;
			       arg2487_3044 = stack__132_cfa_stack((((app_ly_162_t) CREF(node_3040))->arg));
			       ((((app_ly_162_t) CREF(node_3040))->arg) = ((node_t) arg2487_3044), BUNSPEC);
			    }
			    aux_3988 = (obj_t) (node_3040);
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_3046;
			    node_3046 = (funcall_t) (node_7);
			    {
			       node_t arg2489_3048;
			       arg2489_3048 = stack__132_cfa_stack((((funcall_t) CREF(node_3046))->fun));
			       ((((funcall_t) CREF(node_3046))->fun) = ((node_t) arg2489_3048), BUNSPEC);
			    }
			    stack___129_cfa_stack((((funcall_t) CREF(node_3046))->args));
			    aux_3988 = (obj_t) (node_3046);
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_3051;
			    node_3051 = (pragma_t) (node_7);
			    stack___129_cfa_stack((((pragma_t) CREF(node_3051))->args));
			    aux_3988 = (obj_t) (node_3051);
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_3054;
			    node_3054 = (cast_t) (node_7);
			    stack__132_cfa_stack((((cast_t) CREF(node_3054))->arg));
			    aux_3988 = (obj_t) (node_3054);
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_t node_3057;
			    node_3057 = (setq_t) (node_7);
			    {
			       node_t arg2495_3059;
			       arg2495_3059 = stack__132_cfa_stack((((setq_t) CREF(node_3057))->value));
			       ((((setq_t) CREF(node_3057))->value) = ((node_t) arg2495_3059), BUNSPEC);
			    }
			    {
			       node_t arg2497_3061;
			       {
				  node_t aux_4034;
				  {
				     var_t aux_4035;
				     aux_4035 = (((setq_t) CREF(node_3057))->var);
				     aux_4034 = (node_t) (aux_4035);
				  }
				  arg2497_3061 = stack__132_cfa_stack(aux_4034);
			       }
			       {
				  var_t val1356_3642;
				  val1356_3642 = (var_t) (arg2497_3061);
				  ((((setq_t) CREF(node_3057))->var) = ((var_t) val1356_3642), BUNSPEC);
			       }
			    }
			    aux_3988 = (obj_t) (node_3057);
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_t node_3063;
			    node_3063 = (conditional_t) (node_7);
			    {
			       node_t arg2499_3065;
			       arg2499_3065 = stack__132_cfa_stack((((conditional_t) CREF(node_3063))->test));
			       ((((conditional_t) CREF(node_3063))->test) = ((node_t) arg2499_3065), BUNSPEC);
			    }
			    {
			       node_t arg2501_3067;
			       arg2501_3067 = stack__132_cfa_stack((((conditional_t) CREF(node_3063))->true));
			       ((((conditional_t) CREF(node_3063))->true) = ((node_t) arg2501_3067), BUNSPEC);
			    }
			    {
			       node_t arg2503_3069;
			       arg2503_3069 = stack__132_cfa_stack((((conditional_t) CREF(node_3063))->false));
			       ((((conditional_t) CREF(node_3063))->false) = ((node_t) arg2503_3069), BUNSPEC);
			    }
			    aux_3988 = (obj_t) (node_3063);
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_t node_3071;
			    node_3071 = (fail_t) (node_7);
			    {
			       node_t arg2506_3073;
			       arg2506_3073 = stack__132_cfa_stack((((fail_t) CREF(node_3071))->proc));
			       ((((fail_t) CREF(node_3071))->proc) = ((node_t) arg2506_3073), BUNSPEC);
			    }
			    {
			       node_t arg2508_3075;
			       arg2508_3075 = stack__132_cfa_stack((((fail_t) CREF(node_3071))->msg));
			       ((((fail_t) CREF(node_3071))->msg) = ((node_t) arg2508_3075), BUNSPEC);
			    }
			    {
			       node_t arg2511_3077;
			       arg2511_3077 = stack__132_cfa_stack((((fail_t) CREF(node_3071))->obj));
			       ((((fail_t) CREF(node_3071))->obj) = ((node_t) arg2511_3077), BUNSPEC);
			    }
			    aux_3988 = (obj_t) (node_3071);
			 }
			 break;
		      case ((long) 12):
			 {
			    select_t node_3079;
			    node_3079 = (select_t) (node_7);
			    {
			       node_t arg2514_3081;
			       arg2514_3081 = stack__132_cfa_stack((((select_t) CREF(node_3079))->test));
			       ((((select_t) CREF(node_3079))->test) = ((node_t) arg2514_3081), BUNSPEC);
			    }
			    {
			       obj_t l2114_3083;
			       l2114_3083 = (((select_t) CREF(node_3079))->clauses);
			     lname2115_3084:
			       if (PAIRP(l2114_3083))
				 {
				    {
				       obj_t clause_3087;
				       clause_3087 = CAR(l2114_3083);
				       {
					  node_t arg2518_3088;
					  {
					     node_t aux_4071;
					     {
						obj_t aux_4072;
						aux_4072 = CDR(clause_3087);
						aux_4071 = (node_t) (aux_4072);
					     }
					     arg2518_3088 = stack__132_cfa_stack(aux_4071);
					  }
					  {
					     obj_t aux_4076;
					     aux_4076 = (obj_t) (arg2518_3088);
					     SET_CDR(clause_3087, aux_4076);
					  }
				       }
				    }
				    {
				       obj_t l2114_4079;
				       l2114_4079 = CDR(l2114_3083);
				       l2114_3083 = l2114_4079;
				       goto lname2115_3084;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_3988 = (obj_t) (node_3079);
			 }
			 break;
		      case ((long) 13):
			 {
			    let_fun_218_t node_3091;
			    node_3091 = (let_fun_218_t) (node_7);
			    {
			       obj_t l2117_3093;
			       l2117_3093 = (((let_fun_218_t) CREF(node_3091))->locals);
			     lname2118_3094:
			       if (PAIRP(l2117_3093))
				 {
				    {
				       value_t fun_3098;
				       {
					  local_t obj_3674;
					  {
					     obj_t aux_4086;
					     aux_4086 = CAR(l2117_3093);
					     obj_3674 = (local_t) (aux_4086);
					  }
					  fun_3098 = (((local_t) CREF(obj_3674))->value);
				       }
				       {
					  node_t arg2524_3099;
					  {
					     node_t aux_4090;
					     {
						obj_t aux_4091;
						{
						   sfun_t obj_3675;
						   obj_3675 = (sfun_t) (fun_3098);
						   aux_4091 = (((sfun_t) CREF(obj_3675))->body);
						}
						aux_4090 = (node_t) (aux_4091);
					     }
					     arg2524_3099 = stack__132_cfa_stack(aux_4090);
					  }
					  {
					     sfun_t obj_3676;
					     obj_t val1185_3677;
					     obj_3676 = (sfun_t) (fun_3098);
					     val1185_3677 = (obj_t) (arg2524_3099);
					     ((((sfun_t) CREF(obj_3676))->body) = ((obj_t) val1185_3677), BUNSPEC);
					  }
				       }
				    }
				    {
				       obj_t l2117_4099;
				       l2117_4099 = CDR(l2117_3093);
				       l2117_3093 = l2117_4099;
				       goto lname2118_3094;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg2527_3102;
			       arg2527_3102 = stack__132_cfa_stack((((let_fun_218_t) CREF(node_3091))->body));
			       ((((let_fun_218_t) CREF(node_3091))->body) = ((node_t) arg2527_3102), BUNSPEC);
			    }
			    aux_3988 = (obj_t) (node_3091);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_var_6_t node_3104;
			    node_3104 = (let_var_6_t) (node_7);
			    {
			       node_t arg2529_3106;
			       arg2529_3106 = stack__132_cfa_stack((((let_var_6_t) CREF(node_3104))->body));
			       ((((let_var_6_t) CREF(node_3104))->body) = ((node_t) arg2529_3106), BUNSPEC);
			    }
			    {
			       obj_t l2120_3108;
			       l2120_3108 = (((let_var_6_t) CREF(node_3104))->bindings);
			     lname2121_3109:
			       if (PAIRP(l2120_3108))
				 {
				    {
				       obj_t binding_3112;
				       binding_3112 = CAR(l2120_3108);
				       {
					  node_t arg2533_3113;
					  {
					     node_t aux_4113;
					     {
						obj_t aux_4114;
						aux_4114 = CDR(binding_3112);
						aux_4113 = (node_t) (aux_4114);
					     }
					     arg2533_3113 = stack__132_cfa_stack(aux_4113);
					  }
					  {
					     obj_t aux_4118;
					     aux_4118 = (obj_t) (arg2533_3113);
					     SET_CDR(binding_3112, aux_4118);
					  }
				       }
				    }
				    {
				       obj_t l2120_4121;
				       l2120_4121 = CDR(l2120_3108);
				       l2120_3108 = l2120_4121;
				       goto lname2121_3109;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_3988 = (obj_t) (node_3104);
			 }
			 break;
		      case ((long) 15):
			 {
			    set_ex_it_116_t node_3116;
			    node_3116 = (set_ex_it_116_t) (node_7);
			    {
			       node_t arg2536_3118;
			       arg2536_3118 = stack__132_cfa_stack((((set_ex_it_116_t) CREF(node_3116))->body));
			       ((((set_ex_it_116_t) CREF(node_3116))->body) = ((node_t) arg2536_3118), BUNSPEC);
			    }
			    {
			       node_t arg2538_3120;
			       {
				  node_t aux_4129;
				  {
				     var_t aux_4130;
				     aux_4130 = (((set_ex_it_116_t) CREF(node_3116))->var);
				     aux_4129 = (node_t) (aux_4130);
				  }
				  arg2538_3120 = stack__132_cfa_stack(aux_4129);
			       }
			       {
				  var_t val1438_3697;
				  val1438_3697 = (var_t) (arg2538_3120);
				  ((((set_ex_it_116_t) CREF(node_3116))->var) = ((var_t) val1438_3697), BUNSPEC);
			       }
			    }
			    aux_3988 = (obj_t) (node_3116);
			 }
			 break;
		      case ((long) 16):
			 {
			    jump_ex_it_184_t node_3122;
			    node_3122 = (jump_ex_it_184_t) (node_7);
			    {
			       node_t arg2540_3124;
			       arg2540_3124 = stack__132_cfa_stack((((jump_ex_it_184_t) CREF(node_3122))->exit));
			       ((((jump_ex_it_184_t) CREF(node_3122))->exit) = ((node_t) arg2540_3124), BUNSPEC);
			    }
			    {
			       node_t arg2542_3126;
			       arg2542_3126 = stack__132_cfa_stack((((jump_ex_it_184_t) CREF(node_3122))->value));
			       ((((jump_ex_it_184_t) CREF(node_3122))->value) = ((node_t) arg2542_3126), BUNSPEC);
			    }
			    aux_3988 = (obj_t) (node_3122);
			 }
			 break;
		      case ((long) 17):
			 {
			    make_box_202_t node_3128;
			    node_3128 = (make_box_202_t) (node_7);
			    {
			       node_t arg2544_3130;
			       arg2544_3130 = stack__132_cfa_stack((((make_box_202_t) CREF(node_3128))->value));
			       ((((make_box_202_t) CREF(node_3128))->value) = ((node_t) arg2544_3130), BUNSPEC);
			    }
			    aux_3988 = (obj_t) (node_3128);
			 }
			 break;
		      case ((long) 18):
			 {
			    box_set__221_t node_3132;
			    node_3132 = (box_set__221_t) (node_7);
			    {
			       node_t arg2546_3134;
			       {
				  node_t aux_4151;
				  {
				     var_t aux_4152;
				     aux_4152 = (((box_set__221_t) CREF(node_3132))->var);
				     aux_4151 = (node_t) (aux_4152);
				  }
				  arg2546_3134 = stack__132_cfa_stack(aux_4151);
			       }
			       {
				  var_t val1482_3709;
				  val1482_3709 = (var_t) (arg2546_3134);
				  ((((box_set__221_t) CREF(node_3132))->var) = ((var_t) val1482_3709), BUNSPEC);
			       }
			    }
			    {
			       node_t arg2548_3136;
			       arg2548_3136 = stack__132_cfa_stack((((box_set__221_t) CREF(node_3132))->value));
			       ((((box_set__221_t) CREF(node_3132))->value) = ((node_t) arg2548_3136), BUNSPEC);
			    }
			    aux_3988 = (obj_t) (node_3132);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_ref_242_t node_3138;
			    node_3138 = (box_ref_242_t) (node_7);
			    {
			       node_t arg2551_3140;
			       {
				  node_t aux_4163;
				  {
				     var_t aux_4164;
				     aux_4164 = (((box_ref_242_t) CREF(node_3138))->var);
				     aux_4163 = (node_t) (aux_4164);
				  }
				  arg2551_3140 = stack__132_cfa_stack(aux_4163);
			       }
			       {
				  var_t val1473_3715;
				  val1473_3715 = (var_t) (arg2551_3140);
				  ((((box_ref_242_t) CREF(node_3138))->var) = ((var_t) val1473_3715), BUNSPEC);
			       }
			    }
			    aux_3988 = (obj_t) (node_3138);
			 }
			 break;
		      case ((long) 20):
			 {
			    app_t node_3142;
			    node_3142 = (app_t) (node_7);
			    stack___129_cfa_stack((((app_t) CREF(node_3142))->args));
			    aux_3988 = (obj_t) (node_3142);
			 }
			 break;
		      default:
		       case_else2478_3030:
			 if (PROCEDUREP(method2472_3026))
			   {
			      aux_3988 = PROCEDURE_ENTRY(method2472_3026) (method2472_3026, (obj_t) (node_7), BEOA);
			   }
			 else
			   {
			      obj_t fun2469_3020;
			      fun2469_3020 = PROCEDURE_REF(stack__env_104_cfa_stack, ((long) 0));
			      aux_3988 = PROCEDURE_ENTRY(fun2469_3020) (fun2469_3020, (obj_t) (node_7), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else2478_3030;
		 }
	    }
	    return (node_t) (aux_3988);
	 }
      }
   }
}


/* _stack!2562 */ obj_t 
_stack_2562_230_cfa_stack(obj_t env_3733, obj_t node_3734)
{
   {
      node_t aux_4187;
      aux_4187 = stack__132_cfa_stack((node_t) (node_3734));
      return (obj_t) (aux_4187);
   }
}


/* stack!-default2129 */ node_t 
stack__default2129_89_cfa_stack(node_t node_8)
{
   FAILURE(CNST_TABLE_REF(((long) 3)), string2567_cfa_stack, (obj_t) (node_8));
}


/* _stack!-default2129 */ obj_t 
_stack__default2129_204_cfa_stack(obj_t env_3735, obj_t node_3736)
{
   {
      node_t aux_4194;
      aux_4194 = stack__default2129_89_cfa_stack((node_t) (node_3736));
      return (obj_t) (aux_4194);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_stack()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_STACK");
   module_initialization_70_engine_param(((long) 0), "CFA_STACK");
   module_initialization_70_tools_speek(((long) 0), "CFA_STACK");
   module_initialization_70_tools_shape(((long) 0), "CFA_STACK");
   module_initialization_70_type_type(((long) 0), "CFA_STACK");
   module_initialization_70_ast_var(((long) 0), "CFA_STACK");
   module_initialization_70_ast_node(((long) 0), "CFA_STACK");
   module_initialization_70_cfa_info(((long) 0), "CFA_STACK");
   module_initialization_70_cfa_iterate(((long) 0), "CFA_STACK");
   module_initialization_70_cfa_loose(((long) 0), "CFA_STACK");
   module_initialization_70_inline_inline(((long) 0), "CFA_STACK");
   return module_initialization_70_inline_walk(((long) 0), "CFA_STACK");
}
