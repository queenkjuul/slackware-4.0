/*===========================================================================*/
/*   (Llib/bexit.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t _unwind_until__238___bexit(obj_t, obj_t, obj_t);
extern obj_t unwind_stack_until(obj_t, obj_t, obj_t, obj_t);
static obj_t _protected_val__170___bexit = BUNSPEC;
obj_t exitd_top = BUNSPEC;
static obj_t toplevel_init_63___bexit();
extern bool_t unwind_stack_value_p(obj_t);
static obj_t _val_from_exit__167___bexit(obj_t, obj_t);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _unwind_stack_until__173___bexit(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _unwind_stack_value__112___bexit(obj_t, obj_t);
static obj_t imported_modules_init_94___bexit();
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114___bexit = BUNSPEC;
obj_t exitd_stamp = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( unwind_until__env_204___bexit, _unwind_until__238___bexit1173, _unwind_until__238___bexit, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( val_from_exit__env_189___bexit, _val_from_exit__167___bexit1174, _val_from_exit__167___bexit, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( unwind_stack_value__env_181___bexit, _unwind_stack_value__112___bexit1175, _unwind_stack_value__112___bexit, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( unwind_stack_until__env_164___bexit, _unwind_stack_until__173___bexit1176, _unwind_stack_until__173___bexit, 0L, 4 );
DEFINE_STRING( string1171___bexit, string1171___bexit1177, "exit out of dynamic scope", 25 );
DEFINE_STRING( string1170___bexit, string1170___bexit1178, "unwind-until!", 13 );


/* module-initialization */obj_t module_initialization_70___bexit(long checksum_416, char * from_417)
{
if(CBOOL(require_initialization_114___bexit)){
require_initialization_114___bexit = BBOOL(((bool_t)0));
imported_modules_init_94___bexit();
toplevel_init_63___bexit();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* toplevel-init */obj_t toplevel_init_63___bexit()
{
exitd_top = BFALSE;
exitd_stamp = BINT(((long)0));
return (_protected_val__170___bexit = MAKE_PAIR(BUNSPEC, BUNSPEC),
BUNSPEC);
}


/* val-from-exit? */obj_t val_from_exit__100___bexit(obj_t val_1)
{
{
bool_t aux_425;
aux_425 = (val_1==_protected_val__170___bexit);
return BBOOL(aux_425);
}
}


/* _val-from-exit? */obj_t _val_from_exit__167___bexit(obj_t env_404, obj_t val_405)
{
return val_from_exit__100___bexit(val_405);
}


/* unwind-stack-value? */bool_t unwind_stack_value_p(obj_t val_2)
{
return (val_2==_protected_val__170___bexit);
}


/* _unwind-stack-value? */obj_t _unwind_stack_value__112___bexit(obj_t env_406, obj_t val_407)
{
{
bool_t aux_430;
aux_430 = unwind_stack_value_p(val_407);
return BBOOL(aux_430);
}
}


/* unwind-until! */obj_t unwind_until__178___bexit(obj_t exitd_3, obj_t val_4)
{
if(PAIRP(exitd_3)){
return unwind_stack_until(CAR(exitd_3), BFALSE, val_4, CDR(exitd_3));
}
 else {
return unwind_stack_until(exitd_3, BFALSE, val_4, BFALSE);
}
}


/* _unwind-until! */obj_t _unwind_until__238___bexit(obj_t env_408, obj_t exitd_409, obj_t val_410)
{
return unwind_until__178___bexit(exitd_409, val_410);
}


/* unwind-stack-until! */obj_t unwind_stack_until(obj_t exitd_5, obj_t estamp_6, obj_t val_7, obj_t proc_8)
{
{
loop_214:
{
bool_t test1007_215;
{
obj_t obj1_387;
obj1_387 = exitd_top;
test1007_215 = (obj1_387==BFALSE);
}
if(test1007_215){
if(PROCEDUREP(proc_8)){
return PROCEDURE_ENTRY(proc_8)(proc_8, val_7, BEOA);
}
 else {
FAILURE(string1170___bexit,string1171___bexit,BUNSPEC);}
}
 else {
obj_t exit_top_38_217;
exit_top_38_217 = exitd_top;
POP_EXIT();
{
bool_t test1009_218;
if((exit_top_38_217==exitd_5)){
bool_t _ortest_1002_222;
if(INTEGERP(estamp_6)){
_ortest_1002_222 = ((bool_t)0);
}
 else {
_ortest_1002_222 = ((bool_t)1);
}
if(_ortest_1002_222){
test1009_218 = _ortest_1002_222;
}
 else {
obj_t arg1013_223;
arg1013_223 = EXITD_STAMP(exit_top_38_217);
{
long aux_456;
long aux_454;
aux_456 = (long)CINT(estamp_6);
aux_454 = (long)CINT(arg1013_223);
test1009_218 = (aux_454==aux_456);
}
}
}
 else {
test1009_218 = ((bool_t)0);
}
if(test1009_218){
JUMP_EXIT( EXITD_TO_EXIT(exit_top_38_217),val_7);
}
 else {
bool_t test1010_219;
test1010_219 = EXITD_USERP(exit_top_38_217);
if(test1010_219){
goto loop_214;
}
 else {
{
obj_t arg1011_220;
arg1011_220 = MAKE_PAIR(exitd_5, proc_8);
SET_CAR(_protected_val__170___bexit, arg1011_220);
}
SET_CDR(_protected_val__170___bexit, val_7);
JUMP_EXIT( EXITD_TO_EXIT(exit_top_38_217),_protected_val__170___bexit);
}
}
}
}
}
}
}


/* _unwind-stack-until! */obj_t _unwind_stack_until__173___bexit(obj_t env_411, obj_t exitd_412, obj_t estamp_413, obj_t val_414, obj_t proc_415)
{
return unwind_stack_until(exitd_412, estamp_413, val_414, proc_415);
}


/* imported-modules-init */obj_t imported_modules_init_94___bexit()
{
return module_initialization_70___error(((long)0), "__BEXIT");
}

