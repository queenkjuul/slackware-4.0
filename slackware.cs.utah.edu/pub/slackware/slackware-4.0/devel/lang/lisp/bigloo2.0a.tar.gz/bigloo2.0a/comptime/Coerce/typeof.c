/*===========================================================================*/
/*   (Coerce/typeof.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_coerce_typeof();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static type_t typeof_default1448_249_coerce_typeof(node_t);
extern obj_t closure_ast_node;
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t last_pair_93___r4_pairs_and_lists_6_3(obj_t);
extern obj_t _magic__144_type_cache;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t _unspec__87_type_cache;
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_typeof(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_coerce_typeof();
extern type_t typeof_kwote_49_type_typeof(obj_t);
static obj_t _typeof1623_coerce_typeof(obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t cfun_ast_var;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_coerce_typeof();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_coerce_typeof();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t sfun_ast_var;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern type_t typeof_coerce_typeof(node_t);
static obj_t _typeof_default1448_200_coerce_typeof(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern type_t typeof_atom_134_type_typeof(obj_t);
extern obj_t _procedure__226_type_cache;
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_coerce_typeof = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_coerce_typeof();
static obj_t __cnst[1];

DEFINE_EXPORT_GENERIC(typeof_env_7_coerce_typeof, _typeof1623_coerce_typeof1634, _typeof1623_coerce_typeof, 0L, 1);
DEFINE_STATIC_PROCEDURE(typeof_default1448_env_215_coerce_typeof, _typeof_default1448_200_coerce_typeof1635, _typeof_default1448_200_coerce_typeof, 0L, 1);
DEFINE_STRING(string1627_coerce_typeof, string1627_coerce_typeof1636, "TYPEOF-DEFAULT1448 ", 19);
DEFINE_STRING(string1626_coerce_typeof, string1626_coerce_typeof1637, "No method for this object", 25);
DEFINE_STRING(string1625_coerce_typeof, string1625_coerce_typeof1638, "Je n'ai pas encore fait ce truc", 31);
DEFINE_STRING(string1624_coerce_typeof, string1624_coerce_typeof1639, "typeof", 6);


/* module-initialization */ obj_t 
module_initialization_70_coerce_typeof(long checksum_1212, char *from_1213)
{
   if (CBOOL(require_initialization_114_coerce_typeof))
     {
	require_initialization_114_coerce_typeof = BBOOL(((bool_t) 0));
	library_modules_init_112_coerce_typeof();
	cnst_init_137_coerce_typeof();
	imported_modules_init_94_coerce_typeof();
	method_init_76_coerce_typeof();
	toplevel_init_63_coerce_typeof();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_coerce_typeof()
{
   module_initialization_70___object(((long) 0), "COERCE_TYPEOF");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "COERCE_TYPEOF");
   module_initialization_70___reader(((long) 0), "COERCE_TYPEOF");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_coerce_typeof()
{
   {
      obj_t cnst_port_138_1204;
      cnst_port_138_1204 = open_input_string(string1627_coerce_typeof);
      {
	 long i_1205;
	 i_1205 = ((long) 0);
       loop_1206:
	 {
	    bool_t test1628_1207;
	    test1628_1207 = (i_1205 == ((long) -1));
	    if (test1628_1207)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1630_1208;
		    {
		       obj_t list1631_1209;
		       {
			  obj_t arg1632_1210;
			  arg1632_1210 = BNIL;
			  list1631_1209 = MAKE_PAIR(cnst_port_138_1204, arg1632_1210);
		       }
		       arg1630_1208 = read___reader(list1631_1209);
		    }
		    CNST_TABLE_SET(i_1205, arg1630_1208);
		 }
		 {
		    int aux_1211;
		    {
		       long aux_1231;
		       aux_1231 = (i_1205 - ((long) 1));
		       aux_1211 = (int) (aux_1231);
		    }
		    {
		       long i_1234;
		       i_1234 = (long) (aux_1211);
		       i_1205 = i_1234;
		       goto loop_1206;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_coerce_typeof()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_coerce_typeof()
{
   add_generic__110___object(typeof_env_7_coerce_typeof, typeof_default1448_env_215_coerce_typeof);
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, var_ast_node, ((long) 2));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, pragma_ast_node, ((long) 5));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, cast_ast_node, ((long) 6));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, setq_ast_node, ((long) 7));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, conditional_ast_node, ((long) 8));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, fail_ast_node, ((long) 9));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, select_ast_node, ((long) 10));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, let_fun_218_ast_node, ((long) 11));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, let_var_6_ast_node, ((long) 12));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, set_ex_it_116_ast_node, ((long) 13));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, jump_ex_it_184_ast_node, ((long) 14));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, make_box_202_ast_node, ((long) 15));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, box_ref_242_ast_node, ((long) 16));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, box_set__221_ast_node, ((long) 17));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, app_ly_162_ast_node, ((long) 18));
   add_inlined_method__244___object(typeof_env_7_coerce_typeof, funcall_ast_node, ((long) 19));
   {
      long aux_1257;
      aux_1257 = add_inlined_method__244___object(typeof_env_7_coerce_typeof, app_ast_node, ((long) 20));
      return BINT(aux_1257);
   }
}


/* typeof */ type_t 
typeof_coerce_typeof(node_t node_1)
{
   {
      obj_t method1562_1046;
      obj_t class1567_1047;
      {
	 obj_t arg1570_1044;
	 obj_t arg1572_1045;
	 {
	    object_t obj_1132;
	    obj_1132 = (object_t) (node_1);
	    {
	       obj_t pre_method_105_1133;
	       pre_method_105_1133 = PROCEDURE_REF(typeof_env_7_coerce_typeof, ((long) 2));
	       if (INTEGERP(pre_method_105_1133))
		 {
		    PROCEDURE_SET(typeof_env_7_coerce_typeof, ((long) 2), BUNSPEC);
		    arg1570_1044 = pre_method_105_1133;
		 }
	       else
		 {
		    long obj_class_num_177_1138;
		    obj_class_num_177_1138 = TYPE(obj_1132);
		    {
		       obj_t arg1177_1139;
		       arg1177_1139 = PROCEDURE_REF(typeof_env_7_coerce_typeof, ((long) 1));
		       {
			  long arg1178_1143;
			  {
			     long arg1179_1144;
			     arg1179_1144 = OBJECT_TYPE;
			     arg1178_1143 = (obj_class_num_177_1138 - arg1179_1144);
			  }
			  arg1570_1044 = VECTOR_REF(arg1177_1139, arg1178_1143);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1149;
	    object_1149 = (object_t) (node_1);
	    {
	       long arg1180_1150;
	       {
		  long arg1181_1151;
		  long arg1182_1152;
		  arg1181_1151 = TYPE(object_1149);
		  arg1182_1152 = OBJECT_TYPE;
		  arg1180_1150 = (arg1181_1151 - arg1182_1152);
	       }
	       {
		  obj_t vector_1156;
		  vector_1156 = _classes__134___object;
		  arg1572_1045 = VECTOR_REF(vector_1156, arg1180_1150);
	       }
	    }
	 }
	 {
	    obj_t aux_1275;
	    method1562_1046 = arg1570_1044;
	    class1567_1047 = arg1572_1045;
	    {
	       if (INTEGERP(method1562_1046))
		 {
		    switch ((long) CINT(method1562_1046))
		      {
		      case ((long) 0):
			 {
			    atom_t node_1053;
			    node_1053 = (atom_t) (node_1);
			    {
			       type_t aux_1279;
			       aux_1279 = typeof_atom_134_type_typeof((((atom_t) CREF(node_1053))->value));
			       aux_1275 = (obj_t) (aux_1279);
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t node_1056;
			    node_1056 = (kwote_t) (node_1);
			    {
			       type_t aux_1284;
			       aux_1284 = typeof_kwote_49_type_typeof((((kwote_t) CREF(node_1056))->value));
			       aux_1275 = (obj_t) (aux_1284);
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t node_1059;
			    node_1059 = (var_t) (node_1);
			    {
			       value_t value_1061;
			       {
				  variable_t arg1585_1068;
				  arg1585_1068 = (((var_t) CREF(node_1059))->variable);
				  value_1061 = (((variable_t) CREF(arg1585_1068))->value);
			       }
			       {
				  bool_t test1579_1062;
				  test1579_1062 = is_a__118___object((obj_t) (value_1061), sfun_ast_var);
				  if (test1579_1062)
				    {
				       aux_1275 = _procedure__226_type_cache;
				    }
				  else
				    {
				       bool_t test1580_1063;
				       test1580_1063 = is_a__118___object((obj_t) (value_1061), cfun_ast_var);
				       if (test1580_1063)
					 {
					    {
					       obj_t arg1583_1066;
					       arg1583_1066 = shape_tools_shape((obj_t) (node_1059));
					       FAILURE(string1624_coerce_typeof, string1625_coerce_typeof, arg1583_1066);
					    }
					 }
				       else
					 {
					    {
					       variable_t arg1584_1067;
					       arg1584_1067 = (((var_t) CREF(node_1059))->variable);
					       {
						  type_t aux_1301;
						  aux_1301 = (((variable_t) CREF(arg1584_1067))->type);
						  aux_1275 = (obj_t) (aux_1301);
					       }
					    }
					 }
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 3):
			 aux_1275 = _procedure__226_type_cache;
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1070;
			    node_1070 = (sequence_t) (node_1);
			    {
			       type_t aux_1305;
			       {
				  node_t aux_1306;
				  {
				     obj_t aux_1307;
				     {
					obj_t aux_1308;
					aux_1308 = last_pair_93___r4_pairs_and_lists_6_3((((sequence_t) CREF(node_1070))->nodes));
					aux_1307 = CAR(aux_1308);
				     }
				     aux_1306 = (node_t) (aux_1307);
				  }
				  aux_1305 = typeof_coerce_typeof(aux_1306);
			       }
			       aux_1275 = (obj_t) (aux_1305);
			    }
			 }
			 break;
		      case ((long) 5):
			 {
			    pragma_t node_1075;
			    node_1075 = (pragma_t) (node_1);
			    {
			       type_t aux_1316;
			       aux_1316 = (((pragma_t) CREF(node_1075))->type);
			       aux_1275 = (obj_t) (aux_1316);
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    cast_t node_1077;
			    node_1077 = (cast_t) (node_1);
			    {
			       type_t aux_1320;
			       aux_1320 = (((cast_t) CREF(node_1077))->type);
			       aux_1275 = (obj_t) (aux_1320);
			    }
			 }
			 break;
		      case ((long) 7):
			 aux_1275 = _unspec__87_type_cache;
			 break;
		      case ((long) 8):
			 {
			    conditional_t node_1080;
			    node_1080 = (conditional_t) (node_1);
			    {
			       type_t ttrue_1082;
			       type_t tfalse_1083;
			       ttrue_1082 = typeof_coerce_typeof((((conditional_t) CREF(node_1080))->true));
			       tfalse_1083 = typeof_coerce_typeof((((conditional_t) CREF(node_1080))->false));
			       {
				  bool_t test_1328;
				  {
				     obj_t aux_1331;
				     obj_t aux_1329;
				     aux_1331 = (obj_t) (tfalse_1083);
				     aux_1329 = (obj_t) (ttrue_1082);
				     test_1328 = (aux_1329 == aux_1331);
				  }
				  if (test_1328)
				    {
				       aux_1275 = (obj_t) (ttrue_1082);
				    }
				  else
				    {
				       aux_1275 = _obj__252_type_cache;
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 9):
			 aux_1275 = _magic__144_type_cache;
			 break;
		      case ((long) 10):
			 {
			    select_t node_1089;
			    node_1089 = (select_t) (node_1);
			    {
			       obj_t clauses_1091;
			       type_t type_1092;
			       {
				  obj_t arg1594_1094;
				  type_t arg1595_1095;
				  {
				     obj_t aux_1336;
				     aux_1336 = (((select_t) CREF(node_1089))->clauses);
				     arg1594_1094 = CDR(aux_1336);
				  }
				  {
				     node_t aux_1339;
				     {
					obj_t aux_1340;
					{
					   obj_t aux_1341;
					   {
					      obj_t aux_1342;
					      aux_1342 = (((select_t) CREF(node_1089))->clauses);
					      aux_1341 = CAR(aux_1342);
					   }
					   aux_1340 = CDR(aux_1341);
					}
					aux_1339 = (node_t) (aux_1340);
				     }
				     arg1595_1095 = typeof_coerce_typeof(aux_1339);
				  }
				  clauses_1091 = arg1594_1094;
				  type_1092 = arg1595_1095;
				loop_1093:
				  if (NULLP(clauses_1091))
				    {
				       aux_1275 = (obj_t) (type_1092);
				    }
				  else
				    {
				       bool_t test1605_1101;
				       {
					  type_t arg1607_1103;
					  {
					     node_t aux_1351;
					     {
						obj_t aux_1352;
						{
						   obj_t aux_1353;
						   aux_1353 = CAR(clauses_1091);
						   aux_1352 = CDR(aux_1353);
						}
						aux_1351 = (node_t) (aux_1352);
					     }
					     arg1607_1103 = typeof_coerce_typeof(aux_1351);
					  }
					  {
					     obj_t aux_1360;
					     obj_t aux_1358;
					     aux_1360 = (obj_t) (type_1092);
					     aux_1358 = (obj_t) (arg1607_1103);
					     test1605_1101 = (aux_1358 == aux_1360);
					  }
				       }
				       if (test1605_1101)
					 {
					    obj_t clauses_1364;
					    clauses_1364 = CDR(clauses_1091);
					    clauses_1091 = clauses_1364;
					    goto loop_1093;
					 }
				       else
					 {
					    aux_1275 = _obj__252_type_cache;
					 }
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    let_fun_218_t node_1106;
			    node_1106 = (let_fun_218_t) (node_1);
			    {
			       type_t aux_1367;
			       aux_1367 = typeof_coerce_typeof((((let_fun_218_t) CREF(node_1106))->body));
			       aux_1275 = (obj_t) (aux_1367);
			    }
			 }
			 break;
		      case ((long) 12):
			 {
			    let_var_6_t node_1109;
			    node_1109 = (let_var_6_t) (node_1);
			    {
			       type_t aux_1372;
			       aux_1372 = typeof_coerce_typeof((((let_var_6_t) CREF(node_1109))->body));
			       aux_1275 = (obj_t) (aux_1372);
			    }
			 }
			 break;
		      case ((long) 13):
			 aux_1275 = _obj__252_type_cache;
			 break;
		      case ((long) 14):
			 aux_1275 = _obj__252_type_cache;
			 break;
		      case ((long) 15):
			 aux_1275 = _obj__252_type_cache;
			 break;
		      case ((long) 16):
			 aux_1275 = _obj__252_type_cache;
			 break;
		      case ((long) 17):
			 aux_1275 = _unspec__87_type_cache;
			 break;
		      case ((long) 18):
			 aux_1275 = _obj__252_type_cache;
			 break;
		      case ((long) 19):
			 aux_1275 = _obj__252_type_cache;
			 break;
		      case ((long) 20):
			 {
			    app_t node_1119;
			    node_1119 = (app_t) (node_1);
			    {
			       variable_t arg1613_1121;
			       {
				  var_t arg1615_1122;
				  arg1615_1122 = (((app_t) CREF(node_1119))->fun);
				  arg1613_1121 = (((var_t) CREF(arg1615_1122))->variable);
			       }
			       {
				  type_t aux_1379;
				  aux_1379 = (((variable_t) CREF(arg1613_1121))->type);
				  aux_1275 = (obj_t) (aux_1379);
			       }
			    }
			 }
			 break;
		      default:
		       case_else1568_1050:
			 if (PROCEDUREP(method1562_1046))
			   {
			      aux_1275 = PROCEDURE_ENTRY(method1562_1046) (method1562_1046, (obj_t) (node_1), BEOA);
			   }
			 else
			   {
			      obj_t fun1559_1040;
			      fun1559_1040 = PROCEDURE_REF(typeof_env_7_coerce_typeof, ((long) 0));
			      aux_1275 = PROCEDURE_ENTRY(fun1559_1040) (fun1559_1040, (obj_t) (node_1), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1568_1050;
		 }
	    }
	    return (type_t) (aux_1275);
	 }
      }
   }
}


/* _typeof1623 */ obj_t 
_typeof1623_coerce_typeof(obj_t env_1200, obj_t node_1201)
{
   {
      type_t aux_1394;
      aux_1394 = typeof_coerce_typeof((node_t) (node_1201));
      return (obj_t) (aux_1394);
   }
}


/* typeof-default1448 */ type_t 
typeof_default1448_249_coerce_typeof(node_t node_2)
{
   FAILURE(CNST_TABLE_REF(((long) 0)), string1626_coerce_typeof, (obj_t) (node_2));
}


/* _typeof-default1448 */ obj_t 
_typeof_default1448_200_coerce_typeof(obj_t env_1202, obj_t node_1203)
{
   {
      type_t aux_1401;
      aux_1401 = typeof_default1448_249_coerce_typeof((node_t) (node_1203));
      return (obj_t) (aux_1401);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_coerce_typeof()
{
   module_initialization_70_type_type(((long) 0), "COERCE_TYPEOF");
   module_initialization_70_type_cache(((long) 0), "COERCE_TYPEOF");
   module_initialization_70_type_typeof(((long) 0), "COERCE_TYPEOF");
   module_initialization_70_tools_shape(((long) 0), "COERCE_TYPEOF");
   module_initialization_70_ast_var(((long) 0), "COERCE_TYPEOF");
   return module_initialization_70_ast_node(((long) 0), "COERCE_TYPEOF");
}
