/*===========================================================================*/
/*   (Inline/inline.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct isfun
  {
     struct node *original_body_40;
     obj_t recursive_calls_44;
  }
     *isfun_t;


static obj_t _isfun_side_effect_1771_246_inline_inline(obj_t, obj_t);
extern sfun_t allocate_isfun_51_inline_inline();
static obj_t method_init_76_inline_inline();
extern obj_t make_box_202_ast_node;
static obj_t _isfun_stack_allocator1775_212_inline_inline(obj_t, obj_t);
extern obj_t funcall_ast_node;
extern obj_t inline_sfun__229_inline_inline(variable_t, long, obj_t);
extern isfun_t make_isfun_38_inline_inline(long, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, node_t, obj_t);
extern obj_t _optim__89_engine_param;
extern obj_t isfun_loc_set__164_inline_inline(sfun_t, obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t isfun_args_set__220_inline_inline(sfun_t, obj_t);
extern obj_t fail_ast_node;
static obj_t _isfun_loc1791_189_inline_inline(obj_t, obj_t);
extern obj_t box_ref_242_ast_node;
extern obj_t isfun_property_57_inline_inline(sfun_t);
static obj_t _object__struct1799_153___object(obj_t, obj_t);
extern obj_t isfun_loc_80_inline_inline(sfun_t);
extern isfun_t widening1002_isfun_194_inline_inline(node_t, obj_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static obj_t _isfun_args_set_1782_125_inline_inline(obj_t, obj_t, obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _sfun__63_inline_inline(obj_t, obj_t);
extern obj_t global_ast_var;
static obj_t _isfun_loc_set_1790_160_inline_inline(obj_t, obj_t, obj_t);
extern obj_t pragma_ast_node;
static obj_t _isfun_the_closure_set_1778_182_inline_inline(obj_t, obj_t, obj_t);
static obj_t inline_node___77_inline_inline(obj_t, long, obj_t);
extern obj_t set_ex_it_116_ast_node;
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern obj_t isfun_top__set__21_inline_inline(sfun_t, bool_t);
static obj_t _inline_node1800_250_inline_inline(obj_t, obj_t, obj_t, obj_t);
static obj_t _isfun_top__set_1776_74_inline_inline(obj_t, obj_t, obj_t);
static obj_t _isfun_original_body1792_13_inline_inline(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _isfun_top_1777_40_inline_inline(obj_t, obj_t);
extern obj_t isfun_class_set__81_inline_inline(sfun_t, obj_t);
static obj_t _isfun_predicate_of1773_67_inline_inline(obj_t, obj_t);
extern obj_t module_initialization_70_inline_inline(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_inline_walk(long, char *);
extern obj_t module_initialization_70_inline_app(long, char *);
extern obj_t module_initialization_70_ast_alphatize(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t _isfun_arity1769_193_inline_inline(obj_t, obj_t);
extern node_t inline_app_72_inline_app(app_t, long, obj_t);
static obj_t _isfun_dsssl_keywords1789_10_inline_inline(obj_t, obj_t);
static obj_t _isfun_side_effect__set_1770_92_inline_inline(obj_t, obj_t, obj_t);
extern bool_t isfun__40_inline_inline(obj_t);
extern obj_t isfun_predicate_of_231_inline_inline(sfun_t);
extern long list_length(obj_t);
static obj_t _isfun_args1783_180_inline_inline(obj_t, obj_t);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t _isfun_property_set_1780_18_inline_inline(obj_t, obj_t, obj_t);
static obj_t _isfun_the_closure1779_68_inline_inline(obj_t, obj_t);
static obj_t imported_modules_init_94_inline_inline();
extern obj_t isfun_the_closure_set__113_inline_inline(sfun_t, obj_t);
static obj_t _isfun__19_inline_inline(obj_t, obj_t);
extern obj_t isfun_side_effect__245_inline_inline(sfun_t);
static obj_t _inline_sfun_1766_255_inline_inline(obj_t, obj_t, obj_t, obj_t);
static obj_t _isfun_stack_allocator_set_1774_62_inline_inline(obj_t, obj_t, obj_t);
static obj_t _struct_object__object1797_83___object(obj_t, obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
static obj_t _widening1002_isfun1767_163_inline_inline(obj_t, obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t isfun_property_set__21_inline_inline(sfun_t, obj_t);
extern obj_t isfun_recursive_calls_set__23_inline_inline(isfun_t, obj_t);
static obj_t _inline_node_default1476_23_inline_inline(obj_t, obj_t, obj_t, obj_t);
extern obj_t isfun_body_set__168_inline_inline(sfun_t, obj_t);
static obj_t _isfun_body1785_105_inline_inline(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t isfun_side_effect__set__5_inline_inline(sfun_t, obj_t);
static obj_t library_modules_init_112_inline_inline();
extern node_t inline_node_218_inline_inline(node_t, long, obj_t);
static obj_t _isfun_class_set_1786_172_inline_inline(obj_t, obj_t, obj_t);
extern obj_t isfun_dsssl_keywords_set__79_inline_inline(sfun_t, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
extern long isfun_arity_98_inline_inline(sfun_t);
extern obj_t atom_ast_node;
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_inline_inline();
static obj_t _make_isfun1768_168_inline_inline(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t isfun_class_67_inline_inline(sfun_t);
extern node_t isfun_original_body_3_inline_inline(isfun_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t isfun_stack_allocator_set__37_inline_inline(sfun_t, obj_t);
static obj_t struct_object__object_isfun_164_inline_inline(obj_t, obj_t, obj_t);
extern bool_t isfun_top__57_inline_inline(sfun_t);
extern obj_t isfun_dsssl_keywords_90_inline_inline(sfun_t);
extern node_t alphatize_ast_alphatize(obj_t, obj_t, obj_t, node_t);
extern obj_t sfun_ast_var;
extern obj_t isfun_the_closure_61_inline_inline(sfun_t);
extern obj_t _non_inlined_calls__201_inline_walk;
static obj_t object__struct_isfun_152_inline_inline(obj_t, obj_t);
extern obj_t setq_ast_node;
static obj_t _isfun_class1787_21_inline_inline(obj_t, obj_t);
extern obj_t box_set__221_ast_node;
static obj_t _isfun_recursive_calls1794_191_inline_inline(obj_t, obj_t);
extern obj_t isfun_stack_allocator_184_inline_inline(sfun_t);
static obj_t _isfun_recursive_calls_set_1793_3_inline_inline(obj_t, obj_t, obj_t);
obj_t isfun_inline_inline = BUNSPEC;
static bool_t sfun__199_inline_inline(obj_t);
static obj_t _isfun_dsssl_keywords_set_1788_177_inline_inline(obj_t, obj_t, obj_t);
static obj_t _isfun_property1781_242_inline_inline(obj_t, obj_t);
static obj_t object_init_111_inline_inline();
static obj_t _isfun_body_set_1784_164_inline_inline(obj_t, obj_t, obj_t);
static obj_t _isfun_predicate_of_set_1772_31_inline_inline(obj_t, obj_t, obj_t);
extern bool_t inline_app__99_inline_app(variable_t, long, long, obj_t);
static obj_t _allocate_isfun_106_inline_inline(obj_t);
extern obj_t isfun_body_87_inline_inline(sfun_t);
extern obj_t _kfactor__149_inline_walk;
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern obj_t object__struct_50___object(object_t);
extern obj_t isfun_predicate_of_set__54_inline_inline(sfun_t, obj_t);
static obj_t require_initialization_114_inline_inline = BUNSPEC;
extern obj_t conditional_ast_node;
extern obj_t isfun_args_255_inline_inline(sfun_t);
extern obj_t isfun_recursive_calls_17_inline_inline(isfun_t);
static node_t inline_node_default1476_251_inline_inline(node_t, long, obj_t);
static obj_t cnst_init_137_inline_inline();
static obj_t __cnst[5];

DEFINE_EXPORT_PROCEDURE(isfun_loc_set__env_208_inline_inline, _isfun_loc_set_1790_160_inline_inline1810, _isfun_loc_set_1790_160_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_original_body_env_221_inline_inline, _isfun_original_body1792_13_inline_inline1811, _isfun_original_body1792_13_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_body_env_234_inline_inline, _isfun_body1785_105_inline_inline1812, _isfun_body1785_105_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_side_effect__set__env_185_inline_inline, _isfun_side_effect__set_1770_92_inline_inline1813, _isfun_side_effect__set_1770_92_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_predicate_of_env_198_inline_inline, _isfun_predicate_of1773_67_inline_inline1814, _isfun_predicate_of1773_67_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_isfun_env_162_inline_inline, _make_isfun1768_168_inline_inline1815, _make_isfun1768_168_inline_inline, 0L, 14);
DEFINE_EXPORT_PROCEDURE(isfun_class_set__env_226_inline_inline, _isfun_class_set_1786_172_inline_inline1816, _isfun_class_set_1786_172_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_the_closure_env_205_inline_inline, _isfun_the_closure1779_68_inline_inline1817, _isfun_the_closure1779_68_inline_inline, 0L, 1);
DEFINE_STATIC_PROCEDURE(inline_node_default1476_env_173_inline_inline, _inline_node_default1476_23_inline_inline1818, _inline_node_default1476_23_inline_inline, 0L, 3);
DEFINE_EXPORT_PROCEDURE(isfun_property_set__env_123_inline_inline, _isfun_property_set_1780_18_inline_inline1819, _isfun_property_set_1780_18_inline_inline, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1802_inline_inline, struct_object__object_isfun_164_inline_inline1820, struct_object__object_isfun_164_inline_inline, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1801_inline_inline, object__struct_isfun_152_inline_inline1821, object__struct_isfun_152_inline_inline, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(widening1002_isfun_env_246_inline_inline, _widening1002_isfun1767_163_inline_inline1822, _widening1002_isfun1767_163_inline_inline, 0L, 2);
DEFINE_EXPORT_GENERIC(inline_node_env_12_inline_inline, _inline_node1800_250_inline_inline1823, _inline_node1800_250_inline_inline, 0L, 3);
DEFINE_EXPORT_PROCEDURE(isfun_body_set__env_132_inline_inline, _isfun_body_set_1784_164_inline_inline1824, _isfun_body_set_1784_164_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_arity_env_65_inline_inline, _isfun_arity1769_193_inline_inline1825, _isfun_arity1769_193_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_dsssl_keywords_set__env_141_inline_inline, _isfun_dsssl_keywords_set_1788_177_inline_inline1826, _isfun_dsssl_keywords_set_1788_177_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_recursive_calls_env_195_inline_inline, _isfun_recursive_calls1794_191_inline_inline1827, _isfun_recursive_calls1794_191_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_predicate_of_set__env_19_inline_inline, _isfun_predicate_of_set_1772_31_inline_inline1828, _isfun_predicate_of_set_1772_31_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_stack_allocator_set__env_121_inline_inline, _isfun_stack_allocator_set_1774_62_inline_inline1829, _isfun_stack_allocator_set_1774_62_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_property_env_240_inline_inline, _isfun_property1781_242_inline_inline1830, _isfun_property1781_242_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_args_set__env_155_inline_inline, _isfun_args_set_1782_125_inline_inline1831, _isfun_args_set_1782_125_inline_inline, 0L, 2);
DEFINE_STATIC_PROCEDURE(sfun__env_206_inline_inline, _sfun__63_inline_inline1832, _sfun__63_inline_inline, 0L, 1);
DEFINE_STRING(string1804_inline_inline, string1804_inline_inline1833, "INLINE-NODE-DEFAULT1476 READ STATIC ISFUN DONE ", 47);
DEFINE_STRING(string1803_inline_inline, string1803_inline_inline1834, "No method for this object", 25);
DEFINE_EXPORT_PROCEDURE(isfun_top__env_240_inline_inline, _isfun_top_1777_40_inline_inline1835, _isfun_top_1777_40_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_class_env_109_inline_inline, _isfun_class1787_21_inline_inline1836, _isfun_class1787_21_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_the_closure_set__env_39_inline_inline, _isfun_the_closure_set_1778_182_inline_inline1837, _isfun_the_closure_set_1778_182_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_top__set__env_123_inline_inline, _isfun_top__set_1776_74_inline_inline1838, _isfun_top__set_1776_74_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_recursive_calls_set__env_241_inline_inline, _isfun_recursive_calls_set_1793_3_inline_inline1839, _isfun_recursive_calls_set_1793_3_inline_inline, 0L, 2);
DEFINE_EXPORT_PROCEDURE(isfun_side_effect__env_113_inline_inline, _isfun_side_effect_1771_246_inline_inline1840, _isfun_side_effect_1771_246_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_dsssl_keywords_env_237_inline_inline, _isfun_dsssl_keywords1789_10_inline_inline1841, _isfun_dsssl_keywords1789_10_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_stack_allocator_env_161_inline_inline, _isfun_stack_allocator1775_212_inline_inline1842, _isfun_stack_allocator1775_212_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_isfun_env_181_inline_inline, _allocate_isfun_106_inline_inline1843, _allocate_isfun_106_inline_inline, 0L, 0);
DEFINE_EXPORT_PROCEDURE(isfun__env_170_inline_inline, _isfun__19_inline_inline1844, _isfun__19_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_loc_env_134_inline_inline, _isfun_loc1791_189_inline_inline1845, _isfun_loc1791_189_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(isfun_args_env_194_inline_inline, _isfun_args1783_180_inline_inline1846, _isfun_args1783_180_inline_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(inline_sfun__env_218_inline_inline, _inline_sfun_1766_255_inline_inline1847, _inline_sfun_1766_255_inline_inline, 0L, 3);
extern obj_t object__struct_env_210___object;


/* module-initialization */ obj_t 
module_initialization_70_inline_inline(long checksum_1757, char *from_1758)
{
   if (CBOOL(require_initialization_114_inline_inline))
     {
	require_initialization_114_inline_inline = BBOOL(((bool_t) 0));
	library_modules_init_112_inline_inline();
	cnst_init_137_inline_inline();
	imported_modules_init_94_inline_inline();
	object_init_111_inline_inline();
	method_init_76_inline_inline();
	toplevel_init_63_inline_inline();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_inline_inline()
{
   module_initialization_70___object(((long) 0), "INLINE_INLINE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INLINE_INLINE");
   module_initialization_70___reader(((long) 0), "INLINE_INLINE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_inline_inline()
{
   {
      obj_t cnst_port_138_1749;
      cnst_port_138_1749 = open_input_string(string1804_inline_inline);
      {
	 long i_1750;
	 i_1750 = ((long) 4);
       loop_1751:
	 {
	    bool_t test1805_1752;
	    test1805_1752 = (i_1750 == ((long) -1));
	    if (test1805_1752)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1806_1753;
		    {
		       obj_t list1807_1754;
		       {
			  obj_t arg1808_1755;
			  arg1808_1755 = BNIL;
			  list1807_1754 = MAKE_PAIR(cnst_port_138_1749, arg1808_1755);
		       }
		       arg1806_1753 = read___reader(list1807_1754);
		    }
		    CNST_TABLE_SET(i_1750, arg1806_1753);
		 }
		 {
		    int aux_1756;
		    {
		       long aux_1777;
		       aux_1777 = (i_1750 - ((long) 1));
		       aux_1756 = (int) (aux_1777);
		    }
		    {
		       long i_1780;
		       i_1780 = (long) (aux_1756);
		       i_1750 = i_1780;
		       goto loop_1751;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_inline_inline()
{
   return BUNSPEC;
}


/* inline-sfun! */ obj_t 
inline_sfun__229_inline_inline(variable_t variable_1, long kfactor_2, obj_t stack_3)
{
   {
      value_t sfun_822;
      sfun_822 = (((variable_t) CREF(variable_1))->value);
      {
	 obj_t isfun_823;
	 {
	    bool_t test1515_836;
	    test1515_836 = is_a__118___object(sfun__env_206_inline_inline, isfun_inline_inline);
	    if (test1515_836)
	      {
		 isfun_823 = (obj_t) (sfun_822);
	      }
	    else
	      {
		 isfun_t obj1462_837;
		 obj1462_837 = ((isfun_t) (sfun_822));
		 {
		    isfun_t arg1516_838;
		    {
		       isfun_t res1761_1388;
		       {
			  node_t original_body_40_1383;
			  {
			     obj_t aux_1787;
			     {
				sfun_t obj_1382;
				obj_1382 = (sfun_t) (sfun_822);
				aux_1787 = (((sfun_t) CREF(obj_1382))->body);
			     }
			     original_body_40_1383 = (node_t) (aux_1787);
			  }
			  {
			     isfun_t new1436_1385;
			     new1436_1385 = ((isfun_t) BREF(GC_MALLOC(sizeof(struct isfun))));
			     ((((isfun_t) CREF(new1436_1385))->original_body_40) = ((node_t) original_body_40_1383), BUNSPEC);
			     ((((isfun_t) CREF(new1436_1385))->recursive_calls_44) = ((obj_t) BUNSPEC), BUNSPEC);
			     res1761_1388 = new1436_1385;
			  }
		       }
		       arg1516_838 = res1761_1388;
		    }
		    {
		       obj_t aux_1796;
		       object_t aux_1794;
		       aux_1796 = (obj_t) (arg1516_838);
		       aux_1794 = (object_t) (obj1462_837);
		       OBJECT_WIDENING_SET(aux_1794, aux_1796);
		    }
		 }
		 {
		    long arg1518_840;
		    arg1518_840 = class_num_218___object(isfun_inline_inline);
		    {
		       obj_t obj_1389;
		       obj_1389 = (obj_t) (obj1462_837);
		       (((obj_t) CREF(obj_1389))->header = MAKE_HEADER(arg1518_840, 0), BUNSPEC);
		    }
		 }
		 isfun_823 = (obj_t) (obj1462_837);
	      }
	 }
	 {
	    node_t o_body_107_824;
	    {
	       isfun_t obj_1391;
	       obj_1391 = (isfun_t) (isfun_823);
	       {
		  obj_t aux_1804;
		  {
		     object_t aux_1805;
		     aux_1805 = (object_t) (obj_1391);
		     aux_1804 = OBJECT_WIDENING(aux_1805);
		  }
		  o_body_107_824 = (((isfun_t) CREF(aux_1804))->original_body_40);
	       }
	    }
	    {
	       node_t inl_body_109_825;
	       {
		  bool_t test1503_828;
		  {
		     long arg1507_831;
		     {
			long aux_1809;
			{
			   obj_t aux_1810;
			   {
			      sfun_t obj_1392;
			      obj_1392 = (sfun_t) (sfun_822);
			      aux_1810 = (((sfun_t) CREF(obj_1392))->args);
			   }
			   aux_1809 = list_length(aux_1810);
			}
			arg1507_831 = (((long) 1) + aux_1809);
		     }
		     test1503_828 = inline_app__99_inline_app(variable_1, (long) CINT(_kfactor__149_inline_walk), arg1507_831, BNIL);
		  }
		  if (test1503_828)
		    {
		       inl_body_109_825 = alphatize_ast_alphatize(BNIL, BNIL, BFALSE, o_body_107_824);
		    }
		  else
		    {
		       inl_body_109_825 = o_body_107_824;
		    }
	       }
	       {
		  {
		     node_t arg1501_826;
		     {
			obj_t arg1502_827;
			{
			   obj_t aux_1819;
			   aux_1819 = (obj_t) (variable_1);
			   arg1502_827 = MAKE_PAIR(aux_1819, stack_3);
			}
			arg1501_826 = inline_node_218_inline_inline(inl_body_109_825, kfactor_2, arg1502_827);
		     }
		     {
			sfun_t obj_1397;
			obj_t val1136_1398;
			obj_1397 = (sfun_t) (sfun_822);
			val1136_1398 = (obj_t) (arg1501_826);
			((((sfun_t) CREF(obj_1397))->body) = ((obj_t) val1136_1398), BUNSPEC);
		     }
		  }
		  return BUNSPEC;
	       }
	    }
	 }
      }
   }
}


/* _inline-sfun!1766 */ obj_t 
_inline_sfun_1766_255_inline_inline(obj_t env_1638, obj_t variable_1639, obj_t kfactor_1640, obj_t stack_1641)
{
   return inline_sfun__229_inline_inline((variable_t) (variable_1639), (long) CINT(kfactor_1640), stack_1641);
}


/* inline-node*! */ obj_t 
inline_node___77_inline_inline(obj_t node__221_70, long kfactor_71, obj_t stack_72)
{
 inline_node___77_inline_inline:
   if (NULLP(node__221_70))
     {
	return CNST_TABLE_REF(((long) 0));
     }
   else
     {
	{
	   node_t arg1522_842;
	   {
	      node_t aux_1832;
	      {
		 obj_t aux_1833;
		 aux_1833 = CAR(node__221_70);
		 aux_1832 = (node_t) (aux_1833);
	      }
	      arg1522_842 = inline_node_218_inline_inline(aux_1832, kfactor_71, stack_72);
	   }
	   {
	      obj_t aux_1837;
	      aux_1837 = (obj_t) (arg1522_842);
	      SET_CAR(node__221_70, aux_1837);
	   }
	}
	{
	   obj_t node__221_1840;
	   node__221_1840 = CDR(node__221_70);
	   node__221_70 = node__221_1840;
	   goto inline_node___77_inline_inline;
	}
     }
}


/* object-init */ obj_t 
object_init_111_inline_inline()
{
   {
      obj_t arg1527_846;
      arg1527_846 = sfun_ast_var;
      isfun_inline_inline = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1527_846, allocate_isfun_env_181_inline_inline, ((long) 49291), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-isfun */ sfun_t 
allocate_isfun_51_inline_inline()
{
   {
      sfun_t new1454_849;
      new1454_849 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
      {
	 long arg1530_850;
	 arg1530_850 = class_num_218___object(isfun_inline_inline);
	 {
	    obj_t obj_1404;
	    obj_1404 = (obj_t) (new1454_849);
	    (((obj_t) CREF(obj_1404))->header = MAKE_HEADER(arg1530_850, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_1848;
	 aux_1848 = (object_t) (new1454_849);
	 OBJECT_WIDENING_SET(aux_1848, BFALSE);
      }
      return new1454_849;
   }
}


/* _allocate-isfun */ obj_t 
_allocate_isfun_106_inline_inline(obj_t env_1644)
{
   {
      sfun_t aux_1851;
      aux_1851 = allocate_isfun_51_inline_inline();
      return (obj_t) (aux_1851);
   }
}


/* isfun? */ bool_t 
isfun__40_inline_inline(obj_t obj_76)
{
   return is_a__118___object(obj_76, isfun_inline_inline);
}


/* _isfun? */ obj_t 
_isfun__19_inline_inline(obj_t env_1645, obj_t obj_1646)
{
   {
      bool_t aux_1855;
      aux_1855 = isfun__40_inline_inline(obj_1646);
      return BBOOL(aux_1855);
   }
}


/* widening1002-isfun */ isfun_t 
widening1002_isfun_194_inline_inline(node_t original_body_40_77, obj_t recursive_calls_44_78)
{
   {
      isfun_t new1436_1406;
      new1436_1406 = ((isfun_t) BREF(GC_MALLOC(sizeof(struct isfun))));
      ((((isfun_t) CREF(new1436_1406))->original_body_40) = ((node_t) original_body_40_77), BUNSPEC);
      ((((isfun_t) CREF(new1436_1406))->recursive_calls_44) = ((obj_t) recursive_calls_44_78), BUNSPEC);
      return new1436_1406;
   }
}


/* _widening1002-isfun1767 */ obj_t 
_widening1002_isfun1767_163_inline_inline(obj_t env_1647, obj_t original_body_40_1648, obj_t recursive_calls_44_1649)
{
   {
      isfun_t aux_1861;
      aux_1861 = widening1002_isfun_194_inline_inline((node_t) (original_body_40_1648), recursive_calls_44_1649);
      return (obj_t) (aux_1861);
   }
}


/* make-isfun */ isfun_t 
make_isfun_38_inline_inline(long arity_79, obj_t side_effect__165_80, obj_t predicate_of_78_81, obj_t stack_allocator_172_82, bool_t top__138_83, obj_t the_closure_238_84, obj_t property_85, obj_t args_86, obj_t body_87, obj_t class_88, obj_t dsssl_keywords_243_89, obj_t loc_90, node_t original_body_40_91, obj_t recursive_calls_44_92)
{
   {
      sfun_t aux1440_1409;
      {
	 sfun_t res1762_1441;
	 {
	    sfun_t new1115_1425;
	    new1115_1425 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
	    {
	       long arg1610_1426;
	       arg1610_1426 = class_num_218___object(sfun_ast_var);
	       {
		  obj_t obj_1439;
		  obj_1439 = (obj_t) (new1115_1425);
		  (((obj_t) CREF(obj_1439))->header = MAKE_HEADER(arg1610_1426, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_1869;
	       aux_1869 = (object_t) (new1115_1425);
	       OBJECT_WIDENING_SET(aux_1869, BFALSE);
	    }
	    ((((sfun_t) CREF(new1115_1425))->arity) = ((long) arity_79), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->side_effect__165) = ((obj_t) side_effect__165_80), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->predicate_of_78) = ((obj_t) predicate_of_78_81), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->stack_allocator_172) = ((obj_t) stack_allocator_172_82), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->top__138) = ((bool_t) top__138_83), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->the_closure_238) = ((obj_t) the_closure_238_84), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->property) = ((obj_t) property_85), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->args) = ((obj_t) args_86), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->body) = ((obj_t) body_87), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->class) = ((obj_t) class_88), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->dsssl_keywords_243) = ((obj_t) dsssl_keywords_243_89), BUNSPEC);
	    ((((sfun_t) CREF(new1115_1425))->loc) = ((obj_t) loc_90), BUNSPEC);
	    res1762_1441 = new1115_1425;
	 }
	 aux1440_1409 = res1762_1441;
      }
      {
	 isfun_t new1441_1410;
	 new1441_1410 = ((isfun_t) (aux1440_1409));
	 {
	    long arg1531_1411;
	    arg1531_1411 = class_num_218___object(isfun_inline_inline);
	    {
	       obj_t obj_1442;
	       obj_1442 = (obj_t) (new1441_1410);
	       (((obj_t) CREF(obj_1442))->header = MAKE_HEADER(arg1531_1411, 0), BUNSPEC);
	    }
	 }
	 {
	    isfun_t arg1532_1412;
	    {
	       isfun_t res1763_1449;
	       {
		  isfun_t new1436_1446;
		  new1436_1446 = ((isfun_t) BREF(GC_MALLOC(sizeof(struct isfun))));
		  ((((isfun_t) CREF(new1436_1446))->original_body_40) = ((node_t) original_body_40_91), BUNSPEC);
		  ((((isfun_t) CREF(new1436_1446))->recursive_calls_44) = ((obj_t) recursive_calls_44_92), BUNSPEC);
		  res1763_1449 = new1436_1446;
	       }
	       arg1532_1412 = res1763_1449;
	    }
	    {
	       obj_t aux_1893;
	       object_t aux_1891;
	       aux_1893 = (obj_t) (arg1532_1412);
	       aux_1891 = (object_t) (new1441_1410);
	       OBJECT_WIDENING_SET(aux_1891, aux_1893);
	    }
	 }
	 return new1441_1410;
      }
   }
}


/* _make-isfun1768 */ obj_t 
_make_isfun1768_168_inline_inline(obj_t env_1650, obj_t arity_1651, obj_t side_effect__165_1652, obj_t predicate_of_78_1653, obj_t stack_allocator_172_1654, obj_t top__138_1655, obj_t the_closure_238_1656, obj_t property_1657, obj_t args_1658, obj_t body_1659, obj_t class_1660, obj_t dsssl_keywords_243_1661, obj_t loc_1662, obj_t original_body_40_1663, obj_t recursive_calls_44_1664)
{
   {
      isfun_t aux_1896;
      aux_1896 = make_isfun_38_inline_inline((long) CINT(arity_1651), side_effect__165_1652, predicate_of_78_1653, stack_allocator_172_1654, CBOOL(top__138_1655), the_closure_238_1656, property_1657, args_1658, body_1659, class_1660, dsssl_keywords_243_1661, loc_1662, (node_t) (original_body_40_1663), recursive_calls_44_1664);
      return (obj_t) (aux_1896);
   }
}


/* isfun-arity */ long 
isfun_arity_98_inline_inline(sfun_t obj_93)
{
   return (((sfun_t) CREF(obj_93))->arity);
}


/* _isfun-arity1769 */ obj_t 
_isfun_arity1769_193_inline_inline(obj_t env_1665, obj_t obj_1666)
{
   {
      long aux_1903;
      aux_1903 = isfun_arity_98_inline_inline((sfun_t) (obj_1666));
      return BINT(aux_1903);
   }
}


/* isfun-side-effect?-set! */ obj_t 
isfun_side_effect__set__5_inline_inline(sfun_t obj_94, obj_t val1442_95)
{
   return ((((sfun_t) CREF(obj_94))->side_effect__165) = ((obj_t) val1442_95), BUNSPEC);
}


/* _isfun-side-effect?-set!1770 */ obj_t 
_isfun_side_effect__set_1770_92_inline_inline(obj_t env_1667, obj_t obj_1668, obj_t val1442_1669)
{
   return isfun_side_effect__set__5_inline_inline((sfun_t) (obj_1668), val1442_1669);
}


/* isfun-side-effect? */ obj_t 
isfun_side_effect__245_inline_inline(sfun_t obj_96)
{
   return (((sfun_t) CREF(obj_96))->side_effect__165);
}


/* _isfun-side-effect?1771 */ obj_t 
_isfun_side_effect_1771_246_inline_inline(obj_t env_1670, obj_t obj_1671)
{
   return isfun_side_effect__245_inline_inline((sfun_t) (obj_1671));
}


/* isfun-predicate-of-set! */ obj_t 
isfun_predicate_of_set__54_inline_inline(sfun_t obj_97, obj_t val1443_98)
{
   return ((((sfun_t) CREF(obj_97))->predicate_of_78) = ((obj_t) val1443_98), BUNSPEC);
}


/* _isfun-predicate-of-set!1772 */ obj_t 
_isfun_predicate_of_set_1772_31_inline_inline(obj_t env_1672, obj_t obj_1673, obj_t val1443_1674)
{
   return isfun_predicate_of_set__54_inline_inline((sfun_t) (obj_1673), val1443_1674);
}


/* isfun-predicate-of */ obj_t 
isfun_predicate_of_231_inline_inline(sfun_t obj_99)
{
   return (((sfun_t) CREF(obj_99))->predicate_of_78);
}


/* _isfun-predicate-of1773 */ obj_t 
_isfun_predicate_of1773_67_inline_inline(obj_t env_1675, obj_t obj_1676)
{
   return isfun_predicate_of_231_inline_inline((sfun_t) (obj_1676));
}


/* isfun-stack-allocator-set! */ obj_t 
isfun_stack_allocator_set__37_inline_inline(sfun_t obj_100, obj_t val1444_101)
{
   return ((((sfun_t) CREF(obj_100))->stack_allocator_172) = ((obj_t) val1444_101), BUNSPEC);
}


/* _isfun-stack-allocator-set!1774 */ obj_t 
_isfun_stack_allocator_set_1774_62_inline_inline(obj_t env_1677, obj_t obj_1678, obj_t val1444_1679)
{
   return isfun_stack_allocator_set__37_inline_inline((sfun_t) (obj_1678), val1444_1679);
}


/* isfun-stack-allocator */ obj_t 
isfun_stack_allocator_184_inline_inline(sfun_t obj_102)
{
   return (((sfun_t) CREF(obj_102))->stack_allocator_172);
}


/* _isfun-stack-allocator1775 */ obj_t 
_isfun_stack_allocator1775_212_inline_inline(obj_t env_1680, obj_t obj_1681)
{
   return isfun_stack_allocator_184_inline_inline((sfun_t) (obj_1681));
}


/* isfun-top?-set! */ obj_t 
isfun_top__set__21_inline_inline(sfun_t obj_103, bool_t val1445_104)
{
   return ((((sfun_t) CREF(obj_103))->top__138) = ((bool_t) val1445_104), BUNSPEC);
}


/* _isfun-top?-set!1776 */ obj_t 
_isfun_top__set_1776_74_inline_inline(obj_t env_1682, obj_t obj_1683, obj_t val1445_1684)
{
   return isfun_top__set__21_inline_inline((sfun_t) (obj_1683), CBOOL(val1445_1684));
}


/* isfun-top? */ bool_t 
isfun_top__57_inline_inline(sfun_t obj_105)
{
   return (((sfun_t) CREF(obj_105))->top__138);
}


/* _isfun-top?1777 */ obj_t 
_isfun_top_1777_40_inline_inline(obj_t env_1685, obj_t obj_1686)
{
   {
      bool_t aux_1930;
      aux_1930 = isfun_top__57_inline_inline((sfun_t) (obj_1686));
      return BBOOL(aux_1930);
   }
}


/* isfun-the-closure-set! */ obj_t 
isfun_the_closure_set__113_inline_inline(sfun_t obj_106, obj_t val1446_107)
{
   return ((((sfun_t) CREF(obj_106))->the_closure_238) = ((obj_t) val1446_107), BUNSPEC);
}


/* _isfun-the-closure-set!1778 */ obj_t 
_isfun_the_closure_set_1778_182_inline_inline(obj_t env_1687, obj_t obj_1688, obj_t val1446_1689)
{
   return isfun_the_closure_set__113_inline_inline((sfun_t) (obj_1688), val1446_1689);
}


/* isfun-the-closure */ obj_t 
isfun_the_closure_61_inline_inline(sfun_t obj_108)
{
   return (((sfun_t) CREF(obj_108))->the_closure_238);
}


/* _isfun-the-closure1779 */ obj_t 
_isfun_the_closure1779_68_inline_inline(obj_t env_1690, obj_t obj_1691)
{
   return isfun_the_closure_61_inline_inline((sfun_t) (obj_1691));
}


/* isfun-property-set! */ obj_t 
isfun_property_set__21_inline_inline(sfun_t obj_109, obj_t val1447_110)
{
   return ((((sfun_t) CREF(obj_109))->property) = ((obj_t) val1447_110), BUNSPEC);
}


/* _isfun-property-set!1780 */ obj_t 
_isfun_property_set_1780_18_inline_inline(obj_t env_1692, obj_t obj_1693, obj_t val1447_1694)
{
   return isfun_property_set__21_inline_inline((sfun_t) (obj_1693), val1447_1694);
}


/* isfun-property */ obj_t 
isfun_property_57_inline_inline(sfun_t obj_111)
{
   return (((sfun_t) CREF(obj_111))->property);
}


/* _isfun-property1781 */ obj_t 
_isfun_property1781_242_inline_inline(obj_t env_1695, obj_t obj_1696)
{
   return isfun_property_57_inline_inline((sfun_t) (obj_1696));
}


/* isfun-args-set! */ obj_t 
isfun_args_set__220_inline_inline(sfun_t obj_112, obj_t val1448_113)
{
   return ((((sfun_t) CREF(obj_112))->args) = ((obj_t) val1448_113), BUNSPEC);
}


/* _isfun-args-set!1782 */ obj_t 
_isfun_args_set_1782_125_inline_inline(obj_t env_1697, obj_t obj_1698, obj_t val1448_1699)
{
   return isfun_args_set__220_inline_inline((sfun_t) (obj_1698), val1448_1699);
}


/* isfun-args */ obj_t 
isfun_args_255_inline_inline(sfun_t obj_114)
{
   return (((sfun_t) CREF(obj_114))->args);
}


/* _isfun-args1783 */ obj_t 
_isfun_args1783_180_inline_inline(obj_t env_1700, obj_t obj_1701)
{
   return isfun_args_255_inline_inline((sfun_t) (obj_1701));
}


/* isfun-body-set! */ obj_t 
isfun_body_set__168_inline_inline(sfun_t obj_115, obj_t val1449_116)
{
   return ((((sfun_t) CREF(obj_115))->body) = ((obj_t) val1449_116), BUNSPEC);
}


/* _isfun-body-set!1784 */ obj_t 
_isfun_body_set_1784_164_inline_inline(obj_t env_1702, obj_t obj_1703, obj_t val1449_1704)
{
   return isfun_body_set__168_inline_inline((sfun_t) (obj_1703), val1449_1704);
}


/* isfun-body */ obj_t 
isfun_body_87_inline_inline(sfun_t obj_117)
{
   return (((sfun_t) CREF(obj_117))->body);
}


/* _isfun-body1785 */ obj_t 
_isfun_body1785_105_inline_inline(obj_t env_1705, obj_t obj_1706)
{
   return isfun_body_87_inline_inline((sfun_t) (obj_1706));
}


/* isfun-class-set! */ obj_t 
isfun_class_set__81_inline_inline(sfun_t obj_118, obj_t val1450_119)
{
   return ((((sfun_t) CREF(obj_118))->class) = ((obj_t) val1450_119), BUNSPEC);
}


/* _isfun-class-set!1786 */ obj_t 
_isfun_class_set_1786_172_inline_inline(obj_t env_1707, obj_t obj_1708, obj_t val1450_1709)
{
   return isfun_class_set__81_inline_inline((sfun_t) (obj_1708), val1450_1709);
}


/* isfun-class */ obj_t 
isfun_class_67_inline_inline(sfun_t obj_120)
{
   return (((sfun_t) CREF(obj_120))->class);
}


/* _isfun-class1787 */ obj_t 
_isfun_class1787_21_inline_inline(obj_t env_1710, obj_t obj_1711)
{
   return isfun_class_67_inline_inline((sfun_t) (obj_1711));
}


/* isfun-dsssl-keywords-set! */ obj_t 
isfun_dsssl_keywords_set__79_inline_inline(sfun_t obj_121, obj_t val1451_122)
{
   return ((((sfun_t) CREF(obj_121))->dsssl_keywords_243) = ((obj_t) val1451_122), BUNSPEC);
}


/* _isfun-dsssl-keywords-set!1788 */ obj_t 
_isfun_dsssl_keywords_set_1788_177_inline_inline(obj_t env_1712, obj_t obj_1713, obj_t val1451_1714)
{
   return isfun_dsssl_keywords_set__79_inline_inline((sfun_t) (obj_1713), val1451_1714);
}


/* isfun-dsssl-keywords */ obj_t 
isfun_dsssl_keywords_90_inline_inline(sfun_t obj_123)
{
   return (((sfun_t) CREF(obj_123))->dsssl_keywords_243);
}


/* _isfun-dsssl-keywords1789 */ obj_t 
_isfun_dsssl_keywords1789_10_inline_inline(obj_t env_1715, obj_t obj_1716)
{
   return isfun_dsssl_keywords_90_inline_inline((sfun_t) (obj_1716));
}


/* isfun-loc-set! */ obj_t 
isfun_loc_set__164_inline_inline(sfun_t obj_124, obj_t val1452_125)
{
   return ((((sfun_t) CREF(obj_124))->loc) = ((obj_t) val1452_125), BUNSPEC);
}


/* _isfun-loc-set!1790 */ obj_t 
_isfun_loc_set_1790_160_inline_inline(obj_t env_1717, obj_t obj_1718, obj_t val1452_1719)
{
   return isfun_loc_set__164_inline_inline((sfun_t) (obj_1718), val1452_1719);
}


/* isfun-loc */ obj_t 
isfun_loc_80_inline_inline(sfun_t obj_126)
{
   return (((sfun_t) CREF(obj_126))->loc);
}


/* _isfun-loc1791 */ obj_t 
_isfun_loc1791_189_inline_inline(obj_t env_1720, obj_t obj_1721)
{
   return isfun_loc_80_inline_inline((sfun_t) (obj_1721));
}


/* isfun-original-body */ node_t 
isfun_original_body_3_inline_inline(isfun_t obj_127)
{
   {
      obj_t aux_1976;
      {
	 object_t aux_1977;
	 aux_1977 = (object_t) (obj_127);
	 aux_1976 = OBJECT_WIDENING(aux_1977);
      }
      return (((isfun_t) CREF(aux_1976))->original_body_40);
   }
}


/* _isfun-original-body1792 */ obj_t 
_isfun_original_body1792_13_inline_inline(obj_t env_1722, obj_t obj_1723)
{
   {
      node_t aux_1981;
      aux_1981 = isfun_original_body_3_inline_inline((isfun_t) (obj_1723));
      return (obj_t) (aux_1981);
   }
}


/* isfun-recursive-calls-set! */ obj_t 
isfun_recursive_calls_set__23_inline_inline(isfun_t obj_128, obj_t val1453_129)
{
   {
      obj_t aux_1985;
      {
	 object_t aux_1986;
	 aux_1986 = (object_t) (obj_128);
	 aux_1985 = OBJECT_WIDENING(aux_1986);
      }
      return ((((isfun_t) CREF(aux_1985))->recursive_calls_44) = ((obj_t) val1453_129), BUNSPEC);
   }
}


/* _isfun-recursive-calls-set!1793 */ obj_t 
_isfun_recursive_calls_set_1793_3_inline_inline(obj_t env_1724, obj_t obj_1725, obj_t val1453_1726)
{
   return isfun_recursive_calls_set__23_inline_inline((isfun_t) (obj_1725), val1453_1726);
}


/* isfun-recursive-calls */ obj_t 
isfun_recursive_calls_17_inline_inline(isfun_t obj_130)
{
   {
      obj_t aux_1992;
      {
	 object_t aux_1993;
	 aux_1993 = (object_t) (obj_130);
	 aux_1992 = OBJECT_WIDENING(aux_1993);
      }
      return (((isfun_t) CREF(aux_1992))->recursive_calls_44);
   }
}


/* _isfun-recursive-calls1794 */ obj_t 
_isfun_recursive_calls1794_191_inline_inline(obj_t env_1727, obj_t obj_1728)
{
   return isfun_recursive_calls_17_inline_inline((isfun_t) (obj_1728));
}


/* sfun? */ bool_t 
sfun__199_inline_inline(obj_t obj_581)
{
   return is_a__118___object(obj_581, sfun_ast_var);
}


/* _sfun? */ obj_t 
_sfun__63_inline_inline(obj_t env_1642, obj_t obj_1643)
{
   {
      bool_t aux_2000;
      aux_2000 = sfun__199_inline_inline(obj_1643);
      return BBOOL(aux_2000);
   }
}


/* method-init */ obj_t 
method_init_76_inline_inline()
{
   add_generic__110___object(inline_node_env_12_inline_inline, inline_node_default1476_env_173_inline_inline);
   add_inlined_method__244___object(inline_node_env_12_inline_inline, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, var_ast_node, ((long) 1));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, kwote_ast_node, ((long) 2));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, sequence_ast_node, ((long) 3));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, app_ast_node, ((long) 4));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, select_ast_node, ((long) 12));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, box_ref_242_ast_node, ((long) 18));
   add_inlined_method__244___object(inline_node_env_12_inline_inline, box_set__221_ast_node, ((long) 19));
   {
      obj_t object__struct_isfun_152_1733;
      object__struct_isfun_152_1733 = proc1801_inline_inline;
      add_method__1___object(object__struct_env_210___object, isfun_inline_inline, object__struct_isfun_152_1733);
   }
   {
      obj_t struct_object__object_isfun_164_1729;
      struct_object__object_isfun_164_1729 = proc1802_inline_inline;
      return add_method__1___object(struct_object__object_env_209___object, isfun_inline_inline, struct_object__object_isfun_164_1729);
   }
}


/* struct+object->object-isfun */ obj_t 
struct_object__object_isfun_164_inline_inline(obj_t env_1736, obj_t o_1737, obj_t s_1738)
{
   {
      isfun_t o_1198;
      obj_t s_1199;
      {
	 isfun_t aux_2026;
	 o_1198 = (isfun_t) (o_1737);
	 s_1199 = s_1738;
	 {
	    {
	       obj_t old1459_1202;
	       obj_t aux1460_1203;
	       {
		  obj_t next_method1500_218_1209;
		  next_method1500_218_1209 = find_super_class_method_167___object((object_t) (o_1198), struct_object__object_env_209___object, isfun_inline_inline);
		  if (PROCEDUREP(next_method1500_218_1209))
		    {
		       old1459_1202 = PROCEDURE_ENTRY(next_method1500_218_1209) (next_method1500_218_1209, (obj_t) (o_1198), s_1199, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1500_218_1209);
		       {
			  object_t aux_2035;
			  aux_2035 = struct_object__object_93___object((object_t) (o_1198), s_1199);
			  old1459_1202 = (obj_t) (aux_2035);
		       }
		    }
	       }
	       aux1460_1203 = STRUCT_REF(s_1199, ((long) 0));
	       {
		  isfun_t new1461_1204;
		  new1461_1204 = ((isfun_t) (old1459_1202));
		  {
		     long arg1641_1205;
		     arg1641_1205 = class_num_218___object(isfun_inline_inline);
		     {
			obj_t obj_1489;
			obj_1489 = (obj_t) (new1461_1204);
			(((obj_t) CREF(obj_1489))->header = MAKE_HEADER(arg1641_1205, 0), BUNSPEC);
		     }
		  }
		  {
		     isfun_t arg1645_1206;
		     {
			obj_t arg1647_1208;
			arg1647_1208 = STRUCT_REF(aux1460_1203, ((long) 1));
			{
			   isfun_t res1764_1500;
			   {
			      node_t original_body_40_1495;
			      {
				 obj_t aux_2045;
				 aux_2045 = STRUCT_REF(aux1460_1203, ((long) 0));
				 original_body_40_1495 = (node_t) (aux_2045);
			      }
			      {
				 isfun_t new1436_1497;
				 new1436_1497 = ((isfun_t) BREF(GC_MALLOC(sizeof(struct isfun))));
				 ((((isfun_t) CREF(new1436_1497))->original_body_40) = ((node_t) original_body_40_1495), BUNSPEC);
				 ((((isfun_t) CREF(new1436_1497))->recursive_calls_44) = ((obj_t) arg1647_1208), BUNSPEC);
				 res1764_1500 = new1436_1497;
			      }
			   }
			   arg1645_1206 = res1764_1500;
			}
		     }
		     {
			obj_t aux_2053;
			object_t aux_2051;
			aux_2053 = (obj_t) (arg1645_1206);
			aux_2051 = (object_t) (new1461_1204);
			OBJECT_WIDENING_SET(aux_2051, aux_2053);
		     }
		  }
		  aux_2026 = new1461_1204;
	       }
	    }
	 }
	 return (obj_t) (aux_2026);
      }
   }
}


/* object->struct-isfun */ obj_t 
object__struct_isfun_152_inline_inline(obj_t env_1739, obj_t obj1456_1740)
{
   {
      isfun_t obj1456_1183;
      obj1456_1183 = (isfun_t) (obj1456_1740);
      {
	 {
	    obj_t res1457_1186;
	    {
	       obj_t next_method1499_150_1196;
	       next_method1499_150_1196 = find_super_class_method_167___object((object_t) (obj1456_1183), object__struct_env_210___object, isfun_inline_inline);
	       if (PROCEDUREP(next_method1499_150_1196))
		 {
		    res1457_1186 = PROCEDURE_ENTRY(next_method1499_150_1196) (next_method1499_150_1196, (obj_t) (obj1456_1183), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1499_150_1196);
		    res1457_1186 = object__struct_50___object((object_t) (obj1456_1183));
		 }
	    }
	    {
	       obj_t aux1458_1187;
	       {
		  obj_t aux_2068;
		  aux_2068 = CNST_TABLE_REF(((long) 1));
		  aux1458_1187 = make_struct(aux_2068, ((long) 2), BUNSPEC);
	       }
	       {
		  obj_t aux_2071;
		  {
		     node_t aux_2072;
		     {
			obj_t aux_2073;
			{
			   object_t aux_2074;
			   aux_2074 = (object_t) (obj1456_1183);
			   aux_2073 = OBJECT_WIDENING(aux_2074);
			}
			aux_2072 = (((isfun_t) CREF(aux_2073))->original_body_40);
		     }
		     aux_2071 = (obj_t) (aux_2072);
		  }
		  STRUCT_SET(aux1458_1187, ((long) 0), aux_2071);
	       }
	       {
		  obj_t aux_2080;
		  {
		     obj_t aux_2081;
		     {
			object_t aux_2082;
			aux_2082 = (object_t) (obj1456_1183);
			aux_2081 = OBJECT_WIDENING(aux_2082);
		     }
		     aux_2080 = (((isfun_t) CREF(aux_2081))->recursive_calls_44);
		  }
		  STRUCT_SET(aux1458_1187, ((long) 1), aux_2080);
	       }
	       STRUCT_SET(res1457_1186, ((long) 0), aux1458_1187);
	       {
		  obj_t aux_2088;
		  aux_2088 = STRUCT_KEY(res1457_1186);
		  STRUCT_KEY_SET(aux1458_1187, aux_2088);
	       }
	       {
		  obj_t aux_2091;
		  aux_2091 = CNST_TABLE_REF(((long) 1));
		  STRUCT_KEY_SET(res1457_1186, aux_2091);
	       }
	       return res1457_1186;
	    }
	 }
      }
   }
}


/* inline-node */ node_t 
inline_node_218_inline_inline(node_t node_4, long kfactor_5, obj_t stack_6)
{
   {
      obj_t method1653_1217;
      obj_t class1658_1218;
      {
	 obj_t arg1661_1215;
	 obj_t arg1663_1216;
	 {
	    object_t obj_1503;
	    obj_1503 = (object_t) (node_4);
	    {
	       obj_t pre_method_105_1504;
	       pre_method_105_1504 = PROCEDURE_REF(inline_node_env_12_inline_inline, ((long) 2));
	       if (INTEGERP(pre_method_105_1504))
		 {
		    PROCEDURE_SET(inline_node_env_12_inline_inline, ((long) 2), BUNSPEC);
		    arg1661_1215 = pre_method_105_1504;
		 }
	       else
		 {
		    long obj_class_num_177_1509;
		    obj_class_num_177_1509 = TYPE(obj_1503);
		    {
		       obj_t arg1177_1510;
		       arg1177_1510 = PROCEDURE_REF(inline_node_env_12_inline_inline, ((long) 1));
		       {
			  long arg1178_1514;
			  {
			     long arg1179_1515;
			     arg1179_1515 = OBJECT_TYPE;
			     arg1178_1514 = (obj_class_num_177_1509 - arg1179_1515);
			  }
			  arg1661_1215 = VECTOR_REF(arg1177_1510, arg1178_1514);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1520;
	    object_1520 = (object_t) (node_4);
	    {
	       long arg1180_1521;
	       {
		  long arg1181_1522;
		  long arg1182_1523;
		  arg1181_1522 = TYPE(object_1520);
		  arg1182_1523 = OBJECT_TYPE;
		  arg1180_1521 = (arg1181_1522 - arg1182_1523);
	       }
	       {
		  obj_t vector_1527;
		  vector_1527 = _classes__134___object;
		  arg1663_1216 = VECTOR_REF(vector_1527, arg1180_1521);
	       }
	    }
	 }
	 {
	    obj_t aux_2110;
	    method1653_1217 = arg1661_1215;
	    class1658_1218 = arg1663_1216;
	    {
	       if (INTEGERP(method1653_1217))
		 {
		    switch ((long) CINT(method1653_1217))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_2113;
			    aux_2113 = (atom_t) (node_4);
			    aux_2110 = (obj_t) (aux_2113);
			 }
			 break;
		      case ((long) 1):
			 {
			    var_t node_1227;
			    node_1227 = (var_t) (node_4);
			    {
			       bool_t test1666_1231;
			       {
				  bool_t test1668_1233;
				  {
				     long n1_1529;
				     n1_1529 = (long) CINT(_optim__89_engine_param);
				     test1668_1233 = (n1_1529 > ((long) 0));
				  }
				  if (test1668_1233)
				    {
				       bool_t test1669_1234;
				       {
					  obj_t aux_2120;
					  {
					     variable_t aux_2121;
					     aux_2121 = (((var_t) CREF(node_1227))->variable);
					     aux_2120 = (obj_t) (aux_2121);
					  }
					  test1669_1234 = is_a__118___object(aux_2120, global_ast_var);
				       }
				       if (test1669_1234)
					 {
					    bool_t test_2126;
					    {
					       obj_t aux_2132;
					       obj_t aux_2127;
					       aux_2132 = CNST_TABLE_REF(((long) 2));
					       {
						  global_t obj_1534;
						  {
						     variable_t aux_2128;
						     aux_2128 = (((var_t) CREF(node_1227))->variable);
						     obj_1534 = (global_t) (aux_2128);
						  }
						  aux_2127 = (((global_t) CREF(obj_1534))->import);
					       }
					       test_2126 = (aux_2127 == aux_2132);
					    }
					    if (test_2126)
					      {
						 bool_t test_2135;
						 {
						    obj_t aux_2141;
						    obj_t aux_2136;
						    aux_2141 = CNST_TABLE_REF(((long) 3));
						    {
						       global_t obj_1538;
						       {
							  variable_t aux_2137;
							  aux_2137 = (((var_t) CREF(node_1227))->variable);
							  obj_1538 = (global_t) (aux_2137);
						       }
						       aux_2136 = (((global_t) CREF(obj_1538))->access);
						    }
						    test_2135 = (aux_2136 == aux_2141);
						 }
						 if (test_2135)
						   {
						      obj_t aux_2144;
						      {
							 global_t obj_1542;
							 {
							    variable_t aux_2145;
							    aux_2145 = (((var_t) CREF(node_1227))->variable);
							    obj_1542 = (global_t) (aux_2145);
							 }
							 aux_2144 = (((global_t) CREF(obj_1542))->src);
						      }
						      test1666_1231 = is_a__118___object(aux_2144, atom_ast_node);
						   }
						 else
						   {
						      test1666_1231 = ((bool_t) 0);
						   }
					      }
					    else
					      {
						 test1666_1231 = ((bool_t) 0);
					      }
					 }
				       else
					 {
					    test1666_1231 = ((bool_t) 0);
					 }
				    }
				  else
				    {
				       test1666_1231 = ((bool_t) 0);
				    }
			       }
			       if (test1666_1231)
				 {
				    {
				       global_t obj_1545;
				       {
					  variable_t aux_2151;
					  aux_2151 = (((var_t) CREF(node_1227))->variable);
					  obj_1545 = (global_t) (aux_2151);
				       }
				       aux_2110 = (((global_t) CREF(obj_1545))->src);
				    }
				 }
			       else
				 {
				    aux_2110 = (obj_t) (node_1227);
				 }
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    kwote_t aux_2156;
			    aux_2156 = (kwote_t) (node_4);
			    aux_2110 = (obj_t) (aux_2156);
			 }
			 break;
		      case ((long) 3):
			 {
			    sequence_t node_1249;
			    node_1249 = (sequence_t) (node_4);
			    inline_node___77_inline_inline((((sequence_t) CREF(node_1249))->nodes), kfactor_5, stack_6);
			    aux_2110 = (obj_t) (node_1249);
			 }
			 break;
		      case ((long) 4):
			 {
			    app_t node_1253;
			    node_1253 = (app_t) (node_4);
			    inline_node___77_inline_inline((((app_t) CREF(node_1253))->args), kfactor_5, stack_6);
			    {
			       node_t aux_2166;
			       aux_2166 = inline_app_72_inline_app(node_1253, kfactor_5, stack_6);
			       aux_2110 = (obj_t) (aux_2166);
			    }
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_1257;
			    node_1257 = (app_ly_162_t) (node_4);
			    {
			       node_t arg1684_1261;
			       arg1684_1261 = inline_node_218_inline_inline((((app_ly_162_t) CREF(node_1257))->fun), kfactor_5, stack_6);
			       ((((app_ly_162_t) CREF(node_1257))->fun) = ((node_t) arg1684_1261), BUNSPEC);
			    }
			    {
			       node_t arg1686_1263;
			       arg1686_1263 = inline_node_218_inline_inline((((app_ly_162_t) CREF(node_1257))->arg), kfactor_5, stack_6);
			       ((((app_ly_162_t) CREF(node_1257))->arg) = ((node_t) arg1686_1263), BUNSPEC);
			    }
			    aux_2110 = (obj_t) (node_1257);
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_1265;
			    node_1265 = (funcall_t) (node_4);
			    {
			       long z1_1554;
			       z1_1554 = (long) CINT(_non_inlined_calls__201_inline_walk);
			       {
				  long aux_2179;
				  aux_2179 = (z1_1554 + ((long) 1));
				  _non_inlined_calls__201_inline_walk = BINT(aux_2179);
			       }
			    }
			    {
			       node_t arg1689_1268;
			       arg1689_1268 = inline_node_218_inline_inline((((funcall_t) CREF(node_1265))->fun), kfactor_5, stack_6);
			       ((((funcall_t) CREF(node_1265))->fun) = ((node_t) arg1689_1268), BUNSPEC);
			    }
			    inline_node___77_inline_inline((((funcall_t) CREF(node_1265))->args), kfactor_5, stack_6);
			    aux_2110 = (obj_t) (node_1265);
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1271;
			    node_1271 = (pragma_t) (node_4);
			    inline_node___77_inline_inline((((pragma_t) CREF(node_1271))->args), kfactor_5, stack_6);
			    aux_2110 = (obj_t) (node_1271);
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_1275;
			    node_1275 = (cast_t) (node_4);
			    inline_node_218_inline_inline((((cast_t) CREF(node_1275))->arg), kfactor_5, stack_6);
			    aux_2110 = (obj_t) (node_1275);
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_t node_1279;
			    node_1279 = (setq_t) (node_4);
			    {
			       node_t arg1695_1282;
			       arg1695_1282 = inline_node_218_inline_inline((((setq_t) CREF(node_1279))->value), kfactor_5, stack_6);
			       ((((setq_t) CREF(node_1279))->value) = ((node_t) arg1695_1282), BUNSPEC);
			    }
			    aux_2110 = (obj_t) (node_1279);
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_t node_1284;
			    node_1284 = (conditional_t) (node_4);
			    {
			       node_t arg1698_1288;
			       arg1698_1288 = inline_node_218_inline_inline((((conditional_t) CREF(node_1284))->test), kfactor_5, stack_6);
			       ((((conditional_t) CREF(node_1284))->test) = ((node_t) arg1698_1288), BUNSPEC);
			    }
			    {
			       node_t arg1700_1290;
			       arg1700_1290 = inline_node_218_inline_inline((((conditional_t) CREF(node_1284))->true), kfactor_5, stack_6);
			       ((((conditional_t) CREF(node_1284))->true) = ((node_t) arg1700_1290), BUNSPEC);
			    }
			    {
			       node_t arg1702_1292;
			       arg1702_1292 = inline_node_218_inline_inline((((conditional_t) CREF(node_1284))->false), kfactor_5, stack_6);
			       ((((conditional_t) CREF(node_1284))->false) = ((node_t) arg1702_1292), BUNSPEC);
			    }
			    aux_2110 = (obj_t) (node_1284);
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_t node_1294;
			    node_1294 = (fail_t) (node_4);
			    {
			       node_t arg1704_1298;
			       arg1704_1298 = inline_node_218_inline_inline((((fail_t) CREF(node_1294))->proc), kfactor_5, stack_6);
			       ((((fail_t) CREF(node_1294))->proc) = ((node_t) arg1704_1298), BUNSPEC);
			    }
			    {
			       node_t arg1706_1300;
			       arg1706_1300 = inline_node_218_inline_inline((((fail_t) CREF(node_1294))->msg), kfactor_5, stack_6);
			       ((((fail_t) CREF(node_1294))->msg) = ((node_t) arg1706_1300), BUNSPEC);
			    }
			    {
			       node_t arg1708_1302;
			       arg1708_1302 = inline_node_218_inline_inline((((fail_t) CREF(node_1294))->obj), kfactor_5, stack_6);
			       ((((fail_t) CREF(node_1294))->obj) = ((node_t) arg1708_1302), BUNSPEC);
			    }
			    aux_2110 = (obj_t) (node_1294);
			 }
			 break;
		      case ((long) 12):
			 {
			    select_t node_1304;
			    node_1304 = (select_t) (node_4);
			    {
			       node_t arg1710_1307;
			       arg1710_1307 = inline_node_218_inline_inline((((select_t) CREF(node_1304))->test), kfactor_5, stack_6);
			       ((((select_t) CREF(node_1304))->test) = ((node_t) arg1710_1307), BUNSPEC);
			    }
			    {
			       obj_t l1467_1309;
			       l1467_1309 = (((select_t) CREF(node_1304))->clauses);
			     lname1468_1310:
			       if (PAIRP(l1467_1309))
				 {
				    {
				       obj_t clause_1313;
				       clause_1313 = CAR(l1467_1309);
				       {
					  node_t arg1714_1314;
					  {
					     node_t aux_2230;
					     {
						obj_t aux_2231;
						aux_2231 = CDR(clause_1313);
						aux_2230 = (node_t) (aux_2231);
					     }
					     arg1714_1314 = inline_node_218_inline_inline(aux_2230, kfactor_5, stack_6);
					  }
					  {
					     obj_t aux_2235;
					     aux_2235 = (obj_t) (arg1714_1314);
					     SET_CDR(clause_1313, aux_2235);
					  }
				       }
				    }
				    {
				       obj_t l1467_2238;
				       l1467_2238 = CDR(l1467_1309);
				       l1467_1309 = l1467_2238;
				       goto lname1468_1310;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2110 = (obj_t) (node_1304);
			 }
			 break;
		      case ((long) 13):
			 {
			    let_fun_218_t node_1317;
			    node_1317 = (let_fun_218_t) (node_4);
			    {
			       node_t arg1718_1320;
			       arg1718_1320 = inline_node_218_inline_inline((((let_fun_218_t) CREF(node_1317))->body), kfactor_5, stack_6);
			       ((((let_fun_218_t) CREF(node_1317))->body) = ((node_t) arg1718_1320), BUNSPEC);
			    }
			    {
			       obj_t l1469_1322;
			       l1469_1322 = (((let_fun_218_t) CREF(node_1317))->locals);
			     lname1470_1323:
			       if (PAIRP(l1469_1322))
				 {
				    {
				       variable_t aux_2248;
				       {
					  obj_t aux_2249;
					  aux_2249 = CAR(l1469_1322);
					  aux_2248 = (variable_t) (aux_2249);
				       }
				       inline_sfun__229_inline_inline(aux_2248, kfactor_5, stack_6);
				    }
				    {
				       obj_t l1469_2253;
				       l1469_2253 = CDR(l1469_1322);
				       l1469_1322 = l1469_2253;
				       goto lname1470_1323;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2110 = (obj_t) (node_1317);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_var_6_t node_1328;
			    node_1328 = (let_var_6_t) (node_4);
			    {
			       obj_t l1471_1331;
			       l1471_1331 = (((let_var_6_t) CREF(node_1328))->bindings);
			     lname1472_1332:
			       if (PAIRP(l1471_1331))
				 {
				    {
				       obj_t binding_1335;
				       binding_1335 = CAR(l1471_1331);
				       {
					  node_t arg1726_1336;
					  {
					     node_t aux_2261;
					     {
						obj_t aux_2262;
						aux_2262 = CDR(binding_1335);
						aux_2261 = (node_t) (aux_2262);
					     }
					     arg1726_1336 = inline_node_218_inline_inline(aux_2261, kfactor_5, stack_6);
					  }
					  {
					     obj_t aux_2266;
					     aux_2266 = (obj_t) (arg1726_1336);
					     SET_CDR(binding_1335, aux_2266);
					  }
				       }
				    }
				    {
				       obj_t l1471_2269;
				       l1471_2269 = CDR(l1471_1331);
				       l1471_1331 = l1471_2269;
				       goto lname1472_1332;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1729_1339;
			       arg1729_1339 = inline_node_218_inline_inline((((let_var_6_t) CREF(node_1328))->body), kfactor_5, stack_6);
			       ((((let_var_6_t) CREF(node_1328))->body) = ((node_t) arg1729_1339), BUNSPEC);
			    }
			    aux_2110 = (obj_t) (node_1328);
			 }
			 break;
		      case ((long) 15):
			 {
			    set_ex_it_116_t node_1341;
			    node_1341 = (set_ex_it_116_t) (node_4);
			    {
			       node_t arg1731_1344;
			       arg1731_1344 = inline_node_218_inline_inline((((set_ex_it_116_t) CREF(node_1341))->body), kfactor_5, stack_6);
			       ((((set_ex_it_116_t) CREF(node_1341))->body) = ((node_t) arg1731_1344), BUNSPEC);
			    }
			    aux_2110 = (obj_t) (node_1341);
			 }
			 break;
		      case ((long) 16):
			 {
			    jump_ex_it_184_t node_1346;
			    node_1346 = (jump_ex_it_184_t) (node_4);
			    {
			       node_t arg1733_1350;
			       arg1733_1350 = inline_node_218_inline_inline((((jump_ex_it_184_t) CREF(node_1346))->exit), kfactor_5, stack_6);
			       ((((jump_ex_it_184_t) CREF(node_1346))->exit) = ((node_t) arg1733_1350), BUNSPEC);
			    }
			    {
			       node_t arg1739_1352;
			       arg1739_1352 = inline_node_218_inline_inline((((jump_ex_it_184_t) CREF(node_1346))->value), kfactor_5, stack_6);
			       ((((jump_ex_it_184_t) CREF(node_1346))->value) = ((node_t) arg1739_1352), BUNSPEC);
			    }
			    aux_2110 = (obj_t) (node_1346);
			 }
			 break;
		      case ((long) 17):
			 {
			    make_box_202_t node_1354;
			    node_1354 = (make_box_202_t) (node_4);
			    {
			       node_t arg1743_1357;
			       arg1743_1357 = inline_node_218_inline_inline((((make_box_202_t) CREF(node_1354))->value), kfactor_5, stack_6);
			       ((((make_box_202_t) CREF(node_1354))->value) = ((node_t) arg1743_1357), BUNSPEC);
			    }
			    aux_2110 = (obj_t) (node_1354);
			 }
			 break;
		      case ((long) 18):
			 {
			    box_ref_242_t node_1359;
			    node_1359 = (box_ref_242_t) (node_4);
			    {
			       node_t arg1745_1362;
			       {
				  node_t aux_2295;
				  {
				     var_t aux_2296;
				     aux_2296 = (((box_ref_242_t) CREF(node_1359))->var);
				     aux_2295 = (node_t) (aux_2296);
				  }
				  arg1745_1362 = inline_node_218_inline_inline(aux_2295, kfactor_5, stack_6);
			       }
			       {
				  var_t val1424_1624;
				  val1424_1624 = (var_t) (arg1745_1362);
				  ((((box_ref_242_t) CREF(node_1359))->var) = ((var_t) val1424_1624), BUNSPEC);
			       }
			    }
			    aux_2110 = (obj_t) (node_1359);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_set__221_t node_1364;
			    node_1364 = (box_set__221_t) (node_4);
			    {
			       node_t arg1747_1368;
			       {
				  node_t aux_2304;
				  {
				     var_t aux_2305;
				     aux_2305 = (((box_set__221_t) CREF(node_1364))->var);
				     aux_2304 = (node_t) (aux_2305);
				  }
				  arg1747_1368 = inline_node_218_inline_inline(aux_2304, kfactor_5, stack_6);
			       }
			       {
				  var_t val1433_1627;
				  val1433_1627 = (var_t) (arg1747_1368);
				  ((((box_set__221_t) CREF(node_1364))->var) = ((var_t) val1433_1627), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1749_1370;
			       arg1749_1370 = inline_node_218_inline_inline((((box_set__221_t) CREF(node_1364))->value), kfactor_5, stack_6);
			       ((((box_set__221_t) CREF(node_1364))->value) = ((node_t) arg1749_1370), BUNSPEC);
			    }
			    aux_2110 = (obj_t) (node_1364);
			 }
			 break;
		      default:
		       case_else1659_1221:
			 if (PROCEDUREP(method1653_1217))
			   {
			      aux_2110 = PROCEDURE_ENTRY(method1653_1217) (method1653_1217, (obj_t) (node_4), BINT(kfactor_5), stack_6, BEOA);
			   }
			 else
			   {
			      obj_t fun1649_1211;
			      fun1649_1211 = PROCEDURE_REF(inline_node_env_12_inline_inline, ((long) 0));
			      aux_2110 = PROCEDURE_ENTRY(fun1649_1211) (fun1649_1211, (obj_t) (node_4), BINT(kfactor_5), stack_6, BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1659_1221;
		 }
	    }
	    return (node_t) (aux_2110);
	 }
      }
   }
}


/* _inline-node1800 */ obj_t 
_inline_node1800_250_inline_inline(obj_t env_1741, obj_t node_1742, obj_t kfactor_1743, obj_t stack_1744)
{
   {
      node_t aux_2329;
      aux_2329 = inline_node_218_inline_inline((node_t) (node_1742), (long) CINT(kfactor_1743), stack_1744);
      return (obj_t) (aux_2329);
   }
}


/* inline-node-default1476 */ node_t 
inline_node_default1476_251_inline_inline(node_t node_7, long kfactor_8, obj_t stack_9)
{
   FAILURE(CNST_TABLE_REF(((long) 4)), string1803_inline_inline, (obj_t) (node_7));
}


/* _inline-node-default1476 */ obj_t 
_inline_node_default1476_23_inline_inline(obj_t env_1745, obj_t node_1746, obj_t kfactor_1747, obj_t stack_1748)
{
   {
      node_t aux_2337;
      aux_2337 = inline_node_default1476_251_inline_inline((node_t) (node_1746), (long) CINT(kfactor_1747), stack_1748);
      return (obj_t) (aux_2337);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_inline_inline()
{
   module_initialization_70_type_type(((long) 0), "INLINE_INLINE");
   module_initialization_70_ast_var(((long) 0), "INLINE_INLINE");
   module_initialization_70_ast_node(((long) 0), "INLINE_INLINE");
   module_initialization_70_tools_trace(((long) 0), "INLINE_INLINE");
   module_initialization_70_inline_walk(((long) 0), "INLINE_INLINE");
   module_initialization_70_inline_app(((long) 0), "INLINE_INLINE");
   module_initialization_70_ast_alphatize(((long) 0), "INLINE_INLINE");
   module_initialization_70_engine_param(((long) 0), "INLINE_INLINE");
   module_initialization_70_tools_shape(((long) 0), "INLINE_INLINE");
   return module_initialization_70_tools_error(((long) 0), "INLINE_INLINE");
}
