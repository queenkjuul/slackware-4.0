/*===========================================================================*/
/*   (Object/tools.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


static obj_t make_pragma_direct_ref_209_object_tools(type_t, obj_t, obj_t);
static obj_t method_init_76_object_tools();
static obj_t _make_pragma_direct_set__widening_61_object_tools(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t _alloca_object_tools(obj_t, obj_t, obj_t);
static obj_t malloc_allocator_153_object_tools(obj_t, type_t, obj_t);
static obj_t _make_pragma_indexed_set__widening_42_object_tools(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t string_sans___40_type_tools(obj_t);
static obj_t _class__id_49_object_tools(obj_t, obj_t);
static obj_t _class__obj_id_208_object_tools(obj_t, obj_t);
extern obj_t make_pragma_direct_set__widening_17_object_tools(type_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _make_pragma_indexed_ref_widening_107_object_tools(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_object_tools(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t _make_pragma_direct_set__177_object_tools(obj_t, obj_t, obj_t, obj_t, obj_t);
extern type_t find_type_26_type_env(obj_t);
static obj_t imported_modules_init_94_object_tools();
static obj_t _make_pragma_indexed_init_set__29_object_tools(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t make_pragma_indexed_ref_widening_28_object_tools(type_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _obj__class_id_160_object_tools(obj_t, obj_t);
static obj_t make_pragma_indexed_ref_228_object_tools(type_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_object_tools();
extern obj_t class__super_id_210_object_tools(obj_t, obj_t);
static obj_t toplevel_init_63_object_tools();
extern obj_t malloc_object_tools(type_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t class__obj_id_219_object_tools(obj_t);
static obj_t _malloc_object_tools(obj_t, obj_t, obj_t);
extern obj_t make_pragma_indexed_init_set__66_object_tools(type_t, obj_t, obj_t, obj_t);
extern obj_t super__class_id_210_object_tools(obj_t, obj_t);
static obj_t _class__super_id_254_object_tools(obj_t, obj_t, obj_t);
static obj_t _make_pragma_direct_ref_widening_149_object_tools(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _make_pragma_indexed_set__138_object_tools(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t class__id_80_object_tools(obj_t);
extern obj_t make_pragma_direct_set__7_object_tools(type_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t obj__class_id_9_object_tools(obj_t);
extern obj_t make_pragma_direct_ref_widening_240_object_tools(type_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_object_tools = BUNSPEC;
extern obj_t alloca_object_tools(type_t, obj_t);
static obj_t _super__class_id_61_object_tools(obj_t, obj_t, obj_t);
extern obj_t make_pragma_indexed_set__widening_24_object_tools(type_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t cnst_init_137_object_tools();
extern obj_t make_pragma_indexed_set__175_object_tools(type_t, obj_t, obj_t, obj_t, obj_t);
static obj_t __cnst[8];

DEFINE_EXPORT_PROCEDURE(make_pragma_direct_set__widening_env_195_object_tools, _make_pragma_direct_set__widening_61_object_tools1580, _make_pragma_direct_set__widening_61_object_tools, 0L, 5);
DEFINE_EXPORT_PROCEDURE(class__obj_id_env_11_object_tools, _class__obj_id_208_object_tools1581, _class__obj_id_208_object_tools, 0L, 1);
DEFINE_EXPORT_PROCEDURE(alloca_env_212_object_tools, _alloca_object_tools1582, _alloca_object_tools, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_pragma_indexed_set__widening_env_6_object_tools, _make_pragma_indexed_set__widening_42_object_tools1583, _make_pragma_indexed_set__widening_42_object_tools, 0L, 6);
DEFINE_EXPORT_PROCEDURE(obj__class_id_env_107_object_tools, _obj__class_id_160_object_tools1584, _obj__class_id_160_object_tools, 0L, 1);
DEFINE_EXPORT_PROCEDURE(super__class_id_env_38_object_tools, _super__class_id_61_object_tools1585, _super__class_id_61_object_tools, 0L, 2);
DEFINE_EXPORT_PROCEDURE(malloc_env_105_object_tools, _malloc_object_tools1586, _malloc_object_tools, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_pragma_indexed_ref_widening_env_131_object_tools, _make_pragma_indexed_ref_widening_107_object_tools1587, _make_pragma_indexed_ref_widening_107_object_tools, 0L, 5);
DEFINE_EXPORT_PROCEDURE(class__id_env_134_object_tools, _class__id_49_object_tools1588, _class__id_49_object_tools, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_pragma_indexed_init_set__env_86_object_tools, _make_pragma_indexed_init_set__29_object_tools1589, _make_pragma_indexed_init_set__29_object_tools, 0L, 4);
DEFINE_EXPORT_PROCEDURE(class__super_id_env_38_object_tools, _class__super_id_254_object_tools1590, _class__super_id_254_object_tools, 0L, 2);
DEFINE_STRING(string1572_object_tools, string1572_object_tools1591, "VOID* PRAGMA::OBJ OBJECT-WIDENING FREE-PRAGMA -> ? OBJ-> ->OBJ ", 63);
DEFINE_STRING(string1571_object_tools, string1571_object_tools1592, "STACK_ALLOC", 11);
DEFINE_STRING(string1569_object_tools, string1569_object_tools1593, "((", 2);
DEFINE_STRING(string1570_object_tools, string1570_object_tools1594, "GC_MALLOC", 9);
DEFINE_STRING(string1568_object_tools, string1568_object_tools1595, ")BREF( ", 7);
DEFINE_STRING(string1567_object_tools, string1567_object_tools1596, ") )))", 5);
DEFINE_STRING(string1566_object_tools, string1566_object_tools1597, "( sizeof(", 9);
DEFINE_STRING(string1565_object_tools, string1565_object_tools1598, ") * $1 )", 8);
DEFINE_STRING(string1564_object_tools, string1564_object_tools1599, ")[ $2 ] = ((", 12);
DEFINE_STRING(string1563_object_tools, string1563_object_tools1600, ")$3), BUNSPEC)", 14);
DEFINE_STRING(string1562_object_tools, string1562_object_tools1601, " *)$2), BUNSPEC)", 16);
DEFINE_STRING(string1561_object_tools, string1561_object_tools1602, "((((", 4);
DEFINE_STRING(string1559_object_tools, string1559_object_tools1603, ")$2), BUNSPEC)", 14);
DEFINE_STRING(string1560_object_tools, string1560_object_tools1604, ") = ((", 6);
DEFINE_STRING(string1558_object_tools, string1558_object_tools1605, ")[ $2 ]", 7);
DEFINE_STRING(string1557_object_tools, string1557_object_tools1606, "(((", 3);
DEFINE_STRING(string1556_object_tools, string1556_object_tools1607, ")CREF($1))->", 12);
DEFINE_STRING(string1555_object_tools, string1555_object_tools1608, ")", 1);
DEFINE_EXPORT_PROCEDURE(make_pragma_direct_set__env_183_object_tools, _make_pragma_direct_set__177_object_tools1609, _make_pragma_direct_set__177_object_tools, 0L, 4);
DEFINE_EXPORT_PROCEDURE(make_pragma_direct_ref_widening_env_95_object_tools, _make_pragma_direct_ref_widening_149_object_tools1610, _make_pragma_direct_ref_widening_149_object_tools, 0L, 4);
DEFINE_EXPORT_PROCEDURE(make_pragma_indexed_set__env_176_object_tools, _make_pragma_indexed_set__138_object_tools1611, _make_pragma_indexed_set__138_object_tools, 0L, 5);


/* module-initialization */ obj_t 
module_initialization_70_object_tools(long checksum_1068, char *from_1069)
{
   if (CBOOL(require_initialization_114_object_tools))
     {
	require_initialization_114_object_tools = BBOOL(((bool_t) 0));
	library_modules_init_112_object_tools();
	cnst_init_137_object_tools();
	imported_modules_init_94_object_tools();
	method_init_76_object_tools();
	toplevel_init_63_object_tools();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_tools()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "OBJECT_TOOLS");
   module_initialization_70___r4_strings_6_7(((long) 0), "OBJECT_TOOLS");
   module_initialization_70___reader(((long) 0), "OBJECT_TOOLS");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_TOOLS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_tools()
{
   {
      obj_t cnst_port_138_1060;
      cnst_port_138_1060 = open_input_string(string1572_object_tools);
      {
	 long i_1061;
	 i_1061 = ((long) 7);
       loop_1062:
	 {
	    bool_t test1573_1063;
	    test1573_1063 = (i_1061 == ((long) -1));
	    if (test1573_1063)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1575_1064;
		    {
		       obj_t list1576_1065;
		       {
			  obj_t arg1578_1066;
			  arg1578_1066 = BNIL;
			  list1576_1065 = MAKE_PAIR(cnst_port_138_1060, arg1578_1066);
		       }
		       arg1575_1064 = read___reader(list1576_1065);
		    }
		    CNST_TABLE_SET(i_1061, arg1575_1064);
		 }
		 {
		    int aux_1067;
		    {
		       long aux_1088;
		       aux_1088 = (i_1061 - ((long) 1));
		       aux_1067 = (int) (aux_1088);
		    }
		    {
		       long i_1091;
		       i_1091 = (long) (aux_1067);
		       i_1061 = i_1091;
		       goto loop_1062;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_object_tools()
{
   return BUNSPEC;
}


/* class->obj-id */ obj_t 
class__obj_id_219_object_tools(obj_t id_63)
{
   {
      obj_t list1233_509;
      {
	 obj_t arg1234_510;
	 {
	    obj_t aux_1093;
	    aux_1093 = CNST_TABLE_REF(((long) 0));
	    arg1234_510 = MAKE_PAIR(aux_1093, BNIL);
	 }
	 list1233_509 = MAKE_PAIR(id_63, arg1234_510);
      }
      return symbol_append_197___r4_symbols_6_4(list1233_509);
   }
}


/* _class->obj-id */ obj_t 
_class__obj_id_208_object_tools(obj_t env_1001, obj_t id_1002)
{
   return class__obj_id_219_object_tools(id_1002);
}


/* obj->class-id */ obj_t 
obj__class_id_9_object_tools(obj_t id_64)
{
   {
      obj_t arg1236_512;
      arg1236_512 = CNST_TABLE_REF(((long) 1));
      {
	 obj_t list1237_513;
	 {
	    obj_t arg1238_514;
	    arg1238_514 = MAKE_PAIR(id_64, BNIL);
	    list1237_513 = MAKE_PAIR(arg1236_512, arg1238_514);
	 }
	 return symbol_append_197___r4_symbols_6_4(list1237_513);
      }
   }
}


/* _obj->class-id */ obj_t 
_obj__class_id_160_object_tools(obj_t env_1003, obj_t id_1004)
{
   return obj__class_id_9_object_tools(id_1004);
}


/* class?-id */ obj_t 
class__id_80_object_tools(obj_t id_65)
{
   {
      obj_t list1242_517;
      {
	 obj_t arg1243_518;
	 {
	    obj_t aux_1104;
	    aux_1104 = CNST_TABLE_REF(((long) 2));
	    arg1243_518 = MAKE_PAIR(aux_1104, BNIL);
	 }
	 list1242_517 = MAKE_PAIR(id_65, arg1243_518);
      }
      return symbol_append_197___r4_symbols_6_4(list1242_517);
   }
}


/* _class?-id */ obj_t 
_class__id_49_object_tools(obj_t env_1005, obj_t id_1006)
{
   return class__id_80_object_tools(id_1006);
}


/* class->super-id */ obj_t 
class__super_id_210_object_tools(obj_t class_66, obj_t super_67)
{
   {
      obj_t arg1245_520;
      arg1245_520 = CNST_TABLE_REF(((long) 3));
      {
	 obj_t list1246_521;
	 {
	    obj_t arg1247_522;
	    {
	       obj_t arg1248_523;
	       arg1248_523 = MAKE_PAIR(super_67, BNIL);
	       arg1247_522 = MAKE_PAIR(arg1245_520, arg1248_523);
	    }
	    list1246_521 = MAKE_PAIR(class_66, arg1247_522);
	 }
	 return symbol_append_197___r4_symbols_6_4(list1246_521);
      }
   }
}


/* _class->super-id */ obj_t 
_class__super_id_254_object_tools(obj_t env_1007, obj_t class_1008, obj_t super_1009)
{
   return class__super_id_210_object_tools(class_1008, super_1009);
}


/* super->class-id */ obj_t 
super__class_id_210_object_tools(obj_t super_68, obj_t class_69)
{
   {
      obj_t arg1251_525;
      arg1251_525 = CNST_TABLE_REF(((long) 3));
      {
	 obj_t list1252_526;
	 {
	    obj_t arg1253_527;
	    {
	       obj_t arg1254_528;
	       arg1254_528 = MAKE_PAIR(class_69, BNIL);
	       arg1253_527 = MAKE_PAIR(arg1251_525, arg1254_528);
	    }
	    list1252_526 = MAKE_PAIR(super_68, arg1253_527);
	 }
	 return symbol_append_197___r4_symbols_6_4(list1252_526);
      }
   }
}


/* _super->class-id */ obj_t 
_super__class_id_61_object_tools(obj_t env_1010, obj_t super_1011, obj_t class_1012)
{
   return super__class_id_210_object_tools(super_1011, class_1012);
}


/* make-pragma-direct-ref */ obj_t 
make_pragma_direct_ref_209_object_tools(type_t type_70, obj_t slot_71, obj_t obj_72)
{
   {
      obj_t arg1256_530;
      obj_t arg1257_531;
      {
	 obj_t arg1265_537;
	 arg1265_537 = CNST_TABLE_REF(((long) 4));
	 {
	    obj_t list1268_539;
	    {
	       obj_t arg1269_540;
	       {
		  obj_t arg1270_541;
		  {
		     obj_t aux_1123;
		     {
			type_t obj_925;
			{
			   obj_t aux_1124;
			   aux_1124 = STRUCT_REF(slot_71, ((long) 2));
			   obj_925 = (type_t) (aux_1124);
			}
			aux_1123 = (((type_t) CREF(obj_925))->id);
		     }
		     arg1270_541 = MAKE_PAIR(aux_1123, BNIL);
		  }
		  arg1269_540 = MAKE_PAIR(_4dots_199_tools_misc, arg1270_541);
	       }
	       list1268_539 = MAKE_PAIR(arg1265_537, arg1269_540);
	    }
	    arg1256_530 = symbol_append_197___r4_symbols_6_4(list1268_539);
	 }
      }
      {
	 obj_t arg1277_545;
	 obj_t arg1281_547;
	 arg1277_545 = (((type_t) CREF(type_70))->name);
	 arg1281_547 = STRUCT_REF(slot_71, ((long) 1));
	 {
	    obj_t list1283_549;
	    {
	       obj_t arg1284_550;
	       {
		  obj_t arg1285_551;
		  {
		     obj_t arg1286_552;
		     {
			obj_t arg1287_553;
			arg1287_553 = MAKE_PAIR(string1555_object_tools, BNIL);
			arg1286_552 = MAKE_PAIR(arg1281_547, arg1287_553);
		     }
		     arg1285_551 = MAKE_PAIR(string1556_object_tools, arg1286_552);
		  }
		  arg1284_550 = MAKE_PAIR(arg1277_545, arg1285_551);
	       }
	       list1283_549 = MAKE_PAIR(string1557_object_tools, arg1284_550);
	    }
	    arg1257_531 = string_append_106___r4_strings_6_7(list1283_549);
	 }
      }
      {
	 obj_t list1259_533;
	 {
	    obj_t arg1260_534;
	    {
	       obj_t arg1262_535;
	       arg1262_535 = MAKE_PAIR(BNIL, BNIL);
	       arg1260_534 = MAKE_PAIR(obj_72, arg1262_535);
	    }
	    list1259_533 = MAKE_PAIR(arg1257_531, arg1260_534);
	 }
	 return cons__138___r4_pairs_and_lists_6_3(arg1256_530, list1259_533);
      }
   }
}


/* make-pragma-direct-ref/widening */ obj_t 
make_pragma_direct_ref_widening_240_object_tools(type_t type_73, obj_t slot_74, obj_t obj_75, obj_t widening_76)
{
   if (CBOOL(widening_76))
     {
	obj_t arg1290_555;
	{
	   obj_t arg1291_556;
	   arg1291_556 = CNST_TABLE_REF(((long) 5));
	   {
	      obj_t list1293_558;
	      {
		 obj_t arg1294_559;
		 arg1294_559 = MAKE_PAIR(BNIL, BNIL);
		 list1293_558 = MAKE_PAIR(obj_75, arg1294_559);
	      }
	      arg1290_555 = cons__138___r4_pairs_and_lists_6_3(arg1291_556, list1293_558);
	   }
	}
	return make_pragma_direct_ref_209_object_tools(type_73, slot_74, arg1290_555);
     }
   else
     {
	return make_pragma_direct_ref_209_object_tools(type_73, slot_74, obj_75);
     }
}


/* _make-pragma-direct-ref/widening */ obj_t 
_make_pragma_direct_ref_widening_149_object_tools(obj_t env_1013, obj_t type_1014, obj_t slot_1015, obj_t obj_1016, obj_t widening_1017)
{
   return make_pragma_direct_ref_widening_240_object_tools((type_t) (type_1014), slot_1015, obj_1016, widening_1017);
}


/* make-pragma-indexed-ref */ obj_t 
make_pragma_indexed_ref_228_object_tools(type_t type_77, obj_t slot_78, obj_t obj_79, obj_t index_80)
{
   {
      obj_t arg1296_561;
      obj_t arg1297_562;
      {
	 obj_t arg1304_569;
	 arg1304_569 = CNST_TABLE_REF(((long) 4));
	 {
	    obj_t list1308_571;
	    {
	       obj_t arg1309_572;
	       {
		  obj_t arg1310_573;
		  {
		     obj_t aux_1155;
		     {
			type_t obj_933;
			{
			   obj_t aux_1156;
			   aux_1156 = STRUCT_REF(slot_78, ((long) 2));
			   obj_933 = (type_t) (aux_1156);
			}
			aux_1155 = (((type_t) CREF(obj_933))->id);
		     }
		     arg1310_573 = MAKE_PAIR(aux_1155, BNIL);
		  }
		  arg1309_572 = MAKE_PAIR(_4dots_199_tools_misc, arg1310_573);
	       }
	       list1308_571 = MAKE_PAIR(arg1304_569, arg1309_572);
	    }
	    arg1296_561 = symbol_append_197___r4_symbols_6_4(list1308_571);
	 }
      }
      {
	 obj_t arg1316_577;
	 obj_t arg1321_579;
	 arg1316_577 = (((type_t) CREF(type_77))->name);
	 arg1321_579 = STRUCT_REF(slot_78, ((long) 1));
	 {
	    obj_t list1323_581;
	    {
	       obj_t arg1324_582;
	       {
		  obj_t arg1325_583;
		  {
		     obj_t arg1326_584;
		     {
			obj_t arg1328_585;
			arg1328_585 = MAKE_PAIR(string1558_object_tools, BNIL);
			arg1326_584 = MAKE_PAIR(arg1321_579, arg1328_585);
		     }
		     arg1325_583 = MAKE_PAIR(string1556_object_tools, arg1326_584);
		  }
		  arg1324_582 = MAKE_PAIR(arg1316_577, arg1325_583);
	       }
	       list1323_581 = MAKE_PAIR(string1557_object_tools, arg1324_582);
	    }
	    arg1297_562 = string_append_106___r4_strings_6_7(list1323_581);
	 }
      }
      {
	 obj_t list1299_564;
	 {
	    obj_t arg1300_565;
	    {
	       obj_t arg1301_566;
	       {
		  obj_t arg1302_567;
		  arg1302_567 = MAKE_PAIR(BNIL, BNIL);
		  arg1301_566 = MAKE_PAIR(index_80, arg1302_567);
	       }
	       arg1300_565 = MAKE_PAIR(obj_79, arg1301_566);
	    }
	    list1299_564 = MAKE_PAIR(arg1297_562, arg1300_565);
	 }
	 return cons__138___r4_pairs_and_lists_6_3(arg1296_561, list1299_564);
      }
   }
}


/* make-pragma-indexed-ref/widening */ obj_t 
make_pragma_indexed_ref_widening_28_object_tools(type_t type_81, obj_t slot_82, obj_t obj_83, obj_t index_84, obj_t widening_85)
{
   if (CBOOL(widening_85))
     {
	obj_t arg1331_587;
	{
	   obj_t arg1332_588;
	   arg1332_588 = CNST_TABLE_REF(((long) 5));
	   {
	      obj_t list1334_590;
	      {
		 obj_t arg1337_591;
		 arg1337_591 = MAKE_PAIR(BNIL, BNIL);
		 list1334_590 = MAKE_PAIR(obj_83, arg1337_591);
	      }
	      arg1331_587 = cons__138___r4_pairs_and_lists_6_3(arg1332_588, list1334_590);
	   }
	}
	return make_pragma_indexed_ref_228_object_tools(type_81, slot_82, arg1331_587, index_84);
     }
   else
     {
	return make_pragma_indexed_ref_228_object_tools(type_81, slot_82, obj_83, index_84);
     }
}


/* _make-pragma-indexed-ref/widening */ obj_t 
_make_pragma_indexed_ref_widening_107_object_tools(obj_t env_1018, obj_t type_1019, obj_t slot_1020, obj_t obj_1021, obj_t index_1022, obj_t widening_1023)
{
   return make_pragma_indexed_ref_widening_28_object_tools((type_t) (type_1019), slot_1020, obj_1021, index_1022, widening_1023);
}


/* make-pragma-direct-set! */ obj_t 
make_pragma_direct_set__7_object_tools(type_t type_86, obj_t slot_87, obj_t obj_88, obj_t val_89)
{
   {
      obj_t arg1340_593;
      obj_t arg1342_594;
      arg1340_593 = CNST_TABLE_REF(((long) 6));
      {
	 obj_t arg1352_602;
	 obj_t arg1355_604;
	 obj_t arg1357_606;
	 arg1352_602 = (((type_t) CREF(type_86))->name);
	 arg1355_604 = STRUCT_REF(slot_87, ((long) 1));
	 {
	    type_t obj_945;
	    {
	       obj_t aux_1190;
	       aux_1190 = STRUCT_REF(slot_87, ((long) 2));
	       obj_945 = (type_t) (aux_1190);
	    }
	    arg1357_606 = (((type_t) CREF(obj_945))->name);
	 }
	 {
	    obj_t list1362_608;
	    {
	       obj_t arg1363_609;
	       {
		  obj_t arg1364_610;
		  {
		     obj_t arg1365_611;
		     {
			obj_t arg1367_612;
			{
			   obj_t arg1368_613;
			   {
			      obj_t arg1369_614;
			      arg1369_614 = MAKE_PAIR(string1559_object_tools, BNIL);
			      arg1368_613 = MAKE_PAIR(arg1357_606, arg1369_614);
			   }
			   arg1367_612 = MAKE_PAIR(string1560_object_tools, arg1368_613);
			}
			arg1365_611 = MAKE_PAIR(arg1355_604, arg1367_612);
		     }
		     arg1364_610 = MAKE_PAIR(string1556_object_tools, arg1365_611);
		  }
		  arg1363_609 = MAKE_PAIR(arg1352_602, arg1364_610);
	       }
	       list1362_608 = MAKE_PAIR(string1561_object_tools, arg1363_609);
	    }
	    arg1342_594 = string_append_106___r4_strings_6_7(list1362_608);
	 }
      }
      {
	 obj_t list1344_596;
	 {
	    obj_t arg1345_597;
	    {
	       obj_t arg1347_598;
	       {
		  obj_t arg1349_599;
		  arg1349_599 = MAKE_PAIR(BNIL, BNIL);
		  arg1347_598 = MAKE_PAIR(val_89, arg1349_599);
	       }
	       arg1345_597 = MAKE_PAIR(obj_88, arg1347_598);
	    }
	    list1344_596 = MAKE_PAIR(arg1342_594, arg1345_597);
	 }
	 return cons__138___r4_pairs_and_lists_6_3(arg1340_593, list1344_596);
      }
   }
}


/* _make-pragma-direct-set! */ obj_t 
_make_pragma_direct_set__177_object_tools(obj_t env_1024, obj_t type_1025, obj_t slot_1026, obj_t obj_1027, obj_t val_1028)
{
   return make_pragma_direct_set__7_object_tools((type_t) (type_1025), slot_1026, obj_1027, val_1028);
}


/* make-pragma-direct-set!/widening */ obj_t 
make_pragma_direct_set__widening_17_object_tools(type_t type_90, obj_t slot_91, obj_t obj_92, obj_t val_93, obj_t widening_94)
{
   if (CBOOL(widening_94))
     {
	obj_t arg1373_617;
	{
	   obj_t arg1375_618;
	   arg1375_618 = CNST_TABLE_REF(((long) 5));
	   {
	      obj_t list1379_620;
	      {
		 obj_t arg1381_621;
		 arg1381_621 = MAKE_PAIR(BNIL, BNIL);
		 list1379_620 = MAKE_PAIR(obj_92, arg1381_621);
	      }
	      arg1373_617 = cons__138___r4_pairs_and_lists_6_3(arg1375_618, list1379_620);
	   }
	}
	return make_pragma_direct_set__7_object_tools(type_90, slot_91, arg1373_617, val_93);
     }
   else
     {
	return make_pragma_direct_set__7_object_tools(type_90, slot_91, obj_92, val_93);
     }
}


/* _make-pragma-direct-set!/widening */ obj_t 
_make_pragma_direct_set__widening_61_object_tools(obj_t env_1029, obj_t type_1030, obj_t slot_1031, obj_t obj_1032, obj_t val_1033, obj_t widening_1034)
{
   return make_pragma_direct_set__widening_17_object_tools((type_t) (type_1030), slot_1031, obj_1032, val_1033, widening_1034);
}


/* make-pragma-indexed-init-set! */ obj_t 
make_pragma_indexed_init_set__66_object_tools(type_t type_95, obj_t slot_96, obj_t obj_97, obj_t val_98)
{
   {
      obj_t arg1384_623;
      obj_t arg1385_624;
      arg1384_623 = CNST_TABLE_REF(((long) 6));
      {
	 obj_t arg1395_632;
	 obj_t arg1397_634;
	 obj_t arg1399_636;
	 arg1395_632 = (((type_t) CREF(type_95))->name);
	 arg1397_634 = STRUCT_REF(slot_96, ((long) 1));
	 {
	    type_t obj_953;
	    {
	       obj_t aux_1222;
	       aux_1222 = STRUCT_REF(slot_96, ((long) 2));
	       obj_953 = (type_t) (aux_1222);
	    }
	    arg1399_636 = (((type_t) CREF(obj_953))->name);
	 }
	 {
	    obj_t list1402_638;
	    {
	       obj_t arg1403_639;
	       {
		  obj_t arg1405_640;
		  {
		     obj_t arg1407_641;
		     {
			obj_t arg1408_642;
			{
			   obj_t arg1410_643;
			   {
			      obj_t arg1411_644;
			      arg1411_644 = MAKE_PAIR(string1562_object_tools, BNIL);
			      arg1410_643 = MAKE_PAIR(arg1399_636, arg1411_644);
			   }
			   arg1408_642 = MAKE_PAIR(string1560_object_tools, arg1410_643);
			}
			arg1407_641 = MAKE_PAIR(arg1397_634, arg1408_642);
		     }
		     arg1405_640 = MAKE_PAIR(string1556_object_tools, arg1407_641);
		  }
		  arg1403_639 = MAKE_PAIR(arg1395_632, arg1405_640);
	       }
	       list1402_638 = MAKE_PAIR(string1561_object_tools, arg1403_639);
	    }
	    arg1385_624 = string_append_106___r4_strings_6_7(list1402_638);
	 }
      }
      {
	 obj_t list1388_626;
	 {
	    obj_t arg1389_627;
	    {
	       obj_t arg1390_628;
	       {
		  obj_t arg1391_629;
		  arg1391_629 = MAKE_PAIR(BNIL, BNIL);
		  arg1390_628 = MAKE_PAIR(val_98, arg1391_629);
	       }
	       arg1389_627 = MAKE_PAIR(obj_97, arg1390_628);
	    }
	    list1388_626 = MAKE_PAIR(arg1385_624, arg1389_627);
	 }
	 return cons__138___r4_pairs_and_lists_6_3(arg1384_623, list1388_626);
      }
   }
}


/* _make-pragma-indexed-init-set! */ obj_t 
_make_pragma_indexed_init_set__29_object_tools(obj_t env_1035, obj_t type_1036, obj_t slot_1037, obj_t obj_1038, obj_t val_1039)
{
   return make_pragma_indexed_init_set__66_object_tools((type_t) (type_1036), slot_1037, obj_1038, val_1039);
}


/* make-pragma-indexed-set! */ obj_t 
make_pragma_indexed_set__175_object_tools(type_t type_99, obj_t slot_100, obj_t obj_101, obj_t val_102, obj_t index_103)
{
   {
      obj_t arg1415_647;
      obj_t arg1416_648;
      arg1415_647 = CNST_TABLE_REF(((long) 6));
      {
	 obj_t arg1431_657;
	 obj_t arg1433_659;
	 obj_t arg1437_661;
	 arg1431_657 = (((type_t) CREF(type_99))->name);
	 arg1433_659 = STRUCT_REF(slot_100, ((long) 1));
	 {
	    type_t obj_961;
	    {
	       obj_t aux_1244;
	       aux_1244 = STRUCT_REF(slot_100, ((long) 2));
	       obj_961 = (type_t) (aux_1244);
	    }
	    arg1437_661 = (((type_t) CREF(obj_961))->name);
	 }
	 {
	    obj_t list1439_663;
	    {
	       obj_t arg1440_664;
	       {
		  obj_t arg1441_665;
		  {
		     obj_t arg1443_666;
		     {
			obj_t arg1444_667;
			{
			   obj_t arg1446_668;
			   {
			      obj_t arg1448_669;
			      arg1448_669 = MAKE_PAIR(string1563_object_tools, BNIL);
			      arg1446_668 = MAKE_PAIR(arg1437_661, arg1448_669);
			   }
			   arg1444_667 = MAKE_PAIR(string1564_object_tools, arg1446_668);
			}
			arg1443_666 = MAKE_PAIR(arg1433_659, arg1444_667);
		     }
		     arg1441_665 = MAKE_PAIR(string1556_object_tools, arg1443_666);
		  }
		  arg1440_664 = MAKE_PAIR(arg1431_657, arg1441_665);
	       }
	       list1439_663 = MAKE_PAIR(string1561_object_tools, arg1440_664);
	    }
	    arg1416_648 = string_append_106___r4_strings_6_7(list1439_663);
	 }
      }
      {
	 obj_t list1418_650;
	 {
	    obj_t arg1419_651;
	    {
	       obj_t arg1421_652;
	       {
		  obj_t arg1423_653;
		  {
		     obj_t arg1426_654;
		     arg1426_654 = MAKE_PAIR(BNIL, BNIL);
		     arg1423_653 = MAKE_PAIR(val_102, arg1426_654);
		  }
		  arg1421_652 = MAKE_PAIR(index_103, arg1423_653);
	       }
	       arg1419_651 = MAKE_PAIR(obj_101, arg1421_652);
	    }
	    list1418_650 = MAKE_PAIR(arg1416_648, arg1419_651);
	 }
	 return cons__138___r4_pairs_and_lists_6_3(arg1415_647, list1418_650);
      }
   }
}


/* _make-pragma-indexed-set! */ obj_t 
_make_pragma_indexed_set__138_object_tools(obj_t env_1040, obj_t type_1041, obj_t slot_1042, obj_t obj_1043, obj_t val_1044, obj_t index_1045)
{
   return make_pragma_indexed_set__175_object_tools((type_t) (type_1041), slot_1042, obj_1043, val_1044, index_1045);
}


/* make-pragma-indexed-set!/widening */ obj_t 
make_pragma_indexed_set__widening_24_object_tools(type_t type_104, obj_t slot_105, obj_t obj_106, obj_t val_107, obj_t index_108, obj_t widening_109)
{
   if (CBOOL(widening_109))
     {
	obj_t arg1453_962;
	{
	   obj_t arg1454_963;
	   arg1454_963 = CNST_TABLE_REF(((long) 5));
	   {
	      obj_t list1456_965;
	      {
		 obj_t arg1458_966;
		 arg1458_966 = MAKE_PAIR(BNIL, BNIL);
		 list1456_965 = MAKE_PAIR(obj_106, arg1458_966);
	      }
	      arg1453_962 = cons__138___r4_pairs_and_lists_6_3(arg1454_963, list1456_965);
	   }
	}
	return make_pragma_indexed_set__175_object_tools(type_104, slot_105, arg1453_962, val_107, index_108);
     }
   else
     {
	return make_pragma_indexed_set__175_object_tools(type_104, slot_105, obj_106, val_107, index_108);
     }
}


/* _make-pragma-indexed-set!/widening */ obj_t 
_make_pragma_indexed_set__widening_42_object_tools(obj_t env_1046, obj_t type_1047, obj_t slot_1048, obj_t obj_1049, obj_t val_1050, obj_t index_1051, obj_t widening_1052)
{
   return make_pragma_indexed_set__widening_24_object_tools((type_t) (type_1047), slot_1048, obj_1049, val_1050, index_1051, widening_1052);
}


/* malloc/allocator */ obj_t 
malloc_allocator_153_object_tools(obj_t allocator_110, type_t type_111, obj_t size_112)
{
   {
      obj_t tid_678;
      obj_t tname_679;
      obj_t sizeof_680;
      tid_678 = (((type_t) CREF(type_111))->id);
      tname_679 = string_sans___40_type_tools((((type_t) CREF(type_111))->name));
      {
	 bool_t test_1277;
	 {
	    obj_t aux_1278;
	    aux_1278 = (((type_t) CREF(type_111))->size);
	    test_1277 = STRINGP(aux_1278);
	 }
	 if (test_1277)
	   {
	      sizeof_680 = (((type_t) CREF(type_111))->size);
	   }
	 else
	   {
	      sizeof_680 = (((type_t) CREF(type_111))->name);
	   }
      }
      if (SYMBOLP(size_112))
	{
	   type_t void__131_682;
	   void__131_682 = find_type_26_type_env(CNST_TABLE_REF(((long) 7)));
	   {
	      {
		 obj_t arg1463_685;
		 obj_t arg1464_686;
		 {
		    obj_t arg1470_692;
		    arg1470_692 = CNST_TABLE_REF(((long) 4));
		    {
		       obj_t list1471_693;
		       {
			  obj_t arg1473_694;
			  {
			     obj_t arg1474_695;
			     {
				obj_t aux_1288;
				aux_1288 = (((type_t) CREF(void__131_682))->id);
				arg1474_695 = MAKE_PAIR(aux_1288, BNIL);
			     }
			     arg1473_694 = MAKE_PAIR(_4dots_199_tools_misc, arg1474_695);
			  }
			  list1471_693 = MAKE_PAIR(arg1470_692, arg1473_694);
		       }
		       arg1463_685 = symbol_append_197___r4_symbols_6_4(list1471_693);
		    }
		 }
		 {
		    obj_t list1476_697;
		    {
		       obj_t arg1477_698;
		       {
			  obj_t arg1479_700;
			  {
			     obj_t arg1480_701;
			     arg1480_701 = MAKE_PAIR(string1565_object_tools, BNIL);
			     arg1479_700 = MAKE_PAIR(sizeof_680, arg1480_701);
			  }
			  arg1477_698 = MAKE_PAIR(string1566_object_tools, arg1479_700);
		       }
		       list1476_697 = MAKE_PAIR(allocator_110, arg1477_698);
		    }
		    arg1464_686 = string_append_106___r4_strings_6_7(list1476_697);
		 }
		 {
		    obj_t list1466_688;
		    {
		       obj_t arg1467_689;
		       {
			  obj_t arg1468_690;
			  arg1468_690 = MAKE_PAIR(BNIL, BNIL);
			  arg1467_689 = MAKE_PAIR(size_112, arg1468_690);
		       }
		       list1466_688 = MAKE_PAIR(arg1464_686, arg1467_689);
		    }
		    return cons__138___r4_pairs_and_lists_6_3(arg1463_685, list1466_688);
		 }
	      }
	   }
	}
      else
	{
	   obj_t arg1485_705;
	   obj_t arg1486_706;
	   {
	      obj_t arg1491_711;
	      arg1491_711 = CNST_TABLE_REF(((long) 4));
	      {
		 obj_t list1492_712;
		 {
		    obj_t arg1494_713;
		    {
		       obj_t arg1496_714;
		       arg1496_714 = MAKE_PAIR(tid_678, BNIL);
		       arg1494_713 = MAKE_PAIR(_4dots_199_tools_misc, arg1496_714);
		    }
		    list1492_712 = MAKE_PAIR(arg1491_711, arg1494_713);
		 }
		 arg1485_705 = symbol_append_197___r4_symbols_6_4(list1492_712);
	      }
	   }
	   {
	      obj_t list1498_716;
	      {
		 obj_t arg1500_718;
		 {
		    obj_t arg1501_719;
		    {
		       obj_t arg1503_721;
		       {
			  obj_t arg1504_722;
			  {
			     obj_t arg1507_724;
			     {
				obj_t arg1510_725;
				arg1510_725 = MAKE_PAIR(string1567_object_tools, BNIL);
				arg1507_724 = MAKE_PAIR(sizeof_680, arg1510_725);
			     }
			     arg1504_722 = MAKE_PAIR(string1566_object_tools, arg1507_724);
			  }
			  arg1503_721 = MAKE_PAIR(allocator_110, arg1504_722);
		       }
		       arg1501_719 = MAKE_PAIR(string1568_object_tools, arg1503_721);
		    }
		    arg1500_718 = MAKE_PAIR(tname_679, arg1501_719);
		 }
		 list1498_716 = MAKE_PAIR(string1569_object_tools, arg1500_718);
	      }
	      arg1486_706 = string_append_106___r4_strings_6_7(list1498_716);
	   }
	   {
	      obj_t list1488_708;
	      {
		 obj_t arg1489_709;
		 arg1489_709 = MAKE_PAIR(BNIL, BNIL);
		 list1488_708 = MAKE_PAIR(arg1486_706, arg1489_709);
	      }
	      return cons__138___r4_pairs_and_lists_6_3(arg1485_705, list1488_708);
	   }
	}
   }
}


/* malloc */ obj_t 
malloc_object_tools(type_t type_113, obj_t size_114)
{
   return malloc_allocator_153_object_tools(string1570_object_tools, type_113, size_114);
}


/* _malloc */ obj_t 
_malloc_object_tools(obj_t env_1053, obj_t type_1054, obj_t size_1055)
{
   return malloc_object_tools((type_t) (type_1054), size_1055);
}


/* alloca */ obj_t 
alloca_object_tools(type_t type_115, obj_t size_116)
{
   return malloc_allocator_153_object_tools(string1571_object_tools, type_115, size_116);
}


/* _alloca */ obj_t 
_alloca_object_tools(obj_t env_1056, obj_t type_1057, obj_t size_1058)
{
   return alloca_object_tools((type_t) (type_1057), size_1058);
}


/* method-init */ obj_t 
method_init_76_object_tools()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_tools()
{
   module_initialization_70_tools_misc(((long) 0), "OBJECT_TOOLS");
   module_initialization_70_type_type(((long) 0), "OBJECT_TOOLS");
   module_initialization_70_type_env(((long) 0), "OBJECT_TOOLS");
   module_initialization_70_type_tools(((long) 0), "OBJECT_TOOLS");
   module_initialization_70_ast_var(((long) 0), "OBJECT_TOOLS");
   return module_initialization_70_object_class(((long) 0), "OBJECT_TOOLS");
}
