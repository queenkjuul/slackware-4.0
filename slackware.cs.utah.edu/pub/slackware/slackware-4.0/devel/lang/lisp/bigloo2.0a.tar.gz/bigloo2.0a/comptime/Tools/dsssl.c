/*===========================================================================*/
/*   (Tools/dsssl.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t dsssl_formals_skeleton_108_tools_dsssl(obj_t);
extern obj_t dsssl_find_first_formal_237_tools_dsssl(obj_t);
static obj_t _dsssl_named_constant__60_tools_dsssl(obj_t, obj_t);
extern obj_t dsssl_defaulted_formal__174_tools_dsssl(obj_t);
static obj_t _dsssl_args___args_list_110_tools_dsssl(obj_t, obj_t);
extern obj_t dsssl_formals_encoding_15_tools_dsssl(obj_t);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
static obj_t imported_modules_init_94_tools_dsssl();
extern obj_t dsssl_named_constant__188_tools_dsssl(obj_t);
static obj_t _dsssl_formals_skeleton_135_tools_dsssl(obj_t, obj_t);
static obj_t _dsssl_find_first_formal_102_tools_dsssl(obj_t, obj_t);
extern obj_t dsssl_args___args_list_201_tools_dsssl(obj_t);
static obj_t _dsssl_default_formal_247_tools_dsssl(obj_t, obj_t);
static obj_t loop_tools_dsssl(obj_t, bool_t);
static obj_t _dsssl_defaulted_formal__146_tools_dsssl(obj_t, obj_t);
static obj_t _dsssl_formals_encoding_186_tools_dsssl(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_tools_dsssl = BUNSPEC;
extern obj_t dsssl_default_formal_243_tools_dsssl(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(dsssl_formals_skeleton_env_26_tools_dsssl, _dsssl_formals_skeleton_135_tools_dsssl1194, _dsssl_formals_skeleton_135_tools_dsssl, 0L, 1);
DEFINE_EXPORT_PROCEDURE(dsssl_named_constant__env_14_tools_dsssl, _dsssl_named_constant__60_tools_dsssl1195, _dsssl_named_constant__60_tools_dsssl, 0L, 1);
DEFINE_EXPORT_PROCEDURE(dsssl_args___args_list_env_148_tools_dsssl, _dsssl_args___args_list_110_tools_dsssl1196, _dsssl_args___args_list_110_tools_dsssl, 0L, 1);
DEFINE_EXPORT_PROCEDURE(dsssl_formals_encoding_env_27_tools_dsssl, _dsssl_formals_encoding_186_tools_dsssl1197, _dsssl_formals_encoding_186_tools_dsssl, 0L, 1);
DEFINE_EXPORT_PROCEDURE(dsssl_default_formal_env_20_tools_dsssl, _dsssl_default_formal_247_tools_dsssl1198, _dsssl_default_formal_247_tools_dsssl, 0L, 1);
DEFINE_EXPORT_PROCEDURE(dsssl_defaulted_formal__env_156_tools_dsssl, _dsssl_defaulted_formal__146_tools_dsssl1199, _dsssl_defaulted_formal__146_tools_dsssl, 0L, 1);
DEFINE_STRING(string1192_tools_dsssl, string1192_tools_dsssl1200, "Illegal dsssl formal list", 25);
DEFINE_STRING(string1191_tools_dsssl, string1191_tools_dsssl1201, "dsssl-find-first-formal", 23);
DEFINE_EXPORT_PROCEDURE(dsssl_find_first_formal_env_30_tools_dsssl, _dsssl_find_first_formal_102_tools_dsssl1202, _dsssl_find_first_formal_102_tools_dsssl, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_tools_dsssl(long checksum_138, char *from_139)
{
   if (CBOOL(require_initialization_114_tools_dsssl))
     {
	require_initialization_114_tools_dsssl = BBOOL(((bool_t) 0));
	imported_modules_init_94_tools_dsssl();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* dsssl-named-constant? */ obj_t 
dsssl_named_constant__188_tools_dsssl(obj_t obj_1)
{
   if (CNSTP(obj_1))
     {
	long aux1004_10;
	aux1004_10 = CCNST(obj_1);
	switch (aux1004_10)
	  {
	  case ((long) 258):
	  case ((long) 259):
	  case ((long) 262):
	     return BTRUE;
	     break;
	  default:
	     return BFALSE;
	  }
     }
   else
     {
	return BFALSE;
     }
}


/* _dsssl-named-constant? */ obj_t 
_dsssl_named_constant__60_tools_dsssl(obj_t env_124, obj_t obj_125)
{
   return dsssl_named_constant__188_tools_dsssl(obj_125);
}


/* dsssl-defaulted-formal? */ obj_t 
dsssl_defaulted_formal__174_tools_dsssl(obj_t obj_2)
{
   if (PAIRP(obj_2))
     {
	obj_t cdr_105_52_16;
	cdr_105_52_16 = CDR(obj_2);
	if (PAIRP(cdr_105_52_16))
	  {
	     bool_t test_154;
	     {
		obj_t aux_155;
		aux_155 = CDR(cdr_105_52_16);
		test_154 = (aux_155 == BNIL);
	     }
	     if (test_154)
	       {
		  return BTRUE;
	       }
	     else
	       {
		  return BFALSE;
	       }
	  }
	else
	  {
	     return BFALSE;
	  }
     }
   else
     {
	return BFALSE;
     }
}


/* _dsssl-defaulted-formal? */ obj_t 
_dsssl_defaulted_formal__146_tools_dsssl(obj_t env_126, obj_t obj_127)
{
   return dsssl_defaulted_formal__174_tools_dsssl(obj_127);
}


/* dsssl-default-formal */ obj_t 
dsssl_default_formal_243_tools_dsssl(obj_t obj_3)
{
   return CAR(obj_3);
}


/* _dsssl-default-formal */ obj_t 
_dsssl_default_formal_247_tools_dsssl(obj_t env_128, obj_t obj_129)
{
   return dsssl_default_formal_243_tools_dsssl(obj_129);
}


/* dsssl-find-first-formal */ obj_t 
dsssl_find_first_formal_237_tools_dsssl(obj_t args_4)
{
 dsssl_find_first_formal_237_tools_dsssl:
   if (NULLP(args_4))
     {
	return BFALSE;
     }
   else
     {
	if (PAIRP(args_4))
	  {
	     bool_t test1015_23;
	     {
		obj_t aux_165;
		aux_165 = dsssl_named_constant__188_tools_dsssl(CAR(args_4));
		test1015_23 = CBOOL(aux_165);
	     }
	     if (test1015_23)
	       {
		  {
		     obj_t args_170;
		     args_170 = CDR(args_4);
		     args_4 = args_170;
		     goto dsssl_find_first_formal_237_tools_dsssl;
		  }
	       }
	     else
	       {
		  bool_t test_172;
		  {
		     obj_t aux_173;
		     aux_173 = dsssl_defaulted_formal__174_tools_dsssl(CAR(args_4));
		     test_172 = CBOOL(aux_173);
		  }
		  if (test_172)
		    {
		       {
			  obj_t aux_177;
			  aux_177 = CAR(args_4);
			  return CAR(aux_177);
		       }
		    }
		  else
		    {
		       bool_t test_180;
		       {
			  obj_t aux_181;
			  aux_181 = CAR(args_4);
			  test_180 = SYMBOLP(aux_181);
		       }
		       if (test_180)
			 {
			    return CAR(args_4);
			 }
		       else
			 {
			    return internal_error_43_tools_error(string1191_tools_dsssl, string1192_tools_dsssl, args_4);
			 }
		    }
	       }
	  }
	else
	  {
	     return internal_error_43_tools_error(string1191_tools_dsssl, string1192_tools_dsssl, args_4);
	  }
     }
}


/* _dsssl-find-first-formal */ obj_t 
_dsssl_find_first_formal_102_tools_dsssl(obj_t env_130, obj_t args_131)
{
   return dsssl_find_first_formal_237_tools_dsssl(args_131);
}


/* dsssl-formals-skeleton */ obj_t 
dsssl_formals_skeleton_108_tools_dsssl(obj_t args_5)
{
   return loop_tools_dsssl(args_5, ((bool_t) 0));
}


/* loop */ obj_t 
loop_tools_dsssl(obj_t args_31, bool_t skip_32)
{
 loop_tools_dsssl:
   if (NULLP(args_31))
     {
	return BNIL;
     }
   else
     {
	if (PAIRP(args_31))
	  {
	     bool_t test1037_36;
	     {
		obj_t aux_193;
		aux_193 = dsssl_named_constant__188_tools_dsssl(CAR(args_31));
		test1037_36 = CBOOL(aux_193);
	     }
	     if (test1037_36)
	       {
		  {
		     obj_t arg1038_37;
		     obj_t arg1039_38;
		     arg1038_37 = CAR(args_31);
		     arg1039_38 = loop_tools_dsssl(CDR(args_31), ((bool_t) 1));
		     return MAKE_PAIR(arg1038_37, arg1039_38);
		  }
	       }
	     else
	       {
		  if (skip_32)
		    {
		       {
			  obj_t args_203;
			  args_203 = CDR(args_31);
			  args_31 = args_203;
			  goto loop_tools_dsssl;
		       }
		    }
		  else
		    {
		       {
			  obj_t arg1053_41;
			  obj_t arg1055_42;
			  arg1053_41 = CAR(args_31);
			  arg1055_42 = loop_tools_dsssl(CDR(args_31), skip_32);
			  return MAKE_PAIR(arg1053_41, arg1055_42);
		       }
		    }
	       }
	  }
	else
	  {
	     return args_31;
	  }
     }
}


/* _dsssl-formals-skeleton */ obj_t 
_dsssl_formals_skeleton_135_tools_dsssl(obj_t env_132, obj_t args_133)
{
   return dsssl_formals_skeleton_108_tools_dsssl(args_133);
}


/* dsssl-formals-encoding */ obj_t 
dsssl_formals_encoding_15_tools_dsssl(obj_t args_6)
{
   {
      obj_t args_45;
      obj_t res_46;
      args_45 = args_6;
      res_46 = BNIL;
    loop_47:
      if (NULLP(args_45))
	{
	   return res_46;
	}
      else
	{
	   if (PAIRP(args_45))
	     {
		bool_t test1069_51;
		{
		   obj_t aux_214;
		   aux_214 = dsssl_named_constant__188_tools_dsssl(CAR(args_45));
		   test1069_51 = CBOOL(aux_214);
		}
		if (test1069_51)
		  {
		     {
			obj_t arg1077_52;
			obj_t arg1137_53;
			arg1077_52 = CDR(args_45);
			{
			   obj_t aux_220;
			   aux_220 = CAR(args_45);
			   arg1137_53 = MAKE_PAIR(aux_220, res_46);
			}
			{
			   obj_t res_224;
			   obj_t args_223;
			   args_223 = arg1077_52;
			   res_224 = arg1137_53;
			   res_46 = res_224;
			   args_45 = args_223;
			   goto loop_47;
			}
		     }
		  }
		else
		  {
		     {
			obj_t args_225;
			args_225 = CDR(args_45);
			args_45 = args_225;
			goto loop_47;
		     }
		  }
	     }
	   else
	     {
		return res_46;
	     }
	}
   }
}


/* _dsssl-formals-encoding */ obj_t 
_dsssl_formals_encoding_186_tools_dsssl(obj_t env_134, obj_t args_135)
{
   return dsssl_formals_encoding_15_tools_dsssl(args_135);
}


/* dsssl-args*->args-list */ obj_t 
dsssl_args___args_list_201_tools_dsssl(obj_t exp_7)
{
 dsssl_args___args_list_201_tools_dsssl:
   if (NULLP(exp_7))
     {
	return BNIL;
     }
   else
     {
	if (PAIRP(exp_7))
	  {
	     bool_t test1148_59;
	     {
		obj_t aux_232;
		aux_232 = dsssl_named_constant__188_tools_dsssl(CAR(exp_7));
		test1148_59 = CBOOL(aux_232);
	     }
	     if (test1148_59)
	       {
		  {
		     obj_t arg_60;
		     arg_60 = dsssl_find_first_formal_237_tools_dsssl(CDR(exp_7));
		     if (CBOOL(arg_60))
		       {
			  obj_t list1149_61;
			  list1149_61 = MAKE_PAIR(arg_60, BNIL);
			  return list1149_61;
		       }
		     else
		       {
			  return BNIL;
		       }
		  }
	       }
	     else
	       {
		  bool_t test_242;
		  {
		     obj_t aux_243;
		     aux_243 = dsssl_defaulted_formal__174_tools_dsssl(CAR(exp_7));
		     test_242 = CBOOL(aux_243);
		  }
		  if (test_242)
		    {
		       {
			  obj_t exp_247;
			  exp_247 = CDR(exp_7);
			  exp_7 = exp_247;
			  goto dsssl_args___args_list_201_tools_dsssl;
		       }
		    }
		  else
		    {
		       {
			  obj_t arg1163_66;
			  obj_t arg1175_67;
			  arg1163_66 = CAR(exp_7);
			  arg1175_67 = dsssl_args___args_list_201_tools_dsssl(CDR(exp_7));
			  return MAKE_PAIR(arg1163_66, arg1175_67);
		       }
		    }
	       }
	  }
	else
	  {
	     {
		obj_t list1189_71;
		list1189_71 = MAKE_PAIR(exp_7, BNIL);
		return list1189_71;
	     }
	  }
     }
}


/* _dsssl-args*->args-list */ obj_t 
_dsssl_args___args_list_110_tools_dsssl(obj_t env_136, obj_t exp_137)
{
   return dsssl_args___args_list_201_tools_dsssl(exp_137);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tools_dsssl()
{
   return module_initialization_70_tools_error(((long) 0), "TOOLS_DSSSL");
}
