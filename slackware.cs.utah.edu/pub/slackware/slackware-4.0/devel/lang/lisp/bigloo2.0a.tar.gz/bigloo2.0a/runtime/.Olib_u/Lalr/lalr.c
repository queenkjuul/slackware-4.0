/*===========================================================================*/
/*   (Lalr/lalr.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t lalr___lalr_expand();
extern obj_t _symv__174___lalr_rewrite;
extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t get_state_218___lalr_expand(obj_t);
extern obj_t gen_lalr_code_179___lalr_gen();
extern obj_t first_state_187___lalr_global;
extern obj_t first_shift_251___lalr_global;
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t digraph___lalr_expand(obj_t);
extern obj_t filter___lalr_util(obj_t, obj_t);
static obj_t compute_lookaheads_139___lalr_expand();
extern obj_t consistent___lalr_global;
static obj_t set_fderives_66___lalr_expand();
extern obj_t assv___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t set_shift_table_58___lalr_expand();
static obj_t toplevel_init_63___lalr_expand();
extern obj_t acces_symbol_228___lalr_global;
extern obj_t nitems___lalr_global;
extern obj_t last_state_163___lalr_global;
extern obj_t rrhs___lalr_global;
extern obj_t last_shift_62___lalr_global;
static obj_t new_state_138___lalr_expand(obj_t);
static obj_t _default__79___lalr_expand = BUNSPEC;
extern obj_t fderives___lalr_global;
static obj_t generate_states_115___lalr_expand();
extern obj_t action_table_22___lalr_global;
extern obj_t laruleno___lalr_global;
static obj_t save_reductions_215___lalr_expand(obj_t, obj_t);
extern obj_t token_set_size_186___lalr_global;
static obj_t add_action_218___lalr_expand(obj_t, obj_t, obj_t);
extern obj_t warning___error(obj_t);
static obj_t traverse___lalr_expand(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t kernel_end_41___lalr_global;
static obj_t set_nullable_228___lalr_expand();
static obj_t closure___lalr_expand(obj_t);
static obj_t initialize_la_143___lalr_expand();
extern obj_t includes___lalr_global;
static obj_t _expand_lalr_grammar_175___lalr_expand(obj_t, obj_t, obj_t);
extern obj_t initialize_all_10___lalr_global();
extern obj_t gensym___r4_symbols_6_4;
extern obj_t getprop___r4_symbols_6_4(obj_t, obj_t);
static obj_t arg1772___lalr_expand(obj_t, obj_t);
extern obj_t kernel_base_67___lalr_global;
extern obj_t to_state_44___lalr_global;
static obj_t transpose___lalr_expand(obj_t, obj_t);
extern obj_t nullable___lalr_global;
extern obj_t state_table_161___lalr_global;
extern obj_t shift_symbol_29___lalr_global;
static obj_t loop___lalr_expand(obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern obj_t final_state_208___lalr_global;
static obj_t set_firsts_49___lalr_expand();
extern obj_t rlhs___lalr_global;
static obj_t pack_grammar_254___lalr_expand();
extern obj_t shift_set_155___lalr_global;
static obj_t build_rule_121___lalr_expand(long);
static obj_t set_accessing_symbol_190___lalr_expand();
static obj_t loop2_1959___lalr_expand(long, obj_t, obj_t, obj_t, obj_t, obj_t, long);
static obj_t save_shifts_66___lalr_expand(obj_t);
extern obj_t nvars___lalr_global;
static obj_t add_lookback_edge_142___lalr_expand(obj_t, obj_t, long);
extern obj_t sunion___lalr_util(obj_t, obj_t);
extern obj_t module_initialization_70___lalr_expand(long, char *);
extern obj_t module_initialization_70___evenv(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___lalr_util(long, char *);
extern obj_t module_initialization_70___lalr_gen(long, char *);
extern obj_t module_initialization_70___lalr_global(long, char *);
extern obj_t module_initialization_70___lalr_rewrite(long, char *);
extern obj_t module_initialization_70___type(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___bit(long, char *);
extern obj_t nstates___lalr_global;
extern obj_t expt___r4_numbers_6_5(obj_t, obj_t);
static obj_t allocate_storage_249___lalr_expand();
extern obj_t reduction_table_100___lalr_global;
extern obj_t state_table_size_33___lalr_global;
static obj_t initialize_f_119___lalr_expand();
static bool_t compact_action_table_234___lalr_expand();
extern obj_t clean_plist_205___lalr_rewrite();
extern obj_t max___r4_numbers_6_5(obj_t, obj_t);
extern obj_t derives___lalr_global;
static obj_t set_max_rhs_57___lalr_expand();
static obj_t new_itemsets_10___lalr_expand(obj_t);
extern obj_t la___lalr_global;
extern obj_t last_reduction_147___lalr_global;
extern obj_t nshifts___lalr_global;
extern obj_t lookback___lalr_global;
static obj_t set_reduction_table_187___lalr_expand();
extern obj_t ritem___lalr_global;
extern obj_t red_set_247___lalr_global;
extern obj_t lookaheads___lalr_global;
extern obj_t nsyms___lalr_global;
static obj_t build_relations_89___lalr_expand();
extern long list_length(obj_t);
static obj_t append_states_189___lalr_expand();
static obj_t allocate_item_sets_231___lalr_expand();
extern obj_t maxrhs___lalr_global;
extern obj_t grammar___lalr_global;
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__116___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t nrules___lalr_global;
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t initialize_states_154___lalr_expand();
extern obj_t ngotos___lalr_global;
extern obj_t nterms___lalr_global;
extern obj_t sinsert___lalr_util(obj_t, obj_t);
static bool_t set_goto_map_92___lalr_expand();
extern obj_t shift_table_147___lalr_global;
extern obj_t first_reduction_146___lalr_global;
static obj_t symbol1978___lalr_expand = BUNSPEC;
static obj_t symbol1977___lalr_expand = BUNSPEC;
static obj_t symbol1969___lalr_expand = BUNSPEC;
static obj_t symbol1968___lalr_expand = BUNSPEC;
static obj_t symbol1967___lalr_expand = BUNSPEC;
static obj_t symbol1963___lalr_expand = BUNSPEC;
static obj_t symbol1960___lalr_expand = BUNSPEC;
static obj_t set_derives_187___lalr_expand();
extern obj_t expand_lalr_grammar_224___lalr_expand(obj_t, obj_t);
extern obj_t goto_map_48___lalr_global;
static obj_t imported_modules_init_94___lalr_expand();
extern long modulo___r4_numbers_6_5_fixnum(long, long);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
static obj_t list1964___lalr_expand = BUNSPEC;
static obj_t require_initialization_114___lalr_expand = BUNSPEC;
static obj_t loop3___lalr_expand(obj_t, obj_t, long, obj_t, long, obj_t, long, long);
static obj_t loop2___lalr_expand(long, long, long, obj_t, obj_t, obj_t, obj_t, long, bool_t);
extern obj_t from_state_185___lalr_global;
extern obj_t rewrite_grammar__232___lalr_rewrite(obj_t);
static obj_t build_tables_64___lalr_expand();
extern obj_t f___lalr_global;
static obj_t cnst_init_137___lalr_expand();
static obj_t loop_1958___lalr_expand(obj_t, obj_t, obj_t, obj_t, long, long);
static obj_t loop_1957___lalr_expand(obj_t, obj_t, obj_t, obj_t, long, long, long);
static obj_t loop_1956___lalr_expand(obj_t);
static obj_t loop_1955___lalr_expand(obj_t);
extern obj_t firsts___lalr_global;
static long map_goto_153___lalr_expand(obj_t, obj_t);
extern obj_t make_vector(long, obj_t);
static obj_t *__cnst;

DEFINE_STRING( string1976___lalr_expand, string1976___lalr_expand1980, "** Shift/Reduce conflict: ", 26 );
DEFINE_STRING( string1975___lalr_expand, string1975___lalr_expand1981, "\n - shift to state ", 19 );
DEFINE_STRING( string1974___lalr_expand, string1974___lalr_expand1982, "\n - reduce rule ", 16 );
DEFINE_STRING( string1973___lalr_expand, string1973___lalr_expand1983, "** Reduce/Reduce conflict: ", 27 );
DEFINE_STRING( string1972___lalr_expand, string1972___lalr_expand1984, "\n - reduce by rule ", 19 );
DEFINE_STRING( string1971___lalr_expand, string1971___lalr_expand1985, "\non token `", 11 );
DEFINE_STRING( string1970___lalr_expand, string1970___lalr_expand1986, "'", 1 );
DEFINE_STRING( string1966___lalr_expand, string1966___lalr_expand1987, "Error in add-lookback-edge : ", 29 );
DEFINE_STRING( string1965___lalr_expand, string1965___lalr_expand1988, "Error in map-goto", 17 );
DEFINE_STRING( string1962___lalr_expand, string1962___lalr_expand1989, "Illegal form", 12 );
DEFINE_STRING( string1961___lalr_expand, string1961___lalr_expand1990, "lalr-grammar", 12 );
DEFINE_EXPORT_PROCEDURE( expand_lalr_grammar_env_33___lalr_expand, _expand_lalr_grammar_175___lalr_expand1991, _expand_lalr_grammar_175___lalr_expand, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___lalr_expand(long checksum_3006, char * from_3007)
{
if(CBOOL(require_initialization_114___lalr_expand)){
require_initialization_114___lalr_expand = BBOOL(((bool_t)0));
cnst_init_137___lalr_expand();
imported_modules_init_94___lalr_expand();
toplevel_init_63___lalr_expand();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___lalr_expand()
{
symbol1960___lalr_expand = string_to_symbol("DEFAULT");
symbol1963___lalr_expand = string_to_symbol("SYM-NO");
{
obj_t aux_3016;
aux_3016 = BINT(((long)0));
list1964___lalr_expand = MAKE_PAIR(aux_3016, BNIL);
}
symbol1967___lalr_expand = string_to_symbol("BIDON");
symbol1968___lalr_expand = string_to_symbol("-->");
symbol1969___lalr_expand = string_to_symbol("ACCEPT");
symbol1977___lalr_expand = string_to_symbol("ERROR");
return (symbol1978___lalr_expand = string_to_symbol("*ERROR*"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___lalr_expand()
{
return (_default__79___lalr_expand = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1960___lalr_expand, BEOA),
BUNSPEC);
}


/* expand-lalr-grammar */obj_t expand_lalr_grammar_224___lalr_expand(obj_t x_1, obj_t e_2)
{
{
obj_t rules_348;
if(PAIRP(x_1)){
obj_t cdr_107_0_353;
cdr_107_0_353 = CDR(x_1);
if(PAIRP(cdr_107_0_353)){
rules_348 = cdr_107_0_353;
initialize_all_10___lalr_global();
rewrite_grammar__232___lalr_rewrite(rules_348);
pack_grammar_254___lalr_expand();
set_derives_187___lalr_expand();
set_nullable_228___lalr_expand();
generate_states_115___lalr_expand();
lalr___lalr_expand();
build_tables_64___lalr_expand();
compact_action_table_234___lalr_expand();
{
obj_t code_355;
code_355 = gen_lalr_code_179___lalr_gen();
clean_plist_205___lalr_rewrite();
return PROCEDURE_ENTRY(e_2)(e_2, code_355, e_2, BEOA);
}
}
 else {
FAILURE(string1961___lalr_expand,string1962___lalr_expand,x_1);}
}
 else {
FAILURE(string1961___lalr_expand,string1962___lalr_expand,x_1);}
}
}


/* _expand-lalr-grammar */obj_t _expand_lalr_grammar_175___lalr_expand(obj_t env_2959, obj_t x_2960, obj_t e_2961)
{
return expand_lalr_grammar_224___lalr_expand(x_2960, e_2961);
}


/* pack-grammar */obj_t pack_grammar_254___lalr_expand()
{
{
long aux_3047;
aux_3047 = (long)CINT(nrules___lalr_global);
rlhs___lalr_global = make_vector(aux_3047, BFALSE);
}
{
long aux_3050;
aux_3050 = (long)CINT(nrules___lalr_global);
rrhs___lalr_global = make_vector(aux_3050, BFALSE);
}
{
long arg1057_356;
{
long z2_1490;
z2_1490 = (long)CINT(nitems___lalr_global);
arg1057_356 = (((long)1)+z2_1490);
}
ritem___lalr_global = make_vector(arg1057_356, BFALSE);
}
{
obj_t p_357;
long item_no_56_358;
long rule_no_231_359;
p_357 = grammar___lalr_global;
item_no_56_358 = ((long)0);
rule_no_231_359 = ((long)1);
loop_360:
if(NULLP(p_357)){
return BUNSPEC;
}
 else {
obj_t nt_362;
{
obj_t aux_3058;
{
obj_t aux_3059;
aux_3059 = CAR(p_357);
aux_3058 = CAR(aux_3059);
}
nt_362 = getprop___r4_symbols_6_4(aux_3058, symbol1963___lalr_expand);
}
{
obj_t prods_363;
long it_no2_41_364;
long rl_no2_158_365;
{
obj_t aux_3101;
aux_3101 = CAR(p_357);
prods_363 = CDR(aux_3101);
}
it_no2_41_364 = item_no_56_358;
rl_no2_158_365 = rule_no_231_359;
loop2_366:
if(NULLP(prods_363)){
long rule_no_231_3068;
long item_no_56_3067;
obj_t p_3065;
p_3065 = CDR(p_357);
item_no_56_3067 = it_no2_41_364;
rule_no_231_3068 = rl_no2_158_365;
rule_no_231_359 = rule_no_231_3068;
item_no_56_358 = item_no_56_3067;
p_357 = p_3065;
goto loop_360;
}
 else {
{
obj_t vector_1502;
vector_1502 = rlhs___lalr_global;
VECTOR_SET(vector_1502, rl_no2_158_365, nt_362);
}
{
obj_t vector_1505;
vector_1505 = rrhs___lalr_global;
{
obj_t aux_3070;
aux_3070 = BINT(it_no2_41_364);
VECTOR_SET(vector_1505, rl_no2_158_365, aux_3070);
}
}
{
obj_t rhs_370;
long it_no3_254_371;
{
obj_t aux_3098;
aux_3098 = CAR(prods_363);
rhs_370 = CAR(aux_3098);
}
it_no3_254_371 = it_no2_41_364;
loop3_372:
if(NULLP(rhs_370)){
{
obj_t vector_1514;
vector_1514 = ritem___lalr_global;
{
obj_t aux_3075;
{
long aux_3076;
aux_3076 = NEG(rl_no2_158_365);
aux_3075 = BINT(aux_3076);
}
VECTOR_SET(vector_1514, it_no3_254_371, aux_3075);
}
}
{
long rl_no2_158_3084;
long it_no2_41_3082;
obj_t prods_3080;
prods_3080 = CDR(prods_363);
it_no2_41_3082 = (it_no3_254_371+((long)1));
rl_no2_158_3084 = (rl_no2_158_365+((long)1));
rl_no2_158_365 = rl_no2_158_3084;
it_no2_41_364 = it_no2_41_3082;
prods_363 = prods_3080;
goto loop2_366;
}
}
 else {
obj_t sym_379;
sym_379 = CAR(rhs_370);
{
{
obj_t vector_1525;
vector_1525 = ritem___lalr_global;
{
obj_t aux_3087;
{
obj_t aux_3088;
if(PAIRP(sym_379)){
aux_3088 = CAR(sym_379);
}
 else {
aux_3088 = sym_379;
}
aux_3087 = getprop___r4_symbols_6_4(aux_3088, symbol1963___lalr_expand);
}
VECTOR_SET(vector_1525, it_no3_254_371, aux_3087);
}
}
{
long it_no3_254_3096;
obj_t rhs_3094;
rhs_3094 = CDR(rhs_370);
it_no3_254_3096 = (it_no3_254_371+((long)1));
it_no3_254_371 = it_no3_254_3096;
rhs_370 = rhs_3094;
goto loop3_372;
}
}
}
}
}
}
}
}
}


/* set-derives */obj_t set_derives_187___lalr_expand()
{
{
obj_t dset_388;
obj_t delts_389;
dset_388 = BUNSPEC;
delts_389 = BUNSPEC;
{
long arg1093_416;
{
long z1_1531;
z1_1531 = (long)CINT(nrules___lalr_global);
arg1093_416 = (z1_1531+((long)1));
}
{
obj_t aux_3106;
aux_3106 = BINT(((long)0));
delts_389 = make_vector(arg1093_416, aux_3106);
}
}
{
obj_t aux_3111;
long aux_3109;
aux_3111 = BINT(((long)-1));
aux_3109 = (long)CINT(nvars___lalr_global);
dset_388 = make_vector(aux_3109, aux_3111);
}
{
long i_390;
long j_391;
i_390 = ((long)1);
j_391 = ((long)0);
loop_392:
{
bool_t test1078_393;
{
long n2_1534;
n2_1534 = (long)CINT(nrules___lalr_global);
test1078_393 = (i_390<n2_1534);
}
if(test1078_393){
obj_t lhs_394;
{
obj_t vector_1535;
vector_1535 = rlhs___lalr_global;
lhs_394 = VECTOR_REF(vector_1535, i_390);
}
{
bool_t test_3118;
{
long aux_3119;
aux_3119 = (long)CINT(lhs_394);
test_3118 = (aux_3119>=((long)0));
}
if(test_3118){
{
obj_t arg1080_396;
{
obj_t arg1081_397;
{
obj_t vector_1539;
vector_1539 = dset_388;
{
long aux_3122;
aux_3122 = (long)CINT(lhs_394);
arg1081_397 = VECTOR_REF(vector_1539, aux_3122);
}
}
{
obj_t aux_3125;
aux_3125 = BINT(i_390);
arg1080_396 = MAKE_PAIR(aux_3125, arg1081_397);
}
}
{
obj_t vector_1543;
vector_1543 = delts_389;
VECTOR_SET(vector_1543, j_391, arg1080_396);
}
}
{
obj_t vector_1546;
vector_1546 = dset_388;
{
obj_t aux_3131;
long aux_3129;
aux_3131 = BINT(j_391);
aux_3129 = (long)CINT(lhs_394);
VECTOR_SET(vector_1546, aux_3129, aux_3131);
}
}
{
long j_3136;
long i_3134;
i_3134 = (i_390+((long)1));
j_3136 = (j_391+((long)1));
j_391 = j_3136;
i_390 = i_3134;
goto loop_392;
}
}
 else {
long i_3138;
i_3138 = (i_390+((long)1));
i_390 = i_3138;
goto loop_392;
}
}
}
 else {
BUNSPEC;
}
}
}
{
obj_t aux_3142;
long aux_3140;
aux_3142 = BINT(((long)0));
aux_3140 = (long)CINT(nvars___lalr_global);
derives___lalr_global = make_vector(aux_3140, aux_3142);
}
{
long i_401;
i_401 = ((long)0);
loop_402:
{
bool_t test1085_403;
{
long n2_1556;
n2_1556 = (long)CINT(nvars___lalr_global);
test1085_403 = (i_401<n2_1556);
}
if(test1085_403){
obj_t q_404;
{
obj_t arg1087_409;
{
obj_t vector_1557;
vector_1557 = dset_388;
arg1087_409 = VECTOR_REF(vector_1557, i_401);
}
{
obj_t j_1560;
obj_t s_1561;
j_1560 = arg1087_409;
s_1561 = BNIL;
loop2_1559:
{
bool_t test_3149;
{
long aux_3150;
aux_3150 = (long)CINT(j_1560);
test_3149 = (aux_3150<((long)0));
}
if(test_3149){
q_404 = s_1561;
}
 else {
obj_t x_1568;
{
obj_t vector_1574;
vector_1574 = delts_389;
{
long aux_3153;
aux_3153 = (long)CINT(j_1560);
x_1568 = VECTOR_REF(vector_1574, aux_3153);
}
}
{
obj_t arg1090_1569;
obj_t arg1091_1570;
arg1090_1569 = CDR(x_1568);
{
obj_t aux_3157;
aux_3157 = CAR(x_1568);
arg1091_1570 = MAKE_PAIR(aux_3157, s_1561);
}
{
obj_t s_3161;
obj_t j_3160;
j_3160 = arg1090_1569;
s_3161 = arg1091_1570;
s_1561 = s_3161;
j_1560 = j_3160;
goto loop2_1559;
}
}
}
}
}
}
{
obj_t vector_1608;
vector_1608 = derives___lalr_global;
VECTOR_SET(vector_1608, i_401, q_404);
}
{
long i_3163;
i_3163 = (i_401+((long)1));
i_401 = i_3163;
goto loop_402;
}
}
 else {
return BUNSPEC;
}
}
}
}
}


/* set-nullable */obj_t set_nullable_228___lalr_expand()
{
{
long aux_3165;
aux_3165 = (long)CINT(nvars___lalr_global);
nullable___lalr_global = make_vector(aux_3165, BFALSE);
}
{
obj_t squeue_418;
obj_t rcount_419;
obj_t rsets_420;
obj_t relts_421;
{
obj_t aux_3170;
long aux_3168;
aux_3170 = BINT(((long)0));
aux_3168 = (long)CINT(nvars___lalr_global);
squeue_418 = make_vector(aux_3168, aux_3170);
}
{
long arg1129_482;
{
long z1_1613;
z1_1613 = (long)CINT(nrules___lalr_global);
arg1129_482 = (z1_1613+((long)1));
}
{
obj_t aux_3175;
aux_3175 = BINT(((long)0));
rcount_419 = make_vector(arg1129_482, aux_3175);
}
}
{
long aux_3178;
aux_3178 = (long)CINT(nvars___lalr_global);
rsets_420 = make_vector(aux_3178, BFALSE);
}
{
long arg1131_484;
{
long arg1132_485;
{
long z1_1615;
z1_1615 = (long)CINT(nvars___lalr_global);
arg1132_485 = (z1_1615+((long)1));
}
{
long z1_1617;
z1_1617 = (long)CINT(nitems___lalr_global);
arg1131_484 = (z1_1617+arg1132_485);
}
}
relts_421 = make_vector(arg1131_484, BFALSE);
}
return loop_1957___lalr_expand(squeue_418, rsets_420, rcount_419, relts_421, ((long)0), ((long)0), ((long)0));
}
}


/* loop3 */obj_t loop3___lalr_expand(obj_t relts_2983, obj_t rsets_2982, long ruleno_2981, obj_t rcount_2980, long s2_2979, obj_t squeue_2978, long r2_445, long p2_446)
{
loop3___lalr_expand:
{
obj_t symbol_448;
{
obj_t vector_1651;
vector_1651 = ritem___lalr_global;
symbol_448 = VECTOR_REF(vector_1651, r2_445);
}
{
bool_t test_3188;
{
long aux_3189;
aux_3189 = (long)CINT(symbol_448);
test_3188 = (aux_3189>((long)0));
}
if(test_3188){
{
obj_t aux_3192;
{
long aux_3193;
{
long aux_3194;
{
obj_t aux_3195;
aux_3195 = VECTOR_REF(rcount_2980, ruleno_2981);
aux_3194 = (long)CINT(aux_3195);
}
aux_3193 = (aux_3194+((long)1));
}
aux_3192 = BINT(aux_3193);
}
VECTOR_SET(rcount_2980, ruleno_2981, aux_3192);
}
{
obj_t arg1110_453;
{
obj_t aux_3205;
obj_t aux_3201;
aux_3205 = BINT(ruleno_2981);
{
long aux_3202;
aux_3202 = (long)CINT(symbol_448);
aux_3201 = VECTOR_REF(rsets_2982, aux_3202);
}
arg1110_453 = MAKE_PAIR(aux_3201, aux_3205);
}
VECTOR_SET(relts_2983, p2_446, arg1110_453);
}
{
obj_t aux_3211;
long aux_3209;
aux_3211 = BINT(p2_446);
aux_3209 = (long)CINT(symbol_448);
VECTOR_SET(rsets_2982, aux_3209, aux_3211);
}
{
long p2_3216;
long r2_3214;
r2_3214 = (r2_445+((long)1));
p2_3216 = (p2_446+((long)1));
p2_446 = p2_3216;
r2_445 = r2_3214;
goto loop3___lalr_expand;
}
}
 else {
return loop_1957___lalr_expand(squeue_2978, rsets_2982, rcount_2980, relts_2983, (r2_445+((long)1)), s2_2979, p2_446);
}
}
}
}


/* loop2 */obj_t loop2___lalr_expand(long s2_2990, long p_2989, long r_2988, obj_t squeue_2987, obj_t rsets_2986, obj_t rcount_2985, obj_t relts_2984, long r1_435, bool_t any_tokens_152_436)
{
loop2___lalr_expand:
{
obj_t symbol_438;
{
obj_t vector_1640;
vector_1640 = ritem___lalr_global;
symbol_438 = VECTOR_REF(vector_1640, r1_435);
}
{
{
bool_t test_3221;
{
long aux_3222;
aux_3222 = (long)CINT(symbol_438);
test_3221 = (aux_3222>((long)0));
}
if(test_3221){
long arg1103_440;
bool_t arg1104_441;
arg1103_440 = (r1_435+((long)1));
if(any_tokens_152_436){
arg1104_441 = any_tokens_152_436;
}
 else {
long n1_1646;
long n2_1647;
n1_1646 = (long)CINT(symbol_438);
n2_1647 = (long)CINT(nvars___lalr_global);
arg1104_441 = (n1_1646>=n2_1647);
}
{
bool_t any_tokens_152_3231;
long r1_3230;
r1_3230 = arg1103_440;
any_tokens_152_3231 = arg1104_441;
any_tokens_152_436 = any_tokens_152_3231;
r1_435 = r1_3230;
goto loop2___lalr_expand;
}
}
 else {
if(any_tokens_152_436){
return loop_1957___lalr_expand(squeue_2987, rsets_2986, rcount_2985, relts_2984, (r1_435+((long)1)), s2_2990, p_2989);
}
 else {
long aux_3235;
{
long aux_3236;
aux_3236 = (long)CINT(symbol_438);
aux_3235 = NEG(aux_3236);
}
return loop3___lalr_expand(relts_2984, rsets_2986, aux_3235, rcount_2985, s2_2990, squeue_2987, r_2988, p_2989);
}
}
}
}
}
}


/* loop_1958 */obj_t loop_1958___lalr_expand(obj_t rsets_2994, obj_t squeue_2993, obj_t rcount_2992, obj_t relts_2991, long s1_458, long s3_459)
{
if((s1_458<s3_459)){
obj_t aux_3242;
{
long aux_3243;
{
obj_t aux_3244;
aux_3244 = VECTOR_REF(squeue_2993, s1_458);
aux_3243 = (long)CINT(aux_3244);
}
aux_3242 = VECTOR_REF(rsets_2994, aux_3243);
}
return loop2_1959___lalr_expand(s1_458, squeue_2993, rcount_2992, relts_2991, rsets_2994, aux_3242, s3_459);
}
 else {
return BUNSPEC;
}
}


/* loop_1957 */obj_t loop_1957___lalr_expand(obj_t squeue_2998, obj_t rsets_2997, obj_t rcount_2996, obj_t relts_2995, long r_422, long s2_423, long p_424)
{
loop_1957___lalr_expand:
{
obj_t _r_33_426;
{
obj_t vector_1619;
vector_1619 = ritem___lalr_global;
_r_33_426 = VECTOR_REF(vector_1619, r_422);
}
if(CBOOL(_r_33_426)){
bool_t test_3252;
{
long aux_3253;
aux_3253 = (long)CINT(_r_33_426);
test_3252 = (aux_3253<((long)0));
}
if(test_3252){
obj_t symbol_428;
{
obj_t vector_1624;
vector_1624 = rlhs___lalr_global;
{
long aux_3256;
{
long aux_3257;
aux_3257 = (long)CINT(_r_33_426);
aux_3256 = NEG(aux_3257);
}
symbol_428 = VECTOR_REF(vector_1624, aux_3256);
}
}
{
bool_t test1096_429;
{
bool_t test_3261;
{
long aux_3262;
aux_3262 = (long)CINT(symbol_428);
test_3261 = (aux_3262>=((long)0));
}
if(test_3261){
bool_t test1100_433;
{
obj_t vector_1628;
vector_1628 = nullable___lalr_global;
{
obj_t aux_3265;
{
long aux_3266;
aux_3266 = (long)CINT(symbol_428);
aux_3265 = VECTOR_REF(vector_1628, aux_3266);
}
test1100_433 = CBOOL(aux_3265);
}
}
if(test1100_433){
test1096_429 = ((bool_t)0);
}
 else {
test1096_429 = ((bool_t)1);
}
}
 else {
test1096_429 = ((bool_t)0);
}
}
if(test1096_429){
{
obj_t vector_1630;
vector_1630 = nullable___lalr_global;
{
long aux_3272;
aux_3272 = (long)CINT(symbol_428);
VECTOR_SET(vector_1630, aux_3272, BTRUE);
}
}
VECTOR_SET(squeue_2998, s2_423, symbol_428);
{
long s2_3278;
long r_3276;
r_3276 = (r_422+((long)1));
s2_3278 = (s2_423+((long)1));
s2_423 = s2_3278;
r_422 = r_3276;
goto loop_1957___lalr_expand;
}
}
 else {
return BUNSPEC;
}
}
}
 else {
return loop2___lalr_expand(s2_423, p_424, r_422, squeue_2998, rsets_2997, rcount_2996, relts_2995, r_422, ((bool_t)0));
}
}
 else {
return loop_1958___lalr_expand(rsets_2997, squeue_2998, rcount_2996, relts_2995, ((long)0), s2_423);
}
}
}


/* loop2_1959 */obj_t loop2_1959___lalr_expand(long s1_3003, obj_t squeue_3002, obj_t rcount_3001, obj_t relts_3000, obj_t rsets_2999, obj_t p_462, long s4_463)
{
if(CBOOL(p_462)){
obj_t x_467;
{
long aux_3284;
aux_3284 = (long)CINT(p_462);
x_467 = VECTOR_REF(relts_3000, aux_3284);
}
{
obj_t ruleno_468;
ruleno_468 = CDR(x_467);
{
long y_469;
{
long aux_3288;
{
obj_t aux_3289;
{
long aux_3290;
aux_3290 = (long)CINT(ruleno_468);
aux_3289 = VECTOR_REF(rcount_3001, aux_3290);
}
aux_3288 = (long)CINT(aux_3289);
}
y_469 = (aux_3288-((long)1));
}
{
{
obj_t aux_3297;
long aux_3295;
aux_3297 = BINT(y_469);
aux_3295 = (long)CINT(ruleno_468);
VECTOR_SET(rcount_3001, aux_3295, aux_3297);
}
if(_2__95___r4_numbers_6_5(BINT(y_469), BINT(((long)0)))){
obj_t symbol_471;
{
obj_t vector_1694;
vector_1694 = rlhs___lalr_global;
{
long aux_3304;
aux_3304 = (long)CINT(ruleno_468);
symbol_471 = VECTOR_REF(vector_1694, aux_3304);
}
}
{
bool_t test1119_472;
{
bool_t test_3307;
{
long aux_3308;
aux_3308 = (long)CINT(symbol_471);
test_3307 = (aux_3308>=((long)0));
}
if(test_3307){
bool_t test1124_477;
{
obj_t vector_1698;
vector_1698 = nullable___lalr_global;
{
obj_t aux_3311;
{
long aux_3312;
aux_3312 = (long)CINT(symbol_471);
aux_3311 = VECTOR_REF(vector_1698, aux_3312);
}
test1124_477 = CBOOL(aux_3311);
}
}
if(test1124_477){
test1119_472 = ((bool_t)0);
}
 else {
test1119_472 = ((bool_t)1);
}
}
 else {
test1119_472 = ((bool_t)0);
}
}
if(test1119_472){
{
obj_t vector_1700;
vector_1700 = nullable___lalr_global;
{
long aux_3318;
aux_3318 = (long)CINT(symbol_471);
VECTOR_SET(vector_1700, aux_3318, BTRUE);
}
}
VECTOR_SET(squeue_3002, s4_463, symbol_471);
loop2_1959___lalr_expand(s1_3003, squeue_3002, rcount_3001, relts_3000, rsets_2999, CAR(x_467), (s4_463+((long)1)));
}
 else {
loop2_1959___lalr_expand(s1_3003, squeue_3002, rcount_3001, relts_3000, rsets_2999, CAR(x_467), s4_463);
}
}
}
 else {
loop2_1959___lalr_expand(s1_3003, squeue_3002, rcount_3001, relts_3000, rsets_2999, CAR(x_467), s4_463);
}
}
}
}
}
 else {
BUNSPEC;
}
return loop_1958___lalr_expand(rsets_2999, squeue_3002, rcount_3001, relts_3000, (s1_3003+((long)1)), s4_463);
}


/* set-firsts */obj_t set_firsts_49___lalr_expand()
{
{
long aux_3331;
aux_3331 = (long)CINT(nvars___lalr_global);
firsts___lalr_global = make_vector(aux_3331, BNIL);
}
{
long i_487;
i_487 = ((long)0);
loop_488:
{
bool_t test1134_489;
{
long n2_1714;
n2_1714 = (long)CINT(nvars___lalr_global);
test1134_489 = (i_487<n2_1714);
}
if(test1134_489){
obj_t sp_490;
{
obj_t arg1135_492;
{
obj_t vector_1715;
vector_1715 = derives___lalr_global;
arg1135_492 = VECTOR_REF(vector_1715, i_487);
}
sp_490 = arg1135_492;
loop2_491:
if(NULLP(sp_490)){
long i_3340;
i_3340 = (i_487+((long)1));
i_487 = i_3340;
goto loop_488;
}
 else {
obj_t sym_495;
{
obj_t arg1142_501;
{
obj_t vector_1721;
vector_1721 = rrhs___lalr_global;
{
long aux_3342;
{
obj_t aux_3343;
aux_3343 = CAR(sp_490);
aux_3342 = (long)CINT(aux_3343);
}
arg1142_501 = VECTOR_REF(vector_1721, aux_3342);
}
}
{
obj_t vector_1723;
vector_1723 = ritem___lalr_global;
{
long aux_3347;
aux_3347 = (long)CINT(arg1142_501);
sym_495 = VECTOR_REF(vector_1723, aux_3347);
}
}
}
{
bool_t test1138_496;
if(_2__116___r4_numbers_6_5(BINT(((long)-1)), sym_495)){
test1138_496 = _2__116___r4_numbers_6_5(sym_495, nvars___lalr_global);
}
 else {
test1138_496 = ((bool_t)0);
}
if(test1138_496){
obj_t arg1139_497;
{
obj_t arg1140_498;
{
obj_t vector_1725;
vector_1725 = firsts___lalr_global;
arg1140_498 = VECTOR_REF(vector_1725, i_487);
}
arg1139_497 = sinsert___lalr_util(sym_495, arg1140_498);
}
{
obj_t vector_1727;
vector_1727 = firsts___lalr_global;
VECTOR_SET(vector_1727, i_487, arg1139_497);
}
}
 else {
BUNSPEC;
}
}
{
obj_t sp_3358;
sp_3358 = CDR(sp_490);
sp_490 = sp_3358;
goto loop2_491;
}
}
}
}
 else {
BUNSPEC;
}
}
}
{
bool_t continue_503;
continue_503 = ((bool_t)1);
loop_504:
if(continue_503){
long i_505;
bool_t cont_506;
i_505 = ((long)0);
cont_506 = ((bool_t)0);
loop2_507:
{
bool_t test1144_508;
{
long n2_1732;
n2_1732 = (long)CINT(nvars___lalr_global);
test1144_508 = (i_505>=n2_1732);
}
if(test1144_508){
bool_t continue_3364;
continue_3364 = cont_506;
continue_503 = continue_3364;
goto loop_504;
}
 else {
obj_t x_509;
{
obj_t vector_1733;
vector_1733 = firsts___lalr_global;
x_509 = VECTOR_REF(vector_1733, i_505);
}
{
obj_t y_510;
{
obj_t l_1736;
obj_t z_1737;
l_1736 = x_509;
z_1737 = x_509;
loop3_1735:
if(NULLP(l_1736)){
y_510 = z_1737;
}
 else {
obj_t arg1150_1744;
obj_t arg1151_1745;
arg1150_1744 = CDR(l_1736);
{
obj_t arg1152_1746;
{
obj_t vector_1751;
vector_1751 = firsts___lalr_global;
{
long aux_3369;
{
obj_t aux_3370;
aux_3370 = CAR(l_1736);
aux_3369 = (long)CINT(aux_3370);
}
arg1152_1746 = VECTOR_REF(vector_1751, aux_3369);
}
}
arg1151_1745 = sunion___lalr_util(arg1152_1746, z_1737);
}
{
obj_t z_3376;
obj_t l_3375;
l_3375 = arg1150_1744;
z_3376 = arg1151_1745;
z_1737 = z_3376;
l_1736 = l_3375;
goto loop3_1735;
}
}
}
{
if(equal__25___r4_equivalence_6_2(x_509, y_510)){
long i_3379;
i_3379 = (i_505+((long)1));
i_505 = i_3379;
goto loop2_507;
}
 else {
{
obj_t vector_1777;
vector_1777 = firsts___lalr_global;
VECTOR_SET(vector_1777, i_505, y_510);
}
{
bool_t cont_3384;
long i_3382;
i_3382 = (i_505+((long)1));
cont_3384 = ((bool_t)1);
cont_506 = cont_3384;
i_505 = i_3382;
goto loop2_507;
}
}
}
}
}
}
}
 else {
BUNSPEC;
}
}
{
long i_522;
i_522 = ((long)0);
loop_523:
{
bool_t test1154_524;
{
long n2_1783;
n2_1783 = (long)CINT(nvars___lalr_global);
test1154_524 = (i_522<n2_1783);
}
if(test1154_524){
{
obj_t arg1155_525;
{
obj_t arg1156_526;
{
obj_t vector_1784;
vector_1784 = firsts___lalr_global;
arg1156_526 = VECTOR_REF(vector_1784, i_522);
}
arg1155_525 = sinsert___lalr_util(BINT(i_522), arg1156_526);
}
{
obj_t vector_1786;
vector_1786 = firsts___lalr_global;
VECTOR_SET(vector_1786, i_522, arg1155_525);
}
}
{
long i_3392;
i_3392 = (i_522+((long)1));
i_522 = i_3392;
goto loop_523;
}
}
 else {
return BUNSPEC;
}
}
}
}


/* set-fderives */obj_t set_fderives_66___lalr_expand()
{
{
long aux_3394;
aux_3394 = (long)CINT(nvars___lalr_global);
fderives___lalr_global = make_vector(aux_3394, BFALSE);
}
set_firsts_49___lalr_expand();
{
long i_528;
i_528 = ((long)0);
loop_529:
{
bool_t test1158_530;
{
long n2_1792;
n2_1792 = (long)CINT(nvars___lalr_global);
test1158_530 = (i_528<n2_1792);
}
if(test1158_530){
obj_t x_531;
{
obj_t arg1161_536;
{
obj_t vector_1793;
vector_1793 = firsts___lalr_global;
arg1161_536 = VECTOR_REF(vector_1793, i_528);
}
{
obj_t l_1796;
obj_t fd_1797;
l_1796 = arg1161_536;
fd_1797 = BNIL;
loop2_1795:
if(NULLP(l_1796)){
x_531 = fd_1797;
}
 else {
obj_t arg1164_1804;
obj_t arg1165_1805;
arg1164_1804 = CDR(l_1796);
{
obj_t arg1166_1806;
{
obj_t vector_1811;
vector_1811 = derives___lalr_global;
{
long aux_3405;
{
obj_t aux_3406;
aux_3406 = CAR(l_1796);
aux_3405 = (long)CINT(aux_3406);
}
arg1166_1806 = VECTOR_REF(vector_1811, aux_3405);
}
}
arg1165_1805 = sunion___lalr_util(arg1166_1806, fd_1797);
}
{
obj_t fd_3412;
obj_t l_3411;
l_3411 = arg1164_1804;
fd_3412 = arg1165_1805;
fd_1797 = fd_3412;
l_1796 = l_3411;
goto loop2_1795;
}
}
}
}
{
obj_t vector_1835;
vector_1835 = fderives___lalr_global;
VECTOR_SET(vector_1835, i_528, x_531);
}
{
long i_3414;
i_3414 = (i_528+((long)1));
i_528 = i_3414;
goto loop_529;
}
}
 else {
return BUNSPEC;
}
}
}
}


/* closure */obj_t closure___lalr_expand(obj_t core_3)
{
{
obj_t ruleset_543;
ruleset_543 = BUNSPEC;
{
long aux_3416;
aux_3416 = (long)CINT(nrules___lalr_global);
ruleset_543 = make_vector(aux_3416, BFALSE);
}
{
obj_t csp_544;
csp_544 = core_3;
loop_545:
if(NULLP(csp_544)){
BUNSPEC;
}
 else {
obj_t sym_547;
{
obj_t vector_1842;
vector_1842 = ritem___lalr_global;
{
long aux_3421;
{
obj_t aux_3422;
aux_3422 = CAR(csp_544);
aux_3421 = (long)CINT(aux_3422);
}
sym_547 = VECTOR_REF(vector_1842, aux_3421);
}
}
{
bool_t test1169_548;
if(_2__116___r4_numbers_6_5(BINT(((long)-1)), sym_547)){
test1169_548 = _2__116___r4_numbers_6_5(sym_547, nvars___lalr_global);
}
 else {
test1169_548 = ((bool_t)0);
}
if(test1169_548){
obj_t arg1170_551;
{
obj_t vector_1844;
vector_1844 = fderives___lalr_global;
{
long aux_3431;
aux_3431 = (long)CINT(sym_547);
arg1170_551 = VECTOR_REF(vector_1844, aux_3431);
}
}
{
obj_t dsp_1847;
dsp_1847 = arg1170_551;
loop2_1846:
if(NULLP(dsp_1847)){
BUNSPEC;
}
 else {
{
obj_t vector_1856;
vector_1856 = ruleset_543;
{
long aux_3436;
{
obj_t aux_3437;
aux_3437 = CAR(dsp_1847);
aux_3436 = (long)CINT(aux_3437);
}
VECTOR_SET(vector_1856, aux_3436, BTRUE);
}
}
{
obj_t dsp_3441;
dsp_3441 = CDR(dsp_1847);
dsp_1847 = dsp_3441;
goto loop2_1846;
}
}
}
}
 else {
BUNSPEC;
}
}
{
obj_t csp_3443;
csp_3443 = CDR(csp_544);
csp_544 = csp_3443;
goto loop_545;
}
}
}
{
long ruleno_558;
obj_t csp_559;
obj_t itemsetv_560;
ruleno_558 = ((long)1);
csp_559 = core_3;
itemsetv_560 = BNIL;
loop_561:
{
bool_t test1178_564;
{
long n2_1881;
n2_1881 = (long)CINT(nrules___lalr_global);
test1178_564 = (ruleno_558<n2_1881);
}
if(test1178_564){
bool_t test1179_565;
{
obj_t vector_1882;
vector_1882 = ruleset_543;
{
obj_t aux_3448;
aux_3448 = VECTOR_REF(vector_1882, ruleno_558);
test1179_565 = CBOOL(aux_3448);
}
}
if(test1179_565){
obj_t itemno_566;
{
obj_t vector_1884;
vector_1884 = rrhs___lalr_global;
itemno_566 = VECTOR_REF(vector_1884, ruleno_558);
}
{
obj_t c_567;
obj_t itemsetv2_568;
c_567 = csp_559;
itemsetv2_568 = itemsetv_560;
loop2_569:
{
bool_t test_3453;
if(PAIRP(c_567)){
long aux_3460;
long aux_3456;
aux_3460 = (long)CINT(itemno_566);
{
obj_t aux_3457;
aux_3457 = CAR(c_567);
aux_3456 = (long)CINT(aux_3457);
}
test_3453 = (aux_3456<aux_3460);
}
 else {
test_3453 = ((bool_t)0);
}
if(test_3453){
obj_t arg1181_571;
obj_t arg1182_572;
arg1181_571 = CDR(c_567);
{
obj_t aux_3464;
aux_3464 = CAR(c_567);
arg1182_572 = MAKE_PAIR(aux_3464, itemsetv2_568);
}
{
obj_t itemsetv2_3468;
obj_t c_3467;
c_3467 = arg1181_571;
itemsetv2_3468 = arg1182_572;
itemsetv2_568 = itemsetv2_3468;
c_567 = c_3467;
goto loop2_569;
}
}
 else {
long arg1184_574;
obj_t arg1185_575;
arg1184_574 = (ruleno_558+((long)1));
arg1185_575 = MAKE_PAIR(itemno_566, itemsetv2_568);
{
obj_t itemsetv_3473;
obj_t csp_3472;
long ruleno_3471;
ruleno_3471 = arg1184_574;
csp_3472 = c_567;
itemsetv_3473 = arg1185_575;
itemsetv_560 = itemsetv_3473;
csp_559 = csp_3472;
ruleno_558 = ruleno_3471;
goto loop_561;
}
}
}
}
}
 else {
long ruleno_3474;
ruleno_3474 = (ruleno_558+((long)1));
ruleno_558 = ruleno_3474;
goto loop_561;
}
}
 else {
obj_t c_1901;
obj_t itemsetv2_1902;
c_1901 = csp_559;
itemsetv2_1902 = itemsetv_560;
loop2_1900:
if(PAIRP(c_1901)){
obj_t arg1190_1908;
obj_t arg1191_1909;
arg1190_1908 = CDR(c_1901);
{
obj_t aux_3479;
aux_3479 = CAR(c_1901);
arg1191_1909 = MAKE_PAIR(aux_3479, itemsetv2_1902);
}
{
obj_t itemsetv2_3483;
obj_t c_3482;
c_3482 = arg1190_1908;
itemsetv2_3483 = arg1191_1909;
itemsetv2_1902 = itemsetv2_3483;
c_1901 = c_3482;
goto loop2_1900;
}
}
 else {
return reverse___r4_pairs_and_lists_6_3(itemsetv2_1902);
}
}
}
}
}
}


/* allocate-item-sets */obj_t allocate_item_sets_231___lalr_expand()
{
{
obj_t aux_3487;
long aux_3485;
aux_3487 = BINT(((long)0));
aux_3485 = (long)CINT(nsyms___lalr_global);
kernel_base_67___lalr_global = make_vector(aux_3485, aux_3487);
}
{
long aux_3490;
aux_3490 = (long)CINT(nsyms___lalr_global);
return (kernel_end_41___lalr_global = make_vector(aux_3490, BFALSE),
BUNSPEC);
}
}


/* allocate-storage */obj_t allocate_storage_249___lalr_expand()
{
allocate_item_sets_231___lalr_expand();
{
long arg1193_586;
{
long z1_1936;
z1_1936 = (long)CINT(nrules___lalr_global);
arg1193_586 = (z1_1936+((long)1));
}
{
obj_t aux_3496;
aux_3496 = BINT(((long)0));
return (red_set_247___lalr_global = make_vector(arg1193_586, aux_3496),
BUNSPEC);
}
}
}


/* initialize-states */obj_t initialize_states_154___lalr_expand()
{
{
obj_t p_588;
{
obj_t aux_3499;
aux_3499 = BINT(((long)0));
p_588 = make_vector(((long)4), aux_3499);
}
{
obj_t aux_3502;
aux_3502 = BINT(((long)0));
VECTOR_SET(p_588, ((long)0), aux_3502);
}
VECTOR_SET(p_588, ((long)1), BFALSE);
{
obj_t aux_3506;
aux_3506 = BINT(((long)1));
VECTOR_SET(p_588, ((long)2), aux_3506);
}
VECTOR_SET(p_588, ((long)3), list1964___lalr_expand);
{
obj_t list1197_591;
list1197_591 = MAKE_PAIR(p_588, BNIL);
first_state_187___lalr_global = list1197_591;
}
last_state_163___lalr_global = first_state_187___lalr_global;
return (nstates___lalr_global = BINT(((long)1)),
BUNSPEC);
}
}


/* generate-states */obj_t generate_states_115___lalr_expand()
{
allocate_storage_249___lalr_expand();
set_fderives_66___lalr_expand();
initialize_states_154___lalr_expand();
{
obj_t this_state_201_593;
this_state_201_593 = first_state_187___lalr_global;
loop_594:
if(PAIRP(this_state_201_593)){
obj_t x_596;
x_596 = CAR(this_state_201_593);
{
obj_t is_597;
is_597 = closure___lalr_expand(VECTOR_REF(x_596, ((long)3)));
{
save_reductions_215___lalr_expand(x_596, is_597);
new_itemsets_10___lalr_expand(is_597);
append_states_189___lalr_expand();
{
bool_t test1201_598;
{
long n1_1955;
n1_1955 = (long)CINT(nshifts___lalr_global);
test1201_598 = (n1_1955>((long)0));
}
if(test1201_598){
save_shifts_66___lalr_expand(x_596);
}
 else {
BUNSPEC;
}
}
{
obj_t this_state_201_3527;
this_state_201_3527 = CDR(this_state_201_593);
this_state_201_593 = this_state_201_3527;
goto loop_594;
}
}
}
}
 else {
return BUNSPEC;
}
}
}


/* new-itemsets */obj_t new_itemsets_10___lalr_expand(obj_t itemset_4)
{
shift_symbol_29___lalr_global = BNIL;
{
long i_601;
i_601 = ((long)0);
loop_602:
{
bool_t test1204_603;
{
long n2_1959;
n2_1959 = (long)CINT(nsyms___lalr_global);
test1204_603 = (i_601<n2_1959);
}
if(test1204_603){
{
obj_t vector_1960;
vector_1960 = kernel_end_41___lalr_global;
VECTOR_SET(vector_1960, i_601, BNIL);
}
{
long i_3533;
i_3533 = (i_601+((long)1));
i_601 = i_3533;
goto loop_602;
}
}
 else {
BUNSPEC;
}
}
}
{
obj_t isp_606;
isp_606 = itemset_4;
loop_607:
if(PAIRP(isp_606)){
obj_t i_609;
i_609 = CAR(isp_606);
{
obj_t sym_610;
{
obj_t vector_1967;
vector_1967 = ritem___lalr_global;
{
long aux_3538;
aux_3538 = (long)CINT(i_609);
sym_610 = VECTOR_REF(vector_1967, aux_3538);
}
}
{
{
bool_t test_3541;
{
long aux_3542;
aux_3542 = (long)CINT(sym_610);
test_3541 = (aux_3542>=((long)0));
}
if(test_3541){
shift_symbol_29___lalr_global = sinsert___lalr_util(sym_610, shift_symbol_29___lalr_global);
{
obj_t x_612;
{
obj_t vector_1971;
vector_1971 = kernel_end_41___lalr_global;
{
long aux_3546;
aux_3546 = (long)CINT(sym_610);
x_612 = VECTOR_REF(vector_1971, aux_3546);
}
}
if(NULLP(x_612)){
{
obj_t arg1210_614;
{
obj_t aux_3551;
{
long aux_3552;
{
long aux_3553;
aux_3553 = (long)CINT(i_609);
aux_3552 = (aux_3553+((long)1));
}
aux_3551 = BINT(aux_3552);
}
arg1210_614 = MAKE_PAIR(aux_3551, x_612);
}
{
obj_t vector_1978;
vector_1978 = kernel_base_67___lalr_global;
{
long aux_3558;
aux_3558 = (long)CINT(sym_610);
VECTOR_SET(vector_1978, aux_3558, arg1210_614);
}
}
}
{
obj_t arg1213_616;
{
obj_t vector_1981;
vector_1981 = kernel_base_67___lalr_global;
{
long aux_3561;
aux_3561 = (long)CINT(sym_610);
arg1213_616 = VECTOR_REF(vector_1981, aux_3561);
}
}
{
obj_t vector_1983;
vector_1983 = kernel_end_41___lalr_global;
{
long aux_3564;
aux_3564 = (long)CINT(sym_610);
VECTOR_SET(vector_1983, aux_3564, arg1213_616);
}
}
}
}
 else {
{
obj_t arg1214_617;
{
obj_t list1217_619;
{
obj_t aux_3567;
{
long aux_3568;
{
long aux_3569;
aux_3569 = (long)CINT(i_609);
aux_3568 = (aux_3569+((long)1));
}
aux_3567 = BINT(aux_3568);
}
list1217_619 = MAKE_PAIR(aux_3567, BNIL);
}
arg1214_617 = list1217_619;
}
SET_CDR(x_612, arg1214_617);
}
{
obj_t vector_1992;
vector_1992 = kernel_end_41___lalr_global;
{
obj_t aux_3577;
long aux_3575;
aux_3577 = CDR(x_612);
aux_3575 = (long)CINT(sym_610);
VECTOR_SET(vector_1992, aux_3575, aux_3577);
}
}
}
}
}
 else {
BUNSPEC;
}
}
{
obj_t isp_3580;
isp_3580 = CDR(isp_606);
isp_606 = isp_3580;
goto loop_607;
}
}
}
}
 else {
BUNSPEC;
}
}
{
long aux_3582;
aux_3582 = list_length(shift_symbol_29___lalr_global);
return (nshifts___lalr_global = BINT(aux_3582),
BUNSPEC);
}
}


/* get-state */obj_t get_state_218___lalr_expand(obj_t sym_5)
{
{
obj_t isp_623;
{
obj_t vector_1996;
vector_1996 = kernel_base_67___lalr_global;
{
long aux_3585;
aux_3585 = (long)CINT(sym_5);
isp_623 = VECTOR_REF(vector_1996, aux_3585);
}
}
{
long n_624;
n_624 = list_length(isp_623);
{
long key_625;
{
obj_t isp1_1999;
long k_2000;
isp1_1999 = isp_623;
k_2000 = ((long)0);
loop_1998:
if(NULLP(isp1_1999)){
key_625 = modulo___r4_numbers_6_5_fixnum(k_2000, (long)CINT(state_table_size_33___lalr_global));
}
 else {
long k_3595;
obj_t isp1_3593;
isp1_3593 = CDR(isp1_1999);
{
long aux_3596;
{
obj_t aux_3597;
aux_3597 = CAR(isp1_1999);
aux_3596 = (long)CINT(aux_3597);
}
k_3595 = (k_2000+aux_3596);
}
k_2000 = k_3595;
isp1_1999 = isp1_3593;
goto loop_1998;
}
}
{
obj_t sp_626;
{
obj_t vector_2034;
vector_2034 = state_table_161___lalr_global;
sp_626 = VECTOR_REF(vector_2034, key_625);
}
{
if(NULLP(sp_626)){
obj_t x_628;
x_628 = new_state_138___lalr_expand(sym_5);
{
obj_t arg1224_629;
{
obj_t list1225_630;
list1225_630 = MAKE_PAIR(x_628, BNIL);
arg1224_629 = list1225_630;
}
{
obj_t vector_2038;
vector_2038 = state_table_161___lalr_global;
VECTOR_SET(vector_2038, key_625, arg1224_629);
}
}
return VECTOR_REF(x_628, ((long)0));
}
 else {
obj_t sp1_632;
sp1_632 = sp_626;
loop_633:
{
bool_t test_3608;
{
bool_t test_3609;
{
obj_t aux_3610;
{
obj_t aux_3612;
aux_3612 = CAR(sp1_632);
aux_3610 = VECTOR_REF(aux_3612, ((long)2));
}
test_3609 = _2__95___r4_numbers_6_5(BINT(n_624), aux_3610);
}
if(test_3609){
obj_t i1_2050;
obj_t t_2051;
i1_2050 = isp_623;
{
obj_t aux_3627;
aux_3627 = CAR(sp1_632);
t_2051 = VECTOR_REF(aux_3627, ((long)3));
}
loop2_2049:
{
bool_t test_3616;
if(PAIRP(i1_2050)){
test_3616 = _2__95___r4_numbers_6_5(CAR(i1_2050), CAR(t_2051));
}
 else {
test_3616 = ((bool_t)0);
}
if(test_3616){
obj_t t_3624;
obj_t i1_3622;
i1_3622 = CDR(i1_2050);
t_3624 = CDR(t_2051);
t_2051 = t_3624;
i1_2050 = i1_3622;
goto loop2_2049;
}
 else {
test_3608 = NULLP(i1_2050);
}
}
}
 else {
test_3608 = ((bool_t)0);
}
}
if(test_3608){
obj_t aux_3630;
aux_3630 = CAR(sp1_632);
return VECTOR_REF(aux_3630, ((long)0));
}
 else {
bool_t test_3633;
{
obj_t aux_3634;
aux_3634 = CDR(sp1_632);
test_3633 = NULLP(aux_3634);
}
if(test_3633){
obj_t x_638;
x_638 = new_state_138___lalr_expand(sym_5);
{
obj_t arg1233_639;
{
obj_t list1234_640;
list1234_640 = MAKE_PAIR(x_638, BNIL);
arg1233_639 = list1234_640;
}
SET_CDR(sp1_632, arg1233_639);
}
return VECTOR_REF(x_638, ((long)0));
}
 else {
obj_t sp1_3641;
sp1_3641 = CDR(sp1_632);
sp1_632 = sp1_3641;
goto loop_633;
}
}
}
}
}
}
}
}
}
}


/* new-state */obj_t new_state_138___lalr_expand(obj_t sym_6)
{
{
obj_t isp_667;
{
obj_t vector_2107;
vector_2107 = kernel_base_67___lalr_global;
{
long aux_3643;
aux_3643 = (long)CINT(sym_6);
isp_667 = VECTOR_REF(vector_2107, aux_3643);
}
}
{
long n_668;
n_668 = list_length(isp_667);
{
obj_t p_669;
{
obj_t aux_3647;
aux_3647 = BINT(((long)0));
p_669 = make_vector(((long)4), aux_3647);
}
{
{
obj_t obj_2111;
obj_2111 = nstates___lalr_global;
VECTOR_SET(p_669, ((long)0), obj_2111);
}
VECTOR_SET(p_669, ((long)1), sym_6);
{
bool_t test1259_670;
test1259_670 = _2__95___r4_numbers_6_5(sym_6, nvars___lalr_global);
if(test1259_670){
final_state_208___lalr_global = nstates___lalr_global;
}
 else {
BUNSPEC;
}
}
{
obj_t aux_3654;
aux_3654 = BINT(n_668);
VECTOR_SET(p_669, ((long)2), aux_3654);
}
VECTOR_SET(p_669, ((long)3), isp_667);
{
obj_t arg1260_671;
{
obj_t list1261_672;
list1261_672 = MAKE_PAIR(p_669, BNIL);
arg1260_671 = list1261_672;
}
{
obj_t pair_2122;
pair_2122 = last_state_163___lalr_global;
SET_CDR(pair_2122, arg1260_671);
}
}
{
obj_t pair_2124;
pair_2124 = last_state_163___lalr_global;
last_state_163___lalr_global = CDR(pair_2124);
}
{
long z1_2125;
z1_2125 = (long)CINT(nstates___lalr_global);
{
long aux_3662;
aux_3662 = (z1_2125+((long)1));
nstates___lalr_global = BINT(aux_3662);
}
}
return p_669;
}
}
}
}
}


/* append-states */obj_t append_states_189___lalr_expand()
{
return (shift_set_155___lalr_global = loop_1956___lalr_expand(shift_symbol_29___lalr_global),
BUNSPEC);
}


/* loop_1956 */obj_t loop_1956___lalr_expand(obj_t l_674)
{
if(NULLP(l_674)){
return BNIL;
}
 else {
obj_t arg1265_677;
obj_t arg1267_678;
arg1265_677 = get_state_218___lalr_expand(CAR(l_674));
arg1267_678 = loop_1956___lalr_expand(CDR(l_674));
return MAKE_PAIR(arg1265_677, arg1267_678);
}
}


/* save-shifts */obj_t save_shifts_66___lalr_expand(obj_t core_7)
{
{
obj_t p_681;
{
obj_t aux_3673;
aux_3673 = BINT(((long)0));
p_681 = make_vector(((long)3), aux_3673);
}
{
obj_t aux_3676;
aux_3676 = VECTOR_REF(core_7, ((long)0));
VECTOR_SET(p_681, ((long)0), aux_3676);
}
{
obj_t obj_2139;
obj_2139 = nshifts___lalr_global;
VECTOR_SET(p_681, ((long)1), obj_2139);
}
{
obj_t obj_2142;
obj_2142 = shift_set_155___lalr_global;
VECTOR_SET(p_681, ((long)2), obj_2142);
}
if(CBOOL(last_shift_62___lalr_global)){
{
obj_t arg1273_684;
{
obj_t list1274_685;
list1274_685 = MAKE_PAIR(p_681, BNIL);
arg1273_684 = list1274_685;
}
{
obj_t pair_2144;
pair_2144 = last_shift_62___lalr_global;
SET_CDR(pair_2144, arg1273_684);
}
}
{
obj_t pair_2146;
pair_2146 = last_shift_62___lalr_global;
return (last_shift_62___lalr_global = CDR(pair_2146),
BUNSPEC);
}
}
 else {
{
obj_t list1278_687;
list1278_687 = MAKE_PAIR(p_681, BNIL);
first_shift_251___lalr_global = list1278_687;
}
return (last_shift_62___lalr_global = first_shift_251___lalr_global,
BUNSPEC);
}
}
}


/* save-reductions */obj_t save_reductions_215___lalr_expand(obj_t core_8, obj_t itemset_9)
{
{
obj_t rs_689;
rs_689 = loop_1955___lalr_expand(itemset_9);
if(PAIRP(rs_689)){
obj_t p_691;
{
obj_t aux_3690;
aux_3690 = BINT(((long)0));
p_691 = make_vector(((long)3), aux_3690);
}
{
obj_t aux_3693;
aux_3693 = VECTOR_REF(core_8, ((long)0));
VECTOR_SET(p_691, ((long)0), aux_3693);
}
{
obj_t aux_3696;
{
long aux_3697;
aux_3697 = list_length(rs_689);
aux_3696 = BINT(aux_3697);
}
VECTOR_SET(p_691, ((long)1), aux_3696);
}
VECTOR_SET(p_691, ((long)2), rs_689);
if(CBOOL(last_reduction_147___lalr_global)){
{
obj_t arg1287_696;
{
obj_t list1288_697;
list1288_697 = MAKE_PAIR(p_691, BNIL);
arg1287_696 = list1288_697;
}
{
obj_t pair_2172;
pair_2172 = last_reduction_147___lalr_global;
SET_CDR(pair_2172, arg1287_696);
}
}
{
obj_t pair_2174;
pair_2174 = last_reduction_147___lalr_global;
return (last_reduction_147___lalr_global = CDR(pair_2174),
BUNSPEC);
}
}
 else {
{
obj_t list1291_699;
list1291_699 = MAKE_PAIR(p_691, BNIL);
first_reduction_146___lalr_global = list1291_699;
}
return (last_reduction_147___lalr_global = first_reduction_146___lalr_global,
BUNSPEC);
}
}
 else {
return BUNSPEC;
}
}
}


/* loop_1955 */obj_t loop_1955___lalr_expand(obj_t l_701)
{
loop_1955___lalr_expand:
if(NULLP(l_701)){
return BNIL;
}
 else {
obj_t item_704;
{
obj_t vector_2150;
vector_2150 = ritem___lalr_global;
{
long aux_3710;
{
obj_t aux_3711;
aux_3711 = CAR(l_701);
aux_3710 = (long)CINT(aux_3711);
}
item_704 = VECTOR_REF(vector_2150, aux_3710);
}
}
{
bool_t test_3715;
{
long aux_3716;
aux_3716 = (long)CINT(item_704);
test_3715 = (aux_3716<((long)0));
}
if(test_3715){
long arg1295_706;
obj_t arg1296_707;
{
long aux_3719;
aux_3719 = (long)CINT(item_704);
arg1295_706 = NEG(aux_3719);
}
arg1296_707 = loop_1955___lalr_expand(CDR(l_701));
{
obj_t aux_3724;
aux_3724 = BINT(arg1295_706);
return MAKE_PAIR(aux_3724, arg1296_707);
}
}
 else {
obj_t l_3727;
l_3727 = CDR(l_701);
l_701 = l_3727;
goto loop_1955___lalr_expand;
}
}
}
}


/* lalr */obj_t lalr___lalr_expand()
{
{
long arg1301_712;
{
long n1_2176;
n1_2176 = (long)CINT(nterms___lalr_global);
arg1301_712 = (n1_2176/((long)28));
}
{
long aux_3731;
aux_3731 = (((long)1)+arg1301_712);
token_set_size_186___lalr_global = BINT(aux_3731);
}
}
set_accessing_symbol_190___lalr_expand();
set_shift_table_58___lalr_expand();
set_reduction_table_187___lalr_expand();
set_max_rhs_57___lalr_expand();
initialize_la_143___lalr_expand();
set_goto_map_92___lalr_expand();
initialize_f_119___lalr_expand();
build_relations_89___lalr_expand();
digraph___lalr_expand(includes___lalr_global);
return compute_lookaheads_139___lalr_expand();
}


/* set-accessing-symbol */obj_t set_accessing_symbol_190___lalr_expand()
{
{
long aux_3744;
aux_3744 = (long)CINT(nstates___lalr_global);
acces_symbol_228___lalr_global = make_vector(aux_3744, BFALSE);
}
{
obj_t l_713;
l_713 = first_state_187___lalr_global;
loop_714:
if(PAIRP(l_713)){
obj_t x_716;
x_716 = CAR(l_713);
{
obj_t vector_2186;
vector_2186 = acces_symbol_228___lalr_global;
{
obj_t aux_3754;
long aux_3750;
aux_3754 = VECTOR_REF(x_716, ((long)1));
{
obj_t aux_3751;
aux_3751 = VECTOR_REF(x_716, ((long)0));
aux_3750 = (long)CINT(aux_3751);
}
VECTOR_SET(vector_2186, aux_3750, aux_3754);
}
}
{
obj_t l_3757;
l_3757 = CDR(l_713);
l_713 = l_3757;
goto loop_714;
}
}
 else {
return BUNSPEC;
}
}
}


/* set-shift-table */obj_t set_shift_table_58___lalr_expand()
{
{
long aux_3759;
aux_3759 = (long)CINT(nstates___lalr_global);
shift_table_147___lalr_global = make_vector(aux_3759, BFALSE);
}
{
obj_t l_720;
l_720 = first_shift_251___lalr_global;
loop_721:
if(PAIRP(l_720)){
obj_t x_723;
x_723 = CAR(l_720);
{
obj_t vector_2194;
vector_2194 = shift_table_147___lalr_global;
{
long aux_3765;
{
obj_t aux_3766;
aux_3766 = VECTOR_REF(x_723, ((long)0));
aux_3765 = (long)CINT(aux_3766);
}
VECTOR_SET(vector_2194, aux_3765, x_723);
}
}
{
obj_t l_3770;
l_3770 = CDR(l_720);
l_720 = l_3770;
goto loop_721;
}
}
 else {
return BUNSPEC;
}
}
}


/* set-reduction-table */obj_t set_reduction_table_187___lalr_expand()
{
{
long aux_3772;
aux_3772 = (long)CINT(nstates___lalr_global);
reduction_table_100___lalr_global = make_vector(aux_3772, BFALSE);
}
{
obj_t l_726;
l_726 = first_reduction_146___lalr_global;
loop_727:
if(PAIRP(l_726)){
obj_t x_729;
x_729 = CAR(l_726);
{
obj_t vector_2202;
vector_2202 = reduction_table_100___lalr_global;
{
long aux_3778;
{
obj_t aux_3779;
aux_3779 = VECTOR_REF(x_729, ((long)0));
aux_3778 = (long)CINT(aux_3779);
}
VECTOR_SET(vector_2202, aux_3778, x_729);
}
}
{
obj_t l_3783;
l_3783 = CDR(l_726);
l_726 = l_3783;
goto loop_727;
}
}
 else {
return BUNSPEC;
}
}
}


/* set-max-rhs */obj_t set_max_rhs_57___lalr_expand()
{
{
long p_732;
obj_t curmax_733;
long length_734;
p_732 = ((long)0);
curmax_733 = BINT(((long)0));
length_734 = ((long)0);
loop_735:
{
obj_t x_736;
{
obj_t vector_2206;
vector_2206 = ritem___lalr_global;
x_736 = VECTOR_REF(vector_2206, p_732);
}
if(CBOOL(x_736)){
bool_t test_3788;
{
long aux_3789;
aux_3789 = (long)CINT(x_736);
test_3788 = (aux_3789>=((long)0));
}
if(test_3788){
long length_3794;
long p_3792;
p_3792 = (p_732+((long)1));
length_3794 = (length_734+((long)1));
length_734 = length_3794;
p_732 = p_3792;
goto loop_735;
}
 else {
long arg1322_740;
obj_t arg1323_741;
arg1322_740 = (p_732+((long)1));
{
obj_t list1325_743;
{
obj_t aux_3797;
aux_3797 = BINT(length_734);
list1325_743 = MAKE_PAIR(aux_3797, BNIL);
}
arg1323_741 = max___r4_numbers_6_5(curmax_733, list1325_743);
}
{
long length_3803;
obj_t curmax_3802;
long p_3801;
p_3801 = arg1322_740;
curmax_3802 = arg1323_741;
length_3803 = ((long)0);
length_734 = length_3803;
curmax_733 = curmax_3802;
p_732 = p_3801;
goto loop_735;
}
}
}
 else {
return (maxrhs___lalr_global = curmax_733,
BUNSPEC);
}
}
}
}


/* initialize-la */obj_t initialize_la_143___lalr_expand()
{
{
long aux_3805;
aux_3805 = (long)CINT(nstates___lalr_global);
consistent___lalr_global = make_vector(aux_3805, BFALSE);
}
{
long arg1328_746;
{
long z1_2216;
z1_2216 = (long)CINT(nstates___lalr_global);
arg1328_746 = (z1_2216+((long)1));
}
lookaheads___lalr_global = make_vector(arg1328_746, BFALSE);
}
{
long count_747;
long i_748;
count_747 = ((long)0);
i_748 = ((long)0);
loop_749:
{
bool_t test1329_750;
{
long n2_2219;
n2_2219 = (long)CINT(nstates___lalr_global);
test1329_750 = (i_748<n2_2219);
}
if(test1329_750){
{
obj_t vector_2220;
vector_2220 = lookaheads___lalr_global;
{
obj_t aux_3814;
aux_3814 = BINT(count_747);
VECTOR_SET(vector_2220, i_748, aux_3814);
}
}
{
obj_t rp_751;
obj_t sp_752;
{
obj_t vector_2223;
vector_2223 = reduction_table_100___lalr_global;
rp_751 = VECTOR_REF(vector_2223, i_748);
}
{
obj_t vector_2225;
vector_2225 = shift_table_147___lalr_global;
sp_752 = VECTOR_REF(vector_2225, i_748);
}
{
bool_t test1330_753;
if(CBOOL(rp_751)){
bool_t _ortest_1033_758;
{
long aux_3821;
{
obj_t aux_3822;
aux_3822 = VECTOR_REF(rp_751, ((long)1));
aux_3821 = (long)CINT(aux_3822);
}
_ortest_1033_758 = (aux_3821>((long)1));
}
if(_ortest_1033_758){
test1330_753 = _ortest_1033_758;
}
 else {
if(CBOOL(sp_752)){
bool_t test1335_760;
{
obj_t arg1337_761;
{
obj_t vector_2245;
vector_2245 = acces_symbol_228___lalr_global;
{
long aux_3829;
{
obj_t aux_3830;
{
obj_t l_2234;
l_2234 = VECTOR_REF(sp_752, ((long)2));
last_2233:
{
bool_t test_3831;
{
obj_t aux_3832;
aux_3832 = CDR(l_2234);
test_3831 = NULLP(aux_3832);
}
if(test_3831){
aux_3830 = CAR(l_2234);
}
 else {
obj_t l_3836;
l_3836 = CDR(l_2234);
l_2234 = l_3836;
goto last_2233;
}
}
}
aux_3829 = (long)CINT(aux_3830);
}
arg1337_761 = VECTOR_REF(vector_2245, aux_3829);
}
}
{
long n1_2247;
long n2_2248;
n1_2247 = (long)CINT(arg1337_761);
n2_2248 = (long)CINT(nvars___lalr_global);
test1335_760 = (n1_2247<n2_2248);
}
}
if(test1335_760){
test1330_753 = ((bool_t)0);
}
 else {
test1330_753 = ((bool_t)1);
}
}
 else {
test1330_753 = ((bool_t)0);
}
}
}
 else {
test1330_753 = ((bool_t)0);
}
if(test1330_753){
long i_3852;
long count_3846;
{
long aux_3847;
{
obj_t aux_3848;
aux_3848 = VECTOR_REF(rp_751, ((long)1));
aux_3847 = (long)CINT(aux_3848);
}
count_3846 = (count_747+aux_3847);
}
i_3852 = (i_748+((long)1));
i_748 = i_3852;
count_747 = count_3846;
goto loop_749;
}
 else {
{
obj_t vector_2255;
vector_2255 = consistent___lalr_global;
VECTOR_SET(vector_2255, i_748, BTRUE);
}
{
long i_3855;
i_3855 = (i_748+((long)1));
i_748 = i_3855;
goto loop_749;
}
}
}
}
}
 else {
{
obj_t vector_2260;
long k_2261;
obj_t obj_2262;
vector_2260 = lookaheads___lalr_global;
k_2261 = (long)CINT(nstates___lalr_global);
obj_2262 = BINT(count_747);
VECTOR_SET(vector_2260, k_2261, obj_2262);
}
{
obj_t c_766;
{
obj_t list1350_774;
{
obj_t aux_3860;
aux_3860 = BINT(((long)1));
list1350_774 = MAKE_PAIR(aux_3860, BNIL);
}
c_766 = max___r4_numbers_6_5(BINT(count_747), list1350_774);
}
{
long aux_3865;
aux_3865 = (long)CINT(c_766);
la___lalr_global = make_vector(aux_3865, BFALSE);
}
{
long j_768;
j_768 = ((long)0);
do_loop__1035_241_773:
if(_2__95___r4_numbers_6_5(BINT(j_768), c_766)){
((bool_t)0);
}
 else {
{
obj_t arg1347_771;
{
obj_t aux_3873;
long aux_3871;
aux_3873 = BINT(((long)0));
aux_3871 = (long)CINT(token_set_size_186___lalr_global);
arg1347_771 = make_vector(aux_3871, aux_3873);
}
{
obj_t vector_2263;
vector_2263 = la___lalr_global;
VECTOR_SET(vector_2263, j_768, arg1347_771);
}
}
{
long j_3877;
j_3877 = (j_768+((long)1));
j_768 = j_3877;
goto do_loop__1035_241_773;
}
}
}
{
obj_t aux_3881;
long aux_3879;
aux_3881 = BINT(((long)-1));
aux_3879 = (long)CINT(c_766);
laruleno___lalr_global = make_vector(aux_3879, aux_3881);
}
{
long aux_3884;
aux_3884 = (long)CINT(c_766);
lookback___lalr_global = make_vector(aux_3884, BFALSE);
}
}
{
long i_777;
long np_778;
i_777 = ((long)0);
np_778 = ((long)0);
loop_779:
{
bool_t test1353_780;
{
long n2_2269;
n2_2269 = (long)CINT(nstates___lalr_global);
test1353_780 = (i_777<n2_2269);
}
if(test1353_780){
bool_t test1354_781;
{
obj_t vector_2270;
vector_2270 = consistent___lalr_global;
{
obj_t aux_3890;
aux_3890 = VECTOR_REF(vector_2270, i_777);
test1354_781 = CBOOL(aux_3890);
}
}
if(test1354_781){
long i_3894;
i_3894 = (i_777+((long)1));
i_777 = i_3894;
goto loop_779;
}
 else {
obj_t rp_783;
{
obj_t vector_2274;
vector_2274 = reduction_table_100___lalr_global;
rp_783 = VECTOR_REF(vector_2274, i_777);
}
if(CBOOL(rp_783)){
obj_t j_784;
long np2_785;
j_784 = VECTOR_REF(rp_783, ((long)2));
np2_785 = np_778;
loop2_786:
if(NULLP(j_784)){
long np_3903;
long i_3901;
i_3901 = (i_777+((long)1));
np_3903 = np2_785;
np_778 = np_3903;
i_777 = i_3901;
goto loop_779;
}
 else {
{
obj_t vector_2282;
vector_2282 = laruleno___lalr_global;
{
obj_t aux_3904;
aux_3904 = CAR(j_784);
VECTOR_SET(vector_2282, np2_785, aux_3904);
}
}
{
long np2_3909;
obj_t j_3907;
j_3907 = CDR(j_784);
np2_3909 = (np2_785+((long)1));
np2_785 = np2_3909;
j_784 = j_3907;
goto loop2_786;
}
}
}
 else {
long i_3912;
i_3912 = (i_777+((long)1));
i_777 = i_3912;
goto loop_779;
}
}
}
 else {
return BUNSPEC;
}
}
}
}
}
}
}


/* set-goto-map */bool_t set_goto_map_92___lalr_expand()
{
{
long arg1373_800;
{
long z1_2305;
z1_2305 = (long)CINT(nvars___lalr_global);
arg1373_800 = (z1_2305+((long)1));
}
{
obj_t aux_3916;
aux_3916 = BINT(((long)0));
goto_map_48___lalr_global = make_vector(arg1373_800, aux_3916);
}
}
{
obj_t temp_map_101_802;
{
long arg1415_859;
{
long z1_2307;
z1_2307 = (long)CINT(nvars___lalr_global);
arg1415_859 = (z1_2307+((long)1));
}
{
obj_t aux_3921;
aux_3921 = BINT(((long)0));
temp_map_101_802 = make_vector(arg1415_859, aux_3921);
}
}
{
long ng_803;
obj_t sp_804;
ng_803 = ((long)0);
sp_804 = first_shift_251___lalr_global;
loop_805:
if(PAIRP(sp_804)){
obj_t i_807;
long ng2_808;
{
obj_t aux_3957;
{
obj_t aux_3958;
aux_3958 = CAR(sp_804);
aux_3957 = VECTOR_REF(aux_3958, ((long)2));
}
i_807 = reverse___r4_pairs_and_lists_6_3(aux_3957);
}
ng2_808 = ng_803;
loop2_809:
if(PAIRP(i_807)){
obj_t symbol_815;
{
obj_t vector_2315;
vector_2315 = acces_symbol_228___lalr_global;
{
long aux_3928;
{
obj_t aux_3929;
aux_3929 = CAR(i_807);
aux_3928 = (long)CINT(aux_3929);
}
symbol_815 = VECTOR_REF(vector_2315, aux_3928);
}
}
{
bool_t test1385_816;
{
long n1_2317;
long n2_2318;
n1_2317 = (long)CINT(symbol_815);
n2_2318 = (long)CINT(nvars___lalr_global);
test1385_816 = (n1_2317<n2_2318);
}
if(test1385_816){
{
long arg1387_817;
{
obj_t arg1389_819;
{
obj_t vector_2319;
vector_2319 = goto_map_48___lalr_global;
{
long aux_3937;
aux_3937 = (long)CINT(symbol_815);
arg1389_819 = VECTOR_REF(vector_2319, aux_3937);
}
}
{
long aux_3940;
aux_3940 = (long)CINT(arg1389_819);
arg1387_817 = (((long)1)+aux_3940);
}
}
{
obj_t vector_2323;
vector_2323 = goto_map_48___lalr_global;
{
obj_t aux_3945;
long aux_3943;
aux_3945 = BINT(arg1387_817);
aux_3943 = (long)CINT(symbol_815);
VECTOR_SET(vector_2323, aux_3943, aux_3945);
}
}
}
{
long ng2_3950;
obj_t i_3948;
i_3948 = CDR(i_807);
ng2_3950 = (ng2_808+((long)1));
ng2_808 = ng2_3950;
i_807 = i_3948;
goto loop2_809;
}
}
 else {
obj_t i_3952;
i_3952 = CDR(i_807);
i_807 = i_3952;
goto loop2_809;
}
}
}
 else {
obj_t sp_3955;
long ng_3954;
ng_3954 = ng2_808;
sp_3955 = CDR(sp_804);
sp_804 = sp_3955;
ng_803 = ng_3954;
goto loop_805;
}
}
 else {
long k_825;
long i_826;
k_825 = ((long)0);
i_826 = ((long)0);
loop_827:
{
bool_t test1396_828;
{
long n2_2332;
n2_2332 = (long)CINT(nvars___lalr_global);
test1396_828 = (i_826<n2_2332);
}
if(test1396_828){
{
obj_t aux_3965;
aux_3965 = BINT(k_825);
VECTOR_SET(temp_map_101_802, i_826, aux_3965);
}
{
long arg1397_829;
{
obj_t arg1399_831;
{
obj_t vector_2336;
vector_2336 = goto_map_48___lalr_global;
arg1399_831 = VECTOR_REF(vector_2336, i_826);
}
{
long aux_3969;
aux_3969 = (long)CINT(arg1399_831);
arg1397_829 = (k_825+aux_3969);
}
}
{
long i_3973;
long k_3972;
k_3972 = arg1397_829;
i_3973 = (i_826+((long)1));
i_826 = i_3973;
k_825 = k_3972;
goto loop_827;
}
}
}
 else {
{
long i_833;
i_833 = ((long)0);
do_loop__1036_79_838:
{
bool_t test1401_835;
{
long n2_2343;
n2_2343 = (long)CINT(nvars___lalr_global);
test1401_835 = (i_833>=n2_2343);
}
if(test1401_835){
((bool_t)0);
}
 else {
{
obj_t vector_2346;
vector_2346 = goto_map_48___lalr_global;
{
obj_t aux_3978;
aux_3978 = VECTOR_REF(temp_map_101_802, i_833);
VECTOR_SET(vector_2346, i_833, aux_3978);
}
}
{
long i_3981;
i_3981 = (i_833+((long)1));
i_833 = i_3981;
goto do_loop__1036_79_838;
}
}
}
}
ngotos___lalr_global = BINT(ng_803);
{
obj_t vector_2351;
long k_2352;
obj_t obj_2353;
vector_2351 = goto_map_48___lalr_global;
k_2352 = (long)CINT(nvars___lalr_global);
obj_2353 = ngotos___lalr_global;
VECTOR_SET(vector_2351, k_2352, obj_2353);
}
{
long k_2355;
obj_t obj_2356;
k_2355 = (long)CINT(nvars___lalr_global);
obj_2356 = ngotos___lalr_global;
VECTOR_SET(temp_map_101_802, k_2355, obj_2356);
}
{
long aux_3988;
aux_3988 = (long)CINT(ngotos___lalr_global);
from_state_185___lalr_global = make_vector(aux_3988, BFALSE);
}
{
long aux_3991;
aux_3991 = (long)CINT(ngotos___lalr_global);
to_state_44___lalr_global = make_vector(aux_3991, BFALSE);
}
{
obj_t sp_840;
sp_840 = first_shift_251___lalr_global;
do_loop__1037_46_858:
if(NULLP(sp_840)){
return ((bool_t)0);
}
 else {
{
obj_t x_843;
x_843 = CAR(sp_840);
{
obj_t state1_844;
state1_844 = VECTOR_REF(x_843, ((long)0));
{
{
obj_t i_847;
i_847 = VECTOR_REF(x_843, ((long)2));
do_loop__1038_60_856:
if(NULLP(i_847)){
((bool_t)0);
}
 else {
{
obj_t state2_850;
state2_850 = CAR(i_847);
{
obj_t symbol_851;
{
obj_t vector_2365;
vector_2365 = acces_symbol_228___lalr_global;
{
long aux_4001;
aux_4001 = (long)CINT(state2_850);
symbol_851 = VECTOR_REF(vector_2365, aux_4001);
}
}
{
{
bool_t test1410_852;
{
long n1_2367;
long n2_2368;
n1_2367 = (long)CINT(symbol_851);
n2_2368 = (long)CINT(nvars___lalr_global);
test1410_852 = (n1_2367<n2_2368);
}
if(test1410_852){
obj_t k_853;
{
long aux_4008;
aux_4008 = (long)CINT(symbol_851);
k_853 = VECTOR_REF(temp_map_101_802, aux_4008);
}
{
obj_t aux_4013;
long aux_4011;
{
long aux_4014;
{
long aux_4015;
aux_4015 = (long)CINT(k_853);
aux_4014 = (aux_4015+((long)1));
}
aux_4013 = BINT(aux_4014);
}
aux_4011 = (long)CINT(symbol_851);
VECTOR_SET(temp_map_101_802, aux_4011, aux_4013);
}
{
obj_t vector_2376;
vector_2376 = from_state_185___lalr_global;
{
long aux_4020;
aux_4020 = (long)CINT(k_853);
VECTOR_SET(vector_2376, aux_4020, state1_844);
}
}
{
obj_t vector_2379;
vector_2379 = to_state_44___lalr_global;
{
long aux_4023;
aux_4023 = (long)CINT(k_853);
VECTOR_SET(vector_2379, aux_4023, state2_850);
}
}
}
 else {
BUNSPEC;
}
}
}
}
}
{
obj_t i_4026;
i_4026 = CDR(i_847);
i_847 = i_4026;
goto do_loop__1038_60_856;
}
}
}
}
}
}
{
obj_t sp_4029;
sp_4029 = CDR(sp_840);
sp_840 = sp_4029;
goto do_loop__1037_46_858;
}
}
}
}
}
}
}
}
}


/* map-goto */long map_goto_153___lalr_expand(obj_t state_10, obj_t symbol_11)
{
{
obj_t low_861;
long high_862;
{
obj_t arg1417_864;
long arg1418_865;
{
obj_t vector_2384;
vector_2384 = goto_map_48___lalr_global;
{
long aux_4031;
aux_4031 = (long)CINT(symbol_11);
arg1417_864 = VECTOR_REF(vector_2384, aux_4031);
}
}
{
obj_t arg1419_866;
{
obj_t vector_2388;
vector_2388 = goto_map_48___lalr_global;
{
long aux_4034;
{
long aux_4035;
aux_4035 = (long)CINT(symbol_11);
aux_4034 = (aux_4035+((long)1));
}
arg1419_866 = VECTOR_REF(vector_2388, aux_4034);
}
}
{
long aux_4039;
aux_4039 = (long)CINT(arg1419_866);
arg1418_865 = (aux_4039-((long)1));
}
}
low_861 = arg1417_864;
high_862 = arg1418_865;
loop_863:
{
bool_t test_4042;
{
long aux_4043;
aux_4043 = (long)CINT(low_861);
test_4042 = (aux_4043>high_862);
}
if(test_4042){
{
obj_t arg1426_870;
{
obj_t list1428_872;
{
obj_t arg1432_874;
{
obj_t arg1433_875;
arg1433_875 = MAKE_PAIR(symbol_11, BNIL);
arg1432_874 = MAKE_PAIR(state_10, arg1433_875);
}
list1428_872 = MAKE_PAIR(string1965___lalr_expand, arg1432_874);
}
arg1426_870 = list1428_872;
}
display___r4_output_6_10_3(arg1426_870, BNIL);
}
newline___r4_output_6_10_3(BNIL);
return ((long)0);
}
 else {
long middle_878;
{
long aux_4051;
{
long aux_4052;
aux_4052 = (long)CINT(low_861);
aux_4051 = (aux_4052+high_862);
}
middle_878 = (aux_4051/((long)2));
}
{
obj_t s_879;
{
obj_t vector_2399;
vector_2399 = from_state_185___lalr_global;
s_879 = VECTOR_REF(vector_2399, middle_878);
}
{
if(_2__95___r4_numbers_6_5(s_879, state_10)){
return middle_878;
}
 else {
bool_t test_4059;
{
long aux_4062;
long aux_4060;
aux_4062 = (long)CINT(state_10);
aux_4060 = (long)CINT(s_879);
test_4059 = (aux_4060<aux_4062);
}
if(test_4059){
{
obj_t low_4065;
{
long aux_4066;
aux_4066 = (middle_878+((long)1));
low_4065 = BINT(aux_4066);
}
low_861 = low_4065;
goto loop_863;
}
}
 else {
{
long high_4069;
high_4069 = (middle_878-((long)1));
high_862 = high_4069;
goto loop_863;
}
}
}
}
}
}
}
}
}
}


/* initialize-f */obj_t initialize_f_119___lalr_expand()
{
{
long aux_4071;
aux_4071 = (long)CINT(ngotos___lalr_global);
f___lalr_global = make_vector(aux_4071, BFALSE);
}
{
long i_887;
i_887 = ((long)0);
do_loop__1039_66_892:
{
bool_t test1446_889;
test1446_889 = _2__95___r4_numbers_6_5(BINT(i_887), ngotos___lalr_global);
if(test1446_889){
((bool_t)0);
}
 else {
{
obj_t arg1448_890;
{
obj_t aux_4079;
long aux_4077;
aux_4079 = BINT(((long)0));
aux_4077 = (long)CINT(token_set_size_186___lalr_global);
arg1448_890 = make_vector(aux_4077, aux_4079);
}
{
obj_t vector_2407;
vector_2407 = f___lalr_global;
VECTOR_SET(vector_2407, i_887, arg1448_890);
}
}
{
long i_4083;
i_4083 = (i_887+((long)1));
i_887 = i_4083;
goto do_loop__1039_66_892;
}
}
}
}
{
obj_t reads_893;
{
long aux_4085;
aux_4085 = (long)CINT(ngotos___lalr_global);
reads_893 = make_vector(aux_4085, BFALSE);
}
{
long i_894;
long rowp_895;
i_894 = ((long)0);
rowp_895 = ((long)0);
loop_896:
{
bool_t test1450_897;
{
long n2_2413;
n2_2413 = (long)CINT(ngotos___lalr_global);
test1450_897 = (i_894<n2_2413);
}
if(test1450_897){
obj_t rowf_898;
{
obj_t vector_2414;
vector_2414 = f___lalr_global;
rowf_898 = VECTOR_REF(vector_2414, rowp_895);
}
{
obj_t stateno_899;
{
obj_t vector_2416;
vector_2416 = to_state_44___lalr_global;
stateno_899 = VECTOR_REF(vector_2416, i_894);
}
{
obj_t sp_900;
{
obj_t vector_2418;
vector_2418 = shift_table_147___lalr_global;
{
long aux_4093;
aux_4093 = (long)CINT(stateno_899);
sp_900 = VECTOR_REF(vector_2418, aux_4093);
}
}
{
if(CBOOL(sp_900)){
obj_t j_901;
obj_t edges_902;
j_901 = VECTOR_REF(sp_900, ((long)2));
edges_902 = BNIL;
loop2_903:
if(PAIRP(j_901)){
obj_t symbol_907;
{
obj_t vector_2424;
vector_2424 = acces_symbol_228___lalr_global;
{
long aux_4100;
{
obj_t aux_4101;
aux_4101 = CAR(j_901);
aux_4100 = (long)CINT(aux_4101);
}
symbol_907 = VECTOR_REF(vector_2424, aux_4100);
}
}
{
bool_t test1456_908;
{
long n1_2426;
long n2_2427;
n1_2426 = (long)CINT(symbol_907);
n2_2427 = (long)CINT(nvars___lalr_global);
test1456_908 = (n1_2426<n2_2427);
}
if(test1456_908){
bool_t test1457_909;
{
obj_t vector_2428;
vector_2428 = nullable___lalr_global;
{
obj_t aux_4109;
{
long aux_4110;
aux_4110 = (long)CINT(symbol_907);
aux_4109 = VECTOR_REF(vector_2428, aux_4110);
}
test1457_909 = CBOOL(aux_4109);
}
}
if(test1457_909){
obj_t arg1458_910;
obj_t arg1460_911;
arg1458_910 = CDR(j_901);
{
long arg1461_912;
arg1461_912 = map_goto_153___lalr_expand(stateno_899, symbol_907);
{
obj_t aux_4117;
aux_4117 = BINT(arg1461_912);
arg1460_911 = MAKE_PAIR(aux_4117, edges_902);
}
}
{
obj_t edges_4121;
obj_t j_4120;
j_4120 = arg1458_910;
edges_4121 = arg1460_911;
edges_902 = edges_4121;
j_901 = j_4120;
goto loop2_903;
}
}
 else {
obj_t j_4122;
j_4122 = CDR(j_901);
j_901 = j_4122;
goto loop2_903;
}
}
 else {
{
long x_914;
obj_t y_915;
{
long arg1466_918;
{
long z1_2434;
long z2_2435;
z1_2434 = (long)CINT(symbol_907);
z2_2435 = (long)CINT(nvars___lalr_global);
arg1466_918 = (z1_2434-z2_2435);
}
x_914 = (arg1466_918/((long)28));
}
{
long arg1469_921;
{
long arg1470_922;
{
long z1_2438;
long z2_2439;
z1_2438 = (long)CINT(symbol_907);
z2_2439 = (long)CINT(nvars___lalr_global);
arg1470_922 = (z1_2438-z2_2439);
}
arg1469_921 = (arg1470_922%((long)28));
}
y_915 = expt___r4_numbers_6_5(BINT(((long)2)), BINT(arg1469_921));
}
{
obj_t aux_4135;
{
long aux_4136;
{
long aux_4141;
long aux_4137;
aux_4141 = (long)CINT(y_915);
{
obj_t aux_4138;
aux_4138 = VECTOR_REF(rowf_898, x_914);
aux_4137 = (long)CINT(aux_4138);
}
aux_4136 = (aux_4137 | aux_4141);
}
aux_4135 = BINT(aux_4136);
}
VECTOR_SET(rowf_898, x_914, aux_4135);
}
}
{
obj_t j_4146;
j_4146 = CDR(j_901);
j_901 = j_4146;
goto loop2_903;
}
}
}
}
 else {
if(PAIRP(edges_902)){
obj_t x_3004;
{
obj_t aux_4150;
aux_4150 = reverse___r4_pairs_and_lists_6_3(edges_902);
x_3004 = VECTOR_SET(reads_893, i_894, aux_4150);
}
BUNSPEC;
}
 else {
BUNSPEC;
}
}
}
 else {
BUNSPEC;
}
{
long rowp_4156;
long i_4154;
i_4154 = (i_894+((long)1));
rowp_4156 = (rowp_895+((long)1));
rowp_895 = rowp_4156;
i_894 = i_4154;
goto loop_896;
}
}
}
}
}
 else {
BUNSPEC;
}
}
}
return digraph___lalr_expand(reads_893);
}
}


/* add-lookback-edge */obj_t add_lookback_edge_142___lalr_expand(obj_t stateno_12, obj_t ruleno_13, long gotono_14)
{
{
obj_t k_930;
{
obj_t vector_2460;
vector_2460 = lookaheads___lalr_global;
{
long aux_4159;
{
long aux_4160;
aux_4160 = (long)CINT(stateno_12);
aux_4159 = (aux_4160+((long)1));
}
k_930 = VECTOR_REF(vector_2460, aux_4159);
}
}
{
bool_t found_931;
obj_t i_932;
{
obj_t arg1479_934;
{
obj_t vector_2462;
vector_2462 = lookaheads___lalr_global;
{
long aux_4164;
aux_4164 = (long)CINT(stateno_12);
arg1479_934 = VECTOR_REF(vector_2462, aux_4164);
}
}
found_931 = ((bool_t)0);
i_932 = arg1479_934;
loop_933:
{
bool_t test_4167;
if(found_931){
test_4167 = ((bool_t)0);
}
 else {
long aux_4171;
long aux_4169;
aux_4171 = (long)CINT(k_930);
aux_4169 = (long)CINT(i_932);
test_4167 = (aux_4169<aux_4171);
}
if(test_4167){
bool_t test1481_936;
{
obj_t arg1484_938;
{
obj_t vector_2466;
vector_2466 = laruleno___lalr_global;
{
long aux_4174;
aux_4174 = (long)CINT(i_932);
arg1484_938 = VECTOR_REF(vector_2466, aux_4174);
}
}
test1481_936 = _2__95___r4_numbers_6_5(arg1484_938, ruleno_13);
}
if(test1481_936){
bool_t found_4179;
found_4179 = ((bool_t)1);
found_931 = found_4179;
goto loop_933;
}
 else {
obj_t i_4180;
{
long aux_4181;
{
long aux_4182;
aux_4182 = (long)CINT(i_932);
aux_4181 = (aux_4182+((long)1));
}
i_4180 = BINT(aux_4181);
}
i_932 = i_4180;
goto loop_933;
}
}
 else {
if(found_931){
obj_t arg1485_939;
{
obj_t arg1486_940;
{
obj_t vector_2470;
vector_2470 = lookback___lalr_global;
{
long aux_4187;
aux_4187 = (long)CINT(i_932);
arg1486_940 = VECTOR_REF(vector_2470, aux_4187);
}
}
{
obj_t aux_4190;
aux_4190 = BINT(gotono_14);
arg1485_939 = MAKE_PAIR(aux_4190, arg1486_940);
}
}
{
obj_t vector_2474;
vector_2474 = lookback___lalr_global;
{
long aux_4193;
aux_4193 = (long)CINT(i_932);
return VECTOR_SET(vector_2474, aux_4193, arg1485_939);
}
}
}
 else {
display___r4_output_6_10_3(string1966___lalr_expand, BNIL);
{
obj_t arg1488_942;
{
obj_t list1490_944;
{
obj_t arg1491_945;
{
obj_t arg1494_946;
{
obj_t aux_4197;
aux_4197 = BINT(gotono_14);
arg1494_946 = MAKE_PAIR(aux_4197, BNIL);
}
arg1491_945 = MAKE_PAIR(ruleno_13, arg1494_946);
}
list1490_944 = MAKE_PAIR(stateno_12, arg1491_945);
}
arg1488_942 = list1490_944;
}
display___r4_output_6_10_3(arg1488_942, BNIL);
}
return newline___r4_output_6_10_3(BNIL);
}
}
}
}
}
}
}


/* transpose */obj_t transpose___lalr_expand(obj_t r_arg_181_15, obj_t n_16)
{
{
obj_t new_end_242_950;
obj_t new_r_167_951;
{
long aux_4204;
aux_4204 = (long)CINT(n_16);
new_end_242_950 = make_vector(aux_4204, BFALSE);
}
{
long aux_4207;
aux_4207 = (long)CINT(n_16);
new_r_167_951 = make_vector(aux_4207, BFALSE);
}
{
long i_953;
i_953 = ((long)0);
do_loop__1040_98_961:
if(_2__95___r4_numbers_6_5(BINT(i_953), n_16)){
((bool_t)0);
}
 else {
{
obj_t x_956;
{
obj_t list1502_958;
list1502_958 = MAKE_PAIR(symbol1967___lalr_expand, BNIL);
x_956 = list1502_958;
}
VECTOR_SET(new_r_167_951, i_953, x_956);
VECTOR_SET(new_end_242_950, i_953, x_956);
}
{
long i_4216;
i_4216 = (i_953+((long)1));
i_953 = i_4216;
goto do_loop__1040_98_961;
}
}
}
{
long i_963;
i_963 = ((long)0);
do_loop__1041_21_978:
if(_2__95___r4_numbers_6_5(BINT(i_963), n_16)){
((bool_t)0);
}
 else {
{
obj_t sp_966;
sp_966 = VECTOR_REF(r_arg_181_15, i_963);
if(PAIRP(sp_966)){
obj_t sp2_968;
sp2_968 = sp_966;
loop_969:
if(PAIRP(sp2_968)){
obj_t x_971;
x_971 = CAR(sp2_968);
{
obj_t y_972;
{
long aux_4227;
aux_4227 = (long)CINT(x_971);
y_972 = VECTOR_REF(new_end_242_950, aux_4227);
}
{
{
obj_t arg1510_973;
{
obj_t aux_4232;
obj_t aux_4230;
aux_4232 = CDR(y_972);
aux_4230 = BINT(i_963);
arg1510_973 = MAKE_PAIR(aux_4230, aux_4232);
}
SET_CDR(y_972, arg1510_973);
}
{
obj_t aux_4238;
long aux_4236;
aux_4238 = CDR(y_972);
aux_4236 = (long)CINT(x_971);
VECTOR_SET(new_end_242_950, aux_4236, aux_4238);
}
{
obj_t sp2_4241;
sp2_4241 = CDR(sp2_968);
sp2_968 = sp2_4241;
goto loop_969;
}
}
}
}
 else {
BUNSPEC;
}
}
 else {
BUNSPEC;
}
}
{
long i_4243;
i_4243 = (i_963+((long)1));
i_963 = i_4243;
goto do_loop__1041_21_978;
}
}
}
{
long i_980;
i_980 = ((long)0);
do_loop__1042_112_986:
if(_2__95___r4_numbers_6_5(BINT(i_980), n_16)){
((bool_t)0);
}
 else {
{
obj_t aux_4248;
{
obj_t aux_4249;
aux_4249 = VECTOR_REF(new_r_167_951, i_980);
aux_4248 = CDR(aux_4249);
}
VECTOR_SET(new_r_167_951, i_980, aux_4248);
}
{
long i_4253;
i_4253 = (i_980+((long)1));
i_980 = i_4253;
goto do_loop__1042_112_986;
}
}
}
return new_r_167_951;
}
}


/* build-relations */obj_t build_relations_89___lalr_expand()
{
{
obj_t stateno_1036;
obj_t symbol_1037;
{
long aux_4255;
aux_4255 = (long)CINT(ngotos___lalr_global);
includes___lalr_global = make_vector(aux_4255, BFALSE);
}
{
long i_989;
i_989 = ((long)0);
do_loop__1043_113_1035:
{
bool_t test1524_991;
test1524_991 = _2__95___r4_numbers_6_5(BINT(i_989), ngotos___lalr_global);
if(test1524_991){
((bool_t)0);
}
 else {
{
obj_t state1_992;
obj_t symbol1_993;
{
obj_t vector_2514;
vector_2514 = from_state_185___lalr_global;
state1_992 = VECTOR_REF(vector_2514, i_989);
}
{
obj_t arg1554_1033;
{
obj_t vector_2516;
vector_2516 = to_state_44___lalr_global;
arg1554_1033 = VECTOR_REF(vector_2516, i_989);
}
{
obj_t vector_2518;
vector_2518 = acces_symbol_228___lalr_global;
{
long aux_4263;
aux_4263 = (long)CINT(arg1554_1033);
symbol1_993 = VECTOR_REF(vector_2518, aux_4263);
}
}
}
{
obj_t rulep_994;
obj_t edges_995;
{
obj_t arg1525_997;
{
obj_t vector_2520;
vector_2520 = derives___lalr_global;
{
long aux_4266;
aux_4266 = (long)CINT(symbol1_993);
arg1525_997 = VECTOR_REF(vector_2520, aux_4266);
}
}
rulep_994 = arg1525_997;
edges_995 = BNIL;
loop_996:
if(PAIRP(rulep_994)){
obj_t _rulep_167_1000;
_rulep_167_1000 = CAR(rulep_994);
{
obj_t rp_1001;
obj_t stateno_1002;
obj_t states_1003;
{
obj_t arg1528_1005;
obj_t arg1529_1006;
{
obj_t vector_2524;
vector_2524 = rrhs___lalr_global;
{
long aux_4272;
aux_4272 = (long)CINT(_rulep_167_1000);
arg1528_1005 = VECTOR_REF(vector_2524, aux_4272);
}
}
{
obj_t list1530_1007;
list1530_1007 = MAKE_PAIR(state1_992, BNIL);
arg1529_1006 = list1530_1007;
}
rp_1001 = arg1528_1005;
stateno_1002 = state1_992;
states_1003 = arg1529_1006;
loop2_1004:
{
obj_t _rp_85_1009;
{
obj_t vector_2527;
vector_2527 = ritem___lalr_global;
{
long aux_4276;
aux_4276 = (long)CINT(rp_1001);
_rp_85_1009 = VECTOR_REF(vector_2527, aux_4276);
}
}
{
bool_t test_4279;
{
long aux_4280;
aux_4280 = (long)CINT(_rp_85_1009);
test_4279 = (aux_4280>((long)0));
}
if(test_4279){
obj_t st_1011;
stateno_1036 = stateno_1002;
symbol_1037 = _rp_85_1009;
{
obj_t arg1557_1042;
{
obj_t arg1558_1043;
{
obj_t vector_2556;
vector_2556 = shift_table_147___lalr_global;
{
long aux_4283;
aux_4283 = (long)CINT(stateno_1036);
arg1558_1043 = VECTOR_REF(vector_2556, aux_4283);
}
}
arg1557_1042 = VECTOR_REF(arg1558_1043, ((long)2));
}
{
obj_t j_2561;
obj_t stno_2562;
j_2561 = arg1557_1042;
stno_2562 = stateno_1036;
loop_2560:
if(NULLP(j_2561)){
st_1011 = stno_2562;
}
 else {
obj_t st2_2569;
st2_2569 = CAR(j_2561);
{
bool_t test1561_2570;
{
obj_t arg1563_2571;
{
obj_t vector_2575;
vector_2575 = acces_symbol_228___lalr_global;
{
long aux_4290;
aux_4290 = (long)CINT(st2_2569);
arg1563_2571 = VECTOR_REF(vector_2575, aux_4290);
}
}
test1561_2570 = _2__95___r4_numbers_6_5(arg1563_2571, symbol_1037);
}
if(test1561_2570){
st_1011 = st2_2569;
}
 else {
obj_t stno_4297;
obj_t j_4295;
j_4295 = CDR(j_2561);
stno_4297 = st2_2569;
stno_2562 = stno_4297;
j_2561 = j_4295;
goto loop_2560;
}
}
}
}
}
{
long arg1533_1012;
obj_t arg1534_1013;
{
long aux_4298;
aux_4298 = (long)CINT(rp_1001);
arg1533_1012 = (aux_4298+((long)1));
}
arg1534_1013 = MAKE_PAIR(st_1011, states_1003);
{
obj_t states_4305;
obj_t stateno_4304;
obj_t rp_4302;
rp_4302 = BINT(arg1533_1012);
stateno_4304 = st_1011;
states_4305 = arg1534_1013;
states_1003 = states_4305;
stateno_1002 = stateno_4304;
rp_1001 = rp_4302;
goto loop2_1004;
}
}
}
 else {
{
bool_t test1535_1014;
{
obj_t vector_2535;
vector_2535 = consistent___lalr_global;
{
obj_t aux_4306;
{
long aux_4307;
aux_4307 = (long)CINT(stateno_1002);
aux_4306 = VECTOR_REF(vector_2535, aux_4307);
}
test1535_1014 = CBOOL(aux_4306);
}
}
if(test1535_1014){
BUNSPEC;
}
 else {
add_lookback_edge_142___lalr_expand(stateno_1002, _rulep_167_1000, i_989);
}
}
{
bool_t done_1015;
obj_t stp_1016;
long rp2_1017;
obj_t edgp_1018;
done_1015 = ((bool_t)0);
stp_1016 = CDR(states_1003);
{
long aux_4342;
aux_4342 = (long)CINT(rp_1001);
rp2_1017 = (aux_4342-((long)1));
}
edgp_1018 = edges_995;
loop2_1019:
if(done_1015){
obj_t edges_4316;
obj_t rulep_4314;
rulep_4314 = CDR(rulep_994);
edges_4316 = edgp_1018;
edges_995 = edges_4316;
rulep_994 = rulep_4314;
goto loop_996;
}
 else {
obj_t _rp_85_1023;
{
obj_t vector_2541;
vector_2541 = ritem___lalr_global;
_rp_85_1023 = VECTOR_REF(vector_2541, rp2_1017);
}
{
bool_t test1540_1024;
if(_2__116___r4_numbers_6_5(BINT(((long)-1)), _rp_85_1023)){
test1540_1024 = _2__116___r4_numbers_6_5(_rp_85_1023, nvars___lalr_global);
}
 else {
test1540_1024 = ((bool_t)0);
}
if(test1540_1024){
bool_t arg1542_1025;
obj_t arg1545_1026;
long arg1548_1027;
obj_t arg1549_1028;
{
bool_t test1550_1029;
{
obj_t vector_2543;
vector_2543 = nullable___lalr_global;
{
obj_t aux_4323;
{
long aux_4324;
aux_4324 = (long)CINT(_rp_85_1023);
aux_4323 = VECTOR_REF(vector_2543, aux_4324);
}
test1550_1029 = CBOOL(aux_4323);
}
}
if(test1550_1029){
arg1542_1025 = ((bool_t)0);
}
 else {
arg1542_1025 = ((bool_t)1);
}
}
arg1545_1026 = CDR(stp_1016);
arg1548_1027 = (rp2_1017-((long)1));
{
long arg1552_1030;
arg1552_1030 = map_goto_153___lalr_expand(CAR(stp_1016), _rp_85_1023);
{
obj_t aux_4333;
aux_4333 = BINT(arg1552_1030);
arg1549_1028 = MAKE_PAIR(aux_4333, edgp_1018);
}
}
{
obj_t edgp_4339;
long rp2_4338;
obj_t stp_4337;
bool_t done_4336;
done_4336 = arg1542_1025;
stp_4337 = arg1545_1026;
rp2_4338 = arg1548_1027;
edgp_4339 = arg1549_1028;
edgp_1018 = edgp_4339;
rp2_1017 = rp2_4338;
stp_1016 = stp_4337;
done_1015 = done_4336;
goto loop2_1019;
}
}
 else {
bool_t done_4340;
done_4340 = ((bool_t)1);
done_1015 = done_4340;
goto loop2_1019;
}
}
}
}
}
}
}
}
}
}
 else {
obj_t vector_2551;
vector_2551 = includes___lalr_global;
{
obj_t x_3005;
x_3005 = VECTOR_SET(vector_2551, i_989, edges_995);
BUNSPEC;
}
}
}
}
}
{
long i_4346;
i_4346 = (i_989+((long)1));
i_989 = i_4346;
goto do_loop__1043_113_1035;
}
}
}
}
return (includes___lalr_global = transpose___lalr_expand(includes___lalr_global, ngotos___lalr_global),
BUNSPEC);
}
}


/* compute-lookaheads */obj_t compute_lookaheads_139___lalr_expand()
{
{
obj_t n_1051;
{
obj_t vector_2600;
long k_2601;
vector_2600 = lookaheads___lalr_global;
k_2601 = (long)CINT(nstates___lalr_global);
n_1051 = VECTOR_REF(vector_2600, k_2601);
}
{
long i_1052;
i_1052 = ((long)0);
loop_1053:
{
bool_t test_4351;
{
long aux_4352;
aux_4352 = (long)CINT(n_1051);
test_4351 = (i_1052<aux_4352);
}
if(test_4351){
obj_t sp_1055;
{
obj_t arg1565_1057;
{
obj_t vector_2604;
vector_2604 = lookback___lalr_global;
arg1565_1057 = VECTOR_REF(vector_2604, i_1052);
}
sp_1055 = arg1565_1057;
loop2_1056:
if(PAIRP(sp_1055)){
obj_t la_i_166_1059;
obj_t f_j_247_1060;
{
obj_t vector_2607;
vector_2607 = la___lalr_global;
la_i_166_1059 = VECTOR_REF(vector_2607, i_1052);
}
{
obj_t vector_2610;
vector_2610 = f___lalr_global;
{
long aux_4359;
{
obj_t aux_4360;
aux_4360 = CAR(sp_1055);
aux_4359 = (long)CINT(aux_4360);
}
f_j_247_1060 = VECTOR_REF(vector_2610, aux_4359);
}
}
{
obj_t i_1062;
i_1062 = BINT(((long)0));
do_loop__1045_251_1069:
{
bool_t test1568_1064;
test1568_1064 = _2__95___r4_numbers_6_5(i_1062, token_set_size_186___lalr_global);
if(test1568_1064){
((bool_t)0);
}
 else {
{
obj_t aux_4368;
long aux_4366;
{
long aux_4369;
{
long aux_4376;
long aux_4370;
{
obj_t aux_4377;
{
long aux_4378;
aux_4378 = (long)CINT(i_1062);
aux_4377 = VECTOR_REF(f_j_247_1060, aux_4378);
}
aux_4376 = (long)CINT(aux_4377);
}
{
obj_t aux_4371;
{
long aux_4372;
aux_4372 = (long)CINT(i_1062);
aux_4371 = VECTOR_REF(la_i_166_1059, aux_4372);
}
aux_4370 = (long)CINT(aux_4371);
}
aux_4369 = (aux_4370 | aux_4376);
}
aux_4368 = BINT(aux_4369);
}
aux_4366 = (long)CINT(i_1062);
VECTOR_SET(la_i_166_1059, aux_4366, aux_4368);
}
{
obj_t i_4385;
i_4385 = _2__168___r4_numbers_6_5(i_1062, BINT(((long)1)));
i_1062 = i_4385;
goto do_loop__1045_251_1069;
}
}
}
}
{
obj_t sp_4389;
sp_4389 = CDR(sp_1055);
sp_1055 = sp_4389;
goto loop2_1056;
}
}
 else {
long i_4391;
i_4391 = (i_1052+((long)1));
i_1052 = i_4391;
goto loop_1053;
}
}
}
 else {
return BUNSPEC;
}
}
}
}
}


/* digraph */obj_t digraph___lalr_expand(obj_t relation_17)
{
{
obj_t r_1074;
obj_t top_1075;
obj_t vertices_1076;
obj_t index_1077;
obj_t infinity_1078;
r_1074 = MAKE_CELL(BUNSPEC);
top_1075 = MAKE_CELL(BUNSPEC);
vertices_1076 = MAKE_CELL(BUNSPEC);
index_1077 = MAKE_CELL(BUNSPEC);
infinity_1078 = MAKE_CELL(BUNSPEC);
{
obj_t aux_2973;
{
long z1_2624;
z1_2624 = (long)CINT(ngotos___lalr_global);
{
long aux_4394;
aux_4394 = (z1_2624+((long)2));
aux_2973 = BINT(aux_4394);
}
}
CELL_SET(infinity_1078, aux_2973);
}
{
obj_t aux_2974;
{
long arg1627_1135;
{
long z1_2626;
z1_2626 = (long)CINT(ngotos___lalr_global);
arg1627_1135 = (z1_2626+((long)1));
}
{
obj_t aux_4399;
aux_4399 = BINT(((long)0));
aux_2974 = make_vector(arg1627_1135, aux_4399);
}
}
CELL_SET(index_1077, aux_2974);
}
{
obj_t aux_2975;
{
long arg1624_1133;
{
long z1_2628;
z1_2628 = (long)CINT(ngotos___lalr_global);
arg1624_1133 = (z1_2628+((long)1));
}
{
obj_t aux_4404;
aux_4404 = BINT(((long)0));
aux_2975 = make_vector(arg1624_1133, aux_4404);
}
}
CELL_SET(vertices_1076, aux_2975);
}
CELL_SET(top_1075, BINT(((long)0)));
CELL_SET(r_1074, relation_17);
{
long i_1079;
i_1079 = ((long)0);
loop_1080:
{
bool_t test1581_1081;
{
long n2_2631;
n2_2631 = (long)CINT(ngotos___lalr_global);
test1581_1081 = (i_1079<n2_2631);
}
if(test1581_1081){
{
bool_t test1582_1082;
{
bool_t test1583_1083;
{
obj_t arg1586_1086;
{
obj_t vector_2632;
vector_2632 = CELL_REF(index_1077);
arg1586_1086 = VECTOR_REF(vector_2632, i_1079);
}
test1583_1083 = _2__95___r4_numbers_6_5(BINT(((long)0)), arg1586_1086);
}
if(test1583_1083){
obj_t arg1584_1084;
{
obj_t vector_2634;
vector_2634 = CELL_REF(r_1074);
arg1584_1084 = VECTOR_REF(vector_2634, i_1079);
}
test1582_1082 = PAIRP(arg1584_1084);
}
 else {
test1582_1082 = ((bool_t)0);
}
}
if(test1582_1082){
traverse___lalr_expand(infinity_1078, r_1074, index_1077, vertices_1076, top_1075, BINT(i_1079));
}
 else {
BUNSPEC;
}
}
{
long i_4420;
i_4420 = (i_1079+((long)1));
i_1079 = i_4420;
goto loop_1080;
}
}
 else {
return BUNSPEC;
}
}
}
}
}


/* traverse */obj_t traverse___lalr_expand(obj_t infinity_2970, obj_t r_2969, obj_t index_2968, obj_t vertices_2967, obj_t top_2966, obj_t i_1088)
{
{
obj_t aux_2971;
{
long z2_2640;
{
obj_t aux_4422;
aux_4422 = CELL_REF(top_2966);
z2_2640 = (long)CINT(aux_4422);
}
{
long aux_4424;
aux_4424 = (((long)1)+z2_2640);
aux_2971 = BINT(aux_4424);
}
}
CELL_SET(top_2966, aux_2971);
}
{
obj_t vector_2641;
long k_2642;
vector_2641 = CELL_REF(vertices_2967);
{
obj_t aux_4427;
aux_4427 = CELL_REF(top_2966);
k_2642 = (long)CINT(aux_4427);
}
VECTOR_SET(vector_2641, k_2642, i_1088);
}
{
obj_t height_1090;
height_1090 = CELL_REF(top_2966);
{
obj_t vector_2644;
vector_2644 = CELL_REF(index_2968);
{
long aux_4430;
aux_4430 = (long)CINT(i_1088);
VECTOR_SET(vector_2644, aux_4430, height_1090);
}
}
{
obj_t rp_1091;
{
obj_t vector_2647;
vector_2647 = CELL_REF(r_2969);
{
long aux_4433;
aux_4433 = (long)CINT(i_1088);
rp_1091 = VECTOR_REF(vector_2647, aux_4433);
}
}
if(PAIRP(rp_1091)){
obj_t rp2_1093;
rp2_1093 = rp_1091;
loop_1094:
if(PAIRP(rp2_1093)){
obj_t j_1096;
j_1096 = CAR(rp2_1093);
{
bool_t test1591_1097;
{
obj_t arg1593_1099;
{
obj_t vector_2652;
vector_2652 = CELL_REF(index_2968);
{
long aux_4441;
aux_4441 = (long)CINT(j_1096);
arg1593_1099 = VECTOR_REF(vector_2652, aux_4441);
}
}
test1591_1097 = _2__95___r4_numbers_6_5(BINT(((long)0)), arg1593_1099);
}
if(test1591_1097){
traverse___lalr_expand(infinity_2970, r_2969, index_2968, vertices_2967, top_2966, j_1096);
}
 else {
BUNSPEC;
}
}
{
bool_t test1594_1100;
{
obj_t arg1598_1102;
obj_t arg1600_1103;
{
obj_t vector_2654;
vector_2654 = CELL_REF(index_2968);
{
long aux_4448;
aux_4448 = (long)CINT(i_1088);
arg1598_1102 = VECTOR_REF(vector_2654, aux_4448);
}
}
{
obj_t vector_2656;
vector_2656 = CELL_REF(index_2968);
{
long aux_4451;
aux_4451 = (long)CINT(j_1096);
arg1600_1103 = VECTOR_REF(vector_2656, aux_4451);
}
}
{
long aux_4456;
long aux_4454;
aux_4456 = (long)CINT(arg1600_1103);
aux_4454 = (long)CINT(arg1598_1102);
test1594_1100 = (aux_4454>aux_4456);
}
}
if(test1594_1100){
obj_t arg1595_1101;
{
obj_t vector_2660;
vector_2660 = CELL_REF(index_2968);
{
long aux_4460;
aux_4460 = (long)CINT(j_1096);
arg1595_1101 = VECTOR_REF(vector_2660, aux_4460);
}
}
{
obj_t vector_2662;
vector_2662 = CELL_REF(index_2968);
{
long aux_4463;
aux_4463 = (long)CINT(i_1088);
VECTOR_SET(vector_2662, aux_4463, arg1595_1101);
}
}
}
 else {
BUNSPEC;
}
}
{
obj_t f_i_43_1104;
obj_t f_j_247_1105;
{
obj_t vector_2665;
vector_2665 = f___lalr_global;
{
long aux_4466;
aux_4466 = (long)CINT(i_1088);
f_i_43_1104 = VECTOR_REF(vector_2665, aux_4466);
}
}
{
obj_t vector_2667;
vector_2667 = f___lalr_global;
{
long aux_4469;
aux_4469 = (long)CINT(j_1096);
f_j_247_1105 = VECTOR_REF(vector_2667, aux_4469);
}
}
{
obj_t i_1107;
i_1107 = BINT(((long)0));
do_loop__1046_207_1114:
{
bool_t test1602_1109;
test1602_1109 = _2__95___r4_numbers_6_5(i_1107, token_set_size_186___lalr_global);
if(test1602_1109){
((bool_t)0);
}
 else {
{
obj_t aux_4476;
long aux_4474;
{
long aux_4477;
{
long aux_4484;
long aux_4478;
{
obj_t aux_4485;
{
long aux_4486;
aux_4486 = (long)CINT(i_1107);
aux_4485 = VECTOR_REF(f_j_247_1105, aux_4486);
}
aux_4484 = (long)CINT(aux_4485);
}
{
obj_t aux_4479;
{
long aux_4480;
aux_4480 = (long)CINT(i_1107);
aux_4479 = VECTOR_REF(f_i_43_1104, aux_4480);
}
aux_4478 = (long)CINT(aux_4479);
}
aux_4477 = (aux_4478 | aux_4484);
}
aux_4476 = BINT(aux_4477);
}
aux_4474 = (long)CINT(i_1107);
VECTOR_SET(f_i_43_1104, aux_4474, aux_4476);
}
{
obj_t i_4493;
i_4493 = _2__168___r4_numbers_6_5(i_1107, BINT(((long)1)));
i_1107 = i_4493;
goto do_loop__1046_207_1114;
}
}
}
}
}
{
obj_t rp2_4497;
rp2_4497 = CDR(rp2_1093);
rp2_1093 = rp2_4497;
goto loop_1094;
}
}
 else {
BUNSPEC;
}
}
 else {
BUNSPEC;
}
{
bool_t test1609_1116;
{
obj_t arg1623_1132;
{
obj_t vector_2679;
vector_2679 = CELL_REF(index_2968);
{
long aux_4499;
aux_4499 = (long)CINT(i_1088);
arg1623_1132 = VECTOR_REF(vector_2679, aux_4499);
}
}
test1609_1116 = _2__95___r4_numbers_6_5(arg1623_1132, height_1090);
}
if(test1609_1116){
loop_1117:
{
obj_t j_1118;
{
obj_t vector_2681;
long k_2682;
vector_2681 = CELL_REF(vertices_2967);
{
obj_t aux_4504;
aux_4504 = CELL_REF(top_2966);
k_2682 = (long)CINT(aux_4504);
}
j_1118 = VECTOR_REF(vector_2681, k_2682);
}
{
obj_t aux_2972;
{
long z1_2683;
{
obj_t aux_4507;
aux_4507 = CELL_REF(top_2966);
z1_2683 = (long)CINT(aux_4507);
}
{
long aux_4509;
aux_4509 = (z1_2683-((long)1));
aux_2972 = BINT(aux_4509);
}
}
CELL_SET(top_2966, aux_2972);
}
{
obj_t vector_2685;
obj_t obj_2687;
vector_2685 = CELL_REF(index_2968);
obj_2687 = CELL_REF(infinity_2970);
{
long aux_4512;
aux_4512 = (long)CINT(j_1118);
VECTOR_SET(vector_2685, aux_4512, obj_2687);
}
}
if(_2__95___r4_numbers_6_5(i_1088, j_1118)){
return BUNSPEC;
}
 else {
{
obj_t i_1121;
i_1121 = BINT(((long)0));
do_loop__1047_225_1131:
{
bool_t test1612_1123;
test1612_1123 = _2__95___r4_numbers_6_5(i_1121, token_set_size_186___lalr_global);
if(test1612_1123){
((bool_t)0);
}
 else {
{
obj_t arg1613_1124;
long arg1615_1125;
{
obj_t vector_2688;
vector_2688 = f___lalr_global;
{
long aux_4519;
aux_4519 = (long)CINT(i_1121);
arg1613_1124 = VECTOR_REF(vector_2688, aux_4519);
}
}
{
obj_t arg1617_1126;
obj_t arg1618_1127;
{
obj_t arg1620_1128;
{
obj_t vector_2690;
vector_2690 = f___lalr_global;
{
long aux_4522;
aux_4522 = (long)CINT(i_1121);
arg1620_1128 = VECTOR_REF(vector_2690, aux_4522);
}
}
{
long aux_4525;
aux_4525 = (long)CINT(i_1121);
arg1617_1126 = VECTOR_REF(arg1620_1128, aux_4525);
}
}
{
obj_t arg1621_1129;
{
obj_t vector_2694;
vector_2694 = f___lalr_global;
{
long aux_4528;
aux_4528 = (long)CINT(j_1118);
arg1621_1129 = VECTOR_REF(vector_2694, aux_4528);
}
}
{
long aux_4531;
aux_4531 = (long)CINT(i_1121);
arg1618_1127 = VECTOR_REF(arg1621_1129, aux_4531);
}
}
{
long aux_4536;
long aux_4534;
aux_4536 = (long)CINT(arg1618_1127);
aux_4534 = (long)CINT(arg1617_1126);
arg1615_1125 = (aux_4534 | aux_4536);
}
}
{
obj_t aux_4541;
long aux_4539;
aux_4541 = BINT(arg1615_1125);
aux_4539 = (long)CINT(i_1121);
VECTOR_SET(arg1613_1124, aux_4539, aux_4541);
}
}
{
obj_t i_4544;
i_4544 = _2__168___r4_numbers_6_5(i_1121, BINT(((long)1)));
i_1121 = i_4544;
goto do_loop__1047_225_1131;
}
}
}
}
goto loop_1117;
}
}
}
 else {
return BUNSPEC;
}
}
}
}
}


/* build-rule */obj_t build_rule_121___lalr_expand(long n_18)
{
{
obj_t arg1630_1138;
obj_t arg1632_1139;
{
obj_t arg1633_1140;
{
obj_t vector_2703;
vector_2703 = rlhs___lalr_global;
arg1633_1140 = VECTOR_REF(vector_2703, n_18);
}
{
obj_t vector_2705;
vector_2705 = _symv__174___lalr_rewrite;
{
long aux_4549;
aux_4549 = (long)CINT(arg1633_1140);
arg1630_1138 = VECTOR_REF(vector_2705, aux_4549);
}
}
}
{
obj_t arg1634_1141;
obj_t arg1636_1142;
arg1634_1141 = symbol1968___lalr_expand;
{
obj_t arg1638_1145;
{
obj_t vector_2707;
vector_2707 = rrhs___lalr_global;
arg1638_1145 = VECTOR_REF(vector_2707, n_18);
}
arg1636_1142 = loop___lalr_expand(arg1638_1145);
}
arg1632_1139 = MAKE_PAIR(arg1634_1141, arg1636_1142);
}
return MAKE_PAIR(arg1630_1138, arg1632_1139);
}
}


/* loop */obj_t loop___lalr_expand(obj_t pos_1143)
{
{
obj_t x_1146;
{
obj_t vector_2709;
vector_2709 = ritem___lalr_global;
{
long aux_4556;
aux_4556 = (long)CINT(pos_1143);
x_1146 = VECTOR_REF(vector_2709, aux_4556);
}
}
{
bool_t test_4559;
{
long aux_4560;
aux_4560 = (long)CINT(x_1146);
test_4559 = (aux_4560<((long)0));
}
if(test_4559){
return BNIL;
}
 else {
obj_t arg1640_1148;
obj_t arg1641_1149;
{
obj_t vector_2713;
vector_2713 = _symv__174___lalr_rewrite;
{
long aux_4563;
aux_4563 = (long)CINT(x_1146);
arg1640_1148 = VECTOR_REF(vector_2713, aux_4563);
}
}
{
obj_t aux_4566;
{
long aux_4567;
{
long aux_4568;
aux_4568 = (long)CINT(pos_1143);
aux_4567 = (aux_4568+((long)1));
}
aux_4566 = BINT(aux_4567);
}
arg1641_1149 = loop___lalr_expand(aux_4566);
}
return MAKE_PAIR(arg1640_1148, arg1641_1149);
}
}
}
}


/* build-tables */obj_t build_tables_64___lalr_expand()
{
{
long aux_4574;
aux_4574 = (long)CINT(nstates___lalr_global);
action_table_22___lalr_global = make_vector(aux_4574, BNIL);
}
{
long i_1154;
i_1154 = ((long)0);
do_loop__1048_17_1210:
{
bool_t test1648_1156;
test1648_1156 = _2__95___r4_numbers_6_5(BINT(i_1154), nstates___lalr_global);
if(test1648_1156){
((bool_t)0);
}
 else {
{
obj_t red_1157;
{
obj_t vector_2723;
vector_2723 = reduction_table_100___lalr_global;
red_1157 = VECTOR_REF(vector_2723, i_1154);
}
{
bool_t test_4581;
if(CBOOL(red_1157)){
long aux_4584;
{
obj_t aux_4585;
aux_4585 = VECTOR_REF(red_1157, ((long)1));
aux_4584 = (long)CINT(aux_4585);
}
test_4581 = (aux_4584>=((long)1));
}
 else {
test_4581 = ((bool_t)0);
}
if(test_4581){
bool_t test1650_1159;
if(_2__95___r4_numbers_6_5(VECTOR_REF(red_1157, ((long)1)), BINT(((long)1)))){
obj_t vector_2731;
vector_2731 = consistent___lalr_global;
{
obj_t aux_4593;
aux_4593 = VECTOR_REF(vector_2731, i_1154);
test1650_1159 = CBOOL(aux_4593);
}
}
 else {
test1650_1159 = ((bool_t)0);
}
if(test1650_1159){
obj_t aux_4597;
{
long aux_4599;
{
long aux_4600;
{
obj_t aux_4601;
{
obj_t aux_4602;
aux_4602 = VECTOR_REF(red_1157, ((long)2));
aux_4601 = CAR(aux_4602);
}
aux_4600 = (long)CINT(aux_4601);
}
aux_4599 = NEG(aux_4600);
}
aux_4597 = BINT(aux_4599);
}
add_action_218___lalr_expand(BINT(i_1154), _default__79___lalr_expand, aux_4597);
}
 else {
obj_t k_1163;
{
obj_t vector_2739;
vector_2739 = lookaheads___lalr_global;
{
long aux_4609;
aux_4609 = (i_1154+((long)1));
k_1163 = VECTOR_REF(vector_2739, aux_4609);
}
}
{
obj_t j_1164;
{
obj_t arg1655_1166;
{
obj_t vector_2741;
vector_2741 = lookaheads___lalr_global;
arg1655_1166 = VECTOR_REF(vector_2741, i_1154);
}
j_1164 = arg1655_1166;
loop_1165:
{
bool_t test_4613;
{
long aux_4616;
long aux_4614;
aux_4616 = (long)CINT(k_1163);
aux_4614 = (long)CINT(j_1164);
test_4613 = (aux_4614<aux_4616);
}
if(test_4613){
long rule_1168;
obj_t lav_1169;
{
obj_t arg1676_1192;
{
obj_t vector_2745;
vector_2745 = laruleno___lalr_global;
{
long aux_4619;
aux_4619 = (long)CINT(j_1164);
arg1676_1192 = VECTOR_REF(vector_2745, aux_4619);
}
}
{
long aux_4622;
aux_4622 = (long)CINT(arg1676_1192);
rule_1168 = NEG(aux_4622);
}
}
{
obj_t vector_2748;
vector_2748 = la___lalr_global;
{
long aux_4625;
aux_4625 = (long)CINT(j_1164);
lav_1169 = VECTOR_REF(vector_2748, aux_4625);
}
}
{
long token_1170;
obj_t x_1171;
long y_1172;
long z_1173;
token_1170 = ((long)0);
x_1171 = VECTOR_REF(lav_1169, ((long)0));
y_1172 = ((long)1);
z_1173 = ((long)0);
loop2_1174:
{
bool_t test1662_1179;
{
long n2_2753;
n2_2753 = (long)CINT(nterms___lalr_global);
test1662_1179 = (token_1170<n2_2753);
}
if(test1662_1179){
{
bool_t test_4631;
{
obj_t aux_4632;
{
long aux_4633;
aux_4633 = modulo___r4_numbers_6_5_fixnum((long)CINT(x_1171), ((long)2));
aux_4632 = BINT(aux_4633);
}
test_4631 = _2__95___r4_numbers_6_5(aux_4632, BINT(((long)1)));
}
if(test_4631){
add_action_218___lalr_expand(BINT(i_1154), BINT(token_1170), BINT(rule_1168));
}
 else {
BUNSPEC;
}
}
if(_2__95___r4_numbers_6_5(BINT(y_1172), BINT(((long)28)))){
long z_4654;
long y_4653;
obj_t x_4649;
long token_4647;
token_4647 = (token_1170+((long)1));
{
long aux_4650;
aux_4650 = (z_1173+((long)1));
x_4649 = VECTOR_REF(lav_1169, aux_4650);
}
y_4653 = ((long)1);
z_4654 = (z_1173+((long)1));
z_1173 = z_4654;
y_1172 = y_4653;
x_1171 = x_4649;
token_1170 = token_4647;
goto loop2_1174;
}
 else {
long arg1670_1188;
long arg1672_1189;
long arg1673_1190;
arg1670_1188 = (token_1170+((long)1));
{
long aux_4657;
aux_4657 = (long)CINT(x_1171);
arg1672_1189 = (aux_4657/((long)2));
}
arg1673_1190 = (y_1172+((long)1));
{
long y_4664;
obj_t x_4662;
long token_4661;
token_4661 = arg1670_1188;
x_4662 = BINT(arg1672_1189);
y_4664 = arg1673_1190;
y_1172 = y_4664;
x_1171 = x_4662;
token_1170 = token_4661;
goto loop2_1174;
}
}
}
 else {
BUNSPEC;
}
}
}
{
obj_t j_4666;
{
long aux_4667;
{
long aux_4668;
aux_4668 = (long)CINT(j_1164);
aux_4667 = (aux_4668+((long)1));
}
j_4666 = BINT(aux_4667);
}
j_1164 = j_4666;
goto loop_1165;
}
}
 else {
BUNSPEC;
}
}
}
}
}
}
 else {
BUNSPEC;
}
}
}
{
obj_t shiftp_1199;
{
obj_t vector_2770;
vector_2770 = shift_table_147___lalr_global;
shiftp_1199 = VECTOR_REF(vector_2770, i_1154);
}
if(CBOOL(shiftp_1199)){
obj_t k_1200;
k_1200 = VECTOR_REF(shiftp_1199, ((long)2));
loop_1201:
if(PAIRP(k_1200)){
obj_t state_1204;
state_1204 = CAR(k_1200);
{
obj_t symbol_1205;
{
obj_t vector_2776;
vector_2776 = acces_symbol_228___lalr_global;
{
long aux_4678;
aux_4678 = (long)CINT(state_1204);
symbol_1205 = VECTOR_REF(vector_2776, aux_4678);
}
}
{
{
bool_t test1685_1206;
{
long n1_2778;
long n2_2779;
n1_2778 = (long)CINT(symbol_1205);
n2_2779 = (long)CINT(nvars___lalr_global);
test1685_1206 = (n1_2778>=n2_2779);
}
if(test1685_1206){
long arg1686_1207;
{
long z1_2780;
long z2_2781;
z1_2780 = (long)CINT(symbol_1205);
z2_2781 = (long)CINT(nvars___lalr_global);
arg1686_1207 = (z1_2780-z2_2781);
}
add_action_218___lalr_expand(BINT(i_1154), BINT(arg1686_1207), state_1204);
}
 else {
BUNSPEC;
}
}
{
obj_t k_4691;
k_4691 = CDR(k_1200);
k_1200 = k_4691;
goto loop_1201;
}
}
}
}
 else {
BUNSPEC;
}
}
 else {
BUNSPEC;
}
}
{
long i_4694;
i_4694 = (i_1154+((long)1));
i_1154 = i_4694;
goto do_loop__1048_17_1210;
}
}
}
}
return add_action_218___lalr_expand(final_state_208___lalr_global, BINT(((long)0)), symbol1969___lalr_expand);
}


/* add-action */obj_t add_action_218___lalr_expand(obj_t st_1213, obj_t sym_1214, obj_t act_1215)
{
{
obj_t x_1217;
{
obj_t vector_2785;
vector_2785 = action_table_22___lalr_global;
{
long aux_4698;
aux_4698 = (long)CINT(st_1213);
x_1217 = VECTOR_REF(vector_2785, aux_4698);
}
}
{
obj_t y_1218;
y_1218 = assv___r4_pairs_and_lists_6_3(sym_1214, x_1217);
{
if(CBOOL(y_1218)){
if(_2__95___r4_numbers_6_5(act_1215, CDR(y_1218))){
return BUNSPEC;
}
 else {
{
bool_t test_4707;
{
bool_t test_4708;
{
long aux_4709;
{
obj_t aux_4710;
aux_4710 = CDR(y_1218);
aux_4709 = (long)CINT(aux_4710);
}
test_4708 = (aux_4709<=((long)0));
}
if(test_4708){
long aux_4714;
aux_4714 = (long)CINT(act_1215);
test_4707 = (aux_4714<=((long)0));
}
 else {
test_4707 = ((bool_t)0);
}
}
if(test_4707){
{
obj_t arg1700_1224;
obj_t arg1702_1226;
obj_t arg1704_1228;
{
long aux_4717;
{
long aux_4718;
aux_4718 = (long)CINT(act_1215);
aux_4717 = NEG(aux_4718);
}
arg1700_1224 = build_rule_121___lalr_expand(aux_4717);
}
{
long aux_4722;
{
long aux_4723;
{
obj_t aux_4724;
aux_4724 = CDR(y_1218);
aux_4723 = (long)CINT(aux_4724);
}
aux_4722 = NEG(aux_4723);
}
arg1702_1226 = build_rule_121___lalr_expand(aux_4722);
}
{
long arg1721_1243;
{
long z1_2796;
long z2_2797;
z1_2796 = (long)CINT(nvars___lalr_global);
z2_2797 = (long)CINT(sym_1214);
arg1721_1243 = (z1_2796+z2_2797);
}
{
obj_t vector_2798;
vector_2798 = _symv__174___lalr_rewrite;
arg1704_1228 = VECTOR_REF(vector_2798, arg1721_1243);
}
}
{
obj_t list1706_1230;
{
obj_t arg1707_1231;
{
obj_t arg1708_1232;
{
obj_t arg1709_1233;
{
obj_t arg1710_1234;
{
obj_t arg1711_1235;
{
obj_t arg1712_1236;
{
obj_t arg1713_1237;
{
obj_t arg1714_1238;
arg1714_1238 = MAKE_PAIR(string1970___lalr_expand, BNIL);
arg1713_1237 = MAKE_PAIR(arg1704_1228, arg1714_1238);
}
arg1712_1236 = MAKE_PAIR(string1971___lalr_expand, arg1713_1237);
}
arg1711_1235 = MAKE_PAIR(arg1702_1226, arg1712_1236);
}
arg1710_1234 = MAKE_PAIR(string1972___lalr_expand, arg1711_1235);
}
arg1709_1233 = MAKE_PAIR(arg1700_1224, arg1710_1234);
}
arg1708_1232 = MAKE_PAIR(string1972___lalr_expand, arg1709_1233);
}
arg1707_1231 = MAKE_PAIR(string1973___lalr_expand, arg1708_1232);
}
list1706_1230 = MAKE_PAIR(string1961___lalr_expand, arg1707_1231);
}
warning___error(list1706_1230);
}
}
{
obj_t arg1722_1244;
{
obj_t arg1723_1245;
arg1723_1245 = CDR(y_1218);
{
obj_t list1724_1246;
list1724_1246 = MAKE_PAIR(act_1215, BNIL);
arg1722_1244 = max___r4_numbers_6_5(arg1723_1245, list1724_1246);
}
}
return SET_CDR(y_1218, arg1722_1244);
}
}
 else {
{
obj_t arg1730_1252;
obj_t arg1732_1254;
{
long aux_4747;
{
long aux_4748;
{
obj_t aux_4749;
aux_4749 = CDR(y_1218);
aux_4748 = (long)CINT(aux_4749);
}
aux_4747 = NEG(aux_4748);
}
arg1730_1252 = build_rule_121___lalr_expand(aux_4747);
}
{
long arg1755_1268;
{
long z1_2805;
long z2_2806;
z1_2805 = (long)CINT(nvars___lalr_global);
z2_2806 = (long)CINT(sym_1214);
arg1755_1268 = (z1_2805+z2_2806);
}
{
obj_t vector_2807;
vector_2807 = _symv__174___lalr_rewrite;
arg1732_1254 = VECTOR_REF(vector_2807, arg1755_1268);
}
}
{
obj_t list1734_1256;
{
obj_t arg1738_1257;
{
obj_t arg1739_1258;
{
obj_t arg1740_1259;
{
obj_t arg1743_1260;
{
obj_t arg1744_1261;
{
obj_t arg1745_1262;
{
obj_t arg1746_1263;
{
obj_t arg1747_1264;
arg1747_1264 = MAKE_PAIR(string1970___lalr_expand, BNIL);
arg1746_1263 = MAKE_PAIR(arg1732_1254, arg1747_1264);
}
arg1745_1262 = MAKE_PAIR(string1971___lalr_expand, arg1746_1263);
}
arg1744_1261 = MAKE_PAIR(arg1730_1252, arg1745_1262);
}
arg1743_1260 = MAKE_PAIR(string1974___lalr_expand, arg1744_1261);
}
arg1740_1259 = MAKE_PAIR(act_1215, arg1743_1260);
}
arg1739_1258 = MAKE_PAIR(string1975___lalr_expand, arg1740_1259);
}
arg1738_1257 = MAKE_PAIR(string1976___lalr_expand, arg1739_1258);
}
list1734_1256 = MAKE_PAIR(string1961___lalr_expand, arg1738_1257);
}
warning___error(list1734_1256);
}
}
return SET_CDR(y_1218, act_1215);
}
}
}
}
 else {
obj_t arg1761_1273;
{
obj_t arg1762_1274;
arg1762_1274 = MAKE_PAIR(sym_1214, act_1215);
arg1761_1273 = MAKE_PAIR(arg1762_1274, x_1217);
}
{
obj_t vector_2815;
vector_2815 = action_table_22___lalr_global;
{
long aux_4771;
aux_4771 = (long)CINT(st_1213);
return VECTOR_SET(vector_2815, aux_4771, arg1761_1273);
}
}
}
}
}
}
}


/* compact-action-table */bool_t compact_action_table_234___lalr_expand()
{
{
obj_t acts_1304;
{
long i_1278;
i_1278 = ((long)0);
do_loop__1049_127_1303:
{
bool_t test1764_1280;
test1764_1280 = _2__95___r4_numbers_6_5(BINT(i_1278), nstates___lalr_global);
if(test1764_1280){
return ((bool_t)0);
}
 else {
{
obj_t acts_1281;
{
obj_t vector_2818;
vector_2818 = action_table_22___lalr_global;
acts_1281 = VECTOR_REF(vector_2818, i_1278);
}
{
bool_t test1765_1282;
{
obj_t arg1783_1301;
{
obj_t vector_2820;
vector_2820 = reduction_table_100___lalr_global;
arg1783_1301 = VECTOR_REF(vector_2820, i_1278);
}
test1765_1282 = VECTORP(arg1783_1301);
}
if(test1765_1282){
obj_t act_1283;
acts_1304 = acts_1281;
{
obj_t accums_1306;
accums_1306 = BNIL;
{
obj_t l_1307;
l_1307 = acts_1304;
loop_1308:
if(PAIRP(l_1307)){
obj_t x_1310;
{
obj_t aux_4783;
aux_4783 = CAR(l_1307);
x_1310 = CDR(aux_4783);
}
{
obj_t y_1311;
y_1311 = assv___r4_pairs_and_lists_6_3(x_1310, accums_1306);
{
{
bool_t test_4787;
{
bool_t test_4788;
if(INTEGERP(x_1310)){
test_4788 = ((bool_t)1);
}
 else {
test_4788 = REALP(x_1310);
}
if(test_4788){
long aux_4792;
aux_4792 = (long)CINT(x_1310);
test_4787 = (aux_4792<((long)0));
}
 else {
test_4787 = ((bool_t)0);
}
}
if(test_4787){
if(CBOOL(y_1311)){
obj_t aux_4797;
{
long aux_4798;
{
long aux_4799;
{
obj_t aux_4800;
aux_4800 = CDR(y_1311);
aux_4799 = (long)CINT(aux_4800);
}
aux_4798 = (((long)1)+aux_4799);
}
aux_4797 = BINT(aux_4798);
}
SET_CDR(y_1311, aux_4797);
}
 else {
obj_t arg1794_1316;
{
obj_t list1795_1317;
{
obj_t aux_4806;
aux_4806 = BINT(((long)1));
list1795_1317 = MAKE_PAIR(aux_4806, BNIL);
}
arg1794_1316 = cons__138___r4_pairs_and_lists_6_3(x_1310, list1795_1317);
}
{
obj_t obj2_2858;
obj2_2858 = accums_1306;
accums_1306 = MAKE_PAIR(arg1794_1316, obj2_2858);
}
}
}
 else {
BUNSPEC;
}
}
{
obj_t l_4811;
l_4811 = CDR(l_1307);
l_1307 = l_4811;
goto loop_1308;
}
}
}
}
 else {
BUNSPEC;
}
}
{
obj_t l_2861;
obj_t max_2862;
obj_t sym_2863;
l_2861 = accums_1306;
max_2862 = BINT(((long)0));
sym_2863 = BFALSE;
loop_2860:
if(NULLP(l_2861)){
act_1283 = sym_2863;
}
 else {
obj_t x_2873;
x_2873 = CAR(l_2861);
{
bool_t test_4816;
{
long aux_4821;
long aux_4817;
aux_4821 = (long)CINT(max_2862);
{
obj_t aux_4818;
aux_4818 = CDR(x_2873);
aux_4817 = (long)CINT(aux_4818);
}
test_4816 = (aux_4817>aux_4821);
}
if(test_4816){
obj_t sym_4828;
obj_t max_4826;
obj_t l_4824;
l_4824 = CDR(l_2861);
max_4826 = CDR(x_2873);
sym_4828 = CAR(x_2873);
sym_2863 = sym_4828;
max_2862 = max_4826;
l_2861 = l_4824;
goto loop_2860;
}
 else {
obj_t l_4830;
l_4830 = CDR(l_2861);
l_2861 = l_4830;
goto loop_2860;
}
}
}
}
}
{
obj_t arg1766_1284;
{
obj_t arg1767_1285;
obj_t arg1768_1286;
{
obj_t list1770_1288;
{
obj_t aux_4833;
if(CBOOL(act_1283)){
aux_4833 = act_1283;
}
 else {
aux_4833 = symbol1977___lalr_expand;
}
list1770_1288 = MAKE_PAIR(aux_4833, BNIL);
}
arg1767_1285 = cons__138___r4_pairs_and_lists_6_3(_default__79___lalr_expand, list1770_1288);
}
{
obj_t arg1772_2962;
arg1772_2962 = make_fx_procedure(arg1772___lalr_expand, ((long)1), ((long)1));
PROCEDURE_SET(arg1772_2962, ((long)0), act_1283);
arg1768_1286 = filter___lalr_util(arg1772_2962, acts_1281);
}
arg1766_1284 = MAKE_PAIR(arg1767_1285, arg1768_1286);
}
{
obj_t vector_2830;
vector_2830 = action_table_22___lalr_global;
VECTOR_SET(vector_2830, i_1278, arg1766_1284);
}
}
}
 else {
obj_t arg1777_1296;
{
obj_t arg1778_1297;
{
obj_t list1780_1299;
list1780_1299 = MAKE_PAIR(symbol1978___lalr_expand, BNIL);
arg1778_1297 = cons__138___r4_pairs_and_lists_6_3(_default__79___lalr_expand, list1780_1299);
}
arg1777_1296 = MAKE_PAIR(arg1778_1297, acts_1281);
}
{
obj_t vector_2835;
vector_2835 = action_table_22___lalr_global;
VECTOR_SET(vector_2835, i_1278, arg1777_1296);
}
}
}
}
{
long i_4847;
i_4847 = (i_1278+((long)1));
i_1278 = i_4847;
goto do_loop__1049_127_1303;
}
}
}
}
}
}


/* arg1772 */obj_t arg1772___lalr_expand(obj_t env_2963, obj_t x_2965)
{
{
obj_t act_2964;
act_2964 = PROCEDURE_REF(env_2963, ((long)0));
{
obj_t x_1291;
{
bool_t aux_4850;
x_1291 = x_2965;
{
bool_t test_4851;
{
obj_t aux_4852;
aux_4852 = CDR(x_1291);
test_4851 = (aux_4852==act_2964);
}
if(test_4851){
aux_4850 = ((bool_t)0);
}
 else {
aux_4850 = ((bool_t)1);
}
}
return BBOOL(aux_4850);
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___lalr_expand()
{
module_initialization_70___error(((long)0), "__LALR_EXPAND");
module_initialization_70___lalr_util(((long)0), "__LALR_EXPAND");
module_initialization_70___lalr_gen(((long)0), "__LALR_EXPAND");
module_initialization_70___lalr_global(((long)0), "__LALR_EXPAND");
module_initialization_70___lalr_rewrite(((long)0), "__LALR_EXPAND");
module_initialization_70___type(((long)0), "__LALR_EXPAND");
module_initialization_70___bigloo(((long)0), "__LALR_EXPAND");
module_initialization_70___tvector(((long)0), "__LALR_EXPAND");
module_initialization_70___structure(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_numbers_6_5(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_characters_6_6(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_equivalence_6_2(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_booleans_6_1(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_symbols_6_4(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_strings_6_7(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_input_6_10_2(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_control_features_6_9(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_vectors_6_8(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_ports_6_10_1(((long)0), "__LALR_EXPAND");
module_initialization_70___r4_output_6_10_3(((long)0), "__LALR_EXPAND");
module_initialization_70___bit(((long)0), "__LALR_EXPAND");
return module_initialization_70___evenv(((long)0), "__LALR_EXPAND");
}

