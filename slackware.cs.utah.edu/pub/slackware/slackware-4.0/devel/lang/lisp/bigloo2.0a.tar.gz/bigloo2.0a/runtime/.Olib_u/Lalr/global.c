/*===========================================================================*/
/*   (Lalr/global.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

obj_t first_state_187___lalr_global = BUNSPEC;
obj_t first_shift_251___lalr_global = BUNSPEC;
obj_t nonterminals___lalr_global = BUNSPEC;
obj_t consistent___lalr_global = BUNSPEC;
static obj_t toplevel_init_63___lalr_global();
obj_t acces_symbol_228___lalr_global = BUNSPEC;
obj_t nitems___lalr_global = BUNSPEC;
obj_t last_state_163___lalr_global = BUNSPEC;
obj_t rrhs___lalr_global = BUNSPEC;
obj_t last_shift_62___lalr_global = BUNSPEC;
obj_t fderives___lalr_global = BUNSPEC;
obj_t action_table_22___lalr_global = BUNSPEC;
obj_t laruleno___lalr_global = BUNSPEC;
obj_t token_set_size_186___lalr_global = BUNSPEC;
obj_t kernel_end_41___lalr_global = BUNSPEC;
obj_t includes___lalr_global = BUNSPEC;
extern obj_t initialize_all_10___lalr_global();
obj_t kernel_base_67___lalr_global = BUNSPEC;
obj_t to_state_44___lalr_global = BUNSPEC;
obj_t nullable___lalr_global = BUNSPEC;
obj_t state_table_161___lalr_global = BUNSPEC;
obj_t shift_symbol_29___lalr_global = BUNSPEC;
obj_t final_state_208___lalr_global = BUNSPEC;
obj_t rlhs___lalr_global = BUNSPEC;
obj_t shift_set_155___lalr_global = BUNSPEC;
obj_t nvars___lalr_global = BUNSPEC;
extern obj_t module_initialization_70___lalr_global(long, char *);
extern obj_t module_initialization_70___error(long, char *);
obj_t nstates___lalr_global = BUNSPEC;
obj_t reduction_table_100___lalr_global = BUNSPEC;
obj_t state_table_size_33___lalr_global = BUNSPEC;
obj_t actions___lalr_global = BUNSPEC;
obj_t derives___lalr_global = BUNSPEC;
obj_t la___lalr_global = BUNSPEC;
obj_t last_reduction_147___lalr_global = BUNSPEC;
obj_t nshifts___lalr_global = BUNSPEC;
obj_t lookback___lalr_global = BUNSPEC;
obj_t ritem___lalr_global = BUNSPEC;
obj_t red_set_247___lalr_global = BUNSPEC;
obj_t lookaheads___lalr_global = BUNSPEC;
obj_t nsyms___lalr_global = BUNSPEC;
obj_t maxrhs___lalr_global = BUNSPEC;
obj_t grammar___lalr_global = BUNSPEC;
obj_t nrules___lalr_global = BUNSPEC;
obj_t ngotos___lalr_global = BUNSPEC;
obj_t nterms___lalr_global = BUNSPEC;
obj_t shift_table_147___lalr_global = BUNSPEC;
obj_t terminals___lalr_global = BUNSPEC;
obj_t first_reduction_146___lalr_global = BUNSPEC;
obj_t goto_map_48___lalr_global = BUNSPEC;
static obj_t imported_modules_init_94___lalr_global();
static obj_t require_initialization_114___lalr_global = BUNSPEC;
obj_t from_state_185___lalr_global = BUNSPEC;
static obj_t _initialize_all_212___lalr_global(obj_t);
obj_t f___lalr_global = BUNSPEC;
obj_t firsts___lalr_global = BUNSPEC;
extern obj_t make_vector(long, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( initialize_all_env_71___lalr_global, _initialize_all_212___lalr_global1174, _initialize_all_212___lalr_global, 0L, 0 );


/* module-initialization */obj_t module_initialization_70___lalr_global(long checksum_464, char * from_465)
{
if(CBOOL(require_initialization_114___lalr_global)){
require_initialization_114___lalr_global = BBOOL(((bool_t)0));
imported_modules_init_94___lalr_global();
toplevel_init_63___lalr_global();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* toplevel-init */obj_t toplevel_init_63___lalr_global()
{
rrhs___lalr_global = BFALSE;
rlhs___lalr_global = BFALSE;
ritem___lalr_global = BFALSE;
nullable___lalr_global = BFALSE;
derives___lalr_global = BFALSE;
fderives___lalr_global = BFALSE;
firsts___lalr_global = BFALSE;
kernel_base_67___lalr_global = BFALSE;
kernel_end_41___lalr_global = BFALSE;
shift_symbol_29___lalr_global = BFALSE;
shift_set_155___lalr_global = BFALSE;
red_set_247___lalr_global = BFALSE;
state_table_161___lalr_global = BFALSE;
acces_symbol_228___lalr_global = BFALSE;
reduction_table_100___lalr_global = BFALSE;
shift_table_147___lalr_global = BFALSE;
consistent___lalr_global = BFALSE;
lookaheads___lalr_global = BFALSE;
la___lalr_global = BFALSE;
laruleno___lalr_global = BFALSE;
lookback___lalr_global = BFALSE;
goto_map_48___lalr_global = BFALSE;
from_state_185___lalr_global = BFALSE;
to_state_44___lalr_global = BFALSE;
includes___lalr_global = BFALSE;
f___lalr_global = BFALSE;
action_table_22___lalr_global = BFALSE;
nitems___lalr_global = BFALSE;
nrules___lalr_global = BFALSE;
nvars___lalr_global = BFALSE;
nterms___lalr_global = BFALSE;
nsyms___lalr_global = BFALSE;
nstates___lalr_global = BFALSE;
first_state_187___lalr_global = BFALSE;
last_state_163___lalr_global = BFALSE;
final_state_208___lalr_global = BFALSE;
first_shift_251___lalr_global = BFALSE;
last_shift_62___lalr_global = BFALSE;
first_reduction_146___lalr_global = BFALSE;
last_reduction_147___lalr_global = BFALSE;
nshifts___lalr_global = BFALSE;
maxrhs___lalr_global = BFALSE;
ngotos___lalr_global = BFALSE;
token_set_size_186___lalr_global = BFALSE;
grammar___lalr_global = BFALSE;
terminals___lalr_global = BFALSE;
nonterminals___lalr_global = BFALSE;
actions___lalr_global = BFALSE;
return (state_table_size_33___lalr_global = BINT(((long)1009)),
BUNSPEC);
}


/* initialize-all */obj_t initialize_all_10___lalr_global()
{
rrhs___lalr_global = BFALSE;
rlhs___lalr_global = BFALSE;
ritem___lalr_global = BFALSE;
nullable___lalr_global = BFALSE;
derives___lalr_global = BFALSE;
fderives___lalr_global = BFALSE;
firsts___lalr_global = BFALSE;
kernel_base_67___lalr_global = BFALSE;
kernel_end_41___lalr_global = BFALSE;
shift_symbol_29___lalr_global = BFALSE;
shift_set_155___lalr_global = BFALSE;
red_set_247___lalr_global = BFALSE;
{
long aux_472;
aux_472 = (long)CINT(state_table_size_33___lalr_global);
state_table_161___lalr_global = make_vector(aux_472, BNIL);
}
acces_symbol_228___lalr_global = BFALSE;
reduction_table_100___lalr_global = BFALSE;
shift_table_147___lalr_global = BFALSE;
consistent___lalr_global = BFALSE;
lookaheads___lalr_global = BFALSE;
la___lalr_global = BFALSE;
laruleno___lalr_global = BFALSE;
lookback___lalr_global = BFALSE;
goto_map_48___lalr_global = BFALSE;
from_state_185___lalr_global = BFALSE;
to_state_44___lalr_global = BFALSE;
includes___lalr_global = BFALSE;
f___lalr_global = BFALSE;
action_table_22___lalr_global = BFALSE;
nstates___lalr_global = BFALSE;
first_state_187___lalr_global = BFALSE;
last_state_163___lalr_global = BFALSE;
final_state_208___lalr_global = BFALSE;
first_shift_251___lalr_global = BFALSE;
last_shift_62___lalr_global = BFALSE;
first_reduction_146___lalr_global = BFALSE;
last_reduction_147___lalr_global = BFALSE;
nshifts___lalr_global = BFALSE;
maxrhs___lalr_global = BFALSE;
ngotos___lalr_global = BFALSE;
token_set_size_186___lalr_global = BFALSE;
grammar___lalr_global = BFALSE;
terminals___lalr_global = BFALSE;
nonterminals___lalr_global = BFALSE;
return (actions___lalr_global = BFALSE,
BUNSPEC);
}


/* _initialize-all */obj_t _initialize_all_212___lalr_global(obj_t env_463)
{
return initialize_all_10___lalr_global();
}


/* imported-modules-init */obj_t imported_modules_init_94___lalr_global()
{
return module_initialization_70___error(((long)0), "__LALR_GLOBAL");
}

