/*===========================================================================*/
/*   (Engine/pass.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t stop_on_pass_198_engine_pass(obj_t, obj_t);
static obj_t _stop_on_pass1003_83_engine_pass(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t exit_bigloo_229_init_main(obj_t);
static obj_t imported_modules_init_94_engine_pass();
static obj_t toplevel_init_63_engine_pass();
static obj_t require_initialization_114_engine_pass = BUNSPEC;
extern obj_t _pass__125_engine_param;
obj_t _current_pass__25_engine_pass = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(stop_on_pass_env_207_engine_pass, _stop_on_pass1003_83_engine_pass1005, _stop_on_pass1003_83_engine_pass, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_engine_pass(long checksum_10, char *from_11)
{
   if (CBOOL(require_initialization_114_engine_pass))
     {
	require_initialization_114_engine_pass = BBOOL(((bool_t) 0));
	imported_modules_init_94_engine_pass();
	toplevel_init_63_engine_pass();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* toplevel-init */ obj_t 
toplevel_init_63_engine_pass()
{
   return (_current_pass__25_engine_pass = BNIL,
      BUNSPEC);
}


/* stop-on-pass */ obj_t 
stop_on_pass_198_engine_pass(obj_t pass_1, obj_t thunk_2)
{
   {
      bool_t test1002_4;
      {
	 obj_t obj1_5;
	 obj1_5 = _pass__125_engine_param;
	 test1002_4 = (obj1_5 == pass_1);
      }
      if (test1002_4)
	{
	   PROCEDURE_ENTRY(thunk_2) (thunk_2, BEOA);
	   return exit_bigloo_229_init_main(BINT(((long) 0)));
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _stop-on-pass1003 */ obj_t 
_stop_on_pass1003_83_engine_pass(obj_t env_7, obj_t pass_8, obj_t thunk_9)
{
   return stop_on_pass_198_engine_pass(pass_8, thunk_9);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_engine_pass()
{
   module_initialization_70_engine_param(((long) 0), "ENGINE_PASS");
   return module_initialization_70_init_main(((long) 0), "ENGINE_PASS");
}
