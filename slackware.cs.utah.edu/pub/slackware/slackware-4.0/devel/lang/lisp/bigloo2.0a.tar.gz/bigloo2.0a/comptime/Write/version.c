/*===========================================================================*/
/*   (Write/version.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
static obj_t display_to_column_161_write_version(obj_t, long, unsigned char);
extern obj_t string_append(obj_t, obj_t);
extern obj_t _verbose__1_engine_param;
extern obj_t _bigloo_version__168_engine_param;
extern obj_t _bigloo_level__187_engine_param;
static obj_t _version_write_version(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_write_version(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _short_version_78_write_version(obj_t);
extern obj_t version_write_version();
static obj_t imported_modules_init_94_write_version();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t write_char_165___r4_output_6_10_3(unsigned char, obj_t);
static obj_t _revision_write_version(obj_t);
static obj_t library_modules_init_112_write_version();
extern obj_t newline___r4_output_6_10_3(obj_t);
extern obj_t revision_write_version();
extern obj_t open_input_string(obj_t);
extern obj_t print___r4_output_6_10_3(obj_t);
extern obj_t _bigloo_author__68_engine_param;
extern obj_t _bigloo_date__70_engine_param;
extern obj_t make_string(long, unsigned char);
extern obj_t c_substring(obj_t, long, long);
static obj_t horse_write_version(obj_t);
extern obj_t short_version_52_write_version();
extern obj_t _bigloo_name__170_engine_param;
extern obj_t read___reader(obj_t);
extern obj_t _bigloo_email__0_engine_param;
static obj_t require_initialization_114_write_version = BUNSPEC;
static obj_t cnst_init_137_write_version();
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(revision_env_124_write_version, _revision_write_version1249, _revision_write_version, 0L, 0);
DEFINE_EXPORT_PROCEDURE(short_version_env_59_write_version, _short_version_78_write_version1250, _short_version_78_write_version, 0L, 0);
DEFINE_EXPORT_PROCEDURE(version_env_45_write_version, _version_write_version1251, _version_write_version, 0L, 0);
DEFINE_STRING(string1242_write_version, string1242_write_version1252, "(\"            ,--^, \" \"      _ ___/ /|/  \" \"  ,;'( )__, ) '   \" \" ;;  //   L__.    \" #\" '   \\\\    /  '    \" \"      ^   ^       \") DONE ", 135);
DEFINE_STRING(string1241_write_version, string1241_write_version1253, " ainsi qu'a Marcel Lebas, mon grand-pere, decede le 29 Octobre 1998.", 68);
DEFINE_STRING(string1239_write_version, string1239_write_version1254, " ", 1);
DEFINE_STRING(string1240_write_version, string1240_write_version1255, " Ce travail est dedie a Nelly Lebas, ma grand-mere, decedee le 10 Mars 1995,", 76);
DEFINE_STRING(string1238_write_version, string1238_write_version1256, "`a practical Scheme compiler'", 29);
DEFINE_STRING(string1237_write_version, string1237_write_version1257, "email:", 6);
DEFINE_STRING(string1236_write_version, string1236_write_version1258, " (level ", 8);
DEFINE_STRING(string1235_write_version, string1235_write_version1259, ")", 1);
DEFINE_STRING(string1234_write_version, string1234_write_version1260, "", 0);


/* module-initialization */ obj_t 
module_initialization_70_write_version(long checksum_152, char *from_153)
{
   if (CBOOL(require_initialization_114_write_version))
     {
	require_initialization_114_write_version = BBOOL(((bool_t) 0));
	library_modules_init_112_write_version();
	cnst_init_137_write_version();
	imported_modules_init_94_write_version();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_write_version()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "WRITE_VERSION");
   module_initialization_70___r4_strings_6_7(((long) 0), "WRITE_VERSION");
   module_initialization_70___reader(((long) 0), "WRITE_VERSION");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_write_version()
{
   {
      obj_t cnst_port_138_144;
      cnst_port_138_144 = open_input_string(string1242_write_version);
      {
	 long i_145;
	 i_145 = ((long) 1);
       loop_146:
	 {
	    bool_t test1243_147;
	    test1243_147 = (i_145 == ((long) -1));
	    if (test1243_147)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1244_148;
		    {
		       obj_t list1245_149;
		       {
			  obj_t arg1247_150;
			  arg1247_150 = BNIL;
			  list1245_149 = MAKE_PAIR(cnst_port_138_144, arg1247_150);
		       }
		       arg1244_148 = read___reader(list1245_149);
		    }
		    CNST_TABLE_SET(i_145, arg1244_148);
		 }
		 {
		    int aux_151;
		    {
		       long aux_169;
		       aux_169 = (i_145 - ((long) 1));
		       aux_151 = (int) (aux_169);
		    }
		    {
		       long i_172;
		       i_172 = (long) (aux_151);
		       i_145 = i_172;
		       goto loop_146;
		    }
		 }
	      }
	 }
      }
   }
}


/* revision */ obj_t 
revision_write_version()
{
   {
      obj_t arg1002_5;
      {
	 bool_t test1006_9;
	 {
	    obj_t obj_96;
	    obj_96 = _bigloo_level__187_engine_param;
	    test1006_9 = CHARP(obj_96);
	 }
	 if (test1006_9)
	   {
	      arg1002_5 = _bigloo_level__187_engine_param;
	   }
	 else
	   {
	      arg1002_5 = string1234_write_version;
	   }
      }
      {
	 obj_t list1003_6;
	 {
	    obj_t arg1004_7;
	    arg1004_7 = MAKE_PAIR(arg1002_5, BNIL);
	    list1003_6 = MAKE_PAIR(_bigloo_version__168_engine_param, arg1004_7);
	 }
	 return print___r4_output_6_10_3(list1003_6);
      }
   }
}


/* _revision */ obj_t 
_revision_write_version(obj_t env_141)
{
   return revision_write_version();
}


/* short-version */ obj_t 
short_version_52_write_version()
{
   {
      obj_t arg1007_10;
      {
	 bool_t test1012_14;
	 {
	    obj_t obj_97;
	    obj_97 = _bigloo_level__187_engine_param;
	    test1012_14 = CHARP(obj_97);
	 }
	 if (test1012_14)
	   {
	      obj_t arg1016_16;
	      {
		 obj_t list1033_22;
		 list1033_22 = MAKE_PAIR(_bigloo_level__187_engine_param, BNIL);
		 {
		    obj_t res1232_104;
		    {
		       unsigned char aux_187;
		       long aux_183;
		       {
			  obj_t aux_188;
			  aux_188 = CAR(list1033_22);
			  aux_187 = (unsigned char) CCHAR(aux_188);
		       }
		       {
			  int aux_184;
			  aux_184 = (int) (((long) 1));
			  aux_183 = (long) (aux_184);
		       }
		       res1232_104 = make_string(aux_183, aux_187);
		    }
		    arg1016_16 = res1232_104;
		 }
	      }
	      {
		 obj_t list1019_18;
		 {
		    obj_t arg1020_19;
		    {
		       obj_t arg1025_20;
		       arg1025_20 = MAKE_PAIR(string1235_write_version, BNIL);
		       arg1020_19 = MAKE_PAIR(arg1016_16, arg1025_20);
		    }
		    list1019_18 = MAKE_PAIR(string1236_write_version, arg1020_19);
		 }
		 arg1007_10 = string_append_106___r4_strings_6_7(list1019_18);
	      }
	   }
	 else
	   {
	      arg1007_10 = string1234_write_version;
	   }
      }
      {
	 obj_t list1008_11;
	 {
	    obj_t arg1009_12;
	    arg1009_12 = MAKE_PAIR(arg1007_10, BNIL);
	    list1008_11 = MAKE_PAIR(_bigloo_name__170_engine_param, arg1009_12);
	 }
	 return print___r4_output_6_10_3(list1008_11);
      }
   }
}


/* _short-version */ obj_t 
_short_version_78_write_version(obj_t env_142)
{
   return short_version_52_write_version();
}


/* version */ obj_t 
version_write_version()
{
   display_to_column_161_write_version(string1234_write_version, ((long) 79), ((unsigned char) '-'));
   newline___r4_output_6_10_3(BNIL);
   {
      obj_t arg1038_25;
      obj_t arg1040_27;
      {
	 obj_t arg1060_36;
	 {
	    bool_t test1067_37;
	    {
	       obj_t obj_105;
	       obj_105 = _bigloo_level__187_engine_param;
	       test1067_37 = CHARP(obj_105);
	    }
	    if (test1067_37)
	      {
		 obj_t arg1137_39;
		 {
		    obj_t list1151_45;
		    list1151_45 = MAKE_PAIR(_bigloo_level__187_engine_param, BNIL);
		    {
		       obj_t res1233_112;
		       {
			  unsigned char aux_209;
			  long aux_205;
			  {
			     obj_t aux_210;
			     aux_210 = CAR(list1151_45);
			     aux_209 = (unsigned char) CCHAR(aux_210);
			  }
			  {
			     int aux_206;
			     aux_206 = (int) (((long) 1));
			     aux_205 = (long) (aux_206);
			  }
			  res1233_112 = make_string(aux_205, aux_209);
		       }
		       arg1137_39 = res1233_112;
		    }
		 }
		 {
		    obj_t list1143_41;
		    {
		       obj_t arg1144_42;
		       {
			  obj_t arg1145_43;
			  arg1145_43 = MAKE_PAIR(string1235_write_version, BNIL);
			  arg1144_42 = MAKE_PAIR(arg1137_39, arg1145_43);
		       }
		       list1143_41 = MAKE_PAIR(string1236_write_version, arg1144_42);
		    }
		    arg1060_36 = string_append_106___r4_strings_6_7(list1143_41);
		 }
	      }
	    else
	      {
		 arg1060_36 = string1234_write_version;
	      }
	 }
	 arg1038_25 = string_append(_bigloo_name__170_engine_param, arg1060_36);
      }
      {
	 bool_t test1158_47;
	 {
	    unsigned char arg1175_50;
	    {
	       obj_t string_113;
	       string_113 = _bigloo_date__70_engine_param;
	       arg1175_50 = STRING_REF(string_113, ((long) 0));
	    }
	    test1158_47 = (arg1175_50 == ((unsigned char) ' '));
	 }
	 if (test1158_47)
	   {
	      long arg1163_49;
	      {
		 obj_t string_117;
		 string_117 = _bigloo_date__70_engine_param;
		 arg1163_49 = STRING_LENGTH(string_117);
	      }
	      {
		 obj_t string_118;
		 string_118 = _bigloo_date__70_engine_param;
		 arg1040_27 = c_substring(string_118, ((long) 1), arg1163_49);
	      }
	   }
	 else
	   {
	      arg1040_27 = _bigloo_date__70_engine_param;
	   }
      }
      {
	 obj_t list1042_29;
	 {
	    obj_t arg1053_30;
	    {
	       obj_t arg1055_31;
	       {
		  obj_t arg1056_32;
		  {
		     obj_t arg1057_33;
		     {
			obj_t arg1058_34;
			arg1058_34 = MAKE_PAIR(_bigloo_email__0_engine_param, BNIL);
			arg1057_33 = MAKE_PAIR(string1237_write_version, arg1058_34);
		     }
		     arg1056_32 = MAKE_PAIR(_bigloo_author__68_engine_param, arg1057_33);
		  }
		  arg1055_31 = MAKE_PAIR(arg1040_27, arg1056_32);
	       }
	       arg1053_30 = MAKE_PAIR(string1238_write_version, arg1055_31);
	    }
	    list1042_29 = MAKE_PAIR(arg1038_25, arg1053_30);
	 }
	 horse_write_version(list1042_29);
      }
   }
   {
      bool_t test1177_51;
      {
	 long n1_121;
	 n1_121 = (long) CINT(_verbose__1_engine_param);
	 test1177_51 = (n1_121 >= ((long) 3));
      }
      if (test1177_51)
	{
	   display_to_column_161_write_version(string1239_write_version, ((long) 78), ((unsigned char) '-'));
	   newline___r4_output_6_10_3(BNIL);
	   {
	      obj_t list1179_53;
	      {
		 obj_t arg1188_55;
		 {
		    obj_t aux_236;
		    aux_236 = BCHAR(((unsigned char) '\n'));
		    arg1188_55 = MAKE_PAIR(aux_236, BNIL);
		 }
		 list1179_53 = MAKE_PAIR(string1240_write_version, arg1188_55);
	      }
	      verbose_tools_speek(BINT(((long) 3)), list1179_53);
	   }
	   {
	      obj_t list1191_57;
	      {
		 obj_t arg1193_59;
		 {
		    obj_t aux_242;
		    aux_242 = BCHAR(((unsigned char) '\n'));
		    arg1193_59 = MAKE_PAIR(aux_242, BNIL);
		 }
		 list1191_57 = MAKE_PAIR(string1241_write_version, arg1193_59);
	      }
	      verbose_tools_speek(BINT(((long) 3)), list1191_57);
	   }
	}
      else
	{
	   BUNSPEC;
	}
   }
   display_to_column_161_write_version(string1234_write_version, ((long) 79), ((unsigned char) '-'));
   newline___r4_output_6_10_3(BNIL);
   return newline___r4_output_6_10_3(BNIL);
}


/* _version */ obj_t 
_version_write_version(obj_t env_143)
{
   return version_write_version();
}


/* horse */ obj_t 
horse_write_version(obj_t l_1)
{
   {
      obj_t l_63;
      obj_t horse_64;
      l_63 = l_1;
      horse_64 = CNST_TABLE_REF(((long) 1));
    loop_65:
      if (NULLP(l_63))
	{
	   if (NULLP(horse_64))
	     {
		return CNST_TABLE_REF(((long) 0));
	     }
	   else
	     {
		display_to_column_161_write_version(string1234_write_version, ((long) 62), ((unsigned char) ' '));
		{
		   obj_t list1201_70;
		   {
		      obj_t aux_258;
		      aux_258 = CAR(horse_64);
		      list1201_70 = MAKE_PAIR(aux_258, BNIL);
		   }
		   print___r4_output_6_10_3(list1201_70);
		}
		{
		   obj_t horse_263;
		   obj_t l_262;
		   l_262 = BNIL;
		   horse_263 = CDR(horse_64);
		   horse_64 = horse_263;
		   l_63 = l_262;
		   goto loop_65;
		}
	     }
	}
      else
	{
	   if (NULLP(horse_64))
	     {
		{
		   obj_t list1207_76;
		   {
		      obj_t aux_267;
		      aux_267 = CAR(l_63);
		      list1207_76 = MAKE_PAIR(aux_267, BNIL);
		   }
		   print___r4_output_6_10_3(list1207_76);
		}
		{
		   obj_t horse_273;
		   obj_t l_271;
		   l_271 = CDR(l_63);
		   horse_273 = BNIL;
		   horse_64 = horse_273;
		   l_63 = l_271;
		   goto loop_65;
		}
	     }
	   else
	     {
		display_to_column_161_write_version(CAR(l_63), ((long) 62), ((unsigned char) ' '));
		{
		   obj_t list1217_83;
		   {
		      obj_t aux_276;
		      aux_276 = CAR(horse_64);
		      list1217_83 = MAKE_PAIR(aux_276, BNIL);
		   }
		   print___r4_output_6_10_3(list1217_83);
		}
		{
		   obj_t horse_282;
		   obj_t l_280;
		   l_280 = CDR(l_63);
		   horse_282 = CDR(horse_64);
		   horse_64 = horse_282;
		   l_63 = l_280;
		   goto loop_65;
		}
	     }
	}
   }
}


/* display-to-column */ obj_t 
display_to_column_161_write_version(obj_t string_2, long column_3, unsigned char char_4)
{
   display___r4_output_6_10_3(string_2, BNIL);
   {
      long l_88;
      {
	 long aux_292;
	 aux_292 = STRING_LENGTH(string_2);
	 l_88 = (((long) 1) + aux_292);
      }
    loop_89:
      if ((l_88 == column_3))
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   write_char_165___r4_output_6_10_3(char_4, BNIL);
	   {
	      long l_290;
	      l_290 = (l_88 + ((long) 1));
	      l_88 = l_290;
	      goto loop_89;
	   }
	}
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_write_version()
{
   module_initialization_70_engine_param(((long) 0), "WRITE_VERSION");
   return module_initialization_70_tools_speek(((long) 0), "WRITE_VERSION");
}
