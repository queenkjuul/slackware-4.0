/*===========================================================================*/
/*   (Type/pptype.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


static obj_t method_init_76_type_pptype();
static obj_t _variable_type__string1258_208_type_pptype(obj_t, obj_t);
static obj_t _function_type__string1257_65_type_pptype(obj_t, obj_t);
extern obj_t module_initialization_70_type_pptype(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t imported_modules_init_94_type_pptype();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
extern obj_t variable_type__string_186_type_pptype(variable_t);
static obj_t library_modules_init_112_type_pptype();
extern obj_t string_to_bstring(char *);
static obj_t loop_type_pptype(obj_t);
extern obj_t function_type__string_79_type_pptype(variable_t);
static obj_t require_initialization_114_type_pptype = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(variable_type__string_env_196_type_pptype, _variable_type__string1258_208_type_pptype1262, _variable_type__string1258_208_type_pptype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(function_type__string_env_141_type_pptype, _function_type__string1257_65_type_pptype1263, _function_type__string1257_65_type_pptype, 0L, 1);
DEFINE_STRING(string1259_type_pptype, string1259_type_pptype1264, " -> ", 4);
DEFINE_STRING(string1260_type_pptype, string1260_type_pptype1265, "", 0);


/* module-initialization */ obj_t 
module_initialization_70_type_pptype(long checksum_486, char *from_487)
{
   if (CBOOL(require_initialization_114_type_pptype))
     {
	require_initialization_114_type_pptype = BBOOL(((bool_t) 0));
	library_modules_init_112_type_pptype();
	imported_modules_init_94_type_pptype();
	method_init_76_type_pptype();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_type_pptype()
{
   module_initialization_70___r4_strings_6_7(((long) 0), "TYPE_PPTYPE");
   return BUNSPEC;
}


/* function-type->string */ obj_t 
function_type__string_79_type_pptype(variable_t variable_2)
{
   {
      obj_t arg1190_308;
      obj_t arg1192_310;
      {
	 obj_t aux_495;
	 {
	    sfun_t obj_467;
	    {
	       value_t aux_496;
	       aux_496 = (((variable_t) CREF(variable_2))->value);
	       obj_467 = (sfun_t) (aux_496);
	    }
	    aux_495 = (((sfun_t) CREF(obj_467))->args);
	 }
	 arg1190_308 = loop_type_pptype(aux_495);
      }
      {
	 obj_t arg1216_333;
	 {
	    obj_t aux_501;
	    {
	       type_t arg1220_335;
	       arg1220_335 = (((variable_t) CREF(variable_2))->type);
	       aux_501 = (((type_t) CREF(arg1220_335))->id);
	    }
	    arg1216_333 = SYMBOL_TO_STRING(aux_501);
	 }
	 arg1192_310 = string_downcase_77___r4_strings_6_7(arg1216_333);
      }
      {
	 obj_t list1193_311;
	 {
	    obj_t arg1194_312;
	    {
	       obj_t arg1195_313;
	       arg1195_313 = MAKE_PAIR(arg1192_310, BNIL);
	       arg1194_312 = MAKE_PAIR(string1259_type_pptype, arg1195_313);
	    }
	    list1193_311 = MAKE_PAIR(arg1190_308, arg1194_312);
	 }
	 return string_append_106___r4_strings_6_7(list1193_311);
      }
   }
}


/* loop */ obj_t 
loop_type_pptype(obj_t args_315)
{
   if (NULLP(args_315))
     {
	return string1260_type_pptype;
     }
   else
     {
	obj_t arg1199_319;
	char *arg1200_320;
	obj_t arg1201_321;
	{
	   obj_t arg1206_326;
	   {
	      obj_t aux_512;
	      {
		 type_t arg1209_328;
		 {
		    local_t obj_470;
		    {
		       obj_t aux_513;
		       aux_513 = CAR(args_315);
		       obj_470 = (local_t) (aux_513);
		    }
		    arg1209_328 = (((local_t) CREF(obj_470))->type);
		 }
		 aux_512 = (((type_t) CREF(arg1209_328))->id);
	      }
	      arg1206_326 = SYMBOL_TO_STRING(aux_512);
	   }
	   arg1199_319 = string_downcase_77___r4_strings_6_7(arg1206_326);
	}
	{
	   bool_t test_520;
	   {
	      obj_t aux_521;
	      aux_521 = CDR(args_315);
	      test_520 = NULLP(aux_521);
	   }
	   if (test_520)
	     {
		arg1200_320 = "";
	     }
	   else
	     {
		arg1200_320 = " x ";
	     }
	}
	arg1201_321 = loop_type_pptype(CDR(args_315));
	{
	   obj_t list1202_322;
	   {
	      obj_t arg1203_323;
	      {
		 obj_t arg1204_324;
		 arg1204_324 = MAKE_PAIR(arg1201_321, BNIL);
		 {
		    obj_t aux_527;
		    aux_527 = string_to_bstring(arg1200_320);
		    arg1203_323 = MAKE_PAIR(aux_527, arg1204_324);
		 }
	      }
	      list1202_322 = MAKE_PAIR(arg1199_319, arg1203_323);
	   }
	   return string_append_106___r4_strings_6_7(list1202_322);
	}
     }
}


/* _function-type->string1257 */ obj_t 
_function_type__string1257_65_type_pptype(obj_t env_482, obj_t variable_483)
{
   return function_type__string_79_type_pptype((variable_t) (variable_483));
}


/* variable-type->string */ obj_t 
variable_type__string_186_type_pptype(variable_t variable_3)
{
   {
      obj_t arg1221_336;
      {
	 obj_t aux_534;
	 {
	    type_t arg1224_338;
	    arg1224_338 = (((variable_t) CREF(variable_3))->type);
	    aux_534 = (((type_t) CREF(arg1224_338))->id);
	 }
	 arg1221_336 = SYMBOL_TO_STRING(aux_534);
      }
      return string_downcase_77___r4_strings_6_7(arg1221_336);
   }
}


/* _variable-type->string1258 */ obj_t 
_variable_type__string1258_208_type_pptype(obj_t env_484, obj_t variable_485)
{
   return variable_type__string_186_type_pptype((variable_t) (variable_485));
}


/* method-init */ obj_t 
method_init_76_type_pptype()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_type_pptype()
{
   module_initialization_70_type_type(((long) 0), "TYPE_PPTYPE");
   return module_initialization_70_ast_var(((long) 0), "TYPE_PPTYPE");
}
