/*===========================================================================*/
/*   (Bdb/walk.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_bdb_walk();
extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
static obj_t _bdb_walk__166_bdb_walk(obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_bdb_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70_bdb_initialize(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t imported_modules_init_94_bdb_walk();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_bdb_walk();
extern obj_t open_input_string(obj_t);
extern obj_t initialize_ast_128_bdb_initialize();
extern obj_t string_to_bstring(char *);
extern obj_t bdb_walk__231_bdb_walk(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_bdb_walk = BUNSPEC;
static obj_t cnst_init_137_bdb_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(bdb_walk__env_198_bdb_walk, _bdb_walk__166_bdb_walk1586, _bdb_walk__166_bdb_walk, 0L, 1);
DEFINE_STRING(string1579_bdb_walk, string1579_bdb_walk1587, "failure during postlude hook", 28);
DEFINE_STRING(string1580_bdb_walk, string1580_bdb_walk1588, "PASS-STARTED ", 13);
DEFINE_STRING(string1578_bdb_walk, string1578_bdb_walk1589, " error", 6);
DEFINE_STRING(string1577_bdb_walk, string1577_bdb_walk1590, " occured, ending ...", 20);
DEFINE_STRING(string1576_bdb_walk, string1576_bdb_walk1591, "failure during prelude hook", 27);
DEFINE_STRING(string1575_bdb_walk, string1575_bdb_walk1592, "   . ", 5);
DEFINE_STRING(string1574_bdb_walk, string1574_bdb_walk1593, "Bdb", 3);


/* module-initialization */ obj_t 
module_initialization_70_bdb_walk(long checksum_1092, char *from_1093)
{
   if (CBOOL(require_initialization_114_bdb_walk))
     {
	require_initialization_114_bdb_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_bdb_walk();
	cnst_init_137_bdb_walk();
	imported_modules_init_94_bdb_walk();
	method_init_76_bdb_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_bdb_walk()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "BDB_WALK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "BDB_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "BDB_WALK");
   module_initialization_70___reader(((long) 0), "BDB_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_bdb_walk()
{
   {
      obj_t cnst_port_138_1084;
      cnst_port_138_1084 = open_input_string(string1580_bdb_walk);
      {
	 long i_1085;
	 i_1085 = ((long) 0);
       loop_1086:
	 {
	    bool_t test1581_1087;
	    test1581_1087 = (i_1085 == ((long) -1));
	    if (test1581_1087)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1582_1088;
		    {
		       obj_t list1583_1089;
		       {
			  obj_t arg1584_1090;
			  arg1584_1090 = BNIL;
			  list1583_1089 = MAKE_PAIR(cnst_port_138_1084, arg1584_1090);
		       }
		       arg1582_1088 = read___reader(list1583_1089);
		    }
		    CNST_TABLE_SET(i_1085, arg1582_1088);
		 }
		 {
		    int aux_1091;
		    {
		       long aux_1111;
		       aux_1111 = (i_1085 - ((long) 1));
		       aux_1091 = (int) (aux_1111);
		    }
		    {
		       long i_1114;
		       i_1114 = (long) (aux_1091);
		       i_1085 = i_1114;
		       goto loop_1086;
		    }
		 }
	      }
	 }
      }
   }
}


/* bdb-walk! */ obj_t 
bdb_walk__231_bdb_walk(obj_t globals_1)
{
   {
      obj_t list1435_693;
      {
	 obj_t arg1437_695;
	 {
	    obj_t arg1440_697;
	    {
	       obj_t aux_1116;
	       aux_1116 = BCHAR(((unsigned char) '\n'));
	       arg1440_697 = MAKE_PAIR(aux_1116, BNIL);
	    }
	    arg1437_695 = MAKE_PAIR(string1574_bdb_walk, arg1440_697);
	 }
	 list1435_693 = MAKE_PAIR(string1575_bdb_walk, arg1437_695);
      }
      verbose_tools_speek(BINT(((long) 1)), list1435_693);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1574_bdb_walk;
   {
      obj_t hooks_699;
      obj_t hnames_700;
      hooks_699 = BNIL;
      hnames_700 = BNIL;
    loop_701:
      if (NULLP(hooks_699))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1447_706;
	   {
	      obj_t fun1455_712;
	      fun1455_712 = CAR(hooks_699);
	      {
		 obj_t aux_1128;
		 aux_1128 = PROCEDURE_ENTRY(fun1455_712) (fun1455_712, BEOA);
		 test1447_706 = CBOOL(aux_1128);
	      }
	   }
	   if (test1447_706)
	     {
		{
		   obj_t hnames_1135;
		   obj_t hooks_1133;
		   hooks_1133 = CDR(hooks_699);
		   hnames_1135 = CDR(hnames_700);
		   hnames_700 = hnames_1135;
		   hooks_699 = hooks_1133;
		   goto loop_701;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1574_bdb_walk, string1576_bdb_walk, CAR(hnames_700));
	     }
	}
   }
   {
      obj_t value_713;
      {
	 obj_t arg1483_739;
	 arg1483_739 = initialize_ast_128_bdb_initialize();
	 value_713 = append_2_18___r4_pairs_and_lists_6_3(arg1483_739, globals_1);
      }
      {
	 bool_t test1456_714;
	 {
	    long n1_1071;
	    n1_1071 = (long) CINT(_nb_error_on_pass__70_tools_error);
	    test1456_714 = (n1_1071 > ((long) 0));
	 }
	 if (test1456_714)
	   {
	      {
		 char *arg1461_717;
		 {
		    bool_t test1469_724;
		    {
		       bool_t test1470_725;
		       {
			  obj_t obj_1073;
			  obj_1073 = _nb_error_on_pass__70_tools_error;
			  test1470_725 = INTEGERP(obj_1073);
		       }
		       if (test1470_725)
			 {
			    test1469_724 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
			 }
		       else
			 {
			    test1469_724 = ((bool_t) 0);
			 }
		    }
		    if (test1469_724)
		      {
			 arg1461_717 = "s";
		      }
		    else
		      {
			 arg1461_717 = "";
		      }
		 }
		 {
		    obj_t list1464_719;
		    {
		       obj_t arg1465_720;
		       {
			  obj_t arg1466_721;
			  {
			     obj_t arg1467_722;
			     arg1467_722 = MAKE_PAIR(string1577_bdb_walk, BNIL);
			     {
				obj_t aux_1150;
				aux_1150 = string_to_bstring(arg1461_717);
				arg1466_721 = MAKE_PAIR(aux_1150, arg1467_722);
			     }
			  }
			  arg1465_720 = MAKE_PAIR(string1578_bdb_walk, arg1466_721);
		       }
		       list1464_719 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1465_720);
		    }
		    fprint___r4_output_6_10_3(current_error_port, list1464_719);
		 }
	      }
	      {
		 obj_t res1573_1075;
		 exit(((long) -1));
		 res1573_1075 = BINT(((long) -1));
		 return res1573_1075;
	      }
	   }
	 else
	   {
	      obj_t hooks_726;
	      obj_t hnames_727;
	      hooks_726 = BNIL;
	      hnames_727 = BNIL;
	    loop_728:
	      if (NULLP(hooks_726))
		{
		   return value_713;
		}
	      else
		{
		   bool_t test1476_733;
		   {
		      obj_t fun1481_738;
		      fun1481_738 = CAR(hooks_726);
		      {
			 obj_t aux_1161;
			 aux_1161 = PROCEDURE_ENTRY(fun1481_738) (fun1481_738, BEOA);
			 test1476_733 = CBOOL(aux_1161);
		      }
		   }
		   if (test1476_733)
		     {
			{
			   obj_t hnames_1168;
			   obj_t hooks_1166;
			   hooks_1166 = CDR(hooks_726);
			   hnames_1168 = CDR(hnames_727);
			   hnames_727 = hnames_1168;
			   hooks_726 = hooks_1166;
			   goto loop_728;
			}
		     }
		   else
		     {
			return internal_error_43_tools_error(_current_pass__25_engine_pass, string1579_bdb_walk, CAR(hnames_727));
		     }
		}
	   }
      }
   }
}


/* _bdb-walk! */ obj_t 
_bdb_walk__166_bdb_walk(obj_t env_1082, obj_t globals_1083)
{
   return bdb_walk__231_bdb_walk(globals_1083);
}


/* method-init */ obj_t 
method_init_76_bdb_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_bdb_walk()
{
   module_initialization_70_tools_speek(((long) 0), "BDB_WALK");
   module_initialization_70_tools_error(((long) 0), "BDB_WALK");
   module_initialization_70_engine_pass(((long) 0), "BDB_WALK");
   module_initialization_70_tools_shape(((long) 0), "BDB_WALK");
   module_initialization_70_engine_param(((long) 0), "BDB_WALK");
   module_initialization_70_type_type(((long) 0), "BDB_WALK");
   module_initialization_70_ast_var(((long) 0), "BDB_WALK");
   module_initialization_70_ast_node(((long) 0), "BDB_WALK");
   module_initialization_70_ast_remove(((long) 0), "BDB_WALK");
   return module_initialization_70_bdb_initialize(((long) 0), "BDB_WALK");
}
