/*===========================================================================*/
/*   (Eval/expd-let.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t expand_eval_labels_169___expander_let(obj_t, obj_t);
static obj_t _expand_eval_let_26___expander_let(obj_t, obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t list1540___expander_let = BUNSPEC;
static obj_t _expand_eval_labels_129___expander_let(obj_t, obj_t, obj_t);
static obj_t _expand_eval_let__12___expander_let(obj_t, obj_t, obj_t);
extern obj_t replace__160___progn(obj_t, obj_t);
extern obj_t expand_eval_letrec_133___expander_let(obj_t, obj_t);
static obj_t _expand_eval_letrec_176___expander_let(obj_t, obj_t, obj_t);
extern obj_t expand_eval_let__60___expander_let(obj_t, obj_t);
static obj_t loop___expander_let(obj_t, obj_t);
extern obj_t module_initialization_70___expander_let(long, char *);
extern obj_t module_initialization_70___progn(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t expand_eval_let_110___expander_let(obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t imported_modules_init_94___expander_let();
static obj_t require_initialization_114___expander_let = BUNSPEC;
extern obj_t normalize_progn_143___progn(obj_t);
static obj_t cnst_init_137___expander_let();
static obj_t symbol1547___expander_let = BUNSPEC;
static obj_t symbol1543___expander_let = BUNSPEC;
static obj_t symbol1542___expander_let = BUNSPEC;
static obj_t symbol1541___expander_let = BUNSPEC;
static obj_t symbol1536___expander_let = BUNSPEC;
static obj_t symbol1535___expander_let = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( expand_eval_labels_env_182___expander_let, _expand_eval_labels_129___expander_let1550, _expand_eval_labels_129___expander_let, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( expand_eval_letrec_env_248___expander_let, _expand_eval_letrec_176___expander_let1551, _expand_eval_letrec_176___expander_let, 0L, 2 );
DEFINE_STRING( string1548___expander_let, string1548___expander_let1552, "expand-labels", 13 );
DEFINE_STRING( string1546___expander_let, string1546___expander_let1553, "letrec", 6 );
DEFINE_STRING( string1545___expander_let, string1545___expander_let1554, "Illegal form", 12 );
DEFINE_STRING( string1544___expander_let, string1544___expander_let1555, "expand-let*", 11 );
DEFINE_STRING( string1539___expander_let, string1539___expander_let1556, "let", 3 );
DEFINE_STRING( string1538___expander_let, string1538___expander_let1557, "Illegal `let' form", 18 );
DEFINE_STRING( string1537___expander_let, string1537___expander_let1558, "expand-let", 10 );
DEFINE_EXPORT_PROCEDURE( expand_eval_let__env_46___expander_let, _expand_eval_let__12___expander_let1559, _expand_eval_let__12___expander_let, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( expand_eval_let_env_128___expander_let, _expand_eval_let_26___expander_let1560, _expand_eval_let_26___expander_let, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___expander_let(long checksum_1296, char * from_1297)
{
if(CBOOL(require_initialization_114___expander_let)){
require_initialization_114___expander_let = BBOOL(((bool_t)0));
cnst_init_137___expander_let();
imported_modules_init_94___expander_let();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___expander_let()
{
symbol1535___expander_let = string_to_symbol("LAMBDA");
symbol1536___expander_let = string_to_symbol("LETREC");
symbol1541___expander_let = string_to_symbol("UNSPECIFIED");
list1540___expander_let = MAKE_PAIR(symbol1541___expander_let, BNIL);
symbol1542___expander_let = string_to_symbol("LET");
symbol1543___expander_let = string_to_symbol("LET*");
return (symbol1547___expander_let = string_to_symbol("SET!"),
BUNSPEC);
}


/* expand-eval-let */obj_t expand_eval_let_110___expander_let(obj_t x_1, obj_t e_2)
{
{
obj_t res_324;
{
obj_t bindings_331;
obj_t body_332;
obj_t loop_327;
obj_t bindings_328;
obj_t body_329;
obj_t body_325;
if(PAIRP(x_1)){
obj_t cdr_111_186_337;
cdr_111_186_337 = CDR(x_1);
if(PAIRP(cdr_111_186_337)){
obj_t cdr_114_48_339;
cdr_114_48_339 = CDR(cdr_111_186_337);
{
bool_t test_1316;
{
obj_t aux_1317;
aux_1317 = CAR(cdr_111_186_337);
test_1316 = (aux_1317==BNIL);
}
if(test_1316){
if((cdr_114_48_339==BNIL)){
obj_t car_128_220_343;
obj_t cdr_129_16_344;
car_128_220_343 = CAR(cdr_111_186_337);
cdr_129_16_344 = CDR(cdr_111_186_337);
if(SYMBOLP(car_128_220_343)){
if(PAIRP(cdr_129_16_344)){
obj_t cdr_136_29_347;
cdr_136_29_347 = CDR(cdr_129_16_344);
if((cdr_136_29_347==BNIL)){
obj_t car_148_109_350;
car_148_109_350 = CAR(cdr_111_186_337);
if(PAIRP(car_148_109_350)){
bindings_331 = car_148_109_350;
body_332 = CDR(cdr_111_186_337);
tag_103_156_333:
{
obj_t body_460;
obj_t vars_vals_190_461;
body_460 = normalize_progn_143___progn(body_332);
{
obj_t bindings_478;
obj_t vars_479;
obj_t vals_480;
bindings_478 = bindings_331;
vars_479 = BNIL;
vals_480 = BNIL;
loop_481:
if(NULLP(bindings_478)){
vars_vals_190_461 = MAKE_PAIR(vars_479, vals_480);
}
 else {
bool_t test_1338;
{
obj_t aux_1339;
aux_1339 = CAR(bindings_478);
test_1338 = PAIRP(aux_1339);
}
if(test_1338){
{
obj_t arg1136_486;
obj_t arg1137_487;
obj_t arg1139_488;
arg1136_486 = CDR(bindings_478);
{
obj_t aux_1343;
{
obj_t aux_1344;
aux_1344 = CAR(bindings_478);
aux_1343 = CAR(aux_1344);
}
arg1137_487 = MAKE_PAIR(aux_1343, vars_479);
}
{
obj_t arg1142_491;
{
obj_t aux_1348;
{
obj_t aux_1349;
aux_1349 = CAR(bindings_478);
aux_1348 = CDR(aux_1349);
}
arg1142_491 = normalize_progn_143___progn(aux_1348);
}
arg1139_488 = MAKE_PAIR(arg1142_491, vals_480);
}
{
obj_t vals_1356;
obj_t vars_1355;
obj_t bindings_1354;
bindings_1354 = arg1136_486;
vars_1355 = arg1137_487;
vals_1356 = arg1139_488;
vals_480 = vals_1356;
vars_479 = vars_1355;
bindings_478 = bindings_1354;
goto loop_481;
}
}
}
 else {
{
obj_t arg1145_494;
obj_t arg1146_495;
obj_t arg1147_496;
arg1145_494 = CDR(bindings_478);
{
obj_t aux_1358;
aux_1358 = CAR(bindings_478);
arg1146_495 = MAKE_PAIR(aux_1358, vars_479);
}
arg1147_496 = MAKE_PAIR(list1540___expander_let, vals_480);
{
obj_t vals_1364;
obj_t vars_1363;
obj_t bindings_1362;
bindings_1362 = arg1145_494;
vars_1363 = arg1146_495;
vals_1364 = arg1147_496;
vals_480 = vals_1364;
vars_479 = vars_1363;
bindings_478 = bindings_1362;
goto loop_481;
}
}
}
}
}
{
obj_t arg1116_462;
{
obj_t arg1117_463;
obj_t arg1118_464;
{
obj_t arg1121_467;
obj_t arg1122_468;
arg1121_467 = symbol1535___expander_let;
arg1122_468 = CAR(vars_vals_190_461);
{
obj_t list1124_470;
{
obj_t arg1125_471;
{
obj_t arg1126_472;
arg1126_472 = MAKE_PAIR(BNIL, BNIL);
arg1125_471 = MAKE_PAIR(body_460, arg1126_472);
}
list1124_470 = MAKE_PAIR(arg1122_468, arg1125_471);
}
arg1117_463 = cons__138___r4_pairs_and_lists_6_3(arg1121_467, list1124_470);
}
}
{
obj_t arg1128_474;
obj_t arg1129_475;
arg1128_474 = CDR(vars_vals_190_461);
arg1129_475 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1118_464 = append_2_18___r4_pairs_and_lists_6_3(arg1128_474, arg1129_475);
}
{
obj_t list1119_465;
list1119_465 = MAKE_PAIR(arg1118_464, BNIL);
arg1116_462 = cons__138___r4_pairs_and_lists_6_3(arg1117_463, list1119_465);
}
}
res_324 = PROCEDURE_ENTRY(e_2)(e_2, arg1116_462, e_2, BEOA);
}
}
}
 else {
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
}
 else {
loop_327 = car_128_220_343;
bindings_328 = CAR(cdr_129_16_344);
body_329 = cdr_136_29_347;
tag_102_241_330:
{
bool_t test_1379;
if(NULLP(bindings_328)){
test_1379 = ((bool_t)1);
}
 else {
test_1379 = PAIRP(bindings_328);
}
if(test_1379){
obj_t arg1063_397;
{
obj_t arg1065_398;
obj_t arg1066_399;
obj_t arg1067_400;
arg1065_398 = symbol1536___expander_let;
{
obj_t arg1076_406;
{
obj_t arg1080_410;
{
obj_t arg1085_415;
obj_t arg1086_416;
obj_t arg1087_417;
arg1085_415 = symbol1535___expander_let;
if(NULLP(bindings_328)){
arg1086_416 = BNIL;
}
 else {
obj_t head1004_425;
head1004_425 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1002_426;
obj_t tail1005_427;
l1002_426 = bindings_328;
tail1005_427 = head1004_425;
lname1003_428:
if(NULLP(l1002_426)){
arg1086_416 = CDR(head1004_425);
}
 else {
obj_t newtail1006_430;
{
obj_t arg1096_432;
{
obj_t b_434;
b_434 = CAR(l1002_426);
if(PAIRP(b_434)){
arg1096_432 = CAR(b_434);
}
 else {
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
}
newtail1006_430 = MAKE_PAIR(arg1096_432, BNIL);
}
SET_CDR(tail1005_427, newtail1006_430);
{
obj_t tail1005_1398;
obj_t l1002_1396;
l1002_1396 = CDR(l1002_426);
tail1005_1398 = newtail1006_430;
tail1005_427 = tail1005_1398;
l1002_426 = l1002_1396;
goto lname1003_428;
}
}
}
}
arg1087_417 = normalize_progn_143___progn(body_329);
{
obj_t list1089_419;
{
obj_t arg1090_420;
{
obj_t arg1091_421;
arg1091_421 = MAKE_PAIR(BNIL, BNIL);
arg1090_420 = MAKE_PAIR(arg1087_417, arg1091_421);
}
list1089_419 = MAKE_PAIR(arg1086_416, arg1090_420);
}
arg1080_410 = cons__138___r4_pairs_and_lists_6_3(arg1085_415, list1089_419);
}
}
{
obj_t list1082_412;
{
obj_t arg1083_413;
arg1083_413 = MAKE_PAIR(BNIL, BNIL);
list1082_412 = MAKE_PAIR(arg1080_410, arg1083_413);
}
arg1076_406 = cons__138___r4_pairs_and_lists_6_3(loop_327, list1082_412);
}
}
{
obj_t list1078_408;
list1078_408 = MAKE_PAIR(BNIL, BNIL);
arg1066_399 = cons__138___r4_pairs_and_lists_6_3(arg1076_406, list1078_408);
}
}
{
obj_t arg1101_438;
{
obj_t arg1104_441;
obj_t arg1105_442;
if(NULLP(bindings_328)){
arg1104_441 = BNIL;
}
 else {
obj_t head1009_445;
head1009_445 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1007_983;
obj_t tail1010_984;
l1007_983 = bindings_328;
tail1010_984 = head1009_445;
lname1008_982:
if(NULLP(l1007_983)){
arg1104_441 = CDR(head1009_445);
}
 else {
obj_t newtail1011_992;
{
obj_t aux_1415;
{
obj_t aux_1416;
{
obj_t aux_1417;
aux_1417 = CAR(l1007_983);
aux_1416 = CDR(aux_1417);
}
aux_1415 = CAR(aux_1416);
}
newtail1011_992 = MAKE_PAIR(aux_1415, BNIL);
}
SET_CDR(tail1010_984, newtail1011_992);
{
obj_t tail1010_1425;
obj_t l1007_1423;
l1007_1423 = CDR(l1007_983);
tail1010_1425 = newtail1011_992;
tail1010_984 = tail1010_1425;
l1007_983 = l1007_1423;
goto lname1008_982;
}
}
}
}
arg1105_442 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1101_438 = append_2_18___r4_pairs_and_lists_6_3(arg1104_441, arg1105_442);
}
{
obj_t list1102_439;
list1102_439 = MAKE_PAIR(arg1101_438, BNIL);
arg1067_400 = cons__138___r4_pairs_and_lists_6_3(loop_327, list1102_439);
}
}
{
obj_t list1069_402;
{
obj_t arg1070_403;
{
obj_t arg1072_404;
arg1072_404 = MAKE_PAIR(BNIL, BNIL);
arg1070_403 = MAKE_PAIR(arg1067_400, arg1072_404);
}
list1069_402 = MAKE_PAIR(arg1066_399, arg1070_403);
}
arg1063_397 = cons__138___r4_pairs_and_lists_6_3(arg1065_398, list1069_402);
}
}
res_324 = PROCEDURE_ENTRY(e_2)(e_2, arg1063_397, e_2, BEOA);
}
 else {
FAILURE(string1539___expander_let,string1538___expander_let,x_1);}
}
}
}
 else {
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
}
 else {
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
}
 else {
body_325 = cdr_114_48_339;
{
obj_t arg1048_383;
{
obj_t arg1049_384;
{
obj_t arg1054_388;
obj_t arg1056_390;
arg1054_388 = symbol1535___expander_let;
arg1056_390 = normalize_progn_143___progn(body_325);
{
obj_t list1058_392;
{
obj_t arg1059_393;
{
obj_t arg1060_394;
arg1060_394 = MAKE_PAIR(BNIL, BNIL);
arg1059_393 = MAKE_PAIR(arg1056_390, arg1060_394);
}
list1058_392 = MAKE_PAIR(BNIL, arg1059_393);
}
arg1049_384 = cons__138___r4_pairs_and_lists_6_3(arg1054_388, list1058_392);
}
}
{
obj_t list1051_386;
list1051_386 = MAKE_PAIR(BNIL, BNIL);
arg1048_383 = cons__138___r4_pairs_and_lists_6_3(arg1049_384, list1051_386);
}
}
res_324 = PROCEDURE_ENTRY(e_2)(e_2, arg1048_383, e_2, BEOA);
}
}
}
 else {
obj_t car_174_239_357;
obj_t cdr_175_128_358;
car_174_239_357 = CAR(cdr_111_186_337);
cdr_175_128_358 = CDR(cdr_111_186_337);
if(SYMBOLP(car_174_239_357)){
if(PAIRP(cdr_175_128_358)){
obj_t cdr_182_91_361;
cdr_182_91_361 = CDR(cdr_175_128_358);
if((cdr_182_91_361==BNIL)){
obj_t car_196_45_364;
car_196_45_364 = CAR(cdr_111_186_337);
if(PAIRP(car_196_45_364)){
obj_t body_1462;
obj_t bindings_1461;
bindings_1461 = car_196_45_364;
body_1462 = CDR(cdr_111_186_337);
body_332 = body_1462;
bindings_331 = bindings_1461;
goto tag_103_156_333;
}
 else {
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
}
 else {
obj_t body_1468;
obj_t bindings_1466;
obj_t loop_1465;
loop_1465 = car_174_239_357;
bindings_1466 = CAR(cdr_175_128_358);
body_1468 = cdr_182_91_361;
body_329 = body_1468;
bindings_328 = bindings_1466;
loop_327 = loop_1465;
goto tag_102_241_330;
}
}
 else {
obj_t car_215_75_370;
obj_t cdr_216_67_371;
car_215_75_370 = CAR(cdr_111_186_337);
cdr_216_67_371 = CDR(cdr_111_186_337);
if(PAIRP(car_215_75_370)){
if((cdr_216_67_371==BNIL)){
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
 else {
obj_t body_1477;
obj_t bindings_1476;
bindings_1476 = car_215_75_370;
body_1477 = cdr_216_67_371;
body_332 = body_1477;
bindings_331 = bindings_1476;
goto tag_103_156_333;
}
}
 else {
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
}
}
 else {
obj_t car_232_157_376;
obj_t cdr_233_190_377;
car_232_157_376 = CAR(cdr_111_186_337);
cdr_233_190_377 = CDR(cdr_111_186_337);
if(PAIRP(car_232_157_376)){
if((cdr_233_190_377==BNIL)){
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
 else {
obj_t body_1487;
obj_t bindings_1486;
bindings_1486 = car_232_157_376;
body_1487 = cdr_233_190_377;
body_332 = body_1487;
bindings_331 = bindings_1486;
goto tag_103_156_333;
}
}
 else {
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
}
}
}
}
 else {
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
}
 else {
FAILURE(string1537___expander_let,string1538___expander_let,x_1);}
}
return replace__160___progn(x_1, res_324);
}
}


/* _expand-eval-let */obj_t _expand_eval_let_26___expander_let(obj_t env_1283, obj_t x_1284, obj_t e_1285)
{
return expand_eval_let_110___expander_let(x_1284, e_1285);
}


/* expand-eval-let* */obj_t expand_eval_let__60___expander_let(obj_t x_3, obj_t e_4)
{
{
obj_t res_500;
{
obj_t bindings_503;
obj_t body_504;
obj_t body_501;
if(PAIRP(x_3)){
obj_t cdr_267_105_509;
cdr_267_105_509 = CDR(x_3);
if(PAIRP(cdr_267_105_509)){
obj_t cdr_270_183_511;
cdr_270_183_511 = CDR(cdr_267_105_509);
{
bool_t test_1499;
{
obj_t aux_1500;
aux_1500 = CAR(cdr_267_105_509);
test_1499 = (aux_1500==BNIL);
}
if(test_1499){
if((cdr_270_183_511==BNIL)){
FAILURE(string1544___expander_let,string1545___expander_let,x_3);}
 else {
body_501 = cdr_270_183_511;
{
obj_t arg1163_522;
{
obj_t arg1164_523;
{
obj_t arg1168_527;
obj_t arg1170_529;
arg1168_527 = symbol1535___expander_let;
arg1170_529 = normalize_progn_143___progn(body_501);
{
obj_t list1172_531;
{
obj_t arg1173_532;
{
obj_t arg1174_533;
arg1174_533 = MAKE_PAIR(BNIL, BNIL);
arg1173_532 = MAKE_PAIR(arg1170_529, arg1174_533);
}
list1172_531 = MAKE_PAIR(BNIL, arg1173_532);
}
arg1164_523 = cons__138___r4_pairs_and_lists_6_3(arg1168_527, list1172_531);
}
}
{
obj_t list1166_525;
list1166_525 = MAKE_PAIR(BNIL, BNIL);
arg1163_522 = cons__138___r4_pairs_and_lists_6_3(arg1164_523, list1166_525);
}
}
res_500 = PROCEDURE_ENTRY(e_4)(e_4, arg1163_522, e_4, BEOA);
}
}
}
 else {
obj_t cdr_286_158_516;
cdr_286_158_516 = CDR(cdr_267_105_509);
if((cdr_286_158_516==BNIL)){
FAILURE(string1544___expander_let,string1545___expander_let,x_3);}
 else {
bindings_503 = CAR(cdr_267_105_509);
body_504 = cdr_286_158_516;
{
obj_t arg1176_535;
{
obj_t arg1177_536;
obj_t arg1178_537;
obj_t arg1179_538;
arg1177_536 = symbol1542___expander_let;
{
obj_t arg1185_544;
arg1185_544 = CAR(bindings_503);
{
obj_t list1187_546;
list1187_546 = MAKE_PAIR(BNIL, BNIL);
arg1178_537 = cons__138___r4_pairs_and_lists_6_3(arg1185_544, list1187_546);
}
}
{
obj_t arg1189_548;
obj_t arg1190_549;
obj_t arg1191_550;
arg1189_548 = symbol1543___expander_let;
arg1190_549 = CDR(bindings_503);
arg1191_550 = normalize_progn_143___progn(body_504);
{
obj_t list1193_552;
{
obj_t arg1194_553;
{
obj_t arg1195_554;
arg1195_554 = MAKE_PAIR(BNIL, BNIL);
arg1194_553 = MAKE_PAIR(arg1191_550, arg1195_554);
}
list1193_552 = MAKE_PAIR(arg1190_549, arg1194_553);
}
arg1179_538 = cons__138___r4_pairs_and_lists_6_3(arg1189_548, list1193_552);
}
}
{
obj_t list1181_540;
{
obj_t arg1182_541;
{
obj_t arg1183_542;
arg1183_542 = MAKE_PAIR(BNIL, BNIL);
arg1182_541 = MAKE_PAIR(arg1179_538, arg1183_542);
}
list1181_540 = MAKE_PAIR(arg1178_537, arg1182_541);
}
arg1176_535 = cons__138___r4_pairs_and_lists_6_3(arg1177_536, list1181_540);
}
}
res_500 = PROCEDURE_ENTRY(e_4)(e_4, arg1176_535, e_4, BEOA);
}
}
}
}
}
 else {
FAILURE(string1544___expander_let,string1545___expander_let,x_3);}
}
 else {
FAILURE(string1544___expander_let,string1545___expander_let,x_3);}
}
return replace__160___progn(x_3, res_500);
}
}


/* _expand-eval-let* */obj_t _expand_eval_let__12___expander_let(obj_t env_1286, obj_t x_1287, obj_t e_1288)
{
return expand_eval_let__60___expander_let(x_1287, e_1288);
}


/* expand-eval-letrec */obj_t expand_eval_letrec_133___expander_let(obj_t x_5, obj_t e_6)
{
{
obj_t res_556;
{
obj_t bindings_559;
obj_t body_560;
obj_t body_557;
if(PAIRP(x_5)){
obj_t cdr_306_55_565;
cdr_306_55_565 = CDR(x_5);
if(PAIRP(cdr_306_55_565)){
obj_t cdr_309_130_567;
cdr_309_130_567 = CDR(cdr_306_55_565);
{
bool_t test_1545;
{
obj_t aux_1546;
aux_1546 = CAR(cdr_306_55_565);
test_1545 = (aux_1546==BNIL);
}
if(test_1545){
if((cdr_309_130_567==BNIL)){
FAILURE(string1546___expander_let,string1545___expander_let,x_5);}
 else {
body_557 = cdr_309_130_567;
{
obj_t arg1207_579;
{
obj_t arg1209_580;
{
obj_t arg1214_584;
obj_t arg1219_586;
arg1214_584 = symbol1535___expander_let;
arg1219_586 = normalize_progn_143___progn(body_557);
{
obj_t list1221_588;
{
obj_t arg1222_589;
{
obj_t arg1224_590;
arg1224_590 = MAKE_PAIR(BNIL, BNIL);
arg1222_589 = MAKE_PAIR(arg1219_586, arg1224_590);
}
list1221_588 = MAKE_PAIR(BNIL, arg1222_589);
}
arg1209_580 = cons__138___r4_pairs_and_lists_6_3(arg1214_584, list1221_588);
}
}
{
obj_t list1211_582;
list1211_582 = MAKE_PAIR(BNIL, BNIL);
arg1207_579 = cons__138___r4_pairs_and_lists_6_3(arg1209_580, list1211_582);
}
}
res_556 = PROCEDURE_ENTRY(e_6)(e_6, arg1207_579, e_6, BEOA);
}
}
}
 else {
obj_t car_324_234_572;
obj_t cdr_325_196_573;
car_324_234_572 = CAR(cdr_306_55_565);
cdr_325_196_573 = CDR(cdr_306_55_565);
if(PAIRP(car_324_234_572)){
if((cdr_325_196_573==BNIL)){
FAILURE(string1546___expander_let,string1545___expander_let,x_5);}
 else {
bindings_559 = car_324_234_572;
body_560 = cdr_325_196_573;
{
obj_t body_592;
obj_t vars_vals_190_593;
body_592 = normalize_progn_143___progn(body_560);
{
obj_t bindings_648;
obj_t vars_649;
obj_t vals_650;
bindings_648 = bindings_559;
vars_649 = BNIL;
vals_650 = BNIL;
loop_651:
if(NULLP(bindings_648)){
vars_vals_190_593 = MAKE_PAIR(vars_649, vals_650);
}
 else {
bool_t test_1572;
{
obj_t aux_1573;
aux_1573 = CAR(bindings_648);
test_1572 = PAIRP(aux_1573);
}
if(test_1572){
{
obj_t arg1287_656;
obj_t arg1288_657;
obj_t arg1290_658;
arg1287_656 = CDR(bindings_648);
{
obj_t aux_1577;
{
obj_t aux_1578;
aux_1578 = CAR(bindings_648);
aux_1577 = CAR(aux_1578);
}
arg1288_657 = MAKE_PAIR(aux_1577, vars_649);
}
{
obj_t arg1294_661;
{
obj_t aux_1582;
{
obj_t aux_1583;
aux_1583 = CAR(bindings_648);
aux_1582 = CDR(aux_1583);
}
arg1294_661 = normalize_progn_143___progn(aux_1582);
}
arg1290_658 = MAKE_PAIR(arg1294_661, vals_650);
}
{
obj_t vals_1590;
obj_t vars_1589;
obj_t bindings_1588;
bindings_1588 = arg1287_656;
vars_1589 = arg1288_657;
vals_1590 = arg1290_658;
vals_650 = vals_1590;
vars_649 = vars_1589;
bindings_648 = bindings_1588;
goto loop_651;
}
}
}
 else {
FAILURE(string1546___expander_let,string1545___expander_let,x_5);}
}
}
{
obj_t arg1226_594;
{
obj_t arg1228_595;
obj_t arg1231_596;
{
obj_t arg1234_599;
obj_t arg1235_600;
obj_t arg1236_601;
arg1234_599 = symbol1535___expander_let;
arg1235_600 = CAR(vars_vals_190_593);
{
obj_t arg1244_607;
{
obj_t vars_608;
obj_t vals_609;
obj_t res_610;
{
obj_t arg1245_612;
obj_t arg1247_613;
obj_t arg1248_614;
arg1245_612 = CAR(vars_vals_190_593);
arg1247_613 = CDR(vars_vals_190_593);
{
obj_t list1249_615;
list1249_615 = MAKE_PAIR(body_592, BNIL);
arg1248_614 = list1249_615;
}
vars_608 = arg1245_612;
vals_609 = arg1247_613;
res_610 = arg1248_614;
loop_611:
if(NULLP(vars_608)){
arg1244_607 = res_610;
}
 else {
obj_t arg1252_618;
obj_t arg1253_619;
obj_t arg1254_620;
arg1252_618 = CDR(vars_608);
arg1253_619 = CDR(vals_609);
{
obj_t arg1255_621;
{
obj_t arg1256_622;
obj_t arg1257_623;
obj_t arg1258_624;
arg1256_622 = symbol1547___expander_let;
arg1257_623 = CAR(vars_608);
arg1258_624 = CAR(vals_609);
{
obj_t list1260_626;
{
obj_t arg1262_627;
{
obj_t arg1263_628;
arg1263_628 = MAKE_PAIR(BNIL, BNIL);
arg1262_627 = MAKE_PAIR(arg1258_624, arg1263_628);
}
list1260_626 = MAKE_PAIR(arg1257_623, arg1262_627);
}
arg1255_621 = cons__138___r4_pairs_and_lists_6_3(arg1256_622, list1260_626);
}
}
arg1254_620 = MAKE_PAIR(arg1255_621, res_610);
}
{
obj_t res_1609;
obj_t vals_1608;
obj_t vars_1607;
vars_1607 = arg1252_618;
vals_1608 = arg1253_619;
res_1609 = arg1254_620;
res_610 = res_1609;
vals_609 = vals_1608;
vars_608 = vars_1607;
goto loop_611;
}
}
}
}
arg1236_601 = normalize_progn_143___progn(arg1244_607);
}
{
obj_t list1239_603;
{
obj_t arg1240_604;
{
obj_t arg1241_605;
arg1241_605 = MAKE_PAIR(BNIL, BNIL);
arg1240_604 = MAKE_PAIR(arg1236_601, arg1241_605);
}
list1239_603 = MAKE_PAIR(arg1235_600, arg1240_604);
}
arg1228_595 = cons__138___r4_pairs_and_lists_6_3(arg1234_599, list1239_603);
}
}
{
obj_t arg1267_630;
obj_t arg1268_631;
if(NULLP(bindings_559)){
arg1267_630 = BNIL;
}
 else {
obj_t head1014_634;
head1014_634 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1012_1168;
obj_t tail1015_1169;
l1012_1168 = bindings_559;
tail1015_1169 = head1014_634;
lname1013_1167:
if(NULLP(l1012_1168)){
arg1267_630 = CDR(head1014_634);
}
 else {
obj_t newtail1016_1177;
newtail1016_1177 = MAKE_PAIR(list1540___expander_let, BNIL);
SET_CDR(tail1015_1169, newtail1016_1177);
{
obj_t tail1015_1625;
obj_t l1012_1623;
l1012_1623 = CDR(l1012_1168);
tail1015_1625 = newtail1016_1177;
tail1015_1169 = tail1015_1625;
l1012_1168 = l1012_1623;
goto lname1013_1167;
}
}
}
}
arg1268_631 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1231_596 = append_2_18___r4_pairs_and_lists_6_3(arg1267_630, arg1268_631);
}
{
obj_t list1232_597;
list1232_597 = MAKE_PAIR(arg1231_596, BNIL);
arg1226_594 = cons__138___r4_pairs_and_lists_6_3(arg1228_595, list1232_597);
}
}
res_556 = PROCEDURE_ENTRY(e_6)(e_6, arg1226_594, e_6, BEOA);
}
}
}
}
 else {
FAILURE(string1546___expander_let,string1545___expander_let,x_5);}
}
}
}
 else {
FAILURE(string1546___expander_let,string1545___expander_let,x_5);}
}
 else {
FAILURE(string1546___expander_let,string1545___expander_let,x_5);}
}
return replace__160___progn(x_5, res_556);
}
}


/* _expand-eval-letrec */obj_t _expand_eval_letrec_176___expander_let(obj_t env_1289, obj_t x_1290, obj_t e_1291)
{
return expand_eval_letrec_133___expander_let(x_1290, e_1291);
}


/* expand-eval-labels */obj_t expand_eval_labels_169___expander_let(obj_t x_7, obj_t e_8)
{
{
obj_t res_665;
{
obj_t body_666;
obj_t bindings_668;
obj_t body_669;
if(PAIRP(x_7)){
obj_t cdr_347_27_674;
cdr_347_27_674 = CDR(x_7);
if(PAIRP(cdr_347_27_674)){
obj_t cdr_350_16_676;
cdr_350_16_676 = CDR(cdr_347_27_674);
{
bool_t test_1643;
{
obj_t aux_1644;
aux_1644 = CAR(cdr_347_27_674);
test_1643 = (aux_1644==BNIL);
}
if(test_1643){
if((cdr_350_16_676==BNIL)){
FAILURE(string1548___expander_let,string1545___expander_let,x_7);}
 else {
body_666 = cdr_350_16_676;
{
obj_t arg1310_687;
{
obj_t arg1311_688;
{
obj_t arg1316_692;
obj_t arg1321_694;
arg1316_692 = symbol1535___expander_let;
arg1321_694 = normalize_progn_143___progn(body_666);
{
obj_t list1323_696;
{
obj_t arg1324_697;
{
obj_t arg1325_698;
arg1325_698 = MAKE_PAIR(BNIL, BNIL);
arg1324_697 = MAKE_PAIR(arg1321_694, arg1325_698);
}
list1323_696 = MAKE_PAIR(BNIL, arg1324_697);
}
arg1311_688 = cons__138___r4_pairs_and_lists_6_3(arg1316_692, list1323_696);
}
}
{
obj_t list1314_690;
list1314_690 = MAKE_PAIR(BNIL, BNIL);
arg1310_687 = cons__138___r4_pairs_and_lists_6_3(arg1311_688, list1314_690);
}
}
res_665 = PROCEDURE_ENTRY(e_8)(e_8, arg1310_687, e_8, BEOA);
}
}
}
 else {
obj_t cdr_366_96_681;
cdr_366_96_681 = CDR(cdr_347_27_674);
if((cdr_366_96_681==BNIL)){
FAILURE(string1548___expander_let,string1545___expander_let,x_7);}
 else {
bindings_668 = CAR(cdr_347_27_674);
body_669 = cdr_366_96_681;
{
obj_t new_700;
new_700 = loop___expander_let(x_7, bindings_668);
{
obj_t arg1328_701;
{
obj_t arg1330_702;
obj_t arg1331_703;
arg1330_702 = symbol1536___expander_let;
{
obj_t arg1337_707;
arg1337_707 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1331_703 = append_2_18___r4_pairs_and_lists_6_3(body_669, arg1337_707);
}
{
obj_t list1332_704;
{
obj_t arg1333_705;
arg1333_705 = MAKE_PAIR(arg1331_703, BNIL);
list1332_704 = MAKE_PAIR(new_700, arg1333_705);
}
arg1328_701 = cons__138___r4_pairs_and_lists_6_3(arg1330_702, list1332_704);
}
}
res_665 = PROCEDURE_ENTRY(e_8)(e_8, arg1328_701, e_8, BEOA);
}
}
}
}
}
}
 else {
FAILURE(string1548___expander_let,string1545___expander_let,x_7);}
}
 else {
FAILURE(string1548___expander_let,string1545___expander_let,x_7);}
}
return replace__160___progn(x_7, res_665);
}
}


/* loop */obj_t loop___expander_let(obj_t x_1295, obj_t bindings_710)
{
if(NULLP(bindings_710)){
return BNIL;
}
 else {
if(PAIRP(bindings_710)){
{
obj_t name_714;
obj_t args_715;
obj_t lbody_716;
{
obj_t e_380_132_719;
e_380_132_719 = CAR(bindings_710);
if(PAIRP(e_380_132_719)){
obj_t cdr_388_242_721;
cdr_388_242_721 = CDR(e_380_132_719);
if(PAIRP(cdr_388_242_721)){
name_714 = CAR(e_380_132_719);
args_715 = CAR(cdr_388_242_721);
lbody_716 = CDR(cdr_388_242_721);
{
obj_t arg1350_726;
obj_t arg1351_727;
{
obj_t arg1352_728;
{
obj_t arg1357_733;
obj_t arg1361_734;
arg1357_733 = symbol1535___expander_let;
{
obj_t arg1365_738;
arg1365_738 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1361_734 = append_2_18___r4_pairs_and_lists_6_3(lbody_716, arg1365_738);
}
{
obj_t list1362_735;
{
obj_t arg1363_736;
arg1363_736 = MAKE_PAIR(arg1361_734, BNIL);
list1362_735 = MAKE_PAIR(args_715, arg1363_736);
}
arg1352_728 = cons__138___r4_pairs_and_lists_6_3(arg1357_733, list1362_735);
}
}
{
obj_t list1354_730;
{
obj_t arg1355_731;
arg1355_731 = MAKE_PAIR(BNIL, BNIL);
list1354_730 = MAKE_PAIR(arg1352_728, arg1355_731);
}
arg1350_726 = cons__138___r4_pairs_and_lists_6_3(name_714, list1354_730);
}
}
arg1351_727 = loop___expander_let(x_1295, CDR(bindings_710));
return MAKE_PAIR(arg1350_726, arg1351_727);
}
}
 else {
FAILURE(string1548___expander_let,string1545___expander_let,x_1295);}
}
 else {
FAILURE(string1548___expander_let,string1545___expander_let,x_1295);}
}
}
}
 else {
FAILURE(string1548___expander_let,string1545___expander_let,x_1295);}
}
}


/* _expand-eval-labels */obj_t _expand_eval_labels_129___expander_let(obj_t env_1292, obj_t x_1293, obj_t e_1294)
{
return expand_eval_labels_169___expander_let(x_1293, e_1294);
}


/* imported-modules-init */obj_t imported_modules_init_94___expander_let()
{
module_initialization_70___error(((long)0), "__EXPANDER_LET");
module_initialization_70___bigloo(((long)0), "__EXPANDER_LET");
module_initialization_70___tvector(((long)0), "__EXPANDER_LET");
module_initialization_70___structure(((long)0), "__EXPANDER_LET");
module_initialization_70___bexit(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_numbers_6_5(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_characters_6_6(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_booleans_6_1(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_symbols_6_4(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_strings_6_7(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_input_6_10_2(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_control_features_6_9(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_vectors_6_8(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EXPANDER_LET");
module_initialization_70___r4_output_6_10_3(((long)0), "__EXPANDER_LET");
return module_initialization_70___progn(((long)0), "__EXPANDER_LET");
}

