/*===========================================================================*/
/*   (R5rs/usual5.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
static obj_t symbol1151___r5_syntax_usual = BUNSPEC;
static obj_t symbol1149___r5_syntax_usual = BUNSPEC;
extern obj_t open_input_string(obj_t);
static obj_t _initialize_usual_syntax__120___r5_syntax_usual(obj_t);
extern obj_t internal_expand_syntax_49___r5_syntax_expand(obj_t);
extern obj_t close_input_port(obj_t);
extern obj_t module_initialization_70___r5_syntax_usual(long, char *);
extern obj_t initialize_usual_syntax__76___r5_syntax_usual();
extern obj_t define_syntax_scope_173___r5_syntax_expand;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114___r5_syntax_usual = BUNSPEC;
static obj_t cnst_init_137___r5_syntax_usual();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( initialize_usual_syntax__env_22___r5_syntax_usual, _initialize_usual_syntax__120___r5_syntax_usual1153, _initialize_usual_syntax__120___r5_syntax_usual, 0L, 0 );
DEFINE_STRING( string1150___r5_syntax_usual, string1150___r5_syntax_usual1154, "(\n\n(define-syntax let\n  (syntax-rules ()\n    ((let ((?name ?val) ...) ?body ?body1 ...)\n     ((lambda (?name ...) ?body ?body1 ...) ?val ...))\n    ((let ?tag ((?name ?val) ...) ?body ?body1 ...)\n     ((letrec ((?tag (lambda (?name ...) ?body ?body1 ...)))\n        ?tag)\n      ?val ...))))\n\n(define-syntax let*\n  (syntax-rules ()\n    ((let* () ?body ?body1 ...)\n     (let () ?body ?body1 ...))\n    ((let* ((?name1 ?val1) (?name ?val) ...) ?body ?body1 ...)\n     (let ((?name1 ?val1)) (let* ((?name ?val) ...) ?body ?body1 ...)))\n    ((let* ?tag ((?name ?val) ...) ?body ?body1 ...)\n     ((letrec ((?tag (lambda (?name ...) ?body ?body1 ...)))\n        ?tag)\n      ?val ...))))\n\n(define-syntax letrec\n  (syntax-rules ()\n    ((letrec ((?name ?val) ...) ?body ?body2 ...)\n     (let ((?name '*) ...)\n       (set! ?name ?val)\n       ...\n       ?body ?body2 ...))))\n\n(define-syntax and\n  (syntax-rules ()\n    ((and) #t)\n    ((and ?e) ?e)\n    ((and ?e1 ?e2 ?e3 ...)\n     (if ?e1 (and ?e2 ?e3 ...) #"
"f))))\n\n(define-syntax or\n  (syntax-rules ()\n    ((or) #f)\n    ((or ?e) ?e)\n    ((or ?e1 ?e2 ?e3 ...)\n     (let ((temp ?e1))\n       (if temp temp (or ?e2 ?e3 ...))))))\n\n(define-syntax cond\n  (syntax-rules (else =>)\n    ((cond (else ?result ?result2 ...))\n     (begin ?result ?result2 ...))\n    \n    ((cond (?test => ?result))\n     (let ((temp ?test))\n       (if temp (?result temp))))\n    \n    ((cond (?test)) ?test)\n    \n    ((cond (?test ?result ?result2 ...))\n     (if ?test (begin ?result ?result2 ...)))\n    \n    ((cond (?test => ?result) ?clause ?clause2 ...)\n     (let ((temp ?test))\n       (if temp (?result temp) (cond ?clause ?clause2 ...))))\n    \n    ((cond (?test) ?clause ?clause2 ...)\n     (or ?test (cond ?clause ?clause2 ...)))\n    \n    ((cond (?test ?result ?result2 ...)\n           ?clause ?clause2 ...)\n     (if ?test\n         (begin ?result ?result2 ...)\n         (cond ?clause ?clause2 ...)))))\n\n(define-syntax do\n  (syntax-rules ()\n    ((do (?bindings0 ...) ?claus"
"e0 ?body0 ...)\n     (letrec-syntax\n       ((do-aux\n         (___ (syntax-rules ()\n                ((do-aux () ((?name ?init ?step) ...) ?clause ?body ...)\n                 (letrec ((loop (lambda (?name ...)\n                                  (cond ?clause\n                                        (else\n                                         (begin ?body ...)\n                                         (loop ?step ...))))))\n                   (loop ?init ...)))\n                ((do-aux ((?name ?init ?step) ?todo ...)\n                         (?bindings ...)\n                         ?clause\n                         ?body ...)\n                 (do-aux (?todo ...)\n                         (?bindings ... (?name ?init ?step))\n                         ?clause\n                         ?body ...))\n                ((do-aux ((?name ?init) ?todo ...)\n                         (?bindings ...)\n                         ?clause\n                         ?body ...)\n                 (do-aux (?todo ...)\n      "
"                   (?bindings ... (?name ?init ?name))\n                         ?clause\n                         ?body ...))))))\n       (do-aux (?bindings0 ...) () ?clause0 ?body0 ...)))))\n\n(define-syntax delay\n  (syntax-rules ()\n    ((delay ?e) (make-promise (lambda () ?e)))))\n\n(define-syntax case\n  (syntax-rules (else)\n    ((case ?e1 (else ?body ?body2 ...))\n     (begin ?e1 ?body ?body2 ...))\n    ((case ?e1 (?z ?body ?body2 ...))\n     (if (memv ?e1 '?z) (begin ?body ?body2 ...)))\n    ((case ?e1 ?clause1 ?clause2 ?clause3 ...)\n     (letrec-syntax\n       ((case-aux\n          (___ (syntax-rules ()\n                ((case-aux ?temp (else ?body ?body2 ...))\n                 (begin ?body ?body2 ...))\n                ((case-aux ?temp (?z ?body ?body2 ...))\n                 (if (memv ?temp '?z) (begin ?body ?body2 ...)))\n                ((case-aux ?temp (?z ?body ?body2 ...) ?c1 ?c2 ...)\n                 (if (memv ?temp '?z)\n                     (begin ?body ?body2 ...)\n                    "
" (case-aux ?temp ?c1 ?c2 ...)))))))\n       (let ((temp ?e1))\n         (case-aux temp ?clause1 ?clause2 ?clause3 ...))))))\n\n(begin\n \n (define-syntax finalize-quasiquote letrec\n   (syntax-rules (quote unquote unquote-splicing)\n    ((finalize-quasiquote quote ?arg ?return)\n     (interpret-continuation ?return (quote ?arg)))\n    ((finalize-quasiquote unquote ?arg ?return)\n     (interpret-continuation ?return ?arg))\n    ((finalize-quasiquote unquote-splicing ?arg ?return)\n     (syntax-error \",@ in illegal context\" ?arg))\n    ((finalize-quasiquote ?mode ?arg ?return)\n     (interpret-continuation ?return (?mode . ?arg)))))\n \n (define-syntax descend-quasiquote letrec\n   (syntax-rules (quasiquote unquote unquote-splicing)\n    ((descend-quasiquote `?y ?x ?level ?return)\n     (descend-quasiquote-pair ?x ?x (?level) ?return))\n    ((descend-quasiquote ,?y ?x () ?return)\n     (interpret-continuation ?return unquote ?y))\n    ((descend-quasiquote ,?y ?x (?level) ?return)\n     (descend-quasiquote-pai"
"r ?x ?x ?level ?return))\n    ((descend-quasiquote ,@?y ?x () ?return)\n     (interpret-continuation ?return unquote-splicing ?y))\n    ((descend-quasiquote ,@?y ?x (?level) ?return)\n     (descend-quasiquote-pair ?x ?x ?level ?return))\n    ((descend-quasiquote (?y . ?z) ?x ?level ?return)\n     (descend-quasiquote-pair ?x ?x ?level ?return))\n    ((descend-quasiquote #(?y ...) ?x ?level ?return)\n     (descend-quasiquote-vector ?x ?x ?level ?return))\n    ((descend-quasiquote ?y ?x ?level ?return)\n     (interpret-continuation ?return quote ?x))))\n \n (define-syntax descend-quasiquote-pair letrec\n   (syntax-rules (quote unquote unquote-splicing)\n    ((descend-quasiquote-pair (?carx . ?cdrx) ?x ?level ?return)\n     (descend-quasiquote ?carx ?carx ?level (1 ?cdrx ?x ?level ?return)))))\n \n (define-syntax descend-quasiquote-vector letrec\n   (syntax-rules (quote)\n    ((descend-quasiquote-vector #(?y ...) ?x ?level ?return)\n     (descend-quasiquote (?y ...) (?y ...) ?level (6 ?x ?return)))))\n \n (define"
"-syntax interpret-continuation letrec\n   (syntax-rules (quote unquote unquote-splicing)\n    ((interpret-continuation (-1) ?e) ?e)\n    ((interpret-continuation (0) ?mode ?arg)\n     (finalize-quasiquote ?mode ?arg (-1)))    \n    ((interpret-continuation (1 ?cdrx ?x ?level ?return) ?car-mode ?car-arg)\n     (descend-quasiquote ?cdrx\n                         ?cdrx\n                         ?level\n                         (2 ?car-mode ?car-arg ?x ?return)))    \n    ((interpret-continuation (2 quote ?car-arg ?x ?return) quote ?cdr-arg)\n     (interpret-continuation ?return quote ?x))    \n    ((interpret-continuation (2 unquote-splicing ?car-arg ?x ?return) quote ())\n     (interpret-continuation ?return unquote ?car-arg))\n    ((interpret-continuation (2 unquote-splicing ?car-arg ?x ?return)\n                             ?cdr-mode ?cdr-arg)\n     (finalize-quasiquote ?cdr-mode ?cdr-arg (3 ?car-arg ?return)))  \n    ((interpret-continuation (2 ?car-mode ?car-arg ?x ?return)\n                             ?cd"
"r-mode ?cdr-arg)\n     (finalize-quasiquote ?car-mode ?car-arg (4 ?cdr-mode ?cdr-arg ?return)))\n      \n    ((interpret-continuation (3 ?car-arg ?return) ?e)\n     (interpret-continuation ?return append (?car-arg ?e)))\n    ((interpret-continuation (4 ?cdr-mode ?cdr-arg ?return) ?e1)\n     (finalize-quasiquote ?cdr-mode ?cdr-arg (5 ?e1 ?return)))\n    ((interpret-continuation (5 ?e1 ?return) ?e2)\n     (interpret-continuation ?return cons (?e1 ?e2)))\n    ((interpret-continuation (6 ?x ?return) quote ?arg)\n     (interpret-continuation ?return quote ?x))\n    ((interpret-continuation (6 ?x ?return) ?mode ?arg)\n     (finalize-quasiquote ?mode ?arg (7 ?return)))\n    ((interpret-continuation (7 ?return) ?e)\n     (interpret-continuation ?return list->vector (?e)))))\n \n (define-syntax quasiquote letrec\n   (syntax-rules ()\n    ((quasiquote ?x)\n     (descend-quasiquote ?x ?x () (0)))))\n )\n\n(define-syntax let*-syntax\n  (syntax-rules ()\n    ((let*-syntax () ?body)\n     (let-syntax () ?body))\n    ((let*"
"-syntax ((?name1 ?val1) (?name ?val) ...) ?body)\n     (let-syntax ((?name1 ?val1)) (let*-syntax ((?name ?val) ...) ?body)))))\n\n\n(define-syntax define-macro\n   (syntax-rules ()\n      ((define-macro args ...)\n       (define-hygien-macro 'args ...))))\n\n            )", 8239 );


/* module-initialization */obj_t module_initialization_70___r5_syntax_usual(long checksum_491, char * from_492)
{
if(CBOOL(require_initialization_114___r5_syntax_usual)){
require_initialization_114___r5_syntax_usual = BBOOL(((bool_t)0));
cnst_init_137___r5_syntax_usual();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r5_syntax_usual()
{
symbol1149___r5_syntax_usual = string_to_symbol("LETREC*");
return (symbol1151___r5_syntax_usual = string_to_symbol("LETREC"),
BUNSPEC);
}


/* initialize-usual-syntax! */obj_t initialize_usual_syntax__76___r5_syntax_usual()
{
PROCEDURE_ENTRY(define_syntax_scope_173___r5_syntax_expand)(define_syntax_scope_173___r5_syntax_expand, symbol1149___r5_syntax_usual, BEOA);
{
obj_t p_311;
p_311 = open_input_string(string1150___r5_syntax_usual);
{
obj_t l_312;
{
obj_t list1011_318;
list1011_318 = MAKE_PAIR(p_311, BNIL);
l_312 = read___reader(list1011_318);
}
{
close_input_port(p_311);
{
obj_t l1002_463;
l1002_463 = l_312;
lname1003_462:
if(PAIRP(l1002_463)){
internal_expand_syntax_49___r5_syntax_expand(CAR(l1002_463));
{
obj_t l1002_509;
l1002_509 = CDR(l1002_463);
l1002_463 = l1002_509;
goto lname1003_462;
}
}
 else {
((bool_t)1);
}
}
}
}
}
return PROCEDURE_ENTRY(define_syntax_scope_173___r5_syntax_expand)(define_syntax_scope_173___r5_syntax_expand, symbol1151___r5_syntax_usual, BEOA);
}


/* _initialize-usual-syntax! */obj_t _initialize_usual_syntax__120___r5_syntax_usual(obj_t env_490)
{
return initialize_usual_syntax__76___r5_syntax_usual();
}

