/*===========================================================================*/
/*   (Ast/let.scm)                                                           */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_ast_let();
extern obj_t find_location_loc_243_tools_location(obj_t, obj_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern node_t substitute__30_ast_substitute(obj_t, obj_t, node_t, obj_t);
extern bool_t user_symbol__147_ast_ident(obj_t);
extern obj_t _obj__252_type_cache;
extern local_t clone_local_230_ast_local(local_t, value_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t _unspec__87_type_cache;
extern obj_t module_initialization_70_ast_let(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_substitute(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t _let__node1806_38_ast_let(obj_t, obj_t, obj_t, obj_t, obj_t);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
static let_var_6_t make_generic_let_111_ast_let(obj_t, obj_t, obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_ast_let();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static let_var_6_t let_or_letrec_20_ast_let(obj_t, let_var_6_t);
extern obj_t normalize_progn_143_tools_progn(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_ast_let();
static obj_t toplevel_init_63_ast_let();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t use_variable__4_ast_sexp(variable_t, obj_t, obj_t);
static obj_t make_smart_generic_let_237_ast_let(obj_t, let_var_6_t, obj_t);
extern obj_t setq_ast_node;
extern obj_t parse_id_241_ast_ident(obj_t);
extern node_t error_sexp__node_157_ast_sexp(obj_t, obj_t, obj_t);
extern node_t let__node_121_ast_let(obj_t, obj_t, obj_t, obj_t);
extern local_t make_user_local_svar_134_ast_local(obj_t, type_t);
extern obj_t _procedure__226_type_cache;
static let_fun_218_t let__labels_169_ast_let(obj_t, node_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_let = BUNSPEC;
static obj_t cnst_init_137_ast_let();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[5];

DEFINE_EXPORT_PROCEDURE(let__node_env_100_ast_let, _let__node1806_38_ast_let1815, _let__node1806_38_ast_let, 0L, 4);
DEFINE_STRING(string1809_ast_let, string1809_ast_let1816, "SET! WRITE LET VALUE LOCATION ", 30);
DEFINE_STRING(string1808_ast_let, string1808_ast_let1817, "Illegal form `", 14);
DEFINE_STRING(string1807_ast_let, string1807_ast_let1818, "' form", 6);


/* module-initialization */ obj_t 
module_initialization_70_ast_let(long checksum_1764, char *from_1765)
{
   if (CBOOL(require_initialization_114_ast_let))
     {
	require_initialization_114_ast_let = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_let();
	cnst_init_137_ast_let();
	imported_modules_init_94_ast_let();
	method_init_76_ast_let();
	toplevel_init_63_ast_let();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_let()
{
   module_initialization_70___object(((long) 0), "AST_LET");
   module_initialization_70___r4_strings_6_7(((long) 0), "AST_LET");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_LET");
   module_initialization_70___reader(((long) 0), "AST_LET");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_let()
{
   {
      obj_t cnst_port_138_1756;
      cnst_port_138_1756 = open_input_string(string1809_ast_let);
      {
	 long i_1757;
	 i_1757 = ((long) 4);
       loop_1758:
	 {
	    bool_t test1810_1759;
	    test1810_1759 = (i_1757 == ((long) -1));
	    if (test1810_1759)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1811_1760;
		    {
		       obj_t list1812_1761;
		       {
			  obj_t arg1813_1762;
			  arg1813_1762 = BNIL;
			  list1812_1761 = MAKE_PAIR(cnst_port_138_1756, arg1813_1762);
		       }
		       arg1811_1760 = read___reader(list1812_1761);
		    }
		    CNST_TABLE_SET(i_1757, arg1811_1760);
		 }
		 {
		    int aux_1763;
		    {
		       long aux_1784;
		       aux_1784 = (i_1757 - ((long) 1));
		       aux_1763 = (int) (aux_1784);
		    }
		    {
		       long i_1787;
		       i_1787 = (long) (aux_1763);
		       i_1757 = i_1787;
		       goto loop_1758;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_let()
{
   return BUNSPEC;
}


/* let->node */ node_t 
let__node_121_ast_let(obj_t exp_15, obj_t stack_16, obj_t oloc_17, obj_t site_18)
{
   {
      obj_t bindings_741;
      obj_t body_739;
      if (PAIRP(exp_15))
	{
	   obj_t cdr_128_145_746;
	   cdr_128_145_746 = CDR(exp_15);
	   if (PAIRP(cdr_128_145_746))
	     {
		bool_t test_1794;
		{
		   obj_t aux_1795;
		   aux_1795 = CAR(cdr_128_145_746);
		   test_1794 = (aux_1795 == BNIL);
		}
		if (test_1794)
		  {
		     let_var_6_t aux_1798;
		     body_739 = CDR(cdr_128_145_746);
		     {
			obj_t nloc_754;
			nloc_754 = find_location_loc_243_tools_location(exp_15, oloc_17);
			{
			   node_t body_755;
			   {
			      obj_t arg1500_766;
			      arg1500_766 = normalize_progn_143_tools_progn(body_739);
			      body_755 = sexp__node_235_ast_sexp(arg1500_766, stack_16, nloc_754, site_18);
			   }
			   {
			      obj_t loc_756;
			      {
				 obj_t loc_763;
				 loc_763 = find_location_loc_243_tools_location(exp_15, (((node_t) CREF(body_755))->loc));
				 {
				    bool_t test_1804;
				    if (STRUCTP(loc_763))
				      {
					 obj_t aux_1809;
					 obj_t aux_1807;
					 aux_1809 = CNST_TABLE_REF(((long) 0));
					 aux_1807 = STRUCT_KEY(loc_763);
					 test_1804 = (aux_1807 == aux_1809);
				      }
				    else
				      {
					 test_1804 = ((bool_t) 0);
				      }
				    if (test_1804)
				      {
					 loc_756 = loc_763;
				      }
				    else
				      {
					 loc_756 = oloc_17;
				      }
				 }
			      }
			      {
				 {
				    type_t arg1490_758;
				    arg1490_758 = (((node_t) CREF(body_755))->type);
				    {
				       let_var_6_t res1799_1410;
				       {
					  obj_t key_1395;
					  key_1395 = BINT(((long) -1));
					  {
					     let_var_6_t new1365_1399;
					     new1365_1399 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
					     {
						long arg1720_1400;
						arg1720_1400 = class_num_218___object(let_var_6_ast_node);
						{
						   obj_t obj_1408;
						   obj_1408 = (obj_t) (new1365_1399);
						   (((obj_t) CREF(obj_1408))->header = MAKE_HEADER(arg1720_1400, 0), BUNSPEC);
						}
					     }
					     {
						object_t aux_1818;
						aux_1818 = (object_t) (new1365_1399);
						OBJECT_WIDENING_SET(aux_1818, BFALSE);
					     }
					     ((((let_var_6_t) CREF(new1365_1399))->loc) = ((obj_t) loc_756), BUNSPEC);
					     ((((let_var_6_t) CREF(new1365_1399))->type) = ((type_t) arg1490_758), BUNSPEC);
					     ((((let_var_6_t) CREF(new1365_1399))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
					     ((((let_var_6_t) CREF(new1365_1399))->key) = ((obj_t) key_1395), BUNSPEC);
					     ((((let_var_6_t) CREF(new1365_1399))->bindings) = ((obj_t) BNIL), BUNSPEC);
					     ((((let_var_6_t) CREF(new1365_1399))->body) = ((node_t) body_755), BUNSPEC);
					     ((((let_var_6_t) CREF(new1365_1399))->removable__42) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					     res1799_1410 = new1365_1399;
					  }
				       }
				       aux_1798 = res1799_1410;
				    }
				 }
			      }
			   }
			}
		     }
		     return (node_t) (aux_1798);
		  }
		else
		  {
		     obj_t aux_1830;
		     bindings_741 = CAR(cdr_128_145_746);
		     {
			bool_t test_1831;
			{
			   bool_t test_1832;
			   if (PAIRP(bindings_741))
			     {
				test_1832 = ((bool_t) 1);
			     }
			   else
			     {
				test_1832 = NULLP(bindings_741);
			     }
			   if (test_1832)
			     {
				obj_t bindings_781;
				bindings_781 = bindings_741;
			      loop_782:
				if (NULLP(bindings_781))
				  {
				     test_1831 = ((bool_t) 0);
				  }
				else
				  {
				     obj_t binding_784;
				     binding_784 = CAR(bindings_781);
				     {
					if (PAIRP(binding_784))
					  {
					     obj_t cdr_149_75_789;
					     cdr_149_75_789 = CDR(binding_784);
					     if (PAIRP(cdr_149_75_789))
					       {
						  bool_t test_1844;
						  {
						     obj_t aux_1845;
						     aux_1845 = CDR(cdr_149_75_789);
						     test_1844 = (aux_1845 == BNIL);
						  }
						  if (test_1844)
						    {
						       {
							  obj_t bindings_1848;
							  bindings_1848 = CDR(bindings_781);
							  bindings_781 = bindings_1848;
							  goto loop_782;
						       }
						    }
						  else
						    {
						       test_1831 = ((bool_t) 1);
						    }
					       }
					     else
					       {
						  test_1831 = ((bool_t) 1);
					       }
					  }
					else
					  {
					     test_1831 = ((bool_t) 1);
					  }
				     }
				  }
			     }
			   else
			     {
				test_1831 = ((bool_t) 1);
			     }
			}
			if (test_1831)
			  {
			     obj_t arg1502_768;
			     obj_t arg1503_769;
			     {
				obj_t arg1505_771;
				{
				   obj_t aux_1850;
				   aux_1850 = CAR(exp_15);
				   arg1505_771 = SYMBOL_TO_STRING(aux_1850);
				}
				{
				   obj_t list1508_773;
				   {
				      obj_t arg1510_774;
				      {
					 obj_t arg1511_775;
					 arg1511_775 = MAKE_PAIR(string1807_ast_let, BNIL);
					 arg1510_774 = MAKE_PAIR(arg1505_771, arg1511_775);
				      }
				      list1508_773 = MAKE_PAIR(string1808_ast_let, arg1510_774);
				   }
				   arg1502_768 = string_append_106___r4_strings_6_7(list1508_773);
				}
			     }
			     arg1503_769 = find_location_loc_243_tools_location(exp_15, oloc_17);
			     {
				node_t aux_1858;
				aux_1858 = error_sexp__node_157_ast_sexp(arg1502_768, exp_15, arg1503_769);
				aux_1830 = (obj_t) (aux_1858);
			     }
			  }
			else
			  {
			     obj_t arg1515_778;
			     let_var_6_t arg1516_779;
			     arg1515_778 = CAR(exp_15);
			     arg1516_779 = make_generic_let_111_ast_let(exp_15, stack_16, oloc_17, site_18);
			     aux_1830 = make_smart_generic_let_237_ast_let(arg1515_778, arg1516_779, site_18);
			  }
		     }
		     return (node_t) (aux_1830);
		  }
	     }
	   else
	     {
	      tag_122_225_743:
		{
		   obj_t arg1527_796;
		   obj_t arg1528_797;
		   {
		      obj_t arg1530_799;
		      {
			 obj_t aux_1866;
			 aux_1866 = CAR(exp_15);
			 arg1530_799 = SYMBOL_TO_STRING(aux_1866);
		      }
		      {
			 obj_t list1532_801;
			 {
			    obj_t arg1533_802;
			    {
			       obj_t arg1534_803;
			       arg1534_803 = MAKE_PAIR(string1807_ast_let, BNIL);
			       arg1533_802 = MAKE_PAIR(arg1530_799, arg1534_803);
			    }
			    list1532_801 = MAKE_PAIR(string1808_ast_let, arg1533_802);
			 }
			 arg1527_796 = string_append_106___r4_strings_6_7(list1532_801);
		      }
		   }
		   arg1528_797 = find_location_loc_243_tools_location(exp_15, oloc_17);
		   return error_sexp__node_157_ast_sexp(arg1527_796, exp_15, arg1528_797);
		}
	     }
	}
      else
	{
	   goto tag_122_225_743;
	}
   }
}


/* _let->node1806 */ obj_t 
_let__node1806_38_ast_let(obj_t env_1750, obj_t exp_1751, obj_t stack_1752, obj_t oloc_1753, obj_t site_1754)
{
   {
      node_t aux_1875;
      aux_1875 = let__node_121_ast_let(exp_1751, stack_1752, oloc_1753, site_1754);
      return (obj_t) (aux_1875);
   }
}


/* make-generic-let */ let_var_6_t 
make_generic_let_111_ast_let(obj_t exp_19, obj_t stack_20, obj_t oloc_21, obj_t site_22)
{
   {
      obj_t bindings_806;
      {
	 obj_t aux_1878;
	 aux_1878 = CDR(exp_19);
	 bindings_806 = CAR(aux_1878);
      }
      {
	 obj_t body_807;
	 {
	    obj_t aux_1881;
	    {
	       obj_t aux_1882;
	       aux_1882 = CDR(exp_19);
	       aux_1881 = CDR(aux_1882);
	    }
	    body_807 = normalize_progn_143_tools_progn(aux_1881);
	 }
	 {
	    obj_t frame_808;
	    if (NULLP(bindings_806))
	      {
		 frame_808 = BNIL;
	      }
	    else
	      {
		 obj_t head1438_855;
		 head1438_855 = MAKE_PAIR(BNIL, BNIL);
		 {
		    obj_t l1436_856;
		    obj_t tail1439_857;
		    l1436_856 = bindings_806;
		    tail1439_857 = head1438_855;
		  lname1437_858:
		    if (NULLP(l1436_856))
		      {
			 frame_808 = CDR(head1438_855);
		      }
		    else
		      {
			 obj_t newtail1440_860;
			 {
			    local_t arg1575_862;
			    {
			       obj_t var_id_112_865;
			       {
				  obj_t aux_1892;
				  {
				     obj_t aux_1893;
				     aux_1893 = CAR(l1436_856);
				     aux_1892 = CAR(aux_1893);
				  }
				  var_id_112_865 = parse_id_241_ast_ident(aux_1892);
			       }
			       {
				  obj_t id_866;
				  id_866 = CAR(var_id_112_865);
				  {
				     obj_t type_867;
				     type_867 = CDR(var_id_112_865);
				     {
					{
					   bool_t test1579_868;
					   test1579_868 = user_symbol__147_ast_ident(id_866);
					   if (test1579_868)
					     {
						arg1575_862 = make_user_local_svar_134_ast_local(id_866, (type_t) (type_867));
					     }
					   else
					     {
						arg1575_862 = make_local_svar_140_ast_local(id_866, (type_t) (type_867));
					     }
					}
				     }
				  }
			       }
			    }
			    {
			       obj_t aux_1905;
			       aux_1905 = (obj_t) (arg1575_862);
			       newtail1440_860 = MAKE_PAIR(aux_1905, BNIL);
			    }
			 }
			 SET_CDR(tail1439_857, newtail1440_860);
			 {
			    obj_t tail1439_1911;
			    obj_t l1436_1909;
			    l1436_1909 = CDR(l1436_856);
			    tail1439_1911 = newtail1440_860;
			    tail1439_857 = tail1439_1911;
			    l1436_856 = l1436_1909;
			    goto lname1437_858;
			 }
		      }
		 }
	      }
	    {
	       obj_t new_stack_37_809;
	       new_stack_37_809 = append_2_18___r4_pairs_and_lists_6_3(frame_808, stack_20);
	       {
		  {
		     obj_t nloc_810;
		     nloc_810 = find_location_loc_243_tools_location(exp_19, oloc_21);
		     {
			node_t body_811;
			body_811 = sexp__node_235_ast_sexp(body_807, new_stack_37_809, nloc_810, CNST_TABLE_REF(((long) 1)));
			{
			   obj_t bstack_812;
			   {
			      bool_t test_1916;
			      {
				 obj_t aux_1919;
				 obj_t aux_1917;
				 aux_1919 = CNST_TABLE_REF(((long) 2));
				 aux_1917 = CAR(exp_19);
				 test_1916 = (aux_1917 == aux_1919);
			      }
			      if (test_1916)
				{
				   bstack_812 = stack_20;
				}
			      else
				{
				   bstack_812 = new_stack_37_809;
				}
			   }
			   {
			      obj_t bindings_813;
			      if (NULLP(bindings_806))
				{
				   bindings_813 = BNIL;
				}
			      else
				{
				   obj_t head1443_829;
				   head1443_829 = MAKE_PAIR(BNIL, BNIL);
				   {
				      obj_t ll1441_830;
				      obj_t ll1442_831;
				      obj_t tail1444_832;
				      ll1441_830 = bindings_806;
				      ll1442_831 = frame_808;
				      tail1444_832 = head1443_829;
				    lname1446_833:
				      if (NULLP(ll1441_830))
					{
					   bindings_813 = CDR(head1443_829);
					}
				      else
					{
					   obj_t newtail1445_835;
					   {
					      obj_t arg1557_838;
					      {
						 obj_t binding_840;
						 obj_t var_841;
						 binding_840 = CAR(ll1441_830);
						 var_841 = CAR(ll1442_831);
						 {
						    node_t arg1559_842;
						    {
						       obj_t arg1560_843;
						       obj_t arg1561_844;
						       obj_t arg1562_845;
						       arg1560_843 = normalize_progn_143_tools_progn(CDR(binding_840));
						       arg1561_844 = find_location_loc_243_tools_location(binding_840, nloc_810);
						       arg1562_845 = CNST_TABLE_REF(((long) 1));
						       arg1559_842 = sexp__node_235_ast_sexp(arg1560_843, bstack_812, arg1561_844, arg1562_845);
						    }
						    {
						       obj_t aux_1935;
						       aux_1935 = (obj_t) (arg1559_842);
						       arg1557_838 = MAKE_PAIR(var_841, aux_1935);
						    }
						 }
					      }
					      newtail1445_835 = MAKE_PAIR(arg1557_838, BNIL);
					   }
					   SET_CDR(tail1444_832, newtail1445_835);
					   {
					      obj_t tail1444_1944;
					      obj_t ll1442_1942;
					      obj_t ll1441_1940;
					      ll1441_1940 = CDR(ll1441_830);
					      ll1442_1942 = CDR(ll1442_831);
					      tail1444_1944 = newtail1445_835;
					      tail1444_832 = tail1444_1944;
					      ll1442_831 = ll1442_1942;
					      ll1441_830 = ll1441_1940;
					      goto lname1446_833;
					   }
					}
				   }
				}
			      {
				 obj_t loc_814;
				 {
				    obj_t loc_820;
				    {
				       obj_t aux_1945;
				       if (PAIRP(bindings_813))
					 {
					    node_t obj_1471;
					    {
					       obj_t aux_1948;
					       {
						  obj_t aux_1949;
						  aux_1949 = CAR(bindings_813);
						  aux_1948 = CDR(aux_1949);
					       }
					       obj_1471 = (node_t) (aux_1948);
					    }
					    aux_1945 = (((node_t) CREF(obj_1471))->loc);
					 }
				       else
					 {
					    aux_1945 = (((node_t) CREF(body_811))->loc);
					 }
				       loc_820 = find_location_loc_243_tools_location(exp_19, aux_1945);
				    }
				    {
				       bool_t test_1956;
				       if (STRUCTP(loc_820))
					 {
					    obj_t aux_1961;
					    obj_t aux_1959;
					    aux_1961 = CNST_TABLE_REF(((long) 0));
					    aux_1959 = STRUCT_KEY(loc_820);
					    test_1956 = (aux_1959 == aux_1961);
					 }
				       else
					 {
					    test_1956 = ((bool_t) 0);
					 }
				       if (test_1956)
					 {
					    loc_814 = loc_820;
					 }
				       else
					 {
					    loc_814 = oloc_21;
					 }
				    }
				 }
				 {
				    {
				       obj_t arg1539_816;
				       arg1539_816 = ____74_type_cache;
				       {
					  let_var_6_t res1800_1499;
					  {
					     type_t type_1482;
					     obj_t key_1484;
					     type_1482 = (type_t) (arg1539_816);
					     key_1484 = BINT(((long) -1));
					     {
						let_var_6_t new1365_1488;
						new1365_1488 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
						{
						   long arg1720_1489;
						   arg1720_1489 = class_num_218___object(let_var_6_ast_node);
						   {
						      obj_t obj_1497;
						      obj_1497 = (obj_t) (new1365_1488);
						      (((obj_t) CREF(obj_1497))->header = MAKE_HEADER(arg1720_1489, 0), BUNSPEC);
						   }
						}
						{
						   object_t aux_1970;
						   aux_1970 = (object_t) (new1365_1488);
						   OBJECT_WIDENING_SET(aux_1970, BFALSE);
						}
						((((let_var_6_t) CREF(new1365_1488))->loc) = ((obj_t) loc_814), BUNSPEC);
						((((let_var_6_t) CREF(new1365_1488))->type) = ((type_t) type_1482), BUNSPEC);
						((((let_var_6_t) CREF(new1365_1488))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
						((((let_var_6_t) CREF(new1365_1488))->key) = ((obj_t) key_1484), BUNSPEC);
						((((let_var_6_t) CREF(new1365_1488))->bindings) = ((obj_t) bindings_813), BUNSPEC);
						((((let_var_6_t) CREF(new1365_1488))->body) = ((node_t) body_811), BUNSPEC);
						((((let_var_6_t) CREF(new1365_1488))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
						res1800_1499 = new1365_1488;
					     }
					  }
					  return res1800_1499;
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* make-smart-generic-let */ obj_t 
make_smart_generic_let_237_ast_let(obj_t let_letrec_14_23, let_var_6_t node_let_193_24, obj_t site_25)
{
   {
      obj_t bindings_873;
      obj_t fun_874;
      obj_t value_875;
      bindings_873 = (((let_var_6_t) CREF(node_let_193_24))->bindings);
      fun_874 = BNIL;
      value_875 = BNIL;
    loop_876:
      if (NULLP(bindings_873))
	{
	   if (NULLP(fun_874))
	     {
		{
		   let_var_6_t aux_1984;
		   aux_1984 = let_or_letrec_20_ast_let(let_letrec_14_23, node_let_193_24);
		   return (obj_t) (aux_1984);
		}
	     }
	   else
	     {
		if (NULLP(value_875))
		  {
		     {
			let_fun_218_t aux_1989;
			aux_1989 = let__labels_169_ast_let(fun_874, (((let_var_6_t) CREF(node_let_193_24))->body), site_25);
			return (obj_t) (aux_1989);
		     }
		  }
		else
		  {
		     {
			obj_t arg1593_884;
			arg1593_884 = reverse__39___r4_pairs_and_lists_6_3(value_875);
			((((let_var_6_t) CREF(node_let_193_24))->bindings) = ((obj_t) arg1593_884), BUNSPEC);
		     }
		     {
			let_var_6_t let_885;
			let_885 = let_or_letrec_20_ast_let(let_letrec_14_23, node_let_193_24);
			{
			   let_fun_218_t arg1594_886;
			   arg1594_886 = let__labels_169_ast_let(fun_874, (((let_var_6_t) CREF(let_885))->body), site_25);
			   {
			      node_t val1378_1509;
			      val1378_1509 = (node_t) (arg1594_886);
			      ((((let_var_6_t) CREF(let_885))->body) = ((node_t) val1378_1509), BUNSPEC);
			   }
			}
			return (obj_t) (let_885);
		     }
		  }
	     }
	}
      else
	{
	   obj_t binding_888;
	   binding_888 = CAR(bindings_873);
	   {
	      obj_t var_889;
	      var_889 = CAR(binding_888);
	      {
		 obj_t sexp_890;
		 sexp_890 = CDR(binding_888);
		 {
		    {
		       bool_t test1596_891;
		       test1596_891 = is_a__118___object(sexp_890, let_fun_218_ast_node);
		       if (test1596_891)
			 {
			    obj_t locals_892;
			    {
			       let_fun_218_t obj_1514;
			       obj_1514 = (let_fun_218_t) (sexp_890);
			       locals_892 = (((let_fun_218_t) CREF(obj_1514))->locals);
			    }
			    {
			       node_t body_893;
			       {
				  let_fun_218_t obj_1515;
				  obj_1515 = (let_fun_218_t) (sexp_890);
				  body_893 = (((let_fun_218_t) CREF(obj_1515))->body);
			       }
			       {
				  {
				     bool_t test_2010;
				     if (NULLP(locals_892))
				       {
					  test_2010 = ((bool_t) 1);
				       }
				     else
				       {
					  bool_t test_2013;
					  {
					     obj_t aux_2014;
					     aux_2014 = CDR(locals_892);
					     test_2013 = NULLP(aux_2014);
					  }
					  if (test_2013)
					    {
					       test_2010 = ((bool_t) 0);
					    }
					  else
					    {
					       test_2010 = ((bool_t) 1);
					    }
				       }
				     if (test_2010)
				       {
					  obj_t arg1598_895;
					  obj_t arg1600_896;
					  arg1598_895 = CDR(bindings_873);
					  arg1600_896 = MAKE_PAIR(binding_888, value_875);
					  {
					     obj_t value_2020;
					     obj_t bindings_2019;
					     bindings_2019 = arg1598_895;
					     value_2020 = arg1600_896;
					     value_875 = value_2020;
					     bindings_873 = bindings_2019;
					     goto loop_876;
					  }
				       }
				     else
				       {
					  bool_t test1603_898;
					  test1603_898 = is_a__118___object((obj_t) (body_893), var_ast_node);
					  if (test1603_898)
					    {
					       bool_t test1604_901;
					       {
						  bool_t test_2024;
						  {
						     obj_t aux_2030;
						     obj_t aux_2025;
						     aux_2030 = CAR(locals_892);
						     {
							variable_t aux_2026;
							{
							   var_t obj_1524;
							   obj_1524 = (var_t) (body_893);
							   aux_2026 = (((var_t) CREF(obj_1524))->variable);
							}
							aux_2025 = (obj_t) (aux_2026);
						     }
						     test_2024 = (aux_2025 == aux_2030);
						  }
						  if (test_2024)
						    {
						       bool_t test_2033;
						       {
							  obj_t aux_2037;
							  obj_t aux_2034;
							  aux_2037 = CNST_TABLE_REF(((long) 3));
							  {
							     local_t obj_1528;
							     obj_1528 = (local_t) (var_889);
							     aux_2034 = (((local_t) CREF(obj_1528))->access);
							  }
							  test_2033 = (aux_2034 == aux_2037);
						       }
						       if (test_2033)
							 {
							    test1604_901 = ((bool_t) 1);
							 }
						       else
							 {
							    bool_t test1613_910;
							    {
							       bool_t test1614_911;
							       {
								  obj_t obj2_1533;
								  obj2_1533 = _procedure__226_type_cache;
								  {
								     obj_t aux_2040;
								     {
									type_t aux_2041;
									{
									   local_t obj_1531;
									   obj_1531 = (local_t) (var_889);
									   aux_2041 = (((local_t) CREF(obj_1531))->type);
									}
									aux_2040 = (obj_t) (aux_2041);
								     }
								     test1614_911 = (aux_2040 == obj2_1533);
								  }
							       }
							       if (test1614_911)
								 {
								    test1613_910 = ((bool_t) 1);
								 }
							       else
								 {
								    bool_t test1615_912;
								    {
								       obj_t obj2_1536;
								       obj2_1536 = ____74_type_cache;
								       {
									  obj_t aux_2047;
									  {
									     type_t aux_2048;
									     {
										local_t obj_1534;
										obj_1534 = (local_t) (var_889);
										aux_2048 = (((local_t) CREF(obj_1534))->type);
									     }
									     aux_2047 = (obj_t) (aux_2048);
									  }
									  test1615_912 = (aux_2047 == obj2_1536);
								       }
								    }
								    if (test1615_912)
								      {
									 test1613_910 = ((bool_t) 1);
								      }
								    else
								      {
									 obj_t obj2_1539;
									 obj2_1539 = _obj__252_type_cache;
									 {
									    obj_t aux_2054;
									    {
									       type_t aux_2055;
									       {
										  local_t obj_1537;
										  obj_1537 = (local_t) (var_889);
										  aux_2055 = (((local_t) CREF(obj_1537))->type);
									       }
									       aux_2054 = (obj_t) (aux_2055);
									    }
									    test1613_910 = (aux_2054 == obj2_1539);
									 }
								      }
								 }
							    }
							    if (test1613_910)
							      {
								 test1604_901 = ((bool_t) 0);
							      }
							    else
							      {
								 test1604_901 = ((bool_t) 1);
							      }
							 }
						    }
						  else
						    {
						       test1604_901 = ((bool_t) 1);
						    }
					       }
					       if (test1604_901)
						 {
						    obj_t arg1605_902;
						    obj_t arg1606_903;
						    arg1605_902 = CDR(bindings_873);
						    arg1606_903 = MAKE_PAIR(binding_888, value_875);
						    {
						       obj_t value_2065;
						       obj_t bindings_2064;
						       bindings_2064 = arg1605_902;
						       value_2065 = arg1606_903;
						       value_875 = value_2065;
						       bindings_873 = bindings_2064;
						       goto loop_876;
						    }
						 }
					       else
						 {
						    obj_t arg1608_905;
						    obj_t arg1609_906;
						    arg1608_905 = CDR(bindings_873);
						    arg1609_906 = MAKE_PAIR(binding_888, fun_874);
						    {
						       obj_t fun_2069;
						       obj_t bindings_2068;
						       bindings_2068 = arg1608_905;
						       fun_2069 = arg1609_906;
						       fun_874 = fun_2069;
						       bindings_873 = bindings_2068;
						       goto loop_876;
						    }
						 }
					    }
					  else
					    {
					       obj_t arg1623_918;
					       obj_t arg1624_919;
					       arg1623_918 = CDR(bindings_873);
					       arg1624_919 = MAKE_PAIR(binding_888, value_875);
					       {
						  obj_t value_2073;
						  obj_t bindings_2072;
						  bindings_2072 = arg1623_918;
						  value_2073 = arg1624_919;
						  value_875 = value_2073;
						  bindings_873 = bindings_2072;
						  goto loop_876;
					       }
					    }
				       }
				  }
			       }
			    }
			 }
		       else
			 {
			    obj_t arg1630_924;
			    obj_t arg1632_925;
			    arg1630_924 = CDR(bindings_873);
			    arg1632_925 = MAKE_PAIR(binding_888, value_875);
			    {
			       obj_t value_2077;
			       obj_t bindings_2076;
			       bindings_2076 = arg1630_924;
			       value_2077 = arg1632_925;
			       value_875 = value_2077;
			       bindings_873 = bindings_2076;
			       goto loop_876;
			    }
			 }
		    }
		 }
	      }
	   }
	}
   }
}


/* let-or-letrec */ let_var_6_t 
let_or_letrec_20_ast_let(obj_t let_letrec_14_26, let_var_6_t node_let_193_27)
{
   {
      bool_t test_2079;
      {
	 obj_t aux_2080;
	 aux_2080 = CNST_TABLE_REF(((long) 2));
	 test_2079 = (let_letrec_14_26 == aux_2080);
      }
      if (test_2079)
	{
	   return node_let_193_27;
	}
      else
	{
	   obj_t bindings_928;
	   bindings_928 = (((let_var_6_t) CREF(node_let_193_27))->bindings);
	   {
	      node_t body_929;
	      body_929 = (((let_var_6_t) CREF(node_let_193_27))->body);
	      {
		 obj_t seq_930;
		 {
		    bool_t test1660_959;
		    test1660_959 = is_a__118___object((obj_t) (body_929), sequence_ast_node);
		    if (test1660_959)
		      {
			 seq_930 = (obj_t) (body_929);
		      }
		    else
		      {
			 obj_t arg1661_960;
			 obj_t arg1663_961;
			 obj_t arg1666_963;
			 arg1661_960 = (((node_t) CREF(body_929))->loc);
			 arg1663_961 = ____74_type_cache;
			 {
			    obj_t list1667_964;
			    {
			       obj_t aux_2090;
			       aux_2090 = (obj_t) (body_929);
			       list1667_964 = MAKE_PAIR(aux_2090, BNIL);
			    }
			    arg1666_963 = list1667_964;
			 }
			 {
			    sequence_t res1801_1577;
			    {
			       type_t type_1564;
			       obj_t key_1566;
			       type_1564 = (type_t) (arg1663_961);
			       key_1566 = BINT(((long) -1));
			       {
				  sequence_t new1229_1568;
				  new1229_1568 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
				  {
				     long arg1748_1569;
				     arg1748_1569 = class_num_218___object(sequence_ast_node);
				     {
					obj_t obj_1575;
					obj_1575 = (obj_t) (new1229_1568);
					(((obj_t) CREF(obj_1575))->header = MAKE_HEADER(arg1748_1569, 0), BUNSPEC);
				     }
				  }
				  {
				     object_t aux_2099;
				     aux_2099 = (object_t) (new1229_1568);
				     OBJECT_WIDENING_SET(aux_2099, BFALSE);
				  }
				  ((((sequence_t) CREF(new1229_1568))->loc) = ((obj_t) arg1661_960), BUNSPEC);
				  ((((sequence_t) CREF(new1229_1568))->type) = ((type_t) type_1564), BUNSPEC);
				  ((((sequence_t) CREF(new1229_1568))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
				  ((((sequence_t) CREF(new1229_1568))->key) = ((obj_t) key_1566), BUNSPEC);
				  ((((sequence_t) CREF(new1229_1568))->nodes) = ((obj_t) arg1666_963), BUNSPEC);
				  res1801_1577 = new1229_1568;
			       }
			    }
			    seq_930 = (obj_t) (res1801_1577);
			 }
		      }
		 }
		 {
		    {
		       node_t val1378_1579;
		       val1378_1579 = (node_t) (seq_930);
		       ((((let_var_6_t) CREF(node_let_193_27))->body) = ((node_t) val1378_1579), BUNSPEC);
		    }
		    {
		       obj_t bindings_931;
		       obj_t nsequence_932;
		       bindings_931 = bindings_928;
		       {
			  sequence_t obj_1580;
			  obj_1580 = (sequence_t) (seq_930);
			  nsequence_932 = (((sequence_t) CREF(obj_1580))->nodes);
		       }
		     loop_933:
		       if (NULLP(bindings_931))
			 {
			    {
			       sequence_t arg1638_936;
			       {
				  obj_t arg1639_937;
				  obj_t arg1640_938;
				  {
				     node_t obj_1582;
				     obj_1582 = (node_t) (seq_930);
				     arg1639_937 = (((node_t) CREF(obj_1582))->loc);
				  }
				  arg1640_938 = ____74_type_cache;
				  {
				     sequence_t res1802_1597;
				     {
					type_t type_1584;
					obj_t key_1586;
					type_1584 = (type_t) (arg1640_938);
					key_1586 = BINT(((long) -1));
					{
					   sequence_t new1229_1588;
					   new1229_1588 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
					   {
					      long arg1748_1589;
					      arg1748_1589 = class_num_218___object(sequence_ast_node);
					      {
						 obj_t obj_1595;
						 obj_1595 = (obj_t) (new1229_1588);
						 (((obj_t) CREF(obj_1595))->header = MAKE_HEADER(arg1748_1589, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_2120;
					      aux_2120 = (object_t) (new1229_1588);
					      OBJECT_WIDENING_SET(aux_2120, BFALSE);
					   }
					   ((((sequence_t) CREF(new1229_1588))->loc) = ((obj_t) arg1639_937), BUNSPEC);
					   ((((sequence_t) CREF(new1229_1588))->type) = ((type_t) type_1584), BUNSPEC);
					   ((((sequence_t) CREF(new1229_1588))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
					   ((((sequence_t) CREF(new1229_1588))->key) = ((obj_t) key_1586), BUNSPEC);
					   ((((sequence_t) CREF(new1229_1588))->nodes) = ((obj_t) nsequence_932), BUNSPEC);
					   res1802_1597 = new1229_1588;
					}
				     }
				     arg1638_936 = res1802_1597;
				  }
			       }
			       {
				  node_t val1378_1599;
				  val1378_1599 = (node_t) (arg1638_936);
				  ((((let_var_6_t) CREF(node_let_193_27))->body) = ((node_t) val1378_1599), BUNSPEC);
			       }
			    }
			    return node_let_193_27;
			 }
		       else
			 {
			    obj_t binding_941;
			    binding_941 = CAR(bindings_931);
			    {
			       obj_t var_942;
			       var_942 = CAR(binding_941);
			       {
				  obj_t val_943;
				  val_943 = CDR(binding_941);
				  {
				     obj_t loc_944;
				     {
					node_t obj_1603;
					obj_1603 = (node_t) (val_943);
					loc_944 = (((node_t) CREF(obj_1603))->loc);
				     }
				     {
					{
					   setq_t init_945;
					   {
					      obj_t arg1654_953;
					      var_t arg1655_954;
					      arg1654_953 = _unspec__87_type_cache;
					      {
						 obj_t arg1658_957;
						 arg1658_957 = ____74_type_cache;
						 {
						    var_t res1803_1614;
						    {
						       type_t type_1605;
						       variable_t variable_1606;
						       type_1605 = (type_t) (arg1658_957);
						       variable_1606 = (variable_t) (var_942);
						       {
							  var_t new1206_1607;
							  new1206_1607 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							  {
							     long arg1760_1608;
							     arg1760_1608 = class_num_218___object(var_ast_node);
							     {
								obj_t obj_1612;
								obj_1612 = (obj_t) (new1206_1607);
								(((obj_t) CREF(obj_1612))->header = MAKE_HEADER(arg1760_1608, 0), BUNSPEC);
							     }
							  }
							  {
							     object_t aux_2141;
							     aux_2141 = (object_t) (new1206_1607);
							     OBJECT_WIDENING_SET(aux_2141, BFALSE);
							  }
							  ((((var_t) CREF(new1206_1607))->loc) = ((obj_t) loc_944), BUNSPEC);
							  ((((var_t) CREF(new1206_1607))->type) = ((type_t) type_1605), BUNSPEC);
							  ((((var_t) CREF(new1206_1607))->variable) = ((variable_t) variable_1606), BUNSPEC);
							  res1803_1614 = new1206_1607;
						       }
						    }
						    arg1655_954 = res1803_1614;
						 }
					      }
					      {
						 setq_t res1804_1627;
						 {
						    type_t type_1616;
						    node_t value_1618;
						    type_1616 = (type_t) (arg1654_953);
						    value_1618 = (node_t) (val_943);
						    {
						       setq_t new1299_1619;
						       new1299_1619 = ((setq_t) BREF(GC_MALLOC(sizeof(struct setq))));
						       {
							  long arg1730_1620;
							  arg1730_1620 = class_num_218___object(setq_ast_node);
							  {
							     obj_t obj_1625;
							     obj_1625 = (obj_t) (new1299_1619);
							     (((obj_t) CREF(obj_1625))->header = MAKE_HEADER(arg1730_1620, 0), BUNSPEC);
							  }
						       }
						       {
							  object_t aux_2153;
							  aux_2153 = (object_t) (new1299_1619);
							  OBJECT_WIDENING_SET(aux_2153, BFALSE);
						       }
						       ((((setq_t) CREF(new1299_1619))->loc) = ((obj_t) loc_944), BUNSPEC);
						       ((((setq_t) CREF(new1299_1619))->type) = ((type_t) type_1616), BUNSPEC);
						       ((((setq_t) CREF(new1299_1619))->var) = ((var_t) arg1655_954), BUNSPEC);
						       ((((setq_t) CREF(new1299_1619))->value) = ((node_t) value_1618), BUNSPEC);
						       res1804_1627 = new1299_1619;
						    }
						 }
						 init_945 = res1804_1627;
					      }
					   }
					   use_variable__4_ast_sexp((variable_t) (var_942), loc_944, CNST_TABLE_REF(((long) 4)));
					   {
					      node_t arg1647_947;
					      arg1647_947 = sexp__node_235_ast_sexp(BUNSPEC, BNIL, loc_944, CNST_TABLE_REF(((long) 1)));
					      {
						 obj_t aux_2165;
						 aux_2165 = (obj_t) (arg1647_947);
						 SET_CDR(binding_941, aux_2165);
					      }
					   }
					   {
					      obj_t arg1650_950;
					      obj_t arg1652_951;
					      arg1650_950 = CDR(bindings_931);
					      {
						 obj_t aux_2169;
						 aux_2169 = (obj_t) (init_945);
						 arg1652_951 = MAKE_PAIR(aux_2169, nsequence_932);
					      }
					      {
						 obj_t nsequence_2173;
						 obj_t bindings_2172;
						 bindings_2172 = arg1650_950;
						 nsequence_2173 = arg1652_951;
						 nsequence_932 = nsequence_2173;
						 bindings_931 = bindings_2172;
						 goto loop_933;
					      }
					   }
					}
				     }
				  }
			       }
			    }
			 }
		    }
		 }
	      }
	   }
	}
   }
}


/* let->labels */ let_fun_218_t 
let__labels_169_ast_let(obj_t value_bindings_254_28, node_t node_29, obj_t site_30)
{
   {
      obj_t old_funs_44_967;
      obj_t new_funs_1_968;
      if (NULLP(value_bindings_254_28))
	{
	   old_funs_44_967 = BNIL;
	}
      else
	{
	   obj_t head1454_994;
	   {
	      obj_t aux_2178;
	      {
		 obj_t aux_2179;
		 aux_2179 = CAR(value_bindings_254_28);
		 aux_2178 = CAR(aux_2179);
	      }
	      head1454_994 = MAKE_PAIR(aux_2178, BNIL);
	   }
	   {
	      obj_t l1452_995;
	      obj_t tail1455_996;
	      l1452_995 = CDR(value_bindings_254_28);
	      tail1455_996 = head1454_994;
	    lname1453_997:
	      if (NULLP(l1452_995))
		{
		   old_funs_44_967 = head1454_994;
		}
	      else
		{
		   obj_t newtail1456_1000;
		   {
		      obj_t aux_2185;
		      {
			 obj_t aux_2186;
			 aux_2186 = CAR(l1452_995);
			 aux_2185 = CAR(aux_2186);
		      }
		      newtail1456_1000 = MAKE_PAIR(aux_2185, BNIL);
		   }
		   SET_CDR(tail1455_996, newtail1456_1000);
		   {
		      obj_t tail1455_2193;
		      obj_t l1452_2191;
		      l1452_2191 = CDR(l1452_995);
		      tail1455_2193 = newtail1456_1000;
		      tail1455_996 = tail1455_2193;
		      l1452_995 = l1452_2191;
		      goto lname1453_997;
		   }
		}
	   }
	}
      if (NULLP(value_bindings_254_28))
	{
	   new_funs_1_968 = BNIL;
	}
      else
	{
	   obj_t head1459_1010;
	   head1459_1010 = MAKE_PAIR(BNIL, BNIL);
	   {
	      obj_t l1457_1011;
	      obj_t tail1460_1012;
	      l1457_1011 = value_bindings_254_28;
	      tail1460_1012 = head1459_1010;
	    lname1458_1013:
	      if (NULLP(l1457_1011))
		{
		   new_funs_1_968 = CDR(head1459_1010);
		}
	      else
		{
		   obj_t newtail1461_1015;
		   {
		      local_t arg1699_1017;
		      {
			 obj_t binding_1019;
			 binding_1019 = CAR(l1457_1011);
			 {
			    obj_t aux_1022;
			    {
			       obj_t aux_2202;
			       {
				  let_fun_218_t obj_1655;
				  {
				     obj_t aux_2203;
				     aux_2203 = CDR(binding_1019);
				     obj_1655 = (let_fun_218_t) (aux_2203);
				  }
				  aux_2202 = (((let_fun_218_t) CREF(obj_1655))->locals);
			       }
			       aux_1022 = CAR(aux_2202);
			    }
			    {
			       local_t new_1023;
			       {
				  value_t aux_2212;
				  local_t aux_2208;
				  {
				     local_t obj_1657;
				     obj_1657 = (local_t) (aux_1022);
				     aux_2212 = (((local_t) CREF(obj_1657))->value);
				  }
				  {
				     obj_t aux_2209;
				     aux_2209 = CAR(binding_1019);
				     aux_2208 = (local_t) (aux_2209);
				  }
				  new_1023 = clone_local_230_ast_local(aux_2208, aux_2212);
			       }
			       {
				  {
				     type_t arg1701_1024;
				     {
					local_t obj_1658;
					obj_1658 = (local_t) (aux_1022);
					arg1701_1024 = (((local_t) CREF(obj_1658))->type);
				     }
				     ((((local_t) CREF(new_1023))->type) = ((type_t) arg1701_1024), BUNSPEC);
				  }
				  {
				     bool_t arg1702_1025;
				     {
					bool_t _ortest_1462_1026;
					_ortest_1462_1026 = (((local_t) CREF(new_1023))->user__32);
					if (_ortest_1462_1026)
					  {
					     arg1702_1025 = _ortest_1462_1026;
					  }
					else
					  {
					     local_t obj_1662;
					     obj_1662 = (local_t) (aux_1022);
					     arg1702_1025 = (((local_t) CREF(obj_1662))->user__32);
					  }
				     }
				     ((((local_t) CREF(new_1023))->user__32) = ((bool_t) arg1702_1025), BUNSPEC);
				  }
				  arg1699_1017 = new_1023;
			       }
			    }
			 }
		      }
		      {
			 obj_t aux_2224;
			 aux_2224 = (obj_t) (arg1699_1017);
			 newtail1461_1015 = MAKE_PAIR(aux_2224, BNIL);
		      }
		   }
		   SET_CDR(tail1460_1012, newtail1461_1015);
		   {
		      obj_t tail1460_2230;
		      obj_t l1457_2228;
		      l1457_2228 = CDR(l1457_1011);
		      tail1460_2230 = newtail1461_1015;
		      tail1460_1012 = tail1460_2230;
		      l1457_1011 = l1457_2228;
		      goto lname1458_1013;
		   }
		}
	   }
	}
      {
	 obj_t vbindings_969;
	 obj_t nvars_970;
	 vbindings_969 = value_bindings_254_28;
	 nvars_970 = new_funs_1_968;
       loop_971:
	 if (NULLP(vbindings_969))
	   {
	      node_t body_973;
	      body_973 = substitute__30_ast_substitute(old_funs_44_967, new_funs_1_968, node_29, site_30);
	      {
		 obj_t arg1672_974;
		 type_t arg1673_975;
		 obj_t arg1676_977;
		 arg1672_974 = (((node_t) CREF(node_29))->loc);
		 arg1673_975 = (((node_t) CREF(node_29))->type);
		 arg1676_977 = reverse__39___r4_pairs_and_lists_6_3(new_funs_1_968);
		 {
		    let_fun_218_t res1805_1689;
		    {
		       obj_t key_1676;
		       key_1676 = BINT(((long) -1));
		       {
			  let_fun_218_t new1351_1679;
			  new1351_1679 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
			  {
			     long arg1722_1680;
			     arg1722_1680 = class_num_218___object(let_fun_218_ast_node);
			     {
				obj_t obj_1687;
				obj_1687 = (obj_t) (new1351_1679);
				(((obj_t) CREF(obj_1687))->header = MAKE_HEADER(arg1722_1680, 0), BUNSPEC);
			     }
			  }
			  {
			     object_t aux_2242;
			     aux_2242 = (object_t) (new1351_1679);
			     OBJECT_WIDENING_SET(aux_2242, BFALSE);
			  }
			  ((((let_fun_218_t) CREF(new1351_1679))->loc) = ((obj_t) arg1672_974), BUNSPEC);
			  ((((let_fun_218_t) CREF(new1351_1679))->type) = ((type_t) arg1673_975), BUNSPEC);
			  ((((let_fun_218_t) CREF(new1351_1679))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
			  ((((let_fun_218_t) CREF(new1351_1679))->key) = ((obj_t) key_1676), BUNSPEC);
			  ((((let_fun_218_t) CREF(new1351_1679))->locals) = ((obj_t) arg1676_977), BUNSPEC);
			  ((((let_fun_218_t) CREF(new1351_1679))->body) = ((node_t) body_973), BUNSPEC);
			  res1805_1689 = new1351_1679;
		       }
		    }
		    return res1805_1689;
		 }
	      }
	   }
	 else
	   {
	      obj_t nvar_980;
	      nvar_980 = CAR(nvars_970);
	      {
		 value_t sfun_981;
		 {
		    local_t obj_1692;
		    obj_1692 = (local_t) (nvar_980);
		    sfun_981 = (((local_t) CREF(obj_1692))->value);
		 }
		 {
		    obj_t body_982;
		    {
		       sfun_t obj_1693;
		       obj_1693 = (sfun_t) (sfun_981);
		       body_982 = (((sfun_t) CREF(obj_1693))->body);
		    }
		    {
		       {
			  node_t arg1678_985;
			  {
			     obj_t arg1679_986;
			     obj_t arg1680_987;
			     obj_t arg1681_988;
			     {
				obj_t aux_2256;
				{
				   obj_t aux_2257;
				   {
				      let_fun_218_t obj_1695;
				      {
					 obj_t aux_2258;
					 {
					    obj_t aux_2259;
					    aux_2259 = CAR(vbindings_969);
					    aux_2258 = CDR(aux_2259);
					 }
					 obj_1695 = (let_fun_218_t) (aux_2258);
				      }
				      aux_2257 = (((let_fun_218_t) CREF(obj_1695))->locals);
				   }
				   aux_2256 = CAR(aux_2257);
				}
				arg1679_986 = MAKE_PAIR(aux_2256, old_funs_44_967);
			     }
			     arg1680_987 = MAKE_PAIR(nvar_980, new_funs_1_968);
			     arg1681_988 = CNST_TABLE_REF(((long) 1));
			     arg1678_985 = substitute__30_ast_substitute(arg1679_986, arg1680_987, (node_t) (body_982), arg1681_988);
			  }
			  {
			     sfun_t obj_1701;
			     obj_t val1135_1702;
			     obj_1701 = (sfun_t) (sfun_981);
			     val1135_1702 = (obj_t) (arg1678_985);
			     ((((sfun_t) CREF(obj_1701))->body) = ((obj_t) val1135_1702), BUNSPEC);
			  }
		       }
		       {
			  obj_t nvars_2275;
			  obj_t vbindings_2273;
			  vbindings_2273 = CDR(vbindings_969);
			  nvars_2275 = CDR(nvars_970);
			  nvars_970 = nvars_2275;
			  vbindings_969 = vbindings_2273;
			  goto loop_971;
		       }
		    }
		 }
	      }
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_ast_let()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_let()
{
   module_initialization_70_type_type(((long) 0), "AST_LET");
   module_initialization_70_ast_var(((long) 0), "AST_LET");
   module_initialization_70_ast_node(((long) 0), "AST_LET");
   module_initialization_70_tools_trace(((long) 0), "AST_LET");
   module_initialization_70_type_cache(((long) 0), "AST_LET");
   module_initialization_70_tools_progn(((long) 0), "AST_LET");
   module_initialization_70_tools_shape(((long) 0), "AST_LET");
   module_initialization_70_tools_location(((long) 0), "AST_LET");
   module_initialization_70_ast_ident(((long) 0), "AST_LET");
   module_initialization_70_ast_sexp(((long) 0), "AST_LET");
   module_initialization_70_ast_local(((long) 0), "AST_LET");
   return module_initialization_70_ast_substitute(((long) 0), "AST_LET");
}
