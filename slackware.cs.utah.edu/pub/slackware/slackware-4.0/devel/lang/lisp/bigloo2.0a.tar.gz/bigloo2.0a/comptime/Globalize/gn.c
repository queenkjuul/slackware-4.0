/*===========================================================================*/
/*   (Globalize/gn.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


extern obj_t _g1__181_globalize_globalize;
extern obj_t _g0__244_globalize_globalize;
extern obj_t _e__34_globalize_globalize;
static obj_t method_init_76_globalize_gn();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t global_ast_var;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_gn(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_globalize_globalize(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t e_default1574_82_globalize_gn(node_t, variable_t, obj_t);
extern obj_t let_fun_218_ast_node;
extern obj_t gn__33_globalize_gn(obj_t, node_t, variable_t, obj_t);
static obj_t imported_modules_init_94_globalize_gn();
static obj_t save_app__130_globalize_gn(variable_t, variable_t);
static obj_t save_fun__213_globalize_gn(variable_t, variable_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_globalize_gn();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_globalize_gn();
static obj_t _gn_1860_48_globalize_gn(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t local_ast_var;
static obj_t g_from_cto_7_globalize_gn(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t e__176_globalize_gn(obj_t, variable_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t _e_default1574_77_globalize_gn(obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_globalize_gn = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t _e1861_globalize_gn(obj_t, obj_t, obj_t, obj_t);
static obj_t e_globalize_gn(node_t, variable_t, obj_t);
static obj_t cnst_init_137_globalize_gn();
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(gn__env_63_globalize_gn, _gn_1860_48_globalize_gn1869, _gn_1860_48_globalize_gn, 0L, 4);
DEFINE_STRING(string1863_globalize_gn, string1863_globalize_gn1870, "E-DEFAULT1574 DONE ", 19);
DEFINE_STRING(string1862_globalize_gn, string1862_globalize_gn1871, "No method for this object", 25);
DEFINE_STATIC_GENERIC(e_env_17_globalize_gn, _e1861_globalize_gn1872, _e1861_globalize_gn, 0L, 3);
DEFINE_STATIC_PROCEDURE(e_default1574_env_106_globalize_gn, _e_default1574_77_globalize_gn1873, _e_default1574_77_globalize_gn, 0L, 3);


/* module-initialization */ obj_t 
module_initialization_70_globalize_gn(long checksum_1929, char *from_1930)
{
   if (CBOOL(require_initialization_114_globalize_gn))
     {
	require_initialization_114_globalize_gn = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_gn();
	cnst_init_137_globalize_gn();
	imported_modules_init_94_globalize_gn();
	method_init_76_globalize_gn();
	toplevel_init_63_globalize_gn();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_gn()
{
   module_initialization_70___object(((long) 0), "GLOBALIZE_GN");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "GLOBALIZE_GN");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_GN");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_gn()
{
   {
      obj_t cnst_port_138_1921;
      cnst_port_138_1921 = open_input_string(string1863_globalize_gn);
      {
	 long i_1922;
	 i_1922 = ((long) 1);
       loop_1923:
	 {
	    bool_t test1864_1924;
	    test1864_1924 = (i_1922 == ((long) -1));
	    if (test1864_1924)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1865_1925;
		    {
		       obj_t list1866_1926;
		       {
			  obj_t arg1867_1927;
			  arg1867_1927 = BNIL;
			  list1866_1926 = MAKE_PAIR(cnst_port_138_1921, arg1867_1927);
		       }
		       arg1865_1925 = read___reader(list1866_1926);
		    }
		    CNST_TABLE_SET(i_1922, arg1865_1925);
		 }
		 {
		    int aux_1928;
		    {
		       long aux_1948;
		       aux_1948 = (i_1922 - ((long) 1));
		       aux_1928 = (int) (aux_1948);
		    }
		    {
		       long i_1951;
		       i_1951 = (long) (aux_1928);
		       i_1922 = i_1951;
		       goto loop_1923;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_globalize_gn()
{
   return BUNSPEC;
}


/* gn! */ obj_t 
gn__33_globalize_gn(obj_t args_1, node_t node_2, variable_t caller_3, obj_t g_4)
{
   _e__34_globalize_globalize = e_globalize_gn(node_2, caller_3, g_4);
   {
      obj_t g_1071;
      obj_t g1_1072;
      g_1071 = _e__34_globalize_globalize;
      g1_1072 = BNIL;
    loop_1073:
      if (NULLP(g_1071))
	{
	   _g0__244_globalize_globalize = append_2_18___r4_pairs_and_lists_6_3(_e__34_globalize_globalize, g1_1072);
	   return (_g1__181_globalize_globalize = g1_1072,
	      BUNSPEC);
	}
      else
	{
	   obj_t new_g_67_1076;
	   new_g_67_1076 = g_from_cto_7_globalize_gn(CAR(g_1071));
	   {
	      obj_t g1_1962;
	      obj_t g_1959;
	      g_1959 = append_2_18___r4_pairs_and_lists_6_3(new_g_67_1076, CDR(g_1071));
	      g1_1962 = append_2_18___r4_pairs_and_lists_6_3(new_g_67_1076, g1_1072);
	      g1_1072 = g1_1962;
	      g_1071 = g_1959;
	      goto loop_1073;
	   }
	}
   }
}


/* _gn!1860 */ obj_t 
_gn_1860_48_globalize_gn(obj_t env_1908, obj_t args_1909, obj_t node_1910, obj_t caller_1911, obj_t g_1912)
{
   return gn__33_globalize_gn(args_1909, (node_t) (node_1910), (variable_t) (caller_1911), g_1912);
}


/* e* */ obj_t 
e__176_globalize_gn(obj_t node__221_74, variable_t caller_75, obj_t g_76)
{
   {
      obj_t node__221_1081;
      obj_t g_1082;
      node__221_1081 = node__221_74;
      g_1082 = g_76;
    loop_1083:
      if (NULLP(node__221_1081))
	{
	   return g_1082;
	}
      else
	{
	   obj_t arg1615_1085;
	   obj_t arg1617_1086;
	   arg1615_1085 = CDR(node__221_1081);
	   {
	      node_t aux_1970;
	      {
		 obj_t aux_1971;
		 aux_1971 = CAR(node__221_1081);
		 aux_1970 = (node_t) (aux_1971);
	      }
	      arg1617_1086 = e_globalize_gn(aux_1970, caller_75, g_1082);
	   }
	   {
	      obj_t g_1976;
	      obj_t node__221_1975;
	      node__221_1975 = arg1615_1085;
	      g_1976 = arg1617_1086;
	      g_1082 = g_1976;
	      node__221_1081 = node__221_1975;
	      goto loop_1083;
	   }
	}
   }
}


/* save-app! */ obj_t 
save_app__130_globalize_gn(variable_t caller_77, variable_t callee_78)
{
   {
      bool_t test1619_1088;
      test1619_1088 = is_a__118___object((obj_t) (callee_78), global_ast_var);
      if (test1619_1088)
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   value_t callee_info_105_1089;
	   {
	      local_t obj_1689;
	      obj_1689 = (local_t) (callee_78);
	      callee_info_105_1089 = (((local_t) CREF(obj_1689))->value);
	   }
	   {
	      bool_t test_1983;
	      {
		 obj_t aux_1984;
		 {
		    obj_t aux_1985;
		    {
		       sfun_ginfo_98_t obj_1690;
		       obj_1690 = (sfun_ginfo_98_t) (callee_info_105_1089);
		       {
			  obj_t aux_1988;
			  {
			     object_t aux_1989;
			     aux_1989 = (object_t) (obj_1690);
			     aux_1988 = OBJECT_WIDENING(aux_1989);
			  }
			  aux_1985 = (((sfun_ginfo_98_t) CREF(aux_1988))->cfrom);
		       }
		    }
		    aux_1984 = memq___r4_pairs_and_lists_6_3((obj_t) (caller_77), aux_1985);
		 }
		 test_1983 = CBOOL(aux_1984);
	      }
	      if (test_1983)
		{
		   BUNSPEC;
		}
	      else
		{
		   {
		      obj_t arg1621_1091;
		      {
			 obj_t aux_1997;
			 obj_t aux_1995;
			 {
			    sfun_ginfo_98_t obj_1691;
			    obj_1691 = (sfun_ginfo_98_t) (callee_info_105_1089);
			    {
			       obj_t aux_1999;
			       {
				  object_t aux_2000;
				  aux_2000 = (object_t) (obj_1691);
				  aux_1999 = OBJECT_WIDENING(aux_2000);
			       }
			       aux_1997 = (((sfun_ginfo_98_t) CREF(aux_1999))->cfrom);
			    }
			 }
			 aux_1995 = (obj_t) (caller_77);
			 arg1621_1091 = MAKE_PAIR(aux_1995, aux_1997);
		      }
		      {
			 sfun_ginfo_98_t obj_1694;
			 obj_1694 = (sfun_ginfo_98_t) (callee_info_105_1089);
			 {
			    obj_t aux_2006;
			    {
			       object_t aux_2007;
			       aux_2007 = (object_t) (obj_1694);
			       aux_2006 = OBJECT_WIDENING(aux_2007);
			    }
			    ((((sfun_ginfo_98_t) CREF(aux_2006))->cfrom) = ((obj_t) arg1621_1091), BUNSPEC);
			 }
		      }
		   }
		   {
		      bool_t test1623_1093;
		      test1623_1093 = is_a__118___object((obj_t) (caller_77), local_ast_var);
		      if (test1623_1093)
			{
			   value_t caller_info_12_1094;
			   {
			      local_t obj_1697;
			      obj_1697 = (local_t) (caller_77);
			      caller_info_12_1094 = (((local_t) CREF(obj_1697))->value);
			   }
			   {
			      obj_t arg1624_1095;
			      {
				 obj_t aux_2018;
				 obj_t aux_2016;
				 {
				    sfun_ginfo_98_t obj_1698;
				    obj_1698 = (sfun_ginfo_98_t) (caller_info_12_1094);
				    {
				       obj_t aux_2020;
				       {
					  object_t aux_2021;
					  aux_2021 = (object_t) (obj_1698);
					  aux_2020 = OBJECT_WIDENING(aux_2021);
				       }
				       aux_2018 = (((sfun_ginfo_98_t) CREF(aux_2020))->cto);
				    }
				 }
				 aux_2016 = (obj_t) (callee_78);
				 arg1624_1095 = MAKE_PAIR(aux_2016, aux_2018);
			      }
			      {
				 sfun_ginfo_98_t obj_1701;
				 obj_1701 = (sfun_ginfo_98_t) (caller_info_12_1094);
				 {
				    obj_t aux_2027;
				    {
				       object_t aux_2028;
				       aux_2028 = (object_t) (obj_1701);
				       aux_2027 = OBJECT_WIDENING(aux_2028);
				    }
				    ((((sfun_ginfo_98_t) CREF(aux_2027))->cto) = ((obj_t) arg1624_1095), BUNSPEC);
				 }
			      }
			   }
			}
		      else
			{
			   BUNSPEC;
			}
		   }
		}
	   }
	   return CNST_TABLE_REF(((long) 0));
	}
   }
}


/* save-fun! */ obj_t 
save_fun__213_globalize_gn(variable_t caller_79, variable_t callee_80)
{
   {
      bool_t test1628_1098;
      {
	 bool_t test1634_1104;
	 test1634_1104 = is_a__118___object((obj_t) (caller_79), global_ast_var);
	 if (test1634_1104)
	   {
	      test1628_1098 = ((bool_t) 1);
	   }
	 else
	   {
	      test1628_1098 = is_a__118___object((obj_t) (callee_80), global_ast_var);
	   }
      }
      if (test1628_1098)
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   value_t caller_info_12_1099;
	   {
	      local_t obj_1705;
	      obj_1705 = (local_t) (caller_79);
	      caller_info_12_1099 = (((local_t) CREF(obj_1705))->value);
	   }
	   {
	      bool_t test_2042;
	      {
		 obj_t aux_2043;
		 {
		    obj_t aux_2044;
		    {
		       sfun_ginfo_98_t obj_1706;
		       obj_1706 = (sfun_ginfo_98_t) (caller_info_12_1099);
		       {
			  obj_t aux_2047;
			  {
			     object_t aux_2048;
			     aux_2048 = (object_t) (obj_1706);
			     aux_2047 = OBJECT_WIDENING(aux_2048);
			  }
			  aux_2044 = (((sfun_ginfo_98_t) CREF(aux_2047))->cfunction);
		       }
		    }
		    aux_2043 = memq___r4_pairs_and_lists_6_3((obj_t) (callee_80), aux_2044);
		 }
		 test_2042 = CBOOL(aux_2043);
	      }
	      if (test_2042)
		{
		   BUNSPEC;
		}
	      else
		{
		   obj_t arg1630_1101;
		   {
		      obj_t aux_2056;
		      obj_t aux_2054;
		      {
			 sfun_ginfo_98_t obj_1707;
			 obj_1707 = (sfun_ginfo_98_t) (caller_info_12_1099);
			 {
			    obj_t aux_2058;
			    {
			       object_t aux_2059;
			       aux_2059 = (object_t) (obj_1707);
			       aux_2058 = OBJECT_WIDENING(aux_2059);
			    }
			    aux_2056 = (((sfun_ginfo_98_t) CREF(aux_2058))->cfunction);
			 }
		      }
		      aux_2054 = (obj_t) (callee_80);
		      arg1630_1101 = MAKE_PAIR(aux_2054, aux_2056);
		   }
		   {
		      sfun_ginfo_98_t obj_1710;
		      obj_1710 = (sfun_ginfo_98_t) (caller_info_12_1099);
		      {
			 obj_t aux_2065;
			 {
			    object_t aux_2066;
			    aux_2066 = (object_t) (obj_1710);
			    aux_2065 = OBJECT_WIDENING(aux_2066);
			 }
			 ((((sfun_ginfo_98_t) CREF(aux_2065))->cfunction) = ((obj_t) arg1630_1101), BUNSPEC);
		      }
		   }
		}
	   }
	   return CNST_TABLE_REF(((long) 0));
	}
   }
}


/* g-from-cto */ obj_t 
g_from_cto_7_globalize_gn(obj_t local_81)
{
   {
      obj_t cto_1105;
      obj_t g_1106;
      {
	 sfun_ginfo_98_t obj_1713;
	 {
	    value_t aux_2104;
	    {
	       local_t obj_1712;
	       obj_1712 = (local_t) (local_81);
	       aux_2104 = (((local_t) CREF(obj_1712))->value);
	    }
	    obj_1713 = (sfun_ginfo_98_t) (aux_2104);
	 }
	 {
	    obj_t aux_2108;
	    {
	       object_t aux_2109;
	       aux_2109 = (object_t) (obj_1713);
	       aux_2108 = OBJECT_WIDENING(aux_2109);
	    }
	    cto_1105 = (((sfun_ginfo_98_t) CREF(aux_2108))->cto);
	 }
      }
      g_1106 = BNIL;
    loop_1107:
      if (NULLP(cto_1105))
	{
	   return g_1106;
	}
      else
	{
	   bool_t test_2073;
	   {
	      sfun_ginfo_98_t obj_1717;
	      {
		 value_t aux_2074;
		 {
		    local_t obj_1716;
		    {
		       obj_t aux_2075;
		       aux_2075 = CAR(cto_1105);
		       obj_1716 = (local_t) (aux_2075);
		    }
		    aux_2074 = (((local_t) CREF(obj_1716))->value);
		 }
		 obj_1717 = (sfun_ginfo_98_t) (aux_2074);
	      }
	      {
		 obj_t aux_2080;
		 {
		    object_t aux_2081;
		    aux_2081 = (object_t) (obj_1717);
		    aux_2080 = OBJECT_WIDENING(aux_2081);
		 }
		 test_2073 = (((sfun_ginfo_98_t) CREF(aux_2080))->g__219);
	      }
	   }
	   if (test_2073)
	     {
		{
		   obj_t cto_2085;
		   cto_2085 = CDR(cto_1105);
		   cto_1105 = cto_2085;
		   goto loop_1107;
		}
	     }
	   else
	     {
		{
		   sfun_ginfo_98_t obj_1721;
		   {
		      value_t aux_2087;
		      {
			 local_t obj_1720;
			 {
			    obj_t aux_2088;
			    aux_2088 = CAR(cto_1105);
			    obj_1720 = (local_t) (aux_2088);
			 }
			 aux_2087 = (((local_t) CREF(obj_1720))->value);
		      }
		      obj_1721 = (sfun_ginfo_98_t) (aux_2087);
		   }
		   {
		      obj_t aux_2093;
		      {
			 object_t aux_2094;
			 aux_2094 = (object_t) (obj_1721);
			 aux_2093 = OBJECT_WIDENING(aux_2094);
		      }
		      ((((sfun_ginfo_98_t) CREF(aux_2093))->g__219) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		   }
		}
		{
		   obj_t arg1648_1116;
		   obj_t arg1649_1117;
		   arg1648_1116 = CDR(cto_1105);
		   {
		      obj_t aux_2099;
		      aux_2099 = CAR(cto_1105);
		      arg1649_1117 = MAKE_PAIR(aux_2099, g_1106);
		   }
		   {
		      obj_t g_2103;
		      obj_t cto_2102;
		      cto_2102 = arg1648_1116;
		      g_2103 = arg1649_1117;
		      g_1106 = g_2103;
		      cto_1105 = cto_2102;
		      goto loop_1107;
		   }
		}
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_globalize_gn()
{
   add_generic__110___object(e_env_17_globalize_gn, e_default1574_env_106_globalize_gn);
   add_inlined_method__244___object(e_env_17_globalize_gn, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(e_env_17_globalize_gn, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(e_env_17_globalize_gn, var_ast_node, ((long) 2));
   add_inlined_method__244___object(e_env_17_globalize_gn, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(e_env_17_globalize_gn, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(e_env_17_globalize_gn, app_ast_node, ((long) 5));
   add_inlined_method__244___object(e_env_17_globalize_gn, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(e_env_17_globalize_gn, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(e_env_17_globalize_gn, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(e_env_17_globalize_gn, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(e_env_17_globalize_gn, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(e_env_17_globalize_gn, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(e_env_17_globalize_gn, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(e_env_17_globalize_gn, select_ast_node, ((long) 13));
   add_inlined_method__244___object(e_env_17_globalize_gn, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(e_env_17_globalize_gn, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(e_env_17_globalize_gn, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(e_env_17_globalize_gn, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(e_env_17_globalize_gn, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(e_env_17_globalize_gn, box_ref_242_ast_node, ((long) 19));
   {
      long aux_2134;
      aux_2134 = add_inlined_method__244___object(e_env_17_globalize_gn, box_set__221_ast_node, ((long) 20));
      return BINT(aux_2134);
   }
}


/* e */ obj_t 
e_globalize_gn(node_t node_5, variable_t caller_6, obj_t g_7)
{
 e_globalize_gn:
   {
      obj_t method1766_1516;
      obj_t class1771_1517;
      {
	 obj_t arg1774_1514;
	 obj_t arg1776_1515;
	 {
	    object_t obj_1821;
	    obj_1821 = (object_t) (node_5);
	    {
	       obj_t pre_method_105_1822;
	       pre_method_105_1822 = PROCEDURE_REF(e_env_17_globalize_gn, ((long) 2));
	       if (INTEGERP(pre_method_105_1822))
		 {
		    PROCEDURE_SET(e_env_17_globalize_gn, ((long) 2), BUNSPEC);
		    arg1774_1514 = pre_method_105_1822;
		 }
	       else
		 {
		    long obj_class_num_177_1827;
		    obj_class_num_177_1827 = TYPE(obj_1821);
		    {
		       obj_t arg1177_1828;
		       arg1177_1828 = PROCEDURE_REF(e_env_17_globalize_gn, ((long) 1));
		       {
			  long arg1178_1832;
			  {
			     long arg1179_1833;
			     arg1179_1833 = OBJECT_TYPE;
			     arg1178_1832 = (obj_class_num_177_1827 - arg1179_1833);
			  }
			  arg1774_1514 = VECTOR_REF(arg1177_1828, arg1178_1832);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1838;
	    object_1838 = (object_t) (node_5);
	    {
	       long arg1180_1839;
	       {
		  long arg1181_1840;
		  long arg1182_1841;
		  arg1181_1840 = TYPE(object_1838);
		  arg1182_1841 = OBJECT_TYPE;
		  arg1180_1839 = (arg1181_1840 - arg1182_1841);
	       }
	       {
		  obj_t vector_1845;
		  vector_1845 = _classes__134___object;
		  arg1776_1515 = VECTOR_REF(vector_1845, arg1180_1839);
	       }
	    }
	 }
	 method1766_1516 = arg1774_1514;
	 class1771_1517 = arg1776_1515;
	 {
	    if (INTEGERP(method1766_1516))
	      {
		 switch ((long) CINT(method1766_1516))
		   {
		   case ((long) 0):
		      return g_7;
		      break;
		   case ((long) 1):
		      return g_7;
		      break;
		   case ((long) 2):
		      return g_7;
		      break;
		   case ((long) 3):
		      {
			 variable_t var_1535;
			 {
			    var_t obj_1847;
			    {
			       closure_t aux_2154;
			       aux_2154 = (closure_t) (node_5);
			       obj_1847 = (var_t) (aux_2154);
			    }
			    var_1535 = (((var_t) CREF(obj_1847))->variable);
			 }
			 save_fun__213_globalize_gn(caller_6, var_1535);
			 {
			    bool_t test1779_1536;
			    {
			       bool_t test1781_1538;
			       test1781_1538 = is_a__118___object((obj_t) (var_1535), local_ast_var);
			       if (test1781_1538)
				 {
				    bool_t test_2162;
				    {
				       local_ginfo_108_t obj_1849;
				       obj_1849 = (local_ginfo_108_t) (var_1535);
				       {
					  obj_t aux_2164;
					  {
					     object_t aux_2165;
					     aux_2165 = (object_t) (obj_1849);
					     aux_2164 = OBJECT_WIDENING(aux_2165);
					  }
					  test_2162 = (((local_ginfo_108_t) CREF(aux_2164))->escape__117);
				       }
				    }
				    if (test_2162)
				      {
					 bool_t test_2169;
					 {
					    sfun_ginfo_98_t obj_1851;
					    {
					       value_t aux_2170;
					       {
						  local_t obj_1850;
						  obj_1850 = (local_t) (var_1535);
						  aux_2170 = (((local_t) CREF(obj_1850))->value);
					       }
					       obj_1851 = (sfun_ginfo_98_t) (aux_2170);
					    }
					    {
					       obj_t aux_2174;
					       {
						  object_t aux_2175;
						  aux_2175 = (object_t) (obj_1851);
						  aux_2174 = OBJECT_WIDENING(aux_2175);
					       }
					       test_2169 = (((sfun_ginfo_98_t) CREF(aux_2174))->g__219);
					    }
					 }
					 if (test_2169)
					   {
					      test1779_1536 = ((bool_t) 0);
					   }
					 else
					   {
					      test1779_1536 = ((bool_t) 1);
					   }
				      }
				    else
				      {
					 test1779_1536 = ((bool_t) 0);
				      }
				 }
			       else
				 {
				    test1779_1536 = ((bool_t) 0);
				 }
			    }
			    if (test1779_1536)
			      {
				 {
				    sfun_ginfo_98_t obj_1853;
				    {
				       value_t aux_2180;
				       {
					  local_t obj_1852;
					  obj_1852 = (local_t) (var_1535);
					  aux_2180 = (((local_t) CREF(obj_1852))->value);
				       }
				       obj_1853 = (sfun_ginfo_98_t) (aux_2180);
				    }
				    {
				       obj_t aux_2184;
				       {
					  object_t aux_2185;
					  aux_2185 = (object_t) (obj_1853);
					  aux_2184 = OBJECT_WIDENING(aux_2185);
				       }
				       ((((sfun_ginfo_98_t) CREF(aux_2184))->g__219) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				    }
				 }
				 {
				    obj_t aux_2189;
				    aux_2189 = (obj_t) (var_1535);
				    return MAKE_PAIR(aux_2189, g_7);
				 }
			      }
			    else
			      {
				 return g_7;
			      }
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1542;
			 node_1542 = (sequence_t) (node_5);
			 return e__176_globalize_gn((((sequence_t) CREF(node_1542))->nodes), caller_6, g_7);
		      }
		      break;
		   case ((long) 5):
		      {
			 app_t node_1546;
			 node_1546 = (app_t) (node_5);
			 {
			    variable_t aux_2196;
			    {
			       var_t arg1790_1551;
			       arg1790_1551 = (((app_t) CREF(node_1546))->fun);
			       aux_2196 = (((var_t) CREF(arg1790_1551))->variable);
			    }
			    save_app__130_globalize_gn(caller_6, aux_2196);
			 }
			 return e__176_globalize_gn((((app_t) CREF(node_1546))->args), caller_6, g_7);
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_1553;
			 node_1553 = (app_ly_162_t) (node_5);
			 {
			    node_t arg1792_1557;
			    obj_t arg1793_1558;
			    arg1792_1557 = (((app_ly_162_t) CREF(node_1553))->fun);
			    arg1793_1558 = e_globalize_gn((((app_ly_162_t) CREF(node_1553))->arg), caller_6, g_7);
			    {
			       obj_t g_2207;
			       node_t node_2206;
			       node_2206 = arg1792_1557;
			       g_2207 = arg1793_1558;
			       g_7 = g_2207;
			       node_5 = node_2206;
			       goto e_globalize_gn;
			    }
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_1560;
			 node_1560 = (funcall_t) (node_5);
			 {
			    node_t arg1795_1564;
			    obj_t arg1796_1565;
			    arg1795_1564 = (((funcall_t) CREF(node_1560))->fun);
			    arg1796_1565 = e__176_globalize_gn((((funcall_t) CREF(node_1560))->args), caller_6, g_7);
			    {
			       obj_t g_2213;
			       node_t node_2212;
			       node_2212 = arg1795_1564;
			       g_2213 = arg1796_1565;
			       g_7 = g_2213;
			       node_5 = node_2212;
			       goto e_globalize_gn;
			    }
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_1567;
			 node_1567 = (pragma_t) (node_5);
			 return e__176_globalize_gn((((pragma_t) CREF(node_1567))->args), caller_6, g_7);
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_1572;
			 node_1572 = (cast_t) (node_5);
			 {
			    node_t node_2218;
			    node_2218 = (((cast_t) CREF(node_1572))->arg);
			    node_5 = node_2218;
			    goto e_globalize_gn;
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_1577;
			 node_1577 = (setq_t) (node_5);
			 {
			    node_t node_2221;
			    node_2221 = (((setq_t) CREF(node_1577))->value);
			    node_5 = node_2221;
			    goto e_globalize_gn;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_1582;
			 node_1582 = (conditional_t) (node_5);
			 {
			    node_t arg1803_1586;
			    obj_t arg1804_1587;
			    arg1803_1586 = (((conditional_t) CREF(node_1582))->test);
			    {
			       node_t arg1805_1588;
			       obj_t arg1806_1589;
			       arg1805_1588 = (((conditional_t) CREF(node_1582))->true);
			       arg1806_1589 = e_globalize_gn((((conditional_t) CREF(node_1582))->false), caller_6, g_7);
			       arg1804_1587 = e_globalize_gn(arg1805_1588, caller_6, arg1806_1589);
			    }
			    {
			       obj_t g_2230;
			       node_t node_2229;
			       node_2229 = arg1803_1586;
			       g_2230 = arg1804_1587;
			       g_7 = g_2230;
			       node_5 = node_2229;
			       goto e_globalize_gn;
			    }
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_1591;
			 node_1591 = (fail_t) (node_5);
			 {
			    node_t arg1808_1595;
			    obj_t arg1809_1596;
			    arg1808_1595 = (((fail_t) CREF(node_1591))->proc);
			    {
			       node_t arg1810_1597;
			       obj_t arg1811_1598;
			       arg1810_1597 = (((fail_t) CREF(node_1591))->msg);
			       arg1811_1598 = e_globalize_gn((((fail_t) CREF(node_1591))->obj), caller_6, g_7);
			       arg1809_1596 = e_globalize_gn(arg1810_1597, caller_6, arg1811_1598);
			    }
			    {
			       obj_t g_2238;
			       node_t node_2237;
			       node_2237 = arg1808_1595;
			       g_2238 = arg1809_1596;
			       g_7 = g_2238;
			       node_5 = node_2237;
			       goto e_globalize_gn;
			    }
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_1600;
			 node_1600 = (select_t) (node_5);
			 {
			    obj_t clauses_1604;
			    obj_t g_1605;
			    clauses_1604 = (((select_t) CREF(node_1600))->clauses);
			    g_1605 = g_7;
			  loop_1606:
			    if (NULLP(clauses_1604))
			      {
				 obj_t g_2244;
				 node_t node_2242;
				 node_2242 = (((select_t) CREF(node_1600))->test);
				 g_2244 = g_1605;
				 g_7 = g_2244;
				 node_5 = node_2242;
				 goto e_globalize_gn;
			      }
			    else
			      {
				 obj_t arg1816_1610;
				 obj_t arg1817_1611;
				 arg1816_1610 = CDR(clauses_1604);
				 {
				    node_t aux_2246;
				    {
				       obj_t aux_2247;
				       {
					  obj_t aux_2248;
					  aux_2248 = CAR(clauses_1604);
					  aux_2247 = CDR(aux_2248);
				       }
				       aux_2246 = (node_t) (aux_2247);
				    }
				    arg1817_1611 = e_globalize_gn(aux_2246, caller_6, g_1605);
				 }
				 {
				    obj_t g_2254;
				    obj_t clauses_2253;
				    clauses_2253 = arg1816_1610;
				    g_2254 = arg1817_1611;
				    g_1605 = g_2254;
				    clauses_1604 = clauses_2253;
				    goto loop_1606;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_1614;
			 node_1614 = (let_fun_218_t) (node_5);
			 {
			    obj_t locals_1618;
			    obj_t g_1619;
			    locals_1618 = (((let_fun_218_t) CREF(node_1614))->locals);
			    g_1619 = g_7;
			  loop_1620:
			    if (NULLP(locals_1618))
			      {
				 obj_t g_2261;
				 node_t node_2259;
				 node_2259 = (((let_fun_218_t) CREF(node_1614))->body);
				 g_2261 = g_1619;
				 g_7 = g_2261;
				 node_5 = node_2259;
				 goto e_globalize_gn;
			      }
			    else
			      {
				 obj_t arg1824_1624;
				 obj_t arg1826_1625;
				 arg1824_1624 = CDR(locals_1618);
				 {
				    variable_t aux_2273;
				    node_t aux_2263;
				    {
				       obj_t aux_2274;
				       aux_2274 = CAR(locals_1618);
				       aux_2273 = (variable_t) (aux_2274);
				    }
				    {
				       obj_t aux_2264;
				       {
					  sfun_t obj_1886;
					  {
					     value_t aux_2265;
					     {
						local_t obj_1885;
						{
						   obj_t aux_2266;
						   aux_2266 = CAR(locals_1618);
						   obj_1885 = (local_t) (aux_2266);
						}
						aux_2265 = (((local_t) CREF(obj_1885))->value);
					     }
					     obj_1886 = (sfun_t) (aux_2265);
					  }
					  aux_2264 = (((sfun_t) CREF(obj_1886))->body);
				       }
				       aux_2263 = (node_t) (aux_2264);
				    }
				    arg1826_1625 = e_globalize_gn(aux_2263, aux_2273, g_1619);
				 }
				 {
				    obj_t g_2279;
				    obj_t locals_2278;
				    locals_2278 = arg1824_1624;
				    g_2279 = arg1826_1625;
				    g_1619 = g_2279;
				    locals_1618 = locals_2278;
				    goto loop_1620;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_1630;
			 node_1630 = (let_var_6_t) (node_5);
			 {
			    obj_t bindings_1634;
			    obj_t g_1635;
			    bindings_1634 = (((let_var_6_t) CREF(node_1630))->bindings);
			    g_1635 = g_7;
			  loop_1636:
			    if (NULLP(bindings_1634))
			      {
				 obj_t g_2286;
				 node_t node_2284;
				 node_2284 = (((let_var_6_t) CREF(node_1630))->body);
				 g_2286 = g_1635;
				 g_7 = g_2286;
				 node_5 = node_2284;
				 goto e_globalize_gn;
			      }
			    else
			      {
				 obj_t arg1835_1640;
				 obj_t arg1836_1641;
				 arg1835_1640 = CDR(bindings_1634);
				 {
				    node_t aux_2288;
				    {
				       obj_t aux_2289;
				       {
					  obj_t aux_2290;
					  aux_2290 = CAR(bindings_1634);
					  aux_2289 = CDR(aux_2290);
				       }
				       aux_2288 = (node_t) (aux_2289);
				    }
				    arg1836_1641 = e_globalize_gn(aux_2288, caller_6, g_1635);
				 }
				 {
				    obj_t g_2296;
				    obj_t bindings_2295;
				    bindings_2295 = arg1835_1640;
				    g_2296 = arg1836_1641;
				    g_1635 = g_2296;
				    bindings_1634 = bindings_2295;
				    goto loop_1636;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_1644;
			 node_1644 = (set_ex_it_116_t) (node_5);
			 {
			    node_t node_2299;
			    node_2299 = (((set_ex_it_116_t) CREF(node_1644))->body);
			    node_5 = node_2299;
			    goto e_globalize_gn;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_1649;
			 node_1649 = (jump_ex_it_184_t) (node_5);
			 {
			    node_t arg1842_1653;
			    obj_t arg1843_1654;
			    arg1842_1653 = (((jump_ex_it_184_t) CREF(node_1649))->exit);
			    arg1843_1654 = e_globalize_gn((((jump_ex_it_184_t) CREF(node_1649))->value), caller_6, g_7);
			    {
			       obj_t g_2306;
			       node_t node_2305;
			       node_2305 = arg1842_1653;
			       g_2306 = arg1843_1654;
			       g_7 = g_2306;
			       node_5 = node_2305;
			       goto e_globalize_gn;
			    }
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_1656;
			 node_1656 = (make_box_202_t) (node_5);
			 {
			    node_t node_2308;
			    node_2308 = (((make_box_202_t) CREF(node_1656))->value);
			    node_5 = node_2308;
			    goto e_globalize_gn;
			 }
		      }
		      break;
		   case ((long) 19):
		      {
			 box_ref_242_t node_1661;
			 node_1661 = (box_ref_242_t) (node_5);
			 {
			    node_t node_2311;
			    {
			       var_t aux_2312;
			       aux_2312 = (((box_ref_242_t) CREF(node_1661))->var);
			       node_2311 = (node_t) (aux_2312);
			    }
			    node_5 = node_2311;
			    goto e_globalize_gn;
			 }
		      }
		      break;
		   case ((long) 20):
		      {
			 box_set__221_t node_1666;
			 node_1666 = (box_set__221_t) (node_5);
			 {
			    var_t arg1851_1670;
			    obj_t arg1852_1671;
			    arg1851_1670 = (((box_set__221_t) CREF(node_1666))->var);
			    arg1852_1671 = e_globalize_gn((((box_set__221_t) CREF(node_1666))->value), caller_6, g_7);
			    {
			       obj_t g_2321;
			       node_t node_2319;
			       node_2319 = (node_t) (arg1851_1670);
			       g_2321 = arg1852_1671;
			       g_7 = g_2321;
			       node_5 = node_2319;
			       goto e_globalize_gn;
			    }
			 }
		      }
		      break;
		   default:
		    case_else1772_1520:
		      if (PROCEDUREP(method1766_1516))
			{
			   return PROCEDURE_ENTRY(method1766_1516) (method1766_1516, (obj_t) (node_5), (obj_t) (caller_6), g_7, BEOA);
			}
		      else
			{
			   obj_t fun1761_1510;
			   fun1761_1510 = PROCEDURE_REF(e_env_17_globalize_gn, ((long) 0));
			   return PROCEDURE_ENTRY(fun1761_1510) (fun1761_1510, (obj_t) (node_5), (obj_t) (caller_6), g_7, BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1772_1520;
	      }
	 }
      }
   }
}


/* _e1861 */ obj_t 
_e1861_globalize_gn(obj_t env_1913, obj_t node_1914, obj_t caller_1915, obj_t g_1916)
{
   return e_globalize_gn((node_t) (node_1914), (variable_t) (caller_1915), g_1916);
}


/* e-default1574 */ obj_t 
e_default1574_82_globalize_gn(node_t node_8, variable_t caller_9, obj_t g_10)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string1862_globalize_gn, (obj_t) (node_8));
}


/* _e-default1574 */ obj_t 
_e_default1574_77_globalize_gn(obj_t env_1917, obj_t node_1918, obj_t caller_1919, obj_t g_1920)
{
   return e_default1574_82_globalize_gn((node_t) (node_1918), (variable_t) (caller_1919), g_1920);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_gn()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_GN");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_GN");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_GN");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_GN");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_GN");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_GN");
   return module_initialization_70_globalize_globalize(((long) 0), "GLOBALIZE_GN");
}
