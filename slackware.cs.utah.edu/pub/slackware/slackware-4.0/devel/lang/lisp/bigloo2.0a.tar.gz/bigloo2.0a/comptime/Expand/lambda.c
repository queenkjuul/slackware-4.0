/*===========================================================================*/
/*   (Expand/lambda.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

static obj_t lambda_defines_105_expand_lambda(obj_t);
extern obj_t args___args_list_50_tools_args(obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern obj_t module_initialization_70_expand_lambda(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_expand_eps(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t _expand_lambda1234_137_expand_lambda(obj_t, obj_t, obj_t);
extern obj_t internal_begin_expander_196_expand_lambda(obj_t);
static obj_t _internal_begin_expander1235_59_expand_lambda(obj_t, obj_t);
static obj_t imported_modules_init_94_expand_lambda();
extern obj_t normalize_progn_143_tools_progn(obj_t);
extern obj_t expand_lambda_217_expand_lambda(obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_lambda();
static obj_t toplevel_init_63_expand_lambda();
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t with_lexical_22_expand_eps(obj_t, obj_t, obj_t);
static obj_t lambda1042_expand_lambda(obj_t, obj_t, obj_t);
static obj_t arg1025_expand_lambda(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_expand_lambda = BUNSPEC;
static obj_t cnst_init_137_expand_lambda();
obj_t internal_definition__7_expand_lambda = BUNSPEC;
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(internal_begin_expander_env_105_expand_lambda, _internal_begin_expander1235_59_expand_lambda1245, _internal_begin_expander1235_59_expand_lambda, 0L, 1);
DEFINE_EXPORT_PROCEDURE(expand_lambda_env_152_expand_lambda, _expand_lambda1234_137_expand_lambda1246, _expand_lambda1234_137_expand_lambda, 0L, 2);
DEFINE_STRING(string1238_expand_lambda, string1238_expand_lambda1247, "LETREC DEFINE BEGIN _ ", 22);
DEFINE_STRING(string1237_expand_lambda, string1237_expand_lambda1248, "Illegal `begin' form", 20);
DEFINE_STRING(string1236_expand_lambda, string1236_expand_lambda1249, "Illegal `lambda' form", 21);


/* module-initialization */ obj_t 
module_initialization_70_expand_lambda(long checksum_205, char *from_206)
{
   if (CBOOL(require_initialization_114_expand_lambda))
     {
	require_initialization_114_expand_lambda = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_lambda();
	cnst_init_137_expand_lambda();
	imported_modules_init_94_expand_lambda();
	toplevel_init_63_expand_lambda();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_lambda()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_LAMBDA");
   module_initialization_70___reader(((long) 0), "EXPAND_LAMBDA");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_lambda()
{
   {
      obj_t cnst_port_138_197;
      cnst_port_138_197 = open_input_string(string1238_expand_lambda);
      {
	 long i_198;
	 i_198 = ((long) 3);
       loop_199:
	 {
	    bool_t test1239_200;
	    test1239_200 = (i_198 == ((long) -1));
	    if (test1239_200)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1240_201;
		    {
		       obj_t list1241_202;
		       {
			  obj_t arg1243_203;
			  arg1243_203 = BNIL;
			  list1241_202 = MAKE_PAIR(cnst_port_138_197, arg1243_203);
		       }
		       arg1240_201 = read___reader(list1241_202);
		    }
		    CNST_TABLE_SET(i_198, arg1240_201);
		 }
		 {
		    int aux_204;
		    {
		       long aux_222;
		       aux_222 = (i_198 - ((long) 1));
		       aux_204 = (int) (aux_222);
		    }
		    {
		       long i_225;
		       i_225 = (long) (aux_204);
		       i_198 = i_225;
		       goto loop_199;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_expand_lambda()
{
   return (internal_definition__7_expand_lambda = BFALSE,
      BUNSPEC);
}


/* expand-lambda */ obj_t 
expand_lambda_217_expand_lambda(obj_t x_1, obj_t e_2)
{
   {
      obj_t old_internal_68_5;
      old_internal_68_5 = internal_definition__7_expand_lambda;
      internal_definition__7_expand_lambda = BTRUE;
      {
	 obj_t res_6;
	 {
	    obj_t lam_7;
	    obj_t args_8;
	    obj_t body_9;
	    if (PAIRP(x_1))
	      {
		 obj_t cdr_130_105_14;
		 cdr_130_105_14 = CDR(x_1);
		 if (PAIRP(cdr_130_105_14))
		   {
		      obj_t cdr_135_194_16;
		      cdr_135_194_16 = CDR(cdr_130_105_14);
		      if ((cdr_135_194_16 == BNIL))
			{
			 tag_121_151_11:
			   FAILURE(BFALSE, string1236_expand_lambda, x_1);
			}
		      else
			{
			   lam_7 = CAR(x_1);
			   args_8 = CAR(cdr_130_105_14);
			   body_9 = cdr_135_194_16;
			   {
			      obj_t arg1018_21;
			      obj_t arg1020_22;
			      arg1018_21 = args___args_list_50_tools_args(args_8);
			      arg1020_22 = CNST_TABLE_REF(((long) 0));
			      {
				 obj_t arg1025_181;
				 arg1025_181 = make_fx_procedure(arg1025_expand_lambda, ((long) 0), ((long) 4));
				 PROCEDURE_SET(arg1025_181, ((long) 0), e_2);
				 PROCEDURE_SET(arg1025_181, ((long) 1), body_9);
				 PROCEDURE_SET(arg1025_181, ((long) 2), args_8);
				 PROCEDURE_SET(arg1025_181, ((long) 3), lam_7);
				 res_6 = with_lexical_22_expand_eps(arg1018_21, arg1020_22, arg1025_181);
			      }
			   }
			}
		   }
		 else
		   {
		      goto tag_121_151_11;
		   }
	      }
	    else
	      {
		 goto tag_121_151_11;
	      }
	 }
	 internal_definition__7_expand_lambda = old_internal_68_5;
	 return replace__160_tools_misc(x_1, res_6);
      }
   }
}


/* _expand-lambda1234 */ obj_t 
_expand_lambda1234_137_expand_lambda(obj_t env_182, obj_t x_183, obj_t e_184)
{
   return expand_lambda_217_expand_lambda(x_183, e_184);
}


/* arg1025 */ obj_t 
arg1025_expand_lambda(obj_t env_185)
{
   {
      obj_t e_186;
      obj_t body_187;
      obj_t args_188;
      obj_t lam_189;
      e_186 = PROCEDURE_REF(env_185, ((long) 0));
      body_187 = PROCEDURE_REF(env_185, ((long) 1));
      args_188 = PROCEDURE_REF(env_185, ((long) 2));
      lam_189 = PROCEDURE_REF(env_185, ((long) 3));
      {
	 {
	    obj_t e_25;
	    e_25 = internal_begin_expander_196_expand_lambda(e_186);
	    {
	       obj_t arg1032_26;
	       {
		  obj_t arg1041_32;
		  arg1041_32 = normalize_progn_143_tools_progn(body_187);
		  arg1032_26 = PROCEDURE_ENTRY(e_25) (e_25, arg1041_32, e_25, BEOA);
	       }
	       {
		  obj_t list1035_28;
		  {
		     obj_t arg1038_29;
		     {
			obj_t arg1039_30;
			arg1039_30 = MAKE_PAIR(BNIL, BNIL);
			arg1038_29 = MAKE_PAIR(arg1032_26, arg1039_30);
		     }
		     list1035_28 = MAKE_PAIR(args_188, arg1038_29);
		  }
		  return cons__138___r4_pairs_and_lists_6_3(lam_189, list1035_28);
	       }
	    }
	 }
      }
   }
}


/* internal-begin-expander */ obj_t 
internal_begin_expander_196_expand_lambda(obj_t old_expander_200_3)
{
   {
      obj_t lambda1042_190;
      lambda1042_190 = make_fx_procedure(lambda1042_expand_lambda, ((long) 2), ((long) 1));
      PROCEDURE_SET(lambda1042_190, ((long) 0), old_expander_200_3);
      return lambda1042_190;
   }
}


/* _internal-begin-expander1235 */ obj_t 
_internal_begin_expander1235_59_expand_lambda(obj_t env_191, obj_t old_expander_200_192)
{
   return internal_begin_expander_196_expand_lambda(old_expander_200_192);
}


/* lambda1042 */ obj_t 
lambda1042_expand_lambda(obj_t env_193, obj_t expr_195, obj_t expander_196)
{
   {
      obj_t old_expander_200_194;
      old_expander_200_194 = PROCEDURE_REF(env_193, ((long) 0));
      {
	 obj_t expr_34;
	 obj_t expander_35;
	 expr_34 = expr_195;
	 expander_35 = expander_196;
	 {
	    obj_t res_37;
	    {
	       bool_t test_264;
	       if (PAIRP(expr_34))
		 {
		    obj_t aux_269;
		    obj_t aux_267;
		    aux_269 = CNST_TABLE_REF(((long) 1));
		    aux_267 = CAR(expr_34);
		    test_264 = (aux_267 == aux_269);
		 }
	       else
		 {
		    test_264 = ((bool_t) 0);
		 }
	       if (test_264)
		 {
		    bool_t test_272;
		    {
		       obj_t aux_273;
		       aux_273 = CDR(expr_34);
		       test_272 = NULLP(aux_273);
		    }
		    if (test_272)
		      {
			 FAILURE(BFALSE, string1237_expand_lambda, expr_34);
		      }
		    else
		      {
			 obj_t arg1053_41;
			 obj_t arg1055_42;
			 arg1053_41 = CNST_TABLE_REF(((long) 1));
			 {
			    obj_t arg1058_45;
			    obj_t arg1059_46;
			    {
			       obj_t arg1060_47;
			       {
				  obj_t l1002_48;
				  l1002_48 = CDR(expr_34);
				  if (NULLP(l1002_48))
				    {
				       arg1060_47 = BNIL;
				    }
				  else
				    {
				       obj_t head1004_50;
				       head1004_50 = MAKE_PAIR(BNIL, BNIL);
				       {
					  obj_t l1002_51;
					  obj_t tail1005_52;
					  l1002_51 = l1002_48;
					  tail1005_52 = head1004_50;
					lname1003_53:
					  if (NULLP(l1002_51))
					    {
					       arg1060_47 = CDR(head1004_50);
					    }
					  else
					    {
					       obj_t newtail1006_55;
					       {
						  obj_t arg1137_57;
						  arg1137_57 = PROCEDURE_ENTRY(expander_35) (expander_35, CAR(l1002_51), expander_35, BEOA);
						  newtail1006_55 = MAKE_PAIR(arg1137_57, BNIL);
					       }
					       SET_CDR(tail1005_52, newtail1006_55);
					       {
						  obj_t tail1005_292;
						  obj_t l1002_290;
						  l1002_290 = CDR(l1002_51);
						  tail1005_292 = newtail1006_55;
						  tail1005_52 = tail1005_292;
						  l1002_51 = l1002_290;
						  goto lname1003_53;
					       }
					    }
				       }
				    }
			       }
			       arg1058_45 = lambda_defines_105_expand_lambda(arg1060_47);
			    }
			    arg1059_46 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
			    arg1055_42 = append_2_18___r4_pairs_and_lists_6_3(arg1058_45, arg1059_46);
			 }
			 {
			    obj_t list1056_43;
			    list1056_43 = MAKE_PAIR(arg1055_42, BNIL);
			    res_37 = cons__138___r4_pairs_and_lists_6_3(arg1053_41, list1056_43);
			 }
		      }
		 }
	       else
		 {
		    res_37 = PROCEDURE_ENTRY(old_expander_200_194) (old_expander_200_194, expr_34, expander_35, BEOA);
		 }
	    }
	    if (PAIRP(res_37))
	      {
		 return replace__160_tools_misc(expr_34, res_37);
	      }
	    else
	      {
		 return res_37;
	      }
	 }
      }
   }
}


/* lambda-defines */ obj_t 
lambda_defines_105_expand_lambda(obj_t body_4)
{
   {
      obj_t oldforms_68;
      obj_t newforms_69;
      obj_t vars_70;
      obj_t decls_71;
      oldforms_68 = body_4;
      newforms_69 = BNIL;
      vars_70 = BNIL;
      decls_71 = BNIL;
    loop_72:
      if (PAIRP(oldforms_68))
	{
	   obj_t form_77;
	   form_77 = CAR(oldforms_68);
	   {
	      obj_t var_78;
	      obj_t val_79;
	      if (PAIRP(form_77))
		{
		   obj_t cdr_147_183_84;
		   cdr_147_183_84 = CDR(form_77);
		   {
		      bool_t test_309;
		      {
			 obj_t aux_312;
			 obj_t aux_310;
			 aux_312 = CNST_TABLE_REF(((long) 2));
			 aux_310 = CAR(form_77);
			 test_309 = (aux_310 == aux_312);
		      }
		      if (test_309)
			{
			   if (PAIRP(cdr_147_183_84))
			     {
				obj_t cdr_151_70_87;
				cdr_151_70_87 = CDR(cdr_147_183_84);
				if (PAIRP(cdr_151_70_87))
				  {
				     bool_t test_320;
				     {
					obj_t aux_321;
					aux_321 = CDR(cdr_151_70_87);
					test_320 = (aux_321 == BNIL);
				     }
				     if (test_320)
				       {
					  var_78 = CAR(cdr_147_183_84);
					  val_79 = CAR(cdr_151_70_87);
					  {
					     obj_t arg1203_96;
					     obj_t arg1204_97;
					     obj_t arg1205_98;
					     arg1203_96 = CDR(oldforms_68);
					     arg1204_97 = MAKE_PAIR(var_78, vars_70);
					     {
						obj_t arg1206_99;
						{
						   obj_t list1208_101;
						   {
						      obj_t arg1209_102;
						      arg1209_102 = MAKE_PAIR(BNIL, BNIL);
						      list1208_101 = MAKE_PAIR(val_79, arg1209_102);
						   }
						   arg1206_99 = cons__138___r4_pairs_and_lists_6_3(var_78, list1208_101);
						}
						arg1205_98 = MAKE_PAIR(arg1206_99, decls_71);
					     }
					     {
						obj_t decls_332;
						obj_t vars_331;
						obj_t oldforms_330;
						oldforms_330 = arg1203_96;
						vars_331 = arg1204_97;
						decls_332 = arg1205_98;
						decls_71 = decls_332;
						vars_70 = vars_331;
						oldforms_68 = oldforms_330;
						goto loop_72;
					     }
					  }
				       }
				     else
				       {
					tag_140_156_81:
					  {
					     obj_t arg1211_104;
					     obj_t arg1213_105;
					     arg1211_104 = CDR(oldforms_68);
					     arg1213_105 = MAKE_PAIR(form_77, newforms_69);
					     {
						obj_t newforms_338;
						obj_t oldforms_337;
						oldforms_337 = arg1211_104;
						newforms_338 = arg1213_105;
						newforms_69 = newforms_338;
						oldforms_68 = oldforms_337;
						goto loop_72;
					     }
					  }
				       }
				  }
				else
				  {
				     goto tag_140_156_81;
				  }
			     }
			   else
			     {
				goto tag_140_156_81;
			     }
			}
		      else
			{
			   goto tag_140_156_81;
			}
		   }
		}
	      else
		{
		   goto tag_140_156_81;
		}
	   }
	}
      else
	{
	   if (NULLP(newforms_69))
	     {
		FAILURE(BFALSE, string1237_expand_lambda, body_4);
	     }
	   else
	     {
		if (NULLP(vars_70))
		  {
		     return body_4;
		  }
		else
		  {
		     {
			obj_t arg1216_108;
			{
			   obj_t arg1222_112;
			   obj_t arg1224_113;
			   arg1222_112 = CNST_TABLE_REF(((long) 3));
			   arg1224_113 = normalize_progn_143_tools_progn(reverse___r4_pairs_and_lists_6_3(newforms_69));
			   {
			      obj_t list1226_115;
			      {
				 obj_t arg1228_116;
				 {
				    obj_t arg1231_117;
				    arg1231_117 = MAKE_PAIR(BNIL, BNIL);
				    arg1228_116 = MAKE_PAIR(arg1224_113, arg1231_117);
				 }
				 list1226_115 = MAKE_PAIR(decls_71, arg1228_116);
			      }
			      arg1216_108 = cons__138___r4_pairs_and_lists_6_3(arg1222_112, list1226_115);
			   }
			}
			{
			   obj_t list1220_110;
			   list1220_110 = MAKE_PAIR(BNIL, BNIL);
			   return cons__138___r4_pairs_and_lists_6_3(arg1216_108, list1220_110);
			}
		     }
		  }
	     }
	}
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_lambda()
{
   module_initialization_70_tools_trace(((long) 0), "EXPAND_LAMBDA");
   module_initialization_70_tools_args(((long) 0), "EXPAND_LAMBDA");
   module_initialization_70_tools_progn(((long) 0), "EXPAND_LAMBDA");
   module_initialization_70_tools_misc(((long) 0), "EXPAND_LAMBDA");
   module_initialization_70_expand_eps(((long) 0), "EXPAND_LAMBDA");
   return module_initialization_70_engine_param(((long) 0), "EXPAND_LAMBDA");
}
