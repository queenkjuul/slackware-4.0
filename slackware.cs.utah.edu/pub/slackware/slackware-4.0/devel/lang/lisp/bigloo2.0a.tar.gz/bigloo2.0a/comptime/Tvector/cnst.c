/*===========================================================================*/
/*   (Tvector/cnst.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct tvec
  {
     struct type *item_type_130;
  }
    *tvec_t;


extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
extern obj_t _long__149_type_cache;
static obj_t method_init_76_tvector_cnst();
static obj_t _tvector_c_static__159_tvector_cnst(obj_t, obj_t);
extern bool_t tvector_c_static__211_tvector_cnst(obj_t);
static obj_t tvector_c_printer_216_tvector_cnst(obj_t);
extern obj_t module_initialization_70_tvector_cnst(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tvector_tvector(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t _real__144_type_cache;
static obj_t imported_modules_init_94_tvector_cnst();
static obj_t _tvector__c_vector_218_tvector_cnst(obj_t, obj_t);
extern obj_t tvector__c_vector_165_tvector_cnst(obj_t);
static obj_t library_modules_init_112_tvector_cnst();
static obj_t toplevel_init_63_tvector_cnst();
extern obj_t close_output_port(obj_t);
static obj_t lambda1165_tvector_cnst(obj_t, obj_t, obj_t);
static obj_t lambda1154_tvector_cnst(obj_t, obj_t, obj_t);
extern obj_t open_output_string();
static obj_t _write___r4_output_6_10_3(obj_t, obj_t, obj_t);
static obj_t _display___r4_output_6_10_3(obj_t, obj_t, obj_t);
extern obj_t _char__84_type_cache;
extern obj_t _string__3_type_cache;
static obj_t require_initialization_114_tvector_cnst = BUNSPEC;
extern obj_t _int__35_type_cache;
extern obj_t _bool__149_type_cache;
static obj_t *__cnst;

extern obj_t display_env_131___r4_output_6_10_3;
DEFINE_EXPORT_PROCEDURE(tvector__c_vector_env_35_tvector_cnst, _tvector__c_vector_218_tvector_cnst1226, _tvector__c_vector_218_tvector_cnst, 0L, 1);
extern obj_t write_env_37___r4_output_6_10_3;
DEFINE_STATIC_PROCEDURE(proc1218_tvector_cnst, lambda1165_tvector_cnst1227, lambda1165_tvector_cnst, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1217_tvector_cnst, lambda1154_tvector_cnst1228, lambda1154_tvector_cnst, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvector_c_static__env_219_tvector_cnst, _tvector_c_static__159_tvector_cnst1229, _tvector_c_static__159_tvector_cnst, 0L, 1);
DEFINE_STRING(string1224_tvector_cnst, string1224_tvector_cnst1230, ", ", 2);
DEFINE_STRING(string1223_tvector_cnst, string1223_tvector_cnst1231, "0", 1);
DEFINE_STRING(string1222_tvector_cnst, string1222_tvector_cnst1232, "1", 1);
DEFINE_STRING(string1221_tvector_cnst, string1221_tvector_cnst1233, "(unsigned char)", 15);
DEFINE_STRING(string1219_tvector_cnst, string1219_tvector_cnst1234, "tvector-c-printer", 17);
DEFINE_STRING(string1220_tvector_cnst, string1220_tvector_cnst1235, "This tvector can't not be compiled as a static C vector", 55);


/* module-initialization */ obj_t 
module_initialization_70_tvector_cnst(long checksum_300, char *from_301)
{
   if (CBOOL(require_initialization_114_tvector_cnst))
     {
	require_initialization_114_tvector_cnst = BBOOL(((bool_t) 0));
	library_modules_init_112_tvector_cnst();
	imported_modules_init_94_tvector_cnst();
	method_init_76_tvector_cnst();
	toplevel_init_63_tvector_cnst();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tvector_cnst()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "TVECTOR_CNST");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_tvector_cnst()
{
   return BUNSPEC;
}


/* tvector-c-static? */ bool_t 
tvector_c_static__211_tvector_cnst(obj_t tvect_11)
{
   {
      type_t itype_128;
      {
	 tvec_t obj_215;
	 {
	    obj_t aux_310;
	    aux_310 = STRUCT_REF(tvect_11, ((long) 0));
	    obj_215 = (tvec_t) (aux_310);
	 }
	 {
	    obj_t aux_313;
	    {
	       object_t aux_314;
	       aux_314 = (object_t) (obj_215);
	       aux_313 = OBJECT_WIDENING(aux_314);
	    }
	    itype_128 = (((tvec_t) CREF(aux_313))->item_type_130);
	 }
      }
      {
	 bool_t test1139_129;
	 {
	    obj_t obj2_217;
	    obj2_217 = _long__149_type_cache;
	    {
	       obj_t aux_318;
	       aux_318 = (obj_t) (itype_128);
	       test1139_129 = (aux_318 == obj2_217);
	    }
	 }
	 if (test1139_129)
	   {
	      return ((bool_t) 1);
	   }
	 else
	   {
	      bool_t test1140_130;
	      {
		 obj_t obj2_219;
		 obj2_219 = _int__35_type_cache;
		 {
		    obj_t aux_322;
		    aux_322 = (obj_t) (itype_128);
		    test1140_130 = (aux_322 == obj2_219);
		 }
	      }
	      if (test1140_130)
		{
		   return ((bool_t) 1);
		}
	      else
		{
		   bool_t test1141_131;
		   {
		      obj_t obj2_221;
		      obj2_221 = _char__84_type_cache;
		      {
			 obj_t aux_326;
			 aux_326 = (obj_t) (itype_128);
			 test1141_131 = (aux_326 == obj2_221);
		      }
		   }
		   if (test1141_131)
		     {
			return ((bool_t) 1);
		     }
		   else
		     {
			bool_t test1143_132;
			{
			   obj_t obj2_223;
			   obj2_223 = _bool__149_type_cache;
			   {
			      obj_t aux_330;
			      aux_330 = (obj_t) (itype_128);
			      test1143_132 = (aux_330 == obj2_223);
			   }
			}
			if (test1143_132)
			  {
			     return ((bool_t) 1);
			  }
			else
			  {
			     bool_t test1146_133;
			     {
				obj_t obj2_225;
				obj2_225 = _string__3_type_cache;
				{
				   obj_t aux_334;
				   aux_334 = (obj_t) (itype_128);
				   test1146_133 = (aux_334 == obj2_225);
				}
			     }
			     if (test1146_133)
			       {
				  return ((bool_t) 1);
			       }
			     else
			       {
				  bool_t test1147_134;
				  {
				     obj_t obj2_227;
				     obj2_227 = _real__144_type_cache;
				     {
					obj_t aux_338;
					aux_338 = (obj_t) (itype_128);
					test1147_134 = (aux_338 == obj2_227);
				     }
				  }
				  if (test1147_134)
				    {
				       return ((bool_t) 1);
				    }
				  else
				    {
				       return ((bool_t) 0);
				    }
			       }
			  }
		     }
		}
	   }
      }
   }
}


/* _tvector-c-static? */ obj_t 
_tvector_c_static__159_tvector_cnst(obj_t env_281, obj_t tvect_282)
{
   {
      bool_t aux_342;
      aux_342 = tvector_c_static__211_tvector_cnst(tvect_282);
      return BBOOL(aux_342);
   }
}


/* tvector-c-printer */ obj_t 
tvector_c_printer_216_tvector_cnst(obj_t tvect_12)
{
   {
      type_t itype_136;
      {
	 tvec_t obj_231;
	 {
	    obj_t aux_345;
	    aux_345 = STRUCT_REF(tvect_12, ((long) 0));
	    obj_231 = (tvec_t) (aux_345);
	 }
	 {
	    obj_t aux_348;
	    {
	       object_t aux_349;
	       aux_349 = (object_t) (obj_231);
	       aux_348 = OBJECT_WIDENING(aux_349);
	    }
	    itype_136 = (((tvec_t) CREF(aux_348))->item_type_130);
	 }
      }
      {
	 bool_t test1151_137;
	 {
	    obj_t obj2_233;
	    obj2_233 = _long__149_type_cache;
	    {
	       obj_t aux_353;
	       aux_353 = (obj_t) (itype_136);
	       test1151_137 = (aux_353 == obj2_233);
	    }
	 }
	 if (test1151_137)
	   {
	      return display_env_131___r4_output_6_10_3;
	   }
	 else
	   {
	      bool_t test1152_138;
	      {
		 obj_t obj2_235;
		 obj2_235 = _int__35_type_cache;
		 {
		    obj_t aux_357;
		    aux_357 = (obj_t) (itype_136);
		    test1152_138 = (aux_357 == obj2_235);
		 }
	      }
	      if (test1152_138)
		{
		   return display_env_131___r4_output_6_10_3;
		}
	      else
		{
		   bool_t test1153_139;
		   {
		      obj_t obj2_237;
		      obj2_237 = _char__84_type_cache;
		      {
			 obj_t aux_361;
			 aux_361 = (obj_t) (itype_136);
			 test1153_139 = (aux_361 == obj2_237);
		      }
		   }
		   if (test1153_139)
		     {
			{
			   obj_t lambda1154_283;
			   lambda1154_283 = proc1217_tvector_cnst;
			   return lambda1154_283;
			}
		     }
		   else
		     {
			bool_t test1164_148;
			{
			   obj_t obj2_240;
			   obj2_240 = _bool__149_type_cache;
			   {
			      obj_t aux_365;
			      aux_365 = (obj_t) (itype_136);
			      test1164_148 = (aux_365 == obj2_240);
			   }
			}
			if (test1164_148)
			  {
			     {
				obj_t lambda1165_284;
				lambda1165_284 = proc1218_tvector_cnst;
				return lambda1165_284;
			     }
			  }
			else
			  {
			     bool_t test1189_156;
			     {
				obj_t obj2_242;
				obj2_242 = _string__3_type_cache;
				{
				   obj_t aux_369;
				   aux_369 = (obj_t) (itype_136);
				   test1189_156 = (aux_369 == obj2_242);
				}
			     }
			     if (test1189_156)
			       {
				  return write_env_37___r4_output_6_10_3;
			       }
			     else
			       {
				  bool_t test1191_157;
				  {
				     obj_t obj2_244;
				     obj2_244 = _real__144_type_cache;
				     {
					obj_t aux_373;
					aux_373 = (obj_t) (itype_136);
					test1191_157 = (aux_373 == obj2_244);
				     }
				  }
				  if (test1191_157)
				    {
				       return display_env_131___r4_output_6_10_3;
				    }
				  else
				    {
				       FAILURE(string1219_tvector_cnst, string1220_tvector_cnst, tvect_12);
				    }
			       }
			  }
		     }
		}
	   }
      }
   }
}


/* lambda1154 */ obj_t 
lambda1154_tvector_cnst(obj_t env_285, obj_t x_286, obj_t port_287)
{
   {
      obj_t x_140;
      obj_t port_141;
      x_140 = x_286;
      port_141 = port_287;
      {
	 obj_t list1155_143;
	 list1155_143 = MAKE_PAIR(port_141, BNIL);
	 display___r4_output_6_10_3(string1221_tvector_cnst, list1155_143);
      }
      {
	 long arg1161_145;
	 {
	    unsigned char aux_380;
	    aux_380 = (unsigned char) CCHAR(x_140);
	    arg1161_145 = (aux_380);
	 }
	 {
	    obj_t list1162_146;
	    list1162_146 = MAKE_PAIR(port_141, BNIL);
	    return display___r4_output_6_10_3(BINT(arg1161_145), list1162_146);
	 }
      }
   }
}


/* lambda1165 */ obj_t 
lambda1165_tvector_cnst(obj_t env_288, obj_t x_289, obj_t port_290)
{
   {
      obj_t x_149;
      obj_t port_150;
      x_149 = x_289;
      port_150 = port_290;
      if (CBOOL(x_149))
	{
	   obj_t list1166_152;
	   list1166_152 = MAKE_PAIR(port_150, BNIL);
	   return display___r4_output_6_10_3(string1222_tvector_cnst, list1166_152);
	}
      else
	{
	   obj_t list1176_154;
	   list1176_154 = MAKE_PAIR(port_150, BNIL);
	   return display___r4_output_6_10_3(string1223_tvector_cnst, list1176_154);
	}
   }
}


/* tvector->c-vector */ obj_t 
tvector__c_vector_165_tvector_cnst(obj_t tvector_13)
{
   {
      obj_t vect_159;
      vect_159 = STRUCT_REF(tvector_13, ((long) 1));
      {
	 obj_t c_printer_19_160;
	 c_printer_19_160 = tvector_c_printer_216_tvector_cnst(tvector_13);
	 {
	    long len_1_56_161;
	    {
	       long aux_394;
	       aux_394 = VECTOR_LENGTH(vect_159);
	       len_1_56_161 = (aux_394 - ((long) 1));
	    }
	    {
	       obj_t port_162;
	       port_162 = open_output_string();
	       {
		  {
		     obj_t list1193_163;
		     list1193_163 = MAKE_PAIR(port_162, BNIL);
		     display___r4_output_6_10_3(BCHAR(((unsigned char) '{')), list1193_163);
		  }
		  {
		     long i_165;
		     i_165 = ((long) 0);
		   loop_166:
		     if ((i_165 == len_1_56_161))
		       {
			  PROCEDURE_ENTRY(c_printer_19_160) (c_printer_19_160, VECTOR_REF(vect_159, i_165), port_162, BEOA);
			  {
			     obj_t list1197_169;
			     list1197_169 = MAKE_PAIR(port_162, BNIL);
			     display___r4_output_6_10_3(BCHAR(((unsigned char) '}')), list1197_169);
			  }
			  return close_output_port(port_162);
		       }
		     else
		       {
			  PROCEDURE_ENTRY(c_printer_19_160) (c_printer_19_160, VECTOR_REF(vect_159, i_165), port_162, BEOA);
			  {
			     obj_t list1201_172;
			     list1201_172 = MAKE_PAIR(port_162, BNIL);
			     display___r4_output_6_10_3(string1224_tvector_cnst, list1201_172);
			  }
			  {
			     long i_415;
			     i_415 = (i_165 + ((long) 1));
			     i_165 = i_415;
			     goto loop_166;
			  }
		       }
		  }
	       }
	    }
	 }
      }
   }
}


/* _tvector->c-vector */ obj_t 
_tvector__c_vector_218_tvector_cnst(obj_t env_297, obj_t tvector_298)
{
   return tvector__c_vector_165_tvector_cnst(tvector_298);
}


/* method-init */ obj_t 
method_init_76_tvector_cnst()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tvector_cnst()
{
   module_initialization_70_type_type(((long) 0), "TVECTOR_CNST");
   module_initialization_70_type_env(((long) 0), "TVECTOR_CNST");
   module_initialization_70_type_cache(((long) 0), "TVECTOR_CNST");
   return module_initialization_70_tvector_tvector(((long) 0), "TVECTOR_CNST");
}
