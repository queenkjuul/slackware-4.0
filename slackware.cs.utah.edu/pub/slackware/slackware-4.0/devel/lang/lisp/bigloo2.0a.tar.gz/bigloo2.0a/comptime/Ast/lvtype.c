/*===========================================================================*/
/*   (Ast/lvtype.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_ast_lvtype();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t lvtype_node__58_ast_lvtype(node_t);
static obj_t _lvtype_node__default1460_93_ast_lvtype(obj_t, obj_t);
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t module_initialization_70_ast_lvtype(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t lvtype_node__default1460_116_ast_lvtype(node_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_ast_lvtype();
static obj_t _lvtype_node__190_ast_lvtype(obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static bool_t lvtype_node___164_ast_lvtype(obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_ast_lvtype();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_ast_lvtype();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern type_t typeof_coerce_typeof(node_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t set_variable_type__9_ast_lvtype(variable_t, type_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_lvtype = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_ast_lvtype();
static obj_t __cnst[1];

DEFINE_EXPORT_GENERIC(lvtype_node__env_81_ast_lvtype, _lvtype_node__190_ast_lvtype1670, _lvtype_node__190_ast_lvtype, 0L, 1);
DEFINE_STATIC_PROCEDURE(lvtype_node__default1460_env_159_ast_lvtype, _lvtype_node__default1460_93_ast_lvtype1671, _lvtype_node__default1460_93_ast_lvtype, 0L, 1);
DEFINE_STRING(string1664_ast_lvtype, string1664_ast_lvtype1672, "LVTYPE-NODE!-DEFAULT1460 ", 25);
DEFINE_STRING(string1663_ast_lvtype, string1663_ast_lvtype1673, "No method for this object", 25);
DEFINE_STRING(string1662_ast_lvtype, string1662_ast_lvtype1674, "Unexpected closure", 18);
DEFINE_STRING(string1661_ast_lvtype, string1661_ast_lvtype1675, "lvtype-node!", 12);


/* module-initialization */ obj_t 
module_initialization_70_ast_lvtype(long checksum_1265, char *from_1266)
{
   if (CBOOL(require_initialization_114_ast_lvtype))
     {
	require_initialization_114_ast_lvtype = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_lvtype();
	cnst_init_137_ast_lvtype();
	imported_modules_init_94_ast_lvtype();
	method_init_76_ast_lvtype();
	toplevel_init_63_ast_lvtype();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_lvtype()
{
   module_initialization_70___object(((long) 0), "AST_LVTYPE");
   module_initialization_70___reader(((long) 0), "AST_LVTYPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_lvtype()
{
   {
      obj_t cnst_port_138_1257;
      cnst_port_138_1257 = open_input_string(string1664_ast_lvtype);
      {
	 long i_1258;
	 i_1258 = ((long) 0);
       loop_1259:
	 {
	    bool_t test1665_1260;
	    test1665_1260 = (i_1258 == ((long) -1));
	    if (test1665_1260)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1666_1261;
		    {
		       obj_t list1667_1262;
		       {
			  obj_t arg1668_1263;
			  arg1668_1263 = BNIL;
			  list1667_1262 = MAKE_PAIR(cnst_port_138_1257, arg1668_1263);
		       }
		       arg1666_1261 = read___reader(list1667_1262);
		    }
		    CNST_TABLE_SET(i_1258, arg1666_1261);
		 }
		 {
		    int aux_1264;
		    {
		       long aux_1283;
		       aux_1283 = (i_1258 - ((long) 1));
		       aux_1264 = (int) (aux_1283);
		    }
		    {
		       long i_1286;
		       i_1286 = (long) (aux_1264);
		       i_1258 = i_1286;
		       goto loop_1259;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_lvtype()
{
   return BUNSPEC;
}


/* lvtype-node*! */ bool_t 
lvtype_node___164_ast_lvtype(obj_t node__221_24)
{
   {
      obj_t l1458_718;
      l1458_718 = node__221_24;
    lname1459_719:
      if (PAIRP(l1458_718))
	{
	   {
	      node_t aux_1290;
	      {
		 obj_t aux_1291;
		 aux_1291 = CAR(l1458_718);
		 aux_1290 = (node_t) (aux_1291);
	      }
	      lvtype_node__58_ast_lvtype(aux_1290);
	   }
	   {
	      obj_t l1458_1295;
	      l1458_1295 = CDR(l1458_718);
	      l1458_718 = l1458_1295;
	      goto lname1459_719;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* set-variable-type! */ obj_t 
set_variable_type__9_ast_lvtype(variable_t variable_25, type_t type_26)
{
   {
      obj_t ntype_723;
      {
	 bool_t test1488_726;
	 {
	    obj_t obj2_1170;
	    obj2_1170 = ____74_type_cache;
	    {
	       obj_t aux_1297;
	       aux_1297 = (obj_t) (type_26);
	       test1488_726 = (aux_1297 == obj2_1170);
	    }
	 }
	 if (test1488_726)
	   {
	      ntype_723 = _obj__252_type_cache;
	   }
	 else
	   {
	      ntype_723 = (obj_t) (type_26);
	   }
      }
      {
	 bool_t test1487_725;
	 {
	    obj_t obj2_1173;
	    obj2_1173 = ____74_type_cache;
	    {
	       obj_t aux_1302;
	       {
		  type_t aux_1303;
		  aux_1303 = (((variable_t) CREF(variable_25))->type);
		  aux_1302 = (obj_t) (aux_1303);
	       }
	       test1487_725 = (aux_1302 == obj2_1173);
	    }
	 }
	 if (test1487_725)
	   {
	      type_t val1042_1175;
	      val1042_1175 = (type_t) (ntype_723);
	      return ((((variable_t) CREF(variable_25))->type) = ((type_t) val1042_1175), BUNSPEC);
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_ast_lvtype()
{
   add_generic__110___object(lvtype_node__env_81_ast_lvtype, lvtype_node__default1460_env_159_ast_lvtype);
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, var_ast_node, ((long) 2));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, app_ast_node, ((long) 5));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, select_ast_node, ((long) 13));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, box_set__221_ast_node, ((long) 19));
   {
      long aux_1331;
      aux_1331 = add_inlined_method__244___object(lvtype_node__env_81_ast_lvtype, box_ref_242_ast_node, ((long) 20));
      return BINT(aux_1331);
   }
}


/* lvtype-node! */ obj_t 
lvtype_node__58_ast_lvtype(node_t node_1)
{
 lvtype_node__58_ast_lvtype:
   {
      obj_t method1585_1058;
      obj_t class1590_1059;
      {
	 obj_t arg1593_1056;
	 obj_t arg1594_1057;
	 {
	    object_t obj_1176;
	    obj_1176 = (object_t) (node_1);
	    {
	       obj_t pre_method_105_1177;
	       pre_method_105_1177 = PROCEDURE_REF(lvtype_node__env_81_ast_lvtype, ((long) 2));
	       if (INTEGERP(pre_method_105_1177))
		 {
		    PROCEDURE_SET(lvtype_node__env_81_ast_lvtype, ((long) 2), BUNSPEC);
		    arg1593_1056 = pre_method_105_1177;
		 }
	       else
		 {
		    long obj_class_num_177_1182;
		    obj_class_num_177_1182 = TYPE(obj_1176);
		    {
		       obj_t arg1177_1183;
		       arg1177_1183 = PROCEDURE_REF(lvtype_node__env_81_ast_lvtype, ((long) 1));
		       {
			  long arg1178_1187;
			  {
			     long arg1179_1188;
			     arg1179_1188 = OBJECT_TYPE;
			     arg1178_1187 = (obj_class_num_177_1182 - arg1179_1188);
			  }
			  arg1593_1056 = VECTOR_REF(arg1177_1183, arg1178_1187);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1193;
	    object_1193 = (object_t) (node_1);
	    {
	       long arg1180_1194;
	       {
		  long arg1181_1195;
		  long arg1182_1196;
		  arg1181_1195 = TYPE(object_1193);
		  arg1182_1196 = OBJECT_TYPE;
		  arg1180_1194 = (arg1181_1195 - arg1182_1196);
	       }
	       {
		  obj_t vector_1200;
		  vector_1200 = _classes__134___object;
		  arg1594_1057 = VECTOR_REF(vector_1200, arg1180_1194);
	       }
	    }
	 }
	 method1585_1058 = arg1593_1056;
	 class1590_1059 = arg1594_1057;
	 {
	    if (INTEGERP(method1585_1058))
	      {
		 switch ((long) CINT(method1585_1058))
		   {
		   case ((long) 0):
		      return BUNSPEC;
		      break;
		   case ((long) 1):
		      return BUNSPEC;
		      break;
		   case ((long) 2):
		      return BUNSPEC;
		      break;
		   case ((long) 3):
		      {
			 obj_t arg1602_1071;
			 {
			    obj_t aux_1351;
			    {
			       closure_t aux_1352;
			       aux_1352 = (closure_t) (node_1);
			       aux_1351 = (obj_t) (aux_1352);
			    }
			    arg1602_1071 = shape_tools_shape(aux_1351);
			 }
			 return internal_error_43_tools_error(string1661_ast_lvtype, string1662_ast_lvtype, arg1602_1071);
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1072;
			 node_1072 = (sequence_t) (node_1);
			 {
			    bool_t aux_1358;
			    aux_1358 = lvtype_node___164_ast_lvtype((((sequence_t) CREF(node_1072))->nodes));
			    return BBOOL(aux_1358);
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_t node_1075;
			 node_1075 = (app_t) (node_1);
			 {
			    bool_t aux_1363;
			    aux_1363 = lvtype_node___164_ast_lvtype((((app_t) CREF(node_1075))->args));
			    return BBOOL(aux_1363);
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_1078;
			 node_1078 = (app_ly_162_t) (node_1);
			 lvtype_node__58_ast_lvtype((((app_ly_162_t) CREF(node_1078))->fun));
			 {
			    node_t node_1370;
			    node_1370 = (((app_ly_162_t) CREF(node_1078))->arg);
			    node_1 = node_1370;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_1082;
			 node_1082 = (funcall_t) (node_1);
			 lvtype_node__58_ast_lvtype((((funcall_t) CREF(node_1082))->fun));
			 {
			    bool_t aux_1375;
			    aux_1375 = lvtype_node___164_ast_lvtype((((funcall_t) CREF(node_1082))->args));
			    return BBOOL(aux_1375);
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_1086;
			 node_1086 = (pragma_t) (node_1);
			 {
			    bool_t aux_1380;
			    aux_1380 = lvtype_node___164_ast_lvtype((((pragma_t) CREF(node_1086))->args));
			    return BBOOL(aux_1380);
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_1089;
			 node_1089 = (cast_t) (node_1);
			 {
			    node_t node_1385;
			    node_1385 = (((cast_t) CREF(node_1089))->arg);
			    node_1 = node_1385;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_1092;
			 node_1092 = (setq_t) (node_1);
			 lvtype_node__58_ast_lvtype((((setq_t) CREF(node_1092))->value));
			 {
			    node_t node_1390;
			    {
			       var_t aux_1391;
			       aux_1391 = (((setq_t) CREF(node_1092))->var);
			       node_1390 = (node_t) (aux_1391);
			    }
			    node_1 = node_1390;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_1096;
			 node_1096 = (conditional_t) (node_1);
			 lvtype_node__58_ast_lvtype((((conditional_t) CREF(node_1096))->test));
			 lvtype_node__58_ast_lvtype((((conditional_t) CREF(node_1096))->true));
			 {
			    node_t node_1399;
			    node_1399 = (((conditional_t) CREF(node_1096))->false);
			    node_1 = node_1399;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_1101;
			 node_1101 = (fail_t) (node_1);
			 lvtype_node__58_ast_lvtype((((fail_t) CREF(node_1101))->proc));
			 lvtype_node__58_ast_lvtype((((fail_t) CREF(node_1101))->msg));
			 {
			    node_t node_1406;
			    node_1406 = (((fail_t) CREF(node_1101))->obj);
			    node_1 = node_1406;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_1106;
			 node_1106 = (select_t) (node_1);
			 lvtype_node__58_ast_lvtype((((select_t) CREF(node_1106))->test));
			 {
			    obj_t l1445_1109;
			    {
			       bool_t aux_1411;
			       l1445_1109 = (((select_t) CREF(node_1106))->clauses);
			     lname1446_1110:
			       if (PAIRP(l1445_1109))
				 {
				    {
				       node_t aux_1414;
				       {
					  obj_t aux_1415;
					  {
					     obj_t aux_1416;
					     aux_1416 = CAR(l1445_1109);
					     aux_1415 = CDR(aux_1416);
					  }
					  aux_1414 = (node_t) (aux_1415);
				       }
				       lvtype_node__58_ast_lvtype(aux_1414);
				    }
				    {
				       obj_t l1445_1421;
				       l1445_1421 = CDR(l1445_1109);
				       l1445_1109 = l1445_1421;
				       goto lname1446_1110;
				    }
				 }
			       else
				 {
				    aux_1411 = ((bool_t) 1);
				 }
			       return BBOOL(aux_1411);
			    }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_1116;
			 node_1116 = (let_fun_218_t) (node_1);
			 {
			    obj_t l1448_1118;
			    l1448_1118 = (((let_fun_218_t) CREF(node_1116))->locals);
			  lname1449_1119:
			    if (PAIRP(l1448_1118))
			      {
				 {
				    node_t aux_1428;
				    {
				       obj_t aux_1429;
				       {
					  sfun_t obj_1228;
					  {
					     value_t aux_1430;
					     {
						local_t obj_1227;
						{
						   obj_t aux_1431;
						   aux_1431 = CAR(l1448_1118);
						   obj_1227 = (local_t) (aux_1431);
						}
						aux_1430 = (((local_t) CREF(obj_1227))->value);
					     }
					     obj_1228 = (sfun_t) (aux_1430);
					  }
					  aux_1429 = (((sfun_t) CREF(obj_1228))->body);
				       }
				       aux_1428 = (node_t) (aux_1429);
				    }
				    lvtype_node__58_ast_lvtype(aux_1428);
				 }
				 {
				    obj_t l1448_1439;
				    l1448_1439 = CDR(l1448_1118);
				    l1448_1118 = l1448_1439;
				    goto lname1449_1119;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1442;
			    node_1442 = (((let_fun_218_t) CREF(node_1116))->body);
			    node_1 = node_1442;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_1127;
			 node_1127 = (let_var_6_t) (node_1);
			 {
			    obj_t l1451_1129;
			    l1451_1129 = (((let_var_6_t) CREF(node_1127))->bindings);
			  lname1452_1130:
			    if (PAIRP(l1451_1129))
			      {
				 {
				    obj_t binding_1133;
				    binding_1133 = CAR(l1451_1129);
				    {
				       obj_t var_1134;
				       obj_t val_1135;
				       var_1134 = CAR(binding_1133);
				       val_1135 = CDR(binding_1133);
				       lvtype_node__58_ast_lvtype((node_t) (val_1135));
				       {
					  type_t arg1640_1136;
					  arg1640_1136 = typeof_coerce_typeof((node_t) (val_1135));
					  set_variable_type__9_ast_lvtype((variable_t) (var_1134), arg1640_1136);
				       }
				    }
				 }
				 {
				    obj_t l1451_1456;
				    l1451_1456 = CDR(l1451_1129);
				    l1451_1129 = l1451_1456;
				    goto lname1452_1130;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1459;
			    node_1459 = (((let_var_6_t) CREF(node_1127))->body);
			    node_1 = node_1459;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_1139;
			 node_1139 = (set_ex_it_116_t) (node_1);
			 lvtype_node__58_ast_lvtype((((set_ex_it_116_t) CREF(node_1139))->body));
			 {
			    node_t node_1464;
			    {
			       var_t aux_1465;
			       aux_1465 = (((set_ex_it_116_t) CREF(node_1139))->var);
			       node_1464 = (node_t) (aux_1465);
			    }
			    node_1 = node_1464;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_1143;
			 node_1143 = (jump_ex_it_184_t) (node_1);
			 lvtype_node__58_ast_lvtype((((jump_ex_it_184_t) CREF(node_1143))->exit));
			 {
			    node_t node_1471;
			    node_1471 = (((jump_ex_it_184_t) CREF(node_1143))->value);
			    node_1 = node_1471;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_1147;
			 node_1147 = (make_box_202_t) (node_1);
			 {
			    node_t node_1474;
			    node_1474 = (((make_box_202_t) CREF(node_1147))->value);
			    node_1 = node_1474;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 19):
		      {
			 box_set__221_t node_1150;
			 node_1150 = (box_set__221_t) (node_1);
			 {
			    node_t aux_1477;
			    {
			       var_t aux_1478;
			       aux_1478 = (((box_set__221_t) CREF(node_1150))->var);
			       aux_1477 = (node_t) (aux_1478);
			    }
			    lvtype_node__58_ast_lvtype(aux_1477);
			 }
			 {
			    node_t node_1482;
			    node_1482 = (((box_set__221_t) CREF(node_1150))->value);
			    node_1 = node_1482;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   case ((long) 20):
		      {
			 box_ref_242_t node_1154;
			 node_1154 = (box_ref_242_t) (node_1);
			 {
			    node_t node_1485;
			    {
			       var_t aux_1486;
			       aux_1486 = (((box_ref_242_t) CREF(node_1154))->var);
			       node_1485 = (node_t) (aux_1486);
			    }
			    node_1 = node_1485;
			    goto lvtype_node__58_ast_lvtype;
			 }
		      }
		      break;
		   default:
		    case_else1591_1062:
		      if (PROCEDUREP(method1585_1058))
			{
			   return PROCEDURE_ENTRY(method1585_1058) (method1585_1058, (obj_t) (node_1), BEOA);
			}
		      else
			{
			   obj_t fun1582_1052;
			   fun1582_1052 = PROCEDURE_REF(lvtype_node__env_81_ast_lvtype, ((long) 0));
			   return PROCEDURE_ENTRY(fun1582_1052) (fun1582_1052, (obj_t) (node_1), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1591_1062;
	      }
	 }
      }
   }
}


/* _lvtype-node! */ obj_t 
_lvtype_node__190_ast_lvtype(obj_t env_1253, obj_t node_1254)
{
   return lvtype_node__58_ast_lvtype((node_t) (node_1254));
}


/* lvtype-node!-default1460 */ obj_t 
lvtype_node__default1460_116_ast_lvtype(node_t node_2)
{
   FAILURE(CNST_TABLE_REF(((long) 0)), string1663_ast_lvtype, (obj_t) (node_2));
}


/* _lvtype-node!-default1460 */ obj_t 
_lvtype_node__default1460_93_ast_lvtype(obj_t env_1255, obj_t node_1256)
{
   return lvtype_node__default1460_116_ast_lvtype((node_t) (node_1256));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_lvtype()
{
   module_initialization_70_type_type(((long) 0), "AST_LVTYPE");
   module_initialization_70_type_cache(((long) 0), "AST_LVTYPE");
   module_initialization_70_tools_shape(((long) 0), "AST_LVTYPE");
   module_initialization_70_tools_error(((long) 0), "AST_LVTYPE");
   module_initialization_70_coerce_typeof(((long) 0), "AST_LVTYPE");
   module_initialization_70_ast_var(((long) 0), "AST_LVTYPE");
   return module_initialization_70_ast_node(((long) 0), "AST_LVTYPE");
}
