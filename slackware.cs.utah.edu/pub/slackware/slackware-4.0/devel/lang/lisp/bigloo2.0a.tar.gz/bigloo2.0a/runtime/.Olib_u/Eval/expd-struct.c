/*===========================================================================*/
/*   (Eval/expd-struct.scm)                                                  */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t expand_eval_define_struct_250___expander_struct(obj_t, obj_t);
static obj_t _expand_eval_define_struct_219___expander_struct(obj_t, obj_t, obj_t);
extern obj_t match_define_structure__81___match_normalize(obj_t);
extern obj_t module_initialization_70___expander_struct(long, char *);
extern obj_t module_initialization_70___progn(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___match_normalize(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern long list_length(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t imported_modules_init_94___expander_struct();
static obj_t symbol1843___expander_struct = BUNSPEC;
static obj_t symbol1839___expander_struct = BUNSPEC;
static obj_t symbol1838___expander_struct = BUNSPEC;
static obj_t symbol1836___expander_struct = BUNSPEC;
static obj_t symbol1835___expander_struct = BUNSPEC;
static obj_t symbol1834___expander_struct = BUNSPEC;
static obj_t symbol1833___expander_struct = BUNSPEC;
static obj_t symbol1832___expander_struct = BUNSPEC;
static obj_t symbol1831___expander_struct = BUNSPEC;
static obj_t symbol1829___expander_struct = BUNSPEC;
static obj_t symbol1830___expander_struct = BUNSPEC;
static obj_t symbol1828___expander_struct = BUNSPEC;
static obj_t symbol1827___expander_struct = BUNSPEC;
static obj_t symbol1826___expander_struct = BUNSPEC;
static obj_t symbol1823___expander_struct = BUNSPEC;
static obj_t symbol1822___expander_struct = BUNSPEC;
static obj_t symbol1819___expander_struct = BUNSPEC;
static obj_t symbol1820___expander_struct = BUNSPEC;
static obj_t symbol1818___expander_struct = BUNSPEC;
static obj_t symbol1817___expander_struct = BUNSPEC;
static obj_t symbol1816___expander_struct = BUNSPEC;
static obj_t symbol1815___expander_struct = BUNSPEC;
static obj_t symbol1814___expander_struct = BUNSPEC;
static obj_t symbol1813___expander_struct = BUNSPEC;
static obj_t symbol1812___expander_struct = BUNSPEC;
static obj_t symbol1811___expander_struct = BUNSPEC;
static obj_t symbol1810___expander_struct = BUNSPEC;
static obj_t require_initialization_114___expander_struct = BUNSPEC;
static obj_t list1842___expander_struct = BUNSPEC;
static obj_t list1841___expander_struct = BUNSPEC;
static obj_t list1809___expander_struct = BUNSPEC;
static obj_t cnst_init_137___expander_struct();
static obj_t *__cnst;

DEFINE_STRING( string1840___expander_struct, string1840___expander_struct1845, "struct-set!:not an instance of", 30 );
DEFINE_STRING( string1837___expander_struct, string1837___expander_struct1846, "struct-ref:not an instance of", 29 );
DEFINE_STRING( string1825___expander_struct, string1825___expander_struct1847, "Type `extended pair' expected for expression", 44 );
DEFINE_STRING( string1824___expander_struct, string1824___expander_struct1848, "cer", 3 );
DEFINE_STRING( string1821___expander_struct, string1821___expander_struct1849, "Too many argument provided", 26 );
DEFINE_STRING( string1808___expander_struct, string1808___expander_struct1850, "Illegal `define-struct' form", 28 );
DEFINE_STRING( string1807___expander_struct, string1807___expander_struct1851, "define-struct", 13 );
DEFINE_EXPORT_PROCEDURE( expand_eval_define_struct_env_150___expander_struct, _expand_eval_define_struct_219___expander_struct1852, _expand_eval_define_struct_219___expander_struct, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___expander_struct(long checksum_1260, char * from_1261)
{
if(CBOOL(require_initialization_114___expander_struct)){
require_initialization_114___expander_struct = BBOOL(((bool_t)0));
cnst_init_137___expander_struct();
imported_modules_init_94___expander_struct();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___expander_struct()
{
symbol1810___expander_struct = string_to_symbol("QUOTE");
{
obj_t aux_1268;
aux_1268 = MAKE_PAIR(BNIL, BNIL);
list1809___expander_struct = MAKE_PAIR(symbol1810___expander_struct, aux_1268);
}
symbol1811___expander_struct = string_to_symbol("BEGIN");
symbol1812___expander_struct = string_to_symbol("DEFINE-INLINE");
symbol1813___expander_struct = string_to_symbol("MAKE-");
symbol1814___expander_struct = string_to_symbol("INIT");
symbol1815___expander_struct = string_to_symbol("IF");
symbol1816___expander_struct = string_to_symbol("PAIR?");
symbol1817___expander_struct = string_to_symbol("NOT");
symbol1818___expander_struct = string_to_symbol("NULL?");
symbol1819___expander_struct = string_to_symbol("CDR");
symbol1820___expander_struct = string_to_symbol("ERROR");
symbol1822___expander_struct = string_to_symbol("MAKE-STRUCT");
symbol1823___expander_struct = string_to_symbol("CAR");
symbol1826___expander_struct = string_to_symbol("LET");
symbol1827___expander_struct = string_to_symbol("NEW");
symbol1828___expander_struct = string_to_symbol("-");
symbol1829___expander_struct = string_to_symbol("-SET!");
symbol1830___expander_struct = string_to_symbol("?");
symbol1831___expander_struct = string_to_symbol("O");
symbol1832___expander_struct = string_to_symbol("STRUCT?");
symbol1833___expander_struct = string_to_symbol("EQ?");
symbol1834___expander_struct = string_to_symbol("STRUCT-KEY");
symbol1835___expander_struct = string_to_symbol("S");
symbol1836___expander_struct = string_to_symbol("STRUCT-REF");
symbol1838___expander_struct = string_to_symbol("V");
symbol1839___expander_struct = string_to_symbol("STRUCT-SET!");
symbol1843___expander_struct = string_to_symbol("UNSPECIFIED");
list1842___expander_struct = MAKE_PAIR(symbol1843___expander_struct, BNIL);
return (list1841___expander_struct = MAKE_PAIR(list1842___expander_struct, BNIL),
BUNSPEC);
}


/* expand-eval-define-struct */obj_t expand_eval_define_struct_250___expander_struct(obj_t x_1, obj_t e_2)
{
{
obj_t name_320;
obj_t slots_321;
if(PAIRP(x_1)){
obj_t cdr_109_69_326;
cdr_109_69_326 = CDR(x_1);
if(PAIRP(cdr_109_69_326)){
name_320 = CAR(cdr_109_69_326);
slots_321 = CDR(cdr_109_69_326);
match_define_structure__81___match_normalize(x_1);
{
long len_330;
len_330 = list_length(slots_321);
{
obj_t slots_name_121_331;
if(NULLP(slots_321)){
slots_name_121_331 = BNIL;
}
 else {
obj_t head1004_857;
head1004_857 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1002_858;
obj_t tail1005_859;
l1002_858 = slots_321;
tail1005_859 = head1004_857;
lname1003_860:
if(NULLP(l1002_858)){
slots_name_121_331 = CDR(head1004_857);
}
 else {
obj_t newtail1006_862;
{
obj_t arg1625_864;
{
obj_t s_866;
s_866 = CAR(l1002_858);
if(PAIRP(s_866)){
obj_t cdr_125_100_874;
cdr_125_100_874 = CDR(s_866);
if(PAIRP(cdr_125_100_874)){
bool_t test_1318;
{
obj_t aux_1319;
aux_1319 = CDR(cdr_125_100_874);
test_1318 = (aux_1319==BNIL);
}
if(test_1318){
arg1625_864 = CAR(s_866);
}
 else {
if(SYMBOLP(s_866)){
arg1625_864 = s_866;
}
 else {
FAILURE(string1807___expander_struct,string1808___expander_struct,x_1);}
}
}
 else {
if(SYMBOLP(s_866)){
arg1625_864 = s_866;
}
 else {
FAILURE(string1807___expander_struct,string1808___expander_struct,x_1);}
}
}
 else {
if(SYMBOLP(s_866)){
arg1625_864 = s_866;
}
 else {
FAILURE(string1807___expander_struct,string1808___expander_struct,x_1);}
}
}
newtail1006_862 = MAKE_PAIR(arg1625_864, BNIL);
}
SET_CDR(tail1005_859, newtail1006_862);
{
obj_t tail1005_1336;
obj_t l1002_1334;
l1002_1334 = CDR(l1002_858);
tail1005_1336 = newtail1006_862;
tail1005_859 = tail1005_1336;
l1002_858 = l1002_1334;
goto lname1003_860;
}
}
}
}
{
bool_t slots_val__167_332;
slots_val__167_332 = ((bool_t)0);
{
obj_t slots_val_6_333;
if(NULLP(slots_321)){
slots_val_6_333 = BNIL;
}
 else {
obj_t head1009_828;
head1009_828 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1007_829;
obj_t tail1010_830;
l1007_829 = slots_321;
tail1010_830 = head1009_828;
lname1008_831:
if(NULLP(l1007_829)){
slots_val_6_333 = CDR(head1009_828);
}
 else {
obj_t newtail1011_833;
{
obj_t arg1606_835;
{
obj_t s_837;
s_837 = CAR(l1007_829);
if(PAIRP(s_837)){
obj_t cdr_138_77_844;
cdr_138_77_844 = CDR(s_837);
if(PAIRP(cdr_138_77_844)){
bool_t test_1349;
{
obj_t aux_1350;
aux_1350 = CDR(cdr_138_77_844);
test_1349 = (aux_1350==BNIL);
}
if(test_1349){
slots_val__167_332 = ((bool_t)1);
arg1606_835 = CAR(cdr_138_77_844);
}
 else {
if(SYMBOLP(s_837)){
arg1606_835 = list1809___expander_struct;
}
 else {
FAILURE(string1807___expander_struct,string1808___expander_struct,x_1);}
}
}
 else {
if(SYMBOLP(s_837)){
arg1606_835 = list1809___expander_struct;
}
 else {
FAILURE(string1807___expander_struct,string1808___expander_struct,x_1);}
}
}
 else {
if(SYMBOLP(s_837)){
arg1606_835 = list1809___expander_struct;
}
 else {
FAILURE(string1807___expander_struct,string1808___expander_struct,x_1);}
}
}
newtail1011_833 = MAKE_PAIR(arg1606_835, BNIL);
}
SET_CDR(tail1010_830, newtail1011_833);
{
obj_t tail1010_1367;
obj_t l1007_1365;
l1007_1365 = CDR(l1007_829);
tail1010_1367 = newtail1011_833;
tail1010_830 = tail1010_1367;
l1007_829 = l1007_1365;
goto lname1008_831;
}
}
}
}
{
{
obj_t arg1020_334;
obj_t arg1021_335;
arg1020_334 = symbol1811___expander_struct;
{
obj_t arg1022_336;
obj_t arg1023_337;
{
obj_t arg1025_338;
{
obj_t arg1026_339;
{
obj_t arg1027_340;
obj_t arg1028_341;
obj_t arg1029_342;
arg1027_340 = symbol1812___expander_struct;
{
obj_t arg1035_348;
obj_t arg1037_349;
{
obj_t arg1040_352;
arg1040_352 = symbol1813___expander_struct;
{
obj_t list1041_353;
{
obj_t arg1042_354;
arg1042_354 = MAKE_PAIR(name_320, BNIL);
list1041_353 = MAKE_PAIR(arg1040_352, arg1042_354);
}
arg1035_348 = symbol_append_197___r4_symbols_6_4(list1041_353);
}
}
arg1037_349 = symbol1814___expander_struct;
{
obj_t list1038_350;
list1038_350 = MAKE_PAIR(arg1037_349, BNIL);
arg1028_341 = cons__138___r4_pairs_and_lists_6_3(arg1035_348, list1038_350);
}
}
if(slots_val__167_332){
obj_t arg1044_356;
obj_t arg1045_357;
obj_t arg1046_358;
obj_t arg1047_359;
arg1044_356 = symbol1815___expander_struct;
{
obj_t arg1055_366;
obj_t arg1056_367;
arg1055_366 = symbol1816___expander_struct;
arg1056_367 = symbol1814___expander_struct;
{
obj_t list1058_369;
{
obj_t arg1059_370;
arg1059_370 = MAKE_PAIR(BNIL, BNIL);
list1058_369 = MAKE_PAIR(arg1056_367, arg1059_370);
}
arg1045_357 = cons__138___r4_pairs_and_lists_6_3(arg1055_366, list1058_369);
}
}
{
obj_t arg1061_372;
obj_t arg1062_373;
obj_t arg1063_374;
obj_t arg1065_375;
arg1061_372 = symbol1815___expander_struct;
{
obj_t arg1073_382;
obj_t arg1076_383;
arg1073_382 = symbol1817___expander_struct;
{
obj_t arg1081_388;
obj_t arg1082_389;
arg1081_388 = symbol1818___expander_struct;
{
obj_t arg1087_394;
obj_t arg1088_395;
arg1087_394 = symbol1819___expander_struct;
arg1088_395 = symbol1814___expander_struct;
{
obj_t list1090_397;
{
obj_t arg1091_398;
arg1091_398 = MAKE_PAIR(BNIL, BNIL);
list1090_397 = MAKE_PAIR(arg1088_395, arg1091_398);
}
arg1082_389 = cons__138___r4_pairs_and_lists_6_3(arg1087_394, list1090_397);
}
}
{
obj_t list1084_391;
{
obj_t arg1085_392;
arg1085_392 = MAKE_PAIR(BNIL, BNIL);
list1084_391 = MAKE_PAIR(arg1082_389, arg1085_392);
}
arg1076_383 = cons__138___r4_pairs_and_lists_6_3(arg1081_388, list1084_391);
}
}
{
obj_t list1078_385;
{
obj_t arg1079_386;
arg1079_386 = MAKE_PAIR(BNIL, BNIL);
list1078_385 = MAKE_PAIR(arg1076_383, arg1079_386);
}
arg1062_373 = cons__138___r4_pairs_and_lists_6_3(arg1073_382, list1078_385);
}
}
{
obj_t arg1093_400;
obj_t arg1094_401;
obj_t arg1096_403;
arg1093_400 = symbol1820___expander_struct;
{
obj_t arg1103_410;
obj_t arg1104_411;
arg1103_410 = symbol1810___expander_struct;
{
obj_t arg1109_416;
arg1109_416 = symbol1813___expander_struct;
{
obj_t list1110_417;
{
obj_t arg1111_418;
arg1111_418 = MAKE_PAIR(name_320, BNIL);
list1110_417 = MAKE_PAIR(arg1109_416, arg1111_418);
}
arg1104_411 = symbol_append_197___r4_symbols_6_4(list1110_417);
}
}
{
obj_t list1106_413;
{
obj_t arg1107_414;
arg1107_414 = MAKE_PAIR(BNIL, BNIL);
list1106_413 = MAKE_PAIR(arg1104_411, arg1107_414);
}
arg1094_401 = cons__138___r4_pairs_and_lists_6_3(arg1103_410, list1106_413);
}
}
arg1096_403 = symbol1814___expander_struct;
{
obj_t list1098_405;
{
obj_t arg1099_406;
{
obj_t arg1100_407;
{
obj_t arg1101_408;
arg1101_408 = MAKE_PAIR(BNIL, BNIL);
arg1100_407 = MAKE_PAIR(arg1096_403, arg1101_408);
}
arg1099_406 = MAKE_PAIR(string1821___expander_struct, arg1100_407);
}
list1098_405 = MAKE_PAIR(arg1094_401, arg1099_406);
}
arg1063_374 = cons__138___r4_pairs_and_lists_6_3(arg1093_400, list1098_405);
}
}
{
obj_t arg1113_420;
obj_t arg1114_421;
obj_t arg1115_422;
arg1113_420 = symbol1822___expander_struct;
{
obj_t arg1122_429;
arg1122_429 = symbol1810___expander_struct;
{
obj_t list1124_431;
{
obj_t arg1125_432;
arg1125_432 = MAKE_PAIR(BNIL, BNIL);
list1124_431 = MAKE_PAIR(name_320, arg1125_432);
}
arg1114_421 = cons__138___r4_pairs_and_lists_6_3(arg1122_429, list1124_431);
}
}
{
obj_t arg1127_434;
obj_t arg1128_435;
arg1127_434 = symbol1823___expander_struct;
arg1128_435 = symbol1814___expander_struct;
{
obj_t list1130_437;
{
obj_t arg1131_438;
arg1131_438 = MAKE_PAIR(BNIL, BNIL);
list1130_437 = MAKE_PAIR(arg1128_435, arg1131_438);
}
arg1115_422 = cons__138___r4_pairs_and_lists_6_3(arg1127_434, list1130_437);
}
}
{
obj_t list1117_424;
{
obj_t arg1118_425;
{
obj_t arg1119_426;
{
obj_t arg1120_427;
arg1120_427 = MAKE_PAIR(BNIL, BNIL);
arg1119_426 = MAKE_PAIR(arg1115_422, arg1120_427);
}
{
obj_t aux_1405;
aux_1405 = BINT(len_330);
arg1118_425 = MAKE_PAIR(aux_1405, arg1119_426);
}
}
list1117_424 = MAKE_PAIR(arg1114_421, arg1118_425);
}
arg1065_375 = cons__138___r4_pairs_and_lists_6_3(arg1113_420, list1117_424);
}
}
{
obj_t list1067_377;
{
obj_t arg1068_378;
{
obj_t arg1069_379;
{
obj_t arg1070_380;
arg1070_380 = MAKE_PAIR(BNIL, BNIL);
arg1069_379 = MAKE_PAIR(arg1065_375, arg1070_380);
}
arg1068_378 = MAKE_PAIR(arg1063_374, arg1069_379);
}
list1067_377 = MAKE_PAIR(arg1062_373, arg1068_378);
}
arg1046_358 = cons__138___r4_pairs_and_lists_6_3(arg1061_372, list1067_377);
}
}
{
obj_t arg1133_440;
{
obj_t arg1136_443;
arg1136_443 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1133_440 = append_2_18___r4_pairs_and_lists_6_3(slots_val_6_333, arg1136_443);
}
{
obj_t list1134_441;
list1134_441 = MAKE_PAIR(arg1133_440, BNIL);
arg1047_359 = cons__138___r4_pairs_and_lists_6_3(name_320, list1134_441);
}
}
{
obj_t list1049_361;
{
obj_t arg1050_362;
{
obj_t arg1051_363;
{
obj_t arg1053_364;
arg1053_364 = MAKE_PAIR(BNIL, BNIL);
arg1051_363 = MAKE_PAIR(arg1047_359, arg1053_364);
}
arg1050_362 = MAKE_PAIR(arg1046_358, arg1051_363);
}
list1049_361 = MAKE_PAIR(arg1045_357, arg1050_362);
}
arg1029_342 = cons__138___r4_pairs_and_lists_6_3(arg1044_356, list1049_361);
}
}
 else {
obj_t arg1139_446;
obj_t arg1140_447;
obj_t arg1141_448;
obj_t arg1142_449;
arg1139_446 = symbol1815___expander_struct;
{
obj_t arg1150_456;
obj_t arg1151_457;
arg1150_456 = symbol1816___expander_struct;
arg1151_457 = symbol1814___expander_struct;
{
obj_t list1153_459;
{
obj_t arg1154_460;
arg1154_460 = MAKE_PAIR(BNIL, BNIL);
list1153_459 = MAKE_PAIR(arg1151_457, arg1154_460);
}
arg1140_447 = cons__138___r4_pairs_and_lists_6_3(arg1150_456, list1153_459);
}
}
{
obj_t arg1156_462;
obj_t arg1157_463;
obj_t arg1158_464;
obj_t arg1160_465;
arg1156_462 = symbol1815___expander_struct;
{
obj_t arg1167_472;
obj_t arg1168_473;
arg1167_472 = symbol1817___expander_struct;
{
obj_t arg1173_478;
obj_t arg1174_479;
arg1173_478 = symbol1818___expander_struct;
{
obj_t arg1179_484;
obj_t arg1180_485;
arg1179_484 = symbol1819___expander_struct;
arg1180_485 = symbol1814___expander_struct;
{
obj_t list1182_487;
{
obj_t arg1183_488;
arg1183_488 = MAKE_PAIR(BNIL, BNIL);
list1182_487 = MAKE_PAIR(arg1180_485, arg1183_488);
}
arg1174_479 = cons__138___r4_pairs_and_lists_6_3(arg1179_484, list1182_487);
}
}
{
obj_t list1176_481;
{
obj_t arg1177_482;
arg1177_482 = MAKE_PAIR(BNIL, BNIL);
list1176_481 = MAKE_PAIR(arg1174_479, arg1177_482);
}
arg1168_473 = cons__138___r4_pairs_and_lists_6_3(arg1173_478, list1176_481);
}
}
{
obj_t list1170_475;
{
obj_t arg1171_476;
arg1171_476 = MAKE_PAIR(BNIL, BNIL);
list1170_475 = MAKE_PAIR(arg1168_473, arg1171_476);
}
arg1157_463 = cons__138___r4_pairs_and_lists_6_3(arg1167_472, list1170_475);
}
}
{
obj_t arg1185_490;
obj_t arg1186_491;
obj_t arg1188_493;
arg1185_490 = symbol1820___expander_struct;
{
obj_t arg1195_500;
obj_t arg1196_501;
arg1195_500 = symbol1810___expander_struct;
{
obj_t arg1201_506;
arg1201_506 = symbol1813___expander_struct;
{
obj_t list1202_507;
{
obj_t arg1203_508;
arg1203_508 = MAKE_PAIR(name_320, BNIL);
list1202_507 = MAKE_PAIR(arg1201_506, arg1203_508);
}
arg1196_501 = symbol_append_197___r4_symbols_6_4(list1202_507);
}
}
{
obj_t list1198_503;
{
obj_t arg1199_504;
arg1199_504 = MAKE_PAIR(BNIL, BNIL);
list1198_503 = MAKE_PAIR(arg1196_501, arg1199_504);
}
arg1186_491 = cons__138___r4_pairs_and_lists_6_3(arg1195_500, list1198_503);
}
}
arg1188_493 = symbol1814___expander_struct;
{
obj_t list1190_495;
{
obj_t arg1191_496;
{
obj_t arg1192_497;
{
obj_t arg1193_498;
arg1193_498 = MAKE_PAIR(BNIL, BNIL);
arg1192_497 = MAKE_PAIR(arg1188_493, arg1193_498);
}
arg1191_496 = MAKE_PAIR(string1821___expander_struct, arg1192_497);
}
list1190_495 = MAKE_PAIR(arg1186_491, arg1191_496);
}
arg1158_464 = cons__138___r4_pairs_and_lists_6_3(arg1185_490, list1190_495);
}
}
{
obj_t arg1205_510;
obj_t arg1206_511;
obj_t arg1207_512;
arg1205_510 = symbol1822___expander_struct;
{
obj_t arg1219_519;
arg1219_519 = symbol1810___expander_struct;
{
obj_t list1221_521;
{
obj_t arg1222_522;
arg1222_522 = MAKE_PAIR(BNIL, BNIL);
list1221_521 = MAKE_PAIR(name_320, arg1222_522);
}
arg1206_511 = cons__138___r4_pairs_and_lists_6_3(arg1219_519, list1221_521);
}
}
{
obj_t arg1225_524;
obj_t arg1226_525;
arg1225_524 = symbol1823___expander_struct;
arg1226_525 = symbol1814___expander_struct;
{
obj_t list1229_527;
{
obj_t arg1231_528;
arg1231_528 = MAKE_PAIR(BNIL, BNIL);
list1229_527 = MAKE_PAIR(arg1226_525, arg1231_528);
}
arg1207_512 = cons__138___r4_pairs_and_lists_6_3(arg1225_524, list1229_527);
}
}
{
obj_t list1210_514;
{
obj_t arg1211_515;
{
obj_t arg1213_516;
{
obj_t arg1214_517;
arg1214_517 = MAKE_PAIR(BNIL, BNIL);
arg1213_516 = MAKE_PAIR(arg1207_512, arg1214_517);
}
{
obj_t aux_1455;
aux_1455 = BINT(len_330);
arg1211_515 = MAKE_PAIR(aux_1455, arg1213_516);
}
}
list1210_514 = MAKE_PAIR(arg1206_511, arg1211_515);
}
arg1160_465 = cons__138___r4_pairs_and_lists_6_3(arg1205_510, list1210_514);
}
}
{
obj_t list1162_467;
{
obj_t arg1163_468;
{
obj_t arg1164_469;
{
obj_t arg1165_470;
arg1165_470 = MAKE_PAIR(BNIL, BNIL);
arg1164_469 = MAKE_PAIR(arg1160_465, arg1165_470);
}
arg1163_468 = MAKE_PAIR(arg1158_464, arg1164_469);
}
list1162_467 = MAKE_PAIR(arg1157_463, arg1163_468);
}
arg1141_448 = cons__138___r4_pairs_and_lists_6_3(arg1156_462, list1162_467);
}
}
{
obj_t arg1233_530;
obj_t arg1234_531;
obj_t arg1235_532;
arg1233_530 = symbol1822___expander_struct;
{
obj_t arg1244_539;
arg1244_539 = symbol1810___expander_struct;
{
obj_t list1246_541;
{
obj_t arg1247_542;
arg1247_542 = MAKE_PAIR(BNIL, BNIL);
list1246_541 = MAKE_PAIR(name_320, arg1247_542);
}
arg1234_531 = cons__138___r4_pairs_and_lists_6_3(arg1244_539, list1246_541);
}
}
{
obj_t arg1250_544;
arg1250_544 = symbol1810___expander_struct;
{
obj_t list1253_547;
{
obj_t arg1254_548;
arg1254_548 = MAKE_PAIR(BNIL, BNIL);
list1253_547 = MAKE_PAIR(BNIL, arg1254_548);
}
arg1235_532 = cons__138___r4_pairs_and_lists_6_3(arg1250_544, list1253_547);
}
}
{
obj_t list1237_534;
{
obj_t arg1238_535;
{
obj_t arg1240_536;
{
obj_t arg1241_537;
arg1241_537 = MAKE_PAIR(BNIL, BNIL);
arg1240_536 = MAKE_PAIR(arg1235_532, arg1241_537);
}
{
obj_t aux_1473;
aux_1473 = BINT(len_330);
arg1238_535 = MAKE_PAIR(aux_1473, arg1240_536);
}
}
list1237_534 = MAKE_PAIR(arg1234_531, arg1238_535);
}
arg1142_449 = cons__138___r4_pairs_and_lists_6_3(arg1233_530, list1237_534);
}
}
{
obj_t list1144_451;
{
obj_t arg1145_452;
{
obj_t arg1146_453;
{
obj_t arg1147_454;
arg1147_454 = MAKE_PAIR(BNIL, BNIL);
arg1146_453 = MAKE_PAIR(arg1142_449, arg1147_454);
}
arg1145_452 = MAKE_PAIR(arg1141_448, arg1146_453);
}
list1144_451 = MAKE_PAIR(arg1140_447, arg1145_452);
}
arg1029_342 = cons__138___r4_pairs_and_lists_6_3(arg1139_446, list1144_451);
}
}
{
obj_t list1031_344;
{
obj_t arg1032_345;
{
obj_t arg1033_346;
arg1033_346 = MAKE_PAIR(BNIL, BNIL);
arg1032_345 = MAKE_PAIR(arg1029_342, arg1033_346);
}
list1031_344 = MAKE_PAIR(arg1028_341, arg1032_345);
}
arg1026_339 = cons__138___r4_pairs_and_lists_6_3(arg1027_340, list1031_344);
}
}
{
bool_t test1646_1115;
test1646_1115 = EXTENDED_PAIRP(x_1);
if(test1646_1115){
obj_t arg1647_1116;
obj_t arg1648_1117;
obj_t arg1649_1118;
arg1647_1116 = CAR(arg1026_339);
arg1648_1117 = CDR(arg1026_339);
{
bool_t test1748_1123;
test1748_1123 = EXTENDED_PAIRP(x_1);
if(test1748_1123){
arg1649_1118 = CER(x_1);
}
 else {
FAILURE(string1824___expander_struct,string1825___expander_struct,x_1);}
}
arg1025_338 = MAKE_EXTENDED_PAIR(arg1647_1116, arg1648_1117, arg1649_1118);
}
 else {
arg1025_338 = arg1026_339;
}
}
}
arg1022_336 = PROCEDURE_ENTRY(e_2)(e_2, arg1025_338, e_2, BEOA);
}
{
obj_t arg1256_550;
obj_t arg1257_551;
{
obj_t arg1258_552;
{
obj_t arg1259_553;
{
obj_t arg1260_554;
obj_t arg1262_555;
obj_t arg1263_556;
arg1260_554 = symbol1812___expander_struct;
{
obj_t arg1270_562;
{
obj_t arg1273_565;
arg1273_565 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1270_562 = append_2_18___r4_pairs_and_lists_6_3(slots_name_121_331, arg1273_565);
}
{
obj_t list1271_563;
list1271_563 = MAKE_PAIR(arg1270_562, BNIL);
arg1262_555 = cons__138___r4_pairs_and_lists_6_3(name_320, list1271_563);
}
}
{
obj_t arg1277_568;
obj_t arg1278_569;
obj_t arg1281_570;
arg1277_568 = symbol1826___expander_struct;
{
obj_t arg1285_574;
{
obj_t arg1290_578;
obj_t arg1291_579;
arg1290_578 = symbol1827___expander_struct;
{
obj_t arg1296_584;
obj_t arg1297_585;
obj_t arg1298_586;
arg1296_584 = symbol1822___expander_struct;
{
obj_t arg1307_593;
arg1307_593 = symbol1810___expander_struct;
{
obj_t list1309_595;
{
obj_t arg1310_596;
arg1310_596 = MAKE_PAIR(BNIL, BNIL);
list1309_595 = MAKE_PAIR(name_320, arg1310_596);
}
arg1297_585 = cons__138___r4_pairs_and_lists_6_3(arg1307_593, list1309_595);
}
}
{
obj_t arg1313_598;
arg1313_598 = symbol1810___expander_struct;
{
obj_t list1317_601;
{
obj_t arg1319_602;
arg1319_602 = MAKE_PAIR(BNIL, BNIL);
list1317_601 = MAKE_PAIR(BNIL, arg1319_602);
}
arg1298_586 = cons__138___r4_pairs_and_lists_6_3(arg1313_598, list1317_601);
}
}
{
obj_t list1300_588;
{
obj_t arg1301_589;
{
obj_t arg1302_590;
{
obj_t arg1303_591;
arg1303_591 = MAKE_PAIR(BNIL, BNIL);
arg1302_590 = MAKE_PAIR(arg1298_586, arg1303_591);
}
{
obj_t aux_1510;
aux_1510 = BINT(len_330);
arg1301_589 = MAKE_PAIR(aux_1510, arg1302_590);
}
}
list1300_588 = MAKE_PAIR(arg1297_585, arg1301_589);
}
arg1291_579 = cons__138___r4_pairs_and_lists_6_3(arg1296_584, list1300_588);
}
}
{
obj_t list1293_581;
{
obj_t arg1294_582;
arg1294_582 = MAKE_PAIR(BNIL, BNIL);
list1293_581 = MAKE_PAIR(arg1291_579, arg1294_582);
}
arg1285_574 = cons__138___r4_pairs_and_lists_6_3(arg1290_578, list1293_581);
}
}
{
obj_t list1287_576;
list1287_576 = MAKE_PAIR(BNIL, BNIL);
arg1278_569 = cons__138___r4_pairs_and_lists_6_3(arg1285_574, list1287_576);
}
}
{
obj_t arg1322_604;
obj_t arg1323_605;
{
obj_t slots_606;
obj_t res_607;
slots_606 = slots_name_121_331;
res_607 = BNIL;
loop_608:
if(NULLP(slots_606)){
arg1322_604 = res_607;
}
 else {
obj_t arg1326_611;
obj_t arg1328_612;
arg1326_611 = CDR(slots_606);
{
obj_t arg1330_613;
{
obj_t arg1331_614;
obj_t arg1332_615;
obj_t arg1333_616;
{
obj_t arg1342_622;
obj_t arg1343_623;
arg1342_622 = symbol1828___expander_struct;
arg1343_623 = CAR(slots_606);
{
obj_t list1345_625;
{
obj_t arg1347_626;
{
obj_t arg1349_627;
{
obj_t arg1350_628;
arg1350_628 = MAKE_PAIR(symbol1829___expander_struct, BNIL);
arg1349_627 = MAKE_PAIR(arg1343_623, arg1350_628);
}
arg1347_626 = MAKE_PAIR(arg1342_622, arg1349_627);
}
list1345_625 = MAKE_PAIR(name_320, arg1347_626);
}
arg1331_614 = symbol_append_197___r4_symbols_6_4(list1345_625);
}
}
arg1332_615 = symbol1827___expander_struct;
arg1333_616 = CAR(slots_606);
{
obj_t list1335_618;
{
obj_t arg1337_619;
{
obj_t arg1339_620;
arg1339_620 = MAKE_PAIR(BNIL, BNIL);
arg1337_619 = MAKE_PAIR(arg1333_616, arg1339_620);
}
list1335_618 = MAKE_PAIR(arg1332_615, arg1337_619);
}
arg1330_613 = cons__138___r4_pairs_and_lists_6_3(arg1331_614, list1335_618);
}
}
arg1328_612 = MAKE_PAIR(arg1330_613, res_607);
}
{
obj_t res_1536;
obj_t slots_1535;
slots_1535 = arg1326_611;
res_1536 = arg1328_612;
res_607 = res_1536;
slots_606 = slots_1535;
goto loop_608;
}
}
}
{
obj_t arg1352_630;
arg1352_630 = symbol1827___expander_struct;
{
obj_t list1354_632;
list1354_632 = MAKE_PAIR(BNIL, BNIL);
arg1323_605 = cons__138___r4_pairs_and_lists_6_3(arg1352_630, list1354_632);
}
}
arg1281_570 = append_2_18___r4_pairs_and_lists_6_3(arg1322_604, arg1323_605);
}
{
obj_t list1282_571;
{
obj_t arg1283_572;
arg1283_572 = MAKE_PAIR(arg1281_570, BNIL);
list1282_571 = MAKE_PAIR(arg1278_569, arg1283_572);
}
arg1263_556 = cons__138___r4_pairs_and_lists_6_3(arg1277_568, list1282_571);
}
}
{
obj_t list1266_558;
{
obj_t arg1267_559;
{
obj_t arg1268_560;
arg1268_560 = MAKE_PAIR(BNIL, BNIL);
arg1267_559 = MAKE_PAIR(arg1263_556, arg1268_560);
}
list1266_558 = MAKE_PAIR(arg1262_555, arg1267_559);
}
arg1259_553 = cons__138___r4_pairs_and_lists_6_3(arg1260_554, list1266_558);
}
}
{
bool_t test1646_1139;
test1646_1139 = EXTENDED_PAIRP(x_1);
if(test1646_1139){
obj_t arg1647_1140;
obj_t arg1648_1141;
obj_t arg1649_1142;
arg1647_1140 = CAR(arg1259_553);
arg1648_1141 = CDR(arg1259_553);
{
bool_t test1748_1147;
test1748_1147 = EXTENDED_PAIRP(x_1);
if(test1748_1147){
arg1649_1142 = CER(x_1);
}
 else {
FAILURE(string1824___expander_struct,string1825___expander_struct,x_1);}
}
arg1258_552 = MAKE_EXTENDED_PAIR(arg1647_1140, arg1648_1141, arg1649_1142);
}
 else {
arg1258_552 = arg1259_553;
}
}
}
arg1256_550 = PROCEDURE_ENTRY(e_2)(e_2, arg1258_552, e_2, BEOA);
}
{
obj_t arg1356_634;
obj_t arg1357_635;
{
obj_t arg1361_636;
{
obj_t arg1363_637;
{
obj_t arg1364_638;
obj_t arg1365_639;
obj_t arg1367_640;
arg1364_638 = symbol1812___expander_struct;
{
obj_t arg1375_646;
obj_t arg1378_647;
{
obj_t list1385_653;
{
obj_t arg1387_654;
arg1387_654 = MAKE_PAIR(symbol1830___expander_struct, BNIL);
list1385_653 = MAKE_PAIR(name_320, arg1387_654);
}
arg1375_646 = symbol_append_197___r4_symbols_6_4(list1385_653);
}
arg1378_647 = symbol1831___expander_struct;
{
obj_t list1380_649;
{
obj_t arg1381_650;
arg1381_650 = MAKE_PAIR(BNIL, BNIL);
list1380_649 = MAKE_PAIR(arg1378_647, arg1381_650);
}
arg1365_639 = cons__138___r4_pairs_and_lists_6_3(arg1375_646, list1380_649);
}
}
{
obj_t arg1389_656;
obj_t arg1390_657;
obj_t arg1391_658;
arg1389_656 = symbol1815___expander_struct;
{
obj_t arg1399_665;
obj_t arg1401_666;
arg1399_665 = symbol1832___expander_struct;
arg1401_666 = symbol1831___expander_struct;
{
obj_t list1403_668;
{
obj_t arg1405_669;
arg1405_669 = MAKE_PAIR(BNIL, BNIL);
list1403_668 = MAKE_PAIR(arg1401_666, arg1405_669);
}
arg1390_657 = cons__138___r4_pairs_and_lists_6_3(arg1399_665, list1403_668);
}
}
{
obj_t arg1408_671;
obj_t arg1410_672;
obj_t arg1411_673;
arg1408_671 = symbol1833___expander_struct;
{
obj_t arg1418_679;
obj_t arg1419_680;
arg1418_679 = symbol1834___expander_struct;
arg1419_680 = symbol1831___expander_struct;
{
obj_t list1422_682;
{
obj_t arg1423_683;
arg1423_683 = MAKE_PAIR(BNIL, BNIL);
list1422_682 = MAKE_PAIR(arg1419_680, arg1423_683);
}
arg1410_672 = cons__138___r4_pairs_and_lists_6_3(arg1418_679, list1422_682);
}
}
{
obj_t arg1427_685;
arg1427_685 = symbol1810___expander_struct;
{
obj_t list1429_687;
{
obj_t arg1431_688;
arg1431_688 = MAKE_PAIR(BNIL, BNIL);
list1429_687 = MAKE_PAIR(name_320, arg1431_688);
}
arg1411_673 = cons__138___r4_pairs_and_lists_6_3(arg1427_685, list1429_687);
}
}
{
obj_t list1414_675;
{
obj_t arg1415_676;
{
obj_t arg1416_677;
arg1416_677 = MAKE_PAIR(BNIL, BNIL);
arg1415_676 = MAKE_PAIR(arg1411_673, arg1416_677);
}
list1414_675 = MAKE_PAIR(arg1410_672, arg1415_676);
}
arg1391_658 = cons__138___r4_pairs_and_lists_6_3(arg1408_671, list1414_675);
}
}
{
obj_t list1393_660;
{
obj_t arg1395_661;
{
obj_t arg1396_662;
{
obj_t arg1397_663;
arg1397_663 = MAKE_PAIR(BNIL, BNIL);
arg1396_662 = MAKE_PAIR(BFALSE, arg1397_663);
}
arg1395_661 = MAKE_PAIR(arg1391_658, arg1396_662);
}
list1393_660 = MAKE_PAIR(arg1390_657, arg1395_661);
}
arg1367_640 = cons__138___r4_pairs_and_lists_6_3(arg1389_656, list1393_660);
}
}
{
obj_t list1369_642;
{
obj_t arg1370_643;
{
obj_t arg1372_644;
arg1372_644 = MAKE_PAIR(BNIL, BNIL);
arg1370_643 = MAKE_PAIR(arg1367_640, arg1372_644);
}
list1369_642 = MAKE_PAIR(arg1365_639, arg1370_643);
}
arg1363_637 = cons__138___r4_pairs_and_lists_6_3(arg1364_638, list1369_642);
}
}
{
bool_t test1646_1157;
test1646_1157 = EXTENDED_PAIRP(x_1);
if(test1646_1157){
obj_t arg1647_1158;
obj_t arg1648_1159;
obj_t arg1649_1160;
arg1647_1158 = CAR(arg1363_637);
arg1648_1159 = CDR(arg1363_637);
{
bool_t test1748_1165;
test1748_1165 = EXTENDED_PAIRP(x_1);
if(test1748_1165){
arg1649_1160 = CER(x_1);
}
 else {
FAILURE(string1824___expander_struct,string1825___expander_struct,x_1);}
}
arg1361_636 = MAKE_EXTENDED_PAIR(arg1647_1158, arg1648_1159, arg1649_1160);
}
 else {
arg1361_636 = arg1363_637;
}
}
}
arg1356_634 = PROCEDURE_ENTRY(e_2)(e_2, arg1361_636, e_2, BEOA);
}
{
long i_690;
obj_t slots_691;
obj_t res_692;
i_690 = ((long)0);
slots_691 = slots_name_121_331;
res_692 = list1841___expander_struct;
loop_693:
if((i_690==len_330)){
arg1357_635 = res_692;
}
 else {
obj_t pr_697;
pr_697 = CAR(slots_691);
{
long arg1438_698;
obj_t arg1440_699;
obj_t arg1441_700;
arg1438_698 = (i_690+((long)1));
arg1440_699 = CDR(slots_691);
{
obj_t arg1443_701;
obj_t arg1444_702;
{
obj_t arg1446_703;
{
obj_t arg1448_704;
{
obj_t arg1449_705;
obj_t arg1450_706;
obj_t arg1453_707;
arg1449_705 = symbol1812___expander_struct;
{
obj_t arg1461_713;
obj_t arg1463_714;
{
obj_t arg1468_719;
arg1468_719 = symbol1828___expander_struct;
{
obj_t list1469_720;
{
obj_t arg1470_721;
{
obj_t arg1471_722;
arg1471_722 = MAKE_PAIR(pr_697, BNIL);
arg1470_721 = MAKE_PAIR(arg1468_719, arg1471_722);
}
list1469_720 = MAKE_PAIR(name_320, arg1470_721);
}
arg1461_713 = symbol_append_197___r4_symbols_6_4(list1469_720);
}
}
arg1463_714 = symbol1835___expander_struct;
{
obj_t list1465_716;
{
obj_t arg1466_717;
arg1466_717 = MAKE_PAIR(BNIL, BNIL);
list1465_716 = MAKE_PAIR(arg1463_714, arg1466_717);
}
arg1450_706 = cons__138___r4_pairs_and_lists_6_3(arg1461_713, list1465_716);
}
}
{
obj_t arg1474_724;
obj_t arg1475_725;
obj_t arg1476_726;
obj_t arg1477_727;
arg1474_724 = symbol1815___expander_struct;
{
obj_t arg1485_734;
obj_t arg1486_735;
{
obj_t list1492_741;
{
obj_t arg1494_742;
arg1494_742 = MAKE_PAIR(symbol1830___expander_struct, BNIL);
list1492_741 = MAKE_PAIR(name_320, arg1494_742);
}
arg1485_734 = symbol_append_197___r4_symbols_6_4(list1492_741);
}
arg1486_735 = symbol1835___expander_struct;
{
obj_t list1488_737;
{
obj_t arg1489_738;
arg1489_738 = MAKE_PAIR(BNIL, BNIL);
list1488_737 = MAKE_PAIR(arg1486_735, arg1489_738);
}
arg1475_725 = cons__138___r4_pairs_and_lists_6_3(arg1485_734, list1488_737);
}
}
{
obj_t arg1497_744;
obj_t arg1498_745;
arg1497_744 = symbol1836___expander_struct;
arg1498_745 = symbol1835___expander_struct;
{
obj_t list1500_747;
{
obj_t arg1501_748;
{
obj_t arg1502_749;
arg1502_749 = MAKE_PAIR(BNIL, BNIL);
{
obj_t aux_1616;
aux_1616 = BINT(i_690);
arg1501_748 = MAKE_PAIR(aux_1616, arg1502_749);
}
}
list1500_747 = MAKE_PAIR(arg1498_745, arg1501_748);
}
arg1476_726 = cons__138___r4_pairs_and_lists_6_3(arg1497_744, list1500_747);
}
}
{
obj_t arg1504_751;
obj_t arg1507_753;
obj_t arg1510_754;
arg1504_751 = symbol1820___expander_struct;
arg1507_753 = SYMBOL_TO_STRING(name_320);
arg1510_754 = symbol1835___expander_struct;
{
obj_t list1512_756;
{
obj_t arg1513_757;
{
obj_t arg1514_758;
{
obj_t arg1515_759;
arg1515_759 = MAKE_PAIR(BNIL, BNIL);
arg1514_758 = MAKE_PAIR(arg1510_754, arg1515_759);
}
arg1513_757 = MAKE_PAIR(arg1507_753, arg1514_758);
}
list1512_756 = MAKE_PAIR(string1837___expander_struct, arg1513_757);
}
arg1477_727 = cons__138___r4_pairs_and_lists_6_3(arg1504_751, list1512_756);
}
}
{
obj_t list1479_729;
{
obj_t arg1480_730;
{
obj_t arg1481_731;
{
obj_t arg1483_732;
arg1483_732 = MAKE_PAIR(BNIL, BNIL);
arg1481_731 = MAKE_PAIR(arg1477_727, arg1483_732);
}
arg1480_730 = MAKE_PAIR(arg1476_726, arg1481_731);
}
list1479_729 = MAKE_PAIR(arg1475_725, arg1480_730);
}
arg1453_707 = cons__138___r4_pairs_and_lists_6_3(arg1474_724, list1479_729);
}
}
{
obj_t list1455_709;
{
obj_t arg1456_710;
{
obj_t arg1458_711;
arg1458_711 = MAKE_PAIR(BNIL, BNIL);
arg1456_710 = MAKE_PAIR(arg1453_707, arg1458_711);
}
list1455_709 = MAKE_PAIR(arg1450_706, arg1456_710);
}
arg1448_704 = cons__138___r4_pairs_and_lists_6_3(arg1449_705, list1455_709);
}
}
{
bool_t test1646_1182;
test1646_1182 = EXTENDED_PAIRP(x_1);
if(test1646_1182){
obj_t arg1647_1183;
obj_t arg1648_1184;
obj_t arg1649_1185;
arg1647_1183 = CAR(arg1448_704);
arg1648_1184 = CDR(arg1448_704);
{
bool_t test1748_1190;
test1748_1190 = EXTENDED_PAIRP(x_1);
if(test1748_1190){
arg1649_1185 = CER(x_1);
}
 else {
FAILURE(string1824___expander_struct,string1825___expander_struct,x_1);}
}
arg1446_703 = MAKE_EXTENDED_PAIR(arg1647_1183, arg1648_1184, arg1649_1185);
}
 else {
arg1446_703 = arg1448_704;
}
}
}
arg1443_701 = PROCEDURE_ENTRY(e_2)(e_2, arg1446_703, e_2, BEOA);
}
{
obj_t arg1517_761;
{
obj_t arg1518_762;
{
obj_t arg1519_763;
{
obj_t arg1522_764;
obj_t arg1524_765;
obj_t arg1525_766;
arg1522_764 = symbol1812___expander_struct;
{
obj_t arg1531_772;
obj_t arg1532_773;
obj_t arg1533_774;
{
obj_t arg1540_780;
arg1540_780 = symbol1828___expander_struct;
{
obj_t list1543_782;
{
obj_t arg1545_783;
{
obj_t arg1548_784;
{
obj_t arg1549_785;
arg1549_785 = MAKE_PAIR(symbol1829___expander_struct, BNIL);
arg1548_784 = MAKE_PAIR(pr_697, arg1549_785);
}
arg1545_783 = MAKE_PAIR(arg1540_780, arg1548_784);
}
list1543_782 = MAKE_PAIR(name_320, arg1545_783);
}
arg1531_772 = symbol_append_197___r4_symbols_6_4(list1543_782);
}
}
arg1532_773 = symbol1835___expander_struct;
arg1533_774 = symbol1838___expander_struct;
{
obj_t list1535_776;
{
obj_t arg1536_777;
{
obj_t arg1537_778;
arg1537_778 = MAKE_PAIR(BNIL, BNIL);
arg1536_777 = MAKE_PAIR(arg1533_774, arg1537_778);
}
list1535_776 = MAKE_PAIR(arg1532_773, arg1536_777);
}
arg1524_765 = cons__138___r4_pairs_and_lists_6_3(arg1531_772, list1535_776);
}
}
{
obj_t arg1552_787;
obj_t arg1553_788;
obj_t arg1554_789;
obj_t arg1555_790;
arg1552_787 = symbol1815___expander_struct;
{
obj_t arg1562_797;
obj_t arg1563_798;
{
obj_t list1570_804;
{
obj_t arg1572_805;
arg1572_805 = MAKE_PAIR(symbol1830___expander_struct, BNIL);
list1570_804 = MAKE_PAIR(name_320, arg1572_805);
}
arg1562_797 = symbol_append_197___r4_symbols_6_4(list1570_804);
}
arg1563_798 = symbol1835___expander_struct;
{
obj_t list1565_800;
{
obj_t arg1566_801;
arg1566_801 = MAKE_PAIR(BNIL, BNIL);
list1565_800 = MAKE_PAIR(arg1563_798, arg1566_801);
}
arg1553_788 = cons__138___r4_pairs_and_lists_6_3(arg1562_797, list1565_800);
}
}
{
obj_t arg1575_807;
obj_t arg1578_808;
obj_t arg1580_809;
arg1575_807 = symbol1839___expander_struct;
arg1578_808 = symbol1835___expander_struct;
arg1580_809 = symbol1838___expander_struct;
{
obj_t list1582_811;
{
obj_t arg1583_812;
{
obj_t arg1584_813;
{
obj_t arg1585_814;
arg1585_814 = MAKE_PAIR(BNIL, BNIL);
arg1584_813 = MAKE_PAIR(arg1580_809, arg1585_814);
}
{
obj_t aux_1664;
aux_1664 = BINT(i_690);
arg1583_812 = MAKE_PAIR(aux_1664, arg1584_813);
}
}
list1582_811 = MAKE_PAIR(arg1578_808, arg1583_812);
}
arg1554_789 = cons__138___r4_pairs_and_lists_6_3(arg1575_807, list1582_811);
}
}
{
obj_t arg1587_816;
obj_t arg1589_818;
obj_t arg1592_819;
arg1587_816 = symbol1820___expander_struct;
arg1589_818 = SYMBOL_TO_STRING(name_320);
arg1592_819 = symbol1835___expander_struct;
{
obj_t list1594_821;
{
obj_t arg1595_822;
{
obj_t arg1598_823;
{
obj_t arg1600_824;
arg1600_824 = MAKE_PAIR(BNIL, BNIL);
arg1598_823 = MAKE_PAIR(arg1592_819, arg1600_824);
}
arg1595_822 = MAKE_PAIR(arg1589_818, arg1598_823);
}
list1594_821 = MAKE_PAIR(string1840___expander_struct, arg1595_822);
}
arg1555_790 = cons__138___r4_pairs_and_lists_6_3(arg1587_816, list1594_821);
}
}
{
obj_t list1557_792;
{
obj_t arg1558_793;
{
obj_t arg1559_794;
{
obj_t arg1560_795;
arg1560_795 = MAKE_PAIR(BNIL, BNIL);
arg1559_794 = MAKE_PAIR(arg1555_790, arg1560_795);
}
arg1558_793 = MAKE_PAIR(arg1554_789, arg1559_794);
}
list1557_792 = MAKE_PAIR(arg1553_788, arg1558_793);
}
arg1525_766 = cons__138___r4_pairs_and_lists_6_3(arg1552_787, list1557_792);
}
}
{
obj_t list1527_768;
{
obj_t arg1528_769;
{
obj_t arg1529_770;
arg1529_770 = MAKE_PAIR(BNIL, BNIL);
arg1528_769 = MAKE_PAIR(arg1525_766, arg1529_770);
}
list1527_768 = MAKE_PAIR(arg1524_765, arg1528_769);
}
arg1519_763 = cons__138___r4_pairs_and_lists_6_3(arg1522_764, list1527_768);
}
}
{
bool_t test1646_1201;
test1646_1201 = EXTENDED_PAIRP(x_1);
if(test1646_1201){
obj_t arg1647_1202;
obj_t arg1648_1203;
obj_t arg1649_1204;
arg1647_1202 = CAR(arg1519_763);
arg1648_1203 = CDR(arg1519_763);
{
bool_t test1748_1209;
test1748_1209 = EXTENDED_PAIRP(x_1);
if(test1748_1209){
arg1649_1204 = CER(x_1);
}
 else {
FAILURE(string1824___expander_struct,string1825___expander_struct,x_1);}
}
arg1518_762 = MAKE_EXTENDED_PAIR(arg1647_1202, arg1648_1203, arg1649_1204);
}
 else {
arg1518_762 = arg1519_763;
}
}
}
arg1517_761 = PROCEDURE_ENTRY(e_2)(e_2, arg1518_762, e_2, BEOA);
}
arg1444_702 = MAKE_PAIR(arg1517_761, res_692);
}
arg1441_700 = MAKE_PAIR(arg1443_701, arg1444_702);
}
{
obj_t res_1699;
obj_t slots_1698;
long i_1697;
i_1697 = arg1438_698;
slots_1698 = arg1440_699;
res_1699 = arg1441_700;
res_692 = res_1699;
slots_691 = slots_1698;
i_690 = i_1697;
goto loop_693;
}
}
}
}
arg1257_551 = MAKE_PAIR(arg1356_634, arg1357_635);
}
arg1023_337 = MAKE_PAIR(arg1256_550, arg1257_551);
}
arg1021_335 = MAKE_PAIR(arg1022_336, arg1023_337);
}
return MAKE_PAIR(arg1020_334, arg1021_335);
}
}
}
}
}
}
}
 else {
FAILURE(string1807___expander_struct,string1808___expander_struct,x_1);}
}
 else {
FAILURE(string1807___expander_struct,string1808___expander_struct,x_1);}
}
}


/* _expand-eval-define-struct */obj_t _expand_eval_define_struct_219___expander_struct(obj_t env_1257, obj_t x_1258, obj_t e_1259)
{
return expand_eval_define_struct_250___expander_struct(x_1258, e_1259);
}


/* imported-modules-init */obj_t imported_modules_init_94___expander_struct()
{
module_initialization_70___error(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___bigloo(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___tvector(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___structure(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___bexit(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___match_normalize(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_numbers_6_5(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_characters_6_6(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_booleans_6_1(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_symbols_6_4(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_strings_6_7(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_input_6_10_2(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_control_features_6_9(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_vectors_6_8(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EXPANDER_STRUCT");
module_initialization_70___r4_output_6_10_3(((long)0), "__EXPANDER_STRUCT");
return module_initialization_70___progn(((long)0), "__EXPANDER_STRUCT");
}

