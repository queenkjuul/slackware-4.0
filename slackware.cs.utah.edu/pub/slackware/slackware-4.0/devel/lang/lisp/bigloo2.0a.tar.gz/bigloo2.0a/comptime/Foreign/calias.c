/*===========================================================================*/
/*   (Foreign/calias.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct calias
  {
     bool_t array__248;
  }
      *calias_t;

typedef struct cenum
  {
     struct type *btype;
     obj_t literals;
  }
     *cenum_t;

typedef struct cfunction
  {
     struct type *btype;
     long arity;
     struct type *type_res_48;
     obj_t type_args_244;
  }
         *cfunction_t;

typedef struct cptr
  {
     struct type *btype;
     struct type *point_to_164;
     bool_t array__248;
  }
    *cptr_t;

typedef struct cstruct
  {
     bool_t struct__46;
     obj_t fields;
     obj_t cstruct__170;
  }
       *cstruct_t;

typedef struct cstruct__170
  {
     struct type *btype;
     struct cstruct *cstruct;
  }
            *cstruct__170_t;


static obj_t method_init_76_foreign_calias();
extern obj_t make_ctype_accesses__219_foreign_access(type_t, type_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_foreign_calias(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_foreign_ctype(long, char *);
extern obj_t module_initialization_70_foreign_access(long, char *);
extern obj_t module_initialization_70___object(long, char *);
static obj_t _make_ctype_accesses_1207_146_foreign_access(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_foreign_calias();
static obj_t make_ctype_accesses__calias_189_foreign_calias(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_foreign_calias();
static obj_t toplevel_init_63_foreign_calias();
extern obj_t calias_foreign_ctype;
static obj_t require_initialization_114_foreign_calias = BUNSPEC;
static obj_t *__cnst;

DEFINE_STATIC_PROCEDURE(proc1208_foreign_calias, make_ctype_accesses__calias_189_foreign_calias1210, make_ctype_accesses__calias_189_foreign_calias, 0L, 2);
extern obj_t make_ctype_accesses__env_11_foreign_access;


/* module-initialization */ obj_t 
module_initialization_70_foreign_calias(long checksum_507, char *from_508)
{
   if (CBOOL(require_initialization_114_foreign_calias))
     {
	require_initialization_114_foreign_calias = BBOOL(((bool_t) 0));
	library_modules_init_112_foreign_calias();
	imported_modules_init_94_foreign_calias();
	method_init_76_foreign_calias();
	toplevel_init_63_foreign_calias();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_foreign_calias()
{
   module_initialization_70___object(((long) 0), "FOREIGN_CALIAS");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_foreign_calias()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_foreign_calias()
{
   {
      obj_t make_ctype_accesses__calias_189_500;
      make_ctype_accesses__calias_189_500 = proc1208_foreign_calias;
      return add_method__1___object(make_ctype_accesses__env_11_foreign_access, calias_foreign_ctype, make_ctype_accesses__calias_189_500);
   }
}


/* make-ctype-accesses!-calias */ obj_t 
make_ctype_accesses__calias_189_foreign_calias(obj_t env_501, obj_t what_502, obj_t who_503)
{
   {
      calias_t what_454;
      type_t who_455;
      what_454 = (calias_t) (what_502);
      who_455 = (type_t) (who_503);
      {
	 type_t aux_518;
	 {
	    obj_t aux_519;
	    {
	       type_t obj_499;
	       obj_499 = (type_t) (what_454);
	       aux_519 = (((type_t) CREF(obj_499))->alias);
	    }
	    aux_518 = (type_t) (aux_519);
	 }
	 return make_ctype_accesses__219_foreign_access(aux_518, who_455);
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_foreign_calias()
{
   module_initialization_70_tools_trace(((long) 0), "FOREIGN_CALIAS");
   module_initialization_70_type_tools(((long) 0), "FOREIGN_CALIAS");
   module_initialization_70_type_type(((long) 0), "FOREIGN_CALIAS");
   module_initialization_70_tools_shape(((long) 0), "FOREIGN_CALIAS");
   module_initialization_70_foreign_ctype(((long) 0), "FOREIGN_CALIAS");
   return module_initialization_70_foreign_access(((long) 0), "FOREIGN_CALIAS");
}
