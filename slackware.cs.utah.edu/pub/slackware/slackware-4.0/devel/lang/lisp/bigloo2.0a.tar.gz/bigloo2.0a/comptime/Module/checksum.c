/*===========================================================================*/
/*   (Module/checksum.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern long clause_checksummer_12_module_checksum(obj_t, long);
extern obj_t _bigloo_level__187_engine_param;
extern obj_t module_initialization_70_module_checksum(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern long get_hash_power_number(char *, long);
static obj_t imported_modules_init_94_module_checksum();
static obj_t _clause_checksummer1161_14_module_checksum(obj_t, obj_t, obj_t);
extern long initial_checksum_14_module_checksum(obj_t);
static obj_t toplevel_init_63_module_checksum();
static obj_t list__number_226_module_checksum(obj_t, obj_t);
static obj_t _initial_checksum1160_210_module_checksum(obj_t, obj_t);
static obj_t atom__number_88_module_checksum(obj_t, obj_t);
extern obj_t _bigloo_name__170_engine_param;
static obj_t require_initialization_114_module_checksum = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(initial_checksum_env_225_module_checksum, _initial_checksum1160_210_module_checksum1163, _initial_checksum1160_210_module_checksum, 0L, 1);
DEFINE_EXPORT_PROCEDURE(clause_checksummer_env_74_module_checksum, _clause_checksummer1161_14_module_checksum1164, _clause_checksummer1161_14_module_checksum, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_module_checksum(long checksum_145, char *from_146)
{
   if (CBOOL(require_initialization_114_module_checksum))
     {
	require_initialization_114_module_checksum = BBOOL(((bool_t) 0));
	imported_modules_init_94_module_checksum();
	toplevel_init_63_module_checksum();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_checksum()
{
   return BUNSPEC;
}


/* initial-checksum */ long 
initial_checksum_14_module_checksum(obj_t mname_19)
{
   {
      long checksum_39;
      {
	 long arg1038_42;
	 long arg1039_43;
	 {
	    char *string_90;
	    string_90 = BSTRING_TO_STRING(_bigloo_name__170_engine_param);
	    arg1038_42 = get_hash_power_number(string_90, ((long) 16));
	 }
	 {
	    obj_t arg1040_44;
	    arg1040_44 = SYMBOL_TO_STRING(mname_19);
	    {
	       char *aux_155;
	       aux_155 = BSTRING_TO_STRING(arg1040_44);
	       arg1039_43 = get_hash_power_number(aux_155, ((long) 16));
	    }
	 }
	 checksum_39 = (arg1038_42 ^ arg1039_43);
      }
      {
	 bool_t test1033_40;
	 {
	    obj_t obj_97;
	    obj_97 = _bigloo_level__187_engine_param;
	    test1033_40 = CHARP(obj_97);
	 }
	 if (test1033_40)
	   {
	      long arg1034_41;
	      {
		 unsigned char char_166_98;
		 char_166_98 = (unsigned char) CCHAR(_bigloo_level__187_engine_param);
		 arg1034_41 = (char_166_98);
	      }
	      return (checksum_39 ^ arg1034_41);
	   }
	 else
	   {
	      return checksum_39;
	   }
      }
   }
}


/* _initial-checksum1160 */ obj_t 
_initial_checksum1160_210_module_checksum(obj_t env_139, obj_t mname_140)
{
   {
      long aux_164;
      aux_164 = initial_checksum_14_module_checksum(mname_140);
      return BINT(aux_164);
   }
}


/* clause-checksummer */ long 
clause_checksummer_12_module_checksum(obj_t clause_20, long checksum_21)
{
   {
      obj_t aux_167;
      aux_167 = list__number_226_module_checksum(BINT(checksum_21), clause_20);
      return (long) CINT(aux_167);
   }
}


/* list->number */ obj_t 
list__number_226_module_checksum(obj_t checksum_49, obj_t clause_50)
{
 list__number_226_module_checksum:
   if (NULLP(clause_50))
     {
	return checksum_49;
     }
   else
     {
	if (PAIRP(clause_50))
	  {
	     {
		obj_t arg1053_54;
		obj_t arg1055_55;
		arg1053_54 = atom__number_88_module_checksum(checksum_49, CAR(clause_50));
		arg1055_55 = CDR(clause_50);
		{
		   obj_t clause_179;
		   obj_t checksum_178;
		   checksum_178 = arg1053_54;
		   clause_179 = arg1055_55;
		   clause_50 = clause_179;
		   checksum_49 = checksum_178;
		   goto list__number_226_module_checksum;
		}
	     }
	  }
	else
	  {
	     return atom__number_88_module_checksum(checksum_49, clause_50);
	  }
     }
}


/* atom->number */ obj_t 
atom__number_88_module_checksum(obj_t checksum_57, obj_t clause_58)
{
   {
      bool_t test_181;
      if (INTEGERP(clause_58))
	{
	   test_181 = ((bool_t) 1);
	}
      else
	{
	   test_181 = REALP(clause_58);
	}
      if (test_181)
	{
	   {
	      long aux_185;
	      {
		 long aux_188;
		 long aux_186;
		 aux_188 = (long) CINT(clause_58);
		 aux_186 = (long) CINT(checksum_57);
		 aux_185 = (aux_186 ^ aux_188);
	      }
	      return BINT(aux_185);
	   }
	}
      else
	{
	   if (CHARP(clause_58))
	     {
		{
		   long aux_194;
		   {
		      long aux_197;
		      long aux_195;
		      {
			 unsigned char aux_198;
			 aux_198 = (unsigned char) CCHAR(clause_58);
			 aux_197 = (aux_198);
		      }
		      aux_195 = (long) CINT(checksum_57);
		      aux_194 = (aux_195 ^ aux_197);
		   }
		   return BINT(aux_194);
		}
	     }
	   else
	     {
		if (CNSTP(clause_58))
		  {
		     {
			long arg1137_64;
			arg1137_64 = CCNST(clause_58);
			{
			   long aux_206;
			   {
			      long aux_207;
			      aux_207 = (long) CINT(checksum_57);
			      aux_206 = (aux_207 ^ arg1137_64);
			   }
			   return BINT(aux_206);
			}
		     }
		  }
		else
		  {
		     if (STRINGP(clause_58))
		       {
			  {
			     long arg1142_66;
			     {
				char *aux_213;
				aux_213 = BSTRING_TO_STRING(clause_58);
				arg1142_66 = get_hash_power_number(aux_213, ((long) 16));
			     }
			     {
				long aux_216;
				{
				   long aux_217;
				   aux_217 = (long) CINT(checksum_57);
				   aux_216 = (aux_217 ^ arg1142_66);
				}
				return BINT(aux_216);
			     }
			  }
		       }
		     else
		       {
			  if (SYMBOLP(clause_58))
			    {
			       {
				  long arg1144_68;
				  {
				     obj_t arg1150_126;
				     arg1150_126 = SYMBOL_TO_STRING(clause_58);
				     {
					char *aux_224;
					aux_224 = BSTRING_TO_STRING(arg1150_126);
					arg1144_68 = get_hash_power_number(aux_224, ((long) 16));
				     }
				  }
				  {
				     long aux_227;
				     {
					long aux_228;
					aux_228 = (long) CINT(checksum_57);
					aux_227 = (aux_228 ^ arg1144_68);
				     }
				     return BINT(aux_227);
				  }
			       }
			    }
			  else
			    {
			       if (PAIRP(clause_58))
				 {
				    return list__number_226_module_checksum(checksum_57, clause_58);
				 }
			       else
				 {
				    return BFALSE;
				 }
			    }
		       }
		  }
	     }
	}
   }
}


/* _clause-checksummer1161 */ obj_t 
_clause_checksummer1161_14_module_checksum(obj_t env_141, obj_t clause_142, obj_t checksum_143)
{
   {
      long aux_235;
      aux_235 = clause_checksummer_12_module_checksum(clause_142, (long) CINT(checksum_143));
      return BINT(aux_235);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_checksum()
{
   module_initialization_70_tools_speek(((long) 0), "MODULE_CHECKSUM");
   module_initialization_70_tools_error(((long) 0), "MODULE_CHECKSUM");
   module_initialization_70_engine_pass(((long) 0), "MODULE_CHECKSUM");
   return module_initialization_70_engine_param(((long) 0), "MODULE_CHECKSUM");
}
