/*===========================================================================*/
/*   (Engine/param.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
obj_t _additional_traces__2_engine_param = BUNSPEC;
obj_t _src_files__222_engine_param = BUNSPEC;
obj_t _inlining_reduce_kfactor__26_engine_param = BUNSPEC;
obj_t _profile_library__193_engine_param = BUNSPEC;
obj_t _cc__215_engine_param = BUNSPEC;
extern obj_t display__75___r4_output_6_10_3(obj_t);
obj_t _auto_mode__185_engine_param = BUNSPEC;
obj_t _optim__89_engine_param = BUNSPEC;
obj_t _mco_suffix__47_engine_param = BUNSPEC;
obj_t _access_table__91_engine_param = BUNSPEC;
obj_t _optim_unroll_loop___80_engine_param = BUNSPEC;
obj_t _inlining_kfactor__130_engine_param = BUNSPEC;
obj_t _verbose__1_engine_param = BUNSPEC;
obj_t _type_shape___78_engine_param = BUNSPEC;
extern obj_t _load_path__54___eval;
obj_t _max_c_foreign_arity__143_engine_param = BUNSPEC;
obj_t _rm_c_files__192_engine_param = BUNSPEC;
obj_t _bigloo_lib_base_name__84_engine_param = BUNSPEC;
obj_t _reflection___104_engine_param = BUNSPEC;
static obj_t eval_init_57_engine_param();
obj_t _stdc__25_engine_param = BUNSPEC;
obj_t _shared_cnst___67_engine_param = BUNSPEC;
obj_t _unsafe_library__118_engine_param = BUNSPEC;
static obj_t _bigloo_date_59_tools_date(obj_t);
obj_t _bigloo_version__168_engine_param = BUNSPEC;
static obj_t _add_doc_variable__66_engine_param(obj_t, obj_t, obj_t);
obj_t _access_shape___50_engine_param = BUNSPEC;
obj_t _bdb_debug__1_engine_param = BUNSPEC;
obj_t _bigloo_level__187_engine_param = BUNSPEC;
obj_t _reader__83_engine_param = BUNSPEC;
static obj_t add_doc_variable__44_engine_param(obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern obj_t bigloo_date_110_tools_date();
obj_t _additional_bigloo_libraries__50_engine_param = BUNSPEC;
obj_t _unsafe_struct__195_engine_param = BUNSPEC;
obj_t _bigloo_user_lib__33_engine_param = BUNSPEC;
obj_t _genericity__47_engine_param = BUNSPEC;
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_date(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___evenv(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
obj_t _default_lib_dir__128_engine_param = BUNSPEC;
obj_t _module_checksum_object___74_engine_param = BUNSPEC;
extern obj_t os_tmp_175___os;
obj_t _unsafe_arity__240_engine_param = BUNSPEC;
obj_t _strip__173_engine_param = BUNSPEC;
obj_t _heap_base_name__65_engine_param = BUNSPEC;
obj_t _heap_name__135_engine_param = BUNSPEC;
obj_t _lib_src_dir__208_engine_param = BUNSPEC;
static obj_t _bigloo_variables_usage_193_engine_param(obj_t, obj_t);
obj_t _unsafe_version__81_engine_param = BUNSPEC;
obj_t _max_c_token_length__129_engine_param = BUNSPEC;
extern obj_t define_primop_ref__105___evenv(obj_t, obj_t);
extern obj_t write___r4_output_6_10_3(obj_t, obj_t);
obj_t _max_stack_alloc_size__239_engine_param = BUNSPEC;
obj_t _module_shape___145_engine_param = BUNSPEC;
static obj_t imported_modules_init_94_engine_param();
obj_t _bigloo_lib__121_engine_param = BUNSPEC;
extern obj_t string_append_106___r4_strings_6_7(obj_t);
obj_t _optim_o_macro___96_engine_param = BUNSPEC;
obj_t _dest__217_engine_param = BUNSPEC;
obj_t _cc_options__252_engine_param = BUNSPEC;
obj_t _additional_include_foreign__44_engine_param = BUNSPEC;
obj_t _prof_table_name__107_engine_param = BUNSPEC;
obj_t _trace_name__101_engine_param = BUNSPEC;
obj_t _optim_inline_method___30_engine_param = BUNSPEC;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
obj_t _rest_args__8_engine_param = BUNSPEC;
static obj_t library_modules_init_112_engine_param();
obj_t _with_files__6_engine_param = BUNSPEC;
obj_t _c_debug_option__198_engine_param = BUNSPEC;
obj_t _user_heap_size__225_engine_param = BUNSPEC;
extern obj_t newline___r4_output_6_10_3(obj_t);
obj_t _optim_stack___57_engine_param = BUNSPEC;
obj_t _o_files__27_engine_param = BUNSPEC;
obj_t _key_shape___172_engine_param = BUNSPEC;
static obj_t toplevel_init_63_engine_param();
obj_t _unsafe_type__146_engine_param = BUNSPEC;
obj_t _inlining___224_engine_param = BUNSPEC;
obj_t _call_cc___102_engine_param = BUNSPEC;
extern obj_t open_input_string(obj_t);
extern obj_t print___r4_output_6_10_3(obj_t);
obj_t _bigloo_licensing___64_engine_param = BUNSPEC;
obj_t _interpreter__140_engine_param = BUNSPEC;
obj_t _bigloo_author__68_engine_param = BUNSPEC;
static obj_t lambda1380_engine_param(obj_t, obj_t);
static obj_t lambda1377_engine_param(obj_t, obj_t);
extern obj_t string_to_bstring(char *);
obj_t _lib_dir__34_engine_param = BUNSPEC;
obj_t _bigloo_date__70_engine_param = BUNSPEC;
obj_t _bigloo_args__103_engine_param = BUNSPEC;
obj_t _access_file__194_engine_param = BUNSPEC;
obj_t _case_sensitive__90_engine_param = BUNSPEC;
obj_t _init_mode__183_engine_param = BUNSPEC;
obj_t _location_shape___48_engine_param = BUNSPEC;
obj_t _compiler_debug__134_engine_param = BUNSPEC;
obj_t _static_bigloo___233_engine_param = BUNSPEC;
obj_t _include_foreign__253_engine_param = BUNSPEC;
extern obj_t make_string(long, unsigned char);
obj_t _trace_write_length__146_engine_param = BUNSPEC;
obj_t _optim_loop_inlining___30_engine_param = BUNSPEC;
obj_t _additional_heap_name__223_engine_param = BUNSPEC;
obj_t _gc_lib__201_engine_param = BUNSPEC;
obj_t _shell__121_engine_param = BUNSPEC;
obj_t _bigloo_name__170_engine_param = BUNSPEC;
extern obj_t bigloo_variables_usage_232_engine_param(bool_t);
obj_t _startup_file__78_engine_param = BUNSPEC;
obj_t _tmp_dest__132_engine_param = BUNSPEC;
extern obj_t define_primop__185___evenv(obj_t, obj_t);
extern obj_t eval___eval(obj_t, obj_t);
static obj_t _bigloo_variables__214_engine_param = BUNSPEC;
obj_t _unsafe_range__218_engine_param = BUNSPEC;
extern obj_t read___reader(obj_t);
obj_t _profile_mode__105_engine_param = BUNSPEC;
obj_t _bigloo_cmd_name__60_engine_param = BUNSPEC;
obj_t _ld_options__88_engine_param = BUNSPEC;
obj_t _bigloo_tmp__142_engine_param = BUNSPEC;
obj_t _user_shape___227_engine_param = BUNSPEC;
obj_t _c_debug__136_engine_param = BUNSPEC;
obj_t _garbage_collector__95_engine_param = BUNSPEC;
obj_t _lib_mode__85_engine_param = BUNSPEC;
obj_t _bigloo_email__0_engine_param = BUNSPEC;
obj_t _hello__249_engine_param = BUNSPEC;
static obj_t require_initialization_114_engine_param = BUNSPEC;
extern obj_t make_file_name_203___os(obj_t, obj_t);
obj_t _additional_heap_names__104_engine_param = BUNSPEC;
obj_t _src_suffix__192_engine_param = BUNSPEC;
obj_t _obj_suffix__189_engine_param = BUNSPEC;
obj_t _pass__125_engine_param = BUNSPEC;
static obj_t cnst_init_137_engine_param();
obj_t _indent__220_engine_param = BUNSPEC;
obj_t _extend_entry__7_engine_param = BUNSPEC;
static obj_t __cnst[114];

DEFINE_STATIC_PROCEDURE(proc1576_engine_param, lambda1380_engine_param1609, lambda1380_engine_param, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1574_engine_param, lambda1377_engine_param1610, lambda1377_engine_param, 0L, 1);
DEFINE_STATIC_PROCEDURE(add_doc_variable__env_43_engine_param, _add_doc_variable__66_engine_param1611, _add_doc_variable__66_engine_param, 0L, 2);
extern obj_t bigloo_date_env_128_tools_date;
DEFINE_EXPORT_PROCEDURE(bigloo_variables_usage_env_96_engine_param, _bigloo_variables_usage_193_engine_param1612, _bigloo_variables_usage_193_engine_param, 0L, 1);
DEFINE_STRING(string1599_engine_param, string1599_engine_param1613, "     ", 5);
DEFINE_STRING(string1598_engine_param, string1598_engine_param1614, "   - ", 5);
DEFINE_STRING(string1597_engine_param, string1597_engine_param1615, " : ", 3);
DEFINE_STRING(string1596_engine_param, string1596_engine_param1616, "   These variables are:", 23);
DEFINE_STRING(string1595_engine_param, string1595_engine_param1617, "   `*strip*' to the value `#t'.", 31);
DEFINE_STRING(string1594_engine_param, string1594_engine_param1618, "   \"-eval '(set! *strip* #t)'\" will set the variable", 52);
DEFINE_STRING(string1593_engine_param, string1593_engine_param1619, "   the module clause `option'. For instance the option", 54);
DEFINE_STRING(string1603_engine_param, string1603_engine_param1620, "*ADDITIONAL-TRACES* *ACCESS-TABLE* *TYPE-SHAPE?* *ACCESS-SHAPE?* ADD-DOC-VARIABLE! BIGLOO-DATE *GENERICITY* *MODULE-SHAPE?* *REST-ARGS* *KEY-SHAPE?* *BIGLOO-AUTHOR* *BIGLOO-DATE* *BIGLOO-ARGS* *LOCATION-SHAPE?* BIGLOO-VARIABLES-USAGE *TMP-DEST* *BIGLOO-VARIABLES* *BIGLOO-CMD-NAME* *USER-SHAPE?* *BIGLOO-EMAIL* *HYGIEN?* *WARNING* *DEBUG* *USER-PASS* *LOAD-PATH* *READER* PLAIN *USER-HEAP-SIZE* *CASE-SENSITIVE* *AUTO-MODE* ((\"ml\" . \"caml\") (\"mli\" . \"caml\") (\"oon\" . \"meroon\")) *MCO-SUFFIX* (\"mco\") *OBJ-SUFFIX* (\"o\") *SRC-SUFFIX* (\"scm\" \"bgl\") *EXTEND-ENTRY* *INLINING-REDUCE-KFACTOR* *INLINING-KFACTOR* *INLINING?* *OPTIM-O-MACRO?* *OPTIM-LOOP-INLINING?* *OPTIM-UNROLL-LOOP?* *OPTIM-INLINE-METHOD?* *OPTIM-STACK?* *OPTIM* *TRACE-WRITE-LENGTH* *TRACE-NAME* *MAX-C-FOREIGN-ARITY* *MAX-C-TOKEN-LENGTH* *INIT-MODE* READ *LIB-MODE* *SHARED-CNST?* *MAX-STACK-ALLOC-SIZE* *PROFILE-LIBRARY* *UNSAFE-LIBRARY* *UNSAFE-VERSION* *UNSAFE-STRUCT* *UNSAFE-RANGE* *UNSAFE-ARITY* *UNSAFE-TYPE* *GARBAGE-COLLECTOR* BOEHM"
   " *MODULE-CHECKSUM-OBJECT?* *PASS* LD *REFLECTION?* *CALL/CC?* *STARTUP-FILE* *INTERPRETER* *WITH-FILES* *O-FILES* *ACCESS-FILE* *PROF-TABLE-NAME* *PROFILE-MODE* *BDB-DEBUG* *C-DEBUG-OPTION* *C-DEBUG* *COMPILER-DEBUG* *INDENT* *ADDITIONAL-HEAP-NAMES* *ADDITIONAL-HEAP-NAME* *HEAP-NAME* *HEAP-BASE-NAME* *ADDITIONAL-INCLUDE-FOREIGN* *INCLUDE-FOREIGN* *ADDITIONAL-BIGLOO-LIBRARIES* *BIGLOO-USER-LIB* *STATIC-BIGLOO?* *GC-LIB* *BIGLOO-LIB* *BIGLOO-LIB-BASE-NAME* *LIB-SRC-DIR* *LIB-DIR* *DEFAULT-LIB-DIR* *STRIP* *LD-OPTIONS* *RM-C-FILES* *CC-OPTIONS* *STDC* *CC* *SHELL* *DEST* *SRC-FILES* *HELLO* *VERBOSE* *BIGLOO-LICENSING?* *BIGLOO-TMP* NOTHING-YET *BIGLOO-LEVEL* *BIGLOO-NAME* *BIGLOO-VERSION* ", 1700);
DEFINE_STRING(string1592_engine_param, string1592_engine_param1621, "   interpreter, by the means of the `-eval' option, or using", 60);
DEFINE_STRING(string1602_engine_param, string1602_engine_param1622, "]", 1);
DEFINE_STRING(string1591_engine_param, string1591_engine_param1623, "   All the Bigloo control variables can be changed from the", 59);
DEFINE_STRING(string1601_engine_param, string1601_engine_param1624, " [", 2);
DEFINE_STRING(string1589_engine_param, string1589_engine_param1625, "The warning level", 17);
DEFINE_STRING(string1590_engine_param, string1590_engine_param1626, "Hygienic r5rs macro expansion activation", 40);
DEFINE_STRING(string1600_engine_param, string1600_engine_param1627, "     default: ", 14);
DEFINE_STRING(string1588_engine_param, string1588_engine_param1628, "The debugging level", 19);
DEFINE_STRING(string1587_engine_param, string1587_engine_param1629, "The user specific compilation pass", 34);
DEFINE_STRING(string1586_engine_param, string1586_engine_param1630, "The load path", 13);
DEFINE_STRING(string1585_engine_param, string1585_engine_param1631, "The way the reader reads input file ('plain or 'intern)", 55);
DEFINE_STRING(string1584_engine_param, string1584_engine_param1632, "Heap size (in MegaByte) or #f for default value", 47);
DEFINE_STRING(string1583_engine_param, string1583_engine_param1633, "Case sensitivity", 16);
DEFINE_STRING(string1582_engine_param, string1582_engine_param1634, "auto-mode (extend mode) list", 28);
DEFINE_STRING(string1581_engine_param, string1581_engine_param1635, "Module checksum object legal suffixes", 37);
DEFINE_STRING(string1579_engine_param, string1579_engine_param1636, "Scheme legal suffixes", 21);
DEFINE_STRING(string1580_engine_param, string1580_engine_param1637, "Object legal suffixes", 21);
DEFINE_STRING(string1578_engine_param, string1578_engine_param1638, "Extend entry", 12);
DEFINE_STRING(string1577_engine_param, string1577_engine_param1639, "Inlinine growth factor reductor", 31);
DEFINE_STRING(string1575_engine_param, string1575_engine_param1640, "Inlining growth factor", 22);
DEFINE_STRING(string1573_engine_param, string1573_engine_param1641, "Inlining optimization", 21);
DEFINE_STRING(string1572_engine_param, string1572_engine_param1642, "Enable optimization by macro-expansion", 38);
DEFINE_STRING(string1571_engine_param, string1571_engine_param1643, "Loop inlining optimization", 26);
DEFINE_STRING(string1569_engine_param, string1569_engine_param1644, "Method inlining optimization", 28);
DEFINE_STRING(string1570_engine_param, string1570_engine_param1645, "Loop unrolling optimization", 27);
DEFINE_STRING(string1568_engine_param, string1568_engine_param1646, "Stack allocation optimization", 29);
DEFINE_STRING(string1567_engine_param, string1567_engine_param1647, "Optimization level", 18);
DEFINE_STRING(string1566_engine_param, string1566_engine_param1648, "Trace dumping max level", 23);
DEFINE_STRING(string1565_engine_param, string1565_engine_param1649, "Trace file name", 15);
DEFINE_STRING(string1564_engine_param, string1564_engine_param1650, "trace", 5);
DEFINE_STRING(string1563_engine_param, string1563_engine_param1651, "Max C function arity", 20);
DEFINE_STRING(string1562_engine_param, string1562_engine_param1652, "Max c token length", 18);
DEFINE_STRING(string1561_engine_param, string1561_engine_param1653, "Module initialization mode", 26);
DEFINE_STRING(string1559_engine_param, string1559_engine_param1654, "Shared constant compilation?", 28);
DEFINE_STRING(string1560_engine_param, string1560_engine_param1655, "Lib-mode compilation?", 21);
DEFINE_STRING(string1558_engine_param, string1558_engine_param1656, "Maximum size of stack allocated objects", 39);
DEFINE_STRING(string1557_engine_param, string1557_engine_param1657, "Use the profiled library version", 32);
DEFINE_STRING(string1556_engine_param, string1556_engine_param1658, "Use the unsafe library version", 30);
DEFINE_STRING(string1555_engine_param, string1555_engine_param1659, "Module version safety", 21);
DEFINE_STRING(string1554_engine_param, string1554_engine_param1660, "Runtime struct range safety", 27);
DEFINE_STRING(string1553_engine_param, string1553_engine_param1661, "Runtime range safety", 20);
DEFINE_STRING(string1552_engine_param, string1552_engine_param1662, "Runtime type arity safety", 25);
DEFINE_STRING(string1551_engine_param, string1551_engine_param1663, "Runtime type safety", 19);
DEFINE_STRING(string1549_engine_param, string1549_engine_param1664, "Produce a module checksum object (.mco)", 39);
DEFINE_STRING(string1550_engine_param, string1550_engine_param1665, "The garbage collector", 21);
DEFINE_STRING(string1548_engine_param, string1548_engine_param1666, "Stop after the pass", 19);
DEFINE_STRING(string1547_engine_param, string1547_engine_param1667, "Shall we produce refection code for classes", 43);
DEFINE_STRING(string1546_engine_param, string1546_engine_param1668, "Shall we enabled call/cc?", 25);
DEFINE_STRING(string1545_engine_param, string1545_engine_param1669, "A startup file for the interpreter", 34);
DEFINE_STRING(string1544_engine_param, string1544_engine_param1670, "Shall we interprete the source file?", 36);
DEFINE_STRING(string1543_engine_param, string1543_engine_param1671, "The additional modules", 22);
DEFINE_STRING(string1542_engine_param, string1542_engine_param1672, "The additional obect files", 26);
DEFINE_STRING(string1541_engine_param, string1541_engine_param1673, "The access file name", 20);
DEFINE_STRING(string1539_engine_param, string1539_engine_param1674, "bmon.out", 8);
DEFINE_STRING(string1540_engine_param, string1540_engine_param1675, "Bprof translation table file name", 33);
DEFINE_STRING(string1538_engine_param, string1538_engine_param1676, "Bigloo profile mode", 19);
DEFINE_STRING(string1537_engine_param, string1537_engine_param1677, "Bdb debugging mode", 18);
DEFINE_STRING(string1536_engine_param, string1536_engine_param1678, "cc debugging option", 19);
DEFINE_STRING(string1535_engine_param, string1535_engine_param1679, "-g", 2);
DEFINE_STRING(string1534_engine_param, string1534_engine_param1680, "C debugging mode?", 17);
DEFINE_STRING(string1533_engine_param, string1533_engine_param1681, "Debugging level", 15);
DEFINE_STRING(string1532_engine_param, string1532_engine_param1682, "The name of the C beautifier", 28);
DEFINE_STRING(string1531_engine_param, string1531_engine_param1683, "A list of Bigloo additional heap file name", 42);
DEFINE_STRING(string1529_engine_param, string1529_engine_param1684, "The Bigloo heap file name", 25);
DEFINE_STRING(string1530_engine_param, string1530_engine_param1685, "A name of an additional heap file name to be build", 50);
DEFINE_STRING(string1528_engine_param, string1528_engine_param1686, ".heap", 5);
DEFINE_STRING(string1527_engine_param, string1527_engine_param1687, "The Bigloo heap base name", 25);
DEFINE_STRING(string1526_engine_param, string1526_engine_param1688, "The additional C included files", 31);
DEFINE_STRING(string1525_engine_param, string1525_engine_param1689, "The C included files", 20);
DEFINE_STRING(string1524_engine_param, string1524_engine_param1690, "bigloo", 6);
DEFINE_STRING(string1523_engine_param, string1523_engine_param1691, ".h", 2);
DEFINE_STRING(string1522_engine_param, string1522_engine_param1692, "The user extra Bigloo libraries", 31);
DEFINE_STRING(string1521_engine_param, string1521_engine_param1693, "The user extra C libraries", 26);
DEFINE_STRING(string1519_engine_param, string1519_engine_param1694, "The Gc library", 14);
DEFINE_STRING(string1520_engine_param, string1520_engine_param1695, "Do we use the static Bigloo library", 35);
DEFINE_STRING(string1518_engine_param, string1518_engine_param1696, "gc", 2);
DEFINE_STRING(string1517_engine_param, string1517_engine_param1697, "The Bigloo library", 18);
DEFINE_STRING(string1516_engine_param, string1516_engine_param1698, "The Bigloo library base name", 28);
DEFINE_STRING(string1515_engine_param, string1515_engine_param1699, "runtime", 7);
DEFINE_STRING(string1514_engine_param, string1514_engine_param1700, "The lib dir path", 16);
DEFINE_STRING(string1513_engine_param, string1513_engine_param1701, "The default lib dir path (without version)", 42);
DEFINE_STRING(string1512_engine_param, string1512_engine_param1702, "Shall we strip the executable?", 30);
DEFINE_STRING(string1511_engine_param, string1511_engine_param1703, "ld options", 10);
DEFINE_STRING(string1499_engine_param, string1499_engine_param1704, "Manuel.Serrano@unice.fr", 23);
DEFINE_STRING(string1509_engine_param, string1509_engine_param1705, "cc options", 10);
DEFINE_STRING(string1510_engine_param, string1510_engine_param1706, "Shall we remove the C produced file?", 36);
DEFINE_STRING(string1498_engine_param, string1498_engine_param1707, "Manuel Serrano", 14);
DEFINE_STRING(string1508_engine_param, string1508_engine_param1708, "", 0);
DEFINE_STRING(string1497_engine_param, string1497_engine_param1709, "The Bigloo minor release number (#f or a char)", 46);
DEFINE_STRING(string1507_engine_param, string1507_engine_param1710, "Shall we produced ISO C?", 24);
DEFINE_STRING(string1496_engine_param, string1496_engine_param1711, "The Bigloo name", 15);
DEFINE_STRING(string1506_engine_param, string1506_engine_param1712, "The C compiler", 14);
DEFINE_STRING(string1495_engine_param, string1495_engine_param1713, "Bigloo (", 8);
DEFINE_STRING(string1505_engine_param, string1505_engine_param1714, "The target name", 15);
DEFINE_STRING(string1494_engine_param, string1494_engine_param1715, ")", 1);
DEFINE_STRING(string1504_engine_param, string1504_engine_param1716, "The sources files", 17);
DEFINE_STRING(string1493_engine_param, string1493_engine_param1717, "The Bigloo major release number", 31);
DEFINE_STRING(string1503_engine_param, string1503_engine_param1718, "Say hello (when verbose)", 24);
DEFINE_STRING(string1492_engine_param, string1492_engine_param1719, "2.0", 3);
DEFINE_STRING(string1502_engine_param, string1502_engine_param1720, "The verbosity level", 19);
DEFINE_STRING(string1501_engine_param, string1501_engine_param1721, "Add the Bigloo license ?", 24);
DEFINE_STRING(string1500_engine_param, string1500_engine_param1722, "The tmp directory name", 22);


/* module-initialization */ obj_t 
module_initialization_70_engine_param(long checksum_958, char *from_959)
{
   if (CBOOL(require_initialization_114_engine_param))
     {
	require_initialization_114_engine_param = BBOOL(((bool_t) 0));
	library_modules_init_112_engine_param();
	cnst_init_137_engine_param();
	imported_modules_init_94_engine_param();
	eval_init_57_engine_param();
	toplevel_init_63_engine_param();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_engine_param()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "ENGINE_PARAM");
   module_initialization_70___eval(((long) 0), "ENGINE_PARAM");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "ENGINE_PARAM");
   module_initialization_70___os(((long) 0), "ENGINE_PARAM");
   module_initialization_70___evenv(((long) 0), "ENGINE_PARAM");
   module_initialization_70___r4_strings_6_7(((long) 0), "ENGINE_PARAM");
   module_initialization_70___reader(((long) 0), "ENGINE_PARAM");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_engine_param()
{
   {
      obj_t cnst_port_138_950;
      cnst_port_138_950 = open_input_string(string1603_engine_param);
      {
	 long i_951;
	 i_951 = ((long) 113);
       loop_952:
	 {
	    bool_t test1604_953;
	    test1604_953 = (i_951 == ((long) -1));
	    if (test1604_953)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1605_954;
		    {
		       obj_t list1606_955;
		       {
			  obj_t arg1607_956;
			  arg1607_956 = BNIL;
			  list1606_955 = MAKE_PAIR(cnst_port_138_950, arg1607_956);
		       }
		       arg1605_954 = read___reader(list1606_955);
		    }
		    CNST_TABLE_SET(i_951, arg1605_954);
		 }
		 {
		    int aux_957;
		    {
		       long aux_981;
		       aux_981 = (i_951 - ((long) 1));
		       aux_957 = (int) (aux_981);
		    }
		    {
		       long i_984;
		       i_984 = (long) (aux_957);
		       i_951 = i_984;
		       goto loop_952;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_engine_param()
{
   _bigloo_variables__214_engine_param = BNIL;
   _bigloo_version__168_engine_param = string1492_engine_param;
   {
      obj_t arg1417_292;
      {
	 obj_t aux_986;
	 aux_986 = CNST_TABLE_REF(((long) 0));
	 arg1417_292 = MAKE_PAIR(aux_986, string1493_engine_param);
      }
      {
	 obj_t obj2_296;
	 obj2_296 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_292, obj2_296);
      }
   }
   {
      obj_t list1005_6;
      {
	 obj_t arg1007_8;
	 {
	    obj_t arg1008_9;
	    arg1008_9 = MAKE_PAIR(string1494_engine_param, BNIL);
	    arg1007_8 = MAKE_PAIR(_bigloo_version__168_engine_param, arg1008_9);
	 }
	 list1005_6 = MAKE_PAIR(string1495_engine_param, arg1007_8);
      }
      _bigloo_name__170_engine_param = string_append_106___r4_strings_6_7(list1005_6);
   }
   {
      obj_t arg1417_299;
      {
	 obj_t aux_994;
	 aux_994 = CNST_TABLE_REF(((long) 1));
	 arg1417_299 = MAKE_PAIR(aux_994, string1496_engine_param);
      }
      {
	 obj_t obj2_303;
	 obj2_303 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_299, obj2_303);
      }
   }
   _bigloo_level__187_engine_param = BCHAR(((unsigned char) 'a'));
   {
      obj_t arg1417_306;
      {
	 obj_t aux_999;
	 aux_999 = CNST_TABLE_REF(((long) 2));
	 arg1417_306 = MAKE_PAIR(aux_999, string1497_engine_param);
      }
      {
	 obj_t obj2_310;
	 obj2_310 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_306, obj2_310);
      }
   }
   _bigloo_cmd_name__60_engine_param = CNST_TABLE_REF(((long) 3));
   _bigloo_args__103_engine_param = CNST_TABLE_REF(((long) 3));
   _rest_args__8_engine_param = BNIL;
   _bigloo_author__68_engine_param = string1498_engine_param;
   _bigloo_email__0_engine_param = string1499_engine_param;
   _bigloo_date__70_engine_param = bigloo_date_110_tools_date();
   {
      obj_t venv_16;
      {
	 bool_t test1190_312;
	 test1190_312 = (long) getenv("TMPDIR");
	 if (test1190_312)
	   {
	      char *aux_1008;
	      aux_1008 = (char *) getenv("TMPDIR");
	      venv_16 = string_to_bstring(aux_1008);
	   }
	 else
	   {
	      venv_16 = BFALSE;
	   }
      }
      if (STRINGP(venv_16))
	{
	   _bigloo_tmp__142_engine_param = venv_16;
	}
      else
	{
	   _bigloo_tmp__142_engine_param = PROCEDURE_ENTRY(os_tmp_175___os) (os_tmp_175___os, BEOA);
	}
   }
   {
      obj_t arg1417_316;
      {
	 obj_t aux_1015;
	 aux_1015 = CNST_TABLE_REF(((long) 4));
	 arg1417_316 = MAKE_PAIR(aux_1015, string1500_engine_param);
      }
      {
	 obj_t obj2_320;
	 obj2_320 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_316, obj2_320);
      }
   }
   _bigloo_licensing___64_engine_param = BFALSE;
   {
      obj_t arg1417_323;
      {
	 obj_t aux_1019;
	 aux_1019 = CNST_TABLE_REF(((long) 5));
	 arg1417_323 = MAKE_PAIR(aux_1019, string1501_engine_param);
      }
      {
	 obj_t obj2_327;
	 obj2_327 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_323, obj2_327);
      }
   }
   _verbose__1_engine_param = BINT(((long) 0));
   {
      obj_t arg1417_330;
      {
	 obj_t aux_1024;
	 aux_1024 = CNST_TABLE_REF(((long) 6));
	 arg1417_330 = MAKE_PAIR(aux_1024, string1502_engine_param);
      }
      {
	 obj_t obj2_334;
	 obj2_334 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_330, obj2_334);
      }
   }
   _hello__249_engine_param = BTRUE;
   {
      obj_t arg1417_337;
      {
	 obj_t aux_1028;
	 aux_1028 = CNST_TABLE_REF(((long) 7));
	 arg1417_337 = MAKE_PAIR(aux_1028, string1503_engine_param);
      }
      {
	 obj_t obj2_341;
	 obj2_341 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_337, obj2_341);
      }
   }
   _src_files__222_engine_param = BNIL;
   {
      obj_t arg1417_344;
      {
	 obj_t aux_1032;
	 aux_1032 = CNST_TABLE_REF(((long) 8));
	 arg1417_344 = MAKE_PAIR(aux_1032, string1504_engine_param);
      }
      {
	 obj_t obj2_348;
	 obj2_348 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_344, obj2_348);
      }
   }
   _tmp_dest__132_engine_param = BFALSE;
   _dest__217_engine_param = BFALSE;
   {
      obj_t arg1417_351;
      {
	 obj_t aux_1036;
	 aux_1036 = CNST_TABLE_REF(((long) 9));
	 arg1417_351 = MAKE_PAIR(aux_1036, string1505_engine_param);
      }
      {
	 obj_t obj2_355;
	 obj2_355 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_351, obj2_355);
      }
   }
   _shell__121_engine_param = string_to_bstring(SHELL);
   {
      obj_t arg1417_358;
      {
	 obj_t aux_1041;
	 aux_1041 = CNST_TABLE_REF(((long) 10));
	 arg1417_358 = MAKE_PAIR(aux_1041, string1506_engine_param);
      }
      {
	 obj_t obj2_362;
	 obj2_362 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_358, obj2_362);
      }
   }
   _cc__215_engine_param = string_to_bstring(C_COMPILER);
   {
      obj_t arg1417_365;
      {
	 obj_t aux_1046;
	 aux_1046 = CNST_TABLE_REF(((long) 11));
	 arg1417_365 = MAKE_PAIR(aux_1046, string1506_engine_param);
      }
      {
	 obj_t obj2_369;
	 obj2_369 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_365, obj2_369);
      }
   }
   _stdc__25_engine_param = BFALSE;
   {
      obj_t arg1417_372;
      {
	 obj_t aux_1050;
	 aux_1050 = CNST_TABLE_REF(((long) 12));
	 arg1417_372 = MAKE_PAIR(aux_1050, string1507_engine_param);
      }
      {
	 obj_t obj2_376;
	 obj2_376 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_372, obj2_376);
      }
   }
   _cc_options__252_engine_param = string1508_engine_param;
   {
      obj_t arg1417_379;
      {
	 obj_t aux_1054;
	 aux_1054 = CNST_TABLE_REF(((long) 13));
	 arg1417_379 = MAKE_PAIR(aux_1054, string1509_engine_param);
      }
      {
	 obj_t obj2_383;
	 obj2_383 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_379, obj2_383);
      }
   }
   _rm_c_files__192_engine_param = BTRUE;
   {
      obj_t arg1417_386;
      {
	 obj_t aux_1058;
	 aux_1058 = CNST_TABLE_REF(((long) 14));
	 arg1417_386 = MAKE_PAIR(aux_1058, string1510_engine_param);
      }
      {
	 obj_t obj2_390;
	 obj2_390 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_386, obj2_390);
      }
   }
   _ld_options__88_engine_param = string1508_engine_param;
   {
      obj_t arg1417_393;
      {
	 obj_t aux_1062;
	 aux_1062 = CNST_TABLE_REF(((long) 15));
	 arg1417_393 = MAKE_PAIR(aux_1062, string1511_engine_param);
      }
      {
	 obj_t obj2_397;
	 obj2_397 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_393, obj2_397);
      }
   }
   _strip__173_engine_param = BTRUE;
   {
      obj_t arg1417_400;
      {
	 obj_t aux_1066;
	 aux_1066 = CNST_TABLE_REF(((long) 16));
	 arg1417_400 = MAKE_PAIR(aux_1066, string1512_engine_param);
      }
      {
	 obj_t obj2_404;
	 obj2_404 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_400, obj2_404);
      }
   }
   _default_lib_dir__128_engine_param = string_to_bstring(LIBRARY_DIRECTORY);
   {
      obj_t arg1417_407;
      {
	 obj_t aux_1071;
	 aux_1071 = CNST_TABLE_REF(((long) 17));
	 arg1417_407 = MAKE_PAIR(aux_1071, string1513_engine_param);
      }
      {
	 obj_t obj2_411;
	 obj2_411 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_407, obj2_411);
      }
   }
   {
      obj_t lib_env_98_46;
      {
	 bool_t test1190_413;
	 test1190_413 = (long) getenv("BIGLOOLIB");
	 if (test1190_413)
	   {
	      char *aux_1077;
	      aux_1077 = (char *) getenv("BIGLOOLIB");
	      lib_env_98_46 = string_to_bstring(aux_1077);
	   }
	 else
	   {
	      lib_env_98_46 = BFALSE;
	   }
      }
      if (STRINGP(lib_env_98_46))
	{
	   obj_t list1165_48;
	   list1165_48 = MAKE_PAIR(lib_env_98_46, BNIL);
	   _lib_dir__34_engine_param = list1165_48;
	}
      else
	{
	   obj_t list1176_50;
	   list1176_50 = MAKE_PAIR(_default_lib_dir__128_engine_param, BNIL);
	   _lib_dir__34_engine_param = list1176_50;
	}
   }
   {
      obj_t arg1417_419;
      {
	 obj_t aux_1084;
	 aux_1084 = CNST_TABLE_REF(((long) 18));
	 arg1417_419 = MAKE_PAIR(aux_1084, string1514_engine_param);
      }
      {
	 obj_t obj2_423;
	 obj2_423 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_419, obj2_423);
      }
   }
   {
      obj_t arg1191_54;
      {
	 obj_t pair_424;
	 pair_424 = _lib_dir__34_engine_param;
	 arg1191_54 = CAR(pair_424);
      }
      _lib_src_dir__208_engine_param = make_file_name_203___os(arg1191_54, string1515_engine_param);
   }
   {
      obj_t arg1417_427;
      {
	 obj_t aux_1090;
	 aux_1090 = CNST_TABLE_REF(((long) 19));
	 arg1417_427 = MAKE_PAIR(aux_1090, string1514_engine_param);
      }
      {
	 obj_t obj2_431;
	 obj2_431 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_427, obj2_431);
      }
   }
   _bigloo_lib_base_name__84_engine_param = string_to_bstring(LIBRARY_BASE_NAME);
   {
      obj_t arg1417_434;
      {
	 obj_t aux_1095;
	 aux_1095 = CNST_TABLE_REF(((long) 20));
	 arg1417_434 = MAKE_PAIR(aux_1095, string1516_engine_param);
      }
      {
	 obj_t obj2_438;
	 obj2_438 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_434, obj2_438);
      }
   }
   {
      obj_t arg1197_60;
      {
	 bool_t test1202_65;
	 {
	    obj_t obj_439;
	    obj_439 = _bigloo_level__187_engine_param;
	    test1202_65 = CHARP(obj_439);
	 }
	 if (test1202_65)
	   {
	      obj_t list1203_66;
	      list1203_66 = MAKE_PAIR(_bigloo_level__187_engine_param, BNIL);
	      {
		 obj_t res1489_446;
		 {
		    unsigned char aux_1106;
		    long aux_1102;
		    {
		       obj_t aux_1107;
		       aux_1107 = CAR(list1203_66);
		       aux_1106 = (unsigned char) CCHAR(aux_1107);
		    }
		    {
		       int aux_1103;
		       aux_1103 = (int) (((long) 1));
		       aux_1102 = (long) (aux_1103);
		    }
		    res1489_446 = make_string(aux_1102, aux_1106);
		 }
		 arg1197_60 = res1489_446;
	      }
	   }
	 else
	   {
	      arg1197_60 = string1508_engine_param;
	   }
      }
      {
	 obj_t list1198_61;
	 {
	    obj_t arg1199_62;
	    {
	       obj_t arg1200_63;
	       arg1200_63 = MAKE_PAIR(arg1197_60, BNIL);
	       arg1199_62 = MAKE_PAIR(_bigloo_version__168_engine_param, arg1200_63);
	    }
	    list1198_61 = MAKE_PAIR(_bigloo_lib_base_name__84_engine_param, arg1199_62);
	 }
	 _bigloo_lib__121_engine_param = string_append_106___r4_strings_6_7(list1198_61);
      }
   }
   {
      obj_t arg1417_449;
      {
	 obj_t aux_1115;
	 aux_1115 = CNST_TABLE_REF(((long) 21));
	 arg1417_449 = MAKE_PAIR(aux_1115, string1517_engine_param);
      }
      {
	 obj_t obj2_453;
	 obj2_453 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_449, obj2_453);
      }
   }
   _gc_lib__201_engine_param = string1518_engine_param;
   {
      obj_t arg1417_456;
      {
	 obj_t aux_1119;
	 aux_1119 = CNST_TABLE_REF(((long) 22));
	 arg1417_456 = MAKE_PAIR(aux_1119, string1519_engine_param);
      }
      {
	 obj_t obj2_460;
	 obj2_460 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_456, obj2_460);
      }
   }
   _static_bigloo___233_engine_param = BFALSE;
   {
      obj_t arg1417_463;
      {
	 obj_t aux_1123;
	 aux_1123 = CNST_TABLE_REF(((long) 23));
	 arg1417_463 = MAKE_PAIR(aux_1123, string1520_engine_param);
      }
      {
	 obj_t obj2_467;
	 obj2_467 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_463, obj2_467);
      }
   }
   {
      obj_t list1212_74;
      {
	 obj_t aux_1127;
	 aux_1127 = string_to_bstring(USER_LIBRARIES);
	 list1212_74 = MAKE_PAIR(aux_1127, BNIL);
      }
      _bigloo_user_lib__33_engine_param = list1212_74;
   }
   {
      obj_t arg1417_471;
      {
	 obj_t aux_1130;
	 aux_1130 = CNST_TABLE_REF(((long) 24));
	 arg1417_471 = MAKE_PAIR(aux_1130, string1521_engine_param);
      }
      {
	 obj_t obj2_475;
	 obj2_475 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_471, obj2_475);
      }
   }
   _additional_bigloo_libraries__50_engine_param = BNIL;
   {
      obj_t arg1417_478;
      {
	 obj_t aux_1134;
	 aux_1134 = CNST_TABLE_REF(((long) 25));
	 arg1417_478 = MAKE_PAIR(aux_1134, string1522_engine_param);
      }
      {
	 obj_t obj2_482;
	 obj2_482 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_478, obj2_482);
      }
   }
   _load_path__54___eval = append_2_18___r4_pairs_and_lists_6_3(_lib_dir__34_engine_param, _load_path__54___eval);
   {
      obj_t arg1221_80;
      {
	 obj_t arg1226_84;
	 {
	    bool_t test1235_91;
	    {
	       obj_t obj_483;
	       obj_483 = _bigloo_level__187_engine_param;
	       test1235_91 = CHARP(obj_483);
	    }
	    if (test1235_91)
	      {
		 obj_t list1236_92;
		 list1236_92 = MAKE_PAIR(_bigloo_level__187_engine_param, BNIL);
		 {
		    obj_t res1490_490;
		    {
		       unsigned char aux_1146;
		       long aux_1142;
		       {
			  obj_t aux_1147;
			  aux_1147 = CAR(list1236_92);
			  aux_1146 = (unsigned char) CCHAR(aux_1147);
		       }
		       {
			  int aux_1143;
			  aux_1143 = (int) (((long) 1));
			  aux_1142 = (long) (aux_1143);
		       }
		       res1490_490 = make_string(aux_1142, aux_1146);
		    }
		    arg1226_84 = res1490_490;
		 }
	      }
	    else
	      {
		 arg1226_84 = string1508_engine_param;
	      }
	 }
	 {
	    obj_t list1229_86;
	    {
	       obj_t arg1231_87;
	       {
		  obj_t arg1232_88;
		  {
		     obj_t arg1233_89;
		     arg1233_89 = MAKE_PAIR(string1523_engine_param, BNIL);
		     arg1232_88 = MAKE_PAIR(arg1226_84, arg1233_89);
		  }
		  arg1231_87 = MAKE_PAIR(_bigloo_version__168_engine_param, arg1232_88);
	       }
	       list1229_86 = MAKE_PAIR(string1524_engine_param, arg1231_87);
	    }
	    arg1221_80 = string_append_106___r4_strings_6_7(list1229_86);
	 }
      }
      {
	 obj_t list1222_81;
	 list1222_81 = MAKE_PAIR(arg1221_80, BNIL);
	 _include_foreign__253_engine_param = list1222_81;
      }
   }
   {
      obj_t arg1417_494;
      {
	 obj_t aux_1157;
	 aux_1157 = CNST_TABLE_REF(((long) 26));
	 arg1417_494 = MAKE_PAIR(aux_1157, string1525_engine_param);
      }
      {
	 obj_t obj2_498;
	 obj2_498 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_494, obj2_498);
      }
   }
   _additional_include_foreign__44_engine_param = BNIL;
   {
      obj_t arg1417_501;
      {
	 obj_t aux_1161;
	 aux_1161 = CNST_TABLE_REF(((long) 27));
	 arg1417_501 = MAKE_PAIR(aux_1161, string1526_engine_param);
      }
      {
	 obj_t obj2_505;
	 obj2_505 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_501, obj2_505);
      }
   }
   _heap_base_name__65_engine_param = string1524_engine_param;
   {
      obj_t arg1417_508;
      {
	 obj_t aux_1165;
	 aux_1165 = CNST_TABLE_REF(((long) 28));
	 arg1417_508 = MAKE_PAIR(aux_1165, string1527_engine_param);
      }
      {
	 obj_t obj2_512;
	 obj2_512 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_508, obj2_512);
      }
   }
   {
      obj_t arg1248_100;
      {
	 bool_t test1256_107;
	 {
	    obj_t obj_513;
	    obj_513 = _bigloo_level__187_engine_param;
	    test1256_107 = CHARP(obj_513);
	 }
	 if (test1256_107)
	   {
	      obj_t list1257_108;
	      list1257_108 = MAKE_PAIR(_bigloo_level__187_engine_param, BNIL);
	      {
		 obj_t res1491_520;
		 {
		    unsigned char aux_1176;
		    long aux_1172;
		    {
		       obj_t aux_1177;
		       aux_1177 = CAR(list1257_108);
		       aux_1176 = (unsigned char) CCHAR(aux_1177);
		    }
		    {
		       int aux_1173;
		       aux_1173 = (int) (((long) 1));
		       aux_1172 = (long) (aux_1173);
		    }
		    res1491_520 = make_string(aux_1172, aux_1176);
		 }
		 arg1248_100 = res1491_520;
	      }
	   }
	 else
	   {
	      arg1248_100 = string1508_engine_param;
	   }
      }
      {
	 obj_t list1251_102;
	 {
	    obj_t arg1252_103;
	    {
	       obj_t arg1253_104;
	       {
		  obj_t arg1254_105;
		  arg1254_105 = MAKE_PAIR(string1528_engine_param, BNIL);
		  arg1253_104 = MAKE_PAIR(arg1248_100, arg1254_105);
	       }
	       arg1252_103 = MAKE_PAIR(_bigloo_version__168_engine_param, arg1253_104);
	    }
	    list1251_102 = MAKE_PAIR(_heap_base_name__65_engine_param, arg1252_103);
	 }
	 _heap_name__135_engine_param = string_append_106___r4_strings_6_7(list1251_102);
      }
   }
   {
      obj_t arg1417_523;
      {
	 obj_t aux_1186;
	 aux_1186 = CNST_TABLE_REF(((long) 29));
	 arg1417_523 = MAKE_PAIR(aux_1186, string1529_engine_param);
      }
      {
	 obj_t obj2_527;
	 obj2_527 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_523, obj2_527);
      }
   }
   _additional_heap_name__223_engine_param = BFALSE;
   {
      obj_t arg1417_530;
      {
	 obj_t aux_1190;
	 aux_1190 = CNST_TABLE_REF(((long) 30));
	 arg1417_530 = MAKE_PAIR(aux_1190, string1530_engine_param);
      }
      {
	 obj_t obj2_534;
	 obj2_534 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_530, obj2_534);
      }
   }
   _additional_heap_names__104_engine_param = BNIL;
   {
      obj_t arg1417_537;
      {
	 obj_t aux_1194;
	 aux_1194 = CNST_TABLE_REF(((long) 31));
	 arg1417_537 = MAKE_PAIR(aux_1194, string1531_engine_param);
      }
      {
	 obj_t obj2_541;
	 obj2_541 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_537, obj2_541);
      }
   }
   _indent__220_engine_param = string_to_bstring(C_BEAUTIFIER);
   {
      obj_t arg1417_544;
      {
	 obj_t aux_1199;
	 aux_1199 = CNST_TABLE_REF(((long) 32));
	 arg1417_544 = MAKE_PAIR(aux_1199, string1532_engine_param);
      }
      {
	 obj_t obj2_548;
	 obj2_548 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_544, obj2_548);
      }
   }
   _compiler_debug__134_engine_param = BINT(((long) 0));
   {
      obj_t arg1417_551;
      {
	 obj_t aux_1204;
	 aux_1204 = CNST_TABLE_REF(((long) 33));
	 arg1417_551 = MAKE_PAIR(aux_1204, string1533_engine_param);
      }
      {
	 obj_t obj2_555;
	 obj2_555 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_551, obj2_555);
      }
   }
   _c_debug__136_engine_param = BFALSE;
   {
      obj_t arg1417_558;
      {
	 obj_t aux_1208;
	 aux_1208 = CNST_TABLE_REF(((long) 34));
	 arg1417_558 = MAKE_PAIR(aux_1208, string1534_engine_param);
      }
      {
	 obj_t obj2_562;
	 obj2_562 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_558, obj2_562);
      }
   }
   _c_debug_option__198_engine_param = string1535_engine_param;
   {
      obj_t arg1417_565;
      {
	 obj_t aux_1212;
	 aux_1212 = CNST_TABLE_REF(((long) 35));
	 arg1417_565 = MAKE_PAIR(aux_1212, string1536_engine_param);
      }
      {
	 obj_t obj2_569;
	 obj2_569 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_565, obj2_569);
      }
   }
   _bdb_debug__1_engine_param = BINT(((long) 0));
   {
      obj_t arg1417_572;
      {
	 obj_t aux_1217;
	 aux_1217 = CNST_TABLE_REF(((long) 36));
	 arg1417_572 = MAKE_PAIR(aux_1217, string1537_engine_param);
      }
      {
	 obj_t obj2_576;
	 obj2_576 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_572, obj2_576);
      }
   }
   _profile_mode__105_engine_param = BINT(((long) 0));
   {
      obj_t arg1417_579;
      {
	 obj_t aux_1222;
	 aux_1222 = CNST_TABLE_REF(((long) 37));
	 arg1417_579 = MAKE_PAIR(aux_1222, string1538_engine_param);
      }
      {
	 obj_t obj2_583;
	 obj2_583 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_579, obj2_583);
      }
   }
   _prof_table_name__107_engine_param = string1539_engine_param;
   {
      obj_t arg1417_586;
      {
	 obj_t aux_1226;
	 aux_1226 = CNST_TABLE_REF(((long) 38));
	 arg1417_586 = MAKE_PAIR(aux_1226, string1540_engine_param);
      }
      {
	 obj_t obj2_590;
	 obj2_590 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_586, obj2_590);
      }
   }
   _access_file__194_engine_param = BFALSE;
   {
      obj_t arg1417_593;
      {
	 obj_t aux_1230;
	 aux_1230 = CNST_TABLE_REF(((long) 39));
	 arg1417_593 = MAKE_PAIR(aux_1230, string1541_engine_param);
      }
      {
	 obj_t obj2_597;
	 obj2_597 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_593, obj2_597);
      }
   }
   _access_table__91_engine_param = BNIL;
   _o_files__27_engine_param = BNIL;
   {
      obj_t arg1417_600;
      {
	 obj_t aux_1234;
	 aux_1234 = CNST_TABLE_REF(((long) 40));
	 arg1417_600 = MAKE_PAIR(aux_1234, string1542_engine_param);
      }
      {
	 obj_t obj2_604;
	 obj2_604 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_600, obj2_604);
      }
   }
   _with_files__6_engine_param = BNIL;
   {
      obj_t arg1417_607;
      {
	 obj_t aux_1238;
	 aux_1238 = CNST_TABLE_REF(((long) 41));
	 arg1417_607 = MAKE_PAIR(aux_1238, string1543_engine_param);
      }
      {
	 obj_t obj2_611;
	 obj2_611 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_607, obj2_611);
      }
   }
   _interpreter__140_engine_param = BFALSE;
   {
      obj_t arg1417_614;
      {
	 obj_t aux_1242;
	 aux_1242 = CNST_TABLE_REF(((long) 42));
	 arg1417_614 = MAKE_PAIR(aux_1242, string1544_engine_param);
      }
      {
	 obj_t obj2_618;
	 obj2_618 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_614, obj2_618);
      }
   }
   _startup_file__78_engine_param = BFALSE;
   {
      obj_t arg1417_621;
      {
	 obj_t aux_1246;
	 aux_1246 = CNST_TABLE_REF(((long) 43));
	 arg1417_621 = MAKE_PAIR(aux_1246, string1545_engine_param);
      }
      {
	 obj_t obj2_625;
	 obj2_625 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_621, obj2_625);
      }
   }
   _call_cc___102_engine_param = BFALSE;
   {
      obj_t arg1417_628;
      {
	 obj_t aux_1250;
	 aux_1250 = CNST_TABLE_REF(((long) 44));
	 arg1417_628 = MAKE_PAIR(aux_1250, string1546_engine_param);
      }
      {
	 obj_t obj2_632;
	 obj2_632 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_628, obj2_632);
      }
   }
   _reflection___104_engine_param = BTRUE;
   {
      obj_t arg1417_635;
      {
	 obj_t aux_1254;
	 aux_1254 = CNST_TABLE_REF(((long) 45));
	 arg1417_635 = MAKE_PAIR(aux_1254, string1547_engine_param);
      }
      {
	 obj_t obj2_639;
	 obj2_639 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_635, obj2_639);
      }
   }
   _pass__125_engine_param = CNST_TABLE_REF(((long) 46));
   {
      obj_t arg1417_642;
      {
	 obj_t aux_1259;
	 aux_1259 = CNST_TABLE_REF(((long) 47));
	 arg1417_642 = MAKE_PAIR(aux_1259, string1548_engine_param);
      }
      {
	 obj_t obj2_646;
	 obj2_646 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_642, obj2_646);
      }
   }
   _module_checksum_object___74_engine_param = BFALSE;
   {
      obj_t arg1417_649;
      {
	 obj_t aux_1263;
	 aux_1263 = CNST_TABLE_REF(((long) 48));
	 arg1417_649 = MAKE_PAIR(aux_1263, string1549_engine_param);
      }
      {
	 obj_t obj2_653;
	 obj2_653 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_649, obj2_653);
      }
   }
   _garbage_collector__95_engine_param = CNST_TABLE_REF(((long) 49));
   {
      obj_t arg1417_656;
      {
	 obj_t aux_1268;
	 aux_1268 = CNST_TABLE_REF(((long) 50));
	 arg1417_656 = MAKE_PAIR(aux_1268, string1550_engine_param);
      }
      {
	 obj_t obj2_660;
	 obj2_660 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_656, obj2_660);
      }
   }
   _unsafe_type__146_engine_param = BFALSE;
   {
      obj_t arg1417_663;
      {
	 obj_t aux_1272;
	 aux_1272 = CNST_TABLE_REF(((long) 51));
	 arg1417_663 = MAKE_PAIR(aux_1272, string1551_engine_param);
      }
      {
	 obj_t obj2_667;
	 obj2_667 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_663, obj2_667);
      }
   }
   _unsafe_arity__240_engine_param = BFALSE;
   {
      obj_t arg1417_670;
      {
	 obj_t aux_1276;
	 aux_1276 = CNST_TABLE_REF(((long) 52));
	 arg1417_670 = MAKE_PAIR(aux_1276, string1552_engine_param);
      }
      {
	 obj_t obj2_674;
	 obj2_674 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_670, obj2_674);
      }
   }
   _unsafe_range__218_engine_param = BFALSE;
   {
      obj_t arg1417_677;
      {
	 obj_t aux_1280;
	 aux_1280 = CNST_TABLE_REF(((long) 53));
	 arg1417_677 = MAKE_PAIR(aux_1280, string1553_engine_param);
      }
      {
	 obj_t obj2_681;
	 obj2_681 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_677, obj2_681);
      }
   }
   _unsafe_struct__195_engine_param = BFALSE;
   {
      obj_t arg1417_684;
      {
	 obj_t aux_1284;
	 aux_1284 = CNST_TABLE_REF(((long) 54));
	 arg1417_684 = MAKE_PAIR(aux_1284, string1554_engine_param);
      }
      {
	 obj_t obj2_688;
	 obj2_688 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_684, obj2_688);
      }
   }
   _unsafe_version__81_engine_param = BFALSE;
   {
      obj_t arg1417_691;
      {
	 obj_t aux_1288;
	 aux_1288 = CNST_TABLE_REF(((long) 55));
	 arg1417_691 = MAKE_PAIR(aux_1288, string1555_engine_param);
      }
      {
	 obj_t obj2_695;
	 obj2_695 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_691, obj2_695);
      }
   }
   _unsafe_library__118_engine_param = BFALSE;
   {
      obj_t arg1417_698;
      {
	 obj_t aux_1292;
	 aux_1292 = CNST_TABLE_REF(((long) 56));
	 arg1417_698 = MAKE_PAIR(aux_1292, string1556_engine_param);
      }
      {
	 obj_t obj2_702;
	 obj2_702 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_698, obj2_702);
      }
   }
   _profile_library__193_engine_param = BFALSE;
   {
      obj_t arg1417_705;
      {
	 obj_t aux_1296;
	 aux_1296 = CNST_TABLE_REF(((long) 57));
	 arg1417_705 = MAKE_PAIR(aux_1296, string1557_engine_param);
      }
      {
	 obj_t obj2_709;
	 obj2_709 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_705, obj2_709);
      }
   }
   _module_shape___145_engine_param = BFALSE;
   _key_shape___172_engine_param = BFALSE;
   _type_shape___78_engine_param = BFALSE;
   _access_shape___50_engine_param = BFALSE;
   _location_shape___48_engine_param = BFALSE;
   _user_shape___227_engine_param = BFALSE;
   _max_stack_alloc_size__239_engine_param = BFALSE;
   {
      obj_t arg1417_712;
      {
	 obj_t aux_1300;
	 aux_1300 = CNST_TABLE_REF(((long) 58));
	 arg1417_712 = MAKE_PAIR(aux_1300, string1558_engine_param);
      }
      {
	 obj_t obj2_716;
	 obj2_716 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_712, obj2_716);
      }
   }
   _genericity__47_engine_param = BTRUE;
   _shared_cnst___67_engine_param = BTRUE;
   {
      obj_t arg1417_719;
      {
	 obj_t aux_1304;
	 aux_1304 = CNST_TABLE_REF(((long) 59));
	 arg1417_719 = MAKE_PAIR(aux_1304, string1559_engine_param);
      }
      {
	 obj_t obj2_723;
	 obj2_723 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_719, obj2_723);
      }
   }
   _lib_mode__85_engine_param = BFALSE;
   {
      obj_t arg1417_726;
      {
	 obj_t aux_1308;
	 aux_1308 = CNST_TABLE_REF(((long) 60));
	 arg1417_726 = MAKE_PAIR(aux_1308, string1560_engine_param);
      }
      {
	 obj_t obj2_730;
	 obj2_730 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_726, obj2_730);
      }
   }
   _init_mode__183_engine_param = CNST_TABLE_REF(((long) 61));
   {
      obj_t arg1417_733;
      {
	 obj_t aux_1313;
	 aux_1313 = CNST_TABLE_REF(((long) 62));
	 arg1417_733 = MAKE_PAIR(aux_1313, string1561_engine_param);
      }
      {
	 obj_t obj2_737;
	 obj2_737 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_733, obj2_737);
      }
   }
   _max_c_token_length__129_engine_param = BINT(((long) 1024));
   {
      obj_t arg1417_740;
      {
	 obj_t aux_1318;
	 aux_1318 = CNST_TABLE_REF(((long) 63));
	 arg1417_740 = MAKE_PAIR(aux_1318, string1562_engine_param);
      }
      {
	 obj_t obj2_744;
	 obj2_744 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_740, obj2_744);
      }
   }
   _max_c_foreign_arity__143_engine_param = BINT(((long) 16));
   {
      obj_t arg1417_747;
      {
	 obj_t aux_1323;
	 aux_1323 = CNST_TABLE_REF(((long) 64));
	 arg1417_747 = MAKE_PAIR(aux_1323, string1563_engine_param);
      }
      {
	 obj_t obj2_751;
	 obj2_751 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_747, obj2_751);
      }
   }
   _trace_name__101_engine_param = string1564_engine_param;
   {
      obj_t arg1417_754;
      {
	 obj_t aux_1327;
	 aux_1327 = CNST_TABLE_REF(((long) 65));
	 arg1417_754 = MAKE_PAIR(aux_1327, string1565_engine_param);
      }
      {
	 obj_t obj2_758;
	 obj2_758 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_754, obj2_758);
      }
   }
   _trace_write_length__146_engine_param = BINT(((long) 80));
   {
      obj_t arg1417_761;
      {
	 obj_t aux_1332;
	 aux_1332 = CNST_TABLE_REF(((long) 66));
	 arg1417_761 = MAKE_PAIR(aux_1332, string1566_engine_param);
      }
      {
	 obj_t obj2_765;
	 obj2_765 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_761, obj2_765);
      }
   }
   _additional_traces__2_engine_param = BNIL;
   _optim__89_engine_param = BINT(((long) 0));
   {
      obj_t arg1417_768;
      {
	 obj_t aux_1337;
	 aux_1337 = CNST_TABLE_REF(((long) 67));
	 arg1417_768 = MAKE_PAIR(aux_1337, string1567_engine_param);
      }
      {
	 obj_t obj2_772;
	 obj2_772 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_768, obj2_772);
      }
   }
   _optim_stack___57_engine_param = BUNSPEC;
   {
      obj_t arg1417_775;
      {
	 obj_t aux_1341;
	 aux_1341 = CNST_TABLE_REF(((long) 68));
	 arg1417_775 = MAKE_PAIR(aux_1341, string1568_engine_param);
      }
      {
	 obj_t obj2_779;
	 obj2_779 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_775, obj2_779);
      }
   }
   _optim_inline_method___30_engine_param = BUNSPEC;
   {
      obj_t arg1417_782;
      {
	 obj_t aux_1345;
	 aux_1345 = CNST_TABLE_REF(((long) 69));
	 arg1417_782 = MAKE_PAIR(aux_1345, string1569_engine_param);
      }
      {
	 obj_t obj2_786;
	 obj2_786 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_782, obj2_786);
      }
   }
   _optim_unroll_loop___80_engine_param = BUNSPEC;
   {
      obj_t arg1417_789;
      {
	 obj_t aux_1349;
	 aux_1349 = CNST_TABLE_REF(((long) 70));
	 arg1417_789 = MAKE_PAIR(aux_1349, string1570_engine_param);
      }
      {
	 obj_t obj2_793;
	 obj2_793 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_789, obj2_793);
      }
   }
   _optim_loop_inlining___30_engine_param = BTRUE;
   {
      obj_t arg1417_796;
      {
	 obj_t aux_1353;
	 aux_1353 = CNST_TABLE_REF(((long) 71));
	 arg1417_796 = MAKE_PAIR(aux_1353, string1571_engine_param);
      }
      {
	 obj_t obj2_800;
	 obj2_800 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_796, obj2_800);
      }
   }
   _optim_o_macro___96_engine_param = BTRUE;
   {
      obj_t arg1417_803;
      {
	 obj_t aux_1357;
	 aux_1357 = CNST_TABLE_REF(((long) 72));
	 arg1417_803 = MAKE_PAIR(aux_1357, string1572_engine_param);
      }
      {
	 obj_t obj2_807;
	 obj2_807 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_803, obj2_807);
      }
   }
   _inlining___224_engine_param = BTRUE;
   {
      obj_t arg1417_810;
      {
	 obj_t aux_1361;
	 aux_1361 = CNST_TABLE_REF(((long) 73));
	 arg1417_810 = MAKE_PAIR(aux_1361, string1573_engine_param);
      }
      {
	 obj_t obj2_814;
	 obj2_814 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_810, obj2_814);
      }
   }
   {
      obj_t lambda1377_939;
      lambda1377_939 = proc1574_engine_param;
      _inlining_kfactor__130_engine_param = lambda1377_939;
   }
   {
      obj_t arg1417_819;
      {
	 obj_t aux_1365;
	 aux_1365 = CNST_TABLE_REF(((long) 74));
	 arg1417_819 = MAKE_PAIR(aux_1365, string1575_engine_param);
      }
      {
	 obj_t obj2_823;
	 obj2_823 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_819, obj2_823);
      }
   }
   {
      obj_t lambda1380_938;
      lambda1380_938 = proc1576_engine_param;
      _inlining_reduce_kfactor__26_engine_param = lambda1380_938;
   }
   {
      obj_t arg1417_828;
      {
	 obj_t aux_1369;
	 aux_1369 = CNST_TABLE_REF(((long) 75));
	 arg1417_828 = MAKE_PAIR(aux_1369, string1577_engine_param);
      }
      {
	 obj_t obj2_832;
	 obj2_832 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_828, obj2_832);
      }
   }
   _extend_entry__7_engine_param = BFALSE;
   {
      obj_t arg1417_835;
      {
	 obj_t aux_1373;
	 aux_1373 = CNST_TABLE_REF(((long) 76));
	 arg1417_835 = MAKE_PAIR(aux_1373, string1578_engine_param);
      }
      {
	 obj_t obj2_839;
	 obj2_839 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_835, obj2_839);
      }
   }
   _src_suffix__192_engine_param = CNST_TABLE_REF(((long) 77));
   {
      obj_t arg1417_842;
      {
	 obj_t aux_1378;
	 aux_1378 = CNST_TABLE_REF(((long) 78));
	 arg1417_842 = MAKE_PAIR(aux_1378, string1579_engine_param);
      }
      {
	 obj_t obj2_846;
	 obj2_846 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_842, obj2_846);
      }
   }
   _obj_suffix__189_engine_param = CNST_TABLE_REF(((long) 79));
   {
      obj_t arg1417_849;
      {
	 obj_t aux_1383;
	 aux_1383 = CNST_TABLE_REF(((long) 80));
	 arg1417_849 = MAKE_PAIR(aux_1383, string1580_engine_param);
      }
      {
	 obj_t obj2_853;
	 obj2_853 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_849, obj2_853);
      }
   }
   _mco_suffix__47_engine_param = CNST_TABLE_REF(((long) 81));
   {
      obj_t arg1417_856;
      {
	 obj_t aux_1388;
	 aux_1388 = CNST_TABLE_REF(((long) 82));
	 arg1417_856 = MAKE_PAIR(aux_1388, string1581_engine_param);
      }
      {
	 obj_t obj2_860;
	 obj2_860 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_856, obj2_860);
      }
   }
   _auto_mode__185_engine_param = CNST_TABLE_REF(((long) 83));
   {
      obj_t arg1417_863;
      {
	 obj_t aux_1393;
	 aux_1393 = CNST_TABLE_REF(((long) 84));
	 arg1417_863 = MAKE_PAIR(aux_1393, string1582_engine_param);
      }
      {
	 obj_t obj2_867;
	 obj2_867 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_863, obj2_867);
      }
   }
   _case_sensitive__90_engine_param = BFALSE;
   {
      obj_t arg1417_870;
      {
	 obj_t aux_1397;
	 aux_1397 = CNST_TABLE_REF(((long) 85));
	 arg1417_870 = MAKE_PAIR(aux_1397, string1583_engine_param);
      }
      {
	 obj_t obj2_874;
	 obj2_874 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_870, obj2_874);
      }
   }
   _user_heap_size__225_engine_param = BFALSE;
   {
      obj_t arg1417_877;
      {
	 obj_t aux_1401;
	 aux_1401 = CNST_TABLE_REF(((long) 86));
	 arg1417_877 = MAKE_PAIR(aux_1401, string1584_engine_param);
      }
      {
	 obj_t obj2_881;
	 obj2_881 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_877, obj2_881);
      }
   }
   _reader__83_engine_param = CNST_TABLE_REF(((long) 87));
   {
      obj_t arg1417_884;
      {
	 obj_t aux_1406;
	 aux_1406 = CNST_TABLE_REF(((long) 88));
	 arg1417_884 = MAKE_PAIR(aux_1406, string1585_engine_param);
      }
      {
	 obj_t obj2_888;
	 obj2_888 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_884, obj2_888);
      }
   }
   {
      obj_t arg1417_891;
      {
	 obj_t aux_1410;
	 aux_1410 = CNST_TABLE_REF(((long) 89));
	 arg1417_891 = MAKE_PAIR(aux_1410, string1586_engine_param);
      }
      {
	 obj_t obj2_895;
	 obj2_895 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_891, obj2_895);
      }
   }
   {
      obj_t arg1417_898;
      {
	 obj_t aux_1414;
	 aux_1414 = CNST_TABLE_REF(((long) 90));
	 arg1417_898 = MAKE_PAIR(aux_1414, string1587_engine_param);
      }
      {
	 obj_t obj2_902;
	 obj2_902 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_898, obj2_902);
      }
   }
   {
      obj_t arg1417_905;
      {
	 obj_t aux_1418;
	 aux_1418 = CNST_TABLE_REF(((long) 91));
	 arg1417_905 = MAKE_PAIR(aux_1418, string1588_engine_param);
      }
      {
	 obj_t obj2_909;
	 obj2_909 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_905, obj2_909);
      }
   }
   {
      obj_t arg1417_912;
      {
	 obj_t aux_1422;
	 aux_1422 = CNST_TABLE_REF(((long) 92));
	 arg1417_912 = MAKE_PAIR(aux_1422, string1589_engine_param);
      }
      {
	 obj_t obj2_916;
	 obj2_916 = _bigloo_variables__214_engine_param;
	 _bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_912, obj2_916);
      }
   }
   {
      obj_t arg1417_919;
      {
	 obj_t aux_1426;
	 aux_1426 = CNST_TABLE_REF(((long) 93));
	 arg1417_919 = MAKE_PAIR(aux_1426, string1590_engine_param);
      }
      {
	 obj_t obj2_923;
	 obj2_923 = _bigloo_variables__214_engine_param;
	 return (_bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_919, obj2_923),
	    BUNSPEC);
      }
   }
}


/* lambda1380 */ obj_t 
lambda1380_engine_param(obj_t env_940, obj_t kfactor_941)
{
   {
      obj_t kfactor_198;
      {
	 long aux_1430;
	 kfactor_198 = kfactor_941;
	 {
	    long aux_1431;
	    aux_1431 = (long) CINT(kfactor_198);
	    aux_1430 = (aux_1431 / ((long) 2));
	 }
	 return BINT(aux_1430);
      }
   }
}


/* lambda1377 */ obj_t 
lambda1377_engine_param(obj_t env_942, obj_t olevel_943)
{
   {
      obj_t olevel_194;
      {
	 long aux_1435;
	 olevel_194 = olevel_943;
	 {
	    long aux_1436;
	    aux_1436 = (long) CINT(olevel_194);
	    aux_1435 = (((long) 2) * aux_1436);
	 }
	 return BINT(aux_1435);
      }
   }
}


/* add-doc-variable! */ obj_t 
add_doc_variable__44_engine_param(obj_t id_1, obj_t doc_2)
{
   {
      obj_t arg1417_924;
      arg1417_924 = MAKE_PAIR(id_1, doc_2);
      {
	 obj_t obj2_928;
	 obj2_928 = _bigloo_variables__214_engine_param;
	 return (_bigloo_variables__214_engine_param = MAKE_PAIR(arg1417_924, obj2_928),
	    BUNSPEC);
      }
   }
}


/* _add-doc-variable! */ obj_t 
_add_doc_variable__66_engine_param(obj_t env_944, obj_t id_945, obj_t doc_946)
{
   return add_doc_variable__44_engine_param(id_945, doc_946);
}


/* bigloo-variables-usage */ obj_t 
bigloo_variables_usage_232_engine_param(bool_t manual__151_3)
{
   {
      obj_t list1418_229;
      list1418_229 = MAKE_PAIR(string1591_engine_param, BNIL);
      print___r4_output_6_10_3(list1418_229);
   }
   {
      obj_t list1422_232;
      list1422_232 = MAKE_PAIR(string1592_engine_param, BNIL);
      print___r4_output_6_10_3(list1422_232);
   }
   {
      obj_t list1427_235;
      list1427_235 = MAKE_PAIR(string1593_engine_param, BNIL);
      print___r4_output_6_10_3(list1427_235);
   }
   {
      obj_t list1432_238;
      list1432_238 = MAKE_PAIR(string1594_engine_param, BNIL);
      print___r4_output_6_10_3(list1432_238);
   }
   {
      obj_t list1437_241;
      list1437_241 = MAKE_PAIR(string1595_engine_param, BNIL);
      print___r4_output_6_10_3(list1437_241);
   }
   {
      obj_t list1441_244;
      list1441_244 = MAKE_PAIR(string1596_engine_param, BNIL);
      print___r4_output_6_10_3(list1441_244);
   }
   newline___r4_output_6_10_3(BNIL);
   {
      obj_t l_248;
      {
	 obj_t arg1446_250;
	 arg1446_250 = reverse___r4_pairs_and_lists_6_3(_bigloo_variables__214_engine_param);
	 l_248 = arg1446_250;
       loop_249:
	 if (PAIRP(l_248))
	   {
	      obj_t var_252;
	      var_252 = CAR(l_248);
	      if (manual__151_3)
		{
		   {
		      obj_t arg1449_254;
		      arg1449_254 = CAR(var_252);
		      {
			 obj_t list1451_256;
			 {
			    obj_t arg1453_257;
			    {
			       obj_t arg1454_258;
			       arg1454_258 = MAKE_PAIR(string1597_engine_param, BNIL);
			       arg1453_257 = MAKE_PAIR(arg1449_254, arg1454_258);
			    }
			    list1451_256 = MAKE_PAIR(string1598_engine_param, arg1453_257);
			 }
			 print___r4_output_6_10_3(list1451_256);
		      }
		   }
		   {
		      obj_t list1459_262;
		      {
			 obj_t arg1460_263;
			 {
			    obj_t aux_1466;
			    aux_1466 = CDR(var_252);
			    arg1460_263 = MAKE_PAIR(aux_1466, BNIL);
			 }
			 list1459_262 = MAKE_PAIR(string1599_engine_param, arg1460_263);
		      }
		      print___r4_output_6_10_3(list1459_262);
		   }
		   display___r4_output_6_10_3(string1600_engine_param, BNIL);
		   {
		      obj_t arg1463_266;
		      arg1463_266 = eval___eval(CAR(var_252), BNIL);
		      write___r4_output_6_10_3(arg1463_266, BNIL);
		   }
		   newline___r4_output_6_10_3(BNIL);
		}
	      else
		{
		   {
		      obj_t arg1469_272;
		      obj_t arg1471_274;
		      arg1469_272 = CAR(var_252);
		      arg1471_274 = CDR(var_252);
		      {
			 obj_t list1474_276;
			 {
			    obj_t arg1475_277;
			    {
			       obj_t arg1476_278;
			       {
				  obj_t arg1477_279;
				  {
				     obj_t arg1478_280;
				     arg1478_280 = MAKE_PAIR(string1601_engine_param, BNIL);
				     arg1477_279 = MAKE_PAIR(arg1471_274, arg1478_280);
				  }
				  arg1476_278 = MAKE_PAIR(string1597_engine_param, arg1477_279);
			       }
			       arg1475_277 = MAKE_PAIR(arg1469_272, arg1476_278);
			    }
			    list1474_276 = MAKE_PAIR(string1598_engine_param, arg1475_277);
			 }
			 display__75___r4_output_6_10_3(list1474_276);
		      }
		   }
		   {
		      obj_t arg1480_282;
		      arg1480_282 = eval___eval(CAR(var_252), BNIL);
		      write___r4_output_6_10_3(arg1480_282, BNIL);
		   }
		   {
		      obj_t list1485_286;
		      list1485_286 = MAKE_PAIR(string1602_engine_param, BNIL);
		      print___r4_output_6_10_3(list1485_286);
		   }
		}
	      {
		 obj_t l_1489;
		 l_1489 = CDR(l_248);
		 l_248 = l_1489;
		 goto loop_249;
	      }
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* _bigloo-variables-usage */ obj_t 
_bigloo_variables_usage_193_engine_param(obj_t env_947, obj_t manual__151_948)
{
   return bigloo_variables_usage_232_engine_param(CBOOL(manual__151_948));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_engine_param()
{
   return module_initialization_70_tools_date(((long) 0), "ENGINE_PARAM");
}


/* eval-init */ obj_t 
eval_init_57_engine_param()
{
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 76)), __EVMEANING_ADDRESS(_extend_entry__7_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 32)), __EVMEANING_ADDRESS(_indent__220_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 47)), __EVMEANING_ADDRESS(_pass__125_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 80)), __EVMEANING_ADDRESS(_obj_suffix__189_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 78)), __EVMEANING_ADDRESS(_src_suffix__192_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 31)), __EVMEANING_ADDRESS(_additional_heap_names__104_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 7)), __EVMEANING_ADDRESS(_hello__249_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 94)), __EVMEANING_ADDRESS(_bigloo_email__0_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 60)), __EVMEANING_ADDRESS(_lib_mode__85_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 50)), __EVMEANING_ADDRESS(_garbage_collector__95_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 34)), __EVMEANING_ADDRESS(_c_debug__136_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 95)), __EVMEANING_ADDRESS(_user_shape___227_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 4)), __EVMEANING_ADDRESS(_bigloo_tmp__142_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 15)), __EVMEANING_ADDRESS(_ld_options__88_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 96)), __EVMEANING_ADDRESS(_bigloo_cmd_name__60_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 37)), __EVMEANING_ADDRESS(_profile_mode__105_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 53)), __EVMEANING_ADDRESS(_unsafe_range__218_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 97)), __EVMEANING_ADDRESS(_bigloo_variables__214_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 98)), __EVMEANING_ADDRESS(_tmp_dest__132_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 43)), __EVMEANING_ADDRESS(_startup_file__78_engine_param));
   define_primop__185___evenv(CNST_TABLE_REF(((long) 99)), bigloo_variables_usage_env_96_engine_param);
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 1)), __EVMEANING_ADDRESS(_bigloo_name__170_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 10)), __EVMEANING_ADDRESS(_shell__121_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 22)), __EVMEANING_ADDRESS(_gc_lib__201_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 30)), __EVMEANING_ADDRESS(_additional_heap_name__223_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 71)), __EVMEANING_ADDRESS(_optim_loop_inlining___30_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 66)), __EVMEANING_ADDRESS(_trace_write_length__146_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 26)), __EVMEANING_ADDRESS(_include_foreign__253_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 23)), __EVMEANING_ADDRESS(_static_bigloo___233_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 33)), __EVMEANING_ADDRESS(_compiler_debug__134_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 100)), __EVMEANING_ADDRESS(_location_shape___48_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 62)), __EVMEANING_ADDRESS(_init_mode__183_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 85)), __EVMEANING_ADDRESS(_case_sensitive__90_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 39)), __EVMEANING_ADDRESS(_access_file__194_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 101)), __EVMEANING_ADDRESS(_bigloo_args__103_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 102)), __EVMEANING_ADDRESS(_bigloo_date__70_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 18)), __EVMEANING_ADDRESS(_lib_dir__34_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 103)), __EVMEANING_ADDRESS(_bigloo_author__68_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 42)), __EVMEANING_ADDRESS(_interpreter__140_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 5)), __EVMEANING_ADDRESS(_bigloo_licensing___64_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 44)), __EVMEANING_ADDRESS(_call_cc___102_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 73)), __EVMEANING_ADDRESS(_inlining___224_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 51)), __EVMEANING_ADDRESS(_unsafe_type__146_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 104)), __EVMEANING_ADDRESS(_key_shape___172_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 40)), __EVMEANING_ADDRESS(_o_files__27_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 68)), __EVMEANING_ADDRESS(_optim_stack___57_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 86)), __EVMEANING_ADDRESS(_user_heap_size__225_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 35)), __EVMEANING_ADDRESS(_c_debug_option__198_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 41)), __EVMEANING_ADDRESS(_with_files__6_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 105)), __EVMEANING_ADDRESS(_rest_args__8_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 69)), __EVMEANING_ADDRESS(_optim_inline_method___30_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 65)), __EVMEANING_ADDRESS(_trace_name__101_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 38)), __EVMEANING_ADDRESS(_prof_table_name__107_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 27)), __EVMEANING_ADDRESS(_additional_include_foreign__44_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 13)), __EVMEANING_ADDRESS(_cc_options__252_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 9)), __EVMEANING_ADDRESS(_dest__217_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 72)), __EVMEANING_ADDRESS(_optim_o_macro___96_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 21)), __EVMEANING_ADDRESS(_bigloo_lib__121_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 106)), __EVMEANING_ADDRESS(_module_shape___145_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 58)), __EVMEANING_ADDRESS(_max_stack_alloc_size__239_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 63)), __EVMEANING_ADDRESS(_max_c_token_length__129_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 55)), __EVMEANING_ADDRESS(_unsafe_version__81_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 19)), __EVMEANING_ADDRESS(_lib_src_dir__208_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 29)), __EVMEANING_ADDRESS(_heap_name__135_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 28)), __EVMEANING_ADDRESS(_heap_base_name__65_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 16)), __EVMEANING_ADDRESS(_strip__173_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 52)), __EVMEANING_ADDRESS(_unsafe_arity__240_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 48)), __EVMEANING_ADDRESS(_module_checksum_object___74_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 17)), __EVMEANING_ADDRESS(_default_lib_dir__128_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 107)), __EVMEANING_ADDRESS(_genericity__47_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 24)), __EVMEANING_ADDRESS(_bigloo_user_lib__33_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 54)), __EVMEANING_ADDRESS(_unsafe_struct__195_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 25)), __EVMEANING_ADDRESS(_additional_bigloo_libraries__50_engine_param));
   define_primop__185___evenv(CNST_TABLE_REF(((long) 108)), bigloo_date_env_128_tools_date);
   define_primop__185___evenv(CNST_TABLE_REF(((long) 109)), add_doc_variable__env_43_engine_param);
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 88)), __EVMEANING_ADDRESS(_reader__83_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 2)), __EVMEANING_ADDRESS(_bigloo_level__187_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 36)), __EVMEANING_ADDRESS(_bdb_debug__1_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 110)), __EVMEANING_ADDRESS(_access_shape___50_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 0)), __EVMEANING_ADDRESS(_bigloo_version__168_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 56)), __EVMEANING_ADDRESS(_unsafe_library__118_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 59)), __EVMEANING_ADDRESS(_shared_cnst___67_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 12)), __EVMEANING_ADDRESS(_stdc__25_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 45)), __EVMEANING_ADDRESS(_reflection___104_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 20)), __EVMEANING_ADDRESS(_bigloo_lib_base_name__84_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 14)), __EVMEANING_ADDRESS(_rm_c_files__192_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 64)), __EVMEANING_ADDRESS(_max_c_foreign_arity__143_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 111)), __EVMEANING_ADDRESS(_type_shape___78_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 6)), __EVMEANING_ADDRESS(_verbose__1_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 74)), __EVMEANING_ADDRESS(_inlining_kfactor__130_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 70)), __EVMEANING_ADDRESS(_optim_unroll_loop___80_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 112)), __EVMEANING_ADDRESS(_access_table__91_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 82)), __EVMEANING_ADDRESS(_mco_suffix__47_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 67)), __EVMEANING_ADDRESS(_optim__89_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 84)), __EVMEANING_ADDRESS(_auto_mode__185_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 11)), __EVMEANING_ADDRESS(_cc__215_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 57)), __EVMEANING_ADDRESS(_profile_library__193_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 75)), __EVMEANING_ADDRESS(_inlining_reduce_kfactor__26_engine_param));
   define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 8)), __EVMEANING_ADDRESS(_src_files__222_engine_param));
   return define_primop_ref__105___evenv(CNST_TABLE_REF(((long) 113)), __EVMEANING_ADDRESS(_additional_traces__2_engine_param));
}
