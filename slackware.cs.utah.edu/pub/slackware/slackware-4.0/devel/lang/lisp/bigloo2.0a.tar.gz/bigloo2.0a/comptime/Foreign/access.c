/*===========================================================================*/
/*   (Foreign/access.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_foreign_access();
extern obj_t make_ctype_accesses__219_foreign_access(type_t, type_t);
extern obj_t module_initialization_70_foreign_access(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_foreign_calias(long, char *);
extern obj_t module_initialization_70_foreign_cenum(long, char *);
extern obj_t module_initialization_70_foreign_cfunction(long, char *);
extern obj_t module_initialization_70_foreign_cpointer(long, char *);
extern obj_t module_initialization_70_foreign_cstruct(long, char *);
extern obj_t module_initialization_70___object(long, char *);
static obj_t _make_ctype_accesses_1141_73_foreign_access(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_foreign_access();
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t library_modules_init_112_foreign_access();
static obj_t _make_ctype_accesses__default1029_82_foreign_access(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_foreign_access();
static obj_t make_ctype_accesses__default1029_154_foreign_access(type_t, type_t);
extern obj_t _classes__134___object;
static obj_t require_initialization_114_foreign_access = BUNSPEC;
static obj_t *__cnst;

DEFINE_STATIC_PROCEDURE(make_ctype_accesses__default1029_env_58_foreign_access, _make_ctype_accesses__default1029_82_foreign_access1143, _make_ctype_accesses__default1029_82_foreign_access, 0L, 2);
DEFINE_EXPORT_GENERIC(make_ctype_accesses__env_11_foreign_access, _make_ctype_accesses_1141_73_foreign_access1144, _make_ctype_accesses_1141_73_foreign_access, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_foreign_access(long checksum_120, char *from_121)
{
   if (CBOOL(require_initialization_114_foreign_access))
     {
	require_initialization_114_foreign_access = BBOOL(((bool_t) 0));
	library_modules_init_112_foreign_access();
	imported_modules_init_94_foreign_access();
	method_init_76_foreign_access();
	toplevel_init_63_foreign_access();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_foreign_access()
{
   module_initialization_70___object(((long) 0), "FOREIGN_ACCESS");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_foreign_access()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_foreign_access()
{
   return add_generic__110___object(make_ctype_accesses__env_11_foreign_access, make_ctype_accesses__default1029_env_58_foreign_access);
}


/* make-ctype-accesses! */ obj_t 
make_ctype_accesses__219_foreign_access(type_t what_1, type_t who_2)
{
   {
      obj_t method1036_72;
      obj_t class1041_73;
      {
	 obj_t arg1053_70;
	 obj_t arg1055_71;
	 {
	    object_t obj_86;
	    obj_86 = (object_t) (what_1);
	    {
	       obj_t pre_method_105_87;
	       pre_method_105_87 = PROCEDURE_REF(make_ctype_accesses__env_11_foreign_access, ((long) 2));
	       if (INTEGERP(pre_method_105_87))
		 {
		    PROCEDURE_SET(make_ctype_accesses__env_11_foreign_access, ((long) 2), BUNSPEC);
		    arg1053_70 = pre_method_105_87;
		 }
	       else
		 {
		    long obj_class_num_177_92;
		    obj_class_num_177_92 = TYPE(obj_86);
		    {
		       obj_t arg1177_93;
		       arg1177_93 = PROCEDURE_REF(make_ctype_accesses__env_11_foreign_access, ((long) 1));
		       {
			  long arg1178_97;
			  {
			     long arg1179_98;
			     arg1179_98 = OBJECT_TYPE;
			     arg1178_97 = (obj_class_num_177_92 - arg1179_98);
			  }
			  arg1053_70 = VECTOR_REF(arg1177_93, arg1178_97);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_103;
	    object_103 = (object_t) (what_1);
	    {
	       long arg1180_104;
	       {
		  long arg1181_105;
		  long arg1182_106;
		  arg1181_105 = TYPE(object_103);
		  arg1182_106 = OBJECT_TYPE;
		  arg1180_104 = (arg1181_105 - arg1182_106);
	       }
	       {
		  obj_t vector_110;
		  vector_110 = _classes__134___object;
		  arg1055_71 = VECTOR_REF(vector_110, arg1180_104);
	       }
	    }
	 }
	 method1036_72 = arg1053_70;
	 class1041_73 = arg1055_71;
	 if (PROCEDUREP(method1036_72))
	   {
	      return PROCEDURE_ENTRY(method1036_72) (method1036_72, (obj_t) (what_1), (obj_t) (who_2), BEOA);
	   }
	 else
	   {
	      obj_t fun1035_68;
	      fun1035_68 = PROCEDURE_REF(make_ctype_accesses__env_11_foreign_access, ((long) 0));
	      return PROCEDURE_ENTRY(fun1035_68) (fun1035_68, (obj_t) (what_1), (obj_t) (who_2), BEOA);
	   }
      }
   }
}


/* _make-ctype-accesses!1141 */ obj_t 
_make_ctype_accesses_1141_73_foreign_access(obj_t env_114, obj_t what_115, obj_t who_116)
{
   return make_ctype_accesses__219_foreign_access((type_t) (what_115), (type_t) (who_116));
}


/* make-ctype-accesses!-default1029 */ obj_t 
make_ctype_accesses__default1029_154_foreign_access(type_t what_3, type_t who_4)
{
   return BNIL;
}


/* _make-ctype-accesses!-default1029 */ obj_t 
_make_ctype_accesses__default1029_82_foreign_access(obj_t env_117, obj_t what_118, obj_t who_119)
{
   return make_ctype_accesses__default1029_154_foreign_access((type_t) (what_118), (type_t) (who_119));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_foreign_access()
{
   module_initialization_70_type_type(((long) 0), "FOREIGN_ACCESS");
   module_initialization_70_foreign_calias(((long) 0), "FOREIGN_ACCESS");
   module_initialization_70_foreign_cenum(((long) 0), "FOREIGN_ACCESS");
   module_initialization_70_foreign_cfunction(((long) 0), "FOREIGN_ACCESS");
   module_initialization_70_foreign_cpointer(((long) 0), "FOREIGN_ACCESS");
   return module_initialization_70_foreign_cstruct(((long) 0), "FOREIGN_ACCESS");
}
