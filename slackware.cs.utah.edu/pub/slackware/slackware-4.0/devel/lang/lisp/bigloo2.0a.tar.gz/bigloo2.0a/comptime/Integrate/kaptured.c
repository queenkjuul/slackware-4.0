/*===========================================================================*/
/*   (Integrate/kaptured.scm)                                                */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t method_init_76_integrate_kaptured();
extern obj_t set_kaptured__104_integrate_kaptured(obj_t);
extern obj_t set_cto__5_integrate_cto(node_t, local_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t set_one_kaptured__205_integrate_kaptured(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_kaptured(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70_integrate_free(long, char *);
extern obj_t module_initialization_70_integrate_cto(long, char *);
extern obj_t module_initialization_70___object(long, char *);
static obj_t union_3_integrate_kaptured(obj_t);
static obj_t imported_modules_init_94_integrate_kaptured();
static obj_t library_modules_init_112_integrate_kaptured();
static long _union_round__11_integrate_kaptured;
static obj_t toplevel_init_63_integrate_kaptured();
extern obj_t create_vector(long);
static obj_t _set_kaptured__95_integrate_kaptured(obj_t, obj_t);
extern obj_t get_free_vars_244_integrate_free(node_t, local_t);
extern obj_t local_ast_var;
extern obj_t free_from_222_integrate_free(obj_t, local_t);
static obj_t require_initialization_114_integrate_kaptured = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(set_kaptured__env_5_integrate_kaptured, _set_kaptured__95_integrate_kaptured1687, _set_kaptured__95_integrate_kaptured, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_integrate_kaptured(long checksum_1482, char *from_1483)
{
   if (CBOOL(require_initialization_114_integrate_kaptured))
     {
	require_initialization_114_integrate_kaptured = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_kaptured();
	imported_modules_init_94_integrate_kaptured();
	method_init_76_integrate_kaptured();
	toplevel_init_63_integrate_kaptured();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_kaptured()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_KAPTURED");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_integrate_kaptured()
{
   return (_union_round__11_integrate_kaptured = ((long) 0),
      BUNSPEC);
}


/* set-kaptured! */ obj_t 
set_kaptured__104_integrate_kaptured(obj_t local__0_1)
{
   {
      obj_t l1517_882;
      {
	 bool_t aux_1492;
	 l1517_882 = local__0_1;
       lname1518_883:
	 if (PAIRP(l1517_882))
	   {
	      {
		 obj_t local_885;
		 local_885 = CAR(l1517_882);
		 set_one_kaptured__205_integrate_kaptured(local_885, local_885);
	      }
	      {
		 obj_t l1517_1497;
		 l1517_1497 = CDR(l1517_882);
		 l1517_882 = l1517_1497;
		 goto lname1518_883;
	      }
	   }
	 else
	   {
	      aux_1492 = ((bool_t) 1);
	   }
	 return BBOOL(aux_1492);
      }
   }
}


/* _set-kaptured! */ obj_t 
_set_kaptured__95_integrate_kaptured(obj_t env_1480, obj_t local__0_1481)
{
   return set_kaptured__104_integrate_kaptured(local__0_1481);
}


/* set-one-kaptured! */ obj_t 
set_one_kaptured__205_integrate_kaptured(obj_t local_2, obj_t locking_3)
{
   {
      value_t info_887;
      {
	 local_t obj_1330;
	 obj_1330 = (local_t) (local_2);
	 info_887 = (((local_t) CREF(obj_1330))->value);
      }
      {
	 obj_t kaptured_888;
	 {
	    sfun_iinfo_105_t obj_1331;
	    obj_1331 = (sfun_iinfo_105_t) (info_887);
	    {
	       obj_t aux_1504;
	       {
		  object_t aux_1505;
		  aux_1505 = (object_t) (obj_1331);
		  aux_1504 = OBJECT_WIDENING(aux_1505);
	       }
	       kaptured_888 = (((sfun_iinfo_105_t) CREF(aux_1504))->kaptured);
	    }
	 }
	 {
	    {
	       bool_t test_1509;
	       if (PAIRP(kaptured_888))
		 {
		    test_1509 = ((bool_t) 1);
		 }
	       else
		 {
		    test_1509 = NULLP(kaptured_888);
		 }
	       if (test_1509)
		 {
		    {
		       obj_t v1519_890;
		       v1519_890 = create_vector(((long) 3));
		       VECTOR_SET(v1519_890, ((long) 2), kaptured_888);
		       VECTOR_SET(v1519_890, ((long) 1), locking_3);
		       VECTOR_SET(v1519_890, ((long) 0), BTRUE);
		       return v1519_890;
		    }
		 }
	       else
		 {
		    bool_t test1528_891;
		    test1528_891 = is_a__118___object(kaptured_888, local_ast_var);
		    if (test1528_891)
		      {
			 {
			    obj_t v1520_892;
			    v1520_892 = create_vector(((long) 3));
			    VECTOR_SET(v1520_892, ((long) 2), BNIL);
			    VECTOR_SET(v1520_892, ((long) 1), locking_3);
			    VECTOR_SET(v1520_892, ((long) 0), BFALSE);
			    return v1520_892;
			 }
		      }
		    else
		      {
			 {
			    obj_t body_895;
			    {
			       sfun_t obj_1354;
			       obj_1354 = (sfun_t) (info_887);
			       body_895 = (((sfun_t) CREF(obj_1354))->body);
			    }
			    set_cto__5_integrate_cto((node_t) (body_895), (local_t) (local_2));
			    {
			       sfun_iinfo_105_t obj_1355;
			       obj_1355 = (sfun_iinfo_105_t) (info_887);
			       {
				  obj_t aux_1529;
				  {
				     object_t aux_1530;
				     aux_1530 = (object_t) (obj_1355);
				     aux_1529 = OBJECT_WIDENING(aux_1530);
				  }
				  ((((sfun_iinfo_105_t) CREF(aux_1529))->kaptured) = ((obj_t) local_2), BUNSPEC);
			       }
			    }
			    {
			       obj_t kaptured_896;
			       obj_t cto_897;
			       bool_t setter__165_898;
			       kaptured_896 = BNIL;
			       {
				  sfun_iinfo_105_t obj_1357;
				  obj_1357 = (sfun_iinfo_105_t) (info_887);
				  {
				     obj_t aux_1623;
				     {
					object_t aux_1624;
					aux_1624 = (object_t) (obj_1357);
					aux_1623 = OBJECT_WIDENING(aux_1624);
				     }
				     cto_897 = (((sfun_iinfo_105_t) CREF(aux_1623))->cto);
				  }
			       }
			       setter__165_898 = ((bool_t) 1);
			     loop_899:
			       if (NULLP(cto_897))
				 {
				    {
				       obj_t free_903;
				       free_903 = get_free_vars_244_integrate_free((node_t) (body_895), (local_t) (local_2));
				       {
					  obj_t fkaptured_904;
					  fkaptured_904 = free_from_222_integrate_free(kaptured_896, (local_t) (local_2));
					  {
					     obj_t rkaptured_905;
					     {
						obj_t arg1537_913;
						arg1537_913 = MAKE_PAIR(free_903, fkaptured_904);
						rkaptured_905 = union_3_integrate_kaptured(arg1537_913);
					     }
					     {
						if (setter__165_898)
						  {
						     {
							sfun_iinfo_105_t obj_1361;
							obj_1361 = (sfun_iinfo_105_t) (info_887);
							{
							   obj_t aux_1545;
							   {
							      object_t aux_1546;
							      aux_1546 = (object_t) (obj_1361);
							      aux_1545 = OBJECT_WIDENING(aux_1546);
							   }
							   ((((sfun_iinfo_105_t) CREF(aux_1545))->kaptured) = ((obj_t) rkaptured_905), BUNSPEC);
							}
						     }
						     {
							obj_t l1521_906;
							{
							   bool_t aux_1550;
							   l1521_906 = rkaptured_905;
							 lname1522_907:
							   if (PAIRP(l1521_906))
							     {
								{
								   svar_iinfo_76_t obj_1366;
								   {
								      value_t aux_1553;
								      {
									 local_t obj_1365;
									 {
									    obj_t aux_1554;
									    aux_1554 = CAR(l1521_906);
									    obj_1365 = (local_t) (aux_1554);
									 }
									 aux_1553 = (((local_t) CREF(obj_1365))->value);
								      }
								      obj_1366 = (svar_iinfo_76_t) (aux_1553);
								   }
								   {
								      obj_t aux_1559;
								      {
									 object_t aux_1560;
									 aux_1560 = (object_t) (obj_1366);
									 aux_1559 = OBJECT_WIDENING(aux_1560);
								      }
								      ((((svar_iinfo_76_t) CREF(aux_1559))->kaptured__204) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								   }
								}
								{
								   obj_t l1521_1564;
								   l1521_1564 = CDR(l1521_906);
								   l1521_906 = l1521_1564;
								   goto lname1522_907;
								}
							     }
							   else
							     {
								aux_1550 = ((bool_t) 1);
							     }
							   BBOOL(aux_1550);
							}
						     }
						  }
						else
						  {
						     sfun_iinfo_105_t obj_1369;
						     obj_1369 = (sfun_iinfo_105_t) (info_887);
						     {
							obj_t aux_1568;
							{
							   object_t aux_1569;
							   aux_1569 = (object_t) (obj_1369);
							   aux_1568 = OBJECT_WIDENING(aux_1569);
							}
							((((sfun_iinfo_105_t) CREF(aux_1568))->kaptured) = ((obj_t) BUNSPEC), BUNSPEC);
						     }
						  }
						{
						   obj_t v1523_912;
						   v1523_912 = create_vector(((long) 3));
						   VECTOR_SET(v1523_912, ((long) 2), rkaptured_905);
						   VECTOR_SET(v1523_912, ((long) 1), locking_3);
						   {
						      obj_t aux_1576;
						      aux_1576 = BBOOL(setter__165_898);
						      VECTOR_SET(v1523_912, ((long) 0), aux_1576);
						   }
						   return v1523_912;
						}
					     }
					  }
				       }
				    }
				 }
			       else
				 {
				    bool_t test_1579;
				    {
				       obj_t aux_1580;
				       aux_1580 = CAR(cto_897);
				       test_1579 = (aux_1580 == local_2);
				    }
				    if (test_1579)
				      {
					 {
					    obj_t cto_1583;
					    cto_1583 = CDR(cto_897);
					    cto_897 = cto_1583;
					    goto loop_899;
					 }
				      }
				    else
				      {
					 bool_t test_1585;
					 {
					    sfun_iinfo_105_t obj_1386;
					    {
					       value_t aux_1586;
					       {
						  local_t obj_1385;
						  {
						     obj_t aux_1587;
						     aux_1587 = CAR(cto_897);
						     obj_1385 = (local_t) (aux_1587);
						  }
						  aux_1586 = (((local_t) CREF(obj_1385))->value);
					       }
					       obj_1386 = (sfun_iinfo_105_t) (aux_1586);
					    }
					    {
					       obj_t aux_1592;
					       {
						  object_t aux_1593;
						  aux_1593 = (object_t) (obj_1386);
						  aux_1592 = OBJECT_WIDENING(aux_1593);
					       }
					       test_1585 = (((sfun_iinfo_105_t) CREF(aux_1592))->g__219);
					    }
					 }
					 if (test_1585)
					   {
					      {
						 obj_t other_kaptured_142_917;
						 other_kaptured_142_917 = set_one_kaptured__205_integrate_kaptured(CAR(cto_897), locking_3);
						 {
						    bool_t test_1599;
						    {
						       obj_t aux_1600;
						       aux_1600 = VECTOR_REF(other_kaptured_142_917, ((long) 0));
						       test_1599 = CBOOL(aux_1600);
						    }
						    if (test_1599)
						      {
							 obj_t arg1542_919;
							 obj_t arg1545_920;
							 {
							    obj_t aux_1603;
							    aux_1603 = VECTOR_REF(other_kaptured_142_917, ((long) 2));
							    arg1542_919 = MAKE_PAIR(aux_1603, kaptured_896);
							 }
							 arg1545_920 = CDR(cto_897);
							 {
							    obj_t cto_1608;
							    obj_t kaptured_1607;
							    kaptured_1607 = arg1542_919;
							    cto_1608 = arg1545_920;
							    cto_897 = cto_1608;
							    kaptured_896 = kaptured_1607;
							    goto loop_899;
							 }
						      }
						    else
						      {
							 obj_t arg1549_922;
							 obj_t arg1550_923;
							 bool_t arg1552_924;
							 {
							    obj_t aux_1609;
							    aux_1609 = VECTOR_REF(other_kaptured_142_917, ((long) 2));
							    arg1549_922 = MAKE_PAIR(aux_1609, kaptured_896);
							 }
							 arg1550_923 = CDR(cto_897);
							 if (setter__165_898)
							   {
							      obj_t aux_1614;
							      aux_1614 = VECTOR_REF(other_kaptured_142_917, ((long) 1));
							      arg1552_924 = (aux_1614 == local_2);
							   }
							 else
							   {
							      arg1552_924 = ((bool_t) 0);
							   }
							 {
							    bool_t setter__165_1619;
							    obj_t cto_1618;
							    obj_t kaptured_1617;
							    kaptured_1617 = arg1549_922;
							    cto_1618 = arg1550_923;
							    setter__165_1619 = arg1552_924;
							    setter__165_898 = setter__165_1619;
							    cto_897 = cto_1618;
							    kaptured_896 = kaptured_1617;
							    goto loop_899;
							 }
						      }
						 }
					      }
					   }
					 else
					   {
					      {
						 obj_t cto_1620;
						 cto_1620 = CDR(cto_897);
						 cto_897 = cto_1620;
						 goto loop_899;
					      }
					   }
				      }
				 }
			    }
			 }
		      }
		 }
	    }
	 }
      }
   }
}


/* union */ obj_t 
union_3_integrate_kaptured(obj_t sets_4)
{
   {
      long z2_1406;
      z2_1406 = _union_round__11_integrate_kaptured;
      _union_round__11_integrate_kaptured = (((long) 1) + z2_1406);
   }
   {
      obj_t sets_935;
      obj_t union_936;
      sets_935 = sets_4;
      union_936 = BNIL;
    loop_937:
      if (NULLP(sets_935))
	{
	   return union_936;
	}
      else
	{
	   obj_t set_940;
	   obj_t union_941;
	   set_940 = CAR(sets_935);
	   union_941 = union_936;
	 liip_942:
	   if (NULLP(set_940))
	     {
		{
		   obj_t union_1635;
		   obj_t sets_1633;
		   sets_1633 = CDR(sets_935);
		   union_1635 = union_941;
		   union_936 = union_1635;
		   sets_935 = sets_1633;
		   goto loop_937;
		}
	     }
	   else
	     {
		bool_t test1567_946;
		{
		   obj_t arg1578_953;
		   {
		      svar_iinfo_76_t obj_1413;
		      {
			 value_t aux_1636;
			 {
			    local_t obj_1412;
			    {
			       obj_t aux_1637;
			       aux_1637 = CAR(set_940);
			       obj_1412 = (local_t) (aux_1637);
			    }
			    aux_1636 = (((local_t) CREF(obj_1412))->value);
			 }
			 obj_1413 = (svar_iinfo_76_t) (aux_1636);
		      }
		      {
			 obj_t aux_1642;
			 {
			    object_t aux_1643;
			    aux_1643 = (object_t) (obj_1413);
			    aux_1642 = OBJECT_WIDENING(aux_1643);
			 }
			 arg1578_953 = (((svar_iinfo_76_t) CREF(aux_1642))->u_mark_209);
		      }
		   }
		   {
		      obj_t obj2_1415;
		      obj2_1415 = BINT(_union_round__11_integrate_kaptured);
		      test1567_946 = (arg1578_953 == obj2_1415);
		   }
		}
		if (test1567_946)
		  {
		     {
			obj_t set_1650;
			set_1650 = CDR(set_940);
			set_940 = set_1650;
			goto liip_942;
		     }
		  }
		else
		  {
		     {
			svar_iinfo_76_t obj_1419;
			obj_t val1448_1420;
			{
			   value_t aux_1652;
			   {
			      local_t obj_1418;
			      {
				 obj_t aux_1653;
				 aux_1653 = CAR(set_940);
				 obj_1418 = (local_t) (aux_1653);
			      }
			      aux_1652 = (((local_t) CREF(obj_1418))->value);
			   }
			   obj_1419 = (svar_iinfo_76_t) (aux_1652);
			}
			val1448_1420 = BINT(_union_round__11_integrate_kaptured);
			{
			   obj_t aux_1659;
			   {
			      object_t aux_1660;
			      aux_1660 = (object_t) (obj_1419);
			      aux_1659 = OBJECT_WIDENING(aux_1660);
			   }
			   ((((svar_iinfo_76_t) CREF(aux_1659))->u_mark_209) = ((obj_t) val1448_1420), BUNSPEC);
			}
		     }
		     {
			obj_t arg1572_950;
			obj_t arg1573_951;
			arg1572_950 = CDR(set_940);
			{
			   obj_t aux_1665;
			   aux_1665 = CAR(set_940);
			   arg1573_951 = MAKE_PAIR(aux_1665, union_941);
			}
			{
			   obj_t union_1669;
			   obj_t set_1668;
			   set_1668 = arg1572_950;
			   union_1669 = arg1573_951;
			   union_941 = union_1669;
			   set_940 = set_1668;
			   goto liip_942;
			}
		     }
		  }
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_integrate_kaptured()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_kaptured()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_KAPTURED");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_KAPTURED");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_KAPTURED");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_KAPTURED");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_KAPTURED");
   module_initialization_70_integrate_info(((long) 0), "INTEGRATE_KAPTURED");
   module_initialization_70_integrate_free(((long) 0), "INTEGRATE_KAPTURED");
   return module_initialization_70_integrate_cto(((long) 0), "INTEGRATE_KAPTURED");
}
