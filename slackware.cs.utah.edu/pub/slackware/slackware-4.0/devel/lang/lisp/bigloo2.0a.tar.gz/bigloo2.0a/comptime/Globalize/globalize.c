/*===========================================================================*/
/*   (Globalize/globalize.scm)                                               */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


obj_t _g1__181_globalize_globalize = BUNSPEC;
obj_t _g0__244_globalize_globalize = BUNSPEC;
obj_t _e__34_globalize_globalize = BUNSPEC;
static obj_t method_init_76_globalize_globalize();
extern obj_t set_kaptured__104_globalize_kapture(obj_t);
extern obj_t globalize__167_globalize_globalize(global_t);
extern obj_t set_globalized_new_bodies__10_globalize_new_body_146(global_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_globalize(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_globalize_node(long, char *);
extern obj_t module_initialization_70_globalize_free(long, char *);
extern obj_t module_initialization_70_globalize_kapture(long, char *);
extern obj_t module_initialization_70_globalize_gn(long, char *);
extern obj_t module_initialization_70_globalize_integration(long, char *);
extern obj_t module_initialization_70_globalize_new_body_146(long, char *);
extern obj_t module_initialization_70_globalize_local__global_194(long, char *);
extern obj_t module_initialization_70_globalize_global_closure_246(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern global_t local__global_40_globalize_local__global_194(local_t);
extern node_t node_globalize__229_globalize_node(node_t, variable_t, obj_t);
extern obj_t gn__33_globalize_gn(obj_t, node_t, variable_t, obj_t);
static obj_t imported_modules_init_94_globalize_globalize();
static obj_t library_modules_init_112_globalize_globalize();
static obj_t toplevel_init_63_globalize_globalize();
static obj_t _globalize_1767_62_globalize_globalize(obj_t, obj_t);
extern obj_t local_ast_var;
extern global_t global_closure_229_globalize_global_closure_246(global_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
static bool_t verb_globalization_175_globalize_globalize();
extern obj_t set_integration__52_globalize_integration();
static obj_t require_initialization_114_globalize_globalize = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(globalize__env_187_globalize_globalize, _globalize_1767_62_globalize_globalize1775, _globalize_1767_62_globalize_globalize, 0L, 1);
DEFINE_STRING(string1773_globalize_globalize, string1773_globalize_globalize1776, " -->", 4);
DEFINE_STRING(string1772_globalize_globalize, string1772_globalize_globalize1777, " --> ", 5);
DEFINE_STRING(string1771_globalize_globalize, string1771_globalize_globalize1778, "           ", 11);
DEFINE_STRING(string1769_globalize_globalize, string1769_globalize_globalize1779, "        ", 8);
DEFINE_STRING(string1770_globalize_globalize, string1770_globalize_globalize1780, " ==>", 4);
DEFINE_STRING(string1768_globalize_globalize, string1768_globalize_globalize1781, " : ", 3);


/* module-initialization */ obj_t 
module_initialization_70_globalize_globalize(long checksum_1602, char *from_1603)
{
   if (CBOOL(require_initialization_114_globalize_globalize))
     {
	require_initialization_114_globalize_globalize = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_globalize();
	imported_modules_init_94_globalize_globalize();
	method_init_76_globalize_globalize();
	toplevel_init_63_globalize_globalize();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_globalize()
{
   module_initialization_70___object(((long) 0), "GLOBALIZE_GLOBALIZE");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_globalize_globalize()
{
   _e__34_globalize_globalize = BNIL;
   _g0__244_globalize_globalize = BNIL;
   return (_g1__181_globalize_globalize = BNIL,
      BUNSPEC);
}


/* globalize! */ obj_t 
globalize__167_globalize_globalize(global_t global_1)
{
   {
      obj_t arg1563_993;
      arg1563_993 = shape_tools_shape((obj_t) (global_1));
      {
	 obj_t list1565_995;
	 {
	    obj_t arg1566_996;
	    {
	       obj_t arg1568_997;
	       {
		  obj_t arg1569_998;
		  {
		     obj_t aux_1614;
		     aux_1614 = BCHAR(((unsigned char) '\n'));
		     arg1569_998 = MAKE_PAIR(aux_1614, BNIL);
		  }
		  arg1568_997 = MAKE_PAIR(string1768_globalize_globalize, arg1569_998);
	       }
	       arg1566_996 = MAKE_PAIR(arg1563_993, arg1568_997);
	    }
	    list1565_995 = MAKE_PAIR(string1769_globalize_globalize, arg1566_996);
	 }
	 verbose_tools_speek(BINT(((long) 3)), list1565_995);
      }
   }
   {
      value_t fun_1000;
      fun_1000 = (((global_t) CREF(global_1))->value);
      _e__34_globalize_globalize = BNIL;
      _g0__244_globalize_globalize = BNIL;
      _g1__181_globalize_globalize = BNIL;
      {
	 node_t aux_1626;
	 obj_t aux_1623;
	 {
	    obj_t aux_1627;
	    {
	       sfun_t obj_1472;
	       obj_1472 = (sfun_t) (fun_1000);
	       aux_1627 = (((sfun_t) CREF(obj_1472))->body);
	    }
	    aux_1626 = (node_t) (aux_1627);
	 }
	 {
	    sfun_t obj_1471;
	    obj_1471 = (sfun_t) (fun_1000);
	    aux_1623 = (((sfun_t) CREF(obj_1471))->args);
	 }
	 gn__33_globalize_gn(aux_1623, aux_1626, (variable_t) (global_1), BNIL);
      }
      set_integration__52_globalize_integration();
      {
	 obj_t g_1004;
	 {
	    obj_t g1_1026;
	    obj_t g_1027;
	    g1_1026 = _g1__181_globalize_globalize;
	    g_1027 = _e__34_globalize_globalize;
	  loop_1028:
	    if (NULLP(g1_1026))
	      {
		 g_1004 = g_1027;
	      }
	    else
	      {
		 bool_t test1600_1030;
		 {
		    obj_t aux_1636;
		    {
		       sfun_ginfo_98_t obj_1476;
		       {
			  value_t aux_1637;
			  {
			     local_t obj_1475;
			     {
				obj_t aux_1638;
				aux_1638 = CAR(g1_1026);
				obj_1475 = (local_t) (aux_1638);
			     }
			     aux_1637 = (((local_t) CREF(obj_1475))->value);
			  }
			  obj_1476 = (sfun_ginfo_98_t) (aux_1637);
		       }
		       {
			  obj_t aux_1643;
			  {
			     object_t aux_1644;
			     aux_1644 = (object_t) (obj_1476);
			     aux_1643 = OBJECT_WIDENING(aux_1644);
			  }
			  aux_1636 = (((sfun_ginfo_98_t) CREF(aux_1643))->integrator);
		       }
		    }
		    test1600_1030 = is_a__118___object(aux_1636, local_ast_var);
		 }
		 if (test1600_1030)
		   {
		      {
			 obj_t g1_1650;
			 g1_1650 = CDR(g1_1026);
			 g1_1026 = g1_1650;
			 goto loop_1028;
		      }
		   }
		 else
		   {
		      {
			 obj_t arg1603_1032;
			 obj_t arg1605_1033;
			 arg1603_1032 = CDR(g1_1026);
			 {
			    obj_t aux_1653;
			    aux_1653 = CAR(g1_1026);
			    arg1605_1033 = MAKE_PAIR(aux_1653, g_1027);
			 }
			 {
			    obj_t g_1657;
			    obj_t g1_1656;
			    g1_1656 = arg1603_1032;
			    g_1657 = arg1605_1033;
			    g_1027 = g_1657;
			    g1_1026 = g1_1656;
			    goto loop_1028;
			 }
		      }
		   }
	      }
	 }
	 verb_globalization_175_globalize_globalize();
	 set_globalized_new_bodies__10_globalize_new_body_146(global_1, g_1004);
	 set_kaptured__104_globalize_kapture(g_1004);
	 {
	    obj_t g_1005;
	    obj_t new_g_67_1006;
	    {
	       obj_t arg1578_1008;
	       {
		  bool_t test_1661;
		  {
		     global_ginfo_75_t obj_1483;
		     obj_1483 = (global_ginfo_75_t) (global_1);
		     {
			obj_t aux_1663;
			{
			   object_t aux_1664;
			   aux_1664 = (object_t) (obj_1483);
			   aux_1663 = OBJECT_WIDENING(aux_1664);
			}
			test_1661 = (((global_ginfo_75_t) CREF(aux_1663))->escape__117);
		     }
		  }
		  if (test_1661)
		    {
		       global_t arg1580_1010;
		       {
			  obj_t aux_1668;
			  {
			     node_t obj_1485;
			     {
				obj_t aux_1669;
				{
				   sfun_t obj_1484;
				   obj_1484 = (sfun_t) (fun_1000);
				   aux_1669 = (((sfun_t) CREF(obj_1484))->body);
				}
				obj_1485 = (node_t) (aux_1669);
			     }
			     aux_1668 = (((node_t) CREF(obj_1485))->loc);
			  }
			  arg1580_1010 = global_closure_229_globalize_global_closure_246(global_1, aux_1668);
		       }
		       {
			  obj_t list1581_1011;
			  {
			     obj_t arg1582_1012;
			     {
				obj_t aux_1675;
				aux_1675 = (obj_t) (global_1);
				arg1582_1012 = MAKE_PAIR(aux_1675, BNIL);
			     }
			     {
				obj_t aux_1678;
				aux_1678 = (obj_t) (arg1580_1010);
				list1581_1011 = MAKE_PAIR(aux_1678, arg1582_1012);
			     }
			  }
			  arg1578_1008 = list1581_1011;
		       }
		    }
		  else
		    {
		       obj_t list1586_1016;
		       {
			  obj_t aux_1681;
			  aux_1681 = (obj_t) (global_1);
			  list1586_1016 = MAKE_PAIR(aux_1681, BNIL);
		       }
		       arg1578_1008 = list1586_1016;
		    }
	       }
	       g_1005 = g_1004;
	       new_g_67_1006 = arg1578_1008;
	     loop_1007:
	       if (NULLP(g_1005))
		 {
		    node_t body_1019;
		    {
		       node_t aux_1686;
		       {
			  obj_t aux_1687;
			  {
			     sfun_t obj_1489;
			     obj_1489 = (sfun_t) (fun_1000);
			     aux_1687 = (((sfun_t) CREF(obj_1489))->body);
			  }
			  aux_1686 = (node_t) (aux_1687);
		       }
		       body_1019 = node_globalize__229_globalize_node(aux_1686, (variable_t) (global_1), BNIL);
		    }
		    {
		       sfun_t obj_1490;
		       obj_t val1140_1491;
		       obj_1490 = (sfun_t) (fun_1000);
		       val1140_1491 = (obj_t) (body_1019);
		       ((((sfun_t) CREF(obj_1490))->body) = ((obj_t) val1140_1491), BUNSPEC);
		    }
		    return new_g_67_1006;
		 }
	       else
		 {
		    obj_t arg1593_1022;
		    obj_t arg1594_1023;
		    arg1593_1022 = CDR(g_1005);
		    {
		       global_t arg1595_1024;
		       {
			  local_t aux_1697;
			  {
			     obj_t aux_1698;
			     aux_1698 = CAR(g_1005);
			     aux_1697 = (local_t) (aux_1698);
			  }
			  arg1595_1024 = local__global_40_globalize_local__global_194(aux_1697);
		       }
		       {
			  obj_t aux_1702;
			  aux_1702 = (obj_t) (arg1595_1024);
			  arg1594_1023 = MAKE_PAIR(aux_1702, new_g_67_1006);
		       }
		    }
		    {
		       obj_t new_g_67_1706;
		       obj_t g_1705;
		       g_1705 = arg1593_1022;
		       new_g_67_1706 = arg1594_1023;
		       new_g_67_1006 = new_g_67_1706;
		       g_1005 = g_1705;
		       goto loop_1007;
		    }
		 }
	    }
	 }
      }
   }
}


/* _globalize!1767 */ obj_t 
_globalize_1767_62_globalize_globalize(obj_t env_1600, obj_t global_1601)
{
   return globalize__167_globalize_globalize((global_t) (global_1601));
}


/* verb-globalization */ bool_t 
verb_globalization_175_globalize_globalize()
{
   {
      obj_t l1557_1038;
      l1557_1038 = _e__34_globalize_globalize;
    lname1558_1039:
      if (PAIRP(l1557_1038))
	{
	   {
	      obj_t arg1615_1044;
	      arg1615_1044 = shape_tools_shape(CAR(l1557_1038));
	      {
		 obj_t list1618_1046;
		 {
		    obj_t arg1620_1047;
		    {
		       obj_t arg1621_1048;
		       {
			  obj_t arg1622_1049;
			  {
			     obj_t aux_1713;
			     aux_1713 = BCHAR(((unsigned char) '\n'));
			     arg1622_1049 = MAKE_PAIR(aux_1713, BNIL);
			  }
			  arg1621_1048 = MAKE_PAIR(string1770_globalize_globalize, arg1622_1049);
		       }
		       arg1620_1047 = MAKE_PAIR(arg1615_1044, arg1621_1048);
		    }
		    list1618_1046 = MAKE_PAIR(string1771_globalize_globalize, arg1620_1047);
		 }
		 verbose_tools_speek(BINT(((long) 3)), list1618_1046);
	      }
	   }
	   {
	      obj_t l1557_1721;
	      l1557_1721 = CDR(l1557_1038);
	      l1557_1038 = l1557_1721;
	      goto lname1558_1039;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t l1559_1052;
      l1559_1052 = _g1__181_globalize_globalize;
    lname1560_1053:
      if (PAIRP(l1559_1052))
	{
	   {
	      obj_t local_1055;
	      local_1055 = CAR(l1559_1052);
	      {
		 value_t sfun_ginfo_98_1056;
		 {
		    local_t obj_1501;
		    obj_1501 = (local_t) (local_1055);
		    sfun_ginfo_98_1056 = (((local_t) CREF(obj_1501))->value);
		 }
		 {
		    bool_t test1626_1057;
		    {
		       obj_t aux_1728;
		       {
			  sfun_ginfo_98_t obj_1502;
			  obj_1502 = (sfun_ginfo_98_t) (sfun_ginfo_98_1056);
			  {
			     obj_t aux_1730;
			     {
				object_t aux_1731;
				aux_1731 = (object_t) (obj_1502);
				aux_1730 = OBJECT_WIDENING(aux_1731);
			     }
			     aux_1728 = (((sfun_ginfo_98_t) CREF(aux_1730))->integrator);
			  }
		       }
		       test1626_1057 = is_a__118___object(aux_1728, local_ast_var);
		    }
		    if (test1626_1057)
		      {
			 obj_t arg1630_1060;
			 obj_t arg1633_1062;
			 arg1630_1060 = shape_tools_shape(local_1055);
			 {
			    obj_t aux_1738;
			    {
			       sfun_ginfo_98_t obj_1504;
			       obj_1504 = (sfun_ginfo_98_t) (sfun_ginfo_98_1056);
			       {
				  obj_t aux_1740;
				  {
				     object_t aux_1741;
				     aux_1741 = (object_t) (obj_1504);
				     aux_1740 = OBJECT_WIDENING(aux_1741);
				  }
				  aux_1738 = (((sfun_ginfo_98_t) CREF(aux_1740))->integrator);
			       }
			    }
			    arg1633_1062 = shape_tools_shape(aux_1738);
			 }
			 {
			    obj_t list1634_1063;
			    {
			       obj_t arg1636_1064;
			       {
				  obj_t arg1638_1065;
				  {
				     obj_t arg1639_1066;
				     {
					obj_t arg1640_1067;
					{
					   obj_t aux_1746;
					   aux_1746 = BCHAR(((unsigned char) '\n'));
					   arg1640_1067 = MAKE_PAIR(aux_1746, BNIL);
					}
					arg1639_1066 = MAKE_PAIR(arg1633_1062, arg1640_1067);
				     }
				     arg1638_1065 = MAKE_PAIR(string1772_globalize_globalize, arg1639_1066);
				  }
				  arg1636_1064 = MAKE_PAIR(arg1630_1060, arg1638_1065);
			       }
			       list1634_1063 = MAKE_PAIR(string1771_globalize_globalize, arg1636_1064);
			    }
			    verbose_tools_speek(BINT(((long) 3)), list1634_1063);
			 }
		      }
		    else
		      {
			 obj_t arg1648_1072;
			 arg1648_1072 = shape_tools_shape(local_1055);
			 {
			    obj_t list1650_1074;
			    {
			       obj_t arg1652_1075;
			       {
				  obj_t arg1653_1076;
				  {
				     obj_t arg1654_1077;
				     {
					obj_t aux_1756;
					aux_1756 = BCHAR(((unsigned char) '\n'));
					arg1654_1077 = MAKE_PAIR(aux_1756, BNIL);
				     }
				     arg1653_1076 = MAKE_PAIR(string1773_globalize_globalize, arg1654_1077);
				  }
				  arg1652_1075 = MAKE_PAIR(arg1648_1072, arg1653_1076);
			       }
			       list1650_1074 = MAKE_PAIR(string1771_globalize_globalize, arg1652_1075);
			    }
			    verbose_tools_speek(BINT(((long) 3)), list1650_1074);
			 }
		      }
		 }
	      }
	   }
	   {
	      obj_t l1559_1764;
	      l1559_1764 = CDR(l1559_1052);
	      l1559_1052 = l1559_1764;
	      goto lname1560_1053;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* method-init */ obj_t 
method_init_76_globalize_globalize()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_globalize()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_tools_speek(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_globalize_node(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_globalize_free(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_globalize_kapture(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_globalize_gn(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_globalize_integration(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_globalize_new_body_146(((long) 0), "GLOBALIZE_GLOBALIZE");
   module_initialization_70_globalize_local__global_194(((long) 0), "GLOBALIZE_GLOBALIZE");
   return module_initialization_70_globalize_global_closure_246(((long) 0), "GLOBALIZE_GLOBALIZE");
}
