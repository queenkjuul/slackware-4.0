/*===========================================================================*/
/*   (Cc/cc.scm)                                                             */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t _cc__215_engine_param;
extern obj_t string_append(obj_t, obj_t);
extern obj_t _rm_c_files__192_engine_param;
extern obj_t dirname___os(obj_t);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t pwd___os();
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_cc_cc(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_cc_exec(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t os_class_179___os;
static obj_t imported_modules_init_94_cc_cc();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t unix_cc_222_cc_cc(obj_t, bool_t);
extern obj_t _cc_options__252_engine_param;
extern bool_t bigloo_strcmp(obj_t, obj_t);
static obj_t library_modules_init_112_cc_cc();
extern obj_t _c_debug_option__198_engine_param;
extern obj_t string_to_bstring(char *);
extern obj_t _lib_dir__34_engine_param;
static obj_t loop_cc_cc(obj_t);
extern obj_t basename___os(obj_t);
extern obj_t exec_cc_exec(obj_t, bool_t, obj_t);
extern obj_t cc_cc_cc(obj_t, bool_t);
extern obj_t _c_debug__136_engine_param;
static obj_t require_initialization_114_cc_cc = BUNSPEC;
static obj_t _cc_cc_cc(obj_t, obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(cc_env_200_cc_cc, _cc_cc_cc1251, _cc_cc_cc, 0L, 2);
DEFINE_STRING(string1249_cc_cc, string1249_cc_cc1252, "-I", 2);
DEFINE_STRING(string1248_cc_cc, string1248_cc_cc1253, "can't process cc on stdout", 26);
DEFINE_STRING(string1247_cc_cc, string1247_cc_cc1254, "&& /bin/mv ", 11);
DEFINE_STRING(string1246_cc_cc, string1246_cc_cc1255, ".o ", 3);
DEFINE_STRING(string1245_cc_cc, string1245_cc_cc1256, ".o 2>&1 >/dev/null ", 19);
DEFINE_STRING(string1244_cc_cc, string1244_cc_cc1257, "&& /bin/rm -f ", 14);
DEFINE_STRING(string1243_cc_cc, string1243_cc_cc1258, "      [", 7);
DEFINE_STRING(string1242_cc_cc, string1242_cc_cc1259, " -c ", 4);
DEFINE_STRING(string1241_cc_cc, string1241_cc_cc1260, " -I. ", 5);
DEFINE_STRING(string1239_cc_cc, string1239_cc_cc1261, "", 0);
DEFINE_STRING(string1240_cc_cc, string1240_cc_cc1262, ".c ", 3);
DEFINE_STRING(string1238_cc_cc, string1238_cc_cc1263, " ", 1);
DEFINE_STRING(string1237_cc_cc, string1237_cc_cc1264, "   . cc (", 9);
DEFINE_STRING(string1236_cc_cc, string1236_cc_cc1265, ")", 1);
DEFINE_STRING(string1235_cc_cc, string1235_cc_cc1266, "Unknow os", 9);
DEFINE_STRING(string1234_cc_cc, string1234_cc_cc1267, "cc", 2);
DEFINE_STRING(string1233_cc_cc, string1233_cc_cc1268, "unix", 4);


/* module-initialization */ obj_t 
module_initialization_70_cc_cc(long checksum_110, char *from_111)
{
   if (CBOOL(require_initialization_114_cc_cc))
     {
	require_initialization_114_cc_cc = BBOOL(((bool_t) 0));
	library_modules_init_112_cc_cc();
	imported_modules_init_94_cc_cc();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cc_cc()
{
   module_initialization_70___os(((long) 0), "CC_CC");
   module_initialization_70___r4_strings_6_7(((long) 0), "CC_CC");
   return BUNSPEC;
}


/* cc */ obj_t 
cc_cc_cc(obj_t name_1, bool_t need_to_return_234_2)
{
   {
      bool_t test1002_5;
      {
	 obj_t arg1007_10;
	 arg1007_10 = PROCEDURE_ENTRY(os_class_179___os) (os_class_179___os, BEOA);
	 test1002_5 = bigloo_strcmp(arg1007_10, string1233_cc_cc);
      }
      if (test1002_5)
	{
	   return unix_cc_222_cc_cc(name_1, need_to_return_234_2);
	}
      else
	{
	   {
	      obj_t arg1005_8;
	      arg1005_8 = PROCEDURE_ENTRY(os_class_179___os) (os_class_179___os, BEOA);
	      return user_error_151_tools_error(string1234_cc_cc, string1235_cc_cc, arg1005_8, BNIL);
	   }
	}
   }
}


/* _cc */ obj_t 
_cc_cc_cc(obj_t env_107, obj_t name_108, obj_t need_to_return_234_109)
{
   return cc_cc_cc(name_108, CBOOL(need_to_return_234_109));
}


/* unix-cc */ obj_t 
unix_cc_222_cc_cc(obj_t name_3, bool_t need_to_return_234_4)
{
   {
      obj_t list1009_12;
      {
	 obj_t arg1014_14;
	 {
	    obj_t arg1016_15;
	    {
	       obj_t arg1020_17;
	       {
		  obj_t aux_129;
		  aux_129 = BCHAR(((unsigned char) '\n'));
		  arg1020_17 = MAKE_PAIR(aux_129, BNIL);
	       }
	       arg1016_15 = MAKE_PAIR(string1236_cc_cc, arg1020_17);
	    }
	    arg1014_14 = MAKE_PAIR(_cc__215_engine_param, arg1016_15);
	 }
	 list1009_12 = MAKE_PAIR(string1237_cc_cc, arg1014_14);
      }
      verbose_tools_speek(BINT(((long) 1)), list1009_12);
   }
   if (STRINGP(name_3))
     {
	{
	   obj_t cc_20;
	   {
	      obj_t arg1196_60;
	      obj_t arg1197_61;
	      arg1196_60 = loop_cc_cc(_lib_dir__34_engine_param);
	      {
		 bool_t test1232_88;
		 if (CBOOL(_c_debug__136_engine_param))
		   {
		      test1232_88 = ((bool_t) 1);
		   }
		 else
		   {
		      long n1_95;
		      n1_95 = (long) CINT(_bdb_debug__1_engine_param);
		      test1232_88 = (n1_95 > ((long) 0));
		   }
		 if (test1232_88)
		   {
		      arg1197_61 = string_append(string1238_cc_cc, _c_debug_option__198_engine_param);
		   }
		 else
		   {
		      arg1197_61 = string1239_cc_cc;
		   }
	      }
	      {
		 obj_t list1201_64;
		 {
		    obj_t arg1202_65;
		    {
		       obj_t arg1203_66;
		       {
			  obj_t arg1204_67;
			  {
			     obj_t arg1205_68;
			     {
				obj_t arg1206_69;
				{
				   obj_t arg1207_70;
				   {
				      obj_t arg1209_71;
				      {
					 obj_t arg1210_72;
					 {
					    obj_t arg1211_73;
					    arg1211_73 = MAKE_PAIR(string1240_cc_cc, BNIL);
					    arg1210_72 = MAKE_PAIR(name_3, arg1211_73);
					 }
					 arg1209_71 = MAKE_PAIR(string1238_cc_cc, arg1210_72);
				      }
				      arg1207_70 = MAKE_PAIR(arg1197_61, arg1209_71);
				   }
				   arg1206_69 = MAKE_PAIR(arg1196_60, arg1207_70);
				}
				arg1205_68 = MAKE_PAIR(string1241_cc_cc, arg1206_69);
			     }
			     arg1204_67 = MAKE_PAIR(string1242_cc_cc, arg1205_68);
			  }
			  arg1203_66 = MAKE_PAIR(_cc_options__252_engine_param, arg1204_67);
		       }
		       arg1202_65 = MAKE_PAIR(string1238_cc_cc, arg1203_66);
		    }
		    list1201_64 = MAKE_PAIR(_cc__215_engine_param, arg1202_65);
		 }
		 cc_20 = string_append_106___r4_strings_6_7(list1201_64);
	      }
	   }
	   {
	      obj_t list1027_21;
	      {
		 obj_t arg1034_23;
		 {
		    obj_t arg1038_24;
		    {
		       obj_t arg1039_25;
		       {
			  obj_t aux_157;
			  aux_157 = BCHAR(((unsigned char) '\n'));
			  arg1039_25 = MAKE_PAIR(aux_157, BNIL);
		       }
		       {
			  obj_t aux_160;
			  aux_160 = BCHAR(((unsigned char) ']'));
			  arg1038_24 = MAKE_PAIR(aux_160, arg1039_25);
		       }
		    }
		    arg1034_23 = MAKE_PAIR(cc_20, arg1038_24);
		 }
		 list1027_21 = MAKE_PAIR(string1243_cc_cc, arg1034_23);
	      }
	      verbose_tools_speek(BINT(((long) 2)), list1027_21);
	   }
	   {
	      obj_t basename_27;
	      basename_27 = basename___os(name_3);
	      {
		 obj_t rm_csrc_15_28;
		 if (CBOOL(_rm_c_files__192_engine_param))
		   {
		      obj_t list1178_51;
		      {
			 obj_t arg1188_53;
			 {
			    obj_t arg1190_54;
			    arg1190_54 = MAKE_PAIR(string1240_cc_cc, BNIL);
			    arg1188_53 = MAKE_PAIR(name_3, arg1190_54);
			 }
			 list1178_51 = MAKE_PAIR(string1244_cc_cc, arg1188_53);
		      }
		      rm_csrc_15_28 = string_append_106___r4_strings_6_7(list1178_51);
		   }
		 else
		   {
		      rm_csrc_15_28 = string1239_cc_cc;
		   }
		 {
		    obj_t pwd_29;
		    {
		       obj_t vpwd_49;
		       {
			  bool_t test1190_98;
			  test1190_98 = (long) getenv("PWD");
			  if (test1190_98)
			    {
			       char *aux_176;
			       aux_176 = (char *) getenv("PWD");
			       vpwd_49 = string_to_bstring(aux_176);
			    }
			  else
			    {
			       vpwd_49 = BFALSE;
			    }
		       }
		       if (STRINGP(vpwd_49))
			 {
			    pwd_29 = vpwd_49;
			 }
		       else
			 {
			    pwd_29 = pwd___os();
			 }
		    }
		    {
		       obj_t mv_obj_214_30;
		       {
			  bool_t test1067_36;
			  {
			     bool_t test1162_46;
			     test1162_46 = bigloo_strcmp(basename_27, name_3);
			     if (test1162_46)
			       {
				  test1067_36 = ((bool_t) 0);
			       }
			     else
			       {
				  bool_t test1163_47;
				  {
				     obj_t arg1175_48;
				     arg1175_48 = dirname___os(name_3);
				     test1163_47 = bigloo_strcmp(pwd_29, arg1175_48);
				  }
				  if (test1163_47)
				    {
				       test1067_36 = ((bool_t) 0);
				    }
				  else
				    {
				       test1067_36 = ((bool_t) 1);
				    }
			       }
			  }
			  if (test1067_36)
			    {
			       obj_t list1068_37;
			       {
				  obj_t arg1137_39;
				  {
				     obj_t arg1142_40;
				     {
					obj_t arg1145_42;
					{
					   obj_t arg1150_43;
					   arg1150_43 = MAKE_PAIR(string1245_cc_cc, BNIL);
					   arg1145_42 = MAKE_PAIR(name_3, arg1150_43);
					}
					arg1142_40 = MAKE_PAIR(string1246_cc_cc, arg1145_42);
				     }
				     arg1137_39 = MAKE_PAIR(basename_27, arg1142_40);
				  }
				  list1068_37 = MAKE_PAIR(string1247_cc_cc, arg1137_39);
			       }
			       mv_obj_214_30 = string_append_106___r4_strings_6_7(list1068_37);
			    }
			  else
			    {
			       mv_obj_214_30 = string1239_cc_cc;
			    }
		       }
		       {
			  obj_t cmd_31;
			  {
			     obj_t list1041_32;
			     {
				obj_t arg1053_33;
				{
				   obj_t arg1055_34;
				   arg1055_34 = MAKE_PAIR(rm_csrc_15_28, BNIL);
				   arg1053_33 = MAKE_PAIR(mv_obj_214_30, arg1055_34);
				}
				list1041_32 = MAKE_PAIR(cc_20, arg1053_33);
			     }
			     cmd_31 = string_append_106___r4_strings_6_7(list1041_32);
			  }
			  {
			     return exec_cc_exec(cmd_31, need_to_return_234_4, string1234_cc_cc);
			  }
		       }
		    }
		 }
	      }
	   }
	}
     }
   else
     {
	FAILURE(string1234_cc_cc, string1248_cc_cc, name_3);
     }
}


/* loop */ obj_t 
loop_cc_cc(obj_t path_75)
{
   if (NULLP(path_75))
     {
	return string1239_cc_cc;
     }
   else
     {
	obj_t arg1219_79;
	obj_t arg1221_81;
	arg1219_79 = CAR(path_75);
	arg1221_81 = loop_cc_cc(CDR(path_75));
	{
	   obj_t list1222_82;
	   {
	      obj_t arg1224_83;
	      {
		 obj_t arg1225_84;
		 {
		    obj_t arg1226_85;
		    arg1226_85 = MAKE_PAIR(arg1221_81, BNIL);
		    arg1225_84 = MAKE_PAIR(string1238_cc_cc, arg1226_85);
		 }
		 arg1224_83 = MAKE_PAIR(arg1219_79, arg1225_84);
	      }
	      list1222_82 = MAKE_PAIR(string1249_cc_cc, arg1224_83);
	   }
	   return string_append_106___r4_strings_6_7(list1222_82);
	}
     }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cc_cc()
{
   module_initialization_70_tools_speek(((long) 0), "CC_CC");
   module_initialization_70_tools_file(((long) 0), "CC_CC");
   module_initialization_70_tools_error(((long) 0), "CC_CC");
   module_initialization_70_cc_exec(((long) 0), "CC_CC");
   return module_initialization_70_engine_param(((long) 0), "CC_CC");
}
