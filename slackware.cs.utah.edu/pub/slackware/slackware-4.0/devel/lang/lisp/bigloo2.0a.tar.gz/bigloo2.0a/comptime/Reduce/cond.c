/*===========================================================================*/
/*   (Reduce/cond.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_reduce_cond();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static obj_t _node_cond_1702_117_reduce_cond(obj_t, obj_t);
extern obj_t closure_ast_node;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_reduce_cond(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t _reduce_conditional__210_reduce_cond(obj_t, obj_t);
static obj_t _node_cond__default1461_103_reduce_cond(obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_reduce_cond();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_reduce_cond();
extern obj_t reduce_conditional__50_reduce_cond(obj_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_reduce_cond();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static obj_t node_cond___88_reduce_cond(obj_t);
static long _cond_reduced__35_reduce_cond;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static node_t node_cond__default1461_177_reduce_cond(node_t);
static node_t node_cond__1_reduce_cond(node_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_reduce_cond = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_reduce_cond();
static obj_t __cnst[2];

DEFINE_STATIC_PROCEDURE(node_cond__default1461_env_7_reduce_cond, _node_cond__default1461_103_reduce_cond1712, _node_cond__default1461_103_reduce_cond, 0L, 1);
DEFINE_EXPORT_PROCEDURE(reduce_conditional__env_210_reduce_cond, _reduce_conditional__210_reduce_cond1713, _reduce_conditional__210_reduce_cond, 0L, 1);
DEFINE_STATIC_GENERIC(node_cond__env_233_reduce_cond, _node_cond_1702_117_reduce_cond1714, _node_cond_1702_117_reduce_cond, 0L, 1);
DEFINE_STRING(string1706_reduce_cond, string1706_reduce_cond1715, "NODE-COND!-DEFAULT1461 DONE ", 28);
DEFINE_STRING(string1705_reduce_cond, string1705_reduce_cond1716, "No method for this object", 25);
DEFINE_STRING(string1704_reduce_cond, string1704_reduce_cond1717, "(reduced : ", 11);
DEFINE_STRING(string1703_reduce_cond, string1703_reduce_cond1718, "      conditional expression ", 29);


/* module-initialization */ obj_t 
module_initialization_70_reduce_cond(long checksum_1363, char *from_1364)
{
   if (CBOOL(require_initialization_114_reduce_cond))
     {
	require_initialization_114_reduce_cond = BBOOL(((bool_t) 0));
	library_modules_init_112_reduce_cond();
	cnst_init_137_reduce_cond();
	imported_modules_init_94_reduce_cond();
	method_init_76_reduce_cond();
	toplevel_init_63_reduce_cond();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_reduce_cond()
{
   module_initialization_70___object(((long) 0), "REDUCE_COND");
   module_initialization_70___reader(((long) 0), "REDUCE_COND");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_reduce_cond()
{
   {
      obj_t cnst_port_138_1355;
      cnst_port_138_1355 = open_input_string(string1706_reduce_cond);
      {
	 long i_1356;
	 i_1356 = ((long) 1);
       loop_1357:
	 {
	    bool_t test1707_1358;
	    test1707_1358 = (i_1356 == ((long) -1));
	    if (test1707_1358)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1708_1359;
		    {
		       obj_t list1709_1360;
		       {
			  obj_t arg1710_1361;
			  arg1710_1361 = BNIL;
			  list1709_1360 = MAKE_PAIR(cnst_port_138_1355, arg1710_1361);
		       }
		       arg1708_1359 = read___reader(list1709_1360);
		    }
		    CNST_TABLE_SET(i_1356, arg1708_1359);
		 }
		 {
		    int aux_1362;
		    {
		       long aux_1381;
		       aux_1381 = (i_1356 - ((long) 1));
		       aux_1362 = (int) (aux_1381);
		    }
		    {
		       long i_1384;
		       i_1384 = (long) (aux_1362);
		       i_1356 = i_1384;
		       goto loop_1357;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_reduce_cond()
{
   _cond_reduced__35_reduce_cond = ((long) 0);
   return BUNSPEC;
}


/* reduce-conditional! */ obj_t 
reduce_conditional__50_reduce_cond(obj_t globals_1)
{
   {
      obj_t list1485_717;
      list1485_717 = MAKE_PAIR(string1703_reduce_cond, BNIL);
      verbose_tools_speek(BINT(((long) 2)), list1485_717);
   }
   {
      obj_t l1435_720;
      l1435_720 = globals_1;
    lname1436_721:
      if (PAIRP(l1435_720))
	{
	   {
	      value_t fun_724;
	      {
		 global_t obj_1205;
		 {
		    obj_t aux_1391;
		    aux_1391 = CAR(l1435_720);
		    obj_1205 = (global_t) (aux_1391);
		 }
		 fun_724 = (((global_t) CREF(obj_1205))->value);
	      }
	      {
		 {
		    node_t arg1489_726;
		    {
		       node_t aux_1395;
		       {
			  obj_t aux_1396;
			  {
			     sfun_t obj_1206;
			     obj_1206 = (sfun_t) (fun_724);
			     aux_1396 = (((sfun_t) CREF(obj_1206))->body);
			  }
			  aux_1395 = (node_t) (aux_1396);
		       }
		       arg1489_726 = node_cond__1_reduce_cond(aux_1395);
		    }
		    {
		       sfun_t obj_1207;
		       obj_t val1135_1208;
		       obj_1207 = (sfun_t) (fun_724);
		       val1135_1208 = (obj_t) (arg1489_726);
		       ((((sfun_t) CREF(obj_1207))->body) = ((obj_t) val1135_1208), BUNSPEC);
		    }
		 }
		 BUNSPEC;
	      }
	   }
	   {
	      obj_t l1435_1404;
	      l1435_1404 = CDR(l1435_720);
	      l1435_720 = l1435_1404;
	      goto lname1436_721;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t list1491_728;
      {
	 obj_t arg1496_730;
	 {
	    obj_t arg1497_731;
	    {
	       obj_t arg1498_732;
	       {
		  obj_t aux_1406;
		  aux_1406 = BCHAR(((unsigned char) '\n'));
		  arg1498_732 = MAKE_PAIR(aux_1406, BNIL);
	       }
	       {
		  obj_t aux_1409;
		  aux_1409 = BCHAR(((unsigned char) ')'));
		  arg1497_731 = MAKE_PAIR(aux_1409, arg1498_732);
	       }
	    }
	    {
	       obj_t aux_1412;
	       aux_1412 = BINT(_cond_reduced__35_reduce_cond);
	       arg1496_730 = MAKE_PAIR(aux_1412, arg1497_731);
	    }
	 }
	 list1491_728 = MAKE_PAIR(string1704_reduce_cond, arg1496_730);
      }
      verbose_tools_speek(BINT(((long) 2)), list1491_728);
   }
   return globals_1;
}


/* _reduce-conditional! */ obj_t 
_reduce_conditional__210_reduce_cond(obj_t env_1349, obj_t globals_1350)
{
   return reduce_conditional__50_reduce_cond(globals_1350);
}


/* node-cond*! */ obj_t 
node_cond___88_reduce_cond(obj_t node__221_25)
{
   {
      obj_t node__221_734;
      node__221_734 = node__221_25;
    loop_735:
      if (NULLP(node__221_734))
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   {
	      node_t arg1501_737;
	      {
		 node_t aux_1422;
		 {
		    obj_t aux_1423;
		    aux_1423 = CAR(node__221_734);
		    aux_1422 = (node_t) (aux_1423);
		 }
		 arg1501_737 = node_cond__1_reduce_cond(aux_1422);
	      }
	      {
		 obj_t aux_1427;
		 aux_1427 = (obj_t) (arg1501_737);
		 SET_CAR(node__221_734, aux_1427);
	      }
	   }
	   {
	      obj_t node__221_1430;
	      node__221_1430 = CDR(node__221_734);
	      node__221_734 = node__221_1430;
	      goto loop_735;
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_reduce_cond()
{
   add_generic__110___object(node_cond__env_233_reduce_cond, node_cond__default1461_env_7_reduce_cond);
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, var_ast_node, ((long) 2));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, app_ast_node, ((long) 5));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, select_ast_node, ((long) 13));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(node_cond__env_233_reduce_cond, box_set__221_ast_node, ((long) 19));
   {
      long aux_1453;
      aux_1453 = add_inlined_method__244___object(node_cond__env_233_reduce_cond, box_ref_242_ast_node, ((long) 20));
      return BINT(aux_1453);
   }
}


/* node-cond! */ node_t 
node_cond__1_reduce_cond(node_t node_2)
{
   {
      obj_t method1601_1071;
      obj_t class1606_1072;
      {
	 obj_t arg1609_1069;
	 obj_t arg1610_1070;
	 {
	    object_t obj_1215;
	    obj_1215 = (object_t) (node_2);
	    {
	       obj_t pre_method_105_1216;
	       pre_method_105_1216 = PROCEDURE_REF(node_cond__env_233_reduce_cond, ((long) 2));
	       if (INTEGERP(pre_method_105_1216))
		 {
		    PROCEDURE_SET(node_cond__env_233_reduce_cond, ((long) 2), BUNSPEC);
		    arg1609_1069 = pre_method_105_1216;
		 }
	       else
		 {
		    long obj_class_num_177_1221;
		    obj_class_num_177_1221 = TYPE(obj_1215);
		    {
		       obj_t arg1177_1222;
		       arg1177_1222 = PROCEDURE_REF(node_cond__env_233_reduce_cond, ((long) 1));
		       {
			  long arg1178_1226;
			  {
			     long arg1179_1227;
			     arg1179_1227 = OBJECT_TYPE;
			     arg1178_1226 = (obj_class_num_177_1221 - arg1179_1227);
			  }
			  arg1609_1069 = VECTOR_REF(arg1177_1222, arg1178_1226);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1232;
	    object_1232 = (object_t) (node_2);
	    {
	       long arg1180_1233;
	       {
		  long arg1181_1234;
		  long arg1182_1235;
		  arg1181_1234 = TYPE(object_1232);
		  arg1182_1235 = OBJECT_TYPE;
		  arg1180_1233 = (arg1181_1234 - arg1182_1235);
	       }
	       {
		  obj_t vector_1239;
		  vector_1239 = _classes__134___object;
		  arg1610_1070 = VECTOR_REF(vector_1239, arg1180_1233);
	       }
	    }
	 }
	 {
	    obj_t aux_1471;
	    method1601_1071 = arg1609_1069;
	    class1606_1072 = arg1610_1070;
	    {
	       if (INTEGERP(method1601_1071))
		 {
		    switch ((long) CINT(method1601_1071))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_1474;
			    aux_1474 = (atom_t) (node_2);
			    aux_1471 = (obj_t) (aux_1474);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_1477;
			    aux_1477 = (kwote_t) (node_2);
			    aux_1471 = (obj_t) (aux_1477);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t aux_1480;
			    aux_1480 = (var_t) (node_2);
			    aux_1471 = (obj_t) (aux_1480);
			 }
			 break;
		      case ((long) 3):
			 {
			    closure_t aux_1483;
			    aux_1483 = (closure_t) (node_2);
			    aux_1471 = (obj_t) (aux_1483);
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1082;
			    node_1082 = (sequence_t) (node_2);
			    node_cond___88_reduce_cond((((sequence_t) CREF(node_1082))->nodes));
			    aux_1471 = (obj_t) (node_1082);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_t node_1085;
			    node_1085 = (app_t) (node_2);
			    node_cond___88_reduce_cond((((app_t) CREF(node_1085))->args));
			    aux_1471 = (obj_t) (node_1085);
			 }
			 break;
		      case ((long) 6):
			 {
			    app_ly_162_t node_1088;
			    node_1088 = (app_ly_162_t) (node_2);
			    {
			       node_t arg1617_1090;
			       arg1617_1090 = node_cond__1_reduce_cond((((app_ly_162_t) CREF(node_1088))->fun));
			       ((((app_ly_162_t) CREF(node_1088))->fun) = ((node_t) arg1617_1090), BUNSPEC);
			    }
			    {
			       node_t arg1620_1092;
			       arg1620_1092 = node_cond__1_reduce_cond((((app_ly_162_t) CREF(node_1088))->arg));
			       ((((app_ly_162_t) CREF(node_1088))->arg) = ((node_t) arg1620_1092), BUNSPEC);
			    }
			    aux_1471 = (obj_t) (node_1088);
			 }
			 break;
		      case ((long) 7):
			 {
			    funcall_t node_1094;
			    node_1094 = (funcall_t) (node_2);
			    {
			       node_t arg1622_1096;
			       arg1622_1096 = node_cond__1_reduce_cond((((funcall_t) CREF(node_1094))->fun));
			       ((((funcall_t) CREF(node_1094))->fun) = ((node_t) arg1622_1096), BUNSPEC);
			    }
			    node_cond___88_reduce_cond((((funcall_t) CREF(node_1094))->args));
			    aux_1471 = (obj_t) (node_1094);
			 }
			 break;
		      case ((long) 8):
			 {
			    pragma_t node_1099;
			    node_1099 = (pragma_t) (node_2);
			    node_cond___88_reduce_cond((((pragma_t) CREF(node_1099))->args));
			    aux_1471 = (obj_t) (node_1099);
			 }
			 break;
		      case ((long) 9):
			 {
			    cast_t node_1102;
			    node_1102 = (cast_t) (node_2);
			    node_cond__1_reduce_cond((((cast_t) CREF(node_1102))->arg));
			    aux_1471 = (obj_t) (node_1102);
			 }
			 break;
		      case ((long) 10):
			 {
			    setq_t node_1105;
			    node_1105 = (setq_t) (node_2);
			    {
			       node_t arg1628_1107;
			       arg1628_1107 = node_cond__1_reduce_cond((((setq_t) CREF(node_1105))->value));
			       ((((setq_t) CREF(node_1105))->value) = ((node_t) arg1628_1107), BUNSPEC);
			    }
			    {
			       node_t arg1632_1109;
			       {
				  node_t aux_1521;
				  {
				     var_t aux_1522;
				     aux_1522 = (((setq_t) CREF(node_1105))->var);
				     aux_1521 = (node_t) (aux_1522);
				  }
				  arg1632_1109 = node_cond__1_reduce_cond(aux_1521);
			       }
			       {
				  var_t val1306_1260;
				  val1306_1260 = (var_t) (arg1632_1109);
				  ((((setq_t) CREF(node_1105))->var) = ((var_t) val1306_1260), BUNSPEC);
			       }
			    }
			    aux_1471 = (obj_t) (node_1105);
			 }
			 break;
		      case ((long) 11):
			 {
			    conditional_t node_1111;
			    node_1111 = (conditional_t) (node_2);
			    {
			       node_t arg1634_1113;
			       arg1634_1113 = node_cond__1_reduce_cond((((conditional_t) CREF(node_1111))->test));
			       ((((conditional_t) CREF(node_1111))->test) = ((node_t) arg1634_1113), BUNSPEC);
			    }
			    {
			       node_t arg1638_1115;
			       arg1638_1115 = node_cond__1_reduce_cond((((conditional_t) CREF(node_1111))->true));
			       ((((conditional_t) CREF(node_1111))->true) = ((node_t) arg1638_1115), BUNSPEC);
			    }
			    {
			       node_t arg1640_1117;
			       arg1640_1117 = node_cond__1_reduce_cond((((conditional_t) CREF(node_1111))->false));
			       ((((conditional_t) CREF(node_1111))->false) = ((node_t) arg1640_1117), BUNSPEC);
			    }
			    {
			       bool_t test1642_1119;
			       {
				  obj_t aux_1539;
				  {
				     node_t aux_1540;
				     aux_1540 = (((conditional_t) CREF(node_1111))->test);
				     aux_1539 = (obj_t) (aux_1540);
				  }
				  test1642_1119 = is_a__118___object(aux_1539, atom_ast_node);
			       }
			       if (test1642_1119)
				 {
				    {
				       long z2_1273;
				       z2_1273 = _cond_reduced__35_reduce_cond;
				       _cond_reduced__35_reduce_cond = (((long) 1) + z2_1273);
				    }
				    {
				       bool_t test_1546;
				       {
					  atom_t obj_1275;
					  {
					     node_t aux_1547;
					     aux_1547 = (((conditional_t) CREF(node_1111))->test);
					     obj_1275 = (atom_t) (aux_1547);
					  }
					  {
					     obj_t aux_1550;
					     aux_1550 = (((atom_t) CREF(obj_1275))->value);
					     test_1546 = CBOOL(aux_1550);
					  }
				       }
				       if (test_1546)
					 {
					    node_t aux_1553;
					    aux_1553 = (((conditional_t) CREF(node_1111))->true);
					    aux_1471 = (obj_t) (aux_1553);
					 }
				       else
					 {
					    node_t aux_1556;
					    aux_1556 = (((conditional_t) CREF(node_1111))->false);
					    aux_1471 = (obj_t) (aux_1556);
					 }
				    }
				 }
			       else
				 {
				    aux_1471 = (obj_t) (node_1111);
				 }
			    }
			 }
			 break;
		      case ((long) 12):
			 {
			    fail_t node_1123;
			    node_1123 = (fail_t) (node_2);
			    {
			       node_t arg1647_1125;
			       arg1647_1125 = node_cond__1_reduce_cond((((fail_t) CREF(node_1123))->proc));
			       ((((fail_t) CREF(node_1123))->proc) = ((node_t) arg1647_1125), BUNSPEC);
			    }
			    {
			       node_t arg1649_1127;
			       arg1649_1127 = node_cond__1_reduce_cond((((fail_t) CREF(node_1123))->msg));
			       ((((fail_t) CREF(node_1123))->msg) = ((node_t) arg1649_1127), BUNSPEC);
			    }
			    {
			       node_t arg1652_1129;
			       arg1652_1129 = node_cond__1_reduce_cond((((fail_t) CREF(node_1123))->obj));
			       ((((fail_t) CREF(node_1123))->obj) = ((node_t) arg1652_1129), BUNSPEC);
			    }
			    aux_1471 = (obj_t) (node_1123);
			 }
			 break;
		      case ((long) 13):
			 {
			    select_t node_1131;
			    node_1131 = (select_t) (node_2);
			    {
			       node_t arg1654_1133;
			       arg1654_1133 = node_cond__1_reduce_cond((((select_t) CREF(node_1131))->test));
			       ((((select_t) CREF(node_1131))->test) = ((node_t) arg1654_1133), BUNSPEC);
			    }
			    {
			       obj_t l1447_1135;
			       l1447_1135 = (((select_t) CREF(node_1131))->clauses);
			     lname1448_1136:
			       if (PAIRP(l1447_1135))
				 {
				    {
				       obj_t clause_1139;
				       clause_1139 = CAR(l1447_1135);
				       {
					  node_t arg1658_1140;
					  {
					     node_t aux_1578;
					     {
						obj_t aux_1579;
						aux_1579 = CDR(clause_1139);
						aux_1578 = (node_t) (aux_1579);
					     }
					     arg1658_1140 = node_cond__1_reduce_cond(aux_1578);
					  }
					  {
					     obj_t aux_1583;
					     aux_1583 = (obj_t) (arg1658_1140);
					     SET_CDR(clause_1139, aux_1583);
					  }
				       }
				    }
				    {
				       obj_t l1447_1586;
				       l1447_1586 = CDR(l1447_1135);
				       l1447_1135 = l1447_1586;
				       goto lname1448_1136;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_1471 = (obj_t) (node_1131);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_fun_218_t node_1143;
			    node_1143 = (let_fun_218_t) (node_2);
			    {
			       obj_t l1450_1145;
			       l1450_1145 = (((let_fun_218_t) CREF(node_1143))->locals);
			     lname1451_1146:
			       if (PAIRP(l1450_1145))
				 {
				    {
				       value_t fun_1150;
				       {
					  local_t obj_1300;
					  {
					     obj_t aux_1593;
					     aux_1593 = CAR(l1450_1145);
					     obj_1300 = (local_t) (aux_1593);
					  }
					  fun_1150 = (((local_t) CREF(obj_1300))->value);
				       }
				       {
					  node_t arg1665_1151;
					  {
					     node_t aux_1597;
					     {
						obj_t aux_1598;
						{
						   sfun_t obj_1301;
						   obj_1301 = (sfun_t) (fun_1150);
						   aux_1598 = (((sfun_t) CREF(obj_1301))->body);
						}
						aux_1597 = (node_t) (aux_1598);
					     }
					     arg1665_1151 = node_cond__1_reduce_cond(aux_1597);
					  }
					  {
					     sfun_t obj_1302;
					     obj_t val1135_1303;
					     obj_1302 = (sfun_t) (fun_1150);
					     val1135_1303 = (obj_t) (arg1665_1151);
					     ((((sfun_t) CREF(obj_1302))->body) = ((obj_t) val1135_1303), BUNSPEC);
					  }
				       }
				    }
				    {
				       obj_t l1450_1606;
				       l1450_1606 = CDR(l1450_1145);
				       l1450_1145 = l1450_1606;
				       goto lname1451_1146;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1668_1154;
			       arg1668_1154 = node_cond__1_reduce_cond((((let_fun_218_t) CREF(node_1143))->body));
			       ((((let_fun_218_t) CREF(node_1143))->body) = ((node_t) arg1668_1154), BUNSPEC);
			    }
			    aux_1471 = (obj_t) (node_1143);
			 }
			 break;
		      case ((long) 15):
			 {
			    let_var_6_t node_1156;
			    node_1156 = (let_var_6_t) (node_2);
			    {
			       obj_t l1453_1158;
			       l1453_1158 = (((let_var_6_t) CREF(node_1156))->bindings);
			     lname1454_1159:
			       if (PAIRP(l1453_1158))
				 {
				    {
				       obj_t binding_1162;
				       binding_1162 = CAR(l1453_1158);
				       {
					  node_t arg1672_1163;
					  {
					     node_t aux_1617;
					     {
						obj_t aux_1618;
						aux_1618 = CDR(binding_1162);
						aux_1617 = (node_t) (aux_1618);
					     }
					     arg1672_1163 = node_cond__1_reduce_cond(aux_1617);
					  }
					  {
					     obj_t aux_1622;
					     aux_1622 = (obj_t) (arg1672_1163);
					     SET_CDR(binding_1162, aux_1622);
					  }
				       }
				    }
				    {
				       obj_t l1453_1625;
				       l1453_1625 = CDR(l1453_1158);
				       l1453_1158 = l1453_1625;
				       goto lname1454_1159;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1676_1166;
			       arg1676_1166 = node_cond__1_reduce_cond((((let_var_6_t) CREF(node_1156))->body));
			       ((((let_var_6_t) CREF(node_1156))->body) = ((node_t) arg1676_1166), BUNSPEC);
			    }
			    aux_1471 = (obj_t) (node_1156);
			 }
			 break;
		      case ((long) 16):
			 {
			    set_ex_it_116_t node_1168;
			    node_1168 = (set_ex_it_116_t) (node_2);
			    {
			       node_t arg1678_1170;
			       arg1678_1170 = node_cond__1_reduce_cond((((set_ex_it_116_t) CREF(node_1168))->body));
			       ((((set_ex_it_116_t) CREF(node_1168))->body) = ((node_t) arg1678_1170), BUNSPEC);
			    }
			    {
			       node_t arg1680_1172;
			       {
				  node_t aux_1636;
				  {
				     var_t aux_1637;
				     aux_1637 = (((set_ex_it_116_t) CREF(node_1168))->var);
				     aux_1636 = (node_t) (aux_1637);
				  }
				  arg1680_1172 = node_cond__1_reduce_cond(aux_1636);
			       }
			       {
				  var_t val1388_1323;
				  val1388_1323 = (var_t) (arg1680_1172);
				  ((((set_ex_it_116_t) CREF(node_1168))->var) = ((var_t) val1388_1323), BUNSPEC);
			       }
			    }
			    aux_1471 = (obj_t) (node_1168);
			 }
			 break;
		      case ((long) 17):
			 {
			    jump_ex_it_184_t node_1174;
			    node_1174 = (jump_ex_it_184_t) (node_2);
			    {
			       node_t arg1682_1176;
			       arg1682_1176 = node_cond__1_reduce_cond((((jump_ex_it_184_t) CREF(node_1174))->exit));
			       ((((jump_ex_it_184_t) CREF(node_1174))->exit) = ((node_t) arg1682_1176), BUNSPEC);
			    }
			    {
			       node_t arg1684_1178;
			       arg1684_1178 = node_cond__1_reduce_cond((((jump_ex_it_184_t) CREF(node_1174))->value));
			       ((((jump_ex_it_184_t) CREF(node_1174))->value) = ((node_t) arg1684_1178), BUNSPEC);
			    }
			    aux_1471 = (obj_t) (node_1174);
			 }
			 break;
		      case ((long) 18):
			 {
			    make_box_202_t node_1180;
			    node_1180 = (make_box_202_t) (node_2);
			    {
			       node_t arg1686_1182;
			       arg1686_1182 = node_cond__1_reduce_cond((((make_box_202_t) CREF(node_1180))->value));
			       ((((make_box_202_t) CREF(node_1180))->value) = ((node_t) arg1686_1182), BUNSPEC);
			    }
			    aux_1471 = (obj_t) (node_1180);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_set__221_t node_1184;
			    node_1184 = (box_set__221_t) (node_2);
			    {
			       node_t arg1689_1186;
			       {
				  node_t aux_1658;
				  {
				     var_t aux_1659;
				     aux_1659 = (((box_set__221_t) CREF(node_1184))->var);
				     aux_1658 = (node_t) (aux_1659);
				  }
				  arg1689_1186 = node_cond__1_reduce_cond(aux_1658);
			       }
			       {
				  var_t val1432_1335;
				  val1432_1335 = (var_t) (arg1689_1186);
				  ((((box_set__221_t) CREF(node_1184))->var) = ((var_t) val1432_1335), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1692_1188;
			       arg1692_1188 = node_cond__1_reduce_cond((((box_set__221_t) CREF(node_1184))->value));
			       ((((box_set__221_t) CREF(node_1184))->value) = ((node_t) arg1692_1188), BUNSPEC);
			    }
			    aux_1471 = (obj_t) (node_1184);
			 }
			 break;
		      case ((long) 20):
			 {
			    box_ref_242_t node_1190;
			    node_1190 = (box_ref_242_t) (node_2);
			    {
			       node_t arg1694_1192;
			       {
				  node_t aux_1670;
				  {
				     var_t aux_1671;
				     aux_1671 = (((box_ref_242_t) CREF(node_1190))->var);
				     aux_1670 = (node_t) (aux_1671);
				  }
				  arg1694_1192 = node_cond__1_reduce_cond(aux_1670);
			       }
			       {
				  var_t val1423_1341;
				  val1423_1341 = (var_t) (arg1694_1192);
				  ((((box_ref_242_t) CREF(node_1190))->var) = ((var_t) val1423_1341), BUNSPEC);
			       }
			    }
			    aux_1471 = (obj_t) (node_1190);
			 }
			 break;
		      default:
		       case_else1607_1075:
			 if (PROCEDUREP(method1601_1071))
			   {
			      aux_1471 = PROCEDURE_ENTRY(method1601_1071) (method1601_1071, (obj_t) (node_2), BEOA);
			   }
			 else
			   {
			      obj_t fun1596_1065;
			      fun1596_1065 = PROCEDURE_REF(node_cond__env_233_reduce_cond, ((long) 0));
			      aux_1471 = PROCEDURE_ENTRY(fun1596_1065) (fun1596_1065, (obj_t) (node_2), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1607_1075;
		 }
	    }
	    return (node_t) (aux_1471);
	 }
      }
   }
}


/* _node-cond!1702 */ obj_t 
_node_cond_1702_117_reduce_cond(obj_t env_1351, obj_t node_1352)
{
   {
      node_t aux_1690;
      aux_1690 = node_cond__1_reduce_cond((node_t) (node_1352));
      return (obj_t) (aux_1690);
   }
}


/* node-cond!-default1461 */ node_t 
node_cond__default1461_177_reduce_cond(node_t node_3)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string1705_reduce_cond, (obj_t) (node_3));
}


/* _node-cond!-default1461 */ obj_t 
_node_cond__default1461_103_reduce_cond(obj_t env_1353, obj_t node_1354)
{
   {
      node_t aux_1697;
      aux_1697 = node_cond__default1461_177_reduce_cond((node_t) (node_1354));
      return (obj_t) (aux_1697);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_reduce_cond()
{
   module_initialization_70_tools_trace(((long) 0), "REDUCE_COND");
   module_initialization_70_tools_shape(((long) 0), "REDUCE_COND");
   module_initialization_70_tools_speek(((long) 0), "REDUCE_COND");
   module_initialization_70_tools_error(((long) 0), "REDUCE_COND");
   module_initialization_70_type_type(((long) 0), "REDUCE_COND");
   module_initialization_70_ast_var(((long) 0), "REDUCE_COND");
   return module_initialization_70_ast_node(((long) 0), "REDUCE_COND");
}
