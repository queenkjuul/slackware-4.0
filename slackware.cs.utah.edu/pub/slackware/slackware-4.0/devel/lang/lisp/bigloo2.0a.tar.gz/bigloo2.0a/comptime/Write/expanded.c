/*===========================================================================*/
/*   (Write/expanded.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t _src_files__222_engine_param;
static obj_t method_init_76_write_expanded();
extern obj_t current_output_port;
extern obj_t string_append(obj_t, obj_t);
extern obj_t write_scheme_comment_102_write_scheme(obj_t, obj_t);
static obj_t _write_expanded_29_write_expanded(obj_t, obj_t);
static obj_t handling_function1158_write_expanded(obj_t, obj_t);
extern obj_t module_initialization_70_write_expanded(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_write_scheme(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70_ast_unit(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___pp(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t write_expanded_48_write_expanded(obj_t);
static obj_t imported_modules_init_94_write_expanded();
extern obj_t _pp_case__242___pp;
extern obj_t _dest__217_engine_param;
extern obj_t prefix___os(obj_t);
extern obj_t _module_clause__117_module_module;
static obj_t library_modules_init_112_write_expanded();
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t toplevel_init_63_write_expanded();
extern obj_t open_input_string(obj_t);
extern obj_t close_output_port(obj_t);
extern obj_t pp___pp(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t open_output_file(obj_t);
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114_write_expanded = BUNSPEC;
extern obj_t write_scheme_file_header_174_write_scheme(obj_t, obj_t);
static obj_t cnst_init_137_write_expanded();
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(write_expanded_env_164_write_expanded, _write_expanded_29_write_expanded1288, _write_expanded_29_write_expanded, 0L, 1);
DEFINE_STRING(string1282_write_expanded, string1282_write_expanded1289, "DEFINE-INLINE DEFINE LOWER --TO-STDOUT ", 39);
DEFINE_STRING(string1281_write_expanded, string1281_write_expanded1290, "unit: ", 6);
DEFINE_STRING(string1279_write_expanded, string1279_write_expanded1291, "The expanded module", 19);
DEFINE_STRING(string1280_write_expanded, string1280_write_expanded1292, "The module clause", 17);
DEFINE_STRING(string1278_write_expanded, string1278_write_expanded1293, "Can't open output file", 22);
DEFINE_STRING(string1277_write_expanded, string1277_write_expanded1294, "write-expanded", 14);
DEFINE_STRING(string1276_write_expanded, string1276_write_expanded1295, ".escm", 5);


/* module-initialization */ obj_t 
module_initialization_70_write_expanded(long checksum_312, char *from_313)
{
   if (CBOOL(require_initialization_114_write_expanded))
     {
	require_initialization_114_write_expanded = BBOOL(((bool_t) 0));
	library_modules_init_112_write_expanded();
	cnst_init_137_write_expanded();
	imported_modules_init_94_write_expanded();
	method_init_76_write_expanded();
	toplevel_init_63_write_expanded();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_write_expanded()
{
   module_initialization_70___bexit(((long) 0), "WRITE_EXPANDED");
   module_initialization_70___pp(((long) 0), "WRITE_EXPANDED");
   module_initialization_70___os(((long) 0), "WRITE_EXPANDED");
   module_initialization_70___r4_output_6_10_3(((long) 0), "WRITE_EXPANDED");
   module_initialization_70___reader(((long) 0), "WRITE_EXPANDED");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_write_expanded()
{
   {
      obj_t cnst_port_138_304;
      cnst_port_138_304 = open_input_string(string1282_write_expanded);
      {
	 long i_305;
	 i_305 = ((long) 3);
       loop_306:
	 {
	    bool_t test1283_307;
	    test1283_307 = (i_305 == ((long) -1));
	    if (test1283_307)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1284_308;
		    {
		       obj_t list1285_309;
		       {
			  obj_t arg1286_310;
			  arg1286_310 = BNIL;
			  list1285_309 = MAKE_PAIR(cnst_port_138_304, arg1286_310);
		       }
		       arg1284_308 = read___reader(list1285_309);
		    }
		    CNST_TABLE_SET(i_305, arg1284_308);
		 }
		 {
		    int aux_311;
		    {
		       long aux_333;
		       aux_333 = (i_305 - ((long) 1));
		       aux_311 = (int) (aux_333);
		    }
		    {
		       long i_336;
		       i_336 = (long) (aux_311);
		       i_305 = i_336;
		       goto loop_306;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_write_expanded()
{
   return BUNSPEC;
}


/* write-expanded */ obj_t 
write_expanded_48_write_expanded(obj_t units_19)
{
   {
      obj_t output_name_205_48;
      {
	 bool_t test1262_160;
	 {
	    obj_t obj_197;
	    obj_197 = _dest__217_engine_param;
	    test1262_160 = STRINGP(obj_197);
	 }
	 if (test1262_160)
	   {
	      output_name_205_48 = _dest__217_engine_param;
	   }
	 else
	   {
	      bool_t test1263_161;
	      {
		 obj_t obj1_198;
		 obj1_198 = _dest__217_engine_param;
		 {
		    obj_t aux_340;
		    aux_340 = CNST_TABLE_REF(((long) 0));
		    test1263_161 = (obj1_198 == aux_340);
		 }
	      }
	      if (test1263_161)
		{
		   output_name_205_48 = BFALSE;
		}
	      else
		{
		   bool_t test1264_162;
		   {
		      bool_t test1269_166;
		      {
			 obj_t obj_200;
			 obj_200 = _src_files__222_engine_param;
			 test1269_166 = PAIRP(obj_200);
		      }
		      if (test1269_166)
			{
			   obj_t arg1270_167;
			   {
			      obj_t pair_201;
			      pair_201 = _src_files__222_engine_param;
			      arg1270_167 = CAR(pair_201);
			   }
			   test1264_162 = STRINGP(arg1270_167);
			}
		      else
			{
			   test1264_162 = ((bool_t) 0);
			}
		   }
		   if (test1264_162)
		     {
			{
			   obj_t arg1265_163;
			   {
			      obj_t arg1268_165;
			      {
				 obj_t pair_203;
				 pair_203 = _src_files__222_engine_param;
				 arg1268_165 = CAR(pair_203);
			      }
			      arg1265_163 = prefix___os(arg1268_165);
			   }
			   output_name_205_48 = string_append(arg1265_163, string1276_write_expanded);
			}
		     }
		   else
		     {
			output_name_205_48 = BFALSE;
		     }
		}
	   }
      }
      {
	 obj_t port_49;
	 if (STRINGP(output_name_205_48))
	   {
	      port_49 = open_output_file(output_name_205_48);
	   }
	 else
	   {
	      port_49 = current_output_port;
	   }
	 {
	    {
	       bool_t test1139_50;
	       test1139_50 = OUTPUT_PORTP(port_49);
	       if (test1139_50)
		 {
		    obj_t val1010_51;
		    val1010_51 = handling_function1158_write_expanded(units_19, port_49);
		    {
		       bool_t test_358;
		       if (test1139_50)
			 {
			    if ((port_49 == current_output_port))
			      {
				 test_358 = ((bool_t) 0);
			      }
			    else
			      {
				 test_358 = ((bool_t) 1);
			      }
			 }
		       else
			 {
			    test_358 = ((bool_t) 0);
			 }
		       if (test_358)
			 {
			    close_output_port(port_49);
			 }
		       else
			 {
			    BUNSPEC;
			 }
		    }
		    {
		       bool_t test1146_56;
		       {
			  obj_t aux_363;
			  aux_363 = val_from_exit__100___bexit(val1010_51);
			  test1146_56 = CBOOL(aux_363);
		       }
		       if (test1146_56)
			 {
			    return unwind_until__178___bexit(CAR(val1010_51), CDR(val1010_51));
			 }
		       else
			 {
			    return val1010_51;
			 }
		    }
		 }
	       else
		 {
		    FAILURE(string1277_write_expanded, string1278_write_expanded, output_name_205_48);
		 }
	    }
	 }
      }
   }
}


/* handling_function1158 */ obj_t 
handling_function1158_write_expanded(obj_t units_302, obj_t port_301)
{
   jmp_buf jmpbuf;
   obj_t an_exit1011_60;
   if (SET_EXIT(an_exit1011_60))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1011_60 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1011_60, ((bool_t) 0));
	   {
	      bool_t val1012_61;
	      _pp_case__242___pp = CNST_TABLE_REF(((long) 1));
	      write_scheme_file_header_174_write_scheme(port_301, string1279_write_expanded);
	      {
		 obj_t list1159_62;
		 list1159_62 = MAKE_PAIR(string1280_write_expanded, BNIL);
		 write_scheme_comment_102_write_scheme(port_301, list1159_62);
	      }
	      {
		 obj_t list1164_65;
		 list1164_65 = MAKE_PAIR(port_301, BNIL);
		 pp___pp(_module_clause__117_module_module, list1164_65);
	      }
	      {
		 obj_t list1176_67;
		 list1176_67 = MAKE_PAIR(port_301, BNIL);
		 newline___r4_output_6_10_3(list1176_67);
	      }
	      {
		 obj_t l1013_69;
		 l1013_69 = units_302;
	       lname1014_70:
		 if (PAIRP(l1013_69))
		   {
		      {
			 obj_t u_72;
			 u_72 = CAR(l1013_69);
			 {
			    bool_t test_385;
			    {
			       obj_t aux_386;
			       aux_386 = STRUCT_REF(u_72, ((long) 3));
			       test_385 = CBOOL(aux_386);
			    }
			    if (test_385)
			      {
				 {
				    bool_t test_389;
				    {
				       obj_t aux_390;
				       aux_390 = STRUCT_REF(u_72, ((long) 2));
				       test_389 = PAIRP(aux_390);
				    }
				    if (test_389)
				      {
					 obj_t arg1193_75;
					 {
					    obj_t arg1197_79;
					    {
					       obj_t aux_393;
					       aux_393 = STRUCT_REF(u_72, ((long) 0));
					       arg1197_79 = SYMBOL_TO_STRING(aux_393);
					    }
					    arg1193_75 = string_append(string1281_write_expanded, arg1197_79);
					 }
					 {
					    obj_t list1194_76;
					    list1194_76 = MAKE_PAIR(arg1193_75, BNIL);
					    write_scheme_comment_102_write_scheme(port_301, list1194_76);
					 }
				      }
				    else
				      {
					 BUNSPEC;
				      }
				 }
				 {
				    obj_t l1015_82;
				    {
				       obj_t arg1201_84;
				       {
					  obj_t code_85;
					  code_85 = STRUCT_REF(u_72, ((long) 2));
					  if (PROCEDUREP(code_85))
					    {
					       arg1201_84 = PROCEDURE_ENTRY(code_85) (code_85, BEOA);
					    }
					  else
					    {
					       arg1201_84 = code_85;
					    }
				       }
				       l1015_82 = arg1201_84;
				     lname1016_83:
				       if (PAIRP(l1015_82))
					 {
					    {
					       obj_t code_88;
					       code_88 = CAR(l1015_82);
					       {
						  obj_t name_93;
						  obj_t value_94;
						  if (PAIRP(code_88))
						    {
						       obj_t cdr_113_28_103;
						       cdr_113_28_103 = CDR(code_88);
						       {
							  bool_t test_410;
							  {
							     obj_t aux_413;
							     obj_t aux_411;
							     aux_413 = CNST_TABLE_REF(((long) 2));
							     aux_411 = CAR(code_88);
							     test_410 = (aux_411 == aux_413);
							  }
							  if (test_410)
							    {
							       if (PAIRP(cdr_113_28_103))
								 {
								    obj_t car_117_76_106;
								    obj_t cdr_118_57_107;
								    car_117_76_106 = CAR(cdr_113_28_103);
								    cdr_118_57_107 = CDR(cdr_113_28_103);
								    if (PAIRP(car_117_76_106))
								      {
									 if (PAIRP(cdr_118_57_107))
									   {
									      bool_t test_424;
									      {
										 obj_t aux_425;
										 aux_425 = CDR(cdr_118_57_107);
										 test_424 = (aux_425 == BNIL);
									      }
									      if (test_424)
										{
										   {
										      obj_t list1241_246;
										      {
											 obj_t aux_428;
											 aux_428 = CAR(car_117_76_106);
											 list1241_246 = MAKE_PAIR(aux_428, BNIL);
										      }
										      write_scheme_comment_102_write_scheme(port_301, list1241_246);
										   }
										   {
										      obj_t list1244_248;
										      list1244_248 = MAKE_PAIR(port_301, BNIL);
										      pp___pp(code_88, list1244_248);
										   }
										}
									      else
										{
										 tag_104_254_100:
										   {
										      obj_t list1255_153;
										      list1255_153 = MAKE_PAIR(port_301, BNIL);
										      pp___pp(code_88, list1255_153);
										   }
										}
									   }
									 else
									   {
									      goto tag_104_254_100;
									   }
								      }
								    else
								      {
									 obj_t cdr_162_110_117;
									 cdr_162_110_117 = CDR(cdr_113_28_103);
									 if (PAIRP(cdr_162_110_117))
									   {
									      bool_t test_439;
									      {
										 obj_t aux_440;
										 aux_440 = CDR(cdr_162_110_117);
										 test_439 = (aux_440 == BNIL);
									      }
									      if (test_439)
										{
										   name_93 = CAR(cdr_113_28_103);
										   value_94 = CAR(cdr_162_110_117);
										   {
										      obj_t list1246_145;
										      list1246_145 = MAKE_PAIR(name_93, BNIL);
										      write_scheme_comment_102_write_scheme(port_301, list1246_145);
										   }
										   {
										      obj_t list1248_147;
										      list1248_147 = MAKE_PAIR(port_301, BNIL);
										      pp___pp(code_88, list1248_147);
										   }
										}
									      else
										{
										   goto tag_104_254_100;
										}
									   }
									 else
									   {
									      goto tag_104_254_100;
									   }
								      }
								 }
							       else
								 {
								    goto tag_104_254_100;
								 }
							    }
							  else
							    {
							       bool_t test_449;
							       {
								  obj_t aux_452;
								  obj_t aux_450;
								  aux_452 = CNST_TABLE_REF(((long) 3));
								  aux_450 = CAR(code_88);
								  test_449 = (aux_450 == aux_452);
							       }
							       if (test_449)
								 {
								    if (PAIRP(cdr_113_28_103))
								      {
									 obj_t car_207_125_127;
									 obj_t cdr_208_113_128;
									 car_207_125_127 = CAR(cdr_113_28_103);
									 cdr_208_113_128 = CDR(cdr_113_28_103);
									 if (PAIRP(car_207_125_127))
									   {
									      if (PAIRP(cdr_208_113_128))
										{
										   bool_t test_463;
										   {
										      obj_t aux_464;
										      aux_464 = CDR(cdr_208_113_128);
										      test_463 = (aux_464 == BNIL);
										   }
										   if (test_463)
										     {
											{
											   obj_t list1251_276;
											   {
											      obj_t aux_467;
											      aux_467 = CAR(car_207_125_127);
											      list1251_276 = MAKE_PAIR(aux_467, BNIL);
											   }
											   write_scheme_comment_102_write_scheme(port_301, list1251_276);
											}
											{
											   obj_t list1253_278;
											   list1253_278 = MAKE_PAIR(port_301, BNIL);
											   pp___pp(code_88, list1253_278);
											}
										     }
										   else
										     {
											goto tag_104_254_100;
										     }
										}
									      else
										{
										   goto tag_104_254_100;
										}
									   }
									 else
									   {
									      goto tag_104_254_100;
									   }
								      }
								    else
								      {
									 goto tag_104_254_100;
								      }
								 }
							       else
								 {
								    goto tag_104_254_100;
								 }
							    }
						       }
						    }
						  else
						    {
						       goto tag_104_254_100;
						    }
					       }
					    }
					    {
					       obj_t l1015_473;
					       l1015_473 = CDR(l1015_82);
					       l1015_82 = l1015_473;
					       goto lname1016_83;
					    }
					 }
				       else
					 {
					    ((bool_t) 1);
					 }
				    }
				 }
				 {
				    obj_t list1258_156;
				    list1258_156 = MAKE_PAIR(port_301, BNIL);
				    newline___r4_output_6_10_3(list1258_156);
				 }
			      }
			    else
			      {
				 BUNSPEC;
			      }
			 }
		      }
		      {
			 obj_t l1013_477;
			 l1013_477 = CDR(l1013_69);
			 l1013_69 = l1013_477;
			 goto lname1014_70;
		      }
		   }
		 else
		   {
		      val1012_61 = ((bool_t) 1);
		   }
	      }
	      POP_EXIT();
	      return BBOOL(val1012_61);
	   }
	}
     }
}


/* _write-expanded */ obj_t 
_write_expanded_29_write_expanded(obj_t env_299, obj_t units_300)
{
   return write_expanded_48_write_expanded(units_300);
}


/* method-init */ obj_t 
method_init_76_write_expanded()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_write_expanded()
{
   module_initialization_70_engine_param(((long) 0), "WRITE_EXPANDED");
   module_initialization_70_write_scheme(((long) 0), "WRITE_EXPANDED");
   module_initialization_70_tools_args(((long) 0), "WRITE_EXPANDED");
   module_initialization_70_tools_file(((long) 0), "WRITE_EXPANDED");
   module_initialization_70_ast_unit(((long) 0), "WRITE_EXPANDED");
   return module_initialization_70_module_module(((long) 0), "WRITE_EXPANDED");
}
