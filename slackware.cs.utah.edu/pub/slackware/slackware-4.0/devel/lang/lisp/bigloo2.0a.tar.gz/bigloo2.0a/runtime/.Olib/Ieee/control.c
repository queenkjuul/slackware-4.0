/*===========================================================================*/
/*   (Ieee/control.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t _procedure__196___r4_control_features_6_9(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t force___r4_control_features_6_9(obj_t);
static obj_t _dynamic_wind1223_143___r4_control_features_6_9(obj_t, obj_t, obj_t, obj_t);
extern obj_t call_with_current_continuation_81___r4_control_features_6_9(obj_t);
extern obj_t call_cc_68___r4_control_features_6_9(obj_t);
extern obj_t call_cc(obj_t);
static obj_t loop_1225___r4_control_features_6_9(obj_t);
static obj_t loop_1224___r4_control_features_6_9(obj_t, obj_t);
static obj_t _car1216___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _call_with_current_continuation1222_235___r4_control_features_6_9(obj_t, obj_t);
extern bool_t procedure__188___r4_control_features_6_9(obj_t);
static obj_t _call_cc1221_225___r4_control_features_6_9(obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _make_promise1220_238___r4_control_features_6_9(obj_t, obj_t);
static obj_t loop___r4_control_features_6_9(obj_t, obj_t);
static obj_t _for_each1219_134___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t lambda1071___r4_control_features_6_9(obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t make_promise_21___r4_control_features_6_9(obj_t);
static obj_t handling_function1085___r4_control_features_6_9(obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t _res_number__75___r5_control_features_6_4;
static obj_t _apply1213___r4_control_features_6_9(obj_t, obj_t, obj_t, obj_t);
extern obj_t map___r4_control_features_6_9(obj_t, obj_t);
static obj_t arg1076___r4_control_features_6_9(obj_t, obj_t);
static obj_t arg1072___r4_control_features_6_9(obj_t, obj_t);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern long list_length(obj_t);
extern obj_t apply___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t for_each_2_102___r4_control_features_6_9(obj_t, obj_t);
static obj_t _for_each_21218_162___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t _map1215___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t _cdr1217___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t map_2_128___r4_control_features_6_9(obj_t, obj_t);
extern obj_t for_each_73___r4_control_features_6_9(obj_t, obj_t);
static obj_t symbol1899___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1898___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1897___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1894___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1892___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1889___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1888___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1887___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1886___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1884___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1883___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1879___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1880___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1876___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1875___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1874___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1871___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1869___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1870___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1868___r4_control_features_6_9 = BUNSPEC;
static obj_t imported_modules_init_94___r4_control_features_6_9();
static obj_t symbol1865___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1864___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1862___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1858___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1856___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1854___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1846___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1841___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1838___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1834___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1823___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1818___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1814___r4_control_features_6_9 = BUNSPEC;
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t symbol1810___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1796___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1806___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1794___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1803___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1791___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1789___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1800___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1787___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1785___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1781___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1776___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1774___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1770___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1766___r4_control_features_6_9 = BUNSPEC;
static obj_t require_initialization_114___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1762___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1758___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1756___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1754___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1752___r4_control_features_6_9 = BUNSPEC;
static obj_t list1896___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1748___r4_control_features_6_9 = BUNSPEC;
static obj_t list1893___r4_control_features_6_9 = BUNSPEC;
static obj_t list1891___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1744___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1741___r4_control_features_6_9 = BUNSPEC;
static obj_t list1885___r4_control_features_6_9 = BUNSPEC;
static obj_t list1882___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1734___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1733___r4_control_features_6_9 = BUNSPEC;
static obj_t list1878___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1732___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1729___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1728___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1727___r4_control_features_6_9 = BUNSPEC;
static obj_t list1873___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1726___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1725___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1722___r4_control_features_6_9 = BUNSPEC;
static obj_t list1867___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1721___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1719___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1720___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1718___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1717___r4_control_features_6_9 = BUNSPEC;
static obj_t list1863___r4_control_features_6_9 = BUNSPEC;
static obj_t list1861___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1714___r4_control_features_6_9 = BUNSPEC;
static obj_t list1859___r4_control_features_6_9 = BUNSPEC;
static obj_t list1860___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1713___r4_control_features_6_9 = BUNSPEC;
static obj_t list1857___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1711___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1709___r4_control_features_6_9 = BUNSPEC;
static obj_t list1855___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1708___r4_control_features_6_9 = BUNSPEC;
static obj_t list1853___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1706___r4_control_features_6_9 = BUNSPEC;
static obj_t list1852___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1705___r4_control_features_6_9 = BUNSPEC;
static obj_t list1851___r4_control_features_6_9 = BUNSPEC;
static obj_t list1849___r4_control_features_6_9 = BUNSPEC;
static obj_t list1850___r4_control_features_6_9 = BUNSPEC;
static obj_t list1848___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1702___r4_control_features_6_9 = BUNSPEC;
static obj_t list1847___r4_control_features_6_9 = BUNSPEC;
static obj_t symbol1701___r4_control_features_6_9 = BUNSPEC;
static obj_t list1845___r4_control_features_6_9 = BUNSPEC;
static obj_t list1844___r4_control_features_6_9 = BUNSPEC;
static obj_t list1843___r4_control_features_6_9 = BUNSPEC;
static obj_t list1842___r4_control_features_6_9 = BUNSPEC;
static obj_t list1839___r4_control_features_6_9 = BUNSPEC;
static obj_t list1840___r4_control_features_6_9 = BUNSPEC;
static obj_t list1837___r4_control_features_6_9 = BUNSPEC;
static obj_t list1836___r4_control_features_6_9 = BUNSPEC;
static obj_t list1835___r4_control_features_6_9 = BUNSPEC;
static obj_t list1833___r4_control_features_6_9 = BUNSPEC;
static obj_t list1832___r4_control_features_6_9 = BUNSPEC;
static obj_t list1831___r4_control_features_6_9 = BUNSPEC;
static obj_t list1829___r4_control_features_6_9 = BUNSPEC;
static obj_t list1830___r4_control_features_6_9 = BUNSPEC;
static obj_t list1828___r4_control_features_6_9 = BUNSPEC;
static obj_t list1827___r4_control_features_6_9 = BUNSPEC;
static obj_t list1826___r4_control_features_6_9 = BUNSPEC;
static obj_t list1825___r4_control_features_6_9 = BUNSPEC;
static obj_t list1824___r4_control_features_6_9 = BUNSPEC;
static obj_t list1822___r4_control_features_6_9 = BUNSPEC;
static obj_t list1821___r4_control_features_6_9 = BUNSPEC;
static obj_t list1819___r4_control_features_6_9 = BUNSPEC;
static obj_t list1820___r4_control_features_6_9 = BUNSPEC;
static obj_t list1817___r4_control_features_6_9 = BUNSPEC;
static obj_t list1816___r4_control_features_6_9 = BUNSPEC;
static obj_t list1815___r4_control_features_6_9 = BUNSPEC;
static obj_t list1813___r4_control_features_6_9 = BUNSPEC;
static obj_t list1812___r4_control_features_6_9 = BUNSPEC;
static obj_t list1811___r4_control_features_6_9 = BUNSPEC;
static obj_t list1799___r4_control_features_6_9 = BUNSPEC;
static obj_t list1809___r4_control_features_6_9 = BUNSPEC;
static obj_t list1798___r4_control_features_6_9 = BUNSPEC;
static obj_t list1808___r4_control_features_6_9 = BUNSPEC;
static obj_t list1797___r4_control_features_6_9 = BUNSPEC;
static obj_t list1807___r4_control_features_6_9 = BUNSPEC;
static obj_t list1795___r4_control_features_6_9 = BUNSPEC;
static obj_t list1805___r4_control_features_6_9 = BUNSPEC;
static obj_t list1804___r4_control_features_6_9 = BUNSPEC;
static obj_t list1793___r4_control_features_6_9 = BUNSPEC;
static obj_t list1792___r4_control_features_6_9 = BUNSPEC;
static obj_t list1802___r4_control_features_6_9 = BUNSPEC;
static obj_t list1801___r4_control_features_6_9 = BUNSPEC;
static obj_t list1790___r4_control_features_6_9 = BUNSPEC;
static obj_t list1788___r4_control_features_6_9 = BUNSPEC;
static obj_t list1786___r4_control_features_6_9 = BUNSPEC;
static obj_t list1784___r4_control_features_6_9 = BUNSPEC;
static obj_t list1783___r4_control_features_6_9 = BUNSPEC;
static obj_t list1782___r4_control_features_6_9 = BUNSPEC;
static obj_t list1779___r4_control_features_6_9 = BUNSPEC;
static obj_t list1780___r4_control_features_6_9 = BUNSPEC;
static obj_t list1778___r4_control_features_6_9 = BUNSPEC;
static obj_t list1777___r4_control_features_6_9 = BUNSPEC;
static obj_t list1775___r4_control_features_6_9 = BUNSPEC;
static obj_t list1773___r4_control_features_6_9 = BUNSPEC;
static obj_t list1772___r4_control_features_6_9 = BUNSPEC;
static obj_t list1771___r4_control_features_6_9 = BUNSPEC;
static obj_t list1769___r4_control_features_6_9 = BUNSPEC;
static obj_t list1768___r4_control_features_6_9 = BUNSPEC;
static obj_t list1767___r4_control_features_6_9 = BUNSPEC;
static obj_t list1765___r4_control_features_6_9 = BUNSPEC;
static obj_t list1764___r4_control_features_6_9 = BUNSPEC;
static obj_t list1763___r4_control_features_6_9 = BUNSPEC;
static obj_t list1761___r4_control_features_6_9 = BUNSPEC;
static obj_t list1759___r4_control_features_6_9 = BUNSPEC;
static obj_t list1760___r4_control_features_6_9 = BUNSPEC;
static obj_t list1757___r4_control_features_6_9 = BUNSPEC;
static obj_t _force___r4_control_features_6_9(obj_t, obj_t);
static obj_t list1755___r4_control_features_6_9 = BUNSPEC;
static obj_t list1753___r4_control_features_6_9 = BUNSPEC;
static obj_t list1751___r4_control_features_6_9 = BUNSPEC;
static obj_t list1749___r4_control_features_6_9 = BUNSPEC;
static obj_t list1750___r4_control_features_6_9 = BUNSPEC;
static obj_t list1747___r4_control_features_6_9 = BUNSPEC;
static obj_t list1746___r4_control_features_6_9 = BUNSPEC;
static obj_t list1745___r4_control_features_6_9 = BUNSPEC;
static obj_t list1743___r4_control_features_6_9 = BUNSPEC;
static obj_t list1742___r4_control_features_6_9 = BUNSPEC;
static obj_t cnst_init_137___r4_control_features_6_9();
static obj_t list1739___r4_control_features_6_9 = BUNSPEC;
static obj_t list1740___r4_control_features_6_9 = BUNSPEC;
static obj_t list1731___r4_control_features_6_9 = BUNSPEC;
static obj_t list1724___r4_control_features_6_9 = BUNSPEC;
static obj_t list1723___r4_control_features_6_9 = BUNSPEC;
static obj_t list1716___r4_control_features_6_9 = BUNSPEC;
static obj_t _map_21214_55___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t list1704___r4_control_features_6_9 = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( call_with_current_continuation_env_226___r4_control_features_6_9, _call_with_current_continuation1222_235___r4_control_features_6_91901, _call_with_current_continuation1222_235___r4_control_features_6_9, 0L, 1 );
extern obj_t car_env_2___r4_pairs_and_lists_6_3;
DEFINE_EXPORT_PROCEDURE( call_cc_env_179___r4_control_features_6_9, _call_cc1221_225___r4_control_features_6_91902, _call_cc1221_225___r4_control_features_6_9, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( make_promise_env_123___r4_control_features_6_9, _make_promise1220_238___r4_control_features_6_91903, _make_promise1220_238___r4_control_features_6_9, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( apply_env_60___r4_control_features_6_9, _apply1213___r4_control_features_6_91904, va_generic_entry, _apply1213___r4_control_features_6_9, -3 );
DEFINE_EXPORT_PROCEDURE( for_each_env_83___r4_control_features_6_9, _for_each1219_134___r4_control_features_6_91905, va_generic_entry, _for_each1219_134___r4_control_features_6_9, -2 );
DEFINE_EXPORT_PROCEDURE( map_env_220___r4_control_features_6_9, _map1215___r4_control_features_6_91906, va_generic_entry, _map1215___r4_control_features_6_9, -2 );
extern obj_t cdr_env_184___r4_pairs_and_lists_6_3;
DEFINE_EXPORT_PROCEDURE( procedure__env_14___r4_control_features_6_9, _procedure__196___r4_control_features_6_91907, _procedure__196___r4_control_features_6_9, 0L, 1 );
DEFINE_STRING( string1895___r4_control_features_6_9, string1895___r4_control_features_6_91908, "HANDLING_FUNCTION1085:Wrong number of arguments", 47 );
DEFINE_STRING( string1890___r4_control_features_6_9, string1890___r4_control_features_6_91909, "DYNAMIC-WIND:Wrong number of arguments", 38 );
DEFINE_STRING( string1881___r4_control_features_6_9, string1881___r4_control_features_6_91910, "ARG1076:Wrong number of arguments", 33 );
DEFINE_STRING( string1877___r4_control_features_6_9, string1877___r4_control_features_6_91911, "ARG1072:Wrong number of arguments", 33 );
DEFINE_STRING( string1872___r4_control_features_6_9, string1872___r4_control_features_6_91912, "LAMBDA1071:Wrong number of arguments", 36 );
DEFINE_STRING( string1866___r4_control_features_6_9, string1866___r4_control_features_6_91913, "FORCE:Wrong number of arguments", 31 );
DEFINE_STRING( string1738___r4_control_features_6_9, string1738___r4_control_features_6_91914, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1737___r4_control_features_6_9, string1737___r4_control_features_6_91915, "argument not a list", 19 );
DEFINE_STRING( string1736___r4_control_features_6_9, string1736___r4_control_features_6_91916, "map", 3 );
DEFINE_STRING( string1735___r4_control_features_6_9, string1735___r4_control_features_6_91917, "FOR-EACH:Wrong number of arguments", 34 );
DEFINE_STRING( string1730___r4_control_features_6_9, string1730___r4_control_features_6_91918, "FOR-EACH-2:Wrong number of arguments", 36 );
DEFINE_STRING( string1715___r4_control_features_6_9, string1715___r4_control_features_6_91919, "LOOP_1224:Wrong number of arguments", 35 );
DEFINE_EXPORT_PROCEDURE( for_each_2_env_153___r4_control_features_6_9, _for_each_21218_162___r4_control_features_6_91920, _for_each_21218_162___r4_control_features_6_9, 0L, 2 );
DEFINE_STRING( string1712___r4_control_features_6_9, string1712___r4_control_features_6_91921, "PROCEDURE", 9 );
DEFINE_STRING( string1710___r4_control_features_6_9, string1710___r4_control_features_6_91922, "PAIR", 4 );
DEFINE_STRING( string1707___r4_control_features_6_9, string1707___r4_control_features_6_91923, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/control.scm", 60 );
DEFINE_STRING( string1703___r4_control_features_6_9, string1703___r4_control_features_6_91924, "Wrong number of arguments", 25 );
DEFINE_EXPORT_PROCEDURE( map_2_env_80___r4_control_features_6_9, _map_21214_55___r4_control_features_6_91925, _map_21214_55___r4_control_features_6_9, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( force_env_196___r4_control_features_6_9, _force___r4_control_features_6_91926, _force___r4_control_features_6_9, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( dynamic_wind_env_99___r4_control_features_6_9, _dynamic_wind1223_143___r4_control_features_6_91927, _dynamic_wind1223_143___r4_control_features_6_9, 0L, 3 );


/* module-initialization */obj_t module_initialization_70___r4_control_features_6_9(long checksum_983, char * from_984)
{
if(CBOOL(require_initialization_114___r4_control_features_6_9)){
require_initialization_114___r4_control_features_6_9 = BBOOL(((bool_t)0));
cnst_init_137___r4_control_features_6_9();
imported_modules_init_94___r4_control_features_6_9();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_control_features_6_9()
{
symbol1701___r4_control_features_6_9 = string_to_symbol("PROCEDURE?");
symbol1702___r4_control_features_6_9 = string_to_symbol("APPLY");
symbol1705___r4_control_features_6_9 = string_to_symbol("proc");
symbol1706___r4_control_features_6_9 = string_to_symbol("args");
{
obj_t aux_994;
{
obj_t aux_995;
aux_995 = MAKE_PAIR(symbol1706___r4_control_features_6_9, BNIL);
aux_994 = MAKE_PAIR(symbol1705___r4_control_features_6_9, aux_995);
}
list1704___r4_control_features_6_9 = MAKE_PAIR(symbol1702___r4_control_features_6_9, aux_994);
}
symbol1708___r4_control_features_6_9 = string_to_symbol("_");
symbol1709___r4_control_features_6_9 = string_to_symbol("LOOP_1225");
symbol1711___r4_control_features_6_9 = string_to_symbol("_APPLY1213");
symbol1713___r4_control_features_6_9 = string_to_symbol("MAP-2");
symbol1714___r4_control_features_6_9 = string_to_symbol("LOOP_1224");
symbol1717___r4_control_features_6_9 = string_to_symbol("FUNCALL");
symbol1718___r4_control_features_6_9 = string_to_symbol("f");
symbol1719___r4_control_features_6_9 = string_to_symbol("arg1026");
{
obj_t aux_1007;
{
obj_t aux_1008;
{
obj_t aux_1009;
aux_1009 = MAKE_PAIR(symbol1719___r4_control_features_6_9, BNIL);
aux_1008 = MAKE_PAIR(symbol1718___r4_control_features_6_9, aux_1009);
}
aux_1007 = MAKE_PAIR(symbol1718___r4_control_features_6_9, aux_1008);
}
list1716___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1007);
}
symbol1720___r4_control_features_6_9 = string_to_symbol("_MAP-21214");
symbol1721___r4_control_features_6_9 = string_to_symbol("MAP");
symbol1722___r4_control_features_6_9 = string_to_symbol("LOOP");
symbol1725___r4_control_features_6_9 = string_to_symbol("map-2");
symbol1726___r4_control_features_6_9 = string_to_symbol("car-env");
symbol1727___r4_control_features_6_9 = string_to_symbol("l");
{
obj_t aux_1020;
{
obj_t aux_1021;
aux_1021 = MAKE_PAIR(symbol1727___r4_control_features_6_9, BNIL);
aux_1020 = MAKE_PAIR(symbol1726___r4_control_features_6_9, aux_1021);
}
list1724___r4_control_features_6_9 = MAKE_PAIR(symbol1725___r4_control_features_6_9, aux_1020);
}
{
obj_t aux_1025;
{
obj_t aux_1026;
aux_1026 = MAKE_PAIR(list1724___r4_control_features_6_9, BNIL);
aux_1025 = MAKE_PAIR(symbol1718___r4_control_features_6_9, aux_1026);
}
list1723___r4_control_features_6_9 = MAKE_PAIR(symbol1702___r4_control_features_6_9, aux_1025);
}
symbol1728___r4_control_features_6_9 = string_to_symbol("_MAP1215");
symbol1729___r4_control_features_6_9 = string_to_symbol("FOR-EACH-2");
symbol1732___r4_control_features_6_9 = string_to_symbol("arg1039");
{
obj_t aux_1033;
{
obj_t aux_1034;
{
obj_t aux_1035;
aux_1035 = MAKE_PAIR(symbol1732___r4_control_features_6_9, BNIL);
aux_1034 = MAKE_PAIR(symbol1718___r4_control_features_6_9, aux_1035);
}
aux_1033 = MAKE_PAIR(symbol1718___r4_control_features_6_9, aux_1034);
}
list1731___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1033);
}
symbol1733___r4_control_features_6_9 = string_to_symbol("_FOR-EACH-21218");
symbol1734___r4_control_features_6_9 = string_to_symbol("FOR-EACH");
symbol1741___r4_control_features_6_9 = string_to_symbol("LET");
symbol1744___r4_control_features_6_9 = string_to_symbol("l1002");
{
obj_t aux_1044;
aux_1044 = MAKE_PAIR(symbol1727___r4_control_features_6_9, BNIL);
list1743___r4_control_features_6_9 = MAKE_PAIR(symbol1744___r4_control_features_6_9, aux_1044);
}
list1742___r4_control_features_6_9 = MAKE_PAIR(list1743___r4_control_features_6_9, BNIL);
symbol1748___r4_control_features_6_9 = string_to_symbol("test1045");
symbol1752___r4_control_features_6_9 = string_to_symbol("obj");
{
obj_t aux_1050;
aux_1050 = MAKE_PAIR(symbol1744___r4_control_features_6_9, BNIL);
list1751___r4_control_features_6_9 = MAKE_PAIR(symbol1752___r4_control_features_6_9, aux_1050);
}
list1750___r4_control_features_6_9 = MAKE_PAIR(list1751___r4_control_features_6_9, BNIL);
symbol1754___r4_control_features_6_9 = string_to_symbol("c-null?");
{
obj_t aux_1055;
aux_1055 = MAKE_PAIR(symbol1752___r4_control_features_6_9, BNIL);
list1753___r4_control_features_6_9 = MAKE_PAIR(symbol1754___r4_control_features_6_9, aux_1055);
}
{
obj_t aux_1058;
{
obj_t aux_1059;
aux_1059 = MAKE_PAIR(list1753___r4_control_features_6_9, BNIL);
aux_1058 = MAKE_PAIR(list1750___r4_control_features_6_9, aux_1059);
}
list1749___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1058);
}
{
obj_t aux_1063;
aux_1063 = MAKE_PAIR(list1749___r4_control_features_6_9, BNIL);
list1747___r4_control_features_6_9 = MAKE_PAIR(symbol1748___r4_control_features_6_9, aux_1063);
}
list1746___r4_control_features_6_9 = MAKE_PAIR(list1747___r4_control_features_6_9, BNIL);
symbol1756___r4_control_features_6_9 = string_to_symbol("IF");
symbol1758___r4_control_features_6_9 = string_to_symbol("QUOTE");
{
obj_t aux_1069;
aux_1069 = MAKE_PAIR(BNIL, BNIL);
list1757___r4_control_features_6_9 = MAKE_PAIR(symbol1758___r4_control_features_6_9, aux_1069);
}
symbol1762___r4_control_features_6_9 = string_to_symbol("head1004");
symbol1766___r4_control_features_6_9 = string_to_symbol("arg1053");
symbol1770___r4_control_features_6_9 = string_to_symbol("arg1055");
symbol1774___r4_control_features_6_9 = string_to_symbol("pair");
{
obj_t aux_1076;
aux_1076 = MAKE_PAIR(symbol1744___r4_control_features_6_9, BNIL);
list1773___r4_control_features_6_9 = MAKE_PAIR(symbol1774___r4_control_features_6_9, aux_1076);
}
list1772___r4_control_features_6_9 = MAKE_PAIR(list1773___r4_control_features_6_9, BNIL);
symbol1776___r4_control_features_6_9 = string_to_symbol("c-car");
{
obj_t aux_1081;
aux_1081 = MAKE_PAIR(symbol1774___r4_control_features_6_9, BNIL);
list1775___r4_control_features_6_9 = MAKE_PAIR(symbol1776___r4_control_features_6_9, aux_1081);
}
{
obj_t aux_1084;
{
obj_t aux_1085;
aux_1085 = MAKE_PAIR(list1775___r4_control_features_6_9, BNIL);
aux_1084 = MAKE_PAIR(list1772___r4_control_features_6_9, aux_1085);
}
list1771___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1084);
}
{
obj_t aux_1089;
aux_1089 = MAKE_PAIR(list1771___r4_control_features_6_9, BNIL);
list1769___r4_control_features_6_9 = MAKE_PAIR(symbol1770___r4_control_features_6_9, aux_1089);
}
list1768___r4_control_features_6_9 = MAKE_PAIR(list1769___r4_control_features_6_9, BNIL);
{
obj_t aux_1093;
aux_1093 = MAKE_PAIR(symbol1770___r4_control_features_6_9, BNIL);
list1779___r4_control_features_6_9 = MAKE_PAIR(symbol1774___r4_control_features_6_9, aux_1093);
}
list1778___r4_control_features_6_9 = MAKE_PAIR(list1779___r4_control_features_6_9, BNIL);
{
obj_t aux_1097;
{
obj_t aux_1098;
aux_1098 = MAKE_PAIR(list1775___r4_control_features_6_9, BNIL);
aux_1097 = MAKE_PAIR(list1778___r4_control_features_6_9, aux_1098);
}
list1777___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1097);
}
{
obj_t aux_1102;
{
obj_t aux_1103;
aux_1103 = MAKE_PAIR(list1777___r4_control_features_6_9, BNIL);
aux_1102 = MAKE_PAIR(list1768___r4_control_features_6_9, aux_1103);
}
list1767___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1102);
}
{
obj_t aux_1107;
aux_1107 = MAKE_PAIR(list1767___r4_control_features_6_9, BNIL);
list1765___r4_control_features_6_9 = MAKE_PAIR(symbol1766___r4_control_features_6_9, aux_1107);
}
symbol1781___r4_control_features_6_9 = string_to_symbol("arg1054");
{
obj_t aux_1111;
aux_1111 = MAKE_PAIR(list1757___r4_control_features_6_9, BNIL);
list1780___r4_control_features_6_9 = MAKE_PAIR(symbol1781___r4_control_features_6_9, aux_1111);
}
{
obj_t aux_1114;
aux_1114 = MAKE_PAIR(list1780___r4_control_features_6_9, BNIL);
list1764___r4_control_features_6_9 = MAKE_PAIR(list1765___r4_control_features_6_9, aux_1114);
}
symbol1785___r4_control_features_6_9 = string_to_symbol("obj1");
{
obj_t aux_1118;
aux_1118 = MAKE_PAIR(symbol1766___r4_control_features_6_9, BNIL);
list1784___r4_control_features_6_9 = MAKE_PAIR(symbol1785___r4_control_features_6_9, aux_1118);
}
symbol1787___r4_control_features_6_9 = string_to_symbol("obj2");
{
obj_t aux_1122;
aux_1122 = MAKE_PAIR(symbol1781___r4_control_features_6_9, BNIL);
list1786___r4_control_features_6_9 = MAKE_PAIR(symbol1787___r4_control_features_6_9, aux_1122);
}
{
obj_t aux_1125;
aux_1125 = MAKE_PAIR(list1786___r4_control_features_6_9, BNIL);
list1783___r4_control_features_6_9 = MAKE_PAIR(list1784___r4_control_features_6_9, aux_1125);
}
symbol1789___r4_control_features_6_9 = string_to_symbol("c-cons");
{
obj_t aux_1129;
{
obj_t aux_1130;
aux_1130 = MAKE_PAIR(symbol1787___r4_control_features_6_9, BNIL);
aux_1129 = MAKE_PAIR(symbol1785___r4_control_features_6_9, aux_1130);
}
list1788___r4_control_features_6_9 = MAKE_PAIR(symbol1789___r4_control_features_6_9, aux_1129);
}
{
obj_t aux_1134;
{
obj_t aux_1135;
aux_1135 = MAKE_PAIR(list1788___r4_control_features_6_9, BNIL);
aux_1134 = MAKE_PAIR(list1783___r4_control_features_6_9, aux_1135);
}
list1782___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1134);
}
{
obj_t aux_1139;
{
obj_t aux_1140;
aux_1140 = MAKE_PAIR(list1782___r4_control_features_6_9, BNIL);
aux_1139 = MAKE_PAIR(list1764___r4_control_features_6_9, aux_1140);
}
list1763___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1139);
}
{
obj_t aux_1144;
aux_1144 = MAKE_PAIR(list1763___r4_control_features_6_9, BNIL);
list1761___r4_control_features_6_9 = MAKE_PAIR(symbol1762___r4_control_features_6_9, aux_1144);
}
list1760___r4_control_features_6_9 = MAKE_PAIR(list1761___r4_control_features_6_9, BNIL);
symbol1791___r4_control_features_6_9 = string_to_symbol("LABELS");
symbol1794___r4_control_features_6_9 = string_to_symbol("lname1003");
symbol1796___r4_control_features_6_9 = string_to_symbol("tail1005");
{
obj_t aux_1151;
aux_1151 = MAKE_PAIR(symbol1796___r4_control_features_6_9, BNIL);
list1795___r4_control_features_6_9 = MAKE_PAIR(symbol1744___r4_control_features_6_9, aux_1151);
}
symbol1800___r4_control_features_6_9 = string_to_symbol("test1047");
symbol1803___r4_control_features_6_9 = string_to_symbol("c-pair?");
{
obj_t aux_1156;
aux_1156 = MAKE_PAIR(symbol1752___r4_control_features_6_9, BNIL);
list1802___r4_control_features_6_9 = MAKE_PAIR(symbol1803___r4_control_features_6_9, aux_1156);
}
{
obj_t aux_1159;
{
obj_t aux_1160;
aux_1160 = MAKE_PAIR(list1802___r4_control_features_6_9, BNIL);
aux_1159 = MAKE_PAIR(list1750___r4_control_features_6_9, aux_1160);
}
list1801___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1159);
}
{
obj_t aux_1164;
aux_1164 = MAKE_PAIR(list1801___r4_control_features_6_9, BNIL);
list1799___r4_control_features_6_9 = MAKE_PAIR(symbol1800___r4_control_features_6_9, aux_1164);
}
list1798___r4_control_features_6_9 = MAKE_PAIR(list1799___r4_control_features_6_9, BNIL);
symbol1806___r4_control_features_6_9 = string_to_symbol("BEGIN");
symbol1810___r4_control_features_6_9 = string_to_symbol("newtail1006");
symbol1814___r4_control_features_6_9 = string_to_symbol("arg1049");
symbol1818___r4_control_features_6_9 = string_to_symbol("arg1051");
{
obj_t aux_1172;
aux_1172 = MAKE_PAIR(list1771___r4_control_features_6_9, BNIL);
list1817___r4_control_features_6_9 = MAKE_PAIR(symbol1818___r4_control_features_6_9, aux_1172);
}
list1816___r4_control_features_6_9 = MAKE_PAIR(list1817___r4_control_features_6_9, BNIL);
{
obj_t aux_1176;
aux_1176 = MAKE_PAIR(symbol1818___r4_control_features_6_9, BNIL);
list1821___r4_control_features_6_9 = MAKE_PAIR(symbol1774___r4_control_features_6_9, aux_1176);
}
list1820___r4_control_features_6_9 = MAKE_PAIR(list1821___r4_control_features_6_9, BNIL);
{
obj_t aux_1180;
{
obj_t aux_1181;
aux_1181 = MAKE_PAIR(list1775___r4_control_features_6_9, BNIL);
aux_1180 = MAKE_PAIR(list1820___r4_control_features_6_9, aux_1181);
}
list1819___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1180);
}
{
obj_t aux_1185;
{
obj_t aux_1186;
aux_1186 = MAKE_PAIR(list1819___r4_control_features_6_9, BNIL);
aux_1185 = MAKE_PAIR(list1816___r4_control_features_6_9, aux_1186);
}
list1815___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1185);
}
{
obj_t aux_1190;
aux_1190 = MAKE_PAIR(list1815___r4_control_features_6_9, BNIL);
list1813___r4_control_features_6_9 = MAKE_PAIR(symbol1814___r4_control_features_6_9, aux_1190);
}
symbol1823___r4_control_features_6_9 = string_to_symbol("arg1050");
{
obj_t aux_1194;
aux_1194 = MAKE_PAIR(list1757___r4_control_features_6_9, BNIL);
list1822___r4_control_features_6_9 = MAKE_PAIR(symbol1823___r4_control_features_6_9, aux_1194);
}
{
obj_t aux_1197;
aux_1197 = MAKE_PAIR(list1822___r4_control_features_6_9, BNIL);
list1812___r4_control_features_6_9 = MAKE_PAIR(list1813___r4_control_features_6_9, aux_1197);
}
{
obj_t aux_1200;
aux_1200 = MAKE_PAIR(symbol1814___r4_control_features_6_9, BNIL);
list1826___r4_control_features_6_9 = MAKE_PAIR(symbol1785___r4_control_features_6_9, aux_1200);
}
{
obj_t aux_1203;
aux_1203 = MAKE_PAIR(symbol1823___r4_control_features_6_9, BNIL);
list1827___r4_control_features_6_9 = MAKE_PAIR(symbol1787___r4_control_features_6_9, aux_1203);
}
{
obj_t aux_1206;
aux_1206 = MAKE_PAIR(list1827___r4_control_features_6_9, BNIL);
list1825___r4_control_features_6_9 = MAKE_PAIR(list1826___r4_control_features_6_9, aux_1206);
}
{
obj_t aux_1209;
{
obj_t aux_1210;
aux_1210 = MAKE_PAIR(list1788___r4_control_features_6_9, BNIL);
aux_1209 = MAKE_PAIR(list1825___r4_control_features_6_9, aux_1210);
}
list1824___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1209);
}
{
obj_t aux_1214;
{
obj_t aux_1215;
aux_1215 = MAKE_PAIR(list1824___r4_control_features_6_9, BNIL);
aux_1214 = MAKE_PAIR(list1812___r4_control_features_6_9, aux_1215);
}
list1811___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1214);
}
{
obj_t aux_1219;
aux_1219 = MAKE_PAIR(list1811___r4_control_features_6_9, BNIL);
list1809___r4_control_features_6_9 = MAKE_PAIR(symbol1810___r4_control_features_6_9, aux_1219);
}
list1808___r4_control_features_6_9 = MAKE_PAIR(list1809___r4_control_features_6_9, BNIL);
{
obj_t aux_1223;
aux_1223 = MAKE_PAIR(symbol1796___r4_control_features_6_9, BNIL);
list1831___r4_control_features_6_9 = MAKE_PAIR(symbol1774___r4_control_features_6_9, aux_1223);
}
{
obj_t aux_1226;
aux_1226 = MAKE_PAIR(symbol1810___r4_control_features_6_9, BNIL);
list1832___r4_control_features_6_9 = MAKE_PAIR(symbol1752___r4_control_features_6_9, aux_1226);
}
{
obj_t aux_1229;
aux_1229 = MAKE_PAIR(list1832___r4_control_features_6_9, BNIL);
list1830___r4_control_features_6_9 = MAKE_PAIR(list1831___r4_control_features_6_9, aux_1229);
}
symbol1834___r4_control_features_6_9 = string_to_symbol("c-set-cdr!");
{
obj_t aux_1233;
{
obj_t aux_1234;
aux_1234 = MAKE_PAIR(symbol1752___r4_control_features_6_9, BNIL);
aux_1233 = MAKE_PAIR(symbol1774___r4_control_features_6_9, aux_1234);
}
list1833___r4_control_features_6_9 = MAKE_PAIR(symbol1834___r4_control_features_6_9, aux_1233);
}
{
obj_t aux_1238;
{
obj_t aux_1239;
aux_1239 = MAKE_PAIR(list1833___r4_control_features_6_9, BNIL);
aux_1238 = MAKE_PAIR(list1830___r4_control_features_6_9, aux_1239);
}
list1829___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1238);
}
symbol1838___r4_control_features_6_9 = string_to_symbol("arg1048");
symbol1841___r4_control_features_6_9 = string_to_symbol("c-cdr");
{
obj_t aux_1245;
aux_1245 = MAKE_PAIR(symbol1774___r4_control_features_6_9, BNIL);
list1840___r4_control_features_6_9 = MAKE_PAIR(symbol1841___r4_control_features_6_9, aux_1245);
}
{
obj_t aux_1248;
{
obj_t aux_1249;
aux_1249 = MAKE_PAIR(list1840___r4_control_features_6_9, BNIL);
aux_1248 = MAKE_PAIR(list1772___r4_control_features_6_9, aux_1249);
}
list1839___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1248);
}
{
obj_t aux_1253;
aux_1253 = MAKE_PAIR(list1839___r4_control_features_6_9, BNIL);
list1837___r4_control_features_6_9 = MAKE_PAIR(symbol1838___r4_control_features_6_9, aux_1253);
}
list1836___r4_control_features_6_9 = MAKE_PAIR(list1837___r4_control_features_6_9, BNIL);
{
obj_t aux_1257;
{
obj_t aux_1258;
aux_1258 = MAKE_PAIR(symbol1810___r4_control_features_6_9, BNIL);
aux_1257 = MAKE_PAIR(symbol1838___r4_control_features_6_9, aux_1258);
}
list1842___r4_control_features_6_9 = MAKE_PAIR(symbol1794___r4_control_features_6_9, aux_1257);
}
{
obj_t aux_1262;
{
obj_t aux_1263;
aux_1263 = MAKE_PAIR(list1842___r4_control_features_6_9, BNIL);
aux_1262 = MAKE_PAIR(list1836___r4_control_features_6_9, aux_1263);
}
list1835___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1262);
}
{
obj_t aux_1267;
{
obj_t aux_1268;
aux_1268 = MAKE_PAIR(list1835___r4_control_features_6_9, BNIL);
aux_1267 = MAKE_PAIR(list1829___r4_control_features_6_9, aux_1268);
}
list1828___r4_control_features_6_9 = MAKE_PAIR(symbol1806___r4_control_features_6_9, aux_1267);
}
{
obj_t aux_1272;
{
obj_t aux_1273;
aux_1273 = MAKE_PAIR(list1828___r4_control_features_6_9, BNIL);
aux_1272 = MAKE_PAIR(list1808___r4_control_features_6_9, aux_1273);
}
list1807___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1272);
}
{
obj_t aux_1277;
aux_1277 = MAKE_PAIR(list1807___r4_control_features_6_9, BNIL);
list1805___r4_control_features_6_9 = MAKE_PAIR(symbol1806___r4_control_features_6_9, aux_1277);
}
symbol1846___r4_control_features_6_9 = string_to_symbol("test1052");
{
obj_t aux_1281;
aux_1281 = MAKE_PAIR(list1749___r4_control_features_6_9, BNIL);
list1845___r4_control_features_6_9 = MAKE_PAIR(symbol1846___r4_control_features_6_9, aux_1281);
}
list1844___r4_control_features_6_9 = MAKE_PAIR(list1845___r4_control_features_6_9, BNIL);
{
obj_t aux_1285;
aux_1285 = MAKE_PAIR(symbol1762___r4_control_features_6_9, BNIL);
list1848___r4_control_features_6_9 = MAKE_PAIR(symbol1806___r4_control_features_6_9, aux_1285);
}
{
obj_t aux_1288;
aux_1288 = MAKE_PAIR(string1736___r4_control_features_6_9, BNIL);
list1852___r4_control_features_6_9 = MAKE_PAIR(symbol1705___r4_control_features_6_9, aux_1288);
}
symbol1854___r4_control_features_6_9 = string_to_symbol("message");
{
obj_t aux_1292;
aux_1292 = MAKE_PAIR(string1737___r4_control_features_6_9, BNIL);
list1853___r4_control_features_6_9 = MAKE_PAIR(symbol1854___r4_control_features_6_9, aux_1292);
}
symbol1856___r4_control_features_6_9 = string_to_symbol("object");
{
obj_t aux_1296;
aux_1296 = MAKE_PAIR(symbol1744___r4_control_features_6_9, BNIL);
list1855___r4_control_features_6_9 = MAKE_PAIR(symbol1856___r4_control_features_6_9, aux_1296);
}
{
obj_t aux_1299;
{
obj_t aux_1300;
aux_1300 = MAKE_PAIR(list1855___r4_control_features_6_9, BNIL);
aux_1299 = MAKE_PAIR(list1853___r4_control_features_6_9, aux_1300);
}
list1851___r4_control_features_6_9 = MAKE_PAIR(list1852___r4_control_features_6_9, aux_1299);
}
symbol1858___r4_control_features_6_9 = string_to_symbol("debug-error/location");
{
obj_t aux_1305;
{
obj_t aux_1306;
{
obj_t aux_1307;
{
obj_t aux_1308;
{
obj_t aux_1309;
{
obj_t aux_1310;
aux_1310 = BINT(((long)7610));
aux_1309 = MAKE_PAIR(aux_1310, BNIL);
}
aux_1308 = MAKE_PAIR(string1738___r4_control_features_6_9, aux_1309);
}
aux_1307 = MAKE_PAIR(symbol1856___r4_control_features_6_9, aux_1308);
}
aux_1306 = MAKE_PAIR(symbol1854___r4_control_features_6_9, aux_1307);
}
aux_1305 = MAKE_PAIR(symbol1705___r4_control_features_6_9, aux_1306);
}
list1857___r4_control_features_6_9 = MAKE_PAIR(symbol1858___r4_control_features_6_9, aux_1305);
}
{
obj_t aux_1318;
{
obj_t aux_1319;
aux_1319 = MAKE_PAIR(list1857___r4_control_features_6_9, BNIL);
aux_1318 = MAKE_PAIR(list1851___r4_control_features_6_9, aux_1319);
}
list1850___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1318);
}
{
obj_t aux_1323;
aux_1323 = MAKE_PAIR(list1850___r4_control_features_6_9, BNIL);
list1849___r4_control_features_6_9 = MAKE_PAIR(symbol1806___r4_control_features_6_9, aux_1323);
}
{
obj_t aux_1326;
{
obj_t aux_1327;
{
obj_t aux_1328;
aux_1328 = MAKE_PAIR(list1849___r4_control_features_6_9, BNIL);
aux_1327 = MAKE_PAIR(list1848___r4_control_features_6_9, aux_1328);
}
aux_1326 = MAKE_PAIR(symbol1846___r4_control_features_6_9, aux_1327);
}
list1847___r4_control_features_6_9 = MAKE_PAIR(symbol1756___r4_control_features_6_9, aux_1326);
}
{
obj_t aux_1333;
{
obj_t aux_1334;
aux_1334 = MAKE_PAIR(list1847___r4_control_features_6_9, BNIL);
aux_1333 = MAKE_PAIR(list1844___r4_control_features_6_9, aux_1334);
}
list1843___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1333);
}
{
obj_t aux_1338;
{
obj_t aux_1339;
{
obj_t aux_1340;
aux_1340 = MAKE_PAIR(list1843___r4_control_features_6_9, BNIL);
aux_1339 = MAKE_PAIR(list1805___r4_control_features_6_9, aux_1340);
}
aux_1338 = MAKE_PAIR(symbol1800___r4_control_features_6_9, aux_1339);
}
list1804___r4_control_features_6_9 = MAKE_PAIR(symbol1756___r4_control_features_6_9, aux_1338);
}
{
obj_t aux_1345;
{
obj_t aux_1346;
aux_1346 = MAKE_PAIR(list1804___r4_control_features_6_9, BNIL);
aux_1345 = MAKE_PAIR(list1798___r4_control_features_6_9, aux_1346);
}
list1797___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1345);
}
{
obj_t aux_1350;
{
obj_t aux_1351;
aux_1351 = MAKE_PAIR(list1797___r4_control_features_6_9, BNIL);
aux_1350 = MAKE_PAIR(list1795___r4_control_features_6_9, aux_1351);
}
list1793___r4_control_features_6_9 = MAKE_PAIR(symbol1794___r4_control_features_6_9, aux_1350);
}
list1792___r4_control_features_6_9 = MAKE_PAIR(list1793___r4_control_features_6_9, BNIL);
symbol1862___r4_control_features_6_9 = string_to_symbol("arg1046");
{
obj_t aux_1357;
aux_1357 = MAKE_PAIR(list1839___r4_control_features_6_9, BNIL);
list1861___r4_control_features_6_9 = MAKE_PAIR(symbol1862___r4_control_features_6_9, aux_1357);
}
list1860___r4_control_features_6_9 = MAKE_PAIR(list1861___r4_control_features_6_9, BNIL);
{
obj_t aux_1361;
{
obj_t aux_1362;
aux_1362 = MAKE_PAIR(symbol1762___r4_control_features_6_9, BNIL);
aux_1361 = MAKE_PAIR(symbol1862___r4_control_features_6_9, aux_1362);
}
list1863___r4_control_features_6_9 = MAKE_PAIR(symbol1794___r4_control_features_6_9, aux_1361);
}
{
obj_t aux_1366;
{
obj_t aux_1367;
aux_1367 = MAKE_PAIR(list1863___r4_control_features_6_9, BNIL);
aux_1366 = MAKE_PAIR(list1860___r4_control_features_6_9, aux_1367);
}
list1859___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1366);
}
{
obj_t aux_1371;
{
obj_t aux_1372;
aux_1372 = MAKE_PAIR(list1859___r4_control_features_6_9, BNIL);
aux_1371 = MAKE_PAIR(list1792___r4_control_features_6_9, aux_1372);
}
list1790___r4_control_features_6_9 = MAKE_PAIR(symbol1791___r4_control_features_6_9, aux_1371);
}
{
obj_t aux_1376;
{
obj_t aux_1377;
aux_1377 = MAKE_PAIR(list1790___r4_control_features_6_9, BNIL);
aux_1376 = MAKE_PAIR(list1760___r4_control_features_6_9, aux_1377);
}
list1759___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1376);
}
{
obj_t aux_1381;
{
obj_t aux_1382;
{
obj_t aux_1383;
aux_1383 = MAKE_PAIR(list1759___r4_control_features_6_9, BNIL);
aux_1382 = MAKE_PAIR(list1757___r4_control_features_6_9, aux_1383);
}
aux_1381 = MAKE_PAIR(symbol1748___r4_control_features_6_9, aux_1382);
}
list1755___r4_control_features_6_9 = MAKE_PAIR(symbol1756___r4_control_features_6_9, aux_1381);
}
{
obj_t aux_1388;
{
obj_t aux_1389;
aux_1389 = MAKE_PAIR(list1755___r4_control_features_6_9, BNIL);
aux_1388 = MAKE_PAIR(list1746___r4_control_features_6_9, aux_1389);
}
list1745___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1388);
}
{
obj_t aux_1393;
{
obj_t aux_1394;
aux_1394 = MAKE_PAIR(list1745___r4_control_features_6_9, BNIL);
aux_1393 = MAKE_PAIR(list1742___r4_control_features_6_9, aux_1394);
}
list1740___r4_control_features_6_9 = MAKE_PAIR(symbol1741___r4_control_features_6_9, aux_1393);
}
{
obj_t aux_1398;
{
obj_t aux_1399;
aux_1399 = MAKE_PAIR(list1740___r4_control_features_6_9, BNIL);
aux_1398 = MAKE_PAIR(symbol1718___r4_control_features_6_9, aux_1399);
}
list1739___r4_control_features_6_9 = MAKE_PAIR(symbol1702___r4_control_features_6_9, aux_1398);
}
symbol1864___r4_control_features_6_9 = string_to_symbol("_FOR-EACH1219");
symbol1865___r4_control_features_6_9 = string_to_symbol("FORCE");
symbol1868___r4_control_features_6_9 = string_to_symbol("promise");
{
obj_t aux_1406;
{
obj_t aux_1407;
aux_1407 = MAKE_PAIR(symbol1868___r4_control_features_6_9, BNIL);
aux_1406 = MAKE_PAIR(symbol1868___r4_control_features_6_9, aux_1407);
}
list1867___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1406);
}
symbol1869___r4_control_features_6_9 = string_to_symbol("MAKE-PROMISE");
symbol1870___r4_control_features_6_9 = string_to_symbol("_MAKE-PROMISE1220");
symbol1871___r4_control_features_6_9 = string_to_symbol("LAMBDA1071");
{
obj_t aux_1414;
{
obj_t aux_1415;
aux_1415 = MAKE_PAIR(symbol1705___r4_control_features_6_9, BNIL);
aux_1414 = MAKE_PAIR(symbol1705___r4_control_features_6_9, aux_1415);
}
list1873___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1414);
}
symbol1874___r4_control_features_6_9 = string_to_symbol("CALL/CC");
symbol1875___r4_control_features_6_9 = string_to_symbol("_CALL/CC1221");
symbol1876___r4_control_features_6_9 = string_to_symbol("ARG1072");
symbol1879___r4_control_features_6_9 = string_to_symbol("arg1076");
{
obj_t aux_1423;
{
obj_t aux_1424;
{
obj_t aux_1425;
aux_1425 = MAKE_PAIR(symbol1879___r4_control_features_6_9, BNIL);
aux_1424 = MAKE_PAIR(symbol1705___r4_control_features_6_9, aux_1425);
}
aux_1423 = MAKE_PAIR(symbol1705___r4_control_features_6_9, aux_1424);
}
list1878___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1423);
}
symbol1880___r4_control_features_6_9 = string_to_symbol("ARG1076");
symbol1883___r4_control_features_6_9 = string_to_symbol("cont");
symbol1884___r4_control_features_6_9 = string_to_symbol("arg1079");
{
obj_t aux_1433;
{
obj_t aux_1434;
{
obj_t aux_1435;
aux_1435 = MAKE_PAIR(symbol1884___r4_control_features_6_9, BNIL);
aux_1434 = MAKE_PAIR(symbol1883___r4_control_features_6_9, aux_1435);
}
aux_1433 = MAKE_PAIR(symbol1883___r4_control_features_6_9, aux_1434);
}
list1882___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1433);
}
symbol1886___r4_control_features_6_9 = string_to_symbol("vals");
{
obj_t aux_1441;
{
obj_t aux_1442;
{
obj_t aux_1443;
aux_1443 = MAKE_PAIR(symbol1886___r4_control_features_6_9, BNIL);
aux_1442 = MAKE_PAIR(symbol1883___r4_control_features_6_9, aux_1443);
}
aux_1441 = MAKE_PAIR(symbol1883___r4_control_features_6_9, aux_1442);
}
list1885___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1441);
}
symbol1887___r4_control_features_6_9 = string_to_symbol("CALL-WITH-CURRENT-CONTINUATION");
symbol1888___r4_control_features_6_9 = string_to_symbol("_CALL-WITH-CURRENT-CONTINUATION1222");
symbol1889___r4_control_features_6_9 = string_to_symbol("DYNAMIC-WIND");
symbol1892___r4_control_features_6_9 = string_to_symbol("before");
{
obj_t aux_1452;
{
obj_t aux_1453;
aux_1453 = MAKE_PAIR(symbol1892___r4_control_features_6_9, BNIL);
aux_1452 = MAKE_PAIR(symbol1892___r4_control_features_6_9, aux_1453);
}
list1891___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1452);
}
symbol1894___r4_control_features_6_9 = string_to_symbol("after");
{
obj_t aux_1458;
{
obj_t aux_1459;
aux_1459 = MAKE_PAIR(symbol1894___r4_control_features_6_9, BNIL);
aux_1458 = MAKE_PAIR(symbol1894___r4_control_features_6_9, aux_1459);
}
list1893___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1458);
}
symbol1897___r4_control_features_6_9 = string_to_symbol("thunk");
{
obj_t aux_1464;
{
obj_t aux_1465;
aux_1465 = MAKE_PAIR(symbol1897___r4_control_features_6_9, BNIL);
aux_1464 = MAKE_PAIR(symbol1897___r4_control_features_6_9, aux_1465);
}
list1896___r4_control_features_6_9 = MAKE_PAIR(symbol1717___r4_control_features_6_9, aux_1464);
}
symbol1898___r4_control_features_6_9 = string_to_symbol("_DYNAMIC-WIND1223");
return (symbol1899___r4_control_features_6_9 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* procedure? */bool_t procedure__188___r4_control_features_6_9(obj_t obj_1)
{
{
obj_t symbol1190_964;
symbol1190_964 = symbol1701___r4_control_features_6_9;
{
PUSH_TRACE(symbol1190_964);
BUNSPEC;
{
bool_t aux1189_965;
aux1189_965 = PROCEDUREP(obj_1);
POP_TRACE();
return aux1189_965;
}
}
}
}


/* _procedure? */obj_t _procedure__196___r4_control_features_6_9(obj_t env_509, obj_t obj_510)
{
{
bool_t aux_1474;
{
obj_t obj_966;
obj_966 = obj_510;
{
obj_t symbol1190_967;
symbol1190_967 = symbol1701___r4_control_features_6_9;
{
PUSH_TRACE(symbol1190_967);
BUNSPEC;
{
bool_t aux1189_968;
aux1189_968 = PROCEDUREP(obj_966);
POP_TRACE();
aux_1474 = aux1189_968;
}
}
}
}
return BBOOL(aux_1474);
}
}


/* apply */obj_t apply___r4_control_features_6_9(obj_t proc_2, obj_t args_3, obj_t opt_4)
{
{
obj_t symbol1192_487;
symbol1192_487 = symbol1702___r4_control_features_6_9;
{
PUSH_TRACE(symbol1192_487);
BUNSPEC;
{
obj_t aux1191_488;
{
obj_t args_197;
if(PAIRP(opt_4)){
obj_t arg1016_199;
arg1016_199 = loop_1225___r4_control_features_6_9(opt_4);
args_197 = MAKE_PAIR(args_3, arg1016_199);
}
 else {
args_197 = args_3;
}
{
bool_t test1235_569;
{
long aux_1484;
aux_1484 = list_length(args_197);
test1235_569 = PROCEDURE_CORRECT_ARITYP(proc_2, aux_1484);
}
if(test1235_569){
aux1191_488 = apply(proc_2, args_197);
}
 else {
error_location_112___error(symbol1702___r4_control_features_6_9, string1703___r4_control_features_6_9, list1704___r4_control_features_6_9, string1707___r4_control_features_6_9, BINT(((long)3175)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
POP_TRACE();
return aux1191_488;
}
}
}
}


/* loop_1225 */obj_t loop_1225___r4_control_features_6_9(obj_t opt_200)
{
{
bool_t test1017_202;
{
obj_t arg1021_206;
{
obj_t pair_397;
if(PAIRP(opt_200)){
pair_397 = opt_200;
}
 else {
bigloo_type_error_location_103___error(symbol1709___r4_control_features_6_9, string1710___r4_control_features_6_9, opt_200, string1707___r4_control_features_6_9, BINT(((long)3081)));
exit( -1 );}
arg1021_206 = CDR(pair_397);
}
test1017_202 = PAIRP(arg1021_206);
}
if(test1017_202){
obj_t arg1018_203;
obj_t arg1019_204;
{
obj_t pair_399;
if(PAIRP(opt_200)){
pair_399 = opt_200;
}
 else {
bigloo_type_error_location_103___error(symbol1709___r4_control_features_6_9, string1710___r4_control_features_6_9, opt_200, string1707___r4_control_features_6_9, BINT(((long)3107)));
exit( -1 );}
arg1018_203 = CAR(pair_399);
}
{
obj_t arg1020_205;
{
obj_t pair_400;
if(PAIRP(opt_200)){
pair_400 = opt_200;
}
 else {
bigloo_type_error_location_103___error(symbol1709___r4_control_features_6_9, string1710___r4_control_features_6_9, opt_200, string1707___r4_control_features_6_9, BINT(((long)3123)));
exit( -1 );}
arg1020_205 = CDR(pair_400);
}
arg1019_204 = loop_1225___r4_control_features_6_9(arg1020_205);
}
return MAKE_PAIR(arg1018_203, arg1019_204);
}
 else {
obj_t pair_403;
if(PAIRP(opt_200)){
pair_403 = opt_200;
}
 else {
bigloo_type_error_location_103___error(symbol1709___r4_control_features_6_9, string1710___r4_control_features_6_9, opt_200, string1707___r4_control_features_6_9, BINT(((long)3144)));
exit( -1 );}
return CAR(pair_403);
}
}
}


/* _apply1213 */obj_t _apply1213___r4_control_features_6_9(obj_t env_511, obj_t proc_512, obj_t args_513, obj_t opt_514)
{
{
obj_t aux_1522;
if(PROCEDUREP(proc_512)){
aux_1522 = proc_512;
}
 else {
bigloo_type_error_location_103___error(symbol1711___r4_control_features_6_9, string1712___r4_control_features_6_9, proc_512, string1707___r4_control_features_6_9, BINT(((long)2963)));
exit( -1 );}
return apply___r4_control_features_6_9(aux_1522, args_513, opt_514);
}
}


/* map-2 */obj_t map_2_128___r4_control_features_6_9(obj_t f_5, obj_t l_6)
{
{
obj_t symbol1194_489;
symbol1194_489 = symbol1713___r4_control_features_6_9;
{
PUSH_TRACE(symbol1194_489);
BUNSPEC;
{
obj_t aux1193_490;
aux1193_490 = loop_1224___r4_control_features_6_9(f_5, l_6);
POP_TRACE();
return aux1193_490;
}
}
}
}


/* loop_1224 */obj_t loop_1224___r4_control_features_6_9(obj_t f_560, obj_t l_207)
{
if(NULLP(l_207)){
return BNIL;
}
 else {
obj_t arg1023_210;
obj_t arg1025_211;
{
obj_t arg1026_212;
{
obj_t pair_407;
if(PAIRP(l_207)){
pair_407 = l_207;
}
 else {
bigloo_type_error_location_103___error(symbol1714___r4_control_features_6_9, string1710___r4_control_features_6_9, l_207, string1707___r4_control_features_6_9, BINT(((long)3500)));
exit( -1 );}
arg1026_212 = CAR(pair_407);
}
{
bool_t test1289_613;
test1289_613 = PROCEDURE_CORRECT_ARITYP(f_560, ((long)1));
if(test1289_613){
arg1023_210 = PROCEDURE_ENTRY(f_560)(f_560, arg1026_212, BEOA);
}
 else {
error_location_112___error(string1715___r4_control_features_6_9, list1716___r4_control_features_6_9, f_560, string1707___r4_control_features_6_9, BINT(((long)3496)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
{
obj_t arg1027_213;
{
obj_t pair_408;
if(PAIRP(l_207)){
pair_408 = l_207;
}
 else {
bigloo_type_error_location_103___error(symbol1714___r4_control_features_6_9, string1710___r4_control_features_6_9, l_207, string1707___r4_control_features_6_9, BINT(((long)3515)));
exit( -1 );}
arg1027_213 = CDR(pair_408);
}
arg1025_211 = loop_1224___r4_control_features_6_9(f_560, arg1027_213);
}
return MAKE_PAIR(arg1023_210, arg1025_211);
}
}


/* _map-21214 */obj_t _map_21214_55___r4_control_features_6_9(obj_t env_515, obj_t f_516, obj_t l_517)
{
{
obj_t aux_1555;
if(PROCEDUREP(f_516)){
aux_1555 = f_516;
}
 else {
bigloo_type_error_location_103___error(symbol1720___r4_control_features_6_9, string1712___r4_control_features_6_9, f_516, string1707___r4_control_features_6_9, BINT(((long)3418)));
exit( -1 );}
return map_2_128___r4_control_features_6_9(aux_1555, l_517);
}
}


/* map */obj_t map___r4_control_features_6_9(obj_t f_7, obj_t l_8)
{
{
obj_t symbol1196_491;
symbol1196_491 = symbol1721___r4_control_features_6_9;
{
PUSH_TRACE(symbol1196_491);
BUNSPEC;
{
obj_t aux1195_492;
if(NULLP(l_8)){
aux1195_492 = BNIL;
}
 else {
bool_t test1029_215;
{
obj_t arg1037_224;
{
obj_t pair_412;
if(PAIRP(l_8)){
pair_412 = l_8;
}
 else {
bigloo_type_error_location_103___error(symbol1721___r4_control_features_6_9, string1710___r4_control_features_6_9, l_8, string1707___r4_control_features_6_9, BINT(((long)3823)));
exit( -1 );}
arg1037_224 = CDR(pair_412);
}
test1029_215 = NULLP(arg1037_224);
}
if(test1029_215){
{
obj_t arg1030_216;
{
obj_t pair_414;
if(PAIRP(l_8)){
pair_414 = l_8;
}
 else {
bigloo_type_error_location_103___error(symbol1721___r4_control_features_6_9, string1710___r4_control_features_6_9, l_8, string1707___r4_control_features_6_9, BINT(((long)3848)));
exit( -1 );}
arg1030_216 = CAR(pair_414);
}
aux1195_492 = map_2_128___r4_control_features_6_9(f_7, arg1030_216);
}
}
 else {
aux1195_492 = loop___r4_control_features_6_9(f_7, l_8);
}
}
POP_TRACE();
return aux1195_492;
}
}
}
}


/* loop */obj_t loop___r4_control_features_6_9(obj_t f_559, obj_t l_217)
{
{
bool_t test1031_219;
{
obj_t arg1035_223;
{
obj_t pair_415;
if(PAIRP(l_217)){
pair_415 = l_217;
}
 else {
bigloo_type_error_location_103___error(symbol1722___r4_control_features_6_9, string1710___r4_control_features_6_9, l_217, string1707___r4_control_features_6_9, BINT(((long)3909)));
exit( -1 );}
arg1035_223 = CAR(pair_415);
}
test1031_219 = NULLP(arg1035_223);
}
if(test1031_219){
return BNIL;
}
 else {
obj_t arg1032_220;
obj_t arg1033_221;
{
obj_t val_645;
val_645 = map_2_128___r4_control_features_6_9(car_env_2___r4_pairs_and_lists_6_3, l_217);
{
bool_t test1334_652;
{
long aux_1591;
aux_1591 = list_length(val_645);
test1334_652 = PROCEDURE_CORRECT_ARITYP(f_559, aux_1591);
}
if(test1334_652){
arg1032_220 = apply(f_559, val_645);
}
 else {
error_location_112___error(symbol1722___r4_control_features_6_9, string1703___r4_control_features_6_9, list1723___r4_control_features_6_9, string1707___r4_control_features_6_9, BINT(((long)3941)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
{
obj_t arg1034_222;
arg1034_222 = map_2_128___r4_control_features_6_9(cdr_env_184___r4_pairs_and_lists_6_3, l_217);
arg1033_221 = loop___r4_control_features_6_9(f_559, arg1034_222);
}
return MAKE_PAIR(arg1032_220, arg1033_221);
}
}
}


/* _map1215 */obj_t _map1215___r4_control_features_6_9(obj_t env_518, obj_t f_519, obj_t l_520)
{
{
obj_t aux_1603;
if(PROCEDUREP(f_519)){
aux_1603 = f_519;
}
 else {
bigloo_type_error_location_103___error(symbol1728___r4_control_features_6_9, string1712___r4_control_features_6_9, f_519, string1707___r4_control_features_6_9, BINT(((long)3750)));
exit( -1 );}
return map___r4_control_features_6_9(aux_1603, l_520);
}
}


/* for-each-2 */obj_t for_each_2_102___r4_control_features_6_9(obj_t f_9, obj_t l_10)
{
{
obj_t symbol1198_493;
symbol1198_493 = symbol1729___r4_control_features_6_9;
{
PUSH_TRACE(symbol1198_493);
BUNSPEC;
{
obj_t aux1197_494;
{
obj_t l_420;
l_420 = l_10;
loop_419:
if(NULLP(l_420)){
aux1197_494 = BNIL;
}
 else {
{
obj_t arg1039_422;
{
obj_t pair_425;
if(PAIRP(l_420)){
pair_425 = l_420;
}
 else {
bigloo_type_error_location_103___error(symbol1729___r4_control_features_6_9, string1710___r4_control_features_6_9, l_420, string1707___r4_control_features_6_9, BINT(((long)4314)));
exit( -1 );}
arg1039_422 = CAR(pair_425);
}
{
bool_t test1358_672;
test1358_672 = PROCEDURE_CORRECT_ARITYP(f_9, ((long)1));
if(test1358_672){
PROCEDURE_ENTRY(f_9)(f_9, arg1039_422, BEOA);
}
 else {
error_location_112___error(string1730___r4_control_features_6_9, list1731___r4_control_features_6_9, f_9, string1707___r4_control_features_6_9, BINT(((long)4310)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
{
obj_t arg1040_423;
{
obj_t pair_426;
if(PAIRP(l_420)){
pair_426 = l_420;
}
 else {
bigloo_type_error_location_103___error(symbol1729___r4_control_features_6_9, string1710___r4_control_features_6_9, l_420, string1707___r4_control_features_6_9, BINT(((long)4335)));
exit( -1 );}
arg1040_423 = CDR(pair_426);
}
{
obj_t l_1632;
l_1632 = arg1040_423;
l_420 = l_1632;
goto loop_419;
}
}
}
}
POP_TRACE();
return aux1197_494;
}
}
}
}


/* _for-each-21218 */obj_t _for_each_21218_162___r4_control_features_6_9(obj_t env_525, obj_t f_526, obj_t l_527)
{
{
obj_t aux_1634;
if(PROCEDUREP(f_526)){
aux_1634 = f_526;
}
 else {
bigloo_type_error_location_103___error(symbol1733___r4_control_features_6_9, string1712___r4_control_features_6_9, f_526, string1707___r4_control_features_6_9, BINT(((long)4221)));
exit( -1 );}
return for_each_2_102___r4_control_features_6_9(aux_1634, l_527);
}
}


/* for-each */obj_t for_each_73___r4_control_features_6_9(obj_t f_11, obj_t l_12)
{
{
obj_t symbol1200_495;
symbol1200_495 = symbol1734___r4_control_features_6_9;
{
PUSH_TRACE(symbol1200_495);
BUNSPEC;
{
obj_t aux1199_496;
if(NULLP(l_12)){
aux1199_496 = BNIL;
}
 else {
bool_t test1042_231;
{
obj_t arg1069_272;
{
obj_t pair_428;
if(PAIRP(l_12)){
pair_428 = l_12;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l_12, string1707___r4_control_features_6_9, BINT(((long)4648)));
exit( -1 );}
arg1069_272 = CDR(pair_428);
}
test1042_231 = NULLP(arg1069_272);
}
if(test1042_231){
{
obj_t arg1043_232;
{
obj_t pair_430;
if(PAIRP(l_12)){
pair_430 = l_12;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l_12, string1707___r4_control_features_6_9, BINT(((long)4678)));
exit( -1 );}
arg1043_232 = CAR(pair_430);
}
{
obj_t l_434;
l_434 = arg1043_232;
loop_433:
if(NULLP(l_434)){
aux1199_496 = BNIL;
}
 else {
{
obj_t arg1039_436;
{
obj_t pair_439;
if(PAIRP(l_434)){
pair_439 = l_434;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l_434, string1707___r4_control_features_6_9, BINT(((long)4314)));
exit( -1 );}
arg1039_436 = CAR(pair_439);
}
{
bool_t test1403_710;
test1403_710 = PROCEDURE_CORRECT_ARITYP(f_11, ((long)1));
if(test1403_710){
PROCEDURE_ENTRY(f_11)(f_11, arg1039_436, BEOA);
}
 else {
error_location_112___error(string1735___r4_control_features_6_9, list1731___r4_control_features_6_9, f_11, string1707___r4_control_features_6_9, BINT(((long)4310)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
{
obj_t arg1040_437;
{
obj_t pair_440;
if(PAIRP(l_434)){
pair_440 = l_434;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l_434, string1707___r4_control_features_6_9, BINT(((long)4335)));
exit( -1 );}
arg1040_437 = CDR(pair_440);
}
{
obj_t l_1679;
l_1679 = arg1040_437;
l_434 = l_1679;
goto loop_433;
}
}
}
}
}
}
 else {
{
obj_t l_233;
l_233 = l_12;
loop_234:
{
bool_t test1044_235;
{
obj_t arg1068_271;
{
obj_t pair_441;
if(PAIRP(l_233)){
pair_441 = l_233;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l_233, string1707___r4_control_features_6_9, BINT(((long)4739)));
exit( -1 );}
arg1068_271 = CAR(pair_441);
}
test1044_235 = NULLP(arg1068_271);
}
if(test1044_235){
aux1199_496 = BNIL;
}
 else {
{
obj_t val_760;
if(NULLP(l_233)){
val_760 = BNIL;
}
 else {
obj_t head1004_238;
{
obj_t arg1053_250;
{
obj_t arg1055_252;
{
obj_t pair_444;
if(PAIRP(l_233)){
pair_444 = l_233;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l_233, string1707___r4_control_features_6_9, BINT(((long)4784)));
exit( -1 );}
arg1055_252 = CAR(pair_444);
}
{
obj_t pair_445;
if(PAIRP(arg1055_252)){
pair_445 = arg1055_252;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, arg1055_252, string1707___r4_control_features_6_9, BINT(((long)4784)));
exit( -1 );}
arg1053_250 = CAR(pair_445);
}
}
head1004_238 = MAKE_PAIR(arg1053_250, BNIL);
}
{
obj_t l1002_239;
obj_t tail1005_240;
{
obj_t arg1046_242;
{
obj_t pair_448;
if(PAIRP(l_233)){
pair_448 = l_233;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l_233, string1707___r4_control_features_6_9, BINT(((long)4784)));
exit( -1 );}
arg1046_242 = CDR(pair_448);
}
l1002_239 = arg1046_242;
tail1005_240 = head1004_238;
lname1003_241:
{
bool_t test1047_243;
test1047_243 = PAIRP(l1002_239);
if(test1047_243){
{
obj_t newtail1006_244;
{
obj_t arg1049_246;
{
obj_t arg1051_248;
{
obj_t pair_450;
if(test1047_243){
pair_450 = l1002_239;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l1002_239, string1707___r4_control_features_6_9, BINT(((long)4784)));
exit( -1 );}
arg1051_248 = CAR(pair_450);
}
{
obj_t pair_451;
if(PAIRP(arg1051_248)){
pair_451 = arg1051_248;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, arg1051_248, string1707___r4_control_features_6_9, BINT(((long)4784)));
exit( -1 );}
arg1049_246 = CAR(pair_451);
}
}
newtail1006_244 = MAKE_PAIR(arg1049_246, BNIL);
}
SET_CDR(tail1005_240, newtail1006_244);
{
obj_t arg1048_245;
{
obj_t pair_456;
if(PAIRP(l1002_239)){
pair_456 = l1002_239;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l1002_239, string1707___r4_control_features_6_9, BINT(((long)4784)));
exit( -1 );}
arg1048_245 = CDR(pair_456);
}
{
obj_t tail1005_1731;
obj_t l1002_1730;
l1002_1730 = arg1048_245;
tail1005_1731 = newtail1006_244;
tail1005_240 = tail1005_1731;
l1002_239 = l1002_1730;
goto lname1003_241;
}
}
}
}
 else {
if(NULLP(l1002_239)){
val_760 = head1004_238;
}
 else {
val_760 = debug_error_location_199___error(string1736___r4_control_features_6_9, string1737___r4_control_features_6_9, l1002_239, string1738___r4_control_features_6_9, BINT(((long)7610)));
}
}
}
}
}
}
{
bool_t test1475_767;
{
long aux_1736;
aux_1736 = list_length(val_760);
test1475_767 = PROCEDURE_CORRECT_ARITYP(f_11, aux_1736);
}
if(test1475_767){
apply(f_11, val_760);
}
 else {
error_location_112___error(symbol1734___r4_control_features_6_9, string1703___r4_control_features_6_9, list1739___r4_control_features_6_9, string1707___r4_control_features_6_9, BINT(((long)4775)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
{
obj_t arg1056_253;
if(NULLP(l_233)){
arg1056_253 = BNIL;
}
 else {
obj_t head1009_256;
{
obj_t arg1065_268;
{
obj_t arg1067_270;
{
obj_t pair_462;
if(PAIRP(l_233)){
pair_462 = l_233;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l_233, string1707___r4_control_features_6_9, BINT(((long)4806)));
exit( -1 );}
arg1067_270 = CAR(pair_462);
}
{
obj_t pair_463;
if(PAIRP(arg1067_270)){
pair_463 = arg1067_270;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, arg1067_270, string1707___r4_control_features_6_9, BINT(((long)4806)));
exit( -1 );}
arg1065_268 = CDR(pair_463);
}
}
head1009_256 = MAKE_PAIR(arg1065_268, BNIL);
}
{
obj_t l1007_257;
obj_t tail1010_258;
{
obj_t arg1058_260;
{
obj_t pair_466;
if(PAIRP(l_233)){
pair_466 = l_233;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l_233, string1707___r4_control_features_6_9, BINT(((long)4806)));
exit( -1 );}
arg1058_260 = CDR(pair_466);
}
l1007_257 = arg1058_260;
tail1010_258 = head1009_256;
lname1008_259:
{
bool_t test1059_261;
test1059_261 = PAIRP(l1007_257);
if(test1059_261){
{
obj_t newtail1011_262;
{
obj_t arg1061_264;
{
obj_t arg1063_266;
{
obj_t pair_468;
if(test1059_261){
pair_468 = l1007_257;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l1007_257, string1707___r4_control_features_6_9, BINT(((long)4806)));
exit( -1 );}
arg1063_266 = CAR(pair_468);
}
{
obj_t pair_469;
if(PAIRP(arg1063_266)){
pair_469 = arg1063_266;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, arg1063_266, string1707___r4_control_features_6_9, BINT(((long)4806)));
exit( -1 );}
arg1061_264 = CDR(pair_469);
}
}
newtail1011_262 = MAKE_PAIR(arg1061_264, BNIL);
}
SET_CDR(tail1010_258, newtail1011_262);
{
obj_t arg1060_263;
{
obj_t pair_474;
if(PAIRP(l1007_257)){
pair_474 = l1007_257;
}
 else {
bigloo_type_error_location_103___error(symbol1734___r4_control_features_6_9, string1710___r4_control_features_6_9, l1007_257, string1707___r4_control_features_6_9, BINT(((long)4806)));
exit( -1 );}
arg1060_263 = CDR(pair_474);
}
{
obj_t tail1010_1788;
obj_t l1007_1787;
l1007_1787 = arg1060_263;
tail1010_1788 = newtail1011_262;
tail1010_258 = tail1010_1788;
l1007_257 = l1007_1787;
goto lname1008_259;
}
}
}
}
 else {
if(NULLP(l1007_257)){
arg1056_253 = head1009_256;
}
 else {
arg1056_253 = debug_error_location_199___error(string1736___r4_control_features_6_9, string1737___r4_control_features_6_9, l1007_257, string1738___r4_control_features_6_9, BINT(((long)7610)));
}
}
}
}
}
}
{
obj_t l_1793;
l_1793 = arg1056_253;
l_233 = l_1793;
goto loop_234;
}
}
}
}
}
}
}
POP_TRACE();
return aux1199_496;
}
}
}
}


/* _for-each1219 */obj_t _for_each1219_134___r4_control_features_6_9(obj_t env_528, obj_t f_529, obj_t l_530)
{
{
obj_t aux_1795;
if(PROCEDUREP(f_529)){
aux_1795 = f_529;
}
 else {
bigloo_type_error_location_103___error(symbol1864___r4_control_features_6_9, string1712___r4_control_features_6_9, f_529, string1707___r4_control_features_6_9, BINT(((long)4570)));
exit( -1 );}
return for_each_73___r4_control_features_6_9(aux_1795, l_530);
}
}


/* force */obj_t force___r4_control_features_6_9(obj_t promise_13)
{
{
obj_t symbol1202_969;
symbol1202_969 = symbol1865___r4_control_features_6_9;
{
PUSH_TRACE(symbol1202_969);
BUNSPEC;
{
obj_t aux1201_970;
{
obj_t fun_971;
if(PROCEDUREP(promise_13)){
fun_971 = promise_13;
}
 else {
bigloo_type_error_location_103___error(symbol1865___r4_control_features_6_9, string1712___r4_control_features_6_9, promise_13, string1707___r4_control_features_6_9, BINT(((long)5082)));
exit( -1 );}
{
bool_t test1540_972;
test1540_972 = PROCEDURE_CORRECT_ARITYP(fun_971, ((long)0));
if(test1540_972){
aux1201_970 = PROCEDURE_ENTRY(fun_971)(promise_13, BEOA);
}
 else {
error_location_112___error(string1866___r4_control_features_6_9, list1867___r4_control_features_6_9, fun_971, string1707___r4_control_features_6_9, BINT(((long)5082)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
POP_TRACE();
return aux1201_970;
}
}
}
}


/* _force */obj_t _force___r4_control_features_6_9(obj_t env_531, obj_t promise_532)
{
{
obj_t promise_973;
promise_973 = promise_532;
{
obj_t symbol1202_974;
symbol1202_974 = symbol1865___r4_control_features_6_9;
{
PUSH_TRACE(symbol1202_974);
BUNSPEC;
{
obj_t aux1201_975;
{
obj_t fun_976;
if(PROCEDUREP(promise_973)){
fun_976 = promise_973;
}
 else {
bigloo_type_error_location_103___error(symbol1865___r4_control_features_6_9, string1712___r4_control_features_6_9, promise_973, string1707___r4_control_features_6_9, BINT(((long)5082)));
exit( -1 );}
{
bool_t test1540_977;
test1540_977 = PROCEDURE_CORRECT_ARITYP(fun_976, ((long)0));
if(test1540_977){
aux1201_975 = PROCEDURE_ENTRY(fun_976)(promise_973, BEOA);
}
 else {
error_location_112___error(string1866___r4_control_features_6_9, list1867___r4_control_features_6_9, fun_976, string1707___r4_control_features_6_9, BINT(((long)5082)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
POP_TRACE();
return aux1201_975;
}
}
}
}
}


/* make-promise */obj_t make_promise_21___r4_control_features_6_9(obj_t proc_14)
{
{
obj_t symbol1204_499;
symbol1204_499 = symbol1869___r4_control_features_6_9;
{
PUSH_TRACE(symbol1204_499);
BUNSPEC;
{
obj_t aux1203_500;
{
obj_t result_ready__3_273;
obj_t result_274;
result_ready__3_273 = MAKE_CELL(BFALSE);
result_274 = MAKE_CELL(BFALSE);
{
obj_t lambda1071_533;
lambda1071_533 = make_fx_procedure(lambda1071___r4_control_features_6_9, ((long)0), ((long)3));
PROCEDURE_SET(lambda1071_533, ((long)0), proc_14);
PROCEDURE_SET(lambda1071_533, ((long)1), result_ready__3_273);
PROCEDURE_SET(lambda1071_533, ((long)2), result_274);
aux1203_500 = lambda1071_533;
}
}
POP_TRACE();
return aux1203_500;
}
}
}
}


/* _make-promise1220 */obj_t _make_promise1220_238___r4_control_features_6_9(obj_t env_534, obj_t proc_535)
{
{
obj_t aux_1836;
if(PROCEDUREP(proc_535)){
aux_1836 = proc_535;
}
 else {
bigloo_type_error_location_103___error(symbol1870___r4_control_features_6_9, string1712___r4_control_features_6_9, proc_535, string1707___r4_control_features_6_9, BINT(((long)5316)));
exit( -1 );}
return make_promise_21___r4_control_features_6_9(aux_1836);
}
}


/* lambda1071 */obj_t lambda1071___r4_control_features_6_9(obj_t env_536)
{
{
obj_t proc_537;
obj_t result_ready__3_538;
obj_t result_539;
proc_537 = PROCEDURE_REF(env_536, ((long)0));
result_ready__3_538 = PROCEDURE_REF(env_536, ((long)1));
result_539 = PROCEDURE_REF(env_536, ((long)2));
{
{
bool_t test_1846;
{
obj_t aux_1847;
aux_1847 = CELL_REF(result_ready__3_538);
test_1846 = CBOOL(aux_1847);
}
if(test_1846){
return CELL_REF(result_539);
}
 else {
obj_t x_276;
{
obj_t fun_836;
if(PROCEDUREP(proc_537)){
fun_836 = proc_537;
}
 else {
bigloo_type_error_location_103___error(symbol1871___r4_control_features_6_9, string1712___r4_control_features_6_9, proc_537, string1707___r4_control_features_6_9, BINT(((long)5459)));
exit( -1 );}
{
bool_t test1563_843;
test1563_843 = PROCEDURE_CORRECT_ARITYP(fun_836, ((long)0));
if(test1563_843){
x_276 = PROCEDURE_ENTRY(fun_836)(proc_537, BEOA);
}
 else {
error_location_112___error(string1872___r4_control_features_6_9, list1873___r4_control_features_6_9, fun_836, string1707___r4_control_features_6_9, BINT(((long)5459)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
{
bool_t test_1861;
{
obj_t aux_1862;
aux_1862 = CELL_REF(result_ready__3_538);
test_1861 = CBOOL(aux_1862);
}
if(test_1861){
return CELL_REF(result_539);
}
 else {
CELL_SET(result_ready__3_538, BTRUE);
CELL_SET(result_539, x_276);
return CELL_REF(result_539);
}
}
}
}
}
}
}


/* call/cc */obj_t call_cc_68___r4_control_features_6_9(obj_t proc_15)
{
{
obj_t symbol1206_501;
symbol1206_501 = symbol1874___r4_control_features_6_9;
{
PUSH_TRACE(symbol1206_501);
BUNSPEC;
{
obj_t aux1205_502;
{
obj_t arg1072_543;
arg1072_543 = make_fx_procedure(arg1072___r4_control_features_6_9, ((long)1), ((long)1));
PROCEDURE_SET(arg1072_543, ((long)0), proc_15);
aux1205_502 = call_cc(arg1072_543);
}
POP_TRACE();
return aux1205_502;
}
}
}
}


/* _call/cc1221 */obj_t _call_cc1221_225___r4_control_features_6_9(obj_t env_544, obj_t proc_545)
{
{
obj_t aux_1869;
if(PROCEDUREP(proc_545)){
aux_1869 = proc_545;
}
 else {
bigloo_type_error_location_103___error(symbol1875___r4_control_features_6_9, string1712___r4_control_features_6_9, proc_545, string1707___r4_control_features_6_9, BINT(((long)5819)));
exit( -1 );}
return call_cc_68___r4_control_features_6_9(aux_1869);
}
}


/* arg1072 */obj_t arg1072___r4_control_features_6_9(obj_t env_546, obj_t cont_548)
{
{
obj_t proc_547;
proc_547 = PROCEDURE_REF(env_546, ((long)0));
{
obj_t cont_278;
cont_278 = cont_548;
{
obj_t arg1076_542;
arg1076_542 = make_va_procedure(arg1076___r4_control_features_6_9, ((long)-1), ((long)1));
PROCEDURE_SET(arg1076_542, ((long)0), cont_278);
{
obj_t fun_856;
if(PROCEDUREP(proc_547)){
fun_856 = proc_547;
}
 else {
bigloo_type_error_location_103___error(symbol1876___r4_control_features_6_9, string1712___r4_control_features_6_9, proc_547, string1707___r4_control_features_6_9, BINT(((long)5951)));
exit( -1 );}
{
bool_t test1587_863;
test1587_863 = PROCEDURE_CORRECT_ARITYP(fun_856, ((long)1));
if(test1587_863){
return PROCEDURE_ENTRY(fun_856)(proc_547, arg1076_542, BEOA);
}
 else {
error_location_112___error(string1877___r4_control_features_6_9, list1878___r4_control_features_6_9, fun_856, string1707___r4_control_features_6_9, BINT(((long)5951)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
}
}
}
}


/* arg1076 */obj_t arg1076___r4_control_features_6_9(obj_t env_549, obj_t vals_551)
{
{
obj_t cont_550;
cont_550 = PROCEDURE_REF(env_549, ((long)0));
{
obj_t vals_281;
vals_281 = vals_551;
{
bool_t test1078_283;
{
bool_t test1080_285;
test1080_285 = PAIRP(vals_281);
if(test1080_285){
obj_t arg1081_286;
{
obj_t pair_480;
if(test1080_285){
pair_480 = vals_281;
}
 else {
bigloo_type_error_location_103___error(symbol1880___r4_control_features_6_9, string1710___r4_control_features_6_9, vals_281, string1707___r4_control_features_6_9, BINT(((long)6003)));
exit( -1 );}
arg1081_286 = CDR(pair_480);
}
test1078_283 = NULLP(arg1081_286);
}
 else {
test1078_283 = ((bool_t)0);
}
}
if(test1078_283){
obj_t arg1079_284;
{
obj_t pair_482;
if(PAIRP(vals_281)){
pair_482 = vals_281;
}
 else {
bigloo_type_error_location_103___error(symbol1880___r4_control_features_6_9, string1710___r4_control_features_6_9, vals_281, string1707___r4_control_features_6_9, BINT(((long)6029)));
exit( -1 );}
arg1079_284 = CAR(pair_482);
}
{
obj_t fun_882;
if(PROCEDUREP(cont_550)){
fun_882 = cont_550;
}
 else {
bigloo_type_error_location_103___error(symbol1880___r4_control_features_6_9, string1712___r4_control_features_6_9, cont_550, string1707___r4_control_features_6_9, BINT(((long)6022)));
exit( -1 );}
{
bool_t test1619_889;
test1619_889 = PROCEDURE_CORRECT_ARITYP(fun_882, ((long)1));
if(test1619_889){
return PROCEDURE_ENTRY(fun_882)(cont_550, arg1079_284, BEOA);
}
 else {
error_location_112___error(string1881___r4_control_features_6_9, list1882___r4_control_features_6_9, fun_882, string1707___r4_control_features_6_9, BINT(((long)6022)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
}
 else {
_res_number__75___r5_control_features_6_4 = BINT(((long)-1));
{
obj_t fun_896;
if(PROCEDUREP(cont_550)){
fun_896 = cont_550;
}
 else {
bigloo_type_error_location_103___error(symbol1880___r4_control_features_6_9, string1712___r4_control_features_6_9, cont_550, string1707___r4_control_features_6_9, BINT(((long)6097)));
exit( -1 );}
{
bool_t test1634_903;
test1634_903 = PROCEDURE_CORRECT_ARITYP(fun_896, ((long)1));
if(test1634_903){
return PROCEDURE_ENTRY(fun_896)(cont_550, vals_281, BEOA);
}
 else {
error_location_112___error(string1881___r4_control_features_6_9, list1885___r4_control_features_6_9, fun_896, string1707___r4_control_features_6_9, BINT(((long)6097)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
}
}
}
}
}
}


/* call-with-current-continuation */obj_t call_with_current_continuation_81___r4_control_features_6_9(obj_t proc_16)
{
{
obj_t symbol1208_978;
symbol1208_978 = symbol1887___r4_control_features_6_9;
{
PUSH_TRACE(symbol1208_978);
BUNSPEC;
{
obj_t aux1207_979;
aux1207_979 = call_cc_68___r4_control_features_6_9(proc_16);
POP_TRACE();
return aux1207_979;
}
}
}
}


/* _call-with-current-continuation1222 */obj_t _call_with_current_continuation1222_235___r4_control_features_6_9(obj_t env_552, obj_t proc_553)
{
{
obj_t proc_980;
if(PROCEDUREP(proc_553)){
proc_980 = proc_553;
}
 else {
bigloo_type_error_location_103___error(symbol1888___r4_control_features_6_9, string1712___r4_control_features_6_9, proc_553, string1707___r4_control_features_6_9, BINT(((long)6339)));
exit( -1 );}
{
obj_t symbol1208_981;
symbol1208_981 = symbol1887___r4_control_features_6_9;
{
PUSH_TRACE(symbol1208_981);
BUNSPEC;
{
obj_t aux1207_982;
aux1207_982 = call_cc_68___r4_control_features_6_9(proc_980);
POP_TRACE();
return aux1207_982;
}
}
}
}
}


/* dynamic-wind */obj_t dynamic_wind_31___r4_control_features_6_9(obj_t before_17, obj_t thunk_18, obj_t after_19)
{
{
obj_t symbol1210_505;
symbol1210_505 = symbol1889___r4_control_features_6_9;
{
PUSH_TRACE(symbol1210_505);
BUNSPEC;
{
obj_t aux1209_506;
{
bool_t test1650_917;
test1650_917 = PROCEDURE_CORRECT_ARITYP(before_17, ((long)0));
if(test1650_917){
PROCEDURE_ENTRY(before_17)(before_17, BEOA);
}
 else {
error_location_112___error(string1890___r4_control_features_6_9, list1891___r4_control_features_6_9, before_17, string1707___r4_control_features_6_9, BINT(((long)6712)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
{
PUSH_BEFORE(before_17);
{
obj_t val1012_289;
val1012_289 = handling_function1085___r4_control_features_6_9(thunk_18);
{
bool_t test1657_925;
test1657_925 = PROCEDURE_CORRECT_ARITYP(after_19, ((long)0));
if(test1657_925){
PROCEDURE_ENTRY(after_19)(after_19, BEOA);
}
 else {
error_location_112___error(string1890___r4_control_features_6_9, list1893___r4_control_features_6_9, after_19, string1707___r4_control_features_6_9, BINT(((long)6806)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
POP_BEFORE();
{
bool_t test1082_290;
{
obj_t aux_1961;
aux_1961 = val_from_exit__100___bexit(val1012_289);
test1082_290 = CBOOL(aux_1961);
}
if(test1082_290){
obj_t arg1083_291;
obj_t arg1084_292;
{
obj_t pair_483;
if(PAIRP(val1012_289)){
pair_483 = val1012_289;
}
 else {
bigloo_type_error_location_103___error(symbol1889___r4_control_features_6_9, string1710___r4_control_features_6_9, val1012_289, string1707___r4_control_features_6_9, BINT(((long)6819)));
exit( -1 );}
arg1083_291 = CAR(pair_483);
}
{
obj_t pair_484;
if(PAIRP(val1012_289)){
pair_484 = val1012_289;
}
 else {
bigloo_type_error_location_103___error(symbol1889___r4_control_features_6_9, string1710___r4_control_features_6_9, val1012_289, string1707___r4_control_features_6_9, BINT(((long)6819)));
exit( -1 );}
arg1084_292 = CDR(pair_484);
}
aux1209_506 = unwind_until__178___bexit(arg1083_291, arg1084_292);
}
 else {
aux1209_506 = val1012_289;
}
}
}
}
POP_TRACE();
return aux1209_506;
}
}
}
}


/* handling_function1085 */obj_t handling_function1085___r4_control_features_6_9(obj_t thunk_558)
{
jmp_buf jmpbuf;
obj_t an_exit1013_294;
if( SET_EXIT(an_exit1013_294) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1013_294 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1013_294, ((bool_t)0));
{
obj_t val1014_295;
{
bool_t test1680_945;
test1680_945 = PROCEDURE_CORRECT_ARITYP(thunk_558, ((long)0));
if(test1680_945){
val1014_295 = PROCEDURE_ENTRY(thunk_558)(thunk_558, BEOA);
}
 else {
error_location_112___error(string1895___r4_control_features_6_9, list1896___r4_control_features_6_9, thunk_558, string1707___r4_control_features_6_9, BINT(((long)6784)));
FAILURE(symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9,symbol1708___r4_control_features_6_9);}
}
POP_EXIT();
return val1014_295;
}
}
}
}


/* _dynamic-wind1223 */obj_t _dynamic_wind1223_143___r4_control_features_6_9(obj_t env_554, obj_t before_555, obj_t thunk_556, obj_t after_557)
{
{
obj_t aux_2002;
obj_t aux_1996;
obj_t aux_1990;
if(PROCEDUREP(after_557)){
aux_2002 = after_557;
}
 else {
bigloo_type_error_location_103___error(symbol1898___r4_control_features_6_9, string1712___r4_control_features_6_9, after_557, string1707___r4_control_features_6_9, BINT(((long)6634)));
exit( -1 );}
if(PROCEDUREP(thunk_556)){
aux_1996 = thunk_556;
}
 else {
bigloo_type_error_location_103___error(symbol1898___r4_control_features_6_9, string1712___r4_control_features_6_9, thunk_556, string1707___r4_control_features_6_9, BINT(((long)6634)));
exit( -1 );}
if(PROCEDUREP(before_555)){
aux_1990 = before_555;
}
 else {
bigloo_type_error_location_103___error(symbol1898___r4_control_features_6_9, string1712___r4_control_features_6_9, before_555, string1707___r4_control_features_6_9, BINT(((long)6634)));
exit( -1 );}
return dynamic_wind_31___r4_control_features_6_9(aux_1990, aux_1996, aux_2002);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_control_features_6_9()
{
{
obj_t symbol1212_507;
symbol1212_507 = symbol1899___r4_control_features_6_9;
{
PUSH_TRACE(symbol1212_507);
BUNSPEC;
{
obj_t aux1211_508;
aux1211_508 = module_initialization_70___error(((long)0), "__R4_CONTROL_FEATURES_6_9");
POP_TRACE();
return aux1211_508;
}
}
}
}

