/*===========================================================================*/
/*   (Ieee/pair-list.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t cer___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t append___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cdadar1269___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t car___r4_pairs_and_lists_6_3(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _epair__200___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t set_car__100___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _list_tail1275_0___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t cddr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdddr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t append__79___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t append_list_2___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cddar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _memv___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _memq___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t cddddr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdddar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _list_set_1277_149___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t, obj_t);
extern obj_t assv___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t caddr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cddaar1267___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cadar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _reverse___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _pair__14___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cdaddr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _append___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cddddr1271___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _last_pair_60___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _caaaar1256___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cdadar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _set_cdr_1273_240___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _remq__174___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t cadr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _caaddr1261___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cdadr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t list_ref_194___r4_pairs_and_lists_6_3(obj_t, long);
extern obj_t caar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdaar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cddadr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _caaar1248___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _caar1244___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _car1241___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cddaar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _list_ref1276_64___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _caddr1251___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cddr1247___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern bool_t pair__182___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cons___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t caadr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _list___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t caaar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t remq__51___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cdaadr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdaaar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _remq___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _remove__17___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _null__116___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cadadr1263___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _caddar1262___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cdadr1254___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _assoc___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t last_pair_93___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cddar1253___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t memv___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern bool_t null__121___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cdaaar1260___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _econs___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t, obj_t);
static obj_t _cdaddr1266___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t assoc___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t list_tail_190___r4_pairs_and_lists_6_3(obj_t, long);
extern obj_t econs___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t remove__21___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cons___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t list___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cons__190___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _member___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _cddadr1268___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern long list_length(obj_t);
extern obj_t remq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cdddar1270___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _set_car_1272_193___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _caaadr1257___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t remove___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _caadar1258___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _set_cer_1274_122___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t cadddr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t list_set__58___r4_pairs_and_lists_6_3(obj_t, long, obj_t);
static obj_t _caadr1249___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t caddar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _list__66___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cadr1245___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cdr1242___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cadar1250___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cdar1246___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t caaddr___r4_pairs_and_lists_6_3(obj_t);
extern bool_t eqv__112___r4_equivalence_6_2(obj_t, obj_t);
static obj_t _assv___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _assq___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t caadar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _reverse__87___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern bool_t epair__249___r4_pairs_and_lists_6_3(obj_t);
extern bool_t list__240___r4_pairs_and_lists_6_3(obj_t);
static obj_t imported_modules_init_94___r4_pairs_and_lists_6_3();
extern obj_t cadadr___r4_pairs_and_lists_6_3(obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
static obj_t cons_1_212___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cadaar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _append__27___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _length___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t _append_2_70___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _cadaar1259___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t set_cer__213___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _remove___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _cadddr1264___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t caaadr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cer1243___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t caaaar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cdaar1252___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t set_cdr__56___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cdddr1255___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cdaadr1265___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( cons_env_70___r4_pairs_and_lists_6_3, _cons___r4_pairs_and_lists_6_31282, _cons___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( car_env_2___r4_pairs_and_lists_6_3, _car1241___r4_pairs_and_lists_6_31283, _car1241___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( pair__env_127___r4_pairs_and_lists_6_3, _pair__14___r4_pairs_and_lists_6_31284, _pair__14___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caaar_env_253___r4_pairs_and_lists_6_3, _caaar1248___r4_pairs_and_lists_6_31285, _caaar1248___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( reverse__env_230___r4_pairs_and_lists_6_3, _reverse__87___r4_pairs_and_lists_6_31286, _reverse__87___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caddr_env_228___r4_pairs_and_lists_6_3, _caddr1251___r4_pairs_and_lists_6_31287, _caddr1251___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cddaar_env_237___r4_pairs_and_lists_6_3, _cddaar1267___r4_pairs_and_lists_6_31288, _cddaar1267___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caaaar_env_120___r4_pairs_and_lists_6_3, _caaaar1256___r4_pairs_and_lists_6_31289, _caaaar1256___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cddddr_env_176___r4_pairs_and_lists_6_3, _cddddr1271___r4_pairs_and_lists_6_31290, _cddddr1271___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remove_env_232___r4_pairs_and_lists_6_3, _remove___r4_pairs_and_lists_6_31291, _remove___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( caaddr_env_185___r4_pairs_and_lists_6_3, _caaddr1261___r4_pairs_and_lists_6_31292, _caaddr1261___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( assv_env_68___r4_pairs_and_lists_6_3, _assv___r4_pairs_and_lists_6_31293, _assv___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( assq_env_11___r4_pairs_and_lists_6_3, _assq___r4_pairs_and_lists_6_31294, _assq___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( last_pair_env_209___r4_pairs_and_lists_6_3, _last_pair_60___r4_pairs_and_lists_6_31295, _last_pair_60___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( set_cdr__env_88___r4_pairs_and_lists_6_3, _set_cdr_1273_240___r4_pairs_and_lists_6_31296, _set_cdr_1273_240___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cdadr_env_187___r4_pairs_and_lists_6_3, _cdadr1254___r4_pairs_and_lists_6_31297, _cdadr1254___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( list_ref_env_246___r4_pairs_and_lists_6_3, _list_ref1276_64___r4_pairs_and_lists_6_31298, _list_ref1276_64___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cddar_env_87___r4_pairs_and_lists_6_3, _cddar1253___r4_pairs_and_lists_6_31299, _cddar1253___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cadadr_env_215___r4_pairs_and_lists_6_3, _cadadr1263___r4_pairs_and_lists_6_31300, _cadadr1263___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caddar_env_165___r4_pairs_and_lists_6_3, _caddar1262___r4_pairs_and_lists_6_31301, _caddar1262___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( append_env_23___r4_pairs_and_lists_6_3, _append___r4_pairs_and_lists_6_31302, va_generic_entry, _append___r4_pairs_and_lists_6_3, -1 );
DEFINE_EXPORT_PROCEDURE( cdaaar_env_65___r4_pairs_and_lists_6_3, _cdaaar1260___r4_pairs_and_lists_6_31303, _cdaaar1260___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdaddr_env_139___r4_pairs_and_lists_6_3, _cdaddr1266___r4_pairs_and_lists_6_31304, _cdaddr1266___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cadr_env_124___r4_pairs_and_lists_6_3, _cadr1245___r4_pairs_and_lists_6_31305, _cadr1245___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( econs_env_160___r4_pairs_and_lists_6_3, _econs___r4_pairs_and_lists_6_31306, _econs___r4_pairs_and_lists_6_3, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( cdar_env_110___r4_pairs_and_lists_6_3, _cdar1246___r4_pairs_and_lists_6_31307, _cdar1246___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remq__env_181___r4_pairs_and_lists_6_3, _remq__174___r4_pairs_and_lists_6_31308, _remq__174___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cdr_env_184___r4_pairs_and_lists_6_3, _cdr1242___r4_pairs_and_lists_6_31309, _cdr1242___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caadr_env_216___r4_pairs_and_lists_6_3, _caadr1249___r4_pairs_and_lists_6_31310, _caadr1249___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remove__env_123___r4_pairs_and_lists_6_3, _remove__17___r4_pairs_and_lists_6_31311, _remove__17___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cadar_env_80___r4_pairs_and_lists_6_3, _cadar1250___r4_pairs_and_lists_6_31312, _cadar1250___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( list_tail_env_188___r4_pairs_and_lists_6_3, _list_tail1275_0___r4_pairs_and_lists_6_31313, _list_tail1275_0___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cddadr_env_82___r4_pairs_and_lists_6_3, _cddadr1268___r4_pairs_and_lists_6_31314, _cddadr1268___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( assoc_env_175___r4_pairs_and_lists_6_3, _assoc___r4_pairs_and_lists_6_31315, _assoc___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( list__env_95___r4_pairs_and_lists_6_3, _list__66___r4_pairs_and_lists_6_31316, _list__66___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdddar_env_95___r4_pairs_and_lists_6_3, _cdddar1270___r4_pairs_and_lists_6_31317, _cdddar1270___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caaadr_env_84___r4_pairs_and_lists_6_3, _caaadr1257___r4_pairs_and_lists_6_31318, _caaadr1257___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caadar_env_94___r4_pairs_and_lists_6_3, _caadar1258___r4_pairs_and_lists_6_31319, _caadar1258___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( list_set__env_81___r4_pairs_and_lists_6_3, _list_set_1277_149___r4_pairs_and_lists_6_31320, _list_set_1277_149___r4_pairs_and_lists_6_3, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( length_env_176___r4_pairs_and_lists_6_3, _length___r4_pairs_and_lists_6_31321, _length___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remq_env_28___r4_pairs_and_lists_6_3, _remq___r4_pairs_and_lists_6_31322, _remq___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( null__env_100___r4_pairs_and_lists_6_3, _null__116___r4_pairs_and_lists_6_31323, _null__116___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( set_car__env_189___r4_pairs_and_lists_6_3, _set_car_1272_193___r4_pairs_and_lists_6_31324, _set_car_1272_193___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( list_env_29___r4_pairs_and_lists_6_3, _list___r4_pairs_and_lists_6_31325, va_generic_entry, _list___r4_pairs_and_lists_6_3, -1 );
DEFINE_EXPORT_PROCEDURE( cer_env_92___r4_pairs_and_lists_6_3, _cer1243___r4_pairs_and_lists_6_31326, _cer1243___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( set_cer__env_36___r4_pairs_and_lists_6_3, _set_cer_1274_122___r4_pairs_and_lists_6_31327, _set_cer_1274_122___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cons__env_67___r4_pairs_and_lists_6_3, _cons__190___r4_pairs_and_lists_6_31328, va_generic_entry, _cons__190___r4_pairs_and_lists_6_3, -2 );
DEFINE_EXPORT_PROCEDURE( reverse_env_76___r4_pairs_and_lists_6_3, _reverse___r4_pairs_and_lists_6_31329, _reverse___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdaar_env_98___r4_pairs_and_lists_6_3, _cdaar1252___r4_pairs_and_lists_6_31330, _cdaar1252___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdddr_env_34___r4_pairs_and_lists_6_3, _cdddr1255___r4_pairs_and_lists_6_31331, _cdddr1255___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( append__env_141___r4_pairs_and_lists_6_3, _append__27___r4_pairs_and_lists_6_31332, _append__27___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cadaar_env_111___r4_pairs_and_lists_6_3, _cadaar1259___r4_pairs_and_lists_6_31333, _cadaar1259___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( memv_env_45___r4_pairs_and_lists_6_3, _memv___r4_pairs_and_lists_6_31334, _memv___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cadddr_env_191___r4_pairs_and_lists_6_3, _cadddr1264___r4_pairs_and_lists_6_31335, _cadddr1264___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( memq_env_197___r4_pairs_and_lists_6_3, _memq___r4_pairs_and_lists_6_31336, _memq___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( member_env_128___r4_pairs_and_lists_6_3, _member___r4_pairs_and_lists_6_31337, _member___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_STRING( string1279___r4_pairs_and_lists_6_3, string1279___r4_pairs_and_lists_6_31338, "Type `extended pair' expected for expression", 44 );
DEFINE_STRING( string1280___r4_pairs_and_lists_6_3, string1280___r4_pairs_and_lists_6_31339, "set-cer!", 8 );
DEFINE_STRING( string1278___r4_pairs_and_lists_6_3, string1278___r4_pairs_and_lists_6_31340, "cer", 3 );
DEFINE_EXPORT_PROCEDURE( cdaadr_env_56___r4_pairs_and_lists_6_3, _cdaadr1265___r4_pairs_and_lists_6_31341, _cdaadr1265___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdadar_env_63___r4_pairs_and_lists_6_3, _cdadar1269___r4_pairs_and_lists_6_31342, _cdadar1269___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caar_env_69___r4_pairs_and_lists_6_3, _caar1244___r4_pairs_and_lists_6_31343, _caar1244___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( epair__env_215___r4_pairs_and_lists_6_3, _epair__200___r4_pairs_and_lists_6_31344, _epair__200___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cddr_env_173___r4_pairs_and_lists_6_3, _cddr1247___r4_pairs_and_lists_6_31345, _cddr1247___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( append_2_env_90___r4_pairs_and_lists_6_3, _append_2_70___r4_pairs_and_lists_6_31346, _append_2_70___r4_pairs_and_lists_6_3, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___r4_pairs_and_lists_6_3(long checksum_1321, char * from_1322)
{
if(CBOOL(require_initialization_114___r4_pairs_and_lists_6_3)){
require_initialization_114___r4_pairs_and_lists_6_3 = BBOOL(((bool_t)0));
imported_modules_init_94___r4_pairs_and_lists_6_3();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* pair? */bool_t pair__182___r4_pairs_and_lists_6_3(obj_t obj_1)
{
return PAIRP(obj_1);
}


/* _pair? */obj_t _pair__14___r4_pairs_and_lists_6_3(obj_t env_1123, obj_t obj_1124)
{
{
bool_t aux_1328;
{
obj_t obj_1270;
obj_1270 = obj_1124;
aux_1328 = PAIRP(obj_1270);
}
return BBOOL(aux_1328);
}
}


/* epair? */bool_t epair__249___r4_pairs_and_lists_6_3(obj_t obj_2)
{
return EXTENDED_PAIRP(obj_2);
}


/* _epair? */obj_t _epair__200___r4_pairs_and_lists_6_3(obj_t env_1125, obj_t obj_1126)
{
{
bool_t aux_1332;
{
obj_t obj_1271;
obj_1271 = obj_1126;
aux_1332 = EXTENDED_PAIRP(obj_1271);
}
return BBOOL(aux_1332);
}
}


/* cons */obj_t cons___r4_pairs_and_lists_6_3(obj_t obj1_3, obj_t obj2_4)
{
return MAKE_PAIR(obj1_3, obj2_4);
}


/* _cons */obj_t _cons___r4_pairs_and_lists_6_3(obj_t env_1127, obj_t obj1_1128, obj_t obj2_1129)
{
{
obj_t obj1_1272;
obj_t obj2_1273;
obj1_1272 = obj1_1128;
obj2_1273 = obj2_1129;
return MAKE_PAIR(obj1_1272, obj2_1273);
}
}


/* econs */obj_t econs___r4_pairs_and_lists_6_3(obj_t obj1_5, obj_t obj2_6, obj_t obj3_7)
{
return MAKE_EXTENDED_PAIR(obj1_5, obj2_6, obj3_7);
}


/* _econs */obj_t _econs___r4_pairs_and_lists_6_3(obj_t env_1130, obj_t obj1_1131, obj_t obj2_1132, obj_t obj3_1133)
{
{
obj_t obj1_1274;
obj_t obj2_1275;
obj_t obj3_1276;
obj1_1274 = obj1_1131;
obj2_1275 = obj2_1132;
obj3_1276 = obj3_1133;
return MAKE_EXTENDED_PAIR(obj1_1274, obj2_1275, obj3_1276);
}
}


/* car */obj_t car___r4_pairs_and_lists_6_3(obj_t pair_8)
{
return CAR(pair_8);
}


/* _car1241 */obj_t _car1241___r4_pairs_and_lists_6_3(obj_t env_1134, obj_t pair_1135)
{
{
obj_t pair_1277;
pair_1277 = pair_1135;
return CAR(pair_1277);
}
}


/* cdr */obj_t cdr___r4_pairs_and_lists_6_3(obj_t pair_9)
{
return CDR(pair_9);
}


/* _cdr1242 */obj_t _cdr1242___r4_pairs_and_lists_6_3(obj_t env_1136, obj_t pair_1137)
{
{
obj_t pair_1278;
pair_1278 = pair_1137;
return CDR(pair_1278);
}
}


/* cer */obj_t cer___r4_pairs_and_lists_6_3(obj_t obj_10)
{
{
bool_t test1005_1279;
test1005_1279 = EXTENDED_PAIRP(obj_10);
if(test1005_1279){
return CER(obj_10);
}
 else {
FAILURE(string1278___r4_pairs_and_lists_6_3,string1279___r4_pairs_and_lists_6_3,obj_10);}
}
}


/* _cer1243 */obj_t _cer1243___r4_pairs_and_lists_6_3(obj_t env_1138, obj_t obj_1139)
{
{
obj_t obj_1280;
obj_1280 = obj_1139;
{
bool_t test1005_1281;
test1005_1281 = EXTENDED_PAIRP(obj_1280);
if(test1005_1281){
return CER(obj_1280);
}
 else {
FAILURE(string1278___r4_pairs_and_lists_6_3,string1279___r4_pairs_and_lists_6_3,obj_1280);}
}
}
}


/* caar */obj_t caar___r4_pairs_and_lists_6_3(obj_t pair_11)
{
{
obj_t aux_1351;
aux_1351 = CAR(pair_11);
return CAR(aux_1351);
}
}


/* _caar1244 */obj_t _caar1244___r4_pairs_and_lists_6_3(obj_t env_1140, obj_t pair_1141)
{
{
obj_t pair_1282;
pair_1282 = pair_1141;
{
obj_t aux_1354;
aux_1354 = CAR(pair_1282);
return CAR(aux_1354);
}
}
}


/* cadr */obj_t cadr___r4_pairs_and_lists_6_3(obj_t pair_12)
{
{
obj_t aux_1357;
aux_1357 = CDR(pair_12);
return CAR(aux_1357);
}
}


/* _cadr1245 */obj_t _cadr1245___r4_pairs_and_lists_6_3(obj_t env_1142, obj_t pair_1143)
{
{
obj_t pair_1283;
pair_1283 = pair_1143;
{
obj_t aux_1360;
aux_1360 = CDR(pair_1283);
return CAR(aux_1360);
}
}
}


/* cdar */obj_t cdar___r4_pairs_and_lists_6_3(obj_t pair_13)
{
{
obj_t aux_1363;
aux_1363 = CAR(pair_13);
return CDR(aux_1363);
}
}


/* _cdar1246 */obj_t _cdar1246___r4_pairs_and_lists_6_3(obj_t env_1144, obj_t pair_1145)
{
{
obj_t pair_1284;
pair_1284 = pair_1145;
{
obj_t aux_1366;
aux_1366 = CAR(pair_1284);
return CDR(aux_1366);
}
}
}


/* cddr */obj_t cddr___r4_pairs_and_lists_6_3(obj_t pair_14)
{
{
obj_t aux_1369;
aux_1369 = CDR(pair_14);
return CDR(aux_1369);
}
}


/* _cddr1247 */obj_t _cddr1247___r4_pairs_and_lists_6_3(obj_t env_1146, obj_t pair_1147)
{
{
obj_t pair_1285;
pair_1285 = pair_1147;
{
obj_t aux_1372;
aux_1372 = CDR(pair_1285);
return CDR(aux_1372);
}
}
}


/* caaar */obj_t caaar___r4_pairs_and_lists_6_3(obj_t pair_15)
{
{
obj_t aux_1375;
{
obj_t aux_1376;
aux_1376 = CAR(pair_15);
aux_1375 = CAR(aux_1376);
}
return CAR(aux_1375);
}
}


/* _caaar1248 */obj_t _caaar1248___r4_pairs_and_lists_6_3(obj_t env_1148, obj_t pair_1149)
{
{
obj_t pair_1286;
pair_1286 = pair_1149;
{
obj_t aux_1380;
{
obj_t aux_1381;
aux_1381 = CAR(pair_1286);
aux_1380 = CAR(aux_1381);
}
return CAR(aux_1380);
}
}
}


/* caadr */obj_t caadr___r4_pairs_and_lists_6_3(obj_t pair_16)
{
{
obj_t aux_1385;
{
obj_t aux_1386;
aux_1386 = CDR(pair_16);
aux_1385 = CAR(aux_1386);
}
return CAR(aux_1385);
}
}


/* _caadr1249 */obj_t _caadr1249___r4_pairs_and_lists_6_3(obj_t env_1150, obj_t pair_1151)
{
{
obj_t pair_1287;
pair_1287 = pair_1151;
{
obj_t aux_1390;
{
obj_t aux_1391;
aux_1391 = CDR(pair_1287);
aux_1390 = CAR(aux_1391);
}
return CAR(aux_1390);
}
}
}


/* cadar */obj_t cadar___r4_pairs_and_lists_6_3(obj_t pair_17)
{
{
obj_t aux_1395;
{
obj_t aux_1396;
aux_1396 = CAR(pair_17);
aux_1395 = CDR(aux_1396);
}
return CAR(aux_1395);
}
}


/* _cadar1250 */obj_t _cadar1250___r4_pairs_and_lists_6_3(obj_t env_1152, obj_t pair_1153)
{
{
obj_t pair_1288;
pair_1288 = pair_1153;
{
obj_t aux_1400;
{
obj_t aux_1401;
aux_1401 = CAR(pair_1288);
aux_1400 = CDR(aux_1401);
}
return CAR(aux_1400);
}
}
}


/* caddr */obj_t caddr___r4_pairs_and_lists_6_3(obj_t pair_18)
{
{
obj_t aux_1405;
{
obj_t aux_1406;
aux_1406 = CDR(pair_18);
aux_1405 = CDR(aux_1406);
}
return CAR(aux_1405);
}
}


/* _caddr1251 */obj_t _caddr1251___r4_pairs_and_lists_6_3(obj_t env_1154, obj_t pair_1155)
{
{
obj_t pair_1289;
pair_1289 = pair_1155;
{
obj_t aux_1410;
{
obj_t aux_1411;
aux_1411 = CDR(pair_1289);
aux_1410 = CDR(aux_1411);
}
return CAR(aux_1410);
}
}
}


/* cdaar */obj_t cdaar___r4_pairs_and_lists_6_3(obj_t pair_19)
{
{
obj_t aux_1415;
{
obj_t aux_1416;
aux_1416 = CAR(pair_19);
aux_1415 = CAR(aux_1416);
}
return CDR(aux_1415);
}
}


/* _cdaar1252 */obj_t _cdaar1252___r4_pairs_and_lists_6_3(obj_t env_1156, obj_t pair_1157)
{
{
obj_t pair_1290;
pair_1290 = pair_1157;
{
obj_t aux_1420;
{
obj_t aux_1421;
aux_1421 = CAR(pair_1290);
aux_1420 = CAR(aux_1421);
}
return CDR(aux_1420);
}
}
}


/* cddar */obj_t cddar___r4_pairs_and_lists_6_3(obj_t pair_20)
{
{
obj_t aux_1425;
{
obj_t aux_1426;
aux_1426 = CAR(pair_20);
aux_1425 = CDR(aux_1426);
}
return CDR(aux_1425);
}
}


/* _cddar1253 */obj_t _cddar1253___r4_pairs_and_lists_6_3(obj_t env_1158, obj_t pair_1159)
{
{
obj_t pair_1291;
pair_1291 = pair_1159;
{
obj_t aux_1430;
{
obj_t aux_1431;
aux_1431 = CAR(pair_1291);
aux_1430 = CDR(aux_1431);
}
return CDR(aux_1430);
}
}
}


/* cdadr */obj_t cdadr___r4_pairs_and_lists_6_3(obj_t pair_21)
{
{
obj_t aux_1435;
{
obj_t aux_1436;
aux_1436 = CDR(pair_21);
aux_1435 = CAR(aux_1436);
}
return CDR(aux_1435);
}
}


/* _cdadr1254 */obj_t _cdadr1254___r4_pairs_and_lists_6_3(obj_t env_1160, obj_t pair_1161)
{
{
obj_t pair_1292;
pair_1292 = pair_1161;
{
obj_t aux_1440;
{
obj_t aux_1441;
aux_1441 = CDR(pair_1292);
aux_1440 = CAR(aux_1441);
}
return CDR(aux_1440);
}
}
}


/* cdddr */obj_t cdddr___r4_pairs_and_lists_6_3(obj_t pair_22)
{
{
obj_t aux_1445;
{
obj_t aux_1446;
aux_1446 = CDR(pair_22);
aux_1445 = CDR(aux_1446);
}
return CDR(aux_1445);
}
}


/* _cdddr1255 */obj_t _cdddr1255___r4_pairs_and_lists_6_3(obj_t env_1162, obj_t pair_1163)
{
{
obj_t pair_1293;
pair_1293 = pair_1163;
{
obj_t aux_1450;
{
obj_t aux_1451;
aux_1451 = CDR(pair_1293);
aux_1450 = CDR(aux_1451);
}
return CDR(aux_1450);
}
}
}


/* caaaar */obj_t caaaar___r4_pairs_and_lists_6_3(obj_t pair_23)
{
{
obj_t aux_1455;
{
obj_t aux_1456;
{
obj_t aux_1457;
aux_1457 = CAR(pair_23);
aux_1456 = CAR(aux_1457);
}
aux_1455 = CAR(aux_1456);
}
return CAR(aux_1455);
}
}


/* _caaaar1256 */obj_t _caaaar1256___r4_pairs_and_lists_6_3(obj_t env_1164, obj_t pair_1165)
{
{
obj_t pair_1294;
pair_1294 = pair_1165;
{
obj_t aux_1462;
{
obj_t aux_1463;
{
obj_t aux_1464;
aux_1464 = CAR(pair_1294);
aux_1463 = CAR(aux_1464);
}
aux_1462 = CAR(aux_1463);
}
return CAR(aux_1462);
}
}
}


/* caaadr */obj_t caaadr___r4_pairs_and_lists_6_3(obj_t pair_24)
{
{
obj_t aux_1469;
{
obj_t aux_1470;
{
obj_t aux_1471;
aux_1471 = CDR(pair_24);
aux_1470 = CAR(aux_1471);
}
aux_1469 = CAR(aux_1470);
}
return CAR(aux_1469);
}
}


/* _caaadr1257 */obj_t _caaadr1257___r4_pairs_and_lists_6_3(obj_t env_1166, obj_t pair_1167)
{
{
obj_t pair_1295;
pair_1295 = pair_1167;
{
obj_t aux_1476;
{
obj_t aux_1477;
{
obj_t aux_1478;
aux_1478 = CDR(pair_1295);
aux_1477 = CAR(aux_1478);
}
aux_1476 = CAR(aux_1477);
}
return CAR(aux_1476);
}
}
}


/* caadar */obj_t caadar___r4_pairs_and_lists_6_3(obj_t pair_25)
{
{
obj_t aux_1483;
{
obj_t aux_1484;
{
obj_t aux_1485;
aux_1485 = CAR(pair_25);
aux_1484 = CDR(aux_1485);
}
aux_1483 = CAR(aux_1484);
}
return CAR(aux_1483);
}
}


/* _caadar1258 */obj_t _caadar1258___r4_pairs_and_lists_6_3(obj_t env_1168, obj_t pair_1169)
{
{
obj_t pair_1296;
pair_1296 = pair_1169;
{
obj_t aux_1490;
{
obj_t aux_1491;
{
obj_t aux_1492;
aux_1492 = CAR(pair_1296);
aux_1491 = CDR(aux_1492);
}
aux_1490 = CAR(aux_1491);
}
return CAR(aux_1490);
}
}
}


/* cadaar */obj_t cadaar___r4_pairs_and_lists_6_3(obj_t pair_26)
{
{
obj_t aux_1497;
{
obj_t aux_1498;
{
obj_t aux_1499;
aux_1499 = CAR(pair_26);
aux_1498 = CAR(aux_1499);
}
aux_1497 = CDR(aux_1498);
}
return CAR(aux_1497);
}
}


/* _cadaar1259 */obj_t _cadaar1259___r4_pairs_and_lists_6_3(obj_t env_1170, obj_t pair_1171)
{
{
obj_t pair_1297;
pair_1297 = pair_1171;
{
obj_t aux_1504;
{
obj_t aux_1505;
{
obj_t aux_1506;
aux_1506 = CAR(pair_1297);
aux_1505 = CAR(aux_1506);
}
aux_1504 = CDR(aux_1505);
}
return CAR(aux_1504);
}
}
}


/* cdaaar */obj_t cdaaar___r4_pairs_and_lists_6_3(obj_t pair_27)
{
{
obj_t aux_1511;
{
obj_t aux_1512;
{
obj_t aux_1513;
aux_1513 = CAR(pair_27);
aux_1512 = CAR(aux_1513);
}
aux_1511 = CAR(aux_1512);
}
return CDR(aux_1511);
}
}


/* _cdaaar1260 */obj_t _cdaaar1260___r4_pairs_and_lists_6_3(obj_t env_1172, obj_t pair_1173)
{
{
obj_t pair_1298;
pair_1298 = pair_1173;
{
obj_t aux_1518;
{
obj_t aux_1519;
{
obj_t aux_1520;
aux_1520 = CAR(pair_1298);
aux_1519 = CAR(aux_1520);
}
aux_1518 = CAR(aux_1519);
}
return CDR(aux_1518);
}
}
}


/* caaddr */obj_t caaddr___r4_pairs_and_lists_6_3(obj_t pair_28)
{
{
obj_t aux_1525;
{
obj_t aux_1526;
{
obj_t aux_1527;
aux_1527 = CDR(pair_28);
aux_1526 = CDR(aux_1527);
}
aux_1525 = CAR(aux_1526);
}
return CAR(aux_1525);
}
}


/* _caaddr1261 */obj_t _caaddr1261___r4_pairs_and_lists_6_3(obj_t env_1174, obj_t pair_1175)
{
{
obj_t pair_1299;
pair_1299 = pair_1175;
{
obj_t aux_1532;
{
obj_t aux_1533;
{
obj_t aux_1534;
aux_1534 = CDR(pair_1299);
aux_1533 = CDR(aux_1534);
}
aux_1532 = CAR(aux_1533);
}
return CAR(aux_1532);
}
}
}


/* caddar */obj_t caddar___r4_pairs_and_lists_6_3(obj_t pair_29)
{
{
obj_t aux_1539;
{
obj_t aux_1540;
{
obj_t aux_1541;
aux_1541 = CAR(pair_29);
aux_1540 = CDR(aux_1541);
}
aux_1539 = CDR(aux_1540);
}
return CAR(aux_1539);
}
}


/* _caddar1262 */obj_t _caddar1262___r4_pairs_and_lists_6_3(obj_t env_1176, obj_t pair_1177)
{
{
obj_t pair_1300;
pair_1300 = pair_1177;
{
obj_t aux_1546;
{
obj_t aux_1547;
{
obj_t aux_1548;
aux_1548 = CAR(pair_1300);
aux_1547 = CDR(aux_1548);
}
aux_1546 = CDR(aux_1547);
}
return CAR(aux_1546);
}
}
}


/* cadadr */obj_t cadadr___r4_pairs_and_lists_6_3(obj_t pair_30)
{
{
obj_t aux_1553;
{
obj_t aux_1554;
{
obj_t aux_1555;
aux_1555 = CDR(pair_30);
aux_1554 = CAR(aux_1555);
}
aux_1553 = CDR(aux_1554);
}
return CAR(aux_1553);
}
}


/* _cadadr1263 */obj_t _cadadr1263___r4_pairs_and_lists_6_3(obj_t env_1178, obj_t pair_1179)
{
{
obj_t pair_1301;
pair_1301 = pair_1179;
{
obj_t aux_1560;
{
obj_t aux_1561;
{
obj_t aux_1562;
aux_1562 = CDR(pair_1301);
aux_1561 = CAR(aux_1562);
}
aux_1560 = CDR(aux_1561);
}
return CAR(aux_1560);
}
}
}


/* cadddr */obj_t cadddr___r4_pairs_and_lists_6_3(obj_t pair_31)
{
{
obj_t aux_1567;
{
obj_t aux_1568;
{
obj_t aux_1569;
aux_1569 = CDR(pair_31);
aux_1568 = CDR(aux_1569);
}
aux_1567 = CDR(aux_1568);
}
return CAR(aux_1567);
}
}


/* _cadddr1264 */obj_t _cadddr1264___r4_pairs_and_lists_6_3(obj_t env_1180, obj_t pair_1181)
{
{
obj_t pair_1302;
pair_1302 = pair_1181;
{
obj_t aux_1574;
{
obj_t aux_1575;
{
obj_t aux_1576;
aux_1576 = CDR(pair_1302);
aux_1575 = CDR(aux_1576);
}
aux_1574 = CDR(aux_1575);
}
return CAR(aux_1574);
}
}
}


/* cdaadr */obj_t cdaadr___r4_pairs_and_lists_6_3(obj_t pair_32)
{
{
obj_t aux_1581;
{
obj_t aux_1582;
{
obj_t aux_1583;
aux_1583 = CDR(pair_32);
aux_1582 = CAR(aux_1583);
}
aux_1581 = CAR(aux_1582);
}
return CDR(aux_1581);
}
}


/* _cdaadr1265 */obj_t _cdaadr1265___r4_pairs_and_lists_6_3(obj_t env_1182, obj_t pair_1183)
{
{
obj_t pair_1303;
pair_1303 = pair_1183;
{
obj_t aux_1588;
{
obj_t aux_1589;
{
obj_t aux_1590;
aux_1590 = CDR(pair_1303);
aux_1589 = CAR(aux_1590);
}
aux_1588 = CAR(aux_1589);
}
return CDR(aux_1588);
}
}
}


/* cdaddr */obj_t cdaddr___r4_pairs_and_lists_6_3(obj_t pair_33)
{
{
obj_t aux_1595;
{
obj_t aux_1596;
{
obj_t aux_1597;
aux_1597 = CDR(pair_33);
aux_1596 = CDR(aux_1597);
}
aux_1595 = CAR(aux_1596);
}
return CDR(aux_1595);
}
}


/* _cdaddr1266 */obj_t _cdaddr1266___r4_pairs_and_lists_6_3(obj_t env_1184, obj_t pair_1185)
{
{
obj_t pair_1304;
pair_1304 = pair_1185;
{
obj_t aux_1602;
{
obj_t aux_1603;
{
obj_t aux_1604;
aux_1604 = CDR(pair_1304);
aux_1603 = CDR(aux_1604);
}
aux_1602 = CAR(aux_1603);
}
return CDR(aux_1602);
}
}
}


/* cddaar */obj_t cddaar___r4_pairs_and_lists_6_3(obj_t pair_34)
{
{
obj_t aux_1609;
{
obj_t aux_1610;
{
obj_t aux_1611;
aux_1611 = CAR(pair_34);
aux_1610 = CAR(aux_1611);
}
aux_1609 = CDR(aux_1610);
}
return CDR(aux_1609);
}
}


/* _cddaar1267 */obj_t _cddaar1267___r4_pairs_and_lists_6_3(obj_t env_1186, obj_t pair_1187)
{
{
obj_t pair_1305;
pair_1305 = pair_1187;
{
obj_t aux_1616;
{
obj_t aux_1617;
{
obj_t aux_1618;
aux_1618 = CAR(pair_1305);
aux_1617 = CAR(aux_1618);
}
aux_1616 = CDR(aux_1617);
}
return CDR(aux_1616);
}
}
}


/* cddadr */obj_t cddadr___r4_pairs_and_lists_6_3(obj_t pair_35)
{
{
obj_t aux_1623;
{
obj_t aux_1624;
{
obj_t aux_1625;
aux_1625 = CDR(pair_35);
aux_1624 = CAR(aux_1625);
}
aux_1623 = CDR(aux_1624);
}
return CDR(aux_1623);
}
}


/* _cddadr1268 */obj_t _cddadr1268___r4_pairs_and_lists_6_3(obj_t env_1188, obj_t pair_1189)
{
{
obj_t pair_1306;
pair_1306 = pair_1189;
{
obj_t aux_1630;
{
obj_t aux_1631;
{
obj_t aux_1632;
aux_1632 = CDR(pair_1306);
aux_1631 = CAR(aux_1632);
}
aux_1630 = CDR(aux_1631);
}
return CDR(aux_1630);
}
}
}


/* cdadar */obj_t cdadar___r4_pairs_and_lists_6_3(obj_t pair_36)
{
{
obj_t aux_1637;
{
obj_t aux_1638;
{
obj_t aux_1639;
aux_1639 = CAR(pair_36);
aux_1638 = CDR(aux_1639);
}
aux_1637 = CAR(aux_1638);
}
return CDR(aux_1637);
}
}


/* _cdadar1269 */obj_t _cdadar1269___r4_pairs_and_lists_6_3(obj_t env_1190, obj_t pair_1191)
{
{
obj_t pair_1307;
pair_1307 = pair_1191;
{
obj_t aux_1644;
{
obj_t aux_1645;
{
obj_t aux_1646;
aux_1646 = CAR(pair_1307);
aux_1645 = CDR(aux_1646);
}
aux_1644 = CAR(aux_1645);
}
return CDR(aux_1644);
}
}
}


/* cdddar */obj_t cdddar___r4_pairs_and_lists_6_3(obj_t pair_37)
{
{
obj_t aux_1651;
{
obj_t aux_1652;
{
obj_t aux_1653;
aux_1653 = CAR(pair_37);
aux_1652 = CDR(aux_1653);
}
aux_1651 = CDR(aux_1652);
}
return CDR(aux_1651);
}
}


/* _cdddar1270 */obj_t _cdddar1270___r4_pairs_and_lists_6_3(obj_t env_1192, obj_t pair_1193)
{
{
obj_t pair_1308;
pair_1308 = pair_1193;
{
obj_t aux_1658;
{
obj_t aux_1659;
{
obj_t aux_1660;
aux_1660 = CAR(pair_1308);
aux_1659 = CDR(aux_1660);
}
aux_1658 = CDR(aux_1659);
}
return CDR(aux_1658);
}
}
}


/* cddddr */obj_t cddddr___r4_pairs_and_lists_6_3(obj_t pair_38)
{
{
obj_t aux_1665;
{
obj_t aux_1666;
{
obj_t aux_1667;
aux_1667 = CDR(pair_38);
aux_1666 = CDR(aux_1667);
}
aux_1665 = CDR(aux_1666);
}
return CDR(aux_1665);
}
}


/* _cddddr1271 */obj_t _cddddr1271___r4_pairs_and_lists_6_3(obj_t env_1194, obj_t pair_1195)
{
{
obj_t pair_1309;
pair_1309 = pair_1195;
{
obj_t aux_1672;
{
obj_t aux_1673;
{
obj_t aux_1674;
aux_1674 = CDR(pair_1309);
aux_1673 = CDR(aux_1674);
}
aux_1672 = CDR(aux_1673);
}
return CDR(aux_1672);
}
}
}


/* set-car! */obj_t set_car__100___r4_pairs_and_lists_6_3(obj_t pair_39, obj_t obj_40)
{
return SET_CAR(pair_39, obj_40);
}


/* _set-car!1272 */obj_t _set_car_1272_193___r4_pairs_and_lists_6_3(obj_t env_1196, obj_t pair_1197, obj_t obj_1198)
{
{
obj_t pair_1310;
obj_t obj_1311;
pair_1310 = pair_1197;
obj_1311 = obj_1198;
return SET_CAR(pair_1310, obj_1311);
}
}


/* set-cdr! */obj_t set_cdr__56___r4_pairs_and_lists_6_3(obj_t pair_41, obj_t obj_42)
{
return SET_CDR(pair_41, obj_42);
}


/* _set-cdr!1273 */obj_t _set_cdr_1273_240___r4_pairs_and_lists_6_3(obj_t env_1199, obj_t pair_1200, obj_t obj_1201)
{
{
obj_t pair_1312;
obj_t obj_1313;
pair_1312 = pair_1200;
obj_1313 = obj_1201;
return SET_CDR(pair_1312, obj_1313);
}
}


/* set-cer! */obj_t set_cer__213___r4_pairs_and_lists_6_3(obj_t epair_43, obj_t obj_44)
{
{
bool_t test1081_1314;
test1081_1314 = EXTENDED_PAIRP(epair_43);
if(test1081_1314){
return SET_CER(epair_43, obj_44);
}
 else {
FAILURE(string1280___r4_pairs_and_lists_6_3,string1279___r4_pairs_and_lists_6_3,epair_43);}
}
}


/* _set-cer!1274 */obj_t _set_cer_1274_122___r4_pairs_and_lists_6_3(obj_t env_1202, obj_t epair_1203, obj_t obj_1204)
{
{
obj_t epair_1315;
obj_t obj_1316;
epair_1315 = epair_1203;
obj_1316 = obj_1204;
{
bool_t test1081_1317;
test1081_1317 = EXTENDED_PAIRP(epair_1315);
if(test1081_1317){
return SET_CER(epair_1315, obj_1316);
}
 else {
FAILURE(string1280___r4_pairs_and_lists_6_3,string1279___r4_pairs_and_lists_6_3,epair_1315);}
}
}
}


/* null? */bool_t null__121___r4_pairs_and_lists_6_3(obj_t obj_45)
{
return NULLP(obj_45);
}


/* _null? */obj_t _null__116___r4_pairs_and_lists_6_3(obj_t env_1205, obj_t obj_1206)
{
{
bool_t aux_1692;
{
obj_t obj_1318;
obj_1318 = obj_1206;
aux_1692 = NULLP(obj_1318);
}
return BBOOL(aux_1692);
}
}


/* list */obj_t list___r4_pairs_and_lists_6_3(obj_t l_46)
{
return l_46;
}


/* _list */obj_t _list___r4_pairs_and_lists_6_3(obj_t env_1207, obj_t l_1208)
{
{
obj_t l_1319;
l_1319 = l_1208;
return l_1319;
}
}


/* list? */bool_t list__240___r4_pairs_and_lists_6_3(obj_t x_47)
{
{
obj_t x_290;
obj_t prev_291;
if(NULLP(x_47)){
return ((bool_t)1);
}
 else {
if(PAIRP(x_47)){
{
obj_t arg1084_295;
arg1084_295 = CDR(x_47);
if(NULLP(arg1084_295)){
return ((bool_t)1);
}
 else {
if(PAIRP(arg1084_295)){
if((arg1084_295==x_47)){
return ((bool_t)0);
}
 else {
x_290 = CDR(arg1084_295);
prev_291 = x_47;
l2_292:
if(NULLP(x_290)){
return ((bool_t)1);
}
 else {
if(PAIRP(x_290)){
if((x_290==prev_291)){
return ((bool_t)0);
}
 else {
obj_t arg1092_697;
obj_t arg1093_698;
arg1092_697 = CDR(x_290);
arg1093_698 = CDR(prev_291);
if(NULLP(arg1092_697)){
return ((bool_t)1);
}
 else {
if(PAIRP(arg1092_697)){
if((arg1092_697==arg1093_698)){
return ((bool_t)0);
}
 else {
obj_t prev_1722;
obj_t x_1720;
x_1720 = CDR(arg1092_697);
prev_1722 = arg1093_698;
prev_291 = prev_1722;
x_290 = x_1720;
goto l2_292;
}
}
 else {
return ((bool_t)0);
}
}
}
}
 else {
return ((bool_t)0);
}
}
}
}
 else {
return ((bool_t)0);
}
}
}
}
 else {
return ((bool_t)0);
}
}
}
}


/* _list? */obj_t _list__66___r4_pairs_and_lists_6_3(obj_t env_1209, obj_t x_1210)
{
{
bool_t aux_1724;
aux_1724 = list__240___r4_pairs_and_lists_6_3(x_1210);
return BBOOL(aux_1724);
}
}


/* append-2 */obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t l1_48, obj_t l2_49)
{
{
obj_t head_305;
head_305 = MAKE_PAIR(BNIL, l2_49);
{
obj_t prev_719;
obj_t tail_720;
prev_719 = head_305;
tail_720 = l1_48;
loop_718:
if(NULLP(tail_720)){
BNIL;
}
 else {
obj_t new_prev_45_726;
{
obj_t aux_1730;
aux_1730 = CAR(tail_720);
new_prev_45_726 = MAKE_PAIR(aux_1730, l2_49);
}
SET_CDR(prev_719, new_prev_45_726);
{
obj_t tail_1735;
obj_t prev_1734;
prev_1734 = new_prev_45_726;
tail_1735 = CDR(tail_720);
tail_720 = tail_1735;
prev_719 = prev_1734;
goto loop_718;
}
}
}
return CDR(head_305);
}
}


/* _append-2 */obj_t _append_2_70___r4_pairs_and_lists_6_3(obj_t env_1211, obj_t l1_1212, obj_t l2_1213)
{
return append_2_18___r4_pairs_and_lists_6_3(l1_1212, l2_1213);
}


/* append */obj_t append___r4_pairs_and_lists_6_3(obj_t l_50)
{
return append_list_2___r4_pairs_and_lists_6_3(l_50);
}


/* append-list */obj_t append_list_2___r4_pairs_and_lists_6_3(obj_t l_314)
{
{
switch (list_length(l_314)){
case ((long)0) : 
return BNIL;
break;
case ((long)1) : 
return CAR(l_314);
break;
case ((long)2) : 
{
obj_t aux_1741;
{
obj_t aux_1743;
aux_1743 = CDR(l_314);
aux_1741 = CAR(aux_1743);
}
return append_2_18___r4_pairs_and_lists_6_3(CAR(l_314), aux_1741);
}
break;
default: 
{
obj_t arg1102_323;
obj_t arg1103_324;
arg1102_323 = CAR(l_314);
arg1103_324 = append_list_2___r4_pairs_and_lists_6_3(CDR(l_314));
return append_2_18___r4_pairs_and_lists_6_3(arg1102_323, arg1103_324);
}
}
}
}


/* _append */obj_t _append___r4_pairs_and_lists_6_3(obj_t env_1214, obj_t l_1215)
{
{
obj_t l_1320;
l_1320 = l_1215;
return append_list_2___r4_pairs_and_lists_6_3(l_1320);
}
}


/* append! */obj_t append__79___r4_pairs_and_lists_6_3(obj_t x_51, obj_t y_52)
{
if(NULLP(x_51)){
return y_52;
}
 else {
obj_t a_770;
obj_t b_771;
a_770 = x_51;
b_771 = CDR(x_51);
do_loop__1004_127_769:
if(NULLP(b_771)){
SET_CDR(a_770, y_52);
return x_51;
}
 else {
{
obj_t b_1760;
obj_t a_1759;
a_1759 = b_771;
b_1760 = CDR(b_771);
b_771 = b_1760;
a_770 = a_1759;
goto do_loop__1004_127_769;
}
}
}
}


/* _append! */obj_t _append__27___r4_pairs_and_lists_6_3(obj_t env_1216, obj_t x_1217, obj_t y_1218)
{
return append__79___r4_pairs_and_lists_6_3(x_1217, y_1218);
}


/* length */long list_length(obj_t list_53)
{
{
obj_t l_795;
long res_796;
l_795 = list_53;
res_796 = ((long)0);
loop_794:
if(NULLP(l_795)){
return res_796;
}
 else {
{
long res_1768;
obj_t l_1766;
l_1766 = CDR(l_795);
res_1768 = (((long)1)+res_796);
res_796 = res_1768;
l_795 = l_1766;
goto loop_794;
}
}
}
}


/* _length */obj_t _length___r4_pairs_and_lists_6_3(obj_t env_1219, obj_t list_1220)
{
{
long aux_1770;
aux_1770 = list_length(list_1220);
return BINT(aux_1770);
}
}


/* reverse */obj_t reverse___r4_pairs_and_lists_6_3(obj_t l_54)
{
{
obj_t l_824;
obj_t acc_825;
l_824 = l_54;
acc_825 = BNIL;
loop_823:
if(NULLP(l_824)){
return acc_825;
}
 else {
obj_t arg1115_831;
obj_t arg1116_832;
arg1115_831 = CDR(l_824);
{
obj_t aux_1776;
aux_1776 = CAR(l_824);
arg1116_832 = MAKE_PAIR(aux_1776, acc_825);
}
{
obj_t acc_1780;
obj_t l_1779;
l_1779 = arg1115_831;
acc_1780 = arg1116_832;
acc_825 = acc_1780;
l_824 = l_1779;
goto loop_823;
}
}
}
}


/* _reverse */obj_t _reverse___r4_pairs_and_lists_6_3(obj_t env_1221, obj_t l_1222)
{
return reverse___r4_pairs_and_lists_6_3(l_1222);
}


/* list-tail */obj_t list_tail_190___r4_pairs_and_lists_6_3(obj_t list_55, long k_56)
{
list_tail_190___r4_pairs_and_lists_6_3:
if((k_56==((long)0))){
return list_55;
}
 else {
obj_t arg1119_860;
long arg1120_861;
arg1119_860 = CDR(list_55);
arg1120_861 = (k_56-((long)1));
if((arg1120_861==((long)0))){
return arg1119_860;
}
 else {
long k_1790;
obj_t list_1788;
list_1788 = CDR(arg1119_860);
k_1790 = (arg1120_861-((long)1));
k_56 = k_1790;
list_55 = list_1788;
goto list_tail_190___r4_pairs_and_lists_6_3;
}
}
}


/* _list-tail1275 */obj_t _list_tail1275_0___r4_pairs_and_lists_6_3(obj_t env_1223, obj_t list_1224, obj_t k_1225)
{
return list_tail_190___r4_pairs_and_lists_6_3(list_1224, (long)CINT(k_1225));
}


/* list-ref */obj_t list_ref_194___r4_pairs_and_lists_6_3(obj_t list_57, long k_58)
{
list_ref_194___r4_pairs_and_lists_6_3:
if((k_58==((long)0))){
return CAR(list_57);
}
 else {
obj_t arg1122_880;
long arg1123_881;
arg1122_880 = CDR(list_57);
arg1123_881 = (k_58-((long)1));
if((arg1123_881==((long)0))){
return CAR(arg1122_880);
}
 else {
long k_1804;
obj_t list_1802;
list_1802 = CDR(arg1122_880);
k_1804 = (arg1123_881-((long)1));
k_58 = k_1804;
list_57 = list_1802;
goto list_ref_194___r4_pairs_and_lists_6_3;
}
}
}


/* _list-ref1276 */obj_t _list_ref1276_64___r4_pairs_and_lists_6_3(obj_t env_1226, obj_t list_1227, obj_t k_1228)
{
return list_ref_194___r4_pairs_and_lists_6_3(list_1227, (long)CINT(k_1228));
}


/* list-set! */obj_t list_set__58___r4_pairs_and_lists_6_3(obj_t list_59, long k_60, obj_t val_61)
{
list_set__58___r4_pairs_and_lists_6_3:
if((k_60==((long)0))){
return SET_CAR(list_59, val_61);
}
 else {
obj_t arg1125_902;
long arg1126_903;
arg1125_902 = CDR(list_59);
arg1126_903 = (k_60-((long)1));
if((arg1126_903==((long)0))){
return SET_CAR(arg1125_902, val_61);
}
 else {
long k_1818;
obj_t list_1816;
list_1816 = CDR(arg1125_902);
k_1818 = (arg1126_903-((long)1));
k_60 = k_1818;
list_59 = list_1816;
goto list_set__58___r4_pairs_and_lists_6_3;
}
}
}


/* _list-set!1277 */obj_t _list_set_1277_149___r4_pairs_and_lists_6_3(obj_t env_1229, obj_t list_1230, obj_t k_1231, obj_t val_1232)
{
return list_set__58___r4_pairs_and_lists_6_3(list_1230, (long)CINT(k_1231), val_1232);
}


/* last-pair */obj_t last_pair_93___r4_pairs_and_lists_6_3(obj_t x_62)
{
last_pair_93___r4_pairs_and_lists_6_3:
{
bool_t test_1822;
{
obj_t aux_1823;
aux_1823 = CDR(x_62);
test_1822 = PAIRP(aux_1823);
}
if(test_1822){
obj_t arg1128_928;
arg1128_928 = CDR(x_62);
{
bool_t test_1827;
{
obj_t aux_1828;
aux_1828 = CDR(arg1128_928);
test_1827 = PAIRP(aux_1828);
}
if(test_1827){
obj_t x_1831;
x_1831 = CDR(arg1128_928);
x_62 = x_1831;
goto last_pair_93___r4_pairs_and_lists_6_3;
}
 else {
return arg1128_928;
}
}
}
 else {
return x_62;
}
}
}


/* _last-pair */obj_t _last_pair_60___r4_pairs_and_lists_6_3(obj_t env_1233, obj_t x_1234)
{
return last_pair_93___r4_pairs_and_lists_6_3(x_1234);
}


/* memq */obj_t memq___r4_pairs_and_lists_6_3(obj_t obj_63, obj_t list_64)
{
{
obj_t list_940;
list_940 = list_64;
loop_939:
if(PAIRP(list_940)){
bool_t test_1836;
{
obj_t aux_1837;
aux_1837 = CAR(list_940);
test_1836 = (aux_1837==obj_63);
}
if(test_1836){
return list_940;
}
 else {
obj_t list_1840;
list_1840 = CDR(list_940);
list_940 = list_1840;
goto loop_939;
}
}
 else {
return BFALSE;
}
}
}


/* _memq */obj_t _memq___r4_pairs_and_lists_6_3(obj_t env_1235, obj_t obj_1236, obj_t list_1237)
{
return memq___r4_pairs_and_lists_6_3(obj_1236, list_1237);
}


/* memv */obj_t memv___r4_pairs_and_lists_6_3(obj_t obj_65, obj_t list_66)
{
{
obj_t list_951;
list_951 = list_66;
loop_950:
if(PAIRP(list_951)){
bool_t test_1845;
{
obj_t aux_1846;
aux_1846 = CAR(list_951);
test_1845 = (aux_1846==obj_65);
}
if(test_1845){
return list_951;
}
 else {
obj_t list_1849;
list_1849 = CDR(list_951);
list_951 = list_1849;
goto loop_950;
}
}
 else {
return BFALSE;
}
}
}


/* _memv */obj_t _memv___r4_pairs_and_lists_6_3(obj_t env_1238, obj_t obj_1239, obj_t list_1240)
{
return memv___r4_pairs_and_lists_6_3(obj_1239, list_1240);
}


/* member */obj_t member___r4_pairs_and_lists_6_3(obj_t obj_67, obj_t list_68)
{
{
obj_t list_962;
list_962 = list_68;
loop_961:
if(NULLP(list_962)){
return BFALSE;
}
 else {
if(equal__25___r4_equivalence_6_2(obj_67, CAR(list_962))){
return list_962;
}
 else {
{
obj_t list_1857;
list_1857 = CDR(list_962);
list_962 = list_1857;
goto loop_961;
}
}
}
}
}


/* _member */obj_t _member___r4_pairs_and_lists_6_3(obj_t env_1241, obj_t obj_1242, obj_t list_1243)
{
return member___r4_pairs_and_lists_6_3(obj_1242, list_1243);
}


/* assq */obj_t assq___r4_pairs_and_lists_6_3(obj_t obj_69, obj_t alist_70)
{
{
obj_t alist_971;
alist_971 = alist_70;
loop_970:
if(NULLP(alist_971)){
return BFALSE;
}
 else {
bool_t test_1862;
{
obj_t aux_1863;
{
obj_t aux_1864;
aux_1864 = CAR(alist_971);
aux_1863 = CAR(aux_1864);
}
test_1862 = (aux_1863==obj_69);
}
if(test_1862){
return CAR(alist_971);
}
 else {
obj_t alist_1869;
alist_1869 = CDR(alist_971);
alist_971 = alist_1869;
goto loop_970;
}
}
}
}


/* _assq */obj_t _assq___r4_pairs_and_lists_6_3(obj_t env_1244, obj_t obj_1245, obj_t alist_1246)
{
return assq___r4_pairs_and_lists_6_3(obj_1245, alist_1246);
}


/* assv */obj_t assv___r4_pairs_and_lists_6_3(obj_t obj_71, obj_t alist_72)
{
{
obj_t alist_985;
alist_985 = alist_72;
loop_984:
if(NULLP(alist_985)){
return BFALSE;
}
 else {
bool_t test_1874;
{
obj_t aux_1875;
{
obj_t aux_1876;
aux_1876 = CAR(alist_985);
aux_1875 = CAR(aux_1876);
}
test_1874 = eqv__112___r4_equivalence_6_2(aux_1875, obj_71);
}
if(test_1874){
return CAR(alist_985);
}
 else {
obj_t alist_1881;
alist_1881 = CDR(alist_985);
alist_985 = alist_1881;
goto loop_984;
}
}
}
}


/* _assv */obj_t _assv___r4_pairs_and_lists_6_3(obj_t env_1247, obj_t obj_1248, obj_t alist_1249)
{
return assv___r4_pairs_and_lists_6_3(obj_1248, alist_1249);
}


/* assoc */obj_t assoc___r4_pairs_and_lists_6_3(obj_t obj_73, obj_t alist_74)
{
assoc___r4_pairs_and_lists_6_3:
if(NULLP(alist_74)){
return BFALSE;
}
 else {
obj_t cary_997;
cary_997 = CAR(alist_74);
if(equal__25___r4_equivalence_6_2(obj_73, CAR(cary_997))){
return cary_997;
}
 else {
obj_t arg1155_1000;
arg1155_1000 = CDR(alist_74);
if(NULLP(arg1155_1000)){
return BFALSE;
}
 else {
obj_t cary_1008;
cary_1008 = CAR(arg1155_1000);
if(equal__25___r4_equivalence_6_2(obj_73, CAR(cary_1008))){
return cary_1008;
}
 else {
obj_t alist_1897;
alist_1897 = CDR(arg1155_1000);
alist_74 = alist_1897;
goto assoc___r4_pairs_and_lists_6_3;
}
}
}
}
}


/* _assoc */obj_t _assoc___r4_pairs_and_lists_6_3(obj_t env_1250, obj_t obj_1251, obj_t alist_1252)
{
return assoc___r4_pairs_and_lists_6_3(obj_1251, alist_1252);
}


/* remq */obj_t remq___r4_pairs_and_lists_6_3(obj_t x_75, obj_t y_76)
{
remq___r4_pairs_and_lists_6_3:
if(NULLP(y_76)){
return y_76;
}
 else {
bool_t test_1902;
{
obj_t aux_1903;
aux_1903 = CAR(y_76);
test_1902 = (x_75==aux_1903);
}
if(test_1902){
{
obj_t y_1906;
y_1906 = CDR(y_76);
y_76 = y_1906;
goto remq___r4_pairs_and_lists_6_3;
}
}
 else {
{
obj_t arg1161_401;
obj_t arg1162_402;
arg1161_401 = CAR(y_76);
arg1162_402 = remq___r4_pairs_and_lists_6_3(x_75, CDR(y_76));
return MAKE_PAIR(arg1161_401, arg1162_402);
}
}
}
}


/* _remq */obj_t _remq___r4_pairs_and_lists_6_3(obj_t env_1253, obj_t x_1254, obj_t y_1255)
{
return remq___r4_pairs_and_lists_6_3(x_1254, y_1255);
}


/* remove */obj_t remove___r4_pairs_and_lists_6_3(obj_t x_77, obj_t y_78)
{
remove___r4_pairs_and_lists_6_3:
if(NULLP(y_78)){
return y_78;
}
 else {
if(equal__25___r4_equivalence_6_2(x_77, CAR(y_78))){
{
obj_t y_1918;
y_1918 = CDR(y_78);
y_78 = y_1918;
goto remove___r4_pairs_and_lists_6_3;
}
}
 else {
{
obj_t arg1168_408;
obj_t arg1169_409;
arg1168_408 = CAR(y_78);
arg1169_409 = remove___r4_pairs_and_lists_6_3(x_77, CDR(y_78));
return MAKE_PAIR(arg1168_408, arg1169_409);
}
}
}
}


/* _remove */obj_t _remove___r4_pairs_and_lists_6_3(obj_t env_1256, obj_t x_1257, obj_t y_1258)
{
return remove___r4_pairs_and_lists_6_3(x_1257, y_1258);
}


/* remq! */obj_t remq__51___r4_pairs_and_lists_6_3(obj_t x_79, obj_t y_80)
{
remq__51___r4_pairs_and_lists_6_3:
if(NULLP(y_80)){
return y_80;
}
 else {
bool_t test_1927;
{
obj_t aux_1928;
aux_1928 = CAR(y_80);
test_1927 = (x_79==aux_1928);
}
if(test_1927){
{
obj_t y_1931;
y_1931 = CDR(y_80);
y_80 = y_1931;
goto remq__51___r4_pairs_and_lists_6_3;
}
}
 else {
{
obj_t prev_415;
prev_415 = y_80;
loop_416:
{
bool_t test_1933;
{
obj_t aux_1934;
aux_1934 = CDR(prev_415);
test_1933 = NULLP(aux_1934);
}
if(test_1933){
return y_80;
}
 else {
bool_t test_1937;
{
obj_t aux_1938;
{
obj_t aux_1939;
aux_1939 = CDR(prev_415);
aux_1938 = CAR(aux_1939);
}
test_1937 = (aux_1938==x_79);
}
if(test_1937){
{
obj_t aux_1943;
{
obj_t aux_1944;
aux_1944 = CDR(prev_415);
aux_1943 = CDR(aux_1944);
}
SET_CDR(prev_415, aux_1943);
}
{
goto loop_416;
}
}
 else {
{
obj_t prev_1948;
prev_1948 = CDR(prev_415);
prev_415 = prev_1948;
goto loop_416;
}
}
}
}
}
}
}
}


/* _remq! */obj_t _remq__174___r4_pairs_and_lists_6_3(obj_t env_1259, obj_t x_1260, obj_t y_1261)
{
return remq__51___r4_pairs_and_lists_6_3(x_1260, y_1261);
}


/* remove! */obj_t remove__21___r4_pairs_and_lists_6_3(obj_t x_81, obj_t y_82)
{
remove__21___r4_pairs_and_lists_6_3:
if(NULLP(y_82)){
return y_82;
}
 else {
if(equal__25___r4_equivalence_6_2(x_81, CAR(y_82))){
{
obj_t y_1956;
y_1956 = CDR(y_82);
y_82 = y_1956;
goto remove__21___r4_pairs_and_lists_6_3;
}
}
 else {
{
obj_t prev_427;
prev_427 = y_82;
loop_428:
{
bool_t test_1958;
{
obj_t aux_1959;
aux_1959 = CDR(prev_427);
test_1958 = NULLP(aux_1959);
}
if(test_1958){
return y_82;
}
 else {
bool_t test_1962;
{
obj_t aux_1963;
{
obj_t aux_1964;
aux_1964 = CDR(prev_427);
aux_1963 = CAR(aux_1964);
}
test_1962 = equal__25___r4_equivalence_6_2(aux_1963, x_81);
}
if(test_1962){
{
obj_t aux_1968;
{
obj_t aux_1969;
aux_1969 = CDR(prev_427);
aux_1968 = CDR(aux_1969);
}
SET_CDR(prev_427, aux_1968);
}
{
goto loop_428;
}
}
 else {
{
obj_t prev_1973;
prev_1973 = CDR(prev_427);
prev_427 = prev_1973;
goto loop_428;
}
}
}
}
}
}
}
}


/* _remove! */obj_t _remove__17___r4_pairs_and_lists_6_3(obj_t env_1262, obj_t x_1263, obj_t y_1264)
{
return remove__21___r4_pairs_and_lists_6_3(x_1263, y_1264);
}


/* cons* */obj_t cons__138___r4_pairs_and_lists_6_3(obj_t x_83, obj_t y_84)
{
if(NULLP(y_84)){
return x_83;
}
 else {
obj_t arg1193_439;
arg1193_439 = cons_1_212___r4_pairs_and_lists_6_3(y_84);
return MAKE_PAIR(x_83, arg1193_439);
}
}


/* cons*1 */obj_t cons_1_212___r4_pairs_and_lists_6_3(obj_t x_436)
{
{
bool_t test_1980;
{
obj_t aux_1981;
aux_1981 = CDR(x_436);
test_1980 = NULLP(aux_1981);
}
if(test_1980){
return CAR(x_436);
}
 else {
{
obj_t arg1195_441;
obj_t arg1196_442;
arg1195_441 = CAR(x_436);
arg1196_442 = cons_1_212___r4_pairs_and_lists_6_3(CDR(x_436));
return MAKE_PAIR(arg1195_441, arg1196_442);
}
}
}
}


/* _cons* */obj_t _cons__190___r4_pairs_and_lists_6_3(obj_t env_1265, obj_t x_1266, obj_t y_1267)
{
return cons__138___r4_pairs_and_lists_6_3(x_1266, y_1267);
}


/* reverse! */obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t l_85)
{
if(PAIRP(l_85)){
obj_t l_1080;
obj_t r_1081;
l_1080 = l_85;
r_1081 = BNIL;
nr_1079:
{
bool_t test_1992;
{
obj_t aux_1993;
aux_1993 = CDR(l_1080);
test_1992 = NULLP(aux_1993);
}
if(test_1992){
SET_CDR(l_1080, r_1081);
return l_1080;
}
 else {
obj_t cdrl_1088;
cdrl_1088 = CDR(l_1080);
{
obj_t arg1203_1089;
SET_CDR(l_1080, r_1081);
arg1203_1089 = l_1080;
{
obj_t r_2000;
obj_t l_1999;
l_1999 = cdrl_1088;
r_2000 = arg1203_1089;
r_1081 = r_2000;
l_1080 = l_1999;
goto nr_1079;
}
}
}
}
}
 else {
return l_85;
}
}


/* _reverse! */obj_t _reverse__87___r4_pairs_and_lists_6_3(obj_t env_1268, obj_t l_1269)
{
return reverse__39___r4_pairs_and_lists_6_3(l_1269);
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_pairs_and_lists_6_3()
{
return module_initialization_70___error(((long)0), "__R4_PAIRS_AND_LISTS_6_3");
}

