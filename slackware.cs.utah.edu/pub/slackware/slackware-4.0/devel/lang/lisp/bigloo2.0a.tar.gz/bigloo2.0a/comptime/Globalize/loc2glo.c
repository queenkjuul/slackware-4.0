/*===========================================================================*/
/*   (Globalize/loc2glo.scm)                                                 */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
extern obj_t local_ginfo_108_globalize_ginfo;
static obj_t method_init_76_globalize_local__global_194();
static obj_t _the_global2010_242_globalize_local__global_194(obj_t, obj_t);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t _optim__89_engine_param;
extern obj_t the_closure_238_globalize_free(variable_t, obj_t);
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static obj_t _local__global2009_124_globalize_local__global_194(obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_local__global_194(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_globalize_node(long, char *);
extern obj_t module_initialization_70_globalize_free(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern long list_length(obj_t);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
extern global_t def_global_sfun__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern global_t local__global_40_globalize_local__global_194(local_t);
extern obj_t let_fun_218_ast_node;
extern node_t node_globalize__229_globalize_node(node_t, variable_t, obj_t);
static obj_t imported_modules_init_94_globalize_local__global_194();
extern obj_t sfun_ginfo_98_globalize_ginfo;
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static global_t fix_non_escaping_definition_247_globalize_local__global_194(global_t, local_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_globalize_local__global_194();
extern obj_t global_ginfo_75_globalize_ginfo;
extern obj_t svar_ginfo_131_globalize_ginfo;
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
extern global_t the_global_201_globalize_local__global_194(local_t);
extern obj_t __arity_132_tools_args(obj_t, obj_t);
extern obj_t _module__166_module_module;
extern obj_t _procedure__226_type_cache;
static node_t make_escaping_body_209_globalize_local__global_194(local_t, global_t, obj_t, obj_t, local_t, node_t);
static global_t fix_escaping_definition_56_globalize_local__global_194(global_t, local_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_globalize_local__global_194 = BUNSPEC;
static obj_t cnst_init_137_globalize_local__global_194();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t default_type_190_globalize_local__global_194();
static obj_t __cnst[7];

DEFINE_EXPORT_PROCEDURE(local__global_env_170_globalize_local__global_194, _local__global2009_124_globalize_local__global_1942017, _local__global2009_124_globalize_local__global_194, 0L, 1);
DEFINE_EXPORT_PROCEDURE(the_global_env_148_globalize_local__global_194, _the_global2010_242_globalize_local__global_1942018, _the_global2010_242_globalize_local__global_194, 0L, 1);
DEFINE_STRING(string2011_globalize_local__global_194, string2011_globalize_local__global_1942019, "NOW SFUN STATIC _ VALUE PROCEDURE-REF ENV ", 42);


/* module-initialization */ obj_t 
module_initialization_70_globalize_local__global_194(long checksum_2333, char *from_2334)
{
   if (CBOOL(require_initialization_114_globalize_local__global_194))
     {
	require_initialization_114_globalize_local__global_194 = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_local__global_194();
	cnst_init_137_globalize_local__global_194();
	imported_modules_init_94_globalize_local__global_194();
	method_init_76_globalize_local__global_194();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_local__global_194()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70___object(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_local__global_194()
{
   {
      obj_t cnst_port_138_2325;
      cnst_port_138_2325 = open_input_string(string2011_globalize_local__global_194);
      {
	 long i_2326;
	 i_2326 = ((long) 6);
       loop_2327:
	 {
	    bool_t test2012_2328;
	    test2012_2328 = (i_2326 == ((long) -1));
	    if (test2012_2328)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2013_2329;
		    {
		       obj_t list2014_2330;
		       {
			  obj_t arg2015_2331;
			  arg2015_2331 = BNIL;
			  list2014_2330 = MAKE_PAIR(cnst_port_138_2325, arg2015_2331);
		       }
		       arg2013_2329 = read___reader(list2014_2330);
		    }
		    CNST_TABLE_SET(i_2326, arg2013_2329);
		 }
		 {
		    int aux_2332;
		    {
		       long aux_2352;
		       aux_2352 = (i_2326 - ((long) 1));
		       aux_2332 = (int) (aux_2352);
		    }
		    {
		       long i_2355;
		       i_2355 = (long) (aux_2332);
		       i_2326 = i_2355;
		       goto loop_2327;
		    }
		 }
	      }
	 }
      }
   }
}


/* default-type */ obj_t 
default_type_190_globalize_local__global_194()
{
   {
      bool_t test1618_1019;
      {
	 long n1_1727;
	 n1_1727 = (long) CINT(_optim__89_engine_param);
	 test1618_1019 = (n1_1727 < ((long) 2));
      }
      if (test1618_1019)
	{
	   return _obj__252_type_cache;
	}
      else
	{
	   return ____74_type_cache;
	}
   }
}


/* local->global */ global_t 
local__global_40_globalize_local__global_194(local_t local_1)
{
   {
      global_t global_1020;
      global_1020 = the_global_201_globalize_local__global_194(local_1);
      {
	 obj_t args_1021;
	 {
	    sfun_t obj_1730;
	    {
	       value_t aux_2361;
	       aux_2361 = (((local_t) CREF(local_1))->value);
	       obj_1730 = (sfun_t) (aux_2361);
	    }
	    args_1021 = (((sfun_t) CREF(obj_1730))->args);
	 }
	 {
	    value_t info_1022;
	    info_1022 = (((local_t) CREF(local_1))->value);
	    {
	       obj_t new_body_215_1023;
	       {
		  sfun_ginfo_98_t obj_1732;
		  obj_1732 = (sfun_ginfo_98_t) (info_1022);
		  {
		     obj_t aux_2367;
		     {
			object_t aux_2368;
			aux_2368 = (object_t) (obj_1732);
			aux_2367 = OBJECT_WIDENING(aux_2368);
		     }
		     new_body_215_1023 = (((sfun_ginfo_98_t) CREF(aux_2367))->new_body_215);
		  }
	       }
	       {
		  obj_t kaptured_1024;
		  {
		     sfun_ginfo_98_t obj_1733;
		     obj_1733 = (sfun_ginfo_98_t) (info_1022);
		     {
			obj_t aux_2373;
			{
			   object_t aux_2374;
			   aux_2374 = (object_t) (obj_1733);
			   aux_2373 = OBJECT_WIDENING(aux_2374);
			}
			kaptured_1024 = (((sfun_ginfo_98_t) CREF(aux_2373))->kaptured);
		     }
		  }
		  {
		     {
			bool_t test_2378;
			{
			   local_ginfo_108_t obj_1734;
			   obj_1734 = (local_ginfo_108_t) (local_1);
			   {
			      obj_t aux_2380;
			      {
				 object_t aux_2381;
				 aux_2381 = (object_t) (obj_1734);
				 aux_2380 = OBJECT_WIDENING(aux_2381);
			      }
			      test_2378 = (((local_ginfo_108_t) CREF(aux_2380))->escape__117);
			   }
			}
			if (test_2378)
			  {
			     fix_escaping_definition_56_globalize_local__global_194(global_1020, local_1, args_1021, kaptured_1024, new_body_215_1023);
			  }
			else
			  {
			     fix_non_escaping_definition_247_globalize_local__global_194(global_1020, local_1, args_1021, kaptured_1024, new_body_215_1023);
			  }
		     }
		     return global_1020;
		  }
	       }
	    }
	 }
      }
   }
}


/* _local->global2009 */ obj_t 
_local__global2009_124_globalize_local__global_194(obj_t env_2321, obj_t local_2322)
{
   {
      global_t aux_2387;
      aux_2387 = local__global_40_globalize_local__global_194((local_t) (local_2322));
      return (obj_t) (aux_2387);
   }
}


/* fix-escaping-definition */ global_t 
fix_escaping_definition_56_globalize_local__global_194(global_t global_2, local_t local_3, obj_t args_4, obj_t kaptured_5, obj_t body_6)
{
   {
      local_t env_1027;
      env_1027 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 0)), (type_t) (_procedure__226_type_cache));
      {
	 obj_t new_free_31_1028;
	 if (NULLP(kaptured_5))
	   {
	      new_free_31_1028 = BNIL;
	   }
	 else
	   {
	      obj_t head1567_1134;
	      head1567_1134 = MAKE_PAIR(BNIL, BNIL);
	      {
		 obj_t l1565_1135;
		 obj_t tail1568_1136;
		 l1565_1135 = kaptured_5;
		 tail1568_1136 = head1567_1134;
	       lname1566_1137:
		 if (NULLP(l1565_1135))
		   {
		      new_free_31_1028 = CDR(head1567_1134);
		   }
		 else
		   {
		      obj_t newtail1569_1139;
		      {
			 local_t arg1716_1141;
			 {
			    obj_t old_1143;
			    old_1143 = CAR(l1565_1135);
			    {
			       local_t new_1144;
			       {
				  type_t aux_2404;
				  obj_t aux_2401;
				  {
				     obj_t aux_2405;
				     aux_2405 = default_type_190_globalize_local__global_194();
				     aux_2404 = (type_t) (aux_2405);
				  }
				  {
				     local_t obj_1741;
				     obj_1741 = (local_t) (old_1143);
				     aux_2401 = (((local_t) CREF(obj_1741))->id);
				  }
				  new_1144 = make_local_svar_140_ast_local(aux_2401, aux_2404);
			       }
			       {
				  bool_t arg1718_1145;
				  {
				     local_t obj_1742;
				     obj_1742 = (local_t) (old_1143);
				     arg1718_1145 = (((local_t) CREF(obj_1742))->user__32);
				  }
				  ((((local_t) CREF(new_1144))->user__32) = ((bool_t) arg1718_1145), BUNSPEC);
			       }
			       {
				  local_ginfo_108_t obj1571_1146;
				  obj1571_1146 = ((local_ginfo_108_t) (new_1144));
				  {
				     local_ginfo_108_t arg1720_1147;
				     {
					local_ginfo_108_t res1993_1748;
					{
					   local_ginfo_108_t new1529_1746;
					   new1529_1746 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
					   ((((local_ginfo_108_t) CREF(new1529_1746))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					   res1993_1748 = new1529_1746;
					}
					arg1720_1147 = res1993_1748;
				     }
				     {
					obj_t aux_2417;
					object_t aux_2415;
					aux_2417 = (obj_t) (arg1720_1147);
					aux_2415 = (object_t) (obj1571_1146);
					OBJECT_WIDENING_SET(aux_2415, aux_2417);
				     }
				  }
				  {
				     long arg1721_1148;
				     arg1721_1148 = class_num_218___object(local_ginfo_108_globalize_ginfo);
				     {
					obj_t obj_1749;
					obj_1749 = (obj_t) (obj1571_1146);
					(((obj_t) CREF(obj_1749))->header = MAKE_HEADER(arg1721_1148, 0), BUNSPEC);
				     }
				  }
				  obj1571_1146;
			       }
			       {
				  svar_ginfo_131_t obj1572_1149;
				  obj1572_1149 = ((svar_ginfo_131_t) ((((local_t) CREF(new_1144))->value)));
				  {
				     svar_ginfo_131_t arg1722_1150;
				     {
					svar_ginfo_131_t res1994_1761;
					{
					   svar_ginfo_131_t new1500_1756;
					   new1500_1756 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
					   ((((svar_ginfo_131_t) CREF(new1500_1756))->kaptured__204) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					   ((((svar_ginfo_131_t) CREF(new1500_1756))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
					   ((((svar_ginfo_131_t) CREF(new1500_1756))->mark) = ((long) ((long) -10)), BUNSPEC);
					   ((((svar_ginfo_131_t) CREF(new1500_1756))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					   res1994_1761 = new1500_1756;
					}
					arg1722_1150 = res1994_1761;
				     }
				     {
					obj_t aux_2432;
					object_t aux_2430;
					aux_2432 = (obj_t) (arg1722_1150);
					aux_2430 = (object_t) (obj1572_1149);
					OBJECT_WIDENING_SET(aux_2430, aux_2432);
				     }
				  }
				  {
				     long arg1726_1154;
				     arg1726_1154 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
				     {
					obj_t obj_1762;
					obj_1762 = (obj_t) (obj1572_1149);
					(((obj_t) CREF(obj_1762))->header = MAKE_HEADER(arg1726_1154, 0), BUNSPEC);
				     }
				  }
				  obj1572_1149;
			       }
			       {
				  obj_t arg1727_1155;
				  {
				     local_t obj_1764;
				     obj_1764 = (local_t) (old_1143);
				     arg1727_1155 = (((local_t) CREF(obj_1764))->access);
				  }
				  ((((local_t) CREF(new_1144))->access) = ((obj_t) arg1727_1155), BUNSPEC);
			       }
			       arg1716_1141 = new_1144;
			    }
			 }
			 {
			    obj_t aux_2441;
			    aux_2441 = (obj_t) (arg1716_1141);
			    newtail1569_1139 = MAKE_PAIR(aux_2441, BNIL);
			 }
		      }
		      SET_CDR(tail1568_1136, newtail1569_1139);
		      {
			 obj_t tail1568_2447;
			 obj_t l1565_2445;
			 l1565_2445 = CDR(l1565_1135);
			 tail1568_2447 = newtail1569_1139;
			 tail1568_1136 = tail1568_2447;
			 l1565_1135 = l1565_2445;
			 goto lname1566_1137;
		      }
		   }
	      }
	   }
	 {
	    obj_t new_args_235_1029;
	    if (NULLP(args_4))
	      {
		 new_args_235_1029 = BNIL;
	      }
	    else
	      {
		 obj_t head1575_1105;
		 head1575_1105 = MAKE_PAIR(BNIL, BNIL);
		 {
		    obj_t l1573_1106;
		    obj_t tail1576_1107;
		    l1573_1106 = args_4;
		    tail1576_1107 = head1575_1105;
		  lname1574_1108:
		    if (NULLP(l1573_1106))
		      {
			 new_args_235_1029 = CDR(head1575_1105);
		      }
		    else
		      {
			 obj_t newtail1577_1110;
			 {
			    local_t arg1695_1112;
			    {
			       obj_t old_1114;
			       old_1114 = CAR(l1573_1106);
			       {
				  local_t new_1115;
				  {
				     type_t aux_2458;
				     obj_t aux_2455;
				     {
					obj_t aux_2459;
					aux_2459 = default_type_190_globalize_local__global_194();
					aux_2458 = (type_t) (aux_2459);
				     }
				     {
					local_t obj_1778;
					obj_1778 = (local_t) (old_1114);
					aux_2455 = (((local_t) CREF(obj_1778))->id);
				     }
				     new_1115 = make_local_svar_140_ast_local(aux_2455, aux_2458);
				  }
				  {
				     bool_t arg1698_1116;
				     {
					local_t obj_1779;
					obj_1779 = (local_t) (old_1114);
					arg1698_1116 = (((local_t) CREF(obj_1779))->user__32);
				     }
				     ((((local_t) CREF(new_1115))->user__32) = ((bool_t) arg1698_1116), BUNSPEC);
				  }
				  {
				     local_ginfo_108_t obj1578_1117;
				     obj1578_1117 = ((local_ginfo_108_t) (new_1115));
				     {
					local_ginfo_108_t arg1699_1118;
					{
					   local_ginfo_108_t res1995_1785;
					   {
					      local_ginfo_108_t new1529_1783;
					      new1529_1783 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
					      ((((local_ginfo_108_t) CREF(new1529_1783))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					      res1995_1785 = new1529_1783;
					   }
					   arg1699_1118 = res1995_1785;
					}
					{
					   obj_t aux_2471;
					   object_t aux_2469;
					   aux_2471 = (obj_t) (arg1699_1118);
					   aux_2469 = (object_t) (obj1578_1117);
					   OBJECT_WIDENING_SET(aux_2469, aux_2471);
					}
				     }
				     {
					long arg1700_1119;
					arg1700_1119 = class_num_218___object(local_ginfo_108_globalize_ginfo);
					{
					   obj_t obj_1786;
					   obj_1786 = (obj_t) (obj1578_1117);
					   (((obj_t) CREF(obj_1786))->header = MAKE_HEADER(arg1700_1119, 0), BUNSPEC);
					}
				     }
				     obj1578_1117;
				  }
				  {
				     svar_ginfo_131_t obj1579_1120;
				     obj1579_1120 = ((svar_ginfo_131_t) ((((local_t) CREF(new_1115))->value)));
				     {
					svar_ginfo_131_t arg1701_1121;
					{
					   bool_t arg1702_1122;
					   {
					      svar_ginfo_131_t obj_1790;
					      {
						 value_t aux_2479;
						 {
						    local_t obj_1789;
						    obj_1789 = (local_t) (old_1114);
						    aux_2479 = (((local_t) CREF(obj_1789))->value);
						 }
						 obj_1790 = (svar_ginfo_131_t) (aux_2479);
					      }
					      {
						 obj_t aux_2483;
						 {
						    object_t aux_2484;
						    aux_2484 = (object_t) (obj_1790);
						    aux_2483 = OBJECT_WIDENING(aux_2484);
						 }
						 arg1702_1122 = (((svar_ginfo_131_t) CREF(aux_2483))->kaptured__204);
					      }
					   }
					   {
					      svar_ginfo_131_t res1996_1800;
					      {
						 svar_ginfo_131_t new1500_1795;
						 new1500_1795 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
						 ((((svar_ginfo_131_t) CREF(new1500_1795))->kaptured__204) = ((bool_t) arg1702_1122), BUNSPEC);
						 ((((svar_ginfo_131_t) CREF(new1500_1795))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
						 ((((svar_ginfo_131_t) CREF(new1500_1795))->mark) = ((long) ((long) -10)), BUNSPEC);
						 ((((svar_ginfo_131_t) CREF(new1500_1795))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						 res1996_1800 = new1500_1795;
					      }
					      arg1701_1121 = res1996_1800;
					   }
					}
					{
					   obj_t aux_2495;
					   object_t aux_2493;
					   aux_2495 = (obj_t) (arg1701_1121);
					   aux_2493 = (object_t) (obj1579_1120);
					   OBJECT_WIDENING_SET(aux_2493, aux_2495);
					}
				     }
				     {
					long arg1706_1126;
					arg1706_1126 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
					{
					   obj_t obj_1801;
					   obj_1801 = (obj_t) (obj1579_1120);
					   (((obj_t) CREF(obj_1801))->header = MAKE_HEADER(arg1706_1126, 0), BUNSPEC);
					}
				     }
				     obj1579_1120;
				  }
				  {
				     obj_t arg1707_1127;
				     {
					local_t obj_1803;
					obj_1803 = (local_t) (old_1114);
					arg1707_1127 = (((local_t) CREF(obj_1803))->access);
				     }
				     ((((local_t) CREF(new_1115))->access) = ((obj_t) arg1707_1127), BUNSPEC);
				  }
				  arg1695_1112 = new_1115;
			       }
			    }
			    {
			       obj_t aux_2504;
			       aux_2504 = (obj_t) (arg1695_1112);
			       newtail1577_1110 = MAKE_PAIR(aux_2504, BNIL);
			    }
			 }
			 SET_CDR(tail1576_1107, newtail1577_1110);
			 {
			    obj_t tail1576_2510;
			    obj_t l1573_2508;
			    l1573_2508 = CDR(l1573_1106);
			    tail1576_2510 = newtail1577_1110;
			    tail1576_1107 = tail1576_2510;
			    l1573_1106 = l1573_2508;
			    goto lname1574_1108;
			 }
		      }
		 }
	      }
	    {
	       sfun_t new_fun_115_1031;
	       {
		  sfun_t duplicated1580_1087;
		  {
		     value_t aux_2511;
		     aux_2511 = (((local_t) CREF(local_3))->value);
		     duplicated1580_1087 = (sfun_t) (aux_2511);
		  }
		  {
		     sfun_t new1581_1088;
		     {
			obj_t arg1676_1089;
			obj_t arg1677_1090;
			obj_t arg1678_1091;
			obj_t arg1679_1092;
			bool_t arg1680_1093;
			obj_t arg1681_1094;
			obj_t arg1682_1095;
			obj_t arg1683_1096;
			obj_t arg1684_1097;
			obj_t arg1685_1098;
			obj_t arg1686_1099;
			obj_t arg1688_1100;
			{
			   obj_t aux_2514;
			   {
			      long aux_2515;
			      aux_2515 = (((sfun_t) CREF(duplicated1580_1087))->arity);
			      aux_2514 = BINT(aux_2515);
			   }
			   arg1676_1089 = __arity_132_tools_args(aux_2514, BINT(((long) 1)));
			}
			arg1677_1090 = (((sfun_t) CREF(duplicated1580_1087))->side_effect__165);
			arg1678_1091 = (((sfun_t) CREF(duplicated1580_1087))->predicate_of_78);
			arg1679_1092 = (((sfun_t) CREF(duplicated1580_1087))->stack_allocator_172);
			arg1680_1093 = (((sfun_t) CREF(duplicated1580_1087))->top__138);
			arg1681_1094 = (((sfun_t) CREF(duplicated1580_1087))->the_closure_238);
			arg1682_1095 = (((sfun_t) CREF(duplicated1580_1087))->property);
			{
			   obj_t aux_2526;
			   aux_2526 = (obj_t) (env_1027);
			   arg1683_1096 = MAKE_PAIR(aux_2526, new_args_235_1029);
			}
			arg1684_1097 = (((sfun_t) CREF(duplicated1580_1087))->body);
			arg1685_1098 = (((sfun_t) CREF(duplicated1580_1087))->class);
			arg1686_1099 = (((sfun_t) CREF(duplicated1580_1087))->dsssl_keywords_243);
			arg1688_1100 = (((sfun_t) CREF(duplicated1580_1087))->loc);
			{
			   sfun_t res1997_1853;
			   {
			      long arity_1825;
			      arity_1825 = (long) CINT(arg1676_1089);
			      {
				 sfun_t new1127_1837;
				 new1127_1837 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
				 {
				    long arg1978_1838;
				    arg1978_1838 = class_num_218___object(sfun_ast_var);
				    {
				       obj_t obj_1851;
				       obj_1851 = (obj_t) (new1127_1837);
				       (((obj_t) CREF(obj_1851))->header = MAKE_HEADER(arg1978_1838, 0), BUNSPEC);
				    }
				 }
				 {
				    object_t aux_2538;
				    aux_2538 = (object_t) (new1127_1837);
				    OBJECT_WIDENING_SET(aux_2538, BFALSE);
				 }
				 ((((sfun_t) CREF(new1127_1837))->arity) = ((long) arity_1825), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->side_effect__165) = ((obj_t) arg1677_1090), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->predicate_of_78) = ((obj_t) arg1678_1091), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->stack_allocator_172) = ((obj_t) arg1679_1092), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->top__138) = ((bool_t) arg1680_1093), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->the_closure_238) = ((obj_t) arg1681_1094), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->property) = ((obj_t) arg1682_1095), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->args) = ((obj_t) arg1683_1096), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->body) = ((obj_t) arg1684_1097), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->class) = ((obj_t) arg1685_1098), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->dsssl_keywords_243) = ((obj_t) arg1686_1099), BUNSPEC);
				 ((((sfun_t) CREF(new1127_1837))->loc) = ((obj_t) arg1688_1100), BUNSPEC);
				 res1997_1853 = new1127_1837;
			      }
			   }
			   new1581_1088 = res1997_1853;
			}
		     }
		     {
			new_fun_115_1031 = new1581_1088;
		     }
		  }
	       }
	       {
		  {
		     global_ginfo_75_t obj_1854;
		     obj_1854 = (global_ginfo_75_t) (global_2);
		     {
			obj_t aux_2554;
			{
			   object_t aux_2555;
			   aux_2555 = (object_t) (obj_1854);
			   aux_2554 = OBJECT_WIDENING(aux_2555);
			}
			((((global_ginfo_75_t) CREF(aux_2554))->escape__117) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		     }
		  }
		  {
		     sfun_ginfo_98_t obj1582_1032;
		     obj1582_1032 = ((sfun_ginfo_98_t) (new_fun_115_1031));
		     {
			sfun_ginfo_98_t arg1621_1033;
			{
			   sfun_ginfo_98_t res1998_1893;
			   {
			      obj_t cfrom__119_1858;
			      obj_t cto__14_1860;
			      obj_t the_global_201_1867;
			      obj_t kaptured_1868;
			      obj_t new_body_215_1869;
			      cfrom__119_1858 = BFALSE;
			      cto__14_1860 = BFALSE;
			      the_global_201_1867 = BFALSE;
			      kaptured_1868 = BFALSE;
			      new_body_215_1869 = BFALSE;
			      {
				 sfun_ginfo_98_t new1448_1874;
				 new1448_1874 = ((sfun_ginfo_98_t) BREF(GC_MALLOC(sizeof(struct sfun_ginfo_98))));
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->g__219) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->cfrom) = ((obj_t) BNIL), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->cfrom__119) = ((obj_t) cfrom__119_1858), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->cto) = ((obj_t) BNIL), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->cto__14) = ((obj_t) cto__14_1860), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->cfunction) = ((obj_t) BNIL), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->integrator) = ((obj_t) BNIL), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->integrated) = ((obj_t) BNIL), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->plugged_in_15) = ((obj_t) BNIL), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->mark) = ((long) ((long) -10)), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->free_mark_81) = ((obj_t) BNIL), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->the_global_201) = ((obj_t) the_global_201_1867), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->kaptured) = ((obj_t) kaptured_1868), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->new_body_215) = ((obj_t) new_body_215_1869), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->bmark) = ((long) ((long) -10)), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->umark) = ((long) ((long) -10)), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->free) = ((obj_t) BUNSPEC), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1448_1874))->bound) = ((obj_t) BNIL), BUNSPEC);
				 res1998_1893 = new1448_1874;
			      }
			   }
			   arg1621_1033 = res1998_1893;
			}
			{
			   obj_t aux_2581;
			   object_t aux_2579;
			   aux_2581 = (obj_t) (arg1621_1033);
			   aux_2579 = (object_t) (obj1582_1032);
			   OBJECT_WIDENING_SET(aux_2579, aux_2581);
			}
		     }
		     {
			long arg1638_1045;
			arg1638_1045 = class_num_218___object(sfun_ginfo_98_globalize_ginfo);
			{
			   obj_t obj_1894;
			   obj_1894 = (obj_t) (obj1582_1032);
			   (((obj_t) CREF(obj_1894))->header = MAKE_HEADER(arg1638_1045, 0), BUNSPEC);
			}
		     }
		     obj1582_1032;
		  }
		  {
		     svar_ginfo_131_t obj1583_1046;
		     obj1583_1046 = ((svar_ginfo_131_t) ((((local_t) CREF(env_1027))->value)));
		     {
			svar_ginfo_131_t arg1639_1047;
			{
			   svar_ginfo_131_t res1999_1906;
			   {
			      svar_ginfo_131_t new1500_1901;
			      new1500_1901 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
			      ((((svar_ginfo_131_t) CREF(new1500_1901))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			      ((((svar_ginfo_131_t) CREF(new1500_1901))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
			      ((((svar_ginfo_131_t) CREF(new1500_1901))->mark) = ((long) ((long) -10)), BUNSPEC);
			      ((((svar_ginfo_131_t) CREF(new1500_1901))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			      res1999_1906 = new1500_1901;
			   }
			   arg1639_1047 = res1999_1906;
			}
			{
			   obj_t aux_2596;
			   object_t aux_2594;
			   aux_2596 = (obj_t) (arg1639_1047);
			   aux_2594 = (object_t) (obj1583_1046);
			   OBJECT_WIDENING_SET(aux_2594, aux_2596);
			}
		     }
		     {
			long arg1646_1051;
			arg1646_1051 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
			{
			   obj_t obj_1907;
			   obj_1907 = (obj_t) (obj1583_1046);
			   (((obj_t) CREF(obj_1907))->header = MAKE_HEADER(arg1646_1051, 0), BUNSPEC);
			}
		     }
		     obj1583_1046;
		  }
		  {
		     type_t val1080_1910;
		     val1080_1910 = (type_t) (_obj__252_type_cache);
		     ((((global_t) CREF(global_2))->type) = ((type_t) val1080_1910), BUNSPEC);
		  }
		  {
		     obj_t l1584_1052;
		     {
			obj_t aux_2613;
			aux_2613 = (((sfun_t) CREF(new_fun_115_1031))->args);
			l1584_1052 = CDR(aux_2613);
		     }
		   lname1585_1053:
		     if (PAIRP(l1584_1052))
		       {
			  {
			     local_t obj_1915;
			     type_t val1105_1916;
			     {
				obj_t aux_2606;
				aux_2606 = CAR(l1584_1052);
				obj_1915 = (local_t) (aux_2606);
			     }
			     val1105_1916 = (type_t) (_obj__252_type_cache);
			     ((((local_t) CREF(obj_1915))->type) = ((type_t) val1105_1916), BUNSPEC);
			  }
			  {
			     obj_t l1584_2611;
			     l1584_2611 = CDR(l1584_1052);
			     l1584_1052 = l1584_2611;
			     goto lname1585_1053;
			  }
		       }
		     else
		       {
			  ((bool_t) 1);
		       }
		  }
		  {
		     value_t val1081_1919;
		     val1081_1919 = (value_t) (new_fun_115_1031);
		     ((((global_t) CREF(global_2))->value) = ((value_t) val1081_1919), BUNSPEC);
		  }
		  {
		     node_t arg1652_1059;
		     {
			node_t arg1653_1060;
			{
			   obj_t arg1654_1061;
			   {
			      obj_t arg1655_1062;
			      obj_t arg1656_1063;
			      {
				 obj_t arg1657_1064;
				 arg1657_1064 = the_closure_238_globalize_free((variable_t) (local_3), BFALSE);
				 {
				    obj_t aux_2620;
				    aux_2620 = (obj_t) (env_1027);
				    arg1655_1062 = MAKE_PAIR(arg1657_1064, aux_2620);
				 }
			      }
			      if (NULLP(kaptured_5))
				{
				   arg1656_1063 = BNIL;
				}
			      else
				{
				   obj_t head1588_1068;
				   {
				      obj_t arg1670_1083;
				      {
					 obj_t aux_2627;
					 obj_t aux_2625;
					 aux_2627 = CAR(new_free_31_1028);
					 aux_2625 = CAR(kaptured_5);
					 arg1670_1083 = MAKE_PAIR(aux_2625, aux_2627);
				      }
				      head1588_1068 = MAKE_PAIR(arg1670_1083, BNIL);
				   }
				   {
				      obj_t ll1586_1069;
				      obj_t ll1587_1070;
				      obj_t tail1589_1071;
				      ll1586_1069 = CDR(kaptured_5);
				      ll1587_1070 = CDR(new_free_31_1028);
				      tail1589_1071 = head1588_1068;
				    lname1591_1072:
				      if (NULLP(ll1586_1069))
					{
					   arg1656_1063 = head1588_1068;
					}
				      else
					{
					   obj_t newtail1590_1076;
					   {
					      obj_t arg1666_1079;
					      {
						 obj_t aux_2635;
						 obj_t aux_2633;
						 aux_2635 = CAR(ll1587_1070);
						 aux_2633 = CAR(ll1586_1069);
						 arg1666_1079 = MAKE_PAIR(aux_2633, aux_2635);
					      }
					      newtail1590_1076 = MAKE_PAIR(arg1666_1079, BNIL);
					   }
					   SET_CDR(tail1589_1071, newtail1590_1076);
					   {
					      obj_t tail1589_2644;
					      obj_t ll1587_2642;
					      obj_t ll1586_2640;
					      ll1586_2640 = CDR(ll1586_1069);
					      ll1587_2642 = CDR(ll1587_1070);
					      tail1589_2644 = newtail1590_1076;
					      tail1589_1071 = tail1589_2644;
					      ll1587_1070 = ll1587_2642;
					      ll1586_1069 = ll1586_2640;
					      goto lname1591_1072;
					   }
					}
				   }
				}
			      arg1654_1061 = MAKE_PAIR(arg1655_1062, arg1656_1063);
			   }
			   arg1653_1060 = node_globalize__229_globalize_node((node_t) (body_6), (variable_t) (local_3), arg1654_1061);
			}
			arg1652_1059 = make_escaping_body_209_globalize_local__global_194(local_3, global_2, new_args_235_1029, new_free_31_1028, env_1027, arg1653_1060);
		     }
		     {
			obj_t val1148_1945;
			val1148_1945 = (obj_t) (arg1652_1059);
			((((sfun_t) CREF(new_fun_115_1031))->body) = ((obj_t) val1148_1945), BUNSPEC);
		     }
		  }
		  return global_2;
	       }
	    }
	 }
      }
   }
}


/* make-escaping-body */ node_t 
make_escaping_body_209_globalize_local__global_194(local_t local_7, global_t global_8, obj_t args_9, obj_t kaptured_10, local_t env_11, node_t body_12)
{
   {
      obj_t stack_1161;
      obj_t loc_1162;
      {
	 obj_t list1803_1223;
	 {
	    obj_t aux_2654;
	    aux_2654 = (obj_t) (env_11);
	    list1803_1223 = MAKE_PAIR(aux_2654, BNIL);
	 }
	 stack_1161 = list1803_1223;
      }
      loc_1162 = (((node_t) CREF(body_12))->loc);
      {
	 sfun_t obj_1949;
	 obj_t val1148_1950;
	 {
	    value_t aux_2658;
	    aux_2658 = (((local_t) CREF(local_7))->value);
	    obj_1949 = (sfun_t) (aux_2658);
	 }
	 val1148_1950 = (obj_t) (body_12);
	 ((((sfun_t) CREF(obj_1949))->body) = ((obj_t) val1148_1950), BUNSPEC);
      }
      {
	 obj_t arg1739_1165;
	 obj_t arg1743_1167;
	 let_fun_218_t arg1744_1168;
	 arg1739_1165 = ____74_type_cache;
	 {
	    obj_t kaptured_1169;
	    long num_1170;
	    obj_t res_1171;
	    kaptured_1169 = kaptured_10;
	    num_1170 = ((long) 0);
	    res_1171 = BNIL;
	  loop_1172:
	    if (NULLP(kaptured_1169))
	      {
		 arg1743_1167 = reverse__39___r4_pairs_and_lists_6_3(res_1171);
	      }
	    else
	      {
		 obj_t arg1748_1176;
		 long arg1749_1177;
		 obj_t arg1753_1178;
		 arg1748_1176 = CDR(kaptured_1169);
		 arg1749_1177 = (num_1170 + ((long) 1));
		 {
		    obj_t arg1755_1179;
		    {
		       obj_t arg1758_1180;
		       node_t arg1759_1181;
		       arg1758_1180 = CAR(kaptured_1169);
		       {
			  obj_t arg1760_1182;
			  obj_t arg1761_1183;
			  {
			     obj_t arg1762_1184;
			     obj_t arg1765_1185;
			     arg1762_1184 = CNST_TABLE_REF(((long) 1));
			     arg1765_1185 = CNST_TABLE_REF(((long) 0));
			     {
				obj_t list1767_1187;
				{
				   obj_t arg1768_1188;
				   {
				      obj_t arg1769_1189;
				      arg1769_1189 = MAKE_PAIR(BNIL, BNIL);
				      {
					 obj_t aux_2672;
					 aux_2672 = BINT(num_1170);
					 arg1768_1188 = MAKE_PAIR(aux_2672, arg1769_1189);
				      }
				   }
				   list1767_1187 = MAKE_PAIR(arg1765_1185, arg1768_1188);
				}
				arg1760_1182 = cons__138___r4_pairs_and_lists_6_3(arg1762_1184, list1767_1187);
			     }
			  }
			  arg1761_1183 = CNST_TABLE_REF(((long) 2));
			  arg1759_1181 = sexp__node_235_ast_sexp(arg1760_1182, stack_1161, loc_1162, arg1761_1183);
		       }
		       {
			  obj_t aux_2679;
			  aux_2679 = (obj_t) (arg1759_1181);
			  arg1755_1179 = MAKE_PAIR(arg1758_1180, aux_2679);
		       }
		    }
		    arg1753_1178 = MAKE_PAIR(arg1755_1179, res_1171);
		 }
		 {
		    obj_t res_2685;
		    long num_2684;
		    obj_t kaptured_2683;
		    kaptured_2683 = arg1748_1176;
		    num_2684 = arg1749_1177;
		    res_2685 = arg1753_1178;
		    res_1171 = res_2685;
		    num_1170 = num_2684;
		    kaptured_1169 = kaptured_2683;
		    goto loop_1172;
		 }
	      }
	 }
	 {
	    obj_t arg1772_1192;
	    obj_t arg1774_1194;
	    app_t arg1776_1195;
	    arg1772_1192 = ____74_type_cache;
	    {
	       obj_t list1777_1196;
	       {
		  obj_t aux_2686;
		  aux_2686 = (obj_t) (local_7);
		  list1777_1196 = MAKE_PAIR(aux_2686, BNIL);
	       }
	       arg1774_1194 = list1777_1196;
	    }
	    {
	       obj_t arg1780_1199;
	       var_t arg1783_1201;
	       obj_t arg1786_1202;
	       arg1780_1199 = ____74_type_cache;
	       {
		  obj_t arg1789_1204;
		  arg1789_1204 = ____74_type_cache;
		  {
		     var_t res2000_1971;
		     {
			type_t type_1962;
			variable_t variable_1963;
			type_1962 = (type_t) (arg1789_1204);
			variable_1963 = (variable_t) (local_7);
			{
			   var_t new1219_1964;
			   new1219_1964 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			   {
			      long arg1956_1965;
			      arg1956_1965 = class_num_218___object(var_ast_node);
			      {
				 obj_t obj_1969;
				 obj_1969 = (obj_t) (new1219_1964);
				 (((obj_t) CREF(obj_1969))->header = MAKE_HEADER(arg1956_1965, 0), BUNSPEC);
			      }
			   }
			   {
			      object_t aux_2695;
			      aux_2695 = (object_t) (new1219_1964);
			      OBJECT_WIDENING_SET(aux_2695, BFALSE);
			   }
			   ((((var_t) CREF(new1219_1964))->loc) = ((obj_t) loc_1162), BUNSPEC);
			   ((((var_t) CREF(new1219_1964))->type) = ((type_t) type_1962), BUNSPEC);
			   ((((var_t) CREF(new1219_1964))->variable) = ((variable_t) variable_1963), BUNSPEC);
			   res2000_1971 = new1219_1964;
			}
		     }
		     arg1783_1201 = res2000_1971;
		  }
	       }
	       if (NULLP(args_9))
		 {
		    arg1786_1202 = BNIL;
		 }
	       else
		 {
		    obj_t head1598_1208;
		    head1598_1208 = MAKE_PAIR(BNIL, BNIL);
		    {
		       obj_t l1596_1209;
		       obj_t tail1599_1210;
		       l1596_1209 = args_9;
		       tail1599_1210 = head1598_1208;
		     lname1597_1211:
		       if (NULLP(l1596_1209))
			 {
			    arg1786_1202 = CDR(head1598_1208);
			 }
		       else
			 {
			    obj_t newtail1600_1213;
			    {
			       var_t arg1794_1215;
			       {
				  obj_t arg1797_1219;
				  arg1797_1219 = ____74_type_cache;
				  {
				     var_t res2001_1988;
				     {
					type_t type_1979;
					variable_t variable_1980;
					type_1979 = (type_t) (arg1797_1219);
					{
					   obj_t aux_2708;
					   aux_2708 = CAR(l1596_1209);
					   variable_1980 = (variable_t) (aux_2708);
					}
					{
					   var_t new1219_1981;
					   new1219_1981 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
					   {
					      long arg1956_1982;
					      arg1956_1982 = class_num_218___object(var_ast_node);
					      {
						 obj_t obj_1986;
						 obj_1986 = (obj_t) (new1219_1981);
						 (((obj_t) CREF(obj_1986))->header = MAKE_HEADER(arg1956_1982, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_2715;
					      aux_2715 = (object_t) (new1219_1981);
					      OBJECT_WIDENING_SET(aux_2715, BFALSE);
					   }
					   ((((var_t) CREF(new1219_1981))->loc) = ((obj_t) loc_1162), BUNSPEC);
					   ((((var_t) CREF(new1219_1981))->type) = ((type_t) type_1979), BUNSPEC);
					   ((((var_t) CREF(new1219_1981))->variable) = ((variable_t) variable_1980), BUNSPEC);
					   res2001_1988 = new1219_1981;
					}
				     }
				     arg1794_1215 = res2001_1988;
				  }
			       }
			       {
				  obj_t aux_2721;
				  aux_2721 = (obj_t) (arg1794_1215);
				  newtail1600_1213 = MAKE_PAIR(aux_2721, BNIL);
			       }
			    }
			    SET_CDR(tail1599_1210, newtail1600_1213);
			    {
			       obj_t tail1599_2727;
			       obj_t l1596_2725;
			       l1596_2725 = CDR(l1596_1209);
			       tail1599_2727 = newtail1600_1213;
			       tail1599_1210 = tail1599_2727;
			       l1596_1209 = l1596_2725;
			       goto lname1597_1211;
			    }
			 }
		    }
		 }
	       {
		  app_t res2002_2012;
		  {
		     type_t type_1995;
		     obj_t key_1997;
		     type_1995 = (type_t) (arg1780_1199);
		     key_1997 = BINT(((long) -1));
		     {
			app_t new1253_2001;
			new1253_2001 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
			{
			   long arg1947_2002;
			   arg1947_2002 = class_num_218___object(app_ast_node);
			   {
			      obj_t obj_2010;
			      obj_2010 = (obj_t) (new1253_2001);
			      (((obj_t) CREF(obj_2010))->header = MAKE_HEADER(arg1947_2002, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_2734;
			   aux_2734 = (object_t) (new1253_2001);
			   OBJECT_WIDENING_SET(aux_2734, BFALSE);
			}
			((((app_t) CREF(new1253_2001))->loc) = ((obj_t) loc_1162), BUNSPEC);
			((((app_t) CREF(new1253_2001))->type) = ((type_t) type_1995), BUNSPEC);
			((((app_t) CREF(new1253_2001))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
			((((app_t) CREF(new1253_2001))->key) = ((obj_t) key_1997), BUNSPEC);
			((((app_t) CREF(new1253_2001))->fun) = ((var_t) arg1783_1201), BUNSPEC);
			((((app_t) CREF(new1253_2001))->args) = ((obj_t) arg1786_1202), BUNSPEC);
			((((app_t) CREF(new1253_2001))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
			res2002_2012 = new1253_2001;
		     }
		  }
		  arg1776_1195 = res2002_2012;
	       }
	    }
	    {
	       let_fun_218_t res2003_2029;
	       {
		  type_t type_2014;
		  obj_t key_2016;
		  node_t body_2018;
		  type_2014 = (type_t) (arg1772_1192);
		  key_2016 = BINT(((long) -1));
		  body_2018 = (node_t) (arg1776_1195);
		  {
		     let_fun_218_t new1364_2019;
		     new1364_2019 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
		     {
			long arg1928_2020;
			arg1928_2020 = class_num_218___object(let_fun_218_ast_node);
			{
			   obj_t obj_2027;
			   obj_2027 = (obj_t) (new1364_2019);
			   (((obj_t) CREF(obj_2027))->header = MAKE_HEADER(arg1928_2020, 0), BUNSPEC);
			}
		     }
		     {
			object_t aux_2751;
			aux_2751 = (object_t) (new1364_2019);
			OBJECT_WIDENING_SET(aux_2751, BFALSE);
		     }
		     ((((let_fun_218_t) CREF(new1364_2019))->loc) = ((obj_t) loc_1162), BUNSPEC);
		     ((((let_fun_218_t) CREF(new1364_2019))->type) = ((type_t) type_2014), BUNSPEC);
		     ((((let_fun_218_t) CREF(new1364_2019))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		     ((((let_fun_218_t) CREF(new1364_2019))->key) = ((obj_t) key_2016), BUNSPEC);
		     ((((let_fun_218_t) CREF(new1364_2019))->locals) = ((obj_t) arg1774_1194), BUNSPEC);
		     ((((let_fun_218_t) CREF(new1364_2019))->body) = ((node_t) body_2018), BUNSPEC);
		     res2003_2029 = new1364_2019;
		  }
	       }
	       arg1744_1168 = res2003_2029;
	    }
	 }
	 {
	    let_var_6_t res2004_2048;
	    {
	       type_t type_2031;
	       obj_t key_2033;
	       node_t body_2035;
	       type_2031 = (type_t) (arg1739_1165);
	       key_2033 = BINT(((long) -1));
	       body_2035 = (node_t) (arg1744_1168);
	       {
		  let_var_6_t new1378_2037;
		  new1378_2037 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
		  {
		     long arg1925_2038;
		     arg1925_2038 = class_num_218___object(let_var_6_ast_node);
		     {
			obj_t obj_2046;
			obj_2046 = (obj_t) (new1378_2037);
			(((obj_t) CREF(obj_2046))->header = MAKE_HEADER(arg1925_2038, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_2767;
		     aux_2767 = (object_t) (new1378_2037);
		     OBJECT_WIDENING_SET(aux_2767, BFALSE);
		  }
		  ((((let_var_6_t) CREF(new1378_2037))->loc) = ((obj_t) loc_1162), BUNSPEC);
		  ((((let_var_6_t) CREF(new1378_2037))->type) = ((type_t) type_2031), BUNSPEC);
		  ((((let_var_6_t) CREF(new1378_2037))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		  ((((let_var_6_t) CREF(new1378_2037))->key) = ((obj_t) key_2033), BUNSPEC);
		  ((((let_var_6_t) CREF(new1378_2037))->bindings) = ((obj_t) arg1743_1167), BUNSPEC);
		  ((((let_var_6_t) CREF(new1378_2037))->body) = ((node_t) body_2035), BUNSPEC);
		  ((((let_var_6_t) CREF(new1378_2037))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		  res2004_2048 = new1378_2037;
	       }
	    }
	    return (node_t) (res2004_2048);
	 }
      }
   }
}


/* fix-non-escaping-definition */ global_t 
fix_non_escaping_definition_247_globalize_local__global_194(global_t global_13, local_t local_14, obj_t args_15, obj_t kaptured_16, obj_t body_17)
{
   {
      obj_t add_args_4_1225;
      if (NULLP(kaptured_16))
	{
	   add_args_4_1225 = BNIL;
	}
      else
	{
	   obj_t head1604_1274;
	   head1604_1274 = MAKE_PAIR(BNIL, BNIL);
	   {
	      obj_t l1602_1275;
	      obj_t tail1605_1276;
	      l1602_1275 = kaptured_16;
	      tail1605_1276 = head1604_1274;
	    lname1603_1277:
	      if (NULLP(l1602_1275))
		{
		   add_args_4_1225 = CDR(head1604_1274);
		}
	      else
		{
		   obj_t newtail1606_1279;
		   {
		      local_t arg1848_1281;
		      {
			 obj_t old_1283;
			 old_1283 = CAR(l1602_1275);
			 {
			    local_t new_1284;
			    {
			       type_t aux_2788;
			       obj_t aux_2785;
			       {
				  obj_t aux_2789;
				  aux_2789 = default_type_190_globalize_local__global_194();
				  aux_2788 = (type_t) (aux_2789);
			       }
			       {
				  local_t obj_2055;
				  obj_2055 = (local_t) (old_1283);
				  aux_2785 = (((local_t) CREF(obj_2055))->id);
			       }
			       new_1284 = make_local_svar_140_ast_local(aux_2785, aux_2788);
			    }
			    {
			       bool_t arg1851_1285;
			       {
				  local_t obj_2056;
				  obj_2056 = (local_t) (old_1283);
				  arg1851_1285 = (((local_t) CREF(obj_2056))->user__32);
			       }
			       ((((local_t) CREF(new_1284))->user__32) = ((bool_t) arg1851_1285), BUNSPEC);
			    }
			    {
			       local_ginfo_108_t obj1607_1286;
			       obj1607_1286 = ((local_ginfo_108_t) (new_1284));
			       {
				  local_ginfo_108_t arg1852_1287;
				  {
				     local_ginfo_108_t res2005_2062;
				     {
					local_ginfo_108_t new1529_2060;
					new1529_2060 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
					((((local_ginfo_108_t) CREF(new1529_2060))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					res2005_2062 = new1529_2060;
				     }
				     arg1852_1287 = res2005_2062;
				  }
				  {
				     obj_t aux_2801;
				     object_t aux_2799;
				     aux_2801 = (obj_t) (arg1852_1287);
				     aux_2799 = (object_t) (obj1607_1286);
				     OBJECT_WIDENING_SET(aux_2799, aux_2801);
				  }
			       }
			       {
				  long arg1853_1288;
				  arg1853_1288 = class_num_218___object(local_ginfo_108_globalize_ginfo);
				  {
				     obj_t obj_2063;
				     obj_2063 = (obj_t) (obj1607_1286);
				     (((obj_t) CREF(obj_2063))->header = MAKE_HEADER(arg1853_1288, 0), BUNSPEC);
				  }
			       }
			       obj1607_1286;
			    }
			    {
			       svar_ginfo_131_t obj1608_1289;
			       obj1608_1289 = ((svar_ginfo_131_t) ((((local_t) CREF(new_1284))->value)));
			       {
				  svar_ginfo_131_t arg1856_1290;
				  {
				     svar_ginfo_131_t res2006_2075;
				     {
					svar_ginfo_131_t new1500_2070;
					new1500_2070 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
					((((svar_ginfo_131_t) CREF(new1500_2070))->kaptured__204) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					((((svar_ginfo_131_t) CREF(new1500_2070))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
					((((svar_ginfo_131_t) CREF(new1500_2070))->mark) = ((long) ((long) -10)), BUNSPEC);
					((((svar_ginfo_131_t) CREF(new1500_2070))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					res2006_2075 = new1500_2070;
				     }
				     arg1856_1290 = res2006_2075;
				  }
				  {
				     obj_t aux_2816;
				     object_t aux_2814;
				     aux_2816 = (obj_t) (arg1856_1290);
				     aux_2814 = (object_t) (obj1608_1289);
				     OBJECT_WIDENING_SET(aux_2814, aux_2816);
				  }
			       }
			       {
				  long arg1860_1294;
				  arg1860_1294 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
				  {
				     obj_t obj_2076;
				     obj_2076 = (obj_t) (obj1608_1289);
				     (((obj_t) CREF(obj_2076))->header = MAKE_HEADER(arg1860_1294, 0), BUNSPEC);
				  }
			       }
			       obj1608_1289;
			    }
			    {
			       obj_t arg1861_1295;
			       {
				  local_t obj_2078;
				  obj_2078 = (local_t) (old_1283);
				  arg1861_1295 = (((local_t) CREF(obj_2078))->access);
			       }
			       ((((local_t) CREF(new_1284))->access) = ((obj_t) arg1861_1295), BUNSPEC);
			    }
			    arg1848_1281 = new_1284;
			 }
		      }
		      {
			 obj_t aux_2825;
			 aux_2825 = (obj_t) (arg1848_1281);
			 newtail1606_1279 = MAKE_PAIR(aux_2825, BNIL);
		      }
		   }
		   SET_CDR(tail1605_1276, newtail1606_1279);
		   {
		      obj_t tail1605_2831;
		      obj_t l1602_2829;
		      l1602_2829 = CDR(l1602_1275);
		      tail1605_2831 = newtail1606_1279;
		      tail1605_1276 = tail1605_2831;
		      l1602_1275 = l1602_2829;
		      goto lname1603_1277;
		   }
		}
	   }
	}
      {
	 sfun_t new_fun_115_1227;
	 {
	    sfun_t duplicated1609_1255;
	    {
	       value_t aux_2832;
	       aux_2832 = (((local_t) CREF(local_14))->value);
	       duplicated1609_1255 = (sfun_t) (aux_2832);
	    }
	    {
	       sfun_t new1610_1256;
	       {
		  obj_t arg1826_1257;
		  obj_t arg1827_1258;
		  obj_t arg1829_1259;
		  obj_t arg1830_1260;
		  bool_t arg1831_1261;
		  obj_t arg1832_1262;
		  obj_t arg1833_1263;
		  obj_t arg1834_1264;
		  obj_t arg1835_1265;
		  obj_t arg1836_1266;
		  obj_t arg1837_1267;
		  obj_t arg1838_1268;
		  {
		     obj_t aux_2839;
		     obj_t aux_2835;
		     {
			long aux_2840;
			aux_2840 = list_length(kaptured_16);
			aux_2839 = BINT(aux_2840);
		     }
		     {
			long aux_2836;
			aux_2836 = (((sfun_t) CREF(duplicated1609_1255))->arity);
			aux_2835 = BINT(aux_2836);
		     }
		     arg1826_1257 = __arity_132_tools_args(aux_2835, aux_2839);
		  }
		  arg1827_1258 = (((sfun_t) CREF(duplicated1609_1255))->side_effect__165);
		  arg1829_1259 = (((sfun_t) CREF(duplicated1609_1255))->predicate_of_78);
		  arg1830_1260 = (((sfun_t) CREF(duplicated1609_1255))->stack_allocator_172);
		  arg1831_1261 = (((sfun_t) CREF(duplicated1609_1255))->top__138);
		  arg1832_1262 = (((sfun_t) CREF(duplicated1609_1255))->the_closure_238);
		  arg1833_1263 = (((sfun_t) CREF(duplicated1609_1255))->property);
		  arg1834_1264 = append_2_18___r4_pairs_and_lists_6_3(reverse___r4_pairs_and_lists_6_3(add_args_4_1225), args_15);
		  arg1835_1265 = (((sfun_t) CREF(duplicated1609_1255))->body);
		  arg1836_1266 = (((sfun_t) CREF(duplicated1609_1255))->class);
		  arg1837_1267 = (((sfun_t) CREF(duplicated1609_1255))->dsssl_keywords_243);
		  arg1838_1268 = (((sfun_t) CREF(duplicated1609_1255))->loc);
		  {
		     sfun_t res2007_2126;
		     {
			long arity_2098;
			arity_2098 = (long) CINT(arg1826_1257);
			{
			   sfun_t new1127_2110;
			   new1127_2110 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
			   {
			      long arg1978_2111;
			      arg1978_2111 = class_num_218___object(sfun_ast_var);
			      {
				 obj_t obj_2124;
				 obj_2124 = (obj_t) (new1127_2110);
				 (((obj_t) CREF(obj_2124))->header = MAKE_HEADER(arg1978_2111, 0), BUNSPEC);
			      }
			   }
			   {
			      object_t aux_2861;
			      aux_2861 = (object_t) (new1127_2110);
			      OBJECT_WIDENING_SET(aux_2861, BFALSE);
			   }
			   ((((sfun_t) CREF(new1127_2110))->arity) = ((long) arity_2098), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->side_effect__165) = ((obj_t) arg1827_1258), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->predicate_of_78) = ((obj_t) arg1829_1259), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->stack_allocator_172) = ((obj_t) arg1830_1260), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->top__138) = ((bool_t) arg1831_1261), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->the_closure_238) = ((obj_t) arg1832_1262), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->property) = ((obj_t) arg1833_1263), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->args) = ((obj_t) arg1834_1264), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->body) = ((obj_t) arg1835_1265), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->class) = ((obj_t) arg1836_1266), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->dsssl_keywords_243) = ((obj_t) arg1837_1267), BUNSPEC);
			   ((((sfun_t) CREF(new1127_2110))->loc) = ((obj_t) arg1838_1268), BUNSPEC);
			   res2007_2126 = new1127_2110;
			}
		     }
		     new1610_1256 = res2007_2126;
		  }
	       }
	       {
		  new_fun_115_1227 = new1610_1256;
	       }
	    }
	 }
	 {
	    {
	       local_ginfo_108_t obj_2127;
	       obj_2127 = (local_ginfo_108_t) (local_14);
	       {
		  obj_t aux_2877;
		  {
		     object_t aux_2878;
		     aux_2878 = (object_t) (obj_2127);
		     aux_2877 = OBJECT_WIDENING(aux_2878);
		  }
		  ((((local_ginfo_108_t) CREF(aux_2877))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
	       }
	    }
	    {
	       global_ginfo_75_t obj_2129;
	       obj_2129 = (global_ginfo_75_t) (global_13);
	       {
		  obj_t aux_2883;
		  {
		     object_t aux_2884;
		     aux_2884 = (object_t) (obj_2129);
		     aux_2883 = OBJECT_WIDENING(aux_2884);
		  }
		  ((((global_ginfo_75_t) CREF(aux_2883))->escape__117) = ((bool_t) ((bool_t) 1)), BUNSPEC);
	       }
	    }
	    {
	       type_t val1080_2132;
	       {
		  obj_t aux_2888;
		  aux_2888 = default_type_190_globalize_local__global_194();
		  val1080_2132 = (type_t) (aux_2888);
	       }
	       ((((global_t) CREF(global_13))->type) = ((type_t) val1080_2132), BUNSPEC);
	    }
	    {
	       node_t arg1806_1229;
	       {
		  obj_t arg1807_1230;
		  obj_t arg1808_1231;
		  {
		     sfun_ginfo_98_t obj_2134;
		     {
			value_t aux_2892;
			aux_2892 = (((local_t) CREF(local_14))->value);
			obj_2134 = (sfun_ginfo_98_t) (aux_2892);
		     }
		     {
			obj_t aux_2895;
			{
			   object_t aux_2896;
			   aux_2896 = (object_t) (obj_2134);
			   aux_2895 = OBJECT_WIDENING(aux_2896);
			}
			arg1807_1230 = (((sfun_ginfo_98_t) CREF(aux_2895))->new_body_215);
		     }
		  }
		  if (NULLP(kaptured_16))
		    {
		       arg1808_1231 = BNIL;
		    }
		  else
		    {
		       obj_t head1613_1236;
		       {
			  obj_t arg1821_1251;
			  {
			     obj_t aux_2904;
			     obj_t aux_2902;
			     aux_2904 = CAR(add_args_4_1225);
			     aux_2902 = CAR(kaptured_16);
			     arg1821_1251 = MAKE_PAIR(aux_2902, aux_2904);
			  }
			  head1613_1236 = MAKE_PAIR(arg1821_1251, BNIL);
		       }
		       {
			  obj_t ll1611_1237;
			  obj_t ll1612_1238;
			  obj_t tail1614_1239;
			  ll1611_1237 = CDR(kaptured_16);
			  ll1612_1238 = CDR(add_args_4_1225);
			  tail1614_1239 = head1613_1236;
			lname1616_1240:
			  if (NULLP(ll1611_1237))
			    {
			       arg1808_1231 = head1613_1236;
			    }
			  else
			    {
			       obj_t newtail1615_1244;
			       {
				  obj_t arg1816_1247;
				  {
				     obj_t aux_2912;
				     obj_t aux_2910;
				     aux_2912 = CAR(ll1612_1238);
				     aux_2910 = CAR(ll1611_1237);
				     arg1816_1247 = MAKE_PAIR(aux_2910, aux_2912);
				  }
				  newtail1615_1244 = MAKE_PAIR(arg1816_1247, BNIL);
			       }
			       SET_CDR(tail1614_1239, newtail1615_1244);
			       {
				  obj_t tail1614_2921;
				  obj_t ll1612_2919;
				  obj_t ll1611_2917;
				  ll1611_2917 = CDR(ll1611_1237);
				  ll1612_2919 = CDR(ll1612_1238);
				  tail1614_2921 = newtail1615_1244;
				  tail1614_1239 = tail1614_2921;
				  ll1612_1238 = ll1612_2919;
				  ll1611_1237 = ll1611_2917;
				  goto lname1616_1240;
			       }
			    }
		       }
		    }
		  arg1806_1229 = node_globalize__229_globalize_node((node_t) (arg1807_1230), (variable_t) (local_14), arg1808_1231);
	       }
	       {
		  obj_t val1148_2156;
		  val1148_2156 = (obj_t) (arg1806_1229);
		  ((((sfun_t) CREF(new_fun_115_1227))->body) = ((obj_t) val1148_2156), BUNSPEC);
	       }
	    }
	    {
	       value_t val1081_2158;
	       val1081_2158 = (value_t) (new_fun_115_1227);
	       ((((global_t) CREF(global_13))->value) = ((value_t) val1081_2158), BUNSPEC);
	    }
	    return global_13;
	 }
      }
   }
}


/* the-global */ global_t 
the_global_201_globalize_local__global_194(local_t local_18)
{
   {
      value_t value_1300;
      value_1300 = (((local_t) CREF(local_18))->value);
      {
	 bool_t test1866_1301;
	 {
	    obj_t aux_2932;
	    {
	       sfun_ginfo_98_t obj_2160;
	       obj_2160 = (sfun_ginfo_98_t) (value_1300);
	       {
		  obj_t aux_2934;
		  {
		     object_t aux_2935;
		     aux_2935 = (object_t) (obj_2160);
		     aux_2934 = OBJECT_WIDENING(aux_2935);
		  }
		  aux_2932 = (((sfun_ginfo_98_t) CREF(aux_2934))->the_global_201);
	       }
	    }
	    test1866_1301 = is_a__118___object(aux_2932, global_ast_var);
	 }
	 if (test1866_1301)
	   {
	      sfun_ginfo_98_t obj_2162;
	      obj_2162 = (sfun_ginfo_98_t) (value_1300);
	      {
		 obj_t aux_2942;
		 {
		    obj_t aux_2943;
		    {
		       object_t aux_2944;
		       aux_2944 = (object_t) (obj_2162);
		       aux_2943 = OBJECT_WIDENING(aux_2944);
		    }
		    aux_2942 = (((sfun_ginfo_98_t) CREF(aux_2943))->the_global_201);
		 }
		 return (global_t) (aux_2942);
	      }
	   }
	 else
	   {
	      obj_t id_1302;
	      {
		 bool_t test1881_1317;
		 {
		    obj_t arg1890_1324;
		    {
		       obj_t arg1892_1325;
		       arg1892_1325 = (((local_t) CREF(local_18))->id);
		       {
			  obj_t list1893_1326;
			  list1893_1326 = MAKE_PAIR(_module__166_module_module, BNIL);
			  arg1890_1324 = find_global_223_ast_env(arg1892_1325, list1893_1326);
		       }
		    }
		    test1881_1317 = is_a__118___object(arg1890_1324, global_ast_var);
		 }
		 if (test1881_1317)
		   {
		      obj_t arg1883_1318;
		      {
			 obj_t arg1884_1319;
			 arg1884_1319 = (((local_t) CREF(local_18))->id);
			 {
			    obj_t list1886_1321;
			    {
			       obj_t arg1887_1322;
			       {
				  obj_t aux_2955;
				  aux_2955 = CNST_TABLE_REF(((long) 3));
				  arg1887_1322 = MAKE_PAIR(aux_2955, BNIL);
			       }
			       list1886_1321 = MAKE_PAIR(arg1884_1319, arg1887_1322);
			    }
			    arg1883_1318 = symbol_append_197___r4_symbols_6_4(list1886_1321);
			 }
		      }
		      id_1302 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, arg1883_1318, BEOA);
		   }
		 else
		   {
		      id_1302 = (((local_t) CREF(local_18))->id);
		   }
	      }
	      {
		 global_t global_1303;
		 global_1303 = def_global_sfun__93_ast_glo_def_117(id_1302, BNIL, BNIL, _module__166_module_module, CNST_TABLE_REF(((long) 4)), CNST_TABLE_REF(((long) 5)), CNST_TABLE_REF(((long) 6)), BUNSPEC);
		 {
		    {
		       obj_t arg1868_1305;
		       {
			  sfun_t obj_2168;
			  obj_2168 = (sfun_t) (value_1300);
			  arg1868_1305 = (((sfun_t) CREF(obj_2168))->loc);
		       }
		       {
			  sfun_t obj_2169;
			  {
			     value_t aux_2969;
			     aux_2969 = (((global_t) CREF(global_1303))->value);
			     obj_2169 = (sfun_t) (aux_2969);
			  }
			  ((((sfun_t) CREF(obj_2169))->loc) = ((obj_t) arg1868_1305), BUNSPEC);
		       }
		    }
		    if ((((local_t) CREF(local_18))->user__32))
		      {
			 BUNSPEC;
		      }
		    else
		      {
			 ((((global_t) CREF(global_1303))->user__32) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		      }
		    {
		       global_ginfo_75_t obj1617_1307;
		       obj1617_1307 = ((global_ginfo_75_t) (global_1303));
		       {
			  global_ginfo_75_t arg1870_1308;
			  {
			     global_ginfo_75_t res2008_2179;
			     {
				obj_t global_closure_229_2175;
				global_closure_229_2175 = BFALSE;
				{
				   global_ginfo_75_t new1544_2176;
				   new1544_2176 = ((global_ginfo_75_t) BREF(GC_MALLOC(sizeof(struct global_ginfo_75))));
				   ((((global_ginfo_75_t) CREF(new1544_2176))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				   ((((global_ginfo_75_t) CREF(new1544_2176))->global_closure_229) = ((obj_t) global_closure_229_2175), BUNSPEC);
				   res2008_2179 = new1544_2176;
				}
			     }
			     arg1870_1308 = res2008_2179;
			  }
			  {
			     obj_t aux_2982;
			     object_t aux_2980;
			     aux_2982 = (obj_t) (arg1870_1308);
			     aux_2980 = (object_t) (obj1617_1307);
			     OBJECT_WIDENING_SET(aux_2980, aux_2982);
			  }
		       }
		       {
			  long arg1871_1309;
			  arg1871_1309 = class_num_218___object(global_ginfo_75_globalize_ginfo);
			  {
			     obj_t obj_2180;
			     obj_2180 = (obj_t) (obj1617_1307);
			     (((obj_t) CREF(obj_2180))->header = MAKE_HEADER(arg1871_1309, 0), BUNSPEC);
			  }
		       }
		       obj1617_1307;
		    }
		    {
		       obj_t arg1875_1311;
		       {
			  sfun_t obj_2183;
			  obj_2183 = (sfun_t) (value_1300);
			  arg1875_1311 = (((sfun_t) CREF(obj_2183))->side_effect__165);
		       }
		       {
			  sfun_t obj_2184;
			  {
			     value_t aux_2990;
			     aux_2990 = (((global_t) CREF(global_1303))->value);
			     obj_2184 = (sfun_t) (aux_2990);
			  }
			  ((((sfun_t) CREF(obj_2184))->side_effect__165) = ((obj_t) arg1875_1311), BUNSPEC);
		       }
		    }
		    {
		       sfun_ginfo_98_t obj_2186;
		       obj_t val1492_2187;
		       obj_2186 = (sfun_ginfo_98_t) (value_1300);
		       val1492_2187 = (obj_t) (global_1303);
		       {
			  obj_t aux_2996;
			  {
			     object_t aux_2997;
			     aux_2997 = (object_t) (obj_2186);
			     aux_2996 = OBJECT_WIDENING(aux_2997);
			  }
			  ((((sfun_ginfo_98_t) CREF(aux_2996))->the_global_201) = ((obj_t) val1492_2187), BUNSPEC);
		       }
		    }
		    return global_1303;
		 }
	      }
	   }
      }
   }
}


/* _the-global2010 */ obj_t 
_the_global2010_242_globalize_local__global_194(obj_t env_2323, obj_t local_2324)
{
   {
      global_t aux_3001;
      aux_3001 = the_global_201_globalize_local__global_194((local_t) (local_2324));
      return (obj_t) (aux_3001);
   }
}


/* method-init */ obj_t 
method_init_76_globalize_local__global_194()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_local__global_194()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_tools_args(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_engine_param(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_module_module(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_type_cache(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_ast_local(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_ast_glo_def_117(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_ast_sexp(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_ast_env(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   module_initialization_70_globalize_node(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
   return module_initialization_70_globalize_free(((long) 0), "GLOBALIZE_LOCAL->GLOBAL");
}
