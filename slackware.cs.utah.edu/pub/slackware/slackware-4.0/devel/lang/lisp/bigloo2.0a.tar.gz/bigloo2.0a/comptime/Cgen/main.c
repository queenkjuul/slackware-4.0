/*===========================================================================*/
/*   (Cgen/main.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_cgen_main();
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
static obj_t _make_bigloo_main_92_cgen_main(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_cgen_main(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t make_bigloo_main_85_cgen_main();
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern global_t def_global_sfun__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_id_110_module_module(obj_t);
static obj_t imported_modules_init_94_cgen_main();
static obj_t library_modules_init_112_cgen_main();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t _module__166_module_module;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_cgen_main = BUNSPEC;
extern obj_t _main__152_module_module;
static obj_t cnst_init_137_cgen_main();
static obj_t __cnst[10];

DEFINE_EXPORT_PROCEDURE(make_bigloo_main_env_171_cgen_main, _make_bigloo_main_92_cgen_main1622, _make_bigloo_main_92_cgen_main, 0L, 0);
DEFINE_STRING(string1614_cgen_main, string1614_cgen_main1623, "NOW BIGLOO-MAIN-PROCEDURE SFUN (ARGV::OBJ) BIGLOO_MAIN::OBJ VALUE @ BIGLOO-EXIT BEGIN ARGV ", 91);
DEFINE_STRING(string1613_cgen_main, string1613_cgen_main1624, "bigloo_main", 11);


/* module-initialization */ obj_t 
module_initialization_70_cgen_main(long checksum_1124, char *from_1125)
{
   if (CBOOL(require_initialization_114_cgen_main))
     {
	require_initialization_114_cgen_main = BBOOL(((bool_t) 0));
	library_modules_init_112_cgen_main();
	cnst_init_137_cgen_main();
	imported_modules_init_94_cgen_main();
	method_init_76_cgen_main();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cgen_main()
{
   module_initialization_70___object(((long) 0), "CGEN_MAIN");
   module_initialization_70___reader(((long) 0), "CGEN_MAIN");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CGEN_MAIN");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cgen_main()
{
   {
      obj_t cnst_port_138_1116;
      cnst_port_138_1116 = open_input_string(string1614_cgen_main);
      {
	 long i_1117;
	 i_1117 = ((long) 9);
       loop_1118:
	 {
	    bool_t test1615_1119;
	    test1615_1119 = (i_1117 == ((long) -1));
	    if (test1615_1119)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1617_1120;
		    {
		       obj_t list1618_1121;
		       {
			  obj_t arg1620_1122;
			  arg1620_1122 = BNIL;
			  list1618_1121 = MAKE_PAIR(cnst_port_138_1116, arg1620_1122);
		       }
		       arg1617_1120 = read___reader(list1618_1121);
		    }
		    CNST_TABLE_SET(i_1117, arg1617_1120);
		 }
		 {
		    int aux_1123;
		    {
		       long aux_1142;
		       aux_1142 = (i_1117 - ((long) 1));
		       aux_1123 = (int) (aux_1142);
		    }
		    {
		       long i_1145;
		       i_1145 = (long) (aux_1123);
		       i_1117 = i_1145;
		       goto loop_1118;
		    }
		 }
	      }
	 }
      }
   }
}


/* make-bigloo-main */ obj_t 
make_bigloo_main_85_cgen_main()
{
   {
      obj_t args_703;
      {
	 local_t arg1513_768;
	 arg1513_768 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 0)), (type_t) (_obj__252_type_cache));
	 {
	    obj_t list1514_769;
	    {
	       obj_t aux_1150;
	       aux_1150 = (obj_t) (arg1513_768);
	       list1514_769 = MAKE_PAIR(aux_1150, BNIL);
	    }
	    args_703 = list1514_769;
	 }
      }
      {
	 obj_t user_main_99_704;
	 {
	    bool_t test1512_767;
	    {
	       obj_t obj_1107;
	       obj_1107 = _main__152_module_module;
	       test1512_767 = is_a__118___object(obj_1107, global_ast_var);
	    }
	    if (test1512_767)
	      {
		 user_main_99_704 = _main__152_module_module;
	      }
	    else
	      {
		 user_main_99_704 = BFALSE;
	      }
	 }
	 {
	    obj_t main_body_213_705;
	    {
	       bool_t test1451_716;
	       test1451_716 = is_a__118___object(user_main_99_704, global_ast_var);
	       if (test1451_716)
		 {
		    obj_t arg1453_717;
		    obj_t arg1454_718;
		    obj_t arg1455_719;
		    arg1453_717 = CNST_TABLE_REF(((long) 1));
		    {
		       obj_t arg1463_725;
		       obj_t arg1465_727;
		       arg1463_725 = module_initialization_id_110_module_module(_module__166_module_module);
		       {
			  obj_t symbol_1109;
			  symbol_1109 = _module__166_module_module;
			  arg1465_727 = SYMBOL_TO_STRING(symbol_1109);
		       }
		       {
			  obj_t list1467_729;
			  {
			     obj_t arg1468_730;
			     {
				obj_t arg1469_731;
				arg1469_731 = MAKE_PAIR(BNIL, BNIL);
				arg1468_730 = MAKE_PAIR(arg1465_727, arg1469_731);
			     }
			     {
				obj_t aux_1162;
				aux_1162 = BINT(((long) 0));
				list1467_729 = MAKE_PAIR(aux_1162, arg1468_730);
			     }
			  }
			  arg1454_718 = cons__138___r4_pairs_and_lists_6_3(arg1463_725, list1467_729);
		       }
		    }
		    {
		       obj_t arg1471_733;
		       obj_t arg1473_734;
		       arg1471_733 = CNST_TABLE_REF(((long) 2));
		       {
			  obj_t arg1478_739;
			  obj_t arg1479_740;
			  {
			     obj_t arg1485_745;
			     obj_t arg1486_746;
			     obj_t arg1487_747;
			     arg1485_745 = CNST_TABLE_REF(((long) 3));
			     {
				global_t obj_1110;
				obj_1110 = (global_t) (user_main_99_704);
				arg1486_746 = (((global_t) CREF(obj_1110))->id);
			     }
			     {
				global_t obj_1111;
				obj_1111 = (global_t) (user_main_99_704);
				arg1487_747 = (((global_t) CREF(obj_1111))->module);
			     }
			     {
				obj_t list1489_749;
				{
				   obj_t arg1490_750;
				   {
				      obj_t arg1491_751;
				      arg1491_751 = MAKE_PAIR(BNIL, BNIL);
				      arg1490_750 = MAKE_PAIR(arg1487_747, arg1491_751);
				   }
				   list1489_749 = MAKE_PAIR(arg1486_746, arg1490_750);
				}
				arg1478_739 = cons__138___r4_pairs_and_lists_6_3(arg1485_745, list1489_749);
			     }
			  }
			  arg1479_740 = CNST_TABLE_REF(((long) 0));
			  {
			     obj_t list1481_742;
			     {
				obj_t arg1483_743;
				arg1483_743 = MAKE_PAIR(BNIL, BNIL);
				list1481_742 = MAKE_PAIR(arg1479_740, arg1483_743);
			     }
			     arg1473_734 = cons__138___r4_pairs_and_lists_6_3(arg1478_739, list1481_742);
			  }
		       }
		       {
			  obj_t list1475_736;
			  {
			     obj_t arg1476_737;
			     arg1476_737 = MAKE_PAIR(BNIL, BNIL);
			     list1475_736 = MAKE_PAIR(arg1473_734, arg1476_737);
			  }
			  arg1455_719 = cons__138___r4_pairs_and_lists_6_3(arg1471_733, list1475_736);
		       }
		    }
		    {
		       obj_t list1457_721;
		       {
			  obj_t arg1458_722;
			  {
			     obj_t arg1460_723;
			     arg1460_723 = MAKE_PAIR(BNIL, BNIL);
			     arg1458_722 = MAKE_PAIR(arg1455_719, arg1460_723);
			  }
			  list1457_721 = MAKE_PAIR(arg1454_718, arg1458_722);
		       }
		       main_body_213_705 = cons__138___r4_pairs_and_lists_6_3(arg1453_717, list1457_721);
		    }
		 }
	       else
		 {
		    obj_t arg1496_753;
		    obj_t arg1497_754;
		    arg1496_753 = CNST_TABLE_REF(((long) 2));
		    {
		       obj_t arg1502_759;
		       obj_t arg1504_761;
		       arg1502_759 = module_initialization_id_110_module_module(_module__166_module_module);
		       {
			  obj_t symbol_1112;
			  symbol_1112 = _module__166_module_module;
			  arg1504_761 = SYMBOL_TO_STRING(symbol_1112);
		       }
		       {
			  obj_t list1506_763;
			  {
			     obj_t arg1507_764;
			     {
				obj_t arg1510_765;
				arg1510_765 = MAKE_PAIR(BNIL, BNIL);
				arg1507_764 = MAKE_PAIR(arg1504_761, arg1510_765);
			     }
			     {
				obj_t aux_1192;
				aux_1192 = BINT(((long) 0));
				list1506_763 = MAKE_PAIR(aux_1192, arg1507_764);
			     }
			  }
			  arg1497_754 = cons__138___r4_pairs_and_lists_6_3(arg1502_759, list1506_763);
		       }
		    }
		    {
		       obj_t list1499_756;
		       {
			  obj_t arg1500_757;
			  arg1500_757 = MAKE_PAIR(BNIL, BNIL);
			  list1499_756 = MAKE_PAIR(arg1497_754, arg1500_757);
		       }
		       main_body_213_705 = cons__138___r4_pairs_and_lists_6_3(arg1496_753, list1499_756);
		    }
		 }
	    }
	    {
	       node_t node_706;
	       {
		  obj_t __713;
		  __713 = ____74_type_cache;
		  ____74_type_cache = _obj__252_type_cache;
		  {
		     node_t node_714;
		     node_714 = sexp__node_235_ast_sexp(main_body_213_705, args_703, BFALSE, CNST_TABLE_REF(((long) 4)));
		     ____74_type_cache = __713;
		     node_706 = node_714;
		  }
	       }
	       {
		  global_t bigloo_main_109_707;
		  bigloo_main_109_707 = def_global_sfun__93_ast_glo_def_117(CNST_TABLE_REF(((long) 5)), CNST_TABLE_REF(((long) 6)), args_703, _module__166_module_module, CNST_TABLE_REF(((long) 7)), CNST_TABLE_REF(((long) 8)), CNST_TABLE_REF(((long) 9)), (obj_t) (node_706));
		  {
		     {
			obj_t val1074_1114;
			val1074_1114 = string1613_cgen_main;
			((((global_t) CREF(bigloo_main_109_707))->name) = ((obj_t) val1074_1114), BUNSPEC);
		     }
		     return (obj_t) (bigloo_main_109_707);
		  }
	       }
	    }
	 }
      }
   }
}


/* _make-bigloo-main */ obj_t 
_make_bigloo_main_92_cgen_main(obj_t env_1115)
{
   return make_bigloo_main_85_cgen_main();
}


/* method-init */ obj_t 
method_init_76_cgen_main()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cgen_main()
{
   module_initialization_70_engine_param(((long) 0), "CGEN_MAIN");
   module_initialization_70_module_module(((long) 0), "CGEN_MAIN");
   module_initialization_70_type_type(((long) 0), "CGEN_MAIN");
   module_initialization_70_type_cache(((long) 0), "CGEN_MAIN");
   module_initialization_70_ast_var(((long) 0), "CGEN_MAIN");
   module_initialization_70_ast_node(((long) 0), "CGEN_MAIN");
   module_initialization_70_ast_env(((long) 0), "CGEN_MAIN");
   module_initialization_70_ast_sexp(((long) 0), "CGEN_MAIN");
   module_initialization_70_ast_local(((long) 0), "CGEN_MAIN");
   return module_initialization_70_ast_glo_def_117(((long) 0), "CGEN_MAIN");
}
