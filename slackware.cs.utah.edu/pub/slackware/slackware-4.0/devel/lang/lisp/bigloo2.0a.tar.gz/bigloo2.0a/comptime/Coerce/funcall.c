/*===========================================================================*/
/*   (Coerce/funcall.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_coerce_funcall();
extern obj_t funcall_ast_node;
static obj_t coerce_funcall_args__156_coerce_funcall(funcall_t, obj_t);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t string_append(obj_t, obj_t);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t location_full_fname_231_tools_location(obj_t);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
extern obj_t current_function_76_tools_error();
extern obj_t module_initialization_70_coerce_funcall(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_coerce_convert(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t _unsafe_arity__240_engine_param;
extern long list_length(obj_t);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
static obj_t imported_modules_init_94_coerce_funcall();
extern node_t coerce__182_coerce_coerce(node_t, type_t);
static obj_t library_modules_init_112_coerce_funcall();
static obj_t _coerce_1755_66_coerce_coerce(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_coerce_funcall();
extern obj_t _unsafe_type__146_engine_param;
extern obj_t open_input_string(obj_t);
extern node_t top_level_sexp__node_204_ast_sexp(obj_t, obj_t);
extern node_t convert__122_coerce_convert(node_t, type_t, type_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _compiler_debug__134_engine_param;
extern obj_t shape_tools_shape(obj_t);
extern obj_t _procedure__226_type_cache;
static obj_t coerce__funcall_115_coerce_funcall(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static node_t make_error_node_135_coerce_funcall(local_t, obj_t, obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_coerce_funcall = BUNSPEC;
static obj_t cnst_init_137_coerce_funcall();
static obj_t __cnst[17];

DEFINE_STATIC_PROCEDURE(proc1757_coerce_funcall, coerce__funcall_115_coerce_funcall1764, coerce__funcall_115_coerce_funcall, 0L, 2);
DEFINE_STRING(string1758_coerce_funcall, string1758_coerce_funcall1765, "CORRECT-ARITY? IF LET ::LONG LEN FUN (LIGHT ELIGHT) DUMMY __EOA__ _ QUOTE FAILURE __ERROR ERROR/LOCATION @ BEGIN LOCATION ", 122);
DEFINE_STRING(string1756_coerce_funcall, string1756_coerce_funcall1766, ":Wrong number of arguments", 26);
extern obj_t coerce__env_127_coerce_coerce;


/* module-initialization */ obj_t 
module_initialization_70_coerce_funcall(long checksum_1365, char *from_1366)
{
   if (CBOOL(require_initialization_114_coerce_funcall))
     {
	require_initialization_114_coerce_funcall = BBOOL(((bool_t) 0));
	library_modules_init_112_coerce_funcall();
	cnst_init_137_coerce_funcall();
	imported_modules_init_94_coerce_funcall();
	method_init_76_coerce_funcall();
	toplevel_init_63_coerce_funcall();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_coerce_funcall()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "COERCE_FUNCALL");
   module_initialization_70___object(((long) 0), "COERCE_FUNCALL");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "COERCE_FUNCALL");
   module_initialization_70___reader(((long) 0), "COERCE_FUNCALL");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_coerce_funcall()
{
   {
      obj_t cnst_port_138_1357;
      cnst_port_138_1357 = open_input_string(string1758_coerce_funcall);
      {
	 long i_1358;
	 i_1358 = ((long) 16);
       loop_1359:
	 {
	    bool_t test1759_1360;
	    test1759_1360 = (i_1358 == ((long) -1));
	    if (test1759_1360)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1760_1361;
		    {
		       obj_t list1761_1362;
		       {
			  obj_t arg1762_1363;
			  arg1762_1363 = BNIL;
			  list1761_1362 = MAKE_PAIR(cnst_port_138_1357, arg1762_1363);
		       }
		       arg1760_1361 = read___reader(list1761_1362);
		    }
		    CNST_TABLE_SET(i_1358, arg1760_1361);
		 }
		 {
		    int aux_1364;
		    {
		       long aux_1385;
		       aux_1385 = (i_1358 - ((long) 1));
		       aux_1364 = (int) (aux_1385);
		    }
		    {
		       long i_1388;
		       i_1388 = (long) (aux_1364);
		       i_1358 = i_1388;
		       goto loop_1359;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_coerce_funcall()
{
   return BUNSPEC;
}


/* make-error-node */ node_t 
make_error_node_135_coerce_funcall(local_t fun_17, obj_t error_msg_180_18, obj_t loc_19, obj_t to_20)
{
   {
      obj_t ut_731;
      ut_731 = _unsafe_type__146_engine_param;
      _unsafe_type__146_engine_param = BTRUE;
      {
	 node_t node_732;
	 {
	    node_t arg1461_733;
	    {
	       obj_t arg1463_734;
	       {
		  bool_t test1464_735;
		  {
		     bool_t test1551_806;
		     {
			bool_t test1552_807;
			{
			   long n1_1254;
			   n1_1254 = (long) CINT(_compiler_debug__134_engine_param);
			   test1552_807 = (n1_1254 > ((long) 0));
			}
			if (test1552_807)
			  {
			     test1551_806 = ((bool_t) 1);
			  }
			else
			  {
			     long n1_1256;
			     n1_1256 = (long) CINT(_bdb_debug__1_engine_param);
			     test1551_806 = (n1_1256 > ((long) 0));
			  }
		     }
		     if (test1551_806)
		       {
			  if (STRUCTP(loc_19))
			    {
			       obj_t aux_1400;
			       obj_t aux_1398;
			       aux_1400 = CNST_TABLE_REF(((long) 0));
			       aux_1398 = STRUCT_KEY(loc_19);
			       test1464_735 = (aux_1398 == aux_1400);
			    }
			  else
			    {
			       test1464_735 = ((bool_t) 0);
			    }
		       }
		     else
		       {
			  test1464_735 = ((bool_t) 0);
		       }
		  }
		  if (test1464_735)
		    {
		       obj_t arg1465_736;
		       obj_t arg1466_737;
		       obj_t arg1467_738;
		       arg1465_736 = CNST_TABLE_REF(((long) 1));
		       {
			  obj_t arg1474_744;
			  obj_t arg1475_745;
			  obj_t arg1476_746;
			  obj_t arg1477_747;
			  {
			     obj_t arg1487_756;
			     obj_t arg1488_757;
			     obj_t arg1489_758;
			     arg1487_756 = CNST_TABLE_REF(((long) 2));
			     arg1488_757 = CNST_TABLE_REF(((long) 3));
			     arg1489_758 = CNST_TABLE_REF(((long) 4));
			     {
				obj_t list1491_760;
				{
				   obj_t arg1494_761;
				   {
				      obj_t arg1496_762;
				      arg1496_762 = MAKE_PAIR(BNIL, BNIL);
				      arg1494_761 = MAKE_PAIR(arg1489_758, arg1496_762);
				   }
				   list1491_760 = MAKE_PAIR(arg1488_757, arg1494_761);
				}
				arg1474_744 = cons__138___r4_pairs_and_lists_6_3(arg1487_756, list1491_760);
			     }
			  }
			  {
			     obj_t arg1498_764;
			     {
				obj_t arg1500_766;
				arg1500_766 = current_function_76_tools_error();
				arg1498_764 = SYMBOL_TO_STRING(arg1500_766);
			     }
			     arg1475_745 = string_append(arg1498_764, string1756_coerce_funcall);
			  }
			  arg1476_746 = location_full_fname_231_tools_location(loc_19);
			  arg1477_747 = STRUCT_REF(loc_19, ((long) 1));
			  {
			     obj_t list1479_749;
			     {
				obj_t arg1480_750;
				{
				   obj_t arg1481_751;
				   {
				      obj_t arg1483_752;
				      {
					 obj_t arg1484_753;
					 {
					    obj_t arg1485_754;
					    arg1485_754 = MAKE_PAIR(BNIL, BNIL);
					    arg1484_753 = MAKE_PAIR(arg1477_747, arg1485_754);
					 }
					 arg1483_752 = MAKE_PAIR(arg1476_746, arg1484_753);
				      }
				      {
					 obj_t aux_1420;
					 aux_1420 = (obj_t) (fun_17);
					 arg1481_751 = MAKE_PAIR(aux_1420, arg1483_752);
				      }
				   }
				   arg1480_750 = MAKE_PAIR(error_msg_180_18, arg1481_751);
				}
				list1479_749 = MAKE_PAIR(arg1475_745, arg1480_750);
			     }
			     arg1466_737 = cons__138___r4_pairs_and_lists_6_3(arg1474_744, list1479_749);
			  }
		       }
		       {
			  obj_t arg1501_767;
			  obj_t arg1502_768;
			  obj_t arg1503_769;
			  obj_t arg1504_770;
			  arg1501_767 = CNST_TABLE_REF(((long) 5));
			  {
			     obj_t arg1514_777;
			     obj_t arg1515_778;
			     arg1514_777 = CNST_TABLE_REF(((long) 6));
			     arg1515_778 = CNST_TABLE_REF(((long) 7));
			     {
				obj_t list1517_780;
				{
				   obj_t arg1518_781;
				   arg1518_781 = MAKE_PAIR(BNIL, BNIL);
				   list1517_780 = MAKE_PAIR(arg1515_778, arg1518_781);
				}
				arg1502_768 = cons__138___r4_pairs_and_lists_6_3(arg1514_777, list1517_780);
			     }
			  }
			  {
			     obj_t arg1522_783;
			     obj_t arg1524_784;
			     arg1522_783 = CNST_TABLE_REF(((long) 6));
			     arg1524_784 = CNST_TABLE_REF(((long) 7));
			     {
				obj_t list1526_786;
				{
				   obj_t arg1527_787;
				   arg1527_787 = MAKE_PAIR(BNIL, BNIL);
				   list1526_786 = MAKE_PAIR(arg1524_784, arg1527_787);
				}
				arg1503_769 = cons__138___r4_pairs_and_lists_6_3(arg1522_783, list1526_786);
			     }
			  }
			  {
			     obj_t arg1529_789;
			     obj_t arg1530_790;
			     arg1529_789 = CNST_TABLE_REF(((long) 6));
			     arg1530_790 = CNST_TABLE_REF(((long) 7));
			     {
				obj_t list1532_792;
				{
				   obj_t arg1533_793;
				   arg1533_793 = MAKE_PAIR(BNIL, BNIL);
				   list1532_792 = MAKE_PAIR(arg1530_790, arg1533_793);
				}
				arg1504_770 = cons__138___r4_pairs_and_lists_6_3(arg1529_789, list1532_792);
			     }
			  }
			  {
			     obj_t list1506_772;
			     {
				obj_t arg1507_773;
				{
				   obj_t arg1510_774;
				   {
				      obj_t arg1511_775;
				      arg1511_775 = MAKE_PAIR(BNIL, BNIL);
				      arg1510_774 = MAKE_PAIR(arg1504_770, arg1511_775);
				   }
				   arg1507_773 = MAKE_PAIR(arg1503_769, arg1510_774);
				}
				list1506_772 = MAKE_PAIR(arg1502_768, arg1507_773);
			     }
			     arg1467_738 = cons__138___r4_pairs_and_lists_6_3(arg1501_767, list1506_772);
			  }
		       }
		       {
			  obj_t list1469_740;
			  {
			     obj_t arg1470_741;
			     {
				obj_t arg1471_742;
				arg1471_742 = MAKE_PAIR(BNIL, BNIL);
				arg1470_741 = MAKE_PAIR(arg1467_738, arg1471_742);
			     }
			     list1469_740 = MAKE_PAIR(arg1466_737, arg1470_741);
			  }
			  arg1463_734 = cons__138___r4_pairs_and_lists_6_3(arg1465_736, list1469_740);
		       }
		    }
		  else
		    {
		       obj_t arg1535_795;
		       obj_t arg1536_796;
		       arg1535_795 = CNST_TABLE_REF(((long) 5));
		       {
			  obj_t arg1548_803;
			  {
			     obj_t arg1550_805;
			     arg1550_805 = current_function_76_tools_error();
			     arg1548_803 = SYMBOL_TO_STRING(arg1550_805);
			  }
			  arg1536_796 = string_append(arg1548_803, string1756_coerce_funcall);
		       }
		       {
			  obj_t list1538_798;
			  {
			     obj_t arg1539_799;
			     {
				obj_t arg1540_800;
				{
				   obj_t arg1542_801;
				   arg1542_801 = MAKE_PAIR(BNIL, BNIL);
				   {
				      obj_t aux_1456;
				      aux_1456 = (obj_t) (fun_17);
				      arg1540_800 = MAKE_PAIR(aux_1456, arg1542_801);
				   }
				}
				arg1539_799 = MAKE_PAIR(error_msg_180_18, arg1540_800);
			     }
			     list1538_798 = MAKE_PAIR(arg1536_796, arg1539_799);
			  }
			  arg1463_734 = cons__138___r4_pairs_and_lists_6_3(arg1535_795, list1538_798);
		       }
		    }
	       }
	       arg1461_733 = top_level_sexp__node_204_ast_sexp(arg1463_734, loc_19);
	    }
	    node_732 = coerce__182_coerce_coerce(arg1461_733, (type_t) (to_20));
	 }
	 _unsafe_type__146_engine_param = ut_731;
	 return node_732;
      }
   }
}


/* coerce-funcall-args! */ obj_t 
coerce_funcall_args__156_coerce_funcall(funcall_t node_21, obj_t to_22)
{
   {
      bool_t test_1465;
      {
	 obj_t aux_1466;
	 aux_1466 = (((funcall_t) CREF(node_21))->args);
	 test_1465 = NULLP(aux_1466);
      }
      if (test_1465)
	{
	   obj_t arg1554_809;
	   {
	      node_t arg1555_810;
	      {
		 obj_t aux_1469;
		 {
		    node_t obj_1273;
		    obj_1273 = (node_t) (node_21);
		    aux_1469 = (((node_t) CREF(obj_1273))->loc);
		 }
		 arg1555_810 = top_level_sexp__node_204_ast_sexp(CNST_TABLE_REF(((long) 8)), aux_1469);
	      }
	      {
		 obj_t list1556_811;
		 {
		    obj_t aux_1474;
		    aux_1474 = (obj_t) (arg1555_810);
		    list1556_811 = MAKE_PAIR(aux_1474, BNIL);
		 }
		 arg1554_809 = list1556_811;
	      }
	   }
	   return ((((funcall_t) CREF(node_21))->args) = ((obj_t) arg1554_809), BUNSPEC);
	}
      else
	{
	   obj_t actuals_815;
	   obj_t prev_816;
	   actuals_815 = (((funcall_t) CREF(node_21))->args);
	   prev_816 = CNST_TABLE_REF(((long) 9));
	 loop_817:
	   if (NULLP(actuals_815))
	     {
		obj_t arg1563_821;
		{
		   node_t arg1564_822;
		   {
		      obj_t aux_1480;
		      {
			 node_t obj_1279;
			 obj_1279 = (node_t) (node_21);
			 aux_1480 = (((node_t) CREF(obj_1279))->loc);
		      }
		      arg1564_822 = top_level_sexp__node_204_ast_sexp(CNST_TABLE_REF(((long) 8)), aux_1480);
		   }
		   {
		      obj_t list1565_823;
		      {
			 obj_t aux_1485;
			 aux_1485 = (obj_t) (arg1564_822);
			 list1565_823 = MAKE_PAIR(aux_1485, BNIL);
		      }
		      arg1563_821 = list1565_823;
		   }
		}
		return SET_CDR(prev_816, arg1563_821);
	     }
	   else
	     {
		{
		   node_t arg1570_827;
		   {
		      node_t aux_1489;
		      {
			 obj_t aux_1490;
			 aux_1490 = CAR(actuals_815);
			 aux_1489 = (node_t) (aux_1490);
		      }
		      arg1570_827 = coerce__182_coerce_coerce(aux_1489, (type_t) (_obj__252_type_cache));
		   }
		   {
		      obj_t aux_1495;
		      aux_1495 = (obj_t) (arg1570_827);
		      SET_CAR(actuals_815, aux_1495);
		   }
		}
		{
		   obj_t prev_1500;
		   obj_t actuals_1498;
		   actuals_1498 = CDR(actuals_815);
		   prev_1500 = actuals_815;
		   prev_816 = prev_1500;
		   actuals_815 = actuals_1498;
		   goto loop_817;
		}
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_coerce_funcall()
{
   {
      obj_t coerce__funcall_115_1349;
      coerce__funcall_115_1349 = proc1757_coerce_funcall;
      return add_method__1___object(coerce__env_127_coerce_coerce, funcall_ast_node, coerce__funcall_115_1349);
   }
}


/* coerce!-funcall */ obj_t 
coerce__funcall_115_coerce_funcall(obj_t env_1350, obj_t node_1351, obj_t to_1352)
{
   {
      funcall_t node_1156;
      obj_t to_1157;
      node_1156 = (funcall_t) (node_1351);
      to_1157 = to_1352;
      {
	 obj_t error_msg_180_1160;
	 obj_t strength_1161;
	 {
	    obj_t arg1744_1228;
	    obj_t arg1745_1229;
	    arg1744_1228 = CNST_TABLE_REF(((long) 6));
	    arg1745_1229 = shape_tools_shape((obj_t) (node_1156));
	    {
	       obj_t list1746_1230;
	       {
		  obj_t arg1747_1231;
		  arg1747_1231 = MAKE_PAIR(arg1745_1229, BNIL);
		  list1746_1230 = MAKE_PAIR(arg1744_1228, arg1747_1231);
	       }
	       error_msg_180_1160 = list1746_1230;
	    }
	 }
	 strength_1161 = (((funcall_t) CREF(node_1156))->strength);
	 coerce_funcall_args__156_coerce_funcall(node_1156, to_1157);
	 {
	    bool_t test_1511;
	    {
	       obj_t aux_1512;
	       aux_1512 = memq___r4_pairs_and_lists_6_3(strength_1161, CNST_TABLE_REF(((long) 10)));
	       test_1511 = CBOOL(aux_1512);
	    }
	    if (test_1511)
	      {
		 node_t aux_1516;
		 aux_1516 = convert__122_coerce_convert((node_t) (node_1156), (type_t) (_obj__252_type_cache), (type_t) (to_1157));
		 return (obj_t) (aux_1516);
	      }
	    else
	      {
		 node_t c_fun_136_1163;
		 c_fun_136_1163 = coerce__182_coerce_coerce((((funcall_t) CREF(node_1156))->fun), (type_t) (_procedure__226_type_cache));
		 if (CBOOL(_unsafe_arity__240_engine_param))
		   {
		      ((((funcall_t) CREF(node_1156))->fun) = ((node_t) c_fun_136_1163), BUNSPEC);
		      {
			 node_t aux_1528;
			 aux_1528 = convert__122_coerce_convert((node_t) (node_1156), (type_t) (_obj__252_type_cache), (type_t) (to_1157));
			 return (obj_t) (aux_1528);
		      }
		   }
		 else
		   {
		      local_t fun_1164;
		      fun_1164 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 11)), (type_t) (_procedure__226_type_cache));
		      {
			 obj_t loc_1165;
			 {
			    node_t obj_1310;
			    obj_1310 = (node_t) (node_1156);
			    loc_1165 = (((node_t) CREF(obj_1310))->loc);
			 }
			 {
			    long len_1166;
			    {
			       long aux_1539;
			       aux_1539 = list_length((((funcall_t) CREF(node_1156))->args));
			       len_1166 = (aux_1539 - ((long) 2));
			    }
			    {
			       obj_t a_len_134_1167;
			       {
				  obj_t arg1730_1220;
				  arg1730_1220 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 12)), BEOA);
				  a_len_134_1167 = mark_symbol_non_user__17_ast_ident(arg1730_1220);
			       }
			       {
				  obj_t a_tlen_49_1168;
				  {
				     obj_t arg1725_1215;
				     {
					obj_t list1727_1217;
					{
					   obj_t arg1728_1218;
					   {
					      obj_t aux_1547;
					      aux_1547 = CNST_TABLE_REF(((long) 13));
					      arg1728_1218 = MAKE_PAIR(aux_1547, BNIL);
					   }
					   list1727_1217 = MAKE_PAIR(a_len_134_1167, arg1728_1218);
					}
					arg1725_1215 = symbol_append_197___r4_symbols_6_4(list1727_1217);
				     }
				     a_tlen_49_1168 = mark_symbol_non_user__17_ast_ident(arg1725_1215);
				  }
				  {
				     let_var_6_t lnode_1169;
				     {
					obj_t arg1680_1175;
					obj_t arg1682_1177;
					node_t arg1683_1178;
					arg1680_1175 = _obj__252_type_cache;
					{
					   obj_t arg1684_1179;
					   {
					      obj_t aux_1555;
					      obj_t aux_1553;
					      aux_1555 = (obj_t) (c_fun_136_1163);
					      aux_1553 = (obj_t) (fun_1164);
					      arg1684_1179 = MAKE_PAIR(aux_1553, aux_1555);
					   }
					   {
					      obj_t list1685_1180;
					      list1685_1180 = MAKE_PAIR(arg1684_1179, BNIL);
					      arg1682_1177 = list1685_1180;
					   }
					}
					{
					   obj_t arg1688_1182;
					   {
					      obj_t arg1689_1183;
					      obj_t arg1691_1184;
					      obj_t arg1692_1185;
					      arg1689_1183 = CNST_TABLE_REF(((long) 14));
					      {
						 obj_t arg1699_1191;
						 {
						    obj_t list1704_1196;
						    {
						       obj_t arg1705_1197;
						       arg1705_1197 = MAKE_PAIR(BNIL, BNIL);
						       {
							  obj_t aux_1561;
							  aux_1561 = BINT(len_1166);
							  list1704_1196 = MAKE_PAIR(aux_1561, arg1705_1197);
						       }
						    }
						    arg1699_1191 = cons__138___r4_pairs_and_lists_6_3(a_tlen_49_1168, list1704_1196);
						 }
						 {
						    obj_t list1701_1193;
						    list1701_1193 = MAKE_PAIR(BNIL, BNIL);
						    arg1691_1184 = cons__138___r4_pairs_and_lists_6_3(arg1699_1191, list1701_1193);
						 }
					      }
					      {
						 obj_t arg1707_1199;
						 obj_t arg1708_1200;
						 node_t arg1709_1201;
						 node_t arg1710_1202;
						 arg1707_1199 = CNST_TABLE_REF(((long) 15));
						 {
						    obj_t arg1718_1209;
						    arg1718_1209 = CNST_TABLE_REF(((long) 16));
						    {
						       obj_t list1721_1211;
						       {
							  obj_t arg1722_1212;
							  {
							     obj_t arg1723_1213;
							     arg1723_1213 = MAKE_PAIR(BNIL, BNIL);
							     arg1722_1212 = MAKE_PAIR(a_len_134_1167, arg1723_1213);
							  }
							  {
							     obj_t aux_1571;
							     aux_1571 = (obj_t) (fun_1164);
							     list1721_1211 = MAKE_PAIR(aux_1571, arg1722_1212);
							  }
						       }
						       arg1708_1200 = cons__138___r4_pairs_and_lists_6_3(arg1718_1209, list1721_1211);
						    }
						 }
						 arg1709_1201 = convert__122_coerce_convert((node_t) (node_1156), (type_t) (_obj__252_type_cache), (type_t) (to_1157));
						 arg1710_1202 = make_error_node_135_coerce_funcall(fun_1164, error_msg_180_1160, loc_1165, to_1157);
						 {
						    obj_t list1712_1204;
						    {
						       obj_t arg1713_1205;
						       {
							  obj_t arg1714_1206;
							  {
							     obj_t arg1716_1207;
							     arg1716_1207 = MAKE_PAIR(BNIL, BNIL);
							     {
								obj_t aux_1581;
								aux_1581 = (obj_t) (arg1710_1202);
								arg1714_1206 = MAKE_PAIR(aux_1581, arg1716_1207);
							     }
							  }
							  {
							     obj_t aux_1584;
							     aux_1584 = (obj_t) (arg1709_1201);
							     arg1713_1205 = MAKE_PAIR(aux_1584, arg1714_1206);
							  }
						       }
						       list1712_1204 = MAKE_PAIR(arg1708_1200, arg1713_1205);
						    }
						    arg1692_1185 = cons__138___r4_pairs_and_lists_6_3(arg1707_1199, list1712_1204);
						 }
					      }
					      {
						 obj_t list1694_1187;
						 {
						    obj_t arg1695_1188;
						    {
						       obj_t arg1697_1189;
						       arg1697_1189 = MAKE_PAIR(BNIL, BNIL);
						       arg1695_1188 = MAKE_PAIR(arg1692_1185, arg1697_1189);
						    }
						    list1694_1187 = MAKE_PAIR(arg1691_1184, arg1695_1188);
						 }
						 arg1688_1182 = cons__138___r4_pairs_and_lists_6_3(arg1689_1183, list1694_1187);
					      }
					   }
					   arg1683_1178 = top_level_sexp__node_204_ast_sexp(arg1688_1182, loc_1165);
					}
					{
					   let_var_6_t res1751_1335;
					   {
					      type_t type_1318;
					      obj_t key_1320;
					      type_1318 = (type_t) (arg1680_1175);
					      key_1320 = BINT(((long) -1));
					      {
						 let_var_6_t new1365_1324;
						 new1365_1324 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
						 {
						    long arg1592_1325;
						    arg1592_1325 = class_num_218___object(let_var_6_ast_node);
						    {
						       obj_t obj_1333;
						       obj_1333 = (obj_t) (new1365_1324);
						       (((obj_t) CREF(obj_1333))->header = MAKE_HEADER(arg1592_1325, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_1600;
						    aux_1600 = (object_t) (new1365_1324);
						    OBJECT_WIDENING_SET(aux_1600, BFALSE);
						 }
						 ((((let_var_6_t) CREF(new1365_1324))->loc) = ((obj_t) loc_1165), BUNSPEC);
						 ((((let_var_6_t) CREF(new1365_1324))->type) = ((type_t) type_1318), BUNSPEC);
						 ((((let_var_6_t) CREF(new1365_1324))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
						 ((((let_var_6_t) CREF(new1365_1324))->key) = ((obj_t) key_1320), BUNSPEC);
						 ((((let_var_6_t) CREF(new1365_1324))->bindings) = ((obj_t) arg1682_1177), BUNSPEC);
						 ((((let_var_6_t) CREF(new1365_1324))->body) = ((node_t) arg1683_1178), BUNSPEC);
						 ((((let_var_6_t) CREF(new1365_1324))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
						 res1751_1335 = new1365_1324;
					      }
					   }
					   lnode_1169 = res1751_1335;
					}
				     }
				     {
					{
					   var_t arg1675_1170;
					   {
					      obj_t arg1677_1172;
					      arg1677_1172 = _obj__252_type_cache;
					      {
						 var_t res1752_1346;
						 {
						    type_t type_1337;
						    variable_t variable_1338;
						    type_1337 = (type_t) (arg1677_1172);
						    variable_1338 = (variable_t) (fun_1164);
						    {
						       var_t new1206_1339;
						       new1206_1339 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						       {
							  long arg1632_1340;
							  arg1632_1340 = class_num_218___object(var_ast_node);
							  {
							     obj_t obj_1344;
							     obj_1344 = (obj_t) (new1206_1339);
							     (((obj_t) CREF(obj_1344))->header = MAKE_HEADER(arg1632_1340, 0), BUNSPEC);
							  }
						       }
						       {
							  object_t aux_1616;
							  aux_1616 = (object_t) (new1206_1339);
							  OBJECT_WIDENING_SET(aux_1616, BFALSE);
						       }
						       ((((var_t) CREF(new1206_1339))->loc) = ((obj_t) loc_1165), BUNSPEC);
						       ((((var_t) CREF(new1206_1339))->type) = ((type_t) type_1337), BUNSPEC);
						       ((((var_t) CREF(new1206_1339))->variable) = ((variable_t) variable_1338), BUNSPEC);
						       res1752_1346 = new1206_1339;
						    }
						 }
						 arg1675_1170 = res1752_1346;
					      }
					   }
					   {
					      node_t val1274_1348;
					      val1274_1348 = (node_t) (arg1675_1170);
					      ((((funcall_t) CREF(node_1156))->fun) = ((node_t) val1274_1348), BUNSPEC);
					   }
					}
					return (obj_t) (lnode_1169);
				     }
				  }
			       }
			    }
			 }
		      }
		   }
	      }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_coerce_funcall()
{
   module_initialization_70_tools_trace(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_engine_param(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_tools_shape(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_tools_error(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_tools_location(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_type_type(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_type_cache(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_ast_var(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_ast_node(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_ast_sexp(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_ast_local(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_ast_ident(((long) 0), "COERCE_FUNCALL");
   module_initialization_70_coerce_coerce(((long) 0), "COERCE_FUNCALL");
   return module_initialization_70_coerce_convert(((long) 0), "COERCE_FUNCALL");
}
