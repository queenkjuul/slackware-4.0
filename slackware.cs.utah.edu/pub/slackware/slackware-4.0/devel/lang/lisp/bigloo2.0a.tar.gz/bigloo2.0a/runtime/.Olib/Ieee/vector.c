/*===========================================================================*/
/*   (Ieee/vector.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t vector_fill__80___r4_vectors_6_8(obj_t, obj_t);
static obj_t _vector_fill_1156_202___r4_vectors_6_8(obj_t, obj_t, obj_t);
extern obj_t vector_ref_ur_84___r4_vectors_6_8(obj_t, long);
extern long vector_tag_145___r4_vectors_6_8(obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t _vector_tag1157_249___r4_vectors_6_8(obj_t, obj_t);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t symbol1313___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1312___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1311___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1299___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1309___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1310___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1308___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1297___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1307___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1296___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1306___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1305___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1304___r4_vectors_6_8 = BUNSPEC;
extern obj_t vector_ref_121___r4_vectors_6_8(obj_t, long);
static obj_t symbol1303___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1292___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1302___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1301___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1289___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1290___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1300___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1288___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1286___r4_vectors_6_8 = BUNSPEC;
static obj_t symbol1283___r4_vectors_6_8 = BUNSPEC;
extern bool_t vector__172___r4_vectors_6_8(obj_t);
extern obj_t vector__list_155___r4_vectors_6_8(obj_t);
extern long vector_length_150___r4_vectors_6_8(obj_t);
static obj_t _vector_set_ur_1154_169___r4_vectors_6_8(obj_t, obj_t, obj_t, obj_t);
extern long list_length(obj_t);
static obj_t _vector__list1155_42___r4_vectors_6_8(obj_t, obj_t);
static obj_t _vector_tag_set_1158_236___r4_vectors_6_8(obj_t, obj_t, obj_t);
extern obj_t list__vector_101___r4_vectors_6_8(obj_t);
extern obj_t vector___r4_vectors_6_8(obj_t);
static obj_t _list__vector_50___r4_vectors_6_8(obj_t, obj_t);
extern obj_t fill_vector(obj_t, long, obj_t);
static obj_t _vector_ref_ur1153_88___r4_vectors_6_8(obj_t, obj_t, obj_t);
static obj_t _make_vector1149_82___r4_vectors_6_8(obj_t, obj_t, obj_t);
extern obj_t vector_set_ur__74___r4_vectors_6_8(obj_t, long, obj_t);
extern obj_t vector_set__141___r4_vectors_6_8(obj_t, long, obj_t);
static obj_t imported_modules_init_94___r4_vectors_6_8();
static obj_t _vector_length1150_232___r4_vectors_6_8(obj_t, obj_t);
static obj_t _vector__62___r4_vectors_6_8(obj_t, obj_t);
extern obj_t make_vector_110___r4_vectors_6_8(long, obj_t);
static obj_t require_initialization_114___r4_vectors_6_8 = BUNSPEC;
static obj_t _vector_ref1151_19___r4_vectors_6_8(obj_t, obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t vector_tag_set__158___r4_vectors_6_8(obj_t, long);
static obj_t cnst_init_137___r4_vectors_6_8();
extern obj_t make_vector(long, obj_t);
static obj_t _vector___r4_vectors_6_8(obj_t, obj_t);
static obj_t _vector_set_1152_161___r4_vectors_6_8(obj_t, obj_t, obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( vector_env_233___r4_vectors_6_8, _vector___r4_vectors_6_81315, va_generic_entry, _vector___r4_vectors_6_8, -1 );
DEFINE_EXPORT_PROCEDURE( vector_set__env_232___r4_vectors_6_8, _vector_set_1152_161___r4_vectors_6_81316, _vector_set_1152_161___r4_vectors_6_8, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( list__vector_env_25___r4_vectors_6_8, _list__vector_50___r4_vectors_6_81317, _list__vector_50___r4_vectors_6_8, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( vector_set_ur__env_52___r4_vectors_6_8, _vector_set_ur_1154_169___r4_vectors_6_81318, _vector_set_ur_1154_169___r4_vectors_6_8, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( vector__env_224___r4_vectors_6_8, _vector__62___r4_vectors_6_81319, _vector__62___r4_vectors_6_8, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( vector_tag_set__env_48___r4_vectors_6_8, _vector_tag_set_1158_236___r4_vectors_6_81320, _vector_tag_set_1158_236___r4_vectors_6_8, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( vector_fill__env_134___r4_vectors_6_8, _vector_fill_1156_202___r4_vectors_6_81321, _vector_fill_1156_202___r4_vectors_6_8, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( vector_ref_env_100___r4_vectors_6_8, _vector_ref1151_19___r4_vectors_6_81322, _vector_ref1151_19___r4_vectors_6_8, 0L, 2 );
DEFINE_STRING( string1298___r4_vectors_6_8, string1298___r4_vectors_6_81323, "vector-set!", 11 );
DEFINE_STRING( string1295___r4_vectors_6_8, string1295___r4_vectors_6_81324, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1294___r4_vectors_6_8, string1294___r4_vectors_6_81325, "index out of range", 18 );
DEFINE_STRING( string1293___r4_vectors_6_8, string1293___r4_vectors_6_81326, "vector-ref", 10 );
DEFINE_STRING( string1291___r4_vectors_6_8, string1291___r4_vectors_6_81327, "VECTOR", 6 );
DEFINE_STRING( string1287___r4_vectors_6_8, string1287___r4_vectors_6_81328, "LONG", 4 );
DEFINE_STRING( string1285___r4_vectors_6_8, string1285___r4_vectors_6_81329, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/vector.scm", 59 );
DEFINE_STRING( string1284___r4_vectors_6_8, string1284___r4_vectors_6_81330, "PAIR", 4 );
DEFINE_EXPORT_PROCEDURE( make_vector_env_128___r4_vectors_6_8, _make_vector1149_82___r4_vectors_6_81331, va_generic_entry, _make_vector1149_82___r4_vectors_6_8, -2 );
DEFINE_EXPORT_PROCEDURE( vector_ref_ur_env_72___r4_vectors_6_8, _vector_ref_ur1153_88___r4_vectors_6_81332, _vector_ref_ur1153_88___r4_vectors_6_8, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( vector_tag_env_1___r4_vectors_6_8, _vector_tag1157_249___r4_vectors_6_81333, _vector_tag1157_249___r4_vectors_6_8, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( vector__list_env_228___r4_vectors_6_8, _vector__list1155_42___r4_vectors_6_81334, _vector__list1155_42___r4_vectors_6_8, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( vector_length_env_9___r4_vectors_6_8, _vector_length1150_232___r4_vectors_6_81335, _vector_length1150_232___r4_vectors_6_8, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r4_vectors_6_8(long checksum_580, char * from_581)
{
if(CBOOL(require_initialization_114___r4_vectors_6_8)){
require_initialization_114___r4_vectors_6_8 = BBOOL(((bool_t)0));
cnst_init_137___r4_vectors_6_8();
imported_modules_init_94___r4_vectors_6_8();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_vectors_6_8()
{
symbol1283___r4_vectors_6_8 = string_to_symbol("MAKE-VECTOR");
symbol1286___r4_vectors_6_8 = string_to_symbol("_MAKE-VECTOR1149");
symbol1288___r4_vectors_6_8 = string_to_symbol("VECTOR");
symbol1289___r4_vectors_6_8 = string_to_symbol("VECTOR-LENGTH");
symbol1290___r4_vectors_6_8 = string_to_symbol("_VECTOR-LENGTH1150");
symbol1292___r4_vectors_6_8 = string_to_symbol("VECTOR-REF");
symbol1296___r4_vectors_6_8 = string_to_symbol("_VECTOR-REF1151");
symbol1297___r4_vectors_6_8 = string_to_symbol("VECTOR-SET!");
symbol1299___r4_vectors_6_8 = string_to_symbol("_VECTOR-SET!1152");
symbol1300___r4_vectors_6_8 = string_to_symbol("VECTOR-REF-UR");
symbol1301___r4_vectors_6_8 = string_to_symbol("_VECTOR-REF-UR1153");
symbol1302___r4_vectors_6_8 = string_to_symbol("VECTOR-SET-UR!");
symbol1303___r4_vectors_6_8 = string_to_symbol("_VECTOR-SET-UR!1154");
symbol1304___r4_vectors_6_8 = string_to_symbol("VECTOR->LIST");
symbol1305___r4_vectors_6_8 = string_to_symbol("_VECTOR->LIST1155");
symbol1306___r4_vectors_6_8 = string_to_symbol("LIST->VECTOR");
symbol1307___r4_vectors_6_8 = string_to_symbol("VECTOR-FILL!");
symbol1308___r4_vectors_6_8 = string_to_symbol("_VECTOR-FILL!1156");
symbol1309___r4_vectors_6_8 = string_to_symbol("VECTOR-TAG");
symbol1310___r4_vectors_6_8 = string_to_symbol("_VECTOR-TAG1157");
symbol1311___r4_vectors_6_8 = string_to_symbol("VECTOR-TAG-SET!");
symbol1312___r4_vectors_6_8 = string_to_symbol("_VECTOR-TAG-SET!1158");
return (symbol1313___r4_vectors_6_8 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* vector? */bool_t vector__172___r4_vectors_6_8(obj_t obj_1)
{
return VECTORP(obj_1);
}


/* _vector? */obj_t _vector__62___r4_vectors_6_8(obj_t env_375, obj_t obj_376)
{
{
bool_t aux_611;
{
obj_t obj_518;
obj_518 = obj_376;
aux_611 = VECTORP(obj_518);
}
return BBOOL(aux_611);
}
}


/* make-vector */obj_t make_vector_110___r4_vectors_6_8(long int_2, obj_t fill_3)
{
{
obj_t symbol1124_519;
symbol1124_519 = symbol1283___r4_vectors_6_8;
{
PUSH_TRACE(symbol1124_519);
BUNSPEC;
{
obj_t aux1123_520;
if(NULLP(fill_3)){
aux1123_520 = make_vector(int_2, BUNSPEC);
}
 else {
obj_t arg1003_521;
{
obj_t pair_522;
if(PAIRP(fill_3)){
pair_522 = fill_3;
}
 else {
bigloo_type_error_location_103___error(symbol1283___r4_vectors_6_8, string1284___r4_vectors_6_8, fill_3, string1285___r4_vectors_6_8, BINT(((long)4131)));
exit( -1 );}
arg1003_521 = CAR(pair_522);
}
aux1123_520 = make_vector(int_2, arg1003_521);
}
POP_TRACE();
return aux1123_520;
}
}
}
}


/* _make-vector1149 */obj_t _make_vector1149_82___r4_vectors_6_8(obj_t env_377, obj_t int_378, obj_t fill_379)
{
{
long int_184_523;
obj_t fill_524;
{
obj_t aux_626;
if(INTEGERP(int_378)){
aux_626 = int_378;
}
 else {
bigloo_type_error_location_103___error(symbol1286___r4_vectors_6_8, string1287___r4_vectors_6_8, int_378, string1285___r4_vectors_6_8, BINT(((long)4004)));
exit( -1 );}
int_184_523 = (long)CINT(aux_626);
}
fill_524 = fill_379;
{
obj_t symbol1124_525;
symbol1124_525 = symbol1283___r4_vectors_6_8;
{
PUSH_TRACE(symbol1124_525);
BUNSPEC;
{
obj_t aux1123_526;
if(NULLP(fill_524)){
aux1123_526 = make_vector(int_184_523, BUNSPEC);
}
 else {
obj_t arg1003_527;
{
obj_t pair_528;
if(PAIRP(fill_524)){
pair_528 = fill_524;
}
 else {
bigloo_type_error_location_103___error(symbol1283___r4_vectors_6_8, string1284___r4_vectors_6_8, fill_524, string1285___r4_vectors_6_8, BINT(((long)4131)));
exit( -1 );}
arg1003_527 = CAR(pair_528);
}
aux1123_526 = make_vector(int_184_523, arg1003_527);
}
POP_TRACE();
return aux1123_526;
}
}
}
}
}


/* vector */obj_t vector___r4_vectors_6_8(obj_t args_4)
{
{
obj_t symbol1126_529;
symbol1126_529 = symbol1288___r4_vectors_6_8;
{
PUSH_TRACE(symbol1126_529);
BUNSPEC;
{
obj_t aux1125_530;
aux1125_530 = list__vector_101___r4_vectors_6_8(args_4);
POP_TRACE();
return aux1125_530;
}
}
}
}


/* _vector */obj_t _vector___r4_vectors_6_8(obj_t env_380, obj_t args_381)
{
{
obj_t args_531;
args_531 = args_381;
{
obj_t symbol1126_532;
symbol1126_532 = symbol1288___r4_vectors_6_8;
{
PUSH_TRACE(symbol1126_532);
BUNSPEC;
{
obj_t aux1125_533;
aux1125_533 = list__vector_101___r4_vectors_6_8(args_531);
POP_TRACE();
return aux1125_533;
}
}
}
}
}


/* vector-length */long vector_length_150___r4_vectors_6_8(obj_t vector_5)
{
{
obj_t symbol1128_534;
symbol1128_534 = symbol1289___r4_vectors_6_8;
{
PUSH_TRACE(symbol1128_534);
BUNSPEC;
{
long aux1127_535;
aux1127_535 = VECTOR_LENGTH(vector_5);
POP_TRACE();
return aux1127_535;
}
}
}
}


/* _vector-length1150 */obj_t _vector_length1150_232___r4_vectors_6_8(obj_t env_382, obj_t vector_383)
{
{
long aux_654;
{
obj_t vector_536;
if(VECTORP(vector_383)){
vector_536 = vector_383;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r4_vectors_6_8, string1291___r4_vectors_6_8, vector_383, string1285___r4_vectors_6_8, BINT(((long)4645)));
exit( -1 );}
{
obj_t symbol1128_537;
symbol1128_537 = symbol1289___r4_vectors_6_8;
{
PUSH_TRACE(symbol1128_537);
BUNSPEC;
{
long aux1127_538;
aux1127_538 = VECTOR_LENGTH(vector_536);
POP_TRACE();
aux_654 = aux1127_538;
}
}
}
}
return BINT(aux_654);
}
}


/* vector-ref */obj_t vector_ref_121___r4_vectors_6_8(obj_t vector_6, long k_7)
{
{
obj_t symbol1130_539;
symbol1130_539 = symbol1292___r4_vectors_6_8;
{
PUSH_TRACE(symbol1130_539);
BUNSPEC;
{
obj_t aux1129_540;
{
bool_t test1004_541;
{
long aux_665;
aux_665 = VECTOR_LENGTH(vector_6);
test1004_541 = BOUND_CHECK(k_7, aux_665);
}
if(test1004_541){
aux1129_540 = VECTOR_REF(vector_6, k_7);
}
 else {
aux1129_540 = debug_error_location_199___error(string1293___r4_vectors_6_8, string1294___r4_vectors_6_8, BINT(k_7), string1295___r4_vectors_6_8, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1129_540;
}
}
}
}


/* _vector-ref1151 */obj_t _vector_ref1151_19___r4_vectors_6_8(obj_t env_384, obj_t vector_385, obj_t k_386)
{
{
obj_t vector_542;
long k_543;
if(VECTORP(vector_385)){
vector_542 = vector_385;
}
 else {
bigloo_type_error_location_103___error(symbol1296___r4_vectors_6_8, string1291___r4_vectors_6_8, vector_385, string1285___r4_vectors_6_8, BINT(((long)4935)));
exit( -1 );}
{
obj_t aux_679;
if(INTEGERP(k_386)){
aux_679 = k_386;
}
 else {
bigloo_type_error_location_103___error(symbol1296___r4_vectors_6_8, string1287___r4_vectors_6_8, k_386, string1285___r4_vectors_6_8, BINT(((long)4935)));
exit( -1 );}
k_543 = (long)CINT(aux_679);
}
{
obj_t symbol1130_544;
symbol1130_544 = symbol1292___r4_vectors_6_8;
{
PUSH_TRACE(symbol1130_544);
BUNSPEC;
{
obj_t aux1129_545;
{
bool_t test1004_546;
{
long aux_687;
aux_687 = VECTOR_LENGTH(vector_542);
test1004_546 = BOUND_CHECK(k_543, aux_687);
}
if(test1004_546){
aux1129_545 = VECTOR_REF(vector_542, k_543);
}
 else {
aux1129_545 = debug_error_location_199___error(string1293___r4_vectors_6_8, string1294___r4_vectors_6_8, BINT(k_543), string1295___r4_vectors_6_8, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1129_545;
}
}
}
}
}


/* vector-set! */obj_t vector_set__141___r4_vectors_6_8(obj_t vector_8, long k_9, obj_t obj_10)
{
{
obj_t symbol1132_547;
symbol1132_547 = symbol1297___r4_vectors_6_8;
{
PUSH_TRACE(symbol1132_547);
BUNSPEC;
{
obj_t aux1131_548;
{
bool_t test1006_549;
{
long aux_697;
aux_697 = VECTOR_LENGTH(vector_8);
test1006_549 = BOUND_CHECK(k_9, aux_697);
}
if(test1006_549){
aux1131_548 = VECTOR_SET(vector_8, k_9, obj_10);
}
 else {
aux1131_548 = debug_error_location_199___error(string1298___r4_vectors_6_8, string1294___r4_vectors_6_8, BINT(k_9), string1295___r4_vectors_6_8, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1131_548;
}
}
}
}


/* _vector-set!1152 */obj_t _vector_set_1152_161___r4_vectors_6_8(obj_t env_387, obj_t vector_388, obj_t k_389, obj_t obj_390)
{
{
obj_t vector_550;
long k_551;
obj_t obj_552;
if(VECTORP(vector_388)){
vector_550 = vector_388;
}
 else {
bigloo_type_error_location_103___error(symbol1299___r4_vectors_6_8, string1291___r4_vectors_6_8, vector_388, string1285___r4_vectors_6_8, BINT(((long)5333)));
exit( -1 );}
{
obj_t aux_711;
if(INTEGERP(k_389)){
aux_711 = k_389;
}
 else {
bigloo_type_error_location_103___error(symbol1299___r4_vectors_6_8, string1287___r4_vectors_6_8, k_389, string1285___r4_vectors_6_8, BINT(((long)5333)));
exit( -1 );}
k_551 = (long)CINT(aux_711);
}
obj_552 = obj_390;
{
obj_t symbol1132_553;
symbol1132_553 = symbol1297___r4_vectors_6_8;
{
PUSH_TRACE(symbol1132_553);
BUNSPEC;
{
obj_t aux1131_554;
{
bool_t test1006_555;
{
long aux_719;
aux_719 = VECTOR_LENGTH(vector_550);
test1006_555 = BOUND_CHECK(k_551, aux_719);
}
if(test1006_555){
aux1131_554 = VECTOR_SET(vector_550, k_551, obj_552);
}
 else {
aux1131_554 = debug_error_location_199___error(string1298___r4_vectors_6_8, string1294___r4_vectors_6_8, BINT(k_551), string1295___r4_vectors_6_8, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1131_554;
}
}
}
}
}


/* vector-ref-ur */obj_t vector_ref_ur_84___r4_vectors_6_8(obj_t vector_11, long k_12)
{
{
obj_t symbol1134_556;
symbol1134_556 = symbol1300___r4_vectors_6_8;
{
PUSH_TRACE(symbol1134_556);
BUNSPEC;
{
obj_t aux1133_557;
aux1133_557 = VECTOR_REF(vector_11, k_12);
POP_TRACE();
return aux1133_557;
}
}
}
}


/* _vector-ref-ur1153 */obj_t _vector_ref_ur1153_88___r4_vectors_6_8(obj_t env_391, obj_t vector_392, obj_t k_393)
{
{
obj_t vector_558;
long k_559;
if(VECTORP(vector_392)){
vector_558 = vector_392;
}
 else {
bigloo_type_error_location_103___error(symbol1301___r4_vectors_6_8, string1291___r4_vectors_6_8, vector_392, string1285___r4_vectors_6_8, BINT(((long)5742)));
exit( -1 );}
{
obj_t aux_736;
if(INTEGERP(k_393)){
aux_736 = k_393;
}
 else {
bigloo_type_error_location_103___error(symbol1301___r4_vectors_6_8, string1287___r4_vectors_6_8, k_393, string1285___r4_vectors_6_8, BINT(((long)5742)));
exit( -1 );}
k_559 = (long)CINT(aux_736);
}
{
obj_t symbol1134_560;
symbol1134_560 = symbol1300___r4_vectors_6_8;
{
PUSH_TRACE(symbol1134_560);
BUNSPEC;
{
obj_t aux1133_561;
aux1133_561 = VECTOR_REF(vector_558, k_559);
POP_TRACE();
return aux1133_561;
}
}
}
}
}


/* vector-set-ur! */obj_t vector_set_ur__74___r4_vectors_6_8(obj_t vector_13, long k_14, obj_t obj_15)
{
{
obj_t symbol1136_562;
symbol1136_562 = symbol1302___r4_vectors_6_8;
{
PUSH_TRACE(symbol1136_562);
BUNSPEC;
{
obj_t aux1135_563;
aux1135_563 = VECTOR_SET(vector_13, k_14, obj_15);
POP_TRACE();
return aux1135_563;
}
}
}
}


/* _vector-set-ur!1154 */obj_t _vector_set_ur_1154_169___r4_vectors_6_8(obj_t env_394, obj_t vector_395, obj_t k_396, obj_t obj_397)
{
{
obj_t vector_564;
long k_565;
obj_t obj_566;
if(VECTORP(vector_395)){
vector_564 = vector_395;
}
 else {
bigloo_type_error_location_103___error(symbol1303___r4_vectors_6_8, string1291___r4_vectors_6_8, vector_395, string1285___r4_vectors_6_8, BINT(((long)6033)));
exit( -1 );}
{
obj_t aux_754;
if(INTEGERP(k_396)){
aux_754 = k_396;
}
 else {
bigloo_type_error_location_103___error(symbol1303___r4_vectors_6_8, string1287___r4_vectors_6_8, k_396, string1285___r4_vectors_6_8, BINT(((long)6033)));
exit( -1 );}
k_565 = (long)CINT(aux_754);
}
obj_566 = obj_397;
{
obj_t symbol1136_567;
symbol1136_567 = symbol1302___r4_vectors_6_8;
{
PUSH_TRACE(symbol1136_567);
BUNSPEC;
{
obj_t aux1135_568;
aux1135_568 = VECTOR_SET(vector_564, k_565, obj_566);
POP_TRACE();
return aux1135_568;
}
}
}
}
}


/* vector->list */obj_t vector__list_155___r4_vectors_6_8(obj_t vector_16)
{
{
obj_t symbol1138_363;
symbol1138_363 = symbol1304___r4_vectors_6_8;
{
PUSH_TRACE(symbol1138_363);
BUNSPEC;
{
obj_t aux1137_364;
{
long vlen_188;
vlen_188 = VECTOR_LENGTH(vector_16);
if((vlen_188==((long)0))){
aux1137_364 = BNIL;
}
 else {
long i_190;
obj_t acc_191;
i_190 = (vlen_188-((long)1));
acc_191 = BNIL;
loop_192:
if((i_190==((long)0))){
obj_t aux_770;
aux_770 = VECTOR_REF(vector_16, i_190);
aux1137_364 = MAKE_PAIR(aux_770, acc_191);
}
 else {
long arg1013_197;
obj_t arg1014_198;
arg1013_197 = (i_190-((long)1));
{
obj_t aux_774;
aux_774 = VECTOR_REF(vector_16, i_190);
arg1014_198 = MAKE_PAIR(aux_774, acc_191);
}
{
obj_t acc_778;
long i_777;
i_777 = arg1013_197;
acc_778 = arg1014_198;
acc_191 = acc_778;
i_190 = i_777;
goto loop_192;
}
}
}
}
POP_TRACE();
return aux1137_364;
}
}
}
}


/* _vector->list1155 */obj_t _vector__list1155_42___r4_vectors_6_8(obj_t env_398, obj_t vector_399)
{
{
obj_t aux_781;
if(VECTORP(vector_399)){
aux_781 = vector_399;
}
 else {
bigloo_type_error_location_103___error(symbol1305___r4_vectors_6_8, string1291___r4_vectors_6_8, vector_399, string1285___r4_vectors_6_8, BINT(((long)6334)));
exit( -1 );}
return vector__list_155___r4_vectors_6_8(aux_781);
}
}


/* list->vector */obj_t list__vector_101___r4_vectors_6_8(obj_t list_17)
{
{
obj_t symbol1140_365;
symbol1140_365 = symbol1306___r4_vectors_6_8;
{
PUSH_TRACE(symbol1140_365);
BUNSPEC;
{
obj_t aux1139_366;
{
long len_200;
len_200 = list_length(list_17);
{
obj_t vec_201;
vec_201 = make_vector(len_200, BNIL);
{
{
long i_202;
obj_t l_203;
i_202 = ((long)0);
l_203 = list_17;
loop_204:
if((i_202==len_200)){
aux1139_366 = vec_201;
}
 else {
{
obj_t arg1017_206;
{
obj_t pair_340;
if(PAIRP(l_203)){
pair_340 = l_203;
}
 else {
bigloo_type_error_location_103___error(symbol1306___r4_vectors_6_8, string1284___r4_vectors_6_8, l_203, string1285___r4_vectors_6_8, BINT(((long)7020)));
exit( -1 );}
arg1017_206 = CAR(pair_340);
}
VECTOR_SET(vec_201, i_202, arg1017_206);
}
{
long arg1018_207;
obj_t arg1019_208;
arg1018_207 = (i_202+((long)1));
{
obj_t pair_346;
if(PAIRP(l_203)){
pair_346 = l_203;
}
 else {
bigloo_type_error_location_103___error(symbol1306___r4_vectors_6_8, string1284___r4_vectors_6_8, l_203, string1285___r4_vectors_6_8, BINT(((long)7047)));
exit( -1 );}
arg1019_208 = CDR(pair_346);
}
{
obj_t l_808;
long i_807;
i_807 = arg1018_207;
l_808 = arg1019_208;
l_203 = l_808;
i_202 = i_807;
goto loop_204;
}
}
}
}
}
}
}
POP_TRACE();
return aux1139_366;
}
}
}
}


/* _list->vector */obj_t _list__vector_50___r4_vectors_6_8(obj_t env_400, obj_t list_401)
{
return list__vector_101___r4_vectors_6_8(list_401);
}


/* vector-fill! */obj_t vector_fill__80___r4_vectors_6_8(obj_t vector_18, obj_t fill_19)
{
{
obj_t symbol1142_367;
symbol1142_367 = symbol1307___r4_vectors_6_8;
{
PUSH_TRACE(symbol1142_367);
BUNSPEC;
{
obj_t aux1141_368;
{
long aux_812;
aux_812 = VECTOR_LENGTH(vector_18);
aux1141_368 = fill_vector(vector_18, aux_812, fill_19);
}
POP_TRACE();
return aux1141_368;
}
}
}
}


/* _vector-fill!1156 */obj_t _vector_fill_1156_202___r4_vectors_6_8(obj_t env_402, obj_t vector_403, obj_t fill_404)
{
{
obj_t aux_816;
if(VECTORP(vector_403)){
aux_816 = vector_403;
}
 else {
bigloo_type_error_location_103___error(symbol1308___r4_vectors_6_8, string1291___r4_vectors_6_8, vector_403, string1285___r4_vectors_6_8, BINT(((long)7283)));
exit( -1 );}
return vector_fill__80___r4_vectors_6_8(aux_816, fill_404);
}
}


/* vector-tag */long vector_tag_145___r4_vectors_6_8(obj_t vector_20)
{
{
obj_t symbol1144_569;
symbol1144_569 = symbol1309___r4_vectors_6_8;
{
PUSH_TRACE(symbol1144_569);
BUNSPEC;
{
long aux1143_570;
aux1143_570 = VECTOR_TAG(vector_20);
POP_TRACE();
return aux1143_570;
}
}
}
}


/* _vector-tag1157 */obj_t _vector_tag1157_249___r4_vectors_6_8(obj_t env_405, obj_t vector_406)
{
{
long aux_826;
{
obj_t vector_571;
if(VECTORP(vector_406)){
vector_571 = vector_406;
}
 else {
bigloo_type_error_location_103___error(symbol1310___r4_vectors_6_8, string1291___r4_vectors_6_8, vector_406, string1285___r4_vectors_6_8, BINT(((long)7597)));
exit( -1 );}
{
obj_t symbol1144_572;
symbol1144_572 = symbol1309___r4_vectors_6_8;
{
PUSH_TRACE(symbol1144_572);
BUNSPEC;
{
long aux1143_573;
aux1143_573 = VECTOR_TAG(vector_571);
POP_TRACE();
aux_826 = aux1143_573;
}
}
}
}
return BINT(aux_826);
}
}


/* vector-tag-set! */obj_t vector_tag_set__158___r4_vectors_6_8(obj_t vector_21, long tag_22)
{
{
obj_t symbol1146_574;
symbol1146_574 = symbol1311___r4_vectors_6_8;
{
PUSH_TRACE(symbol1146_574);
BUNSPEC;
{
obj_t aux1145_575;
aux1145_575 = VECTOR_TAG_SET(vector_21, tag_22);
POP_TRACE();
return aux1145_575;
}
}
}
}


/* _vector-tag-set!1158 */obj_t _vector_tag_set_1158_236___r4_vectors_6_8(obj_t env_407, obj_t vector_408, obj_t tag_409)
{
{
obj_t vector_576;
long tag_577;
if(VECTORP(vector_408)){
vector_576 = vector_408;
}
 else {
bigloo_type_error_location_103___error(symbol1312___r4_vectors_6_8, string1291___r4_vectors_6_8, vector_408, string1285___r4_vectors_6_8, BINT(((long)7881)));
exit( -1 );}
{
obj_t aux_844;
if(INTEGERP(tag_409)){
aux_844 = tag_409;
}
 else {
bigloo_type_error_location_103___error(symbol1312___r4_vectors_6_8, string1287___r4_vectors_6_8, tag_409, string1285___r4_vectors_6_8, BINT(((long)7881)));
exit( -1 );}
tag_577 = (long)CINT(aux_844);
}
{
obj_t symbol1146_578;
symbol1146_578 = symbol1311___r4_vectors_6_8;
{
PUSH_TRACE(symbol1146_578);
BUNSPEC;
{
obj_t aux1145_579;
aux1145_579 = VECTOR_TAG_SET(vector_576, tag_577);
POP_TRACE();
return aux1145_579;
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_vectors_6_8()
{
{
obj_t symbol1148_373;
symbol1148_373 = symbol1313___r4_vectors_6_8;
{
PUSH_TRACE(symbol1148_373);
BUNSPEC;
{
obj_t aux1147_374;
aux1147_374 = module_initialization_70___error(((long)0), "__R4_VECTORS_6_8");
POP_TRACE();
return aux1147_374;
}
}
}
}

