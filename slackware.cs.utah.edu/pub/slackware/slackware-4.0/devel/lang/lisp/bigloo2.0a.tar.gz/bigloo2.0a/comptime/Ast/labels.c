/*===========================================================================*/
/*   (Ast/labels.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_ast_labels();
static obj_t allocate_sfuns_248_ast_labels(obj_t, obj_t);
extern obj_t find_location_loc_243_tools_location(obj_t, obj_t);
extern obj_t leave_function_170_tools_error();
extern bool_t user_symbol__147_ast_ident(obj_t);
extern obj_t _obj__252_type_cache;
extern obj_t last_pair_93___r4_pairs_and_lists_6_3(obj_t);
extern obj_t module_initialization_70_ast_labels(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___dsssl(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_ast_labels();
extern obj_t normalize_progn_143_tools_progn(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _user_error_251_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_ast_labels();
static obj_t toplevel_init_63_ast_labels();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern local_t make_local_sfun_184_ast_local(obj_t, type_t, sfun_t);
extern obj_t sfun_ast_var;
extern int arity_tools_args(obj_t);
extern obj_t dsssl_args___args_list_201_tools_dsssl(obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
extern node_t error_sexp__node_157_ast_sexp(obj_t, obj_t, obj_t);
extern obj_t enter_function_81_tools_error(obj_t);
extern local_t make_user_local_svar_134_ast_local(obj_t, type_t);
static obj_t labels_binding_77_ast_labels(obj_t, obj_t, obj_t, obj_t);
extern let_fun_218_t labels__node_197_ast_labels(obj_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t make_dsssl_function_prelude_58___dsssl(obj_t, obj_t, obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_labels = BUNSPEC;
static obj_t cnst_init_137_ast_labels();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t _labels__node1658_109_ast_labels(obj_t, obj_t, obj_t, obj_t, obj_t);
extern local_t make_user_local_sfun_221_ast_local(obj_t, type_t, sfun_t);
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(labels__node_env_244_ast_labels, _labels__node1658_109_ast_labels1674, _labels__node1658_109_ast_labels, 0L, 4);
extern obj_t user_error_env_101_tools_error;
DEFINE_STRING(string1667_ast_labels, string1667_ast_labels1675, "VALUE PLAIN ", 12);
DEFINE_STRING(string1666_ast_labels, string1666_ast_labels1676, "Illegal `labels' form", 21);
DEFINE_STRING(string1665_ast_labels, string1665_ast_labels1677, "Illegal `binding' form", 22);
DEFINE_STRING(string1664_ast_labels, string1664_ast_labels1678, "Illegal formal type", 19);
DEFINE_STRING(string1663_ast_labels, string1663_ast_labels1679, "Illegal `labels' expression", 27);


/* module-initialization */ obj_t 
module_initialization_70_ast_labels(long checksum_1370, char *from_1371)
{
   if (CBOOL(require_initialization_114_ast_labels))
     {
	require_initialization_114_ast_labels = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_labels();
	cnst_init_137_ast_labels();
	imported_modules_init_94_ast_labels();
	method_init_76_ast_labels();
	toplevel_init_63_ast_labels();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_labels()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_LABELS");
   module_initialization_70___object(((long) 0), "AST_LABELS");
   module_initialization_70___reader(((long) 0), "AST_LABELS");
   module_initialization_70___dsssl(((long) 0), "AST_LABELS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_labels()
{
   {
      obj_t cnst_port_138_1362;
      cnst_port_138_1362 = open_input_string(string1667_ast_labels);
      {
	 long i_1363;
	 i_1363 = ((long) 1);
       loop_1364:
	 {
	    bool_t test1668_1365;
	    test1668_1365 = (i_1363 == ((long) -1));
	    if (test1668_1365)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1669_1366;
		    {
		       obj_t list1670_1367;
		       {
			  obj_t arg1672_1368;
			  arg1672_1368 = BNIL;
			  list1670_1367 = MAKE_PAIR(cnst_port_138_1362, arg1672_1368);
		       }
		       arg1669_1366 = read___reader(list1670_1367);
		    }
		    CNST_TABLE_SET(i_1363, arg1669_1366);
		 }
		 {
		    int aux_1369;
		    {
		       long aux_1390;
		       aux_1390 = (i_1363 - ((long) 1));
		       aux_1369 = (int) (aux_1390);
		    }
		    {
		       long i_1393;
		       i_1393 = (long) (aux_1369);
		       i_1363 = i_1393;
		       goto loop_1364;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_labels()
{
   return BUNSPEC;
}


/* labels->node */ let_fun_218_t 
labels__node_197_ast_labels(obj_t exp_15, obj_t stack_16, obj_t loc_17, obj_t site_18)
{
   {
      obj_t loc_733;
      loc_733 = find_location_loc_243_tools_location(exp_15, loc_17);
      {
	 obj_t bindings_734;
	 obj_t body_735;
	 if (PAIRP(exp_15))
	   {
	      obj_t cdr_128_145_740;
	      cdr_128_145_740 = CDR(exp_15);
	      if (PAIRP(cdr_128_145_740))
		{
		   obj_t car_131_9_742;
		   car_131_9_742 = CAR(cdr_128_145_740);
		   if (PAIRP(car_131_9_742))
		     {
			bindings_734 = car_131_9_742;
			body_735 = CDR(cdr_128_145_740);
			{
			   obj_t locals_745;
			   locals_745 = allocate_sfuns_248_ast_labels(bindings_734, loc_733);
			   {
			      obj_t new_stack_37_746;
			      new_stack_37_746 = append_2_18___r4_pairs_and_lists_6_3(locals_745, stack_16);
			      {
				 node_t body_747;
				 {
				    obj_t arg1483_762;
				    arg1483_762 = normalize_progn_143_tools_progn(body_735);
				    body_747 = sexp__node_235_ast_sexp(arg1483_762, new_stack_37_746, loc_733, site_18);
				 }
				 {
				    obj_t loc_748;
				    loc_748 = find_location_loc_243_tools_location(exp_15, loc_733);
				    {
				       {
					  obj_t ll1435_749;
					  obj_t ll1436_750;
					  ll1435_749 = locals_745;
					  ll1436_750 = bindings_734;
					lname1437_751:
					  if (NULLP(ll1435_749))
					    {
					       ((bool_t) 1);
					    }
					  else
					    {
					       labels_binding_77_ast_labels(CAR(ll1435_749), CAR(ll1436_750), new_stack_37_746, loc_748);
					       {
						  obj_t ll1436_1416;
						  obj_t ll1435_1414;
						  ll1435_1414 = CDR(ll1435_749);
						  ll1436_1416 = CDR(ll1436_750);
						  ll1436_750 = ll1436_1416;
						  ll1435_749 = ll1435_1414;
						  goto lname1437_751;
					       }
					    }
				       }
				       {
					  type_t arg1478_758;
					  arg1478_758 = (((node_t) CREF(body_747))->type);
					  {
					     let_fun_218_t res1656_1229;
					     {
						obj_t key_1216;
						key_1216 = BINT(((long) -1));
						{
						   let_fun_218_t new1351_1219;
						   new1351_1219 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
						   {
						      long arg1575_1220;
						      arg1575_1220 = class_num_218___object(let_fun_218_ast_node);
						      {
							 obj_t obj_1227;
							 obj_1227 = (obj_t) (new1351_1219);
							 (((obj_t) CREF(obj_1227))->header = MAKE_HEADER(arg1575_1220, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_1424;
						      aux_1424 = (object_t) (new1351_1219);
						      OBJECT_WIDENING_SET(aux_1424, BFALSE);
						   }
						   ((((let_fun_218_t) CREF(new1351_1219))->loc) = ((obj_t) loc_748), BUNSPEC);
						   ((((let_fun_218_t) CREF(new1351_1219))->type) = ((type_t) arg1478_758), BUNSPEC);
						   ((((let_fun_218_t) CREF(new1351_1219))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
						   ((((let_fun_218_t) CREF(new1351_1219))->key) = ((obj_t) key_1216), BUNSPEC);
						   ((((let_fun_218_t) CREF(new1351_1219))->locals) = ((obj_t) locals_745), BUNSPEC);
						   ((((let_fun_218_t) CREF(new1351_1219))->body) = ((node_t) body_747), BUNSPEC);
						   res1656_1229 = new1351_1219;
						}
					     }
					     return res1656_1229;
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		   else
		     {
			node_t aux_1434;
		      tag_121_151_737:
			aux_1434 = error_sexp__node_157_ast_sexp(string1663_ast_labels, exp_15, loc_733);
			return (let_fun_218_t) (aux_1434);
		     }
		}
	      else
		{
		   node_t aux_1437;
		   goto tag_121_151_737;
		   return (let_fun_218_t) (aux_1437);
		}
	   }
	 else
	   {
	      node_t aux_1439;
	      goto tag_121_151_737;
	      return (let_fun_218_t) (aux_1439);
	   }
      }
   }
}


/* _labels->node1658 */ obj_t 
_labels__node1658_109_ast_labels(obj_t env_1351, obj_t exp_1352, obj_t stack_1353, obj_t loc_1354, obj_t site_1355)
{
   {
      let_fun_218_t aux_1441;
      aux_1441 = labels__node_197_ast_labels(exp_1352, stack_1353, loc_1354, site_1355);
      return (obj_t) (aux_1441);
   }
}


/* allocate-sfuns */ obj_t 
allocate_sfuns_248_ast_labels(obj_t bindings_19, obj_t loc_20)
{
   {
      obj_t bindings_763;
      obj_t res_764;
      bindings_763 = bindings_19;
      res_764 = BNIL;
    loop_765:
      if (NULLP(bindings_763))
	{
	   return reverse__39___r4_pairs_and_lists_6_3(res_764);
	}
      else
	{
	   obj_t fun_768;
	   obj_t args_769;
	   obj_t body_770;
	   {
	      obj_t e_139_15_773;
	      e_139_15_773 = CAR(bindings_763);
	      if (PAIRP(e_139_15_773))
		{
		   obj_t car_146_142_775;
		   obj_t cdr_147_183_776;
		   car_146_142_775 = CAR(e_139_15_773);
		   cdr_147_183_776 = CDR(e_139_15_773);
		   if (SYMBOLP(car_146_142_775))
		     {
			if (PAIRP(cdr_147_183_776))
			  {
			     fun_768 = car_146_142_775;
			     args_769 = CAR(cdr_147_183_776);
			     body_770 = CDR(cdr_147_183_776);
			     {
				obj_t id_type_89_781;
				id_type_89_781 = parse_id_241_ast_ident(fun_768);
				{
				   obj_t id_782;
				   id_782 = CAR(id_type_89_781);
				   {
				      obj_t type_783;
				      type_783 = CDR(id_type_89_781);
				      {
					 int arity_784;
					 arity_784 = arity_tools_args(args_769);
					 {
					    obj_t formals_785;
					    {
					       obj_t l1439_827;
					       l1439_827 = dsssl_args___args_list_201_tools_dsssl(args_769);
					       if (NULLP(l1439_827))
						 {
						    formals_785 = BNIL;
						 }
					       else
						 {
						    obj_t head1441_829;
						    {
						       obj_t arg1536_840;
						       arg1536_840 = parse_id_241_ast_ident(CAR(l1439_827));
						       head1441_829 = MAKE_PAIR(arg1536_840, BNIL);
						    }
						    {
						       obj_t l1439_830;
						       obj_t tail1442_831;
						       l1439_830 = CDR(l1439_827);
						       tail1442_831 = head1441_829;
						     lname1440_832:
						       if (NULLP(l1439_830))
							 {
							    formals_785 = head1441_829;
							 }
						       else
							 {
							    obj_t newtail1443_835;
							    {
							       obj_t arg1533_837;
							       arg1533_837 = parse_id_241_ast_ident(CAR(l1439_830));
							       newtail1443_835 = MAKE_PAIR(arg1533_837, BNIL);
							    }
							    SET_CDR(tail1442_831, newtail1443_835);
							    {
							       obj_t tail1442_1474;
							       obj_t l1439_1472;
							       l1439_1472 = CDR(l1439_830);
							       tail1442_1474 = newtail1443_835;
							       tail1442_831 = tail1442_1474;
							       l1439_830 = l1439_1472;
							       goto lname1440_832;
							    }
							 }
						    }
						 }
					    }
					    {
					       {
						  bool_t test1491_786;
						  {
						     bool_t test_1476;
						     {
							long aux_1477;
							aux_1477 = (long) (arity_784);
							test_1476 = (aux_1477 >= ((long) 0));
						     }
						     if (test_1476)
						       {
							  test1491_786 = ((bool_t) 1);
						       }
						     else
						       {
							  obj_t larg_822;
							  {
							     obj_t aux_1480;
							     aux_1480 = last_pair_93___r4_pairs_and_lists_6_3(formals_785);
							     larg_822 = CAR(aux_1480);
							  }
							  {
							     obj_t type_823;
							     type_823 = CDR(larg_822);
							     {
								{
								   bool_t test1526_824;
								   {
								      obj_t obj2_1258;
								      obj2_1258 = _obj__252_type_cache;
								      test1526_824 = (type_823 == obj2_1258);
								   }
								   if (test1526_824)
								     {
									test1491_786 = ((bool_t) 1);
								     }
								   else
								     {
									bool_t test1527_825;
									{
									   obj_t obj2_1260;
									   obj2_1260 = ____74_type_cache;
									   test1527_825 = (type_823 == obj2_1260);
									}
									if (test1527_825)
									  {
									     {
										obj_t obj_1262;
										obj_1262 = _obj__252_type_cache;
										SET_CDR(larg_822, obj_1262);
									     }
									     test1491_786 = ((bool_t) 1);
									  }
									else
									  {
									     test1491_786 = ((bool_t) 0);
									  }
								     }
								}
							     }
							  }
						       }
						  }
						  if (test1491_786)
						    {
						       obj_t args_787;
						       if (NULLP(formals_785))
							 {
							    args_787 = BNIL;
							 }
						       else
							 {
							    obj_t head1446_801;
							    head1446_801 = MAKE_PAIR(BNIL, BNIL);
							    {
							       obj_t l1444_802;
							       obj_t tail1447_803;
							       l1444_802 = formals_785;
							       tail1447_803 = head1446_801;
							     lname1445_804:
							       if (NULLP(l1444_802))
								 {
								    args_787 = CDR(head1446_801);
								 }
							       else
								 {
								    obj_t newtail1448_806;
								    {
								       local_t arg1510_808;
								       {
									  obj_t f_810;
									  f_810 = CAR(l1444_802);
									  {
									     bool_t test1512_811;
									     test1512_811 = user_symbol__147_ast_ident(CAR(f_810));
									     if (test1512_811)
									       {
										  type_t aux_1500;
										  {
										     obj_t aux_1502;
										     aux_1502 = CDR(f_810);
										     aux_1500 = (type_t) (aux_1502);
										  }
										  arg1510_808 = make_user_local_svar_134_ast_local(CAR(f_810), aux_1500);
									       }
									     else
									       {
										  type_t aux_1506;
										  {
										     obj_t aux_1508;
										     aux_1508 = CDR(f_810);
										     aux_1506 = (type_t) (aux_1508);
										  }
										  arg1510_808 = make_local_svar_140_ast_local(CAR(f_810), aux_1506);
									       }
									  }
								       }
								       {
									  obj_t aux_1512;
									  aux_1512 = (obj_t) (arg1510_808);
									  newtail1448_806 = MAKE_PAIR(aux_1512, BNIL);
								       }
								    }
								    SET_CDR(tail1447_803, newtail1448_806);
								    {
								       obj_t tail1447_1518;
								       obj_t l1444_1516;
								       l1444_1516 = CDR(l1444_802);
								       tail1447_1518 = newtail1448_806;
								       tail1447_803 = tail1447_1518;
								       l1444_802 = l1444_1516;
								       goto lname1445_804;
								    }
								 }
							    }
							 }
						       {
							  sfun_t sfun_788;
							  {
							     obj_t arg1501_796;
							     obj_t arg1503_798;
							     arg1501_796 = CNST_TABLE_REF(((long) 0));
							     arg1503_798 = find_location_loc_243_tools_location(body_770, loc_20);
							     {
								sfun_t res1657_1307;
								{
								   long arity_1279;
								   obj_t predicate_of_78_1281;
								   obj_t stack_allocator_172_1282;
								   arity_1279 = (long) (arity_784);
								   predicate_of_78_1281 = BFALSE;
								   stack_allocator_172_1282 = BFALSE;
								   {
								      sfun_t new1114_1291;
								      new1114_1291 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
								      {
									 long arg1638_1292;
									 arg1638_1292 = class_num_218___object(sfun_ast_var);
									 {
									    obj_t obj_1305;
									    obj_1305 = (obj_t) (new1114_1291);
									    (((obj_t) CREF(obj_1305))->header = MAKE_HEADER(arg1638_1292, 0), BUNSPEC);
									 }
								      }
								      {
									 object_t aux_1526;
									 aux_1526 = (object_t) (new1114_1291);
									 OBJECT_WIDENING_SET(aux_1526, predicate_of_78_1281);
								      }
								      ((((sfun_t) CREF(new1114_1291))->arity) = ((long) arity_1279), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->predicate_of_78) = ((obj_t) predicate_of_78_1281), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->stack_allocator_172) = ((obj_t) stack_allocator_172_1282), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->top__138) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->the_closure_238) = ((obj_t) BUNSPEC), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->property) = ((obj_t) BNIL), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->args) = ((obj_t) args_787), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->body) = ((obj_t) BUNSPEC), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->class) = ((obj_t) arg1501_796), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->dsssl_keywords_243) = ((obj_t) BNIL), BUNSPEC);
								      ((((sfun_t) CREF(new1114_1291))->loc) = ((obj_t) arg1503_798), BUNSPEC);
								      res1657_1307 = new1114_1291;
								   }
								}
								sfun_788 = res1657_1307;
							     }
							  }
							  {
							     local_t fun_789;
							     {
								bool_t test1497_792;
								test1497_792 = user_symbol__147_ast_ident(id_782);
								if (test1497_792)
								  {
								     fun_789 = make_user_local_sfun_221_ast_local(id_782, (type_t) (type_783), sfun_788);
								  }
								else
								  {
								     fun_789 = make_local_sfun_184_ast_local(id_782, (type_t) (type_783), sfun_788);
								  }
							     }
							     {
								{
								   obj_t arg1494_790;
								   obj_t arg1496_791;
								   arg1494_790 = CDR(bindings_763);
								   {
								      obj_t aux_1548;
								      aux_1548 = (obj_t) (fun_789);
								      arg1496_791 = MAKE_PAIR(aux_1548, res_764);
								   }
								   {
								      obj_t res_1552;
								      obj_t bindings_1551;
								      bindings_1551 = arg1494_790;
								      res_1552 = arg1496_791;
								      res_764 = res_1552;
								      bindings_763 = bindings_1551;
								      goto loop_765;
								   }
								}
							     }
							  }
						       }
						    }
						  else
						    {
						       error_sexp__node_157_ast_sexp(string1664_ast_labels, CAR(bindings_763), loc_20);
						       return BNIL;
						    }
					       }
					    }
					 }
				      }
				   }
				}
			     }
			  }
			else
			  {
			   tag_138_212_772:
			     error_sexp__node_157_ast_sexp(string1665_ast_labels, CAR(bindings_763), loc_20);
			     return BNIL;
			  }
		     }
		   else
		     {
			goto tag_138_212_772;
		     }
		}
	      else
		{
		   goto tag_138_212_772;
		}
	   }
	}
   }
}


/* labels-binding */ obj_t 
labels_binding_77_ast_labels(obj_t local_21, obj_t binding_22, obj_t stack_23, obj_t loc_24)
{
   {
      obj_t args_845;
      obj_t body_846;
      if (PAIRP(binding_22))
	{
	   obj_t cdr_165_174_851;
	   cdr_165_174_851 = CDR(binding_22);
	   if (PAIRP(cdr_165_174_851))
	     {
		args_845 = CAR(cdr_165_174_851);
		body_846 = CDR(cdr_165_174_851);
		{
		   obj_t aux_1564;
		   {
		      local_t obj_1318;
		      obj_1318 = (local_t) (local_21);
		      aux_1564 = (((local_t) CREF(obj_1318))->id);
		   }
		   enter_function_81_tools_error(aux_1564);
		}
		{
		   obj_t loc_856;
		   loc_856 = find_location_loc_243_tools_location(binding_22, loc_24);
		   {
		      node_t body_857;
		      {
			 obj_t arg1552_859;
			 obj_t arg1553_860;
			 obj_t arg1554_861;
			 {
			    obj_t arg1555_862;
			    obj_t arg1556_863;
			    {
			       local_t obj_1319;
			       obj_1319 = (local_t) (local_21);
			       arg1555_862 = (((local_t) CREF(obj_1319))->id);
			    }
			    arg1556_863 = normalize_progn_143_tools_progn(body_846);
			    arg1552_859 = make_dsssl_function_prelude_58___dsssl(arg1555_862, args_845, arg1556_863, user_error_env_101_tools_error);
			 }
			 {
			    obj_t aux_1573;
			    {
			       sfun_t obj_1321;
			       {
				  value_t aux_1574;
				  {
				     local_t obj_1320;
				     obj_1320 = (local_t) (local_21);
				     aux_1574 = (((local_t) CREF(obj_1320))->value);
				  }
				  obj_1321 = (sfun_t) (aux_1574);
			       }
			       aux_1573 = (((sfun_t) CREF(obj_1321))->args);
			    }
			    arg1553_860 = append_2_18___r4_pairs_and_lists_6_3(aux_1573, stack_23);
			 }
			 arg1554_861 = CNST_TABLE_REF(((long) 1));
			 body_857 = sexp__node_235_ast_sexp(arg1552_859, arg1553_860, loc_856, arg1554_861);
		      }
		      {
			 {
			    sfun_t obj_1323;
			    obj_t val1135_1324;
			    {
			       value_t aux_1582;
			       {
				  local_t obj_1322;
				  obj_1322 = (local_t) (local_21);
				  aux_1582 = (((local_t) CREF(obj_1322))->value);
			       }
			       obj_1323 = (sfun_t) (aux_1582);
			    }
			    val1135_1324 = (obj_t) (body_857);
			    ((((sfun_t) CREF(obj_1323))->body) = ((obj_t) val1135_1324), BUNSPEC);
			 }
			 return leave_function_170_tools_error();
		      }
		   }
		}
	     }
	   else
	     {
		node_t aux_1591;
	      tag_158_23_848:
		aux_1591 = error_sexp__node_157_ast_sexp(string1666_ast_labels, binding_22, loc_24);
		return (obj_t) (aux_1591);
	     }
	}
      else
	{
	   node_t aux_1594;
	   goto tag_158_23_848;
	   return (obj_t) (aux_1594);
	}
   }
}


/* method-init */ obj_t 
method_init_76_ast_labels()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_labels()
{
   module_initialization_70_type_type(((long) 0), "AST_LABELS");
   module_initialization_70_ast_var(((long) 0), "AST_LABELS");
   module_initialization_70_ast_node(((long) 0), "AST_LABELS");
   module_initialization_70_tools_trace(((long) 0), "AST_LABELS");
   module_initialization_70_tools_error(((long) 0), "AST_LABELS");
   module_initialization_70_tools_progn(((long) 0), "AST_LABELS");
   module_initialization_70_tools_args(((long) 0), "AST_LABELS");
   module_initialization_70_tools_location(((long) 0), "AST_LABELS");
   module_initialization_70_tools_dsssl(((long) 0), "AST_LABELS");
   module_initialization_70_type_cache(((long) 0), "AST_LABELS");
   module_initialization_70_ast_sexp(((long) 0), "AST_LABELS");
   module_initialization_70_ast_ident(((long) 0), "AST_LABELS");
   return module_initialization_70_ast_local(((long) 0), "AST_LABELS");
}
