/*===========================================================================*/
/*   (Ieee/boolean.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern bool_t not___r4_booleans_6_1(obj_t);
static obj_t _boolean__157___r4_booleans_6_1(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
static obj_t symbol1096___r4_booleans_6_1 = BUNSPEC;
static obj_t symbol1095___r4_booleans_6_1 = BUNSPEC;
extern bool_t boolean__35___r4_booleans_6_1(obj_t);
static obj_t _not___r4_booleans_6_1(obj_t, obj_t);
static obj_t require_initialization_114___r4_booleans_6_1 = BUNSPEC;
static obj_t cnst_init_137___r4_booleans_6_1();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( boolean__env_44___r4_booleans_6_1, _boolean__157___r4_booleans_6_11098, _boolean__157___r4_booleans_6_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( not_env_16___r4_booleans_6_1, _not___r4_booleans_6_11099, _not___r4_booleans_6_1, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r4_booleans_6_1(long checksum_222, char * from_223)
{
if(CBOOL(require_initialization_114___r4_booleans_6_1)){
require_initialization_114___r4_booleans_6_1 = BBOOL(((bool_t)0));
cnst_init_137___r4_booleans_6_1();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_booleans_6_1()
{
symbol1095___r4_booleans_6_1 = string_to_symbol("NOT");
return (symbol1096___r4_booleans_6_1 = string_to_symbol("BOOLEAN?"),
BUNSPEC);
}


/* not */bool_t not___r4_booleans_6_1(obj_t obj_1)
{
{
obj_t symbol1092_212;
symbol1092_212 = symbol1095___r4_booleans_6_1;
{
PUSH_TRACE(symbol1092_212);
BUNSPEC;
{
bool_t aux1091_213;
if(CBOOL(obj_1)){
aux1091_213 = ((bool_t)0);
}
 else {
aux1091_213 = ((bool_t)1);
}
POP_TRACE();
return aux1091_213;
}
}
}
}


/* _not */obj_t _not___r4_booleans_6_1(obj_t env_208, obj_t obj_209)
{
{
bool_t aux_234;
{
obj_t obj_214;
obj_214 = obj_209;
{
obj_t symbol1092_215;
symbol1092_215 = symbol1095___r4_booleans_6_1;
{
PUSH_TRACE(symbol1092_215);
BUNSPEC;
{
bool_t aux1091_216;
if(CBOOL(obj_214)){
aux1091_216 = ((bool_t)0);
}
 else {
aux1091_216 = ((bool_t)1);
}
POP_TRACE();
aux_234 = aux1091_216;
}
}
}
}
return BBOOL(aux_234);
}
}


/* boolean? */bool_t boolean__35___r4_booleans_6_1(obj_t obj_2)
{
{
obj_t symbol1094_217;
symbol1094_217 = symbol1096___r4_booleans_6_1;
{
PUSH_TRACE(symbol1094_217);
BUNSPEC;
{
bool_t aux1093_218;
aux1093_218 = BOOLEANP(obj_2);
POP_TRACE();
return aux1093_218;
}
}
}
}


/* _boolean? */obj_t _boolean__157___r4_booleans_6_1(obj_t env_210, obj_t obj_211)
{
{
bool_t aux_243;
{
obj_t obj_219;
obj_219 = obj_211;
{
obj_t symbol1094_220;
symbol1094_220 = symbol1096___r4_booleans_6_1;
{
PUSH_TRACE(symbol1094_220);
BUNSPEC;
{
bool_t aux1093_221;
aux1093_221 = BOOLEANP(obj_219);
POP_TRACE();
aux_243 = aux1093_221;
}
}
}
}
return BBOOL(aux_243);
}
}

