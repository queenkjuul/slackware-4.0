/*===========================================================================*/
/*   (Eval/eval.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
static obj_t _expand_define_pattern_119___eval(obj_t, obj_t);
static obj_t _expand_define_hygien_macro_7___eval(obj_t, obj_t, obj_t);
static obj_t rhandler1079___eval(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t interaction_environment_31___eval();
extern bool_t reset_eof(obj_t);
static obj_t rhandler1062___eval(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1049___eval(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _prompt__73___eval = BUNSPEC;
static obj_t rhandler1041___eval(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t command_line_67___os();
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t rhandler1033___eval(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1025___eval(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1017___eval(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t evmeaning_notify_error_24___evmeaning(obj_t, obj_t, obj_t);
static obj_t _bigloo_exit_78___eval(obj_t, obj_t);
extern obj_t current_output_port;
static obj_t _imported_files__212___eval = BUNSPEC;
static obj_t body1080___eval(obj_t);
static obj_t body1063___eval(obj_t);
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t body1050___eval(obj_t);
static obj_t _quit___eval(obj_t);
static obj_t _interaction_environment_35___eval(obj_t);
static obj_t body1042___eval(obj_t);
static obj_t body1034___eval(obj_t);
static obj_t body1026___eval(obj_t);
static obj_t body1018___eval(obj_t);
extern obj_t expand_define_expander_27___eval(obj_t, obj_t);
static obj_t _expand_define_expander_206___eval(obj_t, obj_t, obj_t);
extern obj_t current_error_port;
extern obj_t exitd_top;
static obj_t _load___eval(obj_t, obj_t);
obj_t _load_path__54___eval = BUNSPEC;
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63___eval();
extern obj_t expand_syntax_236___r5_macro_4_3_init(obj_t);
extern obj_t install_all_expanders__168___install_expanders();
extern obj_t expand___expand(obj_t);
extern obj_t replace__160___progn(obj_t, obj_t);
extern obj_t print___r4_output_6_10_3(obj_t);
static obj_t handling_function1581___eval(obj_t, obj_t, obj_t);
extern obj_t module_declaration__32___eval(obj_t);
extern obj_t extend_r_macro_env_37___match_normalize(obj_t, obj_t);
static obj_t _repl___eval(obj_t);
extern obj_t evmeaning_reset_error__111___evmeaning();
static obj_t lambda1340___eval(obj_t, obj_t, obj_t);
extern obj_t signal___os(int, obj_t);
extern obj_t get_prompter_227___eval();
static bool_t include__198___eval(obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t install_expander_245___macro(obj_t, obj_t);
static obj_t _eval___eval(obj_t, obj_t, obj_t);
extern obj_t current_input_port;
static obj_t lambda1268___eval(obj_t, obj_t, obj_t);
static obj_t _expand_define_macro_10___eval(obj_t, obj_t, obj_t);
static obj_t _loadq___eval(obj_t, obj_t);
static obj_t _loada___eval(obj_t, obj_t);
static obj_t destructure___eval(obj_t, obj_t, obj_t);
static obj_t handling_function1341___eval(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1620___eval(obj_t, obj_t);
obj_t _nil__217___eval = BUNSPEC;
extern obj_t quit___eval();
static obj_t arg1583___eval(obj_t);
static obj_t arg1582___eval(obj_t);
extern obj_t notify_assert_fail_37___eval(obj_t, obj_t, obj_t);
static obj_t lambda1092___eval(obj_t, obj_t);
static obj_t handling_function1269___eval(obj_t, obj_t, obj_t, obj_t);
obj_t _user_pass__208___eval = BUNSPEC;
extern obj_t evmeaning___evmeaning(obj_t, obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t find_loc_64___evcompile(obj_t, obj_t);
static obj_t find_file_173___eval(obj_t);
static obj_t handling_function1235___eval(obj_t, obj_t, obj_t, obj_t);
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t handling_function1174___eval(obj_t, obj_t, obj_t, obj_t);
static obj_t loadv___eval(obj_t, bool_t);
static obj_t _afile_list__205___eval = BUNSPEC;
extern obj_t loadq___eval(obj_t);
static obj_t _notify_assert_fail_157___eval(obj_t, obj_t, obj_t, obj_t);
static obj_t handling_function1148___eval(obj_t, obj_t, obj_t);
extern obj_t loada___eval(obj_t);
extern obj_t load___eval(obj_t);
static obj_t handling_function1138___eval(obj_t, obj_t, obj_t);
static obj_t handling_function1123___eval();
static obj_t handling_function1122___eval();
static obj_t handling_function1115___eval();
static obj_t handling_function1111___eval(obj_t, long);
static obj_t internal_repl_154___eval();
obj_t _user_pass_name__185___eval = BUNSPEC;
extern obj_t close_input_port(obj_t);
static obj_t quit_1783___eval(obj_t, obj_t);
static obj_t arg1343___eval(obj_t);
static obj_t arg1342___eval(obj_t);
extern obj_t expand_define_hygien_macro_18___eval(obj_t, obj_t);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r5_macro_4_3_init(long, char *);
extern obj_t module_initialization_70___type(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___macro(long, char *);
extern obj_t module_initialization_70___install_expanders(long, char *);
extern obj_t module_initialization_70___progn(long, char *);
extern obj_t module_initialization_70___expand(long, char *);
extern obj_t module_initialization_70___evcompile(long, char *);
extern obj_t module_initialization_70___evmeaning(long, char *);
extern obj_t module_initialization_70___evprimop(long, char *);
extern obj_t module_initialization_70___evenv(long, char *);
extern obj_t module_initialization_70___match_normalize(long, char *);
static obj_t arg1272___eval(obj_t);
static obj_t arg1270___eval(obj_t);
extern obj_t notify_error_43___error(obj_t, obj_t, obj_t);
static obj_t arg1238___eval(obj_t);
static obj_t arg1236___eval(obj_t);
static obj_t arg1231___eval(obj_t, obj_t, obj_t);
static obj_t arg1176___eval(obj_t);
static obj_t arg1175___eval(obj_t);
static long _repl_num__134___eval;
static obj_t arg1151___eval(obj_t);
static obj_t arg1150___eval(obj_t);
static obj_t arg1140___eval(obj_t);
static obj_t arg1139___eval(obj_t);
static obj_t intrhdl___eval(obj_t, obj_t);
extern long get_write_length_193___r4_output_6_10_3();
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t remove_error_handler__102___error();
extern bool_t fexists(char *);
extern obj_t repl___eval();
extern obj_t eval___eval(obj_t, obj_t);
extern obj_t get_signal_handler_120___os(int);
static obj_t _null_environment_179___eval(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t expand_define_pattern_97___eval(obj_t);
static obj_t _included_files__122___eval = BUNSPEC;
static obj_t _module_declaration__185___eval(obj_t, obj_t);
static obj_t escape_1789___eval(obj_t, obj_t);
static obj_t escape_1788___eval(obj_t, obj_t);
static obj_t escape_1787___eval(obj_t, obj_t);
static obj_t escape_1786___eval(obj_t, obj_t);
static obj_t escape_1785___eval(obj_t, obj_t);
static obj_t escape_1784___eval(obj_t, obj_t);
static obj_t escape___eval(obj_t, obj_t);
static obj_t imported_modules_init_94___eval();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t symbol1841___eval = BUNSPEC;
static obj_t symbol1838___eval = BUNSPEC;
static obj_t symbol1837___eval = BUNSPEC;
static obj_t symbol1836___eval = BUNSPEC;
static obj_t symbol1835___eval = BUNSPEC;
static obj_t symbol1834___eval = BUNSPEC;
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t symbol1832___eval = BUNSPEC;
static obj_t symbol1831___eval = BUNSPEC;
static obj_t symbol1829___eval = BUNSPEC;
static obj_t symbol1830___eval = BUNSPEC;
static obj_t symbol1828___eval = BUNSPEC;
static obj_t symbol1827___eval = BUNSPEC;
static obj_t _repl_quit__177___eval = BUNSPEC;
static obj_t symbol1824___eval = BUNSPEC;
static obj_t symbol1822___eval = BUNSPEC;
static obj_t symbol1821___eval = BUNSPEC;
static obj_t symbol1819___eval = BUNSPEC;
static obj_t symbol1820___eval = BUNSPEC;
extern obj_t val_from_exit__100___bexit(obj_t);
extern obj_t scheme_report_environment_154___eval(obj_t);
static obj_t symbol1799___eval = BUNSPEC;
static obj_t symbol1810___eval = BUNSPEC;
static obj_t symbol1808___eval = BUNSPEC;
static obj_t symbol1796___eval = BUNSPEC;
static obj_t symbol1793___eval = BUNSPEC;
static obj_t symbol1800___eval = BUNSPEC;
extern obj_t set_write_length__244___r4_output_6_10_3(long);
static bool_t import__31___eval(obj_t);
extern obj_t _hygien___100___r5_macro_4_3_init;
static obj_t require_initialization_114___eval = BUNSPEC;
extern obj_t expand_define_macro_35___eval(obj_t, obj_t);
extern obj_t set_prompter__17___eval(obj_t);
extern obj_t evcompile___evcompile(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _get_prompter_47___eval(obj_t);
static obj_t list1840___eval = BUNSPEC;
static obj_t _scheme_report_environment_246___eval(obj_t, obj_t);
static obj_t list1823___eval = BUNSPEC;
extern obj_t reader_reset__72___reader();
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t normalize_progn_143___progn(obj_t);
extern obj_t null_environment_221___eval(obj_t);
static obj_t cnst_init_137___eval();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t _set_prompter__109___eval(obj_t, obj_t);
extern obj_t reset_console(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( get_prompter_env_129___eval, _get_prompter_47___eval1853, _get_prompter_47___eval, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( expand_define_hygien_macro_env_90___eval, _expand_define_hygien_macro_7___eval1854, _expand_define_hygien_macro_7___eval, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( repl_env_175___eval, _repl___eval1855, _repl___eval, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( notify_assert_fail_env_121___eval, _notify_assert_fail_157___eval1856, _notify_assert_fail_157___eval, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( null_environment_env_4___eval, _null_environment_179___eval1857, _null_environment_179___eval, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( loadq_env_160___eval, _loadq___eval1858, _loadq___eval, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1848___eval, arg1620___eval1859, arg1620___eval, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1803___eval, body1018___eval1860, body1018___eval, 0L, 0 );
DEFINE_STATIC_PROCEDURE( proc1790___eval, lambda1092___eval1861, lambda1092___eval, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( scheme_report_environment_env_58___eval, _scheme_report_environment_246___eval1862, _scheme_report_environment_246___eval, 0L, 1 );
DEFINE_STRING( string1851___eval, string1851___eval1863, "assertion failed", 16 );
DEFINE_STRING( string1849___eval, string1849___eval1864, "*:=> ", 5 );
DEFINE_STRING( string1850___eval, string1850___eval1865, "assert", 6 );
DEFINE_STRING( string1847___eval, string1847___eval1866, "   ", 3 );
DEFINE_STRING( string1846___eval, string1846___eval1867, " : ", 3 );
DEFINE_STRING( string1845___eval, string1845___eval1868, "Variables' value are : ", 23 );
DEFINE_STRING( string1844___eval, string1844___eval1869, "-----------------------", 23 );
DEFINE_STRING( string1843___eval, string1843___eval1870, "Illegal form", 12 );
DEFINE_STRING( string1842___eval, string1842___eval1871, "expand-define-pattern", 21 );
DEFINE_STRING( string1839___eval, string1839___eval1872, "Illegal module declaration", 26 );
DEFINE_STRING( string1833___eval, string1833___eval1873, "Too many arguments provided", 27 );
DEFINE_STRING( string1826___eval, string1826___eval1874, "Illegal `define-macro' syntax", 29 );
DEFINE_STRING( string1825___eval, string1825___eval1875, "define-macro", 12 );
DEFINE_STRING( string1818___eval, string1818___eval1876, "error occured while expansing the call", 38 );
DEFINE_STRING( string1817___eval, string1817___eval1877, "expand", 6 );
DEFINE_STRING( string1816___eval, string1816___eval1878, "illegal expander", 16 );
DEFINE_STRING( string1815___eval, string1815___eval1879, "wrong number of argument for expand", 35 );
DEFINE_STRING( string1814___eval, string1814___eval1880, "Illegal `define-expander' syntax", 32 );
DEFINE_STRING( string1813___eval, string1813___eval1881, "define-expander", 15 );
DEFINE_STRING( string1812___eval, string1812___eval1882, "loada", 5 );
DEFINE_STRING( string1811___eval, string1811___eval1883, "error occured when loading", 26 );
DEFINE_STRING( string1809___eval, string1809___eval1884, "module defined twice", 20 );
DEFINE_STRING( string1798___eval, string1798___eval1885, "Illegal environment", 19 );
DEFINE_STRING( string1797___eval, string1797___eval1886, "eval", 4 );
DEFINE_STRING( string1807___eval, string1807___eval1887, "Can't open file", 15 );
DEFINE_STRING( string1806___eval, string1806___eval1888, "load", 4 );
DEFINE_STRING( string1795___eval, string1795___eval1889, "Version not supported", 21 );
DEFINE_STRING( string1805___eval, string1805___eval1890, "/", 1 );
DEFINE_STRING( string1794___eval, string1794___eval1891, "scheme-report-environment", 25 );
DEFINE_STRING( string1804___eval, string1804___eval1892, "*** INTERRUPT:bigloo:", 21 );
DEFINE_STRING( string1792___eval, string1792___eval1893, ":=> ", 4 );
DEFINE_STRING( string1802___eval, string1802___eval1894, "argument has to be a procedure of 1 argument", 44 );
DEFINE_STRING( string1791___eval, string1791___eval1895, "User", 4 );
DEFINE_STRING( string1801___eval, string1801___eval1896, "set-prompter!", 13 );
DEFINE_EXPORT_PROCEDURE( bigloo_exit_env_50_foreign, _bigloo_exit_78___eval1897, _bigloo_exit_78___eval, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( set_prompter__env_195___eval, _set_prompter__109___eval1898, _set_prompter__109___eval, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( loada_env_94___eval, _loada___eval1899, _loada___eval, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( module_declaration__env_250___eval, _module_declaration__185___eval1900, _module_declaration__185___eval, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( interaction_environment_env_99___eval, _interaction_environment_35___eval1901, _interaction_environment_35___eval, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( expand_define_expander_env_64___eval, _expand_define_expander_206___eval1902, _expand_define_expander_206___eval, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( expand_define_pattern_env_247___eval, _expand_define_pattern_119___eval1903, _expand_define_pattern_119___eval, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( quit_env_185___eval, _quit___eval1904, _quit___eval, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( eval_env_197___eval, _eval___eval1905, va_generic_entry, _eval___eval, -2 );
DEFINE_EXPORT_PROCEDURE( expand_define_macro_env_44___eval, _expand_define_macro_10___eval1906, _expand_define_macro_10___eval, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( load_env_157___eval, _load___eval1907, _load___eval, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___eval(long checksum_2104, char * from_2105)
{
if(CBOOL(require_initialization_114___eval)){
require_initialization_114___eval = BBOOL(((bool_t)0));
cnst_init_137___eval();
imported_modules_init_94___eval();
toplevel_init_63___eval();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___eval()
{
symbol1793___eval = string_to_symbol("SCHEME-REPORT-ENVIRONMENT");
symbol1796___eval = string_to_symbol("NULL-ENVIRONMENT");
symbol1799___eval = string_to_symbol("INTERACTION-ENVIRONMENT");
symbol1800___eval = string_to_symbol("NOWHERE");
symbol1808___eval = string_to_symbol("MODULE");
symbol1810___eval = string_to_symbol("MAIN");
symbol1819___eval = string_to_symbol("LAMBDA");
symbol1820___eval = string_to_symbol("X");
symbol1821___eval = string_to_symbol("E");
symbol1822___eval = string_to_symbol("LET");
symbol1824___eval = string_to_symbol("CDR");
{
obj_t aux_2123;
aux_2123 = MAKE_PAIR(symbol1820___eval, BNIL);
list1823___eval = MAKE_PAIR(symbol1824___eval, aux_2123);
}
symbol1827___eval = string_to_symbol("QUOTE");
symbol1828___eval = string_to_symbol(".DUMMY.");
symbol1829___eval = string_to_symbol("IF");
symbol1830___eval = string_to_symbol("NOT");
symbol1831___eval = string_to_symbol("NULL?");
symbol1832___eval = string_to_symbol("ERROR");
symbol1834___eval = string_to_symbol("CAR");
symbol1835___eval = string_to_symbol("DONE");
symbol1836___eval = string_to_symbol("INCLUDE");
symbol1837___eval = string_to_symbol("IMPORT");
symbol1838___eval = string_to_symbol("LOAD");
symbol1841___eval = string_to_symbol("DUMMY");
{
obj_t aux_2138;
aux_2138 = MAKE_PAIR(symbol1841___eval, BNIL);
return (list1840___eval = MAKE_PAIR(symbol1827___eval, aux_2138),
BUNSPEC);
}
}


/* _bigloo-exit */obj_t _bigloo_exit_78___eval(obj_t env_1807, obj_t g1782_1808)
{
return BIGLOO_EXIT(g1782_1808);
}


/* toplevel-init */obj_t toplevel_init_63___eval()
{
install_all_expanders__168___install_expanders();
{
obj_t lambda1092_1804;
lambda1092_1804 = proc1790___eval;
_prompt__73___eval = lambda1092_1804;
}
_repl_num__134___eval = ((long)0);
_repl_quit__177___eval = bigloo_exit_env_50_foreign;
_load_path__54___eval = BNIL;
_included_files__122___eval = BNIL;
_imported_files__212___eval = BNIL;
_afile_list__205___eval = BNIL;
_nil__217___eval = BTRUE;
_user_pass__208___eval = BUNSPEC;
return (_user_pass_name__185___eval = string1791___eval,
BUNSPEC);
}


/* lambda1092 */obj_t lambda1092___eval(obj_t env_1805, obj_t num_1806)
{
{
obj_t num_346;
num_346 = num_1806;
display___r4_output_6_10_3(num_346, BNIL);
display___r4_output_6_10_3(string1792___eval, BNIL);
return FLUSH_OUTPUT_PORT(current_output_port);
}
}


/* eval */obj_t eval___eval(obj_t exp_1, obj_t environment_2)
{
{
obj_t env_351;
if(PAIRP(environment_2)){
obj_t env_362;
env_362 = CAR(environment_2);
{
bool_t test1103_363;
{
bool_t test1104_364;
{
obj_t arg1107_367;
{
obj_t version_1244;
version_1244 = BINT(((long)5));
{
bool_t test_2150;
{
long aux_2151;
aux_2151 = (long)CINT(version_1244);
test_2150 = (aux_2151==((long)5));
}
if(test_2150){
arg1107_367 = symbol1793___eval;
}
 else {
FAILURE(string1794___eval,string1795___eval,version_1244);}
}
}
test1104_364 = (env_362==arg1107_367);
}
if(test1104_364){
test1103_363 = ((bool_t)1);
}
 else {
bool_t test1105_365;
{
obj_t arg1106_366;
{
obj_t version_1253;
version_1253 = BINT(((long)5));
{
bool_t test_2158;
{
long aux_2159;
aux_2159 = (long)CINT(version_1253);
test_2158 = (aux_2159==((long)5));
}
if(test_2158){
arg1106_366 = symbol1796___eval;
}
 else {
FAILURE(string1794___eval,string1795___eval,version_1253);}
}
}
test1105_365 = (env_362==arg1106_366);
}
if(test1105_365){
test1103_363 = ((bool_t)1);
}
 else {
test1103_363 = ((bool_t)1);
}
}
}
if(test1103_363){
env_351 = env_362;
}
 else {
FAILURE(string1797___eval,string1798___eval,environment_2);}
}
}
 else {
env_351 = symbol1799___eval;
}
{
obj_t loc_352;
loc_352 = find_loc_64___evcompile(exp_1, BFALSE);
{
obj_t exp_353;
{
bool_t test1101_360;
{
obj_t obj_1265;
obj_1265 = _user_pass__208___eval;
test1101_360 = PROCEDUREP(obj_1265);
}
if(test1101_360){
exp_353 = PROCEDURE_ENTRY(_user_pass__208___eval)(_user_pass__208___eval, exp_1, BEOA);
}
 else {
exp_353 = exp_1;
}
}
{
obj_t sexp_354;
if(CBOOL(_hygien___100___r5_macro_4_3_init)){
sexp_354 = expand_syntax_236___r5_macro_4_3_init(exp_353);
}
 else {
sexp_354 = exp_353;
}
{
evmeaning_reset_error__111___evmeaning();
{
obj_t arg1096_355;
{
obj_t arg1098_357;
obj_t arg1100_359;
arg1098_357 = expand___expand(sexp_354);
arg1100_359 = symbol1800___eval;
arg1096_355 = evcompile___evcompile(arg1098_357, BNIL, env_351, arg1100_359, BFALSE, loc_352);
}
return evmeaning___evmeaning(arg1096_355, BNIL);
}
}
}
}
}
}
}


/* _eval */obj_t _eval___eval(obj_t env_1809, obj_t exp_1810, obj_t environment_1811)
{
return eval___eval(exp_1810, environment_1811);
}


/* scheme-report-environment */obj_t scheme_report_environment_154___eval(obj_t version_3)
{
{
bool_t test_2180;
{
long aux_2181;
aux_2181 = (long)CINT(version_3);
test_2180 = (aux_2181==((long)5));
}
if(test_2180){
return symbol1793___eval;
}
 else {
FAILURE(string1794___eval,string1795___eval,version_3);}
}
}


/* _scheme-report-environment */obj_t _scheme_report_environment_246___eval(obj_t env_1812, obj_t version_1813)
{
return scheme_report_environment_154___eval(version_1813);
}


/* null-environment */obj_t null_environment_221___eval(obj_t version_4)
{
{
bool_t test_2186;
{
long aux_2187;
aux_2187 = (long)CINT(version_4);
test_2186 = (aux_2187==((long)5));
}
if(test_2186){
return symbol1796___eval;
}
 else {
FAILURE(string1794___eval,string1795___eval,version_4);}
}
}


/* _null-environment */obj_t _null_environment_179___eval(obj_t env_1814, obj_t version_1815)
{
return null_environment_221___eval(version_1815);
}


/* interaction-environment */obj_t interaction_environment_31___eval()
{
return symbol1799___eval;
}


/* _interaction-environment */obj_t _interaction_environment_35___eval(obj_t env_1816)
{
return symbol1799___eval;
}


/* set-prompter! */obj_t set_prompter__17___eval(obj_t proc_5)
{
{
bool_t test1110_1278;
test1110_1278 = PROCEDURE_CORRECT_ARITYP(proc_5, ((long)1));
if(test1110_1278){
return (_prompt__73___eval = proc_5,
BUNSPEC);
}
 else {
FAILURE(string1801___eval,string1802___eval,proc_5);}
}
}


/* _set-prompter! */obj_t _set_prompter__109___eval(obj_t env_1817, obj_t proc_1818)
{
return set_prompter__17___eval(proc_1818);
}


/* get-prompter */obj_t get_prompter_227___eval()
{
return _prompt__73___eval;
}


/* _get-prompter */obj_t _get_prompter_47___eval(obj_t env_1819)
{
return _prompt__73___eval;
}


/* repl */obj_t repl___eval()
{
{
obj_t repl_quit_168_371;
long repl_num_20_372;
repl_quit_168_371 = _repl_quit__177___eval;
repl_num_20_372 = _repl_num__134___eval;
handling_function1111___eval(repl_quit_168_371, repl_num_20_372);
newline___r4_output_6_10_3(BNIL);
return FLUSH_OUTPUT_PORT(current_output_port);
}
}


/* handling_function1115 */obj_t handling_function1115___eval()
{
jmp_buf jmpbuf;
obj_t an_exit1007_384;
if( SET_EXIT(an_exit1007_384) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1007_384 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1007_384, ((bool_t)0));
{
obj_t val1008_385;
val1008_385 = internal_repl_154___eval();
POP_EXIT();
return val1008_385;
}
}
}
}


/* handling_function1111 */obj_t handling_function1111___eval(obj_t repl_quit_168_2097, long repl_num_20_2096)
{
jmp_buf jmpbuf;
obj_t an_exit1002_374;
if( SET_EXIT(an_exit1002_374) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1002_374 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1002_374, ((bool_t)1));
{
obj_t an_exitd1003_375;
an_exitd1003_375 = exitd_top;
{
obj_t quit_1820;
quit_1820 = make_fx_procedure(quit_1783___eval, ((long)1), ((long)1));
PROCEDURE_SET(quit_1820, ((long)0), an_exitd1003_375);
{
obj_t res1005_378;
_repl_quit__177___eval = quit_1820;
{
long z2_1283;
z2_1283 = _repl_num__134___eval;
_repl_num__134___eval = (((long)1)+z2_1283);
}
{
obj_t val1006_379;
val1006_379 = handling_function1115___eval();
_repl_num__134___eval = repl_num_20_2096;
_repl_quit__177___eval = repl_quit_168_2097;
{
bool_t test1112_380;
{
obj_t aux_2211;
aux_2211 = val_from_exit__100___bexit(val1006_379);
test1112_380 = CBOOL(aux_2211);
}
if(test1112_380){
res1005_378 = unwind_until__178___bexit(CAR(val1006_379), CDR(val1006_379));
}
 else {
res1005_378 = val1006_379;
}
}
}
POP_EXIT();
return res1005_378;
}
}
}
}
}
}


/* _repl */obj_t _repl___eval(obj_t env_1821)
{
return repl___eval();
}


/* quit_1783 */obj_t quit_1783___eval(obj_t env_1822, obj_t val1004_1824)
{
{
obj_t an_exitd1003_1823;
an_exitd1003_1823 = PROCEDURE_REF(env_1822, ((long)0));
{
obj_t val1004_376;
val1004_376 = val1004_1824;
return unwind_until__178___bexit(an_exitd1003_1823, val1004_376);
}
}
}


/* internal-repl */obj_t internal_repl_154___eval()
{
{
obj_t old_intrhdl_185_388;
old_intrhdl_185_388 = get_signal_handler_120___os(SIGINT);
{
obj_t val1009_389;
val1009_389 = handling_function1122___eval();
if(PROCEDUREP(old_intrhdl_185_388)){
signal___os(SIGINT, old_intrhdl_185_388);
}
 else {
BUNSPEC;
}
{
bool_t test1119_391;
{
obj_t aux_2227;
aux_2227 = val_from_exit__100___bexit(val1009_389);
test1119_391 = CBOOL(aux_2227);
}
if(test1119_391){
return unwind_until__178___bexit(CAR(val1009_389), CDR(val1009_389));
}
 else {
return val1009_389;
}
}
}
}
}


/* handling_function1148 */obj_t handling_function1148___eval(obj_t body1018_2092, obj_t rhandler1017_2091, obj_t armed1019_2090)
{
jmp_buf jmpbuf;
obj_t an_exit1020_461;
if( SET_EXIT(an_exit1020_461) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1020_461 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1020_461, ((bool_t)1));
{
obj_t an_exitd1021_462;
an_exitd1021_462 = exitd_top;
{
obj_t escape_1832;
escape_1832 = make_fx_procedure(escape_1784___eval, ((long)1), ((long)1));
PROCEDURE_SET(escape_1832, ((long)0), an_exitd1021_462);
{
obj_t res1023_465;
{
obj_t arg1151_1830;
obj_t arg1150_1834;
arg1151_1830 = make_fx_procedure(arg1151___eval, ((long)0), ((long)1));
arg1150_1834 = make_fx_procedure(arg1150___eval, ((long)0), ((long)4));
PROCEDURE_SET(arg1151_1830, ((long)0), armed1019_2090);
PROCEDURE_SET(arg1150_1834, ((long)0), an_exitd1021_462);
PROCEDURE_SET(arg1150_1834, ((long)1), armed1019_2090);
PROCEDURE_SET(arg1150_1834, ((long)2), rhandler1017_2091);
PROCEDURE_SET(arg1150_1834, ((long)3), escape_1832);
res1023_465 = dynamic_wind_31___r4_control_features_6_9(arg1150_1834, body1018_2092, arg1151_1830);
}
POP_EXIT();
return res1023_465;
}
}
}
}
}
}


/* handling_function1138 */obj_t handling_function1138___eval(obj_t body1026_2095, obj_t rhandler1025_2094, obj_t armed1027_2093)
{
jmp_buf jmpbuf;
obj_t an_exit1028_429;
if( SET_EXIT(an_exit1028_429) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1028_429 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1028_429, ((bool_t)1));
{
obj_t an_exitd1029_430;
an_exitd1029_430 = exitd_top;
{
obj_t escape_1827;
escape_1827 = make_fx_procedure(escape___eval, ((long)1), ((long)1));
PROCEDURE_SET(escape_1827, ((long)0), an_exitd1029_430);
{
obj_t res1031_433;
{
obj_t arg1140_1825;
obj_t arg1139_1829;
arg1140_1825 = make_fx_procedure(arg1140___eval, ((long)0), ((long)1));
arg1139_1829 = make_fx_procedure(arg1139___eval, ((long)0), ((long)4));
PROCEDURE_SET(arg1140_1825, ((long)0), armed1027_2093);
PROCEDURE_SET(arg1139_1829, ((long)0), an_exitd1029_430);
PROCEDURE_SET(arg1139_1829, ((long)1), armed1027_2093);
PROCEDURE_SET(arg1139_1829, ((long)2), rhandler1025_2094);
PROCEDURE_SET(arg1139_1829, ((long)3), escape_1827);
res1031_433 = dynamic_wind_31___r4_control_features_6_9(arg1139_1829, body1026_2095, arg1140_1825);
}
POP_EXIT();
return res1031_433;
}
}
}
}
}
}


/* handling_function1123 */obj_t handling_function1123___eval()
{
jmp_buf jmpbuf;
obj_t an_exit1012_399;
if( SET_EXIT(an_exit1012_399) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1012_399 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1012_399, ((bool_t)1));
{
obj_t an_exitd1013_400;
an_exitd1013_400 = exitd_top;
{
obj_t res1015_403;
{
obj_t intrhdl_1835;
intrhdl_1835 = make_fx_procedure(intrhdl___eval, ((long)1), ((long)1));
PROCEDURE_SET(intrhdl_1835, ((long)0), an_exitd1013_400);
signal___os(SIGINT, intrhdl_1835);
}
newline___r4_output_6_10_3(BNIL);
{
loop_418:
PROCEDURE_ENTRY(_prompt__73___eval)(_prompt__73___eval, BINT(_repl_num__134___eval), BEOA);
{
obj_t exp_419;
{
obj_t cellval_2272;
{
obj_t armed1019_456;
armed1019_456 = MAKE_CELL(BUNSPEC);
{
obj_t body1018_1831;
obj_t rhandler1017_1833;
body1018_1831 = proc1803___eval;
rhandler1017_1833 = make_fx_procedure(rhandler1017___eval, ((long)4), ((long)1));
PROCEDURE_SET(rhandler1017_1833, ((long)0), armed1019_456);
CELL_SET(armed1019_456, BTRUE);
cellval_2272 = handling_function1148___eval(body1018_1831, rhandler1017_1833, armed1019_456);
}
}
exp_419 = MAKE_CELL(cellval_2272);
}
{
bool_t test1135_420;
{
obj_t object_1308;
object_1308 = CELL_REF(exp_419);
test1135_420 = EOF_OBJECTP(object_1308);
}
if(test1135_420){
res1015_403 = PROCEDURE_ENTRY(_repl_quit__177___eval)(_repl_quit__177___eval, BINT(((long)0)), BEOA);
}
 else {
obj_t v_421;
{
obj_t armed1027_424;
armed1027_424 = MAKE_CELL(BUNSPEC);
{
obj_t body1026_1826;
obj_t rhandler1025_1828;
body1026_1826 = make_fx_procedure(body1026___eval, ((long)0), ((long)1));
rhandler1025_1828 = make_fx_procedure(rhandler1025___eval, ((long)4), ((long)1));
PROCEDURE_SET(body1026_1826, ((long)0), exp_419);
PROCEDURE_SET(rhandler1025_1828, ((long)0), armed1027_424);
CELL_SET(armed1027_424, BTRUE);
v_421 = handling_function1138___eval(body1026_1826, rhandler1025_1828, armed1027_424);
}
}
{
obj_t list1136_422;
list1136_422 = MAKE_PAIR(v_421, BNIL);
print___r4_output_6_10_3(list1136_422);
}
CELL_SET(exp_419, BUNSPEC);
goto loop_418;
}
}
}
}
POP_EXIT();
return res1015_403;
}
}
}
}
}


/* handling_function1122 */obj_t handling_function1122___eval()
{
jmp_buf jmpbuf;
obj_t an_exit1010_395;
if( SET_EXIT(an_exit1010_395) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1010_395 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1010_395, ((bool_t)0));
{
obj_t val1011_396;
{
loop_397:
handling_function1123___eval();
goto loop_397;
}
POP_EXIT();
return val1011_396;
}
}
}
}


/* arg1140 */obj_t arg1140___eval(obj_t env_1836)
{
{
obj_t armed1027_1837;
armed1027_1837 = PROCEDURE_REF(env_1836, ((long)0));
{
{
bool_t test_2295;
{
obj_t aux_2296;
aux_2296 = CELL_REF(armed1027_1837);
test_2295 = CBOOL(aux_2296);
}
if(test_2295){
CELL_SET(armed1027_1837, BFALSE);
return remove_error_handler__102___error();
}
 else {
return BUNSPEC;
}
}
}
}
}


/* body1026 */obj_t body1026___eval(obj_t env_1839)
{
{
obj_t exp_1840;
exp_1840 = PROCEDURE_REF(env_1839, ((long)0));
{
return eval___eval(CELL_REF(exp_1840), BNIL);
}
}
}


/* arg1139 */obj_t arg1139___eval(obj_t env_1841)
{
{
obj_t rhandler1025_1844;
obj_t escape_1845;
rhandler1025_1844 = PROCEDURE_REF(env_1841, ((long)2));
escape_1845 = PROCEDURE_REF(env_1841, ((long)3));
{
return add_error_handler__155___error(rhandler1025_1844, escape_1845);
}
}
}


/* escape */obj_t escape___eval(obj_t env_1846, obj_t val1030_1848)
{
{
obj_t an_exitd1029_1847;
an_exitd1029_1847 = PROCEDURE_REF(env_1846, ((long)0));
{
obj_t val1030_431;
val1030_431 = val1030_1848;
return unwind_until__178___bexit(an_exitd1029_1847, val1030_431);
}
}
}


/* rhandler1025 */obj_t rhandler1025___eval(obj_t env_1849, obj_t esc_1851, obj_t obj_1852, obj_t proc_1853, obj_t msg_1854)
{
{
obj_t armed1027_1850;
armed1027_1850 = PROCEDURE_REF(env_1849, ((long)0));
{
obj_t esc_446;
obj_t obj_447;
obj_t proc_448;
obj_t msg_449;
esc_446 = esc_1851;
obj_447 = obj_1852;
proc_448 = proc_1853;
msg_449 = msg_1854;
CELL_SET(armed1027_1850, BFALSE);
remove_error_handler__102___error();
evmeaning_notify_error_24___evmeaning(obj_447, proc_448, msg_449);
FLUSH_OUTPUT_PORT(current_error_port);
{
int aux_2310;
aux_2310 = (int)(((long)0));
sigsetmask(aux_2310);
}
return PROCEDURE_ENTRY(esc_446)(esc_446, BUNSPEC, BEOA);
}
}
}


/* arg1151 */obj_t arg1151___eval(obj_t env_1856)
{
{
obj_t armed1019_1857;
armed1019_1857 = PROCEDURE_REF(env_1856, ((long)0));
{
{
bool_t test_2316;
{
obj_t aux_2317;
aux_2317 = CELL_REF(armed1019_1857);
test_2316 = CBOOL(aux_2317);
}
if(test_2316){
CELL_SET(armed1019_1857, BFALSE);
return remove_error_handler__102___error();
}
 else {
return BUNSPEC;
}
}
}
}
}


/* body1018 */obj_t body1018___eval(obj_t env_1859)
{
{
{
obj_t list1161_1306;
list1161_1306 = MAKE_PAIR(current_input_port, BNIL);
return read___reader(list1161_1306);
}
}
}


/* arg1150 */obj_t arg1150___eval(obj_t env_1860)
{
{
obj_t rhandler1017_1863;
obj_t escape_1864;
rhandler1017_1863 = PROCEDURE_REF(env_1860, ((long)2));
escape_1864 = PROCEDURE_REF(env_1860, ((long)3));
{
return add_error_handler__155___error(rhandler1017_1863, escape_1864);
}
}
}


/* escape_1784 */obj_t escape_1784___eval(obj_t env_1865, obj_t val1022_1867)
{
{
obj_t an_exitd1021_1866;
an_exitd1021_1866 = PROCEDURE_REF(env_1865, ((long)0));
{
obj_t val1022_463;
val1022_463 = val1022_1867;
return unwind_until__178___bexit(an_exitd1021_1866, val1022_463);
}
}
}


/* rhandler1017 */obj_t rhandler1017___eval(obj_t env_1868, obj_t esc_1870, obj_t obj_1871, obj_t proc_1872, obj_t msg_1873)
{
{
obj_t armed1019_1869;
armed1019_1869 = PROCEDURE_REF(env_1868, ((long)0));
{
obj_t esc_480;
obj_t obj_481;
obj_t proc_482;
obj_t msg_483;
esc_480 = esc_1870;
obj_481 = obj_1871;
proc_482 = proc_1872;
msg_483 = msg_1873;
CELL_SET(armed1019_1869, BFALSE);
remove_error_handler__102___error();
FLUSH_OUTPUT_PORT(current_error_port);
{
bool_t test1156_1300;
test1156_1300 = EOF_OBJECTP(proc_482);
if(test1156_1300){
bool_t aux_2332;
aux_2332 = reset_eof(current_input_port);
BBOOL(aux_2332);
}
 else {
BUNSPEC;
}
}
{
int aux_2335;
aux_2335 = (int)(((long)0));
sigsetmask(aux_2335);
}
return PROCEDURE_ENTRY(esc_480)(esc_480, BUNSPEC, BEOA);
}
}
}


/* intrhdl */obj_t intrhdl___eval(obj_t env_1875, obj_t n_1877)
{
{
obj_t an_exitd1013_1876;
an_exitd1013_1876 = PROCEDURE_REF(env_1875, ((long)0));
{
obj_t n_405;
n_405 = n_1877;
{
obj_t list1126_408;
list1126_408 = MAKE_PAIR(current_error_port, BNIL);
newline___r4_output_6_10_3(list1126_408);
}
{
obj_t list1130_412;
list1130_412 = MAKE_PAIR(string1804___eval, BNIL);
fprint___r4_output_6_10_3(current_error_port, list1130_412);
}
FLUSH_OUTPUT_PORT(current_error_port);
reader_reset__72___reader();
reset_console(current_input_port);
{
int aux_2348;
aux_2348 = (int)(((long)0));
sigsetmask(aux_2348);
}
signal___os(CINT(n_405), env_1875);
return unwind_until__178___bexit(an_exitd1013_1876, BUNSPEC);
}
}
}


/* quit */obj_t quit___eval()
{
return PROCEDURE_ENTRY(_repl_quit__177___eval)(_repl_quit__177___eval, BINT(((long)0)), BEOA);
}


/* _quit */obj_t _quit___eval(obj_t env_1881)
{
return quit___eval();
}


/* find-file */obj_t find_file_173___eval(obj_t name_6)
{
{
bool_t test1163_492;
{
char * aux_2358;
aux_2358 = BSTRING_TO_STRING(name_6);
test1163_492 = fexists(aux_2358);
}
if(test1163_492){
return name_6;
}
 else {
obj_t path_493;
path_493 = _load_path__54___eval;
loop_494:
if(NULLP(path_493)){
return name_6;
}
 else {
obj_t try_496;
{
obj_t arg1167_499;
arg1167_499 = CAR(path_493);
{
obj_t list1169_501;
{
obj_t arg1170_502;
{
obj_t arg1171_503;
arg1171_503 = MAKE_PAIR(name_6, BNIL);
arg1170_502 = MAKE_PAIR(string1805___eval, arg1171_503);
}
list1169_501 = MAKE_PAIR(arg1167_499, arg1170_502);
}
try_496 = string_append_106___r4_strings_6_7(list1169_501);
}
}
{
bool_t test1165_497;
{
char * aux_2369;
aux_2369 = BSTRING_TO_STRING(try_496);
test1165_497 = fexists(aux_2369);
}
if(test1165_497){
return try_496;
}
 else {
obj_t path_2373;
path_2373 = CDR(path_493);
path_493 = path_2373;
goto loop_494;
}
}
}
}
}
}


/* load */obj_t load___eval(obj_t file_name_128_7)
{
return loadv___eval(file_name_128_7, ((bool_t)1));
}


/* _load */obj_t _load___eval(obj_t env_1882, obj_t file_name_128_1883)
{
return load___eval(file_name_128_1883);
}


/* loadq */obj_t loadq___eval(obj_t file_name_128_8)
{
return loadv___eval(file_name_128_8, ((bool_t)0));
}


/* _loadq */obj_t _loadq___eval(obj_t env_1884, obj_t file_name_128_1885)
{
return loadq___eval(file_name_128_1885);
}


/* loadv */obj_t loadv___eval(obj_t file_name_128_9, bool_t v__116_10)
{
{
obj_t port_505;
{
obj_t arg1216_578;
arg1216_578 = find_file_173___eval(file_name_128_9);
port_505 = open_input_file_61___r4_ports_6_10_1(arg1216_578, BNIL);
}
evmeaning_reset_error__111___evmeaning();
if(INPUT_PORTP(port_505)){
obj_t armed1035_507;
armed1035_507 = MAKE_CELL(BUNSPEC);
{
obj_t body1034_1887;
obj_t rhandler1033_1889;
body1034_1887 = make_fx_procedure(body1034___eval, ((long)0), ((long)2));
rhandler1033_1889 = make_fx_procedure(rhandler1033___eval, ((long)4), ((long)2));
{
obj_t aux_2386;
aux_2386 = BBOOL(v__116_10);
PROCEDURE_SET(body1034_1887, ((long)0), aux_2386);
}
PROCEDURE_SET(body1034_1887, ((long)1), port_505);
PROCEDURE_SET(rhandler1033_1889, ((long)0), armed1035_507);
PROCEDURE_SET(rhandler1033_1889, ((long)1), file_name_128_9);
CELL_SET(armed1035_507, BTRUE);
return handling_function1174___eval(body1034_1887, rhandler1033_1889, file_name_128_9, armed1035_507);
}
}
 else {
FAILURE(string1806___eval,string1807___eval,file_name_128_9);}
}
}


/* handling_function1174 */obj_t handling_function1174___eval(obj_t body1034_2089, obj_t rhandler1033_2088, obj_t file_name_128_2087, obj_t armed1035_2086)
{
jmp_buf jmpbuf;
obj_t an_exit1036_512;
if( SET_EXIT(an_exit1036_512) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1036_512 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1036_512, ((bool_t)1));
{
obj_t an_exitd1037_513;
an_exitd1037_513 = exitd_top;
{
obj_t escape_1888;
escape_1888 = make_fx_procedure(escape_1785___eval, ((long)1), ((long)1));
PROCEDURE_SET(escape_1888, ((long)0), an_exitd1037_513);
{
obj_t res1039_516;
{
obj_t arg1176_1886;
obj_t arg1175_1890;
arg1176_1886 = make_fx_procedure(arg1176___eval, ((long)0), ((long)1));
arg1175_1890 = make_fx_procedure(arg1175___eval, ((long)0), ((long)5));
PROCEDURE_SET(arg1176_1886, ((long)0), armed1035_2086);
PROCEDURE_SET(arg1175_1890, ((long)0), an_exitd1037_513);
PROCEDURE_SET(arg1175_1890, ((long)1), armed1035_2086);
PROCEDURE_SET(arg1175_1890, ((long)2), file_name_128_2087);
PROCEDURE_SET(arg1175_1890, ((long)3), rhandler1033_2088);
PROCEDURE_SET(arg1175_1890, ((long)4), escape_1888);
res1039_516 = dynamic_wind_31___r4_control_features_6_9(arg1175_1890, body1034_2089, arg1176_1886);
}
POP_EXIT();
return res1039_516;
}
}
}
}
}
}


/* arg1176 */obj_t arg1176___eval(obj_t env_1891)
{
{
obj_t armed1035_1892;
armed1035_1892 = PROCEDURE_REF(env_1891, ((long)0));
{
{
bool_t test_2410;
{
obj_t aux_2411;
aux_2411 = CELL_REF(armed1035_1892);
test_2410 = CBOOL(aux_2411);
}
if(test_2410){
CELL_SET(armed1035_1892, BFALSE);
return remove_error_handler__102___error();
}
 else {
return BUNSPEC;
}
}
}
}
}


/* body1034 */obj_t body1034___eval(obj_t env_1894)
{
{
obj_t v__116_1895;
obj_t port_1896;
v__116_1895 = PROCEDURE_REF(env_1894, ((long)0));
port_1896 = PROCEDURE_REF(env_1894, ((long)1));
{
{
obj_t sexp_534;
obj_t v_535;
bool_t module_seen__27_536;
obj_t main_537;
{
obj_t arg1182_539;
{
obj_t list1184_541;
{
obj_t arg1185_542;
arg1185_542 = MAKE_PAIR(BTRUE, BNIL);
list1184_541 = MAKE_PAIR(port_1896, arg1185_542);
}
arg1182_539 = read___reader(list1184_541);
}
sexp_534 = arg1182_539;
v_535 = BUNSPEC;
module_seen__27_536 = ((bool_t)0);
main_537 = BFALSE;
loop_538:
{
bool_t test1187_544;
test1187_544 = EOF_OBJECTP(sexp_534);
if(test1187_544){
close_input_port(port_1896);
{
obj_t pmain_545;
if(SYMBOLP(main_537)){
pmain_545 = eval___eval(main_537, BNIL);
}
 else {
pmain_545 = BFALSE;
}
if(PROCEDUREP(pmain_545)){
obj_t arg1189_547;
arg1189_547 = command_line_67___os();
return PROCEDURE_ENTRY(pmain_545)(pmain_545, arg1189_547, BEOA);
}
 else {
return v_535;
}
}
}
 else {
bool_t test_2430;
if(PAIRP(sexp_534)){
obj_t aux_2433;
aux_2433 = CAR(sexp_534);
test_2430 = (aux_2433==symbol1808___eval);
}
 else {
test_2430 = ((bool_t)0);
}
if(test_2430){
if(module_seen__27_536){
FAILURE(string1806___eval,string1809___eval,sexp_534);}
 else {
obj_t main_551;
{
obj_t aux_2438;
{
obj_t aux_2439;
aux_2439 = CDR(sexp_534);
aux_2438 = CDR(aux_2439);
}
main_551 = assq___r4_pairs_and_lists_6_3(symbol1810___eval, aux_2438);
}
{
obj_t v_552;
v_552 = eval___eval(sexp_534, BNIL);
if(CBOOL(v__116_1895)){
obj_t list1193_553;
list1193_553 = MAKE_PAIR(v_552, BNIL);
print___r4_output_6_10_3(list1193_553);
}
 else {
BUNSPEC;
}
{
obj_t arg1195_555;
obj_t arg1196_556;
{
obj_t list1197_557;
{
obj_t arg1199_558;
arg1199_558 = MAKE_PAIR(BTRUE, BNIL);
list1197_557 = MAKE_PAIR(port_1896, arg1199_558);
}
arg1195_555 = read___reader(list1197_557);
}
if(PAIRP(main_551)){
obj_t aux_2453;
aux_2453 = CDR(main_551);
arg1196_556 = CAR(aux_2453);
}
 else {
arg1196_556 = v_552;
}
{
obj_t main_2459;
bool_t module_seen__27_2458;
obj_t v_2457;
obj_t sexp_2456;
sexp_2456 = arg1195_555;
v_2457 = v_552;
module_seen__27_2458 = ((bool_t)1);
main_2459 = arg1196_556;
main_537 = main_2459;
module_seen__27_536 = module_seen__27_2458;
v_535 = v_2457;
sexp_534 = sexp_2456;
goto loop_538;
}
}
}
}
}
 else {
{
obj_t v_564;
v_564 = eval___eval(sexp_534, BNIL);
evmeaning_reset_error__111___evmeaning();
if(CBOOL(v__116_1895)){
obj_t list1205_565;
list1205_565 = MAKE_PAIR(v_564, BNIL);
print___r4_output_6_10_3(list1205_565);
}
 else {
BUNSPEC;
}
{
obj_t arg1207_567;
{
obj_t list1208_568;
{
obj_t arg1209_569;
arg1209_569 = MAKE_PAIR(BTRUE, BNIL);
list1208_568 = MAKE_PAIR(port_1896, arg1209_569);
}
arg1207_567 = read___reader(list1208_568);
}
{
obj_t v_2470;
obj_t sexp_2469;
sexp_2469 = arg1207_567;
v_2470 = v_564;
v_535 = v_2470;
sexp_534 = sexp_2469;
goto loop_538;
}
}
}
}
}
}
}
}
}
}
}


/* arg1175 */obj_t arg1175___eval(obj_t env_1897)
{
{
obj_t rhandler1033_1901;
obj_t escape_1902;
rhandler1033_1901 = PROCEDURE_REF(env_1897, ((long)3));
escape_1902 = PROCEDURE_REF(env_1897, ((long)4));
{
return add_error_handler__155___error(rhandler1033_1901, escape_1902);
}
}
}


/* escape_1785 */obj_t escape_1785___eval(obj_t env_1903, obj_t val1038_1905)
{
{
obj_t an_exitd1037_1904;
an_exitd1037_1904 = PROCEDURE_REF(env_1903, ((long)0));
{
obj_t val1038_514;
val1038_514 = val1038_1905;
return unwind_until__178___bexit(an_exitd1037_1904, val1038_514);
}
}
}


/* rhandler1033 */obj_t rhandler1033___eval(obj_t env_1906, obj_t esc_1909, obj_t obj_1910, obj_t proc_1911, obj_t msg_1912)
{
{
obj_t armed1035_1907;
obj_t file_name_128_1908;
armed1035_1907 = PROCEDURE_REF(env_1906, ((long)0));
file_name_128_1908 = PROCEDURE_REF(env_1906, ((long)1));
{
obj_t esc_528;
obj_t obj_529;
obj_t proc_530;
obj_t msg_531;
esc_528 = esc_1909;
obj_529 = obj_1910;
proc_530 = proc_1911;
msg_531 = msg_1912;
CELL_SET(armed1035_1907, BFALSE);
remove_error_handler__102___error();
evmeaning_notify_error_24___evmeaning(obj_529, proc_530, msg_531);
FAILURE(string1806___eval,string1811___eval,file_name_128_1908);}
}
}


/* loada */obj_t loada___eval(obj_t file_11)
{
{
obj_t port_580;
port_580 = open_input_file_61___r4_ports_6_10_1(file_11, BNIL);
if(INPUT_PORTP(port_580)){
{
obj_t arg1219_582;
{
obj_t list1220_583;
{
obj_t arg1221_584;
arg1221_584 = MAKE_PAIR(BTRUE, BNIL);
list1220_583 = MAKE_PAIR(port_580, arg1221_584);
}
arg1219_582 = read___reader(list1220_583);
}
_afile_list__205___eval = append_2_18___r4_pairs_and_lists_6_3(arg1219_582, _afile_list__205___eval);
}
return close_input_port(port_580);
}
 else {
FAILURE(string1812___eval,string1807___eval,file_11);}
}
}


/* _loada */obj_t _loada___eval(obj_t env_1915, obj_t file_1916)
{
return loada___eval(file_1916);
}


/* expand-define-expander */obj_t expand_define_expander_27___eval(obj_t x_12, obj_t e_13)
{
{
obj_t name_587;
obj_t macro_588;
if(PAIRP(x_12)){
obj_t cdr_109_69_593;
cdr_109_69_593 = CDR(x_12);
if(PAIRP(cdr_109_69_593)){
obj_t car_112_152_595;
car_112_152_595 = CAR(cdr_109_69_593);
if(SYMBOLP(car_112_152_595)){
name_587 = car_112_152_595;
macro_588 = CDR(cdr_109_69_593);
{
obj_t expd_lam_214_598;
expd_lam_214_598 = normalize_progn_143___progn(macro_588);
{
obj_t expd_lam_loc_197_599;
expd_lam_loc_197_599 = replace__160___progn(x_12, expd_lam_214_598);
{
obj_t expd_eval_73_600;
expd_eval_73_600 = eval___eval(expd_lam_loc_197_599, BNIL);
{
{
obj_t arg1231_1922;
arg1231_1922 = make_fx_procedure(arg1231___eval, ((long)2), ((long)3));
PROCEDURE_SET(arg1231_1922, ((long)0), expd_eval_73_600);
PROCEDURE_SET(arg1231_1922, ((long)1), name_587);
PROCEDURE_SET(arg1231_1922, ((long)2), macro_588);
install_expander_245___macro(name_587, arg1231_1922);
}
}
}
}
}
return BUNSPEC;
}
 else {
FAILURE(string1813___eval,string1814___eval,x_12);}
}
 else {
FAILURE(string1813___eval,string1814___eval,x_12);}
}
 else {
FAILURE(string1813___eval,string1814___eval,x_12);}
}
}


/* _expand-define-expander */obj_t _expand_define_expander_206___eval(obj_t env_1923, obj_t x_1924, obj_t e_1925)
{
return expand_define_expander_27___eval(x_1924, e_1925);
}


/* arg1231 */obj_t arg1231___eval(obj_t env_1926, obj_t x_1930, obj_t e_1931)
{
{
obj_t expd_eval_73_1927;
obj_t name_1928;
obj_t macro_1929;
expd_eval_73_1927 = PROCEDURE_REF(env_1926, ((long)0));
name_1928 = PROCEDURE_REF(env_1926, ((long)1));
macro_1929 = PROCEDURE_REF(env_1926, ((long)2));
{
obj_t x_602;
obj_t e_603;
x_602 = x_1930;
e_603 = e_1931;
if(PROCEDUREP(expd_eval_73_1927)){
bool_t test1234_606;
test1234_606 = PROCEDURE_CORRECT_ARITYP(expd_eval_73_1927, ((long)2));
if(test1234_606){
obj_t armed1043_607;
armed1043_607 = MAKE_CELL(BUNSPEC);
{
obj_t body1042_1920;
obj_t rhandler1041_1918;
body1042_1920 = make_fx_procedure(body1042___eval, ((long)0), ((long)3));
rhandler1041_1918 = make_fx_procedure(rhandler1041___eval, ((long)4), ((long)2));
PROCEDURE_SET(body1042_1920, ((long)0), expd_eval_73_1927);
PROCEDURE_SET(body1042_1920, ((long)1), x_602);
PROCEDURE_SET(body1042_1920, ((long)2), e_603);
PROCEDURE_SET(rhandler1041_1918, ((long)0), armed1043_607);
PROCEDURE_SET(rhandler1041_1918, ((long)1), x_602);
CELL_SET(armed1043_607, BTRUE);
return handling_function1235___eval(body1042_1920, rhandler1041_1918, x_602, armed1043_607);
}
}
 else {
FAILURE(name_1928,string1815___eval,macro_1929);}
}
 else {
FAILURE(name_1928,string1816___eval,macro_1929);}
}
}
}


/* handling_function1235 */obj_t handling_function1235___eval(obj_t body1042_2085, obj_t rhandler1041_2084, obj_t x_2083, obj_t armed1043_2082)
{
jmp_buf jmpbuf;
obj_t an_exit1044_612;
if( SET_EXIT(an_exit1044_612) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1044_612 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1044_612, ((bool_t)1));
{
obj_t an_exitd1045_613;
an_exitd1045_613 = exitd_top;
{
obj_t escape_1917;
escape_1917 = make_fx_procedure(escape_1786___eval, ((long)1), ((long)1));
PROCEDURE_SET(escape_1917, ((long)0), an_exitd1045_613);
{
obj_t res1047_616;
{
obj_t arg1238_1921;
obj_t arg1236_1919;
arg1238_1921 = make_fx_procedure(arg1238___eval, ((long)0), ((long)1));
arg1236_1919 = make_fx_procedure(arg1236___eval, ((long)0), ((long)5));
PROCEDURE_SET(arg1238_1921, ((long)0), armed1043_2082);
PROCEDURE_SET(arg1236_1919, ((long)0), an_exitd1045_613);
PROCEDURE_SET(arg1236_1919, ((long)1), armed1043_2082);
PROCEDURE_SET(arg1236_1919, ((long)2), x_2083);
PROCEDURE_SET(arg1236_1919, ((long)3), rhandler1041_2084);
PROCEDURE_SET(arg1236_1919, ((long)4), escape_1917);
res1047_616 = dynamic_wind_31___r4_control_features_6_9(arg1236_1919, body1042_2085, arg1238_1921);
}
POP_EXIT();
return res1047_616;
}
}
}
}
}
}


/* arg1238 */obj_t arg1238___eval(obj_t env_1933)
{
{
obj_t armed1043_1934;
armed1043_1934 = PROCEDURE_REF(env_1933, ((long)0));
{
{
bool_t test_2545;
{
obj_t aux_2546;
aux_2546 = CELL_REF(armed1043_1934);
test_2545 = CBOOL(aux_2546);
}
if(test_2545){
CELL_SET(armed1043_1934, BFALSE);
return remove_error_handler__102___error();
}
 else {
return BUNSPEC;
}
}
}
}
}


/* body1042 */obj_t body1042___eval(obj_t env_1936)
{
{
obj_t expd_eval_73_1937;
obj_t x_1938;
obj_t e_1939;
expd_eval_73_1937 = PROCEDURE_REF(env_1936, ((long)0));
x_1938 = PROCEDURE_REF(env_1936, ((long)1));
e_1939 = PROCEDURE_REF(env_1936, ((long)2));
{
return PROCEDURE_ENTRY(expd_eval_73_1937)(expd_eval_73_1937, x_1938, e_1939, BEOA);
}
}
}


/* arg1236 */obj_t arg1236___eval(obj_t env_1940)
{
{
obj_t rhandler1041_1944;
obj_t escape_1945;
rhandler1041_1944 = PROCEDURE_REF(env_1940, ((long)3));
escape_1945 = PROCEDURE_REF(env_1940, ((long)4));
{
return add_error_handler__155___error(rhandler1041_1944, escape_1945);
}
}
}


/* escape_1786 */obj_t escape_1786___eval(obj_t env_1946, obj_t val1046_1948)
{
{
obj_t an_exitd1045_1947;
an_exitd1045_1947 = PROCEDURE_REF(env_1946, ((long)0));
{
obj_t val1046_614;
val1046_614 = val1046_1948;
return unwind_until__178___bexit(an_exitd1045_1947, val1046_614);
}
}
}


/* rhandler1041 */obj_t rhandler1041___eval(obj_t env_1949, obj_t esc_1952, obj_t obj_1953, obj_t proc_1954, obj_t msg_1955)
{
{
obj_t armed1043_1950;
obj_t x_1951;
armed1043_1950 = PROCEDURE_REF(env_1949, ((long)0));
x_1951 = PROCEDURE_REF(env_1949, ((long)1));
{
obj_t esc_628;
obj_t obj_629;
obj_t proc_630;
obj_t msg_631;
esc_628 = esc_1952;
obj_629 = obj_1953;
proc_630 = proc_1954;
msg_631 = msg_1955;
CELL_SET(armed1043_1950, BFALSE);
remove_error_handler__102___error();
evmeaning_notify_error_24___evmeaning(obj_629, proc_630, msg_631);
FAILURE(string1817___eval,string1818___eval,x_1951);}
}
}


/* expand-define-macro */obj_t expand_define_macro_35___eval(obj_t x_14, obj_t e_15)
{
{
obj_t name_639;
obj_t args_640;
obj_t body_641;
if(PAIRP(x_14)){
obj_t cdr_132_143_646;
cdr_132_143_646 = CDR(x_14);
if(PAIRP(cdr_132_143_646)){
obj_t car_136_42_648;
car_136_42_648 = CAR(cdr_132_143_646);
if(PAIRP(car_136_42_648)){
name_639 = CAR(car_136_42_648);
args_640 = CDR(car_136_42_648);
body_641 = CDR(cdr_132_143_646);
tag_118_180_642:
{
obj_t arg1267_669;
{
obj_t expd_lam_214_670;
{
obj_t arg1281_707;
obj_t arg1282_708;
obj_t arg1283_709;
arg1281_707 = symbol1819___eval;
{
obj_t arg1290_715;
obj_t arg1291_716;
arg1290_715 = symbol1820___eval;
arg1291_716 = symbol1821___eval;
{
obj_t list1293_718;
{
obj_t arg1294_719;
arg1294_719 = MAKE_PAIR(BNIL, BNIL);
list1293_718 = MAKE_PAIR(arg1291_716, arg1294_719);
}
arg1282_708 = cons__138___r4_pairs_and_lists_6_3(arg1290_715, list1293_718);
}
}
{
obj_t arg1296_721;
obj_t arg1297_722;
obj_t arg1298_723;
arg1296_721 = symbol1821___eval;
{
obj_t arg1304_729;
obj_t arg1307_730;
obj_t arg1308_731;
arg1304_729 = symbol1822___eval;
arg1307_730 = destructure___eval(args_640, list1823___eval, BNIL);
arg1308_731 = normalize_progn_143___progn(body_641);
{
obj_t list1310_733;
{
obj_t arg1311_734;
{
obj_t arg1313_735;
arg1313_735 = MAKE_PAIR(BNIL, BNIL);
arg1311_734 = MAKE_PAIR(arg1308_731, arg1313_735);
}
list1310_733 = MAKE_PAIR(arg1307_730, arg1311_734);
}
arg1297_722 = cons__138___r4_pairs_and_lists_6_3(arg1304_729, list1310_733);
}
}
arg1298_723 = symbol1821___eval;
{
obj_t list1300_725;
{
obj_t arg1301_726;
{
obj_t arg1302_727;
arg1302_727 = MAKE_PAIR(BNIL, BNIL);
arg1301_726 = MAKE_PAIR(arg1298_723, arg1302_727);
}
list1300_725 = MAKE_PAIR(arg1297_722, arg1301_726);
}
arg1283_709 = cons__138___r4_pairs_and_lists_6_3(arg1296_721, list1300_725);
}
}
{
obj_t list1285_711;
{
obj_t arg1286_712;
{
obj_t arg1287_713;
arg1287_713 = MAKE_PAIR(BNIL, BNIL);
arg1286_712 = MAKE_PAIR(arg1283_709, arg1287_713);
}
list1285_711 = MAKE_PAIR(arg1282_708, arg1286_712);
}
expd_lam_214_670 = cons__138___r4_pairs_and_lists_6_3(arg1281_707, list1285_711);
}
}
{
obj_t expd_lam_loc_197_671;
expd_lam_loc_197_671 = replace__160___progn(x_14, expd_lam_214_670);
{
obj_t expd_eval_73_672;
expd_eval_73_672 = eval___eval(expd_lam_loc_197_671, BNIL);
{
{
obj_t lambda1268_1962;
lambda1268_1962 = make_fx_procedure(lambda1268___eval, ((long)2), ((long)1));
PROCEDURE_SET(lambda1268_1962, ((long)0), expd_eval_73_672);
arg1267_669 = lambda1268_1962;
}
}
}
}
}
install_expander_245___macro(name_639, arg1267_669);
}
return BUNSPEC;
}
 else {
obj_t cdr_154_75_654;
cdr_154_75_654 = CDR(cdr_132_143_646);
if(PAIRP(cdr_154_75_654)){
obj_t car_158_189_656;
car_158_189_656 = CAR(cdr_154_75_654);
if(PAIRP(car_158_189_656)){
obj_t cdr_163_25_658;
cdr_163_25_658 = CDR(car_158_189_656);
{
bool_t test_2604;
{
obj_t aux_2605;
aux_2605 = CAR(car_158_189_656);
test_2604 = (aux_2605==symbol1819___eval);
}
if(test_2604){
if(PAIRP(cdr_163_25_658)){
bool_t test_2610;
{
obj_t aux_2611;
aux_2611 = CDR(cdr_154_75_654);
test_2610 = (aux_2611==BNIL);
}
if(test_2610){
obj_t body_2618;
obj_t args_2616;
obj_t name_2614;
name_2614 = CAR(cdr_132_143_646);
args_2616 = CAR(cdr_163_25_658);
body_2618 = CDR(cdr_163_25_658);
body_641 = body_2618;
args_640 = args_2616;
name_639 = name_2614;
goto tag_118_180_642;
}
 else {
FAILURE(string1825___eval,string1826___eval,x_14);}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_14);}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_14);}
}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_14);}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_14);}
}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_14);}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_14);}
}
}


/* _expand-define-macro */obj_t _expand_define_macro_10___eval(obj_t env_1963, obj_t x_1964, obj_t e_1965)
{
return expand_define_macro_35___eval(x_1964, e_1965);
}


/* lambda1268 */obj_t lambda1268___eval(obj_t env_1966, obj_t x_1968, obj_t e_1969)
{
{
obj_t expd_eval_73_1967;
expd_eval_73_1967 = PROCEDURE_REF(env_1966, ((long)0));
{
obj_t x_673;
obj_t e_674;
x_673 = x_1968;
e_674 = e_1969;
{
obj_t armed1051_676;
armed1051_676 = MAKE_CELL(BUNSPEC);
{
obj_t body1050_1960;
obj_t rhandler1049_1958;
body1050_1960 = make_fx_procedure(body1050___eval, ((long)0), ((long)3));
rhandler1049_1958 = make_fx_procedure(rhandler1049___eval, ((long)4), ((long)2));
PROCEDURE_SET(body1050_1960, ((long)0), expd_eval_73_1967);
PROCEDURE_SET(body1050_1960, ((long)1), x_673);
PROCEDURE_SET(body1050_1960, ((long)2), e_674);
PROCEDURE_SET(rhandler1049_1958, ((long)0), armed1051_676);
PROCEDURE_SET(rhandler1049_1958, ((long)1), x_673);
CELL_SET(armed1051_676, BTRUE);
return handling_function1269___eval(body1050_1960, rhandler1049_1958, x_673, armed1051_676);
}
}
}
}
}


/* handling_function1269 */obj_t handling_function1269___eval(obj_t body1050_2081, obj_t rhandler1049_2080, obj_t x_2079, obj_t armed1051_2078)
{
jmp_buf jmpbuf;
obj_t an_exit1052_681;
if( SET_EXIT(an_exit1052_681) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1052_681 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1052_681, ((bool_t)1));
{
obj_t an_exitd1053_682;
an_exitd1053_682 = exitd_top;
{
obj_t escape_1957;
escape_1957 = make_fx_procedure(escape_1787___eval, ((long)1), ((long)1));
PROCEDURE_SET(escape_1957, ((long)0), an_exitd1053_682);
{
obj_t res1055_685;
{
obj_t arg1272_1961;
obj_t arg1270_1959;
arg1272_1961 = make_fx_procedure(arg1272___eval, ((long)0), ((long)1));
arg1270_1959 = make_fx_procedure(arg1270___eval, ((long)0), ((long)5));
PROCEDURE_SET(arg1272_1961, ((long)0), armed1051_2078);
PROCEDURE_SET(arg1270_1959, ((long)0), an_exitd1053_682);
PROCEDURE_SET(arg1270_1959, ((long)1), armed1051_2078);
PROCEDURE_SET(arg1270_1959, ((long)2), x_2079);
PROCEDURE_SET(arg1270_1959, ((long)3), rhandler1049_2080);
PROCEDURE_SET(arg1270_1959, ((long)4), escape_1957);
res1055_685 = dynamic_wind_31___r4_control_features_6_9(arg1270_1959, body1050_2081, arg1272_1961);
}
POP_EXIT();
return res1055_685;
}
}
}
}
}
}


/* arg1272 */obj_t arg1272___eval(obj_t env_1971)
{
{
obj_t armed1051_1972;
armed1051_1972 = PROCEDURE_REF(env_1971, ((long)0));
{
{
bool_t test_2653;
{
obj_t aux_2654;
aux_2654 = CELL_REF(armed1051_1972);
test_2653 = CBOOL(aux_2654);
}
if(test_2653){
CELL_SET(armed1051_1972, BFALSE);
return remove_error_handler__102___error();
}
 else {
return BUNSPEC;
}
}
}
}
}


/* body1050 */obj_t body1050___eval(obj_t env_1974)
{
{
obj_t expd_eval_73_1975;
obj_t x_1976;
obj_t e_1977;
expd_eval_73_1975 = PROCEDURE_REF(env_1974, ((long)0));
x_1976 = PROCEDURE_REF(env_1974, ((long)1));
e_1977 = PROCEDURE_REF(env_1974, ((long)2));
{
return PROCEDURE_ENTRY(expd_eval_73_1975)(expd_eval_73_1975, x_1976, e_1977, BEOA);
}
}
}


/* arg1270 */obj_t arg1270___eval(obj_t env_1978)
{
{
obj_t rhandler1049_1982;
obj_t escape_1983;
rhandler1049_1982 = PROCEDURE_REF(env_1978, ((long)3));
escape_1983 = PROCEDURE_REF(env_1978, ((long)4));
{
return add_error_handler__155___error(rhandler1049_1982, escape_1983);
}
}
}


/* escape_1787 */obj_t escape_1787___eval(obj_t env_1984, obj_t val1054_1986)
{
{
obj_t an_exitd1053_1985;
an_exitd1053_1985 = PROCEDURE_REF(env_1984, ((long)0));
{
obj_t val1054_683;
val1054_683 = val1054_1986;
return unwind_until__178___bexit(an_exitd1053_1985, val1054_683);
}
}
}


/* rhandler1049 */obj_t rhandler1049___eval(obj_t env_1987, obj_t esc_1990, obj_t obj_1991, obj_t proc_1992, obj_t msg_1993)
{
{
obj_t armed1051_1988;
obj_t x_1989;
armed1051_1988 = PROCEDURE_REF(env_1987, ((long)0));
x_1989 = PROCEDURE_REF(env_1987, ((long)1));
{
obj_t esc_697;
obj_t obj_698;
obj_t proc_699;
obj_t msg_700;
esc_697 = esc_1990;
obj_698 = obj_1991;
proc_699 = proc_1992;
msg_700 = msg_1993;
CELL_SET(armed1051_1988, BFALSE);
remove_error_handler__102___error();
evmeaning_notify_error_24___evmeaning(obj_698, proc_699, msg_700);
FAILURE(string1817___eval,string1818___eval,x_1989);}
}
}


/* expand-define-hygien-macro */obj_t expand_define_hygien_macro_18___eval(obj_t x_16, obj_t e_17)
{
{
obj_t name_739;
obj_t args_740;
obj_t body_741;
if(PAIRP(x_16)){
obj_t cdr_186_81_746;
cdr_186_81_746 = CDR(x_16);
if(PAIRP(cdr_186_81_746)){
obj_t car_190_111_748;
car_190_111_748 = CAR(cdr_186_81_746);
if(PAIRP(car_190_111_748)){
obj_t cdr_195_37_750;
cdr_195_37_750 = CDR(car_190_111_748);
{
bool_t test_2681;
{
obj_t aux_2682;
aux_2682 = CAR(car_190_111_748);
test_2681 = (aux_2682==symbol1827___eval);
}
if(test_2681){
if(PAIRP(cdr_195_37_750)){
obj_t car_198_19_753;
car_198_19_753 = CAR(cdr_195_37_750);
if(PAIRP(car_198_19_753)){
bool_t test_2690;
{
obj_t aux_2691;
aux_2691 = CDR(cdr_195_37_750);
test_2690 = (aux_2691==BNIL);
}
if(test_2690){
name_739 = CAR(car_198_19_753);
args_740 = CDR(car_198_19_753);
body_741 = CDR(cdr_186_81_746);
{
obj_t body_763;
if(NULLP(body_741)){
body_763 = BNIL;
}
 else {
obj_t head1058_836;
{
obj_t aux_2696;
{
obj_t aux_2697;
{
obj_t aux_2698;
aux_2698 = CAR(body_741);
aux_2697 = CDR(aux_2698);
}
aux_2696 = CAR(aux_2697);
}
head1058_836 = MAKE_PAIR(aux_2696, BNIL);
}
{
obj_t l1056_1510;
obj_t tail1059_1511;
l1056_1510 = CDR(body_741);
tail1059_1511 = head1058_836;
lname1057_1509:
if(NULLP(l1056_1510)){
body_763 = head1058_836;
}
 else {
obj_t newtail1060_1519;
{
obj_t aux_2705;
{
obj_t aux_2706;
{
obj_t aux_2707;
aux_2707 = CAR(l1056_1510);
aux_2706 = CDR(aux_2707);
}
aux_2705 = CAR(aux_2706);
}
newtail1060_1519 = MAKE_PAIR(aux_2705, BNIL);
}
SET_CDR(tail1059_1511, newtail1060_1519);
{
obj_t tail1059_2715;
obj_t l1056_2713;
l1056_2713 = CDR(l1056_1510);
tail1059_2715 = newtail1060_1519;
tail1059_1511 = tail1059_2715;
l1056_1510 = l1056_2713;
goto lname1057_1509;
}
}
}
}
{
obj_t arg1339_764;
{
obj_t expd_lam_214_765;
{
obj_t arg1350_802;
obj_t arg1351_803;
obj_t arg1352_804;
arg1350_802 = symbol1819___eval;
{
obj_t arg1361_810;
obj_t arg1363_811;
arg1361_810 = symbol1820___eval;
arg1363_811 = symbol1821___eval;
{
obj_t list1365_813;
{
obj_t arg1367_814;
arg1367_814 = MAKE_PAIR(BNIL, BNIL);
list1365_813 = MAKE_PAIR(arg1363_811, arg1367_814);
}
arg1351_803 = cons__138___r4_pairs_and_lists_6_3(arg1361_810, list1365_813);
}
}
{
obj_t arg1369_816;
obj_t arg1370_817;
obj_t arg1372_818;
arg1369_816 = symbol1821___eval;
{
obj_t arg1381_824;
obj_t arg1383_825;
obj_t arg1384_826;
arg1381_824 = symbol1822___eval;
arg1383_825 = destructure___eval(args_740, list1823___eval, BNIL);
arg1384_826 = normalize_progn_143___progn(body_763);
{
obj_t list1386_828;
{
obj_t arg1387_829;
{
obj_t arg1388_830;
arg1388_830 = MAKE_PAIR(BNIL, BNIL);
arg1387_829 = MAKE_PAIR(arg1384_826, arg1388_830);
}
list1386_828 = MAKE_PAIR(arg1383_825, arg1387_829);
}
arg1370_817 = cons__138___r4_pairs_and_lists_6_3(arg1381_824, list1386_828);
}
}
arg1372_818 = symbol1821___eval;
{
obj_t list1374_820;
{
obj_t arg1375_821;
{
obj_t arg1378_822;
arg1378_822 = MAKE_PAIR(BNIL, BNIL);
arg1375_821 = MAKE_PAIR(arg1372_818, arg1378_822);
}
list1374_820 = MAKE_PAIR(arg1370_817, arg1375_821);
}
arg1352_804 = cons__138___r4_pairs_and_lists_6_3(arg1369_816, list1374_820);
}
}
{
obj_t list1354_806;
{
obj_t arg1355_807;
{
obj_t arg1356_808;
arg1356_808 = MAKE_PAIR(BNIL, BNIL);
arg1355_807 = MAKE_PAIR(arg1352_804, arg1356_808);
}
list1354_806 = MAKE_PAIR(arg1351_803, arg1355_807);
}
expd_lam_214_765 = cons__138___r4_pairs_and_lists_6_3(arg1350_802, list1354_806);
}
}
{
obj_t expd_lam_loc_197_766;
expd_lam_loc_197_766 = replace__160___progn(x_16, expd_lam_214_765);
{
obj_t expd_eval_73_767;
expd_eval_73_767 = eval___eval(expd_lam_loc_197_766, BNIL);
{
{
obj_t lambda1340_2000;
lambda1340_2000 = make_fx_procedure(lambda1340___eval, ((long)2), ((long)1));
PROCEDURE_SET(lambda1340_2000, ((long)0), expd_eval_73_767);
arg1339_764 = lambda1340_2000;
}
}
}
}
}
install_expander_245___macro(name_739, arg1339_764);
}
return BUNSPEC;
}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_16);}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_16);}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_16);}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_16);}
}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_16);}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_16);}
}
 else {
FAILURE(string1825___eval,string1826___eval,x_16);}
}
}


/* _expand-define-hygien-macro */obj_t _expand_define_hygien_macro_7___eval(obj_t env_2001, obj_t x_2002, obj_t e_2003)
{
return expand_define_hygien_macro_18___eval(x_2002, e_2003);
}


/* lambda1340 */obj_t lambda1340___eval(obj_t env_2004, obj_t x_2006, obj_t e_2007)
{
{
obj_t expd_eval_73_2005;
expd_eval_73_2005 = PROCEDURE_REF(env_2004, ((long)0));
{
obj_t x_768;
obj_t e_769;
x_768 = x_2006;
e_769 = e_2007;
{
obj_t armed1064_771;
armed1064_771 = MAKE_CELL(BUNSPEC);
{
obj_t body1063_1998;
obj_t rhandler1062_1996;
body1063_1998 = make_fx_procedure(body1063___eval, ((long)0), ((long)3));
rhandler1062_1996 = make_fx_procedure(rhandler1062___eval, ((long)4), ((long)2));
PROCEDURE_SET(body1063_1998, ((long)0), expd_eval_73_2005);
PROCEDURE_SET(body1063_1998, ((long)1), x_768);
PROCEDURE_SET(body1063_1998, ((long)2), e_769);
PROCEDURE_SET(rhandler1062_1996, ((long)0), armed1064_771);
PROCEDURE_SET(rhandler1062_1996, ((long)1), x_768);
CELL_SET(armed1064_771, BTRUE);
return handling_function1341___eval(body1063_1998, rhandler1062_1996, x_768, armed1064_771);
}
}
}
}
}


/* handling_function1341 */obj_t handling_function1341___eval(obj_t body1063_2077, obj_t rhandler1062_2076, obj_t x_2075, obj_t armed1064_2074)
{
jmp_buf jmpbuf;
obj_t an_exit1065_776;
if( SET_EXIT(an_exit1065_776) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1065_776 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1065_776, ((bool_t)1));
{
obj_t an_exitd1066_777;
an_exitd1066_777 = exitd_top;
{
obj_t escape_1995;
escape_1995 = make_fx_procedure(escape_1788___eval, ((long)1), ((long)1));
PROCEDURE_SET(escape_1995, ((long)0), an_exitd1066_777);
{
obj_t res1068_780;
{
obj_t arg1343_1999;
obj_t arg1342_1997;
arg1343_1999 = make_fx_procedure(arg1343___eval, ((long)0), ((long)1));
arg1342_1997 = make_fx_procedure(arg1342___eval, ((long)0), ((long)5));
PROCEDURE_SET(arg1343_1999, ((long)0), armed1064_2074);
PROCEDURE_SET(arg1342_1997, ((long)0), an_exitd1066_777);
PROCEDURE_SET(arg1342_1997, ((long)1), armed1064_2074);
PROCEDURE_SET(arg1342_1997, ((long)2), x_2075);
PROCEDURE_SET(arg1342_1997, ((long)3), rhandler1062_2076);
PROCEDURE_SET(arg1342_1997, ((long)4), escape_1995);
res1068_780 = dynamic_wind_31___r4_control_features_6_9(arg1342_1997, body1063_2077, arg1343_1999);
}
POP_EXIT();
return res1068_780;
}
}
}
}
}
}


/* arg1343 */obj_t arg1343___eval(obj_t env_2009)
{
{
obj_t armed1064_2010;
armed1064_2010 = PROCEDURE_REF(env_2009, ((long)0));
{
{
bool_t test_2775;
{
obj_t aux_2776;
aux_2776 = CELL_REF(armed1064_2010);
test_2775 = CBOOL(aux_2776);
}
if(test_2775){
CELL_SET(armed1064_2010, BFALSE);
return remove_error_handler__102___error();
}
 else {
return BUNSPEC;
}
}
}
}
}


/* body1063 */obj_t body1063___eval(obj_t env_2012)
{
{
obj_t expd_eval_73_2013;
obj_t x_2014;
obj_t e_2015;
expd_eval_73_2013 = PROCEDURE_REF(env_2012, ((long)0));
x_2014 = PROCEDURE_REF(env_2012, ((long)1));
e_2015 = PROCEDURE_REF(env_2012, ((long)2));
{
return PROCEDURE_ENTRY(expd_eval_73_2013)(expd_eval_73_2013, x_2014, e_2015, BEOA);
}
}
}


/* arg1342 */obj_t arg1342___eval(obj_t env_2016)
{
{
obj_t rhandler1062_2020;
obj_t escape_2021;
rhandler1062_2020 = PROCEDURE_REF(env_2016, ((long)3));
escape_2021 = PROCEDURE_REF(env_2016, ((long)4));
{
return add_error_handler__155___error(rhandler1062_2020, escape_2021);
}
}
}


/* escape_1788 */obj_t escape_1788___eval(obj_t env_2022, obj_t val1067_2024)
{
{
obj_t an_exitd1066_2023;
an_exitd1066_2023 = PROCEDURE_REF(env_2022, ((long)0));
{
obj_t val1067_778;
val1067_778 = val1067_2024;
return unwind_until__178___bexit(an_exitd1066_2023, val1067_778);
}
}
}


/* rhandler1062 */obj_t rhandler1062___eval(obj_t env_2025, obj_t esc_2028, obj_t obj_2029, obj_t proc_2030, obj_t msg_2031)
{
{
obj_t armed1064_2026;
obj_t x_2027;
armed1064_2026 = PROCEDURE_REF(env_2025, ((long)0));
x_2027 = PROCEDURE_REF(env_2025, ((long)1));
{
obj_t esc_792;
obj_t obj_793;
obj_t proc_794;
obj_t msg_795;
esc_792 = esc_2028;
obj_793 = obj_2029;
proc_794 = proc_2030;
msg_795 = msg_2031;
CELL_SET(armed1064_2026, BFALSE);
remove_error_handler__102___error();
evmeaning_notify_error_24___evmeaning(obj_793, proc_794, msg_795);
FAILURE(string1817___eval,string1818___eval,x_2027);}
}
}


/* destructure */obj_t destructure___eval(obj_t pat_18, obj_t arg_19, obj_t bindings_20)
{
destructure___eval:
if(NULLP(pat_18)){
{
obj_t arg1405_851;
{
obj_t arg1407_852;
obj_t arg1408_853;
arg1407_852 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1828___eval, BEOA);
{
obj_t arg1416_859;
obj_t arg1417_860;
obj_t arg1418_861;
obj_t arg1419_862;
arg1416_859 = symbol1829___eval;
{
obj_t arg1431_869;
obj_t arg1432_870;
arg1431_869 = symbol1830___eval;
{
obj_t arg1438_875;
arg1438_875 = symbol1831___eval;
{
obj_t list1441_877;
{
obj_t arg1443_878;
arg1443_878 = MAKE_PAIR(BNIL, BNIL);
list1441_877 = MAKE_PAIR(arg_19, arg1443_878);
}
arg1432_870 = cons__138___r4_pairs_and_lists_6_3(arg1438_875, list1441_877);
}
}
{
obj_t list1434_872;
{
obj_t arg1436_873;
arg1436_873 = MAKE_PAIR(BNIL, BNIL);
list1434_872 = MAKE_PAIR(arg1432_870, arg1436_873);
}
arg1417_860 = cons__138___r4_pairs_and_lists_6_3(arg1431_869, list1434_872);
}
}
{
obj_t arg1446_880;
arg1446_880 = symbol1832___eval;
{
obj_t list1451_884;
{
obj_t arg1453_885;
{
obj_t arg1454_886;
{
obj_t arg1455_887;
arg1455_887 = MAKE_PAIR(BNIL, BNIL);
arg1454_886 = MAKE_PAIR(arg_19, arg1455_887);
}
arg1453_885 = MAKE_PAIR(string1833___eval, arg1454_886);
}
list1451_884 = MAKE_PAIR(string1817___eval, arg1453_885);
}
arg1418_861 = cons__138___r4_pairs_and_lists_6_3(arg1446_880, list1451_884);
}
}
{
obj_t arg1458_889;
arg1458_889 = symbol1827___eval;
{
obj_t list1462_892;
{
obj_t arg1463_893;
arg1463_893 = MAKE_PAIR(BNIL, BNIL);
list1462_892 = MAKE_PAIR(BNIL, arg1463_893);
}
arg1419_862 = cons__138___r4_pairs_and_lists_6_3(arg1458_889, list1462_892);
}
}
{
obj_t list1422_864;
{
obj_t arg1423_865;
{
obj_t arg1426_866;
{
obj_t arg1427_867;
arg1427_867 = MAKE_PAIR(BNIL, BNIL);
arg1426_866 = MAKE_PAIR(arg1419_862, arg1427_867);
}
arg1423_865 = MAKE_PAIR(arg1418_861, arg1426_866);
}
list1422_864 = MAKE_PAIR(arg1417_860, arg1423_865);
}
arg1408_853 = cons__138___r4_pairs_and_lists_6_3(arg1416_859, list1422_864);
}
}
{
obj_t list1411_855;
{
obj_t arg1413_856;
arg1413_856 = MAKE_PAIR(BNIL, BNIL);
list1411_855 = MAKE_PAIR(arg1408_853, arg1413_856);
}
arg1405_851 = cons__138___r4_pairs_and_lists_6_3(arg1407_852, list1411_855);
}
}
return MAKE_PAIR(arg1405_851, bindings_20);
}
}
 else {
if(SYMBOLP(pat_18)){
{
obj_t arg1466_896;
{
obj_t list1468_898;
{
obj_t arg1469_899;
arg1469_899 = MAKE_PAIR(BNIL, BNIL);
list1468_898 = MAKE_PAIR(arg_19, arg1469_899);
}
arg1466_896 = cons__138___r4_pairs_and_lists_6_3(pat_18, list1468_898);
}
return MAKE_PAIR(arg1466_896, bindings_20);
}
}
 else {
if(PAIRP(pat_18)){
{
obj_t arg1473_902;
obj_t arg1474_903;
obj_t arg1475_904;
arg1473_902 = CAR(pat_18);
{
obj_t arg1476_905;
arg1476_905 = symbol1834___eval;
{
obj_t list1478_907;
{
obj_t arg1479_908;
arg1479_908 = MAKE_PAIR(BNIL, BNIL);
list1478_907 = MAKE_PAIR(arg_19, arg1479_908);
}
arg1474_903 = cons__138___r4_pairs_and_lists_6_3(arg1476_905, list1478_907);
}
}
{
obj_t arg1481_910;
obj_t arg1483_911;
arg1481_910 = CDR(pat_18);
{
obj_t arg1484_912;
arg1484_912 = symbol1824___eval;
{
obj_t list1486_914;
{
obj_t arg1487_915;
arg1487_915 = MAKE_PAIR(BNIL, BNIL);
list1486_914 = MAKE_PAIR(arg_19, arg1487_915);
}
arg1483_911 = cons__138___r4_pairs_and_lists_6_3(arg1484_912, list1486_914);
}
}
arg1475_904 = destructure___eval(arg1481_910, arg1483_911, bindings_20);
}
{
obj_t bindings_2840;
obj_t arg_2839;
obj_t pat_2838;
pat_2838 = arg1473_902;
arg_2839 = arg1474_903;
bindings_2840 = arg1475_904;
bindings_20 = bindings_2840;
arg_19 = arg_2839;
pat_18 = pat_2838;
goto destructure___eval;
}
}
}
 else {
return BFALSE;
}
}
}
}


/* module-declaration! */obj_t module_declaration__32___eval(obj_t decls_21)
{
{
obj_t decls_917;
decls_917 = decls_21;
loop_918:
if(NULLP(decls_917)){
return symbol1835___eval;
}
 else {
bool_t test_2843;
{
obj_t aux_2844;
aux_2844 = CAR(decls_917);
test_2843 = PAIRP(aux_2844);
}
if(test_2843){
bool_t test_2847;
{
obj_t aux_2848;
{
obj_t aux_2849;
aux_2849 = CAR(decls_917);
aux_2848 = CAR(aux_2849);
}
test_2847 = (aux_2848==symbol1836___eval);
}
if(test_2847){
{
obj_t aux_2853;
{
obj_t aux_2854;
aux_2854 = CAR(decls_917);
aux_2853 = CDR(aux_2854);
}
include__198___eval(aux_2853);
}
{
obj_t decls_2858;
decls_2858 = CDR(decls_917);
decls_917 = decls_2858;
goto loop_918;
}
}
 else {
bool_t test_2860;
{
obj_t aux_2861;
{
obj_t aux_2862;
aux_2862 = CAR(decls_917);
aux_2861 = CAR(aux_2862);
}
test_2860 = (aux_2861==symbol1837___eval);
}
if(test_2860){
{
obj_t aux_2866;
{
obj_t aux_2867;
aux_2867 = CAR(decls_917);
aux_2866 = CDR(aux_2867);
}
import__31___eval(aux_2866);
}
{
obj_t decls_2871;
decls_2871 = CDR(decls_917);
decls_917 = decls_2871;
goto loop_918;
}
}
 else {
bool_t test_2873;
{
obj_t aux_2874;
{
obj_t aux_2875;
aux_2875 = CAR(decls_917);
aux_2874 = CAR(aux_2875);
}
test_2873 = (aux_2874==symbol1838___eval);
}
if(test_2873){
{
obj_t aux_2879;
{
obj_t aux_2880;
aux_2880 = CAR(decls_917);
aux_2879 = CDR(aux_2880);
}
import__31___eval(aux_2879);
}
{
obj_t decls_2884;
decls_2884 = CDR(decls_917);
decls_917 = decls_2884;
goto loop_918;
}
}
 else {
{
obj_t decls_2886;
decls_2886 = CDR(decls_917);
decls_917 = decls_2886;
goto loop_918;
}
}
}
}
}
 else {
FAILURE(string1797___eval,string1839___eval,decls_917);}
}
}
}


/* _module-declaration! */obj_t _module_declaration__185___eval(obj_t env_2033, obj_t decls_2034)
{
return module_declaration__32___eval(decls_2034);
}


/* include! */bool_t include__198___eval(obj_t includes_22)
{
{
obj_t l1069_944;
l1069_944 = includes_22;
lname1070_945:
if(PAIRP(l1069_944)){
{
obj_t i_947;
i_947 = CAR(l1069_944);
{
bool_t test1524_948;
{
obj_t aux_2893;
aux_2893 = member___r4_pairs_and_lists_6_3(i_947, _included_files__122___eval);
test1524_948 = CBOOL(aux_2893);
}
if(test1524_948){
BUNSPEC;
}
 else {
{
obj_t obj2_1625;
obj2_1625 = _included_files__122___eval;
_included_files__122___eval = MAKE_PAIR(i_947, obj2_1625);
}
loadv___eval(i_947, ((bool_t)0));
}
}
}
{
obj_t l1069_2899;
l1069_2899 = CDR(l1069_944);
l1069_944 = l1069_2899;
goto lname1070_945;
}
}
 else {
return ((bool_t)1);
}
}
}


/* import! */bool_t import__31___eval(obj_t iclauses_23)
{
{
obj_t l_950;
if(NULLP(iclauses_23)){
l_950 = BNIL;
}
 else {
obj_t head1073_961;
head1073_961 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1071_962;
obj_t tail1074_963;
l1071_962 = iclauses_23;
tail1074_963 = head1073_961;
lname1072_964:
if(NULLP(l1071_962)){
l_950 = CDR(head1073_961);
}
 else {
obj_t newtail1075_966;
{
obj_t arg1534_968;
{
obj_t i_970;
i_970 = CAR(l1071_962);
if(PAIRP(i_970)){
obj_t cdr_217_186_980;
cdr_217_186_980 = CDR(i_970);
if(PAIRP(cdr_217_186_980)){
bool_t test_2913;
{
obj_t aux_2914;
aux_2914 = CDR(cdr_217_186_980);
test_2913 = (aux_2914==BNIL);
}
if(test_2913){
obj_t arg1539_983;
arg1539_983 = CAR(cdr_217_186_980);
if(STRINGP(arg1539_983)){
arg1534_968 = arg1539_983;
}
 else {
obj_t cell_1643;
cell_1643 = assq___r4_pairs_and_lists_6_3(arg1539_983, _afile_list__205___eval);
if(PAIRP(cell_1643)){
obj_t aux_2923;
aux_2923 = CDR(cell_1643);
arg1534_968 = CAR(aux_2923);
}
 else {
arg1534_968 = BFALSE;
}
}
}
 else {
obj_t cdr_229_251_984;
cdr_229_251_984 = CDR(cdr_217_186_980);
if(PAIRP(cdr_229_251_984)){
bool_t test_2929;
{
obj_t aux_2930;
aux_2930 = CDR(cdr_229_251_984);
test_2929 = (aux_2930==BNIL);
}
if(test_2929){
arg1534_968 = CAR(cdr_229_251_984);
}
 else {
obj_t cell_1660;
cell_1660 = assq___r4_pairs_and_lists_6_3(i_970, _afile_list__205___eval);
if(PAIRP(cell_1660)){
obj_t aux_2937;
aux_2937 = CDR(cell_1660);
arg1534_968 = CAR(aux_2937);
}
 else {
arg1534_968 = BFALSE;
}
}
}
 else {
obj_t cell_1668;
cell_1668 = assq___r4_pairs_and_lists_6_3(i_970, _afile_list__205___eval);
if(PAIRP(cell_1668)){
obj_t aux_2943;
aux_2943 = CDR(cell_1668);
arg1534_968 = CAR(aux_2943);
}
 else {
arg1534_968 = BFALSE;
}
}
}
}
 else {
obj_t cell_1676;
cell_1676 = assq___r4_pairs_and_lists_6_3(i_970, _afile_list__205___eval);
if(PAIRP(cell_1676)){
obj_t aux_2949;
aux_2949 = CDR(cell_1676);
arg1534_968 = CAR(aux_2949);
}
 else {
arg1534_968 = BFALSE;
}
}
}
 else {
obj_t cell_1684;
cell_1684 = assq___r4_pairs_and_lists_6_3(i_970, _afile_list__205___eval);
if(PAIRP(cell_1684)){
obj_t aux_2955;
aux_2955 = CDR(cell_1684);
arg1534_968 = CAR(aux_2955);
}
 else {
arg1534_968 = BFALSE;
}
}
}
newtail1075_966 = MAKE_PAIR(arg1534_968, BNIL);
}
SET_CDR(tail1074_963, newtail1075_966);
{
obj_t tail1074_2962;
obj_t l1071_2960;
l1071_2960 = CDR(l1071_962);
tail1074_2962 = newtail1075_966;
tail1074_963 = tail1074_2962;
l1071_962 = l1071_2960;
goto lname1072_964;
}
}
}
}
{
obj_t l1076_951;
l1076_951 = l_950;
lname1077_952:
if(PAIRP(l1076_951)){
{
obj_t i_954;
i_954 = CAR(l1076_951);
{
bool_t test1527_955;
if(STRINGP(i_954)){
bool_t test1529_957;
{
obj_t aux_2968;
aux_2968 = member___r4_pairs_and_lists_6_3(i_954, _imported_files__212___eval);
test1529_957 = CBOOL(aux_2968);
}
if(test1529_957){
test1527_955 = ((bool_t)0);
}
 else {
test1527_955 = ((bool_t)1);
}
}
 else {
test1527_955 = ((bool_t)0);
}
if(test1527_955){
{
obj_t obj2_1716;
obj2_1716 = _imported_files__212___eval;
_imported_files__212___eval = MAKE_PAIR(i_954, obj2_1716);
}
loadv___eval(i_954, ((bool_t)0));
}
 else {
BUNSPEC;
}
}
}
{
obj_t l1076_2975;
l1076_2975 = CDR(l1076_951);
l1076_951 = l1076_2975;
goto lname1077_952;
}
}
 else {
return ((bool_t)1);
}
}
}
}


/* expand-define-pattern */obj_t expand_define_pattern_97___eval(obj_t x_24)
{
if(PAIRP(x_24)){
obj_t cdr_258_124_1007;
cdr_258_124_1007 = CDR(x_24);
if(PAIRP(cdr_258_124_1007)){
obj_t cdr_263_185_1009;
cdr_263_185_1009 = CDR(cdr_258_124_1007);
if(PAIRP(cdr_263_185_1009)){
obj_t cdr_268_245_1011;
cdr_268_245_1011 = CDR(cdr_263_185_1009);
if(PAIRP(cdr_268_245_1011)){
bool_t test_2988;
{
obj_t aux_2989;
aux_2989 = CDR(cdr_268_245_1011);
test_2988 = (aux_2989==BNIL);
}
if(test_2988){
obj_t arg1563_1014;
obj_t arg1564_1015;
obj_t arg1565_1016;
arg1563_1014 = CAR(cdr_258_124_1007);
arg1564_1015 = CAR(cdr_263_185_1009);
arg1565_1016 = CAR(cdr_268_245_1011);
{
obj_t arg1569_1735;
{
obj_t arg1570_1736;
{
obj_t arg1572_1737;
arg1572_1737 = symbol1819___eval;
{
obj_t list1574_1739;
{
obj_t arg1575_1740;
{
obj_t arg1578_1741;
arg1578_1741 = MAKE_PAIR(BNIL, BNIL);
arg1575_1740 = MAKE_PAIR(arg1565_1016, arg1578_1741);
}
list1574_1739 = MAKE_PAIR(arg1564_1015, arg1575_1740);
}
arg1570_1736 = cons__138___r4_pairs_and_lists_6_3(arg1572_1737, list1574_1739);
}
}
arg1569_1735 = eval___eval(arg1570_1736, BNIL);
}
extend_r_macro_env_37___match_normalize(arg1563_1014, arg1569_1735);
}
return list1840___eval;
}
 else {
FAILURE(string1842___eval,string1843___eval,x_24);}
}
 else {
FAILURE(string1842___eval,string1843___eval,x_24);}
}
 else {
FAILURE(string1842___eval,string1843___eval,x_24);}
}
 else {
FAILURE(string1842___eval,string1843___eval,x_24);}
}
 else {
FAILURE(string1842___eval,string1843___eval,x_24);}
}


/* _expand-define-pattern */obj_t _expand_define_pattern_119___eval(obj_t env_2035, obj_t x_2036)
{
return expand_define_pattern_97___eval(x_2036);
}


/* notify-assert-fail */obj_t notify_assert_fail_37___eval(obj_t vars_25, obj_t fail_body_118_26, obj_t loc_27)
{
{
long old_1029;
old_1029 = get_write_length_193___r4_output_6_10_3();
set_write_length__244___r4_output_6_10_3(((long)80));
{
obj_t armed1081_1030;
armed1081_1030 = MAKE_CELL(BUNSPEC);
{
obj_t body1080_2039;
obj_t rhandler1079_2041;
body1080_2039 = make_fx_procedure(body1080___eval, ((long)0), ((long)2));
rhandler1079_2041 = make_fx_procedure(rhandler1079___eval, ((long)4), ((long)1));
PROCEDURE_SET(body1080_2039, ((long)0), loc_27);
PROCEDURE_SET(body1080_2039, ((long)1), fail_body_118_26);
PROCEDURE_SET(rhandler1079_2041, ((long)0), armed1081_1030);
CELL_SET(armed1081_1030, BTRUE);
handling_function1581___eval(body1080_2039, rhandler1079_2041, armed1081_1030);
}
}
{
obj_t list1596_1065;
list1596_1065 = MAKE_PAIR(string1844___eval, BNIL);
fprint___r4_output_6_10_3(current_error_port, list1596_1065);
}
{
obj_t list1601_1068;
list1601_1068 = MAKE_PAIR(string1845___eval, BNIL);
fprint___r4_output_6_10_3(current_error_port, list1601_1068);
}
{
obj_t l1086_1071;
l1086_1071 = vars_25;
lname1087_1072:
if(PAIRP(l1086_1071)){
{
obj_t f_1074;
f_1074 = CAR(l1086_1071);
{
obj_t arg1607_1077;
arg1607_1077 = eval___eval(f_1074, BNIL);
{
obj_t list1608_1078;
{
obj_t arg1609_1079;
{
obj_t arg1610_1080;
{
obj_t arg1612_1081;
arg1612_1081 = MAKE_PAIR(arg1607_1077, BNIL);
arg1610_1080 = MAKE_PAIR(string1846___eval, arg1612_1081);
}
arg1609_1079 = MAKE_PAIR(f_1074, arg1610_1080);
}
list1608_1078 = MAKE_PAIR(string1847___eval, arg1609_1079);
}
fprint___r4_output_6_10_3(current_error_port, list1608_1078);
}
}
}
{
obj_t l1086_3028;
l1086_3028 = CDR(l1086_1071);
l1086_1071 = l1086_3028;
goto lname1087_1072;
}
}
 else {
((bool_t)1);
}
}
{
obj_t list1616_1085;
list1616_1085 = MAKE_PAIR(string1844___eval, BNIL);
fprint___r4_output_6_10_3(current_error_port, list1616_1085);
}
set_write_length__244___r4_output_6_10_3(old_1029);
{
obj_t old_prompter_218_1088;
{
obj_t res1781_1784;
res1781_1784 = _prompt__73___eval;
old_prompter_218_1088 = res1781_1784;
}
{
obj_t arg1620_2037;
arg1620_2037 = proc1848___eval;
{
bool_t test1110_1785;
test1110_1785 = PROCEDURE_CORRECT_ARITYP(arg1620_2037, ((long)1));
if(test1110_1785){
_prompt__73___eval = arg1620_2037;
}
 else {
FAILURE(string1801___eval,string1802___eval,arg1620_2037);}
}
}
repl___eval();
{
bool_t test1110_1790;
test1110_1790 = PROCEDURE_CORRECT_ARITYP(old_prompter_218_1088, ((long)1));
if(test1110_1790){
return (_prompt__73___eval = old_prompter_218_1088,
BUNSPEC);
}
 else {
FAILURE(string1801___eval,string1802___eval,old_prompter_218_1088);}
}
}
}
}


/* handling_function1581 */obj_t handling_function1581___eval(obj_t body1080_2073, obj_t rhandler1079_2072, obj_t armed1081_2071)
{
jmp_buf jmpbuf;
obj_t an_exit1082_1035;
if( SET_EXIT(an_exit1082_1035) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1082_1035 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1082_1035, ((bool_t)1));
{
obj_t an_exitd1083_1036;
an_exitd1083_1036 = exitd_top;
{
obj_t escape_2040;
escape_2040 = make_fx_procedure(escape_1789___eval, ((long)1), ((long)1));
PROCEDURE_SET(escape_2040, ((long)0), an_exitd1083_1036);
{
obj_t res1085_1039;
{
obj_t arg1583_2038;
obj_t arg1582_2042;
arg1583_2038 = make_fx_procedure(arg1583___eval, ((long)0), ((long)1));
arg1582_2042 = make_fx_procedure(arg1582___eval, ((long)0), ((long)4));
PROCEDURE_SET(arg1583_2038, ((long)0), armed1081_2071);
PROCEDURE_SET(arg1582_2042, ((long)0), an_exitd1083_1036);
PROCEDURE_SET(arg1582_2042, ((long)1), armed1081_2071);
PROCEDURE_SET(arg1582_2042, ((long)2), rhandler1079_2072);
PROCEDURE_SET(arg1582_2042, ((long)3), escape_2040);
res1085_1039 = dynamic_wind_31___r4_control_features_6_9(arg1582_2042, body1080_2073, arg1583_2038);
}
POP_EXIT();
return res1085_1039;
}
}
}
}
}
}


/* _notify-assert-fail */obj_t _notify_assert_fail_157___eval(obj_t env_2043, obj_t vars_2044, obj_t fail_body_118_2045, obj_t loc_2046)
{
return notify_assert_fail_37___eval(vars_2044, fail_body_118_2045, loc_2046);
}


/* arg1620 */obj_t arg1620___eval(obj_t env_2047, obj_t num_2048)
{
{
obj_t num_1090;
num_1090 = num_2048;
return display___r4_output_6_10_3(string1849___eval, BNIL);
}
}


/* arg1583 */obj_t arg1583___eval(obj_t env_2049)
{
{
obj_t armed1081_2050;
armed1081_2050 = PROCEDURE_REF(env_2049, ((long)0));
{
{
bool_t test_3057;
{
obj_t aux_3058;
aux_3058 = CELL_REF(armed1081_2050);
test_3057 = CBOOL(aux_3058);
}
if(test_3057){
CELL_SET(armed1081_2050, BFALSE);
return remove_error_handler__102___error();
}
 else {
return BUNSPEC;
}
}
}
}
}


/* body1080 */obj_t body1080___eval(obj_t env_2052)
{
{
obj_t loc_2053;
obj_t fail_body_118_2054;
loc_2053 = PROCEDURE_REF(env_2052, ((long)0));
fail_body_118_2054 = PROCEDURE_REF(env_2052, ((long)1));
{
if(PAIRP(loc_2053)){
return error_location_112___error(string1850___eval, string1851___eval, fail_body_118_2054, CAR(loc_2053), CDR(loc_2053));
}
 else {
FAILURE(string1850___eval,string1851___eval,fail_body_118_2054);}
}
}
}


/* arg1582 */obj_t arg1582___eval(obj_t env_2055)
{
{
obj_t rhandler1079_2058;
obj_t escape_2059;
rhandler1079_2058 = PROCEDURE_REF(env_2055, ((long)2));
escape_2059 = PROCEDURE_REF(env_2055, ((long)3));
{
return add_error_handler__155___error(rhandler1079_2058, escape_2059);
}
}
}


/* escape_1789 */obj_t escape_1789___eval(obj_t env_2060, obj_t val1084_2062)
{
{
obj_t an_exitd1083_2061;
an_exitd1083_2061 = PROCEDURE_REF(env_2060, ((long)0));
{
obj_t val1084_1037;
val1084_1037 = val1084_2062;
return unwind_until__178___bexit(an_exitd1083_2061, val1084_1037);
}
}
}


/* rhandler1079 */obj_t rhandler1079___eval(obj_t env_2063, obj_t esc_2065, obj_t obj_2066, obj_t proc_2067, obj_t msg_2068)
{
{
obj_t armed1081_2064;
armed1081_2064 = PROCEDURE_REF(env_2063, ((long)0));
{
obj_t esc_1051;
obj_t obj_1052;
obj_t proc_1053;
obj_t msg_1054;
esc_1051 = esc_2065;
obj_1052 = obj_2066;
proc_1053 = proc_2067;
msg_1054 = msg_2068;
CELL_SET(armed1081_2064, BFALSE);
remove_error_handler__102___error();
notify_error_43___error(obj_1052, proc_1053, msg_1054);
return PROCEDURE_ENTRY(esc_1051)(esc_1051, BUNSPEC, BEOA);
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___eval()
{
module_initialization_70___type(((long)0), "__EVAL");
module_initialization_70___error(((long)0), "__EVAL");
module_initialization_70___bigloo(((long)0), "__EVAL");
module_initialization_70___tvector(((long)0), "__EVAL");
module_initialization_70___structure(((long)0), "__EVAL");
module_initialization_70___bexit(((long)0), "__EVAL");
module_initialization_70___os(((long)0), "__EVAL");
module_initialization_70___reader(((long)0), "__EVAL");
module_initialization_70___r4_numbers_6_5(((long)0), "__EVAL");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EVAL");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EVAL");
module_initialization_70___r4_characters_6_6(((long)0), "__EVAL");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EVAL");
module_initialization_70___r4_booleans_6_1(((long)0), "__EVAL");
module_initialization_70___r4_symbols_6_4(((long)0), "__EVAL");
module_initialization_70___r4_strings_6_7(((long)0), "__EVAL");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EVAL");
module_initialization_70___r4_input_6_10_2(((long)0), "__EVAL");
module_initialization_70___r4_control_features_6_9(((long)0), "__EVAL");
module_initialization_70___r4_vectors_6_8(((long)0), "__EVAL");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EVAL");
module_initialization_70___r4_output_6_10_3(((long)0), "__EVAL");
module_initialization_70___macro(((long)0), "__EVAL");
module_initialization_70___install_expanders(((long)0), "__EVAL");
module_initialization_70___progn(((long)0), "__EVAL");
module_initialization_70___expand(((long)0), "__EVAL");
module_initialization_70___evcompile(((long)0), "__EVAL");
module_initialization_70___evmeaning(((long)0), "__EVAL");
module_initialization_70___evprimop(((long)0), "__EVAL");
module_initialization_70___evenv(((long)0), "__EVAL");
module_initialization_70___match_normalize(((long)0), "__EVAL");
return module_initialization_70___r5_macro_4_3_init(((long)0), "__EVAL");
}

