/*===========================================================================*/
/*   (Llib/foreign.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _string_null_1110_118___foreign(obj_t, obj_t);
extern obj_t module_initialization_70___foreign(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _foreign__107___foreign(obj_t, obj_t);
static obj_t _obj__cobj_187___foreign(obj_t, obj_t);
extern bool_t foreign__213___foreign(obj_t);
extern bool_t foreign_null__229___foreign(obj_t);
static obj_t _foreign_null__100___foreign(obj_t, obj_t);
static obj_t imported_modules_init_94___foreign();
extern bool_t string_null__17___foreign(char *);
extern long obj__cobj_132___foreign(obj_t);
static obj_t require_initialization_114___foreign = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( foreign__env_36___foreign, _foreign__107___foreign1114, _foreign__107___foreign, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( string_null__env_195___foreign, _string_null_1110_118___foreign1115, _string_null_1110_118___foreign, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( foreign_null__env_218___foreign, _foreign_null__100___foreign1116, _foreign_null__100___foreign, 0L, 1 );
DEFINE_STRING( string1112___foreign, string1112___foreign1117, "not a foreign object", 20 );
DEFINE_STRING( string1111___foreign, string1111___foreign1118, "foreign-null?", 13 );
DEFINE_EXPORT_PROCEDURE( obj__cobj_env_104___foreign, _obj__cobj_187___foreign1119, _obj__cobj_187___foreign, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___foreign(long checksum_321, char * from_322)
{
if(CBOOL(require_initialization_114___foreign)){
require_initialization_114___foreign = BBOOL(((bool_t)0));
imported_modules_init_94___foreign();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* foreign? */bool_t foreign__213___foreign(obj_t obj_1)
{
return FOREIGNP(obj_1);
}


/* _foreign? */obj_t _foreign__107___foreign(obj_t env_309, obj_t obj_310)
{
{
bool_t aux_328;
{
obj_t obj_317;
obj_317 = obj_310;
aux_328 = FOREIGNP(obj_317);
}
return BBOOL(aux_328);
}
}


/* foreign-null? */bool_t foreign_null__229___foreign(obj_t obj_2)
{
if(FOREIGNP(obj_2)){
return FOREIGN_NULLP(obj_2);
}
 else {
FAILURE(string1111___foreign,string1112___foreign,obj_2);}
}


/* _foreign-null? */obj_t _foreign_null__100___foreign(obj_t env_311, obj_t obj_312)
{
{
bool_t aux_335;
{
obj_t obj_318;
obj_318 = obj_312;
if(FOREIGNP(obj_318)){
aux_335 = FOREIGN_NULLP(obj_318);
}
 else {
FAILURE(string1111___foreign,string1112___foreign,obj_318);}
}
return BBOOL(aux_335);
}
}


/* string-null? */bool_t string_null__17___foreign(char * obj_3)
{
return (obj_3 == 0L);
}


/* _string-null?1110 */obj_t _string_null_1110_118___foreign(obj_t env_313, obj_t obj_314)
{
{
bool_t aux_342;
{
char * obj_319;
obj_319 = BSTRING_TO_STRING(obj_314);
aux_342 = (obj_319 == 0L);
}
return BBOOL(aux_342);
}
}


/* obj->cobj */long obj__cobj_132___foreign(obj_t obj_4)
{
return obj_to_cobj(obj_4);
}


/* _obj->cobj */obj_t _obj__cobj_187___foreign(obj_t env_315, obj_t obj_316)
{
{
long aux_347;
{
obj_t obj_320;
obj_320 = obj_316;
aux_347 = obj_to_cobj(obj_320);
}
return (obj_t)(aux_347);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___foreign()
{
return module_initialization_70___error(((long)0), "__FOREIGN");
}

