/*===========================================================================*/
/*   (Llib/binary.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t output_obj_57___binary(obj_t, obj_t);
static obj_t _open_output_binary_file1165_32___binary(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_output_binary_file(obj_t);
static obj_t _open_input_binary_file1167_254___binary(obj_t, obj_t);
extern obj_t input_obj(obj_t);
static obj_t symbol1256___binary = BUNSPEC;
static obj_t symbol1255___binary = BUNSPEC;
static obj_t symbol1254___binary = BUNSPEC;
static obj_t symbol1252___binary = BUNSPEC;
static obj_t symbol1251___binary = BUNSPEC;
static obj_t symbol1249___binary = BUNSPEC;
static obj_t symbol1250___binary = BUNSPEC;
static obj_t symbol1248___binary = BUNSPEC;
static obj_t symbol1247___binary = BUNSPEC;
static obj_t symbol1245___binary = BUNSPEC;
static obj_t symbol1244___binary = BUNSPEC;
static obj_t symbol1243___binary = BUNSPEC;
static obj_t symbol1242___binary = BUNSPEC;
static obj_t symbol1241___binary = BUNSPEC;
static obj_t symbol1240___binary = BUNSPEC;
static obj_t symbol1237___binary = BUNSPEC;
static obj_t symbol1236___binary = BUNSPEC;
static obj_t symbol1235___binary = BUNSPEC;
extern obj_t output_obj(obj_t, obj_t);
extern obj_t input_obj_79___binary(obj_t);
extern bool_t binary_port__84___binary(obj_t);
extern obj_t output_char_229___binary(obj_t, char);
static obj_t _append_output_binary_file1166_34___binary(obj_t, obj_t);
extern obj_t open_output_binary_file_193___binary(obj_t);
extern obj_t close_binary_port(obj_t);
extern obj_t open_input_binary_file_64___binary(obj_t);
static obj_t _close_binary_port1168_34___binary(obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _input_obj1169_49___binary(obj_t, obj_t);
static obj_t _output_obj1170_244___binary(obj_t, obj_t, obj_t);
extern obj_t open_output_binary_file(obj_t);
extern obj_t module_initialization_70___binary(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t open_input_binary_file(obj_t);
extern unsigned char integer__char_140___r4_characters_6_6(long);
extern obj_t append_output_binary_file_44___binary(obj_t);
static obj_t _input_char1172_220___binary(obj_t, obj_t);
extern obj_t close_binary_port_18___binary(obj_t);
static obj_t _binary_port__90___binary(obj_t, obj_t);
extern obj_t input_char_4___binary(obj_t);
static obj_t imported_modules_init_94___binary();
static obj_t require_initialization_114___binary = BUNSPEC;
static obj_t _output_char1171_242___binary(obj_t, obj_t, obj_t);
static obj_t cnst_init_137___binary();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( output_char_env_218___binary, _output_char1171_242___binary1258, _output_char1171_242___binary, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( binary_port__env_72___binary, _binary_port__90___binary1259, _binary_port__90___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( open_input_binary_file_env_41___binary, _open_input_binary_file1167_254___binary1260, _open_input_binary_file1167_254___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( open_output_binary_file_env_149___binary, _open_output_binary_file1165_32___binary1261, _open_output_binary_file1165_32___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( append_output_binary_file_env_43___binary, _append_output_binary_file1166_34___binary1262, _append_output_binary_file1166_34___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( output_obj_env_240___binary, _output_obj1170_244___binary1263, _output_obj1170_244___binary, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( input_char_env_235___binary, _input_char1172_220___binary1264, _input_char1172_220___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( close_binary_port_env_90___binary, _close_binary_port1168_34___binary1265, _close_binary_port1168_34___binary, 0L, 1 );
DEFINE_STRING( string1253___binary, string1253___binary1266, "CHAR", 4 );
DEFINE_STRING( string1246___binary, string1246___binary1267, "BINARY-PORT", 11 );
DEFINE_STRING( string1239___binary, string1239___binary1268, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/binary.scm", 59 );
DEFINE_STRING( string1238___binary, string1238___binary1269, "BSTRING", 7 );
DEFINE_EXPORT_PROCEDURE( input_obj_env_141___binary, _input_obj1169_49___binary1270, _input_obj1169_49___binary, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___binary(long checksum_628, char * from_629)
{
if(CBOOL(require_initialization_114___binary)){
require_initialization_114___binary = BBOOL(((bool_t)0));
cnst_init_137___binary();
imported_modules_init_94___binary();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___binary()
{
symbol1235___binary = string_to_symbol("BINARY-PORT?");
symbol1236___binary = string_to_symbol("OPEN-OUTPUT-BINARY-FILE");
symbol1237___binary = string_to_symbol("_OPEN-OUTPUT-BINARY-FILE1165");
symbol1240___binary = string_to_symbol("APPEND-OUTPUT-BINARY-FILE");
symbol1241___binary = string_to_symbol("_APPEND-OUTPUT-BINARY-FILE1166");
symbol1242___binary = string_to_symbol("OPEN-INPUT-BINARY-FILE");
symbol1243___binary = string_to_symbol("_OPEN-INPUT-BINARY-FILE1167");
symbol1244___binary = string_to_symbol("CLOSE-BINARY-PORT");
symbol1245___binary = string_to_symbol("_CLOSE-BINARY-PORT1168");
symbol1247___binary = string_to_symbol("INPUT-OBJ");
symbol1248___binary = string_to_symbol("_INPUT-OBJ1169");
symbol1249___binary = string_to_symbol("OUTPUT-OBJ");
symbol1250___binary = string_to_symbol("_OUTPUT-OBJ1170");
symbol1251___binary = string_to_symbol("OUTPUT-CHAR");
symbol1252___binary = string_to_symbol("_OUTPUT-CHAR1171");
symbol1254___binary = string_to_symbol("INPUT-CHAR");
symbol1255___binary = string_to_symbol("_INPUT-CHAR1172");
return (symbol1256___binary = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* binary-port? */bool_t binary_port__84___binary(obj_t obj_1)
{
{
obj_t symbol1146_575;
symbol1146_575 = symbol1235___binary;
{
PUSH_TRACE(symbol1146_575);
BUNSPEC;
{
bool_t aux1145_576;
aux1145_576 = BINARY_PORTP(obj_1);
POP_TRACE();
return aux1145_576;
}
}
}
}


/* _binary-port? */obj_t _binary_port__90___binary(obj_t env_501, obj_t obj_502)
{
{
bool_t aux_656;
{
obj_t obj_577;
obj_577 = obj_502;
{
obj_t symbol1146_578;
symbol1146_578 = symbol1235___binary;
{
PUSH_TRACE(symbol1146_578);
BUNSPEC;
{
bool_t aux1145_579;
aux1145_579 = BINARY_PORTP(obj_577);
POP_TRACE();
aux_656 = aux1145_579;
}
}
}
}
return BBOOL(aux_656);
}
}


/* open-output-binary-file */obj_t open_output_binary_file_193___binary(obj_t str_2)
{
{
obj_t symbol1148_580;
symbol1148_580 = symbol1236___binary;
{
PUSH_TRACE(symbol1148_580);
BUNSPEC;
{
obj_t aux1147_581;
aux1147_581 = open_output_binary_file(str_2);
POP_TRACE();
return aux1147_581;
}
}
}
}


/* _open-output-binary-file1165 */obj_t _open_output_binary_file1165_32___binary(obj_t env_503, obj_t str_504)
{
{
obj_t str_582;
if(STRINGP(str_504)){
str_582 = str_504;
}
 else {
bigloo_type_error_location_103___error(symbol1237___binary, string1238___binary, str_504, string1239___binary, BINT(((long)3727)));
exit( -1 );}
{
obj_t symbol1148_583;
symbol1148_583 = symbol1236___binary;
{
PUSH_TRACE(symbol1148_583);
BUNSPEC;
{
obj_t aux1147_584;
aux1147_584 = open_output_binary_file(str_582);
POP_TRACE();
return aux1147_584;
}
}
}
}
}


/* append-output-binary-file */obj_t append_output_binary_file_44___binary(obj_t str_3)
{
{
obj_t symbol1150_585;
symbol1150_585 = symbol1240___binary;
{
PUSH_TRACE(symbol1150_585);
BUNSPEC;
{
obj_t aux1149_586;
aux1149_586 = append_output_binary_file(str_3);
POP_TRACE();
return aux1149_586;
}
}
}
}


/* _append-output-binary-file1166 */obj_t _append_output_binary_file1166_34___binary(obj_t env_505, obj_t str_506)
{
{
obj_t str_587;
if(STRINGP(str_506)){
str_587 = str_506;
}
 else {
bigloo_type_error_location_103___error(symbol1241___binary, string1238___binary, str_506, string1239___binary, BINT(((long)4031)));
exit( -1 );}
{
obj_t symbol1150_588;
symbol1150_588 = symbol1240___binary;
{
PUSH_TRACE(symbol1150_588);
BUNSPEC;
{
obj_t aux1149_589;
aux1149_589 = append_output_binary_file(str_587);
POP_TRACE();
return aux1149_589;
}
}
}
}
}


/* open-input-binary-file */obj_t open_input_binary_file_64___binary(obj_t str_4)
{
{
obj_t symbol1152_590;
symbol1152_590 = symbol1242___binary;
{
PUSH_TRACE(symbol1152_590);
BUNSPEC;
{
obj_t aux1151_591;
aux1151_591 = open_input_binary_file(str_4);
POP_TRACE();
return aux1151_591;
}
}
}
}


/* _open-input-binary-file1167 */obj_t _open_input_binary_file1167_254___binary(obj_t env_507, obj_t str_508)
{
{
obj_t str_592;
if(STRINGP(str_508)){
str_592 = str_508;
}
 else {
bigloo_type_error_location_103___error(symbol1243___binary, string1238___binary, str_508, string1239___binary, BINT(((long)4339)));
exit( -1 );}
{
obj_t symbol1152_593;
symbol1152_593 = symbol1242___binary;
{
PUSH_TRACE(symbol1152_593);
BUNSPEC;
{
obj_t aux1151_594;
aux1151_594 = open_input_binary_file(str_592);
POP_TRACE();
return aux1151_594;
}
}
}
}
}


/* close-binary-port */obj_t close_binary_port_18___binary(obj_t port_5)
{
{
obj_t symbol1154_595;
symbol1154_595 = symbol1244___binary;
{
PUSH_TRACE(symbol1154_595);
BUNSPEC;
{
obj_t aux1153_596;
aux1153_596 = close_binary_port(port_5);
POP_TRACE();
return aux1153_596;
}
}
}
}


/* _close-binary-port1168 */obj_t _close_binary_port1168_34___binary(obj_t env_509, obj_t port_510)
{
{
obj_t port_597;
if(BINARY_PORTP(port_510)){
port_597 = port_510;
}
 else {
bigloo_type_error_location_103___error(symbol1245___binary, string1246___binary, port_510, string1239___binary, BINT(((long)4641)));
exit( -1 );}
{
obj_t symbol1154_598;
symbol1154_598 = symbol1244___binary;
{
PUSH_TRACE(symbol1154_598);
BUNSPEC;
{
obj_t aux1153_599;
aux1153_599 = close_binary_port(port_597);
POP_TRACE();
return aux1153_599;
}
}
}
}
}


/* input-obj */obj_t input_obj_79___binary(obj_t port_6)
{
{
obj_t symbol1156_600;
symbol1156_600 = symbol1247___binary;
{
PUSH_TRACE(symbol1156_600);
BUNSPEC;
{
obj_t aux1155_601;
aux1155_601 = input_obj(port_6);
POP_TRACE();
return aux1155_601;
}
}
}
}


/* _input-obj1169 */obj_t _input_obj1169_49___binary(obj_t env_511, obj_t port_512)
{
{
obj_t port_602;
if(BINARY_PORTP(port_512)){
port_602 = port_512;
}
 else {
bigloo_type_error_location_103___error(symbol1248___binary, string1246___binary, port_512, string1239___binary, BINT(((long)4935)));
exit( -1 );}
{
obj_t symbol1156_603;
symbol1156_603 = symbol1247___binary;
{
PUSH_TRACE(symbol1156_603);
BUNSPEC;
{
obj_t aux1155_604;
aux1155_604 = input_obj(port_602);
POP_TRACE();
return aux1155_604;
}
}
}
}
}


/* output-obj */obj_t output_obj_57___binary(obj_t port_7, obj_t obj_8)
{
{
obj_t symbol1158_605;
symbol1158_605 = symbol1249___binary;
{
PUSH_TRACE(symbol1158_605);
BUNSPEC;
{
obj_t aux1157_606;
aux1157_606 = output_obj(port_7, obj_8);
POP_TRACE();
return aux1157_606;
}
}
}
}


/* _output-obj1170 */obj_t _output_obj1170_244___binary(obj_t env_513, obj_t port_514, obj_t obj_515)
{
{
obj_t port_607;
obj_t obj_608;
if(BINARY_PORTP(port_514)){
port_607 = port_514;
}
 else {
bigloo_type_error_location_103___error(symbol1250___binary, string1246___binary, port_514, string1239___binary, BINT(((long)5213)));
exit( -1 );}
obj_608 = obj_515;
{
obj_t symbol1158_609;
symbol1158_609 = symbol1249___binary;
{
PUSH_TRACE(symbol1158_609);
BUNSPEC;
{
obj_t aux1157_610;
aux1157_610 = output_obj(port_607, obj_608);
POP_TRACE();
return aux1157_610;
}
}
}
}
}


/* output-char */obj_t output_char_229___binary(obj_t port_9, char char_10)
{
{
obj_t symbol1160_611;
symbol1160_611 = symbol1251___binary;
{
PUSH_TRACE(symbol1160_611);
BUNSPEC;
{
obj_t aux1159_612;
aux1159_612 = (fputc( char_10, BINARY_PORT( port_9 ).file ), BUNSPEC);
POP_TRACE();
return aux1159_612;
}
}
}
}


/* _output-char1171 */obj_t _output_char1171_242___binary(obj_t env_516, obj_t port_517, obj_t char_518)
{
{
obj_t port_613;
char char_166_614;
if(BINARY_PORTP(port_517)){
port_613 = port_517;
}
 else {
bigloo_type_error_location_103___error(symbol1252___binary, string1246___binary, port_517, string1239___binary, BINT(((long)5506)));
exit( -1 );}
{
obj_t aux_735;
if(CHARP(char_518)){
aux_735 = char_518;
}
 else {
bigloo_type_error_location_103___error(symbol1252___binary, string1253___binary, char_518, string1239___binary, BINT(((long)5506)));
exit( -1 );}
char_166_614 = CCHAR(aux_735);
}
{
obj_t symbol1160_615;
symbol1160_615 = symbol1251___binary;
{
PUSH_TRACE(symbol1160_615);
BUNSPEC;
{
obj_t aux1159_616;
aux1159_616 = (fputc( char_166_614, BINARY_PORT( port_613 ).file ), BUNSPEC);
POP_TRACE();
return aux1159_616;
}
}
}
}
}


/* input-char */obj_t input_char_4___binary(obj_t port_11)
{
{
obj_t symbol1162_617;
symbol1162_617 = symbol1254___binary;
{
PUSH_TRACE(symbol1162_617);
BUNSPEC;
{
obj_t aux1161_618;
{
int char_619;
char_619 = (fgetc( BINARY_PORT( port_11 ).file ));
{
bool_t test1006_620;
{
int arg1007_621;
arg1007_621 = EOF;
{
long aux_750;
long aux_748;
aux_750 = (long)(arg1007_621);
aux_748 = (long)(char_619);
test1006_620 = (aux_748==aux_750);
}
}
if(test1006_620){
aux1161_618 = BEOF;
}
 else {
unsigned char aux_754;
aux_754 = integer__char_140___r4_characters_6_6((long)(char_619));
aux1161_618 = BCHAR(aux_754);
}
}
}
POP_TRACE();
return aux1161_618;
}
}
}
}


/* _input-char1172 */obj_t _input_char1172_220___binary(obj_t env_519, obj_t port_520)
{
{
obj_t port_622;
if(BINARY_PORTP(port_520)){
port_622 = port_520;
}
 else {
bigloo_type_error_location_103___error(symbol1255___binary, string1246___binary, port_520, string1239___binary, BINT(((long)5840)));
exit( -1 );}
{
obj_t symbol1162_623;
symbol1162_623 = symbol1254___binary;
{
PUSH_TRACE(symbol1162_623);
BUNSPEC;
{
obj_t aux1161_624;
{
int char_625;
char_625 = (fgetc( BINARY_PORT( port_622 ).file ));
{
bool_t test1006_626;
{
int arg1007_627;
arg1007_627 = EOF;
{
long aux_769;
long aux_767;
aux_769 = (long)(arg1007_627);
aux_767 = (long)(char_625);
test1006_626 = (aux_767==aux_769);
}
}
if(test1006_626){
aux1161_624 = BEOF;
}
 else {
unsigned char aux_773;
aux_773 = integer__char_140___r4_characters_6_6((long)(char_625));
aux1161_624 = BCHAR(aux_773);
}
}
}
POP_TRACE();
return aux1161_624;
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___binary()
{
{
obj_t symbol1164_499;
symbol1164_499 = symbol1256___binary;
{
PUSH_TRACE(symbol1164_499);
BUNSPEC;
{
obj_t aux1163_500;
aux1163_500 = module_initialization_70___error(((long)0), "__BINARY");
POP_TRACE();
return aux1163_500;
}
}
}
}

