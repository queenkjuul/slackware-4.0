/*===========================================================================*/
/*   (Reduce/1occ.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_reduce_1occ();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static obj_t node_1occ___233_reduce_1occ(obj_t, obj_t);
static obj_t _node_1occ__default1512_153_reduce_1occ(obj_t, obj_t, obj_t);
extern obj_t box_ref_242_ast_node;
extern obj_t _res1__155___r5_control_features_6_4;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_reduce_1occ(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_effect_effect(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_lvtype(long, char *);
extern obj_t module_initialization_70_ast_occur(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r5_control_features_6_4(long, char *);
extern obj_t reduce_1occ__237_reduce_1occ(obj_t);
extern obj_t let_fun_218_ast_node;
static long _variable_removed__90_reduce_1occ;
static obj_t imported_modules_init_94_reduce_1occ();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_reduce_1occ();
extern obj_t occur_var_108_ast_occur(obj_t);
extern obj_t atom_ast_node;
static obj_t node_1occ__default1512_239_reduce_1occ(node_t, obj_t);
extern obj_t cast_ast_node;
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_reduce_1occ();
static obj_t _reduce_1occ__206_reduce_1occ(obj_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern bool_t side_effect__165_effect_effect(node_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t _res_number__75___r5_control_features_6_4;
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t node_1occ__69_reduce_1occ(node_t, obj_t);
static obj_t _node_1occ_1791_88_reduce_1occ(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_reduce_1occ = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_reduce_1occ();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(reduce_1occ__env_30_reduce_1occ, _reduce_1occ__206_reduce_1occ1801, _reduce_1occ__206_reduce_1occ, 0L, 1);
DEFINE_STATIC_GENERIC(node_1occ__env_84_reduce_1occ, _node_1occ_1791_88_reduce_1occ1802, _node_1occ_1791_88_reduce_1occ, 0L, 2);
DEFINE_STATIC_PROCEDURE(node_1occ__default1512_env_251_reduce_1occ, _node_1occ__default1512_153_reduce_1occ1803, _node_1occ__default1512_153_reduce_1occ, 0L, 2);
DEFINE_STRING(string1795_reduce_1occ, string1795_reduce_1occ1804, "NODE-1OCC!-DEFAULT1512 READ ", 28);
DEFINE_STRING(string1794_reduce_1occ, string1794_reduce_1occ1805, "No method for this object", 25);
DEFINE_STRING(string1793_reduce_1occ, string1793_reduce_1occ1806, "(removed : ", 11);
DEFINE_STRING(string1792_reduce_1occ, string1792_reduce_1occ1807, "      single occurrence      ", 29);


/* module-initialization */ obj_t 
module_initialization_70_reduce_1occ(long checksum_1600, char *from_1601)
{
   if (CBOOL(require_initialization_114_reduce_1occ))
     {
	require_initialization_114_reduce_1occ = BBOOL(((bool_t) 0));
	library_modules_init_112_reduce_1occ();
	cnst_init_137_reduce_1occ();
	imported_modules_init_94_reduce_1occ();
	method_init_76_reduce_1occ();
	toplevel_init_63_reduce_1occ();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_reduce_1occ()
{
   module_initialization_70___object(((long) 0), "REDUCE_1OCC");
   module_initialization_70___r5_control_features_6_4(((long) 0), "REDUCE_1OCC");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "REDUCE_1OCC");
   module_initialization_70___reader(((long) 0), "REDUCE_1OCC");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_reduce_1occ()
{
   {
      obj_t cnst_port_138_1592;
      cnst_port_138_1592 = open_input_string(string1795_reduce_1occ);
      {
	 long i_1593;
	 i_1593 = ((long) 1);
       loop_1594:
	 {
	    bool_t test1796_1595;
	    test1796_1595 = (i_1593 == ((long) -1));
	    if (test1796_1595)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1797_1596;
		    {
		       obj_t list1798_1597;
		       {
			  obj_t arg1799_1598;
			  arg1799_1598 = BNIL;
			  list1798_1597 = MAKE_PAIR(cnst_port_138_1592, arg1799_1598);
		       }
		       arg1797_1596 = read___reader(list1798_1597);
		    }
		    CNST_TABLE_SET(i_1593, arg1797_1596);
		 }
		 {
		    int aux_1599;
		    {
		       long aux_1620;
		       aux_1620 = (i_1593 - ((long) 1));
		       aux_1599 = (int) (aux_1620);
		    }
		    {
		       long i_1623;
		       i_1623 = (long) (aux_1599);
		       i_1593 = i_1623;
		       goto loop_1594;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_reduce_1occ()
{
   _variable_removed__90_reduce_1occ = ((long) 0);
   return BUNSPEC;
}


/* reduce-1occ! */ obj_t 
reduce_1occ__237_reduce_1occ(obj_t globals_1)
{
   {
      obj_t list1544_741;
      list1544_741 = MAKE_PAIR(string1792_reduce_1occ, BNIL);
      verbose_tools_speek(BINT(((long) 2)), list1544_741);
   }
   occur_var_108_ast_occur(globals_1);
   _variable_removed__90_reduce_1occ = ((long) 0);
   {
      obj_t l1435_744;
      l1435_744 = globals_1;
    lname1436_745:
      if (PAIRP(l1435_744))
	{
	   {
	      value_t fun_748;
	      {
		 global_t obj_1403;
		 {
		    obj_t aux_1631;
		    aux_1631 = CAR(l1435_744);
		    obj_1403 = (global_t) (aux_1631);
		 }
		 fun_748 = (((global_t) CREF(obj_1403))->value);
	      }
	      {
		 {
		    obj_t arg1550_750;
		    {
		       obj_t __751;
		       {
			  node_t aux_1635;
			  {
			     obj_t aux_1636;
			     {
				sfun_t obj_1404;
				obj_1404 = (sfun_t) (fun_748);
				aux_1636 = (((sfun_t) CREF(obj_1404))->body);
			     }
			     aux_1635 = (node_t) (aux_1636);
			  }
			  __751 = node_1occ__69_reduce_1occ(aux_1635, BNIL);
		       }
		       {
			  obj_t node_752;
			  node_752 = _res1__155___r5_control_features_6_4;
			  arg1550_750 = node_752;
		       }
		    }
		    {
		       sfun_t obj_1405;
		       obj_1405 = (sfun_t) (fun_748);
		       ((((sfun_t) CREF(obj_1405))->body) = ((obj_t) arg1550_750), BUNSPEC);
		    }
		 }
		 BUNSPEC;
	      }
	   }
	   {
	      obj_t l1435_1643;
	      l1435_1643 = CDR(l1435_744);
	      l1435_744 = l1435_1643;
	      goto lname1436_745;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t list1554_755;
      {
	 obj_t arg1556_757;
	 {
	    obj_t arg1557_758;
	    {
	       obj_t arg1558_759;
	       {
		  obj_t aux_1645;
		  aux_1645 = BCHAR(((unsigned char) '\n'));
		  arg1558_759 = MAKE_PAIR(aux_1645, BNIL);
	       }
	       {
		  obj_t aux_1648;
		  aux_1648 = BCHAR(((unsigned char) ')'));
		  arg1557_758 = MAKE_PAIR(aux_1648, arg1558_759);
	       }
	    }
	    {
	       obj_t aux_1651;
	       aux_1651 = BINT(_variable_removed__90_reduce_1occ);
	       arg1556_757 = MAKE_PAIR(aux_1651, arg1557_758);
	    }
	 }
	 list1554_755 = MAKE_PAIR(string1793_reduce_1occ, arg1556_757);
      }
      verbose_tools_speek(BINT(((long) 2)), list1554_755);
   }
   return globals_1;
}


/* _reduce-1occ! */ obj_t 
_reduce_1occ__206_reduce_1occ(obj_t env_1584, obj_t globals_1585)
{
   return reduce_1occ__237_reduce_1occ(globals_1585);
}


/* node-1occ*! */ obj_t 
node_1occ___233_reduce_1occ(obj_t node__221_48, obj_t _1_exp__141_49)
{
   {
      obj_t node__221_761;
      bool_t reset_762;
      obj_t _1_exp__141_763;
      node__221_761 = node__221_48;
      reset_762 = ((bool_t) 0);
      _1_exp__141_763 = _1_exp__141_49;
    loop_764:
      if (NULLP(node__221_761))
	{
	   return BBOOL(reset_762);
	}
      else
	{
	   bool_t test_1661;
	   {
	      obj_t aux_1662;
	      aux_1662 = CDR(node__221_761);
	      test_1661 = NULLP(aux_1662);
	   }
	   if (test_1661)
	     {
		{
		   obj_t reset__69_767;
		   {
		      node_t aux_1665;
		      {
			 obj_t aux_1666;
			 aux_1666 = CAR(node__221_761);
			 aux_1665 = (node_t) (aux_1666);
		      }
		      reset__69_767 = node_1occ__69_reduce_1occ(aux_1665, _1_exp__141_763);
		   }
		   {
		      obj_t node_768;
		      node_768 = _res1__155___r5_control_features_6_4;
		      SET_CAR(node__221_761, node_768);
		      if (reset_762)
			{
			   return BBOOL(reset_762);
			}
		      else
			{
			   return reset__69_767;
			}
		   }
		}
	     }
	   else
	     {
		{
		   obj_t reset__69_771;
		   {
		      node_t aux_1673;
		      {
			 obj_t aux_1674;
			 aux_1674 = CAR(node__221_761);
			 aux_1673 = (node_t) (aux_1674);
		      }
		      reset__69_771 = node_1occ__69_reduce_1occ(aux_1673, _1_exp__141_763);
		   }
		   {
		      obj_t node_772;
		      node_772 = _res1__155___r5_control_features_6_4;
		      SET_CAR(node__221_761, node_772);
		      {
			 bool_t test_1679;
			 if (reset_762)
			   {
			      test_1679 = ((bool_t) 1);
			   }
			 else
			   {
			      test_1679 = CBOOL(reset__69_771);
			   }
			 if (test_1679)
			   {
			      obj_t _1_exp__141_1685;
			      bool_t reset_1684;
			      obj_t node__221_1682;
			      node__221_1682 = CDR(node__221_761);
			      reset_1684 = ((bool_t) 1);
			      _1_exp__141_1685 = BNIL;
			      _1_exp__141_763 = _1_exp__141_1685;
			      reset_762 = reset_1684;
			      node__221_761 = node__221_1682;
			      goto loop_764;
			   }
			 else
			   {
			      bool_t reset_1688;
			      obj_t node__221_1686;
			      node__221_1686 = CDR(node__221_761);
			      reset_1688 = ((bool_t) 0);
			      reset_762 = reset_1688;
			      node__221_761 = node__221_1686;
			      goto loop_764;
			   }
		      }
		   }
		}
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_reduce_1occ()
{
   add_generic__110___object(node_1occ__env_84_reduce_1occ, node_1occ__default1512_env_251_reduce_1occ);
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, var_ast_node, ((long) 2));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, select_ast_node, ((long) 12));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, box_set__221_ast_node, ((long) 18));
   add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, box_ref_242_ast_node, ((long) 19));
   {
      long aux_1710;
      aux_1710 = add_inlined_method__244___object(node_1occ__env_84_reduce_1occ, app_ast_node, ((long) 20));
      return BINT(aux_1710);
   }
}


/* node-1occ! */ obj_t 
node_1occ__69_reduce_1occ(node_t node_2, obj_t _1_exp__141_3)
{
 node_1occ__69_reduce_1occ:
   {
      obj_t method1671_1110;
      obj_t class1676_1111;
      {
	 obj_t arg1679_1108;
	 obj_t arg1680_1109;
	 {
	    object_t obj_1419;
	    obj_1419 = (object_t) (node_2);
	    {
	       obj_t pre_method_105_1420;
	       pre_method_105_1420 = PROCEDURE_REF(node_1occ__env_84_reduce_1occ, ((long) 2));
	       if (INTEGERP(pre_method_105_1420))
		 {
		    PROCEDURE_SET(node_1occ__env_84_reduce_1occ, ((long) 2), BUNSPEC);
		    arg1679_1108 = pre_method_105_1420;
		 }
	       else
		 {
		    long obj_class_num_177_1425;
		    obj_class_num_177_1425 = TYPE(obj_1419);
		    {
		       obj_t arg1177_1426;
		       arg1177_1426 = PROCEDURE_REF(node_1occ__env_84_reduce_1occ, ((long) 1));
		       {
			  long arg1178_1430;
			  {
			     long arg1179_1431;
			     arg1179_1431 = OBJECT_TYPE;
			     arg1178_1430 = (obj_class_num_177_1425 - arg1179_1431);
			  }
			  arg1679_1108 = VECTOR_REF(arg1177_1426, arg1178_1430);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1436;
	    object_1436 = (object_t) (node_2);
	    {
	       long arg1180_1437;
	       {
		  long arg1181_1438;
		  long arg1182_1439;
		  arg1181_1438 = TYPE(object_1436);
		  arg1182_1439 = OBJECT_TYPE;
		  arg1180_1437 = (arg1181_1438 - arg1182_1439);
	       }
	       {
		  obj_t vector_1443;
		  vector_1443 = _classes__134___object;
		  arg1680_1109 = VECTOR_REF(vector_1443, arg1180_1437);
	       }
	    }
	 }
	 method1671_1110 = arg1679_1108;
	 class1676_1111 = arg1680_1109;
	 {
	    if (INTEGERP(method1671_1110))
	      {
		 switch ((long) CINT(method1671_1110))
		   {
		   case ((long) 0):
		      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
		      {
			 atom_t aux_1731;
			 aux_1731 = (atom_t) (node_2);
			 _res1__155___r5_control_features_6_4 = (obj_t) (aux_1731);
		      }
		      return BFALSE;
		      break;
		   case ((long) 1):
		      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
		      {
			 kwote_t aux_1735;
			 aux_1735 = (kwote_t) (node_2);
			 _res1__155___r5_control_features_6_4 = (obj_t) (aux_1735);
		      }
		      return BFALSE;
		      break;
		   case ((long) 2):
		      {
			 var_t node_1125;
			 node_1125 = (var_t) (node_2);
			 {
			    variable_t v_1127;
			    v_1127 = (((var_t) CREF(node_1125))->variable);
			    {
			       obj_t falpha_1128;
			       falpha_1128 = assq___r4_pairs_and_lists_6_3((obj_t) (v_1127), _1_exp__141_3);
			       if (PAIRP(falpha_1128))
				 {
				    {
				       long arg1684_1130;
				       {
					  long aux_1744;
					  aux_1744 = (((variable_t) CREF(v_1127))->occurrence);
					  arg1684_1130 = (aux_1744 - ((long) 1));
				       }
				       ((((variable_t) CREF(v_1127))->occurrence) = ((long) arg1684_1130), BUNSPEC);
				    }
				    {
				       long z1_1452;
				       z1_1452 = _variable_removed__90_reduce_1occ;
				       _variable_removed__90_reduce_1occ = (z1_1452 + ((long) 1));
				    }
				    {
				       node_t node_1749;
				       {
					  obj_t aux_1750;
					  aux_1750 = CDR(falpha_1128);
					  node_1749 = (node_t) (aux_1750);
				       }
				       node_2 = node_1749;
				       goto node_1occ__69_reduce_1occ;
				    }
				 }
			       else
				 {
				    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				    _res1__155___r5_control_features_6_4 = (obj_t) (node_1125);
				    return BFALSE;
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 3):
		      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
		      {
			 closure_t aux_1756;
			 aux_1756 = (closure_t) (node_2);
			 _res1__155___r5_control_features_6_4 = (obj_t) (aux_1756);
		      }
		      return BFALSE;
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1140;
			 node_1140 = (sequence_t) (node_2);
			 {
			    obj_t val0_1446_1143;
			    val0_1446_1143 = node_1occ___233_reduce_1occ((((sequence_t) CREF(node_1140))->nodes), _1_exp__141_3);
			    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			    _res1__155___r5_control_features_6_4 = (obj_t) (node_1140);
			    return val0_1446_1143;
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_ly_162_t node_1146;
			 node_1146 = (app_ly_162_t) (node_2);
			 {
			    obj_t reset_1149;
			    reset_1149 = node_1occ__69_reduce_1occ((((app_ly_162_t) CREF(node_1146))->fun), _1_exp__141_3);
			    {
			       obj_t nfun_1150;
			       nfun_1150 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1263_1458;
				  val1263_1458 = (node_t) (nfun_1150);
				  ((((app_ly_162_t) CREF(node_1146))->fun) = ((node_t) val1263_1458), BUNSPEC);
			       }
			       {
				  obj_t reset__69_1151;
				  {
				     obj_t aux_1769;
				     if (CBOOL(reset_1149))
				       {
					  aux_1769 = BNIL;
				       }
				     else
				       {
					  aux_1769 = _1_exp__141_3;
				       }
				     reset__69_1151 = node_1occ__69_reduce_1occ((((app_ly_162_t) CREF(node_1146))->arg), aux_1769);
				  }
				  {
				     obj_t narg_1152;
				     narg_1152 = _res1__155___r5_control_features_6_4;
				     {
					node_t val1264_1461;
					val1264_1461 = (node_t) (narg_1152);
					((((app_ly_162_t) CREF(node_1146))->arg) = ((node_t) val1264_1461), BUNSPEC);
				     }
				     _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				     _res1__155___r5_control_features_6_4 = (obj_t) (node_1146);
				     if (CBOOL(reset_1149))
				       {
					  return reset_1149;
				       }
				     else
				       {
					  return reset__69_1151;
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 funcall_t node_1159;
			 node_1159 = (funcall_t) (node_2);
			 {
			    obj_t reset__69_1162;
			    reset__69_1162 = node_1occ___233_reduce_1occ((((funcall_t) CREF(node_1159))->args), _1_exp__141_3);
			    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			    _res1__155___r5_control_features_6_4 = (obj_t) (node_1159);
			    return reset__69_1162;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 pragma_t node_1166;
			 node_1166 = (pragma_t) (node_2);
			 {
			    bool_t val0_1456_1169;
			    val0_1456_1169 = side_effect__165_effect_effect((node_t) (node_1166));
			    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			    _res1__155___r5_control_features_6_4 = (obj_t) (node_1166);
			    return BBOOL(val0_1456_1169);
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 cast_t node_1171;
			 node_1171 = (cast_t) (node_2);
			 {
			    obj_t reset_1174;
			    reset_1174 = node_1occ__69_reduce_1occ((((cast_t) CREF(node_1171))->arg), _1_exp__141_3);
			    {
			       obj_t narg_1175;
			       narg_1175 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1297_1465;
				  val1297_1465 = (node_t) (narg_1175);
				  ((((cast_t) CREF(node_1171))->arg) = ((node_t) val1297_1465), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1171);
			       return reset_1174;
			    }
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 setq_t node_1179;
			 node_1179 = (setq_t) (node_2);
			 {
			    obj_t reset_1182;
			    reset_1182 = node_1occ__69_reduce_1occ((((setq_t) CREF(node_1179))->value), _1_exp__141_3);
			    {
			       obj_t nvalue_1183;
			       nvalue_1183 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1307_1468;
				  val1307_1468 = (node_t) (nvalue_1183);
				  ((((setq_t) CREF(node_1179))->value) = ((node_t) val1307_1468), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1179);
			       return reset_1182;
			    }
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 conditional_t node_1187;
			 node_1187 = (conditional_t) (node_2);
			 {
			    obj_t reset_1190;
			    reset_1190 = node_1occ__69_reduce_1occ((((conditional_t) CREF(node_1187))->test), _1_exp__141_3);
			    {
			       obj_t ntest_1191;
			       ntest_1191 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1321_1471;
				  val1321_1471 = (node_t) (ntest_1191);
				  ((((conditional_t) CREF(node_1187))->test) = ((node_t) val1321_1471), BUNSPEC);
			       }
			       {
				  obj_t _1_exp___225_1192;
				  if (CBOOL(reset_1190))
				    {
				       _1_exp___225_1192 = BNIL;
				    }
				  else
				    {
				       _1_exp___225_1192 = _1_exp__141_3;
				    }
				  {
				     obj_t reset__69_1193;
				     reset__69_1193 = node_1occ__69_reduce_1occ((((conditional_t) CREF(node_1187))->true), _1_exp___225_1192);
				     {
					obj_t ntrue_1194;
					ntrue_1194 = _res1__155___r5_control_features_6_4;
					{
					   node_t val1322_1474;
					   val1322_1474 = (node_t) (ntrue_1194);
					   ((((conditional_t) CREF(node_1187))->true) = ((node_t) val1322_1474), BUNSPEC);
					}
					{
					   obj_t reset___255_1195;
					   reset___255_1195 = node_1occ__69_reduce_1occ((((conditional_t) CREF(node_1187))->false), _1_exp___225_1192);
					   {
					      obj_t nfalse_1196;
					      nfalse_1196 = _res1__155___r5_control_features_6_4;
					      {
						 node_t val1323_1477;
						 val1323_1477 = (node_t) (nfalse_1196);
						 ((((conditional_t) CREF(node_1187))->false) = ((node_t) val1323_1477), BUNSPEC);
					      }
					      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
					      _res1__155___r5_control_features_6_4 = (obj_t) (node_1187);
					      if (CBOOL(reset_1190))
						{
						   return reset_1190;
						}
					      else
						{
						   if (CBOOL(reset__69_1193))
						     {
							return reset__69_1193;
						     }
						   else
						     {
							return reset___255_1195;
						     }
						}
					   }
					}
				     }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 fail_t node_1204;
			 node_1204 = (fail_t) (node_2);
			 {
			    obj_t reset_1207;
			    reset_1207 = node_1occ__69_reduce_1occ((((fail_t) CREF(node_1204))->proc), _1_exp__141_3);
			    {
			       obj_t nproc_1208;
			       nproc_1208 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1333_1480;
				  val1333_1480 = (node_t) (nproc_1208);
				  ((((fail_t) CREF(node_1204))->proc) = ((node_t) val1333_1480), BUNSPEC);
			       }
			       {
				  obj_t _1_exp___225_1209;
				  if (CBOOL(reset_1207))
				    {
				       _1_exp___225_1209 = BNIL;
				    }
				  else
				    {
				       _1_exp___225_1209 = _1_exp__141_3;
				    }
				  {
				     obj_t reset__69_1210;
				     reset__69_1210 = node_1occ__69_reduce_1occ((((fail_t) CREF(node_1204))->msg), _1_exp___225_1209);
				     {
					obj_t nmsg_1211;
					nmsg_1211 = _res1__155___r5_control_features_6_4;
					{
					   node_t val1334_1483;
					   val1334_1483 = (node_t) (nmsg_1211);
					   ((((fail_t) CREF(node_1204))->msg) = ((node_t) val1334_1483), BUNSPEC);
					}
					{
					   obj_t reset___255_1213;
					   {
					      obj_t aux_1837;
					      if (CBOOL(reset__69_1210))
						{
						   aux_1837 = BNIL;
						}
					      else
						{
						   aux_1837 = _1_exp___225_1209;
						}
					      reset___255_1213 = node_1occ__69_reduce_1occ((((fail_t) CREF(node_1204))->obj), aux_1837);
					   }
					   {
					      obj_t nobj_1214;
					      nobj_1214 = _res1__155___r5_control_features_6_4;
					      {
						 node_t val1335_1486;
						 val1335_1486 = (node_t) (nobj_1214);
						 ((((fail_t) CREF(node_1204))->obj) = ((node_t) val1335_1486), BUNSPEC);
					      }
					      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
					      _res1__155___r5_control_features_6_4 = (obj_t) (node_1204);
					      if (CBOOL(reset_1207))
						{
						   return reset_1207;
						}
					      else
						{
						   if (CBOOL(reset__69_1210))
						     {
							return reset__69_1210;
						     }
						   else
						     {
							return reset___255_1213;
						     }
						}
					   }
					}
				     }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 select_t node_1222;
			 node_1222 = (select_t) (node_2);
			 {
			    obj_t reset_1225;
			    reset_1225 = node_1occ__69_reduce_1occ((((select_t) CREF(node_1222))->test), _1_exp__141_3);
			    {
			       obj_t ntest_1226;
			       ntest_1226 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1349_1489;
				  val1349_1489 = (node_t) (ntest_1226);
				  ((((select_t) CREF(node_1222))->test) = ((node_t) val1349_1489), BUNSPEC);
			       }
			       {
				  obj_t clauses_1228;
				  obj_t reset_1229;
				  clauses_1228 = (((select_t) CREF(node_1222))->clauses);
				  reset_1229 = reset_1225;
				loop_1230:
				  if (NULLP(clauses_1228))
				    {
				       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				       _res1__155___r5_control_features_6_4 = (obj_t) (node_1222);
				       return reset_1229;
				    }
				  else
				    {
				       obj_t clause_1235;
				       clause_1235 = CAR(clauses_1228);
				       {
					  obj_t reset__69_1236;
					  {
					     node_t aux_1860;
					     {
						obj_t aux_1861;
						aux_1861 = CDR(clause_1235);
						aux_1860 = (node_t) (aux_1861);
					     }
					     reset__69_1236 = node_1occ__69_reduce_1occ(aux_1860, _1_exp__141_3);
					  }
					  {
					     obj_t nclause_1237;
					     nclause_1237 = _res1__155___r5_control_features_6_4;
					     SET_CDR(clause_1235, nclause_1237);
					     {
						obj_t reset_1868;
						obj_t clauses_1866;
						clauses_1866 = CDR(clauses_1228);
						if (CBOOL(reset_1229))
						  {
						     reset_1868 = reset_1229;
						  }
						else
						  {
						     reset_1868 = reset__69_1236;
						  }
						reset_1229 = reset_1868;
						clauses_1228 = clauses_1866;
						goto loop_1230;
					     }
					  }
				       }
				    }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 let_fun_218_t node_1243;
			 node_1243 = (let_fun_218_t) (node_2);
			 {
			    obj_t reset_1246;
			    reset_1246 = node_1occ__69_reduce_1occ((((let_fun_218_t) CREF(node_1243))->body), _1_exp__141_3);
			    {
			       obj_t nbody_1247;
			       nbody_1247 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1363_1499;
				  val1363_1499 = (node_t) (nbody_1247);
				  ((((let_fun_218_t) CREF(node_1243))->body) = ((node_t) val1363_1499), BUNSPEC);
			       }
			       {
				  obj_t locals_1248;
				  obj_t reset_1249;
				  locals_1248 = (((let_fun_218_t) CREF(node_1243))->locals);
				  reset_1249 = reset_1246;
				loop_1250:
				  if (NULLP(locals_1248))
				    {
				       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				       _res1__155___r5_control_features_6_4 = (obj_t) (node_1243);
				       return reset_1249;
				    }
				  else
				    {
				       value_t sfun_1256;
				       {
					  local_t obj_1503;
					  {
					     obj_t aux_1881;
					     aux_1881 = CAR(locals_1248);
					     obj_1503 = (local_t) (aux_1881);
					  }
					  sfun_1256 = (((local_t) CREF(obj_1503))->value);
				       }
				       {
					  {
					     obj_t reset__69_1257;
					     {
						node_t aux_1885;
						{
						   obj_t aux_1886;
						   {
						      sfun_t obj_1504;
						      obj_1504 = (sfun_t) (sfun_1256);
						      aux_1886 = (((sfun_t) CREF(obj_1504))->body);
						   }
						   aux_1885 = (node_t) (aux_1886);
						}
						reset__69_1257 = node_1occ__69_reduce_1occ(aux_1885, BNIL);
					     }
					     {
						obj_t nbody_1258;
						nbody_1258 = _res1__155___r5_control_features_6_4;
						{
						   sfun_t obj_1505;
						   obj_1505 = (sfun_t) (sfun_1256);
						   ((((sfun_t) CREF(obj_1505))->body) = ((obj_t) nbody_1258), BUNSPEC);
						}
						{
						   obj_t reset_1895;
						   obj_t locals_1893;
						   locals_1893 = CDR(locals_1248);
						   if (CBOOL(reset_1249))
						     {
							reset_1895 = reset_1249;
						     }
						   else
						     {
							reset_1895 = reset__69_1257;
						     }
						   reset_1249 = reset_1895;
						   locals_1248 = locals_1893;
						   goto loop_1250;
						}
					     }
					  }
				       }
				    }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_var_6_t node_1265;
			 node_1265 = (let_var_6_t) (node_2);
			 {
			    obj_t obindings_1268;
			    bool_t reset_1269;
			    obj_t extend_1270;
			    obindings_1268 = (((let_var_6_t) CREF(node_1265))->bindings);
			    reset_1269 = ((bool_t) 0);
			    extend_1270 = BNIL;
			  loop_1271:
			    if (NULLP(obindings_1268))
			      {
				 if (reset_1269)
				   {
				      obj_t reset__69_1275;
				      reset__69_1275 = node_1occ__69_reduce_1occ((((let_var_6_t) CREF(node_1265))->body), BNIL);
				      {
					 obj_t nbody_1276;
					 nbody_1276 = _res1__155___r5_control_features_6_4;
					 {
					    node_t val1378_1512;
					    val1378_1512 = (node_t) (nbody_1276);
					    ((((let_var_6_t) CREF(node_1265))->body) = ((node_t) val1378_1512), BUNSPEC);
					 }
					 _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
					 _res1__155___r5_control_features_6_4 = (obj_t) (node_1265);
					 return BTRUE;
				      }
				   }
				 else
				   {
				      obj_t reset__69_1282;
				      reset__69_1282 = node_1occ__69_reduce_1occ((((let_var_6_t) CREF(node_1265))->body), append_2_18___r4_pairs_and_lists_6_3(extend_1270, _1_exp__141_3));
				      {
					 obj_t nbody_1283;
					 nbody_1283 = _res1__155___r5_control_features_6_4;
					 {
					    node_t val1378_1515;
					    val1378_1515 = (node_t) (nbody_1283);
					    ((((let_var_6_t) CREF(node_1265))->body) = ((node_t) val1378_1515), BUNSPEC);
					 }
					 {
					    obj_t obindings_1284;
					    obj_t nbindings_1285;
					    obindings_1284 = (((let_var_6_t) CREF(node_1265))->bindings);
					    nbindings_1285 = BNIL;
					  loop_1286:
					    if (NULLP(obindings_1284))
					      {
						 {
						    bool_t test_1916;
						    if ((((let_var_6_t) CREF(node_1265))->removable__42))
						      {
							 test_1916 = NULLP(nbindings_1285);
						      }
						    else
						      {
							 test_1916 = ((bool_t) 0);
						      }
						    if (test_1916)
						      {
							 _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
							 {
							    node_t aux_1921;
							    aux_1921 = (((let_var_6_t) CREF(node_1265))->body);
							    _res1__155___r5_control_features_6_4 = (obj_t) (aux_1921);
							 }
							 return reset__69_1282;
						      }
						    else
						      {
							 {
							    obj_t arg1728_1293;
							    arg1728_1293 = reverse__39___r4_pairs_and_lists_6_3(nbindings_1285);
							    ((((let_var_6_t) CREF(node_1265))->bindings) = ((obj_t) arg1728_1293), BUNSPEC);
							 }
							 _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
							 _res1__155___r5_control_features_6_4 = (obj_t) (node_1265);
							 return reset__69_1282;
						      }
						 }
					      }
					    else
					      {
						 bool_t test1730_1297;
						 {
						    bool_t test_1928;
						    {
						       long aux_1929;
						       {
							  local_t obj_1527;
							  {
							     obj_t aux_1930;
							     {
								obj_t aux_1931;
								aux_1931 = CAR(obindings_1284);
								aux_1930 = CAR(aux_1931);
							     }
							     obj_1527 = (local_t) (aux_1930);
							  }
							  aux_1929 = (((local_t) CREF(obj_1527))->occurrence);
						       }
						       test_1928 = (aux_1929 == ((long) 0));
						    }
						    if (test_1928)
						      {
							 bool_t test1739_1305;
							 {
							    node_t aux_1937;
							    {
							       obj_t aux_1938;
							       {
								  obj_t aux_1939;
								  aux_1939 = CAR(obindings_1284);
								  aux_1938 = CDR(aux_1939);
							       }
							       aux_1937 = (node_t) (aux_1938);
							    }
							    test1739_1305 = side_effect__165_effect_effect(aux_1937);
							 }
							 if (test1739_1305)
							   {
							      test1730_1297 = ((bool_t) 0);
							   }
							 else
							   {
							      test1730_1297 = ((bool_t) 1);
							   }
						      }
						    else
						      {
							 test1730_1297 = ((bool_t) 0);
						      }
						 }
						 if (test1730_1297)
						   {
						      {
							 obj_t obindings_1946;
							 obindings_1946 = CDR(obindings_1284);
							 obindings_1284 = obindings_1946;
							 goto loop_1286;
						      }
						   }
						 else
						   {
						      {
							 obj_t arg1732_1299;
							 obj_t arg1733_1300;
							 arg1732_1299 = CDR(obindings_1284);
							 {
							    obj_t aux_1949;
							    aux_1949 = CAR(obindings_1284);
							    arg1733_1300 = MAKE_PAIR(aux_1949, nbindings_1285);
							 }
							 {
							    obj_t nbindings_1953;
							    obj_t obindings_1952;
							    obindings_1952 = arg1732_1299;
							    nbindings_1953 = arg1733_1300;
							    nbindings_1285 = nbindings_1953;
							    obindings_1284 = obindings_1952;
							    goto loop_1286;
							 }
						      }
						   }
					      }
					 }
				      }
				   }
			      }
			    else
			      {
				 obj_t binding_1311;
				 binding_1311 = CAR(obindings_1268);
				 {
				    obj_t var_1312;
				    obj_t val_1313;
				    var_1312 = CAR(binding_1311);
				    val_1313 = CDR(binding_1311);
				    {
				       obj_t reset__69_1314;
				       reset__69_1314 = node_1occ__69_reduce_1occ((node_t) (val_1313), _1_exp__141_3);
				       {
					  obj_t nval_1315;
					  nval_1315 = _res1__155___r5_control_features_6_4;
					  SET_CDR(binding_1311, nval_1315);
					  {
					     bool_t test_1961;
					     if (reset_1269)
					       {
						  test_1961 = ((bool_t) 1);
					       }
					     else
					       {
						  test_1961 = CBOOL(reset__69_1314);
					       }
					     if (test_1961)
					       {
						  {
						     obj_t extend_1967;
						     bool_t reset_1966;
						     obj_t obindings_1964;
						     obindings_1964 = CDR(obindings_1268);
						     reset_1966 = ((bool_t) 1);
						     extend_1967 = BNIL;
						     extend_1270 = extend_1967;
						     reset_1269 = reset_1966;
						     obindings_1268 = obindings_1964;
						     goto loop_1271;
						  }
					       }
					     else
					       {
						  bool_t test1750_1319;
						  {
						     obj_t aux_1971;
						     obj_t aux_1968;
						     aux_1971 = CNST_TABLE_REF(((long) 0));
						     {
							local_t obj_1541;
							obj_1541 = (local_t) (var_1312);
							aux_1968 = (((local_t) CREF(obj_1541))->access);
						     }
						     test1750_1319 = (aux_1968 == aux_1971);
						  }
						  if (test1750_1319)
						    {
						       bool_t test1751_1320;
						       {
							  bool_t test_1975;
							  {
							     long aux_1976;
							     {
								local_t obj_1544;
								obj_1544 = (local_t) (var_1312);
								aux_1976 = (((local_t) CREF(obj_1544))->occurrence);
							     }
							     test_1975 = (aux_1976 == ((long) 1));
							  }
							  if (test_1975)
							    {
							       if (test1750_1319)
								 {
								    bool_t test1768_1333;
								    test1768_1333 = side_effect__165_effect_effect((node_t) (val_1313));
								    if (test1768_1333)
								      {
									 test1751_1320 = ((bool_t) 0);
								      }
								    else
								      {
									 test1751_1320 = ((bool_t) 1);
								      }
								 }
							       else
								 {
								    test1751_1320 = ((bool_t) 0);
								 }
							    }
							  else
							    {
							       test1751_1320 = ((bool_t) 0);
							    }
						       }
						       if (test1751_1320)
							 {
							    {
							       obj_t arg1753_1321;
							       obj_t arg1755_1322;
							       arg1753_1321 = CDR(obindings_1268);
							       arg1755_1322 = MAKE_PAIR(binding_1311, extend_1270);
							       {
								  obj_t extend_1989;
								  bool_t reset_1988;
								  obj_t obindings_1987;
								  obindings_1987 = arg1753_1321;
								  reset_1988 = ((bool_t) 0);
								  extend_1989 = arg1755_1322;
								  extend_1270 = extend_1989;
								  reset_1269 = reset_1988;
								  obindings_1268 = obindings_1987;
								  goto loop_1271;
							       }
							    }
							 }
						       else
							 {
							    {
							       bool_t test1756_1323;
							       {
								  bool_t test_1990;
								  {
								     long aux_1991;
								     {
									local_t obj_1553;
									obj_1553 = (local_t) (var_1312);
									aux_1991 = (((local_t) CREF(obj_1553))->occurrence);
								     }
								     test_1990 = (aux_1991 == ((long) 1));
								  }
								  if (test_1990)
								    {
								       if (test1750_1319)
									 {
									    test1756_1323 = side_effect__165_effect_effect((node_t) (val_1313));
									 }
								       else
									 {
									    test1756_1323 = ((bool_t) 0);
									 }
								    }
								  else
								    {
								       test1756_1323 = ((bool_t) 0);
								    }
							       }
							       if (test1756_1323)
								 {
								    BUNSPEC;
								 }
							       else
								 {
								    BUNSPEC;
								 }
							    }
							    {
							       bool_t reset_2001;
							       obj_t obindings_1999;
							       obindings_1999 = CDR(obindings_1268);
							       reset_2001 = ((bool_t) 0);
							       reset_1269 = reset_2001;
							       obindings_1268 = obindings_1999;
							       goto loop_1271;
							    }
							 }
						    }
						  else
						    {
						       {
							  bool_t reset_2004;
							  obj_t obindings_2002;
							  obindings_2002 = CDR(obindings_1268);
							  reset_2004 = ((bool_t) 0);
							  reset_1269 = reset_2004;
							  obindings_1268 = obindings_2002;
							  goto loop_1271;
						       }
						    }
					       }
					  }
				       }
				    }
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 set_ex_it_116_t node_1341;
			 node_1341 = (set_ex_it_116_t) (node_2);
			 {
			    obj_t reset_1344;
			    reset_1344 = node_1occ__69_reduce_1occ((((set_ex_it_116_t) CREF(node_1341))->body), _1_exp__141_3);
			    {
			       obj_t nbody_1345;
			       nbody_1345 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1389_1563;
				  val1389_1563 = (node_t) (nbody_1345);
				  ((((set_ex_it_116_t) CREF(node_1341))->body) = ((node_t) val1389_1563), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1341);
			       return reset_1344;
			    }
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 jump_ex_it_184_t node_1349;
			 node_1349 = (jump_ex_it_184_t) (node_2);
			 {
			    obj_t reset_1352;
			    reset_1352 = node_1occ__69_reduce_1occ((((jump_ex_it_184_t) CREF(node_1349))->exit), _1_exp__141_3);
			    {
			       obj_t nexit_1353;
			       nexit_1353 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1398_1566;
				  val1398_1566 = (node_t) (nexit_1353);
				  ((((jump_ex_it_184_t) CREF(node_1349))->exit) = ((node_t) val1398_1566), BUNSPEC);
			       }
			       {
				  obj_t reset__69_1355;
				  {
				     obj_t aux_2018;
				     if (CBOOL(reset_1352))
				       {
					  aux_2018 = BNIL;
				       }
				     else
				       {
					  aux_2018 = _1_exp__141_3;
				       }
				     reset__69_1355 = node_1occ__69_reduce_1occ((((jump_ex_it_184_t) CREF(node_1349))->value), aux_2018);
				  }
				  {
				     obj_t nvalue_1356;
				     nvalue_1356 = _res1__155___r5_control_features_6_4;
				     {
					node_t val1399_1569;
					val1399_1569 = (node_t) (nvalue_1356);
					((((jump_ex_it_184_t) CREF(node_1349))->value) = ((node_t) val1399_1569), BUNSPEC);
				     }
				     _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				     _res1__155___r5_control_features_6_4 = (obj_t) (node_1349);
				     if (CBOOL(reset_1352))
				       {
					  return reset_1352;
				       }
				     else
				       {
					  return reset__69_1355;
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 make_box_202_t node_1362;
			 node_1362 = (make_box_202_t) (node_2);
			 {
			    obj_t reset_1365;
			    reset_1365 = node_1occ__69_reduce_1occ((((make_box_202_t) CREF(node_1362))->value), _1_exp__141_3);
			    {
			       obj_t nvalue_1366;
			       nvalue_1366 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1411_1572;
				  val1411_1572 = (node_t) (nvalue_1366);
				  ((((make_box_202_t) CREF(node_1362))->value) = ((node_t) val1411_1572), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1362);
			       return reset_1365;
			    }
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 box_set__221_t node_1370;
			 node_1370 = (box_set__221_t) (node_2);
			 {
			    obj_t reset_1373;
			    reset_1373 = node_1occ__69_reduce_1occ((((box_set__221_t) CREF(node_1370))->value), _1_exp__141_3);
			    {
			       obj_t nvalue_1374;
			       nvalue_1374 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1433_1575;
				  val1433_1575 = (node_t) (nvalue_1374);
				  ((((box_set__221_t) CREF(node_1370))->value) = ((node_t) val1433_1575), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1370);
			       return reset_1373;
			    }
			 }
		      }
		      break;
		   case ((long) 19):
		      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
		      {
			 box_ref_242_t aux_2044;
			 aux_2044 = (box_ref_242_t) (node_2);
			 _res1__155___r5_control_features_6_4 = (obj_t) (aux_2044);
		      }
		      return BFALSE;
		      break;
		   case ((long) 20):
		      {
			 app_t node_1382;
			 node_1382 = (app_t) (node_2);
			 {
			    obj_t reset_1385;
			    reset_1385 = node_1occ___233_reduce_1occ((((app_t) CREF(node_1382))->args), _1_exp__141_3);
			    {
			       bool_t test1782_1386;
			       if (CBOOL(reset_1385))
				 {
				    test1782_1386 = ((bool_t) 1);
				 }
			       else
				 {
				    test1782_1386 = side_effect__165_effect_effect((node_t) (node_1382));
				 }
			       if (test1782_1386)
				 {
				    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				    _res1__155___r5_control_features_6_4 = (obj_t) (node_1382);
				    return BTRUE;
				 }
			       else
				 {
				    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				    _res1__155___r5_control_features_6_4 = (obj_t) (node_1382);
				    return BFALSE;
				 }
			    }
			 }
		      }
		      break;
		   default:
		    case_else1677_1114:
		      if (PROCEDUREP(method1671_1110))
			{
			   return PROCEDURE_ENTRY(method1671_1110) (method1671_1110, (obj_t) (node_2), _1_exp__141_3, BEOA);
			}
		      else
			{
			   obj_t fun1668_1104;
			   fun1668_1104 = PROCEDURE_REF(node_1occ__env_84_reduce_1occ, ((long) 0));
			   return PROCEDURE_ENTRY(fun1668_1104) (fun1668_1104, (obj_t) (node_2), _1_exp__141_3, BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1677_1114;
	      }
	 }
      }
   }
}


/* _node-1occ!1791 */ obj_t 
_node_1occ_1791_88_reduce_1occ(obj_t env_1586, obj_t node_1587, obj_t _1_exp__141_1588)
{
   return node_1occ__69_reduce_1occ((node_t) (node_1587), _1_exp__141_1588);
}


/* node-1occ!-default1512 */ obj_t 
node_1occ__default1512_239_reduce_1occ(node_t node_4, obj_t _1_exp__141_5)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string1794_reduce_1occ, (obj_t) (node_4));
}


/* _node-1occ!-default1512 */ obj_t 
_node_1occ__default1512_153_reduce_1occ(obj_t env_1589, obj_t node_1590, obj_t _1_exp__141_1591)
{
   return node_1occ__default1512_239_reduce_1occ((node_t) (node_1590), _1_exp__141_1591);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_reduce_1occ()
{
   module_initialization_70_tools_trace(((long) 0), "REDUCE_1OCC");
   module_initialization_70_tools_shape(((long) 0), "REDUCE_1OCC");
   module_initialization_70_tools_speek(((long) 0), "REDUCE_1OCC");
   module_initialization_70_tools_error(((long) 0), "REDUCE_1OCC");
   module_initialization_70_type_type(((long) 0), "REDUCE_1OCC");
   module_initialization_70_type_cache(((long) 0), "REDUCE_1OCC");
   module_initialization_70_coerce_typeof(((long) 0), "REDUCE_1OCC");
   module_initialization_70_coerce_coerce(((long) 0), "REDUCE_1OCC");
   module_initialization_70_effect_effect(((long) 0), "REDUCE_1OCC");
   module_initialization_70_ast_var(((long) 0), "REDUCE_1OCC");
   module_initialization_70_ast_node(((long) 0), "REDUCE_1OCC");
   module_initialization_70_ast_lvtype(((long) 0), "REDUCE_1OCC");
   return module_initialization_70_ast_occur(((long) 0), "REDUCE_1OCC");
}
