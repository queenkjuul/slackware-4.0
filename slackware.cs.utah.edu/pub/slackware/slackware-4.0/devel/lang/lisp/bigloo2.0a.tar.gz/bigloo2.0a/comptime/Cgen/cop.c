/*===========================================================================*/
/*   (Cgen/cop.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct cop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *cop_t;

typedef struct clabel
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t name;
     bool_t used__226;
     obj_t body;
  }
      *clabel_t;

typedef struct cgoto
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct clabel *label;
  }
     *cgoto_t;

typedef struct block
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
     *block_t;

typedef struct creturn
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
       *creturn_t;

typedef struct cvoid
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
     *cvoid_t;

typedef struct catom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t value;
  }
     *catom_t;

typedef struct varc
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct variable *variable;
  }
    *varc_t;

typedef struct cpragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t format;
     obj_t args;
  }
       *cpragma_t;

typedef struct ccast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct cop *arg;
  }
     *ccast_t;

typedef struct csequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     bool_t c_exp__163;
     obj_t cops;
  }
         *csequence_t;

typedef struct nop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *nop_t;

typedef struct stop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
    *stop_t;

typedef struct csetq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct varc *var;
     struct cop *value;
  }
     *csetq_t;

typedef struct cif
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     struct cop *true;
     struct cop *false;
  }
   *cif_t;

typedef struct local_var_164
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t vars;
  }
             *local_var_164_t;

typedef struct cfuncall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
     obj_t strength;
  }
        *cfuncall_t;

typedef struct capply
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     struct cop *arg;
  }
      *capply_t;

typedef struct capp
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
  }
    *capp_t;

typedef struct cfail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *proc;
     struct cop *msg;
     struct cop *obj;
  }
     *cfail_t;

typedef struct cswitch
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     obj_t clauses;
  }
       *cswitch_t;

typedef struct cmake_box_177
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
             *cmake_box_177_t;

typedef struct cbox_ref_44
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
  }
           *cbox_ref_44_t;

typedef struct cbox_set__132
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
     struct cop *value;
  }
             *cbox_set__132_t;

typedef struct cset_ex_it_123
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *jump_value_221;
     struct cop *body;
  }
              *cset_ex_it_123_t;

typedef struct cjump_ex_it_131
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *value;
  }
               *cjump_ex_it_131_t;

typedef struct sfun_c_188
  {
     struct clabel *label;
     bool_t integrated;
  }
          *sfun_c_188_t;

typedef struct bdb_block_21
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
            *bdb_block_21_t;


static obj_t _make_varc2744_204_cgen_cop(obj_t, obj_t, obj_t);
extern cop_t make_cop_70_cgen_cop(obj_t);
extern obj_t csetq_loc_set__106_cgen_cop(csetq_t, obj_t);
static obj_t object__struct_cop_119_cgen_cop(obj_t, obj_t);
static obj_t _cbox_ref_var2678_157_cgen_cop(obj_t, obj_t);
static obj_t struct_object__object_cmake_box_25_cgen_cop(obj_t, obj_t, obj_t);
extern cset_ex_it_123_t make_cset_ex_it_102_cgen_cop(obj_t, cop_t, cop_t, cop_t);
extern variable_t varc_variable_146_cgen_cop(varc_t);
static obj_t _cgoto_label2766_60_cgen_cop(obj_t, obj_t);
extern cif_t make_cif_3_cgen_cop(obj_t, cop_t, cop_t, cop_t);
static obj_t method_init_76_cgen_cop();
extern bdb_block_21_t allocate_bdb_block_152_cgen_cop();
extern bool_t local_var__228_cgen_cop(obj_t);
extern cop_t cfail_proc_96_cgen_cop(cfail_t);
static obj_t _clabel_name2770_181_cgen_cop(obj_t, obj_t);
extern bool_t csetq__161_cgen_cop(obj_t);
obj_t block_cgen_cop = BUNSPEC;
static obj_t _local_var_loc_set_2710_19_cgen_cop(obj_t, obj_t, obj_t);
extern varc_t csetq_var_122_cgen_cop(csetq_t);
static obj_t object__struct_cif_61_cgen_cop(obj_t, obj_t);
static obj_t _csetq_var2722_217_cgen_cop(obj_t, obj_t);
static obj_t _cbox_ref_loc_set_2676_199_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _capply_loc2701_113_cgen_cop(obj_t, obj_t);
extern capply_t make_capply_101_cgen_cop(obj_t, cop_t, cop_t);
extern obj_t nop_loc_175_cgen_cop(nop_t);
static obj_t _make_cjump_ex_it2659_119_cgen_cop(obj_t, obj_t, obj_t, obj_t);
obj_t cbox_ref_44_cgen_cop = BUNSPEC;
extern cop_t cfail_obj_133_cgen_cop(cfail_t);
extern obj_t stop_loc_69_cgen_cop(stop_t);
extern cfail_t allocate_cfail_187_cgen_cop();
extern cop_t cfail_msg_43_cgen_cop(cfail_t);
extern cswitch_t allocate_cswitch_92_cgen_cop();
static obj_t _bdb_block_loc_set_2628_168_cgen_cop(obj_t, obj_t, obj_t);
extern stop_t allocate_stop_49_cgen_cop();
extern obj_t cjump_ex_it_loc_set__72_cgen_cop(cjump_ex_it_131_t, obj_t);
extern stop_t make_stop_166_cgen_cop(obj_t, cop_t);
extern cop_t cset_ex_it_exit_130_cgen_cop(cset_ex_it_123_t);
static obj_t _stop_loc_set_2725_24_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _clabel_loc2769_184_cgen_cop(obj_t, obj_t);
extern obj_t csequence_loc_21_cgen_cop(csequence_t);
extern clabel_t allocate_clabel_48_cgen_cop();
extern cjump_ex_it_131_t allocate_cjump_ex_it_67_cgen_cop();
static obj_t struct_object__object_varc_23_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _sfun_c_the_closure2643_245_cgen_cop(obj_t, obj_t);
extern obj_t cfail_loc_182_cgen_cop(cfail_t);
extern cfail_t make_cfail_76_cgen_cop(obj_t, cop_t, cop_t, cop_t);
extern obj_t clabel_name_59_cgen_cop(clabel_t);
static obj_t _csequence__120_cgen_cop(obj_t, obj_t);
static obj_t object__struct_sfun_c_73_cgen_cop(obj_t, obj_t);
static obj_t object__struct_cfuncall_147_cgen_cop(obj_t, obj_t);
static obj_t _make_clabel2767_36_cgen_cop(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _cpragma_loc_set_2740_10_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _csequence_cops2733_166_cgen_cop(obj_t, obj_t);
extern obj_t sfun_c_property_set__116_cgen_cop(sfun_t, obj_t);
extern obj_t cbox_ref_loc_81_cgen_cop(cbox_ref_44_t);
static obj_t struct_object__object_csequence_144_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _csetq__142_cgen_cop(obj_t, obj_t);
static obj_t _make_cif2713_209_cgen_cop(obj_t, obj_t, obj_t, obj_t, obj_t);
extern cop_t cbox_set__var_213_cgen_cop(cbox_set__132_t);
static obj_t _allocate_cfuncall_49_cgen_cop(obj_t);
static obj_t _cmake_box__210_cgen_cop(obj_t, obj_t);
static obj_t _ccast_loc_set_2735_152_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _cif_true2717_251_cgen_cop(obj_t, obj_t);
static obj_t _allocate_block_150_cgen_cop(obj_t);
extern cop_t stop_value_3_cgen_cop(stop_t);
extern obj_t clabel_loc_12_cgen_cop(clabel_t);
extern local_var_164_t make_local_var_50_cgen_cop(obj_t, obj_t);
static obj_t struct_object__object_nop_31_cgen_cop(obj_t, obj_t, obj_t);
static obj_t struct_object__object_cset_ex_it_17_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _sfun_c_body2649_249_cgen_cop(obj_t, obj_t);
static obj_t _cpragma_args2743_86_cgen_cop(obj_t, obj_t);
static obj_t object__struct_stop_197_cgen_cop(obj_t, obj_t);
static obj_t _cjump_ex_it_loc2661_83_cgen_cop(obj_t, obj_t);
static obj_t _cop__234_cgen_cop(obj_t, obj_t);
static obj_t _cset_ex_it_loc_set_2665_239_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _make_cbox_set_2670_157_cgen_cop(obj_t, obj_t, obj_t, obj_t);
extern bool_t sfun_c_top__135_cgen_cop(sfun_t);
static obj_t _sfun_c_arity2633_20_cgen_cop(obj_t, obj_t);
static obj_t _cif_loc_set_2714_174_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _catom_loc2749_178_cgen_cop(obj_t, obj_t);
extern cop_t csetq_value_168_cgen_cop(csetq_t);
static obj_t _make_capply2699_147_cgen_cop(obj_t, obj_t, obj_t, obj_t);
static obj_t _sfun_c_stack_allocator_set_2638_247_cgen_cop(obj_t, obj_t, obj_t);
static obj_t struct_object__object_catom_48_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t local_var_loc_15_cgen_cop(local_var_164_t);
static obj_t object__struct_cbox_ref_102_cgen_cop(obj_t, obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
obj_t cjump_ex_it_131_cgen_cop = BUNSPEC;
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _sfun_c_side_effect_2635_59_cgen_cop(obj_t, obj_t);
extern obj_t sfun_c_side_effect__set__242_cgen_cop(sfun_t, obj_t);
static obj_t _cvoid_value2754_28_cgen_cop(obj_t, obj_t);
extern obj_t capply_loc_38_cgen_cop(capply_t);
static obj_t struct_object__object_ccast_65_cgen_cop(obj_t, obj_t, obj_t);
extern cfuncall_t allocate_cfuncall_37_cgen_cop();
extern bool_t bdb_block__15_cgen_cop(obj_t);
static obj_t _make_cfuncall2704_63_cgen_cop(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _allocate_creturn_205_cgen_cop(obj_t);
obj_t cpragma_cgen_cop = BUNSPEC;
static obj_t _allocate_cbox_ref_237_cgen_cop(obj_t);
static obj_t _make_block2759_147_cgen_cop(obj_t, obj_t, obj_t);
static obj_t struct_object__object_cgoto_101_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _nop__15_cgen_cop(obj_t, obj_t);
static obj_t _cbox_set__var2673_154_cgen_cop(obj_t, obj_t);
extern obj_t clabel_loc_set__72_cgen_cop(clabel_t, obj_t);
extern obj_t csetq_loc_189_cgen_cop(csetq_t);
extern obj_t csequence_loc_set__134_cgen_cop(csequence_t, obj_t);
extern cop_t cswitch_test_204_cgen_cop(cswitch_t);
extern cbox_set__132_t make_cbox_set__218_cgen_cop(obj_t, cop_t, cop_t);
extern cfuncall_t make_cfuncall_230_cgen_cop(obj_t, cop_t, obj_t, obj_t);
static obj_t object__struct_catom_180_cgen_cop(obj_t, obj_t);
obj_t varc_cgen_cop = BUNSPEC;
static obj_t _sfun_c_loc_set_2654_112_cgen_cop(obj_t, obj_t, obj_t);
static obj_t struct_object__object_capply_0_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
static obj_t _local_var_vars2712_20_cgen_cop(obj_t, obj_t);
static obj_t object__struct_ccast_238_cgen_cop(obj_t, obj_t);
static obj_t _sfun_c_side_effect__set_2634_236_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _sfun_c_property_set_2644_124_cgen_cop(obj_t, obj_t, obj_t);
extern bool_t block__82_cgen_cop(obj_t);
obj_t local_var_164_cgen_cop = BUNSPEC;
static obj_t object__struct_cgoto_44_cgen_cop(obj_t, obj_t);
static obj_t _clabel_used__set_2771_82_cgen_cop(obj_t, obj_t, obj_t);
extern cbox_ref_44_t allocate_cbox_ref_60_cgen_cop();
static obj_t object__struct_cset_ex_it_165_cgen_cop(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t creturn_loc_120_cgen_cop(creturn_t);
static obj_t _cswitch_loc_set_2684_178_cgen_cop(obj_t, obj_t, obj_t);
static obj_t struct_object__object_csetq_16_cgen_cop(obj_t, obj_t, obj_t);
static obj_t struct_object__object_stop_60_cgen_cop(obj_t, obj_t, obj_t);
obj_t catom_cgen_cop = BUNSPEC;
obj_t nop_cgen_cop = BUNSPEC;
extern obj_t cop_loc_231_cgen_cop(cop_t);
extern bdb_block_21_t make_bdb_block_176_cgen_cop(obj_t, cop_t);
obj_t ccast_cgen_cop = BUNSPEC;
static obj_t _sfun_c_body_set_2648_173_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t ccast_loc_144_cgen_cop(ccast_t);
static obj_t struct_object__object_cpragma_169_cgen_cop(obj_t, obj_t, obj_t);
extern cbox_ref_44_t make_cbox_ref_208_cgen_cop(obj_t, cop_t);
obj_t cswitch_cgen_cop = BUNSPEC;
static obj_t object__struct_local_var_3_cgen_cop(obj_t, obj_t);
static obj_t _sfun_c_the_closure_set_2642_89_cgen_cop(obj_t, obj_t, obj_t);
obj_t cgoto_cgen_cop = BUNSPEC;
extern cop_t cbox_set__value_106_cgen_cop(cbox_set__132_t);
extern obj_t cvoid_loc_set__124_cgen_cop(cvoid_t, obj_t);
static obj_t _cfail_obj2693_80_cgen_cop(obj_t, obj_t);
extern obj_t module_initialization_70_cgen_cop(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern cop_t capply_fun_1_cgen_cop(capply_t);
static obj_t _make_cvoid2751_4_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t sfun_c_dsssl_keywords_96_cgen_cop(sfun_t);
static obj_t _cfail_proc2691_25_cgen_cop(obj_t, obj_t);
extern cop_t cmake_box_value_135_cgen_cop(cmake_box_177_t);
static obj_t _struct_object__object2779_148___object(obj_t, obj_t, obj_t);
extern sfun_t allocate_sfun_c_74_cgen_cop();
static obj_t object__struct_csetq_144_cgen_cop(obj_t, obj_t);
static obj_t _cif__54_cgen_cop(obj_t, obj_t);
static obj_t _allocate_clabel_4_cgen_cop(obj_t);
extern capp_t allocate_capp_109_cgen_cop();
extern bool_t catom__16_cgen_cop(obj_t);
obj_t cbox_set__132_cgen_cop = BUNSPEC;
extern obj_t sfun_c_predicate_of_188_cgen_cop(sfun_t);
extern obj_t cbox_set__loc_125_cgen_cop(cbox_set__132_t);
extern capp_t make_capp_159_cgen_cop(obj_t, cop_t, obj_t);
extern obj_t capp_loc_231_cgen_cop(capp_t);
static obj_t _cbox_set__value2674_113_cgen_cop(obj_t, obj_t);
extern obj_t local_var_loc_set__93_cgen_cop(local_var_164_t, obj_t);
extern sfun_c_188_t widening1002_sfun_c_222_cgen_cop(clabel_t, bool_t);
extern creturn_t allocate_creturn_170_cgen_cop();
extern obj_t csequence_cops_198_cgen_cop(csequence_t);
extern cmake_box_177_t allocate_cmake_box_148_cgen_cop();
static obj_t object__struct_cpragma_233_cgen_cop(obj_t, obj_t);
static obj_t _cfuncall__70_cgen_cop(obj_t, obj_t);
static obj_t _cfail_loc2690_159_cgen_cop(obj_t, obj_t);
extern obj_t cpragma_args_115_cgen_cop(cpragma_t);
extern bool_t cop__160_cgen_cop(obj_t);
static obj_t _block__12_cgen_cop(obj_t, obj_t);
extern bool_t csequence_c_exp__44_cgen_cop(csequence_t);
obj_t clabel_cgen_cop = BUNSPEC;
static obj_t _cfuncall_loc2706_72_cgen_cop(obj_t, obj_t);
extern block_t allocate_block_20_cgen_cop();
extern cop_t cjump_ex_it_value_92_cgen_cop(cjump_ex_it_131_t);
extern bool_t capp__160_cgen_cop(obj_t);
obj_t csetq_cgen_cop = BUNSPEC;
extern obj_t cset_ex_it_loc_set__45_cgen_cop(cset_ex_it_123_t, obj_t);
static obj_t _catom_loc_set_2748_111_cgen_cop(obj_t, obj_t, obj_t);
extern clabel_t cgoto_label_241_cgen_cop(cgoto_t);
extern obj_t catom_loc_set__236_cgen_cop(catom_t, obj_t);
static obj_t _make_cmake_box2679_81_cgen_cop(obj_t, obj_t, obj_t);
static obj_t object__struct_cbox_set__79_cgen_cop(obj_t, obj_t);
static obj_t _local_var__240_cgen_cop(obj_t, obj_t);
extern bool_t stop__17_cgen_cop(obj_t);
static obj_t _cswitch__47_cgen_cop(obj_t, obj_t);
static obj_t _varc__28_cgen_cop(obj_t, obj_t);
static obj_t struct_object__object_cswitch_246_cgen_cop(obj_t, obj_t, obj_t);
obj_t bdb_block_21_cgen_cop = BUNSPEC;
static obj_t _cpragma_loc2741_49_cgen_cop(obj_t, obj_t);
static obj_t struct_object__object_cop_66_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _ccast_type2737_234_cgen_cop(obj_t, obj_t);
extern long class_num_218___object(obj_t);
static obj_t _cmake_box_loc_set_2680_187_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _allocate_catom_138_cgen_cop(obj_t);
extern bool_t nop__205_cgen_cop(obj_t);
extern obj_t sfun_c_dsssl_keywords_set__154_cgen_cop(sfun_t, obj_t);
extern block_t make_block_156_cgen_cop(obj_t, cop_t);
static obj_t object__struct_capp_230_cgen_cop(obj_t, obj_t);
static obj_t _sfun_c_integrated_set_2657_241_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _make_cset_ex_it2664_66_cgen_cop(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t struct_object__object_cif_118_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _allocate_ccast_222_cgen_cop(obj_t);
obj_t stop_cgen_cop = BUNSPEC;
static obj_t _cjump_ex_it_exit2662_210_cgen_cop(obj_t, obj_t);
static obj_t _capp_args2698_252_cgen_cop(obj_t, obj_t);
extern bool_t ccast__115_cgen_cop(obj_t);
extern clabel_t make_clabel_15_cgen_cop(obj_t, obj_t, bool_t, obj_t);
extern cop_t creturn_value_251_cgen_cop(creturn_t);
extern obj_t sfun_c_body_138_cgen_cop(sfun_t);
static obj_t _make_creturn2755_253_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _allocate_cgoto_159_cgen_cop(obj_t);
extern obj_t catom_value_103_cgen_cop(catom_t);
static obj_t _cset_ex_it__255_cgen_cop(obj_t, obj_t);
static obj_t _capp_loc2696_15_cgen_cop(obj_t, obj_t);
extern cop_t capply_arg_66_cgen_cop(capply_t);
extern obj_t ccast_loc_set__38_cgen_cop(ccast_t, obj_t);
static obj_t _catom__202_cgen_cop(obj_t, obj_t);
static obj_t _capply_fun2702_109_cgen_cop(obj_t, obj_t);
static obj_t object__struct_cswitch_161_cgen_cop(obj_t, obj_t);
extern obj_t sfun_c_side_effect__183_cgen_cop(sfun_t);
static obj_t _make_bdb_block2627_154_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t cop_loc_set__54_cgen_cop(cop_t, obj_t);
extern obj_t catom_loc_164_cgen_cop(catom_t);
static obj_t _cbox_set__loc_set_2671_185_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _ccast_loc2736_52_cgen_cop(obj_t, obj_t);
static obj_t _make_stop2724_181_cgen_cop(obj_t, obj_t, obj_t);
extern long sfun_c_arity_65_cgen_cop(sfun_t);
static obj_t object__struct_bdb_block_145_cgen_cop(obj_t, obj_t);
extern cop_t capp_fun_71_cgen_cop(capp_t);
static obj_t _make_cfail2688_47_cgen_cop(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t sfun_c_the_closure_51_cgen_cop(sfun_t);
extern bool_t cswitch__75_cgen_cop(obj_t);
static obj_t _allocate_local_var_109_cgen_cop(obj_t);
extern csequence_t allocate_csequence_231_cgen_cop();
extern obj_t sfun_c_loc_set__123_cgen_cop(sfun_t, obj_t);
extern obj_t sfun_c_class_37_cgen_cop(sfun_t);
extern obj_t sfun_c_args_set__112_cgen_cop(sfun_t, obj_t);
static obj_t _sfun_c_integrated2658_215_cgen_cop(obj_t, obj_t);
static obj_t imported_modules_init_94_cgen_cop();
static obj_t _cfuncall_loc_set_2705_205_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _cgoto_loc2765_49_cgen_cop(obj_t, obj_t);
static obj_t _allocate_csetq_62_cgen_cop(obj_t);
static obj_t _sfun_c_predicate_of2637_187_cgen_cop(obj_t, obj_t);
static obj_t _allocate_varc_172_cgen_cop(obj_t);
extern obj_t cset_ex_it_loc_150_cgen_cop(cset_ex_it_123_t);
extern nop_t allocate_nop_42_cgen_cop();
static obj_t _creturn_value2758_124_cgen_cop(obj_t, obj_t);
extern obj_t sfun_c_class_set__22_cgen_cop(sfun_t, obj_t);
static obj_t _csequence_loc2731_3_cgen_cop(obj_t, obj_t);
extern bool_t cif__209_cgen_cop(obj_t);
static obj_t _cswitch_test2686_46_cgen_cop(obj_t, obj_t);
static obj_t _make_csequence_138_cgen_cop(obj_t, obj_t, obj_t, obj_t);
extern bool_t cset_ex_it__60_cgen_cop(obj_t);
extern bool_t cgoto__160_cgen_cop(obj_t);
static obj_t struct_object__object_capp_36_cgen_cop(obj_t, obj_t, obj_t);
extern cop_t ccast_arg_212_cgen_cop(ccast_t);
static obj_t _ccast__188_cgen_cop(obj_t, obj_t);
static obj_t _creturn__112_cgen_cop(obj_t, obj_t);
extern cop_t cif_true_58_cgen_cop(cif_t);
obj_t cop_cgen_cop = BUNSPEC;
extern obj_t sfun_c_property_208_cgen_cop(sfun_t);
static obj_t _csetq_loc_set_2720_84_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t cmake_box_loc_203_cgen_cop(cmake_box_177_t);
static obj_t _allocate_cbox_set__70_cgen_cop(obj_t);
extern obj_t cpragma_loc_96_cgen_cop(cpragma_t);
extern obj_t sfun_c_args_197_cgen_cop(sfun_t);
obj_t cif_cgen_cop = BUNSPEC;
static obj_t _varc_loc2746_80_cgen_cop(obj_t, obj_t);
extern obj_t cswitch_loc_193_cgen_cop(cswitch_t);
static obj_t _allocate_sfun_c_103_cgen_cop(obj_t);
extern bool_t cbox_ref__107_cgen_cop(obj_t);
static obj_t _cfail_msg2692_109_cgen_cop(obj_t, obj_t);
static obj_t _cjump_ex_it_loc_set_2660_78_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _make_csetq2719_239_cgen_cop(obj_t, obj_t, obj_t, obj_t);
extern cop_t cjump_ex_it_exit_93_cgen_cop(cjump_ex_it_131_t);
obj_t creturn_cgen_cop = BUNSPEC;
extern obj_t capp_loc_set__54_cgen_cop(capp_t, obj_t);
static obj_t _bdb_block__112_cgen_cop(obj_t, obj_t);
extern cop_t bdb_block_body_146_cgen_cop(bdb_block_21_t);
static obj_t _cop_loc_set_2775_219_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _nop_loc_set_2728_230_cgen_cop(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_cgen_cop();
extern obj_t bdb_block_loc_147_cgen_cop(bdb_block_21_t);
obj_t sfun_c_188_cgen_cop = BUNSPEC;
extern obj_t cif_loc_set__209_cgen_cop(cif_t, obj_t);
static obj_t _clabel_body_set_2773_235_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t cgoto_loc_231_cgen_cop(cgoto_t);
static obj_t _creturn_loc2757_219_cgen_cop(obj_t, obj_t);
static obj_t struct_object__object_cvoid_49_cgen_cop(obj_t, obj_t, obj_t);
extern bool_t creturn__207_cgen_cop(obj_t);
static obj_t _allocate_bdb_block_200_cgen_cop(obj_t);
static obj_t _sfun_c_class2651_178_cgen_cop(obj_t, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t object__struct_capply_87_cgen_cop(obj_t, obj_t);
extern cmake_box_177_t make_cmake_box_87_cgen_cop(obj_t, cop_t);
extern bool_t sfun_c_integrated_120_cgen_cop(sfun_c_188_t);
static obj_t _cop_loc2776_142_cgen_cop(obj_t, obj_t);
extern obj_t cfuncall_loc_set__107_cgen_cop(cfuncall_t, obj_t);
static obj_t struct_object__object_clabel_24_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t capp_args_148_cgen_cop(capp_t);
extern obj_t varc_loc_set__52_cgen_cop(varc_t, obj_t);
extern catom_t allocate_catom_78_cgen_cop();
static obj_t _make_ccast2734_32_cgen_cop(obj_t, obj_t, obj_t, obj_t);
static obj_t _allocate_cset_ex_it_129_cgen_cop(obj_t);
static obj_t _cgoto__255_cgen_cop(obj_t, obj_t);
extern ccast_t allocate_ccast_96_cgen_cop();
static obj_t _clabel_used_2772_222_cgen_cop(obj_t, obj_t);
extern obj_t sfun_c_top__set__31_cgen_cop(sfun_t, bool_t);
static obj_t _sfun_c_loc2655_19_cgen_cop(obj_t, obj_t);
extern bool_t cjump_ex_it__247_cgen_cop(obj_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
extern cgoto_t allocate_cgoto_58_cgen_cop();
static obj_t _cif_loc2715_71_cgen_cop(obj_t, obj_t);
extern sfun_c_188_t make_sfun_c_65_cgen_cop(long, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, clabel_t, bool_t);
static obj_t struct_object__object_creturn_28_cgen_cop(obj_t, obj_t, obj_t);
static obj_t object__struct_cvoid_78_cgen_cop(obj_t, obj_t);
static obj_t _capply_arg2703_187_cgen_cop(obj_t, obj_t);
static obj_t toplevel_init_63_cgen_cop();
extern cop_t cset_ex_it_jump_value_128_cgen_cop(cset_ex_it_123_t);
static obj_t _cset_ex_it_body2669_156_cgen_cop(obj_t, obj_t);
extern obj_t sfun_c_predicate_of_set__140_cgen_cop(sfun_t, obj_t);
static obj_t struct_object__object_local_var_195_cgen_cop(obj_t, obj_t, obj_t);
obj_t capp_cgen_cop = BUNSPEC;
static obj_t _cset_ex_it_jump_value2668_122_cgen_cop(obj_t, obj_t);
extern catom_t make_catom_185_cgen_cop(obj_t, obj_t);
extern obj_t block_loc_set__28_cgen_cop(block_t, obj_t);
extern obj_t cfail_loc_set__82_cgen_cop(cfail_t, obj_t);
extern obj_t sfun_c_stack_allocator_34_cgen_cop(sfun_t);
extern ccast_t make_ccast_74_cgen_cop(obj_t, type_t, cop_t);
static obj_t _cswitch_clauses2687_232_cgen_cop(obj_t, obj_t);
static obj_t _allocate_stop_67_cgen_cop(obj_t);
extern obj_t cjump_ex_it_loc_12_cgen_cop(cjump_ex_it_131_t);
static obj_t _sfun_c_dsssl_keywords_set_2652_202_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _cpragma__0_cgen_cop(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t _nop_loc2729_69_cgen_cop(obj_t, obj_t);
extern cgoto_t make_cgoto_92_cgen_cop(obj_t, clabel_t);
extern obj_t cmake_box_loc_set__105_cgen_cop(cmake_box_177_t, obj_t);
static obj_t _sfun_c_args_set_2646_77_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t capply_loc_set__0_cgen_cop(capply_t, obj_t);
extern bool_t clabel_used__102_cgen_cop(clabel_t);
static obj_t _cmake_box_loc2681_4_cgen_cop(obj_t, obj_t);
static obj_t _make_cpragma2739_122_cgen_cop(obj_t, obj_t, obj_t, obj_t);
static obj_t object__struct_creturn_165_cgen_cop(obj_t, obj_t);
static obj_t _stop_loc2726_93_cgen_cop(obj_t, obj_t);
static obj_t _block_loc_set_2760_160_cgen_cop(obj_t, obj_t, obj_t);
obj_t cvoid_cgen_cop = BUNSPEC;
extern obj_t sfun_ast_var;
extern obj_t cbox_ref_loc_set__77_cgen_cop(cbox_ref_44_t, obj_t);
static obj_t _cif_test2716_234_cgen_cop(obj_t, obj_t);
static obj_t _block_loc2761_12_cgen_cop(obj_t, obj_t);
static obj_t _make_cbox_ref2675_90_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _make_capp2694_163_cgen_cop(obj_t, obj_t, obj_t, obj_t);
extern csetq_t allocate_csetq_141_cgen_cop();
static obj_t _make_cswitch2683_182_cgen_cop(obj_t, obj_t, obj_t, obj_t);
obj_t cmake_box_177_cgen_cop = BUNSPEC;
static obj_t _sfun_c_label2656_48_cgen_cop(obj_t, obj_t);
static obj_t _cset_ex_it_exit2667_56_cgen_cop(obj_t, obj_t);
extern cpragma_t make_cpragma_16_cgen_cop(obj_t, obj_t, obj_t);
extern bool_t cbox_set___212_cgen_cop(obj_t);
extern csequence_t make_csequence_181_cgen_cop(obj_t, bool_t, obj_t);
static obj_t struct_object__object_cbox_set__145_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t varc_loc_177_cgen_cop(varc_t);
static obj_t _sfun_c__160_cgen_cop(obj_t, obj_t);
extern obj_t cfuncall_loc_128_cgen_cop(cfuncall_t);
static obj_t struct_object__object_cfail_119_cgen_cop(obj_t, obj_t, obj_t);
extern cop_t allocate_cop_141_cgen_cop();
extern obj_t creturn_loc_set__24_cgen_cop(creturn_t, obj_t);
extern obj_t cbox_set__loc_set__99_cgen_cop(cbox_set__132_t, obj_t);
static obj_t _cvoid_loc_set_2752_198_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _cbox_ref_loc2677_114_cgen_cop(obj_t, obj_t);
extern csetq_t make_csetq_177_cgen_cop(obj_t, varc_t, cop_t);
extern bool_t cpragma__50_cgen_cop(obj_t);
extern bool_t cvoid__191_cgen_cop(obj_t);
extern cif_t allocate_cif_90_cgen_cop();
static obj_t _sfun_c_predicate_of_set_2636_153_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _cfuncall_fun2707_141_cgen_cop(obj_t, obj_t);
static obj_t object__struct_cmake_box_32_cgen_cop(obj_t, obj_t);
static obj_t _sfun_c_top__set_2640_57_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t object___object;
static obj_t _csetq_loc2721_49_cgen_cop(obj_t, obj_t);
static obj_t struct_object__object_cfuncall_72_cgen_cop(obj_t, obj_t, obj_t);
static obj_t object__struct_cfail_230_cgen_cop(obj_t, obj_t);
static obj_t _cvoid_loc2753_0_cgen_cop(obj_t, obj_t);
static obj_t _make_nop_127_cgen_cop(obj_t, obj_t);
static obj_t _capply__134_cgen_cop(obj_t, obj_t);
static obj_t struct_object__object_bdb_block_117_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t cpragma_format_90_cgen_cop(cpragma_t);
extern obj_t sfun_c_the_closure_set__169_cgen_cop(sfun_t, obj_t);
static obj_t _allocate_nop_142_cgen_cop(obj_t);
extern obj_t stop_loc_set__39_cgen_cop(stop_t, obj_t);
extern cswitch_t make_cswitch_250_cgen_cop(obj_t, cop_t, obj_t);
static obj_t _sfun_c_dsssl_keywords2653_22_cgen_cop(obj_t, obj_t);
extern cop_t cif_test_82_cgen_cop(cif_t);
extern type_t ccast_type_180_cgen_cop(ccast_t);
extern capply_t allocate_capply_99_cgen_cop();
static obj_t _allocate_cvoid_169_cgen_cop(obj_t);
static obj_t _catom_value2750_110_cgen_cop(obj_t, obj_t);
static obj_t _capp_fun2697_239_cgen_cop(obj_t, obj_t);
static obj_t _csetq_value2723_42_cgen_cop(obj_t, obj_t);
obj_t csequence_cgen_cop = BUNSPEC;
obj_t cfail_cgen_cop = BUNSPEC;
extern obj_t cswitch_loc_set__163_cgen_cop(cswitch_t, obj_t);
static obj_t struct_object__object_cbox_ref_164_cgen_cop(obj_t, obj_t, obj_t);
static obj_t struct_object__object_sfun_c_84_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _varc_variable2747_221_cgen_cop(obj_t, obj_t);
extern obj_t cgoto_loc_set__54_cgen_cop(cgoto_t, obj_t);
static obj_t _bdb_block_loc2629_39_cgen_cop(obj_t, obj_t);
static obj_t _cmake_box_value2682_176_cgen_cop(obj_t, obj_t);
extern cop_t cfuncall_fun_206_cgen_cop(cfuncall_t);
static obj_t _cjump_ex_it_value2663_237_cgen_cop(obj_t, obj_t);
extern bool_t csequence__124_cgen_cop(obj_t);
extern obj_t cif_loc_54_cgen_cop(cif_t);
static obj_t _cvoid__92_cgen_cop(obj_t, obj_t);
extern nop_t make_nop_193_cgen_cop(obj_t);
extern bool_t sfun_c__72_cgen_cop(obj_t);
static obj_t _cpragma_format2742_234_cgen_cop(obj_t, obj_t);
extern bool_t cfail__244_cgen_cop(obj_t);
static obj_t _creturn_loc_set_2756_44_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t bdb_block_loc_set__89_cgen_cop(bdb_block_21_t, obj_t);
static obj_t _cswitch_loc2685_52_cgen_cop(obj_t, obj_t);
static obj_t _capp__47_cgen_cop(obj_t, obj_t);
static obj_t _varc_loc_set_2745_98_cgen_cop(obj_t, obj_t, obj_t);
static obj_t object__struct_nop_253_cgen_cop(obj_t, obj_t);
static obj_t object_init_111_cgen_cop();
extern obj_t clabel_body_set__90_cgen_cop(clabel_t, obj_t);
static obj_t object__struct_csequence_69_cgen_cop(obj_t, obj_t);
static obj_t _stop__237_cgen_cop(obj_t, obj_t);
extern cop_t cset_ex_it_body_210_cgen_cop(cset_ex_it_123_t);
extern bool_t cmake_box__185_cgen_cop(obj_t);
static obj_t _cfuncall_strength2709_48_cgen_cop(obj_t, obj_t);
extern cop_t block_body_21_cgen_cop(block_t);
static obj_t _csequence_c_exp_2732_23_cgen_cop(obj_t, obj_t);
static obj_t _allocate_cjump_ex_it_10_cgen_cop(obj_t);
extern cset_ex_it_123_t allocate_cset_ex_it_68_cgen_cop();
static obj_t _sfun_c_property2645_193_cgen_cop(obj_t, obj_t);
static obj_t _allocate_capp_243_cgen_cop(obj_t);
extern obj_t sfun_c_integrated_set__24_cgen_cop(sfun_c_188_t, bool_t);
static obj_t _clabel__209_cgen_cop(obj_t, obj_t);
obj_t cset_ex_it_123_cgen_cop = BUNSPEC;
extern obj_t nop_loc_set__235_cgen_cop(nop_t, obj_t);
static obj_t _bdb_block_body2630_50_cgen_cop(obj_t, obj_t);
static obj_t _make_cgoto2763_123_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _allocate_cmake_box_154_cgen_cop(obj_t);
extern cjump_ex_it_131_t make_cjump_ex_it_216_cgen_cop(obj_t, cop_t, cop_t);
extern bool_t capply__56_cgen_cop(obj_t);
static obj_t _cfuncall_args2708_4_cgen_cop(obj_t, obj_t);
static obj_t _capply_loc_set_2700_55_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t sfun_c_loc_247_cgen_cop(sfun_t);
static obj_t _make_sfun_c2632_73_cgen_cop(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _cbox_set__loc2672_191_cgen_cop(obj_t, obj_t);
static obj_t _cjump_ex_it__240_cgen_cop(obj_t, obj_t);
static obj_t _allocate_cfail_114_cgen_cop(obj_t);
static obj_t _csequence_loc_set_2730_187_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _cbox_ref__77_cgen_cop(obj_t, obj_t);
static obj_t _cfail_loc_set_2689_94_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t sfun_c_body_set__172_cgen_cop(sfun_t, obj_t);
static obj_t _allocate_cpragma_102_cgen_cop(obj_t);
static obj_t _widening1002_sfun_c2631_56_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t clabel_used__set__46_cgen_cop(clabel_t, bool_t);
static obj_t _block_body2762_237_cgen_cop(obj_t, obj_t);
static obj_t _cfail__212_cgen_cop(obj_t, obj_t);
static obj_t _cgoto_loc_set_2764_203_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _stop_value2727_118_cgen_cop(obj_t, obj_t);
static obj_t _clabel_loc_set_2768_200_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _clabel_body2774_177_cgen_cop(obj_t, obj_t);
extern bool_t varc__41_cgen_cop(obj_t);
extern local_var_164_t allocate_local_var_218_cgen_cop();
extern obj_t cfuncall_args_216_cgen_cop(cfuncall_t);
static obj_t _sfun_c_top_2641_78_cgen_cop(obj_t, obj_t);
static obj_t object__struct_cjump_ex_it_155_cgen_cop(obj_t, obj_t);
extern obj_t block_loc_240_cgen_cop(block_t);
static obj_t object__struct_clabel_136_cgen_cop(obj_t, obj_t);
static obj_t _sfun_c_stack_allocator2639_86_cgen_cop(obj_t, obj_t);
extern cop_t cif_false_61_cgen_cop(cif_t);
extern varc_t allocate_varc_53_cgen_cop();
extern obj_t cswitch_clauses_50_cgen_cop(cswitch_t);
extern varc_t make_varc_148_cgen_cop(obj_t, variable_t);
static obj_t _local_var_loc2711_133_cgen_cop(obj_t, obj_t);
static obj_t _make_catom_20_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _sfun_c_class_set_2650_224_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t cpragma_loc_set__154_cgen_cop(cpragma_t, obj_t);
static obj_t _make_cop_194_cgen_cop(obj_t, obj_t);
static obj_t _make_local_var_232_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t object__struct_50___object(object_t);
extern cvoid_t allocate_cvoid_159_cgen_cop();
static obj_t struct_object__object_block_188_cgen_cop(obj_t, obj_t, obj_t);
static obj_t _cif_false2718_168_cgen_cop(obj_t, obj_t);
static obj_t _object__struct2781_4___object(obj_t, obj_t);
static obj_t _allocate_csequence_87_cgen_cop(obj_t);
extern bool_t clabel__247_cgen_cop(obj_t);
static obj_t _allocate_capply_222_cgen_cop(obj_t);
extern bool_t cfuncall__223_cgen_cop(obj_t);
extern cop_t cbox_ref_var_149_cgen_cop(cbox_ref_44_t);
static obj_t require_initialization_114_cgen_cop = BUNSPEC;
static obj_t _allocate_cswitch_108_cgen_cop(obj_t);
static obj_t _allocate_cop_129_cgen_cop(obj_t);
static obj_t _ccast_arg2738_227_cgen_cop(obj_t, obj_t);
static obj_t _cset_ex_it_loc2666_211_cgen_cop(obj_t, obj_t);
static obj_t struct_object__object_cjump_ex_it_93_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t cfuncall_strength_61_cgen_cop(cfuncall_t);
extern cbox_set__132_t allocate_cbox_set__13_cgen_cop();
static obj_t _allocate_cif_80_cgen_cop(obj_t);
extern cvoid_t make_cvoid_194_cgen_cop(obj_t, cop_t);
extern obj_t clabel_body_114_cgen_cop(clabel_t);
extern creturn_t make_creturn_204_cgen_cop(obj_t, cop_t);
static obj_t object__struct_block_53_cgen_cop(obj_t, obj_t);
extern clabel_t sfun_c_label_89_cgen_cop(sfun_c_188_t);
obj_t capply_cgen_cop = BUNSPEC;
static obj_t object__struct_varc_203_cgen_cop(obj_t, obj_t);
extern cop_t cvoid_value_152_cgen_cop(cvoid_t);
static obj_t _cbox_set___248_cgen_cop(obj_t, obj_t);
static obj_t _sfun_c_args2647_83_cgen_cop(obj_t, obj_t);
static obj_t cnst_init_137_cgen_cop();
extern obj_t cvoid_loc_83_cgen_cop(cvoid_t);
extern cpragma_t allocate_cpragma_231_cgen_cop();
obj_t cfuncall_cgen_cop = BUNSPEC;
static obj_t _capp_loc_set_2695_133_cgen_cop(obj_t, obj_t, obj_t);
extern obj_t local_var_vars_243_cgen_cop(local_var_164_t);
extern obj_t sfun_c_stack_allocator_set__151_cgen_cop(sfun_t, obj_t);
static obj_t __cnst[28];

DEFINE_EXPORT_PROCEDURE(capp_fun_env_136_cgen_cop, _capp_fun2697_239_cgen_cop2844, _capp_fun2697_239_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_varc_env_82_cgen_cop, _make_varc2744_204_cgen_cop2845, _make_varc2744_204_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfail_proc_env_158_cgen_cop, _cfail_proc2691_25_cgen_cop2846, _cfail_proc2691_25_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_predicate_of_set__env_143_cgen_cop, _sfun_c_predicate_of_set_2636_153_cgen_cop2847, _sfun_c_predicate_of_set_2636_153_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_cvoid_env_246_cgen_cop, _make_cvoid2751_4_cgen_cop2848, _make_cvoid2751_4_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_local_var_env_210_cgen_cop, _make_local_var_232_cgen_cop2849, _make_local_var_232_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(csetq_var_env_238_cgen_cop, _csetq_var2722_217_cgen_cop2850, _csetq_var2722_217_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_creturn_env_236_cgen_cop, _make_creturn2755_253_cgen_cop2851, _make_creturn2755_253_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cswitch_loc_set__env_255_cgen_cop, _cswitch_loc_set_2684_178_cgen_cop2852, _cswitch_loc_set_2684_178_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(clabel__env_62_cgen_cop, _clabel__209_cgen_cop2853, _clabel__209_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(csequence_loc_env_123_cgen_cop, _csequence_loc2731_3_cgen_cop2854, _csequence_loc2731_3_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(creturn_value_env_173_cgen_cop, _creturn_value2758_124_cgen_cop2855, _creturn_value2758_124_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_body_set__env_224_cgen_cop, _sfun_c_body_set_2648_173_cgen_cop2856, _sfun_c_body_set_2648_173_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_var_loc_set__env_209_cgen_cop, _local_var_loc_set_2710_19_cgen_cop2857, _local_var_loc_set_2710_19_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_ccast_env_158_cgen_cop, _allocate_ccast_222_cgen_cop2858, _allocate_ccast_222_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(catom_value_env_21_cgen_cop, _catom_value2750_110_cgen_cop2859, _catom_value2750_110_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cbox_set__value_env_17_cgen_cop, _cbox_set__value2674_113_cgen_cop2860, _cbox_set__value2674_113_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(csetq_value_env_132_cgen_cop, _csetq_value2723_42_cgen_cop2861, _csetq_value2723_42_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(creturn__env_8_cgen_cop, _creturn__112_cgen_cop2862, _creturn__112_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(bdb_block_loc_set__env_133_cgen_cop, _bdb_block_loc_set_2628_168_cgen_cop2863, _bdb_block_loc_set_2628_168_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2837_cgen_cop, struct_object__object_cop_66_cgen_cop2864, struct_object__object_cop_66_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2836_cgen_cop, object__struct_cop_119_cgen_cop2865, object__struct_cop_119_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2835_cgen_cop, struct_object__object_clabel_24_cgen_cop2866, struct_object__object_clabel_24_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2834_cgen_cop, object__struct_clabel_136_cgen_cop2867, object__struct_clabel_136_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2833_cgen_cop, struct_object__object_cgoto_101_cgen_cop2868, struct_object__object_cgoto_101_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2832_cgen_cop, object__struct_cgoto_44_cgen_cop2869, object__struct_cgoto_44_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2831_cgen_cop, struct_object__object_block_188_cgen_cop2870, struct_object__object_block_188_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2829_cgen_cop, struct_object__object_creturn_28_cgen_cop2871, struct_object__object_creturn_28_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2830_cgen_cop, object__struct_block_53_cgen_cop2872, object__struct_block_53_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2828_cgen_cop, object__struct_creturn_165_cgen_cop2873, object__struct_creturn_165_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2827_cgen_cop, struct_object__object_cvoid_49_cgen_cop2874, struct_object__object_cvoid_49_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2826_cgen_cop, object__struct_cvoid_78_cgen_cop2875, object__struct_cvoid_78_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2825_cgen_cop, struct_object__object_catom_48_cgen_cop2876, struct_object__object_catom_48_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2824_cgen_cop, object__struct_catom_180_cgen_cop2877, object__struct_catom_180_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(ccast_type_env_154_cgen_cop, _ccast_type2737_234_cgen_cop2878, _ccast_type2737_234_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2823_cgen_cop, struct_object__object_varc_23_cgen_cop2879, struct_object__object_varc_23_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2822_cgen_cop, object__struct_varc_203_cgen_cop2880, object__struct_varc_203_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2821_cgen_cop, struct_object__object_cpragma_169_cgen_cop2881, struct_object__object_cpragma_169_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2819_cgen_cop, struct_object__object_ccast_65_cgen_cop2882, struct_object__object_ccast_65_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2820_cgen_cop, object__struct_cpragma_233_cgen_cop2883, object__struct_cpragma_233_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2818_cgen_cop, object__struct_ccast_238_cgen_cop2884, object__struct_ccast_238_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2817_cgen_cop, struct_object__object_csequence_144_cgen_cop2885, struct_object__object_csequence_144_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2816_cgen_cop, object__struct_csequence_69_cgen_cop2886, object__struct_csequence_69_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2815_cgen_cop, struct_object__object_nop_31_cgen_cop2887, struct_object__object_nop_31_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2814_cgen_cop, object__struct_nop_253_cgen_cop2888, object__struct_nop_253_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2813_cgen_cop, struct_object__object_stop_60_cgen_cop2889, struct_object__object_stop_60_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2812_cgen_cop, object__struct_stop_197_cgen_cop2890, object__struct_stop_197_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2811_cgen_cop, struct_object__object_csetq_16_cgen_cop2891, struct_object__object_csetq_16_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2799_cgen_cop, struct_object__object_cfail_119_cgen_cop2892, struct_object__object_cfail_119_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2809_cgen_cop, struct_object__object_cif_118_cgen_cop2893, struct_object__object_cif_118_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2810_cgen_cop, object__struct_csetq_144_cgen_cop2894, object__struct_csetq_144_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2798_cgen_cop, object__struct_cfail_230_cgen_cop2895, object__struct_cfail_230_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2808_cgen_cop, object__struct_cif_61_cgen_cop2896, object__struct_cif_61_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2797_cgen_cop, struct_object__object_cswitch_246_cgen_cop2897, struct_object__object_cswitch_246_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2807_cgen_cop, struct_object__object_local_var_195_cgen_cop2898, struct_object__object_local_var_195_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2796_cgen_cop, object__struct_cswitch_161_cgen_cop2899, object__struct_cswitch_161_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2806_cgen_cop, object__struct_local_var_3_cgen_cop2900, object__struct_local_var_3_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2795_cgen_cop, struct_object__object_cmake_box_25_cgen_cop2901, struct_object__object_cmake_box_25_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2805_cgen_cop, struct_object__object_cfuncall_72_cgen_cop2902, struct_object__object_cfuncall_72_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2794_cgen_cop, object__struct_cmake_box_32_cgen_cop2903, object__struct_cmake_box_32_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2804_cgen_cop, object__struct_cfuncall_147_cgen_cop2904, object__struct_cfuncall_147_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2793_cgen_cop, struct_object__object_cbox_ref_164_cgen_cop2905, struct_object__object_cbox_ref_164_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2803_cgen_cop, struct_object__object_capply_0_cgen_cop2906, struct_object__object_capply_0_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2792_cgen_cop, object__struct_cbox_ref_102_cgen_cop2907, object__struct_cbox_ref_102_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2802_cgen_cop, object__struct_capply_87_cgen_cop2908, object__struct_capply_87_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2791_cgen_cop, struct_object__object_cbox_set__145_cgen_cop2909, struct_object__object_cbox_set__145_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2801_cgen_cop, struct_object__object_capp_36_cgen_cop2910, struct_object__object_capp_36_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2789_cgen_cop, struct_object__object_cset_ex_it_17_cgen_cop2911, struct_object__object_cset_ex_it_17_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2790_cgen_cop, object__struct_cbox_set__79_cgen_cop2912, object__struct_cbox_set__79_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2800_cgen_cop, object__struct_capp_230_cgen_cop2913, object__struct_capp_230_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2788_cgen_cop, object__struct_cset_ex_it_165_cgen_cop2914, object__struct_cset_ex_it_165_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2787_cgen_cop, struct_object__object_cjump_ex_it_93_cgen_cop2915, struct_object__object_cjump_ex_it_93_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2786_cgen_cop, object__struct_cjump_ex_it_155_cgen_cop2916, object__struct_cjump_ex_it_155_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2785_cgen_cop, struct_object__object_sfun_c_84_cgen_cop2917, struct_object__object_sfun_c_84_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2784_cgen_cop, object__struct_sfun_c_73_cgen_cop2918, object__struct_sfun_c_73_cgen_cop, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2783_cgen_cop, struct_object__object_bdb_block_117_cgen_cop2919, struct_object__object_bdb_block_117_cgen_cop, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2782_cgen_cop, object__struct_bdb_block_145_cgen_cop2920, object__struct_bdb_block_145_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_the_closure_env_181_cgen_cop, _sfun_c_the_closure2643_245_cgen_cop2921, _sfun_c_the_closure2643_245_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cswitch_test_env_236_cgen_cop, _cswitch_test2686_46_cgen_cop2922, _cswitch_test2686_46_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cswitch_loc_env_149_cgen_cop, _cswitch_loc2685_52_cgen_cop2923, _cswitch_loc2685_52_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(capply_fun_env_233_cgen_cop, _capply_fun2702_109_cgen_cop2924, _capply_fun2702_109_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(csequence_cops_env_207_cgen_cop, _csequence_cops2733_166_cgen_cop2925, _csequence_cops2733_166_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_cfail_env_22_cgen_cop, _make_cfail2688_47_cgen_cop2926, _make_cfail2688_47_cgen_cop, 0L, 4);
DEFINE_EXPORT_PROCEDURE(allocate_cmake_box_env_82_cgen_cop, _allocate_cmake_box_154_cgen_cop2927, _allocate_cmake_box_154_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(ccast_loc_set__env_162_cgen_cop, _ccast_loc_set_2735_152_cgen_cop2928, _ccast_loc_set_2735_152_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cset_ex_it_loc_set__env_125_cgen_cop, _cset_ex_it_loc_set_2665_239_cgen_cop2929, _cset_ex_it_loc_set_2665_239_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_cset_ex_it_env_153_cgen_cop, _make_cset_ex_it2664_66_cgen_cop2930, _make_cset_ex_it2664_66_cgen_cop, 0L, 4);
DEFINE_EXPORT_PROCEDURE(make_cbox_set__env_12_cgen_cop, _make_cbox_set_2670_157_cgen_cop2931, _make_cbox_set_2670_157_cgen_cop, 0L, 3);
DEFINE_EXPORT_PROCEDURE(sfun_c_side_effect__env_122_cgen_cop, _sfun_c_side_effect_2635_59_cgen_cop2932, _sfun_c_side_effect_2635_59_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_sfun_c_env_32_cgen_cop, _make_sfun_c2632_73_cgen_cop2933, _make_sfun_c2632_73_cgen_cop, 0L, 14);
DEFINE_EXPORT_PROCEDURE(sfun_c_integrated_set__env_6_cgen_cop, _sfun_c_integrated_set_2657_241_cgen_cop2934, _sfun_c_integrated_set_2657_241_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cjump_ex_it_exit_env_209_cgen_cop, _cjump_ex_it_exit2662_210_cgen_cop2935, _cjump_ex_it_exit2662_210_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(clabel_used__set__env_28_cgen_cop, _clabel_used__set_2771_82_cgen_cop2936, _clabel_used__set_2771_82_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(catom_loc_env_208_cgen_cop, _catom_loc2749_178_cgen_cop2937, _catom_loc2749_178_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cop_loc_set__env_19_cgen_cop, _cop_loc_set_2775_219_cgen_cop2938, _cop_loc_set_2775_219_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(nop_loc_set__env_201_cgen_cop, _nop_loc_set_2728_230_cgen_cop2939, _nop_loc_set_2728_230_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_bdb_block_env_114_cgen_cop, _allocate_bdb_block_200_cgen_cop2940, _allocate_bdb_block_200_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cop_loc_env_198_cgen_cop, _cop_loc2776_142_cgen_cop2941, _cop_loc2776_142_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cmake_box__env_203_cgen_cop, _cmake_box__210_cgen_cop2942, _cmake_box__210_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_class_env_121_cgen_cop, _sfun_c_class2651_178_cgen_cop2943, _sfun_c_class2651_178_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cjump_ex_it_loc_set__env_13_cgen_cop, _cjump_ex_it_loc_set_2660_78_cgen_cop2944, _cjump_ex_it_loc_set_2660_78_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_cop_env_232_cgen_cop, _allocate_cop_129_cgen_cop2945, _allocate_cop_129_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(allocate_catom_env_249_cgen_cop, _allocate_catom_138_cgen_cop2946, _allocate_catom_138_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cif_loc_env_19_cgen_cop, _cif_loc2715_71_cgen_cop2947, _cif_loc2715_71_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_top__env_18_cgen_cop, _sfun_c_top_2641_78_cgen_cop2948, _sfun_c_top_2641_78_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cmake_box_loc_env_223_cgen_cop, _cmake_box_loc2681_4_cgen_cop2949, _cmake_box_loc2681_4_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cop__env_157_cgen_cop, _cop__234_cgen_cop2950, _cop__234_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_the_closure_set__env_182_cgen_cop, _sfun_c_the_closure_set_2642_89_cgen_cop2951, _sfun_c_the_closure_set_2642_89_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_cbox_ref_env_54_cgen_cop, _make_cbox_ref2675_90_cgen_cop2952, _make_cbox_ref2675_90_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_var_vars_env_20_cgen_cop, _local_var_vars2712_20_cgen_cop2953, _local_var_vars2712_20_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(clabel_body_env_16_cgen_cop, _clabel_body2774_177_cgen_cop2954, _clabel_body2774_177_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(nop_loc_env_176_cgen_cop, _nop_loc2729_69_cgen_cop2955, _nop_loc2729_69_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(ccast__env_172_cgen_cop, _ccast__188_cgen_cop2956, _ccast__188_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_csetq_env_7_cgen_cop, _make_csetq2719_239_cgen_cop2957, _make_csetq2719_239_cgen_cop, 0L, 3);
DEFINE_EXPORT_PROCEDURE(clabel_used__env_153_cgen_cop, _clabel_used_2772_222_cgen_cop2958, _clabel_used_2772_222_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_clabel_env_164_cgen_cop, _allocate_clabel_4_cgen_cop2959, _allocate_clabel_4_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(allocate_cjump_ex_it_env_109_cgen_cop, _allocate_cjump_ex_it_10_cgen_cop2960, _allocate_cjump_ex_it_10_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cfail_obj_env_248_cgen_cop, _cfail_obj2693_80_cgen_cop2961, _cfail_obj2693_80_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cpragma__env_210_cgen_cop, _cpragma__0_cgen_cop2962, _cpragma__0_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_cpragma_env_165_cgen_cop, _make_cpragma2739_122_cgen_cop2963, _make_cpragma2739_122_cgen_cop, 0L, 3);
DEFINE_EXPORT_PROCEDURE(allocate_creturn_env_89_cgen_cop, _allocate_creturn_205_cgen_cop2964, _allocate_creturn_205_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_cswitch_env_150_cgen_cop, _make_cswitch2683_182_cgen_cop2965, _make_cswitch2683_182_cgen_cop, 0L, 3);
DEFINE_EXPORT_PROCEDURE(sfun_c_label_env_133_cgen_cop, _sfun_c_label2656_48_cgen_cop2966, _sfun_c_label2656_48_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_loc_env_62_cgen_cop, _sfun_c_loc2655_19_cgen_cop2967, _sfun_c_loc2655_19_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_args_env_244_cgen_cop, _sfun_c_args2647_83_cgen_cop2968, _sfun_c_args2647_83_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_capply_env_184_cgen_cop, _allocate_capply_222_cgen_cop2969, _allocate_capply_222_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cjump_ex_it__env_62_cgen_cop, _cjump_ex_it__240_cgen_cop2970, _cjump_ex_it__240_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cset_ex_it_env_179_cgen_cop, _allocate_cset_ex_it_129_cgen_cop2971, _allocate_cset_ex_it_129_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_ccast_env_52_cgen_cop, _make_ccast2734_32_cgen_cop2972, _make_ccast2734_32_cgen_cop, 0L, 3);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(cswitch__env_163_cgen_cop, _cswitch__47_cgen_cop2973, _cswitch__47_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfail_loc_env_127_cgen_cop, _cfail_loc2690_159_cgen_cop2974, _cfail_loc2690_159_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(capply_arg_env_86_cgen_cop, _capply_arg2703_187_cgen_cop2975, _capply_arg2703_187_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cbox_ref_loc_env_226_cgen_cop, _cbox_ref_loc2677_114_cgen_cop2976, _cbox_ref_loc2677_114_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(nop__env_76_cgen_cop, _nop__15_cgen_cop2977, _nop__15_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cgoto_env_81_cgen_cop, _allocate_cgoto_159_cgen_cop2978, _allocate_cgoto_159_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(bdb_block_loc_env_177_cgen_cop, _bdb_block_loc2629_39_cgen_cop2979, _bdb_block_loc2629_39_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfuncall_fun_env_227_cgen_cop, _cfuncall_fun2707_141_cgen_cop2980, _cfuncall_fun2707_141_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_integrated_env_192_cgen_cop, _sfun_c_integrated2658_215_cgen_cop2981, _sfun_c_integrated2658_215_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_cmake_box_env_234_cgen_cop, _make_cmake_box2679_81_cgen_cop2982, _make_cmake_box2679_81_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfuncall_loc_set__env_23_cgen_cop, _cfuncall_loc_set_2705_205_cgen_cop2983, _cfuncall_loc_set_2705_205_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(clabel_body_set__env_237_cgen_cop, _clabel_body_set_2773_235_cgen_cop2984, _clabel_body_set_2773_235_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(catom_loc_set__env_94_cgen_cop, _catom_loc_set_2748_111_cgen_cop2985, _catom_loc_set_2748_111_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cgoto_label_env_180_cgen_cop, _cgoto_label2766_60_cgen_cop2986, _cgoto_label2766_60_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(varc_variable_env_211_cgen_cop, _varc_variable2747_221_cgen_cop2987, _varc_variable2747_221_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(clabel_name_env_119_cgen_cop, _clabel_name2770_181_cgen_cop2988, _clabel_name2770_181_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cset_ex_it_body_env_38_cgen_cop, _cset_ex_it_body2669_156_cgen_cop2989, _cset_ex_it_body2669_156_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_stop_env_110_cgen_cop, _allocate_stop_67_cgen_cop2990, _allocate_stop_67_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_cif_env_221_cgen_cop, _make_cif2713_209_cgen_cop2991, _make_cif2713_209_cgen_cop, 0L, 4);
DEFINE_EXPORT_PROCEDURE(capp_args_env_82_cgen_cop, _capp_args2698_252_cgen_cop2992, _capp_args2698_252_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cif_true_env_81_cgen_cop, _cif_true2717_251_cgen_cop2993, _cif_true2717_251_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_var__env_140_cgen_cop, _local_var__240_cgen_cop2994, _local_var__240_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cmake_box_loc_set__env_166_cgen_cop, _cmake_box_loc_set_2680_187_cgen_cop2995, _cmake_box_loc_set_2680_187_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_bdb_block_env_239_cgen_cop, _make_bdb_block2627_154_cgen_cop2996, _make_bdb_block2627_154_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cswitch_clauses_env_210_cgen_cop, _cswitch_clauses2687_232_cgen_cop2997, _cswitch_clauses2687_232_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(varc_loc_set__env_59_cgen_cop, _varc_loc_set_2745_98_cgen_cop2998, _varc_loc_set_2745_98_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(stop__env_195_cgen_cop, _stop__237_cgen_cop2999, _stop__237_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_args_set__env_202_cgen_cop, _sfun_c_args_set_2646_77_cgen_cop3000, _sfun_c_args_set_2646_77_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_stop_env_242_cgen_cop, _make_stop2724_181_cgen_cop3001, _make_stop2724_181_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(ccast_loc_env_243_cgen_cop, _ccast_loc2736_52_cgen_cop3002, _ccast_loc2736_52_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(catom__env_165_cgen_cop, _catom__202_cgen_cop3003, _catom__202_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cbox_ref_env_46_cgen_cop, _allocate_cbox_ref_237_cgen_cop3004, _allocate_cbox_ref_237_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cbox_set__loc_set__env_184_cgen_cop, _cbox_set__loc_set_2671_185_cgen_cop3005, _cbox_set__loc_set_2671_185_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_c_predicate_of_env_14_cgen_cop, _sfun_c_predicate_of2637_187_cgen_cop3006, _sfun_c_predicate_of2637_187_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfuncall_args_env_213_cgen_cop, _cfuncall_args2708_4_cgen_cop3007, _cfuncall_args2708_4_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cset_ex_it_exit_env_120_cgen_cop, _cset_ex_it_exit2667_56_cgen_cop3008, _cset_ex_it_exit2667_56_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cbox_set__loc_env_217_cgen_cop, _cbox_set__loc2672_191_cgen_cop3009, _cbox_set__loc2672_191_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_catom_env_203_cgen_cop, _make_catom_20_cgen_cop3010, _make_catom_20_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cgoto_loc_env_198_cgen_cop, _cgoto_loc2765_49_cgen_cop3011, _cgoto_loc2765_49_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_clabel_env_27_cgen_cop, _make_clabel2767_36_cgen_cop3012, _make_clabel2767_36_cgen_cop, 0L, 4);
DEFINE_EXPORT_PROCEDURE(capply__env_88_cgen_cop, _capply__134_cgen_cop3013, _capply__134_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c__env_13_cgen_cop, _sfun_c__160_cgen_cop3014, _sfun_c__160_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_body_env_67_cgen_cop, _sfun_c_body2649_249_cgen_cop3015, _sfun_c_body2649_249_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_top__set__env_99_cgen_cop, _sfun_c_top__set_2640_57_cgen_cop3016, _sfun_c_top__set_2640_57_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(csetq_loc_set__env_17_cgen_cop, _csetq_loc_set_2720_84_cgen_cop3017, _csetq_loc_set_2720_84_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_capply_env_25_cgen_cop, _make_capply2699_147_cgen_cop3018, _make_capply2699_147_cgen_cop, 0L, 3);
DEFINE_EXPORT_PROCEDURE(cfail_msg_env_37_cgen_cop, _cfail_msg2692_109_cgen_cop3019, _cfail_msg2692_109_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_var_loc_env_27_cgen_cop, _local_var_loc2711_133_cgen_cop3020, _local_var_loc2711_133_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cvoid_value_env_114_cgen_cop, _cvoid_value2754_28_cgen_cop3021, _cvoid_value2754_28_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cbox_set___env_145_cgen_cop, _cbox_set___248_cgen_cop3022, _cbox_set___248_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(capp__env_157_cgen_cop, _capp__47_cgen_cop3023, _capp__47_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cpragma_env_198_cgen_cop, _allocate_cpragma_102_cgen_cop3024, _allocate_cpragma_102_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(allocate_cswitch_env_29_cgen_cop, _allocate_cswitch_108_cgen_cop3025, _allocate_cswitch_108_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cmake_box_value_env_18_cgen_cop, _cmake_box_value2682_176_cgen_cop3026, _cmake_box_value2682_176_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_side_effect__set__env_200_cgen_cop, _sfun_c_side_effect__set_2634_236_cgen_cop3027, _sfun_c_side_effect__set_2634_236_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_cgoto_env_29_cgen_cop, _make_cgoto2763_123_cgen_cop3028, _make_cgoto2763_123_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(capp_loc_set__env_19_cgen_cop, _capp_loc_set_2695_133_cgen_cop3029, _capp_loc_set_2695_133_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(bdb_block__env_27_cgen_cop, _bdb_block__112_cgen_cop3030, _bdb_block__112_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(csequence__env_55_cgen_cop, _csequence__120_cgen_cop3031, _csequence__120_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cset_ex_it_jump_value_env_80_cgen_cop, _cset_ex_it_jump_value2668_122_cgen_cop3032, _cset_ex_it_jump_value2668_122_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_property_env_54_cgen_cop, _sfun_c_property2645_193_cgen_cop3033, _sfun_c_property2645_193_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(creturn_loc_set__env_6_cgen_cop, _creturn_loc_set_2756_44_cgen_cop3034, _creturn_loc_set_2756_44_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_capp_env_45_cgen_cop, _allocate_capp_243_cgen_cop3035, _allocate_capp_243_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(csetq__env_53_cgen_cop, _csetq__142_cgen_cop3036, _csetq__142_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(csequence_c_exp__env_43_cgen_cop, _csequence_c_exp_2732_23_cgen_cop3037, _csequence_c_exp_2732_23_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(stop_value_env_221_cgen_cop, _stop_value2727_118_cgen_cop3038, _stop_value2727_118_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(capply_loc_set__env_93_cgen_cop, _capply_loc_set_2700_55_cgen_cop3039, _capply_loc_set_2700_55_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(block_body_env_123_cgen_cop, _block_body2762_237_cgen_cop3040, _block_body2762_237_cgen_cop, 0L, 1);
DEFINE_STRING(string2838_cgen_cop, string2838_cgen_cop3041, "BDB-BLOCK SFUN/C CJUMP-EX-IT CSET-EX-IT CBOX-SET! CBOX-REF CMAKE-BOX CSWITCH CFAIL CAPP CAPPLY CFUNCALL LOCAL-VAR CIF CSETQ STOP NOP CSEQUENCE CCAST CPRAGMA VARC CATOM CVOID CRETURN BLOCK CGOTO CLABEL COP ", 205);
DEFINE_EXPORT_PROCEDURE(make_capp_env_139_cgen_cop, _make_capp2694_163_cgen_cop3042, _make_capp2694_163_cgen_cop, 0L, 3);
DEFINE_EXPORT_PROCEDURE(capp_loc_env_198_cgen_cop, _capp_loc2696_15_cgen_cop3043, _capp_loc2696_15_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(block_loc_set__env_131_cgen_cop, _block_loc_set_2760_160_cgen_cop3044, _block_loc_set_2760_160_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(block_loc_env_95_cgen_cop, _block_loc2761_12_cgen_cop3045, _block_loc2761_12_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_nop_env_149_cgen_cop, _make_nop_127_cgen_cop3046, _make_nop_127_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cbox_ref_var_env_191_cgen_cop, _cbox_ref_var2678_157_cgen_cop3047, _cbox_ref_var2678_157_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfail__env_212_cgen_cop, _cfail__212_cgen_cop3048, _cfail__212_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(stop_loc_set__env_230_cgen_cop, _stop_loc_set_2725_24_cgen_cop3049, _stop_loc_set_2725_24_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(clabel_loc_set__env_13_cgen_cop, _clabel_loc_set_2768_200_cgen_cop3050, _clabel_loc_set_2768_200_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cpragma_loc_env_158_cgen_cop, _cpragma_loc2741_49_cgen_cop3051, _cpragma_loc2741_49_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_block_env_49_cgen_cop, _allocate_block_150_cgen_cop3052, _allocate_block_150_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cjump_ex_it_value_env_29_cgen_cop, _cjump_ex_it_value2663_237_cgen_cop3053, _cjump_ex_it_value2663_237_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cvoid_loc_set__env_55_cgen_cop, _cvoid_loc_set_2752_198_cgen_cop3054, _cvoid_loc_set_2752_198_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_c_stack_allocator_env_70_cgen_cop, _sfun_c_stack_allocator2639_86_cgen_cop3055, _sfun_c_stack_allocator2639_86_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(csetq_loc_env_214_cgen_cop, _csetq_loc2721_49_cgen_cop3056, _csetq_loc2721_49_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cif_env_237_cgen_cop, _allocate_cif_80_cgen_cop3057, _allocate_cif_80_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cvoid__env_2_cgen_cop, _cvoid__92_cgen_cop3058, _cvoid__92_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cgoto__env_157_cgen_cop, _cgoto__255_cgen_cop3059, _cgoto__255_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cvoid_loc_env_245_cgen_cop, _cvoid_loc2753_0_cgen_cop3060, _cvoid_loc2753_0_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfuncall_strength_env_205_cgen_cop, _cfuncall_strength2709_48_cgen_cop3061, _cfuncall_strength2709_48_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_dsssl_keywords_env_158_cgen_cop, _sfun_c_dsssl_keywords2653_22_cgen_cop3062, _sfun_c_dsssl_keywords2653_22_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_csequence_env_198_cgen_cop, _allocate_csequence_87_cgen_cop3063, _allocate_csequence_87_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(varc_loc_env_7_cgen_cop, _varc_loc2746_80_cgen_cop3064, _varc_loc2746_80_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(capply_loc_env_162_cgen_cop, _capply_loc2701_113_cgen_cop3065, _capply_loc2701_113_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_cfuncall_env_253_cgen_cop, _make_cfuncall2704_63_cgen_cop3066, _make_cfuncall2704_63_cgen_cop, 0L, 4);
DEFINE_EXPORT_PROCEDURE(cbox_set__var_env_36_cgen_cop, _cbox_set__var2673_154_cgen_cop3067, _cbox_set__var2673_154_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cvoid_env_139_cgen_cop, _allocate_cvoid_169_cgen_cop3068, _allocate_cvoid_169_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sfun_c_arity_env_32_cgen_cop, _sfun_c_arity2633_20_cgen_cop3069, _sfun_c_arity2633_20_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cpragma_format_env_237_cgen_cop, _cpragma_format2742_234_cgen_cop3070, _cpragma_format2742_234_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cpragma_args_env_172_cgen_cop, _cpragma_args2743_86_cgen_cop3071, _cpragma_args2743_86_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cif_loc_set__env_78_cgen_cop, _cif_loc_set_2714_174_cgen_cop3072, _cif_loc_set_2714_174_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(bdb_block_body_env_211_cgen_cop, _bdb_block_body2630_50_cgen_cop3073, _bdb_block_body2630_50_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_stack_allocator_set__env_101_cgen_cop, _sfun_c_stack_allocator_set_2638_247_cgen_cop3074, _sfun_c_stack_allocator_set_2638_247_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_local_var_env_12_cgen_cop, _allocate_local_var_109_cgen_cop3075, _allocate_local_var_109_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(varc__env_66_cgen_cop, _varc__28_cgen_cop3076, _varc__28_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(clabel_loc_env_74_cgen_cop, _clabel_loc2769_184_cgen_cop3077, _clabel_loc2769_184_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_c_class_set__env_98_cgen_cop, _sfun_c_class_set_2650_224_cgen_cop3078, _sfun_c_class_set_2650_224_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_cjump_ex_it_env_213_cgen_cop, _make_cjump_ex_it2659_119_cgen_cop3079, _make_cjump_ex_it2659_119_cgen_cop, 0L, 3);
DEFINE_EXPORT_PROCEDURE(cif__env_78_cgen_cop, _cif__54_cgen_cop3080, _cif__54_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfuncall__env_126_cgen_cop, _cfuncall__70_cgen_cop3081, _cfuncall__70_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_cop_env_79_cgen_cop, _make_cop_194_cgen_cop3082, _make_cop_194_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1002_sfun_c_env_97_cgen_cop, _widening1002_sfun_c2631_56_cgen_cop3083, _widening1002_sfun_c2631_56_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfail_loc_set__env_106_cgen_cop, _cfail_loc_set_2689_94_cgen_cop3084, _cfail_loc_set_2689_94_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cset_ex_it__env_46_cgen_cop, _cset_ex_it__255_cgen_cop3085, _cset_ex_it__255_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(creturn_loc_env_192_cgen_cop, _creturn_loc2757_219_cgen_cop3086, _creturn_loc2757_219_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(block__env_106_cgen_cop, _block__12_cgen_cop3087, _block__12_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cfail_env_151_cgen_cop, _allocate_cfail_114_cgen_cop3088, _allocate_cfail_114_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(stop_loc_env_84_cgen_cop, _stop_loc2726_93_cgen_cop3089, _stop_loc2726_93_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cif_test_env_106_cgen_cop, _cif_test2716_234_cgen_cop3090, _cif_test2716_234_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(csequence_loc_set__env_199_cgen_cop, _csequence_loc_set_2730_187_cgen_cop3091, _csequence_loc_set_2730_187_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_c_property_set__env_159_cgen_cop, _sfun_c_property_set_2644_124_cgen_cop3092, _sfun_c_property_set_2644_124_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cgoto_loc_set__env_19_cgen_cop, _cgoto_loc_set_2764_203_cgen_cop3093, _cgoto_loc_set_2764_203_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cbox_ref__env_23_cgen_cop, _cbox_ref__77_cgen_cop3094, _cbox_ref__77_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cpragma_loc_set__env_58_cgen_cop, _cpragma_loc_set_2740_10_cgen_cop3095, _cpragma_loc_set_2740_10_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_c_dsssl_keywords_set__env_58_cgen_cop, _sfun_c_dsssl_keywords_set_2652_202_cgen_cop3096, _sfun_c_dsssl_keywords_set_2652_202_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cjump_ex_it_loc_env_74_cgen_cop, _cjump_ex_it_loc2661_83_cgen_cop3097, _cjump_ex_it_loc2661_83_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_block_env_108_cgen_cop, _make_block2759_147_cgen_cop3098, _make_block2759_147_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_csequence_env_60_cgen_cop, _make_csequence_138_cgen_cop3099, _make_csequence_138_cgen_cop, 0L, 3);
DEFINE_EXPORT_PROCEDURE(cif_false_env_205_cgen_cop, _cif_false2718_168_cgen_cop3100, _cif_false2718_168_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cbox_ref_loc_set__env_169_cgen_cop, _cbox_ref_loc_set_2676_199_cgen_cop3101, _cbox_ref_loc_set_2676_199_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_cbox_set__env_34_cgen_cop, _allocate_cbox_set__70_cgen_cop3102, _allocate_cbox_set__70_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cset_ex_it_loc_env_9_cgen_cop, _cset_ex_it_loc2666_211_cgen_cop3103, _cset_ex_it_loc2666_211_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(ccast_arg_env_145_cgen_cop, _ccast_arg2738_227_cgen_cop3104, _ccast_arg2738_227_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_sfun_c_env_52_cgen_cop, _allocate_sfun_c_103_cgen_cop3105, _allocate_sfun_c_103_cgen_cop, 0L, 0);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(allocate_cfuncall_env_121_cgen_cop, _allocate_cfuncall_49_cgen_cop3106, _allocate_cfuncall_49_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cfuncall_loc_env_80_cgen_cop, _cfuncall_loc2706_72_cgen_cop3107, _cfuncall_loc2706_72_cgen_cop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_varc_env_92_cgen_cop, _allocate_varc_172_cgen_cop3108, _allocate_varc_172_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(allocate_nop_env_73_cgen_cop, _allocate_nop_142_cgen_cop3109, _allocate_nop_142_cgen_cop, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sfun_c_loc_set__env_229_cgen_cop, _sfun_c_loc_set_2654_112_cgen_cop3110, _sfun_c_loc_set_2654_112_cgen_cop, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_csetq_env_232_cgen_cop, _allocate_csetq_62_cgen_cop3111, _allocate_csetq_62_cgen_cop, 0L, 0);


/* module-initialization */ obj_t 
module_initialization_70_cgen_cop(long checksum_4005, char *from_4006)
{
   if (CBOOL(require_initialization_114_cgen_cop))
     {
	require_initialization_114_cgen_cop = BBOOL(((bool_t) 0));
	library_modules_init_112_cgen_cop();
	cnst_init_137_cgen_cop();
	imported_modules_init_94_cgen_cop();
	object_init_111_cgen_cop();
	method_init_76_cgen_cop();
	toplevel_init_63_cgen_cop();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cgen_cop()
{
   module_initialization_70___object(((long) 0), "CGEN_COP");
   module_initialization_70___reader(((long) 0), "CGEN_COP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cgen_cop()
{
   {
      obj_t cnst_port_138_3997;
      cnst_port_138_3997 = open_input_string(string2838_cgen_cop);
      {
	 long i_3998;
	 i_3998 = ((long) 27);
       loop_3999:
	 {
	    bool_t test2839_4000;
	    test2839_4000 = (i_3998 == ((long) -1));
	    if (test2839_4000)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2840_4001;
		    {
		       obj_t list2841_4002;
		       {
			  obj_t arg2842_4003;
			  arg2842_4003 = BNIL;
			  list2841_4002 = MAKE_PAIR(cnst_port_138_3997, arg2842_4003);
		       }
		       arg2840_4001 = read___reader(list2841_4002);
		    }
		    CNST_TABLE_SET(i_3998, arg2840_4001);
		 }
		 {
		    int aux_4004;
		    {
		       long aux_4024;
		       aux_4024 = (i_3998 - ((long) 1));
		       aux_4004 = (int) (aux_4024);
		    }
		    {
		       long i_4027;
		       i_4027 = (long) (aux_4004);
		       i_3998 = i_4027;
		       goto loop_3999;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cgen_cop()
{
   return BUNSPEC;
}


/* object-init */ obj_t 
object_init_111_cgen_cop()
{
   {
      obj_t arg2041_1059;
      arg2041_1059 = object___object;
      cop_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 0)), arg2041_1059, allocate_cop_env_232_cgen_cop, ((long) 11407), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2045_1063;
      arg2045_1063 = cop_cgen_cop;
      clabel_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg2045_1063, allocate_clabel_env_164_cgen_cop, ((long) 11059), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2049_1067;
      arg2049_1067 = cop_cgen_cop;
      cgoto_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 2)), arg2049_1067, allocate_cgoto_env_81_cgen_cop, ((long) 48811), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2053_1071;
      arg2053_1071 = cop_cgen_cop;
      block_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 3)), arg2053_1071, allocate_block_env_49_cgen_cop, ((long) 52831), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2057_1075;
      arg2057_1075 = cop_cgen_cop;
      creturn_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 4)), arg2057_1075, allocate_creturn_env_89_cgen_cop, ((long) 15248), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2061_1079;
      arg2061_1079 = cop_cgen_cop;
      cvoid_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 5)), arg2061_1079, allocate_cvoid_env_139_cgen_cop, ((long) 55726), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2065_1083;
      arg2065_1083 = cop_cgen_cop;
      catom_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 6)), arg2065_1083, allocate_catom_env_249_cgen_cop, ((long) 64409), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2070_1087;
      arg2070_1087 = cop_cgen_cop;
      varc_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 7)), arg2070_1087, allocate_varc_env_92_cgen_cop, ((long) 19036), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2074_1091;
      arg2074_1091 = cop_cgen_cop;
      cpragma_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 8)), arg2074_1091, allocate_cpragma_env_198_cgen_cop, ((long) 21000), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2078_1095;
      arg2078_1095 = cop_cgen_cop;
      ccast_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 9)), arg2078_1095, allocate_ccast_env_158_cgen_cop, ((long) 25742), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2082_1099;
      arg2082_1099 = cop_cgen_cop;
      csequence_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 10)), arg2082_1099, allocate_csequence_env_198_cgen_cop, ((long) 22005), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2086_1103;
      arg2086_1103 = cop_cgen_cop;
      nop_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 11)), arg2086_1103, allocate_nop_env_73_cgen_cop, ((long) 7109), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2090_1107;
      arg2090_1107 = cop_cgen_cop;
      stop_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 12)), arg2090_1107, allocate_stop_env_110_cgen_cop, ((long) 5749), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2094_1111;
      arg2094_1111 = cop_cgen_cop;
      csetq_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 13)), arg2094_1111, allocate_csetq_env_232_cgen_cop, ((long) 40138), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2098_1115;
      arg2098_1115 = cop_cgen_cop;
      cif_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 14)), arg2098_1115, allocate_cif_env_237_cgen_cop, ((long) 22507), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2102_1119;
      arg2102_1119 = cop_cgen_cop;
      local_var_164_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 15)), arg2102_1119, allocate_local_var_env_12_cgen_cop, ((long) 37069), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2107_1123;
      arg2107_1123 = cop_cgen_cop;
      cfuncall_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 16)), arg2107_1123, allocate_cfuncall_env_121_cgen_cop, ((long) 43811), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2112_1127;
      arg2112_1127 = cop_cgen_cop;
      capply_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 17)), arg2112_1127, allocate_capply_env_184_cgen_cop, ((long) 27774), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2116_1131;
      arg2116_1131 = cop_cgen_cop;
      capp_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 18)), arg2116_1131, allocate_capp_env_45_cgen_cop, ((long) 56870), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2122_1135;
      arg2122_1135 = cop_cgen_cop;
      cfail_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 19)), arg2122_1135, allocate_cfail_env_151_cgen_cop, ((long) 63849), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2127_1139;
      arg2127_1139 = cop_cgen_cop;
      cswitch_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 20)), arg2127_1139, allocate_cswitch_env_29_cgen_cop, ((long) 21483), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2133_1143;
      arg2133_1143 = cop_cgen_cop;
      cmake_box_177_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 21)), arg2133_1143, allocate_cmake_box_env_82_cgen_cop, ((long) 14804), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2137_1147;
      arg2137_1147 = cop_cgen_cop;
      cbox_ref_44_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 22)), arg2137_1147, allocate_cbox_ref_env_46_cgen_cop, ((long) 40945), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2141_1151;
      arg2141_1151 = cop_cgen_cop;
      cbox_set__132_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 23)), arg2141_1151, allocate_cbox_set__env_34_cgen_cop, ((long) 34730), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2146_1155;
      arg2146_1155 = cop_cgen_cop;
      cset_ex_it_123_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 24)), arg2146_1155, allocate_cset_ex_it_env_179_cgen_cop, ((long) 65203), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2150_1159;
      arg2150_1159 = cop_cgen_cop;
      cjump_ex_it_131_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 25)), arg2150_1159, allocate_cjump_ex_it_env_109_cgen_cop, ((long) 14432), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2154_1163;
      arg2154_1163 = sfun_ast_var;
      sfun_c_188_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 26)), arg2154_1163, allocate_sfun_c_env_52_cgen_cop, ((long) 52518), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2158_1167;
      arg2158_1167 = cop_cgen_cop;
      bdb_block_21_cgen_cop = add_class__117___object(CNST_TABLE_REF(((long) 27)), arg2158_1167, allocate_bdb_block_env_114_cgen_cop, ((long) 56220), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-bdb-block */ bdb_block_21_t 
allocate_bdb_block_152_cgen_cop()
{
   {
      bdb_block_21_t new1971_1170;
      new1971_1170 = ((bdb_block_21_t) BREF(GC_MALLOC(sizeof(struct bdb_block_21))));
      {
	 long arg2161_1171;
	 arg2161_1171 = class_num_218___object(bdb_block_21_cgen_cop);
	 {
	    obj_t obj_2329;
	    obj_2329 = (obj_t) (new1971_1170);
	    (((obj_t) CREF(obj_2329))->header = MAKE_HEADER(arg2161_1171, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4089;
	 aux_4089 = (object_t) (new1971_1170);
	 OBJECT_WIDENING_SET(aux_4089, BFALSE);
      }
      return new1971_1170;
   }
}


/* _allocate-bdb-block */ obj_t 
_allocate_bdb_block_200_cgen_cop(obj_t env_3330)
{
   {
      bdb_block_21_t aux_4092;
      aux_4092 = allocate_bdb_block_152_cgen_cop();
      return (obj_t) (aux_4092);
   }
}


/* bdb-block? */ bool_t 
bdb_block__15_cgen_cop(obj_t obj_4)
{
   return is_a__118___object(obj_4, bdb_block_21_cgen_cop);
}


/* _bdb-block? */ obj_t 
_bdb_block__112_cgen_cop(obj_t env_3331, obj_t obj_3332)
{
   {
      bool_t aux_4096;
      aux_4096 = bdb_block__15_cgen_cop(obj_3332);
      return BBOOL(aux_4096);
   }
}


/* make-bdb-block */ bdb_block_21_t 
make_bdb_block_176_cgen_cop(obj_t loc_5, cop_t body_6)
{
   {
      bdb_block_21_t new1966_2331;
      new1966_2331 = ((bdb_block_21_t) BREF(GC_MALLOC(sizeof(struct bdb_block_21))));
      {
	 long arg2162_2332;
	 arg2162_2332 = class_num_218___object(bdb_block_21_cgen_cop);
	 {
	    obj_t obj_2335;
	    obj_2335 = (obj_t) (new1966_2331);
	    (((obj_t) CREF(obj_2335))->header = MAKE_HEADER(arg2162_2332, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4103;
	 aux_4103 = (object_t) (new1966_2331);
	 OBJECT_WIDENING_SET(aux_4103, BFALSE);
      }
      ((((bdb_block_21_t) CREF(new1966_2331))->loc) = ((obj_t) loc_5), BUNSPEC);
      ((((bdb_block_21_t) CREF(new1966_2331))->body) = ((cop_t) body_6), BUNSPEC);
      return new1966_2331;
   }
}


/* _make-bdb-block2627 */ obj_t 
_make_bdb_block2627_154_cgen_cop(obj_t env_3333, obj_t loc_3334, obj_t body_3335)
{
   {
      bdb_block_21_t aux_4108;
      aux_4108 = make_bdb_block_176_cgen_cop(loc_3334, (cop_t) (body_3335));
      return (obj_t) (aux_4108);
   }
}


/* bdb-block-loc-set! */ obj_t 
bdb_block_loc_set__89_cgen_cop(bdb_block_21_t obj_7, obj_t val1970_8)
{
   return ((((bdb_block_21_t) CREF(obj_7))->loc) = ((obj_t) val1970_8), BUNSPEC);
}


/* _bdb-block-loc-set!2628 */ obj_t 
_bdb_block_loc_set_2628_168_cgen_cop(obj_t env_3336, obj_t obj_3337, obj_t val1970_3338)
{
   return bdb_block_loc_set__89_cgen_cop((bdb_block_21_t) (obj_3337), val1970_3338);
}


/* bdb-block-loc */ obj_t 
bdb_block_loc_147_cgen_cop(bdb_block_21_t obj_9)
{
   return (((bdb_block_21_t) CREF(obj_9))->loc);
}


/* _bdb-block-loc2629 */ obj_t 
_bdb_block_loc2629_39_cgen_cop(obj_t env_3339, obj_t obj_3340)
{
   return bdb_block_loc_147_cgen_cop((bdb_block_21_t) (obj_3340));
}


/* bdb-block-body */ cop_t 
bdb_block_body_146_cgen_cop(bdb_block_21_t obj_10)
{
   return (((bdb_block_21_t) CREF(obj_10))->body);
}


/* _bdb-block-body2630 */ obj_t 
_bdb_block_body2630_50_cgen_cop(obj_t env_3341, obj_t obj_3342)
{
   {
      cop_t aux_4119;
      aux_4119 = bdb_block_body_146_cgen_cop((bdb_block_21_t) (obj_3342));
      return (obj_t) (aux_4119);
   }
}


/* allocate-sfun/c */ sfun_t 
allocate_sfun_c_74_cgen_cop()
{
   {
      sfun_t new1959_1176;
      new1959_1176 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
      {
	 long arg2163_1177;
	 arg2163_1177 = class_num_218___object(sfun_c_188_cgen_cop);
	 {
	    obj_t obj_2337;
	    obj_2337 = (obj_t) (new1959_1176);
	    (((obj_t) CREF(obj_2337))->header = MAKE_HEADER(arg2163_1177, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4127;
	 aux_4127 = (object_t) (new1959_1176);
	 OBJECT_WIDENING_SET(aux_4127, BFALSE);
      }
      return new1959_1176;
   }
}


/* _allocate-sfun/c */ obj_t 
_allocate_sfun_c_103_cgen_cop(obj_t env_3329)
{
   {
      sfun_t aux_4130;
      aux_4130 = allocate_sfun_c_74_cgen_cop();
      return (obj_t) (aux_4130);
   }
}


/* sfun/c? */ bool_t 
sfun_c__72_cgen_cop(obj_t obj_14)
{
   return is_a__118___object(obj_14, sfun_c_188_cgen_cop);
}


/* _sfun/c? */ obj_t 
_sfun_c__160_cgen_cop(obj_t env_3343, obj_t obj_3344)
{
   {
      bool_t aux_4134;
      aux_4134 = sfun_c__72_cgen_cop(obj_3344);
      return BBOOL(aux_4134);
   }
}


/* widening1002-sfun/c */ sfun_c_188_t 
widening1002_sfun_c_222_cgen_cop(clabel_t label_15, bool_t integrated_16)
{
   {
      sfun_c_188_t new1941_2339;
      new1941_2339 = ((sfun_c_188_t) BREF(GC_MALLOC(sizeof(struct sfun_c_188))));
      ((((sfun_c_188_t) CREF(new1941_2339))->label) = ((clabel_t) label_15), BUNSPEC);
      ((((sfun_c_188_t) CREF(new1941_2339))->integrated) = ((bool_t) integrated_16), BUNSPEC);
      return new1941_2339;
   }
}


/* _widening1002-sfun/c2631 */ obj_t 
_widening1002_sfun_c2631_56_cgen_cop(obj_t env_3345, obj_t label_3346, obj_t integrated_3347)
{
   {
      sfun_c_188_t aux_4140;
      aux_4140 = widening1002_sfun_c_222_cgen_cop((clabel_t) (label_3346), CBOOL(integrated_3347));
      return (obj_t) (aux_4140);
   }
}


/* make-sfun/c */ sfun_c_188_t 
make_sfun_c_65_cgen_cop(long arity_17, obj_t side_effect__165_18, obj_t predicate_of_78_19, obj_t stack_allocator_172_20, bool_t top__138_21, obj_t the_closure_238_22, obj_t property_23, obj_t args_24, obj_t body_25, obj_t class_26, obj_t dsssl_keywords_243_27, obj_t loc_28, clabel_t label_29, bool_t integrated_30)
{
   {
      sfun_t aux1945_2342;
      {
	 sfun_t res2624_2374;
	 {
	    sfun_t new1115_2358;
	    new1115_2358 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
	    {
	       long arg2291_2359;
	       arg2291_2359 = class_num_218___object(sfun_ast_var);
	       {
		  obj_t obj_2372;
		  obj_2372 = (obj_t) (new1115_2358);
		  (((obj_t) CREF(obj_2372))->header = MAKE_HEADER(arg2291_2359, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_4149;
	       aux_4149 = (object_t) (new1115_2358);
	       OBJECT_WIDENING_SET(aux_4149, BFALSE);
	    }
	    ((((sfun_t) CREF(new1115_2358))->arity) = ((long) arity_17), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->side_effect__165) = ((obj_t) side_effect__165_18), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->predicate_of_78) = ((obj_t) predicate_of_78_19), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->stack_allocator_172) = ((obj_t) stack_allocator_172_20), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->top__138) = ((bool_t) top__138_21), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->the_closure_238) = ((obj_t) the_closure_238_22), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->property) = ((obj_t) property_23), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->args) = ((obj_t) args_24), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->body) = ((obj_t) body_25), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->class) = ((obj_t) class_26), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->dsssl_keywords_243) = ((obj_t) dsssl_keywords_243_27), BUNSPEC);
	    ((((sfun_t) CREF(new1115_2358))->loc) = ((obj_t) loc_28), BUNSPEC);
	    res2624_2374 = new1115_2358;
	 }
	 aux1945_2342 = res2624_2374;
      }
      {
	 sfun_c_188_t new1946_2343;
	 new1946_2343 = ((sfun_c_188_t) (aux1945_2342));
	 {
	    long arg2164_2344;
	    arg2164_2344 = class_num_218___object(sfun_c_188_cgen_cop);
	    {
	       obj_t obj_2375;
	       obj_2375 = (obj_t) (new1946_2343);
	       (((obj_t) CREF(obj_2375))->header = MAKE_HEADER(arg2164_2344, 0), BUNSPEC);
	    }
	 }
	 {
	    sfun_c_188_t arg2165_2345;
	    {
	       sfun_c_188_t res2625_2382;
	       {
		  sfun_c_188_t new1941_2379;
		  new1941_2379 = ((sfun_c_188_t) BREF(GC_MALLOC(sizeof(struct sfun_c_188))));
		  ((((sfun_c_188_t) CREF(new1941_2379))->label) = ((clabel_t) label_29), BUNSPEC);
		  ((((sfun_c_188_t) CREF(new1941_2379))->integrated) = ((bool_t) integrated_30), BUNSPEC);
		  res2625_2382 = new1941_2379;
	       }
	       arg2165_2345 = res2625_2382;
	    }
	    {
	       obj_t aux_4173;
	       object_t aux_4171;
	       aux_4173 = (obj_t) (arg2165_2345);
	       aux_4171 = (object_t) (new1946_2343);
	       OBJECT_WIDENING_SET(aux_4171, aux_4173);
	    }
	 }
	 return new1946_2343;
      }
   }
}


/* _make-sfun/c2632 */ obj_t 
_make_sfun_c2632_73_cgen_cop(obj_t env_3348, obj_t arity_3349, obj_t side_effect__165_3350, obj_t predicate_of_78_3351, obj_t stack_allocator_172_3352, obj_t top__138_3353, obj_t the_closure_238_3354, obj_t property_3355, obj_t args_3356, obj_t body_3357, obj_t class_3358, obj_t dsssl_keywords_243_3359, obj_t loc_3360, obj_t label_3361, obj_t integrated_3362)
{
   {
      sfun_c_188_t aux_4176;
      aux_4176 = make_sfun_c_65_cgen_cop((long) CINT(arity_3349), side_effect__165_3350, predicate_of_78_3351, stack_allocator_172_3352, CBOOL(top__138_3353), the_closure_238_3354, property_3355, args_3356, body_3357, class_3358, dsssl_keywords_243_3359, loc_3360, (clabel_t) (label_3361), CBOOL(integrated_3362));
      return (obj_t) (aux_4176);
   }
}


/* sfun/c-arity */ long 
sfun_c_arity_65_cgen_cop(sfun_t obj_31)
{
   return (((sfun_t) CREF(obj_31))->arity);
}


/* _sfun/c-arity2633 */ obj_t 
_sfun_c_arity2633_20_cgen_cop(obj_t env_3363, obj_t obj_3364)
{
   {
      long aux_4184;
      aux_4184 = sfun_c_arity_65_cgen_cop((sfun_t) (obj_3364));
      return BINT(aux_4184);
   }
}


/* sfun/c-side-effect?-set! */ obj_t 
sfun_c_side_effect__set__242_cgen_cop(sfun_t obj_32, obj_t val1947_33)
{
   return ((((sfun_t) CREF(obj_32))->side_effect__165) = ((obj_t) val1947_33), BUNSPEC);
}


/* _sfun/c-side-effect?-set!2634 */ obj_t 
_sfun_c_side_effect__set_2634_236_cgen_cop(obj_t env_3365, obj_t obj_3366, obj_t val1947_3367)
{
   return sfun_c_side_effect__set__242_cgen_cop((sfun_t) (obj_3366), val1947_3367);
}


/* sfun/c-side-effect? */ obj_t 
sfun_c_side_effect__183_cgen_cop(sfun_t obj_34)
{
   return (((sfun_t) CREF(obj_34))->side_effect__165);
}


/* _sfun/c-side-effect?2635 */ obj_t 
_sfun_c_side_effect_2635_59_cgen_cop(obj_t env_3368, obj_t obj_3369)
{
   return sfun_c_side_effect__183_cgen_cop((sfun_t) (obj_3369));
}


/* sfun/c-predicate-of-set! */ obj_t 
sfun_c_predicate_of_set__140_cgen_cop(sfun_t obj_35, obj_t val1948_36)
{
   return ((((sfun_t) CREF(obj_35))->predicate_of_78) = ((obj_t) val1948_36), BUNSPEC);
}


/* _sfun/c-predicate-of-set!2636 */ obj_t 
_sfun_c_predicate_of_set_2636_153_cgen_cop(obj_t env_3370, obj_t obj_3371, obj_t val1948_3372)
{
   return sfun_c_predicate_of_set__140_cgen_cop((sfun_t) (obj_3371), val1948_3372);
}


/* sfun/c-predicate-of */ obj_t 
sfun_c_predicate_of_188_cgen_cop(sfun_t obj_37)
{
   return (((sfun_t) CREF(obj_37))->predicate_of_78);
}


/* _sfun/c-predicate-of2637 */ obj_t 
_sfun_c_predicate_of2637_187_cgen_cop(obj_t env_3373, obj_t obj_3374)
{
   return sfun_c_predicate_of_188_cgen_cop((sfun_t) (obj_3374));
}


/* sfun/c-stack-allocator-set! */ obj_t 
sfun_c_stack_allocator_set__151_cgen_cop(sfun_t obj_38, obj_t val1949_39)
{
   return ((((sfun_t) CREF(obj_38))->stack_allocator_172) = ((obj_t) val1949_39), BUNSPEC);
}


/* _sfun/c-stack-allocator-set!2638 */ obj_t 
_sfun_c_stack_allocator_set_2638_247_cgen_cop(obj_t env_3375, obj_t obj_3376, obj_t val1949_3377)
{
   return sfun_c_stack_allocator_set__151_cgen_cop((sfun_t) (obj_3376), val1949_3377);
}


/* sfun/c-stack-allocator */ obj_t 
sfun_c_stack_allocator_34_cgen_cop(sfun_t obj_40)
{
   return (((sfun_t) CREF(obj_40))->stack_allocator_172);
}


/* _sfun/c-stack-allocator2639 */ obj_t 
_sfun_c_stack_allocator2639_86_cgen_cop(obj_t env_3378, obj_t obj_3379)
{
   return sfun_c_stack_allocator_34_cgen_cop((sfun_t) (obj_3379));
}


/* sfun/c-top?-set! */ obj_t 
sfun_c_top__set__31_cgen_cop(sfun_t obj_41, bool_t val1950_42)
{
   return ((((sfun_t) CREF(obj_41))->top__138) = ((bool_t) val1950_42), BUNSPEC);
}


/* _sfun/c-top?-set!2640 */ obj_t 
_sfun_c_top__set_2640_57_cgen_cop(obj_t env_3380, obj_t obj_3381, obj_t val1950_3382)
{
   return sfun_c_top__set__31_cgen_cop((sfun_t) (obj_3381), CBOOL(val1950_3382));
}


/* sfun/c-top? */ bool_t 
sfun_c_top__135_cgen_cop(sfun_t obj_43)
{
   return (((sfun_t) CREF(obj_43))->top__138);
}


/* _sfun/c-top?2641 */ obj_t 
_sfun_c_top_2641_78_cgen_cop(obj_t env_3383, obj_t obj_3384)
{
   {
      bool_t aux_4211;
      aux_4211 = sfun_c_top__135_cgen_cop((sfun_t) (obj_3384));
      return BBOOL(aux_4211);
   }
}


/* sfun/c-the-closure-set! */ obj_t 
sfun_c_the_closure_set__169_cgen_cop(sfun_t obj_44, obj_t val1951_45)
{
   return ((((sfun_t) CREF(obj_44))->the_closure_238) = ((obj_t) val1951_45), BUNSPEC);
}


/* _sfun/c-the-closure-set!2642 */ obj_t 
_sfun_c_the_closure_set_2642_89_cgen_cop(obj_t env_3385, obj_t obj_3386, obj_t val1951_3387)
{
   return sfun_c_the_closure_set__169_cgen_cop((sfun_t) (obj_3386), val1951_3387);
}


/* sfun/c-the-closure */ obj_t 
sfun_c_the_closure_51_cgen_cop(sfun_t obj_46)
{
   return (((sfun_t) CREF(obj_46))->the_closure_238);
}


/* _sfun/c-the-closure2643 */ obj_t 
_sfun_c_the_closure2643_245_cgen_cop(obj_t env_3388, obj_t obj_3389)
{
   return sfun_c_the_closure_51_cgen_cop((sfun_t) (obj_3389));
}


/* sfun/c-property-set! */ obj_t 
sfun_c_property_set__116_cgen_cop(sfun_t obj_47, obj_t val1952_48)
{
   return ((((sfun_t) CREF(obj_47))->property) = ((obj_t) val1952_48), BUNSPEC);
}


/* _sfun/c-property-set!2644 */ obj_t 
_sfun_c_property_set_2644_124_cgen_cop(obj_t env_3390, obj_t obj_3391, obj_t val1952_3392)
{
   return sfun_c_property_set__116_cgen_cop((sfun_t) (obj_3391), val1952_3392);
}


/* sfun/c-property */ obj_t 
sfun_c_property_208_cgen_cop(sfun_t obj_49)
{
   return (((sfun_t) CREF(obj_49))->property);
}


/* _sfun/c-property2645 */ obj_t 
_sfun_c_property2645_193_cgen_cop(obj_t env_3393, obj_t obj_3394)
{
   return sfun_c_property_208_cgen_cop((sfun_t) (obj_3394));
}


/* sfun/c-args-set! */ obj_t 
sfun_c_args_set__112_cgen_cop(sfun_t obj_50, obj_t val1953_51)
{
   return ((((sfun_t) CREF(obj_50))->args) = ((obj_t) val1953_51), BUNSPEC);
}


/* _sfun/c-args-set!2646 */ obj_t 
_sfun_c_args_set_2646_77_cgen_cop(obj_t env_3395, obj_t obj_3396, obj_t val1953_3397)
{
   return sfun_c_args_set__112_cgen_cop((sfun_t) (obj_3396), val1953_3397);
}


/* sfun/c-args */ obj_t 
sfun_c_args_197_cgen_cop(sfun_t obj_52)
{
   return (((sfun_t) CREF(obj_52))->args);
}


/* _sfun/c-args2647 */ obj_t 
_sfun_c_args2647_83_cgen_cop(obj_t env_3398, obj_t obj_3399)
{
   return sfun_c_args_197_cgen_cop((sfun_t) (obj_3399));
}


/* sfun/c-body-set! */ obj_t 
sfun_c_body_set__172_cgen_cop(sfun_t obj_53, obj_t val1954_54)
{
   return ((((sfun_t) CREF(obj_53))->body) = ((obj_t) val1954_54), BUNSPEC);
}


/* _sfun/c-body-set!2648 */ obj_t 
_sfun_c_body_set_2648_173_cgen_cop(obj_t env_3400, obj_t obj_3401, obj_t val1954_3402)
{
   return sfun_c_body_set__172_cgen_cop((sfun_t) (obj_3401), val1954_3402);
}


/* sfun/c-body */ obj_t 
sfun_c_body_138_cgen_cop(sfun_t obj_55)
{
   return (((sfun_t) CREF(obj_55))->body);
}


/* _sfun/c-body2649 */ obj_t 
_sfun_c_body2649_249_cgen_cop(obj_t env_3403, obj_t obj_3404)
{
   return sfun_c_body_138_cgen_cop((sfun_t) (obj_3404));
}


/* sfun/c-class-set! */ obj_t 
sfun_c_class_set__22_cgen_cop(sfun_t obj_56, obj_t val1955_57)
{
   return ((((sfun_t) CREF(obj_56))->class) = ((obj_t) val1955_57), BUNSPEC);
}


/* _sfun/c-class-set!2650 */ obj_t 
_sfun_c_class_set_2650_224_cgen_cop(obj_t env_3405, obj_t obj_3406, obj_t val1955_3407)
{
   return sfun_c_class_set__22_cgen_cop((sfun_t) (obj_3406), val1955_3407);
}


/* sfun/c-class */ obj_t 
sfun_c_class_37_cgen_cop(sfun_t obj_58)
{
   return (((sfun_t) CREF(obj_58))->class);
}


/* _sfun/c-class2651 */ obj_t 
_sfun_c_class2651_178_cgen_cop(obj_t env_3408, obj_t obj_3409)
{
   return sfun_c_class_37_cgen_cop((sfun_t) (obj_3409));
}


/* sfun/c-dsssl-keywords-set! */ obj_t 
sfun_c_dsssl_keywords_set__154_cgen_cop(sfun_t obj_59, obj_t val1956_60)
{
   return ((((sfun_t) CREF(obj_59))->dsssl_keywords_243) = ((obj_t) val1956_60), BUNSPEC);
}


/* _sfun/c-dsssl-keywords-set!2652 */ obj_t 
_sfun_c_dsssl_keywords_set_2652_202_cgen_cop(obj_t env_3410, obj_t obj_3411, obj_t val1956_3412)
{
   return sfun_c_dsssl_keywords_set__154_cgen_cop((sfun_t) (obj_3411), val1956_3412);
}


/* sfun/c-dsssl-keywords */ obj_t 
sfun_c_dsssl_keywords_96_cgen_cop(sfun_t obj_61)
{
   return (((sfun_t) CREF(obj_61))->dsssl_keywords_243);
}


/* _sfun/c-dsssl-keywords2653 */ obj_t 
_sfun_c_dsssl_keywords2653_22_cgen_cop(obj_t env_3413, obj_t obj_3414)
{
   return sfun_c_dsssl_keywords_96_cgen_cop((sfun_t) (obj_3414));
}


/* sfun/c-loc-set! */ obj_t 
sfun_c_loc_set__123_cgen_cop(sfun_t obj_62, obj_t val1957_63)
{
   return ((((sfun_t) CREF(obj_62))->loc) = ((obj_t) val1957_63), BUNSPEC);
}


/* _sfun/c-loc-set!2654 */ obj_t 
_sfun_c_loc_set_2654_112_cgen_cop(obj_t env_3415, obj_t obj_3416, obj_t val1957_3417)
{
   return sfun_c_loc_set__123_cgen_cop((sfun_t) (obj_3416), val1957_3417);
}


/* sfun/c-loc */ obj_t 
sfun_c_loc_247_cgen_cop(sfun_t obj_64)
{
   return (((sfun_t) CREF(obj_64))->loc);
}


/* _sfun/c-loc2655 */ obj_t 
_sfun_c_loc2655_19_cgen_cop(obj_t env_3418, obj_t obj_3419)
{
   return sfun_c_loc_247_cgen_cop((sfun_t) (obj_3419));
}


/* sfun/c-label */ clabel_t 
sfun_c_label_89_cgen_cop(sfun_c_188_t obj_65)
{
   {
      obj_t aux_4257;
      {
	 object_t aux_4258;
	 aux_4258 = (object_t) (obj_65);
	 aux_4257 = OBJECT_WIDENING(aux_4258);
      }
      return (((sfun_c_188_t) CREF(aux_4257))->label);
   }
}


/* _sfun/c-label2656 */ obj_t 
_sfun_c_label2656_48_cgen_cop(obj_t env_3420, obj_t obj_3421)
{
   {
      clabel_t aux_4262;
      aux_4262 = sfun_c_label_89_cgen_cop((sfun_c_188_t) (obj_3421));
      return (obj_t) (aux_4262);
   }
}


/* sfun/c-integrated-set! */ obj_t 
sfun_c_integrated_set__24_cgen_cop(sfun_c_188_t obj_66, bool_t val1958_67)
{
   {
      obj_t aux_4266;
      {
	 object_t aux_4267;
	 aux_4267 = (object_t) (obj_66);
	 aux_4266 = OBJECT_WIDENING(aux_4267);
      }
      return ((((sfun_c_188_t) CREF(aux_4266))->integrated) = ((bool_t) val1958_67), BUNSPEC);
   }
}


/* _sfun/c-integrated-set!2657 */ obj_t 
_sfun_c_integrated_set_2657_241_cgen_cop(obj_t env_3422, obj_t obj_3423, obj_t val1958_3424)
{
   return sfun_c_integrated_set__24_cgen_cop((sfun_c_188_t) (obj_3423), CBOOL(val1958_3424));
}


/* sfun/c-integrated */ bool_t 
sfun_c_integrated_120_cgen_cop(sfun_c_188_t obj_68)
{
   {
      obj_t aux_4274;
      {
	 object_t aux_4275;
	 aux_4275 = (object_t) (obj_68);
	 aux_4274 = OBJECT_WIDENING(aux_4275);
      }
      return (((sfun_c_188_t) CREF(aux_4274))->integrated);
   }
}


/* _sfun/c-integrated2658 */ obj_t 
_sfun_c_integrated2658_215_cgen_cop(obj_t env_3425, obj_t obj_3426)
{
   {
      bool_t aux_4279;
      aux_4279 = sfun_c_integrated_120_cgen_cop((sfun_c_188_t) (obj_3426));
      return BBOOL(aux_4279);
   }
}


/* allocate-cjump-ex-it */ cjump_ex_it_131_t 
allocate_cjump_ex_it_67_cgen_cop()
{
   {
      cjump_ex_it_131_t new1926_1185;
      new1926_1185 = ((cjump_ex_it_131_t) BREF(GC_MALLOC(sizeof(struct cjump_ex_it_131))));
      {
	 long arg2166_1186;
	 arg2166_1186 = class_num_218___object(cjump_ex_it_131_cgen_cop);
	 {
	    obj_t obj_2383;
	    obj_2383 = (obj_t) (new1926_1185);
	    (((obj_t) CREF(obj_2383))->header = MAKE_HEADER(arg2166_1186, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4287;
	 aux_4287 = (object_t) (new1926_1185);
	 OBJECT_WIDENING_SET(aux_4287, BFALSE);
      }
      return new1926_1185;
   }
}


/* _allocate-cjump-ex-it */ obj_t 
_allocate_cjump_ex_it_10_cgen_cop(obj_t env_3328)
{
   {
      cjump_ex_it_131_t aux_4290;
      aux_4290 = allocate_cjump_ex_it_67_cgen_cop();
      return (obj_t) (aux_4290);
   }
}


/* cjump-ex-it? */ bool_t 
cjump_ex_it__247_cgen_cop(obj_t obj_72)
{
   return is_a__118___object(obj_72, cjump_ex_it_131_cgen_cop);
}


/* _cjump-ex-it? */ obj_t 
_cjump_ex_it__240_cgen_cop(obj_t env_3427, obj_t obj_3428)
{
   {
      bool_t aux_4294;
      aux_4294 = cjump_ex_it__247_cgen_cop(obj_3428);
      return BBOOL(aux_4294);
   }
}


/* make-cjump-ex-it */ cjump_ex_it_131_t 
make_cjump_ex_it_216_cgen_cop(obj_t loc_73, cop_t exit_74, cop_t value_75)
{
   {
      cjump_ex_it_131_t new1920_2385;
      new1920_2385 = ((cjump_ex_it_131_t) BREF(GC_MALLOC(sizeof(struct cjump_ex_it_131))));
      {
	 long arg2167_2386;
	 arg2167_2386 = class_num_218___object(cjump_ex_it_131_cgen_cop);
	 {
	    obj_t obj_2390;
	    obj_2390 = (obj_t) (new1920_2385);
	    (((obj_t) CREF(obj_2390))->header = MAKE_HEADER(arg2167_2386, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4301;
	 aux_4301 = (object_t) (new1920_2385);
	 OBJECT_WIDENING_SET(aux_4301, BFALSE);
      }
      ((((cjump_ex_it_131_t) CREF(new1920_2385))->loc) = ((obj_t) loc_73), BUNSPEC);
      ((((cjump_ex_it_131_t) CREF(new1920_2385))->exit) = ((cop_t) exit_74), BUNSPEC);
      ((((cjump_ex_it_131_t) CREF(new1920_2385))->value) = ((cop_t) value_75), BUNSPEC);
      return new1920_2385;
   }
}


/* _make-cjump-ex-it2659 */ obj_t 
_make_cjump_ex_it2659_119_cgen_cop(obj_t env_3429, obj_t loc_3430, obj_t exit_3431, obj_t value_3432)
{
   {
      cjump_ex_it_131_t aux_4307;
      aux_4307 = make_cjump_ex_it_216_cgen_cop(loc_3430, (cop_t) (exit_3431), (cop_t) (value_3432));
      return (obj_t) (aux_4307);
   }
}


/* cjump-ex-it-loc-set! */ obj_t 
cjump_ex_it_loc_set__72_cgen_cop(cjump_ex_it_131_t obj_76, obj_t val1925_77)
{
   return ((((cjump_ex_it_131_t) CREF(obj_76))->loc) = ((obj_t) val1925_77), BUNSPEC);
}


/* _cjump-ex-it-loc-set!2660 */ obj_t 
_cjump_ex_it_loc_set_2660_78_cgen_cop(obj_t env_3433, obj_t obj_3434, obj_t val1925_3435)
{
   return cjump_ex_it_loc_set__72_cgen_cop((cjump_ex_it_131_t) (obj_3434), val1925_3435);
}


/* cjump-ex-it-loc */ obj_t 
cjump_ex_it_loc_12_cgen_cop(cjump_ex_it_131_t obj_78)
{
   return (((cjump_ex_it_131_t) CREF(obj_78))->loc);
}


/* _cjump-ex-it-loc2661 */ obj_t 
_cjump_ex_it_loc2661_83_cgen_cop(obj_t env_3436, obj_t obj_3437)
{
   return cjump_ex_it_loc_12_cgen_cop((cjump_ex_it_131_t) (obj_3437));
}


/* cjump-ex-it-exit */ cop_t 
cjump_ex_it_exit_93_cgen_cop(cjump_ex_it_131_t obj_79)
{
   return (((cjump_ex_it_131_t) CREF(obj_79))->exit);
}


/* _cjump-ex-it-exit2662 */ obj_t 
_cjump_ex_it_exit2662_210_cgen_cop(obj_t env_3438, obj_t obj_3439)
{
   {
      cop_t aux_4319;
      aux_4319 = cjump_ex_it_exit_93_cgen_cop((cjump_ex_it_131_t) (obj_3439));
      return (obj_t) (aux_4319);
   }
}


/* cjump-ex-it-value */ cop_t 
cjump_ex_it_value_92_cgen_cop(cjump_ex_it_131_t obj_80)
{
   return (((cjump_ex_it_131_t) CREF(obj_80))->value);
}


/* _cjump-ex-it-value2663 */ obj_t 
_cjump_ex_it_value2663_237_cgen_cop(obj_t env_3440, obj_t obj_3441)
{
   {
      cop_t aux_4324;
      aux_4324 = cjump_ex_it_value_92_cgen_cop((cjump_ex_it_131_t) (obj_3441));
      return (obj_t) (aux_4324);
   }
}


/* allocate-cset-ex-it */ cset_ex_it_123_t 
allocate_cset_ex_it_68_cgen_cop()
{
   {
      cset_ex_it_123_t new1901_1192;
      new1901_1192 = ((cset_ex_it_123_t) BREF(GC_MALLOC(sizeof(struct cset_ex_it_123))));
      {
	 long arg2169_1193;
	 arg2169_1193 = class_num_218___object(cset_ex_it_123_cgen_cop);
	 {
	    obj_t obj_2392;
	    obj_2392 = (obj_t) (new1901_1192);
	    (((obj_t) CREF(obj_2392))->header = MAKE_HEADER(arg2169_1193, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4332;
	 aux_4332 = (object_t) (new1901_1192);
	 OBJECT_WIDENING_SET(aux_4332, BFALSE);
      }
      return new1901_1192;
   }
}


/* _allocate-cset-ex-it */ obj_t 
_allocate_cset_ex_it_129_cgen_cop(obj_t env_3327)
{
   {
      cset_ex_it_123_t aux_4335;
      aux_4335 = allocate_cset_ex_it_68_cgen_cop();
      return (obj_t) (aux_4335);
   }
}


/* cset-ex-it? */ bool_t 
cset_ex_it__60_cgen_cop(obj_t obj_84)
{
   return is_a__118___object(obj_84, cset_ex_it_123_cgen_cop);
}


/* _cset-ex-it? */ obj_t 
_cset_ex_it__255_cgen_cop(obj_t env_3442, obj_t obj_3443)
{
   {
      bool_t aux_4339;
      aux_4339 = cset_ex_it__60_cgen_cop(obj_3443);
      return BBOOL(aux_4339);
   }
}


/* make-cset-ex-it */ cset_ex_it_123_t 
make_cset_ex_it_102_cgen_cop(obj_t loc_85, cop_t exit_86, cop_t jump_value_221_87, cop_t body_88)
{
   {
      cset_ex_it_123_t new1894_2394;
      new1894_2394 = ((cset_ex_it_123_t) BREF(GC_MALLOC(sizeof(struct cset_ex_it_123))));
      {
	 long arg2170_2395;
	 arg2170_2395 = class_num_218___object(cset_ex_it_123_cgen_cop);
	 {
	    obj_t obj_2400;
	    obj_2400 = (obj_t) (new1894_2394);
	    (((obj_t) CREF(obj_2400))->header = MAKE_HEADER(arg2170_2395, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4346;
	 aux_4346 = (object_t) (new1894_2394);
	 OBJECT_WIDENING_SET(aux_4346, BFALSE);
      }
      ((((cset_ex_it_123_t) CREF(new1894_2394))->loc) = ((obj_t) loc_85), BUNSPEC);
      ((((cset_ex_it_123_t) CREF(new1894_2394))->exit) = ((cop_t) exit_86), BUNSPEC);
      ((((cset_ex_it_123_t) CREF(new1894_2394))->jump_value_221) = ((cop_t) jump_value_221_87), BUNSPEC);
      ((((cset_ex_it_123_t) CREF(new1894_2394))->body) = ((cop_t) body_88), BUNSPEC);
      return new1894_2394;
   }
}


/* _make-cset-ex-it2664 */ obj_t 
_make_cset_ex_it2664_66_cgen_cop(obj_t env_3444, obj_t loc_3445, obj_t exit_3446, obj_t jump_value_221_3447, obj_t body_3448)
{
   {
      cset_ex_it_123_t aux_4353;
      aux_4353 = make_cset_ex_it_102_cgen_cop(loc_3445, (cop_t) (exit_3446), (cop_t) (jump_value_221_3447), (cop_t) (body_3448));
      return (obj_t) (aux_4353);
   }
}


/* cset-ex-it-loc-set! */ obj_t 
cset_ex_it_loc_set__45_cgen_cop(cset_ex_it_123_t obj_89, obj_t val1900_90)
{
   return ((((cset_ex_it_123_t) CREF(obj_89))->loc) = ((obj_t) val1900_90), BUNSPEC);
}


/* _cset-ex-it-loc-set!2665 */ obj_t 
_cset_ex_it_loc_set_2665_239_cgen_cop(obj_t env_3449, obj_t obj_3450, obj_t val1900_3451)
{
   return cset_ex_it_loc_set__45_cgen_cop((cset_ex_it_123_t) (obj_3450), val1900_3451);
}


/* cset-ex-it-loc */ obj_t 
cset_ex_it_loc_150_cgen_cop(cset_ex_it_123_t obj_91)
{
   return (((cset_ex_it_123_t) CREF(obj_91))->loc);
}


/* _cset-ex-it-loc2666 */ obj_t 
_cset_ex_it_loc2666_211_cgen_cop(obj_t env_3452, obj_t obj_3453)
{
   return cset_ex_it_loc_150_cgen_cop((cset_ex_it_123_t) (obj_3453));
}


/* cset-ex-it-exit */ cop_t 
cset_ex_it_exit_130_cgen_cop(cset_ex_it_123_t obj_92)
{
   return (((cset_ex_it_123_t) CREF(obj_92))->exit);
}


/* _cset-ex-it-exit2667 */ obj_t 
_cset_ex_it_exit2667_56_cgen_cop(obj_t env_3454, obj_t obj_3455)
{
   {
      cop_t aux_4366;
      aux_4366 = cset_ex_it_exit_130_cgen_cop((cset_ex_it_123_t) (obj_3455));
      return (obj_t) (aux_4366);
   }
}


/* cset-ex-it-jump-value */ cop_t 
cset_ex_it_jump_value_128_cgen_cop(cset_ex_it_123_t obj_93)
{
   return (((cset_ex_it_123_t) CREF(obj_93))->jump_value_221);
}


/* _cset-ex-it-jump-value2668 */ obj_t 
_cset_ex_it_jump_value2668_122_cgen_cop(obj_t env_3456, obj_t obj_3457)
{
   {
      cop_t aux_4371;
      aux_4371 = cset_ex_it_jump_value_128_cgen_cop((cset_ex_it_123_t) (obj_3457));
      return (obj_t) (aux_4371);
   }
}


/* cset-ex-it-body */ cop_t 
cset_ex_it_body_210_cgen_cop(cset_ex_it_123_t obj_94)
{
   return (((cset_ex_it_123_t) CREF(obj_94))->body);
}


/* _cset-ex-it-body2669 */ obj_t 
_cset_ex_it_body2669_156_cgen_cop(obj_t env_3458, obj_t obj_3459)
{
   {
      cop_t aux_4376;
      aux_4376 = cset_ex_it_body_210_cgen_cop((cset_ex_it_123_t) (obj_3459));
      return (obj_t) (aux_4376);
   }
}


/* allocate-cbox-set! */ cbox_set__132_t 
allocate_cbox_set__13_cgen_cop()
{
   {
      cbox_set__132_t new1879_1200;
      new1879_1200 = ((cbox_set__132_t) BREF(GC_MALLOC(sizeof(struct cbox_set__132))));
      {
	 long arg2172_1201;
	 arg2172_1201 = class_num_218___object(cbox_set__132_cgen_cop);
	 {
	    obj_t obj_2402;
	    obj_2402 = (obj_t) (new1879_1200);
	    (((obj_t) CREF(obj_2402))->header = MAKE_HEADER(arg2172_1201, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4384;
	 aux_4384 = (object_t) (new1879_1200);
	 OBJECT_WIDENING_SET(aux_4384, BFALSE);
      }
      return new1879_1200;
   }
}


/* _allocate-cbox-set! */ obj_t 
_allocate_cbox_set__70_cgen_cop(obj_t env_3326)
{
   {
      cbox_set__132_t aux_4387;
      aux_4387 = allocate_cbox_set__13_cgen_cop();
      return (obj_t) (aux_4387);
   }
}


/* cbox-set!? */ bool_t 
cbox_set___212_cgen_cop(obj_t obj_98)
{
   return is_a__118___object(obj_98, cbox_set__132_cgen_cop);
}


/* _cbox-set!? */ obj_t 
_cbox_set___248_cgen_cop(obj_t env_3460, obj_t obj_3461)
{
   {
      bool_t aux_4391;
      aux_4391 = cbox_set___212_cgen_cop(obj_3461);
      return BBOOL(aux_4391);
   }
}


/* make-cbox-set! */ cbox_set__132_t 
make_cbox_set__218_cgen_cop(obj_t loc_99, cop_t var_100, cop_t value_101)
{
   {
      cbox_set__132_t new1873_2404;
      new1873_2404 = ((cbox_set__132_t) BREF(GC_MALLOC(sizeof(struct cbox_set__132))));
      {
	 long arg2173_2405;
	 arg2173_2405 = class_num_218___object(cbox_set__132_cgen_cop);
	 {
	    obj_t obj_2409;
	    obj_2409 = (obj_t) (new1873_2404);
	    (((obj_t) CREF(obj_2409))->header = MAKE_HEADER(arg2173_2405, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4398;
	 aux_4398 = (object_t) (new1873_2404);
	 OBJECT_WIDENING_SET(aux_4398, BFALSE);
      }
      ((((cbox_set__132_t) CREF(new1873_2404))->loc) = ((obj_t) loc_99), BUNSPEC);
      ((((cbox_set__132_t) CREF(new1873_2404))->var) = ((cop_t) var_100), BUNSPEC);
      ((((cbox_set__132_t) CREF(new1873_2404))->value) = ((cop_t) value_101), BUNSPEC);
      return new1873_2404;
   }
}


/* _make-cbox-set!2670 */ obj_t 
_make_cbox_set_2670_157_cgen_cop(obj_t env_3462, obj_t loc_3463, obj_t var_3464, obj_t value_3465)
{
   {
      cbox_set__132_t aux_4404;
      aux_4404 = make_cbox_set__218_cgen_cop(loc_3463, (cop_t) (var_3464), (cop_t) (value_3465));
      return (obj_t) (aux_4404);
   }
}


/* cbox-set!-loc-set! */ obj_t 
cbox_set__loc_set__99_cgen_cop(cbox_set__132_t obj_102, obj_t val1878_103)
{
   return ((((cbox_set__132_t) CREF(obj_102))->loc) = ((obj_t) val1878_103), BUNSPEC);
}


/* _cbox-set!-loc-set!2671 */ obj_t 
_cbox_set__loc_set_2671_185_cgen_cop(obj_t env_3466, obj_t obj_3467, obj_t val1878_3468)
{
   return cbox_set__loc_set__99_cgen_cop((cbox_set__132_t) (obj_3467), val1878_3468);
}


/* cbox-set!-loc */ obj_t 
cbox_set__loc_125_cgen_cop(cbox_set__132_t obj_104)
{
   return (((cbox_set__132_t) CREF(obj_104))->loc);
}


/* _cbox-set!-loc2672 */ obj_t 
_cbox_set__loc2672_191_cgen_cop(obj_t env_3469, obj_t obj_3470)
{
   return cbox_set__loc_125_cgen_cop((cbox_set__132_t) (obj_3470));
}


/* cbox-set!-var */ cop_t 
cbox_set__var_213_cgen_cop(cbox_set__132_t obj_105)
{
   return (((cbox_set__132_t) CREF(obj_105))->var);
}


/* _cbox-set!-var2673 */ obj_t 
_cbox_set__var2673_154_cgen_cop(obj_t env_3471, obj_t obj_3472)
{
   {
      cop_t aux_4416;
      aux_4416 = cbox_set__var_213_cgen_cop((cbox_set__132_t) (obj_3472));
      return (obj_t) (aux_4416);
   }
}


/* cbox-set!-value */ cop_t 
cbox_set__value_106_cgen_cop(cbox_set__132_t obj_106)
{
   return (((cbox_set__132_t) CREF(obj_106))->value);
}


/* _cbox-set!-value2674 */ obj_t 
_cbox_set__value2674_113_cgen_cop(obj_t env_3473, obj_t obj_3474)
{
   {
      cop_t aux_4421;
      aux_4421 = cbox_set__value_106_cgen_cop((cbox_set__132_t) (obj_3474));
      return (obj_t) (aux_4421);
   }
}


/* allocate-cbox-ref */ cbox_ref_44_t 
allocate_cbox_ref_60_cgen_cop()
{
   {
      cbox_ref_44_t new1862_1207;
      new1862_1207 = ((cbox_ref_44_t) BREF(GC_MALLOC(sizeof(struct cbox_ref_44))));
      {
	 long arg2174_1208;
	 arg2174_1208 = class_num_218___object(cbox_ref_44_cgen_cop);
	 {
	    obj_t obj_2411;
	    obj_2411 = (obj_t) (new1862_1207);
	    (((obj_t) CREF(obj_2411))->header = MAKE_HEADER(arg2174_1208, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4429;
	 aux_4429 = (object_t) (new1862_1207);
	 OBJECT_WIDENING_SET(aux_4429, BFALSE);
      }
      return new1862_1207;
   }
}


/* _allocate-cbox-ref */ obj_t 
_allocate_cbox_ref_237_cgen_cop(obj_t env_3325)
{
   {
      cbox_ref_44_t aux_4432;
      aux_4432 = allocate_cbox_ref_60_cgen_cop();
      return (obj_t) (aux_4432);
   }
}


/* cbox-ref? */ bool_t 
cbox_ref__107_cgen_cop(obj_t obj_110)
{
   return is_a__118___object(obj_110, cbox_ref_44_cgen_cop);
}


/* _cbox-ref? */ obj_t 
_cbox_ref__77_cgen_cop(obj_t env_3475, obj_t obj_3476)
{
   {
      bool_t aux_4436;
      aux_4436 = cbox_ref__107_cgen_cop(obj_3476);
      return BBOOL(aux_4436);
   }
}


/* make-cbox-ref */ cbox_ref_44_t 
make_cbox_ref_208_cgen_cop(obj_t loc_111, cop_t var_112)
{
   {
      cbox_ref_44_t new1857_2413;
      new1857_2413 = ((cbox_ref_44_t) BREF(GC_MALLOC(sizeof(struct cbox_ref_44))));
      {
	 long arg2175_2414;
	 arg2175_2414 = class_num_218___object(cbox_ref_44_cgen_cop);
	 {
	    obj_t obj_2417;
	    obj_2417 = (obj_t) (new1857_2413);
	    (((obj_t) CREF(obj_2417))->header = MAKE_HEADER(arg2175_2414, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4443;
	 aux_4443 = (object_t) (new1857_2413);
	 OBJECT_WIDENING_SET(aux_4443, BFALSE);
      }
      ((((cbox_ref_44_t) CREF(new1857_2413))->loc) = ((obj_t) loc_111), BUNSPEC);
      ((((cbox_ref_44_t) CREF(new1857_2413))->var) = ((cop_t) var_112), BUNSPEC);
      return new1857_2413;
   }
}


/* _make-cbox-ref2675 */ obj_t 
_make_cbox_ref2675_90_cgen_cop(obj_t env_3477, obj_t loc_3478, obj_t var_3479)
{
   {
      cbox_ref_44_t aux_4448;
      aux_4448 = make_cbox_ref_208_cgen_cop(loc_3478, (cop_t) (var_3479));
      return (obj_t) (aux_4448);
   }
}


/* cbox-ref-loc-set! */ obj_t 
cbox_ref_loc_set__77_cgen_cop(cbox_ref_44_t obj_113, obj_t val1861_114)
{
   return ((((cbox_ref_44_t) CREF(obj_113))->loc) = ((obj_t) val1861_114), BUNSPEC);
}


/* _cbox-ref-loc-set!2676 */ obj_t 
_cbox_ref_loc_set_2676_199_cgen_cop(obj_t env_3480, obj_t obj_3481, obj_t val1861_3482)
{
   return cbox_ref_loc_set__77_cgen_cop((cbox_ref_44_t) (obj_3481), val1861_3482);
}


/* cbox-ref-loc */ obj_t 
cbox_ref_loc_81_cgen_cop(cbox_ref_44_t obj_115)
{
   return (((cbox_ref_44_t) CREF(obj_115))->loc);
}


/* _cbox-ref-loc2677 */ obj_t 
_cbox_ref_loc2677_114_cgen_cop(obj_t env_3483, obj_t obj_3484)
{
   return cbox_ref_loc_81_cgen_cop((cbox_ref_44_t) (obj_3484));
}


/* cbox-ref-var */ cop_t 
cbox_ref_var_149_cgen_cop(cbox_ref_44_t obj_116)
{
   return (((cbox_ref_44_t) CREF(obj_116))->var);
}


/* _cbox-ref-var2678 */ obj_t 
_cbox_ref_var2678_157_cgen_cop(obj_t env_3485, obj_t obj_3486)
{
   {
      cop_t aux_4459;
      aux_4459 = cbox_ref_var_149_cgen_cop((cbox_ref_44_t) (obj_3486));
      return (obj_t) (aux_4459);
   }
}


/* allocate-cmake-box */ cmake_box_177_t 
allocate_cmake_box_148_cgen_cop()
{
   {
      cmake_box_177_t new1846_1213;
      new1846_1213 = ((cmake_box_177_t) BREF(GC_MALLOC(sizeof(struct cmake_box_177))));
      {
	 long arg2176_1214;
	 arg2176_1214 = class_num_218___object(cmake_box_177_cgen_cop);
	 {
	    obj_t obj_2419;
	    obj_2419 = (obj_t) (new1846_1213);
	    (((obj_t) CREF(obj_2419))->header = MAKE_HEADER(arg2176_1214, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4467;
	 aux_4467 = (object_t) (new1846_1213);
	 OBJECT_WIDENING_SET(aux_4467, BFALSE);
      }
      return new1846_1213;
   }
}


/* _allocate-cmake-box */ obj_t 
_allocate_cmake_box_154_cgen_cop(obj_t env_3324)
{
   {
      cmake_box_177_t aux_4470;
      aux_4470 = allocate_cmake_box_148_cgen_cop();
      return (obj_t) (aux_4470);
   }
}


/* cmake-box? */ bool_t 
cmake_box__185_cgen_cop(obj_t obj_120)
{
   return is_a__118___object(obj_120, cmake_box_177_cgen_cop);
}


/* _cmake-box? */ obj_t 
_cmake_box__210_cgen_cop(obj_t env_3487, obj_t obj_3488)
{
   {
      bool_t aux_4474;
      aux_4474 = cmake_box__185_cgen_cop(obj_3488);
      return BBOOL(aux_4474);
   }
}


/* make-cmake-box */ cmake_box_177_t 
make_cmake_box_87_cgen_cop(obj_t loc_121, cop_t value_122)
{
   {
      cmake_box_177_t new1841_2421;
      new1841_2421 = ((cmake_box_177_t) BREF(GC_MALLOC(sizeof(struct cmake_box_177))));
      {
	 long arg2178_2422;
	 arg2178_2422 = class_num_218___object(cmake_box_177_cgen_cop);
	 {
	    obj_t obj_2425;
	    obj_2425 = (obj_t) (new1841_2421);
	    (((obj_t) CREF(obj_2425))->header = MAKE_HEADER(arg2178_2422, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4481;
	 aux_4481 = (object_t) (new1841_2421);
	 OBJECT_WIDENING_SET(aux_4481, BFALSE);
      }
      ((((cmake_box_177_t) CREF(new1841_2421))->loc) = ((obj_t) loc_121), BUNSPEC);
      ((((cmake_box_177_t) CREF(new1841_2421))->value) = ((cop_t) value_122), BUNSPEC);
      return new1841_2421;
   }
}


/* _make-cmake-box2679 */ obj_t 
_make_cmake_box2679_81_cgen_cop(obj_t env_3489, obj_t loc_3490, obj_t value_3491)
{
   {
      cmake_box_177_t aux_4486;
      aux_4486 = make_cmake_box_87_cgen_cop(loc_3490, (cop_t) (value_3491));
      return (obj_t) (aux_4486);
   }
}


/* cmake-box-loc-set! */ obj_t 
cmake_box_loc_set__105_cgen_cop(cmake_box_177_t obj_123, obj_t val1845_124)
{
   return ((((cmake_box_177_t) CREF(obj_123))->loc) = ((obj_t) val1845_124), BUNSPEC);
}


/* _cmake-box-loc-set!2680 */ obj_t 
_cmake_box_loc_set_2680_187_cgen_cop(obj_t env_3492, obj_t obj_3493, obj_t val1845_3494)
{
   return cmake_box_loc_set__105_cgen_cop((cmake_box_177_t) (obj_3493), val1845_3494);
}


/* cmake-box-loc */ obj_t 
cmake_box_loc_203_cgen_cop(cmake_box_177_t obj_125)
{
   return (((cmake_box_177_t) CREF(obj_125))->loc);
}


/* _cmake-box-loc2681 */ obj_t 
_cmake_box_loc2681_4_cgen_cop(obj_t env_3495, obj_t obj_3496)
{
   return cmake_box_loc_203_cgen_cop((cmake_box_177_t) (obj_3496));
}


/* cmake-box-value */ cop_t 
cmake_box_value_135_cgen_cop(cmake_box_177_t obj_126)
{
   return (((cmake_box_177_t) CREF(obj_126))->value);
}


/* _cmake-box-value2682 */ obj_t 
_cmake_box_value2682_176_cgen_cop(obj_t env_3497, obj_t obj_3498)
{
   {
      cop_t aux_4497;
      aux_4497 = cmake_box_value_135_cgen_cop((cmake_box_177_t) (obj_3498));
      return (obj_t) (aux_4497);
   }
}


/* allocate-cswitch */ cswitch_t 
allocate_cswitch_92_cgen_cop()
{
   {
      cswitch_t new1826_1219;
      new1826_1219 = ((cswitch_t) BREF(GC_MALLOC(sizeof(struct cswitch))));
      {
	 long arg2179_1220;
	 arg2179_1220 = class_num_218___object(cswitch_cgen_cop);
	 {
	    obj_t obj_2427;
	    obj_2427 = (obj_t) (new1826_1219);
	    (((obj_t) CREF(obj_2427))->header = MAKE_HEADER(arg2179_1220, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4505;
	 aux_4505 = (object_t) (new1826_1219);
	 OBJECT_WIDENING_SET(aux_4505, BFALSE);
      }
      return new1826_1219;
   }
}


/* _allocate-cswitch */ obj_t 
_allocate_cswitch_108_cgen_cop(obj_t env_3323)
{
   {
      cswitch_t aux_4508;
      aux_4508 = allocate_cswitch_92_cgen_cop();
      return (obj_t) (aux_4508);
   }
}


/* cswitch? */ bool_t 
cswitch__75_cgen_cop(obj_t obj_130)
{
   return is_a__118___object(obj_130, cswitch_cgen_cop);
}


/* _cswitch? */ obj_t 
_cswitch__47_cgen_cop(obj_t env_3499, obj_t obj_3500)
{
   {
      bool_t aux_4512;
      aux_4512 = cswitch__75_cgen_cop(obj_3500);
      return BBOOL(aux_4512);
   }
}


/* make-cswitch */ cswitch_t 
make_cswitch_250_cgen_cop(obj_t loc_131, cop_t test_132, obj_t clauses_133)
{
   {
      cswitch_t new1820_2429;
      new1820_2429 = ((cswitch_t) BREF(GC_MALLOC(sizeof(struct cswitch))));
      {
	 long arg2180_2430;
	 arg2180_2430 = class_num_218___object(cswitch_cgen_cop);
	 {
	    obj_t obj_2434;
	    obj_2434 = (obj_t) (new1820_2429);
	    (((obj_t) CREF(obj_2434))->header = MAKE_HEADER(arg2180_2430, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4519;
	 aux_4519 = (object_t) (new1820_2429);
	 OBJECT_WIDENING_SET(aux_4519, BFALSE);
      }
      ((((cswitch_t) CREF(new1820_2429))->loc) = ((obj_t) loc_131), BUNSPEC);
      ((((cswitch_t) CREF(new1820_2429))->test) = ((cop_t) test_132), BUNSPEC);
      ((((cswitch_t) CREF(new1820_2429))->clauses) = ((obj_t) clauses_133), BUNSPEC);
      return new1820_2429;
   }
}


/* _make-cswitch2683 */ obj_t 
_make_cswitch2683_182_cgen_cop(obj_t env_3501, obj_t loc_3502, obj_t test_3503, obj_t clauses_3504)
{
   {
      cswitch_t aux_4525;
      aux_4525 = make_cswitch_250_cgen_cop(loc_3502, (cop_t) (test_3503), clauses_3504);
      return (obj_t) (aux_4525);
   }
}


/* cswitch-loc-set! */ obj_t 
cswitch_loc_set__163_cgen_cop(cswitch_t obj_134, obj_t val1825_135)
{
   return ((((cswitch_t) CREF(obj_134))->loc) = ((obj_t) val1825_135), BUNSPEC);
}


/* _cswitch-loc-set!2684 */ obj_t 
_cswitch_loc_set_2684_178_cgen_cop(obj_t env_3505, obj_t obj_3506, obj_t val1825_3507)
{
   return cswitch_loc_set__163_cgen_cop((cswitch_t) (obj_3506), val1825_3507);
}


/* cswitch-loc */ obj_t 
cswitch_loc_193_cgen_cop(cswitch_t obj_136)
{
   return (((cswitch_t) CREF(obj_136))->loc);
}


/* _cswitch-loc2685 */ obj_t 
_cswitch_loc2685_52_cgen_cop(obj_t env_3508, obj_t obj_3509)
{
   return cswitch_loc_193_cgen_cop((cswitch_t) (obj_3509));
}


/* cswitch-test */ cop_t 
cswitch_test_204_cgen_cop(cswitch_t obj_137)
{
   return (((cswitch_t) CREF(obj_137))->test);
}


/* _cswitch-test2686 */ obj_t 
_cswitch_test2686_46_cgen_cop(obj_t env_3510, obj_t obj_3511)
{
   {
      cop_t aux_4536;
      aux_4536 = cswitch_test_204_cgen_cop((cswitch_t) (obj_3511));
      return (obj_t) (aux_4536);
   }
}


/* cswitch-clauses */ obj_t 
cswitch_clauses_50_cgen_cop(cswitch_t obj_138)
{
   return (((cswitch_t) CREF(obj_138))->clauses);
}


/* _cswitch-clauses2687 */ obj_t 
_cswitch_clauses2687_232_cgen_cop(obj_t env_3512, obj_t obj_3513)
{
   return cswitch_clauses_50_cgen_cop((cswitch_t) (obj_3513));
}


/* allocate-cfail */ cfail_t 
allocate_cfail_187_cgen_cop()
{
   {
      cfail_t new1801_1226;
      new1801_1226 = ((cfail_t) BREF(GC_MALLOC(sizeof(struct cfail))));
      {
	 long arg2181_1227;
	 arg2181_1227 = class_num_218___object(cfail_cgen_cop);
	 {
	    obj_t obj_2436;
	    obj_2436 = (obj_t) (new1801_1226);
	    (((obj_t) CREF(obj_2436))->header = MAKE_HEADER(arg2181_1227, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4547;
	 aux_4547 = (object_t) (new1801_1226);
	 OBJECT_WIDENING_SET(aux_4547, BFALSE);
      }
      return new1801_1226;
   }
}


/* _allocate-cfail */ obj_t 
_allocate_cfail_114_cgen_cop(obj_t env_3322)
{
   {
      cfail_t aux_4550;
      aux_4550 = allocate_cfail_187_cgen_cop();
      return (obj_t) (aux_4550);
   }
}


/* cfail? */ bool_t 
cfail__244_cgen_cop(obj_t obj_142)
{
   return is_a__118___object(obj_142, cfail_cgen_cop);
}


/* _cfail? */ obj_t 
_cfail__212_cgen_cop(obj_t env_3514, obj_t obj_3515)
{
   {
      bool_t aux_4554;
      aux_4554 = cfail__244_cgen_cop(obj_3515);
      return BBOOL(aux_4554);
   }
}


/* make-cfail */ cfail_t 
make_cfail_76_cgen_cop(obj_t loc_143, cop_t proc_144, cop_t msg_145, cop_t obj_146)
{
   {
      cfail_t new1794_2438;
      new1794_2438 = ((cfail_t) BREF(GC_MALLOC(sizeof(struct cfail))));
      {
	 long arg2182_2439;
	 arg2182_2439 = class_num_218___object(cfail_cgen_cop);
	 {
	    obj_t obj_2444;
	    obj_2444 = (obj_t) (new1794_2438);
	    (((obj_t) CREF(obj_2444))->header = MAKE_HEADER(arg2182_2439, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4561;
	 aux_4561 = (object_t) (new1794_2438);
	 OBJECT_WIDENING_SET(aux_4561, BFALSE);
      }
      ((((cfail_t) CREF(new1794_2438))->loc) = ((obj_t) loc_143), BUNSPEC);
      ((((cfail_t) CREF(new1794_2438))->proc) = ((cop_t) proc_144), BUNSPEC);
      ((((cfail_t) CREF(new1794_2438))->msg) = ((cop_t) msg_145), BUNSPEC);
      ((((cfail_t) CREF(new1794_2438))->obj) = ((cop_t) obj_146), BUNSPEC);
      return new1794_2438;
   }
}


/* _make-cfail2688 */ obj_t 
_make_cfail2688_47_cgen_cop(obj_t env_3516, obj_t loc_3517, obj_t proc_3518, obj_t msg_3519, obj_t obj_3520)
{
   {
      cfail_t aux_4568;
      aux_4568 = make_cfail_76_cgen_cop(loc_3517, (cop_t) (proc_3518), (cop_t) (msg_3519), (cop_t) (obj_3520));
      return (obj_t) (aux_4568);
   }
}


/* cfail-loc-set! */ obj_t 
cfail_loc_set__82_cgen_cop(cfail_t obj_147, obj_t val1800_148)
{
   return ((((cfail_t) CREF(obj_147))->loc) = ((obj_t) val1800_148), BUNSPEC);
}


/* _cfail-loc-set!2689 */ obj_t 
_cfail_loc_set_2689_94_cgen_cop(obj_t env_3521, obj_t obj_3522, obj_t val1800_3523)
{
   return cfail_loc_set__82_cgen_cop((cfail_t) (obj_3522), val1800_3523);
}


/* cfail-loc */ obj_t 
cfail_loc_182_cgen_cop(cfail_t obj_149)
{
   return (((cfail_t) CREF(obj_149))->loc);
}


/* _cfail-loc2690 */ obj_t 
_cfail_loc2690_159_cgen_cop(obj_t env_3524, obj_t obj_3525)
{
   return cfail_loc_182_cgen_cop((cfail_t) (obj_3525));
}


/* cfail-proc */ cop_t 
cfail_proc_96_cgen_cop(cfail_t obj_150)
{
   return (((cfail_t) CREF(obj_150))->proc);
}


/* _cfail-proc2691 */ obj_t 
_cfail_proc2691_25_cgen_cop(obj_t env_3526, obj_t obj_3527)
{
   {
      cop_t aux_4581;
      aux_4581 = cfail_proc_96_cgen_cop((cfail_t) (obj_3527));
      return (obj_t) (aux_4581);
   }
}


/* cfail-msg */ cop_t 
cfail_msg_43_cgen_cop(cfail_t obj_151)
{
   return (((cfail_t) CREF(obj_151))->msg);
}


/* _cfail-msg2692 */ obj_t 
_cfail_msg2692_109_cgen_cop(obj_t env_3528, obj_t obj_3529)
{
   {
      cop_t aux_4586;
      aux_4586 = cfail_msg_43_cgen_cop((cfail_t) (obj_3529));
      return (obj_t) (aux_4586);
   }
}


/* cfail-obj */ cop_t 
cfail_obj_133_cgen_cop(cfail_t obj_152)
{
   return (((cfail_t) CREF(obj_152))->obj);
}


/* _cfail-obj2693 */ obj_t 
_cfail_obj2693_80_cgen_cop(obj_t env_3530, obj_t obj_3531)
{
   {
      cop_t aux_4591;
      aux_4591 = cfail_obj_133_cgen_cop((cfail_t) (obj_3531));
      return (obj_t) (aux_4591);
   }
}


/* allocate-capp */ capp_t 
allocate_capp_109_cgen_cop()
{
   {
      capp_t new1778_1234;
      new1778_1234 = ((capp_t) BREF(GC_MALLOC(sizeof(struct capp))));
      {
	 long arg2183_1235;
	 arg2183_1235 = class_num_218___object(capp_cgen_cop);
	 {
	    obj_t obj_2446;
	    obj_2446 = (obj_t) (new1778_1234);
	    (((obj_t) CREF(obj_2446))->header = MAKE_HEADER(arg2183_1235, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4599;
	 aux_4599 = (object_t) (new1778_1234);
	 OBJECT_WIDENING_SET(aux_4599, BFALSE);
      }
      return new1778_1234;
   }
}


/* _allocate-capp */ obj_t 
_allocate_capp_243_cgen_cop(obj_t env_3321)
{
   {
      capp_t aux_4602;
      aux_4602 = allocate_capp_109_cgen_cop();
      return (obj_t) (aux_4602);
   }
}


/* capp? */ bool_t 
capp__160_cgen_cop(obj_t obj_156)
{
   return is_a__118___object(obj_156, capp_cgen_cop);
}


/* _capp? */ obj_t 
_capp__47_cgen_cop(obj_t env_3532, obj_t obj_3533)
{
   {
      bool_t aux_4606;
      aux_4606 = capp__160_cgen_cop(obj_3533);
      return BBOOL(aux_4606);
   }
}


/* make-capp */ capp_t 
make_capp_159_cgen_cop(obj_t loc_157, cop_t fun_158, obj_t args_159)
{
   {
      capp_t new1772_2448;
      new1772_2448 = ((capp_t) BREF(GC_MALLOC(sizeof(struct capp))));
      {
	 long arg2184_2449;
	 arg2184_2449 = class_num_218___object(capp_cgen_cop);
	 {
	    obj_t obj_2453;
	    obj_2453 = (obj_t) (new1772_2448);
	    (((obj_t) CREF(obj_2453))->header = MAKE_HEADER(arg2184_2449, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4613;
	 aux_4613 = (object_t) (new1772_2448);
	 OBJECT_WIDENING_SET(aux_4613, BFALSE);
      }
      ((((capp_t) CREF(new1772_2448))->loc) = ((obj_t) loc_157), BUNSPEC);
      ((((capp_t) CREF(new1772_2448))->fun) = ((cop_t) fun_158), BUNSPEC);
      ((((capp_t) CREF(new1772_2448))->args) = ((obj_t) args_159), BUNSPEC);
      return new1772_2448;
   }
}


/* _make-capp2694 */ obj_t 
_make_capp2694_163_cgen_cop(obj_t env_3534, obj_t loc_3535, obj_t fun_3536, obj_t args_3537)
{
   {
      capp_t aux_4619;
      aux_4619 = make_capp_159_cgen_cop(loc_3535, (cop_t) (fun_3536), args_3537);
      return (obj_t) (aux_4619);
   }
}


/* capp-loc-set! */ obj_t 
capp_loc_set__54_cgen_cop(capp_t obj_160, obj_t val1777_161)
{
   return ((((capp_t) CREF(obj_160))->loc) = ((obj_t) val1777_161), BUNSPEC);
}


/* _capp-loc-set!2695 */ obj_t 
_capp_loc_set_2695_133_cgen_cop(obj_t env_3538, obj_t obj_3539, obj_t val1777_3540)
{
   return capp_loc_set__54_cgen_cop((capp_t) (obj_3539), val1777_3540);
}


/* capp-loc */ obj_t 
capp_loc_231_cgen_cop(capp_t obj_162)
{
   return (((capp_t) CREF(obj_162))->loc);
}


/* _capp-loc2696 */ obj_t 
_capp_loc2696_15_cgen_cop(obj_t env_3541, obj_t obj_3542)
{
   return capp_loc_231_cgen_cop((capp_t) (obj_3542));
}


/* capp-fun */ cop_t 
capp_fun_71_cgen_cop(capp_t obj_163)
{
   return (((capp_t) CREF(obj_163))->fun);
}


/* _capp-fun2697 */ obj_t 
_capp_fun2697_239_cgen_cop(obj_t env_3543, obj_t obj_3544)
{
   {
      cop_t aux_4630;
      aux_4630 = capp_fun_71_cgen_cop((capp_t) (obj_3544));
      return (obj_t) (aux_4630);
   }
}


/* capp-args */ obj_t 
capp_args_148_cgen_cop(capp_t obj_164)
{
   return (((capp_t) CREF(obj_164))->args);
}


/* _capp-args2698 */ obj_t 
_capp_args2698_252_cgen_cop(obj_t env_3545, obj_t obj_3546)
{
   return capp_args_148_cgen_cop((capp_t) (obj_3546));
}


/* allocate-capply */ capply_t 
allocate_capply_99_cgen_cop()
{
   {
      capply_t new1757_1241;
      new1757_1241 = ((capply_t) BREF(GC_MALLOC(sizeof(struct capply))));
      {
	 long arg2185_1242;
	 arg2185_1242 = class_num_218___object(capply_cgen_cop);
	 {
	    obj_t obj_2455;
	    obj_2455 = (obj_t) (new1757_1241);
	    (((obj_t) CREF(obj_2455))->header = MAKE_HEADER(arg2185_1242, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4641;
	 aux_4641 = (object_t) (new1757_1241);
	 OBJECT_WIDENING_SET(aux_4641, BFALSE);
      }
      return new1757_1241;
   }
}


/* _allocate-capply */ obj_t 
_allocate_capply_222_cgen_cop(obj_t env_3320)
{
   {
      capply_t aux_4644;
      aux_4644 = allocate_capply_99_cgen_cop();
      return (obj_t) (aux_4644);
   }
}


/* capply? */ bool_t 
capply__56_cgen_cop(obj_t obj_168)
{
   return is_a__118___object(obj_168, capply_cgen_cop);
}


/* _capply? */ obj_t 
_capply__134_cgen_cop(obj_t env_3547, obj_t obj_3548)
{
   {
      bool_t aux_4648;
      aux_4648 = capply__56_cgen_cop(obj_3548);
      return BBOOL(aux_4648);
   }
}


/* make-capply */ capply_t 
make_capply_101_cgen_cop(obj_t loc_169, cop_t fun_170, cop_t arg_171)
{
   {
      capply_t new1751_2457;
      new1751_2457 = ((capply_t) BREF(GC_MALLOC(sizeof(struct capply))));
      {
	 long arg2186_2458;
	 arg2186_2458 = class_num_218___object(capply_cgen_cop);
	 {
	    obj_t obj_2462;
	    obj_2462 = (obj_t) (new1751_2457);
	    (((obj_t) CREF(obj_2462))->header = MAKE_HEADER(arg2186_2458, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4655;
	 aux_4655 = (object_t) (new1751_2457);
	 OBJECT_WIDENING_SET(aux_4655, BFALSE);
      }
      ((((capply_t) CREF(new1751_2457))->loc) = ((obj_t) loc_169), BUNSPEC);
      ((((capply_t) CREF(new1751_2457))->fun) = ((cop_t) fun_170), BUNSPEC);
      ((((capply_t) CREF(new1751_2457))->arg) = ((cop_t) arg_171), BUNSPEC);
      return new1751_2457;
   }
}


/* _make-capply2699 */ obj_t 
_make_capply2699_147_cgen_cop(obj_t env_3549, obj_t loc_3550, obj_t fun_3551, obj_t arg_3552)
{
   {
      capply_t aux_4661;
      aux_4661 = make_capply_101_cgen_cop(loc_3550, (cop_t) (fun_3551), (cop_t) (arg_3552));
      return (obj_t) (aux_4661);
   }
}


/* capply-loc-set! */ obj_t 
capply_loc_set__0_cgen_cop(capply_t obj_172, obj_t val1756_173)
{
   return ((((capply_t) CREF(obj_172))->loc) = ((obj_t) val1756_173), BUNSPEC);
}


/* _capply-loc-set!2700 */ obj_t 
_capply_loc_set_2700_55_cgen_cop(obj_t env_3553, obj_t obj_3554, obj_t val1756_3555)
{
   return capply_loc_set__0_cgen_cop((capply_t) (obj_3554), val1756_3555);
}


/* capply-loc */ obj_t 
capply_loc_38_cgen_cop(capply_t obj_174)
{
   return (((capply_t) CREF(obj_174))->loc);
}


/* _capply-loc2701 */ obj_t 
_capply_loc2701_113_cgen_cop(obj_t env_3556, obj_t obj_3557)
{
   return capply_loc_38_cgen_cop((capply_t) (obj_3557));
}


/* capply-fun */ cop_t 
capply_fun_1_cgen_cop(capply_t obj_175)
{
   return (((capply_t) CREF(obj_175))->fun);
}


/* _capply-fun2702 */ obj_t 
_capply_fun2702_109_cgen_cop(obj_t env_3558, obj_t obj_3559)
{
   {
      cop_t aux_4673;
      aux_4673 = capply_fun_1_cgen_cop((capply_t) (obj_3559));
      return (obj_t) (aux_4673);
   }
}


/* capply-arg */ cop_t 
capply_arg_66_cgen_cop(capply_t obj_176)
{
   return (((capply_t) CREF(obj_176))->arg);
}


/* _capply-arg2703 */ obj_t 
_capply_arg2703_187_cgen_cop(obj_t env_3560, obj_t obj_3561)
{
   {
      cop_t aux_4678;
      aux_4678 = capply_arg_66_cgen_cop((capply_t) (obj_3561));
      return (obj_t) (aux_4678);
   }
}


/* allocate-cfuncall */ cfuncall_t 
allocate_cfuncall_37_cgen_cop()
{
   {
      cfuncall_t new1732_1248;
      new1732_1248 = ((cfuncall_t) BREF(GC_MALLOC(sizeof(struct cfuncall))));
      {
	 long arg2187_1249;
	 arg2187_1249 = class_num_218___object(cfuncall_cgen_cop);
	 {
	    obj_t obj_2464;
	    obj_2464 = (obj_t) (new1732_1248);
	    (((obj_t) CREF(obj_2464))->header = MAKE_HEADER(arg2187_1249, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4686;
	 aux_4686 = (object_t) (new1732_1248);
	 OBJECT_WIDENING_SET(aux_4686, BFALSE);
      }
      return new1732_1248;
   }
}


/* _allocate-cfuncall */ obj_t 
_allocate_cfuncall_49_cgen_cop(obj_t env_3319)
{
   {
      cfuncall_t aux_4689;
      aux_4689 = allocate_cfuncall_37_cgen_cop();
      return (obj_t) (aux_4689);
   }
}


/* cfuncall? */ bool_t 
cfuncall__223_cgen_cop(obj_t obj_180)
{
   return is_a__118___object(obj_180, cfuncall_cgen_cop);
}


/* _cfuncall? */ obj_t 
_cfuncall__70_cgen_cop(obj_t env_3562, obj_t obj_3563)
{
   {
      bool_t aux_4693;
      aux_4693 = cfuncall__223_cgen_cop(obj_3563);
      return BBOOL(aux_4693);
   }
}


/* make-cfuncall */ cfuncall_t 
make_cfuncall_230_cgen_cop(obj_t loc_181, cop_t fun_182, obj_t args_183, obj_t strength_184)
{
   {
      cfuncall_t new1725_2466;
      new1725_2466 = ((cfuncall_t) BREF(GC_MALLOC(sizeof(struct cfuncall))));
      {
	 long arg2188_2467;
	 arg2188_2467 = class_num_218___object(cfuncall_cgen_cop);
	 {
	    obj_t obj_2472;
	    obj_2472 = (obj_t) (new1725_2466);
	    (((obj_t) CREF(obj_2472))->header = MAKE_HEADER(arg2188_2467, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4700;
	 aux_4700 = (object_t) (new1725_2466);
	 OBJECT_WIDENING_SET(aux_4700, BFALSE);
      }
      ((((cfuncall_t) CREF(new1725_2466))->loc) = ((obj_t) loc_181), BUNSPEC);
      ((((cfuncall_t) CREF(new1725_2466))->fun) = ((cop_t) fun_182), BUNSPEC);
      ((((cfuncall_t) CREF(new1725_2466))->args) = ((obj_t) args_183), BUNSPEC);
      ((((cfuncall_t) CREF(new1725_2466))->strength) = ((obj_t) strength_184), BUNSPEC);
      return new1725_2466;
   }
}


/* _make-cfuncall2704 */ obj_t 
_make_cfuncall2704_63_cgen_cop(obj_t env_3564, obj_t loc_3565, obj_t fun_3566, obj_t args_3567, obj_t strength_3568)
{
   {
      cfuncall_t aux_4707;
      aux_4707 = make_cfuncall_230_cgen_cop(loc_3565, (cop_t) (fun_3566), args_3567, strength_3568);
      return (obj_t) (aux_4707);
   }
}


/* cfuncall-loc-set! */ obj_t 
cfuncall_loc_set__107_cgen_cop(cfuncall_t obj_185, obj_t val1731_186)
{
   return ((((cfuncall_t) CREF(obj_185))->loc) = ((obj_t) val1731_186), BUNSPEC);
}


/* _cfuncall-loc-set!2705 */ obj_t 
_cfuncall_loc_set_2705_205_cgen_cop(obj_t env_3569, obj_t obj_3570, obj_t val1731_3571)
{
   return cfuncall_loc_set__107_cgen_cop((cfuncall_t) (obj_3570), val1731_3571);
}


/* cfuncall-loc */ obj_t 
cfuncall_loc_128_cgen_cop(cfuncall_t obj_187)
{
   return (((cfuncall_t) CREF(obj_187))->loc);
}


/* _cfuncall-loc2706 */ obj_t 
_cfuncall_loc2706_72_cgen_cop(obj_t env_3572, obj_t obj_3573)
{
   return cfuncall_loc_128_cgen_cop((cfuncall_t) (obj_3573));
}


/* cfuncall-fun */ cop_t 
cfuncall_fun_206_cgen_cop(cfuncall_t obj_188)
{
   return (((cfuncall_t) CREF(obj_188))->fun);
}


/* _cfuncall-fun2707 */ obj_t 
_cfuncall_fun2707_141_cgen_cop(obj_t env_3574, obj_t obj_3575)
{
   {
      cop_t aux_4718;
      aux_4718 = cfuncall_fun_206_cgen_cop((cfuncall_t) (obj_3575));
      return (obj_t) (aux_4718);
   }
}


/* cfuncall-args */ obj_t 
cfuncall_args_216_cgen_cop(cfuncall_t obj_189)
{
   return (((cfuncall_t) CREF(obj_189))->args);
}


/* _cfuncall-args2708 */ obj_t 
_cfuncall_args2708_4_cgen_cop(obj_t env_3576, obj_t obj_3577)
{
   return cfuncall_args_216_cgen_cop((cfuncall_t) (obj_3577));
}


/* cfuncall-strength */ obj_t 
cfuncall_strength_61_cgen_cop(cfuncall_t obj_190)
{
   return (((cfuncall_t) CREF(obj_190))->strength);
}


/* _cfuncall-strength2709 */ obj_t 
_cfuncall_strength2709_48_cgen_cop(obj_t env_3578, obj_t obj_3579)
{
   return cfuncall_strength_61_cgen_cop((cfuncall_t) (obj_3579));
}


/* allocate-local-var */ local_var_164_t 
allocate_local_var_218_cgen_cop()
{
   {
      local_var_164_t new1714_1256;
      new1714_1256 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
      {
	 long arg2189_1257;
	 arg2189_1257 = class_num_218___object(local_var_164_cgen_cop);
	 {
	    obj_t obj_2474;
	    obj_2474 = (obj_t) (new1714_1256);
	    (((obj_t) CREF(obj_2474))->header = MAKE_HEADER(arg2189_1257, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4732;
	 aux_4732 = (object_t) (new1714_1256);
	 OBJECT_WIDENING_SET(aux_4732, BFALSE);
      }
      return new1714_1256;
   }
}


/* _allocate-local-var */ obj_t 
_allocate_local_var_109_cgen_cop(obj_t env_3318)
{
   {
      local_var_164_t aux_4735;
      aux_4735 = allocate_local_var_218_cgen_cop();
      return (obj_t) (aux_4735);
   }
}


/* local-var? */ bool_t 
local_var__228_cgen_cop(obj_t obj_194)
{
   return is_a__118___object(obj_194, local_var_164_cgen_cop);
}


/* _local-var? */ obj_t 
_local_var__240_cgen_cop(obj_t env_3580, obj_t obj_3581)
{
   {
      bool_t aux_4739;
      aux_4739 = local_var__228_cgen_cop(obj_3581);
      return BBOOL(aux_4739);
   }
}


/* make-local-var */ local_var_164_t 
make_local_var_50_cgen_cop(obj_t loc_195, obj_t vars_196)
{
   {
      local_var_164_t new1709_2476;
      new1709_2476 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
      {
	 long arg2190_2477;
	 arg2190_2477 = class_num_218___object(local_var_164_cgen_cop);
	 {
	    obj_t obj_2480;
	    obj_2480 = (obj_t) (new1709_2476);
	    (((obj_t) CREF(obj_2480))->header = MAKE_HEADER(arg2190_2477, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4746;
	 aux_4746 = (object_t) (new1709_2476);
	 OBJECT_WIDENING_SET(aux_4746, BFALSE);
      }
      ((((local_var_164_t) CREF(new1709_2476))->loc) = ((obj_t) loc_195), BUNSPEC);
      ((((local_var_164_t) CREF(new1709_2476))->vars) = ((obj_t) vars_196), BUNSPEC);
      return new1709_2476;
   }
}


/* _make-local-var */ obj_t 
_make_local_var_232_cgen_cop(obj_t env_3582, obj_t loc_3583, obj_t vars_3584)
{
   {
      local_var_164_t aux_4751;
      aux_4751 = make_local_var_50_cgen_cop(loc_3583, vars_3584);
      return (obj_t) (aux_4751);
   }
}


/* local-var-loc-set! */ obj_t 
local_var_loc_set__93_cgen_cop(local_var_164_t obj_197, obj_t val1713_198)
{
   return ((((local_var_164_t) CREF(obj_197))->loc) = ((obj_t) val1713_198), BUNSPEC);
}


/* _local-var-loc-set!2710 */ obj_t 
_local_var_loc_set_2710_19_cgen_cop(obj_t env_3585, obj_t obj_3586, obj_t val1713_3587)
{
   return local_var_loc_set__93_cgen_cop((local_var_164_t) (obj_3586), val1713_3587);
}


/* local-var-loc */ obj_t 
local_var_loc_15_cgen_cop(local_var_164_t obj_199)
{
   return (((local_var_164_t) CREF(obj_199))->loc);
}


/* _local-var-loc2711 */ obj_t 
_local_var_loc2711_133_cgen_cop(obj_t env_3588, obj_t obj_3589)
{
   return local_var_loc_15_cgen_cop((local_var_164_t) (obj_3589));
}


/* local-var-vars */ obj_t 
local_var_vars_243_cgen_cop(local_var_164_t obj_200)
{
   return (((local_var_164_t) CREF(obj_200))->vars);
}


/* _local-var-vars2712 */ obj_t 
_local_var_vars2712_20_cgen_cop(obj_t env_3590, obj_t obj_3591)
{
   return local_var_vars_243_cgen_cop((local_var_164_t) (obj_3591));
}


/* allocate-cif */ cif_t 
allocate_cif_90_cgen_cop()
{
   {
      cif_t new1690_1262;
      new1690_1262 = ((cif_t) BREF(GC_MALLOC(sizeof(struct cif))));
      {
	 long arg2191_1263;
	 arg2191_1263 = class_num_218___object(cif_cgen_cop);
	 {
	    obj_t obj_2482;
	    obj_2482 = (obj_t) (new1690_1262);
	    (((obj_t) CREF(obj_2482))->header = MAKE_HEADER(arg2191_1263, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4767;
	 aux_4767 = (object_t) (new1690_1262);
	 OBJECT_WIDENING_SET(aux_4767, BFALSE);
      }
      return new1690_1262;
   }
}


/* _allocate-cif */ obj_t 
_allocate_cif_80_cgen_cop(obj_t env_3317)
{
   {
      cif_t aux_4770;
      aux_4770 = allocate_cif_90_cgen_cop();
      return (obj_t) (aux_4770);
   }
}


/* cif? */ bool_t 
cif__209_cgen_cop(obj_t obj_204)
{
   return is_a__118___object(obj_204, cif_cgen_cop);
}


/* _cif? */ obj_t 
_cif__54_cgen_cop(obj_t env_3592, obj_t obj_3593)
{
   {
      bool_t aux_4774;
      aux_4774 = cif__209_cgen_cop(obj_3593);
      return BBOOL(aux_4774);
   }
}


/* make-cif */ cif_t 
make_cif_3_cgen_cop(obj_t loc_205, cop_t test_206, cop_t true_207, cop_t false_208)
{
   {
      cif_t new1683_2484;
      new1683_2484 = ((cif_t) BREF(GC_MALLOC(sizeof(struct cif))));
      {
	 long arg2192_2485;
	 arg2192_2485 = class_num_218___object(cif_cgen_cop);
	 {
	    obj_t obj_2490;
	    obj_2490 = (obj_t) (new1683_2484);
	    (((obj_t) CREF(obj_2490))->header = MAKE_HEADER(arg2192_2485, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4781;
	 aux_4781 = (object_t) (new1683_2484);
	 OBJECT_WIDENING_SET(aux_4781, BFALSE);
      }
      ((((cif_t) CREF(new1683_2484))->loc) = ((obj_t) loc_205), BUNSPEC);
      ((((cif_t) CREF(new1683_2484))->test) = ((cop_t) test_206), BUNSPEC);
      ((((cif_t) CREF(new1683_2484))->true) = ((cop_t) true_207), BUNSPEC);
      ((((cif_t) CREF(new1683_2484))->false) = ((cop_t) false_208), BUNSPEC);
      return new1683_2484;
   }
}


/* _make-cif2713 */ obj_t 
_make_cif2713_209_cgen_cop(obj_t env_3594, obj_t loc_3595, obj_t test_3596, obj_t true_3597, obj_t false_3598)
{
   {
      cif_t aux_4788;
      aux_4788 = make_cif_3_cgen_cop(loc_3595, (cop_t) (test_3596), (cop_t) (true_3597), (cop_t) (false_3598));
      return (obj_t) (aux_4788);
   }
}


/* cif-loc-set! */ obj_t 
cif_loc_set__209_cgen_cop(cif_t obj_209, obj_t val1689_210)
{
   return ((((cif_t) CREF(obj_209))->loc) = ((obj_t) val1689_210), BUNSPEC);
}


/* _cif-loc-set!2714 */ obj_t 
_cif_loc_set_2714_174_cgen_cop(obj_t env_3599, obj_t obj_3600, obj_t val1689_3601)
{
   return cif_loc_set__209_cgen_cop((cif_t) (obj_3600), val1689_3601);
}


/* cif-loc */ obj_t 
cif_loc_54_cgen_cop(cif_t obj_211)
{
   return (((cif_t) CREF(obj_211))->loc);
}


/* _cif-loc2715 */ obj_t 
_cif_loc2715_71_cgen_cop(obj_t env_3602, obj_t obj_3603)
{
   return cif_loc_54_cgen_cop((cif_t) (obj_3603));
}


/* cif-test */ cop_t 
cif_test_82_cgen_cop(cif_t obj_212)
{
   return (((cif_t) CREF(obj_212))->test);
}


/* _cif-test2716 */ obj_t 
_cif_test2716_234_cgen_cop(obj_t env_3604, obj_t obj_3605)
{
   {
      cop_t aux_4801;
      aux_4801 = cif_test_82_cgen_cop((cif_t) (obj_3605));
      return (obj_t) (aux_4801);
   }
}


/* cif-true */ cop_t 
cif_true_58_cgen_cop(cif_t obj_213)
{
   return (((cif_t) CREF(obj_213))->true);
}


/* _cif-true2717 */ obj_t 
_cif_true2717_251_cgen_cop(obj_t env_3606, obj_t obj_3607)
{
   {
      cop_t aux_4806;
      aux_4806 = cif_true_58_cgen_cop((cif_t) (obj_3607));
      return (obj_t) (aux_4806);
   }
}


/* cif-false */ cop_t 
cif_false_61_cgen_cop(cif_t obj_214)
{
   return (((cif_t) CREF(obj_214))->false);
}


/* _cif-false2718 */ obj_t 
_cif_false2718_168_cgen_cop(obj_t env_3608, obj_t obj_3609)
{
   {
      cop_t aux_4811;
      aux_4811 = cif_false_61_cgen_cop((cif_t) (obj_3609));
      return (obj_t) (aux_4811);
   }
}


/* allocate-csetq */ csetq_t 
allocate_csetq_141_cgen_cop()
{
   {
      csetq_t new1668_1270;
      new1668_1270 = ((csetq_t) BREF(GC_MALLOC(sizeof(struct csetq))));
      {
	 long arg2193_1271;
	 arg2193_1271 = class_num_218___object(csetq_cgen_cop);
	 {
	    obj_t obj_2492;
	    obj_2492 = (obj_t) (new1668_1270);
	    (((obj_t) CREF(obj_2492))->header = MAKE_HEADER(arg2193_1271, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4819;
	 aux_4819 = (object_t) (new1668_1270);
	 OBJECT_WIDENING_SET(aux_4819, BFALSE);
      }
      return new1668_1270;
   }
}


/* _allocate-csetq */ obj_t 
_allocate_csetq_62_cgen_cop(obj_t env_3316)
{
   {
      csetq_t aux_4822;
      aux_4822 = allocate_csetq_141_cgen_cop();
      return (obj_t) (aux_4822);
   }
}


/* csetq? */ bool_t 
csetq__161_cgen_cop(obj_t obj_218)
{
   return is_a__118___object(obj_218, csetq_cgen_cop);
}


/* _csetq? */ obj_t 
_csetq__142_cgen_cop(obj_t env_3610, obj_t obj_3611)
{
   {
      bool_t aux_4826;
      aux_4826 = csetq__161_cgen_cop(obj_3611);
      return BBOOL(aux_4826);
   }
}


/* make-csetq */ csetq_t 
make_csetq_177_cgen_cop(obj_t loc_219, varc_t var_220, cop_t value_221)
{
   {
      csetq_t new1662_2494;
      new1662_2494 = ((csetq_t) BREF(GC_MALLOC(sizeof(struct csetq))));
      {
	 long arg2194_2495;
	 arg2194_2495 = class_num_218___object(csetq_cgen_cop);
	 {
	    obj_t obj_2499;
	    obj_2499 = (obj_t) (new1662_2494);
	    (((obj_t) CREF(obj_2499))->header = MAKE_HEADER(arg2194_2495, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4833;
	 aux_4833 = (object_t) (new1662_2494);
	 OBJECT_WIDENING_SET(aux_4833, BFALSE);
      }
      ((((csetq_t) CREF(new1662_2494))->loc) = ((obj_t) loc_219), BUNSPEC);
      ((((csetq_t) CREF(new1662_2494))->var) = ((varc_t) var_220), BUNSPEC);
      ((((csetq_t) CREF(new1662_2494))->value) = ((cop_t) value_221), BUNSPEC);
      return new1662_2494;
   }
}


/* _make-csetq2719 */ obj_t 
_make_csetq2719_239_cgen_cop(obj_t env_3612, obj_t loc_3613, obj_t var_3614, obj_t value_3615)
{
   {
      csetq_t aux_4839;
      aux_4839 = make_csetq_177_cgen_cop(loc_3613, (varc_t) (var_3614), (cop_t) (value_3615));
      return (obj_t) (aux_4839);
   }
}


/* csetq-loc-set! */ obj_t 
csetq_loc_set__106_cgen_cop(csetq_t obj_222, obj_t val1667_223)
{
   return ((((csetq_t) CREF(obj_222))->loc) = ((obj_t) val1667_223), BUNSPEC);
}


/* _csetq-loc-set!2720 */ obj_t 
_csetq_loc_set_2720_84_cgen_cop(obj_t env_3616, obj_t obj_3617, obj_t val1667_3618)
{
   return csetq_loc_set__106_cgen_cop((csetq_t) (obj_3617), val1667_3618);
}


/* csetq-loc */ obj_t 
csetq_loc_189_cgen_cop(csetq_t obj_224)
{
   return (((csetq_t) CREF(obj_224))->loc);
}


/* _csetq-loc2721 */ obj_t 
_csetq_loc2721_49_cgen_cop(obj_t env_3619, obj_t obj_3620)
{
   return csetq_loc_189_cgen_cop((csetq_t) (obj_3620));
}


/* csetq-var */ varc_t 
csetq_var_122_cgen_cop(csetq_t obj_225)
{
   return (((csetq_t) CREF(obj_225))->var);
}


/* _csetq-var2722 */ obj_t 
_csetq_var2722_217_cgen_cop(obj_t env_3621, obj_t obj_3622)
{
   {
      varc_t aux_4851;
      aux_4851 = csetq_var_122_cgen_cop((csetq_t) (obj_3622));
      return (obj_t) (aux_4851);
   }
}


/* csetq-value */ cop_t 
csetq_value_168_cgen_cop(csetq_t obj_226)
{
   return (((csetq_t) CREF(obj_226))->value);
}


/* _csetq-value2723 */ obj_t 
_csetq_value2723_42_cgen_cop(obj_t env_3623, obj_t obj_3624)
{
   {
      cop_t aux_4856;
      aux_4856 = csetq_value_168_cgen_cop((csetq_t) (obj_3624));
      return (obj_t) (aux_4856);
   }
}


/* allocate-stop */ stop_t 
allocate_stop_49_cgen_cop()
{
   {
      stop_t new1651_1277;
      new1651_1277 = ((stop_t) BREF(GC_MALLOC(sizeof(struct stop))));
      {
	 long arg2196_1278;
	 arg2196_1278 = class_num_218___object(stop_cgen_cop);
	 {
	    obj_t obj_2501;
	    obj_2501 = (obj_t) (new1651_1277);
	    (((obj_t) CREF(obj_2501))->header = MAKE_HEADER(arg2196_1278, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4864;
	 aux_4864 = (object_t) (new1651_1277);
	 OBJECT_WIDENING_SET(aux_4864, BFALSE);
      }
      return new1651_1277;
   }
}


/* _allocate-stop */ obj_t 
_allocate_stop_67_cgen_cop(obj_t env_3315)
{
   {
      stop_t aux_4867;
      aux_4867 = allocate_stop_49_cgen_cop();
      return (obj_t) (aux_4867);
   }
}


/* stop? */ bool_t 
stop__17_cgen_cop(obj_t obj_230)
{
   return is_a__118___object(obj_230, stop_cgen_cop);
}


/* _stop? */ obj_t 
_stop__237_cgen_cop(obj_t env_3625, obj_t obj_3626)
{
   {
      bool_t aux_4871;
      aux_4871 = stop__17_cgen_cop(obj_3626);
      return BBOOL(aux_4871);
   }
}


/* make-stop */ stop_t 
make_stop_166_cgen_cop(obj_t loc_231, cop_t value_232)
{
   {
      stop_t new1646_2503;
      new1646_2503 = ((stop_t) BREF(GC_MALLOC(sizeof(struct stop))));
      {
	 long arg2197_2504;
	 arg2197_2504 = class_num_218___object(stop_cgen_cop);
	 {
	    obj_t obj_2507;
	    obj_2507 = (obj_t) (new1646_2503);
	    (((obj_t) CREF(obj_2507))->header = MAKE_HEADER(arg2197_2504, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4878;
	 aux_4878 = (object_t) (new1646_2503);
	 OBJECT_WIDENING_SET(aux_4878, BFALSE);
      }
      ((((stop_t) CREF(new1646_2503))->loc) = ((obj_t) loc_231), BUNSPEC);
      ((((stop_t) CREF(new1646_2503))->value) = ((cop_t) value_232), BUNSPEC);
      return new1646_2503;
   }
}


/* _make-stop2724 */ obj_t 
_make_stop2724_181_cgen_cop(obj_t env_3627, obj_t loc_3628, obj_t value_3629)
{
   {
      stop_t aux_4883;
      aux_4883 = make_stop_166_cgen_cop(loc_3628, (cop_t) (value_3629));
      return (obj_t) (aux_4883);
   }
}


/* stop-loc-set! */ obj_t 
stop_loc_set__39_cgen_cop(stop_t obj_233, obj_t val1650_234)
{
   return ((((stop_t) CREF(obj_233))->loc) = ((obj_t) val1650_234), BUNSPEC);
}


/* _stop-loc-set!2725 */ obj_t 
_stop_loc_set_2725_24_cgen_cop(obj_t env_3630, obj_t obj_3631, obj_t val1650_3632)
{
   return stop_loc_set__39_cgen_cop((stop_t) (obj_3631), val1650_3632);
}


/* stop-loc */ obj_t 
stop_loc_69_cgen_cop(stop_t obj_235)
{
   return (((stop_t) CREF(obj_235))->loc);
}


/* _stop-loc2726 */ obj_t 
_stop_loc2726_93_cgen_cop(obj_t env_3633, obj_t obj_3634)
{
   return stop_loc_69_cgen_cop((stop_t) (obj_3634));
}


/* stop-value */ cop_t 
stop_value_3_cgen_cop(stop_t obj_236)
{
   return (((stop_t) CREF(obj_236))->value);
}


/* _stop-value2727 */ obj_t 
_stop_value2727_118_cgen_cop(obj_t env_3635, obj_t obj_3636)
{
   {
      cop_t aux_4894;
      aux_4894 = stop_value_3_cgen_cop((stop_t) (obj_3636));
      return (obj_t) (aux_4894);
   }
}


/* allocate-nop */ nop_t 
allocate_nop_42_cgen_cop()
{
   {
      nop_t new1639_1283;
      new1639_1283 = ((nop_t) BREF(GC_MALLOC(sizeof(struct nop))));
      {
	 long arg2198_1284;
	 arg2198_1284 = class_num_218___object(nop_cgen_cop);
	 {
	    obj_t obj_2509;
	    obj_2509 = (obj_t) (new1639_1283);
	    (((obj_t) CREF(obj_2509))->header = MAKE_HEADER(arg2198_1284, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4902;
	 aux_4902 = (object_t) (new1639_1283);
	 OBJECT_WIDENING_SET(aux_4902, BFALSE);
      }
      return new1639_1283;
   }
}


/* _allocate-nop */ obj_t 
_allocate_nop_142_cgen_cop(obj_t env_3314)
{
   {
      nop_t aux_4905;
      aux_4905 = allocate_nop_42_cgen_cop();
      return (obj_t) (aux_4905);
   }
}


/* nop? */ bool_t 
nop__205_cgen_cop(obj_t obj_240)
{
   return is_a__118___object(obj_240, nop_cgen_cop);
}


/* _nop? */ obj_t 
_nop__15_cgen_cop(obj_t env_3637, obj_t obj_3638)
{
   {
      bool_t aux_4909;
      aux_4909 = nop__205_cgen_cop(obj_3638);
      return BBOOL(aux_4909);
   }
}


/* make-nop */ nop_t 
make_nop_193_cgen_cop(obj_t loc_241)
{
   {
      nop_t new1635_2511;
      new1635_2511 = ((nop_t) BREF(GC_MALLOC(sizeof(struct nop))));
      {
	 long arg2199_2512;
	 arg2199_2512 = class_num_218___object(nop_cgen_cop);
	 {
	    obj_t obj_2514;
	    obj_2514 = (obj_t) (new1635_2511);
	    (((obj_t) CREF(obj_2514))->header = MAKE_HEADER(arg2199_2512, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4916;
	 aux_4916 = (object_t) (new1635_2511);
	 OBJECT_WIDENING_SET(aux_4916, BFALSE);
      }
      ((((nop_t) CREF(new1635_2511))->loc) = ((obj_t) loc_241), BUNSPEC);
      return new1635_2511;
   }
}


/* _make-nop */ obj_t 
_make_nop_127_cgen_cop(obj_t env_3639, obj_t loc_3640)
{
   {
      nop_t aux_4920;
      aux_4920 = make_nop_193_cgen_cop(loc_3640);
      return (obj_t) (aux_4920);
   }
}


/* nop-loc-set! */ obj_t 
nop_loc_set__235_cgen_cop(nop_t obj_242, obj_t val1638_243)
{
   return ((((nop_t) CREF(obj_242))->loc) = ((obj_t) val1638_243), BUNSPEC);
}


/* _nop-loc-set!2728 */ obj_t 
_nop_loc_set_2728_230_cgen_cop(obj_t env_3641, obj_t obj_3642, obj_t val1638_3643)
{
   return nop_loc_set__235_cgen_cop((nop_t) (obj_3642), val1638_3643);
}


/* nop-loc */ obj_t 
nop_loc_175_cgen_cop(nop_t obj_244)
{
   return (((nop_t) CREF(obj_244))->loc);
}


/* _nop-loc2729 */ obj_t 
_nop_loc2729_69_cgen_cop(obj_t env_3644, obj_t obj_3645)
{
   return nop_loc_175_cgen_cop((nop_t) (obj_3645));
}


/* allocate-csequence */ csequence_t 
allocate_csequence_231_cgen_cop()
{
   {
      csequence_t new1620_1288;
      new1620_1288 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
      {
	 long arg2200_1289;
	 arg2200_1289 = class_num_218___object(csequence_cgen_cop);
	 {
	    obj_t obj_2516;
	    obj_2516 = (obj_t) (new1620_1288);
	    (((obj_t) CREF(obj_2516))->header = MAKE_HEADER(arg2200_1289, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4933;
	 aux_4933 = (object_t) (new1620_1288);
	 OBJECT_WIDENING_SET(aux_4933, BFALSE);
      }
      return new1620_1288;
   }
}


/* _allocate-csequence */ obj_t 
_allocate_csequence_87_cgen_cop(obj_t env_3313)
{
   {
      csequence_t aux_4936;
      aux_4936 = allocate_csequence_231_cgen_cop();
      return (obj_t) (aux_4936);
   }
}


/* csequence? */ bool_t 
csequence__124_cgen_cop(obj_t obj_248)
{
   return is_a__118___object(obj_248, csequence_cgen_cop);
}


/* _csequence? */ obj_t 
_csequence__120_cgen_cop(obj_t env_3646, obj_t obj_3647)
{
   {
      bool_t aux_4940;
      aux_4940 = csequence__124_cgen_cop(obj_3647);
      return BBOOL(aux_4940);
   }
}


/* make-csequence */ csequence_t 
make_csequence_181_cgen_cop(obj_t loc_249, bool_t c_exp__163_250, obj_t cops_251)
{
   {
      csequence_t new1614_2518;
      new1614_2518 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
      {
	 long arg2201_2519;
	 arg2201_2519 = class_num_218___object(csequence_cgen_cop);
	 {
	    obj_t obj_2523;
	    obj_2523 = (obj_t) (new1614_2518);
	    (((obj_t) CREF(obj_2523))->header = MAKE_HEADER(arg2201_2519, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4947;
	 aux_4947 = (object_t) (new1614_2518);
	 OBJECT_WIDENING_SET(aux_4947, BFALSE);
      }
      ((((csequence_t) CREF(new1614_2518))->loc) = ((obj_t) loc_249), BUNSPEC);
      ((((csequence_t) CREF(new1614_2518))->c_exp__163) = ((bool_t) c_exp__163_250), BUNSPEC);
      ((((csequence_t) CREF(new1614_2518))->cops) = ((obj_t) cops_251), BUNSPEC);
      return new1614_2518;
   }
}


/* _make-csequence */ obj_t 
_make_csequence_138_cgen_cop(obj_t env_3648, obj_t loc_3649, obj_t c_exp__163_3650, obj_t cops_3651)
{
   {
      csequence_t aux_4953;
      aux_4953 = make_csequence_181_cgen_cop(loc_3649, CBOOL(c_exp__163_3650), cops_3651);
      return (obj_t) (aux_4953);
   }
}


/* csequence-loc-set! */ obj_t 
csequence_loc_set__134_cgen_cop(csequence_t obj_252, obj_t val1619_253)
{
   return ((((csequence_t) CREF(obj_252))->loc) = ((obj_t) val1619_253), BUNSPEC);
}


/* _csequence-loc-set!2730 */ obj_t 
_csequence_loc_set_2730_187_cgen_cop(obj_t env_3652, obj_t obj_3653, obj_t val1619_3654)
{
   return csequence_loc_set__134_cgen_cop((csequence_t) (obj_3653), val1619_3654);
}


/* csequence-loc */ obj_t 
csequence_loc_21_cgen_cop(csequence_t obj_254)
{
   return (((csequence_t) CREF(obj_254))->loc);
}


/* _csequence-loc2731 */ obj_t 
_csequence_loc2731_3_cgen_cop(obj_t env_3655, obj_t obj_3656)
{
   return csequence_loc_21_cgen_cop((csequence_t) (obj_3656));
}


/* csequence-c-exp? */ bool_t 
csequence_c_exp__44_cgen_cop(csequence_t obj_255)
{
   return (((csequence_t) CREF(obj_255))->c_exp__163);
}


/* _csequence-c-exp?2732 */ obj_t 
_csequence_c_exp_2732_23_cgen_cop(obj_t env_3657, obj_t obj_3658)
{
   {
      bool_t aux_4964;
      aux_4964 = csequence_c_exp__44_cgen_cop((csequence_t) (obj_3658));
      return BBOOL(aux_4964);
   }
}


/* csequence-cops */ obj_t 
csequence_cops_198_cgen_cop(csequence_t obj_256)
{
   return (((csequence_t) CREF(obj_256))->cops);
}


/* _csequence-cops2733 */ obj_t 
_csequence_cops2733_166_cgen_cop(obj_t env_3659, obj_t obj_3660)
{
   return csequence_cops_198_cgen_cop((csequence_t) (obj_3660));
}


/* allocate-ccast */ ccast_t 
allocate_ccast_96_cgen_cop()
{
   {
      ccast_t new1599_1295;
      new1599_1295 = ((ccast_t) BREF(GC_MALLOC(sizeof(struct ccast))));
      {
	 long arg2202_1296;
	 arg2202_1296 = class_num_218___object(ccast_cgen_cop);
	 {
	    obj_t obj_2525;
	    obj_2525 = (obj_t) (new1599_1295);
	    (((obj_t) CREF(obj_2525))->header = MAKE_HEADER(arg2202_1296, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4975;
	 aux_4975 = (object_t) (new1599_1295);
	 OBJECT_WIDENING_SET(aux_4975, BFALSE);
      }
      return new1599_1295;
   }
}


/* _allocate-ccast */ obj_t 
_allocate_ccast_222_cgen_cop(obj_t env_3312)
{
   {
      ccast_t aux_4978;
      aux_4978 = allocate_ccast_96_cgen_cop();
      return (obj_t) (aux_4978);
   }
}


/* ccast? */ bool_t 
ccast__115_cgen_cop(obj_t obj_260)
{
   return is_a__118___object(obj_260, ccast_cgen_cop);
}


/* _ccast? */ obj_t 
_ccast__188_cgen_cop(obj_t env_3661, obj_t obj_3662)
{
   {
      bool_t aux_4982;
      aux_4982 = ccast__115_cgen_cop(obj_3662);
      return BBOOL(aux_4982);
   }
}


/* make-ccast */ ccast_t 
make_ccast_74_cgen_cop(obj_t loc_261, type_t type_262, cop_t arg_263)
{
   {
      ccast_t new1593_2527;
      new1593_2527 = ((ccast_t) BREF(GC_MALLOC(sizeof(struct ccast))));
      {
	 long arg2204_2528;
	 arg2204_2528 = class_num_218___object(ccast_cgen_cop);
	 {
	    obj_t obj_2532;
	    obj_2532 = (obj_t) (new1593_2527);
	    (((obj_t) CREF(obj_2532))->header = MAKE_HEADER(arg2204_2528, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4989;
	 aux_4989 = (object_t) (new1593_2527);
	 OBJECT_WIDENING_SET(aux_4989, BFALSE);
      }
      ((((ccast_t) CREF(new1593_2527))->loc) = ((obj_t) loc_261), BUNSPEC);
      ((((ccast_t) CREF(new1593_2527))->type) = ((type_t) type_262), BUNSPEC);
      ((((ccast_t) CREF(new1593_2527))->arg) = ((cop_t) arg_263), BUNSPEC);
      return new1593_2527;
   }
}


/* _make-ccast2734 */ obj_t 
_make_ccast2734_32_cgen_cop(obj_t env_3663, obj_t loc_3664, obj_t type_3665, obj_t arg_3666)
{
   {
      ccast_t aux_4995;
      aux_4995 = make_ccast_74_cgen_cop(loc_3664, (type_t) (type_3665), (cop_t) (arg_3666));
      return (obj_t) (aux_4995);
   }
}


/* ccast-loc-set! */ obj_t 
ccast_loc_set__38_cgen_cop(ccast_t obj_264, obj_t val1598_265)
{
   return ((((ccast_t) CREF(obj_264))->loc) = ((obj_t) val1598_265), BUNSPEC);
}


/* _ccast-loc-set!2735 */ obj_t 
_ccast_loc_set_2735_152_cgen_cop(obj_t env_3667, obj_t obj_3668, obj_t val1598_3669)
{
   return ccast_loc_set__38_cgen_cop((ccast_t) (obj_3668), val1598_3669);
}


/* ccast-loc */ obj_t 
ccast_loc_144_cgen_cop(ccast_t obj_266)
{
   return (((ccast_t) CREF(obj_266))->loc);
}


/* _ccast-loc2736 */ obj_t 
_ccast_loc2736_52_cgen_cop(obj_t env_3670, obj_t obj_3671)
{
   return ccast_loc_144_cgen_cop((ccast_t) (obj_3671));
}


/* ccast-type */ type_t 
ccast_type_180_cgen_cop(ccast_t obj_267)
{
   return (((ccast_t) CREF(obj_267))->type);
}


/* _ccast-type2737 */ obj_t 
_ccast_type2737_234_cgen_cop(obj_t env_3672, obj_t obj_3673)
{
   {
      type_t aux_5007;
      aux_5007 = ccast_type_180_cgen_cop((ccast_t) (obj_3673));
      return (obj_t) (aux_5007);
   }
}


/* ccast-arg */ cop_t 
ccast_arg_212_cgen_cop(ccast_t obj_268)
{
   return (((ccast_t) CREF(obj_268))->arg);
}


/* _ccast-arg2738 */ obj_t 
_ccast_arg2738_227_cgen_cop(obj_t env_3674, obj_t obj_3675)
{
   {
      cop_t aux_5012;
      aux_5012 = ccast_arg_212_cgen_cop((ccast_t) (obj_3675));
      return (obj_t) (aux_5012);
   }
}


/* allocate-cpragma */ cpragma_t 
allocate_cpragma_231_cgen_cop()
{
   {
      cpragma_t new1578_1302;
      new1578_1302 = ((cpragma_t) BREF(GC_MALLOC(sizeof(struct cpragma))));
      {
	 long arg2205_1303;
	 arg2205_1303 = class_num_218___object(cpragma_cgen_cop);
	 {
	    obj_t obj_2534;
	    obj_2534 = (obj_t) (new1578_1302);
	    (((obj_t) CREF(obj_2534))->header = MAKE_HEADER(arg2205_1303, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5020;
	 aux_5020 = (object_t) (new1578_1302);
	 OBJECT_WIDENING_SET(aux_5020, BFALSE);
      }
      return new1578_1302;
   }
}


/* _allocate-cpragma */ obj_t 
_allocate_cpragma_102_cgen_cop(obj_t env_3311)
{
   {
      cpragma_t aux_5023;
      aux_5023 = allocate_cpragma_231_cgen_cop();
      return (obj_t) (aux_5023);
   }
}


/* cpragma? */ bool_t 
cpragma__50_cgen_cop(obj_t obj_272)
{
   return is_a__118___object(obj_272, cpragma_cgen_cop);
}


/* _cpragma? */ obj_t 
_cpragma__0_cgen_cop(obj_t env_3676, obj_t obj_3677)
{
   {
      bool_t aux_5027;
      aux_5027 = cpragma__50_cgen_cop(obj_3677);
      return BBOOL(aux_5027);
   }
}


/* make-cpragma */ cpragma_t 
make_cpragma_16_cgen_cop(obj_t loc_273, obj_t format_274, obj_t args_275)
{
   {
      cpragma_t new1572_2536;
      new1572_2536 = ((cpragma_t) BREF(GC_MALLOC(sizeof(struct cpragma))));
      {
	 long arg2206_2537;
	 arg2206_2537 = class_num_218___object(cpragma_cgen_cop);
	 {
	    obj_t obj_2541;
	    obj_2541 = (obj_t) (new1572_2536);
	    (((obj_t) CREF(obj_2541))->header = MAKE_HEADER(arg2206_2537, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5034;
	 aux_5034 = (object_t) (new1572_2536);
	 OBJECT_WIDENING_SET(aux_5034, BFALSE);
      }
      ((((cpragma_t) CREF(new1572_2536))->loc) = ((obj_t) loc_273), BUNSPEC);
      ((((cpragma_t) CREF(new1572_2536))->format) = ((obj_t) format_274), BUNSPEC);
      ((((cpragma_t) CREF(new1572_2536))->args) = ((obj_t) args_275), BUNSPEC);
      return new1572_2536;
   }
}


/* _make-cpragma2739 */ obj_t 
_make_cpragma2739_122_cgen_cop(obj_t env_3678, obj_t loc_3679, obj_t format_3680, obj_t args_3681)
{
   {
      cpragma_t aux_5040;
      aux_5040 = make_cpragma_16_cgen_cop(loc_3679, format_3680, args_3681);
      return (obj_t) (aux_5040);
   }
}


/* cpragma-loc-set! */ obj_t 
cpragma_loc_set__154_cgen_cop(cpragma_t obj_276, obj_t val1577_277)
{
   return ((((cpragma_t) CREF(obj_276))->loc) = ((obj_t) val1577_277), BUNSPEC);
}


/* _cpragma-loc-set!2740 */ obj_t 
_cpragma_loc_set_2740_10_cgen_cop(obj_t env_3682, obj_t obj_3683, obj_t val1577_3684)
{
   return cpragma_loc_set__154_cgen_cop((cpragma_t) (obj_3683), val1577_3684);
}


/* cpragma-loc */ obj_t 
cpragma_loc_96_cgen_cop(cpragma_t obj_278)
{
   return (((cpragma_t) CREF(obj_278))->loc);
}


/* _cpragma-loc2741 */ obj_t 
_cpragma_loc2741_49_cgen_cop(obj_t env_3685, obj_t obj_3686)
{
   return cpragma_loc_96_cgen_cop((cpragma_t) (obj_3686));
}


/* cpragma-format */ obj_t 
cpragma_format_90_cgen_cop(cpragma_t obj_279)
{
   return (((cpragma_t) CREF(obj_279))->format);
}


/* _cpragma-format2742 */ obj_t 
_cpragma_format2742_234_cgen_cop(obj_t env_3687, obj_t obj_3688)
{
   return cpragma_format_90_cgen_cop((cpragma_t) (obj_3688));
}


/* cpragma-args */ obj_t 
cpragma_args_115_cgen_cop(cpragma_t obj_280)
{
   return (((cpragma_t) CREF(obj_280))->args);
}


/* _cpragma-args2743 */ obj_t 
_cpragma_args2743_86_cgen_cop(obj_t env_3689, obj_t obj_3690)
{
   return cpragma_args_115_cgen_cop((cpragma_t) (obj_3690));
}


/* allocate-varc */ varc_t 
allocate_varc_53_cgen_cop()
{
   {
      varc_t new1561_1309;
      new1561_1309 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
      {
	 long arg2207_1310;
	 arg2207_1310 = class_num_218___object(varc_cgen_cop);
	 {
	    obj_t obj_2543;
	    obj_2543 = (obj_t) (new1561_1309);
	    (((obj_t) CREF(obj_2543))->header = MAKE_HEADER(arg2207_1310, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5059;
	 aux_5059 = (object_t) (new1561_1309);
	 OBJECT_WIDENING_SET(aux_5059, BFALSE);
      }
      return new1561_1309;
   }
}


/* _allocate-varc */ obj_t 
_allocate_varc_172_cgen_cop(obj_t env_3310)
{
   {
      varc_t aux_5062;
      aux_5062 = allocate_varc_53_cgen_cop();
      return (obj_t) (aux_5062);
   }
}


/* varc? */ bool_t 
varc__41_cgen_cop(obj_t obj_284)
{
   return is_a__118___object(obj_284, varc_cgen_cop);
}


/* _varc? */ obj_t 
_varc__28_cgen_cop(obj_t env_3691, obj_t obj_3692)
{
   {
      bool_t aux_5066;
      aux_5066 = varc__41_cgen_cop(obj_3692);
      return BBOOL(aux_5066);
   }
}


/* make-varc */ varc_t 
make_varc_148_cgen_cop(obj_t loc_285, variable_t variable_286)
{
   {
      varc_t new1556_2545;
      new1556_2545 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
      {
	 long arg2208_2546;
	 arg2208_2546 = class_num_218___object(varc_cgen_cop);
	 {
	    obj_t obj_2549;
	    obj_2549 = (obj_t) (new1556_2545);
	    (((obj_t) CREF(obj_2549))->header = MAKE_HEADER(arg2208_2546, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5073;
	 aux_5073 = (object_t) (new1556_2545);
	 OBJECT_WIDENING_SET(aux_5073, BFALSE);
      }
      ((((varc_t) CREF(new1556_2545))->loc) = ((obj_t) loc_285), BUNSPEC);
      ((((varc_t) CREF(new1556_2545))->variable) = ((variable_t) variable_286), BUNSPEC);
      return new1556_2545;
   }
}


/* _make-varc2744 */ obj_t 
_make_varc2744_204_cgen_cop(obj_t env_3693, obj_t loc_3694, obj_t variable_3695)
{
   {
      varc_t aux_5078;
      aux_5078 = make_varc_148_cgen_cop(loc_3694, (variable_t) (variable_3695));
      return (obj_t) (aux_5078);
   }
}


/* varc-loc-set! */ obj_t 
varc_loc_set__52_cgen_cop(varc_t obj_287, obj_t val1560_288)
{
   return ((((varc_t) CREF(obj_287))->loc) = ((obj_t) val1560_288), BUNSPEC);
}


/* _varc-loc-set!2745 */ obj_t 
_varc_loc_set_2745_98_cgen_cop(obj_t env_3696, obj_t obj_3697, obj_t val1560_3698)
{
   return varc_loc_set__52_cgen_cop((varc_t) (obj_3697), val1560_3698);
}


/* varc-loc */ obj_t 
varc_loc_177_cgen_cop(varc_t obj_289)
{
   return (((varc_t) CREF(obj_289))->loc);
}


/* _varc-loc2746 */ obj_t 
_varc_loc2746_80_cgen_cop(obj_t env_3699, obj_t obj_3700)
{
   return varc_loc_177_cgen_cop((varc_t) (obj_3700));
}


/* varc-variable */ variable_t 
varc_variable_146_cgen_cop(varc_t obj_290)
{
   return (((varc_t) CREF(obj_290))->variable);
}


/* _varc-variable2747 */ obj_t 
_varc_variable2747_221_cgen_cop(obj_t env_3701, obj_t obj_3702)
{
   {
      variable_t aux_5089;
      aux_5089 = varc_variable_146_cgen_cop((varc_t) (obj_3702));
      return (obj_t) (aux_5089);
   }
}


/* allocate-catom */ catom_t 
allocate_catom_78_cgen_cop()
{
   {
      catom_t new1545_1315;
      new1545_1315 = ((catom_t) BREF(GC_MALLOC(sizeof(struct catom))));
      {
	 long arg2209_1316;
	 arg2209_1316 = class_num_218___object(catom_cgen_cop);
	 {
	    obj_t obj_2551;
	    obj_2551 = (obj_t) (new1545_1315);
	    (((obj_t) CREF(obj_2551))->header = MAKE_HEADER(arg2209_1316, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5097;
	 aux_5097 = (object_t) (new1545_1315);
	 OBJECT_WIDENING_SET(aux_5097, BFALSE);
      }
      return new1545_1315;
   }
}


/* _allocate-catom */ obj_t 
_allocate_catom_138_cgen_cop(obj_t env_3309)
{
   {
      catom_t aux_5100;
      aux_5100 = allocate_catom_78_cgen_cop();
      return (obj_t) (aux_5100);
   }
}


/* catom? */ bool_t 
catom__16_cgen_cop(obj_t obj_294)
{
   return is_a__118___object(obj_294, catom_cgen_cop);
}


/* _catom? */ obj_t 
_catom__202_cgen_cop(obj_t env_3703, obj_t obj_3704)
{
   {
      bool_t aux_5104;
      aux_5104 = catom__16_cgen_cop(obj_3704);
      return BBOOL(aux_5104);
   }
}


/* make-catom */ catom_t 
make_catom_185_cgen_cop(obj_t loc_295, obj_t value_296)
{
   {
      catom_t new1540_2553;
      new1540_2553 = ((catom_t) BREF(GC_MALLOC(sizeof(struct catom))));
      {
	 long arg2210_2554;
	 arg2210_2554 = class_num_218___object(catom_cgen_cop);
	 {
	    obj_t obj_2557;
	    obj_2557 = (obj_t) (new1540_2553);
	    (((obj_t) CREF(obj_2557))->header = MAKE_HEADER(arg2210_2554, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5111;
	 aux_5111 = (object_t) (new1540_2553);
	 OBJECT_WIDENING_SET(aux_5111, BFALSE);
      }
      ((((catom_t) CREF(new1540_2553))->loc) = ((obj_t) loc_295), BUNSPEC);
      ((((catom_t) CREF(new1540_2553))->value) = ((obj_t) value_296), BUNSPEC);
      return new1540_2553;
   }
}


/* _make-catom */ obj_t 
_make_catom_20_cgen_cop(obj_t env_3705, obj_t loc_3706, obj_t value_3707)
{
   {
      catom_t aux_5116;
      aux_5116 = make_catom_185_cgen_cop(loc_3706, value_3707);
      return (obj_t) (aux_5116);
   }
}


/* catom-loc-set! */ obj_t 
catom_loc_set__236_cgen_cop(catom_t obj_297, obj_t val1544_298)
{
   return ((((catom_t) CREF(obj_297))->loc) = ((obj_t) val1544_298), BUNSPEC);
}


/* _catom-loc-set!2748 */ obj_t 
_catom_loc_set_2748_111_cgen_cop(obj_t env_3708, obj_t obj_3709, obj_t val1544_3710)
{
   return catom_loc_set__236_cgen_cop((catom_t) (obj_3709), val1544_3710);
}


/* catom-loc */ obj_t 
catom_loc_164_cgen_cop(catom_t obj_299)
{
   return (((catom_t) CREF(obj_299))->loc);
}


/* _catom-loc2749 */ obj_t 
_catom_loc2749_178_cgen_cop(obj_t env_3711, obj_t obj_3712)
{
   return catom_loc_164_cgen_cop((catom_t) (obj_3712));
}


/* catom-value */ obj_t 
catom_value_103_cgen_cop(catom_t obj_300)
{
   return (((catom_t) CREF(obj_300))->value);
}


/* _catom-value2750 */ obj_t 
_catom_value2750_110_cgen_cop(obj_t env_3713, obj_t obj_3714)
{
   return catom_value_103_cgen_cop((catom_t) (obj_3714));
}


/* allocate-cvoid */ cvoid_t 
allocate_cvoid_159_cgen_cop()
{
   {
      cvoid_t new1528_1321;
      new1528_1321 = ((cvoid_t) BREF(GC_MALLOC(sizeof(struct cvoid))));
      {
	 long arg2211_1322;
	 arg2211_1322 = class_num_218___object(cvoid_cgen_cop);
	 {
	    obj_t obj_2559;
	    obj_2559 = (obj_t) (new1528_1321);
	    (((obj_t) CREF(obj_2559))->header = MAKE_HEADER(arg2211_1322, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5132;
	 aux_5132 = (object_t) (new1528_1321);
	 OBJECT_WIDENING_SET(aux_5132, BFALSE);
      }
      return new1528_1321;
   }
}


/* _allocate-cvoid */ obj_t 
_allocate_cvoid_169_cgen_cop(obj_t env_3308)
{
   {
      cvoid_t aux_5135;
      aux_5135 = allocate_cvoid_159_cgen_cop();
      return (obj_t) (aux_5135);
   }
}


/* cvoid? */ bool_t 
cvoid__191_cgen_cop(obj_t obj_304)
{
   return is_a__118___object(obj_304, cvoid_cgen_cop);
}


/* _cvoid? */ obj_t 
_cvoid__92_cgen_cop(obj_t env_3715, obj_t obj_3716)
{
   {
      bool_t aux_5139;
      aux_5139 = cvoid__191_cgen_cop(obj_3716);
      return BBOOL(aux_5139);
   }
}


/* make-cvoid */ cvoid_t 
make_cvoid_194_cgen_cop(obj_t loc_305, cop_t value_306)
{
   {
      cvoid_t new1523_2561;
      new1523_2561 = ((cvoid_t) BREF(GC_MALLOC(sizeof(struct cvoid))));
      {
	 long arg2213_2562;
	 arg2213_2562 = class_num_218___object(cvoid_cgen_cop);
	 {
	    obj_t obj_2565;
	    obj_2565 = (obj_t) (new1523_2561);
	    (((obj_t) CREF(obj_2565))->header = MAKE_HEADER(arg2213_2562, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5146;
	 aux_5146 = (object_t) (new1523_2561);
	 OBJECT_WIDENING_SET(aux_5146, BFALSE);
      }
      ((((cvoid_t) CREF(new1523_2561))->loc) = ((obj_t) loc_305), BUNSPEC);
      ((((cvoid_t) CREF(new1523_2561))->value) = ((cop_t) value_306), BUNSPEC);
      return new1523_2561;
   }
}


/* _make-cvoid2751 */ obj_t 
_make_cvoid2751_4_cgen_cop(obj_t env_3717, obj_t loc_3718, obj_t value_3719)
{
   {
      cvoid_t aux_5151;
      aux_5151 = make_cvoid_194_cgen_cop(loc_3718, (cop_t) (value_3719));
      return (obj_t) (aux_5151);
   }
}


/* cvoid-loc-set! */ obj_t 
cvoid_loc_set__124_cgen_cop(cvoid_t obj_307, obj_t val1527_308)
{
   return ((((cvoid_t) CREF(obj_307))->loc) = ((obj_t) val1527_308), BUNSPEC);
}


/* _cvoid-loc-set!2752 */ obj_t 
_cvoid_loc_set_2752_198_cgen_cop(obj_t env_3720, obj_t obj_3721, obj_t val1527_3722)
{
   return cvoid_loc_set__124_cgen_cop((cvoid_t) (obj_3721), val1527_3722);
}


/* cvoid-loc */ obj_t 
cvoid_loc_83_cgen_cop(cvoid_t obj_309)
{
   return (((cvoid_t) CREF(obj_309))->loc);
}


/* _cvoid-loc2753 */ obj_t 
_cvoid_loc2753_0_cgen_cop(obj_t env_3723, obj_t obj_3724)
{
   return cvoid_loc_83_cgen_cop((cvoid_t) (obj_3724));
}


/* cvoid-value */ cop_t 
cvoid_value_152_cgen_cop(cvoid_t obj_310)
{
   return (((cvoid_t) CREF(obj_310))->value);
}


/* _cvoid-value2754 */ obj_t 
_cvoid_value2754_28_cgen_cop(obj_t env_3725, obj_t obj_3726)
{
   {
      cop_t aux_5162;
      aux_5162 = cvoid_value_152_cgen_cop((cvoid_t) (obj_3726));
      return (obj_t) (aux_5162);
   }
}


/* allocate-creturn */ creturn_t 
allocate_creturn_170_cgen_cop()
{
   {
      creturn_t new1512_1327;
      new1512_1327 = ((creturn_t) BREF(GC_MALLOC(sizeof(struct creturn))));
      {
	 long arg2214_1328;
	 arg2214_1328 = class_num_218___object(creturn_cgen_cop);
	 {
	    obj_t obj_2567;
	    obj_2567 = (obj_t) (new1512_1327);
	    (((obj_t) CREF(obj_2567))->header = MAKE_HEADER(arg2214_1328, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5170;
	 aux_5170 = (object_t) (new1512_1327);
	 OBJECT_WIDENING_SET(aux_5170, BFALSE);
      }
      return new1512_1327;
   }
}


/* _allocate-creturn */ obj_t 
_allocate_creturn_205_cgen_cop(obj_t env_3307)
{
   {
      creturn_t aux_5173;
      aux_5173 = allocate_creturn_170_cgen_cop();
      return (obj_t) (aux_5173);
   }
}


/* creturn? */ bool_t 
creturn__207_cgen_cop(obj_t obj_314)
{
   return is_a__118___object(obj_314, creturn_cgen_cop);
}


/* _creturn? */ obj_t 
_creturn__112_cgen_cop(obj_t env_3727, obj_t obj_3728)
{
   {
      bool_t aux_5177;
      aux_5177 = creturn__207_cgen_cop(obj_3728);
      return BBOOL(aux_5177);
   }
}


/* make-creturn */ creturn_t 
make_creturn_204_cgen_cop(obj_t loc_315, cop_t value_316)
{
   {
      creturn_t new1507_2569;
      new1507_2569 = ((creturn_t) BREF(GC_MALLOC(sizeof(struct creturn))));
      {
	 long arg2215_2570;
	 arg2215_2570 = class_num_218___object(creturn_cgen_cop);
	 {
	    obj_t obj_2573;
	    obj_2573 = (obj_t) (new1507_2569);
	    (((obj_t) CREF(obj_2573))->header = MAKE_HEADER(arg2215_2570, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5184;
	 aux_5184 = (object_t) (new1507_2569);
	 OBJECT_WIDENING_SET(aux_5184, BFALSE);
      }
      ((((creturn_t) CREF(new1507_2569))->loc) = ((obj_t) loc_315), BUNSPEC);
      ((((creturn_t) CREF(new1507_2569))->value) = ((cop_t) value_316), BUNSPEC);
      return new1507_2569;
   }
}


/* _make-creturn2755 */ obj_t 
_make_creturn2755_253_cgen_cop(obj_t env_3729, obj_t loc_3730, obj_t value_3731)
{
   {
      creturn_t aux_5189;
      aux_5189 = make_creturn_204_cgen_cop(loc_3730, (cop_t) (value_3731));
      return (obj_t) (aux_5189);
   }
}


/* creturn-loc-set! */ obj_t 
creturn_loc_set__24_cgen_cop(creturn_t obj_317, obj_t val1511_318)
{
   return ((((creturn_t) CREF(obj_317))->loc) = ((obj_t) val1511_318), BUNSPEC);
}


/* _creturn-loc-set!2756 */ obj_t 
_creturn_loc_set_2756_44_cgen_cop(obj_t env_3732, obj_t obj_3733, obj_t val1511_3734)
{
   return creturn_loc_set__24_cgen_cop((creturn_t) (obj_3733), val1511_3734);
}


/* creturn-loc */ obj_t 
creturn_loc_120_cgen_cop(creturn_t obj_319)
{
   return (((creturn_t) CREF(obj_319))->loc);
}


/* _creturn-loc2757 */ obj_t 
_creturn_loc2757_219_cgen_cop(obj_t env_3735, obj_t obj_3736)
{
   return creturn_loc_120_cgen_cop((creturn_t) (obj_3736));
}


/* creturn-value */ cop_t 
creturn_value_251_cgen_cop(creturn_t obj_320)
{
   return (((creturn_t) CREF(obj_320))->value);
}


/* _creturn-value2758 */ obj_t 
_creturn_value2758_124_cgen_cop(obj_t env_3737, obj_t obj_3738)
{
   {
      cop_t aux_5200;
      aux_5200 = creturn_value_251_cgen_cop((creturn_t) (obj_3738));
      return (obj_t) (aux_5200);
   }
}


/* allocate-block */ block_t 
allocate_block_20_cgen_cop()
{
   {
      block_t new1496_1333;
      new1496_1333 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
      {
	 long arg2216_1334;
	 arg2216_1334 = class_num_218___object(block_cgen_cop);
	 {
	    obj_t obj_2575;
	    obj_2575 = (obj_t) (new1496_1333);
	    (((obj_t) CREF(obj_2575))->header = MAKE_HEADER(arg2216_1334, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5208;
	 aux_5208 = (object_t) (new1496_1333);
	 OBJECT_WIDENING_SET(aux_5208, BFALSE);
      }
      return new1496_1333;
   }
}


/* _allocate-block */ obj_t 
_allocate_block_150_cgen_cop(obj_t env_3306)
{
   {
      block_t aux_5211;
      aux_5211 = allocate_block_20_cgen_cop();
      return (obj_t) (aux_5211);
   }
}


/* block? */ bool_t 
block__82_cgen_cop(obj_t obj_324)
{
   return is_a__118___object(obj_324, block_cgen_cop);
}


/* _block? */ obj_t 
_block__12_cgen_cop(obj_t env_3739, obj_t obj_3740)
{
   {
      bool_t aux_5215;
      aux_5215 = block__82_cgen_cop(obj_3740);
      return BBOOL(aux_5215);
   }
}


/* make-block */ block_t 
make_block_156_cgen_cop(obj_t loc_325, cop_t body_326)
{
   {
      block_t new1491_2577;
      new1491_2577 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
      {
	 long arg2217_2578;
	 arg2217_2578 = class_num_218___object(block_cgen_cop);
	 {
	    obj_t obj_2581;
	    obj_2581 = (obj_t) (new1491_2577);
	    (((obj_t) CREF(obj_2581))->header = MAKE_HEADER(arg2217_2578, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5222;
	 aux_5222 = (object_t) (new1491_2577);
	 OBJECT_WIDENING_SET(aux_5222, BFALSE);
      }
      ((((block_t) CREF(new1491_2577))->loc) = ((obj_t) loc_325), BUNSPEC);
      ((((block_t) CREF(new1491_2577))->body) = ((cop_t) body_326), BUNSPEC);
      return new1491_2577;
   }
}


/* _make-block2759 */ obj_t 
_make_block2759_147_cgen_cop(obj_t env_3741, obj_t loc_3742, obj_t body_3743)
{
   {
      block_t aux_5227;
      aux_5227 = make_block_156_cgen_cop(loc_3742, (cop_t) (body_3743));
      return (obj_t) (aux_5227);
   }
}


/* block-loc-set! */ obj_t 
block_loc_set__28_cgen_cop(block_t obj_327, obj_t val1495_328)
{
   return ((((block_t) CREF(obj_327))->loc) = ((obj_t) val1495_328), BUNSPEC);
}


/* _block-loc-set!2760 */ obj_t 
_block_loc_set_2760_160_cgen_cop(obj_t env_3744, obj_t obj_3745, obj_t val1495_3746)
{
   return block_loc_set__28_cgen_cop((block_t) (obj_3745), val1495_3746);
}


/* block-loc */ obj_t 
block_loc_240_cgen_cop(block_t obj_329)
{
   return (((block_t) CREF(obj_329))->loc);
}


/* _block-loc2761 */ obj_t 
_block_loc2761_12_cgen_cop(obj_t env_3747, obj_t obj_3748)
{
   return block_loc_240_cgen_cop((block_t) (obj_3748));
}


/* block-body */ cop_t 
block_body_21_cgen_cop(block_t obj_330)
{
   return (((block_t) CREF(obj_330))->body);
}


/* _block-body2762 */ obj_t 
_block_body2762_237_cgen_cop(obj_t env_3749, obj_t obj_3750)
{
   {
      cop_t aux_5238;
      aux_5238 = block_body_21_cgen_cop((block_t) (obj_3750));
      return (obj_t) (aux_5238);
   }
}


/* allocate-cgoto */ cgoto_t 
allocate_cgoto_58_cgen_cop()
{
   {
      cgoto_t new1480_1339;
      new1480_1339 = ((cgoto_t) BREF(GC_MALLOC(sizeof(struct cgoto))));
      {
	 long arg2219_1340;
	 arg2219_1340 = class_num_218___object(cgoto_cgen_cop);
	 {
	    obj_t obj_2583;
	    obj_2583 = (obj_t) (new1480_1339);
	    (((obj_t) CREF(obj_2583))->header = MAKE_HEADER(arg2219_1340, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5246;
	 aux_5246 = (object_t) (new1480_1339);
	 OBJECT_WIDENING_SET(aux_5246, BFALSE);
      }
      return new1480_1339;
   }
}


/* _allocate-cgoto */ obj_t 
_allocate_cgoto_159_cgen_cop(obj_t env_3305)
{
   {
      cgoto_t aux_5249;
      aux_5249 = allocate_cgoto_58_cgen_cop();
      return (obj_t) (aux_5249);
   }
}


/* cgoto? */ bool_t 
cgoto__160_cgen_cop(obj_t obj_334)
{
   return is_a__118___object(obj_334, cgoto_cgen_cop);
}


/* _cgoto? */ obj_t 
_cgoto__255_cgen_cop(obj_t env_3751, obj_t obj_3752)
{
   {
      bool_t aux_5253;
      aux_5253 = cgoto__160_cgen_cop(obj_3752);
      return BBOOL(aux_5253);
   }
}


/* make-cgoto */ cgoto_t 
make_cgoto_92_cgen_cop(obj_t loc_335, clabel_t label_336)
{
   {
      cgoto_t new1475_2585;
      new1475_2585 = ((cgoto_t) BREF(GC_MALLOC(sizeof(struct cgoto))));
      {
	 long arg2220_2586;
	 arg2220_2586 = class_num_218___object(cgoto_cgen_cop);
	 {
	    obj_t obj_2589;
	    obj_2589 = (obj_t) (new1475_2585);
	    (((obj_t) CREF(obj_2589))->header = MAKE_HEADER(arg2220_2586, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5260;
	 aux_5260 = (object_t) (new1475_2585);
	 OBJECT_WIDENING_SET(aux_5260, BFALSE);
      }
      ((((cgoto_t) CREF(new1475_2585))->loc) = ((obj_t) loc_335), BUNSPEC);
      ((((cgoto_t) CREF(new1475_2585))->label) = ((clabel_t) label_336), BUNSPEC);
      return new1475_2585;
   }
}


/* _make-cgoto2763 */ obj_t 
_make_cgoto2763_123_cgen_cop(obj_t env_3753, obj_t loc_3754, obj_t label_3755)
{
   {
      cgoto_t aux_5265;
      aux_5265 = make_cgoto_92_cgen_cop(loc_3754, (clabel_t) (label_3755));
      return (obj_t) (aux_5265);
   }
}


/* cgoto-loc-set! */ obj_t 
cgoto_loc_set__54_cgen_cop(cgoto_t obj_337, obj_t val1479_338)
{
   return ((((cgoto_t) CREF(obj_337))->loc) = ((obj_t) val1479_338), BUNSPEC);
}


/* _cgoto-loc-set!2764 */ obj_t 
_cgoto_loc_set_2764_203_cgen_cop(obj_t env_3756, obj_t obj_3757, obj_t val1479_3758)
{
   return cgoto_loc_set__54_cgen_cop((cgoto_t) (obj_3757), val1479_3758);
}


/* cgoto-loc */ obj_t 
cgoto_loc_231_cgen_cop(cgoto_t obj_339)
{
   return (((cgoto_t) CREF(obj_339))->loc);
}


/* _cgoto-loc2765 */ obj_t 
_cgoto_loc2765_49_cgen_cop(obj_t env_3759, obj_t obj_3760)
{
   return cgoto_loc_231_cgen_cop((cgoto_t) (obj_3760));
}


/* cgoto-label */ clabel_t 
cgoto_label_241_cgen_cop(cgoto_t obj_340)
{
   return (((cgoto_t) CREF(obj_340))->label);
}


/* _cgoto-label2766 */ obj_t 
_cgoto_label2766_60_cgen_cop(obj_t env_3761, obj_t obj_3762)
{
   {
      clabel_t aux_5276;
      aux_5276 = cgoto_label_241_cgen_cop((cgoto_t) (obj_3762));
      return (obj_t) (aux_5276);
   }
}


/* allocate-clabel */ clabel_t 
allocate_clabel_48_cgen_cop()
{
   {
      clabel_t new1456_1345;
      new1456_1345 = ((clabel_t) BREF(GC_MALLOC(sizeof(struct clabel))));
      {
	 long arg2221_1346;
	 arg2221_1346 = class_num_218___object(clabel_cgen_cop);
	 {
	    obj_t obj_2591;
	    obj_2591 = (obj_t) (new1456_1345);
	    (((obj_t) CREF(obj_2591))->header = MAKE_HEADER(arg2221_1346, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5284;
	 aux_5284 = (object_t) (new1456_1345);
	 OBJECT_WIDENING_SET(aux_5284, BFALSE);
      }
      return new1456_1345;
   }
}


/* _allocate-clabel */ obj_t 
_allocate_clabel_4_cgen_cop(obj_t env_3304)
{
   {
      clabel_t aux_5287;
      aux_5287 = allocate_clabel_48_cgen_cop();
      return (obj_t) (aux_5287);
   }
}


/* clabel? */ bool_t 
clabel__247_cgen_cop(obj_t obj_344)
{
   return is_a__118___object(obj_344, clabel_cgen_cop);
}


/* _clabel? */ obj_t 
_clabel__209_cgen_cop(obj_t env_3763, obj_t obj_3764)
{
   {
      bool_t aux_5291;
      aux_5291 = clabel__247_cgen_cop(obj_3764);
      return BBOOL(aux_5291);
   }
}


/* make-clabel */ clabel_t 
make_clabel_15_cgen_cop(obj_t loc_345, obj_t name_346, bool_t used__226_347, obj_t body_348)
{
   {
      clabel_t new1447_2593;
      new1447_2593 = ((clabel_t) BREF(GC_MALLOC(sizeof(struct clabel))));
      {
	 long arg2222_2594;
	 arg2222_2594 = class_num_218___object(clabel_cgen_cop);
	 {
	    obj_t obj_2599;
	    obj_2599 = (obj_t) (new1447_2593);
	    (((obj_t) CREF(obj_2599))->header = MAKE_HEADER(arg2222_2594, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5298;
	 aux_5298 = (object_t) (new1447_2593);
	 OBJECT_WIDENING_SET(aux_5298, BFALSE);
      }
      ((((clabel_t) CREF(new1447_2593))->loc) = ((obj_t) loc_345), BUNSPEC);
      ((((clabel_t) CREF(new1447_2593))->name) = ((obj_t) name_346), BUNSPEC);
      ((((clabel_t) CREF(new1447_2593))->used__226) = ((bool_t) used__226_347), BUNSPEC);
      ((((clabel_t) CREF(new1447_2593))->body) = ((obj_t) body_348), BUNSPEC);
      return new1447_2593;
   }
}


/* _make-clabel2767 */ obj_t 
_make_clabel2767_36_cgen_cop(obj_t env_3765, obj_t loc_3766, obj_t name_3767, obj_t used__226_3768, obj_t body_3769)
{
   {
      clabel_t aux_5305;
      aux_5305 = make_clabel_15_cgen_cop(loc_3766, name_3767, CBOOL(used__226_3768), body_3769);
      return (obj_t) (aux_5305);
   }
}


/* clabel-loc-set! */ obj_t 
clabel_loc_set__72_cgen_cop(clabel_t obj_349, obj_t val1453_350)
{
   return ((((clabel_t) CREF(obj_349))->loc) = ((obj_t) val1453_350), BUNSPEC);
}


/* _clabel-loc-set!2768 */ obj_t 
_clabel_loc_set_2768_200_cgen_cop(obj_t env_3770, obj_t obj_3771, obj_t val1453_3772)
{
   return clabel_loc_set__72_cgen_cop((clabel_t) (obj_3771), val1453_3772);
}


/* clabel-loc */ obj_t 
clabel_loc_12_cgen_cop(clabel_t obj_351)
{
   return (((clabel_t) CREF(obj_351))->loc);
}


/* _clabel-loc2769 */ obj_t 
_clabel_loc2769_184_cgen_cop(obj_t env_3773, obj_t obj_3774)
{
   return clabel_loc_12_cgen_cop((clabel_t) (obj_3774));
}


/* clabel-name */ obj_t 
clabel_name_59_cgen_cop(clabel_t obj_352)
{
   return (((clabel_t) CREF(obj_352))->name);
}


/* _clabel-name2770 */ obj_t 
_clabel_name2770_181_cgen_cop(obj_t env_3775, obj_t obj_3776)
{
   return clabel_name_59_cgen_cop((clabel_t) (obj_3776));
}


/* clabel-used?-set! */ obj_t 
clabel_used__set__46_cgen_cop(clabel_t obj_353, bool_t val1454_354)
{
   return ((((clabel_t) CREF(obj_353))->used__226) = ((bool_t) val1454_354), BUNSPEC);
}


/* _clabel-used?-set!2771 */ obj_t 
_clabel_used__set_2771_82_cgen_cop(obj_t env_3777, obj_t obj_3778, obj_t val1454_3779)
{
   return clabel_used__set__46_cgen_cop((clabel_t) (obj_3778), CBOOL(val1454_3779));
}


/* clabel-used? */ bool_t 
clabel_used__102_cgen_cop(clabel_t obj_355)
{
   return (((clabel_t) CREF(obj_355))->used__226);
}


/* _clabel-used?2772 */ obj_t 
_clabel_used_2772_222_cgen_cop(obj_t env_3780, obj_t obj_3781)
{
   {
      bool_t aux_5323;
      aux_5323 = clabel_used__102_cgen_cop((clabel_t) (obj_3781));
      return BBOOL(aux_5323);
   }
}


/* clabel-body-set! */ obj_t 
clabel_body_set__90_cgen_cop(clabel_t obj_356, obj_t val1455_357)
{
   return ((((clabel_t) CREF(obj_356))->body) = ((obj_t) val1455_357), BUNSPEC);
}


/* _clabel-body-set!2773 */ obj_t 
_clabel_body_set_2773_235_cgen_cop(obj_t env_3782, obj_t obj_3783, obj_t val1455_3784)
{
   return clabel_body_set__90_cgen_cop((clabel_t) (obj_3783), val1455_3784);
}


/* clabel-body */ obj_t 
clabel_body_114_cgen_cop(clabel_t obj_358)
{
   return (((clabel_t) CREF(obj_358))->body);
}


/* _clabel-body2774 */ obj_t 
_clabel_body2774_177_cgen_cop(obj_t env_3785, obj_t obj_3786)
{
   return clabel_body_114_cgen_cop((clabel_t) (obj_3786));
}


/* allocate-cop */ cop_t 
allocate_cop_141_cgen_cop()
{
   {
      cop_t new1440_1353;
      new1440_1353 = ((cop_t) BREF(GC_MALLOC(sizeof(struct cop))));
      {
	 long arg2223_1354;
	 arg2223_1354 = class_num_218___object(cop_cgen_cop);
	 {
	    obj_t obj_2601;
	    obj_2601 = (obj_t) (new1440_1353);
	    (((obj_t) CREF(obj_2601))->header = MAKE_HEADER(arg2223_1354, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5337;
	 aux_5337 = (object_t) (new1440_1353);
	 OBJECT_WIDENING_SET(aux_5337, BFALSE);
      }
      return new1440_1353;
   }
}


/* _allocate-cop */ obj_t 
_allocate_cop_129_cgen_cop(obj_t env_3303)
{
   {
      cop_t aux_5340;
      aux_5340 = allocate_cop_141_cgen_cop();
      return (obj_t) (aux_5340);
   }
}


/* cop? */ bool_t 
cop__160_cgen_cop(obj_t obj_362)
{
   return is_a__118___object(obj_362, cop_cgen_cop);
}


/* _cop? */ obj_t 
_cop__234_cgen_cop(obj_t env_3787, obj_t obj_3788)
{
   {
      bool_t aux_5344;
      aux_5344 = cop__160_cgen_cop(obj_3788);
      return BBOOL(aux_5344);
   }
}


/* make-cop */ cop_t 
make_cop_70_cgen_cop(obj_t loc_363)
{
   {
      cop_t new1436_2603;
      new1436_2603 = ((cop_t) BREF(GC_MALLOC(sizeof(struct cop))));
      {
	 long arg2224_2604;
	 arg2224_2604 = class_num_218___object(cop_cgen_cop);
	 {
	    obj_t obj_2606;
	    obj_2606 = (obj_t) (new1436_2603);
	    (((obj_t) CREF(obj_2606))->header = MAKE_HEADER(arg2224_2604, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5351;
	 aux_5351 = (object_t) (new1436_2603);
	 OBJECT_WIDENING_SET(aux_5351, BFALSE);
      }
      ((((cop_t) CREF(new1436_2603))->loc) = ((obj_t) loc_363), BUNSPEC);
      return new1436_2603;
   }
}


/* _make-cop */ obj_t 
_make_cop_194_cgen_cop(obj_t env_3789, obj_t loc_3790)
{
   {
      cop_t aux_5355;
      aux_5355 = make_cop_70_cgen_cop(loc_3790);
      return (obj_t) (aux_5355);
   }
}


/* cop-loc-set! */ obj_t 
cop_loc_set__54_cgen_cop(cop_t obj_364, obj_t val1439_365)
{
   return ((((cop_t) CREF(obj_364))->loc) = ((obj_t) val1439_365), BUNSPEC);
}


/* _cop-loc-set!2775 */ obj_t 
_cop_loc_set_2775_219_cgen_cop(obj_t env_3791, obj_t obj_3792, obj_t val1439_3793)
{
   return cop_loc_set__54_cgen_cop((cop_t) (obj_3792), val1439_3793);
}


/* cop-loc */ obj_t 
cop_loc_231_cgen_cop(cop_t obj_366)
{
   return (((cop_t) CREF(obj_366))->loc);
}


/* _cop-loc2776 */ obj_t 
_cop_loc2776_142_cgen_cop(obj_t env_3794, obj_t obj_3795)
{
   return cop_loc_231_cgen_cop((cop_t) (obj_3795));
}


/* method-init */ obj_t 
method_init_76_cgen_cop()
{
   {
      obj_t object__struct_bdb_block_145_3856;
      object__struct_bdb_block_145_3856 = proc2782_cgen_cop;
      add_method__1___object(object__struct_env_210___object, bdb_block_21_cgen_cop, object__struct_bdb_block_145_3856);
   }
   {
      obj_t struct_object__object_bdb_block_117_3855;
      struct_object__object_bdb_block_117_3855 = proc2783_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, bdb_block_21_cgen_cop, struct_object__object_bdb_block_117_3855);
   }
   {
      obj_t object__struct_sfun_c_73_3852;
      object__struct_sfun_c_73_3852 = proc2784_cgen_cop;
      add_method__1___object(object__struct_env_210___object, sfun_c_188_cgen_cop, object__struct_sfun_c_73_3852);
   }
   {
      obj_t struct_object__object_sfun_c_84_3848;
      struct_object__object_sfun_c_84_3848 = proc2785_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, sfun_c_188_cgen_cop, struct_object__object_sfun_c_84_3848);
   }
   {
      obj_t object__struct_cjump_ex_it_155_3847;
      object__struct_cjump_ex_it_155_3847 = proc2786_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cjump_ex_it_131_cgen_cop, object__struct_cjump_ex_it_155_3847);
   }
   {
      obj_t struct_object__object_cjump_ex_it_93_3846;
      struct_object__object_cjump_ex_it_93_3846 = proc2787_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cjump_ex_it_131_cgen_cop, struct_object__object_cjump_ex_it_93_3846);
   }
   {
      obj_t object__struct_cset_ex_it_165_3845;
      object__struct_cset_ex_it_165_3845 = proc2788_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cset_ex_it_123_cgen_cop, object__struct_cset_ex_it_165_3845);
   }
   {
      obj_t struct_object__object_cset_ex_it_17_3844;
      struct_object__object_cset_ex_it_17_3844 = proc2789_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cset_ex_it_123_cgen_cop, struct_object__object_cset_ex_it_17_3844);
   }
   {
      obj_t object__struct_cbox_set__79_3843;
      object__struct_cbox_set__79_3843 = proc2790_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cbox_set__132_cgen_cop, object__struct_cbox_set__79_3843);
   }
   {
      obj_t struct_object__object_cbox_set__145_3842;
      struct_object__object_cbox_set__145_3842 = proc2791_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cbox_set__132_cgen_cop, struct_object__object_cbox_set__145_3842);
   }
   {
      obj_t object__struct_cbox_ref_102_3841;
      object__struct_cbox_ref_102_3841 = proc2792_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cbox_ref_44_cgen_cop, object__struct_cbox_ref_102_3841);
   }
   {
      obj_t struct_object__object_cbox_ref_164_3840;
      struct_object__object_cbox_ref_164_3840 = proc2793_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cbox_ref_44_cgen_cop, struct_object__object_cbox_ref_164_3840);
   }
   {
      obj_t object__struct_cmake_box_32_3839;
      object__struct_cmake_box_32_3839 = proc2794_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cmake_box_177_cgen_cop, object__struct_cmake_box_32_3839);
   }
   {
      obj_t struct_object__object_cmake_box_25_3838;
      struct_object__object_cmake_box_25_3838 = proc2795_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cmake_box_177_cgen_cop, struct_object__object_cmake_box_25_3838);
   }
   {
      obj_t object__struct_cswitch_161_3837;
      object__struct_cswitch_161_3837 = proc2796_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cswitch_cgen_cop, object__struct_cswitch_161_3837);
   }
   {
      obj_t struct_object__object_cswitch_246_3836;
      struct_object__object_cswitch_246_3836 = proc2797_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cswitch_cgen_cop, struct_object__object_cswitch_246_3836);
   }
   {
      obj_t object__struct_cfail_230_3835;
      object__struct_cfail_230_3835 = proc2798_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cfail_cgen_cop, object__struct_cfail_230_3835);
   }
   {
      obj_t struct_object__object_cfail_119_3834;
      struct_object__object_cfail_119_3834 = proc2799_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cfail_cgen_cop, struct_object__object_cfail_119_3834);
   }
   {
      obj_t object__struct_capp_230_3833;
      object__struct_capp_230_3833 = proc2800_cgen_cop;
      add_method__1___object(object__struct_env_210___object, capp_cgen_cop, object__struct_capp_230_3833);
   }
   {
      obj_t struct_object__object_capp_36_3832;
      struct_object__object_capp_36_3832 = proc2801_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, capp_cgen_cop, struct_object__object_capp_36_3832);
   }
   {
      obj_t object__struct_capply_87_3831;
      object__struct_capply_87_3831 = proc2802_cgen_cop;
      add_method__1___object(object__struct_env_210___object, capply_cgen_cop, object__struct_capply_87_3831);
   }
   {
      obj_t struct_object__object_capply_0_3830;
      struct_object__object_capply_0_3830 = proc2803_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, capply_cgen_cop, struct_object__object_capply_0_3830);
   }
   {
      obj_t object__struct_cfuncall_147_3829;
      object__struct_cfuncall_147_3829 = proc2804_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cfuncall_cgen_cop, object__struct_cfuncall_147_3829);
   }
   {
      obj_t struct_object__object_cfuncall_72_3828;
      struct_object__object_cfuncall_72_3828 = proc2805_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cfuncall_cgen_cop, struct_object__object_cfuncall_72_3828);
   }
   {
      obj_t object__struct_local_var_3_3827;
      object__struct_local_var_3_3827 = proc2806_cgen_cop;
      add_method__1___object(object__struct_env_210___object, local_var_164_cgen_cop, object__struct_local_var_3_3827);
   }
   {
      obj_t struct_object__object_local_var_195_3826;
      struct_object__object_local_var_195_3826 = proc2807_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, local_var_164_cgen_cop, struct_object__object_local_var_195_3826);
   }
   {
      obj_t object__struct_cif_61_3825;
      object__struct_cif_61_3825 = proc2808_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cif_cgen_cop, object__struct_cif_61_3825);
   }
   {
      obj_t struct_object__object_cif_118_3824;
      struct_object__object_cif_118_3824 = proc2809_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cif_cgen_cop, struct_object__object_cif_118_3824);
   }
   {
      obj_t object__struct_csetq_144_3823;
      object__struct_csetq_144_3823 = proc2810_cgen_cop;
      add_method__1___object(object__struct_env_210___object, csetq_cgen_cop, object__struct_csetq_144_3823);
   }
   {
      obj_t struct_object__object_csetq_16_3822;
      struct_object__object_csetq_16_3822 = proc2811_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, csetq_cgen_cop, struct_object__object_csetq_16_3822);
   }
   {
      obj_t object__struct_stop_197_3821;
      object__struct_stop_197_3821 = proc2812_cgen_cop;
      add_method__1___object(object__struct_env_210___object, stop_cgen_cop, object__struct_stop_197_3821);
   }
   {
      obj_t struct_object__object_stop_60_3820;
      struct_object__object_stop_60_3820 = proc2813_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, stop_cgen_cop, struct_object__object_stop_60_3820);
   }
   {
      obj_t object__struct_nop_253_3819;
      object__struct_nop_253_3819 = proc2814_cgen_cop;
      add_method__1___object(object__struct_env_210___object, nop_cgen_cop, object__struct_nop_253_3819);
   }
   {
      obj_t struct_object__object_nop_31_3818;
      struct_object__object_nop_31_3818 = proc2815_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, nop_cgen_cop, struct_object__object_nop_31_3818);
   }
   {
      obj_t object__struct_csequence_69_3817;
      object__struct_csequence_69_3817 = proc2816_cgen_cop;
      add_method__1___object(object__struct_env_210___object, csequence_cgen_cop, object__struct_csequence_69_3817);
   }
   {
      obj_t struct_object__object_csequence_144_3816;
      struct_object__object_csequence_144_3816 = proc2817_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, csequence_cgen_cop, struct_object__object_csequence_144_3816);
   }
   {
      obj_t object__struct_ccast_238_3815;
      object__struct_ccast_238_3815 = proc2818_cgen_cop;
      add_method__1___object(object__struct_env_210___object, ccast_cgen_cop, object__struct_ccast_238_3815);
   }
   {
      obj_t struct_object__object_ccast_65_3814;
      struct_object__object_ccast_65_3814 = proc2819_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, ccast_cgen_cop, struct_object__object_ccast_65_3814);
   }
   {
      obj_t object__struct_cpragma_233_3813;
      object__struct_cpragma_233_3813 = proc2820_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cpragma_cgen_cop, object__struct_cpragma_233_3813);
   }
   {
      obj_t struct_object__object_cpragma_169_3812;
      struct_object__object_cpragma_169_3812 = proc2821_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cpragma_cgen_cop, struct_object__object_cpragma_169_3812);
   }
   {
      obj_t object__struct_varc_203_3811;
      object__struct_varc_203_3811 = proc2822_cgen_cop;
      add_method__1___object(object__struct_env_210___object, varc_cgen_cop, object__struct_varc_203_3811);
   }
   {
      obj_t struct_object__object_varc_23_3810;
      struct_object__object_varc_23_3810 = proc2823_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, varc_cgen_cop, struct_object__object_varc_23_3810);
   }
   {
      obj_t object__struct_catom_180_3809;
      object__struct_catom_180_3809 = proc2824_cgen_cop;
      add_method__1___object(object__struct_env_210___object, catom_cgen_cop, object__struct_catom_180_3809);
   }
   {
      obj_t struct_object__object_catom_48_3808;
      struct_object__object_catom_48_3808 = proc2825_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, catom_cgen_cop, struct_object__object_catom_48_3808);
   }
   {
      obj_t object__struct_cvoid_78_3807;
      object__struct_cvoid_78_3807 = proc2826_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cvoid_cgen_cop, object__struct_cvoid_78_3807);
   }
   {
      obj_t struct_object__object_cvoid_49_3806;
      struct_object__object_cvoid_49_3806 = proc2827_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cvoid_cgen_cop, struct_object__object_cvoid_49_3806);
   }
   {
      obj_t object__struct_creturn_165_3805;
      object__struct_creturn_165_3805 = proc2828_cgen_cop;
      add_method__1___object(object__struct_env_210___object, creturn_cgen_cop, object__struct_creturn_165_3805);
   }
   {
      obj_t struct_object__object_creturn_28_3804;
      struct_object__object_creturn_28_3804 = proc2829_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, creturn_cgen_cop, struct_object__object_creturn_28_3804);
   }
   {
      obj_t object__struct_block_53_3803;
      object__struct_block_53_3803 = proc2830_cgen_cop;
      add_method__1___object(object__struct_env_210___object, block_cgen_cop, object__struct_block_53_3803);
   }
   {
      obj_t struct_object__object_block_188_3802;
      struct_object__object_block_188_3802 = proc2831_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, block_cgen_cop, struct_object__object_block_188_3802);
   }
   {
      obj_t object__struct_cgoto_44_3801;
      object__struct_cgoto_44_3801 = proc2832_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cgoto_cgen_cop, object__struct_cgoto_44_3801);
   }
   {
      obj_t struct_object__object_cgoto_101_3800;
      struct_object__object_cgoto_101_3800 = proc2833_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, cgoto_cgen_cop, struct_object__object_cgoto_101_3800);
   }
   {
      obj_t object__struct_clabel_136_3799;
      object__struct_clabel_136_3799 = proc2834_cgen_cop;
      add_method__1___object(object__struct_env_210___object, clabel_cgen_cop, object__struct_clabel_136_3799);
   }
   {
      obj_t struct_object__object_clabel_24_3798;
      struct_object__object_clabel_24_3798 = proc2835_cgen_cop;
      add_method__1___object(struct_object__object_env_209___object, clabel_cgen_cop, struct_object__object_clabel_24_3798);
   }
   {
      obj_t object__struct_cop_119_3797;
      object__struct_cop_119_3797 = proc2836_cgen_cop;
      add_method__1___object(object__struct_env_210___object, cop_cgen_cop, object__struct_cop_119_3797);
   }
   {
      obj_t struct_object__object_cop_66_3796;
      struct_object__object_cop_66_3796 = proc2837_cgen_cop;
      return add_method__1___object(struct_object__object_env_209___object, cop_cgen_cop, struct_object__object_cop_66_3796);
   }
}


/* struct+object->object-cop */ obj_t 
struct_object__object_cop_66_cgen_cop(obj_t env_3857, obj_t o_3858, obj_t s_3859)
{
   {
      cop_t o_2321;
      obj_t s_2322;
      {
	 cop_t aux_5420;
	 o_2321 = (cop_t) (o_3858);
	 s_2322 = s_3859;
	 {
	    obj_t aux_5423;
	    object_t aux_5421;
	    aux_5423 = STRUCT_REF(s_2322, ((long) 0));
	    aux_5421 = (object_t) (o_2321);
	    OBJECT_WIDENING_SET(aux_5421, aux_5423);
	 }
	 {
	    obj_t v1445_2326;
	    v1445_2326 = STRUCT_REF(s_2322, ((long) 1));
	    ((((cop_t) CREF(o_2321))->loc) = ((obj_t) v1445_2326), BUNSPEC);
	 }
	 aux_5420 = o_2321;
	 return (obj_t) (aux_5420);
      }
   }
}


/* object->struct-cop */ obj_t 
object__struct_cop_119_cgen_cop(obj_t env_3860, obj_t obj1441_3861)
{
   {
      cop_t obj1441_2311;
      obj1441_2311 = (cop_t) (obj1441_3861);
      {
	 obj_t res1442_2314;
	 {
	    obj_t aux_5430;
	    aux_5430 = CNST_TABLE_REF(((long) 0));
	    res1442_2314 = make_struct(aux_5430, ((long) 2), BUNSPEC);
	 }
	 STRUCT_SET(res1442_2314, ((long) 0), BFALSE);
	 {
	    obj_t aux_5434;
	    aux_5434 = (((cop_t) CREF(obj1441_2311))->loc);
	    STRUCT_SET(res1442_2314, ((long) 1), aux_5434);
	 }
	 return res1442_2314;
      }
   }
}


/* struct+object->object-clabel */ obj_t 
struct_object__object_clabel_24_cgen_cop(obj_t env_3862, obj_t o_3863, obj_t s_3864)
{
   {
      clabel_t o_2300;
      obj_t s_2301;
      {
	 clabel_t aux_5438;
	 o_2300 = (clabel_t) (o_3863);
	 s_2301 = s_3864;
	 {
	    obj_t aux_5441;
	    object_t aux_5439;
	    aux_5441 = STRUCT_REF(s_2301, ((long) 0));
	    aux_5439 = (object_t) (o_2300);
	    OBJECT_WIDENING_SET(aux_5439, aux_5441);
	 }
	 {
	    obj_t v1461_2305;
	    v1461_2305 = STRUCT_REF(s_2301, ((long) 1));
	    ((((clabel_t) CREF(o_2300))->loc) = ((obj_t) v1461_2305), BUNSPEC);
	 }
	 {
	    obj_t v1465_2306;
	    v1465_2306 = STRUCT_REF(s_2301, ((long) 2));
	    ((((clabel_t) CREF(o_2300))->name) = ((obj_t) v1465_2306), BUNSPEC);
	 }
	 {
	    bool_t v1469_2307;
	    {
	       obj_t aux_5448;
	       aux_5448 = STRUCT_REF(s_2301, ((long) 3));
	       v1469_2307 = CBOOL(aux_5448);
	    }
	    ((((clabel_t) CREF(o_2300))->used__226) = ((bool_t) v1469_2307), BUNSPEC);
	 }
	 {
	    obj_t v1473_2308;
	    v1473_2308 = STRUCT_REF(s_2301, ((long) 4));
	    ((((clabel_t) CREF(o_2300))->body) = ((obj_t) v1473_2308), BUNSPEC);
	 }
	 aux_5438 = o_2300;
	 return (obj_t) (aux_5438);
      }
   }
}


/* object->struct-clabel */ obj_t 
object__struct_clabel_136_cgen_cop(obj_t env_3865, obj_t obj1457_3866)
{
   {
      clabel_t obj1457_2284;
      obj1457_2284 = (clabel_t) (obj1457_3866);
      {
	 obj_t res1458_2287;
	 {
	    obj_t aux_5456;
	    aux_5456 = CNST_TABLE_REF(((long) 1));
	    res1458_2287 = make_struct(aux_5456, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1458_2287, ((long) 0), BFALSE);
	 {
	    obj_t aux_5460;
	    aux_5460 = (((clabel_t) CREF(obj1457_2284))->loc);
	    STRUCT_SET(res1458_2287, ((long) 1), aux_5460);
	 }
	 {
	    obj_t aux_5463;
	    aux_5463 = (((clabel_t) CREF(obj1457_2284))->name);
	    STRUCT_SET(res1458_2287, ((long) 2), aux_5463);
	 }
	 {
	    obj_t aux_5466;
	    {
	       bool_t aux_5467;
	       aux_5467 = (((clabel_t) CREF(obj1457_2284))->used__226);
	       aux_5466 = BBOOL(aux_5467);
	    }
	    STRUCT_SET(res1458_2287, ((long) 3), aux_5466);
	 }
	 {
	    obj_t aux_5471;
	    aux_5471 = (((clabel_t) CREF(obj1457_2284))->body);
	    STRUCT_SET(res1458_2287, ((long) 4), aux_5471);
	 }
	 return res1458_2287;
      }
   }
}


/* struct+object->object-cgoto */ obj_t 
struct_object__object_cgoto_101_cgen_cop(obj_t env_3867, obj_t o_3868, obj_t s_3869)
{
   {
      cgoto_t o_2275;
      obj_t s_2276;
      {
	 cgoto_t aux_5475;
	 o_2275 = (cgoto_t) (o_3868);
	 s_2276 = s_3869;
	 {
	    obj_t aux_5478;
	    object_t aux_5476;
	    aux_5478 = STRUCT_REF(s_2276, ((long) 0));
	    aux_5476 = (object_t) (o_2275);
	    OBJECT_WIDENING_SET(aux_5476, aux_5478);
	 }
	 {
	    obj_t v1485_2280;
	    v1485_2280 = STRUCT_REF(s_2276, ((long) 1));
	    ((((cgoto_t) CREF(o_2275))->loc) = ((obj_t) v1485_2280), BUNSPEC);
	 }
	 {
	    clabel_t v1489_2281;
	    {
	       obj_t aux_5483;
	       aux_5483 = STRUCT_REF(s_2276, ((long) 2));
	       v1489_2281 = (clabel_t) (aux_5483);
	    }
	    ((((cgoto_t) CREF(o_2275))->label) = ((clabel_t) v1489_2281), BUNSPEC);
	 }
	 aux_5475 = o_2275;
	 return (obj_t) (aux_5475);
      }
   }
}


/* object->struct-cgoto */ obj_t 
object__struct_cgoto_44_cgen_cop(obj_t env_3870, obj_t obj1481_3871)
{
   {
      cgoto_t obj1481_2263;
      obj1481_2263 = (cgoto_t) (obj1481_3871);
      {
	 obj_t res1482_2266;
	 {
	    obj_t aux_5489;
	    aux_5489 = CNST_TABLE_REF(((long) 2));
	    res1482_2266 = make_struct(aux_5489, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1482_2266, ((long) 0), BFALSE);
	 {
	    obj_t aux_5493;
	    aux_5493 = (((cgoto_t) CREF(obj1481_2263))->loc);
	    STRUCT_SET(res1482_2266, ((long) 1), aux_5493);
	 }
	 {
	    obj_t aux_5496;
	    {
	       clabel_t aux_5497;
	       aux_5497 = (((cgoto_t) CREF(obj1481_2263))->label);
	       aux_5496 = (obj_t) (aux_5497);
	    }
	    STRUCT_SET(res1482_2266, ((long) 2), aux_5496);
	 }
	 return res1482_2266;
      }
   }
}


/* struct+object->object-block */ obj_t 
struct_object__object_block_188_cgen_cop(obj_t env_3872, obj_t o_3873, obj_t s_3874)
{
   {
      block_t o_2254;
      obj_t s_2255;
      {
	 block_t aux_5502;
	 o_2254 = (block_t) (o_3873);
	 s_2255 = s_3874;
	 {
	    obj_t aux_5505;
	    object_t aux_5503;
	    aux_5505 = STRUCT_REF(s_2255, ((long) 0));
	    aux_5503 = (object_t) (o_2254);
	    OBJECT_WIDENING_SET(aux_5503, aux_5505);
	 }
	 {
	    obj_t v1501_2259;
	    v1501_2259 = STRUCT_REF(s_2255, ((long) 1));
	    ((((block_t) CREF(o_2254))->loc) = ((obj_t) v1501_2259), BUNSPEC);
	 }
	 {
	    cop_t v1505_2260;
	    {
	       obj_t aux_5510;
	       aux_5510 = STRUCT_REF(s_2255, ((long) 2));
	       v1505_2260 = (cop_t) (aux_5510);
	    }
	    ((((block_t) CREF(o_2254))->body) = ((cop_t) v1505_2260), BUNSPEC);
	 }
	 aux_5502 = o_2254;
	 return (obj_t) (aux_5502);
      }
   }
}


/* object->struct-block */ obj_t 
object__struct_block_53_cgen_cop(obj_t env_3875, obj_t obj1497_3876)
{
   {
      block_t obj1497_2242;
      obj1497_2242 = (block_t) (obj1497_3876);
      {
	 obj_t res1498_2245;
	 {
	    obj_t aux_5516;
	    aux_5516 = CNST_TABLE_REF(((long) 3));
	    res1498_2245 = make_struct(aux_5516, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1498_2245, ((long) 0), BFALSE);
	 {
	    obj_t aux_5520;
	    aux_5520 = (((block_t) CREF(obj1497_2242))->loc);
	    STRUCT_SET(res1498_2245, ((long) 1), aux_5520);
	 }
	 {
	    obj_t aux_5523;
	    {
	       cop_t aux_5524;
	       aux_5524 = (((block_t) CREF(obj1497_2242))->body);
	       aux_5523 = (obj_t) (aux_5524);
	    }
	    STRUCT_SET(res1498_2245, ((long) 2), aux_5523);
	 }
	 return res1498_2245;
      }
   }
}


/* struct+object->object-creturn */ obj_t 
struct_object__object_creturn_28_cgen_cop(obj_t env_3877, obj_t o_3878, obj_t s_3879)
{
   {
      creturn_t o_2233;
      obj_t s_2234;
      {
	 creturn_t aux_5529;
	 o_2233 = (creturn_t) (o_3878);
	 s_2234 = s_3879;
	 {
	    obj_t aux_5532;
	    object_t aux_5530;
	    aux_5532 = STRUCT_REF(s_2234, ((long) 0));
	    aux_5530 = (object_t) (o_2233);
	    OBJECT_WIDENING_SET(aux_5530, aux_5532);
	 }
	 {
	    obj_t v1517_2238;
	    v1517_2238 = STRUCT_REF(s_2234, ((long) 1));
	    ((((creturn_t) CREF(o_2233))->loc) = ((obj_t) v1517_2238), BUNSPEC);
	 }
	 {
	    cop_t v1521_2239;
	    {
	       obj_t aux_5537;
	       aux_5537 = STRUCT_REF(s_2234, ((long) 2));
	       v1521_2239 = (cop_t) (aux_5537);
	    }
	    ((((creturn_t) CREF(o_2233))->value) = ((cop_t) v1521_2239), BUNSPEC);
	 }
	 aux_5529 = o_2233;
	 return (obj_t) (aux_5529);
      }
   }
}


/* object->struct-creturn */ obj_t 
object__struct_creturn_165_cgen_cop(obj_t env_3880, obj_t obj1513_3881)
{
   {
      creturn_t obj1513_2221;
      obj1513_2221 = (creturn_t) (obj1513_3881);
      {
	 obj_t res1514_2224;
	 {
	    obj_t aux_5543;
	    aux_5543 = CNST_TABLE_REF(((long) 4));
	    res1514_2224 = make_struct(aux_5543, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1514_2224, ((long) 0), BFALSE);
	 {
	    obj_t aux_5547;
	    aux_5547 = (((creturn_t) CREF(obj1513_2221))->loc);
	    STRUCT_SET(res1514_2224, ((long) 1), aux_5547);
	 }
	 {
	    obj_t aux_5550;
	    {
	       cop_t aux_5551;
	       aux_5551 = (((creturn_t) CREF(obj1513_2221))->value);
	       aux_5550 = (obj_t) (aux_5551);
	    }
	    STRUCT_SET(res1514_2224, ((long) 2), aux_5550);
	 }
	 return res1514_2224;
      }
   }
}


/* struct+object->object-cvoid */ obj_t 
struct_object__object_cvoid_49_cgen_cop(obj_t env_3882, obj_t o_3883, obj_t s_3884)
{
   {
      cvoid_t o_2212;
      obj_t s_2213;
      {
	 cvoid_t aux_5556;
	 o_2212 = (cvoid_t) (o_3883);
	 s_2213 = s_3884;
	 {
	    obj_t aux_5559;
	    object_t aux_5557;
	    aux_5559 = STRUCT_REF(s_2213, ((long) 0));
	    aux_5557 = (object_t) (o_2212);
	    OBJECT_WIDENING_SET(aux_5557, aux_5559);
	 }
	 {
	    obj_t v1534_2217;
	    v1534_2217 = STRUCT_REF(s_2213, ((long) 1));
	    ((((cvoid_t) CREF(o_2212))->loc) = ((obj_t) v1534_2217), BUNSPEC);
	 }
	 {
	    cop_t v1538_2218;
	    {
	       obj_t aux_5564;
	       aux_5564 = STRUCT_REF(s_2213, ((long) 2));
	       v1538_2218 = (cop_t) (aux_5564);
	    }
	    ((((cvoid_t) CREF(o_2212))->value) = ((cop_t) v1538_2218), BUNSPEC);
	 }
	 aux_5556 = o_2212;
	 return (obj_t) (aux_5556);
      }
   }
}


/* object->struct-cvoid */ obj_t 
object__struct_cvoid_78_cgen_cop(obj_t env_3885, obj_t obj1530_3886)
{
   {
      cvoid_t obj1530_2200;
      obj1530_2200 = (cvoid_t) (obj1530_3886);
      {
	 obj_t res1531_2203;
	 {
	    obj_t aux_5570;
	    aux_5570 = CNST_TABLE_REF(((long) 5));
	    res1531_2203 = make_struct(aux_5570, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1531_2203, ((long) 0), BFALSE);
	 {
	    obj_t aux_5574;
	    aux_5574 = (((cvoid_t) CREF(obj1530_2200))->loc);
	    STRUCT_SET(res1531_2203, ((long) 1), aux_5574);
	 }
	 {
	    obj_t aux_5577;
	    {
	       cop_t aux_5578;
	       aux_5578 = (((cvoid_t) CREF(obj1530_2200))->value);
	       aux_5577 = (obj_t) (aux_5578);
	    }
	    STRUCT_SET(res1531_2203, ((long) 2), aux_5577);
	 }
	 return res1531_2203;
      }
   }
}


/* struct+object->object-catom */ obj_t 
struct_object__object_catom_48_cgen_cop(obj_t env_3887, obj_t o_3888, obj_t s_3889)
{
   {
      catom_t o_2191;
      obj_t s_2192;
      {
	 catom_t aux_5583;
	 o_2191 = (catom_t) (o_3888);
	 s_2192 = s_3889;
	 {
	    obj_t aux_5586;
	    object_t aux_5584;
	    aux_5586 = STRUCT_REF(s_2192, ((long) 0));
	    aux_5584 = (object_t) (o_2191);
	    OBJECT_WIDENING_SET(aux_5584, aux_5586);
	 }
	 {
	    obj_t v1550_2196;
	    v1550_2196 = STRUCT_REF(s_2192, ((long) 1));
	    ((((catom_t) CREF(o_2191))->loc) = ((obj_t) v1550_2196), BUNSPEC);
	 }
	 {
	    obj_t v1554_2197;
	    v1554_2197 = STRUCT_REF(s_2192, ((long) 2));
	    ((((catom_t) CREF(o_2191))->value) = ((obj_t) v1554_2197), BUNSPEC);
	 }
	 aux_5583 = o_2191;
	 return (obj_t) (aux_5583);
      }
   }
}


/* object->struct-catom */ obj_t 
object__struct_catom_180_cgen_cop(obj_t env_3890, obj_t obj1546_3891)
{
   {
      catom_t obj1546_2179;
      obj1546_2179 = (catom_t) (obj1546_3891);
      {
	 obj_t res1547_2182;
	 {
	    obj_t aux_5595;
	    aux_5595 = CNST_TABLE_REF(((long) 6));
	    res1547_2182 = make_struct(aux_5595, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1547_2182, ((long) 0), BFALSE);
	 {
	    obj_t aux_5599;
	    aux_5599 = (((catom_t) CREF(obj1546_2179))->loc);
	    STRUCT_SET(res1547_2182, ((long) 1), aux_5599);
	 }
	 {
	    obj_t aux_5602;
	    aux_5602 = (((catom_t) CREF(obj1546_2179))->value);
	    STRUCT_SET(res1547_2182, ((long) 2), aux_5602);
	 }
	 return res1547_2182;
      }
   }
}


/* struct+object->object-varc */ obj_t 
struct_object__object_varc_23_cgen_cop(obj_t env_3892, obj_t o_3893, obj_t s_3894)
{
   {
      varc_t o_2170;
      obj_t s_2171;
      {
	 varc_t aux_5606;
	 o_2170 = (varc_t) (o_3893);
	 s_2171 = s_3894;
	 {
	    obj_t aux_5609;
	    object_t aux_5607;
	    aux_5609 = STRUCT_REF(s_2171, ((long) 0));
	    aux_5607 = (object_t) (o_2170);
	    OBJECT_WIDENING_SET(aux_5607, aux_5609);
	 }
	 {
	    obj_t v1566_2175;
	    v1566_2175 = STRUCT_REF(s_2171, ((long) 1));
	    ((((varc_t) CREF(o_2170))->loc) = ((obj_t) v1566_2175), BUNSPEC);
	 }
	 {
	    variable_t v1570_2176;
	    {
	       obj_t aux_5614;
	       aux_5614 = STRUCT_REF(s_2171, ((long) 2));
	       v1570_2176 = (variable_t) (aux_5614);
	    }
	    ((((varc_t) CREF(o_2170))->variable) = ((variable_t) v1570_2176), BUNSPEC);
	 }
	 aux_5606 = o_2170;
	 return (obj_t) (aux_5606);
      }
   }
}


/* object->struct-varc */ obj_t 
object__struct_varc_203_cgen_cop(obj_t env_3895, obj_t obj1562_3896)
{
   {
      varc_t obj1562_2158;
      obj1562_2158 = (varc_t) (obj1562_3896);
      {
	 obj_t res1563_2161;
	 {
	    obj_t aux_5620;
	    aux_5620 = CNST_TABLE_REF(((long) 7));
	    res1563_2161 = make_struct(aux_5620, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1563_2161, ((long) 0), BFALSE);
	 {
	    obj_t aux_5624;
	    aux_5624 = (((varc_t) CREF(obj1562_2158))->loc);
	    STRUCT_SET(res1563_2161, ((long) 1), aux_5624);
	 }
	 {
	    obj_t aux_5627;
	    {
	       variable_t aux_5628;
	       aux_5628 = (((varc_t) CREF(obj1562_2158))->variable);
	       aux_5627 = (obj_t) (aux_5628);
	    }
	    STRUCT_SET(res1563_2161, ((long) 2), aux_5627);
	 }
	 return res1563_2161;
      }
   }
}


/* struct+object->object-cpragma */ obj_t 
struct_object__object_cpragma_169_cgen_cop(obj_t env_3897, obj_t o_3898, obj_t s_3899)
{
   {
      cpragma_t o_2148;
      obj_t s_2149;
      {
	 cpragma_t aux_5633;
	 o_2148 = (cpragma_t) (o_3898);
	 s_2149 = s_3899;
	 {
	    obj_t aux_5636;
	    object_t aux_5634;
	    aux_5636 = STRUCT_REF(s_2149, ((long) 0));
	    aux_5634 = (object_t) (o_2148);
	    OBJECT_WIDENING_SET(aux_5634, aux_5636);
	 }
	 {
	    obj_t v1583_2153;
	    v1583_2153 = STRUCT_REF(s_2149, ((long) 1));
	    ((((cpragma_t) CREF(o_2148))->loc) = ((obj_t) v1583_2153), BUNSPEC);
	 }
	 {
	    obj_t v1587_2154;
	    v1587_2154 = STRUCT_REF(s_2149, ((long) 2));
	    ((((cpragma_t) CREF(o_2148))->format) = ((obj_t) v1587_2154), BUNSPEC);
	 }
	 {
	    obj_t v1591_2155;
	    v1591_2155 = STRUCT_REF(s_2149, ((long) 3));
	    ((((cpragma_t) CREF(o_2148))->args) = ((obj_t) v1591_2155), BUNSPEC);
	 }
	 aux_5633 = o_2148;
	 return (obj_t) (aux_5633);
      }
   }
}


/* object->struct-cpragma */ obj_t 
object__struct_cpragma_233_cgen_cop(obj_t env_3900, obj_t obj1579_3901)
{
   {
      cpragma_t obj1579_2134;
      obj1579_2134 = (cpragma_t) (obj1579_3901);
      {
	 obj_t res1580_2137;
	 {
	    obj_t aux_5647;
	    aux_5647 = CNST_TABLE_REF(((long) 8));
	    res1580_2137 = make_struct(aux_5647, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1580_2137, ((long) 0), BFALSE);
	 {
	    obj_t aux_5651;
	    aux_5651 = (((cpragma_t) CREF(obj1579_2134))->loc);
	    STRUCT_SET(res1580_2137, ((long) 1), aux_5651);
	 }
	 {
	    obj_t aux_5654;
	    aux_5654 = (((cpragma_t) CREF(obj1579_2134))->format);
	    STRUCT_SET(res1580_2137, ((long) 2), aux_5654);
	 }
	 {
	    obj_t aux_5657;
	    aux_5657 = (((cpragma_t) CREF(obj1579_2134))->args);
	    STRUCT_SET(res1580_2137, ((long) 3), aux_5657);
	 }
	 return res1580_2137;
      }
   }
}


/* struct+object->object-ccast */ obj_t 
struct_object__object_ccast_65_cgen_cop(obj_t env_3902, obj_t o_3903, obj_t s_3904)
{
   {
      ccast_t o_2124;
      obj_t s_2125;
      {
	 ccast_t aux_5661;
	 o_2124 = (ccast_t) (o_3903);
	 s_2125 = s_3904;
	 {
	    obj_t aux_5664;
	    object_t aux_5662;
	    aux_5664 = STRUCT_REF(s_2125, ((long) 0));
	    aux_5662 = (object_t) (o_2124);
	    OBJECT_WIDENING_SET(aux_5662, aux_5664);
	 }
	 {
	    obj_t v1604_2129;
	    v1604_2129 = STRUCT_REF(s_2125, ((long) 1));
	    ((((ccast_t) CREF(o_2124))->loc) = ((obj_t) v1604_2129), BUNSPEC);
	 }
	 {
	    type_t v1608_2130;
	    {
	       obj_t aux_5669;
	       aux_5669 = STRUCT_REF(s_2125, ((long) 2));
	       v1608_2130 = (type_t) (aux_5669);
	    }
	    ((((ccast_t) CREF(o_2124))->type) = ((type_t) v1608_2130), BUNSPEC);
	 }
	 {
	    cop_t v1612_2131;
	    {
	       obj_t aux_5673;
	       aux_5673 = STRUCT_REF(s_2125, ((long) 3));
	       v1612_2131 = (cop_t) (aux_5673);
	    }
	    ((((ccast_t) CREF(o_2124))->arg) = ((cop_t) v1612_2131), BUNSPEC);
	 }
	 aux_5661 = o_2124;
	 return (obj_t) (aux_5661);
      }
   }
}


/* object->struct-ccast */ obj_t 
object__struct_ccast_238_cgen_cop(obj_t env_3905, obj_t obj1600_3906)
{
   {
      ccast_t obj1600_2110;
      obj1600_2110 = (ccast_t) (obj1600_3906);
      {
	 obj_t res1601_2113;
	 {
	    obj_t aux_5679;
	    aux_5679 = CNST_TABLE_REF(((long) 9));
	    res1601_2113 = make_struct(aux_5679, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1601_2113, ((long) 0), BFALSE);
	 {
	    obj_t aux_5683;
	    aux_5683 = (((ccast_t) CREF(obj1600_2110))->loc);
	    STRUCT_SET(res1601_2113, ((long) 1), aux_5683);
	 }
	 {
	    obj_t aux_5686;
	    {
	       type_t aux_5687;
	       aux_5687 = (((ccast_t) CREF(obj1600_2110))->type);
	       aux_5686 = (obj_t) (aux_5687);
	    }
	    STRUCT_SET(res1601_2113, ((long) 2), aux_5686);
	 }
	 {
	    obj_t aux_5691;
	    {
	       cop_t aux_5692;
	       aux_5692 = (((ccast_t) CREF(obj1600_2110))->arg);
	       aux_5691 = (obj_t) (aux_5692);
	    }
	    STRUCT_SET(res1601_2113, ((long) 3), aux_5691);
	 }
	 return res1601_2113;
      }
   }
}


/* struct+object->object-csequence */ obj_t 
struct_object__object_csequence_144_cgen_cop(obj_t env_3907, obj_t o_3908, obj_t s_3909)
{
   {
      csequence_t o_2100;
      obj_t s_2101;
      {
	 csequence_t aux_5697;
	 o_2100 = (csequence_t) (o_3908);
	 s_2101 = s_3909;
	 {
	    obj_t aux_5700;
	    object_t aux_5698;
	    aux_5700 = STRUCT_REF(s_2101, ((long) 0));
	    aux_5698 = (object_t) (o_2100);
	    OBJECT_WIDENING_SET(aux_5698, aux_5700);
	 }
	 {
	    obj_t v1625_2105;
	    v1625_2105 = STRUCT_REF(s_2101, ((long) 1));
	    ((((csequence_t) CREF(o_2100))->loc) = ((obj_t) v1625_2105), BUNSPEC);
	 }
	 {
	    bool_t v1629_2106;
	    {
	       obj_t aux_5705;
	       aux_5705 = STRUCT_REF(s_2101, ((long) 2));
	       v1629_2106 = CBOOL(aux_5705);
	    }
	    ((((csequence_t) CREF(o_2100))->c_exp__163) = ((bool_t) v1629_2106), BUNSPEC);
	 }
	 {
	    obj_t v1633_2107;
	    v1633_2107 = STRUCT_REF(s_2101, ((long) 3));
	    ((((csequence_t) CREF(o_2100))->cops) = ((obj_t) v1633_2107), BUNSPEC);
	 }
	 aux_5697 = o_2100;
	 return (obj_t) (aux_5697);
      }
   }
}


/* object->struct-csequence */ obj_t 
object__struct_csequence_69_cgen_cop(obj_t env_3910, obj_t obj1621_3911)
{
   {
      csequence_t obj1621_2086;
      obj1621_2086 = (csequence_t) (obj1621_3911);
      {
	 obj_t res1622_2089;
	 {
	    obj_t aux_5713;
	    aux_5713 = CNST_TABLE_REF(((long) 10));
	    res1622_2089 = make_struct(aux_5713, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1622_2089, ((long) 0), BFALSE);
	 {
	    obj_t aux_5717;
	    aux_5717 = (((csequence_t) CREF(obj1621_2086))->loc);
	    STRUCT_SET(res1622_2089, ((long) 1), aux_5717);
	 }
	 {
	    obj_t aux_5720;
	    {
	       bool_t aux_5721;
	       aux_5721 = (((csequence_t) CREF(obj1621_2086))->c_exp__163);
	       aux_5720 = BBOOL(aux_5721);
	    }
	    STRUCT_SET(res1622_2089, ((long) 2), aux_5720);
	 }
	 {
	    obj_t aux_5725;
	    aux_5725 = (((csequence_t) CREF(obj1621_2086))->cops);
	    STRUCT_SET(res1622_2089, ((long) 3), aux_5725);
	 }
	 return res1622_2089;
      }
   }
}


/* struct+object->object-nop */ obj_t 
struct_object__object_nop_31_cgen_cop(obj_t env_3912, obj_t o_3913, obj_t s_3914)
{
   {
      nop_t o_2078;
      obj_t s_2079;
      {
	 nop_t aux_5729;
	 o_2078 = (nop_t) (o_3913);
	 s_2079 = s_3914;
	 {
	    obj_t aux_5732;
	    object_t aux_5730;
	    aux_5732 = STRUCT_REF(s_2079, ((long) 0));
	    aux_5730 = (object_t) (o_2078);
	    OBJECT_WIDENING_SET(aux_5730, aux_5732);
	 }
	 {
	    obj_t v1644_2083;
	    v1644_2083 = STRUCT_REF(s_2079, ((long) 1));
	    ((((nop_t) CREF(o_2078))->loc) = ((obj_t) v1644_2083), BUNSPEC);
	 }
	 aux_5729 = o_2078;
	 return (obj_t) (aux_5729);
      }
   }
}


/* object->struct-nop */ obj_t 
object__struct_nop_253_cgen_cop(obj_t env_3915, obj_t obj1640_3916)
{
   {
      nop_t obj1640_2068;
      obj1640_2068 = (nop_t) (obj1640_3916);
      {
	 obj_t res1641_2071;
	 {
	    obj_t aux_5739;
	    aux_5739 = CNST_TABLE_REF(((long) 11));
	    res1641_2071 = make_struct(aux_5739, ((long) 2), BUNSPEC);
	 }
	 STRUCT_SET(res1641_2071, ((long) 0), BFALSE);
	 {
	    obj_t aux_5743;
	    aux_5743 = (((nop_t) CREF(obj1640_2068))->loc);
	    STRUCT_SET(res1641_2071, ((long) 1), aux_5743);
	 }
	 return res1641_2071;
      }
   }
}


/* struct+object->object-stop */ obj_t 
struct_object__object_stop_60_cgen_cop(obj_t env_3917, obj_t o_3918, obj_t s_3919)
{
   {
      stop_t o_2059;
      obj_t s_2060;
      {
	 stop_t aux_5747;
	 o_2059 = (stop_t) (o_3918);
	 s_2060 = s_3919;
	 {
	    obj_t aux_5750;
	    object_t aux_5748;
	    aux_5750 = STRUCT_REF(s_2060, ((long) 0));
	    aux_5748 = (object_t) (o_2059);
	    OBJECT_WIDENING_SET(aux_5748, aux_5750);
	 }
	 {
	    obj_t v1656_2064;
	    v1656_2064 = STRUCT_REF(s_2060, ((long) 1));
	    ((((stop_t) CREF(o_2059))->loc) = ((obj_t) v1656_2064), BUNSPEC);
	 }
	 {
	    cop_t v1660_2065;
	    {
	       obj_t aux_5755;
	       aux_5755 = STRUCT_REF(s_2060, ((long) 2));
	       v1660_2065 = (cop_t) (aux_5755);
	    }
	    ((((stop_t) CREF(o_2059))->value) = ((cop_t) v1660_2065), BUNSPEC);
	 }
	 aux_5747 = o_2059;
	 return (obj_t) (aux_5747);
      }
   }
}


/* object->struct-stop */ obj_t 
object__struct_stop_197_cgen_cop(obj_t env_3920, obj_t obj1652_3921)
{
   {
      stop_t obj1652_2047;
      obj1652_2047 = (stop_t) (obj1652_3921);
      {
	 obj_t res1653_2050;
	 {
	    obj_t aux_5761;
	    aux_5761 = CNST_TABLE_REF(((long) 12));
	    res1653_2050 = make_struct(aux_5761, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1653_2050, ((long) 0), BFALSE);
	 {
	    obj_t aux_5765;
	    aux_5765 = (((stop_t) CREF(obj1652_2047))->loc);
	    STRUCT_SET(res1653_2050, ((long) 1), aux_5765);
	 }
	 {
	    obj_t aux_5768;
	    {
	       cop_t aux_5769;
	       aux_5769 = (((stop_t) CREF(obj1652_2047))->value);
	       aux_5768 = (obj_t) (aux_5769);
	    }
	    STRUCT_SET(res1653_2050, ((long) 2), aux_5768);
	 }
	 return res1653_2050;
      }
   }
}


/* struct+object->object-csetq */ obj_t 
struct_object__object_csetq_16_cgen_cop(obj_t env_3922, obj_t o_3923, obj_t s_3924)
{
   {
      csetq_t o_2037;
      obj_t s_2038;
      {
	 csetq_t aux_5774;
	 o_2037 = (csetq_t) (o_3923);
	 s_2038 = s_3924;
	 {
	    obj_t aux_5777;
	    object_t aux_5775;
	    aux_5777 = STRUCT_REF(s_2038, ((long) 0));
	    aux_5775 = (object_t) (o_2037);
	    OBJECT_WIDENING_SET(aux_5775, aux_5777);
	 }
	 {
	    obj_t v1673_2042;
	    v1673_2042 = STRUCT_REF(s_2038, ((long) 1));
	    ((((csetq_t) CREF(o_2037))->loc) = ((obj_t) v1673_2042), BUNSPEC);
	 }
	 {
	    varc_t v1677_2043;
	    {
	       obj_t aux_5782;
	       aux_5782 = STRUCT_REF(s_2038, ((long) 2));
	       v1677_2043 = (varc_t) (aux_5782);
	    }
	    ((((csetq_t) CREF(o_2037))->var) = ((varc_t) v1677_2043), BUNSPEC);
	 }
	 {
	    cop_t v1681_2044;
	    {
	       obj_t aux_5786;
	       aux_5786 = STRUCT_REF(s_2038, ((long) 3));
	       v1681_2044 = (cop_t) (aux_5786);
	    }
	    ((((csetq_t) CREF(o_2037))->value) = ((cop_t) v1681_2044), BUNSPEC);
	 }
	 aux_5774 = o_2037;
	 return (obj_t) (aux_5774);
      }
   }
}


/* object->struct-csetq */ obj_t 
object__struct_csetq_144_cgen_cop(obj_t env_3925, obj_t obj1669_3926)
{
   {
      csetq_t obj1669_2023;
      obj1669_2023 = (csetq_t) (obj1669_3926);
      {
	 obj_t res1670_2026;
	 {
	    obj_t aux_5792;
	    aux_5792 = CNST_TABLE_REF(((long) 13));
	    res1670_2026 = make_struct(aux_5792, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1670_2026, ((long) 0), BFALSE);
	 {
	    obj_t aux_5796;
	    aux_5796 = (((csetq_t) CREF(obj1669_2023))->loc);
	    STRUCT_SET(res1670_2026, ((long) 1), aux_5796);
	 }
	 {
	    obj_t aux_5799;
	    {
	       varc_t aux_5800;
	       aux_5800 = (((csetq_t) CREF(obj1669_2023))->var);
	       aux_5799 = (obj_t) (aux_5800);
	    }
	    STRUCT_SET(res1670_2026, ((long) 2), aux_5799);
	 }
	 {
	    obj_t aux_5804;
	    {
	       cop_t aux_5805;
	       aux_5805 = (((csetq_t) CREF(obj1669_2023))->value);
	       aux_5804 = (obj_t) (aux_5805);
	    }
	    STRUCT_SET(res1670_2026, ((long) 3), aux_5804);
	 }
	 return res1670_2026;
      }
   }
}


/* struct+object->object-cif */ obj_t 
struct_object__object_cif_118_cgen_cop(obj_t env_3927, obj_t o_3928, obj_t s_3929)
{
   {
      cif_t o_2012;
      obj_t s_2013;
      {
	 cif_t aux_5810;
	 o_2012 = (cif_t) (o_3928);
	 s_2013 = s_3929;
	 {
	    obj_t aux_5813;
	    object_t aux_5811;
	    aux_5813 = STRUCT_REF(s_2013, ((long) 0));
	    aux_5811 = (object_t) (o_2012);
	    OBJECT_WIDENING_SET(aux_5811, aux_5813);
	 }
	 {
	    obj_t v1695_2017;
	    v1695_2017 = STRUCT_REF(s_2013, ((long) 1));
	    ((((cif_t) CREF(o_2012))->loc) = ((obj_t) v1695_2017), BUNSPEC);
	 }
	 {
	    cop_t v1699_2018;
	    {
	       obj_t aux_5818;
	       aux_5818 = STRUCT_REF(s_2013, ((long) 2));
	       v1699_2018 = (cop_t) (aux_5818);
	    }
	    ((((cif_t) CREF(o_2012))->test) = ((cop_t) v1699_2018), BUNSPEC);
	 }
	 {
	    cop_t v1703_2019;
	    {
	       obj_t aux_5822;
	       aux_5822 = STRUCT_REF(s_2013, ((long) 3));
	       v1703_2019 = (cop_t) (aux_5822);
	    }
	    ((((cif_t) CREF(o_2012))->true) = ((cop_t) v1703_2019), BUNSPEC);
	 }
	 {
	    cop_t v1707_2020;
	    {
	       obj_t aux_5826;
	       aux_5826 = STRUCT_REF(s_2013, ((long) 4));
	       v1707_2020 = (cop_t) (aux_5826);
	    }
	    ((((cif_t) CREF(o_2012))->false) = ((cop_t) v1707_2020), BUNSPEC);
	 }
	 aux_5810 = o_2012;
	 return (obj_t) (aux_5810);
      }
   }
}


/* object->struct-cif */ obj_t 
object__struct_cif_61_cgen_cop(obj_t env_3930, obj_t obj1691_3931)
{
   {
      cif_t obj1691_1996;
      obj1691_1996 = (cif_t) (obj1691_3931);
      {
	 obj_t res1692_1999;
	 {
	    obj_t aux_5832;
	    aux_5832 = CNST_TABLE_REF(((long) 14));
	    res1692_1999 = make_struct(aux_5832, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1692_1999, ((long) 0), BFALSE);
	 {
	    obj_t aux_5836;
	    aux_5836 = (((cif_t) CREF(obj1691_1996))->loc);
	    STRUCT_SET(res1692_1999, ((long) 1), aux_5836);
	 }
	 {
	    obj_t aux_5839;
	    {
	       cop_t aux_5840;
	       aux_5840 = (((cif_t) CREF(obj1691_1996))->test);
	       aux_5839 = (obj_t) (aux_5840);
	    }
	    STRUCT_SET(res1692_1999, ((long) 2), aux_5839);
	 }
	 {
	    obj_t aux_5844;
	    {
	       cop_t aux_5845;
	       aux_5845 = (((cif_t) CREF(obj1691_1996))->true);
	       aux_5844 = (obj_t) (aux_5845);
	    }
	    STRUCT_SET(res1692_1999, ((long) 3), aux_5844);
	 }
	 {
	    obj_t aux_5849;
	    {
	       cop_t aux_5850;
	       aux_5850 = (((cif_t) CREF(obj1691_1996))->false);
	       aux_5849 = (obj_t) (aux_5850);
	    }
	    STRUCT_SET(res1692_1999, ((long) 4), aux_5849);
	 }
	 return res1692_1999;
      }
   }
}


/* struct+object->object-local-var */ obj_t 
struct_object__object_local_var_195_cgen_cop(obj_t env_3932, obj_t o_3933, obj_t s_3934)
{
   {
      local_var_164_t o_1987;
      obj_t s_1988;
      {
	 local_var_164_t aux_5855;
	 o_1987 = (local_var_164_t) (o_3933);
	 s_1988 = s_3934;
	 {
	    obj_t aux_5858;
	    object_t aux_5856;
	    aux_5858 = STRUCT_REF(s_1988, ((long) 0));
	    aux_5856 = (object_t) (o_1987);
	    OBJECT_WIDENING_SET(aux_5856, aux_5858);
	 }
	 {
	    obj_t v1719_1992;
	    v1719_1992 = STRUCT_REF(s_1988, ((long) 1));
	    ((((local_var_164_t) CREF(o_1987))->loc) = ((obj_t) v1719_1992), BUNSPEC);
	 }
	 {
	    obj_t v1723_1993;
	    v1723_1993 = STRUCT_REF(s_1988, ((long) 2));
	    ((((local_var_164_t) CREF(o_1987))->vars) = ((obj_t) v1723_1993), BUNSPEC);
	 }
	 aux_5855 = o_1987;
	 return (obj_t) (aux_5855);
      }
   }
}


/* object->struct-local-var */ obj_t 
object__struct_local_var_3_cgen_cop(obj_t env_3935, obj_t obj1715_3936)
{
   {
      local_var_164_t obj1715_1975;
      obj1715_1975 = (local_var_164_t) (obj1715_3936);
      {
	 obj_t res1716_1978;
	 {
	    obj_t aux_5867;
	    aux_5867 = CNST_TABLE_REF(((long) 15));
	    res1716_1978 = make_struct(aux_5867, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1716_1978, ((long) 0), BFALSE);
	 {
	    obj_t aux_5871;
	    aux_5871 = (((local_var_164_t) CREF(obj1715_1975))->loc);
	    STRUCT_SET(res1716_1978, ((long) 1), aux_5871);
	 }
	 {
	    obj_t aux_5874;
	    aux_5874 = (((local_var_164_t) CREF(obj1715_1975))->vars);
	    STRUCT_SET(res1716_1978, ((long) 2), aux_5874);
	 }
	 return res1716_1978;
      }
   }
}


/* struct+object->object-cfuncall */ obj_t 
struct_object__object_cfuncall_72_cgen_cop(obj_t env_3937, obj_t o_3938, obj_t s_3939)
{
   {
      cfuncall_t o_1964;
      obj_t s_1965;
      {
	 cfuncall_t aux_5878;
	 o_1964 = (cfuncall_t) (o_3938);
	 s_1965 = s_3939;
	 {
	    obj_t aux_5881;
	    object_t aux_5879;
	    aux_5881 = STRUCT_REF(s_1965, ((long) 0));
	    aux_5879 = (object_t) (o_1964);
	    OBJECT_WIDENING_SET(aux_5879, aux_5881);
	 }
	 {
	    obj_t v1737_1969;
	    v1737_1969 = STRUCT_REF(s_1965, ((long) 1));
	    ((((cfuncall_t) CREF(o_1964))->loc) = ((obj_t) v1737_1969), BUNSPEC);
	 }
	 {
	    cop_t v1741_1970;
	    {
	       obj_t aux_5886;
	       aux_5886 = STRUCT_REF(s_1965, ((long) 2));
	       v1741_1970 = (cop_t) (aux_5886);
	    }
	    ((((cfuncall_t) CREF(o_1964))->fun) = ((cop_t) v1741_1970), BUNSPEC);
	 }
	 {
	    obj_t v1745_1971;
	    v1745_1971 = STRUCT_REF(s_1965, ((long) 3));
	    ((((cfuncall_t) CREF(o_1964))->args) = ((obj_t) v1745_1971), BUNSPEC);
	 }
	 {
	    obj_t v1749_1972;
	    v1749_1972 = STRUCT_REF(s_1965, ((long) 4));
	    ((((cfuncall_t) CREF(o_1964))->strength) = ((obj_t) v1749_1972), BUNSPEC);
	 }
	 aux_5878 = o_1964;
	 return (obj_t) (aux_5878);
      }
   }
}


/* object->struct-cfuncall */ obj_t 
object__struct_cfuncall_147_cgen_cop(obj_t env_3940, obj_t obj1733_3941)
{
   {
      cfuncall_t obj1733_1948;
      obj1733_1948 = (cfuncall_t) (obj1733_3941);
      {
	 obj_t res1734_1951;
	 {
	    obj_t aux_5896;
	    aux_5896 = CNST_TABLE_REF(((long) 16));
	    res1734_1951 = make_struct(aux_5896, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1734_1951, ((long) 0), BFALSE);
	 {
	    obj_t aux_5900;
	    aux_5900 = (((cfuncall_t) CREF(obj1733_1948))->loc);
	    STRUCT_SET(res1734_1951, ((long) 1), aux_5900);
	 }
	 {
	    obj_t aux_5903;
	    {
	       cop_t aux_5904;
	       aux_5904 = (((cfuncall_t) CREF(obj1733_1948))->fun);
	       aux_5903 = (obj_t) (aux_5904);
	    }
	    STRUCT_SET(res1734_1951, ((long) 2), aux_5903);
	 }
	 {
	    obj_t aux_5908;
	    aux_5908 = (((cfuncall_t) CREF(obj1733_1948))->args);
	    STRUCT_SET(res1734_1951, ((long) 3), aux_5908);
	 }
	 {
	    obj_t aux_5911;
	    aux_5911 = (((cfuncall_t) CREF(obj1733_1948))->strength);
	    STRUCT_SET(res1734_1951, ((long) 4), aux_5911);
	 }
	 return res1734_1951;
      }
   }
}


/* struct+object->object-capply */ obj_t 
struct_object__object_capply_0_cgen_cop(obj_t env_3942, obj_t o_3943, obj_t s_3944)
{
   {
      capply_t o_1938;
      obj_t s_1939;
      {
	 capply_t aux_5915;
	 o_1938 = (capply_t) (o_3943);
	 s_1939 = s_3944;
	 {
	    obj_t aux_5918;
	    object_t aux_5916;
	    aux_5918 = STRUCT_REF(s_1939, ((long) 0));
	    aux_5916 = (object_t) (o_1938);
	    OBJECT_WIDENING_SET(aux_5916, aux_5918);
	 }
	 {
	    obj_t v1762_1943;
	    v1762_1943 = STRUCT_REF(s_1939, ((long) 1));
	    ((((capply_t) CREF(o_1938))->loc) = ((obj_t) v1762_1943), BUNSPEC);
	 }
	 {
	    cop_t v1766_1944;
	    {
	       obj_t aux_5923;
	       aux_5923 = STRUCT_REF(s_1939, ((long) 2));
	       v1766_1944 = (cop_t) (aux_5923);
	    }
	    ((((capply_t) CREF(o_1938))->fun) = ((cop_t) v1766_1944), BUNSPEC);
	 }
	 {
	    cop_t v1770_1945;
	    {
	       obj_t aux_5927;
	       aux_5927 = STRUCT_REF(s_1939, ((long) 3));
	       v1770_1945 = (cop_t) (aux_5927);
	    }
	    ((((capply_t) CREF(o_1938))->arg) = ((cop_t) v1770_1945), BUNSPEC);
	 }
	 aux_5915 = o_1938;
	 return (obj_t) (aux_5915);
      }
   }
}


/* object->struct-capply */ obj_t 
object__struct_capply_87_cgen_cop(obj_t env_3945, obj_t obj1758_3946)
{
   {
      capply_t obj1758_1924;
      obj1758_1924 = (capply_t) (obj1758_3946);
      {
	 obj_t res1759_1927;
	 {
	    obj_t aux_5933;
	    aux_5933 = CNST_TABLE_REF(((long) 17));
	    res1759_1927 = make_struct(aux_5933, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1759_1927, ((long) 0), BFALSE);
	 {
	    obj_t aux_5937;
	    aux_5937 = (((capply_t) CREF(obj1758_1924))->loc);
	    STRUCT_SET(res1759_1927, ((long) 1), aux_5937);
	 }
	 {
	    obj_t aux_5940;
	    {
	       cop_t aux_5941;
	       aux_5941 = (((capply_t) CREF(obj1758_1924))->fun);
	       aux_5940 = (obj_t) (aux_5941);
	    }
	    STRUCT_SET(res1759_1927, ((long) 2), aux_5940);
	 }
	 {
	    obj_t aux_5945;
	    {
	       cop_t aux_5946;
	       aux_5946 = (((capply_t) CREF(obj1758_1924))->arg);
	       aux_5945 = (obj_t) (aux_5946);
	    }
	    STRUCT_SET(res1759_1927, ((long) 3), aux_5945);
	 }
	 return res1759_1927;
      }
   }
}


/* struct+object->object-capp */ obj_t 
struct_object__object_capp_36_cgen_cop(obj_t env_3947, obj_t o_3948, obj_t s_3949)
{
   {
      capp_t o_1914;
      obj_t s_1915;
      {
	 capp_t aux_5951;
	 o_1914 = (capp_t) (o_3948);
	 s_1915 = s_3949;
	 {
	    obj_t aux_5954;
	    object_t aux_5952;
	    aux_5954 = STRUCT_REF(s_1915, ((long) 0));
	    aux_5952 = (object_t) (o_1914);
	    OBJECT_WIDENING_SET(aux_5952, aux_5954);
	 }
	 {
	    obj_t v1784_1919;
	    v1784_1919 = STRUCT_REF(s_1915, ((long) 1));
	    ((((capp_t) CREF(o_1914))->loc) = ((obj_t) v1784_1919), BUNSPEC);
	 }
	 {
	    cop_t v1788_1920;
	    {
	       obj_t aux_5959;
	       aux_5959 = STRUCT_REF(s_1915, ((long) 2));
	       v1788_1920 = (cop_t) (aux_5959);
	    }
	    ((((capp_t) CREF(o_1914))->fun) = ((cop_t) v1788_1920), BUNSPEC);
	 }
	 {
	    obj_t v1792_1921;
	    v1792_1921 = STRUCT_REF(s_1915, ((long) 3));
	    ((((capp_t) CREF(o_1914))->args) = ((obj_t) v1792_1921), BUNSPEC);
	 }
	 aux_5951 = o_1914;
	 return (obj_t) (aux_5951);
      }
   }
}


/* object->struct-capp */ obj_t 
object__struct_capp_230_cgen_cop(obj_t env_3950, obj_t obj1780_3951)
{
   {
      capp_t obj1780_1900;
      obj1780_1900 = (capp_t) (obj1780_3951);
      {
	 obj_t res1781_1903;
	 {
	    obj_t aux_5967;
	    aux_5967 = CNST_TABLE_REF(((long) 18));
	    res1781_1903 = make_struct(aux_5967, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1781_1903, ((long) 0), BFALSE);
	 {
	    obj_t aux_5971;
	    aux_5971 = (((capp_t) CREF(obj1780_1900))->loc);
	    STRUCT_SET(res1781_1903, ((long) 1), aux_5971);
	 }
	 {
	    obj_t aux_5974;
	    {
	       cop_t aux_5975;
	       aux_5975 = (((capp_t) CREF(obj1780_1900))->fun);
	       aux_5974 = (obj_t) (aux_5975);
	    }
	    STRUCT_SET(res1781_1903, ((long) 2), aux_5974);
	 }
	 {
	    obj_t aux_5979;
	    aux_5979 = (((capp_t) CREF(obj1780_1900))->args);
	    STRUCT_SET(res1781_1903, ((long) 3), aux_5979);
	 }
	 return res1781_1903;
      }
   }
}


/* struct+object->object-cfail */ obj_t 
struct_object__object_cfail_119_cgen_cop(obj_t env_3952, obj_t o_3953, obj_t s_3954)
{
   {
      cfail_t o_1889;
      obj_t s_1890;
      {
	 cfail_t aux_5983;
	 o_1889 = (cfail_t) (o_3953);
	 s_1890 = s_3954;
	 {
	    obj_t aux_5986;
	    object_t aux_5984;
	    aux_5986 = STRUCT_REF(s_1890, ((long) 0));
	    aux_5984 = (object_t) (o_1889);
	    OBJECT_WIDENING_SET(aux_5984, aux_5986);
	 }
	 {
	    obj_t v1806_1894;
	    v1806_1894 = STRUCT_REF(s_1890, ((long) 1));
	    ((((cfail_t) CREF(o_1889))->loc) = ((obj_t) v1806_1894), BUNSPEC);
	 }
	 {
	    cop_t v1810_1895;
	    {
	       obj_t aux_5991;
	       aux_5991 = STRUCT_REF(s_1890, ((long) 2));
	       v1810_1895 = (cop_t) (aux_5991);
	    }
	    ((((cfail_t) CREF(o_1889))->proc) = ((cop_t) v1810_1895), BUNSPEC);
	 }
	 {
	    cop_t v1814_1896;
	    {
	       obj_t aux_5995;
	       aux_5995 = STRUCT_REF(s_1890, ((long) 3));
	       v1814_1896 = (cop_t) (aux_5995);
	    }
	    ((((cfail_t) CREF(o_1889))->msg) = ((cop_t) v1814_1896), BUNSPEC);
	 }
	 {
	    cop_t v1818_1897;
	    {
	       obj_t aux_5999;
	       aux_5999 = STRUCT_REF(s_1890, ((long) 4));
	       v1818_1897 = (cop_t) (aux_5999);
	    }
	    ((((cfail_t) CREF(o_1889))->obj) = ((cop_t) v1818_1897), BUNSPEC);
	 }
	 aux_5983 = o_1889;
	 return (obj_t) (aux_5983);
      }
   }
}


/* object->struct-cfail */ obj_t 
object__struct_cfail_230_cgen_cop(obj_t env_3955, obj_t obj1802_3956)
{
   {
      cfail_t obj1802_1873;
      obj1802_1873 = (cfail_t) (obj1802_3956);
      {
	 obj_t res1803_1876;
	 {
	    obj_t aux_6005;
	    aux_6005 = CNST_TABLE_REF(((long) 19));
	    res1803_1876 = make_struct(aux_6005, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1803_1876, ((long) 0), BFALSE);
	 {
	    obj_t aux_6009;
	    aux_6009 = (((cfail_t) CREF(obj1802_1873))->loc);
	    STRUCT_SET(res1803_1876, ((long) 1), aux_6009);
	 }
	 {
	    obj_t aux_6012;
	    {
	       cop_t aux_6013;
	       aux_6013 = (((cfail_t) CREF(obj1802_1873))->proc);
	       aux_6012 = (obj_t) (aux_6013);
	    }
	    STRUCT_SET(res1803_1876, ((long) 2), aux_6012);
	 }
	 {
	    obj_t aux_6017;
	    {
	       cop_t aux_6018;
	       aux_6018 = (((cfail_t) CREF(obj1802_1873))->msg);
	       aux_6017 = (obj_t) (aux_6018);
	    }
	    STRUCT_SET(res1803_1876, ((long) 3), aux_6017);
	 }
	 {
	    obj_t aux_6022;
	    {
	       cop_t aux_6023;
	       aux_6023 = (((cfail_t) CREF(obj1802_1873))->obj);
	       aux_6022 = (obj_t) (aux_6023);
	    }
	    STRUCT_SET(res1803_1876, ((long) 4), aux_6022);
	 }
	 return res1803_1876;
      }
   }
}


/* struct+object->object-cswitch */ obj_t 
struct_object__object_cswitch_246_cgen_cop(obj_t env_3957, obj_t o_3958, obj_t s_3959)
{
   {
      cswitch_t o_1863;
      obj_t s_1864;
      {
	 cswitch_t aux_6028;
	 o_1863 = (cswitch_t) (o_3958);
	 s_1864 = s_3959;
	 {
	    obj_t aux_6031;
	    object_t aux_6029;
	    aux_6031 = STRUCT_REF(s_1864, ((long) 0));
	    aux_6029 = (object_t) (o_1863);
	    OBJECT_WIDENING_SET(aux_6029, aux_6031);
	 }
	 {
	    obj_t v1831_1868;
	    v1831_1868 = STRUCT_REF(s_1864, ((long) 1));
	    ((((cswitch_t) CREF(o_1863))->loc) = ((obj_t) v1831_1868), BUNSPEC);
	 }
	 {
	    cop_t v1835_1869;
	    {
	       obj_t aux_6036;
	       aux_6036 = STRUCT_REF(s_1864, ((long) 2));
	       v1835_1869 = (cop_t) (aux_6036);
	    }
	    ((((cswitch_t) CREF(o_1863))->test) = ((cop_t) v1835_1869), BUNSPEC);
	 }
	 {
	    obj_t v1839_1870;
	    v1839_1870 = STRUCT_REF(s_1864, ((long) 3));
	    ((((cswitch_t) CREF(o_1863))->clauses) = ((obj_t) v1839_1870), BUNSPEC);
	 }
	 aux_6028 = o_1863;
	 return (obj_t) (aux_6028);
      }
   }
}


/* object->struct-cswitch */ obj_t 
object__struct_cswitch_161_cgen_cop(obj_t env_3960, obj_t obj1827_3961)
{
   {
      cswitch_t obj1827_1849;
      obj1827_1849 = (cswitch_t) (obj1827_3961);
      {
	 obj_t res1828_1852;
	 {
	    obj_t aux_6044;
	    aux_6044 = CNST_TABLE_REF(((long) 20));
	    res1828_1852 = make_struct(aux_6044, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1828_1852, ((long) 0), BFALSE);
	 {
	    obj_t aux_6048;
	    aux_6048 = (((cswitch_t) CREF(obj1827_1849))->loc);
	    STRUCT_SET(res1828_1852, ((long) 1), aux_6048);
	 }
	 {
	    obj_t aux_6051;
	    {
	       cop_t aux_6052;
	       aux_6052 = (((cswitch_t) CREF(obj1827_1849))->test);
	       aux_6051 = (obj_t) (aux_6052);
	    }
	    STRUCT_SET(res1828_1852, ((long) 2), aux_6051);
	 }
	 {
	    obj_t aux_6056;
	    aux_6056 = (((cswitch_t) CREF(obj1827_1849))->clauses);
	    STRUCT_SET(res1828_1852, ((long) 3), aux_6056);
	 }
	 return res1828_1852;
      }
   }
}


/* struct+object->object-cmake-box */ obj_t 
struct_object__object_cmake_box_25_cgen_cop(obj_t env_3962, obj_t o_3963, obj_t s_3964)
{
   {
      cmake_box_177_t o_1840;
      obj_t s_1841;
      {
	 cmake_box_177_t aux_6060;
	 o_1840 = (cmake_box_177_t) (o_3963);
	 s_1841 = s_3964;
	 {
	    obj_t aux_6063;
	    object_t aux_6061;
	    aux_6063 = STRUCT_REF(s_1841, ((long) 0));
	    aux_6061 = (object_t) (o_1840);
	    OBJECT_WIDENING_SET(aux_6061, aux_6063);
	 }
	 {
	    obj_t v1851_1845;
	    v1851_1845 = STRUCT_REF(s_1841, ((long) 1));
	    ((((cmake_box_177_t) CREF(o_1840))->loc) = ((obj_t) v1851_1845), BUNSPEC);
	 }
	 {
	    cop_t v1855_1846;
	    {
	       obj_t aux_6068;
	       aux_6068 = STRUCT_REF(s_1841, ((long) 2));
	       v1855_1846 = (cop_t) (aux_6068);
	    }
	    ((((cmake_box_177_t) CREF(o_1840))->value) = ((cop_t) v1855_1846), BUNSPEC);
	 }
	 aux_6060 = o_1840;
	 return (obj_t) (aux_6060);
      }
   }
}


/* object->struct-cmake-box */ obj_t 
object__struct_cmake_box_32_cgen_cop(obj_t env_3965, obj_t obj1847_3966)
{
   {
      cmake_box_177_t obj1847_1828;
      obj1847_1828 = (cmake_box_177_t) (obj1847_3966);
      {
	 obj_t res1848_1831;
	 {
	    obj_t aux_6074;
	    aux_6074 = CNST_TABLE_REF(((long) 21));
	    res1848_1831 = make_struct(aux_6074, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1848_1831, ((long) 0), BFALSE);
	 {
	    obj_t aux_6078;
	    aux_6078 = (((cmake_box_177_t) CREF(obj1847_1828))->loc);
	    STRUCT_SET(res1848_1831, ((long) 1), aux_6078);
	 }
	 {
	    obj_t aux_6081;
	    {
	       cop_t aux_6082;
	       aux_6082 = (((cmake_box_177_t) CREF(obj1847_1828))->value);
	       aux_6081 = (obj_t) (aux_6082);
	    }
	    STRUCT_SET(res1848_1831, ((long) 2), aux_6081);
	 }
	 return res1848_1831;
      }
   }
}


/* struct+object->object-cbox-ref */ obj_t 
struct_object__object_cbox_ref_164_cgen_cop(obj_t env_3967, obj_t o_3968, obj_t s_3969)
{
   {
      cbox_ref_44_t o_1819;
      obj_t s_1820;
      {
	 cbox_ref_44_t aux_6087;
	 o_1819 = (cbox_ref_44_t) (o_3968);
	 s_1820 = s_3969;
	 {
	    obj_t aux_6090;
	    object_t aux_6088;
	    aux_6090 = STRUCT_REF(s_1820, ((long) 0));
	    aux_6088 = (object_t) (o_1819);
	    OBJECT_WIDENING_SET(aux_6088, aux_6090);
	 }
	 {
	    obj_t v1867_1824;
	    v1867_1824 = STRUCT_REF(s_1820, ((long) 1));
	    ((((cbox_ref_44_t) CREF(o_1819))->loc) = ((obj_t) v1867_1824), BUNSPEC);
	 }
	 {
	    cop_t v1871_1825;
	    {
	       obj_t aux_6095;
	       aux_6095 = STRUCT_REF(s_1820, ((long) 2));
	       v1871_1825 = (cop_t) (aux_6095);
	    }
	    ((((cbox_ref_44_t) CREF(o_1819))->var) = ((cop_t) v1871_1825), BUNSPEC);
	 }
	 aux_6087 = o_1819;
	 return (obj_t) (aux_6087);
      }
   }
}


/* object->struct-cbox-ref */ obj_t 
object__struct_cbox_ref_102_cgen_cop(obj_t env_3970, obj_t obj1863_3971)
{
   {
      cbox_ref_44_t obj1863_1807;
      obj1863_1807 = (cbox_ref_44_t) (obj1863_3971);
      {
	 obj_t res1864_1810;
	 {
	    obj_t aux_6101;
	    aux_6101 = CNST_TABLE_REF(((long) 22));
	    res1864_1810 = make_struct(aux_6101, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1864_1810, ((long) 0), BFALSE);
	 {
	    obj_t aux_6105;
	    aux_6105 = (((cbox_ref_44_t) CREF(obj1863_1807))->loc);
	    STRUCT_SET(res1864_1810, ((long) 1), aux_6105);
	 }
	 {
	    obj_t aux_6108;
	    {
	       cop_t aux_6109;
	       aux_6109 = (((cbox_ref_44_t) CREF(obj1863_1807))->var);
	       aux_6108 = (obj_t) (aux_6109);
	    }
	    STRUCT_SET(res1864_1810, ((long) 2), aux_6108);
	 }
	 return res1864_1810;
      }
   }
}


/* struct+object->object-cbox-set! */ obj_t 
struct_object__object_cbox_set__145_cgen_cop(obj_t env_3972, obj_t o_3973, obj_t s_3974)
{
   {
      cbox_set__132_t o_1797;
      obj_t s_1798;
      {
	 cbox_set__132_t aux_6114;
	 o_1797 = (cbox_set__132_t) (o_3973);
	 s_1798 = s_3974;
	 {
	    obj_t aux_6117;
	    object_t aux_6115;
	    aux_6117 = STRUCT_REF(s_1798, ((long) 0));
	    aux_6115 = (object_t) (o_1797);
	    OBJECT_WIDENING_SET(aux_6115, aux_6117);
	 }
	 {
	    obj_t v1884_1802;
	    v1884_1802 = STRUCT_REF(s_1798, ((long) 1));
	    ((((cbox_set__132_t) CREF(o_1797))->loc) = ((obj_t) v1884_1802), BUNSPEC);
	 }
	 {
	    cop_t v1888_1803;
	    {
	       obj_t aux_6122;
	       aux_6122 = STRUCT_REF(s_1798, ((long) 2));
	       v1888_1803 = (cop_t) (aux_6122);
	    }
	    ((((cbox_set__132_t) CREF(o_1797))->var) = ((cop_t) v1888_1803), BUNSPEC);
	 }
	 {
	    cop_t v1892_1804;
	    {
	       obj_t aux_6126;
	       aux_6126 = STRUCT_REF(s_1798, ((long) 3));
	       v1892_1804 = (cop_t) (aux_6126);
	    }
	    ((((cbox_set__132_t) CREF(o_1797))->value) = ((cop_t) v1892_1804), BUNSPEC);
	 }
	 aux_6114 = o_1797;
	 return (obj_t) (aux_6114);
      }
   }
}


/* object->struct-cbox-set! */ obj_t 
object__struct_cbox_set__79_cgen_cop(obj_t env_3975, obj_t obj1880_3976)
{
   {
      cbox_set__132_t obj1880_1783;
      obj1880_1783 = (cbox_set__132_t) (obj1880_3976);
      {
	 obj_t res1881_1786;
	 {
	    obj_t aux_6132;
	    aux_6132 = CNST_TABLE_REF(((long) 23));
	    res1881_1786 = make_struct(aux_6132, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1881_1786, ((long) 0), BFALSE);
	 {
	    obj_t aux_6136;
	    aux_6136 = (((cbox_set__132_t) CREF(obj1880_1783))->loc);
	    STRUCT_SET(res1881_1786, ((long) 1), aux_6136);
	 }
	 {
	    obj_t aux_6139;
	    {
	       cop_t aux_6140;
	       aux_6140 = (((cbox_set__132_t) CREF(obj1880_1783))->var);
	       aux_6139 = (obj_t) (aux_6140);
	    }
	    STRUCT_SET(res1881_1786, ((long) 2), aux_6139);
	 }
	 {
	    obj_t aux_6144;
	    {
	       cop_t aux_6145;
	       aux_6145 = (((cbox_set__132_t) CREF(obj1880_1783))->value);
	       aux_6144 = (obj_t) (aux_6145);
	    }
	    STRUCT_SET(res1881_1786, ((long) 3), aux_6144);
	 }
	 return res1881_1786;
      }
   }
}


/* struct+object->object-cset-ex-it */ obj_t 
struct_object__object_cset_ex_it_17_cgen_cop(obj_t env_3977, obj_t o_3978, obj_t s_3979)
{
   {
      cset_ex_it_123_t o_1772;
      obj_t s_1773;
      {
	 cset_ex_it_123_t aux_6150;
	 o_1772 = (cset_ex_it_123_t) (o_3978);
	 s_1773 = s_3979;
	 {
	    obj_t aux_6153;
	    object_t aux_6151;
	    aux_6153 = STRUCT_REF(s_1773, ((long) 0));
	    aux_6151 = (object_t) (o_1772);
	    OBJECT_WIDENING_SET(aux_6151, aux_6153);
	 }
	 {
	    obj_t v1906_1777;
	    v1906_1777 = STRUCT_REF(s_1773, ((long) 1));
	    ((((cset_ex_it_123_t) CREF(o_1772))->loc) = ((obj_t) v1906_1777), BUNSPEC);
	 }
	 {
	    cop_t v1910_1778;
	    {
	       obj_t aux_6158;
	       aux_6158 = STRUCT_REF(s_1773, ((long) 2));
	       v1910_1778 = (cop_t) (aux_6158);
	    }
	    ((((cset_ex_it_123_t) CREF(o_1772))->exit) = ((cop_t) v1910_1778), BUNSPEC);
	 }
	 {
	    cop_t v1914_1779;
	    {
	       obj_t aux_6162;
	       aux_6162 = STRUCT_REF(s_1773, ((long) 3));
	       v1914_1779 = (cop_t) (aux_6162);
	    }
	    ((((cset_ex_it_123_t) CREF(o_1772))->jump_value_221) = ((cop_t) v1914_1779), BUNSPEC);
	 }
	 {
	    cop_t v1918_1780;
	    {
	       obj_t aux_6166;
	       aux_6166 = STRUCT_REF(s_1773, ((long) 4));
	       v1918_1780 = (cop_t) (aux_6166);
	    }
	    ((((cset_ex_it_123_t) CREF(o_1772))->body) = ((cop_t) v1918_1780), BUNSPEC);
	 }
	 aux_6150 = o_1772;
	 return (obj_t) (aux_6150);
      }
   }
}


/* object->struct-cset-ex-it */ obj_t 
object__struct_cset_ex_it_165_cgen_cop(obj_t env_3980, obj_t obj1902_3981)
{
   {
      cset_ex_it_123_t obj1902_1756;
      obj1902_1756 = (cset_ex_it_123_t) (obj1902_3981);
      {
	 obj_t res1903_1759;
	 {
	    obj_t aux_6172;
	    aux_6172 = CNST_TABLE_REF(((long) 24));
	    res1903_1759 = make_struct(aux_6172, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1903_1759, ((long) 0), BFALSE);
	 {
	    obj_t aux_6176;
	    aux_6176 = (((cset_ex_it_123_t) CREF(obj1902_1756))->loc);
	    STRUCT_SET(res1903_1759, ((long) 1), aux_6176);
	 }
	 {
	    obj_t aux_6179;
	    {
	       cop_t aux_6180;
	       aux_6180 = (((cset_ex_it_123_t) CREF(obj1902_1756))->exit);
	       aux_6179 = (obj_t) (aux_6180);
	    }
	    STRUCT_SET(res1903_1759, ((long) 2), aux_6179);
	 }
	 {
	    obj_t aux_6184;
	    {
	       cop_t aux_6185;
	       aux_6185 = (((cset_ex_it_123_t) CREF(obj1902_1756))->jump_value_221);
	       aux_6184 = (obj_t) (aux_6185);
	    }
	    STRUCT_SET(res1903_1759, ((long) 3), aux_6184);
	 }
	 {
	    obj_t aux_6189;
	    {
	       cop_t aux_6190;
	       aux_6190 = (((cset_ex_it_123_t) CREF(obj1902_1756))->body);
	       aux_6189 = (obj_t) (aux_6190);
	    }
	    STRUCT_SET(res1903_1759, ((long) 4), aux_6189);
	 }
	 return res1903_1759;
      }
   }
}


/* struct+object->object-cjump-ex-it */ obj_t 
struct_object__object_cjump_ex_it_93_cgen_cop(obj_t env_3982, obj_t o_3983, obj_t s_3984)
{
   {
      cjump_ex_it_131_t o_1746;
      obj_t s_1747;
      {
	 cjump_ex_it_131_t aux_6195;
	 o_1746 = (cjump_ex_it_131_t) (o_3983);
	 s_1747 = s_3984;
	 {
	    obj_t aux_6198;
	    object_t aux_6196;
	    aux_6198 = STRUCT_REF(s_1747, ((long) 0));
	    aux_6196 = (object_t) (o_1746);
	    OBJECT_WIDENING_SET(aux_6196, aux_6198);
	 }
	 {
	    obj_t v1931_1751;
	    v1931_1751 = STRUCT_REF(s_1747, ((long) 1));
	    ((((cjump_ex_it_131_t) CREF(o_1746))->loc) = ((obj_t) v1931_1751), BUNSPEC);
	 }
	 {
	    cop_t v1935_1752;
	    {
	       obj_t aux_6203;
	       aux_6203 = STRUCT_REF(s_1747, ((long) 2));
	       v1935_1752 = (cop_t) (aux_6203);
	    }
	    ((((cjump_ex_it_131_t) CREF(o_1746))->exit) = ((cop_t) v1935_1752), BUNSPEC);
	 }
	 {
	    cop_t v1939_1753;
	    {
	       obj_t aux_6207;
	       aux_6207 = STRUCT_REF(s_1747, ((long) 3));
	       v1939_1753 = (cop_t) (aux_6207);
	    }
	    ((((cjump_ex_it_131_t) CREF(o_1746))->value) = ((cop_t) v1939_1753), BUNSPEC);
	 }
	 aux_6195 = o_1746;
	 return (obj_t) (aux_6195);
      }
   }
}


/* object->struct-cjump-ex-it */ obj_t 
object__struct_cjump_ex_it_155_cgen_cop(obj_t env_3985, obj_t obj1927_3986)
{
   {
      cjump_ex_it_131_t obj1927_1732;
      obj1927_1732 = (cjump_ex_it_131_t) (obj1927_3986);
      {
	 obj_t res1928_1735;
	 {
	    obj_t aux_6213;
	    aux_6213 = CNST_TABLE_REF(((long) 25));
	    res1928_1735 = make_struct(aux_6213, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1928_1735, ((long) 0), BFALSE);
	 {
	    obj_t aux_6217;
	    aux_6217 = (((cjump_ex_it_131_t) CREF(obj1927_1732))->loc);
	    STRUCT_SET(res1928_1735, ((long) 1), aux_6217);
	 }
	 {
	    obj_t aux_6220;
	    {
	       cop_t aux_6221;
	       aux_6221 = (((cjump_ex_it_131_t) CREF(obj1927_1732))->exit);
	       aux_6220 = (obj_t) (aux_6221);
	    }
	    STRUCT_SET(res1928_1735, ((long) 2), aux_6220);
	 }
	 {
	    obj_t aux_6225;
	    {
	       cop_t aux_6226;
	       aux_6226 = (((cjump_ex_it_131_t) CREF(obj1927_1732))->value);
	       aux_6225 = (obj_t) (aux_6226);
	    }
	    STRUCT_SET(res1928_1735, ((long) 3), aux_6225);
	 }
	 return res1928_1735;
      }
   }
}


/* struct+object->object-sfun/c */ obj_t 
struct_object__object_sfun_c_84_cgen_cop(obj_t env_3987, obj_t o_3988, obj_t s_3989)
{
   {
      sfun_c_188_t o_1719;
      obj_t s_1720;
      {
	 sfun_c_188_t aux_6231;
	 o_1719 = (sfun_c_188_t) (o_3988);
	 s_1720 = s_3989;
	 {
	    {
	       obj_t old1963_1723;
	       obj_t aux1964_1724;
	       {
		  obj_t next_method1985_37_1730;
		  next_method1985_37_1730 = find_super_class_method_167___object((object_t) (o_1719), struct_object__object_env_209___object, sfun_c_188_cgen_cop);
		  if (PROCEDUREP(next_method1985_37_1730))
		    {
		       old1963_1723 = PROCEDURE_ENTRY(next_method1985_37_1730) (next_method1985_37_1730, (obj_t) (o_1719), s_1720, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1985_37_1730);
		       {
			  object_t aux_6240;
			  aux_6240 = struct_object__object_93___object((object_t) (o_1719), s_1720);
			  old1963_1723 = (obj_t) (aux_6240);
		       }
		    }
	       }
	       aux1964_1724 = STRUCT_REF(s_1720, ((long) 0));
	       {
		  sfun_c_188_t new1965_1725;
		  new1965_1725 = ((sfun_c_188_t) (old1963_1723));
		  {
		     long arg2328_1726;
		     arg2328_1726 = class_num_218___object(sfun_c_188_cgen_cop);
		     {
			obj_t obj_2667;
			obj_2667 = (obj_t) (new1965_1725);
			(((obj_t) CREF(obj_2667))->header = MAKE_HEADER(arg2328_1726, 0), BUNSPEC);
		     }
		  }
		  {
		     sfun_c_188_t arg2329_1727;
		     {
			sfun_c_188_t res2626_2678;
			{
			   clabel_t label_2673;
			   bool_t integrated_2674;
			   {
			      obj_t aux_6249;
			      aux_6249 = STRUCT_REF(aux1964_1724, ((long) 0));
			      label_2673 = (clabel_t) (aux_6249);
			   }
			   {
			      obj_t aux_6252;
			      aux_6252 = STRUCT_REF(aux1964_1724, ((long) 1));
			      integrated_2674 = CBOOL(aux_6252);
			   }
			   {
			      sfun_c_188_t new1941_2675;
			      new1941_2675 = ((sfun_c_188_t) BREF(GC_MALLOC(sizeof(struct sfun_c_188))));
			      ((((sfun_c_188_t) CREF(new1941_2675))->label) = ((clabel_t) label_2673), BUNSPEC);
			      ((((sfun_c_188_t) CREF(new1941_2675))->integrated) = ((bool_t) integrated_2674), BUNSPEC);
			      res2626_2678 = new1941_2675;
			   }
			}
			arg2329_1727 = res2626_2678;
		     }
		     {
			obj_t aux_6260;
			object_t aux_6258;
			aux_6260 = (obj_t) (arg2329_1727);
			aux_6258 = (object_t) (new1965_1725);
			OBJECT_WIDENING_SET(aux_6258, aux_6260);
		     }
		  }
		  aux_6231 = new1965_1725;
	       }
	    }
	 }
	 return (obj_t) (aux_6231);
      }
   }
}


/* object->struct-sfun/c */ obj_t 
object__struct_sfun_c_73_cgen_cop(obj_t env_3990, obj_t obj1960_3991)
{
   {
      sfun_c_188_t obj1960_1704;
      obj1960_1704 = (sfun_c_188_t) (obj1960_3991);
      {
	 {
	    obj_t res1961_1707;
	    {
	       obj_t next_method1984_69_1717;
	       next_method1984_69_1717 = find_super_class_method_167___object((object_t) (obj1960_1704), object__struct_env_210___object, sfun_c_188_cgen_cop);
	       if (PROCEDUREP(next_method1984_69_1717))
		 {
		    res1961_1707 = PROCEDURE_ENTRY(next_method1984_69_1717) (next_method1984_69_1717, (obj_t) (obj1960_1704), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1984_69_1717);
		    res1961_1707 = object__struct_50___object((object_t) (obj1960_1704));
		 }
	    }
	    {
	       obj_t aux1962_1708;
	       {
		  obj_t aux_6275;
		  aux_6275 = CNST_TABLE_REF(((long) 26));
		  aux1962_1708 = make_struct(aux_6275, ((long) 2), BUNSPEC);
	       }
	       {
		  obj_t aux_6278;
		  {
		     clabel_t aux_6279;
		     {
			obj_t aux_6280;
			{
			   object_t aux_6281;
			   aux_6281 = (object_t) (obj1960_1704);
			   aux_6280 = OBJECT_WIDENING(aux_6281);
			}
			aux_6279 = (((sfun_c_188_t) CREF(aux_6280))->label);
		     }
		     aux_6278 = (obj_t) (aux_6279);
		  }
		  STRUCT_SET(aux1962_1708, ((long) 0), aux_6278);
	       }
	       {
		  obj_t aux_6287;
		  {
		     bool_t aux_6288;
		     {
			obj_t aux_6289;
			{
			   object_t aux_6290;
			   aux_6290 = (object_t) (obj1960_1704);
			   aux_6289 = OBJECT_WIDENING(aux_6290);
			}
			aux_6288 = (((sfun_c_188_t) CREF(aux_6289))->integrated);
		     }
		     aux_6287 = BBOOL(aux_6288);
		  }
		  STRUCT_SET(aux1962_1708, ((long) 1), aux_6287);
	       }
	       STRUCT_SET(res1961_1707, ((long) 0), aux1962_1708);
	       {
		  obj_t aux_6297;
		  aux_6297 = STRUCT_KEY(res1961_1707);
		  STRUCT_KEY_SET(aux1962_1708, aux_6297);
	       }
	       {
		  obj_t aux_6300;
		  aux_6300 = CNST_TABLE_REF(((long) 26));
		  STRUCT_KEY_SET(res1961_1707, aux_6300);
	       }
	       return res1961_1707;
	    }
	 }
      }
   }
}


/* struct+object->object-bdb-block */ obj_t 
struct_object__object_bdb_block_117_cgen_cop(obj_t env_3992, obj_t o_3993, obj_t s_3994)
{
   {
      bdb_block_21_t o_1695;
      obj_t s_1696;
      {
	 bdb_block_21_t aux_6304;
	 o_1695 = (bdb_block_21_t) (o_3993);
	 s_1696 = s_3994;
	 {
	    obj_t aux_6307;
	    object_t aux_6305;
	    aux_6307 = STRUCT_REF(s_1696, ((long) 0));
	    aux_6305 = (object_t) (o_1695);
	    OBJECT_WIDENING_SET(aux_6305, aux_6307);
	 }
	 {
	    obj_t v1976_1700;
	    v1976_1700 = STRUCT_REF(s_1696, ((long) 1));
	    ((((bdb_block_21_t) CREF(o_1695))->loc) = ((obj_t) v1976_1700), BUNSPEC);
	 }
	 {
	    cop_t v1980_1701;
	    {
	       obj_t aux_6312;
	       aux_6312 = STRUCT_REF(s_1696, ((long) 2));
	       v1980_1701 = (cop_t) (aux_6312);
	    }
	    ((((bdb_block_21_t) CREF(o_1695))->body) = ((cop_t) v1980_1701), BUNSPEC);
	 }
	 aux_6304 = o_1695;
	 return (obj_t) (aux_6304);
      }
   }
}


/* object->struct-bdb-block */ obj_t 
object__struct_bdb_block_145_cgen_cop(obj_t env_3995, obj_t obj1972_3996)
{
   {
      bdb_block_21_t obj1972_1683;
      obj1972_1683 = (bdb_block_21_t) (obj1972_3996);
      {
	 obj_t res1973_1686;
	 {
	    obj_t aux_6318;
	    aux_6318 = CNST_TABLE_REF(((long) 27));
	    res1973_1686 = make_struct(aux_6318, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1973_1686, ((long) 0), BFALSE);
	 {
	    obj_t aux_6322;
	    aux_6322 = (((bdb_block_21_t) CREF(obj1972_1683))->loc);
	    STRUCT_SET(res1973_1686, ((long) 1), aux_6322);
	 }
	 {
	    obj_t aux_6325;
	    {
	       cop_t aux_6326;
	       aux_6326 = (((bdb_block_21_t) CREF(obj1972_1683))->body);
	       aux_6325 = (obj_t) (aux_6326);
	    }
	    STRUCT_SET(res1973_1686, ((long) 2), aux_6325);
	 }
	 return res1973_1686;
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cgen_cop()
{
   module_initialization_70_type_type(((long) 0), "CGEN_COP");
   module_initialization_70_ast_var(((long) 0), "CGEN_COP");
   return module_initialization_70_ast_node(((long) 0), "CGEN_COP");
}
