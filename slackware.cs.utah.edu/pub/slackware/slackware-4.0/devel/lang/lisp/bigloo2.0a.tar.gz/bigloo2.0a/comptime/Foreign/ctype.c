/*===========================================================================*/
/*   (Foreign/ctype.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct calias
  {
     bool_t array__248;
  }
      *calias_t;

typedef struct cenum
  {
     struct type *btype;
     obj_t literals;
  }
     *cenum_t;

typedef struct cfunction
  {
     struct type *btype;
     long arity;
     struct type *type_res_48;
     obj_t type_args_244;
  }
         *cfunction_t;

typedef struct cptr
  {
     struct type *btype;
     struct type *point_to_164;
     bool_t array__248;
  }
    *cptr_t;

typedef struct cstruct
  {
     bool_t struct__46;
     obj_t fields;
     obj_t cstruct__170;
  }
       *cstruct_t;

typedef struct cstruct__170
  {
     struct type *btype;
     struct cstruct *cstruct;
  }
            *cstruct__170_t;


extern obj_t cptr_name_23_foreign_ctype(type_t);
static obj_t _cptr_btype1940_10_foreign_ctype(obj_t, obj_t);
extern obj_t cptr_name_set__65_foreign_ctype(type_t, obj_t);
static obj_t _cenum_btype1997_132_foreign_ctype(obj_t, obj_t);
extern obj_t cfunction_alias_134_foreign_ctype(type_t);
extern obj_t cenum_coerce_to_set__113_foreign_ctype(type_t, obj_t);
static obj_t _cptr_init_1929_151_foreign_ctype(obj_t, obj_t);
static obj_t _cfunction___set_1960_53_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t method_init_76_foreign_ctype();
extern obj_t cstruct__size_set__210_foreign_ctype(type_t, obj_t);
static obj_t _cptr_parents_set_1926_4_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cstruct_size_set__133_foreign_ctype(type_t, obj_t);
extern obj_t cstruct_pointed_to_by_set__16_foreign_ctype(type_t, obj_t);
static obj_t _cenum_init_1986_19_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct_cstruct__set_1913_24_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cstruct_id1888_251_foreign_ctype(obj_t, obj_t);
static obj_t _cptr__176_foreign_ctype(obj_t, obj_t);
extern obj_t cfunction_class_set__229_foreign_ctype(type_t, obj_t);
extern obj_t cenum_literals_124_foreign_ctype(cenum_t);
extern bool_t cstruct_init__254_foreign_ctype(type_t);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t _cfunction_class1951_36_foreign_ctype(obj_t, obj_t);
extern bool_t cstruct__188_foreign_ctype(obj_t);
static obj_t _make_cfunction1944_30_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t calias_name_11_foreign_ctype(type_t);
extern obj_t cptr_tvector_set__194_foreign_ctype(type_t, obj_t);
obj_t cstruct__170_foreign_ctype = BUNSPEC;
static type_t declare_c_enum__96_foreign_ctype(obj_t, obj_t, obj_t);
extern bool_t calias_array__53_foreign_ctype(calias_t);
extern bool_t cenum_init__104_foreign_ctype(type_t);
static obj_t object__struct_cptr_2_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct__id1862_28_foreign_ctype(obj_t, obj_t);
extern obj_t cenum_id_181_foreign_ctype(type_t);
extern obj_t cstruct_cstruct__58_foreign_ctype(cstruct_t);
extern obj_t calias_pointed_to_by_168_foreign_ctype(type_t);
static obj_t struct_object__object_calias_28_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cfunction_parents_set_1954_155_foreign_ctype(obj_t, obj_t, obj_t);
extern bool_t cstruct_magic__87_foreign_ctype(type_t);
static obj_t _object__struct2029_225___object(obj_t, obj_t);
extern obj_t type_type_type;
static obj_t _cfunction_name1947_221_foreign_ctype(obj_t, obj_t);
extern obj_t cstruct___set__137_foreign_ctype(type_t, obj_t);
static obj_t _widening1003_cenum1972_19_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cstruct__name1864_107_foreign_ctype(obj_t, obj_t);
static obj_t _cfunction_alias_set_1962_74_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t calias_class_set__218_foreign_ctype(type_t, obj_t);
extern obj_t string_sans___40_type_tools(obj_t);
static obj_t _calias_size_set_2003_67_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _allocate_cstruct_15_foreign_ctype(obj_t);
static obj_t _cstruct_fields1912_50_foreign_ctype(obj_t, obj_t);
extern bool_t calias_magic__158_foreign_ctype(type_t);
static obj_t _cfunction_size1949_201_foreign_ctype(obj_t, obj_t);
static obj_t _cptr_init__set_1928_69_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cenum_tvector_set_1995_73_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cenum_parents_set__114_foreign_ctype(type_t, obj_t);
static obj_t _cstruct__size1866_255_foreign_ctype(obj_t, obj_t);
extern obj_t warning___error(obj_t);
static obj_t _cstruct__parents_set_1871_149_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _widening1004_cfunction1943_26_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t calias___set__245_foreign_ctype(type_t, obj_t);
extern obj_t calias_tvector_113_foreign_ctype(type_t);
extern bool_t calias_init__198_foreign_ctype(type_t);
extern obj_t cstruct_coerce_to_set__7_foreign_ctype(type_t, obj_t);
static obj_t _declare_c_type_1859_219_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t cstruct_class_110_foreign_ctype(type_t);
static obj_t _cptr_name1919_43_foreign_ctype(obj_t, obj_t);
static obj_t object__struct_cstruct__194_foreign_ctype(obj_t, obj_t);
static obj_t _cfunction_class_set_1950_25_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t struct_object__object_cptr_119_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cenum_magic__set_1987_48_foreign_ctype(obj_t, obj_t, obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t cenum_class_5_foreign_ctype(type_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _cptr_size_set_1920_144_foreign_ctype(obj_t, obj_t, obj_t);
extern bool_t cptr_array__44_foreign_ctype(cptr_t);
static obj_t _cstruct___set_1903_92_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _allocate_cstruct__211_foreign_ctype(obj_t);
extern type_t declare_aliastype__27_type_env(obj_t, obj_t, obj_t, type_t);
extern obj_t declare_c_type__49_foreign_ctype(obj_t, obj_t, obj_t, obj_t);
extern obj_t _obj__252_type_cache;
static obj_t _cstruct___1878_35_foreign_ctype(obj_t, obj_t);
extern obj_t calias_magic__set__219_foreign_ctype(type_t, bool_t);
static obj_t _calias_class2006_123_foreign_ctype(obj_t, obj_t);
static obj_t _cptr_size1921_214_foreign_ctype(obj_t, obj_t);
extern obj_t cstruct_cstruct__set__66_foreign_ctype(cstruct_t, obj_t);
static obj_t _cstruct_tvector_set_1909_49_foreign_ctype(obj_t, obj_t, obj_t);
extern bool_t cenum_magic__102_foreign_ctype(type_t);
static obj_t _cptr_point_to1941_63_foreign_ctype(obj_t, obj_t);
extern obj_t cenum___set__140_foreign_ctype(type_t, obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern obj_t args___args_list_50_tools_args(obj_t);
extern obj_t cstruct__pointed_to_by_set__253_foreign_ctype(type_t, obj_t);
extern obj_t cptr_coerce_to_35_foreign_ctype(type_t);
extern obj_t cstruct__alias_set__14_foreign_ctype(type_t, obj_t);
extern type_t allocate_cstruct__181_foreign_ctype();
extern obj_t cenum_alias_set__5_foreign_ctype(type_t, obj_t);
static obj_t _cenum_pointed_to_by1994_118_foreign_ctype(obj_t, obj_t);
extern obj_t cstruct__size_205_foreign_ctype(type_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern type_t allocate_cstruct_27_foreign_ctype();
extern obj_t cstruct_alias_118_foreign_ctype(type_t);
static obj_t _cstruct_pointed_to_by_set_1907_148_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cstruct_alias_set__11_foreign_ctype(type_t, obj_t);
static obj_t _cstruct__magic__set_1875_54_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cfunction_parents_200_foreign_ctype(type_t);
static obj_t _cfunction_size_set_1948_79_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cenum_alias_245_foreign_ctype(type_t);
extern bool_t cptr_magic__160_foreign_ctype(type_t);
extern cstruct__170_t make_cstruct__157_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t, obj_t, obj_t, obj_t, type_t, cstruct_t);
static obj_t _calias__2016_88_foreign_ctype(obj_t, obj_t);
extern obj_t cptr_pointed_to_by_set__176_foreign_ctype(type_t, obj_t);
extern cfunction_t widening1004_cfunction_132_foreign_ctype(type_t, long, type_t, obj_t);
static obj_t _cptr_pointed_to_by1937_55_foreign_ctype(obj_t, obj_t);
extern obj_t cptr_tvector_165_foreign_ctype(type_t);
extern obj_t cptr___set__200_foreign_ctype(type_t, obj_t);
extern obj_t module_initialization_70_foreign_ctype(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t calias_class_74_foreign_ctype(type_t);
static obj_t _cstruct__pointed_to_by1882_106_foreign_ctype(obj_t, obj_t);
extern type_t allocate_cfunction_24_foreign_ctype();
extern obj_t cptr___8_foreign_ctype(type_t);
static obj_t _widening1006_cstruct_89_foreign_ctype(obj_t, obj_t, obj_t, obj_t);
static obj_t _calias_array__set_2023_137_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cfunction_pointed_to_by_set_1964_24_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cfunction_tvector1967_127_foreign_ctype(obj_t, obj_t);
obj_t cptr_foreign_ctype = BUNSPEC;
extern type_t cfunction_type_res_120_foreign_ctype(cfunction_t);
extern obj_t cptr_init__set__182_foreign_ctype(type_t, bool_t);
static obj_t _widening1007_cstruct_1860_48_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cptr___set_1932_61_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _calias_tvector_set_2021_223_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cfunction_magic_1959_239_foreign_ctype(obj_t, obj_t);
extern obj_t cptr_size_set__35_foreign_ctype(type_t, obj_t);
static obj_t _cstruct__init__set_1873_51_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t calias_coerce_to_set__100_foreign_ctype(type_t, obj_t);
extern obj_t cstruct__name_49_foreign_ctype(type_t);
extern obj_t cstruct_tvector_set__212_foreign_ctype(type_t, obj_t);
static obj_t _cptr_id1917_233_foreign_ctype(obj_t, obj_t);
extern obj_t calias_parents_set__116_foreign_ctype(type_t, obj_t);
static obj_t _calias___set_2015_38_foreign_ctype(obj_t, obj_t, obj_t);
extern cenum_t widening1003_cenum_43_foreign_ctype(type_t, obj_t);
extern obj_t cfunction_coerce_to_set__196_foreign_ctype(type_t, obj_t);
static obj_t _cptr_alias_set_1934_211_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cstruct__tvector_148_foreign_ctype(type_t);
static obj_t _cfunction_parents1955_40_foreign_ctype(obj_t, obj_t);
extern obj_t cptr_pointed_to_by_194_foreign_ctype(type_t);
static obj_t _calias_name_set_2001_205_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cfunction_type_args1971_56_foreign_ctype(obj_t, obj_t);
extern long class_num_218___object(obj_t);
extern obj_t calias_pointed_to_by_set__239_foreign_ctype(type_t, obj_t);
extern obj_t calias_alias_8_foreign_ctype(type_t);
extern obj_t cenum_parents_29_foreign_ctype(type_t);
static obj_t _cenum_coerce_to_set_1981_153_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cstruct__class_set__61_foreign_ctype(type_t, obj_t);
extern obj_t cfunction_size_85_foreign_ctype(type_t);
static obj_t _widening1002_calias_170_foreign_ctype(obj_t, obj_t);
extern obj_t cenum_class_set__128_foreign_ctype(type_t, obj_t);
static obj_t _cptr_pointed_to_by_set_1936_151_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cenum_name1976_20_foreign_ctype(obj_t, obj_t);
extern obj_t cfunction_type_args_85_foreign_ctype(cfunction_t);
static obj_t _cstruct____set_1877_75_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cptr_class_set_1922_122_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cstruct_cstruct_1914_241_foreign_ctype(obj_t, obj_t);
extern type_t cstruct__btype_111_foreign_ctype(cstruct__170_t);
extern obj_t cstruct_class_set__32_foreign_ctype(type_t, obj_t);
static obj_t _cptr_name_set_1918_55_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cstruct__1904_16_foreign_ctype(obj_t, obj_t);
static obj_t _calias_coerce_to2008_173_foreign_ctype(obj_t, obj_t);
extern obj_t cenum_size_56_foreign_ctype(type_t);
static obj_t _cstruct_class1894_10_foreign_ctype(obj_t, obj_t);
static obj_t _cenum_size1978_23_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct__alias1880_170_foreign_ctype(obj_t, obj_t);
extern type_t find_type_26_type_env(obj_t);
static obj_t _cstruct_magic__set_1901_171_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cstruct_parents_88_foreign_ctype(type_t);
extern obj_t cfunction_pointed_to_by_151_foreign_ctype(type_t);
static obj_t object__struct_calias_54_foreign_ctype(obj_t, obj_t);
static obj_t imported_modules_init_94_foreign_ctype();
static obj_t _cstruct__tvector1884_54_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct_init__set_1899_10_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t cstruct___251_foreign_ctype(type_t);
extern bool_t cstruct___171_foreign_ctype(obj_t);
static obj_t _cfunction_coerce_to_set_1952_186_foreign_ctype(obj_t, obj_t, obj_t);
static type_t declare_c_struct___243_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _struct_object__object2027_42___object(obj_t, obj_t, obj_t);
static obj_t _cptr_coerce_to1925_103_foreign_ctype(obj_t, obj_t);
static obj_t _cenum_literals1998_64_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct__cstruct1886_96_foreign_ctype(obj_t, obj_t);
obj_t cstruct_foreign_ctype = BUNSPEC;
extern obj_t cfunction_name_21_foreign_ctype(type_t);
extern obj_t cptr_parents_set__163_foreign_ctype(type_t, obj_t);
static obj_t _cstruct_magic_1902_29_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct__btype1885_131_foreign_ctype(obj_t, obj_t);
static type_t declare_c_pointer__90_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cfunction_pointed_to_by_set__108_foreign_ctype(type_t, obj_t);
static obj_t _cfunction_alias1963_244_foreign_ctype(obj_t, obj_t);
static obj_t make_foreign_coercers_168_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct__parents1872_30_foreign_ctype(obj_t, obj_t);
extern obj_t cfunction_magic__set__231_foreign_ctype(type_t, bool_t);
extern obj_t cenum_name_176_foreign_ctype(type_t);
static obj_t _cstruct__init_1874_158_foreign_ctype(obj_t, obj_t);
static obj_t _cfunction_name_set_1946_158_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cptr_id_104_foreign_ctype(type_t);
extern bool_t type_exists__12_type_env(obj_t);
extern obj_t cstruct_fields_109_foreign_ctype(cstruct_t);
extern obj_t cstruct__magic__set__181_foreign_ctype(type_t, bool_t);
static type_t declare_c_function__152_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cfunction_init__set__153_foreign_ctype(type_t, bool_t);
static obj_t _cenum___set_1989_21_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cenum_pointed_to_by_86_foreign_ctype(type_t);
extern obj_t cfunction_tvector_set__184_foreign_ctype(type_t, obj_t);
static obj_t _cstruct__alias_set_1879_62_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cenum_init__set_1985_245_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cenum_magic__set__46_foreign_ctype(type_t, bool_t);
static obj_t _calias_pointed_to_by2020_19_foreign_ctype(obj_t, obj_t);
extern obj_t produce_module_clause__172_module_module(obj_t);
static obj_t _cfunction_btype1968_86_foreign_ctype(obj_t, obj_t);
static obj_t _allocate_cptr_1_foreign_ctype(obj_t);
static obj_t _cptr_class1923_142_foreign_ctype(obj_t, obj_t);
extern cfunction_t make_cfunction_198_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t, obj_t, obj_t, obj_t, type_t, long, type_t, obj_t);
static obj_t library_modules_init_112_foreign_ctype();
static obj_t struct_object__object_cstruct_172_foreign_ctype(obj_t, obj_t, obj_t);
extern cptr_t widening1005_cptr_244_foreign_ctype(type_t, type_t, bool_t);
static obj_t _cfunction_coerce_to1953_176_foreign_ctype(obj_t, obj_t);
extern obj_t cstruct__tvector_set__171_foreign_ctype(type_t, obj_t);
static obj_t _cenum_class1980_229_foreign_ctype(obj_t, obj_t);
extern bool_t cfunction__229_foreign_ctype(obj_t);
static obj_t _cfunction_init_1957_114_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct__size_set_1865_53_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cenum_size_set_1977_49_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cstruct_coerce_to_set_1895_194_foreign_ctype(obj_t, obj_t, obj_t);
extern cstruct_t widening1006_cstruct_174_foreign_ctype(bool_t, obj_t, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t _cstruct__class_set_1867_75_foreign_ctype(obj_t, obj_t, obj_t);
extern bool_t cstruct__init__248_foreign_ctype(type_t);
extern obj_t calias___14_foreign_ctype(type_t);
extern type_t cptr_btype_116_foreign_ctype(cptr_t);
static obj_t struct_object__object_cenum_149_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cenum_parents_set_1983_79_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _make_calias1999_199_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _widening1005_cptr1915_81_foreign_ctype(obj_t, obj_t, obj_t, obj_t);
extern obj_t cenum___188_foreign_ctype(type_t);
extern obj_t calias_init__set__16_foreign_ctype(type_t, bool_t);
static obj_t object__struct_cstruct_165_foreign_ctype(obj_t, obj_t);
static obj_t _cptr_magic_1931_25_foreign_ctype(obj_t, obj_t);
extern cstruct_t cstruct__cstruct_236_foreign_ctype(cstruct__170_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
extern obj_t cfunction_name_set__134_foreign_ctype(type_t, obj_t);
extern bool_t cptr__215_foreign_ctype(obj_t);
extern type_t use_type__231_type_env(obj_t);
static obj_t _cptr_coerce_to_set_1924_106_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t calias_name_set__248_foreign_ctype(type_t, obj_t);
extern obj_t cstruct__id_51_foreign_ctype(type_t);
static obj_t _cstruct__coerce_to_set_1869_25_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cptr_tvector_set_1938_234_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _calias_magic_2014_60_foreign_ctype(obj_t, obj_t);
static obj_t _cenum_id1974_44_foreign_ctype(obj_t, obj_t);
extern obj_t cfunction_tvector_181_foreign_ctype(type_t);
static obj_t object__struct_cenum_54_foreign_ctype(obj_t, obj_t);
static obj_t _calias__112_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct_pointed_to_by1908_245_foreign_ctype(obj_t, obj_t);
static type_t declare_c_alias__61_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern type_t allocate_calias_11_foreign_ctype();
obj_t cfunction_foreign_ctype = BUNSPEC;
extern obj_t cenum_name_set__100_foreign_ctype(type_t, obj_t);
static obj_t _calias_alias2018_43_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct_parents_set_1897_117_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cptr_coerce_to_set__10_foreign_ctype(type_t, obj_t);
extern calias_t widening1002_calias_172_foreign_ctype(bool_t);
static obj_t _cstruct_alias_set_1905_60_foreign_ctype(obj_t, obj_t, obj_t);
extern int arity_tools_args(obj_t);
static obj_t _cstruct_tvector1910_169_foreign_ctype(obj_t, obj_t);
extern type_t cfunction_btype_24_foreign_ctype(cfunction_t);
static obj_t _cenum_tvector1996_178_foreign_ctype(obj_t, obj_t);
extern bool_t cstruct_struct__141_foreign_ctype(cstruct_t);
static obj_t _cfunction_arity1969_95_foreign_ctype(obj_t, obj_t);
obj_t cenum_foreign_ctype = BUNSPEC;
extern obj_t cptr_magic__set__186_foreign_ctype(type_t, bool_t);
extern obj_t _cobj__54_type_cache;
static obj_t _cstruct_size_set_1891_20_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t object__struct_cfunction_148_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct__magic_1876_41_foreign_ctype(obj_t, obj_t);
static obj_t _cfunction_type_res1970_141_foreign_ctype(obj_t, obj_t);
static obj_t _cfunction_tvector_set_1966_191_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _calias_coerce_to_set_2007_153_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cstruct_class_set_1893_187_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cstruct__class_95_foreign_ctype(type_t);
extern obj_t cstruct_magic__set__168_foreign_ctype(type_t, bool_t);
extern obj_t cfunction_id_42_foreign_ctype(type_t);
static obj_t _cstruct_parents1898_169_foreign_ctype(obj_t, obj_t);
static obj_t _calias_init_2012_60_foreign_ctype(obj_t, obj_t);
static obj_t _cenum_parents1984_202_foreign_ctype(obj_t, obj_t);
static obj_t _calias_init__set_2011_201_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cenum_alias_set_1991_164_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cptr_alias_set__91_foreign_ctype(type_t, obj_t);
extern bool_t cstruct__magic__185_foreign_ctype(type_t);
extern obj_t cenum_tvector_92_foreign_ctype(type_t);
static obj_t _make_cptr1916_221_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t cstruct__pointed_to_by_43_foreign_ctype(type_t);
static obj_t _make_cstruct1887_248_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _cstruct__tvector_set_1883_89_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cstruct_parents_set__165_foreign_ctype(type_t, obj_t);
static obj_t _calias_parents_set_2009_52_foreign_ctype(obj_t, obj_t, obj_t);
extern bool_t calias__152_foreign_ctype(obj_t);
extern bool_t cptr_init__109_foreign_ctype(type_t);
extern obj_t cstruct____set__209_foreign_ctype(type_t, obj_t);
extern obj_t cstruct__name_set__191_foreign_ctype(type_t, obj_t);
extern obj_t cenum_tvector_set__58_foreign_ctype(type_t, obj_t);
extern obj_t cstruct_name_set__169_foreign_ctype(type_t, obj_t);
extern obj_t cstruct_size_252_foreign_ctype(type_t);
extern obj_t cstruct_pointed_to_by_198_foreign_ctype(type_t);
static obj_t _cptr_tvector1939_203_foreign_ctype(obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cenum_class_set_1979_23_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cptr_array_1942_178_foreign_ctype(obj_t, obj_t);
static obj_t _allocate_cenum_156_foreign_ctype(obj_t);
static obj_t struct_object__object_cstruct__130_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cenum_pointed_to_by_set__34_foreign_ctype(type_t, obj_t);
static obj_t _calias_magic__set_2013_54_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cstruct__name_set_1863_172_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cenum_name_set_1975_178_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _cstruct_struct_1911_122_foreign_ctype(obj_t, obj_t);
extern obj_t cstruct__alias_70_foreign_ctype(type_t);
extern obj_t cstruct_tvector_3_foreign_ctype(type_t);
static obj_t _cenum_magic_1988_186_foreign_ctype(obj_t, obj_t);
static obj_t _calias_array_2024_78_foreign_ctype(obj_t, obj_t);
static obj_t _cenum__1990_116_foreign_ctype(obj_t, obj_t);
static obj_t _cptr_parents1927_64_foreign_ctype(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _cptr_magic__set_1930_218_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t object_init_111_foreign_ctype();
static obj_t _calias_name2002_238_foreign_ctype(obj_t, obj_t);
extern bool_t cfunction_init__78_foreign_ctype(type_t);
static obj_t _cstruct___40_foreign_ctype(obj_t, obj_t);
extern obj_t cfunction_coerce_to_79_foreign_ctype(type_t);
static obj_t _calias_id2000_202_foreign_ctype(obj_t, obj_t);
extern type_t get_aliased_type_1_type_type(type_t);
static obj_t _allocate_cfunction_151_foreign_ctype(obj_t);
static obj_t _cstruct__coerce_to1870_126_foreign_ctype(obj_t, obj_t);
static obj_t _cenum_coerce_to1982_244_foreign_ctype(obj_t, obj_t);
extern obj_t calias_parents_208_foreign_ctype(type_t);
extern obj_t cstruct_name_51_foreign_ctype(type_t);
extern obj_t calias_coerce_to_176_foreign_ctype(type_t);
static obj_t _cenum_pointed_to_by_set_1993_135_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _allocate_calias_121_foreign_ctype(obj_t);
extern obj_t cstruct__init__set__144_foreign_ctype(type_t, bool_t);
static obj_t _cfunction__1961_93_foreign_ctype(obj_t, obj_t);
extern obj_t calias_array__set__238_foreign_ctype(calias_t, bool_t);
extern obj_t cenum_init__set__60_foreign_ctype(type_t, bool_t);
static obj_t _calias_size2004_229_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct_alias1906_110_foreign_ctype(obj_t, obj_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t cstruct_id_82_foreign_ctype(type_t);
extern bool_t cenum__97_foreign_ctype(obj_t);
extern obj_t cptr_class_set__116_foreign_ctype(type_t, obj_t);
extern obj_t cenum_coerce_to_61_foreign_ctype(type_t);
extern obj_t cptr_class_208_foreign_ctype(type_t);
extern obj_t cstruct_init__set__88_foreign_ctype(type_t, bool_t);
obj_t calias_foreign_ctype = BUNSPEC;
static obj_t _cfunction__240_foreign_ctype(obj_t, obj_t);
extern obj_t cfunction___70_foreign_ctype(type_t);
static obj_t _cptr__1933_82_foreign_ctype(obj_t, obj_t);
extern obj_t cfunction_size_set__97_foreign_ctype(type_t, obj_t);
static obj_t _cstruct_name_set_1889_66_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern cstruct__170_t widening1007_cstruct__84_foreign_ctype(type_t, cstruct_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t calias_size_set__23_foreign_ctype(type_t, obj_t);
static obj_t _calias_alias_set_2017_29_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t make_pointer_to_name_76_type_tools(type_t);
extern type_t cenum_btype_86_foreign_ctype(cenum_t);
extern obj_t cfunction_alias_set__135_foreign_ctype(type_t, obj_t);
static obj_t _cstruct_init_1900_136_foreign_ctype(obj_t, obj_t);
extern long cfunction_arity_21_foreign_ctype(cfunction_t);
static obj_t _cfunction_magic__set_1958_27_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t calias_tvector_set__197_foreign_ctype(type_t, obj_t);
extern obj_t cfunction_parents_set__120_foreign_ctype(type_t, obj_t);
extern calias_t make_calias_75_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t, obj_t, obj_t, obj_t, bool_t);
extern obj_t cenum_size_set__27_foreign_ctype(type_t, obj_t);
static obj_t _cfunction_pointed_to_by1965_21_foreign_ctype(obj_t, obj_t);
extern cstruct_t make_cstruct_17_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t);
extern obj_t cptr_size_68_foreign_ctype(type_t);
extern type_t cptr_point_to_238_foreign_ctype(cptr_t);
static obj_t _cfunction_init__set_1956_150_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _calias_tvector2022_106_foreign_ctype(obj_t, obj_t);
extern obj_t cfunction_class_142_foreign_ctype(type_t);
extern obj_t cptr_parents_193_foreign_ctype(type_t);
static obj_t _cstruct_coerce_to1896_225_foreign_ctype(obj_t, obj_t);
static obj_t _make_cstruct_1861_187_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _cstruct_name1890_224_foreign_ctype(obj_t, obj_t);
extern obj_t cptr_alias_0_foreign_ctype(type_t);
static obj_t _cenum__111_foreign_ctype(obj_t, obj_t);
static obj_t _calias_class_set_2005_119_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t object__struct_50___object(object_t);
extern type_t declare_subtype__66_type_env(obj_t, obj_t, obj_t, obj_t);
static type_t declare_c_struct__84_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _make_cenum1973_207_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t cstruct__parents_set__224_foreign_ctype(type_t, obj_t);
static obj_t require_initialization_114_foreign_ctype = BUNSPEC;
static obj_t _cptr_alias1935_162_foreign_ctype(obj_t, obj_t);
extern obj_t calias_id_19_foreign_ctype(type_t);
extern obj_t cstruct__coerce_to_8_foreign_ctype(type_t);
extern type_t allocate_cenum_165_foreign_ctype();
extern obj_t cstruct_coerce_to_171_foreign_ctype(type_t);
static obj_t _cenum_alias1992_58_foreign_ctype(obj_t, obj_t);
extern bool_t cfunction_magic__129_foreign_ctype(type_t);
extern obj_t cstruct____54_foreign_ctype(type_t);
static obj_t _cstruct_size1892_126_foreign_ctype(obj_t, obj_t);
extern obj_t calias_size_17_foreign_ctype(type_t);
static obj_t _cstruct__pointed_to_by_set_1881_39_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t _calias_parents2010_113_foreign_ctype(obj_t, obj_t);
static obj_t _cstruct__158_foreign_ctype(obj_t, obj_t);
static obj_t _cfunction_id1945_146_foreign_ctype(obj_t, obj_t);
extern obj_t calias_alias_set__200_foreign_ctype(type_t, obj_t);
extern obj_t cfunction___set__14_foreign_ctype(type_t, obj_t);
static obj_t struct_object__object_cfunction_210_foreign_ctype(obj_t, obj_t, obj_t);
static obj_t cnst_init_137_foreign_ctype();
extern obj_t cstruct__parents_225_foreign_ctype(type_t);
static obj_t _cstruct__class1868_56_foreign_ctype(obj_t, obj_t);
extern cenum_t make_cenum_38_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t, obj_t, obj_t, obj_t, type_t, obj_t);
extern type_t allocate_cptr_217_foreign_ctype();
extern cptr_t make_cptr_169_foreign_ctype(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t, obj_t, obj_t, obj_t, type_t, type_t, bool_t);
static obj_t _calias_pointed_to_by_set_2019_43_foreign_ctype(obj_t, obj_t, obj_t);
extern obj_t cstruct__coerce_to_set__200_foreign_ctype(type_t, obj_t);
static obj_t __cnst[28];

DEFINE_EXPORT_PROCEDURE(calias__env_114_foreign_ctype, _calias__112_foreign_ctype2053, _calias__112_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_fields_env_45_foreign_ctype, _cstruct_fields1912_50_foreign_ctype2054, _cstruct_fields1912_50_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__parents_set__env_33_foreign_ctype, _cstruct__parents_set_1871_149_foreign_ctype2055, _cstruct__parents_set_1871_149_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias_name_set__env_124_foreign_ctype, _calias_name_set_2001_205_foreign_ctype2056, _calias_name_set_2001_205_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_size_env_171_foreign_ctype, _cfunction_size1949_201_foreign_ctype2057, _cfunction_size1949_201_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1003_cenum_env_37_foreign_ctype, _widening1003_cenum1972_19_foreign_ctype2058, _widening1003_cenum1972_19_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias_size_env_195_foreign_ctype, _calias_size2004_229_foreign_ctype2059, _calias_size2004_229_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_size_env_88_foreign_ctype, _cenum_size1978_23_foreign_ctype2060, _cenum_size1978_23_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct____set__env_78_foreign_ctype, _cstruct____set_1877_75_foreign_ctype2061, _cstruct____set_1877_75_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum___set__env_143_foreign_ctype, _cenum___set_1989_21_foreign_ctype2062, _cenum___set_1989_21_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction___env_79_foreign_ctype, _cfunction__1961_93_foreign_ctype2063, _cfunction__1961_93_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_name_env_241_foreign_ctype, _cptr_name1919_43_foreign_ctype2064, _cptr_name1919_43_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_class_set__env_159_foreign_ctype, _cptr_class_set_1922_122_foreign_ctype2065, _cptr_class_set_1922_122_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct___set__env_77_foreign_ctype, _cstruct___set_1903_92_foreign_ctype2066, _cstruct___set_1903_92_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum_pointed_to_by_set__env_70_foreign_ctype, _cenum_pointed_to_by_set_1993_135_foreign_ctype2067, _cenum_pointed_to_by_set_1993_135_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cptr_size_set__env_44_foreign_ctype, _cptr_size_set_1920_144_foreign_ctype2068, _cptr_size_set_1920_144_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias_magic__env_48_foreign_ctype, _calias_magic_2014_60_foreign_ctype2069, _calias_magic_2014_60_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_cstruct__env_81_foreign_ctype, _cstruct_cstruct_1914_241_foreign_ctype2070, _cstruct_cstruct_1914_241_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_tvector_set__env_81_foreign_ctype, _cenum_tvector_set_1995_73_foreign_ctype2071, _cenum_tvector_set_1995_73_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cptr_size_env_179_foreign_ctype, _cptr_size1921_214_foreign_ctype2072, _cptr_size1921_214_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_coerce_to_env_239_foreign_ctype, _calias_coerce_to2008_173_foreign_ctype2073, _calias_coerce_to2008_173_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_pointed_to_by_env_132_foreign_ctype, _calias_pointed_to_by2020_19_foreign_ctype2074, _calias_pointed_to_by2020_19_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_tvector_env_60_foreign_ctype, _cfunction_tvector1967_127_foreign_ctype2075, _cfunction_tvector1967_127_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__tvector_env_82_foreign_ctype, _cstruct__tvector1884_54_foreign_ctype2076, _cstruct__tvector1884_54_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__cstruct_env_94_foreign_ctype, _cstruct__cstruct1886_96_foreign_ctype2077, _cstruct__cstruct1886_96_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_tvector_env_29_foreign_ctype, _cenum_tvector1996_178_foreign_ctype2078, _cenum_tvector1996_178_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_pointed_to_by_env_138_foreign_ctype, _cenum_pointed_to_by1994_118_foreign_ctype2079, _cenum_pointed_to_by1994_118_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_class_env_54_foreign_ctype, _cptr_class1923_142_foreign_ctype2080, _cptr_class1923_142_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_size_set__env_247_foreign_ctype, _cfunction_size_set_1948_79_foreign_ctype2081, _cfunction_size_set_1948_79_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_alias_env_199_foreign_ctype, _cfunction_alias1963_244_foreign_ctype2082, _cfunction_alias1963_244_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_parents_env_68_foreign_ctype, _cfunction_parents1955_40_foreign_ctype2083, _cfunction_parents1955_40_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__parents_env_118_foreign_ctype, _cstruct__parents1872_30_foreign_ctype2084, _cstruct__parents1872_30_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_alias_env_130_foreign_ctype, _calias_alias2018_43_foreign_ctype2085, _calias_alias2018_43_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1007_cstruct__env_72_foreign_ctype, _widening1007_cstruct_1860_48_foreign_ctype2086, _widening1007_cstruct_1860_48_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum_parents_env_117_foreign_ctype, _cenum_parents1984_202_foreign_ctype2087, _cenum_parents1984_202_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_tvector_set__env_244_foreign_ctype, _calias_tvector_set_2021_223_foreign_ctype2088, _calias_tvector_set_2021_223_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct__init__set__env_243_foreign_ctype, _cstruct__init__set_1873_51_foreign_ctype2089, _cstruct__init__set_1873_51_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum_alias_env_113_foreign_ctype, _cenum_alias1992_58_foreign_ctype2090, _cenum_alias1992_58_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_pointed_to_by_env_246_foreign_ctype, _cptr_pointed_to_by1937_55_foreign_ctype2091, _cptr_pointed_to_by1937_55_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_btype_env_6_foreign_ctype, _cfunction_btype1968_86_foreign_ctype2092, _cfunction_btype1968_86_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_init__set__env_46_foreign_ctype, _cenum_init__set_1985_245_foreign_ctype2093, _cenum_init__set_1985_245_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias_array__set__env_75_foreign_ctype, _calias_array__set_2023_137_foreign_ctype2094, _calias_array__set_2023_137_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_parents_set__env_35_foreign_ctype, _cstruct_parents_set_1897_117_foreign_ctype2095, _cstruct_parents_set_1897_117_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_init__env_249_foreign_ctype, _cfunction_init_1957_114_foreign_ctype2096, _cfunction_init_1957_114_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_pointed_to_by_set__env_239_foreign_ctype, _cptr_pointed_to_by_set_1936_151_foreign_ctype2097, _cptr_pointed_to_by_set_1936_151_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum_size_set__env_64_foreign_ctype, _cenum_size_set_1977_49_foreign_ctype2098, _cenum_size_set_1977_49_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias_init__env_207_foreign_ctype, _calias_init_2012_60_foreign_ctype2099, _calias_init_2012_60_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_coerce_to_set__env_183_foreign_ctype, _cstruct_coerce_to_set_1895_194_foreign_ctype2100, _cstruct_coerce_to_set_1895_194_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum_btype_env_138_foreign_ctype, _cenum_btype1997_132_foreign_ctype2101, _cenum_btype1997_132_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_type_args_env_171_foreign_ctype, _cfunction_type_args1971_56_foreign_ctype2102, _cfunction_type_args1971_56_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_cstruct_env_195_foreign_ctype, _make_cstruct1887_248_foreign_ctype2103, _make_cstruct1887_248_foreign_ctype, 0L, 15);
DEFINE_EXPORT_PROCEDURE(cenum_init__env_5_foreign_ctype, _cenum_init_1986_19_foreign_ctype2104, _cenum_init_1986_19_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_array__env_92_foreign_ctype, _calias_array_2024_78_foreign_ctype2105, _calias_array_2024_78_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__id_env_181_foreign_ctype, _cstruct__id1862_28_foreign_ctype2106, _cstruct__id1862_28_foreign_ctype, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2046_foreign_ctype, struct_object__object_calias_28_foreign_ctype2107, struct_object__object_calias_28_foreign_ctype, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2045_foreign_ctype, object__struct_calias_54_foreign_ctype2108, object__struct_calias_54_foreign_ctype, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2044_foreign_ctype, struct_object__object_cenum_149_foreign_ctype2109, struct_object__object_cenum_149_foreign_ctype, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2043_foreign_ctype, object__struct_cenum_54_foreign_ctype2110, object__struct_cenum_54_foreign_ctype, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2042_foreign_ctype, struct_object__object_cfunction_210_foreign_ctype2111, struct_object__object_cfunction_210_foreign_ctype, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2041_foreign_ctype, object__struct_cfunction_148_foreign_ctype2112, object__struct_cfunction_148_foreign_ctype, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2039_foreign_ctype, object__struct_cptr_2_foreign_ctype2113, object__struct_cptr_2_foreign_ctype, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2040_foreign_ctype, struct_object__object_cptr_119_foreign_ctype2114, struct_object__object_cptr_119_foreign_ctype, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2038_foreign_ctype, struct_object__object_cstruct_172_foreign_ctype2115, struct_object__object_cstruct_172_foreign_ctype, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2037_foreign_ctype, object__struct_cstruct_165_foreign_ctype2116, object__struct_cstruct_165_foreign_ctype, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2036_foreign_ctype, struct_object__object_cstruct__130_foreign_ctype2117, struct_object__object_cstruct__130_foreign_ctype, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2035_foreign_ctype, object__struct_cstruct__194_foreign_ctype2118, object__struct_cstruct__194_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_tvector_env_35_foreign_ctype, _cptr_tvector1939_203_foreign_ctype2119, _cptr_tvector1939_203_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct___env_115_foreign_ctype, _cstruct___40_foreign_ctype2120, _cstruct___40_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct___env_173_foreign_ctype, _cstruct__1904_16_foreign_ctype2121, _cstruct__1904_16_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_name_set__env_32_foreign_ctype, _cptr_name_set_1918_55_foreign_ctype2122, _cptr_name_set_1918_55_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_magic__set__env_132_foreign_ctype, _cstruct_magic__set_1901_171_foreign_ctype2123, _cstruct_magic__set_1901_171_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum___env_14_foreign_ctype, _cenum__1990_116_foreign_ctype2124, _cenum__1990_116_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__alias_env_79_foreign_ctype, _cstruct__alias1880_170_foreign_ctype2125, _cstruct__alias1880_170_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_alias_env_220_foreign_ctype, _cstruct_alias1906_110_foreign_ctype2126, _cstruct_alias1906_110_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_tvector_env_221_foreign_ctype, _cstruct_tvector1910_169_foreign_ctype2127, _cstruct_tvector1910_169_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_parents_env_149_foreign_ctype, _cptr_parents1927_64_foreign_ctype2128, _cptr_parents1927_64_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__magic__env_203_foreign_ctype, _cstruct__magic_1876_41_foreign_ctype2129, _cstruct__magic_1876_41_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cenum_env_35_foreign_ctype, _allocate_cenum_156_foreign_ctype2130, _allocate_cenum_156_foreign_ctype, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cfunction_arity_env_123_foreign_ctype, _cfunction_arity1969_95_foreign_ctype2131, _cfunction_arity1969_95_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_magic__env_153_foreign_ctype, _cenum_magic_1988_186_foreign_ctype2132, _cenum_magic_1988_186_foreign_ctype, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(widening1006_cstruct_env_156_foreign_ctype, _widening1006_cstruct_89_foreign_ctype2133, _widening1006_cstruct_89_foreign_ctype, 0L, 3);
DEFINE_EXPORT_PROCEDURE(cptr_coerce_to_env_44_foreign_ctype, _cptr_coerce_to1925_103_foreign_ctype2134, _cptr_coerce_to1925_103_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_init__set__env_168_foreign_ctype, _cstruct_init__set_1899_10_foreign_ctype2135, _cstruct_init__set_1899_10_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_magic__env_234_foreign_ctype, _cstruct_magic_1902_29_foreign_ctype2136, _cstruct_magic_1902_29_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__btype_env_190_foreign_ctype, _cstruct__btype1885_131_foreign_ctype2137, _cstruct__btype1885_131_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_parents_env_168_foreign_ctype, _cstruct_parents1898_169_foreign_ctype2138, _cstruct_parents1898_169_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_literals_env_55_foreign_ctype, _cenum_literals1998_64_foreign_ctype2139, _cenum_literals1998_64_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__init__env_124_foreign_ctype, _cstruct__init_1874_158_foreign_ctype2140, _cstruct__init_1874_158_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_tvector_set__env_161_foreign_ctype, _cfunction_tvector_set_1966_191_foreign_ctype2141, _cfunction_tvector_set_1966_191_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_init__env_85_foreign_ctype, _cstruct_init_1900_136_foreign_ctype2142, _cstruct_init_1900_136_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_name_set__env_199_foreign_ctype, _cfunction_name_set_1946_158_foreign_ctype2143, _cfunction_name_set_1946_158_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct__alias_set__env_225_foreign_ctype, _cstruct__alias_set_1879_62_foreign_ctype2144, _cstruct__alias_set_1879_62_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(widening1005_cptr_env_212_foreign_ctype, _widening1005_cptr1915_81_foreign_ctype2145, _widening1005_cptr1915_81_foreign_ctype, 0L, 3);
DEFINE_EXPORT_PROCEDURE(make_cstruct__env_24_foreign_ctype, _make_cstruct_1861_187_foreign_ctype2146, _make_cstruct_1861_187_foreign_ctype, 0L, 14);
DEFINE_EXPORT_PROCEDURE(cenum_alias_set__env_185_foreign_ctype, _cenum_alias_set_1991_164_foreign_ctype2147, _cenum_alias_set_1991_164_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias___env_225_foreign_ctype, _calias__2016_88_foreign_ctype2148, _calias__2016_88_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_tvector_set__env_246_foreign_ctype, _cptr_tvector_set_1938_234_foreign_ctype2149, _cptr_tvector_set_1938_234_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_coerce_to_env_141_foreign_ctype, _cfunction_coerce_to1953_176_foreign_ctype2150, _cfunction_coerce_to1953_176_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction__env_218_foreign_ctype, _cfunction__240_foreign_ctype2151, _cfunction__240_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__class_set__env_205_foreign_ctype, _cstruct__class_set_1867_75_foreign_ctype2152, _cstruct__class_set_1867_75_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct__coerce_to_set__env_68_foreign_ctype, _cstruct__coerce_to_set_1869_25_foreign_ctype2153, _cstruct__coerce_to_set_1869_25_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_struct__env_232_foreign_ctype, _cstruct_struct_1911_122_foreign_ctype2154, _cstruct_struct_1911_122_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_class_set__env_80_foreign_ctype, _cenum_class_set_1979_23_foreign_ctype2155, _cenum_class_set_1979_23_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct__size_set__env_38_foreign_ctype, _cstruct__size_set_1865_53_foreign_ctype2156, _cstruct__size_set_1865_53_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum_name_set__env_189_foreign_ctype, _cenum_name_set_1975_178_foreign_ctype2157, _cenum_name_set_1975_178_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum__env_247_foreign_ctype, _cenum__111_foreign_ctype2158, _cenum__111_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_size_set__env_248_foreign_ctype, _cstruct_size_set_1891_20_foreign_ctype2159, _cstruct_size_set_1891_20_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_pointed_to_by_set__env_165_foreign_ctype, _cstruct_pointed_to_by_set_1907_148_foreign_ctype2160, _cstruct_pointed_to_by_set_1907_148_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_name_env_181_foreign_ctype, _cstruct_name1890_224_foreign_ctype2161, _cstruct_name1890_224_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_coerce_to_set__env_71_foreign_ctype, _cptr_coerce_to_set_1924_106_foreign_ctype2162, _cptr_coerce_to_set_1924_106_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cptr_magic__set__env_196_foreign_ctype, _cptr_magic__set_1930_218_foreign_ctype2163, _cptr_magic__set_1930_218_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_cstruct_env_64_foreign_ctype, _allocate_cstruct_15_foreign_ctype2164, _allocate_cstruct_15_foreign_ctype, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cenum_coerce_to_env_205_foreign_ctype, _cenum_coerce_to1982_244_foreign_ctype2165, _cenum_coerce_to1982_244_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_parents_set__env_16_foreign_ctype, _cenum_parents_set_1983_79_foreign_ctype2166, _cenum_parents_set_1983_79_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_size_env_175_foreign_ctype, _cstruct_size1892_126_foreign_ctype2167, _cstruct_size1892_126_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_pointed_to_by_env_207_foreign_ctype, _cstruct_pointed_to_by1908_245_foreign_ctype2168, _cstruct_pointed_to_by1908_245_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1002_calias_env_224_foreign_ctype, _widening1002_calias_170_foreign_ctype2169, _widening1002_calias_170_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_init__set__env_165_foreign_ctype, _calias_init__set_2011_201_foreign_ctype2170, _calias_init__set_2011_201_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cptr___set__env_68_foreign_ctype, _cptr___set_1932_61_foreign_ctype2171, _cptr___set_1932_61_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_init__set__env_216_foreign_ctype, _cfunction_init__set_1956_150_foreign_ctype2172, _cfunction_init__set_1956_150_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_id_env_73_foreign_ctype, _cfunction_id1945_146_foreign_ctype2173, _cfunction_id1945_146_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__pointed_to_by_set__env_31_foreign_ctype, _cstruct__pointed_to_by_set_1881_39_foreign_ctype2174, _cstruct__pointed_to_by_set_1881_39_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_alias_set__env_186_foreign_ctype, _cstruct_alias_set_1905_60_foreign_ctype2175, _cstruct_alias_set_1905_60_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias_coerce_to_set__env_189_foreign_ctype, _calias_coerce_to_set_2007_153_foreign_ctype2176, _calias_coerce_to_set_2007_153_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_cptr_env_152_foreign_ctype, _allocate_cptr_1_foreign_ctype2177, _allocate_cptr_1_foreign_ctype, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_cenum_env_162_foreign_ctype, _make_cenum1973_207_foreign_ctype2178, _make_cenum1973_207_foreign_ctype, 0L, 14);
DEFINE_EXPORT_PROCEDURE(cptr_alias_env_93_foreign_ctype, _cptr_alias1935_162_foreign_ctype2179, _cptr_alias1935_162_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__name_env_110_foreign_ctype, _cstruct__name1864_107_foreign_ctype2180, _cstruct__name1864_107_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_class_set__env_250_foreign_ctype, _cstruct_class_set_1893_187_foreign_ctype2181, _cstruct_class_set_1893_187_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_type_res_env_192_foreign_ctype, _cfunction_type_res1970_141_foreign_ctype2182, _cfunction_type_res1970_141_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cstruct__env_60_foreign_ctype, _allocate_cstruct__211_foreign_ctype2183, _allocate_cstruct__211_foreign_ctype, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_cptr_env_182_foreign_ctype, _make_cptr1916_221_foreign_ctype2184, _make_cptr1916_221_foreign_ctype, 0L, 15);
DEFINE_EXPORT_PROCEDURE(calias_parents_set__env_159_foreign_ctype, _calias_parents_set_2009_52_foreign_ctype2185, _calias_parents_set_2009_52_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_calias_env_186_foreign_ctype, _allocate_calias_121_foreign_ctype2186, _allocate_calias_121_foreign_ctype, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cstruct__size_env_76_foreign_ctype, _cstruct__size1866_255_foreign_ctype2187, _cstruct__size1866_255_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__tvector_set__env_115_foreign_ctype, _cstruct__tvector_set_1883_89_foreign_ctype2188, _cstruct__tvector_set_1883_89_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cptr_btype_env_159_foreign_ctype, _cptr_btype1940_10_foreign_ctype2189, _cptr_btype1940_10_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_init__env_45_foreign_ctype, _cptr_init_1929_151_foreign_ctype2190, _cptr_init_1929_151_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_id_env_106_foreign_ctype, _cstruct_id1888_251_foreign_ctype2191, _cstruct_id1888_251_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__name_set__env_2_foreign_ctype, _cstruct__name_set_1863_172_foreign_ctype2192, _cstruct__name_set_1863_172_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias_magic__set__env_11_foreign_ctype, _calias_magic__set_2013_54_foreign_ctype2193, _calias_magic__set_2013_54_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_coerce_to_set__env_105_foreign_ctype, _cfunction_coerce_to_set_1952_186_foreign_ctype2194, _cfunction_coerce_to_set_1952_186_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct_name_set__env_182_foreign_ctype, _cstruct_name_set_1889_66_foreign_ctype2195, _cstruct_name_set_1889_66_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cptr_point_to_env_75_foreign_ctype, _cptr_point_to1941_63_foreign_ctype2196, _cptr_point_to1941_63_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_id_env_102_foreign_ctype, _calias_id2000_202_foreign_ctype2197, _calias_id2000_202_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_alias_set__env_68_foreign_ctype, _calias_alias_set_2017_29_foreign_ctype2198, _calias_alias_set_2017_29_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_alias_set__env_18_foreign_ctype, _cfunction_alias_set_1962_74_foreign_ctype2199, _cfunction_alias_set_1962_74_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction___set__env_225_foreign_ctype, _cfunction___set_1960_53_foreign_ctype2200, _cfunction___set_1960_53_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct__coerce_to_env_130_foreign_ctype, _cstruct__coerce_to1870_126_foreign_ctype2201, _cstruct__coerce_to1870_126_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_class_env_160_foreign_ctype, _cfunction_class1951_36_foreign_ctype2202, _cfunction_class1951_36_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_pointed_to_by_set__env_251_foreign_ctype, _calias_pointed_to_by_set_2019_43_foreign_ctype2203, _calias_pointed_to_by_set_2019_43_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias_class_env_52_foreign_ctype, _calias_class2006_123_foreign_ctype2204, _calias_class2006_123_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_coerce_to_env_115_foreign_ctype, _cstruct_coerce_to1896_225_foreign_ctype2205, _cstruct_coerce_to1896_225_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cfunction_env_6_foreign_ctype, _allocate_cfunction_151_foreign_ctype2206, _allocate_cfunction_151_foreign_ctype, 0L, 0);
DEFINE_EXPORT_PROCEDURE(calias_class_set__env_12_foreign_ctype, _calias_class_set_2005_119_foreign_ctype2207, _calias_class_set_2005_119_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum_id_env_60_foreign_ctype, _cenum_id1974_44_foreign_ctype2208, _cenum_id1974_44_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_class_set__env_218_foreign_ctype, _cfunction_class_set_1950_25_foreign_ctype2209, _cfunction_class_set_1950_25_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum_class_env_185_foreign_ctype, _cenum_class1980_229_foreign_ctype2210, _cenum_class1980_229_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_pointed_to_by_env_101_foreign_ctype, _cfunction_pointed_to_by1965_21_foreign_ctype2211, _cfunction_pointed_to_by1965_21_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_tvector_set__env_145_foreign_ctype, _cstruct_tvector_set_1909_49_foreign_ctype2212, _cstruct_tvector_set_1909_49_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct__env_14_foreign_ctype, _cstruct__158_foreign_ctype2213, _cstruct__158_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_magic__env_157_foreign_ctype, _cptr_magic_1931_25_foreign_ctype2214, _cptr_magic_1931_25_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfunction_parents_set__env_192_foreign_ctype, _cfunction_parents_set_1954_155_foreign_ctype2215, _cfunction_parents_set_1954_155_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias___set__env_113_foreign_ctype, _calias___set_2015_38_foreign_ctype2216, _calias___set_2015_38_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cstruct____env_19_foreign_ctype, _cstruct___1878_35_foreign_ctype2217, _cstruct___1878_35_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_calias_env_163_foreign_ctype, _make_calias1999_199_foreign_ctype2218, _make_calias1999_199_foreign_ctype, 0L, 13);
DEFINE_EXPORT_PROCEDURE(cfunction_magic__set__env_198_foreign_ctype, _cfunction_magic__set_1958_27_foreign_ctype2219, _cfunction_magic__set_1958_27_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cptr_init__set__env_127_foreign_ctype, _cptr_init__set_1928_69_foreign_ctype2220, _cptr_init__set_1928_69_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(calias_size_set__env_241_foreign_ctype, _calias_size_set_2003_67_foreign_ctype2221, _calias_size_set_2003_67_foreign_ctype, 0L, 2);
DEFINE_STRING(string2047_foreign_ctype, string2047_foreign_ctype2222, "CSTRUCT* CSTRUCT CPTR CFUNCTION CENUM CALIAS QUOTE X LAMBDA FOREIGN COBJ COERCE TYPE -> ? * STRUCT ARRAY BIGLOO (OBJ) (COBJ) B C (STRUCT* UNION*) (STRUCT UNION) (POINTER ARRAY) FUNCTION ENUM ", 191);
DEFINE_EXPORT_PROCEDURE(cptr_id_env_5_foreign_ctype, _cptr_id1917_233_foreign_ctype2223, _cptr_id1917_233_foreign_ctype, 0L, 1);
DEFINE_STRING(string2034_foreign_ctype, string2034_foreign_ctype2224, "*((", 3);
DEFINE_STRING(string2033_foreign_ctype, string2033_foreign_ctype2225, ") 0)", 4);
DEFINE_STRING(string2032_foreign_ctype, string2032_foreign_ctype2226, "Illegal c type declaration", 26);
DEFINE_STRING(string2031_foreign_ctype, string2031_foreign_ctype2227, "declare-c-type!", 15);
DEFINE_STRING(string2030_foreign_ctype, string2030_foreign_ctype2228, "Type redefinition -- ", 21);
DEFINE_EXPORT_PROCEDURE(calias_tvector_env_39_foreign_ctype, _calias_tvector2022_106_foreign_ctype2229, _calias_tvector2022_106_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(declare_c_type__env_110_foreign_ctype, _declare_c_type_1859_219_foreign_ctype2230, _declare_c_type_1859_219_foreign_ctype, 0L, 4);
DEFINE_EXPORT_PROCEDURE(cstruct__magic__set__env_60_foreign_ctype, _cstruct__magic__set_1875_54_foreign_ctype2231, _cstruct__magic__set_1875_54_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cptr_parents_set__env_255_foreign_ctype, _cptr_parents_set_1926_4_foreign_ctype2232, _cptr_parents_set_1926_4_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(widening1004_cfunction_env_104_foreign_ctype, _widening1004_cfunction1943_26_foreign_ctype2233, _widening1004_cfunction1943_26_foreign_ctype, 0L, 4);
DEFINE_EXPORT_PROCEDURE(calias_parents_env_54_foreign_ctype, _calias_parents2010_113_foreign_ctype2234, _calias_parents2010_113_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct__class_env_147_foreign_ctype, _cstruct__class1868_56_foreign_ctype2235, _cstruct__class1868_56_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_class_env_128_foreign_ctype, _cstruct_class1894_10_foreign_ctype2236, _cstruct_class1894_10_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cstruct_cstruct__set__env_86_foreign_ctype, _cstruct_cstruct__set_1913_24_foreign_ctype2237, _cstruct_cstruct__set_1913_24_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_pointed_to_by_set__env_26_foreign_ctype, _cfunction_pointed_to_by_set_1964_24_foreign_ctype2238, _cfunction_pointed_to_by_set_1964_24_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_cfunction_env_207_foreign_ctype, _make_cfunction1944_30_foreign_ctype2239, _make_cfunction1944_30_foreign_ctype, 0L, 16);
DEFINE_EXPORT_PROCEDURE(cstruct__pointed_to_by_env_37_foreign_ctype, _cstruct__pointed_to_by1882_106_foreign_ctype2240, _cstruct__pointed_to_by1882_106_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_coerce_to_set__env_39_foreign_ctype, _cenum_coerce_to_set_1981_153_foreign_ctype2241, _cenum_coerce_to_set_1981_153_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cptr___env_130_foreign_ctype, _cptr__1933_82_foreign_ctype2242, _cptr__1933_82_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr__env_167_foreign_ctype, _cptr__176_foreign_ctype2243, _cptr__176_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_array__env_43_foreign_ctype, _cptr_array_1942_178_foreign_ctype2244, _cptr_array_1942_178_foreign_ctype, 0L, 1);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(cfunction_magic__env_10_foreign_ctype, _cfunction_magic_1959_239_foreign_ctype2245, _cfunction_magic_1959_239_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cenum_magic__set__env_28_foreign_ctype, _cenum_magic__set_1987_48_foreign_ctype2246, _cenum_magic__set_1987_48_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfunction_name_env_123_foreign_ctype, _cfunction_name1947_221_foreign_ctype2247, _cfunction_name1947_221_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(calias_name_env_186_foreign_ctype, _calias_name2002_238_foreign_ctype2248, _calias_name2002_238_foreign_ctype, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cptr_alias_set__env_87_foreign_ctype, _cptr_alias_set_1934_211_foreign_ctype2249, _cptr_alias_set_1934_211_foreign_ctype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cenum_name_env_239_foreign_ctype, _cenum_name1976_20_foreign_ctype2250, _cenum_name1976_20_foreign_ctype, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_foreign_ctype(long checksum_2362, char *from_2363)
{
   if (CBOOL(require_initialization_114_foreign_ctype))
     {
	require_initialization_114_foreign_ctype = BBOOL(((bool_t) 0));
	library_modules_init_112_foreign_ctype();
	cnst_init_137_foreign_ctype();
	imported_modules_init_94_foreign_ctype();
	object_init_111_foreign_ctype();
	method_init_76_foreign_ctype();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_foreign_ctype()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70___error(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70___object(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70___r4_strings_6_7(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70___reader(((long) 0), "FOREIGN_CTYPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_foreign_ctype()
{
   {
      obj_t cnst_port_138_2354;
      cnst_port_138_2354 = open_input_string(string2047_foreign_ctype);
      {
	 long i_2355;
	 i_2355 = ((long) 27);
       loop_2356:
	 {
	    bool_t test2048_2357;
	    test2048_2357 = (i_2355 == ((long) -1));
	    if (test2048_2357)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2049_2358;
		    {
		       obj_t list2050_2359;
		       {
			  obj_t arg2051_2360;
			  arg2051_2360 = BNIL;
			  list2050_2359 = MAKE_PAIR(cnst_port_138_2354, arg2051_2360);
		       }
		       arg2049_2358 = read___reader(list2050_2359);
		    }
		    CNST_TABLE_SET(i_2355, arg2049_2358);
		 }
		 {
		    int aux_2361;
		    {
		       long aux_2384;
		       aux_2384 = (i_2355 - ((long) 1));
		       aux_2361 = (int) (aux_2384);
		    }
		    {
		       long i_2387;
		       i_2387 = (long) (aux_2361);
		       i_2355 = i_2387;
		       goto loop_2356;
		    }
		 }
	      }
	 }
      }
   }
}


/* declare-c-type! */ obj_t 
declare_c_type__49_foreign_ctype(obj_t ct_def_203_1, obj_t ct_id_32_2, obj_t ct_exp_132_3, obj_t ct_name_117_4)
{
   {
      bool_t test1227_432;
      test1227_432 = type_exists__12_type_env(ct_id_32_2);
      if (test1227_432)
	{
	   {
	      obj_t list1228_433;
	      {
		 obj_t arg1232_435;
		 {
		    obj_t arg1234_437;
		    arg1234_437 = MAKE_PAIR(ct_id_32_2, BNIL);
		    arg1232_435 = MAKE_PAIR(string2030_foreign_ctype, arg1234_437);
		 }
		 list1228_433 = MAKE_PAIR(string2031_foreign_ctype, arg1232_435);
	      }
	      warning___error(list1228_433);
	   }
	   return BUNSPEC;
	}
      else
	{
	   if (SYMBOLP(ct_exp_132_3))
	     {
		{
		   type_t aux_2397;
		   aux_2397 = declare_c_alias__61_foreign_ctype(ct_id_32_2, ct_exp_132_3, ct_name_117_4);
		   return (obj_t) (aux_2397);
		}
	     }
	   else
	     {
		if (PAIRP(ct_exp_132_3))
		  {
		     {
			obj_t case_value_58_441;
			case_value_58_441 = CAR(ct_exp_132_3);
			{
			   bool_t test_2403;
			   {
			      obj_t aux_2404;
			      aux_2404 = CNST_TABLE_REF(((long) 0));
			      test_2403 = (case_value_58_441 == aux_2404);
			   }
			   if (test_2403)
			     {
				type_t aux_2407;
				aux_2407 = declare_c_enum__96_foreign_ctype(ct_id_32_2, ct_exp_132_3, ct_name_117_4);
				return (obj_t) (aux_2407);
			     }
			   else
			     {
				bool_t test_2410;
				{
				   obj_t aux_2411;
				   aux_2411 = CNST_TABLE_REF(((long) 1));
				   test_2410 = (case_value_58_441 == aux_2411);
				}
				if (test_2410)
				  {
				     type_t aux_2414;
				     aux_2414 = declare_c_function__152_foreign_ctype(ct_id_32_2, ct_exp_132_3, ct_name_117_4);
				     return (obj_t) (aux_2414);
				  }
				else
				  {
				     bool_t test_2417;
				     {
					obj_t aux_2418;
					aux_2418 = memq___r4_pairs_and_lists_6_3(case_value_58_441, CNST_TABLE_REF(((long) 2)));
					test_2417 = CBOOL(aux_2418);
				     }
				     if (test_2417)
				       {
					  type_t aux_2422;
					  aux_2422 = declare_c_pointer__90_foreign_ctype(ct_id_32_2, ct_exp_132_3, ct_name_117_4);
					  return (obj_t) (aux_2422);
				       }
				     else
				       {
					  bool_t test_2425;
					  {
					     obj_t aux_2426;
					     aux_2426 = memq___r4_pairs_and_lists_6_3(case_value_58_441, CNST_TABLE_REF(((long) 3)));
					     test_2425 = CBOOL(aux_2426);
					  }
					  if (test_2425)
					    {
					       type_t aux_2430;
					       aux_2430 = declare_c_struct__84_foreign_ctype(ct_id_32_2, ct_exp_132_3, ct_name_117_4);
					       return (obj_t) (aux_2430);
					    }
					  else
					    {
					       bool_t test_2433;
					       {
						  obj_t aux_2434;
						  aux_2434 = memq___r4_pairs_and_lists_6_3(case_value_58_441, CNST_TABLE_REF(((long) 4)));
						  test_2433 = CBOOL(aux_2434);
					       }
					       if (test_2433)
						 {
						    type_t aux_2438;
						    aux_2438 = declare_c_struct___243_foreign_ctype(ct_id_32_2, ct_exp_132_3, ct_name_117_4);
						    return (obj_t) (aux_2438);
						 }
					       else
						 {
						    return internal_error_43_tools_error(string2031_foreign_ctype, string2032_foreign_ctype, ct_def_203_1);
						 }
					    }
				       }
				  }
			     }
			}
		     }
		  }
		else
		  {
		     return internal_error_43_tools_error(string2031_foreign_ctype, string2032_foreign_ctype, ct_def_203_1);
		  }
	     }
	}
   }
}


/* _declare-c-type!1859 */ obj_t 
_declare_c_type_1859_219_foreign_ctype(obj_t env_1792, obj_t ct_def_203_1793, obj_t ct_id_32_1794, obj_t ct_exp_132_1795, obj_t ct_name_117_1796)
{
   return declare_c_type__49_foreign_ctype(ct_def_203_1793, ct_id_32_1794, ct_exp_132_1795, ct_name_117_1796);
}


/* declare-c-alias! */ type_t 
declare_c_alias__61_foreign_ctype(obj_t id_5, obj_t exp_6, obj_t name_7)
{
   {
      type_t atype_452;
      {
	 type_t arg1254_460;
	 arg1254_460 = find_type_26_type_env(exp_6);
	 atype_452 = get_aliased_type_1_type_type(arg1254_460);
      }
      {
	 bool_t test_2446;
	 {
	    obj_t aux_2447;
	    aux_2447 = (((type_t) CREF(atype_452))->id);
	    test_2446 = (id_5 == aux_2447);
	 }
	 if (test_2446)
	   {
	      return atype_452;
	   }
	 else
	   {
	      type_t ctype_454;
	      ctype_454 = declare_aliastype__27_type_env(id_5, name_7, CNST_TABLE_REF(((long) 5)), atype_452);
	      {
		 calias_t obj1192_455;
		 obj1192_455 = ((calias_t) (ctype_454));
		 {
		    calias_t arg1250_456;
		    {
		       calias_t res1835_1121;
		       {
			  calias_t new1042_1119;
			  new1042_1119 = ((calias_t) BREF(GC_MALLOC(sizeof(struct calias))));
			  ((((calias_t) CREF(new1042_1119))->array__248) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			  res1835_1121 = new1042_1119;
		       }
		       arg1250_456 = res1835_1121;
		    }
		    {
		       obj_t aux_2457;
		       object_t aux_2455;
		       aux_2457 = (obj_t) (arg1250_456);
		       aux_2455 = (object_t) (obj1192_455);
		       OBJECT_WIDENING_SET(aux_2455, aux_2457);
		    }
		 }
		 {
		    long arg1251_457;
		    arg1251_457 = class_num_218___object(calias_foreign_ctype);
		    {
		       obj_t obj_1122;
		       obj_1122 = (obj_t) (obj1192_455);
		       (((obj_t) CREF(obj_1122))->header = MAKE_HEADER(arg1251_457, 0), BUNSPEC);
		    }
		 }
		 obj1192_455;
	      }
	      return ctype_454;
	   }
      }
   }
}


/* declare-c-enum! */ type_t 
declare_c_enum__96_foreign_ctype(obj_t id_8, obj_t exp_9, obj_t name_10)
{
   {
      obj_t cobj_461;
      cobj_461 = _cobj__54_type_cache;
      {
	 obj_t obj_462;
	 obj_462 = _obj__252_type_cache;
	 {
	    obj_t bid_463;
	    {
	       obj_t arg1268_477;
	       arg1268_477 = CNST_TABLE_REF(((long) 6));
	       {
		  obj_t list1269_478;
		  {
		     obj_t arg1270_479;
		     arg1270_479 = MAKE_PAIR(id_8, BNIL);
		     list1269_478 = MAKE_PAIR(arg1268_477, arg1270_479);
		  }
		  bid_463 = symbol_append_197___r4_symbols_6_4(list1269_478);
	       }
	    }
	    {
	       type_t ctype_464;
	       ctype_464 = declare_subtype__66_type_env(id_8, name_10, CNST_TABLE_REF(((long) 7)), CNST_TABLE_REF(((long) 5)));
	       {
		  type_t btype_465;
		  {
		     obj_t aux_2470;
		     {
			type_t obj_1124;
			obj_1124 = (type_t) (obj_462);
			aux_2470 = (((type_t) CREF(obj_1124))->name);
		     }
		     btype_465 = declare_subtype__66_type_env(bid_463, aux_2470, CNST_TABLE_REF(((long) 8)), CNST_TABLE_REF(((long) 9)));
		  }
		  {
		     {
			obj_t arg1255_466;
			arg1255_466 = make_foreign_coercers_168_foreign_ctype(id_8, bid_463);
			produce_module_clause__172_module_module(arg1255_466);
		     }
		     {
			cenum_t obj1193_467;
			obj1193_467 = ((cenum_t) (ctype_464));
			{
			   cenum_t arg1256_468;
			   {
			      obj_t arg1258_470;
			      arg1258_470 = CDR(exp_9);
			      {
				 cenum_t res1836_1131;
				 {
				    cenum_t new1067_1128;
				    new1067_1128 = ((cenum_t) BREF(GC_MALLOC(sizeof(struct cenum))));
				    ((((cenum_t) CREF(new1067_1128))->btype) = ((type_t) btype_465), BUNSPEC);
				    ((((cenum_t) CREF(new1067_1128))->literals) = ((obj_t) arg1258_470), BUNSPEC);
				    res1836_1131 = new1067_1128;
				 }
				 arg1256_468 = res1836_1131;
			      }
			   }
			   {
			      obj_t aux_2485;
			      object_t aux_2483;
			      aux_2485 = (obj_t) (arg1256_468);
			      aux_2483 = (object_t) (obj1193_467);
			      OBJECT_WIDENING_SET(aux_2483, aux_2485);
			   }
			}
			{
			   long arg1259_471;
			   arg1259_471 = class_num_218___object(cenum_foreign_ctype);
			   {
			      obj_t obj_1132;
			      obj_1132 = (obj_t) (obj1193_467);
			      (((obj_t) CREF(obj_1132))->header = MAKE_HEADER(arg1259_471, 0), BUNSPEC);
			   }
			}
			obj1193_467;
		     }
		     return ctype_464;
		  }
	       }
	    }
	 }
      }
   }
}


/* declare-c-function! */ type_t 
declare_c_function__152_foreign_ctype(obj_t id_11, obj_t exp_12, obj_t name_13)
{
   {
      obj_t cobj_481;
      cobj_481 = _cobj__54_type_cache;
      {
	 obj_t obj_482;
	 obj_482 = _obj__252_type_cache;
	 {
	    obj_t bid_483;
	    {
	       obj_t arg1303_520;
	       arg1303_520 = CNST_TABLE_REF(((long) 6));
	       {
		  obj_t list1304_521;
		  {
		     obj_t arg1307_522;
		     arg1307_522 = MAKE_PAIR(id_11, BNIL);
		     list1304_521 = MAKE_PAIR(arg1303_520, arg1307_522);
		  }
		  bid_483 = symbol_append_197___r4_symbols_6_4(list1304_521);
	       }
	    }
	    {
	       type_t ctype_484;
	       ctype_484 = declare_subtype__66_type_env(id_11, name_13, CNST_TABLE_REF(((long) 7)), CNST_TABLE_REF(((long) 5)));
	       {
		  type_t btype_485;
		  {
		     obj_t aux_2498;
		     {
			type_t obj_1134;
			obj_1134 = (type_t) (obj_482);
			aux_2498 = (((type_t) CREF(obj_1134))->name);
		     }
		     btype_485 = declare_subtype__66_type_env(bid_483, aux_2498, CNST_TABLE_REF(((long) 8)), CNST_TABLE_REF(((long) 9)));
		  }
		  {
		     int arity_486;
		     {
			obj_t aux_2504;
			{
			   obj_t aux_2505;
			   {
			      obj_t aux_2506;
			      aux_2506 = CDR(exp_12);
			      aux_2505 = CDR(aux_2506);
			   }
			   aux_2504 = CAR(aux_2505);
			}
			arity_486 = arity_tools_args(aux_2504);
		     }
		     {
			obj_t tres_id_18_487;
			{
			   obj_t aux_2511;
			   aux_2511 = CDR(exp_12);
			   tres_id_18_487 = CAR(aux_2511);
			}
			{
			   obj_t targs_id_78_488;
			   {
			      obj_t aux_2514;
			      {
				 obj_t aux_2515;
				 {
				    obj_t aux_2516;
				    aux_2516 = CDR(exp_12);
				    aux_2515 = CDR(aux_2516);
				 }
				 aux_2514 = CAR(aux_2515);
			      }
			      targs_id_78_488 = args___args_list_50_tools_args(aux_2514);
			   }
			   {
			      {
				 obj_t arg1273_489;
				 arg1273_489 = make_foreign_coercers_168_foreign_ctype(id_11, bid_483);
				 produce_module_clause__172_module_module(arg1273_489);
			      }
			      {
				 cfunction_t obj1194_490;
				 obj1194_490 = ((cfunction_t) (ctype_484));
				 {
				    cfunction_t arg1274_491;
				    {
				       type_t arg1281_494;
				       obj_t arg1282_495;
				       arg1281_494 = use_type__231_type_env(tres_id_18_487);
				       if (NULLP(targs_id_78_488))
					 {
					    arg1282_495 = BNIL;
					 }
				       else
					 {
					    obj_t head1197_498;
					    {
					       type_t arg1291_509;
					       arg1291_509 = use_type__231_type_env(CAR(targs_id_78_488));
					       {
						  obj_t aux_2529;
						  aux_2529 = (obj_t) (arg1291_509);
						  head1197_498 = MAKE_PAIR(aux_2529, BNIL);
					       }
					    }
					    {
					       obj_t l1195_499;
					       obj_t tail1198_500;
					       l1195_499 = CDR(targs_id_78_488);
					       tail1198_500 = head1197_498;
					     lname1196_501:
					       if (NULLP(l1195_499))
						 {
						    arg1282_495 = head1197_498;
						 }
					       else
						 {
						    obj_t newtail1199_504;
						    {
						       type_t arg1287_506;
						       arg1287_506 = use_type__231_type_env(CAR(l1195_499));
						       {
							  obj_t aux_2536;
							  aux_2536 = (obj_t) (arg1287_506);
							  newtail1199_504 = MAKE_PAIR(aux_2536, BNIL);
						       }
						    }
						    SET_CDR(tail1198_500, newtail1199_504);
						    {
						       obj_t tail1198_2542;
						       obj_t l1195_2540;
						       l1195_2540 = CDR(l1195_499);
						       tail1198_2542 = newtail1199_504;
						       tail1198_500 = tail1198_2542;
						       l1195_499 = l1195_2540;
						       goto lname1196_501;
						    }
						 }
					    }
					 }
				       {
					  cfunction_t res1837_1172;
					  {
					     long arity_1164;
					     arity_1164 = (long) (arity_486);
					     {
						cfunction_t new1091_1167;
						new1091_1167 = ((cfunction_t) BREF(GC_MALLOC(sizeof(struct cfunction))));
						((((cfunction_t) CREF(new1091_1167))->btype) = ((type_t) btype_485), BUNSPEC);
						((((cfunction_t) CREF(new1091_1167))->arity) = ((long) arity_1164), BUNSPEC);
						((((cfunction_t) CREF(new1091_1167))->type_res_48) = ((type_t) arg1281_494), BUNSPEC);
						((((cfunction_t) CREF(new1091_1167))->type_args_244) = ((obj_t) arg1282_495), BUNSPEC);
						res1837_1172 = new1091_1167;
					     }
					  }
					  arg1274_491 = res1837_1172;
				       }
				    }
				    {
				       obj_t aux_2552;
				       object_t aux_2550;
				       aux_2552 = (obj_t) (arg1274_491);
				       aux_2550 = (object_t) (obj1194_490);
				       OBJECT_WIDENING_SET(aux_2550, aux_2552);
				    }
				 }
				 {
				    long arg1295_512;
				    arg1295_512 = class_num_218___object(cfunction_foreign_ctype);
				    {
				       obj_t obj_1173;
				       obj_1173 = (obj_t) (obj1194_490);
				       (((obj_t) CREF(obj_1173))->header = MAKE_HEADER(arg1295_512, 0), BUNSPEC);
				    }
				 }
				 obj1194_490;
			      }
			      return ctype_484;
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* declare-c-pointer! */ type_t 
declare_c_pointer__90_foreign_ctype(obj_t id_14, obj_t exp_15, obj_t name_16)
{
   {
      type_t pointed_524;
      {
	 obj_t aux_2558;
	 {
	    obj_t aux_2559;
	    aux_2559 = CDR(exp_15);
	    aux_2558 = CAR(aux_2559);
	 }
	 pointed_524 = find_type_26_type_env(aux_2558);
      }
      {
	 obj_t pointer_525;
	 pointer_525 = (((type_t) CREF(pointed_524))->pointed_to_by_76);
	 {
	    {
	       bool_t test1309_526;
	       test1309_526 = is_a__118___object(pointer_525, type_type_type);
	       if (test1309_526)
		 {
		    {
		       type_t alias_527;
		       {
			  obj_t arg1319_534;
			  obj_t arg1321_535;
			  {
			     type_t obj_1181;
			     obj_1181 = (type_t) (pointer_525);
			     arg1319_534 = (((type_t) CREF(obj_1181))->id);
			  }
			  arg1321_535 = make_pointer_to_name_76_type_tools(pointed_524);
			  alias_527 = declare_c_alias__61_foreign_ctype(id_14, arg1319_534, arg1321_535);
		       }
		       {
			  bool_t test_2570;
			  {
			     bool_t test_2571;
			     {
				obj_t aux_2574;
				obj_t aux_2572;
				aux_2574 = CNST_TABLE_REF(((long) 10));
				aux_2572 = CAR(exp_15);
				test_2571 = (aux_2572 == aux_2574);
			     }
			     if (test_2571)
			       {
				  bool_t test_2577;
				  {
				     cptr_t obj_1185;
				     obj_1185 = (cptr_t) (pointer_525);
				     {
					obj_t aux_2579;
					{
					   object_t aux_2580;
					   aux_2580 = (object_t) (obj_1185);
					   aux_2579 = OBJECT_WIDENING(aux_2580);
					}
					test_2577 = (((cptr_t) CREF(aux_2579))->array__248);
				     }
				  }
				  if (test_2577)
				    {
				       test_2570 = ((bool_t) 0);
				    }
				  else
				    {
				       test_2570 = ((bool_t) 1);
				    }
			       }
			     else
			       {
				  test_2570 = ((bool_t) 0);
			       }
			  }
			  if (test_2570)
			    {
			       {
				  obj_t arg1311_529;
				  arg1311_529 = string_sans___40_type_tools(name_16);
				  ((((type_t) CREF(alias_527))->size) = ((obj_t) arg1311_529), BUNSPEC);
			       }
			       {
				  calias_t obj_1188;
				  obj_1188 = (calias_t) (alias_527);
				  {
				     obj_t aux_2587;
				     {
					object_t aux_2588;
					aux_2588 = (object_t) (obj_1188);
					aux_2587 = OBJECT_WIDENING(aux_2588);
				     }
				     ((((calias_t) CREF(aux_2587))->array__248) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				  }
			       }
			    }
			  else
			    {
			       BUNSPEC;
			    }
		       }
		       return alias_527;
		    }
		 }
	       else
		 {
		    {
		       obj_t cobj_536;
		       cobj_536 = _cobj__54_type_cache;
		       {
			  obj_t obj_537;
			  obj_537 = _obj__252_type_cache;
			  {
			     obj_t nobj_538;
			     {
				type_t obj_1190;
				obj_1190 = (type_t) (obj_537);
				nobj_538 = (((type_t) CREF(obj_1190))->name);
			     }
			     {
				obj_t bid_539;
				{
				   obj_t arg1340_557;
				   arg1340_557 = CNST_TABLE_REF(((long) 6));
				   {
				      obj_t list1341_558;
				      {
					 obj_t arg1342_559;
					 arg1342_559 = MAKE_PAIR(id_14, BNIL);
					 list1341_558 = MAKE_PAIR(arg1340_557, arg1342_559);
				      }
				      bid_539 = symbol_append_197___r4_symbols_6_4(list1341_558);
				   }
				}
				{
				   obj_t tname_540;
				   tname_540 = make_pointer_to_name_76_type_tools(pointed_524);
				   {
				      type_t ctype_541;
				      ctype_541 = declare_subtype__66_type_env(id_14, tname_540, CNST_TABLE_REF(((long) 7)), CNST_TABLE_REF(((long) 5)));
				      {
					 type_t btype_542;
					 btype_542 = declare_subtype__66_type_env(bid_539, nobj_538, CNST_TABLE_REF(((long) 8)), CNST_TABLE_REF(((long) 9)));
					 {
					    {
					       obj_t arg1322_543;
					       arg1322_543 = string_sans___40_type_tools(name_16);
					       ((((type_t) CREF(ctype_541))->size) = ((obj_t) arg1322_543), BUNSPEC);
					    }
					    {
					       obj_t arg1323_544;
					       arg1323_544 = make_foreign_coercers_168_foreign_ctype(id_14, bid_539);
					       produce_module_clause__172_module_module(arg1323_544);
					    }
					    {
					       obj_t val1031_1194;
					       val1031_1194 = (obj_t) (ctype_541);
					       ((((type_t) CREF(pointed_524))->pointed_to_by_76) = ((obj_t) val1031_1194), BUNSPEC);
					    }
					    {
					       cptr_t obj1200_545;
					       obj1200_545 = ((cptr_t) (ctype_541));
					       {
						  cptr_t arg1324_546;
						  {
						     bool_t arg1328_549;
						     {
							obj_t aux_2614;
							obj_t aux_2612;
							aux_2614 = CNST_TABLE_REF(((long) 10));
							aux_2612 = CAR(exp_15);
							arg1328_549 = (aux_2612 == aux_2614);
						     }
						     {
							cptr_t res1838_1205;
							{
							   cptr_t new1117_1201;
							   new1117_1201 = ((cptr_t) BREF(GC_MALLOC(sizeof(struct cptr))));
							   ((((cptr_t) CREF(new1117_1201))->btype) = ((type_t) btype_542), BUNSPEC);
							   ((((cptr_t) CREF(new1117_1201))->point_to_164) = ((type_t) pointed_524), BUNSPEC);
							   ((((cptr_t) CREF(new1117_1201))->array__248) = ((bool_t) arg1328_549), BUNSPEC);
							   res1838_1205 = new1117_1201;
							}
							arg1324_546 = res1838_1205;
						     }
						  }
						  {
						     obj_t aux_2623;
						     object_t aux_2621;
						     aux_2623 = (obj_t) (arg1324_546);
						     aux_2621 = (object_t) (obj1200_545);
						     OBJECT_WIDENING_SET(aux_2621, aux_2623);
						  }
					       }
					       {
						  long arg1332_552;
						  arg1332_552 = class_num_218___object(cptr_foreign_ctype);
						  {
						     obj_t obj_1206;
						     obj_1206 = (obj_t) (obj1200_545);
						     (((obj_t) CREF(obj_1206))->header = MAKE_HEADER(arg1332_552, 0), BUNSPEC);
						  }
					       }
					       obj1200_545;
					    }
					    return ctype_541;
					 }
				      }
				   }
				}
			     }
			  }
		       }
		    }
		 }
	    }
	 }
      }
   }
}


/* declare-c-struct! */ type_t 
declare_c_struct__84_foreign_ctype(obj_t id_17, obj_t exp_18, obj_t name_19)
{
   {
      obj_t cobj_562;
      cobj_562 = _cobj__54_type_cache;
      {
	 obj_t obj_563;
	 obj_563 = _obj__252_type_cache;
	 {
	    obj_t bid_564;
	    {
	       obj_t arg1372_587;
	       arg1372_587 = CNST_TABLE_REF(((long) 6));
	       {
		  obj_t list1373_588;
		  {
		     obj_t arg1375_589;
		     arg1375_589 = MAKE_PAIR(id_17, BNIL);
		     list1373_588 = MAKE_PAIR(arg1372_587, arg1375_589);
		  }
		  bid_564 = symbol_append_197___r4_symbols_6_4(list1373_588);
	       }
	    }
	    {
	       type_t ctype_565;
	       ctype_565 = declare_subtype__66_type_env(id_17, name_19, CNST_TABLE_REF(((long) 7)), CNST_TABLE_REF(((long) 5)));
	       {
		  ((((type_t) CREF(ctype_565))->size) = ((obj_t) name_19), BUNSPEC);
		  {
		     cstruct_t obj1201_566;
		     obj1201_566 = ((cstruct_t) (ctype_565));
		     {
			cstruct_t arg1345_567;
			{
			   bool_t arg1347_568;
			   obj_t arg1349_569;
			   {
			      obj_t aux_2640;
			      obj_t aux_2638;
			      aux_2640 = CNST_TABLE_REF(((long) 11));
			      aux_2638 = CAR(exp_18);
			      arg1347_568 = (aux_2638 == aux_2640);
			   }
			   arg1349_569 = CDR(exp_18);
			   {
			      cstruct_t res1839_1221;
			      {
				 obj_t cstruct__170_1216;
				 cstruct__170_1216 = BFALSE;
				 {
				    cstruct_t new1142_1217;
				    new1142_1217 = ((cstruct_t) BREF(GC_MALLOC(sizeof(struct cstruct))));
				    ((((cstruct_t) CREF(new1142_1217))->struct__46) = ((bool_t) arg1347_568), BUNSPEC);
				    ((((cstruct_t) CREF(new1142_1217))->fields) = ((obj_t) arg1349_569), BUNSPEC);
				    ((((cstruct_t) CREF(new1142_1217))->cstruct__170) = ((obj_t) cstruct__170_1216), BUNSPEC);
				    res1839_1221 = new1142_1217;
				 }
			      }
			      arg1345_567 = res1839_1221;
			   }
			}
			{
			   obj_t aux_2650;
			   object_t aux_2648;
			   aux_2650 = (obj_t) (arg1345_567);
			   aux_2648 = (object_t) (obj1201_566);
			   OBJECT_WIDENING_SET(aux_2648, aux_2650);
			}
		     }
		     {
			long arg1352_572;
			arg1352_572 = class_num_218___object(cstruct_foreign_ctype);
			{
			   obj_t obj_1222;
			   obj_1222 = (obj_t) (obj1201_566);
			   (((obj_t) CREF(obj_1222))->header = MAKE_HEADER(arg1352_572, 0), BUNSPEC);
			}
		     }
		     obj1201_566;
		  }
		  {
		     obj_t ptr_id_217_573;
		     {
			obj_t list1365_582;
			{
			   obj_t arg1367_583;
			   {
			      obj_t aux_2656;
			      aux_2656 = CNST_TABLE_REF(((long) 12));
			      arg1367_583 = MAKE_PAIR(aux_2656, BNIL);
			   }
			   list1365_582 = MAKE_PAIR(id_17, arg1367_583);
			}
			ptr_id_217_573 = symbol_append_197___r4_symbols_6_4(list1365_582);
		     }
		     {
			obj_t arg1353_574;
			obj_t arg1355_575;
			{
			   obj_t arg1356_576;
			   arg1356_576 = CAR(exp_18);
			   {
			      obj_t list1358_578;
			      {
				 obj_t arg1361_579;
				 arg1361_579 = MAKE_PAIR(BNIL, BNIL);
				 list1358_578 = MAKE_PAIR(id_17, arg1361_579);
			      }
			      arg1353_574 = cons__138___r4_pairs_and_lists_6_3(arg1356_576, list1358_578);
			   }
			}
			arg1355_575 = make_pointer_to_name_76_type_tools(ctype_565);
			return declare_c_struct___243_foreign_ctype(ptr_id_217_573, arg1353_574, arg1355_575);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* declare-c-struct*! */ type_t 
declare_c_struct___243_foreign_ctype(obj_t id_20, obj_t exp_21, obj_t name_22)
{
   {
      type_t struct_591;
      {
	 obj_t aux_2667;
	 {
	    obj_t aux_2668;
	    aux_2668 = CDR(exp_21);
	    aux_2667 = CAR(aux_2668);
	 }
	 struct_591 = find_type_26_type_env(aux_2667);
      }
      {
	 obj_t struct__54_592;
	 {
	    cstruct_t obj_1229;
	    obj_1229 = (cstruct_t) (struct_591);
	    {
	       obj_t aux_2673;
	       {
		  object_t aux_2674;
		  aux_2674 = (object_t) (obj_1229);
		  aux_2673 = OBJECT_WIDENING(aux_2674);
	       }
	       struct__54_592 = (((cstruct_t) CREF(aux_2673))->cstruct__170);
	    }
	 }
	 {
	    {
	       bool_t test1379_593;
	       test1379_593 = is_a__118___object(struct__54_592, cstruct__170_foreign_ctype);
	       if (test1379_593)
		 {
		    {
		       obj_t aux_2680;
		       {
			  type_t obj_1231;
			  obj_1231 = (type_t) (struct__54_592);
			  aux_2680 = (((type_t) CREF(obj_1231))->id);
		       }
		       return declare_c_alias__61_foreign_ctype(id_20, aux_2680, name_22);
		    }
		 }
	       else
		 {
		    {
		       obj_t cobj_595;
		       cobj_595 = _cobj__54_type_cache;
		       {
			  obj_t obj_596;
			  obj_596 = _obj__252_type_cache;
			  {
			     obj_t nobj_597;
			     {
				type_t obj_1232;
				obj_1232 = (type_t) (obj_596);
				nobj_597 = (((type_t) CREF(obj_1232))->name);
			     }
			     {
				obj_t bid_598;
				{
				   obj_t arg1403_619;
				   arg1403_619 = CNST_TABLE_REF(((long) 6));
				   {
				      obj_t list1404_620;
				      {
					 obj_t arg1405_621;
					 arg1405_621 = MAKE_PAIR(id_20, BNIL);
					 list1404_620 = MAKE_PAIR(arg1403_619, arg1405_621);
				      }
				      bid_598 = symbol_append_197___r4_symbols_6_4(list1404_620);
				   }
				}
				{
				   type_t ctype_599;
				   ctype_599 = declare_subtype__66_type_env(id_20, name_22, CNST_TABLE_REF(((long) 7)), CNST_TABLE_REF(((long) 5)));
				   {
				      type_t btype_600;
				      btype_600 = declare_subtype__66_type_env(bid_598, nobj_597, CNST_TABLE_REF(((long) 8)), CNST_TABLE_REF(((long) 9)));
				      {
					 {
					    obj_t arg1383_601;
					    {
					       obj_t arg1385_603;
					       arg1385_603 = string_sans___40_type_tools(name_22);
					       {
						  obj_t list1388_605;
						  {
						     obj_t arg1389_606;
						     {
							obj_t arg1390_607;
							arg1390_607 = MAKE_PAIR(string2033_foreign_ctype, BNIL);
							arg1389_606 = MAKE_PAIR(arg1385_603, arg1390_607);
						     }
						     list1388_605 = MAKE_PAIR(string2034_foreign_ctype, arg1389_606);
						  }
						  arg1383_601 = string_append_106___r4_strings_6_7(list1388_605);
					       }
					    }
					    ((((type_t) CREF(ctype_599))->size) = ((obj_t) arg1383_601), BUNSPEC);
					 }
					 {
					    obj_t arg1392_609;
					    arg1392_609 = make_foreign_coercers_168_foreign_ctype(id_20, bid_598);
					    produce_module_clause__172_module_module(arg1392_609);
					 }
					 {
					    cstruct_t obj_1235;
					    obj_t val1160_1236;
					    obj_1235 = (cstruct_t) (struct_591);
					    val1160_1236 = (obj_t) (ctype_599);
					    {
					       obj_t aux_2706;
					       {
						  object_t aux_2707;
						  aux_2707 = (object_t) (obj_1235);
						  aux_2706 = OBJECT_WIDENING(aux_2707);
					       }
					       ((((cstruct_t) CREF(aux_2706))->cstruct__170) = ((obj_t) val1160_1236), BUNSPEC);
					    }
					 }
					 {
					    cstruct__170_t obj1202_610;
					    obj1202_610 = ((cstruct__170_t) (ctype_599));
					    {
					       cstruct__170_t arg1393_611;
					       {
						  cstruct__170_t res1840_1242;
						  {
						     cstruct_t cstruct_1238;
						     cstruct_1238 = (cstruct_t) (struct_591);
						     {
							cstruct__170_t new1168_1239;
							new1168_1239 = ((cstruct__170_t) BREF(GC_MALLOC(sizeof(struct cstruct__170))));
							((((cstruct__170_t) CREF(new1168_1239))->btype) = ((type_t) btype_600), BUNSPEC);
							((((cstruct__170_t) CREF(new1168_1239))->cstruct) = ((cstruct_t) cstruct_1238), BUNSPEC);
							res1840_1242 = new1168_1239;
						     }
						  }
						  arg1393_611 = res1840_1242;
					       }
					       {
						  obj_t aux_2718;
						  object_t aux_2716;
						  aux_2718 = (obj_t) (arg1393_611);
						  aux_2716 = (object_t) (obj1202_610);
						  OBJECT_WIDENING_SET(aux_2716, aux_2718);
					       }
					    }
					    {
					       long arg1397_614;
					       arg1397_614 = class_num_218___object(cstruct__170_foreign_ctype);
					       {
						  obj_t obj_1243;
						  obj_1243 = (obj_t) (obj1202_610);
						  (((obj_t) CREF(obj_1243))->header = MAKE_HEADER(arg1397_614, 0), BUNSPEC);
					       }
					    }
					    obj1202_610;
					 }
					 return ctype_599;
				      }
				   }
				}
			     }
			  }
		       }
		    }
		 }
	    }
	 }
      }
   }
}


/* make-foreign-coercers */ obj_t 
make_foreign_coercers_168_foreign_ctype(obj_t id_23, obj_t bid_24)
{
   {
      obj_t id__219_624;
      obj_t id__bid_132_625;
      obj_t bid__id_105_626;
      {
	 obj_t list1650_812;
	 {
	    obj_t arg1652_813;
	    {
	       obj_t aux_2724;
	       aux_2724 = CNST_TABLE_REF(((long) 13));
	       arg1652_813 = MAKE_PAIR(aux_2724, BNIL);
	    }
	    list1650_812 = MAKE_PAIR(id_23, arg1652_813);
	 }
	 id__219_624 = symbol_append_197___r4_symbols_6_4(list1650_812);
      }
      {
	 obj_t arg1654_815;
	 arg1654_815 = CNST_TABLE_REF(((long) 14));
	 {
	    obj_t list1655_816;
	    {
	       obj_t arg1656_817;
	       {
		  obj_t arg1657_818;
		  arg1657_818 = MAKE_PAIR(bid_24, BNIL);
		  arg1656_817 = MAKE_PAIR(arg1654_815, arg1657_818);
	       }
	       list1655_816 = MAKE_PAIR(id_23, arg1656_817);
	    }
	    id__bid_132_625 = symbol_append_197___r4_symbols_6_4(list1655_816);
	 }
      }
      {
	 obj_t arg1659_820;
	 arg1659_820 = CNST_TABLE_REF(((long) 14));
	 {
	    obj_t list1660_821;
	    {
	       obj_t arg1661_822;
	       {
		  obj_t arg1663_823;
		  arg1663_823 = MAKE_PAIR(id_23, BNIL);
		  arg1661_822 = MAKE_PAIR(arg1659_820, arg1663_823);
	       }
	       list1660_821 = MAKE_PAIR(bid_24, arg1661_822);
	    }
	    bid__id_105_626 = symbol_append_197___r4_symbols_6_4(list1660_821);
	 }
      }
      {
	 obj_t arg1410_627;
	 obj_t arg1411_628;
	 obj_t arg1413_629;
	 obj_t arg1414_630;
	 obj_t arg1415_631;
	 obj_t arg1416_632;
	 obj_t arg1417_633;
	 obj_t arg1418_634;
	 obj_t arg1419_635;
	 arg1410_627 = CNST_TABLE_REF(((long) 15));
	 {
	    obj_t arg1438_647;
	    obj_t arg1440_648;
	    arg1438_647 = CNST_TABLE_REF(((long) 16));
	    arg1440_648 = CNST_TABLE_REF(((long) 17));
	    {
	       obj_t list1445_652;
	       {
		  obj_t arg1446_653;
		  {
		     obj_t arg1448_654;
		     {
			obj_t arg1449_655;
			{
			   obj_t arg1450_656;
			   arg1450_656 = MAKE_PAIR(BNIL, BNIL);
			   arg1449_655 = MAKE_PAIR(BNIL, arg1450_656);
			}
			arg1448_654 = MAKE_PAIR(BNIL, arg1449_655);
		     }
		     arg1446_653 = MAKE_PAIR(arg1440_648, arg1448_654);
		  }
		  list1445_652 = MAKE_PAIR(id_23, arg1446_653);
	       }
	       arg1411_628 = cons__138___r4_pairs_and_lists_6_3(arg1438_647, list1445_652);
	    }
	 }
	 {
	    obj_t arg1454_658;
	    obj_t arg1455_659;
	    arg1454_658 = CNST_TABLE_REF(((long) 16));
	    arg1455_659 = CNST_TABLE_REF(((long) 17));
	    {
	       obj_t list1461_663;
	       {
		  obj_t arg1463_664;
		  {
		     obj_t arg1464_665;
		     {
			obj_t arg1465_666;
			{
			   obj_t arg1466_667;
			   arg1466_667 = MAKE_PAIR(BNIL, BNIL);
			   arg1465_666 = MAKE_PAIR(BNIL, arg1466_667);
			}
			arg1464_665 = MAKE_PAIR(BNIL, arg1465_666);
		     }
		     arg1463_664 = MAKE_PAIR(id_23, arg1464_665);
		  }
		  list1461_663 = MAKE_PAIR(arg1455_659, arg1463_664);
	       }
	       arg1413_629 = cons__138___r4_pairs_and_lists_6_3(arg1454_658, list1461_663);
	    }
	 }
	 {
	    obj_t arg1468_669;
	    obj_t arg1469_670;
	    arg1468_669 = CNST_TABLE_REF(((long) 16));
	    arg1469_670 = CNST_TABLE_REF(((long) 18));
	    {
	       obj_t list1474_674;
	       {
		  obj_t arg1475_675;
		  {
		     obj_t arg1476_676;
		     {
			obj_t arg1477_677;
			{
			   obj_t arg1478_678;
			   arg1478_678 = MAKE_PAIR(BNIL, BNIL);
			   arg1477_677 = MAKE_PAIR(BNIL, arg1478_678);
			}
			arg1476_676 = MAKE_PAIR(BNIL, arg1477_677);
		     }
		     arg1475_675 = MAKE_PAIR(arg1469_670, arg1476_676);
		  }
		  list1474_674 = MAKE_PAIR(bid_24, arg1475_675);
	       }
	       arg1414_630 = cons__138___r4_pairs_and_lists_6_3(arg1468_669, list1474_674);
	    }
	 }
	 {
	    obj_t arg1480_680;
	    obj_t arg1481_681;
	    obj_t arg1483_682;
	    arg1480_680 = CNST_TABLE_REF(((long) 16));
	    arg1481_681 = CNST_TABLE_REF(((long) 18));
	    {
	       obj_t list1495_692;
	       list1495_692 = MAKE_PAIR(BNIL, BNIL);
	       arg1483_682 = cons__138___r4_pairs_and_lists_6_3(id__219_624, list1495_692);
	    }
	    {
	       obj_t list1486_685;
	       {
		  obj_t arg1487_686;
		  {
		     obj_t arg1488_687;
		     {
			obj_t arg1489_688;
			{
			   obj_t arg1490_689;
			   arg1490_689 = MAKE_PAIR(BNIL, BNIL);
			   arg1489_688 = MAKE_PAIR(BNIL, arg1490_689);
			}
			arg1488_687 = MAKE_PAIR(arg1483_682, arg1489_688);
		     }
		     arg1487_686 = MAKE_PAIR(bid_24, arg1488_687);
		  }
		  list1486_685 = MAKE_PAIR(arg1481_681, arg1487_686);
	       }
	       arg1415_631 = cons__138___r4_pairs_and_lists_6_3(arg1480_680, list1486_685);
	    }
	 }
	 {
	    obj_t arg1497_694;
	    obj_t arg1499_696;
	    arg1497_694 = CNST_TABLE_REF(((long) 16));
	    {
	       obj_t arg1510_704;
	       {
		  obj_t arg1514_708;
		  obj_t arg1515_709;
		  obj_t arg1516_710;
		  arg1514_708 = CNST_TABLE_REF(((long) 19));
		  {
		     obj_t arg1525_716;
		     {
			obj_t arg1529_720;
			arg1529_720 = CNST_TABLE_REF(((long) 20));
			{
			   obj_t list1530_721;
			   {
			      obj_t arg1531_722;
			      {
				 obj_t arg1532_723;
				 arg1532_723 = MAKE_PAIR(id_23, BNIL);
				 arg1531_722 = MAKE_PAIR(_4dots_199_tools_misc, arg1532_723);
			      }
			      list1530_721 = MAKE_PAIR(arg1529_720, arg1531_722);
			   }
			   arg1525_716 = symbol_append_197___r4_symbols_6_4(list1530_721);
			}
		     }
		     {
			obj_t list1527_718;
			list1527_718 = MAKE_PAIR(BNIL, BNIL);
			arg1515_709 = cons__138___r4_pairs_and_lists_6_3(arg1525_716, list1527_718);
		     }
		  }
		  {
		     obj_t arg1534_725;
		     obj_t arg1535_726;
		     {
			obj_t arg1545_732;
			arg1545_732 = CNST_TABLE_REF(((long) 21));
			{
			   obj_t list1549_734;
			   {
			      obj_t arg1550_735;
			      arg1550_735 = MAKE_PAIR(BNIL, BNIL);
			      list1549_734 = MAKE_PAIR(bid_24, arg1550_735);
			   }
			   arg1534_725 = cons__138___r4_pairs_and_lists_6_3(arg1545_732, list1549_734);
			}
		     }
		     arg1535_726 = CNST_TABLE_REF(((long) 20));
		     {
			obj_t list1537_728;
			{
			   obj_t arg1539_729;
			   {
			      obj_t arg1540_730;
			      arg1540_730 = MAKE_PAIR(BNIL, BNIL);
			      arg1539_729 = MAKE_PAIR(arg1535_726, arg1540_730);
			   }
			   list1537_728 = MAKE_PAIR(arg1534_725, arg1539_729);
			}
			arg1516_710 = cons__138___r4_pairs_and_lists_6_3(id__bid_132_625, list1537_728);
		     }
		  }
		  {
		     obj_t list1518_712;
		     {
			obj_t arg1519_713;
			{
			   obj_t arg1522_714;
			   arg1522_714 = MAKE_PAIR(BNIL, BNIL);
			   arg1519_713 = MAKE_PAIR(arg1516_710, arg1522_714);
			}
			list1518_712 = MAKE_PAIR(arg1515_709, arg1519_713);
		     }
		     arg1510_704 = cons__138___r4_pairs_and_lists_6_3(arg1514_708, list1518_712);
		  }
	       }
	       {
		  obj_t list1512_706;
		  list1512_706 = MAKE_PAIR(BNIL, BNIL);
		  arg1499_696 = cons__138___r4_pairs_and_lists_6_3(arg1510_704, list1512_706);
	       }
	    }
	    {
	       obj_t list1501_698;
	       {
		  obj_t arg1502_699;
		  {
		     obj_t arg1503_700;
		     {
			obj_t arg1504_701;
			{
			   obj_t arg1505_702;
			   arg1505_702 = MAKE_PAIR(BNIL, BNIL);
			   arg1504_701 = MAKE_PAIR(arg1499_696, arg1505_702);
			}
			arg1503_700 = MAKE_PAIR(BNIL, arg1504_701);
		     }
		     arg1502_699 = MAKE_PAIR(bid_24, arg1503_700);
		  }
		  list1501_698 = MAKE_PAIR(id_23, arg1502_699);
	       }
	       arg1416_632 = cons__138___r4_pairs_and_lists_6_3(arg1497_694, list1501_698);
	    }
	 }
	 {
	    obj_t arg1553_737;
	    obj_t arg1554_738;
	    obj_t arg1556_740;
	    arg1553_737 = CNST_TABLE_REF(((long) 16));
	    arg1554_738 = CNST_TABLE_REF(((long) 18));
	    {
	       obj_t arg1564_748;
	       {
		  obj_t arg1569_752;
		  obj_t arg1570_753;
		  obj_t arg1572_754;
		  arg1569_752 = CNST_TABLE_REF(((long) 19));
		  {
		     obj_t arg1581_760;
		     {
			obj_t arg1585_764;
			arg1585_764 = CNST_TABLE_REF(((long) 20));
			{
			   obj_t list1586_765;
			   {
			      obj_t arg1587_766;
			      {
				 obj_t arg1588_767;
				 arg1588_767 = MAKE_PAIR(id_23, BNIL);
				 arg1587_766 = MAKE_PAIR(_4dots_199_tools_misc, arg1588_767);
			      }
			      list1586_765 = MAKE_PAIR(arg1585_764, arg1587_766);
			   }
			   arg1581_760 = symbol_append_197___r4_symbols_6_4(list1586_765);
			}
		     }
		     {
			obj_t list1583_762;
			list1583_762 = MAKE_PAIR(BNIL, BNIL);
			arg1570_753 = cons__138___r4_pairs_and_lists_6_3(arg1581_760, list1583_762);
		     }
		  }
		  {
		     obj_t arg1592_769;
		     obj_t arg1593_770;
		     {
			obj_t arg1603_776;
			arg1603_776 = CNST_TABLE_REF(((long) 21));
			{
			   obj_t list1606_778;
			   {
			      obj_t arg1607_779;
			      arg1607_779 = MAKE_PAIR(BNIL, BNIL);
			      list1606_778 = MAKE_PAIR(bid_24, arg1607_779);
			   }
			   arg1592_769 = cons__138___r4_pairs_and_lists_6_3(arg1603_776, list1606_778);
			}
		     }
		     arg1593_770 = CNST_TABLE_REF(((long) 20));
		     {
			obj_t list1595_772;
			{
			   obj_t arg1598_773;
			   {
			      obj_t arg1600_774;
			      arg1600_774 = MAKE_PAIR(BNIL, BNIL);
			      arg1598_773 = MAKE_PAIR(arg1593_770, arg1600_774);
			   }
			   list1595_772 = MAKE_PAIR(arg1592_769, arg1598_773);
			}
			arg1572_754 = cons__138___r4_pairs_and_lists_6_3(id__bid_132_625, list1595_772);
		     }
		  }
		  {
		     obj_t list1574_756;
		     {
			obj_t arg1575_757;
			{
			   obj_t arg1578_758;
			   arg1578_758 = MAKE_PAIR(BNIL, BNIL);
			   arg1575_757 = MAKE_PAIR(arg1572_754, arg1578_758);
			}
			list1574_756 = MAKE_PAIR(arg1570_753, arg1575_757);
		     }
		     arg1564_748 = cons__138___r4_pairs_and_lists_6_3(arg1569_752, list1574_756);
		  }
	       }
	       {
		  obj_t list1566_750;
		  list1566_750 = MAKE_PAIR(BNIL, BNIL);
		  arg1556_740 = cons__138___r4_pairs_and_lists_6_3(arg1564_748, list1566_750);
	       }
	    }
	    {
	       obj_t list1558_742;
	       {
		  obj_t arg1559_743;
		  {
		     obj_t arg1560_744;
		     {
			obj_t arg1561_745;
			{
			   obj_t arg1562_746;
			   arg1562_746 = MAKE_PAIR(BNIL, BNIL);
			   arg1561_745 = MAKE_PAIR(arg1556_740, arg1562_746);
			}
			arg1560_744 = MAKE_PAIR(BNIL, arg1561_745);
		     }
		     arg1559_743 = MAKE_PAIR(arg1554_738, arg1560_744);
		  }
		  list1558_742 = MAKE_PAIR(id_23, arg1559_743);
	       }
	       arg1417_633 = cons__138___r4_pairs_and_lists_6_3(arg1553_737, list1558_742);
	    }
	 }
	 {
	    obj_t arg1609_781;
	    obj_t arg1612_783;
	    arg1609_781 = CNST_TABLE_REF(((long) 16));
	    {
	       obj_t list1623_792;
	       list1623_792 = MAKE_PAIR(BNIL, BNIL);
	       arg1612_783 = cons__138___r4_pairs_and_lists_6_3(bid__id_105_626, list1623_792);
	    }
	    {
	       obj_t list1614_785;
	       {
		  obj_t arg1615_786;
		  {
		     obj_t arg1617_787;
		     {
			obj_t arg1618_788;
			{
			   obj_t arg1620_789;
			   arg1620_789 = MAKE_PAIR(BNIL, BNIL);
			   arg1618_788 = MAKE_PAIR(arg1612_783, arg1620_789);
			}
			arg1617_787 = MAKE_PAIR(BNIL, arg1618_788);
		     }
		     arg1615_786 = MAKE_PAIR(id_23, arg1617_787);
		  }
		  list1614_785 = MAKE_PAIR(bid_24, arg1615_786);
	       }
	       arg1418_634 = cons__138___r4_pairs_and_lists_6_3(arg1609_781, list1614_785);
	    }
	 }
	 {
	    obj_t arg1625_794;
	    obj_t arg1627_795;
	    obj_t arg1628_796;
	    obj_t arg1630_797;
	    arg1625_794 = CNST_TABLE_REF(((long) 16));
	    arg1627_795 = CNST_TABLE_REF(((long) 18));
	    {
	       obj_t list1642_806;
	       list1642_806 = MAKE_PAIR(BNIL, BNIL);
	       arg1628_796 = cons__138___r4_pairs_and_lists_6_3(id__219_624, list1642_806);
	    }
	    {
	       obj_t list1647_809;
	       list1647_809 = MAKE_PAIR(BNIL, BNIL);
	       arg1630_797 = cons__138___r4_pairs_and_lists_6_3(bid__id_105_626, list1647_809);
	    }
	    {
	       obj_t list1633_799;
	       {
		  obj_t arg1634_800;
		  {
		     obj_t arg1636_801;
		     {
			obj_t arg1638_802;
			{
			   obj_t arg1639_803;
			   arg1639_803 = MAKE_PAIR(BNIL, BNIL);
			   arg1638_802 = MAKE_PAIR(arg1630_797, arg1639_803);
			}
			arg1636_801 = MAKE_PAIR(arg1628_796, arg1638_802);
		     }
		     arg1634_800 = MAKE_PAIR(id_23, arg1636_801);
		  }
		  list1633_799 = MAKE_PAIR(arg1627_795, arg1634_800);
	       }
	       arg1419_635 = cons__138___r4_pairs_and_lists_6_3(arg1625_794, list1633_799);
	    }
	 }
	 {
	    obj_t list1422_637;
	    {
	       obj_t arg1423_638;
	       {
		  obj_t arg1426_639;
		  {
		     obj_t arg1427_640;
		     {
			obj_t arg1428_641;
			{
			   obj_t arg1431_642;
			   {
			      obj_t arg1432_643;
			      {
				 obj_t arg1433_644;
				 {
				    obj_t arg1436_645;
				    arg1436_645 = MAKE_PAIR(BNIL, BNIL);
				    arg1433_644 = MAKE_PAIR(arg1419_635, arg1436_645);
				 }
				 arg1432_643 = MAKE_PAIR(arg1418_634, arg1433_644);
			      }
			      arg1431_642 = MAKE_PAIR(arg1417_633, arg1432_643);
			   }
			   arg1428_641 = MAKE_PAIR(arg1416_632, arg1431_642);
			}
			arg1427_640 = MAKE_PAIR(arg1415_631, arg1428_641);
		     }
		     arg1426_639 = MAKE_PAIR(arg1414_630, arg1427_640);
		  }
		  arg1423_638 = MAKE_PAIR(arg1413_629, arg1426_639);
	       }
	       list1422_637 = MAKE_PAIR(arg1411_628, arg1423_638);
	    }
	    return cons__138___r4_pairs_and_lists_6_3(arg1410_627, list1422_637);
	 }
      }
   }
}


/* object-init */ obj_t 
object_init_111_foreign_ctype()
{
   {
      obj_t arg1667_826;
      arg1667_826 = type_type_type;
      calias_foreign_ctype = add_class__117___object(CNST_TABLE_REF(((long) 22)), arg1667_826, allocate_calias_env_186_foreign_ctype, ((long) 60395), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1672_830;
      arg1672_830 = type_type_type;
      cenum_foreign_ctype = add_class__117___object(CNST_TABLE_REF(((long) 23)), arg1672_830, allocate_cenum_env_35_foreign_ctype, ((long) 29922), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1677_834;
      arg1677_834 = type_type_type;
      cfunction_foreign_ctype = add_class__117___object(CNST_TABLE_REF(((long) 24)), arg1677_834, allocate_cfunction_env_6_foreign_ctype, ((long) 32485), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1681_838;
      arg1681_838 = type_type_type;
      cptr_foreign_ctype = add_class__117___object(CNST_TABLE_REF(((long) 25)), arg1681_838, allocate_cptr_env_152_foreign_ctype, ((long) 52069), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1685_842;
      arg1685_842 = type_type_type;
      cstruct_foreign_ctype = add_class__117___object(CNST_TABLE_REF(((long) 26)), arg1685_842, allocate_cstruct_env_64_foreign_ctype, ((long) 2561), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1691_846;
      arg1691_846 = type_type_type;
      cstruct__170_foreign_ctype = add_class__117___object(CNST_TABLE_REF(((long) 27)), arg1691_846, allocate_cstruct__env_60_foreign_ctype, ((long) 39212), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-cstruct* */ type_t 
allocate_cstruct__181_foreign_ctype()
{
   {
      type_t new1185_849;
      new1185_849 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1694_850;
	 arg1694_850 = class_num_218___object(cstruct__170_foreign_ctype);
	 {
	    obj_t obj_1245;
	    obj_1245 = (obj_t) (new1185_849);
	    (((obj_t) CREF(obj_1245))->header = MAKE_HEADER(arg1694_850, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2882;
	 aux_2882 = (object_t) (new1185_849);
	 OBJECT_WIDENING_SET(aux_2882, BFALSE);
      }
      return new1185_849;
   }
}


/* _allocate-cstruct* */ obj_t 
_allocate_cstruct__211_foreign_ctype(obj_t env_1802)
{
   {
      type_t aux_2885;
      aux_2885 = allocate_cstruct__181_foreign_ctype();
      return (obj_t) (aux_2885);
   }
}


/* cstruct*? */ bool_t 
cstruct___171_foreign_ctype(obj_t obj_28)
{
   return is_a__118___object(obj_28, cstruct__170_foreign_ctype);
}


/* _cstruct*? */ obj_t 
_cstruct___40_foreign_ctype(obj_t env_1803, obj_t obj_1804)
{
   {
      bool_t aux_2889;
      aux_2889 = cstruct___171_foreign_ctype(obj_1804);
      return BBOOL(aux_2889);
   }
}


/* widening1007-cstruct* */ cstruct__170_t 
widening1007_cstruct__84_foreign_ctype(type_t btype_29, cstruct_t cstruct_30)
{
   {
      cstruct__170_t new1168_1247;
      new1168_1247 = ((cstruct__170_t) BREF(GC_MALLOC(sizeof(struct cstruct__170))));
      ((((cstruct__170_t) CREF(new1168_1247))->btype) = ((type_t) btype_29), BUNSPEC);
      ((((cstruct__170_t) CREF(new1168_1247))->cstruct) = ((cstruct_t) cstruct_30), BUNSPEC);
      return new1168_1247;
   }
}


/* _widening1007-cstruct*1860 */ obj_t 
_widening1007_cstruct_1860_48_foreign_ctype(obj_t env_1805, obj_t btype_1806, obj_t cstruct_1807)
{
   {
      cstruct__170_t aux_2895;
      aux_2895 = widening1007_cstruct__84_foreign_ctype((type_t) (btype_1806), (cstruct_t) (cstruct_1807));
      return (obj_t) (aux_2895);
   }
}


/* make-cstruct* */ cstruct__170_t 
make_cstruct__157_foreign_ctype(obj_t id_31, obj_t name_32, obj_t size_33, obj_t class_34, obj_t coerce_to_204_35, obj_t parents_36, bool_t init__47_37, bool_t magic__53_38, obj_t __57_39, obj_t alias_40, obj_t pointed_to_by_76_41, obj_t tvector_42, type_t btype_43, cstruct_t cstruct_44)
{
   {
      type_t aux1172_1250;
      {
	 type_t res1841_1282;
	 {
	    type_t new1008_1266;
	    new1008_1266 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
	    {
	       long arg1717_1267;
	       arg1717_1267 = class_num_218___object(type_type_type);
	       {
		  obj_t obj_1280;
		  obj_1280 = (obj_t) (new1008_1266);
		  (((obj_t) CREF(obj_1280))->header = MAKE_HEADER(arg1717_1267, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_2904;
	       aux_2904 = (object_t) (new1008_1266);
	       OBJECT_WIDENING_SET(aux_2904, BFALSE);
	    }
	    ((((type_t) CREF(new1008_1266))->id) = ((obj_t) id_31), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->name) = ((obj_t) name_32), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->size) = ((obj_t) size_33), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->class) = ((obj_t) class_34), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->coerce_to_204) = ((obj_t) coerce_to_204_35), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->parents) = ((obj_t) parents_36), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->init__47) = ((bool_t) init__47_37), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->magic__53) = ((bool_t) magic__53_38), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->__57) = ((obj_t) __57_39), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->alias) = ((obj_t) alias_40), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_41), BUNSPEC);
	    ((((type_t) CREF(new1008_1266))->tvector) = ((obj_t) tvector_42), BUNSPEC);
	    res1841_1282 = new1008_1266;
	 }
	 aux1172_1250 = res1841_1282;
      }
      {
	 cstruct__170_t new1173_1251;
	 new1173_1251 = ((cstruct__170_t) (aux1172_1250));
	 {
	    long arg1695_1252;
	    arg1695_1252 = class_num_218___object(cstruct__170_foreign_ctype);
	    {
	       obj_t obj_1283;
	       obj_1283 = (obj_t) (new1173_1251);
	       (((obj_t) CREF(obj_1283))->header = MAKE_HEADER(arg1695_1252, 0), BUNSPEC);
	    }
	 }
	 {
	    cstruct__170_t arg1697_1253;
	    {
	       cstruct__170_t res1842_1290;
	       {
		  cstruct__170_t new1168_1287;
		  new1168_1287 = ((cstruct__170_t) BREF(GC_MALLOC(sizeof(struct cstruct__170))));
		  ((((cstruct__170_t) CREF(new1168_1287))->btype) = ((type_t) btype_43), BUNSPEC);
		  ((((cstruct__170_t) CREF(new1168_1287))->cstruct) = ((cstruct_t) cstruct_44), BUNSPEC);
		  res1842_1290 = new1168_1287;
	       }
	       arg1697_1253 = res1842_1290;
	    }
	    {
	       obj_t aux_2928;
	       object_t aux_2926;
	       aux_2928 = (obj_t) (arg1697_1253);
	       aux_2926 = (object_t) (new1173_1251);
	       OBJECT_WIDENING_SET(aux_2926, aux_2928);
	    }
	 }
	 return new1173_1251;
      }
   }
}


/* _make-cstruct*1861 */ obj_t 
_make_cstruct_1861_187_foreign_ctype(obj_t env_1808, obj_t id_1809, obj_t name_1810, obj_t size_1811, obj_t class_1812, obj_t coerce_to_204_1813, obj_t parents_1814, obj_t init__47_1815, obj_t magic__53_1816, obj_t __57_1817, obj_t alias_1818, obj_t pointed_to_by_76_1819, obj_t tvector_1820, obj_t btype_1821, obj_t cstruct_1822)
{
   {
      cstruct__170_t aux_2931;
      aux_2931 = make_cstruct__157_foreign_ctype(id_1809, name_1810, size_1811, class_1812, coerce_to_204_1813, parents_1814, CBOOL(init__47_1815), CBOOL(magic__53_1816), __57_1817, alias_1818, pointed_to_by_76_1819, tvector_1820, (type_t) (btype_1821), (cstruct_t) (cstruct_1822));
      return (obj_t) (aux_2931);
   }
}


/* cstruct*-id */ obj_t 
cstruct__id_51_foreign_ctype(type_t obj_45)
{
   return (((type_t) CREF(obj_45))->id);
}


/* _cstruct*-id1862 */ obj_t 
_cstruct__id1862_28_foreign_ctype(obj_t env_1823, obj_t obj_1824)
{
   return cstruct__id_51_foreign_ctype((type_t) (obj_1824));
}


/* cstruct*-name-set! */ obj_t 
cstruct__name_set__191_foreign_ctype(type_t obj_46, obj_t val1174_47)
{
   return ((((type_t) CREF(obj_46))->name) = ((obj_t) val1174_47), BUNSPEC);
}


/* _cstruct*-name-set!1863 */ obj_t 
_cstruct__name_set_1863_172_foreign_ctype(obj_t env_1825, obj_t obj_1826, obj_t val1174_1827)
{
   return cstruct__name_set__191_foreign_ctype((type_t) (obj_1826), val1174_1827);
}


/* cstruct*-name */ obj_t 
cstruct__name_49_foreign_ctype(type_t obj_48)
{
   return (((type_t) CREF(obj_48))->name);
}


/* _cstruct*-name1864 */ obj_t 
_cstruct__name1864_107_foreign_ctype(obj_t env_1828, obj_t obj_1829)
{
   return cstruct__name_49_foreign_ctype((type_t) (obj_1829));
}


/* cstruct*-size-set! */ obj_t 
cstruct__size_set__210_foreign_ctype(type_t obj_49, obj_t val1175_50)
{
   return ((((type_t) CREF(obj_49))->size) = ((obj_t) val1175_50), BUNSPEC);
}


/* _cstruct*-size-set!1865 */ obj_t 
_cstruct__size_set_1865_53_foreign_ctype(obj_t env_1830, obj_t obj_1831, obj_t val1175_1832)
{
   return cstruct__size_set__210_foreign_ctype((type_t) (obj_1831), val1175_1832);
}


/* cstruct*-size */ obj_t 
cstruct__size_205_foreign_ctype(type_t obj_51)
{
   return (((type_t) CREF(obj_51))->size);
}


/* _cstruct*-size1866 */ obj_t 
_cstruct__size1866_255_foreign_ctype(obj_t env_1833, obj_t obj_1834)
{
   return cstruct__size_205_foreign_ctype((type_t) (obj_1834));
}


/* cstruct*-class-set! */ obj_t 
cstruct__class_set__61_foreign_ctype(type_t obj_52, obj_t val1176_53)
{
   return ((((type_t) CREF(obj_52))->class) = ((obj_t) val1176_53), BUNSPEC);
}


/* _cstruct*-class-set!1867 */ obj_t 
_cstruct__class_set_1867_75_foreign_ctype(obj_t env_1835, obj_t obj_1836, obj_t val1176_1837)
{
   return cstruct__class_set__61_foreign_ctype((type_t) (obj_1836), val1176_1837);
}


/* cstruct*-class */ obj_t 
cstruct__class_95_foreign_ctype(type_t obj_54)
{
   return (((type_t) CREF(obj_54))->class);
}


/* _cstruct*-class1868 */ obj_t 
_cstruct__class1868_56_foreign_ctype(obj_t env_1838, obj_t obj_1839)
{
   return cstruct__class_95_foreign_ctype((type_t) (obj_1839));
}


/* cstruct*-coerce-to-set! */ obj_t 
cstruct__coerce_to_set__200_foreign_ctype(type_t obj_55, obj_t val1177_56)
{
   return ((((type_t) CREF(obj_55))->coerce_to_204) = ((obj_t) val1177_56), BUNSPEC);
}


/* _cstruct*-coerce-to-set!1869 */ obj_t 
_cstruct__coerce_to_set_1869_25_foreign_ctype(obj_t env_1840, obj_t obj_1841, obj_t val1177_1842)
{
   return cstruct__coerce_to_set__200_foreign_ctype((type_t) (obj_1841), val1177_1842);
}


/* cstruct*-coerce-to */ obj_t 
cstruct__coerce_to_8_foreign_ctype(type_t obj_57)
{
   return (((type_t) CREF(obj_57))->coerce_to_204);
}


/* _cstruct*-coerce-to1870 */ obj_t 
_cstruct__coerce_to1870_126_foreign_ctype(obj_t env_1843, obj_t obj_1844)
{
   return cstruct__coerce_to_8_foreign_ctype((type_t) (obj_1844));
}


/* cstruct*-parents-set! */ obj_t 
cstruct__parents_set__224_foreign_ctype(type_t obj_58, obj_t val1178_59)
{
   return ((((type_t) CREF(obj_58))->parents) = ((obj_t) val1178_59), BUNSPEC);
}


/* _cstruct*-parents-set!1871 */ obj_t 
_cstruct__parents_set_1871_149_foreign_ctype(obj_t env_1845, obj_t obj_1846, obj_t val1178_1847)
{
   return cstruct__parents_set__224_foreign_ctype((type_t) (obj_1846), val1178_1847);
}


/* cstruct*-parents */ obj_t 
cstruct__parents_225_foreign_ctype(type_t obj_60)
{
   return (((type_t) CREF(obj_60))->parents);
}


/* _cstruct*-parents1872 */ obj_t 
_cstruct__parents1872_30_foreign_ctype(obj_t env_1848, obj_t obj_1849)
{
   return cstruct__parents_225_foreign_ctype((type_t) (obj_1849));
}


/* cstruct*-init?-set! */ obj_t 
cstruct__init__set__144_foreign_ctype(type_t obj_61, bool_t val1179_62)
{
   return ((((type_t) CREF(obj_61))->init__47) = ((bool_t) val1179_62), BUNSPEC);
}


/* _cstruct*-init?-set!1873 */ obj_t 
_cstruct__init__set_1873_51_foreign_ctype(obj_t env_1850, obj_t obj_1851, obj_t val1179_1852)
{
   return cstruct__init__set__144_foreign_ctype((type_t) (obj_1851), CBOOL(val1179_1852));
}


/* cstruct*-init? */ bool_t 
cstruct__init__248_foreign_ctype(type_t obj_63)
{
   return (((type_t) CREF(obj_63))->init__47);
}


/* _cstruct*-init?1874 */ obj_t 
_cstruct__init_1874_158_foreign_ctype(obj_t env_1853, obj_t obj_1854)
{
   {
      bool_t aux_2976;
      aux_2976 = cstruct__init__248_foreign_ctype((type_t) (obj_1854));
      return BBOOL(aux_2976);
   }
}


/* cstruct*-magic?-set! */ obj_t 
cstruct__magic__set__181_foreign_ctype(type_t obj_64, bool_t val1180_65)
{
   return ((((type_t) CREF(obj_64))->magic__53) = ((bool_t) val1180_65), BUNSPEC);
}


/* _cstruct*-magic?-set!1875 */ obj_t 
_cstruct__magic__set_1875_54_foreign_ctype(obj_t env_1855, obj_t obj_1856, obj_t val1180_1857)
{
   return cstruct__magic__set__181_foreign_ctype((type_t) (obj_1856), CBOOL(val1180_1857));
}


/* cstruct*-magic? */ bool_t 
cstruct__magic__185_foreign_ctype(type_t obj_66)
{
   return (((type_t) CREF(obj_66))->magic__53);
}


/* _cstruct*-magic?1876 */ obj_t 
_cstruct__magic_1876_41_foreign_ctype(obj_t env_1858, obj_t obj_1859)
{
   {
      bool_t aux_2985;
      aux_2985 = cstruct__magic__185_foreign_ctype((type_t) (obj_1859));
      return BBOOL(aux_2985);
   }
}


/* cstruct*-$-set! */ obj_t 
cstruct____set__209_foreign_ctype(type_t obj_67, obj_t val1181_68)
{
   return ((((type_t) CREF(obj_67))->__57) = ((obj_t) val1181_68), BUNSPEC);
}


/* _cstruct*-$-set!1877 */ obj_t 
_cstruct____set_1877_75_foreign_ctype(obj_t env_1860, obj_t obj_1861, obj_t val1181_1862)
{
   return cstruct____set__209_foreign_ctype((type_t) (obj_1861), val1181_1862);
}


/* cstruct*-$ */ obj_t 
cstruct____54_foreign_ctype(type_t obj_69)
{
   return (((type_t) CREF(obj_69))->__57);
}


/* _cstruct*-$1878 */ obj_t 
_cstruct___1878_35_foreign_ctype(obj_t env_1863, obj_t obj_1864)
{
   return cstruct____54_foreign_ctype((type_t) (obj_1864));
}


/* cstruct*-alias-set! */ obj_t 
cstruct__alias_set__14_foreign_ctype(type_t obj_70, obj_t val1182_71)
{
   return ((((type_t) CREF(obj_70))->alias) = ((obj_t) val1182_71), BUNSPEC);
}


/* _cstruct*-alias-set!1879 */ obj_t 
_cstruct__alias_set_1879_62_foreign_ctype(obj_t env_1865, obj_t obj_1866, obj_t val1182_1867)
{
   return cstruct__alias_set__14_foreign_ctype((type_t) (obj_1866), val1182_1867);
}


/* cstruct*-alias */ obj_t 
cstruct__alias_70_foreign_ctype(type_t obj_72)
{
   return (((type_t) CREF(obj_72))->alias);
}


/* _cstruct*-alias1880 */ obj_t 
_cstruct__alias1880_170_foreign_ctype(obj_t env_1868, obj_t obj_1869)
{
   return cstruct__alias_70_foreign_ctype((type_t) (obj_1869));
}


/* cstruct*-pointed-to-by-set! */ obj_t 
cstruct__pointed_to_by_set__253_foreign_ctype(type_t obj_73, obj_t val1183_74)
{
   return ((((type_t) CREF(obj_73))->pointed_to_by_76) = ((obj_t) val1183_74), BUNSPEC);
}


/* _cstruct*-pointed-to-by-set!1881 */ obj_t 
_cstruct__pointed_to_by_set_1881_39_foreign_ctype(obj_t env_1870, obj_t obj_1871, obj_t val1183_1872)
{
   return cstruct__pointed_to_by_set__253_foreign_ctype((type_t) (obj_1871), val1183_1872);
}


/* cstruct*-pointed-to-by */ obj_t 
cstruct__pointed_to_by_43_foreign_ctype(type_t obj_75)
{
   return (((type_t) CREF(obj_75))->pointed_to_by_76);
}


/* _cstruct*-pointed-to-by1882 */ obj_t 
_cstruct__pointed_to_by1882_106_foreign_ctype(obj_t env_1873, obj_t obj_1874)
{
   return cstruct__pointed_to_by_43_foreign_ctype((type_t) (obj_1874));
}


/* cstruct*-tvector-set! */ obj_t 
cstruct__tvector_set__171_foreign_ctype(type_t obj_76, obj_t val1184_77)
{
   return ((((type_t) CREF(obj_76))->tvector) = ((obj_t) val1184_77), BUNSPEC);
}


/* _cstruct*-tvector-set!1883 */ obj_t 
_cstruct__tvector_set_1883_89_foreign_ctype(obj_t env_1875, obj_t obj_1876, obj_t val1184_1877)
{
   return cstruct__tvector_set__171_foreign_ctype((type_t) (obj_1876), val1184_1877);
}


/* cstruct*-tvector */ obj_t 
cstruct__tvector_148_foreign_ctype(type_t obj_78)
{
   return (((type_t) CREF(obj_78))->tvector);
}


/* _cstruct*-tvector1884 */ obj_t 
_cstruct__tvector1884_54_foreign_ctype(obj_t env_1878, obj_t obj_1879)
{
   return cstruct__tvector_148_foreign_ctype((type_t) (obj_1879));
}


/* cstruct*-btype */ type_t 
cstruct__btype_111_foreign_ctype(cstruct__170_t obj_79)
{
   {
      obj_t aux_3013;
      {
	 object_t aux_3014;
	 aux_3014 = (object_t) (obj_79);
	 aux_3013 = OBJECT_WIDENING(aux_3014);
      }
      return (((cstruct__170_t) CREF(aux_3013))->btype);
   }
}


/* _cstruct*-btype1885 */ obj_t 
_cstruct__btype1885_131_foreign_ctype(obj_t env_1880, obj_t obj_1881)
{
   {
      type_t aux_3018;
      aux_3018 = cstruct__btype_111_foreign_ctype((cstruct__170_t) (obj_1881));
      return (obj_t) (aux_3018);
   }
}


/* cstruct*-cstruct */ cstruct_t 
cstruct__cstruct_236_foreign_ctype(cstruct__170_t obj_80)
{
   {
      obj_t aux_3022;
      {
	 object_t aux_3023;
	 aux_3023 = (object_t) (obj_80);
	 aux_3022 = OBJECT_WIDENING(aux_3023);
      }
      return (((cstruct__170_t) CREF(aux_3022))->cstruct);
   }
}


/* _cstruct*-cstruct1886 */ obj_t 
_cstruct__cstruct1886_96_foreign_ctype(obj_t env_1882, obj_t obj_1883)
{
   {
      cstruct_t aux_3027;
      aux_3027 = cstruct__cstruct_236_foreign_ctype((cstruct__170_t) (obj_1883));
      return (obj_t) (aux_3027);
   }
}


/* allocate-cstruct */ type_t 
allocate_cstruct_27_foreign_ctype()
{
   {
      type_t new1161_858;
      new1161_858 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1698_859;
	 arg1698_859 = class_num_218___object(cstruct_foreign_ctype);
	 {
	    obj_t obj_1291;
	    obj_1291 = (obj_t) (new1161_858);
	    (((obj_t) CREF(obj_1291))->header = MAKE_HEADER(arg1698_859, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3035;
	 aux_3035 = (object_t) (new1161_858);
	 OBJECT_WIDENING_SET(aux_3035, BFALSE);
      }
      return new1161_858;
   }
}


/* _allocate-cstruct */ obj_t 
_allocate_cstruct_15_foreign_ctype(obj_t env_1801)
{
   {
      type_t aux_3038;
      aux_3038 = allocate_cstruct_27_foreign_ctype();
      return (obj_t) (aux_3038);
   }
}


/* cstruct? */ bool_t 
cstruct__188_foreign_ctype(obj_t obj_84)
{
   return is_a__118___object(obj_84, cstruct_foreign_ctype);
}


/* _cstruct? */ obj_t 
_cstruct__158_foreign_ctype(obj_t env_1884, obj_t obj_1885)
{
   {
      bool_t aux_3042;
      aux_3042 = cstruct__188_foreign_ctype(obj_1885);
      return BBOOL(aux_3042);
   }
}


/* widening1006-cstruct */ cstruct_t 
widening1006_cstruct_174_foreign_ctype(bool_t struct__46_85, obj_t fields_86, obj_t cstruct__170_87)
{
   {
      cstruct_t new1142_1293;
      new1142_1293 = ((cstruct_t) BREF(GC_MALLOC(sizeof(struct cstruct))));
      ((((cstruct_t) CREF(new1142_1293))->struct__46) = ((bool_t) struct__46_85), BUNSPEC);
      ((((cstruct_t) CREF(new1142_1293))->fields) = ((obj_t) fields_86), BUNSPEC);
      ((((cstruct_t) CREF(new1142_1293))->cstruct__170) = ((obj_t) cstruct__170_87), BUNSPEC);
      return new1142_1293;
   }
}


/* _widening1006-cstruct */ obj_t 
_widening1006_cstruct_89_foreign_ctype(obj_t env_1886, obj_t struct__46_1887, obj_t fields_1888, obj_t cstruct__170_1889)
{
   {
      cstruct_t aux_3049;
      aux_3049 = widening1006_cstruct_174_foreign_ctype(CBOOL(struct__46_1887), fields_1888, cstruct__170_1889);
      return (obj_t) (aux_3049);
   }
}


/* make-cstruct */ cstruct_t 
make_cstruct_17_foreign_ctype(obj_t id_88, obj_t name_89, obj_t size_90, obj_t class_91, obj_t coerce_to_204_92, obj_t parents_93, bool_t init__47_94, bool_t magic__53_95, obj_t __57_96, obj_t alias_97, obj_t pointed_to_by_76_98, obj_t tvector_99, bool_t struct__46_100, obj_t fields_101, obj_t cstruct__170_102)
{
   {
      type_t aux1147_1297;
      {
	 type_t res1843_1329;
	 {
	    type_t new1008_1313;
	    new1008_1313 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
	    {
	       long arg1717_1314;
	       arg1717_1314 = class_num_218___object(type_type_type);
	       {
		  obj_t obj_1327;
		  obj_1327 = (obj_t) (new1008_1313);
		  (((obj_t) CREF(obj_1327))->header = MAKE_HEADER(arg1717_1314, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3057;
	       aux_3057 = (object_t) (new1008_1313);
	       OBJECT_WIDENING_SET(aux_3057, BFALSE);
	    }
	    ((((type_t) CREF(new1008_1313))->id) = ((obj_t) id_88), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->name) = ((obj_t) name_89), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->size) = ((obj_t) size_90), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->class) = ((obj_t) class_91), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->coerce_to_204) = ((obj_t) coerce_to_204_92), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->parents) = ((obj_t) parents_93), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->init__47) = ((bool_t) init__47_94), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->magic__53) = ((bool_t) magic__53_95), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->__57) = ((obj_t) __57_96), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->alias) = ((obj_t) alias_97), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_98), BUNSPEC);
	    ((((type_t) CREF(new1008_1313))->tvector) = ((obj_t) tvector_99), BUNSPEC);
	    res1843_1329 = new1008_1313;
	 }
	 aux1147_1297 = res1843_1329;
      }
      {
	 cstruct_t new1148_1298;
	 new1148_1298 = ((cstruct_t) (aux1147_1297));
	 {
	    long arg1699_1299;
	    arg1699_1299 = class_num_218___object(cstruct_foreign_ctype);
	    {
	       obj_t obj_1330;
	       obj_1330 = (obj_t) (new1148_1298);
	       (((obj_t) CREF(obj_1330))->header = MAKE_HEADER(arg1699_1299, 0), BUNSPEC);
	    }
	 }
	 {
	    cstruct_t arg1700_1300;
	    {
	       cstruct_t res1844_1339;
	       {
		  cstruct_t new1142_1335;
		  new1142_1335 = ((cstruct_t) BREF(GC_MALLOC(sizeof(struct cstruct))));
		  ((((cstruct_t) CREF(new1142_1335))->struct__46) = ((bool_t) struct__46_100), BUNSPEC);
		  ((((cstruct_t) CREF(new1142_1335))->fields) = ((obj_t) fields_101), BUNSPEC);
		  ((((cstruct_t) CREF(new1142_1335))->cstruct__170) = ((obj_t) cstruct__170_102), BUNSPEC);
		  res1844_1339 = new1142_1335;
	       }
	       arg1700_1300 = res1844_1339;
	    }
	    {
	       obj_t aux_3082;
	       object_t aux_3080;
	       aux_3082 = (obj_t) (arg1700_1300);
	       aux_3080 = (object_t) (new1148_1298);
	       OBJECT_WIDENING_SET(aux_3080, aux_3082);
	    }
	 }
	 return new1148_1298;
      }
   }
}


/* _make-cstruct1887 */ obj_t 
_make_cstruct1887_248_foreign_ctype(obj_t env_1890, obj_t id_1891, obj_t name_1892, obj_t size_1893, obj_t class_1894, obj_t coerce_to_204_1895, obj_t parents_1896, obj_t init__47_1897, obj_t magic__53_1898, obj_t __57_1899, obj_t alias_1900, obj_t pointed_to_by_76_1901, obj_t tvector_1902, obj_t struct__46_1903, obj_t fields_1904, obj_t cstruct__170_1905)
{
   {
      cstruct_t aux_3085;
      aux_3085 = make_cstruct_17_foreign_ctype(id_1891, name_1892, size_1893, class_1894, coerce_to_204_1895, parents_1896, CBOOL(init__47_1897), CBOOL(magic__53_1898), __57_1899, alias_1900, pointed_to_by_76_1901, tvector_1902, CBOOL(struct__46_1903), fields_1904, cstruct__170_1905);
      return (obj_t) (aux_3085);
   }
}


/* cstruct-id */ obj_t 
cstruct_id_82_foreign_ctype(type_t obj_103)
{
   return (((type_t) CREF(obj_103))->id);
}


/* _cstruct-id1888 */ obj_t 
_cstruct_id1888_251_foreign_ctype(obj_t env_1906, obj_t obj_1907)
{
   return cstruct_id_82_foreign_ctype((type_t) (obj_1907));
}


/* cstruct-name-set! */ obj_t 
cstruct_name_set__169_foreign_ctype(type_t obj_104, obj_t val1149_105)
{
   return ((((type_t) CREF(obj_104))->name) = ((obj_t) val1149_105), BUNSPEC);
}


/* _cstruct-name-set!1889 */ obj_t 
_cstruct_name_set_1889_66_foreign_ctype(obj_t env_1908, obj_t obj_1909, obj_t val1149_1910)
{
   return cstruct_name_set__169_foreign_ctype((type_t) (obj_1909), val1149_1910);
}


/* cstruct-name */ obj_t 
cstruct_name_51_foreign_ctype(type_t obj_106)
{
   return (((type_t) CREF(obj_106))->name);
}


/* _cstruct-name1890 */ obj_t 
_cstruct_name1890_224_foreign_ctype(obj_t env_1911, obj_t obj_1912)
{
   return cstruct_name_51_foreign_ctype((type_t) (obj_1912));
}


/* cstruct-size-set! */ obj_t 
cstruct_size_set__133_foreign_ctype(type_t obj_107, obj_t val1150_108)
{
   return ((((type_t) CREF(obj_107))->size) = ((obj_t) val1150_108), BUNSPEC);
}


/* _cstruct-size-set!1891 */ obj_t 
_cstruct_size_set_1891_20_foreign_ctype(obj_t env_1913, obj_t obj_1914, obj_t val1150_1915)
{
   return cstruct_size_set__133_foreign_ctype((type_t) (obj_1914), val1150_1915);
}


/* cstruct-size */ obj_t 
cstruct_size_252_foreign_ctype(type_t obj_109)
{
   return (((type_t) CREF(obj_109))->size);
}


/* _cstruct-size1892 */ obj_t 
_cstruct_size1892_126_foreign_ctype(obj_t env_1916, obj_t obj_1917)
{
   return cstruct_size_252_foreign_ctype((type_t) (obj_1917));
}


/* cstruct-class-set! */ obj_t 
cstruct_class_set__32_foreign_ctype(type_t obj_110, obj_t val1151_111)
{
   return ((((type_t) CREF(obj_110))->class) = ((obj_t) val1151_111), BUNSPEC);
}


/* _cstruct-class-set!1893 */ obj_t 
_cstruct_class_set_1893_187_foreign_ctype(obj_t env_1918, obj_t obj_1919, obj_t val1151_1920)
{
   return cstruct_class_set__32_foreign_ctype((type_t) (obj_1919), val1151_1920);
}


/* cstruct-class */ obj_t 
cstruct_class_110_foreign_ctype(type_t obj_112)
{
   return (((type_t) CREF(obj_112))->class);
}


/* _cstruct-class1894 */ obj_t 
_cstruct_class1894_10_foreign_ctype(obj_t env_1921, obj_t obj_1922)
{
   return cstruct_class_110_foreign_ctype((type_t) (obj_1922));
}


/* cstruct-coerce-to-set! */ obj_t 
cstruct_coerce_to_set__7_foreign_ctype(type_t obj_113, obj_t val1152_114)
{
   return ((((type_t) CREF(obj_113))->coerce_to_204) = ((obj_t) val1152_114), BUNSPEC);
}


/* _cstruct-coerce-to-set!1895 */ obj_t 
_cstruct_coerce_to_set_1895_194_foreign_ctype(obj_t env_1923, obj_t obj_1924, obj_t val1152_1925)
{
   return cstruct_coerce_to_set__7_foreign_ctype((type_t) (obj_1924), val1152_1925);
}


/* cstruct-coerce-to */ obj_t 
cstruct_coerce_to_171_foreign_ctype(type_t obj_115)
{
   return (((type_t) CREF(obj_115))->coerce_to_204);
}


/* _cstruct-coerce-to1896 */ obj_t 
_cstruct_coerce_to1896_225_foreign_ctype(obj_t env_1926, obj_t obj_1927)
{
   return cstruct_coerce_to_171_foreign_ctype((type_t) (obj_1927));
}


/* cstruct-parents-set! */ obj_t 
cstruct_parents_set__165_foreign_ctype(type_t obj_116, obj_t val1153_117)
{
   return ((((type_t) CREF(obj_116))->parents) = ((obj_t) val1153_117), BUNSPEC);
}


/* _cstruct-parents-set!1897 */ obj_t 
_cstruct_parents_set_1897_117_foreign_ctype(obj_t env_1928, obj_t obj_1929, obj_t val1153_1930)
{
   return cstruct_parents_set__165_foreign_ctype((type_t) (obj_1929), val1153_1930);
}


/* cstruct-parents */ obj_t 
cstruct_parents_88_foreign_ctype(type_t obj_118)
{
   return (((type_t) CREF(obj_118))->parents);
}


/* _cstruct-parents1898 */ obj_t 
_cstruct_parents1898_169_foreign_ctype(obj_t env_1931, obj_t obj_1932)
{
   return cstruct_parents_88_foreign_ctype((type_t) (obj_1932));
}


/* cstruct-init?-set! */ obj_t 
cstruct_init__set__88_foreign_ctype(type_t obj_119, bool_t val1154_120)
{
   return ((((type_t) CREF(obj_119))->init__47) = ((bool_t) val1154_120), BUNSPEC);
}


/* _cstruct-init?-set!1899 */ obj_t 
_cstruct_init__set_1899_10_foreign_ctype(obj_t env_1933, obj_t obj_1934, obj_t val1154_1935)
{
   return cstruct_init__set__88_foreign_ctype((type_t) (obj_1934), CBOOL(val1154_1935));
}


/* cstruct-init? */ bool_t 
cstruct_init__254_foreign_ctype(type_t obj_121)
{
   return (((type_t) CREF(obj_121))->init__47);
}


/* _cstruct-init?1900 */ obj_t 
_cstruct_init_1900_136_foreign_ctype(obj_t env_1936, obj_t obj_1937)
{
   {
      bool_t aux_3129;
      aux_3129 = cstruct_init__254_foreign_ctype((type_t) (obj_1937));
      return BBOOL(aux_3129);
   }
}


/* cstruct-magic?-set! */ obj_t 
cstruct_magic__set__168_foreign_ctype(type_t obj_122, bool_t val1155_123)
{
   return ((((type_t) CREF(obj_122))->magic__53) = ((bool_t) val1155_123), BUNSPEC);
}


/* _cstruct-magic?-set!1901 */ obj_t 
_cstruct_magic__set_1901_171_foreign_ctype(obj_t env_1938, obj_t obj_1939, obj_t val1155_1940)
{
   return cstruct_magic__set__168_foreign_ctype((type_t) (obj_1939), CBOOL(val1155_1940));
}


/* cstruct-magic? */ bool_t 
cstruct_magic__87_foreign_ctype(type_t obj_124)
{
   return (((type_t) CREF(obj_124))->magic__53);
}


/* _cstruct-magic?1902 */ obj_t 
_cstruct_magic_1902_29_foreign_ctype(obj_t env_1941, obj_t obj_1942)
{
   {
      bool_t aux_3138;
      aux_3138 = cstruct_magic__87_foreign_ctype((type_t) (obj_1942));
      return BBOOL(aux_3138);
   }
}


/* cstruct-$-set! */ obj_t 
cstruct___set__137_foreign_ctype(type_t obj_125, obj_t val1156_126)
{
   return ((((type_t) CREF(obj_125))->__57) = ((obj_t) val1156_126), BUNSPEC);
}


/* _cstruct-$-set!1903 */ obj_t 
_cstruct___set_1903_92_foreign_ctype(obj_t env_1943, obj_t obj_1944, obj_t val1156_1945)
{
   return cstruct___set__137_foreign_ctype((type_t) (obj_1944), val1156_1945);
}


/* cstruct-$ */ obj_t 
cstruct___251_foreign_ctype(type_t obj_127)
{
   return (((type_t) CREF(obj_127))->__57);
}


/* _cstruct-$1904 */ obj_t 
_cstruct__1904_16_foreign_ctype(obj_t env_1946, obj_t obj_1947)
{
   return cstruct___251_foreign_ctype((type_t) (obj_1947));
}


/* cstruct-alias-set! */ obj_t 
cstruct_alias_set__11_foreign_ctype(type_t obj_128, obj_t val1157_129)
{
   return ((((type_t) CREF(obj_128))->alias) = ((obj_t) val1157_129), BUNSPEC);
}


/* _cstruct-alias-set!1905 */ obj_t 
_cstruct_alias_set_1905_60_foreign_ctype(obj_t env_1948, obj_t obj_1949, obj_t val1157_1950)
{
   return cstruct_alias_set__11_foreign_ctype((type_t) (obj_1949), val1157_1950);
}


/* cstruct-alias */ obj_t 
cstruct_alias_118_foreign_ctype(type_t obj_130)
{
   return (((type_t) CREF(obj_130))->alias);
}


/* _cstruct-alias1906 */ obj_t 
_cstruct_alias1906_110_foreign_ctype(obj_t env_1951, obj_t obj_1952)
{
   return cstruct_alias_118_foreign_ctype((type_t) (obj_1952));
}


/* cstruct-pointed-to-by-set! */ obj_t 
cstruct_pointed_to_by_set__16_foreign_ctype(type_t obj_131, obj_t val1158_132)
{
   return ((((type_t) CREF(obj_131))->pointed_to_by_76) = ((obj_t) val1158_132), BUNSPEC);
}


/* _cstruct-pointed-to-by-set!1907 */ obj_t 
_cstruct_pointed_to_by_set_1907_148_foreign_ctype(obj_t env_1953, obj_t obj_1954, obj_t val1158_1955)
{
   return cstruct_pointed_to_by_set__16_foreign_ctype((type_t) (obj_1954), val1158_1955);
}


/* cstruct-pointed-to-by */ obj_t 
cstruct_pointed_to_by_198_foreign_ctype(type_t obj_133)
{
   return (((type_t) CREF(obj_133))->pointed_to_by_76);
}


/* _cstruct-pointed-to-by1908 */ obj_t 
_cstruct_pointed_to_by1908_245_foreign_ctype(obj_t env_1956, obj_t obj_1957)
{
   return cstruct_pointed_to_by_198_foreign_ctype((type_t) (obj_1957));
}


/* cstruct-tvector-set! */ obj_t 
cstruct_tvector_set__212_foreign_ctype(type_t obj_134, obj_t val1159_135)
{
   return ((((type_t) CREF(obj_134))->tvector) = ((obj_t) val1159_135), BUNSPEC);
}


/* _cstruct-tvector-set!1909 */ obj_t 
_cstruct_tvector_set_1909_49_foreign_ctype(obj_t env_1958, obj_t obj_1959, obj_t val1159_1960)
{
   return cstruct_tvector_set__212_foreign_ctype((type_t) (obj_1959), val1159_1960);
}


/* cstruct-tvector */ obj_t 
cstruct_tvector_3_foreign_ctype(type_t obj_136)
{
   return (((type_t) CREF(obj_136))->tvector);
}


/* _cstruct-tvector1910 */ obj_t 
_cstruct_tvector1910_169_foreign_ctype(obj_t env_1961, obj_t obj_1962)
{
   return cstruct_tvector_3_foreign_ctype((type_t) (obj_1962));
}


/* cstruct-struct? */ bool_t 
cstruct_struct__141_foreign_ctype(cstruct_t obj_137)
{
   {
      obj_t aux_3166;
      {
	 object_t aux_3167;
	 aux_3167 = (object_t) (obj_137);
	 aux_3166 = OBJECT_WIDENING(aux_3167);
      }
      return (((cstruct_t) CREF(aux_3166))->struct__46);
   }
}


/* _cstruct-struct?1911 */ obj_t 
_cstruct_struct_1911_122_foreign_ctype(obj_t env_1963, obj_t obj_1964)
{
   {
      bool_t aux_3171;
      aux_3171 = cstruct_struct__141_foreign_ctype((cstruct_t) (obj_1964));
      return BBOOL(aux_3171);
   }
}


/* cstruct-fields */ obj_t 
cstruct_fields_109_foreign_ctype(cstruct_t obj_138)
{
   {
      obj_t aux_3175;
      {
	 object_t aux_3176;
	 aux_3176 = (object_t) (obj_138);
	 aux_3175 = OBJECT_WIDENING(aux_3176);
      }
      return (((cstruct_t) CREF(aux_3175))->fields);
   }
}


/* _cstruct-fields1912 */ obj_t 
_cstruct_fields1912_50_foreign_ctype(obj_t env_1965, obj_t obj_1966)
{
   return cstruct_fields_109_foreign_ctype((cstruct_t) (obj_1966));
}


/* cstruct-cstruct*-set! */ obj_t 
cstruct_cstruct__set__66_foreign_ctype(cstruct_t obj_139, obj_t val1160_140)
{
   {
      obj_t aux_3182;
      {
	 object_t aux_3183;
	 aux_3183 = (object_t) (obj_139);
	 aux_3182 = OBJECT_WIDENING(aux_3183);
      }
      return ((((cstruct_t) CREF(aux_3182))->cstruct__170) = ((obj_t) val1160_140), BUNSPEC);
   }
}


/* _cstruct-cstruct*-set!1913 */ obj_t 
_cstruct_cstruct__set_1913_24_foreign_ctype(obj_t env_1967, obj_t obj_1968, obj_t val1160_1969)
{
   return cstruct_cstruct__set__66_foreign_ctype((cstruct_t) (obj_1968), val1160_1969);
}


/* cstruct-cstruct* */ obj_t 
cstruct_cstruct__58_foreign_ctype(cstruct_t obj_141)
{
   {
      obj_t aux_3189;
      {
	 object_t aux_3190;
	 aux_3190 = (object_t) (obj_141);
	 aux_3189 = OBJECT_WIDENING(aux_3190);
      }
      return (((cstruct_t) CREF(aux_3189))->cstruct__170);
   }
}


/* _cstruct-cstruct*1914 */ obj_t 
_cstruct_cstruct_1914_241_foreign_ctype(obj_t env_1970, obj_t obj_1971)
{
   return cstruct_cstruct__58_foreign_ctype((cstruct_t) (obj_1971));
}


/* allocate-cptr */ type_t 
allocate_cptr_217_foreign_ctype()
{
   {
      type_t new1135_868;
      new1135_868 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1701_869;
	 arg1701_869 = class_num_218___object(cptr_foreign_ctype);
	 {
	    obj_t obj_1340;
	    obj_1340 = (obj_t) (new1135_868);
	    (((obj_t) CREF(obj_1340))->header = MAKE_HEADER(arg1701_869, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3200;
	 aux_3200 = (object_t) (new1135_868);
	 OBJECT_WIDENING_SET(aux_3200, BFALSE);
      }
      return new1135_868;
   }
}


/* _allocate-cptr */ obj_t 
_allocate_cptr_1_foreign_ctype(obj_t env_1800)
{
   {
      type_t aux_3203;
      aux_3203 = allocate_cptr_217_foreign_ctype();
      return (obj_t) (aux_3203);
   }
}


/* cptr? */ bool_t 
cptr__215_foreign_ctype(obj_t obj_145)
{
   return is_a__118___object(obj_145, cptr_foreign_ctype);
}


/* _cptr? */ obj_t 
_cptr__176_foreign_ctype(obj_t env_1972, obj_t obj_1973)
{
   {
      bool_t aux_3207;
      aux_3207 = cptr__215_foreign_ctype(obj_1973);
      return BBOOL(aux_3207);
   }
}


/* widening1005-cptr */ cptr_t 
widening1005_cptr_244_foreign_ctype(type_t btype_146, type_t point_to_164_147, bool_t array__248_148)
{
   {
      cptr_t new1117_1342;
      new1117_1342 = ((cptr_t) BREF(GC_MALLOC(sizeof(struct cptr))));
      ((((cptr_t) CREF(new1117_1342))->btype) = ((type_t) btype_146), BUNSPEC);
      ((((cptr_t) CREF(new1117_1342))->point_to_164) = ((type_t) point_to_164_147), BUNSPEC);
      ((((cptr_t) CREF(new1117_1342))->array__248) = ((bool_t) array__248_148), BUNSPEC);
      return new1117_1342;
   }
}


/* _widening1005-cptr1915 */ obj_t 
_widening1005_cptr1915_81_foreign_ctype(obj_t env_1974, obj_t btype_1975, obj_t point_to_164_1976, obj_t array__248_1977)
{
   {
      cptr_t aux_3214;
      aux_3214 = widening1005_cptr_244_foreign_ctype((type_t) (btype_1975), (type_t) (point_to_164_1976), CBOOL(array__248_1977));
      return (obj_t) (aux_3214);
   }
}


/* make-cptr */ cptr_t 
make_cptr_169_foreign_ctype(obj_t id_149, obj_t name_150, obj_t size_151, obj_t class_152, obj_t coerce_to_204_153, obj_t parents_154, bool_t init__47_155, bool_t magic__53_156, obj_t __57_157, obj_t alias_158, obj_t pointed_to_by_76_159, obj_t tvector_160, type_t btype_161, type_t point_to_164_162, bool_t array__248_163)
{
   {
      type_t aux1122_1346;
      {
	 type_t res1845_1378;
	 {
	    type_t new1008_1362;
	    new1008_1362 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
	    {
	       long arg1717_1363;
	       arg1717_1363 = class_num_218___object(type_type_type);
	       {
		  obj_t obj_1376;
		  obj_1376 = (obj_t) (new1008_1362);
		  (((obj_t) CREF(obj_1376))->header = MAKE_HEADER(arg1717_1363, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3224;
	       aux_3224 = (object_t) (new1008_1362);
	       OBJECT_WIDENING_SET(aux_3224, BFALSE);
	    }
	    ((((type_t) CREF(new1008_1362))->id) = ((obj_t) id_149), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->name) = ((obj_t) name_150), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->size) = ((obj_t) size_151), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->class) = ((obj_t) class_152), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->coerce_to_204) = ((obj_t) coerce_to_204_153), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->parents) = ((obj_t) parents_154), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->init__47) = ((bool_t) init__47_155), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->magic__53) = ((bool_t) magic__53_156), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->__57) = ((obj_t) __57_157), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->alias) = ((obj_t) alias_158), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_159), BUNSPEC);
	    ((((type_t) CREF(new1008_1362))->tvector) = ((obj_t) tvector_160), BUNSPEC);
	    res1845_1378 = new1008_1362;
	 }
	 aux1122_1346 = res1845_1378;
      }
      {
	 cptr_t new1123_1347;
	 new1123_1347 = ((cptr_t) (aux1122_1346));
	 {
	    long arg1702_1348;
	    arg1702_1348 = class_num_218___object(cptr_foreign_ctype);
	    {
	       obj_t obj_1379;
	       obj_1379 = (obj_t) (new1123_1347);
	       (((obj_t) CREF(obj_1379))->header = MAKE_HEADER(arg1702_1348, 0), BUNSPEC);
	    }
	 }
	 {
	    cptr_t arg1703_1349;
	    {
	       cptr_t res1846_1388;
	       {
		  cptr_t new1117_1384;
		  new1117_1384 = ((cptr_t) BREF(GC_MALLOC(sizeof(struct cptr))));
		  ((((cptr_t) CREF(new1117_1384))->btype) = ((type_t) btype_161), BUNSPEC);
		  ((((cptr_t) CREF(new1117_1384))->point_to_164) = ((type_t) point_to_164_162), BUNSPEC);
		  ((((cptr_t) CREF(new1117_1384))->array__248) = ((bool_t) array__248_163), BUNSPEC);
		  res1846_1388 = new1117_1384;
	       }
	       arg1703_1349 = res1846_1388;
	    }
	    {
	       obj_t aux_3249;
	       object_t aux_3247;
	       aux_3249 = (obj_t) (arg1703_1349);
	       aux_3247 = (object_t) (new1123_1347);
	       OBJECT_WIDENING_SET(aux_3247, aux_3249);
	    }
	 }
	 return new1123_1347;
      }
   }
}


/* _make-cptr1916 */ obj_t 
_make_cptr1916_221_foreign_ctype(obj_t env_1978, obj_t id_1979, obj_t name_1980, obj_t size_1981, obj_t class_1982, obj_t coerce_to_204_1983, obj_t parents_1984, obj_t init__47_1985, obj_t magic__53_1986, obj_t __57_1987, obj_t alias_1988, obj_t pointed_to_by_76_1989, obj_t tvector_1990, obj_t btype_1991, obj_t point_to_164_1992, obj_t array__248_1993)
{
   {
      cptr_t aux_3252;
      aux_3252 = make_cptr_169_foreign_ctype(id_1979, name_1980, size_1981, class_1982, coerce_to_204_1983, parents_1984, CBOOL(init__47_1985), CBOOL(magic__53_1986), __57_1987, alias_1988, pointed_to_by_76_1989, tvector_1990, (type_t) (btype_1991), (type_t) (point_to_164_1992), CBOOL(array__248_1993));
      return (obj_t) (aux_3252);
   }
}


/* cptr-id */ obj_t 
cptr_id_104_foreign_ctype(type_t obj_164)
{
   return (((type_t) CREF(obj_164))->id);
}


/* _cptr-id1917 */ obj_t 
_cptr_id1917_233_foreign_ctype(obj_t env_1994, obj_t obj_1995)
{
   return cptr_id_104_foreign_ctype((type_t) (obj_1995));
}


/* cptr-name-set! */ obj_t 
cptr_name_set__65_foreign_ctype(type_t obj_165, obj_t val1124_166)
{
   return ((((type_t) CREF(obj_165))->name) = ((obj_t) val1124_166), BUNSPEC);
}


/* _cptr-name-set!1918 */ obj_t 
_cptr_name_set_1918_55_foreign_ctype(obj_t env_1996, obj_t obj_1997, obj_t val1124_1998)
{
   return cptr_name_set__65_foreign_ctype((type_t) (obj_1997), val1124_1998);
}


/* cptr-name */ obj_t 
cptr_name_23_foreign_ctype(type_t obj_167)
{
   return (((type_t) CREF(obj_167))->name);
}


/* _cptr-name1919 */ obj_t 
_cptr_name1919_43_foreign_ctype(obj_t env_1999, obj_t obj_2000)
{
   return cptr_name_23_foreign_ctype((type_t) (obj_2000));
}


/* cptr-size-set! */ obj_t 
cptr_size_set__35_foreign_ctype(type_t obj_168, obj_t val1125_169)
{
   return ((((type_t) CREF(obj_168))->size) = ((obj_t) val1125_169), BUNSPEC);
}


/* _cptr-size-set!1920 */ obj_t 
_cptr_size_set_1920_144_foreign_ctype(obj_t env_2001, obj_t obj_2002, obj_t val1125_2003)
{
   return cptr_size_set__35_foreign_ctype((type_t) (obj_2002), val1125_2003);
}


/* cptr-size */ obj_t 
cptr_size_68_foreign_ctype(type_t obj_170)
{
   return (((type_t) CREF(obj_170))->size);
}


/* _cptr-size1921 */ obj_t 
_cptr_size1921_214_foreign_ctype(obj_t env_2004, obj_t obj_2005)
{
   return cptr_size_68_foreign_ctype((type_t) (obj_2005));
}


/* cptr-class-set! */ obj_t 
cptr_class_set__116_foreign_ctype(type_t obj_171, obj_t val1126_172)
{
   return ((((type_t) CREF(obj_171))->class) = ((obj_t) val1126_172), BUNSPEC);
}


/* _cptr-class-set!1922 */ obj_t 
_cptr_class_set_1922_122_foreign_ctype(obj_t env_2006, obj_t obj_2007, obj_t val1126_2008)
{
   return cptr_class_set__116_foreign_ctype((type_t) (obj_2007), val1126_2008);
}


/* cptr-class */ obj_t 
cptr_class_208_foreign_ctype(type_t obj_173)
{
   return (((type_t) CREF(obj_173))->class);
}


/* _cptr-class1923 */ obj_t 
_cptr_class1923_142_foreign_ctype(obj_t env_2009, obj_t obj_2010)
{
   return cptr_class_208_foreign_ctype((type_t) (obj_2010));
}


/* cptr-coerce-to-set! */ obj_t 
cptr_coerce_to_set__10_foreign_ctype(type_t obj_174, obj_t val1127_175)
{
   return ((((type_t) CREF(obj_174))->coerce_to_204) = ((obj_t) val1127_175), BUNSPEC);
}


/* _cptr-coerce-to-set!1924 */ obj_t 
_cptr_coerce_to_set_1924_106_foreign_ctype(obj_t env_2011, obj_t obj_2012, obj_t val1127_2013)
{
   return cptr_coerce_to_set__10_foreign_ctype((type_t) (obj_2012), val1127_2013);
}


/* cptr-coerce-to */ obj_t 
cptr_coerce_to_35_foreign_ctype(type_t obj_176)
{
   return (((type_t) CREF(obj_176))->coerce_to_204);
}


/* _cptr-coerce-to1925 */ obj_t 
_cptr_coerce_to1925_103_foreign_ctype(obj_t env_2014, obj_t obj_2015)
{
   return cptr_coerce_to_35_foreign_ctype((type_t) (obj_2015));
}


/* cptr-parents-set! */ obj_t 
cptr_parents_set__163_foreign_ctype(type_t obj_177, obj_t val1128_178)
{
   return ((((type_t) CREF(obj_177))->parents) = ((obj_t) val1128_178), BUNSPEC);
}


/* _cptr-parents-set!1926 */ obj_t 
_cptr_parents_set_1926_4_foreign_ctype(obj_t env_2016, obj_t obj_2017, obj_t val1128_2018)
{
   return cptr_parents_set__163_foreign_ctype((type_t) (obj_2017), val1128_2018);
}


/* cptr-parents */ obj_t 
cptr_parents_193_foreign_ctype(type_t obj_179)
{
   return (((type_t) CREF(obj_179))->parents);
}


/* _cptr-parents1927 */ obj_t 
_cptr_parents1927_64_foreign_ctype(obj_t env_2019, obj_t obj_2020)
{
   return cptr_parents_193_foreign_ctype((type_t) (obj_2020));
}


/* cptr-init?-set! */ obj_t 
cptr_init__set__182_foreign_ctype(type_t obj_180, bool_t val1129_181)
{
   return ((((type_t) CREF(obj_180))->init__47) = ((bool_t) val1129_181), BUNSPEC);
}


/* _cptr-init?-set!1928 */ obj_t 
_cptr_init__set_1928_69_foreign_ctype(obj_t env_2021, obj_t obj_2022, obj_t val1129_2023)
{
   return cptr_init__set__182_foreign_ctype((type_t) (obj_2022), CBOOL(val1129_2023));
}


/* cptr-init? */ bool_t 
cptr_init__109_foreign_ctype(type_t obj_182)
{
   return (((type_t) CREF(obj_182))->init__47);
}


/* _cptr-init?1929 */ obj_t 
_cptr_init_1929_151_foreign_ctype(obj_t env_2024, obj_t obj_2025)
{
   {
      bool_t aux_3298;
      aux_3298 = cptr_init__109_foreign_ctype((type_t) (obj_2025));
      return BBOOL(aux_3298);
   }
}


/* cptr-magic?-set! */ obj_t 
cptr_magic__set__186_foreign_ctype(type_t obj_183, bool_t val1130_184)
{
   return ((((type_t) CREF(obj_183))->magic__53) = ((bool_t) val1130_184), BUNSPEC);
}


/* _cptr-magic?-set!1930 */ obj_t 
_cptr_magic__set_1930_218_foreign_ctype(obj_t env_2026, obj_t obj_2027, obj_t val1130_2028)
{
   return cptr_magic__set__186_foreign_ctype((type_t) (obj_2027), CBOOL(val1130_2028));
}


/* cptr-magic? */ bool_t 
cptr_magic__160_foreign_ctype(type_t obj_185)
{
   return (((type_t) CREF(obj_185))->magic__53);
}


/* _cptr-magic?1931 */ obj_t 
_cptr_magic_1931_25_foreign_ctype(obj_t env_2029, obj_t obj_2030)
{
   {
      bool_t aux_3307;
      aux_3307 = cptr_magic__160_foreign_ctype((type_t) (obj_2030));
      return BBOOL(aux_3307);
   }
}


/* cptr-$-set! */ obj_t 
cptr___set__200_foreign_ctype(type_t obj_186, obj_t val1131_187)
{
   return ((((type_t) CREF(obj_186))->__57) = ((obj_t) val1131_187), BUNSPEC);
}


/* _cptr-$-set!1932 */ obj_t 
_cptr___set_1932_61_foreign_ctype(obj_t env_2031, obj_t obj_2032, obj_t val1131_2033)
{
   return cptr___set__200_foreign_ctype((type_t) (obj_2032), val1131_2033);
}


/* cptr-$ */ obj_t 
cptr___8_foreign_ctype(type_t obj_188)
{
   return (((type_t) CREF(obj_188))->__57);
}


/* _cptr-$1933 */ obj_t 
_cptr__1933_82_foreign_ctype(obj_t env_2034, obj_t obj_2035)
{
   return cptr___8_foreign_ctype((type_t) (obj_2035));
}


/* cptr-alias-set! */ obj_t 
cptr_alias_set__91_foreign_ctype(type_t obj_189, obj_t val1132_190)
{
   return ((((type_t) CREF(obj_189))->alias) = ((obj_t) val1132_190), BUNSPEC);
}


/* _cptr-alias-set!1934 */ obj_t 
_cptr_alias_set_1934_211_foreign_ctype(obj_t env_2036, obj_t obj_2037, obj_t val1132_2038)
{
   return cptr_alias_set__91_foreign_ctype((type_t) (obj_2037), val1132_2038);
}


/* cptr-alias */ obj_t 
cptr_alias_0_foreign_ctype(type_t obj_191)
{
   return (((type_t) CREF(obj_191))->alias);
}


/* _cptr-alias1935 */ obj_t 
_cptr_alias1935_162_foreign_ctype(obj_t env_2039, obj_t obj_2040)
{
   return cptr_alias_0_foreign_ctype((type_t) (obj_2040));
}


/* cptr-pointed-to-by-set! */ obj_t 
cptr_pointed_to_by_set__176_foreign_ctype(type_t obj_192, obj_t val1133_193)
{
   return ((((type_t) CREF(obj_192))->pointed_to_by_76) = ((obj_t) val1133_193), BUNSPEC);
}


/* _cptr-pointed-to-by-set!1936 */ obj_t 
_cptr_pointed_to_by_set_1936_151_foreign_ctype(obj_t env_2041, obj_t obj_2042, obj_t val1133_2043)
{
   return cptr_pointed_to_by_set__176_foreign_ctype((type_t) (obj_2042), val1133_2043);
}


/* cptr-pointed-to-by */ obj_t 
cptr_pointed_to_by_194_foreign_ctype(type_t obj_194)
{
   return (((type_t) CREF(obj_194))->pointed_to_by_76);
}


/* _cptr-pointed-to-by1937 */ obj_t 
_cptr_pointed_to_by1937_55_foreign_ctype(obj_t env_2044, obj_t obj_2045)
{
   return cptr_pointed_to_by_194_foreign_ctype((type_t) (obj_2045));
}


/* cptr-tvector-set! */ obj_t 
cptr_tvector_set__194_foreign_ctype(type_t obj_195, obj_t val1134_196)
{
   return ((((type_t) CREF(obj_195))->tvector) = ((obj_t) val1134_196), BUNSPEC);
}


/* _cptr-tvector-set!1938 */ obj_t 
_cptr_tvector_set_1938_234_foreign_ctype(obj_t env_2046, obj_t obj_2047, obj_t val1134_2048)
{
   return cptr_tvector_set__194_foreign_ctype((type_t) (obj_2047), val1134_2048);
}


/* cptr-tvector */ obj_t 
cptr_tvector_165_foreign_ctype(type_t obj_197)
{
   return (((type_t) CREF(obj_197))->tvector);
}


/* _cptr-tvector1939 */ obj_t 
_cptr_tvector1939_203_foreign_ctype(obj_t env_2049, obj_t obj_2050)
{
   return cptr_tvector_165_foreign_ctype((type_t) (obj_2050));
}


/* cptr-btype */ type_t 
cptr_btype_116_foreign_ctype(cptr_t obj_198)
{
   {
      obj_t aux_3335;
      {
	 object_t aux_3336;
	 aux_3336 = (object_t) (obj_198);
	 aux_3335 = OBJECT_WIDENING(aux_3336);
      }
      return (((cptr_t) CREF(aux_3335))->btype);
   }
}


/* _cptr-btype1940 */ obj_t 
_cptr_btype1940_10_foreign_ctype(obj_t env_2051, obj_t obj_2052)
{
   {
      type_t aux_3340;
      aux_3340 = cptr_btype_116_foreign_ctype((cptr_t) (obj_2052));
      return (obj_t) (aux_3340);
   }
}


/* cptr-point-to */ type_t 
cptr_point_to_238_foreign_ctype(cptr_t obj_199)
{
   {
      obj_t aux_3344;
      {
	 object_t aux_3345;
	 aux_3345 = (object_t) (obj_199);
	 aux_3344 = OBJECT_WIDENING(aux_3345);
      }
      return (((cptr_t) CREF(aux_3344))->point_to_164);
   }
}


/* _cptr-point-to1941 */ obj_t 
_cptr_point_to1941_63_foreign_ctype(obj_t env_2053, obj_t obj_2054)
{
   {
      type_t aux_3349;
      aux_3349 = cptr_point_to_238_foreign_ctype((cptr_t) (obj_2054));
      return (obj_t) (aux_3349);
   }
}


/* cptr-array? */ bool_t 
cptr_array__44_foreign_ctype(cptr_t obj_200)
{
   {
      obj_t aux_3353;
      {
	 object_t aux_3354;
	 aux_3354 = (object_t) (obj_200);
	 aux_3353 = OBJECT_WIDENING(aux_3354);
      }
      return (((cptr_t) CREF(aux_3353))->array__248);
   }
}


/* _cptr-array?1942 */ obj_t 
_cptr_array_1942_178_foreign_ctype(obj_t env_2055, obj_t obj_2056)
{
   {
      bool_t aux_3358;
      aux_3358 = cptr_array__44_foreign_ctype((cptr_t) (obj_2056));
      return BBOOL(aux_3358);
   }
}


/* allocate-cfunction */ type_t 
allocate_cfunction_24_foreign_ctype()
{
   {
      type_t new1110_878;
      new1110_878 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1704_879;
	 arg1704_879 = class_num_218___object(cfunction_foreign_ctype);
	 {
	    obj_t obj_1389;
	    obj_1389 = (obj_t) (new1110_878);
	    (((obj_t) CREF(obj_1389))->header = MAKE_HEADER(arg1704_879, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3366;
	 aux_3366 = (object_t) (new1110_878);
	 OBJECT_WIDENING_SET(aux_3366, BFALSE);
      }
      return new1110_878;
   }
}


/* _allocate-cfunction */ obj_t 
_allocate_cfunction_151_foreign_ctype(obj_t env_1799)
{
   {
      type_t aux_3369;
      aux_3369 = allocate_cfunction_24_foreign_ctype();
      return (obj_t) (aux_3369);
   }
}


/* cfunction? */ bool_t 
cfunction__229_foreign_ctype(obj_t obj_204)
{
   return is_a__118___object(obj_204, cfunction_foreign_ctype);
}


/* _cfunction? */ obj_t 
_cfunction__240_foreign_ctype(obj_t env_2057, obj_t obj_2058)
{
   {
      bool_t aux_3373;
      aux_3373 = cfunction__229_foreign_ctype(obj_2058);
      return BBOOL(aux_3373);
   }
}


/* widening1004-cfunction */ cfunction_t 
widening1004_cfunction_132_foreign_ctype(type_t btype_205, long arity_206, type_t type_res_48_207, obj_t type_args_244_208)
{
   {
      cfunction_t new1091_1391;
      new1091_1391 = ((cfunction_t) BREF(GC_MALLOC(sizeof(struct cfunction))));
      ((((cfunction_t) CREF(new1091_1391))->btype) = ((type_t) btype_205), BUNSPEC);
      ((((cfunction_t) CREF(new1091_1391))->arity) = ((long) arity_206), BUNSPEC);
      ((((cfunction_t) CREF(new1091_1391))->type_res_48) = ((type_t) type_res_48_207), BUNSPEC);
      ((((cfunction_t) CREF(new1091_1391))->type_args_244) = ((obj_t) type_args_244_208), BUNSPEC);
      return new1091_1391;
   }
}


/* _widening1004-cfunction1943 */ obj_t 
_widening1004_cfunction1943_26_foreign_ctype(obj_t env_2059, obj_t btype_2060, obj_t arity_2061, obj_t type_res_48_2062, obj_t type_args_244_2063)
{
   {
      cfunction_t aux_3381;
      aux_3381 = widening1004_cfunction_132_foreign_ctype((type_t) (btype_2060), (long) CINT(arity_2061), (type_t) (type_res_48_2062), type_args_244_2063);
      return (obj_t) (aux_3381);
   }
}


/* make-cfunction */ cfunction_t 
make_cfunction_198_foreign_ctype(obj_t id_209, obj_t name_210, obj_t size_211, obj_t class_212, obj_t coerce_to_204_213, obj_t parents_214, bool_t init__47_215, bool_t magic__53_216, obj_t __57_217, obj_t alias_218, obj_t pointed_to_by_76_219, obj_t tvector_220, type_t btype_221, long arity_222, type_t type_res_48_223, obj_t type_args_244_224)
{
   {
      type_t aux1097_1396;
      {
	 type_t res1847_1428;
	 {
	    type_t new1008_1412;
	    new1008_1412 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
	    {
	       long arg1717_1413;
	       arg1717_1413 = class_num_218___object(type_type_type);
	       {
		  obj_t obj_1426;
		  obj_1426 = (obj_t) (new1008_1412);
		  (((obj_t) CREF(obj_1426))->header = MAKE_HEADER(arg1717_1413, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3391;
	       aux_3391 = (object_t) (new1008_1412);
	       OBJECT_WIDENING_SET(aux_3391, BFALSE);
	    }
	    ((((type_t) CREF(new1008_1412))->id) = ((obj_t) id_209), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->name) = ((obj_t) name_210), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->size) = ((obj_t) size_211), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->class) = ((obj_t) class_212), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->coerce_to_204) = ((obj_t) coerce_to_204_213), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->parents) = ((obj_t) parents_214), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->init__47) = ((bool_t) init__47_215), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->magic__53) = ((bool_t) magic__53_216), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->__57) = ((obj_t) __57_217), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->alias) = ((obj_t) alias_218), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_219), BUNSPEC);
	    ((((type_t) CREF(new1008_1412))->tvector) = ((obj_t) tvector_220), BUNSPEC);
	    res1847_1428 = new1008_1412;
	 }
	 aux1097_1396 = res1847_1428;
      }
      {
	 cfunction_t new1098_1397;
	 new1098_1397 = ((cfunction_t) (aux1097_1396));
	 {
	    long arg1705_1398;
	    arg1705_1398 = class_num_218___object(cfunction_foreign_ctype);
	    {
	       obj_t obj_1429;
	       obj_1429 = (obj_t) (new1098_1397);
	       (((obj_t) CREF(obj_1429))->header = MAKE_HEADER(arg1705_1398, 0), BUNSPEC);
	    }
	 }
	 {
	    cfunction_t arg1706_1399;
	    {
	       cfunction_t res1848_1440;
	       {
		  cfunction_t new1091_1435;
		  new1091_1435 = ((cfunction_t) BREF(GC_MALLOC(sizeof(struct cfunction))));
		  ((((cfunction_t) CREF(new1091_1435))->btype) = ((type_t) btype_221), BUNSPEC);
		  ((((cfunction_t) CREF(new1091_1435))->arity) = ((long) arity_222), BUNSPEC);
		  ((((cfunction_t) CREF(new1091_1435))->type_res_48) = ((type_t) type_res_48_223), BUNSPEC);
		  ((((cfunction_t) CREF(new1091_1435))->type_args_244) = ((obj_t) type_args_244_224), BUNSPEC);
		  res1848_1440 = new1091_1435;
	       }
	       arg1706_1399 = res1848_1440;
	    }
	    {
	       obj_t aux_3417;
	       object_t aux_3415;
	       aux_3417 = (obj_t) (arg1706_1399);
	       aux_3415 = (object_t) (new1098_1397);
	       OBJECT_WIDENING_SET(aux_3415, aux_3417);
	    }
	 }
	 return new1098_1397;
      }
   }
}


/* _make-cfunction1944 */ obj_t 
_make_cfunction1944_30_foreign_ctype(obj_t env_2064, obj_t id_2065, obj_t name_2066, obj_t size_2067, obj_t class_2068, obj_t coerce_to_204_2069, obj_t parents_2070, obj_t init__47_2071, obj_t magic__53_2072, obj_t __57_2073, obj_t alias_2074, obj_t pointed_to_by_76_2075, obj_t tvector_2076, obj_t btype_2077, obj_t arity_2078, obj_t type_res_48_2079, obj_t type_args_244_2080)
{
   {
      cfunction_t aux_3420;
      aux_3420 = make_cfunction_198_foreign_ctype(id_2065, name_2066, size_2067, class_2068, coerce_to_204_2069, parents_2070, CBOOL(init__47_2071), CBOOL(magic__53_2072), __57_2073, alias_2074, pointed_to_by_76_2075, tvector_2076, (type_t) (btype_2077), (long) CINT(arity_2078), (type_t) (type_res_48_2079), type_args_244_2080);
      return (obj_t) (aux_3420);
   }
}


/* cfunction-id */ obj_t 
cfunction_id_42_foreign_ctype(type_t obj_225)
{
   return (((type_t) CREF(obj_225))->id);
}


/* _cfunction-id1945 */ obj_t 
_cfunction_id1945_146_foreign_ctype(obj_t env_2081, obj_t obj_2082)
{
   return cfunction_id_42_foreign_ctype((type_t) (obj_2082));
}


/* cfunction-name-set! */ obj_t 
cfunction_name_set__134_foreign_ctype(type_t obj_226, obj_t val1099_227)
{
   return ((((type_t) CREF(obj_226))->name) = ((obj_t) val1099_227), BUNSPEC);
}


/* _cfunction-name-set!1946 */ obj_t 
_cfunction_name_set_1946_158_foreign_ctype(obj_t env_2083, obj_t obj_2084, obj_t val1099_2085)
{
   return cfunction_name_set__134_foreign_ctype((type_t) (obj_2084), val1099_2085);
}


/* cfunction-name */ obj_t 
cfunction_name_21_foreign_ctype(type_t obj_228)
{
   return (((type_t) CREF(obj_228))->name);
}


/* _cfunction-name1947 */ obj_t 
_cfunction_name1947_221_foreign_ctype(obj_t env_2086, obj_t obj_2087)
{
   return cfunction_name_21_foreign_ctype((type_t) (obj_2087));
}


/* cfunction-size-set! */ obj_t 
cfunction_size_set__97_foreign_ctype(type_t obj_229, obj_t val1100_230)
{
   return ((((type_t) CREF(obj_229))->size) = ((obj_t) val1100_230), BUNSPEC);
}


/* _cfunction-size-set!1948 */ obj_t 
_cfunction_size_set_1948_79_foreign_ctype(obj_t env_2088, obj_t obj_2089, obj_t val1100_2090)
{
   return cfunction_size_set__97_foreign_ctype((type_t) (obj_2089), val1100_2090);
}


/* cfunction-size */ obj_t 
cfunction_size_85_foreign_ctype(type_t obj_231)
{
   return (((type_t) CREF(obj_231))->size);
}


/* _cfunction-size1949 */ obj_t 
_cfunction_size1949_201_foreign_ctype(obj_t env_2091, obj_t obj_2092)
{
   return cfunction_size_85_foreign_ctype((type_t) (obj_2092));
}


/* cfunction-class-set! */ obj_t 
cfunction_class_set__229_foreign_ctype(type_t obj_232, obj_t val1101_233)
{
   return ((((type_t) CREF(obj_232))->class) = ((obj_t) val1101_233), BUNSPEC);
}


/* _cfunction-class-set!1950 */ obj_t 
_cfunction_class_set_1950_25_foreign_ctype(obj_t env_2093, obj_t obj_2094, obj_t val1101_2095)
{
   return cfunction_class_set__229_foreign_ctype((type_t) (obj_2094), val1101_2095);
}


/* cfunction-class */ obj_t 
cfunction_class_142_foreign_ctype(type_t obj_234)
{
   return (((type_t) CREF(obj_234))->class);
}


/* _cfunction-class1951 */ obj_t 
_cfunction_class1951_36_foreign_ctype(obj_t env_2096, obj_t obj_2097)
{
   return cfunction_class_142_foreign_ctype((type_t) (obj_2097));
}


/* cfunction-coerce-to-set! */ obj_t 
cfunction_coerce_to_set__196_foreign_ctype(type_t obj_235, obj_t val1102_236)
{
   return ((((type_t) CREF(obj_235))->coerce_to_204) = ((obj_t) val1102_236), BUNSPEC);
}


/* _cfunction-coerce-to-set!1952 */ obj_t 
_cfunction_coerce_to_set_1952_186_foreign_ctype(obj_t env_2098, obj_t obj_2099, obj_t val1102_2100)
{
   return cfunction_coerce_to_set__196_foreign_ctype((type_t) (obj_2099), val1102_2100);
}


/* cfunction-coerce-to */ obj_t 
cfunction_coerce_to_79_foreign_ctype(type_t obj_237)
{
   return (((type_t) CREF(obj_237))->coerce_to_204);
}


/* _cfunction-coerce-to1953 */ obj_t 
_cfunction_coerce_to1953_176_foreign_ctype(obj_t env_2101, obj_t obj_2102)
{
   return cfunction_coerce_to_79_foreign_ctype((type_t) (obj_2102));
}


/* cfunction-parents-set! */ obj_t 
cfunction_parents_set__120_foreign_ctype(type_t obj_238, obj_t val1103_239)
{
   return ((((type_t) CREF(obj_238))->parents) = ((obj_t) val1103_239), BUNSPEC);
}


/* _cfunction-parents-set!1954 */ obj_t 
_cfunction_parents_set_1954_155_foreign_ctype(obj_t env_2103, obj_t obj_2104, obj_t val1103_2105)
{
   return cfunction_parents_set__120_foreign_ctype((type_t) (obj_2104), val1103_2105);
}


/* cfunction-parents */ obj_t 
cfunction_parents_200_foreign_ctype(type_t obj_240)
{
   return (((type_t) CREF(obj_240))->parents);
}


/* _cfunction-parents1955 */ obj_t 
_cfunction_parents1955_40_foreign_ctype(obj_t env_2106, obj_t obj_2107)
{
   return cfunction_parents_200_foreign_ctype((type_t) (obj_2107));
}


/* cfunction-init?-set! */ obj_t 
cfunction_init__set__153_foreign_ctype(type_t obj_241, bool_t val1104_242)
{
   return ((((type_t) CREF(obj_241))->init__47) = ((bool_t) val1104_242), BUNSPEC);
}


/* _cfunction-init?-set!1956 */ obj_t 
_cfunction_init__set_1956_150_foreign_ctype(obj_t env_2108, obj_t obj_2109, obj_t val1104_2110)
{
   return cfunction_init__set__153_foreign_ctype((type_t) (obj_2109), CBOOL(val1104_2110));
}


/* cfunction-init? */ bool_t 
cfunction_init__78_foreign_ctype(type_t obj_243)
{
   return (((type_t) CREF(obj_243))->init__47);
}


/* _cfunction-init?1957 */ obj_t 
_cfunction_init_1957_114_foreign_ctype(obj_t env_2111, obj_t obj_2112)
{
   {
      bool_t aux_3466;
      aux_3466 = cfunction_init__78_foreign_ctype((type_t) (obj_2112));
      return BBOOL(aux_3466);
   }
}


/* cfunction-magic?-set! */ obj_t 
cfunction_magic__set__231_foreign_ctype(type_t obj_244, bool_t val1105_245)
{
   return ((((type_t) CREF(obj_244))->magic__53) = ((bool_t) val1105_245), BUNSPEC);
}


/* _cfunction-magic?-set!1958 */ obj_t 
_cfunction_magic__set_1958_27_foreign_ctype(obj_t env_2113, obj_t obj_2114, obj_t val1105_2115)
{
   return cfunction_magic__set__231_foreign_ctype((type_t) (obj_2114), CBOOL(val1105_2115));
}


/* cfunction-magic? */ bool_t 
cfunction_magic__129_foreign_ctype(type_t obj_246)
{
   return (((type_t) CREF(obj_246))->magic__53);
}


/* _cfunction-magic?1959 */ obj_t 
_cfunction_magic_1959_239_foreign_ctype(obj_t env_2116, obj_t obj_2117)
{
   {
      bool_t aux_3475;
      aux_3475 = cfunction_magic__129_foreign_ctype((type_t) (obj_2117));
      return BBOOL(aux_3475);
   }
}


/* cfunction-$-set! */ obj_t 
cfunction___set__14_foreign_ctype(type_t obj_247, obj_t val1106_248)
{
   return ((((type_t) CREF(obj_247))->__57) = ((obj_t) val1106_248), BUNSPEC);
}


/* _cfunction-$-set!1960 */ obj_t 
_cfunction___set_1960_53_foreign_ctype(obj_t env_2118, obj_t obj_2119, obj_t val1106_2120)
{
   return cfunction___set__14_foreign_ctype((type_t) (obj_2119), val1106_2120);
}


/* cfunction-$ */ obj_t 
cfunction___70_foreign_ctype(type_t obj_249)
{
   return (((type_t) CREF(obj_249))->__57);
}


/* _cfunction-$1961 */ obj_t 
_cfunction__1961_93_foreign_ctype(obj_t env_2121, obj_t obj_2122)
{
   return cfunction___70_foreign_ctype((type_t) (obj_2122));
}


/* cfunction-alias-set! */ obj_t 
cfunction_alias_set__135_foreign_ctype(type_t obj_250, obj_t val1107_251)
{
   return ((((type_t) CREF(obj_250))->alias) = ((obj_t) val1107_251), BUNSPEC);
}


/* _cfunction-alias-set!1962 */ obj_t 
_cfunction_alias_set_1962_74_foreign_ctype(obj_t env_2123, obj_t obj_2124, obj_t val1107_2125)
{
   return cfunction_alias_set__135_foreign_ctype((type_t) (obj_2124), val1107_2125);
}


/* cfunction-alias */ obj_t 
cfunction_alias_134_foreign_ctype(type_t obj_252)
{
   return (((type_t) CREF(obj_252))->alias);
}


/* _cfunction-alias1963 */ obj_t 
_cfunction_alias1963_244_foreign_ctype(obj_t env_2126, obj_t obj_2127)
{
   return cfunction_alias_134_foreign_ctype((type_t) (obj_2127));
}


/* cfunction-pointed-to-by-set! */ obj_t 
cfunction_pointed_to_by_set__108_foreign_ctype(type_t obj_253, obj_t val1108_254)
{
   return ((((type_t) CREF(obj_253))->pointed_to_by_76) = ((obj_t) val1108_254), BUNSPEC);
}


/* _cfunction-pointed-to-by-set!1964 */ obj_t 
_cfunction_pointed_to_by_set_1964_24_foreign_ctype(obj_t env_2128, obj_t obj_2129, obj_t val1108_2130)
{
   return cfunction_pointed_to_by_set__108_foreign_ctype((type_t) (obj_2129), val1108_2130);
}


/* cfunction-pointed-to-by */ obj_t 
cfunction_pointed_to_by_151_foreign_ctype(type_t obj_255)
{
   return (((type_t) CREF(obj_255))->pointed_to_by_76);
}


/* _cfunction-pointed-to-by1965 */ obj_t 
_cfunction_pointed_to_by1965_21_foreign_ctype(obj_t env_2131, obj_t obj_2132)
{
   return cfunction_pointed_to_by_151_foreign_ctype((type_t) (obj_2132));
}


/* cfunction-tvector-set! */ obj_t 
cfunction_tvector_set__184_foreign_ctype(type_t obj_256, obj_t val1109_257)
{
   return ((((type_t) CREF(obj_256))->tvector) = ((obj_t) val1109_257), BUNSPEC);
}


/* _cfunction-tvector-set!1966 */ obj_t 
_cfunction_tvector_set_1966_191_foreign_ctype(obj_t env_2133, obj_t obj_2134, obj_t val1109_2135)
{
   return cfunction_tvector_set__184_foreign_ctype((type_t) (obj_2134), val1109_2135);
}


/* cfunction-tvector */ obj_t 
cfunction_tvector_181_foreign_ctype(type_t obj_258)
{
   return (((type_t) CREF(obj_258))->tvector);
}


/* _cfunction-tvector1967 */ obj_t 
_cfunction_tvector1967_127_foreign_ctype(obj_t env_2136, obj_t obj_2137)
{
   return cfunction_tvector_181_foreign_ctype((type_t) (obj_2137));
}


/* cfunction-btype */ type_t 
cfunction_btype_24_foreign_ctype(cfunction_t obj_259)
{
   {
      obj_t aux_3503;
      {
	 object_t aux_3504;
	 aux_3504 = (object_t) (obj_259);
	 aux_3503 = OBJECT_WIDENING(aux_3504);
      }
      return (((cfunction_t) CREF(aux_3503))->btype);
   }
}


/* _cfunction-btype1968 */ obj_t 
_cfunction_btype1968_86_foreign_ctype(obj_t env_2138, obj_t obj_2139)
{
   {
      type_t aux_3508;
      aux_3508 = cfunction_btype_24_foreign_ctype((cfunction_t) (obj_2139));
      return (obj_t) (aux_3508);
   }
}


/* cfunction-arity */ long 
cfunction_arity_21_foreign_ctype(cfunction_t obj_260)
{
   {
      obj_t aux_3512;
      {
	 object_t aux_3513;
	 aux_3513 = (object_t) (obj_260);
	 aux_3512 = OBJECT_WIDENING(aux_3513);
      }
      return (((cfunction_t) CREF(aux_3512))->arity);
   }
}


/* _cfunction-arity1969 */ obj_t 
_cfunction_arity1969_95_foreign_ctype(obj_t env_2140, obj_t obj_2141)
{
   {
      long aux_3517;
      aux_3517 = cfunction_arity_21_foreign_ctype((cfunction_t) (obj_2141));
      return BINT(aux_3517);
   }
}


/* cfunction-type-res */ type_t 
cfunction_type_res_120_foreign_ctype(cfunction_t obj_261)
{
   {
      obj_t aux_3521;
      {
	 object_t aux_3522;
	 aux_3522 = (object_t) (obj_261);
	 aux_3521 = OBJECT_WIDENING(aux_3522);
      }
      return (((cfunction_t) CREF(aux_3521))->type_res_48);
   }
}


/* _cfunction-type-res1970 */ obj_t 
_cfunction_type_res1970_141_foreign_ctype(obj_t env_2142, obj_t obj_2143)
{
   {
      type_t aux_3526;
      aux_3526 = cfunction_type_res_120_foreign_ctype((cfunction_t) (obj_2143));
      return (obj_t) (aux_3526);
   }
}


/* cfunction-type-args */ obj_t 
cfunction_type_args_85_foreign_ctype(cfunction_t obj_262)
{
   {
      obj_t aux_3530;
      {
	 object_t aux_3531;
	 aux_3531 = (object_t) (obj_262);
	 aux_3530 = OBJECT_WIDENING(aux_3531);
      }
      return (((cfunction_t) CREF(aux_3530))->type_args_244);
   }
}


/* _cfunction-type-args1971 */ obj_t 
_cfunction_type_args1971_56_foreign_ctype(obj_t env_2144, obj_t obj_2145)
{
   return cfunction_type_args_85_foreign_ctype((cfunction_t) (obj_2145));
}


/* allocate-cenum */ type_t 
allocate_cenum_165_foreign_ctype()
{
   {
      type_t new1084_889;
      new1084_889 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1707_890;
	 arg1707_890 = class_num_218___object(cenum_foreign_ctype);
	 {
	    obj_t obj_1441;
	    obj_1441 = (obj_t) (new1084_889);
	    (((obj_t) CREF(obj_1441))->header = MAKE_HEADER(arg1707_890, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3541;
	 aux_3541 = (object_t) (new1084_889);
	 OBJECT_WIDENING_SET(aux_3541, BFALSE);
      }
      return new1084_889;
   }
}


/* _allocate-cenum */ obj_t 
_allocate_cenum_156_foreign_ctype(obj_t env_1798)
{
   {
      type_t aux_3544;
      aux_3544 = allocate_cenum_165_foreign_ctype();
      return (obj_t) (aux_3544);
   }
}


/* cenum? */ bool_t 
cenum__97_foreign_ctype(obj_t obj_266)
{
   return is_a__118___object(obj_266, cenum_foreign_ctype);
}


/* _cenum? */ obj_t 
_cenum__111_foreign_ctype(obj_t env_2146, obj_t obj_2147)
{
   {
      bool_t aux_3548;
      aux_3548 = cenum__97_foreign_ctype(obj_2147);
      return BBOOL(aux_3548);
   }
}


/* widening1003-cenum */ cenum_t 
widening1003_cenum_43_foreign_ctype(type_t btype_267, obj_t literals_268)
{
   {
      cenum_t new1067_1443;
      new1067_1443 = ((cenum_t) BREF(GC_MALLOC(sizeof(struct cenum))));
      ((((cenum_t) CREF(new1067_1443))->btype) = ((type_t) btype_267), BUNSPEC);
      ((((cenum_t) CREF(new1067_1443))->literals) = ((obj_t) literals_268), BUNSPEC);
      return new1067_1443;
   }
}


/* _widening1003-cenum1972 */ obj_t 
_widening1003_cenum1972_19_foreign_ctype(obj_t env_2148, obj_t btype_2149, obj_t literals_2150)
{
   {
      cenum_t aux_3554;
      aux_3554 = widening1003_cenum_43_foreign_ctype((type_t) (btype_2149), literals_2150);
      return (obj_t) (aux_3554);
   }
}


/* make-cenum */ cenum_t 
make_cenum_38_foreign_ctype(obj_t id_269, obj_t name_270, obj_t size_271, obj_t class_272, obj_t coerce_to_204_273, obj_t parents_274, bool_t init__47_275, bool_t magic__53_276, obj_t __57_277, obj_t alias_278, obj_t pointed_to_by_76_279, obj_t tvector_280, type_t btype_281, obj_t literals_282)
{
   {
      type_t aux1071_1446;
      {
	 type_t res1849_1478;
	 {
	    type_t new1008_1462;
	    new1008_1462 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
	    {
	       long arg1717_1463;
	       arg1717_1463 = class_num_218___object(type_type_type);
	       {
		  obj_t obj_1476;
		  obj_1476 = (obj_t) (new1008_1462);
		  (((obj_t) CREF(obj_1476))->header = MAKE_HEADER(arg1717_1463, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3562;
	       aux_3562 = (object_t) (new1008_1462);
	       OBJECT_WIDENING_SET(aux_3562, BFALSE);
	    }
	    ((((type_t) CREF(new1008_1462))->id) = ((obj_t) id_269), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->name) = ((obj_t) name_270), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->size) = ((obj_t) size_271), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->class) = ((obj_t) class_272), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->coerce_to_204) = ((obj_t) coerce_to_204_273), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->parents) = ((obj_t) parents_274), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->init__47) = ((bool_t) init__47_275), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->magic__53) = ((bool_t) magic__53_276), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->__57) = ((obj_t) __57_277), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->alias) = ((obj_t) alias_278), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_279), BUNSPEC);
	    ((((type_t) CREF(new1008_1462))->tvector) = ((obj_t) tvector_280), BUNSPEC);
	    res1849_1478 = new1008_1462;
	 }
	 aux1071_1446 = res1849_1478;
      }
      {
	 cenum_t new1072_1447;
	 new1072_1447 = ((cenum_t) (aux1071_1446));
	 {
	    long arg1708_1448;
	    arg1708_1448 = class_num_218___object(cenum_foreign_ctype);
	    {
	       obj_t obj_1479;
	       obj_1479 = (obj_t) (new1072_1447);
	       (((obj_t) CREF(obj_1479))->header = MAKE_HEADER(arg1708_1448, 0), BUNSPEC);
	    }
	 }
	 {
	    cenum_t arg1709_1449;
	    {
	       cenum_t res1850_1486;
	       {
		  cenum_t new1067_1483;
		  new1067_1483 = ((cenum_t) BREF(GC_MALLOC(sizeof(struct cenum))));
		  ((((cenum_t) CREF(new1067_1483))->btype) = ((type_t) btype_281), BUNSPEC);
		  ((((cenum_t) CREF(new1067_1483))->literals) = ((obj_t) literals_282), BUNSPEC);
		  res1850_1486 = new1067_1483;
	       }
	       arg1709_1449 = res1850_1486;
	    }
	    {
	       obj_t aux_3586;
	       object_t aux_3584;
	       aux_3586 = (obj_t) (arg1709_1449);
	       aux_3584 = (object_t) (new1072_1447);
	       OBJECT_WIDENING_SET(aux_3584, aux_3586);
	    }
	 }
	 return new1072_1447;
      }
   }
}


/* _make-cenum1973 */ obj_t 
_make_cenum1973_207_foreign_ctype(obj_t env_2151, obj_t id_2152, obj_t name_2153, obj_t size_2154, obj_t class_2155, obj_t coerce_to_204_2156, obj_t parents_2157, obj_t init__47_2158, obj_t magic__53_2159, obj_t __57_2160, obj_t alias_2161, obj_t pointed_to_by_76_2162, obj_t tvector_2163, obj_t btype_2164, obj_t literals_2165)
{
   {
      cenum_t aux_3589;
      aux_3589 = make_cenum_38_foreign_ctype(id_2152, name_2153, size_2154, class_2155, coerce_to_204_2156, parents_2157, CBOOL(init__47_2158), CBOOL(magic__53_2159), __57_2160, alias_2161, pointed_to_by_76_2162, tvector_2163, (type_t) (btype_2164), literals_2165);
      return (obj_t) (aux_3589);
   }
}


/* cenum-id */ obj_t 
cenum_id_181_foreign_ctype(type_t obj_283)
{
   return (((type_t) CREF(obj_283))->id);
}


/* _cenum-id1974 */ obj_t 
_cenum_id1974_44_foreign_ctype(obj_t env_2166, obj_t obj_2167)
{
   return cenum_id_181_foreign_ctype((type_t) (obj_2167));
}


/* cenum-name-set! */ obj_t 
cenum_name_set__100_foreign_ctype(type_t obj_284, obj_t val1073_285)
{
   return ((((type_t) CREF(obj_284))->name) = ((obj_t) val1073_285), BUNSPEC);
}


/* _cenum-name-set!1975 */ obj_t 
_cenum_name_set_1975_178_foreign_ctype(obj_t env_2168, obj_t obj_2169, obj_t val1073_2170)
{
   return cenum_name_set__100_foreign_ctype((type_t) (obj_2169), val1073_2170);
}


/* cenum-name */ obj_t 
cenum_name_176_foreign_ctype(type_t obj_286)
{
   return (((type_t) CREF(obj_286))->name);
}


/* _cenum-name1976 */ obj_t 
_cenum_name1976_20_foreign_ctype(obj_t env_2171, obj_t obj_2172)
{
   return cenum_name_176_foreign_ctype((type_t) (obj_2172));
}


/* cenum-size-set! */ obj_t 
cenum_size_set__27_foreign_ctype(type_t obj_287, obj_t val1074_288)
{
   return ((((type_t) CREF(obj_287))->size) = ((obj_t) val1074_288), BUNSPEC);
}


/* _cenum-size-set!1977 */ obj_t 
_cenum_size_set_1977_49_foreign_ctype(obj_t env_2173, obj_t obj_2174, obj_t val1074_2175)
{
   return cenum_size_set__27_foreign_ctype((type_t) (obj_2174), val1074_2175);
}


/* cenum-size */ obj_t 
cenum_size_56_foreign_ctype(type_t obj_289)
{
   return (((type_t) CREF(obj_289))->size);
}


/* _cenum-size1978 */ obj_t 
_cenum_size1978_23_foreign_ctype(obj_t env_2176, obj_t obj_2177)
{
   return cenum_size_56_foreign_ctype((type_t) (obj_2177));
}


/* cenum-class-set! */ obj_t 
cenum_class_set__128_foreign_ctype(type_t obj_290, obj_t val1075_291)
{
   return ((((type_t) CREF(obj_290))->class) = ((obj_t) val1075_291), BUNSPEC);
}


/* _cenum-class-set!1979 */ obj_t 
_cenum_class_set_1979_23_foreign_ctype(obj_t env_2178, obj_t obj_2179, obj_t val1075_2180)
{
   return cenum_class_set__128_foreign_ctype((type_t) (obj_2179), val1075_2180);
}


/* cenum-class */ obj_t 
cenum_class_5_foreign_ctype(type_t obj_292)
{
   return (((type_t) CREF(obj_292))->class);
}


/* _cenum-class1980 */ obj_t 
_cenum_class1980_229_foreign_ctype(obj_t env_2181, obj_t obj_2182)
{
   return cenum_class_5_foreign_ctype((type_t) (obj_2182));
}


/* cenum-coerce-to-set! */ obj_t 
cenum_coerce_to_set__113_foreign_ctype(type_t obj_293, obj_t val1076_294)
{
   return ((((type_t) CREF(obj_293))->coerce_to_204) = ((obj_t) val1076_294), BUNSPEC);
}


/* _cenum-coerce-to-set!1981 */ obj_t 
_cenum_coerce_to_set_1981_153_foreign_ctype(obj_t env_2183, obj_t obj_2184, obj_t val1076_2185)
{
   return cenum_coerce_to_set__113_foreign_ctype((type_t) (obj_2184), val1076_2185);
}


/* cenum-coerce-to */ obj_t 
cenum_coerce_to_61_foreign_ctype(type_t obj_295)
{
   return (((type_t) CREF(obj_295))->coerce_to_204);
}


/* _cenum-coerce-to1982 */ obj_t 
_cenum_coerce_to1982_244_foreign_ctype(obj_t env_2186, obj_t obj_2187)
{
   return cenum_coerce_to_61_foreign_ctype((type_t) (obj_2187));
}


/* cenum-parents-set! */ obj_t 
cenum_parents_set__114_foreign_ctype(type_t obj_296, obj_t val1077_297)
{
   return ((((type_t) CREF(obj_296))->parents) = ((obj_t) val1077_297), BUNSPEC);
}


/* _cenum-parents-set!1983 */ obj_t 
_cenum_parents_set_1983_79_foreign_ctype(obj_t env_2188, obj_t obj_2189, obj_t val1077_2190)
{
   return cenum_parents_set__114_foreign_ctype((type_t) (obj_2189), val1077_2190);
}


/* cenum-parents */ obj_t 
cenum_parents_29_foreign_ctype(type_t obj_298)
{
   return (((type_t) CREF(obj_298))->parents);
}


/* _cenum-parents1984 */ obj_t 
_cenum_parents1984_202_foreign_ctype(obj_t env_2191, obj_t obj_2192)
{
   return cenum_parents_29_foreign_ctype((type_t) (obj_2192));
}


/* cenum-init?-set! */ obj_t 
cenum_init__set__60_foreign_ctype(type_t obj_299, bool_t val1078_300)
{
   return ((((type_t) CREF(obj_299))->init__47) = ((bool_t) val1078_300), BUNSPEC);
}


/* _cenum-init?-set!1985 */ obj_t 
_cenum_init__set_1985_245_foreign_ctype(obj_t env_2193, obj_t obj_2194, obj_t val1078_2195)
{
   return cenum_init__set__60_foreign_ctype((type_t) (obj_2194), CBOOL(val1078_2195));
}


/* cenum-init? */ bool_t 
cenum_init__104_foreign_ctype(type_t obj_301)
{
   return (((type_t) CREF(obj_301))->init__47);
}


/* _cenum-init?1986 */ obj_t 
_cenum_init_1986_19_foreign_ctype(obj_t env_2196, obj_t obj_2197)
{
   {
      bool_t aux_3633;
      aux_3633 = cenum_init__104_foreign_ctype((type_t) (obj_2197));
      return BBOOL(aux_3633);
   }
}


/* cenum-magic?-set! */ obj_t 
cenum_magic__set__46_foreign_ctype(type_t obj_302, bool_t val1079_303)
{
   return ((((type_t) CREF(obj_302))->magic__53) = ((bool_t) val1079_303), BUNSPEC);
}


/* _cenum-magic?-set!1987 */ obj_t 
_cenum_magic__set_1987_48_foreign_ctype(obj_t env_2198, obj_t obj_2199, obj_t val1079_2200)
{
   return cenum_magic__set__46_foreign_ctype((type_t) (obj_2199), CBOOL(val1079_2200));
}


/* cenum-magic? */ bool_t 
cenum_magic__102_foreign_ctype(type_t obj_304)
{
   return (((type_t) CREF(obj_304))->magic__53);
}


/* _cenum-magic?1988 */ obj_t 
_cenum_magic_1988_186_foreign_ctype(obj_t env_2201, obj_t obj_2202)
{
   {
      bool_t aux_3642;
      aux_3642 = cenum_magic__102_foreign_ctype((type_t) (obj_2202));
      return BBOOL(aux_3642);
   }
}


/* cenum-$-set! */ obj_t 
cenum___set__140_foreign_ctype(type_t obj_305, obj_t val1080_306)
{
   return ((((type_t) CREF(obj_305))->__57) = ((obj_t) val1080_306), BUNSPEC);
}


/* _cenum-$-set!1989 */ obj_t 
_cenum___set_1989_21_foreign_ctype(obj_t env_2203, obj_t obj_2204, obj_t val1080_2205)
{
   return cenum___set__140_foreign_ctype((type_t) (obj_2204), val1080_2205);
}


/* cenum-$ */ obj_t 
cenum___188_foreign_ctype(type_t obj_307)
{
   return (((type_t) CREF(obj_307))->__57);
}


/* _cenum-$1990 */ obj_t 
_cenum__1990_116_foreign_ctype(obj_t env_2206, obj_t obj_2207)
{
   return cenum___188_foreign_ctype((type_t) (obj_2207));
}


/* cenum-alias-set! */ obj_t 
cenum_alias_set__5_foreign_ctype(type_t obj_308, obj_t val1081_309)
{
   return ((((type_t) CREF(obj_308))->alias) = ((obj_t) val1081_309), BUNSPEC);
}


/* _cenum-alias-set!1991 */ obj_t 
_cenum_alias_set_1991_164_foreign_ctype(obj_t env_2208, obj_t obj_2209, obj_t val1081_2210)
{
   return cenum_alias_set__5_foreign_ctype((type_t) (obj_2209), val1081_2210);
}


/* cenum-alias */ obj_t 
cenum_alias_245_foreign_ctype(type_t obj_310)
{
   return (((type_t) CREF(obj_310))->alias);
}


/* _cenum-alias1992 */ obj_t 
_cenum_alias1992_58_foreign_ctype(obj_t env_2211, obj_t obj_2212)
{
   return cenum_alias_245_foreign_ctype((type_t) (obj_2212));
}


/* cenum-pointed-to-by-set! */ obj_t 
cenum_pointed_to_by_set__34_foreign_ctype(type_t obj_311, obj_t val1082_312)
{
   return ((((type_t) CREF(obj_311))->pointed_to_by_76) = ((obj_t) val1082_312), BUNSPEC);
}


/* _cenum-pointed-to-by-set!1993 */ obj_t 
_cenum_pointed_to_by_set_1993_135_foreign_ctype(obj_t env_2213, obj_t obj_2214, obj_t val1082_2215)
{
   return cenum_pointed_to_by_set__34_foreign_ctype((type_t) (obj_2214), val1082_2215);
}


/* cenum-pointed-to-by */ obj_t 
cenum_pointed_to_by_86_foreign_ctype(type_t obj_313)
{
   return (((type_t) CREF(obj_313))->pointed_to_by_76);
}


/* _cenum-pointed-to-by1994 */ obj_t 
_cenum_pointed_to_by1994_118_foreign_ctype(obj_t env_2216, obj_t obj_2217)
{
   return cenum_pointed_to_by_86_foreign_ctype((type_t) (obj_2217));
}


/* cenum-tvector-set! */ obj_t 
cenum_tvector_set__58_foreign_ctype(type_t obj_314, obj_t val1083_315)
{
   return ((((type_t) CREF(obj_314))->tvector) = ((obj_t) val1083_315), BUNSPEC);
}


/* _cenum-tvector-set!1995 */ obj_t 
_cenum_tvector_set_1995_73_foreign_ctype(obj_t env_2218, obj_t obj_2219, obj_t val1083_2220)
{
   return cenum_tvector_set__58_foreign_ctype((type_t) (obj_2219), val1083_2220);
}


/* cenum-tvector */ obj_t 
cenum_tvector_92_foreign_ctype(type_t obj_316)
{
   return (((type_t) CREF(obj_316))->tvector);
}


/* _cenum-tvector1996 */ obj_t 
_cenum_tvector1996_178_foreign_ctype(obj_t env_2221, obj_t obj_2222)
{
   return cenum_tvector_92_foreign_ctype((type_t) (obj_2222));
}


/* cenum-btype */ type_t 
cenum_btype_86_foreign_ctype(cenum_t obj_317)
{
   {
      obj_t aux_3670;
      {
	 object_t aux_3671;
	 aux_3671 = (object_t) (obj_317);
	 aux_3670 = OBJECT_WIDENING(aux_3671);
      }
      return (((cenum_t) CREF(aux_3670))->btype);
   }
}


/* _cenum-btype1997 */ obj_t 
_cenum_btype1997_132_foreign_ctype(obj_t env_2223, obj_t obj_2224)
{
   {
      type_t aux_3675;
      aux_3675 = cenum_btype_86_foreign_ctype((cenum_t) (obj_2224));
      return (obj_t) (aux_3675);
   }
}


/* cenum-literals */ obj_t 
cenum_literals_124_foreign_ctype(cenum_t obj_318)
{
   {
      obj_t aux_3679;
      {
	 object_t aux_3680;
	 aux_3680 = (object_t) (obj_318);
	 aux_3679 = OBJECT_WIDENING(aux_3680);
      }
      return (((cenum_t) CREF(aux_3679))->literals);
   }
}


/* _cenum-literals1998 */ obj_t 
_cenum_literals1998_64_foreign_ctype(obj_t env_2225, obj_t obj_2226)
{
   return cenum_literals_124_foreign_ctype((cenum_t) (obj_2226));
}


/* allocate-calias */ type_t 
allocate_calias_11_foreign_ctype()
{
   {
      type_t new1059_898;
      new1059_898 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1710_899;
	 arg1710_899 = class_num_218___object(calias_foreign_ctype);
	 {
	    obj_t obj_1487;
	    obj_1487 = (obj_t) (new1059_898);
	    (((obj_t) CREF(obj_1487))->header = MAKE_HEADER(arg1710_899, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3690;
	 aux_3690 = (object_t) (new1059_898);
	 OBJECT_WIDENING_SET(aux_3690, BFALSE);
      }
      return new1059_898;
   }
}


/* _allocate-calias */ obj_t 
_allocate_calias_121_foreign_ctype(obj_t env_1797)
{
   {
      type_t aux_3693;
      aux_3693 = allocate_calias_11_foreign_ctype();
      return (obj_t) (aux_3693);
   }
}


/* calias? */ bool_t 
calias__152_foreign_ctype(obj_t obj_322)
{
   return is_a__118___object(obj_322, calias_foreign_ctype);
}


/* _calias? */ obj_t 
_calias__112_foreign_ctype(obj_t env_2227, obj_t obj_2228)
{
   {
      bool_t aux_3697;
      aux_3697 = calias__152_foreign_ctype(obj_2228);
      return BBOOL(aux_3697);
   }
}


/* widening1002-calias */ calias_t 
widening1002_calias_172_foreign_ctype(bool_t array__248_323)
{
   {
      calias_t new1042_1489;
      new1042_1489 = ((calias_t) BREF(GC_MALLOC(sizeof(struct calias))));
      ((((calias_t) CREF(new1042_1489))->array__248) = ((bool_t) array__248_323), BUNSPEC);
      return new1042_1489;
   }
}


/* _widening1002-calias */ obj_t 
_widening1002_calias_170_foreign_ctype(obj_t env_2229, obj_t array__248_2230)
{
   {
      calias_t aux_3702;
      aux_3702 = widening1002_calias_172_foreign_ctype(CBOOL(array__248_2230));
      return (obj_t) (aux_3702);
   }
}


/* make-calias */ calias_t 
make_calias_75_foreign_ctype(obj_t id_324, obj_t name_325, obj_t size_326, obj_t class_327, obj_t coerce_to_204_328, obj_t parents_329, bool_t init__47_330, bool_t magic__53_331, obj_t __57_332, obj_t alias_333, obj_t pointed_to_by_76_334, obj_t tvector_335, bool_t array__248_336)
{
   {
      type_t aux1045_1491;
      {
	 type_t res1851_1523;
	 {
	    type_t new1008_1507;
	    new1008_1507 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
	    {
	       long arg1717_1508;
	       arg1717_1508 = class_num_218___object(type_type_type);
	       {
		  obj_t obj_1521;
		  obj_1521 = (obj_t) (new1008_1507);
		  (((obj_t) CREF(obj_1521))->header = MAKE_HEADER(arg1717_1508, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3710;
	       aux_3710 = (object_t) (new1008_1507);
	       OBJECT_WIDENING_SET(aux_3710, BFALSE);
	    }
	    ((((type_t) CREF(new1008_1507))->id) = ((obj_t) id_324), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->name) = ((obj_t) name_325), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->size) = ((obj_t) size_326), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->class) = ((obj_t) class_327), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->coerce_to_204) = ((obj_t) coerce_to_204_328), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->parents) = ((obj_t) parents_329), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->init__47) = ((bool_t) init__47_330), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->magic__53) = ((bool_t) magic__53_331), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->__57) = ((obj_t) __57_332), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->alias) = ((obj_t) alias_333), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_334), BUNSPEC);
	    ((((type_t) CREF(new1008_1507))->tvector) = ((obj_t) tvector_335), BUNSPEC);
	    res1851_1523 = new1008_1507;
	 }
	 aux1045_1491 = res1851_1523;
      }
      {
	 calias_t new1046_1492;
	 new1046_1492 = ((calias_t) (aux1045_1491));
	 {
	    long arg1711_1493;
	    arg1711_1493 = class_num_218___object(calias_foreign_ctype);
	    {
	       obj_t obj_1524;
	       obj_1524 = (obj_t) (new1046_1492);
	       (((obj_t) CREF(obj_1524))->header = MAKE_HEADER(arg1711_1493, 0), BUNSPEC);
	    }
	 }
	 {
	    calias_t arg1712_1494;
	    {
	       calias_t res1852_1529;
	       {
		  calias_t new1042_1527;
		  new1042_1527 = ((calias_t) BREF(GC_MALLOC(sizeof(struct calias))));
		  ((((calias_t) CREF(new1042_1527))->array__248) = ((bool_t) array__248_336), BUNSPEC);
		  res1852_1529 = new1042_1527;
	       }
	       arg1712_1494 = res1852_1529;
	    }
	    {
	       obj_t aux_3733;
	       object_t aux_3731;
	       aux_3733 = (obj_t) (arg1712_1494);
	       aux_3731 = (object_t) (new1046_1492);
	       OBJECT_WIDENING_SET(aux_3731, aux_3733);
	    }
	 }
	 return new1046_1492;
      }
   }
}


/* _make-calias1999 */ obj_t 
_make_calias1999_199_foreign_ctype(obj_t env_2231, obj_t id_2232, obj_t name_2233, obj_t size_2234, obj_t class_2235, obj_t coerce_to_204_2236, obj_t parents_2237, obj_t init__47_2238, obj_t magic__53_2239, obj_t __57_2240, obj_t alias_2241, obj_t pointed_to_by_76_2242, obj_t tvector_2243, obj_t array__248_2244)
{
   {
      calias_t aux_3736;
      aux_3736 = make_calias_75_foreign_ctype(id_2232, name_2233, size_2234, class_2235, coerce_to_204_2236, parents_2237, CBOOL(init__47_2238), CBOOL(magic__53_2239), __57_2240, alias_2241, pointed_to_by_76_2242, tvector_2243, CBOOL(array__248_2244));
      return (obj_t) (aux_3736);
   }
}


/* calias-id */ obj_t 
calias_id_19_foreign_ctype(type_t obj_337)
{
   return (((type_t) CREF(obj_337))->id);
}


/* _calias-id2000 */ obj_t 
_calias_id2000_202_foreign_ctype(obj_t env_2245, obj_t obj_2246)
{
   return calias_id_19_foreign_ctype((type_t) (obj_2246));
}


/* calias-name-set! */ obj_t 
calias_name_set__248_foreign_ctype(type_t obj_338, obj_t val1047_339)
{
   return ((((type_t) CREF(obj_338))->name) = ((obj_t) val1047_339), BUNSPEC);
}


/* _calias-name-set!2001 */ obj_t 
_calias_name_set_2001_205_foreign_ctype(obj_t env_2247, obj_t obj_2248, obj_t val1047_2249)
{
   return calias_name_set__248_foreign_ctype((type_t) (obj_2248), val1047_2249);
}


/* calias-name */ obj_t 
calias_name_11_foreign_ctype(type_t obj_340)
{
   return (((type_t) CREF(obj_340))->name);
}


/* _calias-name2002 */ obj_t 
_calias_name2002_238_foreign_ctype(obj_t env_2250, obj_t obj_2251)
{
   return calias_name_11_foreign_ctype((type_t) (obj_2251));
}


/* calias-size-set! */ obj_t 
calias_size_set__23_foreign_ctype(type_t obj_341, obj_t val1048_342)
{
   return ((((type_t) CREF(obj_341))->size) = ((obj_t) val1048_342), BUNSPEC);
}


/* _calias-size-set!2003 */ obj_t 
_calias_size_set_2003_67_foreign_ctype(obj_t env_2252, obj_t obj_2253, obj_t val1048_2254)
{
   return calias_size_set__23_foreign_ctype((type_t) (obj_2253), val1048_2254);
}


/* calias-size */ obj_t 
calias_size_17_foreign_ctype(type_t obj_343)
{
   return (((type_t) CREF(obj_343))->size);
}


/* _calias-size2004 */ obj_t 
_calias_size2004_229_foreign_ctype(obj_t env_2255, obj_t obj_2256)
{
   return calias_size_17_foreign_ctype((type_t) (obj_2256));
}


/* calias-class-set! */ obj_t 
calias_class_set__218_foreign_ctype(type_t obj_344, obj_t val1049_345)
{
   return ((((type_t) CREF(obj_344))->class) = ((obj_t) val1049_345), BUNSPEC);
}


/* _calias-class-set!2005 */ obj_t 
_calias_class_set_2005_119_foreign_ctype(obj_t env_2257, obj_t obj_2258, obj_t val1049_2259)
{
   return calias_class_set__218_foreign_ctype((type_t) (obj_2258), val1049_2259);
}


/* calias-class */ obj_t 
calias_class_74_foreign_ctype(type_t obj_346)
{
   return (((type_t) CREF(obj_346))->class);
}


/* _calias-class2006 */ obj_t 
_calias_class2006_123_foreign_ctype(obj_t env_2260, obj_t obj_2261)
{
   return calias_class_74_foreign_ctype((type_t) (obj_2261));
}


/* calias-coerce-to-set! */ obj_t 
calias_coerce_to_set__100_foreign_ctype(type_t obj_347, obj_t val1050_348)
{
   return ((((type_t) CREF(obj_347))->coerce_to_204) = ((obj_t) val1050_348), BUNSPEC);
}


/* _calias-coerce-to-set!2007 */ obj_t 
_calias_coerce_to_set_2007_153_foreign_ctype(obj_t env_2262, obj_t obj_2263, obj_t val1050_2264)
{
   return calias_coerce_to_set__100_foreign_ctype((type_t) (obj_2263), val1050_2264);
}


/* calias-coerce-to */ obj_t 
calias_coerce_to_176_foreign_ctype(type_t obj_349)
{
   return (((type_t) CREF(obj_349))->coerce_to_204);
}


/* _calias-coerce-to2008 */ obj_t 
_calias_coerce_to2008_173_foreign_ctype(obj_t env_2265, obj_t obj_2266)
{
   return calias_coerce_to_176_foreign_ctype((type_t) (obj_2266));
}


/* calias-parents-set! */ obj_t 
calias_parents_set__116_foreign_ctype(type_t obj_350, obj_t val1051_351)
{
   return ((((type_t) CREF(obj_350))->parents) = ((obj_t) val1051_351), BUNSPEC);
}


/* _calias-parents-set!2009 */ obj_t 
_calias_parents_set_2009_52_foreign_ctype(obj_t env_2267, obj_t obj_2268, obj_t val1051_2269)
{
   return calias_parents_set__116_foreign_ctype((type_t) (obj_2268), val1051_2269);
}


/* calias-parents */ obj_t 
calias_parents_208_foreign_ctype(type_t obj_352)
{
   return (((type_t) CREF(obj_352))->parents);
}


/* _calias-parents2010 */ obj_t 
_calias_parents2010_113_foreign_ctype(obj_t env_2270, obj_t obj_2271)
{
   return calias_parents_208_foreign_ctype((type_t) (obj_2271));
}


/* calias-init?-set! */ obj_t 
calias_init__set__16_foreign_ctype(type_t obj_353, bool_t val1052_354)
{
   return ((((type_t) CREF(obj_353))->init__47) = ((bool_t) val1052_354), BUNSPEC);
}


/* _calias-init?-set!2011 */ obj_t 
_calias_init__set_2011_201_foreign_ctype(obj_t env_2272, obj_t obj_2273, obj_t val1052_2274)
{
   return calias_init__set__16_foreign_ctype((type_t) (obj_2273), CBOOL(val1052_2274));
}


/* calias-init? */ bool_t 
calias_init__198_foreign_ctype(type_t obj_355)
{
   return (((type_t) CREF(obj_355))->init__47);
}


/* _calias-init?2012 */ obj_t 
_calias_init_2012_60_foreign_ctype(obj_t env_2275, obj_t obj_2276)
{
   {
      bool_t aux_3780;
      aux_3780 = calias_init__198_foreign_ctype((type_t) (obj_2276));
      return BBOOL(aux_3780);
   }
}


/* calias-magic?-set! */ obj_t 
calias_magic__set__219_foreign_ctype(type_t obj_356, bool_t val1053_357)
{
   return ((((type_t) CREF(obj_356))->magic__53) = ((bool_t) val1053_357), BUNSPEC);
}


/* _calias-magic?-set!2013 */ obj_t 
_calias_magic__set_2013_54_foreign_ctype(obj_t env_2277, obj_t obj_2278, obj_t val1053_2279)
{
   return calias_magic__set__219_foreign_ctype((type_t) (obj_2278), CBOOL(val1053_2279));
}


/* calias-magic? */ bool_t 
calias_magic__158_foreign_ctype(type_t obj_358)
{
   return (((type_t) CREF(obj_358))->magic__53);
}


/* _calias-magic?2014 */ obj_t 
_calias_magic_2014_60_foreign_ctype(obj_t env_2280, obj_t obj_2281)
{
   {
      bool_t aux_3789;
      aux_3789 = calias_magic__158_foreign_ctype((type_t) (obj_2281));
      return BBOOL(aux_3789);
   }
}


/* calias-$-set! */ obj_t 
calias___set__245_foreign_ctype(type_t obj_359, obj_t val1054_360)
{
   return ((((type_t) CREF(obj_359))->__57) = ((obj_t) val1054_360), BUNSPEC);
}


/* _calias-$-set!2015 */ obj_t 
_calias___set_2015_38_foreign_ctype(obj_t env_2282, obj_t obj_2283, obj_t val1054_2284)
{
   return calias___set__245_foreign_ctype((type_t) (obj_2283), val1054_2284);
}


/* calias-$ */ obj_t 
calias___14_foreign_ctype(type_t obj_361)
{
   return (((type_t) CREF(obj_361))->__57);
}


/* _calias-$2016 */ obj_t 
_calias__2016_88_foreign_ctype(obj_t env_2285, obj_t obj_2286)
{
   return calias___14_foreign_ctype((type_t) (obj_2286));
}


/* calias-alias-set! */ obj_t 
calias_alias_set__200_foreign_ctype(type_t obj_362, obj_t val1055_363)
{
   return ((((type_t) CREF(obj_362))->alias) = ((obj_t) val1055_363), BUNSPEC);
}


/* _calias-alias-set!2017 */ obj_t 
_calias_alias_set_2017_29_foreign_ctype(obj_t env_2287, obj_t obj_2288, obj_t val1055_2289)
{
   return calias_alias_set__200_foreign_ctype((type_t) (obj_2288), val1055_2289);
}


/* calias-alias */ obj_t 
calias_alias_8_foreign_ctype(type_t obj_364)
{
   return (((type_t) CREF(obj_364))->alias);
}


/* _calias-alias2018 */ obj_t 
_calias_alias2018_43_foreign_ctype(obj_t env_2290, obj_t obj_2291)
{
   return calias_alias_8_foreign_ctype((type_t) (obj_2291));
}


/* calias-pointed-to-by-set! */ obj_t 
calias_pointed_to_by_set__239_foreign_ctype(type_t obj_365, obj_t val1056_366)
{
   return ((((type_t) CREF(obj_365))->pointed_to_by_76) = ((obj_t) val1056_366), BUNSPEC);
}


/* _calias-pointed-to-by-set!2019 */ obj_t 
_calias_pointed_to_by_set_2019_43_foreign_ctype(obj_t env_2292, obj_t obj_2293, obj_t val1056_2294)
{
   return calias_pointed_to_by_set__239_foreign_ctype((type_t) (obj_2293), val1056_2294);
}


/* calias-pointed-to-by */ obj_t 
calias_pointed_to_by_168_foreign_ctype(type_t obj_367)
{
   return (((type_t) CREF(obj_367))->pointed_to_by_76);
}


/* _calias-pointed-to-by2020 */ obj_t 
_calias_pointed_to_by2020_19_foreign_ctype(obj_t env_2295, obj_t obj_2296)
{
   return calias_pointed_to_by_168_foreign_ctype((type_t) (obj_2296));
}


/* calias-tvector-set! */ obj_t 
calias_tvector_set__197_foreign_ctype(type_t obj_368, obj_t val1057_369)
{
   return ((((type_t) CREF(obj_368))->tvector) = ((obj_t) val1057_369), BUNSPEC);
}


/* _calias-tvector-set!2021 */ obj_t 
_calias_tvector_set_2021_223_foreign_ctype(obj_t env_2297, obj_t obj_2298, obj_t val1057_2299)
{
   return calias_tvector_set__197_foreign_ctype((type_t) (obj_2298), val1057_2299);
}


/* calias-tvector */ obj_t 
calias_tvector_113_foreign_ctype(type_t obj_370)
{
   return (((type_t) CREF(obj_370))->tvector);
}


/* _calias-tvector2022 */ obj_t 
_calias_tvector2022_106_foreign_ctype(obj_t env_2300, obj_t obj_2301)
{
   return calias_tvector_113_foreign_ctype((type_t) (obj_2301));
}


/* calias-array?-set! */ obj_t 
calias_array__set__238_foreign_ctype(calias_t obj_371, bool_t val1058_372)
{
   {
      obj_t aux_3817;
      {
	 object_t aux_3818;
	 aux_3818 = (object_t) (obj_371);
	 aux_3817 = OBJECT_WIDENING(aux_3818);
      }
      return ((((calias_t) CREF(aux_3817))->array__248) = ((bool_t) val1058_372), BUNSPEC);
   }
}


/* _calias-array?-set!2023 */ obj_t 
_calias_array__set_2023_137_foreign_ctype(obj_t env_2302, obj_t obj_2303, obj_t val1058_2304)
{
   return calias_array__set__238_foreign_ctype((calias_t) (obj_2303), CBOOL(val1058_2304));
}


/* calias-array? */ bool_t 
calias_array__53_foreign_ctype(calias_t obj_373)
{
   {
      obj_t aux_3825;
      {
	 object_t aux_3826;
	 aux_3826 = (object_t) (obj_373);
	 aux_3825 = OBJECT_WIDENING(aux_3826);
      }
      return (((calias_t) CREF(aux_3825))->array__248);
   }
}


/* _calias-array?2024 */ obj_t 
_calias_array_2024_78_foreign_ctype(obj_t env_2305, obj_t obj_2306)
{
   {
      bool_t aux_3830;
      aux_3830 = calias_array__53_foreign_ctype((calias_t) (obj_2306));
      return BBOOL(aux_3830);
   }
}


/* method-init */ obj_t 
method_init_76_foreign_ctype()
{
   {
      obj_t object__struct_cstruct__194_2323;
      object__struct_cstruct__194_2323 = proc2035_foreign_ctype;
      add_method__1___object(object__struct_env_210___object, cstruct__170_foreign_ctype, object__struct_cstruct__194_2323);
   }
   {
      obj_t struct_object__object_cstruct__130_2322;
      struct_object__object_cstruct__130_2322 = proc2036_foreign_ctype;
      add_method__1___object(struct_object__object_env_209___object, cstruct__170_foreign_ctype, struct_object__object_cstruct__130_2322);
   }
   {
      obj_t object__struct_cstruct_165_2321;
      object__struct_cstruct_165_2321 = proc2037_foreign_ctype;
      add_method__1___object(object__struct_env_210___object, cstruct_foreign_ctype, object__struct_cstruct_165_2321);
   }
   {
      obj_t struct_object__object_cstruct_172_2320;
      struct_object__object_cstruct_172_2320 = proc2038_foreign_ctype;
      add_method__1___object(struct_object__object_env_209___object, cstruct_foreign_ctype, struct_object__object_cstruct_172_2320);
   }
   {
      obj_t object__struct_cptr_2_2319;
      object__struct_cptr_2_2319 = proc2039_foreign_ctype;
      add_method__1___object(object__struct_env_210___object, cptr_foreign_ctype, object__struct_cptr_2_2319);
   }
   {
      obj_t struct_object__object_cptr_119_2318;
      struct_object__object_cptr_119_2318 = proc2040_foreign_ctype;
      add_method__1___object(struct_object__object_env_209___object, cptr_foreign_ctype, struct_object__object_cptr_119_2318);
   }
   {
      obj_t object__struct_cfunction_148_2317;
      object__struct_cfunction_148_2317 = proc2041_foreign_ctype;
      add_method__1___object(object__struct_env_210___object, cfunction_foreign_ctype, object__struct_cfunction_148_2317);
   }
   {
      obj_t struct_object__object_cfunction_210_2316;
      struct_object__object_cfunction_210_2316 = proc2042_foreign_ctype;
      add_method__1___object(struct_object__object_env_209___object, cfunction_foreign_ctype, struct_object__object_cfunction_210_2316);
   }
   {
      obj_t object__struct_cenum_54_2315;
      object__struct_cenum_54_2315 = proc2043_foreign_ctype;
      add_method__1___object(object__struct_env_210___object, cenum_foreign_ctype, object__struct_cenum_54_2315);
   }
   {
      obj_t struct_object__object_cenum_149_2314;
      struct_object__object_cenum_149_2314 = proc2044_foreign_ctype;
      add_method__1___object(struct_object__object_env_209___object, cenum_foreign_ctype, struct_object__object_cenum_149_2314);
   }
   {
      obj_t object__struct_calias_54_2311;
      object__struct_calias_54_2311 = proc2045_foreign_ctype;
      add_method__1___object(object__struct_env_210___object, calias_foreign_ctype, object__struct_calias_54_2311);
   }
   {
      obj_t struct_object__object_calias_28_2307;
      struct_object__object_calias_28_2307 = proc2046_foreign_ctype;
      return add_method__1___object(struct_object__object_env_209___object, calias_foreign_ctype, struct_object__object_calias_28_2307);
   }
}


/* struct+object->object-calias */ obj_t 
struct_object__object_calias_28_foreign_ctype(obj_t env_2324, obj_t o_2325, obj_t s_2326)
{
   {
      calias_t o_1096;
      obj_t s_1097;
      {
	 calias_t aux_3846;
	 o_1096 = (calias_t) (o_2325);
	 s_1097 = s_2326;
	 {
	    {
	       obj_t old1064_1100;
	       obj_t aux1065_1101;
	       {
		  obj_t next_method1226_0_1106;
		  next_method1226_0_1106 = find_super_class_method_167___object((object_t) (o_1096), struct_object__object_env_209___object, calias_foreign_ctype);
		  if (PROCEDUREP(next_method1226_0_1106))
		    {
		       old1064_1100 = PROCEDURE_ENTRY(next_method1226_0_1106) (next_method1226_0_1106, (obj_t) (o_1096), s_1097, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1226_0_1106);
		       {
			  object_t aux_3855;
			  aux_3855 = struct_object__object_93___object((object_t) (o_1096), s_1097);
			  old1064_1100 = (obj_t) (aux_3855);
		       }
		    }
	       }
	       aux1065_1101 = STRUCT_REF(s_1097, ((long) 0));
	       {
		  calias_t new1066_1102;
		  new1066_1102 = ((calias_t) (old1064_1100));
		  {
		     long arg1831_1103;
		     arg1831_1103 = class_num_218___object(calias_foreign_ctype);
		     {
			obj_t obj_1782;
			obj_1782 = (obj_t) (new1066_1102);
			(((obj_t) CREF(obj_1782))->header = MAKE_HEADER(arg1831_1103, 0), BUNSPEC);
		     }
		  }
		  {
		     calias_t arg1832_1104;
		     {
			calias_t res1858_1789;
			{
			   bool_t array__248_1786;
			   {
			      obj_t aux_3864;
			      aux_3864 = STRUCT_REF(aux1065_1101, ((long) 0));
			      array__248_1786 = CBOOL(aux_3864);
			   }
			   {
			      calias_t new1042_1787;
			      new1042_1787 = ((calias_t) BREF(GC_MALLOC(sizeof(struct calias))));
			      ((((calias_t) CREF(new1042_1787))->array__248) = ((bool_t) array__248_1786), BUNSPEC);
			      res1858_1789 = new1042_1787;
			   }
			}
			arg1832_1104 = res1858_1789;
		     }
		     {
			obj_t aux_3871;
			object_t aux_3869;
			aux_3871 = (obj_t) (arg1832_1104);
			aux_3869 = (object_t) (new1066_1102);
			OBJECT_WIDENING_SET(aux_3869, aux_3871);
		     }
		  }
		  aux_3846 = new1066_1102;
	       }
	    }
	 }
	 return (obj_t) (aux_3846);
      }
   }
}


/* object->struct-calias */ obj_t 
object__struct_calias_54_foreign_ctype(obj_t env_2327, obj_t obj1061_2328)
{
   {
      calias_t obj1061_1083;
      obj1061_1083 = (calias_t) (obj1061_2328);
      {
	 {
	    obj_t res1062_1086;
	    {
	       obj_t next_method1225_216_1094;
	       next_method1225_216_1094 = find_super_class_method_167___object((object_t) (obj1061_1083), object__struct_env_210___object, calias_foreign_ctype);
	       if (PROCEDUREP(next_method1225_216_1094))
		 {
		    res1062_1086 = PROCEDURE_ENTRY(next_method1225_216_1094) (next_method1225_216_1094, (obj_t) (obj1061_1083), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1225_216_1094);
		    res1062_1086 = object__struct_50___object((object_t) (obj1061_1083));
		 }
	    }
	    {
	       obj_t aux1063_1087;
	       {
		  obj_t aux_3886;
		  aux_3886 = CNST_TABLE_REF(((long) 22));
		  aux1063_1087 = make_struct(aux_3886, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_3889;
		  {
		     bool_t aux_3890;
		     {
			obj_t aux_3891;
			{
			   object_t aux_3892;
			   aux_3892 = (object_t) (obj1061_1083);
			   aux_3891 = OBJECT_WIDENING(aux_3892);
			}
			aux_3890 = (((calias_t) CREF(aux_3891))->array__248);
		     }
		     aux_3889 = BBOOL(aux_3890);
		  }
		  STRUCT_SET(aux1063_1087, ((long) 0), aux_3889);
	       }
	       STRUCT_SET(res1062_1086, ((long) 0), aux1063_1087);
	       {
		  obj_t aux_3899;
		  aux_3899 = STRUCT_KEY(res1062_1086);
		  STRUCT_KEY_SET(aux1063_1087, aux_3899);
	       }
	       {
		  obj_t aux_3902;
		  aux_3902 = CNST_TABLE_REF(((long) 22));
		  STRUCT_KEY_SET(res1062_1086, aux_3902);
	       }
	       return res1062_1086;
	    }
	 }
      }
   }
}


/* struct+object->object-cenum */ obj_t 
struct_object__object_cenum_149_foreign_ctype(obj_t env_2329, obj_t o_2330, obj_t s_2331)
{
   {
      cenum_t o_1070;
      obj_t s_1071;
      {
	 cenum_t aux_3906;
	 o_1070 = (cenum_t) (o_2330);
	 s_1071 = s_2331;
	 {
	    {
	       obj_t old1088_1074;
	       obj_t aux1089_1075;
	       {
		  obj_t next_method1224_52_1081;
		  next_method1224_52_1081 = find_super_class_method_167___object((object_t) (o_1070), struct_object__object_env_209___object, cenum_foreign_ctype);
		  if (PROCEDUREP(next_method1224_52_1081))
		    {
		       old1088_1074 = PROCEDURE_ENTRY(next_method1224_52_1081) (next_method1224_52_1081, (obj_t) (o_1070), s_1071, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1224_52_1081);
		       {
			  object_t aux_3915;
			  aux_3915 = struct_object__object_93___object((object_t) (o_1070), s_1071);
			  old1088_1074 = (obj_t) (aux_3915);
		       }
		    }
	       }
	       aux1089_1075 = STRUCT_REF(s_1071, ((long) 0));
	       {
		  cenum_t new1090_1076;
		  new1090_1076 = ((cenum_t) (old1088_1074));
		  {
		     long arg1816_1077;
		     arg1816_1077 = class_num_218___object(cenum_foreign_ctype);
		     {
			obj_t obj_1749;
			obj_1749 = (obj_t) (new1090_1076);
			(((obj_t) CREF(obj_1749))->header = MAKE_HEADER(arg1816_1077, 0), BUNSPEC);
		     }
		  }
		  {
		     cenum_t arg1817_1078;
		     {
			obj_t arg1820_1080;
			arg1820_1080 = STRUCT_REF(aux1089_1075, ((long) 1));
			{
			   cenum_t res1857_1760;
			   {
			      type_t btype_1755;
			      {
				 obj_t aux_3925;
				 aux_3925 = STRUCT_REF(aux1089_1075, ((long) 0));
				 btype_1755 = (type_t) (aux_3925);
			      }
			      {
				 cenum_t new1067_1757;
				 new1067_1757 = ((cenum_t) BREF(GC_MALLOC(sizeof(struct cenum))));
				 ((((cenum_t) CREF(new1067_1757))->btype) = ((type_t) btype_1755), BUNSPEC);
				 ((((cenum_t) CREF(new1067_1757))->literals) = ((obj_t) arg1820_1080), BUNSPEC);
				 res1857_1760 = new1067_1757;
			      }
			   }
			   arg1817_1078 = res1857_1760;
			}
		     }
		     {
			obj_t aux_3933;
			object_t aux_3931;
			aux_3933 = (obj_t) (arg1817_1078);
			aux_3931 = (object_t) (new1090_1076);
			OBJECT_WIDENING_SET(aux_3931, aux_3933);
		     }
		  }
		  aux_3906 = new1090_1076;
	       }
	    }
	 }
	 return (obj_t) (aux_3906);
      }
   }
}


/* object->struct-cenum */ obj_t 
object__struct_cenum_54_foreign_ctype(obj_t env_2332, obj_t obj1085_2333)
{
   {
      cenum_t obj1085_1055;
      obj1085_1055 = (cenum_t) (obj1085_2333);
      {
	 {
	    obj_t res1086_1058;
	    {
	       obj_t next_method1223_44_1068;
	       next_method1223_44_1068 = find_super_class_method_167___object((object_t) (obj1085_1055), object__struct_env_210___object, cenum_foreign_ctype);
	       if (PROCEDUREP(next_method1223_44_1068))
		 {
		    res1086_1058 = PROCEDURE_ENTRY(next_method1223_44_1068) (next_method1223_44_1068, (obj_t) (obj1085_1055), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1223_44_1068);
		    res1086_1058 = object__struct_50___object((object_t) (obj1085_1055));
		 }
	    }
	    {
	       obj_t aux1087_1059;
	       {
		  obj_t aux_3948;
		  aux_3948 = CNST_TABLE_REF(((long) 23));
		  aux1087_1059 = make_struct(aux_3948, ((long) 2), BUNSPEC);
	       }
	       {
		  obj_t aux_3951;
		  {
		     type_t aux_3952;
		     {
			obj_t aux_3953;
			{
			   object_t aux_3954;
			   aux_3954 = (object_t) (obj1085_1055);
			   aux_3953 = OBJECT_WIDENING(aux_3954);
			}
			aux_3952 = (((cenum_t) CREF(aux_3953))->btype);
		     }
		     aux_3951 = (obj_t) (aux_3952);
		  }
		  STRUCT_SET(aux1087_1059, ((long) 0), aux_3951);
	       }
	       {
		  obj_t aux_3960;
		  {
		     obj_t aux_3961;
		     {
			object_t aux_3962;
			aux_3962 = (object_t) (obj1085_1055);
			aux_3961 = OBJECT_WIDENING(aux_3962);
		     }
		     aux_3960 = (((cenum_t) CREF(aux_3961))->literals);
		  }
		  STRUCT_SET(aux1087_1059, ((long) 1), aux_3960);
	       }
	       STRUCT_SET(res1086_1058, ((long) 0), aux1087_1059);
	       {
		  obj_t aux_3968;
		  aux_3968 = STRUCT_KEY(res1086_1058);
		  STRUCT_KEY_SET(aux1087_1059, aux_3968);
	       }
	       {
		  obj_t aux_3971;
		  aux_3971 = CNST_TABLE_REF(((long) 23));
		  STRUCT_KEY_SET(res1086_1058, aux_3971);
	       }
	       return res1086_1058;
	    }
	 }
      }
   }
}


/* struct+object->object-cfunction */ obj_t 
struct_object__object_cfunction_210_foreign_ctype(obj_t env_2334, obj_t o_2335, obj_t s_2336)
{
   {
      cfunction_t o_1040;
      obj_t s_1041;
      {
	 cfunction_t aux_3975;
	 o_1040 = (cfunction_t) (o_2335);
	 s_1041 = s_2336;
	 {
	    {
	       obj_t old1114_1044;
	       obj_t aux1115_1045;
	       {
		  obj_t next_method1222_38_1053;
		  next_method1222_38_1053 = find_super_class_method_167___object((object_t) (o_1040), struct_object__object_env_209___object, cfunction_foreign_ctype);
		  if (PROCEDUREP(next_method1222_38_1053))
		    {
		       old1114_1044 = PROCEDURE_ENTRY(next_method1222_38_1053) (next_method1222_38_1053, (obj_t) (o_1040), s_1041, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1222_38_1053);
		       {
			  object_t aux_3984;
			  aux_3984 = struct_object__object_93___object((object_t) (o_1040), s_1041);
			  old1114_1044 = (obj_t) (aux_3984);
		       }
		    }
	       }
	       aux1115_1045 = STRUCT_REF(s_1041, ((long) 0));
	       {
		  cfunction_t new1116_1046;
		  new1116_1046 = ((cfunction_t) (old1114_1044));
		  {
		     long arg1799_1047;
		     arg1799_1047 = class_num_218___object(cfunction_foreign_ctype);
		     {
			obj_t obj_1704;
			obj_1704 = (obj_t) (new1116_1046);
			(((obj_t) CREF(obj_1704))->header = MAKE_HEADER(arg1799_1047, 0), BUNSPEC);
		     }
		  }
		  {
		     cfunction_t arg1800_1048;
		     {
			obj_t arg1805_1052;
			arg1805_1052 = STRUCT_REF(aux1115_1045, ((long) 3));
			{
			   cfunction_t res1856_1723;
			   {
			      type_t btype_1714;
			      long arity_1715;
			      type_t type_res_48_1716;
			      {
				 obj_t aux_3994;
				 aux_3994 = STRUCT_REF(aux1115_1045, ((long) 0));
				 btype_1714 = (type_t) (aux_3994);
			      }
			      {
				 obj_t aux_3997;
				 aux_3997 = STRUCT_REF(aux1115_1045, ((long) 1));
				 arity_1715 = (long) CINT(aux_3997);
			      }
			      {
				 obj_t aux_4000;
				 aux_4000 = STRUCT_REF(aux1115_1045, ((long) 2));
				 type_res_48_1716 = (type_t) (aux_4000);
			      }
			      {
				 cfunction_t new1091_1718;
				 new1091_1718 = ((cfunction_t) BREF(GC_MALLOC(sizeof(struct cfunction))));
				 ((((cfunction_t) CREF(new1091_1718))->btype) = ((type_t) btype_1714), BUNSPEC);
				 ((((cfunction_t) CREF(new1091_1718))->arity) = ((long) arity_1715), BUNSPEC);
				 ((((cfunction_t) CREF(new1091_1718))->type_res_48) = ((type_t) type_res_48_1716), BUNSPEC);
				 ((((cfunction_t) CREF(new1091_1718))->type_args_244) = ((obj_t) arg1805_1052), BUNSPEC);
				 res1856_1723 = new1091_1718;
			      }
			   }
			   arg1800_1048 = res1856_1723;
			}
		     }
		     {
			obj_t aux_4010;
			object_t aux_4008;
			aux_4010 = (obj_t) (arg1800_1048);
			aux_4008 = (object_t) (new1116_1046);
			OBJECT_WIDENING_SET(aux_4008, aux_4010);
		     }
		  }
		  aux_3975 = new1116_1046;
	       }
	    }
	 }
	 return (obj_t) (aux_3975);
      }
   }
}


/* object->struct-cfunction */ obj_t 
object__struct_cfunction_148_foreign_ctype(obj_t env_2337, obj_t obj1111_2338)
{
   {
      cfunction_t obj1111_1021;
      obj1111_1021 = (cfunction_t) (obj1111_2338);
      {
	 {
	    obj_t res1112_1024;
	    {
	       obj_t next_method1221_31_1038;
	       next_method1221_31_1038 = find_super_class_method_167___object((object_t) (obj1111_1021), object__struct_env_210___object, cfunction_foreign_ctype);
	       if (PROCEDUREP(next_method1221_31_1038))
		 {
		    res1112_1024 = PROCEDURE_ENTRY(next_method1221_31_1038) (next_method1221_31_1038, (obj_t) (obj1111_1021), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1221_31_1038);
		    res1112_1024 = object__struct_50___object((object_t) (obj1111_1021));
		 }
	    }
	    {
	       obj_t aux1113_1025;
	       {
		  obj_t aux_4025;
		  aux_4025 = CNST_TABLE_REF(((long) 24));
		  aux1113_1025 = make_struct(aux_4025, ((long) 4), BUNSPEC);
	       }
	       {
		  obj_t aux_4028;
		  {
		     type_t aux_4029;
		     {
			obj_t aux_4030;
			{
			   object_t aux_4031;
			   aux_4031 = (object_t) (obj1111_1021);
			   aux_4030 = OBJECT_WIDENING(aux_4031);
			}
			aux_4029 = (((cfunction_t) CREF(aux_4030))->btype);
		     }
		     aux_4028 = (obj_t) (aux_4029);
		  }
		  STRUCT_SET(aux1113_1025, ((long) 0), aux_4028);
	       }
	       {
		  obj_t aux_4037;
		  {
		     long aux_4038;
		     {
			obj_t aux_4039;
			{
			   object_t aux_4040;
			   aux_4040 = (object_t) (obj1111_1021);
			   aux_4039 = OBJECT_WIDENING(aux_4040);
			}
			aux_4038 = (((cfunction_t) CREF(aux_4039))->arity);
		     }
		     aux_4037 = BINT(aux_4038);
		  }
		  STRUCT_SET(aux1113_1025, ((long) 1), aux_4037);
	       }
	       {
		  obj_t aux_4046;
		  {
		     type_t aux_4047;
		     {
			obj_t aux_4048;
			{
			   object_t aux_4049;
			   aux_4049 = (object_t) (obj1111_1021);
			   aux_4048 = OBJECT_WIDENING(aux_4049);
			}
			aux_4047 = (((cfunction_t) CREF(aux_4048))->type_res_48);
		     }
		     aux_4046 = (obj_t) (aux_4047);
		  }
		  STRUCT_SET(aux1113_1025, ((long) 2), aux_4046);
	       }
	       {
		  obj_t aux_4055;
		  {
		     obj_t aux_4056;
		     {
			object_t aux_4057;
			aux_4057 = (object_t) (obj1111_1021);
			aux_4056 = OBJECT_WIDENING(aux_4057);
		     }
		     aux_4055 = (((cfunction_t) CREF(aux_4056))->type_args_244);
		  }
		  STRUCT_SET(aux1113_1025, ((long) 3), aux_4055);
	       }
	       STRUCT_SET(res1112_1024, ((long) 0), aux1113_1025);
	       {
		  obj_t aux_4063;
		  aux_4063 = STRUCT_KEY(res1112_1024);
		  STRUCT_KEY_SET(aux1113_1025, aux_4063);
	       }
	       {
		  obj_t aux_4066;
		  aux_4066 = CNST_TABLE_REF(((long) 24));
		  STRUCT_KEY_SET(res1112_1024, aux_4066);
	       }
	       return res1112_1024;
	    }
	 }
      }
   }
}


/* struct+object->object-cptr */ obj_t 
struct_object__object_cptr_119_foreign_ctype(obj_t env_2339, obj_t o_2340, obj_t s_2341)
{
   {
      cptr_t o_1007;
      obj_t s_1008;
      {
	 cptr_t aux_4070;
	 o_1007 = (cptr_t) (o_2340);
	 s_1008 = s_2341;
	 {
	    {
	       obj_t old1139_1011;
	       obj_t aux1140_1012;
	       {
		  obj_t next_method1220_149_1019;
		  next_method1220_149_1019 = find_super_class_method_167___object((object_t) (o_1007), struct_object__object_env_209___object, cptr_foreign_ctype);
		  if (PROCEDUREP(next_method1220_149_1019))
		    {
		       old1139_1011 = PROCEDURE_ENTRY(next_method1220_149_1019) (next_method1220_149_1019, (obj_t) (o_1007), s_1008, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1220_149_1019);
		       {
			  object_t aux_4079;
			  aux_4079 = struct_object__object_93___object((object_t) (o_1007), s_1008);
			  old1139_1011 = (obj_t) (aux_4079);
		       }
		    }
	       }
	       aux1140_1012 = STRUCT_REF(s_1008, ((long) 0));
	       {
		  cptr_t new1141_1013;
		  new1141_1013 = ((cptr_t) (old1139_1011));
		  {
		     long arg1776_1014;
		     arg1776_1014 = class_num_218___object(cptr_foreign_ctype);
		     {
			obj_t obj_1655;
			obj_1655 = (obj_t) (new1141_1013);
			(((obj_t) CREF(obj_1655))->header = MAKE_HEADER(arg1776_1014, 0), BUNSPEC);
		     }
		  }
		  {
		     cptr_t arg1777_1015;
		     {
			cptr_t res1855_1670;
			{
			   type_t btype_1663;
			   type_t point_to_164_1664;
			   bool_t array__248_1665;
			   {
			      obj_t aux_4088;
			      aux_4088 = STRUCT_REF(aux1140_1012, ((long) 0));
			      btype_1663 = (type_t) (aux_4088);
			   }
			   {
			      obj_t aux_4091;
			      aux_4091 = STRUCT_REF(aux1140_1012, ((long) 1));
			      point_to_164_1664 = (type_t) (aux_4091);
			   }
			   {
			      obj_t aux_4094;
			      aux_4094 = STRUCT_REF(aux1140_1012, ((long) 2));
			      array__248_1665 = CBOOL(aux_4094);
			   }
			   {
			      cptr_t new1117_1666;
			      new1117_1666 = ((cptr_t) BREF(GC_MALLOC(sizeof(struct cptr))));
			      ((((cptr_t) CREF(new1117_1666))->btype) = ((type_t) btype_1663), BUNSPEC);
			      ((((cptr_t) CREF(new1117_1666))->point_to_164) = ((type_t) point_to_164_1664), BUNSPEC);
			      ((((cptr_t) CREF(new1117_1666))->array__248) = ((bool_t) array__248_1665), BUNSPEC);
			      res1855_1670 = new1117_1666;
			   }
			}
			arg1777_1015 = res1855_1670;
		     }
		     {
			obj_t aux_4103;
			object_t aux_4101;
			aux_4103 = (obj_t) (arg1777_1015);
			aux_4101 = (object_t) (new1141_1013);
			OBJECT_WIDENING_SET(aux_4101, aux_4103);
		     }
		  }
		  aux_4070 = new1141_1013;
	       }
	    }
	 }
	 return (obj_t) (aux_4070);
      }
   }
}


/* object->struct-cptr */ obj_t 
object__struct_cptr_2_foreign_ctype(obj_t env_2342, obj_t obj1136_2343)
{
   {
      cptr_t obj1136_990;
      obj1136_990 = (cptr_t) (obj1136_2343);
      {
	 {
	    obj_t res1137_993;
	    {
	       obj_t next_method1207_63_1005;
	       next_method1207_63_1005 = find_super_class_method_167___object((object_t) (obj1136_990), object__struct_env_210___object, cptr_foreign_ctype);
	       if (PROCEDUREP(next_method1207_63_1005))
		 {
		    res1137_993 = PROCEDURE_ENTRY(next_method1207_63_1005) (next_method1207_63_1005, (obj_t) (obj1136_990), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1207_63_1005);
		    res1137_993 = object__struct_50___object((object_t) (obj1136_990));
		 }
	    }
	    {
	       obj_t aux1138_994;
	       {
		  obj_t aux_4118;
		  aux_4118 = CNST_TABLE_REF(((long) 25));
		  aux1138_994 = make_struct(aux_4118, ((long) 3), BUNSPEC);
	       }
	       {
		  obj_t aux_4121;
		  {
		     type_t aux_4122;
		     {
			obj_t aux_4123;
			{
			   object_t aux_4124;
			   aux_4124 = (object_t) (obj1136_990);
			   aux_4123 = OBJECT_WIDENING(aux_4124);
			}
			aux_4122 = (((cptr_t) CREF(aux_4123))->btype);
		     }
		     aux_4121 = (obj_t) (aux_4122);
		  }
		  STRUCT_SET(aux1138_994, ((long) 0), aux_4121);
	       }
	       {
		  obj_t aux_4130;
		  {
		     type_t aux_4131;
		     {
			obj_t aux_4132;
			{
			   object_t aux_4133;
			   aux_4133 = (object_t) (obj1136_990);
			   aux_4132 = OBJECT_WIDENING(aux_4133);
			}
			aux_4131 = (((cptr_t) CREF(aux_4132))->point_to_164);
		     }
		     aux_4130 = (obj_t) (aux_4131);
		  }
		  STRUCT_SET(aux1138_994, ((long) 1), aux_4130);
	       }
	       {
		  obj_t aux_4139;
		  {
		     bool_t aux_4140;
		     {
			obj_t aux_4141;
			{
			   object_t aux_4142;
			   aux_4142 = (object_t) (obj1136_990);
			   aux_4141 = OBJECT_WIDENING(aux_4142);
			}
			aux_4140 = (((cptr_t) CREF(aux_4141))->array__248);
		     }
		     aux_4139 = BBOOL(aux_4140);
		  }
		  STRUCT_SET(aux1138_994, ((long) 2), aux_4139);
	       }
	       STRUCT_SET(res1137_993, ((long) 0), aux1138_994);
	       {
		  obj_t aux_4149;
		  aux_4149 = STRUCT_KEY(res1137_993);
		  STRUCT_KEY_SET(aux1138_994, aux_4149);
	       }
	       {
		  obj_t aux_4152;
		  aux_4152 = CNST_TABLE_REF(((long) 25));
		  STRUCT_KEY_SET(res1137_993, aux_4152);
	       }
	       return res1137_993;
	    }
	 }
      }
   }
}


/* struct+object->object-cstruct */ obj_t 
struct_object__object_cstruct_172_foreign_ctype(obj_t env_2344, obj_t o_2345, obj_t s_2346)
{
   {
      cstruct_t o_976;
      obj_t s_977;
      {
	 cstruct_t aux_4156;
	 o_976 = (cstruct_t) (o_2345);
	 s_977 = s_2346;
	 {
	    {
	       obj_t old1165_980;
	       obj_t aux1166_981;
	       {
		  obj_t next_method1206_23_988;
		  next_method1206_23_988 = find_super_class_method_167___object((object_t) (o_976), struct_object__object_env_209___object, cstruct_foreign_ctype);
		  if (PROCEDUREP(next_method1206_23_988))
		    {
		       old1165_980 = PROCEDURE_ENTRY(next_method1206_23_988) (next_method1206_23_988, (obj_t) (o_976), s_977, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1206_23_988);
		       {
			  object_t aux_4165;
			  aux_4165 = struct_object__object_93___object((object_t) (o_976), s_977);
			  old1165_980 = (obj_t) (aux_4165);
		       }
		    }
	       }
	       aux1166_981 = STRUCT_REF(s_977, ((long) 0));
	       {
		  cstruct_t new1167_982;
		  new1167_982 = ((cstruct_t) (old1165_980));
		  {
		     long arg1753_983;
		     arg1753_983 = class_num_218___object(cstruct_foreign_ctype);
		     {
			obj_t obj_1610;
			obj_1610 = (obj_t) (new1167_982);
			(((obj_t) CREF(obj_1610))->header = MAKE_HEADER(arg1753_983, 0), BUNSPEC);
		     }
		  }
		  {
		     cstruct_t arg1755_984;
		     {
			obj_t arg1759_986;
			obj_t arg1760_987;
			arg1759_986 = STRUCT_REF(aux1166_981, ((long) 1));
			arg1760_987 = STRUCT_REF(aux1166_981, ((long) 2));
			{
			   cstruct_t res1854_1625;
			   {
			      bool_t struct__46_1618;
			      {
				 obj_t aux_4176;
				 aux_4176 = STRUCT_REF(aux1166_981, ((long) 0));
				 struct__46_1618 = CBOOL(aux_4176);
			      }
			      {
				 cstruct_t new1142_1621;
				 new1142_1621 = ((cstruct_t) BREF(GC_MALLOC(sizeof(struct cstruct))));
				 ((((cstruct_t) CREF(new1142_1621))->struct__46) = ((bool_t) struct__46_1618), BUNSPEC);
				 ((((cstruct_t) CREF(new1142_1621))->fields) = ((obj_t) arg1759_986), BUNSPEC);
				 ((((cstruct_t) CREF(new1142_1621))->cstruct__170) = ((obj_t) arg1760_987), BUNSPEC);
				 res1854_1625 = new1142_1621;
			      }
			   }
			   arg1755_984 = res1854_1625;
			}
		     }
		     {
			obj_t aux_4185;
			object_t aux_4183;
			aux_4185 = (obj_t) (arg1755_984);
			aux_4183 = (object_t) (new1167_982);
			OBJECT_WIDENING_SET(aux_4183, aux_4185);
		     }
		  }
		  aux_4156 = new1167_982;
	       }
	    }
	 }
	 return (obj_t) (aux_4156);
      }
   }
}


/* object->struct-cstruct */ obj_t 
object__struct_cstruct_165_foreign_ctype(obj_t env_2347, obj_t obj1162_2348)
{
   {
      cstruct_t obj1162_959;
      obj1162_959 = (cstruct_t) (obj1162_2348);
      {
	 {
	    obj_t res1163_962;
	    {
	       obj_t next_method1205_37_974;
	       next_method1205_37_974 = find_super_class_method_167___object((object_t) (obj1162_959), object__struct_env_210___object, cstruct_foreign_ctype);
	       if (PROCEDUREP(next_method1205_37_974))
		 {
		    res1163_962 = PROCEDURE_ENTRY(next_method1205_37_974) (next_method1205_37_974, (obj_t) (obj1162_959), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1205_37_974);
		    res1163_962 = object__struct_50___object((object_t) (obj1162_959));
		 }
	    }
	    {
	       obj_t aux1164_963;
	       {
		  obj_t aux_4200;
		  aux_4200 = CNST_TABLE_REF(((long) 26));
		  aux1164_963 = make_struct(aux_4200, ((long) 3), BUNSPEC);
	       }
	       {
		  obj_t aux_4203;
		  {
		     bool_t aux_4204;
		     {
			obj_t aux_4205;
			{
			   object_t aux_4206;
			   aux_4206 = (object_t) (obj1162_959);
			   aux_4205 = OBJECT_WIDENING(aux_4206);
			}
			aux_4204 = (((cstruct_t) CREF(aux_4205))->struct__46);
		     }
		     aux_4203 = BBOOL(aux_4204);
		  }
		  STRUCT_SET(aux1164_963, ((long) 0), aux_4203);
	       }
	       {
		  obj_t aux_4212;
		  {
		     obj_t aux_4213;
		     {
			object_t aux_4214;
			aux_4214 = (object_t) (obj1162_959);
			aux_4213 = OBJECT_WIDENING(aux_4214);
		     }
		     aux_4212 = (((cstruct_t) CREF(aux_4213))->fields);
		  }
		  STRUCT_SET(aux1164_963, ((long) 1), aux_4212);
	       }
	       {
		  obj_t aux_4219;
		  {
		     obj_t aux_4220;
		     {
			object_t aux_4221;
			aux_4221 = (object_t) (obj1162_959);
			aux_4220 = OBJECT_WIDENING(aux_4221);
		     }
		     aux_4219 = (((cstruct_t) CREF(aux_4220))->cstruct__170);
		  }
		  STRUCT_SET(aux1164_963, ((long) 2), aux_4219);
	       }
	       STRUCT_SET(res1163_962, ((long) 0), aux1164_963);
	       {
		  obj_t aux_4227;
		  aux_4227 = STRUCT_KEY(res1163_962);
		  STRUCT_KEY_SET(aux1164_963, aux_4227);
	       }
	       {
		  obj_t aux_4230;
		  aux_4230 = CNST_TABLE_REF(((long) 26));
		  STRUCT_KEY_SET(res1163_962, aux_4230);
	       }
	       return res1163_962;
	    }
	 }
      }
   }
}


/* struct+object->object-cstruct* */ obj_t 
struct_object__object_cstruct__130_foreign_ctype(obj_t env_2349, obj_t o_2350, obj_t s_2351)
{
   {
      cstruct__170_t o_946;
      obj_t s_947;
      {
	 cstruct__170_t aux_4234;
	 o_946 = (cstruct__170_t) (o_2350);
	 s_947 = s_2351;
	 {
	    {
	       obj_t old1189_950;
	       obj_t aux1190_951;
	       {
		  obj_t next_method1204_69_957;
		  next_method1204_69_957 = find_super_class_method_167___object((object_t) (o_946), struct_object__object_env_209___object, cstruct__170_foreign_ctype);
		  if (PROCEDUREP(next_method1204_69_957))
		    {
		       old1189_950 = PROCEDURE_ENTRY(next_method1204_69_957) (next_method1204_69_957, (obj_t) (o_946), s_947, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1204_69_957);
		       {
			  object_t aux_4243;
			  aux_4243 = struct_object__object_93___object((object_t) (o_946), s_947);
			  old1189_950 = (obj_t) (aux_4243);
		       }
		    }
	       }
	       aux1190_951 = STRUCT_REF(s_947, ((long) 0));
	       {
		  cstruct__170_t new1191_952;
		  new1191_952 = ((cstruct__170_t) (old1189_950));
		  {
		     long arg1728_953;
		     arg1728_953 = class_num_218___object(cstruct__170_foreign_ctype);
		     {
			obj_t obj_1569;
			obj_1569 = (obj_t) (new1191_952);
			(((obj_t) CREF(obj_1569))->header = MAKE_HEADER(arg1728_953, 0), BUNSPEC);
		     }
		  }
		  {
		     cstruct__170_t arg1729_954;
		     {
			cstruct__170_t res1853_1580;
			{
			   type_t btype_1575;
			   cstruct_t cstruct_1576;
			   {
			      obj_t aux_4252;
			      aux_4252 = STRUCT_REF(aux1190_951, ((long) 0));
			      btype_1575 = (type_t) (aux_4252);
			   }
			   {
			      obj_t aux_4255;
			      aux_4255 = STRUCT_REF(aux1190_951, ((long) 1));
			      cstruct_1576 = (cstruct_t) (aux_4255);
			   }
			   {
			      cstruct__170_t new1168_1577;
			      new1168_1577 = ((cstruct__170_t) BREF(GC_MALLOC(sizeof(struct cstruct__170))));
			      ((((cstruct__170_t) CREF(new1168_1577))->btype) = ((type_t) btype_1575), BUNSPEC);
			      ((((cstruct__170_t) CREF(new1168_1577))->cstruct) = ((cstruct_t) cstruct_1576), BUNSPEC);
			      res1853_1580 = new1168_1577;
			   }
			}
			arg1729_954 = res1853_1580;
		     }
		     {
			obj_t aux_4263;
			object_t aux_4261;
			aux_4263 = (obj_t) (arg1729_954);
			aux_4261 = (object_t) (new1191_952);
			OBJECT_WIDENING_SET(aux_4261, aux_4263);
		     }
		  }
		  aux_4234 = new1191_952;
	       }
	    }
	 }
	 return (obj_t) (aux_4234);
      }
   }
}


/* object->struct-cstruct* */ obj_t 
object__struct_cstruct__194_foreign_ctype(obj_t env_2352, obj_t obj1186_2353)
{
   {
      cstruct__170_t obj1186_931;
      obj1186_931 = (cstruct__170_t) (obj1186_2353);
      {
	 {
	    obj_t res1187_934;
	    {
	       obj_t next_method1203_39_944;
	       next_method1203_39_944 = find_super_class_method_167___object((object_t) (obj1186_931), object__struct_env_210___object, cstruct__170_foreign_ctype);
	       if (PROCEDUREP(next_method1203_39_944))
		 {
		    res1187_934 = PROCEDURE_ENTRY(next_method1203_39_944) (next_method1203_39_944, (obj_t) (obj1186_931), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1203_39_944);
		    res1187_934 = object__struct_50___object((object_t) (obj1186_931));
		 }
	    }
	    {
	       obj_t aux1188_935;
	       {
		  obj_t aux_4278;
		  aux_4278 = CNST_TABLE_REF(((long) 27));
		  aux1188_935 = make_struct(aux_4278, ((long) 2), BUNSPEC);
	       }
	       {
		  obj_t aux_4281;
		  {
		     type_t aux_4282;
		     {
			obj_t aux_4283;
			{
			   object_t aux_4284;
			   aux_4284 = (object_t) (obj1186_931);
			   aux_4283 = OBJECT_WIDENING(aux_4284);
			}
			aux_4282 = (((cstruct__170_t) CREF(aux_4283))->btype);
		     }
		     aux_4281 = (obj_t) (aux_4282);
		  }
		  STRUCT_SET(aux1188_935, ((long) 0), aux_4281);
	       }
	       {
		  obj_t aux_4290;
		  {
		     cstruct_t aux_4291;
		     {
			obj_t aux_4292;
			{
			   object_t aux_4293;
			   aux_4293 = (object_t) (obj1186_931);
			   aux_4292 = OBJECT_WIDENING(aux_4293);
			}
			aux_4291 = (((cstruct__170_t) CREF(aux_4292))->cstruct);
		     }
		     aux_4290 = (obj_t) (aux_4291);
		  }
		  STRUCT_SET(aux1188_935, ((long) 1), aux_4290);
	       }
	       STRUCT_SET(res1187_934, ((long) 0), aux1188_935);
	       {
		  obj_t aux_4300;
		  aux_4300 = STRUCT_KEY(res1187_934);
		  STRUCT_KEY_SET(aux1188_935, aux_4300);
	       }
	       {
		  obj_t aux_4303;
		  aux_4303 = CNST_TABLE_REF(((long) 27));
		  STRUCT_KEY_SET(res1187_934, aux_4303);
	       }
	       return res1187_934;
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_foreign_ctype()
{
   module_initialization_70_tools_trace(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70_type_type(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70_type_env(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70_type_cache(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70_type_tools(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70_tools_error(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70_tools_args(((long) 0), "FOREIGN_CTYPE");
   module_initialization_70_tools_misc(((long) 0), "FOREIGN_CTYPE");
   return module_initialization_70_module_module(((long) 0), "FOREIGN_CTYPE");
}
