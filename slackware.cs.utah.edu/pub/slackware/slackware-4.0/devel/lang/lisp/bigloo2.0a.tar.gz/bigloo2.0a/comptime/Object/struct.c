/*===========================================================================*/
/*   (Object/struct.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


extern obj_t make_struct__wide_object_7_object_struct(obj_t, type_t, obj_t, obj_t, obj_t);
static obj_t method_init_76_object_struct();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t make_wide_object__struct_148_object_struct(obj_t, type_t, obj_t, obj_t, obj_t);
extern obj_t make_struct__object_35_object_struct(obj_t, type_t, obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
static obj_t _make_object__struct_151_object_struct(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_object_struct(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_object_tools(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t save_slot_187_object_struct(obj_t, obj_t, obj_t, long, obj_t);
static obj_t imported_modules_init_94_object_struct();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t make_object__struct_189_object_struct(obj_t, type_t, obj_t, obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_object_struct();
static obj_t toplevel_init_63_object_struct();
extern obj_t malloc_object_tools(type_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t epairify_object_struct(obj_t, obj_t);
extern obj_t make_pragma_indexed_init_set__66_object_tools(type_t, obj_t, obj_t, obj_t);
static obj_t restore_slot_6_object_struct(obj_t, obj_t, obj_t, type_t, long, obj_t);
extern obj_t _4dots_199_tools_misc;
static obj_t _make_struct__wide_object_21_object_struct(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static long slots_length_21_object_struct(obj_t);
extern obj_t make_pragma_direct_set__7_object_tools(type_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _make_struct__object_170_object_struct(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_object_struct = BUNSPEC;
static obj_t _make_wide_object__struct_137_object_struct(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t cnst_init_137_object_struct();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t make_pragma_indexed_set__175_object_tools(type_t, obj_t, obj_t, obj_t, obj_t);
static obj_t __cnst[46];

DEFINE_EXPORT_PROCEDURE(make_object__struct_env_214_object_struct, _make_object__struct_151_object_struct2537, _make_object__struct_151_object_struct, 0L, 5);
DEFINE_EXPORT_PROCEDURE(make_wide_object__struct_env_82_object_struct, _make_wide_object__struct_137_object_struct2538, _make_wide_object__struct_137_object_struct, 0L, 5);
DEFINE_STRING(string2531_object_struct, string2531_object_struct2539, "@ CLASS-NUM OBJECT-CLASS-NUM-SET! PRAGMA NEW OLD OBJECT-WIDENING-SET! S::STRUCT STRUCT+OBJECT->OBJECT::OBJECT VECTOR-REF-UR DONE O VECTOR-LENGTH S STRUCT-REF ::LONG V I STRUCT-KEY STRUCT-KEY-SET! CALL-NEXT-METHOD AUX ::STRUCT QUOTE MAKE-STRUCT OBJECT->STRUCT::STRUCT DEFINE-METHOD RES OBJ -LEN +FX -REF VECTOR-SET-UR! BEGIN =FX IF LABELS MAKE-VECTOR PRAGMA::LONG LET LEN LOOP J VEC - STRUCT-SET! ", 396);
DEFINE_STRING(string2529_object_struct, string2529_object_struct2540, "cer", 3);
DEFINE_STRING(string2530_object_struct, string2530_object_struct2541, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string2528_object_struct, string2528_object_struct2542, "((", 2);
DEFINE_STRING(string2527_object_struct, string2527_object_struct2543, ")($1))", 6);
DEFINE_EXPORT_PROCEDURE(make_struct__wide_object_env_183_object_struct, _make_struct__wide_object_21_object_struct2544, _make_struct__wide_object_21_object_struct, 0L, 5);
DEFINE_EXPORT_PROCEDURE(make_struct__object_env_44_object_struct, _make_struct__object_170_object_struct2545, _make_struct__object_170_object_struct, 0L, 5);


/* module-initialization */ obj_t 
module_initialization_70_object_struct(long checksum_2001, char *from_2002)
{
   if (CBOOL(require_initialization_114_object_struct))
     {
	require_initialization_114_object_struct = BBOOL(((bool_t) 0));
	library_modules_init_112_object_struct();
	cnst_init_137_object_struct();
	imported_modules_init_94_object_struct();
	method_init_76_object_struct();
	toplevel_init_63_object_struct();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_struct()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "OBJECT_STRUCT");
   module_initialization_70___r4_strings_6_7(((long) 0), "OBJECT_STRUCT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_STRUCT");
   module_initialization_70___reader(((long) 0), "OBJECT_STRUCT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_struct()
{
   {
      obj_t cnst_port_138_1993;
      cnst_port_138_1993 = open_input_string(string2531_object_struct);
      {
	 long i_1994;
	 i_1994 = ((long) 45);
       loop_1995:
	 {
	    bool_t test2532_1996;
	    test2532_1996 = (i_1994 == ((long) -1));
	    if (test2532_1996)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2533_1997;
		    {
		       obj_t list2534_1998;
		       {
			  obj_t arg2535_1999;
			  arg2535_1999 = BNIL;
			  list2534_1998 = MAKE_PAIR(cnst_port_138_1993, arg2535_1999);
		       }
		       arg2533_1997 = read___reader(list2534_1998);
		    }
		    CNST_TABLE_SET(i_1994, arg2533_1997);
		 }
		 {
		    int aux_2000;
		    {
		       long aux_2021;
		       aux_2021 = (i_1994 - ((long) 1));
		       aux_2000 = (int) (aux_2021);
		    }
		    {
		       long i_2024;
		       i_2024 = (long) (aux_2000);
		       i_1994 = i_2024;
		       goto loop_1995;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_object_struct()
{
   return BUNSPEC;
}


/* save-slot */ obj_t 
save_slot_187_object_struct(obj_t oname_63, obj_t sname_64, obj_t cname_65, long i_66, obj_t slot_67)
{
   {
      {
	 bool_t test_2026;
	 {
	    obj_t aux_2027;
	    aux_2027 = STRUCT_REF(slot_67, ((long) 5));
	    test_2026 = CBOOL(aux_2027);
	 }
	 if (test_2026)
	   {
	      {
		 obj_t vec_661;
		 obj_t j_662;
		 obj_t loop_663;
		 obj_t len_664;
		 vec_661 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
		 j_662 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 3)), BEOA);
		 loop_663 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
		 len_664 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
		 {
		    obj_t arg1458_665;
		    obj_t arg1460_666;
		    obj_t arg1461_667;
		    arg1458_665 = CNST_TABLE_REF(((long) 6));
		    {
		       obj_t arg1468_673;
		       {
			  obj_t arg1473_677;
			  {
			     obj_t arg1478_682;
			     {
				obj_t arg1484_687;
				obj_t arg1485_688;
				arg1484_687 = CNST_TABLE_REF(((long) 1));
				arg1485_688 = STRUCT_REF(slot_67, ((long) 0));
				{
				   obj_t list1487_690;
				   {
				      obj_t arg1488_691;
				      {
					 obj_t arg1489_692;
					 {
					    obj_t arg1490_693;
					    {
					       obj_t aux_2045;
					       aux_2045 = CNST_TABLE_REF(((long) 16));
					       arg1490_693 = MAKE_PAIR(aux_2045, BNIL);
					    }
					    arg1489_692 = MAKE_PAIR(arg1485_688, arg1490_693);
					 }
					 arg1488_691 = MAKE_PAIR(arg1484_687, arg1489_692);
				      }
				      list1487_690 = MAKE_PAIR(cname_65, arg1488_691);
				   }
				   arg1478_682 = symbol_append_197___r4_symbols_6_4(list1487_690);
				}
			     }
			     {
				obj_t list1480_684;
				{
				   obj_t arg1481_685;
				   arg1481_685 = MAKE_PAIR(BNIL, BNIL);
				   list1480_684 = MAKE_PAIR(oname_63, arg1481_685);
				}
				arg1473_677 = cons__138___r4_pairs_and_lists_6_3(arg1478_682, list1480_684);
			     }
			  }
			  {
			     obj_t list1475_679;
			     {
				obj_t arg1476_680;
				arg1476_680 = MAKE_PAIR(BNIL, BNIL);
				list1475_679 = MAKE_PAIR(arg1473_677, arg1476_680);
			     }
			     arg1468_673 = cons__138___r4_pairs_and_lists_6_3(len_664, list1475_679);
			  }
		       }
		       {
			  obj_t list1470_675;
			  list1470_675 = MAKE_PAIR(BNIL, BNIL);
			  arg1460_666 = cons__138___r4_pairs_and_lists_6_3(arg1468_673, list1470_675);
		       }
		    }
		    {
		       obj_t arg1494_695;
		       obj_t arg1496_696;
		       obj_t arg1497_697;
		       arg1494_695 = CNST_TABLE_REF(((long) 6));
		       {
			  obj_t arg1503_703;
			  {
			     obj_t arg1510_707;
			     {
				obj_t arg1515_712;
				arg1515_712 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t list1517_714;
				   {
				      obj_t arg1518_715;
				      arg1518_715 = MAKE_PAIR(BNIL, BNIL);
				      list1517_714 = MAKE_PAIR(len_664, arg1518_715);
				   }
				   arg1510_707 = cons__138___r4_pairs_and_lists_6_3(arg1515_712, list1517_714);
				}
			     }
			     {
				obj_t list1512_709;
				{
				   obj_t arg1513_710;
				   arg1513_710 = MAKE_PAIR(BNIL, BNIL);
				   list1512_709 = MAKE_PAIR(arg1510_707, arg1513_710);
				}
				arg1503_703 = cons__138___r4_pairs_and_lists_6_3(vec_661, list1512_709);
			     }
			  }
			  {
			     obj_t list1505_705;
			     list1505_705 = MAKE_PAIR(BNIL, BNIL);
			     arg1496_696 = cons__138___r4_pairs_and_lists_6_3(arg1503_703, list1505_705);
			  }
		       }
		       {
			  obj_t arg1522_717;
			  obj_t arg1524_718;
			  obj_t arg1525_719;
			  arg1522_717 = CNST_TABLE_REF(((long) 9));
			  {
			     obj_t arg1531_725;
			     {
				obj_t arg1535_729;
				obj_t arg1536_730;
				{
				   obj_t list1546_737;
				   list1546_737 = MAKE_PAIR(BNIL, BNIL);
				   arg1535_729 = cons__138___r4_pairs_and_lists_6_3(j_662, list1546_737);
				}
				{
				   obj_t arg1549_739;
				   obj_t arg1550_740;
				   obj_t arg1552_741;
				   obj_t arg1553_742;
				   arg1549_739 = CNST_TABLE_REF(((long) 10));
				   {
				      obj_t arg1560_749;
				      arg1560_749 = CNST_TABLE_REF(((long) 11));
				      {
					 obj_t list1562_751;
					 {
					    obj_t arg1563_752;
					    {
					       obj_t arg1564_753;
					       arg1564_753 = MAKE_PAIR(BNIL, BNIL);
					       arg1563_752 = MAKE_PAIR(len_664, arg1564_753);
					    }
					    list1562_751 = MAKE_PAIR(j_662, arg1563_752);
					 }
					 arg1550_740 = cons__138___r4_pairs_and_lists_6_3(arg1560_749, list1562_751);
				      }
				   }
				   {
				      obj_t arg1566_755;
				      arg1566_755 = CNST_TABLE_REF(((long) 0));
				      {
					 obj_t list1569_757;
					 {
					    obj_t arg1570_758;
					    {
					       obj_t arg1572_759;
					       {
						  obj_t arg1573_760;
						  arg1573_760 = MAKE_PAIR(BNIL, BNIL);
						  arg1572_759 = MAKE_PAIR(vec_661, arg1573_760);
					       }
					       {
						  obj_t aux_2082;
						  aux_2082 = BINT(i_66);
						  arg1570_758 = MAKE_PAIR(aux_2082, arg1572_759);
					       }
					    }
					    list1569_757 = MAKE_PAIR(sname_64, arg1570_758);
					 }
					 arg1552_741 = cons__138___r4_pairs_and_lists_6_3(arg1566_755, list1569_757);
				      }
				   }
				   {
				      obj_t arg1578_762;
				      obj_t arg1580_763;
				      obj_t arg1581_764;
				      arg1578_762 = CNST_TABLE_REF(((long) 12));
				      {
					 obj_t arg1587_770;
					 obj_t arg1588_771;
					 arg1587_770 = CNST_TABLE_REF(((long) 13));
					 {
					    obj_t arg1598_778;
					    {
					       obj_t arg1606_784;
					       obj_t arg1607_785;
					       arg1606_784 = CNST_TABLE_REF(((long) 1));
					       arg1607_785 = STRUCT_REF(slot_67, ((long) 0));
					       {
						  obj_t list1609_787;
						  {
						     obj_t arg1610_788;
						     {
							obj_t arg1612_789;
							{
							   obj_t arg1613_790;
							   {
							      obj_t aux_2091;
							      aux_2091 = CNST_TABLE_REF(((long) 14));
							      arg1613_790 = MAKE_PAIR(aux_2091, BNIL);
							   }
							   arg1612_789 = MAKE_PAIR(arg1607_785, arg1613_790);
							}
							arg1610_788 = MAKE_PAIR(arg1606_784, arg1612_789);
						     }
						     list1609_787 = MAKE_PAIR(cname_65, arg1610_788);
						  }
						  arg1598_778 = symbol_append_197___r4_symbols_6_4(list1609_787);
					       }
					    }
					    {
					       obj_t list1601_780;
					       {
						  obj_t arg1602_781;
						  {
						     obj_t arg1603_782;
						     arg1603_782 = MAKE_PAIR(BNIL, BNIL);
						     arg1602_781 = MAKE_PAIR(j_662, arg1603_782);
						  }
						  list1601_780 = MAKE_PAIR(oname_63, arg1602_781);
					       }
					       arg1588_771 = cons__138___r4_pairs_and_lists_6_3(arg1598_778, list1601_780);
					    }
					 }
					 {
					    obj_t list1590_773;
					    {
					       obj_t arg1592_774;
					       {
						  obj_t arg1593_775;
						  {
						     obj_t arg1594_776;
						     arg1594_776 = MAKE_PAIR(BNIL, BNIL);
						     arg1593_775 = MAKE_PAIR(arg1588_771, arg1594_776);
						  }
						  arg1592_774 = MAKE_PAIR(j_662, arg1593_775);
					       }
					       list1590_773 = MAKE_PAIR(vec_661, arg1592_774);
					    }
					    arg1580_763 = cons__138___r4_pairs_and_lists_6_3(arg1587_770, list1590_773);
					 }
				      }
				      {
					 obj_t arg1617_792;
					 {
					    obj_t arg1622_797;
					    arg1622_797 = CNST_TABLE_REF(((long) 15));
					    {
					       obj_t list1625_800;
					       {
						  obj_t arg1627_801;
						  {
						     obj_t arg1628_802;
						     arg1628_802 = MAKE_PAIR(BNIL, BNIL);
						     {
							obj_t aux_2109;
							aux_2109 = BINT(((long) 1));
							arg1627_801 = MAKE_PAIR(aux_2109, arg1628_802);
						     }
						  }
						  list1625_800 = MAKE_PAIR(j_662, arg1627_801);
					       }
					       arg1617_792 = cons__138___r4_pairs_and_lists_6_3(arg1622_797, list1625_800);
					    }
					 }
					 {
					    obj_t list1619_794;
					    {
					       obj_t arg1620_795;
					       arg1620_795 = MAKE_PAIR(BNIL, BNIL);
					       list1619_794 = MAKE_PAIR(arg1617_792, arg1620_795);
					    }
					    arg1581_764 = cons__138___r4_pairs_and_lists_6_3(loop_663, list1619_794);
					 }
				      }
				      {
					 obj_t list1583_766;
					 {
					    obj_t arg1584_767;
					    {
					       obj_t arg1585_768;
					       arg1585_768 = MAKE_PAIR(BNIL, BNIL);
					       arg1584_767 = MAKE_PAIR(arg1581_764, arg1585_768);
					    }
					    list1583_766 = MAKE_PAIR(arg1580_763, arg1584_767);
					 }
					 arg1553_742 = cons__138___r4_pairs_and_lists_6_3(arg1578_762, list1583_766);
				      }
				   }
				   {
				      obj_t list1555_744;
				      {
					 obj_t arg1556_745;
					 {
					    obj_t arg1557_746;
					    {
					       obj_t arg1558_747;
					       arg1558_747 = MAKE_PAIR(BNIL, BNIL);
					       arg1557_746 = MAKE_PAIR(arg1553_742, arg1558_747);
					    }
					    arg1556_745 = MAKE_PAIR(arg1552_741, arg1557_746);
					 }
					 list1555_744 = MAKE_PAIR(arg1550_740, arg1556_745);
				      }
				      arg1536_730 = cons__138___r4_pairs_and_lists_6_3(arg1549_739, list1555_744);
				   }
				}
				{
				   obj_t list1538_732;
				   {
				      obj_t arg1539_733;
				      {
					 obj_t arg1540_734;
					 arg1540_734 = MAKE_PAIR(BNIL, BNIL);
					 arg1539_733 = MAKE_PAIR(arg1536_730, arg1540_734);
				      }
				      list1538_732 = MAKE_PAIR(arg1535_729, arg1539_733);
				   }
				   arg1531_725 = cons__138___r4_pairs_and_lists_6_3(loop_663, list1538_732);
				}
			     }
			     {
				obj_t list1533_727;
				list1533_727 = MAKE_PAIR(BNIL, BNIL);
				arg1524_718 = cons__138___r4_pairs_and_lists_6_3(arg1531_725, list1533_727);
			     }
			  }
			  {
			     obj_t list1634_806;
			     {
				obj_t arg1636_807;
				arg1636_807 = MAKE_PAIR(BNIL, BNIL);
				{
				   obj_t aux_2133;
				   aux_2133 = BINT(((long) 0));
				   list1634_806 = MAKE_PAIR(aux_2133, arg1636_807);
				}
			     }
			     arg1525_719 = cons__138___r4_pairs_and_lists_6_3(loop_663, list1634_806);
			  }
			  {
			     obj_t list1527_721;
			     {
				obj_t arg1528_722;
				{
				   obj_t arg1529_723;
				   arg1529_723 = MAKE_PAIR(BNIL, BNIL);
				   arg1528_722 = MAKE_PAIR(arg1525_719, arg1529_723);
				}
				list1527_721 = MAKE_PAIR(arg1524_718, arg1528_722);
			     }
			     arg1497_697 = cons__138___r4_pairs_and_lists_6_3(arg1522_717, list1527_721);
			  }
		       }
		       {
			  obj_t list1499_699;
			  {
			     obj_t arg1500_700;
			     {
				obj_t arg1501_701;
				arg1501_701 = MAKE_PAIR(BNIL, BNIL);
				arg1500_700 = MAKE_PAIR(arg1497_697, arg1501_701);
			     }
			     list1499_699 = MAKE_PAIR(arg1496_696, arg1500_700);
			  }
			  arg1461_667 = cons__138___r4_pairs_and_lists_6_3(arg1494_695, list1499_699);
		       }
		    }
		    {
		       obj_t list1464_669;
		       {
			  obj_t arg1465_670;
			  {
			     obj_t arg1466_671;
			     arg1466_671 = MAKE_PAIR(BNIL, BNIL);
			     arg1465_670 = MAKE_PAIR(arg1461_667, arg1466_671);
			  }
			  list1464_669 = MAKE_PAIR(arg1460_666, arg1465_670);
		       }
		       return cons__138___r4_pairs_and_lists_6_3(arg1458_665, list1464_669);
		    }
		 }
	      }
	   }
	 else
	   {
	      bool_t test_2149;
	      {
		 obj_t aux_2150;
		 aux_2150 = STRUCT_REF(slot_67, ((long) 3));
		 test_2149 = CBOOL(aux_2150);
	      }
	      if (test_2149)
		{
		   {
		      obj_t vec_515;
		      obj_t j_516;
		      obj_t loop_517;
		      obj_t len_518;
		      vec_515 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
		      j_516 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 3)), BEOA);
		      loop_517 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
		      len_518 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
		      {
			 obj_t arg1262_519;
			 obj_t arg1263_520;
			 obj_t arg1265_521;
			 arg1262_519 = CNST_TABLE_REF(((long) 6));
			 {
			    obj_t arg1273_527;
			    {
			       obj_t arg1278_531;
			       {
				  obj_t arg1285_536;
				  obj_t arg1286_537;
				  arg1285_536 = CNST_TABLE_REF(((long) 7));
				  arg1286_537 = STRUCT_REF(slot_67, ((long) 4));
				  {
				     obj_t list1288_539;
				     {
					obj_t arg1290_540;
					arg1290_540 = MAKE_PAIR(BNIL, BNIL);
					list1288_539 = MAKE_PAIR(arg1286_537, arg1290_540);
				     }
				     arg1278_531 = cons__138___r4_pairs_and_lists_6_3(arg1285_536, list1288_539);
				  }
			       }
			       {
				  obj_t list1282_533;
				  {
				     obj_t arg1283_534;
				     arg1283_534 = MAKE_PAIR(BNIL, BNIL);
				     list1282_533 = MAKE_PAIR(arg1278_531, arg1283_534);
				  }
				  arg1273_527 = cons__138___r4_pairs_and_lists_6_3(len_518, list1282_533);
			       }
			    }
			    {
			       obj_t list1275_529;
			       list1275_529 = MAKE_PAIR(BNIL, BNIL);
			       arg1263_520 = cons__138___r4_pairs_and_lists_6_3(arg1273_527, list1275_529);
			    }
			 }
			 {
			    obj_t arg1292_542;
			    obj_t arg1294_543;
			    obj_t arg1295_544;
			    arg1292_542 = CNST_TABLE_REF(((long) 6));
			    {
			       obj_t arg1301_550;
			       {
				  obj_t arg1307_554;
				  {
				     obj_t arg1313_559;
				     arg1313_559 = CNST_TABLE_REF(((long) 8));
				     {
					obj_t list1316_561;
					{
					   obj_t arg1319_562;
					   arg1319_562 = MAKE_PAIR(BNIL, BNIL);
					   list1316_561 = MAKE_PAIR(len_518, arg1319_562);
					}
					arg1307_554 = cons__138___r4_pairs_and_lists_6_3(arg1313_559, list1316_561);
				     }
				  }
				  {
				     obj_t list1309_556;
				     {
					obj_t arg1310_557;
					arg1310_557 = MAKE_PAIR(BNIL, BNIL);
					list1309_556 = MAKE_PAIR(arg1307_554, arg1310_557);
				     }
				     arg1301_550 = cons__138___r4_pairs_and_lists_6_3(vec_515, list1309_556);
				  }
			       }
			       {
				  obj_t list1303_552;
				  list1303_552 = MAKE_PAIR(BNIL, BNIL);
				  arg1294_543 = cons__138___r4_pairs_and_lists_6_3(arg1301_550, list1303_552);
			       }
			    }
			    {
			       obj_t arg1322_564;
			       obj_t arg1323_565;
			       obj_t arg1324_566;
			       arg1322_564 = CNST_TABLE_REF(((long) 9));
			       {
				  obj_t arg1332_572;
				  {
				     obj_t arg1339_576;
				     obj_t arg1340_577;
				     {
					obj_t list1350_584;
					list1350_584 = MAKE_PAIR(BNIL, BNIL);
					arg1339_576 = cons__138___r4_pairs_and_lists_6_3(j_516, list1350_584);
				     }
				     {
					obj_t arg1352_586;
					obj_t arg1353_587;
					obj_t arg1355_588;
					obj_t arg1356_589;
					arg1352_586 = CNST_TABLE_REF(((long) 10));
					{
					   obj_t arg1367_596;
					   arg1367_596 = CNST_TABLE_REF(((long) 11));
					   {
					      obj_t list1369_598;
					      {
						 obj_t arg1370_599;
						 {
						    obj_t arg1372_600;
						    arg1372_600 = MAKE_PAIR(BNIL, BNIL);
						    arg1370_599 = MAKE_PAIR(len_518, arg1372_600);
						 }
						 list1369_598 = MAKE_PAIR(j_516, arg1370_599);
					      }
					      arg1353_587 = cons__138___r4_pairs_and_lists_6_3(arg1367_596, list1369_598);
					   }
					}
					{
					   obj_t arg1375_602;
					   arg1375_602 = CNST_TABLE_REF(((long) 0));
					   {
					      obj_t list1379_604;
					      {
						 obj_t arg1381_605;
						 {
						    obj_t arg1383_606;
						    {
						       obj_t arg1384_607;
						       arg1384_607 = MAKE_PAIR(BNIL, BNIL);
						       arg1383_606 = MAKE_PAIR(vec_515, arg1384_607);
						    }
						    {
						       obj_t aux_2198;
						       aux_2198 = BINT(i_66);
						       arg1381_605 = MAKE_PAIR(aux_2198, arg1383_606);
						    }
						 }
						 list1379_604 = MAKE_PAIR(sname_64, arg1381_605);
					      }
					      arg1355_588 = cons__138___r4_pairs_and_lists_6_3(arg1375_602, list1379_604);
					   }
					}
					{
					   obj_t arg1387_609;
					   obj_t arg1388_610;
					   obj_t arg1389_611;
					   arg1387_609 = CNST_TABLE_REF(((long) 12));
					   {
					      obj_t arg1396_617;
					      obj_t arg1397_618;
					      arg1396_617 = CNST_TABLE_REF(((long) 13));
					      {
						 obj_t arg1407_625;
						 {
						    obj_t arg1414_631;
						    obj_t arg1415_632;
						    arg1414_631 = CNST_TABLE_REF(((long) 1));
						    arg1415_632 = STRUCT_REF(slot_67, ((long) 0));
						    {
						       obj_t list1417_634;
						       {
							  obj_t arg1418_635;
							  {
							     obj_t arg1419_636;
							     {
								obj_t arg1421_637;
								{
								   obj_t aux_2207;
								   aux_2207 = CNST_TABLE_REF(((long) 14));
								   arg1421_637 = MAKE_PAIR(aux_2207, BNIL);
								}
								arg1419_636 = MAKE_PAIR(arg1415_632, arg1421_637);
							     }
							     arg1418_635 = MAKE_PAIR(arg1414_631, arg1419_636);
							  }
							  list1417_634 = MAKE_PAIR(cname_65, arg1418_635);
						       }
						       arg1407_625 = symbol_append_197___r4_symbols_6_4(list1417_634);
						    }
						 }
						 {
						    obj_t list1409_627;
						    {
						       obj_t arg1410_628;
						       {
							  obj_t arg1411_629;
							  arg1411_629 = MAKE_PAIR(BNIL, BNIL);
							  arg1410_628 = MAKE_PAIR(j_516, arg1411_629);
						       }
						       list1409_627 = MAKE_PAIR(oname_63, arg1410_628);
						    }
						    arg1397_618 = cons__138___r4_pairs_and_lists_6_3(arg1407_625, list1409_627);
						 }
					      }
					      {
						 obj_t list1399_620;
						 {
						    obj_t arg1401_621;
						    {
						       obj_t arg1402_622;
						       {
							  obj_t arg1403_623;
							  arg1403_623 = MAKE_PAIR(BNIL, BNIL);
							  arg1402_622 = MAKE_PAIR(arg1397_618, arg1403_623);
						       }
						       arg1401_621 = MAKE_PAIR(j_516, arg1402_622);
						    }
						    list1399_620 = MAKE_PAIR(vec_515, arg1401_621);
						 }
						 arg1388_610 = cons__138___r4_pairs_and_lists_6_3(arg1396_617, list1399_620);
					      }
					   }
					   {
					      obj_t arg1426_639;
					      {
						 obj_t arg1433_644;
						 arg1433_644 = CNST_TABLE_REF(((long) 15));
						 {
						    obj_t list1438_647;
						    {
						       obj_t arg1440_648;
						       {
							  obj_t arg1441_649;
							  arg1441_649 = MAKE_PAIR(BNIL, BNIL);
							  {
							     obj_t aux_2225;
							     aux_2225 = BINT(((long) 1));
							     arg1440_648 = MAKE_PAIR(aux_2225, arg1441_649);
							  }
						       }
						       list1438_647 = MAKE_PAIR(j_516, arg1440_648);
						    }
						    arg1426_639 = cons__138___r4_pairs_and_lists_6_3(arg1433_644, list1438_647);
						 }
					      }
					      {
						 obj_t list1428_641;
						 {
						    obj_t arg1431_642;
						    arg1431_642 = MAKE_PAIR(BNIL, BNIL);
						    list1428_641 = MAKE_PAIR(arg1426_639, arg1431_642);
						 }
						 arg1389_611 = cons__138___r4_pairs_and_lists_6_3(loop_517, list1428_641);
					      }
					   }
					   {
					      obj_t list1391_613;
					      {
						 obj_t arg1392_614;
						 {
						    obj_t arg1393_615;
						    arg1393_615 = MAKE_PAIR(BNIL, BNIL);
						    arg1392_614 = MAKE_PAIR(arg1389_611, arg1393_615);
						 }
						 list1391_613 = MAKE_PAIR(arg1388_610, arg1392_614);
					      }
					      arg1356_589 = cons__138___r4_pairs_and_lists_6_3(arg1387_609, list1391_613);
					   }
					}
					{
					   obj_t list1358_591;
					   {
					      obj_t arg1361_592;
					      {
						 obj_t arg1363_593;
						 {
						    obj_t arg1364_594;
						    arg1364_594 = MAKE_PAIR(BNIL, BNIL);
						    arg1363_593 = MAKE_PAIR(arg1356_589, arg1364_594);
						 }
						 arg1361_592 = MAKE_PAIR(arg1355_588, arg1363_593);
					      }
					      list1358_591 = MAKE_PAIR(arg1353_587, arg1361_592);
					   }
					   arg1340_577 = cons__138___r4_pairs_and_lists_6_3(arg1352_586, list1358_591);
					}
				     }
				     {
					obj_t list1343_579;
					{
					   obj_t arg1344_580;
					   {
					      obj_t arg1345_581;
					      arg1345_581 = MAKE_PAIR(BNIL, BNIL);
					      arg1344_580 = MAKE_PAIR(arg1340_577, arg1345_581);
					   }
					   list1343_579 = MAKE_PAIR(arg1339_576, arg1344_580);
					}
					arg1332_572 = cons__138___r4_pairs_and_lists_6_3(loop_517, list1343_579);
				     }
				  }
				  {
				     obj_t list1334_574;
				     list1334_574 = MAKE_PAIR(BNIL, BNIL);
				     arg1323_565 = cons__138___r4_pairs_and_lists_6_3(arg1332_572, list1334_574);
				  }
			       }
			       {
				  obj_t list1447_653;
				  {
				     obj_t arg1448_654;
				     arg1448_654 = MAKE_PAIR(BNIL, BNIL);
				     {
					obj_t aux_2249;
					aux_2249 = BINT(((long) 0));
					list1447_653 = MAKE_PAIR(aux_2249, arg1448_654);
				     }
				  }
				  arg1324_566 = cons__138___r4_pairs_and_lists_6_3(loop_517, list1447_653);
			       }
			       {
				  obj_t list1326_568;
				  {
				     obj_t arg1328_569;
				     {
					obj_t arg1330_570;
					arg1330_570 = MAKE_PAIR(BNIL, BNIL);
					arg1328_569 = MAKE_PAIR(arg1324_566, arg1330_570);
				     }
				     list1326_568 = MAKE_PAIR(arg1323_565, arg1328_569);
				  }
				  arg1295_544 = cons__138___r4_pairs_and_lists_6_3(arg1322_564, list1326_568);
			       }
			    }
			    {
			       obj_t list1297_546;
			       {
				  obj_t arg1298_547;
				  {
				     obj_t arg1299_548;
				     arg1299_548 = MAKE_PAIR(BNIL, BNIL);
				     arg1298_547 = MAKE_PAIR(arg1295_544, arg1299_548);
				  }
				  list1297_546 = MAKE_PAIR(arg1294_543, arg1298_547);
			       }
			       arg1265_521 = cons__138___r4_pairs_and_lists_6_3(arg1292_542, list1297_546);
			    }
			 }
			 {
			    obj_t list1268_523;
			    {
			       obj_t arg1269_524;
			       {
				  obj_t arg1270_525;
				  arg1270_525 = MAKE_PAIR(BNIL, BNIL);
				  arg1269_524 = MAKE_PAIR(arg1265_521, arg1270_525);
			       }
			       list1268_523 = MAKE_PAIR(arg1263_520, arg1269_524);
			    }
			    return cons__138___r4_pairs_and_lists_6_3(arg1262_519, list1268_523);
			 }
		      }
		   }
		}
	      else
		{
		   bool_t test_2265;
		   {
		      obj_t aux_2266;
		      aux_2266 = STRUCT_REF(slot_67, ((long) 11));
		      test_2265 = CBOOL(aux_2266);
		   }
		   if (test_2265)
		     {
			return BUNSPEC;
		     }
		   else
		     {
			{
			   obj_t arg1236_495;
			   obj_t arg1238_496;
			   arg1236_495 = CNST_TABLE_REF(((long) 0));
			   {
			      obj_t arg1248_503;
			      {
				 obj_t arg1254_508;
				 arg1254_508 = CNST_TABLE_REF(((long) 1));
				 {
				    obj_t list1256_510;
				    {
				       obj_t arg1257_511;
				       {
					  obj_t arg1258_512;
					  {
					     obj_t aux_2271;
					     aux_2271 = STRUCT_REF(slot_67, ((long) 0));
					     arg1258_512 = MAKE_PAIR(aux_2271, BNIL);
					  }
					  arg1257_511 = MAKE_PAIR(arg1254_508, arg1258_512);
				       }
				       list1256_510 = MAKE_PAIR(cname_65, arg1257_511);
				    }
				    arg1248_503 = symbol_append_197___r4_symbols_6_4(list1256_510);
				 }
			      }
			      {
				 obj_t list1251_505;
				 {
				    obj_t arg1252_506;
				    arg1252_506 = MAKE_PAIR(BNIL, BNIL);
				    list1251_505 = MAKE_PAIR(oname_63, arg1252_506);
				 }
				 arg1238_496 = cons__138___r4_pairs_and_lists_6_3(arg1248_503, list1251_505);
			      }
			   }
			   {
			      obj_t list1241_498;
			      {
				 obj_t arg1243_499;
				 {
				    obj_t arg1244_500;
				    {
				       obj_t arg1245_501;
				       arg1245_501 = MAKE_PAIR(BNIL, BNIL);
				       arg1244_500 = MAKE_PAIR(arg1238_496, arg1245_501);
				    }
				    {
				       obj_t aux_2282;
				       aux_2282 = BINT(i_66);
				       arg1243_499 = MAKE_PAIR(aux_2282, arg1244_500);
				    }
				 }
				 list1241_498 = MAKE_PAIR(sname_64, arg1243_499);
			      }
			      return cons__138___r4_pairs_and_lists_6_3(arg1236_495, list1241_498);
			   }
			}
		     }
		}
	   }
      }
   }
}


/* slots-length */ long 
slots_length_21_object_struct(obj_t slots_68)
{
   {
      obj_t slots_816;
      long len_817;
      slots_816 = slots_68;
      len_817 = ((long) 0);
    loop_818:
      if (NULLP(slots_816))
	{
	   return len_817;
	}
      else
	{
	   bool_t test_2289;
	   {
	      obj_t aux_2290;
	      {
		 obj_t aux_2291;
		 aux_2291 = CAR(slots_816);
		 aux_2290 = STRUCT_REF(aux_2291, ((long) 11));
	      }
	      test_2289 = CBOOL(aux_2290);
	   }
	   if (test_2289)
	     {
		{
		   obj_t slots_2295;
		   slots_2295 = CDR(slots_816);
		   slots_816 = slots_2295;
		   goto loop_818;
		}
	     }
	   else
	     {
		{
		   long len_2299;
		   obj_t slots_2297;
		   slots_2297 = CDR(slots_816);
		   len_2299 = (((long) 1) + len_817);
		   len_817 = len_2299;
		   slots_816 = slots_2297;
		   goto loop_818;
		}
	     }
	}
   }
}


/* make-object->struct */ obj_t 
make_object__struct_189_object_struct(obj_t cname_69, type_t type_70, obj_t module_71, obj_t slots_72, obj_t src_def_101_73)
{
   {
      long len_825;
      obj_t oname_826;
      obj_t sname_827;
      {
	 long aux_2301;
	 aux_2301 = slots_length_21_object_struct(slots_72);
	 len_825 = (((long) 1) + aux_2301);
      }
      oname_826 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 17)), BEOA);
      sname_827 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 18)), BEOA);
      {
	 obj_t arg1653_828;
	 {
	    obj_t arg1656_831;
	    obj_t arg1657_832;
	    obj_t arg1658_833;
	    arg1656_831 = CNST_TABLE_REF(((long) 19));
	    {
	       obj_t arg1666_839;
	       obj_t arg1667_840;
	       arg1666_839 = CNST_TABLE_REF(((long) 20));
	       {
		  obj_t list1673_845;
		  {
		     obj_t arg1675_846;
		     {
			obj_t arg1676_847;
			arg1676_847 = MAKE_PAIR(cname_69, BNIL);
			arg1675_846 = MAKE_PAIR(_4dots_199_tools_misc, arg1676_847);
		     }
		     list1673_845 = MAKE_PAIR(oname_826, arg1675_846);
		  }
		  arg1667_840 = symbol_append_197___r4_symbols_6_4(list1673_845);
	       }
	       {
		  obj_t list1669_842;
		  {
		     obj_t arg1670_843;
		     arg1670_843 = MAKE_PAIR(BNIL, BNIL);
		     list1669_842 = MAKE_PAIR(arg1667_840, arg1670_843);
		  }
		  arg1657_832 = cons__138___r4_pairs_and_lists_6_3(arg1666_839, list1669_842);
	       }
	    }
	    {
	       obj_t arg1678_849;
	       obj_t arg1679_850;
	       obj_t arg1680_851;
	       arg1678_849 = CNST_TABLE_REF(((long) 6));
	       {
		  obj_t arg1686_857;
		  {
		     obj_t arg1692_861;
		     {
			obj_t arg1698_866;
			obj_t arg1699_867;
			arg1698_866 = CNST_TABLE_REF(((long) 21));
			{
			   obj_t arg1706_874;
			   arg1706_874 = CNST_TABLE_REF(((long) 22));
			   {
			      obj_t list1708_876;
			      {
				 obj_t arg1709_877;
				 arg1709_877 = MAKE_PAIR(BNIL, BNIL);
				 list1708_876 = MAKE_PAIR(cname_69, arg1709_877);
			      }
			      arg1699_867 = cons__138___r4_pairs_and_lists_6_3(arg1706_874, list1708_876);
			   }
			}
			{
			   obj_t list1701_869;
			   {
			      obj_t arg1702_870;
			      {
				 obj_t arg1703_871;
				 {
				    obj_t arg1704_872;
				    arg1704_872 = MAKE_PAIR(BNIL, BNIL);
				    arg1703_871 = MAKE_PAIR(BUNSPEC, arg1704_872);
				 }
				 {
				    obj_t aux_2327;
				    aux_2327 = BINT(len_825);
				    arg1702_870 = MAKE_PAIR(aux_2327, arg1703_871);
				 }
			      }
			      list1701_869 = MAKE_PAIR(arg1699_867, arg1702_870);
			   }
			   arg1692_861 = cons__138___r4_pairs_and_lists_6_3(arg1698_866, list1701_869);
			}
		     }
		     {
			obj_t list1694_863;
			{
			   obj_t arg1695_864;
			   arg1695_864 = MAKE_PAIR(BNIL, BNIL);
			   list1694_863 = MAKE_PAIR(arg1692_861, arg1695_864);
			}
			arg1686_857 = cons__138___r4_pairs_and_lists_6_3(sname_827, list1694_863);
		     }
		  }
		  {
		     obj_t list1689_859;
		     list1689_859 = MAKE_PAIR(BNIL, BNIL);
		     arg1679_850 = cons__138___r4_pairs_and_lists_6_3(arg1686_857, list1689_859);
		  }
	       }
	       {
		  obj_t arg1711_879;
		  obj_t arg1712_880;
		  obj_t arg1713_881;
		  arg1711_879 = CNST_TABLE_REF(((long) 12));
		  {
		     obj_t arg1718_885;
		     arg1718_885 = CNST_TABLE_REF(((long) 0));
		     {
			obj_t list1722_888;
			{
			   obj_t arg1723_889;
			   {
			      obj_t arg1724_890;
			      {
				 obj_t arg1725_891;
				 arg1725_891 = MAKE_PAIR(BNIL, BNIL);
				 arg1724_890 = MAKE_PAIR(BFALSE, arg1725_891);
			      }
			      {
				 obj_t aux_2341;
				 aux_2341 = BINT(((long) 0));
				 arg1723_889 = MAKE_PAIR(aux_2341, arg1724_890);
			      }
			   }
			   list1722_888 = MAKE_PAIR(sname_827, arg1723_889);
			}
			arg1712_880 = cons__138___r4_pairs_and_lists_6_3(arg1718_885, list1722_888);
		     }
		  }
		  {
		     obj_t arg1727_893;
		     obj_t arg1728_894;
		     {
			long i_895;
			obj_t slots_896;
			obj_t res_897;
			i_895 = ((long) 1);
			slots_896 = slots_72;
			res_897 = BNIL;
		      loop_898:
			if ((i_895 == len_825))
			  {
			     arg1727_893 = reverse__39___r4_pairs_and_lists_6_3(res_897);
			  }
			else
			  {
			     bool_t test_2349;
			     {
				obj_t aux_2350;
				{
				   obj_t aux_2351;
				   aux_2351 = CAR(slots_896);
				   aux_2350 = STRUCT_REF(aux_2351, ((long) 11));
				}
				test_2349 = CBOOL(aux_2350);
			     }
			     if (test_2349)
			       {
				  {
				     obj_t slots_2357;
				     long i_2355;
				     i_2355 = (i_895 + ((long) 1));
				     slots_2357 = CDR(slots_896);
				     slots_896 = slots_2357;
				     i_895 = i_2355;
				     goto loop_898;
				  }
			       }
			     else
			       {
				  {
				     long arg1739_905;
				     obj_t arg1740_906;
				     obj_t arg1743_907;
				     arg1739_905 = (i_895 + ((long) 1));
				     arg1740_906 = CDR(slots_896);
				     {
					obj_t arg1744_908;
					arg1744_908 = save_slot_187_object_struct(oname_826, sname_827, cname_69, i_895, CAR(slots_896));
					arg1743_907 = MAKE_PAIR(arg1744_908, res_897);
				     }
				     {
					obj_t res_2366;
					obj_t slots_2365;
					long i_2364;
					i_2364 = arg1739_905;
					slots_2365 = arg1740_906;
					res_2366 = arg1743_907;
					res_897 = res_2366;
					slots_896 = slots_2365;
					i_895 = i_2364;
					goto loop_898;
				     }
				  }
			       }
			  }
		     }
		     {
			obj_t list1748_912;
			list1748_912 = MAKE_PAIR(BNIL, BNIL);
			arg1728_894 = cons__138___r4_pairs_and_lists_6_3(sname_827, list1748_912);
		     }
		     arg1713_881 = append_2_18___r4_pairs_and_lists_6_3(arg1727_893, arg1728_894);
		  }
		  {
		     obj_t list1714_882;
		     {
			obj_t arg1716_883;
			arg1716_883 = MAKE_PAIR(arg1713_881, BNIL);
			list1714_882 = MAKE_PAIR(arg1712_880, arg1716_883);
		     }
		     arg1680_851 = cons__138___r4_pairs_and_lists_6_3(arg1711_879, list1714_882);
		  }
	       }
	       {
		  obj_t list1682_853;
		  {
		     obj_t arg1683_854;
		     {
			obj_t arg1684_855;
			arg1684_855 = MAKE_PAIR(BNIL, BNIL);
			arg1683_854 = MAKE_PAIR(arg1680_851, arg1684_855);
		     }
		     list1682_853 = MAKE_PAIR(arg1679_850, arg1683_854);
		  }
		  arg1658_833 = cons__138___r4_pairs_and_lists_6_3(arg1678_849, list1682_853);
	       }
	    }
	    {
	       obj_t list1660_835;
	       {
		  obj_t arg1661_836;
		  {
		     obj_t arg1663_837;
		     arg1663_837 = MAKE_PAIR(BNIL, BNIL);
		     arg1661_836 = MAKE_PAIR(arg1658_833, arg1663_837);
		  }
		  list1660_835 = MAKE_PAIR(arg1657_832, arg1661_836);
	       }
	       arg1653_828 = cons__138___r4_pairs_and_lists_6_3(arg1656_831, list1660_835);
	    }
	 }
	 {
	    obj_t list1654_829;
	    list1654_829 = MAKE_PAIR(src_def_101_73, BNIL);
	    return epairify_object_struct(arg1653_828, list1654_829);
	 }
      }
   }
}


/* _make-object->struct */ obj_t 
_make_object__struct_151_object_struct(obj_t env_1968, obj_t cname_1969, obj_t type_1970, obj_t module_1971, obj_t slots_1972, obj_t src_def_101_1973)
{
   return make_object__struct_189_object_struct(cname_1969, (type_t) (type_1970), module_1971, slots_1972, src_def_101_1973);
}


/* make-wide-object->struct */ obj_t 
make_wide_object__struct_148_object_struct(obj_t cname_74, type_t type_75, obj_t module_76, obj_t slots_77, obj_t src_def_101_78)
{
   {
      long len_918;
      len_918 = slots_length_21_object_struct(slots_77);
      {
	 obj_t oname_919;
	 oname_919 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 17)), BEOA);
	 {
	    obj_t res_920;
	    res_920 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 18)), BEOA);
	    {
	       obj_t tres_921;
	       {
		  obj_t list1913_1054;
		  {
		     obj_t arg1914_1055;
		     {
			obj_t aux_2392;
			aux_2392 = CNST_TABLE_REF(((long) 23));
			arg1914_1055 = MAKE_PAIR(aux_2392, BNIL);
		     }
		     list1913_1054 = MAKE_PAIR(res_920, arg1914_1055);
		  }
		  tres_921 = symbol_append_197___r4_symbols_6_4(list1913_1054);
	       }
	       {
		  obj_t aux_922;
		  aux_922 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 24)), BEOA);
		  {
		     {
			obj_t arg1760_923;
			{
			   obj_t arg1765_926;
			   obj_t arg1766_927;
			   obj_t arg1767_928;
			   arg1765_926 = CNST_TABLE_REF(((long) 19));
			   {
			      obj_t arg1773_934;
			      obj_t arg1774_935;
			      arg1773_934 = CNST_TABLE_REF(((long) 20));
			      {
				 obj_t list1780_940;
				 {
				    obj_t arg1781_941;
				    {
				       obj_t arg1783_942;
				       arg1783_942 = MAKE_PAIR(cname_74, BNIL);
				       arg1781_941 = MAKE_PAIR(_4dots_199_tools_misc, arg1783_942);
				    }
				    list1780_940 = MAKE_PAIR(oname_919, arg1781_941);
				 }
				 arg1774_935 = symbol_append_197___r4_symbols_6_4(list1780_940);
			      }
			      {
				 obj_t list1777_937;
				 {
				    obj_t arg1778_938;
				    arg1778_938 = MAKE_PAIR(BNIL, BNIL);
				    list1777_937 = MAKE_PAIR(arg1774_935, arg1778_938);
				 }
				 arg1766_927 = cons__138___r4_pairs_and_lists_6_3(arg1773_934, list1777_937);
			      }
			   }
			   {
			      obj_t arg1788_944;
			      obj_t arg1789_945;
			      obj_t arg1790_946;
			      arg1788_944 = CNST_TABLE_REF(((long) 6));
			      {
				 obj_t arg1796_952;
				 {
				    obj_t arg1800_956;
				    {
				       obj_t arg1806_961;
				       arg1806_961 = CNST_TABLE_REF(((long) 25));
				       {
					  obj_t list1808_963;
					  list1808_963 = MAKE_PAIR(BNIL, BNIL);
					  arg1800_956 = cons__138___r4_pairs_and_lists_6_3(arg1806_961, list1808_963);
				       }
				    }
				    {
				       obj_t list1803_958;
				       {
					  obj_t arg1804_959;
					  arg1804_959 = MAKE_PAIR(BNIL, BNIL);
					  list1803_958 = MAKE_PAIR(arg1800_956, arg1804_959);
				       }
				       arg1796_952 = cons__138___r4_pairs_and_lists_6_3(tres_921, list1803_958);
				    }
				 }
				 {
				    obj_t list1798_954;
				    list1798_954 = MAKE_PAIR(BNIL, BNIL);
				    arg1789_945 = cons__138___r4_pairs_and_lists_6_3(arg1796_952, list1798_954);
				 }
			      }
			      {
				 obj_t arg1810_965;
				 obj_t arg1811_966;
				 obj_t arg1812_967;
				 arg1810_965 = CNST_TABLE_REF(((long) 6));
				 {
				    obj_t arg1816_971;
				    {
				       obj_t arg1821_975;
				       {
					  obj_t arg1827_980;
					  obj_t arg1829_981;
					  arg1827_980 = CNST_TABLE_REF(((long) 21));
					  {
					     obj_t arg1836_988;
					     arg1836_988 = CNST_TABLE_REF(((long) 22));
					     {
						obj_t list1838_990;
						{
						   obj_t arg1839_991;
						   arg1839_991 = MAKE_PAIR(BNIL, BNIL);
						   list1838_990 = MAKE_PAIR(cname_74, arg1839_991);
						}
						arg1829_981 = cons__138___r4_pairs_and_lists_6_3(arg1836_988, list1838_990);
					     }
					  }
					  {
					     obj_t list1831_983;
					     {
						obj_t arg1832_984;
						{
						   obj_t arg1833_985;
						   {
						      obj_t arg1834_986;
						      arg1834_986 = MAKE_PAIR(BNIL, BNIL);
						      arg1833_985 = MAKE_PAIR(BUNSPEC, arg1834_986);
						   }
						   {
						      obj_t aux_2426;
						      aux_2426 = BINT(len_918);
						      arg1832_984 = MAKE_PAIR(aux_2426, arg1833_985);
						   }
						}
						list1831_983 = MAKE_PAIR(arg1829_981, arg1832_984);
					     }
					     arg1821_975 = cons__138___r4_pairs_and_lists_6_3(arg1827_980, list1831_983);
					  }
				       }
				       {
					  obj_t list1823_977;
					  {
					     obj_t arg1824_978;
					     arg1824_978 = MAKE_PAIR(BNIL, BNIL);
					     list1823_977 = MAKE_PAIR(arg1821_975, arg1824_978);
					  }
					  arg1816_971 = cons__138___r4_pairs_and_lists_6_3(aux_922, list1823_977);
				       }
				    }
				    {
				       obj_t list1818_973;
				       list1818_973 = MAKE_PAIR(BNIL, BNIL);
				       arg1811_966 = cons__138___r4_pairs_and_lists_6_3(arg1816_971, list1818_973);
				    }
				 }
				 {
				    obj_t arg1843_993;
				    obj_t arg1847_994;
				    {
				       long i_995;
				       obj_t slots_996;
				       obj_t res_997;
				       i_995 = ((long) 0);
				       slots_996 = slots_77;
				       res_997 = BNIL;
				     loop_998:
				       if ((i_995 == len_918))
					 {
					    arg1843_993 = reverse__39___r4_pairs_and_lists_6_3(res_997);
					 }
				       else
					 {
					    bool_t test_2439;
					    {
					       obj_t aux_2440;
					       {
						  obj_t aux_2441;
						  aux_2441 = CAR(slots_996);
						  aux_2440 = STRUCT_REF(aux_2441, ((long) 11));
					       }
					       test_2439 = CBOOL(aux_2440);
					    }
					    if (test_2439)
					      {
						 {
						    obj_t slots_2447;
						    long i_2445;
						    i_2445 = (i_995 + ((long) 1));
						    slots_2447 = CDR(slots_996);
						    slots_996 = slots_2447;
						    i_995 = i_2445;
						    goto loop_998;
						 }
					      }
					    else
					      {
						 {
						    long arg1857_1005;
						    obj_t arg1858_1006;
						    obj_t arg1859_1007;
						    arg1857_1005 = (i_995 + ((long) 1));
						    arg1858_1006 = CDR(slots_996);
						    {
						       obj_t arg1860_1008;
						       arg1860_1008 = save_slot_187_object_struct(oname_919, aux_922, cname_74, i_995, CAR(slots_996));
						       arg1859_1007 = MAKE_PAIR(arg1860_1008, res_997);
						    }
						    {
						       obj_t res_2456;
						       obj_t slots_2455;
						       long i_2454;
						       i_2454 = arg1857_1005;
						       slots_2455 = arg1858_1006;
						       res_2456 = arg1859_1007;
						       res_997 = res_2456;
						       slots_996 = slots_2455;
						       i_995 = i_2454;
						       goto loop_998;
						    }
						 }
					      }
					 }
				    }
				    {
				       obj_t arg1863_1011;
				       obj_t arg1864_1012;
				       obj_t arg1865_1013;
				       {
					  obj_t arg1874_1020;
					  arg1874_1020 = CNST_TABLE_REF(((long) 0));
					  {
					     obj_t list1877_1023;
					     {
						obj_t arg1878_1024;
						{
						   obj_t arg1879_1025;
						   {
						      obj_t arg1880_1026;
						      arg1880_1026 = MAKE_PAIR(BNIL, BNIL);
						      arg1879_1025 = MAKE_PAIR(aux_922, arg1880_1026);
						   }
						   {
						      obj_t aux_2460;
						      aux_2460 = BINT(((long) 0));
						      arg1878_1024 = MAKE_PAIR(aux_2460, arg1879_1025);
						   }
						}
						list1877_1023 = MAKE_PAIR(res_920, arg1878_1024);
					     }
					     arg1863_1011 = cons__138___r4_pairs_and_lists_6_3(arg1874_1020, list1877_1023);
					  }
				       }
				       {
					  obj_t arg1883_1028;
					  obj_t arg1884_1029;
					  arg1883_1028 = CNST_TABLE_REF(((long) 26));
					  {
					     obj_t arg1892_1035;
					     arg1892_1035 = CNST_TABLE_REF(((long) 27));
					     {
						obj_t list1894_1037;
						{
						   obj_t arg1895_1038;
						   arg1895_1038 = MAKE_PAIR(BNIL, BNIL);
						   list1894_1037 = MAKE_PAIR(res_920, arg1895_1038);
						}
						arg1884_1029 = cons__138___r4_pairs_and_lists_6_3(arg1892_1035, list1894_1037);
					     }
					  }
					  {
					     obj_t list1886_1031;
					     {
						obj_t arg1887_1032;
						{
						   obj_t arg1888_1033;
						   arg1888_1033 = MAKE_PAIR(BNIL, BNIL);
						   arg1887_1032 = MAKE_PAIR(arg1884_1029, arg1888_1033);
						}
						list1886_1031 = MAKE_PAIR(aux_922, arg1887_1032);
					     }
					     arg1864_1012 = cons__138___r4_pairs_and_lists_6_3(arg1883_1028, list1886_1031);
					  }
				       }
				       {
					  obj_t arg1897_1040;
					  obj_t arg1898_1041;
					  arg1897_1040 = CNST_TABLE_REF(((long) 26));
					  {
					     obj_t arg1905_1047;
					     arg1905_1047 = CNST_TABLE_REF(((long) 22));
					     {
						obj_t list1907_1049;
						{
						   obj_t arg1909_1050;
						   arg1909_1050 = MAKE_PAIR(BNIL, BNIL);
						   list1907_1049 = MAKE_PAIR(cname_74, arg1909_1050);
						}
						arg1898_1041 = cons__138___r4_pairs_and_lists_6_3(arg1905_1047, list1907_1049);
					     }
					  }
					  {
					     obj_t list1900_1043;
					     {
						obj_t arg1901_1044;
						{
						   obj_t arg1902_1045;
						   arg1902_1045 = MAKE_PAIR(BNIL, BNIL);
						   arg1901_1044 = MAKE_PAIR(arg1898_1041, arg1902_1045);
						}
						list1900_1043 = MAKE_PAIR(res_920, arg1901_1044);
					     }
					     arg1865_1013 = cons__138___r4_pairs_and_lists_6_3(arg1897_1040, list1900_1043);
					  }
				       }
				       {
					  obj_t list1867_1015;
					  {
					     obj_t arg1868_1016;
					     {
						obj_t arg1869_1017;
						{
						   obj_t arg1870_1018;
						   arg1870_1018 = MAKE_PAIR(BNIL, BNIL);
						   arg1869_1017 = MAKE_PAIR(res_920, arg1870_1018);
						}
						arg1868_1016 = MAKE_PAIR(arg1865_1013, arg1869_1017);
					     }
					     list1867_1015 = MAKE_PAIR(arg1864_1012, arg1868_1016);
					  }
					  arg1847_994 = cons__138___r4_pairs_and_lists_6_3(arg1863_1011, list1867_1015);
				       }
				    }
				    arg1812_967 = append_2_18___r4_pairs_and_lists_6_3(arg1843_993, arg1847_994);
				 }
				 {
				    obj_t list1813_968;
				    {
				       obj_t arg1814_969;
				       arg1814_969 = MAKE_PAIR(arg1812_967, BNIL);
				       list1813_968 = MAKE_PAIR(arg1811_966, arg1814_969);
				    }
				    arg1790_946 = cons__138___r4_pairs_and_lists_6_3(arg1810_965, list1813_968);
				 }
			      }
			      {
				 obj_t list1792_948;
				 {
				    obj_t arg1793_949;
				    {
				       obj_t arg1794_950;
				       arg1794_950 = MAKE_PAIR(BNIL, BNIL);
				       arg1793_949 = MAKE_PAIR(arg1790_946, arg1794_950);
				    }
				    list1792_948 = MAKE_PAIR(arg1789_945, arg1793_949);
				 }
				 arg1767_928 = cons__138___r4_pairs_and_lists_6_3(arg1788_944, list1792_948);
			      }
			   }
			   {
			      obj_t list1769_930;
			      {
				 obj_t arg1770_931;
				 {
				    obj_t arg1771_932;
				    arg1771_932 = MAKE_PAIR(BNIL, BNIL);
				    arg1770_931 = MAKE_PAIR(arg1767_928, arg1771_932);
				 }
				 list1769_930 = MAKE_PAIR(arg1766_927, arg1770_931);
			      }
			      arg1760_923 = cons__138___r4_pairs_and_lists_6_3(arg1765_926, list1769_930);
			   }
			}
			{
			   obj_t list1761_924;
			   list1761_924 = MAKE_PAIR(src_def_101_78, BNIL);
			   return epairify_object_struct(arg1760_923, list1761_924);
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _make-wide-object->struct */ obj_t 
_make_wide_object__struct_137_object_struct(obj_t env_1974, obj_t cname_1975, obj_t type_1976, obj_t module_1977, obj_t slots_1978, obj_t src_def_101_1979)
{
   return make_wide_object__struct_148_object_struct(cname_1975, (type_t) (type_1976), module_1977, slots_1978, src_def_101_1979);
}


/* restore-slot */ obj_t 
restore_slot_6_object_struct(obj_t oname_79, obj_t sname_80, obj_t cname_81, type_t type_82, long i_83, obj_t slot_84)
{
   {
      obj_t loop_1059;
      loop_1059 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
      {
	 obj_t runner_1060;
	 runner_1060 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 28)), BEOA);
	 {
	    obj_t v_1061;
	    v_1061 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 29)), BEOA);
	    {
	       obj_t len_1062;
	       len_1062 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
	       {
		  obj_t runner_typed_89_1063;
		  {
		     obj_t list2223_1341;
		     {
			obj_t arg2224_1342;
			{
			   obj_t aux_2516;
			   aux_2516 = CNST_TABLE_REF(((long) 30));
			   arg2224_1342 = MAKE_PAIR(aux_2516, BNIL);
			}
			list2223_1341 = MAKE_PAIR(runner_1060, arg2224_1342);
		     }
		     runner_typed_89_1063 = symbol_append_197___r4_symbols_6_4(list2223_1341);
		  }
		  {
		     {
			bool_t test_2521;
			{
			   obj_t aux_2522;
			   aux_2522 = STRUCT_REF(slot_84, ((long) 5));
			   test_2521 = CBOOL(aux_2522);
			}
			if (test_2521)
			  {
			     {
				obj_t arg1919_1065;
				obj_t arg1920_1066;
				obj_t arg1921_1067;
				arg1919_1065 = CNST_TABLE_REF(((long) 6));
				{
				   obj_t arg1929_1073;
				   {
				      obj_t arg1933_1077;
				      {
					 obj_t arg1938_1082;
					 obj_t arg1939_1083;
					 arg1938_1082 = CNST_TABLE_REF(((long) 31));
					 arg1939_1083 = CNST_TABLE_REF(((long) 32));
					 {
					    obj_t list1941_1085;
					    {
					       obj_t arg1942_1086;
					       {
						  obj_t arg1943_1087;
						  arg1943_1087 = MAKE_PAIR(BNIL, BNIL);
						  {
						     obj_t aux_2529;
						     aux_2529 = BINT(i_83);
						     arg1942_1086 = MAKE_PAIR(aux_2529, arg1943_1087);
						  }
					       }
					       list1941_1085 = MAKE_PAIR(arg1939_1083, arg1942_1086);
					    }
					    arg1933_1077 = cons__138___r4_pairs_and_lists_6_3(arg1938_1082, list1941_1085);
					 }
				      }
				      {
					 obj_t list1935_1079;
					 {
					    obj_t arg1936_1080;
					    arg1936_1080 = MAKE_PAIR(BNIL, BNIL);
					    list1935_1079 = MAKE_PAIR(arg1933_1077, arg1936_1080);
					 }
					 arg1929_1073 = cons__138___r4_pairs_and_lists_6_3(v_1061, list1935_1079);
				      }
				   }
				   {
				      obj_t list1931_1075;
				      list1931_1075 = MAKE_PAIR(BNIL, BNIL);
				      arg1920_1066 = cons__138___r4_pairs_and_lists_6_3(arg1929_1073, list1931_1075);
				   }
				}
				{
				   obj_t arg1945_1089;
				   obj_t arg1947_1090;
				   obj_t arg1948_1091;
				   obj_t arg1949_1092;
				   arg1945_1089 = CNST_TABLE_REF(((long) 6));
				   {
				      obj_t arg1957_1099;
				      {
					 obj_t arg1961_1103;
					 obj_t arg1962_1104;
					 {
					    obj_t list1971_1110;
					    {
					       obj_t arg1972_1111;
					       {
						  obj_t aux_2540;
						  aux_2540 = CNST_TABLE_REF(((long) 30));
						  arg1972_1111 = MAKE_PAIR(aux_2540, BNIL);
					       }
					       list1971_1110 = MAKE_PAIR(len_1062, arg1972_1111);
					    }
					    arg1961_1103 = symbol_append_197___r4_symbols_6_4(list1971_1110);
					 }
					 {
					    obj_t arg1974_1113;
					    arg1974_1113 = CNST_TABLE_REF(((long) 33));
					    {
					       obj_t list1976_1115;
					       {
						  obj_t arg1977_1116;
						  arg1977_1116 = MAKE_PAIR(BNIL, BNIL);
						  list1976_1115 = MAKE_PAIR(v_1061, arg1977_1116);
					       }
					       arg1962_1104 = cons__138___r4_pairs_and_lists_6_3(arg1974_1113, list1976_1115);
					    }
					 }
					 {
					    obj_t list1964_1106;
					    {
					       obj_t arg1965_1107;
					       arg1965_1107 = MAKE_PAIR(BNIL, BNIL);
					       list1964_1106 = MAKE_PAIR(arg1962_1104, arg1965_1107);
					    }
					    arg1957_1099 = cons__138___r4_pairs_and_lists_6_3(arg1961_1103, list1964_1106);
					 }
				      }
				      {
					 obj_t list1959_1101;
					 list1959_1101 = MAKE_PAIR(BNIL, BNIL);
					 arg1947_1090 = cons__138___r4_pairs_and_lists_6_3(arg1957_1099, list1959_1101);
				      }
				   }
				   {
				      obj_t arg1979_1118;
				      obj_t arg1980_1119;
				      arg1979_1118 = CNST_TABLE_REF(((long) 34));
				      {
					 type_t aux_2555;
					 {
					    obj_t aux_2556;
					    aux_2556 = STRUCT_REF(slot_84, ((long) 2));
					    aux_2555 = (type_t) (aux_2556);
					 }
					 arg1980_1119 = malloc_object_tools(aux_2555, len_1062);
				      }
				      arg1948_1091 = make_pragma_indexed_init_set__66_object_tools(type_82, slot_84, arg1979_1118, arg1980_1119);
				   }
				   {
				      obj_t arg1982_1121;
				      obj_t arg1983_1122;
				      obj_t arg1984_1123;
				      arg1982_1121 = CNST_TABLE_REF(((long) 9));
				      {
					 obj_t arg1990_1129;
					 {
					    obj_t arg1994_1133;
					    obj_t arg1995_1134;
					    {
					       obj_t list2004_1141;
					       list2004_1141 = MAKE_PAIR(BNIL, BNIL);
					       arg1994_1133 = cons__138___r4_pairs_and_lists_6_3(runner_typed_89_1063, list2004_1141);
					    }
					    {
					       obj_t arg2008_1143;
					       obj_t arg2010_1144;
					       obj_t arg2011_1145;
					       obj_t arg2012_1146;
					       arg2008_1143 = CNST_TABLE_REF(((long) 10));
					       {
						  obj_t arg2019_1153;
						  arg2019_1153 = CNST_TABLE_REF(((long) 11));
						  {
						     obj_t list2021_1155;
						     {
							obj_t arg2022_1156;
							{
							   obj_t arg2023_1157;
							   arg2023_1157 = MAKE_PAIR(BNIL, BNIL);
							   arg2022_1156 = MAKE_PAIR(len_1062, arg2023_1157);
							}
							list2021_1155 = MAKE_PAIR(runner_1060, arg2022_1156);
						     }
						     arg2010_1144 = cons__138___r4_pairs_and_lists_6_3(arg2019_1153, list2021_1155);
						  }
					       }
					       {
						  obj_t arg2026_1159;
						  obj_t arg2027_1160;
						  arg2026_1159 = CNST_TABLE_REF(((long) 22));
						  arg2027_1160 = CNST_TABLE_REF(((long) 35));
						  {
						     obj_t list2029_1162;
						     {
							obj_t arg2030_1163;
							arg2030_1163 = MAKE_PAIR(BNIL, BNIL);
							list2029_1162 = MAKE_PAIR(arg2027_1160, arg2030_1163);
						     }
						     arg2011_1145 = cons__138___r4_pairs_and_lists_6_3(arg2026_1159, list2029_1162);
						  }
					       }
					       {
						  obj_t arg2032_1165;
						  obj_t arg2033_1166;
						  obj_t arg2035_1167;
						  arg2032_1165 = CNST_TABLE_REF(((long) 12));
						  {
						     obj_t arg2042_1173;
						     obj_t arg2043_1174;
						     arg2042_1173 = CNST_TABLE_REF(((long) 34));
						     {
							obj_t arg2044_1175;
							arg2044_1175 = CNST_TABLE_REF(((long) 36));
							{
							   obj_t list2046_1177;
							   {
							      obj_t arg2047_1178;
							      {
								 obj_t arg2048_1179;
								 arg2048_1179 = MAKE_PAIR(BNIL, BNIL);
								 arg2047_1178 = MAKE_PAIR(runner_1060, arg2048_1179);
							      }
							      list2046_1177 = MAKE_PAIR(v_1061, arg2047_1178);
							   }
							   arg2043_1174 = cons__138___r4_pairs_and_lists_6_3(arg2044_1175, list2046_1177);
							}
						     }
						     arg2033_1166 = make_pragma_indexed_set__175_object_tools(type_82, slot_84, arg2042_1173, arg2043_1174, runner_1060);
						  }
						  {
						     obj_t arg2050_1181;
						     {
							obj_t arg2055_1186;
							arg2055_1186 = CNST_TABLE_REF(((long) 15));
							{
							   obj_t list2058_1189;
							   {
							      obj_t arg2059_1190;
							      {
								 obj_t arg2060_1191;
								 arg2060_1191 = MAKE_PAIR(BNIL, BNIL);
								 {
								    obj_t aux_2585;
								    aux_2585 = BINT(((long) 1));
								    arg2059_1190 = MAKE_PAIR(aux_2585, arg2060_1191);
								 }
							      }
							      list2058_1189 = MAKE_PAIR(runner_1060, arg2059_1190);
							   }
							   arg2050_1181 = cons__138___r4_pairs_and_lists_6_3(arg2055_1186, list2058_1189);
							}
						     }
						     {
							obj_t list2052_1183;
							{
							   obj_t arg2053_1184;
							   arg2053_1184 = MAKE_PAIR(BNIL, BNIL);
							   list2052_1183 = MAKE_PAIR(arg2050_1181, arg2053_1184);
							}
							arg2035_1167 = cons__138___r4_pairs_and_lists_6_3(loop_1059, list2052_1183);
						     }
						  }
						  {
						     obj_t list2038_1169;
						     {
							obj_t arg2039_1170;
							{
							   obj_t arg2040_1171;
							   arg2040_1171 = MAKE_PAIR(BNIL, BNIL);
							   arg2039_1170 = MAKE_PAIR(arg2035_1167, arg2040_1171);
							}
							list2038_1169 = MAKE_PAIR(arg2033_1166, arg2039_1170);
						     }
						     arg2012_1146 = cons__138___r4_pairs_and_lists_6_3(arg2032_1165, list2038_1169);
						  }
					       }
					       {
						  obj_t list2014_1148;
						  {
						     obj_t arg2015_1149;
						     {
							obj_t arg2016_1150;
							{
							   obj_t arg2017_1151;
							   arg2017_1151 = MAKE_PAIR(BNIL, BNIL);
							   arg2016_1150 = MAKE_PAIR(arg2012_1146, arg2017_1151);
							}
							arg2015_1149 = MAKE_PAIR(arg2011_1145, arg2016_1150);
						     }
						     list2014_1148 = MAKE_PAIR(arg2010_1144, arg2015_1149);
						  }
						  arg1995_1134 = cons__138___r4_pairs_and_lists_6_3(arg2008_1143, list2014_1148);
					       }
					    }
					    {
					       obj_t list1999_1136;
					       {
						  obj_t arg2000_1137;
						  {
						     obj_t arg2001_1138;
						     arg2001_1138 = MAKE_PAIR(BNIL, BNIL);
						     arg2000_1137 = MAKE_PAIR(arg1995_1134, arg2001_1138);
						  }
						  list1999_1136 = MAKE_PAIR(arg1994_1133, arg2000_1137);
					       }
					       arg1990_1129 = cons__138___r4_pairs_and_lists_6_3(loop_1059, list1999_1136);
					    }
					 }
					 {
					    obj_t list1992_1131;
					    list1992_1131 = MAKE_PAIR(BNIL, BNIL);
					    arg1983_1122 = cons__138___r4_pairs_and_lists_6_3(arg1990_1129, list1992_1131);
					 }
				      }
				      {
					 obj_t list2064_1195;
					 {
					    obj_t arg2065_1196;
					    arg2065_1196 = MAKE_PAIR(BNIL, BNIL);
					    {
					       obj_t aux_2609;
					       aux_2609 = BINT(((long) 0));
					       list2064_1195 = MAKE_PAIR(aux_2609, arg2065_1196);
					    }
					 }
					 arg1984_1123 = cons__138___r4_pairs_and_lists_6_3(loop_1059, list2064_1195);
				      }
				      {
					 obj_t list1986_1125;
					 {
					    obj_t arg1987_1126;
					    {
					       obj_t arg1988_1127;
					       arg1988_1127 = MAKE_PAIR(BNIL, BNIL);
					       arg1987_1126 = MAKE_PAIR(arg1984_1123, arg1988_1127);
					    }
					    list1986_1125 = MAKE_PAIR(arg1983_1122, arg1987_1126);
					 }
					 arg1949_1092 = cons__138___r4_pairs_and_lists_6_3(arg1982_1121, list1986_1125);
				      }
				   }
				   {
				      obj_t list1951_1094;
				      {
					 obj_t arg1952_1095;
					 {
					    obj_t arg1953_1096;
					    {
					       obj_t arg1954_1097;
					       arg1954_1097 = MAKE_PAIR(BNIL, BNIL);
					       arg1953_1096 = MAKE_PAIR(arg1949_1092, arg1954_1097);
					    }
					    arg1952_1095 = MAKE_PAIR(arg1948_1091, arg1953_1096);
					 }
					 list1951_1094 = MAKE_PAIR(arg1947_1090, arg1952_1095);
				      }
				      arg1921_1067 = cons__138___r4_pairs_and_lists_6_3(arg1945_1089, list1951_1094);
				   }
				}
				{
				   obj_t list1924_1069;
				   {
				      obj_t arg1925_1070;
				      {
					 obj_t arg1927_1071;
					 arg1927_1071 = MAKE_PAIR(BNIL, BNIL);
					 arg1925_1070 = MAKE_PAIR(arg1921_1067, arg1927_1071);
				      }
				      list1924_1069 = MAKE_PAIR(arg1920_1066, arg1925_1070);
				   }
				   return cons__138___r4_pairs_and_lists_6_3(arg1919_1065, list1924_1069);
				}
			     }
			  }
			else
			  {
			     bool_t test_2626;
			     {
				obj_t aux_2627;
				aux_2627 = STRUCT_REF(slot_84, ((long) 3));
				test_2626 = CBOOL(aux_2627);
			     }
			     if (test_2626)
			       {
				  {
				     obj_t arg2069_1199;
				     obj_t arg2070_1200;
				     obj_t arg2071_1201;
				     arg2069_1199 = CNST_TABLE_REF(((long) 6));
				     {
					obj_t arg2077_1207;
					{
					   obj_t arg2081_1211;
					   {
					      obj_t arg2086_1216;
					      obj_t arg2087_1217;
					      arg2086_1216 = CNST_TABLE_REF(((long) 31));
					      arg2087_1217 = CNST_TABLE_REF(((long) 32));
					      {
						 obj_t list2089_1219;
						 {
						    obj_t arg2090_1220;
						    {
						       obj_t arg2091_1221;
						       arg2091_1221 = MAKE_PAIR(BNIL, BNIL);
						       {
							  obj_t aux_2634;
							  aux_2634 = BINT(i_83);
							  arg2090_1220 = MAKE_PAIR(aux_2634, arg2091_1221);
						       }
						    }
						    list2089_1219 = MAKE_PAIR(arg2087_1217, arg2090_1220);
						 }
						 arg2081_1211 = cons__138___r4_pairs_and_lists_6_3(arg2086_1216, list2089_1219);
					      }
					   }
					   {
					      obj_t list2083_1213;
					      {
						 obj_t arg2084_1214;
						 arg2084_1214 = MAKE_PAIR(BNIL, BNIL);
						 list2083_1213 = MAKE_PAIR(arg2081_1211, arg2084_1214);
					      }
					      arg2077_1207 = cons__138___r4_pairs_and_lists_6_3(v_1061, list2083_1213);
					   }
					}
					{
					   obj_t list2079_1209;
					   list2079_1209 = MAKE_PAIR(BNIL, BNIL);
					   arg2070_1200 = cons__138___r4_pairs_and_lists_6_3(arg2077_1207, list2079_1209);
					}
				     }
				     {
					obj_t arg2093_1223;
					obj_t arg2094_1224;
					obj_t arg2095_1225;
					arg2093_1223 = CNST_TABLE_REF(((long) 9));
					{
					   obj_t arg2101_1231;
					   {
					      obj_t arg2106_1235;
					      obj_t arg2107_1236;
					      {
						 obj_t list2115_1243;
						 list2115_1243 = MAKE_PAIR(BNIL, BNIL);
						 arg2106_1235 = cons__138___r4_pairs_and_lists_6_3(runner_typed_89_1063, list2115_1243);
					      }
					      {
						 obj_t arg2117_1245;
						 obj_t arg2120_1246;
						 obj_t arg2121_1247;
						 obj_t arg2122_1248;
						 arg2117_1245 = CNST_TABLE_REF(((long) 10));
						 {
						    obj_t arg2132_1255;
						    obj_t arg2133_1256;
						    arg2132_1255 = CNST_TABLE_REF(((long) 11));
						    {
						       obj_t arg2139_1262;
						       obj_t arg2140_1263;
						       arg2139_1262 = CNST_TABLE_REF(((long) 7));
						       arg2140_1263 = STRUCT_REF(slot_84, ((long) 4));
						       {
							  obj_t list2142_1265;
							  {
							     obj_t arg2143_1266;
							     arg2143_1266 = MAKE_PAIR(BNIL, BNIL);
							     list2142_1265 = MAKE_PAIR(arg2140_1263, arg2143_1266);
							  }
							  arg2133_1256 = cons__138___r4_pairs_and_lists_6_3(arg2139_1262, list2142_1265);
						       }
						    }
						    {
						       obj_t list2135_1258;
						       {
							  obj_t arg2136_1259;
							  {
							     obj_t arg2137_1260;
							     arg2137_1260 = MAKE_PAIR(BNIL, BNIL);
							     arg2136_1259 = MAKE_PAIR(arg2133_1256, arg2137_1260);
							  }
							  list2135_1258 = MAKE_PAIR(runner_1060, arg2136_1259);
						       }
						       arg2120_1246 = cons__138___r4_pairs_and_lists_6_3(arg2132_1255, list2135_1258);
						    }
						 }
						 {
						    obj_t arg2145_1268;
						    obj_t arg2146_1269;
						    arg2145_1268 = CNST_TABLE_REF(((long) 22));
						    arg2146_1269 = CNST_TABLE_REF(((long) 35));
						    {
						       obj_t list2148_1271;
						       {
							  obj_t arg2149_1272;
							  arg2149_1272 = MAKE_PAIR(BNIL, BNIL);
							  list2148_1271 = MAKE_PAIR(arg2146_1269, arg2149_1272);
						       }
						       arg2121_1247 = cons__138___r4_pairs_and_lists_6_3(arg2145_1268, list2148_1271);
						    }
						 }
						 {
						    obj_t arg2151_1274;
						    obj_t arg2152_1275;
						    obj_t arg2153_1276;
						    arg2151_1274 = CNST_TABLE_REF(((long) 12));
						    {
						       obj_t arg2159_1282;
						       obj_t arg2160_1283;
						       arg2159_1282 = CNST_TABLE_REF(((long) 34));
						       {
							  obj_t arg2161_1284;
							  arg2161_1284 = CNST_TABLE_REF(((long) 36));
							  {
							     obj_t list2163_1286;
							     {
								obj_t arg2164_1287;
								{
								   obj_t arg2165_1288;
								   arg2165_1288 = MAKE_PAIR(BNIL, BNIL);
								   arg2164_1287 = MAKE_PAIR(runner_1060, arg2165_1288);
								}
								list2163_1286 = MAKE_PAIR(v_1061, arg2164_1287);
							     }
							     arg2160_1283 = cons__138___r4_pairs_and_lists_6_3(arg2161_1284, list2163_1286);
							  }
						       }
						       arg2152_1275 = make_pragma_indexed_set__175_object_tools(type_82, slot_84, arg2159_1282, arg2160_1283, runner_1060);
						    }
						    {
						       obj_t arg2167_1290;
						       {
							  obj_t arg2174_1295;
							  arg2174_1295 = CNST_TABLE_REF(((long) 15));
							  {
							     obj_t list2177_1298;
							     {
								obj_t arg2178_1299;
								{
								   obj_t arg2179_1300;
								   arg2179_1300 = MAKE_PAIR(BNIL, BNIL);
								   {
								      obj_t aux_2673;
								      aux_2673 = BINT(((long) 1));
								      arg2178_1299 = MAKE_PAIR(aux_2673, arg2179_1300);
								   }
								}
								list2177_1298 = MAKE_PAIR(runner_1060, arg2178_1299);
							     }
							     arg2167_1290 = cons__138___r4_pairs_and_lists_6_3(arg2174_1295, list2177_1298);
							  }
						       }
						       {
							  obj_t list2170_1292;
							  {
							     obj_t arg2172_1293;
							     arg2172_1293 = MAKE_PAIR(BNIL, BNIL);
							     list2170_1292 = MAKE_PAIR(arg2167_1290, arg2172_1293);
							  }
							  arg2153_1276 = cons__138___r4_pairs_and_lists_6_3(loop_1059, list2170_1292);
						       }
						    }
						    {
						       obj_t list2155_1278;
						       {
							  obj_t arg2156_1279;
							  {
							     obj_t arg2157_1280;
							     arg2157_1280 = MAKE_PAIR(BNIL, BNIL);
							     arg2156_1279 = MAKE_PAIR(arg2153_1276, arg2157_1280);
							  }
							  list2155_1278 = MAKE_PAIR(arg2152_1275, arg2156_1279);
						       }
						       arg2122_1248 = cons__138___r4_pairs_and_lists_6_3(arg2151_1274, list2155_1278);
						    }
						 }
						 {
						    obj_t list2124_1250;
						    {
						       obj_t arg2125_1251;
						       {
							  obj_t arg2127_1252;
							  {
							     obj_t arg2129_1253;
							     arg2129_1253 = MAKE_PAIR(BNIL, BNIL);
							     arg2127_1252 = MAKE_PAIR(arg2122_1248, arg2129_1253);
							  }
							  arg2125_1251 = MAKE_PAIR(arg2121_1247, arg2127_1252);
						       }
						       list2124_1250 = MAKE_PAIR(arg2120_1246, arg2125_1251);
						    }
						    arg2107_1236 = cons__138___r4_pairs_and_lists_6_3(arg2117_1245, list2124_1250);
						 }
					      }
					      {
						 obj_t list2109_1238;
						 {
						    obj_t arg2111_1239;
						    {
						       obj_t arg2112_1240;
						       arg2112_1240 = MAKE_PAIR(BNIL, BNIL);
						       arg2111_1239 = MAKE_PAIR(arg2107_1236, arg2112_1240);
						    }
						    list2109_1238 = MAKE_PAIR(arg2106_1235, arg2111_1239);
						 }
						 arg2101_1231 = cons__138___r4_pairs_and_lists_6_3(loop_1059, list2109_1238);
					      }
					   }
					   {
					      obj_t list2103_1233;
					      list2103_1233 = MAKE_PAIR(BNIL, BNIL);
					      arg2094_1224 = cons__138___r4_pairs_and_lists_6_3(arg2101_1231, list2103_1233);
					   }
					}
					{
					   obj_t list2183_1304;
					   {
					      obj_t arg2184_1305;
					      arg2184_1305 = MAKE_PAIR(BNIL, BNIL);
					      {
						 obj_t aux_2697;
						 aux_2697 = BINT(((long) 0));
						 list2183_1304 = MAKE_PAIR(aux_2697, arg2184_1305);
					      }
					   }
					   arg2095_1225 = cons__138___r4_pairs_and_lists_6_3(loop_1059, list2183_1304);
					}
					{
					   obj_t list2097_1227;
					   {
					      obj_t arg2098_1228;
					      {
						 obj_t arg2099_1229;
						 arg2099_1229 = MAKE_PAIR(BNIL, BNIL);
						 arg2098_1228 = MAKE_PAIR(arg2095_1225, arg2099_1229);
					      }
					      list2097_1227 = MAKE_PAIR(arg2094_1224, arg2098_1228);
					   }
					   arg2071_1201 = cons__138___r4_pairs_and_lists_6_3(arg2093_1223, list2097_1227);
					}
				     }
				     {
					obj_t list2073_1203;
					{
					   obj_t arg2074_1204;
					   {
					      obj_t arg2075_1205;
					      arg2075_1205 = MAKE_PAIR(BNIL, BNIL);
					      arg2074_1204 = MAKE_PAIR(arg2071_1201, arg2075_1205);
					   }
					   list2073_1203 = MAKE_PAIR(arg2070_1200, arg2074_1204);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg2069_1199, list2073_1203);
				     }
				  }
			       }
			     else
			       {
				  bool_t test_2709;
				  {
				     obj_t aux_2710;
				     aux_2710 = STRUCT_REF(slot_84, ((long) 11));
				     test_2709 = CBOOL(aux_2710);
				  }
				  if (test_2709)
				    {
				       return BUNSPEC;
				    }
				  else
				    {
				       {
					  obj_t arg2187_1308;
					  obj_t arg2188_1309;
					  obj_t arg2189_1310;
					  arg2187_1308 = CNST_TABLE_REF(((long) 6));
					  {
					     obj_t arg2196_1316;
					     {
						obj_t arg2200_1320;
						obj_t arg2201_1321;
						{
						   obj_t list2207_1327;
						   {
						      obj_t arg2208_1328;
						      {
							 obj_t arg2209_1329;
							 {
							    obj_t aux_2714;
							    {
							       type_t obj_1892;
							       {
								  obj_t aux_2715;
								  aux_2715 = STRUCT_REF(slot_84, ((long) 2));
								  obj_1892 = (type_t) (aux_2715);
							       }
							       aux_2714 = (((type_t) CREF(obj_1892))->id);
							    }
							    arg2209_1329 = MAKE_PAIR(aux_2714, BNIL);
							 }
							 arg2208_1328 = MAKE_PAIR(_4dots_199_tools_misc, arg2209_1329);
						      }
						      list2207_1327 = MAKE_PAIR(v_1061, arg2208_1328);
						   }
						   arg2200_1320 = symbol_append_197___r4_symbols_6_4(list2207_1327);
						}
						{
						   obj_t arg2213_1332;
						   obj_t arg2214_1333;
						   arg2213_1332 = CNST_TABLE_REF(((long) 31));
						   arg2214_1333 = CNST_TABLE_REF(((long) 32));
						   {
						      obj_t list2216_1335;
						      {
							 obj_t arg2217_1336;
							 {
							    obj_t arg2219_1337;
							    arg2219_1337 = MAKE_PAIR(BNIL, BNIL);
							    {
							       obj_t aux_2726;
							       aux_2726 = BINT(i_83);
							       arg2217_1336 = MAKE_PAIR(aux_2726, arg2219_1337);
							    }
							 }
							 list2216_1335 = MAKE_PAIR(arg2214_1333, arg2217_1336);
						      }
						      arg2201_1321 = cons__138___r4_pairs_and_lists_6_3(arg2213_1332, list2216_1335);
						   }
						}
						{
						   obj_t list2203_1323;
						   {
						      obj_t arg2204_1324;
						      arg2204_1324 = MAKE_PAIR(BNIL, BNIL);
						      list2203_1323 = MAKE_PAIR(arg2201_1321, arg2204_1324);
						   }
						   arg2196_1316 = cons__138___r4_pairs_and_lists_6_3(arg2200_1320, list2203_1323);
						}
					     }
					     {
						obj_t list2198_1318;
						list2198_1318 = MAKE_PAIR(BNIL, BNIL);
						arg2188_1309 = cons__138___r4_pairs_and_lists_6_3(arg2196_1316, list2198_1318);
					     }
					  }
					  arg2189_1310 = make_pragma_direct_set__7_object_tools(type_82, slot_84, CNST_TABLE_REF(((long) 34)), v_1061);
					  {
					     obj_t list2191_1312;
					     {
						obj_t arg2192_1313;
						{
						   obj_t arg2193_1314;
						   arg2193_1314 = MAKE_PAIR(BNIL, BNIL);
						   arg2192_1313 = MAKE_PAIR(arg2189_1310, arg2193_1314);
						}
						list2191_1312 = MAKE_PAIR(arg2188_1309, arg2192_1313);
					     }
					     return cons__138___r4_pairs_and_lists_6_3(arg2187_1308, list2191_1312);
					  }
				       }
				    }
			       }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* make-struct->object */ obj_t 
make_struct__object_35_object_struct(obj_t cname_85, type_t type_86, obj_t module_87, obj_t slots_88, obj_t src_def_101_89)
{
   {
      obj_t arg2230_1348;
      {
	 obj_t arg2233_1351;
	 obj_t arg2234_1352;
	 obj_t arg2235_1353;
	 arg2233_1351 = CNST_TABLE_REF(((long) 19));
	 {
	    obj_t arg2241_1359;
	    obj_t arg2243_1360;
	    obj_t arg2244_1361;
	    arg2241_1359 = CNST_TABLE_REF(((long) 37));
	    {
	       obj_t arg2254_1367;
	       arg2254_1367 = CNST_TABLE_REF(((long) 34));
	       {
		  obj_t list2255_1368;
		  {
		     obj_t arg2256_1369;
		     {
			obj_t arg2257_1370;
			arg2257_1370 = MAKE_PAIR(cname_85, BNIL);
			arg2256_1369 = MAKE_PAIR(_4dots_199_tools_misc, arg2257_1370);
		     }
		     list2255_1368 = MAKE_PAIR(arg2254_1367, arg2256_1369);
		  }
		  arg2243_1360 = symbol_append_197___r4_symbols_6_4(list2255_1368);
	       }
	    }
	    arg2244_1361 = CNST_TABLE_REF(((long) 38));
	    {
	       obj_t list2247_1363;
	       {
		  obj_t arg2248_1364;
		  {
		     obj_t arg2250_1365;
		     arg2250_1365 = MAKE_PAIR(BNIL, BNIL);
		     arg2248_1364 = MAKE_PAIR(arg2244_1361, arg2250_1365);
		  }
		  list2247_1363 = MAKE_PAIR(arg2243_1360, arg2248_1364);
	       }
	       arg2234_1352 = cons__138___r4_pairs_and_lists_6_3(arg2241_1359, list2247_1363);
	    }
	 }
	 {
	    obj_t arg2259_1372;
	    obj_t arg2260_1373;
	    obj_t arg2261_1374;
	    arg2259_1372 = CNST_TABLE_REF(((long) 12));
	    {
	       obj_t arg2265_1378;
	       obj_t arg2266_1379;
	       obj_t arg2267_1380;
	       arg2265_1378 = CNST_TABLE_REF(((long) 39));
	       arg2266_1379 = CNST_TABLE_REF(((long) 34));
	       {
		  obj_t arg2273_1386;
		  obj_t arg2274_1387;
		  arg2273_1386 = CNST_TABLE_REF(((long) 31));
		  arg2274_1387 = CNST_TABLE_REF(((long) 32));
		  {
		     obj_t list2277_1390;
		     {
			obj_t arg2278_1391;
			{
			   obj_t arg2279_1392;
			   arg2279_1392 = MAKE_PAIR(BNIL, BNIL);
			   {
			      obj_t aux_2760;
			      aux_2760 = BINT(((long) 0));
			      arg2278_1391 = MAKE_PAIR(aux_2760, arg2279_1392);
			   }
			}
			list2277_1390 = MAKE_PAIR(arg2274_1387, arg2278_1391);
		     }
		     arg2267_1380 = cons__138___r4_pairs_and_lists_6_3(arg2273_1386, list2277_1390);
		  }
	       }
	       {
		  obj_t list2269_1382;
		  {
		     obj_t arg2270_1383;
		     {
			obj_t arg2271_1384;
			arg2271_1384 = MAKE_PAIR(BNIL, BNIL);
			arg2270_1383 = MAKE_PAIR(arg2267_1380, arg2271_1384);
		     }
		     list2269_1382 = MAKE_PAIR(arg2266_1379, arg2270_1383);
		  }
		  arg2260_1373 = cons__138___r4_pairs_and_lists_6_3(arg2265_1378, list2269_1382);
	       }
	    }
	    {
	       obj_t arg2281_1394;
	       obj_t arg2282_1395;
	       {
		  long i_1396;
		  obj_t slots_1397;
		  obj_t res_1398;
		  i_1396 = ((long) 1);
		  slots_1397 = slots_88;
		  res_1398 = BNIL;
		loop_1399:
		  if (NULLP(slots_1397))
		    {
		       arg2281_1394 = reverse__39___r4_pairs_and_lists_6_3(res_1398);
		    }
		  else
		    {
		       bool_t test_2772;
		       {
			  obj_t aux_2773;
			  {
			     obj_t aux_2774;
			     aux_2774 = CAR(slots_1397);
			     aux_2773 = STRUCT_REF(aux_2774, ((long) 11));
			  }
			  test_2772 = CBOOL(aux_2773);
		       }
		       if (test_2772)
			 {
			    {
			       obj_t slots_2780;
			       long i_2778;
			       i_2778 = (i_1396 + ((long) 1));
			       slots_2780 = CDR(slots_1397);
			       slots_1397 = slots_2780;
			       i_1396 = i_2778;
			       goto loop_1399;
			    }
			 }
		       else
			 {
			    {
			       obj_t new_1406;
			       new_1406 = restore_slot_6_object_struct(CNST_TABLE_REF(((long) 34)), CNST_TABLE_REF(((long) 32)), cname_85, type_86, i_1396, CAR(slots_1397));
			       {
				  long arg2289_1407;
				  obj_t arg2291_1408;
				  obj_t arg2292_1409;
				  arg2289_1407 = (i_1396 + ((long) 1));
				  arg2291_1408 = CDR(slots_1397);
				  arg2292_1409 = MAKE_PAIR(new_1406, res_1398);
				  {
				     obj_t res_2791;
				     obj_t slots_2790;
				     long i_2789;
				     i_2789 = arg2289_1407;
				     slots_2790 = arg2291_1408;
				     res_2791 = arg2292_1409;
				     res_1398 = res_2791;
				     slots_1397 = slots_2790;
				     i_1396 = i_2789;
				     goto loop_1399;
				  }
			       }
			    }
			 }
		    }
	       }
	       {
		  obj_t arg2298_1414;
		  arg2298_1414 = CNST_TABLE_REF(((long) 34));
		  {
		     obj_t list2300_1416;
		     list2300_1416 = MAKE_PAIR(BNIL, BNIL);
		     arg2282_1395 = cons__138___r4_pairs_and_lists_6_3(arg2298_1414, list2300_1416);
		  }
	       }
	       arg2261_1374 = append_2_18___r4_pairs_and_lists_6_3(arg2281_1394, arg2282_1395);
	    }
	    {
	       obj_t list2262_1375;
	       {
		  obj_t arg2263_1376;
		  arg2263_1376 = MAKE_PAIR(arg2261_1374, BNIL);
		  list2262_1375 = MAKE_PAIR(arg2260_1373, arg2263_1376);
	       }
	       arg2235_1353 = cons__138___r4_pairs_and_lists_6_3(arg2259_1372, list2262_1375);
	    }
	 }
	 {
	    obj_t list2237_1355;
	    {
	       obj_t arg2238_1356;
	       {
		  obj_t arg2239_1357;
		  arg2239_1357 = MAKE_PAIR(BNIL, BNIL);
		  arg2238_1356 = MAKE_PAIR(arg2235_1353, arg2239_1357);
	       }
	       list2237_1355 = MAKE_PAIR(arg2234_1352, arg2238_1356);
	    }
	    arg2230_1348 = cons__138___r4_pairs_and_lists_6_3(arg2233_1351, list2237_1355);
	 }
      }
      {
	 obj_t list2231_1349;
	 list2231_1349 = MAKE_PAIR(src_def_101_89, BNIL);
	 return epairify_object_struct(arg2230_1348, list2231_1349);
      }
   }
}


/* _make-struct->object */ obj_t 
_make_struct__object_170_object_struct(obj_t env_1980, obj_t cname_1981, obj_t type_1982, obj_t module_1983, obj_t slots_1984, obj_t src_def_101_1985)
{
   return make_struct__object_35_object_struct(cname_1981, (type_t) (type_1982), module_1983, slots_1984, src_def_101_1985);
}


/* make-struct->wide-object */ obj_t 
make_struct__wide_object_7_object_struct(obj_t cname_90, type_t type_91, obj_t module_92, obj_t slots_93, obj_t src_def_101_94)
{
   {
      obj_t old_1418;
      old_1418 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 40)), BEOA);
      {
	 long len_1419;
	 len_1419 = slots_length_21_object_struct(slots_93);
	 {
	    obj_t aux_1420;
	    aux_1420 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 24)), BEOA);
	    {
	       obj_t taux_1421;
	       {
		  obj_t list2480_1595;
		  {
		     obj_t arg2481_1596;
		     {
			obj_t aux_2814;
			aux_2814 = CNST_TABLE_REF(((long) 23));
			arg2481_1596 = MAKE_PAIR(aux_2814, BNIL);
		     }
		     list2480_1595 = MAKE_PAIR(aux_1420, arg2481_1596);
		  }
		  taux_1421 = symbol_append_197___r4_symbols_6_4(list2480_1595);
	       }
	       {
		  obj_t new_1422;
		  new_1422 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 41)), BEOA);
		  {
		     obj_t tid_1423;
		     tid_1423 = (((type_t) CREF(type_91))->id);
		     {
			global_t holder_1424;
			{
			   class_t obj_1908;
			   obj_1908 = (class_t) (type_91);
			   {
			      obj_t aux_2824;
			      {
				 object_t aux_2825;
				 aux_2825 = (object_t) (obj_1908);
				 aux_2824 = OBJECT_WIDENING(aux_2825);
			      }
			      holder_1424 = (((class_t) CREF(aux_2824))->holder);
			   }
			}
			{
			   obj_t widening_1425;
			   {
			      obj_t arg2471_1586;
			      obj_t arg2472_1587;
			      {
				 class_t obj_1909;
				 obj_1909 = (class_t) (type_91);
				 {
				    obj_t aux_2830;
				    {
				       object_t aux_2831;
				       aux_2831 = (object_t) (obj_1909);
				       aux_2830 = OBJECT_WIDENING(aux_2831);
				    }
				    arg2471_1586 = (((class_t) CREF(aux_2830))->widening);
				 }
			      }
			      arg2472_1587 = CNST_TABLE_REF(((long) 1));
			      {
				 obj_t list2474_1589;
				 {
				    obj_t arg2475_1590;
				    {
				       obj_t arg2476_1591;
				       {
					  obj_t aux_2836;
					  aux_2836 = (((type_t) CREF(type_91))->id);
					  arg2476_1591 = MAKE_PAIR(aux_2836, BNIL);
				       }
				       arg2475_1590 = MAKE_PAIR(arg2472_1587, arg2476_1591);
				    }
				    list2474_1589 = MAKE_PAIR(arg2471_1586, arg2475_1590);
				 }
				 widening_1425 = symbol_append_197___r4_symbols_6_4(list2474_1589);
			      }
			   }
			   {
			      {
				 obj_t arg2302_1426;
				 {
				    obj_t arg2305_1429;
				    obj_t arg2306_1430;
				    obj_t arg2307_1431;
				    arg2305_1429 = CNST_TABLE_REF(((long) 19));
				    {
				       obj_t arg2316_1437;
				       obj_t arg2319_1438;
				       obj_t arg2320_1439;
				       arg2316_1437 = CNST_TABLE_REF(((long) 37));
				       {
					  obj_t arg2327_1445;
					  arg2327_1445 = CNST_TABLE_REF(((long) 34));
					  {
					     obj_t list2328_1446;
					     {
						obj_t arg2329_1447;
						{
						   obj_t arg2330_1448;
						   arg2330_1448 = MAKE_PAIR(cname_90, BNIL);
						   arg2329_1447 = MAKE_PAIR(_4dots_199_tools_misc, arg2330_1448);
						}
						list2328_1446 = MAKE_PAIR(arg2327_1445, arg2329_1447);
					     }
					     arg2319_1438 = symbol_append_197___r4_symbols_6_4(list2328_1446);
					  }
				       }
				       arg2320_1439 = CNST_TABLE_REF(((long) 38));
				       {
					  obj_t list2323_1441;
					  {
					     obj_t arg2324_1442;
					     {
						obj_t arg2325_1443;
						arg2325_1443 = MAKE_PAIR(BNIL, BNIL);
						arg2324_1442 = MAKE_PAIR(arg2320_1439, arg2325_1443);
					     }
					     list2323_1441 = MAKE_PAIR(arg2319_1438, arg2324_1442);
					  }
					  arg2306_1430 = cons__138___r4_pairs_and_lists_6_3(arg2316_1437, list2323_1441);
				       }
				    }
				    {
				       obj_t arg2332_1450;
				       obj_t arg2333_1451;
				       obj_t arg2334_1452;
				       arg2332_1450 = CNST_TABLE_REF(((long) 6));
				       {
					  obj_t arg2340_1458;
					  obj_t arg2341_1459;
					  {
					     obj_t arg2346_1464;
					     {
						obj_t arg2351_1469;
						arg2351_1469 = CNST_TABLE_REF(((long) 25));
						{
						   obj_t list2353_1471;
						   list2353_1471 = MAKE_PAIR(BNIL, BNIL);
						   arg2346_1464 = cons__138___r4_pairs_and_lists_6_3(arg2351_1469, list2353_1471);
						}
					     }
					     {
						obj_t list2348_1466;
						{
						   obj_t arg2349_1467;
						   arg2349_1467 = MAKE_PAIR(BNIL, BNIL);
						   list2348_1466 = MAKE_PAIR(arg2346_1464, arg2349_1467);
						}
						arg2340_1458 = cons__138___r4_pairs_and_lists_6_3(old_1418, list2348_1466);
					     }
					  }
					  {
					     obj_t arg2355_1473;
					     {
						obj_t arg2360_1478;
						obj_t arg2361_1479;
						arg2360_1478 = CNST_TABLE_REF(((long) 31));
						arg2361_1479 = CNST_TABLE_REF(((long) 32));
						{
						   obj_t list2365_1482;
						   {
						      obj_t arg2366_1483;
						      {
							 obj_t arg2367_1484;
							 arg2367_1484 = MAKE_PAIR(BNIL, BNIL);
							 {
							    obj_t aux_2864;
							    aux_2864 = BINT(((long) 0));
							    arg2366_1483 = MAKE_PAIR(aux_2864, arg2367_1484);
							 }
						      }
						      list2365_1482 = MAKE_PAIR(arg2361_1479, arg2366_1483);
						   }
						   arg2355_1473 = cons__138___r4_pairs_and_lists_6_3(arg2360_1478, list2365_1482);
						}
					     }
					     {
						obj_t list2357_1475;
						{
						   obj_t arg2358_1476;
						   arg2358_1476 = MAKE_PAIR(BNIL, BNIL);
						   list2357_1475 = MAKE_PAIR(arg2355_1473, arg2358_1476);
						}
						arg2341_1459 = cons__138___r4_pairs_and_lists_6_3(taux_1421, list2357_1475);
					     }
					  }
					  {
					     obj_t list2343_1461;
					     {
						obj_t arg2344_1462;
						arg2344_1462 = MAKE_PAIR(BNIL, BNIL);
						list2343_1461 = MAKE_PAIR(arg2341_1459, arg2344_1462);
					     }
					     arg2333_1451 = cons__138___r4_pairs_and_lists_6_3(arg2340_1458, list2343_1461);
					  }
				       }
				       {
					  obj_t arg2369_1486;
					  obj_t arg2370_1487;
					  obj_t arg2371_1488;
					  obj_t arg2372_1489;
					  arg2369_1486 = CNST_TABLE_REF(((long) 6));
					  {
					     obj_t arg2380_1497;
					     {
						obj_t arg2384_1501;
						obj_t arg2385_1502;
						{
						   obj_t list2391_1507;
						   {
						      obj_t arg2392_1508;
						      {
							 obj_t arg2394_1509;
							 arg2394_1509 = MAKE_PAIR(tid_1423, BNIL);
							 arg2392_1508 = MAKE_PAIR(_4dots_199_tools_misc, arg2394_1509);
						      }
						      list2391_1507 = MAKE_PAIR(new_1422, arg2392_1508);
						   }
						   arg2384_1501 = symbol_append_197___r4_symbols_6_4(list2391_1507);
						}
						{
						   obj_t arg2399_1511;
						   obj_t arg2400_1512;
						   {
						      obj_t arg2406_1518;
						      arg2406_1518 = CNST_TABLE_REF(((long) 42));
						      {
							 obj_t list2407_1519;
							 {
							    obj_t arg2408_1520;
							    {
							       obj_t arg2409_1521;
							       arg2409_1521 = MAKE_PAIR(tid_1423, BNIL);
							       arg2408_1520 = MAKE_PAIR(_4dots_199_tools_misc, arg2409_1521);
							    }
							    list2407_1519 = MAKE_PAIR(arg2406_1518, arg2408_1520);
							 }
							 arg2399_1511 = symbol_append_197___r4_symbols_6_4(list2407_1519);
						      }
						   }
						   {
						      obj_t arg2412_1524;
						      arg2412_1524 = (((type_t) CREF(type_91))->name);
						      {
							 obj_t list2414_1526;
							 {
							    obj_t arg2415_1527;
							    {
							       obj_t arg2416_1528;
							       arg2416_1528 = MAKE_PAIR(string2527_object_struct, BNIL);
							       arg2415_1527 = MAKE_PAIR(arg2412_1524, arg2416_1528);
							    }
							    list2414_1526 = MAKE_PAIR(string2528_object_struct, arg2415_1527);
							 }
							 arg2400_1512 = string_append_106___r4_strings_6_7(list2414_1526);
						      }
						   }
						   {
						      obj_t list2402_1514;
						      {
							 obj_t arg2403_1515;
							 {
							    obj_t arg2404_1516;
							    arg2404_1516 = MAKE_PAIR(BNIL, BNIL);
							    arg2403_1515 = MAKE_PAIR(old_1418, arg2404_1516);
							 }
							 list2402_1514 = MAKE_PAIR(arg2400_1512, arg2403_1515);
						      }
						      arg2385_1502 = cons__138___r4_pairs_and_lists_6_3(arg2399_1511, list2402_1514);
						   }
						}
						{
						   obj_t list2387_1504;
						   {
						      obj_t arg2388_1505;
						      arg2388_1505 = MAKE_PAIR(BNIL, BNIL);
						      list2387_1504 = MAKE_PAIR(arg2385_1502, arg2388_1505);
						   }
						   arg2380_1497 = cons__138___r4_pairs_and_lists_6_3(arg2384_1501, list2387_1504);
						}
					     }
					     {
						obj_t list2382_1499;
						list2382_1499 = MAKE_PAIR(BNIL, BNIL);
						arg2370_1487 = cons__138___r4_pairs_and_lists_6_3(arg2380_1497, list2382_1499);
					     }
					  }
					  {
					     obj_t arg2418_1530;
					     obj_t arg2419_1531;
					     arg2418_1530 = CNST_TABLE_REF(((long) 43));
					     {
						obj_t arg2425_1537;
						obj_t arg2426_1538;
						arg2425_1537 = CNST_TABLE_REF(((long) 44));
						{
						   obj_t arg2431_1543;
						   obj_t arg2432_1544;
						   obj_t arg2433_1545;
						   arg2431_1543 = CNST_TABLE_REF(((long) 45));
						   arg2432_1544 = (((global_t) CREF(holder_1424))->id);
						   arg2433_1545 = (((global_t) CREF(holder_1424))->module);
						   {
						      obj_t list2435_1547;
						      {
							 obj_t arg2436_1548;
							 {
							    obj_t arg2437_1549;
							    arg2437_1549 = MAKE_PAIR(BNIL, BNIL);
							    arg2436_1548 = MAKE_PAIR(arg2433_1545, arg2437_1549);
							 }
							 list2435_1547 = MAKE_PAIR(arg2432_1544, arg2436_1548);
						      }
						      arg2426_1538 = cons__138___r4_pairs_and_lists_6_3(arg2431_1543, list2435_1547);
						   }
						}
						{
						   obj_t list2428_1540;
						   {
						      obj_t arg2429_1541;
						      arg2429_1541 = MAKE_PAIR(BNIL, BNIL);
						      list2428_1540 = MAKE_PAIR(arg2426_1538, arg2429_1541);
						   }
						   arg2419_1531 = cons__138___r4_pairs_and_lists_6_3(arg2425_1537, list2428_1540);
						}
					     }
					     {
						obj_t list2421_1533;
						{
						   obj_t arg2422_1534;
						   {
						      obj_t arg2423_1535;
						      arg2423_1535 = MAKE_PAIR(BNIL, BNIL);
						      arg2422_1534 = MAKE_PAIR(arg2419_1531, arg2423_1535);
						   }
						   list2421_1533 = MAKE_PAIR(new_1422, arg2422_1534);
						}
						arg2371_1488 = cons__138___r4_pairs_and_lists_6_3(arg2418_1530, list2421_1533);
					     }
					  }
					  {
					     obj_t arg2439_1551;
					     obj_t arg2440_1552;
					     arg2439_1551 = CNST_TABLE_REF(((long) 39));
					     {
						obj_t arg2446_1558;
						{
						   obj_t arg2449_1561;
						   obj_t arg2450_1562;
						   {
						      long i_1563;
						      obj_t slots_1564;
						      obj_t ref__130_1565;
						      i_1563 = ((long) 0);
						      slots_1564 = slots_93;
						      ref__130_1565 = BNIL;
						    loop_1566:
						      if ((i_1563 == len_1419))
							{
							   arg2449_1561 = reverse__39___r4_pairs_and_lists_6_3(ref__130_1565);
							}
						      else
							{
							   bool_t test_2919;
							   {
							      obj_t aux_2920;
							      {
								 obj_t aux_2921;
								 aux_2921 = CAR(slots_1564);
								 aux_2920 = STRUCT_REF(aux_2921, ((long) 11));
							      }
							      test_2919 = CBOOL(aux_2920);
							   }
							   if (test_2919)
							     {
								{
								   obj_t slots_2927;
								   long i_2925;
								   i_2925 = (i_1563 + ((long) 1));
								   slots_2927 = CDR(slots_1564);
								   slots_1564 = slots_2927;
								   i_1563 = i_2925;
								   goto loop_1566;
								}
							     }
							   else
							     {
								{
								   long arg2457_1573;
								   obj_t arg2458_1574;
								   obj_t arg2459_1575;
								   arg2457_1573 = (i_1563 + ((long) 1));
								   arg2458_1574 = CDR(slots_1564);
								   {
								      obj_t arg2460_1576;
								      {
									 obj_t arg2461_1577;
									 arg2461_1577 = CNST_TABLE_REF(((long) 31));
									 {
									    obj_t list2464_1579;
									    {
									       obj_t arg2465_1580;
									       {
										  obj_t arg2466_1581;
										  arg2466_1581 = MAKE_PAIR(BNIL, BNIL);
										  {
										     obj_t aux_2933;
										     aux_2933 = BINT(i_1563);
										     arg2465_1580 = MAKE_PAIR(aux_2933, arg2466_1581);
										  }
									       }
									       list2464_1579 = MAKE_PAIR(aux_1420, arg2465_1580);
									    }
									    arg2460_1576 = cons__138___r4_pairs_and_lists_6_3(arg2461_1577, list2464_1579);
									 }
								      }
								      arg2459_1575 = MAKE_PAIR(arg2460_1576, ref__130_1565);
								   }
								   {
								      obj_t ref__130_2941;
								      obj_t slots_2940;
								      long i_2939;
								      i_2939 = arg2457_1573;
								      slots_2940 = arg2458_1574;
								      ref__130_2941 = arg2459_1575;
								      ref__130_1565 = ref__130_2941;
								      slots_1564 = slots_2940;
								      i_1563 = i_2939;
								      goto loop_1566;
								   }
								}
							     }
							}
						   }
						   arg2450_1562 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						   arg2446_1558 = append_2_18___r4_pairs_and_lists_6_3(arg2449_1561, arg2450_1562);
						}
						{
						   obj_t list2447_1559;
						   list2447_1559 = MAKE_PAIR(arg2446_1558, BNIL);
						   arg2440_1552 = cons__138___r4_pairs_and_lists_6_3(widening_1425, list2447_1559);
						}
					     }
					     {
						obj_t list2442_1554;
						{
						   obj_t arg2443_1555;
						   {
						      obj_t arg2444_1556;
						      arg2444_1556 = MAKE_PAIR(BNIL, BNIL);
						      arg2443_1555 = MAKE_PAIR(arg2440_1552, arg2444_1556);
						   }
						   list2442_1554 = MAKE_PAIR(new_1422, arg2443_1555);
						}
						arg2372_1489 = cons__138___r4_pairs_and_lists_6_3(arg2439_1551, list2442_1554);
					     }
					  }
					  {
					     obj_t list2374_1491;
					     {
						obj_t arg2375_1492;
						{
						   obj_t arg2376_1493;
						   {
						      obj_t arg2377_1494;
						      {
							 obj_t arg2378_1495;
							 arg2378_1495 = MAKE_PAIR(BNIL, BNIL);
							 arg2377_1494 = MAKE_PAIR(new_1422, arg2378_1495);
						      }
						      arg2376_1493 = MAKE_PAIR(arg2372_1489, arg2377_1494);
						   }
						   arg2375_1492 = MAKE_PAIR(arg2371_1488, arg2376_1493);
						}
						list2374_1491 = MAKE_PAIR(arg2370_1487, arg2375_1492);
					     }
					     arg2334_1452 = cons__138___r4_pairs_and_lists_6_3(arg2369_1486, list2374_1491);
					  }
				       }
				       {
					  obj_t list2336_1454;
					  {
					     obj_t arg2337_1455;
					     {
						obj_t arg2338_1456;
						arg2338_1456 = MAKE_PAIR(BNIL, BNIL);
						arg2337_1455 = MAKE_PAIR(arg2334_1452, arg2338_1456);
					     }
					     list2336_1454 = MAKE_PAIR(arg2333_1451, arg2337_1455);
					  }
					  arg2307_1431 = cons__138___r4_pairs_and_lists_6_3(arg2332_1450, list2336_1454);
				       }
				    }
				    {
				       obj_t list2309_1433;
				       {
					  obj_t arg2310_1434;
					  {
					     obj_t arg2311_1435;
					     arg2311_1435 = MAKE_PAIR(BNIL, BNIL);
					     arg2310_1434 = MAKE_PAIR(arg2307_1431, arg2311_1435);
					  }
					  list2309_1433 = MAKE_PAIR(arg2306_1430, arg2310_1434);
				       }
				       arg2302_1426 = cons__138___r4_pairs_and_lists_6_3(arg2305_1429, list2309_1433);
				    }
				 }
				 {
				    obj_t list2303_1427;
				    list2303_1427 = MAKE_PAIR(src_def_101_94, BNIL);
				    return epairify_object_struct(arg2302_1426, list2303_1427);
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _make-struct->wide-object */ obj_t 
_make_struct__wide_object_21_object_struct(obj_t env_1986, obj_t cname_1987, obj_t type_1988, obj_t module_1989, obj_t slots_1990, obj_t src_def_101_1991)
{
   return make_struct__wide_object_7_object_struct(cname_1987, (type_t) (type_1988), module_1989, slots_1990, src_def_101_1991);
}


/* epairify */ obj_t 
epairify_object_struct(obj_t def_95, obj_t srcs_96)
{
   {
      obj_t srcs_1600;
      srcs_1600 = srcs_96;
    loop_1601:
      if (NULLP(srcs_1600))
	{
	   return def_95;
	}
      else
	{
	   bool_t test2487_1603;
	   {
	      obj_t aux_2970;
	      aux_2970 = CAR(srcs_1600);
	      test2487_1603 = EXTENDED_PAIRP(aux_2970);
	   }
	   if (test2487_1603)
	     {
		{
		   obj_t arg2488_1604;
		   obj_t arg2489_1605;
		   obj_t arg2490_1606;
		   arg2488_1604 = CAR(def_95);
		   arg2489_1605 = CDR(def_95);
		   {
		      obj_t arg2491_1607;
		      arg2491_1607 = CAR(srcs_1600);
		      {
			 bool_t test1137_1935;
			 test1137_1935 = EXTENDED_PAIRP(arg2491_1607);
			 if (test1137_1935)
			   {
			      arg2490_1606 = CER(arg2491_1607);
			   }
			 else
			   {
			      FAILURE(string2529_object_struct, string2530_object_struct, arg2491_1607);
			   }
		      }
		   }
		   return MAKE_EXTENDED_PAIR(arg2488_1604, arg2489_1605, arg2490_1606);
		}
	     }
	   else
	     {
		{
		   obj_t srcs_2982;
		   srcs_2982 = CDR(srcs_1600);
		   srcs_1600 = srcs_2982;
		   goto loop_1601;
		}
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_object_struct()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_struct()
{
   module_initialization_70_tools_error(((long) 0), "OBJECT_STRUCT");
   module_initialization_70_tools_misc(((long) 0), "OBJECT_STRUCT");
   module_initialization_70_type_type(((long) 0), "OBJECT_STRUCT");
   module_initialization_70_type_env(((long) 0), "OBJECT_STRUCT");
   module_initialization_70_type_cache(((long) 0), "OBJECT_STRUCT");
   module_initialization_70_type_tools(((long) 0), "OBJECT_STRUCT");
   module_initialization_70_ast_var(((long) 0), "OBJECT_STRUCT");
   module_initialization_70_ast_env(((long) 0), "OBJECT_STRUCT");
   module_initialization_70_engine_param(((long) 0), "OBJECT_STRUCT");
   module_initialization_70_object_class(((long) 0), "OBJECT_STRUCT");
   return module_initialization_70_object_tools(((long) 0), "OBJECT_STRUCT");
}
