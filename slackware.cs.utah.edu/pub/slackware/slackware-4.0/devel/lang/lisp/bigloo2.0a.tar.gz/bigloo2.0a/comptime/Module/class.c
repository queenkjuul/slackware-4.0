/*===========================================================================*/
/*   (Module/class.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_module_class();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t _optim__89_engine_param;
extern obj_t string_append(obj_t, obj_t);
extern obj_t class_finalizer_253_module_class();
extern obj_t type_type_type;
extern obj_t _reflection___104_engine_param;
extern obj_t id_of_id_112_ast_ident(obj_t);
static obj_t make_class_fields_146_module_class(obj_t, obj_t);
static obj_t _declare_class_1930_125_module_class(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t fast_id_of_id_130_ast_ident(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t get_object_unit_72_module_class();
extern type_t declare_class_type__110_object_class(obj_t, global_t, obj_t, bool_t, obj_t);
extern obj_t module_initialization_70_module_class(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_impuse(long, char *);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_object_plain_access_186(long, char *);
extern obj_t module_initialization_70_object_wide_access_168(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
static obj_t _class_finalizer_205_module_class(obj_t);
static obj_t _declare_wide_class_1931_69_module_class(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t make_slot_field_56_module_class(obj_t, obj_t);
extern long get_hash_power_number(char *, long);
static obj_t imported_modules_init_94_module_class();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t _get_class_hash1932_177_module_class(obj_t, obj_t, obj_t);
static obj_t _get_object_unit_43_module_class(obj_t);
extern obj_t import_wide_class_accessors__236_object_wide_access_168(obj_t, type_t, obj_t, obj_t);
extern obj_t get_method_unit_151_module_class();
static obj_t _declared_classes__217_module_class = BUNSPEC;
static obj_t force_class_accesses_39_module_class();
extern obj_t produce_module_clause__172_module_module(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t import_parser_53_module_impuse(obj_t, obj_t);
static obj_t library_modules_init_112_module_class();
static obj_t toplevel_init_63_module_class();
extern obj_t open_input_string(obj_t);
static obj_t _object_unit__229_module_class = BUNSPEC;
static obj_t _method_unit__121_module_class = BUNSPEC;
extern obj_t class_object_class;
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
static obj_t _get_method_unit_29_module_class(obj_t);
extern obj_t string_to_bstring(char *);
static obj_t _class_accesses__244_module_class = BUNSPEC;
extern obj_t make_promise_21___r4_control_features_6_9(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t get_class_hash_100_module_class(obj_t, obj_t);
extern obj_t declare_class__31_module_class(obj_t, obj_t, obj_t, bool_t, obj_t);
static obj_t make_add_class__155_module_class(obj_t, type_t, obj_t);
extern obj_t make_plain_class_accessors__206_object_plain_access_186(obj_t, type_t, obj_t, obj_t);
static obj_t arg1299_module_class(obj_t);
static obj_t arg1295_module_class(obj_t);
static obj_t arg1302_module_class(obj_t);
static obj_t arg1272_module_class(obj_t);
static obj_t arg1268_module_class(obj_t);
static obj_t arg1263_module_class(obj_t);
extern obj_t import_plain_class_accessors__109_object_plain_access_186(obj_t, type_t, obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t make_wide_class_accessors__22_object_wide_access_168(obj_t, type_t, obj_t, obj_t);
static bool_t read_only__11_module_class(obj_t);
extern obj_t declare_wide_class__13_module_class(obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_module_class = BUNSPEC;
static obj_t cnst_init_137_module_class();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[26];

DEFINE_EXPORT_PROCEDURE(declare_class__env_99_module_class, _declare_class_1930_125_module_class1943, _declare_class_1930_125_module_class, 0L, 5);
DEFINE_EXPORT_PROCEDURE(declare_wide_class__env_34_module_class, _declare_wide_class_1931_69_module_class1944, _declare_wide_class_1931_69_module_class, 0L, 4);
DEFINE_EXPORT_PROCEDURE(get_object_unit_env_13_module_class, _get_object_unit_43_module_class1945, _get_object_unit_43_module_class, 0L, 0);
DEFINE_EXPORT_PROCEDURE(get_class_hash_env_189_module_class, _get_class_hash1932_177_module_class1946, _get_class_hash1932_177_module_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_finalizer_env_31_module_class, _class_finalizer_205_module_class1947, _class_finalizer_205_module_class, 0L, 0);
DEFINE_EXPORT_PROCEDURE(get_method_unit_env_101_module_class, _get_method_unit_29_module_class1948, _get_method_unit_29_module_class, 0L, 0);
DEFINE_STRING(string1937_module_class, string1937_module_class1949, "METHOD UNIT (#unspecified) VOID -LEN PRAGMA::LONG OBJECT LAMBDA -REF -SET! - VECTOR (READ-ONLY) LIST + * QUOTE __OBJECT ADD-CLASS! DEFINE @ ALLOCATE- WIDENING (EXPORT STATIC) USE IMPORT ", 186);
DEFINE_STRING(string1936_module_class, string1936_module_class1950, "Illegal slot definition", 23);
DEFINE_STRING(string1935_module_class, string1935_module_class1951, "make-class-fields", 17);
DEFINE_STRING(string1934_module_class, string1934_module_class1952, "+ ", 2);
DEFINE_STRING(string1933_module_class, string1933_module_class1953, "* ", 2);


/* module-initialization */ obj_t 
module_initialization_70_module_class(long checksum_1816, char *from_1817)
{
   if (CBOOL(require_initialization_114_module_class))
     {
	require_initialization_114_module_class = BBOOL(((bool_t) 0));
	library_modules_init_112_module_class();
	cnst_init_137_module_class();
	imported_modules_init_94_module_class();
	method_init_76_module_class();
	toplevel_init_63_module_class();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_class()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "MODULE_CLASS");
   module_initialization_70___object(((long) 0), "MODULE_CLASS");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_CLASS");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_CLASS");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "MODULE_CLASS");
   module_initialization_70___r4_control_features_6_9(((long) 0), "MODULE_CLASS");
   module_initialization_70___reader(((long) 0), "MODULE_CLASS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_class()
{
   {
      obj_t cnst_port_138_1808;
      cnst_port_138_1808 = open_input_string(string1937_module_class);
      {
	 long i_1809;
	 i_1809 = ((long) 25);
       loop_1810:
	 {
	    bool_t test1938_1811;
	    test1938_1811 = (i_1809 == ((long) -1));
	    if (test1938_1811)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1939_1812;
		    {
		       obj_t list1940_1813;
		       {
			  obj_t arg1941_1814;
			  arg1941_1814 = BNIL;
			  list1940_1813 = MAKE_PAIR(cnst_port_138_1808, arg1941_1814);
		       }
		       arg1939_1812 = read___reader(list1940_1813);
		    }
		    CNST_TABLE_SET(i_1809, arg1939_1812);
		 }
		 {
		    int aux_1815;
		    {
		       long aux_1839;
		       aux_1839 = (i_1809 - ((long) 1));
		       aux_1815 = (int) (aux_1839);
		    }
		    {
		       long i_1842;
		       i_1842 = (long) (aux_1815);
		       i_1809 = i_1842;
		       goto loop_1810;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_class()
{
   _object_unit__229_module_class = BUNSPEC;
   _method_unit__121_module_class = BUNSPEC;
   _class_accesses__244_module_class = BNIL;
   return (_declared_classes__217_module_class = BNIL,
      BUNSPEC);
}


/* get-object-unit */ obj_t 
get_object_unit_72_module_class()
{
   return _object_unit__229_module_class;
}


/* _get-object-unit */ obj_t 
_get_object_unit_43_module_class(obj_t env_1752)
{
   return get_object_unit_72_module_class();
}


/* get-method-unit */ obj_t 
get_method_unit_151_module_class()
{
   return _method_unit__121_module_class;
}


/* _get-method-unit */ obj_t 
_get_method_unit_29_module_class(obj_t env_1753)
{
   return get_method_unit_151_module_class();
}


/* declare-class! */ obj_t 
declare_class__31_module_class(obj_t class_def_12_81, obj_t module_82, obj_t import_83, bool_t final__12_84, obj_t src_def_101_85)
{
   {
      obj_t class_id_86_519;
      class_id_86_519 = id_of_id_112_ast_ident(CAR(class_def_12_81));
      {
	 obj_t holder_520;
	 {
	    bool_t test_1848;
	    {
	       bool_t test_1849;
	       {
		  obj_t aux_1850;
		  aux_1850 = CNST_TABLE_REF(((long) 0));
		  test_1849 = (import_83 == aux_1850);
	       }
	       if (test_1849)
		 {
		    test_1848 = ((bool_t) 1);
		 }
	       else
		 {
		    obj_t aux_1853;
		    aux_1853 = CNST_TABLE_REF(((long) 1));
		    test_1848 = (import_83 == aux_1853);
		 }
	    }
	    if (test_1848)
	      {
		 holder_520 = import_parser_53_module_impuse(module_82, class_id_86_519);
	      }
	    else
	      {
		 {
		    obj_t arg1281_540;
		    {
		       obj_t list1283_542;
		       {
			  obj_t arg1284_543;
			  arg1284_543 = MAKE_PAIR(BNIL, BNIL);
			  list1283_542 = MAKE_PAIR(class_id_86_519, arg1284_543);
		       }
		       arg1281_540 = cons__138___r4_pairs_and_lists_6_3(import_83, list1283_542);
		    }
		    produce_module_clause__172_module_module(arg1281_540);
		 }
		 {
		    obj_t list1286_545;
		    list1286_545 = MAKE_PAIR(module_82, BNIL);
		    holder_520 = find_global_223_ast_env(class_id_86_519, list1286_545);
		 }
	      }
	 }
	 {
	    type_t type_521;
	    type_521 = declare_class_type__110_object_class(class_def_12_81, (global_t) (holder_520), BFALSE, final__12_84, src_def_101_85);
	    {
	       {
		  bool_t test1260_522;
		  test1260_522 = is_a__118___object((obj_t) (type_521), class_object_class);
		  if (test1260_522)
		    {
		       {
			  bool_t test_1868;
			  {
			     obj_t aux_1869;
			     aux_1869 = memq___r4_pairs_and_lists_6_3(import_83, CNST_TABLE_REF(((long) 2)));
			     test_1868 = CBOOL(aux_1869);
			  }
			  if (test_1868)
			    {
			       make_add_class__155_module_class(holder_520, type_521, src_def_101_85);
			       {
				  obj_t arg1262_524;
				  {
				     obj_t arg1263_1754;
				     arg1263_1754 = make_fx_procedure(arg1263_module_class, ((long) 0), ((long) 4));
				     PROCEDURE_SET(arg1263_1754, ((long) 0), class_def_12_81);
				     {
					obj_t aux_1876;
					aux_1876 = (obj_t) (type_521);
					PROCEDURE_SET(arg1263_1754, ((long) 1), aux_1876);
				     }
				     PROCEDURE_SET(arg1263_1754, ((long) 2), src_def_101_85);
				     PROCEDURE_SET(arg1263_1754, ((long) 3), import_83);
				     arg1262_524 = make_promise_21___r4_control_features_6_9(arg1263_1754);
				  }
				  {
				     obj_t arg1323_1402;
				     {
					obj_t aux_1882;
					aux_1882 = (obj_t) (type_521);
					arg1323_1402 = MAKE_PAIR(aux_1882, arg1262_524);
				     }
				     {
					obj_t obj2_1406;
					obj2_1406 = _class_accesses__244_module_class;
					_class_accesses__244_module_class = MAKE_PAIR(arg1323_1402, obj2_1406);
				     }
				  }
			       }
			    }
			  else
			    {
			       bool_t test1265_528;
			       {
				  bool_t test1274_537;
				  {
				     long n1_1407;
				     n1_1407 = (long) CINT(_optim__89_engine_param);
				     test1274_537 = (n1_1407 >= ((long) 2));
				  }
				  if (test1274_537)
				    {
				       long n1_1409;
				       n1_1409 = (long) CINT(_bdb_debug__1_engine_param);
				       test1265_528 = (n1_1409 <= ((long) 0));
				    }
				  else
				    {
				       test1265_528 = ((bool_t) 0);
				    }
			       }
			       if (test1265_528)
				 {
				    {
				       obj_t arg1267_529;
				       {
					  obj_t arg1268_1755;
					  arg1268_1755 = make_fx_procedure(arg1268_module_class, ((long) 0), ((long) 4));
					  PROCEDURE_SET(arg1268_1755, ((long) 0), class_def_12_81);
					  {
					     obj_t aux_1894;
					     aux_1894 = (obj_t) (type_521);
					     PROCEDURE_SET(arg1268_1755, ((long) 1), aux_1894);
					  }
					  PROCEDURE_SET(arg1268_1755, ((long) 2), src_def_101_85);
					  PROCEDURE_SET(arg1268_1755, ((long) 3), import_83);
					  arg1267_529 = make_promise_21___r4_control_features_6_9(arg1268_1755);
				       }
				       {
					  obj_t arg1323_1413;
					  {
					     obj_t aux_1900;
					     aux_1900 = (obj_t) (type_521);
					     arg1323_1413 = MAKE_PAIR(aux_1900, arg1267_529);
					  }
					  {
					     obj_t obj2_1417;
					     obj2_1417 = _class_accesses__244_module_class;
					     _class_accesses__244_module_class = MAKE_PAIR(arg1323_1413, obj2_1417);
					  }
				       }
				    }
				 }
			       else
				 {
				    {
				       obj_t arg1270_533;
				       {
					  obj_t arg1272_1756;
					  arg1272_1756 = make_fx_procedure(arg1272_module_class, ((long) 0), ((long) 4));
					  PROCEDURE_SET(arg1272_1756, ((long) 0), class_def_12_81);
					  {
					     obj_t aux_1906;
					     aux_1906 = (obj_t) (type_521);
					     PROCEDURE_SET(arg1272_1756, ((long) 1), aux_1906);
					  }
					  PROCEDURE_SET(arg1272_1756, ((long) 2), src_def_101_85);
					  PROCEDURE_SET(arg1272_1756, ((long) 3), module_82);
					  arg1270_533 = make_promise_21___r4_control_features_6_9(arg1272_1756);
				       }
				       {
					  obj_t arg1323_1420;
					  {
					     obj_t aux_1912;
					     aux_1912 = (obj_t) (type_521);
					     arg1323_1420 = MAKE_PAIR(aux_1912, arg1270_533);
					  }
					  {
					     obj_t obj2_1424;
					     obj2_1424 = _class_accesses__244_module_class;
					     _class_accesses__244_module_class = MAKE_PAIR(arg1323_1420, obj2_1424);
					  }
				       }
				    }
				 }
			    }
		       }
		       return (obj_t) (type_521);
		    }
		  else
		    {
		       return BUNSPEC;
		    }
	       }
	    }
	 }
      }
   }
}


/* _declare-class!1930 */ obj_t 
_declare_class_1930_125_module_class(obj_t env_1757, obj_t class_def_12_1758, obj_t module_1759, obj_t import_1760, obj_t final__12_1761, obj_t src_def_101_1762)
{
   return declare_class__31_module_class(class_def_12_1758, module_1759, import_1760, CBOOL(final__12_1761), src_def_101_1762);
}


/* arg1263 */ obj_t 
arg1263_module_class(obj_t env_1763)
{
   {
      obj_t class_def_12_1764;
      obj_t type_1765;
      obj_t src_def_101_1766;
      obj_t import_1767;
      class_def_12_1764 = PROCEDURE_REF(env_1763, ((long) 0));
      type_1765 = PROCEDURE_REF(env_1763, ((long) 1));
      src_def_101_1766 = PROCEDURE_REF(env_1763, ((long) 2));
      import_1767 = PROCEDURE_REF(env_1763, ((long) 3));
      {
	 return make_plain_class_accessors__206_object_plain_access_186(class_def_12_1764, (type_t) (type_1765), src_def_101_1766, import_1767);
      }
   }
}


/* arg1268 */ obj_t 
arg1268_module_class(obj_t env_1768)
{
   {
      obj_t class_def_12_1769;
      obj_t type_1770;
      obj_t src_def_101_1771;
      obj_t import_1772;
      class_def_12_1769 = PROCEDURE_REF(env_1768, ((long) 0));
      type_1770 = PROCEDURE_REF(env_1768, ((long) 1));
      src_def_101_1771 = PROCEDURE_REF(env_1768, ((long) 2));
      import_1772 = PROCEDURE_REF(env_1768, ((long) 3));
      {
	 return make_plain_class_accessors__206_object_plain_access_186(class_def_12_1769, (type_t) (type_1770), src_def_101_1771, import_1772);
      }
   }
}


/* arg1272 */ obj_t 
arg1272_module_class(obj_t env_1773)
{
   {
      obj_t class_def_12_1774;
      obj_t type_1775;
      obj_t src_def_101_1776;
      obj_t module_1777;
      class_def_12_1774 = PROCEDURE_REF(env_1773, ((long) 0));
      type_1775 = PROCEDURE_REF(env_1773, ((long) 1));
      src_def_101_1776 = PROCEDURE_REF(env_1773, ((long) 2));
      module_1777 = PROCEDURE_REF(env_1773, ((long) 3));
      {
	 return import_plain_class_accessors__109_object_plain_access_186(class_def_12_1774, (type_t) (type_1775), src_def_101_1776, module_1777);
      }
   }
}


/* declare-wide-class! */ obj_t 
declare_wide_class__13_module_class(obj_t class_def_12_86, obj_t module_87, obj_t import_88, obj_t src_def_101_89)
{
   {
      obj_t class_id_86_551;
      class_id_86_551 = id_of_id_112_ast_ident(CAR(class_def_12_86));
      {
	 obj_t holder_552;
	 {
	    bool_t test_1939;
	    {
	       bool_t test_1940;
	       {
		  obj_t aux_1941;
		  aux_1941 = CNST_TABLE_REF(((long) 0));
		  test_1940 = (import_88 == aux_1941);
	       }
	       if (test_1940)
		 {
		    test_1939 = ((bool_t) 1);
		 }
	       else
		 {
		    obj_t aux_1944;
		    aux_1944 = CNST_TABLE_REF(((long) 1));
		    test_1939 = (import_88 == aux_1944);
		 }
	    }
	    if (test_1939)
	      {
		 holder_552 = import_parser_53_module_impuse(module_87, class_id_86_551);
	      }
	    else
	      {
		 {
		    obj_t arg1311_574;
		    {
		       obj_t list1314_576;
		       {
			  obj_t arg1315_577;
			  arg1315_577 = MAKE_PAIR(BNIL, BNIL);
			  list1314_576 = MAKE_PAIR(class_id_86_551, arg1315_577);
		       }
		       arg1311_574 = cons__138___r4_pairs_and_lists_6_3(import_88, list1314_576);
		    }
		    produce_module_clause__172_module_module(arg1311_574);
		 }
		 {
		    obj_t list1317_579;
		    list1317_579 = MAKE_PAIR(module_87, BNIL);
		    holder_552 = find_global_223_ast_env(class_id_86_551, list1317_579);
		 }
	      }
	 }
	 {
	    type_t type_553;
	    {
	       obj_t arg1308_571;
	       arg1308_571 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 3)), BEOA);
	       type_553 = declare_class_type__110_object_class(class_def_12_86, (global_t) (holder_552), arg1308_571, ((bool_t) 0), src_def_101_89);
	    }
	    {
	       {
		  bool_t test1292_554;
		  test1292_554 = is_a__118___object((obj_t) (type_553), class_object_class);
		  if (test1292_554)
		    {
		       bool_t test_1962;
		       {
			  obj_t aux_1963;
			  aux_1963 = memq___r4_pairs_and_lists_6_3(import_88, CNST_TABLE_REF(((long) 2)));
			  test_1962 = CBOOL(aux_1963);
		       }
		       if (test_1962)
			 {
			    make_add_class__155_module_class(holder_552, type_553, src_def_101_89);
			    {
			       obj_t arg1294_556;
			       {
				  obj_t arg1295_1778;
				  arg1295_1778 = make_fx_procedure(arg1295_module_class, ((long) 0), ((long) 4));
				  PROCEDURE_SET(arg1295_1778, ((long) 0), class_def_12_86);
				  {
				     obj_t aux_1970;
				     aux_1970 = (obj_t) (type_553);
				     PROCEDURE_SET(arg1295_1778, ((long) 1), aux_1970);
				  }
				  PROCEDURE_SET(arg1295_1778, ((long) 2), src_def_101_89);
				  PROCEDURE_SET(arg1295_1778, ((long) 3), import_88);
				  arg1294_556 = make_promise_21___r4_control_features_6_9(arg1295_1778);
			       }
			       {
				  obj_t arg1323_1433;
				  {
				     obj_t aux_1976;
				     aux_1976 = (obj_t) (type_553);
				     arg1323_1433 = MAKE_PAIR(aux_1976, arg1294_556);
				  }
				  {
				     obj_t obj2_1437;
				     obj2_1437 = _class_accesses__244_module_class;
				     return (_class_accesses__244_module_class = MAKE_PAIR(arg1323_1433, obj2_1437),
					BUNSPEC);
				  }
			       }
			    }
			 }
		       else
			 {
			    bool_t test1297_560;
			    {
			       bool_t test1304_569;
			       {
				  long n1_1438;
				  n1_1438 = (long) CINT(_optim__89_engine_param);
				  test1304_569 = (n1_1438 >= ((long) 2));
			       }
			       if (test1304_569)
				 {
				    long n1_1440;
				    n1_1440 = (long) CINT(_bdb_debug__1_engine_param);
				    test1297_560 = (n1_1440 <= ((long) 0));
				 }
			       else
				 {
				    test1297_560 = ((bool_t) 0);
				 }
			    }
			    if (test1297_560)
			      {
				 {
				    obj_t arg1298_561;
				    {
				       obj_t arg1299_1779;
				       arg1299_1779 = make_fx_procedure(arg1299_module_class, ((long) 0), ((long) 4));
				       PROCEDURE_SET(arg1299_1779, ((long) 0), class_def_12_86);
				       {
					  obj_t aux_1988;
					  aux_1988 = (obj_t) (type_553);
					  PROCEDURE_SET(arg1299_1779, ((long) 1), aux_1988);
				       }
				       PROCEDURE_SET(arg1299_1779, ((long) 2), src_def_101_89);
				       PROCEDURE_SET(arg1299_1779, ((long) 3), import_88);
				       arg1298_561 = make_promise_21___r4_control_features_6_9(arg1299_1779);
				    }
				    {
				       obj_t arg1323_1444;
				       {
					  obj_t aux_1994;
					  aux_1994 = (obj_t) (type_553);
					  arg1323_1444 = MAKE_PAIR(aux_1994, arg1298_561);
				       }
				       {
					  obj_t obj2_1448;
					  obj2_1448 = _class_accesses__244_module_class;
					  return (_class_accesses__244_module_class = MAKE_PAIR(arg1323_1444, obj2_1448),
					     BUNSPEC);
				       }
				    }
				 }
			      }
			    else
			      {
				 {
				    obj_t arg1301_565;
				    {
				       obj_t arg1302_1780;
				       arg1302_1780 = make_fx_procedure(arg1302_module_class, ((long) 0), ((long) 4));
				       PROCEDURE_SET(arg1302_1780, ((long) 0), class_def_12_86);
				       {
					  obj_t aux_2000;
					  aux_2000 = (obj_t) (type_553);
					  PROCEDURE_SET(arg1302_1780, ((long) 1), aux_2000);
				       }
				       PROCEDURE_SET(arg1302_1780, ((long) 2), src_def_101_89);
				       PROCEDURE_SET(arg1302_1780, ((long) 3), module_87);
				       arg1301_565 = make_promise_21___r4_control_features_6_9(arg1302_1780);
				    }
				    {
				       obj_t arg1323_1451;
				       {
					  obj_t aux_2006;
					  aux_2006 = (obj_t) (type_553);
					  arg1323_1451 = MAKE_PAIR(aux_2006, arg1301_565);
				       }
				       {
					  obj_t obj2_1455;
					  obj2_1455 = _class_accesses__244_module_class;
					  return (_class_accesses__244_module_class = MAKE_PAIR(arg1323_1451, obj2_1455),
					     BUNSPEC);
				       }
				    }
				 }
			      }
			 }
		    }
		  else
		    {
		       return BUNSPEC;
		    }
	       }
	    }
	 }
      }
   }
}


/* _declare-wide-class!1931 */ obj_t 
_declare_wide_class_1931_69_module_class(obj_t env_1781, obj_t class_def_12_1782, obj_t module_1783, obj_t import_1784, obj_t src_def_101_1785)
{
   return declare_wide_class__13_module_class(class_def_12_1782, module_1783, import_1784, src_def_101_1785);
}


/* arg1295 */ obj_t 
arg1295_module_class(obj_t env_1786)
{
   {
      obj_t class_def_12_1787;
      obj_t type_1788;
      obj_t src_def_101_1789;
      obj_t import_1790;
      class_def_12_1787 = PROCEDURE_REF(env_1786, ((long) 0));
      type_1788 = PROCEDURE_REF(env_1786, ((long) 1));
      src_def_101_1789 = PROCEDURE_REF(env_1786, ((long) 2));
      import_1790 = PROCEDURE_REF(env_1786, ((long) 3));
      {
	 return make_wide_class_accessors__22_object_wide_access_168(class_def_12_1787, (type_t) (type_1788), src_def_101_1789, import_1790);
      }
   }
}


/* arg1299 */ obj_t 
arg1299_module_class(obj_t env_1791)
{
   {
      obj_t class_def_12_1792;
      obj_t type_1793;
      obj_t src_def_101_1794;
      obj_t import_1795;
      class_def_12_1792 = PROCEDURE_REF(env_1791, ((long) 0));
      type_1793 = PROCEDURE_REF(env_1791, ((long) 1));
      src_def_101_1794 = PROCEDURE_REF(env_1791, ((long) 2));
      import_1795 = PROCEDURE_REF(env_1791, ((long) 3));
      {
	 return make_wide_class_accessors__22_object_wide_access_168(class_def_12_1792, (type_t) (type_1793), src_def_101_1794, import_1795);
      }
   }
}


/* arg1302 */ obj_t 
arg1302_module_class(obj_t env_1796)
{
   {
      obj_t class_def_12_1797;
      obj_t type_1798;
      obj_t src_def_101_1799;
      obj_t module_1800;
      class_def_12_1797 = PROCEDURE_REF(env_1796, ((long) 0));
      type_1798 = PROCEDURE_REF(env_1796, ((long) 1));
      src_def_101_1799 = PROCEDURE_REF(env_1796, ((long) 2));
      module_1800 = PROCEDURE_REF(env_1796, ((long) 3));
      {
	 return import_wide_class_accessors__236_object_wide_access_168(class_def_12_1797, (type_t) (type_1798), src_def_101_1799, module_1800);
      }
   }
}


/* make-add-class! */ obj_t 
make_add_class__155_module_class(obj_t holder_92, type_t class_93, obj_t src_def_101_94)
{
   {
      obj_t super_585;
      {
	 class_t obj_1461;
	 obj_1461 = (class_t) (class_93);
	 {
	    obj_t aux_2030;
	    {
	       object_t aux_2031;
	       aux_2031 = (object_t) (obj_1461);
	       aux_2030 = OBJECT_WIDENING(aux_2031);
	    }
	    super_585 = (((class_t) CREF(aux_2030))->its_super_214);
	 }
      }
      {
	 obj_t holder_id_229_586;
	 {
	    global_t obj_1462;
	    obj_1462 = (global_t) (holder_92);
	    holder_id_229_586 = (((global_t) CREF(obj_1462))->id);
	 }
	 {
	    obj_t class_id_86_587;
	    class_id_86_587 = (((type_t) CREF(class_93))->id);
	    {
	       obj_t class_module_252_588;
	       {
		  global_t obj_1464;
		  obj_1464 = (global_t) (holder_92);
		  class_module_252_588 = (((global_t) CREF(obj_1464))->module);
	       }
	       {
		  obj_t class_alloc_id_85_589;
		  {
		     obj_t arg1433_678;
		     arg1433_678 = CNST_TABLE_REF(((long) 4));
		     {
			obj_t list1434_679;
			{
			   obj_t arg1436_680;
			   arg1436_680 = MAKE_PAIR(class_id_86_587, BNIL);
			   list1434_679 = MAKE_PAIR(arg1433_678, arg1436_680);
			}
			class_alloc_id_85_589 = symbol_append_197___r4_symbols_6_4(list1434_679);
		     }
		  }
		  {
		     obj_t class_alloc_109_590;
		     {
			obj_t arg1423_672;
			arg1423_672 = CNST_TABLE_REF(((long) 5));
			{
			   obj_t list1427_674;
			   {
			      obj_t arg1428_675;
			      {
				 obj_t arg1431_676;
				 arg1431_676 = MAKE_PAIR(BNIL, BNIL);
				 arg1428_675 = MAKE_PAIR(class_module_252_588, arg1431_676);
			      }
			      list1427_674 = MAKE_PAIR(class_alloc_id_85_589, arg1428_675);
			   }
			   class_alloc_109_590 = cons__138___r4_pairs_and_lists_6_3(arg1423_672, list1427_674);
			}
		     }
		     {
			obj_t hash_591;
			{
			   obj_t aux_2049;
			   {
			      obj_t aux_2050;
			      aux_2050 = CDR(src_def_101_94);
			      aux_2049 = CDR(aux_2050);
			   }
			   hash_591 = get_class_hash_100_module_class(class_id_86_587, aux_2049);
			}
			{
			   obj_t constr_592;
			   {
			      class_t obj_1469;
			      obj_1469 = (class_t) (class_93);
			      {
				 obj_t aux_2055;
				 {
				    object_t aux_2056;
				    aux_2056 = (object_t) (obj_1469);
				    aux_2055 = OBJECT_WIDENING(aux_2056);
				 }
				 constr_592 = (((class_t) CREF(aux_2055))->constructor);
			      }
			   }
			   {
			      {
				 obj_t decl_593;
				 {
				    bool_t test1324_594;
				    test1324_594 = is_a__118___object(super_585, class_object_class);
				    if (test1324_594)
				      {
					 global_t sholder_595;
					 {
					    class_t obj_1471;
					    obj_1471 = (class_t) (super_585);
					    {
					       obj_t aux_2063;
					       {
						  object_t aux_2064;
						  aux_2064 = (object_t) (obj_1471);
						  aux_2063 = OBJECT_WIDENING(aux_2064);
					       }
					       sholder_595 = (((class_t) CREF(aux_2063))->holder);
					    }
					 }
					 {
					    obj_t sholder_id_85_596;
					    sholder_id_85_596 = (((global_t) CREF(sholder_595))->id);
					    {
					       obj_t sholder_module_189_597;
					       sholder_module_189_597 = (((global_t) CREF(sholder_595))->module);
					       {
						  {
						     obj_t arg1325_598;
						     obj_t arg1326_599;
						     arg1325_598 = CNST_TABLE_REF(((long) 6));
						     {
							obj_t arg1333_605;
							obj_t arg1334_606;
							obj_t arg1337_607;
							obj_t arg1339_608;
							{
							   obj_t arg1351_618;
							   obj_t arg1352_619;
							   obj_t arg1353_620;
							   arg1351_618 = CNST_TABLE_REF(((long) 5));
							   arg1352_619 = CNST_TABLE_REF(((long) 7));
							   arg1353_620 = CNST_TABLE_REF(((long) 8));
							   {
							      obj_t list1356_622;
							      {
								 obj_t arg1357_623;
								 {
								    obj_t arg1361_624;
								    arg1361_624 = MAKE_PAIR(BNIL, BNIL);
								    arg1357_623 = MAKE_PAIR(arg1353_620, arg1361_624);
								 }
								 list1356_622 = MAKE_PAIR(arg1352_619, arg1357_623);
							      }
							      arg1333_605 = cons__138___r4_pairs_and_lists_6_3(arg1351_618, list1356_622);
							   }
							}
							{
							   obj_t arg1364_626;
							   arg1364_626 = CNST_TABLE_REF(((long) 9));
							   {
							      obj_t list1366_628;
							      {
								 obj_t arg1367_629;
								 arg1367_629 = MAKE_PAIR(BNIL, BNIL);
								 list1366_628 = MAKE_PAIR(class_id_86_587, arg1367_629);
							      }
							      arg1334_606 = cons__138___r4_pairs_and_lists_6_3(arg1364_626, list1366_628);
							   }
							}
							{
							   obj_t arg1369_631;
							   arg1369_631 = CNST_TABLE_REF(((long) 5));
							   {
							      obj_t list1371_633;
							      {
								 obj_t arg1372_634;
								 {
								    obj_t arg1373_635;
								    arg1373_635 = MAKE_PAIR(BNIL, BNIL);
								    arg1372_634 = MAKE_PAIR(sholder_module_189_597, arg1373_635);
								 }
								 list1371_633 = MAKE_PAIR(sholder_id_85_596, arg1372_634);
							      }
							      arg1337_607 = cons__138___r4_pairs_and_lists_6_3(arg1369_631, list1371_633);
							   }
							}
							{
							   obj_t aux_2087;
							   {
							      obj_t aux_2088;
							      aux_2088 = CDR(src_def_101_94);
							      aux_2087 = CDR(aux_2088);
							   }
							   arg1339_608 = make_class_fields_146_module_class(class_id_86_587, aux_2087);
							}
							{
							   obj_t list1341_610;
							   {
							      obj_t arg1342_611;
							      {
								 obj_t arg1343_612;
								 {
								    obj_t arg1344_613;
								    {
								       obj_t arg1345_614;
								       {
									  obj_t arg1347_615;
									  {
									     obj_t arg1349_616;
									     arg1349_616 = MAKE_PAIR(BNIL, BNIL);
									     arg1347_615 = MAKE_PAIR(constr_592, arg1349_616);
									  }
									  arg1345_614 = MAKE_PAIR(arg1339_608, arg1347_615);
								       }
								       arg1344_613 = MAKE_PAIR(hash_591, arg1345_614);
								    }
								    arg1343_612 = MAKE_PAIR(class_alloc_109_590, arg1344_613);
								 }
								 arg1342_611 = MAKE_PAIR(arg1337_607, arg1343_612);
							      }
							      list1341_610 = MAKE_PAIR(arg1334_606, arg1342_611);
							   }
							   arg1326_599 = cons__138___r4_pairs_and_lists_6_3(arg1333_605, list1341_610);
							}
						     }
						     {
							obj_t list1329_601;
							{
							   obj_t arg1330_602;
							   {
							      obj_t arg1331_603;
							      arg1331_603 = MAKE_PAIR(BNIL, BNIL);
							      arg1330_602 = MAKE_PAIR(arg1326_599, arg1331_603);
							   }
							   list1329_601 = MAKE_PAIR(holder_id_229_586, arg1330_602);
							}
							decl_593 = cons__138___r4_pairs_and_lists_6_3(arg1325_598, list1329_601);
						     }
						  }
					       }
					    }
					 }
				      }
				    else
				      {
					 obj_t arg1379_638;
					 obj_t arg1381_639;
					 arg1379_638 = CNST_TABLE_REF(((long) 6));
					 {
					    obj_t arg1389_645;
					    obj_t arg1390_646;
					    obj_t arg1391_647;
					    {
					       obj_t arg1403_657;
					       obj_t arg1405_658;
					       obj_t arg1407_659;
					       arg1403_657 = CNST_TABLE_REF(((long) 5));
					       arg1405_658 = CNST_TABLE_REF(((long) 7));
					       arg1407_659 = CNST_TABLE_REF(((long) 8));
					       {
						  obj_t list1409_661;
						  {
						     obj_t arg1410_662;
						     {
							obj_t arg1411_663;
							arg1411_663 = MAKE_PAIR(BNIL, BNIL);
							arg1410_662 = MAKE_PAIR(arg1407_659, arg1411_663);
						     }
						     list1409_661 = MAKE_PAIR(arg1405_658, arg1410_662);
						  }
						  arg1389_645 = cons__138___r4_pairs_and_lists_6_3(arg1403_657, list1409_661);
					       }
					    }
					    {
					       obj_t arg1414_665;
					       arg1414_665 = CNST_TABLE_REF(((long) 9));
					       {
						  obj_t list1416_667;
						  {
						     obj_t arg1417_668;
						     arg1417_668 = MAKE_PAIR(BNIL, BNIL);
						     list1416_667 = MAKE_PAIR(class_id_86_587, arg1417_668);
						  }
						  arg1390_646 = cons__138___r4_pairs_and_lists_6_3(arg1414_665, list1416_667);
					       }
					    }
					    {
					       obj_t aux_2116;
					       {
						  obj_t aux_2117;
						  aux_2117 = CDR(src_def_101_94);
						  aux_2116 = CDR(aux_2117);
					       }
					       arg1391_647 = make_class_fields_146_module_class(class_id_86_587, aux_2116);
					    }
					    {
					       obj_t list1393_649;
					       {
						  obj_t arg1395_650;
						  {
						     obj_t arg1396_651;
						     {
							obj_t arg1397_652;
							{
							   obj_t arg1398_653;
							   {
							      obj_t arg1399_654;
							      {
								 obj_t arg1401_655;
								 arg1401_655 = MAKE_PAIR(BNIL, BNIL);
								 arg1399_654 = MAKE_PAIR(constr_592, arg1401_655);
							      }
							      arg1398_653 = MAKE_PAIR(arg1391_647, arg1399_654);
							   }
							   arg1397_652 = MAKE_PAIR(hash_591, arg1398_653);
							}
							arg1396_651 = MAKE_PAIR(class_alloc_109_590, arg1397_652);
						     }
						     arg1395_650 = MAKE_PAIR(BFALSE, arg1396_651);
						  }
						  list1393_649 = MAKE_PAIR(arg1390_646, arg1395_650);
					       }
					       arg1381_639 = cons__138___r4_pairs_and_lists_6_3(arg1389_645, list1393_649);
					    }
					 }
					 {
					    obj_t list1384_641;
					    {
					       obj_t arg1385_642;
					       {
						  obj_t arg1387_643;
						  arg1387_643 = MAKE_PAIR(BNIL, BNIL);
						  arg1385_642 = MAKE_PAIR(arg1381_639, arg1387_643);
					       }
					       list1384_641 = MAKE_PAIR(holder_id_229_586, arg1385_642);
					    }
					    decl_593 = cons__138___r4_pairs_and_lists_6_3(arg1379_638, list1384_641);
					 }
				      }
				 }
				 {
				    obj_t obj2_1483;
				    obj2_1483 = _declared_classes__217_module_class;
				    return (_declared_classes__217_module_class = MAKE_PAIR(decl_593, obj2_1483),
				       BUNSPEC);
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* get-class-hash */ obj_t 
get_class_hash_100_module_class(obj_t class_id_86_95, obj_t fields_96)
{
   {
      obj_t fields_682;
      long hash_683;
      {
	 long arg1438_685;
	 {
	    obj_t arg1440_686;
	    arg1440_686 = SYMBOL_TO_STRING(class_id_86_95);
	    {
	       char *aux_2135;
	       aux_2135 = BSTRING_TO_STRING(arg1440_686);
	       arg1438_685 = get_hash_power_number(aux_2135, ((long) 16));
	    }
	 }
	 fields_682 = fields_96;
	 hash_683 = arg1438_685;
       loop_684:
	 if (NULLP(fields_682))
	   {
	      return BINT(hash_683);
	   }
	 else
	   {
	      obj_t field_689;
	      field_689 = CAR(fields_682);
	      {
		 obj_t id_705;
		 obj_t att_706;
		 obj_t string_700;
		 obj_t len_701;
		 obj_t id_702;
		 obj_t att_703;
		 obj_t integer_695;
		 obj_t len_696;
		 obj_t id_697;
		 obj_t att_698;
		 obj_t id_692;
		 obj_t att_693;
		 if (PAIRP(field_689))
		   {
		      bool_t test_2144;
		      {
			 obj_t aux_2145;
			 aux_2145 = CDR(field_689);
			 test_2144 = (aux_2145 == BNIL);
		      }
		      if (test_2144)
			{
			   {
			      long hash_2150;
			      obj_t fields_2148;
			      fields_2148 = CDR(fields_682);
			      hash_2150 = (hash_683 ^ ((long) 2344));
			      hash_683 = hash_2150;
			      fields_682 = fields_2148;
			      goto loop_684;
			   }
			}
		      else
			{
			   if (SYMBOLP(field_689))
			     {
			      tag_121_151_691:
				{
				   obj_t arg1483_760;
				   long arg1484_761;
				   arg1483_760 = CDR(fields_682);
				   {
				      long arg1485_762;
				      {
					 obj_t arg1486_763;
					 arg1486_763 = SYMBOL_TO_STRING(field_689);
					 {
					    char *aux_2156;
					    aux_2156 = BSTRING_TO_STRING(arg1486_763);
					    arg1485_762 = get_hash_power_number(aux_2156, ((long) 16));
					 }
				      }
				      arg1484_761 = (hash_683 ^ arg1485_762);
				   }
				   {
				      long hash_2161;
				      obj_t fields_2160;
				      fields_2160 = arg1483_760;
				      hash_2161 = arg1484_761;
				      hash_683 = hash_2161;
				      fields_682 = fields_2160;
				      goto loop_684;
				   }
				}
			     }
			   else
			     {
				obj_t cdr_147_183_712;
				cdr_147_183_712 = CDR(field_689);
				{
				   bool_t test_2163;
				   {
				      obj_t aux_2166;
				      obj_t aux_2164;
				      aux_2166 = CNST_TABLE_REF(((long) 10));
				      aux_2164 = CAR(field_689);
				      test_2163 = (aux_2164 == aux_2166);
				   }
				   if (test_2163)
				     {
					if (PAIRP(cdr_147_183_712))
					  {
					     obj_t car_150_99_715;
					     car_150_99_715 = CAR(cdr_147_183_712);
					     if (SYMBOLP(car_150_99_715))
					       {
						  id_692 = car_150_99_715;
						  att_693 = CDR(cdr_147_183_712);
						  {
						     obj_t arg1488_765;
						     long arg1489_766;
						     arg1488_765 = CDR(fields_682);
						     {
							long arg1490_767;
							{
							   obj_t arg1491_768;
							   {
							      obj_t arg1497_771;
							      arg1497_771 = SYMBOL_TO_STRING(id_692);
							      arg1491_768 = string_append(string1933_module_class, arg1497_771);
							   }
							   {
							      char *aux_2177;
							      aux_2177 = BSTRING_TO_STRING(arg1491_768);
							      arg1490_767 = get_hash_power_number(aux_2177, ((long) 16));
							   }
							}
							arg1489_766 = (hash_683 ^ arg1490_767);
						     }
						     {
							long hash_2182;
							obj_t fields_2181;
							fields_2181 = arg1488_765;
							hash_2182 = arg1489_766;
							hash_683 = hash_2182;
							fields_682 = fields_2181;
							goto loop_684;
						     }
						  }
					       }
					     else
					       {
						  obj_t car_176_242_718;
						  car_176_242_718 = CAR(field_689);
						  if (SYMBOLP(car_176_242_718))
						    {
						       id_705 = car_176_242_718;
						       att_706 = cdr_147_183_712;
						     tag_125_98_707:
						       {
							  obj_t arg1526_796;
							  long arg1527_797;
							  arg1526_796 = CDR(fields_682);
							  {
							     long arg1528_798;
							     {
								obj_t arg1529_799;
								arg1529_799 = SYMBOL_TO_STRING(id_705);
								{
								   char *aux_2189;
								   aux_2189 = BSTRING_TO_STRING(arg1529_799);
								   arg1528_798 = get_hash_power_number(aux_2189, ((long) 16));
								}
							     }
							     arg1527_797 = (hash_683 ^ arg1528_798);
							  }
							  {
							     long hash_2194;
							     obj_t fields_2193;
							     fields_2193 = arg1526_796;
							     hash_2194 = arg1527_797;
							     hash_683 = hash_2194;
							     fields_682 = fields_2193;
							     goto loop_684;
							  }
						       }
						    }
						  else
						    {
						       return BFALSE;
						    }
					       }
					  }
					else
					  {
					     obj_t car_202_51_721;
					     car_202_51_721 = CAR(field_689);
					     if (SYMBOLP(car_202_51_721))
					       {
						  obj_t att_2199;
						  obj_t id_2198;
						  id_2198 = car_202_51_721;
						  att_2199 = cdr_147_183_712;
						  att_706 = att_2199;
						  id_705 = id_2198;
						  goto tag_125_98_707;
					       }
					     else
					       {
						  return BFALSE;
					       }
					  }
				     }
				   else
				     {
					bool_t test_2200;
					{
					   obj_t aux_2203;
					   obj_t aux_2201;
					   aux_2203 = CNST_TABLE_REF(((long) 11));
					   aux_2201 = CAR(field_689);
					   test_2200 = (aux_2201 == aux_2203);
					}
					if (test_2200)
					  {
					     if (PAIRP(cdr_147_183_712))
					       {
						  obj_t car_222_9_727;
						  obj_t cdr_223_81_728;
						  car_222_9_727 = CAR(cdr_147_183_712);
						  cdr_223_81_728 = CDR(cdr_147_183_712);
						  if (PAIRP(cdr_223_81_728))
						    {
						       obj_t car_233_238_730;
						       car_233_238_730 = CAR(cdr_223_81_728);
						       if (SYMBOLP(car_233_238_730))
							 {
							    integer_695 = car_222_9_727;
							    len_696 = car_222_9_727;
							    id_697 = car_233_238_730;
							    att_698 = CDR(cdr_223_81_728);
							    {
							       obj_t arg1498_772;
							       long arg1499_773;
							       arg1498_772 = CDR(fields_682);
							       {
								  long arg1500_774;
								  {
								     obj_t arg1501_775;
								     {
									char *arg1504_778;
									obj_t arg1505_779;
									arg1504_778 = integer__string_135___r4_numbers_6_5_fixnum((long) CINT(len_696), BNIL);
									arg1505_779 = SYMBOL_TO_STRING(id_697);
									{
									   obj_t list1506_780;
									   {
									      obj_t arg1507_781;
									      {
										 obj_t arg1510_782;
										 arg1510_782 = MAKE_PAIR(arg1505_779, BNIL);
										 {
										    obj_t aux_2220;
										    aux_2220 = string_to_bstring(arg1504_778);
										    arg1507_781 = MAKE_PAIR(aux_2220, arg1510_782);
										 }
									      }
									      list1506_780 = MAKE_PAIR(string1934_module_class, arg1507_781);
									   }
									   arg1501_775 = string_append_106___r4_strings_6_7(list1506_780);
									}
								     }
								     {
									char *aux_2225;
									aux_2225 = BSTRING_TO_STRING(arg1501_775);
									arg1500_774 = get_hash_power_number(aux_2225, ((long) 16));
								     }
								  }
								  arg1499_773 = (hash_683 ^ arg1500_774);
							       }
							       {
								  long hash_2230;
								  obj_t fields_2229;
								  fields_2229 = arg1498_772;
								  hash_2230 = arg1499_773;
								  hash_683 = hash_2230;
								  fields_682 = fields_2229;
								  goto loop_684;
							       }
							    }
							 }
						       else
							 {
							    obj_t car_254_112_734;
							    obj_t cdr_255_181_735;
							    car_254_112_734 = CAR(cdr_147_183_712);
							    cdr_255_181_735 = CDR(cdr_147_183_712);
							    {
							       obj_t car_265_225_736;
							       car_265_225_736 = CAR(cdr_255_181_735);
							       if (SYMBOLP(car_265_225_736))
								 {
								    string_700 = car_254_112_734;
								    len_701 = car_254_112_734;
								    id_702 = car_265_225_736;
								    att_703 = CDR(cdr_255_181_735);
								    {
								       obj_t arg1513_785;
								       long arg1514_786;
								       arg1513_785 = CDR(fields_682);
								       {
									  long arg1515_787;
									  {
									     obj_t arg1516_788;
									     {
										obj_t arg1519_791;
										arg1519_791 = SYMBOL_TO_STRING(id_702);
										{
										   obj_t list1520_792;
										   {
										      obj_t arg1522_793;
										      {
											 obj_t arg1524_794;
											 arg1524_794 = MAKE_PAIR(arg1519_791, BNIL);
											 arg1522_793 = MAKE_PAIR(len_701, arg1524_794);
										      }
										      list1520_792 = MAKE_PAIR(string1934_module_class, arg1522_793);
										   }
										   arg1516_788 = string_append_106___r4_strings_6_7(list1520_792);
										}
									     }
									     {
										char *aux_2243;
										aux_2243 = BSTRING_TO_STRING(arg1516_788);
										arg1515_787 = get_hash_power_number(aux_2243, ((long) 16));
									     }
									  }
									  arg1514_786 = (hash_683 ^ arg1515_787);
								       }
								       {
									  long hash_2248;
									  obj_t fields_2247;
									  fields_2247 = arg1513_785;
									  hash_2248 = arg1514_786;
									  hash_683 = hash_2248;
									  fields_682 = fields_2247;
									  goto loop_684;
								       }
								    }
								 }
							       else
								 {
								    obj_t car_276_9_739;
								    car_276_9_739 = CAR(field_689);
								    if (SYMBOLP(car_276_9_739))
								      {
									 obj_t att_2254;
									 obj_t id_2253;
									 id_2253 = car_276_9_739;
									 att_2254 = cdr_147_183_712;
									 att_706 = att_2254;
									 id_705 = id_2253;
									 goto tag_125_98_707;
								      }
								    else
								      {
									 return BFALSE;
								      }
								 }
							    }
							 }
						    }
						  else
						    {
						       obj_t car_293_23_742;
						       car_293_23_742 = CAR(field_689);
						       if (SYMBOLP(car_293_23_742))
							 {
							    obj_t att_2259;
							    obj_t id_2258;
							    id_2258 = car_293_23_742;
							    att_2259 = cdr_147_183_712;
							    att_706 = att_2259;
							    id_705 = id_2258;
							    goto tag_125_98_707;
							 }
						       else
							 {
							    return BFALSE;
							 }
						    }
					       }
					     else
					       {
						  obj_t car_310_10_745;
						  car_310_10_745 = CAR(field_689);
						  if (SYMBOLP(car_310_10_745))
						    {
						       obj_t att_2264;
						       obj_t id_2263;
						       id_2263 = car_310_10_745;
						       att_2264 = cdr_147_183_712;
						       att_706 = att_2264;
						       id_705 = id_2263;
						       goto tag_125_98_707;
						    }
						  else
						    {
						       return BFALSE;
						    }
					       }
					  }
					else
					  {
					     obj_t car_327_68_748;
					     car_327_68_748 = CAR(field_689);
					     if (SYMBOLP(car_327_68_748))
					       {
						  obj_t att_2269;
						  obj_t id_2268;
						  id_2268 = car_327_68_748;
						  att_2269 = cdr_147_183_712;
						  att_706 = att_2269;
						  id_705 = id_2268;
						  goto tag_125_98_707;
					       }
					     else
					       {
						  return BFALSE;
					       }
					  }
				     }
				}
			     }
			}
		   }
		 else
		   {
		      if (SYMBOLP(field_689))
			{
			   goto tag_121_151_691;
			}
		      else
			{
			   return BFALSE;
			}
		   }
	      }
	   }
      }
   }
}


/* _get-class-hash1932 */ obj_t 
_get_class_hash1932_177_module_class(obj_t env_1801, obj_t class_id_86_1802, obj_t fields_1803)
{
   return get_class_hash_100_module_class(class_id_86_1802, fields_1803);
}


/* make-class-fields */ obj_t 
make_class_fields_146_module_class(obj_t class_id_86_97, obj_t slot_defs_73_98)
{
   {
      obj_t slot_defs_73_803;
      if (PAIRP(slot_defs_73_98))
	{
	   obj_t car_596_84_833;
	   car_596_84_833 = CAR(slot_defs_73_98);
	   if (PAIRP(car_596_84_833))
	     {
		bool_t test_2278;
		{
		   obj_t aux_2279;
		   aux_2279 = CDR(car_596_84_833);
		   test_2278 = (aux_2279 == BNIL);
		}
		if (test_2278)
		  {
		     slot_defs_73_803 = CDR(slot_defs_73_98);
		  }
		else
		  {
		     slot_defs_73_803 = slot_defs_73_98;
		  }
	     }
	   else
	     {
		slot_defs_73_803 = slot_defs_73_98;
	     }
	}
      else
	{
	   slot_defs_73_803 = slot_defs_73_98;
	}
      if (CBOOL(_reflection___104_engine_param))
	{
	   obj_t arg1531_804;
	   obj_t arg1532_805;
	   arg1531_804 = CNST_TABLE_REF(((long) 12));
	   {
	      obj_t arg1535_808;
	      obj_t arg1536_809;
	      if (NULLP(slot_defs_73_803))
		{
		   arg1535_808 = BNIL;
		}
	      else
		{
		   obj_t head1219_812;
		   {
		      obj_t arg1550_823;
		      arg1550_823 = make_slot_field_56_module_class(class_id_86_97, CAR(slot_defs_73_803));
		      head1219_812 = MAKE_PAIR(arg1550_823, BNIL);
		   }
		   {
		      obj_t l1217_813;
		      obj_t tail1220_814;
		      l1217_813 = CDR(slot_defs_73_803);
		      tail1220_814 = head1219_812;
		    lname1218_815:
		      if (NULLP(l1217_813))
			{
			   arg1535_808 = head1219_812;
			}
		      else
			{
			   obj_t newtail1221_818;
			   {
			      obj_t arg1545_820;
			      arg1545_820 = make_slot_field_56_module_class(class_id_86_97, CAR(l1217_813));
			      newtail1221_818 = MAKE_PAIR(arg1545_820, BNIL);
			   }
			   SET_CDR(tail1220_814, newtail1221_818);
			   {
			      obj_t tail1220_2299;
			      obj_t l1217_2297;
			      l1217_2297 = CDR(l1217_813);
			      tail1220_2299 = newtail1221_818;
			      tail1220_814 = tail1220_2299;
			      l1217_813 = l1217_2297;
			      goto lname1218_815;
			   }
			}
		   }
		}
	      arg1536_809 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
	      arg1532_805 = append_2_18___r4_pairs_and_lists_6_3(arg1535_808, arg1536_809);
	   }
	   {
	      obj_t list1533_806;
	      list1533_806 = MAKE_PAIR(arg1532_805, BNIL);
	      return cons__138___r4_pairs_and_lists_6_3(arg1531_804, list1533_806);
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* read-only? */ bool_t 
read_only__11_module_class(obj_t attr_1098)
{
   {
      obj_t attr_1100;
      attr_1100 = attr_1098;
    loop_1101:
      if (NULLP(attr_1100))
	{
	   return ((bool_t) 0);
	}
      else
	{
	   bool_t test_2307;
	   {
	      obj_t aux_2308;
	      aux_2308 = memq___r4_pairs_and_lists_6_3(CAR(attr_1100), CNST_TABLE_REF(((long) 13)));
	      test_2307 = CBOOL(aux_2308);
	   }
	   if (test_2307)
	     {
		return ((bool_t) 1);
	     }
	   else
	     {
		{
		   obj_t attr_2313;
		   attr_2313 = CDR(attr_1100);
		   attr_1100 = attr_2313;
		   goto loop_1101;
		}
	     }
	}
   }
}


/* make-slot-field */ obj_t 
make_slot_field_56_module_class(obj_t class_id_86_1805, obj_t slot_839)
{
   {
      obj_t id_842;
      obj_t att_843;
      obj_t integer_845;
      obj_t len_846;
      obj_t id_847;
      obj_t att_848;
      obj_t string_850;
      obj_t len_851;
      obj_t id_852;
      obj_t att_853;
      obj_t id_855;
      obj_t att_856;
      if (SYMBOLP(slot_839))
	{
	   {
	      obj_t id_905;
	      id_905 = fast_id_of_id_130_ast_ident(slot_839);
	      {
		 obj_t arg1595_906;
		 obj_t arg1598_907;
		 obj_t arg1600_908;
		 obj_t arg1602_909;
		 arg1595_906 = CNST_TABLE_REF(((long) 14));
		 {
		    obj_t arg1610_917;
		    arg1610_917 = CNST_TABLE_REF(((long) 9));
		    {
		       obj_t list1613_919;
		       {
			  obj_t arg1615_920;
			  arg1615_920 = MAKE_PAIR(BNIL, BNIL);
			  list1613_919 = MAKE_PAIR(slot_839, arg1615_920);
		       }
		       arg1598_907 = cons__138___r4_pairs_and_lists_6_3(arg1610_917, list1613_919);
		    }
		 }
		 {
		    obj_t arg1618_922;
		    arg1618_922 = CNST_TABLE_REF(((long) 15));
		    {
		       obj_t list1619_923;
		       {
			  obj_t arg1620_924;
			  {
			     obj_t arg1621_925;
			     arg1621_925 = MAKE_PAIR(id_905, BNIL);
			     arg1620_924 = MAKE_PAIR(arg1618_922, arg1621_925);
			  }
			  list1619_923 = MAKE_PAIR(class_id_86_1805, arg1620_924);
		       }
		       arg1600_908 = symbol_append_197___r4_symbols_6_4(list1619_923);
		    }
		 }
		 {
		    obj_t arg1623_927;
		    arg1623_927 = CNST_TABLE_REF(((long) 15));
		    {
		       obj_t list1625_929;
		       {
			  obj_t arg1627_930;
			  {
			     obj_t arg1628_931;
			     {
				obj_t arg1630_932;
				{
				   obj_t aux_2329;
				   aux_2329 = CNST_TABLE_REF(((long) 16));
				   arg1630_932 = MAKE_PAIR(aux_2329, BNIL);
				}
				arg1628_931 = MAKE_PAIR(id_905, arg1630_932);
			     }
			     arg1627_930 = MAKE_PAIR(arg1623_927, arg1628_931);
			  }
			  list1625_929 = MAKE_PAIR(class_id_86_1805, arg1627_930);
		       }
		       arg1602_909 = symbol_append_197___r4_symbols_6_4(list1625_929);
		    }
		 }
		 {
		    obj_t list1604_911;
		    {
		       obj_t arg1605_912;
		       {
			  obj_t arg1606_913;
			  {
			     obj_t arg1607_914;
			     {
				obj_t arg1608_915;
				arg1608_915 = MAKE_PAIR(BNIL, BNIL);
				arg1607_914 = MAKE_PAIR(BUNSPEC, arg1608_915);
			     }
			     arg1606_913 = MAKE_PAIR(arg1602_909, arg1607_914);
			  }
			  arg1605_912 = MAKE_PAIR(arg1600_908, arg1606_913);
		       }
		       list1604_911 = MAKE_PAIR(arg1598_907, arg1605_912);
		    }
		    return cons__138___r4_pairs_and_lists_6_3(arg1595_906, list1604_911);
		 }
	      }
	   }
	}
      else
	{
	   if (PAIRP(slot_839))
	     {
		obj_t cdr_385_232_862;
		cdr_385_232_862 = CDR(slot_839);
		{
		   bool_t test_2345;
		   {
		      obj_t aux_2348;
		      obj_t aux_2346;
		      aux_2348 = CNST_TABLE_REF(((long) 10));
		      aux_2346 = CAR(slot_839);
		      test_2345 = (aux_2346 == aux_2348);
		   }
		   if (test_2345)
		     {
			if (PAIRP(cdr_385_232_862))
			  {
			     obj_t car_388_248_865;
			     car_388_248_865 = CAR(cdr_385_232_862);
			     if (SYMBOLP(car_388_248_865))
			       {
				  id_842 = car_388_248_865;
				  att_843 = CDR(cdr_385_232_862);
				  {
				     obj_t id_934;
				     id_934 = fast_id_of_id_130_ast_ident(id_842);
				     {
					obj_t arg1633_935;
					obj_t arg1634_936;
					obj_t arg1636_937;
					obj_t arg1638_938;
					obj_t arg1639_939;
					arg1633_935 = CNST_TABLE_REF(((long) 14));
					{
					   obj_t arg1650_947;
					   arg1650_947 = CNST_TABLE_REF(((long) 9));
					   {
					      obj_t list1653_949;
					      {
						 obj_t arg1654_950;
						 arg1654_950 = MAKE_PAIR(BNIL, BNIL);
						 list1653_949 = MAKE_PAIR(id_934, arg1654_950);
					      }
					      arg1634_936 = cons__138___r4_pairs_and_lists_6_3(arg1650_947, list1653_949);
					   }
					}
					{
					   obj_t arg1656_952;
					   arg1656_952 = CNST_TABLE_REF(((long) 15));
					   {
					      obj_t list1658_954;
					      {
						 obj_t arg1659_955;
						 {
						    obj_t arg1661_956;
						    {
						       obj_t arg1663_957;
						       {
							  obj_t aux_2363;
							  aux_2363 = CNST_TABLE_REF(((long) 17));
							  arg1663_957 = MAKE_PAIR(aux_2363, BNIL);
						       }
						       arg1661_956 = MAKE_PAIR(id_934, arg1663_957);
						    }
						    arg1659_955 = MAKE_PAIR(arg1656_952, arg1661_956);
						 }
						 list1658_954 = MAKE_PAIR(class_id_86_1805, arg1659_955);
					      }
					      arg1636_937 = symbol_append_197___r4_symbols_6_4(list1658_954);
					   }
					}
					if (read_only__11_module_class(att_843))
					  {
					     arg1638_938 = BUNSPEC;
					  }
					else
					  {
					     obj_t arg1667_960;
					     arg1667_960 = CNST_TABLE_REF(((long) 15));
					     {
						obj_t list1669_962;
						{
						   obj_t arg1670_963;
						   {
						      obj_t arg1672_964;
						      {
							 obj_t arg1673_965;
							 {
							    obj_t aux_2373;
							    aux_2373 = CNST_TABLE_REF(((long) 16));
							    arg1673_965 = MAKE_PAIR(aux_2373, BNIL);
							 }
							 arg1672_964 = MAKE_PAIR(id_934, arg1673_965);
						      }
						      arg1670_963 = MAKE_PAIR(arg1667_960, arg1672_964);
						   }
						   list1669_962 = MAKE_PAIR(class_id_86_1805, arg1670_963);
						}
						arg1638_938 = symbol_append_197___r4_symbols_6_4(list1669_962);
					     }
					  }
					{
					   obj_t arg1676_967;
					   arg1676_967 = CNST_TABLE_REF(((long) 15));
					   {
					      obj_t list1678_969;
					      {
						 obj_t arg1679_970;
						 {
						    obj_t arg1680_971;
						    {
						       obj_t arg1681_972;
						       {
							  obj_t aux_2381;
							  aux_2381 = CNST_TABLE_REF(((long) 21));
							  arg1681_972 = MAKE_PAIR(aux_2381, BNIL);
						       }
						       arg1680_971 = MAKE_PAIR(id_934, arg1681_972);
						    }
						    arg1679_970 = MAKE_PAIR(arg1676_967, arg1680_971);
						 }
						 list1678_969 = MAKE_PAIR(class_id_86_1805, arg1679_970);
					      }
					      arg1639_939 = symbol_append_197___r4_symbols_6_4(list1678_969);
					   }
					}
					{
					   obj_t list1641_941;
					   {
					      obj_t arg1645_942;
					      {
						 obj_t arg1646_943;
						 {
						    obj_t arg1647_944;
						    {
						       obj_t arg1648_945;
						       arg1648_945 = MAKE_PAIR(BNIL, BNIL);
						       arg1647_944 = MAKE_PAIR(arg1639_939, arg1648_945);
						    }
						    arg1646_943 = MAKE_PAIR(arg1638_938, arg1647_944);
						 }
						 arg1645_942 = MAKE_PAIR(arg1636_937, arg1646_943);
					      }
					      list1641_941 = MAKE_PAIR(arg1634_936, arg1645_942);
					   }
					   return cons__138___r4_pairs_and_lists_6_3(arg1633_935, list1641_941);
					}
				     }
				  }
			       }
			     else
			       {
				  obj_t car_414_158_868;
				  car_414_158_868 = CAR(slot_839);
				  if (SYMBOLP(car_414_158_868))
				    {
				       id_855 = car_414_158_868;
				       att_856 = cdr_385_232_862;
				     tag_369_107_857:
				       {
					  obj_t id_1068;
					  id_1068 = fast_id_of_id_130_ast_ident(id_855);
					  {
					     obj_t arg1797_1069;
					     obj_t arg1799_1070;
					     obj_t arg1800_1071;
					     obj_t arg1802_1072;
					     arg1797_1069 = CNST_TABLE_REF(((long) 14));
					     {
						obj_t arg1810_1080;
						arg1810_1080 = CNST_TABLE_REF(((long) 9));
						{
						   obj_t list1812_1082;
						   {
						      obj_t arg1813_1083;
						      arg1813_1083 = MAKE_PAIR(BNIL, BNIL);
						      list1812_1082 = MAKE_PAIR(id_1068, arg1813_1083);
						   }
						   arg1799_1070 = cons__138___r4_pairs_and_lists_6_3(arg1810_1080, list1812_1082);
						}
					     }
					     {
						obj_t arg1815_1085;
						arg1815_1085 = CNST_TABLE_REF(((long) 15));
						{
						   obj_t list1816_1086;
						   {
						      obj_t arg1817_1087;
						      {
							 obj_t arg1818_1088;
							 arg1818_1088 = MAKE_PAIR(id_1068, BNIL);
							 arg1817_1087 = MAKE_PAIR(arg1815_1085, arg1818_1088);
						      }
						      list1816_1086 = MAKE_PAIR(class_id_86_1805, arg1817_1087);
						   }
						   arg1800_1071 = symbol_append_197___r4_symbols_6_4(list1816_1086);
						}
					     }
					     if (read_only__11_module_class(att_856))
					       {
						  arg1802_1072 = BUNSPEC;
					       }
					     else
					       {
						  obj_t arg1822_1091;
						  arg1822_1091 = CNST_TABLE_REF(((long) 15));
						  {
						     obj_t list1824_1093;
						     {
							obj_t arg1826_1094;
							{
							   obj_t arg1827_1095;
							   {
							      obj_t arg1829_1096;
							      {
								 obj_t aux_2412;
								 aux_2412 = CNST_TABLE_REF(((long) 16));
								 arg1829_1096 = MAKE_PAIR(aux_2412, BNIL);
							      }
							      arg1827_1095 = MAKE_PAIR(id_1068, arg1829_1096);
							   }
							   arg1826_1094 = MAKE_PAIR(arg1822_1091, arg1827_1095);
							}
							list1824_1093 = MAKE_PAIR(class_id_86_1805, arg1826_1094);
						     }
						     arg1802_1072 = symbol_append_197___r4_symbols_6_4(list1824_1093);
						  }
					       }
					     {
						obj_t list1804_1074;
						{
						   obj_t arg1805_1075;
						   {
						      obj_t arg1806_1076;
						      {
							 obj_t arg1807_1077;
							 {
							    obj_t arg1808_1078;
							    arg1808_1078 = MAKE_PAIR(BNIL, BNIL);
							    arg1807_1077 = MAKE_PAIR(BUNSPEC, arg1808_1078);
							 }
							 arg1806_1076 = MAKE_PAIR(arg1802_1072, arg1807_1077);
						      }
						      arg1805_1075 = MAKE_PAIR(arg1800_1071, arg1806_1076);
						   }
						   list1804_1074 = MAKE_PAIR(arg1799_1070, arg1805_1075);
						}
						return cons__138___r4_pairs_and_lists_6_3(arg1797_1069, list1804_1074);
					     }
					  }
				       }
				    }
				  else
				    {
				     tag_370_207_858:
				       return internal_error_43_tools_error(string1935_module_class, string1936_module_class, slot_839);
				    }
			       }
			  }
			else
			  {
			     obj_t car_440_37_871;
			     car_440_37_871 = CAR(slot_839);
			     if (SYMBOLP(car_440_37_871))
			       {
				  obj_t att_2430;
				  obj_t id_2429;
				  id_2429 = car_440_37_871;
				  att_2430 = cdr_385_232_862;
				  att_856 = att_2430;
				  id_855 = id_2429;
				  goto tag_369_107_857;
			       }
			     else
			       {
				  goto tag_370_207_858;
			       }
			  }
		     }
		   else
		     {
			bool_t test_2431;
			{
			   obj_t aux_2434;
			   obj_t aux_2432;
			   aux_2434 = CNST_TABLE_REF(((long) 11));
			   aux_2432 = CAR(slot_839);
			   test_2431 = (aux_2432 == aux_2434);
			}
			if (test_2431)
			  {
			     if (PAIRP(cdr_385_232_862))
			       {
				  obj_t car_460_249_877;
				  obj_t cdr_461_169_878;
				  car_460_249_877 = CAR(cdr_385_232_862);
				  cdr_461_169_878 = CDR(cdr_385_232_862);
				  if (PAIRP(cdr_461_169_878))
				    {
				       obj_t car_471_231_880;
				       car_471_231_880 = CAR(cdr_461_169_878);
				       if (SYMBOLP(car_471_231_880))
					 {
					    integer_845 = car_460_249_877;
					    len_846 = car_460_249_877;
					    id_847 = car_471_231_880;
					    att_848 = CDR(cdr_461_169_878);
					    {
					       obj_t id_974;
					       id_974 = fast_id_of_id_130_ast_ident(id_847);
					       {
						  obj_t arg1683_975;
						  obj_t arg1684_976;
						  obj_t arg1685_977;
						  obj_t arg1686_978;
						  obj_t arg1688_979;
						  arg1683_975 = CNST_TABLE_REF(((long) 14));
						  {
						     obj_t arg1697_987;
						     arg1697_987 = CNST_TABLE_REF(((long) 9));
						     {
							obj_t list1699_989;
							{
							   obj_t arg1700_990;
							   arg1700_990 = MAKE_PAIR(BNIL, BNIL);
							   list1699_989 = MAKE_PAIR(id_974, arg1700_990);
							}
							arg1684_976 = cons__138___r4_pairs_and_lists_6_3(arg1697_987, list1699_989);
						     }
						  }
						  {
						     obj_t arg1702_992;
						     arg1702_992 = CNST_TABLE_REF(((long) 15));
						     {
							obj_t list1704_994;
							{
							   obj_t arg1705_995;
							   {
							      obj_t arg1706_996;
							      {
								 obj_t arg1707_997;
								 {
								    obj_t aux_2453;
								    aux_2453 = CNST_TABLE_REF(((long) 17));
								    arg1707_997 = MAKE_PAIR(aux_2453, BNIL);
								 }
								 arg1706_996 = MAKE_PAIR(id_974, arg1707_997);
							      }
							      arg1705_995 = MAKE_PAIR(arg1702_992, arg1706_996);
							   }
							   list1704_994 = MAKE_PAIR(class_id_86_1805, arg1705_995);
							}
							arg1685_977 = symbol_append_197___r4_symbols_6_4(list1704_994);
						     }
						  }
						  if (read_only__11_module_class(att_848))
						    {
						       arg1686_978 = BUNSPEC;
						    }
						  else
						    {
						       obj_t arg1710_1000;
						       arg1710_1000 = CNST_TABLE_REF(((long) 15));
						       {
							  obj_t list1712_1002;
							  {
							     obj_t arg1713_1003;
							     {
								obj_t arg1714_1004;
								{
								   obj_t arg1716_1005;
								   {
								      obj_t aux_2463;
								      aux_2463 = CNST_TABLE_REF(((long) 16));
								      arg1716_1005 = MAKE_PAIR(aux_2463, BNIL);
								   }
								   arg1714_1004 = MAKE_PAIR(id_974, arg1716_1005);
								}
								arg1713_1003 = MAKE_PAIR(arg1710_1000, arg1714_1004);
							     }
							     list1712_1002 = MAKE_PAIR(class_id_86_1805, arg1713_1003);
							  }
							  arg1686_978 = symbol_append_197___r4_symbols_6_4(list1712_1002);
						       }
						    }
						  {
						     obj_t arg1718_1007;
						     obj_t arg1720_1008;
						     arg1718_1007 = CNST_TABLE_REF(((long) 18));
						     {
							obj_t arg1726_1014;
							arg1726_1014 = CNST_TABLE_REF(((long) 19));
							{
							   obj_t list1728_1016;
							   list1728_1016 = MAKE_PAIR(BNIL, BNIL);
							   arg1720_1008 = cons__138___r4_pairs_and_lists_6_3(arg1726_1014, list1728_1016);
							}
						     }
						     {
							obj_t list1722_1010;
							{
							   obj_t arg1723_1011;
							   {
							      obj_t arg1724_1012;
							      arg1724_1012 = MAKE_PAIR(BNIL, BNIL);
							      arg1723_1011 = MAKE_PAIR(len_846, arg1724_1012);
							   }
							   list1722_1010 = MAKE_PAIR(arg1720_1008, arg1723_1011);
							}
							arg1688_979 = cons__138___r4_pairs_and_lists_6_3(arg1718_1007, list1722_1010);
						     }
						  }
						  {
						     obj_t list1690_981;
						     {
							obj_t arg1691_982;
							{
							   obj_t arg1692_983;
							   {
							      obj_t arg1693_984;
							      {
								 obj_t arg1694_985;
								 arg1694_985 = MAKE_PAIR(BNIL, BNIL);
								 arg1693_984 = MAKE_PAIR(arg1688_979, arg1694_985);
							      }
							      arg1692_983 = MAKE_PAIR(arg1686_978, arg1693_984);
							   }
							   arg1691_982 = MAKE_PAIR(arg1685_977, arg1692_983);
							}
							list1690_981 = MAKE_PAIR(arg1684_976, arg1691_982);
						     }
						     return cons__138___r4_pairs_and_lists_6_3(arg1683_975, list1690_981);
						  }
					       }
					    }
					 }
				       else
					 {
					    obj_t car_492_30_884;
					    obj_t cdr_493_219_885;
					    car_492_30_884 = CAR(cdr_385_232_862);
					    cdr_493_219_885 = CDR(cdr_385_232_862);
					    {
					       obj_t car_503_8_886;
					       car_503_8_886 = CAR(cdr_493_219_885);
					       if (SYMBOLP(car_503_8_886))
						 {
						    string_850 = car_492_30_884;
						    len_851 = car_492_30_884;
						    id_852 = car_503_8_886;
						    att_853 = CDR(cdr_493_219_885);
						    {
						       obj_t id_1018;
						       id_1018 = fast_id_of_id_130_ast_ident(id_852);
						       {
							  obj_t arg1730_1019;
							  obj_t arg1731_1020;
							  obj_t arg1732_1021;
							  obj_t arg1733_1022;
							  obj_t arg1738_1023;
							  arg1730_1019 = CNST_TABLE_REF(((long) 14));
							  {
							     obj_t arg1748_1031;
							     arg1748_1031 = CNST_TABLE_REF(((long) 9));
							     {
								obj_t list1750_1033;
								{
								   obj_t arg1753_1034;
								   arg1753_1034 = MAKE_PAIR(BNIL, BNIL);
								   list1750_1033 = MAKE_PAIR(id_1018, arg1753_1034);
								}
								arg1731_1020 = cons__138___r4_pairs_and_lists_6_3(arg1748_1031, list1750_1033);
							     }
							  }
							  {
							     obj_t arg1758_1036;
							     arg1758_1036 = CNST_TABLE_REF(((long) 15));
							     {
								obj_t list1760_1038;
								{
								   obj_t arg1761_1039;
								   {
								      obj_t arg1762_1040;
								      {
									 obj_t arg1765_1041;
									 {
									    obj_t aux_2497;
									    aux_2497 = CNST_TABLE_REF(((long) 17));
									    arg1765_1041 = MAKE_PAIR(aux_2497, BNIL);
									 }
									 arg1762_1040 = MAKE_PAIR(id_1018, arg1765_1041);
								      }
								      arg1761_1039 = MAKE_PAIR(arg1758_1036, arg1762_1040);
								   }
								   list1760_1038 = MAKE_PAIR(class_id_86_1805, arg1761_1039);
								}
								arg1732_1021 = symbol_append_197___r4_symbols_6_4(list1760_1038);
							     }
							  }
							  if (read_only__11_module_class(att_853))
							    {
							       arg1733_1022 = BUNSPEC;
							    }
							  else
							    {
							       obj_t arg1768_1044;
							       arg1768_1044 = CNST_TABLE_REF(((long) 15));
							       {
								  obj_t list1770_1046;
								  {
								     obj_t arg1771_1047;
								     {
									obj_t arg1772_1048;
									{
									   obj_t arg1773_1049;
									   {
									      obj_t aux_2507;
									      aux_2507 = CNST_TABLE_REF(((long) 16));
									      arg1773_1049 = MAKE_PAIR(aux_2507, BNIL);
									   }
									   arg1772_1048 = MAKE_PAIR(id_1018, arg1773_1049);
									}
									arg1771_1047 = MAKE_PAIR(arg1768_1044, arg1772_1048);
								     }
								     list1770_1046 = MAKE_PAIR(class_id_86_1805, arg1771_1047);
								  }
								  arg1733_1022 = symbol_append_197___r4_symbols_6_4(list1770_1046);
							       }
							    }
							  {
							     obj_t arg1776_1051;
							     obj_t arg1777_1052;
							     obj_t arg1778_1053;
							     arg1776_1051 = CNST_TABLE_REF(((long) 18));
							     {
								obj_t arg1788_1059;
								arg1788_1059 = CNST_TABLE_REF(((long) 19));
								{
								   obj_t list1790_1061;
								   list1790_1061 = MAKE_PAIR(BNIL, BNIL);
								   arg1777_1052 = cons__138___r4_pairs_and_lists_6_3(arg1788_1059, list1790_1061);
								}
							     }
							     {
								obj_t arg1792_1063;
								arg1792_1063 = CNST_TABLE_REF(((long) 20));
								{
								   obj_t list1794_1065;
								   {
								      obj_t arg1795_1066;
								      arg1795_1066 = MAKE_PAIR(BNIL, BNIL);
								      list1794_1065 = MAKE_PAIR(len_851, arg1795_1066);
								   }
								   arg1778_1053 = cons__138___r4_pairs_and_lists_6_3(arg1792_1063, list1794_1065);
								}
							     }
							     {
								obj_t list1780_1055;
								{
								   obj_t arg1781_1056;
								   {
								      obj_t arg1783_1057;
								      arg1783_1057 = MAKE_PAIR(BNIL, BNIL);
								      arg1781_1056 = MAKE_PAIR(arg1778_1053, arg1783_1057);
								   }
								   list1780_1055 = MAKE_PAIR(arg1777_1052, arg1781_1056);
								}
								arg1738_1023 = cons__138___r4_pairs_and_lists_6_3(arg1776_1051, list1780_1055);
							     }
							  }
							  {
							     obj_t list1740_1025;
							     {
								obj_t arg1743_1026;
								{
								   obj_t arg1744_1027;
								   {
								      obj_t arg1745_1028;
								      {
									 obj_t arg1746_1029;
									 arg1746_1029 = MAKE_PAIR(BNIL, BNIL);
									 arg1745_1028 = MAKE_PAIR(arg1738_1023, arg1746_1029);
								      }
								      arg1744_1027 = MAKE_PAIR(arg1733_1022, arg1745_1028);
								   }
								   arg1743_1026 = MAKE_PAIR(arg1732_1021, arg1744_1027);
								}
								list1740_1025 = MAKE_PAIR(arg1731_1020, arg1743_1026);
							     }
							     return cons__138___r4_pairs_and_lists_6_3(arg1730_1019, list1740_1025);
							  }
						       }
						    }
						 }
					       else
						 {
						    obj_t car_514_4_889;
						    car_514_4_889 = CAR(slot_839);
						    if (SYMBOLP(car_514_4_889))
						      {
							 obj_t att_2537;
							 obj_t id_2536;
							 id_2536 = car_514_4_889;
							 att_2537 = cdr_385_232_862;
							 att_856 = att_2537;
							 id_855 = id_2536;
							 goto tag_369_107_857;
						      }
						    else
						      {
							 goto tag_370_207_858;
						      }
						 }
					    }
					 }
				    }
				  else
				    {
				       obj_t car_531_80_892;
				       car_531_80_892 = CAR(slot_839);
				       if (SYMBOLP(car_531_80_892))
					 {
					    obj_t att_2542;
					    obj_t id_2541;
					    id_2541 = car_531_80_892;
					    att_2542 = cdr_385_232_862;
					    att_856 = att_2542;
					    id_855 = id_2541;
					    goto tag_369_107_857;
					 }
				       else
					 {
					    goto tag_370_207_858;
					 }
				    }
			       }
			     else
			       {
				  obj_t car_548_224_895;
				  car_548_224_895 = CAR(slot_839);
				  if (SYMBOLP(car_548_224_895))
				    {
				       obj_t att_2547;
				       obj_t id_2546;
				       id_2546 = car_548_224_895;
				       att_2547 = cdr_385_232_862;
				       att_856 = att_2547;
				       id_855 = id_2546;
				       goto tag_369_107_857;
				    }
				  else
				    {
				       goto tag_370_207_858;
				    }
			       }
			  }
			else
			  {
			     obj_t car_565_0_898;
			     car_565_0_898 = CAR(slot_839);
			     if (SYMBOLP(car_565_0_898))
			       {
				  obj_t att_2552;
				  obj_t id_2551;
				  id_2551 = car_565_0_898;
				  att_2552 = cdr_385_232_862;
				  att_856 = att_2552;
				  id_855 = id_2551;
				  goto tag_369_107_857;
			       }
			     else
			       {
				  goto tag_370_207_858;
			       }
			  }
		     }
		}
	     }
	   else
	     {
		goto tag_370_207_858;
	     }
	}
   }
}


/* class-finalizer */ obj_t 
class_finalizer_253_module_class()
{
   {
      bool_t test1837_1109;
      {
	 bool_t test1858_1123;
	 {
	    obj_t obj_1639;
	    obj_1639 = _declared_classes__217_module_class;
	    test1858_1123 = NULLP(obj_1639);
	 }
	 if (test1858_1123)
	   {
	      obj_t obj_1640;
	      obj_1640 = _class_accesses__244_module_class;
	      test1837_1109 = NULLP(obj_1640);
	   }
	 else
	   {
	      test1837_1109 = ((bool_t) 0);
	   }
      }
      if (test1837_1109)
	{
	   return CNST_TABLE_REF(((long) 22));
	}
      else
	{
	   {
	      obj_t body_1110;
	      {
		 obj_t arg1856_1121;
		 obj_t arg1857_1122;
		 arg1856_1121 = reverse__39___r4_pairs_and_lists_6_3(_declared_classes__217_module_class);
		 arg1857_1122 = force_class_accesses_39_module_class();
		 body_1110 = append_2_18___r4_pairs_and_lists_6_3(arg1856_1121, arg1857_1122);
	      }
	      {
		 obj_t arg1838_1111;
		 obj_t arg1842_1113;
		 arg1838_1111 = CNST_TABLE_REF(((long) 19));
		 if (PAIRP(body_1110))
		   {
		      arg1842_1113 = body_1110;
		   }
		 else
		   {
		      arg1842_1113 = CNST_TABLE_REF(((long) 23));
		   }
		 {
		    obj_t new_1646;
		    {
		       obj_t aux_2565;
		       aux_2565 = CNST_TABLE_REF(((long) 24));
		       new_1646 = create_struct(aux_2565, ((long) 4));
		    }
		    STRUCT_SET(new_1646, ((long) 3), BTRUE);
		    STRUCT_SET(new_1646, ((long) 2), arg1842_1113);
		    {
		       obj_t aux_2570;
		       aux_2570 = BINT(((long) 19));
		       STRUCT_SET(new_1646, ((long) 1), aux_2570);
		    }
		    STRUCT_SET(new_1646, ((long) 0), arg1838_1111);
		    _object_unit__229_module_class = new_1646;
		 }
	      }
	      {
		 obj_t arg1847_1115;
		 obj_t arg1850_1117;
		 arg1847_1115 = CNST_TABLE_REF(((long) 25));
		 arg1850_1117 = CNST_TABLE_REF(((long) 23));
		 {
		    obj_t new_1673;
		    {
		       obj_t aux_2576;
		       aux_2576 = CNST_TABLE_REF(((long) 24));
		       new_1673 = create_struct(aux_2576, ((long) 4));
		    }
		    STRUCT_SET(new_1673, ((long) 3), BTRUE);
		    STRUCT_SET(new_1673, ((long) 2), arg1850_1117);
		    {
		       obj_t aux_2581;
		       aux_2581 = BINT(((long) 20));
		       STRUCT_SET(new_1673, ((long) 1), aux_2581);
		    }
		    STRUCT_SET(new_1673, ((long) 0), arg1847_1115);
		    _method_unit__121_module_class = new_1673;
		 }
	      }
	      {
		 obj_t list1851_1118;
		 {
		    obj_t arg1852_1119;
		    arg1852_1119 = MAKE_PAIR(_method_unit__121_module_class, BNIL);
		    list1851_1118 = MAKE_PAIR(_object_unit__229_module_class, arg1852_1119);
		 }
		 return list1851_1118;
	      }
	   }
	}
   }
}


/* _class-finalizer */ obj_t 
_class_finalizer_205_module_class(obj_t env_1804)
{
   return class_finalizer_253_module_class();
}


/* force-class-accesses */ obj_t 
force_class_accesses_39_module_class()
{
   {
      obj_t cur_1124;
      obj_t next_1125;
      obj_t access_1126;
      {
	 obj_t arg1859_1128;
	 arg1859_1128 = reverse__39___r4_pairs_and_lists_6_3(_class_accesses__244_module_class);
	 cur_1124 = arg1859_1128;
	 next_1125 = BNIL;
	 access_1126 = BNIL;
       loop_1127:
	 if (NULLP(cur_1124))
	   {
	      if (NULLP(next_1125))
		{
		   return access_1126;
		}
	      else
		{
		   obj_t next_2594;
		   obj_t cur_2593;
		   cur_2593 = next_1125;
		   next_2594 = BNIL;
		   next_1125 = next_2594;
		   cur_1124 = cur_2593;
		   goto loop_1127;
		}
	   }
	 else
	   {
	      obj_t class_1134;
	      {
		 obj_t aux_2595;
		 aux_2595 = CAR(cur_1124);
		 class_1134 = CAR(aux_2595);
	      }
	      {
		 obj_t super_1135;
		 {
		    class_t obj_1701;
		    obj_1701 = (class_t) (class_1134);
		    {
		       obj_t aux_2599;
		       {
			  object_t aux_2600;
			  aux_2600 = (object_t) (obj_1701);
			  aux_2599 = OBJECT_WIDENING(aux_2600);
		       }
		       super_1135 = (((class_t) CREF(aux_2599))->its_super_214);
		    }
		 }
		 {
		    if ((super_1135 == class_1134))
		      {
			 {
			    obj_t arg1867_1138;
			    {
			       obj_t arg1868_1139;
			       {
				  obj_t arg1869_1140;
				  {
				     obj_t aux_2606;
				     aux_2606 = CAR(cur_1124);
				     arg1869_1140 = CDR(aux_2606);
				  }
				  arg1868_1139 = PROCEDURE_ENTRY(arg1869_1140) (arg1869_1140, BEOA);
			       }
			       arg1867_1138 = append_2_18___r4_pairs_and_lists_6_3(arg1868_1139, access_1126);
			    }
			    {
			       obj_t access_2614;
			       obj_t cur_2612;
			       cur_2612 = CDR(cur_1124);
			       access_2614 = arg1867_1138;
			       access_1126 = access_2614;
			       cur_1124 = cur_2612;
			       goto loop_1127;
			    }
			 }
		      }
		    else
		      {
			 bool_t test1871_1142;
			 test1871_1142 = is_a__118___object(super_1135, class_object_class);
			 if (test1871_1142)
			   {
			      bool_t test_2617;
			      {
				 obj_t aux_2618;
				 {
				    class_t obj_1709;
				    obj_1709 = (class_t) (super_1135);
				    {
				       obj_t aux_2620;
				       {
					  object_t aux_2621;
					  aux_2621 = (object_t) (obj_1709);
					  aux_2620 = OBJECT_WIDENING(aux_2621);
				       }
				       aux_2618 = (((class_t) CREF(aux_2620))->slots);
				    }
				 }
				 test_2617 = (aux_2618 == BUNSPEC);
			      }
			      if (test_2617)
				{
				   {
				      obj_t arg1874_1144;
				      obj_t arg1875_1145;
				      arg1874_1144 = CDR(cur_1124);
				      {
					 obj_t aux_2627;
					 aux_2627 = CAR(cur_1124);
					 arg1875_1145 = MAKE_PAIR(aux_2627, next_1125);
				      }
				      {
					 obj_t next_2631;
					 obj_t cur_2630;
					 cur_2630 = arg1874_1144;
					 next_2631 = arg1875_1145;
					 next_1125 = next_2631;
					 cur_1124 = cur_2630;
					 goto loop_1127;
				      }
				   }
				}
			      else
				{
				   {
				      obj_t arg1878_1148;
				      {
					 obj_t arg1879_1149;
					 {
					    obj_t arg1880_1150;
					    {
					       obj_t aux_2632;
					       aux_2632 = CAR(cur_1124);
					       arg1880_1150 = CDR(aux_2632);
					    }
					    arg1879_1149 = PROCEDURE_ENTRY(arg1880_1150) (arg1880_1150, BEOA);
					 }
					 arg1878_1148 = append_2_18___r4_pairs_and_lists_6_3(arg1879_1149, access_1126);
				      }
				      {
					 obj_t access_2640;
					 obj_t cur_2638;
					 cur_2638 = CDR(cur_1124);
					 access_2640 = arg1878_1148;
					 access_1126 = access_2640;
					 cur_1124 = cur_2638;
					 goto loop_1127;
				      }
				   }
				}
			   }
			 else
			   {
			      {
				 bool_t test1884_1153;
				 test1884_1153 = is_a__118___object(super_1135, type_type_type);
				 if (test1884_1153)
				   {
				      {
					 class_t obj_1721;
					 obj_1721 = (class_t) (class_1134);
					 {
					    obj_t aux_2644;
					    {
					       object_t aux_2645;
					       aux_2645 = (object_t) (obj_1721);
					       aux_2644 = OBJECT_WIDENING(aux_2645);
					    }
					    ((((class_t) CREF(aux_2644))->slots) = ((obj_t) BNIL), BUNSPEC);
					 }
				      }
				      {
					 obj_t cur_2649;
					 cur_2649 = CDR(cur_1124);
					 cur_1124 = cur_2649;
					 goto loop_1127;
				      }
				   }
				 else
				   {
				      obj_t arg1888_1157;
				      {
					 obj_t arg1890_1158;
					 {
					    obj_t arg1892_1159;
					    {
					       obj_t aux_2651;
					       aux_2651 = CAR(cur_1124);
					       arg1892_1159 = CDR(aux_2651);
					    }
					    arg1890_1158 = PROCEDURE_ENTRY(arg1892_1159) (arg1892_1159, BEOA);
					 }
					 arg1888_1157 = append_2_18___r4_pairs_and_lists_6_3(arg1890_1158, access_1126);
				      }
				      {
					 obj_t access_2659;
					 obj_t cur_2657;
					 cur_2657 = CDR(cur_1124);
					 access_2659 = arg1888_1157;
					 access_1126 = access_2659;
					 cur_1124 = cur_2657;
					 goto loop_1127;
				      }
				   }
			      }
			   }
		      }
		 }
	      }
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_module_class()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_class()
{
   module_initialization_70_tools_trace(((long) 0), "MODULE_CLASS");
   module_initialization_70_module_module(((long) 0), "MODULE_CLASS");
   module_initialization_70_module_impuse(((long) 0), "MODULE_CLASS");
   module_initialization_70_module_include(((long) 0), "MODULE_CLASS");
   module_initialization_70_engine_param(((long) 0), "MODULE_CLASS");
   module_initialization_70_tools_shape(((long) 0), "MODULE_CLASS");
   module_initialization_70_tools_error(((long) 0), "MODULE_CLASS");
   module_initialization_70_type_type(((long) 0), "MODULE_CLASS");
   module_initialization_70_type_env(((long) 0), "MODULE_CLASS");
   module_initialization_70_ast_ident(((long) 0), "MODULE_CLASS");
   module_initialization_70_ast_var(((long) 0), "MODULE_CLASS");
   module_initialization_70_ast_env(((long) 0), "MODULE_CLASS");
   module_initialization_70_object_class(((long) 0), "MODULE_CLASS");
   module_initialization_70_object_plain_access_186(((long) 0), "MODULE_CLASS");
   return module_initialization_70_object_wide_access_168(((long) 0), "MODULE_CLASS");
}
