/*===========================================================================*/
/*   (Coerce/convert.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


static obj_t method_init_76_coerce_convert();
extern obj_t user_warning_location_190_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t convert_error_217_coerce_convert(type_t, type_t, obj_t, node_t);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t location_full_fname_231_tools_location(obj_t);
extern obj_t lvtype_node__58_ast_lvtype(node_t);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
extern bool_t type_subclass__90_object_class(type_t, type_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t current_function_76_tools_error();
extern obj_t module_initialization_70_coerce_convert(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_coercion(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_lvtype(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t runtime_type_error_216_coerce_convert(obj_t, obj_t, obj_t);
extern bool_t sub_type__174_type_env(type_t, type_t);
extern long class_num_218___object(obj_t);
extern obj_t node_ast_node;
static obj_t imported_modules_init_94_coerce_convert();
static obj_t make_one_conversion_147_coerce_convert(obj_t, type_t, type_t, obj_t, obj_t, obj_t);
extern node_t coerce__182_coerce_coerce(node_t, type_t);
static node_t skip_let_var_187_coerce_convert(node_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_coerce_convert();
static obj_t type_error_location_103_coerce_convert(obj_t, obj_t, type_t, type_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_coerce_convert();
extern obj_t _unsafe_type__146_engine_param;
static obj_t _convert__140_coerce_convert(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern node_t top_level_sexp__node_204_ast_sexp(obj_t, obj_t);
extern obj_t class_object_class;
static obj_t make_one_class_conversion_131_coerce_convert(obj_t, type_t, type_t, obj_t, obj_t, obj_t);
extern node_t convert__122_coerce_convert(node_t, type_t, type_t);
extern obj_t bigloo_type_error_msg_127___error(obj_t, obj_t, obj_t);
extern obj_t _compiler_debug__134_engine_param;
static obj_t do_convert_128_coerce_convert(obj_t, obj_t, type_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern type_t get_aliased_type_1_type_type(type_t);
static obj_t _runtime_type_error_144_coerce_convert(obj_t, obj_t, obj_t, obj_t);
static node_t make_one_type_conversion_101_coerce_convert(obj_t, type_t, type_t, obj_t, obj_t, obj_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t find_coercer_15_type_coercion(type_t, type_t);
static obj_t require_initialization_114_coerce_convert = BUNSPEC;
static obj_t cnst_init_137_coerce_convert();
extern obj_t user_error_location_137_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t runtime_type_error_id_5_coerce_convert(obj_t, obj_t, obj_t);
static obj_t __cnst[14];

DEFINE_EXPORT_PROCEDURE(runtime_type_error_env_213_coerce_convert, _runtime_type_error_144_coerce_convert2000, _runtime_type_error_144_coerce_convert, 0L, 3);
DEFINE_EXPORT_PROCEDURE(convert__env_238_coerce_convert, _convert__140_coerce_convert2001, _convert__140_coerce_convert, 0L, 3);
DEFINE_STRING(string1992_coerce_convert, string1992_coerce_convert2002, "AUX2 IF COERCER BIGLOO-TYPE-ERROR FAILURE QUOTE __ERROR BIGLOO-TYPE-ERROR/LOCATION @ BEGIN LOCATION ::OBJ LET AUX ", 114);
DEFINE_STRING(string1991_coerce_convert, string1991_coerce_convert2003, "Illegal converter", 17);
DEFINE_STRING(string1989_coerce_convert, string1989_coerce_convert2004, "Illegal conversion", 18);
DEFINE_STRING(string1990_coerce_convert, string1990_coerce_convert2005, "do-convert", 10);
DEFINE_STRING(string1988_coerce_convert, string1988_coerce_convert2006, "Type error", 10);
DEFINE_STRING(string1987_coerce_convert, string1987_coerce_convert2007, "", 0);


/* module-initialization */ obj_t 
module_initialization_70_coerce_convert(long checksum_1846, char *from_1847)
{
   if (CBOOL(require_initialization_114_coerce_convert))
     {
	require_initialization_114_coerce_convert = BBOOL(((bool_t) 0));
	library_modules_init_112_coerce_convert();
	cnst_init_137_coerce_convert();
	imported_modules_init_94_coerce_convert();
	method_init_76_coerce_convert();
	toplevel_init_63_coerce_convert();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_coerce_convert()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "COERCE_CONVERT");
   module_initialization_70___object(((long) 0), "COERCE_CONVERT");
   module_initialization_70___error(((long) 0), "COERCE_CONVERT");
   module_initialization_70___reader(((long) 0), "COERCE_CONVERT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "COERCE_CONVERT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_coerce_convert()
{
   {
      obj_t cnst_port_138_1838;
      cnst_port_138_1838 = open_input_string(string1992_coerce_convert);
      {
	 long i_1839;
	 i_1839 = ((long) 13);
       loop_1840:
	 {
	    bool_t test1993_1841;
	    test1993_1841 = (i_1839 == ((long) -1));
	    if (test1993_1841)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1994_1842;
		    {
		       obj_t list1995_1843;
		       {
			  obj_t arg1998_1844;
			  arg1998_1844 = BNIL;
			  list1995_1843 = MAKE_PAIR(cnst_port_138_1838, arg1998_1844);
		       }
		       arg1994_1842 = read___reader(list1995_1843);
		    }
		    CNST_TABLE_SET(i_1839, arg1994_1842);
		 }
		 {
		    int aux_1845;
		    {
		       long aux_1867;
		       aux_1867 = (i_1839 - ((long) 1));
		       aux_1845 = (int) (aux_1867);
		    }
		    {
		       long i_1870;
		       i_1870 = (long) (aux_1845);
		       i_1839 = i_1870;
		       goto loop_1840;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_coerce_convert()
{
   return BUNSPEC;
}


/* type-error/location */ obj_t 
type_error_location_103_coerce_convert(obj_t loc_33, obj_t function_34, type_t from_35, type_t to_36)
{
   {
      obj_t arg1504_873;
      {
	 obj_t arg1510_876;
	 obj_t arg1511_877;
	 {
	    obj_t aux_1872;
	    aux_1872 = (((type_t) CREF(to_36))->id);
	    arg1510_876 = SYMBOL_TO_STRING(aux_1872);
	 }
	 {
	    obj_t aux_1875;
	    aux_1875 = (((type_t) CREF(from_35))->id);
	    arg1511_877 = SYMBOL_TO_STRING(aux_1875);
	 }
	 arg1504_873 = bigloo_type_error_msg_127___error(string1987_coerce_convert, arg1510_876, arg1511_877);
      }
      return user_error_location_137_tools_error(loc_33, function_34, string1988_coerce_convert, arg1504_873, BNIL);
   }
}


/* runtime-type-error */ obj_t 
runtime_type_error_216_coerce_convert(obj_t loc_41, obj_t ti_42, obj_t value_43)
{
   {
      {
	 bool_t test1525_889;
	 test1525_889 = is_a__118___object(value_43, node_ast_node);
	 if (test1525_889)
	   {
	      node_t aux_1882;
	      {
		 obj_t aux_891;
		 aux_891 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 0)), BEOA);
		 {
		    node_t res_892;
		    {
		       obj_t arg1529_895;
		       {
			  obj_t arg1530_896;
			  obj_t arg1531_897;
			  obj_t arg1532_898;
			  arg1530_896 = CNST_TABLE_REF(((long) 1));
			  {
			     obj_t arg1539_904;
			     {
				obj_t arg1545_908;
				{
				   obj_t arg1553_913;
				   {
				      obj_t list1555_915;
				      {
					 obj_t arg1556_916;
					 {
					    obj_t aux_1887;
					    aux_1887 = CNST_TABLE_REF(((long) 2));
					    arg1556_916 = MAKE_PAIR(aux_1887, BNIL);
					 }
					 list1555_915 = MAKE_PAIR(aux_891, arg1556_916);
				      }
				      arg1553_913 = symbol_append_197___r4_symbols_6_4(list1555_915);
				   }
				   arg1545_908 = mark_symbol_non_user__17_ast_ident(arg1553_913);
				}
				{
				   obj_t list1549_910;
				   {
				      obj_t arg1550_911;
				      arg1550_911 = MAKE_PAIR(BNIL, BNIL);
				      list1549_910 = MAKE_PAIR(BUNSPEC, arg1550_911);
				   }
				   arg1539_904 = cons__138___r4_pairs_and_lists_6_3(arg1545_908, list1549_910);
				}
			     }
			     {
				obj_t list1541_906;
				list1541_906 = MAKE_PAIR(BNIL, BNIL);
				arg1531_897 = cons__138___r4_pairs_and_lists_6_3(arg1539_904, list1541_906);
			     }
			  }
			  arg1532_898 = runtime_type_error_id_5_coerce_convert(ti_42, loc_41, aux_891);
			  {
			     obj_t list1534_900;
			     {
				obj_t arg1535_901;
				{
				   obj_t arg1536_902;
				   arg1536_902 = MAKE_PAIR(BNIL, BNIL);
				   arg1535_901 = MAKE_PAIR(arg1532_898, arg1536_902);
				}
				list1534_900 = MAKE_PAIR(arg1531_897, arg1535_901);
			     }
			     arg1529_895 = cons__138___r4_pairs_and_lists_6_3(arg1530_896, list1534_900);
			  }
		       }
		       res_892 = top_level_sexp__node_204_ast_sexp(arg1529_895, loc_41);
		    }
		    {
		       {
			  obj_t aux_1904;
			  {
			     obj_t aux_1905;
			     {
				let_var_6_t obj_1618;
				obj_1618 = (let_var_6_t) (res_892);
				aux_1905 = (((let_var_6_t) CREF(obj_1618))->bindings);
			     }
			     aux_1904 = CAR(aux_1905);
			  }
			  SET_CDR(aux_1904, value_43);
		       }
		       aux_1882 = res_892;
		    }
		 }
	      }
	      return (obj_t) (aux_1882);
	   }
	 else
	   {
	      return runtime_type_error_id_5_coerce_convert(ti_42, loc_41, value_43);
	   }
      }
   }
}


/* runtime-type-error/id */ obj_t 
runtime_type_error_id_5_coerce_convert(obj_t ti_1835, obj_t loc_1834, obj_t id_919)
{
   {
      bool_t test1560_921;
      {
	 bool_t test1668_1002;
	 {
	    bool_t test1669_1003;
	    {
	       long n1_1622;
	       n1_1622 = (long) CINT(_bdb_debug__1_engine_param);
	       test1669_1003 = (n1_1622 > ((long) 0));
	    }
	    if (test1669_1003)
	      {
		 test1668_1002 = ((bool_t) 1);
	      }
	    else
	      {
		 long n1_1624;
		 n1_1624 = (long) CINT(_compiler_debug__134_engine_param);
		 test1668_1002 = (n1_1624 > ((long) 0));
	      }
	 }
	 if (test1668_1002)
	   {
	      if (STRUCTP(loc_1834))
		{
		   obj_t aux_1922;
		   obj_t aux_1920;
		   aux_1922 = CNST_TABLE_REF(((long) 3));
		   aux_1920 = STRUCT_KEY(loc_1834);
		   test1560_921 = (aux_1920 == aux_1922);
		}
	      else
		{
		   test1560_921 = ((bool_t) 0);
		}
	   }
	 else
	   {
	      test1560_921 = ((bool_t) 0);
	   }
      }
      if (test1560_921)
	{
	   obj_t arg1561_922;
	   obj_t arg1562_923;
	   obj_t arg1563_924;
	   arg1561_922 = CNST_TABLE_REF(((long) 4));
	   {
	      obj_t arg1570_930;
	      obj_t arg1572_931;
	      obj_t arg1573_932;
	      obj_t arg1575_933;
	      obj_t arg1578_934;
	      {
		 obj_t arg1588_943;
		 obj_t arg1589_944;
		 obj_t arg1592_945;
		 arg1588_943 = CNST_TABLE_REF(((long) 5));
		 arg1589_944 = CNST_TABLE_REF(((long) 6));
		 arg1592_945 = CNST_TABLE_REF(((long) 7));
		 {
		    obj_t list1594_947;
		    {
		       obj_t arg1595_948;
		       {
			  obj_t arg1598_949;
			  arg1598_949 = MAKE_PAIR(BNIL, BNIL);
			  arg1595_948 = MAKE_PAIR(arg1592_945, arg1598_949);
		       }
		       list1594_947 = MAKE_PAIR(arg1589_944, arg1595_948);
		    }
		    arg1570_930 = cons__138___r4_pairs_and_lists_6_3(arg1588_943, list1594_947);
		 }
	      }
	      {
		 obj_t arg1602_951;
		 obj_t arg1603_952;
		 arg1602_951 = CNST_TABLE_REF(((long) 8));
		 arg1603_952 = current_function_76_tools_error();
		 {
		    obj_t list1606_954;
		    {
		       obj_t arg1607_955;
		       arg1607_955 = MAKE_PAIR(BNIL, BNIL);
		       list1606_954 = MAKE_PAIR(arg1603_952, arg1607_955);
		    }
		    arg1572_931 = cons__138___r4_pairs_and_lists_6_3(arg1602_951, list1606_954);
		 }
	      }
	      arg1573_932 = SYMBOL_TO_STRING(ti_1835);
	      arg1575_933 = location_full_fname_231_tools_location(loc_1834);
	      arg1578_934 = STRUCT_REF(loc_1834, ((long) 1));
	      {
		 obj_t list1581_936;
		 {
		    obj_t arg1582_937;
		    {
		       obj_t arg1583_938;
		       {
			  obj_t arg1584_939;
			  {
			     obj_t arg1585_940;
			     {
				obj_t arg1586_941;
				arg1586_941 = MAKE_PAIR(BNIL, BNIL);
				arg1585_940 = MAKE_PAIR(arg1578_934, arg1586_941);
			     }
			     arg1584_939 = MAKE_PAIR(arg1575_933, arg1585_940);
			  }
			  arg1583_938 = MAKE_PAIR(id_919, arg1584_939);
		       }
		       arg1582_937 = MAKE_PAIR(arg1573_932, arg1583_938);
		    }
		    list1581_936 = MAKE_PAIR(arg1572_931, arg1582_937);
		 }
		 arg1562_923 = cons__138___r4_pairs_and_lists_6_3(arg1570_930, list1581_936);
	      }
	   }
	   {
	      obj_t arg1609_957;
	      arg1609_957 = CNST_TABLE_REF(((long) 9));
	      {
		 obj_t list1611_959;
		 {
		    obj_t arg1612_960;
		    {
		       obj_t arg1613_961;
		       {
			  obj_t arg1615_962;
			  arg1615_962 = MAKE_PAIR(BNIL, BNIL);
			  arg1613_961 = MAKE_PAIR(BFALSE, arg1615_962);
		       }
		       arg1612_960 = MAKE_PAIR(BFALSE, arg1613_961);
		    }
		    list1611_959 = MAKE_PAIR(BFALSE, arg1612_960);
		 }
		 arg1563_924 = cons__138___r4_pairs_and_lists_6_3(arg1609_957, list1611_959);
	      }
	   }
	   {
	      obj_t list1565_926;
	      {
		 obj_t arg1566_927;
		 {
		    obj_t arg1568_928;
		    arg1568_928 = MAKE_PAIR(BNIL, BNIL);
		    arg1566_927 = MAKE_PAIR(arg1563_924, arg1568_928);
		 }
		 list1565_926 = MAKE_PAIR(arg1562_923, arg1566_927);
	      }
	      return cons__138___r4_pairs_and_lists_6_3(arg1561_922, list1565_926);
	   }
	}
      else
	{
	   obj_t arg1618_964;
	   obj_t arg1620_965;
	   obj_t arg1621_966;
	   arg1618_964 = CNST_TABLE_REF(((long) 4));
	   {
	      obj_t arg1628_972;
	      obj_t arg1630_973;
	      obj_t arg1632_974;
	      {
		 obj_t arg1641_981;
		 obj_t arg1645_982;
		 obj_t arg1646_983;
		 arg1641_981 = CNST_TABLE_REF(((long) 5));
		 arg1645_982 = CNST_TABLE_REF(((long) 10));
		 arg1646_983 = CNST_TABLE_REF(((long) 7));
		 {
		    obj_t list1648_985;
		    {
		       obj_t arg1649_986;
		       {
			  obj_t arg1650_987;
			  arg1650_987 = MAKE_PAIR(BNIL, BNIL);
			  arg1649_986 = MAKE_PAIR(arg1646_983, arg1650_987);
		       }
		       list1648_985 = MAKE_PAIR(arg1645_982, arg1649_986);
		    }
		    arg1628_972 = cons__138___r4_pairs_and_lists_6_3(arg1641_981, list1648_985);
		 }
	      }
	      {
		 obj_t arg1653_989;
		 obj_t arg1654_990;
		 arg1653_989 = CNST_TABLE_REF(((long) 8));
		 arg1654_990 = current_function_76_tools_error();
		 {
		    obj_t list1656_992;
		    {
		       obj_t arg1657_993;
		       arg1657_993 = MAKE_PAIR(BNIL, BNIL);
		       list1656_992 = MAKE_PAIR(arg1654_990, arg1657_993);
		    }
		    arg1630_973 = cons__138___r4_pairs_and_lists_6_3(arg1653_989, list1656_992);
		 }
	      }
	      arg1632_974 = SYMBOL_TO_STRING(ti_1835);
	      {
		 obj_t list1634_976;
		 {
		    obj_t arg1636_977;
		    {
		       obj_t arg1638_978;
		       {
			  obj_t arg1639_979;
			  arg1639_979 = MAKE_PAIR(BNIL, BNIL);
			  arg1638_978 = MAKE_PAIR(id_919, arg1639_979);
		       }
		       arg1636_977 = MAKE_PAIR(arg1632_974, arg1638_978);
		    }
		    list1634_976 = MAKE_PAIR(arg1630_973, arg1636_977);
		 }
		 arg1620_965 = cons__138___r4_pairs_and_lists_6_3(arg1628_972, list1634_976);
	      }
	   }
	   {
	      obj_t arg1659_995;
	      arg1659_995 = CNST_TABLE_REF(((long) 9));
	      {
		 obj_t list1662_997;
		 {
		    obj_t arg1663_998;
		    {
		       obj_t arg1665_999;
		       {
			  obj_t arg1666_1000;
			  arg1666_1000 = MAKE_PAIR(BNIL, BNIL);
			  arg1665_999 = MAKE_PAIR(BFALSE, arg1666_1000);
		       }
		       arg1663_998 = MAKE_PAIR(BFALSE, arg1665_999);
		    }
		    list1662_997 = MAKE_PAIR(BFALSE, arg1663_998);
		 }
		 arg1621_966 = cons__138___r4_pairs_and_lists_6_3(arg1659_995, list1662_997);
	      }
	   }
	   {
	      obj_t list1623_968;
	      {
		 obj_t arg1624_969;
		 {
		    obj_t arg1625_970;
		    arg1625_970 = MAKE_PAIR(BNIL, BNIL);
		    arg1624_969 = MAKE_PAIR(arg1621_966, arg1625_970);
		 }
		 list1623_968 = MAKE_PAIR(arg1620_965, arg1624_969);
	      }
	      return cons__138___r4_pairs_and_lists_6_3(arg1618_964, list1623_968);
	   }
	}
   }
}


/* _runtime-type-error */ obj_t 
_runtime_type_error_144_coerce_convert(obj_t env_1826, obj_t loc_1827, obj_t ti_1828, obj_t value_1829)
{
   return runtime_type_error_216_coerce_convert(loc_1827, ti_1828, value_1829);
}


/* convert-error */ obj_t 
convert_error_217_coerce_convert(type_t from_44, type_t to_45, obj_t loc_46, node_t node_47)
{
   {
      bool_t test1670_1006;
      {
	 bool_t test1677_1013;
	 {
	    obj_t obj2_1640;
	    obj2_1640 = _obj__252_type_cache;
	    {
	       obj_t aux_1989;
	       aux_1989 = (obj_t) (to_45);
	       test1677_1013 = (aux_1989 == obj2_1640);
	    }
	 }
	 if (test1677_1013)
	   {
	      test1670_1006 = ((bool_t) 0);
	   }
	 else
	   {
	      test1670_1006 = sub_type__174_type_env(to_45, (type_t) (_obj__252_type_cache));
	   }
      }
      if (test1670_1006)
	{
	   obj_t unsafe_type_48_1007;
	   unsafe_type_48_1007 = _unsafe_type__146_engine_param;
	   _unsafe_type__146_engine_param = BTRUE;
	   {
	      obj_t arg1672_1008;
	      arg1672_1008 = current_function_76_tools_error();
	      {
		 obj_t arg1516_1646;
		 {
		    obj_t arg1518_1648;
		    obj_t arg1519_1649;
		    {
		       obj_t aux_1997;
		       aux_1997 = (((type_t) CREF(to_45))->id);
		       arg1518_1648 = SYMBOL_TO_STRING(aux_1997);
		    }
		    {
		       obj_t aux_2000;
		       aux_2000 = (((type_t) CREF(from_44))->id);
		       arg1519_1649 = SYMBOL_TO_STRING(aux_2000);
		    }
		    arg1516_1646 = bigloo_type_error_msg_127___error(string1987_coerce_convert, arg1518_1648, arg1519_1649);
		 }
		 user_warning_location_190_tools_error(loc_46, arg1672_1008, string1988_coerce_convert, arg1516_1646);
	      }
	   }
	   {
	      node_t res_1009;
	      {
		 obj_t arg1673_1010;
		 arg1673_1010 = runtime_type_error_216_coerce_convert(loc_46, (((type_t) CREF(to_45))->id), (obj_t) (node_47));
		 res_1009 = coerce__182_coerce_coerce((node_t) (arg1673_1010), from_44);
	      }
	      _unsafe_type__146_engine_param = unsafe_type_48_1007;
	      return (obj_t) (res_1009);
	   }
	}
      else
	{
	   obj_t arg1676_1012;
	   arg1676_1012 = current_function_76_tools_error();
	   return type_error_location_103_coerce_convert(loc_46, arg1676_1012, from_44, to_45);
	}
   }
}


/* convert! */ node_t 
convert__122_coerce_convert(node_t node_48, type_t from_49, type_t to_50)
{
   {
      type_t to_1014;
      type_t from_1015;
      to_1014 = get_aliased_type_1_type_type(to_50);
      from_1015 = get_aliased_type_1_type_type(from_49);
      {
	 bool_t test_2015;
	 {
	    bool_t test_2016;
	    {
	       obj_t aux_2019;
	       obj_t aux_2017;
	       aux_2019 = (obj_t) (to_1014);
	       aux_2017 = (obj_t) (from_1015);
	       test_2016 = (aux_2017 == aux_2019);
	    }
	    if (test_2016)
	      {
		 test_2015 = ((bool_t) 1);
	      }
	    else
	      {
		 test_2015 = (((type_t) CREF(from_1015))->magic__53);
	      }
	 }
	 if (test_2015)
	   {
	      return node_48;
	   }
	 else
	   {
	      obj_t coercer_1017;
	      obj_t loc_1018;
	      coercer_1017 = find_coercer_15_type_coercion(from_1015, to_1014);
	      loc_1018 = (((node_t) CREF(node_48))->loc);
	      {
		 bool_t test_2025;
		 if (STRUCTP(coercer_1017))
		   {
		      obj_t aux_2030;
		      obj_t aux_2028;
		      aux_2030 = CNST_TABLE_REF(((long) 11));
		      aux_2028 = STRUCT_KEY(coercer_1017);
		      test_2025 = (aux_2028 == aux_2030);
		   }
		 else
		   {
		      test_2025 = ((bool_t) 0);
		   }
		 if (test_2025)
		   {
		      {
			 obj_t checks_1022;
			 obj_t coerces_1023;
			 obj_t node_1024;
			 {
			    obj_t aux_2033;
			    checks_1022 = STRUCT_REF(coercer_1017, ((long) 2));
			    coerces_1023 = STRUCT_REF(coercer_1017, ((long) 3));
			    node_1024 = (obj_t) (node_48);
			  loop_1025:
			    if (NULLP(checks_1022))
			      {
				 if (NULLP(coerces_1023))
				   {
				      aux_2033 = node_1024;
				   }
				 else
				   {
				      obj_t arg1683_1029;
				      obj_t arg1684_1030;
				      arg1683_1029 = shape_tools_shape((obj_t) (from_1015));
				      arg1684_1030 = shape_tools_shape((obj_t) (to_1014));
				      aux_2033 = internal_error_43_tools_error(string1989_coerce_convert, arg1683_1029, arg1684_1030);
				   }
			      }
			    else
			      {
				 if (NULLP(coerces_1023))
				   {
				      {
					 obj_t arg1688_1033;
					 obj_t arg1689_1034;
					 arg1688_1033 = shape_tools_shape((obj_t) (from_1015));
					 arg1689_1034 = shape_tools_shape((obj_t) (to_1014));
					 aux_2033 = internal_error_43_tools_error(string1989_coerce_convert, arg1688_1033, arg1689_1034);
				      }
				   }
				 else
				   {
				      {
					 obj_t arg1691_1035;
					 obj_t arg1692_1036;
					 obj_t arg1693_1037;
					 arg1691_1035 = CDR(checks_1022);
					 arg1692_1036 = CDR(coerces_1023);
					 arg1693_1037 = make_one_conversion_147_coerce_convert(CAR(checks_1022), from_1015, to_1014, CAR(checks_1022), CAR(coerces_1023), node_1024);
					 {
					    obj_t node_2058;
					    obj_t coerces_2057;
					    obj_t checks_2056;
					    checks_2056 = arg1691_1035;
					    coerces_2057 = arg1692_1036;
					    node_2058 = arg1693_1037;
					    node_1024 = node_2058;
					    coerces_1023 = coerces_2057;
					    checks_1022 = checks_2056;
					    goto loop_1025;
					 }
				      }
				   }
			      }
			    return (node_t) (aux_2033);
			 }
		      }
		   }
		 else
		   {
		      obj_t aux_2063;
		      aux_2063 = convert_error_217_coerce_convert(from_1015, to_1014, loc_1018, node_48);
		      return (node_t) (aux_2063);
		   }
	      }
	   }
      }
   }
}


/* _convert! */ obj_t 
_convert__140_coerce_convert(obj_t env_1830, obj_t node_1831, obj_t from_1832, obj_t to_1833)
{
   {
      node_t aux_2066;
      aux_2066 = convert__122_coerce_convert((node_t) (node_1831), (type_t) (from_1832), (type_t) (to_1833));
      return (obj_t) (aux_2066);
   }
}


/* make-one-conversion */ obj_t 
make_one_conversion_147_coerce_convert(obj_t id_from_153_51, type_t from_52, type_t to_53, obj_t checkop_54, obj_t coerceop_55, obj_t node_56)
{
   {
      bool_t test1699_1042;
      if (NULLP(checkop_54))
	{
	   test1699_1042 = ((bool_t) 1);
	}
      else
	{
	   test1699_1042 = CBOOL(_unsafe_type__146_engine_param);
	}
      if (test1699_1042)
	{
	   return do_convert_128_coerce_convert(coerceop_55, node_56, from_52);
	}
      else
	{
	   bool_t test1700_1043;
	   test1700_1043 = is_a__118___object((obj_t) (from_52), class_object_class);
	   if (test1700_1043)
	     {
		return make_one_class_conversion_131_coerce_convert(id_from_153_51, from_52, to_53, checkop_54, coerceop_55, node_56);
	     }
	   else
	     {
		node_t aux_2081;
		aux_2081 = make_one_type_conversion_101_coerce_convert(id_from_153_51, from_52, to_53, checkop_54, coerceop_55, node_56);
		return (obj_t) (aux_2081);
	     }
	}
   }
}


/* skip-let-var */ node_t 
skip_let_var_187_coerce_convert(node_t node_57)
{
 skip_let_var_187_coerce_convert:
   {
      bool_t test1702_1045;
      test1702_1045 = is_a__118___object((obj_t) (node_57), let_var_6_ast_node);
      if (test1702_1045)
	{
	   node_t node_2087;
	   {
	      let_var_6_t obj_1686;
	      obj_1686 = (let_var_6_t) (node_57);
	      node_2087 = (((let_var_6_t) CREF(obj_1686))->body);
	   }
	   node_57 = node_2087;
	   goto skip_let_var_187_coerce_convert;
	}
      else
	{
	   return node_57;
	}
   }
}


/* make-one-type-conversion */ node_t 
make_one_type_conversion_101_coerce_convert(obj_t id_from_153_58, type_t from_59, type_t to_60, obj_t check_op_210_61, obj_t coerce_op_79_62, obj_t node_63)
{
   {
      obj_t aux_1047;
      {
	 obj_t arg1767_1101;
	 arg1767_1101 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 0)), BEOA);
	 aux_1047 = mark_symbol_non_user__17_ast_ident(arg1767_1101);
      }
      {
	 obj_t loc_1048;
	 {
	    node_t obj_1687;
	    obj_1687 = (node_t) (node_63);
	    loc_1048 = (((node_t) CREF(obj_1687))->loc);
	 }
	 {
	    node_t lnode_1049;
	    {
	       obj_t arg1714_1063;
	       {
		  obj_t arg1716_1064;
		  obj_t arg1717_1065;
		  obj_t arg1718_1066;
		  arg1716_1064 = CNST_TABLE_REF(((long) 1));
		  {
		     obj_t arg1725_1072;
		     {
			obj_t arg1729_1076;
			{
			   obj_t arg1738_1081;
			   {
			      obj_t list1740_1083;
			      {
				 obj_t arg1743_1084;
				 {
				    obj_t arg1744_1085;
				    {
				       obj_t aux_2097;
				       aux_2097 = (((type_t) CREF(from_59))->id);
				       arg1744_1085 = MAKE_PAIR(aux_2097, BNIL);
				    }
				    arg1743_1084 = MAKE_PAIR(_4dots_199_tools_misc, arg1744_1085);
				 }
				 list1740_1083 = MAKE_PAIR(aux_1047, arg1743_1084);
			      }
			      arg1738_1081 = symbol_append_197___r4_symbols_6_4(list1740_1083);
			   }
			   arg1729_1076 = mark_symbol_non_user__17_ast_ident(arg1738_1081);
			}
			{
			   obj_t list1731_1078;
			   {
			      obj_t arg1732_1079;
			      arg1732_1079 = MAKE_PAIR(BNIL, BNIL);
			      list1731_1078 = MAKE_PAIR(BUNSPEC, arg1732_1079);
			   }
			   arg1725_1072 = cons__138___r4_pairs_and_lists_6_3(arg1729_1076, list1731_1078);
			}
		     }
		     {
			obj_t list1727_1074;
			list1727_1074 = MAKE_PAIR(BNIL, BNIL);
			arg1717_1065 = cons__138___r4_pairs_and_lists_6_3(arg1725_1072, list1727_1074);
		     }
		  }
		  {
		     obj_t arg1746_1087;
		     obj_t arg1747_1088;
		     obj_t arg1748_1089;
		     arg1746_1087 = CNST_TABLE_REF(((long) 12));
		     {
			obj_t list1761_1097;
			{
			   obj_t arg1762_1098;
			   arg1762_1098 = MAKE_PAIR(BNIL, BNIL);
			   list1761_1097 = MAKE_PAIR(aux_1047, arg1762_1098);
			}
			arg1747_1088 = cons__138___r4_pairs_and_lists_6_3(check_op_210_61, list1761_1097);
		     }
		     arg1748_1089 = runtime_type_error_216_coerce_convert(loc_1048, (((type_t) CREF(to_60))->id), aux_1047);
		     {
			obj_t list1750_1091;
			{
			   obj_t arg1753_1092;
			   {
			      obj_t arg1755_1093;
			      {
				 obj_t arg1758_1094;
				 arg1758_1094 = MAKE_PAIR(BNIL, BNIL);
				 arg1755_1093 = MAKE_PAIR(arg1748_1089, arg1758_1094);
			      }
			      arg1753_1092 = MAKE_PAIR(aux_1047, arg1755_1093);
			   }
			   list1750_1091 = MAKE_PAIR(arg1747_1088, arg1753_1092);
			}
			arg1718_1066 = cons__138___r4_pairs_and_lists_6_3(arg1746_1087, list1750_1091);
		     }
		  }
		  {
		     obj_t list1721_1068;
		     {
			obj_t arg1722_1069;
			{
			   obj_t arg1723_1070;
			   arg1723_1070 = MAKE_PAIR(BNIL, BNIL);
			   arg1722_1069 = MAKE_PAIR(arg1718_1066, arg1723_1070);
			}
			list1721_1068 = MAKE_PAIR(arg1717_1065, arg1722_1069);
		     }
		     arg1714_1063 = cons__138___r4_pairs_and_lists_6_3(arg1716_1064, list1721_1068);
		  }
	       }
	       lnode_1049 = top_level_sexp__node_204_ast_sexp(arg1714_1063, loc_1048);
	    }
	    {
	       lvtype_node__58_ast_lvtype(lnode_1049);
	       {
		  obj_t var_1050;
		  {
		     obj_t aux_2126;
		     {
			obj_t aux_2127;
			{
			   let_var_6_t obj_1690;
			   obj_1690 = (let_var_6_t) (lnode_1049);
			   aux_2127 = (((let_var_6_t) CREF(obj_1690))->bindings);
			}
			aux_2126 = CAR(aux_2127);
		     }
		     var_1050 = CAR(aux_2126);
		  }
		  {
		     obj_t coerce_app_174_1051;
		     {
			var_t arg1708_1057;
			{
			   var_t res1983_1703;
			   {
			      variable_t variable_1695;
			      variable_1695 = (variable_t) (var_1050);
			      {
				 var_t new1207_1696;
				 new1207_1696 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				 {
				    long arg1944_1697;
				    arg1944_1697 = class_num_218___object(var_ast_node);
				    {
				       obj_t obj_1701;
				       obj_1701 = (obj_t) (new1207_1696);
				       (((obj_t) CREF(obj_1701))->header = MAKE_HEADER(arg1944_1697, 0), BUNSPEC);
				    }
				 }
				 {
				    object_t aux_2137;
				    aux_2137 = (object_t) (new1207_1696);
				    OBJECT_WIDENING_SET(aux_2137, BFALSE);
				 }
				 ((((var_t) CREF(new1207_1696))->loc) = ((obj_t) loc_1048), BUNSPEC);
				 ((((var_t) CREF(new1207_1696))->type) = ((type_t) from_59), BUNSPEC);
				 ((((var_t) CREF(new1207_1696))->variable) = ((variable_t) variable_1695), BUNSPEC);
				 res1983_1703 = new1207_1696;
			      }
			   }
			   arg1708_1057 = res1983_1703;
			}
			coerce_app_174_1051 = do_convert_128_coerce_convert(coerce_op_79_62, (obj_t) (arg1708_1057), from_59);
		     }
		     {
			node_t condn_1052;
			condn_1052 = skip_let_var_187_coerce_convert(lnode_1049);
			{
			   {
			      local_t obj_1704;
			      obj_1704 = (local_t) (var_1050);
			      ((((local_t) CREF(obj_1704))->type) = ((type_t) from_59), BUNSPEC);
			   }
			   {
			      obj_t aux_2148;
			      {
				 obj_t aux_2149;
				 {
				    let_var_6_t obj_1706;
				    obj_1706 = (let_var_6_t) (lnode_1049);
				    aux_2149 = (((let_var_6_t) CREF(obj_1706))->bindings);
				 }
				 aux_2148 = CAR(aux_2149);
			      }
			      SET_CDR(aux_2148, node_63);
			   }
			   {
			      conditional_t obj_1710;
			      node_t val1323_1711;
			      obj_1710 = (conditional_t) (condn_1052);
			      val1323_1711 = (node_t) (coerce_app_174_1051);
			      ((((conditional_t) CREF(obj_1710))->true) = ((node_t) val1323_1711), BUNSPEC);
			   }
			   _unsafe_type__146_engine_param = BTRUE;
			   {
			      node_t arg1706_1055;
			      {
				 node_t aux_2157;
				 {
				    conditional_t obj_1712;
				    obj_1712 = (conditional_t) (condn_1052);
				    aux_2157 = (((conditional_t) CREF(obj_1712))->false);
				 }
				 arg1706_1055 = coerce__182_coerce_coerce(aux_2157, from_59);
			      }
			      {
				 conditional_t obj_1713;
				 obj_1713 = (conditional_t) (condn_1052);
				 ((((conditional_t) CREF(obj_1713))->false) = ((node_t) arg1706_1055), BUNSPEC);
			      }
			   }
			   _unsafe_type__146_engine_param = BFALSE;
			   return lnode_1049;
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* make-one-class-conversion */ obj_t 
make_one_class_conversion_131_coerce_convert(obj_t id_from_153_64, type_t from_65, type_t to_66, obj_t check_op_210_67, obj_t coerce_op_79_68, obj_t node_69)
{
   {
      bool_t test1769_1103;
      {
	 bool_t test1867_1192;
	 test1867_1192 = is_a__118___object((obj_t) (to_66), class_object_class);
	 if (test1867_1192)
	   {
	      test1769_1103 = type_subclass__90_object_class(from_65, to_66);
	   }
	 else
	   {
	      test1769_1103 = ((bool_t) 0);
	   }
      }
      if (test1769_1103)
	{
	   return do_convert_128_coerce_convert(coerce_op_79_68, node_69, from_65);
	}
      else
	{
	   obj_t aux_1104;
	   aux_1104 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 0)), BEOA);
	   {
	      obj_t aux2_1105;
	      aux2_1105 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 13)), BEOA);
	      {
		 obj_t loc_1106;
		 {
		    node_t obj_1716;
		    obj_1716 = (node_t) (node_69);
		    loc_1106 = (((node_t) CREF(obj_1716))->loc);
		 }
		 {
		    node_t lnode_1107;
		    {
		       obj_t arg1794_1131;
		       {
			  obj_t arg1795_1132;
			  obj_t arg1796_1133;
			  obj_t arg1797_1134;
			  arg1795_1132 = CNST_TABLE_REF(((long) 1));
			  {
			     obj_t arg1805_1140;
			     {
				obj_t arg1809_1144;
				{
				   obj_t arg1814_1149;
				   {
				      obj_t list1816_1151;
				      {
					 obj_t arg1817_1152;
					 {
					    obj_t aux_2178;
					    aux_2178 = CNST_TABLE_REF(((long) 2));
					    arg1817_1152 = MAKE_PAIR(aux_2178, BNIL);
					 }
					 list1816_1151 = MAKE_PAIR(aux_1104, arg1817_1152);
				      }
				      arg1814_1149 = symbol_append_197___r4_symbols_6_4(list1816_1151);
				   }
				   arg1809_1144 = mark_symbol_non_user__17_ast_ident(arg1814_1149);
				}
				{
				   obj_t list1811_1146;
				   {
				      obj_t arg1812_1147;
				      arg1812_1147 = MAKE_PAIR(BNIL, BNIL);
				      list1811_1146 = MAKE_PAIR(BUNSPEC, arg1812_1147);
				   }
				   arg1805_1140 = cons__138___r4_pairs_and_lists_6_3(arg1809_1144, list1811_1146);
				}
			     }
			     {
				obj_t list1807_1142;
				list1807_1142 = MAKE_PAIR(BNIL, BNIL);
				arg1796_1133 = cons__138___r4_pairs_and_lists_6_3(arg1805_1140, list1807_1142);
			     }
			  }
			  {
			     obj_t arg1820_1154;
			     obj_t arg1821_1155;
			     obj_t arg1822_1156;
			     arg1820_1154 = CNST_TABLE_REF(((long) 1));
			     {
				obj_t arg1830_1162;
				{
				   obj_t arg1834_1166;
				   {
				      obj_t arg1839_1171;
				      {
					 obj_t list1843_1173;
					 {
					    obj_t arg1847_1174;
					    {
					       obj_t aux_2190;
					       aux_2190 = CNST_TABLE_REF(((long) 2));
					       arg1847_1174 = MAKE_PAIR(aux_2190, BNIL);
					    }
					    list1843_1173 = MAKE_PAIR(aux2_1105, arg1847_1174);
					 }
					 arg1839_1171 = symbol_append_197___r4_symbols_6_4(list1843_1173);
				      }
				      arg1834_1166 = mark_symbol_non_user__17_ast_ident(arg1839_1171);
				   }
				   {
				      obj_t list1836_1168;
				      {
					 obj_t arg1837_1169;
					 arg1837_1169 = MAKE_PAIR(BNIL, BNIL);
					 list1836_1168 = MAKE_PAIR(BUNSPEC, arg1837_1169);
				      }
				      arg1830_1162 = cons__138___r4_pairs_and_lists_6_3(arg1834_1166, list1836_1168);
				   }
				}
				{
				   obj_t list1832_1164;
				   list1832_1164 = MAKE_PAIR(BNIL, BNIL);
				   arg1821_1155 = cons__138___r4_pairs_and_lists_6_3(arg1830_1162, list1832_1164);
				}
			     }
			     {
				obj_t arg1850_1176;
				obj_t arg1851_1177;
				obj_t arg1852_1178;
				arg1850_1176 = CNST_TABLE_REF(((long) 12));
				{
				   obj_t list1861_1186;
				   {
				      obj_t arg1862_1187;
				      arg1862_1187 = MAKE_PAIR(BNIL, BNIL);
				      list1861_1186 = MAKE_PAIR(aux2_1105, arg1862_1187);
				   }
				   arg1851_1177 = cons__138___r4_pairs_and_lists_6_3(check_op_210_67, list1861_1186);
				}
				arg1852_1178 = runtime_type_error_216_coerce_convert(loc_1106, (((type_t) CREF(to_66))->id), aux_1104);
				{
				   obj_t list1854_1180;
				   {
				      obj_t arg1856_1181;
				      {
					 obj_t arg1857_1182;
					 {
					    obj_t arg1858_1183;
					    arg1858_1183 = MAKE_PAIR(BNIL, BNIL);
					    arg1857_1182 = MAKE_PAIR(arg1852_1178, arg1858_1183);
					 }
					 arg1856_1181 = MAKE_PAIR(aux_1104, arg1857_1182);
				      }
				      list1854_1180 = MAKE_PAIR(arg1851_1177, arg1856_1181);
				   }
				   arg1822_1156 = cons__138___r4_pairs_and_lists_6_3(arg1850_1176, list1854_1180);
				}
			     }
			     {
				obj_t list1824_1158;
				{
				   obj_t arg1826_1159;
				   {
				      obj_t arg1827_1160;
				      arg1827_1160 = MAKE_PAIR(BNIL, BNIL);
				      arg1826_1159 = MAKE_PAIR(arg1822_1156, arg1827_1160);
				   }
				   list1824_1158 = MAKE_PAIR(arg1821_1155, arg1826_1159);
				}
				arg1797_1134 = cons__138___r4_pairs_and_lists_6_3(arg1820_1154, list1824_1158);
			     }
			  }
			  {
			     obj_t list1800_1136;
			     {
				obj_t arg1802_1137;
				{
				   obj_t arg1803_1138;
				   arg1803_1138 = MAKE_PAIR(BNIL, BNIL);
				   arg1802_1137 = MAKE_PAIR(arg1797_1134, arg1803_1138);
				}
				list1800_1136 = MAKE_PAIR(arg1796_1133, arg1802_1137);
			     }
			     arg1794_1131 = cons__138___r4_pairs_and_lists_6_3(arg1795_1132, list1800_1136);
			  }
		       }
		       lnode_1107 = top_level_sexp__node_204_ast_sexp(arg1794_1131, loc_1106);
		    }
		    {
		       lvtype_node__58_ast_lvtype(lnode_1107);
		       {
			  obj_t var_1108;
			  {
			     obj_t aux_2222;
			     {
				obj_t aux_2223;
				{
				   let_var_6_t obj_1718;
				   obj_1718 = (let_var_6_t) (lnode_1107);
				   aux_2223 = (((let_var_6_t) CREF(obj_1718))->bindings);
				}
				aux_2222 = CAR(aux_2223);
			     }
			     var_1108 = CAR(aux_2222);
			  }
			  {
			     obj_t coerce_app_174_1109;
			     {
				var_t arg1788_1125;
				{
				   var_t res1984_1731;
				   {
				      variable_t variable_1723;
				      variable_1723 = (variable_t) (var_1108);
				      {
					 var_t new1207_1724;
					 new1207_1724 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
					 {
					    long arg1944_1725;
					    arg1944_1725 = class_num_218___object(var_ast_node);
					    {
					       obj_t obj_1729;
					       obj_1729 = (obj_t) (new1207_1724);
					       (((obj_t) CREF(obj_1729))->header = MAKE_HEADER(arg1944_1725, 0), BUNSPEC);
					    }
					 }
					 {
					    object_t aux_2233;
					    aux_2233 = (object_t) (new1207_1724);
					    OBJECT_WIDENING_SET(aux_2233, BFALSE);
					 }
					 ((((var_t) CREF(new1207_1724))->loc) = ((obj_t) loc_1106), BUNSPEC);
					 ((((var_t) CREF(new1207_1724))->type) = ((type_t) from_65), BUNSPEC);
					 ((((var_t) CREF(new1207_1724))->variable) = ((variable_t) variable_1723), BUNSPEC);
					 res1984_1731 = new1207_1724;
				      }
				   }
				   arg1788_1125 = res1984_1731;
				}
				coerce_app_174_1109 = do_convert_128_coerce_convert(coerce_op_79_68, (obj_t) (arg1788_1125), from_65);
			     }
			     {
				node_t condn_1110;
				condn_1110 = skip_let_var_187_coerce_convert(lnode_1107);
				{
				   {
				      local_t obj_1732;
				      obj_1732 = (local_t) (var_1108);
				      ((((local_t) CREF(obj_1732))->type) = ((type_t) from_65), BUNSPEC);
				   }
				   {
				      obj_t aux_2244;
				      {
					 obj_t aux_2245;
					 {
					    let_var_6_t obj_1734;
					    obj_1734 = (let_var_6_t) (lnode_1107);
					    aux_2245 = (((let_var_6_t) CREF(obj_1734))->bindings);
					 }
					 aux_2244 = CAR(aux_2245);
				      }
				      SET_CDR(aux_2244, node_69);
				   }
				   {
				      obj_t binding2_1113;
				      {
					 obj_t aux_2250;
					 {
					    let_var_6_t obj_1739;
					    {
					       node_t aux_2251;
					       {
						  let_var_6_t obj_1738;
						  obj_1738 = (let_var_6_t) (lnode_1107);
						  aux_2251 = (((let_var_6_t) CREF(obj_1738))->body);
					       }
					       obj_1739 = (let_var_6_t) (aux_2251);
					    }
					    aux_2250 = (((let_var_6_t) CREF(obj_1739))->bindings);
					 }
					 binding2_1113 = CAR(aux_2250);
				      }
				      {
					 cast_t arg1772_1114;
					 {
					    obj_t arg1774_1116;
					    var_t arg1776_1117;
					    arg1774_1116 = _obj__252_type_cache;
					    {
					       var_t res1985_1751;
					       {
						  variable_t variable_1743;
						  variable_1743 = (variable_t) (var_1108);
						  {
						     var_t new1207_1744;
						     new1207_1744 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						     {
							long arg1944_1745;
							arg1944_1745 = class_num_218___object(var_ast_node);
							{
							   obj_t obj_1749;
							   obj_1749 = (obj_t) (new1207_1744);
							   (((obj_t) CREF(obj_1749))->header = MAKE_HEADER(arg1944_1745, 0), BUNSPEC);
							}
						     }
						     {
							object_t aux_2262;
							aux_2262 = (object_t) (new1207_1744);
							OBJECT_WIDENING_SET(aux_2262, BFALSE);
						     }
						     ((((var_t) CREF(new1207_1744))->loc) = ((obj_t) loc_1106), BUNSPEC);
						     ((((var_t) CREF(new1207_1744))->type) = ((type_t) from_65), BUNSPEC);
						     ((((var_t) CREF(new1207_1744))->variable) = ((variable_t) variable_1743), BUNSPEC);
						     res1985_1751 = new1207_1744;
						  }
					       }
					       arg1776_1117 = res1985_1751;
					    }
					    {
					       cast_t res1986_1762;
					       {
						  type_t type_1753;
						  node_t arg_1754;
						  type_1753 = (type_t) (arg1774_1116);
						  arg_1754 = (node_t) (arg1776_1117);
						  {
						     cast_t new1292_1755;
						     new1292_1755 = ((cast_t) BREF(GC_MALLOC(sizeof(struct cast))));
						     {
							long arg1928_1756;
							arg1928_1756 = class_num_218___object(cast_ast_node);
							{
							   obj_t obj_1760;
							   obj_1760 = (obj_t) (new1292_1755);
							   (((obj_t) CREF(obj_1760))->header = MAKE_HEADER(arg1928_1756, 0), BUNSPEC);
							}
						     }
						     {
							object_t aux_2274;
							aux_2274 = (object_t) (new1292_1755);
							OBJECT_WIDENING_SET(aux_2274, BFALSE);
						     }
						     ((((cast_t) CREF(new1292_1755))->loc) = ((obj_t) loc_1106), BUNSPEC);
						     ((((cast_t) CREF(new1292_1755))->type) = ((type_t) type_1753), BUNSPEC);
						     ((((cast_t) CREF(new1292_1755))->arg) = ((node_t) arg_1754), BUNSPEC);
						     res1986_1762 = new1292_1755;
						  }
					       }
					       arg1772_1114 = res1986_1762;
					    }
					 }
					 {
					    obj_t aux_2280;
					    aux_2280 = (obj_t) (arg1772_1114);
					    SET_CDR(binding2_1113, aux_2280);
					 }
				      }
				   }
				   {
				      conditional_t obj_1765;
				      node_t val1323_1766;
				      obj_1765 = (conditional_t) (condn_1110);
				      val1323_1766 = (node_t) (coerce_app_174_1109);
				      ((((conditional_t) CREF(obj_1765))->true) = ((node_t) val1323_1766), BUNSPEC);
				   }
				   _unsafe_type__146_engine_param = BTRUE;
				   {
				      node_t arg1783_1123;
				      {
					 node_t aux_2286;
					 {
					    conditional_t obj_1767;
					    obj_1767 = (conditional_t) (condn_1110);
					    aux_2286 = (((conditional_t) CREF(obj_1767))->false);
					 }
					 arg1783_1123 = coerce__182_coerce_coerce(aux_2286, from_65);
				      }
				      {
					 conditional_t obj_1768;
					 obj_1768 = (conditional_t) (condn_1110);
					 ((((conditional_t) CREF(obj_1768))->false) = ((node_t) arg1783_1123), BUNSPEC);
				      }
				   }
				   _unsafe_type__146_engine_param = BFALSE;
				   return (obj_t) (lnode_1107);
				}
			     }
			  }
		       }
		    }
		 }
	      }
	   }
	}
   }
}


/* do-convert */ obj_t 
do_convert_128_coerce_convert(obj_t coerce_op_79_70, obj_t node_71, type_t from_72)
{
   if (NULLP(coerce_op_79_70))
     {
	return node_71;
     }
   else
     {
	node_t nnode_1194;
	{
	   obj_t arg1892_1214;
	   obj_t arg1893_1215;
	   {
	      obj_t list1895_1217;
	      {
		 obj_t arg1896_1218;
		 arg1896_1218 = MAKE_PAIR(BNIL, BNIL);
		 list1895_1217 = MAKE_PAIR(BUNSPEC, arg1896_1218);
	      }
	      arg1892_1214 = cons__138___r4_pairs_and_lists_6_3(coerce_op_79_70, list1895_1217);
	   }
	   {
	      node_t obj_1771;
	      obj_1771 = (node_t) (node_71);
	      arg1893_1215 = (((node_t) CREF(obj_1771))->loc);
	   }
	   nnode_1194 = top_level_sexp__node_204_ast_sexp(arg1892_1214, arg1893_1215);
	}
	{
	   {
	      bool_t test1869_1195;
	      test1869_1195 = is_a__118___object((obj_t) (nnode_1194), app_ast_node);
	      if (test1869_1195)
		{
		   {
		      obj_t arg1870_1196;
		      {
			 obj_t list1871_1197;
			 list1871_1197 = MAKE_PAIR(node_71, BNIL);
			 arg1870_1196 = list1871_1197;
		      }
		      {
			 app_t obj_1774;
			 obj_1774 = (app_t) (nnode_1194);
			 ((((app_t) CREF(obj_1774))->args) = ((obj_t) arg1870_1196), BUNSPEC);
		      }
		   }
		   return (obj_t) (nnode_1194);
		}
	      else
		{
		   bool_t test1875_1199;
		   test1875_1199 = is_a__118___object((obj_t) (nnode_1194), let_var_6_ast_node);
		   if (test1875_1199)
		     {
			{
			   obj_t bdgs_1200;
			   {
			      let_var_6_t obj_1777;
			      obj_1777 = (let_var_6_t) (nnode_1194);
			      bdgs_1200 = (((let_var_6_t) CREF(obj_1777))->bindings);
			   }
			   {
			      bool_t test_2313;
			      if (NULLP(bdgs_1200))
				{
				   test_2313 = ((bool_t) 1);
				}
			      else
				{
				   bool_t test_2316;
				   {
				      obj_t aux_2317;
				      aux_2317 = CDR(bdgs_1200);
				      test_2316 = NULLP(aux_2317);
				   }
				   if (test_2316)
				     {
					test_2313 = ((bool_t) 0);
				     }
				   else
				     {
					test_2313 = ((bool_t) 1);
				     }
				}
			      if (test_2313)
				{
				   obj_t arg1879_1204;
				   arg1879_1204 = shape_tools_shape(coerce_op_79_70);
				   return internal_error_43_tools_error(string1990_coerce_convert, string1991_coerce_convert, arg1879_1204);
				}
			      else
				{
				   {
				      local_t obj_1783;
				      {
					 obj_t aux_2322;
					 {
					    obj_t aux_2323;
					    aux_2323 = CAR(bdgs_1200);
					    aux_2322 = CAR(aux_2323);
					 }
					 obj_1783 = (local_t) (aux_2322);
				      }
				      ((((local_t) CREF(obj_1783))->type) = ((type_t) from_72), BUNSPEC);
				   }
				   {
				      obj_t aux_2328;
				      aux_2328 = CAR(bdgs_1200);
				      SET_CDR(aux_2328, node_71);
				   }
				   return (obj_t) (nnode_1194);
				}
			   }
			}
		     }
		   else
		     {
			{
			   obj_t arg1890_1213;
			   arg1890_1213 = shape_tools_shape(coerce_op_79_70);
			   return internal_error_43_tools_error(string1990_coerce_convert, string1991_coerce_convert, arg1890_1213);
			}
		     }
		}
	   }
	}
     }
}


/* method-init */ obj_t 
method_init_76_coerce_convert()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_coerce_convert()
{
   module_initialization_70_tools_trace(((long) 0), "COERCE_CONVERT");
   module_initialization_70_engine_param(((long) 0), "COERCE_CONVERT");
   module_initialization_70_tools_shape(((long) 0), "COERCE_CONVERT");
   module_initialization_70_tools_location(((long) 0), "COERCE_CONVERT");
   module_initialization_70_tools_error(((long) 0), "COERCE_CONVERT");
   module_initialization_70_tools_misc(((long) 0), "COERCE_CONVERT");
   module_initialization_70_type_type(((long) 0), "COERCE_CONVERT");
   module_initialization_70_type_cache(((long) 0), "COERCE_CONVERT");
   module_initialization_70_type_coercion(((long) 0), "COERCE_CONVERT");
   module_initialization_70_type_env(((long) 0), "COERCE_CONVERT");
   module_initialization_70_ast_sexp(((long) 0), "COERCE_CONVERT");
   module_initialization_70_ast_var(((long) 0), "COERCE_CONVERT");
   module_initialization_70_ast_node(((long) 0), "COERCE_CONVERT");
   module_initialization_70_ast_ident(((long) 0), "COERCE_CONVERT");
   module_initialization_70_ast_lvtype(((long) 0), "COERCE_CONVERT");
   module_initialization_70_object_class(((long) 0), "COERCE_CONVERT");
   module_initialization_70_coerce_typeof(((long) 0), "COERCE_CONVERT");
   return module_initialization_70_coerce_coerce(((long) 0), "COERCE_CONVERT");
}
