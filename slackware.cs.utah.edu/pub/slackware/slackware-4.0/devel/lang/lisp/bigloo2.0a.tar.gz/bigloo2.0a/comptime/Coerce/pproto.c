/*===========================================================================*/
/*   (Coerce/pproto.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


static obj_t method_init_76_coerce_pproto();
static obj_t old_marge_string_21_coerce_pproto = BUNSPEC;
static long _pp_marge__113_coerce_pproto;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_coerce_pproto(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_pptype(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t pfunction_proto_197_coerce_pproto(long, variable_t);
static obj_t imported_modules_init_94_coerce_pproto();
extern obj_t inc_ppmarge__59_coerce_pproto();
static long old_marge_60_coerce_pproto;
extern obj_t variable_type__string_186_type_pptype(variable_t);
static obj_t _pvariable_proto1251_103_coerce_pproto(obj_t, obj_t, obj_t);
extern obj_t dec_ppmarge__31_coerce_pproto();
static obj_t _reset_ppmarge__204_coerce_pproto(obj_t);
static obj_t toplevel_init_63_coerce_pproto();
extern obj_t reset_ppmarge__67_coerce_pproto();
extern obj_t shape_tools_shape(obj_t);
static obj_t _inc_ppmarge__104_coerce_pproto(obj_t);
extern obj_t make_string(long, unsigned char);
extern obj_t function_type__string_79_type_pptype(variable_t);
static obj_t _dec_ppmarge__17_coerce_pproto(obj_t);
extern obj_t pvariable_proto_90_coerce_pproto(long, variable_t);
static obj_t require_initialization_114_coerce_pproto = BUNSPEC;
static obj_t _pfunction_proto1250_77_coerce_pproto(obj_t, obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(pvariable_proto_env_237_coerce_pproto, _pvariable_proto1251_103_coerce_pproto1255, _pvariable_proto1251_103_coerce_pproto, 0L, 2);
DEFINE_EXPORT_PROCEDURE(reset_ppmarge__env_109_coerce_pproto, _reset_ppmarge__204_coerce_pproto1256, _reset_ppmarge__204_coerce_pproto, 0L, 0);
DEFINE_EXPORT_PROCEDURE(pfunction_proto_env_244_coerce_pproto, _pfunction_proto1250_77_coerce_pproto1257, _pfunction_proto1250_77_coerce_pproto, 0L, 2);
DEFINE_EXPORT_PROCEDURE(inc_ppmarge__env_119_coerce_pproto, _inc_ppmarge__104_coerce_pproto1258, _inc_ppmarge__104_coerce_pproto, 0L, 0);
DEFINE_EXPORT_PROCEDURE(dec_ppmarge__env_99_coerce_pproto, _dec_ppmarge__17_coerce_pproto1259, _dec_ppmarge__17_coerce_pproto, 0L, 0);
DEFINE_STRING(string1253_coerce_pproto, string1253_coerce_pproto1260, " : ", 3);
DEFINE_STRING(string1252_coerce_pproto, string1252_coerce_pproto1261, "", 0);


/* module-initialization */ obj_t 
module_initialization_70_coerce_pproto(long checksum_487, char *from_488)
{
   if (CBOOL(require_initialization_114_coerce_pproto))
     {
	require_initialization_114_coerce_pproto = BBOOL(((bool_t) 0));
	imported_modules_init_94_coerce_pproto();
	method_init_76_coerce_pproto();
	toplevel_init_63_coerce_pproto();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* toplevel-init */ obj_t 
toplevel_init_63_coerce_pproto()
{
   _pp_marge__113_coerce_pproto = ((long) 8);
   old_marge_60_coerce_pproto = ((long) -1);
   return (old_marge_string_21_coerce_pproto = string1252_coerce_pproto,
      BUNSPEC);
}


/* reset-ppmarge! */ obj_t 
reset_ppmarge__67_coerce_pproto()
{
   return (_pp_marge__113_coerce_pproto = ((long) 8),
      BUNSPEC);
}


/* _reset-ppmarge! */ obj_t 
_reset_ppmarge__204_coerce_pproto(obj_t env_478)
{
   return reset_ppmarge__67_coerce_pproto();
}


/* inc-ppmarge! */ obj_t 
inc_ppmarge__59_coerce_pproto()
{
   {
      long z2_459;
      z2_459 = _pp_marge__113_coerce_pproto;
      return (_pp_marge__113_coerce_pproto = (((long) 1) + z2_459),
	 BUNSPEC);
   }
}


/* _inc-ppmarge! */ obj_t 
_inc_ppmarge__104_coerce_pproto(obj_t env_479)
{
   return inc_ppmarge__59_coerce_pproto();
}


/* dec-ppmarge! */ obj_t 
dec_ppmarge__31_coerce_pproto()
{
   {
      long z1_460;
      z1_460 = _pp_marge__113_coerce_pproto;
      return (_pp_marge__113_coerce_pproto = (z1_460 - ((long) 1)),
	 BUNSPEC);
   }
}


/* _dec-ppmarge! */ obj_t 
_dec_ppmarge__17_coerce_pproto(obj_t env_480)
{
   return dec_ppmarge__31_coerce_pproto();
}


/* pfunction-proto */ obj_t 
pfunction_proto_197_coerce_pproto(long level_1, variable_t variable_2)
{
   {
      obj_t marge_305;
      {
	 bool_t test1197_315;
	 {
	    long n1_462;
	    long n2_463;
	    n1_462 = old_marge_60_coerce_pproto;
	    n2_463 = _pp_marge__113_coerce_pproto;
	    test1197_315 = (n1_462 == n2_463);
	 }
	 if (test1197_315)
	   {
	      marge_305 = old_marge_string_21_coerce_pproto;
	   }
	 else
	   {
	      obj_t marge_316;
	      {
		 obj_t list1198_317;
		 {
		    obj_t aux_502;
		    aux_502 = BCHAR(((unsigned char) ' '));
		    list1198_317 = MAKE_PAIR(aux_502, BNIL);
		 }
		 {
		    obj_t res1248_470;
		    {
		       int k_464;
		       k_464 = (int) (_pp_marge__113_coerce_pproto);
		       {
			  unsigned char aux_508;
			  long aux_506;
			  {
			     obj_t aux_509;
			     aux_509 = CAR(list1198_317);
			     aux_508 = (unsigned char) CCHAR(aux_509);
			  }
			  aux_506 = (long) (k_464);
			  res1248_470 = make_string(aux_506, aux_508);
		       }
		    }
		    marge_316 = res1248_470;
		 }
	      }
	      old_marge_60_coerce_pproto = _pp_marge__113_coerce_pproto;
	      old_marge_string_21_coerce_pproto = marge_316;
	      marge_305 = marge_316;
	   }
      }
      {
	 obj_t arg1187_306;
	 obj_t arg1190_308;
	 arg1187_306 = shape_tools_shape((obj_t) (variable_2));
	 arg1190_308 = function_type__string_79_type_pptype(variable_2);
	 {
	    obj_t list1191_309;
	    {
	       obj_t arg1192_310;
	       {
		  obj_t arg1193_311;
		  {
		     obj_t arg1194_312;
		     {
			obj_t arg1195_313;
			{
			   obj_t aux_516;
			   aux_516 = BCHAR(((unsigned char) '\n'));
			   arg1195_313 = MAKE_PAIR(aux_516, BNIL);
			}
			arg1194_312 = MAKE_PAIR(arg1190_308, arg1195_313);
		     }
		     arg1193_311 = MAKE_PAIR(string1253_coerce_pproto, arg1194_312);
		  }
		  arg1192_310 = MAKE_PAIR(arg1187_306, arg1193_311);
	       }
	       list1191_309 = MAKE_PAIR(marge_305, arg1192_310);
	    }
	    return verbose_tools_speek(BINT(level_1), list1191_309);
	 }
      }
   }
}


/* _pfunction-proto1250 */ obj_t 
_pfunction_proto1250_77_coerce_pproto(obj_t env_481, obj_t level_482, obj_t variable_483)
{
   return pfunction_proto_197_coerce_pproto((long) CINT(level_482), (variable_t) (variable_483));
}


/* pvariable-proto */ obj_t 
pvariable_proto_90_coerce_pproto(long level_3, variable_t variable_4)
{
   {
      obj_t marge_319;
      {
	 obj_t list1210_329;
	 {
	    obj_t aux_528;
	    aux_528 = BCHAR(((unsigned char) ' '));
	    list1210_329 = MAKE_PAIR(aux_528, BNIL);
	 }
	 {
	    obj_t res1249_477;
	    {
	       int k_471;
	       k_471 = (int) (_pp_marge__113_coerce_pproto);
	       {
		  unsigned char aux_534;
		  long aux_532;
		  {
		     obj_t aux_535;
		     aux_535 = CAR(list1210_329);
		     aux_534 = (unsigned char) CCHAR(aux_535);
		  }
		  aux_532 = (long) (k_471);
		  res1249_477 = make_string(aux_532, aux_534);
	       }
	    }
	    marge_319 = res1249_477;
	 }
      }
      {
	 obj_t arg1200_320;
	 obj_t arg1202_322;
	 arg1200_320 = shape_tools_shape((obj_t) (variable_4));
	 arg1202_322 = variable_type__string_186_type_pptype(variable_4);
	 {
	    obj_t list1203_323;
	    {
	       obj_t arg1204_324;
	       {
		  obj_t arg1205_325;
		  {
		     obj_t arg1206_326;
		     {
			obj_t arg1207_327;
			{
			   obj_t aux_542;
			   aux_542 = BCHAR(((unsigned char) '\n'));
			   arg1207_327 = MAKE_PAIR(aux_542, BNIL);
			}
			arg1206_326 = MAKE_PAIR(arg1202_322, arg1207_327);
		     }
		     arg1205_325 = MAKE_PAIR(string1253_coerce_pproto, arg1206_326);
		  }
		  arg1204_324 = MAKE_PAIR(arg1200_320, arg1205_325);
	       }
	       list1203_323 = MAKE_PAIR(marge_319, arg1204_324);
	    }
	    return verbose_tools_speek(BINT(level_3), list1203_323);
	 }
      }
   }
}


/* _pvariable-proto1251 */ obj_t 
_pvariable_proto1251_103_coerce_pproto(obj_t env_484, obj_t level_485, obj_t variable_486)
{
   return pvariable_proto_90_coerce_pproto((long) CINT(level_485), (variable_t) (variable_486));
}


/* method-init */ obj_t 
method_init_76_coerce_pproto()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_coerce_pproto()
{
   module_initialization_70_tools_speek(((long) 0), "COERCE_PPROTO");
   module_initialization_70_tools_shape(((long) 0), "COERCE_PPROTO");
   module_initialization_70_type_type(((long) 0), "COERCE_PPROTO");
   module_initialization_70_type_pptype(((long) 0), "COERCE_PPROTO");
   return module_initialization_70_ast_var(((long) 0), "COERCE_PPROTO");
}
