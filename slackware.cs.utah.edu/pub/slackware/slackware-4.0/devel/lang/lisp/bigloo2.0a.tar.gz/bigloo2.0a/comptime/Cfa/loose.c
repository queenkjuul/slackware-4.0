/*===========================================================================*/
/*   (Cfa/loose.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_loose();
static obj_t stack_loose_alloc__default2080_11_cfa_loose(node_t, obj_t);
extern obj_t disable_x_t__211_cfa_procedure(approx_t);
extern obj_t global_loose__8_cfa_loose(global_t, approx_t);
static obj_t _loose_2385_57_cfa_loose(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_cfa_set(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_procedure(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t _stack_loose_alloc__default2080_221_cfa_loose(obj_t, obj_t, obj_t);
static obj_t _loose_alloc__default2079_217_cfa_loose(obj_t, obj_t);
static obj_t _global_loose_2387_4_cfa_loose(obj_t, obj_t, obj_t);
extern obj_t stack_intern_sfun_loose__226_cfa_loose(approx_t, obj_t);
extern obj_t loose_alloc__73_cfa_loose(node_t);
static obj_t _looser__194_cfa_loose = BUNSPEC;
static obj_t imported_modules_init_94_cfa_loose();
static obj_t _stack_loose_alloc_2389_247_cfa_loose(obj_t, obj_t, obj_t);
static obj_t loose_alloc__default2079_220_cfa_loose(node_t);
static obj_t _loose_alloc_2386_212_cfa_loose(obj_t, obj_t);
extern obj_t stack_loose_alloc__95_cfa_loose(node_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t library_modules_init_112_cfa_loose();
static obj_t _set_looser__78_cfa_loose(obj_t, obj_t);
extern obj_t for_each_approx_alloc_83_cfa_approx(obj_t, approx_t);
static obj_t toplevel_init_63_cfa_loose();
extern obj_t open_input_string(obj_t);
extern obj_t set_looser__198_cfa_loose(obj_t);
static obj_t arg2085_cfa_loose(obj_t, obj_t);
static approx_t cfa_loose__48_cfa_loose(approx_t);
static obj_t _stack_intern_sfun_loose_2388_128_cfa_loose(obj_t, obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
extern obj_t _cfa_stamp__16_cfa_iterate;
static obj_t require_initialization_114_cfa_loose = BUNSPEC;
extern approx_t loose__226_cfa_loose(approx_t, obj_t);
static obj_t cnst_init_137_cfa_loose();
static obj_t __cnst[6];

DEFINE_EXPORT_GENERIC(loose_alloc__env_83_cfa_loose, _loose_alloc_2386_212_cfa_loose2398, _loose_alloc_2386_212_cfa_loose, 0L, 1);
DEFINE_EXPORT_PROCEDURE(loose__env_222_cfa_loose, _loose_2385_57_cfa_loose2399, _loose_2385_57_cfa_loose, 0L, 2);
DEFINE_STATIC_PROCEDURE(loose_alloc__default2079_env_155_cfa_loose, _loose_alloc__default2079_217_cfa_loose2400, _loose_alloc__default2079_217_cfa_loose, 0L, 1);
DEFINE_EXPORT_GENERIC(stack_loose_alloc__env_147_cfa_loose, _stack_loose_alloc_2389_247_cfa_loose2401, _stack_loose_alloc_2389_247_cfa_loose, 0L, 2);
DEFINE_EXPORT_PROCEDURE(set_looser__env_207_cfa_loose, _set_looser__78_cfa_loose2402, _set_looser__78_cfa_loose, 0L, 1);
DEFINE_STRING(string2391_cfa_loose, string2391_cfa_loose2403, "STACK-LOOSE-ALLOC!-DEFAULT2080 LOOSE-ALLOC!-DEFAULT2079 STACK ALL (IMPORT EXPORT) CFA ", 86);
DEFINE_STRING(string2390_cfa_loose, string2390_cfa_loose2404, "No method for this object", 25);
DEFINE_EXPORT_PROCEDURE(global_loose__env_130_cfa_loose, _global_loose_2387_4_cfa_loose2405, _global_loose_2387_4_cfa_loose, 0L, 2);
DEFINE_EXPORT_PROCEDURE(stack_intern_sfun_loose__env_222_cfa_loose, _stack_intern_sfun_loose_2388_128_cfa_loose2406, _stack_intern_sfun_loose_2388_128_cfa_loose, 0L, 2);
DEFINE_STATIC_PROCEDURE(stack_loose_alloc__default2080_env_186_cfa_loose, _stack_loose_alloc__default2080_221_cfa_loose2407, _stack_loose_alloc__default2080_221_cfa_loose, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_cfa_loose(long checksum_3391, char *from_3392)
{
   if (CBOOL(require_initialization_114_cfa_loose))
     {
	require_initialization_114_cfa_loose = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_loose();
	cnst_init_137_cfa_loose();
	imported_modules_init_94_cfa_loose();
	method_init_76_cfa_loose();
	toplevel_init_63_cfa_loose();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_loose()
{
   module_initialization_70___object(((long) 0), "CFA_LOOSE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_LOOSE");
   module_initialization_70___reader(((long) 0), "CFA_LOOSE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_loose()
{
   {
      obj_t cnst_port_138_3383;
      cnst_port_138_3383 = open_input_string(string2391_cfa_loose);
      {
	 long i_3384;
	 i_3384 = ((long) 5);
       loop_3385:
	 {
	    bool_t test2392_3386;
	    test2392_3386 = (i_3384 == ((long) -1));
	    if (test2392_3386)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2394_3387;
		    {
		       obj_t list2395_3388;
		       {
			  obj_t arg2396_3389;
			  arg2396_3389 = BNIL;
			  list2395_3388 = MAKE_PAIR(cnst_port_138_3383, arg2396_3389);
		       }
		       arg2394_3387 = read___reader(list2395_3388);
		    }
		    CNST_TABLE_SET(i_3384, arg2394_3387);
		 }
		 {
		    int aux_3390;
		    {
		       long aux_3410;
		       aux_3410 = (i_3384 - ((long) 1));
		       aux_3390 = (int) (aux_3410);
		    }
		    {
		       long i_3413;
		       i_3413 = (long) (aux_3390);
		       i_3384 = i_3413;
		       goto loop_3385;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_loose()
{
   _looser__194_cfa_loose = CNST_TABLE_REF(((long) 0));
   return BUNSPEC;
}


/* set-looser! */ obj_t 
set_looser__198_cfa_loose(obj_t looser_1)
{
   return (_looser__194_cfa_loose = looser_1,
      BUNSPEC);
}


/* _set-looser! */ obj_t 
_set_looser__78_cfa_loose(obj_t env_3358, obj_t looser_3359)
{
   return set_looser__198_cfa_loose(looser_3359);
}


/* loose! */ approx_t 
loose__226_cfa_loose(approx_t approx_2, obj_t owner_3)
{
   {
      bool_t test2081_2113;
      {
	 obj_t obj1_2924;
	 obj1_2924 = _looser__194_cfa_loose;
	 {
	    obj_t aux_3417;
	    aux_3417 = CNST_TABLE_REF(((long) 0));
	    test2081_2113 = (obj1_2924 == aux_3417);
	 }
      }
      if (test2081_2113)
	{
	   return cfa_loose__48_cfa_loose(approx_2);
	}
      else
	{
	   approx_t res2382_2930;
	   {
	      obj_t arg2085_3360;
	      arg2085_3360 = make_fx_procedure(arg2085_cfa_loose, ((long) 1), ((long) 1));
	      PROCEDURE_SET(arg2085_3360, ((long) 0), owner_3);
	      for_each_approx_alloc_83_cfa_approx(arg2085_3360, approx_2);
	   }
	   res2382_2930 = approx_2;
	   return res2382_2930;
	}
   }
}


/* _loose!2385 */ obj_t 
_loose_2385_57_cfa_loose(obj_t env_3361, obj_t approx_3362, obj_t owner_3363)
{
   {
      approx_t aux_3425;
      aux_3425 = loose__226_cfa_loose((approx_t) (approx_3362), owner_3363);
      return (obj_t) (aux_3425);
   }
}


/* arg2085 */ obj_t 
arg2085_cfa_loose(obj_t env_3364, obj_t alloc_3366)
{
   {
      obj_t owner_3365;
      owner_3365 = PROCEDURE_REF(env_3364, ((long) 0));
      {
	 obj_t alloc_2929;
	 alloc_2929 = alloc_3366;
	 return stack_loose_alloc__95_cfa_loose((node_t) (alloc_2929), owner_3365);
      }
   }
}


/* cfa-loose! */ approx_t 
cfa_loose__48_cfa_loose(approx_t approx_4)
{
   {
      bool_t test2083_2116;
      {
	 long arg2084_2117;
	 arg2084_2117 = (((approx_t) CREF(approx_4))->lost_stamp_114);
	 {
	    long n2_2933;
	    n2_2933 = (long) CINT(_cfa_stamp__16_cfa_iterate);
	    test2083_2116 = (arg2084_2117 < n2_2933);
	 }
      }
      if (test2083_2116)
	{
	   {
	      long val1493_2935;
	      val1493_2935 = (long) CINT(_cfa_stamp__16_cfa_iterate);
	      ((((approx_t) CREF(approx_4))->lost_stamp_114) = ((long) val1493_2935), BUNSPEC);
	   }
	   for_each_approx_alloc_83_cfa_approx(loose_alloc__env_83_cfa_loose, approx_4);
	}
      else
	{
	   BUNSPEC;
	}
   }
   return approx_4;
}


/* global-loose! */ obj_t 
global_loose__8_cfa_loose(global_t global_13, approx_t approx_14)
{
   {
      bool_t test_3439;
      {
	 obj_t aux_3440;
	 aux_3440 = memq___r4_pairs_and_lists_6_3((((global_t) CREF(global_13))->import), CNST_TABLE_REF(((long) 1)));
	 test_3439 = CBOOL(aux_3440);
      }
      if (test_3439)
	{
	   {
	      approx_t aux_3445;
	      aux_3445 = loose__226_cfa_loose(approx_14, CNST_TABLE_REF(((long) 2)));
	      return (obj_t) (aux_3445);
	   }
	}
      else
	{
	   bool_t test2089_2124;
	   {
	      obj_t obj1_2939;
	      obj1_2939 = _looser__194_cfa_loose;
	      {
		 obj_t aux_3449;
		 aux_3449 = CNST_TABLE_REF(((long) 3));
		 test2089_2124 = (obj1_2939 == aux_3449);
	      }
	   }
	   if (test2089_2124)
	     {
		disable_x_t__211_cfa_procedure(approx_14);
		{
		   approx_t aux_3454;
		   aux_3454 = loose__226_cfa_loose(approx_14, CNST_TABLE_REF(((long) 2)));
		   return (obj_t) (aux_3454);
		}
	     }
	   else
	     {
		return disable_x_t__211_cfa_procedure(approx_14);
	     }
	}
   }
}


/* _global-loose!2387 */ obj_t 
_global_loose_2387_4_cfa_loose(obj_t env_3369, obj_t global_3370, obj_t approx_3371)
{
   return global_loose__8_cfa_loose((global_t) (global_3370), (approx_t) (approx_3371));
}


/* stack-intern-sfun-loose! */ obj_t 
stack_intern_sfun_loose__226_cfa_loose(approx_t approx_15, obj_t owner_16)
{
   {
      bool_t test2094_2941;
      {
	 obj_t obj1_2943;
	 obj1_2943 = _looser__194_cfa_loose;
	 {
	    obj_t aux_3462;
	    aux_3462 = CNST_TABLE_REF(((long) 3));
	    test2094_2941 = (obj1_2943 == aux_3462);
	 }
      }
      if (test2094_2941)
	{
	   approx_t aux_3466;
	   aux_3466 = loose__226_cfa_loose(approx_15, owner_16);
	   return (obj_t) (aux_3466);
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _stack-intern-sfun-loose!2388 */ obj_t 
_stack_intern_sfun_loose_2388_128_cfa_loose(obj_t env_3372, obj_t approx_3373, obj_t owner_3374)
{
   return stack_intern_sfun_loose__226_cfa_loose((approx_t) (approx_3373), owner_3374);
}


/* method-init */ obj_t 
method_init_76_cfa_loose()
{
   add_generic__110___object(loose_alloc__env_83_cfa_loose, loose_alloc__default2079_env_155_cfa_loose);
   return add_generic__110___object(stack_loose_alloc__env_147_cfa_loose, stack_loose_alloc__default2080_env_186_cfa_loose);
}


/* loose-alloc! */ obj_t 
loose_alloc__73_cfa_loose(node_t node_5)
{
   {
      obj_t method2368_2910;
      obj_t class2373_2911;
      {
	 obj_t arg2374_2908;
	 obj_t arg2375_2909;
	 {
	    object_t obj_3292;
	    obj_3292 = (object_t) (node_5);
	    {
	       obj_t pre_method_105_3293;
	       pre_method_105_3293 = PROCEDURE_REF(loose_alloc__env_83_cfa_loose, ((long) 2));
	       if (INTEGERP(pre_method_105_3293))
		 {
		    PROCEDURE_SET(loose_alloc__env_83_cfa_loose, ((long) 2), BUNSPEC);
		    arg2374_2908 = pre_method_105_3293;
		 }
	       else
		 {
		    long obj_class_num_177_3298;
		    obj_class_num_177_3298 = TYPE(obj_3292);
		    {
		       obj_t arg1177_3299;
		       arg1177_3299 = PROCEDURE_REF(loose_alloc__env_83_cfa_loose, ((long) 1));
		       {
			  long arg1178_3303;
			  {
			     long arg1179_3304;
			     arg1179_3304 = OBJECT_TYPE;
			     arg1178_3303 = (obj_class_num_177_3298 - arg1179_3304);
			  }
			  arg2374_2908 = VECTOR_REF(arg1177_3299, arg1178_3303);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3309;
	    object_3309 = (object_t) (node_5);
	    {
	       long arg1180_3310;
	       {
		  long arg1181_3311;
		  long arg1182_3312;
		  arg1181_3311 = TYPE(object_3309);
		  arg1182_3312 = OBJECT_TYPE;
		  arg1180_3310 = (arg1181_3311 - arg1182_3312);
	       }
	       {
		  obj_t vector_3316;
		  vector_3316 = _classes__134___object;
		  arg2375_2909 = VECTOR_REF(vector_3316, arg1180_3310);
	       }
	    }
	 }
	 method2368_2910 = arg2374_2908;
	 class2373_2911 = arg2375_2909;
	 if (PROCEDUREP(method2368_2910))
	   {
	      return PROCEDURE_ENTRY(method2368_2910) (method2368_2910, (obj_t) (node_5), BEOA);
	   }
	 else
	   {
	      obj_t fun2348_2884;
	      fun2348_2884 = PROCEDURE_REF(loose_alloc__env_83_cfa_loose, ((long) 0));
	      return PROCEDURE_ENTRY(fun2348_2884) (fun2348_2884, (obj_t) (node_5), BEOA);
	   }
      }
   }
}


/* _loose-alloc!2386 */ obj_t 
_loose_alloc_2386_212_cfa_loose(obj_t env_3367, obj_t node_3368)
{
   return loose_alloc__73_cfa_loose((node_t) (node_3368));
}


/* loose-alloc!-default2079 */ obj_t 
loose_alloc__default2079_220_cfa_loose(node_t node_6)
{
   FAILURE(CNST_TABLE_REF(((long) 4)), string2390_cfa_loose, (obj_t) (node_6));
}


/* _loose-alloc!-default2079 */ obj_t 
_loose_alloc__default2079_217_cfa_loose(obj_t env_3375, obj_t node_3376)
{
   return loose_alloc__default2079_220_cfa_loose((node_t) (node_3376));
}


/* stack-loose-alloc! */ obj_t 
stack_loose_alloc__95_cfa_loose(node_t node_9, obj_t owner_10)
{
   {
      obj_t method2354_2893;
      obj_t class2359_2894;
      {
	 obj_t arg2360_2891;
	 obj_t arg2361_2892;
	 {
	    object_t obj_3325;
	    obj_3325 = (object_t) (node_9);
	    {
	       obj_t pre_method_105_3326;
	       pre_method_105_3326 = PROCEDURE_REF(stack_loose_alloc__env_147_cfa_loose, ((long) 2));
	       if (INTEGERP(pre_method_105_3326))
		 {
		    PROCEDURE_SET(stack_loose_alloc__env_147_cfa_loose, ((long) 2), BUNSPEC);
		    arg2360_2891 = pre_method_105_3326;
		 }
	       else
		 {
		    long obj_class_num_177_3331;
		    obj_class_num_177_3331 = TYPE(obj_3325);
		    {
		       obj_t arg1177_3332;
		       arg1177_3332 = PROCEDURE_REF(stack_loose_alloc__env_147_cfa_loose, ((long) 1));
		       {
			  long arg1178_3336;
			  {
			     long arg1179_3337;
			     arg1179_3337 = OBJECT_TYPE;
			     arg1178_3336 = (obj_class_num_177_3331 - arg1179_3337);
			  }
			  arg2360_2891 = VECTOR_REF(arg1177_3332, arg1178_3336);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3342;
	    object_3342 = (object_t) (node_9);
	    {
	       long arg1180_3343;
	       {
		  long arg1181_3344;
		  long arg1182_3345;
		  arg1181_3344 = TYPE(object_3342);
		  arg1182_3345 = OBJECT_TYPE;
		  arg1180_3343 = (arg1181_3344 - arg1182_3345);
	       }
	       {
		  obj_t vector_3349;
		  vector_3349 = _classes__134___object;
		  arg2361_2892 = VECTOR_REF(vector_3349, arg1180_3343);
	       }
	    }
	 }
	 method2354_2893 = arg2360_2891;
	 class2359_2894 = arg2361_2892;
	 if (PROCEDUREP(method2354_2893))
	   {
	      return PROCEDURE_ENTRY(method2354_2893) (method2354_2893, (obj_t) (node_9), owner_10, BEOA);
	   }
	 else
	   {
	      obj_t fun2351_2887;
	      fun2351_2887 = PROCEDURE_REF(stack_loose_alloc__env_147_cfa_loose, ((long) 0));
	      return PROCEDURE_ENTRY(fun2351_2887) (fun2351_2887, (obj_t) (node_9), owner_10, BEOA);
	   }
      }
   }
}


/* _stack-loose-alloc!2389 */ obj_t 
_stack_loose_alloc_2389_247_cfa_loose(obj_t env_3377, obj_t node_3378, obj_t owner_3379)
{
   return stack_loose_alloc__95_cfa_loose((node_t) (node_3378), owner_3379);
}


/* stack-loose-alloc!-default2080 */ obj_t 
stack_loose_alloc__default2080_11_cfa_loose(node_t node_11, obj_t owner_12)
{
   FAILURE(CNST_TABLE_REF(((long) 5)), string2390_cfa_loose, (obj_t) (node_11));
}


/* _stack-loose-alloc!-default2080 */ obj_t 
_stack_loose_alloc__default2080_221_cfa_loose(obj_t env_3380, obj_t node_3381, obj_t owner_3382)
{
   return stack_loose_alloc__default2080_11_cfa_loose((node_t) (node_3381), owner_3382);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_loose()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_LOOSE");
   module_initialization_70_type_type(((long) 0), "CFA_LOOSE");
   module_initialization_70_tools_shape(((long) 0), "CFA_LOOSE");
   module_initialization_70_ast_var(((long) 0), "CFA_LOOSE");
   module_initialization_70_ast_node(((long) 0), "CFA_LOOSE");
   module_initialization_70_cfa_iterate(((long) 0), "CFA_LOOSE");
   module_initialization_70_cfa_set(((long) 0), "CFA_LOOSE");
   module_initialization_70_cfa_info(((long) 0), "CFA_LOOSE");
   module_initialization_70_cfa_approx(((long) 0), "CFA_LOOSE");
   return module_initialization_70_cfa_procedure(((long) 0), "CFA_LOOSE");
}
