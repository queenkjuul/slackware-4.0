/*===========================================================================*/
/*   (Globalize/escape.scm)                                                  */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


extern obj_t local_ginfo_108_globalize_ginfo;
static obj_t method_init_76_globalize_escape();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
static obj_t escape__default1605_80_globalize_escape(node_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
static obj_t _escape_1942_179_globalize_escape(obj_t, obj_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static obj_t _set_escaping_fun_1941_222_globalize_escape(obj_t, obj_t);
extern obj_t closure_ast_node;
extern obj_t global_ast_var;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_escape(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t escape__235_globalize_escape(node_t);
static obj_t _escape_fun__default1598_151_globalize_escape(obj_t, obj_t);
extern long class_num_218___object(obj_t);
static obj_t _escape_fun_1940_98_globalize_escape(obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_globalize_escape();
extern obj_t sfun_ginfo_98_globalize_ginfo;
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t sexit_ginfo_81_globalize_ginfo;
static obj_t library_modules_init_112_globalize_escape();
extern obj_t global_ginfo_75_globalize_ginfo;
extern obj_t svar_ginfo_131_globalize_ginfo;
static obj_t _set_escaping_fun__default1601_79_globalize_escape(obj_t, obj_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_globalize_escape();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t escape_fun__53_globalize_escape(variable_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t local_ast_var;
extern obj_t shape_tools_shape(obj_t);
static obj_t escape_fun__default1598_220_globalize_escape(variable_t);
static obj_t _escape__default1605_91_globalize_escape(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
static bool_t escape___220_globalize_escape(obj_t);
extern obj_t read___reader(obj_t);
static obj_t set_escaping_fun__default1601_120_globalize_escape(variable_t);
static obj_t set_escaping_fun__14_globalize_escape(variable_t);
extern obj_t find_method_from_44___object(object_t, obj_t, obj_t);
static obj_t require_initialization_114_globalize_escape = BUNSPEC;
extern obj_t conditional_ast_node;
extern obj_t class_super_145___object(obj_t);
static obj_t cnst_init_137_globalize_escape();
static obj_t __cnst[3];

DEFINE_EXPORT_GENERIC(escape_fun__env_92_globalize_escape, _escape_fun_1940_98_globalize_escape1952, _escape_fun_1940_98_globalize_escape, 0L, 1);
DEFINE_STATIC_GENERIC(escape__env_201_globalize_escape, _escape_1942_179_globalize_escape1953, _escape_1942_179_globalize_escape, 0L, 1);
DEFINE_STATIC_PROCEDURE(set_escaping_fun__default1601_env_192_globalize_escape, _set_escaping_fun__default1601_79_globalize_escape1954, _set_escaping_fun__default1601_79_globalize_escape, 0L, 1);
DEFINE_STATIC_PROCEDURE(escape__default1605_env_134_globalize_escape, _escape__default1605_91_globalize_escape1955, _escape__default1605_91_globalize_escape, 0L, 1);
DEFINE_STRING(string1946_globalize_escape, string1946_globalize_escape1956, "ESCAPE!-DEFAULT1605 DONE EXPORT ", 32);
DEFINE_STRING(string1945_globalize_escape, string1945_globalize_escape1957, "No method for this object", 25);
DEFINE_STRING(string1944_globalize_escape, string1944_globalize_escape1958, "Illegal variable", 16);
DEFINE_STRING(string1943_globalize_escape, string1943_globalize_escape1959, "set-escaping-fun!", 17);
DEFINE_STATIC_PROCEDURE(escape_fun__default1598_env_155_globalize_escape, _escape_fun__default1598_151_globalize_escape1960, _escape_fun__default1598_151_globalize_escape, 0L, 1);
DEFINE_STATIC_GENERIC(set_escaping_fun__env_225_globalize_escape, _set_escaping_fun_1941_222_globalize_escape1961, _set_escaping_fun_1941_222_globalize_escape, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_globalize_escape(long checksum_2101, char *from_2102)
{
   if (CBOOL(require_initialization_114_globalize_escape))
     {
	require_initialization_114_globalize_escape = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_escape();
	cnst_init_137_globalize_escape();
	imported_modules_init_94_globalize_escape();
	method_init_76_globalize_escape();
	toplevel_init_63_globalize_escape();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_escape()
{
   module_initialization_70___object(((long) 0), "GLOBALIZE_ESCAPE");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_ESCAPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_escape()
{
   {
      obj_t cnst_port_138_2093;
      cnst_port_138_2093 = open_input_string(string1946_globalize_escape);
      {
	 long i_2094;
	 i_2094 = ((long) 2);
       loop_2095:
	 {
	    bool_t test1947_2096;
	    test1947_2096 = (i_2094 == ((long) -1));
	    if (test1947_2096)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1948_2097;
		    {
		       obj_t list1949_2098;
		       {
			  obj_t arg1950_2099;
			  arg1950_2099 = BNIL;
			  list1949_2098 = MAKE_PAIR(cnst_port_138_2093, arg1950_2099);
		       }
		       arg1948_2097 = read___reader(list1949_2098);
		    }
		    CNST_TABLE_SET(i_2094, arg1948_2097);
		 }
		 {
		    int aux_2100;
		    {
		       long aux_2119;
		       aux_2119 = (i_2094 - ((long) 1));
		       aux_2100 = (int) (aux_2119);
		    }
		    {
		       long i_2122;
		       i_2122 = (long) (aux_2100);
		       i_2094 = i_2122;
		       goto loop_2095;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_globalize_escape()
{
   return BUNSPEC;
}


/* escape*! */ bool_t 
escape___220_globalize_escape(obj_t node__221_33)
{
   {
      obj_t l1596_1023;
      l1596_1023 = node__221_33;
    lname1597_1024:
      if (PAIRP(l1596_1023))
	{
	   {
	      node_t aux_2126;
	      {
		 obj_t aux_2127;
		 aux_2127 = CAR(l1596_1023);
		 aux_2126 = (node_t) (aux_2127);
	      }
	      escape__235_globalize_escape(aux_2126);
	   }
	   {
	      obj_t l1596_2131;
	      l1596_2131 = CDR(l1596_1023);
	      l1596_1023 = l1596_2131;
	      goto lname1597_1024;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* method-init */ obj_t 
method_init_76_globalize_escape()
{
   add_generic__110___object(escape_fun__env_92_globalize_escape, escape_fun__default1598_env_155_globalize_escape);
   add_inlined_method__244___object(escape_fun__env_92_globalize_escape, global_ast_var, ((long) 0));
   add_inlined_method__244___object(escape_fun__env_92_globalize_escape, local_ast_var, ((long) 1));
   add_generic__110___object(set_escaping_fun__env_225_globalize_escape, set_escaping_fun__default1601_env_192_globalize_escape);
   add_inlined_method__244___object(set_escaping_fun__env_225_globalize_escape, global_ast_var, ((long) 0));
   add_inlined_method__244___object(set_escaping_fun__env_225_globalize_escape, global_ginfo_75_globalize_ginfo, ((long) 1));
   add_inlined_method__244___object(set_escaping_fun__env_225_globalize_escape, local_ginfo_108_globalize_ginfo, ((long) 2));
   add_generic__110___object(escape__env_201_globalize_escape, escape__default1605_env_134_globalize_escape);
   add_inlined_method__244___object(escape__env_201_globalize_escape, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(escape__env_201_globalize_escape, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(escape__env_201_globalize_escape, var_ast_node, ((long) 2));
   add_inlined_method__244___object(escape__env_201_globalize_escape, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(escape__env_201_globalize_escape, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(escape__env_201_globalize_escape, app_ast_node, ((long) 5));
   add_inlined_method__244___object(escape__env_201_globalize_escape, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(escape__env_201_globalize_escape, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(escape__env_201_globalize_escape, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(escape__env_201_globalize_escape, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(escape__env_201_globalize_escape, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(escape__env_201_globalize_escape, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(escape__env_201_globalize_escape, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(escape__env_201_globalize_escape, select_ast_node, ((long) 13));
   add_inlined_method__244___object(escape__env_201_globalize_escape, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(escape__env_201_globalize_escape, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(escape__env_201_globalize_escape, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(escape__env_201_globalize_escape, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(escape__env_201_globalize_escape, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(escape__env_201_globalize_escape, box_set__221_ast_node, ((long) 19));
   {
      long aux_2161;
      aux_2161 = add_inlined_method__244___object(escape__env_201_globalize_escape, box_ref_242_ast_node, ((long) 20));
      return BINT(aux_2161);
   }
}


/* escape-fun! */ obj_t 
escape_fun__53_globalize_escape(variable_t variable_1)
{
   {
      obj_t method1899_1622;
      obj_t class1904_1623;
      {
	 obj_t arg1907_1620;
	 obj_t arg1909_1621;
	 {
	    object_t obj_1748;
	    obj_1748 = (object_t) (variable_1);
	    {
	       obj_t pre_method_105_1749;
	       pre_method_105_1749 = PROCEDURE_REF(escape_fun__env_92_globalize_escape, ((long) 2));
	       if (INTEGERP(pre_method_105_1749))
		 {
		    PROCEDURE_SET(escape_fun__env_92_globalize_escape, ((long) 2), BUNSPEC);
		    arg1907_1620 = pre_method_105_1749;
		 }
	       else
		 {
		    long obj_class_num_177_1754;
		    obj_class_num_177_1754 = TYPE(obj_1748);
		    {
		       obj_t arg1177_1755;
		       arg1177_1755 = PROCEDURE_REF(escape_fun__env_92_globalize_escape, ((long) 1));
		       {
			  long arg1178_1759;
			  {
			     long arg1179_1760;
			     arg1179_1760 = OBJECT_TYPE;
			     arg1178_1759 = (obj_class_num_177_1754 - arg1179_1760);
			  }
			  arg1907_1620 = VECTOR_REF(arg1177_1755, arg1178_1759);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1765;
	    object_1765 = (object_t) (variable_1);
	    {
	       long arg1180_1766;
	       {
		  long arg1181_1767;
		  long arg1182_1768;
		  arg1181_1767 = TYPE(object_1765);
		  arg1182_1768 = OBJECT_TYPE;
		  arg1180_1766 = (arg1181_1767 - arg1182_1768);
	       }
	       {
		  obj_t vector_1772;
		  vector_1772 = _classes__134___object;
		  arg1909_1621 = VECTOR_REF(vector_1772, arg1180_1766);
	       }
	    }
	 }
	 method1899_1622 = arg1907_1620;
	 class1904_1623 = arg1909_1621;
       loop1900_1650:
	 {
	    {
	       if (INTEGERP(method1899_1622))
		 {
		    switch ((long) CINT(method1899_1622))
		      {
		      case ((long) 0):
			 {
			    global_t variable_1629;
			    variable_1629 = (global_t) (variable_1);
			    {
			       bool_t test1912_1630;
			       test1912_1630 = is_a__118___object((obj_t) (variable_1629), global_ginfo_75_globalize_ginfo);
			       if (test1912_1630)
				 {
				    BUNSPEC;
				 }
			       else
				 {
				    global_ginfo_75_t obj1561_1631;
				    obj1561_1631 = ((global_ginfo_75_t) (variable_1629));
				    {
				       global_ginfo_75_t arg1913_1632;
				       {
					  bool_t arg1914_1633;
					  {
					     obj_t aux_2188;
					     obj_t aux_2186;
					     aux_2188 = CNST_TABLE_REF(((long) 0));
					     aux_2186 = (((global_t) CREF(variable_1629))->import);
					     arg1914_1633 = (aux_2186 == aux_2188);
					  }
					  {
					     global_ginfo_75_t res1926_1783;
					     {
						obj_t global_closure_229_1779;
						global_closure_229_1779 = BFALSE;
						{
						   global_ginfo_75_t new1536_1780;
						   new1536_1780 = ((global_ginfo_75_t) BREF(GC_MALLOC(sizeof(struct global_ginfo_75))));
						   ((((global_ginfo_75_t) CREF(new1536_1780))->escape__117) = ((bool_t) arg1914_1633), BUNSPEC);
						   ((((global_ginfo_75_t) CREF(new1536_1780))->global_closure_229) = ((obj_t) global_closure_229_1779), BUNSPEC);
						   res1926_1783 = new1536_1780;
						}
					     }
					     arg1913_1632 = res1926_1783;
					  }
				       }
				       {
					  obj_t aux_2196;
					  object_t aux_2194;
					  aux_2196 = (obj_t) (arg1913_1632);
					  aux_2194 = (object_t) (obj1561_1631);
					  OBJECT_WIDENING_SET(aux_2194, aux_2196);
				       }
				    }
				    {
				       long arg1917_1636;
				       arg1917_1636 = class_num_218___object(global_ginfo_75_globalize_ginfo);
				       {
					  obj_t obj_1784;
					  obj_1784 = (obj_t) (obj1561_1631);
					  (((obj_t) CREF(obj_1784))->header = MAKE_HEADER(arg1917_1636, 0), BUNSPEC);
				       }
				    }
				    (obj_t) (obj1561_1631);
				 }
			    }
			  call_next_method_114_1649:
			    {
			       obj_t aux1902_1645;
			       {
				  obj_t aux_2203;
				  {
				     bool_t test_2205;
				     if (VECTORP(class1904_1623))
				       {
					  long aux_2208;
					  aux_2208 = VECTOR_LENGTH(class1904_1623);
					  test_2205 = (aux_2208 == ((long) 10));
				       }
				     else
				       {
					  test_2205 = ((bool_t) 0);
				       }
				     if (test_2205)
				       {
					  aux_2203 = class_super_145___object(class1904_1623);
				       }
				     else
				       {
					  aux_2203 = BFALSE;
				       }
				  }
				  aux1902_1645 = find_method_from_44___object((object_t) (variable_1), escape_fun__env_92_globalize_escape, aux_2203);
			       }
			       {
				  {
				     obj_t class1904_2215;
				     obj_t method1899_2213;
				     method1899_2213 = CDR(aux1902_1645);
				     class1904_2215 = CAR(aux1902_1645);
				     class1904_1623 = class1904_2215;
				     method1899_1622 = method1899_2213;
				     goto loop1900_1650;
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    local_t variable_1637;
			    variable_1637 = (local_t) (variable_1);
			    {
			       bool_t test1918_1638;
			       test1918_1638 = is_a__118___object((obj_t) (variable_1637), local_ginfo_108_globalize_ginfo);
			       if (test1918_1638)
				 {
				    BUNSPEC;
				 }
			       else
				 {
				    local_ginfo_108_t obj1562_1639;
				    obj1562_1639 = ((local_ginfo_108_t) (variable_1637));
				    {
				       local_ginfo_108_t arg1919_1640;
				       {
					  local_ginfo_108_t res1927_1790;
					  {
					     local_ginfo_108_t new1521_1788;
					     new1521_1788 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
					     ((((local_ginfo_108_t) CREF(new1521_1788))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					     res1927_1790 = new1521_1788;
					  }
					  arg1919_1640 = res1927_1790;
				       }
				       {
					  obj_t aux_2226;
					  object_t aux_2224;
					  aux_2226 = (obj_t) (arg1919_1640);
					  aux_2224 = (object_t) (obj1562_1639);
					  OBJECT_WIDENING_SET(aux_2224, aux_2226);
				       }
				    }
				    {
				       long arg1920_1641;
				       arg1920_1641 = class_num_218___object(local_ginfo_108_globalize_ginfo);
				       {
					  obj_t obj_1791;
					  obj_1791 = (obj_t) (obj1562_1639);
					  (((obj_t) CREF(obj_1791))->header = MAKE_HEADER(arg1920_1641, 0), BUNSPEC);
				       }
				    }
				    (obj_t) (obj1562_1639);
				 }
			    }
			    goto call_next_method_114_1649;
			 }
			 break;
		      default:
		       case_else1905_1626:
			 if (PROCEDUREP(method1899_1622))
			   {
			      return PROCEDURE_ENTRY(method1899_1622) (method1899_1622, (obj_t) (variable_1), BEOA);
			   }
			 else
			   {
			      obj_t fun1733_1417;
			      fun1733_1417 = PROCEDURE_REF(escape_fun__env_92_globalize_escape, ((long) 0));
			      return PROCEDURE_ENTRY(fun1733_1417) (fun1733_1417, (obj_t) (variable_1), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1905_1626;
		 }
	    }
	 }
      }
   }
}


/* _escape-fun!1940 */ obj_t 
_escape_fun_1940_98_globalize_escape(obj_t env_2081, obj_t variable_2082)
{
   return escape_fun__53_globalize_escape((variable_t) (variable_2082));
}


/* escape-fun!-default1598 */ obj_t 
escape_fun__default1598_220_globalize_escape(variable_t variable_2)
{
   {
      value_t fun_1418;
      fun_1418 = (((variable_t) CREF(variable_2))->value);
      {
	 obj_t l1557_1419;
	 {
	    sfun_t obj_1807;
	    obj_1807 = (sfun_t) (fun_1418);
	    l1557_1419 = (((sfun_t) CREF(obj_1807))->args);
	 }
       lname1558_1420:
	 if (PAIRP(l1557_1419))
	   {
	      {
		 obj_t local_1423;
		 local_1423 = CAR(l1557_1419);
		 {
		    svar_ginfo_131_t obj1559_1424;
		    {
		       value_t aux_2250;
		       {
			  local_t obj_1810;
			  obj_1810 = (local_t) (local_1423);
			  aux_2250 = (((local_t) CREF(obj_1810))->value);
		       }
		       obj1559_1424 = ((svar_ginfo_131_t) (aux_2250));
		    }
		    {
		       svar_ginfo_131_t arg1740_1425;
		       {
			  svar_ginfo_131_t res1930_1820;
			  {
			     svar_ginfo_131_t new1492_1815;
			     new1492_1815 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
			     ((((svar_ginfo_131_t) CREF(new1492_1815))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			     ((((svar_ginfo_131_t) CREF(new1492_1815))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
			     ((((svar_ginfo_131_t) CREF(new1492_1815))->mark) = ((long) ((long) -10)), BUNSPEC);
			     ((((svar_ginfo_131_t) CREF(new1492_1815))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			     res1930_1820 = new1492_1815;
			  }
			  arg1740_1425 = res1930_1820;
		       }
		       {
			  obj_t aux_2261;
			  object_t aux_2259;
			  aux_2261 = (obj_t) (arg1740_1425);
			  aux_2259 = (object_t) (obj1559_1424);
			  OBJECT_WIDENING_SET(aux_2259, aux_2261);
		       }
		    }
		    {
		       long arg1743_1426;
		       arg1743_1426 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
		       {
			  obj_t obj_1821;
			  obj_1821 = (obj_t) (obj1559_1424);
			  (((obj_t) CREF(obj_1821))->header = MAKE_HEADER(arg1743_1426, 0), BUNSPEC);
		       }
		    }
		    obj1559_1424;
		 }
	      }
	      {
		 obj_t l1557_2267;
		 l1557_2267 = CDR(l1557_1419);
		 l1557_1419 = l1557_2267;
		 goto lname1558_1420;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      {
	 sfun_ginfo_98_t obj1560_1428;
	 obj1560_1428 = ((sfun_ginfo_98_t) (fun_1418));
	 {
	    sfun_ginfo_98_t arg1745_1429;
	    {
	       sfun_ginfo_98_t res1931_1861;
	       {
		  obj_t cfrom__119_1826;
		  obj_t cto__14_1828;
		  obj_t the_global_201_1835;
		  obj_t kaptured_1836;
		  obj_t new_body_215_1837;
		  cfrom__119_1826 = BFALSE;
		  cto__14_1828 = BFALSE;
		  the_global_201_1835 = BFALSE;
		  kaptured_1836 = BFALSE;
		  new_body_215_1837 = BFALSE;
		  {
		     sfun_ginfo_98_t new1440_1842;
		     new1440_1842 = ((sfun_ginfo_98_t) BREF(GC_MALLOC(sizeof(struct sfun_ginfo_98))));
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->g__219) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->cfrom) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->cfrom__119) = ((obj_t) cfrom__119_1826), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->cto) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->cto__14) = ((obj_t) cto__14_1828), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->cfunction) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->integrator) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->integrated) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->plugged_in_15) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->mark) = ((long) ((long) -10)), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->free_mark_81) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->the_global_201) = ((obj_t) the_global_201_1835), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->kaptured) = ((obj_t) kaptured_1836), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->new_body_215) = ((obj_t) new_body_215_1837), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->bmark) = ((long) ((long) -10)), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->umark) = ((long) ((long) -10)), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->free) = ((obj_t) BUNSPEC), BUNSPEC);
		     ((((sfun_ginfo_98_t) CREF(new1440_1842))->bound) = ((obj_t) BNIL), BUNSPEC);
		     res1931_1861 = new1440_1842;
		  }
	       }
	       arg1745_1429 = res1931_1861;
	    }
	    {
	       obj_t aux_2293;
	       object_t aux_2291;
	       aux_2293 = (obj_t) (arg1745_1429);
	       aux_2291 = (object_t) (obj1560_1428);
	       OBJECT_WIDENING_SET(aux_2291, aux_2293);
	    }
	 }
	 {
	    long arg1765_1441;
	    arg1765_1441 = class_num_218___object(sfun_ginfo_98_globalize_ginfo);
	    {
	       obj_t obj_1862;
	       obj_1862 = (obj_t) (obj1560_1428);
	       (((obj_t) CREF(obj_1862))->header = MAKE_HEADER(arg1765_1441, 0), BUNSPEC);
	    }
	 }
	 obj1560_1428;
      }
      {
	 node_t aux_2299;
	 {
	    obj_t aux_2300;
	    {
	       sfun_t obj_1864;
	       obj_1864 = (sfun_t) (fun_1418);
	       aux_2300 = (((sfun_t) CREF(obj_1864))->body);
	    }
	    aux_2299 = (node_t) (aux_2300);
	 }
	 return escape__235_globalize_escape(aux_2299);
      }
   }
}


/* _escape-fun!-default1598 */ obj_t 
_escape_fun__default1598_151_globalize_escape(obj_t env_2083, obj_t variable_2084)
{
   return escape_fun__default1598_220_globalize_escape((variable_t) (variable_2084));
}


/* set-escaping-fun! */ obj_t 
set_escaping_fun__14_globalize_escape(variable_t variable_5)
{
   {
      obj_t method1877_1596;
      obj_t class1882_1597;
      {
	 obj_t arg1885_1594;
	 obj_t arg1886_1595;
	 {
	    object_t obj_1865;
	    obj_1865 = (object_t) (variable_5);
	    {
	       obj_t pre_method_105_1866;
	       pre_method_105_1866 = PROCEDURE_REF(set_escaping_fun__env_225_globalize_escape, ((long) 2));
	       if (INTEGERP(pre_method_105_1866))
		 {
		    PROCEDURE_SET(set_escaping_fun__env_225_globalize_escape, ((long) 2), BUNSPEC);
		    arg1885_1594 = pre_method_105_1866;
		 }
	       else
		 {
		    long obj_class_num_177_1871;
		    obj_class_num_177_1871 = TYPE(obj_1865);
		    {
		       obj_t arg1177_1872;
		       arg1177_1872 = PROCEDURE_REF(set_escaping_fun__env_225_globalize_escape, ((long) 1));
		       {
			  long arg1178_1876;
			  {
			     long arg1179_1877;
			     arg1179_1877 = OBJECT_TYPE;
			     arg1178_1876 = (obj_class_num_177_1871 - arg1179_1877);
			  }
			  arg1885_1594 = VECTOR_REF(arg1177_1872, arg1178_1876);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1882;
	    object_1882 = (object_t) (variable_5);
	    {
	       long arg1180_1883;
	       {
		  long arg1181_1884;
		  long arg1182_1885;
		  arg1181_1884 = TYPE(object_1882);
		  arg1182_1885 = OBJECT_TYPE;
		  arg1180_1883 = (arg1181_1884 - arg1182_1885);
	       }
	       {
		  obj_t vector_1889;
		  vector_1889 = _classes__134___object;
		  arg1886_1595 = VECTOR_REF(vector_1889, arg1180_1883);
	       }
	    }
	 }
	 method1877_1596 = arg1885_1594;
	 class1882_1597 = arg1886_1595;
	 {
	    if (INTEGERP(method1877_1596))
	      {
		 switch ((long) CINT(method1877_1596))
		   {
		   case ((long) 0):
		      {
			 global_t variable_1603;
			 variable_1603 = (global_t) (variable_5);
			 {
			    global_ginfo_75_t obj1563_1604;
			    obj1563_1604 = ((global_ginfo_75_t) (variable_1603));
			    {
			       global_ginfo_75_t arg1890_1605;
			       {
				  global_ginfo_75_t res1932_1896;
				  {
				     obj_t global_closure_229_1892;
				     global_closure_229_1892 = BFALSE;
				     {
					global_ginfo_75_t new1536_1893;
					new1536_1893 = ((global_ginfo_75_t) BREF(GC_MALLOC(sizeof(struct global_ginfo_75))));
					((((global_ginfo_75_t) CREF(new1536_1893))->escape__117) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					((((global_ginfo_75_t) CREF(new1536_1893))->global_closure_229) = ((obj_t) global_closure_229_1892), BUNSPEC);
					res1932_1896 = new1536_1893;
				     }
				  }
				  arg1890_1605 = res1932_1896;
			       }
			       {
				  obj_t aux_2331;
				  object_t aux_2329;
				  aux_2331 = (obj_t) (arg1890_1605);
				  aux_2329 = (object_t) (obj1563_1604);
				  OBJECT_WIDENING_SET(aux_2329, aux_2331);
			       }
			    }
			    {
			       long arg1893_1607;
			       arg1893_1607 = class_num_218___object(global_ginfo_75_globalize_ginfo);
			       {
				  obj_t obj_1897;
				  obj_1897 = (obj_t) (obj1563_1604);
				  (((obj_t) CREF(obj_1897))->header = MAKE_HEADER(arg1893_1607, 0), BUNSPEC);
			       }
			    }
			    return (obj_t) (obj1563_1604);
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 global_ginfo_75_t variable_1608;
			 variable_1608 = (global_ginfo_75_t) (variable_5);
			 {
			    obj_t aux_2339;
			    {
			       object_t aux_2340;
			       aux_2340 = (object_t) (variable_1608);
			       aux_2339 = OBJECT_WIDENING(aux_2340);
			    }
			    return ((((global_ginfo_75_t) CREF(aux_2339))->escape__117) = ((bool_t) ((bool_t) 1)), BUNSPEC);
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 local_ginfo_108_t variable_1609;
			 variable_1609 = (local_ginfo_108_t) (variable_5);
			 {
			    obj_t aux_2345;
			    {
			       object_t aux_2346;
			       aux_2346 = (object_t) (variable_1609);
			       aux_2345 = OBJECT_WIDENING(aux_2346);
			    }
			    return ((((local_ginfo_108_t) CREF(aux_2345))->escape__117) = ((bool_t) ((bool_t) 1)), BUNSPEC);
			 }
		      }
		      break;
		   default:
		    case_else1883_1600:
		      if (PROCEDUREP(method1877_1596))
			{
			   return PROCEDURE_ENTRY(method1877_1596) (method1877_1596, (obj_t) (variable_5), BEOA);
			}
		      else
			{
			   obj_t fun1767_1443;
			   fun1767_1443 = PROCEDURE_REF(set_escaping_fun__env_225_globalize_escape, ((long) 0));
			   return PROCEDURE_ENTRY(fun1767_1443) (fun1767_1443, (obj_t) (variable_5), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1883_1600;
	      }
	 }
      }
   }
}


/* _set-escaping-fun!1941 */ obj_t 
_set_escaping_fun_1941_222_globalize_escape(obj_t env_2085, obj_t variable_2086)
{
   return set_escaping_fun__14_globalize_escape((variable_t) (variable_2086));
}


/* set-escaping-fun!-default1601 */ obj_t 
set_escaping_fun__default1601_120_globalize_escape(variable_t variable_6)
{
   {
      obj_t arg1770_1446;
      {
	 obj_t arg1771_1447;
	 arg1771_1447 = shape_tools_shape((obj_t) (variable_6));
	 {
	    obj_t aux_2365;
	    aux_2365 = (obj_t) (variable_6);
	    arg1770_1446 = MAKE_PAIR(aux_2365, arg1771_1447);
	 }
      }
      FAILURE(string1943_globalize_escape, string1944_globalize_escape, arg1770_1446);
   }
}


/* _set-escaping-fun!-default1601 */ obj_t 
_set_escaping_fun__default1601_79_globalize_escape(obj_t env_2087, obj_t variable_2088)
{
   return set_escaping_fun__default1601_120_globalize_escape((variable_t) (variable_2088));
}


/* escape! */ obj_t 
escape__235_globalize_escape(node_t node_10)
{
 escape__235_globalize_escape:
   {
      obj_t method1776_1454;
      obj_t class1781_1455;
      {
	 obj_t arg1786_1452;
	 obj_t arg1788_1453;
	 {
	    object_t obj_1910;
	    obj_1910 = (object_t) (node_10);
	    {
	       obj_t pre_method_105_1911;
	       pre_method_105_1911 = PROCEDURE_REF(escape__env_201_globalize_escape, ((long) 2));
	       if (INTEGERP(pre_method_105_1911))
		 {
		    PROCEDURE_SET(escape__env_201_globalize_escape, ((long) 2), BUNSPEC);
		    arg1786_1452 = pre_method_105_1911;
		 }
	       else
		 {
		    long obj_class_num_177_1916;
		    obj_class_num_177_1916 = TYPE(obj_1910);
		    {
		       obj_t arg1177_1917;
		       arg1177_1917 = PROCEDURE_REF(escape__env_201_globalize_escape, ((long) 1));
		       {
			  long arg1178_1921;
			  {
			     long arg1179_1922;
			     arg1179_1922 = OBJECT_TYPE;
			     arg1178_1921 = (obj_class_num_177_1916 - arg1179_1922);
			  }
			  arg1786_1452 = VECTOR_REF(arg1177_1917, arg1178_1921);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1927;
	    object_1927 = (object_t) (node_10);
	    {
	       long arg1180_1928;
	       {
		  long arg1181_1929;
		  long arg1182_1930;
		  arg1181_1929 = TYPE(object_1927);
		  arg1182_1930 = OBJECT_TYPE;
		  arg1180_1928 = (arg1181_1929 - arg1182_1930);
	       }
	       {
		  obj_t vector_1934;
		  vector_1934 = _classes__134___object;
		  arg1788_1453 = VECTOR_REF(vector_1934, arg1180_1928);
	       }
	    }
	 }
	 method1776_1454 = arg1786_1452;
	 class1781_1455 = arg1788_1453;
	 {
	    if (INTEGERP(method1776_1454))
	      {
		 switch ((long) CINT(method1776_1454))
		   {
		   case ((long) 0):
		      return CNST_TABLE_REF(((long) 1));
		      break;
		   case ((long) 1):
		      return CNST_TABLE_REF(((long) 1));
		      break;
		   case ((long) 2):
		      return CNST_TABLE_REF(((long) 1));
		      break;
		   case ((long) 3):
		      {
			 closure_t node_1464;
			 node_1464 = (closure_t) (node_10);
			 return set_escaping_fun__14_globalize_escape((((closure_t) CREF(node_1464))->variable));
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1466;
			 node_1466 = (sequence_t) (node_10);
			 {
			    bool_t aux_2395;
			    aux_2395 = escape___220_globalize_escape((((sequence_t) CREF(node_1466))->nodes));
			    return BBOOL(aux_2395);
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_t node_1468;
			 node_1468 = (app_t) (node_10);
			 {
			    bool_t aux_2400;
			    aux_2400 = escape___220_globalize_escape((((app_t) CREF(node_1468))->args));
			    return BBOOL(aux_2400);
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_1471;
			 node_1471 = (app_ly_162_t) (node_10);
			 escape__235_globalize_escape((((app_ly_162_t) CREF(node_1471))->fun));
			 {
			    node_t node_2407;
			    node_2407 = (((app_ly_162_t) CREF(node_1471))->arg);
			    node_10 = node_2407;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_1475;
			 node_1475 = (funcall_t) (node_10);
			 escape__235_globalize_escape((((funcall_t) CREF(node_1475))->fun));
			 {
			    bool_t aux_2412;
			    aux_2412 = escape___220_globalize_escape((((funcall_t) CREF(node_1475))->args));
			    return BBOOL(aux_2412);
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_1479;
			 node_1479 = (pragma_t) (node_10);
			 {
			    bool_t aux_2417;
			    aux_2417 = escape___220_globalize_escape((((pragma_t) CREF(node_1479))->args));
			    return BBOOL(aux_2417);
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_1481;
			 node_1481 = (cast_t) (node_10);
			 {
			    node_t node_2422;
			    node_2422 = (((cast_t) CREF(node_1481))->arg);
			    node_10 = node_2422;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_1483;
			 node_1483 = (setq_t) (node_10);
			 {
			    node_t node_2425;
			    node_2425 = (((setq_t) CREF(node_1483))->value);
			    node_10 = node_2425;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_1486;
			 node_1486 = (conditional_t) (node_10);
			 escape__235_globalize_escape((((conditional_t) CREF(node_1486))->test));
			 escape__235_globalize_escape((((conditional_t) CREF(node_1486))->true));
			 {
			    node_t node_2432;
			    node_2432 = (((conditional_t) CREF(node_1486))->false);
			    node_10 = node_2432;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_1491;
			 node_1491 = (fail_t) (node_10);
			 escape__235_globalize_escape((((fail_t) CREF(node_1491))->proc));
			 escape__235_globalize_escape((((fail_t) CREF(node_1491))->msg));
			 {
			    node_t node_2439;
			    node_2439 = (((fail_t) CREF(node_1491))->obj);
			    node_10 = node_2439;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_1496;
			 node_1496 = (select_t) (node_10);
			 escape__235_globalize_escape((((select_t) CREF(node_1496))->test));
			 {
			    obj_t l1571_1499;
			    {
			       bool_t aux_2444;
			       l1571_1499 = (((select_t) CREF(node_1496))->clauses);
			     lname1572_1500:
			       if (PAIRP(l1571_1499))
				 {
				    {
				       node_t aux_2447;
				       {
					  obj_t aux_2448;
					  {
					     obj_t aux_2449;
					     aux_2449 = CAR(l1571_1499);
					     aux_2448 = CDR(aux_2449);
					  }
					  aux_2447 = (node_t) (aux_2448);
				       }
				       escape__235_globalize_escape(aux_2447);
				    }
				    {
				       obj_t l1571_2454;
				       l1571_2454 = CDR(l1571_1499);
				       l1571_1499 = l1571_2454;
				       goto lname1572_1500;
				    }
				 }
			       else
				 {
				    aux_2444 = ((bool_t) 1);
				 }
			       return BBOOL(aux_2444);
			    }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_1506;
			 node_1506 = (let_fun_218_t) (node_10);
			 {
			    obj_t l1574_1508;
			    l1574_1508 = (((let_fun_218_t) CREF(node_1506))->locals);
			  lname1575_1509:
			    if (PAIRP(l1574_1508))
			      {
				 {
				    obj_t local_1512;
				    local_1512 = CAR(l1574_1508);
				    {
				       local_ginfo_108_t obj1576_1513;
				       obj1576_1513 = ((local_ginfo_108_t) (local_1512));
				       {
					  local_ginfo_108_t arg1816_1514;
					  {
					     local_ginfo_108_t res1934_1964;
					     {
						local_ginfo_108_t new1521_1962;
						new1521_1962 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
						((((local_ginfo_108_t) CREF(new1521_1962))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						res1934_1964 = new1521_1962;
					     }
					     arg1816_1514 = res1934_1964;
					  }
					  {
					     obj_t aux_2467;
					     object_t aux_2465;
					     aux_2467 = (obj_t) (arg1816_1514);
					     aux_2465 = (object_t) (obj1576_1513);
					     OBJECT_WIDENING_SET(aux_2465, aux_2467);
					  }
				       }
				       {
					  long arg1817_1515;
					  arg1817_1515 = class_num_218___object(local_ginfo_108_globalize_ginfo);
					  {
					     obj_t obj_1965;
					     obj_1965 = (obj_t) (obj1576_1513);
					     (((obj_t) CREF(obj_1965))->header = MAKE_HEADER(arg1817_1515, 0), BUNSPEC);
					  }
				       }
				       obj1576_1513;
				    }
				    {
				       value_t fun_1516;
				       {
					  local_t obj_1967;
					  obj_1967 = (local_t) (local_1512);
					  fun_1516 = (((local_t) CREF(obj_1967))->value);
				       }
				       {
					  sfun_ginfo_98_t obj1578_1517;
					  obj1578_1517 = ((sfun_ginfo_98_t) (fun_1516));
					  {
					     sfun_ginfo_98_t arg1818_1518;
					     {
						sfun_ginfo_98_t res1935_2005;
						{
						   obj_t cfrom__119_1970;
						   obj_t cto__14_1972;
						   obj_t the_global_201_1979;
						   obj_t kaptured_1980;
						   obj_t new_body_215_1981;
						   cfrom__119_1970 = BFALSE;
						   cto__14_1972 = BFALSE;
						   the_global_201_1979 = BFALSE;
						   kaptured_1980 = BFALSE;
						   new_body_215_1981 = BFALSE;
						   {
						      sfun_ginfo_98_t new1440_1986;
						      new1440_1986 = ((sfun_ginfo_98_t) BREF(GC_MALLOC(sizeof(struct sfun_ginfo_98))));
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->g__219) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->cfrom) = ((obj_t) BNIL), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->cfrom__119) = ((obj_t) cfrom__119_1970), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->cto) = ((obj_t) BNIL), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->cto__14) = ((obj_t) cto__14_1972), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->cfunction) = ((obj_t) BNIL), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->integrator) = ((obj_t) BNIL), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->integrated) = ((obj_t) BNIL), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->plugged_in_15) = ((obj_t) BNIL), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->mark) = ((long) ((long) -10)), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->free_mark_81) = ((obj_t) BNIL), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->the_global_201) = ((obj_t) the_global_201_1979), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->kaptured) = ((obj_t) kaptured_1980), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->new_body_215) = ((obj_t) new_body_215_1981), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->bmark) = ((long) ((long) -10)), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->umark) = ((long) ((long) -10)), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->free) = ((obj_t) BUNSPEC), BUNSPEC);
						      ((((sfun_ginfo_98_t) CREF(new1440_1986))->bound) = ((obj_t) BNIL), BUNSPEC);
						      res1935_2005 = new1440_1986;
						   }
						}
						arg1818_1518 = res1935_2005;
					     }
					     {
						obj_t aux_2497;
						object_t aux_2495;
						aux_2497 = (obj_t) (arg1818_1518);
						aux_2495 = (object_t) (obj1578_1517);
						OBJECT_WIDENING_SET(aux_2495, aux_2497);
					     }
					  }
					  {
					     long arg1833_1530;
					     arg1833_1530 = class_num_218___object(sfun_ginfo_98_globalize_ginfo);
					     {
						obj_t obj_2006;
						obj_2006 = (obj_t) (obj1578_1517);
						(((obj_t) CREF(obj_2006))->header = MAKE_HEADER(arg1833_1530, 0), BUNSPEC);
					     }
					  }
					  obj1578_1517;
				       }
				       {
					  obj_t l1579_1531;
					  {
					     sfun_t obj_2008;
					     obj_2008 = (sfun_t) (fun_1516);
					     l1579_1531 = (((sfun_t) CREF(obj_2008))->args);
					  }
					lname1580_1532:
					  if (PAIRP(l1579_1531))
					    {
					       {
						  obj_t local_1535;
						  local_1535 = CAR(l1579_1531);
						  {
						     svar_ginfo_131_t obj1582_1536;
						     {
							value_t aux_2506;
							{
							   local_t obj_2011;
							   obj_2011 = (local_t) (local_1535);
							   aux_2506 = (((local_t) CREF(obj_2011))->value);
							}
							obj1582_1536 = ((svar_ginfo_131_t) (aux_2506));
						     }
						     {
							svar_ginfo_131_t arg1836_1537;
							{
							   svar_ginfo_131_t res1936_2021;
							   {
							      svar_ginfo_131_t new1492_2016;
							      new1492_2016 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
							      ((((svar_ginfo_131_t) CREF(new1492_2016))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							      ((((svar_ginfo_131_t) CREF(new1492_2016))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
							      ((((svar_ginfo_131_t) CREF(new1492_2016))->mark) = ((long) ((long) -10)), BUNSPEC);
							      ((((svar_ginfo_131_t) CREF(new1492_2016))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							      res1936_2021 = new1492_2016;
							   }
							   arg1836_1537 = res1936_2021;
							}
							{
							   obj_t aux_2517;
							   object_t aux_2515;
							   aux_2517 = (obj_t) (arg1836_1537);
							   aux_2515 = (object_t) (obj1582_1536);
							   OBJECT_WIDENING_SET(aux_2515, aux_2517);
							}
						     }
						     {
							long arg1837_1538;
							arg1837_1538 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
							{
							   obj_t obj_2022;
							   obj_2022 = (obj_t) (obj1582_1536);
							   (((obj_t) CREF(obj_2022))->header = MAKE_HEADER(arg1837_1538, 0), BUNSPEC);
							}
						     }
						     obj1582_1536;
						  }
					       }
					       {
						  obj_t l1579_2523;
						  l1579_2523 = CDR(l1579_1531);
						  l1579_1531 = l1579_2523;
						  goto lname1580_1532;
					       }
					    }
					  else
					    {
					       ((bool_t) 1);
					    }
				       }
				    }
				 }
				 {
				    obj_t l1574_2527;
				    l1574_2527 = CDR(l1574_1508);
				    l1574_1508 = l1574_2527;
				    goto lname1575_1509;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    obj_t l1583_1541;
			    l1583_1541 = (((let_fun_218_t) CREF(node_1506))->locals);
			  lname1584_1542:
			    if (PAIRP(l1583_1541))
			      {
				 {
				    node_t aux_2532;
				    {
				       obj_t aux_2533;
				       {
					  sfun_t obj_2030;
					  {
					     value_t aux_2534;
					     {
						local_t obj_2029;
						{
						   obj_t aux_2535;
						   aux_2535 = CAR(l1583_1541);
						   obj_2029 = (local_t) (aux_2535);
						}
						aux_2534 = (((local_t) CREF(obj_2029))->value);
					     }
					     obj_2030 = (sfun_t) (aux_2534);
					  }
					  aux_2533 = (((sfun_t) CREF(obj_2030))->body);
				       }
				       aux_2532 = (node_t) (aux_2533);
				    }
				    escape__235_globalize_escape(aux_2532);
				 }
				 {
				    obj_t l1583_2543;
				    l1583_2543 = CDR(l1583_1541);
				    l1583_1541 = l1583_2543;
				    goto lname1584_1542;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_2546;
			    node_2546 = (((let_fun_218_t) CREF(node_1506))->body);
			    node_10 = node_2546;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_1550;
			 node_1550 = (let_var_6_t) (node_10);
			 escape__235_globalize_escape((((let_var_6_t) CREF(node_1550))->body));
			 {
			    obj_t l1586_1553;
			    {
			       bool_t aux_2551;
			       l1586_1553 = (((let_var_6_t) CREF(node_1550))->bindings);
			     lname1587_1554:
			       if (PAIRP(l1586_1553))
				 {
				    {
				       obj_t binding_1557;
				       binding_1557 = CAR(l1586_1553);
				       {
					  svar_ginfo_131_t obj1589_1558;
					  {
					     value_t aux_2555;
					     {
						obj_t arg1858_1561;
						arg1858_1561 = CAR(binding_1557);
						{
						   local_t obj_2038;
						   obj_2038 = (local_t) (arg1858_1561);
						   aux_2555 = (((local_t) CREF(obj_2038))->value);
						}
					     }
					     obj1589_1558 = ((svar_ginfo_131_t) (aux_2555));
					  }
					  {
					     svar_ginfo_131_t arg1856_1559;
					     {
						svar_ginfo_131_t res1937_2048;
						{
						   svar_ginfo_131_t new1492_2043;
						   new1492_2043 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
						   ((((svar_ginfo_131_t) CREF(new1492_2043))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						   ((((svar_ginfo_131_t) CREF(new1492_2043))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
						   ((((svar_ginfo_131_t) CREF(new1492_2043))->mark) = ((long) ((long) -10)), BUNSPEC);
						   ((((svar_ginfo_131_t) CREF(new1492_2043))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						   res1937_2048 = new1492_2043;
						}
						arg1856_1559 = res1937_2048;
					     }
					     {
						obj_t aux_2567;
						object_t aux_2565;
						aux_2567 = (obj_t) (arg1856_1559);
						aux_2565 = (object_t) (obj1589_1558);
						OBJECT_WIDENING_SET(aux_2565, aux_2567);
					     }
					  }
					  {
					     long arg1857_1560;
					     arg1857_1560 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
					     {
						obj_t obj_2049;
						obj_2049 = (obj_t) (obj1589_1558);
						(((obj_t) CREF(obj_2049))->header = MAKE_HEADER(arg1857_1560, 0), BUNSPEC);
					     }
					  }
					  obj1589_1558;
				       }
				       {
					  node_t aux_2573;
					  {
					     obj_t aux_2574;
					     aux_2574 = CDR(binding_1557);
					     aux_2573 = (node_t) (aux_2574);
					  }
					  escape__235_globalize_escape(aux_2573);
				       }
				    }
				    {
				       obj_t l1586_2578;
				       l1586_2578 = CDR(l1586_1553);
				       l1586_1553 = l1586_2578;
				       goto lname1587_1554;
				    }
				 }
			       else
				 {
				    aux_2551 = ((bool_t) 1);
				 }
			       return BBOOL(aux_2551);
			    }
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_1564;
			 node_1564 = (set_ex_it_116_t) (node_10);
			 {
			    sexit_ginfo_81_t obj1592_1566;
			    {
			       value_t aux_2583;
			       {
				  variable_t arg1863_1569;
				  {
				     var_t arg1864_1570;
				     arg1864_1570 = (((set_ex_it_116_t) CREF(node_1564))->var);
				     arg1863_1569 = (((var_t) CREF(arg1864_1570))->variable);
				  }
				  {
				     local_t obj_2055;
				     obj_2055 = (local_t) (arg1863_1569);
				     aux_2583 = (((local_t) CREF(obj_2055))->value);
				  }
			       }
			       obj1592_1566 = ((sexit_ginfo_81_t) (aux_2583));
			    }
			    {
			       sexit_ginfo_81_t arg1861_1567;
			       {
				  sexit_ginfo_81_t res1938_2065;
				  {
				     sexit_ginfo_81_t new1506_2060;
				     new1506_2060 = ((sexit_ginfo_81_t) BREF(GC_MALLOC(sizeof(struct sexit_ginfo_81))));
				     ((((sexit_ginfo_81_t) CREF(new1506_2060))->g__219) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				     ((((sexit_ginfo_81_t) CREF(new1506_2060))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				     ((((sexit_ginfo_81_t) CREF(new1506_2060))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
				     ((((sexit_ginfo_81_t) CREF(new1506_2060))->mark) = ((long) ((long) -10)), BUNSPEC);
				     res1938_2065 = new1506_2060;
				  }
				  arg1861_1567 = res1938_2065;
			       }
			       {
				  obj_t aux_2596;
				  object_t aux_2594;
				  aux_2596 = (obj_t) (arg1861_1567);
				  aux_2594 = (object_t) (obj1592_1566);
				  OBJECT_WIDENING_SET(aux_2594, aux_2596);
			       }
			    }
			    {
			       long arg1862_1568;
			       arg1862_1568 = class_num_218___object(sexit_ginfo_81_globalize_ginfo);
			       {
				  obj_t obj_2066;
				  obj_2066 = (obj_t) (obj1592_1566);
				  (((obj_t) CREF(obj_2066))->header = MAKE_HEADER(arg1862_1568, 0), BUNSPEC);
			       }
			    }
			    obj1592_1566;
			 }
			 {
			    node_t node_2602;
			    node_2602 = (((set_ex_it_116_t) CREF(node_1564))->body);
			    node_10 = node_2602;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_1572;
			 node_1572 = (jump_ex_it_184_t) (node_10);
			 escape__235_globalize_escape((((jump_ex_it_184_t) CREF(node_1572))->exit));
			 {
			    node_t node_2607;
			    node_2607 = (((jump_ex_it_184_t) CREF(node_1572))->value);
			    node_10 = node_2607;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_1576;
			 node_1576 = (make_box_202_t) (node_10);
			 {
			    node_t node_2610;
			    node_2610 = (((make_box_202_t) CREF(node_1576))->value);
			    node_10 = node_2610;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 19):
		      {
			 box_set__221_t node_1578;
			 node_1578 = (box_set__221_t) (node_10);
			 {
			    node_t node_2613;
			    node_2613 = (((box_set__221_t) CREF(node_1578))->value);
			    node_10 = node_2613;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   case ((long) 20):
		      {
			 box_ref_242_t node_1581;
			 node_1581 = (box_ref_242_t) (node_10);
			 {
			    node_t node_2616;
			    {
			       var_t aux_2617;
			       aux_2617 = (((box_ref_242_t) CREF(node_1581))->var);
			       node_2616 = (node_t) (aux_2617);
			    }
			    node_10 = node_2616;
			    goto escape__235_globalize_escape;
			 }
		      }
		      break;
		   default:
		    case_else1782_1458:
		      if (PROCEDUREP(method1776_1454))
			{
			   return PROCEDURE_ENTRY(method1776_1454) (method1776_1454, (obj_t) (node_10), BEOA);
			}
		      else
			{
			   obj_t fun1772_1448;
			   fun1772_1448 = PROCEDURE_REF(escape__env_201_globalize_escape, ((long) 0));
			   return PROCEDURE_ENTRY(fun1772_1448) (fun1772_1448, (obj_t) (node_10), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1782_1458;
	      }
	 }
      }
   }
}


/* _escape!1942 */ obj_t 
_escape_1942_179_globalize_escape(obj_t env_2089, obj_t node_2090)
{
   return escape__235_globalize_escape((node_t) (node_2090));
}


/* escape!-default1605 */ obj_t 
escape__default1605_80_globalize_escape(node_t node_11)
{
   FAILURE(CNST_TABLE_REF(((long) 2)), string1945_globalize_escape, (obj_t) (node_11));
}


/* _escape!-default1605 */ obj_t 
_escape__default1605_91_globalize_escape(obj_t env_2091, obj_t node_2092)
{
   return escape__default1605_80_globalize_escape((node_t) (node_2092));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_escape()
{
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_ESCAPE");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_ESCAPE");
   module_initialization_70_engine_param(((long) 0), "GLOBALIZE_ESCAPE");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_ESCAPE");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_ESCAPE");
   return module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_ESCAPE");
}
