/*===========================================================================*/
/*   (Tools/misc.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t string_to_symbol(char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
static obj_t _replace__98_tools_misc(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_tools_misc();
extern obj_t replace__160_tools_misc(obj_t, obj_t);
obj_t _4dots_199_tools_misc = BUNSPEC;
static obj_t require_initialization_114_tools_misc = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(replace__env_157_tools_misc, _replace__98_tools_misc1010, _replace__98_tools_misc, 0L, 2);
DEFINE_STRING(string1008_tools_misc, string1008_tools_misc1011, "::", 2);


/* module-initialization */ obj_t 
module_initialization_70_tools_misc(long checksum_22, char *from_23)
{
   if (CBOOL(require_initialization_114_tools_misc))
     {
	require_initialization_114_tools_misc = BBOOL(((bool_t) 0));
	toplevel_init_63_tools_misc();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* toplevel-init */ obj_t 
toplevel_init_63_tools_misc()
{
   {
      char *aux_28;
      aux_28 = BSTRING_TO_STRING(string1008_tools_misc);
      return (_4dots_199_tools_misc = string_to_symbol(aux_28),
	 BUNSPEC);
   }
}


/* replace! */ obj_t 
replace__160_tools_misc(obj_t p1_1, obj_t p2_2)
{
   {
      bool_t test1002_3;
      if (PAIRP(p1_1))
	{
	   if (PAIRP(p2_2))
	     {
		bool_t test1007_8;
		test1007_8 = EXTENDED_PAIRP(p2_2);
		if (test1007_8)
		  {
		     test1002_3 = ((bool_t) 0);
		  }
		else
		  {
		     test1002_3 = ((bool_t) 1);
		  }
	     }
	   else
	     {
		test1002_3 = ((bool_t) 0);
	     }
	}
      else
	{
	   test1002_3 = ((bool_t) 0);
	}
      if (test1002_3)
	{
	   {
	      obj_t aux_38;
	      aux_38 = CAR(p2_2);
	      SET_CAR(p1_1, aux_38);
	   }
	   {
	      obj_t aux_41;
	      aux_41 = CDR(p2_2);
	      SET_CDR(p1_1, aux_41);
	   }
	   return p1_1;
	}
      else
	{
	   return p2_2;
	}
   }
}


/* _replace! */ obj_t 
_replace__98_tools_misc(obj_t env_19, obj_t p1_20, obj_t p2_21)
{
   return replace__160_tools_misc(p1_20, p2_21);
}
