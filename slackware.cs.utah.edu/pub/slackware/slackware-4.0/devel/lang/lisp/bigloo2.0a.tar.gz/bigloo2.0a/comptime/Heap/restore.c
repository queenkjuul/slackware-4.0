/*===========================================================================*/
/*   (Heap/restore.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t escape_1341_heap_restore(obj_t, obj_t);
static obj_t body1194_heap_restore(obj_t);
static obj_t method_init_76_heap_restore();
static obj_t body1184_heap_restore(obj_t);
extern obj_t exitd_top;
extern obj_t _nb_error_on_pass__70_tools_error;
static obj_t restore_additional_heap_154_heap_restore(obj_t);
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
static obj_t unbind_call_cc__206_heap_restore();
static obj_t _restore_heap_238_heap_restore(obj_t);
static obj_t handling_function1297_heap_restore(obj_t, obj_t, obj_t, obj_t);
static obj_t handling_function1234_heap_restore(obj_t, obj_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_heap_restore(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_engine_engine(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t unbind_global__45_ast_env(obj_t, obj_t);
extern obj_t notify_error_43___error(obj_t, obj_t, obj_t);
static obj_t handler_1342_heap_restore(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _heap_name__135_engine_param;
extern obj_t exit_bigloo_229_init_main(obj_t);
static obj_t imported_modules_init_94_heap_restore();
static obj_t handler_heap_restore(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1193_heap_restore(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _additional_include_foreign__44_engine_param;
static obj_t rhandler1183_heap_restore(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_heap_restore();
extern obj_t add_genv__67_ast_env(obj_t);
extern obj_t input_obj(obj_t);
extern obj_t _call_cc___102_engine_param;
extern obj_t open_input_string(obj_t);
static obj_t _restore_additional_heaps_52_heap_restore(obj_t);
extern obj_t close_binary_port(obj_t);
extern obj_t _lib_dir__34_engine_param;
extern obj_t add_tenv__100_type_env(obj_t);
extern obj_t set_genv__34_ast_env(obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t arg1299_heap_restore(obj_t);
static obj_t arg1298_heap_restore(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t arg1236_heap_restore(obj_t);
static obj_t arg1235_heap_restore(obj_t);
extern obj_t open_input_binary_file(obj_t);
extern obj_t restore_additional_heaps_23_heap_restore();
extern obj_t remove_error_handler__102___error();
extern obj_t restore_heap_59_heap_restore();
extern obj_t read___reader(obj_t);
extern obj_t set_tenv__70_type_env(obj_t);
static obj_t escape_heap_restore(obj_t, obj_t);
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t require_initialization_114_heap_restore = BUNSPEC;
extern obj_t _additional_heap_names__104_engine_param;
static obj_t cnst_init_137_heap_restore();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(restore_heap_env_119_heap_restore, _restore_heap_238_heap_restore1359, _restore_heap_238_heap_restore, 0L, 0);
DEFINE_EXPORT_PROCEDURE(restore_additional_heaps_env_241_heap_restore, _restore_additional_heaps_52_heap_restore1360, _restore_additional_heaps_52_heap_restore, 0L, 0);
DEFINE_STRING(string1353_heap_restore, string1353_heap_restore1361, "CALL-WITH-CURRENT-CONTINUATION __R4_CONTROL_FEATURES_6_9 CALL/CC PASS-STARTED ", 78);
DEFINE_STRING(string1352_heap_restore, string1352_heap_restore1362, "restore-additional-heap", 23);
DEFINE_STRING(string1351_heap_restore, string1351_heap_restore1363, "Library", 7);
DEFINE_STRING(string1349_heap_restore, string1349_heap_restore1364, "Cannot open heap file", 21);
DEFINE_STRING(string1350_heap_restore, string1350_heap_restore1365, "Cannot find heap file", 21);
DEFINE_STRING(string1348_heap_restore, string1348_heap_restore1366, "restore-heap", 12);
DEFINE_STRING(string1347_heap_restore, string1347_heap_restore1367, "      [reading ", 15);
DEFINE_STRING(string1346_heap_restore, string1346_heap_restore1368, "]", 1);
DEFINE_STRING(string1345_heap_restore, string1345_heap_restore1369, "failure during prelude hook", 27);
DEFINE_STRING(string1344_heap_restore, string1344_heap_restore1370, "   . ", 5);
DEFINE_STRING(string1343_heap_restore, string1343_heap_restore1371, "Heap", 4);


/* module-initialization */ obj_t 
module_initialization_70_heap_restore(long checksum_720, char *from_721)
{
   if (CBOOL(require_initialization_114_heap_restore))
     {
	require_initialization_114_heap_restore = BBOOL(((bool_t) 0));
	library_modules_init_112_heap_restore();
	cnst_init_137_heap_restore();
	imported_modules_init_94_heap_restore();
	method_init_76_heap_restore();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_heap_restore()
{
   module_initialization_70___bexit(((long) 0), "HEAP_RESTORE");
   module_initialization_70___error(((long) 0), "HEAP_RESTORE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "HEAP_RESTORE");
   module_initialization_70___r4_control_features_6_9(((long) 0), "HEAP_RESTORE");
   module_initialization_70___reader(((long) 0), "HEAP_RESTORE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_heap_restore()
{
   {
      obj_t cnst_port_138_712;
      cnst_port_138_712 = open_input_string(string1353_heap_restore);
      {
	 long i_713;
	 i_713 = ((long) 3);
       loop_714:
	 {
	    bool_t test1354_715;
	    test1354_715 = (i_713 == ((long) -1));
	    if (test1354_715)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1355_716;
		    {
		       obj_t list1356_717;
		       {
			  obj_t arg1357_718;
			  arg1357_718 = BNIL;
			  list1356_717 = MAKE_PAIR(cnst_port_138_712, arg1357_718);
		       }
		       arg1355_716 = read___reader(list1356_717);
		    }
		    CNST_TABLE_SET(i_713, arg1355_716);
		 }
		 {
		    int aux_719;
		    {
		       long aux_740;
		       aux_740 = (i_713 - ((long) 1));
		       aux_719 = (int) (aux_740);
		    }
		    {
		       long i_743;
		       i_743 = (long) (aux_719);
		       i_713 = i_743;
		       goto loop_714;
		    }
		 }
	      }
	 }
      }
   }
}


/* restore-heap */ obj_t 
restore_heap_59_heap_restore()
{
   {
      bool_t test1200_302;
      {
	 obj_t obj_581;
	 obj_581 = _heap_name__135_engine_param;
	 test1200_302 = STRINGP(obj_581);
      }
      if (test1200_302)
	{
	   {
	      obj_t list1201_303;
	      {
		 obj_t arg1203_305;
		 {
		    obj_t arg1205_307;
		    {
		       obj_t aux_747;
		       aux_747 = BCHAR(((unsigned char) '\n'));
		       arg1205_307 = MAKE_PAIR(aux_747, BNIL);
		    }
		    arg1203_305 = MAKE_PAIR(string1343_heap_restore, arg1205_307);
		 }
		 list1201_303 = MAKE_PAIR(string1344_heap_restore, arg1203_305);
	      }
	      verbose_tools_speek(BINT(((long) 1)), list1201_303);
	   }
	   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
	   _current_pass__25_engine_pass = string1343_heap_restore;
	   {
	      obj_t hooks_309;
	      obj_t hnames_310;
	      hooks_309 = BNIL;
	      hnames_310 = BNIL;
	    loop_311:
	      if (NULLP(hooks_309))
		{
		   CNST_TABLE_REF(((long) 0));
		}
	      else
		{
		   bool_t test1212_316;
		   {
		      obj_t fun1221_322;
		      fun1221_322 = CAR(hooks_309);
		      {
			 obj_t aux_759;
			 aux_759 = PROCEDURE_ENTRY(fun1221_322) (fun1221_322, BEOA);
			 test1212_316 = CBOOL(aux_759);
		      }
		   }
		   if (test1212_316)
		     {
			{
			   obj_t hnames_766;
			   obj_t hooks_764;
			   hooks_764 = CDR(hooks_309);
			   hnames_766 = CDR(hnames_310);
			   hnames_310 = hnames_766;
			   hooks_309 = hooks_764;
			   goto loop_311;
			}
		     }
		   else
		     {
			internal_error_43_tools_error(string1343_heap_restore, string1345_heap_restore, CAR(hnames_310));
		     }
		}
	   }
	   {
	      obj_t fname_323;
	      fname_323 = find_file_path_55_tools_file(_heap_name__135_engine_param, _lib_dir__34_engine_param);
	      if (STRINGP(fname_323))
		{
		   obj_t port_325;
		   port_325 = open_input_binary_file(fname_323);
		   {
		      obj_t handler_635;
		      handler_635 = make_fx_procedure(handler_heap_restore, ((long) 4), ((long) 1));
		      PROCEDURE_SET(handler_635, ((long) 0), port_325);
		      {
			 if (BINARY_PORTP(port_325))
			   {
			      {
				 obj_t list1224_328;
				 {
				    obj_t arg1226_330;
				    {
				       obj_t arg1228_331;
				       {
					  obj_t arg1232_333;
					  {
					     obj_t aux_778;
					     aux_778 = BCHAR(((unsigned char) '\n'));
					     arg1232_333 = MAKE_PAIR(aux_778, BNIL);
					  }
					  arg1228_331 = MAKE_PAIR(string1346_heap_restore, arg1232_333);
				       }
				       arg1226_330 = MAKE_PAIR(fname_323, arg1228_331);
				    }
				    list1224_328 = MAKE_PAIR(string1347_heap_restore, arg1226_330);
				 }
				 verbose_tools_speek(BINT(((long) 2)), list1224_328);
			      }
			      {
				 obj_t armed1185_335;
				 obj_t handler1182_336;
				 armed1185_335 = MAKE_CELL(BUNSPEC);
				 handler1182_336 = MAKE_CELL(BUNSPEC);
				 {
				    obj_t body1184_631;
				    obj_t rhandler1183_633;
				    body1184_631 = make_fx_procedure(body1184_heap_restore, ((long) 0), ((long) 1));
				    rhandler1183_633 = make_fx_procedure(rhandler1183_heap_restore, ((long) 4), ((long) 2));
				    PROCEDURE_SET(body1184_631, ((long) 0), port_325);
				    PROCEDURE_SET(rhandler1183_633, ((long) 0), armed1185_335);
				    PROCEDURE_SET(rhandler1183_633, ((long) 1), handler1182_336);
				    CELL_SET(handler1182_336, handler_635);
				    CELL_SET(armed1185_335, BTRUE);
				    return handling_function1234_heap_restore(body1184_631, rhandler1183_633, handler1182_336, armed1185_335);
				 }
			      }
			   }
			 else
			   {
			      FAILURE(string1348_heap_restore, string1349_heap_restore, fname_323);
			   }
		      }
		   }
		}
	      else
		{
		   {
		      obj_t object_601;
		      object_601 = _heap_name__135_engine_param;
		      FAILURE(string1348_heap_restore, string1350_heap_restore, object_601);
		   }
		   return exit_bigloo_229_init_main(BINT(((long) -5)));
		}
	   }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* handling_function1234 */ obj_t 
handling_function1234_heap_restore(obj_t body1184_711, obj_t rhandler1183_710, obj_t handler1182_709, obj_t armed1185_708)
{
   jmp_buf jmpbuf;
   obj_t an_exit1186_340;
   if (SET_EXIT(an_exit1186_340))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1186_340 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1186_340, ((bool_t) 1));
	   {
	      obj_t an_exitd1187_341;
	      an_exitd1187_341 = exitd_top;
	      {
		 obj_t escape_632;
		 escape_632 = make_fx_procedure(escape_heap_restore, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_632, ((long) 0), an_exitd1187_341);
		 {
		    obj_t res1189_344;
		    {
		       obj_t arg1236_630;
		       obj_t arg1235_634;
		       arg1236_630 = make_fx_procedure(arg1236_heap_restore, ((long) 0), ((long) 1));
		       arg1235_634 = make_fx_procedure(arg1235_heap_restore, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1236_630, ((long) 0), armed1185_708);
		       PROCEDURE_SET(arg1235_634, ((long) 0), an_exitd1187_341);
		       PROCEDURE_SET(arg1235_634, ((long) 1), armed1185_708);
		       PROCEDURE_SET(arg1235_634, ((long) 2), handler1182_709);
		       PROCEDURE_SET(arg1235_634, ((long) 3), rhandler1183_710);
		       PROCEDURE_SET(arg1235_634, ((long) 4), escape_632);
		       res1189_344 = dynamic_wind_31___r4_control_features_6_9(arg1235_634, body1184_711, arg1236_630);
		    }
		    POP_EXIT();
		    return res1189_344;
		 }
	      }
	   }
	}
     }
}


/* _restore-heap */ obj_t 
_restore_heap_238_heap_restore(obj_t env_636)
{
   return restore_heap_59_heap_restore();
}


/* arg1236 */ obj_t 
arg1236_heap_restore(obj_t env_637)
{
   {
      obj_t armed1185_638;
      armed1185_638 = PROCEDURE_REF(env_637, ((long) 0));
      {
	 {
	    bool_t test_815;
	    {
	       obj_t aux_816;
	       aux_816 = CELL_REF(armed1185_638);
	       test_815 = CBOOL(aux_816);
	    }
	    if (test_815)
	      {
		 CELL_SET(armed1185_638, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1184 */ obj_t 
body1184_heap_restore(obj_t env_640)
{
   {
      obj_t port_641;
      port_641 = PROCEDURE_REF(env_640, ((long) 0));
      {
	 {
	    bool_t aux_820;
	    {
	       obj_t envs_357;
	       envs_357 = input_obj(port_641);
	       {
		  obj_t genv_358;
		  genv_358 = CAR(envs_357);
		  {
		     obj_t tenv_359;
		     tenv_359 = CDR(envs_357);
		     {
			close_binary_port(port_641);
			set_genv__34_ast_env(genv_358);
			set_tenv__70_type_env(tenv_359);
			if (CBOOL(_call_cc___102_engine_param))
			  {
			     BUNSPEC;
			  }
			else
			  {
			     unbind_call_cc__206_heap_restore();
			  }
			aux_820 = ((bool_t) 1);
		     }
		  }
	       }
	    }
	    return BBOOL(aux_820);
	 }
      }
   }
}


/* arg1235 */ obj_t 
arg1235_heap_restore(obj_t env_642)
{
   {
      obj_t rhandler1183_646;
      obj_t escape_647;
      rhandler1183_646 = PROCEDURE_REF(env_642, ((long) 3));
      escape_647 = PROCEDURE_REF(env_642, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1183_646, escape_647);
      }
   }
}


/* escape */ obj_t 
escape_heap_restore(obj_t env_648, obj_t val1188_650)
{
   {
      obj_t an_exitd1187_649;
      an_exitd1187_649 = PROCEDURE_REF(env_648, ((long) 0));
      {
	 obj_t val1188_342;
	 val1188_342 = val1188_650;
	 return unwind_until__178___bexit(an_exitd1187_649, val1188_342);
      }
   }
}


/* rhandler1183 */ obj_t 
rhandler1183_heap_restore(obj_t env_651, obj_t esc_654, obj_t obj_655, obj_t proc_656, obj_t msg_657)
{
   {
      obj_t armed1185_652;
      obj_t handler1182_653;
      armed1185_652 = PROCEDURE_REF(env_651, ((long) 0));
      handler1182_653 = PROCEDURE_REF(env_651, ((long) 1));
      {
	 obj_t esc_351;
	 obj_t obj_352;
	 obj_t proc_353;
	 obj_t msg_354;
	 esc_351 = esc_654;
	 obj_352 = obj_655;
	 proc_353 = proc_656;
	 msg_354 = msg_657;
	 CELL_SET(armed1185_652, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_840;
	    aux_840 = CELL_REF(handler1182_653);
	    return PROCEDURE_ENTRY(aux_840) (CELL_REF(handler1182_653), esc_351, obj_352, proc_353, msg_354, BEOA);
	 }
      }
   }
}


/* handler */ obj_t 
handler_heap_restore(obj_t env_659, obj_t escape_661, obj_t proc_662, obj_t mes_663, obj_t obj_664)
{
   {
      obj_t port_660;
      port_660 = PROCEDURE_REF(env_659, ((long) 0));
      {
	 obj_t escape_362;
	 obj_t proc_363;
	 obj_t mes_364;
	 obj_t obj_365;
	 escape_362 = escape_661;
	 proc_363 = proc_662;
	 mes_364 = mes_663;
	 obj_365 = obj_664;
	 notify_error_43___error(proc_363, mes_364, obj_365);
	 close_binary_port(port_660);
	 return exit_bigloo_229_init_main(BINT(((long) -5)));
      }
   }
}


/* unbind-call/cc! */ obj_t 
unbind_call_cc__206_heap_restore()
{
   {
      bool_t test1242_368;
      {
	 obj_t arg1245_371;
	 arg1245_371 = CNST_TABLE_REF(((long) 1));
	 {
	    obj_t list1248_373;
	    {
	       obj_t aux_847;
	       aux_847 = CNST_TABLE_REF(((long) 2));
	       list1248_373 = MAKE_PAIR(aux_847, BNIL);
	    }
	    {
	       obj_t aux_850;
	       aux_850 = find_global_223_ast_env(arg1245_371, list1248_373);
	       test1242_368 = CBOOL(aux_850);
	    }
	 }
      }
      if (test1242_368)
	{
	   unbind_global__45_ast_env(CNST_TABLE_REF(((long) 1)), CNST_TABLE_REF(((long) 2)));
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      bool_t test1251_375;
      {
	 obj_t arg1254_378;
	 arg1254_378 = CNST_TABLE_REF(((long) 3));
	 {
	    obj_t list1256_380;
	    {
	       obj_t aux_858;
	       aux_858 = CNST_TABLE_REF(((long) 2));
	       list1256_380 = MAKE_PAIR(aux_858, BNIL);
	    }
	    {
	       obj_t aux_861;
	       aux_861 = find_global_223_ast_env(arg1254_378, list1256_380);
	       test1251_375 = CBOOL(aux_861);
	    }
	 }
      }
      if (test1251_375)
	{
	   return unbind_global__45_ast_env(CNST_TABLE_REF(((long) 3)), CNST_TABLE_REF(((long) 2)));
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* restore-additional-heaps */ obj_t 
restore_additional_heaps_23_heap_restore()
{
   {
      bool_t test1258_382;
      {
	 obj_t obj_602;
	 obj_602 = _additional_heap_names__104_engine_param;
	 test1258_382 = PAIRP(obj_602);
      }
      if (test1258_382)
	{
	   {
	      obj_t list1259_383;
	      {
		 obj_t arg1262_385;
		 {
		    obj_t arg1265_387;
		    {
		       obj_t aux_870;
		       aux_870 = BCHAR(((unsigned char) '\n'));
		       arg1265_387 = MAKE_PAIR(aux_870, BNIL);
		    }
		    arg1262_385 = MAKE_PAIR(string1351_heap_restore, arg1265_387);
		 }
		 list1259_383 = MAKE_PAIR(string1344_heap_restore, arg1262_385);
	      }
	      verbose_tools_speek(BINT(((long) 1)), list1259_383);
	   }
	   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
	   _current_pass__25_engine_pass = string1351_heap_restore;
	   {
	      obj_t hooks_389;
	      obj_t hnames_390;
	      hooks_389 = BNIL;
	      hnames_390 = BNIL;
	    loop_391:
	      if (NULLP(hooks_389))
		{
		   CNST_TABLE_REF(((long) 0));
		}
	      else
		{
		   bool_t test1272_396;
		   {
		      obj_t fun1282_402;
		      fun1282_402 = CAR(hooks_389);
		      {
			 obj_t aux_882;
			 aux_882 = PROCEDURE_ENTRY(fun1282_402) (fun1282_402, BEOA);
			 test1272_396 = CBOOL(aux_882);
		      }
		   }
		   if (test1272_396)
		     {
			{
			   obj_t hnames_889;
			   obj_t hooks_887;
			   hooks_887 = CDR(hooks_389);
			   hnames_889 = CDR(hnames_390);
			   hnames_390 = hnames_889;
			   hooks_389 = hooks_887;
			   goto loop_391;
			}
		     }
		   else
		     {
			internal_error_43_tools_error(string1351_heap_restore, string1345_heap_restore, CAR(hnames_390));
		     }
		}
	   }
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      obj_t l1190_403;
      {
	 bool_t aux_893;
	 l1190_403 = _additional_heap_names__104_engine_param;
       lname1191_404:
	 if (PAIRP(l1190_403))
	   {
	      restore_additional_heap_154_heap_restore(CAR(l1190_403));
	      {
		 obj_t l1190_898;
		 l1190_898 = CDR(l1190_403);
		 l1190_403 = l1190_898;
		 goto lname1191_404;
	      }
	   }
	 else
	   {
	      aux_893 = ((bool_t) 1);
	   }
	 return BBOOL(aux_893);
      }
   }
}


/* _restore-additional-heaps */ obj_t 
_restore_additional_heaps_52_heap_restore(obj_t env_667)
{
   return restore_additional_heaps_23_heap_restore();
}


/* restore-additional-heap */ obj_t 
restore_additional_heap_154_heap_restore(obj_t heap_1)
{
   {
      obj_t fname_408;
      fname_408 = find_file_path_55_tools_file(heap_1, _lib_dir__34_engine_param);
      if (STRINGP(fname_408))
	{
	   obj_t port_410;
	   port_410 = open_input_binary_file(fname_408);
	   {
	      obj_t handler_673;
	      handler_673 = make_fx_procedure(handler_1342_heap_restore, ((long) 4), ((long) 1));
	      PROCEDURE_SET(handler_673, ((long) 0), port_410);
	      {
		 if (BINARY_PORTP(port_410))
		   {
		      {
			 obj_t list1288_413;
			 {
			    obj_t arg1291_415;
			    {
			       obj_t arg1292_416;
			       {
				  obj_t arg1295_418;
				  {
				     obj_t aux_910;
				     aux_910 = BCHAR(((unsigned char) '\n'));
				     arg1295_418 = MAKE_PAIR(aux_910, BNIL);
				  }
				  arg1292_416 = MAKE_PAIR(string1346_heap_restore, arg1295_418);
			       }
			       arg1291_415 = MAKE_PAIR(fname_408, arg1292_416);
			    }
			    list1288_413 = MAKE_PAIR(string1347_heap_restore, arg1291_415);
			 }
			 verbose_tools_speek(BINT(((long) 2)), list1288_413);
		      }
		      {
			 obj_t armed1195_420;
			 obj_t handler1192_421;
			 armed1195_420 = MAKE_CELL(BUNSPEC);
			 handler1192_421 = MAKE_CELL(BUNSPEC);
			 {
			    obj_t body1194_669;
			    obj_t rhandler1193_671;
			    body1194_669 = make_fx_procedure(body1194_heap_restore, ((long) 0), ((long) 1));
			    rhandler1193_671 = make_fx_procedure(rhandler1193_heap_restore, ((long) 4), ((long) 2));
			    PROCEDURE_SET(body1194_669, ((long) 0), port_410);
			    PROCEDURE_SET(rhandler1193_671, ((long) 0), armed1195_420);
			    PROCEDURE_SET(rhandler1193_671, ((long) 1), handler1192_421);
			    CELL_SET(handler1192_421, handler_673);
			    CELL_SET(armed1195_420, BTRUE);
			    return handling_function1297_heap_restore(body1194_669, rhandler1193_671, handler1192_421, armed1195_420);
			 }
		      }
		   }
		 else
		   {
		      FAILURE(string1352_heap_restore, string1349_heap_restore, fname_408);
		   }
	      }
	   }
	}
      else
	{
	   FAILURE(string1352_heap_restore, string1350_heap_restore, heap_1);
	}
   }
}


/* handling_function1297 */ obj_t 
handling_function1297_heap_restore(obj_t body1194_707, obj_t rhandler1193_706, obj_t handler1192_705, obj_t armed1195_704)
{
   jmp_buf jmpbuf;
   obj_t an_exit1196_425;
   if (SET_EXIT(an_exit1196_425))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1196_425 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1196_425, ((bool_t) 1));
	   {
	      obj_t an_exitd1197_426;
	      an_exitd1197_426 = exitd_top;
	      {
		 obj_t escape_670;
		 escape_670 = make_fx_procedure(escape_1341_heap_restore, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_670, ((long) 0), an_exitd1197_426);
		 {
		    obj_t res1199_429;
		    {
		       obj_t arg1299_668;
		       obj_t arg1298_672;
		       arg1299_668 = make_fx_procedure(arg1299_heap_restore, ((long) 0), ((long) 1));
		       arg1298_672 = make_fx_procedure(arg1298_heap_restore, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1299_668, ((long) 0), armed1195_704);
		       PROCEDURE_SET(arg1298_672, ((long) 0), an_exitd1197_426);
		       PROCEDURE_SET(arg1298_672, ((long) 1), armed1195_704);
		       PROCEDURE_SET(arg1298_672, ((long) 2), handler1192_705);
		       PROCEDURE_SET(arg1298_672, ((long) 3), rhandler1193_706);
		       PROCEDURE_SET(arg1298_672, ((long) 4), escape_670);
		       res1199_429 = dynamic_wind_31___r4_control_features_6_9(arg1298_672, body1194_707, arg1299_668);
		    }
		    POP_EXIT();
		    return res1199_429;
		 }
	      }
	   }
	}
     }
}


/* arg1299 */ obj_t 
arg1299_heap_restore(obj_t env_674)
{
   {
      obj_t armed1195_675;
      armed1195_675 = PROCEDURE_REF(env_674, ((long) 0));
      {
	 {
	    bool_t test_946;
	    {
	       obj_t aux_947;
	       aux_947 = CELL_REF(armed1195_675);
	       test_946 = CBOOL(aux_947);
	    }
	    if (test_946)
	      {
		 CELL_SET(armed1195_675, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1194 */ obj_t 
body1194_heap_restore(obj_t env_677)
{
   {
      obj_t port_678;
      port_678 = PROCEDURE_REF(env_677, ((long) 0));
      {
	 {
	    bool_t aux_951;
	    {
	       obj_t envs_442;
	       envs_442 = input_obj(port_678);
	       {
		  obj_t genv_443;
		  genv_443 = VECTOR_REF(envs_442, ((long) 0));
		  {
		     obj_t tenv_444;
		     tenv_444 = VECTOR_REF(envs_442, ((long) 1));
		     {
			obj_t includes_445;
			includes_445 = VECTOR_REF(envs_442, ((long) 2));
			{
			   close_binary_port(port_678);
			   add_tenv__100_type_env(tenv_444);
			   add_genv__67_ast_env(genv_443);
			   _additional_include_foreign__44_engine_param = append_2_18___r4_pairs_and_lists_6_3(_additional_include_foreign__44_engine_param, includes_445);
			   aux_951 = ((bool_t) 1);
			}
		     }
		  }
	       }
	    }
	    return BBOOL(aux_951);
	 }
      }
   }
}


/* arg1298 */ obj_t 
arg1298_heap_restore(obj_t env_679)
{
   {
      obj_t rhandler1193_683;
      obj_t escape_684;
      rhandler1193_683 = PROCEDURE_REF(env_679, ((long) 3));
      escape_684 = PROCEDURE_REF(env_679, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1193_683, escape_684);
      }
   }
}


/* escape_1341 */ obj_t 
escape_1341_heap_restore(obj_t env_685, obj_t val1198_687)
{
   {
      obj_t an_exitd1197_686;
      an_exitd1197_686 = PROCEDURE_REF(env_685, ((long) 0));
      {
	 obj_t val1198_427;
	 val1198_427 = val1198_687;
	 return unwind_until__178___bexit(an_exitd1197_686, val1198_427);
      }
   }
}


/* rhandler1193 */ obj_t 
rhandler1193_heap_restore(obj_t env_688, obj_t esc_691, obj_t obj_692, obj_t proc_693, obj_t msg_694)
{
   {
      obj_t armed1195_689;
      obj_t handler1192_690;
      armed1195_689 = PROCEDURE_REF(env_688, ((long) 0));
      handler1192_690 = PROCEDURE_REF(env_688, ((long) 1));
      {
	 obj_t esc_436;
	 obj_t obj_437;
	 obj_t proc_438;
	 obj_t msg_439;
	 esc_436 = esc_691;
	 obj_437 = obj_692;
	 proc_438 = proc_693;
	 msg_439 = msg_694;
	 CELL_SET(armed1195_689, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_970;
	    aux_970 = CELL_REF(handler1192_690);
	    return PROCEDURE_ENTRY(aux_970) (CELL_REF(handler1192_690), esc_436, obj_437, proc_438, msg_439, BEOA);
	 }
      }
   }
}


/* handler_1342 */ obj_t 
handler_1342_heap_restore(obj_t env_696, obj_t escape_698, obj_t proc_699, obj_t mes_700, obj_t obj_701)
{
   {
      obj_t port_697;
      port_697 = PROCEDURE_REF(env_696, ((long) 0));
      {
	 obj_t escape_448;
	 obj_t proc_449;
	 obj_t mes_450;
	 obj_t obj_451;
	 escape_448 = escape_698;
	 proc_449 = proc_699;
	 mes_450 = mes_700;
	 obj_451 = obj_701;
	 notify_error_43___error(proc_449, mes_450, obj_451);
	 close_binary_port(port_697);
	 return exit_bigloo_229_init_main(BINT(((long) -6)));
      }
   }
}


/* method-init */ obj_t 
method_init_76_heap_restore()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_heap_restore()
{
   module_initialization_70_tools_speek(((long) 0), "HEAP_RESTORE");
   module_initialization_70_tools_error(((long) 0), "HEAP_RESTORE");
   module_initialization_70_engine_pass(((long) 0), "HEAP_RESTORE");
   module_initialization_70_engine_param(((long) 0), "HEAP_RESTORE");
   module_initialization_70_engine_engine(((long) 0), "HEAP_RESTORE");
   module_initialization_70_init_main(((long) 0), "HEAP_RESTORE");
   module_initialization_70_tools_file(((long) 0), "HEAP_RESTORE");
   module_initialization_70_ast_env(((long) 0), "HEAP_RESTORE");
   module_initialization_70_type_type(((long) 0), "HEAP_RESTORE");
   module_initialization_70_type_env(((long) 0), "HEAP_RESTORE");
   return module_initialization_70_ast_var(((long) 0), "HEAP_RESTORE");
}
