/*===========================================================================*/
/*   (Llib/os.scm)                                                           */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _suffix1253___os(obj_t, obj_t);
static obj_t symbol1521___os = BUNSPEC;
static obj_t symbol1519___os = BUNSPEC;
static obj_t symbol1520___os = BUNSPEC;
static obj_t symbol1517___os = BUNSPEC;
static obj_t symbol1516___os = BUNSPEC;
static obj_t symbol1515___os = BUNSPEC;
static obj_t symbol1514___os = BUNSPEC;
static obj_t symbol1510___os = BUNSPEC;
static obj_t symbol1495___os = BUNSPEC;
static obj_t symbol1505___os = BUNSPEC;
static obj_t symbol1504___os = BUNSPEC;
static obj_t symbol1503___os = BUNSPEC;
extern obj_t prefix___os(obj_t);
extern obj_t make_static_library_name_134___os(obj_t);
extern obj_t command_line_67___os();
extern obj_t string_to_symbol(char *);
static obj_t _chdir1249___os(obj_t, obj_t);
static obj_t _getenv1247___os(obj_t, obj_t);
extern obj_t c_signal(int, obj_t);
obj_t os_arch_255___os = BUNSPEC;
obj_t os_name_233___os = BUNSPEC;
obj_t path_separator_174___os = BUNSPEC;
static obj_t _basename1250___os(obj_t, obj_t);
static obj_t toplevel_init_63___os();
obj_t os_version_65___os = BUNSPEC;
static obj_t _make_static_library_name1255_74___os(obj_t, obj_t);
static obj_t _executable_name_113___os(obj_t);
extern obj_t dirname___os(obj_t);
extern obj_t signal___os(int, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t _make_shared_library_name1256_77___os(obj_t, obj_t);
static obj_t _system1248___os(obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t pwd___os();
static obj_t _make_file_name1254_212___os(obj_t, obj_t, obj_t);
extern obj_t basename___os(obj_t);
static obj_t _date___os(obj_t);
static obj_t lambda1013___os(obj_t);
static obj_t lambda1012___os(obj_t);
static obj_t lambda1011___os(obj_t);
static obj_t lambda1009___os(obj_t);
static obj_t lambda1008___os(obj_t);
static obj_t lambda1007___os(obj_t);
static obj_t lambda1005___os(obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_string(long, unsigned char);
extern obj_t suffix___os(obj_t);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___error(long, char *);
obj_t file_separator_81___os = BUNSPEC;
extern obj_t system___os(char *);
extern obj_t c_substring(obj_t, long, long);
extern obj_t get_signal_handler(int);
static obj_t _command_line_112___os(obj_t);
static obj_t _pwd___os(obj_t);
extern obj_t make_shared_library_name_78___os(obj_t);
static obj_t _signal1245___os(obj_t, obj_t, obj_t);
obj_t os_tmp_175___os = BUNSPEC;
static obj_t _prefix1251___os(obj_t, obj_t);
extern obj_t chdir___os(char *);
obj_t os_class_179___os = BUNSPEC;
static obj_t _get_signal_handler1246_188___os(obj_t, obj_t);
extern obj_t command_line;
extern obj_t get_signal_handler_120___os(int);
static obj_t _dirname1252___os(obj_t, obj_t);
extern char * date___os();
extern obj_t getenv___os(char *);
extern char * executable_name_99___os();
extern char * executable_name;
static obj_t imported_modules_init_94___os();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern char * c_date();
static obj_t require_initialization_114___os = BUNSPEC;
extern obj_t make_file_name_203___os(obj_t, obj_t);
static obj_t cnst_init_137___os();
extern obj_t blit_string(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t symbol1548___os = BUNSPEC;
static obj_t symbol1547___os = BUNSPEC;
static obj_t symbol1546___os = BUNSPEC;
static obj_t symbol1545___os = BUNSPEC;
static obj_t symbol1544___os = BUNSPEC;
static obj_t symbol1543___os = BUNSPEC;
static obj_t symbol1542___os = BUNSPEC;
static obj_t symbol1541___os = BUNSPEC;
static obj_t symbol1539___os = BUNSPEC;
static obj_t symbol1538___os = BUNSPEC;
static obj_t symbol1535___os = BUNSPEC;
static obj_t symbol1534___os = BUNSPEC;
static obj_t symbol1533___os = BUNSPEC;
static obj_t symbol1532___os = BUNSPEC;
static obj_t symbol1525___os = BUNSPEC;
static obj_t symbol1524___os = BUNSPEC;
static obj_t symbol1523___os = BUNSPEC;
static obj_t symbol1522___os = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( basename_env_222___os, _basename1250___os1550, _basename1250___os, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( pwd_env_121___os, _pwd___os1551, _pwd___os, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( get_signal_handler_env_192___os, _get_signal_handler1246_188___os1552, _get_signal_handler1246_188___os, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( system_env_221___os, _system1248___os1553, _system1248___os, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( date_env_128___os, _date___os1554, _date___os, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( make_static_library_name_env_199___os, _make_static_library_name1255_74___os1555, _make_static_library_name1255_74___os, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( dirname_env_218___os, _dirname1252___os1556, _dirname1252___os, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( signal_env_180___os, _signal1245___os1557, _signal1245___os, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( prefix_env_157___os, _prefix1251___os1558, _prefix1251___os, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( make_shared_library_name_env_249___os, _make_shared_library_name1256_77___os1559, _make_shared_library_name1256_77___os, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1499___os, lambda1009___os1560, lambda1009___os, 0L, 0 );
DEFINE_STATIC_PROCEDURE( proc1498___os, lambda1008___os1561, lambda1008___os, 0L, 0 );
DEFINE_STATIC_PROCEDURE( proc1497___os, lambda1007___os1562, lambda1007___os, 0L, 0 );
DEFINE_STATIC_PROCEDURE( proc1496___os, lambda1005___os1563, lambda1005___os, 0L, 0 );
DEFINE_STATIC_PROCEDURE( proc1502___os, lambda1013___os1564, lambda1013___os, 0L, 0 );
DEFINE_STATIC_PROCEDURE( proc1501___os, lambda1012___os1565, lambda1012___os, 0L, 0 );
DEFINE_STATIC_PROCEDURE( proc1500___os, lambda1011___os1566, lambda1011___os, 0L, 0 );
DEFINE_STRING( string1540___os, string1540___os1567, "", 0 );
DEFINE_STRING( string1537___os, string1537___os1568, ".", 1 );
DEFINE_STRING( string1536___os, string1536___os1569, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/string.scm", 59 );
DEFINE_STRING( string1531___os, string1531___os1570, "BSTRING", 7 );
DEFINE_STRING( string1529___os, string1529___os1571, "substring", 9 );
DEFINE_STRING( string1530___os, string1530___os1572, "Illegal index", 13 );
DEFINE_STRING( string1528___os, string1528___os1573, "UCHAR", 5 );
DEFINE_STRING( string1527___os, string1527___os1574, "index out of range", 18 );
DEFINE_STRING( string1526___os, string1526___os1575, "string-ref", 10 );
DEFINE_STRING( string1518___os, string1518___os1576, "STRING", 6 );
DEFINE_STRING( string1513___os, string1513___os1577, "PROCEDURE", 9 );
DEFINE_STRING( string1512___os, string1512___os1578, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/os.scm", 55 );
DEFINE_STRING( string1511___os, string1511___os1579, "INT", 3 );
DEFINE_STRING( string1509___os, string1509___os1580, "Wrong number of arguments", 25 );
DEFINE_STRING( string1508___os, string1508___os1581, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1507___os, string1507___os1582, "Illegal signal", 14 );
DEFINE_STRING( string1506___os, string1506___os1583, "signal", 6 );
DEFINE_EXPORT_PROCEDURE( executable_name_env_184___os, _executable_name_113___os1584, _executable_name_113___os, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( chdir_env_87___os, _chdir1249___os1585, _chdir1249___os, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( suffix_env_109___os, _suffix1253___os1586, _suffix1253___os, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( make_file_name_env_223___os, _make_file_name1254_212___os1587, _make_file_name1254_212___os, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( command_line_env_109___os, _command_line_112___os1588, _command_line_112___os, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( getenv_env_98___os, _getenv1247___os1589, _getenv1247___os, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___os(long checksum_1040, char * from_1041)
{
if(CBOOL(require_initialization_114___os)){
require_initialization_114___os = BBOOL(((bool_t)0));
cnst_init_137___os();
imported_modules_init_94___os();
toplevel_init_63___os();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___os()
{
symbol1495___os = string_to_symbol("TOPLEVEL-INIT");
symbol1503___os = string_to_symbol("COMMAND-LINE");
symbol1504___os = string_to_symbol("EXECUTABLE-NAME");
symbol1505___os = string_to_symbol("SIGNAL");
symbol1510___os = string_to_symbol("_SIGNAL1245");
symbol1514___os = string_to_symbol("GET-SIGNAL-HANDLER");
symbol1515___os = string_to_symbol("_GET-SIGNAL-HANDLER1246");
symbol1516___os = string_to_symbol("GETENV");
symbol1517___os = string_to_symbol("_GETENV1247");
symbol1519___os = string_to_symbol("SYSTEM");
symbol1520___os = string_to_symbol("_SYSTEM1248");
symbol1521___os = string_to_symbol("DATE");
symbol1522___os = string_to_symbol("CHDIR");
symbol1523___os = string_to_symbol("_CHDIR1249");
symbol1524___os = string_to_symbol("PWD");
symbol1525___os = string_to_symbol("BASENAME");
symbol1532___os = string_to_symbol("_BASENAME1250");
symbol1533___os = string_to_symbol("PREFIX");
symbol1534___os = string_to_symbol("_PREFIX1251");
symbol1535___os = string_to_symbol("DIRNAME");
symbol1538___os = string_to_symbol("_DIRNAME1252");
symbol1539___os = string_to_symbol("SUFFIX");
symbol1541___os = string_to_symbol("_SUFFIX1253");
symbol1542___os = string_to_symbol("MAKE-FILE-NAME");
symbol1543___os = string_to_symbol("_MAKE-FILE-NAME1254");
symbol1544___os = string_to_symbol("MAKE-STATIC-LIBRARY-NAME");
symbol1545___os = string_to_symbol("_MAKE-STATIC-LIBRARY-NAME1255");
symbol1546___os = string_to_symbol("MAKE-SHARED-LIBRARY-NAME");
symbol1547___os = string_to_symbol("_MAKE-SHARED-LIBRARY-NAME1256");
return (symbol1548___os = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___os()
{
{
obj_t symbol1210_747;
symbol1210_747 = symbol1495___os;
{
PUSH_TRACE(symbol1210_747);
BUNSPEC;
{
obj_t aux1209_748;
{
obj_t lambda1005_789;
lambda1005_789 = proc1496___os;
os_class_179___os = lambda1005_789;
}
{
obj_t lambda1007_788;
lambda1007_788 = proc1497___os;
os_name_233___os = lambda1007_788;
}
{
obj_t lambda1008_787;
lambda1008_787 = proc1498___os;
os_arch_255___os = lambda1008_787;
}
{
obj_t lambda1009_786;
lambda1009_786 = proc1499___os;
os_version_65___os = lambda1009_786;
}
{
obj_t lambda1011_785;
lambda1011_785 = proc1500___os;
os_tmp_175___os = lambda1011_785;
}
{
obj_t lambda1012_784;
lambda1012_784 = proc1501___os;
file_separator_81___os = lambda1012_784;
}
{
obj_t lambda1013_783;
lambda1013_783 = proc1502___os;
aux1209_748 = (path_separator_174___os = lambda1013_783,
BUNSPEC);
}
POP_TRACE();
return aux1209_748;
}
}
}
}


/* lambda1013 */obj_t lambda1013___os(obj_t env_790)
{
return BCHAR(PATH_SEPARATOR);
}


/* lambda1012 */obj_t lambda1012___os(obj_t env_791)
{
return BCHAR(FILE_SEPARATOR);
}


/* lambda1011 */obj_t lambda1011___os(obj_t env_792)
{
return string_to_bstring(OS_TMP);
}


/* lambda1009 */obj_t lambda1009___os(obj_t env_793)
{
return string_to_bstring(OS_VERSION);
}


/* lambda1008 */obj_t lambda1008___os(obj_t env_794)
{
return string_to_bstring(OS_ARCH);
}


/* lambda1007 */obj_t lambda1007___os(obj_t env_795)
{
return string_to_bstring(OS_NAME);
}


/* lambda1005 */obj_t lambda1005___os(obj_t env_796)
{
return string_to_bstring(OS_CLASS);
}


/* command-line */obj_t command_line_67___os()
{
{
obj_t symbol1212_749;
symbol1212_749 = symbol1503___os;
{
PUSH_TRACE(symbol1212_749);
BUNSPEC;
POP_TRACE();
return command_line;
}
}
}


/* _command-line */obj_t _command_line_112___os(obj_t env_797)
{
return command_line_67___os();
}


/* executable-name */char * executable_name_99___os()
{
{
obj_t symbol1214_751;
symbol1214_751 = symbol1504___os;
{
PUSH_TRACE(symbol1214_751);
BUNSPEC;
POP_TRACE();
return executable_name;
}
}
}


/* _executable-name */obj_t _executable_name_113___os(obj_t env_798)
{
{
char * aux_1092;
aux_1092 = executable_name_99___os();
return string_to_bstring(aux_1092);
}
}


/* signal */obj_t signal___os(int num_1, obj_t proc_2)
{
{
obj_t symbol1216_753;
symbol1216_753 = symbol1505___os;
{
PUSH_TRACE(symbol1216_753);
BUNSPEC;
{
obj_t aux1215_754;
{
bool_t test1014_238;
{
long arg1017_241;
arg1017_241 = PROCEDURE_ARITY(proc_2);
test1014_238 = (arg1017_241==((long)1));
}
if(test1014_238){
bool_t test_1099;
{
bool_t test_1100;
{
long aux_1101;
aux_1101 = (long)(num_1);
test_1100 = (aux_1101<((long)0));
}
if(test_1100){
test_1099 = ((bool_t)1);
}
 else {
long aux_1104;
aux_1104 = (long)(num_1);
test_1099 = (aux_1104>((long)31));
}
}
if(test_1099){
aux1215_754 = debug_error_location_199___error(string1506___os, string1507___os, BINT(num_1), string1508___os, BINT(((long)7610)));
}
 else {
aux1215_754 = c_signal(num_1, proc_2);
}
}
 else {
aux1215_754 = debug_error_location_199___error(string1506___os, string1509___os, proc_2, string1508___os, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1215_754;
}
}
}
}


/* _signal1245 */obj_t _signal1245___os(obj_t env_799, obj_t num_800, obj_t proc_801)
{
{
obj_t aux_1122;
int aux_1114;
if(PROCEDUREP(proc_801)){
aux_1122 = proc_801;
}
 else {
bigloo_type_error_location_103___error(symbol1510___os, string1513___os, proc_801, string1512___os, BINT(((long)4908)));
exit( -1 );}
{
obj_t aux_1115;
if(INTEGERP(num_800)){
aux_1115 = num_800;
}
 else {
bigloo_type_error_location_103___error(symbol1510___os, string1511___os, num_800, string1512___os, BINT(((long)4908)));
exit( -1 );}
aux_1114 = CINT(aux_1115);
}
return signal___os(aux_1114, aux_1122);
}
}


/* get-signal-handler */obj_t get_signal_handler_120___os(int num_3)
{
{
obj_t symbol1218_755;
symbol1218_755 = symbol1514___os;
{
PUSH_TRACE(symbol1218_755);
BUNSPEC;
{
obj_t aux1217_756;
aux1217_756 = get_signal_handler(num_3);
POP_TRACE();
return aux1217_756;
}
}
}
}


/* _get-signal-handler1246 */obj_t _get_signal_handler1246_188___os(obj_t env_802, obj_t num_803)
{
{
int aux_1132;
{
obj_t aux_1133;
if(INTEGERP(num_803)){
aux_1133 = num_803;
}
 else {
bigloo_type_error_location_103___error(symbol1515___os, string1511___os, num_803, string1512___os, BINT(((long)5393)));
exit( -1 );}
aux_1132 = CINT(aux_1133);
}
return get_signal_handler_120___os(aux_1132);
}
}


/* getenv */obj_t getenv___os(char * string_4)
{
{
obj_t symbol1220_1019;
symbol1220_1019 = symbol1516___os;
{
PUSH_TRACE(symbol1220_1019);
BUNSPEC;
{
obj_t aux1219_1020;
{
bool_t test1019_1021;
test1019_1021 = (long)getenv(string_4);
if(test1019_1021){
char * aux_1144;
aux_1144 = (char *)getenv(string_4);
aux1219_1020 = string_to_bstring(aux_1144);
}
 else {
aux1219_1020 = BFALSE;
}
}
POP_TRACE();
return aux1219_1020;
}
}
}
}


/* _getenv1247 */obj_t _getenv1247___os(obj_t env_804, obj_t string_805)
{
{
char * string_1022;
{
obj_t aux_1148;
if(STRINGP(string_805)){
aux_1148 = string_805;
}
 else {
bigloo_type_error_location_103___error(symbol1517___os, string1518___os, string_805, string1512___os, BINT(((long)5680)));
exit( -1 );}
string_1022 = BSTRING_TO_STRING(aux_1148);
}
{
obj_t symbol1220_1023;
symbol1220_1023 = symbol1516___os;
{
PUSH_TRACE(symbol1220_1023);
BUNSPEC;
{
obj_t aux1219_1024;
{
bool_t test1019_1025;
test1019_1025 = (long)getenv(string_1022);
if(test1019_1025){
char * aux_1158;
aux_1158 = (char *)getenv(string_1022);
aux1219_1024 = string_to_bstring(aux_1158);
}
 else {
aux1219_1024 = BFALSE;
}
}
POP_TRACE();
return aux1219_1024;
}
}
}
}
}


/* system */obj_t system___os(char * string_5)
{
{
obj_t symbol1222_1026;
symbol1222_1026 = symbol1519___os;
{
PUSH_TRACE(symbol1222_1026);
BUNSPEC;
{
obj_t aux1221_1027;
{
int aux_1163;
aux_1163 = system(string_5);
aux1221_1027 = BINT(aux_1163);
}
POP_TRACE();
return aux1221_1027;
}
}
}
}


/* _system1248 */obj_t _system1248___os(obj_t env_806, obj_t string_807)
{
{
char * string_1028;
{
obj_t aux_1167;
if(STRINGP(string_807)){
aux_1167 = string_807;
}
 else {
bigloo_type_error_location_103___error(symbol1520___os, string1518___os, string_807, string1512___os, BINT(((long)5997)));
exit( -1 );}
string_1028 = BSTRING_TO_STRING(aux_1167);
}
{
obj_t symbol1222_1029;
symbol1222_1029 = symbol1519___os;
{
PUSH_TRACE(symbol1222_1029);
BUNSPEC;
{
obj_t aux1221_1030;
{
int aux_1175;
aux_1175 = system(string_1028);
aux1221_1030 = BINT(aux_1175);
}
POP_TRACE();
return aux1221_1030;
}
}
}
}
}


/* date */char * date___os()
{
{
obj_t symbol1224_1031;
symbol1224_1031 = symbol1521___os;
{
PUSH_TRACE(symbol1224_1031);
BUNSPEC;
{
char * aux1223_1032;
aux1223_1032 = c_date();
POP_TRACE();
return aux1223_1032;
}
}
}
}


/* _date */obj_t _date___os(obj_t env_808)
{
{
char * aux_1182;
{
obj_t symbol1224_1033;
symbol1224_1033 = symbol1521___os;
{
PUSH_TRACE(symbol1224_1033);
BUNSPEC;
{
char * aux1223_1034;
aux1223_1034 = c_date();
POP_TRACE();
aux_1182 = aux1223_1034;
}
}
}
return string_to_bstring(aux_1182);
}
}


/* chdir */obj_t chdir___os(char * dirname_6)
{
{
obj_t symbol1226_1035;
symbol1226_1035 = symbol1522___os;
{
PUSH_TRACE(symbol1226_1035);
BUNSPEC;
{
obj_t aux1225_1036;
{
int aux_1188;
aux_1188 = chdir(dirname_6);
aux1225_1036 = BINT(aux_1188);
}
POP_TRACE();
return aux1225_1036;
}
}
}
}


/* _chdir1249 */obj_t _chdir1249___os(obj_t env_809, obj_t dirname_810)
{
{
char * dirname_1037;
{
obj_t aux_1192;
if(STRINGP(dirname_810)){
aux_1192 = dirname_810;
}
 else {
bigloo_type_error_location_103___error(symbol1523___os, string1518___os, dirname_810, string1512___os, BINT(((long)6534)));
exit( -1 );}
dirname_1037 = BSTRING_TO_STRING(aux_1192);
}
{
obj_t symbol1226_1038;
symbol1226_1038 = symbol1522___os;
{
PUSH_TRACE(symbol1226_1038);
BUNSPEC;
{
obj_t aux1225_1039;
{
int aux_1200;
aux_1200 = chdir(dirname_1037);
aux1225_1039 = BINT(aux_1200);
}
POP_TRACE();
return aux1225_1039;
}
}
}
}
}


/* pwd */obj_t pwd___os()
{
{
obj_t symbol1228_765;
symbol1228_765 = symbol1524___os;
{
PUSH_TRACE(symbol1228_765);
BUNSPEC;
{
obj_t aux1227_766;
{
obj_t string_244;
{
obj_t res1196_454;
{
long aux_1205;
{
int aux_1206;
aux_1206 = (int)(((long)1021));
aux_1205 = (long)(aux_1206);
}
res1196_454 = make_string(aux_1205, ((unsigned char)' '));
}
string_244 = res1196_454;
}
{
char * aux_1210;
{
int aux_1213;
char * aux_1211;
aux_1213 = (int)(((long)1024));
aux_1211 = BSTRING_TO_STRING(string_244);
aux_1210 = (char *)(long)getcwd(aux_1211, aux_1213);
}
aux1227_766 = string_to_bstring(aux_1210);
}
}
POP_TRACE();
return aux1227_766;
}
}
}
}


/* _pwd */obj_t _pwd___os(obj_t env_811)
{
return pwd___os();
}


/* basename */obj_t basename___os(obj_t string_7)
{
{
obj_t symbol1230_767;
symbol1230_767 = symbol1525___os;
{
PUSH_TRACE(symbol1230_767);
BUNSPEC;
{
obj_t aux1229_768;
{
long index_246;
{
long aux_1268;
aux_1268 = STRING_LENGTH(string_7);
index_246 = (aux_1268-((long)1));
}
loop_247:
if((index_246==((long)-1))){
aux1229_768 = string_7;
}
 else {
bool_t test1025_252;
{
unsigned char arg1029_256;
{
unsigned char res1197_468;
{
bool_t test_1222;
{
long aux_1223;
aux_1223 = STRING_LENGTH(string_7);
test_1222 = BOUND_CHECK(index_246, aux_1223);
}
if(test_1222){
res1197_468 = STRING_REF(string_7, index_246);
}
 else {
obj_t aux_1227;
{
obj_t aux1311_875;
aux1311_875 = debug_error_location_199___error(string1526___os, string1527___os, BINT(index_246), string1508___os, BINT(((long)7610)));
if(CHARP(aux1311_875)){
aux_1227 = aux1311_875;
}
 else {
bigloo_type_error_location_103___error(symbol1525___os, string1528___os, aux1311_875, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
res1197_468 = (unsigned char)CCHAR(aux_1227);
}
}
arg1029_256 = res1197_468;
}
{
unsigned char aux_1237;
aux_1237 = (unsigned char)(FILE_SEPARATOR);
test1025_252 = (arg1029_256==aux_1237);
}
}
if(test1025_252){
{
long arg1026_253;
long arg1027_254;
arg1026_253 = (index_246+((long)1));
arg1027_254 = STRING_LENGTH(string_7);
{
obj_t res1198_502;
{
bool_t test_1243;
if((arg1027_254>=arg1026_253)){
bool_t test_1246;
{
long aux_1247;
aux_1247 = (arg1027_254+((long)1));
test_1246 = BOUND_CHECK(arg1026_253, aux_1247);
}
if(test_1246){
long aux_1250;
aux_1250 = (arg1027_254+((long)1));
test_1243 = BOUND_CHECK(arg1027_254, aux_1250);
}
 else {
test_1243 = ((bool_t)0);
}
}
 else {
test_1243 = ((bool_t)0);
}
if(test_1243){
res1198_502 = c_substring(string_7, arg1026_253, arg1027_254);
}
 else {
obj_t arg1085_488;
{
obj_t aux_1256;
obj_t aux_1254;
aux_1256 = BINT(arg1027_254);
aux_1254 = BINT(arg1026_253);
arg1085_488 = MAKE_PAIR(aux_1254, aux_1256);
}
{
obj_t aux1320_881;
aux1320_881 = debug_error_location_199___error(string1529___os, string1530___os, arg1085_488, string1508___os, BINT(((long)7610)));
if(STRINGP(aux1320_881)){
res1198_502 = aux1320_881;
}
 else {
bigloo_type_error_location_103___error(symbol1525___os, string1531___os, aux1320_881, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
}
}
aux1229_768 = res1198_502;
}
}
}
 else {
{
long index_1266;
index_1266 = (index_246-((long)1));
index_246 = index_1266;
goto loop_247;
}
}
}
}
POP_TRACE();
return aux1229_768;
}
}
}
}


/* _basename1250 */obj_t _basename1250___os(obj_t env_812, obj_t string_813)
{
{
obj_t aux_1272;
if(STRINGP(string_813)){
aux_1272 = string_813;
}
 else {
bigloo_type_error_location_103___error(symbol1532___os, string1531___os, string_813, string1512___os, BINT(((long)7119)));
exit( -1 );}
return basename___os(aux_1272);
}
}


/* prefix */obj_t prefix___os(obj_t string_8)
{
{
obj_t symbol1232_769;
symbol1232_769 = symbol1533___os;
{
PUSH_TRACE(symbol1232_769);
BUNSPEC;
{
obj_t aux1231_770;
{
long len_257;
{
long aux_1280;
aux_1280 = STRING_LENGTH(string_8);
len_257 = (aux_1280-((long)1));
}
{
long e_258;
long s_259;
e_258 = len_257;
s_259 = len_257;
loop_260:
if((s_259<=((long)0))){
{
long arg1032_263;
arg1032_263 = (((long)1)+e_258);
{
obj_t res1199_540;
{
bool_t test_1286;
if((arg1032_263>=((long)0))){
bool_t test_1289;
{
long aux_1290;
{
long aux_1291;
aux_1291 = STRING_LENGTH(string_8);
aux_1290 = (aux_1291+((long)1));
}
test_1289 = BOUND_CHECK(((long)0), aux_1290);
}
if(test_1289){
long aux_1295;
{
long aux_1296;
aux_1296 = STRING_LENGTH(string_8);
aux_1295 = (aux_1296+((long)1));
}
test_1286 = BOUND_CHECK(arg1032_263, aux_1295);
}
 else {
test_1286 = ((bool_t)0);
}
}
 else {
test_1286 = ((bool_t)0);
}
if(test_1286){
res1199_540 = c_substring(string_8, ((long)0), arg1032_263);
}
 else {
obj_t arg1085_526;
{
obj_t aux_1303;
obj_t aux_1301;
aux_1303 = BINT(arg1032_263);
aux_1301 = BINT(((long)0));
arg1085_526 = MAKE_PAIR(aux_1301, aux_1303);
}
{
obj_t aux1333_893;
aux1333_893 = debug_error_location_199___error(string1529___os, string1530___os, arg1085_526, string1508___os, BINT(((long)7610)));
if(STRINGP(aux1333_893)){
res1199_540 = aux1333_893;
}
 else {
bigloo_type_error_location_103___error(symbol1533___os, string1531___os, aux1333_893, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
}
}
aux1231_770 = res1199_540;
}
}
}
 else {
{
bool_t test1033_264;
{
bool_t test1038_268;
{
unsigned char arg1039_269;
{
unsigned char res1200_549;
{
bool_t test_1313;
{
long aux_1314;
aux_1314 = STRING_LENGTH(string_8);
test_1313 = BOUND_CHECK(s_259, aux_1314);
}
if(test_1313){
res1200_549 = STRING_REF(string_8, s_259);
}
 else {
obj_t aux_1318;
{
obj_t aux1343_899;
aux1343_899 = debug_error_location_199___error(string1526___os, string1527___os, BINT(s_259), string1508___os, BINT(((long)7610)));
if(CHARP(aux1343_899)){
aux_1318 = aux1343_899;
}
 else {
bigloo_type_error_location_103___error(symbol1533___os, string1528___os, aux1343_899, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
res1200_549 = (unsigned char)CCHAR(aux_1318);
}
}
arg1039_269 = res1200_549;
}
{
obj_t aux_1330;
obj_t aux_1328;
aux_1330 = BCHAR(((unsigned char)'.'));
aux_1328 = BCHAR(arg1039_269);
test1038_268 = (aux_1328==aux_1330);
}
}
if(test1038_268){
test1033_264 = (e_258==len_257);
}
 else {
test1033_264 = ((bool_t)0);
}
}
if(test1033_264){
long s_1338;
long e_1336;
e_1336 = (s_259-((long)1));
s_1338 = (s_259-((long)1));
s_259 = s_1338;
e_258 = e_1336;
goto loop_260;
}
 else {
long s_1340;
s_1340 = (s_259-((long)1));
s_259 = s_1340;
goto loop_260;
}
}
}
}
}
POP_TRACE();
return aux1231_770;
}
}
}
}


/* _prefix1251 */obj_t _prefix1251___os(obj_t env_814, obj_t string_815)
{
{
obj_t aux_1343;
if(STRINGP(string_815)){
aux_1343 = string_815;
}
 else {
bigloo_type_error_location_103___error(symbol1534___os, string1531___os, string_815, string1512___os, BINT(((long)7613)));
exit( -1 );}
return prefix___os(aux_1343);
}
}


/* dirname */obj_t dirname___os(obj_t string_9)
{
{
obj_t symbol1234_771;
symbol1234_771 = symbol1535___os;
{
PUSH_TRACE(symbol1234_771);
BUNSPEC;
{
obj_t aux1233_772;
{
long read_273;
{
obj_t aux1396_941;
{
long aux_1437;
aux_1437 = STRING_LENGTH(string_9);
read_273 = (aux_1437-((long)1));
}
loop_274:
if((read_273<=((long)0))){
{
bool_t test1043_276;
{
unsigned char arg1046_279;
{
unsigned char res1201_573;
{
bool_t test_1353;
{
long aux_1354;
aux_1354 = STRING_LENGTH(string_9);
test_1353 = BOUND_CHECK(read_273, aux_1354);
}
if(test_1353){
res1201_573 = STRING_REF(string_9, read_273);
}
 else {
obj_t aux_1358;
{
obj_t aux1358_911;
aux1358_911 = debug_error_location_199___error(string1526___os, string1527___os, BINT(read_273), string1508___os, BINT(((long)7610)));
if(CHARP(aux1358_911)){
aux_1358 = aux1358_911;
}
 else {
bigloo_type_error_location_103___error(symbol1535___os, string1528___os, aux1358_911, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
res1201_573 = (unsigned char)CCHAR(aux_1358);
}
}
arg1046_279 = res1201_573;
}
{
unsigned char aux_1368;
aux_1368 = (unsigned char)(FILE_SEPARATOR);
test1043_276 = (arg1046_279==aux_1368);
}
}
if(test1043_276){
obj_t list1044_277;
{
obj_t aux_1372;
aux_1372 = BCHAR(FILE_SEPARATOR);
list1044_277 = MAKE_PAIR(aux_1372, BNIL);
}
{
obj_t res1202_582;
{
obj_t arg1099_579;
arg1099_579 = CAR(list1044_277);
{
unsigned char aux_1380;
long aux_1376;
{
obj_t aux_1381;
if(CHARP(arg1099_579)){
aux_1381 = arg1099_579;
}
 else {
bigloo_type_error_location_103___error(symbol1535___os, string1528___os, arg1099_579, string1536___os, BINT(((long)7260)));
exit( -1 );}
aux_1380 = (unsigned char)CCHAR(aux_1381);
}
{
int aux_1377;
aux_1377 = (int)(((long)1));
aux_1376 = (long)(aux_1377);
}
res1202_582 = make_string(aux_1376, aux_1380);
}
}
aux1396_941 = res1202_582;
}
}
 else {
aux1396_941 = string1537___os;
}
}
}
 else {
bool_t test1047_280;
{
unsigned char arg1049_282;
{
unsigned char res1203_591;
{
bool_t test_1389;
{
long aux_1390;
aux_1390 = STRING_LENGTH(string_9);
test_1389 = BOUND_CHECK(read_273, aux_1390);
}
if(test_1389){
res1203_591 = STRING_REF(string_9, read_273);
}
 else {
obj_t aux_1394;
{
obj_t aux1382_929;
aux1382_929 = debug_error_location_199___error(string1526___os, string1527___os, BINT(read_273), string1508___os, BINT(((long)7610)));
if(CHARP(aux1382_929)){
aux_1394 = aux1382_929;
}
 else {
bigloo_type_error_location_103___error(symbol1535___os, string1528___os, aux1382_929, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
res1203_591 = (unsigned char)CCHAR(aux_1394);
}
}
arg1049_282 = res1203_591;
}
{
unsigned char aux_1404;
aux_1404 = (unsigned char)(FILE_SEPARATOR);
test1047_280 = (arg1049_282==aux_1404);
}
}
if(test1047_280){
{
obj_t res1204_622;
{
bool_t test_1408;
if((read_273>=((long)0))){
bool_t test_1411;
{
long aux_1412;
{
long aux_1413;
aux_1413 = STRING_LENGTH(string_9);
aux_1412 = (aux_1413+((long)1));
}
test_1411 = BOUND_CHECK(((long)0), aux_1412);
}
if(test_1411){
long aux_1417;
{
long aux_1418;
aux_1418 = STRING_LENGTH(string_9);
aux_1417 = (aux_1418+((long)1));
}
test_1408 = BOUND_CHECK(read_273, aux_1417);
}
 else {
test_1408 = ((bool_t)0);
}
}
 else {
test_1408 = ((bool_t)0);
}
if(test_1408){
res1204_622 = c_substring(string_9, ((long)0), read_273);
}
 else {
obj_t arg1085_608;
{
obj_t aux_1425;
obj_t aux_1423;
aux_1425 = BINT(read_273);
aux_1423 = BINT(((long)0));
arg1085_608 = MAKE_PAIR(aux_1423, aux_1425);
}
{
obj_t aux1389_935;
aux1389_935 = debug_error_location_199___error(string1529___os, string1530___os, arg1085_608, string1508___os, BINT(((long)7610)));
if(STRINGP(aux1389_935)){
res1204_622 = aux1389_935;
}
 else {
bigloo_type_error_location_103___error(symbol1535___os, string1531___os, aux1389_935, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
}
}
aux1396_941 = res1204_622;
}
}
 else {
{
long read_1435;
read_1435 = (read_273-((long)1));
read_273 = read_1435;
goto loop_274;
}
}
}
if(STRINGP(aux1396_941)){
aux1233_772 = aux1396_941;
}
 else {
bigloo_type_error_location_103___error(symbol1535___os, string1531___os, aux1396_941, string1512___os, BINT(((long)8313)));
exit( -1 );}
}
}
POP_TRACE();
return aux1233_772;
}
}
}
}


/* _dirname1252 */obj_t _dirname1252___os(obj_t env_816, obj_t string_817)
{
{
obj_t aux_1446;
if(STRINGP(string_817)){
aux_1446 = string_817;
}
 else {
bigloo_type_error_location_103___error(symbol1538___os, string1531___os, string_817, string1512___os, BINT(((long)8235)));
exit( -1 );}
return dirname___os(aux_1446);
}
}


/* suffix */obj_t suffix___os(obj_t string_10)
{
{
obj_t symbol1236_773;
symbol1236_773 = symbol1539___os;
{
PUSH_TRACE(symbol1236_773);
BUNSPEC;
{
obj_t aux1235_774;
{
long len_285;
len_285 = STRING_LENGTH(string_10);
{
long len_1_56_286;
len_1_56_286 = (len_285-((long)1));
{
{
long read_287;
{
obj_t aux1437_971;
read_287 = len_1_56_286;
loop_288:
if((read_287<((long)0))){
aux1437_971 = string1540___os;
}
 else {
bool_t test1053_290;
{
unsigned char arg1059_296;
{
unsigned char res1205_638;
{
bool_t test_1458;
{
long aux_1459;
aux_1459 = STRING_LENGTH(string_10);
test_1458 = BOUND_CHECK(read_287, aux_1459);
}
if(test_1458){
res1205_638 = STRING_REF(string_10, read_287);
}
 else {
obj_t aux_1463;
{
obj_t aux1411_953;
aux1411_953 = debug_error_location_199___error(string1526___os, string1527___os, BINT(read_287), string1508___os, BINT(((long)7610)));
if(CHARP(aux1411_953)){
aux_1463 = aux1411_953;
}
 else {
bigloo_type_error_location_103___error(symbol1539___os, string1528___os, aux1411_953, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
res1205_638 = (unsigned char)CCHAR(aux_1463);
}
}
arg1059_296 = res1205_638;
}
{
unsigned char aux_1473;
aux_1473 = (unsigned char)(FILE_SEPARATOR);
test1053_290 = (arg1059_296==aux_1473);
}
}
if(test1053_290){
aux1437_971 = string1540___os;
}
 else {
bool_t test1054_291;
{
unsigned char arg1058_295;
{
unsigned char res1206_649;
{
bool_t test_1477;
{
long aux_1478;
aux_1478 = STRING_LENGTH(string_10);
test_1477 = BOUND_CHECK(read_287, aux_1478);
}
if(test_1477){
res1206_649 = STRING_REF(string_10, read_287);
}
 else {
obj_t aux_1482;
{
obj_t aux1417_959;
aux1417_959 = debug_error_location_199___error(string1526___os, string1527___os, BINT(read_287), string1508___os, BINT(((long)7610)));
if(CHARP(aux1417_959)){
aux_1482 = aux1417_959;
}
 else {
bigloo_type_error_location_103___error(symbol1539___os, string1528___os, aux1417_959, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
res1206_649 = (unsigned char)CCHAR(aux_1482);
}
}
arg1058_295 = res1206_649;
}
test1054_291 = (arg1058_295==((unsigned char)'.'));
}
if(test1054_291){
if((read_287==len_1_56_286)){
aux1437_971 = string1540___os;
}
 else {
{
long arg1056_293;
arg1056_293 = (read_287+((long)1));
{
obj_t res1207_684;
{
bool_t test_1497;
if((len_285>=arg1056_293)){
bool_t test_1500;
{
long aux_1501;
{
long aux_1502;
aux_1502 = STRING_LENGTH(string_10);
aux_1501 = (aux_1502+((long)1));
}
test_1500 = BOUND_CHECK(arg1056_293, aux_1501);
}
if(test_1500){
long aux_1506;
{
long aux_1507;
aux_1507 = STRING_LENGTH(string_10);
aux_1506 = (aux_1507+((long)1));
}
test_1497 = BOUND_CHECK(len_285, aux_1506);
}
 else {
test_1497 = ((bool_t)0);
}
}
 else {
test_1497 = ((bool_t)0);
}
if(test_1497){
res1207_684 = c_substring(string_10, arg1056_293, len_285);
}
 else {
obj_t arg1085_670;
{
obj_t aux_1514;
obj_t aux_1512;
aux_1514 = BINT(len_285);
aux_1512 = BINT(arg1056_293);
arg1085_670 = MAKE_PAIR(aux_1512, aux_1514);
}
{
obj_t aux1427_965;
aux1427_965 = debug_error_location_199___error(string1529___os, string1530___os, arg1085_670, string1508___os, BINT(((long)7610)));
if(STRINGP(aux1427_965)){
res1207_684 = aux1427_965;
}
 else {
bigloo_type_error_location_103___error(symbol1539___os, string1531___os, aux1427_965, string1508___os, BINT(((long)7610)));
exit( -1 );}
}
}
}
aux1437_971 = res1207_684;
}
}
}
}
 else {
{
long read_1524;
read_1524 = (read_287-((long)1));
read_287 = read_1524;
goto loop_288;
}
}
}
}
if(STRINGP(aux1437_971)){
aux1235_774 = aux1437_971;
}
 else {
bigloo_type_error_location_103___error(symbol1539___os, string1531___os, aux1437_971, string1512___os, BINT(((long)8922)));
exit( -1 );}
}
}
}
}
}
POP_TRACE();
return aux1235_774;
}
}
}
}


/* _suffix1253 */obj_t _suffix1253___os(obj_t env_818, obj_t string_819)
{
{
obj_t aux_1532;
if(STRINGP(string_819)){
aux_1532 = string_819;
}
 else {
bigloo_type_error_location_103___error(symbol1541___os, string1531___os, string_819, string1512___os, BINT(((long)8822)));
exit( -1 );}
return suffix___os(aux_1532);
}
}


/* make-file-name */obj_t make_file_name_203___os(obj_t directory_11, obj_t file_12)
{
{
obj_t symbol1238_775;
symbol1238_775 = symbol1542___os;
{
PUSH_TRACE(symbol1238_775);
BUNSPEC;
{
obj_t aux1237_776;
{
long ldir_297;
ldir_297 = STRING_LENGTH(directory_11);
{
long lfile_298;
lfile_298 = STRING_LENGTH(file_12);
{
long len_299;
{
long aux_1542;
aux_1542 = (lfile_298+((long)1));
len_299 = (ldir_297+aux_1542);
}
{
obj_t str_300;
{
obj_t list1062_303;
{
obj_t aux_1545;
aux_1545 = BCHAR(FILE_SEPARATOR);
list1062_303 = MAKE_PAIR(aux_1545, BNIL);
}
{
obj_t res1208_699;
{
obj_t arg1099_696;
arg1099_696 = CAR(list1062_303);
{
unsigned char aux_1553;
long aux_1549;
{
obj_t aux_1554;
if(CHARP(arg1099_696)){
aux_1554 = arg1099_696;
}
 else {
bigloo_type_error_location_103___error(symbol1542___os, string1528___os, arg1099_696, string1536___os, BINT(((long)7260)));
exit( -1 );}
aux_1553 = (unsigned char)CCHAR(aux_1554);
}
{
int aux_1550;
aux_1550 = (int)(len_299);
aux_1549 = (long)(aux_1550);
}
res1208_699 = make_string(aux_1549, aux_1553);
}
}
str_300 = res1208_699;
}
}
{
{
obj_t aux_1566;
obj_t aux_1564;
obj_t aux_1562;
aux_1566 = BINT(ldir_297);
aux_1564 = BINT(((long)0));
aux_1562 = BINT(((long)0));
blit_string(directory_11, aux_1562, str_300, aux_1564, aux_1566);
}
{
obj_t aux_1575;
obj_t aux_1571;
obj_t aux_1569;
aux_1575 = BINT(lfile_298);
{
long aux_1572;
aux_1572 = (((long)1)+ldir_297);
aux_1571 = BINT(aux_1572);
}
aux_1569 = BINT(((long)0));
blit_string(file_12, aux_1569, str_300, aux_1571, aux_1575);
}
aux1237_776 = str_300;
}
}
}
}
}
POP_TRACE();
return aux1237_776;
}
}
}
}


/* _make-file-name1254 */obj_t _make_file_name1254_212___os(obj_t env_820, obj_t directory_821, obj_t file_822)
{
{
obj_t aux_1585;
obj_t aux_1579;
if(STRINGP(file_822)){
aux_1585 = file_822;
}
 else {
bigloo_type_error_location_103___error(symbol1543___os, string1531___os, file_822, string1512___os, BINT(((long)9782)));
exit( -1 );}
if(STRINGP(directory_821)){
aux_1579 = directory_821;
}
 else {
bigloo_type_error_location_103___error(symbol1543___os, string1531___os, directory_821, string1512___os, BINT(((long)9782)));
exit( -1 );}
return make_file_name_203___os(aux_1579, aux_1585);
}
}


/* make-static-library-name */obj_t make_static_library_name_134___os(obj_t libname_13)
{
{
obj_t symbol1240_777;
symbol1240_777 = symbol1544___os;
{
PUSH_TRACE(symbol1240_777);
BUNSPEC;
{
obj_t aux1239_778;
{
obj_t list1066_306;
{
obj_t arg1067_307;
{
obj_t arg1069_309;
{
obj_t aux_1593;
aux_1593 = string_to_bstring(STATIC_LIB_SUFFIX);
arg1069_309 = MAKE_PAIR(aux_1593, BNIL);
}
arg1067_307 = MAKE_PAIR(string1537___os, arg1069_309);
}
list1066_306 = MAKE_PAIR(libname_13, arg1067_307);
}
aux1239_778 = string_append_106___r4_strings_6_7(list1066_306);
}
POP_TRACE();
return aux1239_778;
}
}
}
}


/* _make-static-library-name1255 */obj_t _make_static_library_name1255_74___os(obj_t env_823, obj_t libname_824)
{
{
obj_t aux_1600;
if(STRINGP(libname_824)){
aux_1600 = libname_824;
}
 else {
bigloo_type_error_location_103___error(symbol1545___os, string1531___os, libname_824, string1512___os, BINT(((long)10482)));
exit( -1 );}
return make_static_library_name_134___os(aux_1600);
}
}


/* make-shared-library-name */obj_t make_shared_library_name_78___os(obj_t libname_14)
{
{
obj_t symbol1242_779;
symbol1242_779 = symbol1546___os;
{
PUSH_TRACE(symbol1242_779);
BUNSPEC;
{
obj_t aux1241_780;
{
obj_t list1071_311;
{
obj_t arg1072_312;
{
obj_t arg1076_314;
{
obj_t aux_1608;
aux_1608 = string_to_bstring(SHARED_LIB_SUFFIX);
arg1076_314 = MAKE_PAIR(aux_1608, BNIL);
}
arg1072_312 = MAKE_PAIR(string1537___os, arg1076_314);
}
list1071_311 = MAKE_PAIR(libname_14, arg1072_312);
}
aux1241_780 = string_append_106___r4_strings_6_7(list1071_311);
}
POP_TRACE();
return aux1241_780;
}
}
}
}


/* _make-shared-library-name1256 */obj_t _make_shared_library_name1256_77___os(obj_t env_825, obj_t libname_826)
{
{
obj_t aux_1615;
if(STRINGP(libname_826)){
aux_1615 = libname_826;
}
 else {
bigloo_type_error_location_103___error(symbol1547___os, string1531___os, libname_826, string1512___os, BINT(((long)10960)));
exit( -1 );}
return make_shared_library_name_78___os(aux_1615);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___os()
{
{
obj_t symbol1244_781;
symbol1244_781 = symbol1548___os;
{
PUSH_TRACE(symbol1244_781);
BUNSPEC;
{
obj_t aux1243_782;
aux1243_782 = module_initialization_70___error(((long)0), "__OS");
POP_TRACE();
return aux1243_782;
}
}
}
}

