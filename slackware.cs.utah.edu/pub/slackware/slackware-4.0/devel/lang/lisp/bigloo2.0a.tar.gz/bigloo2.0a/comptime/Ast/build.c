/*===========================================================================*/
/*   (Ast/build.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern obj_t append___r4_pairs_and_lists_6_3(obj_t);
static obj_t method_init_76_ast_build();
extern obj_t current_error_port;
extern obj_t inline_methods__72_object_inline();
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t find_location_loc_243_tools_location(obj_t, obj_t);
extern obj_t unit__defs_135_ast_unit(obj_t);
extern obj_t leave_function_170_tools_error();
extern obj_t check_to_be_define_14_ast_find_gdefs_13();
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_ast_build(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_unit(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_find_gdefs_13(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_object_inline(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static global_t sfun_def__ast_191_ast_build(global_t);
static obj_t _build_ast_sans_remove_171_ast_build(obj_t, obj_t);
static obj_t imported_modules_init_94_ast_build();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t library_modules_init_112_ast_build();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t build_ast_197_ast_build(obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t remove_var_123_ast_remove(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t build_ast_sans_remove_93_ast_build(obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t find_location_120_tools_location(obj_t);
static obj_t require_initialization_114_ast_build = BUNSPEC;
static obj_t _build_ast_150_ast_build(obj_t, obj_t);
static obj_t cnst_init_137_ast_build();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[3];

DEFINE_EXPORT_PROCEDURE(build_ast_sans_remove_env_209_ast_build, _build_ast_sans_remove_171_ast_build1632, _build_ast_sans_remove_171_ast_build, 0L, 1);
DEFINE_EXPORT_PROCEDURE(build_ast_env_244_ast_build, _build_ast_150_ast_build1633, _build_ast_150_ast_build, 0L, 1);
DEFINE_STRING(string1626_ast_build, string1626_ast_build1634, "VALUE PASS-STARTED AST ", 23);
DEFINE_STRING(string1625_ast_build, string1625_ast_build1635, "failure during postlude hook", 28);
DEFINE_STRING(string1624_ast_build, string1624_ast_build1636, " error", 6);
DEFINE_STRING(string1623_ast_build, string1623_ast_build1637, " occured, ending ...", 20);
DEFINE_STRING(string1622_ast_build, string1622_ast_build1638, "failure during prelude hook", 27);
DEFINE_STRING(string1621_ast_build, string1621_ast_build1639, "   . ", 5);
DEFINE_STRING(string1620_ast_build, string1620_ast_build1640, "Ast", 3);


/* module-initialization */ obj_t 
module_initialization_70_ast_build(long checksum_1174, char *from_1175)
{
   if (CBOOL(require_initialization_114_ast_build))
     {
	require_initialization_114_ast_build = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_build();
	cnst_init_137_ast_build();
	imported_modules_init_94_ast_build();
	method_init_76_ast_build();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_build()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_BUILD");
   module_initialization_70___r4_output_6_10_3(((long) 0), "AST_BUILD");
   module_initialization_70___r4_numbers_6_5(((long) 0), "AST_BUILD");
   module_initialization_70___reader(((long) 0), "AST_BUILD");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_build()
{
   {
      obj_t cnst_port_138_1166;
      cnst_port_138_1166 = open_input_string(string1626_ast_build);
      {
	 long i_1167;
	 i_1167 = ((long) 2);
       loop_1168:
	 {
	    bool_t test1627_1169;
	    test1627_1169 = (i_1167 == ((long) -1));
	    if (test1627_1169)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1628_1170;
		    {
		       obj_t list1629_1171;
		       {
			  obj_t arg1630_1172;
			  arg1630_1172 = BNIL;
			  list1629_1171 = MAKE_PAIR(cnst_port_138_1166, arg1630_1172);
		       }
		       arg1628_1170 = read___reader(list1629_1171);
		    }
		    CNST_TABLE_SET(i_1167, arg1628_1170);
		 }
		 {
		    int aux_1173;
		    {
		       long aux_1193;
		       aux_1193 = (i_1167 - ((long) 1));
		       aux_1173 = (int) (aux_1193);
		    }
		    {
		       long i_1196;
		       i_1196 = (long) (aux_1173);
		       i_1167 = i_1196;
		       goto loop_1168;
		    }
		 }
	      }
	 }
      }
   }
}


/* build-ast */ obj_t 
build_ast_197_ast_build(obj_t units_1)
{
   {
      obj_t arg1446_1112;
      obj_t arg1448_1113;
      arg1446_1112 = CNST_TABLE_REF(((long) 0));
      arg1448_1113 = build_ast_sans_remove_93_ast_build(units_1);
      return remove_var_123_ast_remove(arg1446_1112, arg1448_1113);
   }
}


/* _build-ast */ obj_t 
_build_ast_150_ast_build(obj_t env_1162, obj_t units_1163)
{
   return build_ast_197_ast_build(units_1163);
}


/* build-ast-sans-remove */ obj_t 
build_ast_sans_remove_93_ast_build(obj_t units_2)
{
   {
      obj_t list1449_697;
      {
	 obj_t arg1453_699;
	 {
	    obj_t arg1455_701;
	    {
	       obj_t aux_1202;
	       aux_1202 = BCHAR(((unsigned char) '\n'));
	       arg1455_701 = MAKE_PAIR(aux_1202, BNIL);
	    }
	    arg1453_699 = MAKE_PAIR(string1620_ast_build, arg1455_701);
	 }
	 list1449_697 = MAKE_PAIR(string1621_ast_build, arg1453_699);
      }
      verbose_tools_speek(BINT(((long) 1)), list1449_697);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1620_ast_build;
   {
      obj_t hooks_703;
      obj_t hnames_704;
      hooks_703 = BNIL;
      hnames_704 = BNIL;
    loop_705:
      if (NULLP(hooks_703))
	{
	   CNST_TABLE_REF(((long) 1));
	}
      else
	{
	   bool_t test1463_710;
	   {
	      obj_t fun1470_716;
	      fun1470_716 = CAR(hooks_703);
	      {
		 obj_t aux_1214;
		 aux_1214 = PROCEDURE_ENTRY(fun1470_716) (fun1470_716, BEOA);
		 test1463_710 = CBOOL(aux_1214);
	      }
	   }
	   if (test1463_710)
	     {
		{
		   obj_t hnames_1221;
		   obj_t hooks_1219;
		   hooks_1219 = CDR(hooks_703);
		   hnames_1221 = CDR(hnames_704);
		   hnames_704 = hnames_1221;
		   hooks_703 = hooks_1219;
		   goto loop_705;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1620_ast_build, string1622_ast_build, CAR(hnames_704));
	     }
	}
   }
   {
      obj_t defs_717;
      {
	 obj_t runner1518_777;
	 if (NULLP(units_2))
	   {
	      runner1518_777 = BNIL;
	   }
	 else
	   {
	      obj_t head1437_763;
	      {
		 obj_t arg1515_774;
		 arg1515_774 = unit__defs_135_ast_unit(CAR(units_2));
		 head1437_763 = MAKE_PAIR(arg1515_774, BNIL);
	      }
	      {
		 obj_t l1435_764;
		 obj_t tail1438_765;
		 l1435_764 = CDR(units_2);
		 tail1438_765 = head1437_763;
	       lname1436_766:
		 if (NULLP(l1435_764))
		   {
		      runner1518_777 = head1437_763;
		   }
		 else
		   {
		      obj_t newtail1439_769;
		      {
			 obj_t arg1511_771;
			 arg1511_771 = unit__defs_135_ast_unit(CAR(l1435_764));
			 newtail1439_769 = MAKE_PAIR(arg1511_771, BNIL);
		      }
		      SET_CDR(tail1438_765, newtail1439_769);
		      {
			 obj_t tail1438_1238;
			 obj_t l1435_1236;
			 l1435_1236 = CDR(l1435_764);
			 tail1438_1238 = newtail1439_769;
			 tail1438_765 = tail1438_1238;
			 l1435_764 = l1435_1236;
			 goto lname1436_766;
		      }
		   }
	      }
	   }
	 defs_717 = append___r4_pairs_and_lists_6_3(runner1518_777);
      }
      check_to_be_define_14_ast_find_gdefs_13();
      {
	 obj_t ast_718;
	 if (NULLP(defs_717))
	   {
	      ast_718 = BNIL;
	   }
	 else
	   {
	      obj_t head1442_747;
	      {
		 global_t arg1503_758;
		 {
		    global_t aux_1244;
		    {
		       obj_t aux_1245;
		       aux_1245 = CAR(defs_717);
		       aux_1244 = (global_t) (aux_1245);
		    }
		    arg1503_758 = sfun_def__ast_191_ast_build(aux_1244);
		 }
		 {
		    obj_t aux_1249;
		    aux_1249 = (obj_t) (arg1503_758);
		    head1442_747 = MAKE_PAIR(aux_1249, BNIL);
		 }
	      }
	      {
		 obj_t l1440_748;
		 obj_t tail1443_749;
		 l1440_748 = CDR(defs_717);
		 tail1443_749 = head1442_747;
	       lname1441_750:
		 if (NULLP(l1440_748))
		   {
		      ast_718 = head1442_747;
		   }
		 else
		   {
		      obj_t newtail1444_753;
		      {
			 global_t arg1500_755;
			 {
			    global_t aux_1254;
			    {
			       obj_t aux_1255;
			       aux_1255 = CAR(l1440_748);
			       aux_1254 = (global_t) (aux_1255);
			    }
			    arg1500_755 = sfun_def__ast_191_ast_build(aux_1254);
			 }
			 {
			    obj_t aux_1259;
			    aux_1259 = (obj_t) (arg1500_755);
			    newtail1444_753 = MAKE_PAIR(aux_1259, BNIL);
			 }
		      }
		      SET_CDR(tail1443_749, newtail1444_753);
		      {
			 obj_t tail1443_1265;
			 obj_t l1440_1263;
			 l1440_1263 = CDR(l1440_748);
			 tail1443_1265 = newtail1444_753;
			 tail1443_749 = tail1443_1265;
			 l1440_748 = l1440_1263;
			 goto lname1441_750;
		      }
		   }
	      }
	   }
	 inline_methods__72_object_inline();
	 {
	    bool_t test1471_720;
	    {
	       long n1_1144;
	       n1_1144 = (long) CINT(_nb_error_on_pass__70_tools_error);
	       test1471_720 = (n1_1144 > ((long) 0));
	    }
	    if (test1471_720)
	      {
		 {
		    char *arg1475_723;
		    {
		       bool_t test1482_730;
		       {
			  bool_t test1483_731;
			  {
			     obj_t obj_1146;
			     obj_1146 = _nb_error_on_pass__70_tools_error;
			     test1483_731 = INTEGERP(obj_1146);
			  }
			  if (test1483_731)
			    {
			       test1482_730 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
			    }
			  else
			    {
			       test1482_730 = ((bool_t) 0);
			    }
		       }
		       if (test1482_730)
			 {
			    arg1475_723 = "s";
			 }
		       else
			 {
			    arg1475_723 = "";
			 }
		    }
		    {
		       obj_t list1477_725;
		       {
			  obj_t arg1478_726;
			  {
			     obj_t arg1479_727;
			     {
				obj_t arg1480_728;
				arg1480_728 = MAKE_PAIR(string1623_ast_build, BNIL);
				{
				   obj_t aux_1277;
				   aux_1277 = string_to_bstring(arg1475_723);
				   arg1479_727 = MAKE_PAIR(aux_1277, arg1480_728);
				}
			     }
			     arg1478_726 = MAKE_PAIR(string1624_ast_build, arg1479_727);
			  }
			  list1477_725 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1478_726);
		       }
		       fprint___r4_output_6_10_3(current_error_port, list1477_725);
		    }
		 }
		 {
		    obj_t res1619_1148;
		    exit(((long) -1));
		    res1619_1148 = BINT(((long) -1));
		    return res1619_1148;
		 }
	      }
	    else
	      {
		 obj_t hooks_732;
		 obj_t hnames_733;
		 hooks_732 = BNIL;
		 hnames_733 = BNIL;
	       loop_734:
		 if (NULLP(hooks_732))
		   {
		      return ast_718;
		   }
		 else
		   {
		      bool_t test1488_739;
		      {
			 obj_t fun1495_744;
			 fun1495_744 = CAR(hooks_732);
			 {
			    obj_t aux_1288;
			    aux_1288 = PROCEDURE_ENTRY(fun1495_744) (fun1495_744, BEOA);
			    test1488_739 = CBOOL(aux_1288);
			 }
		      }
		      if (test1488_739)
			{
			   {
			      obj_t hnames_1295;
			      obj_t hooks_1293;
			      hooks_1293 = CDR(hooks_732);
			      hnames_1295 = CDR(hnames_733);
			      hnames_733 = hnames_1295;
			      hooks_732 = hooks_1293;
			      goto loop_734;
			   }
			}
		      else
			{
			   return internal_error_43_tools_error(_current_pass__25_engine_pass, string1625_ast_build, CAR(hnames_733));
			}
		   }
	      }
	 }
      }
   }
}


/* _build-ast-sans-remove */ obj_t 
_build_ast_sans_remove_171_ast_build(obj_t env_1164, obj_t units_1165)
{
   return build_ast_sans_remove_93_ast_build(units_1165);
}


/* sfun-def->ast */ global_t 
sfun_def__ast_191_ast_build(global_t def_3)
{
   enter_function_81_tools_error((((global_t) CREF(def_3))->id));
   {
      value_t sfun_779;
      sfun_779 = (((global_t) CREF(def_3))->value);
      {
	 obj_t sfun_args_174_780;
	 {
	    sfun_t obj_1157;
	    obj_1157 = (sfun_t) (sfun_779);
	    sfun_args_174_780 = (((sfun_t) CREF(obj_1157))->args);
	 }
	 {
	    obj_t sfun_body_exp_131_781;
	    {
	       sfun_t obj_1158;
	       obj_1158 = (sfun_t) (sfun_779);
	       sfun_body_exp_131_781 = (((sfun_t) CREF(obj_1158))->body);
	    }
	    {
	       obj_t def_loc_185_782;
	       def_loc_185_782 = find_location_120_tools_location((((global_t) CREF(def_3))->src));
	       {
		  node_t body_783;
		  {
		     obj_t arg1522_784;
		     obj_t arg1524_785;
		     arg1522_784 = find_location_loc_243_tools_location(sfun_body_exp_131_781, def_loc_185_782);
		     arg1524_785 = CNST_TABLE_REF(((long) 2));
		     body_783 = sexp__node_235_ast_sexp(sfun_body_exp_131_781, sfun_args_174_780, arg1522_784, arg1524_785);
		  }
		  {
		     {
			sfun_t obj_1160;
			obj_t val1135_1161;
			obj_1160 = (sfun_t) (sfun_779);
			val1135_1161 = (obj_t) (body_783);
			((((sfun_t) CREF(obj_1160))->body) = ((obj_t) val1135_1161), BUNSPEC);
		     }
		     leave_function_170_tools_error();
		     return def_3;
		  }
	       }
	    }
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_ast_build()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_build()
{
   module_initialization_70_tools_speek(((long) 0), "AST_BUILD");
   module_initialization_70_tools_error(((long) 0), "AST_BUILD");
   module_initialization_70_engine_pass(((long) 0), "AST_BUILD");
   module_initialization_70_type_type(((long) 0), "AST_BUILD");
   module_initialization_70_ast_var(((long) 0), "AST_BUILD");
   module_initialization_70_ast_node(((long) 0), "AST_BUILD");
   module_initialization_70_ast_unit(((long) 0), "AST_BUILD");
   module_initialization_70_ast_sexp(((long) 0), "AST_BUILD");
   module_initialization_70_ast_env(((long) 0), "AST_BUILD");
   module_initialization_70_ast_find_gdefs_13(((long) 0), "AST_BUILD");
   module_initialization_70_ast_remove(((long) 0), "AST_BUILD");
   module_initialization_70_ast_local(((long) 0), "AST_BUILD");
   module_initialization_70_object_inline(((long) 0), "AST_BUILD");
   module_initialization_70_tools_args(((long) 0), "AST_BUILD");
   module_initialization_70_tools_progn(((long) 0), "AST_BUILD");
   module_initialization_70_tools_location(((long) 0), "AST_BUILD");
   return module_initialization_70_tools_shape(((long) 0), "AST_BUILD");
}
