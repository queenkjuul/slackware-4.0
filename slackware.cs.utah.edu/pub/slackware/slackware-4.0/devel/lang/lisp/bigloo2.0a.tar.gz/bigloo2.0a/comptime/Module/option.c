/*===========================================================================*/
/*   (Module/option.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t ccomp_module_module;
static obj_t method_init_76_module_option();
static obj_t _make_option_compiler_172_module_option(obj_t);
static obj_t option_producer_208_module_option(obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_module_option(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
static obj_t _option_producer_203_module_option(obj_t, obj_t);
extern obj_t make_option_compiler_205_module_option();
extern long class_num_218___object(obj_t);
static obj_t imported_modules_init_94_module_option();
static obj_t library_modules_init_112_module_option();
static obj_t toplevel_init_63_module_option();
extern obj_t open_input_string(obj_t);
static obj_t arg1061_module_option(obj_t, obj_t, obj_t);
static obj_t arg1060_module_option(obj_t);
static obj_t arg1059_module_option(obj_t, obj_t, obj_t);
extern obj_t eval___eval(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_module_option = BUNSPEC;
static obj_t cnst_init_137_module_option();
static obj_t __cnst[2];

DEFINE_STATIC_PROCEDURE(proc1168_module_option, arg1059_module_option1189, arg1059_module_option, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1167_module_option, arg1060_module_option1190, arg1060_module_option, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1166_module_option, arg1061_module_option1191, arg1061_module_option, 0L, 2);
DEFINE_STATIC_PROCEDURE(option_producer_env_54_module_option, _option_producer_203_module_option1192, _option_producer_203_module_option, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_option_compiler_env_76_module_option, _make_option_compiler_172_module_option1193, _make_option_compiler_172_module_option, 0L, 0);
DEFINE_STRING(string1171_module_option, string1171_module_option1194, "VOID OPTION ", 12);
DEFINE_STRING(string1169_module_option, string1169_module_option1195, "Parse error", 11);
DEFINE_STRING(string1170_module_option, string1170_module_option1196, "Illegal `option' clause", 23);


/* module-initialization */ obj_t 
module_initialization_70_module_option(long checksum_150, char *from_151)
{
   if (CBOOL(require_initialization_114_module_option))
     {
	require_initialization_114_module_option = BBOOL(((bool_t) 0));
	library_modules_init_112_module_option();
	cnst_init_137_module_option();
	imported_modules_init_94_module_option();
	method_init_76_module_option();
	toplevel_init_63_module_option();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_option()
{
   module_initialization_70___object(((long) 0), "MODULE_OPTION");
   module_initialization_70___eval(((long) 0), "MODULE_OPTION");
   module_initialization_70___reader(((long) 0), "MODULE_OPTION");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_option()
{
   {
      obj_t cnst_port_138_142;
      cnst_port_138_142 = open_input_string(string1171_module_option);
      {
	 long i_143;
	 i_143 = ((long) 1);
       loop_144:
	 {
	    bool_t test1172_145;
	    test1172_145 = (i_143 == ((long) -1));
	    if (test1172_145)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1175_146;
		    {
		       obj_t list1176_147;
		       {
			  obj_t arg1187_148;
			  arg1187_148 = BNIL;
			  list1176_147 = MAKE_PAIR(cnst_port_138_142, arg1187_148);
		       }
		       arg1175_146 = read___reader(list1176_147);
		    }
		    CNST_TABLE_SET(i_143, arg1175_146);
		 }
		 {
		    int aux_149;
		    {
		       long aux_169;
		       aux_169 = (i_143 - ((long) 1));
		       aux_149 = (int) (aux_169);
		    }
		    {
		       long i_172;
		       i_172 = (long) (aux_149);
		       i_143 = i_172;
		       goto loop_144;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_option()
{
   return BUNSPEC;
}


/* make-option-compiler */ obj_t 
make_option_compiler_205_module_option()
{
   {
      obj_t arg1057_48;
      arg1057_48 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1061_128;
	 obj_t arg1060_129;
	 obj_t arg1059_130;
	 arg1061_128 = proc1166_module_option;
	 arg1060_129 = proc1167_module_option;
	 arg1059_130 = proc1168_module_option;
	 {
	    ccomp_t res1165_113;
	    {
	       ccomp_t new1002_104;
	       new1002_104 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1163_105;
		  arg1163_105 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_111;
		     obj_111 = (obj_t) (new1002_104);
		     (((obj_t) CREF(obj_111))->header = MAKE_HEADER(arg1163_105, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_179;
		  aux_179 = (object_t) (new1002_104);
		  OBJECT_WIDENING_SET(aux_179, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_104))->id) = ((obj_t) arg1057_48), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_104))->producer) = ((obj_t) option_producer_env_54_module_option), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_104))->consumer) = ((obj_t) arg1059_130), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_104))->finalizer) = ((obj_t) arg1060_129), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_104))->checksummer) = ((obj_t) arg1061_128), BUNSPEC);
	       res1165_113 = new1002_104;
	    }
	    return (obj_t) (res1165_113);
	 }
      }
   }
}


/* _make-option-compiler */ obj_t 
_make_option_compiler_172_module_option(obj_t env_131)
{
   return make_option_compiler_205_module_option();
}


/* arg1061 */ obj_t 
arg1061_module_option(obj_t env_132, obj_t m_133, obj_t c_134)
{
   {
      obj_t m_57;
      obj_t c_58;
      m_57 = m_133;
      c_58 = c_134;
      return c_58;
   }
}


/* arg1060 */ obj_t 
arg1060_module_option(obj_t env_135)
{
   {
      return CNST_TABLE_REF(((long) 1));
   }
}


/* arg1059 */ obj_t 
arg1059_module_option(obj_t env_136, obj_t m_137, obj_t c_138)
{
   {
      obj_t m_53;
      obj_t c_54;
      m_53 = m_137;
      c_54 = c_138;
      return BNIL;
   }
}


/* option-producer */ obj_t 
option_producer_208_module_option(obj_t clause_19)
{
   {
      obj_t protos_63;
      if (PAIRP(clause_19))
	{
	   protos_63 = CDR(clause_19);
	   {
	      obj_t l1011_69;
	      l1011_69 = protos_63;
	    lname1012_70:
	      if (PAIRP(l1011_69))
		{
		   eval___eval(CAR(l1011_69), BNIL);
		   {
		      obj_t l1011_196;
		      l1011_196 = CDR(l1011_69);
		      l1011_69 = l1011_196;
		      goto lname1012_70;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   return BNIL;
	}
      else
	{
	   {
	      obj_t list1151_78;
	      list1151_78 = MAKE_PAIR(BNIL, BNIL);
	      return user_error_151_tools_error(string1169_module_option, string1170_module_option, clause_19, list1151_78);
	   }
	}
   }
}


/* _option-producer */ obj_t 
_option_producer_203_module_option(obj_t env_139, obj_t clause_140)
{
   return option_producer_208_module_option(clause_140);
}


/* method-init */ obj_t 
method_init_76_module_option()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_option()
{
   module_initialization_70_module_module(((long) 0), "MODULE_OPTION");
   module_initialization_70_tools_error(((long) 0), "MODULE_OPTION");
   return module_initialization_70_engine_param(((long) 0), "MODULE_OPTION");
}
