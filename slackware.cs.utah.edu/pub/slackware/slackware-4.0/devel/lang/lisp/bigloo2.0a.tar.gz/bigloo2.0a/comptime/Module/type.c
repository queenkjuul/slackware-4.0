/*===========================================================================*/
/*   (Module/type.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct tvec
  {
     struct type *item_type_130;
  }
    *tvec_t;


extern obj_t ccomp_module_module;
static obj_t method_init_76_module_type();
extern obj_t add_coercion__50_type_coercion(type_t, type_t, obj_t, obj_t);
static obj_t type_finalizer_212_module_type();
extern obj_t type_type_type;
extern obj_t create_struct(obj_t, long);
static obj_t _tvector_accesses__185_module_type = BUNSPEC;
extern type_t declare_type__118_type_env(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern tvec_t declare_tvector_type__101_tvector_tvector(obj_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _tvector_finalizer_32_module_type(obj_t);
extern obj_t module_initialization_70_module_type(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_coercion(long, char *);
extern obj_t module_initialization_70_tvector_tvector(long, char *);
extern obj_t module_initialization_70_tvector_access(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t tvector_finalizer_246_module_type();
extern long class_num_218___object(obj_t);
extern type_t find_type_26_type_env(obj_t);
extern obj_t make_type_compiler_68_module_type();
static obj_t imported_modules_init_94_module_type();
static obj_t type_producer_consumer_218_module_type(obj_t);
extern obj_t make_tvector_accesses_19_tvector_access(tvec_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_module_type();
extern type_t use_type__231_type_env(obj_t);
static obj_t toplevel_init_63_module_type();
extern obj_t open_input_string(obj_t);
static obj_t arg1194_module_type(obj_t, obj_t, obj_t);
static obj_t arg1192_module_type(obj_t, obj_t, obj_t);
static obj_t _type_finalizer_85_module_type(obj_t);
extern obj_t read___reader(obj_t);
static obj_t _type_parser_235_module_type(obj_t, obj_t, obj_t);
extern type_t declare_subtype__66_type_env(obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_module_type = BUNSPEC;
static obj_t _make_type_compiler_3_module_type(obj_t);
extern obj_t type_parser_173_module_type(obj_t, obj_t);
static obj_t cnst_init_137_module_type();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t _type_producer_consumer_52_module_type(obj_t, obj_t);
static obj_t __cnst[9];

DEFINE_STATIC_PROCEDURE(type_finalizer_env_145_module_type, _type_finalizer_85_module_type1923, _type_finalizer_85_module_type, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1906_module_type, arg1192_module_type1924, arg1192_module_type, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1905_module_type, arg1194_module_type1925, arg1194_module_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_type_compiler_env_179_module_type, _make_type_compiler_3_module_type1926, _make_type_compiler_3_module_type, 0L, 0);
DEFINE_EXPORT_PROCEDURE(type_parser_env_56_module_type, _type_parser_235_module_type1927, _type_parser_235_module_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvector_finalizer_env_50_module_type, _tvector_finalizer_32_module_type1928, _tvector_finalizer_32_module_type, 0L, 0);
DEFINE_STRING(string1917_module_type, string1917_module_type1929, "VOID UNIT TVECTOR COERCE SUBTYPE MAGIC BIGLOO LAMBDA TYPE ", 58);
DEFINE_STRING(string1916_module_type, string1916_module_type1930, "Unknow type", 11);
DEFINE_STRING(string1915_module_type, string1915_module_type1931, "type coercion", 13);
DEFINE_STRING(string1914_module_type, string1914_module_type1932, "Illegal clause", 14);
DEFINE_STRING(string1913_module_type, string1913_module_type1933, "Coercion", 8);
DEFINE_STRING(string1912_module_type, string1912_module_type1934, "Illegal type declaration", 24);
DEFINE_STRING(string1911_module_type, string1911_module_type1935, "Unknow parent type", 18);
DEFINE_STRING(string1909_module_type, string1909_module_type1936, "Subtype", 7);
DEFINE_STRING(string1910_module_type, string1910_module_type1937, "Parents are of different classes", 32);
DEFINE_STRING(string1908_module_type, string1908_module_type1938, "Illegal `type' clause", 21);
DEFINE_STRING(string1907_module_type, string1907_module_type1939, "Parse error", 11);
DEFINE_STATIC_PROCEDURE(type_producer_consumer_env_12_module_type, _type_producer_consumer_52_module_type1940, _type_producer_consumer_52_module_type, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_module_type(long checksum_2244, char *from_2245)
{
   if (CBOOL(require_initialization_114_module_type))
     {
	require_initialization_114_module_type = BBOOL(((bool_t) 0));
	library_modules_init_112_module_type();
	cnst_init_137_module_type();
	imported_modules_init_94_module_type();
	method_init_76_module_type();
	toplevel_init_63_module_type();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_type()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "MODULE_TYPE");
   module_initialization_70___object(((long) 0), "MODULE_TYPE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_TYPE");
   module_initialization_70___reader(((long) 0), "MODULE_TYPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_type()
{
   {
      obj_t cnst_port_138_2236;
      cnst_port_138_2236 = open_input_string(string1917_module_type);
      {
	 long i_2237;
	 i_2237 = ((long) 8);
       loop_2238:
	 {
	    bool_t test1918_2239;
	    test1918_2239 = (i_2237 == ((long) -1));
	    if (test1918_2239)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1919_2240;
		    {
		       obj_t list1920_2241;
		       {
			  obj_t arg1921_2242;
			  arg1921_2242 = BNIL;
			  list1920_2241 = MAKE_PAIR(cnst_port_138_2236, arg1921_2242);
		       }
		       arg1919_2240 = read___reader(list1920_2241);
		    }
		    CNST_TABLE_SET(i_2237, arg1919_2240);
		 }
		 {
		    int aux_2243;
		    {
		       long aux_2264;
		       aux_2264 = (i_2237 - ((long) 1));
		       aux_2243 = (int) (aux_2264);
		    }
		    {
		       long i_2267;
		       i_2267 = (long) (aux_2243);
		       i_2237 = i_2267;
		       goto loop_2238;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_type()
{
   return (_tvector_accesses__185_module_type = BNIL,
      BUNSPEC);
}


/* make-type-compiler */ obj_t 
make_type_compiler_68_module_type()
{
   {
      obj_t arg1190_147;
      arg1190_147 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1194_2219;
	 obj_t arg1192_2220;
	 arg1194_2219 = proc1905_module_type;
	 arg1192_2220 = proc1906_module_type;
	 {
	    ccomp_t res1904_1201;
	    {
	       ccomp_t new1003_1192;
	       new1003_1192 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1902_1193;
		  arg1902_1193 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_1199;
		     obj_1199 = (obj_t) (new1003_1192);
		     (((obj_t) CREF(obj_1199))->header = MAKE_HEADER(arg1902_1193, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_2274;
		  aux_2274 = (object_t) (new1003_1192);
		  OBJECT_WIDENING_SET(aux_2274, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1003_1192))->id) = ((obj_t) arg1190_147), BUNSPEC);
	       ((((ccomp_t) CREF(new1003_1192))->producer) = ((obj_t) type_producer_consumer_env_12_module_type), BUNSPEC);
	       ((((ccomp_t) CREF(new1003_1192))->consumer) = ((obj_t) arg1192_2220), BUNSPEC);
	       ((((ccomp_t) CREF(new1003_1192))->finalizer) = ((obj_t) type_finalizer_env_145_module_type), BUNSPEC);
	       ((((ccomp_t) CREF(new1003_1192))->checksummer) = ((obj_t) arg1194_2219), BUNSPEC);
	       res1904_1201 = new1003_1192;
	    }
	    return (obj_t) (res1904_1201);
	 }
      }
   }
}


/* _make-type-compiler */ obj_t 
_make_type_compiler_3_module_type(obj_t env_2221)
{
   return make_type_compiler_68_module_type();
}


/* arg1194 */ obj_t 
arg1194_module_type(obj_t env_2222, obj_t m_2223, obj_t c_2224)
{
   {
      obj_t m_155;
      obj_t c_156;
      m_155 = m_2223;
      c_156 = c_2224;
      return c_156;
   }
}


/* arg1192 */ obj_t 
arg1192_module_type(obj_t env_2225, obj_t m_2226, obj_t c_2227)
{
   {
      obj_t m_152;
      obj_t c_153;
      m_152 = m_2226;
      c_153 = c_2227;
      return type_producer_consumer_218_module_type(c_153);
   }
}


/* type-producer/consumer */ obj_t 
type_producer_consumer_218_module_type(obj_t clause_19)
{
   {
      obj_t protos_160;
      if (PAIRP(clause_19))
	{
	   protos_160 = CDR(clause_19);
	   {
	      obj_t l1055_166;
	      l1055_166 = protos_160;
	    lname1056_167:
	      if (PAIRP(l1055_166))
		{
		   type_parser_173_module_type(CAR(l1055_166), clause_19);
		   {
		      obj_t l1055_2291;
		      l1055_2291 = CDR(l1055_166);
		      l1055_166 = l1055_2291;
		      goto lname1056_167;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   return BNIL;
	}
      else
	{
	   {
	      obj_t list1205_174;
	      list1205_174 = MAKE_PAIR(BNIL, BNIL);
	      return user_error_151_tools_error(string1907_module_type, string1908_module_type, clause_19, list1205_174);
	   }
	}
   }
}


/* _type-producer/consumer */ obj_t 
_type_producer_consumer_52_module_type(obj_t env_2228, obj_t clause_2229)
{
   return type_producer_consumer_218_module_type(clause_2229);
}


/* type-parser */ obj_t 
type_parser_173_module_type(obj_t clause_20, obj_t clauses_21)
{
   {
      obj_t from_194;
      obj_t to_195;
      obj_t check_196;
      obj_t coerce_197;
      obj_t id_191;
      obj_t item_type_130_192;
      obj_t child_187;
      obj_t name_188;
      obj_t parent_189;
      if (PAIRP(clause_20))
	{
	   obj_t car_148_109_202;
	   obj_t cdr_149_75_203;
	   car_148_109_202 = CAR(clause_20);
	   cdr_149_75_203 = CDR(clause_20);
	   if (SYMBOLP(car_148_109_202))
	     {
		if (PAIRP(cdr_149_75_203))
		  {
		     obj_t car_153_175_206;
		     car_153_175_206 = CAR(cdr_149_75_203);
		     if (STRINGP(car_153_175_206))
		       {
			  bool_t test_2308;
			  {
			     obj_t aux_2309;
			     aux_2309 = CDR(cdr_149_75_203);
			     test_2308 = (aux_2309 == BNIL);
			  }
			  if (test_2308)
			    {
			       type_t aux_2312;
			       aux_2312 = declare_type__118_type_env(car_148_109_202, car_153_175_206, CNST_TABLE_REF(((long) 2)));
			       return (obj_t) (aux_2312);
			    }
			  else
			    {
			       if (SYMBOLP(car_148_109_202))
				 {
				    obj_t car_181_188_212;
				    obj_t cdr_182_91_213;
				    car_181_188_212 = CAR(cdr_149_75_203);
				    cdr_182_91_213 = CDR(cdr_149_75_203);
				    if (STRINGP(car_181_188_212))
				      {
					 if (PAIRP(cdr_182_91_213))
					   {
					      obj_t car_188_169_216;
					      car_188_169_216 = CAR(cdr_182_91_213);
					      if (SYMBOLP(car_188_169_216))
						{
						   bool_t test_2327;
						   {
						      obj_t aux_2328;
						      aux_2328 = CDR(cdr_182_91_213);
						      test_2327 = (aux_2328 == BNIL);
						   }
						   if (test_2327)
						     {
							type_t aux_2331;
							aux_2331 = declare_type__118_type_env(car_148_109_202, car_181_188_212, car_188_169_216);
							return (obj_t) (aux_2331);
						     }
						   else
						     {
							bool_t test_2334;
							{
							   obj_t aux_2335;
							   aux_2335 = CNST_TABLE_REF(((long) 3));
							   test_2334 = (car_148_109_202 == aux_2335);
							}
							if (test_2334)
							  {
							     obj_t car_214_78_221;
							     obj_t cdr_215_28_222;
							     car_214_78_221 = CAR(cdr_149_75_203);
							     cdr_215_28_222 = CDR(cdr_149_75_203);
							     if (SYMBOLP(car_214_78_221))
							       {
								  obj_t car_223_89_224;
								  obj_t cdr_224_17_225;
								  car_223_89_224 = CAR(cdr_215_28_222);
								  cdr_224_17_225 = CDR(cdr_215_28_222);
								  if (STRINGP(car_223_89_224))
								    {
								       if (PAIRP(cdr_224_17_225))
									 {
									    obj_t car_230_167_228;
									    car_230_167_228 = CAR(cdr_224_17_225);
									    if (SYMBOLP(car_230_167_228))
									      {
										 bool_t test_2351;
										 {
										    obj_t aux_2352;
										    aux_2352 = CDR(cdr_224_17_225);
										    test_2351 = (aux_2352 == BNIL);
										 }
										 if (test_2351)
										   {
										      type_t type_1254;
										      type_1254 = declare_type__118_type_env(car_214_78_221, car_223_89_224, car_230_167_228);
										      ((((type_t) CREF(type_1254))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
										      return (obj_t) (type_1254);
										   }
										 else
										   {
										    tag_134_32_199:
										      {
											 obj_t list1885_1101;
											 list1885_1101 = MAKE_PAIR(BNIL, BNIL);
											 return user_error_151_tools_error(string1907_module_type, string1912_module_type, clause_20, list1885_1101);
										      }
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     bool_t test_2360;
							     {
								obj_t aux_2361;
								aux_2361 = CNST_TABLE_REF(((long) 4));
								test_2360 = (car_148_109_202 == aux_2361);
							     }
							     if (test_2360)
							       {
								  obj_t car_395_45_235;
								  obj_t cdr_396_70_236;
								  car_395_45_235 = CAR(cdr_149_75_203);
								  cdr_396_70_236 = CDR(cdr_149_75_203);
								  if (SYMBOLP(car_395_45_235))
								    {
								       obj_t car_405_221_238;
								       obj_t cdr_406_48_239;
								       car_405_221_238 = CAR(cdr_396_70_236);
								       cdr_406_48_239 = CDR(cdr_396_70_236);
								       if (STRINGP(car_405_221_238))
									 {
									    if (PAIRP(cdr_406_48_239))
									      {
										 obj_t car_412_102_242;
										 car_412_102_242 = CAR(cdr_406_48_239);
										 if (PAIRP(car_412_102_242))
										   {
										      bool_t test_2377;
										      {
											 obj_t aux_2378;
											 aux_2378 = CDR(cdr_406_48_239);
											 test_2377 = (aux_2378 == BNIL);
										      }
										      if (test_2377)
											{
											   child_187 = car_395_45_235;
											   name_188 = car_405_221_238;
											   parent_189 = car_412_102_242;
											 tag_131_18_190:
											   {
											      obj_t walk_1031;
											      obj_t class_1032;
											      walk_1031 = parent_189;
											      class_1032 = BUNSPEC;
											    loop_1033:
											      if (NULLP(walk_1031))
												{
												   {
												      type_t aux_2383;
												      aux_2383 = declare_subtype__66_type_env(child_187, name_188, parent_189, class_1032);
												      return (obj_t) (aux_2383);
												   }
												}
											      else
												{
												   bool_t test_2386;
												   {
												      obj_t aux_2387;
												      aux_2387 = CAR(walk_1031);
												      test_2386 = SYMBOLP(aux_2387);
												   }
												   if (test_2386)
												     {
													{
													   type_t tparent_1036;
													   tparent_1036 = find_type_26_type_env(CAR(walk_1031));
													   {
													      bool_t test1827_1037;
													      test1827_1037 = is_a__118___object((obj_t) (tparent_1036), type_type_type);
													      if (test1827_1037)
														{
														   bool_t test_2395;
														   if (SYMBOLP(class_1032))
														     {
															bool_t test_2398;
															{
															   obj_t aux_2399;
															   aux_2399 = (((type_t) CREF(tparent_1036))->class);
															   test_2398 = (class_1032 == aux_2399);
															}
															if (test_2398)
															  {
															     test_2395 = ((bool_t) 0);
															  }
															else
															  {
															     test_2395 = ((bool_t) 1);
															  }
														     }
														   else
														     {
															test_2395 = ((bool_t) 0);
														     }
														   if (test_2395)
														     {
															return user_error_151_tools_error(string1909_module_type, string1910_module_type, clause_20, BNIL);
														     }
														   else
														     {
															{
															   obj_t class_2405;
															   obj_t walk_2403;
															   walk_2403 = CDR(walk_1031);
															   class_2405 = (((type_t) CREF(tparent_1036))->class);
															   class_1032 = class_2405;
															   walk_1031 = walk_2403;
															   goto loop_1033;
															}
														     }
														}
													      else
														{
														   return user_error_151_tools_error(string1909_module_type, string1911_module_type, clause_20, BNIL);
														}
													   }
													}
												     }
												   else
												     {
													return user_error_151_tools_error(string1907_module_type, string1912_module_type, clause_20, BNIL);
												     }
												}
											   }
											}
										      else
											{
											   goto tag_134_32_199;
											}
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  bool_t test_2409;
								  {
								     obj_t aux_2410;
								     aux_2410 = CNST_TABLE_REF(((long) 5));
								     test_2409 = (car_148_109_202 == aux_2410);
								  }
								  if (test_2409)
								    {
								       obj_t car_523_79_249;
								       obj_t cdr_524_164_250;
								       car_523_79_249 = CAR(cdr_149_75_203);
								       cdr_524_164_250 = CDR(cdr_149_75_203);
								       if (SYMBOLP(car_523_79_249))
									 {
									    obj_t car_534_175_252;
									    obj_t cdr_535_10_253;
									    car_534_175_252 = CAR(cdr_524_164_250);
									    cdr_535_10_253 = CDR(cdr_524_164_250);
									    if (SYMBOLP(car_534_175_252))
									      {
										 if (PAIRP(cdr_535_10_253))
										   {
										      obj_t cdr_544_212_256;
										      cdr_544_212_256 = CDR(cdr_535_10_253);
										      if (PAIRP(cdr_544_212_256))
											{
											   bool_t test_2426;
											   {
											      obj_t aux_2427;
											      aux_2427 = CDR(cdr_544_212_256);
											      test_2426 = (aux_2427 == BNIL);
											   }
											   if (test_2426)
											     {
												from_194 = car_523_79_249;
												to_195 = car_534_175_252;
												check_196 = CAR(cdr_535_10_253);
												coerce_197 = CAR(cdr_544_212_256);
											      tag_133_84_198:
												{
												   bool_t test1840_1051;
												   {
												      bool_t test1857_1066;
												      {
													 obj_t check_1090;
													 {
													    obj_t aux_2430;
													    check_1090 = check_196;
													  loop_1091:
													    if (NULLP(check_1090))
													      {
														 aux_2430 = BTRUE;
													      }
													    else
													      {
														 bool_t test_2433;
														 {
														    obj_t aux_2434;
														    aux_2434 = CAR(check_1090);
														    test_2433 = SYMBOLP(aux_2434);
														 }
														 if (test_2433)
														   {
														      {
															 obj_t check_2437;
															 check_2437 = CDR(check_1090);
															 check_1090 = check_2437;
															 goto loop_1091;
														      }
														   }
														 else
														   {
														      {
															 obj_t list1878_1095;
															 list1878_1095 = MAKE_PAIR(BFALSE, BNIL);
															 aux_2430 = user_error_151_tools_error(string1913_module_type, string1914_module_type, clause_20, list1878_1095);
														      }
														   }
													      }
													    test1857_1066 = CBOOL(aux_2430);
													 }
												      }
												      if (test1857_1066)
													{
													   obj_t coerce_1067;
													   {
													      obj_t aux_2443;
													      coerce_1067 = coerce_197;
													    loop_1068:
													      if (NULLP(coerce_1067))
														{
														   aux_2443 = BTRUE;
														}
													      else
														{
														   bool_t test_2446;
														   {
														      obj_t e_5649_8_1077;
														      e_5649_8_1077 = CAR(coerce_1067);
														      if (SYMBOLP(e_5649_8_1077))
															{
															   test_2446 = ((bool_t) 0);
															}
														      else
															{
															   if (PAIRP(e_5649_8_1077))
															     {
																obj_t cdr_5651_165_1080;
																cdr_5651_165_1080 = CDR(e_5649_8_1077);
																{
																   bool_t test_2453;
																   {
																      obj_t aux_2456;
																      obj_t aux_2454;
																      aux_2456 = CNST_TABLE_REF(((long) 1));
																      aux_2454 = CAR(e_5649_8_1077);
																      test_2453 = (aux_2454 == aux_2456);
																   }
																   if (test_2453)
																     {
																	if (PAIRP(cdr_5651_165_1080))
																	  {
																	     obj_t car_5652_103_1083;
																	     car_5652_103_1083 = CAR(cdr_5651_165_1080);
																	     if (PAIRP(car_5652_103_1083))
																	       {
																		  bool_t test_2464;
																		  {
																		     obj_t aux_2465;
																		     aux_2465 = CDR(car_5652_103_1083);
																		     test_2464 = (aux_2465 == BNIL);
																		  }
																		  if (test_2464)
																		    {
																		       test_2446 = ((bool_t) 0);
																		    }
																		  else
																		    {
																		       test_2446 = ((bool_t) 1);
																		    }
																	       }
																	     else
																	       {
																		  test_2446 = ((bool_t) 1);
																	       }
																	  }
																	else
																	  {
																	     test_2446 = ((bool_t) 1);
																	  }
																     }
																   else
																     {
																	test_2446 = ((bool_t) 1);
																     }
																}
															     }
															   else
															     {
																test_2446 = ((bool_t) 1);
															     }
															}
														   }
														   if (test_2446)
														     {
															{
															   obj_t list1860_1071;
															   list1860_1071 = MAKE_PAIR(BFALSE, BNIL);
															   aux_2443 = user_error_151_tools_error(string1913_module_type, string1914_module_type, clause_20, list1860_1071);
															}
														     }
														   else
														     {
															{
															   obj_t coerce_2470;
															   coerce_2470 = CDR(coerce_1067);
															   coerce_1067 = coerce_2470;
															   goto loop_1068;
															}
														     }
														}
													      test1840_1051 = CBOOL(aux_2443);
													   }
													}
												      else
													{
													   test1840_1051 = ((bool_t) 0);
													}
												   }
												   if (test1840_1051)
												     {
													type_t tfrom_1052;
													type_t tto_1053;
													tfrom_1052 = use_type__231_type_env(from_194);
													tto_1053 = use_type__231_type_env(to_195);
													{
													   bool_t test1841_1054;
													   test1841_1054 = is_a__118___object((obj_t) (tfrom_1052), type_type_type);
													   if (test1841_1054)
													     {
														bool_t test1842_1055;
														test1842_1055 = is_a__118___object((obj_t) (tto_1053), type_type_type);
														if (test1842_1055)
														  {
														     return add_coercion__50_type_coercion(tfrom_1052, tto_1053, check_196, coerce_197);
														  }
														else
														  {
														     {
															obj_t list1849_1059;
															list1849_1059 = MAKE_PAIR(BNIL, BNIL);
															return user_error_151_tools_error(string1915_module_type, string1916_module_type, to_195, list1849_1059);
														     }
														  }
													     }
													   else
													     {
														{
														   obj_t list1854_1064;
														   list1854_1064 = MAKE_PAIR(BNIL, BNIL);
														   return user_error_151_tools_error(string1915_module_type, string1916_module_type, from_194, list1854_1064);
														}
													     }
													}
												     }
												   else
												     {
													return BNIL;
												     }
												}
											     }
											   else
											     {
												goto tag_134_32_199;
											     }
											}
										      else
											{
											   goto tag_134_32_199;
											}
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							  }
						     }
						}
					      else
						{
						   bool_t test_2489;
						   {
						      obj_t aux_2490;
						      aux_2490 = CNST_TABLE_REF(((long) 3));
						      test_2489 = (car_148_109_202 == aux_2490);
						   }
						   if (test_2489)
						     {
							obj_t car_572_136_273;
							obj_t cdr_573_187_274;
							car_572_136_273 = CAR(cdr_149_75_203);
							cdr_573_187_274 = CDR(cdr_149_75_203);
							if (SYMBOLP(car_572_136_273))
							  {
							     obj_t car_581_35_276;
							     obj_t cdr_582_31_277;
							     car_581_35_276 = CAR(cdr_573_187_274);
							     cdr_582_31_277 = CDR(cdr_573_187_274);
							     if (STRINGP(car_581_35_276))
							       {
								  if (PAIRP(cdr_582_31_277))
								    {
								       obj_t car_588_85_280;
								       car_588_85_280 = CAR(cdr_582_31_277);
								       if (SYMBOLP(car_588_85_280))
									 {
									    bool_t test_2506;
									    {
									       obj_t aux_2507;
									       aux_2507 = CDR(cdr_582_31_277);
									       test_2506 = (aux_2507 == BNIL);
									    }
									    if (test_2506)
									      {
										 type_t type_1310;
										 type_1310 = declare_type__118_type_env(car_572_136_273, car_581_35_276, car_588_85_280);
										 ((((type_t) CREF(type_1310))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
										 return (obj_t) (type_1310);
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							bool_t test_2513;
							{
							   obj_t aux_2514;
							   aux_2514 = CNST_TABLE_REF(((long) 4));
							   test_2513 = (car_148_109_202 == aux_2514);
							}
							if (test_2513)
							  {
							     obj_t car_753_18_287;
							     obj_t cdr_754_200_288;
							     car_753_18_287 = CAR(cdr_149_75_203);
							     cdr_754_200_288 = CDR(cdr_149_75_203);
							     if (SYMBOLP(car_753_18_287))
							       {
								  obj_t car_763_131_290;
								  obj_t cdr_764_245_291;
								  car_763_131_290 = CAR(cdr_754_200_288);
								  cdr_764_245_291 = CDR(cdr_754_200_288);
								  if (STRINGP(car_763_131_290))
								    {
								       if (PAIRP(cdr_764_245_291))
									 {
									    obj_t car_770_23_294;
									    car_770_23_294 = CAR(cdr_764_245_291);
									    if (PAIRP(car_770_23_294))
									      {
										 bool_t test_2530;
										 {
										    obj_t aux_2531;
										    aux_2531 = CDR(cdr_764_245_291);
										    test_2530 = (aux_2531 == BNIL);
										 }
										 if (test_2530)
										   {
										      obj_t parent_2536;
										      obj_t name_2535;
										      obj_t child_2534;
										      child_2534 = car_753_18_287;
										      name_2535 = car_763_131_290;
										      parent_2536 = car_770_23_294;
										      parent_189 = parent_2536;
										      name_188 = name_2535;
										      child_187 = child_2534;
										      goto tag_131_18_190;
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     bool_t test_2537;
							     {
								obj_t aux_2538;
								aux_2538 = CNST_TABLE_REF(((long) 6));
								test_2537 = (car_148_109_202 == aux_2538);
							     }
							     if (test_2537)
							       {
								  obj_t car_868_149_301;
								  obj_t cdr_869_96_302;
								  car_868_149_301 = CAR(cdr_149_75_203);
								  cdr_869_96_302 = CDR(cdr_149_75_203);
								  if (SYMBOLP(car_868_149_301))
								    {
								       obj_t car_876_124_304;
								       car_876_124_304 = CAR(cdr_869_96_302);
								       if (PAIRP(car_876_124_304))
									 {
									    obj_t car_879_70_306;
									    car_879_70_306 = CAR(car_876_124_304);
									    if (SYMBOLP(car_879_70_306))
									      {
										 bool_t test_2551;
										 {
										    obj_t aux_2552;
										    aux_2552 = CDR(car_876_124_304);
										    test_2551 = (aux_2552 == BNIL);
										 }
										 if (test_2551)
										   {
										      bool_t test_2555;
										      {
											 obj_t aux_2556;
											 aux_2556 = CDR(cdr_869_96_302);
											 test_2555 = (aux_2556 == BNIL);
										      }
										      if (test_2555)
											{
											   tvec_t aux_2559;
											   id_191 = car_868_149_301;
											   item_type_130_192 = car_879_70_306;
											 tag_132_226_193:
											   {
											      tvec_t tvec_1049;
											      tvec_1049 = declare_tvector_type__101_tvector_tvector(id_191, item_type_130_192, clause_20);
											      {
												 obj_t arg1839_1050;
												 arg1839_1050 = make_tvector_accesses_19_tvector_access(tvec_1049, clause_20);
												 _tvector_accesses__185_module_type = append_2_18___r4_pairs_and_lists_6_3(arg1839_1050, _tvector_accesses__185_module_type);
											      }
											      aux_2559 = tvec_1049;
											   }
											   return (obj_t) (aux_2559);
											}
										      else
											{
											   goto tag_134_32_199;
											}
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  bool_t test_2564;
								  {
								     obj_t aux_2565;
								     aux_2565 = CNST_TABLE_REF(((long) 5));
								     test_2564 = (car_148_109_202 == aux_2565);
								  }
								  if (test_2564)
								    {
								       obj_t car_942_214_316;
								       obj_t cdr_943_244_317;
								       car_942_214_316 = CAR(cdr_149_75_203);
								       cdr_943_244_317 = CDR(cdr_149_75_203);
								       if (SYMBOLP(car_942_214_316))
									 {
									    obj_t car_953_3_319;
									    obj_t cdr_954_202_320;
									    car_953_3_319 = CAR(cdr_943_244_317);
									    cdr_954_202_320 = CDR(cdr_943_244_317);
									    if (SYMBOLP(car_953_3_319))
									      {
										 if (PAIRP(cdr_954_202_320))
										   {
										      obj_t cdr_963_23_323;
										      cdr_963_23_323 = CDR(cdr_954_202_320);
										      if (PAIRP(cdr_963_23_323))
											{
											   bool_t test_2581;
											   {
											      obj_t aux_2582;
											      aux_2582 = CDR(cdr_963_23_323);
											      test_2581 = (aux_2582 == BNIL);
											   }
											   if (test_2581)
											     {
												obj_t coerce_2589;
												obj_t check_2587;
												obj_t to_2586;
												obj_t from_2585;
												from_2585 = car_942_214_316;
												to_2586 = car_953_3_319;
												check_2587 = CAR(cdr_954_202_320);
												coerce_2589 = CAR(cdr_963_23_323);
												coerce_197 = coerce_2589;
												check_196 = check_2587;
												to_195 = to_2586;
												from_194 = from_2585;
												goto tag_133_84_198;
											     }
											   else
											     {
												goto tag_134_32_199;
											     }
											}
										      else
											{
											   goto tag_134_32_199;
											}
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							  }
						     }
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 bool_t test_2591;
					 {
					    obj_t aux_2592;
					    aux_2592 = CNST_TABLE_REF(((long) 3));
					    test_2591 = (car_148_109_202 == aux_2592);
					 }
					 if (test_2591)
					   {
					      obj_t car_1034_197_340;
					      obj_t cdr_1035_107_341;
					      car_1034_197_340 = CAR(cdr_149_75_203);
					      cdr_1035_107_341 = CDR(cdr_149_75_203);
					      if (SYMBOLP(car_1034_197_340))
						{
						   if (PAIRP(cdr_1035_107_341))
						     {
							obj_t car_1042_83_344;
							obj_t cdr_1043_69_345;
							car_1042_83_344 = CAR(cdr_1035_107_341);
							cdr_1043_69_345 = CDR(cdr_1035_107_341);
							if (STRINGP(car_1042_83_344))
							  {
							     if (PAIRP(cdr_1043_69_345))
							       {
								  obj_t car_1047_141_348;
								  car_1047_141_348 = CAR(cdr_1043_69_345);
								  if (SYMBOLP(car_1047_141_348))
								    {
								       bool_t test_2610;
								       {
									  obj_t aux_2611;
									  aux_2611 = CDR(cdr_1043_69_345);
									  test_2610 = (aux_2611 == BNIL);
								       }
								       if (test_2610)
									 {
									    type_t type_1384;
									    type_1384 = declare_type__118_type_env(car_1034_197_340, car_1042_83_344, car_1047_141_348);
									    ((((type_t) CREF(type_1384))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
									    return (obj_t) (type_1384);
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      bool_t test_2617;
					      {
						 obj_t aux_2618;
						 aux_2618 = CNST_TABLE_REF(((long) 4));
						 test_2617 = (car_148_109_202 == aux_2618);
					      }
					      if (test_2617)
						{
						   obj_t car_1238_15_355;
						   obj_t cdr_1239_139_356;
						   car_1238_15_355 = CAR(cdr_149_75_203);
						   cdr_1239_139_356 = CDR(cdr_149_75_203);
						   if (SYMBOLP(car_1238_15_355))
						     {
							if (PAIRP(cdr_1239_139_356))
							  {
							     obj_t car_1247_29_359;
							     obj_t cdr_1248_116_360;
							     car_1247_29_359 = CAR(cdr_1239_139_356);
							     cdr_1248_116_360 = CDR(cdr_1239_139_356);
							     if (STRINGP(car_1247_29_359))
							       {
								  if (PAIRP(cdr_1248_116_360))
								    {
								       obj_t car_1252_243_363;
								       car_1252_243_363 = CAR(cdr_1248_116_360);
								       if (PAIRP(car_1252_243_363))
									 {
									    bool_t test_2636;
									    {
									       obj_t aux_2637;
									       aux_2637 = CDR(cdr_1248_116_360);
									       test_2636 = (aux_2637 == BNIL);
									    }
									    if (test_2636)
									      {
										 obj_t parent_2642;
										 obj_t name_2641;
										 obj_t child_2640;
										 child_2640 = car_1238_15_355;
										 name_2641 = car_1247_29_359;
										 parent_2642 = car_1252_243_363;
										 parent_189 = parent_2642;
										 name_188 = name_2641;
										 child_187 = child_2640;
										 goto tag_131_18_190;
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   bool_t test_2643;
						   {
						      obj_t aux_2644;
						      aux_2644 = CNST_TABLE_REF(((long) 6));
						      test_2643 = (car_148_109_202 == aux_2644);
						   }
						   if (test_2643)
						     {
							obj_t car_1366_188_370;
							obj_t cdr_1367_15_371;
							car_1366_188_370 = CAR(cdr_149_75_203);
							cdr_1367_15_371 = CDR(cdr_149_75_203);
							if (SYMBOLP(car_1366_188_370))
							  {
							     if (PAIRP(cdr_1367_15_371))
							       {
								  obj_t car_1374_112_374;
								  car_1374_112_374 = CAR(cdr_1367_15_371);
								  if (PAIRP(car_1374_112_374))
								    {
								       obj_t car_1377_21_376;
								       car_1377_21_376 = CAR(car_1374_112_374);
								       if (SYMBOLP(car_1377_21_376))
									 {
									    bool_t test_2659;
									    {
									       obj_t aux_2660;
									       aux_2660 = CDR(car_1374_112_374);
									       test_2659 = (aux_2660 == BNIL);
									    }
									    if (test_2659)
									      {
										 bool_t test_2663;
										 {
										    obj_t aux_2664;
										    aux_2664 = CDR(cdr_1367_15_371);
										    test_2663 = (aux_2664 == BNIL);
										 }
										 if (test_2663)
										   {
										      tvec_t aux_2667;
										      {
											 obj_t item_type_130_2669;
											 obj_t id_2668;
											 id_2668 = car_1366_188_370;
											 item_type_130_2669 = car_1377_21_376;
											 item_type_130_192 = item_type_130_2669;
											 id_191 = id_2668;
											 goto tag_132_226_193;
										      }
										      return (obj_t) (aux_2667);
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							bool_t test_2671;
							{
							   obj_t aux_2672;
							   aux_2672 = CNST_TABLE_REF(((long) 5));
							   test_2671 = (car_148_109_202 == aux_2672);
							}
							if (test_2671)
							  {
							     obj_t car_1446_179_386;
							     obj_t cdr_1447_225_387;
							     car_1446_179_386 = CAR(cdr_149_75_203);
							     cdr_1447_225_387 = CDR(cdr_149_75_203);
							     if (SYMBOLP(car_1446_179_386))
							       {
								  if (PAIRP(cdr_1447_225_387))
								    {
								       obj_t car_1456_133_390;
								       obj_t cdr_1457_53_391;
								       car_1456_133_390 = CAR(cdr_1447_225_387);
								       cdr_1457_53_391 = CDR(cdr_1447_225_387);
								       if (SYMBOLP(car_1456_133_390))
									 {
									    if (PAIRP(cdr_1457_53_391))
									      {
										 obj_t cdr_1464_242_394;
										 cdr_1464_242_394 = CDR(cdr_1457_53_391);
										 if (PAIRP(cdr_1464_242_394))
										   {
										      bool_t test_2690;
										      {
											 obj_t aux_2691;
											 aux_2691 = CDR(cdr_1464_242_394);
											 test_2690 = (aux_2691 == BNIL);
										      }
										      if (test_2690)
											{
											   obj_t coerce_2698;
											   obj_t check_2696;
											   obj_t to_2695;
											   obj_t from_2694;
											   from_2694 = car_1446_179_386;
											   to_2695 = car_1456_133_390;
											   check_2696 = CAR(cdr_1457_53_391);
											   coerce_2698 = CAR(cdr_1464_242_394);
											   coerce_197 = coerce_2698;
											   check_196 = check_2696;
											   to_195 = to_2695;
											   from_194 = from_2694;
											   goto tag_133_84_198;
											}
										      else
											{
											   goto tag_134_32_199;
											}
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						}
					   }
				      }
				 }
			       else
				 {
				    bool_t test_2700;
				    {
				       obj_t aux_2701;
				       aux_2701 = CNST_TABLE_REF(((long) 3));
				       test_2700 = (car_148_109_202 == aux_2701);
				    }
				    if (test_2700)
				      {
					 obj_t car_1490_65_411;
					 obj_t cdr_1491_16_412;
					 car_1490_65_411 = CAR(cdr_149_75_203);
					 cdr_1491_16_412 = CDR(cdr_149_75_203);
					 if (SYMBOLP(car_1490_65_411))
					   {
					      if (PAIRP(cdr_1491_16_412))
						{
						   obj_t car_1498_68_415;
						   obj_t cdr_1499_50_416;
						   car_1498_68_415 = CAR(cdr_1491_16_412);
						   cdr_1499_50_416 = CDR(cdr_1491_16_412);
						   if (STRINGP(car_1498_68_415))
						     {
							if (PAIRP(cdr_1499_50_416))
							  {
							     obj_t car_1503_178_419;
							     car_1503_178_419 = CAR(cdr_1499_50_416);
							     if (SYMBOLP(car_1503_178_419))
							       {
								  bool_t test_2719;
								  {
								     obj_t aux_2720;
								     aux_2720 = CDR(cdr_1499_50_416);
								     test_2719 = (aux_2720 == BNIL);
								  }
								  if (test_2719)
								    {
								       type_t type_1461;
								       type_1461 = declare_type__118_type_env(car_1490_65_411, car_1498_68_415, car_1503_178_419);
								       ((((type_t) CREF(type_1461))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								       return (obj_t) (type_1461);
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 bool_t test_2726;
					 {
					    obj_t aux_2727;
					    aux_2727 = CNST_TABLE_REF(((long) 4));
					    test_2726 = (car_148_109_202 == aux_2727);
					 }
					 if (test_2726)
					   {
					      obj_t car_1694_157_426;
					      obj_t cdr_1695_139_427;
					      car_1694_157_426 = CAR(cdr_149_75_203);
					      cdr_1695_139_427 = CDR(cdr_149_75_203);
					      if (SYMBOLP(car_1694_157_426))
						{
						   if (PAIRP(cdr_1695_139_427))
						     {
							obj_t car_1703_74_430;
							obj_t cdr_1704_255_431;
							car_1703_74_430 = CAR(cdr_1695_139_427);
							cdr_1704_255_431 = CDR(cdr_1695_139_427);
							if (STRINGP(car_1703_74_430))
							  {
							     if (PAIRP(cdr_1704_255_431))
							       {
								  obj_t car_1708_242_434;
								  car_1708_242_434 = CAR(cdr_1704_255_431);
								  if (PAIRP(car_1708_242_434))
								    {
								       bool_t test_2745;
								       {
									  obj_t aux_2746;
									  aux_2746 = CDR(cdr_1704_255_431);
									  test_2745 = (aux_2746 == BNIL);
								       }
								       if (test_2745)
									 {
									    obj_t parent_2751;
									    obj_t name_2750;
									    obj_t child_2749;
									    child_2749 = car_1694_157_426;
									    name_2750 = car_1703_74_430;
									    parent_2751 = car_1708_242_434;
									    parent_189 = parent_2751;
									    name_188 = name_2750;
									    child_187 = child_2749;
									    goto tag_131_18_190;
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      bool_t test_2752;
					      {
						 obj_t aux_2753;
						 aux_2753 = CNST_TABLE_REF(((long) 6));
						 test_2752 = (car_148_109_202 == aux_2753);
					      }
					      if (test_2752)
						{
						   obj_t car_1822_34_441;
						   obj_t cdr_1823_61_442;
						   car_1822_34_441 = CAR(cdr_149_75_203);
						   cdr_1823_61_442 = CDR(cdr_149_75_203);
						   if (SYMBOLP(car_1822_34_441))
						     {
							if (PAIRP(cdr_1823_61_442))
							  {
							     obj_t car_1830_234_445;
							     car_1830_234_445 = CAR(cdr_1823_61_442);
							     if (PAIRP(car_1830_234_445))
							       {
								  obj_t car_1833_68_447;
								  car_1833_68_447 = CAR(car_1830_234_445);
								  if (SYMBOLP(car_1833_68_447))
								    {
								       bool_t test_2768;
								       {
									  obj_t aux_2769;
									  aux_2769 = CDR(car_1830_234_445);
									  test_2768 = (aux_2769 == BNIL);
								       }
								       if (test_2768)
									 {
									    bool_t test_2772;
									    {
									       obj_t aux_2773;
									       aux_2773 = CDR(cdr_1823_61_442);
									       test_2772 = (aux_2773 == BNIL);
									    }
									    if (test_2772)
									      {
										 tvec_t aux_2776;
										 {
										    obj_t item_type_130_2778;
										    obj_t id_2777;
										    id_2777 = car_1822_34_441;
										    item_type_130_2778 = car_1833_68_447;
										    item_type_130_192 = item_type_130_2778;
										    id_191 = id_2777;
										    goto tag_132_226_193;
										 }
										 return (obj_t) (aux_2776);
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   bool_t test_2780;
						   {
						      obj_t aux_2781;
						      aux_2781 = CNST_TABLE_REF(((long) 5));
						      test_2780 = (car_148_109_202 == aux_2781);
						   }
						   if (test_2780)
						     {
							obj_t car_1902_192_457;
							obj_t cdr_1903_134_458;
							car_1902_192_457 = CAR(cdr_149_75_203);
							cdr_1903_134_458 = CDR(cdr_149_75_203);
							if (SYMBOLP(car_1902_192_457))
							  {
							     if (PAIRP(cdr_1903_134_458))
							       {
								  obj_t car_1912_208_461;
								  obj_t cdr_1913_24_462;
								  car_1912_208_461 = CAR(cdr_1903_134_458);
								  cdr_1913_24_462 = CDR(cdr_1903_134_458);
								  if (SYMBOLP(car_1912_208_461))
								    {
								       if (PAIRP(cdr_1913_24_462))
									 {
									    obj_t cdr_1920_66_465;
									    cdr_1920_66_465 = CDR(cdr_1913_24_462);
									    if (PAIRP(cdr_1920_66_465))
									      {
										 bool_t test_2799;
										 {
										    obj_t aux_2800;
										    aux_2800 = CDR(cdr_1920_66_465);
										    test_2799 = (aux_2800 == BNIL);
										 }
										 if (test_2799)
										   {
										      obj_t coerce_2807;
										      obj_t check_2805;
										      obj_t to_2804;
										      obj_t from_2803;
										      from_2803 = car_1902_192_457;
										      to_2804 = car_1912_208_461;
										      check_2805 = CAR(cdr_1913_24_462);
										      coerce_2807 = CAR(cdr_1920_66_465);
										      coerce_197 = coerce_2807;
										      check_196 = check_2805;
										      to_195 = to_2804;
										      from_194 = from_2803;
										      goto tag_133_84_198;
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					   }
				      }
				 }
			    }
		       }
		     else
		       {
			  if (SYMBOLP(car_148_109_202))
			    {
			       obj_t car_1950_205_485;
			       obj_t cdr_1951_234_486;
			       car_1950_205_485 = CAR(cdr_149_75_203);
			       cdr_1951_234_486 = CDR(cdr_149_75_203);
			       if (STRINGP(car_1950_205_485))
				 {
				    if (PAIRP(cdr_1951_234_486))
				      {
					 obj_t car_1957_215_489;
					 car_1957_215_489 = CAR(cdr_1951_234_486);
					 if (SYMBOLP(car_1957_215_489))
					   {
					      bool_t test_2820;
					      {
						 obj_t aux_2821;
						 aux_2821 = CDR(cdr_1951_234_486);
						 test_2820 = (aux_2821 == BNIL);
					      }
					      if (test_2820)
						{
						   type_t aux_2824;
						   aux_2824 = declare_type__118_type_env(car_148_109_202, car_1950_205_485, car_1957_215_489);
						   return (obj_t) (aux_2824);
						}
					      else
						{
						   bool_t test_2827;
						   {
						      obj_t aux_2828;
						      aux_2828 = CNST_TABLE_REF(((long) 3));
						      test_2827 = (car_148_109_202 == aux_2828);
						   }
						   if (test_2827)
						     {
							obj_t car_1983_49_494;
							obj_t cdr_1984_1_495;
							car_1983_49_494 = CAR(cdr_149_75_203);
							cdr_1984_1_495 = CDR(cdr_149_75_203);
							if (SYMBOLP(car_1983_49_494))
							  {
							     obj_t car_1992_11_497;
							     obj_t cdr_1993_69_498;
							     car_1992_11_497 = CAR(cdr_1984_1_495);
							     cdr_1993_69_498 = CDR(cdr_1984_1_495);
							     if (STRINGP(car_1992_11_497))
							       {
								  if (PAIRP(cdr_1993_69_498))
								    {
								       obj_t car_1999_108_501;
								       car_1999_108_501 = CAR(cdr_1993_69_498);
								       if (SYMBOLP(car_1999_108_501))
									 {
									    bool_t test_2844;
									    {
									       obj_t aux_2845;
									       aux_2845 = CDR(cdr_1993_69_498);
									       test_2844 = (aux_2845 == BNIL);
									    }
									    if (test_2844)
									      {
										 type_t type_1552;
										 type_1552 = declare_type__118_type_env(car_1983_49_494, car_1992_11_497, car_1999_108_501);
										 ((((type_t) CREF(type_1552))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
										 return (obj_t) (type_1552);
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							bool_t test_2851;
							{
							   obj_t aux_2852;
							   aux_2852 = CNST_TABLE_REF(((long) 4));
							   test_2851 = (car_148_109_202 == aux_2852);
							}
							if (test_2851)
							  {
							     obj_t car_2164_140_508;
							     obj_t cdr_2165_100_509;
							     car_2164_140_508 = CAR(cdr_149_75_203);
							     cdr_2165_100_509 = CDR(cdr_149_75_203);
							     if (SYMBOLP(car_2164_140_508))
							       {
								  obj_t car_2174_104_511;
								  obj_t cdr_2175_194_512;
								  car_2174_104_511 = CAR(cdr_2165_100_509);
								  cdr_2175_194_512 = CDR(cdr_2165_100_509);
								  if (STRINGP(car_2174_104_511))
								    {
								       if (PAIRP(cdr_2175_194_512))
									 {
									    obj_t car_2181_21_515;
									    car_2181_21_515 = CAR(cdr_2175_194_512);
									    if (PAIRP(car_2181_21_515))
									      {
										 bool_t test_2868;
										 {
										    obj_t aux_2869;
										    aux_2869 = CDR(cdr_2175_194_512);
										    test_2868 = (aux_2869 == BNIL);
										 }
										 if (test_2868)
										   {
										      obj_t parent_2874;
										      obj_t name_2873;
										      obj_t child_2872;
										      child_2872 = car_2164_140_508;
										      name_2873 = car_2174_104_511;
										      parent_2874 = car_2181_21_515;
										      parent_189 = parent_2874;
										      name_188 = name_2873;
										      child_187 = child_2872;
										      goto tag_131_18_190;
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     bool_t test_2875;
							     {
								obj_t aux_2876;
								aux_2876 = CNST_TABLE_REF(((long) 5));
								test_2875 = (car_148_109_202 == aux_2876);
							     }
							     if (test_2875)
							       {
								  obj_t car_2292_250_522;
								  obj_t cdr_2293_129_523;
								  car_2292_250_522 = CAR(cdr_149_75_203);
								  cdr_2293_129_523 = CDR(cdr_149_75_203);
								  if (SYMBOLP(car_2292_250_522))
								    {
								       obj_t car_2303_5_525;
								       obj_t cdr_2304_174_526;
								       car_2303_5_525 = CAR(cdr_2293_129_523);
								       cdr_2304_174_526 = CDR(cdr_2293_129_523);
								       if (SYMBOLP(car_2303_5_525))
									 {
									    if (PAIRP(cdr_2304_174_526))
									      {
										 obj_t cdr_2313_216_529;
										 cdr_2313_216_529 = CDR(cdr_2304_174_526);
										 if (PAIRP(cdr_2313_216_529))
										   {
										      bool_t test_2892;
										      {
											 obj_t aux_2893;
											 aux_2893 = CDR(cdr_2313_216_529);
											 test_2892 = (aux_2893 == BNIL);
										      }
										      if (test_2892)
											{
											   obj_t coerce_2900;
											   obj_t check_2898;
											   obj_t to_2897;
											   obj_t from_2896;
											   from_2896 = car_2292_250_522;
											   to_2897 = car_2303_5_525;
											   check_2898 = CAR(cdr_2304_174_526);
											   coerce_2900 = CAR(cdr_2313_216_529);
											   coerce_197 = coerce_2900;
											   check_196 = check_2898;
											   to_195 = to_2897;
											   from_194 = from_2896;
											   goto tag_133_84_198;
											}
										      else
											{
											   goto tag_134_32_199;
											}
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
						     }
						}
					   }
					 else
					   {
					      bool_t test_2902;
					      {
						 obj_t aux_2903;
						 aux_2903 = CNST_TABLE_REF(((long) 3));
						 test_2902 = (car_148_109_202 == aux_2903);
					      }
					      if (test_2902)
						{
						   obj_t car_2341_81_546;
						   obj_t cdr_2342_118_547;
						   car_2341_81_546 = CAR(cdr_149_75_203);
						   cdr_2342_118_547 = CDR(cdr_149_75_203);
						   if (SYMBOLP(car_2341_81_546))
						     {
							obj_t car_2350_168_549;
							obj_t cdr_2351_31_550;
							car_2350_168_549 = CAR(cdr_2342_118_547);
							cdr_2351_31_550 = CDR(cdr_2342_118_547);
							if (STRINGP(car_2350_168_549))
							  {
							     if (PAIRP(cdr_2351_31_550))
							       {
								  obj_t car_2357_46_553;
								  car_2357_46_553 = CAR(cdr_2351_31_550);
								  if (SYMBOLP(car_2357_46_553))
								    {
								       bool_t test_2919;
								       {
									  obj_t aux_2920;
									  aux_2920 = CDR(cdr_2351_31_550);
									  test_2919 = (aux_2920 == BNIL);
								       }
								       if (test_2919)
									 {
									    type_t type_1608;
									    type_1608 = declare_type__118_type_env(car_2341_81_546, car_2350_168_549, car_2357_46_553);
									    ((((type_t) CREF(type_1608))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
									    return (obj_t) (type_1608);
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   bool_t test_2926;
						   {
						      obj_t aux_2927;
						      aux_2927 = CNST_TABLE_REF(((long) 4));
						      test_2926 = (car_148_109_202 == aux_2927);
						   }
						   if (test_2926)
						     {
							obj_t car_2522_17_560;
							obj_t cdr_2523_26_561;
							car_2522_17_560 = CAR(cdr_149_75_203);
							cdr_2523_26_561 = CDR(cdr_149_75_203);
							if (SYMBOLP(car_2522_17_560))
							  {
							     obj_t car_2532_90_563;
							     obj_t cdr_2533_33_564;
							     car_2532_90_563 = CAR(cdr_2523_26_561);
							     cdr_2533_33_564 = CDR(cdr_2523_26_561);
							     if (STRINGP(car_2532_90_563))
							       {
								  if (PAIRP(cdr_2533_33_564))
								    {
								       obj_t car_2539_45_567;
								       car_2539_45_567 = CAR(cdr_2533_33_564);
								       if (PAIRP(car_2539_45_567))
									 {
									    bool_t test_2943;
									    {
									       obj_t aux_2944;
									       aux_2944 = CDR(cdr_2533_33_564);
									       test_2943 = (aux_2944 == BNIL);
									    }
									    if (test_2943)
									      {
										 obj_t parent_2949;
										 obj_t name_2948;
										 obj_t child_2947;
										 child_2947 = car_2522_17_560;
										 name_2948 = car_2532_90_563;
										 parent_2949 = car_2539_45_567;
										 parent_189 = parent_2949;
										 name_188 = name_2948;
										 child_187 = child_2947;
										 goto tag_131_18_190;
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							bool_t test_2950;
							{
							   obj_t aux_2951;
							   aux_2951 = CNST_TABLE_REF(((long) 6));
							   test_2950 = (car_148_109_202 == aux_2951);
							}
							if (test_2950)
							  {
							     obj_t car_2637_104_574;
							     obj_t cdr_2638_64_575;
							     car_2637_104_574 = CAR(cdr_149_75_203);
							     cdr_2638_64_575 = CDR(cdr_149_75_203);
							     if (SYMBOLP(car_2637_104_574))
							       {
								  obj_t car_2645_123_577;
								  car_2645_123_577 = CAR(cdr_2638_64_575);
								  if (PAIRP(car_2645_123_577))
								    {
								       obj_t car_2648_10_579;
								       car_2648_10_579 = CAR(car_2645_123_577);
								       if (SYMBOLP(car_2648_10_579))
									 {
									    bool_t test_2964;
									    {
									       obj_t aux_2965;
									       aux_2965 = CDR(car_2645_123_577);
									       test_2964 = (aux_2965 == BNIL);
									    }
									    if (test_2964)
									      {
										 bool_t test_2968;
										 {
										    obj_t aux_2969;
										    aux_2969 = CDR(cdr_2638_64_575);
										    test_2968 = (aux_2969 == BNIL);
										 }
										 if (test_2968)
										   {
										      tvec_t aux_2972;
										      {
											 obj_t item_type_130_2974;
											 obj_t id_2973;
											 id_2973 = car_2637_104_574;
											 item_type_130_2974 = car_2648_10_579;
											 item_type_130_192 = item_type_130_2974;
											 id_191 = id_2973;
											 goto tag_132_226_193;
										      }
										      return (obj_t) (aux_2972);
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     bool_t test_2976;
							     {
								obj_t aux_2977;
								aux_2977 = CNST_TABLE_REF(((long) 5));
								test_2976 = (car_148_109_202 == aux_2977);
							     }
							     if (test_2976)
							       {
								  obj_t car_2711_73_589;
								  obj_t cdr_2712_171_590;
								  car_2711_73_589 = CAR(cdr_149_75_203);
								  cdr_2712_171_590 = CDR(cdr_149_75_203);
								  if (SYMBOLP(car_2711_73_589))
								    {
								       obj_t car_2722_93_592;
								       obj_t cdr_2723_180_593;
								       car_2722_93_592 = CAR(cdr_2712_171_590);
								       cdr_2723_180_593 = CDR(cdr_2712_171_590);
								       if (SYMBOLP(car_2722_93_592))
									 {
									    if (PAIRP(cdr_2723_180_593))
									      {
										 obj_t cdr_2732_112_596;
										 cdr_2732_112_596 = CDR(cdr_2723_180_593);
										 if (PAIRP(cdr_2732_112_596))
										   {
										      bool_t test_2993;
										      {
											 obj_t aux_2994;
											 aux_2994 = CDR(cdr_2732_112_596);
											 test_2993 = (aux_2994 == BNIL);
										      }
										      if (test_2993)
											{
											   obj_t coerce_3001;
											   obj_t check_2999;
											   obj_t to_2998;
											   obj_t from_2997;
											   from_2997 = car_2711_73_589;
											   to_2998 = car_2722_93_592;
											   check_2999 = CAR(cdr_2723_180_593);
											   coerce_3001 = CAR(cdr_2732_112_596);
											   coerce_197 = coerce_3001;
											   check_196 = check_2999;
											   to_195 = to_2998;
											   from_194 = from_2997;
											   goto tag_133_84_198;
											}
										      else
											{
											   goto tag_134_32_199;
											}
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
						     }
						}
					   }
				      }
				    else
				      {
					 goto tag_134_32_199;
				      }
				 }
			       else
				 {
				    bool_t test_3003;
				    {
				       obj_t aux_3004;
				       aux_3004 = CNST_TABLE_REF(((long) 3));
				       test_3003 = (car_148_109_202 == aux_3004);
				    }
				    if (test_3003)
				      {
					 obj_t car_2803_13_613;
					 obj_t cdr_2804_253_614;
					 car_2803_13_613 = CAR(cdr_149_75_203);
					 cdr_2804_253_614 = CDR(cdr_149_75_203);
					 if (SYMBOLP(car_2803_13_613))
					   {
					      if (PAIRP(cdr_2804_253_614))
						{
						   obj_t car_2811_3_617;
						   obj_t cdr_2812_63_618;
						   car_2811_3_617 = CAR(cdr_2804_253_614);
						   cdr_2812_63_618 = CDR(cdr_2804_253_614);
						   if (STRINGP(car_2811_3_617))
						     {
							if (PAIRP(cdr_2812_63_618))
							  {
							     obj_t car_2816_159_621;
							     car_2816_159_621 = CAR(cdr_2812_63_618);
							     if (SYMBOLP(car_2816_159_621))
							       {
								  bool_t test_3022;
								  {
								     obj_t aux_3023;
								     aux_3023 = CDR(cdr_2812_63_618);
								     test_3022 = (aux_3023 == BNIL);
								  }
								  if (test_3022)
								    {
								       type_t type_1682;
								       type_1682 = declare_type__118_type_env(car_2803_13_613, car_2811_3_617, car_2816_159_621);
								       ((((type_t) CREF(type_1682))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								       return (obj_t) (type_1682);
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 bool_t test_3029;
					 {
					    obj_t aux_3030;
					    aux_3030 = CNST_TABLE_REF(((long) 4));
					    test_3029 = (car_148_109_202 == aux_3030);
					 }
					 if (test_3029)
					   {
					      obj_t car_3007_226_628;
					      obj_t cdr_3008_123_629;
					      car_3007_226_628 = CAR(cdr_149_75_203);
					      cdr_3008_123_629 = CDR(cdr_149_75_203);
					      if (SYMBOLP(car_3007_226_628))
						{
						   if (PAIRP(cdr_3008_123_629))
						     {
							obj_t car_3016_221_632;
							obj_t cdr_3017_185_633;
							car_3016_221_632 = CAR(cdr_3008_123_629);
							cdr_3017_185_633 = CDR(cdr_3008_123_629);
							if (STRINGP(car_3016_221_632))
							  {
							     if (PAIRP(cdr_3017_185_633))
							       {
								  obj_t car_3021_132_636;
								  car_3021_132_636 = CAR(cdr_3017_185_633);
								  if (PAIRP(car_3021_132_636))
								    {
								       bool_t test_3048;
								       {
									  obj_t aux_3049;
									  aux_3049 = CDR(cdr_3017_185_633);
									  test_3048 = (aux_3049 == BNIL);
								       }
								       if (test_3048)
									 {
									    obj_t parent_3054;
									    obj_t name_3053;
									    obj_t child_3052;
									    child_3052 = car_3007_226_628;
									    name_3053 = car_3016_221_632;
									    parent_3054 = car_3021_132_636;
									    parent_189 = parent_3054;
									    name_188 = name_3053;
									    child_187 = child_3052;
									    goto tag_131_18_190;
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      bool_t test_3055;
					      {
						 obj_t aux_3056;
						 aux_3056 = CNST_TABLE_REF(((long) 6));
						 test_3055 = (car_148_109_202 == aux_3056);
					      }
					      if (test_3055)
						{
						   obj_t car_3135_165_643;
						   obj_t cdr_3136_69_644;
						   car_3135_165_643 = CAR(cdr_149_75_203);
						   cdr_3136_69_644 = CDR(cdr_149_75_203);
						   if (SYMBOLP(car_3135_165_643))
						     {
							if (PAIRP(cdr_3136_69_644))
							  {
							     obj_t car_3143_162_647;
							     car_3143_162_647 = CAR(cdr_3136_69_644);
							     if (PAIRP(car_3143_162_647))
							       {
								  obj_t car_3146_180_649;
								  car_3146_180_649 = CAR(car_3143_162_647);
								  if (SYMBOLP(car_3146_180_649))
								    {
								       bool_t test_3071;
								       {
									  obj_t aux_3072;
									  aux_3072 = CDR(car_3143_162_647);
									  test_3071 = (aux_3072 == BNIL);
								       }
								       if (test_3071)
									 {
									    bool_t test_3075;
									    {
									       obj_t aux_3076;
									       aux_3076 = CDR(cdr_3136_69_644);
									       test_3075 = (aux_3076 == BNIL);
									    }
									    if (test_3075)
									      {
										 tvec_t aux_3079;
										 {
										    obj_t item_type_130_3081;
										    obj_t id_3080;
										    id_3080 = car_3135_165_643;
										    item_type_130_3081 = car_3146_180_649;
										    item_type_130_192 = item_type_130_3081;
										    id_191 = id_3080;
										    goto tag_132_226_193;
										 }
										 return (obj_t) (aux_3079);
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   bool_t test_3083;
						   {
						      obj_t aux_3084;
						      aux_3084 = CNST_TABLE_REF(((long) 5));
						      test_3083 = (car_148_109_202 == aux_3084);
						   }
						   if (test_3083)
						     {
							obj_t car_3215_163_659;
							obj_t cdr_3216_246_660;
							car_3215_163_659 = CAR(cdr_149_75_203);
							cdr_3216_246_660 = CDR(cdr_149_75_203);
							if (SYMBOLP(car_3215_163_659))
							  {
							     if (PAIRP(cdr_3216_246_660))
							       {
								  obj_t car_3225_208_663;
								  obj_t cdr_3226_37_664;
								  car_3225_208_663 = CAR(cdr_3216_246_660);
								  cdr_3226_37_664 = CDR(cdr_3216_246_660);
								  if (SYMBOLP(car_3225_208_663))
								    {
								       if (PAIRP(cdr_3226_37_664))
									 {
									    obj_t cdr_3233_155_667;
									    cdr_3233_155_667 = CDR(cdr_3226_37_664);
									    if (PAIRP(cdr_3233_155_667))
									      {
										 bool_t test_3102;
										 {
										    obj_t aux_3103;
										    aux_3103 = CDR(cdr_3233_155_667);
										    test_3102 = (aux_3103 == BNIL);
										 }
										 if (test_3102)
										   {
										      obj_t coerce_3110;
										      obj_t check_3108;
										      obj_t to_3107;
										      obj_t from_3106;
										      from_3106 = car_3215_163_659;
										      to_3107 = car_3225_208_663;
										      check_3108 = CAR(cdr_3226_37_664);
										      coerce_3110 = CAR(cdr_3233_155_667);
										      coerce_197 = coerce_3110;
										      check_196 = check_3108;
										      to_195 = to_3107;
										      from_194 = from_3106;
										      goto tag_133_84_198;
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					   }
				      }
				 }
			    }
			  else
			    {
			       bool_t test_3112;
			       {
				  obj_t aux_3113;
				  aux_3113 = CNST_TABLE_REF(((long) 3));
				  test_3112 = (car_148_109_202 == aux_3113);
			       }
			       if (test_3112)
				 {
				    obj_t car_3259_193_684;
				    obj_t cdr_3260_203_685;
				    car_3259_193_684 = CAR(cdr_149_75_203);
				    cdr_3260_203_685 = CDR(cdr_149_75_203);
				    if (SYMBOLP(car_3259_193_684))
				      {
					 if (PAIRP(cdr_3260_203_685))
					   {
					      obj_t car_3267_51_688;
					      obj_t cdr_3268_248_689;
					      car_3267_51_688 = CAR(cdr_3260_203_685);
					      cdr_3268_248_689 = CDR(cdr_3260_203_685);
					      if (STRINGP(car_3267_51_688))
						{
						   if (PAIRP(cdr_3268_248_689))
						     {
							obj_t car_3272_100_692;
							car_3272_100_692 = CAR(cdr_3268_248_689);
							if (SYMBOLP(car_3272_100_692))
							  {
							     bool_t test_3131;
							     {
								obj_t aux_3132;
								aux_3132 = CDR(cdr_3268_248_689);
								test_3131 = (aux_3132 == BNIL);
							     }
							     if (test_3131)
							       {
								  type_t type_1759;
								  type_1759 = declare_type__118_type_env(car_3259_193_684, car_3267_51_688, car_3272_100_692);
								  ((((type_t) CREF(type_1759))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								  return (obj_t) (type_1759);
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 goto tag_134_32_199;
				      }
				 }
			       else
				 {
				    bool_t test_3138;
				    {
				       obj_t aux_3139;
				       aux_3139 = CNST_TABLE_REF(((long) 4));
				       test_3138 = (car_148_109_202 == aux_3139);
				    }
				    if (test_3138)
				      {
					 obj_t car_3463_233_699;
					 obj_t cdr_3464_180_700;
					 car_3463_233_699 = CAR(cdr_149_75_203);
					 cdr_3464_180_700 = CDR(cdr_149_75_203);
					 if (SYMBOLP(car_3463_233_699))
					   {
					      if (PAIRP(cdr_3464_180_700))
						{
						   obj_t car_3472_64_703;
						   obj_t cdr_3473_48_704;
						   car_3472_64_703 = CAR(cdr_3464_180_700);
						   cdr_3473_48_704 = CDR(cdr_3464_180_700);
						   if (STRINGP(car_3472_64_703))
						     {
							if (PAIRP(cdr_3473_48_704))
							  {
							     obj_t car_3477_208_707;
							     car_3477_208_707 = CAR(cdr_3473_48_704);
							     if (PAIRP(car_3477_208_707))
							       {
								  bool_t test_3157;
								  {
								     obj_t aux_3158;
								     aux_3158 = CDR(cdr_3473_48_704);
								     test_3157 = (aux_3158 == BNIL);
								  }
								  if (test_3157)
								    {
								       obj_t parent_3163;
								       obj_t name_3162;
								       obj_t child_3161;
								       child_3161 = car_3463_233_699;
								       name_3162 = car_3472_64_703;
								       parent_3163 = car_3477_208_707;
								       parent_189 = parent_3163;
								       name_188 = name_3162;
								       child_187 = child_3161;
								       goto tag_131_18_190;
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 bool_t test_3164;
					 {
					    obj_t aux_3165;
					    aux_3165 = CNST_TABLE_REF(((long) 6));
					    test_3164 = (car_148_109_202 == aux_3165);
					 }
					 if (test_3164)
					   {
					      obj_t car_3591_225_714;
					      obj_t cdr_3592_87_715;
					      car_3591_225_714 = CAR(cdr_149_75_203);
					      cdr_3592_87_715 = CDR(cdr_149_75_203);
					      if (SYMBOLP(car_3591_225_714))
						{
						   if (PAIRP(cdr_3592_87_715))
						     {
							obj_t car_3599_81_718;
							car_3599_81_718 = CAR(cdr_3592_87_715);
							if (PAIRP(car_3599_81_718))
							  {
							     obj_t car_3602_37_720;
							     car_3602_37_720 = CAR(car_3599_81_718);
							     if (SYMBOLP(car_3602_37_720))
							       {
								  bool_t test_3180;
								  {
								     obj_t aux_3181;
								     aux_3181 = CDR(car_3599_81_718);
								     test_3180 = (aux_3181 == BNIL);
								  }
								  if (test_3180)
								    {
								       bool_t test_3184;
								       {
									  obj_t aux_3185;
									  aux_3185 = CDR(cdr_3592_87_715);
									  test_3184 = (aux_3185 == BNIL);
								       }
								       if (test_3184)
									 {
									    tvec_t aux_3188;
									    {
									       obj_t item_type_130_3190;
									       obj_t id_3189;
									       id_3189 = car_3591_225_714;
									       item_type_130_3190 = car_3602_37_720;
									       item_type_130_192 = item_type_130_3190;
									       id_191 = id_3189;
									       goto tag_132_226_193;
									    }
									    return (obj_t) (aux_3188);
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      bool_t test_3192;
					      {
						 obj_t aux_3193;
						 aux_3193 = CNST_TABLE_REF(((long) 5));
						 test_3192 = (car_148_109_202 == aux_3193);
					      }
					      if (test_3192)
						{
						   obj_t car_3671_68_730;
						   obj_t cdr_3672_142_731;
						   car_3671_68_730 = CAR(cdr_149_75_203);
						   cdr_3672_142_731 = CDR(cdr_149_75_203);
						   if (SYMBOLP(car_3671_68_730))
						     {
							if (PAIRP(cdr_3672_142_731))
							  {
							     obj_t car_3681_20_734;
							     obj_t cdr_3682_209_735;
							     car_3681_20_734 = CAR(cdr_3672_142_731);
							     cdr_3682_209_735 = CDR(cdr_3672_142_731);
							     if (SYMBOLP(car_3681_20_734))
							       {
								  if (PAIRP(cdr_3682_209_735))
								    {
								       obj_t cdr_3689_248_738;
								       cdr_3689_248_738 = CDR(cdr_3682_209_735);
								       if (PAIRP(cdr_3689_248_738))
									 {
									    bool_t test_3211;
									    {
									       obj_t aux_3212;
									       aux_3212 = CDR(cdr_3689_248_738);
									       test_3211 = (aux_3212 == BNIL);
									    }
									    if (test_3211)
									      {
										 obj_t coerce_3219;
										 obj_t check_3217;
										 obj_t to_3216;
										 obj_t from_3215;
										 from_3215 = car_3671_68_730;
										 to_3216 = car_3681_20_734;
										 check_3217 = CAR(cdr_3682_209_735);
										 coerce_3219 = CAR(cdr_3689_248_738);
										 coerce_197 = coerce_3219;
										 check_196 = check_3217;
										 to_195 = to_3216;
										 from_194 = from_3215;
										 goto tag_133_84_198;
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
				      }
				 }
			    }
		       }
		  }
		else
		  {
		     goto tag_134_32_199;
		  }
	     }
	   else
	     {
		if (SYMBOLP(car_148_109_202))
		  {
		     if (PAIRP(cdr_149_75_203))
		       {
			  obj_t car_3772_38_757;
			  obj_t cdr_3773_10_758;
			  car_3772_38_757 = CAR(cdr_149_75_203);
			  cdr_3773_10_758 = CDR(cdr_149_75_203);
			  if (STRINGP(car_3772_38_757))
			    {
			       if (PAIRP(cdr_3773_10_758))
				 {
				    obj_t car_3777_135_761;
				    car_3777_135_761 = CAR(cdr_3773_10_758);
				    if (SYMBOLP(car_3777_135_761))
				      {
					 bool_t test_3234;
					 {
					    obj_t aux_3235;
					    aux_3235 = CDR(cdr_3773_10_758);
					    test_3234 = (aux_3235 == BNIL);
					 }
					 if (test_3234)
					   {
					      type_t aux_3238;
					      aux_3238 = declare_type__118_type_env(car_148_109_202, car_3772_38_757, car_3777_135_761);
					      return (obj_t) (aux_3238);
					   }
					 else
					   {
					      bool_t test_3241;
					      {
						 obj_t aux_3242;
						 aux_3242 = CNST_TABLE_REF(((long) 3));
						 test_3241 = (car_148_109_202 == aux_3242);
					      }
					      if (test_3241)
						{
						   obj_t car_3803_152_766;
						   obj_t cdr_3804_230_767;
						   car_3803_152_766 = CAR(cdr_149_75_203);
						   cdr_3804_230_767 = CDR(cdr_149_75_203);
						   if (SYMBOLP(car_3803_152_766))
						     {
							obj_t car_3812_8_769;
							obj_t cdr_3813_224_770;
							car_3812_8_769 = CAR(cdr_3804_230_767);
							cdr_3813_224_770 = CDR(cdr_3804_230_767);
							if (STRINGP(car_3812_8_769))
							  {
							     if (PAIRP(cdr_3813_224_770))
							       {
								  obj_t car_3819_195_773;
								  car_3819_195_773 = CAR(cdr_3813_224_770);
								  if (SYMBOLP(car_3819_195_773))
								    {
								       bool_t test_3258;
								       {
									  obj_t aux_3259;
									  aux_3259 = CDR(cdr_3813_224_770);
									  test_3258 = (aux_3259 == BNIL);
								       }
								       if (test_3258)
									 {
									    type_t type_1851;
									    type_1851 = declare_type__118_type_env(car_3803_152_766, car_3812_8_769, car_3819_195_773);
									    ((((type_t) CREF(type_1851))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
									    return (obj_t) (type_1851);
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   bool_t test_3265;
						   {
						      obj_t aux_3266;
						      aux_3266 = CNST_TABLE_REF(((long) 4));
						      test_3265 = (car_148_109_202 == aux_3266);
						   }
						   if (test_3265)
						     {
							obj_t car_3984_34_780;
							obj_t cdr_3985_91_781;
							car_3984_34_780 = CAR(cdr_149_75_203);
							cdr_3985_91_781 = CDR(cdr_149_75_203);
							if (SYMBOLP(car_3984_34_780))
							  {
							     obj_t car_3994_227_783;
							     obj_t cdr_3995_241_784;
							     car_3994_227_783 = CAR(cdr_3985_91_781);
							     cdr_3995_241_784 = CDR(cdr_3985_91_781);
							     if (STRINGP(car_3994_227_783))
							       {
								  if (PAIRP(cdr_3995_241_784))
								    {
								       obj_t car_4001_159_787;
								       car_4001_159_787 = CAR(cdr_3995_241_784);
								       if (PAIRP(car_4001_159_787))
									 {
									    bool_t test_3282;
									    {
									       obj_t aux_3283;
									       aux_3283 = CDR(cdr_3995_241_784);
									       test_3282 = (aux_3283 == BNIL);
									    }
									    if (test_3282)
									      {
										 obj_t parent_3288;
										 obj_t name_3287;
										 obj_t child_3286;
										 child_3286 = car_3984_34_780;
										 name_3287 = car_3994_227_783;
										 parent_3288 = car_4001_159_787;
										 parent_189 = parent_3288;
										 name_188 = name_3287;
										 child_187 = child_3286;
										 goto tag_131_18_190;
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							bool_t test_3289;
							{
							   obj_t aux_3290;
							   aux_3290 = CNST_TABLE_REF(((long) 5));
							   test_3289 = (car_148_109_202 == aux_3290);
							}
							if (test_3289)
							  {
							     obj_t car_4112_45_794;
							     obj_t cdr_4113_26_795;
							     car_4112_45_794 = CAR(cdr_149_75_203);
							     cdr_4113_26_795 = CDR(cdr_149_75_203);
							     if (SYMBOLP(car_4112_45_794))
							       {
								  obj_t car_4123_154_797;
								  obj_t cdr_4124_140_798;
								  car_4123_154_797 = CAR(cdr_4113_26_795);
								  cdr_4124_140_798 = CDR(cdr_4113_26_795);
								  if (SYMBOLP(car_4123_154_797))
								    {
								       if (PAIRP(cdr_4124_140_798))
									 {
									    obj_t cdr_4133_211_801;
									    cdr_4133_211_801 = CDR(cdr_4124_140_798);
									    if (PAIRP(cdr_4133_211_801))
									      {
										 bool_t test_3306;
										 {
										    obj_t aux_3307;
										    aux_3307 = CDR(cdr_4133_211_801);
										    test_3306 = (aux_3307 == BNIL);
										 }
										 if (test_3306)
										   {
										      obj_t coerce_3314;
										      obj_t check_3312;
										      obj_t to_3311;
										      obj_t from_3310;
										      from_3310 = car_4112_45_794;
										      to_3311 = car_4123_154_797;
										      check_3312 = CAR(cdr_4124_140_798);
										      coerce_3314 = CAR(cdr_4133_211_801);
										      coerce_197 = coerce_3314;
										      check_196 = check_3312;
										      to_195 = to_3311;
										      from_194 = from_3310;
										      goto tag_133_84_198;
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						}
					   }
				      }
				    else
				      {
					 bool_t test_3316;
					 {
					    obj_t aux_3317;
					    aux_3317 = CNST_TABLE_REF(((long) 3));
					    test_3316 = (car_148_109_202 == aux_3317);
					 }
					 if (test_3316)
					   {
					      obj_t car_4161_240_818;
					      obj_t cdr_4162_122_819;
					      car_4161_240_818 = CAR(cdr_149_75_203);
					      cdr_4162_122_819 = CDR(cdr_149_75_203);
					      if (SYMBOLP(car_4161_240_818))
						{
						   obj_t car_4170_95_821;
						   obj_t cdr_4171_147_822;
						   car_4170_95_821 = CAR(cdr_4162_122_819);
						   cdr_4171_147_822 = CDR(cdr_4162_122_819);
						   if (STRINGP(car_4170_95_821))
						     {
							if (PAIRP(cdr_4171_147_822))
							  {
							     obj_t car_4177_192_825;
							     car_4177_192_825 = CAR(cdr_4171_147_822);
							     if (SYMBOLP(car_4177_192_825))
							       {
								  bool_t test_3333;
								  {
								     obj_t aux_3334;
								     aux_3334 = CDR(cdr_4171_147_822);
								     test_3333 = (aux_3334 == BNIL);
								  }
								  if (test_3333)
								    {
								       type_t type_1907;
								       type_1907 = declare_type__118_type_env(car_4161_240_818, car_4170_95_821, car_4177_192_825);
								       ((((type_t) CREF(type_1907))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								       return (obj_t) (type_1907);
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      bool_t test_3340;
					      {
						 obj_t aux_3341;
						 aux_3341 = CNST_TABLE_REF(((long) 4));
						 test_3340 = (car_148_109_202 == aux_3341);
					      }
					      if (test_3340)
						{
						   obj_t car_4342_227_832;
						   obj_t cdr_4343_177_833;
						   car_4342_227_832 = CAR(cdr_149_75_203);
						   cdr_4343_177_833 = CDR(cdr_149_75_203);
						   if (SYMBOLP(car_4342_227_832))
						     {
							obj_t car_4352_76_835;
							obj_t cdr_4353_78_836;
							car_4352_76_835 = CAR(cdr_4343_177_833);
							cdr_4353_78_836 = CDR(cdr_4343_177_833);
							if (STRINGP(car_4352_76_835))
							  {
							     if (PAIRP(cdr_4353_78_836))
							       {
								  obj_t car_4359_219_839;
								  car_4359_219_839 = CAR(cdr_4353_78_836);
								  if (PAIRP(car_4359_219_839))
								    {
								       bool_t test_3357;
								       {
									  obj_t aux_3358;
									  aux_3358 = CDR(cdr_4353_78_836);
									  test_3357 = (aux_3358 == BNIL);
								       }
								       if (test_3357)
									 {
									    obj_t parent_3363;
									    obj_t name_3362;
									    obj_t child_3361;
									    child_3361 = car_4342_227_832;
									    name_3362 = car_4352_76_835;
									    parent_3363 = car_4359_219_839;
									    parent_189 = parent_3363;
									    name_188 = name_3362;
									    child_187 = child_3361;
									    goto tag_131_18_190;
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   bool_t test_3364;
						   {
						      obj_t aux_3365;
						      aux_3365 = CNST_TABLE_REF(((long) 6));
						      test_3364 = (car_148_109_202 == aux_3365);
						   }
						   if (test_3364)
						     {
							obj_t car_4457_194_846;
							obj_t cdr_4458_51_847;
							car_4457_194_846 = CAR(cdr_149_75_203);
							cdr_4458_51_847 = CDR(cdr_149_75_203);
							if (SYMBOLP(car_4457_194_846))
							  {
							     obj_t car_4465_177_849;
							     car_4465_177_849 = CAR(cdr_4458_51_847);
							     if (PAIRP(car_4465_177_849))
							       {
								  obj_t car_4468_65_851;
								  car_4468_65_851 = CAR(car_4465_177_849);
								  if (SYMBOLP(car_4468_65_851))
								    {
								       bool_t test_3378;
								       {
									  obj_t aux_3379;
									  aux_3379 = CDR(car_4465_177_849);
									  test_3378 = (aux_3379 == BNIL);
								       }
								       if (test_3378)
									 {
									    bool_t test_3382;
									    {
									       obj_t aux_3383;
									       aux_3383 = CDR(cdr_4458_51_847);
									       test_3382 = (aux_3383 == BNIL);
									    }
									    if (test_3382)
									      {
										 tvec_t aux_3386;
										 {
										    obj_t item_type_130_3388;
										    obj_t id_3387;
										    id_3387 = car_4457_194_846;
										    item_type_130_3388 = car_4468_65_851;
										    item_type_130_192 = item_type_130_3388;
										    id_191 = id_3387;
										    goto tag_132_226_193;
										 }
										 return (obj_t) (aux_3386);
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							bool_t test_3390;
							{
							   obj_t aux_3391;
							   aux_3391 = CNST_TABLE_REF(((long) 5));
							   test_3390 = (car_148_109_202 == aux_3391);
							}
							if (test_3390)
							  {
							     obj_t car_4531_207_861;
							     obj_t cdr_4532_145_862;
							     car_4531_207_861 = CAR(cdr_149_75_203);
							     cdr_4532_145_862 = CDR(cdr_149_75_203);
							     if (SYMBOLP(car_4531_207_861))
							       {
								  obj_t car_4542_71_864;
								  obj_t cdr_4543_194_865;
								  car_4542_71_864 = CAR(cdr_4532_145_862);
								  cdr_4543_194_865 = CDR(cdr_4532_145_862);
								  if (SYMBOLP(car_4542_71_864))
								    {
								       if (PAIRP(cdr_4543_194_865))
									 {
									    obj_t cdr_4552_173_868;
									    cdr_4552_173_868 = CDR(cdr_4543_194_865);
									    if (PAIRP(cdr_4552_173_868))
									      {
										 bool_t test_3407;
										 {
										    obj_t aux_3408;
										    aux_3408 = CDR(cdr_4552_173_868);
										    test_3407 = (aux_3408 == BNIL);
										 }
										 if (test_3407)
										   {
										      obj_t coerce_3415;
										      obj_t check_3413;
										      obj_t to_3412;
										      obj_t from_3411;
										      from_3411 = car_4531_207_861;
										      to_3412 = car_4542_71_864;
										      check_3413 = CAR(cdr_4543_194_865);
										      coerce_3415 = CAR(cdr_4552_173_868);
										      coerce_197 = coerce_3415;
										      check_196 = check_3413;
										      to_195 = to_3412;
										      from_194 = from_3411;
										      goto tag_133_84_198;
										   }
										 else
										   {
										      goto tag_134_32_199;
										   }
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						}
					   }
				      }
				 }
			       else
				 {
				    goto tag_134_32_199;
				 }
			    }
			  else
			    {
			       bool_t test_3417;
			       {
				  obj_t aux_3418;
				  aux_3418 = CNST_TABLE_REF(((long) 3));
				  test_3417 = (car_148_109_202 == aux_3418);
			       }
			       if (test_3417)
				 {
				    obj_t car_4623_36_885;
				    obj_t cdr_4624_27_886;
				    car_4623_36_885 = CAR(cdr_149_75_203);
				    cdr_4624_27_886 = CDR(cdr_149_75_203);
				    if (SYMBOLP(car_4623_36_885))
				      {
					 if (PAIRP(cdr_4624_27_886))
					   {
					      obj_t car_4631_182_889;
					      obj_t cdr_4632_100_890;
					      car_4631_182_889 = CAR(cdr_4624_27_886);
					      cdr_4632_100_890 = CDR(cdr_4624_27_886);
					      if (STRINGP(car_4631_182_889))
						{
						   if (PAIRP(cdr_4632_100_890))
						     {
							obj_t car_4636_45_893;
							car_4636_45_893 = CAR(cdr_4632_100_890);
							if (SYMBOLP(car_4636_45_893))
							  {
							     bool_t test_3436;
							     {
								obj_t aux_3437;
								aux_3437 = CDR(cdr_4632_100_890);
								test_3436 = (aux_3437 == BNIL);
							     }
							     if (test_3436)
							       {
								  type_t type_1981;
								  type_1981 = declare_type__118_type_env(car_4623_36_885, car_4631_182_889, car_4636_45_893);
								  ((((type_t) CREF(type_1981))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								  return (obj_t) (type_1981);
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 goto tag_134_32_199;
				      }
				 }
			       else
				 {
				    bool_t test_3443;
				    {
				       obj_t aux_3444;
				       aux_3444 = CNST_TABLE_REF(((long) 4));
				       test_3443 = (car_148_109_202 == aux_3444);
				    }
				    if (test_3443)
				      {
					 obj_t car_4827_6_900;
					 obj_t cdr_4828_253_901;
					 car_4827_6_900 = CAR(cdr_149_75_203);
					 cdr_4828_253_901 = CDR(cdr_149_75_203);
					 if (SYMBOLP(car_4827_6_900))
					   {
					      if (PAIRP(cdr_4828_253_901))
						{
						   obj_t car_4836_165_904;
						   obj_t cdr_4837_106_905;
						   car_4836_165_904 = CAR(cdr_4828_253_901);
						   cdr_4837_106_905 = CDR(cdr_4828_253_901);
						   if (STRINGP(car_4836_165_904))
						     {
							if (PAIRP(cdr_4837_106_905))
							  {
							     obj_t car_4841_161_908;
							     car_4841_161_908 = CAR(cdr_4837_106_905);
							     if (PAIRP(car_4841_161_908))
							       {
								  bool_t test_3462;
								  {
								     obj_t aux_3463;
								     aux_3463 = CDR(cdr_4837_106_905);
								     test_3462 = (aux_3463 == BNIL);
								  }
								  if (test_3462)
								    {
								       obj_t parent_3468;
								       obj_t name_3467;
								       obj_t child_3466;
								       child_3466 = car_4827_6_900;
								       name_3467 = car_4836_165_904;
								       parent_3468 = car_4841_161_908;
								       parent_189 = parent_3468;
								       name_188 = name_3467;
								       child_187 = child_3466;
								       goto tag_131_18_190;
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 bool_t test_3469;
					 {
					    obj_t aux_3470;
					    aux_3470 = CNST_TABLE_REF(((long) 6));
					    test_3469 = (car_148_109_202 == aux_3470);
					 }
					 if (test_3469)
					   {
					      obj_t car_4955_175_915;
					      obj_t cdr_4956_171_916;
					      car_4955_175_915 = CAR(cdr_149_75_203);
					      cdr_4956_171_916 = CDR(cdr_149_75_203);
					      if (SYMBOLP(car_4955_175_915))
						{
						   if (PAIRP(cdr_4956_171_916))
						     {
							obj_t car_4963_194_919;
							car_4963_194_919 = CAR(cdr_4956_171_916);
							if (PAIRP(car_4963_194_919))
							  {
							     obj_t car_4966_105_921;
							     car_4966_105_921 = CAR(car_4963_194_919);
							     if (SYMBOLP(car_4966_105_921))
							       {
								  bool_t test_3485;
								  {
								     obj_t aux_3486;
								     aux_3486 = CDR(car_4963_194_919);
								     test_3485 = (aux_3486 == BNIL);
								  }
								  if (test_3485)
								    {
								       bool_t test_3489;
								       {
									  obj_t aux_3490;
									  aux_3490 = CDR(cdr_4956_171_916);
									  test_3489 = (aux_3490 == BNIL);
								       }
								       if (test_3489)
									 {
									    tvec_t aux_3493;
									    {
									       obj_t item_type_130_3495;
									       obj_t id_3494;
									       id_3494 = car_4955_175_915;
									       item_type_130_3495 = car_4966_105_921;
									       item_type_130_192 = item_type_130_3495;
									       id_191 = id_3494;
									       goto tag_132_226_193;
									    }
									    return (obj_t) (aux_3493);
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      bool_t test_3497;
					      {
						 obj_t aux_3498;
						 aux_3498 = CNST_TABLE_REF(((long) 5));
						 test_3497 = (car_148_109_202 == aux_3498);
					      }
					      if (test_3497)
						{
						   obj_t car_5035_147_931;
						   obj_t cdr_5036_135_932;
						   car_5035_147_931 = CAR(cdr_149_75_203);
						   cdr_5036_135_932 = CDR(cdr_149_75_203);
						   if (SYMBOLP(car_5035_147_931))
						     {
							if (PAIRP(cdr_5036_135_932))
							  {
							     obj_t car_5045_20_935;
							     obj_t cdr_5046_66_936;
							     car_5045_20_935 = CAR(cdr_5036_135_932);
							     cdr_5046_66_936 = CDR(cdr_5036_135_932);
							     if (SYMBOLP(car_5045_20_935))
							       {
								  if (PAIRP(cdr_5046_66_936))
								    {
								       obj_t cdr_5053_25_939;
								       cdr_5053_25_939 = CDR(cdr_5046_66_936);
								       if (PAIRP(cdr_5053_25_939))
									 {
									    bool_t test_3516;
									    {
									       obj_t aux_3517;
									       aux_3517 = CDR(cdr_5053_25_939);
									       test_3516 = (aux_3517 == BNIL);
									    }
									    if (test_3516)
									      {
										 obj_t coerce_3524;
										 obj_t check_3522;
										 obj_t to_3521;
										 obj_t from_3520;
										 from_3520 = car_5035_147_931;
										 to_3521 = car_5045_20_935;
										 check_3522 = CAR(cdr_5046_66_936);
										 coerce_3524 = CAR(cdr_5053_25_939);
										 coerce_197 = coerce_3524;
										 check_196 = check_3522;
										 to_195 = to_3521;
										 from_194 = from_3520;
										 goto tag_133_84_198;
									      }
									    else
									      {
										 goto tag_134_32_199;
									      }
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
				      }
				 }
			    }
		       }
		     else
		       {
			  goto tag_134_32_199;
		       }
		  }
		else
		  {
		     bool_t test_3526;
		     {
			obj_t aux_3527;
			aux_3527 = CNST_TABLE_REF(((long) 3));
			test_3526 = (car_148_109_202 == aux_3527);
		     }
		     if (test_3526)
		       {
			  if (PAIRP(cdr_149_75_203))
			    {
			       obj_t car_5118_113_957;
			       obj_t cdr_5119_101_958;
			       car_5118_113_957 = CAR(cdr_149_75_203);
			       cdr_5119_101_958 = CDR(cdr_149_75_203);
			       if (SYMBOLP(car_5118_113_957))
				 {
				    if (PAIRP(cdr_5119_101_958))
				      {
					 obj_t car_5124_57_961;
					 obj_t cdr_5125_46_962;
					 car_5124_57_961 = CAR(cdr_5119_101_958);
					 cdr_5125_46_962 = CDR(cdr_5119_101_958);
					 if (STRINGP(car_5124_57_961))
					   {
					      if (PAIRP(cdr_5125_46_962))
						{
						   obj_t car_5129_115_965;
						   car_5129_115_965 = CAR(cdr_5125_46_962);
						   if (SYMBOLP(car_5129_115_965))
						     {
							bool_t test_3547;
							{
							   obj_t aux_3548;
							   aux_3548 = CDR(cdr_5125_46_962);
							   test_3547 = (aux_3548 == BNIL);
							}
							if (test_3547)
							  {
							     type_t type_2059;
							     type_2059 = declare_type__118_type_env(car_5118_113_957, car_5124_57_961, car_5129_115_965);
							     ((((type_t) CREF(type_2059))->magic__53) = ((bool_t) ((bool_t) 1)), BUNSPEC);
							     return (obj_t) (type_2059);
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 goto tag_134_32_199;
				      }
				 }
			       else
				 {
				    goto tag_134_32_199;
				 }
			    }
			  else
			    {
			       goto tag_134_32_199;
			    }
		       }
		     else
		       {
			  bool_t test_3554;
			  {
			     obj_t aux_3555;
			     aux_3555 = CNST_TABLE_REF(((long) 4));
			     test_3554 = (car_148_109_202 == aux_3555);
			  }
			  if (test_3554)
			    {
			       if (PAIRP(cdr_149_75_203))
				 {
				    obj_t car_5346_59_973;
				    obj_t cdr_5347_39_974;
				    car_5346_59_973 = CAR(cdr_149_75_203);
				    cdr_5347_39_974 = CDR(cdr_149_75_203);
				    if (SYMBOLP(car_5346_59_973))
				      {
					 if (PAIRP(cdr_5347_39_974))
					   {
					      obj_t car_5353_163_977;
					      obj_t cdr_5354_172_978;
					      car_5353_163_977 = CAR(cdr_5347_39_974);
					      cdr_5354_172_978 = CDR(cdr_5347_39_974);
					      if (STRINGP(car_5353_163_977))
						{
						   if (PAIRP(cdr_5354_172_978))
						     {
							obj_t car_5358_229_981;
							car_5358_229_981 = CAR(cdr_5354_172_978);
							if (PAIRP(car_5358_229_981))
							  {
							     bool_t test_3575;
							     {
								obj_t aux_3576;
								aux_3576 = CDR(cdr_5354_172_978);
								test_3575 = (aux_3576 == BNIL);
							     }
							     if (test_3575)
							       {
								  obj_t parent_3581;
								  obj_t name_3580;
								  obj_t child_3579;
								  child_3579 = car_5346_59_973;
								  name_3580 = car_5353_163_977;
								  parent_3581 = car_5358_229_981;
								  parent_189 = parent_3581;
								  name_188 = name_3580;
								  child_187 = child_3579;
								  goto tag_131_18_190;
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 goto tag_134_32_199;
				      }
				 }
			       else
				 {
				    goto tag_134_32_199;
				 }
			    }
			  else
			    {
			       bool_t test_3582;
			       {
				  obj_t aux_3583;
				  aux_3583 = CNST_TABLE_REF(((long) 6));
				  test_3582 = (car_148_109_202 == aux_3583);
			       }
			       if (test_3582)
				 {
				    if (PAIRP(cdr_149_75_203))
				      {
					 obj_t car_5486_246_989;
					 obj_t cdr_5487_68_990;
					 car_5486_246_989 = CAR(cdr_149_75_203);
					 cdr_5487_68_990 = CDR(cdr_149_75_203);
					 if (SYMBOLP(car_5486_246_989))
					   {
					      if (PAIRP(cdr_5487_68_990))
						{
						   obj_t car_5492_216_993;
						   car_5492_216_993 = CAR(cdr_5487_68_990);
						   if (PAIRP(car_5492_216_993))
						     {
							obj_t car_5495_38_995;
							car_5495_38_995 = CAR(car_5492_216_993);
							if (SYMBOLP(car_5495_38_995))
							  {
							     bool_t test_3600;
							     {
								obj_t aux_3601;
								aux_3601 = CDR(car_5492_216_993);
								test_3600 = (aux_3601 == BNIL);
							     }
							     if (test_3600)
							       {
								  bool_t test_3604;
								  {
								     obj_t aux_3605;
								     aux_3605 = CDR(cdr_5487_68_990);
								     test_3604 = (aux_3605 == BNIL);
								  }
								  if (test_3604)
								    {
								       tvec_t aux_3608;
								       {
									  obj_t item_type_130_3610;
									  obj_t id_3609;
									  id_3609 = car_5486_246_989;
									  item_type_130_3610 = car_5495_38_995;
									  item_type_130_192 = item_type_130_3610;
									  id_191 = id_3609;
									  goto tag_132_226_193;
								       }
								       return (obj_t) (aux_3608);
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 goto tag_134_32_199;
				      }
				 }
			       else
				 {
				    bool_t test_3612;
				    {
				       obj_t aux_3613;
				       aux_3613 = CNST_TABLE_REF(((long) 5));
				       test_3612 = (car_148_109_202 == aux_3613);
				    }
				    if (test_3612)
				      {
					 if (PAIRP(cdr_149_75_203))
					   {
					      obj_t car_5570_219_1006;
					      obj_t cdr_5571_12_1007;
					      car_5570_219_1006 = CAR(cdr_149_75_203);
					      cdr_5571_12_1007 = CDR(cdr_149_75_203);
					      if (SYMBOLP(car_5570_219_1006))
						{
						   if (PAIRP(cdr_5571_12_1007))
						     {
							obj_t car_5578_120_1010;
							obj_t cdr_5579_183_1011;
							car_5578_120_1010 = CAR(cdr_5571_12_1007);
							cdr_5579_183_1011 = CDR(cdr_5571_12_1007);
							if (SYMBOLP(car_5578_120_1010))
							  {
							     if (PAIRP(cdr_5579_183_1011))
							       {
								  obj_t cdr_5586_174_1014;
								  cdr_5586_174_1014 = CDR(cdr_5579_183_1011);
								  if (PAIRP(cdr_5586_174_1014))
								    {
								       bool_t test_3633;
								       {
									  obj_t aux_3634;
									  aux_3634 = CDR(cdr_5586_174_1014);
									  test_3633 = (aux_3634 == BNIL);
								       }
								       if (test_3633)
									 {
									    obj_t coerce_3641;
									    obj_t check_3639;
									    obj_t to_3638;
									    obj_t from_3637;
									    from_3637 = car_5570_219_1006;
									    to_3638 = car_5578_120_1010;
									    check_3639 = CAR(cdr_5579_183_1011);
									    coerce_3641 = CAR(cdr_5586_174_1014);
									    coerce_197 = coerce_3641;
									    check_196 = check_3639;
									    to_195 = to_3638;
									    from_194 = from_3637;
									    goto tag_133_84_198;
									 }
								       else
									 {
									    goto tag_134_32_199;
									 }
								    }
								  else
								    {
								       goto tag_134_32_199;
								    }
							       }
							     else
							       {
								  goto tag_134_32_199;
							       }
							  }
							else
							  {
							     goto tag_134_32_199;
							  }
						     }
						   else
						     {
							goto tag_134_32_199;
						     }
						}
					      else
						{
						   goto tag_134_32_199;
						}
					   }
					 else
					   {
					      goto tag_134_32_199;
					   }
				      }
				    else
				      {
					 goto tag_134_32_199;
				      }
				 }
			    }
		       }
		  }
	     }
	}
      else
	{
	   goto tag_134_32_199;
	}
   }
}


/* _type-parser */ obj_t 
_type_parser_235_module_type(obj_t env_2231, obj_t clause_2232, obj_t clauses_2233)
{
   return type_parser_173_module_type(clause_2232, clauses_2233);
}


/* type-finalizer */ obj_t 
type_finalizer_212_module_type()
{
   {
      obj_t tvf_1103;
      tvf_1103 = tvector_finalizer_246_module_type();
      {
	 bool_t test_3645;
	 if (STRUCTP(tvf_1103))
	   {
	      obj_t aux_3650;
	      obj_t aux_3648;
	      aux_3650 = CNST_TABLE_REF(((long) 7));
	      aux_3648 = STRUCT_KEY(tvf_1103);
	      test_3645 = (aux_3648 == aux_3650);
	   }
	 else
	   {
	      test_3645 = ((bool_t) 0);
	   }
	 if (test_3645)
	   {
	      obj_t list1888_1105;
	      list1888_1105 = MAKE_PAIR(tvf_1103, BNIL);
	      return list1888_1105;
	   }
	 else
	   {
	      return CNST_TABLE_REF(((long) 8));
	   }
      }
   }
}


/* _type-finalizer */ obj_t 
_type_finalizer_85_module_type(obj_t env_2230)
{
   return type_finalizer_212_module_type();
}


/* tvector-finalizer */ obj_t 
tvector_finalizer_246_module_type()
{
   {
      bool_t test1891_1107;
      {
	 obj_t obj_2164;
	 obj_2164 = _tvector_accesses__185_module_type;
	 test1891_1107 = NULLP(obj_2164);
      }
      if (test1891_1107)
	{
	   return CNST_TABLE_REF(((long) 8));
	}
      else
	{
	   obj_t res_1108;
	   {
	      obj_t arg1892_1109;
	      obj_t arg1894_1111;
	      arg1892_1109 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 6)), BEOA);
	      arg1894_1111 = reverse__39___r4_pairs_and_lists_6_3(_tvector_accesses__185_module_type);
	      {
		 obj_t new_2169;
		 {
		    obj_t aux_3663;
		    aux_3663 = CNST_TABLE_REF(((long) 7));
		    new_2169 = create_struct(aux_3663, ((long) 4));
		 }
		 STRUCT_SET(new_2169, ((long) 3), BTRUE);
		 STRUCT_SET(new_2169, ((long) 2), arg1894_1111);
		 {
		    obj_t aux_3668;
		    aux_3668 = BINT(((long) 6));
		    STRUCT_SET(new_2169, ((long) 1), aux_3668);
		 }
		 STRUCT_SET(new_2169, ((long) 0), arg1892_1109);
		 res_1108 = new_2169;
	      }
	   }
	   _tvector_accesses__185_module_type = BNIL;
	   return res_1108;
	}
   }
}


/* _tvector-finalizer */ obj_t 
_tvector_finalizer_32_module_type(obj_t env_2234)
{
   return tvector_finalizer_246_module_type();
}


/* method-init */ obj_t 
method_init_76_module_type()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_type()
{
   module_initialization_70_tools_trace(((long) 0), "MODULE_TYPE");
   module_initialization_70_module_module(((long) 0), "MODULE_TYPE");
   module_initialization_70_type_type(((long) 0), "MODULE_TYPE");
   module_initialization_70_type_env(((long) 0), "MODULE_TYPE");
   module_initialization_70_type_coercion(((long) 0), "MODULE_TYPE");
   module_initialization_70_tvector_tvector(((long) 0), "MODULE_TYPE");
   module_initialization_70_tvector_access(((long) 0), "MODULE_TYPE");
   return module_initialization_70_tools_error(((long) 0), "MODULE_TYPE");
}
