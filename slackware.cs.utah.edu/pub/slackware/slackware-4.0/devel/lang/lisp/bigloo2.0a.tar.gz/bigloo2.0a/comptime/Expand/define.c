/*===========================================================================*/
/*   (Expand/define.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_expand_define();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t leave_function_170_tools_error();
extern obj_t warning___error(obj_t);
extern obj_t fast_id_of_id_130_ast_ident(obj_t);
extern obj_t args___args_list_50_tools_args(obj_t);
extern obj_t expand_set__12_expand_define(obj_t, obj_t);
static obj_t expand_external_define_86_expand_define(obj_t, obj_t);
extern obj_t expand_method_226_expand_define(obj_t, obj_t);
extern type_t get_default_type_181_type_cache();
static obj_t _expand_define1636_92_expand_define(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_expand_define(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_expand_expander(long, char *);
extern obj_t module_initialization_70_expand_eps(long, char *);
extern obj_t module_initialization_70_expand_lambda(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t do_external_define_value_7_expand_define(obj_t, obj_t, obj_t);
extern obj_t internal_begin_expander_196_expand_lambda(obj_t);
static obj_t expand_internal_define_132_expand_define(obj_t, obj_t);
static obj_t imported_modules_init_94_expand_define();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t _expand_method1638_76_expand_define(obj_t, obj_t, obj_t);
extern obj_t normalize_progn_143_tools_progn(obj_t);
static obj_t _expand_inline1639_39_expand_define(obj_t, obj_t, obj_t);
extern obj_t expand_define_110_expand_define(obj_t, obj_t);
static obj_t library_modules_init_112_expand_define();
static obj_t do_inline_generic_method_204_expand_define(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_expand_define();
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t with_lexical_22_expand_eps(obj_t, obj_t, obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
static obj_t arg1630_expand_define(obj_t);
extern obj_t enter_function_81_tools_error(obj_t);
static obj_t arg1583_expand_define(obj_t);
static obj_t arg1558_expand_define(obj_t);
static obj_t arg1525_expand_define(obj_t);
static obj_t arg1487_expand_define(obj_t);
static obj_t arg1370_expand_define(obj_t);
static obj_t arg1332_expand_define(obj_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _expand_generic1640_163_expand_define(obj_t, obj_t, obj_t);
static obj_t _expand_set_1637_186_expand_define(obj_t, obj_t, obj_t);
static obj_t internal_expand_set__71_expand_define(obj_t, obj_t);
extern obj_t expand_inline_145_expand_define(obj_t, obj_t);
extern obj_t _lib_mode__85_engine_param;
static obj_t require_initialization_114_expand_define = BUNSPEC;
extern obj_t expand_generic_229_expand_define(obj_t, obj_t);
static obj_t cnst_init_137_expand_define();
static obj_t do_external_define_lambda_175_expand_define(obj_t, obj_t, obj_t, obj_t);
extern obj_t internal_definition__7_expand_lambda;
extern obj_t unbind_o_expander__20_expand_expander(obj_t);
extern obj_t find_o_expander_0_expand_expander(obj_t);
static obj_t __cnst[6];

DEFINE_EXPORT_PROCEDURE(expand_set__env_74_expand_define, _expand_set_1637_186_expand_define1656, _expand_set_1637_186_expand_define, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_define_env_128_expand_define, _expand_define1636_92_expand_define1657, _expand_define1636_92_expand_define, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_generic_env_218_expand_define, _expand_generic1640_163_expand_define1658, _expand_generic1640_163_expand_define, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_method_env_222_expand_define, _expand_method1638_76_expand_define1659, _expand_method1638_76_expand_define, 0L, 2);
DEFINE_STRING(string1649_expand_define, string1649_expand_define1660, "EXPANDER @ SET! DEFINE _ LAMBDA ", 32);
DEFINE_STRING(string1648_expand_define, string1648_expand_define1661, "top-level", 9);
DEFINE_STRING(string1647_expand_define, string1647_expand_define1662, "Redefinition of library function -- ", 36);
DEFINE_STRING(string1646_expand_define, string1646_expand_define1663, "Illegal `define-generic' form", 29);
DEFINE_STRING(string1645_expand_define, string1645_expand_define1664, "Illegal `define-inline' form", 28);
DEFINE_STRING(string1644_expand_define, string1644_expand_define1665, "Illegal `define-method' form", 28);
DEFINE_STRING(string1643_expand_define, string1643_expand_define1666, "Illegal `set!' form", 19);
DEFINE_STRING(string1642_expand_define, string1642_expand_define1667, "define", 6);
DEFINE_STRING(string1641_expand_define, string1641_expand_define1668, "Illegal `define' form", 21);
DEFINE_EXPORT_PROCEDURE(expand_inline_env_1_expand_define, _expand_inline1639_39_expand_define1669, _expand_inline1639_39_expand_define, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_expand_define(long checksum_1309, char *from_1310)
{
   if (CBOOL(require_initialization_114_expand_define))
     {
	require_initialization_114_expand_define = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_define();
	cnst_init_137_expand_define();
	imported_modules_init_94_expand_define();
	method_init_76_expand_define();
	toplevel_init_63_expand_define();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_define()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "EXPAND_DEFINE");
   module_initialization_70___error(((long) 0), "EXPAND_DEFINE");
   module_initialization_70___r4_strings_6_7(((long) 0), "EXPAND_DEFINE");
   module_initialization_70___reader(((long) 0), "EXPAND_DEFINE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_DEFINE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_define()
{
   {
      obj_t cnst_port_138_1301;
      cnst_port_138_1301 = open_input_string(string1649_expand_define);
      {
	 long i_1302;
	 i_1302 = ((long) 5);
       loop_1303:
	 {
	    bool_t test1650_1304;
	    test1650_1304 = (i_1302 == ((long) -1));
	    if (test1650_1304)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1652_1305;
		    {
		       obj_t list1653_1306;
		       {
			  obj_t arg1654_1307;
			  arg1654_1307 = BNIL;
			  list1653_1306 = MAKE_PAIR(cnst_port_138_1301, arg1654_1307);
		       }
		       arg1652_1305 = read___reader(list1653_1306);
		    }
		    CNST_TABLE_SET(i_1302, arg1652_1305);
		 }
		 {
		    int aux_1308;
		    {
		       long aux_1330;
		       aux_1330 = (i_1302 - ((long) 1));
		       aux_1308 = (int) (aux_1330);
		    }
		    {
		       long i_1333;
		       i_1333 = (long) (aux_1308);
		       i_1302 = i_1333;
		       goto loop_1303;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_expand_define()
{
   return BUNSPEC;
}


/* expand-define */ obj_t 
expand_define_110_expand_define(obj_t x_11, obj_t e_12)
{
   if (CBOOL(internal_definition__7_expand_lambda))
     {
	return expand_internal_define_132_expand_define(x_11, e_12);
     }
   else
     {
	return expand_external_define_86_expand_define(x_11, e_12);
     }
}


/* _expand-define1636 */ obj_t 
_expand_define1636_92_expand_define(obj_t env_1233, obj_t x_1234, obj_t e_1235)
{
   return expand_define_110_expand_define(x_1234, e_1235);
}


/* expand-external-define */ obj_t 
expand_external_define_86_expand_define(obj_t x_13, obj_t e_14)
{
   internal_definition__7_expand_lambda = BTRUE;
   {
      obj_t res_102;
      {
	 if (PAIRP(x_13))
	   {
	      obj_t cdr_136_29_113;
	      cdr_136_29_113 = CDR(x_13);
	      if (PAIRP(cdr_136_29_113))
		{
		   obj_t car_140_114_115;
		   obj_t cdr_141_172_116;
		   car_140_114_115 = CAR(cdr_136_29_113);
		   cdr_141_172_116 = CDR(cdr_136_29_113);
		   if (PAIRP(car_140_114_115))
		     {
			obj_t car_144_227_118;
			car_144_227_118 = CAR(car_140_114_115);
			if (SYMBOLP(car_144_227_118))
			  {
			     if ((cdr_141_172_116 == BNIL))
			       {
				  obj_t car_160_190_122;
				  obj_t cdr_161_14_123;
				  car_160_190_122 = CAR(cdr_136_29_113);
				  cdr_161_14_123 = CDR(cdr_136_29_113);
				  if (SYMBOLP(car_160_190_122))
				    {
				       if (PAIRP(cdr_161_14_123))
					 {
					    obj_t car_167_57_126;
					    car_167_57_126 = CAR(cdr_161_14_123);
					    if (PAIRP(car_167_57_126))
					      {
						 obj_t cdr_172_161_128;
						 cdr_172_161_128 = CDR(car_167_57_126);
						 {
						    bool_t test_1364;
						    {
						       obj_t aux_1367;
						       obj_t aux_1365;
						       aux_1367 = CNST_TABLE_REF(((long) 0));
						       aux_1365 = CAR(car_167_57_126);
						       test_1364 = (aux_1365 == aux_1367);
						    }
						    if (test_1364)
						      {
							 if (PAIRP(cdr_172_161_128))
							   {
							      obj_t cdr_176_66_131;
							      cdr_176_66_131 = CDR(cdr_172_161_128);
							      if ((cdr_176_66_131 == BNIL))
								{
								   obj_t car_188_169_134;
								   car_188_169_134 = CAR(cdr_136_29_113);
								   if (SYMBOLP(car_188_169_134))
								     {
									res_102 = do_external_define_value_7_expand_define(e_14, car_188_169_134, CDR(cdr_136_29_113));
								     }
								   else
								     {
								      tag_122_225_110:
									FAILURE(BFALSE, string1641_expand_define, x_13);
								     }
								}
							      else
								{
								   bool_t test_1381;
								   {
								      obj_t aux_1382;
								      aux_1382 = CDR(cdr_161_14_123);
								      test_1381 = (aux_1382 == BNIL);
								   }
								   if (test_1381)
								     {
									res_102 = do_external_define_lambda_175_expand_define(e_14, car_160_190_122, CAR(cdr_172_161_128), cdr_176_66_131);
								     }
								   else
								     {
									obj_t car_203_140_140;
									car_203_140_140 = CAR(cdr_136_29_113);
									if (SYMBOLP(car_203_140_140))
									  {
									     res_102 = do_external_define_value_7_expand_define(e_14, car_203_140_140, CDR(cdr_136_29_113));
									  }
									else
									  {
									     goto tag_122_225_110;
									  }
								     }
								}
							   }
							 else
							   {
							      obj_t car_218_157_147;
							      car_218_157_147 = CAR(cdr_136_29_113);
							      if (SYMBOLP(car_218_157_147))
								{
								   res_102 = do_external_define_value_7_expand_define(e_14, car_218_157_147, CDR(cdr_136_29_113));
								}
							      else
								{
								   goto tag_122_225_110;
								}
							   }
						      }
						    else
						      {
							 obj_t car_233_238_151;
							 car_233_238_151 = CAR(cdr_136_29_113);
							 if (SYMBOLP(car_233_238_151))
							   {
							      res_102 = do_external_define_value_7_expand_define(e_14, car_233_238_151, CDR(cdr_136_29_113));
							   }
							 else
							   {
							      goto tag_122_225_110;
							   }
						      }
						 }
					      }
					    else
					      {
						 obj_t car_248_177_157;
						 car_248_177_157 = CAR(cdr_136_29_113);
						 if (SYMBOLP(car_248_177_157))
						   {
						      res_102 = do_external_define_value_7_expand_define(e_14, car_248_177_157, CDR(cdr_136_29_113));
						   }
						 else
						   {
						      goto tag_122_225_110;
						   }
					      }
					 }
				       else
					 {
					    goto tag_122_225_110;
					 }
				    }
				  else
				    {
				       goto tag_122_225_110;
				    }
			       }
			     else
			       {
				  res_102 = do_external_define_lambda_175_expand_define(e_14, car_144_227_118, CDR(car_140_114_115), cdr_141_172_116);
			       }
			  }
			else
			  {
			     obj_t car_271_42_163;
			     obj_t cdr_272_238_164;
			     car_271_42_163 = CAR(cdr_136_29_113);
			     cdr_272_238_164 = CDR(cdr_136_29_113);
			     if (SYMBOLP(car_271_42_163))
			       {
				  if (PAIRP(cdr_272_238_164))
				    {
				       obj_t car_278_106_167;
				       car_278_106_167 = CAR(cdr_272_238_164);
				       if (PAIRP(car_278_106_167))
					 {
					    obj_t cdr_283_240_169;
					    cdr_283_240_169 = CDR(car_278_106_167);
					    {
					       bool_t test_1419;
					       {
						  obj_t aux_1422;
						  obj_t aux_1420;
						  aux_1422 = CNST_TABLE_REF(((long) 0));
						  aux_1420 = CAR(car_278_106_167);
						  test_1419 = (aux_1420 == aux_1422);
					       }
					       if (test_1419)
						 {
						    if (PAIRP(cdr_283_240_169))
						      {
							 obj_t cdr_287_201_172;
							 cdr_287_201_172 = CDR(cdr_283_240_169);
							 if ((cdr_287_201_172 == BNIL))
							   {
							      obj_t car_299_149_175;
							      car_299_149_175 = CAR(cdr_136_29_113);
							      if (SYMBOLP(car_299_149_175))
								{
								   res_102 = do_external_define_value_7_expand_define(e_14, car_299_149_175, CDR(cdr_136_29_113));
								}
							      else
								{
								   goto tag_122_225_110;
								}
							   }
							 else
							   {
							      bool_t test_1435;
							      {
								 obj_t aux_1436;
								 aux_1436 = CDR(cdr_272_238_164);
								 test_1435 = (aux_1436 == BNIL);
							      }
							      if (test_1435)
								{
								   res_102 = do_external_define_lambda_175_expand_define(e_14, car_271_42_163, CAR(cdr_283_240_169), cdr_287_201_172);
								}
							      else
								{
								   obj_t car_314_235_181;
								   car_314_235_181 = CAR(cdr_136_29_113);
								   if (SYMBOLP(car_314_235_181))
								     {
									res_102 = do_external_define_value_7_expand_define(e_14, car_314_235_181, CDR(cdr_136_29_113));
								     }
								   else
								     {
									goto tag_122_225_110;
								     }
								}
							   }
						      }
						    else
						      {
							 obj_t car_329_7_188;
							 car_329_7_188 = CAR(cdr_136_29_113);
							 if (SYMBOLP(car_329_7_188))
							   {
							      res_102 = do_external_define_value_7_expand_define(e_14, car_329_7_188, CDR(cdr_136_29_113));
							   }
							 else
							   {
							      goto tag_122_225_110;
							   }
						      }
						 }
					       else
						 {
						    obj_t car_344_246_192;
						    car_344_246_192 = CAR(cdr_136_29_113);
						    if (SYMBOLP(car_344_246_192))
						      {
							 res_102 = do_external_define_value_7_expand_define(e_14, car_344_246_192, CDR(cdr_136_29_113));
						      }
						    else
						      {
							 goto tag_122_225_110;
						      }
						 }
					    }
					 }
				       else
					 {
					    obj_t car_359_155_198;
					    car_359_155_198 = CAR(cdr_136_29_113);
					    if (SYMBOLP(car_359_155_198))
					      {
						 res_102 = do_external_define_value_7_expand_define(e_14, car_359_155_198, CDR(cdr_136_29_113));
					      }
					    else
					      {
						 goto tag_122_225_110;
					      }
					 }
				    }
				  else
				    {
				       obj_t car_374_148_202;
				       obj_t cdr_375_247_203;
				       car_374_148_202 = CAR(cdr_136_29_113);
				       cdr_375_247_203 = CDR(cdr_136_29_113);
				       if (SYMBOLP(car_374_148_202))
					 {
					    if ((cdr_375_247_203 == BNIL))
					      {
						 goto tag_122_225_110;
					      }
					    else
					      {
						 res_102 = do_external_define_value_7_expand_define(e_14, car_374_148_202, cdr_375_247_203);
					      }
					 }
				       else
					 {
					    goto tag_122_225_110;
					 }
				    }
			       }
			     else
			       {
				  obj_t car_389_243_208;
				  obj_t cdr_390_58_209;
				  car_389_243_208 = CAR(cdr_136_29_113);
				  cdr_390_58_209 = CDR(cdr_136_29_113);
				  if (SYMBOLP(car_389_243_208))
				    {
				       if ((cdr_390_58_209 == BNIL))
					 {
					    goto tag_122_225_110;
					 }
				       else
					 {
					    res_102 = do_external_define_value_7_expand_define(e_14, car_389_243_208, cdr_390_58_209);
					 }
				    }
				  else
				    {
				       goto tag_122_225_110;
				    }
			       }
			  }
		     }
		   else
		     {
			obj_t car_404_54_214;
			obj_t cdr_405_2_215;
			car_404_54_214 = CAR(cdr_136_29_113);
			cdr_405_2_215 = CDR(cdr_136_29_113);
			if (SYMBOLP(car_404_54_214))
			  {
			     if (PAIRP(cdr_405_2_215))
			       {
				  obj_t car_411_240_218;
				  car_411_240_218 = CAR(cdr_405_2_215);
				  if (PAIRP(car_411_240_218))
				    {
				       obj_t cdr_416_181_220;
				       cdr_416_181_220 = CDR(car_411_240_218);
				       {
					  bool_t test_1485;
					  {
					     obj_t aux_1488;
					     obj_t aux_1486;
					     aux_1488 = CNST_TABLE_REF(((long) 0));
					     aux_1486 = CAR(car_411_240_218);
					     test_1485 = (aux_1486 == aux_1488);
					  }
					  if (test_1485)
					    {
					       if (PAIRP(cdr_416_181_220))
						 {
						    obj_t cdr_420_191_223;
						    cdr_420_191_223 = CDR(cdr_416_181_220);
						    if ((cdr_420_191_223 == BNIL))
						      {
							 obj_t car_434_225_226;
							 car_434_225_226 = CAR(cdr_136_29_113);
							 if (SYMBOLP(car_434_225_226))
							   {
							      res_102 = do_external_define_value_7_expand_define(e_14, car_434_225_226, CDR(cdr_136_29_113));
							   }
							 else
							   {
							      goto tag_122_225_110;
							   }
						      }
						    else
						      {
							 bool_t test_1501;
							 {
							    obj_t aux_1502;
							    aux_1502 = CDR(cdr_405_2_215);
							    test_1501 = (aux_1502 == BNIL);
							 }
							 if (test_1501)
							   {
							      res_102 = do_external_define_lambda_175_expand_define(e_14, car_404_54_214, CAR(cdr_416_181_220), cdr_420_191_223);
							   }
							 else
							   {
							      obj_t car_453_154_232;
							      car_453_154_232 = CAR(cdr_136_29_113);
							      if (SYMBOLP(car_453_154_232))
								{
								   res_102 = do_external_define_value_7_expand_define(e_14, car_453_154_232, CDR(cdr_136_29_113));
								}
							      else
								{
								   goto tag_122_225_110;
								}
							   }
						      }
						 }
					       else
						 {
						    obj_t car_472_165_239;
						    car_472_165_239 = CAR(cdr_136_29_113);
						    if (SYMBOLP(car_472_165_239))
						      {
							 res_102 = do_external_define_value_7_expand_define(e_14, car_472_165_239, CDR(cdr_136_29_113));
						      }
						    else
						      {
							 goto tag_122_225_110;
						      }
						 }
					    }
					  else
					    {
					       obj_t car_491_73_243;
					       car_491_73_243 = CAR(cdr_136_29_113);
					       if (SYMBOLP(car_491_73_243))
						 {
						    res_102 = do_external_define_value_7_expand_define(e_14, car_491_73_243, CDR(cdr_136_29_113));
						 }
					       else
						 {
						    goto tag_122_225_110;
						 }
					    }
				       }
				    }
				  else
				    {
				       obj_t car_510_26_249;
				       car_510_26_249 = CAR(cdr_136_29_113);
				       if (SYMBOLP(car_510_26_249))
					 {
					    res_102 = do_external_define_value_7_expand_define(e_14, car_510_26_249, CDR(cdr_136_29_113));
					 }
				       else
					 {
					    goto tag_122_225_110;
					 }
				    }
			       }
			     else
			       {
				  obj_t car_529_176_253;
				  obj_t cdr_530_222_254;
				  car_529_176_253 = CAR(cdr_136_29_113);
				  cdr_530_222_254 = CDR(cdr_136_29_113);
				  if (SYMBOLP(car_529_176_253))
				    {
				       if ((cdr_530_222_254 == BNIL))
					 {
					    goto tag_122_225_110;
					 }
				       else
					 {
					    res_102 = do_external_define_value_7_expand_define(e_14, car_529_176_253, cdr_530_222_254);
					 }
				    }
				  else
				    {
				       goto tag_122_225_110;
				    }
			       }
			  }
			else
			  {
			     obj_t car_546_199_259;
			     obj_t cdr_547_94_260;
			     car_546_199_259 = CAR(cdr_136_29_113);
			     cdr_547_94_260 = CDR(cdr_136_29_113);
			     if (SYMBOLP(car_546_199_259))
			       {
				  if ((cdr_547_94_260 == BNIL))
				    {
				       goto tag_122_225_110;
				    }
				  else
				    {
				       res_102 = do_external_define_value_7_expand_define(e_14, car_546_199_259, cdr_547_94_260);
				    }
			       }
			     else
			       {
				  goto tag_122_225_110;
			       }
			  }
		     }
		}
	      else
		{
		   goto tag_122_225_110;
		}
	   }
	 else
	   {
	      goto tag_122_225_110;
	   }
      }
      internal_definition__7_expand_lambda = BFALSE;
      return replace__160_tools_misc(x_13, res_102);
   }
}


/* expand-internal-define */ obj_t 
expand_internal_define_132_expand_define(obj_t x_15, obj_t e_16)
{
   {
      obj_t e_264;
      e_264 = internal_begin_expander_196_expand_lambda(e_16);
      {
	 obj_t name_275;
	 obj_t value_276;
	 obj_t name_269;
	 obj_t value_270;
	 obj_t lam_271;
	 obj_t args_272;
	 obj_t body_273;
	 obj_t name_265;
	 obj_t args_266;
	 obj_t body_267;
	 if (PAIRP(x_15))
	   {
	      obj_t cdr_581_38_281;
	      cdr_581_38_281 = CDR(x_15);
	      if (PAIRP(cdr_581_38_281))
		{
		   obj_t car_585_252_283;
		   obj_t cdr_586_216_284;
		   car_585_252_283 = CAR(cdr_581_38_281);
		   cdr_586_216_284 = CDR(cdr_581_38_281);
		   if (PAIRP(car_585_252_283))
		     {
			if ((cdr_586_216_284 == BNIL))
			  {
			     obj_t car_612_209_288;
			     obj_t cdr_613_171_289;
			     car_612_209_288 = CAR(cdr_581_38_281);
			     cdr_613_171_289 = CDR(cdr_581_38_281);
			     if (SYMBOLP(car_612_209_288))
			       {
				  if (PAIRP(cdr_613_171_289))
				    {
				       obj_t car_621_252_292;
				       car_621_252_292 = CAR(cdr_613_171_289);
				       if (PAIRP(car_621_252_292))
					 {
					    obj_t cdr_635_119_294;
					    cdr_635_119_294 = CDR(car_621_252_292);
					    if (PAIRP(cdr_635_119_294))
					      {
						 obj_t cdr_640_235_296;
						 cdr_640_235_296 = CDR(cdr_635_119_294);
						 if ((cdr_640_235_296 == BNIL))
						   {
						      obj_t car_652_193_299;
						      car_652_193_299 = CAR(cdr_581_38_281);
						      if (SYMBOLP(car_652_193_299))
							{
							   name_275 = car_652_193_299;
							   value_276 = CDR(cdr_581_38_281);
							 tag_569_3_277:
							   {
							      obj_t arg1416_445;
							      {
								 obj_t arg1417_446;
								 obj_t arg1418_447;
								 arg1417_446 = CNST_TABLE_REF(((long) 2));
								 {
								    obj_t arg1427_453;
								    arg1427_453 = normalize_progn_143_tools_progn(value_276);
								    arg1418_447 = PROCEDURE_ENTRY(e_264) (e_264, arg1427_453, e_264, BEOA);
								 }
								 {
								    obj_t list1420_449;
								    {
								       obj_t arg1421_450;
								       {
									  obj_t arg1423_451;
									  arg1423_451 = MAKE_PAIR(BNIL, BNIL);
									  arg1421_450 = MAKE_PAIR(arg1418_447, arg1423_451);
								       }
								       list1420_449 = MAKE_PAIR(name_275, arg1421_450);
								    }
								    arg1416_445 = cons__138___r4_pairs_and_lists_6_3(arg1417_446, list1420_449);
								 }
							      }
							      return replace__160_tools_misc(x_15, arg1416_445);
							   }
							}
						      else
							{
							 tag_570_126_278:
							   FAILURE(BFALSE, string1641_expand_define, x_15);
							}
						   }
						 else
						   {
						      bool_t test_1583;
						      {
							 obj_t aux_1584;
							 aux_1584 = CDR(cdr_613_171_289);
							 test_1583 = (aux_1584 == BNIL);
						      }
						      if (test_1583)
							{
							   name_269 = car_612_209_288;
							   value_270 = car_621_252_292;
							   lam_271 = CAR(car_621_252_292);
							   args_272 = CAR(cdr_635_119_294);
							   body_273 = cdr_640_235_296;
							 tag_568_61_274:
							   {
							      bool_t test1366_401;
							      {
								 obj_t arg1414_443;
								 obj_t arg1415_444;
								 arg1414_443 = fast_id_of_id_130_ast_ident(lam_271);
								 arg1415_444 = CNST_TABLE_REF(((long) 0));
								 test1366_401 = (arg1414_443 == arg1415_444);
							      }
							      if (test1366_401)
								{
								   if (SYMBOLP(name_269))
								     {
									obj_t pid_403;
									pid_403 = parse_id_241_ast_ident(name_269);
									{
									   obj_t name_id_96_404;
									   name_id_96_404 = CAR(pid_403);
									   {
									      obj_t type_405;
									      type_405 = CDR(pid_403);
									      {
										 obj_t type_id_229_406;
										 {
										    type_t obj_1044;
										    obj_1044 = (type_t) (type_405);
										    type_id_229_406 = (((type_t) CREF(obj_1044))->id);
										 }
										 {
										    {
										       obj_t arg1368_407;
										       obj_t arg1369_408;
										       arg1368_407 = args___args_list_50_tools_args(args_272);
										       arg1369_408 = CNST_TABLE_REF(((long) 1));
										       {
											  obj_t arg1370_1236;
											  arg1370_1236 = make_fx_procedure(arg1370_expand_define, ((long) 0), ((long) 7));
											  PROCEDURE_SET(arg1370_1236, ((long) 0), type_405);
											  PROCEDURE_SET(arg1370_1236, ((long) 1), type_id_229_406);
											  PROCEDURE_SET(arg1370_1236, ((long) 2), body_273);
											  PROCEDURE_SET(arg1370_1236, ((long) 3), e_264);
											  PROCEDURE_SET(arg1370_1236, ((long) 4), args_272);
											  PROCEDURE_SET(arg1370_1236, ((long) 5), name_id_96_404);
											  PROCEDURE_SET(arg1370_1236, ((long) 6), x_15);
											  return with_lexical_22_expand_eps(arg1368_407, arg1369_408, arg1370_1236);
										       }
										    }
										 }
									      }
									   }
									}
								     }
								   else
								     {
									FAILURE(string1642_expand_define, string1641_expand_define, x_15);
								     }
								}
							      else
								{
								   obj_t arg1403_435;
								   {
								      obj_t arg1405_436;
								      obj_t arg1407_437;
								      arg1405_436 = CNST_TABLE_REF(((long) 2));
								      arg1407_437 = PROCEDURE_ENTRY(e_264) (e_264, value_270, e_264, BEOA);
								      {
									 obj_t list1409_439;
									 {
									    obj_t arg1410_440;
									    {
									       obj_t arg1411_441;
									       arg1411_441 = MAKE_PAIR(BNIL, BNIL);
									       arg1410_440 = MAKE_PAIR(arg1407_437, arg1411_441);
									    }
									    list1409_439 = MAKE_PAIR(name_269, arg1410_440);
									 }
									 arg1403_435 = cons__138___r4_pairs_and_lists_6_3(arg1405_436, list1409_439);
								      }
								   }
								   return replace__160_tools_misc(x_15, arg1403_435);
								}
							   }
							}
						      else
							{
							   obj_t car_667_44_306;
							   car_667_44_306 = CAR(cdr_581_38_281);
							   if (SYMBOLP(car_667_44_306))
							     {
								obj_t value_1624;
								obj_t name_1623;
								name_1623 = car_667_44_306;
								value_1624 = CDR(cdr_581_38_281);
								value_276 = value_1624;
								name_275 = name_1623;
								goto tag_569_3_277;
							     }
							   else
							     {
								goto tag_570_126_278;
							     }
							}
						   }
					      }
					    else
					      {
						 obj_t car_682_64_313;
						 car_682_64_313 = CAR(cdr_581_38_281);
						 if (SYMBOLP(car_682_64_313))
						   {
						      obj_t value_1630;
						      obj_t name_1629;
						      name_1629 = car_682_64_313;
						      value_1630 = CDR(cdr_581_38_281);
						      value_276 = value_1630;
						      name_275 = name_1629;
						      goto tag_569_3_277;
						   }
						 else
						   {
						      goto tag_570_126_278;
						   }
					      }
					 }
				       else
					 {
					    obj_t car_697_170_317;
					    car_697_170_317 = CAR(cdr_581_38_281);
					    if (SYMBOLP(car_697_170_317))
					      {
						 obj_t value_1636;
						 obj_t name_1635;
						 name_1635 = car_697_170_317;
						 value_1636 = CDR(cdr_581_38_281);
						 value_276 = value_1636;
						 name_275 = name_1635;
						 goto tag_569_3_277;
					      }
					    else
					      {
						 goto tag_570_126_278;
					      }
					 }
				    }
				  else
				    {
				       goto tag_570_126_278;
				    }
			       }
			     else
			       {
				  goto tag_570_126_278;
			       }
			  }
			else
			  {
			     name_265 = CAR(car_585_252_283);
			     args_266 = CDR(car_585_252_283);
			     body_267 = cdr_586_216_284;
			     if (SYMBOLP(name_265))
			       {
				  obj_t pid_369;
				  pid_369 = parse_id_241_ast_ident(name_265);
				  {
				     obj_t name_id_96_370;
				     name_id_96_370 = CAR(pid_369);
				     {
					obj_t type_371;
					type_371 = CDR(pid_369);
					{
					   obj_t type_id_229_372;
					   {
					      type_t obj_1033;
					      obj_1033 = (type_t) (type_371);
					      type_id_229_372 = (((type_t) CREF(obj_1033))->id);
					   }
					   {
					      {
						 obj_t arg1330_373;
						 obj_t arg1331_374;
						 arg1330_373 = args___args_list_50_tools_args(args_266);
						 arg1331_374 = CNST_TABLE_REF(((long) 1));
						 {
						    obj_t arg1332_1237;
						    arg1332_1237 = make_fx_procedure(arg1332_expand_define, ((long) 0), ((long) 7));
						    PROCEDURE_SET(arg1332_1237, ((long) 0), type_371);
						    PROCEDURE_SET(arg1332_1237, ((long) 1), type_id_229_372);
						    PROCEDURE_SET(arg1332_1237, ((long) 2), body_267);
						    PROCEDURE_SET(arg1332_1237, ((long) 3), e_264);
						    PROCEDURE_SET(arg1332_1237, ((long) 4), args_266);
						    PROCEDURE_SET(arg1332_1237, ((long) 5), name_id_96_370);
						    PROCEDURE_SET(arg1332_1237, ((long) 6), x_15);
						    return with_lexical_22_expand_eps(arg1330_373, arg1331_374, arg1332_1237);
						 }
					      }
					   }
					}
				     }
				  }
			       }
			     else
			       {
				  FAILURE(string1642_expand_define, string1641_expand_define, x_15);
			       }
			  }
		     }
		   else
		     {
			obj_t car_729_8_324;
			obj_t cdr_730_175_325;
			car_729_8_324 = CAR(cdr_581_38_281);
			cdr_730_175_325 = CDR(cdr_581_38_281);
			if (SYMBOLP(car_729_8_324))
			  {
			     if (PAIRP(cdr_730_175_325))
			       {
				  obj_t car_738_109_328;
				  car_738_109_328 = CAR(cdr_730_175_325);
				  if (PAIRP(car_738_109_328))
				    {
				       obj_t cdr_752_10_330;
				       cdr_752_10_330 = CDR(car_738_109_328);
				       if (PAIRP(cdr_752_10_330))
					 {
					    obj_t cdr_757_222_332;
					    cdr_757_222_332 = CDR(cdr_752_10_330);
					    if ((cdr_757_222_332 == BNIL))
					      {
						 obj_t car_771_63_335;
						 car_771_63_335 = CAR(cdr_581_38_281);
						 if (SYMBOLP(car_771_63_335))
						   {
						      obj_t value_1678;
						      obj_t name_1677;
						      name_1677 = car_771_63_335;
						      value_1678 = CDR(cdr_581_38_281);
						      value_276 = value_1678;
						      name_275 = name_1677;
						      goto tag_569_3_277;
						   }
						 else
						   {
						      goto tag_570_126_278;
						   }
					      }
					    else
					      {
						 bool_t test_1680;
						 {
						    obj_t aux_1681;
						    aux_1681 = CDR(cdr_730_175_325);
						    test_1680 = (aux_1681 == BNIL);
						 }
						 if (test_1680)
						   {
						      obj_t body_1690;
						      obj_t args_1688;
						      obj_t lam_1686;
						      obj_t value_1685;
						      obj_t name_1684;
						      name_1684 = car_729_8_324;
						      value_1685 = car_738_109_328;
						      lam_1686 = CAR(car_738_109_328);
						      args_1688 = CAR(cdr_752_10_330);
						      body_1690 = cdr_757_222_332;
						      body_273 = body_1690;
						      args_272 = args_1688;
						      lam_271 = lam_1686;
						      value_270 = value_1685;
						      name_269 = name_1684;
						      goto tag_568_61_274;
						   }
						 else
						   {
						      obj_t car_790_221_342;
						      car_790_221_342 = CAR(cdr_581_38_281);
						      if (SYMBOLP(car_790_221_342))
							{
							   obj_t value_1695;
							   obj_t name_1694;
							   name_1694 = car_790_221_342;
							   value_1695 = CDR(cdr_581_38_281);
							   value_276 = value_1695;
							   name_275 = name_1694;
							   goto tag_569_3_277;
							}
						      else
							{
							   goto tag_570_126_278;
							}
						   }
					      }
					 }
				       else
					 {
					    obj_t car_809_137_349;
					    car_809_137_349 = CAR(cdr_581_38_281);
					    if (SYMBOLP(car_809_137_349))
					      {
						 obj_t value_1701;
						 obj_t name_1700;
						 name_1700 = car_809_137_349;
						 value_1701 = CDR(cdr_581_38_281);
						 value_276 = value_1701;
						 name_275 = name_1700;
						 goto tag_569_3_277;
					      }
					    else
					      {
						 goto tag_570_126_278;
					      }
					 }
				    }
				  else
				    {
				       obj_t car_828_216_353;
				       car_828_216_353 = CAR(cdr_581_38_281);
				       if (SYMBOLP(car_828_216_353))
					 {
					    obj_t value_1707;
					    obj_t name_1706;
					    name_1706 = car_828_216_353;
					    value_1707 = CDR(cdr_581_38_281);
					    value_276 = value_1707;
					    name_275 = name_1706;
					    goto tag_569_3_277;
					 }
				       else
					 {
					    goto tag_570_126_278;
					 }
				    }
			       }
			     else
			       {
				  obj_t car_847_71_357;
				  obj_t cdr_848_163_358;
				  car_847_71_357 = CAR(cdr_581_38_281);
				  cdr_848_163_358 = CDR(cdr_581_38_281);
				  if (SYMBOLP(car_847_71_357))
				    {
				       if ((cdr_848_163_358 == BNIL))
					 {
					    goto tag_570_126_278;
					 }
				       else
					 {
					    obj_t value_1716;
					    obj_t name_1715;
					    name_1715 = car_847_71_357;
					    value_1716 = cdr_848_163_358;
					    value_276 = value_1716;
					    name_275 = name_1715;
					    goto tag_569_3_277;
					 }
				    }
				  else
				    {
				       goto tag_570_126_278;
				    }
			       }
			  }
			else
			  {
			     obj_t car_864_184_363;
			     obj_t cdr_865_47_364;
			     car_864_184_363 = CAR(cdr_581_38_281);
			     cdr_865_47_364 = CDR(cdr_581_38_281);
			     if (SYMBOLP(car_864_184_363))
			       {
				  if ((cdr_865_47_364 == BNIL))
				    {
				       goto tag_570_126_278;
				    }
				  else
				    {
				       obj_t value_1724;
				       obj_t name_1723;
				       name_1723 = car_864_184_363;
				       value_1724 = cdr_865_47_364;
				       value_276 = value_1724;
				       name_275 = name_1723;
				       goto tag_569_3_277;
				    }
			       }
			     else
			       {
				  goto tag_570_126_278;
			       }
			  }
		     }
		}
	      else
		{
		   goto tag_570_126_278;
		}
	   }
	 else
	   {
	      goto tag_570_126_278;
	   }
      }
   }
}


/* arg1370 */ obj_t 
arg1370_expand_define(obj_t env_1238)
{
   {
      obj_t type_1239;
      obj_t type_id_229_1240;
      obj_t body_1241;
      obj_t e_1242;
      obj_t args_1243;
      obj_t name_id_96_1244;
      obj_t x_1245;
      type_1239 = PROCEDURE_REF(env_1238, ((long) 0));
      type_id_229_1240 = PROCEDURE_REF(env_1238, ((long) 1));
      body_1241 = PROCEDURE_REF(env_1238, ((long) 2));
      e_1242 = PROCEDURE_REF(env_1238, ((long) 3));
      args_1243 = PROCEDURE_REF(env_1238, ((long) 4));
      name_id_96_1244 = PROCEDURE_REF(env_1238, ((long) 5));
      x_1245 = PROCEDURE_REF(env_1238, ((long) 6));
      {
	 {
	    obj_t arg1372_411;
	    {
	       obj_t arg1373_412;
	       obj_t arg1375_413;
	       arg1373_412 = CNST_TABLE_REF(((long) 2));
	       {
		  obj_t arg1385_419;
		  obj_t arg1387_420;
		  {
		     bool_t test1393_426;
		     {
			type_t arg1401_432;
			arg1401_432 = get_default_type_181_type_cache();
			{
			   obj_t aux_1734;
			   aux_1734 = (obj_t) (arg1401_432);
			   test1393_426 = (type_1239 == aux_1734);
			}
		     }
		     if (test1393_426)
		       {
			  arg1385_419 = CNST_TABLE_REF(((long) 0));
		       }
		     else
		       {
			  obj_t arg1395_427;
			  arg1395_427 = CNST_TABLE_REF(((long) 0));
			  {
			     obj_t list1396_428;
			     {
				obj_t arg1397_429;
				{
				   obj_t arg1398_430;
				   arg1398_430 = MAKE_PAIR(type_id_229_1240, BNIL);
				   arg1397_429 = MAKE_PAIR(_4dots_199_tools_misc, arg1398_430);
				}
				list1396_428 = MAKE_PAIR(arg1395_427, arg1397_429);
			     }
			     arg1385_419 = symbol_append_197___r4_symbols_6_4(list1396_428);
			  }
		       }
		  }
		  {
		     obj_t arg1402_433;
		     arg1402_433 = normalize_progn_143_tools_progn(body_1241);
		     arg1387_420 = PROCEDURE_ENTRY(e_1242) (e_1242, arg1402_433, e_1242, BEOA);
		  }
		  {
		     obj_t list1389_422;
		     {
			obj_t arg1390_423;
			{
			   obj_t arg1391_424;
			   arg1391_424 = MAKE_PAIR(BNIL, BNIL);
			   arg1390_423 = MAKE_PAIR(arg1387_420, arg1391_424);
			}
			list1389_422 = MAKE_PAIR(args_1243, arg1390_423);
		     }
		     arg1375_413 = cons__138___r4_pairs_and_lists_6_3(arg1385_419, list1389_422);
		  }
	       }
	       {
		  obj_t list1379_415;
		  {
		     obj_t arg1381_416;
		     {
			obj_t arg1383_417;
			arg1383_417 = MAKE_PAIR(BNIL, BNIL);
			arg1381_416 = MAKE_PAIR(arg1375_413, arg1383_417);
		     }
		     list1379_415 = MAKE_PAIR(name_id_96_1244, arg1381_416);
		  }
		  arg1372_411 = cons__138___r4_pairs_and_lists_6_3(arg1373_412, list1379_415);
	       }
	    }
	    return replace__160_tools_misc(x_1245, arg1372_411);
	 }
      }
   }
}


/* arg1332 */ obj_t 
arg1332_expand_define(obj_t env_1246)
{
   {
      obj_t type_1247;
      obj_t type_id_229_1248;
      obj_t body_1249;
      obj_t e_1250;
      obj_t args_1251;
      obj_t name_id_96_1252;
      obj_t x_1253;
      type_1247 = PROCEDURE_REF(env_1246, ((long) 0));
      type_id_229_1248 = PROCEDURE_REF(env_1246, ((long) 1));
      body_1249 = PROCEDURE_REF(env_1246, ((long) 2));
      e_1250 = PROCEDURE_REF(env_1246, ((long) 3));
      args_1251 = PROCEDURE_REF(env_1246, ((long) 4));
      name_id_96_1252 = PROCEDURE_REF(env_1246, ((long) 5));
      x_1253 = PROCEDURE_REF(env_1246, ((long) 6));
      {
	 {
	    obj_t arg1334_377;
	    {
	       obj_t arg1337_378;
	       obj_t arg1339_379;
	       arg1337_378 = CNST_TABLE_REF(((long) 2));
	       {
		  obj_t arg1345_385;
		  obj_t arg1347_386;
		  {
		     bool_t test1354_392;
		     {
			type_t arg1364_398;
			arg1364_398 = get_default_type_181_type_cache();
			{
			   obj_t aux_1765;
			   aux_1765 = (obj_t) (arg1364_398);
			   test1354_392 = (type_1247 == aux_1765);
			}
		     }
		     if (test1354_392)
		       {
			  arg1345_385 = CNST_TABLE_REF(((long) 0));
		       }
		     else
		       {
			  obj_t arg1355_393;
			  arg1355_393 = CNST_TABLE_REF(((long) 0));
			  {
			     obj_t list1356_394;
			     {
				obj_t arg1357_395;
				{
				   obj_t arg1361_396;
				   arg1361_396 = MAKE_PAIR(type_id_229_1248, BNIL);
				   arg1357_395 = MAKE_PAIR(_4dots_199_tools_misc, arg1361_396);
				}
				list1356_394 = MAKE_PAIR(arg1355_393, arg1357_395);
			     }
			     arg1345_385 = symbol_append_197___r4_symbols_6_4(list1356_394);
			  }
		       }
		  }
		  {
		     obj_t arg1365_399;
		     arg1365_399 = normalize_progn_143_tools_progn(body_1249);
		     arg1347_386 = PROCEDURE_ENTRY(e_1250) (e_1250, arg1365_399, e_1250, BEOA);
		  }
		  {
		     obj_t list1350_388;
		     {
			obj_t arg1351_389;
			{
			   obj_t arg1352_390;
			   arg1352_390 = MAKE_PAIR(BNIL, BNIL);
			   arg1351_389 = MAKE_PAIR(arg1347_386, arg1352_390);
			}
			list1350_388 = MAKE_PAIR(args_1251, arg1351_389);
		     }
		     arg1339_379 = cons__138___r4_pairs_and_lists_6_3(arg1345_385, list1350_388);
		  }
	       }
	       {
		  obj_t list1341_381;
		  {
		     obj_t arg1342_382;
		     {
			obj_t arg1343_383;
			arg1343_383 = MAKE_PAIR(BNIL, BNIL);
			arg1342_382 = MAKE_PAIR(arg1339_379, arg1343_383);
		     }
		     list1341_381 = MAKE_PAIR(name_id_96_1252, arg1342_382);
		  }
		  arg1334_377 = cons__138___r4_pairs_and_lists_6_3(arg1337_378, list1341_381);
	       }
	    }
	    return replace__160_tools_misc(x_1253, arg1334_377);
	 }
      }
   }
}


/* expand-set! */ obj_t 
expand_set__12_expand_define(obj_t x_17, obj_t e_18)
{
   if (CBOOL(internal_definition__7_expand_lambda))
     {
	return internal_expand_set__71_expand_define(x_17, e_18);
     }
   else
     {
	internal_definition__7_expand_lambda = BTRUE;
	{
	   obj_t res_455;
	   {
	      obj_t arg1428_456;
	      arg1428_456 = internal_begin_expander_196_expand_lambda(e_18);
	      res_455 = internal_expand_set__71_expand_define(x_17, arg1428_456);
	   }
	   internal_definition__7_expand_lambda = BFALSE;
	   return replace__160_tools_misc(x_17, res_455);
	}
     }
}


/* internal-expand-set! */ obj_t 
internal_expand_set__71_expand_define(obj_t x_457, obj_t e_458)
{
   {
      obj_t var_460;
      obj_t value_461;
      obj_t id_463;
      obj_t var_464;
      obj_t value_465;
      if (PAIRP(x_457))
	{
	   obj_t cdr_909_163_470;
	   cdr_909_163_470 = CDR(x_457);
	   if (PAIRP(cdr_909_163_470))
	     {
		obj_t car_912_11_472;
		obj_t cdr_913_98_473;
		car_912_11_472 = CAR(cdr_909_163_470);
		cdr_913_98_473 = CDR(cdr_909_163_470);
		if (SYMBOLP(car_912_11_472))
		  {
		     if (PAIRP(cdr_913_98_473))
		       {
			  bool_t test_1804;
			  {
			     obj_t aux_1805;
			     aux_1805 = CDR(cdr_913_98_473);
			     test_1804 = (aux_1805 == BNIL);
			  }
			  if (test_1804)
			    {
			       var_460 = car_912_11_472;
			       value_461 = CAR(cdr_913_98_473);
			       enter_function_81_tools_error(var_460);
			       {
				  obj_t ev_503;
				  ev_503 = PROCEDURE_ENTRY(e_458) (e_458, value_461, e_458, BEOA);
				  leave_function_170_tools_error();
				  {
				     obj_t arg1460_504;
				     {
					obj_t arg1461_505;
					arg1461_505 = CNST_TABLE_REF(((long) 3));
					{
					   obj_t list1464_507;
					   {
					      obj_t arg1465_508;
					      {
						 obj_t arg1466_509;
						 arg1466_509 = MAKE_PAIR(BNIL, BNIL);
						 arg1465_508 = MAKE_PAIR(ev_503, arg1466_509);
					      }
					      list1464_507 = MAKE_PAIR(var_460, arg1465_508);
					   }
					   arg1460_504 = cons__138___r4_pairs_and_lists_6_3(arg1461_505, list1464_507);
					}
				     }
				     return replace__160_tools_misc(x_457, arg1460_504);
				  }
			       }
			    }
			  else
			    {
			     tag_901_54_467:
			       FAILURE(BFALSE, string1643_expand_define, x_457);
			    }
		       }
		     else
		       {
			  goto tag_901_54_467;
		       }
		  }
		else
		  {
		     obj_t car_947_13_481;
		     obj_t cdr_948_129_482;
		     car_947_13_481 = CAR(cdr_909_163_470);
		     cdr_948_129_482 = CDR(cdr_909_163_470);
		     if (PAIRP(car_947_13_481))
		       {
			  obj_t cdr_954_202_484;
			  cdr_954_202_484 = CDR(car_947_13_481);
			  {
			     bool_t test_1825;
			     {
				obj_t aux_1828;
				obj_t aux_1826;
				aux_1828 = CNST_TABLE_REF(((long) 4));
				aux_1826 = CAR(car_947_13_481);
				test_1825 = (aux_1826 == aux_1828);
			     }
			     if (test_1825)
			       {
				  if (PAIRP(cdr_954_202_484))
				    {
				       obj_t car_956_42_487;
				       obj_t cdr_957_129_488;
				       car_956_42_487 = CAR(cdr_954_202_484);
				       cdr_957_129_488 = CDR(cdr_954_202_484);
				       if (SYMBOLP(car_956_42_487))
					 {
					    if (PAIRP(cdr_957_129_488))
					      {
						 bool_t test_1839;
						 {
						    obj_t aux_1840;
						    aux_1840 = CAR(cdr_957_129_488);
						    test_1839 = SYMBOLP(aux_1840);
						 }
						 if (test_1839)
						   {
						      bool_t test_1843;
						      {
							 obj_t aux_1844;
							 aux_1844 = CDR(cdr_957_129_488);
							 test_1843 = (aux_1844 == BNIL);
						      }
						      if (test_1843)
							{
							   if (PAIRP(cdr_948_129_482))
							     {
								bool_t test_1849;
								{
								   obj_t aux_1850;
								   aux_1850 = CDR(cdr_948_129_482);
								   test_1849 = (aux_1850 == BNIL);
								}
								if (test_1849)
								  {
								     id_463 = car_956_42_487;
								     var_464 = car_947_13_481;
								     value_465 = CAR(cdr_948_129_482);
								     enter_function_81_tools_error(id_463);
								     {
									obj_t ev_511;
									ev_511 = PROCEDURE_ENTRY(e_458) (e_458, value_465, e_458, BEOA);
									leave_function_170_tools_error();
									{
									   obj_t arg1468_512;
									   {
									      obj_t arg1469_513;
									      arg1469_513 = CNST_TABLE_REF(((long) 3));
									      {
										 obj_t list1471_515;
										 {
										    obj_t arg1473_516;
										    {
										       obj_t arg1474_517;
										       arg1474_517 = MAKE_PAIR(BNIL, BNIL);
										       arg1473_516 = MAKE_PAIR(ev_511, arg1474_517);
										    }
										    list1471_515 = MAKE_PAIR(var_464, arg1473_516);
										 }
										 arg1468_512 = cons__138___r4_pairs_and_lists_6_3(arg1469_513, list1471_515);
									      }
									   }
									   return replace__160_tools_misc(x_457, arg1468_512);
									}
								     }
								  }
								else
								  {
								     goto tag_901_54_467;
								  }
							     }
							   else
							     {
								goto tag_901_54_467;
							     }
							}
						      else
							{
							   goto tag_901_54_467;
							}
						   }
						 else
						   {
						      goto tag_901_54_467;
						   }
					      }
					    else
					      {
						 goto tag_901_54_467;
					      }
					 }
				       else
					 {
					    goto tag_901_54_467;
					 }
				    }
				  else
				    {
				       goto tag_901_54_467;
				    }
			       }
			     else
			       {
				  goto tag_901_54_467;
			       }
			  }
		       }
		     else
		       {
			  goto tag_901_54_467;
		       }
		  }
	     }
	   else
	     {
		goto tag_901_54_467;
	     }
	}
      else
	{
	   goto tag_901_54_467;
	}
   }
}


/* _expand-set!1637 */ obj_t 
_expand_set_1637_186_expand_define(obj_t env_1254, obj_t x_1255, obj_t e_1256)
{
   return expand_set__12_expand_define(x_1255, e_1256);
}


/* expand-method */ obj_t 
expand_method_226_expand_define(obj_t x_19, obj_t e_20)
{
   {
      if (PAIRP(x_19))
	{
	   obj_t cdr_991_113_528;
	   cdr_991_113_528 = CDR(x_19);
	   if (PAIRP(cdr_991_113_528))
	     {
		obj_t car_996_121_530;
		obj_t cdr_997_251_531;
		car_996_121_530 = CAR(cdr_991_113_528);
		cdr_997_251_531 = CDR(cdr_991_113_528);
		if (PAIRP(car_996_121_530))
		  {
		     obj_t car_1000_223_533;
		     car_1000_223_533 = CAR(car_996_121_530);
		     if (SYMBOLP(car_1000_223_533))
		       {
			  if ((cdr_997_251_531 == BNIL))
			    {
			     tag_980_190_525:
			       {
				  obj_t arg1490_545;
				  {
				     obj_t list1491_546;
				     list1491_546 = MAKE_PAIR(string1644_expand_define, BNIL);
				     arg1490_545 = string_append_106___r4_strings_6_7(list1491_546);
				  }
				  FAILURE(BFALSE, arg1490_545, x_19);
			       }
			    }
			  else
			    {
			       obj_t arg1481_536;
			       obj_t arg1483_537;
			       arg1481_536 = CAR(x_19);
			       arg1483_537 = CDR(car_996_121_530);
			       {
				  obj_t arg1485_1106;
				  obj_t arg1486_1107;
				  arg1485_1106 = args___args_list_50_tools_args(arg1483_537);
				  arg1486_1107 = CNST_TABLE_REF(((long) 1));
				  {
				     obj_t arg1487_1257;
				     arg1487_1257 = make_fx_procedure(arg1487_expand_define, ((long) 0), ((long) 6));
				     PROCEDURE_SET(arg1487_1257, ((long) 0), arg1481_536);
				     PROCEDURE_SET(arg1487_1257, ((long) 1), e_20);
				     PROCEDURE_SET(arg1487_1257, ((long) 2), car_1000_223_533);
				     PROCEDURE_SET(arg1487_1257, ((long) 3), arg1483_537);
				     PROCEDURE_SET(arg1487_1257, ((long) 4), cdr_997_251_531);
				     PROCEDURE_SET(arg1487_1257, ((long) 5), x_19);
				     return with_lexical_22_expand_eps(arg1485_1106, arg1486_1107, arg1487_1257);
				  }
			       }
			    }
		       }
		     else
		       {
			  goto tag_980_190_525;
		       }
		  }
		else
		  {
		     goto tag_980_190_525;
		  }
	     }
	   else
	     {
		goto tag_980_190_525;
	     }
	}
      else
	{
	   goto tag_980_190_525;
	}
   }
}


/* _expand-method1638 */ obj_t 
_expand_method1638_76_expand_define(obj_t env_1258, obj_t x_1259, obj_t e_1260)
{
   return expand_method_226_expand_define(x_1259, e_1260);
}


/* arg1487 */ obj_t 
arg1487_expand_define(obj_t env_1261)
{
   {
      obj_t kw_1262;
      obj_t e_1263;
      obj_t id_1264;
      obj_t args_1265;
      obj_t body_1266;
      obj_t x_1267;
      kw_1262 = PROCEDURE_REF(env_1261, ((long) 0));
      e_1263 = PROCEDURE_REF(env_1261, ((long) 1));
      id_1264 = PROCEDURE_REF(env_1261, ((long) 2));
      args_1265 = PROCEDURE_REF(env_1261, ((long) 3));
      body_1266 = PROCEDURE_REF(env_1261, ((long) 4));
      x_1267 = PROCEDURE_REF(env_1261, ((long) 5));
      {
	 {
	    obj_t arg1489_1109;
	    arg1489_1109 = do_inline_generic_method_204_expand_define(kw_1262, e_1263, id_1264, id_1264, args_1265, body_1266);
	    return replace__160_tools_misc(x_1267, arg1489_1109);
	 }
      }
   }
}


/* expand-inline */ obj_t 
expand_inline_145_expand_define(obj_t x_21, obj_t e_22)
{
   {
      if (PAIRP(x_21))
	{
	   obj_t cdr_1022_36_558;
	   cdr_1022_36_558 = CDR(x_21);
	   if (PAIRP(cdr_1022_36_558))
	     {
		obj_t car_1028_33_560;
		obj_t cdr_1029_169_561;
		car_1028_33_560 = CAR(cdr_1022_36_558);
		cdr_1029_169_561 = CDR(cdr_1022_36_558);
		if (PAIRP(car_1028_33_560))
		  {
		     obj_t car_1033_56_563;
		     car_1033_56_563 = CAR(car_1028_33_560);
		     {
			obj_t name_564;
			if (SYMBOLP(car_1033_56_563))
			  {
			     name_564 = car_1033_56_563;
			   kap_1040_73_565:
			     if ((cdr_1029_169_561 == BNIL))
			       {
				tag_1009_68_555:
				  {
				     obj_t arg1528_592;
				     {
					obj_t list1529_593;
					list1529_593 = MAKE_PAIR(string1645_expand_define, BNIL);
					arg1528_592 = string_append_106___r4_strings_6_7(list1529_593);
				     }
				     FAILURE(BFALSE, arg1528_592, x_21);
				  }
			       }
			     else
			       {
				  obj_t arg1517_583;
				  obj_t arg1518_584;
				  arg1517_583 = CAR(x_21);
				  arg1518_584 = CDR(car_1028_33_560);
				  {
				     obj_t arg1522_1149;
				     obj_t arg1524_1150;
				     arg1522_1149 = args___args_list_50_tools_args(arg1518_584);
				     arg1524_1150 = CNST_TABLE_REF(((long) 1));
				     {
					obj_t arg1525_1268;
					arg1525_1268 = make_fx_procedure(arg1525_expand_define, ((long) 0), ((long) 7));
					PROCEDURE_SET(arg1525_1268, ((long) 0), arg1517_583);
					PROCEDURE_SET(arg1525_1268, ((long) 1), e_22);
					PROCEDURE_SET(arg1525_1268, ((long) 2), car_1033_56_563);
					PROCEDURE_SET(arg1525_1268, ((long) 3), name_564);
					PROCEDURE_SET(arg1525_1268, ((long) 4), arg1518_584);
					PROCEDURE_SET(arg1525_1268, ((long) 5), cdr_1029_169_561);
					PROCEDURE_SET(arg1525_1268, ((long) 6), x_21);
					return with_lexical_22_expand_eps(arg1522_1149, arg1524_1150, arg1525_1268);
				     }
				  }
			       }
			  }
			else
			  {
			     if (PAIRP(car_1033_56_563))
			       {
				  obj_t cdr_1051_174_568;
				  cdr_1051_174_568 = CDR(car_1033_56_563);
				  {
				     bool_t test_1936;
				     {
					obj_t aux_1939;
					obj_t aux_1937;
					aux_1939 = CNST_TABLE_REF(((long) 4));
					aux_1937 = CAR(car_1033_56_563);
					test_1936 = (aux_1937 == aux_1939);
				     }
				     if (test_1936)
				       {
					  if (PAIRP(cdr_1051_174_568))
					    {
					       obj_t car_1053_234_571;
					       obj_t cdr_1054_1_572;
					       car_1053_234_571 = CAR(cdr_1051_174_568);
					       cdr_1054_1_572 = CDR(cdr_1051_174_568);
					       if (SYMBOLP(car_1053_234_571))
						 {
						    if (PAIRP(cdr_1054_1_572))
						      {
							 bool_t test_1950;
							 {
							    obj_t aux_1951;
							    aux_1951 = CAR(cdr_1054_1_572);
							    test_1950 = SYMBOLP(aux_1951);
							 }
							 if (test_1950)
							   {
							      bool_t test_1954;
							      {
								 obj_t aux_1955;
								 aux_1955 = CDR(cdr_1054_1_572);
								 test_1954 = (aux_1955 == BNIL);
							      }
							      if (test_1954)
								{
								   obj_t name_1958;
								   name_1958 = car_1053_234_571;
								   name_564 = name_1958;
								   goto kap_1040_73_565;
								}
							      else
								{
								   goto tag_1009_68_555;
								}
							   }
							 else
							   {
							      goto tag_1009_68_555;
							   }
						      }
						    else
						      {
							 goto tag_1009_68_555;
						      }
						 }
					       else
						 {
						    goto tag_1009_68_555;
						 }
					    }
					  else
					    {
					       goto tag_1009_68_555;
					    }
				       }
				     else
				       {
					  goto tag_1009_68_555;
				       }
				  }
			       }
			     else
			       {
				  goto tag_1009_68_555;
			       }
			  }
		     }
		  }
		else
		  {
		     goto tag_1009_68_555;
		  }
	     }
	   else
	     {
		goto tag_1009_68_555;
	     }
	}
      else
	{
	   goto tag_1009_68_555;
	}
   }
}


/* _expand-inline1639 */ obj_t 
_expand_inline1639_39_expand_define(obj_t env_1269, obj_t x_1270, obj_t e_1271)
{
   return expand_inline_145_expand_define(x_1270, e_1271);
}


/* arg1525 */ obj_t 
arg1525_expand_define(obj_t env_1272)
{
   {
      obj_t kw_1273;
      obj_t e_1274;
      obj_t id_1275;
      obj_t name_1276;
      obj_t args_1277;
      obj_t body_1278;
      obj_t x_1279;
      kw_1273 = PROCEDURE_REF(env_1272, ((long) 0));
      e_1274 = PROCEDURE_REF(env_1272, ((long) 1));
      id_1275 = PROCEDURE_REF(env_1272, ((long) 2));
      name_1276 = PROCEDURE_REF(env_1272, ((long) 3));
      args_1277 = PROCEDURE_REF(env_1272, ((long) 4));
      body_1278 = PROCEDURE_REF(env_1272, ((long) 5));
      x_1279 = PROCEDURE_REF(env_1272, ((long) 6));
      {
	 {
	    obj_t arg1527_1152;
	    arg1527_1152 = do_inline_generic_method_204_expand_define(kw_1273, e_1274, id_1275, name_1276, args_1277, body_1278);
	    return replace__160_tools_misc(x_1279, arg1527_1152);
	 }
      }
   }
}


/* expand-generic */ obj_t 
expand_generic_229_expand_define(obj_t x_23, obj_t e_24)
{
   {
      if (PAIRP(x_23))
	{
	   obj_t cdr_1074_22_605;
	   cdr_1074_22_605 = CDR(x_23);
	   if (PAIRP(cdr_1074_22_605))
	     {
		obj_t car_1080_56_607;
		car_1080_56_607 = CAR(cdr_1074_22_605);
		if (PAIRP(car_1080_56_607))
		  {
		     obj_t car_1085_107_609;
		     car_1085_107_609 = CAR(car_1080_56_607);
		     {
			obj_t name_610;
			if (SYMBOLP(car_1085_107_609))
			  {
			     name_610 = car_1085_107_609;
			   kap_1092_49_611:
			     {
				obj_t arg1553_628;
				obj_t arg1554_629;
				obj_t arg1555_630;
				arg1553_628 = CAR(x_23);
				arg1554_629 = CDR(car_1080_56_607);
				arg1555_630 = CDR(cdr_1074_22_605);
				{
				   obj_t arg1556_1190;
				   obj_t arg1557_1191;
				   arg1556_1190 = args___args_list_50_tools_args(arg1554_629);
				   arg1557_1191 = CNST_TABLE_REF(((long) 1));
				   {
				      obj_t arg1558_1280;
				      arg1558_1280 = make_fx_procedure(arg1558_expand_define, ((long) 0), ((long) 7));
				      PROCEDURE_SET(arg1558_1280, ((long) 0), arg1553_628);
				      PROCEDURE_SET(arg1558_1280, ((long) 1), e_24);
				      PROCEDURE_SET(arg1558_1280, ((long) 2), car_1085_107_609);
				      PROCEDURE_SET(arg1558_1280, ((long) 3), name_610);
				      PROCEDURE_SET(arg1558_1280, ((long) 4), arg1554_629);
				      PROCEDURE_SET(arg1558_1280, ((long) 5), arg1555_630);
				      PROCEDURE_SET(arg1558_1280, ((long) 6), x_23);
				      return with_lexical_22_expand_eps(arg1556_1190, arg1557_1191, arg1558_1280);
				   }
				}
			     }
			  }
			else
			  {
			     if (PAIRP(car_1085_107_609))
			       {
				  obj_t cdr_1102_80_614;
				  cdr_1102_80_614 = CDR(car_1085_107_609);
				  {
				     bool_t test_1997;
				     {
					obj_t aux_2000;
					obj_t aux_1998;
					aux_2000 = CNST_TABLE_REF(((long) 4));
					aux_1998 = CAR(car_1085_107_609);
					test_1997 = (aux_1998 == aux_2000);
				     }
				     if (test_1997)
				       {
					  if (PAIRP(cdr_1102_80_614))
					    {
					       obj_t car_1104_254_617;
					       obj_t cdr_1105_100_618;
					       car_1104_254_617 = CAR(cdr_1102_80_614);
					       cdr_1105_100_618 = CDR(cdr_1102_80_614);
					       if (SYMBOLP(car_1104_254_617))
						 {
						    if (PAIRP(cdr_1105_100_618))
						      {
							 bool_t test_2011;
							 {
							    obj_t aux_2012;
							    aux_2012 = CAR(cdr_1105_100_618);
							    test_2011 = SYMBOLP(aux_2012);
							 }
							 if (test_2011)
							   {
							      bool_t test_2015;
							      {
								 obj_t aux_2016;
								 aux_2016 = CDR(cdr_1105_100_618);
								 test_2015 = (aux_2016 == BNIL);
							      }
							      if (test_2015)
								{
								   obj_t name_2019;
								   name_2019 = car_1104_254_617;
								   name_610 = name_2019;
								   goto kap_1092_49_611;
								}
							      else
								{
								 tag_1061_10_602:
								   FAILURE(BFALSE, string1646_expand_define, x_23);
								}
							   }
							 else
							   {
							      goto tag_1061_10_602;
							   }
						      }
						    else
						      {
							 goto tag_1061_10_602;
						      }
						 }
					       else
						 {
						    goto tag_1061_10_602;
						 }
					    }
					  else
					    {
					       goto tag_1061_10_602;
					    }
				       }
				     else
				       {
					  goto tag_1061_10_602;
				       }
				  }
			       }
			     else
			       {
				  goto tag_1061_10_602;
			       }
			  }
		     }
		  }
		else
		  {
		     goto tag_1061_10_602;
		  }
	     }
	   else
	     {
		goto tag_1061_10_602;
	     }
	}
      else
	{
	   goto tag_1061_10_602;
	}
   }
}


/* _expand-generic1640 */ obj_t 
_expand_generic1640_163_expand_define(obj_t env_1281, obj_t x_1282, obj_t e_1283)
{
   return expand_generic_229_expand_define(x_1282, e_1283);
}


/* arg1558 */ obj_t 
arg1558_expand_define(obj_t env_1284)
{
   {
      obj_t kw_1285;
      obj_t e_1286;
      obj_t id_1287;
      obj_t name_1288;
      obj_t args_1289;
      obj_t body_1290;
      obj_t x_1291;
      kw_1285 = PROCEDURE_REF(env_1284, ((long) 0));
      e_1286 = PROCEDURE_REF(env_1284, ((long) 1));
      id_1287 = PROCEDURE_REF(env_1284, ((long) 2));
      name_1288 = PROCEDURE_REF(env_1284, ((long) 3));
      args_1289 = PROCEDURE_REF(env_1284, ((long) 4));
      body_1290 = PROCEDURE_REF(env_1284, ((long) 5));
      x_1291 = PROCEDURE_REF(env_1284, ((long) 6));
      {
	 {
	    obj_t arg1560_1193;
	    arg1560_1193 = do_inline_generic_method_204_expand_define(kw_1285, e_1286, id_1287, name_1288, args_1289, body_1290);
	    return replace__160_tools_misc(x_1291, arg1560_1193);
	 }
      }
   }
}


/* do-external-define-lambda */ obj_t 
do_external_define_lambda_175_expand_define(obj_t e_25, obj_t name_26, obj_t args_27, obj_t body_28)
{
   enter_function_81_tools_error(name_26);
   {
      obj_t o_exp_155_638;
      o_exp_155_638 = find_o_expander_0_expand_expander(name_26);
      {
	 obj_t e_639;
	 e_639 = internal_begin_expander_196_expand_lambda(e_25);
	 {
	    {
	       bool_t test1561_640;
	       {
		  bool_t test_2034;
		  if (STRUCTP(o_exp_155_638))
		    {
		       obj_t aux_2039;
		       obj_t aux_2037;
		       aux_2039 = CNST_TABLE_REF(((long) 5));
		       aux_2037 = STRUCT_KEY(o_exp_155_638);
		       test_2034 = (aux_2037 == aux_2039);
		    }
		  else
		    {
		       test_2034 = ((bool_t) 0);
		    }
		  if (test_2034)
		    {
		       if (CBOOL(_lib_mode__85_engine_param))
			 {
			    test1561_640 = ((bool_t) 0);
			 }
		       else
			 {
			    test1561_640 = ((bool_t) 1);
			 }
		    }
		  else
		    {
		       test1561_640 = ((bool_t) 0);
		    }
	       }
	       if (test1561_640)
		 {
		    {
		       obj_t list1562_641;
		       {
			  obj_t arg1564_643;
			  {
			     obj_t arg1566_645;
			     arg1566_645 = MAKE_PAIR(name_26, BNIL);
			     arg1564_643 = MAKE_PAIR(string1647_expand_define, arg1566_645);
			  }
			  list1562_641 = MAKE_PAIR(string1648_expand_define, arg1564_643);
		       }
		       warning___error(list1562_641);
		    }
		    unbind_o_expander__20_expand_expander(name_26);
		 }
	       else
		 {
		    BUNSPEC;
		 }
	    }
	    {
	       obj_t ebody_648;
	       {
		  obj_t arg1581_656;
		  obj_t arg1582_657;
		  arg1581_656 = args___args_list_50_tools_args(args_27);
		  arg1582_657 = CNST_TABLE_REF(((long) 1));
		  {
		     obj_t arg1583_1292;
		     arg1583_1292 = make_fx_procedure(arg1583_expand_define, ((long) 0), ((long) 2));
		     PROCEDURE_SET(arg1583_1292, ((long) 0), body_28);
		     PROCEDURE_SET(arg1583_1292, ((long) 1), e_639);
		     ebody_648 = with_lexical_22_expand_eps(arg1581_656, arg1582_657, arg1583_1292);
		  }
	       }
	       leave_function_170_tools_error();
	       {
		  obj_t arg1570_649;
		  obj_t arg1572_650;
		  arg1570_649 = CNST_TABLE_REF(((long) 2));
		  arg1572_650 = MAKE_PAIR(name_26, args_27);
		  {
		     obj_t list1574_652;
		     {
			obj_t arg1575_653;
			{
			   obj_t arg1578_654;
			   arg1578_654 = MAKE_PAIR(BNIL, BNIL);
			   arg1575_653 = MAKE_PAIR(ebody_648, arg1578_654);
			}
			list1574_652 = MAKE_PAIR(arg1572_650, arg1575_653);
		     }
		     return cons__138___r4_pairs_and_lists_6_3(arg1570_649, list1574_652);
		  }
	       }
	    }
	 }
      }
   }
}


/* arg1583 */ obj_t 
arg1583_expand_define(obj_t env_1293)
{
   {
      obj_t body_1294;
      obj_t e_1295;
      body_1294 = PROCEDURE_REF(env_1293, ((long) 0));
      e_1295 = PROCEDURE_REF(env_1293, ((long) 1));
      {
	 {
	    obj_t arg1585_660;
	    arg1585_660 = normalize_progn_143_tools_progn(body_1294);
	    return PROCEDURE_ENTRY(e_1295) (e_1295, arg1585_660, e_1295, BEOA);
	 }
      }
   }
}


/* do-external-define-value */ obj_t 
do_external_define_value_7_expand_define(obj_t e_29, obj_t name_30, obj_t value_31)
{
   {
      obj_t o_exp_155_663;
      o_exp_155_663 = find_o_expander_0_expand_expander(name_30);
      {
	 obj_t e_664;
	 e_664 = internal_begin_expander_196_expand_lambda(e_29);
	 {
	    {
	       bool_t test1586_665;
	       {
		  bool_t test_2070;
		  if (STRUCTP(o_exp_155_663))
		    {
		       obj_t aux_2075;
		       obj_t aux_2073;
		       aux_2075 = CNST_TABLE_REF(((long) 5));
		       aux_2073 = STRUCT_KEY(o_exp_155_663);
		       test_2070 = (aux_2073 == aux_2075);
		    }
		  else
		    {
		       test_2070 = ((bool_t) 0);
		    }
		  if (test_2070)
		    {
		       if (CBOOL(_lib_mode__85_engine_param))
			 {
			    test1586_665 = ((bool_t) 0);
			 }
		       else
			 {
			    test1586_665 = ((bool_t) 1);
			 }
		    }
		  else
		    {
		       test1586_665 = ((bool_t) 0);
		    }
	       }
	       if (test1586_665)
		 {
		    {
		       obj_t list1587_666;
		       {
			  obj_t arg1589_668;
			  arg1589_668 = MAKE_PAIR(name_30, BNIL);
			  list1587_666 = MAKE_PAIR(string1647_expand_define, arg1589_668);
		       }
		       warning___error(list1587_666);
		    }
		    unbind_o_expander__20_expand_expander(name_30);
		 }
	       else
		 {
		    BUNSPEC;
		 }
	    }
	    {
	       obj_t evalue_671;
	       {
		  obj_t arg1603_678;
		  arg1603_678 = normalize_progn_143_tools_progn(value_31);
		  evalue_671 = PROCEDURE_ENTRY(e_664) (e_664, arg1603_678, e_664, BEOA);
	       }
	       {
		  obj_t arg1594_672;
		  arg1594_672 = CNST_TABLE_REF(((long) 2));
		  {
		     obj_t list1596_674;
		     {
			obj_t arg1598_675;
			{
			   obj_t arg1600_676;
			   arg1600_676 = MAKE_PAIR(BNIL, BNIL);
			   arg1598_675 = MAKE_PAIR(evalue_671, arg1600_676);
			}
			list1596_674 = MAKE_PAIR(name_30, arg1598_675);
		     }
		     return cons__138___r4_pairs_and_lists_6_3(arg1594_672, list1596_674);
		  }
	       }
	    }
	 }
      }
   }
}


/* do-inline/generic/method */ obj_t 
do_inline_generic_method_204_expand_define(obj_t define_keyword_155_32, obj_t e_33, obj_t id_34, obj_t name_35, obj_t args_36, obj_t body_37)
{
   internal_definition__7_expand_lambda = BTRUE;
   enter_function_81_tools_error(name_35);
   {
      obj_t o_exp_155_679;
      o_exp_155_679 = find_o_expander_0_expand_expander(name_35);
      {
	 obj_t e_680;
	 e_680 = internal_begin_expander_196_expand_lambda(e_33);
	 {
	    obj_t ebody_681;
	    if (PAIRP(body_37))
	      {
		 obj_t arg1627_701;
		 obj_t arg1628_702;
		 arg1627_701 = args___args_list_50_tools_args(args_36);
		 arg1628_702 = CNST_TABLE_REF(((long) 1));
		 {
		    obj_t arg1630_1296;
		    arg1630_1296 = make_fx_procedure(arg1630_expand_define, ((long) 0), ((long) 2));
		    PROCEDURE_SET(arg1630_1296, ((long) 0), body_37);
		    PROCEDURE_SET(arg1630_1296, ((long) 1), e_680);
		    ebody_681 = with_lexical_22_expand_eps(arg1627_701, arg1628_702, arg1630_1296);
		 }
	      }
	    else
	      {
		 ebody_681 = BNIL;
	      }
	    {
	       leave_function_170_tools_error();
	       {
		  bool_t test1604_682;
		  {
		     bool_t test_2105;
		     if (STRUCTP(o_exp_155_679))
		       {
			  obj_t aux_2110;
			  obj_t aux_2108;
			  aux_2110 = CNST_TABLE_REF(((long) 5));
			  aux_2108 = STRUCT_KEY(o_exp_155_679);
			  test_2105 = (aux_2108 == aux_2110);
		       }
		     else
		       {
			  test_2105 = ((bool_t) 0);
		       }
		     if (test_2105)
		       {
			  if (CBOOL(_lib_mode__85_engine_param))
			    {
			       test1604_682 = ((bool_t) 0);
			    }
			  else
			    {
			       test1604_682 = ((bool_t) 1);
			    }
		       }
		     else
		       {
			  test1604_682 = ((bool_t) 0);
		       }
		  }
		  if (test1604_682)
		    {
		       {
			  obj_t list1605_683;
			  {
			     obj_t arg1607_685;
			     arg1607_685 = MAKE_PAIR(name_35, BNIL);
			     list1605_683 = MAKE_PAIR(string1647_expand_define, arg1607_685);
			  }
			  warning___error(list1605_683);
		       }
		       unbind_o_expander__20_expand_expander(name_35);
		    }
		  else
		    {
		       BUNSPEC;
		    }
	       }
	       internal_definition__7_expand_lambda = BFALSE;
	       if (NULLP(ebody_681))
		 {
		    obj_t arg1612_689;
		    arg1612_689 = MAKE_PAIR(id_34, args_36);
		    {
		       obj_t list1614_691;
		       {
			  obj_t arg1615_692;
			  arg1615_692 = MAKE_PAIR(BNIL, BNIL);
			  list1614_691 = MAKE_PAIR(arg1612_689, arg1615_692);
		       }
		       return cons__138___r4_pairs_and_lists_6_3(define_keyword_155_32, list1614_691);
		    }
		 }
	       else
		 {
		    obj_t arg1618_694;
		    arg1618_694 = MAKE_PAIR(id_34, args_36);
		    {
		       obj_t list1621_696;
		       {
			  obj_t arg1622_697;
			  {
			     obj_t arg1623_698;
			     arg1623_698 = MAKE_PAIR(BNIL, BNIL);
			     arg1622_697 = MAKE_PAIR(ebody_681, arg1623_698);
			  }
			  list1621_696 = MAKE_PAIR(arg1618_694, arg1622_697);
		       }
		       return cons__138___r4_pairs_and_lists_6_3(define_keyword_155_32, list1621_696);
		    }
		 }
	    }
	 }
      }
   }
}


/* arg1630 */ obj_t 
arg1630_expand_define(obj_t env_1297)
{
   {
      obj_t body_1298;
      obj_t e_1299;
      body_1298 = PROCEDURE_REF(env_1297, ((long) 0));
      e_1299 = PROCEDURE_REF(env_1297, ((long) 1));
      {
	 {
	    obj_t arg1632_705;
	    arg1632_705 = normalize_progn_143_tools_progn(body_1298);
	    return PROCEDURE_ENTRY(e_1299) (e_1299, arg1632_705, e_1299, BEOA);
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_expand_define()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_define()
{
   module_initialization_70_tools_trace(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_tools_progn(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_tools_args(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_tools_error(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_tools_speek(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_tools_misc(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_expand_expander(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_expand_eps(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_expand_lambda(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_engine_param(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_type_type(((long) 0), "EXPAND_DEFINE");
   module_initialization_70_type_cache(((long) 0), "EXPAND_DEFINE");
   return module_initialization_70_ast_ident(((long) 0), "EXPAND_DEFINE");
}
