/*===========================================================================*/
/*   (Object/access.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t append___r4_pairs_and_lists_6_3(obj_t);
static obj_t _make_class_pred_3348_157_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t method_init_76_object_access();
static obj_t make_one_coercion_132_object_access(obj_t, obj_t, obj_t, obj_t);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t _make_class_makes__119_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _optim__89_engine_param;
static obj_t _alloca_object_tools(obj_t, obj_t, obj_t);
extern obj_t make_class_makes__132_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t import_slot_dyna_indexed_ref__108_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t import_slot_indexed_set__155_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t slot_virtual_ref_147_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _make_coercion_clause_178_object_access(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
static obj_t slot_indexed_ref_219_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_class_pred__174_object_access(obj_t, class_t, obj_t, obj_t);
static obj_t _make_class_slots_access__121_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t slot_dyna_indexed_ref_48_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_pragma_direct_set__widening_17_object_tools(type_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_class_coercers_236_object_access(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _import_class_makes_3354_219_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_object_access(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_object_struct(long, char *);
extern obj_t module_initialization_70_object_slots(long, char *);
extern obj_t module_initialization_70_object_tools(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_impuse(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t make_class_make_typed_formals_184_object_access(obj_t);
static obj_t _make_class_make_formals_78_object_access(obj_t, obj_t);
static obj_t make_class_slot_make__242_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t import_class_make__159_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t slot_virtual_set__86_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t import_slot_indexed_ref__208_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_class_slots_access__80_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t import_slot_set__215_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_object_access();
static obj_t slot_indexed_set__217_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t make_coercion_clause_209_object_access(obj_t, obj_t);
extern obj_t make_pragma_indexed_ref_widening_28_object_tools(type_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t produce_module_clause__172_module_module(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t import_parser_53_module_impuse(obj_t, obj_t);
static obj_t slot_ref_85_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_object_access();
static obj_t slot_set__144_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t import_class_slots_access__39_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _epairify_object_access(obj_t, obj_t, obj_t);
extern obj_t _optim_stack___57_engine_param;
extern obj_t class__super_id_210_object_tools(obj_t, obj_t);
static obj_t toplevel_init_63_object_access();
static obj_t slot_direct_set__173_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t malloc_object_tools(type_t, obj_t);
static obj_t import_slot_ref__77_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t epairify_object_access(obj_t, obj_t);
extern obj_t import_class_pred__91_object_access(obj_t, class_t, obj_t, obj_t);
static obj_t slot_direct_ref_183_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t class_object_class;
static obj_t _make_class_allocate__22_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t class__obj_id_219_object_tools(obj_t);
static obj_t _import_class_pred_3349_50_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _malloc_object_tools(obj_t, obj_t, obj_t);
extern obj_t make_pragma_indexed_init_set__66_object_tools(type_t, obj_t, obj_t, obj_t);
extern obj_t super__class_id_210_object_tools(obj_t, obj_t);
extern obj_t make_class_make_formals_23_object_access(obj_t);
static obj_t _import_class_slots_access_3355_104_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t import_slot_direct_set__76_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t slot_dyna_indexed_set__50_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t class__id_80_object_tools(obj_t);
extern obj_t _unsafe_range__218_engine_param;
extern obj_t make_pragma_direct_set__7_object_tools(type_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t import_class_makes__192_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t make_class_make__196_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t obj__class_id_9_object_tools(obj_t);
static obj_t import_slot_dyna_indexed_set__203_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_pragma_direct_ref_widening_240_object_tools(type_t, obj_t, obj_t, obj_t);
extern obj_t make_class_allocate__44_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_object_access = BUNSPEC;
extern obj_t make_pragma_indexed_set__widening_24_object_tools(type_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _make_class_make_typed_formals_151_object_access(obj_t, obj_t);
extern obj_t find_class_constructors_231_object_class(class_t);
static obj_t cnst_init_137_object_access();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t _make_class_coercers_12_object_access(obj_t, obj_t);
static obj_t import_slot_direct_ref__71_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t __cnst[52];

DEFINE_EXPORT_PROCEDURE(make_class_coercers_env_94_object_access, _make_class_coercers_12_object_access3369, _make_class_coercers_12_object_access, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_class_slots_access__env_134_object_access, _make_class_slots_access__121_object_access3370, _make_class_slots_access__121_object_access, 0L, 6);
DEFINE_EXPORT_PROCEDURE(make_class_makes__env_104_object_access, _make_class_makes__119_object_access3371, _make_class_makes__119_object_access, 0L, 7);
DEFINE_EXPORT_PROCEDURE(import_class_slots_access__env_230_object_access, _import_class_slots_access_3355_104_object_access3372, _import_class_slots_access_3355_104_object_access, 0L, 5);
DEFINE_EXPORT_PROCEDURE(make_class_make_formals_env_241_object_access, _make_class_make_formals_78_object_access3373, _make_class_make_formals_78_object_access, 0L, 1);
extern obj_t alloca_env_212_object_tools;
extern obj_t malloc_env_105_object_tools;
DEFINE_EXPORT_PROCEDURE(import_class_makes__env_142_object_access, _import_class_makes_3354_219_object_access3374, _import_class_makes_3354_219_object_access, 0L, 6);
DEFINE_EXPORT_PROCEDURE(epairify_env_148_object_access, _epairify_object_access3375, va_generic_entry, _epairify_object_access, -2);
DEFINE_STRING(string3362_object_access, string3362_object_access3376, "VAL -SET! -REF SLOT ERROR <FX INDEX >=FX INDEX::LONG __OBJECT ALLOCATE- FREE-PRAGMA::LONG +FX DONE QUOTE =FX IF LABELS -LEN BEGIN LOOP OBJECT-WIDENING-SET! CLASS-NUM OBJECT-CLASS-NUM-SET! WIDENING LET DEFINE (INLINE) ::LONG I NEW STACK-ALLOC -STACK- - @ IS-A? DEFINE-INLINE PREDICATE-OF ::OBJ INLINE SUPER SUPER- ?::BOOL ? MACRO NO-CFA-TOP SIDE-EFFECT-FREE PRAGMA -> OBJ TYPE COERCE ", 383);
DEFINE_STRING(string3361_object_access, string3361_object_access3377, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string3359_object_access, string3359_object_access3378, "Index out of bound", 18);
DEFINE_STRING(string3360_object_access, string3360_object_access3379, "cer", 3);
DEFINE_STRING(string3358_object_access, string3358_object_access3380, "(", 1);
DEFINE_STRING(string3357_object_access, string3357_object_access3381, ")", 1);
DEFINE_STRING(string3356_object_access, string3356_object_access3382, "obj_t", 5);
DEFINE_EXPORT_PROCEDURE(make_class_make_typed_formals_env_161_object_access, _make_class_make_typed_formals_151_object_access3383, _make_class_make_typed_formals_151_object_access, 0L, 1);
DEFINE_EXPORT_PROCEDURE(import_class_pred__env_87_object_access, _import_class_pred_3349_50_object_access3384, _import_class_pred_3349_50_object_access, 0L, 4);
DEFINE_EXPORT_PROCEDURE(make_class_allocate__env_43_object_access, _make_class_allocate__22_object_access3385, _make_class_allocate__22_object_access, 0L, 5);
DEFINE_EXPORT_PROCEDURE(make_coercion_clause_env_78_object_access, _make_coercion_clause_178_object_access3386, _make_coercion_clause_178_object_access, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_class_pred__env_156_object_access, _make_class_pred_3348_157_object_access3387, _make_class_pred_3348_157_object_access, 0L, 4);


/* module-initialization */ obj_t 
module_initialization_70_object_access(long checksum_3550, char *from_3551)
{
   if (CBOOL(require_initialization_114_object_access))
     {
	require_initialization_114_object_access = BBOOL(((bool_t) 0));
	library_modules_init_112_object_access();
	cnst_init_137_object_access();
	imported_modules_init_94_object_access();
	method_init_76_object_access();
	toplevel_init_63_object_access();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_access()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_ACCESS");
   module_initialization_70___r4_symbols_6_4(((long) 0), "OBJECT_ACCESS");
   module_initialization_70___object(((long) 0), "OBJECT_ACCESS");
   module_initialization_70___r4_strings_6_7(((long) 0), "OBJECT_ACCESS");
   module_initialization_70___reader(((long) 0), "OBJECT_ACCESS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_access()
{
   {
      obj_t cnst_port_138_3542;
      cnst_port_138_3542 = open_input_string(string3362_object_access);
      {
	 long i_3543;
	 i_3543 = ((long) 51);
       loop_3544:
	 {
	    bool_t test3363_3545;
	    test3363_3545 = (i_3543 == ((long) -1));
	    if (test3363_3545)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg3364_3546;
		    {
		       obj_t list3365_3547;
		       {
			  obj_t arg3367_3548;
			  arg3367_3548 = BNIL;
			  list3365_3547 = MAKE_PAIR(cnst_port_138_3542, arg3367_3548);
		       }
		       arg3364_3546 = read___reader(list3365_3547);
		    }
		    CNST_TABLE_SET(i_3543, arg3364_3546);
		 }
		 {
		    int aux_3549;
		    {
		       long aux_3571;
		       aux_3571 = (i_3543 - ((long) 1));
		       aux_3549 = (int) (aux_3571);
		    }
		    {
		       long i_3574;
		       i_3574 = (long) (aux_3549);
		       i_3543 = i_3574;
		       goto loop_3544;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_object_access()
{
   return BUNSPEC;
}


/* make-coercion-clause */ obj_t 
make_coercion_clause_209_object_access(obj_t c_id_230_63, obj_t super_64)
{
   {
      obj_t class__obj_201_656;
      class__obj_201_656 = class__obj_id_219_object_tools(c_id_230_63);
      {
	 obj_t obj__class_1_657;
	 obj__class_1_657 = obj__class_id_9_object_tools(c_id_230_63);
	 {
	    obj_t class_id__3_658;
	    class_id__3_658 = class__id_80_object_tools(c_id_230_63);
	    {
	       {
		  obj_t super_659;
		  obj_t coercer_660;
		  {
		     obj_t arg1250_662;
		     {
			obj_t arg1251_663;
			obj_t arg1252_664;
			{
			   obj_t arg1256_668;
			   obj_t arg1257_669;
			   obj_t arg1258_670;
			   obj_t arg1259_671;
			   arg1256_668 = CNST_TABLE_REF(((long) 0));
			   arg1257_669 = CNST_TABLE_REF(((long) 2));
			   {
			      obj_t list1270_680;
			      list1270_680 = MAKE_PAIR(BNIL, BNIL);
			      arg1258_670 = cons__138___r4_pairs_and_lists_6_3(class_id__3_658, list1270_680);
			   }
			   {
			      obj_t list1274_683;
			      list1274_683 = MAKE_PAIR(BNIL, BNIL);
			      arg1259_671 = cons__138___r4_pairs_and_lists_6_3(obj__class_1_657, list1274_683);
			   }
			   {
			      obj_t list1261_673;
			      {
				 obj_t arg1262_674;
				 {
				    obj_t arg1263_675;
				    {
				       obj_t arg1265_676;
				       {
					  obj_t arg1267_677;
					  arg1267_677 = MAKE_PAIR(BNIL, BNIL);
					  arg1265_676 = MAKE_PAIR(arg1259_671, arg1267_677);
				       }
				       arg1263_675 = MAKE_PAIR(arg1258_670, arg1265_676);
				    }
				    arg1262_674 = MAKE_PAIR(c_id_230_63, arg1263_675);
				 }
				 list1261_673 = MAKE_PAIR(arg1257_669, arg1262_674);
			      }
			      arg1251_663 = cons__138___r4_pairs_and_lists_6_3(arg1256_668, list1261_673);
			   }
			}
			{
			   obj_t arg1278_685;
			   obj_t arg1281_686;
			   obj_t arg1283_688;
			   arg1278_685 = CNST_TABLE_REF(((long) 0));
			   arg1281_686 = CNST_TABLE_REF(((long) 2));
			   {
			      obj_t list1293_697;
			      list1293_697 = MAKE_PAIR(BNIL, BNIL);
			      arg1283_688 = cons__138___r4_pairs_and_lists_6_3(class__obj_201_656, list1293_697);
			   }
			   {
			      obj_t list1285_690;
			      {
				 obj_t arg1286_691;
				 {
				    obj_t arg1287_692;
				    {
				       obj_t arg1288_693;
				       {
					  obj_t arg1290_694;
					  arg1290_694 = MAKE_PAIR(BNIL, BNIL);
					  arg1288_693 = MAKE_PAIR(arg1283_688, arg1290_694);
				       }
				       arg1287_692 = MAKE_PAIR(BNIL, arg1288_693);
				    }
				    arg1286_691 = MAKE_PAIR(arg1281_686, arg1287_692);
				 }
				 list1285_690 = MAKE_PAIR(c_id_230_63, arg1286_691);
			      }
			      arg1252_664 = cons__138___r4_pairs_and_lists_6_3(arg1278_685, list1285_690);
			   }
			}
			{
			   obj_t list1253_665;
			   {
			      obj_t arg1254_666;
			      arg1254_666 = MAKE_PAIR(arg1252_664, BNIL);
			      list1253_665 = MAKE_PAIR(arg1251_663, arg1254_666);
			   }
			   arg1250_662 = list1253_665;
			}
		     }
		     super_659 = super_64;
		     coercer_660 = arg1250_662;
		   loop_661:
		     {
			bool_t test1295_699;
			test1295_699 = is_a__118___object(super_659, class_object_class);
			if (test1295_699)
			  {
			     obj_t super_id_153_700;
			     {
				type_t obj_2907;
				obj_2907 = (type_t) (super_659);
				super_id_153_700 = (((type_t) CREF(obj_2907))->id);
			     }
			     {
				obj_t class__super_100_701;
				class__super_100_701 = class__super_id_210_object_tools(c_id_230_63, super_id_153_700);
				{
				   obj_t super__class_100_702;
				   super__class_100_702 = super__class_id_210_object_tools(super_id_153_700, c_id_230_63);
				   {
				      {
					 obj_t arg1296_703;
					 obj_t arg1297_704;
					 {
					    class_t obj_2908;
					    obj_2908 = (class_t) (super_659);
					    {
					       obj_t aux_3610;
					       {
						  object_t aux_3611;
						  aux_3611 = (object_t) (obj_2908);
						  aux_3610 = OBJECT_WIDENING(aux_3611);
					       }
					       arg1296_703 = (((class_t) CREF(aux_3610))->its_super_214);
					    }
					 }
					 {
					    obj_t arg1298_705;
					    obj_t arg1299_706;
					    {
					       obj_t arg1300_707;
					       obj_t arg1301_708;
					       obj_t arg1302_709;
					       arg1300_707 = CNST_TABLE_REF(((long) 0));
					       {
						  obj_t list1314_718;
						  list1314_718 = MAKE_PAIR(BNIL, BNIL);
						  arg1301_708 = cons__138___r4_pairs_and_lists_6_3(class_id__3_658, list1314_718);
					       }
					       {
						  obj_t list1317_721;
						  list1317_721 = MAKE_PAIR(BNIL, BNIL);
						  arg1302_709 = cons__138___r4_pairs_and_lists_6_3(super__class_100_702, list1317_721);
					       }
					       {
						  obj_t list1304_711;
						  {
						     obj_t arg1307_712;
						     {
							obj_t arg1308_713;
							{
							   obj_t arg1309_714;
							   {
							      obj_t arg1310_715;
							      arg1310_715 = MAKE_PAIR(BNIL, BNIL);
							      arg1309_714 = MAKE_PAIR(arg1302_709, arg1310_715);
							   }
							   arg1308_713 = MAKE_PAIR(arg1301_708, arg1309_714);
							}
							arg1307_712 = MAKE_PAIR(c_id_230_63, arg1308_713);
						     }
						     list1304_711 = MAKE_PAIR(super_id_153_700, arg1307_712);
						  }
						  arg1298_705 = cons__138___r4_pairs_and_lists_6_3(arg1300_707, list1304_711);
					       }
					    }
					    {
					       obj_t arg1321_723;
					       {
						  obj_t arg1322_724;
						  obj_t arg1324_726;
						  arg1322_724 = CNST_TABLE_REF(((long) 0));
						  {
						     obj_t list1335_735;
						     list1335_735 = MAKE_PAIR(BNIL, BNIL);
						     arg1324_726 = cons__138___r4_pairs_and_lists_6_3(class__super_100_701, list1335_735);
						  }
						  {
						     obj_t list1326_728;
						     {
							obj_t arg1328_729;
							{
							   obj_t arg1330_730;
							   {
							      obj_t arg1331_731;
							      {
								 obj_t arg1332_732;
								 arg1332_732 = MAKE_PAIR(BNIL, BNIL);
								 arg1331_731 = MAKE_PAIR(arg1324_726, arg1332_732);
							      }
							      arg1330_730 = MAKE_PAIR(BNIL, arg1331_731);
							   }
							   arg1328_729 = MAKE_PAIR(super_id_153_700, arg1330_730);
							}
							list1326_728 = MAKE_PAIR(c_id_230_63, arg1328_729);
						     }
						     arg1321_723 = cons__138___r4_pairs_and_lists_6_3(arg1322_724, list1326_728);
						  }
					       }
					       arg1299_706 = MAKE_PAIR(arg1321_723, coercer_660);
					    }
					    arg1297_704 = MAKE_PAIR(arg1298_705, arg1299_706);
					 }
					 {
					    obj_t coercer_3638;
					    obj_t super_3637;
					    super_3637 = arg1296_703;
					    coercer_3638 = arg1297_704;
					    coercer_660 = coercer_3638;
					    super_659 = super_3637;
					    goto loop_661;
					 }
				      }
				   }
				}
			     }
			  }
			else
			  {
			     obj_t arg1339_737;
			     obj_t arg1340_738;
			     arg1339_737 = CNST_TABLE_REF(((long) 1));
			     {
				obj_t arg1343_741;
				arg1343_741 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				arg1340_738 = append_2_18___r4_pairs_and_lists_6_3(coercer_660, arg1343_741);
			     }
			     {
				obj_t list1341_739;
				list1341_739 = MAKE_PAIR(arg1340_738, BNIL);
				return cons__138___r4_pairs_and_lists_6_3(arg1339_737, list1341_739);
			     }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _make-coercion-clause */ obj_t 
_make_coercion_clause_178_object_access(obj_t env_3479, obj_t c_id_230_3480, obj_t super_3481)
{
   return make_coercion_clause_209_object_access(c_id_230_3480, super_3481);
}


/* make-class-coercers */ obj_t 
make_class_coercers_236_object_access(obj_t class_65)
{
   {
      obj_t tid_745;
      obj_t tname_746;
      {
	 type_t obj_2913;
	 obj_2913 = (type_t) (class_65);
	 tid_745 = (((type_t) CREF(obj_2913))->id);
      }
      {
	 type_t obj_2914;
	 obj_2914 = (type_t) (class_65);
	 tname_746 = (((type_t) CREF(obj_2914))->name);
      }
      {
	 obj_t super_747;
	 obj_t coercer_748;
	 {
	    obj_t arg1347_750;
	    obj_t arg1349_751;
	    {
	       class_t obj_2915;
	       obj_2915 = (class_t) (class_65);
	       {
		  obj_t aux_3650;
		  {
		     object_t aux_3651;
		     aux_3651 = (object_t) (obj_2915);
		     aux_3650 = OBJECT_WIDENING(aux_3651);
		  }
		  arg1347_750 = (((class_t) CREF(aux_3650))->its_super_214);
	       }
	    }
	    arg1349_751 = make_one_coercion_132_object_access(tid_745, tname_746, CNST_TABLE_REF(((long) 2)), string3356_object_access);
	    super_747 = arg1347_750;
	    coercer_748 = arg1349_751;
	  loop_749:
	    {
	       bool_t test1352_754;
	       test1352_754 = is_a__118___object(super_747, class_object_class);
	       if (test1352_754)
		 {
		    obj_t arg1353_757;
		    obj_t arg1355_758;
		    {
		       class_t obj_2919;
		       obj_2919 = (class_t) (super_747);
		       {
			  obj_t aux_3660;
			  {
			     object_t aux_3661;
			     aux_3661 = (object_t) (obj_2919);
			     aux_3660 = OBJECT_WIDENING(aux_3661);
			  }
			  arg1353_757 = (((class_t) CREF(aux_3660))->its_super_214);
		       }
		    }
		    {
		       obj_t arg1356_759;
		       {
			  obj_t aux_3668;
			  obj_t aux_3665;
			  {
			     type_t obj_2918;
			     obj_2918 = (type_t) (super_747);
			     aux_3668 = (((type_t) CREF(obj_2918))->name);
			  }
			  {
			     type_t obj_2917;
			     obj_2917 = (type_t) (super_747);
			     aux_3665 = (((type_t) CREF(obj_2917))->id);
			  }
			  arg1356_759 = make_one_coercion_132_object_access(tid_745, tname_746, aux_3665, aux_3668);
		       }
		       arg1355_758 = append_2_18___r4_pairs_and_lists_6_3(arg1356_759, coercer_748);
		    }
		    {
		       obj_t coercer_3674;
		       obj_t super_3673;
		       super_3673 = arg1353_757;
		       coercer_3674 = arg1355_758;
		       coercer_748 = coercer_3674;
		       super_747 = super_3673;
		       goto loop_749;
		    }
		 }
	       else
		 {
		    return coercer_748;
		 }
	    }
	 }
      }
   }
}


/* make-one-coercion */ obj_t 
make_one_coercion_132_object_access(obj_t from_id_201_760, obj_t from_name_19_761, obj_t to_id_124_762, obj_t to_name_205_763)
{
   {
      obj_t t__f_60_765;
      obj_t f__t_46_766;
      {
	 obj_t arg1454_833;
	 arg1454_833 = CNST_TABLE_REF(((long) 3));
	 {
	    obj_t list1455_834;
	    {
	       obj_t arg1456_835;
	       {
		  obj_t arg1458_836;
		  arg1458_836 = MAKE_PAIR(from_id_201_760, BNIL);
		  arg1456_835 = MAKE_PAIR(arg1454_833, arg1458_836);
	       }
	       list1455_834 = MAKE_PAIR(to_id_124_762, arg1456_835);
	    }
	    t__f_60_765 = symbol_append_197___r4_symbols_6_4(list1455_834);
	 }
      }
      {
	 obj_t arg1461_838;
	 arg1461_838 = CNST_TABLE_REF(((long) 3));
	 {
	    obj_t list1462_839;
	    {
	       obj_t arg1463_840;
	       {
		  obj_t arg1464_841;
		  arg1464_841 = MAKE_PAIR(to_id_124_762, BNIL);
		  arg1463_840 = MAKE_PAIR(arg1461_838, arg1464_841);
	       }
	       list1462_839 = MAKE_PAIR(from_id_201_760, arg1463_840);
	    }
	    f__t_46_766 = symbol_append_197___r4_symbols_6_4(list1462_839);
	 }
      }
      {
	 obj_t arg1361_767;
	 {
	    obj_t arg1363_768;
	    obj_t arg1364_769;
	    obj_t arg1365_770;
	    arg1363_768 = CNST_TABLE_REF(((long) 4));
	    {
	       obj_t arg1373_776;
	       obj_t arg1375_777;
	       arg1373_776 = CNST_TABLE_REF(((long) 5));
	       arg1375_777 = CNST_TABLE_REF(((long) 6));
	       {
		  obj_t list1379_779;
		  {
		     obj_t arg1381_780;
		     {
			obj_t arg1383_781;
			arg1383_781 = MAKE_PAIR(BNIL, BNIL);
			arg1381_780 = MAKE_PAIR(arg1375_777, arg1383_781);
		     }
		     list1379_779 = MAKE_PAIR(arg1373_776, arg1381_780);
		  }
		  arg1364_769 = cons__138___r4_pairs_and_lists_6_3(t__f_60_765, list1379_779);
	       }
	    }
	    {
	       obj_t arg1385_783;
	       obj_t arg1387_784;
	       arg1385_783 = CNST_TABLE_REF(((long) 5));
	       arg1387_784 = CNST_TABLE_REF(((long) 6));
	       {
		  obj_t list1389_786;
		  {
		     obj_t arg1390_787;
		     {
			obj_t arg1391_788;
			arg1391_788 = MAKE_PAIR(BNIL, BNIL);
			arg1390_787 = MAKE_PAIR(arg1387_784, arg1391_788);
		     }
		     list1389_786 = MAKE_PAIR(arg1385_783, arg1390_787);
		  }
		  arg1365_770 = cons__138___r4_pairs_and_lists_6_3(f__t_46_766, list1389_786);
	       }
	    }
	    {
	       obj_t list1368_772;
	       {
		  obj_t arg1369_773;
		  {
		     obj_t arg1370_774;
		     arg1370_774 = MAKE_PAIR(BNIL, BNIL);
		     arg1369_773 = MAKE_PAIR(arg1365_770, arg1370_774);
		  }
		  list1368_772 = MAKE_PAIR(arg1364_769, arg1369_773);
	       }
	       arg1361_767 = cons__138___r4_pairs_and_lists_6_3(arg1363_768, list1368_772);
	    }
	 }
	 produce_module_clause__172_module_module(arg1361_767);
      }
      {
	 obj_t arg1393_790;
	 obj_t arg1395_791;
	 {
	    obj_t arg1399_795;
	    obj_t arg1401_796;
	    obj_t arg1402_797;
	    arg1399_795 = CNST_TABLE_REF(((long) 7));
	    {
	       obj_t list1414_806;
	       list1414_806 = MAKE_PAIR(BNIL, BNIL);
	       arg1401_796 = cons__138___r4_pairs_and_lists_6_3(to_id_124_762, list1414_806);
	    }
	    {
	       obj_t list1416_808;
	       {
		  obj_t arg1418_810;
		  {
		     obj_t arg1419_811;
		     arg1419_811 = MAKE_PAIR(string3357_object_access, BNIL);
		     arg1418_810 = MAKE_PAIR(from_name_19_761, arg1419_811);
		  }
		  list1416_808 = MAKE_PAIR(string3358_object_access, arg1418_810);
	       }
	       arg1402_797 = string_append_106___r4_strings_6_7(list1416_808);
	    }
	    {
	       obj_t list1404_799;
	       {
		  obj_t arg1405_800;
		  {
		     obj_t arg1407_801;
		     {
			obj_t arg1408_802;
			{
			   obj_t arg1410_803;
			   arg1410_803 = MAKE_PAIR(BNIL, BNIL);
			   arg1408_802 = MAKE_PAIR(arg1402_797, arg1410_803);
			}
			arg1407_801 = MAKE_PAIR(arg1401_796, arg1408_802);
		     }
		     arg1405_800 = MAKE_PAIR(t__f_60_765, arg1407_801);
		  }
		  list1404_799 = MAKE_PAIR(from_id_201_760, arg1405_800);
	       }
	       arg1393_790 = cons__138___r4_pairs_and_lists_6_3(arg1399_795, list1404_799);
	    }
	 }
	 {
	    obj_t arg1426_814;
	    obj_t arg1427_815;
	    obj_t arg1428_816;
	    arg1426_814 = CNST_TABLE_REF(((long) 7));
	    {
	       obj_t list1442_825;
	       list1442_825 = MAKE_PAIR(BNIL, BNIL);
	       arg1427_815 = cons__138___r4_pairs_and_lists_6_3(from_id_201_760, list1442_825);
	    }
	    {
	       obj_t list1444_827;
	       {
		  obj_t arg1448_829;
		  {
		     obj_t arg1449_830;
		     arg1449_830 = MAKE_PAIR(string3357_object_access, BNIL);
		     arg1448_829 = MAKE_PAIR(to_name_205_763, arg1449_830);
		  }
		  list1444_827 = MAKE_PAIR(string3358_object_access, arg1448_829);
	       }
	       arg1428_816 = string_append_106___r4_strings_6_7(list1444_827);
	    }
	    {
	       obj_t list1432_818;
	       {
		  obj_t arg1433_819;
		  {
		     obj_t arg1436_820;
		     {
			obj_t arg1437_821;
			{
			   obj_t arg1438_822;
			   arg1438_822 = MAKE_PAIR(BNIL, BNIL);
			   arg1437_821 = MAKE_PAIR(arg1428_816, arg1438_822);
			}
			arg1436_820 = MAKE_PAIR(arg1427_815, arg1437_821);
		     }
		     arg1433_819 = MAKE_PAIR(f__t_46_766, arg1436_820);
		  }
		  list1432_818 = MAKE_PAIR(to_id_124_762, arg1433_819);
	       }
	       arg1395_791 = cons__138___r4_pairs_and_lists_6_3(arg1426_814, list1432_818);
	    }
	 }
	 {
	    obj_t list1396_792;
	    {
	       obj_t arg1397_793;
	       arg1397_793 = MAKE_PAIR(arg1395_791, BNIL);
	       list1396_792 = MAKE_PAIR(arg1393_790, arg1397_793);
	    }
	    return list1396_792;
	 }
      }
   }
}


/* _make-class-coercers */ obj_t 
_make_class_coercers_12_object_access(obj_t env_3482, obj_t class_3483)
{
   return make_class_coercers_236_object_access(class_3483);
}


/* make-class-pred! */ obj_t 
make_class_pred__174_object_access(obj_t id_66, class_t class_67, obj_t src_def_101_68, obj_t import_69)
{
   {
      obj_t id__219_844;
      {
	 obj_t list1567_934;
	 {
	    obj_t arg1568_935;
	    {
	       obj_t aux_3732;
	       aux_3732 = CNST_TABLE_REF(((long) 8));
	       arg1568_935 = MAKE_PAIR(aux_3732, BNIL);
	    }
	    list1567_934 = MAKE_PAIR(id_66, arg1568_935);
	 }
	 id__219_844 = symbol_append_197___r4_symbols_6_4(list1567_934);
      }
      {
	 obj_t pred_id_222_845;
	 {
	    obj_t list1563_930;
	    {
	       obj_t arg1564_931;
	       {
		  obj_t aux_3737;
		  aux_3737 = CNST_TABLE_REF(((long) 9));
		  arg1564_931 = MAKE_PAIR(aux_3737, BNIL);
	       }
	       list1563_930 = MAKE_PAIR(id_66, arg1564_931);
	    }
	    pred_id_222_845 = symbol_append_197___r4_symbols_6_4(list1563_930);
	 }
	 {
	    global_t holder_846;
	    {
	       obj_t aux_3742;
	       {
		  object_t aux_3743;
		  aux_3743 = (object_t) (class_67);
		  aux_3742 = OBJECT_WIDENING(aux_3743);
	       }
	       holder_846 = (((class_t) CREF(aux_3742))->holder);
	    }
	    {
	       obj_t super_847;
	       {
		  obj_t aux_3747;
		  {
		     object_t aux_3748;
		     aux_3748 = (object_t) (class_67);
		     aux_3747 = OBJECT_WIDENING(aux_3748);
		  }
		  super_847 = (((class_t) CREF(aux_3747))->its_super_214);
	       }
	       {
		  {
		     bool_t test1466_848;
		     test1466_848 = is_a__118___object(super_847, class_object_class);
		     if (test1466_848)
		       {
			  obj_t super_pred_id_124_849;
			  obj_t super_typed_158_850;
			  {
			     obj_t arg1552_919;
			     arg1552_919 = CNST_TABLE_REF(((long) 10));
			     {
				obj_t list1553_920;
				{
				   obj_t arg1554_921;
				   arg1554_921 = MAKE_PAIR(pred_id_222_845, BNIL);
				   list1553_920 = MAKE_PAIR(arg1552_919, arg1554_921);
				}
				super_pred_id_124_849 = symbol_append_197___r4_symbols_6_4(list1553_920);
			     }
			  }
			  {
			     obj_t arg1556_923;
			     arg1556_923 = CNST_TABLE_REF(((long) 11));
			     {
				obj_t list1558_925;
				{
				   obj_t arg1559_926;
				   {
				      obj_t arg1560_927;
				      {
					 obj_t aux_3759;
					 {
					    type_t obj_2924;
					    obj_2924 = (type_t) (super_847);
					    aux_3759 = (((type_t) CREF(obj_2924))->id);
					 }
					 arg1560_927 = MAKE_PAIR(aux_3759, BNIL);
				      }
				      arg1559_926 = MAKE_PAIR(_4dots_199_tools_misc, arg1560_927);
				   }
				   list1558_925 = MAKE_PAIR(arg1556_923, arg1559_926);
				}
				super_typed_158_850 = symbol_append_197___r4_symbols_6_4(list1558_925);
			     }
			  }
			  {
			     obj_t arg1467_851;
			     {
				obj_t arg1468_852;
				{
				   obj_t arg1474_857;
				   obj_t arg1475_858;
				   arg1474_857 = CNST_TABLE_REF(((long) 12));
				   arg1475_858 = CNST_TABLE_REF(((long) 13));
				   {
				      obj_t list1477_860;
				      {
					 obj_t arg1478_861;
					 {
					    obj_t arg1479_862;
					    arg1479_862 = MAKE_PAIR(BNIL, BNIL);
					    arg1478_861 = MAKE_PAIR(arg1475_858, arg1479_862);
					 }
					 list1477_860 = MAKE_PAIR(pred_id_222_845, arg1478_861);
				      }
				      arg1468_852 = cons__138___r4_pairs_and_lists_6_3(arg1474_857, list1477_860);
				   }
				}
				{
				   obj_t list1470_854;
				   {
				      obj_t arg1471_855;
				      arg1471_855 = MAKE_PAIR(BNIL, BNIL);
				      list1470_854 = MAKE_PAIR(arg1468_852, arg1471_855);
				   }
				   arg1467_851 = cons__138___r4_pairs_and_lists_6_3(import_69, list1470_854);
				}
			     }
			     produce_module_clause__172_module_module(arg1467_851);
			  }
			  {
			     obj_t arg1481_864;
			     {
				obj_t arg1483_865;
				obj_t arg1484_866;
				arg1483_865 = CNST_TABLE_REF(((long) 4));
				{
				   obj_t arg1489_871;
				   obj_t arg1490_872;
				   {
				      obj_t arg1498_878;
				      obj_t arg1499_879;
				      arg1498_878 = CNST_TABLE_REF(((long) 14));
				      {
					 type_t obj_2925;
					 obj_2925 = (type_t) (class_67);
					 arg1499_879 = (((type_t) CREF(obj_2925))->id);
				      }
				      {
					 obj_t list1501_881;
					 {
					    obj_t arg1502_882;
					    arg1502_882 = MAKE_PAIR(BNIL, BNIL);
					    list1501_881 = MAKE_PAIR(arg1499_879, arg1502_882);
					 }
					 arg1489_871 = cons__138___r4_pairs_and_lists_6_3(arg1498_878, list1501_881);
				      }
				   }
				   arg1490_872 = CNST_TABLE_REF(((long) 6));
				   {
				      obj_t list1492_874;
				      {
					 obj_t arg1494_875;
					 {
					    obj_t arg1496_876;
					    arg1496_876 = MAKE_PAIR(BNIL, BNIL);
					    arg1494_875 = MAKE_PAIR(arg1490_872, arg1496_876);
					 }
					 list1492_874 = MAKE_PAIR(arg1489_871, arg1494_875);
				      }
				      arg1484_866 = cons__138___r4_pairs_and_lists_6_3(id__219_844, list1492_874);
				   }
				}
				{
				   obj_t list1486_868;
				   {
				      obj_t arg1487_869;
				      arg1487_869 = MAKE_PAIR(BNIL, BNIL);
				      list1486_868 = MAKE_PAIR(arg1484_866, arg1487_869);
				   }
				   arg1481_864 = cons__138___r4_pairs_and_lists_6_3(arg1483_865, list1486_868);
				}
			     }
			     produce_module_clause__172_module_module(arg1481_864);
			  }
			  {
			     obj_t arg1504_884;
			     {
				obj_t arg1510_887;
				{
				   obj_t arg1514_890;
				   obj_t arg1515_891;
				   obj_t arg1516_892;
				   arg1514_890 = CNST_TABLE_REF(((long) 15));
				   {
				      obj_t arg1525_898;
				      arg1525_898 = CNST_TABLE_REF(((long) 2));
				      {
					 obj_t list1527_900;
					 {
					    obj_t arg1528_901;
					    arg1528_901 = MAKE_PAIR(BNIL, BNIL);
					    list1527_900 = MAKE_PAIR(arg1525_898, arg1528_901);
					 }
					 arg1515_891 = cons__138___r4_pairs_and_lists_6_3(pred_id_222_845, list1527_900);
				      }
				   }
				   {
				      obj_t arg1530_903;
				      obj_t arg1531_904;
				      obj_t arg1532_905;
				      arg1530_903 = CNST_TABLE_REF(((long) 16));
				      arg1531_904 = CNST_TABLE_REF(((long) 2));
				      {
					 obj_t arg1539_911;
					 obj_t arg1540_912;
					 obj_t arg1542_913;
					 arg1539_911 = CNST_TABLE_REF(((long) 17));
					 arg1540_912 = (((global_t) CREF(holder_846))->id);
					 arg1542_913 = (((global_t) CREF(holder_846))->module);
					 {
					    obj_t list1546_915;
					    {
					       obj_t arg1548_916;
					       {
						  obj_t arg1549_917;
						  arg1549_917 = MAKE_PAIR(BNIL, BNIL);
						  arg1548_916 = MAKE_PAIR(arg1542_913, arg1549_917);
					       }
					       list1546_915 = MAKE_PAIR(arg1540_912, arg1548_916);
					    }
					    arg1532_905 = cons__138___r4_pairs_and_lists_6_3(arg1539_911, list1546_915);
					 }
				      }
				      {
					 obj_t list1534_907;
					 {
					    obj_t arg1535_908;
					    {
					       obj_t arg1536_909;
					       arg1536_909 = MAKE_PAIR(BNIL, BNIL);
					       arg1535_908 = MAKE_PAIR(arg1532_905, arg1536_909);
					    }
					    list1534_907 = MAKE_PAIR(arg1531_904, arg1535_908);
					 }
					 arg1516_892 = cons__138___r4_pairs_and_lists_6_3(arg1530_903, list1534_907);
				      }
				   }
				   {
				      obj_t list1518_894;
				      {
					 obj_t arg1519_895;
					 {
					    obj_t arg1522_896;
					    arg1522_896 = MAKE_PAIR(BNIL, BNIL);
					    arg1519_895 = MAKE_PAIR(arg1516_892, arg1522_896);
					 }
					 list1518_894 = MAKE_PAIR(arg1515_891, arg1519_895);
				      }
				      arg1510_887 = cons__138___r4_pairs_and_lists_6_3(arg1514_890, list1518_894);
				   }
				}
				{
				   obj_t list1511_888;
				   list1511_888 = MAKE_PAIR(src_def_101_68, BNIL);
				   arg1504_884 = epairify_object_access(arg1510_887, list1511_888);
				}
			     }
			     {
				obj_t list1505_885;
				list1505_885 = MAKE_PAIR(arg1504_884, BNIL);
				return list1505_885;
			     }
			  }
		       }
		     else
		       {
			  return BNIL;
		       }
		  }
	       }
	    }
	 }
      }
   }
}


/* _make-class-pred!3348 */ obj_t 
_make_class_pred_3348_157_object_access(obj_t env_3484, obj_t id_3485, obj_t class_3486, obj_t src_def_101_3487, obj_t import_3488)
{
   return make_class_pred__174_object_access(id_3485, (class_t) (class_3486), src_def_101_3487, import_3488);
}


/* import-class-pred! */ obj_t 
import_class_pred__91_object_access(obj_t id_70, class_t class_71, obj_t src_def_101_72, obj_t module_73)
{
   {
      obj_t id__219_937;
      {
	 obj_t list1601_965;
	 {
	    obj_t arg1602_966;
	    {
	       obj_t aux_3819;
	       aux_3819 = CNST_TABLE_REF(((long) 8));
	       arg1602_966 = MAKE_PAIR(aux_3819, BNIL);
	    }
	    list1601_965 = MAKE_PAIR(id_70, arg1602_966);
	 }
	 id__219_937 = symbol_append_197___r4_symbols_6_4(list1601_965);
      }
      {
	 obj_t pred_id_222_938;
	 {
	    obj_t list1594_961;
	    {
	       obj_t arg1595_962;
	       {
		  obj_t aux_3824;
		  aux_3824 = CNST_TABLE_REF(((long) 9));
		  arg1595_962 = MAKE_PAIR(aux_3824, BNIL);
	       }
	       list1594_961 = MAKE_PAIR(id_70, arg1595_962);
	    }
	    pred_id_222_938 = symbol_append_197___r4_symbols_6_4(list1594_961);
	 }
	 {
	    obj_t super_940;
	    {
	       obj_t aux_3829;
	       {
		  object_t aux_3830;
		  aux_3830 = (object_t) (class_71);
		  aux_3829 = OBJECT_WIDENING(aux_3830);
	       }
	       super_940 = (((class_t) CREF(aux_3829))->its_super_214);
	    }
	    {
	       {
		  bool_t test1570_941;
		  test1570_941 = is_a__118___object(super_940, class_object_class);
		  if (test1570_941)
		    {
		       obj_t super_pred_id_124_942;
		       obj_t super_typed_158_943;
		       {
			  obj_t arg1581_950;
			  arg1581_950 = CNST_TABLE_REF(((long) 10));
			  {
			     obj_t list1582_951;
			     {
				obj_t arg1583_952;
				arg1583_952 = MAKE_PAIR(pred_id_222_938, BNIL);
				list1582_951 = MAKE_PAIR(arg1581_950, arg1583_952);
			     }
			     super_pred_id_124_942 = symbol_append_197___r4_symbols_6_4(list1582_951);
			  }
		       }
		       {
			  obj_t arg1585_954;
			  arg1585_954 = CNST_TABLE_REF(((long) 11));
			  {
			     obj_t list1587_956;
			     {
				obj_t arg1588_957;
				{
				   obj_t arg1589_958;
				   {
				      obj_t aux_3841;
				      {
					 type_t obj_2932;
					 obj_2932 = (type_t) (super_940);
					 aux_3841 = (((type_t) CREF(obj_2932))->id);
				      }
				      arg1589_958 = MAKE_PAIR(aux_3841, BNIL);
				   }
				   arg1588_957 = MAKE_PAIR(_4dots_199_tools_misc, arg1589_958);
				}
				list1587_956 = MAKE_PAIR(arg1585_954, arg1588_957);
			     }
			     super_typed_158_943 = symbol_append_197___r4_symbols_6_4(list1587_956);
			  }
		       }
		       {
			  obj_t arg1572_944;
			  {
			     obj_t arg1573_945;
			     arg1573_945 = CNST_TABLE_REF(((long) 13));
			     {
				obj_t list1576_947;
				{
				   obj_t arg1578_948;
				   arg1578_948 = MAKE_PAIR(BNIL, BNIL);
				   list1576_947 = MAKE_PAIR(arg1573_945, arg1578_948);
				}
				arg1572_944 = cons__138___r4_pairs_and_lists_6_3(pred_id_222_938, list1576_947);
			     }
			  }
			  return import_parser_53_module_impuse(module_73, arg1572_944);
		       }
		    }
		  else
		    {
		       return BUNSPEC;
		    }
	       }
	    }
	 }
      }
   }
}


/* _import-class-pred!3349 */ obj_t 
_import_class_pred_3349_50_object_access(obj_t env_3489, obj_t id_3490, obj_t class_3491, obj_t src_def_101_3492, obj_t module_3493)
{
   return import_class_pred__91_object_access(id_3490, (class_t) (class_3491), src_def_101_3492, module_3493);
}


/* make-class-makes! */ obj_t 
make_class_makes__132_object_access(obj_t widening_74, obj_t mk_id_77_75, obj_t id_76, obj_t type_77, obj_t slots_78, obj_t src_def_101_79, obj_t import_80)
{
   {
      obj_t mk_heap_id_73_968;
      obj_t mk_stack_id_29_969;
      {
	 obj_t arg1638_997;
	 arg1638_997 = CNST_TABLE_REF(((long) 18));
	 {
	    obj_t list1639_998;
	    {
	       obj_t arg1640_999;
	       {
		  obj_t arg1641_1000;
		  arg1641_1000 = MAKE_PAIR(id_76, BNIL);
		  arg1640_999 = MAKE_PAIR(arg1638_997, arg1641_1000);
	       }
	       list1639_998 = MAKE_PAIR(mk_id_77_75, arg1640_999);
	    }
	    mk_heap_id_73_968 = symbol_append_197___r4_symbols_6_4(list1639_998);
	 }
      }
      {
	 obj_t arg1646_1002;
	 arg1646_1002 = CNST_TABLE_REF(((long) 19));
	 {
	    obj_t list1647_1003;
	    {
	       obj_t arg1648_1004;
	       {
		  obj_t arg1649_1005;
		  arg1649_1005 = MAKE_PAIR(id_76, BNIL);
		  arg1648_1004 = MAKE_PAIR(arg1646_1002, arg1649_1005);
	       }
	       list1647_1003 = MAKE_PAIR(mk_id_77_75, arg1648_1004);
	    }
	    mk_stack_id_29_969 = symbol_append_197___r4_symbols_6_4(list1647_1003);
	 }
      }
      {
	 bool_t test1604_970;
	 {
	    bool_t test1637_996;
	    {
	       long n1_2933;
	       n1_2933 = (long) CINT(_optim__89_engine_param);
	       test1637_996 = (n1_2933 < ((long) 2));
	    }
	    if (test1637_996)
	      {
		 test1604_970 = ((bool_t) 1);
	      }
	    else
	      {
		 if (CBOOL(_optim_stack___57_engine_param))
		   {
		      test1604_970 = ((bool_t) 0);
		   }
		 else
		   {
		      test1604_970 = ((bool_t) 1);
		   }
	      }
	 }
	 if (test1604_970)
	   {
	      obj_t arg1605_971;
	      arg1605_971 = make_class_make__196_object_access(widening_74, malloc_env_105_object_tools, mk_heap_id_73_968, id_76, type_77, slots_78, src_def_101_79, import_80);
	      {
		 obj_t list1606_972;
		 list1606_972 = MAKE_PAIR(arg1605_971, BNIL);
		 return list1606_972;
	      }
	   }
	 else
	   {
	      {
		 obj_t arg1608_974;
		 {
		    obj_t arg1609_975;
		    obj_t arg1610_976;
		    arg1609_975 = CNST_TABLE_REF(((long) 4));
		    {
		       obj_t arg1618_981;
		       {
			  obj_t arg1624_986;
			  arg1624_986 = CNST_TABLE_REF(((long) 20));
			  {
			     obj_t list1626_988;
			     {
				obj_t arg1627_989;
				arg1627_989 = MAKE_PAIR(BNIL, BNIL);
				list1626_988 = MAKE_PAIR(mk_stack_id_29_969, arg1627_989);
			     }
			     arg1618_981 = cons__138___r4_pairs_and_lists_6_3(arg1624_986, list1626_988);
			  }
		       }
		       {
			  obj_t list1621_983;
			  {
			     obj_t arg1622_984;
			     arg1622_984 = MAKE_PAIR(BNIL, BNIL);
			     list1621_983 = MAKE_PAIR(arg1618_981, arg1622_984);
			  }
			  arg1610_976 = cons__138___r4_pairs_and_lists_6_3(mk_heap_id_73_968, list1621_983);
		       }
		    }
		    {
		       obj_t list1613_978;
		       {
			  obj_t arg1615_979;
			  arg1615_979 = MAKE_PAIR(BNIL, BNIL);
			  list1613_978 = MAKE_PAIR(arg1610_976, arg1615_979);
		       }
		       arg1608_974 = cons__138___r4_pairs_and_lists_6_3(arg1609_975, list1613_978);
		    }
		 }
		 produce_module_clause__172_module_module(arg1608_974);
	      }
	      {
		 obj_t arg1630_991;
		 obj_t arg1632_992;
		 arg1630_991 = make_class_make__196_object_access(widening_74, alloca_env_212_object_tools, mk_stack_id_29_969, id_76, type_77, slots_78, src_def_101_79, import_80);
		 arg1632_992 = make_class_make__196_object_access(widening_74, malloc_env_105_object_tools, mk_heap_id_73_968, id_76, type_77, slots_78, src_def_101_79, import_80);
		 {
		    obj_t list1633_993;
		    {
		       obj_t arg1634_994;
		       arg1634_994 = MAKE_PAIR(arg1632_992, BNIL);
		       list1633_993 = MAKE_PAIR(arg1630_991, arg1634_994);
		    }
		    return list1633_993;
		 }
	      }
	   }
      }
   }
}


/* _make-class-makes! */ obj_t 
_make_class_makes__119_object_access(obj_t env_3494, obj_t widening_3495, obj_t mk_id_77_3496, obj_t id_3497, obj_t type_3498, obj_t slots_3499, obj_t src_def_101_3500, obj_t import_3501)
{
   return make_class_makes__132_object_access(widening_3495, mk_id_77_3496, id_3497, type_3498, slots_3499, src_def_101_3500, import_3501);
}


/* make-class-make-formals */ obj_t 
make_class_make_formals_23_object_access(obj_t slots_81)
{
   {
      obj_t slots_1007;
      obj_t formals_1008;
      slots_1007 = slots_81;
      formals_1008 = BNIL;
    loop_1009:
      if (NULLP(slots_1007))
	{
	   return reverse__39___r4_pairs_and_lists_6_3(formals_1008);
	}
      else
	{
	   bool_t test_3893;
	   {
	      obj_t aux_3894;
	      {
		 obj_t aux_3895;
		 aux_3895 = CAR(slots_1007);
		 aux_3894 = STRUCT_REF(aux_3895, ((long) 11));
	      }
	      test_3893 = CBOOL(aux_3894);
	   }
	   if (test_3893)
	     {
		{
		   obj_t slots_3899;
		   slots_3899 = CDR(slots_1007);
		   slots_1007 = slots_3899;
		   goto loop_1009;
		}
	     }
	   else
	     {
		{
		   obj_t arg1656_1014;
		   obj_t arg1657_1015;
		   arg1656_1014 = CDR(slots_1007);
		   {
		      obj_t aux_3902;
		      {
			 obj_t aux_3903;
			 aux_3903 = CAR(slots_1007);
			 aux_3902 = STRUCT_REF(aux_3903, ((long) 0));
		      }
		      arg1657_1015 = MAKE_PAIR(aux_3902, formals_1008);
		   }
		   {
		      obj_t formals_3908;
		      obj_t slots_3907;
		      slots_3907 = arg1656_1014;
		      formals_3908 = arg1657_1015;
		      formals_1008 = formals_3908;
		      slots_1007 = slots_3907;
		      goto loop_1009;
		   }
		}
	     }
	}
   }
}


/* _make-class-make-formals */ obj_t 
_make_class_make_formals_78_object_access(obj_t env_3508, obj_t slots_3509)
{
   return make_class_make_formals_23_object_access(slots_3509);
}


/* make-class-make-typed-formals */ obj_t 
make_class_make_typed_formals_184_object_access(obj_t slots_82)
{
   {
      obj_t slots_1019;
      obj_t formals_1020;
      slots_1019 = slots_82;
      formals_1020 = BNIL;
    loop_1021:
      if (NULLP(slots_1019))
	{
	   return reverse__39___r4_pairs_and_lists_6_3(formals_1020);
	}
      else
	{
	   bool_t test_3913;
	   {
	      obj_t aux_3914;
	      {
		 obj_t aux_3915;
		 aux_3915 = CAR(slots_1019);
		 aux_3914 = STRUCT_REF(aux_3915, ((long) 11));
	      }
	      test_3913 = CBOOL(aux_3914);
	   }
	   if (test_3913)
	     {
		{
		   obj_t slots_3919;
		   slots_3919 = CDR(slots_1019);
		   slots_1019 = slots_3919;
		   goto loop_1021;
		}
	     }
	   else
	     {
		{
		   obj_t arg1667_1026;
		   obj_t arg1668_1027;
		   arg1667_1026 = CDR(slots_1019);
		   {
		      obj_t arg1669_1028;
		      {
			 obj_t arg1670_1029;
			 {
			    obj_t aux_3922;
			    aux_3922 = CAR(slots_1019);
			    arg1670_1029 = STRUCT_REF(aux_3922, ((long) 0));
			 }
			 {
			    obj_t list1673_1031;
			    {
			       obj_t arg1675_1032;
			       {
				  obj_t arg1676_1033;
				  {
				     obj_t aux_3925;
				     {
					type_t obj_2965;
					{
					   obj_t aux_3926;
					   {
					      obj_t aux_3927;
					      aux_3927 = CAR(slots_1019);
					      aux_3926 = STRUCT_REF(aux_3927, ((long) 2));
					   }
					   obj_2965 = (type_t) (aux_3926);
					}
					aux_3925 = (((type_t) CREF(obj_2965))->id);
				     }
				     arg1676_1033 = MAKE_PAIR(aux_3925, BNIL);
				  }
				  arg1675_1032 = MAKE_PAIR(_4dots_199_tools_misc, arg1676_1033);
			       }
			       list1673_1031 = MAKE_PAIR(arg1670_1029, arg1675_1032);
			    }
			    arg1669_1028 = symbol_append_197___r4_symbols_6_4(list1673_1031);
			 }
		      }
		      arg1668_1027 = MAKE_PAIR(arg1669_1028, formals_1020);
		   }
		   {
		      obj_t formals_3938;
		      obj_t slots_3937;
		      slots_3937 = arg1667_1026;
		      formals_3938 = arg1668_1027;
		      formals_1020 = formals_3938;
		      slots_1019 = slots_3937;
		      goto loop_1021;
		   }
		}
	     }
	}
   }
}


/* _make-class-make-typed-formals */ obj_t 
_make_class_make_typed_formals_151_object_access(obj_t env_3510, obj_t slots_3511)
{
   return make_class_make_typed_formals_184_object_access(slots_3511);
}


/* make-class-make! */ obj_t 
make_class_make__196_object_access(obj_t widening_83, obj_t alloc_84, obj_t mk_id_77_85, obj_t id_86, obj_t type_87, obj_t slots_88, obj_t src_def_101_89, obj_t import_90)
{
   {
      obj_t tid_1039;
      {
	 type_t obj_2968;
	 obj_2968 = (type_t) (type_87);
	 tid_1039 = (((type_t) CREF(obj_2968))->id);
      }
      {
	 global_t holder_1040;
	 {
	    class_t obj_2969;
	    obj_2969 = (class_t) (type_87);
	    {
	       obj_t aux_3943;
	       {
		  object_t aux_3944;
		  aux_3944 = (object_t) (obj_2969);
		  aux_3943 = OBJECT_WIDENING(aux_3944);
	       }
	       holder_1040 = (((class_t) CREF(aux_3943))->holder);
	    }
	 }
	 {
	    obj_t constrs_1041;
	    constrs_1041 = find_class_constructors_231_object_class((class_t) (type_87));
	    {
	       obj_t mk_tid_99_1042;
	       {
		  obj_t list1854_1209;
		  {
		     obj_t arg1856_1210;
		     {
			obj_t arg1857_1211;
			arg1857_1211 = MAKE_PAIR(tid_1039, BNIL);
			arg1856_1210 = MAKE_PAIR(_4dots_199_tools_misc, arg1857_1211);
		     }
		     list1854_1209 = MAKE_PAIR(mk_id_77_85, arg1856_1210);
		  }
		  mk_tid_99_1042 = symbol_append_197___r4_symbols_6_4(list1854_1209);
	       }
	       {
		  obj_t f_ids_164_1043;
		  f_ids_164_1043 = make_class_make_formals_23_object_access(slots_88);
		  {
		     obj_t f_tids_193_1044;
		     f_tids_193_1044 = make_class_make_typed_formals_184_object_access(slots_88);
		     {
			obj_t new_1045;
			new_1045 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 21)), BEOA);
			{
			   obj_t rid_1046;
			   rid_1046 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 22)), BEOA);
			   {
			      obj_t rtid_1047;
			      {
				 obj_t list1849_1204;
				 {
				    obj_t arg1850_1205;
				    {
				       obj_t aux_3962;
				       aux_3962 = CNST_TABLE_REF(((long) 23));
				       arg1850_1205 = MAKE_PAIR(aux_3962, BNIL);
				    }
				    list1849_1204 = MAKE_PAIR(rid_1046, arg1850_1205);
				 }
				 rtid_1047 = symbol_append_197___r4_symbols_6_4(list1849_1204);
			      }
			      {
				 {
				    obj_t arg1682_1048;
				    {
				       obj_t arg1683_1049;
				       {
					  obj_t arg1689_1054;
					  {
					     obj_t arg1691_1056;
					     obj_t arg1692_1057;
					     {
						bool_t test1693_1058;
						{
						   long n1_2970;
						   n1_2970 = (long) CINT(_optim__89_engine_param);
						   test1693_1058 = (n1_2970 >= ((long) 2));
						}
						if (test1693_1058)
						  {
						     arg1691_1056 = CNST_TABLE_REF(((long) 24));
						  }
						else
						  {
						     arg1691_1056 = BNIL;
						  }
					     }
					     {
						obj_t arg1694_1059;
						{
						   obj_t arg1698_1062;
						   arg1698_1062 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						   arg1694_1059 = append_2_18___r4_pairs_and_lists_6_3(f_tids_193_1044, arg1698_1062);
						}
						{
						   obj_t list1695_1060;
						   list1695_1060 = MAKE_PAIR(arg1694_1059, BNIL);
						   arg1692_1057 = cons__138___r4_pairs_and_lists_6_3(mk_tid_99_1042, list1695_1060);
						}
					     }
					     arg1689_1054 = append_2_18___r4_pairs_and_lists_6_3(arg1691_1056, arg1692_1057);
					  }
					  arg1683_1049 = cons__138___r4_pairs_and_lists_6_3(arg1689_1054, BNIL);
				       }
				       {
					  obj_t list1685_1051;
					  {
					     obj_t arg1686_1052;
					     arg1686_1052 = MAKE_PAIR(BNIL, BNIL);
					     list1685_1051 = MAKE_PAIR(arg1683_1049, arg1686_1052);
					  }
					  arg1682_1048 = cons__138___r4_pairs_and_lists_6_3(import_90, list1685_1051);
				       }
				    }
				    produce_module_clause__172_module_module(arg1682_1048);
				 }
				 {
				    obj_t arg1701_1065;
				    {
				       obj_t arg1704_1068;
				       obj_t arg1705_1069;
				       obj_t arg1706_1070;
				       {
					  bool_t test1712_1076;
					  {
					     long n1_2972;
					     n1_2972 = (long) CINT(_optim__89_engine_param);
					     test1712_1076 = (n1_2972 >= ((long) 2));
					  }
					  if (test1712_1076)
					    {
					       arg1704_1068 = CNST_TABLE_REF(((long) 15));
					    }
					  else
					    {
					       arg1704_1068 = CNST_TABLE_REF(((long) 25));
					    }
				       }
				       {
					  obj_t arg1713_1077;
					  {
					     obj_t arg1717_1080;
					     arg1717_1080 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					     arg1713_1077 = append_2_18___r4_pairs_and_lists_6_3(f_tids_193_1044, arg1717_1080);
					  }
					  {
					     obj_t list1714_1078;
					     list1714_1078 = MAKE_PAIR(arg1713_1077, BNIL);
					     arg1705_1069 = cons__138___r4_pairs_and_lists_6_3(mk_tid_99_1042, list1714_1078);
					  }
				       }
				       {
					  obj_t arg1720_1083;
					  obj_t arg1721_1084;
					  obj_t arg1722_1085;
					  arg1720_1083 = CNST_TABLE_REF(((long) 26));
					  {
					     obj_t arg1726_1089;
					     {
						obj_t arg1730_1093;
						obj_t arg1731_1094;
						{
						   obj_t list1740_1099;
						   {
						      obj_t arg1743_1100;
						      {
							 obj_t arg1744_1101;
							 arg1744_1101 = MAKE_PAIR(tid_1039, BNIL);
							 arg1743_1100 = MAKE_PAIR(_4dots_199_tools_misc, arg1744_1101);
						      }
						      list1740_1099 = MAKE_PAIR(new_1045, arg1743_1100);
						   }
						   arg1730_1093 = symbol_append_197___r4_symbols_6_4(list1740_1099);
						}
						arg1731_1094 = PROCEDURE_ENTRY(alloc_84) (alloc_84, type_87, BINT(((long) 1)), BEOA);
						{
						   obj_t list1733_1096;
						   {
						      obj_t arg1738_1097;
						      arg1738_1097 = MAKE_PAIR(BNIL, BNIL);
						      list1733_1096 = MAKE_PAIR(arg1731_1094, arg1738_1097);
						   }
						   arg1726_1089 = cons__138___r4_pairs_and_lists_6_3(arg1730_1093, list1733_1096);
						}
					     }
					     {
						obj_t list1728_1091;
						list1728_1091 = MAKE_PAIR(BNIL, BNIL);
						arg1721_1084 = cons__138___r4_pairs_and_lists_6_3(arg1726_1089, list1728_1091);
					     }
					  }
					  {
					     obj_t arg1746_1103;
					     obj_t arg1747_1104;
					     {
						bool_t test_4003;
						{
						   obj_t aux_4004;
						   aux_4004 = CNST_TABLE_REF(((long) 27));
						   test_4003 = (widening_83 == aux_4004);
						}
						if (test_4003)
						  {
						     arg1746_1103 = BNIL;
						  }
						else
						  {
						     obj_t arg1749_1106;
						     obj_t arg1753_1107;
						     {
							obj_t arg1760_1112;
							obj_t arg1761_1113;
							arg1760_1112 = CNST_TABLE_REF(((long) 28));
							{
							   obj_t arg1768_1119;
							   obj_t arg1769_1120;
							   arg1768_1119 = CNST_TABLE_REF(((long) 29));
							   {
							      obj_t arg1774_1125;
							      obj_t arg1776_1126;
							      obj_t arg1777_1127;
							      arg1774_1125 = CNST_TABLE_REF(((long) 17));
							      arg1776_1126 = (((global_t) CREF(holder_1040))->id);
							      arg1777_1127 = (((global_t) CREF(holder_1040))->module);
							      {
								 obj_t list1779_1129;
								 {
								    obj_t arg1780_1130;
								    {
								       obj_t arg1781_1131;
								       arg1781_1131 = MAKE_PAIR(BNIL, BNIL);
								       arg1780_1130 = MAKE_PAIR(arg1777_1127, arg1781_1131);
								    }
								    list1779_1129 = MAKE_PAIR(arg1776_1126, arg1780_1130);
								 }
								 arg1769_1120 = cons__138___r4_pairs_and_lists_6_3(arg1774_1125, list1779_1129);
							      }
							   }
							   {
							      obj_t list1771_1122;
							      {
								 obj_t arg1772_1123;
								 arg1772_1123 = MAKE_PAIR(BNIL, BNIL);
								 list1771_1122 = MAKE_PAIR(arg1769_1120, arg1772_1123);
							      }
							      arg1761_1113 = cons__138___r4_pairs_and_lists_6_3(arg1768_1119, list1771_1122);
							   }
							}
							{
							   obj_t list1763_1115;
							   {
							      obj_t arg1765_1116;
							      {
								 obj_t arg1766_1117;
								 arg1766_1117 = MAKE_PAIR(BNIL, BNIL);
								 arg1765_1116 = MAKE_PAIR(arg1761_1113, arg1766_1117);
							      }
							      list1763_1115 = MAKE_PAIR(new_1045, arg1765_1116);
							   }
							   arg1749_1106 = cons__138___r4_pairs_and_lists_6_3(arg1760_1112, list1763_1115);
							}
						     }
						     {
							obj_t arg1786_1133;
							arg1786_1133 = CNST_TABLE_REF(((long) 30));
							{
							   obj_t list1789_1135;
							   {
							      obj_t arg1790_1136;
							      {
								 obj_t arg1791_1137;
								 arg1791_1137 = MAKE_PAIR(BNIL, BNIL);
								 arg1790_1136 = MAKE_PAIR(BFALSE, arg1791_1137);
							      }
							      list1789_1135 = MAKE_PAIR(new_1045, arg1790_1136);
							   }
							   arg1753_1107 = cons__138___r4_pairs_and_lists_6_3(arg1786_1133, list1789_1135);
							}
						     }
						     {
							obj_t list1756_1109;
							{
							   obj_t arg1758_1110;
							   arg1758_1110 = MAKE_PAIR(BNIL, BNIL);
							   list1756_1109 = MAKE_PAIR(arg1753_1107, arg1758_1110);
							}
							arg1746_1103 = cons__138___r4_pairs_and_lists_6_3(arg1749_1106, list1756_1109);
						     }
						  }
					     }
					     {
						obj_t arg1794_1140;
						{
						   obj_t arg1799_1144;
						   obj_t arg1800_1145;
						   obj_t arg1802_1146;
						   arg1799_1144 = CNST_TABLE_REF(((long) 26));
						   if (NULLP(f_tids_193_1044))
						     {
							arg1800_1145 = BNIL;
						     }
						   else
						     {
							obj_t head1219_1153;
							head1219_1153 = MAKE_PAIR(BNIL, BNIL);
							{
							   obj_t ll1217_1154;
							   obj_t ll1218_1155;
							   obj_t tail1220_1156;
							   ll1217_1154 = f_tids_193_1044;
							   ll1218_1155 = f_ids_164_1043;
							   tail1220_1156 = head1219_1153;
							 lname1222_1157:
							   if (NULLP(ll1217_1154))
							     {
								arg1800_1145 = CDR(head1219_1153);
							     }
							   else
							     {
								obj_t newtail1221_1159;
								{
								   obj_t arg1810_1162;
								   {
								      obj_t ft_1164;
								      obj_t f_1165;
								      ft_1164 = CAR(ll1217_1154);
								      f_1165 = CAR(ll1218_1155);
								      {
									 obj_t list1813_1167;
									 {
									    obj_t arg1814_1168;
									    arg1814_1168 = MAKE_PAIR(BNIL, BNIL);
									    list1813_1167 = MAKE_PAIR(f_1165, arg1814_1168);
									 }
									 arg1810_1162 = cons__138___r4_pairs_and_lists_6_3(ft_1164, list1813_1167);
								      }
								   }
								   newtail1221_1159 = MAKE_PAIR(arg1810_1162, BNIL);
								}
								SET_CDR(tail1220_1156, newtail1221_1159);
								{
								   obj_t tail1220_4049;
								   obj_t ll1218_4047;
								   obj_t ll1217_4045;
								   ll1217_4045 = CDR(ll1217_1154);
								   ll1218_4047 = CDR(ll1218_1155);
								   tail1220_4049 = newtail1221_1159;
								   tail1220_1156 = tail1220_4049;
								   ll1218_1155 = ll1218_4047;
								   ll1217_1154 = ll1217_4045;
								   goto lname1222_1157;
								}
							     }
							}
						     }
						   {
						      obj_t arg1818_1172;
						      obj_t arg1820_1173;
						      arg1818_1172 = make_class_slot_make__242_object_access(type_87, new_1045, rid_1046, rtid_1047, slots_88, f_ids_164_1043);
						      {
							 obj_t arg1821_1174;
							 {
							    obj_t arg1823_1176;
							    obj_t arg1824_1177;
							    {
							       bool_t test_4051;
							       if (PAIRP(constrs_1041))
								 {
								    bool_t test_4054;
								    {
								       obj_t aux_4055;
								       aux_4055 = CNST_TABLE_REF(((long) 27));
								       test_4054 = (widening_83 == aux_4055);
								    }
								    if (test_4054)
								      {
									 test_4051 = ((bool_t) 0);
								      }
								    else
								      {
									 test_4051 = ((bool_t) 1);
								      }
								 }
							       else
								 {
								    test_4051 = ((bool_t) 0);
								 }
							       if (test_4051)
								 {
								    if (NULLP(constrs_1041))
								      {
									 arg1823_1176 = BNIL;
								      }
								    else
								      {
									 obj_t head1225_1181;
									 head1225_1181 = MAKE_PAIR(BNIL, BNIL);
									 {
									    obj_t l1223_1182;
									    obj_t tail1226_1183;
									    l1223_1182 = constrs_1041;
									    tail1226_1183 = head1225_1181;
									  lname1224_1184:
									    if (NULLP(l1223_1182))
									      {
										 arg1823_1176 = CDR(head1225_1181);
									      }
									    else
									      {
										 obj_t newtail1227_1186;
										 {
										    obj_t arg1830_1188;
										    {
										       obj_t constr_1190;
										       constr_1190 = CAR(l1223_1182);
										       {
											  obj_t list1833_1192;
											  {
											     obj_t arg1834_1193;
											     arg1834_1193 = MAKE_PAIR(BNIL, BNIL);
											     list1833_1192 = MAKE_PAIR(new_1045, arg1834_1193);
											  }
											  arg1830_1188 = cons__138___r4_pairs_and_lists_6_3(constr_1190, list1833_1192);
										       }
										    }
										    newtail1227_1186 = MAKE_PAIR(arg1830_1188, BNIL);
										 }
										 SET_CDR(tail1226_1183, newtail1227_1186);
										 {
										    obj_t tail1226_4072;
										    obj_t l1223_4070;
										    l1223_4070 = CDR(l1223_1182);
										    tail1226_4072 = newtail1227_1186;
										    tail1226_1183 = tail1226_4072;
										    l1223_1182 = l1223_4070;
										    goto lname1224_1184;
										 }
									      }
									 }
								      }
								 }
							       else
								 {
								    arg1823_1176 = BNIL;
								 }
							    }
							    {
							       obj_t list1844_1201;
							       list1844_1201 = MAKE_PAIR(BNIL, BNIL);
							       arg1824_1177 = cons__138___r4_pairs_and_lists_6_3(new_1045, list1844_1201);
							    }
							    arg1821_1174 = append_2_18___r4_pairs_and_lists_6_3(arg1823_1176, arg1824_1177);
							 }
							 arg1820_1173 = cons__138___r4_pairs_and_lists_6_3(arg1821_1174, BNIL);
						      }
						      arg1802_1146 = append_2_18___r4_pairs_and_lists_6_3(arg1818_1172, arg1820_1173);
						   }
						   {
						      obj_t list1803_1147;
						      {
							 obj_t arg1804_1148;
							 arg1804_1148 = MAKE_PAIR(arg1802_1146, BNIL);
							 list1803_1147 = MAKE_PAIR(arg1800_1145, arg1804_1148);
						      }
						      arg1794_1140 = cons__138___r4_pairs_and_lists_6_3(arg1799_1144, list1803_1147);
						   }
						}
						{
						   obj_t list1796_1142;
						   list1796_1142 = MAKE_PAIR(BNIL, BNIL);
						   arg1747_1104 = cons__138___r4_pairs_and_lists_6_3(arg1794_1140, list1796_1142);
						}
					     }
					     arg1722_1085 = append_2_18___r4_pairs_and_lists_6_3(arg1746_1103, arg1747_1104);
					  }
					  {
					     obj_t list1723_1086;
					     {
						obj_t arg1724_1087;
						arg1724_1087 = MAKE_PAIR(arg1722_1085, BNIL);
						list1723_1086 = MAKE_PAIR(arg1721_1084, arg1724_1087);
					     }
					     arg1706_1070 = cons__138___r4_pairs_and_lists_6_3(arg1720_1083, list1723_1086);
					  }
				       }
				       {
					  obj_t list1708_1072;
					  {
					     obj_t arg1709_1073;
					     {
						obj_t arg1710_1074;
						arg1710_1074 = MAKE_PAIR(BNIL, BNIL);
						arg1709_1073 = MAKE_PAIR(arg1706_1070, arg1710_1074);
					     }
					     list1708_1072 = MAKE_PAIR(arg1705_1069, arg1709_1073);
					  }
					  arg1701_1065 = cons__138___r4_pairs_and_lists_6_3(arg1704_1068, list1708_1072);
				       }
				    }
				    {
				       obj_t list1702_1066;
				       list1702_1066 = MAKE_PAIR(src_def_101_89, BNIL);
				       return epairify_object_access(arg1701_1065, list1702_1066);
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* make-class-slot-make! */ obj_t 
make_class_slot_make__242_object_access(obj_t type_91, obj_t new_92, obj_t rid_93, obj_t rtid_94, obj_t slots_95, obj_t f_ids_164_96)
{
   {
      obj_t slot_1229;
      obj_t formal_1230;
      {
	 obj_t slots_1214;
	 obj_t f_ids_164_1215;
	 obj_t res_1216;
	 slots_1214 = slots_95;
	 f_ids_164_1215 = f_ids_164_96;
	 res_1216 = BNIL;
       loop_1217:
	 if (NULLP(slots_1214))
	   {
	      return reverse__39___r4_pairs_and_lists_6_3(res_1216);
	   }
	 else
	   {
	      bool_t test_4096;
	      {
		 obj_t aux_4097;
		 {
		    obj_t aux_4098;
		    aux_4098 = CAR(slots_1214);
		    aux_4097 = STRUCT_REF(aux_4098, ((long) 11));
		 }
		 test_4096 = CBOOL(aux_4097);
	      }
	      if (test_4096)
		{
		   {
		      obj_t slots_4102;
		      slots_4102 = CDR(slots_1214);
		      slots_1214 = slots_4102;
		      goto loop_1217;
		   }
		}
	      else
		{
		   {
		      obj_t arg1863_1222;
		      obj_t arg1864_1223;
		      obj_t arg1865_1224;
		      arg1863_1222 = CDR(slots_1214);
		      arg1864_1223 = CDR(f_ids_164_1215);
		      {
			 obj_t arg1866_1225;
			 slot_1229 = CAR(slots_1214);
			 formal_1230 = CAR(f_ids_164_1215);
			 {
			    obj_t loop_1232;
			    loop_1232 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 31)), BEOA);
			    {
			       bool_t test_4109;
			       {
				  obj_t aux_4110;
				  aux_4110 = STRUCT_REF(slot_1229, ((long) 5));
				  test_4109 = CBOOL(aux_4110);
			       }
			       if (test_4109)
				 {
				    {
				       obj_t arg1874_1234;
				       obj_t arg1875_1235;
				       obj_t arg1876_1236;
				       arg1874_1234 = CNST_TABLE_REF(((long) 32));
				       {
					  obj_t arg1883_1242;
					  {
					     obj_t arg1884_1243;
					     obj_t arg1885_1244;
					     arg1884_1243 = STRUCT_REF(slot_1229, ((long) 2));
					     {
						obj_t list1887_1246;
						{
						   obj_t arg1888_1247;
						   {
						      obj_t aux_4115;
						      aux_4115 = CNST_TABLE_REF(((long) 33));
						      arg1888_1247 = MAKE_PAIR(aux_4115, BNIL);
						   }
						   list1887_1246 = MAKE_PAIR(formal_1230, arg1888_1247);
						}
						arg1885_1244 = symbol_append_197___r4_symbols_6_4(list1887_1246);
					     }
					     arg1883_1242 = malloc_object_tools((type_t) (arg1884_1243), arg1885_1244);
					  }
					  arg1875_1235 = make_pragma_indexed_init_set__66_object_tools((type_t) (type_91), slot_1229, new_92, arg1883_1242);
				       }
				       {
					  obj_t arg1892_1249;
					  obj_t arg1893_1250;
					  obj_t arg1894_1251;
					  arg1892_1249 = CNST_TABLE_REF(((long) 34));
					  {
					     obj_t arg1900_1257;
					     {
						obj_t arg1905_1261;
						obj_t arg1906_1262;
						{
						   obj_t list1913_1269;
						   list1913_1269 = MAKE_PAIR(BNIL, BNIL);
						   arg1905_1261 = cons__138___r4_pairs_and_lists_6_3(rtid_94, list1913_1269);
						}
						{
						   obj_t arg1915_1271;
						   obj_t arg1916_1272;
						   obj_t arg1917_1273;
						   obj_t arg1918_1274;
						   arg1915_1271 = CNST_TABLE_REF(((long) 35));
						   {
						      obj_t arg1927_1281;
						      obj_t arg1928_1282;
						      arg1927_1281 = CNST_TABLE_REF(((long) 36));
						      {
							 obj_t list1935_1289;
							 {
							    obj_t arg1936_1290;
							    {
							       obj_t aux_4129;
							       aux_4129 = CNST_TABLE_REF(((long) 33));
							       arg1936_1290 = MAKE_PAIR(aux_4129, BNIL);
							    }
							    list1935_1289 = MAKE_PAIR(formal_1230, arg1936_1290);
							 }
							 arg1928_1282 = symbol_append_197___r4_symbols_6_4(list1935_1289);
						      }
						      {
							 obj_t list1930_1284;
							 {
							    obj_t arg1931_1285;
							    {
							       obj_t arg1932_1286;
							       arg1932_1286 = MAKE_PAIR(BNIL, BNIL);
							       arg1931_1285 = MAKE_PAIR(arg1928_1282, arg1932_1286);
							    }
							    list1930_1284 = MAKE_PAIR(rid_93, arg1931_1285);
							 }
							 arg1916_1272 = cons__138___r4_pairs_and_lists_6_3(arg1927_1281, list1930_1284);
						      }
						   }
						   {
						      obj_t arg1938_1292;
						      obj_t arg1939_1293;
						      arg1938_1292 = CNST_TABLE_REF(((long) 37));
						      arg1939_1293 = CNST_TABLE_REF(((long) 38));
						      {
							 obj_t list1941_1295;
							 {
							    obj_t arg1942_1296;
							    arg1942_1296 = MAKE_PAIR(BNIL, BNIL);
							    list1941_1295 = MAKE_PAIR(arg1939_1293, arg1942_1296);
							 }
							 arg1917_1273 = cons__138___r4_pairs_and_lists_6_3(arg1938_1292, list1941_1295);
						      }
						   }
						   {
						      obj_t arg1944_1298;
						      obj_t arg1945_1299;
						      obj_t arg1947_1300;
						      arg1944_1298 = CNST_TABLE_REF(((long) 32));
						      arg1945_1299 = make_pragma_indexed_set__widening_24_object_tools((type_t) (type_91), slot_1229, new_92, formal_1230, rid_93, BFALSE);
						      {
							 obj_t arg1953_1306;
							 {
							    obj_t arg1958_1311;
							    arg1958_1311 = CNST_TABLE_REF(((long) 39));
							    {
							       obj_t list1961_1314;
							       {
								  obj_t arg1962_1315;
								  {
								     obj_t arg1963_1316;
								     arg1963_1316 = MAKE_PAIR(BNIL, BNIL);
								     {
									obj_t aux_4148;
									aux_4148 = BINT(((long) 1));
									arg1962_1315 = MAKE_PAIR(aux_4148, arg1963_1316);
								     }
								  }
								  list1961_1314 = MAKE_PAIR(rid_93, arg1962_1315);
							       }
							       arg1953_1306 = cons__138___r4_pairs_and_lists_6_3(arg1958_1311, list1961_1314);
							    }
							 }
							 {
							    obj_t list1955_1308;
							    {
							       obj_t arg1956_1309;
							       arg1956_1309 = MAKE_PAIR(BNIL, BNIL);
							       list1955_1308 = MAKE_PAIR(arg1953_1306, arg1956_1309);
							    }
							    arg1947_1300 = cons__138___r4_pairs_and_lists_6_3(loop_1232, list1955_1308);
							 }
						      }
						      {
							 obj_t list1949_1302;
							 {
							    obj_t arg1950_1303;
							    {
							       obj_t arg1951_1304;
							       arg1951_1304 = MAKE_PAIR(BNIL, BNIL);
							       arg1950_1303 = MAKE_PAIR(arg1947_1300, arg1951_1304);
							    }
							    list1949_1302 = MAKE_PAIR(arg1945_1299, arg1950_1303);
							 }
							 arg1918_1274 = cons__138___r4_pairs_and_lists_6_3(arg1944_1298, list1949_1302);
						      }
						   }
						   {
						      obj_t list1920_1276;
						      {
							 obj_t arg1921_1277;
							 {
							    obj_t arg1923_1278;
							    {
							       obj_t arg1924_1279;
							       arg1924_1279 = MAKE_PAIR(BNIL, BNIL);
							       arg1923_1278 = MAKE_PAIR(arg1918_1274, arg1924_1279);
							    }
							    arg1921_1277 = MAKE_PAIR(arg1917_1273, arg1923_1278);
							 }
							 list1920_1276 = MAKE_PAIR(arg1916_1272, arg1921_1277);
						      }
						      arg1906_1262 = cons__138___r4_pairs_and_lists_6_3(arg1915_1271, list1920_1276);
						   }
						}
						{
						   obj_t list1908_1264;
						   {
						      obj_t arg1909_1265;
						      {
							 obj_t arg1910_1266;
							 arg1910_1266 = MAKE_PAIR(BNIL, BNIL);
							 arg1909_1265 = MAKE_PAIR(arg1906_1262, arg1910_1266);
						      }
						      list1908_1264 = MAKE_PAIR(arg1905_1261, arg1909_1265);
						   }
						   arg1900_1257 = cons__138___r4_pairs_and_lists_6_3(loop_1232, list1908_1264);
						}
					     }
					     {
						obj_t list1902_1259;
						list1902_1259 = MAKE_PAIR(BNIL, BNIL);
						arg1893_1250 = cons__138___r4_pairs_and_lists_6_3(arg1900_1257, list1902_1259);
					     }
					  }
					  {
					     obj_t list1968_1320;
					     {
						obj_t arg1970_1321;
						arg1970_1321 = MAKE_PAIR(BNIL, BNIL);
						{
						   obj_t aux_4172;
						   aux_4172 = BINT(((long) 0));
						   list1968_1320 = MAKE_PAIR(aux_4172, arg1970_1321);
						}
					     }
					     arg1894_1251 = cons__138___r4_pairs_and_lists_6_3(loop_1232, list1968_1320);
					  }
					  {
					     obj_t list1896_1253;
					     {
						obj_t arg1897_1254;
						{
						   obj_t arg1898_1255;
						   arg1898_1255 = MAKE_PAIR(BNIL, BNIL);
						   arg1897_1254 = MAKE_PAIR(arg1894_1251, arg1898_1255);
						}
						list1896_1253 = MAKE_PAIR(arg1893_1250, arg1897_1254);
					     }
					     arg1876_1236 = cons__138___r4_pairs_and_lists_6_3(arg1892_1249, list1896_1253);
					  }
				       }
				       {
					  obj_t list1878_1238;
					  {
					     obj_t arg1879_1239;
					     {
						obj_t arg1880_1240;
						arg1880_1240 = MAKE_PAIR(BNIL, BNIL);
						arg1879_1239 = MAKE_PAIR(arg1876_1236, arg1880_1240);
					     }
					     list1878_1238 = MAKE_PAIR(arg1875_1235, arg1879_1239);
					  }
					  arg1866_1225 = cons__138___r4_pairs_and_lists_6_3(arg1874_1234, list1878_1238);
				       }
				    }
				 }
			       else
				 {
				    bool_t test_4184;
				    {
				       obj_t aux_4185;
				       aux_4185 = STRUCT_REF(slot_1229, ((long) 3));
				       test_4184 = CBOOL(aux_4185);
				    }
				    if (test_4184)
				      {
					 {
					    obj_t arg1973_1324;
					    obj_t arg1974_1325;
					    obj_t arg1975_1326;
					    arg1973_1324 = CNST_TABLE_REF(((long) 34));
					    {
					       obj_t arg1982_1332;
					       {
						  obj_t arg1986_1336;
						  obj_t arg1987_1337;
						  {
						     obj_t list1994_1344;
						     list1994_1344 = MAKE_PAIR(BNIL, BNIL);
						     arg1986_1336 = cons__138___r4_pairs_and_lists_6_3(rtid_94, list1994_1344);
						  }
						  {
						     obj_t arg1998_1346;
						     obj_t arg2000_1347;
						     obj_t arg2001_1348;
						     obj_t arg2002_1349;
						     arg1998_1346 = CNST_TABLE_REF(((long) 35));
						     {
							obj_t arg2012_1356;
							obj_t arg2013_1357;
							arg2012_1356 = CNST_TABLE_REF(((long) 36));
							{
							   obj_t arg2019_1363;
							   obj_t arg2020_1364;
							   arg2019_1363 = CNST_TABLE_REF(((long) 40));
							   arg2020_1364 = STRUCT_REF(slot_1229, ((long) 4));
							   {
							      obj_t list2022_1366;
							      {
								 obj_t arg2023_1367;
								 arg2023_1367 = MAKE_PAIR(BNIL, BNIL);
								 list2022_1366 = MAKE_PAIR(arg2020_1364, arg2023_1367);
							      }
							      arg2013_1357 = cons__138___r4_pairs_and_lists_6_3(arg2019_1363, list2022_1366);
							   }
							}
							{
							   obj_t list2015_1359;
							   {
							      obj_t arg2016_1360;
							      {
								 obj_t arg2017_1361;
								 arg2017_1361 = MAKE_PAIR(BNIL, BNIL);
								 arg2016_1360 = MAKE_PAIR(arg2013_1357, arg2017_1361);
							      }
							      list2015_1359 = MAKE_PAIR(rid_93, arg2016_1360);
							   }
							   arg2000_1347 = cons__138___r4_pairs_and_lists_6_3(arg2012_1356, list2015_1359);
							}
						     }
						     {
							obj_t arg2026_1369;
							obj_t arg2027_1370;
							arg2026_1369 = CNST_TABLE_REF(((long) 37));
							arg2027_1370 = CNST_TABLE_REF(((long) 38));
							{
							   obj_t list2029_1372;
							   {
							      obj_t arg2030_1373;
							      arg2030_1373 = MAKE_PAIR(BNIL, BNIL);
							      list2029_1372 = MAKE_PAIR(arg2027_1370, arg2030_1373);
							   }
							   arg2001_1348 = cons__138___r4_pairs_and_lists_6_3(arg2026_1369, list2029_1372);
							}
						     }
						     {
							obj_t arg2032_1375;
							obj_t arg2033_1376;
							obj_t arg2035_1377;
							arg2032_1375 = CNST_TABLE_REF(((long) 32));
							arg2033_1376 = make_pragma_indexed_set__widening_24_object_tools((type_t) (type_91), slot_1229, new_92, formal_1230, rid_93, BFALSE);
							{
							   obj_t arg2042_1383;
							   {
							      obj_t arg2047_1388;
							      arg2047_1388 = CNST_TABLE_REF(((long) 39));
							      {
								 obj_t list2050_1391;
								 {
								    obj_t arg2051_1392;
								    {
								       obj_t arg2052_1393;
								       arg2052_1393 = MAKE_PAIR(BNIL, BNIL);
								       {
									  obj_t aux_4212;
									  aux_4212 = BINT(((long) 1));
									  arg2051_1392 = MAKE_PAIR(aux_4212, arg2052_1393);
								       }
								    }
								    list2050_1391 = MAKE_PAIR(rid_93, arg2051_1392);
								 }
								 arg2042_1383 = cons__138___r4_pairs_and_lists_6_3(arg2047_1388, list2050_1391);
							      }
							   }
							   {
							      obj_t list2044_1385;
							      {
								 obj_t arg2045_1386;
								 arg2045_1386 = MAKE_PAIR(BNIL, BNIL);
								 list2044_1385 = MAKE_PAIR(arg2042_1383, arg2045_1386);
							      }
							      arg2035_1377 = cons__138___r4_pairs_and_lists_6_3(loop_1232, list2044_1385);
							   }
							}
							{
							   obj_t list2038_1379;
							   {
							      obj_t arg2039_1380;
							      {
								 obj_t arg2040_1381;
								 arg2040_1381 = MAKE_PAIR(BNIL, BNIL);
								 arg2039_1380 = MAKE_PAIR(arg2035_1377, arg2040_1381);
							      }
							      list2038_1379 = MAKE_PAIR(arg2033_1376, arg2039_1380);
							   }
							   arg2002_1349 = cons__138___r4_pairs_and_lists_6_3(arg2032_1375, list2038_1379);
							}
						     }
						     {
							obj_t list2004_1351;
							{
							   obj_t arg2006_1352;
							   {
							      obj_t arg2008_1353;
							      {
								 obj_t arg2010_1354;
								 arg2010_1354 = MAKE_PAIR(BNIL, BNIL);
								 arg2008_1353 = MAKE_PAIR(arg2002_1349, arg2010_1354);
							      }
							      arg2006_1352 = MAKE_PAIR(arg2001_1348, arg2008_1353);
							   }
							   list2004_1351 = MAKE_PAIR(arg2000_1347, arg2006_1352);
							}
							arg1987_1337 = cons__138___r4_pairs_and_lists_6_3(arg1998_1346, list2004_1351);
						     }
						  }
						  {
						     obj_t list1989_1339;
						     {
							obj_t arg1990_1340;
							{
							   obj_t arg1991_1341;
							   arg1991_1341 = MAKE_PAIR(BNIL, BNIL);
							   arg1990_1340 = MAKE_PAIR(arg1987_1337, arg1991_1341);
							}
							list1989_1339 = MAKE_PAIR(arg1986_1336, arg1990_1340);
						     }
						     arg1982_1332 = cons__138___r4_pairs_and_lists_6_3(loop_1232, list1989_1339);
						  }
					       }
					       {
						  obj_t list1984_1334;
						  list1984_1334 = MAKE_PAIR(BNIL, BNIL);
						  arg1974_1325 = cons__138___r4_pairs_and_lists_6_3(arg1982_1332, list1984_1334);
					       }
					    }
					    {
					       obj_t list2056_1397;
					       {
						  obj_t arg2057_1398;
						  arg2057_1398 = MAKE_PAIR(BNIL, BNIL);
						  {
						     obj_t aux_4236;
						     aux_4236 = BINT(((long) 0));
						     list2056_1397 = MAKE_PAIR(aux_4236, arg2057_1398);
						  }
					       }
					       arg1975_1326 = cons__138___r4_pairs_and_lists_6_3(loop_1232, list2056_1397);
					    }
					    {
					       obj_t list1978_1328;
					       {
						  obj_t arg1979_1329;
						  {
						     obj_t arg1980_1330;
						     arg1980_1330 = MAKE_PAIR(BNIL, BNIL);
						     arg1979_1329 = MAKE_PAIR(arg1975_1326, arg1980_1330);
						  }
						  list1978_1328 = MAKE_PAIR(arg1974_1325, arg1979_1329);
					       }
					       arg1866_1225 = cons__138___r4_pairs_and_lists_6_3(arg1973_1324, list1978_1328);
					    }
					 }
				      }
				    else
				      {
					 arg1866_1225 = make_pragma_direct_set__7_object_tools((type_t) (type_91), slot_1229, new_92, formal_1230);
				      }
				 }
			    }
			 }
			 arg1865_1224 = MAKE_PAIR(arg1866_1225, res_1216);
		      }
		      {
			 obj_t res_4251;
			 obj_t f_ids_164_4250;
			 obj_t slots_4249;
			 slots_4249 = arg1863_1222;
			 f_ids_164_4250 = arg1864_1223;
			 res_4251 = arg1865_1224;
			 res_1216 = res_4251;
			 f_ids_164_1215 = f_ids_164_4250;
			 slots_1214 = slots_4249;
			 goto loop_1217;
		      }
		   }
		}
	   }
      }
   }
}


/* import-class-makes! */ obj_t 
import_class_makes__192_object_access(obj_t mk_id_77_97, obj_t id_98, obj_t type_99, obj_t slots_100, obj_t src_def_101_101, obj_t module_102)
{
   {
      obj_t mk_heap_id_73_1402;
      obj_t mk_stack_id_29_1403;
      {
	 obj_t arg2060_1404;
	 arg2060_1404 = CNST_TABLE_REF(((long) 18));
	 {
	    obj_t list2061_1405;
	    {
	       obj_t arg2062_1406;
	       {
		  obj_t arg2063_1407;
		  arg2063_1407 = MAKE_PAIR(id_98, BNIL);
		  arg2062_1406 = MAKE_PAIR(arg2060_1404, arg2063_1407);
	       }
	       list2061_1405 = MAKE_PAIR(mk_id_77_97, arg2062_1406);
	    }
	    mk_heap_id_73_1402 = symbol_append_197___r4_symbols_6_4(list2061_1405);
	 }
      }
      {
	 obj_t arg2065_1409;
	 arg2065_1409 = CNST_TABLE_REF(((long) 19));
	 {
	    obj_t list2066_1410;
	    {
	       obj_t arg2067_1411;
	       {
		  obj_t arg2068_1412;
		  arg2068_1412 = MAKE_PAIR(id_98, BNIL);
		  arg2067_1411 = MAKE_PAIR(arg2065_1409, arg2068_1412);
	       }
	       list2066_1410 = MAKE_PAIR(mk_id_77_97, arg2067_1411);
	    }
	    mk_stack_id_29_1403 = symbol_append_197___r4_symbols_6_4(list2066_1410);
	 }
      }
      return import_class_make__159_object_access(malloc_env_105_object_tools, mk_heap_id_73_1402, id_98, type_99, slots_100, src_def_101_101, module_102);
   }
}


/* _import-class-makes!3354 */ obj_t 
_import_class_makes_3354_219_object_access(obj_t env_3512, obj_t mk_id_77_3513, obj_t id_3514, obj_t type_3515, obj_t slots_3516, obj_t src_def_101_3517, obj_t module_3518)
{
   return import_class_makes__192_object_access(mk_id_77_3513, id_3514, type_3515, slots_3516, src_def_101_3517, module_3518);
}


/* import-class-make! */ obj_t 
import_class_make__159_object_access(obj_t alloc_103, obj_t mk_id_77_104, obj_t id_105, obj_t type_106, obj_t slots_107, obj_t src_def_101_108, obj_t module_109)
{
   {
      obj_t mk_tid_99_1415;
      {
	 obj_t list2077_1424;
	 {
	    obj_t arg2078_1425;
	    {
	       obj_t arg2079_1426;
	       {
		  obj_t aux_4264;
		  {
		     type_t obj_3029;
		     obj_3029 = (type_t) (type_106);
		     aux_4264 = (((type_t) CREF(obj_3029))->id);
		  }
		  arg2079_1426 = MAKE_PAIR(aux_4264, BNIL);
	       }
	       arg2078_1425 = MAKE_PAIR(_4dots_199_tools_misc, arg2079_1426);
	    }
	    list2077_1424 = MAKE_PAIR(mk_id_77_104, arg2078_1425);
	 }
	 mk_tid_99_1415 = symbol_append_197___r4_symbols_6_4(list2077_1424);
      }
      {
	 obj_t f_tids_193_1416;
	 f_tids_193_1416 = make_class_make_typed_formals_184_object_access(slots_107);
	 {
	    {
	       obj_t arg2070_1417;
	       {
		  obj_t arg2071_1418;
		  {
		     obj_t arg2074_1421;
		     arg2074_1421 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
		     arg2071_1418 = append_2_18___r4_pairs_and_lists_6_3(f_tids_193_1416, arg2074_1421);
		  }
		  {
		     obj_t list2072_1419;
		     list2072_1419 = MAKE_PAIR(arg2071_1418, BNIL);
		     arg2070_1417 = cons__138___r4_pairs_and_lists_6_3(mk_tid_99_1415, list2072_1419);
		  }
	       }
	       return import_parser_53_module_impuse(module_109, arg2070_1417);
	    }
	 }
      }
   }
}


/* make-class-allocate! */ obj_t 
make_class_allocate__44_object_access(obj_t id_110, obj_t type_111, obj_t holder_112, obj_t src_def_101_113, obj_t import_114)
{
   {
      obj_t tid_1428;
      {
	 type_t obj_3030;
	 obj_3030 = (type_t) (type_111);
	 tid_1428 = (((type_t) CREF(obj_3030))->id);
      }
      {
	 obj_t alloc_id_207_1429;
	 {
	    obj_t arg2175_1520;
	    arg2175_1520 = CNST_TABLE_REF(((long) 41));
	    {
	       obj_t list2176_1521;
	       {
		  obj_t arg2178_1522;
		  arg2178_1522 = MAKE_PAIR(id_110, BNIL);
		  list2176_1521 = MAKE_PAIR(arg2175_1520, arg2178_1522);
	       }
	       alloc_id_207_1429 = symbol_append_197___r4_symbols_6_4(list2176_1521);
	    }
	 }
	 {
	    obj_t alloc_tid_75_1430;
	    {
	       obj_t list2171_1516;
	       {
		  obj_t arg2172_1517;
		  {
		     obj_t arg2173_1518;
		     arg2173_1518 = MAKE_PAIR(tid_1428, BNIL);
		     arg2172_1517 = MAKE_PAIR(_4dots_199_tools_misc, arg2173_1518);
		  }
		  list2171_1516 = MAKE_PAIR(alloc_id_207_1429, arg2172_1517);
	       }
	       alloc_tid_75_1430 = symbol_append_197___r4_symbols_6_4(list2171_1516);
	    }
	    {
	       obj_t new_1431;
	       new_1431 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 21)), BEOA);
	       {
		  {
		     obj_t arg2081_1432;
		     {
			obj_t arg2082_1433;
			{
			   obj_t list2088_1439;
			   list2088_1439 = MAKE_PAIR(BNIL, BNIL);
			   arg2082_1433 = cons__138___r4_pairs_and_lists_6_3(alloc_tid_75_1430, list2088_1439);
			}
			{
			   obj_t list2084_1435;
			   {
			      obj_t arg2085_1436;
			      arg2085_1436 = MAKE_PAIR(BNIL, BNIL);
			      list2084_1435 = MAKE_PAIR(arg2082_1433, arg2085_1436);
			   }
			   arg2081_1432 = cons__138___r4_pairs_and_lists_6_3(import_114, list2084_1435);
			}
		     }
		     produce_module_clause__172_module_module(arg2081_1432);
		  }
		  {
		     obj_t arg2090_1441;
		     {
			obj_t arg2093_1444;
			obj_t arg2094_1445;
			obj_t arg2095_1446;
			arg2093_1444 = CNST_TABLE_REF(((long) 25));
			{
			   obj_t list2102_1453;
			   list2102_1453 = MAKE_PAIR(BNIL, BNIL);
			   arg2094_1445 = cons__138___r4_pairs_and_lists_6_3(alloc_tid_75_1430, list2102_1453);
			}
			{
			   obj_t arg2105_1455;
			   obj_t arg2106_1456;
			   obj_t arg2107_1457;
			   obj_t arg2108_1458;
			   arg2105_1455 = CNST_TABLE_REF(((long) 26));
			   {
			      obj_t arg2116_1466;
			      {
				 obj_t arg2121_1470;
				 obj_t arg2122_1471;
				 {
				    obj_t list2128_1476;
				    {
				       obj_t arg2129_1477;
				       {
					  obj_t arg2131_1478;
					  arg2131_1478 = MAKE_PAIR(tid_1428, BNIL);
					  arg2129_1477 = MAKE_PAIR(_4dots_199_tools_misc, arg2131_1478);
				       }
				       list2128_1476 = MAKE_PAIR(new_1431, arg2129_1477);
				    }
				    arg2121_1470 = symbol_append_197___r4_symbols_6_4(list2128_1476);
				 }
				 arg2122_1471 = malloc_object_tools((type_t) (type_111), BINT(((long) 1)));
				 {
				    obj_t list2124_1473;
				    {
				       obj_t arg2125_1474;
				       arg2125_1474 = MAKE_PAIR(BNIL, BNIL);
				       list2124_1473 = MAKE_PAIR(arg2122_1471, arg2125_1474);
				    }
				    arg2116_1466 = cons__138___r4_pairs_and_lists_6_3(arg2121_1470, list2124_1473);
				 }
			      }
			      {
				 obj_t list2118_1468;
				 list2118_1468 = MAKE_PAIR(BNIL, BNIL);
				 arg2106_1456 = cons__138___r4_pairs_and_lists_6_3(arg2116_1466, list2118_1468);
			      }
			   }
			   {
			      obj_t arg2133_1480;
			      obj_t arg2134_1481;
			      arg2133_1480 = CNST_TABLE_REF(((long) 28));
			      {
				 obj_t arg2140_1487;
				 obj_t arg2141_1488;
				 {
				    obj_t arg2147_1493;
				    obj_t arg2148_1494;
				    obj_t arg2149_1495;
				    arg2147_1493 = CNST_TABLE_REF(((long) 17));
				    arg2148_1494 = CNST_TABLE_REF(((long) 29));
				    arg2149_1495 = CNST_TABLE_REF(((long) 42));
				    {
				       obj_t list2151_1497;
				       {
					  obj_t arg2152_1498;
					  {
					     obj_t arg2153_1499;
					     arg2153_1499 = MAKE_PAIR(BNIL, BNIL);
					     arg2152_1498 = MAKE_PAIR(arg2149_1495, arg2153_1499);
					  }
					  list2151_1497 = MAKE_PAIR(arg2148_1494, arg2152_1498);
				       }
				       arg2140_1487 = cons__138___r4_pairs_and_lists_6_3(arg2147_1493, list2151_1497);
				    }
				 }
				 {
				    obj_t arg2155_1501;
				    obj_t arg2156_1502;
				    obj_t arg2157_1503;
				    arg2155_1501 = CNST_TABLE_REF(((long) 17));
				    {
				       global_t obj_3031;
				       obj_3031 = (global_t) (holder_112);
				       arg2156_1502 = (((global_t) CREF(obj_3031))->id);
				    }
				    {
				       global_t obj_3032;
				       obj_3032 = (global_t) (holder_112);
				       arg2157_1503 = (((global_t) CREF(obj_3032))->module);
				    }
				    {
				       obj_t list2159_1505;
				       {
					  obj_t arg2160_1506;
					  {
					     obj_t arg2161_1507;
					     arg2161_1507 = MAKE_PAIR(BNIL, BNIL);
					     arg2160_1506 = MAKE_PAIR(arg2157_1503, arg2161_1507);
					  }
					  list2159_1505 = MAKE_PAIR(arg2156_1502, arg2160_1506);
				       }
				       arg2141_1488 = cons__138___r4_pairs_and_lists_6_3(arg2155_1501, list2159_1505);
				    }
				 }
				 {
				    obj_t list2144_1490;
				    {
				       obj_t arg2145_1491;
				       arg2145_1491 = MAKE_PAIR(BNIL, BNIL);
				       list2144_1490 = MAKE_PAIR(arg2141_1488, arg2145_1491);
				    }
				    arg2134_1481 = cons__138___r4_pairs_and_lists_6_3(arg2140_1487, list2144_1490);
				 }
			      }
			      {
				 obj_t list2136_1483;
				 {
				    obj_t arg2137_1484;
				    {
				       obj_t arg2138_1485;
				       arg2138_1485 = MAKE_PAIR(BNIL, BNIL);
				       arg2137_1484 = MAKE_PAIR(arg2134_1481, arg2138_1485);
				    }
				    list2136_1483 = MAKE_PAIR(new_1431, arg2137_1484);
				 }
				 arg2107_1457 = cons__138___r4_pairs_and_lists_6_3(arg2133_1480, list2136_1483);
			      }
			   }
			   {
			      obj_t arg2163_1509;
			      arg2163_1509 = CNST_TABLE_REF(((long) 30));
			      {
				 obj_t list2165_1511;
				 {
				    obj_t arg2166_1512;
				    {
				       obj_t arg2167_1513;
				       arg2167_1513 = MAKE_PAIR(BNIL, BNIL);
				       arg2166_1512 = MAKE_PAIR(BFALSE, arg2167_1513);
				    }
				    list2165_1511 = MAKE_PAIR(new_1431, arg2166_1512);
				 }
				 arg2108_1458 = cons__138___r4_pairs_and_lists_6_3(arg2163_1509, list2165_1511);
			      }
			   }
			   {
			      obj_t list2110_1460;
			      {
				 obj_t arg2111_1461;
				 {
				    obj_t arg2112_1462;
				    {
				       obj_t arg2113_1463;
				       {
					  obj_t arg2114_1464;
					  arg2114_1464 = MAKE_PAIR(BNIL, BNIL);
					  arg2113_1463 = MAKE_PAIR(new_1431, arg2114_1464);
				       }
				       arg2112_1462 = MAKE_PAIR(arg2108_1458, arg2113_1463);
				    }
				    arg2111_1461 = MAKE_PAIR(arg2107_1457, arg2112_1462);
				 }
				 list2110_1460 = MAKE_PAIR(arg2106_1456, arg2111_1461);
			      }
			      arg2095_1446 = cons__138___r4_pairs_and_lists_6_3(arg2105_1455, list2110_1460);
			   }
			}
			{
			   obj_t list2097_1448;
			   {
			      obj_t arg2098_1449;
			      {
				 obj_t arg2099_1450;
				 arg2099_1450 = MAKE_PAIR(BNIL, BNIL);
				 arg2098_1449 = MAKE_PAIR(arg2095_1446, arg2099_1450);
			      }
			      list2097_1448 = MAKE_PAIR(arg2094_1445, arg2098_1449);
			   }
			   arg2090_1441 = cons__138___r4_pairs_and_lists_6_3(arg2093_1444, list2097_1448);
			}
		     }
		     {
			obj_t list2091_1442;
			list2091_1442 = MAKE_PAIR(src_def_101_113, BNIL);
			return epairify_object_access(arg2090_1441, list2091_1442);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _make-class-allocate! */ obj_t 
_make_class_allocate__22_object_access(obj_t env_3519, obj_t id_3520, obj_t type_3521, obj_t holder_3522, obj_t src_def_101_3523, obj_t import_3524)
{
   return make_class_allocate__44_object_access(id_3520, type_3521, holder_3522, src_def_101_3523, import_3524);
}


/* make-class-slots-access! */ obj_t 
make_class_slots_access__80_object_access(obj_t class_id_86_115, obj_t type_116, obj_t slots_117, obj_t widening_118, obj_t src_def_101_119, obj_t import_120)
{
   {
      obj_t slots_1524;
      obj_t res_1525;
      slots_1524 = slots_117;
      res_1525 = BNIL;
    loop_1526:
      if (NULLP(slots_1524))
	{
	   return reverse__39___r4_pairs_and_lists_6_3(res_1525);
	}
      else
	{
	   obj_t slot_1529;
	   slot_1529 = CAR(slots_1524);
	   {
	      bool_t test_4358;
	      {
		 obj_t aux_4359;
		 aux_4359 = STRUCT_REF(slot_1529, ((long) 7));
		 test_4358 = CBOOL(aux_4359);
	      }
	      if (test_4358)
		{
		   obj_t arg2183_1531;
		   obj_t arg2184_1532;
		   arg2183_1531 = CDR(slots_1524);
		   {
		      obj_t arg2185_1533;
		      arg2185_1533 = slot_ref_85_object_access(class_id_86_115, type_116, slot_1529, widening_118, src_def_101_119, import_120);
		      arg2184_1532 = append_2_18___r4_pairs_and_lists_6_3(arg2185_1533, res_1525);
		   }
		   {
		      obj_t res_4366;
		      obj_t slots_4365;
		      slots_4365 = arg2183_1531;
		      res_4366 = arg2184_1532;
		      res_1525 = res_4366;
		      slots_1524 = slots_4365;
		      goto loop_1526;
		   }
		}
	      else
		{
		   obj_t arg2186_1534;
		   obj_t arg2187_1535;
		   arg2186_1534 = CDR(slots_1524);
		   {
		      obj_t arg2188_1536;
		      obj_t arg2189_1537;
		      arg2188_1536 = slot_ref_85_object_access(class_id_86_115, type_116, slot_1529, widening_118, src_def_101_119, import_120);
		      arg2189_1537 = slot_set__144_object_access(class_id_86_115, type_116, slot_1529, widening_118, src_def_101_119, import_120);
		      {
			 obj_t list2190_1538;
			 {
			    obj_t arg2191_1539;
			    {
			       obj_t arg2192_1540;
			       arg2192_1540 = MAKE_PAIR(res_1525, BNIL);
			       arg2191_1539 = MAKE_PAIR(arg2189_1537, arg2192_1540);
			    }
			    list2190_1538 = MAKE_PAIR(arg2188_1536, arg2191_1539);
			 }
			 arg2187_1535 = append___r4_pairs_and_lists_6_3(list2190_1538);
		      }
		   }
		   {
		      obj_t res_4375;
		      obj_t slots_4374;
		      slots_4374 = arg2186_1534;
		      res_4375 = arg2187_1535;
		      res_1525 = res_4375;
		      slots_1524 = slots_4374;
		      goto loop_1526;
		   }
		}
	   }
	}
   }
}


/* _make-class-slots-access! */ obj_t 
_make_class_slots_access__121_object_access(obj_t env_3525, obj_t class_id_86_3526, obj_t type_3527, obj_t slots_3528, obj_t widening_3529, obj_t src_def_101_3530, obj_t import_3531)
{
   return make_class_slots_access__80_object_access(class_id_86_3526, type_3527, slots_3528, widening_3529, src_def_101_3530, import_3531);
}


/* slot-ref */ obj_t 
slot_ref_85_object_access(obj_t class_id_86_121, obj_t type_122, obj_t slot_123, obj_t widening_124, obj_t src_def_101_125, obj_t import_126)
{
   {
      bool_t test_4377;
      {
	 obj_t aux_4378;
	 aux_4378 = STRUCT_REF(slot_123, ((long) 5));
	 test_4377 = CBOOL(aux_4378);
      }
      if (test_4377)
	{
	   return slot_dyna_indexed_ref_48_object_access(class_id_86_121, type_122, slot_123, widening_124, src_def_101_125, import_126);
	}
      else
	{
	   bool_t test_4382;
	   {
	      obj_t aux_4383;
	      aux_4383 = STRUCT_REF(slot_123, ((long) 3));
	      test_4382 = CBOOL(aux_4383);
	   }
	   if (test_4382)
	     {
		{
		   obj_t arg2214_3052;
		   {
		      obj_t arg2215_3053;
		      obj_t arg2216_3054;
		      arg2215_3053 = CNST_TABLE_REF(((long) 40));
		      arg2216_3054 = STRUCT_REF(slot_123, ((long) 4));
		      {
			 obj_t list2218_3056;
			 {
			    obj_t arg2219_3057;
			    arg2219_3057 = MAKE_PAIR(BNIL, BNIL);
			    list2218_3056 = MAKE_PAIR(arg2216_3054, arg2219_3057);
			 }
			 arg2214_3052 = cons__138___r4_pairs_and_lists_6_3(arg2215_3053, list2218_3056);
		      }
		   }
		   return slot_indexed_ref_219_object_access(class_id_86_121, type_122, slot_123, widening_124, arg2214_3052, src_def_101_125, import_126);
		}
	     }
	   else
	     {
		bool_t test_4392;
		{
		   obj_t aux_4393;
		   aux_4393 = STRUCT_REF(slot_123, ((long) 11));
		   test_4392 = CBOOL(aux_4393);
		}
		if (test_4392)
		  {
		     return slot_virtual_ref_147_object_access(class_id_86_121, type_122, slot_123, widening_124, src_def_101_125, import_126);
		  }
		else
		  {
		     return slot_direct_ref_183_object_access(class_id_86_121, type_122, slot_123, widening_124, src_def_101_125, import_126);
		  }
	     }
	}
   }
}


/* slot-dyna-indexed-ref */ obj_t 
slot_dyna_indexed_ref_48_object_access(obj_t class_id_86_127, obj_t type_128, obj_t slot_129, obj_t widening_130, obj_t src_def_101_131, obj_t import_132)
{
   {
      obj_t arg2197_1545;
      {
	 obj_t arg2198_1546;
	 obj_t arg2199_1547;
	 {
	    obj_t arg2205_1552;
	    obj_t arg2206_1553;
	    arg2205_1552 = CNST_TABLE_REF(((long) 18));
	    arg2206_1553 = STRUCT_REF(slot_129, ((long) 0));
	    {
	       obj_t list2208_1555;
	       {
		  obj_t arg2209_1556;
		  {
		     obj_t arg2210_1557;
		     {
			obj_t arg2211_1558;
			{
			   obj_t aux_4400;
			   aux_4400 = CNST_TABLE_REF(((long) 33));
			   arg2211_1558 = MAKE_PAIR(aux_4400, BNIL);
			}
			arg2210_1557 = MAKE_PAIR(arg2206_1553, arg2211_1558);
		     }
		     arg2209_1556 = MAKE_PAIR(arg2205_1552, arg2210_1557);
		  }
		  list2208_1555 = MAKE_PAIR(class_id_86_127, arg2209_1556);
	       }
	       arg2198_1546 = symbol_append_197___r4_symbols_6_4(list2208_1555);
	    }
	 }
	 arg2199_1547 = CNST_TABLE_REF(((long) 2));
	 {
	    obj_t list2201_1549;
	    {
	       obj_t arg2202_1550;
	       arg2202_1550 = MAKE_PAIR(BNIL, BNIL);
	       list2201_1549 = MAKE_PAIR(arg2199_1547, arg2202_1550);
	    }
	    arg2197_1545 = cons__138___r4_pairs_and_lists_6_3(arg2198_1546, list2201_1549);
	 }
      }
      return slot_indexed_ref_219_object_access(class_id_86_127, type_128, slot_129, widening_130, arg2197_1545, src_def_101_131, import_132);
   }
}


/* slot-indexed-ref */ obj_t 
slot_indexed_ref_219_object_access(obj_t class_id_86_139, obj_t type_140, obj_t slot_141, obj_t widening_142, obj_t max_bound_128_143, obj_t src_def_101_144, obj_t import_145)
{
   {
      obj_t slot_ref_id_128_1748;
      obj_t slot_ref_tid_43_1749;
      obj_t slot_ref_id_128_1651;
      obj_t slot_ref_tid_43_1652;
      {
	 obj_t slot_ref_id_128_1569;
	 {
	    obj_t arg2299_1643;
	    obj_t arg2300_1644;
	    arg2299_1643 = CNST_TABLE_REF(((long) 18));
	    arg2300_1644 = STRUCT_REF(slot_141, ((long) 0));
	    {
	       obj_t list2302_1646;
	       {
		  obj_t arg2303_1647;
		  {
		     obj_t arg2304_1648;
		     {
			obj_t arg2305_1649;
			{
			   obj_t aux_4414;
			   aux_4414 = CNST_TABLE_REF(((long) 49));
			   arg2305_1649 = MAKE_PAIR(aux_4414, BNIL);
			}
			arg2304_1648 = MAKE_PAIR(arg2300_1644, arg2305_1649);
		     }
		     arg2303_1647 = MAKE_PAIR(arg2299_1643, arg2304_1648);
		  }
		  list2302_1646 = MAKE_PAIR(class_id_86_139, arg2303_1647);
	       }
	       slot_ref_id_128_1569 = symbol_append_197___r4_symbols_6_4(list2302_1646);
	    }
	 }
	 {
	    obj_t slot_ref_tid_43_1570;
	    {
	       obj_t list2293_1638;
	       {
		  obj_t arg2294_1639;
		  {
		     obj_t arg2295_1640;
		     {
			obj_t aux_4421;
			{
			   type_t obj_3084;
			   {
			      obj_t aux_4422;
			      aux_4422 = STRUCT_REF(slot_141, ((long) 2));
			      obj_3084 = (type_t) (aux_4422);
			   }
			   aux_4421 = (((type_t) CREF(obj_3084))->id);
			}
			arg2295_1640 = MAKE_PAIR(aux_4421, BNIL);
		     }
		     arg2294_1639 = MAKE_PAIR(_4dots_199_tools_misc, arg2295_1640);
		  }
		  list2293_1638 = MAKE_PAIR(slot_ref_id_128_1569, arg2294_1639);
	       }
	       slot_ref_tid_43_1570 = symbol_append_197___r4_symbols_6_4(list2293_1638);
	    }
	    {
	       obj_t tid_1571;
	       {
		  obj_t list2288_1634;
		  {
		     obj_t arg2289_1635;
		     {
			obj_t aux_4430;
			{
			   type_t obj_3085;
			   obj_3085 = (type_t) (type_140);
			   aux_4430 = (((type_t) CREF(obj_3085))->id);
			}
			arg2289_1635 = MAKE_PAIR(aux_4430, BNIL);
		     }
		     list2288_1634 = MAKE_PAIR(_4dots_199_tools_misc, arg2289_1635);
		  }
		  tid_1571 = symbol_append_197___r4_symbols_6_4(list2288_1634);
	       }
	       {
		  if (CBOOL(_unsafe_range__218_engine_param))
		    {
		       {
			  obj_t arg2221_1573;
			  {
			     obj_t arg2222_1574;
			     {
				obj_t arg2227_1579;
				obj_t arg2228_1580;
				arg2227_1579 = CNST_TABLE_REF(((long) 12));
				arg2228_1580 = CNST_TABLE_REF(((long) 23));
				{
				   obj_t list2230_1582;
				   {
				      obj_t arg2231_1583;
				      {
					 obj_t arg2232_1584;
					 {
					    obj_t arg2233_1585;
					    arg2233_1585 = MAKE_PAIR(BNIL, BNIL);
					    arg2232_1584 = MAKE_PAIR(arg2228_1580, arg2233_1585);
					 }
					 arg2231_1583 = MAKE_PAIR(tid_1571, arg2232_1584);
				      }
				      list2230_1582 = MAKE_PAIR(slot_ref_tid_43_1570, arg2231_1583);
				   }
				   arg2222_1574 = cons__138___r4_pairs_and_lists_6_3(arg2227_1579, list2230_1582);
				}
			     }
			     {
				obj_t list2224_1576;
				{
				   obj_t arg2225_1577;
				   arg2225_1577 = MAKE_PAIR(BNIL, BNIL);
				   list2224_1576 = MAKE_PAIR(arg2222_1574, arg2225_1577);
				}
				arg2221_1573 = cons__138___r4_pairs_and_lists_6_3(import_145, list2224_1576);
			     }
			  }
			  produce_module_clause__172_module_module(arg2221_1573);
		       }
		       {
			  obj_t arg2235_1587;
			  {
			     obj_t arg2236_1588;
			     obj_t arg2237_1589;
			     arg2236_1588 = CNST_TABLE_REF(((long) 4));
			     {
				obj_t arg2243_1594;
				obj_t arg2244_1595;
				arg2243_1594 = CNST_TABLE_REF(((long) 5));
				arg2244_1595 = CNST_TABLE_REF(((long) 6));
				{
				   obj_t list2247_1597;
				   {
				      obj_t arg2248_1598;
				      {
					 obj_t arg2250_1599;
					 arg2250_1599 = MAKE_PAIR(BNIL, BNIL);
					 arg2248_1598 = MAKE_PAIR(arg2244_1595, arg2250_1599);
				      }
				      list2247_1597 = MAKE_PAIR(arg2243_1594, arg2248_1598);
				   }
				   arg2237_1589 = cons__138___r4_pairs_and_lists_6_3(slot_ref_id_128_1569, list2247_1597);
				}
			     }
			     {
				obj_t list2239_1591;
				{
				   obj_t arg2240_1592;
				   arg2240_1592 = MAKE_PAIR(BNIL, BNIL);
				   list2239_1591 = MAKE_PAIR(arg2237_1589, arg2240_1592);
				}
				arg2235_1587 = cons__138___r4_pairs_and_lists_6_3(arg2236_1588, list2239_1591);
			     }
			  }
			  produce_module_clause__172_module_module(arg2235_1587);
		       }
		       {
			  obj_t arg2254_1601;
			  slot_ref_id_128_1748 = slot_ref_id_128_1569;
			  slot_ref_tid_43_1749 = slot_ref_tid_43_1570;
			  {
			     obj_t arg2416_1751;
			     obj_t arg2417_1752;
			     {
				obj_t arg2421_1756;
				obj_t arg2422_1757;
				obj_t arg2423_1758;
				arg2421_1756 = CNST_TABLE_REF(((long) 15));
				{
				   obj_t arg2429_1764;
				   obj_t arg2430_1765;
				   {
				      obj_t arg2436_1771;
				      arg2436_1771 = CNST_TABLE_REF(((long) 2));
				      {
					 obj_t list2438_1773;
					 {
					    obj_t arg2439_1774;
					    {
					       obj_t arg2440_1775;
					       {
						  obj_t aux_4462;
						  {
						     type_t obj_3101;
						     obj_3101 = (type_t) (type_140);
						     aux_4462 = (((type_t) CREF(obj_3101))->id);
						  }
						  arg2440_1775 = MAKE_PAIR(aux_4462, BNIL);
					       }
					       arg2439_1774 = MAKE_PAIR(_4dots_199_tools_misc, arg2440_1775);
					    }
					    list2438_1773 = MAKE_PAIR(arg2436_1771, arg2439_1774);
					 }
					 arg2429_1764 = symbol_append_197___r4_symbols_6_4(list2438_1773);
				      }
				   }
				   arg2430_1765 = CNST_TABLE_REF(((long) 43));
				   {
				      obj_t list2432_1767;
				      {
					 obj_t arg2433_1768;
					 {
					    obj_t arg2434_1769;
					    arg2434_1769 = MAKE_PAIR(BNIL, BNIL);
					    arg2433_1768 = MAKE_PAIR(arg2430_1765, arg2434_1769);
					 }
					 list2432_1767 = MAKE_PAIR(arg2429_1764, arg2433_1768);
				      }
				      arg2422_1757 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_1749, list2432_1767);
				   }
				}
				arg2423_1758 = make_pragma_indexed_ref_widening_28_object_tools((type_t) (type_140), slot_141, CNST_TABLE_REF(((long) 2)), CNST_TABLE_REF(((long) 45)), widening_142);
				{
				   obj_t list2425_1760;
				   {
				      obj_t arg2426_1761;
				      {
					 obj_t arg2427_1762;
					 arg2427_1762 = MAKE_PAIR(BNIL, BNIL);
					 arg2426_1761 = MAKE_PAIR(arg2423_1758, arg2427_1762);
				      }
				      list2425_1760 = MAKE_PAIR(arg2422_1757, arg2426_1761);
				   }
				   arg2416_1751 = cons__138___r4_pairs_and_lists_6_3(arg2421_1756, list2425_1760);
				}
			     }
			     {
				bool_t test_4482;
				if (STRUCTP(slot_141))
				  {
				     obj_t aux_4487;
				     obj_t aux_4485;
				     aux_4487 = CNST_TABLE_REF(((long) 48));
				     aux_4485 = STRUCT_KEY(slot_141);
				     test_4482 = (aux_4485 == aux_4487);
				  }
				else
				  {
				     test_4482 = ((bool_t) 0);
				  }
				if (test_4482)
				  {
				     arg2417_1752 = STRUCT_REF(slot_141, ((long) 14));
				  }
				else
				  {
				     arg2417_1752 = slot_141;
				  }
			     }
			     {
				obj_t list2418_1753;
				{
				   obj_t arg2419_1754;
				   arg2419_1754 = MAKE_PAIR(src_def_101_144, BNIL);
				   list2418_1753 = MAKE_PAIR(arg2417_1752, arg2419_1754);
				}
				arg2254_1601 = epairify_object_access(arg2416_1751, list2418_1753);
			     }
			  }
			  {
			     obj_t list2255_1602;
			     list2255_1602 = MAKE_PAIR(arg2254_1601, BNIL);
			     return list2255_1602;
			  }
		       }
		    }
		  else
		    {
		       {
			  obj_t arg2257_1604;
			  {
			     obj_t arg2258_1605;
			     {
				obj_t arg2264_1610;
				arg2264_1610 = CNST_TABLE_REF(((long) 23));
				{
				   obj_t list2266_1612;
				   {
				      obj_t arg2267_1613;
				      {
					 obj_t arg2268_1614;
					 arg2268_1614 = MAKE_PAIR(BNIL, BNIL);
					 arg2267_1613 = MAKE_PAIR(arg2264_1610, arg2268_1614);
				      }
				      list2266_1612 = MAKE_PAIR(tid_1571, arg2267_1613);
				   }
				   arg2258_1605 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_1570, list2266_1612);
				}
			     }
			     {
				obj_t list2260_1607;
				{
				   obj_t arg2261_1608;
				   arg2261_1608 = MAKE_PAIR(BNIL, BNIL);
				   list2260_1607 = MAKE_PAIR(arg2258_1605, arg2261_1608);
				}
				arg2257_1604 = cons__138___r4_pairs_and_lists_6_3(import_145, list2260_1607);
			     }
			  }
			  produce_module_clause__172_module_module(arg2257_1604);
		       }
		       {
			  obj_t arg2270_1616;
			  {
			     obj_t arg2271_1617;
			     obj_t arg2272_1618;
			     arg2271_1617 = CNST_TABLE_REF(((long) 4));
			     {
				obj_t arg2277_1623;
				obj_t arg2278_1624;
				arg2277_1623 = CNST_TABLE_REF(((long) 5));
				arg2278_1624 = CNST_TABLE_REF(((long) 6));
				{
				   obj_t list2280_1626;
				   {
				      obj_t arg2281_1627;
				      {
					 obj_t arg2282_1628;
					 arg2282_1628 = MAKE_PAIR(BNIL, BNIL);
					 arg2281_1627 = MAKE_PAIR(arg2278_1624, arg2282_1628);
				      }
				      list2280_1626 = MAKE_PAIR(arg2277_1623, arg2281_1627);
				   }
				   arg2272_1618 = cons__138___r4_pairs_and_lists_6_3(slot_ref_id_128_1569, list2280_1626);
				}
			     }
			     {
				obj_t list2274_1620;
				{
				   obj_t arg2275_1621;
				   arg2275_1621 = MAKE_PAIR(BNIL, BNIL);
				   list2274_1620 = MAKE_PAIR(arg2272_1618, arg2275_1621);
				}
				arg2270_1616 = cons__138___r4_pairs_and_lists_6_3(arg2271_1617, list2274_1620);
			     }
			  }
			  produce_module_clause__172_module_module(arg2270_1616);
		       }
		       {
			  obj_t arg2284_1630;
			  slot_ref_id_128_1651 = slot_ref_id_128_1569;
			  slot_ref_tid_43_1652 = slot_ref_tid_43_1570;
			  {
			     obj_t arg2308_1654;
			     obj_t arg2309_1655;
			     {
				obj_t arg2316_1659;
				obj_t arg2319_1660;
				obj_t arg2320_1661;
				arg2316_1659 = CNST_TABLE_REF(((long) 25));
				{
				   obj_t arg2327_1667;
				   obj_t arg2328_1668;
				   {
				      obj_t arg2334_1674;
				      arg2334_1674 = CNST_TABLE_REF(((long) 2));
				      {
					 obj_t list2336_1676;
					 {
					    obj_t arg2337_1677;
					    {
					       obj_t arg2338_1678;
					       {
						  obj_t aux_4517;
						  {
						     type_t obj_3089;
						     obj_3089 = (type_t) (type_140);
						     aux_4517 = (((type_t) CREF(obj_3089))->id);
						  }
						  arg2338_1678 = MAKE_PAIR(aux_4517, BNIL);
					       }
					       arg2337_1677 = MAKE_PAIR(_4dots_199_tools_misc, arg2338_1678);
					    }
					    list2336_1676 = MAKE_PAIR(arg2334_1674, arg2337_1677);
					 }
					 arg2327_1667 = symbol_append_197___r4_symbols_6_4(list2336_1676);
				      }
				   }
				   arg2328_1668 = CNST_TABLE_REF(((long) 43));
				   {
				      obj_t list2330_1670;
				      {
					 obj_t arg2331_1671;
					 {
					    obj_t arg2332_1672;
					    arg2332_1672 = MAKE_PAIR(BNIL, BNIL);
					    arg2331_1671 = MAKE_PAIR(arg2328_1668, arg2332_1672);
					 }
					 list2330_1670 = MAKE_PAIR(arg2327_1667, arg2331_1671);
				      }
				      arg2319_1660 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_1652, list2330_1670);
				   }
				}
				{
				   obj_t arg2340_1680;
				   obj_t arg2341_1681;
				   obj_t arg2342_1682;
				   obj_t arg2343_1683;
				   arg2340_1680 = CNST_TABLE_REF(((long) 35));
				   {
				      obj_t arg2350_1690;
				      obj_t arg2351_1691;
				      arg2350_1690 = CNST_TABLE_REF(((long) 44));
				      arg2351_1691 = CNST_TABLE_REF(((long) 45));
				      {
					 obj_t list2354_1694;
					 {
					    obj_t arg2355_1695;
					    {
					       obj_t arg2356_1696;
					       arg2356_1696 = MAKE_PAIR(BNIL, BNIL);
					       {
						  obj_t aux_4533;
						  aux_4533 = BINT(((long) 0));
						  arg2355_1695 = MAKE_PAIR(aux_4533, arg2356_1696);
					       }
					    }
					    list2354_1694 = MAKE_PAIR(arg2351_1691, arg2355_1695);
					 }
					 arg2341_1681 = cons__138___r4_pairs_and_lists_6_3(arg2350_1690, list2354_1694);
				      }
				   }
				   {
				      obj_t arg2358_1698;
				      obj_t arg2359_1699;
				      obj_t arg2360_1700;
				      obj_t arg2361_1701;
				      arg2358_1698 = CNST_TABLE_REF(((long) 35));
				      {
					 obj_t arg2369_1708;
					 obj_t arg2370_1709;
					 arg2369_1708 = CNST_TABLE_REF(((long) 46));
					 arg2370_1709 = CNST_TABLE_REF(((long) 45));
					 {
					    obj_t list2372_1711;
					    {
					       obj_t arg2373_1712;
					       {
						  obj_t arg2374_1713;
						  arg2374_1713 = MAKE_PAIR(BNIL, BNIL);
						  arg2373_1712 = MAKE_PAIR(max_bound_128_143, arg2374_1713);
					       }
					       list2372_1711 = MAKE_PAIR(arg2370_1709, arg2373_1712);
					    }
					    arg2359_1699 = cons__138___r4_pairs_and_lists_6_3(arg2369_1708, list2372_1711);
					 }
				      }
				      arg2360_1700 = make_pragma_indexed_ref_widening_28_object_tools((type_t) (type_140), slot_141, CNST_TABLE_REF(((long) 2)), CNST_TABLE_REF(((long) 45)), widening_142);
				      {
					 obj_t arg2378_1717;
					 obj_t arg2379_1718;
					 obj_t arg2381_1720;
					 arg2378_1717 = CNST_TABLE_REF(((long) 47));
					 {
					    obj_t arg2390_1727;
					    arg2390_1727 = CNST_TABLE_REF(((long) 37));
					    {
					       obj_t list2393_1729;
					       {
						  obj_t arg2394_1730;
						  arg2394_1730 = MAKE_PAIR(BNIL, BNIL);
						  list2393_1729 = MAKE_PAIR(slot_ref_id_128_1651, arg2394_1730);
					       }
					       arg2379_1718 = cons__138___r4_pairs_and_lists_6_3(arg2390_1727, list2393_1729);
					    }
					 }
					 arg2381_1720 = CNST_TABLE_REF(((long) 45));
					 {
					    obj_t list2384_1722;
					    {
					       obj_t arg2385_1723;
					       {
						  obj_t arg2386_1724;
						  {
						     obj_t arg2387_1725;
						     arg2387_1725 = MAKE_PAIR(BNIL, BNIL);
						     arg2386_1724 = MAKE_PAIR(arg2381_1720, arg2387_1725);
						  }
						  arg2385_1723 = MAKE_PAIR(string3359_object_access, arg2386_1724);
					       }
					       list2384_1722 = MAKE_PAIR(arg2379_1718, arg2385_1723);
					    }
					    arg2361_1701 = cons__138___r4_pairs_and_lists_6_3(arg2378_1717, list2384_1722);
					 }
				      }
				      {
					 obj_t list2364_1703;
					 {
					    obj_t arg2365_1704;
					    {
					       obj_t arg2366_1705;
					       {
						  obj_t arg2367_1706;
						  arg2367_1706 = MAKE_PAIR(BNIL, BNIL);
						  arg2366_1705 = MAKE_PAIR(arg2361_1701, arg2367_1706);
					       }
					       arg2365_1704 = MAKE_PAIR(arg2360_1700, arg2366_1705);
					    }
					    list2364_1703 = MAKE_PAIR(arg2359_1699, arg2365_1704);
					 }
					 arg2342_1682 = cons__138___r4_pairs_and_lists_6_3(arg2358_1698, list2364_1703);
				      }
				   }
				   {
				      obj_t arg2399_1732;
				      obj_t arg2400_1733;
				      obj_t arg2402_1735;
				      arg2399_1732 = CNST_TABLE_REF(((long) 47));
				      {
					 obj_t arg2409_1742;
					 arg2409_1742 = CNST_TABLE_REF(((long) 37));
					 {
					    obj_t list2411_1744;
					    {
					       obj_t arg2412_1745;
					       arg2412_1745 = MAKE_PAIR(BNIL, BNIL);
					       list2411_1744 = MAKE_PAIR(slot_ref_id_128_1651, arg2412_1745);
					    }
					    arg2400_1733 = cons__138___r4_pairs_and_lists_6_3(arg2409_1742, list2411_1744);
					 }
				      }
				      arg2402_1735 = CNST_TABLE_REF(((long) 45));
				      {
					 obj_t list2404_1737;
					 {
					    obj_t arg2405_1738;
					    {
					       obj_t arg2406_1739;
					       {
						  obj_t arg2407_1740;
						  arg2407_1740 = MAKE_PAIR(BNIL, BNIL);
						  arg2406_1739 = MAKE_PAIR(arg2402_1735, arg2407_1740);
					       }
					       arg2405_1738 = MAKE_PAIR(string3359_object_access, arg2406_1739);
					    }
					    list2404_1737 = MAKE_PAIR(arg2400_1733, arg2405_1738);
					 }
					 arg2343_1683 = cons__138___r4_pairs_and_lists_6_3(arg2399_1732, list2404_1737);
				      }
				   }
				   {
				      obj_t list2345_1685;
				      {
					 obj_t arg2346_1686;
					 {
					    obj_t arg2347_1687;
					    {
					       obj_t arg2348_1688;
					       arg2348_1688 = MAKE_PAIR(BNIL, BNIL);
					       arg2347_1687 = MAKE_PAIR(arg2343_1683, arg2348_1688);
					    }
					    arg2346_1686 = MAKE_PAIR(arg2342_1682, arg2347_1687);
					 }
					 list2345_1685 = MAKE_PAIR(arg2341_1681, arg2346_1686);
				      }
				      arg2320_1661 = cons__138___r4_pairs_and_lists_6_3(arg2340_1680, list2345_1685);
				   }
				}
				{
				   obj_t list2323_1663;
				   {
				      obj_t arg2324_1664;
				      {
					 obj_t arg2325_1665;
					 arg2325_1665 = MAKE_PAIR(BNIL, BNIL);
					 arg2324_1664 = MAKE_PAIR(arg2320_1661, arg2325_1665);
				      }
				      list2323_1663 = MAKE_PAIR(arg2319_1660, arg2324_1664);
				   }
				   arg2308_1654 = cons__138___r4_pairs_and_lists_6_3(arg2316_1659, list2323_1663);
				}
			     }
			     {
				bool_t test_4585;
				if (STRUCTP(slot_141))
				  {
				     obj_t aux_4590;
				     obj_t aux_4588;
				     aux_4590 = CNST_TABLE_REF(((long) 48));
				     aux_4588 = STRUCT_KEY(slot_141);
				     test_4585 = (aux_4588 == aux_4590);
				  }
				else
				  {
				     test_4585 = ((bool_t) 0);
				  }
				if (test_4585)
				  {
				     arg2309_1655 = STRUCT_REF(slot_141, ((long) 14));
				  }
				else
				  {
				     arg2309_1655 = slot_141;
				  }
			     }
			     {
				obj_t list2310_1656;
				{
				   obj_t arg2311_1657;
				   arg2311_1657 = MAKE_PAIR(src_def_101_144, BNIL);
				   list2310_1656 = MAKE_PAIR(arg2309_1655, arg2311_1657);
				}
				arg2284_1630 = epairify_object_access(arg2308_1654, list2310_1656);
			     }
			  }
			  {
			     obj_t list2285_1631;
			     list2285_1631 = MAKE_PAIR(arg2284_1630, BNIL);
			     return list2285_1631;
			  }
		       }
		    }
	       }
	    }
	 }
      }
   }
}


/* slot-virtual-ref */ obj_t 
slot_virtual_ref_147_object_access(obj_t class_id_86_146, obj_t type_147, obj_t slot_148, obj_t widening_149, obj_t src_def_101_150, obj_t import_151)
{
   {
      obj_t slot_ref_id_128_1782;
      {
	 obj_t arg2576_1908;
	 arg2576_1908 = CNST_TABLE_REF(((long) 18));
	 {
	    obj_t list2578_1910;
	    {
	       obj_t arg2579_1911;
	       {
		  obj_t arg2580_1912;
		  {
		     obj_t aux_4599;
		     aux_4599 = STRUCT_REF(slot_148, ((long) 0));
		     arg2580_1912 = MAKE_PAIR(aux_4599, BNIL);
		  }
		  arg2579_1911 = MAKE_PAIR(arg2576_1908, arg2580_1912);
	       }
	       list2578_1910 = MAKE_PAIR(class_id_86_146, arg2579_1911);
	    }
	    slot_ref_id_128_1782 = symbol_append_197___r4_symbols_6_4(list2578_1910);
	 }
      }
      {
	 obj_t slot_ref_tid_43_1783;
	 {
	    obj_t list2569_1903;
	    {
	       obj_t arg2570_1904;
	       {
		  obj_t arg2573_1905;
		  {
		     obj_t aux_4605;
		     {
			type_t obj_3119;
			{
			   obj_t aux_4606;
			   aux_4606 = STRUCT_REF(slot_148, ((long) 2));
			   obj_3119 = (type_t) (aux_4606);
			}
			aux_4605 = (((type_t) CREF(obj_3119))->id);
		     }
		     arg2573_1905 = MAKE_PAIR(aux_4605, BNIL);
		  }
		  arg2570_1904 = MAKE_PAIR(_4dots_199_tools_misc, arg2573_1905);
	       }
	       list2569_1903 = MAKE_PAIR(slot_ref_id_128_1782, arg2570_1904);
	    }
	    slot_ref_tid_43_1783 = symbol_append_197___r4_symbols_6_4(list2569_1903);
	 }
	 {
	    obj_t tid_1784;
	    {
	       obj_t list2563_1899;
	       {
		  obj_t arg2565_1900;
		  {
		     obj_t aux_4614;
		     {
			type_t obj_3120;
			obj_3120 = (type_t) (type_147);
			aux_4614 = (((type_t) CREF(obj_3120))->id);
		     }
		     arg2565_1900 = MAKE_PAIR(aux_4614, BNIL);
		  }
		  list2563_1899 = MAKE_PAIR(_4dots_199_tools_misc, arg2565_1900);
	       }
	       tid_1784 = symbol_append_197___r4_symbols_6_4(list2563_1899);
	    }
	    {
	       obj_t getter_1785;
	       getter_1785 = STRUCT_REF(slot_148, ((long) 12));
	       {
		  obj_t obj_1787;
		  obj_1787 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
		  {
		     {
			bool_t test2445_1788;
			{
			   long n1_3125;
			   n1_3125 = (long) CINT(_optim__89_engine_param);
			   test2445_1788 = (n1_3125 < ((long) 2));
			}
			if (test2445_1788)
			  {
			     {
				obj_t arg2446_1789;
				{
				   obj_t arg2447_1790;
				   {
				      obj_t list2453_1796;
				      {
					 obj_t arg2454_1797;
					 arg2454_1797 = MAKE_PAIR(BNIL, BNIL);
					 list2453_1796 = MAKE_PAIR(tid_1784, arg2454_1797);
				      }
				      arg2447_1790 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_1783, list2453_1796);
				   }
				   {
				      obj_t list2449_1792;
				      {
					 obj_t arg2450_1793;
					 arg2450_1793 = MAKE_PAIR(BNIL, BNIL);
					 list2449_1792 = MAKE_PAIR(arg2447_1790, arg2450_1793);
				      }
				      arg2446_1789 = cons__138___r4_pairs_and_lists_6_3(import_151, list2449_1792);
				   }
				}
				produce_module_clause__172_module_module(arg2446_1789);
			     }
			     {
				obj_t arg2456_1799;
				{
				   obj_t arg2457_1800;
				   obj_t arg2458_1801;
				   arg2457_1800 = CNST_TABLE_REF(((long) 4));
				   {
				      obj_t arg2464_1806;
				      obj_t arg2465_1807;
				      arg2464_1806 = CNST_TABLE_REF(((long) 5));
				      arg2465_1807 = CNST_TABLE_REF(((long) 6));
				      {
					 obj_t list2467_1809;
					 {
					    obj_t arg2468_1810;
					    {
					       obj_t arg2469_1811;
					       arg2469_1811 = MAKE_PAIR(BNIL, BNIL);
					       arg2468_1810 = MAKE_PAIR(arg2465_1807, arg2469_1811);
					    }
					    list2467_1809 = MAKE_PAIR(arg2464_1806, arg2468_1810);
					 }
					 arg2458_1801 = cons__138___r4_pairs_and_lists_6_3(slot_ref_id_128_1782, list2467_1809);
				      }
				   }
				   {
				      obj_t list2460_1803;
				      {
					 obj_t arg2461_1804;
					 arg2461_1804 = MAKE_PAIR(BNIL, BNIL);
					 list2460_1803 = MAKE_PAIR(arg2458_1801, arg2461_1804);
				      }
				      arg2456_1799 = cons__138___r4_pairs_and_lists_6_3(arg2457_1800, list2460_1803);
				   }
				}
				produce_module_clause__172_module_module(arg2456_1799);
			     }
			     {
				obj_t arg2471_1813;
				{
				   obj_t arg2474_1816;
				   obj_t arg2475_1817;
				   {
				      obj_t arg2479_1821;
				      obj_t arg2480_1822;
				      obj_t arg2481_1823;
				      arg2479_1821 = CNST_TABLE_REF(((long) 25));
				      {
					 obj_t arg2487_1829;
					 {
					    obj_t list2492_1834;
					    {
					       obj_t arg2493_1835;
					       arg2493_1835 = MAKE_PAIR(tid_1784, BNIL);
					       list2492_1834 = MAKE_PAIR(obj_1787, arg2493_1835);
					    }
					    arg2487_1829 = symbol_append_197___r4_symbols_6_4(list2492_1834);
					 }
					 {
					    obj_t list2489_1831;
					    {
					       obj_t arg2490_1832;
					       arg2490_1832 = MAKE_PAIR(BNIL, BNIL);
					       list2489_1831 = MAKE_PAIR(arg2487_1829, arg2490_1832);
					    }
					    arg2480_1822 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_1783, list2489_1831);
					 }
				      }
				      {
					 obj_t list2496_1838;
					 {
					    obj_t arg2497_1839;
					    arg2497_1839 = MAKE_PAIR(BNIL, BNIL);
					    list2496_1838 = MAKE_PAIR(obj_1787, arg2497_1839);
					 }
					 arg2481_1823 = cons__138___r4_pairs_and_lists_6_3(getter_1785, list2496_1838);
				      }
				      {
					 obj_t list2483_1825;
					 {
					    obj_t arg2484_1826;
					    {
					       obj_t arg2485_1827;
					       arg2485_1827 = MAKE_PAIR(BNIL, BNIL);
					       arg2484_1826 = MAKE_PAIR(arg2481_1823, arg2485_1827);
					    }
					    list2483_1825 = MAKE_PAIR(arg2480_1822, arg2484_1826);
					 }
					 arg2474_1816 = cons__138___r4_pairs_and_lists_6_3(arg2479_1821, list2483_1825);
				      }
				   }
				   {
				      bool_t test_4659;
				      if (STRUCTP(slot_148))
					{
					   obj_t aux_4664;
					   obj_t aux_4662;
					   aux_4664 = CNST_TABLE_REF(((long) 48));
					   aux_4662 = STRUCT_KEY(slot_148);
					   test_4659 = (aux_4662 == aux_4664);
					}
				      else
					{
					   test_4659 = ((bool_t) 0);
					}
				      if (test_4659)
					{
					   arg2475_1817 = STRUCT_REF(slot_148, ((long) 14));
					}
				      else
					{
					   arg2475_1817 = slot_148;
					}
				   }
				   {
				      obj_t list2476_1818;
				      {
					 obj_t arg2477_1819;
					 arg2477_1819 = MAKE_PAIR(src_def_101_150, BNIL);
					 list2476_1818 = MAKE_PAIR(arg2475_1817, arg2477_1819);
				      }
				      arg2471_1813 = epairify_object_access(arg2474_1816, list2476_1818);
				   }
				}
				{
				   obj_t list2472_1814;
				   list2472_1814 = MAKE_PAIR(arg2471_1813, BNIL);
				   return list2472_1814;
				}
			     }
			  }
			else
			  {
			     {
				obj_t arg2500_1842;
				{
				   obj_t arg2501_1843;
				   {
				      obj_t arg2507_1848;
				      arg2507_1848 = CNST_TABLE_REF(((long) 12));
				      {
					 obj_t list2509_1850;
					 {
					    obj_t arg2511_1851;
					    {
					       obj_t arg2512_1852;
					       arg2512_1852 = MAKE_PAIR(BNIL, BNIL);
					       arg2511_1851 = MAKE_PAIR(tid_1784, arg2512_1852);
					    }
					    list2509_1850 = MAKE_PAIR(slot_ref_tid_43_1783, arg2511_1851);
					 }
					 arg2501_1843 = cons__138___r4_pairs_and_lists_6_3(arg2507_1848, list2509_1850);
				      }
				   }
				   {
				      obj_t list2503_1845;
				      {
					 obj_t arg2504_1846;
					 arg2504_1846 = MAKE_PAIR(BNIL, BNIL);
					 list2503_1845 = MAKE_PAIR(arg2501_1843, arg2504_1846);
				      }
				      arg2500_1842 = cons__138___r4_pairs_and_lists_6_3(import_151, list2503_1845);
				   }
				}
				produce_module_clause__172_module_module(arg2500_1842);
			     }
			     {
				obj_t arg2515_1854;
				{
				   obj_t arg2516_1855;
				   obj_t arg2517_1856;
				   arg2516_1855 = CNST_TABLE_REF(((long) 4));
				   {
				      obj_t arg2523_1861;
				      obj_t arg2524_1862;
				      arg2523_1861 = CNST_TABLE_REF(((long) 5));
				      arg2524_1862 = CNST_TABLE_REF(((long) 6));
				      {
					 obj_t list2526_1864;
					 {
					    obj_t arg2527_1865;
					    {
					       obj_t arg2528_1866;
					       arg2528_1866 = MAKE_PAIR(BNIL, BNIL);
					       arg2527_1865 = MAKE_PAIR(arg2524_1862, arg2528_1866);
					    }
					    list2526_1864 = MAKE_PAIR(arg2523_1861, arg2527_1865);
					 }
					 arg2517_1856 = cons__138___r4_pairs_and_lists_6_3(slot_ref_id_128_1782, list2526_1864);
				      }
				   }
				   {
				      obj_t list2519_1858;
				      {
					 obj_t arg2520_1859;
					 arg2520_1859 = MAKE_PAIR(BNIL, BNIL);
					 list2519_1858 = MAKE_PAIR(arg2517_1856, arg2520_1859);
				      }
				      arg2515_1854 = cons__138___r4_pairs_and_lists_6_3(arg2516_1855, list2519_1858);
				   }
				}
				produce_module_clause__172_module_module(arg2515_1854);
			     }
			     {
				obj_t arg2530_1868;
				{
				   obj_t arg2533_1871;
				   obj_t arg2534_1872;
				   {
				      obj_t arg2538_1876;
				      obj_t arg2539_1877;
				      obj_t arg2540_1878;
				      arg2538_1876 = CNST_TABLE_REF(((long) 15));
				      {
					 obj_t arg2546_1884;
					 {
					    obj_t list2552_1889;
					    {
					       obj_t arg2553_1890;
					       arg2553_1890 = MAKE_PAIR(tid_1784, BNIL);
					       list2552_1889 = MAKE_PAIR(obj_1787, arg2553_1890);
					    }
					    arg2546_1884 = symbol_append_197___r4_symbols_6_4(list2552_1889);
					 }
					 {
					    obj_t list2548_1886;
					    {
					       obj_t arg2550_1887;
					       arg2550_1887 = MAKE_PAIR(BNIL, BNIL);
					       list2548_1886 = MAKE_PAIR(arg2546_1884, arg2550_1887);
					    }
					    arg2539_1877 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_1783, list2548_1886);
					 }
				      }
				      {
					 obj_t list2557_1893;
					 {
					    obj_t arg2558_1894;
					    arg2558_1894 = MAKE_PAIR(BNIL, BNIL);
					    list2557_1893 = MAKE_PAIR(obj_1787, arg2558_1894);
					 }
					 arg2540_1878 = cons__138___r4_pairs_and_lists_6_3(getter_1785, list2557_1893);
				      }
				      {
					 obj_t list2542_1880;
					 {
					    obj_t arg2543_1881;
					    {
					       obj_t arg2544_1882;
					       arg2544_1882 = MAKE_PAIR(BNIL, BNIL);
					       arg2543_1881 = MAKE_PAIR(arg2540_1878, arg2544_1882);
					    }
					    list2542_1880 = MAKE_PAIR(arg2539_1877, arg2543_1881);
					 }
					 arg2533_1871 = cons__138___r4_pairs_and_lists_6_3(arg2538_1876, list2542_1880);
				      }
				   }
				   {
				      bool_t test_4706;
				      if (STRUCTP(slot_148))
					{
					   obj_t aux_4711;
					   obj_t aux_4709;
					   aux_4711 = CNST_TABLE_REF(((long) 48));
					   aux_4709 = STRUCT_KEY(slot_148);
					   test_4706 = (aux_4709 == aux_4711);
					}
				      else
					{
					   test_4706 = ((bool_t) 0);
					}
				      if (test_4706)
					{
					   arg2534_1872 = STRUCT_REF(slot_148, ((long) 14));
					}
				      else
					{
					   arg2534_1872 = slot_148;
					}
				   }
				   {
				      obj_t list2535_1873;
				      {
					 obj_t arg2536_1874;
					 arg2536_1874 = MAKE_PAIR(src_def_101_150, BNIL);
					 list2535_1873 = MAKE_PAIR(arg2534_1872, arg2536_1874);
				      }
				      arg2530_1868 = epairify_object_access(arg2533_1871, list2535_1873);
				   }
				}
				{
				   obj_t list2531_1869;
				   list2531_1869 = MAKE_PAIR(arg2530_1868, BNIL);
				   return list2531_1869;
				}
			     }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* slot-direct-ref */ obj_t 
slot_direct_ref_183_object_access(obj_t class_id_86_152, obj_t type_153, obj_t slot_154, obj_t widening_155, obj_t src_def_101_156, obj_t import_157)
{
   {
      obj_t slot_ref_id_128_1914;
      {
	 obj_t arg2704_2033;
	 arg2704_2033 = CNST_TABLE_REF(((long) 18));
	 {
	    obj_t list2706_2035;
	    {
	       obj_t arg2707_2036;
	       {
		  obj_t arg2708_2037;
		  {
		     obj_t aux_4720;
		     aux_4720 = STRUCT_REF(slot_154, ((long) 0));
		     arg2708_2037 = MAKE_PAIR(aux_4720, BNIL);
		  }
		  arg2707_2036 = MAKE_PAIR(arg2704_2033, arg2708_2037);
	       }
	       list2706_2035 = MAKE_PAIR(class_id_86_152, arg2707_2036);
	    }
	    slot_ref_id_128_1914 = symbol_append_197___r4_symbols_6_4(list2706_2035);
	 }
      }
      {
	 obj_t slot_ref_tid_43_1915;
	 {
	    obj_t list2699_2028;
	    {
	       obj_t arg2700_2029;
	       {
		  obj_t arg2701_2030;
		  {
		     obj_t aux_4726;
		     {
			type_t obj_3157;
			{
			   obj_t aux_4727;
			   aux_4727 = STRUCT_REF(slot_154, ((long) 2));
			   obj_3157 = (type_t) (aux_4727);
			}
			aux_4726 = (((type_t) CREF(obj_3157))->id);
		     }
		     arg2701_2030 = MAKE_PAIR(aux_4726, BNIL);
		  }
		  arg2700_2029 = MAKE_PAIR(_4dots_199_tools_misc, arg2701_2030);
	       }
	       list2699_2028 = MAKE_PAIR(slot_ref_id_128_1914, arg2700_2029);
	    }
	    slot_ref_tid_43_1915 = symbol_append_197___r4_symbols_6_4(list2699_2028);
	 }
	 {
	    obj_t tid_1916;
	    {
	       obj_t list2695_2024;
	       {
		  obj_t arg2696_2025;
		  {
		     obj_t aux_4735;
		     {
			type_t obj_3158;
			obj_3158 = (type_t) (type_153);
			aux_4735 = (((type_t) CREF(obj_3158))->id);
		     }
		     arg2696_2025 = MAKE_PAIR(aux_4735, BNIL);
		  }
		  list2695_2024 = MAKE_PAIR(_4dots_199_tools_misc, arg2696_2025);
	       }
	       tid_1916 = symbol_append_197___r4_symbols_6_4(list2695_2024);
	    }
	    {
	       {
		  bool_t test2583_1918;
		  {
		     long n1_3160;
		     n1_3160 = (long) CINT(_optim__89_engine_param);
		     test2583_1918 = (n1_3160 < ((long) 2));
		  }
		  if (test2583_1918)
		    {
		       {
			  obj_t arg2584_1919;
			  {
			     obj_t arg2585_1920;
			     {
				obj_t list2592_1926;
				{
				   obj_t arg2593_1927;
				   arg2593_1927 = MAKE_PAIR(BNIL, BNIL);
				   list2592_1926 = MAKE_PAIR(tid_1916, arg2593_1927);
				}
				arg2585_1920 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_1915, list2592_1926);
			     }
			     {
				obj_t list2587_1922;
				{
				   obj_t arg2588_1923;
				   arg2588_1923 = MAKE_PAIR(BNIL, BNIL);
				   list2587_1922 = MAKE_PAIR(arg2585_1920, arg2588_1923);
				}
				arg2584_1919 = cons__138___r4_pairs_and_lists_6_3(import_157, list2587_1922);
			     }
			  }
			  produce_module_clause__172_module_module(arg2584_1919);
		       }
		       {
			  obj_t arg2595_1929;
			  {
			     obj_t arg2596_1930;
			     obj_t arg2597_1931;
			     arg2596_1930 = CNST_TABLE_REF(((long) 4));
			     {
				obj_t arg2602_1936;
				obj_t arg2603_1937;
				arg2602_1936 = CNST_TABLE_REF(((long) 5));
				arg2603_1937 = CNST_TABLE_REF(((long) 6));
				{
				   obj_t list2606_1939;
				   {
				      obj_t arg2607_1940;
				      {
					 obj_t arg2608_1941;
					 arg2608_1941 = MAKE_PAIR(BNIL, BNIL);
					 arg2607_1940 = MAKE_PAIR(arg2603_1937, arg2608_1941);
				      }
				      list2606_1939 = MAKE_PAIR(arg2602_1936, arg2607_1940);
				   }
				   arg2597_1931 = cons__138___r4_pairs_and_lists_6_3(slot_ref_id_128_1914, list2606_1939);
				}
			     }
			     {
				obj_t list2599_1933;
				{
				   obj_t arg2600_1934;
				   arg2600_1934 = MAKE_PAIR(BNIL, BNIL);
				   list2599_1933 = MAKE_PAIR(arg2597_1931, arg2600_1934);
				}
				arg2595_1929 = cons__138___r4_pairs_and_lists_6_3(arg2596_1930, list2599_1933);
			     }
			  }
			  produce_module_clause__172_module_module(arg2595_1929);
		       }
		       {
			  obj_t arg2610_1943;
			  {
			     obj_t arg2613_1946;
			     obj_t arg2614_1947;
			     {
				obj_t arg2618_1951;
				obj_t arg2619_1952;
				obj_t arg2620_1953;
				arg2618_1951 = CNST_TABLE_REF(((long) 25));
				{
				   obj_t arg2626_1959;
				   {
				      obj_t arg2631_1964;
				      arg2631_1964 = CNST_TABLE_REF(((long) 2));
				      {
					 obj_t list2632_1965;
					 {
					    obj_t arg2633_1966;
					    arg2633_1966 = MAKE_PAIR(tid_1916, BNIL);
					    list2632_1965 = MAKE_PAIR(arg2631_1964, arg2633_1966);
					 }
					 arg2626_1959 = symbol_append_197___r4_symbols_6_4(list2632_1965);
				      }
				   }
				   {
				      obj_t list2628_1961;
				      {
					 obj_t arg2629_1962;
					 arg2629_1962 = MAKE_PAIR(BNIL, BNIL);
					 list2628_1961 = MAKE_PAIR(arg2626_1959, arg2629_1962);
				      }
				      arg2619_1952 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_1915, list2628_1961);
				   }
				}
				arg2620_1953 = make_pragma_direct_ref_widening_240_object_tools((type_t) (type_153), slot_154, CNST_TABLE_REF(((long) 2)), widening_155);
				{
				   obj_t list2622_1955;
				   {
				      obj_t arg2623_1956;
				      {
					 obj_t arg2624_1957;
					 arg2624_1957 = MAKE_PAIR(BNIL, BNIL);
					 arg2623_1956 = MAKE_PAIR(arg2620_1953, arg2624_1957);
				      }
				      list2622_1955 = MAKE_PAIR(arg2619_1952, arg2623_1956);
				   }
				   arg2613_1946 = cons__138___r4_pairs_and_lists_6_3(arg2618_1951, list2622_1955);
				}
			     }
			     {
				bool_t test_4777;
				if (STRUCTP(slot_154))
				  {
				     obj_t aux_4782;
				     obj_t aux_4780;
				     aux_4782 = CNST_TABLE_REF(((long) 48));
				     aux_4780 = STRUCT_KEY(slot_154);
				     test_4777 = (aux_4780 == aux_4782);
				  }
				else
				  {
				     test_4777 = ((bool_t) 0);
				  }
				if (test_4777)
				  {
				     arg2614_1947 = STRUCT_REF(slot_154, ((long) 14));
				  }
				else
				  {
				     arg2614_1947 = slot_154;
				  }
			     }
			     {
				obj_t list2615_1948;
				{
				   obj_t arg2616_1949;
				   arg2616_1949 = MAKE_PAIR(src_def_101_156, BNIL);
				   list2615_1948 = MAKE_PAIR(arg2614_1947, arg2616_1949);
				}
				arg2610_1943 = epairify_object_access(arg2613_1946, list2615_1948);
			     }
			  }
			  {
			     obj_t list2611_1944;
			     list2611_1944 = MAKE_PAIR(arg2610_1943, BNIL);
			     return list2611_1944;
			  }
		       }
		    }
		  else
		    {
		       {
			  obj_t arg2638_1970;
			  {
			     obj_t arg2639_1971;
			     {
				obj_t arg2644_1976;
				arg2644_1976 = CNST_TABLE_REF(((long) 12));
				{
				   obj_t list2646_1978;
				   {
				      obj_t arg2647_1979;
				      {
					 obj_t arg2648_1980;
					 arg2648_1980 = MAKE_PAIR(BNIL, BNIL);
					 arg2647_1979 = MAKE_PAIR(tid_1916, arg2648_1980);
				      }
				      list2646_1978 = MAKE_PAIR(slot_ref_tid_43_1915, arg2647_1979);
				   }
				   arg2639_1971 = cons__138___r4_pairs_and_lists_6_3(arg2644_1976, list2646_1978);
				}
			     }
			     {
				obj_t list2641_1973;
				{
				   obj_t arg2642_1974;
				   arg2642_1974 = MAKE_PAIR(BNIL, BNIL);
				   list2641_1973 = MAKE_PAIR(arg2639_1971, arg2642_1974);
				}
				arg2638_1970 = cons__138___r4_pairs_and_lists_6_3(import_157, list2641_1973);
			     }
			  }
			  produce_module_clause__172_module_module(arg2638_1970);
		       }
		       {
			  obj_t arg2650_1982;
			  {
			     obj_t arg2651_1983;
			     obj_t arg2652_1984;
			     arg2651_1983 = CNST_TABLE_REF(((long) 4));
			     {
				obj_t arg2657_1989;
				obj_t arg2658_1990;
				arg2657_1989 = CNST_TABLE_REF(((long) 5));
				arg2658_1990 = CNST_TABLE_REF(((long) 6));
				{
				   obj_t list2660_1992;
				   {
				      obj_t arg2661_1993;
				      {
					 obj_t arg2662_1994;
					 arg2662_1994 = MAKE_PAIR(BNIL, BNIL);
					 arg2661_1993 = MAKE_PAIR(arg2658_1990, arg2662_1994);
				      }
				      list2660_1992 = MAKE_PAIR(arg2657_1989, arg2661_1993);
				   }
				   arg2652_1984 = cons__138___r4_pairs_and_lists_6_3(slot_ref_id_128_1914, list2660_1992);
				}
			     }
			     {
				obj_t list2654_1986;
				{
				   obj_t arg2655_1987;
				   arg2655_1987 = MAKE_PAIR(BNIL, BNIL);
				   list2654_1986 = MAKE_PAIR(arg2652_1984, arg2655_1987);
				}
				arg2650_1982 = cons__138___r4_pairs_and_lists_6_3(arg2651_1983, list2654_1986);
			     }
			  }
			  produce_module_clause__172_module_module(arg2650_1982);
		       }
		       {
			  obj_t arg2664_1996;
			  {
			     obj_t arg2667_1999;
			     obj_t arg2668_2000;
			     {
				obj_t arg2672_2004;
				obj_t arg2673_2005;
				obj_t arg2675_2006;
				arg2672_2004 = CNST_TABLE_REF(((long) 15));
				{
				   obj_t arg2681_2012;
				   {
				      obj_t arg2688_2017;
				      arg2688_2017 = CNST_TABLE_REF(((long) 2));
				      {
					 obj_t list2689_2018;
					 {
					    obj_t arg2690_2019;
					    arg2690_2019 = MAKE_PAIR(tid_1916, BNIL);
					    list2689_2018 = MAKE_PAIR(arg2688_2017, arg2690_2019);
					 }
					 arg2681_2012 = symbol_append_197___r4_symbols_6_4(list2689_2018);
				      }
				   }
				   {
				      obj_t list2684_2014;
				      {
					 obj_t arg2685_2015;
					 arg2685_2015 = MAKE_PAIR(BNIL, BNIL);
					 list2684_2014 = MAKE_PAIR(arg2681_2012, arg2685_2015);
				      }
				      arg2673_2005 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_1915, list2684_2014);
				   }
				}
				arg2675_2006 = make_pragma_direct_ref_widening_240_object_tools((type_t) (type_153), slot_154, CNST_TABLE_REF(((long) 2)), widening_155);
				{
				   obj_t list2677_2008;
				   {
				      obj_t arg2678_2009;
				      {
					 obj_t arg2679_2010;
					 arg2679_2010 = MAKE_PAIR(BNIL, BNIL);
					 arg2678_2009 = MAKE_PAIR(arg2675_2006, arg2679_2010);
				      }
				      list2677_2008 = MAKE_PAIR(arg2673_2005, arg2678_2009);
				   }
				   arg2667_1999 = cons__138___r4_pairs_and_lists_6_3(arg2672_2004, list2677_2008);
				}
			     }
			     {
				bool_t test_4825;
				if (STRUCTP(slot_154))
				  {
				     obj_t aux_4830;
				     obj_t aux_4828;
				     aux_4830 = CNST_TABLE_REF(((long) 48));
				     aux_4828 = STRUCT_KEY(slot_154);
				     test_4825 = (aux_4828 == aux_4830);
				  }
				else
				  {
				     test_4825 = ((bool_t) 0);
				  }
				if (test_4825)
				  {
				     arg2668_2000 = STRUCT_REF(slot_154, ((long) 14));
				  }
				else
				  {
				     arg2668_2000 = slot_154;
				  }
			     }
			     {
				obj_t list2669_2001;
				{
				   obj_t arg2670_2002;
				   arg2670_2002 = MAKE_PAIR(src_def_101_156, BNIL);
				   list2669_2001 = MAKE_PAIR(arg2668_2000, arg2670_2002);
				}
				arg2664_1996 = epairify_object_access(arg2667_1999, list2669_2001);
			     }
			  }
			  {
			     obj_t list2665_1997;
			     list2665_1997 = MAKE_PAIR(arg2664_1996, BNIL);
			     return list2665_1997;
			  }
		       }
		    }
	       }
	    }
	 }
      }
   }
}


/* slot-set! */ obj_t 
slot_set__144_object_access(obj_t class_id_86_158, obj_t type_159, obj_t slot_160, obj_t widening_161, obj_t src_def_101_162, obj_t import_163)
{
   {
      bool_t test_4838;
      {
	 obj_t aux_4839;
	 aux_4839 = STRUCT_REF(slot_160, ((long) 5));
	 test_4838 = CBOOL(aux_4839);
      }
      if (test_4838)
	{
	   return slot_dyna_indexed_set__50_object_access(class_id_86_158, type_159, slot_160, widening_161, src_def_101_162, import_163);
	}
      else
	{
	   bool_t test_4843;
	   {
	      obj_t aux_4844;
	      aux_4844 = STRUCT_REF(slot_160, ((long) 3));
	      test_4843 = CBOOL(aux_4844);
	   }
	   if (test_4843)
	     {
		{
		   obj_t arg2730_3198;
		   {
		      obj_t arg2731_3199;
		      obj_t arg2732_3200;
		      arg2731_3199 = CNST_TABLE_REF(((long) 40));
		      arg2732_3200 = STRUCT_REF(slot_160, ((long) 4));
		      {
			 obj_t list2734_3202;
			 {
			    obj_t arg2735_3203;
			    arg2735_3203 = MAKE_PAIR(BNIL, BNIL);
			    list2734_3202 = MAKE_PAIR(arg2732_3200, arg2735_3203);
			 }
			 arg2730_3198 = cons__138___r4_pairs_and_lists_6_3(arg2731_3199, list2734_3202);
		      }
		   }
		   return slot_indexed_set__217_object_access(class_id_86_158, type_159, slot_160, widening_161, arg2730_3198, src_def_101_162, import_163);
		}
	     }
	   else
	     {
		bool_t test_4853;
		{
		   obj_t aux_4854;
		   aux_4854 = STRUCT_REF(slot_160, ((long) 11));
		   test_4853 = CBOOL(aux_4854);
		}
		if (test_4853)
		  {
		     return slot_virtual_set__86_object_access(class_id_86_158, type_159, slot_160, widening_161, src_def_101_162, import_163);
		  }
		else
		  {
		     return slot_direct_set__173_object_access(class_id_86_158, type_159, slot_160, widening_161, src_def_101_162, import_163);
		  }
	     }
	}
   }
}


/* slot-dyna-indexed-set! */ obj_t 
slot_dyna_indexed_set__50_object_access(obj_t class_id_86_164, obj_t type_165, obj_t slot_166, obj_t widening_167, obj_t src_def_101_168, obj_t import_169)
{
   {
      obj_t arg2713_2042;
      {
	 obj_t arg2714_2043;
	 obj_t arg2715_2044;
	 {
	    obj_t arg2721_2049;
	    obj_t arg2722_2050;
	    arg2721_2049 = CNST_TABLE_REF(((long) 18));
	    arg2722_2050 = STRUCT_REF(slot_166, ((long) 0));
	    {
	       obj_t list2725_2052;
	       {
		  obj_t arg2726_2053;
		  {
		     obj_t arg2727_2054;
		     {
			obj_t arg2728_2055;
			{
			   obj_t aux_4861;
			   aux_4861 = CNST_TABLE_REF(((long) 33));
			   arg2728_2055 = MAKE_PAIR(aux_4861, BNIL);
			}
			arg2727_2054 = MAKE_PAIR(arg2722_2050, arg2728_2055);
		     }
		     arg2726_2053 = MAKE_PAIR(arg2721_2049, arg2727_2054);
		  }
		  list2725_2052 = MAKE_PAIR(class_id_86_164, arg2726_2053);
	       }
	       arg2714_2043 = symbol_append_197___r4_symbols_6_4(list2725_2052);
	    }
	 }
	 arg2715_2044 = CNST_TABLE_REF(((long) 2));
	 {
	    obj_t list2717_2046;
	    {
	       obj_t arg2718_2047;
	       arg2718_2047 = MAKE_PAIR(BNIL, BNIL);
	       list2717_2046 = MAKE_PAIR(arg2715_2044, arg2718_2047);
	    }
	    arg2713_2042 = cons__138___r4_pairs_and_lists_6_3(arg2714_2043, list2717_2046);
	 }
      }
      return slot_indexed_set__217_object_access(class_id_86_164, type_165, slot_166, widening_167, arg2713_2042, src_def_101_168, import_169);
   }
}


/* slot-indexed-set! */ obj_t 
slot_indexed_set__217_object_access(obj_t class_id_86_176, obj_t type_177, obj_t slot_178, obj_t widening_179, obj_t max_bound_128_180, obj_t src_def_101_181, obj_t import_182)
{
   {
      obj_t slot_set__id_195_2229;
      obj_t slot_set__tid_15_2230;
      obj_t val_id_206_2231;
      obj_t val_tid_245_2232;
      obj_t slot_set__id_195_2129;
      obj_t slot_set__tid_15_2130;
      obj_t val_id_206_2131;
      obj_t val_tid_245_2132;
      {
	 obj_t slot_set__id_195_2066;
	 {
	    obj_t arg2786_2121;
	    obj_t arg2787_2122;
	    arg2786_2121 = CNST_TABLE_REF(((long) 18));
	    arg2787_2122 = STRUCT_REF(slot_178, ((long) 0));
	    {
	       obj_t list2789_2124;
	       {
		  obj_t arg2790_2125;
		  {
		     obj_t arg2791_2126;
		     {
			obj_t arg2792_2127;
			{
			   obj_t aux_4875;
			   aux_4875 = CNST_TABLE_REF(((long) 50));
			   arg2792_2127 = MAKE_PAIR(aux_4875, BNIL);
			}
			arg2791_2126 = MAKE_PAIR(arg2787_2122, arg2792_2127);
		     }
		     arg2790_2125 = MAKE_PAIR(arg2786_2121, arg2791_2126);
		  }
		  list2789_2124 = MAKE_PAIR(class_id_86_176, arg2790_2125);
	       }
	       slot_set__id_195_2066 = symbol_append_197___r4_symbols_6_4(list2789_2124);
	    }
	 }
	 {
	    obj_t slot_set__tid_15_2067;
	    {
	       obj_t list2783_2118;
	       {
		  obj_t arg2784_2119;
		  {
		     obj_t aux_4882;
		     aux_4882 = CNST_TABLE_REF(((long) 13));
		     arg2784_2119 = MAKE_PAIR(aux_4882, BNIL);
		  }
		  list2783_2118 = MAKE_PAIR(slot_set__id_195_2066, arg2784_2119);
	       }
	       slot_set__tid_15_2067 = symbol_append_197___r4_symbols_6_4(list2783_2118);
	    }
	    {
	       obj_t tid_2068;
	       {
		  obj_t list2779_2114;
		  {
		     obj_t arg2780_2115;
		     {
			obj_t aux_4887;
			{
			   type_t obj_3227;
			   obj_3227 = (type_t) (type_177);
			   aux_4887 = (((type_t) CREF(obj_3227))->id);
			}
			arg2780_2115 = MAKE_PAIR(aux_4887, BNIL);
		     }
		     list2779_2114 = MAKE_PAIR(_4dots_199_tools_misc, arg2780_2115);
		  }
		  tid_2068 = symbol_append_197___r4_symbols_6_4(list2779_2114);
	       }
	       {
		  obj_t v_id_210_2070;
		  v_id_210_2070 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 51)), BEOA);
		  {
		     obj_t v_tid_138_2071;
		     {
			obj_t list2772_2107;
			{
			   obj_t arg2773_2108;
			   {
			      obj_t arg2774_2109;
			      {
				 obj_t aux_4896;
				 {
				    type_t obj_3232;
				    {
				       obj_t aux_4897;
				       aux_4897 = STRUCT_REF(slot_178, ((long) 2));
				       obj_3232 = (type_t) (aux_4897);
				    }
				    aux_4896 = (((type_t) CREF(obj_3232))->id);
				 }
				 arg2774_2109 = MAKE_PAIR(aux_4896, BNIL);
			      }
			      arg2773_2108 = MAKE_PAIR(_4dots_199_tools_misc, arg2774_2109);
			   }
			   list2772_2107 = MAKE_PAIR(v_id_210_2070, arg2773_2108);
			}
			v_tid_138_2071 = symbol_append_197___r4_symbols_6_4(list2772_2107);
		     }
		     {
			if (CBOOL(_unsafe_range__218_engine_param))
			  {
			     {
				obj_t arg2737_2072;
				{
				   obj_t arg2738_2073;
				   {
				      obj_t arg2743_2078;
				      obj_t arg2744_2079;
				      arg2743_2078 = CNST_TABLE_REF(((long) 12));
				      arg2744_2079 = CNST_TABLE_REF(((long) 23));
				      {
					 obj_t list2746_2081;
					 {
					    obj_t arg2747_2082;
					    {
					       obj_t arg2748_2083;
					       {
						  obj_t arg2749_2084;
						  {
						     obj_t arg2750_2085;
						     arg2750_2085 = MAKE_PAIR(BNIL, BNIL);
						     arg2749_2084 = MAKE_PAIR(v_tid_138_2071, arg2750_2085);
						  }
						  arg2748_2083 = MAKE_PAIR(arg2744_2079, arg2749_2084);
					       }
					       arg2747_2082 = MAKE_PAIR(tid_2068, arg2748_2083);
					    }
					    list2746_2081 = MAKE_PAIR(slot_set__tid_15_2067, arg2747_2082);
					 }
					 arg2738_2073 = cons__138___r4_pairs_and_lists_6_3(arg2743_2078, list2746_2081);
				      }
				   }
				   {
				      obj_t list2740_2075;
				      {
					 obj_t arg2741_2076;
					 arg2741_2076 = MAKE_PAIR(BNIL, BNIL);
					 list2740_2075 = MAKE_PAIR(arg2738_2073, arg2741_2076);
				      }
				      arg2737_2072 = cons__138___r4_pairs_and_lists_6_3(import_182, list2740_2075);
				   }
				}
				produce_module_clause__172_module_module(arg2737_2072);
			     }
			     {
				obj_t arg2752_2087;
				slot_set__id_195_2229 = slot_set__id_195_2066;
				slot_set__tid_15_2230 = slot_set__tid_15_2067;
				val_id_206_2231 = v_id_210_2070;
				val_tid_245_2232 = v_tid_138_2071;
				{
				   obj_t arg2894_2234;
				   obj_t arg2895_2235;
				   {
				      obj_t arg2899_2239;
				      obj_t arg2900_2240;
				      obj_t arg2901_2241;
				      arg2899_2239 = CNST_TABLE_REF(((long) 15));
				      {
					 obj_t arg2908_2247;
					 obj_t arg2909_2248;
					 {
					    obj_t arg2916_2255;
					    arg2916_2255 = CNST_TABLE_REF(((long) 2));
					    {
					       obj_t list2918_2257;
					       {
						  obj_t arg2919_2258;
						  {
						     obj_t arg2920_2259;
						     {
							obj_t aux_4921;
							{
							   type_t obj_3247;
							   obj_3247 = (type_t) (type_177);
							   aux_4921 = (((type_t) CREF(obj_3247))->id);
							}
							arg2920_2259 = MAKE_PAIR(aux_4921, BNIL);
						     }
						     arg2919_2258 = MAKE_PAIR(_4dots_199_tools_misc, arg2920_2259);
						  }
						  list2918_2257 = MAKE_PAIR(arg2916_2255, arg2919_2258);
					       }
					       arg2908_2247 = symbol_append_197___r4_symbols_6_4(list2918_2257);
					    }
					 }
					 arg2909_2248 = CNST_TABLE_REF(((long) 43));
					 {
					    obj_t list2911_2250;
					    {
					       obj_t arg2912_2251;
					       {
						  obj_t arg2913_2252;
						  {
						     obj_t arg2914_2253;
						     arg2914_2253 = MAKE_PAIR(BNIL, BNIL);
						     arg2913_2252 = MAKE_PAIR(val_tid_245_2232, arg2914_2253);
						  }
						  arg2912_2251 = MAKE_PAIR(arg2909_2248, arg2913_2252);
					       }
					       list2911_2250 = MAKE_PAIR(arg2908_2247, arg2912_2251);
					    }
					    arg2900_2240 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2230, list2911_2250);
					 }
				      }
				      arg2901_2241 = make_pragma_indexed_set__widening_24_object_tools((type_t) (type_177), slot_178, CNST_TABLE_REF(((long) 2)), val_id_206_2231, CNST_TABLE_REF(((long) 45)), widening_179);
				      {
					 obj_t list2903_2243;
					 {
					    obj_t arg2905_2244;
					    {
					       obj_t arg2906_2245;
					       arg2906_2245 = MAKE_PAIR(BNIL, BNIL);
					       arg2905_2244 = MAKE_PAIR(arg2901_2241, arg2906_2245);
					    }
					    list2903_2243 = MAKE_PAIR(arg2900_2240, arg2905_2244);
					 }
					 arg2894_2234 = cons__138___r4_pairs_and_lists_6_3(arg2899_2239, list2903_2243);
				      }
				   }
				   {
				      bool_t test_4942;
				      if (STRUCTP(slot_178))
					{
					   obj_t aux_4947;
					   obj_t aux_4945;
					   aux_4947 = CNST_TABLE_REF(((long) 48));
					   aux_4945 = STRUCT_KEY(slot_178);
					   test_4942 = (aux_4945 == aux_4947);
					}
				      else
					{
					   test_4942 = ((bool_t) 0);
					}
				      if (test_4942)
					{
					   arg2895_2235 = STRUCT_REF(slot_178, ((long) 14));
					}
				      else
					{
					   arg2895_2235 = slot_178;
					}
				   }
				   {
				      obj_t list2896_2236;
				      {
					 obj_t arg2897_2237;
					 arg2897_2237 = MAKE_PAIR(src_def_101_181, BNIL);
					 list2896_2236 = MAKE_PAIR(arg2895_2235, arg2897_2237);
				      }
				      arg2752_2087 = epairify_object_access(arg2894_2234, list2896_2236);
				   }
				}
				{
				   obj_t list2753_2088;
				   list2753_2088 = MAKE_PAIR(arg2752_2087, BNIL);
				   return list2753_2088;
				}
			     }
			  }
			else
			  {
			     {
				obj_t arg2755_2090;
				{
				   obj_t arg2756_2091;
				   {
				      obj_t arg2761_2096;
				      arg2761_2096 = CNST_TABLE_REF(((long) 23));
				      {
					 obj_t list2763_2098;
					 {
					    obj_t arg2764_2099;
					    {
					       obj_t arg2765_2100;
					       {
						  obj_t arg2766_2101;
						  arg2766_2101 = MAKE_PAIR(BNIL, BNIL);
						  arg2765_2100 = MAKE_PAIR(v_tid_138_2071, arg2766_2101);
					       }
					       arg2764_2099 = MAKE_PAIR(arg2761_2096, arg2765_2100);
					    }
					    list2763_2098 = MAKE_PAIR(tid_2068, arg2764_2099);
					 }
					 arg2756_2091 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2067, list2763_2098);
				      }
				   }
				   {
				      obj_t list2758_2093;
				      {
					 obj_t arg2759_2094;
					 arg2759_2094 = MAKE_PAIR(BNIL, BNIL);
					 list2758_2093 = MAKE_PAIR(arg2756_2091, arg2759_2094);
				      }
				      arg2755_2090 = cons__138___r4_pairs_and_lists_6_3(import_182, list2758_2093);
				   }
				}
				produce_module_clause__172_module_module(arg2755_2090);
			     }
			     {
				obj_t arg2768_2103;
				slot_set__id_195_2129 = slot_set__id_195_2066;
				slot_set__tid_15_2130 = slot_set__tid_15_2067;
				val_id_206_2131 = v_id_210_2070;
				val_tid_245_2132 = v_tid_138_2071;
				{
				   obj_t arg2795_2134;
				   obj_t arg2796_2135;
				   {
				      obj_t arg2800_2139;
				      obj_t arg2801_2140;
				      obj_t arg2802_2141;
				      arg2800_2139 = CNST_TABLE_REF(((long) 25));
				      {
					 obj_t arg2808_2147;
					 obj_t arg2809_2148;
					 {
					    obj_t arg2816_2155;
					    arg2816_2155 = CNST_TABLE_REF(((long) 2));
					    {
					       obj_t list2818_2157;
					       {
						  obj_t arg2819_2158;
						  {
						     obj_t arg2820_2159;
						     {
							obj_t aux_4967;
							{
							   type_t obj_3235;
							   obj_3235 = (type_t) (type_177);
							   aux_4967 = (((type_t) CREF(obj_3235))->id);
							}
							arg2820_2159 = MAKE_PAIR(aux_4967, BNIL);
						     }
						     arg2819_2158 = MAKE_PAIR(_4dots_199_tools_misc, arg2820_2159);
						  }
						  list2818_2157 = MAKE_PAIR(arg2816_2155, arg2819_2158);
					       }
					       arg2808_2147 = symbol_append_197___r4_symbols_6_4(list2818_2157);
					    }
					 }
					 arg2809_2148 = CNST_TABLE_REF(((long) 43));
					 {
					    obj_t list2811_2150;
					    {
					       obj_t arg2812_2151;
					       {
						  obj_t arg2813_2152;
						  {
						     obj_t arg2814_2153;
						     arg2814_2153 = MAKE_PAIR(BNIL, BNIL);
						     arg2813_2152 = MAKE_PAIR(val_tid_245_2132, arg2814_2153);
						  }
						  arg2812_2151 = MAKE_PAIR(arg2809_2148, arg2813_2152);
					       }
					       list2811_2150 = MAKE_PAIR(arg2808_2147, arg2812_2151);
					    }
					    arg2801_2140 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2130, list2811_2150);
					 }
				      }
				      {
					 obj_t arg2822_2161;
					 obj_t arg2823_2162;
					 obj_t arg2824_2163;
					 obj_t arg2825_2164;
					 arg2822_2161 = CNST_TABLE_REF(((long) 35));
					 {
					    obj_t arg2832_2171;
					    obj_t arg2833_2172;
					    arg2832_2171 = CNST_TABLE_REF(((long) 44));
					    arg2833_2172 = CNST_TABLE_REF(((long) 45));
					    {
					       obj_t list2836_2175;
					       {
						  obj_t arg2837_2176;
						  {
						     obj_t arg2838_2177;
						     arg2838_2177 = MAKE_PAIR(BNIL, BNIL);
						     {
							obj_t aux_4984;
							aux_4984 = BINT(((long) 0));
							arg2837_2176 = MAKE_PAIR(aux_4984, arg2838_2177);
						     }
						  }
						  list2836_2175 = MAKE_PAIR(arg2833_2172, arg2837_2176);
					       }
					       arg2823_2162 = cons__138___r4_pairs_and_lists_6_3(arg2832_2171, list2836_2175);
					    }
					 }
					 {
					    obj_t arg2840_2179;
					    obj_t arg2841_2180;
					    obj_t arg2842_2181;
					    obj_t arg2843_2182;
					    arg2840_2179 = CNST_TABLE_REF(((long) 35));
					    {
					       obj_t arg2850_2189;
					       obj_t arg2851_2190;
					       arg2850_2189 = CNST_TABLE_REF(((long) 46));
					       arg2851_2190 = CNST_TABLE_REF(((long) 45));
					       {
						  obj_t list2853_2192;
						  {
						     obj_t arg2854_2193;
						     {
							obj_t arg2855_2194;
							arg2855_2194 = MAKE_PAIR(BNIL, BNIL);
							arg2854_2193 = MAKE_PAIR(max_bound_128_180, arg2855_2194);
						     }
						     list2853_2192 = MAKE_PAIR(arg2851_2190, arg2854_2193);
						  }
						  arg2841_2180 = cons__138___r4_pairs_and_lists_6_3(arg2850_2189, list2853_2192);
					       }
					    }
					    arg2842_2181 = make_pragma_indexed_set__widening_24_object_tools((type_t) (type_177), slot_178, CNST_TABLE_REF(((long) 2)), val_id_206_2131, CNST_TABLE_REF(((long) 45)), widening_179);
					    {
					       obj_t arg2859_2198;
					       obj_t arg2860_2199;
					       obj_t arg2862_2201;
					       arg2859_2198 = CNST_TABLE_REF(((long) 47));
					       {
						  obj_t arg2869_2208;
						  arg2869_2208 = CNST_TABLE_REF(((long) 37));
						  {
						     obj_t list2871_2210;
						     {
							obj_t arg2872_2211;
							arg2872_2211 = MAKE_PAIR(BNIL, BNIL);
							list2871_2210 = MAKE_PAIR(slot_set__id_195_2129, arg2872_2211);
						     }
						     arg2860_2199 = cons__138___r4_pairs_and_lists_6_3(arg2869_2208, list2871_2210);
						  }
					       }
					       arg2862_2201 = CNST_TABLE_REF(((long) 45));
					       {
						  obj_t list2864_2203;
						  {
						     obj_t arg2865_2204;
						     {
							obj_t arg2866_2205;
							{
							   obj_t arg2867_2206;
							   arg2867_2206 = MAKE_PAIR(BNIL, BNIL);
							   arg2866_2205 = MAKE_PAIR(arg2862_2201, arg2867_2206);
							}
							arg2865_2204 = MAKE_PAIR(string3359_object_access, arg2866_2205);
						     }
						     list2864_2203 = MAKE_PAIR(arg2860_2199, arg2865_2204);
						  }
						  arg2843_2182 = cons__138___r4_pairs_and_lists_6_3(arg2859_2198, list2864_2203);
					       }
					    }
					    {
					       obj_t list2845_2184;
					       {
						  obj_t arg2846_2185;
						  {
						     obj_t arg2847_2186;
						     {
							obj_t arg2848_2187;
							arg2848_2187 = MAKE_PAIR(BNIL, BNIL);
							arg2847_2186 = MAKE_PAIR(arg2843_2182, arg2848_2187);
						     }
						     arg2846_2185 = MAKE_PAIR(arg2842_2181, arg2847_2186);
						  }
						  list2845_2184 = MAKE_PAIR(arg2841_2180, arg2846_2185);
					       }
					       arg2824_2163 = cons__138___r4_pairs_and_lists_6_3(arg2840_2179, list2845_2184);
					    }
					 }
					 {
					    obj_t arg2874_2213;
					    obj_t arg2875_2214;
					    obj_t arg2877_2216;
					    arg2874_2213 = CNST_TABLE_REF(((long) 47));
					    {
					       obj_t arg2886_2223;
					       arg2886_2223 = CNST_TABLE_REF(((long) 37));
					       {
						  obj_t list2889_2225;
						  {
						     obj_t arg2890_2226;
						     arg2890_2226 = MAKE_PAIR(BNIL, BNIL);
						     list2889_2225 = MAKE_PAIR(slot_set__id_195_2129, arg2890_2226);
						  }
						  arg2875_2214 = cons__138___r4_pairs_and_lists_6_3(arg2886_2223, list2889_2225);
					       }
					    }
					    arg2877_2216 = CNST_TABLE_REF(((long) 45));
					    {
					       obj_t list2879_2218;
					       {
						  obj_t arg2880_2219;
						  {
						     obj_t arg2882_2220;
						     {
							obj_t arg2883_2221;
							arg2883_2221 = MAKE_PAIR(BNIL, BNIL);
							arg2882_2220 = MAKE_PAIR(arg2877_2216, arg2883_2221);
						     }
						     arg2880_2219 = MAKE_PAIR(string3359_object_access, arg2882_2220);
						  }
						  list2879_2218 = MAKE_PAIR(arg2875_2214, arg2880_2219);
					       }
					       arg2825_2164 = cons__138___r4_pairs_and_lists_6_3(arg2874_2213, list2879_2218);
					    }
					 }
					 {
					    obj_t list2827_2166;
					    {
					       obj_t arg2828_2167;
					       {
						  obj_t arg2829_2168;
						  {
						     obj_t arg2830_2169;
						     arg2830_2169 = MAKE_PAIR(BNIL, BNIL);
						     arg2829_2168 = MAKE_PAIR(arg2825_2164, arg2830_2169);
						  }
						  arg2828_2167 = MAKE_PAIR(arg2824_2163, arg2829_2168);
					       }
					       list2827_2166 = MAKE_PAIR(arg2823_2162, arg2828_2167);
					    }
					    arg2802_2141 = cons__138___r4_pairs_and_lists_6_3(arg2822_2161, list2827_2166);
					 }
				      }
				      {
					 obj_t list2804_2143;
					 {
					    obj_t arg2805_2144;
					    {
					       obj_t arg2806_2145;
					       arg2806_2145 = MAKE_PAIR(BNIL, BNIL);
					       arg2805_2144 = MAKE_PAIR(arg2802_2141, arg2806_2145);
					    }
					    list2804_2143 = MAKE_PAIR(arg2801_2140, arg2805_2144);
					 }
					 arg2795_2134 = cons__138___r4_pairs_and_lists_6_3(arg2800_2139, list2804_2143);
				      }
				   }
				   {
				      bool_t test_5036;
				      if (STRUCTP(slot_178))
					{
					   obj_t aux_5041;
					   obj_t aux_5039;
					   aux_5041 = CNST_TABLE_REF(((long) 48));
					   aux_5039 = STRUCT_KEY(slot_178);
					   test_5036 = (aux_5039 == aux_5041);
					}
				      else
					{
					   test_5036 = ((bool_t) 0);
					}
				      if (test_5036)
					{
					   arg2796_2135 = STRUCT_REF(slot_178, ((long) 14));
					}
				      else
					{
					   arg2796_2135 = slot_178;
					}
				   }
				   {
				      obj_t list2797_2136;
				      {
					 obj_t arg2798_2137;
					 arg2798_2137 = MAKE_PAIR(src_def_101_181, BNIL);
					 list2797_2136 = MAKE_PAIR(arg2796_2135, arg2798_2137);
				      }
				      arg2768_2103 = epairify_object_access(arg2795_2134, list2797_2136);
				   }
				}
				{
				   obj_t list2769_2104;
				   list2769_2104 = MAKE_PAIR(arg2768_2103, BNIL);
				   return list2769_2104;
				}
			     }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* slot-virtual-set! */ obj_t 
slot_virtual_set__86_object_access(obj_t class_id_86_183, obj_t type_184, obj_t slot_185, obj_t widening_186, obj_t src_def_101_187, obj_t import_188)
{
   {
      obj_t slot_set__id_195_2266;
      {
	 obj_t arg3036_2377;
	 obj_t arg3037_2378;
	 arg3036_2377 = CNST_TABLE_REF(((long) 18));
	 arg3037_2378 = STRUCT_REF(slot_185, ((long) 0));
	 {
	    obj_t list3039_2380;
	    {
	       obj_t arg3040_2381;
	       {
		  obj_t arg3041_2382;
		  {
		     obj_t arg3042_2383;
		     {
			obj_t aux_5051;
			aux_5051 = CNST_TABLE_REF(((long) 50));
			arg3042_2383 = MAKE_PAIR(aux_5051, BNIL);
		     }
		     arg3041_2382 = MAKE_PAIR(arg3037_2378, arg3042_2383);
		  }
		  arg3040_2381 = MAKE_PAIR(arg3036_2377, arg3041_2382);
	       }
	       list3039_2380 = MAKE_PAIR(class_id_86_183, arg3040_2381);
	    }
	    slot_set__id_195_2266 = symbol_append_197___r4_symbols_6_4(list3039_2380);
	 }
      }
      {
	 obj_t slot_set__tid_15_2267;
	 {
	    obj_t list3033_2374;
	    {
	       obj_t arg3034_2375;
	       {
		  obj_t aux_5058;
		  aux_5058 = CNST_TABLE_REF(((long) 13));
		  arg3034_2375 = MAKE_PAIR(aux_5058, BNIL);
	       }
	       list3033_2374 = MAKE_PAIR(slot_set__id_195_2266, arg3034_2375);
	    }
	    slot_set__tid_15_2267 = symbol_append_197___r4_symbols_6_4(list3033_2374);
	 }
	 {
	    obj_t tid_2268;
	    {
	       obj_t list3029_2370;
	       {
		  obj_t arg3030_2371;
		  {
		     obj_t aux_5063;
		     {
			type_t obj_3262;
			obj_3262 = (type_t) (type_184);
			aux_5063 = (((type_t) CREF(obj_3262))->id);
		     }
		     arg3030_2371 = MAKE_PAIR(aux_5063, BNIL);
		  }
		  list3029_2370 = MAKE_PAIR(_4dots_199_tools_misc, arg3030_2371);
	       }
	       tid_2268 = symbol_append_197___r4_symbols_6_4(list3029_2370);
	    }
	    {
	       obj_t setter_2270;
	       setter_2270 = STRUCT_REF(slot_185, ((long) 13));
	       {
		  obj_t v_id_210_2271;
		  v_id_210_2271 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 51)), BEOA);
		  {
		     obj_t obj_2272;
		     obj_2272 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
		     {
			obj_t v_tid_138_2273;
			{
			   obj_t list3021_2362;
			   {
			      obj_t arg3022_2363;
			      {
				 obj_t arg3023_2364;
				 {
				    obj_t aux_5076;
				    {
				       type_t obj_3270;
				       {
					  obj_t aux_5077;
					  aux_5077 = STRUCT_REF(slot_185, ((long) 2));
					  obj_3270 = (type_t) (aux_5077);
				       }
				       aux_5076 = (((type_t) CREF(obj_3270))->id);
				    }
				    arg3023_2364 = MAKE_PAIR(aux_5076, BNIL);
				 }
				 arg3022_2363 = MAKE_PAIR(_4dots_199_tools_misc, arg3023_2364);
			      }
			      list3021_2362 = MAKE_PAIR(v_id_210_2271, arg3022_2363);
			   }
			   v_tid_138_2273 = symbol_append_197___r4_symbols_6_4(list3021_2362);
			}
			{
			   {
			      bool_t test2925_2274;
			      {
				 long n1_3271;
				 n1_3271 = (long) CINT(_optim__89_engine_param);
				 test2925_2274 = (n1_3271 < ((long) 2));
			      }
			      if (test2925_2274)
				{
				   {
				      obj_t arg2926_2275;
				      {
					 obj_t arg2927_2276;
					 {
					    obj_t list2934_2282;
					    {
					       obj_t arg2935_2283;
					       {
						  obj_t arg2936_2284;
						  arg2936_2284 = MAKE_PAIR(BNIL, BNIL);
						  arg2935_2283 = MAKE_PAIR(v_tid_138_2273, arg2936_2284);
					       }
					       list2934_2282 = MAKE_PAIR(tid_2268, arg2935_2283);
					    }
					    arg2927_2276 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2267, list2934_2282);
					 }
					 {
					    obj_t list2929_2278;
					    {
					       obj_t arg2930_2279;
					       arg2930_2279 = MAKE_PAIR(BNIL, BNIL);
					       list2929_2278 = MAKE_PAIR(arg2927_2276, arg2930_2279);
					    }
					    arg2926_2275 = cons__138___r4_pairs_and_lists_6_3(import_188, list2929_2278);
					 }
				      }
				      produce_module_clause__172_module_module(arg2926_2275);
				   }
				   {
				      obj_t arg2938_2286;
				      {
					 obj_t arg2941_2289;
					 obj_t arg2942_2290;
					 {
					    obj_t arg2946_2294;
					    obj_t arg2947_2295;
					    obj_t arg2948_2296;
					    arg2946_2294 = CNST_TABLE_REF(((long) 25));
					    {
					       obj_t arg2955_2302;
					       {
						  obj_t list2962_2308;
						  {
						     obj_t arg2963_2309;
						     arg2963_2309 = MAKE_PAIR(tid_2268, BNIL);
						     list2962_2308 = MAKE_PAIR(obj_2272, arg2963_2309);
						  }
						  arg2955_2302 = symbol_append_197___r4_symbols_6_4(list2962_2308);
					       }
					       {
						  obj_t list2958_2304;
						  {
						     obj_t arg2959_2305;
						     {
							obj_t arg2960_2306;
							arg2960_2306 = MAKE_PAIR(BNIL, BNIL);
							arg2959_2305 = MAKE_PAIR(v_tid_138_2273, arg2960_2306);
						     }
						     list2958_2304 = MAKE_PAIR(arg2955_2302, arg2959_2305);
						  }
						  arg2947_2295 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2267, list2958_2304);
					       }
					    }
					    {
					       obj_t list2966_2312;
					       {
						  obj_t arg2967_2313;
						  {
						     obj_t arg2968_2314;
						     arg2968_2314 = MAKE_PAIR(BNIL, BNIL);
						     arg2967_2313 = MAKE_PAIR(v_id_210_2271, arg2968_2314);
						  }
						  list2966_2312 = MAKE_PAIR(obj_2272, arg2967_2313);
					       }
					       arg2948_2296 = cons__138___r4_pairs_and_lists_6_3(setter_2270, list2966_2312);
					    }
					    {
					       obj_t list2950_2298;
					       {
						  obj_t arg2951_2299;
						  {
						     obj_t arg2952_2300;
						     arg2952_2300 = MAKE_PAIR(BNIL, BNIL);
						     arg2951_2299 = MAKE_PAIR(arg2948_2296, arg2952_2300);
						  }
						  list2950_2298 = MAKE_PAIR(arg2947_2295, arg2951_2299);
					       }
					       arg2941_2289 = cons__138___r4_pairs_and_lists_6_3(arg2946_2294, list2950_2298);
					    }
					 }
					 {
					    bool_t test_5112;
					    if (STRUCTP(slot_185))
					      {
						 obj_t aux_5117;
						 obj_t aux_5115;
						 aux_5117 = CNST_TABLE_REF(((long) 48));
						 aux_5115 = STRUCT_KEY(slot_185);
						 test_5112 = (aux_5115 == aux_5117);
					      }
					    else
					      {
						 test_5112 = ((bool_t) 0);
					      }
					    if (test_5112)
					      {
						 arg2942_2290 = STRUCT_REF(slot_185, ((long) 14));
					      }
					    else
					      {
						 arg2942_2290 = slot_185;
					      }
					 }
					 {
					    obj_t list2943_2291;
					    {
					       obj_t arg2944_2292;
					       arg2944_2292 = MAKE_PAIR(src_def_101_187, BNIL);
					       list2943_2291 = MAKE_PAIR(arg2942_2290, arg2944_2292);
					    }
					    arg2938_2286 = epairify_object_access(arg2941_2289, list2943_2291);
					 }
				      }
				      {
					 obj_t list2939_2287;
					 list2939_2287 = MAKE_PAIR(arg2938_2286, BNIL);
					 return list2939_2287;
				      }
				   }
				}
			      else
				{
				   {
				      obj_t arg2971_2317;
				      {
					 obj_t arg2972_2318;
					 {
					    obj_t arg2977_2323;
					    arg2977_2323 = CNST_TABLE_REF(((long) 12));
					    {
					       obj_t list2979_2325;
					       {
						  obj_t arg2980_2326;
						  {
						     obj_t arg2981_2327;
						     {
							obj_t arg2982_2328;
							arg2982_2328 = MAKE_PAIR(BNIL, BNIL);
							arg2981_2327 = MAKE_PAIR(v_tid_138_2273, arg2982_2328);
						     }
						     arg2980_2326 = MAKE_PAIR(tid_2268, arg2981_2327);
						  }
						  list2979_2325 = MAKE_PAIR(slot_set__tid_15_2267, arg2980_2326);
					       }
					       arg2972_2318 = cons__138___r4_pairs_and_lists_6_3(arg2977_2323, list2979_2325);
					    }
					 }
					 {
					    obj_t list2974_2320;
					    {
					       obj_t arg2975_2321;
					       arg2975_2321 = MAKE_PAIR(BNIL, BNIL);
					       list2974_2320 = MAKE_PAIR(arg2972_2318, arg2975_2321);
					    }
					    arg2971_2317 = cons__138___r4_pairs_and_lists_6_3(import_188, list2974_2320);
					 }
				      }
				      produce_module_clause__172_module_module(arg2971_2317);
				   }
				   {
				      obj_t arg2984_2330;
				      {
					 obj_t arg2987_2333;
					 obj_t arg2989_2334;
					 {
					    obj_t arg2995_2338;
					    obj_t arg2997_2339;
					    obj_t arg2999_2340;
					    arg2995_2338 = CNST_TABLE_REF(((long) 15));
					    {
					       obj_t arg3005_2346;
					       {
						  obj_t list3011_2352;
						  {
						     obj_t arg3012_2353;
						     arg3012_2353 = MAKE_PAIR(tid_2268, BNIL);
						     list3011_2352 = MAKE_PAIR(obj_2272, arg3012_2353);
						  }
						  arg3005_2346 = symbol_append_197___r4_symbols_6_4(list3011_2352);
					       }
					       {
						  obj_t list3007_2348;
						  {
						     obj_t arg3008_2349;
						     {
							obj_t arg3009_2350;
							arg3009_2350 = MAKE_PAIR(BNIL, BNIL);
							arg3008_2349 = MAKE_PAIR(v_tid_138_2273, arg3009_2350);
						     }
						     list3007_2348 = MAKE_PAIR(arg3005_2346, arg3008_2349);
						  }
						  arg2997_2339 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2267, list3007_2348);
					       }
					    }
					    {
					       obj_t list3015_2356;
					       {
						  obj_t arg3016_2357;
						  {
						     obj_t arg3017_2358;
						     arg3017_2358 = MAKE_PAIR(BNIL, BNIL);
						     arg3016_2357 = MAKE_PAIR(v_id_210_2271, arg3017_2358);
						  }
						  list3015_2356 = MAKE_PAIR(obj_2272, arg3016_2357);
					       }
					       arg2999_2340 = cons__138___r4_pairs_and_lists_6_3(setter_2270, list3015_2356);
					    }
					    {
					       obj_t list3001_2342;
					       {
						  obj_t arg3002_2343;
						  {
						     obj_t arg3003_2344;
						     arg3003_2344 = MAKE_PAIR(BNIL, BNIL);
						     arg3002_2343 = MAKE_PAIR(arg2999_2340, arg3003_2344);
						  }
						  list3001_2342 = MAKE_PAIR(arg2997_2339, arg3002_2343);
					       }
					       arg2987_2333 = cons__138___r4_pairs_and_lists_6_3(arg2995_2338, list3001_2342);
					    }
					 }
					 {
					    bool_t test_5151;
					    if (STRUCTP(slot_185))
					      {
						 obj_t aux_5156;
						 obj_t aux_5154;
						 aux_5156 = CNST_TABLE_REF(((long) 48));
						 aux_5154 = STRUCT_KEY(slot_185);
						 test_5151 = (aux_5154 == aux_5156);
					      }
					    else
					      {
						 test_5151 = ((bool_t) 0);
					      }
					    if (test_5151)
					      {
						 arg2989_2334 = STRUCT_REF(slot_185, ((long) 14));
					      }
					    else
					      {
						 arg2989_2334 = slot_185;
					      }
					 }
					 {
					    obj_t list2990_2335;
					    {
					       obj_t arg2991_2336;
					       arg2991_2336 = MAKE_PAIR(src_def_101_187, BNIL);
					       list2990_2335 = MAKE_PAIR(arg2989_2334, arg2991_2336);
					    }
					    arg2984_2330 = epairify_object_access(arg2987_2333, list2990_2335);
					 }
				      }
				      {
					 obj_t list2985_2331;
					 list2985_2331 = MAKE_PAIR(arg2984_2330, BNIL);
					 return list2985_2331;
				      }
				   }
				}
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* slot-direct-set! */ obj_t 
slot_direct_set__173_object_access(obj_t class_id_86_189, obj_t type_190, obj_t slot_191, obj_t widening_192, obj_t src_def_101_193, obj_t import_194)
{
   {
      obj_t slot_set__id_195_2385;
      {
	 obj_t arg3142_2487;
	 obj_t arg3143_2488;
	 arg3142_2487 = CNST_TABLE_REF(((long) 18));
	 arg3143_2488 = STRUCT_REF(slot_191, ((long) 0));
	 {
	    obj_t list3145_2490;
	    {
	       obj_t arg3146_2491;
	       {
		  obj_t arg3147_2492;
		  {
		     obj_t arg3148_2493;
		     {
			obj_t aux_5166;
			aux_5166 = CNST_TABLE_REF(((long) 50));
			arg3148_2493 = MAKE_PAIR(aux_5166, BNIL);
		     }
		     arg3147_2492 = MAKE_PAIR(arg3143_2488, arg3148_2493);
		  }
		  arg3146_2491 = MAKE_PAIR(arg3142_2487, arg3147_2492);
	       }
	       list3145_2490 = MAKE_PAIR(class_id_86_189, arg3146_2491);
	    }
	    slot_set__id_195_2385 = symbol_append_197___r4_symbols_6_4(list3145_2490);
	 }
      }
      {
	 obj_t slot_set__tid_15_2386;
	 {
	    obj_t list3139_2484;
	    {
	       obj_t arg3140_2485;
	       {
		  obj_t aux_5173;
		  aux_5173 = CNST_TABLE_REF(((long) 13));
		  arg3140_2485 = MAKE_PAIR(aux_5173, BNIL);
	       }
	       list3139_2484 = MAKE_PAIR(slot_set__id_195_2385, arg3140_2485);
	    }
	    slot_set__tid_15_2386 = symbol_append_197___r4_symbols_6_4(list3139_2484);
	 }
	 {
	    obj_t tid_2387;
	    {
	       obj_t list3135_2480;
	       {
		  obj_t arg3136_2481;
		  {
		     obj_t aux_5178;
		     {
			type_t obj_3300;
			obj_3300 = (type_t) (type_190);
			aux_5178 = (((type_t) CREF(obj_3300))->id);
		     }
		     arg3136_2481 = MAKE_PAIR(aux_5178, BNIL);
		  }
		  list3135_2480 = MAKE_PAIR(_4dots_199_tools_misc, arg3136_2481);
	       }
	       tid_2387 = symbol_append_197___r4_symbols_6_4(list3135_2480);
	    }
	    {
	       obj_t v_id_210_2389;
	       v_id_210_2389 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 51)), BEOA);
	       {
		  obj_t v_tid_138_2390;
		  {
		     obj_t list3126_2473;
		     {
			obj_t arg3129_2474;
			{
			   obj_t arg3130_2475;
			   {
			      obj_t aux_5187;
			      {
				 type_t obj_3305;
				 {
				    obj_t aux_5188;
				    aux_5188 = STRUCT_REF(slot_191, ((long) 2));
				    obj_3305 = (type_t) (aux_5188);
				 }
				 aux_5187 = (((type_t) CREF(obj_3305))->id);
			      }
			      arg3130_2475 = MAKE_PAIR(aux_5187, BNIL);
			   }
			   arg3129_2474 = MAKE_PAIR(_4dots_199_tools_misc, arg3130_2475);
			}
			list3126_2473 = MAKE_PAIR(v_id_210_2389, arg3129_2474);
		     }
		     v_tid_138_2390 = symbol_append_197___r4_symbols_6_4(list3126_2473);
		  }
		  {
		     {
			bool_t test3044_2391;
			{
			   long n1_3306;
			   n1_3306 = (long) CINT(_optim__89_engine_param);
			   test3044_2391 = (n1_3306 < ((long) 2));
			}
			if (test3044_2391)
			  {
			     {
				obj_t arg3045_2392;
				{
				   obj_t arg3046_2393;
				   {
				      obj_t list3052_2399;
				      {
					 obj_t arg3053_2400;
					 {
					    obj_t arg3054_2401;
					    arg3054_2401 = MAKE_PAIR(BNIL, BNIL);
					    arg3053_2400 = MAKE_PAIR(v_tid_138_2390, arg3054_2401);
					 }
					 list3052_2399 = MAKE_PAIR(tid_2387, arg3053_2400);
				      }
				      arg3046_2393 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2386, list3052_2399);
				   }
				   {
				      obj_t list3048_2395;
				      {
					 obj_t arg3049_2396;
					 arg3049_2396 = MAKE_PAIR(BNIL, BNIL);
					 list3048_2395 = MAKE_PAIR(arg3046_2393, arg3049_2396);
				      }
				      arg3045_2392 = cons__138___r4_pairs_and_lists_6_3(import_194, list3048_2395);
				   }
				}
				produce_module_clause__172_module_module(arg3045_2392);
			     }
			     {
				obj_t arg3056_2403;
				{
				   obj_t arg3059_2406;
				   obj_t arg3060_2407;
				   {
				      obj_t arg3064_2411;
				      obj_t arg3065_2412;
				      obj_t arg3066_2413;
				      arg3064_2411 = CNST_TABLE_REF(((long) 25));
				      {
					 obj_t arg3072_2419;
					 {
					    obj_t arg3078_2425;
					    arg3078_2425 = CNST_TABLE_REF(((long) 2));
					    {
					       obj_t list3079_2426;
					       {
						  obj_t arg3080_2427;
						  arg3080_2427 = MAKE_PAIR(tid_2387, BNIL);
						  list3079_2426 = MAKE_PAIR(arg3078_2425, arg3080_2427);
					       }
					       arg3072_2419 = symbol_append_197___r4_symbols_6_4(list3079_2426);
					    }
					 }
					 {
					    obj_t list3074_2421;
					    {
					       obj_t arg3075_2422;
					       {
						  obj_t arg3076_2423;
						  arg3076_2423 = MAKE_PAIR(BNIL, BNIL);
						  arg3075_2422 = MAKE_PAIR(v_tid_138_2390, arg3076_2423);
					       }
					       list3074_2421 = MAKE_PAIR(arg3072_2419, arg3075_2422);
					    }
					    arg3065_2412 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2386, list3074_2421);
					 }
				      }
				      arg3066_2413 = make_pragma_direct_set__widening_17_object_tools((type_t) (type_190), slot_191, CNST_TABLE_REF(((long) 2)), v_id_210_2389, widening_192);
				      {
					 obj_t list3068_2415;
					 {
					    obj_t arg3069_2416;
					    {
					       obj_t arg3070_2417;
					       arg3070_2417 = MAKE_PAIR(BNIL, BNIL);
					       arg3069_2416 = MAKE_PAIR(arg3066_2413, arg3070_2417);
					    }
					    list3068_2415 = MAKE_PAIR(arg3065_2412, arg3069_2416);
					 }
					 arg3059_2406 = cons__138___r4_pairs_and_lists_6_3(arg3064_2411, list3068_2415);
				      }
				   }
				   {
				      bool_t test_5223;
				      if (STRUCTP(slot_191))
					{
					   obj_t aux_5228;
					   obj_t aux_5226;
					   aux_5228 = CNST_TABLE_REF(((long) 48));
					   aux_5226 = STRUCT_KEY(slot_191);
					   test_5223 = (aux_5226 == aux_5228);
					}
				      else
					{
					   test_5223 = ((bool_t) 0);
					}
				      if (test_5223)
					{
					   arg3060_2407 = STRUCT_REF(slot_191, ((long) 14));
					}
				      else
					{
					   arg3060_2407 = slot_191;
					}
				   }
				   {
				      obj_t list3061_2408;
				      {
					 obj_t arg3062_2409;
					 arg3062_2409 = MAKE_PAIR(src_def_101_193, BNIL);
					 list3061_2408 = MAKE_PAIR(arg3060_2407, arg3062_2409);
				      }
				      arg3056_2403 = epairify_object_access(arg3059_2406, list3061_2408);
				   }
				}
				{
				   obj_t list3057_2404;
				   list3057_2404 = MAKE_PAIR(arg3056_2403, BNIL);
				   return list3057_2404;
				}
			     }
			  }
			else
			  {
			     {
				obj_t arg3084_2431;
				{
				   obj_t arg3085_2432;
				   {
				      obj_t arg3090_2437;
				      arg3090_2437 = CNST_TABLE_REF(((long) 12));
				      {
					 obj_t list3092_2439;
					 {
					    obj_t arg3093_2440;
					    {
					       obj_t arg3094_2441;
					       {
						  obj_t arg3095_2442;
						  arg3095_2442 = MAKE_PAIR(BNIL, BNIL);
						  arg3094_2441 = MAKE_PAIR(v_tid_138_2390, arg3095_2442);
					       }
					       arg3093_2440 = MAKE_PAIR(tid_2387, arg3094_2441);
					    }
					    list3092_2439 = MAKE_PAIR(slot_set__tid_15_2386, arg3093_2440);
					 }
					 arg3085_2432 = cons__138___r4_pairs_and_lists_6_3(arg3090_2437, list3092_2439);
				      }
				   }
				   {
				      obj_t list3087_2434;
				      {
					 obj_t arg3088_2435;
					 arg3088_2435 = MAKE_PAIR(BNIL, BNIL);
					 list3087_2434 = MAKE_PAIR(arg3085_2432, arg3088_2435);
				      }
				      arg3084_2431 = cons__138___r4_pairs_and_lists_6_3(import_194, list3087_2434);
				   }
				}
				produce_module_clause__172_module_module(arg3084_2431);
			     }
			     {
				obj_t arg3097_2444;
				{
				   obj_t arg3100_2447;
				   obj_t arg3101_2448;
				   {
				      obj_t arg3105_2452;
				      obj_t arg3106_2453;
				      obj_t arg3107_2454;
				      arg3105_2452 = CNST_TABLE_REF(((long) 15));
				      {
					 obj_t arg3113_2460;
					 {
					    obj_t arg3119_2466;
					    arg3119_2466 = CNST_TABLE_REF(((long) 2));
					    {
					       obj_t list3120_2467;
					       {
						  obj_t arg3121_2468;
						  arg3121_2468 = MAKE_PAIR(tid_2387, BNIL);
						  list3120_2467 = MAKE_PAIR(arg3119_2466, arg3121_2468);
					       }
					       arg3113_2460 = symbol_append_197___r4_symbols_6_4(list3120_2467);
					    }
					 }
					 {
					    obj_t list3115_2462;
					    {
					       obj_t arg3116_2463;
					       {
						  obj_t arg3117_2464;
						  arg3117_2464 = MAKE_PAIR(BNIL, BNIL);
						  arg3116_2463 = MAKE_PAIR(v_tid_138_2390, arg3117_2464);
					       }
					       list3115_2462 = MAKE_PAIR(arg3113_2460, arg3116_2463);
					    }
					    arg3106_2453 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2386, list3115_2462);
					 }
				      }
				      arg3107_2454 = make_pragma_direct_set__widening_17_object_tools((type_t) (type_190), slot_191, CNST_TABLE_REF(((long) 2)), v_id_210_2389, widening_192);
				      {
					 obj_t list3109_2456;
					 {
					    obj_t arg3110_2457;
					    {
					       obj_t arg3111_2458;
					       arg3111_2458 = MAKE_PAIR(BNIL, BNIL);
					       arg3110_2457 = MAKE_PAIR(arg3107_2454, arg3111_2458);
					    }
					    list3109_2456 = MAKE_PAIR(arg3106_2453, arg3110_2457);
					 }
					 arg3100_2447 = cons__138___r4_pairs_and_lists_6_3(arg3105_2452, list3109_2456);
				      }
				   }
				   {
				      bool_t test_5262;
				      if (STRUCTP(slot_191))
					{
					   obj_t aux_5267;
					   obj_t aux_5265;
					   aux_5267 = CNST_TABLE_REF(((long) 48));
					   aux_5265 = STRUCT_KEY(slot_191);
					   test_5262 = (aux_5265 == aux_5267);
					}
				      else
					{
					   test_5262 = ((bool_t) 0);
					}
				      if (test_5262)
					{
					   arg3101_2448 = STRUCT_REF(slot_191, ((long) 14));
					}
				      else
					{
					   arg3101_2448 = slot_191;
					}
				   }
				   {
				      obj_t list3102_2449;
				      {
					 obj_t arg3103_2450;
					 arg3103_2450 = MAKE_PAIR(src_def_101_193, BNIL);
					 list3102_2449 = MAKE_PAIR(arg3101_2448, arg3103_2450);
				      }
				      arg3097_2444 = epairify_object_access(arg3100_2447, list3102_2449);
				   }
				}
				{
				   obj_t list3098_2445;
				   list3098_2445 = MAKE_PAIR(arg3097_2444, BNIL);
				   return list3098_2445;
				}
			     }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* import-class-slots-access! */ obj_t 
import_class_slots_access__39_object_access(obj_t class_id_86_195, obj_t type_196, obj_t slots_197, obj_t src_def_101_198, obj_t module_199)
{
   {
      obj_t l1228_2495;
      {
	 bool_t aux_5275;
	 l1228_2495 = slots_197;
       lname1229_2496:
	 if (PAIRP(l1228_2495))
	   {
	      {
		 obj_t slot_2498;
		 slot_2498 = CAR(l1228_2495);
		 import_slot_ref__77_object_access(class_id_86_195, type_196, slot_2498, src_def_101_198, module_199);
		 {
		    bool_t test_5280;
		    {
		       obj_t aux_5281;
		       aux_5281 = STRUCT_REF(slot_2498, ((long) 7));
		       test_5280 = CBOOL(aux_5281);
		    }
		    if (test_5280)
		      {
			 BUNSPEC;
		      }
		    else
		      {
			 import_slot_set__215_object_access(class_id_86_195, type_196, slot_2498, src_def_101_198, module_199);
		      }
		 }
	      }
	      {
		 obj_t l1228_5285;
		 l1228_5285 = CDR(l1228_2495);
		 l1228_2495 = l1228_5285;
		 goto lname1229_2496;
	      }
	   }
	 else
	   {
	      aux_5275 = ((bool_t) 1);
	   }
	 return BBOOL(aux_5275);
      }
   }
}


/* _import-class-slots-access!3355 */ obj_t 
_import_class_slots_access_3355_104_object_access(obj_t env_3532, obj_t class_id_86_3533, obj_t type_3534, obj_t slots_3535, obj_t src_def_101_3536, obj_t module_3537)
{
   return import_class_slots_access__39_object_access(class_id_86_3533, type_3534, slots_3535, src_def_101_3536, module_3537);
}


/* import-slot-ref! */ obj_t 
import_slot_ref__77_object_access(obj_t class_id_86_200, obj_t type_201, obj_t slot_202, obj_t src_def_101_203, obj_t module_204)
{
   {
      bool_t test_5289;
      {
	 obj_t aux_5290;
	 aux_5290 = STRUCT_REF(slot_202, ((long) 5));
	 test_5289 = CBOOL(aux_5290);
      }
      if (test_5289)
	{
	   return import_slot_dyna_indexed_ref__108_object_access(class_id_86_200, type_201, slot_202, src_def_101_203, module_204);
	}
      else
	{
	   bool_t test_5294;
	   {
	      obj_t aux_5295;
	      aux_5295 = STRUCT_REF(slot_202, ((long) 3));
	      test_5294 = CBOOL(aux_5295);
	   }
	   if (test_5294)
	     {
		{
		   obj_t arg3170_3349;
		   {
		      obj_t arg3171_3350;
		      obj_t arg3172_3351;
		      arg3171_3350 = CNST_TABLE_REF(((long) 40));
		      arg3172_3351 = STRUCT_REF(slot_202, ((long) 4));
		      {
			 obj_t list3174_3353;
			 {
			    obj_t arg3175_3354;
			    arg3175_3354 = MAKE_PAIR(BNIL, BNIL);
			    list3174_3353 = MAKE_PAIR(arg3172_3351, arg3175_3354);
			 }
			 arg3170_3349 = cons__138___r4_pairs_and_lists_6_3(arg3171_3350, list3174_3353);
		      }
		   }
		   return import_slot_indexed_ref__208_object_access(class_id_86_200, type_201, slot_202, arg3170_3349, src_def_101_203, module_204);
		}
	     }
	   else
	     {
		return import_slot_direct_ref__71_object_access(class_id_86_200, type_201, slot_202, src_def_101_203, module_204);
	     }
	}
   }
}


/* import-slot-dyna-indexed-ref! */ obj_t 
import_slot_dyna_indexed_ref__108_object_access(obj_t class_id_86_205, obj_t type_206, obj_t slot_207, obj_t src_def_101_208, obj_t module_209)
{
   {
      obj_t arg3155_2503;
      {
	 obj_t arg3156_2504;
	 obj_t arg3157_2505;
	 {
	    obj_t arg3162_2510;
	    obj_t arg3163_2511;
	    arg3162_2510 = CNST_TABLE_REF(((long) 18));
	    arg3163_2511 = STRUCT_REF(slot_207, ((long) 0));
	    {
	       obj_t list3165_2513;
	       {
		  obj_t arg3166_2514;
		  {
		     obj_t arg3167_2515;
		     {
			obj_t arg3168_2516;
			{
			   obj_t aux_5307;
			   aux_5307 = CNST_TABLE_REF(((long) 33));
			   arg3168_2516 = MAKE_PAIR(aux_5307, BNIL);
			}
			arg3167_2515 = MAKE_PAIR(arg3163_2511, arg3168_2516);
		     }
		     arg3166_2514 = MAKE_PAIR(arg3162_2510, arg3167_2515);
		  }
		  list3165_2513 = MAKE_PAIR(class_id_86_205, arg3166_2514);
	       }
	       arg3156_2504 = symbol_append_197___r4_symbols_6_4(list3165_2513);
	    }
	 }
	 arg3157_2505 = CNST_TABLE_REF(((long) 2));
	 {
	    obj_t list3159_2507;
	    {
	       obj_t arg3160_2508;
	       arg3160_2508 = MAKE_PAIR(BNIL, BNIL);
	       list3159_2507 = MAKE_PAIR(arg3157_2505, arg3160_2508);
	    }
	    arg3155_2503 = cons__138___r4_pairs_and_lists_6_3(arg3156_2504, list3159_2507);
	 }
      }
      return import_slot_indexed_ref__208_object_access(class_id_86_205, type_206, slot_207, arg3155_2503, src_def_101_208, module_209);
   }
}


/* import-slot-indexed-ref! */ obj_t 
import_slot_indexed_ref__208_object_access(obj_t class_id_86_215, obj_t type_216, obj_t slot_217, obj_t max_bound_128_218, obj_t src_def_101_219, obj_t module_220)
{
   {
      obj_t slot_ref_id_128_2525;
      {
	 obj_t arg3194_2546;
	 obj_t arg3195_2547;
	 arg3194_2546 = CNST_TABLE_REF(((long) 18));
	 arg3195_2547 = STRUCT_REF(slot_217, ((long) 0));
	 {
	    obj_t list3197_2549;
	    {
	       obj_t arg3198_2550;
	       {
		  obj_t arg3199_2551;
		  {
		     obj_t arg3200_2552;
		     {
			obj_t aux_5321;
			aux_5321 = CNST_TABLE_REF(((long) 49));
			arg3200_2552 = MAKE_PAIR(aux_5321, BNIL);
		     }
		     arg3199_2551 = MAKE_PAIR(arg3195_2547, arg3200_2552);
		  }
		  arg3198_2550 = MAKE_PAIR(arg3194_2546, arg3199_2551);
	       }
	       list3197_2549 = MAKE_PAIR(class_id_86_215, arg3198_2550);
	    }
	    slot_ref_id_128_2525 = symbol_append_197___r4_symbols_6_4(list3197_2549);
	 }
      }
      {
	 obj_t slot_ref_tid_43_2526;
	 {
	    obj_t list3189_2541;
	    {
	       obj_t arg3190_2542;
	       {
		  obj_t arg3191_2543;
		  {
		     obj_t aux_5328;
		     {
			type_t obj_3378;
			{
			   obj_t aux_5329;
			   aux_5329 = STRUCT_REF(slot_217, ((long) 2));
			   obj_3378 = (type_t) (aux_5329);
			}
			aux_5328 = (((type_t) CREF(obj_3378))->id);
		     }
		     arg3191_2543 = MAKE_PAIR(aux_5328, BNIL);
		  }
		  arg3190_2542 = MAKE_PAIR(_4dots_199_tools_misc, arg3191_2543);
	       }
	       list3189_2541 = MAKE_PAIR(slot_ref_id_128_2525, arg3190_2542);
	    }
	    slot_ref_tid_43_2526 = symbol_append_197___r4_symbols_6_4(list3189_2541);
	 }
	 {
	    obj_t tid_2527;
	    {
	       obj_t list3185_2537;
	       {
		  obj_t arg3186_2538;
		  {
		     obj_t aux_5337;
		     {
			type_t obj_3379;
			obj_3379 = (type_t) (type_216);
			aux_5337 = (((type_t) CREF(obj_3379))->id);
		     }
		     arg3186_2538 = MAKE_PAIR(aux_5337, BNIL);
		  }
		  list3185_2537 = MAKE_PAIR(_4dots_199_tools_misc, arg3186_2538);
	       }
	       tid_2527 = symbol_append_197___r4_symbols_6_4(list3185_2537);
	    }
	    {
	       {
		  obj_t arg3177_2529;
		  {
		     obj_t arg3178_2530;
		     arg3178_2530 = CNST_TABLE_REF(((long) 23));
		     {
			obj_t list3180_2532;
			{
			   obj_t arg3181_2533;
			   {
			      obj_t arg3182_2534;
			      arg3182_2534 = MAKE_PAIR(BNIL, BNIL);
			      arg3181_2533 = MAKE_PAIR(arg3178_2530, arg3182_2534);
			   }
			   list3180_2532 = MAKE_PAIR(tid_2527, arg3181_2533);
			}
			arg3177_2529 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_2526, list3180_2532);
		     }
		  }
		  return import_parser_53_module_impuse(module_220, arg3177_2529);
	       }
	    }
	 }
      }
   }
}


/* import-slot-direct-ref! */ obj_t 
import_slot_direct_ref__71_object_access(obj_t class_id_86_221, obj_t type_222, obj_t slot_223, obj_t src_def_101_224, obj_t module_225)
{
   {
      obj_t slot_ref_id_128_2554;
      {
	 obj_t arg3217_2572;
	 arg3217_2572 = CNST_TABLE_REF(((long) 18));
	 {
	    obj_t list3219_2574;
	    {
	       obj_t arg3220_2575;
	       {
		  obj_t arg3221_2576;
		  {
		     obj_t aux_5350;
		     aux_5350 = STRUCT_REF(slot_223, ((long) 0));
		     arg3221_2576 = MAKE_PAIR(aux_5350, BNIL);
		  }
		  arg3220_2575 = MAKE_PAIR(arg3217_2572, arg3221_2576);
	       }
	       list3219_2574 = MAKE_PAIR(class_id_86_221, arg3220_2575);
	    }
	    slot_ref_id_128_2554 = symbol_append_197___r4_symbols_6_4(list3219_2574);
	 }
      }
      {
	 obj_t slot_ref_tid_43_2555;
	 {
	    obj_t list3212_2567;
	    {
	       obj_t arg3213_2568;
	       {
		  obj_t arg3214_2569;
		  {
		     obj_t aux_5356;
		     {
			type_t obj_3387;
			{
			   obj_t aux_5357;
			   aux_5357 = STRUCT_REF(slot_223, ((long) 2));
			   obj_3387 = (type_t) (aux_5357);
			}
			aux_5356 = (((type_t) CREF(obj_3387))->id);
		     }
		     arg3214_2569 = MAKE_PAIR(aux_5356, BNIL);
		  }
		  arg3213_2568 = MAKE_PAIR(_4dots_199_tools_misc, arg3214_2569);
	       }
	       list3212_2567 = MAKE_PAIR(slot_ref_id_128_2554, arg3213_2568);
	    }
	    slot_ref_tid_43_2555 = symbol_append_197___r4_symbols_6_4(list3212_2567);
	 }
	 {
	    obj_t tid_2556;
	    {
	       obj_t list3208_2563;
	       {
		  obj_t arg3209_2564;
		  {
		     obj_t aux_5365;
		     {
			type_t obj_3388;
			obj_3388 = (type_t) (type_222);
			aux_5365 = (((type_t) CREF(obj_3388))->id);
		     }
		     arg3209_2564 = MAKE_PAIR(aux_5365, BNIL);
		  }
		  list3208_2563 = MAKE_PAIR(_4dots_199_tools_misc, arg3209_2564);
	       }
	       tid_2556 = symbol_append_197___r4_symbols_6_4(list3208_2563);
	    }
	    {
	       {
		  obj_t arg3202_2557;
		  {
		     obj_t list3204_2559;
		     {
			obj_t arg3205_2560;
			arg3205_2560 = MAKE_PAIR(BNIL, BNIL);
			list3204_2559 = MAKE_PAIR(tid_2556, arg3205_2560);
		     }
		     arg3202_2557 = cons__138___r4_pairs_and_lists_6_3(slot_ref_tid_43_2555, list3204_2559);
		  }
		  return import_parser_53_module_impuse(module_225, arg3202_2557);
	       }
	    }
	 }
      }
   }
}


/* import-slot-set! */ obj_t 
import_slot_set__215_object_access(obj_t class_id_86_226, obj_t type_227, obj_t slot_228, obj_t src_def_101_229, obj_t module_230)
{
   {
      bool_t test_5375;
      {
	 obj_t aux_5376;
	 aux_5376 = STRUCT_REF(slot_228, ((long) 5));
	 test_5375 = CBOOL(aux_5376);
      }
      if (test_5375)
	{
	   return import_slot_dyna_indexed_set__203_object_access(class_id_86_226, type_227, slot_228, src_def_101_229, module_230);
	}
      else
	{
	   bool_t test_5380;
	   {
	      obj_t aux_5381;
	      aux_5381 = STRUCT_REF(slot_228, ((long) 3));
	      test_5380 = CBOOL(aux_5381);
	   }
	   if (test_5380)
	     {
		{
		   obj_t arg3241_3400;
		   {
		      obj_t arg3242_3401;
		      obj_t arg3243_3402;
		      arg3242_3401 = CNST_TABLE_REF(((long) 40));
		      arg3243_3402 = STRUCT_REF(slot_228, ((long) 4));
		      {
			 obj_t list3245_3404;
			 {
			    obj_t arg3246_3405;
			    arg3246_3405 = MAKE_PAIR(BNIL, BNIL);
			    list3245_3404 = MAKE_PAIR(arg3243_3402, arg3246_3405);
			 }
			 arg3241_3400 = cons__138___r4_pairs_and_lists_6_3(arg3242_3401, list3245_3404);
		      }
		   }
		   return import_slot_indexed_set__155_object_access(class_id_86_226, type_227, slot_228, arg3241_3400, src_def_101_229, module_230);
		}
	     }
	   else
	     {
		return import_slot_direct_set__76_object_access(class_id_86_226, type_227, slot_228, src_def_101_229, module_230);
	     }
	}
   }
}


/* import-slot-dyna-indexed-set! */ obj_t 
import_slot_dyna_indexed_set__203_object_access(obj_t class_id_86_231, obj_t type_232, obj_t slot_233, obj_t src_def_101_234, obj_t module_235)
{
   {
      obj_t arg3225_2580;
      {
	 obj_t arg3226_2581;
	 obj_t arg3227_2582;
	 {
	    obj_t arg3232_2587;
	    obj_t arg3233_2588;
	    arg3232_2587 = CNST_TABLE_REF(((long) 18));
	    arg3233_2588 = STRUCT_REF(slot_233, ((long) 0));
	    {
	       obj_t list3236_2590;
	       {
		  obj_t arg3237_2591;
		  {
		     obj_t arg3238_2592;
		     {
			obj_t arg3239_2593;
			{
			   obj_t aux_5393;
			   aux_5393 = CNST_TABLE_REF(((long) 33));
			   arg3239_2593 = MAKE_PAIR(aux_5393, BNIL);
			}
			arg3238_2592 = MAKE_PAIR(arg3233_2588, arg3239_2593);
		     }
		     arg3237_2591 = MAKE_PAIR(arg3232_2587, arg3238_2592);
		  }
		  list3236_2590 = MAKE_PAIR(class_id_86_231, arg3237_2591);
	       }
	       arg3226_2581 = symbol_append_197___r4_symbols_6_4(list3236_2590);
	    }
	 }
	 arg3227_2582 = CNST_TABLE_REF(((long) 2));
	 {
	    obj_t list3229_2584;
	    {
	       obj_t arg3230_2585;
	       arg3230_2585 = MAKE_PAIR(BNIL, BNIL);
	       list3229_2584 = MAKE_PAIR(arg3227_2582, arg3230_2585);
	    }
	    arg3225_2580 = cons__138___r4_pairs_and_lists_6_3(arg3226_2581, list3229_2584);
	 }
      }
      return import_slot_indexed_set__155_object_access(class_id_86_231, type_232, slot_233, arg3225_2580, src_def_101_234, module_235);
   }
}


/* import-slot-indexed-set! */ obj_t 
import_slot_indexed_set__155_object_access(obj_t class_id_86_241, obj_t type_242, obj_t slot_243, obj_t max_bound_128_244, obj_t src_def_101_245, obj_t module_246)
{
   {
      obj_t slot_set__id_195_2602;
      {
	 obj_t arg3273_2630;
	 obj_t arg3274_2631;
	 arg3273_2630 = CNST_TABLE_REF(((long) 18));
	 arg3274_2631 = STRUCT_REF(slot_243, ((long) 0));
	 {
	    obj_t list3276_2633;
	    {
	       obj_t arg3277_2634;
	       {
		  obj_t arg3278_2635;
		  {
		     obj_t arg3279_2636;
		     {
			obj_t aux_5407;
			aux_5407 = CNST_TABLE_REF(((long) 50));
			arg3279_2636 = MAKE_PAIR(aux_5407, BNIL);
		     }
		     arg3278_2635 = MAKE_PAIR(arg3274_2631, arg3279_2636);
		  }
		  arg3277_2634 = MAKE_PAIR(arg3273_2630, arg3278_2635);
	       }
	       list3276_2633 = MAKE_PAIR(class_id_86_241, arg3277_2634);
	    }
	    slot_set__id_195_2602 = symbol_append_197___r4_symbols_6_4(list3276_2633);
	 }
      }
      {
	 obj_t slot_set__tid_15_2603;
	 {
	    obj_t list3270_2627;
	    {
	       obj_t arg3271_2628;
	       {
		  obj_t aux_5414;
		  aux_5414 = CNST_TABLE_REF(((long) 13));
		  arg3271_2628 = MAKE_PAIR(aux_5414, BNIL);
	       }
	       list3270_2627 = MAKE_PAIR(slot_set__id_195_2602, arg3271_2628);
	    }
	    slot_set__tid_15_2603 = symbol_append_197___r4_symbols_6_4(list3270_2627);
	 }
	 {
	    obj_t tid_2604;
	    {
	       obj_t list3266_2623;
	       {
		  obj_t arg3267_2624;
		  {
		     obj_t aux_5419;
		     {
			type_t obj_3426;
			obj_3426 = (type_t) (type_242);
			aux_5419 = (((type_t) CREF(obj_3426))->id);
		     }
		     arg3267_2624 = MAKE_PAIR(aux_5419, BNIL);
		  }
		  list3266_2623 = MAKE_PAIR(_4dots_199_tools_misc, arg3267_2624);
	       }
	       tid_2604 = symbol_append_197___r4_symbols_6_4(list3266_2623);
	    }
	    {
	       obj_t v_id_210_2605;
	       v_id_210_2605 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 51)), BEOA);
	       {
		  obj_t v_tid_138_2606;
		  {
		     obj_t list3257_2616;
		     {
			obj_t arg3259_2617;
			{
			   obj_t arg3261_2618;
			   {
			      obj_t aux_5428;
			      {
				 type_t obj_3430;
				 {
				    obj_t aux_5429;
				    aux_5429 = STRUCT_REF(slot_243, ((long) 2));
				    obj_3430 = (type_t) (aux_5429);
				 }
				 aux_5428 = (((type_t) CREF(obj_3430))->id);
			      }
			      arg3261_2618 = MAKE_PAIR(aux_5428, BNIL);
			   }
			   arg3259_2617 = MAKE_PAIR(_4dots_199_tools_misc, arg3261_2618);
			}
			list3257_2616 = MAKE_PAIR(v_id_210_2605, arg3259_2617);
		     }
		     v_tid_138_2606 = symbol_append_197___r4_symbols_6_4(list3257_2616);
		  }
		  {
		     {
			obj_t arg3248_2607;
			{
			   obj_t arg3249_2608;
			   arg3249_2608 = CNST_TABLE_REF(((long) 23));
			   {
			      obj_t list3251_2610;
			      {
				 obj_t arg3252_2611;
				 {
				    obj_t arg3253_2612;
				    {
				       obj_t arg3254_2613;
				       arg3254_2613 = MAKE_PAIR(BNIL, BNIL);
				       arg3253_2612 = MAKE_PAIR(v_tid_138_2606, arg3254_2613);
				    }
				    arg3252_2611 = MAKE_PAIR(arg3249_2608, arg3253_2612);
				 }
				 list3251_2610 = MAKE_PAIR(tid_2604, arg3252_2611);
			      }
			      arg3248_2607 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2603, list3251_2610);
			   }
			}
			return import_parser_53_module_impuse(module_246, arg3248_2607);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* import-slot-direct-set! */ obj_t 
import_slot_direct_set__76_object_access(obj_t class_id_86_247, obj_t type_248, obj_t slot_249, obj_t src_def_101_250, obj_t module_251)
{
   {
      obj_t slot_set__id_195_2638;
      {
	 obj_t arg3302_2664;
	 obj_t arg3303_2665;
	 arg3302_2664 = CNST_TABLE_REF(((long) 18));
	 arg3303_2665 = STRUCT_REF(slot_249, ((long) 0));
	 {
	    obj_t list3305_2667;
	    {
	       obj_t arg3306_2668;
	       {
		  obj_t arg3307_2669;
		  {
		     obj_t arg3308_2670;
		     {
			obj_t aux_5446;
			aux_5446 = CNST_TABLE_REF(((long) 50));
			arg3308_2670 = MAKE_PAIR(aux_5446, BNIL);
		     }
		     arg3307_2669 = MAKE_PAIR(arg3303_2665, arg3308_2670);
		  }
		  arg3306_2668 = MAKE_PAIR(arg3302_2664, arg3307_2669);
	       }
	       list3305_2667 = MAKE_PAIR(class_id_86_247, arg3306_2668);
	    }
	    slot_set__id_195_2638 = symbol_append_197___r4_symbols_6_4(list3305_2667);
	 }
      }
      {
	 obj_t slot_set__tid_15_2639;
	 {
	    obj_t list3299_2661;
	    {
	       obj_t arg3300_2662;
	       {
		  obj_t aux_5453;
		  aux_5453 = CNST_TABLE_REF(((long) 13));
		  arg3300_2662 = MAKE_PAIR(aux_5453, BNIL);
	       }
	       list3299_2661 = MAKE_PAIR(slot_set__id_195_2638, arg3300_2662);
	    }
	    slot_set__tid_15_2639 = symbol_append_197___r4_symbols_6_4(list3299_2661);
	 }
	 {
	    obj_t tid_2640;
	    {
	       obj_t list3295_2657;
	       {
		  obj_t arg3296_2658;
		  {
		     obj_t aux_5458;
		     {
			type_t obj_3434;
			obj_3434 = (type_t) (type_248);
			aux_5458 = (((type_t) CREF(obj_3434))->id);
		     }
		     arg3296_2658 = MAKE_PAIR(aux_5458, BNIL);
		  }
		  list3295_2657 = MAKE_PAIR(_4dots_199_tools_misc, arg3296_2658);
	       }
	       tid_2640 = symbol_append_197___r4_symbols_6_4(list3295_2657);
	    }
	    {
	       obj_t v_id_210_2641;
	       v_id_210_2641 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 51)), BEOA);
	       {
		  obj_t v_tid_138_2642;
		  {
		     obj_t list3288_2650;
		     {
			obj_t arg3289_2651;
			{
			   obj_t arg3290_2652;
			   {
			      obj_t aux_5467;
			      {
				 type_t obj_3438;
				 {
				    obj_t aux_5468;
				    aux_5468 = STRUCT_REF(slot_249, ((long) 2));
				    obj_3438 = (type_t) (aux_5468);
				 }
				 aux_5467 = (((type_t) CREF(obj_3438))->id);
			      }
			      arg3290_2652 = MAKE_PAIR(aux_5467, BNIL);
			   }
			   arg3289_2651 = MAKE_PAIR(_4dots_199_tools_misc, arg3290_2652);
			}
			list3288_2650 = MAKE_PAIR(v_id_210_2641, arg3289_2651);
		     }
		     v_tid_138_2642 = symbol_append_197___r4_symbols_6_4(list3288_2650);
		  }
		  {
		     {
			obj_t arg3281_2643;
			{
			   obj_t list3283_2645;
			   {
			      obj_t arg3284_2646;
			      {
				 obj_t arg3285_2647;
				 arg3285_2647 = MAKE_PAIR(BNIL, BNIL);
				 arg3284_2646 = MAKE_PAIR(v_tid_138_2642, arg3285_2647);
			      }
			      list3283_2645 = MAKE_PAIR(tid_2640, arg3284_2646);
			   }
			   arg3281_2643 = cons__138___r4_pairs_and_lists_6_3(slot_set__tid_15_2639, list3283_2645);
			}
			return import_parser_53_module_impuse(module_251, arg3281_2643);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* epairify */ obj_t 
epairify_object_access(obj_t def_252, obj_t srcs_253)
{
   {
      obj_t srcs_2672;
      srcs_2672 = srcs_253;
    loop_2673:
      if (NULLP(srcs_2672))
	{
	   return def_252;
	}
      else
	{
	   bool_t test3311_2675;
	   {
	      obj_t aux_5483;
	      aux_5483 = CAR(srcs_2672);
	      test3311_2675 = EXTENDED_PAIRP(aux_5483);
	   }
	   if (test3311_2675)
	     {
		{
		   obj_t arg3312_2676;
		   obj_t arg3313_2677;
		   obj_t arg3314_2678;
		   arg3312_2676 = CAR(def_252);
		   arg3313_2677 = CDR(def_252);
		   {
		      obj_t arg3315_2679;
		      arg3315_2679 = CAR(srcs_2672);
		      {
			 bool_t test1137_3446;
			 test1137_3446 = EXTENDED_PAIRP(arg3315_2679);
			 if (test1137_3446)
			   {
			      arg3314_2678 = CER(arg3315_2679);
			   }
			 else
			   {
			      FAILURE(string3360_object_access, string3361_object_access, arg3315_2679);
			   }
		      }
		   }
		   return MAKE_EXTENDED_PAIR(arg3312_2676, arg3313_2677, arg3314_2678);
		}
	     }
	   else
	     {
		{
		   obj_t srcs_5495;
		   srcs_5495 = CDR(srcs_2672);
		   srcs_2672 = srcs_5495;
		   goto loop_2673;
		}
	     }
	}
   }
}


/* _epairify */ obj_t 
_epairify_object_access(obj_t env_3538, obj_t def_3539, obj_t srcs_3540)
{
   return epairify_object_access(def_3539, srcs_3540);
}


/* method-init */ obj_t 
method_init_76_object_access()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_access()
{
   module_initialization_70_tools_trace(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_tools_error(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_tools_misc(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_type_type(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_type_env(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_type_tools(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_type_cache(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_ast_var(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_ast_ident(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_object_class(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_object_struct(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_object_slots(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_object_tools(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_module_module(((long) 0), "OBJECT_ACCESS");
   module_initialization_70_module_impuse(((long) 0), "OBJECT_ACCESS");
   return module_initialization_70_engine_param(((long) 0), "OBJECT_ACCESS");
}
