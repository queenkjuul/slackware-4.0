/*===========================================================================*/
/*   (Eval/evcompile.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t interaction_environment_31___eval();
extern obj_t string_to_symbol(char *);
static obj_t evcompile_application_224___evcompile(obj_t, obj_t, obj_t, obj_t);
static obj_t evcompile_compiled_application_76___evcompile(obj_t, obj_t, obj_t);
extern obj_t dsssl_formals__scheme_formals_201___dsssl(obj_t, obj_t);
extern obj_t expand___expand(obj_t);
extern obj_t create_vector(long);
static obj_t evcompile_global_application_156___evcompile(obj_t, obj_t, obj_t);
static obj_t evcompile_cnst_159___evcompile(obj_t, obj_t);
static obj_t evcompile_lambda_39___evcompile(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _find_loc_196___evcompile(obj_t, obj_t, obj_t);
static obj_t evcompile_set_124___evcompile(obj_t, obj_t, obj_t);
extern obj_t module_declaration__32___eval(obj_t);
static obj_t evcompile_ref_190___evcompile(obj_t, obj_t);
static obj_t variable___evcompile(obj_t, obj_t, obj_t, obj_t);
static obj_t loop___evcompile(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t find_loc_64___evcompile(obj_t, obj_t);
extern obj_t eval_lookup_172___evenv(obj_t);
extern obj_t make_promise_21___r4_control_features_6_9(obj_t);
static obj_t arg1423___evcompile(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1421___evcompile(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1373___evcompile(obj_t);
extern obj_t module_initialization_70___evcompile(long, char *);
extern obj_t module_initialization_70___expand(long, char *);
extern obj_t module_initialization_70___type(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___dsssl(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___evenv(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
static obj_t evcompile_begin_220___evcompile(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _evcompile___evcompile(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern long list_length(obj_t);
extern obj_t list__vector_101___r4_vectors_6_8(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _loop____evcompile(obj_t, obj_t);
static obj_t symbol1998___evcompile = BUNSPEC;
static obj_t symbol1997___evcompile = BUNSPEC;
static obj_t symbol1996___evcompile = BUNSPEC;
static obj_t symbol1995___evcompile = BUNSPEC;
static obj_t symbol1994___evcompile = BUNSPEC;
static obj_t symbol1993___evcompile = BUNSPEC;
static obj_t symbol1992___evcompile = BUNSPEC;
static obj_t symbol1991___evcompile = BUNSPEC;
static obj_t symbol1989___evcompile = BUNSPEC;
static obj_t symbol1990___evcompile = BUNSPEC;
static obj_t symbol1987___evcompile = BUNSPEC;
static obj_t symbol1985___evcompile = BUNSPEC;
static obj_t symbol2001___evcompile = BUNSPEC;
static obj_t imported_modules_init_94___evcompile();
extern obj_t make_dsssl_function_prelude_58___dsssl(obj_t, obj_t, obj_t, obj_t);
extern obj_t scheme_report_environment_154___eval(obj_t);
static obj_t require_initialization_114___evcompile = BUNSPEC;
extern obj_t evcompile___evcompile(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t evcompile_error_92___evcompile(obj_t, obj_t, obj_t, obj_t);
extern obj_t null_environment_221___eval(obj_t);
static obj_t cnst_init_137___evcompile();
static obj_t *__cnst;

DEFINE_STRING( string1999___evcompile, string1999___evcompile2003, "Unbound variable", 16 );
DEFINE_STRING( string1988___evcompile, string1988___evcompile2004, "Not a procedure", 15 );
DEFINE_STRING( string1986___evcompile, string1986___evcompile2005, "Illegal define form (sealed environment)", 40 );
DEFINE_STRING( string1984___evcompile, string1984___evcompile2006, "Illegal expression (should be quoted)", 37 );
DEFINE_STRING( string1983___evcompile, string1983___evcompile2007, "Illegal expression", 18 );
DEFINE_STRING( string1982___evcompile, string1982___evcompile2008, "eval", 4 );
DEFINE_STRING( string1981___evcompile, string1981___evcompile2009, "Type `extended pair' expected for expression", 44 );
DEFINE_STRING( string1980___evcompile, string1980___evcompile2010, "cer", 3 );
DEFINE_STRING( string2000___evcompile, string2000___evcompile2011, "Illegal `set!' expression", 25 );
DEFINE_EXPORT_PROCEDURE( evcompile_env_4___evcompile, _evcompile___evcompile2012, _evcompile___evcompile, 0L, 6 );
DEFINE_EXPORT_PROCEDURE( find_loc_env_41___evcompile, _find_loc_196___evcompile2013, _find_loc_196___evcompile, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___evcompile(long checksum_3183, char * from_3184)
{
if(CBOOL(require_initialization_114___evcompile)){
require_initialization_114___evcompile = BBOOL(((bool_t)0));
cnst_init_137___evcompile();
imported_modules_init_94___evcompile();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___evcompile()
{
symbol1985___evcompile = string_to_symbol("NOWHERE");
symbol1987___evcompile = string_to_symbol("LAMBDA");
symbol1989___evcompile = string_to_symbol("MODULE");
symbol1990___evcompile = string_to_symbol("ASSERT");
symbol1991___evcompile = string_to_symbol("QUOTE");
symbol1992___evcompile = string_to_symbol("IF");
symbol1993___evcompile = string_to_symbol("BEGIN");
symbol1994___evcompile = string_to_symbol("DEFINE");
symbol1995___evcompile = string_to_symbol("SET!");
symbol1996___evcompile = string_to_symbol("BIND-EXIT");
symbol1997___evcompile = string_to_symbol("UNWIND-PROTECT");
symbol1998___evcompile = string_to_symbol("DYNAMIC");
return (symbol2001___evcompile = string_to_symbol("AT"),
BUNSPEC);
}


/* find-loc */obj_t find_loc_64___evcompile(obj_t exp_1, obj_t default_2)
{
{
bool_t test1099_1346;
test1099_1346 = EXTENDED_PAIRP(exp_1);
if(test1099_1346){
bool_t test1924_1349;
test1924_1349 = EXTENDED_PAIRP(exp_1);
if(test1924_1349){
return CER(exp_1);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_1);}
}
 else {
return default_2;
}
}
}


/* _find-loc */obj_t _find_loc_196___evcompile(obj_t env_3143, obj_t exp_3144, obj_t default_3145)
{
return find_loc_64___evcompile(exp_3144, default_3145);
}


/* evcompile */obj_t evcompile___evcompile(obj_t exp_3, obj_t env_4, obj_t genv_5, obj_t where_6, obj_t named__252_7, obj_t loc_8)
{
{
obj_t fun_419;
obj_t args_420;
obj_t fun_416;
obj_t args_417;
obj_t formals_413;
obj_t body_414;
obj_t body_410;
obj_t protect_411;
obj_t escape_407;
obj_t body_408;
obj_t var_401;
obj_t val_402;
obj_t var_398;
obj_t val_399;
obj_t si_392;
obj_t alors_393;
obj_t sinon_394;
obj_t atom_388;
if((exp_3==BNIL)){
return evcompile_error_92___evcompile(loc_8, string1982___evcompile, string1983___evcompile, BNIL);
}
 else {
if(PAIRP(exp_3)){
obj_t cdr_151_70_426;
cdr_151_70_426 = CDR(exp_3);
{
bool_t test_3216;
{
obj_t aux_3217;
aux_3217 = CAR(exp_3);
test_3216 = (aux_3217==symbol1989___evcompile);
}
if(test_3216){
if(PAIRP(cdr_151_70_426)){
module_declaration__32___eval(CDR(cdr_151_70_426));
return BUNSPEC;
}
 else {
obj_t car_294_146_430;
car_294_146_430 = CAR(exp_3);
if(PAIRP(car_294_146_430)){
fun_419 = car_294_146_430;
args_420 = cdr_151_70_426;
tag_116_227_421:
{
obj_t loc_793;
obj_t actuals_794;
obj_t proc_795;
{
bool_t test1099_2044;
test1099_2044 = EXTENDED_PAIRP(exp_3);
if(test1099_2044){
bool_t test1924_2047;
test1924_2047 = EXTENDED_PAIRP(exp_3);
if(test1924_2047){
loc_793 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
loc_793 = loc_8;
}
}
if(NULLP(args_420)){
actuals_794 = BNIL;
}
 else {
obj_t head1019_798;
head1019_798 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1017_799;
obj_t tail1020_800;
l1017_799 = args_420;
tail1020_800 = head1019_798;
lname1018_801:
if(NULLP(l1017_799)){
actuals_794 = CDR(head1019_798);
}
 else {
obj_t newtail1021_803;
{
obj_t arg1454_805;
arg1454_805 = evcompile___evcompile(CAR(l1017_799), env_4, genv_5, where_6, BFALSE, loc_8);
newtail1021_803 = MAKE_PAIR(arg1454_805, BNIL);
}
SET_CDR(tail1020_800, newtail1021_803);
{
obj_t tail1020_3245;
obj_t l1017_3243;
l1017_3243 = CDR(l1017_799);
tail1020_3245 = newtail1021_803;
tail1020_800 = tail1020_3245;
l1017_799 = l1017_3243;
goto lname1018_801;
}
}
}
}
proc_795 = evcompile___evcompile(fun_419, env_4, genv_5, where_6, BFALSE, loc_8);
return evcompile_application_224___evcompile(fun_419, proc_795, actuals_794, loc_793);
}
}
 else {
fun_416 = car_294_146_430;
args_417 = cdr_151_70_426;
tag_115_230_418:
{
obj_t loc_763;
{
bool_t test1099_2003;
test1099_2003 = EXTENDED_PAIRP(exp_3);
if(test1099_2003){
bool_t test1924_2006;
test1924_2006 = EXTENDED_PAIRP(exp_3);
if(test1924_2006){
loc_763 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
loc_763 = loc_8;
}
}
{
obj_t actuals_764;
if(NULLP(args_417)){
actuals_764 = BNIL;
}
 else {
obj_t head1013_781;
head1013_781 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1011_782;
obj_t tail1014_783;
l1011_782 = args_417;
tail1014_783 = head1013_781;
lname1012_784:
if(NULLP(l1011_782)){
actuals_764 = CDR(head1013_781);
}
 else {
obj_t newtail1015_786;
{
obj_t arg1446_788;
arg1446_788 = evcompile___evcompile(CAR(l1011_782), env_4, genv_5, where_6, BFALSE, loc_763);
newtail1015_786 = MAKE_PAIR(arg1446_788, BNIL);
}
SET_CDR(tail1014_783, newtail1015_786);
{
obj_t tail1014_3266;
obj_t l1011_3264;
l1011_3264 = CDR(l1011_782);
tail1014_3266 = newtail1015_786;
tail1014_783 = tail1014_3266;
l1011_782 = l1011_3264;
goto lname1012_784;
}
}
}
}
{
if(SYMBOLP(fun_416)){
{
obj_t proc_766;
proc_766 = variable___evcompile(loc_763, fun_416, env_4, genv_5);
{
bool_t test_3270;
if(VECTORP(proc_766)){
long aux_3273;
aux_3273 = VECTOR_LENGTH(proc_766);
test_3270 = (aux_3273==((long)3));
}
 else {
test_3270 = ((bool_t)0);
}
if(test_3270){
return evcompile_global_application_156___evcompile(proc_766, actuals_764, loc_763);
}
 else {
{
obj_t arg1427_768;
arg1427_768 = evcompile_ref_190___evcompile(proc_766, loc_763);
return evcompile_application_224___evcompile(fun_416, arg1427_768, actuals_764, loc_763);
}
}
}
}
}
 else {
if(PROCEDUREP(fun_416)){
return evcompile_compiled_application_76___evcompile(fun_416, actuals_764, loc_763);
}
 else {
evcompile_error_92___evcompile(loc_763, string1982___evcompile, string1988___evcompile, fun_416);
{
obj_t v1016_770;
v1016_770 = create_vector(((long)3));
{
obj_t arg1432_772;
{
obj_t list1433_773;
{
obj_t arg1437_775;
{
obj_t arg1440_777;
arg1440_777 = MAKE_PAIR(fun_416, BNIL);
arg1437_775 = MAKE_PAIR(string1988___evcompile, arg1440_777);
}
list1433_773 = MAKE_PAIR(string1982___evcompile, arg1437_775);
}
arg1432_772 = list1433_773;
}
VECTOR_SET(v1016_770, ((long)2), arg1432_772);
}
VECTOR_SET(v1016_770, ((long)1), loc_763);
{
obj_t aux_3289;
aux_3289 = BINT(((long)-2));
VECTOR_SET(v1016_770, ((long)0), aux_3289);
}
return v1016_770;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_3292;
{
obj_t aux_3293;
aux_3293 = CAR(exp_3);
test_3292 = (aux_3293==symbol1990___evcompile);
}
if(test_3292){
if(PAIRP(cdr_151_70_426)){
obj_t cdr_327_247_438;
cdr_327_247_438 = CDR(cdr_151_70_426);
if(PAIRP(cdr_327_247_438)){
obj_t cdr_329_18_440;
cdr_329_18_440 = CDR(cdr_327_247_438);
if(PAIRP(cdr_329_18_440)){
bool_t test_3304;
{
obj_t aux_3305;
aux_3305 = CDR(cdr_329_18_440);
test_3304 = (aux_3305==BNIL);
}
if(test_3304){
return BUNSPEC;
}
 else {
obj_t car_456_178_443;
car_456_178_443 = CAR(exp_3);
if(PAIRP(car_456_178_443)){
obj_t args_3312;
obj_t fun_3311;
fun_3311 = car_456_178_443;
args_3312 = cdr_151_70_426;
args_420 = args_3312;
fun_419 = fun_3311;
goto tag_116_227_421;
}
 else {
obj_t args_3314;
obj_t fun_3313;
fun_3313 = car_456_178_443;
args_3314 = cdr_151_70_426;
args_417 = args_3314;
fun_416 = fun_3313;
goto tag_115_230_418;
}
}
}
 else {
bool_t test_3315;
{
obj_t aux_3316;
{
obj_t aux_3317;
aux_3317 = CDR(cdr_151_70_426);
aux_3316 = CDR(aux_3317);
}
test_3315 = (aux_3316==BNIL);
}
if(test_3315){
return BUNSPEC;
}
 else {
obj_t car_602_130_451;
car_602_130_451 = CAR(exp_3);
if(PAIRP(car_602_130_451)){
obj_t args_3325;
obj_t fun_3324;
fun_3324 = car_602_130_451;
args_3325 = cdr_151_70_426;
args_420 = args_3325;
fun_419 = fun_3324;
goto tag_116_227_421;
}
 else {
obj_t args_3327;
obj_t fun_3326;
fun_3326 = car_602_130_451;
args_3327 = cdr_151_70_426;
args_417 = args_3327;
fun_416 = fun_3326;
goto tag_115_230_418;
}
}
}
}
 else {
obj_t car_742_61_460;
car_742_61_460 = CAR(exp_3);
if(PAIRP(car_742_61_460)){
obj_t args_3332;
obj_t fun_3331;
fun_3331 = car_742_61_460;
args_3332 = cdr_151_70_426;
args_420 = args_3332;
fun_419 = fun_3331;
goto tag_116_227_421;
}
 else {
obj_t args_3334;
obj_t fun_3333;
fun_3333 = car_742_61_460;
args_3334 = cdr_151_70_426;
args_417 = args_3334;
fun_416 = fun_3333;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_882_225_465;
car_882_225_465 = CAR(exp_3);
if(PAIRP(car_882_225_465)){
obj_t args_3339;
obj_t fun_3338;
fun_3338 = car_882_225_465;
args_3339 = cdr_151_70_426;
args_420 = args_3339;
fun_419 = fun_3338;
goto tag_116_227_421;
}
 else {
obj_t args_3341;
obj_t fun_3340;
fun_3340 = car_882_225_465;
args_3341 = cdr_151_70_426;
args_417 = args_3341;
fun_416 = fun_3340;
goto tag_115_230_418;
}
}
}
 else {
bool_t test_3342;
{
obj_t aux_3343;
aux_3343 = CAR(exp_3);
test_3342 = (aux_3343==symbol1991___evcompile);
}
if(test_3342){
if(PAIRP(cdr_151_70_426)){
bool_t test_3348;
{
obj_t aux_3349;
aux_3349 = CDR(cdr_151_70_426);
test_3348 = (aux_3349==BNIL);
}
if(test_3348){
obj_t arg1140_474;
arg1140_474 = CAR(cdr_151_70_426);
{
obj_t arg1361_1419;
{
bool_t test1099_1422;
test1099_1422 = EXTENDED_PAIRP(exp_3);
if(test1099_1422){
bool_t test1924_1425;
test1924_1425 = EXTENDED_PAIRP(exp_3);
if(test1924_1425){
arg1361_1419 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
arg1361_1419 = loc_8;
}
}
return evcompile_cnst_159___evcompile(arg1140_474, arg1361_1419);
}
}
 else {
obj_t car_1030_169_475;
car_1030_169_475 = CAR(exp_3);
if(PAIRP(car_1030_169_475)){
obj_t args_3364;
obj_t fun_3363;
fun_3363 = car_1030_169_475;
args_3364 = cdr_151_70_426;
args_420 = args_3364;
fun_419 = fun_3363;
goto tag_116_227_421;
}
 else {
obj_t args_3366;
obj_t fun_3365;
fun_3365 = car_1030_169_475;
args_3366 = cdr_151_70_426;
args_417 = args_3366;
fun_416 = fun_3365;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_1126_113_482;
car_1126_113_482 = CAR(exp_3);
if(PAIRP(car_1126_113_482)){
obj_t args_3371;
obj_t fun_3370;
fun_3370 = car_1126_113_482;
args_3371 = cdr_151_70_426;
args_420 = args_3371;
fun_419 = fun_3370;
goto tag_116_227_421;
}
 else {
obj_t args_3373;
obj_t fun_3372;
fun_3372 = car_1126_113_482;
args_3373 = cdr_151_70_426;
args_417 = args_3373;
fun_416 = fun_3372;
goto tag_115_230_418;
}
}
}
 else {
bool_t test_3374;
{
obj_t aux_3375;
aux_3375 = CAR(exp_3);
test_3374 = (aux_3375==symbol1992___evcompile);
}
if(test_3374){
if(PAIRP(cdr_151_70_426)){
obj_t cdr_1163_124_490;
cdr_1163_124_490 = CDR(cdr_151_70_426);
if(PAIRP(cdr_1163_124_490)){
obj_t cdr_1168_78_492;
cdr_1168_78_492 = CDR(cdr_1163_124_490);
if(PAIRP(cdr_1168_78_492)){
bool_t test_3386;
{
obj_t aux_3387;
aux_3387 = CDR(cdr_1168_78_492);
test_3386 = (aux_3387==BNIL);
}
if(test_3386){
si_392 = CAR(cdr_151_70_426);
alors_393 = CAR(cdr_1163_124_490);
sinon_394 = CAR(cdr_1168_78_492);
{
obj_t loc_694;
{
bool_t test1099_1717;
test1099_1717 = EXTENDED_PAIRP(exp_3);
if(test1099_1717){
bool_t test1924_1720;
test1924_1720 = EXTENDED_PAIRP(exp_3);
if(test1924_1720){
loc_694 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
loc_694 = loc_8;
}
}
{
obj_t arg1363_695;
obj_t arg1364_696;
obj_t arg1365_697;
{
obj_t arg1367_698;
{
bool_t test1099_1727;
test1099_1727 = EXTENDED_PAIRP(si_392);
if(test1099_1727){
bool_t test1924_1730;
test1924_1730 = EXTENDED_PAIRP(si_392);
if(test1924_1730){
arg1367_698 = CER(si_392);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,si_392);}
}
 else {
arg1367_698 = loc_694;
}
}
arg1363_695 = evcompile___evcompile(si_392, env_4, genv_5, where_6, BFALSE, arg1367_698);
}
{
obj_t arg1368_699;
{
bool_t test1099_1737;
test1099_1737 = EXTENDED_PAIRP(alors_393);
if(test1099_1737){
bool_t test1924_1740;
test1924_1740 = EXTENDED_PAIRP(alors_393);
if(test1924_1740){
arg1368_699 = CER(alors_393);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,alors_393);}
}
 else {
arg1368_699 = loc_694;
}
}
arg1364_696 = evcompile___evcompile(alors_393, env_4, genv_5, where_6, named__252_7, arg1368_699);
}
{
obj_t arg1369_700;
{
bool_t test1099_1747;
test1099_1747 = EXTENDED_PAIRP(sinon_394);
if(test1099_1747){
bool_t test1924_1750;
test1924_1750 = EXTENDED_PAIRP(sinon_394);
if(test1924_1750){
arg1369_700 = CER(sinon_394);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,sinon_394);}
}
 else {
arg1369_700 = loc_694;
}
}
arg1365_697 = evcompile___evcompile(sinon_394, env_4, genv_5, where_6, named__252_7, arg1369_700);
}
{
obj_t v1035_1759;
v1035_1759 = create_vector(((long)3));
{
obj_t arg1488_1761;
{
obj_t v1036_1762;
v1036_1762 = create_vector(((long)3));
VECTOR_SET(v1036_1762, ((long)2), arg1365_697);
VECTOR_SET(v1036_1762, ((long)1), arg1364_696);
VECTOR_SET(v1036_1762, ((long)0), arg1363_695);
arg1488_1761 = v1036_1762;
}
VECTOR_SET(v1035_1759, ((long)2), arg1488_1761);
}
VECTOR_SET(v1035_1759, ((long)1), loc_694);
{
obj_t aux_3424;
aux_3424 = BINT(((long)15));
VECTOR_SET(v1035_1759, ((long)0), aux_3424);
}
return v1035_1759;
}
}
}
}
 else {
obj_t car_1239_2_498;
car_1239_2_498 = CAR(exp_3);
if(PAIRP(car_1239_2_498)){
obj_t args_3434;
obj_t fun_3433;
fun_3433 = car_1239_2_498;
args_3434 = cdr_151_70_426;
args_420 = args_3434;
fun_419 = fun_3433;
goto tag_116_227_421;
}
 else {
obj_t args_3436;
obj_t fun_3435;
fun_3435 = car_1239_2_498;
args_3436 = cdr_151_70_426;
args_417 = args_3436;
fun_416 = fun_3435;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_1320_233_505;
car_1320_233_505 = CAR(exp_3);
if(PAIRP(car_1320_233_505)){
obj_t args_3441;
obj_t fun_3440;
fun_3440 = car_1320_233_505;
args_3441 = cdr_151_70_426;
args_420 = args_3441;
fun_419 = fun_3440;
goto tag_116_227_421;
}
 else {
obj_t args_3443;
obj_t fun_3442;
fun_3442 = car_1320_233_505;
args_3443 = cdr_151_70_426;
args_417 = args_3443;
fun_416 = fun_3442;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_1401_86_510;
car_1401_86_510 = CAR(exp_3);
if(PAIRP(car_1401_86_510)){
obj_t args_3448;
obj_t fun_3447;
fun_3447 = car_1401_86_510;
args_3448 = cdr_151_70_426;
args_420 = args_3448;
fun_419 = fun_3447;
goto tag_116_227_421;
}
 else {
obj_t args_3450;
obj_t fun_3449;
fun_3449 = car_1401_86_510;
args_3450 = cdr_151_70_426;
args_417 = args_3450;
fun_416 = fun_3449;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_1482_221_515;
car_1482_221_515 = CAR(exp_3);
if(PAIRP(car_1482_221_515)){
obj_t args_3455;
obj_t fun_3454;
fun_3454 = car_1482_221_515;
args_3455 = cdr_151_70_426;
args_420 = args_3455;
fun_419 = fun_3454;
goto tag_116_227_421;
}
 else {
obj_t args_3457;
obj_t fun_3456;
fun_3456 = car_1482_221_515;
args_3457 = cdr_151_70_426;
args_417 = args_3457;
fun_416 = fun_3456;
goto tag_115_230_418;
}
}
}
 else {
bool_t test_3458;
{
obj_t aux_3459;
aux_3459 = CAR(exp_3);
test_3458 = (aux_3459==symbol1993___evcompile);
}
if(test_3458){
obj_t arg1370_1480;
{
bool_t test1099_1483;
test1099_1483 = EXTENDED_PAIRP(exp_3);
if(test1099_1483){
bool_t test1924_1486;
test1924_1486 = EXTENDED_PAIRP(exp_3);
if(test1924_1486){
arg1370_1480 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
arg1370_1480 = loc_8;
}
}
return evcompile_begin_220___evcompile(cdr_151_70_426, env_4, genv_5, where_6, named__252_7, arg1370_1480);
}
 else {
bool_t test_3469;
{
obj_t aux_3470;
aux_3470 = CAR(exp_3);
test_3469 = (aux_3470==symbol1994___evcompile);
}
if(test_3469){
if(PAIRP(cdr_151_70_426)){
obj_t cdr_1526_238_525;
cdr_1526_238_525 = CDR(cdr_151_70_426);
if(PAIRP(cdr_1526_238_525)){
obj_t car_1529_123_527;
car_1529_123_527 = CAR(cdr_1526_238_525);
if(PAIRP(car_1529_123_527)){
bool_t test_3481;
{
obj_t aux_3482;
aux_3482 = CAR(car_1529_123_527);
test_3481 = (aux_3482==symbol1987___evcompile);
}
if(test_3481){
bool_t test_3485;
{
obj_t aux_3486;
aux_3486 = CDR(cdr_1526_238_525);
test_3485 = (aux_3486==BNIL);
}
if(test_3485){
var_398 = CAR(cdr_151_70_426);
val_399 = car_1529_123_527;
{
bool_t test1371_702;
if((where_6==symbol1985___evcompile)){
bool_t _ortest_1009_711;
{
obj_t arg1383_713;
arg1383_713 = scheme_report_environment_154___eval(BINT(((long)5)));
_ortest_1009_711 = (genv_5==arg1383_713);
}
if(_ortest_1009_711){
test1371_702 = _ortest_1009_711;
}
 else {
obj_t arg1381_712;
arg1381_712 = null_environment_221___eval(BINT(((long)5)));
test1371_702 = (genv_5==arg1381_712);
}
}
 else {
test1371_702 = ((bool_t)0);
}
if(test1371_702){
return evcompile_error_92___evcompile(loc_8, string1982___evcompile, string1986___evcompile, exp_3);
}
 else {
obj_t loc_703;
{
bool_t test1099_1800;
test1099_1800 = EXTENDED_PAIRP(exp_3);
if(test1099_1800){
bool_t test1924_1803;
test1924_1803 = EXTENDED_PAIRP(exp_3);
if(test1924_1803){
loc_703 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
loc_703 = loc_8;
}
}
{
obj_t arg1372_704;
{
obj_t arg1373_3148;
arg1373_3148 = make_fx_procedure(arg1373___evcompile, ((long)0), ((long)5));
PROCEDURE_SET(arg1373_3148, ((long)0), exp_3);
PROCEDURE_SET(arg1373_3148, ((long)1), loc_703);
PROCEDURE_SET(arg1373_3148, ((long)2), val_399);
PROCEDURE_SET(arg1373_3148, ((long)3), genv_5);
PROCEDURE_SET(arg1373_3148, ((long)4), var_398);
arg1372_704 = make_promise_21___r4_control_features_6_9(arg1373_3148);
}
{
obj_t v1038_1821;
v1038_1821 = create_vector(((long)3));
{
obj_t arg1519_1823;
arg1519_1823 = MAKE_PAIR(var_398, arg1372_704);
VECTOR_SET(v1038_1821, ((long)2), arg1519_1823);
}
VECTOR_SET(v1038_1821, ((long)1), loc_703);
{
obj_t aux_3517;
aux_3517 = BINT(((long)17));
VECTOR_SET(v1038_1821, ((long)0), aux_3517);
}
return v1038_1821;
}
}
}
}
}
 else {
obj_t car_1582_194_532;
car_1582_194_532 = CAR(exp_3);
if(PAIRP(car_1582_194_532)){
obj_t args_3525;
obj_t fun_3524;
fun_3524 = car_1582_194_532;
args_3525 = cdr_151_70_426;
args_420 = args_3525;
fun_419 = fun_3524;
goto tag_116_227_421;
}
 else {
obj_t args_3527;
obj_t fun_3526;
fun_3526 = car_1582_194_532;
args_3527 = cdr_151_70_426;
args_417 = args_3527;
fun_416 = fun_3526;
goto tag_115_230_418;
}
}
}
 else {
obj_t cdr_1615_157_540;
cdr_1615_157_540 = CDR(cdr_151_70_426);
{
bool_t test_3529;
{
obj_t aux_3530;
aux_3530 = CDR(cdr_1615_157_540);
test_3529 = (aux_3530==BNIL);
}
if(test_3529){
var_401 = CAR(cdr_151_70_426);
val_402 = CAR(cdr_1615_157_540);
tag_110_179_403:
{
bool_t test1385_715;
if((where_6==symbol1985___evcompile)){
bool_t _ortest_1010_721;
{
obj_t arg1392_723;
arg1392_723 = scheme_report_environment_154___eval(BINT(((long)5)));
_ortest_1010_721 = (genv_5==arg1392_723);
}
if(_ortest_1010_721){
test1385_715 = _ortest_1010_721;
}
 else {
obj_t arg1391_722;
arg1391_722 = null_environment_221___eval(BINT(((long)5)));
test1385_715 = (genv_5==arg1391_722);
}
}
 else {
test1385_715 = ((bool_t)0);
}
if(test1385_715){
return evcompile_error_92___evcompile(loc_8, string1982___evcompile, string1986___evcompile, exp_3);
}
 else {
obj_t loc_716;
{
bool_t test1099_1843;
test1099_1843 = EXTENDED_PAIRP(exp_3);
if(test1099_1843){
bool_t test1924_1846;
test1924_1846 = EXTENDED_PAIRP(exp_3);
if(test1924_1846){
loc_716 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
loc_716 = loc_8;
}
}
{
obj_t arg1387_717;
{
obj_t arg1389_719;
{
bool_t test1099_1853;
test1099_1853 = EXTENDED_PAIRP(val_402);
if(test1099_1853){
bool_t test1924_1856;
test1924_1856 = EXTENDED_PAIRP(val_402);
if(test1924_1856){
arg1389_719 = CER(val_402);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,val_402);}
}
 else {
arg1389_719 = loc_716;
}
}
arg1387_717 = evcompile___evcompile(val_402, BNIL, genv_5, where_6, named__252_7, arg1389_719);
}
{
obj_t v1039_1864;
v1039_1864 = create_vector(((long)3));
{
obj_t arg1524_1866;
arg1524_1866 = MAKE_PAIR(var_401, arg1387_717);
VECTOR_SET(v1039_1864, ((long)2), arg1524_1866);
}
VECTOR_SET(v1039_1864, ((long)1), loc_716);
{
obj_t aux_3561;
aux_3561 = BINT(((long)63));
VECTOR_SET(v1039_1864, ((long)0), aux_3561);
}
return v1039_1864;
}
}
}
}
}
 else {
obj_t car_1657_20_544;
car_1657_20_544 = CAR(exp_3);
if(PAIRP(car_1657_20_544)){
obj_t args_3570;
obj_t fun_3569;
fun_3569 = car_1657_20_544;
args_3570 = cdr_151_70_426;
args_420 = args_3570;
fun_419 = fun_3569;
goto tag_116_227_421;
}
 else {
obj_t args_3572;
obj_t fun_3571;
fun_3571 = car_1657_20_544;
args_3572 = cdr_151_70_426;
args_417 = args_3572;
fun_416 = fun_3571;
goto tag_115_230_418;
}
}
}
}
}
 else {
obj_t cdr_1690_137_554;
cdr_1690_137_554 = CDR(cdr_151_70_426);
{
bool_t test_3574;
{
obj_t aux_3575;
aux_3575 = CDR(cdr_1690_137_554);
test_3574 = (aux_3575==BNIL);
}
if(test_3574){
obj_t val_3580;
obj_t var_3578;
var_3578 = CAR(cdr_151_70_426);
val_3580 = CAR(cdr_1690_137_554);
val_402 = val_3580;
var_401 = var_3578;
goto tag_110_179_403;
}
 else {
obj_t car_1732_168_558;
car_1732_168_558 = CAR(exp_3);
if(PAIRP(car_1732_168_558)){
obj_t args_3586;
obj_t fun_3585;
fun_3585 = car_1732_168_558;
args_3586 = cdr_151_70_426;
args_420 = args_3586;
fun_419 = fun_3585;
goto tag_116_227_421;
}
 else {
obj_t args_3588;
obj_t fun_3587;
fun_3587 = car_1732_168_558;
args_3588 = cdr_151_70_426;
args_417 = args_3588;
fun_416 = fun_3587;
goto tag_115_230_418;
}
}
}
}
}
 else {
obj_t car_1794_35_565;
car_1794_35_565 = CAR(exp_3);
if(PAIRP(car_1794_35_565)){
obj_t args_3593;
obj_t fun_3592;
fun_3592 = car_1794_35_565;
args_3593 = cdr_151_70_426;
args_420 = args_3593;
fun_419 = fun_3592;
goto tag_116_227_421;
}
 else {
obj_t args_3595;
obj_t fun_3594;
fun_3594 = car_1794_35_565;
args_3595 = cdr_151_70_426;
args_417 = args_3595;
fun_416 = fun_3594;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_1855_2_570;
car_1855_2_570 = CAR(exp_3);
if(PAIRP(car_1855_2_570)){
obj_t args_3600;
obj_t fun_3599;
fun_3599 = car_1855_2_570;
args_3600 = cdr_151_70_426;
args_420 = args_3600;
fun_419 = fun_3599;
goto tag_116_227_421;
}
 else {
obj_t args_3602;
obj_t fun_3601;
fun_3601 = car_1855_2_570;
args_3602 = cdr_151_70_426;
args_417 = args_3602;
fun_416 = fun_3601;
goto tag_115_230_418;
}
}
}
 else {
bool_t test_3603;
{
obj_t aux_3604;
aux_3604 = CAR(exp_3);
test_3603 = (aux_3604==symbol1995___evcompile);
}
if(test_3603){
if(PAIRP(cdr_151_70_426)){
obj_t cdr_1896_250_578;
cdr_1896_250_578 = CDR(cdr_151_70_426);
if(PAIRP(cdr_1896_250_578)){
bool_t test_3612;
{
obj_t aux_3613;
aux_3613 = CDR(cdr_1896_250_578);
test_3612 = (aux_3613==BNIL);
}
if(test_3612){
obj_t arg1236_581;
obj_t arg1238_582;
arg1236_581 = CAR(cdr_151_70_426);
arg1238_582 = CAR(cdr_1896_250_578);
{
obj_t loc_1560;
{
bool_t test1099_1566;
test1099_1566 = EXTENDED_PAIRP(exp_3);
if(test1099_1566){
bool_t test1924_1569;
test1924_1569 = EXTENDED_PAIRP(exp_3);
if(test1924_1569){
loc_1560 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
loc_1560 = loc_8;
}
}
{
obj_t arg1395_1561;
obj_t arg1396_1562;
arg1395_1561 = variable___evcompile(loc_1560, arg1236_581, env_4, genv_5);
{
obj_t arg1397_1563;
{
bool_t test1099_1576;
test1099_1576 = EXTENDED_PAIRP(arg1238_582);
if(test1099_1576){
bool_t test1924_1579;
test1924_1579 = EXTENDED_PAIRP(arg1238_582);
if(test1924_1579){
arg1397_1563 = CER(arg1238_582);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,arg1238_582);}
}
 else {
arg1397_1563 = loc_1560;
}
}
arg1396_1562 = evcompile___evcompile(arg1238_582, env_4, genv_5, arg1236_581, BTRUE, arg1397_1563);
}
return evcompile_set_124___evcompile(arg1395_1561, arg1396_1562, loc_1560);
}
}
}
 else {
obj_t car_1927_113_583;
car_1927_113_583 = CAR(exp_3);
if(PAIRP(car_1927_113_583)){
obj_t args_3637;
obj_t fun_3636;
fun_3636 = car_1927_113_583;
args_3637 = cdr_151_70_426;
args_420 = args_3637;
fun_419 = fun_3636;
goto tag_116_227_421;
}
 else {
obj_t args_3639;
obj_t fun_3638;
fun_3638 = car_1927_113_583;
args_3639 = cdr_151_70_426;
args_417 = args_3639;
fun_416 = fun_3638;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_1968_169_590;
car_1968_169_590 = CAR(exp_3);
if(PAIRP(car_1968_169_590)){
obj_t args_3644;
obj_t fun_3643;
fun_3643 = car_1968_169_590;
args_3644 = cdr_151_70_426;
args_420 = args_3644;
fun_419 = fun_3643;
goto tag_116_227_421;
}
 else {
obj_t args_3646;
obj_t fun_3645;
fun_3645 = car_1968_169_590;
args_3646 = cdr_151_70_426;
args_417 = args_3646;
fun_416 = fun_3645;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_2009_230_595;
car_2009_230_595 = CAR(exp_3);
if(PAIRP(car_2009_230_595)){
obj_t args_3651;
obj_t fun_3650;
fun_3650 = car_2009_230_595;
args_3651 = cdr_151_70_426;
args_420 = args_3651;
fun_419 = fun_3650;
goto tag_116_227_421;
}
 else {
obj_t args_3653;
obj_t fun_3652;
fun_3652 = car_2009_230_595;
args_3653 = cdr_151_70_426;
args_417 = args_3653;
fun_416 = fun_3652;
goto tag_115_230_418;
}
}
}
 else {
bool_t test_3654;
{
obj_t aux_3655;
aux_3655 = CAR(exp_3);
test_3654 = (aux_3655==symbol1996___evcompile);
}
if(test_3654){
if(PAIRP(cdr_151_70_426)){
obj_t cdr_2038_115_603;
cdr_2038_115_603 = CDR(cdr_151_70_426);
if(PAIRP(cdr_2038_115_603)){
bool_t test_3663;
{
obj_t aux_3664;
aux_3664 = CDR(cdr_2038_115_603);
test_3663 = (aux_3664==BNIL);
}
if(test_3663){
escape_407 = CAR(cdr_151_70_426);
body_408 = CAR(cdr_2038_115_603);
{
obj_t loc_729;
{
bool_t test1099_1904;
test1099_1904 = EXTENDED_PAIRP(exp_3);
if(test1099_1904){
bool_t test1924_1907;
test1924_1907 = EXTENDED_PAIRP(exp_3);
if(test1924_1907){
loc_729 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
loc_729 = loc_8;
}
}
{
obj_t arg1398_730;
{
obj_t arg1399_731;
obj_t arg1401_732;
{
obj_t arg1402_733;
arg1402_733 = symbol1987___evcompile;
{
obj_t list1404_735;
{
obj_t arg1405_736;
{
obj_t arg1407_737;
arg1407_737 = MAKE_PAIR(BNIL, BNIL);
arg1405_736 = MAKE_PAIR(body_408, arg1407_737);
}
list1404_735 = MAKE_PAIR(escape_407, arg1405_736);
}
arg1399_731 = cons__138___r4_pairs_and_lists_6_3(arg1402_733, list1404_735);
}
}
{
bool_t test1099_1914;
test1099_1914 = EXTENDED_PAIRP(body_408);
if(test1099_1914){
bool_t test1924_1917;
test1924_1917 = EXTENDED_PAIRP(body_408);
if(test1924_1917){
arg1401_732 = CER(body_408);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,body_408);}
}
 else {
arg1401_732 = loc_729;
}
}
arg1398_730 = evcompile___evcompile(arg1399_731, env_4, genv_5, escape_407, BTRUE, arg1401_732);
}
{
obj_t v1040_1924;
v1040_1924 = create_vector(((long)3));
VECTOR_SET(v1040_1924, ((long)2), arg1398_730);
VECTOR_SET(v1040_1924, ((long)1), loc_729);
{
obj_t aux_3687;
aux_3687 = BINT(((long)18));
VECTOR_SET(v1040_1924, ((long)0), aux_3687);
}
return v1040_1924;
}
}
}
}
 else {
obj_t car_2061_83_608;
car_2061_83_608 = CAR(exp_3);
if(PAIRP(car_2061_83_608)){
obj_t args_3696;
obj_t fun_3695;
fun_3695 = car_2061_83_608;
args_3696 = cdr_151_70_426;
args_420 = args_3696;
fun_419 = fun_3695;
goto tag_116_227_421;
}
 else {
obj_t args_3698;
obj_t fun_3697;
fun_3697 = car_2061_83_608;
args_3698 = cdr_151_70_426;
args_417 = args_3698;
fun_416 = fun_3697;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_2094_154_615;
car_2094_154_615 = CAR(exp_3);
if(PAIRP(car_2094_154_615)){
obj_t args_3703;
obj_t fun_3702;
fun_3702 = car_2094_154_615;
args_3703 = cdr_151_70_426;
args_420 = args_3703;
fun_419 = fun_3702;
goto tag_116_227_421;
}
 else {
obj_t args_3705;
obj_t fun_3704;
fun_3704 = car_2094_154_615;
args_3705 = cdr_151_70_426;
args_417 = args_3705;
fun_416 = fun_3704;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_2127_77_620;
car_2127_77_620 = CAR(exp_3);
if(PAIRP(car_2127_77_620)){
obj_t args_3710;
obj_t fun_3709;
fun_3709 = car_2127_77_620;
args_3710 = cdr_151_70_426;
args_420 = args_3710;
fun_419 = fun_3709;
goto tag_116_227_421;
}
 else {
obj_t args_3712;
obj_t fun_3711;
fun_3711 = car_2127_77_620;
args_3712 = cdr_151_70_426;
args_417 = args_3712;
fun_416 = fun_3711;
goto tag_115_230_418;
}
}
}
 else {
bool_t test_3713;
{
obj_t aux_3714;
aux_3714 = CAR(exp_3);
test_3713 = (aux_3714==symbol1997___evcompile);
}
if(test_3713){
if(PAIRP(cdr_151_70_426)){
body_410 = CAR(cdr_151_70_426);
protect_411 = CDR(cdr_151_70_426);
{
obj_t loc_739;
{
bool_t test1099_1936;
test1099_1936 = EXTENDED_PAIRP(exp_3);
if(test1099_1936){
bool_t test1924_1939;
test1924_1939 = EXTENDED_PAIRP(exp_3);
if(test1924_1939){
loc_739 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
loc_739 = loc_8;
}
}
{
obj_t arg1410_740;
obj_t arg1411_741;
{
obj_t arg1413_742;
{
bool_t test1099_1946;
test1099_1946 = EXTENDED_PAIRP(body_410);
if(test1099_1946){
bool_t test1924_1949;
test1924_1949 = EXTENDED_PAIRP(body_410);
if(test1924_1949){
arg1413_742 = CER(body_410);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,body_410);}
}
 else {
arg1413_742 = loc_739;
}
}
arg1410_740 = evcompile___evcompile(body_410, env_4, genv_5, where_6, named__252_7, arg1413_742);
}
{
obj_t arg1414_743;
{
bool_t test1099_1956;
test1099_1956 = EXTENDED_PAIRP(protect_411);
if(test1099_1956){
bool_t test1924_1959;
test1924_1959 = EXTENDED_PAIRP(protect_411);
if(test1924_1959){
arg1414_743 = CER(protect_411);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,protect_411);}
}
 else {
arg1414_743 = loc_739;
}
}
arg1411_741 = evcompile_begin_220___evcompile(protect_411, env_4, genv_5, where_6, named__252_7, arg1414_743);
}
{
obj_t v1041_1967;
v1041_1967 = create_vector(((long)3));
{
obj_t arg1526_1969;
arg1526_1969 = MAKE_PAIR(arg1410_740, arg1411_741);
VECTOR_SET(v1041_1967, ((long)2), arg1526_1969);
}
VECTOR_SET(v1041_1967, ((long)1), loc_739);
{
obj_t aux_3743;
aux_3743 = BINT(((long)64));
VECTOR_SET(v1041_1967, ((long)0), aux_3743);
}
return v1041_1967;
}
}
}
}
 else {
obj_t car_2168_110_630;
car_2168_110_630 = CAR(exp_3);
if(PAIRP(car_2168_110_630)){
obj_t args_3752;
obj_t fun_3751;
fun_3751 = car_2168_110_630;
args_3752 = cdr_151_70_426;
args_420 = args_3752;
fun_419 = fun_3751;
goto tag_116_227_421;
}
 else {
obj_t args_3754;
obj_t fun_3753;
fun_3753 = car_2168_110_630;
args_3754 = cdr_151_70_426;
args_417 = args_3754;
fun_416 = fun_3753;
goto tag_115_230_418;
}
}
}
 else {
bool_t test_3755;
{
obj_t aux_3756;
aux_3756 = CAR(exp_3);
test_3755 = (aux_3756==symbol1987___evcompile);
}
if(test_3755){
if(PAIRP(cdr_151_70_426)){
obj_t cdr_2195_134_638;
cdr_2195_134_638 = CDR(cdr_151_70_426);
if(PAIRP(cdr_2195_134_638)){
bool_t test_3764;
{
obj_t aux_3765;
aux_3765 = CDR(cdr_2195_134_638);
test_3764 = (aux_3765==BNIL);
}
if(test_3764){
formals_413 = CAR(cdr_151_70_426);
body_414 = CAR(cdr_2195_134_638);
{
obj_t loc_744;
obj_t scm_formals_46_745;
{
bool_t test1099_1983;
test1099_1983 = EXTENDED_PAIRP(exp_3);
if(test1099_1983){
bool_t test1924_1986;
test1924_1986 = EXTENDED_PAIRP(exp_3);
if(test1924_1986){
loc_744 = CER(exp_3);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3);}
}
 else {
loc_744 = loc_8;
}
}
{
obj_t arg1423_3147;
arg1423_3147 = make_fx_procedure(arg1423___evcompile, ((long)3), ((long)1));
PROCEDURE_SET(arg1423_3147, ((long)0), loc_8);
scm_formals_46_745 = dsssl_formals__scheme_formals_201___dsssl(formals_413, arg1423_3147);
}
{
obj_t arg1415_746;
{
obj_t arg1416_747;
obj_t arg1417_748;
obj_t arg1418_749;
{
obj_t arg1419_750;
{
obj_t arg1421_3146;
arg1421_3146 = make_fx_procedure(arg1421___evcompile, ((long)3), ((long)1));
PROCEDURE_SET(arg1421_3146, ((long)0), loc_744);
arg1419_750 = make_dsssl_function_prelude_58___dsssl(exp_3, formals_413, body_414, arg1421_3146);
}
arg1416_747 = expand___expand(arg1419_750);
}
{
obj_t extend_3181;
obj_t old_env_160_3182;
extend_3181 = scm_formals_46_745;
old_env_160_3182 = env_4;
arg1417_748 = _loop____evcompile(old_env_160_3182, extend_3181);
}
{
bool_t test1099_1993;
test1099_1993 = EXTENDED_PAIRP(body_414);
if(test1099_1993){
bool_t test1924_1996;
test1924_1996 = EXTENDED_PAIRP(body_414);
if(test1924_1996){
arg1418_749 = CER(body_414);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,body_414);}
}
 else {
arg1418_749 = loc_744;
}
}
arg1415_746 = evcompile___evcompile(arg1416_747, arg1417_748, genv_5, where_6, BFALSE, arg1418_749);
}
return evcompile_lambda_39___evcompile(scm_formals_46_745, arg1415_746, where_6, named__252_7, loc_744);
}
}
}
 else {
obj_t car_2205_75_643;
car_2205_75_643 = CAR(exp_3);
if(PAIRP(car_2205_75_643)){
obj_t args_3796;
obj_t fun_3795;
fun_3795 = car_2205_75_643;
args_3796 = cdr_151_70_426;
args_420 = args_3796;
fun_419 = fun_3795;
goto tag_116_227_421;
}
 else {
obj_t args_3798;
obj_t fun_3797;
fun_3797 = car_2205_75_643;
args_3798 = cdr_151_70_426;
args_417 = args_3798;
fun_416 = fun_3797;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_2225_124_650;
car_2225_124_650 = CAR(exp_3);
if(PAIRP(car_2225_124_650)){
obj_t args_3803;
obj_t fun_3802;
fun_3802 = car_2225_124_650;
args_3803 = cdr_151_70_426;
args_420 = args_3803;
fun_419 = fun_3802;
goto tag_116_227_421;
}
 else {
obj_t args_3805;
obj_t fun_3804;
fun_3804 = car_2225_124_650;
args_3805 = cdr_151_70_426;
args_417 = args_3805;
fun_416 = fun_3804;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_2245_113_655;
car_2245_113_655 = CAR(exp_3);
if(PAIRP(car_2245_113_655)){
obj_t args_3810;
obj_t fun_3809;
fun_3809 = car_2245_113_655;
args_3810 = cdr_151_70_426;
args_420 = args_3810;
fun_419 = fun_3809;
goto tag_116_227_421;
}
 else {
obj_t args_3812;
obj_t fun_3811;
fun_3811 = car_2245_113_655;
args_3812 = cdr_151_70_426;
args_417 = args_3812;
fun_416 = fun_3811;
goto tag_115_230_418;
}
}
}
 else {
obj_t car_2265_61_660;
car_2265_61_660 = CAR(exp_3);
if(PAIRP(car_2265_61_660)){
obj_t args_3817;
obj_t fun_3816;
fun_3816 = car_2265_61_660;
args_3817 = cdr_151_70_426;
args_420 = args_3817;
fun_419 = fun_3816;
goto tag_116_227_421;
}
 else {
obj_t args_3819;
obj_t fun_3818;
fun_3818 = car_2265_61_660;
args_3819 = cdr_151_70_426;
args_417 = args_3819;
fun_416 = fun_3818;
goto tag_115_230_418;
}
}
}
}
}
}
}
}
}
}
}
}
}
 else {
atom_388 = exp_3;
if(SYMBOLP(atom_388)){
{
obj_t arg1355_690;
arg1355_690 = variable___evcompile(loc_8, atom_388, env_4, genv_5);
return evcompile_ref_190___evcompile(arg1355_690, loc_8);
}
}
 else {
bool_t test_3824;
if(VECTORP(atom_388)){
test_3824 = ((bool_t)1);
}
 else {
test_3824 = STRUCTP(atom_388);
}
if(test_3824){
return evcompile_error_92___evcompile(loc_8, string1982___evcompile, string1984___evcompile, exp_3);
}
 else {
if(VECTORP(atom_388)){
{
obj_t v1022_1679;
v1022_1679 = create_vector(((long)3));
VECTOR_SET(v1022_1679, ((long)2), atom_388);
VECTOR_SET(v1022_1679, ((long)1), loc_8);
{
obj_t aux_3834;
aux_3834 = BINT(((long)-1));
VECTOR_SET(v1022_1679, ((long)0), aux_3834);
}
return v1022_1679;
}
}
 else {
return atom_388;
}
}
}
}
}
}
}


/* _evcompile */obj_t _evcompile___evcompile(obj_t env_3149, obj_t exp_3150, obj_t env_3151, obj_t genv_3152, obj_t where_3153, obj_t named__252_3154, obj_t loc_3155)
{
return evcompile___evcompile(exp_3150, env_3151, genv_3152, where_3153, named__252_3154, loc_3155);
}


/* arg1421 */obj_t arg1421___evcompile(obj_t env_3156, obj_t proc_3158, obj_t msg_3159, obj_t obj_3160)
{
{
obj_t loc_3157;
loc_3157 = PROCEDURE_REF(env_3156, ((long)0));
{
obj_t proc_752;
obj_t msg_753;
obj_t obj_754;
proc_752 = proc_3158;
msg_753 = msg_3159;
obj_754 = obj_3160;
return evcompile_error_92___evcompile(loc_3157, proc_752, msg_753, obj_754);
}
}
}


/* arg1423 */obj_t arg1423___evcompile(obj_t env_3161, obj_t proc_3163, obj_t msg_3164, obj_t obj_3165)
{
{
obj_t loc_3162;
loc_3162 = PROCEDURE_REF(env_3161, ((long)0));
{
obj_t proc_758;
obj_t msg_759;
obj_t obj_760;
proc_758 = proc_3163;
msg_759 = msg_3164;
obj_760 = obj_3165;
return evcompile_error_92___evcompile(loc_3162, proc_758, msg_759, obj_760);
}
}
}


/* arg1373 */obj_t arg1373___evcompile(obj_t env_3166)
{
{
obj_t exp_3167;
obj_t loc_3168;
obj_t val_3169;
obj_t genv_3170;
obj_t var_3171;
exp_3167 = PROCEDURE_REF(env_3166, ((long)0));
loc_3168 = PROCEDURE_REF(env_3166, ((long)1));
val_3169 = PROCEDURE_REF(env_3166, ((long)2));
genv_3170 = PROCEDURE_REF(env_3166, ((long)3));
var_3171 = PROCEDURE_REF(env_3166, ((long)4));
{
{
obj_t arg1378_708;
{
bool_t test1099_1810;
test1099_1810 = EXTENDED_PAIRP(exp_3167);
if(test1099_1810){
bool_t test1924_1813;
test1924_1813 = EXTENDED_PAIRP(exp_3167);
if(test1924_1813){
arg1378_708 = CER(exp_3167);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,exp_3167);}
}
 else {
arg1378_708 = loc_3168;
}
}
return evcompile___evcompile(val_3169, BNIL, genv_3170, var_3171, BTRUE, arg1378_708);
}
}
}
}


/* evcompile-cnst */obj_t evcompile_cnst_159___evcompile(obj_t cnst_9, obj_t loc_10)
{
if(VECTORP(cnst_9)){
{
obj_t v1022_2064;
v1022_2064 = create_vector(((long)3));
VECTOR_SET(v1022_2064, ((long)2), cnst_9);
VECTOR_SET(v1022_2064, ((long)1), loc_10);
{
obj_t aux_3859;
aux_3859 = BINT(((long)-1));
VECTOR_SET(v1022_2064, ((long)0), aux_3859);
}
return v1022_2064;
}
}
 else {
return cnst_9;
}
}


/* evcompile-ref */obj_t evcompile_ref_190___evcompile(obj_t variable_11, obj_t loc_12)
{
{
bool_t test_3862;
if(VECTORP(variable_11)){
long aux_3865;
aux_3865 = VECTOR_LENGTH(variable_11);
test_3862 = (aux_3865==((long)3));
}
 else {
test_3862 = ((bool_t)0);
}
if(test_3862){
{
obj_t v1023_813;
v1023_813 = create_vector(((long)3));
VECTOR_SET(v1023_813, ((long)2), variable_11);
VECTOR_SET(v1023_813, ((long)1), loc_12);
{
obj_t aux_3871;
{
long aux_3872;
{
bool_t test_3873;
{
obj_t aux_3876;
obj_t aux_3874;
aux_3876 = BINT(((long)1));
aux_3874 = VECTOR_REF(variable_11, ((long)0));
test_3873 = (aux_3874==aux_3876);
}
if(test_3873){
aux_3872 = ((long)5);
}
 else {
aux_3872 = ((long)6);
}
}
aux_3871 = BINT(aux_3872);
}
VECTOR_SET(v1023_813, ((long)0), aux_3871);
}
return v1023_813;
}
}
 else {
bool_t test_3881;
if(PAIRP(variable_11)){
obj_t aux_3884;
aux_3884 = CAR(variable_11);
test_3881 = (aux_3884==symbol1998___evcompile);
}
 else {
test_3881 = ((bool_t)0);
}
if(test_3881){
{
obj_t v1024_820;
v1024_820 = create_vector(((long)3));
{
obj_t aux_3888;
aux_3888 = CDR(variable_11);
VECTOR_SET(v1024_820, ((long)2), aux_3888);
}
VECTOR_SET(v1024_820, ((long)1), loc_12);
{
obj_t aux_3892;
aux_3892 = BINT(((long)7));
VECTOR_SET(v1024_820, ((long)0), aux_3892);
}
return v1024_820;
}
}
 else {
{
if(INTEGERP(variable_11)){
switch ((long)CINT(variable_11)){
case ((long)0) : 
case ((long)1) : 
case ((long)2) : 
case ((long)3) : 
{
obj_t v1028_826;
v1028_826 = create_vector(((long)3));
VECTOR_SET(v1028_826, ((long)2), BNIL);
VECTOR_SET(v1028_826, ((long)1), loc_12);
VECTOR_SET(v1028_826, ((long)0), variable_11);
return v1028_826;
}
break;
default: 
case_else1026_823:
{
obj_t v1025_829;
v1025_829 = create_vector(((long)3));
VECTOR_SET(v1025_829, ((long)2), variable_11);
VECTOR_SET(v1025_829, ((long)1), loc_12);
{
obj_t aux_3904;
aux_3904 = BINT(((long)4));
VECTOR_SET(v1025_829, ((long)0), aux_3904);
}
return v1025_829;
}
}
}
 else {
goto case_else1026_823;
}
}
}
}
}
}


/* evcompile-set */obj_t evcompile_set_124___evcompile(obj_t variable_13, obj_t value_14, obj_t loc_15)
{
{
bool_t test_3909;
if(VECTORP(variable_13)){
long aux_3912;
aux_3912 = VECTOR_LENGTH(variable_13);
test_3909 = (aux_3912==((long)3));
}
 else {
test_3909 = ((bool_t)0);
}
if(test_3909){
{
obj_t v1029_831;
v1029_831 = create_vector(((long)3));
{
obj_t arg1476_833;
arg1476_833 = MAKE_PAIR(variable_13, value_14);
VECTOR_SET(v1029_831, ((long)2), arg1476_833);
}
VECTOR_SET(v1029_831, ((long)1), loc_15);
{
obj_t aux_3919;
aux_3919 = BINT(((long)8));
VECTOR_SET(v1029_831, ((long)0), aux_3919);
}
return v1029_831;
}
}
 else {
bool_t test_3922;
if(PAIRP(variable_13)){
obj_t aux_3925;
aux_3925 = CAR(variable_13);
test_3922 = (aux_3925==symbol1998___evcompile);
}
 else {
test_3922 = ((bool_t)0);
}
if(test_3922){
{
obj_t v1030_835;
v1030_835 = create_vector(((long)3));
{
obj_t arg1479_837;
{
obj_t aux_3929;
aux_3929 = CDR(variable_13);
arg1479_837 = MAKE_PAIR(aux_3929, value_14);
}
VECTOR_SET(v1030_835, ((long)2), arg1479_837);
}
VECTOR_SET(v1030_835, ((long)1), loc_15);
{
obj_t aux_3934;
aux_3934 = BINT(((long)9));
VECTOR_SET(v1030_835, ((long)0), aux_3934);
}
return v1030_835;
}
}
 else {
{
if(INTEGERP(variable_13)){
switch ((long)CINT(variable_13)){
case ((long)0) : 
case ((long)1) : 
case ((long)2) : 
case ((long)3) : 
{
obj_t v1034_842;
v1034_842 = create_vector(((long)3));
VECTOR_SET(v1034_842, ((long)2), value_14);
VECTOR_SET(v1034_842, ((long)1), loc_15);
{
obj_t aux_3942;
{
long aux_3943;
{
long aux_3944;
aux_3944 = (long)CINT(variable_13);
aux_3943 = (((long)10)+aux_3944);
}
aux_3942 = BINT(aux_3943);
}
VECTOR_SET(v1034_842, ((long)0), aux_3942);
}
return v1034_842;
}
break;
default: 
case_else1032_839:
{
obj_t v1031_845;
v1031_845 = create_vector(((long)3));
{
obj_t arg1486_847;
arg1486_847 = MAKE_PAIR(variable_13, value_14);
VECTOR_SET(v1031_845, ((long)2), arg1486_847);
}
VECTOR_SET(v1031_845, ((long)1), loc_15);
{
obj_t aux_3953;
aux_3953 = BINT(((long)14));
VECTOR_SET(v1031_845, ((long)0), aux_3953);
}
return v1031_845;
}
}
}
 else {
goto case_else1032_839;
}
}
}
}
}
}


/* evcompile-begin */obj_t evcompile_begin_220___evcompile(obj_t body_20, obj_t env_21, obj_t genv_22, obj_t where_23, obj_t named__252_24, obj_t loc_25)
{
if(NULLP(body_20)){
return evcompile___evcompile(BUNSPEC, env_21, genv_22, where_23, named__252_24, loc_25);
}
 else {
bool_t test_3961;
{
obj_t aux_3962;
aux_3962 = CDR(body_20);
test_3961 = NULLP(aux_3962);
}
if(test_3961){
{
obj_t arg1491_854;
obj_t arg1494_855;
arg1491_854 = CAR(body_20);
{
obj_t arg1496_856;
arg1496_856 = CAR(body_20);
{
bool_t test1099_2225;
test1099_2225 = EXTENDED_PAIRP(arg1496_856);
if(test1099_2225){
bool_t test1924_2228;
test1924_2228 = EXTENDED_PAIRP(arg1496_856);
if(test1924_2228){
arg1494_855 = CER(arg1496_856);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,arg1496_856);}
}
 else {
arg1494_855 = loc_25;
}
}
}
return evcompile___evcompile(arg1491_854, env_21, genv_22, where_23, named__252_24, arg1494_855);
}
}
 else {
{
obj_t cbody_857;
cbody_857 = loop___evcompile(named__252_24, where_23, genv_22, env_21, loc_25, body_20);
{
obj_t v1037_858;
v1037_858 = create_vector(((long)3));
{
obj_t arg1498_860;
arg1498_860 = list__vector_101___r4_vectors_6_8(cbody_857);
VECTOR_SET(v1037_858, ((long)2), arg1498_860);
}
VECTOR_SET(v1037_858, ((long)1), loc_25);
{
obj_t aux_3979;
aux_3979 = BINT(((long)16));
VECTOR_SET(v1037_858, ((long)0), aux_3979);
}
return v1037_858;
}
}
}
}
}


/* loop */obj_t loop___evcompile(obj_t named__252_3177, obj_t where_3176, obj_t genv_3175, obj_t env_3174, obj_t loc_3173, obj_t rest_861)
{
if(NULLP(rest_861)){
return BNIL;
}
 else {
bool_t test_3984;
{
obj_t aux_3985;
aux_3985 = CDR(rest_861);
test_3984 = NULLP(aux_3985);
}
if(test_3984){
{
obj_t arg1501_865;
{
obj_t arg1503_867;
obj_t arg1504_868;
arg1503_867 = CAR(rest_861);
{
obj_t arg1505_869;
arg1505_869 = CAR(rest_861);
{
bool_t test1099_2240;
test1099_2240 = EXTENDED_PAIRP(arg1505_869);
if(test1099_2240){
bool_t test1924_2243;
test1924_2243 = EXTENDED_PAIRP(arg1505_869);
if(test1924_2243){
arg1504_868 = CER(arg1505_869);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,arg1505_869);}
}
 else {
arg1504_868 = loc_3173;
}
}
}
arg1501_865 = evcompile___evcompile(arg1503_867, env_3174, genv_3175, where_3176, named__252_3177, arg1504_868);
}
return MAKE_PAIR(arg1501_865, BNIL);
}
}
 else {
{
obj_t arg1507_870;
obj_t arg1510_871;
{
obj_t arg1511_872;
obj_t arg1513_873;
arg1511_872 = CAR(rest_861);
{
obj_t arg1514_874;
arg1514_874 = CAR(rest_861);
{
bool_t test1099_2254;
test1099_2254 = EXTENDED_PAIRP(arg1514_874);
if(test1099_2254){
bool_t test1924_2257;
test1924_2257 = EXTENDED_PAIRP(arg1514_874);
if(test1924_2257){
arg1513_873 = CER(arg1514_874);
}
 else {
FAILURE(string1980___evcompile,string1981___evcompile,arg1514_874);}
}
 else {
arg1513_873 = loc_3173;
}
}
}
arg1507_870 = evcompile___evcompile(arg1511_872, env_3174, genv_3175, where_3176, BFALSE, arg1513_873);
}
arg1510_871 = loop___evcompile(named__252_3177, where_3176, genv_3175, env_3174, loc_3173, CDR(rest_861));
return MAKE_PAIR(arg1507_870, arg1510_871);
}
}
}
}


/* evcompile-lambda */obj_t evcompile_lambda_39___evcompile(obj_t formals_37, obj_t body_38, obj_t where_39, obj_t named__252_40, obj_t loc_41)
{
{
if((formals_37==BNIL)){
tag_2326_119_888:
if(CBOOL(named__252_40)){
obj_t v1042_944;
v1042_944 = create_vector(((long)3));
{
obj_t arg1584_946;
arg1584_946 = MAKE_PAIR(where_39, body_38);
VECTOR_SET(v1042_944, ((long)2), arg1584_946);
}
VECTOR_SET(v1042_944, ((long)1), loc_41);
{
obj_t aux_4018;
{
long aux_4019;
{
long aux_4020;
aux_4020 = list_length(formals_37);
aux_4019 = (aux_4020+((long)37));
}
aux_4018 = BINT(aux_4019);
}
VECTOR_SET(v1042_944, ((long)0), aux_4018);
}
return v1042_944;
}
 else {
obj_t v1043_951;
v1043_951 = create_vector(((long)3));
VECTOR_SET(v1043_951, ((long)2), body_38);
VECTOR_SET(v1043_951, ((long)1), loc_41);
{
obj_t aux_4028;
{
long aux_4029;
{
long aux_4030;
aux_4030 = list_length(formals_37);
aux_4029 = (aux_4030+((long)42));
}
aux_4028 = BINT(aux_4029);
}
VECTOR_SET(v1043_951, ((long)0), aux_4028);
}
return v1043_951;
}
}
 else {
if(PAIRP(formals_37)){
bool_t test_4037;
{
obj_t aux_4038;
aux_4038 = CDR(formals_37);
test_4037 = (aux_4038==BNIL);
}
if(test_4037){
goto tag_2326_119_888;
}
 else {
obj_t cdr_2339_122_898;
cdr_2339_122_898 = CDR(formals_37);
if(PAIRP(cdr_2339_122_898)){
bool_t test_4044;
{
obj_t aux_4045;
aux_4045 = CDR(cdr_2339_122_898);
test_4044 = (aux_4045==BNIL);
}
if(test_4044){
goto tag_2326_119_888;
}
 else {
obj_t cdr_2346_51_901;
cdr_2346_51_901 = CDR(cdr_2339_122_898);
if(PAIRP(cdr_2346_51_901)){
bool_t test_4051;
{
obj_t aux_4052;
aux_4052 = CDR(cdr_2346_51_901);
test_4051 = (aux_4052==BNIL);
}
if(test_4051){
goto tag_2326_119_888;
}
 else {
obj_t cdr_2354_52_904;
cdr_2354_52_904 = CDR(cdr_2346_51_901);
if(PAIRP(cdr_2354_52_904)){
bool_t test_4058;
{
obj_t aux_4059;
aux_4059 = CDR(cdr_2354_52_904);
test_4058 = (aux_4059==BNIL);
}
if(test_4058){
goto tag_2326_119_888;
}
 else {
bool_t test_4062;
{
obj_t aux_4063;
aux_4063 = CAR(formals_37);
test_4062 = PAIRP(aux_4063);
}
if(test_4062){
tag_2331_135_893:
if(CBOOL(named__252_40)){
obj_t v1052_972;
v1052_972 = create_vector(((long)3));
{
obj_t arg1609_974;
{
obj_t v1053_975;
v1053_975 = create_vector(((long)3));
VECTOR_SET(v1053_975, ((long)2), formals_37);
VECTOR_SET(v1053_975, ((long)1), body_38);
VECTOR_SET(v1053_975, ((long)0), where_39);
arg1609_974 = v1053_975;
}
VECTOR_SET(v1052_972, ((long)2), arg1609_974);
}
VECTOR_SET(v1052_972, ((long)1), loc_41);
{
obj_t aux_4075;
aux_4075 = BINT(((long)55));
VECTOR_SET(v1052_972, ((long)0), aux_4075);
}
return v1052_972;
}
 else {
obj_t v1054_976;
v1054_976 = create_vector(((long)3));
{
obj_t arg1612_978;
arg1612_978 = MAKE_PAIR(body_38, formals_37);
VECTOR_SET(v1054_976, ((long)2), arg1612_978);
}
VECTOR_SET(v1054_976, ((long)1), loc_41);
{
obj_t aux_4082;
aux_4082 = BINT(((long)56));
VECTOR_SET(v1054_976, ((long)0), aux_4082);
}
return v1054_976;
}
}
 else {
bool_t test_4085;
{
obj_t aux_4086;
aux_4086 = CAR(cdr_2339_122_898);
test_4085 = PAIRP(aux_4086);
}
if(test_4085){
goto tag_2331_135_893;
}
 else {
bool_t test_4089;
{
obj_t aux_4090;
aux_4090 = CAR(cdr_2346_51_901);
test_4089 = PAIRP(aux_4090);
}
if(test_4089){
goto tag_2331_135_893;
}
 else {
goto tag_2331_135_893;
}
}
}
}
}
 else {
bool_t test_4093;
{
obj_t aux_4094;
aux_4094 = CAR(formals_37);
test_4093 = PAIRP(aux_4094);
}
if(test_4093){
goto tag_2331_135_893;
}
 else {
bool_t test_4097;
{
obj_t aux_4098;
aux_4098 = CAR(cdr_2339_122_898);
test_4097 = PAIRP(aux_4098);
}
if(test_4097){
goto tag_2331_135_893;
}
 else {
bool_t test_4101;
{
obj_t aux_4102;
aux_4102 = CAR(cdr_2346_51_901);
test_4101 = PAIRP(aux_4102);
}
if(test_4101){
goto tag_2331_135_893;
}
 else {
if(CBOOL(named__252_40)){
obj_t v1050_968;
v1050_968 = create_vector(((long)3));
{
obj_t arg1607_970;
arg1607_970 = MAKE_PAIR(where_39, body_38);
VECTOR_SET(v1050_968, ((long)2), arg1607_970);
}
VECTOR_SET(v1050_968, ((long)1), loc_41);
{
obj_t aux_4111;
aux_4111 = BINT(((long)50));
VECTOR_SET(v1050_968, ((long)0), aux_4111);
}
return v1050_968;
}
 else {
obj_t v1051_971;
v1051_971 = create_vector(((long)3));
VECTOR_SET(v1051_971, ((long)2), body_38);
VECTOR_SET(v1051_971, ((long)1), loc_41);
{
obj_t aux_4117;
aux_4117 = BINT(((long)54));
VECTOR_SET(v1051_971, ((long)0), aux_4117);
}
return v1051_971;
}
}
}
}
}
}
}
 else {
bool_t test_4120;
{
obj_t aux_4121;
aux_4121 = CAR(formals_37);
test_4120 = PAIRP(aux_4121);
}
if(test_4120){
goto tag_2331_135_893;
}
 else {
bool_t test_4124;
{
obj_t aux_4125;
aux_4125 = CAR(cdr_2339_122_898);
test_4124 = PAIRP(aux_4125);
}
if(test_4124){
goto tag_2331_135_893;
}
 else {
if(CBOOL(named__252_40)){
obj_t v1048_964;
v1048_964 = create_vector(((long)3));
{
obj_t arg1605_966;
arg1605_966 = MAKE_PAIR(where_39, body_38);
VECTOR_SET(v1048_964, ((long)2), arg1605_966);
}
VECTOR_SET(v1048_964, ((long)1), loc_41);
{
obj_t aux_4134;
aux_4134 = BINT(((long)49));
VECTOR_SET(v1048_964, ((long)0), aux_4134);
}
return v1048_964;
}
 else {
obj_t v1049_967;
v1049_967 = create_vector(((long)3));
VECTOR_SET(v1049_967, ((long)2), body_38);
VECTOR_SET(v1049_967, ((long)1), loc_41);
{
obj_t aux_4140;
aux_4140 = BINT(((long)53));
VECTOR_SET(v1049_967, ((long)0), aux_4140);
}
return v1049_967;
}
}
}
}
}
}
 else {
bool_t test_4143;
{
obj_t aux_4144;
aux_4144 = CAR(formals_37);
test_4143 = PAIRP(aux_4144);
}
if(test_4143){
goto tag_2331_135_893;
}
 else {
if(CBOOL(named__252_40)){
obj_t v1046_960;
v1046_960 = create_vector(((long)3));
{
obj_t arg1602_962;
arg1602_962 = MAKE_PAIR(where_39, body_38);
VECTOR_SET(v1046_960, ((long)2), arg1602_962);
}
VECTOR_SET(v1046_960, ((long)1), loc_41);
{
obj_t aux_4153;
aux_4153 = BINT(((long)48));
VECTOR_SET(v1046_960, ((long)0), aux_4153);
}
return v1046_960;
}
 else {
obj_t v1047_963;
v1047_963 = create_vector(((long)3));
VECTOR_SET(v1047_963, ((long)2), body_38);
VECTOR_SET(v1047_963, ((long)1), loc_41);
{
obj_t aux_4159;
aux_4159 = BINT(((long)52));
VECTOR_SET(v1047_963, ((long)0), aux_4159);
}
return v1047_963;
}
}
}
}
}
 else {
if(CBOOL(named__252_40)){
obj_t v1044_956;
v1044_956 = create_vector(((long)3));
{
obj_t arg1598_958;
arg1598_958 = MAKE_PAIR(where_39, body_38);
VECTOR_SET(v1044_956, ((long)2), arg1598_958);
}
VECTOR_SET(v1044_956, ((long)1), loc_41);
{
obj_t aux_4168;
aux_4168 = BINT(((long)47));
VECTOR_SET(v1044_956, ((long)0), aux_4168);
}
return v1044_956;
}
 else {
obj_t v1045_959;
v1045_959 = create_vector(((long)3));
VECTOR_SET(v1045_959, ((long)2), body_38);
VECTOR_SET(v1045_959, ((long)1), loc_41);
{
obj_t aux_4174;
aux_4174 = BINT(((long)51));
VECTOR_SET(v1045_959, ((long)0), aux_4174);
}
return v1045_959;
}
}
}
}
}


/* evcompile-global-application */obj_t evcompile_global_application_156___evcompile(obj_t proc_42, obj_t actuals_43, obj_t loc_44)
{
{
switch (list_length(actuals_43)){
case ((long)0) : 
{
obj_t v1059_982;
v1059_982 = create_vector(((long)3));
{
obj_t arg1617_984;
{
obj_t v1060_985;
v1060_985 = create_vector(((long)2));
VECTOR_SET(v1060_985, ((long)1), proc_42);
{
obj_t aux_4180;
aux_4180 = VECTOR_REF(proc_42, ((long)1));
VECTOR_SET(v1060_985, ((long)0), aux_4180);
}
arg1617_984 = v1060_985;
}
VECTOR_SET(v1059_982, ((long)2), arg1617_984);
}
VECTOR_SET(v1059_982, ((long)1), loc_44);
{
obj_t aux_4185;
{
long aux_4186;
{
bool_t test_4187;
{
obj_t aux_4190;
obj_t aux_4188;
aux_4190 = BINT(((long)1));
aux_4188 = VECTOR_REF(proc_42, ((long)0));
test_4187 = (aux_4188==aux_4190);
}
if(test_4187){
aux_4186 = ((long)19);
}
 else {
aux_4186 = ((long)57);
}
}
aux_4185 = BINT(aux_4186);
}
VECTOR_SET(v1059_982, ((long)0), aux_4185);
}
return v1059_982;
}
break;
case ((long)1) : 
{
obj_t v1061_993;
v1061_993 = create_vector(((long)3));
{
obj_t arg1628_995;
{
obj_t v1062_996;
v1062_996 = create_vector(((long)3));
{
obj_t aux_4197;
aux_4197 = CAR(actuals_43);
VECTOR_SET(v1062_996, ((long)2), aux_4197);
}
VECTOR_SET(v1062_996, ((long)1), proc_42);
{
obj_t aux_4201;
aux_4201 = VECTOR_REF(proc_42, ((long)1));
VECTOR_SET(v1062_996, ((long)0), aux_4201);
}
arg1628_995 = v1062_996;
}
VECTOR_SET(v1061_993, ((long)2), arg1628_995);
}
VECTOR_SET(v1061_993, ((long)1), loc_44);
{
obj_t aux_4206;
{
long aux_4207;
{
bool_t test_4208;
{
obj_t aux_4211;
obj_t aux_4209;
aux_4211 = BINT(((long)1));
aux_4209 = VECTOR_REF(proc_42, ((long)0));
test_4208 = (aux_4209==aux_4211);
}
if(test_4208){
aux_4207 = ((long)20);
}
 else {
aux_4207 = ((long)58);
}
}
aux_4206 = BINT(aux_4207);
}
VECTOR_SET(v1061_993, ((long)0), aux_4206);
}
return v1061_993;
}
break;
case ((long)2) : 
{
obj_t v1063_1006;
v1063_1006 = create_vector(((long)3));
{
obj_t arg1646_1008;
{
obj_t v1064_1009;
v1064_1009 = create_vector(((long)4));
{
obj_t aux_4218;
{
obj_t aux_4219;
aux_4219 = CDR(actuals_43);
aux_4218 = CAR(aux_4219);
}
VECTOR_SET(v1064_1009, ((long)3), aux_4218);
}
{
obj_t aux_4223;
aux_4223 = CAR(actuals_43);
VECTOR_SET(v1064_1009, ((long)2), aux_4223);
}
VECTOR_SET(v1064_1009, ((long)1), proc_42);
{
obj_t aux_4227;
aux_4227 = VECTOR_REF(proc_42, ((long)1));
VECTOR_SET(v1064_1009, ((long)0), aux_4227);
}
arg1646_1008 = v1064_1009;
}
VECTOR_SET(v1063_1006, ((long)2), arg1646_1008);
}
VECTOR_SET(v1063_1006, ((long)1), loc_44);
{
obj_t aux_4232;
{
long aux_4233;
{
bool_t test_4234;
{
obj_t aux_4237;
obj_t aux_4235;
aux_4237 = BINT(((long)1));
aux_4235 = VECTOR_REF(proc_42, ((long)0));
test_4234 = (aux_4235==aux_4237);
}
if(test_4234){
aux_4233 = ((long)21);
}
 else {
aux_4233 = ((long)59);
}
}
aux_4232 = BINT(aux_4233);
}
VECTOR_SET(v1063_1006, ((long)0), aux_4232);
}
return v1063_1006;
}
break;
case ((long)3) : 
{
obj_t v1065_1021;
v1065_1021 = create_vector(((long)3));
{
obj_t arg1661_1023;
{
obj_t v1066_1024;
v1066_1024 = create_vector(((long)5));
{
obj_t aux_4244;
{
obj_t aux_4245;
{
obj_t aux_4246;
aux_4246 = CDR(actuals_43);
aux_4245 = CDR(aux_4246);
}
aux_4244 = CAR(aux_4245);
}
VECTOR_SET(v1066_1024, ((long)4), aux_4244);
}
{
obj_t aux_4251;
{
obj_t aux_4252;
aux_4252 = CDR(actuals_43);
aux_4251 = CAR(aux_4252);
}
VECTOR_SET(v1066_1024, ((long)3), aux_4251);
}
{
obj_t aux_4256;
aux_4256 = CAR(actuals_43);
VECTOR_SET(v1066_1024, ((long)2), aux_4256);
}
VECTOR_SET(v1066_1024, ((long)1), proc_42);
{
obj_t aux_4260;
aux_4260 = VECTOR_REF(proc_42, ((long)1));
VECTOR_SET(v1066_1024, ((long)0), aux_4260);
}
arg1661_1023 = v1066_1024;
}
VECTOR_SET(v1065_1021, ((long)2), arg1661_1023);
}
VECTOR_SET(v1065_1021, ((long)1), loc_44);
{
obj_t aux_4265;
{
long aux_4266;
{
bool_t test_4267;
{
obj_t aux_4270;
obj_t aux_4268;
aux_4270 = BINT(((long)1));
aux_4268 = VECTOR_REF(proc_42, ((long)0));
test_4267 = (aux_4268==aux_4270);
}
if(test_4267){
aux_4266 = ((long)22);
}
 else {
aux_4266 = ((long)60);
}
}
aux_4265 = BINT(aux_4266);
}
VECTOR_SET(v1065_1021, ((long)0), aux_4265);
}
return v1065_1021;
}
break;
case ((long)4) : 
{
obj_t v1067_1038;
v1067_1038 = create_vector(((long)3));
{
obj_t arg1680_1040;
{
obj_t v1068_1041;
v1068_1041 = create_vector(((long)6));
{
obj_t aux_4277;
{
obj_t aux_4278;
{
obj_t aux_4279;
{
obj_t aux_4280;
aux_4280 = CDR(actuals_43);
aux_4279 = CDR(aux_4280);
}
aux_4278 = CDR(aux_4279);
}
aux_4277 = CAR(aux_4278);
}
VECTOR_SET(v1068_1041, ((long)5), aux_4277);
}
{
obj_t aux_4286;
{
obj_t aux_4287;
{
obj_t aux_4288;
aux_4288 = CDR(actuals_43);
aux_4287 = CDR(aux_4288);
}
aux_4286 = CAR(aux_4287);
}
VECTOR_SET(v1068_1041, ((long)4), aux_4286);
}
{
obj_t aux_4293;
{
obj_t aux_4294;
aux_4294 = CDR(actuals_43);
aux_4293 = CAR(aux_4294);
}
VECTOR_SET(v1068_1041, ((long)3), aux_4293);
}
{
obj_t aux_4298;
aux_4298 = CAR(actuals_43);
VECTOR_SET(v1068_1041, ((long)2), aux_4298);
}
VECTOR_SET(v1068_1041, ((long)1), proc_42);
{
obj_t aux_4302;
aux_4302 = VECTOR_REF(proc_42, ((long)1));
VECTOR_SET(v1068_1041, ((long)0), aux_4302);
}
arg1680_1040 = v1068_1041;
}
VECTOR_SET(v1067_1038, ((long)2), arg1680_1040);
}
VECTOR_SET(v1067_1038, ((long)1), loc_44);
{
obj_t aux_4307;
{
long aux_4308;
{
bool_t test_4309;
{
obj_t aux_4312;
obj_t aux_4310;
aux_4312 = BINT(((long)1));
aux_4310 = VECTOR_REF(proc_42, ((long)0));
test_4309 = (aux_4310==aux_4312);
}
if(test_4309){
aux_4308 = ((long)23);
}
 else {
aux_4308 = ((long)61);
}
}
aux_4307 = BINT(aux_4308);
}
VECTOR_SET(v1067_1038, ((long)0), aux_4307);
}
return v1067_1038;
}
break;
default: 
{
obj_t v1055_1057;
v1055_1057 = create_vector(((long)3));
{
obj_t arg1700_1059;
{
obj_t v1056_1060;
v1056_1060 = create_vector(((long)3));
VECTOR_SET(v1056_1060, ((long)2), actuals_43);
VECTOR_SET(v1056_1060, ((long)1), proc_42);
{
obj_t aux_4321;
aux_4321 = VECTOR_REF(proc_42, ((long)1));
VECTOR_SET(v1056_1060, ((long)0), aux_4321);
}
arg1700_1059 = v1056_1060;
}
VECTOR_SET(v1055_1057, ((long)2), arg1700_1059);
}
VECTOR_SET(v1055_1057, ((long)1), loc_44);
{
obj_t aux_4326;
{
long aux_4327;
{
bool_t test_4328;
{
obj_t aux_4331;
obj_t aux_4329;
aux_4331 = BINT(((long)1));
aux_4329 = VECTOR_REF(proc_42, ((long)0));
test_4328 = (aux_4329==aux_4331);
}
if(test_4328){
aux_4327 = ((long)24);
}
 else {
aux_4327 = ((long)62);
}
}
aux_4326 = BINT(aux_4327);
}
VECTOR_SET(v1055_1057, ((long)0), aux_4326);
}
return v1055_1057;
}
}
}
}


/* evcompile-compiled-application */obj_t evcompile_compiled_application_76___evcompile(obj_t proc_45, obj_t actuals_46, obj_t loc_47)
{
{
switch (list_length(actuals_46)){
case ((long)0) : 
{
obj_t v1072_1071;
v1072_1071 = create_vector(((long)3));
VECTOR_SET(v1072_1071, ((long)2), proc_45);
VECTOR_SET(v1072_1071, ((long)1), loc_47);
{
obj_t aux_4341;
aux_4341 = BINT(((long)25));
VECTOR_SET(v1072_1071, ((long)0), aux_4341);
}
return v1072_1071;
}
break;
case ((long)1) : 
{
obj_t v1073_1072;
v1073_1072 = create_vector(((long)3));
{
obj_t arg1710_1074;
{
obj_t v1074_1075;
v1074_1075 = create_vector(((long)2));
{
obj_t aux_4346;
aux_4346 = CAR(actuals_46);
VECTOR_SET(v1074_1075, ((long)1), aux_4346);
}
VECTOR_SET(v1074_1075, ((long)0), proc_45);
arg1710_1074 = v1074_1075;
}
VECTOR_SET(v1073_1072, ((long)2), arg1710_1074);
}
VECTOR_SET(v1073_1072, ((long)1), loc_47);
{
obj_t aux_4352;
aux_4352 = BINT(((long)26));
VECTOR_SET(v1073_1072, ((long)0), aux_4352);
}
return v1073_1072;
}
break;
case ((long)2) : 
{
obj_t v1075_1078;
v1075_1078 = create_vector(((long)3));
{
obj_t arg1714_1080;
{
obj_t v1076_1081;
v1076_1081 = create_vector(((long)3));
{
obj_t aux_4357;
{
obj_t aux_4358;
aux_4358 = CDR(actuals_46);
aux_4357 = CAR(aux_4358);
}
VECTOR_SET(v1076_1081, ((long)2), aux_4357);
}
{
obj_t aux_4362;
aux_4362 = CAR(actuals_46);
VECTOR_SET(v1076_1081, ((long)1), aux_4362);
}
VECTOR_SET(v1076_1081, ((long)0), proc_45);
arg1714_1080 = v1076_1081;
}
VECTOR_SET(v1075_1078, ((long)2), arg1714_1080);
}
VECTOR_SET(v1075_1078, ((long)1), loc_47);
{
obj_t aux_4368;
aux_4368 = BINT(((long)27));
VECTOR_SET(v1075_1078, ((long)0), aux_4368);
}
return v1075_1078;
}
break;
case ((long)3) : 
{
obj_t v1077_1086;
v1077_1086 = create_vector(((long)3));
{
obj_t arg1722_1088;
{
obj_t v1078_1089;
v1078_1089 = create_vector(((long)4));
{
obj_t aux_4373;
{
obj_t aux_4374;
{
obj_t aux_4375;
aux_4375 = CDR(actuals_46);
aux_4374 = CDR(aux_4375);
}
aux_4373 = CAR(aux_4374);
}
VECTOR_SET(v1078_1089, ((long)3), aux_4373);
}
{
obj_t aux_4380;
{
obj_t aux_4381;
aux_4381 = CDR(actuals_46);
aux_4380 = CAR(aux_4381);
}
VECTOR_SET(v1078_1089, ((long)2), aux_4380);
}
{
obj_t aux_4385;
aux_4385 = CAR(actuals_46);
VECTOR_SET(v1078_1089, ((long)1), aux_4385);
}
VECTOR_SET(v1078_1089, ((long)0), proc_45);
arg1722_1088 = v1078_1089;
}
VECTOR_SET(v1077_1086, ((long)2), arg1722_1088);
}
VECTOR_SET(v1077_1086, ((long)1), loc_47);
{
obj_t aux_4391;
aux_4391 = BINT(((long)28));
VECTOR_SET(v1077_1086, ((long)0), aux_4391);
}
return v1077_1086;
}
break;
case ((long)4) : 
{
obj_t v1079_1096;
v1079_1096 = create_vector(((long)3));
{
obj_t arg1730_1098;
{
obj_t v1080_1099;
v1080_1099 = create_vector(((long)5));
{
obj_t aux_4396;
{
obj_t aux_4397;
{
obj_t aux_4398;
{
obj_t aux_4399;
aux_4399 = CDR(actuals_46);
aux_4398 = CDR(aux_4399);
}
aux_4397 = CDR(aux_4398);
}
aux_4396 = CAR(aux_4397);
}
VECTOR_SET(v1080_1099, ((long)4), aux_4396);
}
{
obj_t aux_4405;
{
obj_t aux_4406;
{
obj_t aux_4407;
aux_4407 = CDR(actuals_46);
aux_4406 = CDR(aux_4407);
}
aux_4405 = CAR(aux_4406);
}
VECTOR_SET(v1080_1099, ((long)3), aux_4405);
}
{
obj_t aux_4412;
{
obj_t aux_4413;
aux_4413 = CDR(actuals_46);
aux_4412 = CAR(aux_4413);
}
VECTOR_SET(v1080_1099, ((long)2), aux_4412);
}
{
obj_t aux_4417;
aux_4417 = CAR(actuals_46);
VECTOR_SET(v1080_1099, ((long)1), aux_4417);
}
VECTOR_SET(v1080_1099, ((long)0), proc_45);
arg1730_1098 = v1080_1099;
}
VECTOR_SET(v1079_1096, ((long)2), arg1730_1098);
}
VECTOR_SET(v1079_1096, ((long)1), loc_47);
{
obj_t aux_4423;
aux_4423 = BINT(((long)29));
VECTOR_SET(v1079_1096, ((long)0), aux_4423);
}
return v1079_1096;
}
break;
default: 
{
obj_t v1069_1108;
v1069_1108 = create_vector(((long)3));
{
obj_t arg1746_1110;
arg1746_1110 = MAKE_PAIR(proc_45, actuals_46);
VECTOR_SET(v1069_1108, ((long)2), arg1746_1110);
}
VECTOR_SET(v1069_1108, ((long)1), loc_47);
{
obj_t aux_4430;
aux_4430 = BINT(((long)30));
VECTOR_SET(v1069_1108, ((long)0), aux_4430);
}
return v1069_1108;
}
}
}
}


/* evcompile-application */obj_t evcompile_application_224___evcompile(obj_t name_48, obj_t proc_49, obj_t actuals_50, obj_t loc_51)
{
{
switch (list_length(actuals_50)){
case ((long)0) : 
{
obj_t v1085_1114;
v1085_1114 = create_vector(((long)3));
{
obj_t arg1749_1116;
arg1749_1116 = MAKE_PAIR(name_48, proc_49);
VECTOR_SET(v1085_1114, ((long)2), arg1749_1116);
}
VECTOR_SET(v1085_1114, ((long)1), loc_51);
{
obj_t aux_4439;
aux_4439 = BINT(((long)31));
VECTOR_SET(v1085_1114, ((long)0), aux_4439);
}
return v1085_1114;
}
break;
case ((long)1) : 
{
obj_t v1086_1117;
v1086_1117 = create_vector(((long)3));
{
obj_t arg1755_1119;
{
obj_t v1087_1120;
v1087_1120 = create_vector(((long)3));
{
obj_t aux_4444;
aux_4444 = CAR(actuals_50);
VECTOR_SET(v1087_1120, ((long)2), aux_4444);
}
VECTOR_SET(v1087_1120, ((long)1), proc_49);
VECTOR_SET(v1087_1120, ((long)0), name_48);
arg1755_1119 = v1087_1120;
}
VECTOR_SET(v1086_1117, ((long)2), arg1755_1119);
}
VECTOR_SET(v1086_1117, ((long)1), loc_51);
{
obj_t aux_4451;
aux_4451 = BINT(((long)32));
VECTOR_SET(v1086_1117, ((long)0), aux_4451);
}
return v1086_1117;
}
break;
case ((long)2) : 
{
obj_t v1088_1123;
v1088_1123 = create_vector(((long)3));
{
obj_t arg1761_1125;
{
obj_t v1089_1126;
v1089_1126 = create_vector(((long)4));
{
obj_t aux_4456;
{
obj_t aux_4457;
aux_4457 = CDR(actuals_50);
aux_4456 = CAR(aux_4457);
}
VECTOR_SET(v1089_1126, ((long)3), aux_4456);
}
{
obj_t aux_4461;
aux_4461 = CAR(actuals_50);
VECTOR_SET(v1089_1126, ((long)2), aux_4461);
}
VECTOR_SET(v1089_1126, ((long)1), proc_49);
VECTOR_SET(v1089_1126, ((long)0), name_48);
arg1761_1125 = v1089_1126;
}
VECTOR_SET(v1088_1123, ((long)2), arg1761_1125);
}
VECTOR_SET(v1088_1123, ((long)1), loc_51);
{
obj_t aux_4468;
aux_4468 = BINT(((long)33));
VECTOR_SET(v1088_1123, ((long)0), aux_4468);
}
return v1088_1123;
}
break;
case ((long)3) : 
{
obj_t v1090_1131;
v1090_1131 = create_vector(((long)3));
{
obj_t arg1769_1133;
{
obj_t v1091_1134;
v1091_1134 = create_vector(((long)5));
{
obj_t aux_4473;
{
obj_t aux_4474;
{
obj_t aux_4475;
aux_4475 = CDR(actuals_50);
aux_4474 = CDR(aux_4475);
}
aux_4473 = CAR(aux_4474);
}
VECTOR_SET(v1091_1134, ((long)4), aux_4473);
}
{
obj_t aux_4480;
{
obj_t aux_4481;
aux_4481 = CDR(actuals_50);
aux_4480 = CAR(aux_4481);
}
VECTOR_SET(v1091_1134, ((long)3), aux_4480);
}
{
obj_t aux_4485;
aux_4485 = CAR(actuals_50);
VECTOR_SET(v1091_1134, ((long)2), aux_4485);
}
VECTOR_SET(v1091_1134, ((long)1), proc_49);
VECTOR_SET(v1091_1134, ((long)0), name_48);
arg1769_1133 = v1091_1134;
}
VECTOR_SET(v1090_1131, ((long)2), arg1769_1133);
}
VECTOR_SET(v1090_1131, ((long)1), loc_51);
{
obj_t aux_4492;
aux_4492 = BINT(((long)34));
VECTOR_SET(v1090_1131, ((long)0), aux_4492);
}
return v1090_1131;
}
break;
case ((long)4) : 
{
obj_t v1092_1141;
v1092_1141 = create_vector(((long)3));
{
obj_t arg1778_1143;
{
obj_t v1093_1144;
v1093_1144 = create_vector(((long)6));
{
obj_t aux_4497;
{
obj_t aux_4498;
{
obj_t aux_4499;
{
obj_t aux_4500;
aux_4500 = CDR(actuals_50);
aux_4499 = CDR(aux_4500);
}
aux_4498 = CDR(aux_4499);
}
aux_4497 = CAR(aux_4498);
}
VECTOR_SET(v1093_1144, ((long)5), aux_4497);
}
{
obj_t aux_4506;
{
obj_t aux_4507;
{
obj_t aux_4508;
aux_4508 = CDR(actuals_50);
aux_4507 = CDR(aux_4508);
}
aux_4506 = CAR(aux_4507);
}
VECTOR_SET(v1093_1144, ((long)4), aux_4506);
}
{
obj_t aux_4513;
{
obj_t aux_4514;
aux_4514 = CDR(actuals_50);
aux_4513 = CAR(aux_4514);
}
VECTOR_SET(v1093_1144, ((long)3), aux_4513);
}
{
obj_t aux_4518;
aux_4518 = CAR(actuals_50);
VECTOR_SET(v1093_1144, ((long)2), aux_4518);
}
VECTOR_SET(v1093_1144, ((long)1), proc_49);
VECTOR_SET(v1093_1144, ((long)0), name_48);
arg1778_1143 = v1093_1144;
}
VECTOR_SET(v1092_1141, ((long)2), arg1778_1143);
}
VECTOR_SET(v1092_1141, ((long)1), loc_51);
{
obj_t aux_4525;
aux_4525 = BINT(((long)35));
VECTOR_SET(v1092_1141, ((long)0), aux_4525);
}
return v1092_1141;
}
break;
default: 
{
obj_t v1081_1153;
v1081_1153 = create_vector(((long)3));
{
obj_t arg1792_1155;
{
obj_t v1082_1156;
v1082_1156 = create_vector(((long)3));
VECTOR_SET(v1082_1156, ((long)2), actuals_50);
VECTOR_SET(v1082_1156, ((long)1), proc_49);
VECTOR_SET(v1082_1156, ((long)0), name_48);
arg1792_1155 = v1082_1156;
}
VECTOR_SET(v1081_1153, ((long)2), arg1792_1155);
}
VECTOR_SET(v1081_1153, ((long)1), loc_51);
{
obj_t aux_4535;
aux_4535 = BINT(((long)36));
VECTOR_SET(v1081_1153, ((long)0), aux_4535);
}
return v1081_1153;
}
}
}
}


/* variable */obj_t variable___evcompile(obj_t loc_52, obj_t symbol_53, obj_t env_54, obj_t genv_55)
{
if(SYMBOLP(symbol_53)){
obj_t offset_1158;
{
obj_t env_3006;
long count_3007;
env_3006 = env_54;
count_3007 = ((long)0);
loop_3005:
if(NULLP(env_3006)){
offset_1158 = BFALSE;
}
 else {
bool_t test_4544;
{
obj_t aux_4545;
aux_4545 = CAR(env_3006);
test_4544 = (aux_4545==symbol_53);
}
if(test_4544){
offset_1158 = BINT(count_3007);
}
 else {
{
long count_4551;
obj_t env_4549;
env_4549 = CDR(env_3006);
count_4551 = (count_3007+((long)1));
count_3007 = count_4551;
env_3006 = env_4549;
goto loop_3005;
}
}
}
}
if(CBOOL(offset_1158)){
return offset_1158;
}
 else {
obj_t global_1159;
{
bool_t test1797_1163;
{
bool_t test1798_1164;
{
obj_t arg1800_1166;
arg1800_1166 = scheme_report_environment_154___eval(BINT(((long)5)));
test1798_1164 = (genv_55==arg1800_1166);
}
if(test1798_1164){
test1797_1163 = ((bool_t)1);
}
 else {
obj_t arg1799_1165;
arg1799_1165 = interaction_environment_31___eval();
test1797_1163 = (genv_55==arg1799_1165);
}
}
if(test1797_1163){
global_1159 = eval_lookup_172___evenv(symbol_53);
}
 else {
global_1159 = evcompile_error_92___evcompile(loc_52, string1982___evcompile, string1999___evcompile, symbol_53);
}
}
if(CBOOL(global_1159)){
return global_1159;
}
 else {
bool_t test1794_1160;
{
obj_t arg1796_1162;
arg1796_1162 = scheme_report_environment_154___eval(BINT(((long)5)));
test1794_1160 = (genv_55==arg1796_1162);
}
if(test1794_1160){
return evcompile_error_92___evcompile(loc_52, string1982___evcompile, string1999___evcompile, symbol_53);
}
 else {
return MAKE_PAIR(symbol1998___evcompile, symbol_53);
}
}
}
}
 else {
return evcompile_error_92___evcompile(loc_52, string1982___evcompile, string2000___evcompile, symbol_53);
}
}


/* _loop_ */obj_t _loop____evcompile(obj_t old_env_160_3172, obj_t extend_1178)
{
if(NULLP(extend_1178)){
return old_env_160_3172;
}
 else {
if(PAIRP(extend_1178)){
{
obj_t arg1810_1182;
obj_t arg1811_1183;
arg1810_1182 = CAR(extend_1178);
arg1811_1183 = _loop____evcompile(old_env_160_3172, CDR(extend_1178));
return MAKE_PAIR(arg1810_1182, arg1811_1183);
}
}
 else {
return MAKE_PAIR(extend_1178, old_env_160_3172);
}
}
}


/* evcompile-error */obj_t evcompile_error_92___evcompile(obj_t loc_60, obj_t proc_61, obj_t mes_62, obj_t obj_63)
{
if(PAIRP(loc_60)){
obj_t cdr_2470_138_1191;
cdr_2470_138_1191 = CDR(loc_60);
{
bool_t test_4585;
{
obj_t aux_4586;
aux_4586 = CAR(loc_60);
test_4585 = (aux_4586==symbol2001___evcompile);
}
if(test_4585){
if(PAIRP(cdr_2470_138_1191)){
obj_t cdr_2474_27_1194;
cdr_2474_27_1194 = CDR(cdr_2470_138_1191);
if(PAIRP(cdr_2474_27_1194)){
bool_t test_4594;
{
obj_t aux_4595;
aux_4595 = CDR(cdr_2474_27_1194);
test_4594 = (aux_4595==BNIL);
}
if(test_4594){
return error_location_112___error(proc_61, mes_62, obj_63, CAR(cdr_2470_138_1191), CAR(cdr_2474_27_1194));
}
 else {
FAILURE(proc_61,mes_62,obj_63);}
}
 else {
FAILURE(proc_61,mes_62,obj_63);}
}
 else {
FAILURE(proc_61,mes_62,obj_63);}
}
 else {
FAILURE(proc_61,mes_62,obj_63);}
}
}
 else {
FAILURE(proc_61,mes_62,obj_63);}
}


/* imported-modules-init */obj_t imported_modules_init_94___evcompile()
{
module_initialization_70___type(((long)0), "__EVCOMPILE");
module_initialization_70___error(((long)0), "__EVCOMPILE");
module_initialization_70___bigloo(((long)0), "__EVCOMPILE");
module_initialization_70___tvector(((long)0), "__EVCOMPILE");
module_initialization_70___structure(((long)0), "__EVCOMPILE");
module_initialization_70___bexit(((long)0), "__EVCOMPILE");
module_initialization_70___os(((long)0), "__EVCOMPILE");
module_initialization_70___dsssl(((long)0), "__EVCOMPILE");
module_initialization_70___r4_numbers_6_5(((long)0), "__EVCOMPILE");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EVCOMPILE");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EVCOMPILE");
module_initialization_70___r4_characters_6_6(((long)0), "__EVCOMPILE");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EVCOMPILE");
module_initialization_70___r4_booleans_6_1(((long)0), "__EVCOMPILE");
module_initialization_70___r4_symbols_6_4(((long)0), "__EVCOMPILE");
module_initialization_70___r4_strings_6_7(((long)0), "__EVCOMPILE");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EVCOMPILE");
module_initialization_70___r4_input_6_10_2(((long)0), "__EVCOMPILE");
module_initialization_70___r4_control_features_6_9(((long)0), "__EVCOMPILE");
module_initialization_70___r4_vectors_6_8(((long)0), "__EVCOMPILE");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EVCOMPILE");
module_initialization_70___r4_output_6_10_3(((long)0), "__EVCOMPILE");
module_initialization_70___evenv(((long)0), "__EVCOMPILE");
module_initialization_70___eval(((long)0), "__EVCOMPILE");
return module_initialization_70___expand(((long)0), "__EVCOMPILE");
}

