/*===========================================================================*/
/*   (Cnst/initialize.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern char *number__string_214___r4_numbers_6_5(obj_t, obj_t);
static obj_t method_init_76_cnst_initialize();
static obj_t read_initialize__67_cnst_initialize();
extern obj_t get_cnst_offset_21_cnst_alloc();
extern obj_t create_struct(obj_t, long);
extern obj_t obj_to_string(obj_t);
static obj_t intern_initialize__196_cnst_initialize();
static obj_t lib_initialize__103_cnst_initialize();
extern obj_t module_initialization_70_cnst_initialize(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_build(long, char *);
extern obj_t module_initialization_70_ast_lvtype(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_cnst_alloc(long, char *);
extern obj_t module_initialization_70_cnst_node(long, char *);
extern obj_t module_initialization_70___intext(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t cnst_set__cnst_string_40_cnst_initialize(obj_t);
static obj_t read_empty_cnst_initialize__140_cnst_initialize();
static obj_t intern_full_cnst_initialize__85_cnst_initialize();
extern obj_t list__vector_101___r4_vectors_6_8(obj_t);
extern obj_t write___r4_output_6_10_3(obj_t, obj_t);
static obj_t imported_modules_init_94_cnst_initialize();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t _initialize_ast_73_cnst_initialize(obj_t);
extern obj_t write_char_165___r4_output_6_10_3(unsigned char, obj_t);
extern node_t coerce__182_coerce_coerce(node_t, type_t);
static obj_t library_modules_init_112_cnst_initialize();
static obj_t toplevel_init_63_cnst_initialize();
extern obj_t build_ast_197_ast_build(obj_t);
extern obj_t open_input_string(obj_t);
static obj_t read_full_cnst_initialize__176_cnst_initialize();
extern obj_t initialize_ast_128_cnst_initialize();
extern obj_t close_output_port(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t get_cnst_sexp_197_cnst_alloc();
extern node_t cnst_alloc_string_41_cnst_alloc(obj_t, obj_t);
extern obj_t _init_mode__183_engine_param;
extern obj_t get_cnst_table_42_cnst_alloc();
extern obj_t open_output_string();
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t get_cnst_set_138_cnst_alloc();
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t intern_empty_cnst_initialize__171_cnst_initialize();
static obj_t require_initialization_114_cnst_initialize = BUNSPEC;
static obj_t cnst_init_137_cnst_initialize();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[28];

DEFINE_EXPORT_PROCEDURE(initialize_ast_env_80_cnst_initialize, _initialize_ast_73_cnst_initialize1974, _initialize_ast_73_cnst_initialize, 0L, 0);
DEFINE_STRING(string1968_cnst_initialize, string1968_cnst_initialize1975, "CNST-TMP C-VECTOR-REF I::INT __INTEXT STRING->OBJ CNST-TMP::VECTOR AUX C--FX AUX::INT CNST-PORT __READER @ CNST-TABLE-SET! BEGIN I C-=FX IF I::LONG LOOP LABELS C-OPEN-INPUT-STRING CNST-PORT::INPUT-PORT LET UNIT CNST INTERN READ LIB ", 232);
DEFINE_STRING(string1967_cnst_initialize, string1967_cnst_initialize1976, "Can't open output string port", 29);
DEFINE_STRING(string1966_cnst_initialize, string1966_cnst_initialize1977, "cnst-set->cnst-string", 21);
DEFINE_STRING(string1965_cnst_initialize, string1965_cnst_initialize1978, "__cnst[ ", 8);
DEFINE_STRING(string1964_cnst_initialize, string1964_cnst_initialize1979, " ] ", 3);
DEFINE_STRING(string1963_cnst_initialize, string1963_cnst_initialize1980, "*__cnst", 7);
DEFINE_STRING(string1962_cnst_initialize, string1962_cnst_initialize1981, "Illegal init-mode", 17);
DEFINE_STRING(string1961_cnst_initialize, string1961_cnst_initialize1982, "intialize-stop!", 15);


/* module-initialization */ obj_t 
module_initialization_70_cnst_initialize(long checksum_1534, char *from_1535)
{
   if (CBOOL(require_initialization_114_cnst_initialize))
     {
	require_initialization_114_cnst_initialize = BBOOL(((bool_t) 0));
	library_modules_init_112_cnst_initialize();
	cnst_init_137_cnst_initialize();
	imported_modules_init_94_cnst_initialize();
	method_init_76_cnst_initialize();
	toplevel_init_63_cnst_initialize();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cnst_initialize()
{
   module_initialization_70___r4_numbers_6_5(((long) 0), "CNST_INITIALIZE");
   module_initialization_70___intext(((long) 0), "CNST_INITIALIZE");
   module_initialization_70___r4_vectors_6_8(((long) 0), "CNST_INITIALIZE");
   module_initialization_70___r4_output_6_10_3(((long) 0), "CNST_INITIALIZE");
   module_initialization_70___r4_strings_6_7(((long) 0), "CNST_INITIALIZE");
   module_initialization_70___reader(((long) 0), "CNST_INITIALIZE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CNST_INITIALIZE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cnst_initialize()
{
   {
      obj_t cnst_port_138_1526;
      cnst_port_138_1526 = open_input_string(string1968_cnst_initialize);
      {
	 long i_1527;
	 i_1527 = ((long) 27);
       loop_1528:
	 {
	    bool_t test1969_1529;
	    test1969_1529 = (i_1527 == ((long) -1));
	    if (test1969_1529)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1970_1530;
		    {
		       obj_t list1971_1531;
		       {
			  obj_t arg1972_1532;
			  arg1972_1532 = BNIL;
			  list1971_1531 = MAKE_PAIR(cnst_port_138_1526, arg1972_1532);
		       }
		       arg1970_1530 = read___reader(list1971_1531);
		    }
		    CNST_TABLE_SET(i_1527, arg1970_1530);
		 }
		 {
		    int aux_1533;
		    {
		       long aux_1557;
		       aux_1557 = (i_1527 - ((long) 1));
		       aux_1533 = (int) (aux_1557);
		    }
		    {
		       long i_1560;
		       i_1560 = (long) (aux_1533);
		       i_1527 = i_1560;
		       goto loop_1528;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cnst_initialize()
{
   return BUNSPEC;
}


/* initialize-ast */ obj_t 
initialize_ast_128_cnst_initialize()
{
   {
      obj_t body_728;
      {
	 obj_t case_value_58_745;
	 case_value_58_745 = _init_mode__183_engine_param;
	 {
	    bool_t test_1562;
	    {
	       obj_t aux_1563;
	       aux_1563 = CNST_TABLE_REF(((long) 0));
	       test_1562 = (case_value_58_745 == aux_1563);
	    }
	    if (test_1562)
	      {
		 body_728 = lib_initialize__103_cnst_initialize();
	      }
	    else
	      {
		 bool_t test_1567;
		 {
		    obj_t aux_1568;
		    aux_1568 = CNST_TABLE_REF(((long) 1));
		    test_1567 = (case_value_58_745 == aux_1568);
		 }
		 if (test_1567)
		   {
		      body_728 = read_initialize__67_cnst_initialize();
		   }
		 else
		   {
		      bool_t test_1572;
		      {
			 obj_t aux_1573;
			 aux_1573 = CNST_TABLE_REF(((long) 2));
			 test_1572 = (case_value_58_745 == aux_1573);
		      }
		      if (test_1572)
			{
			   body_728 = intern_initialize__196_cnst_initialize();
			}
		      else
			{
			   body_728 = internal_error_43_tools_error(string1961_cnst_initialize, string1962_cnst_initialize, _init_mode__183_engine_param);
			}
		   }
	      }
	 }
      }
      if (PAIRP(body_728))
	{
	   obj_t unit_730;
	   {
	      obj_t arg1470_743;
	      arg1470_743 = CNST_TABLE_REF(((long) 3));
	      {
		 obj_t new_1463;
		 {
		    obj_t aux_1581;
		    aux_1581 = CNST_TABLE_REF(((long) 4));
		    new_1463 = create_struct(aux_1581, ((long) 4));
		 }
		 STRUCT_SET(new_1463, ((long) 3), BTRUE);
		 STRUCT_SET(new_1463, ((long) 2), body_728);
		 {
		    obj_t aux_1586;
		    aux_1586 = BINT(((long) 8));
		    STRUCT_SET(new_1463, ((long) 1), aux_1586);
		 }
		 STRUCT_SET(new_1463, ((long) 0), arg1470_743);
		 unit_730 = new_1463;
	      }
	   }
	   {
	      obj_t ast_731;
	      {
		 obj_t arg1467_740;
		 {
		    obj_t list1468_741;
		    list1468_741 = MAKE_PAIR(unit_730, BNIL);
		    arg1467_740 = list1468_741;
		 }
		 ast_731 = build_ast_197_ast_build(arg1467_740);
	      }
	      {
		 obj_t l1435_732;
		 l1435_732 = ast_731;
	       lname1436_733:
		 if (PAIRP(l1435_732))
		   {
		      {
			 obj_t global_735;
			 global_735 = CAR(l1435_732);
			 {
			    type_t aux_1603;
			    node_t aux_1595;
			    {
			       global_t obj_1491;
			       obj_1491 = (global_t) (global_735);
			       aux_1603 = (((global_t) CREF(obj_1491))->type);
			    }
			    {
			       obj_t aux_1596;
			       {
				  sfun_t obj_1490;
				  {
				     value_t aux_1597;
				     {
					global_t obj_1489;
					obj_1489 = (global_t) (global_735);
					aux_1597 = (((global_t) CREF(obj_1489))->value);
				     }
				     obj_1490 = (sfun_t) (aux_1597);
				  }
				  aux_1596 = (((sfun_t) CREF(obj_1490))->body);
			       }
			       aux_1595 = (node_t) (aux_1596);
			    }
			    coerce__182_coerce_coerce(aux_1595, aux_1603);
			 }
		      }
		      {
			 obj_t l1435_1607;
			 l1435_1607 = CDR(l1435_732);
			 l1435_732 = l1435_1607;
			 goto lname1436_733;
		      }
		   }
		 else
		   {
		      ((bool_t) 1);
		   }
	      }
	      return ast_731;
	   }
	}
      else
	{
	   return BNIL;
	}
   }
}


/* _initialize-ast */ obj_t 
_initialize_ast_73_cnst_initialize(obj_t env_1524)
{
   return initialize_ast_128_cnst_initialize();
}


/* lib-initialize! */ obj_t 
lib_initialize__103_cnst_initialize()
{
   {
      obj_t arg1478_752;
      arg1478_752 = get_cnst_table_42_cnst_alloc();
      {
	 global_t obj_1493;
	 obj_t val1066_1494;
	 obj_1493 = (global_t) (arg1478_752);
	 val1066_1494 = string1963_cnst_initialize;
	 ((((global_t) CREF(obj_1493))->name) = ((obj_t) val1066_1494), BUNSPEC);
      }
   }
   return get_cnst_sexp_197_cnst_alloc();
}


/* read-initialize! */ obj_t 
read_initialize__67_cnst_initialize()
{
   {
      bool_t test1480_754;
      {
	 obj_t arg1481_755;
	 arg1481_755 = get_cnst_offset_21_cnst_alloc();
	 {
	    long aux_1615;
	    aux_1615 = (long) CINT(arg1481_755);
	    test1480_754 = (aux_1615 == ((long) 0));
	 }
      }
      if (test1480_754)
	{
	   return read_empty_cnst_initialize__140_cnst_initialize();
	}
      else
	{
	   return read_full_cnst_initialize__176_cnst_initialize();
	}
   }
}


/* read-empty-cnst-initialize! */ obj_t 
read_empty_cnst_initialize__140_cnst_initialize()
{
   {
      obj_t arg1484_757;
      arg1484_757 = get_cnst_table_42_cnst_alloc();
      {
	 global_t obj_1497;
	 obj_t val1066_1498;
	 obj_1497 = (global_t) (arg1484_757);
	 val1066_1498 = string1963_cnst_initialize;
	 ((((global_t) CREF(obj_1497))->name) = ((obj_t) val1066_1498), BUNSPEC);
      }
   }
   return get_cnst_sexp_197_cnst_alloc();
}


/* read-full-cnst-initialize! */ obj_t 
read_full_cnst_initialize__176_cnst_initialize()
{
   {
      obj_t cnst_string_99_773;
      {
	 obj_t arg1486_760;
	 obj_t arg1487_761;
	 arg1486_760 = get_cnst_table_42_cnst_alloc();
	 {
	    char *arg1489_763;
	    {
	       obj_t arg1498_769;
	       arg1498_769 = get_cnst_offset_21_cnst_alloc();
	       arg1489_763 = number__string_214___r4_numbers_6_5(arg1498_769, BNIL);
	    }
	    {
	       obj_t list1491_765;
	       {
		  obj_t arg1494_766;
		  {
		     obj_t arg1496_767;
		     arg1496_767 = MAKE_PAIR(string1964_cnst_initialize, BNIL);
		     {
			obj_t aux_1629;
			aux_1629 = string_to_bstring(arg1489_763);
			arg1494_766 = MAKE_PAIR(aux_1629, arg1496_767);
		     }
		  }
		  list1491_765 = MAKE_PAIR(string1965_cnst_initialize, arg1494_766);
	       }
	       arg1487_761 = string_append_106___r4_strings_6_7(list1491_765);
	    }
	 }
	 {
	    global_t obj_1499;
	    obj_1499 = (global_t) (arg1486_760);
	    ((((global_t) CREF(obj_1499))->name) = ((obj_t) arg1487_761), BUNSPEC);
	 }
      }
      {
	 obj_t cnst_string_99_771;
	 {
	    obj_t arg1500_772;
	    arg1500_772 = get_cnst_set_138_cnst_alloc();
	    cnst_string_99_771 = cnst_set__cnst_string_40_cnst_initialize(arg1500_772);
	 }
	 cnst_string_99_773 = cnst_string_99_771;
	 {
	    node_t var_string_203_775;
	    var_string_203_775 = cnst_alloc_string_41_cnst_alloc(cnst_string_99_773, BFALSE);
	    {
	       obj_t sexp_776;
	       {
		  obj_t arg1503_778;
		  obj_t arg1504_779;
		  obj_t arg1505_780;
		  arg1503_778 = CNST_TABLE_REF(((long) 5));
		  {
		     obj_t arg1514_786;
		     {
			obj_t arg1518_790;
			obj_t arg1519_791;
			arg1518_790 = CNST_TABLE_REF(((long) 6));
			{
			   obj_t arg1526_796;
			   obj_t arg1527_797;
			   arg1526_796 = CNST_TABLE_REF(((long) 7));
			   {
			      global_t obj_1502;
			      {
				 variable_t aux_1642;
				 {
				    var_t obj_1501;
				    obj_1501 = (var_t) (var_string_203_775);
				    aux_1642 = (((var_t) CREF(obj_1501))->variable);
				 }
				 obj_1502 = (global_t) (aux_1642);
			      }
			      arg1527_797 = (((global_t) CREF(obj_1502))->id);
			   }
			   {
			      obj_t list1529_799;
			      {
				 obj_t arg1530_800;
				 arg1530_800 = MAKE_PAIR(BNIL, BNIL);
				 list1529_799 = MAKE_PAIR(arg1527_797, arg1530_800);
			      }
			      arg1519_791 = cons__138___r4_pairs_and_lists_6_3(arg1526_796, list1529_799);
			   }
			}
			{
			   obj_t list1523_793;
			   {
			      obj_t arg1524_794;
			      arg1524_794 = MAKE_PAIR(BNIL, BNIL);
			      list1523_793 = MAKE_PAIR(arg1519_791, arg1524_794);
			   }
			   arg1514_786 = cons__138___r4_pairs_and_lists_6_3(arg1518_790, list1523_793);
			}
		     }
		     {
			obj_t list1516_788;
			list1516_788 = MAKE_PAIR(BNIL, BNIL);
			arg1504_779 = cons__138___r4_pairs_and_lists_6_3(arg1514_786, list1516_788);
		     }
		  }
		  {
		     obj_t arg1533_803;
		     obj_t arg1534_804;
		     obj_t arg1535_805;
		     arg1533_803 = CNST_TABLE_REF(((long) 8));
		     {
			obj_t arg1545_811;
			{
			   obj_t arg1552_815;
			   obj_t arg1553_816;
			   obj_t arg1554_817;
			   arg1552_815 = CNST_TABLE_REF(((long) 9));
			   {
			      obj_t arg1560_823;
			      arg1560_823 = CNST_TABLE_REF(((long) 10));
			      {
				 obj_t list1562_825;
				 list1562_825 = MAKE_PAIR(BNIL, BNIL);
				 arg1553_816 = cons__138___r4_pairs_and_lists_6_3(arg1560_823, list1562_825);
			      }
			   }
			   {
			      obj_t arg1564_827;
			      obj_t arg1565_828;
			      obj_t arg1566_829;
			      arg1564_827 = CNST_TABLE_REF(((long) 11));
			      {
				 obj_t arg1578_836;
				 obj_t arg1580_837;
				 arg1578_836 = CNST_TABLE_REF(((long) 12));
				 arg1580_837 = CNST_TABLE_REF(((long) 13));
				 {
				    obj_t list1583_840;
				    {
				       obj_t arg1584_841;
				       {
					  obj_t arg1585_842;
					  arg1585_842 = MAKE_PAIR(BNIL, BNIL);
					  {
					     obj_t aux_1664;
					     aux_1664 = BINT(((long) -1));
					     arg1584_841 = MAKE_PAIR(aux_1664, arg1585_842);
					  }
				       }
				       list1583_840 = MAKE_PAIR(arg1580_837, arg1584_841);
				    }
				    arg1565_828 = cons__138___r4_pairs_and_lists_6_3(arg1578_836, list1583_840);
				 }
			      }
			      {
				 obj_t arg1587_844;
				 obj_t arg1588_845;
				 obj_t arg1589_846;
				 arg1587_844 = CNST_TABLE_REF(((long) 14));
				 {
				    obj_t arg1600_852;
				    obj_t arg1602_853;
				    obj_t arg1603_854;
				    arg1600_852 = CNST_TABLE_REF(((long) 15));
				    arg1602_853 = CNST_TABLE_REF(((long) 13));
				    {
				       obj_t arg1610_860;
				       obj_t arg1612_861;
				       {
					  obj_t arg1618_866;
					  obj_t arg1620_867;
					  obj_t arg1621_868;
					  arg1618_866 = CNST_TABLE_REF(((long) 16));
					  arg1620_867 = CNST_TABLE_REF(((long) 1));
					  arg1621_868 = CNST_TABLE_REF(((long) 17));
					  {
					     obj_t list1623_870;
					     {
						obj_t arg1624_871;
						{
						   obj_t arg1625_872;
						   arg1625_872 = MAKE_PAIR(BNIL, BNIL);
						   arg1624_871 = MAKE_PAIR(arg1621_868, arg1625_872);
						}
						list1623_870 = MAKE_PAIR(arg1620_867, arg1624_871);
					     }
					     arg1610_860 = cons__138___r4_pairs_and_lists_6_3(arg1618_866, list1623_870);
					  }
				       }
				       arg1612_861 = CNST_TABLE_REF(((long) 18));
				       {
					  obj_t list1614_863;
					  {
					     obj_t arg1615_864;
					     arg1615_864 = MAKE_PAIR(BNIL, BNIL);
					     list1614_863 = MAKE_PAIR(arg1612_861, arg1615_864);
					  }
					  arg1603_854 = cons__138___r4_pairs_and_lists_6_3(arg1610_860, list1614_863);
				       }
				    }
				    {
				       obj_t list1606_856;
				       {
					  obj_t arg1607_857;
					  {
					     obj_t arg1608_858;
					     arg1608_858 = MAKE_PAIR(BNIL, BNIL);
					     arg1607_857 = MAKE_PAIR(arg1603_854, arg1608_858);
					  }
					  list1606_856 = MAKE_PAIR(arg1602_853, arg1607_857);
				       }
				       arg1588_845 = cons__138___r4_pairs_and_lists_6_3(arg1600_852, list1606_856);
				    }
				 }
				 {
				    obj_t arg1628_874;
				    obj_t arg1630_875;
				    obj_t arg1632_876;
				    arg1628_874 = CNST_TABLE_REF(((long) 5));
				    {
				       obj_t arg1640_882;
				       {
					  obj_t arg1646_886;
					  obj_t arg1647_887;
					  arg1646_886 = CNST_TABLE_REF(((long) 19));
					  {
					     obj_t arg1653_892;
					     obj_t arg1654_893;
					     arg1653_892 = CNST_TABLE_REF(((long) 20));
					     arg1654_893 = CNST_TABLE_REF(((long) 13));
					     {
						obj_t list1657_896;
						{
						   obj_t arg1658_897;
						   {
						      obj_t arg1659_898;
						      arg1659_898 = MAKE_PAIR(BNIL, BNIL);
						      {
							 obj_t aux_1692;
							 aux_1692 = BINT(((long) 1));
							 arg1658_897 = MAKE_PAIR(aux_1692, arg1659_898);
						      }
						   }
						   list1657_896 = MAKE_PAIR(arg1654_893, arg1658_897);
						}
						arg1647_887 = cons__138___r4_pairs_and_lists_6_3(arg1653_892, list1657_896);
					     }
					  }
					  {
					     obj_t list1649_889;
					     {
						obj_t arg1650_890;
						arg1650_890 = MAKE_PAIR(BNIL, BNIL);
						list1649_889 = MAKE_PAIR(arg1647_887, arg1650_890);
					     }
					     arg1640_882 = cons__138___r4_pairs_and_lists_6_3(arg1646_886, list1649_889);
					  }
				       }
				       {
					  obj_t list1642_884;
					  list1642_884 = MAKE_PAIR(BNIL, BNIL);
					  arg1630_875 = cons__138___r4_pairs_and_lists_6_3(arg1640_882, list1642_884);
				       }
				    }
				    {
				       obj_t arg1663_900;
				       obj_t arg1665_901;
				       arg1663_900 = CNST_TABLE_REF(((long) 9));
				       arg1665_901 = CNST_TABLE_REF(((long) 21));
				       {
					  obj_t list1667_903;
					  {
					     obj_t arg1668_904;
					     arg1668_904 = MAKE_PAIR(BNIL, BNIL);
					     list1667_903 = MAKE_PAIR(arg1665_901, arg1668_904);
					  }
					  arg1632_876 = cons__138___r4_pairs_and_lists_6_3(arg1663_900, list1667_903);
				       }
				    }
				    {
				       obj_t list1634_878;
				       {
					  obj_t arg1636_879;
					  {
					     obj_t arg1638_880;
					     arg1638_880 = MAKE_PAIR(BNIL, BNIL);
					     arg1636_879 = MAKE_PAIR(arg1632_876, arg1638_880);
					  }
					  list1634_878 = MAKE_PAIR(arg1630_875, arg1636_879);
				       }
				       arg1589_846 = cons__138___r4_pairs_and_lists_6_3(arg1628_874, list1634_878);
				    }
				 }
				 {
				    obj_t list1593_848;
				    {
				       obj_t arg1594_849;
				       {
					  obj_t arg1595_850;
					  arg1595_850 = MAKE_PAIR(BNIL, BNIL);
					  arg1594_849 = MAKE_PAIR(arg1589_846, arg1595_850);
				       }
				       list1593_848 = MAKE_PAIR(arg1588_845, arg1594_849);
				    }
				    arg1566_829 = cons__138___r4_pairs_and_lists_6_3(arg1587_844, list1593_848);
				 }
			      }
			      {
				 obj_t list1569_831;
				 {
				    obj_t arg1570_832;
				    {
				       obj_t arg1572_833;
				       {
					  obj_t arg1573_834;
					  arg1573_834 = MAKE_PAIR(BNIL, BNIL);
					  arg1572_833 = MAKE_PAIR(arg1566_829, arg1573_834);
				       }
				       arg1570_832 = MAKE_PAIR(BUNSPEC, arg1572_833);
				    }
				    list1569_831 = MAKE_PAIR(arg1565_828, arg1570_832);
				 }
				 arg1554_817 = cons__138___r4_pairs_and_lists_6_3(arg1564_827, list1569_831);
			      }
			   }
			   {
			      obj_t list1556_819;
			      {
				 obj_t arg1557_820;
				 {
				    obj_t arg1558_821;
				    arg1558_821 = MAKE_PAIR(BNIL, BNIL);
				    arg1557_820 = MAKE_PAIR(arg1554_817, arg1558_821);
				 }
				 list1556_819 = MAKE_PAIR(arg1553_816, arg1557_820);
			      }
			      arg1545_811 = cons__138___r4_pairs_and_lists_6_3(arg1552_815, list1556_819);
			   }
			}
			{
			   obj_t list1549_813;
			   list1549_813 = MAKE_PAIR(BNIL, BNIL);
			   arg1534_804 = cons__138___r4_pairs_and_lists_6_3(arg1545_811, list1549_813);
			}
		     }
		     {
			obj_t arg1670_906;
			long arg1672_907;
			arg1670_906 = CNST_TABLE_REF(((long) 9));
			{
			   obj_t arg1677_912;
			   arg1677_912 = get_cnst_offset_21_cnst_alloc();
			   {
			      long aux_1728;
			      aux_1728 = (long) CINT(arg1677_912);
			      arg1672_907 = (aux_1728 - ((long) 1));
			   }
			}
			{
			   obj_t list1674_909;
			   {
			      obj_t arg1675_910;
			      arg1675_910 = MAKE_PAIR(BNIL, BNIL);
			      {
				 obj_t aux_1732;
				 aux_1732 = BINT(arg1672_907);
				 list1674_909 = MAKE_PAIR(aux_1732, arg1675_910);
			      }
			   }
			   arg1535_805 = cons__138___r4_pairs_and_lists_6_3(arg1670_906, list1674_909);
			}
		     }
		     {
			obj_t list1537_807;
			{
			   obj_t arg1539_808;
			   {
			      obj_t arg1540_809;
			      arg1540_809 = MAKE_PAIR(BNIL, BNIL);
			      arg1539_808 = MAKE_PAIR(arg1535_805, arg1540_809);
			   }
			   list1537_807 = MAKE_PAIR(arg1534_804, arg1539_808);
			}
			arg1505_780 = cons__138___r4_pairs_and_lists_6_3(arg1533_803, list1537_807);
		     }
		  }
		  {
		     obj_t list1508_782;
		     {
			obj_t arg1510_783;
			{
			   obj_t arg1511_784;
			   arg1511_784 = MAKE_PAIR(BNIL, BNIL);
			   arg1510_783 = MAKE_PAIR(arg1505_780, arg1511_784);
			}
			list1508_782 = MAKE_PAIR(arg1504_779, arg1510_783);
		     }
		     sexp_776 = cons__138___r4_pairs_and_lists_6_3(arg1503_778, list1508_782);
		  }
	       }
	       {
		  {
		     obj_t arg1502_777;
		     arg1502_777 = get_cnst_sexp_197_cnst_alloc();
		     return MAKE_PAIR(sexp_776, arg1502_777);
		  }
	       }
	    }
	 }
      }
   }
}


/* cnst-set->cnst-string */ obj_t 
cnst_set__cnst_string_40_cnst_initialize(obj_t set_19)
{
   {
      obj_t port_915;
      port_915 = open_output_string();
      if (OUTPUT_PORTP(port_915))
	{
	   {
	      obj_t l1437_917;
	      l1437_917 = set_19;
	    lname1438_918:
	      if (PAIRP(l1437_917))
		{
		   {
		      obj_t cnst_920;
		      cnst_920 = CAR(l1437_917);
		      {
			 obj_t list1681_921;
			 list1681_921 = MAKE_PAIR(port_915, BNIL);
			 write___r4_output_6_10_3(cnst_920, list1681_921);
		      }
		      {
			 obj_t list1683_923;
			 list1683_923 = MAKE_PAIR(port_915, BNIL);
			 write_char_165___r4_output_6_10_3(((unsigned char) ' '), list1683_923);
		      }
		   }
		   {
		      obj_t l1437_1756;
		      l1437_1756 = CDR(l1437_917);
		      l1437_917 = l1437_1756;
		      goto lname1438_918;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   return close_output_port(port_915);
	}
      else
	{
	   return internal_error_43_tools_error(string1966_cnst_initialize, string1967_cnst_initialize, port_915);
	}
   }
}


/* intern-initialize! */ obj_t 
intern_initialize__196_cnst_initialize()
{
   {
      bool_t test1686_926;
      {
	 obj_t arg1688_927;
	 arg1688_927 = get_cnst_offset_21_cnst_alloc();
	 {
	    long aux_1761;
	    aux_1761 = (long) CINT(arg1688_927);
	    test1686_926 = (aux_1761 == ((long) 0));
	 }
      }
      if (test1686_926)
	{
	   return intern_empty_cnst_initialize__171_cnst_initialize();
	}
      else
	{
	   return intern_full_cnst_initialize__85_cnst_initialize();
	}
   }
}


/* intern-empty-cnst-initialize! */ obj_t 
intern_empty_cnst_initialize__171_cnst_initialize()
{
   {
      obj_t arg1691_929;
      arg1691_929 = get_cnst_table_42_cnst_alloc();
      {
	 global_t obj_1514;
	 obj_t val1066_1515;
	 obj_1514 = (global_t) (arg1691_929);
	 val1066_1515 = string1963_cnst_initialize;
	 ((((global_t) CREF(obj_1514))->name) = ((obj_t) val1066_1515), BUNSPEC);
      }
   }
   return get_cnst_sexp_197_cnst_alloc();
}


/* intern-full-cnst-initialize! */ obj_t 
intern_full_cnst_initialize__85_cnst_initialize()
{
   {
      obj_t cnst_string_99_947;
      {
	 obj_t arg1693_932;
	 obj_t arg1694_933;
	 arg1693_932 = get_cnst_table_42_cnst_alloc();
	 {
	    char *arg1697_935;
	    {
	       obj_t arg1703_941;
	       arg1703_941 = get_cnst_offset_21_cnst_alloc();
	       arg1697_935 = number__string_214___r4_numbers_6_5(arg1703_941, BNIL);
	    }
	    {
	       obj_t list1699_937;
	       {
		  obj_t arg1700_938;
		  {
		     obj_t arg1701_939;
		     arg1701_939 = MAKE_PAIR(string1964_cnst_initialize, BNIL);
		     {
			obj_t aux_1775;
			aux_1775 = string_to_bstring(arg1697_935);
			arg1700_938 = MAKE_PAIR(aux_1775, arg1701_939);
		     }
		  }
		  list1699_937 = MAKE_PAIR(string1965_cnst_initialize, arg1700_938);
	       }
	       arg1694_933 = string_append_106___r4_strings_6_7(list1699_937);
	    }
	 }
	 {
	    global_t obj_1516;
	    obj_1516 = (global_t) (arg1693_932);
	    ((((global_t) CREF(obj_1516))->name) = ((obj_t) arg1694_933), BUNSPEC);
	 }
      }
      {
	 obj_t cnst_string_99_943;
	 {
	    obj_t arg1705_944;
	    {
	       obj_t arg1706_945;
	       {
		  obj_t arg1707_946;
		  arg1707_946 = get_cnst_set_138_cnst_alloc();
		  arg1706_945 = reverse__39___r4_pairs_and_lists_6_3(arg1707_946);
	       }
	       arg1705_944 = list__vector_101___r4_vectors_6_8(arg1706_945);
	    }
	    cnst_string_99_943 = obj_to_string(arg1705_944);
	 }
	 {
	    cnst_string_99_947 = cnst_string_99_943;
	    {
	       node_t var_string_203_949;
	       var_string_203_949 = cnst_alloc_string_41_cnst_alloc(cnst_string_99_947, BFALSE);
	       {
		  obj_t sexp_950;
		  {
		     obj_t arg1710_952;
		     obj_t arg1711_953;
		     obj_t arg1712_954;
		     arg1710_952 = CNST_TABLE_REF(((long) 5));
		     {
			obj_t arg1720_960;
			{
			   obj_t arg1724_964;
			   obj_t arg1725_965;
			   arg1724_964 = CNST_TABLE_REF(((long) 22));
			   {
			      obj_t arg1730_970;
			      obj_t arg1731_971;
			      {
				 obj_t arg1740_976;
				 obj_t arg1743_977;
				 obj_t arg1744_978;
				 arg1740_976 = CNST_TABLE_REF(((long) 16));
				 arg1743_977 = CNST_TABLE_REF(((long) 23));
				 arg1744_978 = CNST_TABLE_REF(((long) 24));
				 {
				    obj_t list1746_980;
				    {
				       obj_t arg1747_981;
				       {
					  obj_t arg1748_982;
					  arg1748_982 = MAKE_PAIR(BNIL, BNIL);
					  arg1747_981 = MAKE_PAIR(arg1744_978, arg1748_982);
				       }
				       list1746_980 = MAKE_PAIR(arg1743_977, arg1747_981);
				    }
				    arg1730_970 = cons__138___r4_pairs_and_lists_6_3(arg1740_976, list1746_980);
				 }
			      }
			      {
				 global_t obj_1519;
				 {
				    variable_t aux_1796;
				    {
				       var_t obj_1518;
				       obj_1518 = (var_t) (var_string_203_949);
				       aux_1796 = (((var_t) CREF(obj_1518))->variable);
				    }
				    obj_1519 = (global_t) (aux_1796);
				 }
				 arg1731_971 = (((global_t) CREF(obj_1519))->id);
			      }
			      {
				 obj_t list1733_973;
				 {
				    obj_t arg1738_974;
				    arg1738_974 = MAKE_PAIR(BNIL, BNIL);
				    list1733_973 = MAKE_PAIR(arg1731_971, arg1738_974);
				 }
				 arg1725_965 = cons__138___r4_pairs_and_lists_6_3(arg1730_970, list1733_973);
			      }
			   }
			   {
			      obj_t list1727_967;
			      {
				 obj_t arg1728_968;
				 arg1728_968 = MAKE_PAIR(BNIL, BNIL);
				 list1727_967 = MAKE_PAIR(arg1725_965, arg1728_968);
			      }
			      arg1720_960 = cons__138___r4_pairs_and_lists_6_3(arg1724_964, list1727_967);
			   }
			}
			{
			   obj_t list1722_962;
			   list1722_962 = MAKE_PAIR(BNIL, BNIL);
			   arg1711_953 = cons__138___r4_pairs_and_lists_6_3(arg1720_960, list1722_962);
			}
		     }
		     {
			obj_t arg1755_985;
			obj_t arg1758_986;
			obj_t arg1759_987;
			arg1755_985 = CNST_TABLE_REF(((long) 8));
			{
			   obj_t arg1767_993;
			   {
			      obj_t arg1771_997;
			      obj_t arg1772_998;
			      obj_t arg1773_999;
			      arg1771_997 = CNST_TABLE_REF(((long) 9));
			      {
				 obj_t arg1779_1005;
				 arg1779_1005 = CNST_TABLE_REF(((long) 25));
				 {
				    obj_t list1781_1007;
				    list1781_1007 = MAKE_PAIR(BNIL, BNIL);
				    arg1772_998 = cons__138___r4_pairs_and_lists_6_3(arg1779_1005, list1781_1007);
				 }
			      }
			      {
				 obj_t arg1786_1009;
				 obj_t arg1788_1010;
				 obj_t arg1789_1011;
				 arg1786_1009 = CNST_TABLE_REF(((long) 11));
				 {
				    obj_t arg1796_1018;
				    obj_t arg1797_1019;
				    arg1796_1018 = CNST_TABLE_REF(((long) 12));
				    arg1797_1019 = CNST_TABLE_REF(((long) 13));
				    {
				       obj_t list1801_1022;
				       {
					  obj_t arg1802_1023;
					  {
					     obj_t arg1803_1024;
					     arg1803_1024 = MAKE_PAIR(BNIL, BNIL);
					     {
						obj_t aux_1818;
						aux_1818 = BINT(((long) -1));
						arg1802_1023 = MAKE_PAIR(aux_1818, arg1803_1024);
					     }
					  }
					  list1801_1022 = MAKE_PAIR(arg1797_1019, arg1802_1023);
				       }
				       arg1788_1010 = cons__138___r4_pairs_and_lists_6_3(arg1796_1018, list1801_1022);
				    }
				 }
				 {
				    obj_t arg1805_1026;
				    obj_t arg1806_1027;
				    obj_t arg1807_1028;
				    arg1805_1026 = CNST_TABLE_REF(((long) 14));
				    {
				       obj_t arg1813_1034;
				       obj_t arg1814_1035;
				       obj_t arg1815_1036;
				       arg1813_1034 = CNST_TABLE_REF(((long) 15));
				       arg1814_1035 = CNST_TABLE_REF(((long) 13));
				       {
					  obj_t arg1822_1042;
					  obj_t arg1823_1043;
					  obj_t arg1824_1044;
					  arg1822_1042 = CNST_TABLE_REF(((long) 26));
					  arg1823_1043 = CNST_TABLE_REF(((long) 27));
					  arg1824_1044 = CNST_TABLE_REF(((long) 13));
					  {
					     obj_t list1827_1046;
					     {
						obj_t arg1829_1047;
						{
						   obj_t arg1830_1048;
						   arg1830_1048 = MAKE_PAIR(BNIL, BNIL);
						   arg1829_1047 = MAKE_PAIR(arg1824_1044, arg1830_1048);
						}
						list1827_1046 = MAKE_PAIR(arg1823_1043, arg1829_1047);
					     }
					     arg1815_1036 = cons__138___r4_pairs_and_lists_6_3(arg1822_1042, list1827_1046);
					  }
				       }
				       {
					  obj_t list1817_1038;
					  {
					     obj_t arg1818_1039;
					     {
						obj_t arg1820_1040;
						arg1820_1040 = MAKE_PAIR(BNIL, BNIL);
						arg1818_1039 = MAKE_PAIR(arg1815_1036, arg1820_1040);
					     }
					     list1817_1038 = MAKE_PAIR(arg1814_1035, arg1818_1039);
					  }
					  arg1806_1027 = cons__138___r4_pairs_and_lists_6_3(arg1813_1034, list1817_1038);
				       }
				    }
				    {
				       obj_t arg1832_1050;
				       obj_t arg1833_1051;
				       obj_t arg1834_1052;
				       arg1832_1050 = CNST_TABLE_REF(((long) 5));
				       {
					  obj_t arg1842_1058;
					  {
					     obj_t arg1848_1062;
					     obj_t arg1850_1063;
					     arg1848_1062 = CNST_TABLE_REF(((long) 19));
					     {
						obj_t arg1857_1068;
						obj_t arg1858_1069;
						arg1857_1068 = CNST_TABLE_REF(((long) 20));
						arg1858_1069 = CNST_TABLE_REF(((long) 13));
						{
						   obj_t list1861_1072;
						   {
						      obj_t arg1862_1073;
						      {
							 obj_t arg1863_1074;
							 arg1863_1074 = MAKE_PAIR(BNIL, BNIL);
							 {
							    obj_t aux_1842;
							    aux_1842 = BINT(((long) 1));
							    arg1862_1073 = MAKE_PAIR(aux_1842, arg1863_1074);
							 }
						      }
						      list1861_1072 = MAKE_PAIR(arg1858_1069, arg1862_1073);
						   }
						   arg1850_1063 = cons__138___r4_pairs_and_lists_6_3(arg1857_1068, list1861_1072);
						}
					     }
					     {
						obj_t list1852_1065;
						{
						   obj_t arg1853_1066;
						   arg1853_1066 = MAKE_PAIR(BNIL, BNIL);
						   list1852_1065 = MAKE_PAIR(arg1850_1063, arg1853_1066);
						}
						arg1842_1058 = cons__138___r4_pairs_and_lists_6_3(arg1848_1062, list1852_1065);
					     }
					  }
					  {
					     obj_t list1844_1060;
					     list1844_1060 = MAKE_PAIR(BNIL, BNIL);
					     arg1833_1051 = cons__138___r4_pairs_and_lists_6_3(arg1842_1058, list1844_1060);
					  }
				       }
				       {
					  obj_t arg1865_1076;
					  obj_t arg1866_1077;
					  arg1865_1076 = CNST_TABLE_REF(((long) 9));
					  arg1866_1077 = CNST_TABLE_REF(((long) 21));
					  {
					     obj_t list1868_1079;
					     {
						obj_t arg1869_1080;
						arg1869_1080 = MAKE_PAIR(BNIL, BNIL);
						list1868_1079 = MAKE_PAIR(arg1866_1077, arg1869_1080);
					     }
					     arg1834_1052 = cons__138___r4_pairs_and_lists_6_3(arg1865_1076, list1868_1079);
					  }
				       }
				       {
					  obj_t list1836_1054;
					  {
					     obj_t arg1837_1055;
					     {
						obj_t arg1838_1056;
						arg1838_1056 = MAKE_PAIR(BNIL, BNIL);
						arg1837_1055 = MAKE_PAIR(arg1834_1052, arg1838_1056);
					     }
					     list1836_1054 = MAKE_PAIR(arg1833_1051, arg1837_1055);
					  }
					  arg1807_1028 = cons__138___r4_pairs_and_lists_6_3(arg1832_1050, list1836_1054);
				       }
				    }
				    {
				       obj_t list1809_1030;
				       {
					  obj_t arg1810_1031;
					  {
					     obj_t arg1811_1032;
					     arg1811_1032 = MAKE_PAIR(BNIL, BNIL);
					     arg1810_1031 = MAKE_PAIR(arg1807_1028, arg1811_1032);
					  }
					  list1809_1030 = MAKE_PAIR(arg1806_1027, arg1810_1031);
				       }
				       arg1789_1011 = cons__138___r4_pairs_and_lists_6_3(arg1805_1026, list1809_1030);
				    }
				 }
				 {
				    obj_t list1791_1013;
				    {
				       obj_t arg1792_1014;
				       {
					  obj_t arg1793_1015;
					  {
					     obj_t arg1794_1016;
					     arg1794_1016 = MAKE_PAIR(BNIL, BNIL);
					     arg1793_1015 = MAKE_PAIR(arg1789_1011, arg1794_1016);
					  }
					  arg1792_1014 = MAKE_PAIR(BUNSPEC, arg1793_1015);
				       }
				       list1791_1013 = MAKE_PAIR(arg1788_1010, arg1792_1014);
				    }
				    arg1773_999 = cons__138___r4_pairs_and_lists_6_3(arg1786_1009, list1791_1013);
				 }
			      }
			      {
				 obj_t list1775_1001;
				 {
				    obj_t arg1776_1002;
				    {
				       obj_t arg1777_1003;
				       arg1777_1003 = MAKE_PAIR(BNIL, BNIL);
				       arg1776_1002 = MAKE_PAIR(arg1773_999, arg1777_1003);
				    }
				    list1775_1001 = MAKE_PAIR(arg1772_998, arg1776_1002);
				 }
				 arg1767_993 = cons__138___r4_pairs_and_lists_6_3(arg1771_997, list1775_1001);
			      }
			   }
			   {
			      obj_t list1769_995;
			      list1769_995 = MAKE_PAIR(BNIL, BNIL);
			      arg1758_986 = cons__138___r4_pairs_and_lists_6_3(arg1767_993, list1769_995);
			   }
			}
			{
			   obj_t arg1871_1082;
			   long arg1874_1083;
			   arg1871_1082 = CNST_TABLE_REF(((long) 9));
			   {
			      obj_t arg1879_1088;
			      arg1879_1088 = get_cnst_offset_21_cnst_alloc();
			      {
				 long aux_1878;
				 aux_1878 = (long) CINT(arg1879_1088);
				 arg1874_1083 = (aux_1878 - ((long) 1));
			      }
			   }
			   {
			      obj_t list1876_1085;
			      {
				 obj_t arg1877_1086;
				 arg1877_1086 = MAKE_PAIR(BNIL, BNIL);
				 {
				    obj_t aux_1882;
				    aux_1882 = BINT(arg1874_1083);
				    list1876_1085 = MAKE_PAIR(aux_1882, arg1877_1086);
				 }
			      }
			      arg1759_987 = cons__138___r4_pairs_and_lists_6_3(arg1871_1082, list1876_1085);
			   }
			}
			{
			   obj_t list1761_989;
			   {
			      obj_t arg1762_990;
			      {
				 obj_t arg1765_991;
				 arg1765_991 = MAKE_PAIR(BNIL, BNIL);
				 arg1762_990 = MAKE_PAIR(arg1759_987, arg1765_991);
			      }
			      list1761_989 = MAKE_PAIR(arg1758_986, arg1762_990);
			   }
			   arg1712_954 = cons__138___r4_pairs_and_lists_6_3(arg1755_985, list1761_989);
			}
		     }
		     {
			obj_t list1714_956;
			{
			   obj_t arg1716_957;
			   {
			      obj_t arg1717_958;
			      arg1717_958 = MAKE_PAIR(BNIL, BNIL);
			      arg1716_957 = MAKE_PAIR(arg1712_954, arg1717_958);
			   }
			   list1714_956 = MAKE_PAIR(arg1711_953, arg1716_957);
			}
			sexp_950 = cons__138___r4_pairs_and_lists_6_3(arg1710_952, list1714_956);
		     }
		  }
		  {
		     {
			obj_t arg1709_951;
			arg1709_951 = get_cnst_sexp_197_cnst_alloc();
			return MAKE_PAIR(sexp_950, arg1709_951);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_cnst_initialize()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cnst_initialize()
{
   module_initialization_70_tools_trace(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_tools_shape(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_tools_speek(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_tools_error(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_engine_param(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_type_type(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_type_cache(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_ast_var(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_ast_node(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_ast_env(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_ast_build(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_ast_lvtype(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_coerce_coerce(((long) 0), "CNST_INITIALIZE");
   module_initialization_70_cnst_alloc(((long) 0), "CNST_INITIALIZE");
   return module_initialization_70_cnst_node(((long) 0), "CNST_INITIALIZE");
}
