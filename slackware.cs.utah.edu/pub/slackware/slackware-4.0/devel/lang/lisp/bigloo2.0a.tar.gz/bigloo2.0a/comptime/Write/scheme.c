/*===========================================================================*/
/*   (Write/scheme.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

static obj_t _write_scheme_file_header1176_228_write_scheme(obj_t, obj_t, obj_t);
static obj_t _write_scheme_comment1177_238_write_scheme(obj_t, obj_t, obj_t);
extern obj_t write_scheme_comment_102_write_scheme(obj_t, obj_t);
extern obj_t module_initialization_70_write_scheme(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t imported_modules_init_94_write_scheme();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t library_modules_init_112_write_scheme();
extern obj_t newline___r4_output_6_10_3(obj_t);
extern obj_t _bigloo_author__68_engine_param;
extern obj_t _bigloo_date__70_engine_param;
extern obj_t _bigloo_name__170_engine_param;
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_write_scheme = BUNSPEC;
extern obj_t write_scheme_file_header_174_write_scheme(obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(write_scheme_file_header_env_156_write_scheme, _write_scheme_file_header1176_228_write_scheme1183, _write_scheme_file_header1176_228_write_scheme, 0L, 2);
DEFINE_EXPORT_PROCEDURE(write_scheme_comment_env_153_write_scheme, _write_scheme_comment1177_238_write_scheme1184, va_generic_entry, _write_scheme_comment1177_238_write_scheme, -2);
DEFINE_STRING(string1181_write_scheme, string1181_write_scheme1185, ";;", 2);
DEFINE_STRING(string1179_write_scheme, string1179_write_scheme1186, ";; ", 3);
DEFINE_STRING(string1180_write_scheme, string1180_write_scheme1187, " (c)      ", 10);
DEFINE_STRING(string1178_write_scheme, string1178_write_scheme1188, ";; =========================================================", 60);


/* module-initialization */ obj_t 
module_initialization_70_write_scheme(long checksum_57, char *from_58)
{
   if (CBOOL(require_initialization_114_write_scheme))
     {
	require_initialization_114_write_scheme = BBOOL(((bool_t) 0));
	library_modules_init_112_write_scheme();
	imported_modules_init_94_write_scheme();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_write_scheme()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "WRITE_SCHEME");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "WRITE_SCHEME");
   return BUNSPEC;
}


/* write-scheme-file-header */ obj_t 
write_scheme_file_header_174_write_scheme(obj_t port_1, obj_t string_2)
{
   {
      obj_t list1002_5;
      list1002_5 = MAKE_PAIR(string1178_write_scheme, BNIL);
      fprint___r4_output_6_10_3(port_1, list1002_5);
   }
   {
      obj_t list1005_8;
      {
	 obj_t arg1007_10;
	 arg1007_10 = MAKE_PAIR(string_2, BNIL);
	 list1005_8 = MAKE_PAIR(string1179_write_scheme, arg1007_10);
      }
      fprint___r4_output_6_10_3(port_1, list1005_8);
   }
   {
      obj_t list1009_12;
      {
	 obj_t arg1014_14;
	 arg1014_14 = MAKE_PAIR(_bigloo_name__170_engine_param, BNIL);
	 list1009_12 = MAKE_PAIR(string1179_write_scheme, arg1014_14);
      }
      fprint___r4_output_6_10_3(port_1, list1009_12);
   }
   {
      obj_t list1017_16;
      {
	 obj_t arg1020_18;
	 {
	    obj_t arg1025_19;
	    {
	       obj_t arg1034_21;
	       arg1034_21 = MAKE_PAIR(_bigloo_date__70_engine_param, BNIL);
	       arg1025_19 = MAKE_PAIR(string1180_write_scheme, arg1034_21);
	    }
	    arg1020_18 = MAKE_PAIR(_bigloo_author__68_engine_param, arg1025_19);
	 }
	 list1017_16 = MAKE_PAIR(string1179_write_scheme, arg1020_18);
      }
      fprint___r4_output_6_10_3(port_1, list1017_16);
   }
   {
      obj_t list1039_23;
      list1039_23 = MAKE_PAIR(string1178_write_scheme, BNIL);
      fprint___r4_output_6_10_3(port_1, list1039_23);
   }
   {
      obj_t list1042_26;
      list1042_26 = MAKE_PAIR(port_1, BNIL);
      return newline___r4_output_6_10_3(list1042_26);
   }
}


/* _write-scheme-file-header1176 */ obj_t 
_write_scheme_file_header1176_228_write_scheme(obj_t env_51, obj_t port_52, obj_t string_53)
{
   return write_scheme_file_header_174_write_scheme(port_52, string_53);
}


/* write-scheme-comment */ obj_t 
write_scheme_comment_102_write_scheme(obj_t port_3, obj_t sexp_4)
{
   if (NULLP(sexp_4))
     {
	{
	   obj_t list1055_29;
	   list1055_29 = MAKE_PAIR(string1181_write_scheme, BNIL);
	   return fprint___r4_output_6_10_3(port_3, list1055_29);
	}
     }
   else
     {
	bool_t test_88;
	{
	   obj_t aux_89;
	   aux_89 = CDR(sexp_4);
	   test_88 = NULLP(aux_89);
	}
	if (test_88)
	  {
	     {
		obj_t list1138_35;
		{
		   obj_t arg1142_36;
		   {
		      obj_t aux_92;
		      aux_92 = CAR(sexp_4);
		      arg1142_36 = MAKE_PAIR(aux_92, BNIL);
		   }
		   list1138_35 = MAKE_PAIR(string1179_write_scheme, arg1142_36);
		}
		return fprint___r4_output_6_10_3(port_3, list1138_35);
	     }
	  }
	else
	  {
	     {
		obj_t runner1163_43;
		{
		   obj_t list1145_38;
		   {
		      obj_t arg1157_40;
		      arg1157_40 = MAKE_PAIR(sexp_4, BNIL);
		      list1145_38 = MAKE_PAIR(string1179_write_scheme, arg1157_40);
		   }
		   runner1163_43 = cons__138___r4_pairs_and_lists_6_3(port_3, list1145_38);
		}
		{
		   obj_t aux1162_42;
		   {
		      obj_t pair_49;
		      pair_49 = runner1163_43;
		      aux1162_42 = CAR(pair_49);
		   }
		   {
		      obj_t pair_50;
		      pair_50 = runner1163_43;
		      runner1163_43 = CDR(pair_50);
		   }
		   return fprint___r4_output_6_10_3(aux1162_42, runner1163_43);
		}
	     }
	  }
     }
}


/* _write-scheme-comment1177 */ obj_t 
_write_scheme_comment1177_238_write_scheme(obj_t env_54, obj_t port_55, obj_t sexp_56)
{
   return write_scheme_comment_102_write_scheme(port_55, sexp_56);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_write_scheme()
{
   return module_initialization_70_engine_param(((long) 0), "WRITE_SCHEME");
}
