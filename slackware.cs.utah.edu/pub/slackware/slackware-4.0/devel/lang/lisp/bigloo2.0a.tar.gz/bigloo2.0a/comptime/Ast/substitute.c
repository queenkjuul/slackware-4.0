/*===========================================================================*/
/*   (Ast/substitute.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_ast_substitute();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern node_t known_app_ly__node_26_ast_apply(obj_t, obj_t, node_t, node_t, obj_t);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern node_t substitute__30_ast_substitute(obj_t, obj_t, node_t, obj_t);
extern obj_t closure_ast_node;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t do_substitute___56_ast_substitute(obj_t, obj_t);
extern obj_t module_initialization_70_ast_substitute(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_ast_apply(long, char *);
extern obj_t module_initialization_70_ast_app(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
extern obj_t fun_ast_var;
static obj_t _substitute_1783_133_ast_substitute(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_ast_substitute();
extern bool_t correct_arity_app__187_ast_app(variable_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t _do_substitute__default1462_221_ast_substitute(obj_t, obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_ast_substitute();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_ast_substitute();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t use_variable__4_ast_sexp(variable_t, obj_t, obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t variable_ast_var;
extern obj_t shape_tools_shape(obj_t);
static node_t do_substitute__default1462_120_ast_substitute(node_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _do_substitute_1784_3_ast_substitute(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern node_t make_app_node_80_ast_app(obj_t, obj_t, var_t, obj_t);
static node_t do_substitute__77_ast_substitute(node_t, obj_t);
static obj_t require_initialization_114_ast_substitute = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_ast_substitute();
extern obj_t user_error_location_137_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t __cnst[6];

DEFINE_STATIC_PROCEDURE(do_substitute__default1462_env_192_ast_substitute, _do_substitute__default1462_221_ast_substitute1796, _do_substitute__default1462_221_ast_substitute, 0L, 2);
DEFINE_EXPORT_PROCEDURE(substitute__env_193_ast_substitute, _substitute_1783_133_ast_substitute1797, _substitute_1783_133_ast_substitute, 0L, 4);
DEFINE_STATIC_GENERIC(do_substitute__env_169_ast_substitute, _do_substitute_1784_3_ast_substitute1798, _do_substitute_1784_3_ast_substitute, 0L, 2);
DEFINE_STRING(string1789_ast_substitute, string1789_ast_substitute1799, "No method for this object", 25);
DEFINE_STRING(string1790_ast_substitute, string1790_ast_substitute1800, "DO-SUBSTITUTE!-DEFAULT1462 SET! APPLY APP VALUE DONE ", 53);
DEFINE_STRING(string1788_ast_substitute, string1788_ast_substitute1801, "wrong number of argument(s)", 27);
DEFINE_STRING(string1787_ast_substitute, string1787_ast_substitute1802, "Illegal application", 19);
DEFINE_STRING(string1786_ast_substitute, string1786_ast_substitute1803, "Illegal substitution", 20);
DEFINE_STRING(string1785_ast_substitute, string1785_ast_substitute1804, "duplicate", 9);


/* module-initialization */ obj_t 
module_initialization_70_ast_substitute(long checksum_1573, char *from_1574)
{
   if (CBOOL(require_initialization_114_ast_substitute))
     {
	require_initialization_114_ast_substitute = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_substitute();
	cnst_init_137_ast_substitute();
	imported_modules_init_94_ast_substitute();
	method_init_76_ast_substitute();
	toplevel_init_63_ast_substitute();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_substitute()
{
   module_initialization_70___object(((long) 0), "AST_SUBSTITUTE");
   module_initialization_70___reader(((long) 0), "AST_SUBSTITUTE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_substitute()
{
   {
      obj_t cnst_port_138_1565;
      cnst_port_138_1565 = open_input_string(string1790_ast_substitute);
      {
	 long i_1566;
	 i_1566 = ((long) 5);
       loop_1567:
	 {
	    bool_t test1791_1568;
	    test1791_1568 = (i_1566 == ((long) -1));
	    if (test1791_1568)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1792_1569;
		    {
		       obj_t list1793_1570;
		       {
			  obj_t arg1794_1571;
			  arg1794_1571 = BNIL;
			  list1793_1570 = MAKE_PAIR(cnst_port_138_1565, arg1794_1571);
		       }
		       arg1792_1569 = read___reader(list1793_1570);
		    }
		    CNST_TABLE_SET(i_1566, arg1792_1569);
		 }
		 {
		    int aux_1572;
		    {
		       long aux_1591;
		       aux_1591 = (i_1566 - ((long) 1));
		       aux_1572 = (int) (aux_1591);
		    }
		    {
		       long i_1594;
		       i_1594 = (long) (aux_1572);
		       i_1566 = i_1594;
		       goto loop_1567;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_substitute()
{
   return BUNSPEC;
}


/* substitute! */ node_t 
substitute__30_ast_substitute(obj_t what__148_1, obj_t by__251_2, node_t node_3, obj_t site_4)
{
   {
      obj_t ll1435_742;
      obj_t ll1436_743;
      ll1435_742 = what__148_1;
      ll1436_743 = by__251_2;
    lname1437_744:
      if (NULLP(ll1435_742))
	{
	   ((bool_t) 1);
	}
      else
	{
	   {
	      obj_t by_747;
	      by_747 = CAR(ll1436_743);
	      {
		 variable_t obj_1317;
		 {
		    obj_t aux_1599;
		    aux_1599 = CAR(ll1435_742);
		    obj_1317 = (variable_t) (aux_1599);
		 }
		 ((((variable_t) CREF(obj_1317))->fast_alpha_7) = ((obj_t) by_747), BUNSPEC);
	      }
	   }
	   {
	      obj_t ll1436_1605;
	      obj_t ll1435_1603;
	      ll1435_1603 = CDR(ll1435_742);
	      ll1436_1605 = CDR(ll1436_743);
	      ll1436_743 = ll1436_1605;
	      ll1435_742 = ll1435_1603;
	      goto lname1437_744;
	   }
	}
   }
   {
      node_t res_750;
      res_750 = do_substitute__77_ast_substitute(node_3, site_4);
      {
	 obj_t l1438_751;
	 l1438_751 = what__148_1;
       lname1439_752:
	 if (PAIRP(l1438_751))
	   {
	      {
		 variable_t obj_1323;
		 {
		    obj_t aux_1610;
		    aux_1610 = CAR(l1438_751);
		    obj_1323 = (variable_t) (aux_1610);
		 }
		 ((((variable_t) CREF(obj_1323))->fast_alpha_7) = ((obj_t) BUNSPEC), BUNSPEC);
	      }
	      {
		 obj_t l1438_1614;
		 l1438_1614 = CDR(l1438_751);
		 l1438_751 = l1438_1614;
		 goto lname1439_752;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      return res_750;
   }
}


/* _substitute!1783 */ obj_t 
_substitute_1783_133_ast_substitute(obj_t env_1554, obj_t what__148_1555, obj_t by__251_1556, obj_t node_1557, obj_t site_1558)
{
   {
      node_t aux_1616;
      aux_1616 = substitute__30_ast_substitute(what__148_1555, by__251_1556, (node_t) (node_1557), site_1558);
      return (obj_t) (aux_1616);
   }
}


/* do-substitute*! */ obj_t 
do_substitute___56_ast_substitute(obj_t node__221_49, obj_t site_50)
{
 do_substitute___56_ast_substitute:
   if (NULLP(node__221_49))
     {
	return CNST_TABLE_REF(((long) 0));
     }
   else
     {
	bool_t test_1623;
	{
	   obj_t aux_1624;
	   aux_1624 = CDR(node__221_49);
	   test_1623 = NULLP(aux_1624);
	}
	if (test_1623)
	  {
	     {
		node_t arg1494_758;
		{
		   node_t aux_1627;
		   {
		      obj_t aux_1628;
		      aux_1628 = CAR(node__221_49);
		      aux_1627 = (node_t) (aux_1628);
		   }
		   arg1494_758 = do_substitute__77_ast_substitute(aux_1627, site_50);
		}
		{
		   obj_t aux_1632;
		   aux_1632 = (obj_t) (arg1494_758);
		   SET_CAR(node__221_49, aux_1632);
		}
	     }
	     return CNST_TABLE_REF(((long) 0));
	  }
	else
	  {
	     {
		node_t arg1497_760;
		{
		   node_t aux_1636;
		   {
		      obj_t aux_1637;
		      aux_1637 = CAR(node__221_49);
		      aux_1636 = (node_t) (aux_1637);
		   }
		   arg1497_760 = do_substitute__77_ast_substitute(aux_1636, CNST_TABLE_REF(((long) 1)));
		}
		{
		   obj_t aux_1642;
		   aux_1642 = (obj_t) (arg1497_760);
		   SET_CAR(node__221_49, aux_1642);
		}
	     }
	     {
		obj_t node__221_1645;
		node__221_1645 = CDR(node__221_49);
		node__221_49 = node__221_1645;
		goto do_substitute___56_ast_substitute;
	     }
	  }
     }
}


/* method-init */ obj_t 
method_init_76_ast_substitute()
{
   add_generic__110___object(do_substitute__env_169_ast_substitute, do_substitute__default1462_env_192_ast_substitute);
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, var_ast_node, ((long) 1));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, kwote_ast_node, ((long) 2));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, sequence_ast_node, ((long) 3));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, app_ast_node, ((long) 4));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, select_ast_node, ((long) 12));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(do_substitute__env_169_ast_substitute, box_ref_242_ast_node, ((long) 18));
   {
      long aux_1667;
      aux_1667 = add_inlined_method__244___object(do_substitute__env_169_ast_substitute, box_set__221_ast_node, ((long) 19));
      return BINT(aux_1667);
   }
}


/* do-substitute! */ node_t 
do_substitute__77_ast_substitute(node_t node_5, obj_t site_6)
{
   {
      obj_t method1601_1096;
      obj_t class1606_1097;
      {
	 obj_t arg1609_1094;
	 obj_t arg1610_1095;
	 {
	    object_t obj_1350;
	    obj_1350 = (object_t) (node_5);
	    {
	       obj_t pre_method_105_1351;
	       pre_method_105_1351 = PROCEDURE_REF(do_substitute__env_169_ast_substitute, ((long) 2));
	       if (INTEGERP(pre_method_105_1351))
		 {
		    PROCEDURE_SET(do_substitute__env_169_ast_substitute, ((long) 2), BUNSPEC);
		    arg1609_1094 = pre_method_105_1351;
		 }
	       else
		 {
		    long obj_class_num_177_1356;
		    obj_class_num_177_1356 = TYPE(obj_1350);
		    {
		       obj_t arg1177_1357;
		       arg1177_1357 = PROCEDURE_REF(do_substitute__env_169_ast_substitute, ((long) 1));
		       {
			  long arg1178_1361;
			  {
			     long arg1179_1362;
			     arg1179_1362 = OBJECT_TYPE;
			     arg1178_1361 = (obj_class_num_177_1356 - arg1179_1362);
			  }
			  arg1609_1094 = VECTOR_REF(arg1177_1357, arg1178_1361);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1367;
	    object_1367 = (object_t) (node_5);
	    {
	       long arg1180_1368;
	       {
		  long arg1181_1369;
		  long arg1182_1370;
		  arg1181_1369 = TYPE(object_1367);
		  arg1182_1370 = OBJECT_TYPE;
		  arg1180_1368 = (arg1181_1369 - arg1182_1370);
	       }
	       {
		  obj_t vector_1374;
		  vector_1374 = _classes__134___object;
		  arg1610_1095 = VECTOR_REF(vector_1374, arg1180_1368);
	       }
	    }
	 }
	 {
	    obj_t aux_1685;
	    method1601_1096 = arg1609_1094;
	    class1606_1097 = arg1610_1095;
	    {
	       if (INTEGERP(method1601_1096))
		 {
		    switch ((long) CINT(method1601_1096))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_1688;
			    aux_1688 = (atom_t) (node_5);
			    aux_1685 = (obj_t) (aux_1688);
			 }
			 break;
		      case ((long) 1):
			 {
			    var_t node_1105;
			    node_1105 = (var_t) (node_5);
			    {
			       variable_t var_1107;
			       var_1107 = (((var_t) CREF(node_1105))->variable);
			       {
				  {
				     obj_t alpha_1109;
				     alpha_1109 = (((variable_t) CREF(var_1107))->fast_alpha_7);
				   loop_1110:
				     if ((alpha_1109 == BUNSPEC))
				       {
					  aux_1685 = (obj_t) (node_1105);
				       }
				     else
				       {
					  bool_t test1614_1112;
					  test1614_1112 = is_a__118___object(alpha_1109, var_ast_node);
					  if (test1614_1112)
					    {
					       {
						  obj_t alpha_1698;
						  {
						     variable_t aux_1699;
						     {
							var_t obj_1381;
							obj_1381 = (var_t) (alpha_1109);
							aux_1699 = (((var_t) CREF(obj_1381))->variable);
						     }
						     alpha_1698 = (obj_t) (aux_1699);
						  }
						  alpha_1109 = alpha_1698;
						  goto loop_1110;
					       }
					    }
					  else
					    {
					       bool_t test1616_1114;
					       test1616_1114 = is_a__118___object(alpha_1109, variable_ast_var);
					       if (test1616_1114)
						 {
						    {
						       obj_t aux_1705;
						       {
							  node_t obj_1383;
							  obj_1383 = (node_t) (node_1105);
							  aux_1705 = (((node_t) CREF(obj_1383))->loc);
						       }
						       use_variable__4_ast_sexp((variable_t) (alpha_1109), aux_1705, site_6);
						    }
						    {
						       bool_t test1618_1116;
						       {
							  bool_t test1626_1123;
							  {
							     obj_t aux_1710;
							     {
								value_t aux_1711;
								{
								   variable_t obj_1384;
								   obj_1384 = (variable_t) (alpha_1109);
								   aux_1711 = (((variable_t) CREF(obj_1384))->value);
								}
								aux_1710 = (obj_t) (aux_1711);
							     }
							     test1626_1123 = is_a__118___object(aux_1710, fun_ast_var);
							  }
							  if (test1626_1123)
							    {
							       bool_t test_1717;
							       {
								  obj_t aux_1718;
								  aux_1718 = CNST_TABLE_REF(((long) 2));
								  test_1717 = (site_6 == aux_1718);
							       }
							       if (test_1717)
								 {
								    test1618_1116 = ((bool_t) 0);
								 }
							       else
								 {
								    test1618_1116 = ((bool_t) 1);
								 }
							    }
							  else
							    {
							       test1618_1116 = ((bool_t) 0);
							    }
						       }
						       if (test1618_1116)
							 {
							    obj_t arg1620_1117;
							    type_t arg1621_1118;
							    {
							       node_t obj_1388;
							       obj_1388 = (node_t) (node_1105);
							       arg1620_1117 = (((node_t) CREF(obj_1388))->loc);
							    }
							    {
							       node_t obj_1389;
							       obj_1389 = (node_t) (node_1105);
							       arg1621_1118 = (((node_t) CREF(obj_1389))->type);
							    }
							    {
							       closure_t res1779_1400;
							       {
								  variable_t variable_1392;
								  variable_1392 = (variable_t) (alpha_1109);
								  {
								     closure_t new1214_1393;
								     new1214_1393 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
								     {
									long arg1553_1394;
									arg1553_1394 = class_num_218___object(closure_ast_node);
									{
									   obj_t obj_1398;
									   obj_1398 = (obj_t) (new1214_1393);
									   (((obj_t) CREF(obj_1398))->header = MAKE_HEADER(arg1553_1394, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_1731;
									aux_1731 = (object_t) (new1214_1393);
									OBJECT_WIDENING_SET(aux_1731, BFALSE);
								     }
								     ((((closure_t) CREF(new1214_1393))->loc) = ((obj_t) arg1620_1117), BUNSPEC);
								     ((((closure_t) CREF(new1214_1393))->type) = ((type_t) arg1621_1118), BUNSPEC);
								     ((((closure_t) CREF(new1214_1393))->variable) = ((variable_t) variable_1392), BUNSPEC);
								     res1779_1400 = new1214_1393;
								  }
							       }
							       aux_1685 = (obj_t) (res1779_1400);
							    }
							 }
						       else
							 {
							    obj_t arg1623_1120;
							    type_t arg1624_1121;
							    {
							       node_t obj_1401;
							       obj_1401 = (node_t) (node_1105);
							       arg1623_1120 = (((node_t) CREF(obj_1401))->loc);
							    }
							    {
							       node_t obj_1402;
							       obj_1402 = (node_t) (node_1105);
							       arg1624_1121 = (((node_t) CREF(obj_1402))->type);
							    }
							    {
							       var_t res1780_1413;
							       {
								  variable_t variable_1405;
								  variable_1405 = (variable_t) (alpha_1109);
								  {
								     var_t new1206_1406;
								     new1206_1406 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								     {
									long arg1555_1407;
									arg1555_1407 = class_num_218___object(var_ast_node);
									{
									   obj_t obj_1411;
									   obj_1411 = (obj_t) (new1206_1406);
									   (((obj_t) CREF(obj_1411))->header = MAKE_HEADER(arg1555_1407, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_1747;
									aux_1747 = (object_t) (new1206_1406);
									OBJECT_WIDENING_SET(aux_1747, BFALSE);
								     }
								     ((((var_t) CREF(new1206_1406))->loc) = ((obj_t) arg1623_1120), BUNSPEC);
								     ((((var_t) CREF(new1206_1406))->type) = ((type_t) arg1624_1121), BUNSPEC);
								     ((((var_t) CREF(new1206_1406))->variable) = ((variable_t) variable_1405), BUNSPEC);
								     res1780_1413 = new1206_1406;
								  }
							       }
							       aux_1685 = (obj_t) (res1780_1413);
							    }
							 }
						    }
						 }
					       else
						 {
						    bool_t test1631_1127;
						    test1631_1127 = is_a__118___object(alpha_1109, atom_ast_node);
						    if (test1631_1127)
						      {
							 aux_1685 = alpha_1109;
						      }
						    else
						      {
							 {
							    obj_t arg1634_1130;
							    arg1634_1130 = shape_tools_shape((obj_t) (node_1105));
							    aux_1685 = internal_error_43_tools_error(string1785_ast_substitute, string1786_ast_substitute, arg1634_1130);
							 }
						      }
						 }
					    }
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    kwote_t aux_1760;
			    aux_1760 = (kwote_t) (node_5);
			    aux_1685 = (obj_t) (aux_1760);
			 }
			 break;
		      case ((long) 3):
			 {
			    sequence_t node_1133;
			    node_1133 = (sequence_t) (node_5);
			    do_substitute___56_ast_substitute((((sequence_t) CREF(node_1133))->nodes), site_6);
			    aux_1685 = (obj_t) (node_1133);
			 }
			 break;
		      case ((long) 4):
			 {
			    app_t node_1136;
			    node_1136 = (app_t) (node_5);
			    {
			       node_t arg1638_1138;
			       {
				  node_t aux_1768;
				  {
				     var_t aux_1769;
				     aux_1769 = (((app_t) CREF(node_1136))->fun);
				     aux_1768 = (node_t) (aux_1769);
				  }
				  arg1638_1138 = do_substitute__77_ast_substitute(aux_1768, CNST_TABLE_REF(((long) 2)));
			       }
			       {
				  var_t val1252_1418;
				  val1252_1418 = (var_t) (arg1638_1138);
				  ((((app_t) CREF(node_1136))->fun) = ((var_t) val1252_1418), BUNSPEC);
			       }
			    }
			    do_substitute___56_ast_substitute((((app_t) CREF(node_1136))->args), CNST_TABLE_REF(((long) 1)));
			    aux_1685 = (obj_t) (node_1136);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_1143;
			    node_1143 = (app_ly_162_t) (node_5);
			    {
			       node_t nfun_1146;
			       node_t narg_1147;
			       nfun_1146 = do_substitute__77_ast_substitute((((app_ly_162_t) CREF(node_1143))->fun), CNST_TABLE_REF(((long) 3)));
			       narg_1147 = do_substitute__77_ast_substitute((((app_ly_162_t) CREF(node_1143))->arg), CNST_TABLE_REF(((long) 1)));
			       {
				  bool_t test1646_1148;
				  test1646_1148 = is_a__118___object((obj_t) (nfun_1146), closure_ast_node);
				  if (test1646_1148)
				    {
				       obj_t arg1648_1150;
				       var_t arg1649_1151;
				       arg1648_1150 = (((app_ly_162_t) CREF(node_1143))->loc);
				       {
					  var_t duplicated1443_1152;
					  duplicated1443_1152 = (var_t) (nfun_1146);
					  {
					     var_t new1444_1153;
					     {
						obj_t arg1650_1154;
						type_t arg1652_1155;
						variable_t arg1653_1156;
						arg1650_1154 = (((var_t) CREF(duplicated1443_1152))->loc);
						arg1652_1155 = (((var_t) CREF(duplicated1443_1152))->type);
						arg1653_1156 = (((var_t) CREF(duplicated1443_1152))->variable);
						{
						   var_t res1781_1437;
						   {
						      var_t new1206_1430;
						      new1206_1430 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						      {
							 long arg1555_1431;
							 arg1555_1431 = class_num_218___object(var_ast_node);
							 {
							    obj_t obj_1435;
							    obj_1435 = (obj_t) (new1206_1430);
							    (((obj_t) CREF(obj_1435))->header = MAKE_HEADER(arg1555_1431, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_1799;
							 aux_1799 = (object_t) (new1206_1430);
							 OBJECT_WIDENING_SET(aux_1799, BFALSE);
						      }
						      ((((var_t) CREF(new1206_1430))->loc) = ((obj_t) arg1650_1154), BUNSPEC);
						      ((((var_t) CREF(new1206_1430))->type) = ((type_t) arg1652_1155), BUNSPEC);
						      ((((var_t) CREF(new1206_1430))->variable) = ((variable_t) arg1653_1156), BUNSPEC);
						      res1781_1437 = new1206_1430;
						   }
						   new1444_1153 = res1781_1437;
						}
					     }
					     {
						arg1649_1151 = new1444_1153;
					     }
					  }
				       }
				       {
					  node_t aux_1805;
					  aux_1805 = known_app_ly__node_26_ast_apply(BNIL, arg1648_1150, (node_t) (arg1649_1151), narg_1147, site_6);
					  aux_1685 = (obj_t) (aux_1805);
				       }
				    }
				  else
				    {
				       ((((app_ly_162_t) CREF(node_1143))->fun) = ((node_t) nfun_1146), BUNSPEC);
				       ((((app_ly_162_t) CREF(node_1143))->arg) = ((node_t) narg_1147), BUNSPEC);
				       aux_1685 = (obj_t) (node_1143);
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_1161;
			    node_1161 = (funcall_t) (node_5);
			    {
			       node_t nfun_1164;
			       obj_t nargs_1165;
			       nfun_1164 = do_substitute__77_ast_substitute((((funcall_t) CREF(node_1161))->fun), CNST_TABLE_REF(((long) 1)));
			       {
				  obj_t l1446_1184;
				  l1446_1184 = (((funcall_t) CREF(node_1161))->args);
				  if (NULLP(l1446_1184))
				    {
				       nargs_1165 = BNIL;
				    }
				  else
				    {
				       obj_t head1448_1186;
				       head1448_1186 = MAKE_PAIR(BNIL, BNIL);
				       {
					  obj_t l1446_1187;
					  obj_t tail1449_1188;
					  l1446_1187 = l1446_1184;
					  tail1449_1188 = head1448_1186;
					lname1447_1189:
					  if (NULLP(l1446_1187))
					    {
					       nargs_1165 = CDR(head1448_1186);
					    }
					  else
					    {
					       obj_t newtail1450_1191;
					       {
						  node_t arg1682_1193;
						  {
						     node_t aux_1823;
						     {
							obj_t aux_1824;
							aux_1824 = CAR(l1446_1187);
							aux_1823 = (node_t) (aux_1824);
						     }
						     arg1682_1193 = do_substitute__77_ast_substitute(aux_1823, CNST_TABLE_REF(((long) 1)));
						  }
						  {
						     obj_t aux_1829;
						     aux_1829 = (obj_t) (arg1682_1193);
						     newtail1450_1191 = MAKE_PAIR(aux_1829, BNIL);
						  }
					       }
					       SET_CDR(tail1449_1188, newtail1450_1191);
					       {
						  obj_t tail1449_1835;
						  obj_t l1446_1833;
						  l1446_1833 = CDR(l1446_1187);
						  tail1449_1835 = newtail1450_1191;
						  tail1449_1188 = tail1449_1835;
						  l1446_1187 = l1446_1833;
						  goto lname1447_1189;
					       }
					    }
				       }
				    }
			       }
			       {
				  bool_t test1658_1166;
				  {
				     bool_t test1674_1178;
				     test1674_1178 = is_a__118___object((obj_t) (nfun_1164), closure_ast_node);
				     if (test1674_1178)
				       {
					  test1658_1166 = ((bool_t) 1);
				       }
				     else
				       {
					  bool_t _andtest_1451_1179;
					  _andtest_1451_1179 = is_a__118___object((obj_t) (nfun_1164), var_ast_node);
					  if (_andtest_1451_1179)
					    {
					       obj_t aux_1842;
					       {
						  value_t aux_1843;
						  {
						     variable_t arg1676_1181;
						     {
							var_t obj_1457;
							obj_1457 = (var_t) (nfun_1164);
							arg1676_1181 = (((var_t) CREF(obj_1457))->variable);
						     }
						     aux_1843 = (((variable_t) CREF(arg1676_1181))->value);
						  }
						  aux_1842 = (obj_t) (aux_1843);
					       }
					       test1658_1166 = is_a__118___object(aux_1842, fun_ast_var);
					    }
					  else
					    {
					       test1658_1166 = ((bool_t) 0);
					    }
				       }
				  }
				  if (test1658_1166)
				    {
				       bool_t test1659_1167;
				       {
					  variable_t aux_1850;
					  {
					     var_t obj_1460;
					     obj_1460 = (var_t) (nfun_1164);
					     aux_1850 = (((var_t) CREF(obj_1460))->variable);
					  }
					  test1659_1167 = correct_arity_app__187_ast_app(aux_1850, CDR(nargs_1165));
				       }
				       if (test1659_1167)
					 {
					    node_t aux_1856;
					    aux_1856 = make_app_node_80_ast_app(BNIL, (((funcall_t) CREF(node_1161))->loc), (var_t) (nfun_1164), CDR(nargs_1165));
					    aux_1685 = (obj_t) (aux_1856);
					 }
				       else
					 {
					    obj_t arg1666_1171;
					    obj_t arg1669_1174;
					    arg1666_1171 = (((funcall_t) CREF(node_1161))->loc);
					    arg1669_1174 = shape_tools_shape((obj_t) (node_1161));
					    aux_1685 = user_error_location_137_tools_error(arg1666_1171, string1787_ast_substitute, string1788_ast_substitute, arg1669_1174, BNIL);
					 }
				    }
				  else
				    {
				       ((((funcall_t) CREF(node_1161))->fun) = ((node_t) nfun_1164), BUNSPEC);
				       ((((funcall_t) CREF(node_1161))->args) = ((obj_t) nargs_1165), BUNSPEC);
				       aux_1685 = (obj_t) (node_1161);
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1199;
			    node_1199 = (pragma_t) (node_5);
			    do_substitute___56_ast_substitute((((pragma_t) CREF(node_1199))->args), site_6);
			    aux_1685 = (obj_t) (node_1199);
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_1202;
			    node_1202 = (cast_t) (node_5);
			    do_substitute__77_ast_substitute((((cast_t) CREF(node_1202))->arg), site_6);
			    aux_1685 = (obj_t) (node_1202);
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_t node_1205;
			    node_1205 = (setq_t) (node_5);
			    {
			       node_t arg1691_1208;
			       {
				  node_t aux_1878;
				  {
				     var_t aux_1879;
				     aux_1879 = (((setq_t) CREF(node_1205))->var);
				     aux_1878 = (node_t) (aux_1879);
				  }
				  arg1691_1208 = do_substitute__77_ast_substitute(aux_1878, CNST_TABLE_REF(((long) 4)));
			       }
			       {
				  var_t val1306_1473;
				  val1306_1473 = (var_t) (arg1691_1208);
				  ((((setq_t) CREF(node_1205))->var) = ((var_t) val1306_1473), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1694_1211;
			       arg1694_1211 = do_substitute__77_ast_substitute((((setq_t) CREF(node_1205))->value), site_6);
			       ((((setq_t) CREF(node_1205))->value) = ((node_t) arg1694_1211), BUNSPEC);
			    }
			    aux_1685 = (obj_t) (node_1205);
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_t node_1213;
			    node_1213 = (conditional_t) (node_5);
			    {
			       node_t arg1697_1216;
			       arg1697_1216 = do_substitute__77_ast_substitute((((conditional_t) CREF(node_1213))->test), CNST_TABLE_REF(((long) 1)));
			       ((((conditional_t) CREF(node_1213))->test) = ((node_t) arg1697_1216), BUNSPEC);
			    }
			    {
			       node_t arg1700_1219;
			       arg1700_1219 = do_substitute__77_ast_substitute((((conditional_t) CREF(node_1213))->true), site_6);
			       ((((conditional_t) CREF(node_1213))->true) = ((node_t) arg1700_1219), BUNSPEC);
			    }
			    {
			       node_t arg1702_1221;
			       arg1702_1221 = do_substitute__77_ast_substitute((((conditional_t) CREF(node_1213))->false), site_6);
			       ((((conditional_t) CREF(node_1213))->false) = ((node_t) arg1702_1221), BUNSPEC);
			    }
			    aux_1685 = (obj_t) (node_1213);
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_t node_1223;
			    node_1223 = (fail_t) (node_5);
			    {
			       node_t arg1704_1226;
			       arg1704_1226 = do_substitute__77_ast_substitute((((fail_t) CREF(node_1223))->proc), CNST_TABLE_REF(((long) 1)));
			       ((((fail_t) CREF(node_1223))->proc) = ((node_t) arg1704_1226), BUNSPEC);
			    }
			    {
			       node_t arg1707_1229;
			       arg1707_1229 = do_substitute__77_ast_substitute((((fail_t) CREF(node_1223))->msg), CNST_TABLE_REF(((long) 1)));
			       ((((fail_t) CREF(node_1223))->msg) = ((node_t) arg1707_1229), BUNSPEC);
			    }
			    {
			       node_t arg1710_1232;
			       arg1710_1232 = do_substitute__77_ast_substitute((((fail_t) CREF(node_1223))->obj), CNST_TABLE_REF(((long) 1)));
			       ((((fail_t) CREF(node_1223))->obj) = ((node_t) arg1710_1232), BUNSPEC);
			    }
			    aux_1685 = (obj_t) (node_1223);
			 }
			 break;
		      case ((long) 12):
			 {
			    select_t node_1235;
			    node_1235 = (select_t) (node_5);
			    {
			       node_t arg1713_1237;
			       arg1713_1237 = do_substitute__77_ast_substitute((((select_t) CREF(node_1235))->test), CNST_TABLE_REF(((long) 1)));
			       ((((select_t) CREF(node_1235))->test) = ((node_t) arg1713_1237), BUNSPEC);
			    }
			    {
			       obj_t l1455_1240;
			       l1455_1240 = (((select_t) CREF(node_1235))->clauses);
			     lname1456_1241:
			       if (PAIRP(l1455_1240))
				 {
				    {
				       obj_t clause_1244;
				       clause_1244 = CAR(l1455_1240);
				       {
					  node_t arg1720_1245;
					  {
					     node_t aux_1924;
					     {
						obj_t aux_1925;
						aux_1925 = CDR(clause_1244);
						aux_1924 = (node_t) (aux_1925);
					     }
					     arg1720_1245 = do_substitute__77_ast_substitute(aux_1924, site_6);
					  }
					  {
					     obj_t aux_1929;
					     aux_1929 = (obj_t) (arg1720_1245);
					     SET_CDR(clause_1244, aux_1929);
					  }
				       }
				    }
				    {
				       obj_t l1455_1932;
				       l1455_1932 = CDR(l1455_1240);
				       l1455_1240 = l1455_1932;
				       goto lname1456_1241;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_1685 = (obj_t) (node_1235);
			 }
			 break;
		      case ((long) 13):
			 {
			    let_fun_218_t node_1248;
			    node_1248 = (let_fun_218_t) (node_5);
			    {
			       obj_t l1457_1250;
			       l1457_1250 = (((let_fun_218_t) CREF(node_1248))->locals);
			     lname1458_1251:
			       if (PAIRP(l1457_1250))
				 {
				    {
				       value_t fun_1255;
				       {
					  local_t obj_1508;
					  {
					     obj_t aux_1939;
					     aux_1939 = CAR(l1457_1250);
					     obj_1508 = (local_t) (aux_1939);
					  }
					  fun_1255 = (((local_t) CREF(obj_1508))->value);
				       }
				       {
					  node_t arg1725_1256;
					  {
					     node_t aux_1943;
					     {
						obj_t aux_1944;
						{
						   sfun_t obj_1509;
						   obj_1509 = (sfun_t) (fun_1255);
						   aux_1944 = (((sfun_t) CREF(obj_1509))->body);
						}
						aux_1943 = (node_t) (aux_1944);
					     }
					     arg1725_1256 = do_substitute__77_ast_substitute(aux_1943, CNST_TABLE_REF(((long) 1)));
					  }
					  {
					     sfun_t obj_1510;
					     obj_t val1135_1511;
					     obj_1510 = (sfun_t) (fun_1255);
					     val1135_1511 = (obj_t) (arg1725_1256);
					     ((((sfun_t) CREF(obj_1510))->body) = ((obj_t) val1135_1511), BUNSPEC);
					  }
				       }
				    }
				    {
				       obj_t l1457_1953;
				       l1457_1953 = CDR(l1457_1250);
				       l1457_1250 = l1457_1953;
				       goto lname1458_1251;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1729_1260;
			       arg1729_1260 = do_substitute__77_ast_substitute((((let_fun_218_t) CREF(node_1248))->body), site_6);
			       ((((let_fun_218_t) CREF(node_1248))->body) = ((node_t) arg1729_1260), BUNSPEC);
			    }
			    aux_1685 = (obj_t) (node_1248);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_var_6_t node_1262;
			    node_1262 = (let_var_6_t) (node_5);
			    {
			       obj_t l1459_1264;
			       l1459_1264 = (((let_var_6_t) CREF(node_1262))->bindings);
			     lname1460_1265:
			       if (PAIRP(l1459_1264))
				 {
				    {
				       obj_t binding_1268;
				       binding_1268 = CAR(l1459_1264);
				       {
					  node_t arg1733_1269;
					  {
					     node_t aux_1964;
					     {
						obj_t aux_1965;
						aux_1965 = CDR(binding_1268);
						aux_1964 = (node_t) (aux_1965);
					     }
					     arg1733_1269 = do_substitute__77_ast_substitute(aux_1964, CNST_TABLE_REF(((long) 1)));
					  }
					  {
					     obj_t aux_1970;
					     aux_1970 = (obj_t) (arg1733_1269);
					     SET_CDR(binding_1268, aux_1970);
					  }
				       }
				    }
				    {
				       obj_t l1459_1973;
				       l1459_1973 = CDR(l1459_1264);
				       l1459_1264 = l1459_1973;
				       goto lname1460_1265;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1743_1273;
			       arg1743_1273 = do_substitute__77_ast_substitute((((let_var_6_t) CREF(node_1262))->body), site_6);
			       ((((let_var_6_t) CREF(node_1262))->body) = ((node_t) arg1743_1273), BUNSPEC);
			    }
			    aux_1685 = (obj_t) (node_1262);
			 }
			 break;
		      case ((long) 15):
			 {
			    set_ex_it_116_t node_1275;
			    node_1275 = (set_ex_it_116_t) (node_5);
			    {
			       node_t arg1745_1277;
			       arg1745_1277 = do_substitute__77_ast_substitute((((set_ex_it_116_t) CREF(node_1275))->body), site_6);
			       ((((set_ex_it_116_t) CREF(node_1275))->body) = ((node_t) arg1745_1277), BUNSPEC);
			    }
			    aux_1685 = (obj_t) (node_1275);
			 }
			 break;
		      case ((long) 16):
			 {
			    jump_ex_it_184_t node_1279;
			    node_1279 = (jump_ex_it_184_t) (node_5);
			    {
			       node_t arg1747_1281;
			       arg1747_1281 = do_substitute__77_ast_substitute((((jump_ex_it_184_t) CREF(node_1279))->exit), CNST_TABLE_REF(((long) 2)));
			       ((((jump_ex_it_184_t) CREF(node_1279))->exit) = ((node_t) arg1747_1281), BUNSPEC);
			    }
			    {
			       node_t arg1753_1284;
			       arg1753_1284 = do_substitute__77_ast_substitute((((jump_ex_it_184_t) CREF(node_1279))->value), CNST_TABLE_REF(((long) 1)));
			       ((((jump_ex_it_184_t) CREF(node_1279))->value) = ((node_t) arg1753_1284), BUNSPEC);
			    }
			    aux_1685 = (obj_t) (node_1279);
			 }
			 break;
		      case ((long) 17):
			 {
			    make_box_202_t node_1287;
			    node_1287 = (make_box_202_t) (node_5);
			    {
			       node_t arg1759_1289;
			       arg1759_1289 = do_substitute__77_ast_substitute((((make_box_202_t) CREF(node_1287))->value), CNST_TABLE_REF(((long) 1)));
			       ((((make_box_202_t) CREF(node_1287))->value) = ((node_t) arg1759_1289), BUNSPEC);
			    }
			    aux_1685 = (obj_t) (node_1287);
			 }
			 break;
		      case ((long) 18):
			 {
			    box_ref_242_t node_1292;
			    node_1292 = (box_ref_242_t) (node_5);
			    {
			       node_t arg1762_1294;
			       {
				  node_t aux_2002;
				  {
				     var_t aux_2003;
				     aux_2003 = (((box_ref_242_t) CREF(node_1292))->var);
				     aux_2002 = (node_t) (aux_2003);
				  }
				  arg1762_1294 = do_substitute__77_ast_substitute(aux_2002, CNST_TABLE_REF(((long) 1)));
			       }
			       {
				  var_t val1423_1540;
				  val1423_1540 = (var_t) (arg1762_1294);
				  ((((box_ref_242_t) CREF(node_1292))->var) = ((var_t) val1423_1540), BUNSPEC);
			       }
			    }
			    aux_1685 = (obj_t) (node_1292);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_set__221_t node_1297;
			    node_1297 = (box_set__221_t) (node_5);
			    {
			       node_t arg1767_1299;
			       {
				  node_t aux_2012;
				  {
				     var_t aux_2013;
				     aux_2013 = (((box_set__221_t) CREF(node_1297))->var);
				     aux_2012 = (node_t) (aux_2013);
				  }
				  arg1767_1299 = do_substitute__77_ast_substitute(aux_2012, CNST_TABLE_REF(((long) 1)));
			       }
			       {
				  var_t val1432_1543;
				  val1432_1543 = (var_t) (arg1767_1299);
				  ((((box_set__221_t) CREF(node_1297))->var) = ((var_t) val1432_1543), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1770_1302;
			       arg1770_1302 = do_substitute__77_ast_substitute((((box_set__221_t) CREF(node_1297))->value), CNST_TABLE_REF(((long) 1)));
			       ((((box_set__221_t) CREF(node_1297))->value) = ((node_t) arg1770_1302), BUNSPEC);
			    }
			    aux_1685 = (obj_t) (node_1297);
			 }
			 break;
		      default:
		       case_else1607_1100:
			 if (PROCEDUREP(method1601_1096))
			   {
			      aux_1685 = PROCEDURE_ENTRY(method1601_1096) (method1601_1096, (obj_t) (node_5), site_6, BEOA);
			   }
			 else
			   {
			      obj_t fun1594_1090;
			      fun1594_1090 = PROCEDURE_REF(do_substitute__env_169_ast_substitute, ((long) 0));
			      aux_1685 = PROCEDURE_ENTRY(fun1594_1090) (fun1594_1090, (obj_t) (node_5), site_6, BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1607_1100;
		 }
	    }
	    return (node_t) (aux_1685);
	 }
      }
   }
}


/* _do-substitute!1784 */ obj_t 
_do_substitute_1784_3_ast_substitute(obj_t env_1559, obj_t node_1560, obj_t site_1561)
{
   {
      node_t aux_2037;
      aux_2037 = do_substitute__77_ast_substitute((node_t) (node_1560), site_1561);
      return (obj_t) (aux_2037);
   }
}


/* do-substitute!-default1462 */ node_t 
do_substitute__default1462_120_ast_substitute(node_t node_7, obj_t site_8)
{
   FAILURE(CNST_TABLE_REF(((long) 5)), string1789_ast_substitute, (obj_t) (node_7));
}


/* _do-substitute!-default1462 */ obj_t 
_do_substitute__default1462_221_ast_substitute(obj_t env_1562, obj_t node_1563, obj_t site_1564)
{
   {
      node_t aux_2044;
      aux_2044 = do_substitute__default1462_120_ast_substitute((node_t) (node_1563), site_1564);
      return (obj_t) (aux_2044);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_substitute()
{
   module_initialization_70_tools_trace(((long) 0), "AST_SUBSTITUTE");
   module_initialization_70_type_type(((long) 0), "AST_SUBSTITUTE");
   module_initialization_70_type_cache(((long) 0), "AST_SUBSTITUTE");
   module_initialization_70_ast_var(((long) 0), "AST_SUBSTITUTE");
   module_initialization_70_ast_node(((long) 0), "AST_SUBSTITUTE");
   module_initialization_70_tools_shape(((long) 0), "AST_SUBSTITUTE");
   module_initialization_70_tools_error(((long) 0), "AST_SUBSTITUTE");
   module_initialization_70_ast_apply(((long) 0), "AST_SUBSTITUTE");
   module_initialization_70_ast_app(((long) 0), "AST_SUBSTITUTE");
   return module_initialization_70_ast_sexp(((long) 0), "AST_SUBSTITUTE");
}
