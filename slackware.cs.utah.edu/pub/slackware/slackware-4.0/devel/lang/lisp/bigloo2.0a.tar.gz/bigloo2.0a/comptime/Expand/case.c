/*===========================================================================*/
/*   (Expand/case.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_expand_case();
static obj_t type_test_66_expand_case(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _expand_case_152_expand_case(obj_t, obj_t, obj_t);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
static obj_t do_cnst_case_140_expand_case(obj_t, obj_t, obj_t);
extern obj_t expand_case_249_expand_case(obj_t, obj_t);
static bool_t type_match__71_expand_case(obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t module_initialization_70_expand_case(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static obj_t general_expand_case(obj_t, obj_t);
static obj_t case_type_186_expand_case(obj_t, obj_t);
static obj_t imported_modules_init_94_expand_case();
extern obj_t normalize_progn_143_tools_progn(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_case();
static obj_t loop_1657_expand_case(obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t loop_expand_case(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t do_generic_case_59_expand_case(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_expand_case = BUNSPEC;
static obj_t cnst_init_137_expand_case();
static obj_t do_typed_case_38_expand_case(obj_t, obj_t, obj_t, obj_t);
static obj_t __cnst[20];

DEFINE_EXPORT_PROCEDURE(expand_case_env_215_expand_case, _expand_case_152_expand_case1669, _expand_case_152_expand_case, 0L, 2);
DEFINE_STRING(string1663_expand_case, string1663_expand_case1670, "MEMQ QUOTE EQ? CASE-VALUE C-FIXNUM? C-CHAR? LABELS CNST->INTEGER CNST? IF LET CASE AUX ELSE ETHEROGENEOUS FAIL-TYPE CNST CHAR LONG INTEGER ", 139);
DEFINE_STRING(string1662_expand_case, string1662_expand_case1671, "Unknown `case' type", 19);
DEFINE_STRING(string1661_expand_case, string1661_expand_case1672, "type-test", 9);
DEFINE_STRING(string1659_expand_case, string1659_expand_case1673, "Illegal `case' form", 19);
DEFINE_STRING(string1660_expand_case, string1660_expand_case1674, "case_else", 9);
DEFINE_STRING(string1658_expand_case, string1658_expand_case1675, "case", 4);


/* module-initialization */ obj_t 
module_initialization_70_expand_case(long checksum_768, char *from_769)
{
   if (CBOOL(require_initialization_114_expand_case))
     {
	require_initialization_114_expand_case = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_case();
	cnst_init_137_expand_case();
	imported_modules_init_94_expand_case();
	method_init_76_expand_case();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_case()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "EXPAND_CASE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_CASE");
   module_initialization_70___reader(((long) 0), "EXPAND_CASE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_case()
{
   {
      obj_t cnst_port_138_760;
      cnst_port_138_760 = open_input_string(string1663_expand_case);
      {
	 long i_761;
	 i_761 = ((long) 19);
       loop_762:
	 {
	    bool_t test1664_763;
	    test1664_763 = (i_761 == ((long) -1));
	    if (test1664_763)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1665_764;
		    {
		       obj_t list1666_765;
		       {
			  obj_t arg1667_766;
			  arg1667_766 = BNIL;
			  list1666_765 = MAKE_PAIR(cnst_port_138_760, arg1667_766);
		       }
		       arg1665_764 = read___reader(list1666_765);
		    }
		    CNST_TABLE_SET(i_761, arg1665_764);
		 }
		 {
		    int aux_767;
		    {
		       long aux_786;
		       aux_786 = (i_761 - ((long) 1));
		       aux_767 = (int) (aux_786);
		    }
		    {
		       long i_789;
		       i_789 = (long) (aux_767);
		       i_761 = i_789;
		       goto loop_762;
		    }
		 }
	      }
	 }
      }
   }
}


/* expand-case */ obj_t 
expand_case_249_expand_case(obj_t x_1, obj_t e_2)
{
   {
      obj_t value_69;
      obj_t clauses_70;
      if (PAIRP(x_1))
	{
	   obj_t cdr_128_145_75;
	   cdr_128_145_75 = CDR(x_1);
	   if (PAIRP(cdr_128_145_75))
	     {
		value_69 = CAR(cdr_128_145_75);
		clauses_70 = CDR(cdr_128_145_75);
		{
		   obj_t case_value_58_79;
		   case_value_58_79 = case_type_186_expand_case(x_1, clauses_70);
		   {
		      bool_t test_797;
		      {
			 obj_t aux_798;
			 aux_798 = CNST_TABLE_REF(((long) 0));
			 test_797 = (case_value_58_79 == aux_798);
		      }
		      if (test_797)
			{
			   return do_typed_case_38_expand_case(CNST_TABLE_REF(((long) 1)), value_69, clauses_70, e_2);
			}
		      else
			{
			   bool_t test_803;
			   {
			      obj_t aux_804;
			      aux_804 = CNST_TABLE_REF(((long) 2));
			      test_803 = (case_value_58_79 == aux_804);
			   }
			   if (test_803)
			     {
				return do_typed_case_38_expand_case(CNST_TABLE_REF(((long) 2)), value_69, clauses_70, e_2);
			     }
			   else
			     {
				bool_t test_809;
				{
				   obj_t aux_810;
				   aux_810 = CNST_TABLE_REF(((long) 3));
				   test_809 = (case_value_58_79 == aux_810);
				}
				if (test_809)
				  {
				     return do_cnst_case_140_expand_case(value_69, clauses_70, e_2);
				  }
				else
				  {
				     return do_generic_case_59_expand_case(value_69, clauses_70, e_2);
				  }
			     }
			}
		   }
		}
	     }
	   else
	     {
	      tag_121_151_72:
		FAILURE(string1658_expand_case, string1659_expand_case, x_1);
	     }
	}
      else
	{
	   goto tag_121_151_72;
	}
   }
}


/* _expand-case */ obj_t 
_expand_case_152_expand_case(obj_t env_755, obj_t x_756, obj_t e_757)
{
   return expand_case_249_expand_case(x_756, e_757);
}


/* case-type */ obj_t 
case_type_186_expand_case(obj_t x_3, obj_t clauses_4)
{
   {
      obj_t datum_94;
      obj_t datums_96;
      {
	 obj_t clauses_98;
	 obj_t type_99;
	 clauses_98 = clauses_4;
	 type_99 = BNIL;
       loop_100:
	 if (NULLP(clauses_98))
	   {
	      return type_99;
	   }
	 else
	   {
	      obj_t exps_103;
	      obj_t datum_105;
	      obj_t exps_106;
	      {
		 obj_t e_138_2_109;
		 e_138_2_109 = CAR(clauses_98);
		 if (PAIRP(e_138_2_109))
		   {
		      bool_t test_824;
		      {
			 obj_t aux_827;
			 obj_t aux_825;
			 aux_827 = CNST_TABLE_REF(((long) 6));
			 aux_825 = CAR(e_138_2_109);
			 test_824 = (aux_825 == aux_827);
		      }
		      if (test_824)
			{
			   exps_103 = CDR(e_138_2_109);
			   {
			      bool_t test_830;
			      {
				 bool_t test_831;
				 {
				    obj_t aux_832;
				    aux_832 = CDR(clauses_98);
				    test_831 = NULLP(aux_832);
				 }
				 if (test_831)
				   {
				      test_830 = NULLP(exps_103);
				   }
				 else
				   {
				      test_830 = ((bool_t) 1);
				   }
			      }
			      if (test_830)
				{
				   FAILURE(string1658_expand_case, string1659_expand_case, x_3);
				}
			      else
				{
				   return type_99;
				}
			   }
			}
		      else
			{
			   obj_t car_149_47_113;
			   car_149_47_113 = CAR(e_138_2_109);
			   if ((car_149_47_113 == BNIL))
			     {
			      tag_137_199_108:
				FAILURE(string1658_expand_case, string1659_expand_case, x_3);
			     }
			   else
			     {
				datum_105 = car_149_47_113;
				exps_106 = CDR(e_138_2_109);
				if (NULLP(exps_106))
				  {
				     FAILURE(string1658_expand_case, string1659_expand_case, x_3);
				  }
				else
				  {
				     obj_t dtype_123;
				     datums_96 = datum_105;
				     {
					obj_t datums_147;
					obj_t type_148;
					datums_147 = datums_96;
					type_148 = BNIL;
				      loop_149:
					if (NULLP(datums_147))
					  {
					     dtype_123 = type_148;
					  }
					else
					  {
					     if (PAIRP(datums_147))
					       {
						  {
						     obj_t dtype_153;
						     datum_94 = CAR(datums_147);
						     if (INTEGERP(datum_94))
						       {
							  dtype_153 = CNST_TABLE_REF(((long) 0));
						       }
						     else
						       {
							  if (CHARP(datum_94))
							    {
							       dtype_153 = CNST_TABLE_REF(((long) 2));
							    }
							  else
							    {
							       if (CNSTP(datum_94))
								 {
								    dtype_153 = CNST_TABLE_REF(((long) 3));
								 }
							       else
								 {
								    dtype_153 = CNST_TABLE_REF(((long) 4));
								 }
							    }
						       }
						     if (type_match__71_expand_case(dtype_153, type_148))
						       {
							  obj_t type_864;
							  obj_t datums_862;
							  datums_862 = CDR(datums_147);
							  type_864 = general_expand_case(dtype_153, type_148);
							  type_148 = type_864;
							  datums_147 = datums_862;
							  goto loop_149;
						       }
						     else
						       {
							  dtype_123 = CNST_TABLE_REF(((long) 4));
						       }
						  }
					       }
					     else
					       {
						  FAILURE(string1658_expand_case, string1659_expand_case, x_3);
					       }
					  }
				     }
				     if (type_match__71_expand_case(dtype_123, type_99))
				       {
					  obj_t type_872;
					  obj_t clauses_870;
					  clauses_870 = CDR(clauses_98);
					  type_872 = general_expand_case(dtype_123, type_99);
					  type_99 = type_872;
					  clauses_98 = clauses_870;
					  goto loop_100;
				       }
				     else
				       {
					  return CNST_TABLE_REF(((long) 5));
				       }
				  }
			     }
			}
		   }
		 else
		   {
		      goto tag_137_199_108;
		   }
	      }
	   }
      }
   }
}


/* type-match? */ bool_t 
type_match__71_expand_case(obj_t type1_88, obj_t type2_89)
{
   {
      bool_t _ortest_1028_127;
      _ortest_1028_127 = NULLP(type1_88);
      if (_ortest_1028_127)
	{
	   return _ortest_1028_127;
	}
      else
	{
	   bool_t _ortest_1029_128;
	   _ortest_1029_128 = NULLP(type2_89);
	   if (_ortest_1029_128)
	     {
		return _ortest_1029_128;
	     }
	   else
	     {
		bool_t test_880;
		{
		   bool_t test_881;
		   {
		      obj_t aux_882;
		      aux_882 = CNST_TABLE_REF(((long) 4));
		      test_881 = (type1_88 == aux_882);
		   }
		   if (test_881)
		     {
			test_880 = ((bool_t) 0);
		     }
		   else
		     {
			test_880 = ((bool_t) 1);
		     }
		}
		if (test_880)
		  {
		     bool_t _ortest_1031_130;
		     _ortest_1031_130 = (type1_88 == type2_89);
		     if (_ortest_1031_130)
		       {
			  return _ortest_1031_130;
		       }
		     else
		       {
			  bool_t _ortest_1032_131;
			  {
			     bool_t test_887;
			     {
				obj_t aux_888;
				aux_888 = CNST_TABLE_REF(((long) 3));
				test_887 = (type1_88 == aux_888);
			     }
			     if (test_887)
			       {
				  obj_t aux_891;
				  aux_891 = CNST_TABLE_REF(((long) 2));
				  _ortest_1032_131 = (type2_89 == aux_891);
			       }
			     else
			       {
				  _ortest_1032_131 = ((bool_t) 0);
			       }
			  }
			  if (_ortest_1032_131)
			    {
			       return _ortest_1032_131;
			    }
			  else
			    {
			       bool_t test_895;
			       {
				  obj_t aux_896;
				  aux_896 = CNST_TABLE_REF(((long) 2));
				  test_895 = (type1_88 == aux_896);
			       }
			       if (test_895)
				 {
				    obj_t aux_899;
				    aux_899 = CNST_TABLE_REF(((long) 3));
				    return (type2_89 == aux_899);
				 }
			       else
				 {
				    return ((bool_t) 0);
				 }
			    }
		       }
		  }
		else
		  {
		     return ((bool_t) 0);
		  }
	     }
	}
   }
}


/* general */ obj_t 
general_expand_case(obj_t type1_91, obj_t type2_92)
{
   if ((type1_91 == type2_92))
     {
	return type1_91;
     }
   else
     {
	bool_t test_904;
	{
	   obj_t aux_905;
	   aux_905 = CNST_TABLE_REF(((long) 3));
	   test_904 = (type1_91 == aux_905);
	}
	if (test_904)
	  {
	     return type1_91;
	  }
	else
	  {
	     if (NULLP(type2_92))
	       {
		  return type1_91;
	       }
	     else
	       {
		  return type2_92;
	       }
	  }
     }
}


/* do-typed-case */ obj_t 
do_typed_case_38_expand_case(obj_t type_5, obj_t value_6, obj_t clauses_7, obj_t e_8)
{
   {
      obj_t else_body_107_158;
      {
	 obj_t clauses_249;
	 clauses_249 = clauses_7;
       loop_250:
	 if (NULLP(clauses_249))
	   {
	      obj_t list1305_252;
	      list1305_252 = MAKE_PAIR(BFALSE, BNIL);
	      else_body_107_158 = list1305_252;
	   }
	 else
	   {
	      obj_t body_255;
	      {
		 obj_t e_162_61_258;
		 e_162_61_258 = CAR(clauses_249);
		 if ((e_162_61_258 == BNIL))
		   {
		      else_body_107_158 = BFALSE;
		   }
		 else
		   {
		      if (PAIRP(e_162_61_258))
			{
			   bool_t test_918;
			   {
			      obj_t aux_921;
			      obj_t aux_919;
			      aux_921 = CNST_TABLE_REF(((long) 6));
			      aux_919 = CAR(e_162_61_258);
			      test_918 = (aux_919 == aux_921);
			   }
			   if (test_918)
			     {
				body_255 = CDR(e_162_61_258);
				if (NULLP(body_255))
				  {
				     else_body_107_158 = BNIL;
				  }
				else
				  {
				     obj_t head1037_268;
				     head1037_268 = MAKE_PAIR(BNIL, BNIL);
				     {
					obj_t l1035_269;
					obj_t tail1038_270;
					l1035_269 = body_255;
					tail1038_270 = head1037_268;
				      lname1036_271:
					if (NULLP(l1035_269))
					  {
					     else_body_107_158 = CDR(head1037_268);
					  }
					else
					  {
					     obj_t newtail1039_273;
					     {
						obj_t arg1321_275;
						arg1321_275 = PROCEDURE_ENTRY(e_8) (e_8, CAR(l1035_269), e_8, BEOA);
						newtail1039_273 = MAKE_PAIR(arg1321_275, BNIL);
					     }
					     SET_CDR(tail1038_270, newtail1039_273);
					     {
						obj_t tail1038_937;
						obj_t l1035_935;
						l1035_935 = CDR(l1035_269);
						tail1038_937 = newtail1039_273;
						tail1038_270 = tail1038_937;
						l1035_269 = l1035_935;
						goto lname1036_271;
					     }
					  }
				     }
				  }
			     }
			   else
			     {
			      tag_161_123_257:
				{
				   obj_t clauses_939;
				   clauses_939 = CDR(clauses_249);
				   clauses_249 = clauses_939;
				   goto loop_250;
				}
			     }
			}
		      else
			{
			   goto tag_161_123_257;
			}
		   }
	      }
	   }
      }
      {
	 obj_t else_name_111_159;
	 {
	    obj_t arg1303_248;
	    arg1303_248 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, string1660_expand_case, BEOA);
	    else_name_111_159 = mark_symbol_non_user__17_ast_ident(arg1303_248);
	 }
	 {
	    obj_t aux_160;
	    {
	       obj_t arg1301_246;
	       arg1301_246 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 7)), BEOA);
	       aux_160 = mark_symbol_non_user__17_ast_ident(arg1301_246);
	    }
	    {
	       {
		  obj_t case_161;
		  {
		     obj_t arg1216_162;
		     obj_t arg1219_163;
		     arg1216_162 = CNST_TABLE_REF(((long) 8));
		     {
			obj_t arg1224_167;
			obj_t arg1225_168;
			arg1224_167 = loop_1657_expand_case(else_name_111_159, e_8, clauses_7);
			arg1225_168 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
			arg1219_163 = append_2_18___r4_pairs_and_lists_6_3(arg1224_167, arg1225_168);
		     }
		     {
			obj_t list1220_164;
			{
			   obj_t arg1221_165;
			   arg1221_165 = MAKE_PAIR(arg1219_163, BNIL);
			   list1220_164 = MAKE_PAIR(aux_160, arg1221_165);
			}
			case_161 = cons__138___r4_pairs_and_lists_6_3(arg1216_162, list1220_164);
		     }
		  }
		  return type_test_66_expand_case(aux_160, type_5, value_6, case_161, else_body_107_158, else_name_111_159, e_8);
	       }
	    }
	 }
      }
   }
}


/* loop_1657 */ obj_t 
loop_1657_expand_case(obj_t else_name_111_759, obj_t e_758, obj_t clauses_169)
{
   if (NULLP(clauses_169))
     {
	{
	   obj_t arg1228_172;
	   {
	      obj_t arg1234_176;
	      arg1234_176 = CNST_TABLE_REF(((long) 6));
	      {
		 obj_t list1236_178;
		 {
		    obj_t arg1238_179;
		    arg1238_179 = MAKE_PAIR(BNIL, BNIL);
		    list1236_178 = MAKE_PAIR(BFALSE, arg1238_179);
		 }
		 arg1228_172 = cons__138___r4_pairs_and_lists_6_3(arg1234_176, list1236_178);
	      }
	   }
	   {
	      obj_t list1232_174;
	      list1232_174 = MAKE_PAIR(BNIL, BNIL);
	      return cons__138___r4_pairs_and_lists_6_3(arg1228_172, list1232_174);
	   }
	}
     }
   else
     {
	obj_t body_182;
	obj_t datums_184;
	obj_t body_185;
	{
	   obj_t e_173_18_188;
	   e_173_18_188 = CAR(clauses_169);
	   if ((e_173_18_188 == BNIL))
	     {
		{
		   obj_t arg1252_198;
		   {
		      obj_t arg1256_202;
		      arg1256_202 = CNST_TABLE_REF(((long) 6));
		      {
			 obj_t list1258_204;
			 {
			    obj_t arg1259_205;
			    arg1259_205 = MAKE_PAIR(BNIL, BNIL);
			    list1258_204 = MAKE_PAIR(BFALSE, arg1259_205);
			 }
			 arg1252_198 = cons__138___r4_pairs_and_lists_6_3(arg1256_202, list1258_204);
		      }
		   }
		   {
		      obj_t list1254_200;
		      list1254_200 = MAKE_PAIR(BNIL, BNIL);
		      return cons__138___r4_pairs_and_lists_6_3(arg1252_198, list1254_200);
		   }
		}
	     }
	   else
	     {
		if (PAIRP(e_173_18_188))
		  {
		     bool_t test_975;
		     {
			obj_t aux_978;
			obj_t aux_976;
			aux_978 = CNST_TABLE_REF(((long) 6));
			aux_976 = CAR(e_173_18_188);
			test_975 = (aux_976 == aux_978);
		     }
		     if (test_975)
		       {
			  body_182 = CDR(e_173_18_188);
			  {
			     obj_t arg1262_207;
			     {
				obj_t arg1267_211;
				obj_t arg1268_212;
				arg1267_211 = CNST_TABLE_REF(((long) 6));
				{
				   obj_t list1275_218;
				   list1275_218 = MAKE_PAIR(BNIL, BNIL);
				   arg1268_212 = cons__138___r4_pairs_and_lists_6_3(else_name_111_759, list1275_218);
				}
				{
				   obj_t list1270_214;
				   {
				      obj_t arg1272_215;
				      arg1272_215 = MAKE_PAIR(BNIL, BNIL);
				      list1270_214 = MAKE_PAIR(arg1268_212, arg1272_215);
				   }
				   arg1262_207 = cons__138___r4_pairs_and_lists_6_3(arg1267_211, list1270_214);
				}
			     }
			     {
				obj_t list1264_209;
				list1264_209 = MAKE_PAIR(BNIL, BNIL);
				return cons__138___r4_pairs_and_lists_6_3(arg1262_207, list1264_209);
			     }
			  }
		       }
		     else
		       {
			  datums_184 = CAR(e_173_18_188);
			  body_185 = CDR(e_173_18_188);
			  {
			     obj_t arg1278_220;
			     obj_t arg1281_221;
			     {
				obj_t arg1282_222;
				{
				   obj_t arg1285_225;
				   obj_t arg1286_226;
				   if (NULLP(body_185))
				     {
					arg1285_225 = BNIL;
				     }
				   else
				     {
					obj_t head1042_229;
					head1042_229 = MAKE_PAIR(BNIL, BNIL);
					{
					   obj_t l1040_230;
					   obj_t tail1043_231;
					   l1040_230 = body_185;
					   tail1043_231 = head1042_229;
					 lname1041_232:
					   if (NULLP(l1040_230))
					     {
						arg1285_225 = CDR(head1042_229);
					     }
					   else
					     {
						obj_t newtail1044_234;
						{
						   obj_t arg1291_236;
						   arg1291_236 = PROCEDURE_ENTRY(e_758) (e_758, CAR(l1040_230), e_758, BEOA);
						   newtail1044_234 = MAKE_PAIR(arg1291_236, BNIL);
						}
						SET_CDR(tail1043_231, newtail1044_234);
						{
						   obj_t tail1043_1003;
						   obj_t l1040_1001;
						   l1040_1001 = CDR(l1040_230);
						   tail1043_1003 = newtail1044_234;
						   tail1043_231 = tail1043_1003;
						   l1040_230 = l1040_1001;
						   goto lname1041_232;
						}
					     }
					}
				     }
				   arg1286_226 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				   arg1282_222 = append_2_18___r4_pairs_and_lists_6_3(arg1285_225, arg1286_226);
				}
				{
				   obj_t list1283_223;
				   list1283_223 = MAKE_PAIR(arg1282_222, BNIL);
				   arg1278_220 = cons__138___r4_pairs_and_lists_6_3(datums_184, list1283_223);
				}
			     }
			     arg1281_221 = loop_1657_expand_case(else_name_111_759, e_758, CDR(clauses_169));
			     return MAKE_PAIR(arg1278_220, arg1281_221);
			  }
		       }
		  }
		else
		  {
		     FAILURE(string1658_expand_case, string1659_expand_case, clauses_169);
		  }
	     }
	}
     }
}


/* do-cnst-case */ obj_t 
do_cnst_case_140_expand_case(obj_t value_9, obj_t clauses_10, obj_t e_11)
{
   {
      obj_t aux_281;
      {
	 obj_t arg1397_345;
	 arg1397_345 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 7)), BEOA);
	 aux_281 = mark_symbol_non_user__17_ast_ident(arg1397_345);
      }
      {
	 obj_t value_282;
	 {
	    obj_t arg1350_309;
	    obj_t arg1351_310;
	    obj_t arg1352_311;
	    arg1350_309 = CNST_TABLE_REF(((long) 9));
	    {
	       obj_t arg1361_317;
	       {
		  obj_t list1368_322;
		  {
		     obj_t arg1369_323;
		     arg1369_323 = MAKE_PAIR(BNIL, BNIL);
		     list1368_322 = MAKE_PAIR(value_9, arg1369_323);
		  }
		  arg1361_317 = cons__138___r4_pairs_and_lists_6_3(aux_281, list1368_322);
	       }
	       {
		  obj_t list1364_319;
		  list1364_319 = MAKE_PAIR(BNIL, BNIL);
		  arg1351_310 = cons__138___r4_pairs_and_lists_6_3(arg1361_317, list1364_319);
	       }
	    }
	    {
	       obj_t arg1372_325;
	       obj_t arg1373_326;
	       obj_t arg1375_327;
	       arg1372_325 = CNST_TABLE_REF(((long) 10));
	       {
		  obj_t arg1387_335;
		  arg1387_335 = CNST_TABLE_REF(((long) 11));
		  {
		     obj_t list1389_337;
		     {
			obj_t arg1390_338;
			arg1390_338 = MAKE_PAIR(BNIL, BNIL);
			list1389_337 = MAKE_PAIR(aux_281, arg1390_338);
		     }
		     arg1373_326 = cons__138___r4_pairs_and_lists_6_3(arg1387_335, list1389_337);
		  }
	       }
	       {
		  obj_t arg1392_340;
		  arg1392_340 = CNST_TABLE_REF(((long) 12));
		  {
		     obj_t list1394_342;
		     {
			obj_t arg1395_343;
			arg1395_343 = MAKE_PAIR(BNIL, BNIL);
			list1394_342 = MAKE_PAIR(aux_281, arg1395_343);
		     }
		     arg1375_327 = cons__138___r4_pairs_and_lists_6_3(arg1392_340, list1394_342);
		  }
	       }
	       {
		  obj_t list1380_330;
		  {
		     obj_t arg1381_331;
		     {
			obj_t arg1383_332;
			{
			   obj_t arg1384_333;
			   arg1384_333 = MAKE_PAIR(BNIL, BNIL);
			   {
			      obj_t aux_1034;
			      aux_1034 = BINT(((long) -1));
			      arg1383_332 = MAKE_PAIR(aux_1034, arg1384_333);
			   }
			}
			arg1381_331 = MAKE_PAIR(arg1375_327, arg1383_332);
		     }
		     list1380_330 = MAKE_PAIR(arg1373_326, arg1381_331);
		  }
		  arg1352_311 = cons__138___r4_pairs_and_lists_6_3(arg1372_325, list1380_330);
	       }
	    }
	    {
	       obj_t list1354_313;
	       {
		  obj_t arg1355_314;
		  {
		     obj_t arg1356_315;
		     arg1356_315 = MAKE_PAIR(BNIL, BNIL);
		     arg1355_314 = MAKE_PAIR(arg1352_311, arg1356_315);
		  }
		  list1354_313 = MAKE_PAIR(arg1351_310, arg1355_314);
	       }
	       value_282 = cons__138___r4_pairs_and_lists_6_3(arg1350_309, list1354_313);
	    }
	 }
	 {
	    {
	       obj_t c_283;
	       c_283 = clauses_10;
	     loop_284:
	       if (NULLP(c_283))
		 {
		    return do_typed_case_38_expand_case(CNST_TABLE_REF(((long) 1)), value_282, clauses_10, e_11);
		 }
	       else
		 {
		    obj_t clause_287;
		    clause_287 = CAR(c_283);
		    {
		       bool_t test_1049;
		       {
			  obj_t aux_1052;
			  obj_t aux_1050;
			  aux_1052 = CNST_TABLE_REF(((long) 6));
			  aux_1050 = CAR(clause_287);
			  test_1049 = (aux_1050 == aux_1052);
		       }
		       if (test_1049)
			 {
			    BUNSPEC;
			 }
		       else
			 {
			    obj_t arg1330_289;
			    {
			       obj_t l1045_290;
			       l1045_290 = CAR(clause_287);
			       if (NULLP(l1045_290))
				 {
				    arg1330_289 = BNIL;
				 }
			       else
				 {
				    obj_t head1047_292;
				    {
				       long arg1342_303;
				       {
					  obj_t aux_1058;
					  aux_1058 = CAR(l1045_290);
					  arg1342_303 = CCNST(aux_1058);
				       }
				       {
					  obj_t aux_1061;
					  aux_1061 = BINT(arg1342_303);
					  head1047_292 = MAKE_PAIR(aux_1061, BNIL);
				       }
				    }
				    {
				       obj_t l1045_293;
				       obj_t tail1048_294;
				       l1045_293 = CDR(l1045_290);
				       tail1048_294 = head1047_292;
				     lname1046_295:
				       if (NULLP(l1045_293))
					 {
					    arg1330_289 = head1047_292;
					 }
				       else
					 {
					    obj_t newtail1049_298;
					    {
					       long arg1337_300;
					       {
						  obj_t aux_1066;
						  aux_1066 = CAR(l1045_293);
						  arg1337_300 = CCNST(aux_1066);
					       }
					       {
						  obj_t aux_1069;
						  aux_1069 = BINT(arg1337_300);
						  newtail1049_298 = MAKE_PAIR(aux_1069, BNIL);
					       }
					    }
					    SET_CDR(tail1048_294, newtail1049_298);
					    {
					       obj_t tail1048_1075;
					       obj_t l1045_1073;
					       l1045_1073 = CDR(l1045_293);
					       tail1048_1075 = newtail1049_298;
					       tail1048_294 = tail1048_1075;
					       l1045_293 = l1045_1073;
					       goto lname1046_295;
					    }
					 }
				    }
				 }
			    }
			    SET_CAR(clause_287, arg1330_289);
			 }
		    }
		    {
		       obj_t c_1078;
		       c_1078 = CDR(c_283);
		       c_283 = c_1078;
		       goto loop_284;
		    }
		 }
	    }
	 }
      }
   }
}


/* type-test */ obj_t 
type_test_66_expand_case(obj_t aux_12, obj_t type_13, obj_t value_14, obj_t case_15, obj_t else_body_107_16, obj_t else_name_111_17, obj_t e_18)
{
   {
      bool_t test_1080;
      {
	 obj_t aux_1081;
	 aux_1081 = CNST_TABLE_REF(((long) 2));
	 test_1080 = (type_13 == aux_1081);
      }
      if (test_1080)
	{
	   {
	      obj_t arg1401_348;
	      obj_t arg1402_349;
	      obj_t arg1403_350;
	      arg1401_348 = CNST_TABLE_REF(((long) 13));
	      {
		 obj_t arg1411_356;
		 {
		    obj_t arg1417_361;
		    {
		       obj_t arg1423_365;
		       arg1423_365 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
		       arg1417_361 = append_2_18___r4_pairs_and_lists_6_3(else_body_107_16, arg1423_365);
		    }
		    {
		       obj_t list1418_362;
		       {
			  obj_t arg1419_363;
			  arg1419_363 = MAKE_PAIR(arg1417_361, BNIL);
			  list1418_362 = MAKE_PAIR(BNIL, arg1419_363);
		       }
		       arg1411_356 = cons__138___r4_pairs_and_lists_6_3(else_name_111_17, list1418_362);
		    }
		 }
		 {
		    obj_t list1414_358;
		    list1414_358 = MAKE_PAIR(BNIL, BNIL);
		    arg1402_349 = cons__138___r4_pairs_and_lists_6_3(arg1411_356, list1414_358);
		 }
	      }
	      {
		 obj_t arg1428_368;
		 obj_t arg1431_369;
		 obj_t arg1432_370;
		 arg1428_368 = CNST_TABLE_REF(((long) 9));
		 {
		    obj_t arg1440_376;
		    {
		       obj_t arg1444_380;
		       arg1444_380 = PROCEDURE_ENTRY(e_18) (e_18, value_14, e_18, BEOA);
		       {
			  obj_t list1447_382;
			  {
			     obj_t arg1448_383;
			     arg1448_383 = MAKE_PAIR(BNIL, BNIL);
			     list1447_382 = MAKE_PAIR(arg1444_380, arg1448_383);
			  }
			  arg1440_376 = cons__138___r4_pairs_and_lists_6_3(aux_12, list1447_382);
		       }
		    }
		    {
		       obj_t list1442_378;
		       list1442_378 = MAKE_PAIR(BNIL, BNIL);
		       arg1431_369 = cons__138___r4_pairs_and_lists_6_3(arg1440_376, list1442_378);
		    }
		 }
		 {
		    obj_t arg1450_385;
		    obj_t arg1453_386;
		    obj_t arg1454_387;
		    arg1450_385 = CNST_TABLE_REF(((long) 10));
		    {
		       obj_t arg1464_394;
		       arg1464_394 = CNST_TABLE_REF(((long) 14));
		       {
			  obj_t list1466_396;
			  {
			     obj_t arg1467_397;
			     arg1467_397 = MAKE_PAIR(BNIL, BNIL);
			     list1466_396 = MAKE_PAIR(aux_12, arg1467_397);
			  }
			  arg1453_386 = cons__138___r4_pairs_and_lists_6_3(arg1464_394, list1466_396);
		       }
		    }
		    {
		       obj_t list1470_400;
		       list1470_400 = MAKE_PAIR(BNIL, BNIL);
		       arg1454_387 = cons__138___r4_pairs_and_lists_6_3(else_name_111_17, list1470_400);
		    }
		    {
		       obj_t list1456_389;
		       {
			  obj_t arg1458_390;
			  {
			     obj_t arg1460_391;
			     {
				obj_t arg1461_392;
				arg1461_392 = MAKE_PAIR(BNIL, BNIL);
				arg1460_391 = MAKE_PAIR(arg1454_387, arg1461_392);
			     }
			     arg1458_390 = MAKE_PAIR(case_15, arg1460_391);
			  }
			  list1456_389 = MAKE_PAIR(arg1453_386, arg1458_390);
		       }
		       arg1432_370 = cons__138___r4_pairs_and_lists_6_3(arg1450_385, list1456_389);
		    }
		 }
		 {
		    obj_t list1434_372;
		    {
		       obj_t arg1436_373;
		       {
			  obj_t arg1437_374;
			  arg1437_374 = MAKE_PAIR(BNIL, BNIL);
			  arg1436_373 = MAKE_PAIR(arg1432_370, arg1437_374);
		       }
		       list1434_372 = MAKE_PAIR(arg1431_369, arg1436_373);
		    }
		    arg1403_350 = cons__138___r4_pairs_and_lists_6_3(arg1428_368, list1434_372);
		 }
	      }
	      {
		 obj_t list1406_352;
		 {
		    obj_t arg1407_353;
		    {
		       obj_t arg1408_354;
		       arg1408_354 = MAKE_PAIR(BNIL, BNIL);
		       arg1407_353 = MAKE_PAIR(arg1403_350, arg1408_354);
		    }
		    list1406_352 = MAKE_PAIR(arg1402_349, arg1407_353);
		 }
		 return cons__138___r4_pairs_and_lists_6_3(arg1401_348, list1406_352);
	      }
	   }
	}
      else
	{
	   bool_t test_1120;
	   {
	      obj_t aux_1121;
	      aux_1121 = CNST_TABLE_REF(((long) 1));
	      test_1120 = (type_13 == aux_1121);
	   }
	   if (test_1120)
	     {
		{
		   obj_t arg1473_403;
		   obj_t arg1474_404;
		   obj_t arg1475_405;
		   arg1473_403 = CNST_TABLE_REF(((long) 13));
		   {
		      obj_t arg1481_411;
		      {
			 obj_t arg1487_416;
			 {
			    obj_t arg1491_420;
			    arg1491_420 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
			    arg1487_416 = append_2_18___r4_pairs_and_lists_6_3(else_body_107_16, arg1491_420);
			 }
			 {
			    obj_t list1488_417;
			    {
			       obj_t arg1489_418;
			       arg1489_418 = MAKE_PAIR(arg1487_416, BNIL);
			       list1488_417 = MAKE_PAIR(BNIL, arg1489_418);
			    }
			    arg1481_411 = cons__138___r4_pairs_and_lists_6_3(else_name_111_17, list1488_417);
			 }
		      }
		      {
			 obj_t list1484_413;
			 list1484_413 = MAKE_PAIR(BNIL, BNIL);
			 arg1474_404 = cons__138___r4_pairs_and_lists_6_3(arg1481_411, list1484_413);
		      }
		   }
		   {
		      obj_t arg1496_423;
		      obj_t arg1497_424;
		      obj_t arg1498_425;
		      arg1496_423 = CNST_TABLE_REF(((long) 9));
		      {
			 obj_t arg1504_431;
			 {
			    obj_t arg1510_435;
			    arg1510_435 = PROCEDURE_ENTRY(e_18) (e_18, value_14, e_18, BEOA);
			    {
			       obj_t list1512_437;
			       {
				  obj_t arg1513_438;
				  arg1513_438 = MAKE_PAIR(BNIL, BNIL);
				  list1512_437 = MAKE_PAIR(arg1510_435, arg1513_438);
			       }
			       arg1504_431 = cons__138___r4_pairs_and_lists_6_3(aux_12, list1512_437);
			    }
			 }
			 {
			    obj_t list1506_433;
			    list1506_433 = MAKE_PAIR(BNIL, BNIL);
			    arg1497_424 = cons__138___r4_pairs_and_lists_6_3(arg1504_431, list1506_433);
			 }
		      }
		      {
			 obj_t arg1515_440;
			 obj_t arg1516_441;
			 obj_t arg1517_442;
			 arg1515_440 = CNST_TABLE_REF(((long) 10));
			 {
			    obj_t arg1527_449;
			    arg1527_449 = CNST_TABLE_REF(((long) 15));
			    {
			       obj_t list1529_451;
			       {
				  obj_t arg1530_452;
				  arg1530_452 = MAKE_PAIR(BNIL, BNIL);
				  list1529_451 = MAKE_PAIR(aux_12, arg1530_452);
			       }
			       arg1516_441 = cons__138___r4_pairs_and_lists_6_3(arg1527_449, list1529_451);
			    }
			 }
			 {
			    obj_t list1533_455;
			    list1533_455 = MAKE_PAIR(BNIL, BNIL);
			    arg1517_442 = cons__138___r4_pairs_and_lists_6_3(else_name_111_17, list1533_455);
			 }
			 {
			    obj_t list1519_444;
			    {
			       obj_t arg1522_445;
			       {
				  obj_t arg1524_446;
				  {
				     obj_t arg1525_447;
				     arg1525_447 = MAKE_PAIR(BNIL, BNIL);
				     arg1524_446 = MAKE_PAIR(arg1517_442, arg1525_447);
				  }
				  arg1522_445 = MAKE_PAIR(case_15, arg1524_446);
			       }
			       list1519_444 = MAKE_PAIR(arg1516_441, arg1522_445);
			    }
			    arg1498_425 = cons__138___r4_pairs_and_lists_6_3(arg1515_440, list1519_444);
			 }
		      }
		      {
			 obj_t list1500_427;
			 {
			    obj_t arg1501_428;
			    {
			       obj_t arg1502_429;
			       arg1502_429 = MAKE_PAIR(BNIL, BNIL);
			       arg1501_428 = MAKE_PAIR(arg1498_425, arg1502_429);
			    }
			    list1500_427 = MAKE_PAIR(arg1497_424, arg1501_428);
			 }
			 arg1475_405 = cons__138___r4_pairs_and_lists_6_3(arg1496_423, list1500_427);
		      }
		   }
		   {
		      obj_t list1477_407;
		      {
			 obj_t arg1478_408;
			 {
			    obj_t arg1479_409;
			    arg1479_409 = MAKE_PAIR(BNIL, BNIL);
			    arg1478_408 = MAKE_PAIR(arg1475_405, arg1479_409);
			 }
			 list1477_407 = MAKE_PAIR(arg1474_404, arg1478_408);
		      }
		      return cons__138___r4_pairs_and_lists_6_3(arg1473_403, list1477_407);
		   }
		}
	     }
	   else
	     {
		FAILURE(string1661_expand_case, string1662_expand_case, type_13);
	     }
	}
   }
}


/* do-generic-case */ obj_t 
do_generic_case_59_expand_case(obj_t value_19, obj_t clauses_20, obj_t e_21)
{
   {
      obj_t arg1537_459;
      {
	 obj_t arg1539_460;
	 obj_t arg1540_461;
	 obj_t arg1542_462;
	 arg1539_460 = CNST_TABLE_REF(((long) 9));
	 {
	    obj_t arg1552_468;
	    {
	       obj_t arg1556_472;
	       arg1556_472 = CNST_TABLE_REF(((long) 16));
	       {
		  obj_t list1558_474;
		  {
		     obj_t arg1559_475;
		     arg1559_475 = MAKE_PAIR(BNIL, BNIL);
		     list1558_474 = MAKE_PAIR(value_19, arg1559_475);
		  }
		  arg1552_468 = cons__138___r4_pairs_and_lists_6_3(arg1556_472, list1558_474);
	       }
	    }
	    {
	       obj_t list1554_470;
	       list1554_470 = MAKE_PAIR(BNIL, BNIL);
	       arg1540_461 = cons__138___r4_pairs_and_lists_6_3(arg1552_468, list1554_470);
	    }
	 }
	 arg1542_462 = loop_expand_case(clauses_20);
	 {
	    obj_t list1546_464;
	    {
	       obj_t arg1548_465;
	       {
		  obj_t arg1549_466;
		  arg1549_466 = MAKE_PAIR(BNIL, BNIL);
		  arg1548_465 = MAKE_PAIR(arg1542_462, arg1549_466);
	       }
	       list1546_464 = MAKE_PAIR(arg1540_461, arg1548_465);
	    }
	    arg1537_459 = cons__138___r4_pairs_and_lists_6_3(arg1539_460, list1546_464);
	 }
      }
      return PROCEDURE_ENTRY(e_21) (e_21, arg1537_459, e_21, BEOA);
   }
}


/* loop */ obj_t 
loop_expand_case(obj_t clauses_477)
{
   if (NULLP(clauses_477))
     {
	return BFALSE;
     }
   else
     {
	obj_t datums_483;
	obj_t body_484;
	obj_t datums_486;
	obj_t body_487;
	{
	   obj_t e_198_24_489;
	   e_198_24_489 = CAR(clauses_477);
	   if ((e_198_24_489 == BNIL))
	     {
		return BFALSE;
	     }
	   else
	     {
		if (PAIRP(e_198_24_489))
		  {
		     bool_t test_1182;
		     {
			obj_t aux_1185;
			obj_t aux_1183;
			aux_1185 = CNST_TABLE_REF(((long) 6));
			aux_1183 = CAR(e_198_24_489);
			test_1182 = (aux_1183 == aux_1185);
		     }
		     if (test_1182)
		       {
			  return normalize_progn_143_tools_progn(CDR(e_198_24_489));
		       }
		     else
		       {
			  obj_t car_211_103_494;
			  car_211_103_494 = CAR(e_198_24_489);
			  if (PAIRP(car_211_103_494))
			    {
			       bool_t test_1193;
			       {
				  obj_t aux_1194;
				  aux_1194 = CDR(car_211_103_494);
				  test_1193 = PAIRP(aux_1194);
			       }
			       if (test_1193)
				 {
				    datums_483 = car_211_103_494;
				    body_484 = CDR(e_198_24_489);
				    {
				       obj_t arg1588_515;
				       obj_t arg1589_516;
				       obj_t arg1592_517;
				       obj_t arg1593_518;
				       arg1588_515 = CNST_TABLE_REF(((long) 10));
				       {
					  obj_t arg1605_525;
					  obj_t arg1606_526;
					  obj_t arg1607_527;
					  arg1605_525 = CNST_TABLE_REF(((long) 19));
					  arg1606_526 = CNST_TABLE_REF(((long) 16));
					  {
					     obj_t arg1615_533;
					     arg1615_533 = CNST_TABLE_REF(((long) 18));
					     {
						obj_t list1618_535;
						{
						   obj_t arg1620_536;
						   arg1620_536 = MAKE_PAIR(BNIL, BNIL);
						   list1618_535 = MAKE_PAIR(datums_483, arg1620_536);
						}
						arg1607_527 = cons__138___r4_pairs_and_lists_6_3(arg1615_533, list1618_535);
					     }
					  }
					  {
					     obj_t list1609_529;
					     {
						obj_t arg1610_530;
						{
						   obj_t arg1612_531;
						   arg1612_531 = MAKE_PAIR(BNIL, BNIL);
						   arg1610_530 = MAKE_PAIR(arg1607_527, arg1612_531);
						}
						list1609_529 = MAKE_PAIR(arg1606_526, arg1610_530);
					     }
					     arg1589_516 = cons__138___r4_pairs_and_lists_6_3(arg1605_525, list1609_529);
					  }
				       }
				       arg1592_517 = normalize_progn_143_tools_progn(body_484);
				       arg1593_518 = loop_expand_case(CDR(clauses_477));
				       {
					  obj_t list1595_520;
					  {
					     obj_t arg1598_521;
					     {
						obj_t arg1600_522;
						{
						   obj_t arg1602_523;
						   arg1602_523 = MAKE_PAIR(BNIL, BNIL);
						   arg1600_522 = MAKE_PAIR(arg1593_518, arg1602_523);
						}
						arg1598_521 = MAKE_PAIR(arg1592_517, arg1600_522);
					     }
					     list1595_520 = MAKE_PAIR(arg1589_516, arg1598_521);
					  }
					  return cons__138___r4_pairs_and_lists_6_3(arg1588_515, list1595_520);
				       }
				    }
				 }
			       else
				 {
				    bool_t test_1217;
				    {
				       obj_t aux_1218;
				       aux_1218 = CDR(car_211_103_494);
				       test_1217 = (aux_1218 == BNIL);
				    }
				    if (test_1217)
				      {
					 datums_486 = CAR(car_211_103_494);
					 body_487 = CDR(e_198_24_489);
				       tag_197_205_488:
					 {
					    obj_t arg1623_539;
					    obj_t arg1624_540;
					    obj_t arg1625_541;
					    obj_t arg1627_542;
					    arg1623_539 = CNST_TABLE_REF(((long) 10));
					    {
					       obj_t arg1636_549;
					       obj_t arg1638_550;
					       obj_t arg1639_551;
					       arg1636_549 = CNST_TABLE_REF(((long) 17));
					       arg1638_550 = CNST_TABLE_REF(((long) 16));
					       {
						  obj_t arg1648_557;
						  arg1648_557 = CNST_TABLE_REF(((long) 18));
						  {
						     obj_t list1650_559;
						     {
							obj_t arg1652_560;
							arg1652_560 = MAKE_PAIR(BNIL, BNIL);
							list1650_559 = MAKE_PAIR(datums_486, arg1652_560);
						     }
						     arg1639_551 = cons__138___r4_pairs_and_lists_6_3(arg1648_557, list1650_559);
						  }
					       }
					       {
						  obj_t list1641_553;
						  {
						     obj_t arg1645_554;
						     {
							obj_t arg1646_555;
							arg1646_555 = MAKE_PAIR(BNIL, BNIL);
							arg1645_554 = MAKE_PAIR(arg1639_551, arg1646_555);
						     }
						     list1641_553 = MAKE_PAIR(arg1638_550, arg1645_554);
						  }
						  arg1624_540 = cons__138___r4_pairs_and_lists_6_3(arg1636_549, list1641_553);
					       }
					    }
					    arg1625_541 = normalize_progn_143_tools_progn(body_487);
					    arg1627_542 = loop_expand_case(CDR(clauses_477));
					    {
					       obj_t list1629_544;
					       {
						  obj_t arg1630_545;
						  {
						     obj_t arg1632_546;
						     {
							obj_t arg1633_547;
							arg1633_547 = MAKE_PAIR(BNIL, BNIL);
							arg1632_546 = MAKE_PAIR(arg1627_542, arg1633_547);
						     }
						     arg1630_545 = MAKE_PAIR(arg1625_541, arg1632_546);
						  }
						  list1629_544 = MAKE_PAIR(arg1624_540, arg1630_545);
					       }
					       return cons__138___r4_pairs_and_lists_6_3(arg1623_539, list1629_544);
					    }
					 }
				      }
				    else
				      {
					 return BFALSE;
				      }
				 }
			    }
			  else
			    {
			       if (PAIRP(car_211_103_494))
				 {
				    bool_t test_1244;
				    {
				       obj_t aux_1245;
				       aux_1245 = CDR(car_211_103_494);
				       test_1244 = (aux_1245 == BNIL);
				    }
				    if (test_1244)
				      {
					 obj_t body_1250;
					 obj_t datums_1248;
					 datums_1248 = CAR(car_211_103_494);
					 body_1250 = CDR(e_198_24_489);
					 body_487 = body_1250;
					 datums_486 = datums_1248;
					 goto tag_197_205_488;
				      }
				    else
				      {
					 return BFALSE;
				      }
				 }
			       else
				 {
				    return BFALSE;
				 }
			    }
		       }
		  }
		else
		  {
		     return BFALSE;
		  }
	     }
	}
     }
}


/* method-init */ obj_t 
method_init_76_expand_case()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_case()
{
   module_initialization_70_tools_trace(((long) 0), "EXPAND_CASE");
   module_initialization_70_tools_progn(((long) 0), "EXPAND_CASE");
   module_initialization_70_tools_error(((long) 0), "EXPAND_CASE");
   module_initialization_70_engine_param(((long) 0), "EXPAND_CASE");
   module_initialization_70_type_type(((long) 0), "EXPAND_CASE");
   return module_initialization_70_ast_ident(((long) 0), "EXPAND_CASE");
}
