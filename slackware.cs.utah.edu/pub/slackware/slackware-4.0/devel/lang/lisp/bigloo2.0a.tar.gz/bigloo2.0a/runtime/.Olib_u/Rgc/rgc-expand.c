/*===========================================================================*/
/*   (Rgc/rgc-expand.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t rules__regular_tree_149___rgc_rules(obj_t, obj_t);
static obj_t make_regular_parser_107___rgc_expand(obj_t, obj_t, obj_t, obj_t);
extern obj_t _res3__194___r5_control_features_6_4;
extern obj_t _res2__167___r5_control_features_6_4;
extern obj_t _res1__155___r5_control_features_6_4;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t expand_regular_grammar_0___rgc_expand(obj_t, obj_t);
static obj_t _expand_regular_grammar_168___rgc_expand(obj_t, obj_t, obj_t);
extern obj_t reset_special_match_char__38___rgc_rules();
extern obj_t module_initialization_70___rgc_expand(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___rgc_rules(long, char *);
extern obj_t module_initialization_70___rgc_tree(long, char *);
extern obj_t module_initialization_70___rgc_dfa(long, char *);
extern obj_t module_initialization_70___rgc_compile(long, char *);
extern obj_t module_initialization_70___rgc_config(long, char *);
extern obj_t compile_dfa_101___rgc_compile(obj_t, obj_t);
extern obj_t state_name_114___rgc_dfa(obj_t);
extern obj_t regular_tree__node_150___rgc_tree(obj_t);
extern obj_t expand_string_case_196___rgc_expand(obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t node__dfa_130___rgc_dfa(obj_t, obj_t, obj_t);
static obj_t _expand_string_case_129___rgc_expand(obj_t, obj_t, obj_t);
static obj_t symbol1984___rgc_expand = BUNSPEC;
static obj_t symbol1983___rgc_expand = BUNSPEC;
static obj_t symbol1979___rgc_expand = BUNSPEC;
static obj_t symbol1973___rgc_expand = BUNSPEC;
static obj_t symbol1970___rgc_expand = BUNSPEC;
static obj_t symbol1965___rgc_expand = BUNSPEC;
static obj_t symbol1964___rgc_expand = BUNSPEC;
static obj_t symbol1959___rgc_expand = BUNSPEC;
static obj_t symbol1958___rgc_expand = BUNSPEC;
static obj_t symbol1957___rgc_expand = BUNSPEC;
static obj_t symbol1952___rgc_expand = BUNSPEC;
static obj_t symbol1949___rgc_expand = BUNSPEC;
static obj_t symbol1944___rgc_expand = BUNSPEC;
static obj_t symbol1941___rgc_expand = BUNSPEC;
static obj_t symbol1939___rgc_expand = BUNSPEC;
static obj_t symbol1937___rgc_expand = BUNSPEC;
static obj_t symbol1936___rgc_expand = BUNSPEC;
static obj_t symbol1935___rgc_expand = BUNSPEC;
static obj_t symbol1931___rgc_expand = BUNSPEC;
static obj_t symbol1929___rgc_expand = BUNSPEC;
static obj_t symbol1930___rgc_expand = BUNSPEC;
static obj_t symbol1926___rgc_expand = BUNSPEC;
static obj_t symbol1924___rgc_expand = BUNSPEC;
static obj_t symbol1922___rgc_expand = BUNSPEC;
static obj_t symbol1921___rgc_expand = BUNSPEC;
static obj_t symbol1919___rgc_expand = BUNSPEC;
static obj_t symbol1920___rgc_expand = BUNSPEC;
static obj_t symbol1918___rgc_expand = BUNSPEC;
static obj_t symbol1917___rgc_expand = BUNSPEC;
static obj_t symbol1916___rgc_expand = BUNSPEC;
static obj_t symbol1915___rgc_expand = BUNSPEC;
static obj_t symbol1914___rgc_expand = BUNSPEC;
static obj_t symbol1913___rgc_expand = BUNSPEC;
static obj_t symbol1912___rgc_expand = BUNSPEC;
static obj_t symbol1911___rgc_expand = BUNSPEC;
static obj_t symbol1909___rgc_expand = BUNSPEC;
static obj_t symbol1910___rgc_expand = BUNSPEC;
static obj_t symbol1898___rgc_expand = BUNSPEC;
static obj_t symbol1908___rgc_expand = BUNSPEC;
static obj_t symbol1897___rgc_expand = BUNSPEC;
static obj_t symbol1907___rgc_expand = BUNSPEC;
static obj_t symbol1896___rgc_expand = BUNSPEC;
static obj_t symbol1906___rgc_expand = BUNSPEC;
static obj_t symbol1895___rgc_expand = BUNSPEC;
static obj_t symbol1905___rgc_expand = BUNSPEC;
static obj_t symbol1894___rgc_expand = BUNSPEC;
static obj_t symbol1904___rgc_expand = BUNSPEC;
static obj_t symbol1893___rgc_expand = BUNSPEC;
static obj_t symbol1903___rgc_expand = BUNSPEC;
static obj_t symbol1892___rgc_expand = BUNSPEC;
static obj_t symbol1902___rgc_expand = BUNSPEC;
static obj_t symbol1891___rgc_expand = BUNSPEC;
static obj_t symbol1901___rgc_expand = BUNSPEC;
static obj_t symbol1889___rgc_expand = BUNSPEC;
static obj_t symbol1890___rgc_expand = BUNSPEC;
static obj_t symbol1888___rgc_expand = BUNSPEC;
static obj_t symbol1887___rgc_expand = BUNSPEC;
static obj_t symbol1886___rgc_expand = BUNSPEC;
static obj_t symbol1885___rgc_expand = BUNSPEC;
static obj_t symbol1884___rgc_expand = BUNSPEC;
static obj_t symbol1883___rgc_expand = BUNSPEC;
static obj_t symbol1882___rgc_expand = BUNSPEC;
static obj_t symbol1878___rgc_expand = BUNSPEC;
static obj_t symbol1877___rgc_expand = BUNSPEC;
static obj_t symbol1876___rgc_expand = BUNSPEC;
static obj_t symbol1875___rgc_expand = BUNSPEC;
static obj_t symbol1874___rgc_expand = BUNSPEC;
static obj_t symbol1873___rgc_expand = BUNSPEC;
static obj_t symbol1872___rgc_expand = BUNSPEC;
static obj_t imported_modules_init_94___rgc_expand();
extern obj_t reset_dfa__30___rgc_dfa();
static obj_t list1980___rgc_expand = BUNSPEC;
static obj_t list1978___rgc_expand = BUNSPEC;
static obj_t list1977___rgc_expand = BUNSPEC;
static obj_t list1976___rgc_expand = BUNSPEC;
static obj_t list1975___rgc_expand = BUNSPEC;
static obj_t list1974___rgc_expand = BUNSPEC;
static obj_t list1972___rgc_expand = BUNSPEC;
static obj_t list1971___rgc_expand = BUNSPEC;
static obj_t list1969___rgc_expand = BUNSPEC;
static obj_t list1968___rgc_expand = BUNSPEC;
static obj_t list1967___rgc_expand = BUNSPEC;
static obj_t list1966___rgc_expand = BUNSPEC;
static obj_t list1963___rgc_expand = BUNSPEC;
static obj_t list1962___rgc_expand = BUNSPEC;
static obj_t list1961___rgc_expand = BUNSPEC;
static obj_t list1960___rgc_expand = BUNSPEC;
static obj_t list1956___rgc_expand = BUNSPEC;
static obj_t list1955___rgc_expand = BUNSPEC;
static obj_t list1954___rgc_expand = BUNSPEC;
static obj_t list1953___rgc_expand = BUNSPEC;
static obj_t list1951___rgc_expand = BUNSPEC;
static obj_t list1950___rgc_expand = BUNSPEC;
static obj_t list1948___rgc_expand = BUNSPEC;
static obj_t list1947___rgc_expand = BUNSPEC;
static obj_t list1946___rgc_expand = BUNSPEC;
static obj_t list1945___rgc_expand = BUNSPEC;
static obj_t list1943___rgc_expand = BUNSPEC;
static obj_t list1942___rgc_expand = BUNSPEC;
static obj_t list1940___rgc_expand = BUNSPEC;
static obj_t list1938___rgc_expand = BUNSPEC;
static obj_t list1934___rgc_expand = BUNSPEC;
static obj_t list1933___rgc_expand = BUNSPEC;
static obj_t list1932___rgc_expand = BUNSPEC;
static obj_t list1928___rgc_expand = BUNSPEC;
static obj_t list1927___rgc_expand = BUNSPEC;
static obj_t list1925___rgc_expand = BUNSPEC;
static obj_t list1923___rgc_expand = BUNSPEC;
static obj_t require_initialization_114___rgc_expand = BUNSPEC;
extern obj_t get_initial_state_58___rgc_dfa();
extern obj_t reset_tree__130___rgc_tree();
static obj_t cnst_init_137___rgc_expand();
static obj_t *__cnst;

DEFINE_STRING( string1985___rgc_expand, string1985___rgc_expand1987, "Illegal match", 13 );
DEFINE_STRING( string1982___rgc_expand, string1982___rgc_expand1988, "No such match", 13 );
DEFINE_STRING( string1981___rgc_expand, string1981___rgc_expand1989, "the-submatch", 12 );
DEFINE_STRING( string1899___rgc_expand, string1899___rgc_expand1990, "Illegal range", 13 );
DEFINE_STRING( string1900___rgc_expand, string1900___rgc_expand1991, "the-substring", 13 );
DEFINE_STRING( string1881___rgc_expand, string1881___rgc_expand1992, "regular-grammar", 15 );
DEFINE_STRING( string1879___rgc_expand, string1879___rgc_expand1993, "string-case", 11 );
DEFINE_STRING( string1880___rgc_expand, string1880___rgc_expand1994, "Illegal form", 12 );
DEFINE_EXPORT_PROCEDURE( expand_regular_grammar_env_93___rgc_expand, _expand_regular_grammar_168___rgc_expand1995, _expand_regular_grammar_168___rgc_expand, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( expand_string_case_env_105___rgc_expand, _expand_string_case_129___rgc_expand1996, _expand_string_case_129___rgc_expand, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___rgc_expand(long checksum_1123, char * from_1124)
{
if(CBOOL(require_initialization_114___rgc_expand)){
require_initialization_114___rgc_expand = BBOOL(((bool_t)0));
cnst_init_137___rgc_expand();
imported_modules_init_94___rgc_expand();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___rgc_expand()
{
symbol1872___rgc_expand = string_to_symbol("PORT");
symbol1873___rgc_expand = string_to_symbol("LET");
symbol1874___rgc_expand = string_to_symbol("OPEN-INPUT-STRING");
symbol1875___rgc_expand = string_to_symbol("UNWIND-PROTECT");
symbol1876___rgc_expand = string_to_symbol("READ/RP");
symbol1877___rgc_expand = string_to_symbol("REGULAR-GRAMMAR");
symbol1878___rgc_expand = string_to_symbol("CLOSE-INPUT-PORT");
symbol1882___rgc_expand = string_to_symbol("THE-RGC-CONTEXT");
symbol1883___rgc_expand = string_to_symbol("LAMBDA");
symbol1884___rgc_expand = string_to_symbol("INPUT-PORT");
symbol1885___rgc_expand = string_to_symbol("DEFINE");
symbol1886___rgc_expand = string_to_symbol("THE-PORT::INPUT-PORT");
symbol1887___rgc_expand = string_to_symbol("THE-STRING::BSTRING");
symbol1888___rgc_expand = string_to_symbol("RGC-BUFFER-SUBSTRING");
symbol1889___rgc_expand = string_to_symbol("THE-LENGTH");
symbol1890___rgc_expand = string_to_symbol("THE-SUBSTRING::BSTRING");
symbol1891___rgc_expand = string_to_symbol("MIN");
symbol1892___rgc_expand = string_to_symbol("MAX");
symbol1893___rgc_expand = string_to_symbol("IF");
symbol1894___rgc_expand = string_to_symbol("AND");
symbol1895___rgc_expand = string_to_symbol(">=FX");
symbol1896___rgc_expand = string_to_symbol("<=FX");
symbol1897___rgc_expand = string_to_symbol("ERROR");
symbol1898___rgc_expand = string_to_symbol("CONS");
symbol1901___rgc_expand = string_to_symbol("THE-LENGTH::INT");
symbol1902___rgc_expand = string_to_symbol("RGC-BUFFER-LENGTH");
symbol1903___rgc_expand = string_to_symbol("THE-FIXNUM::INT");
symbol1904___rgc_expand = string_to_symbol("RGC-BUFFER-FIXNUM");
symbol1905___rgc_expand = string_to_symbol("THE-FLONUM::REAL");
symbol1906___rgc_expand = string_to_symbol("RGC-BUFFER-FLONUM");
symbol1907___rgc_expand = string_to_symbol("THE-SYMBOL::SYMBOL");
symbol1908___rgc_expand = string_to_symbol("RGC-BUFFER-SYMBOL");
symbol1909___rgc_expand = string_to_symbol("THE-KEYWORD::KEYWORD");
symbol1910___rgc_expand = string_to_symbol("RGC-BUFFER-KEYWORD");
symbol1911___rgc_expand = string_to_symbol("THE-FAILURE");
symbol1912___rgc_expand = string_to_symbol("=FX");
symbol1913___rgc_expand = string_to_symbol("STRING-REF");
symbol1914___rgc_expand = string_to_symbol("THE-STRING");
symbol1915___rgc_expand = string_to_symbol("THE-CONTEXT");
symbol1916___rgc_expand = string_to_symbol("RGC-CONTEXT?::BOOL");
symbol1917___rgc_expand = string_to_symbol("CONTEXT");
symbol1918___rgc_expand = string_to_symbol("EQ?");
symbol1919___rgc_expand = string_to_symbol("RGC-CONTEXT");
symbol1920___rgc_expand = string_to_symbol("PAIR?");
symbol1921___rgc_expand = string_to_symbol("SET!");
symbol1922___rgc_expand = string_to_symbol("CAR");
symbol1924___rgc_expand = string_to_symbol("RGC-SUBMATCHES");
symbol1926___rgc_expand = string_to_symbol("QUOTE");
{
obj_t aux_1178;
aux_1178 = MAKE_PAIR(BNIL, BNIL);
list1925___rgc_expand = MAKE_PAIR(symbol1926___rgc_expand, aux_1178);
}
{
obj_t aux_1181;
{
obj_t aux_1182;
aux_1182 = MAKE_PAIR(list1925___rgc_expand, BNIL);
aux_1181 = MAKE_PAIR(symbol1924___rgc_expand, aux_1182);
}
list1923___rgc_expand = MAKE_PAIR(symbol1885___rgc_expand, aux_1181);
}
symbol1929___rgc_expand = string_to_symbol("RGC-SUBMATCH-START!");
symbol1930___rgc_expand = string_to_symbol("MATCH::INT");
symbol1931___rgc_expand = string_to_symbol("SUBMATCH::INT");
{
obj_t aux_1189;
{
obj_t aux_1190;
aux_1190 = MAKE_PAIR(symbol1931___rgc_expand, BNIL);
aux_1189 = MAKE_PAIR(symbol1930___rgc_expand, aux_1190);
}
list1928___rgc_expand = MAKE_PAIR(symbol1929___rgc_expand, aux_1189);
}
symbol1935___rgc_expand = string_to_symbol("VECTOR");
symbol1936___rgc_expand = string_to_symbol("MATCH");
symbol1937___rgc_expand = string_to_symbol("SUBMATCH");
symbol1939___rgc_expand = string_to_symbol("RGC-BUFFER-POSITION");
{
obj_t aux_1198;
aux_1198 = MAKE_PAIR(symbol1884___rgc_expand, BNIL);
list1938___rgc_expand = MAKE_PAIR(symbol1939___rgc_expand, aux_1198);
}
symbol1941___rgc_expand = string_to_symbol("START");
{
obj_t aux_1202;
aux_1202 = MAKE_PAIR(symbol1941___rgc_expand, BNIL);
list1940___rgc_expand = MAKE_PAIR(symbol1926___rgc_expand, aux_1202);
}
{
obj_t aux_1205;
{
obj_t aux_1206;
{
obj_t aux_1207;
{
obj_t aux_1208;
aux_1208 = MAKE_PAIR(list1940___rgc_expand, BNIL);
aux_1207 = MAKE_PAIR(list1938___rgc_expand, aux_1208);
}
aux_1206 = MAKE_PAIR(symbol1937___rgc_expand, aux_1207);
}
aux_1205 = MAKE_PAIR(symbol1936___rgc_expand, aux_1206);
}
list1934___rgc_expand = MAKE_PAIR(symbol1935___rgc_expand, aux_1205);
}
{
obj_t aux_1214;
{
obj_t aux_1215;
aux_1215 = MAKE_PAIR(symbol1924___rgc_expand, BNIL);
aux_1214 = MAKE_PAIR(list1934___rgc_expand, aux_1215);
}
list1933___rgc_expand = MAKE_PAIR(symbol1898___rgc_expand, aux_1214);
}
{
obj_t aux_1219;
{
obj_t aux_1220;
aux_1220 = MAKE_PAIR(list1933___rgc_expand, BNIL);
aux_1219 = MAKE_PAIR(symbol1924___rgc_expand, aux_1220);
}
list1932___rgc_expand = MAKE_PAIR(symbol1921___rgc_expand, aux_1219);
}
{
obj_t aux_1224;
{
obj_t aux_1225;
aux_1225 = MAKE_PAIR(list1932___rgc_expand, BNIL);
aux_1224 = MAKE_PAIR(list1928___rgc_expand, aux_1225);
}
list1927___rgc_expand = MAKE_PAIR(symbol1885___rgc_expand, aux_1224);
}
symbol1944___rgc_expand = string_to_symbol("RGC-SUBMATCH-START*!");
{
obj_t aux_1230;
{
obj_t aux_1231;
aux_1231 = MAKE_PAIR(symbol1931___rgc_expand, BNIL);
aux_1230 = MAKE_PAIR(symbol1930___rgc_expand, aux_1231);
}
list1943___rgc_expand = MAKE_PAIR(symbol1944___rgc_expand, aux_1230);
}
symbol1949___rgc_expand = string_to_symbol("START*");
{
obj_t aux_1236;
aux_1236 = MAKE_PAIR(symbol1949___rgc_expand, BNIL);
list1948___rgc_expand = MAKE_PAIR(symbol1926___rgc_expand, aux_1236);
}
{
obj_t aux_1239;
{
obj_t aux_1240;
{
obj_t aux_1241;
{
obj_t aux_1242;
aux_1242 = MAKE_PAIR(list1948___rgc_expand, BNIL);
aux_1241 = MAKE_PAIR(list1938___rgc_expand, aux_1242);
}
aux_1240 = MAKE_PAIR(symbol1937___rgc_expand, aux_1241);
}
aux_1239 = MAKE_PAIR(symbol1936___rgc_expand, aux_1240);
}
list1947___rgc_expand = MAKE_PAIR(symbol1935___rgc_expand, aux_1239);
}
{
obj_t aux_1248;
{
obj_t aux_1249;
aux_1249 = MAKE_PAIR(symbol1924___rgc_expand, BNIL);
aux_1248 = MAKE_PAIR(list1947___rgc_expand, aux_1249);
}
list1946___rgc_expand = MAKE_PAIR(symbol1898___rgc_expand, aux_1248);
}
{
obj_t aux_1253;
{
obj_t aux_1254;
aux_1254 = MAKE_PAIR(list1946___rgc_expand, BNIL);
aux_1253 = MAKE_PAIR(symbol1924___rgc_expand, aux_1254);
}
list1945___rgc_expand = MAKE_PAIR(symbol1921___rgc_expand, aux_1253);
}
{
obj_t aux_1258;
{
obj_t aux_1259;
aux_1259 = MAKE_PAIR(list1945___rgc_expand, BNIL);
aux_1258 = MAKE_PAIR(list1943___rgc_expand, aux_1259);
}
list1942___rgc_expand = MAKE_PAIR(symbol1885___rgc_expand, aux_1258);
}
symbol1952___rgc_expand = string_to_symbol("RGC-SUBMATCH-STOP!");
{
obj_t aux_1264;
{
obj_t aux_1265;
aux_1265 = MAKE_PAIR(symbol1931___rgc_expand, BNIL);
aux_1264 = MAKE_PAIR(symbol1930___rgc_expand, aux_1265);
}
list1951___rgc_expand = MAKE_PAIR(symbol1952___rgc_expand, aux_1264);
}
symbol1957___rgc_expand = string_to_symbol("STOP");
{
obj_t aux_1270;
aux_1270 = MAKE_PAIR(symbol1957___rgc_expand, BNIL);
list1956___rgc_expand = MAKE_PAIR(symbol1926___rgc_expand, aux_1270);
}
{
obj_t aux_1273;
{
obj_t aux_1274;
{
obj_t aux_1275;
{
obj_t aux_1276;
aux_1276 = MAKE_PAIR(list1956___rgc_expand, BNIL);
aux_1275 = MAKE_PAIR(list1938___rgc_expand, aux_1276);
}
aux_1274 = MAKE_PAIR(symbol1937___rgc_expand, aux_1275);
}
aux_1273 = MAKE_PAIR(symbol1936___rgc_expand, aux_1274);
}
list1955___rgc_expand = MAKE_PAIR(symbol1935___rgc_expand, aux_1273);
}
{
obj_t aux_1282;
{
obj_t aux_1283;
aux_1283 = MAKE_PAIR(symbol1924___rgc_expand, BNIL);
aux_1282 = MAKE_PAIR(list1955___rgc_expand, aux_1283);
}
list1954___rgc_expand = MAKE_PAIR(symbol1898___rgc_expand, aux_1282);
}
{
obj_t aux_1287;
{
obj_t aux_1288;
aux_1288 = MAKE_PAIR(list1954___rgc_expand, BNIL);
aux_1287 = MAKE_PAIR(symbol1924___rgc_expand, aux_1288);
}
list1953___rgc_expand = MAKE_PAIR(symbol1921___rgc_expand, aux_1287);
}
{
obj_t aux_1292;
{
obj_t aux_1293;
aux_1293 = MAKE_PAIR(list1953___rgc_expand, BNIL);
aux_1292 = MAKE_PAIR(list1951___rgc_expand, aux_1293);
}
list1950___rgc_expand = MAKE_PAIR(symbol1885___rgc_expand, aux_1292);
}
symbol1958___rgc_expand = string_to_symbol("IGNORE");
symbol1959___rgc_expand = string_to_symbol("RGC-START-MATCH!");
{
obj_t aux_1299;
{
obj_t aux_1300;
aux_1300 = MAKE_PAIR(list1925___rgc_expand, BNIL);
aux_1299 = MAKE_PAIR(symbol1924___rgc_expand, aux_1300);
}
list1960___rgc_expand = MAKE_PAIR(symbol1921___rgc_expand, aux_1299);
}
symbol1964___rgc_expand = string_to_symbol("THE-SUBMATCH");
symbol1965___rgc_expand = string_to_symbol("NUM");
{
obj_t aux_1306;
aux_1306 = MAKE_PAIR(symbol1965___rgc_expand, BNIL);
list1963___rgc_expand = MAKE_PAIR(symbol1964___rgc_expand, aux_1306);
}
{
obj_t aux_1309;
{
obj_t aux_1310;
{
obj_t aux_1311;
aux_1311 = BINT(((long)0));
aux_1310 = MAKE_PAIR(aux_1311, BNIL);
}
aux_1309 = MAKE_PAIR(symbol1965___rgc_expand, aux_1310);
}
list1967___rgc_expand = MAKE_PAIR(symbol1912___rgc_expand, aux_1309);
}
list1968___rgc_expand = MAKE_PAIR(symbol1914___rgc_expand, BNIL);
symbol1970___rgc_expand = string_to_symbol("MULTIPLE-VALUE-BIND");
{
obj_t aux_1318;
aux_1318 = MAKE_PAIR(symbol1957___rgc_expand, BNIL);
list1971___rgc_expand = MAKE_PAIR(symbol1941___rgc_expand, aux_1318);
}
symbol1973___rgc_expand = string_to_symbol("RGC-THE-SUBMATCH");
{
obj_t aux_1322;
{
obj_t aux_1323;
{
obj_t aux_1324;
{
obj_t aux_1325;
aux_1325 = MAKE_PAIR(symbol1965___rgc_expand, BNIL);
aux_1324 = MAKE_PAIR(symbol1936___rgc_expand, aux_1325);
}
aux_1323 = MAKE_PAIR(list1938___rgc_expand, aux_1324);
}
aux_1322 = MAKE_PAIR(symbol1924___rgc_expand, aux_1323);
}
list1972___rgc_expand = MAKE_PAIR(symbol1973___rgc_expand, aux_1322);
}
{
obj_t aux_1331;
{
obj_t aux_1332;
{
obj_t aux_1333;
aux_1333 = BINT(((long)0));
aux_1332 = MAKE_PAIR(aux_1333, BNIL);
}
aux_1331 = MAKE_PAIR(symbol1941___rgc_expand, aux_1332);
}
list1976___rgc_expand = MAKE_PAIR(symbol1895___rgc_expand, aux_1331);
}
{
obj_t aux_1338;
{
obj_t aux_1339;
aux_1339 = MAKE_PAIR(symbol1941___rgc_expand, BNIL);
aux_1338 = MAKE_PAIR(symbol1957___rgc_expand, aux_1339);
}
list1977___rgc_expand = MAKE_PAIR(symbol1895___rgc_expand, aux_1338);
}
{
obj_t aux_1343;
{
obj_t aux_1344;
aux_1344 = MAKE_PAIR(list1977___rgc_expand, BNIL);
aux_1343 = MAKE_PAIR(list1976___rgc_expand, aux_1344);
}
list1975___rgc_expand = MAKE_PAIR(symbol1894___rgc_expand, aux_1343);
}
symbol1979___rgc_expand = string_to_symbol("THE-SUBSTRING");
{
obj_t aux_1349;
{
obj_t aux_1350;
aux_1350 = MAKE_PAIR(symbol1957___rgc_expand, BNIL);
aux_1349 = MAKE_PAIR(symbol1941___rgc_expand, aux_1350);
}
list1978___rgc_expand = MAKE_PAIR(symbol1979___rgc_expand, aux_1349);
}
{
obj_t aux_1354;
{
obj_t aux_1355;
{
obj_t aux_1356;
aux_1356 = MAKE_PAIR(symbol1965___rgc_expand, BNIL);
aux_1355 = MAKE_PAIR(string1982___rgc_expand, aux_1356);
}
aux_1354 = MAKE_PAIR(string1981___rgc_expand, aux_1355);
}
list1980___rgc_expand = MAKE_PAIR(symbol1897___rgc_expand, aux_1354);
}
{
obj_t aux_1361;
{
obj_t aux_1362;
{
obj_t aux_1363;
aux_1363 = MAKE_PAIR(list1980___rgc_expand, BNIL);
aux_1362 = MAKE_PAIR(list1978___rgc_expand, aux_1363);
}
aux_1361 = MAKE_PAIR(list1975___rgc_expand, aux_1362);
}
list1974___rgc_expand = MAKE_PAIR(symbol1893___rgc_expand, aux_1361);
}
{
obj_t aux_1368;
{
obj_t aux_1369;
{
obj_t aux_1370;
aux_1370 = MAKE_PAIR(list1974___rgc_expand, BNIL);
aux_1369 = MAKE_PAIR(list1972___rgc_expand, aux_1370);
}
aux_1368 = MAKE_PAIR(list1971___rgc_expand, aux_1369);
}
list1969___rgc_expand = MAKE_PAIR(symbol1970___rgc_expand, aux_1368);
}
{
obj_t aux_1375;
{
obj_t aux_1376;
{
obj_t aux_1377;
aux_1377 = MAKE_PAIR(list1969___rgc_expand, BNIL);
aux_1376 = MAKE_PAIR(list1968___rgc_expand, aux_1377);
}
aux_1375 = MAKE_PAIR(list1967___rgc_expand, aux_1376);
}
list1966___rgc_expand = MAKE_PAIR(symbol1893___rgc_expand, aux_1375);
}
{
obj_t aux_1382;
{
obj_t aux_1383;
aux_1383 = MAKE_PAIR(list1966___rgc_expand, BNIL);
aux_1382 = MAKE_PAIR(list1963___rgc_expand, aux_1383);
}
list1962___rgc_expand = MAKE_PAIR(symbol1885___rgc_expand, aux_1382);
}
list1961___rgc_expand = MAKE_PAIR(list1962___rgc_expand, BNIL);
symbol1983___rgc_expand = string_to_symbol("CASE");
return (symbol1984___rgc_expand = string_to_symbol("ELSE"),
BUNSPEC);
}


/* expand-string-case */obj_t expand_string_case_196___rgc_expand(obj_t x_1, obj_t e_2)
{
{
obj_t str_318;
obj_t clauses_319;
if(PAIRP(x_1)){
obj_t cdr_109_69_324;
cdr_109_69_324 = CDR(x_1);
if(PAIRP(cdr_109_69_324)){
str_318 = CAR(cdr_109_69_324);
clauses_319 = CDR(cdr_109_69_324);
{
obj_t port_id_80_328;
port_id_80_328 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1872___rgc_expand, BEOA);
{
obj_t new_329;
{
obj_t arg1012_332;
obj_t arg1013_333;
obj_t arg1014_334;
arg1012_332 = symbol1873___rgc_expand;
{
obj_t arg1020_340;
{
obj_t arg1025_344;
{
obj_t arg1030_349;
arg1030_349 = symbol1874___rgc_expand;
{
obj_t list1032_351;
{
obj_t arg1033_352;
arg1033_352 = MAKE_PAIR(BNIL, BNIL);
list1032_351 = MAKE_PAIR(str_318, arg1033_352);
}
arg1025_344 = cons__138___r4_pairs_and_lists_6_3(arg1030_349, list1032_351);
}
}
{
obj_t list1027_346;
{
obj_t arg1028_347;
arg1028_347 = MAKE_PAIR(BNIL, BNIL);
list1027_346 = MAKE_PAIR(arg1025_344, arg1028_347);
}
arg1020_340 = cons__138___r4_pairs_and_lists_6_3(port_id_80_328, list1027_346);
}
}
{
obj_t list1022_342;
list1022_342 = MAKE_PAIR(BNIL, BNIL);
arg1013_333 = cons__138___r4_pairs_and_lists_6_3(arg1020_340, list1022_342);
}
}
{
obj_t arg1035_354;
obj_t arg1037_355;
obj_t arg1038_356;
arg1035_354 = symbol1875___rgc_expand;
{
obj_t arg1044_362;
obj_t arg1045_363;
arg1044_362 = symbol1876___rgc_expand;
{
obj_t arg1051_369;
obj_t arg1054_371;
arg1051_369 = symbol1877___rgc_expand;
{
obj_t arg1058_375;
arg1058_375 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1054_371 = append_2_18___r4_pairs_and_lists_6_3(clauses_319, arg1058_375);
}
{
obj_t list1055_372;
{
obj_t arg1056_373;
arg1056_373 = MAKE_PAIR(arg1054_371, BNIL);
list1055_372 = MAKE_PAIR(BNIL, arg1056_373);
}
arg1045_363 = cons__138___r4_pairs_and_lists_6_3(arg1051_369, list1055_372);
}
}
{
obj_t list1047_365;
{
obj_t arg1048_366;
{
obj_t arg1049_367;
arg1049_367 = MAKE_PAIR(BNIL, BNIL);
arg1048_366 = MAKE_PAIR(port_id_80_328, arg1049_367);
}
list1047_365 = MAKE_PAIR(arg1045_363, arg1048_366);
}
arg1037_355 = cons__138___r4_pairs_and_lists_6_3(arg1044_362, list1047_365);
}
}
{
obj_t arg1061_378;
arg1061_378 = symbol1878___rgc_expand;
{
obj_t list1063_380;
{
obj_t arg1065_381;
arg1065_381 = MAKE_PAIR(BNIL, BNIL);
list1063_380 = MAKE_PAIR(port_id_80_328, arg1065_381);
}
arg1038_356 = cons__138___r4_pairs_and_lists_6_3(arg1061_378, list1063_380);
}
}
{
obj_t list1040_358;
{
obj_t arg1041_359;
{
obj_t arg1042_360;
arg1042_360 = MAKE_PAIR(BNIL, BNIL);
arg1041_359 = MAKE_PAIR(arg1038_356, arg1042_360);
}
list1040_358 = MAKE_PAIR(arg1037_355, arg1041_359);
}
arg1014_334 = cons__138___r4_pairs_and_lists_6_3(arg1035_354, list1040_358);
}
}
{
obj_t list1016_336;
{
obj_t arg1017_337;
{
obj_t arg1018_338;
arg1018_338 = MAKE_PAIR(BNIL, BNIL);
arg1017_337 = MAKE_PAIR(arg1014_334, arg1018_338);
}
list1016_336 = MAKE_PAIR(arg1013_333, arg1017_337);
}
new_329 = cons__138___r4_pairs_and_lists_6_3(arg1012_332, list1016_336);
}
}
{
obj_t aux_1425;
aux_1425 = CAR(new_329);
SET_CAR(x_1, aux_1425);
}
{
obj_t aux_1428;
aux_1428 = CDR(new_329);
SET_CDR(x_1, aux_1428);
}
return PROCEDURE_ENTRY(e_2)(e_2, x_1, e_2, BEOA);
}
}
}
 else {
FAILURE(string1879___rgc_expand,string1880___rgc_expand,x_1);}
}
 else {
FAILURE(string1879___rgc_expand,string1880___rgc_expand,x_1);}
}
}


/* _expand-string-case */obj_t _expand_string_case_129___rgc_expand(obj_t env_1117, obj_t x_1118, obj_t e_1119)
{
return expand_string_case_196___rgc_expand(x_1118, e_1119);
}


/* expand-regular-grammar */obj_t expand_regular_grammar_0___rgc_expand(obj_t x_3, obj_t e_4)
{
{
obj_t user_env_137_384;
obj_t clauses_385;
if(PAIRP(x_3)){
obj_t cdr_124_99_390;
cdr_124_99_390 = CDR(x_3);
if(PAIRP(cdr_124_99_390)){
user_env_137_384 = CAR(cdr_124_99_390);
clauses_385 = CDR(cdr_124_99_390);
{
obj_t tree_394;
tree_394 = rules__regular_tree_149___rgc_rules(user_env_137_384, clauses_385);
{
obj_t actions_395;
obj_t else_num_171_396;
obj_t submatch__50_397;
actions_395 = _res1__155___r5_control_features_6_4;
else_num_171_396 = _res2__167___r5_control_features_6_4;
submatch__50_397 = _res3__194___r5_control_features_6_4;
{
obj_t node_398;
node_398 = regular_tree__node_150___rgc_tree(tree_394);
{
obj_t followpos_399;
obj_t positions_400;
obj_t submatches_401;
followpos_399 = _res1__155___r5_control_features_6_4;
positions_400 = _res2__167___r5_control_features_6_4;
submatches_401 = _res3__194___r5_control_features_6_4;
{
obj_t dfa_402;
dfa_402 = node__dfa_130___rgc_dfa(node_398, followpos_399, positions_400);
{
obj_t sexp_403;
{
obj_t arg1073_404;
arg1073_404 = compile_dfa_101___rgc_compile(submatches_401, dfa_402);
sexp_403 = make_regular_parser_107___rgc_expand(arg1073_404, actions_395, else_num_171_396, submatch__50_397);
}
{
reset_special_match_char__38___rgc_rules();
reset_tree__130___rgc_tree();
reset_dfa__30___rgc_dfa();
return PROCEDURE_ENTRY(e_4)(e_4, sexp_403, e_4, BEOA);
}
}
}
}
}
}
}
}
 else {
FAILURE(string1881___rgc_expand,string1880___rgc_expand,x_3);}
}
 else {
FAILURE(string1881___rgc_expand,string1880___rgc_expand,x_3);}
}
}


/* _expand-regular-grammar */obj_t _expand_regular_grammar_168___rgc_expand(obj_t env_1120, obj_t x_1121, obj_t e_1122)
{
return expand_regular_grammar_0___rgc_expand(x_1121, e_1122);
}


/* make-regular-parser */obj_t make_regular_parser_107___rgc_expand(obj_t states_5, obj_t actions_6, obj_t else_num_171_7, obj_t submatch__50_8)
{
{
obj_t arg1076_405;
obj_t arg1077_406;
obj_t arg1078_407;
arg1076_405 = symbol1873___rgc_expand;
{
obj_t arg1084_413;
{
obj_t arg1088_417;
arg1088_417 = symbol1882___rgc_expand;
{
obj_t list1090_419;
{
obj_t arg1091_420;
arg1091_420 = MAKE_PAIR(BNIL, BNIL);
list1090_419 = MAKE_PAIR(BUNSPEC, arg1091_420);
}
arg1084_413 = cons__138___r4_pairs_and_lists_6_3(arg1088_417, list1090_419);
}
}
{
obj_t list1086_415;
list1086_415 = MAKE_PAIR(BNIL, BNIL);
arg1077_406 = cons__138___r4_pairs_and_lists_6_3(arg1084_413, list1086_415);
}
}
{
obj_t arg1093_422;
obj_t arg1094_423;
obj_t arg1095_424;
arg1093_422 = symbol1883___rgc_expand;
{
obj_t arg1099_428;
arg1099_428 = symbol1884___rgc_expand;
{
obj_t list1101_430;
list1101_430 = MAKE_PAIR(BNIL, BNIL);
arg1094_423 = cons__138___r4_pairs_and_lists_6_3(arg1099_428, list1101_430);
}
}
{
obj_t arg1103_432;
{
obj_t arg1104_433;
obj_t arg1105_434;
obj_t arg1106_435;
obj_t arg1107_436;
obj_t arg1108_437;
obj_t arg1109_438;
obj_t arg1110_439;
obj_t arg1111_440;
obj_t arg1112_441;
obj_t arg1113_442;
obj_t arg1114_443;
obj_t arg1115_444;
obj_t arg1116_445;
{
obj_t arg1130_459;
obj_t arg1131_460;
obj_t arg1132_461;
arg1130_459 = symbol1885___rgc_expand;
{
obj_t arg1139_467;
arg1139_467 = symbol1886___rgc_expand;
{
obj_t list1141_469;
list1141_469 = MAKE_PAIR(BNIL, BNIL);
arg1131_460 = cons__138___r4_pairs_and_lists_6_3(arg1139_467, list1141_469);
}
}
arg1132_461 = symbol1884___rgc_expand;
{
obj_t list1134_463;
{
obj_t arg1135_464;
{
obj_t arg1136_465;
arg1136_465 = MAKE_PAIR(BNIL, BNIL);
arg1135_464 = MAKE_PAIR(arg1132_461, arg1136_465);
}
list1134_463 = MAKE_PAIR(arg1131_460, arg1135_464);
}
arg1104_433 = cons__138___r4_pairs_and_lists_6_3(arg1130_459, list1134_463);
}
}
{
obj_t arg1143_471;
obj_t arg1144_472;
obj_t arg1145_473;
arg1143_471 = symbol1885___rgc_expand;
{
obj_t arg1152_479;
arg1152_479 = symbol1887___rgc_expand;
{
obj_t list1154_481;
list1154_481 = MAKE_PAIR(BNIL, BNIL);
arg1144_472 = cons__138___r4_pairs_and_lists_6_3(arg1152_479, list1154_481);
}
}
{
obj_t arg1156_483;
obj_t arg1157_484;
obj_t arg1160_486;
arg1156_483 = symbol1888___rgc_expand;
arg1157_484 = symbol1884___rgc_expand;
{
obj_t arg1167_493;
arg1167_493 = symbol1889___rgc_expand;
{
obj_t list1169_495;
list1169_495 = MAKE_PAIR(BNIL, BNIL);
arg1160_486 = cons__138___r4_pairs_and_lists_6_3(arg1167_493, list1169_495);
}
}
{
obj_t list1162_488;
{
obj_t arg1163_489;
{
obj_t arg1164_490;
{
obj_t arg1165_491;
arg1165_491 = MAKE_PAIR(BNIL, BNIL);
arg1164_490 = MAKE_PAIR(arg1160_486, arg1165_491);
}
{
obj_t aux_1477;
aux_1477 = BINT(((long)0));
arg1163_489 = MAKE_PAIR(aux_1477, arg1164_490);
}
}
list1162_488 = MAKE_PAIR(arg1157_484, arg1163_489);
}
arg1145_473 = cons__138___r4_pairs_and_lists_6_3(arg1156_483, list1162_488);
}
}
{
obj_t list1147_475;
{
obj_t arg1148_476;
{
obj_t arg1150_477;
arg1150_477 = MAKE_PAIR(BNIL, BNIL);
arg1148_476 = MAKE_PAIR(arg1145_473, arg1150_477);
}
list1147_475 = MAKE_PAIR(arg1144_472, arg1148_476);
}
arg1105_434 = cons__138___r4_pairs_and_lists_6_3(arg1143_471, list1147_475);
}
}
{
obj_t arg1171_497;
obj_t arg1172_498;
obj_t arg1173_499;
arg1171_497 = symbol1885___rgc_expand;
{
obj_t arg1179_505;
obj_t arg1180_506;
obj_t arg1181_507;
arg1179_505 = symbol1890___rgc_expand;
arg1180_506 = symbol1891___rgc_expand;
arg1181_507 = symbol1892___rgc_expand;
{
obj_t list1183_509;
{
obj_t arg1184_510;
{
obj_t arg1185_511;
arg1185_511 = MAKE_PAIR(BNIL, BNIL);
arg1184_510 = MAKE_PAIR(arg1181_507, arg1185_511);
}
list1183_509 = MAKE_PAIR(arg1180_506, arg1184_510);
}
arg1172_498 = cons__138___r4_pairs_and_lists_6_3(arg1179_505, list1183_509);
}
}
{
obj_t arg1187_513;
obj_t arg1188_514;
obj_t arg1189_515;
obj_t arg1190_516;
arg1187_513 = symbol1893___rgc_expand;
{
obj_t arg1197_523;
obj_t arg1199_524;
obj_t arg1200_525;
obj_t arg1201_526;
arg1197_523 = symbol1894___rgc_expand;
{
obj_t arg1209_533;
obj_t arg1210_534;
arg1209_533 = symbol1895___rgc_expand;
arg1210_534 = symbol1891___rgc_expand;
{
obj_t list1214_537;
{
obj_t arg1216_538;
{
obj_t arg1219_539;
arg1219_539 = MAKE_PAIR(BNIL, BNIL);
{
obj_t aux_1491;
aux_1491 = BINT(((long)0));
arg1216_538 = MAKE_PAIR(aux_1491, arg1219_539);
}
}
list1214_537 = MAKE_PAIR(arg1210_534, arg1216_538);
}
arg1199_524 = cons__138___r4_pairs_and_lists_6_3(arg1209_533, list1214_537);
}
}
{
obj_t arg1221_541;
obj_t arg1222_542;
obj_t arg1224_543;
arg1221_541 = symbol1896___rgc_expand;
arg1222_542 = symbol1892___rgc_expand;
{
obj_t arg1233_549;
arg1233_549 = symbol1889___rgc_expand;
{
obj_t list1235_551;
list1235_551 = MAKE_PAIR(BNIL, BNIL);
arg1224_543 = cons__138___r4_pairs_and_lists_6_3(arg1233_549, list1235_551);
}
}
{
obj_t list1226_545;
{
obj_t arg1228_546;
{
obj_t arg1231_547;
arg1231_547 = MAKE_PAIR(BNIL, BNIL);
arg1228_546 = MAKE_PAIR(arg1224_543, arg1231_547);
}
list1226_545 = MAKE_PAIR(arg1222_542, arg1228_546);
}
arg1200_525 = cons__138___r4_pairs_and_lists_6_3(arg1221_541, list1226_545);
}
}
{
obj_t arg1238_553;
obj_t arg1240_554;
obj_t arg1241_555;
arg1238_553 = symbol1895___rgc_expand;
arg1240_554 = symbol1892___rgc_expand;
arg1241_555 = symbol1891___rgc_expand;
{
obj_t list1244_557;
{
obj_t arg1245_558;
{
obj_t arg1247_559;
arg1247_559 = MAKE_PAIR(BNIL, BNIL);
arg1245_558 = MAKE_PAIR(arg1241_555, arg1247_559);
}
list1244_557 = MAKE_PAIR(arg1240_554, arg1245_558);
}
arg1201_526 = cons__138___r4_pairs_and_lists_6_3(arg1238_553, list1244_557);
}
}
{
obj_t list1203_528;
{
obj_t arg1204_529;
{
obj_t arg1205_530;
{
obj_t arg1206_531;
arg1206_531 = MAKE_PAIR(BNIL, BNIL);
arg1205_530 = MAKE_PAIR(arg1201_526, arg1206_531);
}
arg1204_529 = MAKE_PAIR(arg1200_525, arg1205_530);
}
list1203_528 = MAKE_PAIR(arg1199_524, arg1204_529);
}
arg1188_514 = cons__138___r4_pairs_and_lists_6_3(arg1197_523, list1203_528);
}
}
{
obj_t arg1250_561;
obj_t arg1251_562;
obj_t arg1252_563;
obj_t arg1253_564;
arg1250_561 = symbol1888___rgc_expand;
arg1251_562 = symbol1884___rgc_expand;
arg1252_563 = symbol1891___rgc_expand;
arg1253_564 = symbol1892___rgc_expand;
{
obj_t list1255_566;
{
obj_t arg1256_567;
{
obj_t arg1257_568;
{
obj_t arg1258_569;
arg1258_569 = MAKE_PAIR(BNIL, BNIL);
arg1257_568 = MAKE_PAIR(arg1253_564, arg1258_569);
}
arg1256_567 = MAKE_PAIR(arg1252_563, arg1257_568);
}
list1255_566 = MAKE_PAIR(arg1251_562, arg1256_567);
}
arg1189_515 = cons__138___r4_pairs_and_lists_6_3(arg1250_561, list1255_566);
}
}
{
obj_t arg1260_571;
obj_t arg1265_574;
arg1260_571 = symbol1897___rgc_expand;
{
obj_t arg1274_581;
obj_t arg1277_582;
obj_t arg1278_583;
arg1274_581 = symbol1898___rgc_expand;
arg1277_582 = symbol1891___rgc_expand;
arg1278_583 = symbol1892___rgc_expand;
{
obj_t list1282_585;
{
obj_t arg1283_586;
{
obj_t arg1284_587;
arg1284_587 = MAKE_PAIR(BNIL, BNIL);
arg1283_586 = MAKE_PAIR(arg1278_583, arg1284_587);
}
list1282_585 = MAKE_PAIR(arg1277_582, arg1283_586);
}
arg1265_574 = cons__138___r4_pairs_and_lists_6_3(arg1274_581, list1282_585);
}
}
{
obj_t list1268_576;
{
obj_t arg1269_577;
{
obj_t arg1270_578;
{
obj_t arg1272_579;
arg1272_579 = MAKE_PAIR(BNIL, BNIL);
arg1270_578 = MAKE_PAIR(arg1265_574, arg1272_579);
}
arg1269_577 = MAKE_PAIR(string1899___rgc_expand, arg1270_578);
}
list1268_576 = MAKE_PAIR(string1900___rgc_expand, arg1269_577);
}
arg1190_516 = cons__138___r4_pairs_and_lists_6_3(arg1260_571, list1268_576);
}
}
{
obj_t list1192_518;
{
obj_t arg1193_519;
{
obj_t arg1194_520;
{
obj_t arg1195_521;
arg1195_521 = MAKE_PAIR(BNIL, BNIL);
arg1194_520 = MAKE_PAIR(arg1190_516, arg1195_521);
}
arg1193_519 = MAKE_PAIR(arg1189_515, arg1194_520);
}
list1192_518 = MAKE_PAIR(arg1188_514, arg1193_519);
}
arg1173_499 = cons__138___r4_pairs_and_lists_6_3(arg1187_513, list1192_518);
}
}
{
obj_t list1175_501;
{
obj_t arg1176_502;
{
obj_t arg1177_503;
arg1177_503 = MAKE_PAIR(BNIL, BNIL);
arg1176_502 = MAKE_PAIR(arg1173_499, arg1177_503);
}
list1175_501 = MAKE_PAIR(arg1172_498, arg1176_502);
}
arg1106_435 = cons__138___r4_pairs_and_lists_6_3(arg1171_497, list1175_501);
}
}
{
obj_t arg1286_589;
obj_t arg1287_590;
obj_t arg1288_591;
arg1286_589 = symbol1885___rgc_expand;
{
obj_t arg1296_597;
arg1296_597 = symbol1901___rgc_expand;
{
obj_t list1298_599;
list1298_599 = MAKE_PAIR(BNIL, BNIL);
arg1287_590 = cons__138___r4_pairs_and_lists_6_3(arg1296_597, list1298_599);
}
}
{
obj_t arg1300_601;
obj_t arg1301_602;
arg1300_601 = symbol1902___rgc_expand;
arg1301_602 = symbol1884___rgc_expand;
{
obj_t list1303_604;
{
obj_t arg1304_605;
arg1304_605 = MAKE_PAIR(BNIL, BNIL);
list1303_604 = MAKE_PAIR(arg1301_602, arg1304_605);
}
arg1288_591 = cons__138___r4_pairs_and_lists_6_3(arg1300_601, list1303_604);
}
}
{
obj_t list1291_593;
{
obj_t arg1292_594;
{
obj_t arg1294_595;
arg1294_595 = MAKE_PAIR(BNIL, BNIL);
arg1292_594 = MAKE_PAIR(arg1288_591, arg1294_595);
}
list1291_593 = MAKE_PAIR(arg1287_590, arg1292_594);
}
arg1107_436 = cons__138___r4_pairs_and_lists_6_3(arg1286_589, list1291_593);
}
}
{
obj_t arg1308_607;
obj_t arg1309_608;
obj_t arg1310_609;
arg1308_607 = symbol1885___rgc_expand;
{
obj_t arg1319_615;
arg1319_615 = symbol1903___rgc_expand;
{
obj_t list1322_617;
list1322_617 = MAKE_PAIR(BNIL, BNIL);
arg1309_608 = cons__138___r4_pairs_and_lists_6_3(arg1319_615, list1322_617);
}
}
{
obj_t arg1324_619;
obj_t arg1325_620;
arg1324_619 = symbol1904___rgc_expand;
arg1325_620 = symbol1884___rgc_expand;
{
obj_t list1327_622;
{
obj_t arg1328_623;
arg1328_623 = MAKE_PAIR(BNIL, BNIL);
list1327_622 = MAKE_PAIR(arg1325_620, arg1328_623);
}
arg1310_609 = cons__138___r4_pairs_and_lists_6_3(arg1324_619, list1327_622);
}
}
{
obj_t list1312_611;
{
obj_t arg1313_612;
{
obj_t arg1315_613;
arg1315_613 = MAKE_PAIR(BNIL, BNIL);
arg1313_612 = MAKE_PAIR(arg1310_609, arg1315_613);
}
list1312_611 = MAKE_PAIR(arg1309_608, arg1313_612);
}
arg1108_437 = cons__138___r4_pairs_and_lists_6_3(arg1308_607, list1312_611);
}
}
{
obj_t arg1331_625;
obj_t arg1332_626;
obj_t arg1333_627;
arg1331_625 = symbol1885___rgc_expand;
{
obj_t arg1342_633;
arg1342_633 = symbol1905___rgc_expand;
{
obj_t list1344_635;
list1344_635 = MAKE_PAIR(BNIL, BNIL);
arg1332_626 = cons__138___r4_pairs_and_lists_6_3(arg1342_633, list1344_635);
}
}
{
obj_t arg1347_637;
obj_t arg1349_638;
arg1347_637 = symbol1906___rgc_expand;
arg1349_638 = symbol1884___rgc_expand;
{
obj_t list1351_640;
{
obj_t arg1352_641;
arg1352_641 = MAKE_PAIR(BNIL, BNIL);
list1351_640 = MAKE_PAIR(arg1349_638, arg1352_641);
}
arg1333_627 = cons__138___r4_pairs_and_lists_6_3(arg1347_637, list1351_640);
}
}
{
obj_t list1335_629;
{
obj_t arg1337_630;
{
obj_t arg1339_631;
arg1339_631 = MAKE_PAIR(BNIL, BNIL);
arg1337_630 = MAKE_PAIR(arg1333_627, arg1339_631);
}
list1335_629 = MAKE_PAIR(arg1332_626, arg1337_630);
}
arg1109_438 = cons__138___r4_pairs_and_lists_6_3(arg1331_625, list1335_629);
}
}
{
obj_t arg1355_643;
obj_t arg1356_644;
obj_t arg1357_645;
arg1355_643 = symbol1885___rgc_expand;
{
obj_t arg1367_651;
arg1367_651 = symbol1907___rgc_expand;
{
obj_t list1369_653;
list1369_653 = MAKE_PAIR(BNIL, BNIL);
arg1356_644 = cons__138___r4_pairs_and_lists_6_3(arg1367_651, list1369_653);
}
}
{
obj_t arg1372_655;
obj_t arg1373_656;
arg1372_655 = symbol1908___rgc_expand;
arg1373_656 = symbol1884___rgc_expand;
{
obj_t list1376_658;
{
obj_t arg1378_659;
arg1378_659 = MAKE_PAIR(BNIL, BNIL);
list1376_658 = MAKE_PAIR(arg1373_656, arg1378_659);
}
arg1357_645 = cons__138___r4_pairs_and_lists_6_3(arg1372_655, list1376_658);
}
}
{
obj_t list1362_647;
{
obj_t arg1363_648;
{
obj_t arg1364_649;
arg1364_649 = MAKE_PAIR(BNIL, BNIL);
arg1363_648 = MAKE_PAIR(arg1357_645, arg1364_649);
}
list1362_647 = MAKE_PAIR(arg1356_644, arg1363_648);
}
arg1110_439 = cons__138___r4_pairs_and_lists_6_3(arg1355_643, list1362_647);
}
}
{
obj_t arg1381_661;
obj_t arg1383_662;
obj_t arg1384_663;
arg1381_661 = symbol1885___rgc_expand;
{
obj_t arg1390_669;
arg1390_669 = symbol1909___rgc_expand;
{
obj_t list1392_671;
list1392_671 = MAKE_PAIR(BNIL, BNIL);
arg1383_662 = cons__138___r4_pairs_and_lists_6_3(arg1390_669, list1392_671);
}
}
{
obj_t arg1395_673;
obj_t arg1396_674;
arg1395_673 = symbol1910___rgc_expand;
arg1396_674 = symbol1884___rgc_expand;
{
obj_t list1398_676;
{
obj_t arg1399_677;
arg1399_677 = MAKE_PAIR(BNIL, BNIL);
list1398_676 = MAKE_PAIR(arg1396_674, arg1399_677);
}
arg1384_663 = cons__138___r4_pairs_and_lists_6_3(arg1395_673, list1398_676);
}
}
{
obj_t list1386_665;
{
obj_t arg1387_666;
{
obj_t arg1388_667;
arg1388_667 = MAKE_PAIR(BNIL, BNIL);
arg1387_666 = MAKE_PAIR(arg1384_663, arg1388_667);
}
list1386_665 = MAKE_PAIR(arg1383_662, arg1387_666);
}
arg1111_440 = cons__138___r4_pairs_and_lists_6_3(arg1381_661, list1386_665);
}
}
{
obj_t arg1402_679;
obj_t arg1403_680;
obj_t arg1405_681;
arg1402_679 = symbol1885___rgc_expand;
{
obj_t arg1414_687;
arg1414_687 = symbol1911___rgc_expand;
{
obj_t list1416_689;
list1416_689 = MAKE_PAIR(BNIL, BNIL);
arg1403_680 = cons__138___r4_pairs_and_lists_6_3(arg1414_687, list1416_689);
}
}
{
obj_t arg1418_691;
obj_t arg1419_692;
obj_t arg1421_693;
arg1418_691 = symbol1893___rgc_expand;
{
obj_t arg1432_700;
obj_t arg1433_701;
arg1432_700 = symbol1912___rgc_expand;
{
obj_t arg1444_708;
arg1444_708 = symbol1889___rgc_expand;
{
obj_t list1447_710;
list1447_710 = MAKE_PAIR(BNIL, BNIL);
arg1433_701 = cons__138___r4_pairs_and_lists_6_3(arg1444_708, list1447_710);
}
}
{
obj_t list1438_704;
{
obj_t arg1440_705;
{
obj_t arg1441_706;
arg1441_706 = MAKE_PAIR(BNIL, BNIL);
{
obj_t aux_1584;
aux_1584 = BINT(((long)0));
arg1440_705 = MAKE_PAIR(aux_1584, arg1441_706);
}
}
list1438_704 = MAKE_PAIR(arg1433_701, arg1440_705);
}
arg1419_692 = cons__138___r4_pairs_and_lists_6_3(arg1432_700, list1438_704);
}
}
{
obj_t arg1449_712;
obj_t arg1450_713;
arg1449_712 = symbol1913___rgc_expand;
{
obj_t arg1461_720;
arg1461_720 = symbol1914___rgc_expand;
{
obj_t list1464_722;
list1464_722 = MAKE_PAIR(BNIL, BNIL);
arg1450_713 = cons__138___r4_pairs_and_lists_6_3(arg1461_720, list1464_722);
}
}
{
obj_t list1455_716;
{
obj_t arg1456_717;
{
obj_t arg1458_718;
arg1458_718 = MAKE_PAIR(BNIL, BNIL);
{
obj_t aux_1592;
aux_1592 = BINT(((long)0));
arg1456_717 = MAKE_PAIR(aux_1592, arg1458_718);
}
}
list1455_716 = MAKE_PAIR(arg1450_713, arg1456_717);
}
arg1421_693 = cons__138___r4_pairs_and_lists_6_3(arg1449_712, list1455_716);
}
}
{
obj_t list1424_695;
{
obj_t arg1426_696;
{
obj_t arg1427_697;
{
obj_t arg1428_698;
arg1428_698 = MAKE_PAIR(BNIL, BNIL);
arg1427_697 = MAKE_PAIR(arg1421_693, arg1428_698);
}
arg1426_696 = MAKE_PAIR(BCNST(256), arg1427_697);
}
list1424_695 = MAKE_PAIR(arg1419_692, arg1426_696);
}
arg1405_681 = cons__138___r4_pairs_and_lists_6_3(arg1418_691, list1424_695);
}
}
{
obj_t list1408_683;
{
obj_t arg1410_684;
{
obj_t arg1411_685;
arg1411_685 = MAKE_PAIR(BNIL, BNIL);
arg1410_684 = MAKE_PAIR(arg1405_681, arg1411_685);
}
list1408_683 = MAKE_PAIR(arg1403_680, arg1410_684);
}
arg1112_441 = cons__138___r4_pairs_and_lists_6_3(arg1402_679, list1408_683);
}
}
{
obj_t arg1466_724;
obj_t arg1467_725;
obj_t arg1468_726;
arg1466_724 = symbol1885___rgc_expand;
{
obj_t arg1475_732;
arg1475_732 = symbol1915___rgc_expand;
{
obj_t list1477_734;
list1477_734 = MAKE_PAIR(BNIL, BNIL);
arg1467_725 = cons__138___r4_pairs_and_lists_6_3(arg1475_732, list1477_734);
}
}
arg1468_726 = symbol1882___rgc_expand;
{
obj_t list1470_728;
{
obj_t arg1471_729;
{
obj_t arg1473_730;
arg1473_730 = MAKE_PAIR(BNIL, BNIL);
arg1471_729 = MAKE_PAIR(arg1468_726, arg1473_730);
}
list1470_728 = MAKE_PAIR(arg1467_725, arg1471_729);
}
arg1113_442 = cons__138___r4_pairs_and_lists_6_3(arg1466_724, list1470_728);
}
}
{
obj_t arg1479_736;
obj_t arg1480_737;
obj_t arg1481_738;
arg1479_736 = symbol1885___rgc_expand;
{
obj_t arg1488_744;
obj_t arg1489_745;
arg1488_744 = symbol1916___rgc_expand;
arg1489_745 = symbol1917___rgc_expand;
{
obj_t list1491_747;
{
obj_t arg1494_748;
arg1494_748 = MAKE_PAIR(BNIL, BNIL);
list1491_747 = MAKE_PAIR(arg1489_745, arg1494_748);
}
arg1480_737 = cons__138___r4_pairs_and_lists_6_3(arg1488_744, list1491_747);
}
}
{
obj_t arg1497_750;
obj_t arg1498_751;
obj_t arg1499_752;
arg1497_750 = symbol1918___rgc_expand;
arg1498_751 = symbol1882___rgc_expand;
arg1499_752 = symbol1917___rgc_expand;
{
obj_t list1501_754;
{
obj_t arg1502_755;
{
obj_t arg1503_756;
arg1503_756 = MAKE_PAIR(BNIL, BNIL);
arg1502_755 = MAKE_PAIR(arg1499_752, arg1503_756);
}
list1501_754 = MAKE_PAIR(arg1498_751, arg1502_755);
}
arg1481_738 = cons__138___r4_pairs_and_lists_6_3(arg1497_750, list1501_754);
}
}
{
obj_t list1484_740;
{
obj_t arg1485_741;
{
obj_t arg1486_742;
arg1486_742 = MAKE_PAIR(BNIL, BNIL);
arg1485_741 = MAKE_PAIR(arg1481_738, arg1486_742);
}
list1484_740 = MAKE_PAIR(arg1480_737, arg1485_741);
}
arg1114_443 = cons__138___r4_pairs_and_lists_6_3(arg1479_736, list1484_740);
}
}
{
obj_t arg1505_758;
obj_t arg1507_759;
obj_t arg1510_760;
arg1505_758 = symbol1885___rgc_expand;
{
obj_t arg1516_766;
arg1516_766 = symbol1919___rgc_expand;
{
obj_t list1518_768;
list1518_768 = MAKE_PAIR(symbol1917___rgc_expand, BNIL);
arg1507_759 = cons__138___r4_pairs_and_lists_6_3(arg1516_766, list1518_768);
}
}
{
obj_t arg1522_770;
obj_t arg1524_771;
obj_t arg1525_772;
obj_t arg1526_773;
arg1522_770 = symbol1893___rgc_expand;
{
obj_t arg1533_780;
obj_t arg1534_781;
arg1533_780 = symbol1920___rgc_expand;
arg1534_781 = symbol1917___rgc_expand;
{
obj_t list1536_783;
{
obj_t arg1537_784;
arg1537_784 = MAKE_PAIR(BNIL, BNIL);
list1536_783 = MAKE_PAIR(arg1534_781, arg1537_784);
}
arg1524_771 = cons__138___r4_pairs_and_lists_6_3(arg1533_780, list1536_783);
}
}
{
obj_t arg1540_786;
obj_t arg1542_787;
obj_t arg1545_788;
arg1540_786 = symbol1921___rgc_expand;
arg1542_787 = symbol1882___rgc_expand;
{
obj_t arg1554_794;
obj_t arg1555_795;
arg1554_794 = symbol1922___rgc_expand;
arg1555_795 = symbol1917___rgc_expand;
{
obj_t list1557_797;
{
obj_t arg1558_798;
arg1558_798 = MAKE_PAIR(BNIL, BNIL);
list1557_797 = MAKE_PAIR(arg1555_795, arg1558_798);
}
arg1545_788 = cons__138___r4_pairs_and_lists_6_3(arg1554_794, list1557_797);
}
}
{
obj_t list1549_790;
{
obj_t arg1550_791;
{
obj_t arg1552_792;
arg1552_792 = MAKE_PAIR(BNIL, BNIL);
arg1550_791 = MAKE_PAIR(arg1545_788, arg1552_792);
}
list1549_790 = MAKE_PAIR(arg1542_787, arg1550_791);
}
arg1525_772 = cons__138___r4_pairs_and_lists_6_3(arg1540_786, list1549_790);
}
}
{
obj_t arg1560_800;
obj_t arg1561_801;
arg1560_800 = symbol1921___rgc_expand;
arg1561_801 = symbol1882___rgc_expand;
{
obj_t list1563_803;
{
obj_t arg1564_804;
{
obj_t arg1565_805;
arg1565_805 = MAKE_PAIR(BNIL, BNIL);
arg1564_804 = MAKE_PAIR(BUNSPEC, arg1565_805);
}
list1563_803 = MAKE_PAIR(arg1561_801, arg1564_804);
}
arg1526_773 = cons__138___r4_pairs_and_lists_6_3(arg1560_800, list1563_803);
}
}
{
obj_t list1528_775;
{
obj_t arg1529_776;
{
obj_t arg1530_777;
{
obj_t arg1531_778;
arg1531_778 = MAKE_PAIR(BNIL, BNIL);
arg1530_777 = MAKE_PAIR(arg1526_773, arg1531_778);
}
arg1529_776 = MAKE_PAIR(arg1525_772, arg1530_777);
}
list1528_775 = MAKE_PAIR(arg1524_771, arg1529_776);
}
arg1510_760 = cons__138___r4_pairs_and_lists_6_3(arg1522_770, list1528_775);
}
}
{
obj_t list1512_762;
{
obj_t arg1513_763;
{
obj_t arg1514_764;
arg1514_764 = MAKE_PAIR(BNIL, BNIL);
arg1513_763 = MAKE_PAIR(arg1510_760, arg1514_764);
}
list1512_762 = MAKE_PAIR(arg1507_759, arg1513_763);
}
arg1115_444 = cons__138___r4_pairs_and_lists_6_3(arg1505_758, list1512_762);
}
}
{
obj_t arg1568_807;
obj_t arg1569_808;
if(CBOOL(submatch__50_8)){
obj_t arg1570_809;
obj_t arg1572_810;
obj_t arg1573_811;
arg1570_809 = list1923___rgc_expand;
arg1572_810 = list1927___rgc_expand;
arg1573_811 = list1942___rgc_expand;
{
obj_t list1576_813;
{
obj_t arg1578_814;
{
obj_t arg1580_815;
{
obj_t arg1581_816;
arg1581_816 = MAKE_PAIR(list1950___rgc_expand, BNIL);
arg1580_815 = MAKE_PAIR(arg1573_811, arg1581_816);
}
arg1578_814 = MAKE_PAIR(arg1572_810, arg1580_815);
}
list1576_813 = MAKE_PAIR(arg1570_809, arg1578_814);
}
arg1568_807 = list1576_813;
}
}
 else {
arg1568_807 = BNIL;
}
{
obj_t arg1583_818;
obj_t arg1584_819;
{
obj_t arg1589_824;
obj_t arg1592_825;
obj_t arg1593_826;
obj_t arg1594_827;
arg1589_824 = symbol1885___rgc_expand;
{
obj_t arg1603_832;
arg1603_832 = symbol1958___rgc_expand;
{
obj_t list1606_834;
list1606_834 = MAKE_PAIR(BNIL, BNIL);
arg1592_825 = cons__138___r4_pairs_and_lists_6_3(arg1603_832, list1606_834);
}
}
{
obj_t arg1608_836;
obj_t arg1609_837;
arg1608_836 = symbol1959___rgc_expand;
arg1609_837 = symbol1884___rgc_expand;
{
obj_t list1611_839;
{
obj_t arg1612_840;
arg1612_840 = MAKE_PAIR(BNIL, BNIL);
list1611_839 = MAKE_PAIR(arg1609_837, arg1612_840);
}
arg1593_826 = cons__138___r4_pairs_and_lists_6_3(arg1608_836, list1611_839);
}
}
{
obj_t arg1615_842;
obj_t arg1617_843;
if(CBOOL(submatch__50_8)){
obj_t list1619_845;
list1619_845 = MAKE_PAIR(list1960___rgc_expand, BNIL);
arg1615_842 = list1619_845;
}
 else {
arg1615_842 = BNIL;
}
{
obj_t arg1621_847;
{
obj_t arg1625_851;
obj_t arg1627_852;
obj_t arg1628_853;
arg1625_851 = symbol1873___rgc_expand;
{
obj_t arg1633_857;
{
obj_t arg1638_861;
obj_t arg1639_862;
arg1638_861 = symbol1930___rgc_expand;
{
obj_t arg1647_867;
{
obj_t arg1653_872;
arg1653_872 = get_initial_state_58___rgc_dfa();
arg1647_867 = state_name_114___rgc_dfa(arg1653_872);
}
{
obj_t list1649_869;
{
obj_t arg1650_870;
arg1650_870 = MAKE_PAIR(BNIL, BNIL);
list1649_869 = MAKE_PAIR(else_num_171_7, arg1650_870);
}
arg1639_862 = cons__138___r4_pairs_and_lists_6_3(arg1647_867, list1649_869);
}
}
{
obj_t list1641_864;
{
obj_t arg1645_865;
arg1645_865 = MAKE_PAIR(BNIL, BNIL);
list1641_864 = MAKE_PAIR(arg1639_862, arg1645_865);
}
arg1633_857 = cons__138___r4_pairs_and_lists_6_3(arg1638_861, list1641_864);
}
}
{
obj_t list1635_859;
list1635_859 = MAKE_PAIR(BNIL, BNIL);
arg1627_852 = cons__138___r4_pairs_and_lists_6_3(arg1633_857, list1635_859);
}
}
{
obj_t arg1654_873;
obj_t arg1655_874;
if(CBOOL(submatch__50_8)){
arg1654_873 = list1961___rgc_expand;
}
 else {
arg1654_873 = BNIL;
}
{
obj_t arg1656_875;
{
obj_t arg1661_879;
obj_t arg1663_880;
obj_t arg1665_881;
arg1661_879 = symbol1983___rgc_expand;
arg1663_880 = symbol1936___rgc_expand;
{
obj_t arg1669_885;
obj_t arg1670_886;
{
obj_t actions_887;
long num_888;
obj_t res_889;
actions_887 = actions_6;
num_888 = ((long)0);
res_889 = BNIL;
loop_890:
if(NULLP(actions_887)){
arg1669_885 = res_889;
}
 else {
obj_t arg1675_894;
long arg1676_895;
obj_t arg1677_896;
arg1675_894 = CDR(actions_887);
arg1676_895 = (num_888+((long)1));
{
obj_t arg1678_897;
{
obj_t arg1679_898;
obj_t arg1680_899;
{
obj_t list1686_905;
list1686_905 = MAKE_PAIR(BNIL, BNIL);
arg1679_898 = cons__138___r4_pairs_and_lists_6_3(BINT(num_888), list1686_905);
}
arg1680_899 = CAR(actions_887);
{
obj_t list1682_901;
{
obj_t arg1683_902;
arg1683_902 = MAKE_PAIR(BNIL, BNIL);
list1682_901 = MAKE_PAIR(arg1680_899, arg1683_902);
}
arg1678_897 = cons__138___r4_pairs_and_lists_6_3(arg1679_898, list1682_901);
}
}
arg1677_896 = MAKE_PAIR(arg1678_897, res_889);
}
{
obj_t res_1688;
long num_1687;
obj_t actions_1686;
actions_1686 = arg1675_894;
num_1687 = arg1676_895;
res_1688 = arg1677_896;
res_889 = res_1688;
num_888 = num_1687;
actions_887 = actions_1686;
goto loop_890;
}
}
}
{
obj_t arg1689_907;
{
obj_t arg1694_911;
obj_t arg1695_912;
arg1694_911 = symbol1984___rgc_expand;
{
obj_t arg1701_917;
obj_t arg1704_920;
arg1701_917 = symbol1897___rgc_expand;
arg1704_920 = symbol1936___rgc_expand;
{
obj_t list1706_922;
{
obj_t arg1707_923;
{
obj_t arg1708_924;
{
obj_t arg1709_925;
arg1709_925 = MAKE_PAIR(BNIL, BNIL);
arg1708_924 = MAKE_PAIR(arg1704_920, arg1709_925);
}
arg1707_923 = MAKE_PAIR(string1985___rgc_expand, arg1708_924);
}
list1706_922 = MAKE_PAIR(string1881___rgc_expand, arg1707_923);
}
arg1695_912 = cons__138___r4_pairs_and_lists_6_3(arg1701_917, list1706_922);
}
}
{
obj_t list1698_914;
{
obj_t arg1699_915;
arg1699_915 = MAKE_PAIR(BNIL, BNIL);
list1698_914 = MAKE_PAIR(arg1695_912, arg1699_915);
}
arg1689_907 = cons__138___r4_pairs_and_lists_6_3(arg1694_911, list1698_914);
}
}
{
obj_t list1692_909;
list1692_909 = MAKE_PAIR(BNIL, BNIL);
arg1670_886 = cons__138___r4_pairs_and_lists_6_3(arg1689_907, list1692_909);
}
}
arg1665_881 = append_2_18___r4_pairs_and_lists_6_3(arg1669_885, arg1670_886);
}
{
obj_t list1666_882;
{
obj_t arg1667_883;
arg1667_883 = MAKE_PAIR(arg1665_881, BNIL);
list1666_882 = MAKE_PAIR(arg1663_880, arg1667_883);
}
arg1656_875 = cons__138___r4_pairs_and_lists_6_3(arg1661_879, list1666_882);
}
}
{
obj_t list1658_877;
list1658_877 = MAKE_PAIR(BNIL, BNIL);
arg1655_874 = cons__138___r4_pairs_and_lists_6_3(arg1656_875, list1658_877);
}
}
arg1628_853 = append_2_18___r4_pairs_and_lists_6_3(arg1654_873, arg1655_874);
}
{
obj_t list1629_854;
{
obj_t arg1630_855;
arg1630_855 = MAKE_PAIR(arg1628_853, BNIL);
list1629_854 = MAKE_PAIR(arg1627_852, arg1630_855);
}
arg1621_847 = cons__138___r4_pairs_and_lists_6_3(arg1625_851, list1629_854);
}
}
{
obj_t list1623_849;
list1623_849 = MAKE_PAIR(BNIL, BNIL);
arg1617_843 = cons__138___r4_pairs_and_lists_6_3(arg1621_847, list1623_849);
}
}
arg1594_827 = append_2_18___r4_pairs_and_lists_6_3(arg1615_842, arg1617_843);
}
{
obj_t list1595_828;
{
obj_t arg1598_829;
{
obj_t arg1600_830;
arg1600_830 = MAKE_PAIR(arg1594_827, BNIL);
arg1598_829 = MAKE_PAIR(arg1593_826, arg1600_830);
}
list1595_828 = MAKE_PAIR(arg1592_825, arg1598_829);
}
arg1583_818 = cons__138___r4_pairs_and_lists_6_3(arg1589_824, list1595_828);
}
}
{
obj_t arg1711_927;
arg1711_927 = symbol1958___rgc_expand;
{
obj_t list1713_929;
list1713_929 = MAKE_PAIR(BNIL, BNIL);
arg1584_819 = cons__138___r4_pairs_and_lists_6_3(arg1711_927, list1713_929);
}
}
{
obj_t list1586_821;
{
obj_t arg1587_822;
arg1587_822 = MAKE_PAIR(BNIL, BNIL);
list1586_821 = MAKE_PAIR(arg1584_819, arg1587_822);
}
arg1569_808 = cons__138___r4_pairs_and_lists_6_3(arg1583_818, list1586_821);
}
}
arg1116_445 = append_2_18___r4_pairs_and_lists_6_3(arg1568_807, arg1569_808);
}
{
obj_t list1117_446;
{
obj_t arg1118_447;
{
obj_t arg1119_448;
{
obj_t arg1120_449;
{
obj_t arg1121_450;
{
obj_t arg1122_451;
{
obj_t arg1123_452;
{
obj_t arg1124_453;
{
obj_t arg1125_454;
{
obj_t arg1126_455;
{
obj_t arg1127_456;
{
obj_t arg1128_457;
arg1128_457 = MAKE_PAIR(arg1116_445, BNIL);
arg1127_456 = MAKE_PAIR(arg1115_444, arg1128_457);
}
arg1126_455 = MAKE_PAIR(arg1114_443, arg1127_456);
}
arg1125_454 = MAKE_PAIR(arg1113_442, arg1126_455);
}
arg1124_453 = MAKE_PAIR(arg1112_441, arg1125_454);
}
arg1123_452 = MAKE_PAIR(arg1111_440, arg1124_453);
}
arg1122_451 = MAKE_PAIR(arg1110_439, arg1123_452);
}
arg1121_450 = MAKE_PAIR(arg1109_438, arg1122_451);
}
arg1120_449 = MAKE_PAIR(arg1108_437, arg1121_450);
}
arg1119_448 = MAKE_PAIR(arg1107_436, arg1120_449);
}
arg1118_447 = MAKE_PAIR(arg1106_435, arg1119_448);
}
list1117_446 = MAKE_PAIR(arg1105_434, arg1118_447);
}
arg1103_432 = cons__138___r4_pairs_and_lists_6_3(arg1104_433, list1117_446);
}
}
arg1095_424 = append_2_18___r4_pairs_and_lists_6_3(states_5, arg1103_432);
}
{
obj_t list1096_425;
{
obj_t arg1097_426;
arg1097_426 = MAKE_PAIR(arg1095_424, BNIL);
list1096_425 = MAKE_PAIR(arg1094_423, arg1097_426);
}
arg1078_407 = cons__138___r4_pairs_and_lists_6_3(arg1093_422, list1096_425);
}
}
{
obj_t list1080_409;
{
obj_t arg1081_410;
{
obj_t arg1082_411;
arg1082_411 = MAKE_PAIR(BNIL, BNIL);
arg1081_410 = MAKE_PAIR(arg1078_407, arg1082_411);
}
list1080_409 = MAKE_PAIR(arg1077_406, arg1081_410);
}
return cons__138___r4_pairs_and_lists_6_3(arg1076_405, list1080_409);
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___rgc_expand()
{
module_initialization_70___rgc_rules(((long)0), "__RGC_EXPAND");
module_initialization_70___rgc_tree(((long)0), "__RGC_EXPAND");
module_initialization_70___rgc_dfa(((long)0), "__RGC_EXPAND");
module_initialization_70___rgc_compile(((long)0), "__RGC_EXPAND");
module_initialization_70___rgc_config(((long)0), "__RGC_EXPAND");
return module_initialization_70___error(((long)0), "__RGC_EXPAND");
}

