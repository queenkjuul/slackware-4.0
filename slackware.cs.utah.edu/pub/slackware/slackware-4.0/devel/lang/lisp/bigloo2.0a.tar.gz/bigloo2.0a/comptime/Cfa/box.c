/*===========================================================================*/
/*   (Cfa/box.scm)                                                           */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_box();
extern obj_t make_box_202_ast_node;
extern obj_t _optim__89_engine_param;
extern obj_t box_set__cinfo_94_cfa_info;
extern obj_t make_box_cinfo_127_cfa_info;
static obj_t node_setup__pre_make_box_50_cfa_box(obj_t, obj_t);
extern obj_t box_ref_242_ast_node;
static obj_t cfa__make_box_o_cinfo_123_cfa_box(obj_t, obj_t);
static obj_t node_setup__box_set__65_cfa_box(obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t _obj__252_type_cache;
extern obj_t box_ref_o_cinfo_98_cfa_info;
extern approx_t make_type_approx_184_cfa_approx(type_t);
extern approx_t make_empty_approx_131_cfa_approx();
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t _unspec__87_type_cache;
extern obj_t module_initialization_70_cfa_box(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_cfa_setup(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_cfa_closure(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t make_box_o_cinfo_96_cfa_info;
extern approx_t union_approx__241_cfa_approx(approx_t, approx_t);
extern obj_t pre_make_box_186_cfa_info;
extern long class_num_218___object(obj_t);
static obj_t cfa__box_set__o_cinfo_199_cfa_box(obj_t, obj_t);
static obj_t _stack_loose_alloc_2441_94_cfa_loose(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_cfa_box();
static obj_t _loose_alloc_2438_99_cfa_loose(obj_t, obj_t);
extern obj_t node_setup__189_cfa_setup(node_t);
static obj_t stack_loose_alloc__make_box_48_cfa_box(obj_t, obj_t, obj_t);
extern obj_t approx_set_top__187_cfa_approx(approx_t);
static obj_t node_setup__make_box_254_cfa_box(obj_t, obj_t);
extern obj_t box_set__o_cinfo_6_cfa_info;
static obj_t library_modules_init_112_cfa_box();
extern approx_t cfa__102_cfa_cfa(node_t);
static obj_t _node_setup_2434_24_cfa_setup(obj_t, obj_t);
static obj_t arg2414_cfa_box(obj_t, obj_t);
extern obj_t for_each_approx_alloc_83_cfa_approx(obj_t, approx_t);
static obj_t arg2401_cfa_box(obj_t, obj_t);
static obj_t toplevel_init_63_cfa_box();
extern obj_t open_input_string(obj_t);
extern obj_t box_set__221_ast_node;
extern obj_t box_ref_cinfo_214_cfa_info;
static obj_t _cfa_2436_110_cfa_cfa(obj_t, obj_t);
static obj_t loose_alloc__make_box_109_cfa_box(obj_t, obj_t);
static obj_t cfa__box_ref_o_cinfo_85_cfa_box(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
static obj_t node_setup__box_ref_19_cfa_box(obj_t, obj_t);
static obj_t require_initialization_114_cfa_box = BUNSPEC;
extern approx_t make_type_alloc_approx_134_cfa_approx(type_t, node_t);
extern approx_t loose__226_cfa_loose(approx_t, obj_t);
extern obj_t class_super_145___object(obj_t);
static obj_t cnst_init_137_cfa_box();
static obj_t __cnst[1];

extern obj_t loose_alloc__env_83_cfa_loose;
DEFINE_STATIC_PROCEDURE(proc2449_cfa_box, loose_alloc__make_box_109_cfa_box2459, loose_alloc__make_box_109_cfa_box, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2450_cfa_box, stack_loose_alloc__make_box_48_cfa_box2460, stack_loose_alloc__make_box_48_cfa_box, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2448_cfa_box, cfa__box_set__o_cinfo_199_cfa_box2461, cfa__box_set__o_cinfo_199_cfa_box, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2447_cfa_box, cfa__box_ref_o_cinfo_85_cfa_box2462, cfa__box_ref_o_cinfo_85_cfa_box, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2446_cfa_box, cfa__make_box_o_cinfo_123_cfa_box2463, cfa__make_box_o_cinfo_123_cfa_box, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2445_cfa_box, node_setup__box_ref_19_cfa_box2464, node_setup__box_ref_19_cfa_box, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2444_cfa_box, node_setup__box_set__65_cfa_box2465, node_setup__box_set__65_cfa_box, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2443_cfa_box, node_setup__pre_make_box_50_cfa_box2466, node_setup__pre_make_box_50_cfa_box, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2442_cfa_box, node_setup__make_box_254_cfa_box2467, node_setup__make_box_254_cfa_box, 0L, 1);
extern obj_t cfa__env_153_cfa_cfa;
extern obj_t stack_loose_alloc__env_147_cfa_loose;
DEFINE_STRING(string2453_cfa_box, string2453_cfa_box2468, "ALL ", 4);
DEFINE_STRING(string2452_cfa_box, string2452_cfa_box2469, "Illegal mixed of optimized and unoptimize `make-box'", 52);
DEFINE_STRING(string2451_cfa_box, string2451_cfa_box2470, "box-ref", 7);
extern obj_t node_setup__env_214_cfa_setup;


/* module-initialization */ obj_t 
module_initialization_70_cfa_box(long checksum_3468, char *from_3469)
{
   if (CBOOL(require_initialization_114_cfa_box))
     {
	require_initialization_114_cfa_box = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_box();
	cnst_init_137_cfa_box();
	imported_modules_init_94_cfa_box();
	method_init_76_cfa_box();
	toplevel_init_63_cfa_box();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_box()
{
   module_initialization_70___object(((long) 0), "CFA_BOX");
   module_initialization_70___reader(((long) 0), "CFA_BOX");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_box()
{
   {
      obj_t cnst_port_138_3460;
      cnst_port_138_3460 = open_input_string(string2453_cfa_box);
      {
	 long i_3461;
	 i_3461 = ((long) 0);
       loop_3462:
	 {
	    bool_t test2454_3463;
	    test2454_3463 = (i_3461 == ((long) -1));
	    if (test2454_3463)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2455_3464;
		    {
		       obj_t list2456_3465;
		       {
			  obj_t arg2457_3466;
			  arg2457_3466 = BNIL;
			  list2456_3465 = MAKE_PAIR(cnst_port_138_3460, arg2457_3466);
		       }
		       arg2455_3464 = read___reader(list2456_3465);
		    }
		    CNST_TABLE_SET(i_3461, arg2455_3464);
		 }
		 {
		    int aux_3467;
		    {
		       long aux_3486;
		       aux_3486 = (i_3461 - ((long) 1));
		       aux_3467 = (int) (aux_3486);
		    }
		    {
		       long i_3489;
		       i_3489 = (long) (aux_3467);
		       i_3461 = i_3489;
		       goto loop_3462;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_box()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_cfa_box()
{
   {
      obj_t node_setup__make_box_254_3423;
      node_setup__make_box_254_3423 = proc2442_cfa_box;
      add_method__1___object(node_setup__env_214_cfa_setup, make_box_202_ast_node, node_setup__make_box_254_3423);
   }
   {
      obj_t node_setup__pre_make_box_50_3422;
      node_setup__pre_make_box_50_3422 = proc2443_cfa_box;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_make_box_186_cfa_info, node_setup__pre_make_box_50_3422);
   }
   {
      obj_t node_setup__box_set__65_3421;
      node_setup__box_set__65_3421 = proc2444_cfa_box;
      add_method__1___object(node_setup__env_214_cfa_setup, box_set__221_ast_node, node_setup__box_set__65_3421);
   }
   {
      obj_t node_setup__box_ref_19_3420;
      node_setup__box_ref_19_3420 = proc2445_cfa_box;
      add_method__1___object(node_setup__env_214_cfa_setup, box_ref_242_ast_node, node_setup__box_ref_19_3420);
   }
   {
      obj_t cfa__make_box_o_cinfo_123_3419;
      cfa__make_box_o_cinfo_123_3419 = proc2446_cfa_box;
      add_method__1___object(cfa__env_153_cfa_cfa, make_box_o_cinfo_96_cfa_info, cfa__make_box_o_cinfo_123_3419);
   }
   {
      obj_t cfa__box_ref_o_cinfo_85_3418;
      cfa__box_ref_o_cinfo_85_3418 = proc2447_cfa_box;
      add_method__1___object(cfa__env_153_cfa_cfa, box_ref_o_cinfo_98_cfa_info, cfa__box_ref_o_cinfo_85_3418);
   }
   {
      obj_t cfa__box_set__o_cinfo_199_3416;
      cfa__box_set__o_cinfo_199_3416 = proc2448_cfa_box;
      add_method__1___object(cfa__env_153_cfa_cfa, box_set__o_cinfo_6_cfa_info, cfa__box_set__o_cinfo_199_3416);
   }
   {
      obj_t loose_alloc__make_box_109_3414;
      loose_alloc__make_box_109_3414 = proc2449_cfa_box;
      add_method__1___object(loose_alloc__env_83_cfa_loose, make_box_202_ast_node, loose_alloc__make_box_109_3414);
   }
   {
      obj_t stack_loose_alloc__make_box_48_3413;
      stack_loose_alloc__make_box_48_3413 = proc2450_cfa_box;
      return add_method__1___object(stack_loose_alloc__env_147_cfa_loose, make_box_202_ast_node, stack_loose_alloc__make_box_48_3413);
   }
}


/* stack-loose-alloc!-make-box */ obj_t 
stack_loose_alloc__make_box_48_cfa_box(obj_t env_3424, obj_t alloc_3425, obj_t cowner_3426)
{
   {
      make_box_202_t alloc_2982;
      obj_t cowner_2983;
      alloc_2982 = (make_box_202_t) (alloc_3425);
      cowner_2983 = cowner_3426;
      return BUNSPEC;
   }
}


/* loose-alloc!-make-box */ obj_t 
loose_alloc__make_box_109_cfa_box(obj_t env_3427, obj_t alloc_3428)
{
   {
      make_box_202_t alloc_2977;
      alloc_2977 = (make_box_202_t) (alloc_3428);
      return BUNSPEC;
   }
}


/* cfa!-box-set!/o-cinfo */ obj_t 
cfa__box_set__o_cinfo_199_cfa_box(obj_t env_3429, obj_t node_3430)
{
   {
      box_set__o_cinfo_6_t node_2954;
      {
	 approx_t aux_3502;
	 node_2954 = (box_set__o_cinfo_6_t) (node_3430);
	 {
	    approx_t box_approx_152_2958;
	    approx_t val_approx_22_2959;
	    {
	       node_t aux_3503;
	       {
		  var_t aux_3504;
		  {
		     box_set__221_t obj_3406;
		     obj_3406 = (box_set__221_t) (node_2954);
		     aux_3504 = (((box_set__221_t) CREF(obj_3406))->var);
		  }
		  aux_3503 = (node_t) (aux_3504);
	       }
	       box_approx_152_2958 = cfa__102_cfa_cfa(aux_3503);
	    }
	    {
	       node_t aux_3509;
	       {
		  box_set__221_t obj_3407;
		  obj_3407 = (box_set__221_t) (node_2954);
		  aux_3509 = (((box_set__221_t) CREF(obj_3407))->value);
	       }
	       val_approx_22_2959 = cfa__102_cfa_cfa(aux_3509);
	    }
	    if ((((approx_t) CREF(box_approx_152_2958))->top__138))
	      {
		 approx_t aux_3515;
		 aux_3515 = loose__226_cfa_loose(val_approx_22_2959, CNST_TABLE_REF(((long) 0)));
		 (obj_t) (aux_3515);
	      }
	    else
	      {
		 obj_t arg2414_3415;
		 arg2414_3415 = make_fx_procedure(arg2414_cfa_box, ((long) 1), ((long) 2));
		 {
		    obj_t aux_3520;
		    aux_3520 = (obj_t) (node_2954);
		    PROCEDURE_SET(arg2414_3415, ((long) 0), aux_3520);
		 }
		 {
		    obj_t aux_3523;
		    aux_3523 = (obj_t) (val_approx_22_2959);
		    PROCEDURE_SET(arg2414_3415, ((long) 1), aux_3523);
		 }
		 for_each_approx_alloc_83_cfa_approx(arg2414_3415, box_approx_152_2958);
	      }
	 }
	 {
	    obj_t aux_3527;
	    {
	       object_t aux_3528;
	       aux_3528 = (object_t) (node_2954);
	       aux_3527 = OBJECT_WIDENING(aux_3528);
	    }
	    aux_3502 = (((box_set__o_cinfo_6_t) CREF(aux_3527))->approx);
	 }
	 return (obj_t) (aux_3502);
      }
   }
}


/* arg2414 */ obj_t 
arg2414_cfa_box(obj_t env_3431, obj_t box_3434)
{
   {
      obj_t node_3432;
      obj_t val_approx_22_3433;
      node_3432 = PROCEDURE_REF(env_3431, ((long) 0));
      val_approx_22_3433 = PROCEDURE_REF(env_3431, ((long) 1));
      {
	 obj_t box_2963;
	 box_2963 = box_3434;
	 {
	    bool_t test2416_2965;
	    test2416_2965 = is_a__118___object(box_2963, make_box_o_cinfo_96_cfa_info);
	    if (test2416_2965)
	      {
		 {
		    approx_t aux_3538;
		    {
		       approx_t aux_3539;
		       {
			  make_box_o_cinfo_96_t obj_3410;
			  obj_3410 = (make_box_o_cinfo_96_t) (box_2963);
			  {
			     obj_t aux_3541;
			     {
				object_t aux_3542;
				aux_3542 = (object_t) (obj_3410);
				aux_3541 = OBJECT_WIDENING(aux_3542);
			     }
			     aux_3539 = (((make_box_o_cinfo_96_t) CREF(aux_3541))->value_approx_19);
			  }
		       }
		       aux_3538 = union_approx__241_cfa_approx(aux_3539, (approx_t) (val_approx_22_3433));
		    }
		    return (obj_t) (aux_3538);
		 }
	      }
	    else
	      {
		 bool_t test2418_2968;
		 test2418_2968 = is_a__118___object(box_2963, make_box_cinfo_127_cfa_info);
		 if (test2418_2968)
		   {
		      {
			 obj_t arg2421_2971;
			 arg2421_2971 = shape_tools_shape(node_3432);
			 return internal_error_43_tools_error(string2451_cfa_box, string2452_cfa_box, arg2421_2971);
		      }
		   }
		 else
		   {
		      return BFALSE;
		   }
	      }
	 }
      }
   }
}


/* cfa!-box-ref/o-cinfo */ obj_t 
cfa__box_ref_o_cinfo_85_cfa_box(obj_t env_3435, obj_t node_3436)
{
   {
      box_ref_o_cinfo_98_t node_2934;
      {
	 approx_t aux_3553;
	 node_2934 = (box_ref_o_cinfo_98_t) (node_3436);
	 {
	    approx_t box_approx_152_2938;
	    {
	       node_t aux_3554;
	       {
		  var_t aux_3555;
		  {
		     box_ref_242_t obj_3400;
		     obj_3400 = (box_ref_242_t) (node_2934);
		     aux_3555 = (((box_ref_242_t) CREF(obj_3400))->var);
		  }
		  aux_3554 = (node_t) (aux_3555);
	       }
	       box_approx_152_2938 = cfa__102_cfa_cfa(aux_3554);
	    }
	    {
	       obj_t arg2401_3417;
	       arg2401_3417 = make_fx_procedure(arg2401_cfa_box, ((long) 1), ((long) 2));
	       {
		  obj_t aux_3561;
		  aux_3561 = (obj_t) (node_2934);
		  PROCEDURE_SET(arg2401_3417, ((long) 0), aux_3561);
	       }
	       {
		  obj_t aux_3564;
		  aux_3564 = (obj_t) (node_2934);
		  PROCEDURE_SET(arg2401_3417, ((long) 1), aux_3564);
	       }
	       for_each_approx_alloc_83_cfa_approx(arg2401_3417, box_approx_152_2938);
	    }
	 }
	 {
	    obj_t aux_3568;
	    {
	       object_t aux_3569;
	       aux_3569 = (object_t) (node_2934);
	       aux_3568 = OBJECT_WIDENING(aux_3569);
	    }
	    aux_3553 = (((box_ref_o_cinfo_98_t) CREF(aux_3568))->approx);
	 }
	 return (obj_t) (aux_3553);
      }
   }
}


/* arg2401 */ obj_t 
arg2401_cfa_box(obj_t env_3437, obj_t box_3440)
{
   {
      obj_t node_3438;
      obj_t instance2089_3439;
      node_3438 = PROCEDURE_REF(env_3437, ((long) 0));
      instance2089_3439 = PROCEDURE_REF(env_3437, ((long) 1));
      {
	 obj_t box_2940;
	 box_2940 = box_3440;
	 {
	    bool_t test2403_2942;
	    test2403_2942 = is_a__118___object(box_2940, make_box_o_cinfo_96_cfa_info);
	    if (test2403_2942)
	      {
		 {
		    approx_t aux_3579;
		    {
		       approx_t aux_3587;
		       approx_t aux_3580;
		       {
			  make_box_o_cinfo_96_t obj_3403;
			  obj_3403 = (make_box_o_cinfo_96_t) (box_2940);
			  {
			     obj_t aux_3589;
			     {
				object_t aux_3590;
				aux_3590 = (object_t) (obj_3403);
				aux_3589 = OBJECT_WIDENING(aux_3590);
			     }
			     aux_3587 = (((make_box_o_cinfo_96_t) CREF(aux_3589))->value_approx_19);
			  }
		       }
		       {
			  box_ref_o_cinfo_98_t obj_3402;
			  obj_3402 = (box_ref_o_cinfo_98_t) (instance2089_3439);
			  {
			     obj_t aux_3582;
			     {
				object_t aux_3583;
				aux_3583 = (object_t) (obj_3402);
				aux_3582 = OBJECT_WIDENING(aux_3583);
			     }
			     aux_3580 = (((box_ref_o_cinfo_98_t) CREF(aux_3582))->approx);
			  }
		       }
		       aux_3579 = union_approx__241_cfa_approx(aux_3580, aux_3587);
		    }
		    return (obj_t) (aux_3579);
		 }
	      }
	    else
	      {
		 bool_t test2406_2946;
		 test2406_2946 = is_a__118___object(box_2940, make_box_cinfo_127_cfa_info);
		 if (test2406_2946)
		   {
		      {
			 obj_t arg2409_2949;
			 arg2409_2949 = shape_tools_shape(node_3438);
			 return internal_error_43_tools_error(string2451_cfa_box, string2452_cfa_box, arg2409_2949);
		      }
		   }
		 else
		   {
		      return BFALSE;
		   }
	      }
	 }
      }
   }
}


/* cfa!-make-box/o-cinfo */ obj_t 
cfa__make_box_o_cinfo_123_cfa_box(obj_t env_3441, obj_t node_3442)
{
   {
      make_box_o_cinfo_96_t node_2925;
      {
	 approx_t aux_3600;
	 node_2925 = (make_box_o_cinfo_96_t) (node_3442);
	 {
	    approx_t init_value_approx_9_2929;
	    {
	       node_t aux_3601;
	       {
		  make_box_202_t obj_3397;
		  obj_3397 = (make_box_202_t) (node_2925);
		  aux_3601 = (((make_box_202_t) CREF(obj_3397))->value);
	       }
	       init_value_approx_9_2929 = cfa__102_cfa_cfa(aux_3601);
	    }
	    {
	       approx_t aux_3605;
	       {
		  obj_t aux_3606;
		  {
		     object_t aux_3607;
		     aux_3607 = (object_t) (node_2925);
		     aux_3606 = OBJECT_WIDENING(aux_3607);
		  }
		  aux_3605 = (((make_box_o_cinfo_96_t) CREF(aux_3606))->value_approx_19);
	       }
	       union_approx__241_cfa_approx(aux_3605, init_value_approx_9_2929);
	    }
	    {
	       obj_t aux_3612;
	       {
		  object_t aux_3613;
		  aux_3613 = (object_t) (node_2925);
		  aux_3612 = OBJECT_WIDENING(aux_3613);
	       }
	       aux_3600 = (((make_box_o_cinfo_96_t) CREF(aux_3612))->approx);
	    }
	 }
	 return (obj_t) (aux_3600);
      }
   }
}


/* node-setup!-box-ref */ obj_t 
node_setup__box_ref_19_cfa_box(obj_t env_3443, obj_t node_3444)
{
   {
      box_ref_242_t node_2908;
      node_2908 = (box_ref_242_t) (node_3444);
      {
	 node_t aux_3619;
	 {
	    var_t aux_3620;
	    aux_3620 = (((box_ref_242_t) CREF(node_2908))->var);
	    aux_3619 = (node_t) (aux_3620);
	 }
	 node_setup__189_cfa_setup(aux_3619);
      }
      {
	 bool_t test2384_2913;
	 {
	    long n1_3382;
	    n1_3382 = (long) CINT(_optim__89_engine_param);
	    test2384_2913 = (n1_3382 >= ((long) 1));
	 }
	 if (test2384_2913)
	   {
	      box_ref_o_cinfo_98_t obj2086_2914;
	      obj2086_2914 = ((box_ref_o_cinfo_98_t) (node_2908));
	      {
		 box_ref_o_cinfo_98_t arg2385_2915;
		 {
		    approx_t arg2386_2916;
		    arg2386_2916 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
		    {
		       box_ref_o_cinfo_98_t res2431_3387;
		       {
			  box_ref_o_cinfo_98_t new1785_3385;
			  new1785_3385 = ((box_ref_o_cinfo_98_t) BREF(GC_MALLOC(sizeof(struct box_ref_o_cinfo_98))));
			  ((((box_ref_o_cinfo_98_t) CREF(new1785_3385))->approx) = ((approx_t) arg2386_2916), BUNSPEC);
			  res2431_3387 = new1785_3385;
		       }
		       arg2385_2915 = res2431_3387;
		    }
		 }
		 {
		    obj_t aux_3634;
		    object_t aux_3632;
		    aux_3634 = (obj_t) (arg2385_2915);
		    aux_3632 = (object_t) (obj2086_2914);
		    OBJECT_WIDENING_SET(aux_3632, aux_3634);
		 }
	      }
	      {
		 long arg2387_2917;
		 arg2387_2917 = class_num_218___object(box_ref_o_cinfo_98_cfa_info);
		 {
		    obj_t obj_3388;
		    obj_3388 = (obj_t) (obj2086_2914);
		    (((obj_t) CREF(obj_3388))->header = MAKE_HEADER(arg2387_2917, 0), BUNSPEC);
		 }
	      }
	      return (obj_t) (obj2086_2914);
	   }
	 else
	   {
	      {
		 box_ref_cinfo_214_t obj2087_2918;
		 obj2087_2918 = ((box_ref_cinfo_214_t) (node_2908));
		 {
		    box_ref_cinfo_214_t arg2388_2919;
		    {
		       approx_t arg2390_2920;
		       arg2390_2920 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
		       {
			  box_ref_cinfo_214_t res2432_3393;
			  {
			     box_ref_cinfo_214_t new1766_3391;
			     new1766_3391 = ((box_ref_cinfo_214_t) BREF(GC_MALLOC(sizeof(struct box_ref_cinfo_214))));
			     ((((box_ref_cinfo_214_t) CREF(new1766_3391))->approx) = ((approx_t) arg2390_2920), BUNSPEC);
			     res2432_3393 = new1766_3391;
			  }
			  arg2388_2919 = res2432_3393;
		       }
		    }
		    {
		       obj_t aux_3648;
		       object_t aux_3646;
		       aux_3648 = (obj_t) (arg2388_2919);
		       aux_3646 = (object_t) (obj2087_2918);
		       OBJECT_WIDENING_SET(aux_3646, aux_3648);
		    }
		 }
		 {
		    long arg2392_2921;
		    arg2392_2921 = class_num_218___object(box_ref_cinfo_214_cfa_info);
		    {
		       obj_t obj_3394;
		       obj_3394 = (obj_t) (obj2087_2918);
		       (((obj_t) CREF(obj_3394))->header = MAKE_HEADER(arg2392_2921, 0), BUNSPEC);
		    }
		 }
		 obj2087_2918;
	      }
	      {
		 approx_t aux_3654;
		 {
		    box_ref_cinfo_214_t obj_3396;
		    obj_3396 = (box_ref_cinfo_214_t) (node_2908);
		    {
		       obj_t aux_3656;
		       {
			  object_t aux_3657;
			  aux_3657 = (object_t) (obj_3396);
			  aux_3656 = OBJECT_WIDENING(aux_3657);
		       }
		       aux_3654 = (((box_ref_cinfo_214_t) CREF(aux_3656))->approx);
		    }
		 }
		 return approx_set_top__187_cfa_approx(aux_3654);
	      }
	   }
      }
   }
}


/* node-setup!-box-set! */ obj_t 
node_setup__box_set__65_cfa_box(obj_t env_3445, obj_t node_3446)
{
   {
      box_set__221_t node_2891;
      node_2891 = (box_set__221_t) (node_3446);
      {
	 node_t aux_3663;
	 {
	    var_t aux_3664;
	    aux_3664 = (((box_set__221_t) CREF(node_2891))->var);
	    aux_3663 = (node_t) (aux_3664);
	 }
	 node_setup__189_cfa_setup(aux_3663);
      }
      node_setup__189_cfa_setup((((box_set__221_t) CREF(node_2891))->value));
      {
	 bool_t test2374_2897;
	 {
	    long n1_3367;
	    n1_3367 = (long) CINT(_optim__89_engine_param);
	    test2374_2897 = (n1_3367 >= ((long) 1));
	 }
	 if (test2374_2897)
	   {
	      box_set__o_cinfo_6_t obj2083_2898;
	      obj2083_2898 = ((box_set__o_cinfo_6_t) (node_2891));
	      {
		 box_set__o_cinfo_6_t arg2375_2899;
		 {
		    approx_t arg2376_2900;
		    arg2376_2900 = make_type_approx_184_cfa_approx((type_t) (_unspec__87_type_cache));
		    {
		       box_set__o_cinfo_6_t res2429_3372;
		       {
			  box_set__o_cinfo_6_t new1776_3370;
			  new1776_3370 = ((box_set__o_cinfo_6_t) BREF(GC_MALLOC(sizeof(struct box_set__o_cinfo_6))));
			  ((((box_set__o_cinfo_6_t) CREF(new1776_3370))->approx) = ((approx_t) arg2376_2900), BUNSPEC);
			  res2429_3372 = new1776_3370;
		       }
		       arg2375_2899 = res2429_3372;
		    }
		 }
		 {
		    obj_t aux_3680;
		    object_t aux_3678;
		    aux_3680 = (obj_t) (arg2375_2899);
		    aux_3678 = (object_t) (obj2083_2898);
		    OBJECT_WIDENING_SET(aux_3678, aux_3680);
		 }
	      }
	      {
		 long arg2377_2901;
		 arg2377_2901 = class_num_218___object(box_set__o_cinfo_6_cfa_info);
		 {
		    obj_t obj_3373;
		    obj_3373 = (obj_t) (obj2083_2898);
		    (((obj_t) CREF(obj_3373))->header = MAKE_HEADER(arg2377_2901, 0), BUNSPEC);
		 }
	      }
	      return (obj_t) (obj2083_2898);
	   }
	 else
	   {
	      box_set__cinfo_94_t obj2084_2902;
	      obj2084_2902 = ((box_set__cinfo_94_t) (node_2891));
	      {
		 box_set__cinfo_94_t arg2378_2903;
		 {
		    approx_t arg2379_2904;
		    arg2379_2904 = make_type_approx_184_cfa_approx((type_t) (_unspec__87_type_cache));
		    {
		       box_set__cinfo_94_t res2430_3378;
		       {
			  box_set__cinfo_94_t new1757_3376;
			  new1757_3376 = ((box_set__cinfo_94_t) BREF(GC_MALLOC(sizeof(struct box_set__cinfo_94))));
			  ((((box_set__cinfo_94_t) CREF(new1757_3376))->approx) = ((approx_t) arg2379_2904), BUNSPEC);
			  res2430_3378 = new1757_3376;
		       }
		       arg2378_2903 = res2430_3378;
		    }
		 }
		 {
		    obj_t aux_3694;
		    object_t aux_3692;
		    aux_3694 = (obj_t) (arg2378_2903);
		    aux_3692 = (object_t) (obj2084_2902);
		    OBJECT_WIDENING_SET(aux_3692, aux_3694);
		 }
	      }
	      {
		 long arg2380_2905;
		 arg2380_2905 = class_num_218___object(box_set__cinfo_94_cfa_info);
		 {
		    obj_t obj_3379;
		    obj_3379 = (obj_t) (obj2084_2902);
		    (((obj_t) CREF(obj_3379))->header = MAKE_HEADER(arg2380_2905, 0), BUNSPEC);
		 }
	      }
	      return (obj_t) (obj2084_2902);
	   }
      }
   }
}


/* node-setup!-pre-make-box */ obj_t 
node_setup__pre_make_box_50_cfa_box(obj_t env_3447, obj_t node_3448)
{
   {
      pre_make_box_186_t node_2872;
      node_2872 = (pre_make_box_186_t) (node_3448);
      {
	 node_t aux_3702;
	 {
	    make_box_202_t obj_3343;
	    obj_3343 = (make_box_202_t) (node_2872);
	    aux_3702 = (((make_box_202_t) CREF(obj_3343))->value);
	 }
	 node_setup__189_cfa_setup(aux_3702);
      }
      {
	 pre_make_box_186_t node_2877;
	 {
	    long arg2368_2886;
	    {
	       obj_t arg2369_2887;
	       {
		  obj_t arg2370_2888;
		  {
		     object_t object_3344;
		     object_3344 = (object_t) (node_2872);
		     {
			long arg1180_3345;
			{
			   long arg1181_3346;
			   long arg1182_3347;
			   arg1181_3346 = TYPE(object_3344);
			   arg1182_3347 = OBJECT_TYPE;
			   arg1180_3345 = (arg1181_3346 - arg1182_3347);
			}
			{
			   obj_t vector_3351;
			   vector_3351 = _classes__134___object;
			   arg2370_2888 = VECTOR_REF(vector_3351, arg1180_3345);
			}
		     }
		  }
		  arg2369_2887 = class_super_145___object(arg2370_2888);
	       }
	       arg2368_2886 = class_num_218___object(arg2369_2887);
	    }
	    {
	       obj_t obj_3353;
	       obj_3353 = (obj_t) (node_2872);
	       (((obj_t) CREF(obj_3353))->header = MAKE_HEADER(arg2368_2886, 0), BUNSPEC);
	    }
	 }
	 {
	    object_t aux_3715;
	    aux_3715 = (object_t) (node_2872);
	    OBJECT_WIDENING_SET(aux_3715, BFALSE);
	 }
	 node_2877 = node_2872;
	 {
	    {
	       make_box_o_cinfo_96_t node_2878;
	       {
		  make_box_o_cinfo_96_t obj2081_2880;
		  obj2081_2880 = ((make_box_o_cinfo_96_t) (node_2877));
		  {
		     make_box_o_cinfo_96_t arg2364_2881;
		     {
			approx_t arg2365_2882;
			approx_t arg2366_2883;
			arg2365_2882 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
			arg2366_2883 = make_empty_approx_131_cfa_approx();
			{
			   make_box_o_cinfo_96_t res2428_3360;
			   {
			      make_box_o_cinfo_96_t new1745_3357;
			      new1745_3357 = ((make_box_o_cinfo_96_t) BREF(GC_MALLOC(sizeof(struct make_box_o_cinfo_96))));
			      ((((make_box_o_cinfo_96_t) CREF(new1745_3357))->approx) = ((approx_t) arg2365_2882), BUNSPEC);
			      ((((make_box_o_cinfo_96_t) CREF(new1745_3357))->value_approx_19) = ((approx_t) arg2366_2883), BUNSPEC);
			      res2428_3360 = new1745_3357;
			   }
			   arg2364_2881 = res2428_3360;
			}
		     }
		     {
			obj_t aux_3727;
			object_t aux_3725;
			aux_3727 = (obj_t) (arg2364_2881);
			aux_3725 = (object_t) (obj2081_2880);
			OBJECT_WIDENING_SET(aux_3725, aux_3727);
		     }
		  }
		  {
		     long arg2367_2884;
		     arg2367_2884 = class_num_218___object(make_box_o_cinfo_96_cfa_info);
		     {
			obj_t obj_3361;
			obj_3361 = (obj_t) (obj2081_2880);
			(((obj_t) CREF(obj_3361))->header = MAKE_HEADER(arg2367_2884, 0), BUNSPEC);
		     }
		  }
		  node_2878 = obj2081_2880;
	       }
	       {
		  approx_t arg2363_2879;
		  arg2363_2879 = make_type_alloc_approx_134_cfa_approx((type_t) (_obj__252_type_cache), (node_t) (node_2878));
		  {
		     obj_t aux_3736;
		     {
			object_t aux_3737;
			aux_3737 = (object_t) (node_2878);
			aux_3736 = OBJECT_WIDENING(aux_3737);
		     }
		     return ((((make_box_o_cinfo_96_t) CREF(aux_3736))->approx) = ((approx_t) arg2363_2879), BUNSPEC);
		  }
	       }
	    }
	 }
      }
   }
}


/* node-setup!-make-box */ obj_t 
node_setup__make_box_254_cfa_box(obj_t env_3449, obj_t node_3450)
{
   {
      make_box_202_t node_2860;
      node_2860 = (make_box_202_t) (node_3450);
      node_setup__189_cfa_setup((((make_box_202_t) CREF(node_2860))->value));
      {
	 make_box_cinfo_127_t obj2078_2865;
	 obj2078_2865 = ((make_box_cinfo_127_t) (node_2860));
	 {
	    make_box_cinfo_127_t arg2356_2866;
	    {
	       approx_t arg2357_2867;
	       arg2357_2867 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
	       {
		  make_box_cinfo_127_t res2427_3339;
		  {
		     make_box_cinfo_127_t new1735_3337;
		     new1735_3337 = ((make_box_cinfo_127_t) BREF(GC_MALLOC(sizeof(struct make_box_cinfo_127))));
		     ((((make_box_cinfo_127_t) CREF(new1735_3337))->approx) = ((approx_t) arg2357_2867), BUNSPEC);
		     res2427_3339 = new1735_3337;
		  }
		  arg2356_2866 = res2427_3339;
	       }
	    }
	    {
	       obj_t aux_3751;
	       object_t aux_3749;
	       aux_3751 = (obj_t) (arg2356_2866);
	       aux_3749 = (object_t) (obj2078_2865);
	       OBJECT_WIDENING_SET(aux_3749, aux_3751);
	    }
	 }
	 {
	    long arg2358_2868;
	    arg2358_2868 = class_num_218___object(make_box_cinfo_127_cfa_info);
	    {
	       obj_t obj_3340;
	       obj_3340 = (obj_t) (obj2078_2865);
	       (((obj_t) CREF(obj_3340))->header = MAKE_HEADER(arg2358_2868, 0), BUNSPEC);
	    }
	 }
	 obj2078_2865;
      }
      {
	 approx_t aux_3757;
	 {
	    make_box_cinfo_127_t obj_3342;
	    obj_3342 = (make_box_cinfo_127_t) (node_2860);
	    {
	       obj_t aux_3759;
	       {
		  object_t aux_3760;
		  aux_3760 = (object_t) (obj_3342);
		  aux_3759 = OBJECT_WIDENING(aux_3760);
	       }
	       aux_3757 = (((make_box_cinfo_127_t) CREF(aux_3759))->approx);
	    }
	 }
	 return approx_set_top__187_cfa_approx(aux_3757);
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_box()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_BOX");
   module_initialization_70_tools_error(((long) 0), "CFA_BOX");
   module_initialization_70_tools_shape(((long) 0), "CFA_BOX");
   module_initialization_70_engine_param(((long) 0), "CFA_BOX");
   module_initialization_70_type_type(((long) 0), "CFA_BOX");
   module_initialization_70_type_cache(((long) 0), "CFA_BOX");
   module_initialization_70_ast_var(((long) 0), "CFA_BOX");
   module_initialization_70_ast_node(((long) 0), "CFA_BOX");
   module_initialization_70_cfa_info(((long) 0), "CFA_BOX");
   module_initialization_70_cfa_loose(((long) 0), "CFA_BOX");
   module_initialization_70_cfa_setup(((long) 0), "CFA_BOX");
   module_initialization_70_cfa_approx(((long) 0), "CFA_BOX");
   module_initialization_70_cfa_cfa(((long) 0), "CFA_BOX");
   module_initialization_70_cfa_iterate(((long) 0), "CFA_BOX");
   return module_initialization_70_cfa_closure(((long) 0), "CFA_BOX");
}
