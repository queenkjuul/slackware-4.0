/*===========================================================================*/
/*   (Ieee/char.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _integer__char_ur1144_139___r4_characters_6_6(obj_t, obj_t);
static obj_t _char___1130_116___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char___1131_7___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _integer__char1143_74___r4_characters_6_6(obj_t, obj_t);
extern long char__integer_184___r4_characters_6_6(unsigned char);
extern unsigned char char_downcase_76___r4_characters_6_6(unsigned char);
extern bool_t char_alphabetic__208___r4_characters_6_6(unsigned char);
static obj_t _char_upper_case_1140_218___r4_characters_6_6(obj_t, obj_t);
static obj_t _char_ci__1133_115___r4_characters_6_6(obj_t, obj_t, obj_t);
extern unsigned char char_or_106___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_ci____41___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_ci___21___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_ci___242___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_ci___112___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_numeric__32___r4_characters_6_6(unsigned char);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern unsigned char integer__char_ur_23___r4_characters_6_6(long);
extern bool_t char_ci____192___r4_characters_6_6(unsigned char, unsigned char);
static obj_t _char__1128_94___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char_ci__1132_47___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char_or1147_43___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char_ci___1135_235___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char_lower_case_1141_217___r4_characters_6_6(obj_t, obj_t);
static obj_t _char_ci___1136_29___r4_characters_6_6(obj_t, obj_t, obj_t);
extern unsigned char integer__char_140___r4_characters_6_6(long);
static obj_t _char__134___r4_characters_6_6(obj_t, obj_t);
static obj_t _char_upcase1145_59___r4_characters_6_6(obj_t, obj_t);
extern bool_t char_lower_case__222___r4_characters_6_6(unsigned char);
static obj_t _char__1127_178___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char_ci__1134_57___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char__integer1142_184___r4_characters_6_6(obj_t, obj_t);
extern bool_t char__59___r4_characters_6_6(obj_t);
static obj_t _char_whitespace_1139_57___r4_characters_6_6(obj_t, obj_t);
static obj_t _char_downcase1146_238___r4_characters_6_6(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_characters_6_6();
extern bool_t char____252___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char___195___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char___215___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char___13___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_whitespace__92___r4_characters_6_6(unsigned char);
static obj_t _char_numeric_1138_33___r4_characters_6_6(obj_t, obj_t);
static obj_t require_initialization_114___r4_characters_6_6 = BUNSPEC;
extern bool_t char_upper_case__12___r4_characters_6_6(unsigned char);
static obj_t _char__1129_210___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char_alphabetic_1137_169___r4_characters_6_6(obj_t, obj_t);
extern bool_t char____152___r4_characters_6_6(unsigned char, unsigned char);
extern unsigned char char_upcase_134___r4_characters_6_6(unsigned char);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( char_ci___env_200___r4_characters_6_6, _char_ci__1132_47___r4_characters_6_61151, _char_ci__1132_47___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( integer__char_ur_env_241___r4_characters_6_6, _integer__char_ur1144_139___r4_characters_6_61152, _integer__char_ur1144_139___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_ci___env_123___r4_characters_6_6, _char_ci__1134_57___r4_characters_6_61153, _char_ci__1134_57___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_or_env_17___r4_characters_6_6, _char_or1147_43___r4_characters_6_61154, _char_or1147_43___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_upper_case__env_74___r4_characters_6_6, _char_upper_case_1140_218___r4_characters_6_61155, _char_upper_case_1140_218___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char__integer_env_161___r4_characters_6_6, _char__integer1142_184___r4_characters_6_61156, _char__integer1142_184___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char___env_34___r4_characters_6_6, _char__1128_94___r4_characters_6_61157, _char__1128_94___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_downcase_env_22___r4_characters_6_6, _char_downcase1146_238___r4_characters_6_61158, _char_downcase1146_238___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_numeric__env_250___r4_characters_6_6, _char_numeric_1138_33___r4_characters_6_61159, _char_numeric_1138_33___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_ci____env_142___r4_characters_6_6, _char_ci___1135_235___r4_characters_6_61160, _char_ci___1135_235___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_ci____env_66___r4_characters_6_6, _char_ci___1136_29___r4_characters_6_61161, _char_ci___1136_29___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char___env_167___r4_characters_6_6, _char__1127_178___r4_characters_6_61162, _char__1127_178___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_lower_case__env_97___r4_characters_6_6, _char_lower_case_1141_217___r4_characters_6_61163, _char_lower_case_1141_217___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( integer__char_env_143___r4_characters_6_6, _integer__char1143_74___r4_characters_6_61164, _integer__char1143_74___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char____env_114___r4_characters_6_6, _char___1130_116___r4_characters_6_61165, _char___1130_116___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char____env_175___r4_characters_6_6, _char___1131_7___r4_characters_6_61166, _char___1131_7___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char__env_119___r4_characters_6_6, _char__134___r4_characters_6_61167, _char__134___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char___env_57___r4_characters_6_6, _char__1129_210___r4_characters_6_61168, _char__1129_210___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_upcase_env_199___r4_characters_6_6, _char_upcase1145_59___r4_characters_6_61169, _char_upcase1145_59___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_whitespace__env_29___r4_characters_6_6, _char_whitespace_1139_57___r4_characters_6_61170, _char_whitespace_1139_57___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_ci___env_202___r4_characters_6_6, _char_ci__1133_115___r4_characters_6_61171, _char_ci__1133_115___r4_characters_6_6, 0L, 2 );
DEFINE_STRING( string1149___r4_characters_6_6, string1149___r4_characters_6_61172, "integer out of range", 20 );
DEFINE_STRING( string1148___r4_characters_6_6, string1148___r4_characters_6_61173, "integer->char", 13 );
DEFINE_EXPORT_PROCEDURE( char_alphabetic__env_54___r4_characters_6_6, _char_alphabetic_1137_169___r4_characters_6_61174, _char_alphabetic_1137_169___r4_characters_6_6, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r4_characters_6_6(long checksum_488, char * from_489)
{
if(CBOOL(require_initialization_114___r4_characters_6_6)){
require_initialization_114___r4_characters_6_6 = BBOOL(((bool_t)0));
imported_modules_init_94___r4_characters_6_6();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* char? */bool_t char__59___r4_characters_6_6(obj_t obj_1)
{
return CHARP(obj_1);
}


/* _char? */obj_t _char__134___r4_characters_6_6(obj_t env_393, obj_t obj_394)
{
{
bool_t aux_495;
{
obj_t obj_448;
obj_448 = obj_394;
aux_495 = CHARP(obj_448);
}
return BBOOL(aux_495);
}
}


/* char=? */bool_t char___215___r4_characters_6_6(unsigned char char1_2, unsigned char char2_3)
{
return (char1_2==char2_3);
}


/* _char=?1127 */obj_t _char__1127_178___r4_characters_6_6(obj_t env_395, obj_t char1_396, obj_t char2_397)
{
{
bool_t aux_499;
{
unsigned char char1_449;
unsigned char char2_450;
char1_449 = (unsigned char)CCHAR(char1_396);
char2_450 = (unsigned char)CCHAR(char2_397);
aux_499 = (char1_449==char2_450);
}
return BBOOL(aux_499);
}
}


/* char<? */bool_t char___13___r4_characters_6_6(unsigned char char1_4, unsigned char char2_5)
{
return (char1_4<char2_5);
}


/* _char<?1128 */obj_t _char__1128_94___r4_characters_6_6(obj_t env_398, obj_t char1_399, obj_t char2_400)
{
{
bool_t aux_505;
{
unsigned char char1_451;
unsigned char char2_452;
char1_451 = (unsigned char)CCHAR(char1_399);
char2_452 = (unsigned char)CCHAR(char2_400);
aux_505 = (char1_451<char2_452);
}
return BBOOL(aux_505);
}
}


/* char>? */bool_t char___195___r4_characters_6_6(unsigned char char1_6, unsigned char char2_7)
{
return (char1_6>char2_7);
}


/* _char>?1129 */obj_t _char__1129_210___r4_characters_6_6(obj_t env_401, obj_t char1_402, obj_t char2_403)
{
{
bool_t aux_511;
{
unsigned char char1_453;
unsigned char char2_454;
char1_453 = (unsigned char)CCHAR(char1_402);
char2_454 = (unsigned char)CCHAR(char2_403);
aux_511 = (char1_453>char2_454);
}
return BBOOL(aux_511);
}
}


/* char<=? */bool_t char____152___r4_characters_6_6(unsigned char char1_8, unsigned char char2_9)
{
return (char1_8<=char2_9);
}


/* _char<=?1130 */obj_t _char___1130_116___r4_characters_6_6(obj_t env_404, obj_t char1_405, obj_t char2_406)
{
{
bool_t aux_517;
{
unsigned char char1_455;
unsigned char char2_456;
char1_455 = (unsigned char)CCHAR(char1_405);
char2_456 = (unsigned char)CCHAR(char2_406);
aux_517 = (char1_455<=char2_456);
}
return BBOOL(aux_517);
}
}


/* char>=? */bool_t char____252___r4_characters_6_6(unsigned char char1_10, unsigned char char2_11)
{
return (char1_10>=char2_11);
}


/* _char>=?1131 */obj_t _char___1131_7___r4_characters_6_6(obj_t env_407, obj_t char1_408, obj_t char2_409)
{
{
bool_t aux_523;
{
unsigned char char1_457;
unsigned char char2_458;
char1_457 = (unsigned char)CCHAR(char1_408);
char2_458 = (unsigned char)CCHAR(char2_409);
aux_523 = (char1_457>=char2_458);
}
return BBOOL(aux_523);
}
}


/* char-ci=? */bool_t char_ci___242___r4_characters_6_6(unsigned char char1_12, unsigned char char2_13)
{
{
unsigned char aux_530;
unsigned char aux_528;
aux_530 = toupper(char2_13);
aux_528 = toupper(char1_12);
return (aux_528==aux_530);
}
}


/* _char-ci=?1132 */obj_t _char_ci__1132_47___r4_characters_6_6(obj_t env_410, obj_t char1_411, obj_t char2_412)
{
{
bool_t aux_533;
{
unsigned char char1_459;
unsigned char char2_460;
char1_459 = (unsigned char)CCHAR(char1_411);
char2_460 = (unsigned char)CCHAR(char2_412);
{
unsigned char aux_538;
unsigned char aux_536;
aux_538 = toupper(char2_460);
aux_536 = toupper(char1_459);
aux_533 = (aux_536==aux_538);
}
}
return BBOOL(aux_533);
}
}


/* char-ci<? */bool_t char_ci___112___r4_characters_6_6(unsigned char char1_14, unsigned char char2_15)
{
{
unsigned char aux_544;
unsigned char aux_542;
aux_544 = toupper(char2_15);
aux_542 = toupper(char1_14);
return (aux_542<aux_544);
}
}


/* _char-ci<?1133 */obj_t _char_ci__1133_115___r4_characters_6_6(obj_t env_413, obj_t char1_414, obj_t char2_415)
{
{
bool_t aux_547;
{
unsigned char char1_461;
unsigned char char2_462;
char1_461 = (unsigned char)CCHAR(char1_414);
char2_462 = (unsigned char)CCHAR(char2_415);
{
unsigned char aux_552;
unsigned char aux_550;
aux_552 = toupper(char2_462);
aux_550 = toupper(char1_461);
aux_547 = (aux_550<aux_552);
}
}
return BBOOL(aux_547);
}
}


/* char-ci>? */bool_t char_ci___21___r4_characters_6_6(unsigned char char1_16, unsigned char char2_17)
{
{
unsigned char aux_558;
unsigned char aux_556;
aux_558 = toupper(char2_17);
aux_556 = toupper(char1_16);
return (aux_556>aux_558);
}
}


/* _char-ci>?1134 */obj_t _char_ci__1134_57___r4_characters_6_6(obj_t env_416, obj_t char1_417, obj_t char2_418)
{
{
bool_t aux_561;
{
unsigned char char1_463;
unsigned char char2_464;
char1_463 = (unsigned char)CCHAR(char1_417);
char2_464 = (unsigned char)CCHAR(char2_418);
{
unsigned char aux_566;
unsigned char aux_564;
aux_566 = toupper(char2_464);
aux_564 = toupper(char1_463);
aux_561 = (aux_564>aux_566);
}
}
return BBOOL(aux_561);
}
}


/* char-ci<=? */bool_t char_ci____192___r4_characters_6_6(unsigned char char1_18, unsigned char char2_19)
{
{
unsigned char aux_572;
unsigned char aux_570;
aux_572 = toupper(char2_19);
aux_570 = toupper(char1_18);
return (aux_570<=aux_572);
}
}


/* _char-ci<=?1135 */obj_t _char_ci___1135_235___r4_characters_6_6(obj_t env_419, obj_t char1_420, obj_t char2_421)
{
{
bool_t aux_575;
{
unsigned char char1_465;
unsigned char char2_466;
char1_465 = (unsigned char)CCHAR(char1_420);
char2_466 = (unsigned char)CCHAR(char2_421);
{
unsigned char aux_580;
unsigned char aux_578;
aux_580 = toupper(char2_466);
aux_578 = toupper(char1_465);
aux_575 = (aux_578<=aux_580);
}
}
return BBOOL(aux_575);
}
}


/* char-ci>=? */bool_t char_ci____41___r4_characters_6_6(unsigned char char1_20, unsigned char char2_21)
{
{
unsigned char aux_586;
unsigned char aux_584;
aux_586 = toupper(char2_21);
aux_584 = toupper(char1_20);
return (aux_584>=aux_586);
}
}


/* _char-ci>=?1136 */obj_t _char_ci___1136_29___r4_characters_6_6(obj_t env_422, obj_t char1_423, obj_t char2_424)
{
{
bool_t aux_589;
{
unsigned char char1_467;
unsigned char char2_468;
char1_467 = (unsigned char)CCHAR(char1_423);
char2_468 = (unsigned char)CCHAR(char2_424);
{
unsigned char aux_594;
unsigned char aux_592;
aux_594 = toupper(char2_468);
aux_592 = toupper(char1_467);
aux_589 = (aux_592>=aux_594);
}
}
return BBOOL(aux_589);
}
}


/* char-alphabetic? */bool_t char_alphabetic__208___r4_characters_6_6(unsigned char char_22)
{
{
unsigned char c_469;
c_469 = toupper(char_22);
if((c_469>=((unsigned char)'A'))){
return (c_469<=((unsigned char)'Z'));
}
 else {
return ((bool_t)0);
}
}
}


/* _char-alphabetic?1137 */obj_t _char_alphabetic_1137_169___r4_characters_6_6(obj_t env_425, obj_t char_426)
{
{
bool_t aux_602;
{
unsigned char char_166_470;
char_166_470 = (unsigned char)CCHAR(char_426);
{
unsigned char c_471;
c_471 = toupper(char_166_470);
if((c_471>=((unsigned char)'A'))){
aux_602 = (c_471<=((unsigned char)'Z'));
}
 else {
aux_602 = ((bool_t)0);
}
}
}
return BBOOL(aux_602);
}
}


/* char-numeric? */bool_t char_numeric__32___r4_characters_6_6(unsigned char char_23)
{
if((char_23>=((unsigned char)'0'))){
return (char_23<=((unsigned char)'9'));
}
 else {
return ((bool_t)0);
}
}


/* _char-numeric?1138 */obj_t _char_numeric_1138_33___r4_characters_6_6(obj_t env_427, obj_t char_428)
{
{
bool_t aux_612;
{
unsigned char char_166_472;
char_166_472 = (unsigned char)CCHAR(char_428);
if((char_166_472>=((unsigned char)'0'))){
aux_612 = (char_166_472<=((unsigned char)'9'));
}
 else {
aux_612 = ((bool_t)0);
}
}
return BBOOL(aux_612);
}
}


/* char-whitespace? */bool_t char_whitespace__92___r4_characters_6_6(unsigned char char_24)
{
{
bool_t _ortest_1002_473;
_ortest_1002_473 = (char_24==((unsigned char)' '));
if(_ortest_1002_473){
return _ortest_1002_473;
}
 else {
bool_t _ortest_1003_474;
_ortest_1003_474 = (char_24==((unsigned char)'\t'));
if(_ortest_1003_474){
return _ortest_1003_474;
}
 else {
bool_t _ortest_1004_475;
_ortest_1004_475 = (char_24==((unsigned char)'\r'));
if(_ortest_1004_475){
return _ortest_1004_475;
}
 else {
return (char_24==((unsigned char)'\n'));
}
}
}
}
}


/* _char-whitespace?1139 */obj_t _char_whitespace_1139_57___r4_characters_6_6(obj_t env_429, obj_t char_430)
{
{
bool_t aux_625;
{
unsigned char char_166_476;
char_166_476 = (unsigned char)CCHAR(char_430);
{
bool_t _ortest_1002_477;
_ortest_1002_477 = (char_166_476==((unsigned char)' '));
if(_ortest_1002_477){
aux_625 = _ortest_1002_477;
}
 else {
bool_t _ortest_1003_478;
_ortest_1003_478 = (char_166_476==((unsigned char)'\t'));
if(_ortest_1003_478){
aux_625 = _ortest_1003_478;
}
 else {
bool_t _ortest_1004_479;
_ortest_1004_479 = (char_166_476==((unsigned char)'\r'));
if(_ortest_1004_479){
aux_625 = _ortest_1004_479;
}
 else {
aux_625 = (char_166_476==((unsigned char)'\n'));
}
}
}
}
}
return BBOOL(aux_625);
}
}


/* char-upper-case? */bool_t char_upper_case__12___r4_characters_6_6(unsigned char char_25)
{
if((char_25>=((unsigned char)'A'))){
return (char_25<=((unsigned char)'Z'));
}
 else {
return ((bool_t)0);
}
}


/* _char-upper-case?1140 */obj_t _char_upper_case_1140_218___r4_characters_6_6(obj_t env_431, obj_t char_432)
{
{
bool_t aux_638;
{
unsigned char char_166_480;
char_166_480 = (unsigned char)CCHAR(char_432);
if((char_166_480>=((unsigned char)'A'))){
aux_638 = (char_166_480<=((unsigned char)'Z'));
}
 else {
aux_638 = ((bool_t)0);
}
}
return BBOOL(aux_638);
}
}


/* char-lower-case? */bool_t char_lower_case__222___r4_characters_6_6(unsigned char char_26)
{
if((char_26>=((unsigned char)'a'))){
return (char_26<=((unsigned char)'z'));
}
 else {
return ((bool_t)0);
}
}


/* _char-lower-case?1141 */obj_t _char_lower_case_1141_217___r4_characters_6_6(obj_t env_433, obj_t char_434)
{
{
bool_t aux_647;
{
unsigned char char_166_481;
char_166_481 = (unsigned char)CCHAR(char_434);
if((char_166_481>=((unsigned char)'a'))){
aux_647 = (char_166_481<=((unsigned char)'z'));
}
 else {
aux_647 = ((bool_t)0);
}
}
return BBOOL(aux_647);
}
}


/* char->integer */long char__integer_184___r4_characters_6_6(unsigned char char_27)
{
return (char_27);
}


/* _char->integer1142 */obj_t _char__integer1142_184___r4_characters_6_6(obj_t env_435, obj_t char_436)
{
{
long aux_654;
{
unsigned char char_166_482;
char_166_482 = (unsigned char)CCHAR(char_436);
aux_654 = (char_166_482);
}
return BINT(aux_654);
}
}


/* integer->char */unsigned char integer__char_140___r4_characters_6_6(long int_28)
{
{
bool_t test_658;
if((int_28>=((long)0))){
test_658 = (int_28<=((long)255));
}
 else {
test_658 = ((bool_t)0);
}
if(test_658){
return (int_28);
}
 else {
FAILURE(string1148___r4_characters_6_6,string1149___r4_characters_6_6,BINT(int_28));}
}
}


/* _integer->char1143 */obj_t _integer__char1143_74___r4_characters_6_6(obj_t env_437, obj_t int_438)
{
{
unsigned char aux_665;
aux_665 = integer__char_140___r4_characters_6_6((long)CINT(int_438));
return BCHAR(aux_665);
}
}


/* integer->char-ur */unsigned char integer__char_ur_23___r4_characters_6_6(long int_29)
{
return (int_29);
}


/* _integer->char-ur1144 */obj_t _integer__char_ur1144_139___r4_characters_6_6(obj_t env_439, obj_t int_440)
{
{
unsigned char aux_670;
{
long int_184_483;
int_184_483 = (long)CINT(int_440);
aux_670 = (int_184_483);
}
return BCHAR(aux_670);
}
}


/* char-upcase */unsigned char char_upcase_134___r4_characters_6_6(unsigned char char_30)
{
return toupper(char_30);
}


/* _char-upcase1145 */obj_t _char_upcase1145_59___r4_characters_6_6(obj_t env_441, obj_t char_442)
{
{
unsigned char aux_675;
{
unsigned char char_166_484;
char_166_484 = (unsigned char)CCHAR(char_442);
aux_675 = toupper(char_166_484);
}
return BCHAR(aux_675);
}
}


/* char-downcase */unsigned char char_downcase_76___r4_characters_6_6(unsigned char char_31)
{
return tolower(char_31);
}


/* _char-downcase1146 */obj_t _char_downcase1146_238___r4_characters_6_6(obj_t env_443, obj_t char_444)
{
{
unsigned char aux_680;
{
unsigned char char_166_485;
char_166_485 = (unsigned char)CCHAR(char_444);
aux_680 = tolower(char_166_485);
}
return BCHAR(aux_680);
}
}


/* char-or */unsigned char char_or_106___r4_characters_6_6(unsigned char char1_32, unsigned char char2_33)
{
return (char1_32|char2_33);
}


/* _char-or1147 */obj_t _char_or1147_43___r4_characters_6_6(obj_t env_445, obj_t char1_446, obj_t char2_447)
{
{
unsigned char aux_685;
{
unsigned char char1_486;
unsigned char char2_487;
char1_486 = (unsigned char)CCHAR(char1_446);
char2_487 = (unsigned char)CCHAR(char2_447);
aux_685 = (char1_486|char2_487);
}
return BCHAR(aux_685);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_characters_6_6()
{
return module_initialization_70___error(((long)0), "__R4_CHARACTERS_6_6");
}

